# SILICAFLUX HBMCORE — changelog

## v2 (2026-11-25) — independent re-verification, review fixes, refresh-management research hook

v1 was re-run unchanged on a stock toolchain (Verilator 5.020) and gave **43 PASS / 26 FAIL**. v2 fixes the causes, then
fixes what an independent three-way review and new tests found. Full record: `docs/AUDIT_V2.md`, `docs/REVIEW_V2.md`.

### Correctness fixes in synthesizable RTL (each one has a test that fails on v1)

**Scheduler** (`sf_hbm_scheduler`)
* Anti-starvation was defeated by boosted row hits (A1).
* Refresh could issue before tRC since the last ACT (A2).

**Refresh** (`sf_hbm_refresh`)
* `max_postpone` / `max_pullin` were truncated / unreachable, so refresh could stop with no alarm (A3).
* A refresh-mode CSR change in the middle of a sequence corrupted it (R1).
* The refresh debt was re-interpreted across modes, giving spurious deadline misses (R2).

**Pseudo-channel and init** (`sf_hbm_pseudochannel`)
* Re-init with open rows deadlocked (A4).

**Read return** (`sf_hbm_read_return`)
* The late data of a timed-out read was delivered to the next read as good data (B4).

**ECC / RAS** (`sf_hbm_ecc_ras`)
* An injection arm issued in the consuming cycle was lost (B5).
* Two same-cycle PHY error sources were counted once (B6).

**Controller top** (`sf_hbm4_controller`)
* Did not compile on Verilator 5.020 (`BLKLOOPINIT`) for some configurations; `-Wall` width warnings.

**DMA adapter** (`sf_hbm_dma_adapter`)
* Hung for ever under request-link back-pressure at the descriptor (C1).
* An SRAM-side error wedged the DataFabric memory node (C2).
* ECC-flagged SRAM data was written to HBM as good data (C5).
* A single error flit hung the HBM -> SRAM direction (C6).

**Other integration blocks**
* `sf_hbm_datafabric`: the request ID was unstable during a stall (C4).
* `sf_hbm_addr_map`: silent aliasing for more than 8 stacks or 64 channels (C3).
* `sf_hbm_csr`, `sf_hbm_channel`: wrong GEOMETRY readback (C7); occupancy wrap (C8).

### Verification environment

**DRAM model (`hbm4_dram_model`)**
* It was blind on Verilator 5.020: a simulator defect, isolated in `verification/toolchain/`.
* New checks:
  * PHY ready (contract C1);
  * tMRD between two MRS;
  * refresh overlaps;
  * tRC before refresh;
  * RFM rules;
  * a RowHammer research metric.

**Python reference model**
* Rules 18-20, matching the model above, plus their tests.

**Benches and tests**
* New unit bench `tb_read_return`.
* New `tb_pc_single` tests: `reinit`, `longsat`, `rowhammer`, `refswitch`; plusargs `TRCADD`, `MAXPP`, `LIM`, `NH`.
* New `tb_dma_spm` reproducers.
* New cocotb ECC tests.
* `tb_bench` stops at completion on Verilator 5.020. Before the fix every benchmark ran to its 4 M-cycle cap, and its
  refresh / PRE / command counts covered the whole capped run (`docs/AUDIT_V2.md` §3).

**Timing profiles**
* New field `trfm`.
* New profile 3 `sim_trc_slack` (tRC > tRAS + tRP).
* The generator rejects postpone / pull-in limits above 100.

**Formal**
* Runs on the PyPI YoWASP toolchain.
* Read-return ghost model updated to the v2 contract.
* Bank-FSM harness covers `rfm_i`.
* 2 new formal mutants.

**Mutation and coverage**
* 3 new RTL mutants (`phy_ready_ignored`, `rr_orphan_unpoisoned`, `rr_orphan_nodrop`).
* **New:** Verilator line/block coverage (`scripts/coverage.py`, `reports/coverage/`).
  * The script merges the raw coverage points itself, across instances and runs.
  * With Verilator 5.020, `verilator_coverage --write-info` did not combine the same source point across different
    instance hierarchies: lines hit thousands of times were written as 0 (first evaluation: 86.5 %, re-evaluated from
    the same data: 93.9 %).

**Portability**
* Tools come from `PATH`; nothing assumes `/opt/vl548`.
* cocotb 1.9 and 2.x both supported.

### New features

* `rtl/sf_hbm_rfm.sv`: refresh-management (RFM / directed-RFM) **research hook**, with per-bank rolling ACT counts, RFM
  requests, ACT blocking and an aggressor-row tracker. Configured through CSR `REFCFG[31:4]`; perf counters 33/34
  (per-PC 44/45). ENGINEERING_ASSUMPTION. It provides no RowHammer protection (`docs/ROWHAMMER.md`).
* Proxy-node synthesis on the open NanGate45 library: area in um^2 and ABC critical-path delay
  (`scripts/synth_ng45.py`, `reports/synth_ng45/`).
* SECDED encode/decode restructured for timing: constant tables and reduction trees instead of 256 sequential loop
  iterations. About 6.4 ns -> 1.7 ns on the NanGate45 proxy. **Proven equivalent** to v1 for all inputs
  (`verification/formal/eq_secded.py`, SAT on an explicit miter with a non-vacuity mutant).
* Documents:
  * `docs/SIMULATOR_COMPARISON.md`: Ramulator 2.1 / DRAMsim3 HBM4 investigation;
  * `docs/AUDIT_V2.md`;
  * `docs/REVIEW_V2.md`.
* Standards matrix: rows REF-04 (research hook), REF-06, TIM-05, VER-01.

### Not done in v2 (still open)

* Read-modify-write for partial writes with controller ECC.
* Pipelining of the scheduler select (3.0 ns on the NanGate45 proxy). The SECDED path was fixed by restructuring, see above.
* Integration of an external HBM4 simulator (none is an authority; `docs/SIMULATOR_COMPARISON.md`).
* PHY backend B (licensed PHY), JEDEC values and encodings: unchanged, still unavailable.

## v1

The original release, preserved in the repository as `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hbmcore.zip`.
