# SILICAFLUX HBMCORE - independent Python reference model

Built **only** from `docs/TIMING_RULES.md`, `docs/ADDRESS_MAP.md`, `docs/RAS_CODE.md`, `docs/ORDERING.md` and
`configs/timing/profiles.json`; it never looked at the RTL, so it can cross-check the RTL and the behavioural
DRAM model.

> **Status: HYPOTHETICAL_SIM.** Every timing profile is a hypothetical simulation profile. Nothing here is
> JEDEC / JESD270-4 / HBM4 compliant and no result may be described as such. The profile `status` is carried
> into every checker header, JSON report and `SimResult.summary()`.

Assumptions and spec holes are listed in [`SPEC_AMBIGUITIES.md`](SPEC_AMBIGUITIES.md).

## Module map (`python/hbm4/`)

| module | role |
|---|---|
| `commands.py` | command codes 1..13 (ACT ... RFM) and names |
| `timing.py` | `load_profiles`, `Profile` (+ derived RTW / WTR_S / WTR_L / WR2PRE, refresh bound), pure legality oracle `check_command` / `apply_command`, `TimingChecker`, `Violation` |
| `bank_state.py` | `PcState` / `BankState`: open row, last ACT/PRE/RD/WR, refresh busy times, FAW history, per-group last ACT / column / WR, power state (one `PcState` per pseudo-channel) |
| `trace_check.py` | CLI + `check_trace_file()` for the command-trace format |
| `address_map.py` | `AddrMapCfg`, `map_addr`, `unmap_loc`, `check_addr`, `pc_index`, MAP_* modes |
| `reference_memory.py` | sparse masked `RefMemory`, `secded_encode` / `secded_decode` (10 check bits) |
| `transactions.py` | `Txn` / `Rsp`, ORD_* attributes, error codes, `must_stay_ordered` |
| `scoreboard.py` / `txn_check.py` | `check_transactions()` and the `hbm4.txn_check` CLI for the JSON-lines transaction log |
| `scheduler.py` | `simulate()`: one-pseudo-channel cycle-by-cycle FCFS / FR-FCFS performance model (not cycle-matched to any RTL) |
| `performance.py` | `percentile` (nearest-rank), decimal `bandwidth_gb_s`, `pin_bandwidth_gb_s`, `efficiency`, `summarize` |

## Run

From the project root (`hbmcore/`):

```
PYTHONPATH=python python3 -m pytest python/tests -q

PYTHONPATH=python python3 -m hbm4.trace_check trace.txt --profile 1 [--json out.json] [--end-cycle C] [--num-pcs N]
PYTHONPATH=python python3 -m hbm4.txn_check   log.jsonl [--json out.json] [--ecc] [--num-channels N] [--allow-err 7]
```

Exit codes: 0 clean, 1 violations / failures, 2 usage or parse error.

Trace format (docs/ORDERING.md): `cycle pc cmd bg ba row col` and `W cycle pc` lines; blank lines and `#` lines
are ignored. Feed events in non-decreasing cycle order per pseudo-channel; a `W` line must come after the WR it
belongs to. Pass `--end-cycle` (last cycle covered) so missing write data and the refresh deadline are judged.

## Tests

`python/tests/` hand-computes every expected number from the spec (the arithmetic is in the comments): one
illegal command trace per timing rule (and the legal boundary one cycle later), the ADDRESS_MAP worked example,
exhaustive bijection tests on a reduced geometry, hand-derived SECDED check bits, negative scoreboard tests
(corrupted byte, swapped src, duplicate / lost / foreign response, reordered same-id pair), and scheduler
timelines whose every emitted trace is re-validated by `TimingChecker`.
