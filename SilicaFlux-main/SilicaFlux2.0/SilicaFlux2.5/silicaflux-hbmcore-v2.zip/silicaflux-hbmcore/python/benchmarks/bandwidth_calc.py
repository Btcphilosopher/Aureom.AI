#!/usr/bin/env python3
"""Analytical bandwidth calculator (docs/BANDWIDTH.md).

Convention: DECIMAL units, 1 GB = 1e9 B, 1 TB = 1e12 B. Theoretical (pin) bandwidth for a DDR-style parallel interface:
        bandwidth = data_pins * data_rate_per_pin / 8
This is a THEORETICAL PIN THROUGHPUT, not sustained application bandwidth. `efficiency` is only meaningful together with its definition:
efficiency = measured / theoretical, where BOTH must refer to the same configuration, and `measured` comes from a defined method
(the HBMCore benchmark: bytes of error-free responses / simulated time, whole run, including ramp-up).

usage: python3 python/benchmarks/bandwidth_calc.py [--pins 2048 --gbps 8] [--measured GBPS] [--bench reports/bench/A_seq_read.json]
"""
import argparse, json, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from hbm4.performance import pin_bandwidth_gb_s, efficiency  # noqa: E402


def sim_peak_gb_s(npc, burst_cycles, granule_bytes=32, clock_mhz=1000):
    """Peak of the SIMULATION convention: one `granule_bytes` per pseudo-channel every `burst_cycles` controller cycles."""
    return npc * granule_bytes / burst_cycles * clock_mhz / 1000.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pins", type=float, default=2048)
    ap.add_argument("--gbps", type=float, default=8.0, help="data rate per pin in Gb/s (an INPUT, not a claim about any HBM4 speed grade)")
    ap.add_argument("--measured", type=float)
    ap.add_argument("--bench")
    a = ap.parse_args()
    t = pin_bandwidth_gb_s(a.pins, a.gbps)
    print(f"theoretical pin bandwidth: {a.pins:.0f} pins x {a.gbps} Gb/s / 8 = {t:.1f} GB/s = {t/1000:.3f} TB/s   (pin throughput, not application bandwidth)")
    if a.bench:
        r = json.loads(pathlib.Path(a.bench).read_text())
        npc, tb = r["config"]["npc"], r["config"]["tburst"]
        peak = sim_peak_gb_s(npc, tb)
        m = r["bandwidth_gb_s"]
        print(f"{r['benchmark']}: simulation-convention peak = {npc} PCs x 32 B / {tb} cycle @ 1 GHz = {peak:.1f} GB/s;  modelled measured = {m:.1f} GB/s;  efficiency = {efficiency(m, peak):.3f}")
        print("loss accounting available from the same file: row hit rate, ACT/PRE counts, refresh overhead (refresh.overhead_fraction), timing/queue stalls")
    if a.measured is not None:
        print(f"efficiency vs pin bandwidth = {efficiency(a.measured, t):.3f}  (only meaningful if the measured configuration equals the pin configuration)")


if __name__ == "__main__":
    main()
