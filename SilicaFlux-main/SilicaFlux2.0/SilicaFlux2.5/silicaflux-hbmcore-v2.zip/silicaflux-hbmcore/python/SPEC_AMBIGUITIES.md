# Spec ambiguities found while building the independent Python model

Derived only from docs/TIMING_RULES.md, ADDRESS_MAP.md, RAS_CODE.md, ORDERING.md and
configs/timing/profiles.json. Each bullet: doc - what is unclear - what the model assumes
(the most literal reading). Where a cheap switch exists it is named.

## TIMING_RULES.md

- **PRE / PREA to a closed bank and `last_PRE`.** "Closed banks are unaffected (PRE to a closed bank
  is a legal no-op)" but also "After PRE the bank is precharged and `last_PRE(b) = now`". Unclear whether a
  no-op PRE restarts the `trp` window. Assumed NOT (state unchanged). Switch:
  `TimingChecker(..., pre_noop_updates_last_pre=True)`. An RTL/DRAM model that stamps `last_PRE`
  unconditionally will disagree with this model on `ACT` shortly after a redundant PRE.
- **tRC is never independently violable.** In all three profiles `trc == tras + trp`, so any ACT that
  breaks tRC also breaks tRAS (via the PRE) or tRP. Not an error in the spec, but a tRC check cannot
  be tested in isolation; tests assert `{tRC, tRP}`.
- **REF_AB vs per-bank refresh, REF_PB vs all-bank refresh.** REF_AB lists only `ref_busy_until`; REF_PB
  lists only `bank_ref_until(b)`. Not stated whether REF_AB must wait for a running REF_PB on any bank, or
  REF_PB for a running REF_AB. Assumed: no such cross-check (only ACT checks both).
- **RD / WR / PRE during tRFC / tRFCpb.** No rule states them (RD/WR need an open bank, and REF requires all
  banks precharged, so they are implicitly excluded for REF_AB). Not enforced.
- **RFM (cmd 13).** Appears in the command-code list but TIMING_RULES.md gives it no rules or effects.
  Assumed: no checks and no state effect, other than the global gates (low-power, tMRD, tXP/tXS).
- **Global gates apply to every command.** "no command (other than PDX/SRX) may issue for `tmrd`" and
  "After PDX no command may issue for `txp`" are read literally: they include MRS, PDE/SRE, REF, RFM.
  PDX/SRX are exempt from tMRD. No minimum PDE->PDX / SRE->SRX residency is stated, so none is checked.
- **Commands issued while in low power.** Only the matching exit is legal; the model reports
  `command_while_low_power` and ignores the command's state effect (a PDX in self-refresh is reported
  this way too; a PDX/SRX in the active state is `exit_wrong_state`).
- **State effects of violating commands.** The spec defines effects for legal commands only. The model applies
  the effect of a rule-violating command (it was issued on the bus), so one fault does not mask later ones.
- **Write data with `burst > 1`.** The data-timing paragraph says a WR takes "its write data ... during cycle
  `t + wl` -- exactly then". The trace format has one `W cycle pc` line per beat. Assumed ONE beat per WR at
  exactly `t + wl`, whatever `burst` is (profile 2 has burst = 2). `burst` only enters RTW/WTR/WR2PRE. If the
  DRAM model logs `burst` beats per WR the checker will flag the extra beat as `write_data_unexpected`.
- **Read data (`t + rl`) is not checkable.** The trace format has no read-data event, so only the write
  data bus is checked.
- **Missing write data needs an end of trace.** `write_data_missing` is raised at `finish(end_cycle)` for WRs
  whose data was due at or before `end_cycle`; default `end_cycle` = last cycle seen. A beat at the wrong
  cycle is `write_data_off_time` (it consumes the oldest outstanding WR); a beat with no outstanding WR is
  `write_data_unexpected`. W lines must follow the WR line they belong to.
- **One command per pseudo-channel per cycle** is a preamble sentence, not a numbered rule; enforced as
  `cmd_bus_conflict` (both commands still take effect).
- **Refresh deadline instant.** "`now - last_refresh(b) <= bound` for every bank" is continuous in `now`.
  The model evaluates it (a) before each command, so a REF issued at `last + bound + 1` is itself a violation
  (strict reading: the bound was already exceeded before the REF took effect), and (b) at `finish(end_cycle)`.
  The violation cycle reported is the first violating cycle `last_refresh + bound + 1`. Power-down is NOT
  exempt; only self-refresh is. One `refresh_deadline` violation per detection lists all newly lapsed banks.
- **Refresh deadline needs the bank set and a time origin.** Banks that never see a command must still be
  refreshed, so the checker needs the geometry (default 4 x 4 from ADDRESS_MAP.md) and, for silent
  pseudo-channels, a `pcs=` list / `--num-pcs`. "Time zero counts as a refresh" is read as trace cycle 0
  (`time_zero=` overrides for traces starting later).
- **tFAW window.** "4th most recent ACT in the pseudo-channel" counts every ACT of the pc, including ones that
  themselves violated a rule.
- **Row/column ranges** are not validated (only `bg`/`ba` against the geometry, to index state).

## ADDRESS_MAP.md

- **`pcs` vs the literal 2 in the flat pseudo-channel index.** The formula is
  `((stack * NUM_CHANNELS) + ch) * 2 + pc`; `AddrMapCfg` has a `pcs` field. Implemented with `cfg.pcs`
  (identical for the documented `pcs = 2`; differs only for pcs = 1).
- **`il` in LINEAR mode.** `il` is defined as splitting the column, but LINEAR lists a contiguous `col(COL)`.
  `il` is ignored in LINEAR (it would not change the result). `il` outside 0..COL raises in the other modes.
- **Out-of-range / misaligned addresses in `map_addr`.** The doc classifies them separately (`check_addr`) and does
  not define the mapped fields. `map_addr` ignores `addr[OFF-1:0]` and truncates bits above the capacity.
- **Capacity vs `ADDR_W`.** Out of range means any bit at or above `2^cap_bits` is set (the doc); an address
  with bit >= ADDR_W is also treated as out of range (relevant only if cap_bits > ADDR_W).
- **Hash details.** `row[BG-1:0]` / `row[BG+BA-1:BG]` / `(row >> (BG+BA)) & (2^CH-1)`; `pc` and `stack` are not
  hashed; if ROW is narrower than BG+BA+CH the missing row bits read as 0. The hash is applied in every mode
  after extraction; `unmap_loc` takes the post-hash location.
- **Supported channel counts.** "1,2,4,8,32 supported in simulation" lists no 16; any power of two is accepted.

## RAS_CODE.md

- **Bit placement of the 10 check bits.** "check bit i" for i = 0..8 and "check bit 9" are assumed to be
  `ecc[i]`, i.e. `ecc[8:0]` = Hamming bits, `ecc[9]` = overall parity (matches the `ecc[9:0]` naming).
- **Data returned on `ue`.** The table says nothing; the model returns the data as read, uncorrected.
- **Odd-weight multi-bit errors (3+).** `syn != 0, op = 1` is treated as a single-bit error per the table;
  such errors may be mis-corrected, which is inherent and unspecified. A syndrome > 265 that is not a
  power of two is `ue` ("points past the code").
- **`syn` has 9 bits**, so the overall-parity bit does not contribute to it (needed for the `syn = 0, op = 1` row).

## ORDERING.md

- **Mask/data byte lanes.** `mask` is "1 per byte" and `data` a 256-bit value, but not which mask bit goes with
  which byte. Assumed bit `i` of the mask enables byte `i`, bits `[8i+7:8i]` of the data (byte 0 = LSB, as in
  RAS_CODE.md "bit 0 = least-significant bit of the granule").
- **Error precedence.** The table does not order simultaneous causes. Assumed MISALIGN / RANGE first (RANGE wins if
  both, as required for `check_addr`), then POLICY (partial write, mask != 0xffffffff, while ECC is enabled).
  BURST_BND / BURST_LEN / ECC / FLUSHED cannot be derived from a single-granule log and must be declared by the
  caller (`expected_errors`, `error_predicate`, `allowed_err_codes`).
- **Do error transactions appear as `req` records, and are they strictly checked?** "An error transaction ... does
  not modify memory". Assumed they are logged at acceptance like any other; a response error code must match the
  derived/declared set exactly (`expected_error_missing`, `unexpected_error`, `wrong_error_code`).
  FLUSHED writes: whether the write took effect is unspecified; the scoreboard applies a write unless the caller
  declares an error-only expectation (0 not in the allowed set).
- **Response matching.** Responses carry no address, so the scoreboard pairs a response with the oldest outstanding
  request of the same `{src,id}` and, to detect reordering, accepts a younger one only if the older does not match
  the response's kind / error / read data. Two same-id reads with IDENTICAL data cannot be told apart, so swapping
  them is undetectable (and unobservable).
- **Event order.** The log's file order is taken as the true event order for acceptance order and for response
  order; `t` is not used (time regressions are reported as warnings).
- **`must_stay_ordered`.** Rule 6 puts the ORD_SRC attribute on the transaction being ordered: only the newer
  transaction carrying ORD_SRC is ordered after older same-source ones; an older ORD_SRC does not constrain a
  younger relaxed transaction. ORD_STRICT on either side orders regardless of source. Same-{src,id} ordering is
  returned for any pair (the cross-pseudo-channel part is the top level's admission rule, not a queue rule).
  Fences (rule 7) are not queued; a `fence` flag makes the function return True.
- **Write-completion data field.** `data` of a write response is unspecified; it is not compared. Fence requests have
  no documented `req` log form and are not handled by the scoreboard.
- **Hex widths.** `data`/`mask` hex strings are parsed as integers of any width (no `0x` + 64 digit requirement).
