"""Command-trace checker CLI (format of docs/ORDERING.md, "Command trace").

    python3 -m hbm4.trace_check <trace_file> --profile N [--json OUT] [--end-cycle C]

Trace lines (blank lines and lines starting with '#' are ignored)::

    <cycle> <pc> <cmd> <bg> <ba> <row> <col>     command visible at the DRAM boundary
    W <cycle> <pc>                                write-data bus beat

Exit status: 0 clean, 1 violations found, 2 usage / parse error.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Iterator, Optional, Union

from . import STATUS_NOTE
from .timing import Profile, TimingChecker, load_profiles

Event = tuple  # ("cmd", cycle, pc, cmd, bg, ba, row, col) | ("W", cycle, pc)


class TraceParseError(ValueError):
    """A trace line that does not follow the documented format."""


def _int(tok: str, lineno: int) -> int:
    try:
        return int(tok, 0)
    except ValueError as exc:
        raise TraceParseError(f"line {lineno}: bad integer {tok!r}") from exc


def parse_trace(lines: Iterator[str]) -> Iterator[Event]:
    """Yield events from trace text lines (see module docstring)."""
    for lineno, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        tok = line.split()
        if tok[0] == "W":
            if len(tok) != 3:
                raise TraceParseError(f"line {lineno}: expected 'W cycle pc', got {line!r}")
            yield ("W", _int(tok[1], lineno), _int(tok[2], lineno))
        else:
            if len(tok) != 7:
                raise TraceParseError(
                    f"line {lineno}: expected 'cycle pc cmd bg ba row col' (7 fields), got {line!r}")
            vals = [_int(t, lineno) for t in tok]
            yield ("cmd", *vals)


def check_events(events: Iterator[Event], profile: Profile, end_cycle: Optional[int] = None,
                 **checker_kwargs) -> TimingChecker:
    """Run :class:`TimingChecker` over parsed events and call ``finish``."""
    chk = TimingChecker(profile, **checker_kwargs)
    for ev in events:
        if ev[0] == "W":
            chk.feed_wdata(ev[1], ev[2])
        else:
            _, cycle, pc, cmd, bg, ba, row, col = ev
            chk.feed(cycle, pc, cmd, bg, ba, row, col)
    chk.finish(end_cycle)
    return chk


def check_trace_file(
    path: Union[str, Path], profile: Profile, end_cycle: Optional[int] = None, **checker_kwargs,
) -> TimingChecker:
    """Parse ``path`` and check it against ``profile``; returns the finished checker."""
    with open(path, "r", encoding="utf-8") as fh:
        return check_events(parse_trace(fh), profile, end_cycle, **checker_kwargs)


def report_dict(chk: TimingChecker, trace: str = "") -> dict:
    """JSON-serialisable report (carries the profile status)."""
    p = chk.profile
    return {
        "trace": str(trace),
        "profile": {"id": p.id, "name": p.name, "status": p.status, "note": STATUS_NOTE},
        "commands": chk.n_commands,
        "wdata_beats": chk.n_wdata,
        "clean": chk.clean,
        "num_violations": len(chk.violations),
        "by_rule": chk.summary(),
        "violations": [v.to_dict() for v in chk.violations],
    }


def format_report(chk: TimingChecker, trace: str = "", max_listed: int = 20) -> str:
    out = [chk.header(), f"trace: {trace}  commands={chk.n_commands} wdata_beats={chk.n_wdata}"]
    if chk.clean:
        out.append("RESULT: CLEAN (0 violations)")
    else:
        out.append(f"RESULT: {len(chk.violations)} VIOLATION(S)")
        for rule, n in chk.summary().items():
            out.append(f"  {rule:<28} {n}")
        out.append("first violations:")
        for v in chk.violations[:max_listed]:
            out.append(f"  {v}")
        if len(chk.violations) > max_listed:
            out.append(f"  ... {len(chk.violations) - max_listed} more")
    return "\n".join(out)


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        prog="python3 -m hbm4.trace_check",
        description="Check a DRAM command trace against the HYPOTHETICAL_SIM timing rules "
                    "of docs/TIMING_RULES.md.",
    )
    ap.add_argument("trace_file")
    ap.add_argument("--profile", type=int, required=True, help="profile id in profiles.json")
    ap.add_argument("--json", metavar="OUT", help="write a JSON report to OUT")
    ap.add_argument("--end-cycle", type=int, default=None,
                    help="last cycle covered by the trace (default: last cycle seen)")
    ap.add_argument("--profiles-file", default=None, help="alternative profiles.json")
    ap.add_argument("--num-pcs", type=int, default=0,
                    help="pre-register pseudo-channels 0..N-1 (refresh deadline applies to "
                         "silent pseudo-channels too)")
    args = ap.parse_args(argv)

    try:
        profiles = load_profiles(args.profiles_file)
        if args.profile not in profiles:
            print(f"error: no profile {args.profile}; have {sorted(profiles)}", file=sys.stderr)
            return 2
        chk = check_trace_file(args.trace_file, profiles[args.profile], args.end_cycle,
                               pcs=range(args.num_pcs))
    except (OSError, TraceParseError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    print(format_report(chk, args.trace_file))
    if args.json:
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(report_dict(chk, args.trace_file), fh, indent=2)
            fh.write("\n")
    return 0 if chk.clean else 1


if __name__ == "__main__":
    sys.exit(main())
