"""Sparse reference memory and the controller-level SECDED code.

Memory: 32-byte granules (256 bits); byte ``i`` of a granule occupies data bits
``[8i+7:8i]`` and is enabled by mask bit ``i`` (see SPEC_AMBIGUITIES.md).

SECDED: docs/RAS_CODE.md, a (265, 256) Hamming code + overall parity = 10 check
bits (``ecc[8:0]`` Hamming, ``ecc[9]`` overall parity). ENGINEERING_ASSUMPTION.
"""

from __future__ import annotations

GRANULE_BYTES = 32
GRANULE_BITS = 256
FULL_DATA_MASK = (1 << GRANULE_BITS) - 1
FULL_BYTE_MASK = (1 << GRANULE_BYTES) - 1  # 0xffffffff


def _expand_byte_mask(mask: int) -> int:
    """32-bit byte-enable mask -> 256-bit bit mask."""
    out = 0
    for i in range(GRANULE_BYTES):
        if (mask >> i) & 1:
            out |= 0xFF << (8 * i)
    return out


class RefMemory:
    """Sparse, byte-accurate memory of 32-byte granules; unwritten bytes read 0."""

    def __init__(self) -> None:
        self._g: dict[int, int] = {}

    @staticmethod
    def granule_addr(addr: int) -> int:
        """Granule address of a byte address (offset bits are ignored)."""
        return addr >> 5

    def write(self, addr: int, data: int, mask: int = FULL_BYTE_MASK) -> None:
        """Masked write: only bytes whose mask bit is set change."""
        key = self.granule_addr(addr)
        bits = _expand_byte_mask(mask & FULL_BYTE_MASK)
        old = self._g.get(key, 0)
        new = (old & ~bits) | (data & bits & FULL_DATA_MASK)
        if new:
            self._g[key] = new
        else:
            self._g.pop(key, None)

    def read(self, addr: int) -> int:
        """The 256-bit granule containing ``addr`` (0 if never written)."""
        return self._g.get(self.granule_addr(addr), 0)

    def __len__(self) -> int:
        return len(self._g)


# ---------------------------------------------------------------------------
# SECDED (docs/RAS_CODE.md)
# ---------------------------------------------------------------------------

def _build_positions(n_data: int = GRANULE_BITS) -> list[int]:
    """pos(d): the positions 1, 2, 3, ... that are not powers of two, increasing."""
    pos: list[int] = []
    p = 0
    while len(pos) < n_data:
        p += 1
        if p & (p - 1):  # not a power of two
            pos.append(p)
    return pos


POS: list[int] = _build_positions()
_POS_TO_BIT: dict[int, int] = {p: d for d, p in enumerate(POS)}

#: for check bit i (0..8): mask of data bits d whose pos(d) has bit i set
_CHECK_MASKS: list[int] = [
    sum(1 << d for d, p in enumerate(POS) if (p >> i) & 1) for i in range(9)
]


def pos(d: int) -> int:
    """Hamming position of data bit ``d`` (RAS_CODE.md: pos(0)=3, pos(1)=5, pos(2)=6, ...)."""
    return POS[d]


def _parity(x: int) -> int:
    return x.bit_count() & 1


def secded_encode(data: int) -> int:
    """10 check bits for a 256-bit granule.

    check bit ``i`` (0..8) = XOR of data bits whose ``pos`` has bit ``i`` set;
    check bit 9 = XOR of all 256 data bits XOR check bits 0..8.
    """
    data &= FULL_DATA_MASK
    ecc = 0
    for i in range(9):
        ecc |= _parity(data & _CHECK_MASKS[i]) << i
    overall = _parity(data) ^ _parity(ecc)
    return ecc | (overall << 9)


def secded_decode(data: int, ecc: int) -> tuple[int, int, int, int]:
    """Decode ``(data, ecc)`` -> ``(data_out, ce, ue, syndrome)``.

    ``syn[8:0] = recomputed_check[8:0] ^ stored_check[8:0]`` and
    ``op = XOR(all data bits) ^ XOR(all 10 stored check bits)``. Result table
    (RAS_CODE.md "Decoding"); on ``ue`` the data is returned as read.
    """
    data &= FULL_DATA_MASK
    ecc &= 0x3FF
    syn = (secded_encode(data) & 0x1FF) ^ (ecc & 0x1FF)
    op = _parity(data) ^ _parity(ecc)
    if syn == 0 and op == 0:
        return data, 0, 0, syn  # clean
    if syn != 0 and op == 1:  # single-bit error
        if syn & (syn - 1) == 0:  # power of two: a check bit flipped, data fine
            return data, 1, 0, syn
        d = _POS_TO_BIT.get(syn)
        if d is not None:
            return data ^ (1 << d), 1, 0, syn
        return data, 0, 1, syn  # points past the code
    if syn == 0 and op == 1:  # overall-parity bit flipped
        return data, 1, 0, syn
    return data, 0, 1, syn  # syn != 0, op == 0: double-bit error
