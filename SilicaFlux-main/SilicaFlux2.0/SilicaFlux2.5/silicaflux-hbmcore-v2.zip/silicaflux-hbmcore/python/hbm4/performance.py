"""Bandwidth / latency arithmetic helpers.

All bandwidths are DECIMAL: 1 GB = 1e9 bytes, 1 TB = 1e12 bytes.
"""

from __future__ import annotations

import math
from fractions import Fraction
from typing import Iterable, Sequence


def percentile(xs: Iterable[float], p: float) -> float:
    """Nearest-rank percentile.

    Sort ``xs`` ascending (n values); the p-th percentile is the value at rank
    ``ceil(p/100 * n)`` (1-based), with the rank clamped to ``[1, n]`` so that
    ``p = 0`` returns the minimum and ``p = 100`` the maximum. No interpolation:
    the result is always one of the input values. Empty input raises ValueError.
    """
    data = sorted(xs)
    if not data:
        raise ValueError("percentile of an empty sequence")
    if not 0 <= p <= 100:
        raise ValueError(f"percentile p={p} outside [0, 100]")
    # exact decimal arithmetic: float 0.7 * 10 would give 7.000000000000001 -> rank 8
    rank = max(1, min(len(data), math.ceil(Fraction(str(p)) * len(data) / 100)))
    return data[rank - 1]


def bandwidth_gb_s(bytes_: float, cycles: float, clock_mhz: float) -> float:
    """Decimal GB/s for ``bytes_`` moved in ``cycles`` of a ``clock_mhz`` clock.

    seconds = cycles / (clock_mhz * 1e6);  GB/s = bytes / seconds / 1e9.
    """
    if cycles <= 0:
        raise ValueError("cycles must be > 0")
    if clock_mhz <= 0:
        raise ValueError("clock_mhz must be > 0")
    seconds = cycles / (clock_mhz * 1e6)
    return bytes_ / seconds / 1e9


def pin_bandwidth_gb_s(pins: float, gbps_per_pin: float) -> float:
    """Pin-rate bandwidth in decimal GB/s: ``pins * gbps_per_pin / 8``."""
    return pins * gbps_per_pin / 8.0


def efficiency(measured: float, theoretical: float) -> float:
    """``measured / theoretical`` (a ratio, 1.0 == 100 %)."""
    if theoretical <= 0:
        raise ValueError("theoretical must be > 0")
    return measured / theoretical


def summarize(latencies: Sequence[float]) -> dict[str, float]:
    """count / mean / p50 / p95 / p99 / max of a latency list (nearest-rank).

    An empty list yields ``count == 0`` and zeros for every other field.
    """
    xs = list(latencies)
    if not xs:
        return {"count": 0, "mean": 0.0, "p50": 0.0, "p95": 0.0, "p99": 0.0, "max": 0.0}
    return {
        "count": len(xs),
        "mean": sum(xs) / len(xs),
        "p50": percentile(xs, 50),
        "p95": percentile(xs, 95),
        "p99": percentile(xs, 99),
        "max": max(xs),
    }
