"""Bank / pseudo-channel state tracking (docs/TIMING_RULES.md).

One :class:`PcState` per pseudo-channel -- pseudo-channels are completely
independent (TIMING_RULES.md preamble). ``None`` means "never seen", which
satisfies every ``now - last_X >= N`` rule.

This module holds state and mutators only; the legality rules live in
``timing.py``.
"""

from __future__ import annotations

import enum
from collections import deque
from dataclasses import dataclass, field
from typing import Optional


class PowerState(enum.Enum):
    """Low-power state of a pseudo-channel (TIMING_RULES.md, PDE / SRE)."""

    ACTIVE = "active"
    POWER_DOWN = "power_down"
    SELF_REFRESH = "self_refresh"


@dataclass
class BankState:
    """State of one bank = (bank group, bank)."""

    open_row: Optional[int] = None
    last_act: Optional[int] = None
    last_pre: Optional[int] = None
    last_rd: Optional[int] = None
    last_wr: Optional[int] = None
    #: per-bank refresh: ACT / REF_PB legal again at ``now >= bank_ref_until``
    bank_ref_until: int = 0
    #: "Time zero counts as a refresh" (TIMING_RULES.md, refresh deadline)
    last_refresh: int = 0
    #: refresh-deadline lapse already reported for this bank (reset on refresh)
    lapse_flagged: bool = False

    @property
    def is_open(self) -> bool:
        return self.open_row is not None


@dataclass(frozen=True)
class PendingWrite:
    """A WR whose write-data beat is still expected exactly at ``expected``."""

    issue: int
    expected: int  # = issue + wl


@dataclass
class PcState:
    """Complete tracked state of one pseudo-channel."""

    num_bg: int = 4
    num_ba: int = 4
    time_zero: int = 0
    banks: dict[tuple[int, int], BankState] = field(default_factory=dict)
    #: all-bank refresh: ACT / REF_AB / MRS / PDE / SRE legal at ``now >= ref_busy_until``
    ref_busy_until: int = 0
    #: the (up to) four most recent ACT cycles in the pseudo-channel (tFAW)
    faw: deque[int] = field(default_factory=lambda: deque(maxlen=4))
    last_act_group: dict[int, int] = field(default_factory=dict)
    last_col_group: dict[int, int] = field(default_factory=dict)  # RD *or* WR
    last_wr_group: dict[int, int] = field(default_factory=dict)
    last_rd_any: Optional[int] = None
    last_mrs: Optional[int] = None
    last_exit: Optional[int] = None
    last_exit_kind: Optional[PowerState] = None  # POWER_DOWN (PDX) or SELF_REFRESH (SRX)
    power: PowerState = PowerState.ACTIVE
    last_cmd_cycle: Optional[int] = None
    pending_writes: list[PendingWrite] = field(default_factory=list)

    def __post_init__(self) -> None:
        for bg in range(self.num_bg):
            for ba in range(self.num_ba):
                self.banks[(bg, ba)] = BankState(last_refresh=self.time_zero)

    # -- lookup -----------------------------------------------------------
    def bank(self, bg: int, ba: int) -> BankState:
        return self.banks[(bg, ba)]

    def open_banks(self) -> list[tuple[int, int]]:
        return sorted(k for k, b in self.banks.items() if b.is_open)

    # -- mutators (effects stated in TIMING_RULES.md) ----------------------
    def on_act(self, now: int, bg: int, ba: int, row: int) -> None:
        b = self.bank(bg, ba)
        b.open_row = row
        b.last_act = now
        self.last_act_group[bg] = now
        self.faw.append(now)

    def on_rd(self, now: int, bg: int, ba: int) -> None:
        self.bank(bg, ba).last_rd = now
        self.last_rd_any = now
        self.last_col_group[bg] = now

    def on_wr(self, now: int, bg: int, ba: int) -> None:
        self.bank(bg, ba).last_wr = now
        self.last_wr_group[bg] = now
        self.last_col_group[bg] = now

    def on_pre(self, now: int, bg: int, ba: int, noop_updates_last_pre: bool = False) -> None:
        """PRE of one bank. A PRE to a closed bank is a no-op (see SPEC_AMBIGUITIES.md)."""
        b = self.bank(bg, ba)
        if b.is_open or noop_updates_last_pre:
            b.last_pre = now
        b.open_row = None

    def on_prea(self, now: int, noop_updates_last_pre: bool = False) -> None:
        for (bg, ba) in sorted(self.banks):
            self.on_pre(now, bg, ba, noop_updates_last_pre)

    def _refreshed(self, b: BankState, now: int) -> None:
        b.last_refresh = now
        b.lapse_flagged = False

    def on_ref_ab(self, now: int, trfc: int) -> None:
        self.ref_busy_until = now + trfc
        for b in self.banks.values():
            self._refreshed(b, now)

    def on_ref_pb(self, now: int, bg: int, ba: int, trfcpb: int) -> None:
        b = self.bank(bg, ba)
        b.bank_ref_until = now + trfcpb
        self._refreshed(b, now)

    def on_mrs(self, now: int) -> None:
        self.last_mrs = now

    def on_pde(self, now: int) -> None:
        self.power = PowerState.POWER_DOWN

    def on_sre(self, now: int) -> None:
        self.power = PowerState.SELF_REFRESH

    def on_pdx(self, now: int) -> None:
        self.power = PowerState.ACTIVE
        self.last_exit = now
        self.last_exit_kind = PowerState.POWER_DOWN

    def on_srx(self, now: int) -> None:
        """SRX: exit self-refresh; resets ``last_refresh(b) = now`` for all banks."""
        self.power = PowerState.ACTIVE
        self.last_exit = now
        self.last_exit_kind = PowerState.SELF_REFRESH
        for b in self.banks.values():
            self._refreshed(b, now)
