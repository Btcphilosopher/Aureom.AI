"""Transaction-level, one-pseudo-channel, cycle-by-cycle scheduler model.

A PERFORMANCE sanity reference, not a cycle-accurate twin of any RTL. Legality of
every issued command is decided by the same oracle as the trace checker
(:func:`hbm4.timing.check_command` over :class:`hbm4.bank_state.PcState`), so the
emitted trace is violation-free by construction; the tests re-validate it with
:class:`hbm4.timing.TimingChecker`.

Everything is HYPOTHETICAL_SIM (``SimResult.status``): results say nothing about
HBM4 or silicon.

Model summary
-------------
* Requests are ``(arrival_cycle, is_write, bg, ba, row, col)``; each is one
  32-byte granule. They enter a queue of ``queue_depth`` entries in
  ``(arrival, input order)`` order; one command is issued per cycle.
* ``fcfs``: strictly the oldest request; it issues its commands in order
  (PRE if another row is open, ACT if closed, then RD/WR).
* ``frfcfs``: among legal commands prefer column commands (row hits), then the
  oldest request; never PRECHARGE a bank that still has a queued request for
  its open row. Acceptance order is kept for same-granule hazards (a write
  involved) and for the same bank + same row.
* ``page='open'`` leaves rows open until a conflict or refresh; ``'close'``
  precharges a bank as soon as legal after a column command (``frfcfs``: not
  while queued hits to its open row remain).
* All-bank refresh: one is owed every ``trefi`` cycles (``cycle // trefi - done``).
  It starts when owed and the queue is idle, or when more than ``max_postpone``
  are owed; then no new ACT / column command issues, banks are precharged
  (PREA when legal, else PREs) and REF_AB is issued when legal. ``max_pullin``
  is not modelled.
* Latency (per request, input order) = data cycle - arrival, where the data
  cycle is ``issue + rl`` for RD and ``issue + wl`` for WR (TIMING_RULES.md data
  timing; one write-data beat per WR).
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from typing import Iterable, Optional, Sequence

from .bank_state import PcState
from .commands import ACT, PRE, PREA, RD, REF_AB, WR
from .performance import bandwidth_gb_s, efficiency, summarize
from .timing import Profile, TimingChecker, apply_command, check_command

GRANULE_BYTES = 32

Request = tuple[int, bool, int, int, int, int]  # arrival, is_write, bg, ba, row, col


class _Req:
    __slots__ = ("idx", "arrival", "write", "bg", "ba", "row", "col", "first", "issued")

    def __init__(self, idx: int, arrival: int, write: bool, bg: int, ba: int, row: int, col: int):
        self.idx, self.arrival, self.write = idx, arrival, bool(write)
        self.bg, self.ba, self.row, self.col = bg, ba, row, col
        self.first: Optional[str] = None  # 'empty' | 'conflict' | None (== hit)
        self.issued: Optional[int] = None


def _ordered_after(older: _Req, younger: _Req) -> bool:
    """Acceptance order must be kept: same granule with a write involved, or same bank + row."""
    same_bank_row = (older.bg, older.ba, older.row) == (younger.bg, younger.ba, younger.row)
    same_granule = same_bank_row and older.col == younger.col
    return (same_granule and (older.write or younger.write)) or same_bank_row


@dataclass
class SimResult:
    """Outcome of :func:`simulate` (everything HYPOTHETICAL_SIM)."""

    profile: Profile
    policy: str
    page: str
    refresh: bool
    commands: list[tuple[int, int, int, int, int, int, int]] = field(default_factory=list)
    wdata: list[tuple[int, int]] = field(default_factory=list)
    latencies: list[int] = field(default_factory=list)
    issue_cycles: list[int] = field(default_factory=list)
    row_hits: int = 0
    row_empty: int = 0
    row_conflicts: int = 0
    first_arrival: int = 0
    end_cycle: int = 0  # last cycle with a command or data beat
    total_cycles: int = 0  # end_cycle + 1 - first_arrival
    bytes_moved: int = 0

    # -- counts ----------------------------------------------------------------
    def _count(self, cmd: int) -> int:
        return sum(1 for c in self.commands if c[2] == cmd)

    @property
    def activates(self) -> int:
        return self._count(ACT)

    @property
    def precharges(self) -> int:
        """PRE commands plus PREA commands issued."""
        return self._count(PRE) + self._count(PREA)

    @property
    def refreshes(self) -> int:
        return self._count(REF_AB)

    def command_counts(self) -> dict[int, int]:
        return dict(sorted(Counter(c[2] for c in self.commands).items()))

    # -- row-hit accounting (TIMING_RULES.md) -----------------------------------
    @property
    def row_hit_rate(self) -> float:
        total = self.row_hits + self.row_empty + self.row_conflicts
        return self.row_hits / total if total else 0.0

    # -- bandwidth ---------------------------------------------------------------
    @property
    def status(self) -> str:
        return self.profile.status

    @property
    def bandwidth_gb_s(self) -> float:
        """Achieved decimal GB/s over ``total_cycles`` at the profile clock."""
        if self.total_cycles <= 0:
            return 0.0
        return bandwidth_gb_s(self.bytes_moved, self.total_cycles, self.profile.clock_mhz)

    @property
    def peak_bandwidth_gb_s(self) -> float:
        """One granule per ``burst`` cycles on one pseudo-channel."""
        return bandwidth_gb_s(GRANULE_BYTES, self.profile.burst, self.profile.clock_mhz)

    @property
    def efficiency(self) -> float:
        return efficiency(self.bandwidth_gb_s, self.peak_bandwidth_gb_s)

    def latency_summary(self) -> dict[str, float]:
        return summarize(self.latencies)

    # -- trace -----------------------------------------------------------------
    def trace_lines(self) -> list[str]:
        """The issued trace in ``trace_check`` format, ordered by cycle (W after commands)."""
        ev: list[tuple[int, int, int, str]] = []
        for i, (c, pc, cmd, bg, ba, row, col) in enumerate(self.commands):
            ev.append((c, 0, i, f"{c} {pc} {cmd} {bg} {ba} {row} {col}"))
        for i, (c, pc) in enumerate(self.wdata):
            ev.append((c, 1, i, f"W {c} {pc}"))
        ev.sort()
        return [e[3] for e in ev]

    def check(self, **checker_kwargs) -> TimingChecker:
        """Validate the trace with a fresh :class:`TimingChecker` (``finish`` at ``end_cycle``)."""
        chk = TimingChecker(self.profile, **checker_kwargs)
        for line in self.trace_lines():
            tok = line.split()
            if tok[0] == "W":
                chk.feed_wdata(int(tok[1]), int(tok[2]))
            else:
                chk.feed(*(int(t) for t in tok))
        chk.finish(self.end_cycle)
        return chk

    def summary(self) -> dict:
        return {
            "status": self.status,
            "profile": self.profile.name,
            "policy": self.policy,
            "page": self.page,
            "refresh": self.refresh,
            "requests": len(self.latencies),
            "total_cycles": self.total_cycles,
            "bytes_moved": self.bytes_moved,
            "bandwidth_gb_s": self.bandwidth_gb_s,
            "peak_bandwidth_gb_s": self.peak_bandwidth_gb_s,
            "efficiency": self.efficiency,
            "row_hit_rate": self.row_hit_rate,
            "row_hits": self.row_hits,
            "row_empty": self.row_empty,
            "row_conflicts": self.row_conflicts,
            "activates": self.activates,
            "precharges": self.precharges,
            "refreshes": self.refreshes,
            "latency": self.latency_summary(),
        }


def simulate(
    requests: Iterable[Request],
    profile: Profile,
    policy: str = "fcfs",
    queue_depth: int = 16,
    page: str = "open",
    refresh: bool = True,
    num_bg: Optional[int] = None,
    num_ba: Optional[int] = None,
) -> SimResult:
    """Run the model; see the module docstring for the policy definitions."""
    if policy not in ("fcfs", "frfcfs"):
        raise ValueError(f"policy must be 'fcfs' or 'frfcfs', got {policy!r}")
    if page not in ("open", "close"):
        raise ValueError(f"page must be 'open' or 'close', got {page!r}")
    if queue_depth < 1:
        raise ValueError("queue_depth must be >= 1")
    p = profile
    reqs = [_Req(i, *r) for i, r in enumerate(requests)]
    n = len(reqs)
    res = SimResult(profile=p, policy=policy, page=page, refresh=refresh)
    if n == 0:
        return res

    nbg = num_bg if num_bg is not None else max(4, max(r.bg for r in reqs) + 1)
    nba = num_ba if num_ba is not None else max(4, max(r.ba for r in reqs) + 1)
    st = PcState(nbg, nba)

    arrivals = sorted(range(n), key=lambda i: (reqs[i].arrival, i))
    nxt = 0
    queue: list[_Req] = []
    n_ref = 0
    ref_mode = False
    closing: set[tuple[int, int]] = set()
    cycle = 0
    res.first_arrival = min(r.arrival for r in reqs)
    last_arrival = max(r.arrival for r in reqs)
    cycle_limit = last_arrival + (n + 4) * 8 * (p.trc + p.trfc + p.WR2PRE + p.tfaw + p.trp + 64)
    data_end = 0

    def legal(cmd: int, bg: int = 0, ba: int = 0, row: int = 0) -> bool:
        return not check_command(st, p, cycle, cmd, bg, ba, row)

    def issue(cmd: int, bg: int = 0, ba: int = 0, row: int = 0, col: int = 0) -> None:
        res.commands.append((cycle, 0, cmd, bg, ba, row, col))
        apply_command(st, p, cycle, cmd, bg, ba, row)
        st.pending_writes.clear()  # write-data beats are emitted explicitly below
        st.last_cmd_cycle = cycle

    def pick_fcfs() -> Optional[tuple[int, _Req]]:
        r = queue[0]
        b = st.bank(r.bg, r.ba)
        if b.open_row == r.row:
            cmd = WR if r.write else RD
        elif b.open_row is None:
            cmd = ACT
        else:
            cmd = PRE
        return (cmd, r) if legal(cmd, r.bg, r.ba, r.row) else None

    def pick_frfcfs() -> Optional[tuple[int, _Req]]:
        cache: dict[tuple[int, int, int, int], bool] = {}

        def cached(cmd: int, bg: int, ba: int, row: int) -> bool:
            k = (cmd, bg, ba, row)
            if k not in cache:
                cache[k] = legal(cmd, bg, ba, row)
            return cache[k]

        rowcmd: Optional[tuple[int, _Req]] = None
        for i, r in enumerate(queue):
            b = st.bank(r.bg, r.ba)
            if b.open_row == r.row:  # row hit -> column command candidate
                if any(_ordered_after(queue[j], r) for j in range(i)):
                    continue
                cmd = WR if r.write else RD
                if cached(cmd, r.bg, r.ba, r.row):
                    return cmd, r  # first legal column command, oldest first
            elif rowcmd is None:
                if b.open_row is None:
                    cmd = ACT
                elif any(q.bg == r.bg and q.ba == r.ba and q.row == b.open_row for q in queue):
                    continue  # never precharge a bank with pending queued hits
                else:
                    cmd = PRE
                if cached(cmd, r.bg, r.ba, r.row):
                    rowcmd = (cmd, r)
        return rowcmd

    def refresh_step() -> bool:
        """One cycle of an in-progress all-bank refresh; True if a command was issued."""
        nonlocal n_ref, ref_mode
        opened = st.open_banks()
        if opened:
            if legal(PREA):
                issue(PREA)
                closing.clear()
                return True
            for (bg, ba) in opened:
                if legal(PRE, bg, ba):
                    issue(PRE, bg, ba)
                    closing.discard((bg, ba))
                    return True
            return False
        if legal(REF_AB):
            issue(REF_AB)
            n_ref += 1
            ref_mode = False
            return True
        return False

    while True:
        while nxt < n and reqs[arrivals[nxt]].arrival <= cycle and len(queue) < queue_depth:
            queue.append(reqs[arrivals[nxt]])
            nxt += 1
        if not queue and nxt >= n:
            break
        if cycle > cycle_limit:
            raise RuntimeError(f"scheduler made no progress by cycle {cycle} (queue={len(queue)})")

        owed = (cycle // p.trefi - n_ref) if refresh else 0
        if refresh and not ref_mode and owed >= 1 and (not queue or owed > p.max_postpone):
            ref_mode = True

        issued = False
        if ref_mode:
            issued = refresh_step()
        else:
            choice = (pick_fcfs() if policy == "fcfs" else pick_frfcfs()) if queue else None
            if choice is not None:
                cmd, r = choice
                if cmd == ACT:
                    if r.first is None:
                        r.first = "empty"
                    issue(ACT, r.bg, r.ba, r.row)
                    closing.discard((r.bg, r.ba))
                elif cmd == PRE:
                    if r.first is None:
                        r.first = "conflict"
                    issue(PRE, r.bg, r.ba)
                    closing.discard((r.bg, r.ba))
                else:
                    issue(cmd, r.bg, r.ba, r.row, r.col)
                    queue.remove(r)
                    r.issued = cycle
                    if r.first == "empty":
                        res.row_empty += 1
                    elif r.first == "conflict":
                        res.row_conflicts += 1
                    else:
                        res.row_hits += 1
                    data_cycle = cycle + (p.wl if r.write else p.rl)
                    if r.write:
                        res.wdata.append((data_cycle, 0))
                    data_end = max(data_end, data_cycle)
                    if page == "close":
                        closing.add((r.bg, r.ba))
                issued = True
            elif page == "close":
                # closed-page: background precharge of banks whose row was just used
                for key in sorted(closing):
                    b = st.banks[key]
                    if not b.is_open:
                        closing.discard(key)
                        continue
                    if policy == "frfcfs" and any(
                        q.bg == key[0] and q.ba == key[1] and q.row == b.open_row for q in queue
                    ):
                        continue
                    if legal(PRE, key[0], key[1]):
                        issue(PRE, key[0], key[1])
                        closing.discard(key)
                        issued = True
                        break

        if issued:
            cycle += 1
        elif not queue and not ref_mode and not closing and (not refresh or owed < 1):
            # idle: jump to the next arrival or the next refresh-owed instant
            target = reqs[arrivals[nxt]].arrival if nxt < n else cycle + 1
            if refresh:
                target = min(target, (n_ref + 1) * p.trefi)
            cycle = max(cycle + 1, target)
        else:
            cycle += 1

    # -- finalise ------------------------------------------------------------------
    res.latencies = [0] * n
    res.issue_cycles = [0] * n
    for r in reqs:
        assert r.issued is not None
        data_cycle = r.issued + (p.wl if r.write else p.rl)
        res.latencies[r.idx] = data_cycle - r.arrival
        res.issue_cycles[r.idx] = r.issued
    last_cmd = res.commands[-1][0] if res.commands else 0
    res.end_cycle = max(data_end, last_cmd)
    res.total_cycles = res.end_cycle + 1 - res.first_arrival
    res.bytes_moved = GRANULE_BYTES * n
    return res
