"""Transactions, ordering attributes, error codes and the ordering rules.

Derived ONLY from docs/ORDERING.md ("Guarantees", "Error responses").
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

# -- ordering attributes (ORDERING.md rule 6) ---------------------------------
ORD_RELAXED = 0
ORD_SRC = 1
ORD_STRICT = 2

# -- error codes (ORDERING.md, "Error responses") ---------------------------
ERR_NONE = 0
ERR_MISALIGN = 1
ERR_RANGE = 2
ERR_POLICY = 3  # POLICY (DOMAIN): partial write while controller ECC is enabled
ERR_BURST_BND = 4
ERR_BURST_LEN = 5
ERR_ECC = 6
ERR_FLUSHED = 7

ERR_NAMES = {
    ERR_NONE: "NONE", ERR_MISALIGN: "MISALIGN", ERR_RANGE: "RANGE", ERR_POLICY: "POLICY",
    ERR_BURST_BND: "BURST_BND", ERR_BURST_LEN: "BURST_LEN", ERR_ECC: "ECC", ERR_FLUSHED: "FLUSHED",
}

GRANULE_SHIFT = 5  # 32-byte granule
FULL_MASK = 0xFFFFFFFF


def _to_int(v: Any) -> int:
    """JSON-lines value ('0x..' hex string, hex string, or int) -> int."""
    if isinstance(v, str):
        return int(v, 16)
    return int(v)


@dataclass
class Txn:
    """A single-granule transaction at acceptance (``req_valid && req_ready``)."""

    src: int
    id: int
    write: bool
    addr: int
    mask: int = FULL_MASK
    data: int = 0
    ord: int = ORD_RELAXED
    t: int = 0
    fence: bool = False

    @property
    def granule(self) -> int:
        return self.addr >> GRANULE_SHIFT

    @classmethod
    def from_record(cls, rec: Mapping[str, Any]) -> "Txn":
        """Build from a ``{"ev":"req",...}`` JSON-lines record."""
        return cls(
            src=int(rec["src"]), id=int(rec["id"]), write=bool(int(rec["w"])),
            addr=_to_int(rec["addr"]), mask=_to_int(rec.get("mask", FULL_MASK)),
            data=_to_int(rec.get("data", 0)), ord=int(rec.get("ord", ORD_RELAXED)),
            t=int(rec.get("t", 0)),
        )

    def to_record(self) -> dict[str, Any]:
        return {
            "ev": "req", "t": self.t, "src": self.src, "id": self.id, "w": int(self.write),
            "addr": f"0x{self.addr:x}", "mask": f"0x{self.mask:08x}", "data": f"0x{self.data:064x}",
        }


@dataclass
class Rsp:
    """A response at hand-shake."""

    src: int
    id: int
    write: bool
    err: int = ERR_NONE
    data: int = 0
    t: int = 0
    extra: dict = field(default_factory=dict, repr=False)

    @classmethod
    def from_record(cls, rec: Mapping[str, Any]) -> "Rsp":
        """Build from a ``{"ev":"rsp",...}`` JSON-lines record."""
        return cls(
            src=int(rec["src"]), id=int(rec["id"]), write=bool(int(rec["w"])),
            err=int(rec.get("err", 0)), data=_to_int(rec.get("data", 0)), t=int(rec.get("t", 0)),
        )

    def to_record(self) -> dict[str, Any]:
        return {
            "ev": "rsp", "t": self.t, "src": self.src, "id": self.id, "w": int(self.write),
            "err": self.err, "data": f"0x{self.data:064x}",
        }


def same_granule(a: Txn, b: Txn) -> bool:
    """Same 32-byte granule (ORDERING.md rule 4)."""
    return a.granule == b.granule


def must_stay_ordered(newer: Txn, older: Txn) -> bool:
    """True if ``newer`` must not take effect / complete before ``older``.

    Both transactions target the same pseudo-channel queue (the caller checks
    that). Rules, all from ORDERING.md "Guarantees":

    * rule 4: same 32-byte granule and at least one is a write;
    * rule 3: same ``{src, id}``;
    * rule 6 ORD_SRC: ``newer`` carries ORD_SRC and has the same source as ``older``
      (only the transaction carrying the attribute is ordered after its
      predecessors; an older ORD_SRC does not constrain a younger relaxed one);
    * rule 6 ORD_STRICT: either side is a barrier (regardless of source);
    * rule 7 (fence): either side is a fence (extra; fences are not queued, so this
      is trivially satisfied by the controller).

    Everything else (different granules, two reads of one granule, ...) is
    unordered (rules 4/5).
    """
    if newer.fence or older.fence:
        return True
    if same_granule(newer, older) and (newer.write or older.write):
        return True
    if newer.src == older.src and newer.id == older.id:
        return True
    if newer.ord == ORD_SRC and newer.src == older.src:
        return True
    if newer.ord == ORD_STRICT or older.ord == ORD_STRICT:
        return True
    return False
