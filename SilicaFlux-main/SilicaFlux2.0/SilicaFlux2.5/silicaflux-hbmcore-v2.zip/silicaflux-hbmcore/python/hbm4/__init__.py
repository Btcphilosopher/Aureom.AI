"""Independent Python reference model for SILICAFLUX HBMCORE.

Derived ONLY from docs/TIMING_RULES.md, docs/ADDRESS_MAP.md, docs/RAS_CODE.md,
docs/ORDERING.md and configs/timing/profiles.json -- never from the RTL.

Every timing profile is HYPOTHETICAL_SIM: nothing here is JEDEC / HBM4 compliant
and no result may be described as such.
"""

STATUS_NOTE = (
    "HYPOTHETICAL_SIM: abstract controller/DRAM contract; numbers are NOT taken "
    "from JESD270-4, a vendor datasheet or a PHY spec. Not HBM4-compliant."
)

__all__ = ["STATUS_NOTE"]
