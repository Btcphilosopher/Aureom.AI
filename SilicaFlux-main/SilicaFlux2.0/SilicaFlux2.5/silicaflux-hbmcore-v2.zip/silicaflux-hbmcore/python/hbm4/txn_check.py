"""Transaction-log checker CLI.

    python3 -m hbm4.txn_check <log.jsonl> [--json OUT] [--ecc] [--num-channels N]
                              [--num-stacks N] [--allow-err CODE ...]

Exit status: 0 pass, 1 any check failed, 2 usage / parse error.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Optional

from . import STATUS_NOTE
from .address_map import AddrMapCfg
from .scoreboard import check_transactions, load_jsonl


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(
        prog="python3 -m hbm4.txn_check",
        description="Check a docs/ORDERING.md JSON-lines transaction log "
                    "(one response per request, ownership, same-id order, read data vs reference).",
    )
    ap.add_argument("log")
    ap.add_argument("--json", metavar="OUT", help="write a JSON report to OUT")
    ap.add_argument("--ecc", action="store_true",
                    help="controller ECC enabled: partial writes must answer POLICY (3)")
    ap.add_argument("--num-channels", type=int, default=32)
    ap.add_argument("--num-stacks", type=int, default=1)
    ap.add_argument("--allow-err", type=int, action="append", default=[],
                    metavar="CODE", help="tolerate this error code on any response (repeatable)")
    args = ap.parse_args(argv)

    try:
        records = load_jsonl(args.log)
        cfg = AddrMapCfg(num_channels=args.num_channels, num_stacks=args.num_stacks)
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    rep = check_transactions(records, cfg=cfg, ecc_enabled=args.ecc, allowed_err_codes=args.allow_err)
    print(f"({STATUS_NOTE})")
    print(rep.format())
    if args.json:
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(rep.to_dict(), fh, indent=2)
            fh.write("\n")
    return 0 if rep.ok else 1


if __name__ == "__main__":
    sys.exit(main())
