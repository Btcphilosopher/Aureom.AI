"""Command codes of the command-trace format (docs/ORDERING.md, "Command trace")."""

from __future__ import annotations

ACT = 1
RD = 2
WR = 3
PRE = 4
PREA = 5
REF_AB = 6
REF_PB = 7
MRS = 8
PDE = 9
PDX = 10
SRE = 11
SRX = 12
RFM = 13

CMD_NAMES: dict[int, str] = {
    ACT: "ACT",
    RD: "RD",
    WR: "WR",
    PRE: "PRE",
    PREA: "PREA",
    REF_AB: "REF_AB",
    REF_PB: "REF_PB",
    MRS: "MRS",
    PDE: "PDE",
    PDX: "PDX",
    SRE: "SRE",
    SRX: "SRX",
    RFM: "RFM",
}

#: commands that address one bank (bg, ba); the others ignore bg/ba.
BANK_ADDRESSED = frozenset({ACT, RD, WR, PRE, REF_PB})


def cmd_name(cmd: int | None) -> str:
    """Readable mnemonic for a command code (``'-'`` for ``None``)."""
    if cmd is None:
        return "-"
    return CMD_NAMES.get(cmd, f"CMD{cmd}")
