"""Timing profiles and the timing-rule checker, derived ONLY from
docs/TIMING_RULES.md and configs/timing/profiles.json.

EVERY profile is HYPOTHETICAL_SIM: it is neither JEDEC- nor HBM4-compliant, and
this module never claims otherwise (``Profile.status`` is carried into every
report).

Only rules stated in TIMING_RULES.md are enforced. Extra, clearly named
trace-hygiene findings (``cmd_bus_conflict``, ``trace_not_chronological``,
``bank_out_of_range``, ``unknown_command``) are reported separately and are not
DRAM rules.
"""

from __future__ import annotations

import json
from collections import Counter
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Optional

from . import STATUS_NOTE
from .bank_state import PcState, PendingWrite, PowerState
from .commands import (
    ACT, BANK_ADDRESSED, CMD_NAMES, MRS, PDE, PDX, PRE, PREA, RD, REF_AB, REF_PB,
    RFM, SRE, SRX, WR, cmd_name,
)

PROFILE_INT_FIELDS = (
    "clock_mhz",
    "trcdrd", "trcdwr", "trp", "tras", "trc", "tccd_s", "tccd_l", "trrd_s", "trrd_l",
    "tfaw", "twr", "twtr_s", "twtr_l", "trtp", "trfc", "trfcpb", "trefi",
    "rl", "wl", "burst", "tmrd", "txp", "txs", "max_postpone", "max_pullin", "trfm",
)


class ProfileError(ValueError):
    """Malformed profiles.json."""


@dataclass(frozen=True)
class Profile:
    """One timing profile (TIMING_RULES.md, "Profile fields") plus derived values."""

    id: int
    name: str
    status: str
    source: str
    clock_mhz: int
    trcdrd: int
    trcdwr: int
    trp: int
    tras: int
    trc: int
    tccd_s: int
    tccd_l: int
    trrd_s: int
    trrd_l: int
    tfaw: int
    twr: int
    twtr_s: int
    twtr_l: int
    trtp: int
    trfc: int
    trfcpb: int
    trefi: int
    rl: int
    wl: int
    burst: int
    tmrd: int
    txp: int
    txs: int
    max_postpone: int
    max_pullin: int
    trfm: int = 0          # v2: refresh-management busy time (HYPOTHETICAL); default keeps old JSON loadable

    # -- derived (TIMING_RULES.md, "Derived") --------------------------------
    @property
    def RTW(self) -> int:
        """max(1, rl + burst + 2 - wl)"""
        return max(1, self.rl + self.burst + 2 - self.wl)

    @property
    def WTR_S(self) -> int:
        """wl + burst + twtr_s"""
        return self.wl + self.burst + self.twtr_s

    @property
    def WTR_L(self) -> int:
        """wl + burst + twtr_l"""
        return self.wl + self.burst + self.twtr_l

    @property
    def WR2PRE(self) -> int:
        """wl + burst + twr"""
        return self.wl + self.burst + self.twr

    @property
    def refresh_deadline(self) -> int:
        """(max_postpone + 1) * trefi + trfc + 4 * trc  (TIMING_RULES.md, refresh deadline)."""
        return (self.max_postpone + 1) * self.trefi + self.trfc + 4 * self.trc

    def describe(self) -> str:
        return f"profile {self.id} '{self.name}' status={self.status}"


def default_profiles_path() -> Path:
    """``<project root>/configs/timing/profiles.json`` (this file is python/hbm4/timing.py)."""
    return Path(__file__).resolve().parents[2] / "configs" / "timing" / "profiles.json"


def load_profiles(path: Optional[str | Path] = None) -> dict[int, Profile]:
    """Load configs/timing/profiles.json into ``{id: Profile}``."""
    p = Path(path) if path is not None else default_profiles_path()
    with open(p, "r", encoding="utf-8") as fh:
        doc = json.load(fh)
    out: dict[int, Profile] = {}
    for entry in doc.get("profiles", []):
        missing = [f for f in PROFILE_INT_FIELDS if f not in entry]
        for f in ("id", "name", "status"):
            if f not in entry:
                missing.append(f)
        if missing:
            raise ProfileError(f"profile {entry.get('id', '?')}: missing fields {missing}")
        for f in PROFILE_INT_FIELDS:
            if not isinstance(entry[f], int) or isinstance(entry[f], bool):
                raise ProfileError(f"profile {entry['id']}: field {f} must be an integer")
        kwargs = {f: entry[f] for f in PROFILE_INT_FIELDS}
        prof = Profile(
            id=int(entry["id"]), name=str(entry["name"]), status=str(entry["status"]),
            source=str(entry.get("source", "")), **kwargs,
        )
        if prof.id in out:
            raise ProfileError(f"duplicate profile id {prof.id}")
        out[prof.id] = prof
    if not out:
        raise ProfileError("no profiles found")
    return out


@dataclass(frozen=True)
class Violation:
    """One rule violation. ``rule`` is a readable rule name (see RULES below)."""

    rule: str
    cycle: int
    pc: int
    cmd: Optional[int]
    detail: str

    @property
    def cmd_name(self) -> str:
        return cmd_name(self.cmd)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["cmd_name"] = self.cmd_name
        return d

    def __str__(self) -> str:
        return f"[{self.rule}] cycle={self.cycle} pc={self.pc} cmd={self.cmd_name}: {self.detail}"


Finding = tuple[str, str]  # (rule, detail)


# ---------------------------------------------------------------------------
# Pure legality oracle (shared by TimingChecker and the scheduler model)
# ---------------------------------------------------------------------------

def _need(rule: str, now: int, last: int, need: int, what: str) -> Finding:
    return rule, f"{what}: now={now} last={last} gap={now - last} < {need}"


def _group_findings(
    now: int, table: dict[int, int], bg: int, same_need: int, other_need: int,
    same_rule: str, other_rule: str, what: str,
) -> list[Finding]:
    """Per-bank-group check: same group needs ``same_need``, others ``other_need``."""
    out: list[Finding] = []
    same_done = other_done = False
    for g2 in sorted(table):
        last = table[g2]
        gap = now - last
        if g2 == bg:
            if gap < same_need and not same_done:
                out.append(_need(same_rule, now, last, same_need, f"{what} group {g2} (same group)"))
                same_done = True
        elif gap < other_need and not other_done:
            out.append(_need(other_rule, now, last, other_need, f"{what} group {g2} (other group)"))
            other_done = True
    return out


def _pre_findings(st: PcState, p: Profile, now: int, keys: Iterable[tuple[int, int]]) -> list[Finding]:
    """tRAS / tRTP / WR2PRE for every *open* bank among ``keys`` (closed banks unaffected)."""
    out: dict[str, str] = {}
    for key in keys:
        b = st.banks[key]
        if not b.is_open:
            continue
        if b.last_act is not None and now - b.last_act < p.tras:
            out.setdefault("tRAS", _need("tRAS", now, b.last_act, p.tras, f"bank {key} ACT->PRE")[1])
        if b.last_rd is not None and now - b.last_rd < p.trtp:
            out.setdefault("tRTP", _need("tRTP", now, b.last_rd, p.trtp, f"bank {key} RD->PRE")[1])
        if b.last_wr is not None and now - b.last_wr < p.WR2PRE:
            out.setdefault("tWR", _need("tWR", now, b.last_wr, p.WR2PRE, f"bank {key} WR->PRE (WR2PRE)")[1])
    return list(out.items())


def _idle_findings(
    st: PcState, p: Profile, now: int, keys: Iterable[tuple[int, int]],
    open_rule: str, trp_rule: str,
) -> list[Finding]:
    """Common 'banks must be precharged, trp elapsed' precondition (REF/MRS/PDE/SRE)."""
    out: list[Finding] = []
    keys = list(keys)
    open_ = [k for k in keys if st.banks[k].is_open]
    if open_:
        out.append((open_rule, f"banks still open: {open_}"))
    for k in keys:
        b = st.banks[k]
        if b.last_pre is not None and now - b.last_pre < p.trp:
            out.append(_need(trp_rule, now, b.last_pre, p.trp, f"bank {k} PRE->cmd"))
            break
    return out


def check_command(
    st: PcState, p: Profile, now: int, cmd: int, bg: int = 0, ba: int = 0, row: int = 0,
) -> list[Finding]:
    """Return the DRAM-rule findings ``[(rule, detail), ...]`` for a command at ``now``.

    Pure (does not modify ``st``); empty list == legal. Rules are those of
    TIMING_RULES.md; the section is named in each branch. The command is
    assumed to address a bank inside the tracked geometry.
    """
    out: list[Finding] = []

    # -- low-power gating (PDE/SRE section) ---------------------------------
    if st.power is not PowerState.ACTIVE:
        exit_cmd = PDX if st.power is PowerState.POWER_DOWN else SRX
        if cmd != exit_cmd:
            out.append((
                "command_while_low_power",
                f"{cmd_name(cmd)} while in {st.power.value}; only {cmd_name(exit_cmd)} is legal",
            ))
        return out  # the matching exit command has no further preconditions
    if cmd in (PDX, SRX):
        out.append((
            "exit_wrong_state",
            f"{cmd_name(cmd)} issued while not in the matching low-power state",
        ))
        return out

    # -- "no command for txp/txs after exit" (PDE/SRE section) -----------------
    if st.last_exit is not None:
        need = p.txp if st.last_exit_kind is PowerState.POWER_DOWN else p.txs
        which = "txp" if st.last_exit_kind is PowerState.POWER_DOWN else "txs"
        if now - st.last_exit < need:
            out.append(_need("tXP_tXS", now, st.last_exit, need, f"exit->cmd ({which})"))
    # -- "no command for tmrd after MRS" (MRS section) ---------------------------
    if st.last_mrs is not None and now - st.last_mrs < p.tmrd:
        out.append(_need("tMRD", now, st.last_mrs, p.tmrd, "MRS->cmd"))

    all_banks = sorted(st.banks)

    if cmd == ACT:  # ---- ACT section -------------------------------------
        b = st.bank(bg, ba)
        if b.is_open:  # rule 1
            out.append(("ACT_to_open_bank", f"bank {(bg, ba)} already open at row {b.open_row}"))
        if b.last_pre is not None and now - b.last_pre < p.trp:  # rule 2
            out.append(_need("tRP", now, b.last_pre, p.trp, f"bank {(bg, ba)} PRE->ACT"))
        if b.last_act is not None and now - b.last_act < p.trc:  # rule 3
            out.append(_need("tRC", now, b.last_act, p.trc, f"bank {(bg, ba)} ACT->ACT"))
        out += _group_findings(  # rule 4
            now, st.last_act_group, bg, p.trrd_l, p.trrd_s, "tRRD_L", "tRRD_S", "ACT->ACT")
        if len(st.faw) == 4 and now - st.faw[0] < p.tfaw:  # rule 5
            out.append(_need("tFAW", now, st.faw[0], p.tfaw, "4th most recent ACT"))
        if now < st.ref_busy_until:  # rule 6
            out.append(("tRFC", f"ACT at {now} < ref_busy_until={st.ref_busy_until}"))
        if now < b.bank_ref_until:
            out.append(("tRFCpb", f"ACT at {now} < bank_ref_until({(bg, ba)})={b.bank_ref_until}"))

    elif cmd in (RD, WR):  # ---- RD / WR section --------------------------------
        b = st.bank(bg, ba)
        if not b.is_open:
            out.append(("col_to_closed_bank", f"{cmd_name(cmd)} to precharged bank {(bg, ba)}"))
        elif b.open_row != row:
            out.append((
                "col_to_wrong_row",
                f"{cmd_name(cmd)} row {row} but bank {(bg, ba)} has row {b.open_row} open",
            ))
        trcd, trcd_rule = (p.trcdrd, "tRCDRD") if cmd == RD else (p.trcdwr, "tRCDWR")
        if b.last_act is not None and now - b.last_act < trcd:  # rule 1
            out.append(_need(trcd_rule, now, b.last_act, trcd, f"bank {(bg, ba)} ACT->{cmd_name(cmd)}"))
        out += _group_findings(  # rule 2
            now, st.last_col_group, bg, p.tccd_l, p.tccd_s, "tCCD_L", "tCCD_S", "col->col")
        if cmd == RD:  # rule 3 (write-to-read)
            out += _group_findings(
                now, st.last_wr_group, bg, p.WTR_L, p.WTR_S, "tWTR_L", "tWTR_S", "WR->RD (WTR)")
        elif st.last_rd_any is not None and now - st.last_rd_any < p.RTW:  # rule 4 (read-to-write)
            out.append(_need("tRTW", now, st.last_rd_any, p.RTW, "RD->WR (RTW)"))

    elif cmd == PRE:  # ---- PRE / PREA section -----------------------------------
        out += _pre_findings(st, p, now, [(bg, ba)])
    elif cmd == PREA:
        out += _pre_findings(st, p, now, all_banks)

    elif cmd == REF_AB:  # ---- REF_AB section -------------------------------------
        out += _idle_findings(st, p, now, all_banks, "REF_with_open_bank", "tRP_REF")
        if now < st.ref_busy_until:
            out.append(("tRFC", f"REF_AB at {now} < ref_busy_until={st.ref_busy_until}"))
        out += _act_to_ref_findings(st, p, now, all_banks)                       # v2 rule 18
        out += _pb_busy_findings(st, now, all_banks, "REF_AB")                   # v2 rule 19

    elif cmd == REF_PB:  # ---- REF_PB section ---------------------------------------
        b = st.bank(bg, ba)
        out += _idle_findings(st, p, now, [(bg, ba)], "REF_with_open_bank", "tRP_REF")
        if now < b.bank_ref_until:
            out.append(("tRFCpb", f"REF_PB at {now} < bank_ref_until({(bg, ba)})={b.bank_ref_until}"))
        out += _act_to_ref_findings(st, p, now, [(bg, ba)])                      # v2 rule 18
        if now < st.ref_busy_until:                                              # v2 rule 19
            out.append(("tRFC", f"REF_PB at {now} < ref_busy_until={st.ref_busy_until}"))

    elif cmd == MRS:  # ---- MRS section -------------------------------------------
        out += _idle_findings(st, p, now, all_banks, "MRS_with_open_bank", "tRP_MRS")
        if now < st.ref_busy_until:
            out.append(("tRFC", f"MRS at {now} < ref_busy_until={st.ref_busy_until}"))
        out += _pb_busy_findings(st, now, all_banks, "MRS")                      # v2 rule 19

    elif cmd in (PDE, SRE):  # ---- PDE / SRE section ---------------------------------
        out += _idle_findings(st, p, now, all_banks, "LP_entry_with_open_bank", "tRP_LP")
        if now < st.ref_busy_until:
            out.append(("tRFC", f"{cmd_name(cmd)} at {now} < ref_busy_until={st.ref_busy_until}"))
        out += _pb_busy_findings(st, now, all_banks, cmd_name(cmd))              # v2 rule 19

    elif cmd == RFM:  # ---- v2 RFM section (rule 20; ENGINEERING_ASSUMPTION, like REF_PB) ------------------
        b = st.bank(bg, ba)
        out += _idle_findings(st, p, now, [(bg, ba)], "RFM_with_open_bank", "tRP_RFM")
        out += _act_to_ref_findings(st, p, now, [(bg, ba)])
        if now < b.bank_ref_until:
            out.append(("tRFCpb", f"RFM at {now} < bank_ref_until({(bg, ba)})={b.bank_ref_until}"))
        if now < st.ref_busy_until:
            out.append(("tRFC", f"RFM at {now} < ref_busy_until={st.ref_busy_until}"))

    return out


def _act_to_ref_findings(st, p, now, banks):
    """v2 rule 18 (ENGINEERING_ASSUMPTION, docs/TIMING_RULES.md): a refresh of a bank needs tRC since its last ACT."""
    out = []
    for (bg, ba) in banks:
        b = st.bank(bg, ba)
        if b.last_act is not None and now - b.last_act < p.trc:
            out.append(_need("tRC_REF", now, b.last_act, p.trc, f"bank {(bg, ba)} ACT->REF"))
    return out


def _pb_busy_findings(st, now, banks, what):
    """v2 rule 19: no all-bank maintenance command while a per-bank refresh is still running."""
    out = []
    for (bg, ba) in banks:
        b = st.bank(bg, ba)
        if now < b.bank_ref_until:
            out.append(("tRFCpb", f"{what} at {now} < bank_ref_until({(bg, ba)})={b.bank_ref_until}"))
    return out


def apply_command(
    st: PcState, p: Profile, now: int, cmd: int, bg: int = 0, ba: int = 0, row: int = 0,
    noop_pre_updates_last_pre: bool = False,
) -> bool:
    """Apply the state effect of a command; returns False if it had none.

    The effect is applied even if the command violated a rule (it *was* issued
    on the bus). Exception: a command that is illegal because the channel is in
    a low-power state is ignored, as is an exit without a matching entry.
    """
    if st.power is not PowerState.ACTIVE:
        if cmd == PDX and st.power is PowerState.POWER_DOWN:
            st.on_pdx(now)
            return True
        if cmd == SRX and st.power is PowerState.SELF_REFRESH:
            st.on_srx(now)
            return True
        return False
    if cmd in (PDX, SRX):
        return False
    if cmd == ACT:
        st.on_act(now, bg, ba, row)
    elif cmd == RD:
        st.on_rd(now, bg, ba)
    elif cmd == WR:
        st.on_wr(now, bg, ba)
        st.pending_writes.append(PendingWrite(issue=now, expected=now + p.wl))
    elif cmd == PRE:
        st.on_pre(now, bg, ba, noop_pre_updates_last_pre)
    elif cmd == PREA:
        st.on_prea(now, noop_pre_updates_last_pre)
    elif cmd == REF_AB:
        st.on_ref_ab(now, p.trfc)
    elif cmd == REF_PB:
        st.on_ref_pb(now, bg, ba, p.trfcpb)
    elif cmd == MRS:
        st.on_mrs(now)
    elif cmd == PDE:
        st.on_pde(now)
    elif cmd == SRE:
        st.on_sre(now)
    elif cmd == RFM:      # v2: the bank is busy for trfm (a later ACT inside it is a tRFC(pb)-class violation)
        st.bank(bg, ba).bank_ref_until = now + p.trfm
    return True


# ---------------------------------------------------------------------------
# Trace checker
# ---------------------------------------------------------------------------

class TimingChecker:
    """Feed a command trace; collect :class:`Violation` s.

    ``feed`` / ``feed_wdata`` must be called in non-decreasing cycle order per
    pseudo-channel. Pseudo-channels are tracked independently (state per pc),
    created lazily on first use (or up-front via ``pcs=``).

    Parameters
    ----------
    num_bg, num_ba:
        Bank geometry (default 4 x 4 = ADDRESS_MAP.md BG=2, BA=2); needed so the
        refresh-deadline rule can be applied to banks that never see a command.
    time_zero:
        The cycle that "counts as a refresh" for every bank (default 0).
    pre_noop_updates_last_pre:
        Ambiguity knob. False (default, literal "closed banks are unaffected"):
        a PRE/PREA to a closed bank does not touch ``last_PRE``.
    """

    def __init__(
        self, profile: Profile, num_bg: int = 4, num_ba: int = 4, time_zero: int = 0,
        pre_noop_updates_last_pre: bool = False, pcs: Iterable[int] = (),
    ) -> None:
        self.profile = profile
        self.num_bg = num_bg
        self.num_ba = num_ba
        self.time_zero = time_zero
        self.pre_noop_updates_last_pre = pre_noop_updates_last_pre
        self.violations: list[Violation] = []
        self.n_commands = 0
        self.n_wdata = 0
        self._pcs: dict[int, PcState] = {}
        self._last_cycle = time_zero
        for pc in pcs:
            self._pc(pc)

    # -- helpers -----------------------------------------------------------
    @property
    def status(self) -> str:
        """Profile status (always HYPOTHETICAL_SIM for the shipped profiles)."""
        return self.profile.status

    @property
    def clean(self) -> bool:
        return not self.violations

    def pc_state(self, pc: int) -> PcState:
        return self._pc(pc)

    def _pc(self, pc: int) -> PcState:
        st = self._pcs.get(pc)
        if st is None:
            st = self._pcs[pc] = PcState(self.num_bg, self.num_ba, self.time_zero)
        return st

    def _emit(self, rule: str, cycle: int, pc: int, cmd: Optional[int], detail: str) -> Violation:
        v = Violation(rule, cycle, pc, cmd, detail)
        self.violations.append(v)
        return v

    def _deadline(self, st: PcState, pc: int, upto: int) -> Optional[Violation]:
        """Refresh deadline (TIMING_RULES.md): ``now - last_refresh(b) <= bound`` per bank,
        except while in self-refresh. One violation lists every bank that newly lapsed."""
        if st.power is PowerState.SELF_REFRESH:
            return None
        bound = self.profile.refresh_deadline
        lapsed = [
            (key, b) for key, b in sorted(st.banks.items())
            if not b.lapse_flagged and upto - b.last_refresh > bound
        ]
        if not lapsed:
            return None
        for _, b in lapsed:
            b.lapse_flagged = True
        first = min(b.last_refresh + bound + 1 for _, b in lapsed)
        desc = ", ".join(f"{k}(last_refresh={b.last_refresh})" for k, b in lapsed[:4])
        if len(lapsed) > 4:
            desc += f", ... ({len(lapsed)} banks)"
        return self._emit(
            "refresh_deadline", first, pc, None,
            f"bound={bound} exceeded at cycle {upto}: {desc}",
        )

    # -- API ---------------------------------------------------------------
    def feed(
        self, cycle: int, pc: int, cmd: int, bg: int = 0, ba: int = 0, row: int = 0, col: int = 0,
    ) -> list[Violation]:
        """Check one command. Returns the violations found by this command."""
        before = len(self.violations)
        st = self._pc(pc)
        self.n_commands += 1
        self._last_cycle = max(self._last_cycle, cycle)

        # trace hygiene: chronology and "at most one command per pc per cycle"
        if st.last_cmd_cycle is not None:
            if cycle < st.last_cmd_cycle:
                self._emit("trace_not_chronological", cycle, pc, cmd,
                           f"cycle {cycle} after cycle {st.last_cmd_cycle} on the same pc")
            elif cycle == st.last_cmd_cycle:
                self._emit("cmd_bus_conflict", cycle, pc, cmd,
                           f"second command in cycle {cycle} on pc {pc} (max one per pc per cycle)")
        st.last_cmd_cycle = cycle if st.last_cmd_cycle is None else max(st.last_cmd_cycle, cycle)

        if cmd not in CMD_NAMES:
            self._emit("unknown_command", cycle, pc, cmd, f"command code {cmd}")
            return self.violations[before:]
        if cmd in BANK_ADDRESSED and not (0 <= bg < self.num_bg and 0 <= ba < self.num_ba):
            self._emit("bank_out_of_range", cycle, pc, cmd,
                       f"(bg={bg}, ba={ba}) outside {self.num_bg}x{self.num_ba} geometry; command skipped")
            return self.violations[before:]

        self._deadline(st, pc, cycle)
        for rule, detail in check_command(st, self.profile, cycle, cmd, bg, ba, row):
            self._emit(rule, cycle, pc, cmd, detail)
        apply_command(st, self.profile, cycle, cmd, bg, ba, row, self.pre_noop_updates_last_pre)
        return self.violations[before:]

    def feed_wdata(self, cycle: int, pc: int) -> list[Violation]:
        """A write-data beat on pseudo-channel ``pc`` at ``cycle``.

        TIMING_RULES.md, data timing: a WR issued at ``t`` takes its data during
        cycle ``t + wl`` -- exactly then. One beat per WR (see SPEC_AMBIGUITIES.md).
        """
        before = len(self.violations)
        st = self._pc(pc)
        self.n_wdata += 1
        self._last_cycle = max(self._last_cycle, cycle)
        exact = next((w for w in st.pending_writes if w.expected == cycle), None)
        if exact is not None:
            st.pending_writes.remove(exact)
        elif st.pending_writes:
            w = st.pending_writes.pop(0)
            self._emit("write_data_off_time", cycle, pc, WR,
                       f"WR issued at {w.issue} expects its data at {w.expected} (= issue + wl), got {cycle}")
        else:
            self._emit("write_data_unexpected", cycle, pc, None,
                       f"write-data beat at {cycle} with no outstanding WR")
        return self.violations[before:]

    def finish(self, end_cycle: Optional[int] = None) -> list[Violation]:
        """End-of-trace checks: missing write data and the refresh deadline.

        ``end_cycle`` is the last cycle covered by the trace (inclusive); default
        is the last cycle seen. A WR whose data is due at or before ``end_cycle``
        but never arrived is ``write_data_missing``; one still due later is not
        yet judged. The refresh deadline is evaluated at ``end_cycle`` for every
        tracked pseudo-channel not in self-refresh.
        """
        before = len(self.violations)
        end = self._last_cycle if end_cycle is None else end_cycle
        for pc in sorted(self._pcs):
            st = self._pcs[pc]
            keep: list[PendingWrite] = []
            for w in st.pending_writes:
                if w.expected <= end:
                    self._emit("write_data_missing", w.expected, pc, WR,
                               f"WR issued at {w.issue}: no write-data beat at {w.expected} (= issue + wl)")
                else:
                    keep.append(w)
            st.pending_writes = keep
            self._deadline(st, pc, end)
        return self.violations[before:]

    # -- reporting -----------------------------------------------------------
    def summary(self) -> dict[str, int]:
        """Violation count per rule name."""
        return dict(sorted(Counter(v.rule for v in self.violations).items()))

    def rules(self) -> set[str]:
        return {v.rule for v in self.violations}

    def header(self) -> str:
        return f"{self.profile.describe()} -- {STATUS_NOTE}"
