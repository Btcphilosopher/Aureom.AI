"""Address mapping, derived ONLY from docs/ADDRESS_MAP.md.

Geometry is a simulation reference geometry (ENGINEERING_ASSUMPTION); nothing
here is an HBM4 / JEDEC statement.

Granule address ``g = addr >> OFF``; fields are extracted LSB-first in the order
of the selected mode (ADDRESS_MAP.md, mode table).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import NamedTuple

MAP_LINEAR = 0
MAP_CH_IL = 1
MAP_BANK_AWARE = 2

_MODES = (MAP_LINEAR, MAP_CH_IL, MAP_BANK_AWARE)

#: check_addr() results
ADDR_OK = 0
ADDR_MISALIGN = 1
ADDR_RANGE = 2


class Loc(NamedTuple):
    """A mapped location (ADDRESS_MAP.md: ``(stack, ch, pc, bg, ba, row, col)``)."""

    stack: int
    ch: int
    pc: int
    bg: int
    ba: int
    row: int
    col: int


def _log2_pow2(n: int, what: str) -> int:
    if n < 1 or (n & (n - 1)) != 0:
        raise ValueError(f"{what} must be a power of two, got {n}")
    return n.bit_length() - 1


@dataclass(frozen=True)
class AddrMapCfg:
    """Geometry (ADDRESS_MAP.md, geometry table). Widths: OFF, COL, BA, BG, ROW.

    ``num_stacks``, ``num_channels`` and ``pcs`` are powers of two; the field
    widths NS, CH, PC are their log2.
    """

    num_stacks: int = 1
    num_channels: int = 32
    pcs: int = 2
    off: int = 5
    col: int = 6
    ba: int = 2
    bg: int = 2
    row: int = 15
    addr_w: int = 40

    def __post_init__(self) -> None:
        _log2_pow2(self.num_stacks, "num_stacks")
        _log2_pow2(self.num_channels, "num_channels")
        _log2_pow2(self.pcs, "pcs")
        for name in ("off", "col", "ba", "bg", "row", "addr_w"):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be >= 0")

    @property
    def pc_bits(self) -> int:
        return _log2_pow2(self.pcs, "pcs")

    @property
    def ch_bits(self) -> int:
        return _log2_pow2(self.num_channels, "num_channels")

    @property
    def ns_bits(self) -> int:
        return _log2_pow2(self.num_stacks, "num_stacks")

    @property
    def cap_bits(self) -> int:
        """log2 of the addressed capacity: OFF+COL+BA+BG+ROW+PC+CH+NS."""
        return (
            self.off + self.col + self.ba + self.bg + self.row
            + self.pc_bits + self.ch_bits + self.ns_bits
        )

    @property
    def num_bank_groups(self) -> int:
        return 1 << self.bg

    @property
    def num_banks_per_group(self) -> int:
        return 1 << self.ba


def _mask(width: int) -> int:
    return (1 << width) - 1


def _layout(cfg: AddrMapCfg, mode: int, il: int) -> list[tuple[str, int]]:
    """Field order, LSB first, after the byte offset (ADDRESS_MAP.md mode table)."""
    if mode == MAP_LINEAR:
        # `il` has no effect: col_lo and col_hi would be adjacent anyway.
        return [
            ("col", cfg.col), ("ba", cfg.ba), ("bg", cfg.bg), ("row", cfg.row),
            ("pc", cfg.pc_bits), ("ch", cfg.ch_bits), ("stack", cfg.ns_bits),
        ]
    if mode not in _MODES:
        raise ValueError(f"unknown map mode {mode}")
    if not 0 <= il <= cfg.col:
        raise ValueError(f"il={il} outside 0..COL={cfg.col}")
    if mode == MAP_CH_IL:
        return [
            ("col_lo", il), ("pc", cfg.pc_bits), ("ch", cfg.ch_bits),
            ("stack", cfg.ns_bits), ("col_hi", cfg.col - il),
            ("ba", cfg.ba), ("bg", cfg.bg), ("row", cfg.row),
        ]
    return [  # MAP_BANK_AWARE
        ("col_lo", il), ("pc", cfg.pc_bits), ("ch", cfg.ch_bits),
        ("stack", cfg.ns_bits), ("bg", cfg.bg), ("ba", cfg.ba),
        ("col_hi", cfg.col - il), ("row", cfg.row),
    ]


def _hash_xor(cfg: AddrMapCfg, bg: int, ba: int, ch: int, row: int) -> tuple[int, int, int]:
    """The (involutive, given ``row``) hash of ADDRESS_MAP.md.

    bg ^= row[BG-1:0];  ba ^= row[BG+BA-1:BG];
    ch ^= (row >> (BG+BA)) & (2^CH - 1)   (only if CH > 0).
    """
    bg ^= row & _mask(cfg.bg)
    ba ^= (row >> cfg.bg) & _mask(cfg.ba)
    if cfg.ch_bits > 0:
        ch ^= (row >> (cfg.bg + cfg.ba)) & _mask(cfg.ch_bits)
    return bg, ba, ch


def map_addr(addr: int, cfg: AddrMapCfg, mode: int, il: int = 0, hash: bool = False) -> Loc:  # noqa: A002
    """Map a byte address to a location.

    The byte-offset bits ``addr[OFF-1:0]`` and any bits above the capacity are
    ignored here (use :func:`check_addr` to classify misaligned / out-of-range
    addresses). The optional hash is applied after extraction, ``row`` unchanged.
    """
    g = addr >> cfg.off
    fields: dict[str, int] = {}
    for name, width in _layout(cfg, mode, il):
        fields[name] = g & _mask(width)
        g >>= width
    if "col" in fields:
        col = fields["col"]
    else:
        col = fields["col_lo"] | (fields["col_hi"] << il)
    bg, ba, ch, row = fields["bg"], fields["ba"], fields["ch"], fields["row"]
    if hash:
        bg, ba, ch = _hash_xor(cfg, bg, ba, ch, row)
    return Loc(fields["stack"], ch, fields["pc"], bg, ba, row, col)


def unmap_loc(loc: Loc, cfg: AddrMapCfg, mode: int, il: int = 0, hash: bool = False) -> int:  # noqa: A002
    """Inverse of :func:`map_addr`: the byte address (offset bits 0).

    The same XORs are applied first (they are involutions given ``row``), then
    the address is reassembled.
    """
    stack, ch, pc, bg, ba, row, col = loc
    limits = {
        "stack": cfg.num_stacks, "ch": cfg.num_channels, "pc": cfg.pcs,
        "bg": 1 << cfg.bg, "ba": 1 << cfg.ba, "row": 1 << cfg.row, "col": 1 << cfg.col,
    }
    for name, val in zip(loc._fields, loc):
        if not 0 <= val < limits[name]:
            raise ValueError(f"{name}={val} out of range for geometry")
    if hash:
        bg, ba, ch = _hash_xor(cfg, bg, ba, ch, row)
    layout = _layout(cfg, mode, il)
    values = {"stack": stack, "ch": ch, "pc": pc, "bg": bg, "ba": ba, "row": row}
    if mode == MAP_LINEAR:
        values["col"] = col
    else:
        values["col_lo"] = col & _mask(il)
        values["col_hi"] = col >> il
    g = 0
    shift = 0
    for name, width in layout:
        g |= (values[name] & _mask(width)) << shift
        shift += width
    return g << cfg.off


def check_addr(addr: int, cfg: AddrMapCfg) -> int:
    """0 ok, 1 misaligned (``addr[OFF-1:0] != 0``), 2 out of range.

    RANGE wins if both apply. Out of range = any bit at or above the capacity
    ``2^cap_bits`` (or above ADDR_W) set, or a negative value.
    """
    if addr < 0 or (addr >> cfg.cap_bits) != 0 or (addr >> cfg.addr_w) != 0:
        return ADDR_RANGE
    if addr & _mask(cfg.off):
        return ADDR_MISALIGN
    return ADDR_OK


def pc_index(loc: Loc, cfg: AddrMapCfg) -> int:
    """Flat pseudo-channel index: ``((stack * NUM_CHANNELS) + ch) * pcs + pc``.

    ADDRESS_MAP.md writes the multiplier as the literal ``2`` (pcs == 2); see
    SPEC_AMBIGUITIES.md.
    """
    return ((loc.stack * cfg.num_channels) + loc.ch) * cfg.pcs + loc.pc
