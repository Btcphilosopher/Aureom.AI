"""Transaction-log scoreboard, derived ONLY from docs/ORDERING.md.

Consumes the JSON-lines transaction log (``req`` at acceptance, ``rsp`` at
response hand-shake) and checks:

* exactly one response per request (no lost / duplicated / foreign responses);
* response ownership: the response ``src`` equals the request's source;
* same-{src,id} responses are in request order (guarantee 3);
* read data equals a reference memory evaluated in REQUEST-ACCEPTANCE order,
  masked writes applied at their ``req`` record, reads snapshotted at theirs
  (guarantee 4);
* ``err != 0`` only where the request warrants it (misaligned / out of range /
  ECC policy, or what the caller declares via ``expected_errors`` /
  ``error_predicate`` / ``allowed_err_codes``); error transactions neither
  modify memory nor are data-checked (ORDERING.md "Error responses").

The file order of the records is taken as the true event order.
"""

from __future__ import annotations

import json
from collections import Counter, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Optional, Union

from .address_map import AddrMapCfg, check_addr
from .reference_memory import FULL_BYTE_MASK, RefMemory
from .transactions import (
    ERR_NAMES, ERR_NONE, ERR_POLICY, Rsp, Txn,
)

ErrSpec = Union[int, Iterable[int]]
ErrPredicate = Callable[[Txn, int], Optional[ErrSpec]]


@dataclass
class Failure:
    kind: str
    detail: str
    index: Optional[int] = None  # record index in the log
    t: Optional[int] = None

    def __str__(self) -> str:
        loc = f" (record {self.index}, t={self.t})" if self.index is not None else ""
        return f"[{self.kind}]{loc} {self.detail}"


@dataclass
class TxnReport:
    """Result of :func:`check_transactions`."""

    failures: list[Failure] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    n_req: int = 0
    n_rsp: int = 0
    n_paired: int = 0
    n_error_rsp: int = 0
    n_read_checked: int = 0

    @property
    def ok(self) -> bool:
        return not self.failures

    def by_kind(self) -> dict[str, int]:
        return dict(sorted(Counter(f.kind for f in self.failures).items()))

    def to_dict(self) -> dict:
        return {
            "ok": self.ok,
            "n_req": self.n_req,
            "n_rsp": self.n_rsp,
            "n_paired": self.n_paired,
            "n_error_rsp": self.n_error_rsp,
            "n_read_checked": self.n_read_checked,
            "by_kind": self.by_kind(),
            "warnings": list(self.warnings),
            "failures": [
                {"kind": f.kind, "detail": f.detail, "index": f.index, "t": f.t}
                for f in self.failures
            ],
        }

    def format(self, max_listed: int = 20) -> str:
        out = [
            f"transactions: req={self.n_req} rsp={self.n_rsp} paired={self.n_paired} "
            f"error_rsp={self.n_error_rsp} reads_checked={self.n_read_checked}",
        ]
        if self.ok:
            out.append("RESULT: PASS")
        else:
            out.append(f"RESULT: FAIL ({len(self.failures)} failure(s))")
            for k, n in self.by_kind().items():
                out.append(f"  {k:<26} {n}")
            for f in self.failures[:max_listed]:
                out.append(f"  {f}")
            if len(self.failures) > max_listed:
                out.append(f"  ... {len(self.failures) - max_listed} more")
        for w in self.warnings[:5]:
            out.append(f"warning: {w}")
        return "\n".join(out)


@dataclass
class _Pending:
    req: Txn
    req_no: int
    rec_index: int
    base_allowed: frozenset[int]  # error codes the request warrants (0 => normal completion)
    allowed: frozenset[int]  # base_allowed plus globally allowed codes
    expected_data: Optional[int]  # read snapshot, None for writes / error requests


def load_jsonl(path: Union[str, Path]) -> list[dict]:
    """Read a JSON-lines transaction log (blank lines skipped)."""
    out: list[dict] = []
    with open(path, "r", encoding="utf-8") as fh:
        for n, line in enumerate(fh, 1):
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{n}: invalid JSON: {exc}") from exc
    return out


def derived_error(txn: Txn, cfg: AddrMapCfg, ecc_enabled: bool) -> int:
    """Error code the request warrants by itself (ORDERING.md "Error responses").

    MISALIGN / RANGE from the address (RANGE wins, :func:`check_addr`); then POLICY
    for a partial write (mask != all ones) while controller ECC is enabled.
    """
    ac = check_addr(txn.addr, cfg)
    if ac:
        return ac
    if txn.write and ecc_enabled and (txn.mask & FULL_BYTE_MASK) != FULL_BYTE_MASK:
        return ERR_POLICY
    return ERR_NONE


def _as_set(spec: ErrSpec) -> frozenset[int]:
    if isinstance(spec, int):
        return frozenset({spec})
    return frozenset(int(x) for x in spec)


def _err_str(codes: Iterable[int]) -> str:
    return "{" + ", ".join(f"{c}={ERR_NAMES.get(c, '?')}" for c in sorted(codes)) + "}"


def check_transactions(
    records: Iterable[Mapping[str, Any]],
    cfg: Optional[AddrMapCfg] = None,
    ecc_enabled: bool = False,
    expected_errors: Optional[Mapping[int, ErrSpec]] = None,
    error_predicate: Optional[ErrPredicate] = None,
    allowed_err_codes: Iterable[int] = (),
) -> TxnReport:
    """Check a transaction log; returns a :class:`TxnReport` (``.ok`` is the verdict).

    Parameters
    ----------
    cfg:
        Geometry used to classify MISALIGN / RANGE (default :class:`AddrMapCfg`).
    ecc_enabled:
        Controller ECC on: a partial write is expected to answer POLICY (3).
    expected_errors:
        ``{request_number: code or collection of allowed codes}`` where the request
        number counts ``req`` records from 0. Overrides the derived expectation.
    error_predicate:
        ``f(txn, request_number) -> code | collection | None``; consulted when
        ``expected_errors`` has no entry; ``None`` falls back to the derived error.
    allowed_err_codes:
        Codes tolerated on any response (e.g. ``{6, 7}`` for injected faults).
    """
    cfg = cfg or AddrMapCfg()
    globally_ok = frozenset(allowed_err_codes)
    rep = TxnReport()
    mem = RefMemory()
    outstanding: dict[tuple[int, int], deque[_Pending]] = {}
    completed: Counter[tuple[int, int]] = Counter()
    last_t: Optional[int] = None

    def fail(kind: str, detail: str, idx: Optional[int], t: Optional[int]) -> None:
        rep.failures.append(Failure(kind, detail, idx, t))

    def compat(p: _Pending, r: Rsp) -> bool:
        if r.write != p.req.write or r.err not in p.allowed:
            return False
        if r.err == ERR_NONE and not r.write and p.expected_data is not None:
            return r.data == p.expected_data
        return True

    def verify(p: _Pending, r: Rsp, idx: int) -> None:
        tag = f"src={r.src} id={r.id} (req #{p.req_no}, addr=0x{p.req.addr:x})"
        if r.write != p.req.write:
            fail("rsp_kind_mismatch",
                 f"{tag}: response w={int(r.write)} but request w={int(p.req.write)}", idx, r.t)
        if r.err not in p.allowed:
            if r.err == ERR_NONE:
                fail("expected_error_missing",
                     f"{tag}: err=NONE but request warrants {_err_str(p.base_allowed)}", idx, r.t)
            elif p.base_allowed == {ERR_NONE}:
                fail("unexpected_error",
                     f"{tag}: err={r.err}({ERR_NAMES.get(r.err, '?')}) on a request with no error cause",
                     idx, r.t)
            else:
                fail("wrong_error_code",
                     f"{tag}: err={r.err}, allowed {_err_str(p.allowed)}", idx, r.t)
        elif r.err == ERR_NONE and not r.write and p.expected_data is not None:
            rep.n_read_checked += 1
            if r.data != p.expected_data:
                fail("data_mismatch",
                     f"{tag}: read data 0x{r.data:064x} != reference 0x{p.expected_data:064x}",
                     idx, r.t)
        if r.err != ERR_NONE:
            rep.n_error_rsp += 1

    req_no = 0
    for idx, rec in enumerate(records):
        ev = rec.get("ev") if isinstance(rec, Mapping) else None
        t = rec.get("t") if isinstance(rec, Mapping) else None
        if isinstance(t, int):
            if last_t is not None and t < last_t:
                rep.warnings.append(f"record {idx}: time goes backwards ({t} < {last_t})")
            last_t = t
        try:
            if ev == "req":
                txn = Txn.from_record(rec)
            elif ev == "rsp":
                rsp = Rsp.from_record(rec)
            else:
                fail("malformed_record", f"unknown ev {ev!r}", idx, t if isinstance(t, int) else None)
                continue
        except (KeyError, ValueError, TypeError) as exc:
            fail("malformed_record", f"cannot parse {ev!r} record: {exc!r}", idx,
                 t if isinstance(t, int) else None)
            continue

        if ev == "req":
            rep.n_req += 1
            exp: Optional[ErrSpec] = None
            if expected_errors is not None and req_no in expected_errors:
                exp = expected_errors[req_no]
            elif error_predicate is not None:
                exp = error_predicate(txn, req_no)
            base = _as_set(exp) if exp is not None else frozenset({derived_error(txn, cfg, ecc_enabled)})
            error_request = ERR_NONE not in base
            expected_data: Optional[int] = None
            if not error_request:  # error transactions do not touch memory
                if txn.write:
                    mem.write(txn.addr, txn.data, txn.mask)
                else:
                    expected_data = mem.read(txn.addr)
            outstanding.setdefault((txn.src, txn.id), deque()).append(
                _Pending(txn, req_no, idx, base, base | globally_ok, expected_data))
            req_no += 1
            continue

        # ---- response ----------------------------------------------------
        rep.n_rsp += 1
        key = (rsp.src, rsp.id)
        q = outstanding.get(key)
        if q:
            pick = next((i for i, p in enumerate(q) if compat(p, rsp)), None)
            if pick == 0 or pick is None:
                p = q.popleft()
                verify(p, rsp, idx)
            else:
                p = q[pick]
                del q[pick]
                head = q[0]
                fail("same_id_order_violation",
                     f"src={rsp.src} id={rsp.id}: response for req #{p.req_no} overtook "
                     f"older req #{head.req_no}", idx, rsp.t)
                verify(p, rsp, idx)
            completed[key] += 1
            rep.n_paired += 1
            if not q:
                del outstanding[key]
            continue

        # no outstanding request with this {src,id}: wrong owner? duplicate? foreign?
        owner = None
        for okey, oq in outstanding.items():
            if okey[1] == rsp.id and okey[0] != rsp.src and oq and compat(oq[0], rsp):
                owner = okey
                break
        if owner is not None:
            oq = outstanding[owner]
            p = oq.popleft()
            if not oq:
                del outstanding[owner]
            completed[owner] += 1
            rep.n_paired += 1
            fail("src_mismatch",
                 f"response src={rsp.src} id={rsp.id} answers req #{p.req_no} of src={owner[0]} "
                 f"(ownership violated)", idx, rsp.t)
        elif completed[key] > 0:
            fail("duplicate_response",
                 f"src={rsp.src} id={rsp.id}: response with no outstanding request "
                 f"({completed[key]} already answered)", idx, rsp.t)
        else:
            fail("foreign_response",
                 f"src={rsp.src} id={rsp.id}: response matches no request", idx, rsp.t)

    for key, q in outstanding.items():
        for p in q:
            fail("lost_response",
                 f"src={key[0]} id={key[1]}: request #{p.req_no} (addr=0x{p.req.addr:x}, "
                 f"w={int(p.req.write)}) never got a response", p.rec_index, p.req.t)
    return rep
