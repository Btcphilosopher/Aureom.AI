"""trace_check CLI / parser tests (format of docs/ORDERING.md "Command trace")."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from hbm4.timing import load_profiles
from hbm4.trace_check import TraceParseError, check_trace_file, main, parse_trace

PROFILE0 = load_profiles()[0]
PYDIR = Path(__file__).resolve().parents[1]  # python/

CLEAN = """\
# legal trace, profile 0 (sim_fast)
0 0 1 0 0 5 0

3 0 1 1 0 6 0
# RD 4 cycles after ACT (trcdrd = 4); WR at 12 (RTW: no RD) ; data 3 cycles later
4 0 2 0 0 5 1
10 0 3 0 0 5 2
W 13 0
"""

# ACT@0 then RD@3 violates tRCDRD (3 < 4); ACT@1 on another group violates tRRD_S
DIRTY = """\
0 0 1 0 0 5 0
1 0 1 1 0 6 0
3 0 2 0 0 5 1
"""


def write(tmp_path: Path, text: str) -> Path:
    p = tmp_path / "trace.txt"
    p.write_text(text)
    return p


def test_parse_skips_blank_and_comment_lines() -> None:
    evs = list(parse_trace(iter(CLEAN.splitlines())))
    assert evs[0] == ("cmd", 0, 0, 1, 0, 0, 5, 0)
    assert evs[-1] == ("W", 13, 0)
    assert len(evs) == 5


def test_parse_errors() -> None:
    with pytest.raises(TraceParseError):
        list(parse_trace(iter(["1 2 3"])))
    with pytest.raises(TraceParseError):
        list(parse_trace(iter(["W 1"])))
    with pytest.raises(TraceParseError):
        list(parse_trace(iter(["a b c d e f g"])))


def test_check_trace_file_clean(tmp_path: Path) -> None:
    # ACT g0@0, ACT g1@3 (>= trrd_s 2), RD@4 (4-0 >= 4), WR@10: RTW 10-4 = 6 >= 6 ; W at 10+3 = 13
    chk = check_trace_file(write(tmp_path, CLEAN), PROFILE0)
    assert chk.violations == []


def test_check_trace_file_dirty(tmp_path: Path) -> None:
    chk = check_trace_file(write(tmp_path, DIRTY), PROFILE0)
    assert chk.rules() == {"tRRD_S", "tRCDRD"}


def test_end_cycle_triggers_missing_write_data_and_deadline(tmp_path: Path) -> None:
    f = write(tmp_path, "0 0 1 0 0 5 0\n10 0 3 0 0 5 0\n")  # WR@10 without data
    assert check_trace_file(f, PROFILE0).rules() == set()  # last cycle seen = 10 < 13
    assert check_trace_file(f, PROFILE0, end_cycle=13).rules() == {"write_data_missing"}
    # 1036 = refresh bound of profile 0: one cycle later every bank has lapsed
    assert "refresh_deadline" in check_trace_file(f, PROFILE0, end_cycle=1037).rules()


def test_cli_clean_exit_0_and_json(tmp_path: Path, capsys) -> None:
    out = tmp_path / "r.json"
    rc = main([str(write(tmp_path, CLEAN)), "--profile", "0", "--json", str(out)])
    assert rc == 0
    rep = json.loads(out.read_text())
    assert rep["clean"] is True and rep["num_violations"] == 0
    assert rep["profile"]["status"] == "HYPOTHETICAL_SIM"
    assert "HYPOTHETICAL_SIM" in capsys.readouterr().out


def test_cli_dirty_exit_1(tmp_path: Path, capsys) -> None:
    out = tmp_path / "r.json"
    rc = main([str(write(tmp_path, DIRTY)), "--profile", "0", "--json", str(out)])
    assert rc == 1
    rep = json.loads(out.read_text())
    assert rep["by_rule"] == {"tRCDRD": 1, "tRRD_S": 1}
    text = capsys.readouterr().out
    assert "tRCDRD" in text and "tRRD_S" in text and "2 VIOLATION" in text


def test_cli_bad_profile_and_bad_file(tmp_path: Path) -> None:
    assert main([str(write(tmp_path, CLEAN)), "--profile", "42"]) == 2
    assert main([str(tmp_path / "nope.txt"), "--profile", "0"]) == 2
    assert main([str(write(tmp_path, "garbage\n")), "--profile", "0"]) == 2


def test_cli_as_module_subprocess(tmp_path: Path) -> None:
    env = dict(os.environ, PYTHONPATH=str(PYDIR))
    for text, rc in ((CLEAN, 0), (DIRTY, 1)):
        proc = subprocess.run(
            [sys.executable, "-m", "hbm4.trace_check", str(write(tmp_path, text)), "--profile", "0"],
            capture_output=True, text=True, env=env,
        )
        assert proc.returncode == rc, proc.stdout + proc.stderr
        assert "HYPOTHETICAL_SIM" in proc.stdout
