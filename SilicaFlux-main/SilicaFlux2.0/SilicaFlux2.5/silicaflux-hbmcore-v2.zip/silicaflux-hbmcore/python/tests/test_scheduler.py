"""Scheduler-model tests: hand-computed cycle numbers (profile 0 = sim_fast) and
legality of every emitted trace against the independent TimingChecker.

Profile 0: trcdrd 4, trcdwr 3, trp 4, tras 9, trc 13, tccd_s 1, tccd_l 2, trrd_s 2, trrd_l 3,
tfaw 10, twr 5, twtr_s 2, twtr_l 4, trtp 2, trfc 24, trefi 240, rl 6, wl 3, burst 1,
WTR_L = 8, WR2PRE = 9, max_postpone 3.
"""

from __future__ import annotations

import random

import pytest

from hbm4.commands import ACT, PRE, PREA, RD, REF_AB, WR
from hbm4.scheduler import SimResult, simulate
from hbm4.timing import load_profiles
from hbm4.trace_check import check_events, parse_trace

PROFILES = load_profiles()
P0, P1, P2 = PROFILES[0], PROFILES[1], PROFILES[2]

# request tuple: (arrival, is_write, bg, ba, row, col)


def cmds(res: SimResult, which: int) -> list[int]:
    return [c[0] for c in res.commands if c[2] == which]


def assert_clean(res: SimResult) -> None:
    chk = res.check()
    assert chk.violations == [], "\n".join(str(v) for v in chk.violations[:10])
    # the textual trace round-trips through the trace_check parser
    chk2 = check_events(parse_trace(iter(res.trace_lines())), res.profile, res.end_cycle)
    assert chk2.violations == []


# ---------------------------------------------------------------------------
# Hand-computed scenarios
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("policy", ["fcfs", "frfcfs"])
def test_single_read_latency(policy: str) -> None:
    # arrival 10: ACT@10 ; RD@10+trcdrd 4 = 14 ; data at 14+rl 6 = 20 ; latency 20-10 = 10
    res = simulate([(10, False, 0, 0, 7, 3)], P0, policy)
    assert res.commands == [(10, 0, ACT, 0, 0, 7, 0), (14, 0, RD, 0, 0, 7, 3)]
    assert res.latencies == [10] and res.issue_cycles == [14]
    assert (res.row_hits, res.row_empty, res.row_conflicts) == (0, 1, 0)
    assert (res.activates, res.precharges, res.refreshes) == (1, 0, 0)
    assert res.bytes_moved == 32
    assert res.status == "HYPOTHETICAL_SIM"
    assert_clean(res)


def test_single_write_latency_and_write_data_beat() -> None:
    # arrival 0: ACT@0 ; WR@0+trcdwr 3 = 3 ; data at 3+wl 3 = 6 ; latency 6
    res = simulate([(0, True, 1, 2, 9, 0)], P0)
    assert res.commands == [(0, 0, ACT, 1, 2, 9, 0), (3, 0, WR, 1, 2, 9, 0)]
    assert res.wdata == [(6, 0)]
    assert res.latencies == [6]
    assert res.trace_lines() == ["0 0 1 1 2 9 0", "3 0 3 1 2 9 0", "W 6 0"]
    assert_clean(res)


@pytest.mark.parametrize("policy", ["fcfs", "frfcfs"])
def test_row_conflict_timeline(policy: str) -> None:
    # same bank, rows 1 and 2, both arrive at 0.
    # ACT@0 ; RD r0@4 (trcdrd) ; PRE@9 (tras 9 from ACT; RD@4 + trtp 2 = 6 is earlier) ;
    # ACT@13 (PRE@9 + trp 4 = 13 = ACT@0 + trc 13) ; RD r1@17 ; data 17+6 = 23
    res = simulate([(0, False, 0, 0, 1, 0), (0, False, 0, 0, 2, 0)], P0, policy)
    assert res.commands == [
        (0, 0, ACT, 0, 0, 1, 0), (4, 0, RD, 0, 0, 1, 0), (9, 0, PRE, 0, 0, 0, 0),
        (13, 0, ACT, 0, 0, 2, 0), (17, 0, RD, 0, 0, 2, 0),
    ]
    assert res.latencies == [10, 23]
    assert (res.row_hits, res.row_empty, res.row_conflicts) == (0, 1, 1)
    assert (res.activates, res.precharges) == (2, 1)
    assert_clean(res)


def test_write_then_read_same_granule_keeps_order_and_turnaround() -> None:
    # WR@3 (ACT@0 + trcdwr 3) ; RD same granule must follow: WTR_L = 3+1+4 = 8 -> RD@11 ; data 17
    reqs = [(0, True, 0, 0, 1, 5), (0, False, 0, 0, 1, 5)]
    for policy in ("fcfs", "frfcfs"):
        res = simulate(reqs, P0, policy)
        assert res.issue_cycles == [3, 11]
        assert res.latencies == [6, 17]
        assert_clean(res)


def two_group_stream(n: int = 64) -> list:
    # alternate bank group 0 / 1, bank 0, row 0, increasing columns, all arrive at 0
    return [(0, False, k % 2, 0, 0, k // 2) for k in range(n)]


def test_frfcfs_two_group_stream_hand_computed() -> None:
    # ACT g0@0 ; ACT g1@2 (trrd_s) ; RD r0@4 ; r1@6 (ACT@2 + trcdrd) ; r2 g0 needs tccd_l: @7 ;
    # from then one column per cycle: r_k @ k+5 (k >= 1) -> r63 @ 68, data 68+6 = 74
    res = simulate(two_group_stream(), P0, "frfcfs")
    assert cmds(res, ACT) == [0, 2]
    assert res.issue_cycles[0] == 4
    assert res.issue_cycles[1:] == [k + 5 for k in range(1, 64)]
    assert res.latencies[63] == 74
    assert (res.row_hits, res.row_empty, res.row_conflicts) == (62, 2, 0)
    assert res.end_cycle == 74 and res.total_cycles == 75
    assert res.bytes_moved == 64 * 32 == 2048
    assert res.bandwidth_gb_s == pytest.approx(2048 / 75)  # bytes / cycles at 1000 MHz = GB/s
    assert_clean(res)


def test_fcfs_two_group_stream_hand_computed() -> None:
    # FCFS: head r0 ACT@0, RD@4 ; head r1 ACT g1@5 (only after r0 left) ; RD r1@9 ;
    # r2@10 ; ... r_k @ k+8 (k >= 1) -> r63 @ 71, data 77.  Slower than FR-FCFS.
    res = simulate(two_group_stream(), P0, "fcfs")
    assert cmds(res, ACT) == [0, 5]
    assert res.issue_cycles[0] == 4
    assert res.issue_cycles[1:] == [k + 8 for k in range(1, 64)]
    assert res.latencies[63] == 77
    assert (res.row_hits, res.row_empty, res.row_conflicts) == (62, 2, 0)
    assert res.end_cycle == 77 and res.total_cycles == 78
    assert_clean(res)


def test_single_bank_row_stream_bandwidth() -> None:
    # 64 reads of one row of one bank: ACT@0, RD@4, then one per tccd_l = 2 cycles: r_k @ 4 + 2k
    # last RD @ 4 + 126 = 130, data 136, total_cycles 137, 2048 B -> 2048/137 GB/s (< 240 = no refresh)
    reqs = [(0, False, 0, 0, 3, c) for c in range(64)]
    for policy in ("fcfs", "frfcfs"):
        res = simulate(reqs, P0, policy)
        assert res.issue_cycles == [4 + 2 * k for k in range(64)]
        assert res.total_cycles == 137
        assert (res.row_hits, res.row_empty, res.row_conflicts) == (63, 1, 0)
        assert res.row_hit_rate == pytest.approx(63 / 64)
        assert res.bandwidth_gb_s == pytest.approx(2048 / 137)
        assert res.peak_bandwidth_gb_s == pytest.approx(32.0)  # 32 B per burst(1) cycle at 1 GHz
        assert res.efficiency == pytest.approx((2048 / 137) / 32.0)
        assert_clean(res)


def test_frfcfs_serves_hits_before_precharging_but_fcfs_does_not() -> None:
    # r0 row A, r1 row B (older than r2), r2 row A: all same bank, arrive at 0.
    # FR-FCFS: RD r0@4, RD r2@6 (tccd_l 2; a hit, passes r1), PRE@9 (tras), ACT@13, RD r1@17.
    # FCFS:    RD r0@4, PRE@9, ACT@13, RD r1@17, PRE@22 (ACT@13 + tras 9), ACT@26 (22+4 = ACT+trc 26),
    #          RD r2@30.
    reqs = [(0, False, 0, 0, 1, 0), (0, False, 0, 0, 2, 0), (0, False, 0, 0, 1, 1)]
    fr = simulate(reqs, P0, "frfcfs")
    assert fr.issue_cycles == [4, 17, 6]
    assert (fr.row_hits, fr.row_empty, fr.row_conflicts) == (1, 1, 1)
    assert cmds(fr, PRE) == [9]
    assert_clean(fr)
    fc = simulate(reqs, P0, "fcfs")
    assert fc.issue_cycles == [4, 17, 30]
    assert (fc.row_hits, fc.row_empty, fc.row_conflicts) == (0, 1, 2)
    assert cmds(fc, PRE) == [9, 22]
    assert_clean(fc)


def test_page_policy_open_vs_close() -> None:
    # r0 (row 1) at 0, r1 (row 2, same bank) at 50.
    # open : r1 finds row 1 open: PRE@50, ACT@54, RD@58, data 64 -> latency 14, a row conflict
    # close: r0's bank is precharged in the background at 9 (tras 9 from ACT@0, RD@4 + trtp 6 earlier);
    #        r1: ACT@50, RD@54, data 60 -> latency 10, a row empty
    reqs = [(0, False, 0, 0, 1, 0), (50, False, 0, 0, 2, 0)]
    op = simulate(reqs, P0, "frfcfs", page="open")
    assert op.issue_cycles == [4, 58] and op.latencies == [10, 14]
    assert (op.row_empty, op.row_conflicts) == (1, 1) and cmds(op, PRE) == [50]
    assert_clean(op)
    for policy in ("fcfs", "frfcfs"):
        cl = simulate(reqs, P0, policy, page="close")
        assert cmds(cl, PRE) == [9]
        assert cl.issue_cycles == [4, 54] and cl.latencies == [10, 10]
        assert (cl.row_empty, cl.row_conflicts) == (2, 0)
        assert_clean(cl)


def test_idle_refresh_hand_computed() -> None:
    # r0 at 0 leaves bank (0,0) open (ACT@0, RD@4). At 240 one refresh is owed and the queue is
    # idle: PREA@240 (tras/trtp fine), REF_AB@244 (PREA + trp 4). Then one per trefi at 480, 720,
    # ..., 4800 (owed again, banks closed: REF at the owed instant): REF count = 1 + 19 = 20.
    # r1 at 5000: ACT@5000 (> 4800 + trfc 24), RD@5004.
    reqs = [(0, False, 0, 0, 1, 0), (5000, False, 0, 0, 2, 0)]
    res = simulate(reqs, P0, "fcfs", refresh=True)
    assert cmds(res, PREA) == [240]
    assert cmds(res, REF_AB) == [244] + [480 + 240 * i for i in range(19)]
    assert res.refreshes == 20
    assert res.issue_cycles == [4, 5004]
    assert (res.row_empty, res.row_conflicts) == (2, 0)  # the refresh closed the row first
    assert_clean(res)  # includes the refresh deadline at the end
    # without refresh nothing is issued in the gap -- and the checker then flags the deadline
    nr = simulate(reqs, P0, "fcfs", refresh=False)
    assert nr.refreshes == 0 and cmds(nr, PRE) == [5000] and nr.issue_cycles == [4, 5008]
    assert nr.check().rules() == {"refresh_deadline"}


def test_refresh_postponed_under_load_but_deadline_met() -> None:
    # a long saturated stream (hits to rows spread over banks) keeps the queue busy; refreshes are
    # postponed up to max_postpone 3 and then forced; the deadline (1036) must still be met.
    rng = random.Random(21)
    reqs = [(0, False, rng.randrange(4), rng.randrange(4), rng.randrange(2), rng.randrange(64))
            for _ in range(900)]
    res = simulate(reqs, P0, "frfcfs", queue_depth=16)
    assert res.total_cycles > 3 * 240
    assert res.refreshes >= res.end_cycle // 240 - P0.max_postpone - 1
    assert res.refreshes >= 1
    assert_clean(res)


def test_empty_and_validation() -> None:
    res = simulate([], P0)
    assert res.total_cycles == 0 and res.latencies == [] and res.bandwidth_gb_s == 0.0
    with pytest.raises(ValueError):
        simulate([], P0, policy="lifo")
    with pytest.raises(ValueError):
        simulate([], P0, page="half")
    with pytest.raises(ValueError):
        simulate([], P0, queue_depth=0)


def test_summary_carries_status() -> None:
    res = simulate([(0, False, 0, 0, 1, 0)], P0)
    s = res.summary()
    assert s["status"] == "HYPOTHETICAL_SIM" and s["requests"] == 1
    assert s["latency"]["count"] == 1


# ---------------------------------------------------------------------------
# Randomised legality / ordering properties over every profile and policy
# ---------------------------------------------------------------------------

def random_requests(seed: int, n: int, span: int, write_frac: float = 0.4) -> list:
    rng = random.Random(seed)
    hot_rows = [rng.randrange(1 << 15) for _ in range(3)]
    out = []
    for _ in range(n):
        out.append((
            rng.randrange(span + 1), rng.random() < write_frac,
            rng.randrange(4), rng.randrange(4), rng.choice(hot_rows), rng.randrange(8),
        ))
    return out


def check_properties(reqs: list, res: SimResult) -> None:
    n = len(reqs)
    # every request issued exactly once (one RD/WR command each) and counted exactly once
    assert len(res.latencies) == n and len(res.issue_cycles) == n
    assert sum(1 for c in res.commands if c[2] in (RD, WR)) == n
    assert res.row_hits + res.row_empty + res.row_conflicts == n
    assert sum(1 for c in res.commands if c[2] == WR) == sum(1 for r in reqs if r[1])
    # one command per cycle
    cycles = [c[0] for c in res.commands]
    assert len(cycles) == len(set(cycles)) and cycles == sorted(cycles)
    # causality
    for (arr, *_), lat, iss in zip(reqs, res.latencies, res.issue_cycles):
        assert iss >= arr and lat > 0
    # acceptance order is kept for same granule (a write involved) and for the same bank + row
    order = sorted(range(n), key=lambda i: (reqs[i][0], i))
    for a in range(n):
        for b in range(a + 1, n):
            i, j = order[a], order[b]
            ri, rj = reqs[i], reqs[j]
            same_bank_row = ri[2:5] == rj[2:5]
            same_granule = same_bank_row and ri[5] == rj[5]
            if same_bank_row or (same_granule and (ri[1] or rj[1])):
                assert res.issue_cycles[i] < res.issue_cycles[j], (i, j)
    assert res.bytes_moved == 32 * n
    assert res.row_hit_rate == res.row_hits / n


@pytest.mark.parametrize("prof", [P0, P1, P2], ids=lambda p: p.name)
@pytest.mark.parametrize("policy", ["fcfs", "frfcfs"])
@pytest.mark.parametrize("page", ["open", "close"])
@pytest.mark.parametrize("refresh", [True, False])
def test_random_streams_never_violate_timing(prof, policy: str, page: str, refresh: bool) -> None:
    # refresh=False runs are kept shorter than the refresh deadline bound of the profile
    span = 3 * prof.trefi if refresh else prof.refresh_deadline // 4
    n = 250 if refresh else 120
    seed = 100 * prof.id + 10 * (policy == "frfcfs") + 4 * (page == "close") + int(refresh)  # deterministic
    reqs = random_requests(seed=seed, n=n, span=span)
    res = simulate(reqs, prof, policy, queue_depth=8, page=page, refresh=refresh)
    check_properties(reqs, res)
    assert_clean(res)


@pytest.mark.parametrize("prof", [P0, P1, P2], ids=lambda p: p.name)
def test_burst_arrivals_keep_queue_full_and_stay_legal(prof) -> None:
    reqs = random_requests(seed=5 + prof.id, n=400, span=0, write_frac=0.5)  # everything at cycle 0
    for policy in ("fcfs", "frfcfs"):
        res = simulate(reqs, prof, policy, queue_depth=16)
        check_properties(reqs, res)
        assert_clean(res)


def test_frfcfs_not_slower_than_fcfs_on_random_traffic() -> None:
    reqs = random_requests(seed=77, n=300, span=0)
    fc = simulate(reqs, P0, "fcfs", refresh=False)
    fr = simulate(reqs, P0, "frfcfs", refresh=False)
    assert fr.total_cycles <= fc.total_cycles
    assert fr.row_hit_rate >= fc.row_hit_rate


def test_queue_depth_one_makes_policies_identical() -> None:
    reqs = random_requests(seed=3, n=200, span=1500)
    a = simulate(reqs, P0, "fcfs", queue_depth=1)
    b = simulate(reqs, P0, "frfcfs", queue_depth=1)
    assert a.issue_cycles == b.issue_cycles and a.commands == b.commands
