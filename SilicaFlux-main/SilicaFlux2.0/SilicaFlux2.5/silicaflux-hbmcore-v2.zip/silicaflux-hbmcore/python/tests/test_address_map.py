"""Address-map tests. Expected values are hand-computed from docs/ADDRESS_MAP.md."""

from __future__ import annotations

import random

import pytest

from hbm4.address_map import (
    MAP_BANK_AWARE, MAP_CH_IL, MAP_LINEAR, AddrMapCfg, Loc, check_addr, map_addr, pc_index,
    unmap_loc,
)

MODES = (MAP_LINEAR, MAP_CH_IL, MAP_BANK_AWARE)

# NUM_CHANNELS = 4 default-geometry config used by the doc's worked example
CFG4 = AddrMapCfg(num_channels=4)


# ---------------------------------------------------------------------------
# The worked example of ADDRESS_MAP.md (must be reproduced exactly)
# ---------------------------------------------------------------------------

def test_worked_example_capacity() -> None:
    # PC(1) CH(2) COL(6) BA(2) BG(2) ROW(15) = 28 granule bits, +5 offset = 33 bits = 8 GiB
    assert CFG4.cap_bits == 33
    assert (1 << CFG4.cap_bits) == 8 * 2**30


@pytest.mark.parametrize(
    "addr, pc, ch",
    [
        (0x60, 1, 1),  # granule 3 = 0b11 -> pc = 1 (bit 0), ch = 1 (bits 2:1 = 0b01)
        (0x20, 1, 0),  # granule 1 = 0b01 -> pc = 1, ch = 0
        (0x40, 0, 1),  # granule 2 = 0b10 -> pc = 0, ch = 1
        (0x00, 0, 0),
    ],
)
def test_worked_example(addr: int, pc: int, ch: int) -> None:
    loc = map_addr(addr, CFG4, MAP_CH_IL, il=0, hash=False)
    assert loc == Loc(stack=0, ch=ch, pc=pc, bg=0, ba=0, row=0, col=0)
    assert unmap_loc(loc, CFG4, MAP_CH_IL, il=0, hash=False) == addr


# ---------------------------------------------------------------------------
# Hand-computed field placement, one fixed location, all three modes
# Loc: stack 0, ch 3, pc 1, bg 1, ba 2, row 0x1234, col 5   (NUM_CHANNELS = 4)
# ---------------------------------------------------------------------------

LOC = Loc(stack=0, ch=3, pc=1, bg=1, ba=2, row=0x1234, col=5)


def test_linear_hand_computed() -> None:
    # LINEAR: col(6) ba(2) bg(2) row(15) pc(1) ch(2)  from the LSB of the granule address
    # col=5            -> bit 0           =                 5
    # ba=2  << 6       =                                  128
    # bg=1  << 8       =                                  256
    # row=0x1234 << 10 = 4660 * 1024    =            4,771,840
    # pc=1  << 25      =                           33,554,432
    # ch=3  << 26      =                          201,326,592
    # granule = 239,653,253 = 0xE48D185 ;  addr = granule << 5 = 7,668,904,096 = 0x1C91A30A0
    addr = 0x1C91A30A0
    assert addr == 239_653_253 * 32
    assert map_addr(addr, CFG4, MAP_LINEAR) == LOC
    assert unmap_loc(LOC, CFG4, MAP_LINEAR) == addr
    # LINEAR ignores `il`
    assert map_addr(addr, CFG4, MAP_LINEAR, il=3) == LOC


def test_ch_il_il0_hand_computed() -> None:
    # CH_IL il=0: pc(1) ch(2) col(6) ba(2) bg(2) row(15)
    # pc=1 -> 1;  ch=3 << 1 -> 6;  col=5 << 3 -> 40;  ba=2 << 9 -> 1024;  bg=1 << 11 -> 2048
    # row=0x1234 << 13 = 38,174,720;   granule = 38,174,720 + 3,119 = 38,177,839 = 0x2468C2F
    # addr = granule * 32 = 1,221,690,848 = 0x48D185E0
    addr = 0x48D185E0
    assert addr == 38_177_839 * 32
    assert map_addr(addr, CFG4, MAP_CH_IL, il=0) == LOC
    assert unmap_loc(LOC, CFG4, MAP_CH_IL, il=0) == addr


def test_ch_il_il3_hand_computed() -> None:
    # il=3, col=45=0b101101 -> col_lo = 0b101 = 5, col_hi = 0b101 = 5
    # order: col_lo(3) pc(1) ch(2) col_hi(3) ba(2) bg(2) row(15)
    # col_lo=5 -> 5;  pc=1 << 3 -> 8;  ch=3 << 4 -> 48;  col_hi=5 << 6 -> 320;
    # ba=2 << 9 -> 1024;  bg=1 << 11 -> 2048;  row << 13 = 38,174,720
    # granule = 38,174,720 + 3,453 = 38,178,173 ;  addr = *32 = 1,221,701,536 = 0x48D1AFA0
    loc = Loc(0, 3, 1, 1, 2, 0x1234, 45)
    addr = 0x48D1AFA0
    assert addr == 38_178_173 * 32
    assert map_addr(addr, CFG4, MAP_CH_IL, il=3) == loc
    assert unmap_loc(loc, CFG4, MAP_CH_IL, il=3) == addr


def test_bank_aware_il3_hand_computed() -> None:
    # BANK_AWARE il=3, col=45 (lo=5, hi=5): col_lo(3) pc(1) ch(2) bg(2) ba(2) col_hi(3) row(15)
    # col_lo=5 -> 5;  pc=1 << 3 -> 8;  ch=3 << 4 -> 48;  bg=1 << 6 -> 64;  ba=2 << 8 -> 512;
    # col_hi=5 << 10 -> 5120;  row << 13 = 38,174,720
    # granule = 38,174,720 + 5,757 = 38,180,477 ;  addr = *32 = 1,221,775,264 = 0x48D2CFA0
    loc = Loc(0, 3, 1, 1, 2, 0x1234, 45)
    addr = 0x48D2CFA0
    assert addr == 38_180_477 * 32
    assert map_addr(addr, CFG4, MAP_BANK_AWARE, il=3) == loc
    assert unmap_loc(loc, CFG4, MAP_BANK_AWARE, il=3) == addr


def test_hash_hand_computed_1() -> None:
    # raw CH_IL il=0 address 0x48D185E0: pc=1 ch=3 col=5 ba=2 bg=1 row=0x1234
    # row[1:0]   = 0x1234 & 3          = 0 -> bg = 1 ^ 0 = 1
    # row[3:2]   = (0x1234 >> 2) & 3   = 0x48D & 3 = 1 -> ba = 2 ^ 1 = 3
    # (row >> 4) & (2^CH-1) = 0x123 & 3 = 3 -> ch = 3 ^ 3 = 0
    assert map_addr(0x48D185E0, CFG4, MAP_CH_IL, il=0, hash=True) == Loc(0, 0, 1, 1, 3, 0x1234, 5)
    assert unmap_loc(Loc(0, 0, 1, 1, 3, 0x1234, 5), CFG4, MAP_CH_IL, il=0, hash=True) == 0x48D185E0


def test_hash_hand_computed_2() -> None:
    # raw CH_IL il=0: pc=0 ch=2 col=0 ba=0 bg=0 row=7
    # granule = ch 2 << 1 = 4  +  7 << 13 = 57,344  = 57,348 = 0xE004 ; addr = 0xE004 << 5 = 0x1C0080
    # row = 0b111: row[1:0] = 3 -> bg = 0 ^ 3 = 3 ; row[3:2] = 1 -> ba = 0 ^ 1 = 1 ;
    # (row >> 4) & 3 = 0 -> ch = 2
    addr = 0x1C0080
    assert addr == 57_348 * 32
    assert map_addr(addr, CFG4, MAP_CH_IL, il=0, hash=False) == Loc(0, 2, 0, 0, 0, 7, 0)
    assert map_addr(addr, CFG4, MAP_CH_IL, il=0, hash=True) == Loc(0, 2, 0, 3, 1, 7, 0)


def test_hash_does_not_touch_ch_when_single_channel() -> None:
    cfg = AddrMapCfg(num_channels=1)  # CH = 0 -> "only if CH > 0"
    # CH_IL il=0: pc(1) col(6) ba(2) bg(2) row(15): row=0x3F -> bg ^= 3, ba ^= (0x3F>>2)&3 = 3
    # granule = 0x3F << 9 ... (pc 1 + col 6 = 7 bits?) -> pc(1) col(6) ba(2) bg(2) = 11 bits
    g = 0x3F << 11
    loc = map_addr(g << 5, cfg, MAP_CH_IL, il=0, hash=True)
    assert loc == Loc(0, 0, 0, 3, 3, 0x3F, 0)


def test_pc_index() -> None:
    cfg = AddrMapCfg()
    # ((stack * 32) + ch) * 2 + pc
    assert pc_index(Loc(0, 5, 1, 0, 0, 0, 0), cfg) == (0 * 32 + 5) * 2 + 1 == 11
    cfg2 = AddrMapCfg(num_stacks=2)
    assert pc_index(Loc(1, 3, 0, 0, 0, 0, 0), cfg2) == (1 * 32 + 3) * 2 + 0 == 70
    assert pc_index(Loc(0, 0, 0, 0, 0, 0, 0), cfg2) == 0


# ---------------------------------------------------------------------------
# check_addr
# ---------------------------------------------------------------------------

def test_check_addr_default_geometry() -> None:
    cfg = AddrMapCfg()
    # capacity = 2^(5+6+2+2+15+1+5+0) = 2^36
    assert cfg.cap_bits == 36
    assert check_addr(0x0, cfg) == 0
    assert check_addr(0x20, cfg) == 0
    assert check_addr(0x21, cfg) == 1  # addr[4:0] != 0
    assert check_addr(0x1F, cfg) == 1
    assert check_addr((1 << 36) - 32, cfg) == 0  # highest valid granule
    assert check_addr(1 << 36, cfg) == 2
    assert check_addr((1 << 36) | 0x3, cfg) == 2  # both: RANGE wins
    assert check_addr((1 << 39) | 0x20, cfg) == 2


def test_check_addr_four_channels() -> None:
    assert check_addr((1 << 33) - 32, CFG4) == 0
    assert check_addr(1 << 33, CFG4) == 2
    assert check_addr((1 << 33) + 1, CFG4) == 2


def test_cfg_rejects_non_power_of_two() -> None:
    with pytest.raises(ValueError):
        AddrMapCfg(num_channels=3)
    with pytest.raises(ValueError):
        map_addr(0, CFG4, MAP_CH_IL, il=7)  # il > COL
    with pytest.raises(ValueError):
        map_addr(0, CFG4, 9)


# ---------------------------------------------------------------------------
# Structure oracle written independently from address_map.py: string slicing
# ---------------------------------------------------------------------------

ORDER = {
    MAP_LINEAR: "col ba bg row pc ch stack",
    MAP_CH_IL: "col_lo pc ch stack col_hi ba bg row",
    MAP_BANK_AWARE: "col_lo pc ch stack bg ba col_hi row",
}


def oracle_map(addr: int, cfg: AddrMapCfg, mode: int, il: int, do_hash: bool) -> Loc:
    widths = {
        "col": cfg.col, "col_lo": il, "col_hi": cfg.col - il, "ba": cfg.ba, "bg": cfg.bg,
        "row": cfg.row, "pc": (cfg.pcs - 1).bit_length(),
        "ch": (cfg.num_channels - 1).bit_length(), "stack": (cfg.num_stacks - 1).bit_length(),
    }
    names = ORDER[mode].split()
    total = sum(widths[n] for n in names)
    g = (addr >> cfg.off) & ((1 << total) - 1)
    bits = format(g, f"0{total}b") if total else ""
    pos = len(bits)  # slice from the right (LSB first)
    f: dict[str, int] = {}
    for n in names:
        w = widths[n]
        f[n] = int(bits[pos - w:pos], 2) if w else 0
        pos -= w
    col = f["col"] if mode == MAP_LINEAR else f["col_lo"] + f["col_hi"] * (2 ** il)
    bg, ba, ch, row = f["bg"], f["ba"], f["ch"], f["row"]
    if do_hash:
        bg = bg ^ (row % (2 ** cfg.bg))
        ba = ba ^ ((row // (2 ** cfg.bg)) % (2 ** cfg.ba))
        if widths["ch"] > 0:
            ch = ch ^ ((row // (2 ** (cfg.bg + cfg.ba))) % (2 ** widths["ch"]))
    return Loc(f["stack"], ch, f["pc"], bg, ba, row, col)


def _rand_aligned(rng: random.Random, cfg: AddrMapCfg) -> int:
    return rng.randrange(1 << (cfg.cap_bits - cfg.off)) << cfg.off


@pytest.mark.parametrize("do_hash", [False, True])
@pytest.mark.parametrize("mode", MODES)
def test_random_default_geometry_roundtrip_and_oracle(mode: int, do_hash: bool) -> None:
    cfg = AddrMapCfg()
    rng = random.Random(1000 + mode * 2 + int(do_hash))
    for il in (0, 1, 3, 6):
        for _ in range(400):
            addr = _rand_aligned(rng, cfg)
            loc = map_addr(addr, cfg, mode, il=il, hash=do_hash)
            assert loc == oracle_map(addr, cfg, mode, il, do_hash)
            assert unmap_loc(loc, cfg, mode, il=il, hash=do_hash) == addr
            # field ranges
            assert 0 <= loc.ch < 32 and loc.pc in (0, 1) and loc.stack == 0
            assert 0 <= loc.bg < 4 and 0 <= loc.ba < 4 and 0 <= loc.row < 2**15 and 0 <= loc.col < 64


def test_random_roundtrip_other_geometries() -> None:
    rng = random.Random(7)
    for nch in (1, 2, 4, 8, 32):
        for nst in (1, 2):
            cfg = AddrMapCfg(num_stacks=nst, num_channels=nch)
            for mode in MODES:
                for do_hash in (False, True):
                    for _ in range(60):
                        il = rng.randrange(cfg.col + 1)
                        addr = _rand_aligned(rng, cfg)
                        loc = map_addr(addr, cfg, mode, il=il, hash=do_hash)
                        assert unmap_loc(loc, cfg, mode, il=il, hash=do_hash) == addr


# reduced geometry: 2 stacks x 2 channels x 2 pcs, OFF=2 COL=2 BA=1 BG=1 ROW=3
#   capacity bits = 2 + 2 + 1 + 1 + 3 + 1(pc) + 1(ch) + 1(stack) = 12 -> 1024 granules
SMALL = AddrMapCfg(num_stacks=2, num_channels=2, pcs=2, off=2, col=2, ba=1, bg=1, row=3)


@pytest.mark.parametrize("do_hash", [False, True])
@pytest.mark.parametrize("mode", MODES)
def test_exhaustive_small_geometry_bijection(mode: int, do_hash: bool) -> None:
    assert SMALL.cap_bits == 12
    n_granules = 1 << (SMALL.cap_bits - SMALL.off)
    assert n_granules == 1024
    # number of distinct locations = 2*2*2 (stack,ch,pc) * 2*2 (bg,ba) * 8 (row) * 4 (col) = 1024
    for il in range(SMALL.col + 1):
        seen: set[Loc] = set()
        for g in range(n_granules):
            addr = g << SMALL.off
            loc = map_addr(addr, SMALL, mode, il=il, hash=do_hash)
            assert loc == oracle_map(addr, SMALL, mode, il, do_hash)
            assert unmap_loc(loc, SMALL, mode, il=il, hash=do_hash) == addr
            seen.add(loc)
        assert len(seen) == n_granules  # injective => bijective onto the location space
        for loc in seen:
            assert loc.stack < 2 and loc.ch < 2 and loc.pc < 2 and loc.bg < 2 and loc.ba < 2
            assert loc.row < 8 and loc.col < 4


def test_hash_changes_bank_but_not_row_or_pc() -> None:
    cfg = SMALL
    differing = 0
    for g in range(1 << (cfg.cap_bits - cfg.off)):
        a = g << cfg.off
        plain = map_addr(a, cfg, MAP_CH_IL, il=0, hash=False)
        hashed = map_addr(a, cfg, MAP_CH_IL, il=0, hash=True)
        assert (plain.row, plain.pc, plain.col, plain.stack) == (hashed.row, hashed.pc, hashed.col, hashed.stack)
        differing += plain != hashed
    assert differing > 0
