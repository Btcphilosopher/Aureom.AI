"""Reference memory + SECDED tests (docs/RAS_CODE.md, docs/ORDERING.md)."""

from __future__ import annotations

import random

import pytest

from hbm4.reference_memory import (
    FULL_BYTE_MASK, FULL_DATA_MASK, RefMemory, pos, secded_decode, secded_encode,
)


# ---------------------------------------------------------------------------
# RefMemory
# ---------------------------------------------------------------------------

def bytes_to_int(bs: list[int]) -> int:
    """byte i of the granule occupies bits [8i+7:8i]"""
    assert len(bs) == 32
    return sum(b << (8 * i) for i, b in enumerate(bs))


def test_unwritten_reads_zero() -> None:
    m = RefMemory()
    assert m.read(0) == 0
    assert m.read(0x1234560) == 0
    assert len(m) == 0


def test_full_write_then_read() -> None:
    m = RefMemory()
    data = bytes_to_int(list(range(1, 33)))
    m.write(0x40, data, FULL_BYTE_MASK)
    assert m.read(0x40) == data
    assert m.read(0x20) == 0 and m.read(0x60) == 0  # neighbours untouched
    assert m.read(0x5F) == data  # any byte address inside the granule 0x40..0x5f


def test_masked_write_only_changes_enabled_bytes() -> None:
    m = RefMemory()
    m.write(0x100, bytes_to_int([0x11] * 32))
    # enable bytes 0 and 2 (mask 0b101 = 0x5) and byte 31 (bit 31)
    m.write(0x100, bytes_to_int([0x22] * 32), 0x80000005)
    expected = [0x22, 0x11, 0x22] + [0x11] * 28 + [0x22]
    assert m.read(0x100) == bytes_to_int(expected)


def test_zero_mask_write_is_noop_and_byte_accurate_merge() -> None:
    m = RefMemory()
    m.write(0x0, bytes_to_int([0xAA] * 32), 0)
    assert m.read(0) == 0
    m.write(0x0, 0xFF, 0x1)  # byte 0 := 0xFF
    m.write(0x0, 0xEE << 8, 0x2)  # byte 1 := 0xEE
    m.write(0x0, 0xDD << 8, 0x1)  # byte 0 enabled, data byte 0 is 0x00 -> byte 0 := 0
    assert m.read(0) == 0xEE << 8


def test_random_masked_writes_match_bytewise_model() -> None:
    rng = random.Random(5)
    m = RefMemory()
    model: dict[int, list[int]] = {}
    for _ in range(2000):
        g = rng.randrange(8)
        addr = g * 32
        data = [rng.randrange(256) for _ in range(32)]
        mask = rng.getrandbits(32)
        cur = model.setdefault(g, [0] * 32)
        for i in range(32):
            if (mask >> i) & 1:
                cur[i] = data[i]
        m.write(addr, bytes_to_int(data), mask)
        for gg, bs in model.items():
            assert m.read(gg * 32) == bytes_to_int(bs)


# ---------------------------------------------------------------------------
# SECDED
# ---------------------------------------------------------------------------

def test_hamming_positions() -> None:
    # positions 1,2,3,... that are not powers of two: 3,5,6,7,9,10,11,12,13,14,15,17,...
    assert [pos(d) for d in range(5)] == [3, 5, 6, 7, 9]
    assert [pos(d) for d in range(5, 12)] == [10, 11, 12, 13, 14, 15, 17]
    # 265 positions in total hold 9 powers of two (1..256) + 256 data bits
    assert pos(255) == 265
    assert len({pos(d) for d in range(256)}) == 256
    assert all(p & (p - 1) for p in (pos(d) for d in range(256)))


def test_all_zero_is_valid_codeword() -> None:
    assert secded_encode(0) == 0
    assert secded_decode(0, 0) == (0, 0, 0, 0)


@pytest.mark.parametrize(
    "d, ecc",
    [
        # d=0: pos=3=0b11 -> check bits 0,1 -> 0b11 = 3 ; overall = data(1) ^ parity(0b11)=0 -> 1 -> bit 9
        (0, 0x203),
        # d=1: pos=5=0b101 -> checks 0b101; parity(0b101) = 0; overall = 1 -> 0x200 | 5
        (1, 0x205),
        # d=2: pos=6=0b110 -> checks 0b110; parity 0; overall = 1 -> 0x200 | 6
        (2, 0x206),
        # d=3: pos=7=0b111 -> checks 0b111; parity(0b111) = 1; overall = 1 ^ 1 = 0
        (3, 0x007),
        # d=4: pos=9=0b1001 -> checks 0b1001; parity 0; overall = 1
        (4, 0x209),
        # d=255: pos=265=0b1_0000_1001 -> checks bits 0,3,8 = 0x109; parity = 1; overall = 1 ^ 1 = 0
        (255, 0x109),
    ],
)
def test_encode_single_data_bit_hand_computed(d: int, ecc: int) -> None:
    assert secded_encode(1 << d) == ecc


def _slow_encode(data: int) -> int:
    """Bit-by-bit transcription of RAS_CODE.md "Construction" (independent of reference_memory)."""
    positions: list[int] = []
    p = 1
    while len(positions) < 256:
        if p & (p - 1) != 0:
            positions.append(p)
        p += 1
    checks = [0] * 9
    overall = 0
    for d in range(256):
        bit = (data >> d) & 1
        overall ^= bit
        for i in range(9):
            if (positions[d] >> i) & 1:
                checks[i] ^= bit
    for i in range(9):
        overall ^= checks[i]
    return sum(c << i for i, c in enumerate(checks)) | (overall << 9)


def test_encode_matches_slow_transcription_and_is_linear() -> None:
    rng = random.Random(99)
    for _ in range(100):
        a, b = rng.getrandbits(256), rng.getrandbits(256)
        assert secded_encode(a) == _slow_encode(a)
        assert secded_encode(a ^ b) == secded_encode(a) ^ secded_encode(b)
    assert secded_encode(FULL_DATA_MASK) == _slow_encode(FULL_DATA_MASK)


def test_clean_codewords_decode_clean() -> None:
    rng = random.Random(3)
    for _ in range(200):
        d = rng.getrandbits(256)
        out, ce, ue, syn = secded_decode(d, secded_encode(d))
        assert (out, ce, ue, syn) == (d, 0, 0, 0)


def test_every_single_bit_flip_is_corrected() -> None:
    """All 256 data bits + all 10 check bits, for several data patterns."""
    rng = random.Random(11)
    for data in (0, FULL_DATA_MASK, rng.getrandbits(256), rng.getrandbits(256)):
        ecc = secded_encode(data)
        for d in range(256):
            out, ce, ue, syn = secded_decode(data ^ (1 << d), ecc)
            assert (out, ce, ue) == (data, 1, 0), f"data bit {d}"
            assert syn == pos(d)  # syndrome points at the Hamming position
        for c in range(10):
            out, ce, ue, syn = secded_decode(data, ecc ^ (1 << c))
            assert (out, ce, ue) == (data, 1, 0), f"check bit {c}"
            # check bit i flipped -> syn = 2^i ; overall parity bit -> syn = 0
            assert syn == (1 << c if c < 9 else 0)


def test_random_double_bit_flips_are_uncorrectable() -> None:
    rng = random.Random(2024)
    for _ in range(4000):
        data = rng.getrandbits(256)
        ecc = secded_encode(data)
        a, b = rng.sample(range(266), 2)  # 256 data bits then 10 check bits

        def flip(d: int, e: int, k: int) -> tuple[int, int]:
            return (d ^ (1 << k), e) if k < 256 else (d, e ^ (1 << (k - 256)))

        d1, e1 = flip(data, ecc, a)
        d2, e2 = flip(d1, e1, b)
        out, ce, ue, syn = secded_decode(d2, e2)
        assert ue == 1 and ce == 0
        assert out == d2  # uncorrected data is returned as read


def test_syndrome_past_the_code_is_uncorrectable() -> None:
    """syn is not a power of two and not a data position (> 265) with odd parity.

    Flip check bits 8, 3 and 1: syn = 256 ^ 8 ^ 2 = 266 (> pos(255) = 265), and three
    flips give op = 1, so the table's last single-error row applies: uncorrectable.
    """
    data = 0x1234_5678
    ecc = secded_encode(data)
    bad = ecc ^ (1 << 8) ^ (1 << 3) ^ (1 << 1)
    out, ce, ue, syn = secded_decode(data, bad)
    assert syn == 266 and ue == 1 and ce == 0 and out == data
