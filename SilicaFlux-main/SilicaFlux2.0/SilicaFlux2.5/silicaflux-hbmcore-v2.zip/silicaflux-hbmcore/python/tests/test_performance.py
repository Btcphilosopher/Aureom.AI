"""Performance-arithmetic tests (decimal GB/s)."""

from __future__ import annotations

import pytest

from hbm4.performance import (
    bandwidth_gb_s, efficiency, percentile, pin_bandwidth_gb_s, summarize,
)


def test_pin_bandwidth_reference_calculation() -> None:
    # 2048 pins * 8 Gb/s / 8 = 2048 GB/s = 2.048 TB/s (decimal)
    gb_s = pin_bandwidth_gb_s(2048, 8)
    assert gb_s == 2048.0
    assert gb_s / 1000.0 == 2.048


def test_bandwidth_from_bytes_and_cycles() -> None:
    # 32 B per cycle at 1000 MHz = 32e9 B/s = 32 GB/s
    assert bandwidth_gb_s(32 * 1000, 1000, 1000) == pytest.approx(32.0)
    # 64 pseudo-channels * 32 B/cycle at 1 GHz = 2048 GB/s == the pin-rate figure
    assert 64 * bandwidth_gb_s(32 * 10, 10, 1000) == pytest.approx(pin_bandwidth_gb_s(2048, 8))
    # 2048 bytes in 137 cycles at 1000 MHz = 2048 / 137 GB/s
    assert bandwidth_gb_s(2048, 137, 1000) == pytest.approx(2048 / 137)
    # decimal, not binary: 1e9 bytes in 1e9 cycles at 1000 MHz (1 s) is exactly 1 GB/s
    assert bandwidth_gb_s(10**9, 10**9, 1000) == pytest.approx(1.0)
    # clock scaling: same bytes/cycles at 500 MHz is half the bandwidth
    assert bandwidth_gb_s(3200, 100, 500) == pytest.approx(16.0)
    with pytest.raises(ValueError):
        bandwidth_gb_s(1, 0, 1000)


def test_efficiency() -> None:
    assert efficiency(1024.0, 2048.0) == 0.5
    assert efficiency(2048.0, pin_bandwidth_gb_s(2048, 8)) == 1.0
    with pytest.raises(ValueError):
        efficiency(1.0, 0.0)


def test_percentile_nearest_rank() -> None:
    xs = [15, 20, 35, 40, 50]  # classic nearest-rank example, n = 5
    # p30: ceil(0.30*5) = 2 -> 20 ; p40: ceil(2.0) = 2 -> 20 ; p50: ceil(2.5) = 3 -> 35
    # p100: rank 5 -> 50 ; p0 clamps to rank 1 -> 15
    assert percentile(xs, 30) == 20
    assert percentile(xs, 40) == 20
    assert percentile(xs, 50) == 35
    assert percentile(xs, 100) == 50
    assert percentile(xs, 0) == 15
    assert percentile(reversed(xs), 50) == 35  # sorts internally
    ys = list(range(1, 101))  # 1..100: p-th percentile is exactly p
    assert [percentile(ys, p) for p in (1, 50, 95, 99, 100)] == [1, 50, 95, 99, 100]
    # n = 10, p = 70: rank = ceil(7.0) = 7 exactly (binary floating point would give 7.000000000000001)
    assert percentile(range(1, 11), 70) == 7
    assert percentile(range(1, 11), 99.9) == 10
    with pytest.raises(ValueError):
        percentile([], 50)
    with pytest.raises(ValueError):
        percentile([1], 101)


def test_summarize() -> None:
    s = summarize(list(range(1, 101)))
    assert s == {"count": 100, "mean": 50.5, "p50": 50, "p95": 95, "p99": 99, "max": 100}
    assert summarize([7]) == {"count": 1, "mean": 7.0, "p50": 7, "p95": 7, "p99": 7, "max": 7}
    assert summarize([])["count"] == 0
