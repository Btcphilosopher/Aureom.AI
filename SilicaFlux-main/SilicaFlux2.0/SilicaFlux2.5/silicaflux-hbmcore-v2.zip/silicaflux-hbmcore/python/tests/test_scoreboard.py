"""Scoreboard tests incl. negative tests that must each be caught (docs/ORDERING.md)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from hbm4.address_map import AddrMapCfg
from hbm4.scoreboard import check_transactions, load_jsonl
from hbm4.txn_check import main as txn_main

FULL = 0xFFFFFFFF


def d32(byte: int) -> int:
    """256-bit value with every byte == ``byte``."""
    return int.from_bytes(bytes([byte]) * 32, "little")


def req(t: int, src: int, id: int, w: int, addr: int, data: int = 0, mask: int = FULL) -> dict[str, Any]:
    return {"ev": "req", "t": t, "src": src, "id": id, "w": w, "addr": f"0x{addr:x}",
            "mask": f"0x{mask:08x}", "data": f"0x{data:064x}"}


def rsp(t: int, src: int, id: int, w: int, data: int = 0, err: int = 0) -> dict[str, Any]:
    return {"ev": "rsp", "t": t, "src": src, "id": id, "w": w, "err": err, "data": f"0x{data:064x}"}


def kinds(records: list[dict[str, Any]], **kw: Any) -> dict[str, int]:
    return check_transactions(records, **kw).by_kind()


# a clean log: write 0x11.. to 0x40, partial write (bytes 0 and 2 := 0x22), read it back
def clean_log() -> list[dict[str, Any]]:
    expect = int.from_bytes(bytes([0x22, 0x11, 0x22] + [0x11] * 29), "little")
    return [
        req(1, 1, 1, 1, 0x40, d32(0x11)),
        req(2, 1, 2, 1, 0x40, d32(0x22), mask=0x5),
        req(3, 2, 7, 0, 0x40),
        rsp(10, 1, 1, 1),
        rsp(11, 1, 2, 1),
        rsp(12, 2, 7, 0, expect),
    ]


def test_clean_log_passes() -> None:
    rep = check_transactions(clean_log())
    assert rep.ok, rep.format()
    assert (rep.n_req, rep.n_rsp, rep.n_paired, rep.n_read_checked) == (3, 3, 3, 1)


def test_unwritten_memory_reads_zero_and_snapshot_at_acceptance() -> None:
    log = [
        req(1, 1, 1, 0, 0x80),  # read before any write -> zeros
        req(2, 1, 2, 1, 0x80, d32(0x55)),
        rsp(5, 1, 1, 0, 0),
        rsp(6, 1, 2, 1),
    ]
    assert check_transactions(log).ok


def test_read_snapshot_is_taken_at_request_acceptance_not_at_response() -> None:
    # R accepted (t=1) before W (t=2): must return OLD data (0) even if its response comes last
    base = [req(1, 1, 1, 0, 0x80), req(2, 1, 2, 1, 0x80, d32(0x55))]
    good = base + [rsp(5, 1, 2, 1), rsp(6, 1, 1, 0, 0)]
    assert check_transactions(good).ok
    bad = base + [rsp(5, 1, 2, 1), rsp(6, 1, 1, 0, d32(0x55))]
    assert kinds(bad) == {"data_mismatch": 1}
    # and the reverse: a write accepted first IS visible
    raw = [req(1, 1, 2, 1, 0x80, d32(0x55)), req(2, 1, 1, 0, 0x80), rsp(5, 1, 2, 1), rsp(6, 1, 1, 0, d32(0x55))]
    assert check_transactions(raw).ok


def test_cross_id_response_reordering_is_allowed() -> None:
    log = [req(1, 1, 1, 0, 0x40), req(2, 1, 2, 0, 0x80), rsp(5, 1, 2, 0, 0), rsp(6, 1, 1, 0, 0)]
    assert check_transactions(log).ok


# ------------------------- negative tests: each must be caught -------------------------

def test_corrupted_data_byte_is_caught() -> None:
    log = clean_log()
    bad = int(log[-1]["data"], 16) ^ (0x01 << 8 * 5)  # flip one bit of byte 5
    log[-1]["data"] = f"0x{bad:064x}"
    assert kinds(log) == {"data_mismatch": 1}


def test_swapped_src_is_caught() -> None:
    log = [req(1, 1, 5, 0, 0x40), req(2, 2, 6, 0, 0x60),
           rsp(8, 2, 5, 0, 0),  # id 5 belongs to src 1
           rsp(9, 1, 6, 0, 0)]  # id 6 belongs to src 2
    k = kinds(log)
    assert k.get("src_mismatch") == 2 and set(k) == {"src_mismatch"}


def test_duplicate_response_is_caught() -> None:
    log = clean_log() + [rsp(13, 2, 7, 0, int.from_bytes(bytes([0x22, 0x11, 0x22] + [0x11] * 29), "little"))]
    assert kinds(log) == {"duplicate_response": 1}


def test_reordered_same_id_pair_is_caught() -> None:
    # warm-up write by another source, then the same {src,id} twice: a read of 0x40 (-> 0x11..)
    # followed by a write; the two responses are swapped
    log = [req(0, 9, 1, 1, 0x40, d32(0x11)), rsp(1, 9, 1, 1),
           req(2, 3, 9, 0, 0x40),   # older: read -> 0x11
           req(3, 3, 9, 1, 0x60, d32(0x22)),  # newer: write
           rsp(9, 3, 9, 1),         # write response first
           rsp(10, 3, 9, 0, d32(0x11))]
    assert kinds(log) == {"same_id_order_violation": 1}
    # two reads of different data with the same id, answered newest first
    log2 = [req(0, 9, 1, 1, 0x40, d32(0x11)), req(0, 9, 2, 1, 0x60, d32(0x22)), rsp(1, 9, 1, 1), rsp(1, 9, 2, 1),
            req(2, 3, 9, 0, 0x40), req(3, 3, 9, 0, 0x60),
            rsp(9, 3, 9, 0, d32(0x22)), rsp(10, 3, 9, 0, d32(0x11))]
    assert kinds(log2) == {"same_id_order_violation": 1}


def test_lost_response_is_caught() -> None:
    log = clean_log()[:-1]  # drop the read response
    rep = check_transactions(log)
    assert rep.by_kind() == {"lost_response": 1} and not rep.ok


def test_foreign_response_is_caught() -> None:
    log = clean_log() + [rsp(20, 5, 99, 0, 0)]
    assert kinds(log) == {"foreign_response": 1}


def test_response_kind_mismatch_is_caught() -> None:
    log = [req(1, 1, 1, 0, 0x40), rsp(5, 1, 1, 1)]  # write completion for a read
    assert "rsp_kind_mismatch" in kinds(log)


# ------------------------- error handling -------------------------------------------------

def test_misaligned_request_must_answer_misalign_and_not_touch_memory() -> None:
    log = [
        req(1, 1, 1, 1, 0x41, d32(0x77)),  # misaligned write: addr[4:0] != 0
        req(2, 1, 2, 0, 0x40),             # aligned read of the same granule: still zero
        rsp(5, 1, 1, 1, err=1),
        rsp(6, 1, 2, 0, 0),
    ]
    assert check_transactions(log).ok
    # the DUT wrongly stored it: read returns 0x77.. -> caught
    bad = list(log)
    bad[3] = rsp(6, 1, 2, 0, d32(0x77))
    assert kinds(bad) == {"data_mismatch": 1}
    # err NONE for a misaligned request -> caught
    bad2 = list(log)
    bad2[2] = rsp(5, 1, 1, 1, err=0)
    assert kinds(bad2) == {"expected_error_missing": 1}


def test_range_error_default_and_custom_geometry() -> None:
    cap36 = 1 << 36
    log = [req(1, 1, 1, 0, cap36), rsp(5, 1, 1, 0, err=2)]
    assert check_transactions(log).ok  # default geometry: capacity 2^36
    # 4-channel geometry: capacity 2^33, so 1<<34 is out of range and 1<<35 too
    cfg4 = AddrMapCfg(num_channels=4)
    assert check_transactions([req(1, 1, 1, 0, 1 << 34), rsp(5, 1, 1, 0, err=2)], cfg=cfg4).ok
    # misaligned AND out of range: RANGE wins
    assert check_transactions([req(1, 1, 1, 0, cap36 + 1), rsp(5, 1, 1, 0, err=2)]).ok
    assert kinds([req(1, 1, 1, 0, cap36 + 1), rsp(5, 1, 1, 0, err=1)]) == {"wrong_error_code": 1}


def test_unexpected_error_is_caught() -> None:
    log = [req(1, 1, 1, 0, 0x40), rsp(5, 1, 1, 0, err=7)]
    assert kinds(log) == {"unexpected_error": 1}
    # ... unless the caller says it is acceptable (injected flush)
    assert check_transactions(log, allowed_err_codes={7}).ok


def test_ecc_policy_error_for_partial_write() -> None:
    log = [req(1, 1, 1, 1, 0x40, d32(0x11), mask=0x5), rsp(5, 1, 1, 1, err=3)]
    assert check_transactions(log, ecc_enabled=True).ok
    assert kinds(log, ecc_enabled=False) == {"unexpected_error": 1}
    full = [req(1, 1, 1, 1, 0x40, d32(0x11)), rsp(5, 1, 1, 1)]
    assert check_transactions(full, ecc_enabled=True).ok


def test_expected_errors_map_and_predicate_for_ecc_poison() -> None:
    log = [req(1, 1, 1, 1, 0x40, d32(0x11)), req(2, 1, 2, 0, 0x40),
           rsp(5, 1, 1, 1), rsp(6, 1, 2, 0, d32(0x99), err=6)]
    assert kinds(log) == {"unexpected_error": 1}
    assert check_transactions(log, expected_errors={1: {0, 6}}).ok  # request #1 may answer ECC
    assert check_transactions(log, error_predicate=lambda t, n: 6 if not t.write else None).ok
    # an ECC response skips the data comparison (poisoned data), a clean one does not
    log[3] = rsp(6, 1, 2, 0, d32(0x99), err=0)
    assert kinds(log, expected_errors={1: {0, 6}}) == {"data_mismatch": 1}


def test_malformed_records_are_reported() -> None:
    assert "malformed_record" in kinds([{"ev": "zzz"}])
    assert "malformed_record" in kinds([{"ev": "req", "src": 1}])


# ------------------------- JSON-lines + CLI ---------------------------------------------------

def write_jsonl(path: Path, records: list[dict[str, Any]]) -> Path:
    path.write_text("\n".join(json.dumps(r) for r in records) + "\n\n")
    return path


def test_load_jsonl_and_cli(tmp_path: Path, capsys) -> None:
    good = write_jsonl(tmp_path / "good.jsonl", clean_log())
    assert load_jsonl(good) == clean_log()
    out = tmp_path / "rep.json"
    assert txn_main([str(good), "--json", str(out)]) == 0
    assert json.loads(out.read_text())["ok"] is True
    bad_records = clean_log()[:-1]
    bad = write_jsonl(tmp_path / "bad.jsonl", bad_records)
    assert txn_main([str(bad), "--json", str(out)]) == 1
    rep = json.loads(out.read_text())
    assert rep["ok"] is False and rep["by_kind"] == {"lost_response": 1}
    assert txn_main([str(tmp_path / "missing.jsonl")]) == 2
    assert "FAIL" in capsys.readouterr().out
