"""Ordering-rule tests (docs/ORDERING.md guarantees 3, 4, 6)."""

from __future__ import annotations

from hbm4.transactions import (
    ERR_BURST_BND, ERR_BURST_LEN, ERR_ECC, ERR_FLUSHED, ERR_MISALIGN, ERR_NONE, ERR_POLICY,
    ERR_RANGE, ORD_RELAXED, ORD_SRC, ORD_STRICT, Rsp, Txn, must_stay_ordered,
)


def T(src: int = 1, id: int = 1, write: bool = False, addr: int = 0x100, ord: int = ORD_RELAXED) -> Txn:
    return Txn(src=src, id=id, write=write, addr=addr, ord=ord)


def test_constants_match_doc_table() -> None:
    assert (ORD_RELAXED, ORD_SRC, ORD_STRICT) == (0, 1, 2)
    assert (ERR_NONE, ERR_MISALIGN, ERR_RANGE, ERR_POLICY) == (0, 1, 2, 3)
    assert (ERR_BURST_BND, ERR_BURST_LEN, ERR_ECC, ERR_FLUSHED) == (4, 5, 6, 7)


def test_same_granule_with_a_write_is_ordered() -> None:
    # 0x100 and 0x11f are the same 32-byte granule (0x100 >> 5 == 0x11f >> 5 == 8)
    for newer_w, older_w, expect in [(True, False, True), (False, True, True), (True, True, True),
                                     (False, False, False)]:
        a = T(src=1, id=1, write=newer_w, addr=0x100)
        b = T(src=2, id=2, write=older_w, addr=0x11F)
        assert must_stay_ordered(a, b) is expect, (newer_w, older_w)


def test_different_granule_unordered() -> None:
    a = T(src=1, id=1, write=True, addr=0x100)
    b = T(src=2, id=2, write=True, addr=0x120)  # next granule
    assert not must_stay_ordered(a, b)
    assert not must_stay_ordered(b, a)


def test_same_src_id_is_ordered_even_for_reads_to_different_granules() -> None:
    a = T(src=3, id=7, write=False, addr=0x100)
    b = T(src=3, id=7, write=False, addr=0x900)
    assert must_stay_ordered(a, b)
    assert not must_stay_ordered(T(src=3, id=8, addr=0x100), b)  # different id
    assert not must_stay_ordered(T(src=4, id=7, addr=0x100), b)  # different src


def test_ord_src() -> None:
    older = T(src=1, id=1, addr=0x100)
    # newer ORD_SRC, same source, different id/granule: ordered after every older same-source txn
    assert must_stay_ordered(T(src=1, id=2, addr=0x900, ord=ORD_SRC), older)
    # other source: not ordered
    assert not must_stay_ordered(T(src=2, id=2, addr=0x900, ord=ORD_SRC), older)
    # the attribute is on the NEWER transaction only
    assert not must_stay_ordered(T(src=1, id=2, addr=0x900), T(src=1, id=1, addr=0x100, ord=ORD_SRC))


def test_ord_strict_is_a_barrier_on_either_side() -> None:
    a = T(src=1, id=1, addr=0x100)
    b = T(src=2, id=2, addr=0x900)
    assert not must_stay_ordered(a, b)
    assert must_stay_ordered(T(src=1, id=1, addr=0x100, ord=ORD_STRICT), b)  # newer is strict
    assert must_stay_ordered(a, T(src=2, id=2, addr=0x900, ord=ORD_STRICT))  # older is strict


def test_relaxed_unrelated_reads_unordered() -> None:
    assert not must_stay_ordered(T(src=1, id=1, addr=0x100), T(src=2, id=2, addr=0x100))  # two reads


def test_fence_orders_everything() -> None:
    f = Txn(src=9, id=9, write=True, addr=0, fence=True)
    assert must_stay_ordered(T(), f) and must_stay_ordered(f, T())


def test_record_roundtrip() -> None:
    t = Txn(src=2, id=5, write=True, addr=0x40, mask=0x5, data=0xABCD, t=17)
    assert Txn.from_record(t.to_record()) == t
    r = Rsp(src=2, id=5, write=False, err=6, data=0x99, t=30)
    r2 = Rsp.from_record(r.to_record())
    assert (r2.src, r2.id, r2.write, r2.err, r2.data, r2.t) == (2, 5, False, 6, 0x99, 30)
