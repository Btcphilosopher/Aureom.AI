// =============================================================================
//  SILICAFLUX HBMCORE  --  verification/hbm4/hbm4_dram_model.sv
//  *** SIMULATION-ONLY BEHAVIOURAL MODEL.  NOT SYNTHESIZABLE.  NOT A JEDEC-VERIFIED HBM4 DEVICE. ***
//
//  A timing-aware functional model of NUM_PC independent pseudo-channels sitting behind the abstract
//  command interface of sf_hbm_pkg (hbm_cmd_t). Used as the "simulation PHY + DRAM" of every testbench.
//
//  WHAT IT MODELS
//    * per-pseudo-channel, per-bank state: precharged / active, open row
//    * ACT, RD, WR, PRE, PREA, REF_AB, REF_PB, MRS, PDE/PDX, SRE/SRX (abstract commands)
//    * fixed read latency RL, write data exactly WL after the WR command, burst occupancy
//    * SPARSE backing store (associative array keyed by {pc,bg,ba,row,col}) - never allocates
//      the 64 GiB address space; never-written granules read as zero with a valid (all-zero) ECC word
//    * byte-masked writes; 10 sideband ECC bits stored with every granule (see ASSUMPTION below)
//    * refresh DEADLINE tracking per bank (AB and PB), reset by self-refresh exit
//    * activation counters per row-hash bucket (row-hammer research hook, reporting only)
//    * optional random PHY back-pressure (ready_o) and fault injection into the stored data
//
//  INDEPENDENT TIMING CHECKER
//    Every command is judged against the active hbm_timing_t profile by comparing ISSUE TIMESTAMPS
//    (now - last_x >= N). The controller's sf_hbm_timing / sf_hbm_bank_fsm use down-counters instead
//    and share no code with this block, so one implementation bug cannot hide in both. Violations are
//    counted per rule and reported ($error unless viol_quiet_i, used by the deliberately-illegal tests).
//
//  OMITTED JEDEC FEATURES (not modelled): auto-precharge, DBI, CRC/parity generation, on-die ECC,
//  temperature-dependent refresh, mode-register decoding (MRS is accepted and timed only), per-die /
//  stack-ID selection, TSV/PHY analogue behaviour, row-hammer disturbance, command bus partitioning
//  (single abstract bus), power-down variants beyond one PD and one SR state. Behaviour that real
//  HBM4 requires but that is not listed in docs/STANDARDS_MATRIX.md is UNVERIFIED by construction.
//
//  ASSUMPTION (UNVERIFIED for HBM4): a 10-bit sideband ECC word travels with every granule.
//
//  Trace: +HBM_TRACE=<file> writes "cycle pc cmd bg ba row col" for every command (consumed by
//  python/hbm4/trace_check.py, an independent re-implementation of the same rules).
// =============================================================================
`timescale 1ns/1ps
module hbm4_dram_model
  import sf_hbm_pkg::*;
#(
  parameter int unsigned NUM_PC = 1,
  parameter int unsigned READY_LAT   = 1,     // cycles from the scheduler seeing ready_o to the command reaching this model (1 + PHY CMD_LAT)
  parameter int unsigned PC_BASE = 0           // global pseudo-channel number of port 0 (trace labelling)
) (
  input  logic                          clk_i,
  input  logic                          rst_ni,
  input  hbm_timing_t                   tp_i,
  input  logic                          viol_quiet_i,     // count violations without $error
  input  logic [7:0]                    stall_pct_i,      // % of cycles ready_o is low (PHY back-pressure test)

  input  logic [NUM_PC-1:0]             cmd_valid_i,
  input  hbm_cmd_t [NUM_PC-1:0]         cmd_i,
  input  logic [NUM_PC-1:0]             wvalid_i,
  input  hbm_data_t [NUM_PC-1:0]        wdata_i,
  input  hbm_mask_t [NUM_PC-1:0]        wmask_i,
  input  hbm_ecc_t [NUM_PC-1:0]         wecc_i,

  output logic [NUM_PC-1:0]             ready_o,
  output logic [NUM_PC-1:0]             rvalid_o,
  output hbm_data_t [NUM_PC-1:0]        rdata_o,
  output hbm_ecc_t [NUM_PC-1:0]         recc_o,
  output logic [NUM_PC-1:0]             rerr_o,

  output int unsigned                   viol_cnt_o,
  output int unsigned                   cmd_cnt_o
);
  localparam int unsigned NB = HBM_NUM_BANKS;
  localparam longint NEVER = -64'sd1000000;

  // Bank state is kept as one plain 2-D array PER FIELD, not as a 2-D array of unpacked structs:
  // (simulator defect) Verilator-5.020 silently drops all but the last member write to an element of a multi-dimensional
  // array of unpacked structs (reproduced in docs/AUDIT_V2.md, "Simulator defect"), which made this
  // checker blind (every bank looked closed, every reset value was 0). Plain arrays are portable.

  typedef struct {
    longint  data;     // cycle the data is due
    hbm_data_t d;
    hbm_ecc_t  e;
  } rd_item_t;

  bit       bk_open      [NUM_PC][NB];
  int       bk_row       [NUM_PC][NB];
  longint   bk_last_act  [NUM_PC][NB];
  longint   bk_last_pre  [NUM_PC][NB];
  longint   bk_last_rd   [NUM_PC][NB];
  longint   bk_last_wr   [NUM_PC][NB];
  longint   bk_ref_until [NUM_PC][NB];
  longint   bk_last_ref  [NUM_PC][NB];
  longint   act_hist [NUM_PC][4];                 // last four ACT times (FAW)
  longint   last_act_bg [NUM_PC][HBM_NUM_BG];
  longint   last_col_bg [NUM_PC][HBM_NUM_BG];     // last RD/WR per bank group
  longint   last_wr_bg  [NUM_PC][HBM_NUM_BG];
  longint   last_rd_any [NUM_PC];
  longint   last_mrs    [NUM_PC];
  longint   last_exit   [NUM_PC];
  int       exit_n      [NUM_PC];
  longint   ref_busy_until [NUM_PC];
  bit       in_pd [NUM_PC];
  bit [15:0] rdy_hist [NUM_PC];                  // ready_o history: [k] = ready k+1 cycles ago (PHY contract C1)
  bit       in_sr [NUM_PC];
  // explicit circular buffers (NOT arrays of queues: pop_front() on an array-of-queues element
  // operates on a copy in Verilator 5.048 - found the hard way)
  localparam int unsigned QD = 256;
  longint   wq_due [NUM_PC][QD];                 // cycle at which write data is due
  longint   wq_key [NUM_PC][QD];                 // storage key of the granule
  int unsigned wq_h [NUM_PC];
  int unsigned wq_n [NUM_PC];
  rd_item_t rq_it [NUM_PC][QD];
  int unsigned rq_h [NUM_PC];
  int unsigned rq_n [NUM_PC];

  hbm_data_t mem [longint];
  hbm_ecc_t  ecc [longint];
  int unsigned act_bucket [NUM_PC][256];          // row-hash activation counters (reporting)

  longint cycle_q;
  int unsigned viol_cnt;
  int unsigned cmd_cnt;
  int unsigned rule_cnt [string];
  int unsigned total_wr_granules, total_rd_granules;
  int fd;
  string rule_name_buf;
  bit trace_on;
  int unsigned no_refchk = 0;     // +HBM_NO_REFCHECK=1: disable ONLY the refresh-deadline rule (bandwidth baselines with refresh off)
  bit [31:0] lfsr;

  assign viol_cnt_o = viol_cnt;
  assign cmd_cnt_o  = cmd_cnt;

  function automatic longint key_of(int pc, int bg, int ba, int row, int col);
    return (longint'(pc) << 48) | (longint'(bg) << 44) | (longint'(ba) << 40) | (longint'(row) << 16) | longint'(col);
  endfunction

  function automatic int bank_i(hbm_cmd_t c);
    return int'({c.bg, c.ba});
  endfunction

  task automatic viol(input int pc, input string rule, input hbm_cmd_t c);
    viol_cnt++;
    if (rule_cnt.exists(rule)) rule_cnt[rule]++; else rule_cnt[rule] = 1;
    if (!viol_quiet_i)
      $error("[hbm4_dram_model] cycle %0d pc %0d: %s violated by %s bg%0d ba%0d row%0d col%0d",
             cycle_q, PC_BASE + pc, rule, c.cmd.name(), c.bg, c.ba, c.row, c.col);
  endtask

  // ---- fault injection API (called from testbenches) -------------------------
  task automatic flip_bits(input int pc, input int bg, input int ba, input int row, input int col,
                           input hbm_data_t xmask);
    longint k;
    k = key_of(pc, bg, ba, row, col);
    if (!mem.exists(k)) begin mem[k] = '0; ecc[k] = '0; end
    mem[k] = mem[k] ^ xmask;
  endtask

  task automatic poke(input int pc, input int bg, input int ba, input int row, input int col,
                      input hbm_data_t d, input hbm_ecc_t e);
    longint k;
    k = key_of(pc, bg, ba, row, col);
    mem[k] = d; ecc[k] = e;
  endtask

  task automatic clear_all_mem();
    mem.delete(); ecc.delete();
  endtask

  // ---- v2 RowHammer RESEARCH METRIC (behavioural assumption, NOT a device model) -------------------------------
  // hammer[key] = ACTs to one row since that row was last mitigated by a refresh-management command.
  //   directed mode (rfm_directed = 1, set by the testbench): an RFM mitigates the row it names;
  //   undirected mode: an RFM mitigates the most-activated row of its bank (device-side tracking assumption).
  // Regular refresh is deliberately NOT modelled as mitigation (worst case over any refresh window), so the metric
  // is an upper bound. max_unmitigated is reported; it says nothing about a real device's RowHammer threshold.
  longint hammer [longint];
  longint max_unmitigated = 0;
  int unsigned rfm_cnt = 0;
  int rfm_directed = 0;
  task automatic hammer_act(input int pc, input int b, input int row);
    longint k; k = key_of(pc, b >> HBM_BA_W, b & ((1 << HBM_BA_W) - 1), row, 0);
    if (hammer.exists(k)) hammer[k]++; else hammer[k] = 1;
    if (hammer[k] > max_unmitigated) max_unmitigated = hammer[k];
  endtask
  task automatic hammer_mitigate(input int pc, input int b, input int row);
    longint k, best_k, best;
    if (rfm_directed != 0) begin
      k = key_of(pc, b >> HBM_BA_W, b & ((1 << HBM_BA_W) - 1), row, 0);
      if (hammer.exists(k)) hammer[k] = 0;
    end else begin
      best = 0; best_k = -1;
      foreach (hammer[kk]) if ((kk >> 40) == (key_of(pc, b >> HBM_BA_W, b & ((1 << HBM_BA_W) - 1), 0, 0) >> 40) && hammer[kk] > best) begin
        best = hammer[kk]; best_k = kk;
      end
      if (best_k >= 0) hammer[best_k] = 0;
    end
  endtask

  task automatic report();
    $display("[hbm4_dram_model] violations=%0d commands=%0d granules_read=%0d granules_written=%0d",
             viol_cnt, cmd_cnt, total_rd_granules, total_wr_granules);
    $display("[hbm4_dram_model] rfm_commands=%0d max_unmitigated_row_acts=%0d (research metric, see docs/ROWHAMMER.md)",
             rfm_cnt, max_unmitigated);
    foreach (rule_cnt[r]) $display("[hbm4_dram_model]   rule %-28s %0d", r, rule_cnt[r]);
  endtask

  // ---- ready (PHY back-pressure) --------------------------------------------
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) lfsr <= 32'hACE1_2468;
    else lfsr <= {lfsr[30:0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};
  end
  always_comb begin
    for (int p = 0; p < NUM_PC; p++)
      ready_o[p] = ((lfsr[(p*3) % 24 +: 8] % 100) >= stall_pct_i[6:0]) || (stall_pct_i == 8'd0);
  end

  initial begin
    trace_on = 1'b0;
    void'($value$plusargs("HBM_NO_REFCHECK=%d", no_refchk));
    if ($value$plusargs("HBM_TRACE=%s", rule_name_buf)) begin
      fd = $fopen(rule_name_buf, "w");
      if (fd != 0) trace_on = 1'b1;
    end
  end

  // ---- main model ------------------------------------------------------------
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cycle_q <= 0; viol_cnt = 0; cmd_cnt = 0; total_wr_granules = 0; total_rd_granules = 0;
      for (int p = 0; p < NUM_PC; p++) begin
        for (int b = 0; b < NB; b++) begin
          bk_open[p][b] = 0; bk_row[p][b] = 0;
          bk_last_act[p][b] = NEVER; bk_last_pre[p][b] = NEVER; bk_last_rd[p][b] = NEVER;
          bk_last_wr[p][b] = NEVER;  bk_ref_until[p][b] = NEVER; bk_last_ref[p][b] = 0;
        end
        for (int f = 0; f < 4; f++) act_hist[p][f] = NEVER;
        for (int g = 0; g < HBM_NUM_BG; g++) begin
          last_act_bg[p][g] = NEVER; last_col_bg[p][g] = NEVER; last_wr_bg[p][g] = NEVER;
        end
        last_rd_any[p] = NEVER; last_mrs[p] = NEVER; last_exit[p] = NEVER; exit_n[p] = 0;
        ref_busy_until[p] = NEVER; in_pd[p] = 0; in_sr[p] = 0; rdy_hist[p] = '1;
        wq_h[p] = 0; wq_n[p] = 0; rq_h[p] = 0; rq_n[p] = 0;
        for (int k = 0; k < 256; k++) act_bucket[p][k] = 0;
      end
      rvalid_o <= '0; rdata_o <= '0; recc_o <= '0; rerr_o <= '0;
    end else begin
      cycle_q <= cycle_q + 1;
      for (int p = 0; p < NUM_PC; p++) begin
        hbm_cmd_t c;
        longint t;
        int b, g;
        longint need;
        t = cycle_q;
        c = cmd_i[p];
        b = bank_i(c);
        g = int'(c.bg);

        // ---- write data arrival -------------------------------------------------
        if (wvalid_i[p]) begin
          if (trace_on) $fdisplay(fd, "W %0d %0d", t, PC_BASE + p);
          if (wq_n[p] == 0 || wq_due[p][wq_h[p]] != t) viol(p, "write_data_unexpected_or_off_time", c);
          if (wq_n[p] != 0) begin
            longint k;
            hbm_data_t old;
            hbm_data_t nw;
            k = wq_key[p][wq_h[p]];
            old = mem.exists(k) ? mem[k] : '0;
            nw = old;
            for (int i = 0; i < HBM_MASK_W; i++)
              if (wmask_i[p][i]) nw[i*8 +: 8] = wdata_i[p][i*8 +: 8];
            mem[k] = nw;
            ecc[k] = wecc_i[p];
            total_wr_granules++;
            wq_h[p] = (wq_h[p] + 1) % QD; wq_n[p]--;
          end
        end else if (wq_n[p] != 0 && wq_due[p][wq_h[p]] < t) begin
          viol(p, "write_data_missing", c);
          wq_h[p] = (wq_h[p] + 1) % QD; wq_n[p]--;
        end

        // ---- command ------------------------------------------------------------
        if (cmd_valid_i[p] && c.cmd != HCMD_NOP) begin
          cmd_cnt++;
          if (trace_on) $fdisplay(fd, "%0d %0d %0d %0d %0d %0d %0d", t, PC_BASE + p, int'(c.cmd), c.bg, c.ba, c.row, c.col);

          // power-state gating: only the exit command is legal while in PD/SR
          if ((in_pd[p] && c.cmd != HCMD_PDX) || (in_sr[p] && c.cmd != HCMD_SRX))
            viol(p, "command_while_low_power", c);
          // exit latency gates everything after PDX/SRX
          if (c.cmd != HCMD_PDX && c.cmd != HCMD_SRX && (t - last_exit[p]) < longint'(exit_n[p]))
            viol(p, "tXP_tXS", c);
          // tMRD gates EVERY following command, including MRS -> MRS (v2: the MRS exemption made the
          // init-sequence spacing unchecked; docs/TIMING_RULES.md and python/hbm4/timing.py check all commands)
          if ((t - last_mrs[p]) < longint'(tp_i.tmrd) && c.cmd != HCMD_PDX && c.cmd != HCMD_SRX)
            viol(p, "tMRD", c);
          // PHY contract C1 (v2): a command (other than the PDX/SRX wake-ups) may only be issued while ready
          // was high in its issue cycle; nothing checked this before (independent review finding)
          if (c.cmd != HCMD_PDX && c.cmd != HCMD_SRX && !rdy_hist[p][READY_LAT-1])
            viol(p, "issued_while_phy_not_ready", c);

          case (c.cmd)
            HCMD_ACT: begin
              if (bk_open[p][b]) viol(p, "ACT_to_open_bank", c);
              if ((t - bk_last_pre[p][b]) < longint'(tp_i.trp)) viol(p, "tRP", c);
              if ((t - bk_last_act[p][b]) < longint'(tp_i.trc)) viol(p, "tRC", c);
              if (t < ref_busy_until[p] || t < bk_ref_until[p][b]) viol(p, "tRFC", c);
              for (int gg = 0; gg < HBM_NUM_BG; gg++) begin
                need = (gg == g) ? longint'(tp_i.trrd_l) : longint'(tp_i.trrd_s);
                if ((t - last_act_bg[p][gg]) < need) viol(p, (gg == g) ? "tRRD_L" : "tRRD_S", c);
              end
              // FAW: at most 4 ACT in any tFAW window -> the 4th most recent must be >= tFAW old
              if ((t - act_hist[p][3]) < longint'(tp_i.tfaw)) viol(p, "tFAW", c);
              for (int f = 3; f > 0; f--) act_hist[p][f] = act_hist[p][f-1];
              act_hist[p][0] = t;
              last_act_bg[p][g] = t;
              bk_open[p][b] = 1; bk_row[p][b] = int'(c.row); bk_last_act[p][b] = t;
              hammer_act(p, b, int'(c.row));
              act_bucket[p][(int'(c.row) ^ (b*7)) & 255]++;
            end
            HCMD_RD, HCMD_WR: begin
              bit is_rd;
              is_rd = (c.cmd == HCMD_RD);
              if (!bk_open[p][b])                   viol(p, "col_to_closed_bank", c);
              else if (bk_row[p][b] != int'(c.row)) viol(p, "col_to_wrong_row", c);
              if ((t - bk_last_act[p][b]) < longint'(is_rd ? tp_i.trcdrd : tp_i.trcdwr))
                viol(p, is_rd ? "tRCDRD" : "tRCDWR", c);
              for (int gg = 0; gg < HBM_NUM_BG; gg++) begin
                need = (gg == g) ? longint'(tp_i.tccd_l) : longint'(tp_i.tccd_s);
                if ((t - last_col_bg[p][gg]) < need) viol(p, (gg == g) ? "tCCD_L" : "tCCD_S", c);
                if (is_rd) begin
                  need = longint'(tp_i.wl) + longint'(tp_i.burst) + ((gg == g) ? longint'(tp_i.twtr_l) : longint'(tp_i.twtr_s));
                  if ((t - last_wr_bg[p][gg]) < need) viol(p, (gg == g) ? "tWTR_L" : "tWTR_S", c);
                end
              end
              if (!is_rd) begin
                need = longint'(tp_i.rl) + longint'(tp_i.burst) + 2 - longint'(tp_i.wl);
                if (need < 1) need = 1;
                if ((t - last_rd_any[p]) < need) viol(p, "tRTW", c);
              end
              last_col_bg[p][g] = t;
              if (is_rd) begin
                rd_item_t it;
                longint k;
                k = key_of(PC_BASE + p, g, int'(c.ba), int'(c.row), int'(c.col));
                bk_last_rd[p][b] = t; last_rd_any[p] = t;
                it.data = t + longint'(tp_i.rl);
                it.d = mem.exists(k) ? mem[k] : '0;
                it.e = ecc.exists(k) ? ecc[k] : '0;
                if (rq_n[p] >= QD) $fatal(1, "[hbm4_dram_model] read queue overflow");
                rq_it[p][(rq_h[p] + rq_n[p]) % QD] = it;
                rq_n[p]++;
                // (data captured when the RD arrives: tWTR guarantees every older write has landed) (a write landing before then is visible)
                total_rd_granules++;
              end else begin
                bk_last_wr[p][b] = t; last_wr_bg[p][g] = t;
                if (wq_n[p] >= QD) $fatal(1, "[hbm4_dram_model] write expectation queue overflow");
                wq_due[p][(wq_h[p] + wq_n[p]) % QD] = t + longint'(tp_i.wl);
                wq_key[p][(wq_h[p] + wq_n[p]) % QD] = key_of(PC_BASE + p, g, int'(c.ba), int'(c.row), int'(c.col));
                wq_n[p]++;
              end
            end
            HCMD_PRE, HCMD_PREA: begin
              for (int bb = 0; bb < NB; bb++) begin
                if (c.cmd == HCMD_PREA || bb == b) begin
                  if (bk_open[p][bb]) begin
                    if ((t - bk_last_act[p][bb]) < longint'(tp_i.tras)) viol(p, "tRAS", c);
                    if ((t - bk_last_rd[p][bb])  < longint'(tp_i.trtp)) viol(p, "tRTP", c);
                    if ((t - bk_last_wr[p][bb])  < longint'(tp_i.wl) + longint'(tp_i.burst) + longint'(tp_i.twr))
                      viol(p, "tWR", c);
                    bk_open[p][bb] = 0; bk_last_pre[p][bb] = t;
                  end
                end
              end
            end
            HCMD_REF_AB: begin
              for (int bb = 0; bb < NB; bb++) begin
                if (bk_open[p][bb]) viol(p, "REF_with_open_bank", c);
                if ((t - bk_last_pre[p][bb]) < longint'(tp_i.trp)) viol(p, "tRP_before_REF", c);
                bk_last_ref[p][bb] = t;
              end
              if (t < ref_busy_until[p]) viol(p, "tRFC_back_to_back", c);
              for (int bb = 0; bb < NB; bb++) if (t < bk_ref_until[p][bb]) viol(p, "REF_during_REFPB", c);
              for (int bb = 0; bb < NB; bb++) if ((t - bk_last_act[p][bb]) < longint'(tp_i.trc)) viol(p, "tRC_before_REF", c);
              ref_busy_until[p] = t + longint'(tp_i.trfc);
            end
            HCMD_REF_PB: begin
              if (bk_open[p][b]) viol(p, "REFPB_with_open_bank", c);
              if ((t - bk_last_pre[p][b]) < longint'(tp_i.trp)) viol(p, "tRP_before_REFPB", c);
              if (t < bk_ref_until[p][b]) viol(p, "tRFCpb_back_to_back", c);
              if (t < ref_busy_until[p])  viol(p, "REFPB_during_REF", c);
              if ((t - bk_last_act[p][b]) < longint'(tp_i.trc)) viol(p, "tRC_before_REFPB", c);
              bk_ref_until[p][b] = t + longint'(tp_i.trfcpb);
              bk_last_ref[p][b] = t;
            end
            HCMD_MRS: begin
              for (int bb = 0; bb < NB; bb++) begin
                if (bk_open[p][bb]) viol(p, "MRS_with_open_bank", c);
                if ((t - bk_last_pre[p][bb]) < longint'(tp_i.trp)) viol(p, "tRP_before_MRS", c);
              end
              if (t < ref_busy_until[p]) viol(p, "tRFC_before_MRS", c);
              for (int bb = 0; bb < NB; bb++) if (t < bk_ref_until[p][bb]) viol(p, "tRFCpb_before_MRS", c);
              last_mrs[p] = t;
            end
            HCMD_PDE, HCMD_SRE: begin
              for (int bb = 0; bb < NB; bb++) begin
                if (bk_open[p][bb]) viol(p, "LOWPWR_with_open_bank", c);
                if ((t - bk_last_pre[p][bb]) < longint'(tp_i.trp)) viol(p, "tRP_before_LOWPWR", c);
              end
              if (t < ref_busy_until[p]) viol(p, "tRFC_before_LOWPWR", c);
              for (int bb = 0; bb < NB; bb++) if (t < bk_ref_until[p][bb]) viol(p, "tRFCpb_before_LOWPWR", c);
              if (c.cmd == HCMD_PDE) in_pd[p] = 1; else in_sr[p] = 1;
            end
            HCMD_PDX: begin
              if (!in_pd[p]) viol(p, "PDX_not_in_PD", c);
              in_pd[p] = 0; last_exit[p] = t; exit_n[p] = int'(tp_i.txp);
            end
            HCMD_SRX: begin
              if (!in_sr[p]) viol(p, "SRX_not_in_SR", c);
              in_sr[p] = 0; last_exit[p] = t; exit_n[p] = int'(tp_i.txs);
              // the DRAM refreshed itself: restart every refresh deadline
              for (int bb = 0; bb < NB; bb++) bk_last_ref[p][bb] = t;
            end
            HCMD_RFM: begin
              // v2: abstract refresh management (ENGINEERING_ASSUMPTION; HBM4 RFM/DRFM semantics UNVERIFIED):
              // per bank, like REF_PB: bank precharged, tRP / tRC met, no refresh in progress; busy for tRFM
              if (bk_open[p][b]) viol(p, "RFM_with_open_bank", c);
              if ((t - bk_last_pre[p][b]) < longint'(tp_i.trp)) viol(p, "tRP_before_RFM", c);
              if ((t - bk_last_act[p][b]) < longint'(tp_i.trc)) viol(p, "tRC_before_RFM", c);
              if (t < bk_ref_until[p][b]) viol(p, "RFM_during_REFPB_or_RFM", c);
              if (t < ref_busy_until[p])  viol(p, "RFM_during_REF", c);
              bk_ref_until[p][b] = t + longint'(tp_i.trfm);
              rfm_cnt++;
              hammer_mitigate(p, b, int'(c.row));
            end
            default: viol(p, "reserved_command", c);
          endcase
        end

        rdy_hist[p] = {rdy_hist[p][14:0], ready_o[p]};

        // ---- refresh deadline (independent of the controller's debt counter) ----------
        if (!in_sr[p] && (t > 0) && !no_refchk) begin
          longint limit;
          limit = (longint'(tp_i.max_postpone) + 1) * longint'(tp_i.trefi) + longint'(tp_i.trfc) + 4 * longint'(tp_i.trc);
          for (int bb = 0; bb < NB; bb++)
            if ((t - bk_last_ref[p][bb]) > limit) begin
              viol(p, "refresh_deadline", c);
              bk_last_ref[p][bb] = t;      // report once per overrun
            end
        end

        // ---- read return (visible at cycle due) -------------------------------------
        rvalid_o[p] <= 1'b0; rerr_o[p] <= 1'b0;
        if (rq_n[p] != 0 && rq_it[p][rq_h[p]].data == t + 1) begin
          rvalid_o[p] <= 1'b1;
          rdata_o[p]  <= rq_it[p][rq_h[p]].d;
          recc_o[p]   <= rq_it[p][rq_h[p]].e;
          rq_h[p] = (rq_h[p] + 1) % QD; rq_n[p]--;
        end
      end
    end
  end

  final begin
    report();
    if (trace_on) $fclose(fd);
  end
endmodule : hbm4_dram_model
