// =============================================================================
//  vl_ustruct_member_write.sv  --  standalone reproducer of a SIMULATOR defect found during the v2 audit
//
//  the Verilator 5.020 (Ubuntu 24.04 package) keeps only the LAST member write to an element of a MULTI-DIMENSIONAL
//  array of UNPACKED structs (cases A and C below print BROKEN; independent review narrowed it to arrays whose
//  first dimension is 1). 1-D arrays, whole-struct writes and queues are not affected. v1 HBMCore was verified with
//  the Verilator 5.048 only; on 5.020 this defect silently disabled the bank-state checks of the behavioural DRAM model
//  (hbm4_dram_model) in every single-pseudo-channel bench. v2 stores that state in plain per-field arrays.
//  Run:  verilator --binary --timing -Wno-fatal -Wno-lint vl_ustruct_member_write.sv --top-module vl_ustruct_member_write
//        && ./obj_dir/Vvl_ustruct_member_write
//  This file is a toolchain sanity probe, not part of the regression pass criteria.
// =============================================================================
module vl_ustruct_member_write;
  typedef struct { bit open; int row; longint a, b, c, d, e, f; } s8_t;
  typedef struct { bit open; int row; longint a; } s3_t;
  s8_t two8 [1][16];  s8_t one8 [16];  s3_t two3 [1][16];  s8_t whole2 [1][16];  s8_t q[$];
  logic clk = 0; int cyc = 0;
  always #5 clk = ~clk;
  always @(posedge clk) begin
    s8_t tmp;
    cyc <= cyc + 1;
    for (int p = 0; p < 1; p++) begin
      int b; b = 6;
      if (cyc == 1) begin
        two8[p][b].open = 1; two8[p][b].a = -5; two8[p][b].f = 7;
        one8[b].open = 1;    one8[b].a = -5;    one8[b].f = 7;
        two3[p][b].open = 1; two3[p][b].a = -5;
        tmp.open = 1; tmp.row = 0; tmp.a = -5; tmp.b = 0; tmp.c = 0; tmp.d = 0; tmp.e = 0; tmp.f = 7; whole2[p][b] = tmp;
        q.push_back(tmp);
      end
      if (cyc == 2) begin
        $display("A 2-D 8-field member write : open=%0d a=%0d f=%0d  %s", two8[p][b].open, two8[p][b].a, two8[p][b].f, (two8[p][b].open==1 && two8[p][b].a==-5 && two8[p][b].f==7) ? "OK":"BROKEN");
        $display("B 1-D 8-field member write : open=%0d a=%0d f=%0d  %s", one8[b].open, one8[b].a, one8[b].f, (one8[b].open==1 && one8[b].a==-5 && one8[b].f==7) ? "OK":"BROKEN");
        $display("C 2-D 3-field member write : open=%0d a=%0d       %s", two3[p][b].open, two3[p][b].a, (two3[p][b].open==1 && two3[p][b].a==-5) ? "OK":"BROKEN");
        $display("D 2-D whole-struct write   : open=%0d a=%0d f=%0d  %s", whole2[p][b].open, whole2[p][b].a, whole2[p][b].f, (whole2[p][b].open==1 && whole2[p][b].a==-5 && whole2[p][b].f==7) ? "OK":"BROKEN");
        tmp = q.pop_front();
        $display("E queue push/pop           : open=%0d a=%0d f=%0d  %s", tmp.open, tmp.a, tmp.f, (tmp.open==1 && tmp.a==-5 && tmp.f==7) ? "OK":"BROKEN");
        $finish;
      end
    end
  end
endmodule
