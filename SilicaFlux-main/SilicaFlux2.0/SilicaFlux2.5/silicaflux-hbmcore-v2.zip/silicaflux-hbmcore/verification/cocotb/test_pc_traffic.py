"""cocotb: random traffic through ONE pseudo-channel controller + DRAM model, scored by the INDEPENDENT Python model.
 - reads must return python RefMemory contents evaluated in request-acceptance order (masked writes)
 - same-id responses stay in request order, exactly one response per request
 - the DRAM command trace produced by the model is replayed through python/hbm4/timing.TimingChecker (rules from docs/TIMING_RULES.md)
"""
import os, random
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, FallingEdge
from hbm4.reference_memory import RefMemory
from hbm4.trace_check import check_trace_file

PROFILE = int(os.environ.get("PROFILE", "1")); POLICY = int(os.environ.get("POLICY", "1"))
TRACE = os.environ.get("TRACE_FILE", "cocotb_pc.trace")

def gkey(bg, ba, row, col): return ((bg << 48) | (ba << 44) | (row << 24) | col) << 5

@cocotb.test()
async def random_traffic_matches_python_model(dut):
    cocotb.start_soon(Clock(dut.clk, 10, "ns").start())   # positional unit: valid in cocotb 1.9 and 2.x
    dut.rst_n.value = 0; dut.req_valid.value = 0; dut.rsp_ready.value = 1; dut.profile_sel.value = PROFILE; dut.policy.value = POLICY
    dut.req_write.value = 0; dut.req_id.value = 0; dut.req_src.value = 0; dut.req_qos.value = 0
    dut.bg.value = 0; dut.ba.value = 0; dut.row.value = 0; dut.col.value = 0; dut.wdata.value = 0; dut.wmask.value = 0
    for _ in range(5): await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    for _ in range(3): await RisingEdge(dut.clk)

    rng = random.Random(2024)
    mem = RefMemory()
    expq = {}                       # (src,id) -> list of expected (write, data)
    N = int(os.environ.get("NREQ", "1500"))
    sent = done = 0
    reqs = []
    for i in range(N):
        w = rng.random() < 0.45
        bg, ba, row, col = rng.randrange(4), rng.randrange(4), rng.randrange(6), rng.randrange(8)
        mask = 0xFFFFFFFF if rng.random() < .6 else rng.getrandbits(32)
        reqs.append((w, bg, ba, row, col, rng.randrange(8), rng.randrange(3), rng.getrandbits(256), mask))

    errors = []
    async def monitor():
        nonlocal done
        while done < N:
            await RisingEdge(dut.clk)
            dut.rsp_ready.value = int(rng.random() < 0.7)           # consumer back-pressure
            await FallingEdge(dut.clk)
            if int(dut.rsp_valid.value) and int(dut.rsp_ready.value):
                key = (int(dut.rsp_src.value), int(dut.rsp_id.value))
                q = expq.get(key)
                if not q: errors.append(f"foreign/duplicate response {key}"); done += 1; continue
                w, data = q.pop(0)
                if int(dut.rsp_write.value) != int(w): errors.append(f"op mismatch {key}")
                if int(dut.rsp_err.value) != 0: errors.append(f"unexpected error {int(dut.rsp_err.value)} {key}")
                if not w and int(dut.rsp_data.value) != data: errors.append(f"DATA MISMATCH {key}: rtl={int(dut.rsp_data.value):#x} python={data:#x}")
                done += 1
    mon = cocotb.start_soon(monitor())

    i = 0
    while i < N:
        w, bg, ba, row, col, rid, src, data, mask = reqs[i]
        await FallingEdge(dut.clk)
        dut.req_valid.value = 1; dut.req_write.value = int(w); dut.req_id.value = rid; dut.req_src.value = src
        dut.bg.value = bg; dut.ba.value = ba; dut.row.value = row; dut.col.value = col; dut.wdata.value = data; dut.wmask.value = mask
        await RisingEdge(dut.clk)
        if int(dut.req_ready.value):                                  # accepted at this edge
            k = gkey(bg, ba, row, col)
            if w:
                mem.write(k, data, mask); expq.setdefault((src, rid), []).append((True, 0))
            else:
                expq.setdefault((src, rid), []).append((False, mem.read(k)))
            i += 1
    await FallingEdge(dut.clk); dut.req_valid.value = 0
    for _ in range(40000):
        if done >= N: break
        await RisingEdge(dut.clk)
    await mon
    assert done == N, f"only {done} of {N} responses returned"
    assert not errors, errors[:5]
    assert int(dut.violations.value) == 0, "DRAM model reported timing violations"
    dut._log.info(f"{N} requests, all responses match the Python reference memory; DRAM violations = 0")

@cocotb.test()
async def python_timing_checker_accepts_rtl_trace(dut):
    # runs after the traffic test: the model flushes its trace at end of simulation, so the check is done by run_cocotb.py
    pass
