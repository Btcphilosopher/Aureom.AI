// cocotb wrapper: ONE pseudo-channel controller + the timing-aware behavioural DRAM model, plain ports.
`timescale 1ns/1ps
module cocotb_pc_top (
  input  logic clk, rst_n,
  input  logic [3:0] profile_sel, input logic [2:0] policy,
  input  logic req_valid, output logic req_ready,
  input  logic req_write, input logic [7:0] req_id, input logic [3:0] req_src, input logic [1:0] req_qos,
  input  logic [1:0] bg, input logic [1:0] ba, input logic [14:0] row, input logic [5:0] col,
  input  logic [255:0] wdata, input logic [31:0] wmask,
  output logic rsp_valid, input logic rsp_ready, output logic [3:0] rsp_src, output logic [7:0] rsp_id,
  output logic rsp_write, output logic [2:0] rsp_err, output logic [255:0] rsp_data,
  output logic [31:0] violations
);
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;
  hbm_timing_t tp; hbm_sched_cfg_t sc; hbm_ref_cfg_t rc; hbm_txn_t txn; hbm_rsp_t rsp;
  always_comb begin
    tp = hbm_profile(profile_sel);
    sc = '0; sc.policy = hbm_sched_policy_e'(policy); sc.batch_len = 8'd8; sc.close_timeout = 16'd16;
    rc = '0; rc.mode = REFMODE_AB; rc.eager = 1'b1;
    txn = '0; txn.src = req_src; txn.id = req_id; txn.qos = req_qos; txn.write = req_write; txn.err = HERR_NONE;
    txn.bg = bg; txn.ba = ba; txn.row = row; txn.col = col;
  end
  logic sv, wv, rv, rerr, pready; hbm_cmd_t scmd; hbm_data_t wd, rd; hbm_mask_t wm; hbm_ecc_t we, re;
  hbm_pc_evt_t evt; logic [15:0] lat; logic [5:0] by; logic [4:0] occ; logic [2:0] pws; logic [31:0] r0, r1, r2, c0, c1, c2, c3;
  logic signed [7:0] debt; logic quiet, unimpl, lv, lue, alert; logic [8:0] lsyn; logic [HBM_NUM_BANKS-1:0][1:0] bst;
  sf_hbm_pseudochannel #(.DEPTH(16), .CPL_DEPTH(8)) pc (
    .clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .sched_cfg_i(sc), .ref_cfg_i(rc), .ecc_en_i(1'b0), .ctrl_enable_i(1'b1),
    .pwr_req_i(2'd0), .pd_idle_i(16'd0), .sr_idle_i(16'd0), .init_mrs_valid_i(1'b0), .init_mrs_code_i(8'd0), .init_mrs_ack_o(),
    .ecc_clear_i(1'b0), .inj_arm_i(1'b0), .inj_mode_i(2'd0), .inj_bit_i(9'd0),
    .req_valid_i(req_valid), .req_ready_o(req_ready), .req_txn_i(txn), .req_wdata_i(wdata), .req_wmask_i(wmask),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp),
    .phy_ready_ext_i(pready), .phy_event_i(1'b0), .ondie_event_i(1'b0),
    .sim_cmd_valid_o(sv), .sim_cmd_o(scmd), .sim_wvalid_o(wv), .sim_wdata_o(wd), .sim_wmask_o(wm), .sim_wecc_o(we),
    .sim_rvalid_i(rv), .sim_rdata_i(rd), .sim_recc_i(re), .sim_rerr_i(rerr),
    .evt_o(evt), .lat_o(lat), .rsp_bytes_o(by), .occ_o(occ), .pwr_state_o(pws), .res_active_o(r0), .res_pd_o(r1), .res_sr_o(r2),
    .ref_debt_o(debt), .quiet_o(quiet), .backend_unimplemented_o(unimpl), .ecc_ce_o(c0), .ecc_ue_o(c1), .phy_err_o(c2), .ondie_err_o(c3),
    .ecc_log_valid_o(lv), .ecc_log_ue_o(lue), .ecc_log_syn_o(lsyn), .ecc_alert_o(alert), .bank_state_o(bst), .dbg_cmd_valid_o(), .dbg_cmd_o());
  assign rsp_src = rsp.src; assign rsp_id = rsp.id; assign rsp_write = rsp.write; assign rsp_err = rsp.err; assign rsp_data = rsp.data;
  int unsigned vc, cc;
  hbm4_dram_model #(.NUM_PC(1)) dram (.clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .viol_quiet_i(1'b0), .stall_pct_i(8'd0),
    .cmd_valid_i(sv), .cmd_i(scmd), .wvalid_i(wv), .wdata_i(wd), .wmask_i(wm), .wecc_i(we),
    .ready_o(pready), .rvalid_o(rv), .rdata_o(rd), .recc_o(re), .rerr_o(rerr), .viol_cnt_o(vc), .cmd_cnt_o(cc));
  assign violations = 32'(vc);
endmodule
