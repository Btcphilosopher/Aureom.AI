// cocotb wrapper: flat ports around sf_hbm_addr_map (so Python can drive / read every field)
module cocotb_addr_map #(parameter int unsigned NUM_STACKS = 1, parameter int unsigned NUM_CHANNELS = 4) (
  input  logic [39:0] addr_i,
  input  logic [1:0]  mode_i,
  input  logic [2:0]  il_i,
  input  logic        hash_i,
  output logic [2:0]  stk_o, output logic [5:0] ch_o, output logic [1:0] pc_o,
  output logic [1:0]  bg_o,  output logic [1:0] ba_o, output logic [14:0] row_o, output logic [5:0] col_o,
  output logic [15:0] pcflat_o,
  output logic        err_range_o, output logic err_mis_o, output logic [2:0] err_o
);
  import sf_hbm_pkg::*;
  hbm_loc_t loc; logic [$clog2(NUM_STACKS*NUM_CHANNELS*2 > 1 ? NUM_STACKS*NUM_CHANNELS*2 : 2)-1:0] pcf;
  sf_hbm_addr_map #(.NUM_STACKS(NUM_STACKS), .NUM_CHANNELS(NUM_CHANNELS), .PCS(2)) u (
    .addr_i(addr_i), .mode_i(hbm_map_e'(mode_i)), .il_bits_i(il_i), .hash_i(hash_i), .loc_o(loc), .pc_o(pcf),
    .err_range_o(err_range_o), .err_misalign_o(err_mis_o), .err_o());
  assign stk_o = loc.stk; assign ch_o = loc.ch; assign pc_o = loc.pc[1:0]; assign bg_o = loc.bg; assign ba_o = loc.ba;
  assign row_o = loc.row; assign col_o = loc.col; assign pcflat_o = 16'(pcf);
  assign err_o = err_range_o ? 3'd2 : (err_mis_o ? 3'd1 : 3'd0);
endmodule
