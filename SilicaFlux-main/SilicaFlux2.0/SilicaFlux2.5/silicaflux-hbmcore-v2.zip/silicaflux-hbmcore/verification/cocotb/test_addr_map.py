"""cocotb: RTL sf_hbm_addr_map vs the INDEPENDENT Python model (python/hbm4/address_map.py, written from docs/ADDRESS_MAP.md only)."""
import os, random
import cocotb
from cocotb.triggers import Timer
from hbm4.address_map import AddrMapCfg, map_addr, check_addr, pc_index

NCH = int(os.environ.get("NCH", "4"))
CFG = AddrMapCfg(num_stacks=1, num_channels=NCH, pcs=2)

async def drive(dut, addr, mode, il, hsh):
    dut.addr_i.value = addr; dut.mode_i.value = mode; dut.il_i.value = il; dut.hash_i.value = int(hsh)
    await Timer(1, "ns")

@cocotb.test()
async def addr_map_matches_python(dut):
    rng = random.Random(1234)
    n = 0
    cap = 1 << CFG.cap_bits
    for mode in (0, 1, 2):
        for hsh in (False, True):
            for il in ((0,) if mode == 0 else (0, 1, 3, 6)):
                for _ in range(400):
                    a = (rng.getrandbits(40) % cap) & ~31
                    await drive(dut, a, mode, il, hsh)
                    e = map_addr(a, CFG, mode, il, hsh)
                    got = (int(dut.stk_o.value), int(dut.ch_o.value), int(dut.pc_o.value), int(dut.bg_o.value), int(dut.ba_o.value),
                           int(dut.row_o.value), int(dut.col_o.value))
                    assert got == (e.stack, e.ch, e.pc, e.bg, e.ba, e.row, e.col), f"mode={mode} il={il} hash={hsh} addr={a:#x}: rtl={got} python={tuple(e)}"
                    assert int(dut.pcflat_o.value) == pc_index(e, CFG), f"flat pc mismatch at {a:#x}"
                    assert int(dut.err_o.value) == 0
                    n += 1
    dut._log.info(f"{n} address mappings agree with the Python model (NCH={NCH})")

@cocotb.test()
async def range_and_misalign_flags(dut):
    rng = random.Random(99)
    cap = 1 << CFG.cap_bits
    for _ in range(300):
        a = rng.getrandbits(40)
        await drive(dut, a, rng.randrange(3), rng.randrange(4), rng.random() < .5)
        assert int(dut.err_o.value) == check_addr(a, CFG), f"error classification differs at {a:#x}: rtl={int(dut.err_o.value)} python={check_addr(a, CFG)}"
    for a in (cap, cap + 32, cap - 1, cap - 32, 1, 31, 33):
        await drive(dut, a, 1, 0, False)
        assert int(dut.err_o.value) == check_addr(a, CFG), f"edge address {a:#x}"
