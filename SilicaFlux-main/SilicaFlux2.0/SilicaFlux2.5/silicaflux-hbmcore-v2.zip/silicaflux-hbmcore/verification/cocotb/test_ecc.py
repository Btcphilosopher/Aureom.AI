"""cocotb: RTL sf_hbm_ecc_ras SECDED vs python/hbm4/reference_memory.py (independent implementation of docs/RAS_CODE.md)."""
import random
import cocotb
from cocotb.triggers import Timer
from hbm4.reference_memory import secded_encode, secded_decode

async def settle(): await Timer(1, "ns")

@cocotb.test()
async def encode_and_decode_match_python(dut):
    rng = random.Random(7)
    dut.ecc_en_i.value = 1; dut.clear_i.value = 0; dut.inj_arm_i.value = 0; dut.inj_mode_i.value = 0; dut.inj_bit_i.value = 0
    dut.wr_fire_i.value = 0; dut.rd_fire_i.value = 0; dut.phy_event_i.value = 0; dut.phy_rd_err_i.value = 0; dut.ondie_event_i.value = 0
    dut.clk_i.value = 0; dut.rst_ni.value = 1
    cases = 0
    for _ in range(300):
        d = rng.getrandbits(256)
        dut.wdata_i.value = d
        await settle()
        e = secded_encode(d)
        assert int(dut.wecc_o.value) == e, f"encode mismatch data={d:#x}: rtl={int(dut.wecc_o.value):#x} python={e:#x}"
        # clean, single-bit (data and check bits), double-bit
        flips = [[]] + [[rng.randrange(266)] for _ in range(3)] + [rng.sample(range(266), 2) for _ in range(3)]
        for fl in flips:
            dd, ee = d, e
            for b in fl:
                if b < 256: dd ^= 1 << b
                else: ee ^= 1 << (b - 256)
            dut.rdata_i.value = dd; dut.recc_i.value = ee
            await settle()
            pd, pce, pue, _syn = secded_decode(dd, ee)
            rtl_err = int(dut.rerr_o.value)           # 0 none, 6 ECC (uncorrectable)
            assert (rtl_err == 6) == bool(pue), f"UE disagrees flips={fl}: rtl_err={rtl_err} python_ue={pue}"
            if not pue:
                assert int(dut.rdata_o.value) == pd, f"corrected data differs flips={fl}"
                assert int(dut.rcorr_o.value) == int(bool(pce)), f"corrected flag differs flips={fl}"
            cases += 1
    dut._log.info(f"{cases} encode/decode cases agree with the Python SECDED")

@cocotb.test()
async def exhaustive_single_bit_positions(dut):
    d = 0x0123456789ABCDEF_FEDCBA9876543210_0F1E2D3C4B5A6978_8796A5B4C3D2E1F0
    dut.wdata_i.value = d; await settle(); e = int(dut.wecc_o.value)
    for b in range(266):
        dd, ee = d, e
        if b < 256: dd ^= 1 << b
        else: ee ^= 1 << (b - 256)
        dut.rdata_i.value = dd; dut.recc_i.value = ee; await settle()
        assert int(dut.rerr_o.value) == 0 and int(dut.rdata_o.value) == d and int(dut.rcorr_o.value) == 1, f"single-bit error at position {b} not corrected by the RTL"


async def clk_cycle(dut):
    """one manual clock cycle (the ECC block is the cocotb top level; no Clock driver in this module)"""
    dut.clk_i.value = 0; await settle()
    dut.clk_i.value = 1; await settle()
    dut.clk_i.value = 0; await settle()


@cocotb.test()
async def v2_rearm_in_consuming_cycle_is_kept(dut):
    """v2 (independent review B5): an injection arm requested in the SAME cycle the previous shot is consumed must stay
    armed. v1 let the consume-clear override the new arm, so the second injection silently never happened."""
    dut.ecc_en_i.value = 1; dut.clear_i.value = 0; dut.inj_arm_i.value = 0; dut.inj_mode_i.value = 0; dut.inj_bit_i.value = 0
    dut.wr_fire_i.value = 0; dut.rd_fire_i.value = 0; dut.phy_event_i.value = 0; dut.phy_rd_err_i.value = 0; dut.ondie_event_i.value = 0
    dut.rst_ni.value = 0; await clk_cycle(dut); dut.rst_ni.value = 1; await clk_cycle(dut)
    d = 0x5A5A_1234_0000_FFFF_DEAD_BEEF_0123_4567_89AB_CDEF_0F0F_F0F0_AAAA_5555_C3C3_3C3C
    dut.wdata_i.value = d
    # arm shot 1: flip data bit 3 on the next write
    dut.inj_arm_i.value = 1; dut.inj_mode_i.value = 1; dut.inj_bit_i.value = 3
    await clk_cycle(dut); dut.inj_arm_i.value = 0
    # this write consumes shot 1 ... and in the same cycle shot 2 (flip bit 7) is armed
    dut.wr_fire_i.value = 1; await settle()
    assert int(dut.wdata_o.value) == d ^ (1 << 3), "shot 1 not applied"
    dut.inj_arm_i.value = 1; dut.inj_bit_i.value = 7
    await clk_cycle(dut)
    dut.inj_arm_i.value = 0; dut.wr_fire_i.value = 0; await settle()
    # the next write must carry shot 2
    dut.wr_fire_i.value = 1; await settle()
    assert int(dut.wdata_o.value) == d ^ (1 << 7), "re-arm issued in the consuming cycle was lost (review finding B5)"
    await clk_cycle(dut); dut.wr_fire_i.value = 0; await settle()
    assert int(dut.wdata_o.value) == d, "a consumed shot must not fire again"


@cocotb.test()
async def v2_two_phy_error_sources_in_one_cycle_count_two(dut):
    """v2 (independent review B6): a PHY status event and a PHY read-data error in the same cycle are two events."""
    dut.ecc_en_i.value = 1; dut.clear_i.value = 0; dut.inj_arm_i.value = 0; dut.wr_fire_i.value = 0; dut.rd_fire_i.value = 0
    dut.phy_event_i.value = 0; dut.phy_rd_err_i.value = 0; dut.ondie_event_i.value = 0
    dut.rst_ni.value = 0; await clk_cycle(dut); dut.rst_ni.value = 1; await clk_cycle(dut)
    c0 = int(dut.phy_cnt_o.value)
    dut.phy_event_i.value = 1; dut.phy_rd_err_i.value = 1; await clk_cycle(dut)
    dut.phy_event_i.value = 0; await clk_cycle(dut)
    dut.phy_rd_err_i.value = 0; await clk_cycle(dut)
    assert int(dut.phy_cnt_o.value) - c0 == 3, f"expected 3 PHY error events, counter moved by {int(dut.phy_cnt_o.value) - c0}"
