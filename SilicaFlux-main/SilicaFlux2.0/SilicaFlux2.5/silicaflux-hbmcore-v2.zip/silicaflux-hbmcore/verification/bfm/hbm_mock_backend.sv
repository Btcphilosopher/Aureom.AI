// =============================================================================
//  hbm_mock_backend.sv -- SIMULATION-ONLY mock of the HBM granule interface (sf_hbm4_controller host port)
//  Random latency, OUT-OF-ORDER responses, random request back-pressure, byte-accurate memory, RANGE error beyond CAP_BITS.
//  Used to stress response reordering / ownership in the DataFabric and DMA adapters. Not a timing model.
// =============================================================================
`timescale 1ns/1ps
module hbm_mock_backend
  import sf_hbm_pkg::*;
#(parameter int unsigned CAP_BITS = 24, parameter int unsigned LAT_MAX = 24, parameter int unsigned DEPTH = 64)
(
  input  logic clk_i, rst_ni,
  input  logic req_valid_i, output logic req_ready_o,
  input  hbm_addr_t req_addr_i, input logic req_write_i, input hbm_id_t req_id_i, input hbm_src_t req_src_i,
  input  hbm_data_t req_wdata_i, input hbm_mask_t req_wmask_i,
  output logic rsp_valid_o, input logic rsp_ready_i, output hbm_rsp_t rsp_o
);
  typedef struct { bit v; hbm_rsp_t r; int due; } it_t;
  it_t   items [DEPTH];
  hbm_data_t mem [longint];
  int    now;
  logic  [31:0] lfsr;
  int    cnt;
  always_comb begin
    cnt = 0; for (int i = 0; i < DEPTH; i++) cnt += items[i].v;
  end
  assign req_ready_o = (cnt < DEPTH) && (lfsr[3:0] < 4'd13);

  int sel;
  always_comb begin
    sel = -1; rsp_o = '0;
    for (int k = 0; k < DEPTH; k++) begin
      int i; i = (k + int'(lfsr[15:8])) % DEPTH;
      if (sel < 0 && items[i].v && items[i].due <= now) sel = i;
    end
    rsp_valid_o = (sel >= 0);
    if (sel >= 0) rsp_o = items[sel].r;
  end

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      for (int i = 0; i < DEPTH; i++) items[i].v = 0;
      now = 0; lfsr <= 32'h1BADB002;
    end else begin
      now = now + 1;
      lfsr <= {lfsr[30:0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};
      if (rsp_valid_o && rsp_ready_i) items[sel].v = 0;
      if (req_valid_i && req_ready_o) begin
        for (int i = 0; i < DEPTH; i++) if (!items[i].v) begin
          longint g; hbm_data_t old, nw;
          g = longint'(req_addr_i >> HBM_OFF_W);
          items[i].v = 1; items[i].due = now + 1 + int'($urandom % LAT_MAX);
          items[i].r = '0; items[i].r.src = req_src_i; items[i].r.id = req_id_i; items[i].r.write = req_write_i;
          if ((req_addr_i >> CAP_BITS) != 0) items[i].r.err = HERR_RANGE;
          else if (req_write_i) begin
            old = mem.exists(g) ? mem[g] : '0; nw = old;
            for (int b = 0; b < 32; b++) if (req_wmask_i[b]) nw[b*8 +: 8] = req_wdata_i[b*8 +: 8];
            mem[g] = nw;
          end else items[i].r.data = mem.exists(g) ? mem[g] : '0;
          break;
        end
      end
    end
  end
endmodule
