// =============================================================================
//  tb_pc_single.sv  --  self-checking testbench: ONE pseudo-channel controller + timing-aware DRAM model
//
//  FIRST ENGINEERING DELIVERABLE: proves that sf_hbm_pseudochannel schedules ACTIVATE / READ / WRITE /
//  PRECHARGE (and REFRESH) legally against hbm4_dram_model, with correct data, byte enables, IDs and ordering.
//
//  SCOREBOARD
//    * reference memory (byte accurate). Writes are applied at request ACCEPTANCE; a read snapshots the
//      reference at acceptance. This is exactly the contract the DUT promises (hazards on one granule are
//      executed in acceptance order), so the snapshot is the only legal read value.
//    * per-{src,id} FIFOs of expected responses: same-ID responses must return in request order.
//    * every accepted request must produce exactly one response (no loss, no duplicate).
//    * the DRAM model's independent timing checker must report zero violations.
//
//  PLUSARGS  +TEST=<name|all>  +SEED=<n>  +PROFILE=<0..2>  +POLICY=<0..2>  +JSON=<file>  +HBM_TRACE=<file>
//            +PAGE=<0 open,1 close,2 timeout>  +BATCH=<0/1>  +PRIO=<0/1>  +REFMODE=<0 AB,1 PB,2 off>
// =============================================================================
`timescale 1ns/1ps
module tb_pc_single;
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;

  // -G parameters: PHY adapter latencies (extra register stages on command/write data and on read data) and backend select.
  // PHY_BACKEND=1 is the (unimplemented) vendor-PHY stub: only +TEST=backend_stub is meaningful there.
  parameter int unsigned PHY_CMD_LAT = 0;
  parameter int unsigned PHY_RD_LAT  = 0;
  parameter int unsigned PHY_BACKEND = 0;

  // ---------------------------------------------------------------- clock / reset
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint unsigned cyc;
  always @(posedge clk) cyc <= rst_n ? cyc + 1 : 0;

  // ---------------------------------------------------------------- configuration
  int unsigned profile_sel = 0, policy = 1, page_pol = 0, ref_mode = 0, rsp_ready_pct = 100, phy_stall_pct = 0;
  bit batch_en = 0, prio_en = 0;
  int unsigned rfm_en = 0, rfm_dir = 0, raaimt = 32, raammt = 64, raa_dec = 16;   // v2 refresh-management config
  int unsigned starve_lim = 0;               // sched_cfg.starve_limit (0 = off); set by t_starvation
  int track_id = -1; longint track_cyc, track_lat, track_cmp;   // completion tracker used by t_starvation
  hbm_timing_t    tp;
  hbm_sched_cfg_t scfg;
  hbm_ref_cfg_t   rcfg;
  logic           ecc_en = 1'b0;

  // ---------------------------------------------------------------- DUT
  logic        req_valid, req_ready;
  hbm_txn_t    req_txn;
  hbm_data_t   req_wdata;
  hbm_mask_t   req_wmask;
  logic        rsp_valid, rsp_ready;
  hbm_rsp_t    rsp;
  hbm_pc_evt_t evt;
  logic [15:0] lat;
  logic [5:0]  rsp_bytes;
  logic [4:0]  occ;
  logic [2:0]  pwr_state;
  logic [31:0] res_a, res_pd, res_sr;
  logic signed [7:0] ref_debt;
  logic        quiet, unimpl;
  logic [31:0] ecc_ce, ecc_ue, phy_err, ondie_err;
  logic        ecc_lv, ecc_lue, ecc_alert;
  logic [8:0]  ecc_lsyn;
  logic [HBM_NUM_BANKS-1:0][1:0] bank_state;
  logic        dbg_cv; hbm_cmd_t dbg_c;

  logic        sim_cv, sim_wv, sim_rv, sim_rerr, phy_ready;
  hbm_cmd_t    sim_c;
  hbm_data_t   sim_wd, sim_rd;
  hbm_mask_t   sim_wm;
  hbm_ecc_t    sim_we, sim_re;

  logic [1:0] pwr_req = 2'd0;
  logic [15:0] pd_idle_v = 16'd0, sr_idle_v = 16'd0;
  int unsigned ref_eager = 1;
  logic       ecc_clear = 1'b0, inj_arm = 1'b0;
  logic [1:0] inj_mode = 2'd0;
  logic [8:0] inj_bit = 9'd0;
  logic       ctrl_en = 1'b0;
  logic       t_mrs_v = 1'b0, t_mrs_ack;               // init-MRS port (driven by t_reinit)
  logic [7:0] t_mrs_c = 8'd0;
  int unsigned trc_add = 0, maxpp_ovr = 0;             // +TRCADD / +MAXPP profile overrides (v2 corner-case tests)
  logic       phy_ev = 1'b0, ondie_ev = 1'b0;      // PHY / on-die status event inputs (driven by t_phy_events)

  sf_hbm_pseudochannel #(.DEPTH(16), .CPL_DEPTH(8), .PHY_BACKEND(PHY_BACKEND), .PHY_CMD_LAT(PHY_CMD_LAT), .PHY_RD_LAT(PHY_RD_LAT)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .tp_i(tp), .sched_cfg_i(scfg), .ref_cfg_i(rcfg), .ecc_en_i(ecc_en), .ctrl_enable_i(ctrl_en),
    .pwr_req_i(pwr_req), .pd_idle_i(pd_idle_v), .sr_idle_i(sr_idle_v),
    .init_mrs_valid_i(t_mrs_v), .init_mrs_code_i(t_mrs_c), .init_mrs_ack_o(t_mrs_ack),
    .ecc_clear_i(ecc_clear), .inj_arm_i(inj_arm), .inj_mode_i(inj_mode), .inj_bit_i(inj_bit),
    .req_valid_i(req_valid), .req_ready_o(req_ready), .req_txn_i(req_txn),
    .req_wdata_i(req_wdata), .req_wmask_i(req_wmask),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp),
    .phy_ready_ext_i(phy_ready), .phy_event_i(phy_ev), .ondie_event_i(ondie_ev),
    .sim_cmd_valid_o(sim_cv), .sim_cmd_o(sim_c), .sim_wvalid_o(sim_wv), .sim_wdata_o(sim_wd),
    .sim_wmask_o(sim_wm), .sim_wecc_o(sim_we),
    .sim_rvalid_i(sim_rv), .sim_rdata_i(sim_rd), .sim_recc_i(sim_re), .sim_rerr_i(sim_rerr),
    .evt_o(evt), .lat_o(lat), .rsp_bytes_o(rsp_bytes), .occ_o(occ), .pwr_state_o(pwr_state),
    .res_active_o(res_a), .res_pd_o(res_pd), .res_sr_o(res_sr), .ref_debt_o(ref_debt), .quiet_o(quiet),
    .backend_unimplemented_o(unimpl),
    .ecc_ce_o(ecc_ce), .ecc_ue_o(ecc_ue), .phy_err_o(phy_err), .ondie_err_o(ondie_err),
    .ecc_log_valid_o(ecc_lv), .ecc_log_ue_o(ecc_lue), .ecc_log_syn_o(ecc_lsyn), .ecc_alert_o(ecc_alert),
    .bank_state_o(bank_state), .dbg_cmd_valid_o(dbg_cv), .dbg_cmd_o(dbg_c)
  );

  int unsigned viol_cnt, cmd_cnt;
  logic [7:0] stall_pct;
  logic       viol_quiet = 1'b0;
  hbm4_dram_model #(.NUM_PC(1), .READY_LAT(1 + PHY_CMD_LAT)) dram (
    .clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .viol_quiet_i(viol_quiet), .stall_pct_i(stall_pct),
    .cmd_valid_i(sim_cv), .cmd_i(sim_c), .wvalid_i(sim_wv), .wdata_i(sim_wd), .wmask_i(sim_wm), .wecc_i(sim_we),
    .ready_o(phy_ready), .rvalid_o(sim_rv), .rdata_o(sim_rd), .recc_o(sim_re), .rerr_o(sim_rerr),
    .viol_cnt_o(viol_cnt), .cmd_cnt_o(cmd_cnt)
  );

  // ---------------------------------------------------------------- scoreboard
  typedef struct {
    bit        write;
    int        src, id;
    hbm_txn_t  txn;
    hbm_data_t data;
    hbm_mask_t mask;
    longint    t_acc;
    int        exp_err;     // -1 = NONE
    int        exp_corr;    // -1 = don't care
  } item_t;

  typedef struct {
    bit        write;
    hbm_data_t data;
    longint    t_acc;
    longint    key;
    int        exp_err;
    int        exp_corr;
  } exp_t;

  item_t     pend [$];
  exp_t      expq [int][$];
  hbm_data_t refmem [longint];
  int        outstanding;
  longint    accepted, completed, accepted_rd, accepted_wr, flushed;
  int        errors;
  longint    lat_sum, lat_n;
  longint    lat_hist [int];
  longint    bytes_rd, bytes_wr;
  longint    sum_hit, sum_empty, sum_conf, sum_act, sum_pre, sum_ref, sum_forced, sum_pullin;
  longint    sum_tstall, sum_rstall, sum_rfm_block = 0;
  int        max_occ;
  longint    busy_cycles;

  function automatic longint gkey(hbm_txn_t t);
    return (longint'(t.bg) << 44) | (longint'(t.ba) << 40) | (longint'(t.row) << 16) | longint'(t.col);
  endfunction

  function automatic hbm_data_t rnd_data();
    hbm_data_t d;
    for (int i = 0; i < 8; i++) d[i*32 +: 32] = $urandom;
    return d;
  endfunction

  function automatic hbm_mask_t rnd_mask(int mode);
    // mode 0 full, 1 random bytes, 2 single byte, 3 alternating halves
    case (mode)
      0: return '1;
      1: return hbm_mask_t'($urandom);
      2: return hbm_mask_t'(32'd1 << ($urandom % 32));
      default: return ($urandom % 2) ? 32'h0000_FFFF : 32'hFFFF_0000;
    endcase
  endfunction

  task automatic fail(input string msg);
    errors++;
    $display("[TB][FAIL] cycle %0d: %s", cyc, msg);
  endtask

  // request driver -------------------------------------------------------------------
  item_t cur;
  bit    have_cur;
  int unsigned gate_pct = 100;

  always @(posedge clk) begin
    if (!rst_n) begin
      req_valid <= 1'b0; have_cur = 0;
    end else begin
      if (req_valid && req_ready) begin
        // ---- accepted this cycle ----
        exp_t e;
        accepted++; outstanding++;
        e.write = cur.write; e.t_acc = cyc; e.key = gkey(cur.txn); e.exp_err = cur.exp_err; e.exp_corr = cur.exp_corr;
        if (cur.write) begin
          hbm_data_t old;
          accepted_wr++;
          old = refmem.exists(e.key) ? refmem[e.key] : '0;
          for (int i = 0; i < 32; i++) if (cur.mask[i]) old[i*8 +: 8] = cur.data[i*8 +: 8];
          refmem[e.key] = old;
          e.data = '0;
        end else begin
          accepted_rd++;
          e.data = refmem.exists(e.key) ? refmem[e.key] : '0;
        end
        expq[{cur.src[3:0], cur.id[7:0]}].push_back(e);
        req_valid <= 1'b0; have_cur = 0;
      end
      if ((!req_valid || req_ready) && pend.size() != 0 && (($urandom % 100) < gate_pct)) begin
        cur = pend.pop_front(); have_cur = 1;
        req_txn   <= cur.txn;
        req_wdata <= cur.data;
        req_wmask <= cur.mask;
        req_valid <= 1'b1;
      end
    end
  end

  // response monitor ----------------------------------------------------------------------
  always @(posedge clk) begin
    if (rst_n && rsp_valid && rsp_ready) begin
      int k;
      k = {rsp.src, rsp.id};
      if (!expq.exists(k) || expq[k].size() == 0) begin
        fail($sformatf("response with no outstanding request: src=%0d id=%0d (duplicate or foreign response)", rsp.src, rsp.id));
      end else begin
        exp_t e;
        e = expq[k].pop_front();
        completed++; outstanding--;
        if (int'(rsp.id) == track_id && int'(rsp.src) == 0) begin track_cyc = cyc; track_lat = cyc - e.t_acc; track_cmp = completed; end
        if (rsp.write != e.write) fail($sformatf("op mismatch src=%0d id=%0d", rsp.src, rsp.id));
        if (e.exp_err < 0) begin
          if (rsp.err != HERR_NONE) fail($sformatf("unexpected error response %0d src=%0d id=%0d", rsp.err, rsp.src, rsp.id));
        end else if (int'(rsp.err) != e.exp_err)
          fail($sformatf("expected error %0d, got %0d (src=%0d id=%0d)", e.exp_err, rsp.err, rsp.src, rsp.id));
        if (e.exp_corr >= 0 && int'(rsp.corrected) != e.exp_corr)
          fail($sformatf("corrected flag exp=%0d got=%0d (src=%0d id=%0d)", e.exp_corr, rsp.corrected, rsp.src, rsp.id));
        if (!e.write && rsp.err == HERR_NONE && rsp.data !== e.data)
          fail($sformatf("DATA MISMATCH src=%0d id=%0d key=%0h exp=%0h got=%0h", rsp.src, rsp.id, e.key, e.data, rsp.data));
        lat_sum += lat; lat_n++;
        begin int b; b = (lat == 0) ? 0 : $clog2(lat + 1); if (lat_hist.exists(b)) lat_hist[b]++; else lat_hist[b] = 1; end
        if (rsp.write) bytes_wr += rsp_bytes; else bytes_rd += rsp_bytes;
      end
    end
  end

  // response consumer back-pressure
  always @(posedge clk) rsp_ready <= (($urandom % 100) < rsp_ready_pct);

  // event accumulation
  always @(posedge clk) if (rst_n) begin
    sum_hit += evt.row_hit; sum_empty += evt.row_empty; sum_conf += evt.row_conflict;
    sum_act += evt.act; sum_pre += evt.pre; sum_ref += evt.refresh; sum_forced += evt.ref_forced; sum_pullin += evt.ref_pullin;
    sum_tstall += evt.timing_stall; sum_rstall += evt.ref_stall;
    sum_rfm_block += evt.rfm_block;
    busy_cycles += evt.busy;
    if (int'(occ) > max_occ) max_occ = occ;
  end

`ifdef DBG_REF
  // debug monitor (off by default): refresh sequencer + issued commands while refresh is urgent
  int unsigned dbg_n = 0;
  always @(posedge clk) if (rst_n && dut.u_ref.urgent && dbg_n < 400) begin
    dbg_n++;
    $display("[DBGREF] cyc=%0d debt=%0d st=%0d pbk=%0d seqpb=%0d mode=%0d eager=%0d mnt=%s v=%0d g=%0d hb=%0d hbv=%0d hbc=%0d open=%b idle=%b canact=%b cmd=%s%s bg%0d ba%0d",
             cyc, dut.u_ref.debt_q, dut.u_ref.st_q, dut.u_ref.pbk, dut.u_ref.seq_pb_q, dut.ref_cfg_i.mode, dut.ref_cfg_i.eager,
             dut.u_ref.mnt_cmd_o.cmd.name(), dut.u_ref.mnt_valid_o, dut.u_ref.mnt_grant_i, dut.u_ref.hold_bank_o, dut.u_ref.hold_bank_valid_o,
             dut.u_ref.hold_bank_col_o, dut.bk_row_open, dut.bk_idle, dut.bk_can_act,
             dut.dbg_cmd_valid_o ? "" : "-", dut.dbg_cmd_valid_o ? dut.dbg_cmd_o.cmd.name() : "", dut.dbg_cmd_o.bg, dut.dbg_cmd_o.ba);
  end
`endif
  // ---------------------------------------------------------------- helpers
  task automatic apply_cfg();
    tp = hbm_profile(4'(profile_sel));
    tp.trc = tp.trc + 16'(trc_add);                          // +TRCADD: tRC > tRAS + tRP corner (still a legal profile)
    if (maxpp_ovr != 0) tp.max_postpone = 16'(maxpp_ovr);    // +MAXPP: postponement limit above the debt register range
    scfg = '0;
    scfg.policy = hbm_sched_policy_e'(policy[2:0]);
    scfg.prio_en = prio_en; scfg.batch_en = batch_en; scfg.batch_len = 8'd8;
    scfg.page = hbm_page_policy_e'(page_pol[1:0]); scfg.close_timeout = 16'd16; scfg.starve_limit = 16'(starve_lim);
    rcfg = '0; rcfg.mode = hbm_ref_mode_e'(ref_mode[1:0]); rcfg.eager = ref_eager[0]; rcfg.pullin_en = 1'b0;
    rcfg.rfm_en = rfm_en[0]; rcfg.rfm_dir = rfm_dir[0]; rcfg.raaimt = 8'(raaimt); rcfg.raammt = 8'(raammt); rcfg.raa_ref_dec = 8'(raa_dec);
    stall_pct = 8'(phy_stall_pct);
  endtask

  task automatic do_reset();
    rst_n = 1'b0; ctrl_en = 1'b0;
    pend.delete(); expq.delete(); outstanding = 0;
    repeat (4) @(posedge clk);
    rst_n = 1'b1;
    repeat (2) @(posedge clk);
    ctrl_en = 1'b1;
  endtask

  task automatic enq(input bit write, input int bg, input int ba, input int row, input int col,
                     input int id, input int src, input int qos, input hbm_data_t d, input hbm_mask_t m,
                     input hbm_order_e ord = ORD_RELAXED);
    item_t it;
    it.write = write; it.src = src; it.id = id;
    it.txn = '0;
    it.txn.src = hbm_src_t'(src); it.txn.id = hbm_id_t'(id); it.txn.qos = hbm_qos_t'(qos); it.txn.order = ord;
    it.txn.write = write; it.txn.err = HERR_NONE;
    it.txn.bg = hbm_bg_t'(bg); it.txn.ba = hbm_ba_t'(ba); it.txn.row = hbm_row_t'(row); it.txn.col = hbm_col_t'(col);
    it.data = d; it.mask = m; it.exp_err = -1; it.exp_corr = -1;
    pend.push_back(it);
  endtask

  task automatic enq_x(input bit write, input int bg, input int ba, input int row, input int col,
                       input int id, input hbm_data_t d, input hbm_mask_t m, input int exp_err, input int exp_corr);
    enq(write, bg, ba, row, col, id, 0, 0, d, m);
    pend[pend.size()-1].exp_err = exp_err; pend[pend.size()-1].exp_corr = exp_corr;
  endtask

  task automatic drain(input int unsigned max_cycles = 200000);
    int unsigned n;
    n = 0;
    while ((pend.size() != 0 || outstanding != 0 || req_valid) && n < max_cycles) begin
      @(posedge clk); n++;
    end
    if (n >= max_cycles) fail($sformatf("DRAIN TIMEOUT pend=%0d outstanding=%0d", pend.size(), outstanding));
    repeat (6) @(posedge clk);
  endtask

  // ---------------------------------------------------------------- tests
  int test_fail_base;
  task automatic begin_test(input string n);
    test_fail_base = errors;
    $display("[TB] ---- %s", n);
  endtask
  task automatic end_test(input string n);
    int v;
    v = viol_cnt;
    if (v != 0) fail($sformatf("%s: DRAM model reported %0d timing/state violations", n, v));
    if (errors == test_fail_base) $display("[TB] TEST %-34s PASS", n);
    else                          $display("[TB] TEST %-34s FAIL", n);
  endtask

  task automatic t_single_read();
    begin_test("single_read");
    enq(0, 1, 2, 100, 5, 1, 0, 0, '0, '1);
    drain();
    end_test("single_read");
  endtask

  task automatic t_single_write();
    begin_test("single_write");
    enq(1, 0, 0, 7, 3, 2, 0, 0, rnd_data(), '1);
    drain();
    end_test("single_write");
  endtask

  task automatic t_write_readback();
    begin_test("write_readback");
    for (int i = 0; i < 8; i++) begin
      hbm_data_t d; d = rnd_data();
      enq(1, i % 4, i % 4, 50 + i, i * 3, i, 0, 0, d, '1);
      enq(0, i % 4, i % 4, 50 + i, i * 3, 16 + i, 0, 0, '0, '1);
    end
    drain();
    end_test("write_readback");
  endtask

  task automatic t_sequential();
    begin_test("sequential_row_hits");
    for (int c = 0; c < 64; c++) enq(1, 0, 0, 9, c, c % 32, 0, 0, rnd_data(), '1);
    for (int c = 0; c < 64; c++) enq(0, 0, 0, 9, c, 32 + (c % 32), 0, 0, '0, '1);
    drain();
    end_test("sequential_row_hits");
  endtask

  task automatic t_partial_writes();
    begin_test("partial_writes_byte_enables");
    // establish a known granule, then overwrite subsets
    enq(1, 2, 1, 33, 4, 1, 0, 0, rnd_data(), '1);
    for (int i = 0; i < 24; i++) begin
      enq(1, 2, 1, 33, 4, 1, 0, 0, rnd_data(), rnd_mask(1 + (i % 3)));
      enq(0, 2, 1, 33, 4, 2, 0, 0, '0, '1);
    end
    // single-byte writes at every lane
    for (int l = 0; l < 32; l++) begin
      enq(1, 2, 1, 33, 5, 3, 0, 0, rnd_data(), hbm_mask_t'(32'd1 << l));
      enq(0, 2, 1, 33, 5, 4, 0, 0, '0, '1);
    end
    drain();
    end_test("partial_writes_byte_enables");
  endtask

  task automatic t_raw_waw_war();
    begin_test("hazards_raw_war_waw");
    // tight same-granule sequences: the DUT must serialise them in acceptance order
    for (int i = 0; i < 40; i++) begin
      enq(1, 1, 1, 77, 2, i % 8, 0, 0, rnd_data(), rnd_mask(i % 2));   // WAW / RAW
      enq(0, 1, 1, 77, 2, 8 + (i % 8), 0, 0, '0, '1);                    // read after write
      enq(0, 1, 1, 77, 2, 16 + (i % 8), 0, 0, '0, '1);                   // read after read
      enq(1, 1, 1, 77, 2, 24 + (i % 8), 0, 0, rnd_data(), '1);          // WAR
    end
    drain();
    end_test("hazards_raw_war_waw");
  endtask

  task automatic t_random(input int n, input string name, input int rows, input int wr_pct);
    begin_test(name);
    // pre-write a working set so reads are non-trivial
    for (int i = 0; i < 64; i++)
      enq(1, $urandom % 4, $urandom % 4, $urandom % rows, $urandom % 64, $urandom % 256, $urandom % 4, 0, rnd_data(), '1);
    for (int i = 0; i < n; i++) begin
      bit w; w = ($urandom % 100) < wr_pct;
      enq(w, $urandom % 4, $urandom % 4, $urandom % rows, $urandom % 64, $urandom % 256, $urandom % 4,
          $urandom % 4, rnd_data(), rnd_mask($urandom % 3), hbm_order_e'(($urandom % 16 == 0) ? 1 : 0));
    end
    drain();
    end_test(name);
  endtask

  // Policy semantics.  Bank X holds row 100 open. In age order:  A(read row100)  B(read row200)  H1..H12(read row100).
  // The response consumer is stalled, so after CPL_DEPTH(=8) reads the completion queue is full: column commands
  // are credit-blocked while a PRECHARGE of X is NOT. Only the policy's "never close a row that still has pending
  // hits" rule then keeps the older request B from stealing the open row.
  //   (the bank is primed open on row 100, so A is a hit)
  //   FCFS    : strict age order -> A(hit), B (PRE, ACT 200), H1 (PRE, ACT 100), H2..   : 2 ACT, 2 conflicts, 1+11 hits
  //   FR-FCFS : hits first       -> A, H1..H12 (13 hits), then B (PRE, ACT 200)         : 1 ACT, 1 conflict, 13 hits
  task automatic t_policy_semantics();
    longint a0, c0, h0;
    int save, saved_ref;
    begin_test("policy_semantics_row_hit_priority");
    // An all-bank refresh would legitimately close the primed row mid-test, so refresh is switched off for this
    // short window (the DRAM model's refresh-deadline limit is >1000 cycles; the window is ~200).
    saved_ref = ref_mode; ref_mode = 2; apply_cfg(); drain(); repeat (60) @(posedge clk);
    // PRIME: leave bank X deterministically OPEN on row 100, whatever earlier tests left behind (open-page policy)
    enq(0, 1, 1, 100, 0, 250, 0, 0, '0, '1);
    drain();
    a0 = sum_act; c0 = sum_conf; h0 = sum_hit;
    save = rsp_ready_pct;
    rsp_ready_pct = 0;
    enq(0, 1, 1, 100, 1, 1, 0, 0, '0, '1);               // A
    enq(0, 1, 1, 200, 1, 2, 0, 0, '0, '1);               // B  (older than every hit below)
    for (int c = 0; c < 12; c++) enq(0, 1, 1, 100, 2 + c, 3 + c, 0, 0, '0, '1);
    repeat (120) @(posedge clk);                          // let the completion queue fill and stay full
    rsp_ready_pct = save;
    drain();
    // Under CLOSE-page and TIMEOUT-page (close_timeout 16 < RL) the primed row is precharged before A arrives (nothing pending wants it), so A re-opens
    // row 100 (one extra ACT, one fewer row hit); the property under test - hits precede B's PRE - is unchanged.
    if (policy == 0) begin
      if (page_pol == 0) begin
        if (sum_act - a0 != 2) fail($sformatf("FCFS: expected 2 ACT, got %0d", sum_act - a0));
        if (sum_conf - c0 != 2) fail($sformatf("FCFS: expected 2 row conflicts, got %0d", sum_conf - c0));
      end
    end else begin
      int exp_act, exp_hit;
      exp_act = (page_pol != 0) ? 2 : 1;
      exp_hit = (page_pol != 0) ? 12 : 13;
      if (sum_act - a0 != exp_act) fail($sformatf("FR-FCFS: expected %0d ACT (hits must precede B's PRE), got %0d", exp_act, sum_act - a0));
      if (sum_conf - c0 != 1) fail($sformatf("FR-FCFS: expected 1 row conflict, got %0d", sum_conf - c0));
      if (sum_hit - h0 != exp_hit) fail($sformatf("FR-FCFS: expected %0d row hits, got %0d", exp_hit, sum_hit - h0));
    end
    ref_mode = saved_ref; apply_cfg();
    end_test("policy_semantics_row_hit_priority");
  endtask

  // Anti-starvation: a request to a CONFLICTING row must not be postponed for ever by a continuous stream of row hits
  // (PRE protection closes a row only when no hit is pending - a starving entry overrides that protection).
  task automatic starve_run(input int limit, output longint b_lat, output longint b_after, input int nhits);
    longint c0; int saved_ref;
    // refresh is switched OFF for the flood (it would close the row under test); the DRAM model's refresh-DEADLINE rule - and only that
    // rule - is lifted for the same window and re-armed once the controller has caught up on refresh afterwards
    saved_ref = ref_mode; ref_mode = 2; starve_lim = limit; apply_cfg(); dram.no_refchk = 1; drain(); repeat (60) @(posedge clk);
    enq(0, 1, 1, 100, 0, 250, 0, 0, '0, '1); drain();                        // PRIME: row 100 of bank X is open
    track_id = 2; track_cyc = 0; track_lat = -1; track_cmp = 0; c0 = completed;
    for (int c = 0; c < 8; c++) enq(0, 1, 1, 100, 2 + c, 3 + c, 0, 0, '0, '1);   // hits already pending when B arrives
    enq(0, 1, 1, 200, 1, 2, 0, 0, '0, '1);                                   // B: conflicting row (id 2)
    for (int c = 8; c < nhits; c++) enq(0, 1, 1, 100, 2 + (c % 60), 3 + c, 0, 0, '0, '1);   // ... and the flood keeps coming
    drain();
    track_id = -1;
    b_lat = track_lat; b_after = track_cmp - c0;                            // B's latency; responses completed up to and including B
    ref_mode = saved_ref; starve_lim = 0; apply_cfg();
    if (saved_ref != 2) begin
      longint r0; int w; r0 = sum_ref; w = 0;
      while (sum_ref < r0 + 2 && w < 6 * int'(tp.trefi) + 2000) begin @(posedge clk); w++; end
      if (sum_ref < r0 + 2) fail("refresh did not resume after the starvation window");
      repeat (8) @(posedge clk);
    end
    dram.no_refchk = (saved_ref == 2) ? 1 : 0;
  endtask
  // v2 (independent review, finding A4): sf_hbm_init re-runs its MRS sequence after READY drops (power-good / clock loss).
  // With the open-page policy a row is still open; the init MRS needs every bank idle. Before the fix nothing closed the
  // row (enable low holds demand, refresh and power) and the MRS was never granted -> init timeout / hang.
  task automatic t_reinit();
    int w;
    begin_test("reinit_with_open_rows");
    // precondition (open-page policy only): a row is open when READY drops. A refresh may close the rows between
    // the drain and the check, so re-open them a few times; with close-page policies the re-init runs on closed rows.
    for (int k = 0; k < 6; k++) begin
      enq(0, 1, 1, 100, 0, 250, 0, 0, '0, '1);
      enq(0, 2, 3, 77, 1, 251, 0, 0, '0, '1);
      drain();
      ctrl_en = 1'b0;                                  // freeze: from here on nothing but maintenance can close a row
      if (bank_state != '0 || page_pol != 0) break;
      ctrl_en = 1'b1;
    end
    if (page_pol == 0 && bank_state == '0) fail("reinit: precondition not met (no row open before the re-init)");
    repeat (5) @(posedge clk);
    t_mrs_v = 1'b1; t_mrs_c = 8'h5A; w = 0;
    while (!t_mrs_ack && w < 2000) begin @(posedge clk); w++; end
    if (!t_mrs_ack) fail($sformatf("reinit: init MRS not granted after %0d cycles with rows open (deadlock)", w));
    else $display("[TB]   reinit: MRS granted after %0d cycles (banks closed first)", w);
    @(posedge clk); t_mrs_v = 1'b0; ctrl_en = 1'b1; repeat (4) @(posedge clk);
    t_random(300, "after_reinit", 8, 40);                     // the channel must work normally afterwards
    end_test("reinit_with_open_rows");
  endtask

  // v2 (finding A3): long saturating traffic with lazy refresh; with +MAXPP above the 8-bit debt range the controller
  // must still refresh in time (the DRAM model's independent refresh-deadline rule is armed).
  task automatic t_longsat();
    int unsigned e, n; e = 0; n = 20000;
    begin_test("long_saturating_lazy_refresh");
    void'($value$plusargs("EAGER=%d", e)); void'($value$plusargs("NREQ=%d", n));
    ref_eager = e; apply_cfg();
    t_random(n, "long_saturating_random", 16, 40);
    $display("[TB]   refreshes issued: %0d  debt now %0d  cycles %0d", sum_ref, ref_debt, cyc);
    if (sum_ref == 0) fail("no refresh issued under sustained traffic");
    end_test("long_saturating_lazy_refresh");
  endtask

  // v2: refresh-management research hook (sf_hbm_rfm). Adversarial double-sided hammer: two rows of ONE bank are read
  // alternately, so (open page) every access is PRE + ACT. Measured with the DRAM model's research metric
  // max_unmitigated_row_acts (ACTs to one row since it was last mitigated; regular refresh is NOT counted as mitigation).
  //   phase 0  RFM off                -> the metric grows with the hammer length (the test has power)
  //   phase 1  RFM directed, IMT/MMT  -> RFM issued, metric bounded, data exact, no timing violation
  //   phase 2  RFM undirected         -> same with device-side victim choice (model assumption)
  //   phase 3  MMT blocking only (IMT = 0: no RFM requests): ACTs are blocked at RAA >= MMT until refresh decrements
  //            the count -> progress continues, block cycles observed, never an ACT above MMT (sf_hbm_rfm asserts it)
  longint hm_off, hm_dir, hm_und;
  task automatic hammer_run(input int n, input int row_a, input int row_b, output longint max_unmit, output longint rfms,
                            output longint cycles);
    longint r0, c0;
    dram.hammer.delete(); dram.max_unmitigated = 0; r0 = dram.rfm_cnt; c0 = cyc;
    // ORD_STRICT keeps the alternation even under FR-FCFS (an attacker serialises its accesses; a pipelined alternating
    // stream would simply be regrouped into row hits by the scheduler and would not hammer)
    for (int k = 0; k < n; k++) enq(0, 2, 1, (k % 2) ? row_b : row_a, k % 8, 400 + (k % 50), 0, 0, '0, '1, ORD_STRICT);
    drain();
    max_unmit = dram.max_unmitigated; rfms = dram.rfm_cnt - r0; cycles = cyc - c0;
  endtask
  task automatic t_rowhammer();
    longint m, r, c, blk0;
    int unsigned saved_pg;
    begin_test("rowhammer_rfm_research_hook");
    saved_pg = page_pol; page_pol = 0;
    raaimt = 16; raammt = 32; raa_dec = 8;
    rfm_en = 0; apply_cfg(); repeat (4) @(posedge clk);
    hammer_run(600, 100, 102, m, r, c); hm_off = m;
    $display("[TB]   hammer RFM off      : max_unmitigated=%0d rfm=%0d cycles=%0d", m, r, c);
    if (m < 250) fail($sformatf("rowhammer: without RFM the hammer reached only %0d ACTs on one row (test has no power)", m));
    rfm_en = 1; rfm_dir = 1; dram.rfm_directed = 1; apply_cfg(); repeat (4) @(posedge clk);
    hammer_run(600, 100, 102, m, r, c); hm_dir = m;
    $display("[TB]   hammer RFM directed : max_unmitigated=%0d rfm=%0d cycles=%0d (IMT %0d MMT %0d)", m, r, c, raaimt, raammt);
    if (r == 0) fail("rowhammer: directed RFM enabled but no RFM issued");
    if (m > 2 * raammt) fail($sformatf("rowhammer: directed RFM left a row with %0d unmitigated ACTs (> 2 x MMT %0d)", m, raammt));
    rfm_dir = 0; dram.rfm_directed = 0; apply_cfg(); repeat (4) @(posedge clk);
    hammer_run(600, 100, 102, m, r, c); hm_und = m;
    $display("[TB]   hammer RFM undirect : max_unmitigated=%0d rfm=%0d cycles=%0d", m, r, c);
    if (r == 0) fail("rowhammer: undirected RFM enabled but no RFM issued");
    if (m > 2 * raammt) fail($sformatf("rowhammer: undirected RFM left a row with %0d unmitigated ACTs", m));
    // phase 3: blocking only
    raaimt = 0; raammt = 8; raa_dec = 8; apply_cfg(); repeat (4) @(posedge clk);
    blk0 = sum_rfm_block;
    hammer_run(200, 100, 102, m, r, c);
    $display("[TB]   MMT blocking only   : rfm=%0d cycles=%0d block_cycles=%0d", r, c, sum_rfm_block - blk0);
    if (r != 0) fail("rowhammer: RFM issued with raaimt = 0");
    if (sum_rfm_block == blk0) fail("rowhammer: MMT never blocked an ACT although IMT was disabled");
    // benign random traffic with RFM on: must stay exact
    raaimt = 16; raammt = 32; raa_dec = 8; rfm_dir = 1; dram.rfm_directed = 1; apply_cfg();
    t_random(800, "random_with_rfm_enabled", 32, 40);
    rfm_en = 0; rfm_dir = 0; dram.rfm_directed = 0; raaimt = 32; raammt = 64; raa_dec = 16; page_pol = saved_pg; apply_cfg();
    end_test("rowhammer_rfm_research_hook");
  endtask

  // v2 (found by the coverage regression): software changes the refresh MODE / eagerness at arbitrary moments while
  // traffic runs. v1 reinterpreted an in-flight per-bank sequence as all-bank and could stall refresh for good.
  task automatic t_refswitch();
    int unsigned tog, saved_mode, saved_eager;
    longint r0;
    begin_test("refresh_mode_switch_under_traffic");
    saved_mode = ref_mode; saved_eager = ref_eager; r0 = sum_ref; tog = 0;
    for (int i = 0; i < 3000; i++)
      enq($urandom % 2, $urandom % 4, $urandom % 4, $urandom % 16, $urandom % 64, $urandom % 256, 0, 0, rnd_data(), '1);
    while (pend.size() != 0) begin
      repeat (20 + ($urandom % 280)) @(posedge clk);
      if (hbm_profile_pb_ok(4'(profile_sel))) ref_mode = (ref_mode == 1) ? 0 : 1;
      ref_eager = $urandom % 2;
      apply_cfg(); tog++;
    end
    drain();
    ref_mode = saved_mode; ref_eager = saved_eager; apply_cfg();
    $display("[TB]   %0d mode/eagerness switches, %0d refreshes", tog, sum_ref - r0);
    if (sum_ref == r0) fail("no refresh during the mode-switch stress");
    end_test("refresh_mode_switch_under_traffic");
  endtask

  task automatic t_starvation();
    longint lat_off, aft_off, lat_on, aft_on; int lim, nh;
    begin_test("starvation_row_hit_flood");
    lim = 60; nh = 120; void'($value$plusargs("LIM=%d", lim)); void'($value$plusargs("NH=%d", nh));
    if (policy == 0) begin
      // FCFS never lets a younger hit overtake: B completes right after the 8 hits that are OLDER than it (9 responses)
      starve_run(0, lat_off, aft_off, nh);
      if (aft_off != 9) fail($sformatf("FCFS: B completed after %0d responses (expected 9: strictly oldest first)", aft_off));
    end else begin
      starve_run(0, lat_off, aft_off, nh);
      starve_run(lim, lat_on, aft_on, nh);
      $display("[TB]   starvation: limit off -> B latency %0d cycles (%0d responses first);  limit %0d -> B latency %0d cycles (%0d responses first)", lat_off, aft_off, lim, lat_on, aft_on);
      // (a) the test must be able to see starvation at all: without the limit the whole hit stream goes first
      if (aft_off < nh) fail($sformatf("limit off: B completed after only %0d of %0d hits - the hit flood did not starve it (test has no power)", aft_off, nh));
      // (b) with the limit B is served within  limit + PRE + ACT + RD + queue drain  (generous bound, still far below the flood length)
      if (lat_on < 0) fail("limit on: B never completed");
      else if (lat_on > lim + 4 * int'(tp.trc) + int'(tp.rl) + 32 + 2 * 16) fail($sformatf("limit %0d: B latency %0d cycles exceeds the bound %0d", lim, lat_on, lim + 4 * int'(tp.trc) + int'(tp.rl) + 32 + 2 * 16));
      if (aft_on >= aft_off) fail($sformatf("limit on did not reorder B ahead of the hit stream (%0d vs %0d responses first)", aft_on, aft_off));
    end
    end_test("starvation_row_hit_flood");
  endtask

  // PHY-interface and on-die status events are COUNTED separately from ECC and never touch data or the ECC counters
  task automatic t_phy_events();
    int p0, o0, ce0, ue0;
    begin_test("phy_and_ondie_event_counters");
    ecc_clear_pulse(); repeat (3) @(posedge clk);
    p0 = phy_err; o0 = ondie_err; ce0 = ecc_ce; ue0 = ecc_ue;
    if (p0 != 0 || o0 != 0) fail($sformatf("event counters not zero after clear: phy=%0d ondie=%0d", p0, o0));
    for (int i = 0; i < 7; i++) begin @(negedge clk); phy_ev = 1; @(negedge clk); phy_ev = 0; repeat (2) @(posedge clk); end
    for (int i = 0; i < 5; i++) begin @(negedge clk); ondie_ev = 1; @(negedge clk); ondie_ev = 0; end
    // a burst of 3 consecutive cycles counts 3
    @(negedge clk); phy_ev = 1; repeat (3) @(negedge clk); phy_ev = 0;
    repeat (3) @(posedge clk);
    if (phy_err != 10)   fail($sformatf("phy_err = %0d, expected 10 (7 single pulses + a 3-cycle burst)", phy_err));
    if (ondie_err != 5)  fail($sformatf("ondie_err = %0d, expected 5", ondie_err));
    if (ecc_ce != ce0 || ecc_ue != ue0) fail("PHY / on-die events changed the ECC counters");
    // data path unaffected
    for (int i = 0; i < 8; i++) begin hbm_data_t d; d = rnd_data(); enq(1, 2, 1, 40, i, i, 0, 0, d, '1); enq(0, 2, 1, 40, i, 16 + i, 0, 0, '0, '1); end
    drain();
    ecc_clear_pulse(); repeat (3) @(posedge clk);
    if (phy_err != 0 || ondie_err != 0) fail("ECC clear did not clear the PHY / on-die event counters");
    end_test("phy_and_ondie_event_counters");
  endtask

  // BACKEND B (vendor PHY) is an UNIMPLEMENTED stub: it must say so, issue nothing, and never fabricate a completion
  task automatic t_backend_stub();
    int saved_ref;
    begin_test("backend_b_stub_unimplemented");
    saved_ref = ref_mode; ref_mode = 2; apply_cfg(); repeat (4) @(posedge clk);
    if (!unimpl) fail("backend_unimplemented_o is not asserted for BACKEND=1");
    enq(0, 1, 1, 50, 0, 1, 0, 0, '0, '1);
    enq(1, 1, 1, 50, 1, 2, 0, 0, rnd_data(), '1);
    repeat (600) @(posedge clk);
    if (!unimpl) fail("backend_unimplemented_o dropped");
    if (cmd_cnt != 0) fail($sformatf("the stub issued %0d commands to the DRAM", cmd_cnt));
    if (completed != 0) fail($sformatf("the stub completed %0d requests without a PHY", completed));
    if (outstanding == 0) fail("accepted requests vanished");
    // clean up: reset flushes the stuck requests (accounted as flushed)
    flushed += outstanding; rst_n = 1'b0; ctrl_en = 1'b0; repeat (3) @(posedge clk);
    pend.delete(); expq.delete(); outstanding = 0; refmem.delete();
    rst_n = 1'b1; repeat (2) @(posedge clk); ctrl_en = 1'b1;
    ref_mode = saved_ref; apply_cfg();
    end_test("backend_b_stub_unimplemented");
  endtask

  task automatic t_backpressure();
    int save_r, save_p;
    begin_test("backpressure_rsp_and_phy");
    save_r = rsp_ready_pct; save_p = phy_stall_pct;
    rsp_ready_pct = 20; phy_stall_pct = 30; apply_cfg();
    t_random(300, "  (inner random under stall)", 24, 50);
    rsp_ready_pct = save_r; phy_stall_pct = save_p; apply_cfg();
    end_test("backpressure_rsp_and_phy");
  endtask

  task automatic t_saturation();
    begin_test("queue_saturation");
    gate_pct = 100;
    for (int i = 0; i < 400; i++)
      enq($urandom % 2, $urandom % 4, $urandom % 4, $urandom % 8, $urandom % 64, i % 256, 0, 0, rnd_data(), '1);
    drain();
    if (max_occ < 16) fail($sformatf("queue never saturated (max occupancy %0d)", max_occ));
    end_test("queue_saturation");
  endtask

  task automatic t_refresh_long();
    longint r0, t0;
    begin_test("refresh_under_traffic");
    r0 = sum_ref; t0 = cyc;
    // enough traffic to span several refresh intervals
    for (int round = 0; round < 6; round++) begin
      t_random(400, "  (inner)", 16, 40);
    end
    if (sum_ref - r0 < 2) fail($sformatf("expected several refreshes, saw %0d", sum_ref - r0));
    end_test("refresh_under_traffic");
  endtask

  task automatic t_reset_behaviour();
    begin_test("reset_behaviour");
    for (int i = 0; i < 100; i++) enq($urandom % 2, $urandom % 4, $urandom % 4, $urandom % 8, $urandom % 64, i % 256, 0, 0, rnd_data(), '1);
    repeat (60) @(posedge clk);
    // reset in the middle of traffic
    rst_n = 1'b0; ctrl_en = 1'b0;
    repeat (3) @(posedge clk);
    flushed += outstanding; pend.delete(); expq.delete(); outstanding = 0; refmem.delete(); dram.clear_all_mem();
    rst_n = 1'b1; repeat (2) @(posedge clk); ctrl_en = 1'b1;
    if (occ != 0) fail("queue not empty after reset");
    if (rsp_valid) fail("response valid straight after reset");
    // and the controller works again
    for (int i = 0; i < 16; i++) begin
      hbm_data_t d; d = rnd_data();
      enq(1, 0, 1, 20 + i, i, i, 0, 0, d, '1);
      enq(0, 0, 1, 20 + i, i, 32 + i, 0, 0, '0, '1);
    end
    drain();
    end_test("reset_behaviour");
  endtask


  // ------------------------------------------------------------------ feature tests
  task automatic inject(input int mode, input int bit_idx);
    @(negedge clk); inj_mode = 2'(mode); inj_bit = 9'(bit_idx); inj_arm = 1;
    @(negedge clk); inj_arm = 0; @(posedge clk);
  endtask
  task automatic ecc_clear_pulse();
    @(negedge clk); ecc_clear = 1; @(negedge clk); ecc_clear = 0; @(posedge clk);
  endtask

  task automatic t_ecc();
    hbm_data_t d1, d2, d3;
    longint ce0, ue0;
    begin_test("ecc_secded_and_fault_injection");
    ecc_en = 1; drain(); ecc_clear_pulse();
    d1 = rnd_data(); d2 = rnd_data(); d3 = rnd_data();
    // (a) clean write/read
    enq(1, 0, 0, 40, 1, 1, 0, 0, d1, '1); drain();
    enq_x(0, 0, 0, 40, 1, 2, '0, '1, -1, 0); drain();
    if (ecc_ce != 0 || ecc_ue != 0) fail("ECC counters non-zero on clean data");
    // (b) single-bit corruption injected into WRITE data after encoding -> read corrects it
    inject(1, 17);
    enq(1, 0, 0, 40, 2, 3, 0, 0, d2, '1); drain();
    enq_x(0, 0, 0, 40, 2, 4, d2, '1, -1, 1); drain();      // exp data = d2 (corrected), corrected flag = 1
    if (ecc_ce != 1 || ecc_ue != 0) fail($sformatf("after write-path single flip: CE=%0d UE=%0d (expected 1/0)", ecc_ce, ecc_ue));
    if (!ecc_lv || ecc_lue) fail("error log must hold a CORRECTED error");
    // (c) double-bit corruption -> uncorrectable, poisoned response
    inject(2, 100);
    enq(1, 0, 0, 40, 3, 5, 0, 0, d3, '1); drain();
    enq_x(0, 0, 0, 40, 3, 6, '0, '1, int'(HERR_ECC), -1); drain();
    if (ecc_ue != 1) fail($sformatf("UE count %0d, expected 1", ecc_ue));
    if (!ecc_alert) fail("maintenance alert not raised on an uncorrectable error");
    // (d) single flip on the READ path
    inject(3, 200);
    enq_x(0, 0, 0, 40, 1, 7, d1, '1, -1, 1); drain();
    if (ecc_ce != 2) fail($sformatf("CE count %0d after read-path flip, expected 2", ecc_ce));
    // (e) DRAM-side faults in the stored array (as a real DRAM bit error would be)
    ecc_clear_pulse(); ce0 = ecc_ce; ue0 = ecc_ue;
    for (int b = 0; b < 256; b += 37) begin
      hbm_data_t m; m = '0; m[b] = 1'b1;
      enq(1, 1, 1, 60, 1, 8, 0, 0, d1, '1); drain();
      dram.flip_bits(0, 1, 1, 60, 1, m);
      enq_x(0, 1, 1, 60, 1, 9, d1, '1, -1, 1); drain();
    end
    if (ecc_ce != 7 || ecc_ue != 0) fail($sformatf("DRAM-side single flips: CE=%0d UE=%0d (expected 7/0)", ecc_ce, ecc_ue));
    for (int b = 0; b < 256; b += 61) begin
      hbm_data_t m; m = '0; m[b] = 1'b1; m[(b + 7) % 256] = 1'b1;
      enq(1, 1, 1, 61, 1, 10, 0, 0, d2, '1); drain();
      dram.flip_bits(0, 1, 1, 61, 1, m);
      enq_x(0, 1, 1, 61, 1, 11, '0, '1, int'(HERR_ECC), -1); drain();
    end
    if (ecc_ue != 5) fail($sformatf("DRAM-side double flips: UE=%0d (expected 5)", ecc_ue));
    // (f) a flipped CHECK bit (all 10, incl. the overall-parity bit) is corrected and the data stays intact
    ecc_clear_pulse();
    for (int cb = 0; cb < 10; cb++) begin
      enq(1, 2, 2, 70, 1, 12, 0, 0, d3, '1); drain();
      // fetch the stored ECC word by reading it back through the model, then flip one bit of it
      begin
        hbm_data_t dd; hbm_ecc_t ee;
        dd = dram.mem[longint'(0) << 48 | longint'(2) << 44 | longint'(2) << 40 | longint'(70) << 16 | 1];
        ee = dram.ecc[longint'(0) << 48 | longint'(2) << 44 | longint'(2) << 40 | longint'(70) << 16 | 1];
        dram.poke(0, 2, 2, 70, 1, dd, ee ^ (hbm_ecc_t'(1) << cb));
      end
      enq_x(0, 2, 2, 70, 1, 13, d3, '1, -1, 1); drain();
    end
    if (ecc_ce != 10 || ecc_ue != 0) fail($sformatf("check-bit flips: CE=%0d UE=%0d (expected 10/0)", ecc_ce, ecc_ue));
    // (g) clear
    ecc_clear_pulse();
    if (ecc_ce != 0 || ecc_ue != 0 || ecc_lv || ecc_alert) fail("ECC clear did not zero counters / log / alert");
    ecc_en = 0; apply_cfg();
    end_test("ecc_secded_and_fault_injection");
  endtask

  task automatic t_ref_modes();
    longint r0;
    begin_test("refresh_per_bank_and_forced");
    // ---- per-bank refresh under traffic (only where the profile can sustain it: see hbm_profile_pb_ok)
    if (hbm_profile_pb_ok(4'(profile_sel))) begin
      ref_mode = 1; apply_cfg(); drain(); r0 = sum_ref;
      for (int round = 0; round < 5; round++) t_random(300, "  (pb inner)", 16, 50);
      if (sum_ref - r0 < 16) fail($sformatf("per-bank mode issued only %0d refresh commands", sum_ref - r0));
    end else
      $display("[TB]   per-bank refresh: N/A on profile %0d (trefi/16 too short for the serial per-bank sequence; hbm_profile_pb_ok=0)", profile_sel);
    // ---- all-bank, NOT eager (postpone while busy): ONE continuous saturating stream longer than (max_postpone+2)*tREFI
    //      must force refresh (idle-time refresh never gets a chance because the queue never empties)
    ref_mode = 0; ref_eager = 0; apply_cfg(); drain(); r0 = sum_ref;
    begin
      longint f0; int n;
      f0 = sum_forced;
      n = (int'(tp.max_postpone) + 3) * int'(tp.trefi) / 2;
      for (int i = 0; i < n; i++)
        enq($urandom % 2, $urandom % 4, $urandom % 4, $urandom % 24, $urandom % 64, $urandom % 256, 0, 0, rnd_data(), '1);
      drain(4000000);
      if (sum_ref - r0 < 3)  fail($sformatf("lazy refresh: only %0d refreshes", sum_ref - r0));
      if (sum_forced - f0 == 0) fail("lazy refresh under a continuous saturating stream never became URGENT/forced");
      $display("[TB]   lazy refresh: %0d refreshes, %0d forced, over a %0d-request stream", sum_ref - r0, sum_forced - f0, n);
    end
    ref_eager = 1; ref_mode = 0; apply_cfg();
    end_test("refresh_per_bank_and_forced");
  endtask

  task automatic wait_pwr(input int st, input int max_cycles);
    int n; n = 0;
    while (int'(pwr_state) != st && n < max_cycles) begin @(posedge clk); n++; end
    if (int'(pwr_state) != st) fail($sformatf("power state %0d never reached (stuck in %0d)", st, pwr_state));
  endtask

  task automatic t_power();
    begin_test("power_states_pd_sr_auto");
    drain(); ref_mode = 0; apply_cfg();
    // ---- power-down on request: quiesces, closes rows, enters PD; requests wake it (after the request is withdrawn)
    for (int i = 0; i < 20; i++) enq($urandom % 2, $urandom % 4, $urandom % 4, $urandom % 8, $urandom % 64, i, 0, 0, rnd_data(), '1);
    drain();
    pwr_req = 2'd1;
    wait_pwr(3, 2000); repeat (3) @(posedge clk);
    if (!dram.in_pd[0]) fail("controller says power-down but the DRAM model is not in power-down");
    repeat (50) @(posedge clk);
    pwr_req = 2'd0;
    for (int i = 0; i < 20; i++) enq($urandom % 2, $urandom % 4, $urandom % 4, $urandom % 8, $urandom % 64, i, 0, 0, rnd_data(), '1);
    drain();
    if (dram.in_pd[0]) fail("DRAM model still in power-down after traffic was served");
    if (res_pd == 0) fail("power-down residency counter did not count");
    // ---- self-refresh for longer than the refresh deadline: legal because the DRAM refreshes itself; exit clears debt
    pwr_req = 2'd2;
    wait_pwr(4, 2000); repeat (3) @(posedge clk);
    if (!dram.in_sr[0]) fail("controller says self-refresh but the DRAM model is not in self-refresh");
    repeat (6 * int'(tp.trefi)) @(posedge clk);
    pwr_req = 2'd0;
    for (int i = 0; i < 40; i++) enq($urandom % 2, $urandom % 4, $urandom % 4, $urandom % 8, $urandom % 64, i, 0, 0, rnd_data(), '1);
    drain();
    if (res_sr == 0) fail("self-refresh residency counter did not count");
    // ---- automatic entry by idle threshold, automatic wake on new work
    pd_idle_v = 16'd40; apply_cfg();
    repeat (200) @(posedge clk);
    if (int'(pwr_state) != 3) fail($sformatf("auto power-down did not engage (state %0d)", pwr_state));
    for (int i = 0; i < 10; i++) enq(0, i % 4, i % 4, 3, i, i, 0, 0, '0, '1);
    drain();
    pd_idle_v = 16'd0;
    // ---- randomised power requests interleaved with traffic: nothing may be lost and no timing rule may break
    for (int k = 0; k < 12; k++) begin
      pwr_req = 2'($urandom % 3);
      for (int i = 0; i < 8; i++) enq($urandom % 2, $urandom % 4, $urandom % 4, $urandom % 6, $urandom % 64, $urandom % 64, 0, 0, rnd_data(), '1);
      repeat ($urandom % 300) @(posedge clk);
      pwr_req = 2'd0;
      drain();
    end
    ref_mode = 0; apply_cfg();
    end_test("power_states_pd_sr_auto");
  endtask

  // ---------------------------------------------------------------- main
  string tname;
  int unsigned seed;
  int unsigned noreset = 0;
  string json_path;
  initial begin
    if (!$value$plusargs("TEST=%s", tname)) tname = "all";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    void'($value$plusargs("PROFILE=%d", profile_sel));
    void'($value$plusargs("POLICY=%d", policy));
    void'($value$plusargs("PAGE=%d", page_pol));
    void'($value$plusargs("BATCH=%d", batch_en));
    void'($value$plusargs("PRIO=%d", prio_en));
    void'($value$plusargs("REFMODE=%d", ref_mode));
    void'($value$plusargs("NORESET=%d", noreset));
    void'($value$plusargs("RSPRDY=%d", rsp_ready_pct));
    void'($value$plusargs("PHYSTALL=%d", phy_stall_pct));
    void'($value$plusargs("TRCADD=%d", trc_add));
    void'($value$plusargs("MAXPP=%d", maxpp_ovr));
    $urandom(seed);
    errors = 0; flushed = 0; accepted = 0; completed = 0; accepted_rd = 0; accepted_wr = 0; outstanding = 0;
    lat_sum = 0; lat_n = 0; bytes_rd = 0; bytes_wr = 0; max_occ = 0; busy_cycles = 0;
    sum_hit = 0; sum_empty = 0; sum_conf = 0; sum_act = 0; sum_pre = 0; sum_ref = 0; sum_forced = 0; sum_pullin = 0;
    sum_tstall = 0; sum_rstall = 0;
    apply_cfg();
    $display("[TB] tb_pc_single seed=%0d profile=%0d (%s) policy=%0d page=%0d batch=%0d prio=%0d refmode=%0d",
             seed, profile_sel, (hbm_profile_status(4'(profile_sel)) == 2'd0) ? "HYPOTHETICAL_SIM" : "VERIFIED", policy, page_pol, batch_en, prio_en, ref_mode);
    do_reset();

    if (PHY_BACKEND != 0) begin
      t_backend_stub();                                   // nothing else can run without a PHY
    end else begin
    if (tname == "all" || tname == "single_read")     t_single_read();
    if (tname == "all" || tname == "single_write")    t_single_write();
    if (tname == "all" || tname == "write_readback")  t_write_readback();
    if (tname == "all" || tname == "sequential")      t_sequential();
    if (tname == "all" || tname == "partial")         t_partial_writes();
    if (tname == "all" || tname == "hazards")         t_raw_waw_war();
    if (tname == "all" || tname == "random")          t_random(2000, "random_mixed_multi_outstanding", 32, 50);
    if (tname == "all" || tname == "random_hot")      t_random(2000, "random_row_locality_high", 2, 50);
    if (tname == "all" || tname == "policy")          t_policy_semantics();
    if (tname == "all" || tname == "starvation")      t_starvation();
    if (tname == "all" || tname == "backpressure")    t_backpressure();
    if (tname == "all" || tname == "saturation")      t_saturation();
    if (tname == "all" || tname == "refresh")         t_refresh_long();
    if (tname == "all" || tname == "ecc")             t_ecc();
    if (tname == "all" || tname == "refmodes")        t_ref_modes();
    if (tname == "all" || tname == "power")           t_power();
    if (tname == "all" || tname == "phy_events")      t_phy_events();
    if (tname == "all" || tname == "reinit")          t_reinit();
    if (tname == "longsat")                           t_longsat();
    if (tname == "all" || tname == "rowhammer")       t_rowhammer();
    if (tname == "all" || tname == "refswitch")       t_refswitch();
    if ((tname == "all" && !noreset) || tname == "reset") t_reset_behaviour();
    end

    // ---- final accounting ----
    drain();
    if (accepted != completed + flushed) fail($sformatf("accepted %0d != completed %0d + flushed-by-reset %0d (lost or duplicated response)", accepted, completed, flushed));
    foreach (expq[k]) if (expq[k].size() != 0) fail($sformatf("outstanding expectation left for key %0h", k));
    dram.report();
    $display("[TB] SUMMARY accepted=%0d (rd %0d wr %0d) completed=%0d cycles=%0d hit=%0d empty=%0d conflict=%0d act=%0d pre=%0d ref=%0d",
             accepted, accepted_rd, accepted_wr, completed, cyc, sum_hit, sum_empty, sum_conf, sum_act, sum_pre, sum_ref);
    if (lat_n != 0) $display("[TB] avg_latency=%0.1f cycles  max_queue_occ=%0d", real'(lat_sum) / real'(lat_n), max_occ);
    if ($value$plusargs("JSON=%s", json_path)) begin
      int f;
      f = $fopen(json_path, "w");
      $fdisplay(f, "{\"tb\":\"tb_pc_single\",\"seed\":%0d,\"profile\":%0d,\"policy\":%0d,\"accepted\":%0d,\"completed\":%0d,\"cycles\":%0d,\"row_hit\":%0d,\"row_empty\":%0d,\"row_conflict\":%0d,\"act\":%0d,\"pre\":%0d,\"refresh\":%0d,\"bytes_rd\":%0d,\"bytes_wr\":%0d,\"lat_avg\":%0.2f,\"violations\":%0d,\"errors\":%0d}",
                seed, profile_sel, policy, accepted, completed, cyc, sum_hit, sum_empty, sum_conf, sum_act, sum_pre, sum_ref,
                bytes_rd, bytes_wr, (lat_n != 0) ? real'(lat_sum)/real'(lat_n) : 0.0, viol_cnt, errors);
      $fclose(f);
    end
    if (errors == 0 && viol_cnt == 0) $display("RESULT: PASS  (tb_pc_single, %0d responses checked)", completed);
    else                              $display("RESULT: FAIL  (tb_pc_single, %0d errors, %0d DRAM violations)", errors, viol_cnt);
    $finish;
  end

  // global watchdog
  initial begin
    #50_000_000;
    $display("RESULT: FAIL  (tb_pc_single watchdog)");
    $finish;
  end
endmodule
