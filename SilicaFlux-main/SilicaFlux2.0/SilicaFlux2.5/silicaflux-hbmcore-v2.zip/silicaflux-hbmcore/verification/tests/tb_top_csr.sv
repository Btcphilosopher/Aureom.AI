// =============================================================================
//  tb_top_csr.sv  --  self-checking test of sf_hbm_top: the CSR register file, its connection to the controller and the
//  performance counters, driven ONLY through the register bus (rb_*) and the host request/response port.
//
//  PARAMETERS (-G): NCH (channels, 2 pseudo-channels each), CHCL, PERF_W (counter width; 6 = saturation build).
//  PLUSARGS: +JSON=<file>
//
//  WHAT IS CHECKED
//    reset_defaults      every register reads its documented reset value
//    rw_readback         every RW register stores and returns exactly the documented bit fields (incl. SCHED0 page policy
//                        and ADDRHI/MAXBURST) and the value reaches the controller (cfg_o / exported ports)
//    access_errors       writes to RO registers, reads of the WO register, unmapped addresses -> rb_err (RO value unchanged)
//    init_timeout        INITTO + CONTROL.enable: no power-good -> STATUS.init_error with the documented cause
//    bring_up_via_csr    CONTROL.enable + PHY handshakes -> STATUS.ready, init_state = READY
//    profile_flags       PROFINFO MHz, per-bank-refresh-infeasible flag (profile 0 + REFMODE PB)
//    traffic_perf        N writes + N reads (CH_IL map written through MAPCFG): data exact, aggregate AND per-pseudo-channel
//                        counters equal the testbench's own tallies, PERFSEL/PERFLO/PERFHI 64-bit access, snapshot, freeze, clear
//    perf_saturation     (PERF_W < 16) counters saturate at 2^PERF_W-1, STATUS.perf_overflow sets and CLEAR resets it
//    ecc_via_csr         ECCCFG + ECCINJ (single flip -> corrected, double flip -> HERR_ECC), ECCLOG, STATUS alert, ERRSTAT W1C, ECCCLR
//    dram_clean          the DRAM model's independent checker saw zero violations
// =============================================================================
`timescale 1ns/1ps
module tb_top_csr;
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;

  parameter int unsigned NCH    = 2;
  parameter int unsigned CHCL   = 2;
  parameter int unsigned PERF_W = 48;
  localparam int unsigned NPC     = NCH * 2;
  localparam int unsigned CH_BITS = (NCH > 1) ? $clog2(NCH) : 0;
  localparam int unsigned QD      = 16;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint unsigned cyc;
  always @(posedge clk) cyc <= rst_n ? cyc + 1 : 0;

  // ---------------------------------------------------------------- DUT
  logic rb_sel = 0, rb_we = 0; logic [11:0] rb_addr = 0; logic [31:0] rb_wdata = 0;
  logic [31:0] rb_rdata; logic rb_err;
  logic [7:0] addr_hi, max_burst_m1; hbm_cfg_t cfg;
  logic pg = 0, cs = 0, pid = 0, tdn = 0, phy_init_start, train_start, ready;
  logic req_valid = 0, req_ready; hbm_addr_t req_addr = '0; logic req_write = 0, req_fence = 0;
  hbm_id_t req_id = '0; hbm_src_t req_src = '0; hbm_qos_t req_qos = '0; hbm_order_e req_order = hbm_order_e'(0);
  hbm_data_t req_wdata = '0; hbm_mask_t req_wmask = '0;
  logic rsp_valid, rsp_ready = 1'b1; hbm_rsp_t rsp;
  logic [NPC-1:0] phy_ready, sim_cv, sim_wv, sim_rv, sim_rerr;
  hbm_cmd_t [NPC-1:0] sim_c; hbm_data_t [NPC-1:0] sim_wd, sim_rd; hbm_mask_t [NPC-1:0] sim_wm; hbm_ecc_t [NPC-1:0] sim_we, sim_re;
  logic [15:0] outstanding;

  sf_hbm_top #(.NUM_CHANNELS(NCH), .CH_PER_CLUSTER(CHCL), .DEPTH(QD), .PERF_CNT_W(PERF_W)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .rb_sel_i(rb_sel), .rb_we_i(rb_we), .rb_addr_i(rb_addr), .rb_wdata_i(rb_wdata), .rb_rdata_o(rb_rdata), .rb_err_o(rb_err),
    .addr_hi_o(addr_hi), .max_burst_m1_o(max_burst_m1), .cfg_o(cfg),
    .power_good_i(pg), .clk_stable_i(cs), .phy_init_done_i(pid), .train_done_i(tdn),
    .phy_init_start_o(phy_init_start), .train_start_o(train_start), .ready_o(ready),
    .req_valid_i(req_valid), .req_ready_o(req_ready), .req_addr_i(req_addr), .req_write_i(req_write), .req_fence_i(req_fence),
    .req_id_i(req_id), .req_src_i(req_src), .req_qos_i(req_qos), .req_order_i(req_order), .req_wdata_i(req_wdata), .req_wmask_i(req_wmask),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp),
    .phy_ready_ext_i(phy_ready), .phy_event_i('0), .ondie_event_i('0),
    .sim_cmd_valid_o(sim_cv), .sim_cmd_o(sim_c), .sim_wvalid_o(sim_wv), .sim_wdata_o(sim_wd), .sim_wmask_o(sim_wm), .sim_wecc_o(sim_we),
    .sim_rvalid_i(sim_rv), .sim_rdata_i(sim_rd), .sim_recc_i(sim_re), .sim_rerr_i(sim_rerr),
    .outstanding_o(outstanding)
  );

  hbm_timing_t tp; assign tp = hbm_profile(cfg.profile_sel);
  int unsigned viol_cnt, cmd_cnt;
  hbm4_dram_model #(.NUM_PC(NPC)) dram (
    .clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .viol_quiet_i(1'b0), .stall_pct_i(8'd0),
    .cmd_valid_i(sim_cv), .cmd_i(sim_c), .wvalid_i(sim_wv), .wdata_i(sim_wd), .wmask_i(sim_wm), .wecc_i(sim_we),
    .ready_o(phy_ready), .rvalid_o(sim_rv), .rdata_o(sim_rd), .recc_o(sim_re), .rerr_o(sim_rerr),
    .viol_cnt_o(viol_cnt), .cmd_cnt_o(cmd_cnt)
  );

  // ---------------------------------------------------------------- helpers
  int errors = 0;
  task automatic fail(input string m); errors++; $display("[TB][FAIL] %s", m); endtask
  int test_base;
  task automatic bt(input string n); test_base = errors; $display("[TB] ---- %s", n); endtask
  task automatic et(input string n); $display("[TB] TEST %-30s %s", n, (errors == test_base) ? "PASS" : "FAIL"); endtask

  logic [31:0] rd_val; logic rd_err, wr_err;
  task automatic csr_rd(input logic [11:0] a);
    @(negedge clk); rb_sel = 1; rb_we = 0; rb_addr = a; #1; rd_val = rb_rdata; rd_err = rb_err;
    @(negedge clk); rb_sel = 0;
  endtask
  task automatic csr_wr(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk); rb_sel = 1; rb_we = 1; rb_addr = a; rb_wdata = d; #1; wr_err = rb_err;
    @(negedge clk); rb_sel = 0; rb_we = 0;
  endtask
  task automatic chk(input logic [11:0] a, input logic [31:0] exp, input string what);
    csr_rd(a);
    if (rd_val !== exp || rd_err) fail($sformatf("%s: reg 0x%03h = 0x%08h (err=%0b), expected 0x%08h", what, a, rd_val, rd_err, exp));
  endtask
  task automatic wrchk(input logic [11:0] a, input logic [31:0] d, input logic [31:0] exp, input string what);
    csr_wr(a, d);
    if (wr_err) fail($sformatf("%s: write 0x%03h reported rb_err", what, a));
    chk(a, exp, what);
  endtask

  // register map (docs: top of rtl/sf_hbm_csr.sv)
  localparam logic [11:0] R_ID = 12'h000, R_GEO = 12'h001, R_CTL = 12'h002, R_STATUS = 12'h003, R_PROFILE = 12'h004, R_MAPCFG = 12'h005,
                          R_SCHED0 = 12'h006, R_SCHED1 = 12'h007, R_SCHED2 = 12'h008, R_REFCFG = 12'h009, R_POWER0 = 12'h00A,
                          R_POWER1 = 12'h00B, R_INITTO = 12'h00C, R_ECCCFG = 12'h00D, R_ECCINJ = 12'h00E, R_ECCCLR = 12'h00F,
                          R_ECCLOG = 12'h010, R_MAXBURST = 12'h011, R_ADDRHI = 12'h012, R_PERFCTL = 12'h020, R_PERFSEL = 12'h021,
                          R_PERFLO = 12'h022, R_PERFHI = 12'h023, R_ERRSTAT = 12'h030, R_PROFINFO = 12'h040;

  // aggregate / per-PC counter reads through PERFSEL / PERFLO / PERFHI
  function automatic longint unsigned join64(input logic [31:0] hi, input logic [31:0] lo); return {hi, lo}; endfunction
  longint unsigned perf_val;
  task automatic perf_read(input bit agg, input int pcn, input int cnt);
    logic [31:0] lo, hi;
    csr_wr(R_PERFSEL, {7'd0, agg, 2'd0, 6'(cnt), 16'(pcn)});
    csr_rd(R_PERFLO); lo = rd_val;
    csr_rd(R_PERFHI); hi = rd_val;
    perf_val = join64(hi, lo);
  endtask

  // ---- host port (one outstanding request at a time)
  longint unsigned rsp_cnt = 0; hbm_rsp_t last_rsp;
  always @(posedge clk) if (rsp_valid && rsp_ready) begin last_rsp <= rsp; rsp_cnt <= rsp_cnt + 1; end
  task automatic host_req(input bit wr, input longint unsigned addr, input hbm_data_t d, input hbm_mask_t m);
    longint unsigned c0; int w;
    c0 = rsp_cnt;
    @(negedge clk);
    req_valid = 1; req_addr = hbm_addr_t'(addr); req_write = wr; req_wdata = d; req_wmask = m;
    w = 0; @(posedge clk);
    while (!req_ready && w < 20000) begin @(posedge clk); w++; end
    if (w >= 20000) fail("host request never accepted");
    @(negedge clk); req_valid = 0;
    w = 0; while (rsp_cnt == c0 && w < 20000) begin @(posedge clk); w++; end
    if (w >= 20000) fail("no response");
    @(posedge clk);
  endtask
  function automatic hbm_data_t pat(input int g, input int salt);
    hbm_data_t d; for (int i = 0; i < 8; i++) d[i*32 +: 32] = 32'(32'h9E37_79B9 * (g * 8 + i + 1) + salt); return d;
  endfunction
  function automatic int pc_of(input longint unsigned addr, input hbm_map_e mode, input logic hash, input logic [2:0] il);
    hbm_loc_t l; l = hbm_map_addr(hbm_addr_t'(addr), mode, il, hash, 0, CH_BITS, 1); return int'(l.ch) * 2 + int'(l.pc);
  endfunction

  task automatic do_reset();
    rst_n = 0; pg = 0; cs = 0; pid = 0; tdn = 0; req_valid = 0; rb_sel = 0; rb_we = 0;
    repeat (4) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);
  endtask
  task automatic bring_up();
    pg = 0; cs = 0; pid = 0; tdn = 0;
    csr_wr(R_CTL, 32'd1);
    repeat (3) @(posedge clk); pg = 1; repeat (3) @(posedge clk); cs = 1;
    wait (phy_init_start); repeat (4) @(posedge clk); pid = 1;
    wait (train_start); repeat (6) @(posedge clk); tdn = 1;
    wait (ready); repeat (4) @(posedge clk);
  endtask

  localparam logic [31:0] ID_EXP = {16'h4842, 8'h01, 8'(HBM_TXN_VERSION)};

  // ---------------------------------------------------------------- tests
  hbm_data_t refm [longint unsigned];
  longint unsigned N_ACC = 48;

  initial begin
    $display("[TB] tb_top_csr NCH=%0d CHCL=%0d PERF_W=%0d", NCH, CHCL, PERF_W);
    do_reset();

    // ---------------------------------------------------------------- reset defaults
    bt("reset_defaults");
    chk(R_ID,      ID_EXP, "ID");
    chk(R_GEO,     {8'd1, 8'(NCH), 8'(CHCL), 8'(QD)}, "GEOMETRY");
    chk(R_CTL,     32'd0, "CONTROL");
    chk(R_STATUS,  32'd0, "STATUS (idle: not ready, no error, HYPOTHETICAL_SIM, nothing flagged)");
    chk(R_PROFILE, 32'd1, "PROFILE");
    chk(R_MAPCFG,  32'd0, "MAPCFG");
    chk(R_SCHED0,  32'(SCHED_FRFCFS), "SCHED0");
    chk(R_SCHED1,  32'd8, "SCHED1 (batch_len 8)");
    chk(R_SCHED2,  {16'd32, 16'd0}, "SCHED2 (close_timeout 32)");
    // v2: REFCFG also holds the refresh-management defaults: raa_ref_dec 16, raammt 64, raaimt 32, rfm off
    chk(R_REFCFG,  {8'd16, 8'd64, 8'd32, 8'b0000_0100}, "REFCFG (AB, eager, RFM defaults)");
    chk(R_POWER0,  32'd0, "POWER0"); chk(R_POWER1, 32'd0, "POWER1");
    chk(R_INITTO,  32'd100000, "INITTO"); chk(R_ECCCFG, 32'd0, "ECCCFG"); chk(R_ECCINJ, 32'd0, "ECCINJ");
    chk(R_ECCLOG,  32'd0, "ECCLOG"); chk(R_MAXBURST, 32'd31, "MAXBURST"); chk(R_ADDRHI, 32'd0, "ADDRHI");
    chk(R_PERFCTL, 32'd0, "PERFCTL"); chk(R_PERFSEL, 32'd0, "PERFSEL"); chk(R_PERFLO, 32'd0, "PERFLO"); chk(R_PERFHI, 32'd0, "PERFHI");
    chk(R_ERRSTAT, 32'd0, "ERRSTAT"); chk(R_PROFINFO, 32'd1000, "PROFINFO (sim_ref clock, informational)");
    et("reset_defaults");

    // ---------------------------------------------------------------- RW readback + propagation
    bt("rw_readback");
    wrchk(R_PROFILE, 32'd2, 32'd2, "PROFILE");                         if (cfg.profile_sel !== 4'd2) fail("PROFILE did not reach cfg_o");
    chk(R_PROFINFO, 32'd1000, "PROFINFO follows the selected profile");
    wrchk(R_PROFILE, 32'd1, 32'd1, "PROFILE restore");
    wrchk(R_MAPCFG, {23'd0, 1'b1, 3'd0, 3'd5, 2'd2}, {23'd0, 1'b1, 3'd0, 3'd5, 2'd2}, "MAPCFG");
    if (cfg.map_mode !== MAP_BANK_AWARE || cfg.il_bits !== 3'd5 || cfg.map_hash !== 1'b1) fail("MAPCFG did not reach cfg_o");
    wrchk(R_MAPCFG, 32'd0, 32'd0, "MAPCFG restore");
    // SCHED0: policy 2, prio, batch, deadline, page = TIMEOUT(2): {page[9:8], deadline[6], batch[5], prio[4], policy[2:0]}
    wrchk(R_SCHED0, {22'd0, 2'd2, 1'b0, 1'b1, 1'b1, 1'b1, 1'b0, 3'd2}, {22'd0, 2'd2, 1'b0, 1'b1, 1'b1, 1'b1, 1'b0, 3'd2}, "SCHED0 (page readback)");
    if (cfg.sched.page !== PAGE_TIMEOUT || cfg.sched.policy !== hbm_sched_policy_e'(3'd2) || !cfg.sched.prio_en || !cfg.sched.batch_en || !cfg.sched.deadline_en)
      fail("SCHED0 did not reach cfg_o");
    wrchk(R_SCHED0, {22'd0, 2'd1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 3'd1}, {22'd0, 2'd1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 3'd1}, "SCHED0 page=CLOSE");
    if (cfg.sched.page !== PAGE_CLOSE) fail("page policy CLOSE did not reach cfg_o");
    wrchk(R_SCHED0, 32'(SCHED_FRFCFS), 32'(SCHED_FRFCFS), "SCHED0 restore");
    wrchk(R_SCHED1, 32'h00AB_CD07, 32'h00AB_CD07, "SCHED1");           if (cfg.sched.starve_limit !== 16'hABCD || cfg.sched.batch_len !== 8'h07) fail("SCHED1 did not reach cfg_o");
    wrchk(R_SCHED1, 32'd8, 32'd8, "SCHED1 restore");
    wrchk(R_SCHED2, 32'h1234_5678, 32'h1234_5678, "SCHED2");           if (cfg.sched.deadline_thr !== 16'h5678 || cfg.sched.close_timeout !== 16'h1234) fail("SCHED2 did not reach cfg_o");
    wrchk(R_SCHED2, {16'd32, 16'd0}, {16'd32, 16'd0}, "SCHED2 restore");
    wrchk(R_REFCFG, 32'b1101, 32'b1101, "REFCFG");                     if (cfg.ref_cfg.mode !== REFMODE_PB || !cfg.ref_cfg.eager || !cfg.ref_cfg.pullin_en) fail("REFCFG did not reach cfg_o");
    wrchk(R_REFCFG, 32'b0100, 32'b0100, "REFCFG restore");
    wrchk(R_POWER0, 32'd2, 32'd2, "POWER0");                           if (cfg.pwr_req !== 2'd2) fail("POWER0 did not reach cfg_o");
    wrchk(R_POWER0, 32'd0, 32'd0, "POWER0 restore");
    wrchk(R_POWER1, 32'h0123_4567, 32'h0123_4567, "POWER1");           if (cfg.pd_idle !== 16'h4567 || cfg.sr_idle !== 16'h0123) fail("POWER1 did not reach cfg_o");
    wrchk(R_POWER1, 32'd0, 32'd0, "POWER1 restore");
    wrchk(R_INITTO, 32'hDEAD_BEEF, 32'hDEAD_BEEF, "INITTO");           if (cfg.init_timeout !== 32'hDEAD_BEEF) fail("INITTO did not reach cfg_o");
    wrchk(R_INITTO, 32'd100000, 32'd100000, "INITTO restore");
    wrchk(R_ECCCFG, 32'd1, 32'd1, "ECCCFG");                           if (!cfg.ecc_en) fail("ECCCFG did not reach cfg_o");
    wrchk(R_ECCCFG, 32'd0, 32'd0, "ECCCFG restore");
    // ECCINJ without the arm bit stores fields only: {pc[31:16], bit[10:2], mode[1:0]}
    wrchk(R_ECCINJ, {16'd3, 5'd0, 9'h1A5, 2'd2}, {16'd3, 5'd0, 9'h1A5, 2'd2}, "ECCINJ");
    wrchk(R_ECCINJ, 32'd0, 32'd0, "ECCINJ restore");
    wrchk(R_MAXBURST, 32'h15, 32'h15, "MAXBURST");                     if (max_burst_m1 !== 8'h15 || cfg.max_burst_m1 !== 8'h15) fail("MAXBURST not exported");
    wrchk(R_MAXBURST, 32'd31, 32'd31, "MAXBURST restore");
    wrchk(R_ADDRHI, 32'hA5, 32'hA5, "ADDRHI");                         if (addr_hi !== 8'hA5) fail("ADDRHI not exported");
    wrchk(R_ADDRHI, 32'd0, 32'd0, "ADDRHI restore");
    wrchk(R_PERFCTL, 32'd1, 32'd1, "PERFCTL freeze");  wrchk(R_PERFCTL, 32'd0, 32'd0, "PERFCTL unfreeze");
    wrchk(R_PERFSEL, {7'd0, 1'b1, 2'd0, 6'd5, 16'd2}, {7'd0, 1'b1, 2'd0, 6'd5, 16'd2}, "PERFSEL");
    wrchk(R_PERFSEL, 32'd0, 32'd0, "PERFSEL restore");
    et("rw_readback");

    // ---------------------------------------------------------------- access errors
    bt("access_errors");
    begin
      logic [11:0] ro [7] = '{R_ID, R_GEO, R_STATUS, R_ECCLOG, R_PERFLO, R_PERFHI, R_PROFINFO};
      logic [31:0] old_v;
      for (int i = 0; i < 7; i++) begin
        csr_rd(ro[i]); old_v = rd_val;
        csr_wr(ro[i], 32'hFFFF_FFFF);
        if (!wr_err) fail($sformatf("write to RO register 0x%03h did not report rb_err", ro[i]));
        csr_rd(ro[i]);
        if (rd_val !== old_v) fail($sformatf("write to RO register 0x%03h changed it: 0x%08h -> 0x%08h", ro[i], old_v, rd_val));
      end
    end
    csr_rd(R_ECCCLR); if (!rd_err) fail("read of the write-only ECCCLR did not report rb_err");
    csr_wr(R_ECCCLR, 32'd1); if (wr_err) fail("write to ECCCLR reported rb_err");
    csr_rd(12'h7FF); if (!rd_err || rd_val !== 32'd0) fail($sformatf("unmapped read: err=%0b data=0x%08h (expected err, 0)", rd_err, rd_val));
    csr_wr(12'h0FF, 32'h1234); if (!wr_err) fail("write to an unmapped address did not report rb_err");
    csr_rd(12'h013); if (!rd_err) fail("read of the reserved 0x013 did not report rb_err");
    @(negedge clk); rb_sel = 0; rb_addr = 12'h7FF; #1; if (rb_err || rb_rdata !== 32'd0) fail("rb_err / rb_rdata asserted without rb_sel");
    et("access_errors");

    // ---------------------------------------------------------------- init time-out (no power-good) through INITTO
    bt("init_timeout");
    csr_wr(R_INITTO, 32'd40); csr_wr(R_CTL, 32'd1);
    repeat (120) @(posedge clk);
    csr_rd(R_STATUS);
    if (!rd_val[1] || rd_val[4:2] !== 3'd1 || rd_val[0]) fail($sformatf("no power-good: STATUS=0x%08h (expected init_error=1 cause=1 ready=0)", rd_val));
    csr_wr(R_CTL, 32'd0); repeat (4) @(posedge clk);
    csr_rd(R_STATUS); if (rd_val[1] || rd_val[0]) fail($sformatf("enable=0 did not clear the init error: STATUS=0x%08h", rd_val));
    csr_wr(R_INITTO, 32'd100000);
    et("init_timeout");

    // ---------------------------------------------------------------- profile 0 + per-bank refresh flag (done BEFORE bring-up: with the controller disabled no refresh runs, so the infeasible configuration can be inspected without
    // the DRAM model - correctly - flagging the refresh-deadline violation that this configuration would cause if it were run)
    bt("profile_flags_pb_infeasible");
    csr_wr(R_REFCFG, 32'b0101); csr_wr(R_PROFILE, 32'd0); repeat (2) @(posedge clk);
    csr_rd(R_STATUS); if (!rd_val[13]) fail("per-bank refresh on sim_fast not flagged infeasible (STATUS[13])");
    chk(R_PROFINFO, 32'd1000, "PROFINFO sim_fast");
    csr_wr(R_PROFILE, 32'd1); csr_wr(R_REFCFG, 32'b0100); repeat (2) @(posedge clk);
    csr_rd(R_STATUS); if (rd_val[13]) fail("infeasible flag stuck");
    et("profile_flags_pb_infeasible");

    // ---------------------------------------------------------------- bring-up through the CSR
    bt("bring_up_via_csr");
    bring_up();
    chk(R_STATUS, {18'd0, 1'b0, 1'b0, 1'b0, (PERF_W < 16) ? 1'b1 : 1'b0, 2'd0, 3'd6, 3'd0, 1'b0, 1'b1}, "STATUS ready (init_state READY=6; perf_overflow only in the narrow-counter build)");
    et("bring_up_via_csr");

    // ---------------------------------------------------------------- profile flags
    bt("profile_flags");
    wrchk(R_REFCFG, 32'b0101, 32'b0101, "REFCFG PB");                      // per-bank refresh on profile 1 = feasible
    csr_rd(R_STATUS); if (rd_val[13]) fail("per-bank refresh flagged infeasible on sim_ref");
    wrchk(R_REFCFG, 32'b0100, 32'b0100, "REFCFG AB");
    et("profile_flags");

    // ---------------------------------------------------------------- traffic + performance counters (map set THROUGH the CSR)
    bt("traffic_perf");
    wrchk(R_MAPCFG, {23'd0, 1'b0, 3'd0, 3'd0, 2'(MAP_CH_IL)}, {23'd0, 1'b0, 3'd0, 3'd0, 2'(MAP_CH_IL)}, "MAPCFG CH_IL");
    csr_wr(R_PERFCTL, 32'h10);                                              // clear
    begin
      int pcw [NPC], pcr [NPC]; longint unsigned nbad = 0;
      for (int p = 0; p < NPC; p++) begin pcw[p] = 0; pcr[p] = 0; end
      for (int g = 0; g < N_ACC; g++) begin
        longint unsigned a; a = longint'(g) * 32; host_req(1, a, pat(g, 1), '1);
        refm[a] = pat(g, 1); pcw[pc_of(a, MAP_CH_IL, 1'b0, 3'd0)]++;
        if (last_rsp.err !== HERR_NONE || !last_rsp.write) fail($sformatf("write %0d response err=%0d write=%0b", g, last_rsp.err, last_rsp.write));
      end
      for (int g = 0; g < N_ACC; g++) begin
        longint unsigned a; a = longint'(g) * 32; host_req(0, a, '0, '0); pcr[pc_of(a, MAP_CH_IL, 1'b0, 3'd0)]++;
        if (last_rsp.err !== HERR_NONE || last_rsp.write || last_rsp.data !== refm[a] || last_rsp.corrected) begin nbad++; end
      end
      if (nbad != 0) fail($sformatf("%0d of %0d reads returned wrong data / error", nbad, N_ACC));
      repeat (40) @(posedge clk);
      csr_wr(R_PERFCTL, 32'h21);                                            // freeze + snapshot (aggregate shadow)
      repeat (3) @(posedge clk);
      if (PERF_W >= 16) begin
        perf_read(1, 0, 1); if (perf_val != N_ACC) fail($sformatf("aggregate acc_rd = %0d, expected %0d", perf_val, N_ACC));
        perf_read(1, 0, 2); if (perf_val != N_ACC) fail($sformatf("aggregate acc_wr = %0d, expected %0d", perf_val, N_ACC));
        perf_read(1, 0, 3); if (perf_val != N_ACC) fail($sformatf("aggregate cmp_rd = %0d, expected %0d", perf_val, N_ACC));
        perf_read(1, 0, 4); if (perf_val != N_ACC) fail($sformatf("aggregate cmp_wr = %0d, expected %0d", perf_val, N_ACC));
        perf_read(1, 0, 5); if (perf_val != N_ACC * 32) fail($sformatf("aggregate bytes_rd = %0d, expected %0d", perf_val, N_ACC * 32));
        perf_read(1, 0, 6); if (perf_val != N_ACC * 32) fail($sformatf("aggregate bytes_wr = %0d, expected %0d", perf_val, N_ACC * 32));
        perf_read(1, 0, 0); if (perf_val == 0) fail("aggregate cycle counter is 0");
        perf_read(1, 0, 28); if (perf_val != 0) fail($sformatf("aggregate violations = %0d", perf_val));
        for (int p = 0; p < NPC; p++) begin                                  // per-PC counters (live, read under freeze)
          perf_read(0, p, 0); if (perf_val != pcr[p]) fail($sformatf("PC%0d acc_rd = %0d, expected %0d", p, perf_val, pcr[p]));
          perf_read(0, p, 1); if (perf_val != pcw[p]) fail($sformatf("PC%0d acc_wr = %0d, expected %0d", p, perf_val, pcw[p]));
          perf_read(0, p, 4); if (perf_val != pcr[p] * 32) fail($sformatf("PC%0d bytes_rd = %0d", p, perf_val));
        end
        perf_read(0, NPC, 0); if (perf_val != 0) fail("per-PC read of a non-existent pseudo-channel did not return 0");
        // the snapshot bank does not move without a new snapshot, even while the live counters would (after unfreeze + idle cycles)
        perf_read(1, 0, 0); begin longint unsigned c0; c0 = perf_val;
          csr_wr(R_PERFCTL, 32'd0); repeat (50) @(posedge clk); perf_read(1, 0, 0);
          if (perf_val != c0) fail("aggregate snapshot changed without a new snapshot"); end
        csr_wr(R_PERFCTL, 32'h20); repeat (3) @(posedge clk); perf_read(1, 0, 0);
        if (perf_val == 0) fail("new snapshot did not refresh the aggregate cycle counter");
      end else begin
        // saturation build: counters are PERF_W bits wide, saturating
        perf_read(1, 0, 0);
        if (perf_val != (64'd1 << PERF_W) - 1) fail($sformatf("cycle counter did not saturate: %0d (expected %0d)", perf_val, (64'd1 << PERF_W) - 1));
        csr_rd(R_STATUS); if (!rd_val[10]) fail("STATUS.perf_overflow not set after saturation");
      end
      // clear: counters and the overflow flag go to zero (works while not frozen too)
      csr_wr(R_PERFCTL, 32'h10); repeat (2) @(posedge clk);
      csr_wr(R_PERFCTL, 32'h20); repeat (3) @(posedge clk);                 // the snapshot reads the cleared aggregates
      perf_read(1, 0, 1); if (perf_val != 0) fail("CLEAR did not zero acc_rd");
      csr_rd(R_STATUS); if (rd_val[10]) fail("CLEAR did not reset STATUS.perf_overflow");
    end
    wrchk(R_MAPCFG, 32'd0, 32'd0, "MAPCFG LINEAR restore");
    et("traffic_perf");

    // ---------------------------------------------------------------- RAS through the CSR
    bt("ecc_via_csr");
    begin
      longint unsigned a; int p; hbm_data_t d;
      csr_wr(R_MAPCFG, {23'd0, 1'b0, 3'd0, 3'd0, 2'(MAP_CH_IL)});
      csr_wr(R_ECCCFG, 32'd1);
      csr_wr(R_ECCCLR, 32'd1);
      // single flip of the next write data (mode 1) on the pseudo-channel of granule 200
      a = 200 * 32; p = pc_of(a, MAP_CH_IL, 1'b0, 3'd0); d = pat(200, 7);
      csr_wr(R_ECCINJ, {16'(p), 3'd0, 1'b1, 1'b0, 9'd5, 2'd1});           // bit 12 = arm, injection bit 5, mode 1
      host_req(1, a, d, '1);
      host_req(0, a, '0, '0);
      if (last_rsp.err !== HERR_NONE || last_rsp.data !== d || !last_rsp.corrected) fail($sformatf("single flip: err=%0d corrected=%0b datamatch=%0b", last_rsp.err, last_rsp.corrected, last_rsp.data === d));
      csr_rd(R_ECCLOG);
      if (!rd_val[9] || rd_val[10] || rd_val[8:0] === 9'd0 || rd_val[31:16] !== 16'(p)) fail($sformatf("ECCLOG after CE = 0x%08h (valid=1 ue=0 syndrome!=0 pc=%0d expected)", rd_val, p));
      csr_rd(R_STATUS); if (rd_val[12]) fail("ECC alert set by a CORRECTED error (alert = uncorrectable only)");
      perf_read(0, p, 19); if (PERF_W >= 16 && perf_val != 1) fail($sformatf("per-PC ecc_ce = %0d, expected 1", perf_val));
      // double flip (mode 2) -> uncorrectable
      a = 201 * 32; p = pc_of(a, MAP_CH_IL, 1'b0, 3'd0); d = pat(201, 7);
      csr_wr(R_ECCINJ, {16'(p), 3'd0, 1'b1, 1'b0, 9'd40, 2'd2});
      host_req(1, a, d, '1);
      host_req(0, a, '0, '0);
      if (last_rsp.err !== HERR_ECC) fail($sformatf("double flip: err=%0d (expected HERR_ECC)", last_rsp.err));
      csr_rd(R_STATUS); if (!rd_val[12]) fail("STATUS.ecc_alert_any not set after an uncorrectable error");
      csr_rd(R_ERRSTAT); if (!rd_val[3]) fail("ERRSTAT.ue sticky not set");
      csr_wr(R_ERRSTAT, 32'h7); csr_rd(R_ERRSTAT); if (!rd_val[3]) fail("W1C of other bits cleared the ue sticky");
      csr_wr(R_ERRSTAT, 32'h8); csr_rd(R_ERRSTAT); if (rd_val[3]) fail("W1C did not clear the ue sticky");
      csr_rd(R_ERRSTAT); if (rd_val[0] || rd_val[1] || rd_val[2]) fail($sformatf("unexpected sticky error bits 0x%0h (violation/protocol/deadline must stay 0)", rd_val[3:0]));
      // ECCCLR clears log, alert and counters
      csr_wr(R_ECCCLR, 32'd1); repeat (3) @(posedge clk);
      csr_rd(R_ECCLOG); if (rd_val[9]) fail("ECCCLR did not clear the ECC log");
      csr_rd(R_STATUS); if (rd_val[12]) fail("ECCCLR did not clear the alert");
      csr_wr(R_ECCCFG, 32'd0);
    end
    et("ecc_via_csr");

    bt("dram_clean");
    if (viol_cnt != 0) fail($sformatf("DRAM model reported %0d timing/state violations", viol_cnt));
    csr_rd(R_ERRSTAT); if (rd_val[0]) fail("ERRSTAT.violation sticky set");
    $display("[TB] commands at the DRAM boundary: %0d, violations: %0d", cmd_cnt, viol_cnt);
    et("dram_clean");

    if (errors == 0) $display("RESULT: PASS  (tb_top_csr NCH=%0d PERF_W=%0d)", NCH, PERF_W);
    else             $display("RESULT: FAIL  (tb_top_csr NCH=%0d PERF_W=%0d, %0d errors)", NCH, PERF_W, errors);
    $finish;
  end
  initial begin #50_000_000; $display("RESULT: FAIL  (tb_top_csr watchdog)"); $finish; end
endmodule
