// =============================================================================
//  tb_ctrl_multi.sv  --  self-checking testbench for sf_hbm4_controller (1..32+ channels) + hbm4_dram_model
//
//  PARAMETERS (-G): NCH channels per stack (1,2,4,8,32), CHCL channels per cluster, NSTK stacks, QD queue depth.
//  PLUSARGS: +TEST=<name|all> +SEED=<n> +PROFILE=<0..2> +POLICY=<0..2> +MAP=<0..2> +IL=<0..6> +HASH=<0/1>
//            +JSON=<file> +HBM_TRACE=<file> +TXLOG=<file>
//
//  WHAT IS CHECKED (every accepted request, by scoreboard):
//    * data   : reads return the reference-memory value in request-ACCEPTANCE order (byte-masked writes)
//    * owner  : a response is delivered only for a {src,id} that has an outstanding request; its `src` matches
//    * order  : same-{src,id} responses return in request order
//    * 1:1    : exactly one response per request (no loss, no duplicate); fence semantics
//    * errors : out-of-range / misaligned / partial-write-with-ECC give the expected error code and change nothing
//    * mapping: for every accepted non-error request the DRAM boundary sees exactly ONE column command with the
//               expected {pc,bg,ba,row,col,rd/wr}; nothing else touches a pseudo-channel (channel isolation)
//    * timing : the DRAM model's independent checker reports zero violations
//  Benchmarks (+TEST=bench_*) reuse the same machinery and write a JSON result.
// =============================================================================
`timescale 1ns/1ps
module tb_ctrl_multi;
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;

  parameter int unsigned NCH  = 4;
  parameter int unsigned CHCL = 2;
  parameter int unsigned NSTK = 1;
  parameter int unsigned QD   = 16;
  localparam int unsigned NPC = NSTK * NCH * 2;
  localparam int unsigned NSRC = 4;
  localparam int unsigned NS_BITS = (NSTK > 1) ? $clog2(NSTK) : 0;
  localparam int unsigned CH_BITS = (NCH > 1) ? $clog2(NCH) : 0;
  localparam int unsigned CAP_BITS = hbm_cap_bits(NS_BITS, CH_BITS, 1);

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint unsigned cyc;
  always @(posedge clk) cyc <= rst_n ? cyc + 1 : 0;

  // ------------------------------------------------------------------ DUT wiring
  hbm_cfg_t cfg;
  logic pg = 0, cs = 0, pid = 0, tdn = 0;
  logic phy_init_start, train_start, ready, init_err;
  logic [2:0] init_cause, init_state;
  logic req_valid, req_ready;
  hbm_addr_t req_addr;
  logic req_write, req_fence;
  hbm_id_t req_id; hbm_src_t req_src; hbm_qos_t req_qos; hbm_order_e req_order;
  hbm_data_t req_wdata; hbm_mask_t req_wmask;
  logic rsp_valid, rsp_ready; hbm_rsp_t rsp;

  logic [NPC-1:0] phy_ready, sim_cv, sim_wv, sim_rv, sim_rerr;
  hbm_cmd_t  [NPC-1:0] sim_c;
  hbm_data_t [NPC-1:0] sim_wd, sim_rd;
  hbm_mask_t [NPC-1:0] sim_wm;
  hbm_ecc_t  [NPC-1:0] sim_we, sim_re;
  hbm_pc_stat_t [NPC-1:0] stat;
  logic ev_acc, ev_acc_rd, ev_acc_wr, ev_err, ev_sid, ev_sq, ev_sf;
  logic [15:0] outstanding;

  logic ecc_clear = 0, inj_arm = 0; logic [15:0] inj_pc = 0; logic [1:0] inj_mode = 0; logic [8:0] inj_bit = 0;

  sf_hbm4_controller #(.NUM_STACKS(NSTK), .NUM_CHANNELS(NCH), .CH_PER_CLUSTER(CHCL), .DEPTH(QD)) dut (
    .clk_i(clk), .rst_ni(rst_n), .cfg_i(cfg),
    .power_good_i(pg), .clk_stable_i(cs), .phy_init_done_i(pid), .train_done_i(tdn),
    .phy_init_start_o(phy_init_start), .train_start_o(train_start), .ready_o(ready),
    .init_error_o(init_err), .init_cause_o(init_cause), .init_state_o(init_state),
    .req_valid_i(req_valid), .req_ready_o(req_ready), .req_addr_i(req_addr), .req_write_i(req_write),
    .req_fence_i(req_fence), .req_id_i(req_id), .req_src_i(req_src), .req_qos_i(req_qos), .req_order_i(req_order),
    .req_wdata_i(req_wdata), .req_wmask_i(req_wmask),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp),
    .ecc_clear_i(ecc_clear), .inj_arm_i(inj_arm), .inj_pc_i(inj_pc), .inj_mode_i(inj_mode), .inj_bit_i(inj_bit),
    .phy_ready_ext_i(phy_ready), .phy_event_i('0), .ondie_event_i('0),
    .sim_cmd_valid_o(sim_cv), .sim_cmd_o(sim_c), .sim_wvalid_o(sim_wv), .sim_wdata_o(sim_wd),
    .sim_wmask_o(sim_wm), .sim_wecc_o(sim_we),
    .sim_rvalid_i(sim_rv), .sim_rdata_i(sim_rd), .sim_recc_i(sim_re), .sim_rerr_i(sim_rerr),
    .stat_o(stat), .ev_accept_o(ev_acc), .ev_accept_rd_o(ev_acc_rd), .ev_accept_wr_o(ev_acc_wr),
    .ev_err_req_o(ev_err), .ev_stall_id_o(ev_sid), .ev_stall_q_o(ev_sq), .ev_stall_fence_o(ev_sf),
    .outstanding_o(outstanding)
  );

  hbm_timing_t tp;
  assign tp = hbm_profile(cfg.profile_sel);
  int unsigned viol_cnt, cmd_cnt;
  logic [7:0] stall_pct = 8'd0;
  logic viol_quiet = 1'b0;
  hbm4_dram_model #(.NUM_PC(NPC)) dram (
    .clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .viol_quiet_i(viol_quiet), .stall_pct_i(stall_pct),
    .cmd_valid_i(sim_cv), .cmd_i(sim_c), .wvalid_i(sim_wv), .wdata_i(sim_wd), .wmask_i(sim_wm), .wecc_i(sim_we),
    .ready_o(phy_ready), .rvalid_o(sim_rv), .rdata_o(sim_rd), .recc_o(sim_re), .rerr_o(sim_rerr),
    .viol_cnt_o(viol_cnt), .cmd_cnt_o(cmd_cnt)
  );

  // perf block (cross-checked against the TB's own tallies)
  logic [63:0] perf_rd; logic perf_ovf;
  logic perf_clear = 0, perf_snap = 0, perf_freeze = 0, perf_agg = 1;
  logic [15:0] perf_pc = 0; logic [5:0] perf_cnt = 0;
  sf_hbm_perf #(.N(NPC), .CNT_W(48), .PER_PC_EN(1)) perf (
    .clk_i(clk), .rst_ni(rst_n), .stat_i(stat), .ev_stall_id_i(ev_sid), .ev_stall_q_i(ev_sq), .ev_stall_fence_i(ev_sf),
    .clear_i(perf_clear), .snap_i(perf_snap), .freeze_i(perf_freeze),
    .sel_pc_i(perf_pc), .sel_cnt_i(perf_cnt), .sel_agg_i(perf_agg), .rdata_o(perf_rd), .ovf_o(perf_ovf)
  );

  // ------------------------------------------------------------------ scoreboard state
  typedef struct { bit write; bit fence; int src, id, qos; hbm_addr_t addr; hbm_data_t data; hbm_mask_t mask; hbm_order_e ord; } item_t;
  typedef struct { bit write; bit fence; hbm_data_t data; hbm_err_e err; longint t_acc; longint key; } exp_t;

  item_t     pend [$];
  exp_t      expq [int][$];
  hbm_data_t refmem [longint];
  longint    exp_cmd_cnt [longint];
  longint    obs_cmd_cnt [longint];
  int        outstanding_tb;
  longint    accepted, completed, flushed, acc_rd, acc_wr, err_resp_n;
  int        errors;
  longint    lat_sum, lat_n, bytes_rd, bytes_wr;
  real       lat_list_dummy;
  int        lat_arr [$];
  longint    pc_busy [int];
  longint    pc_bytes [int];
  longint    sum_hit, sum_empty, sum_conf, sum_act, sum_pre, sum_ref, sum_tstall, sum_rstall, sum_busy_all, sum_sid, sum_sq, sum_sf;
  longint    pc_cmds [int];
  longint    own_cnt [int];
  longint    t_first, t_last;
  int unsigned gate_pct = 100, rsp_ready_pct = 100, phy_stall_pct = 0;
  int unsigned map_mode = 1, il = 0, hash = 0, profile_sel = 1, policy = 1, page_pol = 0;
  bit ecc_on = 0, prio_on = 0, batch_on = 0;
  int unsigned tracked_lat_max;
  int test_fail_base;
  string json_path, txlog_path;
  int txlog_fd;

  function automatic longint gkey(hbm_addr_t a);
    return longint'(a >> HBM_OFF_W);
  endfunction

  function automatic hbm_data_t rnd_data();
    hbm_data_t d;
    for (int i = 0; i < 8; i++) d[i*32 +: 32] = $urandom;
    return d;
  endfunction

  function automatic hbm_mask_t rnd_mask(int mode);
    case (mode)
      0: return '1;
      1: return hbm_mask_t'($urandom);
      default: return hbm_mask_t'(32'd1 << ($urandom % 32));
    endcase
  endfunction

  function automatic hbm_err_e expected_err(hbm_addr_t a, bit w, hbm_mask_t m);
    if ((a >> CAP_BITS) != 0) return HERR_RANGE;
    if (a[HBM_OFF_W-1:0] != 0) return HERR_MISALIGN;
    if (w && ecc_on && m != '1) return HERR_POLICY;
    return HERR_NONE;
  endfunction

  // expected DRAM location of an address under the current mapping
  function automatic longint cmd_key(hbm_addr_t a, bit w);
    hbm_loc_t l;
    int pcg;
    l = hbm_map_addr(a, hbm_map_e'(map_mode[1:0]), il[2:0], hash[0], NS_BITS, CH_BITS, 1);
    pcg = ((int'(l.stk) * NCH) + int'(l.ch)) * 2 + int'(l.pc);
    return (longint'(pcg) << 48) | (longint'(w) << 47) | (longint'(l.bg) << 44) | (longint'(l.ba) << 40) |
           (longint'(l.row) << 16) | longint'(l.col);
  endfunction

  task automatic fail(input string msg);
    errors++;
    $display("[TB][FAIL] cycle %0d: %s", cyc, msg);
  endtask

  // ------------------------------------------------------------------ driver
  item_t cur;
  always @(posedge clk) begin
    if (!rst_n) begin
      req_valid <= 1'b0; req_fence <= 1'b0;
    end else begin
      if (req_valid && req_ready) begin
        exp_t e;
        e.write = cur.write; e.fence = cur.fence; e.t_acc = cyc; e.err = HERR_NONE; e.data = '0;
        if (cur.fence) begin
          if (outstanding_tb != 0) fail($sformatf("FENCE accepted with %0d outstanding transactions", outstanding_tb));
          e.write = 1'b1;
        end else begin
          e.key = gkey(cur.addr);
          e.err = expected_err(cur.addr, cur.write, cur.mask);
          if (e.err == HERR_NONE) begin
            longint k;
            k = cmd_key(cur.addr, cur.write);
            if (exp_cmd_cnt.exists(k)) exp_cmd_cnt[k]++; else exp_cmd_cnt[k] = 1;
            if (cur.write) begin
              hbm_data_t old;
              old = refmem.exists(e.key) ? refmem[e.key] : '0;
              for (int i = 0; i < 32; i++) if (cur.mask[i]) old[i*8 +: 8] = cur.data[i*8 +: 8];
              refmem[e.key] = old;
              acc_wr++;
            end else begin
              e.data = refmem.exists(e.key) ? refmem[e.key] : '0;
              acc_rd++;
            end
          end
          if (txlog_fd != 0)
            $fdisplay(txlog_fd, "{\"ev\":\"req\",\"t\":%0d,\"src\":%0d,\"id\":%0d,\"w\":%0d,\"addr\":\"0x%0h\",\"mask\":\"0x%0h\",\"data\":\"0x%0h\"}",
                      cyc, cur.src, cur.id, cur.write, cur.addr, cur.mask, cur.data);
        end
        accepted++; outstanding_tb++;
        expq[{cur.src[3:0], cur.id[7:0]}].push_back(e);
        req_valid <= 1'b0; req_fence <= 1'b0;
      end
      if ((!req_valid || req_ready) && pend.size() != 0 && (($urandom % 100) < gate_pct)) begin
        cur = pend.pop_front();
        req_addr  <= cur.addr;       req_write <= cur.write;   req_fence <= cur.fence;
        req_id    <= hbm_id_t'(cur.id); req_src <= hbm_src_t'(cur.src); req_qos <= hbm_qos_t'(cur.qos);
        req_order <= cur.ord;        req_wdata <= cur.data;    req_wmask <= cur.mask;
        req_valid <= 1'b1;
      end
    end
  end

  // ------------------------------------------------------------------ response monitor
  always @(posedge clk) begin
    if (rst_n && rsp_valid && rsp_ready) begin
      int k;
      k = {rsp.src, rsp.id};
      if (!expq.exists(k) || expq[k].size() == 0) begin
        fail($sformatf("FOREIGN/DUPLICATE response src=%0d id=%0d (no outstanding request for that owner)", rsp.src, rsp.id));
      end else begin
        exp_t e;
        e = expq[k].pop_front();
        completed++; outstanding_tb--;
        if (own_cnt.exists(int'(rsp.src))) own_cnt[int'(rsp.src)]++; else own_cnt[int'(rsp.src)] = 1;
        if (rsp.write != e.write) fail($sformatf("op mismatch src=%0d id=%0d", rsp.src, rsp.id));
        if (rsp.err != e.err)     fail($sformatf("error code mismatch src=%0d id=%0d exp=%0d got=%0d", rsp.src, rsp.id, e.err, rsp.err));
        if (e.err != HERR_NONE) err_resp_n++;
        if (!e.write && e.err == HERR_NONE && rsp.err == HERR_NONE && rsp.data !== e.data)
          fail($sformatf("DATA MISMATCH src=%0d id=%0d key=%0h exp=%0h got=%0h", rsp.src, rsp.id, e.key, e.data, rsp.data));
        if (!e.fence && e.err == HERR_NONE) begin
          int l; l = int'(cyc - e.t_acc);
          lat_sum += l; lat_n++; lat_arr.push_back(l);
          if (!e.write) bytes_rd += 32;
        end
        if (txlog_fd != 0 && !e.fence)
          $fdisplay(txlog_fd, "{\"ev\":\"rsp\",\"t\":%0d,\"src\":%0d,\"id\":%0d,\"w\":%0d,\"err\":%0d,\"data\":\"0x%0h\"}",
                    cyc, rsp.src, rsp.id, rsp.write, rsp.err, rsp.data);
        t_last = cyc;
      end
    end
  end

  always @(posedge clk) rsp_ready <= (($urandom % 100) < rsp_ready_pct);

  // DRAM-boundary observation (mapping / isolation check) + per-PC tallies
  always @(posedge clk) if (rst_n) begin
    for (int p = 0; p < NPC; p++) begin
      if (sim_cv[p] && (sim_c[p].cmd == HCMD_RD || sim_c[p].cmd == HCMD_WR)) begin
        longint k;
        k = (longint'(p) << 48) | (longint'(sim_c[p].cmd == HCMD_WR) << 47) | (longint'(sim_c[p].bg) << 44) |
            (longint'(sim_c[p].ba) << 40) | (longint'(sim_c[p].row) << 16) | longint'(sim_c[p].col);
        if (obs_cmd_cnt.exists(k)) obs_cmd_cnt[k]++; else obs_cmd_cnt[k] = 1;
        if (pc_cmds.exists(p)) pc_cmds[p]++; else pc_cmds[p] = 1;
      end
      if (stat[p].evt.busy) begin if (pc_busy.exists(p)) pc_busy[p]++; else pc_busy[p] = 1; end
      if (stat[p].evt.cmp_rd || stat[p].evt.cmp_wr) begin
        if (pc_bytes.exists(p)) pc_bytes[p] += stat[p].bytes; else pc_bytes[p] = stat[p].bytes;
        if (stat[p].evt.cmp_wr) bytes_wr += stat[p].bytes;
      end
      sum_hit += stat[p].evt.row_hit; sum_empty += stat[p].evt.row_empty; sum_conf += stat[p].evt.row_conflict;
      sum_act += stat[p].evt.act; sum_pre += stat[p].evt.pre; sum_ref += stat[p].evt.refresh;
      sum_tstall += stat[p].evt.timing_stall; sum_rstall += stat[p].evt.ref_stall;
      sum_busy_all += stat[p].evt.busy;
    end
    sum_sid += ev_sid; sum_sq += ev_sq; sum_sf += ev_sf;
  end

  // ------------------------------------------------------------------ helpers
  task automatic apply_cfg();
    cfg = '0;
    cfg.enable = 1'b1;
    cfg.map_mode = hbm_map_e'(map_mode[1:0]); cfg.il_bits = il[2:0]; cfg.map_hash = hash[0];
    cfg.profile_sel = 4'(profile_sel);
    cfg.sched.policy = hbm_sched_policy_e'(policy[2:0]); cfg.sched.prio_en = prio_on; cfg.sched.batch_en = batch_on;
    cfg.sched.batch_len = 8'd8; cfg.sched.page = hbm_page_policy_e'(page_pol[1:0]); cfg.sched.close_timeout = 16'd16;
    cfg.ref_cfg.mode = REFMODE_AB; cfg.ref_cfg.eager = 1'b1;
    cfg.ecc_en = ecc_on; cfg.init_timeout = 32'd20000; cfg.max_burst_m1 = 8'd31;
    stall_pct = 8'(phy_stall_pct);
  endtask

  task automatic bring_up();
    // power-good -> clocks -> PHY init -> (controller MRS) -> training -> ready
    pg = 0; cs = 0; pid = 0; tdn = 0;
    apply_cfg();
    repeat (5) @(posedge clk);
    pg = 1;  repeat (3) @(posedge clk);
    cs = 1;  repeat (3) @(posedge clk);
    wait (phy_init_start); repeat (4) @(posedge clk);
    pid = 1;
    wait (train_start);    repeat (6) @(posedge clk);
    tdn = 1;
    wait (ready);
  endtask

  task automatic do_reset();
    rst_n = 1'b0;
    pend.delete(); expq.delete(); outstanding_tb = 0;
    repeat (4) @(posedge clk);
    rst_n = 1'b1;
    repeat (2) @(posedge clk);
    bring_up();
  endtask

  task automatic enq(input bit w, input hbm_addr_t a, input int id, input int src, input int qos,
                     input hbm_data_t d, input hbm_mask_t m, input hbm_order_e ord = ORD_RELAXED, input bit fence = 0);
    item_t it;
    it.write = w; it.fence = fence; it.src = src; it.id = id; it.qos = qos; it.addr = a; it.data = d; it.mask = m; it.ord = ord;
    pend.push_back(it);
  endtask

  task automatic drain(input int unsigned max_cycles = 400000);
    int unsigned n; n = 0;
    while ((pend.size() != 0 || outstanding_tb != 0 || req_valid) && n < max_cycles) begin @(posedge clk); n++; end
    if (n >= max_cycles) fail($sformatf("DRAIN TIMEOUT pend=%0d outstanding=%0d", pend.size(), outstanding_tb));
    repeat (8) @(posedge clk);
  endtask

  task automatic begin_test(input string n); test_fail_base = errors; $display("[TB] ---- %s", n); endtask
  task automatic end_test(input string n);
    if (viol_cnt != 0) fail($sformatf("%s: DRAM model reported %0d violations", n, viol_cnt));
    if (errors == test_fail_base) $display("[TB] TEST %-36s PASS", n); else $display("[TB] TEST %-36s FAIL", n);
  endtask

  // random address inside the capacity, granule aligned, restricted to `span` granules (controls reuse)
  function automatic hbm_addr_t raddr(int unsigned span_log2);
    hbm_addr_t a;
    a = '0;
    for (int i = 0; i < 40; i += 32) a |= hbm_addr_t'($urandom) << i;
    a = (a & ((hbm_addr_t'(1) << (HBM_OFF_W + span_log2)) - 1)) & ~hbm_addr_t'(32'h1F);
    return a;
  endfunction

  // mapping verification: after traffic, the DRAM must have seen exactly the expected column commands
  task automatic check_mapping();
    int bad;
    bad = 0;
    foreach (exp_cmd_cnt[k]) begin
      if (!obs_cmd_cnt.exists(k) || obs_cmd_cnt[k] != exp_cmd_cnt[k]) begin
        if (bad < 5) $display("[TB]   mapping: key pc=%0d w=%0d: expected %0d column cmds, observed %0d",
                              (k >> 48) & 16'hFFFF, (k >> 47) & 1, exp_cmd_cnt[k], obs_cmd_cnt.exists(k) ? obs_cmd_cnt[k] : 0);
        bad++;
      end
    end
    foreach (obs_cmd_cnt[k]) if (!exp_cmd_cnt.exists(k)) begin
      if (bad < 5) $display("[TB]   mapping: UNEXPECTED column command at pc=%0d (wrong channel / extra access)", (k >> 48) & 16'hFFFF);
      bad++;
    end
    if (bad != 0) fail($sformatf("address-mapping / isolation check: %0d mismatching {pc,bank,row,col} entries", bad));
  endtask

  // ------------------------------------------------------------------ tests
  task automatic t_init();
    begin_test("init_sequence_gating");
    pend.delete();
    rst_n = 0; repeat (3) @(posedge clk); rst_n = 1; repeat (2) @(posedge clk);
    pg = 0; cs = 0; pid = 0; tdn = 0; apply_cfg();
    repeat (20) @(posedge clk);
    if (ready) fail("ready before power-good");
    // a request must NOT be accepted while not ready
    req_valid <= 1'b1; req_addr <= 0; req_write <= 0; req_fence <= 0; req_id <= 0; req_src <= 0; req_qos <= 0;
    req_order <= ORD_RELAXED; req_wdata <= '0; req_wmask <= '1;
    repeat (4) @(posedge clk);
    if (req_ready) fail("request accepted before init complete");
    req_valid <= 1'b0; @(posedge clk);
    pg = 1; repeat (3) @(posedge clk); if (ready) fail("ready before clocks/PHY");
    cs = 1; repeat (3) @(posedge clk);
    wait (phy_init_start); repeat (3) @(posedge clk); if (ready) fail("ready before PHY init done");
    pid = 1; wait (train_start); repeat (3) @(posedge clk); if (ready) fail("ready before training done");
    tdn = 1;
    begin int n; n = 0; while (!ready && n < 2000) begin @(posedge clk); n++; end
      if (!ready) fail("controller never became ready"); end
    // the MRS writes must have reached every pseudo-channel's DRAM boundary
    if (cmd_cnt < NPC * 4) fail($sformatf("expected >= %0d MRS commands at the DRAM boundary, saw %0d", NPC * 4, cmd_cnt));
    end_test("init_sequence_gating");
    pg = 0; cs = 0; pid = 0; tdn = 0;
    rst_n = 0; repeat (3) @(posedge clk); rst_n = 1; bring_up();
  endtask

  task automatic t_basic();
    begin_test("write_readback_all_pcs");
    for (int g = 0; g < 4 * NPC; g++) begin
      hbm_addr_t a; hbm_data_t d;
      a = hbm_addr_t'(g) << HBM_OFF_W; d = rnd_data();
      enq(1, a, g % 256, g % NSRC, 0, d, '1);
      enq(0, a, (g + 100) % 256, g % NSRC, 0, '0, '1);
    end
    drain();
    check_mapping();
    end_test("write_readback_all_pcs");
  endtask

  task automatic t_random(input int n, input string name, input int span, input int wr_pct, input bit use_fence);
    begin_test(name);
    for (int i = 0; i < 128; i++) enq(1, raddr(span), $urandom % 256, $urandom % NSRC, 0, rnd_data(), '1);
    for (int i = 0; i < n; i++) begin
      bit w; w = ($urandom % 100) < wr_pct;
      enq(w, raddr(span), $urandom % 24, $urandom % NSRC, $urandom % 4, rnd_data(), w ? rnd_mask($urandom % 3) : '1,
          hbm_order_e'(($urandom % 20 == 0) ? 1 : 0));
      if (use_fence && ($urandom % 150 == 0)) enq(1, 0, 255, $urandom % NSRC, 0, '0, '1, ORD_RELAXED, 1);
    end
    drain();
    check_mapping();
    end_test(name);
  endtask

  task automatic t_errors();
    begin_test("error_responses");
    for (int i = 0; i < 12; i++) begin
      hbm_addr_t bad;
      bad = (hbm_addr_t'(1) << CAP_BITS) | (hbm_addr_t'($urandom) & 40'h00_FFFF_FFE0);   // beyond capacity
      enq(i % 2, bad, i, i % NSRC, 0, rnd_data(), '1);
    end
    for (int i = 0; i < 12; i++) enq(i % 2, hbm_addr_t'(32'h20 * i + 1 + (i % 31)), 20 + i, i % NSRC, 0, rnd_data(), '1);   // misaligned
    // good traffic interleaved with errors must still be correct and ordered
    for (int i = 0; i < 40; i++) begin
      hbm_addr_t a; a = raddr(8);
      enq(1, a, 60 + (i % 4), 1, 0, rnd_data(), '1);
      enq(0, a, 60 + (i % 4), 1, 0, '0, '1);
      if (i % 5 == 0) enq(1, (hbm_addr_t'(1) << CAP_BITS) + 64, 60 + (i % 4), 1, 0, rnd_data(), '1);   // error on the SAME id
    end
    drain();
    if (err_resp_n < 24) fail($sformatf("expected >=24 error responses, saw %0d", err_resp_n));
    check_mapping();
    end_test("error_responses");
  endtask

  task automatic t_ecc_policy();
    begin_test("partial_write_with_ecc_rejected");
    ecc_on = 1; apply_cfg();
    for (int i = 0; i < 16; i++) begin
      hbm_addr_t a; a = raddr(8);
      enq(1, a, i, 0, 0, rnd_data(), '1);                  // full write: fine
      enq(1, a, 32 + i, 0, 0, rnd_data(), rnd_mask(2));    // partial: HERR_POLICY, memory unchanged
      enq(0, a, 64 + i, 0, 0, '0, '1);                     // must read the FULL write's data
    end
    drain();
    check_mapping();
    ecc_on = 0; apply_cfg();
    end_test("partial_write_with_ecc_rejected");
  endtask

  task automatic t_fence();
    begin_test("fence_semantics");
    for (int r = 0; r < 20; r++) begin
      for (int i = 0; i < 6; i++) enq($urandom % 2, raddr(6), i, $urandom % NSRC, 0, rnd_data(), '1);
      enq(1, 0, 200 + r, 0, 0, '0, '1, ORD_RELAXED, 1);
    end
    drain();
    if (sum_sf == 0) fail("fence never had to wait (stall counter 0) - test did not exercise the drain");
    check_mapping();
    end_test("fence_semantics");
  endtask

  task automatic t_same_id();
    begin_test("same_id_across_pcs_order");
    // one {src,id} hammering addresses that map to many different pseudo-channels
    for (int i = 0; i < 400; i++) begin
      hbm_addr_t a; a = hbm_addr_t'($urandom % (NPC * 8)) << HBM_OFF_W;
      enq($urandom % 2, a, 7, 2, 0, rnd_data(), '1);
    end
    drain();
    check_mapping();
    if (NPC > 2 && sum_sid == 0) fail("ID-order tracker never held a request back (stall counter 0)");
    end_test("same_id_across_pcs_order");
  endtask

  task automatic t_backpressure();
    int sr, sp;
    begin_test("backpressure_rsp_and_phy");
    sr = rsp_ready_pct; sp = phy_stall_pct;
    rsp_ready_pct = 15; phy_stall_pct = 35; apply_cfg();
    t_random(600, "  (inner)", 12, 50, 0);
    rsp_ready_pct = sr; phy_stall_pct = sp; apply_cfg();
    end_test("backpressure_rsp_and_phy");
  endtask

  task automatic t_reset();
    begin_test("reset_behaviour");
    for (int i = 0; i < 300; i++) enq($urandom % 2, raddr(10), i % 64, $urandom % NSRC, 0, rnd_data(), '1);
    repeat (90) @(posedge clk);
    flushed += outstanding_tb;
    rst_n = 1'b0; pend.delete(); expq.delete(); outstanding_tb = 0; refmem.delete(); dram.clear_all_mem();
    exp_cmd_cnt.delete(); obs_cmd_cnt.delete();
    repeat (3) @(posedge clk);
    rst_n = 1'b1; repeat (2) @(posedge clk);
    if (ready) fail("controller claims ready straight out of reset");
    bring_up();
    if (outstanding != 0) fail("outstanding counter not cleared by reset");
    for (int i = 0; i < 32; i++) begin
      hbm_addr_t a; a = raddr(8);
      enq(1, a, i, 0, 0, rnd_data(), '1); enq(0, a, 100 + i, 0, 0, '0, '1);
    end
    drain();
    check_mapping();
    end_test("reset_behaviour");
  endtask

  task automatic t_isolation();
    begin_test("channel_hotspot_and_isolation");
    // everything hammers granules of ONE pseudo-channel, a trickle goes elsewhere: nothing may leak between channels
    for (int i = 0; i < 300; i++) begin
      hbm_addr_t a;
      a = hbm_addr_t'(($urandom % 64) * NPC) << HBM_OFF_W;      // linear-in-granule stride NPC: same pc under CH_IL il=0
      enq($urandom % 2, a, $urandom % 16, $urandom % NSRC, 0, rnd_data(), '1);
      if (i % 10 == 0) enq(1, hbm_addr_t'(i % NPC) << HBM_OFF_W, 50 + (i % 8), 3, 0, rnd_data(), '1);
    end
    drain();
    check_mapping();
    end_test("channel_hotspot_and_isolation");
  endtask

  // DUT control pulses are driven on the FALLING edge and sampled by the next rising edge (race-free convention)
  task automatic pulse_clear(); @(negedge clk); perf_clear = 1; @(negedge clk); perf_clear = 0; @(posedge clk); endtask
  task automatic pulse_snap();  @(negedge clk); perf_snap  = 1; @(negedge clk); perf_snap  = 0; @(posedge clk); endtask
  task automatic rd_perf(input bit agg, input int pc, input int c, output longint v);
    perf_agg = agg; perf_pc = 16'(pc); perf_cnt = 6'(c); #1;
    v = longint'(perf_rd);
  endtask

  task automatic t_perf_crosscheck();
    longint n_rd, n_wr, bytes_w, exp_rd_b, hw;
    longint base_hit, base_empty, base_conf, base_act, base_pre;
    longint sum_pc_rd, sum_pc_wr;
    begin_test("perf_counters_exact");
    drain();
    // ---- clear, then known traffic -------------------------------------------------
    pulse_clear();
    base_hit = sum_hit; base_empty = sum_empty; base_conf = sum_conf; base_act = sum_act; base_pre = sum_pre;
    n_rd = 0; n_wr = 0; bytes_w = 0;
    for (int i = 0; i < 200; i++) begin
      hbm_addr_t a; hbm_mask_t m;
      a = raddr(9);
      m = (i % 3 == 0) ? hbm_mask_t'($urandom) : '1;
      enq(1, a, i % 32, i % NSRC, 0, rnd_data(), m);
      n_wr++; for (int k = 0; k < 32; k++) bytes_w += m[k];
      if (i % 2 == 0) begin enq(0, a, 100 + (i % 32), i % NSRC, 0, '0, '1); n_rd++; end
    end
    drain();
    pulse_snap();
    // ---- aggregates (snapshot bank) ---------------------------------------------------
    rd_perf(1, 0, 1, hw);  if (hw != n_rd)            fail($sformatf("agg acc_rd %0d != %0d", hw, n_rd));
    rd_perf(1, 0, 2, hw);  if (hw != n_wr)            fail($sformatf("agg acc_wr %0d != %0d", hw, n_wr));
    rd_perf(1, 0, 3, hw);  if (hw != n_rd)            fail($sformatf("agg cmp_rd %0d != %0d", hw, n_rd));
    rd_perf(1, 0, 4, hw);  if (hw != n_wr)            fail($sformatf("agg cmp_wr %0d != %0d", hw, n_wr));
    rd_perf(1, 0, 5, hw);  if (hw != 32 * n_rd)       fail($sformatf("agg bytes_rd %0d != %0d", hw, 32 * n_rd));
    rd_perf(1, 0, 6, hw);  if (hw != bytes_w)         fail($sformatf("agg bytes_wr %0d != %0d (byte-enable popcount)", hw, bytes_w));
    rd_perf(1, 0, 7, hw);  if (hw != sum_hit - base_hit)     fail($sformatf("agg row_hit %0d != tb %0d", hw, sum_hit - base_hit));
    rd_perf(1, 0, 8, hw);  if (hw != sum_empty - base_empty) fail($sformatf("agg row_empty %0d != tb %0d", hw, sum_empty - base_empty));
    rd_perf(1, 0, 9, hw);  if (hw != sum_conf - base_conf)   fail($sformatf("agg row_conflict %0d != tb %0d", hw, sum_conf - base_conf));
    rd_perf(1, 0, 10, hw); if (hw != sum_act - base_act)     fail($sformatf("agg act %0d != tb %0d", hw, sum_act - base_act));
    rd_perf(1, 0, 11, hw); if (hw != sum_pre - base_pre)     fail($sformatf("agg pre %0d != tb %0d", hw, sum_pre - base_pre));
    if ((sum_hit - base_hit) + (sum_empty - base_empty) + (sum_conf - base_conf) != n_rd + n_wr)
      fail("hit+empty+conflict != number of column commands");
    rd_perf(1, 0, 21, hw); if (hw != n_rd + n_wr)     fail($sformatf("agg lat_cnt %0d != %0d", hw, n_rd + n_wr));
    // ---- per-PC counters sum to the aggregate ---------------------------------------------
    sum_pc_rd = 0; sum_pc_wr = 0;
    for (int p = 0; p < NPC; p++) begin rd_perf(0, p, 0, hw); sum_pc_rd += hw; rd_perf(0, p, 1, hw); sum_pc_wr += hw; end
    if (sum_pc_rd != n_rd) fail($sformatf("sum of per-PC acc_rd %0d != %0d", sum_pc_rd, n_rd));
    if (sum_pc_wr != n_wr) fail($sformatf("sum of per-PC acc_wr %0d != %0d", sum_pc_wr, n_wr));
    // ---- snapshot holds while live counters move -----------------------------------------------
    for (int i = 0; i < 20; i++) enq(0, raddr(9), i, 0, 0, '0, '1);
    drain();
    rd_perf(1, 0, 1, hw); if (hw != n_rd) fail("snapshot bank changed without a new snapshot");
    // ---- freeze: events are not counted ----------------------------------------------------------
    @(negedge clk); perf_freeze = 1;
    for (int i = 0; i < 10; i++) enq(0, raddr(9), i, 0, 0, '0, '1);
    drain();
    @(negedge clk); perf_freeze = 0; pulse_snap();
    rd_perf(1, 0, 1, hw); if (hw != n_rd + 20) fail($sformatf("freeze: acc_rd %0d, expected %0d (reads during freeze must not count)", hw, n_rd + 20));
    // ---- clear ---------------------------------------------------------------------------------------
    pulse_clear();
    rd_perf(0, 0, 0, hw); if (hw != 0) fail("per-PC counter not cleared");
    pulse_snap();
    rd_perf(1, 0, 1, hw); if (hw != 0) fail("aggregate not cleared");
    if (perf_ovf) fail("overflow flag set after clear");
    end_test("perf_counters_exact");
  endtask

  // ------------------------------------------------------------------ main
  string tname; int unsigned seed;
  initial begin
    if (!$value$plusargs("TEST=%s", tname)) tname = "all";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    void'($value$plusargs("PROFILE=%d", profile_sel)); void'($value$plusargs("POLICY=%d", policy));
    void'($value$plusargs("MAP=%d", map_mode)); void'($value$plusargs("IL=%d", il)); void'($value$plusargs("HASH=%d", hash));
    void'($value$plusargs("PAGE=%d", page_pol));
    void'($value$plusargs("RSPRDY=%d", rsp_ready_pct)); void'($value$plusargs("PHYSTALL=%d", phy_stall_pct));
    txlog_fd = 0;
    if ($value$plusargs("TXLOG=%s", txlog_path)) txlog_fd = $fopen(txlog_path, "w");
    $urandom(seed);
    errors = 0; accepted = 0; completed = 0; flushed = 0; acc_rd = 0; acc_wr = 0; err_resp_n = 0; outstanding_tb = 0;
    lat_sum = 0; lat_n = 0; bytes_rd = 0; bytes_wr = 0;
    sum_hit = 0; sum_empty = 0; sum_conf = 0; sum_act = 0; sum_pre = 0; sum_ref = 0; sum_tstall = 0; sum_rstall = 0;
    sum_busy_all = 0; sum_sid = 0; sum_sq = 0; sum_sf = 0; t_first = 0; t_last = 0;
    apply_cfg();
    $display("[TB] tb_ctrl_multi NCH=%0d NSTK=%0d NPC=%0d clusters_of=%0d QD=%0d seed=%0d profile=%0d(%s) policy=%0d map=%0d il=%0d hash=%0d cap_bits=%0d",
             NCH, NSTK, NPC, CHCL, QD, seed, profile_sel,
             (hbm_profile_status(4'(profile_sel)) == 2'd0) ? "HYPOTHETICAL_SIM" : "VERIFIED", policy, map_mode, il, hash, CAP_BITS);

    rst_n = 1'b0; repeat (4) @(posedge clk); rst_n = 1'b1; repeat (2) @(posedge clk);
    if (tname == "all" || tname == "init") t_init(); else bring_up();

    if (tname == "all" || tname == "basic")    t_basic();
    if (tname == "all" || tname == "random")   t_random(1500, "random_mixed_multi_source", 14, 50, 0);
    if (tname == "all" || tname == "maps") begin
      for (int m = 0; m < 3; m++) for (int h = 0; h < 2; h++) begin
        map_mode = m; hash = h; il = (m == 0) ? 0 : (m + h) % 4; apply_cfg();
        // a mapping change is only legal while idle, and it changes WHERE every address lives:
        // the old memory image is meaningless afterwards (software must re-initialise), so clear both sides.
        drain(); exp_cmd_cnt.delete(); obs_cmd_cnt.delete(); refmem.delete(); dram.clear_all_mem();
        t_random(500, $sformatf("random_map_mode%0d_il%0d_hash%0d", m, il, h), 12, 50, 0);
      end
      map_mode = 1; hash = 0; il = 0; apply_cfg(); drain(); exp_cmd_cnt.delete(); obs_cmd_cnt.delete(); refmem.delete(); dram.clear_all_mem();
    end
    if (tname == "all" || tname == "errors")   t_errors();
    if (tname == "all" || tname == "ecc_policy") t_ecc_policy();
    if (tname == "all" || tname == "fence")    t_fence();
    if (tname == "all" || tname == "same_id")  t_same_id();
    if (tname == "all" || tname == "isolation") t_isolation();
    if (tname == "all" || tname == "backpressure") t_backpressure();
    if (tname == "all" || tname == "reset")    t_reset();
    if (tname == "all" || tname == "perf")     t_perf_crosscheck();

    drain();
    if (accepted != completed + flushed) fail($sformatf("accepted %0d != completed %0d + flushed %0d", accepted, completed, flushed));
    foreach (expq[k]) if (expq[k].size() != 0) fail($sformatf("expectation left for key %0h", k));
    // every source got exactly the responses it expected (ownership)
    dram.report();
    $display("[TB] SUMMARY accepted=%0d completed=%0d cycles=%0d  hit=%0d empty=%0d conflict=%0d act=%0d pre=%0d ref=%0d id_stalls=%0d q_stalls=%0d fence_wait=%0d",
             accepted, completed, cyc, sum_hit, sum_empty, sum_conf, sum_act, sum_pre, sum_ref, sum_sid, sum_sq, sum_sf);
    if (lat_n != 0) $display("[TB] avg_latency=%0.1f cycles over %0d error-free transactions", real'(lat_sum) / real'(lat_n), lat_n);
    if (txlog_fd != 0) $fclose(txlog_fd);
    if (errors == 0 && viol_cnt == 0) $display("RESULT: PASS  (tb_ctrl_multi NCH=%0d, %0d responses checked)", NCH, completed);
    else                              $display("RESULT: FAIL  (tb_ctrl_multi NCH=%0d, %0d errors, %0d DRAM violations)", NCH, errors, viol_cnt);
    $finish;
  end
  initial begin #400_000_000; $display("RESULT: FAIL  (tb_ctrl_multi watchdog)"); $finish; end
endmodule
