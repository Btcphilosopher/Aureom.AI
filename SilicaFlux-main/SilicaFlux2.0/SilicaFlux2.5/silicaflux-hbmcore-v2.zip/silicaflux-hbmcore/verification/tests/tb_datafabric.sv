// =============================================================================
//  tb_datafabric.sv -- DataFabric NoC adapter (sf_hbm_datafabric) with NoC masters and two backends
//    BACKEND=0 : mock HBM, random latency, OUT-OF-ORDER granule responses  (stress the reorder buffer / ownership)
//    BACKEND=1 : the real sf_hbm4_controller (NCH channels) + timing-aware DRAM model
//  Real contract: noc_packet_t of silicaflux_pkg (SF-NOC packet contract v1, vendored from DataFabric NoC v2).
//
//  Checks, per RESPONSE FLIT, in global request order: dst_id = requesting tile, src_id, txn_id, pclass, xfer, addr,
//  status, be, data, sop/eop. Ownership: the {dst_id,txn_id} of every response matches the request that produced it.
//  Reference memory is byte accurate; writes apply, reads snapshot, in stream order (the adapter ingests in order).
//  PLUSARGS: +TEST=<name|all> +SEED=<n> +N=<transactions per phase> +RSPRDY=<pct> +JSON=<file>
// =============================================================================
`timescale 1ns/1ps


module tb_datafabric;
  import sf_hbm_pkg::*;
  import sf_hbm_profile_pkg::*;
  import silicaflux_pkg::*;

  parameter int unsigned BACKEND = 0;
  parameter int unsigned NCH     = 2;
  localparam int unsigned NPC    = NCH * 2;
  localparam int unsigned CAPB   = 24;                    // mock capacity: 16 MiB
  localparam int unsigned NS_BITS = 0, CH_BITS = (NCH > 1) ? $clog2(NCH) : 0;
  localparam int unsigned REAL_CAP_BITS = hbm_cap_bits(NS_BITS, CH_BITS, 1);

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  longint unsigned cyc; always @(posedge clk) cyc <= rst_n ? cyc + 1 : 0;

  // ---- NoC side
  logic req_v, req_r; noc_packet_t req_p; logic rsp_v, rsp_r; noc_packet_t rsp_p;
  logic [7:0] addr_hi = 8'h00;
  // ---- HBM side
  logic h_v, h_r; hbm_addr_t h_a; logic h_w; hbm_id_t h_id; hbm_src_t h_src; hbm_qos_t h_q; hbm_data_t h_wd; hbm_mask_t h_wm;
  logic hr_v, hr_r; hbm_rsp_t hr;
  logic ev_drop, ev_errrsp;

  sf_hbm_datafabric #(.REQ_DEPTH(4), .ROB_N(64), .NTAG(64), .HBM_SRC(1)) dut (
    .clk_i(clk), .rst_ni(rst_n), .req_valid_i(req_v), .req_ready_o(req_r), .req_pkt_i(req_p),
    .rsp_valid_o(rsp_v), .rsp_ready_i(rsp_r), .rsp_pkt_o(rsp_p), .addr_hi_i(addr_hi), .max_burst_m1_i(8'd31),
    .h_req_valid_o(h_v), .h_req_ready_i(h_r), .h_req_addr_o(h_a), .h_req_write_o(h_w), .h_req_id_o(h_id),
    .h_req_src_o(h_src), .h_req_qos_o(h_q), .h_req_wdata_o(h_wd), .h_req_wmask_o(h_wm),
    .h_rsp_valid_i(hr_v), .h_rsp_ready_o(hr_r), .h_rsp_i(hr), .ev_drop_o(ev_drop), .ev_err_rsp_o(ev_errrsp));

  int unsigned viol_cnt = 0, cmd_cnt = 0;
  logic bringup_done = 1;
  if (BACKEND == 0) begin : g_mock
    hbm_mock_backend #(.CAP_BITS(CAPB)) mock (.clk_i(clk), .rst_ni(rst_n),
      .req_valid_i(h_v), .req_ready_o(h_r), .req_addr_i(h_a), .req_write_i(h_w), .req_id_i(h_id), .req_src_i(h_src),
      .req_wdata_i(h_wd), .req_wmask_i(h_wm), .rsp_valid_o(hr_v), .rsp_ready_i(hr_r), .rsp_o(hr));
  end else begin : g_real
    hbm_cfg_t cfg;
    logic pg = 0, cs = 0, pid = 0, tdn = 0, rdy, pis, ts, ierr; logic [2:0] ic, ist;
    logic [NPC-1:0] pready, scv, swv, srv, srerr; hbm_cmd_t [NPC-1:0] sc; hbm_data_t [NPC-1:0] swd, srd; hbm_mask_t [NPC-1:0] swm;
    hbm_ecc_t [NPC-1:0] swe, sre; hbm_pc_stat_t [NPC-1:0] stat;
    logic e1, e2, e3, e4, e5, e6, e7; logic [15:0] outst; logic infeas;
    sf_hbm4_controller #(.NUM_STACKS(1), .NUM_CHANNELS(NCH), .CH_PER_CLUSTER(NCH), .DEPTH(16), .TRK_SRC_W(2), .TRK_ID_W(6)) ctl (
      .clk_i(clk), .rst_ni(rst_n), .cfg_i(cfg), .power_good_i(pg), .clk_stable_i(cs), .phy_init_done_i(pid), .train_done_i(tdn),
      .phy_init_start_o(pis), .train_start_o(ts), .ready_o(rdy), .init_error_o(ierr), .init_cause_o(ic), .init_state_o(ist),
      .req_valid_i(h_v), .req_ready_o(h_r), .req_addr_i(h_a), .req_write_i(h_w), .req_fence_i(1'b0), .req_id_i(h_id),
      .req_src_i(h_src), .req_qos_i(h_q), .req_order_i(ORD_RELAXED), .req_wdata_i(h_wd), .req_wmask_i(h_wm),
      .rsp_valid_o(hr_v), .rsp_ready_i(hr_r), .rsp_o(hr),
      .ecc_clear_i(1'b0), .inj_arm_i(1'b0), .inj_pc_i('0), .inj_mode_i('0), .inj_bit_i('0),
      .phy_ready_ext_i(pready), .phy_event_i('0), .ondie_event_i('0),
      .sim_cmd_valid_o(scv), .sim_cmd_o(sc), .sim_wvalid_o(swv), .sim_wdata_o(swd), .sim_wmask_o(swm), .sim_wecc_o(swe),
      .sim_rvalid_i(srv), .sim_rdata_i(srd), .sim_recc_i(sre), .sim_rerr_i(srerr),
      .stat_o(stat), .ev_accept_o(e1), .ev_accept_rd_o(e2), .ev_accept_wr_o(e3), .ev_err_req_o(e4),
      .ev_stall_id_o(e5), .ev_stall_q_o(e6), .ev_stall_fence_o(e7), .outstanding_o(outst), .ref_cfg_infeasible_o(infeas));
    hbm_timing_t tp; assign tp = hbm_profile(4'd1);
    hbm4_dram_model #(.NUM_PC(NPC)) dram (.clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .viol_quiet_i(1'b0), .stall_pct_i(8'd0),
      .cmd_valid_i(scv), .cmd_i(sc), .wvalid_i(swv), .wdata_i(swd), .wmask_i(swm), .wecc_i(swe),
      .ready_o(pready), .rvalid_o(srv), .rdata_o(srd), .recc_o(sre), .rerr_o(srerr), .viol_cnt_o(viol_cnt), .cmd_cnt_o(cmd_cnt));
    initial begin
      bringup_done = 0;
      cfg = '0; cfg.enable = 1; cfg.map_mode = MAP_BANK_AWARE; cfg.il_bits = 0; cfg.profile_sel = 4'd1;
      cfg.sched.policy = SCHED_FRFCFS; cfg.ref_cfg.mode = REFMODE_AB; cfg.ref_cfg.eager = 1; cfg.init_timeout = 32'd20000;
      @(posedge rst_n); repeat (5) @(posedge clk); pg = 1; repeat (3) @(posedge clk); cs = 1; repeat (3) @(posedge clk);
      wait (pis); repeat (4) @(posedge clk); pid = 1; wait (ts); repeat (6) @(posedge clk); tdn = 1; wait (rdy);
      bringup_done = 1;
    end
  end

  // ---------------------------------------------------------------- tiles / packets
  localparam int unsigned NT = 4;
  function automatic sf_noc_id_t tile(int i); return sf_noc_id(i % 2, i / 2, 2); endfunction
  localparam sf_noc_id_t MEM_ID = 4'b0011;      // (1,1)

  function automatic noc_packet_t mk(sf_noc_class_e c, sf_noc_xfer_e x, int src_t, int txn, sf_paddr_t a, sf_noc_be_t be,
                                     sf_noc_data_t d, bit sop, bit eop, int qos);
    noc_packet_t p;
    p = '0; p.valid = 1; p.sop = sop; p.eop = eop; p.pclass = c; p.qos = sf_noc_qos_t'(qos);
    p.dst_id = MEM_ID; p.src_id = tile(src_t); p.txn_id = sf_mem_tag_t'(txn); p.status = SF_MEM_EXC_NONE; p.xfer = x;
    p.hint = SF_MEM_HINT_NORMAL; p.addr = a; p.be = be; p.data = d;
    return p;
  endfunction

  noc_packet_t flit_q [$];       // stream of request flits, in send order
  noc_packet_t expq [$];         // expected response flits, in order
  logic [7:0]  refmem [longint];
  bit          tid_busy [NT][256];
  int          tid_next [NT];
  int          errors, sent_flits, recv_flits, n_req;
  int          per_tile_rsp [NT];

  function automatic int cap_bytes_bits(); return (BACKEND == 0) ? CAPB : REAL_CAP_BITS; endfunction

  function automatic hbm_data_t rnd128();
    hbm_data_t d; d = '0; for (int i = 0; i < 4; i++) d[i*32 +: 32] = $urandom; return d;
  endfunction

  function automatic int new_tid(int t);
    for (int k = 0; k < 256; k++) begin
      int c; c = (tid_next[t] + k) % 256;
      if (!tid_busy[t][c]) begin tid_next[t] = c + 1; tid_busy[t][c] = 1; return c; end
    end
    return -1;
  endfunction

  function automatic bit in_range(longint a, int nbytes);
    return ((a + nbytes - 1) >> cap_bytes_bits()) == 0;
  endfunction

  task automatic add_expect(input noc_packet_t req, input sf_noc_data_t data, input sf_noc_be_t be, input sf_mem_exc_e st,
                            input bit sop, input bit eop, input sf_paddr_t a);
    noc_packet_t e;
    e = sf_noc_make_rsp(req, data, be, st);
    e.sop = sop; e.eop = eop; e.addr = a;
    expq.push_back(e);
  endtask

  // ---- generators: each appends request flits and the exact expected response flits (ref model applied in stream order)
  task automatic gen_scalar(input int t, input bit w, input sf_paddr_t a, input logic [31:0] wd, input logic [3:0] be, input bit misalign_ok = 0);
    int tid; noc_packet_t p; longint la; sf_noc_data_t d;
    tid = new_tid(t); if (tid < 0) return;
    p = mk(w ? SF_NOC_WR_REQ : SF_NOC_RD_REQ, SF_NOC_X_SCALAR, t, tid, a, sf_noc_be_t'(be), sf_noc_data_t'(wd), 1, 1, $urandom % 4);
    flit_q.push_back(p); n_req++;
    la = longint'(a);
    if (a[1:0] != 0)           add_expect(p, '0, '0, SF_MEM_EXC_MISALIGN, 1, 1, a);
    else if (!in_range(la, 4)) add_expect(p, '0, '0, SF_MEM_EXC_RANGE, 1, 1, a);
    else if (w) begin
      for (int i = 0; i < 4; i++) if (be[i]) refmem[la + i] = wd[i*8 +: 8];
      add_expect(p, '0, '0, SF_MEM_EXC_NONE, 1, 1, a);
    end else begin
      d = '0; for (int i = 0; i < 4; i++) d[i*8 +: 8] = refmem.exists(la + i) ? refmem[la + i] : 8'h00;
      add_expect(p, d, 16'h000F, SF_MEM_EXC_NONE, 1, 1, a);
    end
  endtask

  task automatic gen_vector(input int t, input bit w, input sf_paddr_t a, input sf_noc_data_t wd, input sf_noc_be_t be);
    int tid; noc_packet_t p; longint la; sf_noc_data_t d;
    tid = new_tid(t); if (tid < 0) return;
    p = mk(w ? SF_NOC_WR_REQ : SF_NOC_RD_REQ, SF_NOC_X_VECTOR, t, tid, a, be, wd, 1, 1, $urandom % 4);
    flit_q.push_back(p); n_req++;
    la = longint'(a);
    if (a[3:0] != 0)            add_expect(p, '0, '0, SF_MEM_EXC_MISALIGN, 1, 1, a);
    else if (!in_range(la, 16)) add_expect(p, '0, '0, SF_MEM_EXC_RANGE, 1, 1, a);
    else if (w) begin
      for (int i = 0; i < 16; i++) if (be[i]) refmem[la + i] = wd[i*8 +: 8];
      add_expect(p, '0, '0, SF_MEM_EXC_NONE, 1, 1, a);
    end else begin
      d = '0; for (int i = 0; i < 16; i++) d[i*8 +: 8] = refmem.exists(la + i) ? refmem[la + i] : 8'h00;
      add_expect(p, d, 16'hFFFF, SF_MEM_EXC_NONE, 1, 1, a);
    end
  endtask

  task automatic gen_burst_rd(input int t, input sf_paddr_t a, input int len);        // len beats (1..N)
    int tid; noc_packet_t p; longint la; sf_noc_data_t d; bit bad_len;
    tid = new_tid(t); if (tid < 0) return;
    bad_len = (len > 32);
    p = mk(SF_NOC_RD_REQ, SF_NOC_X_BURST, t, tid, a, '0, sf_noc_data_t'(len - 1), 1, 1, $urandom % 4);
    flit_q.push_back(p); n_req++;
    la = longint'(a);
    if (bad_len)                       add_expect(p, '0, '0, SF_MEM_EXC_BURST_LEN, 1, 1, a);
    else if (a[3:0] != 0)              add_expect(p, '0, '0, SF_MEM_EXC_MISALIGN, 1, 1, a);
    else if (!in_range(la, 16 * len))  add_expect(p, '0, '0, SF_MEM_EXC_RANGE, 1, 1, a);   // (only used with whole-burst-out-of-range)
    else for (int b = 0; b < len; b++) begin
      d = '0; for (int i = 0; i < 16; i++) d[i*8 +: 8] = refmem.exists(la + 16*b + i) ? refmem[la + 16*b + i] : 8'h00;
      add_expect(p, d, 16'hFFFF, SF_MEM_EXC_NONE, (b == 0), (b == len - 1), a + sf_paddr_t'(16 * b));
    end
  endtask

  task automatic gen_burst_wr(input int t, input sf_paddr_t a, input int len, input bit random_be);
    int tid; noc_packet_t p; longint la; bit bad;
    tid = new_tid(t); if (tid < 0) return;
    p = mk(SF_NOC_WR_REQ, SF_NOC_X_BURST, t, tid, a, '0, sf_noc_data_t'(len - 1), 1, 0, $urandom % 4);
    flit_q.push_back(p); n_req++;
    la = longint'(a);
    bad = (len > 32) || (a[3:0] != 0) || !in_range(la, 16 * len);
    for (int b = 0; b < len; b++) begin
      noc_packet_t bp; sf_noc_data_t d; sf_noc_be_t be;
      d = rnd128(); be = random_be ? sf_noc_be_t'($urandom) : 16'hFFFF;
      bp = mk(SF_NOC_WR_REQ, SF_NOC_X_BURST, t, tid, a + sf_paddr_t'(16 * b), be, d, 0, (b == len - 1), 0);
      flit_q.push_back(bp);
      if (!bad) for (int i = 0; i < 16; i++) if (be[i]) refmem[la + 16*b + i] = d[i*8 +: 8];
    end
    if (len > 32)                      add_expect(p, '0, '0, SF_MEM_EXC_BURST_LEN, 1, 1, a);
    else if (a[3:0] != 0)              add_expect(p, '0, '0, SF_MEM_EXC_MISALIGN, 1, 1, a);
    else if (!in_range(la, 16 * len))  add_expect(p, '0, '0, SF_MEM_EXC_RANGE, 1, 1, a);
    else begin
      add_expect(p, '0, '0, SF_MEM_EXC_NONE, 1, 1, a);
      expq[expq.size()-1].data = sf_noc_data_t'(len);      // contract: burst-write completion carries data[8:0] = beats committed
    end
  endtask

  task automatic gen_ctrl(input int t);
    int tid; noc_packet_t p;
    tid = new_tid(t); if (tid < 0) return;
    p = mk(SF_NOC_RD_REQ, SF_NOC_X_CTRL, t, tid, 32'h0, '0, '0, 1, 1, 0);
    flit_q.push_back(p); n_req++;
    add_expect(p, '0, '0, SF_MEM_EXC_RANGE, 1, 1, 32'h0);
  endtask

  task automatic gen_msg(input int t);     // posted: dropped, NO response
    noc_packet_t p;
    p = mk(SF_NOC_MSG, SF_NOC_X_SCALAR, t, 0, 32'h100, 16'h000F, 128'h1234, 1, 1, 0);
    flit_q.push_back(p);
  endtask

  int unsigned gate_pct = 100, rsp_pct = 100;
  // ---------------------------------------------------------------- stream driver / response monitor
  always @(posedge clk) begin
    if (!rst_n) req_v <= 0;
    else begin
      if (req_v && req_r) begin sent_flits++; req_v <= 0; end
      if ((!req_v || req_r) && flit_q.size() != 0 && bringup_done && (($urandom % 100) < gate_pct)) begin
        req_p <= flit_q.pop_front(); req_v <= 1;
      end
    end
  end

  always @(posedge clk) rsp_r <= (($urandom % 100) < rsp_pct);

  always @(posedge clk) if (rst_n && rsp_v && rsp_r) begin
    noc_packet_t e, g; int t;
    g = rsp_p; recv_flits++;
    if (expq.size() == 0) begin errors++; $display("[TB][FAIL] cycle %0d: unexpected response flit (txn %0d to tile %0d)", cyc, g.txn_id, g.dst_id); end
    else begin
      e = expq.pop_front();
      if (g.dst_id !== e.dst_id) begin errors++; $display("[TB][FAIL] OWNERSHIP: response routed to tile %0d, expected %0d (txn %0d)", g.dst_id, e.dst_id, e.txn_id); end
      if (g.src_id !== e.src_id || g.txn_id !== e.txn_id || g.pclass !== e.pclass || g.xfer !== e.xfer || g.addr !== e.addr ||
          g.status !== e.status || g.be !== e.be || g.sop !== e.sop || g.eop !== e.eop || g.valid !== 1'b1 || g.qos !== e.qos) begin
        errors++; $display("[TB][FAIL] cycle %0d: header mismatch got{dst=%0d src=%0d txn=%0d cls=%0d x=%0d a=%08h st=%0d be=%04h sop=%0b eop=%0b} exp{dst=%0d src=%0d txn=%0d cls=%0d x=%0d a=%08h st=%0d be=%04h sop=%0b eop=%0b}",
          cyc, g.dst_id, g.src_id, g.txn_id, g.pclass, g.xfer, g.addr, g.status, g.be, g.sop, g.eop,
          e.dst_id, e.src_id, e.txn_id, e.pclass, e.xfer, e.addr, e.status, e.be, e.sop, e.eop);
      end else if (g.data !== e.data) begin
        errors++; $display("[TB][FAIL] cycle %0d: DATA mismatch txn=%0d addr=%08h exp=%032h got=%032h", cyc, e.txn_id, e.addr, e.data, g.data);
      end
      // free the transaction id on the LAST flit of its response
      for (int i = 0; i < NT; i++) if (tile(i) == e.dst_id && e.eop) begin tid_busy[i][e.txn_id] = 0; per_tile_rsp[i]++; end
    end
  end

  task automatic drain(input int max_cycles = 400000);
    int n; n = 0;
    while ((flit_q.size() != 0 || expq.size() != 0 || req_v) && n < max_cycles) begin @(posedge clk); n++; end
    if (n >= max_cycles) begin errors++; $display("[TB][FAIL] DRAIN TIMEOUT flits=%0d expected_rsp=%0d", flit_q.size(), expq.size()); end
    repeat (10) @(posedge clk);
  endtask

  function automatic sf_paddr_t raddr(int align_log2, int window_log2);
    sf_paddr_t a; a = $urandom;
    a = (a & ((32'd1 << window_log2) - 1)) & ~((32'd1 << align_log2) - 1);
    return a;
  endfunction

  int test_base;
  task automatic begin_test(string n); test_base = errors; $display("[TB] ---- %s", n); endtask
  task automatic end_test(string n);
    if (BACKEND == 1 && viol_cnt != 0) begin errors++; $display("[TB][FAIL] DRAM violations %0d", viol_cnt); end
    $display("[TB] TEST %-34s %s", n, (errors == test_base) ? "PASS" : "FAIL");
  endtask

  // ---------------------------------------------------------------- tests
  int N;
  task automatic t_basic();
    begin_test("scalar_vector_rw_strobes");
    for (int i = 0; i < N; i++) begin
      int t; t = $urandom % NT;
      case ($urandom % 4)
        0: gen_scalar(t, 1, raddr(2, 12), $urandom, 4'($urandom));
        1: gen_scalar(t, 0, raddr(2, 12), 0, 0);
        2: gen_vector(t, 1, raddr(4, 12), rnd128(), 16'($urandom));
        3: gen_vector(t, 0, raddr(4, 12), 0, 16'hFFFF);
      endcase
    end
    drain(); end_test("scalar_vector_rw_strobes");
  endtask

  task automatic t_bursts();
    begin_test("burst_rw_fused_and_split_granules");
    for (int i = 0; i < N / 4; i++) begin
      int t, len; t = $urandom % NT; len = 1 + ($urandom % 32);
      // 16-byte aligned base: half the time 32-byte aligned (fused pairs), half the time starts mid-granule (split ends)
      if ($urandom % 2) gen_burst_wr(t, raddr(4, 14), len, $urandom % 2);
      else              gen_burst_rd(t, raddr(4, 14), len);
    end
    drain(); end_test("burst_rw_fused_and_split_granules");
  endtask

  task automatic t_mixed_multi_tile();
    begin_test("mixed_multi_tile_ownership");
    for (int i = 0; i < N; i++) begin
      int t; t = $urandom % NT;
      case ($urandom % 8)
        0, 1: gen_scalar(t, $urandom % 2, raddr(2, 10), $urandom, 4'($urandom));
        2, 3: gen_vector(t, $urandom % 2, raddr(4, 10), rnd128(), ($urandom % 3 == 0) ? 16'($urandom) : 16'hFFFF);
        4:    gen_burst_wr(t, raddr(4, 10), 1 + $urandom % 12, $urandom % 2);
        5:    gen_burst_rd(t, raddr(4, 10), 1 + $urandom % 12);
        6:    gen_vector(t, 0, raddr(4, 10), 0, 16'hFFFF);
        7:    gen_scalar(t, 0, raddr(2, 10), 0, 0);
      endcase
    end
    drain();
    for (int i = 0; i < NT; i++) if (per_tile_rsp[i] == 0) begin errors++; $display("[TB][FAIL] tile %0d got no responses", i); end
    end_test("mixed_multi_tile_ownership");
  endtask

  task automatic t_errors();
    begin_test("errors_drops_and_ctrl");
    for (int i = 0; i < 20; i++) begin
      int t; t = i % NT;
      gen_scalar(t, i % 2, raddr(2, 10) | 1, 32'hDEAD, 4'hF);          // misaligned scalar
      gen_vector(t, i % 2, raddr(4, 10) | 8, rnd128(), 16'hFFFF);       // misaligned vector
      gen_burst_rd(t, raddr(4, 10) | 4, 4);                              // misaligned burst read
      gen_burst_wr(t, raddr(4, 10) | 4, 3, 0);                           // misaligned burst write: beats drained
      gen_burst_rd(t, raddr(4, 10), 33);                                 // too long
      gen_burst_wr(t, raddr(4, 10), 40, 0);                              // too long write: 40 beats drained
      gen_ctrl(t);
      gen_msg(t);                                                        // dropped
      gen_scalar(t, 1, 32'(((longint'(1) << cap_bytes_bits()) - 4) & 32'hFFFF_FFFF) & ~32'd3, $urandom, 4'hF);   // last word of the capacity: valid
      gen_vector(t, 0, raddr(4, 10), 0, 16'hFFFF);                       // normal traffic between the errors
      gen_vector(t, 1, raddr(4, 10), rnd128(), 16'hFFFF);
    end
    drain(); end_test("errors_drops_and_ctrl");
  endtask

  task automatic t_out_of_range();
    begin_test("out_of_range_address_extension");
    // addr_hi selects a window beyond the capacity: every granule comes back RANGE from the controller
    addr_hi = 8'hF0;
    for (int i = 0; i < 20; i++) begin
      noc_packet_t p; int tid; int t;
      t = i % NT; tid = new_tid(t);
      p = mk(SF_NOC_RD_REQ, SF_NOC_X_VECTOR, t, tid, raddr(4, 12), 16'hFFFF, '0, 1, 1, 0);
      flit_q.push_back(p); n_req++; add_expect(p, '0, '0, SF_MEM_EXC_RANGE, 1, 1, p.addr);
      tid = new_tid(t);
      p = mk(SF_NOC_WR_REQ, SF_NOC_X_SCALAR, t, tid, raddr(2, 12), 16'h000F, 128'h55, 1, 1, 0);
      flit_q.push_back(p); n_req++; add_expect(p, '0, '0, SF_MEM_EXC_RANGE, 1, 1, p.addr);
    end
    drain(); addr_hi = 8'h00;
    end_test("out_of_range_address_extension");
  endtask

  task automatic t_backpressure();
    begin_test("response_and_request_backpressure");
    gate_pct = 30; rsp_pct = 15;
    t_mixed_multi_tile();
    gate_pct = 100; rsp_pct = 100;
    end_test("response_and_request_backpressure");
  endtask

  string tname; int unsigned seed;
  initial begin
    if (!$value$plusargs("TEST=%s", tname)) tname = "all";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("N=%d", N)) N = 400;
    void'($value$plusargs("RSPRDY=%d", rsp_pct));
    $urandom(seed); errors = 0; sent_flits = 0; recv_flits = 0; n_req = 0;
    for (int i = 0; i < NT; i++) begin tid_next[i] = 0; per_tile_rsp[i] = 0; for (int k = 0; k < 256; k++) tid_busy[i][k] = 0; end
    $display("[TB] tb_datafabric BACKEND=%0d (%s) seed=%0d N=%0d", BACKEND, (BACKEND == 0) ? "mock, out-of-order" : "real controller + DRAM model", seed, N);
    rst_n = 0; repeat (5) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);
    wait (bringup_done);
    if (tname == "all" || tname == "basic")  t_basic();
    if (tname == "all" || tname == "burst")  t_bursts();
    if (tname == "all" || tname == "mixed")  t_mixed_multi_tile();
    if (tname == "all" || tname == "errors") t_errors();
    if (tname == "all" || tname == "range")  t_out_of_range();
    if (tname == "all" || tname == "bp")     t_backpressure();
    drain();
    if (expq.size() != 0) begin errors++; $display("[TB][FAIL] %0d expected response flits never arrived", expq.size()); end
    $display("[TB] SUMMARY requests=%0d request_flits=%0d response_flits=%0d per_tile=%0d/%0d/%0d/%0d cycles=%0d",
             n_req, sent_flits, recv_flits, per_tile_rsp[0], per_tile_rsp[1], per_tile_rsp[2], per_tile_rsp[3], cyc);
    if (errors == 0) $display("RESULT: PASS  (tb_datafabric BACKEND=%0d, %0d response flits checked)", BACKEND, recv_flits);
    else             $display("RESULT: FAIL  (tb_datafabric BACKEND=%0d, %0d errors)", BACKEND, errors);
    $finish;
  end
  initial begin #300_000_000; $display("RESULT: FAIL  (tb_datafabric watchdog)"); $finish; end
endmodule
