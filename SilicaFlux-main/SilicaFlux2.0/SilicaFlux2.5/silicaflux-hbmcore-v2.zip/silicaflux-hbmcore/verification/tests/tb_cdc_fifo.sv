// tb_cdc_fifo.sv : dual-clock FIFO scoreboard test. Clock periods are unrelated (+WPER/+RPER, default 7 ns / 11 ns).
`timescale 1ns/1ps
module tb_cdc_fifo;
  parameter int unsigned W = 40, D = 8;
  int wper = 7, rper = 11;
  logic wclk = 0, rclk = 0;
  // ONE asynchronous reset source; each domain gets its own synchronised de-assertion (the reset-domain-crossing rule in sf_hbm_cdc_fifo.sv)
  logic rst_a_n = 0, wr_n, rr_n;
  sf_hbm_rst_sync u_wsync (.clk_i(wclk), .arst_n_i(rst_a_n), .srst_n_o(wr_n));
  sf_hbm_rst_sync u_rsync (.clk_i(rclk), .arst_n_i(rst_a_n), .srst_n_o(rr_n));
  initial begin void'($value$plusargs("WPER=%d", wper)); void'($value$plusargs("RPER=%d", rper)); end
  logic push, pop, full, empty; logic [W-1:0] wdata, rdata;
  sf_hbm_cdc_fifo #(.WIDTH(W), .DEPTH(D)) dut (.wclk_i(wclk), .wrst_n_i(wr_n), .push_i(push), .wdata_i(wdata), .full_o(full),
                                               .rclk_i(rclk), .rrst_n_i(rr_n), .pop_i(pop), .rdata_o(rdata), .empty_o(empty));
  // independent clocks with the requested periods
  initial begin wclk = 0; forever #(wper/2.0) wclk = ~wclk; end
  initial begin rclk = 0; forever #(rper/2.0) rclk = ~rclk; end
  logic [W-1:0] q [$];
  int errors = 0, pushed = 0, popped = 0, flushed = 0, resets = 0, wpct = 70, rpct = 60;
  logic [W-1:0] next_val = 40'h1;
  logic want_push = 0, want_pop = 0;
  // a producer/consumer gate push/pop with the CURRENT full/empty flag (combinational), as the contract requires
  assign push  = want_push && !full;
  assign wdata = next_val;
  assign pop   = want_pop && !empty;
  always @(posedge wclk) if (wr_n) begin
    if (push) begin q.push_back(wdata); pushed++; next_val <= next_val * 40'd6364136223 + 40'd1442695; end
    want_push <= (($urandom % 100) < wpct);
  end else want_push <= 1'b0;                          // a stale request must not fire right after reset release
  always @(posedge rclk) if (rr_n) begin
    if (pop) begin
      if (q.size() == 0) begin errors++; $display("[TB][FAIL] pop with empty reference"); end
      else begin
        logic [W-1:0] e; e = q.pop_front();
        if (e !== rdata) begin errors++; $display("[TB][FAIL] data mismatch exp=%h got=%h", e, rdata); end
        popped++;
      end
    end
    want_pop <= (($urandom % 100) < rpct);
  end else want_pop <= 1'b0;
  // reset in the middle of traffic: words still inside are discarded (counted as flushed), both flags must come back clean
  task automatic mid_run_reset(input string why);
    @(negedge wclk);                                   // no recorded push can coincide with the assertion
    flushed += q.size(); q.delete(); resets++;
    rst_a_n = 0; repeat (4) @(posedge wclk); repeat (4) @(posedge rclk);
    wpct = 0; rpct = 0;                                // keep the ports quiet while the flags are inspected
    @(negedge wclk); rst_a_n = 1;
    wait (wr_n && rr_n); repeat (3) @(posedge wclk); repeat (3) @(posedge rclk);
    if (full !== 1'b0)  begin errors++; $display("[TB][FAIL] full after reset (%s)", why); end
    if (empty !== 1'b1) begin errors++; $display("[TB][FAIL] not empty after reset (%s)", why); end
  endtask
  initial begin
    repeat (5) @(posedge wclk); rst_a_n = 1; wait (wr_n && rr_n); repeat (2) @(posedge rclk);
    // phase 1: write-heavy (fills), phase 2: read-heavy (drains), phase 3: balanced; then a mid-run reset
    wpct = 95; rpct = 20; repeat (3000) @(posedge wclk);
    wpct = 20; rpct = 95; repeat (3000) @(posedge wclk);
    wpct = 60; rpct = 60; repeat (3000) @(posedge wclk);
    // reset 1: while the FIFO is FULL (writer far ahead of the reader)
    wpct = 100; rpct = 5; repeat (300) @(posedge wclk);
    if (!full) begin errors++; $display("[TB][FAIL] test set-up: FIFO not full before reset 1"); end
    mid_run_reset("full");
    wpct = 60; rpct = 60; repeat (3000) @(posedge wclk);
    // reset 2: while words are crossing the pointer synchronisers (both sides busy)
    wpct = 100; rpct = 100; repeat (37) @(posedge wclk);
    mid_run_reset("streaming");
    wpct = 70; rpct = 70; repeat (3000) @(posedge wclk);
    wpct = 0;  repeat (200) @(posedge rclk);
    if (q.size() != 0) begin errors++; $display("[TB][FAIL] %0d words never popped (lost)", q.size()); end
    if (pushed != popped + flushed) begin errors++; $display("[TB][FAIL] pushed %0d != popped %0d + flushed-by-reset %0d", pushed, popped, flushed); end
    if (resets != 2) begin errors++; $display("[TB][FAIL] expected 2 mid-run resets, did %0d", resets); end
    $display("[TB] cdc_fifo wper=%0d rper=%0d pushed=%0d popped=%0d flushed_by_%0d_mid_run_resets=%0d", wper, rper, pushed, popped, resets, flushed);
    if (errors == 0 && pushed > 1000) $display("RESULT: PASS  (tb_cdc_fifo %0d words, clocks %0d/%0d ns)", popped, wper, rper);
    else $display("RESULT: FAIL  (tb_cdc_fifo errors=%0d)", errors);
    $finish;
  end
  initial begin #5_000_000; $display("RESULT: FAIL (tb_cdc_fifo watchdog)"); $finish; end
endmodule
