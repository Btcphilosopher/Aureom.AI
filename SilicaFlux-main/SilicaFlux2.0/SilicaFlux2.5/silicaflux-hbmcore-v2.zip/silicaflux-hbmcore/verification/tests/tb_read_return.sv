// =============================================================================
//  tb_read_return.sv  --  directed self-checking unit bench for sf_hbm_read_return (v2)
//
//  Covers the PHY-contract-violation paths that the system benches cannot reach with a
//  well-behaved DRAM model (independent review finding: late data of a timed-out read was
//  delivered to the NEXT read with HERR_NONE):
//    S1 on-time returns -> data and HERR_NONE, strict allocation order
//    S2 timeout, then the late data arrives before the next read's due cycle
//       -> late data dropped (rd_orphan_drop_o), next read gets ITS OWN data with HERR_NONE
//    S3 timeout, data truly lost -> reads completing while the orphan is pending are poisoned
//       (HERR_FLUSHED); after the quiet window the path is clean again
//    S4 early (off-time) return with no timeout -> poisoned, rd_timing_err_o pulses
//    S5 writes, error entries and reads interleaved under response back-pressure -> order kept,
//       nothing lost or duplicated
//  The expected response of every allocated entry is written down when it is pushed; the
//  checker pops the expectation queue on every accepted response (no response may be missing,
//  extra, out of order, or carry a different payload).
//  RESULT: PASS / RESULT: FAIL (regression marker).
// =============================================================================
`timescale 1ns/1ps
module tb_read_return;
  import sf_hbm_pkg::*;

  localparam int unsigned CPL = 8;
  localparam int unsigned RDT = 16;          // RD_TIMEOUT
  localparam int unsigned RL  = 4;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  hbm_timing_t tp;
  hbm_cyc_t    cyc;
  logic        push_v, credit, wr_done_v, rd_v, rd_corr, rsp_v, rsp_rdy;
  hbm_ctx_t    push_ctx;
  logic [1:0]  push_kind;
  logic [$clog2(CPL)-1:0] push_idx, wr_done_idx;
  hbm_data_t   rd_data;
  hbm_err_e    rd_err;
  hbm_rsp_t    rsp;
  logic [5:0]  rsp_bytes;
  logic [15:0] rsp_lat;
  logic [$clog2(CPL):0] occ;
  logic        t_err, t_out, t_unexp, t_orph;

  sf_hbm_read_return #(.CPL_DEPTH(CPL), .RD_EXTRA_LAT(0), .RD_TIMEOUT(RDT)) dut (
    .clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .cyc_i(cyc),
    .push_valid_i(push_v), .push_ctx_i(push_ctx), .push_kind_i(push_kind), .push_idx_o(push_idx), .credit_o(credit),
    .wr_done_valid_i(wr_done_v), .wr_done_idx_i(wr_done_idx),
    .rd_valid_i(rd_v), .rd_data_i(rd_data), .rd_err_i(rd_err), .rd_corr_i(rd_corr),
    .rsp_valid_o(rsp_v), .rsp_ready_i(rsp_rdy), .rsp_o(rsp), .rsp_bytes_o(rsp_bytes), .rsp_lat_o(rsp_lat),
    .occ_o(occ), .rd_timing_err_o(t_err), .rd_timeout_o(t_out), .rd_unexpected_o(t_unexp), .rd_orphan_drop_o(t_orph)
  );

  // ---------------------------------------------------------------- expectations
  typedef struct { int id; bit write; hbm_err_e err; hbm_data_t data; bit check_data; } exp_t;
  exp_t expq [$];
  int   errors = 0, rsp_cnt = 0, orph_cnt = 0, tout_cnt = 0, terr_cnt = 0;
  int   rsp_ready_pct = 100;
  int seed = 1;

  always_ff @(posedge clk or negedge rst_n) if (!rst_n) cyc <= '0; else cyc <= cyc + hbm_cyc_t'(1);

  always_ff @(posedge clk) if (rst_n) begin
    if (t_orph) orph_cnt++;
    if (t_out)  tout_cnt++;
    if (t_err)  terr_cnt++;
    if (t_unexp) begin $display("[TB] ERROR unexpected read return"); errors++; end
    if (rsp_v && rsp_rdy) begin
      exp_t e;
      rsp_cnt++;
      if (expq.size() == 0) begin $display("[TB] ERROR response id%0d with nothing expected", rsp.id); errors++; end
      else begin
        e = expq.pop_front();
        if (int'(rsp.id) != e.id || rsp.write != e.write || rsp.err != e.err ||
            (e.check_data && rsp.data != e.data)) begin
          $display("[TB] ERROR response mismatch: got id%0d wr%0d err=%s data=%h | exp id%0d wr%0d err=%s data=%h",
                   rsp.id, rsp.write, rsp.err.name(), rsp.data[31:0], e.id, e.write, e.err.name(), e.data[31:0]);
          errors++;
        end
      end
    end
  end

  // response back-pressure
  always_ff @(posedge clk) rsp_rdy <= ($unsigned($random(seed)) % 100) < rsp_ready_pct;

  // ---------------------------------------------------------------- driver helpers
  task automatic idle();
    push_v = 0; wr_done_v = 0; rd_v = 0;
  endtask

  // push one entry; returns the cycle stamp of the push (for the due-time computation)
  task automatic push(input int id, input logic [1:0] kind, input hbm_err_e err, output hbm_cyc_t t_push,
                      output logic [$clog2(CPL)-1:0] idx);
    @(negedge clk);
    while (!credit) @(negedge clk);
    push_v = 1; push_kind = kind; push_ctx = '0; push_ctx.id = hbm_id_t'(id); push_ctx.write = (kind == 2'd1);
    push_ctx.err = err; push_ctx.bytes = 6'd32;
    t_push = cyc; idx = push_idx;
    @(negedge clk); push_v = 0;
  endtask

  // drive a read return at absolute cycle `at`
  task automatic ret_at(input hbm_cyc_t at, input hbm_data_t d);
    while (cyc != at) @(negedge clk);
    rd_v = 1; rd_data = d; rd_err = HERR_NONE; rd_corr = 0;
    @(negedge clk); rd_v = 0;
  endtask

  task automatic wait_drain(input int max_cycles);
    int n = 0;
    while ((expq.size() != 0) && n < max_cycles) begin @(negedge clk); n++; end
    if (expq.size() != 0) begin $display("[TB] ERROR drain timeout, %0d responses missing", expq.size()); errors++; end
  endtask

  function automatic hbm_data_t pat(input int k);
    return {8{32'(32'hA000_0000 + k)}};
  endfunction

  function automatic exp_t E(input int id, input bit wr, input hbm_err_e er, input hbm_data_t d, input bit cd);
    exp_t e; e.id = id; e.write = wr; e.err = er; e.data = d; e.check_data = cd; return e;
  endfunction

  hbm_cyc_t tp1, tp2, tp3;
  logic [$clog2(CPL)-1:0] ix1, ix2, ix3;

  initial begin
    void'($value$plusargs("SEED=%d", seed));
    tp = '0; tp.rl = 16'(RL);
    idle(); push_ctx = '0; push_kind = 0; wr_done_idx = 0; rd_data = '0; rd_err = HERR_NONE; rd_corr = 0;
    repeat (3) @(negedge clk); rst_n = 1; repeat (2) @(negedge clk);

    // ---- S1: on-time returns
    $display("[TB] S1 on-time returns");
    push(1, 2'd0, HERR_NONE, tp1, ix1); expq.push_back(E(1, 0, HERR_NONE, pat(1), 1));
    push(2, 2'd0, HERR_NONE, tp2, ix2); expq.push_back(E(2, 0, HERR_NONE, pat(2), 1));
    fork
      ret_at(tp1 + 16'(1 + RL), pat(1));
    join
    ret_at(tp2 + 16'(1 + RL), pat(2));
    wait_drain(200);

    // ---- S2: timeout, late data arrives before the next read's due cycle
    $display("[TB] S2 timeout + late data before the next read (review scenario)");
    push(3, 2'd0, HERR_NONE, tp1, ix1); expq.push_back(E(3, 0, HERR_FLUSHED, '0, 0));
    while (tout_cnt == 0) @(negedge clk);                      // read 3 times out
    push(4, 2'd0, HERR_NONE, tp2, ix2); expq.push_back(E(4, 0, HERR_NONE, pat(4), 1));
    @(negedge clk);
    rd_v = 1; rd_data = pat(3); @(negedge clk); rd_v = 0;      // read 3's LATE data (off-time for read 4)
    ret_at(tp2 + 16'(1 + RL), pat(4));                          // read 4's own data, on time
    wait_drain(200);
    if (orph_cnt != 1) begin $display("[TB] ERROR S2 expected 1 orphan drop, saw %0d", orph_cnt); errors++; end

    // ---- S3: timeout with the data truly lost -> poison window, then quiet-window resync
    $display("[TB] S3 lost data: poison window then resync");
    tout_cnt = 0;
    push(5, 2'd0, HERR_NONE, tp1, ix1); expq.push_back(E(5, 0, HERR_FLUSHED, '0, 0));
    while (tout_cnt == 0) @(negedge clk);
    push(6, 2'd0, HERR_NONE, tp2, ix2); expq.push_back(E(6, 0, HERR_FLUSHED, '0, 0));  // ambiguous: poisoned
    ret_at(tp2 + 16'(1 + RL), pat(6));
    wait_drain(200);
    repeat (RDT + 4) @(negedge clk);                            // quiet window -> orphans cleared
    push(7, 2'd0, HERR_NONE, tp3, ix3); expq.push_back(E(7, 0, HERR_NONE, pat(7), 1));
    ret_at(tp3 + 16'(1 + RL), pat(7));
    wait_drain(200);

    // ---- S4: early off-time return, no timeout -> poisoned
    $display("[TB] S4 early return");
    terr_cnt = 0;
    push(8, 2'd0, HERR_NONE, tp1, ix1); expq.push_back(E(8, 0, HERR_FLUSHED, '0, 0));
    ret_at(tp1 + 16'(RL), pat(8));                              // one cycle early
    wait_drain(200);
    if (terr_cnt != 1) begin $display("[TB] ERROR S4 expected one timing-error pulse, saw %0d", terr_cnt); errors++; end

    // ---- S5: mixed reads / writes / error entries under back-pressure
    $display("[TB] S5 mixed traffic under back-pressure");
    rsp_ready_pct = 35;
    for (int k = 0; k < 60; k++) begin
      int kind; kind = $unsigned($random(seed)) % 3;
      if (kind == 0) begin
        push(100 + k, 2'd0, HERR_NONE, tp1, ix1); expq.push_back(E((100 + k) % 256, 0, HERR_NONE, pat(100 + k), 1));
        ret_at(tp1 + 16'(1 + RL), pat(100 + k));
      end else if (kind == 1) begin
        push(100 + k, 2'd1, HERR_NONE, tp1, ix1); expq.push_back(E((100 + k) % 256, 1, HERR_NONE, '0, 0));
        @(negedge clk); wr_done_v = 1; wr_done_idx = ix1; @(negedge clk); wr_done_v = 0;
      end else begin
        push(100 + k, 2'd2, HERR_RANGE, tp1, ix1); expq.push_back(E((100 + k) % 256, 0, HERR_RANGE, '0, 0));
      end
    end
    wait_drain(2000);

    repeat (5) @(negedge clk);
    if (occ != '0) begin $display("[TB] ERROR completion buffer not empty at the end (occ=%0d)", occ); errors++; end
    $display("[TB] responses=%0d orphan_drops=%0d timeouts=%0d", rsp_cnt, orph_cnt, tout_cnt);
    if (errors == 0) $display("RESULT: PASS  (tb_read_return, %0d responses checked)", rsp_cnt);
    else             $display("RESULT: FAIL  (tb_read_return, %0d errors)", errors);
    $finish;
  end

  initial begin #2000000 $display("RESULT: FAIL  (tb_read_return global timeout)"); $finish; end
endmodule
