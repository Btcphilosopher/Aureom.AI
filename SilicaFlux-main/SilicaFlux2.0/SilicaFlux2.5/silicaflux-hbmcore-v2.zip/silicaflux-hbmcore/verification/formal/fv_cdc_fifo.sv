// =============================================================================
//  fv_cdc_fifo.sv  --  formal harness for sf_hbm_cdc_fifo (WIDTH = 2, DEPTH = 4)
//  See docs/FORMAL.md ("sf_hbm_cdc_fifo").
//
//  Two configurations (macro FV_SINGLE):
//    default      MULTICLOCK (sby `multiclock on`): wclk and rclk are free inputs, so every interleaving of
//                 write-clock and read-clock edges is explored (arbitrary ratio, phase, simultaneous edges).
//                 NOT modelled: metastability and per-bit skew of the 2-flop synchronisers. The justification
//                 for dropping skew is the Gray-code adjacency property (C1): a pointer never changes in more
//                 than one bit per update, so a bit-skewed sample can only equal the OLD or the NEW pointer,
//                 and both are covered by the atomic-sampling model.
//    FV_SINGLE    single-clock abstraction (wclk = rclk = clk): small enough for k-induction (UNBOUNDED for
//                 that abstraction only, which has no clock-ratio freedom).
//
//  Properties (all evaluated at every global step):
//    C1 Gray adjacency / pointer algebra:  g(next) differs from g(cur) in <= 1 bit; gray == bin2gray(bin);
//                                          DUT binary pointers == ghost counts of ACCEPTED pushes / pops
//    C2 no overflow:    accepted pushes - accepted pops <= DEPTH   (full_o never allows overwriting unread data)
//    C3 no underflow:   accepted pops <= accepted pushes            (empty_o never allows reading unwritten data)
//    C4 !full_o => occupancy <= DEPTH-1 ;  !empty_o => occupancy >= 1   (full/empty are pessimistic, never optimistic)
//    C5 data order/integrity of a TRACKED symbolic word n (n is a stable free input): when word n is at the read
//       head (!empty_o, pops == n) it has been pushed and rdata_o equals the value pushed as word n.
//  Environment: push_i / pop_i / wdata_i are completely free (push while full and pop while empty are ignored by
//  contract, so they are legal stimulus). Resets: each domain is released by its OWN clock (first edge) -> the
//  documented "assert both, release each synchronously" rule.  Stable input `trk`.
// =============================================================================
module fv_cdc_fifo (
`ifdef FV_SINGLE
  input  logic       clk,
`else
  input  logic       wclk,
  input  logic       rclk,
`endif
  input  logic       push_i,
  input  logic [1:0] wdata_i,
  input  logic       pop_i,
  input  logic [2:0] trk
);
  localparam int unsigned DEPTH = 4;
  localparam int unsigned AW    = 2;

`ifdef FV_SINGLE
  wire wclk = clk;
  wire rclk = clk;
`endif

  // reset: both domains in reset at the start; each released after its own first clock edge
  logic w_init = 1'b1, r_init = 1'b1;
  always @(posedge wclk) w_init <= 1'b0;
  always @(posedge rclk) r_init <= 1'b0;
  wire wrst_n = !w_init;
  wire rrst_n = !r_init;

  logic       full, empty;
  logic [1:0] rdata;
  sf_hbm_cdc_fifo #(.WIDTH(2), .DEPTH(DEPTH)) dut (
    .wclk_i(wclk), .wrst_n_i(wrst_n), .push_i(push_i), .wdata_i(wdata_i), .full_o(full),
    .rclk_i(rclk), .rrst_n_i(rrst_n), .pop_i(pop_i), .rdata_o(rdata), .empty_o(empty)
  );

  // ---- ghost model: counts of ACCEPTED pushes / pops and the tracked word -----------------------------------
  logic [2:0] gw = '0, gr = '0;              // mod 8 (occupancy <= 4 so the difference is unambiguous)
  logic       trk_pushed = 1'b0;
  logic [1:0] trk_data   = '0;
  always @(posedge wclk) if (!w_init && push_i && !full) begin
    gw <= gw + 3'd1;
    if (gw == trk) begin trk_pushed <= 1'b1; trk_data <= wdata_i; end
  end
  always @(posedge rclk) if (!r_init && pop_i && !empty) gr <= gr + 3'd1;

  // `trk` is a free input that must stay constant: remember the first value and assume it never changes
  logic       trk_seen = 1'b0;
  logic [2:0] trk_q    = '0;
  always @(posedge wclk) begin trk_seen <= 1'b1; trk_q <= trk; end
  always_comb if (trk_seen) assume(trk == trk_q);

  wire [2:0] occ = gw - gr;                 // modular occupancy of the ACCEPTED traffic

  function automatic logic [AW:0] b2g(input logic [AW:0] b); return b ^ (b >> 1); endfunction

  // ---- PROPERTIES ---------------------------------------------------------------------------------------------
  always_comb begin
    // C1 pointer algebra (DUT internals)
    assert($countones(dut.wgray_next ^ dut.wgray_q) <= 1);
    assert($countones(dut.rgray_next ^ dut.rgray_q) <= 1);
    assert(dut.wgray_q == b2g(dut.wbin_q));
    assert(dut.rgray_q == b2g(dut.rbin_q));
    if (!w_init) assert(dut.wbin_q == gw);
    if (!r_init) assert(dut.rbin_q == gr);
    if (!w_init && !r_init) begin
      assert(occ <= 3'(DEPTH));             // C2 + C3: occupancy of accepted traffic is within [0, DEPTH]
                                            //   (an underflow would wrap to 7, 6, 5; an overflow would be 5, 6, ..)
      if (!full)  assert(occ <= 3'(DEPTH - 1));   // C4
      if (!empty) assert(occ >= 3'd1);
      // inductive strengthening: while the tracked word is inside the FIFO, ghost and memory agree
      if ((trk - gr) < occ) begin
        assert(trk_pushed);
        assert(dut.mem[trk[AW-1:0]] == trk_data);
      end
      // C5 tracked word
      if (!empty && gr == trk) begin
        assert(trk_pushed);
        assert(rdata == trk_data);
      end
    end
  end

  // ---- COVER -----------------------------------------------------------------------------------------------------
  always_comb if (!w_init && !r_init) begin
    cover(full);                                              // FIFO full (4 words)
    cover(full && push_i);                                    // push attempted while full (ignored)
    cover(empty && pop_i && gw != 3'd0);                      // empty (after traffic) with a pop attempt
    cover(!empty && gr == trk && trk_pushed && gr == 3'd2);   // tracked word (index 2) reaches the head
`ifdef FV_SINGLE
    cover(!empty && gr == trk && trk_pushed && gr == 3'd5);   // ... and after the pointers wrapped (deep: single clock only)
    cover(gw >= 3'd6 && gr >= 3'd5);                          // pointers wrapped around
`endif
    cover(occ == 3'd3 && !full);
    cover(!empty && pop_i && occ == 3'd1);                    // last word popped
  end
endmodule
