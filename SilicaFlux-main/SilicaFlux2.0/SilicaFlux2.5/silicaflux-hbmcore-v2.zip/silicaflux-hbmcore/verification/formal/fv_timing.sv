// =============================================================================
//  fv_timing.sv  --  formal harness for sf_hbm_timing  (STRETCH; 2 bank groups, small symbolic profile)
//  See docs/FORMAL.md ("sf_hbm_timing").
//
//  Legal environment: one command per cycle; a command is issued only while its ok_* flag is high
//  (ACT: ok_act[bg], RD: ok_rd[bg], WR: ok_wr[bg], REF_AB/MRS: ok_ref). Then, against ghost "cycles since the
//  last event" counters (sat. at 15):
//     tRRD_S/L, tFAW (4th most recent ACT), tCCD_S/L, WR->RD (WL+BL+tWTR_S/L), RD->WR (RL+BL+2-WL),
//     tRFC (REF_AB -> ACT / REF), tMRD (MRS -> any), tXP (PDX -> any), tXS (SRX -> any)
//  must be respected whenever the corresponding ok_* output is high, and violation_o must never fire.
//  Environment assumptions: E0 profile = free input held constant, fields small (<= 4, tFAW <= 6, WL <= 3,
//  RL <= 4, burst <= 2); E1 one command per cycle; E2 legal strobes only.
//  BOUNDED (BMC) -- no inductive invariants were written for the 4-slot tFAW window.
// =============================================================================
module fv_timing
  import sf_hbm_pkg::*;
(
  input  logic        clk,
  input  hbm_timing_t tp,
  input  logic        act_i, rd_i, wr_i,
  input  hbm_bg_t     bg_i,
  input  logic        refab_i, mrs_i, pdx_i, srx_i
);
  localparam int unsigned NBG = HBM_NUM_BG;

  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  hbm_timing_t tp_prev = '0;
  always @(posedge clk) tp_prev <= tp;
  always @(posedge clk) begin
    assume(init || tp == tp_prev);                                                       // E0
    assume(tp.trrd_s <= 16'd4 && tp.trrd_l <= 16'd4 && tp.tccd_s <= 16'd4 && tp.tccd_l <= 16'd4);
    assume(tp.tfaw <= 16'd6 && tp.twtr_s <= 16'd3 && tp.twtr_l <= 16'd3);
    assume(tp.wl <= 16'd3 && tp.rl <= 16'd4 && tp.burst <= 16'd2);
    assume(tp.trfc <= 16'd4 && tp.tmrd <= 16'd4 && tp.txp <= 16'd4 && tp.txs <= 16'd4);
  end

  logic [NBG-1:0] ok_act, ok_rd, ok_wr;
  logic ok_ref, ok_misc, busy, violation;
  sf_hbm_timing dut (
    .clk_i(clk), .rst_ni(rst_n), .tp_i(tp),
    .act_i(act_i), .rd_i(rd_i), .wr_i(wr_i), .bg_i(bg_i),
    .refab_i(refab_i), .mrs_i(mrs_i), .pdx_i(pdx_i), .srx_i(srx_i),
    .ok_act_o(ok_act), .ok_rd_o(ok_rd), .ok_wr_o(ok_wr), .ok_ref_o(ok_ref), .ok_misc_o(ok_misc),
    .busy_o(busy), .violation_o(violation)
  );

  // ---- E1/E2 ------------------------------------------------------------------------------------
  wire [6:0] strobes = {act_i, rd_i, wr_i, refab_i, mrs_i, pdx_i, srx_i};
  always @(posedge clk) if (!init) begin
    assume($onehot0(strobes));
    assume(!act_i || ok_act[bg_i]);
    assume(!rd_i  || ok_rd[bg_i]);
    assume(!wr_i  || ok_wr[bg_i]);
    assume(!(refab_i || mrs_i) || ok_ref);
  end

  // ---- ghost event ages (1 = the cycle after the event) ----------------------------------------------------
  function automatic logic [3:0] sat_inc(input logic [3:0] a);
    sat_inc = (a == 4'd15) ? a : a + 4'd1;
  endfunction
  function automatic logic [15:0] max1(input logic [15:0] n);
    max1 = (n == 16'd0) ? 16'd1 : n;
  endfunction

  logic [3:0] a_act [NBG], a_col [NBG], a_wr [NBG];   // per group: last ACT / last RD|WR / last WR
  logic [NBG-1:0] s_act = '0, s_col = '0, s_wr = '0;
  logic [3:0] a_rd = 4'd15, a_ref = 4'd15, a_mrd = 4'd15, a_x = 4'd15;     // last RD (any group) / REF_AB / MRS / PDX|SRX
  logic       s_rd = 1'b0, s_ref = 1'b0, s_mrd = 1'b0, s_x = 1'b0;
  logic [15:0] x_len = '0;
  logic [3:0] f0 = 4'd15, f1 = 4'd15, f2 = 4'd15, f3 = 4'd15;               // ages of the last four ACTs (f0 newest)
  logic [2:0] n_act = '0;                                                    // ACTs seen (saturating at 4)
  initial for (int g = 0; g < NBG; g++) begin a_act[g] = 4'd15; a_col[g] = 4'd15; a_wr[g] = 4'd15; end

  always @(posedge clk) if (!init) begin
    for (int g = 0; g < NBG; g++) begin
      a_act[g] <= sat_inc(a_act[g]); a_col[g] <= sat_inc(a_col[g]); a_wr[g] <= sat_inc(a_wr[g]);
    end
    a_rd <= sat_inc(a_rd); a_ref <= sat_inc(a_ref); a_mrd <= sat_inc(a_mrd); a_x <= sat_inc(a_x);
    f0 <= sat_inc(f0); f1 <= sat_inc(f1); f2 <= sat_inc(f2); f3 <= sat_inc(f3);
    if (act_i) begin
      a_act[bg_i] <= 4'd1; s_act[bg_i] <= 1'b1;
      f0 <= 4'd1; f1 <= sat_inc(f0); f2 <= sat_inc(f1); f3 <= sat_inc(f2);
      if (n_act != 3'd4) n_act <= n_act + 3'd1;
    end
    if (rd_i || wr_i) begin a_col[bg_i] <= 4'd1; s_col[bg_i] <= 1'b1; end
    if (rd_i) begin a_rd <= 4'd1; s_rd <= 1'b1; end
    if (wr_i) begin a_wr[bg_i] <= 4'd1; s_wr[bg_i] <= 1'b1; end
    if (refab_i) begin a_ref <= 4'd1; s_ref <= 1'b1; end
    if (mrs_i)   begin a_mrd <= 4'd1; s_mrd <= 1'b1; end
    if (pdx_i)   begin a_x <= 4'd1; s_x <= 1'b1; x_len <= tp.txp; end
    if (srx_i)   begin a_x <= 4'd1; s_x <= 1'b1; x_len <= tp.txs; end
  end

  wire [15:0] k_rtw = (tp.rl + tp.burst + 16'd2 > tp.wl) ? (tp.rl + tp.burst + 16'd2 - tp.wl) : 16'd1;

  // ---- PROPERTIES -------------------------------------------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    assert(!violation);                                                    // legal environment => no violation
    for (int g = 0; g < NBG; g++) begin
      if (ok_act[g]) begin
        for (int h = 0; h < NBG; h++)                                      // tRRD_S / tRRD_L
          if (s_act[h]) assert(16'(a_act[h]) >= max1(h == g ? tp.trrd_l : tp.trrd_s));
        if (n_act == 3'd4) assert(16'(f3) >= max1(tp.tfaw));               // tFAW: at most 4 ACT per window
      end
      if (ok_rd[g]) begin
        for (int h = 0; h < NBG; h++) begin
          if (s_col[h]) assert(16'(a_col[h]) >= max1(h == g ? tp.tccd_l : tp.tccd_s));                       // tCCD_S / L
          if (s_wr[h])  assert(16'(a_wr[h])  >= max1(tp.wl + tp.burst + (h == g ? tp.twtr_l : tp.twtr_s))); // WR -> RD
        end
      end
      if (ok_wr[g]) begin
        for (int h = 0; h < NBG; h++)
          if (s_col[h]) assert(16'(a_col[h]) >= max1(h == g ? tp.tccd_l : tp.tccd_s));
        if (s_rd) assert(16'(a_rd) >= max1(k_rtw));                        // RD -> WR turnaround
      end
    end
    if (|ok_act && s_ref) assert(16'(a_ref) >= max1(tp.trfc));             // tRFC
    if (ok_ref  && s_ref) assert(16'(a_ref) >= max1(tp.trfc));
    // tMRD / tXP / tXS block everything
    if (s_mrd && (|ok_act || |ok_rd || |ok_wr || ok_ref || ok_misc)) assert(16'(a_mrd) >= max1(tp.tmrd));
    if (s_x   && (|ok_act || |ok_rd || |ok_wr || ok_ref || ok_misc)) assert(16'(a_x)   >= max1(x_len));
  end

  // ---- COVER ----------------------------------------------------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    cover(act_i);
    cover(rd_i && bg_i == 1'b0 && s_col[0] && a_col[0] <= 4'd3);                       // back-to-back column commands, same group
    cover(wr_i); cover(rd_i);
    cover(refab_i); cover(mrs_i); cover(pdx_i); cover(srx_i);
    cover(n_act == 3'd4 && |ok_act);                                                    // 4 ACTs in the window and ACT allowed again
    cover(!dut.faw_ok && dut.c_rrd[0] == 16'd0 && dut.c_rrd[1] == 16'd0 && dut.c_rfc == 16'd0);   // tFAW is the only blocker
    cover(!ok_rd[0] && ok_rd[1]);                                                       // tCCD_L / tWTR_L blocks the same group only
    cover(s_wr[0] && !ok_rd[0] && ok_wr[0]);                                            // WR -> RD turnaround binding
    cover(s_rd && !ok_wr[0] && ok_rd[0] && dut.c_ccd[0] == 16'd0);                      // RD -> WR turnaround binding
  end
endmodule
