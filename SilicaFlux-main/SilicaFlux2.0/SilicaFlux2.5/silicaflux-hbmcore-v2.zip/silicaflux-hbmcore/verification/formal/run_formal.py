#!/usr/bin/env python3
"""Run every SymbiYosys task in verification/formal/*.sby and write reports/formal.json.

Usage (normally through run_formal.sh):
    run_formal.sh                       # all modules, all tasks, JOBS=2
    run_formal.sh -m req_queue          # only .sby files whose name contains the substring
    run_formal.sh -t '^prove$'          # only tasks whose name matches the regex
    run_formal.sh --no-mutants          # skip the mutant (expected-FAIL) tasks
    run_formal.sh --mutants-only
    JOBS=1 TASK_TIMEOUT=600 run_formal.sh

Result semantics (see docs/FORMAL.md):
    kind "property" : expected PASS.  mode prove -> UNBOUNDED when it passes, bmc -> BOUNDED.
    kind "cover"    : expected PASS (every cover statement reachable within `depth`).
    kind "mutant"   : expected FAIL (a deliberately buggy copy of the RTL must be rejected).
    "result" is PASS only when SymbiYosys itself says PASS; anything else (FAIL, UNKNOWN,
    TIMEOUT, ERROR) is recorded as FAIL with the raw status in "status".
    "ok" = result matches expectation (mutants: FAIL == killed).  A property that fails on the
    real RTL is a documented Finding (KNOWN_FINDINGS below + docs/FORMAL.md); it is reported as
    ok=false, finding=true and does not make the script fail.
"""
import argparse
import concurrent.futures as cf
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
REPORT = os.path.join(ROOT, "reports", "formal.json")

# "module:task" pairs that fail on the REAL RTL and are documented under "Findings" in docs/FORMAL.md
KNOWN_FINDINGS = set()

YOWASP_BIN = os.environ.get("YOWASP_BIN") or (os.path.dirname(shutil.which("yowasp-sby")) if shutil.which("yowasp-sby") else "/tmp/venv_yw/bin")   # pip install yowasp-yosys
ABC_BIN = os.environ.get("ABC_BIN", "/usr/bin/yosys-abc")
WORK = os.environ.get("FORMAL_WORK", os.path.join(os.environ.get("TMPDIR", "/tmp"), "sf_formal_work"))
JOBS = int(os.environ.get("JOBS", "2"))
TASK_TIMEOUT = int(os.environ.get("TASK_TIMEOUT", "420"))


_TOOLS = None


def _ensure_tools():
    """Create $WORK/bin with the shims sby needs:
         yosys-witness / yosys-smtbmc / yosys  -> the YoWASP wrappers (the AIGER flow shells out to these by name;
                                                  the system yosys 0.33 is too old for the witness format)
         abc                                   -> ABC_BIN, with `pdr -v -l` rewritten to `pdr -v` (the new sby passes
                                                  an option the system yosys-abc 0.33 does not know)."""
    global _TOOLS
    if _TOOLS:
        return _TOOLS
    bindir = os.path.join(WORK, "bin")
    os.makedirs(bindir, exist_ok=True)
    for name, target in (("yosys-witness", "yowasp-yosys-witness"), ("yosys-smtbmc", "yowasp-yosys-smtbmc"),
                         ("yosys", "yowasp-yosys")):
        link = os.path.join(bindir, name)
        tgt = os.path.join(YOWASP_BIN, target)
        if os.path.lexists(link):
            os.remove(link)
        os.symlink(tgt, link)
    wrap = os.path.join(bindir, "abc_wrap")
    with open(wrap, "w") as f:
        f.write("#!/bin/bash\nargs=()\nfor a in \"$@\"; do args+=(\"${a//pdr -v -l/pdr -v}\"); done\nexec %s \"${args[@]}\"\n" % ABC_BIN)
    os.chmod(wrap, 0o755)
    _TOOLS = (bindir, wrap)
    return _TOOLS


def tool_env():
    bindir, _ = _ensure_tools()
    env = dict(os.environ)
    env["PATH"] = bindir + os.pathsep + YOWASP_BIN + os.pathsep + env.get("PATH", "")
    return env


def sby_cmd():
    exe = shutil.which("yowasp-sby", path=YOWASP_BIN + os.pathsep + os.environ.get("PATH", ""))
    if exe is None:
        sys.exit("yowasp-sby not found (set YOWASP_BIN)")
    cmd = [exe, "--yosys", os.path.join(YOWASP_BIN, "yowasp-yosys"),
           "--smtbmc", os.path.join(YOWASP_BIN, "yowasp-yosys-smtbmc")]
    if os.path.exists(ABC_BIN):
        cmd += ["--abc", _ensure_tools()[1]]
    return cmd


def list_tasks(sby_file):
    out = subprocess.run(sby_cmd() + ["--dumptasks", sby_file], capture_output=True, text=True, cwd=HERE)
    if out.returncode != 0:
        sys.exit("cannot list tasks of %s:\n%s" % (sby_file, out.stderr))
    return [t.strip() for t in out.stdout.split() if t.strip()]


def task_cfg(sby_file, task):
    out = subprocess.run(sby_cmd() + ["--dumpcfg", sby_file, task], capture_output=True, text=True, cwd=HERE)
    mode, depth, engine = None, None, None
    sect = None
    for line in out.stdout.splitlines():
        line = line.strip()
        if line.startswith("["):
            sect = line
            continue
        if sect == "[options]":
            if line.startswith("mode "):
                mode = line.split()[1]
            elif line.startswith("depth "):
                depth = int(line.split()[1])
        elif sect == "[engines]" and line and engine is None:
            engine = line
    return mode, depth, engine


def classify(task):
    if task.startswith("mut_"):
        return "mutant"
    return "cover" if task == "cover" or task.endswith("_cover") else "property"


def run_one(item):
    sby_file, module, task, mode, depth, engine = item
    kind = classify(task)
    wd = os.path.join(WORK, "%s_%s" % (module, task))
    t0 = time.time()
    status = "ERROR"
    log = ""
    try:
        p = subprocess.run(sby_cmd() + ["-f", "-d", wd, sby_file, task], cwd=HERE,
                           capture_output=True, text=True, timeout=TASK_TIMEOUT, env=tool_env())
        log = p.stdout + p.stderr
        status = {0: "PASS", 2: "FAIL", 4: "UNKNOWN", 8: "TIMEOUT", 16: "ERROR"}.get(p.returncode, "ERROR")
    except subprocess.TimeoutExpired as e:
        status = "TIMEOUT"
        log = (e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        subprocess.run(["pkill", "-f", wd], capture_output=True)
    secs = round(time.time() - t0, 1)
    detail = ""
    m = re.findall(r"failed assertion \S+ at (\S+) step (\d+)", log)
    if m:
        detail = "first failing assertion at %s (step %s)" % (m[0][0].split("/")[-1], m[0][1])
    elif status == "PASS" and kind == "cover":
        detail = "all cover statements reached"
    elif status in ("ERROR", "UNKNOWN"):
        e = [l for l in log.splitlines() if "ERROR" in l or "failed for" in l or "induction" in l.lower() and "FAIL" in l]
        detail = (e[-1][:200] if e else "")
    result = "PASS" if status == "PASS" else "FAIL"
    expected = "FAIL" if kind == "mutant" else "PASS"
    key = "%s:%s" % (module, task)
    finding = (result != expected) and key in KNOWN_FINDINGS
    ok = (result == expected)
    if kind == "mutant" and status != "FAIL":
        ok = False        # an ERROR / TIMEOUT / UNKNOWN is not a kill
    # a prove task that returns UNKNOWN (induction failed, base case ok) is not a PASS and not a counterexample
    return {
        "module": module,
        "task": task,
        "kind": kind,
        "mode": mode,
        "depth": depth,
        "engine": engine,
        "result": result,
        "status": status,
        "expected": expected,
        "ok": ok,
        "finding": finding,
        "seconds": secs,
        "bounded": (mode != "prove"),
        "detail": detail,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-m", "--module", help="substring of the .sby file name")
    ap.add_argument("-t", "--task", help="regex on the task name")
    ap.add_argument("--no-mutants", action="store_true")
    ap.add_argument("--mutants-only", action="store_true")
    ap.add_argument("--json", default=REPORT)
    ap.add_argument("-j", "--jobs", type=int, default=JOBS)
    a = ap.parse_args()

    items = []
    for sby_file in sorted(glob.glob(os.path.join(HERE, "fv_*.sby"))):
        base = os.path.basename(sby_file)
        module = "sf_hbm_" + base[len("fv_"):-len(".sby")]
        if a.module and a.module not in base:
            continue
        for task in list_tasks(base):
            if a.task and not re.search(a.task, task):
                continue
            kind = classify(task)
            if a.no_mutants and kind == "mutant":
                continue
            if a.mutants_only and kind != "mutant":
                continue
            mode, depth, engine = task_cfg(base, task)
            items.append((base, module, task, mode, depth, engine))

    os.makedirs(WORK, exist_ok=True)
    print("running %d tasks, %d at a time (work dir %s)" % (len(items), a.jobs, WORK), flush=True)
    results = []
    with cf.ThreadPoolExecutor(max_workers=max(1, a.jobs)) as ex:
        for r in ex.map(run_one, items):
            tag = "ok " if r["ok"] else ("FND" if r["finding"] else "BAD")
            print("[%s] %-22s %-22s %-6s d=%-3s %-7s %6.1fs  %s" % (
                tag, r["module"], r["task"], r["mode"], r["depth"], r["status"], r["seconds"], r["detail"]), flush=True)
            results.append(r)

    # merge with an existing report when only a subset was run
    merged = {}
    if os.path.exists(a.json) and (a.module or a.task or a.no_mutants or a.mutants_only):
        try:
            for r in json.load(open(a.json)).get("tasks", []):
                merged[(r["module"], r["task"])] = r
        except Exception:
            pass
    for r in results:
        merged[(r["module"], r["task"])] = r
    tasks = [merged[k] for k in sorted(merged)]
    rtl_dir = os.path.join(ROOT, "rtl")
    rtl_digest = {}
    for fn in sorted(glob.glob(os.path.join(rtl_dir, "*.sv")) + glob.glob(os.path.join(rtl_dir, "*.svh"))):
        rtl_digest[os.path.basename(fn)] = hashlib.sha256(open(fn, "rb").read()).hexdigest()[:16]
    summary = {
        "tasks": len(tasks),
        "ok": sum(1 for r in tasks if r["ok"]),
        "findings": sum(1 for r in tasks if r["finding"]),
        "bad": sum(1 for r in tasks if not r["ok"] and not r["finding"]),
        "mutants": sum(1 for r in tasks if r["kind"] == "mutant"),
        "mutants_killed": sum(1 for r in tasks if r["kind"] == "mutant" and r["ok"]),
    }
    os.makedirs(os.path.dirname(a.json), exist_ok=True)
    with open(a.json, "w") as f:
        json.dump({"tool": "SymbiYosys + yosys-slang (YoWASP 0.71), solvers z3 --unroll / abc bmc3",
                   "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                   "rtl_sha256_16": rtl_digest,
                   "summary": summary, "tasks": tasks}, f, indent=2)
        f.write("\n")
    print("summary:", json.dumps(summary))
    print("report :", a.json)
    sys.exit(0 if summary["bad"] == 0 else 1)


if __name__ == "__main__":
    main()
