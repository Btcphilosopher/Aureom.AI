// =============================================================================
//  fv_refresh.sv  --  formal harness for sf_hbm_refresh  (all-bank mode, 4 banks)
//  See docs/FORMAL.md ("sf_hbm_refresh").
//
//  Properties
//    F1 debt bound       -max_pullin <= debt_o <= max_postpone   and   deadline_miss_o never fires
//                         (this implies "debt never exceeds max_postpone+1")
//    F2 hold             hold_act_o, once raised, is released only in the cycle after a REF_AB was granted
//    F3 REF vs rows      REF_AB is never presented while any bank row is open
//    F4 command set      only PREA / REF_AB are ever presented (all-bank mode); hold_act_o whenever the
//                         sequencer is active; ev_ref_o == "REF granted last cycle"
//  Environment (E-numbers are used in docs/FORMAL.md):
//    E0  profile = free input held constant; 24 <= tREFI <= 30, 1 <= max_postpone <= 3, 0 <= max_pullin <= 3
//    E1  enable_i = 1, pause_i = 0, block_i = 0, clear_i = 0, cfg.mode = REFMODE_AB (eager / pullin_en / queue_idle free)
//    E2  a presented maintenance command is granted within KG = 3 cycles; grant only for a presented command
//    E3  bk_idle_i[b] implies !bk_row_open_i[b]
//    E4  a bank row can only OPEN in a cycle after hold_act_o was low (the scheduler honours the ACT hold)
//    E5  the cycle after a granted PREA every row is closed
//    E6  a bank that is neither open nor idle (precharging / refreshing) becomes idle within KI = 3 cycles
//    E7  an idle bank stays idle unless a row is opened (E4) or a REF_AB was granted in the previous cycle
//        (idleness does not toggle spontaneously; without E7 the 4 banks need never be idle at the same time)
//  The result is only as strong as E2/E6 + tREFI >= 24: the refresh sequence needs <= ~13 cycles,
//  so a refresh always completes before the next tREFI tick.
// =============================================================================
module fv_refresh
  import sf_hbm_pkg::*;
(
  input  logic         clk,
  input  hbm_timing_t  tp,
  input  hbm_ref_cfg_t cfg,
  input  logic         queue_idle_i,
  input  logic [HBM_NUM_BANKS-1:0] bk_idle_i,
  input  logic [HBM_NUM_BANKS-1:0] bk_row_open_i,
  input  logic         mnt_grant_i
`ifdef FV_BLOCK
  , input logic        block_i              // FV_BLOCK: block_i is a FREE input (observation cover only, see docs/FORMAL.md)
`endif
);
  localparam int unsigned NB = HBM_NUM_BANKS;
  localparam int unsigned KG = 3;
  localparam int unsigned KI = 3;

  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  // E0: constant profile
  hbm_timing_t tp_prev = '0;
  always @(posedge clk) tp_prev <= tp;
  always @(posedge clk) begin
    assume(init || tp == tp_prev);
    assume(tp.trefi >= 16'd24 && tp.trefi <= 16'd30);
    assume(tp.max_postpone >= 16'd1 && tp.max_postpone <= 16'd3);
    assume(tp.max_pullin <= 16'd3);
  end
  // E1: only the mode is constrained
  always @(posedge clk) assume(cfg.mode == REFMODE_AB);

`ifndef FV_BLOCK
  wire block_i = 1'b0;                      // E1
`endif
  logic         mnt_valid, mnt_prio, hold_act, hold_col, hold_bank_valid, hold_bank_col;
  hbm_cmd_t     mnt_cmd;
  logic [HBM_BANK_W-1:0] hold_bank;
  logic signed [7:0] debt;
  logic         urgent, active, ev_ref, ev_forced, ev_pullin, deadline_miss;

  sf_hbm_refresh dut (
    .clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .cfg_i(cfg),
    .enable_i(1'b1), .pause_i(1'b0), .block_i(block_i), .clear_i(1'b0),
    .queue_idle_i(queue_idle_i), .bk_idle_i(bk_idle_i), .bk_row_open_i(bk_row_open_i),
    .rfm_req_i(1'b0), .rfm_bank_i('0), .rfm_row_i('0), .ev_rfm_o(),     // v2: RFM path not exercised by this all-bank harness
    .mnt_valid_o(mnt_valid), .mnt_cmd_o(mnt_cmd), .mnt_prio_o(mnt_prio), .mnt_grant_i(mnt_grant_i),
    .hold_act_o(hold_act), .hold_col_o(hold_col), .hold_bank_valid_o(hold_bank_valid),
    .hold_bank_o(hold_bank), .hold_bank_col_o(hold_bank_col),
    .debt_o(debt), .urgent_o(urgent), .active_o(active),
    .ev_ref_o(ev_ref), .ev_forced_o(ev_forced), .ev_pullin_o(ev_pullin), .deadline_miss_o(deadline_miss)
  );

  // ---- snapshot / ghost ------------------------------------------------------------------
  logic pv_hold_act = 1'b0, pv_ref_granted = 1'b0, pv_prea_granted = 1'b0;
  logic [NB-1:0] pv_row_open = '0, pv_idle = '0;
  logic [1:0] gnt_wait = '0;
  logic [1:0] ni_cnt [NB];
  logic [2:0] n_ref = '0;
  initial for (int b = 0; b < NB; b++) ni_cnt[b] = '0;
  wire ref_granted  = mnt_valid && mnt_cmd.cmd == HCMD_REF_AB && mnt_grant_i;
  wire prea_granted = mnt_valid && mnt_cmd.cmd == HCMD_PREA   && mnt_grant_i;
  always @(posedge clk) begin
    pv_hold_act     <= hold_act && !init;
    pv_ref_granted  <= ref_granted && !init;
    pv_prea_granted <= prea_granted && !init;
    pv_row_open     <= bk_row_open_i;
    pv_idle         <= bk_idle_i & {NB{!init}};
    gnt_wait        <= (init || !mnt_valid || mnt_grant_i) ? 2'd0 : (gnt_wait == 2'd3 ? 2'd3 : gnt_wait + 2'd1);
    for (int b = 0; b < NB; b++)
      ni_cnt[b] <= (init || bk_row_open_i[b] || bk_idle_i[b]) ? 2'd0 : (ni_cnt[b] == 2'd3 ? 2'd3 : ni_cnt[b] + 2'd1);
    if (!init && ref_granted && n_ref != 3'd7) n_ref <= n_ref + 3'd1;
  end

  // ---- ENVIRONMENT ---------------------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    assume(!mnt_grant_i || mnt_valid);                                        // E2: grant only a presented command
    assume(!(mnt_valid && !mnt_grant_i && gnt_wait == 2'(KG-1)));             // E2: ... and within KG cycles
    for (int b = 0; b < NB; b++) begin
      assume(!bk_idle_i[b] || !bk_row_open_i[b]);                             // E3
      if (!pv_row_open[b] && bk_row_open_i[b]) assume(!pv_hold_act);          // E4
      assume(!(!bk_row_open_i[b] && !bk_idle_i[b] && ni_cnt[b] == 2'(KI-1))); // E6
      if (pv_idle[b] && !bk_row_open_i[b] && !pv_ref_granted) assume(bk_idle_i[b]); // E7
    end
    if (pv_prea_granted) assume(bk_row_open_i == '0);                         // E5
  end

  // ---- PROPERTIES -------------------------------------------------------------------------------
`ifndef FV_BLOCK
  always @(posedge clk) if (!init) begin
    // F1
    assert(!deadline_miss);
    assert(int'(debt) <= int'(tp.max_postpone));
    assert(int'(debt) >= -int'(tp.max_pullin));
    assert(int'(debt) <= int'(tp.max_postpone) + 1);                          // the (weaker) statement of the task
    // F2: hold_act released only after a granted REF
    if (pv_hold_act && !hold_act) assert(pv_ref_granted);
    // F3: never REF_AB with an open row
    if (mnt_valid && mnt_cmd.cmd == HCMD_REF_AB) assert(bk_row_open_i == '0);
    if (ref_granted) assert(bk_row_open_i == '0);
    // F4
    if (mnt_valid) assert(mnt_cmd.cmd == HCMD_PREA || mnt_cmd.cmd == HCMD_REF_AB);
    if (active)    assert(hold_act);
    assert(ev_ref == pv_ref_granted);
    assert(!hold_bank_valid);                                                 // all-bank mode: no per-bank hold
  end
`endif

  // ---- COVER ---------------------------------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    cover(ref_granted);                                                       // a refresh completes
    cover(prea_granted);                                                      // rows had to be closed first
    cover(urgent && mnt_valid && mnt_cmd.cmd == HCMD_REF_AB);                 // forced (urgent) refresh
    cover(int'(debt) == int'(tp.max_postpone) && !active);                    // debt at the postpone limit, sequence not yet running
    cover(int'(debt) < 0);                                                    // pull-in happened
    cover(pv_hold_act && !hold_act && pv_ref_granted && n_ref >= 3'd2);       // second refresh, hold released again
    cover(ev_forced);
    cover(ev_pullin);
`ifndef FV_BLOCK
    cover(mnt_valid && !mnt_grant_i && gnt_wait == 2'd2 - 2'd1);              // grant delayed (back-pressure on the command)
`else
    // OBSERVATION O1: block_i does not stop a sequence that is already past R_HOLD
    cover(block_i && mnt_valid && mnt_cmd.cmd == HCMD_REF_AB);                // REF_AB presented while block_i is high
    cover(block_i && mnt_valid && mnt_cmd.cmd == HCMD_PREA);
    cover(pv_hold_act && !hold_act && !pv_ref_granted);                       // ACT hold released with no REF (the R_HOLD abort)
`endif
  end
endmodule
