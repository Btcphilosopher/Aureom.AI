// =============================================================================
//  fv_rsp_arb.sv  --  formal harness for sf_hbm_rsp_arb (N = 3)
//  See docs/FORMAL.md ("sf_hbm_rsp_arb").
//
//  Safety properties (always on, proved unbounded by k-induction):
//    P1 exclusivity     at most one in_ready_o bit; in_ready_o != 0 <=> output handshake; ready only for a valid input
//    P2 selection       out_valid_o => in_valid_i[sel_o];  out_rsp_o == in_rsp_i[sel_o]
//    P3 1:1 handshakes  every output handshake == exactly one input handshake with the same payload
//                       (=> no response is duplicated, none is lost, none is invented)
//    P4 stability       out_valid_o && !out_ready_i  =>  next cycle: out_valid_o, same sel_o, same out_rsp_o
//  Fairness properties (macro FV_FAIR, bounded):
//    P5 round-robin     while input i waits, at most N-1 grants go to other inputs (no environment timing needed)
//    P6 bounded wait    if out_ready_i is high at least once in every window of 4 cycles, input i waits <= 11 cycles
//  Environment: E1 (source protocol) an input that is valid and not granted stays valid with an unchanged payload.
//               E2 (FV_FAIR only) out_ready_i is high at least once every 4 cycles.
// =============================================================================
module fv_rsp_arb
  import sf_hbm_pkg::*;
(
  input  logic              clk,
  input  logic [2:0]        in_valid_i,
  input  hbm_rsp_t [2:0]    in_rsp_i,
  input  logic              out_ready_i
);
  localparam int unsigned N = 3;

  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  logic [N-1:0]  in_ready;
  logic          out_valid;
  hbm_rsp_t      out_rsp;
  logic [1:0]    sel;

  sf_hbm_rsp_arb #(.N(N)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .in_valid_i(in_valid_i), .in_rsp_i(in_rsp_i), .in_ready_o(in_ready),
    .out_valid_o(out_valid), .out_rsp_o(out_rsp), .out_ready_i(out_ready_i), .sel_o(sel)
  );

  // ---- previous-cycle snapshot (cleared during the reset cycle) ---------------------
  logic            pv_out_valid = 1'b0, pv_out_ready = 1'b0;
  logic [1:0]      pv_sel = '0;
  hbm_rsp_t        pv_out_rsp = '0;
  logic [N-1:0]    pv_in_valid = '0, pv_in_ready = '0;
  hbm_rsp_t [N-1:0] pv_in_rsp = '0;
  always @(posedge clk) begin
    pv_out_valid <= out_valid && !init;
    pv_out_ready <= out_ready_i;
    pv_sel       <= sel;
    pv_out_rsp   <= out_rsp;
    pv_in_valid  <= in_valid_i & {N{!init}};
    pv_in_ready  <= in_ready;
    pv_in_rsp    <= in_rsp_i;
  end

  // ---- ENVIRONMENT -------------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    for (int i = 0; i < N; i++)
      if (pv_in_valid[i] && !pv_in_ready[i]) begin      // E1: a pending input is neither withdrawn nor changed
        assume(in_valid_i[i]);
`ifndef FV_FAIR                                          // (payload is irrelevant for fairness: keep the model small)
        assume(in_rsp_i[i] == pv_in_rsp[i]);
`endif
      end
  end

`ifdef FV_FAIR
  logic [1:0] nready_cnt = '0;                           // consecutive cycles with out_ready_i low
  always @(posedge clk) nready_cnt <= (init || out_ready_i) ? 2'd0 : (nready_cnt == 2'd3 ? 2'd3 : nready_cnt + 2'd1);
  always @(posedge clk) if (!init) assume(out_ready_i || nready_cnt != 2'd3);   // E2: ready at least once in any 4 cycles
`endif

  // ---- SAFETY PROPERTIES ---------------------------------------------------------------
  wire out_hs = out_valid && out_ready_i;
  always @(posedge clk) if (!init) begin
    // auxiliary inductive invariants on the DUT's own state (needed only for k-induction)
    assert(dut.ptr_q < 2'(N));
    assert(dut.lock_idx_q < 2'(N));
    if (dut.lock_q) assert(in_valid_i[dut.lock_idx_q]);          // a locked input never withdraws (follows from E1)
    assert($onehot0(in_ready));                                  // P1
    assert((in_ready != '0) == out_hs);
    for (int i = 0; i < N; i++) if (in_ready[i]) assert(in_valid_i[i]);
    if (out_valid) begin                                         // P2
      assert(sel < 2'(N));
      assert(in_valid_i[sel]);
`ifndef FV_FAIR
      assert(out_rsp == in_rsp_i[sel]);
`endif
    end
    // P3: output handshake <=> exactly one input handshake, carrying the same payload
    begin
      int unsigned n_hs;
      n_hs = 0;
      for (int i = 0; i < N; i++) n_hs += int'(in_valid_i[i] && in_ready[i]);
      assert(n_hs == (out_hs ? 1 : 0));
      for (int i = 0; i < N; i++)
        if (in_valid_i[i] && in_ready[i]) begin
          assert(out_hs);
`ifndef FV_FAIR
          assert(out_rsp == in_rsp_i[i]);
`endif
          assert(sel == 2'(i));
        end
    end
    // P4: stable valid / selection / payload under back-pressure
    if (pv_out_valid && !pv_out_ready) begin
      assert(out_valid);
      assert(sel == pv_sel);
`ifndef FV_FAIR
      assert(out_rsp == pv_out_rsp);
`endif
    end
  end

`ifdef FV_FAIR
  // ---- FAIRNESS ---------------------------------------------------------------------------
  logic [2:0] others [N];           // grants to other inputs while input i has been waiting
  logic [4:0] waitc  [N];           // cycles input i has been valid and not granted
  initial for (int i = 0; i < N; i++) begin others[i] = '0; waitc[i] = '0; end
  always @(posedge clk) if (!init) begin
    for (int i = 0; i < N; i++) begin
      if (!in_valid_i[i] || in_ready[i]) begin others[i] <= '0; waitc[i] <= '0; end
      else begin
        if (out_hs) others[i] <= others[i] + 3'd1;               // someone else won this cycle
        waitc[i] <= (waitc[i] == 5'd31) ? waitc[i] : waitc[i] + 5'd1;
      end
    end
  end
  // distance of input i from the round-robin pointer, in scan order (0 = scanned first)
  function automatic int unsigned rrdist(input logic [1:0] ptr, input int unsigned i);
    rrdist = (i + N - int'(ptr)) % N;
  endfunction
  always @(posedge clk) if (!init) begin
    for (int i = 0; i < N; i++) begin
      assert(others[i] <= 3'(N-1));                              // P5
      assert(waitc[i]  <= 5'd11);                                // P6 (3 handshakes, <=4 cycles each, 1st within 3)
      if (in_valid_i[i] && !in_ready[i]) begin
        // inductive strengthening (invariants of the waiting input i):
        //   every grant to another input moves the pointer strictly closer to i
        assert(int'(others[i]) + int'(rrdist(dut.ptr_q, i)) <= int'(N-1));
        //   time: each handshake costs <= 4 cycles, the open ready-low run is <= 3
        assert(int'(waitc[i]) <= 4*int'(others[i]) + int'(nready_cnt));
        //   a locked winner that was selected while i already waited is scanned no later than i
        if (dut.lock_q && others[i] != 3'd0) assert(rrdist(dut.ptr_q, int'(dut.lock_idx_q)) <= rrdist(dut.ptr_q, i));
      end
    end
  end
`endif

  // ---- COVER ---------------------------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    cover(in_ready[0]); cover(in_ready[1]); cover(in_ready[2]);        // every input gets granted
    cover(out_valid && !out_ready_i);                                  // back-pressure
    cover(pv_out_valid && !pv_out_ready && out_hs);                    // stalled, then accepted (grant lock released)
    cover(&in_valid_i && out_hs && sel == 2'd2);                       // all three contend
    cover(pv_in_ready[2] && out_hs && sel == 2'd0);                    // pointer wraps 2 -> 0
    cover(pv_out_valid && !pv_out_ready && out_hs && (in_valid_i[0] && in_valid_i[1] && in_valid_i[2]));
`ifdef FV_FAIR
    cover(waitc[0] >= 5'd8);                                           // long waits are reachable
    cover(waitc[1] >= 5'd8);
    cover(waitc[2] >= 5'd8);
`endif
  end
endmodule
