#!/usr/bin/env python3
"""Generate the deliberately buggy RTL copies used for formal non-vacuity ("mutation") checks.

Every mutant is a copy of an rtl/ module with exactly ONE injected bug. The script refuses to
write a mutant unless the text to replace occurs exactly once, so a future RTL edit that moves the
code is detected instead of silently producing a different (or no-op) mutant.

    python3 gen_mutants.py            # (re)generate all mutants next to this script
    python3 gen_mutants.py --check    # fail if a generated file is out of date or a pattern no longer matches

rtl/ is only READ. Output goes to verification/formal/mutants/<name>.sv.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RTL = os.path.normpath(os.path.join(HERE, "..", "..", "..", "rtl"))

# name -> (rtl file, bug description, [(old, new), ...])      (exactly one injected bug per mutant)
MUTANTS = {
    # ---------------------------------------------------------------- sf_hbm_req_queue
    "rq_drop_hold": ("sf_hbm_req_queue.sv",
        "allocation ignores hold_i (a slot whose write data is still owed can be re-allocated)",
        [("if (!valid_q[i] && !hold_i[i]) begin any_free = 1'b1;", "if (!valid_q[i]) begin any_free = 1'b1;")]),
    "rq_overwrite": ("sf_hbm_req_queue.sv",
        "payload of a push is always stored in slot 0 (overwrites a valid entry)",
        [("txn_q[free_idx]   <= push_txn_i;", "txn_q[IW'(0)]     <= push_txn_i;")]),
    "rq_dep_stale": ("sf_hbm_req_queue.sv",
        "dependency column of a removed entry is not cleared (stale dep bit)",
        [("          dep_q[i][rem_idx_i]   <= 1'b0;\n", "")]),
    "rq_older_norem": ("sf_hbm_req_queue.sv",
        "new entry's age row does not mask the entry removed in the same cycle (older bit set for an invalid slot)",
        [("older_q[free_idx] <= valid_q & ~rem_oh;", "older_q[free_idx] <= valid_q;")]),
    "rq_dep_all": ("sf_hbm_req_queue.sv",
        "new entry depends on EVERY older entry instead of only on conflicting ones (over-blocking)",
        [("conflict_vec[j] = valid_q[j] && !rem_oh[j] && hbm_conflict(push_txn_i, txn_q[j]);",
          "conflict_vec[j] = valid_q[j] && !rem_oh[j];")]),
    "rq_full_nohold": ("sf_hbm_req_queue.sv",
        "full_o ignores hold_i (full != 'no allocatable slot')",
        [("assign full_o  = ~any_free;", "assign full_o  = &valid_q;")]),

    # ---------------------------------------------------------------- sf_hbm_bank_fsm
    "bf_rcd_ignored": ("sf_hbm_bank_fsm.sv",
        "RD legal immediately after ACT (tRCDRD not enforced)",
        [("assign can_rd_o   = row_open_q && (c_rcdrd == 16'd0);", "assign can_rd_o   = row_open_q;")]),
    "bf_ras_ignored": ("sf_hbm_bank_fsm.sv",
        "PRE legal before tRAS has elapsed",
        [("assign can_pre_o  = row_open_q && (c_ras == 16'd0) && (c_rtp == 16'd0) && (c_wr == 16'd0);",
          "assign can_pre_o  = row_open_q && (c_rtp == 16'd0) && (c_wr == 16'd0);")]),
    "bf_trp_ignored": ("sf_hbm_bank_fsm.sv",
        "bank reported idle (ACT legal) before tRP has elapsed",
        [("assign idle_o     = !row_open_q && (c_rp == 16'd0) && (c_rfc == 16'd0);",
          "assign idle_o     = !row_open_q && (c_rfc == 16'd0);")]),
    "bf_wr_short": ("sf_hbm_bank_fsm.sv",
        "WR->PRE recovery omits WL+burst (only tWR)",
        [("c_wr  <= hbm_max16(hbm_dec16(c_wr), hbm_ld(tp_i.wl + tp_i.burst + tp_i.twr));",
          "c_wr  <= hbm_max16(hbm_dec16(c_wr), hbm_ld(tp_i.twr));")]),
    "bf_row_lost": ("sf_hbm_bank_fsm.sv",
        "ACT does not latch the row address",
        [("        open_row_q <= cmd_row_i;\n        c_rcdrd    <= hbm_ld(tp_i.trcdrd);",
          "        c_rcdrd    <= hbm_ld(tp_i.trcdrd);")]),
    "bf_viol_blind": ("sf_hbm_bank_fsm.sv",
        "violation_o never reports an illegal ACT",
        [("    if (act_i && !can_act_o)                                   viol_c = 1'b1;\n", "")]),

    # ---------------------------------------------------------------- sf_hbm_rsp_arb
    "ra_reselect": ("sf_hbm_rsp_arb.sv",
        "no grant locking: the arbiter re-selects every cycle, even while the output is stalled",
        [("wire [IW-1:0] sel = lock_q ? lock_idx_q : rr_idx;", "wire [IW-1:0] sel = rr_idx;"),
         ("assign out_valid_o = lock_q ? in_valid_i[lock_idx_q] : rr_any;", "assign out_valid_o = rr_any;")]),
    "ra_fixed_prio": ("sf_hbm_rsp_arb.sv",
        "round-robin pointer always restarts at input 0 (fixed priority: starvation)",
        [("ptr_q  <= (int'(sel) == N-1) ? '0 : (sel + 1'b1);", "ptr_q  <= '0;")]),
    "ra_multi_grant": ("sf_hbm_rsp_arb.sv",
        "in_ready_o raised for every input on a handshake (not exclusive; duplicates responses)",
        [("if (out_valid_o && out_ready_i) in_ready_o[sel] = 1'b1;", "if (out_valid_o && out_ready_i) in_ready_o = '1;")]),
    "ra_lost": ("sf_hbm_rsp_arb.sv",
        "in_ready_o raised without out_ready_i (input consumed although the output was not accepted: lost response)",
        [("if (out_valid_o && out_ready_i) in_ready_o[sel] = 1'b1;", "if (out_valid_o) in_ready_o[sel] = 1'b1;")]),

    # ---------------------------------------------------------------- sf_hbm_read_return
    "rr_early_done": ("sf_hbm_read_return.sv",
        "a READ is marked done at allocation (completion released before the data/return event)",
        [("done_q[tail_q] <= (push_kind_i == 2'd2);", "done_q[tail_q] <= (push_kind_i != 2'd1);")]),
    "rr_pop_noready": ("sf_hbm_read_return.sv",
        "head is popped whenever it is done, even if the consumer is not ready (response lost under stall)",
        [("wire pop_fire = head_done && rsp_ready_i;", "wire pop_fire = head_done;")]),
    "rr_credit_early": ("sf_hbm_read_return.sv",
        "credit_o drops one entry early (credit low when not full)",
        [("assign credit_o   = (cnt_q != (IW+1)'(CPL_DEPTH));", "assign credit_o   = (cnt_q < (IW+1)'(CPL_DEPTH-1));")]),
    "rr_done_sticky": ("sf_hbm_read_return.sv",
        "done flag of a released entry is not cleared (stale completion: duplicate response)",
        [("        done_q[head_q] <= 1'b0;\n", "")]),
    "rr_orphan_nodrop": ("sf_hbm_read_return.sv",
        "v2: late data of a timed-out read is not dropped (it completes the NEXT read - the review finding)",
        [("wire        orph_drop = (orph_q != '0) && !rd_ontime;", "wire        orph_drop = 1'b0;")]),
    "rr_orphan_unpoisoned": ("sf_hbm_read_return.sv",
        "v2: an ambiguous (off-time / orphans pending) completion is delivered as good data",
        [("wire        rd_ambig  = !rd_ontime || (orph_q != '0);", "wire        rd_ambig  = 1'b0;")]),
    "rr_early_timeout": ("sf_hbm_read_return.sv",
        "read-return timeout fires one cycle after the due time instead of after RD_TIMEOUT",
        [("((cyc_i - head_due) >= hbm_cyc_t'(RD_TIMEOUT));", "((cyc_i - head_due) >= hbm_cyc_t'(1));")]),
    "rr_data_corrupt": ("sf_hbm_read_return.sv",
        "returned read data is stored inverted",
        [("data_q[rq_idx[rq_rp]] <= rd_data_i;", "data_q[rq_idx[rq_rp]] <= ~rd_data_i;")]),

    # ---------------------------------------------------------------- sf_hbm_refresh
    "rf_hold_early": ("sf_hbm_refresh.sv",
        "ACT hold is dropped while the REF command is still pending (state R_REF)",
        [("          hold_act_o = 1'b1;\n", "          hold_act_o = (st_q != R_REF);\n")]),
    "rf_ref_open": ("sf_hbm_refresh.sv",
        "sequencer skips the PREA when rows are open and goes straight to REF_AB",
        [("          else if (target_open)    st_q <= R_PREA;\n", "          else if (target_open)    st_q <= R_REF;\n")]),
    "rf_urgent_late": ("sf_hbm_refresh.sv",
        "urgent threshold off by one (debt > max_postpone instead of >=)",
        [("wire urgent   = !off_mode && (debt_ext >= mp);", "wire urgent   = !off_mode && (debt_ext > mp);")]),
    "rf_no_repay": ("sf_hbm_refresh.sv",
        "a granted REF does not repay the debt",
        [("if (st_q == R_REF && mnt_grant_i && !kind_q) nd_c = nd_c - 9'sd1;", "if (st_q == R_REF && mnt_grant_i) nd_c = nd_c - 9'sd0;")]),

    # ---------------------------------------------------------------- sf_hbm_cdc_fifo
    "cf_full_never": ("sf_hbm_cdc_fifo.sv",
        "full_o is never raised (overflow: unread data is overwritten)",
        [("(wgray_next == {~rgray_w2[AW:AW-1], rgray_w2[AW-2:0]});", "1'b0;")]),
    "cf_empty_never": ("sf_hbm_cdc_fifo.sv",
        "empty_o is never raised (underflow: unwritten data is read)",
        [("(rgray_next == wgray_r2);", "1'b0;")]),
    "cf_mem_addr": ("sf_hbm_cdc_fifo.sv",
        "write address is off by one (data lands in the wrong slot)",
        [("mem[wbin_q[AW-1:0]] <= wdata_i;", "mem[wbin_q[AW-1:0] + 1'b1] <= wdata_i;")]),
    "cf_bin_ptr": ("sf_hbm_cdc_fifo.sv",
        "pointers cross the domains in BINARY instead of Gray code (multi-bit change per step)",
        [("return b ^ (b >> 1);", "return b;")]),

    # ---------------------------------------------------------------- sf_hbm_timing
    "tm_ccd_l": ("sf_hbm_timing.sv",
        "same-bank-group column-to-column spacing uses tCCD_S instead of tCCD_L",
        [("hbm_ld((g == int'(bg_i)) ? tp_i.tccd_l : tp_i.tccd_s));", "hbm_ld(tp_i.tccd_s));")]),
    "tm_faw_off": ("sf_hbm_timing.sv",
        "tFAW window is never enforced",
        [("faw_ok     = (c_faw[0] == 16'd0) || (c_faw[1] == 16'd0) || (c_faw[2] == 16'd0) || (c_faw[3] == 16'd0);", "faw_ok     = 1'b1;")]),
    "tm_wtr_l_short": ("sf_hbm_timing.sv",
        "WR->RD same-bank-group turnaround uses tWTR_S",
        [("k_wtr_l = tp_i.wl + tp_i.burst + tp_i.twtr_l;", "k_wtr_l = tp_i.wl + tp_i.burst + tp_i.twtr_s;")]),
}


def build(name):
    src, desc, edits = MUTANTS[name]
    path = os.path.join(RTL, src)
    with open(path) as f:
        text = f.read()
    for old, new in edits:
        n = text.count(old)
        if n != 1:
            raise SystemExit("mutant %s: pattern occurs %d times in %s (need exactly 1):\n%s" % (name, n, src, old))
        text = text.replace(old, new, 1)
    hdr = ("// =============================================================================\n"
           "//  FORMAL MUTANT %s   (generated by gen_mutants.py from rtl/%s -- do not edit)\n"
           "//  Injected bug: %s\n"
           "//  Purpose: proof that the formal harness is not vacuous (this copy MUST make a property fail).\n"
           "// =============================================================================\n") % (name, src, desc)
    return hdr + text


def main():
    check = "--check" in sys.argv
    bad = 0
    for name in sorted(MUTANTS):
        out = os.path.join(HERE, name + ".sv")
        text = build(name)
        if check:
            cur = open(out).read() if os.path.exists(out) else None
            if cur != text:
                print("OUT OF DATE:", out)
                bad += 1
        else:
            with open(out, "w") as f:
                f.write(text)
            print("wrote", out)
    if check:
        print("mutants up to date" if not bad else "%d mutant(s) out of date" % bad)
        sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
