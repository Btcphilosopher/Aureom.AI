// =============================================================================
//  secded_v1_reference.svh  --  GOLDEN reference for verification/formal/eq_secded.py
//  The SECDED encode / decode functions exactly as shipped in HBMCore v1 (rtl/sf_hbm_ecc_ras.sv), kept verbatim so
//  that any later restructuring of the RTL code (v2: constant tables + reduction trees for timing) can be PROVEN
//  functionally identical for all 2^266 inputs. Do not edit.
// =============================================================================
  // -------- code construction --------------------------------------------------
  function automatic hbm_ecc_t enc(input hbm_data_t d);
    hbm_ecc_t c;
    int unsigned pos;
    logic p;
    c = '0;  pos = 0;
    for (int k = 0; k < HBM_GRAN_BITS; k++) begin
      pos = pos + 1;
      while ((pos & (pos - 1)) == 0) pos = pos + 1;     // skip powers of two (check-bit positions)
      for (int i = 0; i < 9; i++)
        if (((pos >> i) & 1) != 0) c[i] = c[i] ^ d[k];
    end
    p = ^d;
    for (int i = 0; i < 9; i++) p = p ^ c[i];
    c[9] = p;
    return c;
  endfunction

  // returns {uncorrectable, corrected, syndrome[8:0], corrected_data}
  typedef struct packed {
    logic      ue;
    logic      ce;
    logic [8:0] syn;
    hbm_data_t data;
  } dec_t;

  function automatic dec_t dec(input hbm_data_t d, input hbm_ecc_t c);
    dec_t r;
    hbm_ecc_t cc;
    logic [8:0] syn;
    logic op;
    int unsigned pos;
    logic is_pow2;
    cc = enc(d);
    syn = cc[8:0] ^ c[8:0];
    op  = (^d) ^ (^c);                  // overall parity over data + all 10 stored check bits
    r.data = d; r.ue = 1'b0; r.ce = 1'b0; r.syn = syn;
    if (syn == 9'd0 && !op) begin
      // clean
    end else if (op) begin
      // odd number of flips: treat as single
      r.ce = 1'b1;
      if (syn != 9'd0) begin
        is_pow2 = ((syn & (syn - 9'd1)) == 9'd0);
        if (!is_pow2) begin
          pos = 0;
          r.ue = 1'b1;                    // until proven to point at a real data bit
          for (int k = 0; k < HBM_GRAN_BITS; k++) begin
            pos = pos + 1;
            while ((pos & (pos - 1)) == 0) pos = pos + 1;
            if (pos == 32'(syn)) begin
              r.data[k] = ~d[k];
              r.ue = 1'b0;
            end
          end
          if (r.ue) r.ce = 1'b0;
        end
      end
    end else begin
      r.ue = 1'b1;                        // syndrome != 0, parity ok: double error
    end
    return r;
  endfunction

