// =============================================================================
//  fv_req_queue.sv  --  formal harness for sf_hbm_req_queue (DEPTH = 4)
//  See docs/FORMAL.md ("sf_hbm_req_queue") for the assumption table and results.
//
//  Structure
//    * the DUT is instantiated with DEPTH=4 / AGE_W=4 (small, see the -D geometry in the .sby);
//    * all DUT inputs are free (anyseq) top-level inputs, constrained ONLY by the `assume`s in the
//      "environment" block;
//    * an independent SHADOW MODEL (sv/stxn/sold/sage) re-derives the allocation, payload, age
//      order and age from the interface alone; the DUT is compared against it;
//    * a few checks read DUT internals by hierarchical name (dut.valid_q / dep_q / older_q): the
//      dependency matrix is not a port.
//  Reset: the DUT is held in reset in cycle 0 only (init); every property is guarded by !init.
// =============================================================================
module fv_req_queue
  import sf_hbm_pkg::*;
(
  input  logic        clk,
  input  logic        push_valid_i,
  input  hbm_txn_t    push_txn_i,
  input  logic        rem_valid_i,
  input  logic [1:0]  rem_idx_i,
  input  logic [3:0]  hold_i
);
  localparam int unsigned DEPTH = 4;
  localparam int unsigned AGE_W = 4;
  localparam int unsigned IW    = 2;

  // ---- reset: asserted in cycle 0 only ---------------------------------------
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  // ---- DUT -------------------------------------------------------------------
  logic                    push_ready;
  logic [IW-1:0]           push_idx;
  logic [DEPTH-1:0]        ent_valid;
  hbm_txn_t [DEPTH-1:0]    ent_txn;
  logic [DEPTH-1:0]        ent_blocked;
  logic [DEPTH-1:0][DEPTH-1:0] ent_older;
  logic [DEPTH-1:0][AGE_W-1:0] ent_age;
  logic [IW:0]             occ, occ_rd, occ_wr;
  logic                    full, empty;

  sf_hbm_req_queue #(.DEPTH(DEPTH), .AGE_W(AGE_W)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .push_valid_i(push_valid_i), .push_ready_o(push_ready), .push_txn_i(push_txn_i), .push_idx_o(push_idx),
    .rem_valid_i(rem_valid_i), .rem_idx_i(rem_idx_i), .hold_i(hold_i),
    .ent_valid_o(ent_valid), .ent_txn_o(ent_txn), .ent_blocked_o(ent_blocked),
    .ent_older_o(ent_older), .ent_age_o(ent_age),
    .occ_o(occ), .occ_rd_o(occ_rd), .occ_wr_o(occ_wr), .full_o(full), .empty_o(empty)
  );

  // ---- independent shadow model ---------------------------------------------
  logic [DEPTH-1:0]            sv    = '0;      // allocated slots (shadow of valid)
  hbm_txn_t [DEPTH-1:0]        stxn  = '0;      // payload recorded at push
  logic [DEPTH-1:0][DEPTH-1:0] sold  = '0;      // sold[i][j]: j was pushed before i and is still allocated
  logic [DEPTH-1:0][AGE_W-1:0] sage  = '0;

  // expected allocation: lowest slot that is neither allocated nor held
  logic [DEPTH-1:0] cand;
  logic             exp_ready;
  logic [IW-1:0]    exp_idx;
  always_comb begin
    cand      = ~sv & ~hold_i;
    exp_ready = |cand;
    exp_idx   = '0;
    for (int i = DEPTH-1; i >= 0; i--) if (cand[i]) exp_idx = IW'(i);
  end
  wire push_fire = push_valid_i && exp_ready;

  logic [DEPTH-1:0] rem_oh;
  always_comb begin
    rem_oh = '0;
    if (rem_valid_i) rem_oh[rem_idx_i] = 1'b1;
  end

  always @(posedge clk) if (!init) begin       // the DUT ignores everything in its reset cycle
    for (int i = 0; i < DEPTH; i++)
      if (sv[i] && (sage[i] != {AGE_W{1'b1}})) sage[i] <= sage[i] + AGE_W'(1);
    if (rem_valid_i) begin
      sv[rem_idx_i] <= 1'b0;
      for (int i = 0; i < DEPTH; i++) sold[i][rem_idx_i] <= 1'b0;
    end
    if (push_fire) begin
      sv[exp_idx]   <= 1'b1;
      stxn[exp_idx] <= push_txn_i;
      sage[exp_idx] <= '0;
      sold[exp_idx] <= sv & ~rem_oh;
    end
  end

  // ---- ENVIRONMENT ASSUMPTIONS (documented in docs/FORMAL.md) -----------------
  // E1: the environment (scheduler) removes only slots that its own bookkeeping says are allocated.
  always @(posedge clk) if (!init) assume(!rem_valid_i || sv[rem_idx_i]);
  // (hold_i, push_valid_i, push_txn_i are completely free: no assumption.)

  // ---- helper: oldest entry ----------------------------------------------------
  logic [DEPTH-1:0] oldest;
  always_comb begin
    for (int i = 0; i < DEPTH; i++) begin
      oldest[i] = ent_valid[i];
      for (int j = 0; j < DEPTH; j++)
        if (ent_valid[j] && ent_older[i][j]) oldest[i] = 1'b0;
    end
  end

  function automatic int unsigned popcnt(input logic [DEPTH-1:0] v);
    popcnt = 0;
    for (int i = 0; i < DEPTH; i++) popcnt += int'(v[i]);
  endfunction

  // ---- PROPERTIES -------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    // (a) a push is accepted only into a slot that is neither valid nor held ... and the
    //     DUT agrees with the independent allocator on readiness and slot choice.
    assert(push_ready == exp_ready);
    if (push_ready) assert(push_idx == exp_idx);
    if (push_valid_i && push_ready) begin
      assert(!ent_valid[push_idx]);
      assert(!hold_i[push_idx]);
    end
    // (c) removal of an invalid slot never happens (E1 makes the *environment* respect this; the
    //     assertion checks the DUT's valid vector agrees with the environment's bookkeeping)
    if (rem_valid_i) assert(ent_valid[rem_idx_i]);
    // (b) valid vector == shadow; payload of every valid entry == the payload pushed (=> never
    //     overwritten while valid, stable until removal)
    assert(ent_valid == sv);
    for (int i = 0; i < DEPTH; i++) if (ent_valid[i]) assert(ent_txn[i] == stxn[i]);
    // (d) occupancy / full / empty
    assert(int'(occ) == popcnt(ent_valid));
    assert(occ <= (IW+1)'(DEPTH));                          // no overflow of the occupancy counter
    assert(empty == (ent_valid == '0));
    assert(full == !(|(~ent_valid & ~hold_i)));             // full <=> no allocatable slot
    if (&ent_valid) assert(full);
    begin
      logic [DEPTH-1:0] wmask;
      for (int i = 0; i < DEPTH; i++) wmask[i] = ent_valid[i] && ent_txn[i].write;
      assert(int'(occ_wr) == popcnt(wmask));
      assert(int'(occ_rd) + int'(occ_wr) == int'(occ));
    end
    // (e) age / dependency matrices
    for (int i = 0; i < DEPTH; i++) begin
      if (ent_valid[i]) begin
        assert(ent_age[i] == sage[i]);                      // age counts cycles since push (saturating)
        assert(!ent_older[i][i]);                           // irreflexive
        for (int j = 0; j < DEPTH; j++) begin
          assert(ent_older[i][j] == sold[i][j]);            // age order == arrival order
          if (ent_older[i][j]) assert(ent_valid[j]);        // only valid entries are older
          if (i != j && ent_valid[j]) begin
            assert(!(ent_older[i][j] && ent_older[j][i]));  // antisymmetric
            assert(ent_older[i][j] || ent_older[j][i]);     // total
            if (ent_older[i][j]) assert(ent_age[j] >= ent_age[i]);
            for (int k = 0; k < DEPTH; k++)
              if (ent_valid[k] && ent_older[i][j] && ent_older[j][k]) assert(ent_older[i][k]); // transitive
          end
        end
      end
    end
    if (|ent_valid) assert($onehot(oldest));                // exactly one oldest entry
    else            assert(oldest == '0);
    // dependency matrix (DUT internals): dep[i][j] => valid[j] && older[i][j]   (all i, j)
    for (int i = 0; i < DEPTH; i++)
      for (int j = 0; j < DEPTH; j++) begin
        if (dut.dep_q[i][j]) begin
          assert(dut.valid_q[j]);
          assert(dut.older_q[i][j]);
        end
        // (f) never blocked by a younger entry: if j is younger than i (valid i, valid j) dep[i][j]==0
        if (ent_valid[i] && ent_valid[j] && ent_older[j][i]) assert(!dut.dep_q[i][j]);
        // exact semantics (valid i): dep[i][j] <=> valid[j] && older[i][j] && conflict(i, j)
        if (ent_valid[i] && i != j)
          assert(dut.dep_q[i][j] == (ent_valid[j] && ent_older[i][j] && hbm_conflict(ent_txn[i], ent_txn[j])));
      end
    for (int i = 0; i < DEPTH; i++) begin
      if (ent_valid[i]) begin
        logic exp_blk;
        exp_blk = 1'b0;
        for (int j = 0; j < DEPTH; j++)
          if (ent_valid[j] && ent_older[i][j] && hbm_conflict(ent_txn[i], ent_txn[j])) exp_blk = 1'b1;
        assert(ent_blocked[i] == exp_blk);
        if (oldest[i]) assert(!ent_blocked[i]);             // the oldest entry is never blocked (no deadlock)
      end
    end
  end

  // ---- COVER (non-vacuity) ----------------------------------------------------
  logic pv_rem_valid = 1'b0;
  logic pv_push_fire = 1'b0;
  always @(posedge clk) begin pv_rem_valid <= rem_valid_i; pv_push_fire <= push_fire; end
  always @(posedge clk) if (!init) begin
    cover(&ent_valid);                                      // queue completely full
    cover(full && !(&ent_valid));                           // full because of hold_i, not occupancy
    cover(push_fire && (occ == 3'd2));
    cover(rem_valid_i && (occ == 3'd3));
    cover(|ent_blocked);                                    // a dependency-blocked entry exists
    cover(&ent_valid && (ent_blocked == 4'b1110));          // a chain of blocked entries behind slot 0 ...
    cover(push_fire && rem_valid_i);                        // simultaneous push + removal
    cover(pv_rem_valid && push_fire && (push_idx == rem_idx_i)); // slot reuse right after free
    cover(oldest[3]);                                       // oldest entry is not slot 0 (age order != index order)
    cover(ent_valid == 4'b1111 && ent_age[0] == 4'd15);     // age saturation reachable
  end
endmodule
