#!/usr/bin/env bash
# Run all formal tasks (SymbiYosys) and write reports/formal.json.
#   verification/formal/run_formal.sh [-m <module-substring>] [-t <task-regex>] [--no-mutants] [--mutants-only]
# Environment:
#   YOWASP_BIN    directory with yowasp-sby / yowasp-yosys / yowasp-yosys-smtbmc   (default /tmp/venv_yw/bin)
#   ABC_BIN       yosys-abc used by the `abc bmc3` engine                         (default /usr/bin/yosys-abc)
#   JOBS          solver processes in parallel                                    (default 2; the machine is shared)
#   TASK_TIMEOUT  seconds per task                                                (default 420)
#   FORMAL_WORK   scratch directory for sby work dirs                             (default $TMPDIR/sf_formal_work)
# z3 is run through `smtbmc --unroll z3` (without --unroll z3 does not terminate on these models).
# Exit status 0 = every property passed / every cover reached / every mutant killed (documented Findings excepted).
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
command -v python3 >/dev/null || { echo "python3 required" >&2; exit 2; }
python3 "$here/mutants/gen_mutants.py" --check >/dev/null || { echo "mutants out of date: run mutants/gen_mutants.py" >&2; exit 2; }
exec python3 "$here/run_formal.py" "$@"
