// =============================================================================
//  fv_bank_fsm.sv  --  formal harness for sf_hbm_bank_fsm
//  See docs/FORMAL.md ("sf_hbm_bank_fsm").
//
//  Two environments, selected by the macro FV_ILLEGAL (set in the .sby):
//    (default)   LEGAL environment : the scheduler only issues a strobe when the matching can_* is high,
//                RD/WR address the open row, REF only on an idle bank, one command per cycle.
//                Properties: state encoding, can_* implications, transitions, tRCD/tRAS/tRTP/tWR/tRC/
//                tRP/tRFC timing (against ghost "cycles since" counters), violation_o == 0.
//    FV_ILLEGAL  free environment (only "one command per cycle"): violation_o must be asserted EXACTLY
//                one cycle after an illegal strobe (and the structural properties still hold).
//
//  The timing profile is SYMBOLIC: a free input, assumed constant, whose used fields are assumed <= 4
//  (resp. wl+burst+twr <= 8). 0 is allowed (the RTL treats a rule of 0 or 1 as "next cycle").
//  Timing proof method: ghost counters age_* (cycles since the last event, saturating at 15) are tied
//  to the DUT's internal down-counters by exact INDUCTIVE INVARIANTS (T1). The user-visible timing
//  properties (T2) then follow, which is what lets `prove` (k-induction) give an UNBOUNDED result.
// =============================================================================
module fv_bank_fsm
  import sf_hbm_pkg::*;
(
  input  logic     clk,
  input  logic     act_i, rd_i, wr_i, pre_i, refab_i, refpb_i, rfm_i,   // rfm_i: v2 refresh management (per bank, busy tRFM)
  input  hbm_row_t cmd_row_i,
  input  hbm_timing_t tp                                  // symbolic profile: free input, assumed constant (E0)
);
  // ---- reset in cycle 0 only ---------------------------------------------------
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  // ---- symbolic timing profile -------------------------------------------------
  // E0: the profile is a free input that never changes after reset (emulates an anyconst: the
  //     slang front-end does not turn the anyconst attribute into a $anyconst cell).
  hbm_timing_t tp_prev = '0;
  always @(posedge clk) tp_prev <= tp;
  always @(posedge clk) begin
    assume(init || tp == tp_prev);
    assume(tp.trcdrd <= 16'd4); assume(tp.trcdwr <= 16'd4); assume(tp.tras <= 16'd4);
    assume(tp.trc    <= 16'd4); assume(tp.trp    <= 16'd4); assume(tp.trtp <= 16'd4);
    assume(tp.trfc   <= 16'd4); assume(tp.trfcpb <= 16'd4); assume(tp.trfm <= 16'd4);
    assume(tp.wl <= 16'd3);     assume(tp.burst <= 16'd2);    assume(tp.twr <= 16'd3);
  end

  // ---- DUT ---------------------------------------------------------------------
  logic     row_open, can_act, can_rd, can_wr, can_pre, idle, violation;
  hbm_row_t open_row;
  logic [1:0] state;
  sf_hbm_bank_fsm dut (
    .clk_i(clk), .rst_ni(rst_n), .tp_i(tp),
    .act_i(act_i), .rd_i(rd_i), .wr_i(wr_i), .cmd_row_i(cmd_row_i), .pre_i(pre_i),
    .refab_i(refab_i), .refpb_i(refpb_i), .rfm_i(rfm_i),
    .row_open_o(row_open), .open_row_o(open_row),
    .can_act_o(can_act), .can_rd_o(can_rd), .can_wr_o(can_wr), .can_pre_o(can_pre),
    .idle_o(idle), .state_o(state), .violation_o(violation)
  );

  // ---- ENVIRONMENT ASSUMPTIONS ---------------------------------------------------
  wire [6:0] strobes = {act_i, rd_i, wr_i, pre_i, refab_i, refpb_i, rfm_i};
  always @(posedge clk) if (!init) begin
    assume($onehot0(strobes));                              // E1: one command per cycle (so never ACT+PRE)
`ifndef FV_ILLEGAL
    assume(!act_i || can_act);                              // E2: strobes only when the matching can_* is high
    assume(!rd_i  || (can_rd && cmd_row_i == open_row));    // E3: RD/WR address the open row
    assume(!wr_i  || (can_wr && cmd_row_i == open_row));
    assume(!pre_i || !row_open || can_pre);                 // E4: PRE of an open bank obeys tRAS/tRTP/tWR (closed: no-op)
    assume(!(refab_i || refpb_i || rfm_i) || can_act);      // E5: REF / RFM only on an idle, tRC-clean bank
`endif
  end

  // ---- ghost event history -------------------------------------------------------
  function automatic logic [3:0] sat_inc(input logic [3:0] a);
    sat_inc = (a == 4'd15) ? a : a + 4'd1;
  endfunction
  // remaining down-count `age` cycles after an event that loaded hbm_ld(n)  (age >= 1)
  function automatic logic [15:0] remcnt(input logic [15:0] n, input logic [3:0] age);
    logic [15:0] l, a;
    l = hbm_ld(n);
    a = 16'(age) - 16'd1;
    remcnt = (l > a) ? (l - a) : 16'd0;
  endfunction
  function automatic logic [15:0] max1(input logic [15:0] n);
    max1 = (n == 16'd0) ? 16'd1 : n;
  endfunction

  logic [3:0] age_act = 4'd15, age_rd = 4'd15, age_wr = 4'd15, age_pre = 4'd15, age_ref = 4'd15;
  logic act_seen = 1'b0, rd_seen = 1'b0, wr_seen = 1'b0, pre_seen = 1'b0, ref_seen = 1'b0;  // rd/wr: since last ACT
  logic [15:0] ref_len = '0;
  wire  pre_eff = pre_i && row_open;

  always @(posedge clk) if (!init) begin
    age_act <= sat_inc(age_act); age_rd <= sat_inc(age_rd); age_wr <= sat_inc(age_wr);
    age_pre <= sat_inc(age_pre); age_ref <= sat_inc(age_ref);
    if (act_i)   begin age_act <= 4'd1; act_seen <= 1'b1; rd_seen <= 1'b0; wr_seen <= 1'b0; end
    if (rd_i)    begin age_rd  <= 4'd1; rd_seen  <= 1'b1; end
    if (wr_i)    begin age_wr  <= 4'd1; wr_seen  <= 1'b1; end
    if (pre_eff) begin age_pre <= 4'd1; pre_seen <= 1'b1; end
    if (refab_i) begin age_ref <= 4'd1; ref_seen <= 1'b1; ref_len <= tp.trfc;   end
    if (refpb_i) begin age_ref <= 4'd1; ref_seen <= 1'b1; ref_len <= tp.trfcpb; end
    if (rfm_i)   begin age_ref <= 4'd1; ref_seen <= 1'b1; ref_len <= tp.trfm;   end
  end

  // previous-cycle snapshot (events of the reset cycle are ignored by the DUT, so are not recorded)
  logic pv_act = 1'b0, pv_pre_eff = 1'b0, pv_row_open = 1'b0, pv_illegal = 1'b0;
  hbm_row_t pv_row = '0, pv_open_row = '0;
  logic illegal_now;
  always_comb begin
    illegal_now = 1'b0;
    if (act_i && !can_act)                                illegal_now = 1'b1;
    if (rd_i  && !(can_rd && cmd_row_i == open_row))      illegal_now = 1'b1;
    if (wr_i  && !(can_wr && cmd_row_i == open_row))      illegal_now = 1'b1;
    if (pre_i && row_open && !can_pre)                    illegal_now = 1'b1;
    if ((refab_i || refpb_i || rfm_i) && !can_act)        illegal_now = 1'b1;
  end
  always @(posedge clk) begin
    pv_act      <= act_i && !init;
    pv_pre_eff  <= pre_eff && !init;
    pv_row_open <= row_open;
    pv_illegal  <= illegal_now && !init;
    pv_row      <= cmd_row_i;
    pv_open_row <= open_row;
  end

  // ---- STRUCTURAL PROPERTIES (both environments) ---------------------------------
  always @(posedge clk) if (!init) begin
    // state encoding
    assert(row_open == (state == 2'd1));
    assert(idle     == (state == 2'd0));
    if (state == 2'd2 || state == 2'd3) begin assert(!row_open); assert(!idle); end
    assert(!(idle && row_open));
    // legality outputs
    if (can_act) begin assert(!row_open); assert(idle); end
    if (can_rd || can_wr || can_pre) assert(row_open);
    assert(!(can_act && (can_rd || can_wr || can_pre)));
    // transitions (previous cycle -> now); the reset cycle is excluded by pv_* being cleared
    if (pv_act) begin assert(row_open); assert(open_row == pv_row); end   // after ACT: open, with the ACT row
    if (!pv_act) assert(open_row == pv_open_row);                          // only ACT changes the row
    if (pv_pre_eff) assert(!row_open);
    if (pv_row_open && !pv_pre_eff) assert(row_open);                      // stays open until PRE
    if (!pv_row_open && !pv_act)    assert(!row_open);                     // opens only through ACT
`ifdef FV_ILLEGAL
    assert(violation == pv_illegal);                                       // violation_o == "an illegal strobe last cycle"
`else
    assert(!violation);                                                    // never fires under the legal environment
`endif
  end

`ifndef FV_ILLEGAL
  // ---- TIMING PROPERTIES (legal environment) ---------------------------------------
  always @(posedge clk) if (!init) begin
    // T1: inductive invariants tying the DUT counters to the ghost event ages
    if (row_open) assert(act_seen);
    assert(ref_len <= 16'd4);                                // ghost register stays inside the assumed profile range
    assert(dut.c_rcdrd == (act_seen ? remcnt(tp.trcdrd, age_act) : 16'd0));
    assert(dut.c_rcdwr == (act_seen ? remcnt(tp.trcdwr, age_act) : 16'd0));
    assert(dut.c_ras   == (act_seen ? remcnt(tp.tras,   age_act) : 16'd0));
    assert(dut.c_rc    == (act_seen ? remcnt(tp.trc,    age_act) : 16'd0));
    assert(dut.c_rtp   == (rd_seen  ? remcnt(tp.trtp,   age_rd)  : 16'd0));
    assert(dut.c_wr    == (wr_seen  ? remcnt(tp.wl + tp.burst + tp.twr, age_wr) : 16'd0));
    assert(dut.c_rp    == (pre_seen ? remcnt(tp.trp,    age_pre) : 16'd0));
    assert(dut.c_rfc   == (ref_seen ? remcnt(ref_len,   age_ref) : 16'd0));
    // T2: user-visible timing rules
    if (can_rd)  assert(act_seen && 16'(age_act) >= max1(tp.trcdrd));                       // ACT -> RD  >= tRCDRD
    if (can_wr)  assert(act_seen && 16'(age_act) >= max1(tp.trcdwr));                       // ACT -> WR  >= tRCDWR
    if (can_pre) begin
      assert(act_seen && 16'(age_act) >= max1(tp.tras));                                    // ACT -> PRE >= tRAS
      if (rd_seen) assert(16'(age_rd) >= max1(tp.trtp));                                    // RD  -> PRE >= tRTP
      if (wr_seen) assert(16'(age_wr) >= max1(tp.wl + tp.burst + tp.twr));                  // WR  -> PRE >= WL+BL+tWR
    end
    if (can_act) begin
      if (act_seen) assert(16'(age_act) >= max1(tp.trc));                                   // ACT -> ACT >= tRC
      if (pre_seen) assert(16'(age_pre) >= max1(tp.trp));                                   // PRE -> ACT >= tRP
      if (ref_seen) assert(16'(age_ref) >= max1(ref_len));                                  // REF -> ACT >= tRFC
    end
    if (idle) begin
      if (pre_seen) assert(16'(age_pre) >= max1(tp.trp));
      if (ref_seen) assert(16'(age_ref) >= max1(ref_len));
    end
  end
`endif

  // ---- COVER (non-vacuity) -----------------------------------------------------------
  always @(posedge clk) if (!init) begin
`ifdef FV_ILLEGAL
    cover(violation);                                                       // an illegal strobe is flagged
    cover(pv_illegal && pv_act);                                            // ... an illegal ACT (bank already open)
    cover(violation && state == 2'd1);
    cover(violation && state == 2'd3);                                      // ... in/after refresh
`else
    cover(act_i);
    cover(row_open && age_act == 4'd3);
    cover(can_rd && rd_i);
    cover(can_wr && wr_i);
    cover(can_pre && pre_i);
    cover(pre_i && !row_open);                                              // PRE to a closed bank (no-op)
    cover(state == 2'd2);                                                   // PRECHARGING
    cover(state == 2'd3);                                                   // REFRESHING
    cover(can_act && pre_seen && act_seen);                                 // full ACT -> ... -> PRE -> ACT loop
    cover(row_open && dut.c_ras == 16'd0 && dut.c_wr == 16'd0 && dut.c_rtp != 16'd0 && !can_pre); // PRE blocked ONLY by tRTP
    cover(row_open && dut.c_ras == 16'd0 && dut.c_rtp == 16'd0 && dut.c_wr != 16'd0 && !can_pre); // PRE blocked ONLY by WL+BL+tWR
    cover(can_pre && wr_seen && age_wr >= 4'd3);
    cover(can_act && ref_seen && tp.trfc >= 16'd2 && age_ref >= 4'd2);
    cover(act_seen && !can_rd && row_open && tp.trcdrd >= 16'd3);           // RD blocked by tRCDRD
    cover(act_seen && row_open && can_rd && !can_pre && tp.tras >= 16'd3);  // tRAS longer than tRCD
`endif
  end
endmodule
