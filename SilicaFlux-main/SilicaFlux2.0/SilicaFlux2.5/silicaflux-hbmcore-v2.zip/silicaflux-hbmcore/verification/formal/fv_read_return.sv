// =============================================================================
//  fv_read_return.sv  --  formal harness for sf_hbm_read_return (CPL_DEPTH = 4, RD_TIMEOUT = 3)
//  See docs/FORMAL.md ("sf_hbm_read_return").
//
//  An independent GHOST MODEL of the completion sequencer is built from the interface only:
//    g_alloc/g_pop   allocation / release sequence numbers (the environment labels every pushed
//                    entry with its sequence number in ctx.id, so the DUT output can be checked)
//    g_cnt, g_tail, g_head       occupancy and slot pointers
//    ev_done[slot]   "a completion EVENT happened for this entry": error entry -> at allocation;
//                    write -> wr_done pulse; read -> rd_valid_i (matched to the OLDEST outstanding
//                    read, in order) or the timeout path (rd_timeout_o pulse, one cycle after the
//                    decision, handled combinationally in eff_done)
//    g_due[slot]     independent due time of a read (push cycle + 1 + RL)
//  The DUT's rsp_valid_o must equal "head entry has had its completion event" EXACTLY.
//
//  Environment assumptions (docs/FORMAL.md):
//    E1 kind != 3; ctx.write == (kind==1); ctx.id == allocation sequence number (a label, never decoded)
//    E2 RL <= 2 and constant;  cyc_i is a free-running counter starting at 0
//    E3 rd_valid_i only while the environment model says a read is outstanding
//       (reads allocated - returns - timeouts already reported by rd_timeout_o)
//    E4 wr_done only for an entry that is an allocated, not yet completed WRITE (allocated in an earlier cycle)
//  v2 contract (independent-review fix, docs/REVIEW_V2.md): the ghost also counts ORPHANS (timed-out reads whose data may
//  still arrive): an off-time return while orphans exist is DROPPED (no completion); a completion that is off-time or
//  happens while orphans exist is POISONED (HERR_FLUSHED, corrected = 0); orphans clear after RD_TIMEOUT quiet cycles.
//  Macro FV_DATA adds a 256-bit tracked-word data-integrity check (a separate, heavier task).
// =============================================================================
module fv_read_return
  import sf_hbm_pkg::*;
(
  input  logic        clk,
  input  hbm_timing_t tp,                    // only tp.rl is used (E2)
  input  logic        push_valid_i,
  input  hbm_ctx_t    push_ctx_i,
  input  logic [1:0]  push_kind_i,
  input  logic        wr_done_valid_i,
  input  logic [1:0]  wr_done_idx_i,
  input  logic        rd_valid_i,
  input  hbm_data_t   rd_data_i,
  input  hbm_err_e    rd_err_i,
  input  logic        rd_corr_i,
  input  logic        rsp_ready_i,
  input  logic [3:0]  trk                    // tracked sequence number (stable symbolic, E0)
);
  localparam int unsigned CPL = 4;
  localparam int unsigned RDT = 3;

  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  wire rst_n = !init;

  // ---- constants that are free inputs held stable (E0) -------------------------------
  hbm_timing_t tp_prev = '0;
  logic [3:0]  trk_prev = '0;
  always @(posedge clk) begin tp_prev <= tp; trk_prev <= trk; end
  always @(posedge clk) begin
    assume(init || tp == tp_prev);
    assume(init || trk == trk_prev);
    assume(tp.rl <= 16'd2);                                      // E2
  end

  // free-running cycle counter (E2)
  hbm_cyc_t cyc = '0;
  always @(posedge clk) cyc <= cyc + hbm_cyc_t'(1);

  // ---- DUT ---------------------------------------------------------------------------
  logic [1:0]  push_idx;
  logic        credit, rsp_valid;
  hbm_rsp_t    rsp;
  logic [5:0]  rsp_bytes;
  logic [15:0] rsp_lat;
  logic [2:0]  occ;
  logic        rd_timing_err, rd_timeout, rd_unexpected;

  logic rd_orphan_drop;
  sf_hbm_read_return #(.CPL_DEPTH(CPL), .RD_EXTRA_LAT(0), .RD_TIMEOUT(RDT)) dut (
    .clk_i(clk), .rst_ni(rst_n), .tp_i(tp), .cyc_i(cyc),
    .push_valid_i(push_valid_i), .push_ctx_i(push_ctx_i), .push_kind_i(push_kind_i),
    .push_idx_o(push_idx), .credit_o(credit),
    .wr_done_valid_i(wr_done_valid_i), .wr_done_idx_i(wr_done_idx_i),
    .rd_valid_i(rd_valid_i), .rd_data_i(rd_data_i), .rd_err_i(rd_err_i), .rd_corr_i(rd_corr_i),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready_i), .rsp_o(rsp),
    .rsp_bytes_o(rsp_bytes), .rsp_lat_o(rsp_lat), .occ_o(occ),
    .rd_timing_err_o(rd_timing_err), .rd_timeout_o(rd_timeout), .rd_unexpected_o(rd_unexpected), .rd_orphan_drop_o(rd_orphan_drop)
  );

  // ---- GHOST MODEL ----------------------------------------------------------------------
  logic [3:0]  g_alloc = '0, g_pop = '0;
  logic [1:0]  g_tail = '0, g_head = '0;
  logic [2:0]  g_cnt = '0;
  logic [3:0]  ev_done = '0, g_wr_pend = '0;
  logic [1:0]  g_kind [CPL];
  logic [3:0]  g_seq  [CPL];
  logic [15:0] g_due  [CPL];
  logic [1:0]  g_rd_q [CPL];
  logic [1:0]  g_rd_wp = '0, g_rd_rp = '0;
  logic [2:0]  g_rd_cnt = '0;
  initial for (int i = 0; i < CPL; i++) begin g_kind[i] = '0; g_seq[i] = '0; g_due[i] = '0; g_rd_q[i] = '0; end

  wire g_credit = (g_cnt != 3'(CPL));
  wire g_push   = push_valid_i && g_credit;
  wire tmo      = rd_timeout;                                    // decision of the previous cycle
  wire [1:0] g_rd_head_to  = g_rd_rp;                            // entry the timeout pulse refers to
  wire [1:0] g_rd_head_eff = tmo ? g_rd_rp + 2'd1 : g_rd_rp;      // entry a rd_valid_i in this cycle refers to
  wire [2:0] g_rd_cnt_eff  = tmo ? g_rd_cnt - 3'd1 : g_rd_cnt;
  wire       rd_any        = rd_valid_i;                         // legal only if g_rd_cnt_eff != 0 (E3)
  // v2 orphans (the timeout pulse is one cycle late, like g_rd_cnt_eff)
  logic [2:0]  g_orph = '0;
  logic [15:0] g_quiet = '0;
  wire [2:0] g_orph_eff = (tmo && g_orph != 3'd7) ? g_orph + 3'd1 : g_orph;
  wire       g_ontime   = (g_rd_cnt_eff != 3'd0) && (cyc == g_due[g_rd_q[g_rd_head_eff]]);
  wire       g_drop     = rd_any && (g_orph_eff != 3'd0) && !g_ontime;
  wire       g_ambig    = !g_ontime || (g_orph_eff != 3'd0);
  wire       rd_ret     = rd_any && !g_drop;                     // a return that completes the oldest outstanding read

  // "completion event happened" as seen in THIS cycle (timeout handled combinationally)
  logic [3:0] eff_done;
  always_comb begin
    eff_done = ev_done;
    if (tmo) eff_done[g_rd_q[g_rd_head_to]] = 1'b1;
  end

  wire g_pop_fire = rsp_valid && rsp_ready_i;

  // tracked entry (sequence number == trk)
  logic        trk_have = 1'b0;
  hbm_ctx_t    trk_ctx  = '0;
  logic [1:0]  trk_kind = '0;
  hbm_err_e    trk_err_exp = HERR_NONE;
  logic        trk_corr_exp = 1'b0;
`ifdef FV_DATA
  hbm_data_t   trk_data_exp = '0;
`endif

  always @(posedge clk) if (!init) begin
    // allocation
    if (g_push) begin
      g_alloc <= g_alloc + 4'd1;
      g_tail  <= g_tail + 2'd1;
      g_kind[g_tail] <= push_kind_i;
      g_seq [g_tail] <= g_alloc;
      g_due [g_tail] <= cyc + 16'd1 + tp.rl;
      ev_done[g_tail] <= (push_kind_i == 2'd2);
      g_wr_pend[g_tail] <= (push_kind_i == 2'd1);
      if (push_kind_i == 2'd0) begin g_rd_q[g_rd_wp] <= g_tail; g_rd_wp <= g_rd_wp + 2'd1; end
      if (g_alloc == trk) begin
        trk_have <= 1'b1; trk_ctx <= push_ctx_i; trk_kind <= push_kind_i;
        trk_err_exp  <= push_ctx_i.err;                       // error / write entries complete with ctx.err
        trk_corr_exp <= 1'b0;
`ifdef FV_DATA
        trk_data_exp <= '0;
`endif
      end
    end
    // write completion
    if (wr_done_valid_i) begin
      ev_done[wr_done_idx_i]   <= 1'b1;
      g_wr_pend[wr_done_idx_i] <= 1'b0;
    end
    // read data return (matched in order to the oldest outstanding read, skipping an entry timed out just now)
    if (rd_ret) begin
      ev_done[g_rd_q[g_rd_head_eff]] <= 1'b1;
      if (g_seq[g_rd_q[g_rd_head_eff]] == trk && trk_have) begin
        trk_err_exp  <= g_ambig ? HERR_FLUSHED : ((rd_err_i != HERR_NONE) ? rd_err_i : trk_ctx.err);
        trk_corr_exp <= g_ambig ? 1'b0 : rd_corr_i;
`ifdef FV_DATA
        trk_data_exp <= rd_data_i;
`endif
      end
    end
    // timeout path
    if (tmo) begin
      ev_done[g_rd_q[g_rd_head_to]] <= 1'b1;
      if (g_seq[g_rd_q[g_rd_head_to]] == trk && trk_have) begin
        trk_err_exp  <= HERR_FLUSHED;
        trk_corr_exp <= 1'b0;
      end
    end
    g_rd_rp  <= g_rd_rp + {1'b0, tmo} + {1'b0, rd_ret};
    // orphan bookkeeping (a new timeout decision is picked up next cycle through tmo / g_orph_eff)
    if (g_drop)                                             g_orph <= g_orph_eff - 3'd1;
    else if (g_orph_eff != 3'd0 && g_quiet >= 16'(RDT))     g_orph <= 3'd0;
    else                                                    g_orph <= g_orph_eff;
    if (rd_any || (g_rd_cnt_eff != 3'd0) || g_push) g_quiet <= '0;
    else if (g_quiet != 16'hFFFF)                   g_quiet <= g_quiet + 16'd1;
    g_rd_cnt <= g_rd_cnt + {2'b0, (g_push && push_kind_i == 2'd0)} - {2'b0, tmo} - {2'b0, rd_ret};
    // release
    if (g_pop_fire) begin
      g_pop  <= g_pop + 4'd1;
      g_head <= g_head + 2'd1;
      ev_done[g_head] <= 1'b0;
    end
    g_cnt <= g_cnt + {2'b0, g_push} - {2'b0, g_pop_fire};
  end

  // ---- ENVIRONMENT ASSUMPTIONS ----------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    assume(push_kind_i != 2'd3);                                                   // E1
    assume(push_ctx_i.write == (push_kind_i == 2'd1));
    assume(push_ctx_i.id == g_alloc);
    assume(!rd_valid_i || (g_rd_cnt_eff != 3'd0));                                 // E3
    assume(!wr_done_valid_i || g_wr_pend[wr_done_idx_i]);                          // E4
  end

  // previous-cycle snapshot
  logic     pv_valid = 1'b0, pv_ready = 1'b0;
  hbm_rsp_t pv_rsp = '0;
  logic     pv_rd_hit = 1'b0;            // rd_valid_i with an outstanding head last cycle
  logic     pv_drop   = 1'b0;            // v2: the ghost dropped a return last cycle
  logic [15:0] pv_due = '0, pv_cyc = '0;
  always @(posedge clk) begin
    pv_valid <= rsp_valid && !init;
    pv_ready <= rsp_ready_i;
    pv_rsp   <= rsp;
    pv_rd_hit <= rd_valid_i && !init;
    pv_drop   <= g_drop && !init;
    pv_due   <= g_due[g_rd_q[g_rd_head_eff]];
    pv_cyc   <= cyc;
  end

  // ---- PROPERTIES -------------------------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    // R1: credit / occupancy / allocation slot
    assert(credit == g_credit);                                   // credit_o low exactly when full
    assert(occ == g_cnt);
    assert(push_idx == g_tail);
    // R2: responses leave in allocation order; valid exactly when the head entry's completion event happened
    assert(rsp_valid == (g_cnt != 3'd0 && eff_done[g_head]));
    if (rsp_valid) begin
      assert(g_cnt != 3'd0);                                      // no response for an entry that was never allocated
      assert(rsp.id == g_pop);                                    // order, no duplicate, no skipped entry
      assert(rsp.write == (g_kind[g_head] == 2'd1));
      assert(g_seq[g_head] == g_pop);
      if (g_kind[g_head] == 2'd0) assert(eff_done[g_head]);       // READ valid only after rd_valid_i or the timeout path
    end
    // R3: stable under back-pressure
    if (pv_valid && !pv_ready) begin
      assert(rsp_valid);
      assert(rsp.src == pv_rsp.src && rsp.id == pv_rsp.id && rsp.write == pv_rsp.write &&
             rsp.err == pv_rsp.err && rsp.corrected == pv_rsp.corrected);
`ifdef FV_DATA
      assert(rsp.data == pv_rsp.data);
`endif
    end
    // R4: completion flags exist only for allocated entries (internal), done never set twice by the environment
    for (int i = 0; i < CPL; i++) begin
      logic       in_win;
      logic [1:0] d;
      d      = 2'(i) - g_head;
      in_win = (3'(d) < g_cnt);
      if (dut.done_q[i]) assert(in_win);
    end
    // R5: payload integrity of the tracked entry
    if (rsp_valid && g_pop == trk) begin
      assert(trk_have);
      assert(rsp.src == trk_ctx.src && rsp.id == trk_ctx.id && rsp.write == trk_ctx.write);
      // (a timeout reported THIS cycle is applied to the expectation combinationally, like eff_done)
      assert(rsp.err == ((tmo && g_rd_q[g_rd_head_to] == g_head) ? HERR_FLUSHED : trk_err_exp));
      assert(rsp.corrected == ((tmo && g_rd_q[g_rd_head_to] == g_head) ? 1'b0 : trk_corr_exp));
`ifdef FV_DATA
      assert(rsp.data == (trk_ctx.write ? '0 : trk_data_exp));
`endif
    end
    // R6: timeout path only after due + RD_TIMEOUT; read-return pulses are consistent with the ghost
    if (rd_timeout) begin
      assert(g_rd_cnt != 3'd0);
      assert((cyc - 16'd1) - g_due[g_rd_q[g_rd_head_to]] >= 16'(RDT));
      assert((cyc - 16'd1) != g_due[g_rd_q[g_rd_head_to]]);
    end
    assert(!rd_unexpected);                                       // never, because of E3
    assert(rd_orphan_drop == pv_drop);                            // v2: a return is dropped exactly when the ghost drops it
    assert(dut.orph_q == g_orph_eff);                             // v2: DUT orphan count tracks the ghost (both saturate at 7)
    if (pv_rd_hit) assert(rd_timing_err == (pv_cyc != pv_due));
    else            assert(!rd_timing_err);
  end

  // ---- COVER ----------------------------------------------------------------------------------------
  always @(posedge clk) if (!init) begin
    cover(rsp_valid && g_kind[g_head] == 2'd0 && !tmo && g_cnt == 3'd1);   // read completion via rd_valid_i
    cover(rsp_valid && g_kind[g_head] == 2'd1);                            // write completion
    cover(rsp_valid && g_kind[g_head] == 2'd2);                            // error entry
    cover(rsp_valid && !rsp_ready_i);                                      // back-pressure
    cover(!credit);                                                        // full
    cover(!credit && rsp_valid && rsp_ready_i);                            // full, then a pop frees credit
    cover(tmo && rsp_valid && g_kind[g_head] == 2'd0 && rsp.err == HERR_FLUSHED);   // timeout path
    cover(g_cnt == 3'd2 && !eff_done[g_head] && eff_done[g_head + 2'd1]);  // younger entry done, head still pending (no reorder)
    cover(g_alloc == 4'd6 && g_cnt != 3'd0);                               // slots wrap around
    cover(rd_valid_i && tmo);                                              // return and timeout in the same cycle
    cover(rd_timing_err);                                                  // early/late data flagged
  end
endmodule
