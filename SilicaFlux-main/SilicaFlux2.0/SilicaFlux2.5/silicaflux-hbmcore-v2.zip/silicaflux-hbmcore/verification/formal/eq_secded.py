#!/usr/bin/env python3
"""Combinational SAT equivalence proof: SECDED encode/decode of rtl/sf_hbm_ecc_ras.sv vs the v1 golden functions
(verification/formal/secded_v1_reference.svh), for ALL 2^266 data+check inputs and every output (check bits, UE, CE,
syndrome, corrected data). Non-vacuity: a deliberately wrong CE variant MUST be refuted (counterexample found).

Method note: an explicit SystemVerilog miter (`diff` = OR of all output mismatches) and `sat -prove diff 0` are used.
`miter -equiv -ignore_gold_x` was tried first and accepted the wrong variant (false negative) - do not use it here.
Tool: YoWASP Yosys (yosys-slang front end).  Output: reports/eq_secded.json.  Exit 0 only if proof AND mutant behave.
"""
import json, os, pathlib, shutil, subprocess, sys, tempfile, time
ROOT = pathlib.Path(__file__).resolve().parents[2]
YW = os.environ.get("YOWASP_YOSYS") or shutil.which("yowasp-yosys") or os.path.join(os.environ.get("YOWASP_BIN", ""), "yowasp-yosys")
TMPL = """module %s import sf_hbm_pkg::*; (input hbm_data_t d, input hbm_ecc_t c, output hbm_ecc_t e, output logic ue,
  output logic ce, output logic [8:0] syn, output hbm_data_t q);
%s
  dec_t r;
  always_comb begin e = enc(d); r = dec(d, c); ue = r.ue; ce = r.ce; syn = r.syn; q = r.data; end
endmodule
"""
MITER = """module miter_%s (input sf_hbm_pkg::hbm_data_t d, input sf_hbm_pkg::hbm_ecc_t c, output logic diff);
  import sf_hbm_pkg::*;
  hbm_ecc_t e0, e1; logic u0, u1, c0, c1; logic [8:0] s0, s1; hbm_data_t q0, q1;
  sec_gold g (.d, .c, .e(e0), .ue(u0), .ce(c0), .syn(s0), .q(q0));
  %s i (.d, .c, .e(e1), .ue(u1), .ce(c1), .syn(s1), .q(q1));
  assign diff = (e0 != e1) || (u0 != u1) || (c0 != c1) || (s0 != s1) || (q0 != q1);
endmodule
"""
def block(text):
    i = text.index("  // -------- code construction")
    j = text.index("  // -------- one-shot injection state") if "one-shot injection state" in text else len(text)
    return text[i:j]

def prove(work, top):
    t0 = time.time()
    p = subprocess.run([YW, "-q", "-l", f"{top}.log", "-p",
                        f"read_slang -j 1 -D SYNTHESIS sf_hbm_pkg.sv gold.sv rtl.sv mut.sv {top}.sv --top {top}; "
                        f"proc; flatten; opt -fast; sat -verify -prove diff 0 -set-def-inputs {top}"],
                       cwd=work, capture_output=True, text=True, timeout=3600)
    log = (work / f"{top}.log").read_text() if (work / f"{top}.log").exists() else p.stdout + p.stderr
    if "no model found: SUCCESS" in log: res = "EQUIVALENT"
    elif "model found: FAIL" in log:   res = "DIFFERENT"
    else:                               res = "ERROR"
    return res, round(time.time() - t0, 1)

def main():
    if not (shutil.which(YW) or os.path.exists(YW)):
        print("DEPENDENCY MISSING: yowasp-yosys (pip install yowasp-yosys)"); sys.exit(2)
    gold = block((ROOT / "verification/formal/secded_v1_reference.svh").read_text())
    rtl = block((ROOT / "rtl/sf_hbm_ecc_ras.sv").read_text())
    # mutant of the CURRENT rtl: CE asserted on every odd-parity word (wrong for uncorrectable triple errors)
    mut = rtl.replace("    r.ce   = op && !(nz && !is_pow2 && !any_match);", "    r.ce   = op;")
    if mut == rtl:   # v1-style RTL: mutate its CE clearing instead
        mut = rtl.replace("          if (r.ue) r.ce = 1'b0;", "")
    work = pathlib.Path(tempfile.mkdtemp(prefix="eq_secded_"))
    shutil.copy(ROOT / "rtl/sf_hbm_pkg.sv", work); shutil.copy(ROOT / "rtl/sf_hbm_geom.svh", work)
    (work / "gold.sv").write_text(TMPL % ("sec_gold", gold))
    (work / "rtl.sv").write_text(TMPL % ("sec_rtl", rtl))
    (work / "mut.sv").write_text(TMPL % ("sec_mut", mut))
    (work / "miter_rtl.sv").write_text(MITER % ("rtl", "sec_rtl"))
    (work / "miter_mut.sv").write_text(MITER % ("mut", "sec_mut"))
    r_rtl, t1 = prove(work, "miter_rtl")
    r_mut, t2 = prove(work, "miter_mut")
    ok = (r_rtl == "EQUIVALENT") and (r_mut == "DIFFERENT") and (mut != rtl)
    rep = dict(check="SECDED encode/decode: rtl/sf_hbm_ecc_ras.sv vs v1 golden (all 2^266 inputs, all outputs)",
               rtl_vs_golden=r_rtl, seconds=t1, nonvacuity_mutant=r_mut, mutant_seconds=t2, ok=ok, tool="YoWASP Yosys sat (explicit miter)")
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "eq_secded.json").write_text(json.dumps(rep, indent=1))
    print(json.dumps(rep))
    print("RESULT: PASS" if ok else "RESULT: FAIL")
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()
