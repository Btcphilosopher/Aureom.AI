#!/bin/sh
# Full verification sweep; every step must pass (set -e).  Refreshes reports/ and the generated docs.
#   sim/run_all.sh            (~20 minutes on 4 cores)
# Separate, slower steps:  make mutate  (mutation testing, ~20 min)   make synth  (Yosys, ~25 min)
#                          python3 py/tools/run_exhaustive.py --five   (5-lane bounded-exhaustive, ~25 min)
cd "$(dirname "$0")/.." || exit 1
set -e
J=${JOBS:-4}
echo "== python model tests (incl. the 4-lane bounded-exhaustive equivalence, 640 000 requests)"
PYTHONHASHSEED=0 python3 -m unittest discover -s py/tests -t py 2>&1 | tail -3
echo "== lint";                           sim/lint.sh
echo "== regress: quick (Verilator)";     python3 sim/run_regress.py --suite quick    --jobs "$J" | tail -2
echo "== regress: configs (Verilator)";   python3 sim/run_regress.py --suite configs  --jobs "$J" | tail -2
echo "== regress: mappings (Verilator)";  python3 sim/run_regress.py --suite mappings --jobs "$J" | tail -2
echo "== regress: icarus";                python3 sim/run_regress.py --suite icarus   --jobs "$J" | tail -2
echo "== regress: bench (RTL replay of the benchmark workloads)"; python3 sim/run_regress.py --suite bench --jobs "$J" | tail -2
echo "== self-checking benches (both simulators)"; python3 sim/run_tests.py --jobs "$J" | tail -2
echo "== soak / fairness";                python3 sim/run_soak.py | tail -2
echo "== benchmark sweeps + generated documents"
python3 py/tools/bench.py > /dev/null
python3 py/tools/make_report.py
python3 py/tools/make_verification.py
echo "ALL PASS"
