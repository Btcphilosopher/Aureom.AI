#!/usr/bin/env python3
"""SFSM trace-replay regression: RTL (Verilator, optionally Icarus) vs Python models.

    python3 sim/run_regress.py --suite quick  [--jobs 4]
    python3 sim/run_regress.py --suite configs
    python3 sim/run_regress.py --suite mappings
    python3 sim/run_regress.py --suite icarus
    python3 sim/run_regress.py --suite soak
    python3 sim/run_regress.py --list

For every (configuration, workload):
  1. Python generates per-port trace files (py/sfsm/workloads.py),
  2. the RTL testbench tb/tb_smem_replay.sv replays them and logs every accept /
     response with its cycle, the perf counters, the architectural read-back and
     the physical bank contents,
  3. py/sfsm/cycle.py simulates the same traces; the two must agree EXACTLY (cycles,
     tags, lane valid, status, data, perf counters, memory, physical layout),
  4. the workload's independent numeric expectation (computed without any memory
     model) is applied to the RTL's own architectural memory image.
A case passes only if all four hold and the testbench printed `errors=0 PASS`.
"""
import argparse
import json
import os
import sys
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "py"))

import simlib                                                    # noqa: E402
from sfsm.arch import (Config, MAP_LINEAR, MAP_XOR, MAP_SKEW, MAP_BLOCK, Lane, Req, OP_STORE)  # noqa: E402
from sfsm import workloads as W                                  # noqa: E402
from sfsm.cycle import simulate                                  # noqa: E402
from sfsm.trace import write_traces, parse_log, compare          # noqa: E402

BASE = Config(NL=8, NB=8, DEPTH=64, NP=2, AW=16)


def _safe(fn, *a, **k):
    try:
        return fn(*a, **k)
    except ValueError:
        return None


def full_set(cfg):
    """All workloads that fit this configuration (T limited so that small memories work)."""
    T = min(cfg.NL, 8)
    cands = [
        _safe(W.reduction, cfg, "interleaved"), _safe(W.reduction, cfg, "sequential"),
        _safe(W.reduction, cfg, "atomic_flat"), _safe(W.reduction, cfg, "atomic_private"),
        _safe(W.histogram, cfg, "uniform"), _safe(W.histogram, cfg, "skewed"),
        _safe(W.histogram, cfg, "single"), _safe(W.histogram, cfg, "lane"),
        _safe(W.histogram, cfg, "sorted"), _safe(W.histogram, cfg, "uniform", privatized=True),
        _safe(W.gemm_tiled, cfg, T=T), _safe(W.transpose_tile, cfg, T=T),
        _safe(W.transpose_tile, cfg, T=T, pitch=T + 1),
        _safe(W.hot_add, cfg), _safe(W.bank_hammer, cfg), _safe(W.cas_increment, cfg),
        _safe(W.cas_max, cfg), _safe(W.strided_stream, cfg, 1), _safe(W.strided_stream, cfg, cfg.NB),
        _safe(W.strided_stream, cfg, 2), _safe(W.multiport_hammer, cfg),
        _safe(W.fuzz, cfg, seed=11), _safe(W.fuzz, cfg, seed=12, p_hot=0.95),
    ]
    return [w for w in cands if w is not None]


def core_set(cfg):
    T = min(cfg.NL, 8)
    cands = [
        _safe(W.fuzz, cfg, seed=21), _safe(W.fuzz, cfg, seed=22, p_hot=0.95, p_inactive=0.3),
        _safe(W.hot_add, cfg, nreq=80), _safe(W.cas_increment, cfg),
        _safe(W.histogram, cfg, "skewed"), _safe(W.transpose_tile, cfg, T=T),
        _safe(W.reduction, cfg, "interleaved"), _safe(W.multiport_hammer, cfg, nreq=60),
    ]
    return [w for w in cands if w is not None]


def with_init_prefix(cfg, w):
    """INIT_ON_RESET=0: the array contents are undefined after reset, so a program must
    initialise memory itself.  Prepend zero stores on port 0 and delay the other ports."""
    zero = [Req(0, i & ((1 << cfg.TAGW) - 1),
                [Lane(1, OP_STORE, (base + l) * 4, 0xF, 0, 0) if base + l < cfg.cap_words else Lane(0, 0, 0, 0, 0, 0)
                 for l in range(cfg.NL)])
            for i, base in enumerate(range(0, cfg.cap_words, cfg.NL))]
    pp = [list(x) for x in w.per_port]
    delay = len(zero) * 8 + 64
    for p in range(1, cfg.NP):
        if pp[p]:
            pp[p][0] = pp[p][0]._replace(gap=pp[p][0].gap + delay)
    pp[0] = zero + pp[0]
    return W.Workload(w.name, pp, w.check, w.notes)


# --------------------------------------------------------------------------- suites
def cfgs_sweep():
    c = BASE
    yield "base", c, None
    yield "nl16_nb8", c.with_(NL=16, DEPTH=32), None
    yield "nl4_nb8", c.with_(NL=4), None
    yield "nl8_nb4", c.with_(NB=4, DEPTH=128), None
    yield "nl8_nb2", c.with_(NB=2, DEPTH=256), None
    yield "nl32_nb32", c.with_(NL=32, NB=32, DEPTH=16), None
    yield "nl2_nb2", c.with_(NL=2, NB=2, DEPTH=256), None
    yield "nl6_nb4", c.with_(NL=6, NB=4, DEPTH=128), None
    yield "np1", c.with_(NP=1), None
    yield "np4", c.with_(NP=4), [(1, 1), (3, 2), (5, 1), (1, 1)]
    yield "req1_rsp1", c.with_(REQ_DEPTH=1, RSP_DEPTH=1), None
    yield "req4_rsp8", c.with_(REQ_DEPTH=4, RSP_DEPTH=8), None
    yield "rsp2_slow_consumer", c.with_(RSP_DEPTH=2), [(4, 1), (3, 2)]
    yield "lane_arb_fixed", c.with_(LANE_ARB=0), None
    yield "port_arb_fixed", c.with_(PORT_ARB=0), None
    yield "no_write_combine", c.with_(WRITE_COMBINE=0), None
    yield "init_off", c.with_(INIT_ON_RESET=0), None
    yield "tagw4", c.with_(TAGW=4), None
    yield "aw24", c.with_(AW=24), None
    yield "depth_2", c.with_(NB=16, DEPTH=2, NL=16), None
    yield "map_xor_nl16", c.with_(NL=16, DEPTH=32, MAPPING=MAP_XOR), None


def cfgs_mappings():
    c = BASE
    for name, kw in [("linear", dict(MAPPING=MAP_LINEAR)), ("xor", dict(MAPPING=MAP_XOR)),
                     ("skew", dict(MAPPING=MAP_SKEW)), ("block1", dict(MAPPING=MAP_BLOCK, BLK_LOG2=1)),
                     ("block2", dict(MAPPING=MAP_BLOCK, BLK_LOG2=2)), ("block0", dict(MAPPING=MAP_BLOCK, BLK_LOG2=0))]:
        yield "map_" + name, c.with_(**kw), None
    for name, kw in [("xor_nb32", dict(MAPPING=MAP_XOR)), ("skew_nb32", dict(MAPPING=MAP_SKEW)),
                     ("block3_nb16", dict(MAPPING=MAP_BLOCK, BLK_LOG2=3))]:
        nb = 32 if "nb32" in name else 16
        yield "map_" + name, c.with_(NL=nb, NB=nb, DEPTH=16, **kw), None


def cfgs_bench():
    from sfsm import benchlib
    for n in (8, 16):
        for name, kw in benchlib.MAPPINGS:
            yield "b%d_%s" % (n, name), benchlib.bench_config(n, kw), None


SUITES = {
    "bench": cfgs_bench,
    "quick": lambda: [("base", BASE, None)],
    "configs": cfgs_sweep,
    "mappings": cfgs_mappings,
    "icarus": lambda: [("base", BASE, None), ("nl16_nb8", BASE.with_(NL=16, DEPTH=32), None),
                       ("init_off", BASE.with_(INIT_ON_RESET=0), None),
                       ("nl6_nb4", BASE.with_(NL=6, NB=4, DEPTH=128), None),
                       ("np4_slow", BASE.with_(NP=4), [(1, 1), (3, 2), (5, 1), (1, 1)]),
                       ("map_xor", BASE.with_(MAPPING=MAP_XOR), None),
                       ("map_block2", BASE.with_(MAPPING=MAP_BLOCK, BLK_LOG2=2), None)],
}


def pick_workloads(suite, name, cfg):
    if suite == "bench":
        from sfsm import benchlib
        return benchlib.workload_list(cfg)
    if suite in ("quick", "mappings"):
        return full_set(cfg)
    if suite == "icarus":
        return core_set(cfg) + [w for w in full_set(cfg) if w.name in ("gemm_tiled", "cas_max", "hist_single")]
    if name in ("base", "np4", "init_off"):
        return full_set(cfg)
    return core_set(cfg)


def run_config(suite, name, cfg, pat, sim, outdir, only):
    t0 = time.time()
    tag = "%s_%s_%s" % (suite, name, sim) + simlib.RTLTAG
    rec = dict(config=name, params=cfg.rtl_params(), sim=sim, results=[], build_s=0.0, error=None)
    try:
        tb = ["tb/tb_smem_replay.sv"]
        if sim == "verilator":
            exe = simlib.verilator_build(tag, "tb_smem_replay", tb, cfg.rtl_params())
        else:
            exe = simlib.icarus_build(tag, "tb_smem_replay", tb, cfg.rtl_params())
        rec["build_s"] = round(time.time() - t0, 1)
        wls = pick_workloads(suite, name, cfg)
        if only:
            wls = [w for w in wls if any(o in w.name for o in only)]
        tdir = os.path.join(ROOT, "traces", tag)
        os.makedirs(tdir, exist_ok=True)
        for w in wls:
            r = dict(workload=w.name, ok=False, requests=0, cycles=0, problems=[])
            try:
                if cfg.INIT_ON_RESET == 0:
                    w = with_init_prefix(cfg, w)
                per_port = w.per_port
                r["requests"] = sum(len(x) for x in per_port)
                prefix = os.path.join(tdir, w.name)
                write_traces(prefix, cfg, per_port, pat)
                res = simulate(cfg, per_port, pat)
                r["cycles"] = res.cycles
                r["conflict_cycles"] = res.perf["conflict_cycles"]
                r["model_perf"] = dict(res.perf)
                logf = prefix + ".log"
                # a hang is detected after 20x the cycles the model says the run needs
                args = ["+TRACE=" + prefix, "+OUT=" + logf, "+PHYS", "+MAXCYC=%d" % (20 * res.cycles + 2000)]
                if cfg.INIT_ON_RESET == 0 and sim == "verilator":
                    args += ["+verilator+rand+reset+2", "+verilator+seed+5"]   # arrays start as random garbage
                if sim == "verilator":
                    rc, out = simlib.verilator_run(exe, args)
                else:
                    rc, out = simlib.icarus_run(exe, args)
                tbres = simlib.parse_result(out)
                if rc != 0 or tbres is None or tbres["verdict"] != "PASS":
                    r["problems"].append("testbench: rc=%s result=%s tail=%s" % (rc, tbres, out[-300:].strip()))
                log = parse_log(logf, cfg)
                r["problems"] += compare(cfg, res, log)
                r["rtl_done_cycle"] = log["done"]
                r["rtl_busy_cycles"] = (log["done"] - min(log["acc"].values()) + 1) if log["acc"] else 0
                r["rtl_perf"] = dict(log["perf"])
                words = [log["mem"].get(i, -1) for i in range(cfg.cap_words)]
                r["problems"] += ["independent check: " + m for m in w.check(words)]
                r["ok"] = not r["problems"]
            except Exception as e:                                   # noqa: BLE001
                r["problems"].append("exception: %r\n%s" % (e, traceback.format_exc()[-800:]))
            rec["results"].append(r)
    except Exception as e:                                           # noqa: BLE001
        rec["error"] = "%r\n%s" % (e, traceback.format_exc()[-1500:])
    rec["seconds"] = round(time.time() - t0, 1)
    rec["ok"] = rec["error"] is None and all(r["ok"] for r in rec["results"]) and bool(rec["results"])
    return rec


def mapping_equivalence(recs, suite_dir):
    """For single-port workloads the architectural result (responses, memory) must be
    identical under every mapping; only timing may differ."""
    out, base = [], None
    logs = {}
    for rec in recs:
        if rec["params"]["NL"] != BASE.NL:
            continue
        name = rec["config"]
        cfg = Config(**rec["params"])
        d = os.path.join(ROOT, "traces", "mappings_%s_verilator" % name)
        for r in rec["results"]:
            if r["workload"] in ("multiport_hammer",) or r["workload"].startswith("fuzz"):
                continue                                   # multi-port: arbitration order differs legally
            f = os.path.join(d, r["workload"] + ".log")
            if os.path.exists(f):
                lg = parse_log(f, cfg)
                logs.setdefault(r["workload"], {})[name] = (
                    {k: v[1:] for k, v in lg["rsp"].items()}, lg["mem"])
    cmp_rows = []
    for wl, per_map in sorted(logs.items()):
        names = sorted(per_map)
        ref = per_map[names[0]]
        same = all(per_map[n] == ref for n in names)
        cmp_rows.append(dict(workload=wl, mappings=names, identical=same))
    return cmp_rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", default="quick")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", nargs="*", default=None, help="substring filter on workload names")
    ap.add_argument("--configs", nargs="*", default=None, help="restrict to these configuration names")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    if a.list:
        for s, f in SUITES.items():
            print(s, [n for n, _, _ in f()])
        print("soak: see sim/run_soak.py")
        return 0
    sim = "icarus" if a.suite == "icarus" else "verilator"
    cases = SUITES[a.suite]()
    if a.configs:
        cases = [c for c in cases if c[0] in a.configs]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = [ex.submit(run_config, a.suite, n, c, p, sim, None, a.only) for n, c, p in cases]
        recs = [f.result() for f in futs]
    total = sum(len(r["results"]) for r in recs)
    passed = sum(1 for r in recs for x in r["results"] if x["ok"])
    print("%-22s %-5s %6s  %s" % ("config", "build", "cases", "status"))
    for r in recs:
        n = len(r["results"])
        k = sum(1 for x in r["results"] if x["ok"])
        print("%-22s %4.0fs %3d/%-3d  %s" % (r["config"], r["build_s"], k, n,
                                             "PASS" if r["ok"] else "FAIL " + str(r["error"] or "")[:200]))
        for x in r["results"]:
            if not x["ok"]:
                print("   FAIL", x["workload"])
                for m in x["problems"][:6]:
                    print("      ", m)
    extra = {}
    if a.suite == "mappings":
        rows = mapping_equivalence(recs, None)
        extra["mapping_equivalence"] = rows
        print("\nmapping equivalence (identical architectural results under all mappings):")
        for row in rows:
            print("  %-22s %s" % (row["workload"], "identical" if row["identical"] else "DIFFERENT"))
        if not all(r["identical"] for r in rows):
            passed -= 1
    print("\n%d/%d workload runs passed, %.0fs" % (passed, total, time.time() - t0))
    outp = a.out or os.path.join(ROOT, "reports", "regress_%s.json" % a.suite)
    with open(outp, "w") as f:
        json.dump(dict(suite=a.suite, sim=sim, passed=passed, total=total, configs=recs, **extra), f, indent=1)
    return 0 if passed == total and total > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
