#!/bin/sh
# Generic Yosys synthesis of sf_smem_top: structural checks (no latches, no combinational
# loops, no multiple drivers - `check -assert` fails otherwise) and a cell-count line.
# DEPTH is forced small (override with DEPTH=...) so that the count reflects the CONTROL AND
# DATAPATH LOGIC; the storage array (NB*DEPTH*32 bits) is reported separately and would be an
# SRAM macro in a real flow.  NOT a timing, area or power signoff (no technology library).
# Parameters are applied by patching defaults in a scratch copy (Yosys 0.33's -chparam trips an
# internal assertion on this hierarchy).
#   sim/synth_check.sh <name> [PARAM=value ...]
cd "$(dirname "$0")/.." || exit 1
NAME=${1:-base}; [ $# -gt 0 ] && shift
D=build/yosys/$NAME; rm -rf "$D"; mkdir -p "$D/rtl" reports
cp rtl/*.sv rtl/*.svh "$D/rtl/"
for p in DEPTH=4 "$@"; do
  K=${p%%=*}; V=${p#*=}
  sed -i -E "s/^(  parameter int +$K +)= *[0-9]+/\1= $V/" "$D/rtl/sf_smem_top.sv"
done
cat > "$D/run.ys" <<YS
read_verilog -sv -I $D/rtl $D/rtl/sf_smem_bankmap.sv $D/rtl/sf_smem_atomic.sv $D/rtl/sf_smem_bank.sv $D/rtl/sf_smem_fifo.sv $D/rtl/sf_smem_issue.sv $D/rtl/sf_smem_top.sv
hierarchy -check -top sf_smem_top
proc
check -assert
synth -flatten -top sf_smem_top
check -assert
tee -o $D/stat.txt stat
YS
if ! yosys -q -l "$D/log.txt" "$D/run.ys" > /dev/null 2>&1; then
  echo "$NAME: YOSYS FAILED"; grep -E "^ERROR" "$D/log.txt" | head -5; exit 1
fi
LATCH=$(grep -c "Latch inferred" "$D/log.txt")
CELLS=$(grep -E "Number of cells:" "$D/stat.txt" | tail -1 | awk '{print $NF}')
FFS=$(grep -E '^ +\$_[A-Z0-9_]*DFF' "$D/stat.txt" | awk '{s+=$2} END {print s+0}')
MUX=$(grep -E '^ +\$_MUX_' "$D/stat.txt" | awk '{print $2}')
echo "$NAME: OK  latches=$LATCH  cells=$CELLS  flops=$FFS  mux=${MUX:-0}  [$*]"
