#!/usr/bin/env python3
"""Mutation testing of the test suite.

Each mutant is a one-line change of the RTL (a plausible design bug).  The test
suite must FAIL on it; a surviving mutant is either a hole in the tests or an
*equivalent* mutant (no observable behaviour change) - those are listed with a
justification and checked, not silently ignored.

Per mutant (Icarus Verilog, ~1 minute): directed bench, unit bench, reset bench,
system bench, and trace replays against the Python cycle model.

    python3 sim/mutate.py [--jobs 4] [--only NAME ...]      -> reports/mutation.json
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# (name, file, old, new, what it models, equivalent?)
M = [
    ("fwd_off", "sf_smem_bank.sv", "assign fwd_hit = fwd_valid && (fwd_row == s1_row);",
     "assign fwd_hit = 1'b0;", "write-forwarding removed (back-to-back RMW on one word reads stale data)", False),
    ("fwd_stale", "sf_smem_bank.sv", "fwd_word <= newword;", "fwd_word <= old;",
     "forward register holds the pre-operation word", False),
    ("store_ignores_be", "sf_smem_bank.sv", "assign wbe  = (s1_op == 2'd1) ? s1_be : 4'hF;", "assign wbe  = 4'hF;",
     "stores always write all four bytes", False),
    ("cas_inverted", "sf_smem_atomic.sv", "hit = (old == cmp);", "hit = (old != cmp);",
     "CAS succeeds when the values differ", False),
    ("add_sub", "sf_smem_atomic.sv", "2'd2: begin newword = old + wdata; ", "2'd2: begin newword = old - wdata; ",
     "ADD implemented as subtract", False),
    ("cas_no_write", "sf_smem_atomic.sv", "2'd3: begin newword = hit ? wdata : old;     wr = hit;      end",
     "2'd3: begin newword = hit ? wdata : old;     wr = 1'b0;     end", "CAS never writes", False),
    ("atomics_merge", "sf_smem_issue.sv", "mrg = (c == 2'd0) || (c == 2'd1 && WRITE_COMBINE != 0);",
     "mrg = 1'b1;", "atomics (and uncombined stores) merge like loads", False),
    ("class_mismatch_ok", "sf_smem_issue.sv", "if (!(l_cls[j] == l_cls[k] && mrg(l_cls[k]))) blocked[k] = 1'b1;",
     "if (!mrg(l_cls[k])) blocked[k] = 1'b1;", "a load may be merged across an earlier store on the same word", False),
    ("store_lowest_wins", "sf_smem_issue.sv", "for (k = 0; k < NL; k = k + 1)\n          if (grp[b][k])\n            for (m = 0; m < 4; m = m + 1)",
     "for (k = NL-1; k >= 0; k = k - 1)\n          if (grp[b][k])\n            for (m = 0; m < 4; m = m + 1)",
     "merged stores: lowest lane wins per byte", False),
    ("anchor_highest", "sf_smem_issue.sv", "if (j < k && same[j][k]) begin", "if (j > k && same[j][k]) begin",
     "lane order reversed (highest lane first)", False),
    ("ready_ignored", "sf_smem_issue.sv", "(sel_oh[b][k] || (|(sel_oh[b] & same[k])))", "(sel_oh[b][k] || (|(sel_oh[b] & same[k]))) /*MUT*/",
     "placeholder replaced below", False),
    ("load_mask_ignored", "sf_smem_issue.sv", "rmask[k*4 +: 4] = (l_cls[k] == 2'd0) ? l_be[k] :",
     "rmask[k*4 +: 4] = (l_cls[k] == 2'd0) ? 4'hF :", "loads return the whole word regardless of byte enables", False),
    ("align_over_range", "sf_smem_top.sv", "misal  ? `SF_ST_ALIGN :\n                        oor    ? `SF_ST_RANGE :",
     "oor    ? `SF_ST_RANGE :\n                        misal  ? `SF_ST_ALIGN :", "status precedence RANGE before ALIGN", False),
    ("atomic_be_unchecked", "sf_smem_top.sv", "wire bebad  = isatom && (be_l != 4'hF);", "wire bebad  = 1'b0;",
     "atomics with partial byte enables are accepted", False),
    ("noop_hits_bank", "sf_smem_top.sv", "wire nop = lv && (st == `SF_ST_OK) && !isatom && (be_l == 4'h0);",
     "wire nop = 1'b0;", "be=0 loads/stores consume bank cycles", False),
    ("credit_unchecked", "sf_smem_top.sv", "elig[aq] = !rf_empty[aq] && (cred[aq] != '0);",
     "elig[aq] = !rf_empty[aq];", "port arbiter ignores response credits (response FIFO can overflow)", False),
    ("rr_pointer_stuck", "sf_smem_top.sv", "port_ptr  <= (sel == PW'(NP-1)) ? '0 : sel + 1'b1;", "port_ptr  <= '0;",
     "round-robin pointer never advances (degenerates to fixed priority)", False),
    ("outst_on_push", "sf_smem_top.sv", "OW'(req_valid[fq] && req_ready[fq]) - OW'(rsp_pop[fq]);",
     "OW'(req_valid[fq] && req_ready[fq]) - OW'(rsp_push[fq]);", "outstanding drops when the response is PRODUCED, not consumed", False),
    ("init_short", "sf_smem_top.sv", "if (init_row == RW'(DEPTH-1)) begin", "if (init_row == RW'(DEPTH-2)) begin",
     "init sweep leaves the last row uninitialised", False),
    ("reset_keeps_outst", "sf_smem_top.sv", "        outst[fq] <= '0;\n", "        outst[fq] <= outst[fq];\n",
     "reset does not clear the outstanding counters", False),
    ("asm_leak", "sf_smem_top.sv", "t_base = g1_first ? 32'h0 : asm_q[ak*32 +: 32];", "t_base = asm_q[ak*32 +: 32];",
     "response assembly keeps the previous request's data in unserved lanes", False),
    ("wrong_port", "sf_smem_top.sv", "assign rsp_push[p] = g1_valid && g1_last && (g1_port == PW'(p));",
     "assign rsp_push[p] = g1_valid && g1_last && (p == 0);", "all responses routed to port 0", False),
    ("conflict_counter", "sf_smem_top.sv", "if (act_valid && !act_last) c[2] <= c[2] + 32'd1;",
     "if (act_valid) c[2] <= c[2] + 32'd1;", "performance counter off by one per request", False),
    ("xor_fold_short", "sf_smem_bankmap.sv", "bank  = lo ^ fold(hi);", "bank  = lo ^ hi[B-1:0];",
     "XOR mapping folds only the first chunk of the row index", False),
    ("skew_sign", "sf_smem_bankmap.sv", "bank  = lo + hi[(R<B?R:B)-1:0];", "bank  = lo - hi[(R<B?R:B)-1:0];",
     "skew mapping with the wrong sign (still a bijection, different layout)", False),
    # ---- equivalent mutants: must SURVIVE, and the reason is documented ----
    ("lane_ptr_stuck", "sf_smem_issue.sv", "lptr[fb] <= (aidx[fb] == LW'(NL-1)) ? '0 : aidx[fb] + 1'b1;",
     "lptr[fb] <= '0;", "rotating lane pointer never advances: only the order of DIFFERENT words inside a bank changes, "
     "which is neither architecturally nor timing visible (docs/ARCHITECTURE.md section 6)", True),
]
# the placeholder mutant above is replaced by a real one
M = [m for m in M if m[0] != "ready_ignored"]
M.append(("ready_ignored", "sf_smem_issue.sv", "grp[b][k] = ready[k] && b_valid[b] &&", "grp[b][k] = pend[k] && b_valid[b] &&",
          "group takes every pending lane on the word, ignoring lane-order readiness", False))


def apply_mutant(name, fname, old, new, outdir):
    src = os.path.join(ROOT, "rtl")
    shutil.rmtree(outdir, ignore_errors=True)
    shutil.copytree(src, outdir)
    p = os.path.join(outdir, fname)
    s = open(p).read()
    if s.count(old) != 1:
        raise RuntimeError("mutant %s: pattern found %d times in %s" % (name, s.count(old), fname))
    open(p, "w").write(s.replace(old, new))


def run(cmd, env):
    try:
        p = subprocess.run(cmd, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=900)
    except subprocess.TimeoutExpired:
        return 124, "timeout (hang)"          # a mutant that hangs the bench is detected
    return p.returncode, p.stdout


def evaluate(m):
    name, fname, old, new, why, equiv = m
    t0 = time.time()
    outdir = os.path.join(ROOT, "build", "mut", name, "rtl")
    rec = dict(name=name, change=why, file=fname, equivalent=equiv, killed_by=[], seconds=0)
    try:
        apply_mutant(name, fname, old, new, outdir)
    except Exception as e:                                   # noqa: BLE001
        rec["error"] = str(e)
        return rec
    env = dict(os.environ, SF_RTL_DIR=os.path.relpath(outdir, ROOT))
    tests = [("directed", ["sim/run_tests.py", "--sims", "icarus", "--jobs", "1", "--only", "directed_base"]),
             ("units", ["sim/run_tests.py", "--sims", "icarus", "--jobs", "1", "--only", "units"]),
             ("reset", ["sim/run_tests.py", "--sims", "icarus", "--jobs", "1", "--only", "reset_init1"]),
             ("system", ["sim/run_tests.py", "--sims", "icarus", "--jobs", "1", "--only", "system_rr"]),
             ("replay", ["sim/run_regress.py", "--suite", "icarus", "--jobs", "1", "--configs", "base", "--out",
                         os.path.join(outdir, "..", "replay.json")])]
    for tname, cmd in tests:
        outjson = os.path.join(outdir, "..", tname + ".json")
        c = [sys.executable] + cmd
        if cmd[0] == "sim/run_tests.py":
            c += ["--out", outjson]
        rc, out = run(c, env)
        if rc != 0:
            rec["killed_by"].append(tname)
    rec["killed"] = bool(rec["killed_by"])
    rec["seconds"] = round(time.time() - t0, 1)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", nargs="*", default=None)
    a = ap.parse_args()
    muts = [m for m in M if not a.only or m[0] in a.only]
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        recs = list(ex.map(evaluate, muts))
    print("%-22s %-10s %-34s %s" % ("mutant", "result", "killed by", "what it models"))
    bad = 0
    for r in recs:
        if "error" in r:
            print("%-22s ERROR %s" % (r["name"], r["error"]))
            bad += 1
            continue
        if r["equivalent"]:
            res = "survived (equivalent, expected)" if not r["killed"] else "KILLED (unexpected for an equivalent mutant?)"
            if r["killed"]:
                bad += 1
        else:
            res = "killed" if r["killed"] else "SURVIVED  <-- hole in the tests"
            if not r["killed"]:
                bad += 1
        print("%-22s %-10s %-34s %s" % (r["name"], res.split()[0], ",".join(r["killed_by"]) or "-", r["change"][:70]))
    n_kill = sum(1 for r in recs if r.get("killed") and not r["equivalent"])
    n_non = sum(1 for r in recs if not r["equivalent"])
    print("\nmutants killed: %d / %d non-equivalent; equivalent mutants surviving as documented: %d; problems: %d  (%.0fs)" % (
        n_kill, n_non, sum(1 for r in recs if r["equivalent"] and not r.get("killed")), bad, time.time() - t0))
    with open(os.path.join(ROOT, "reports", "mutation.json"), "w") as f:
        json.dump(recs, f, indent=1)
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
