#!/bin/sh
# Run the generic-synthesis structural check on a set of configurations in parallel.
# The 32x32 point is given a time limit (the O(NL^2 * NB) comparator network is slow in Yosys).
cd "$(dirname "$0")/.." || exit 1
mkdir -p reports build/yosys
rm -f reports/synth_summary.txt
run() { timeout "$T" sim/synth_check.sh "$@" > "build/yosys/out_$1.txt" 2>&1 || echo "$1: TIMEOUT/FAIL after ${T}s" >> "build/yosys/out_$1.txt"; }
T=600
run nl8_nb8_np2 &
run nl16_nb16_np2 NL=16 NB=16 &
run nl8_nb8_np1 NP=1 &
run nl8_nb8_np4 NP=4 &
wait
run nl8_nb8_wc0 WRITE_COMBINE=0 &
run nl8_nb8_lanefix LANE_ARB=0 &
run nl8_nb8_xor MAPPING=1 &
run nl8_nb8_perf0 PERF_EN=0 &
wait
T=1500
run nl32_nb32_np2 NL=32 NB=32
cat build/yosys/out_*.txt | sort > reports/synth_summary.txt
cat reports/synth_summary.txt
