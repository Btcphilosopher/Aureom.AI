#!/usr/bin/env python3
"""Prolonged-contention soak + fairness measurement.

Long multi-port traces run through the RTL (Verilator).  Each scenario must
  (1) agree EXACTLY with the cycle model (so the schedule the metrics are computed
      from is the schedule the RTL really executed),
  (2) satisfy its independent numeric check (sums of commutative atomics, ...),
  (3) satisfy scenario-specific invariants (no deadlock, bounded wait, no
      head-of-line blocking behind a slow consumer, ...).
Writes reports/soak.json (+ prints a table).
"""
import json
import os
import random
import sys
import time
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "py"))
import simlib                                                    # noqa: E402
from sfsm.arch import Config, Lane, INACTIVE, Req, M32, OP_LOAD, OP_STORE, OP_ADD, OP_CAS  # noqa: E402
from sfsm.cycle import simulate                                  # noqa: E402
from sfsm.trace import write_traces, parse_log, compare          # noqa: E402
from sfsm import metrics as M                                    # noqa: E402
from sfsm.randgen import rand_trace                              # noqa: E402

NREQ = 3000
BASE = Config(NL=8, NB=8, DEPTH=64, NP=4, AW=16, REQ_DEPTH=2, RSP_DEPTH=4)


def hot_adds(cfg, nreq, seed, words=(3, 5, 7)):
    """every port: lanes add random values to a few shared words (commutative)."""
    rng = random.Random(seed)
    tot = {w: 0 for w in words}
    pp = []
    for p in range(cfg.NP):
        reqs = []
        for i in range(nreq):
            lanes = []
            for l in range(cfg.NL):
                w, v = rng.choice(words), rng.getrandbits(32)
                tot[w] = (tot[w] + v) & M32
                lanes.append(Lane(1, OP_ADD, w * 4, 0xF, v, 0))
            reqs.append(Req(0, (p << 6 | i) & 0xFF, lanes))
        pp.append(reqs)
    return pp, (lambda mem: ["word %d: %08x != %08x" % (w, mem[w], t) for w, t in tot.items() if mem[w] != t])


def unit_loads(cfg, nreq, base=0):
    return [Req(0, i & 0xFF, [Lane(1, OP_LOAD, ((base + l + i) % cfg.cap_words) * 4, 0xF, 0, 0) for l in range(cfg.NL)])
            for i in range(nreq)]


def conflict_loads(cfg, nreq, seed):
    rng = random.Random(seed)
    out = []
    for i in range(nreq):
        b = rng.randrange(cfg.NB)
        out.append(Req(0, i & 0xFF, [Lane(1, OP_LOAD, ((b + cfg.NB * l) % cfg.cap_words) * 4, 0xF, 0, 0)
                                     for l in range(cfg.NL)]))
    return out


def mixed_degree(cfg, nreq, seed):
    """p0: conflict-free (d=1), p1: 8-way bank conflicts (d=8), p2: hot atomics, p3: random."""
    pp, _chk = hot_adds(cfg.with_(NP=1), nreq, seed)
    rnd = rand_trace(random.Random(seed), cfg.with_(NP=1), nreq, max_gap=0)
    return [unit_loads(cfg, nreq), conflict_loads(cfg, nreq, seed), pp[0], rnd[0]]


def scenarios():
    c = BASE
    pp, chk = hot_adds(c, NREQ, 1)
    yield dict(name="hot_atomics_rr", cfg=c, per_port=pp, check=chk, pat=None,
               why="4 ports saturating 3 hot words with atomic adds; round-robin port arbiter")
    pp, chk = hot_adds(c.with_(PORT_ARB=0), NREQ, 1)
    yield dict(name="hot_atomics_fixed", cfg=c.with_(PORT_ARB=0), per_port=pp, check=chk, pat=None,
               why="same traffic, fixed-priority port arbiter (port 0 highest)")
    yield dict(name="mixed_degree_rr", cfg=c, per_port=mixed_degree(c, NREQ, 2), check=None, pat=None,
               why="ports with conflict degree 1, 8, 8(atomic) and random; round robin")
    yield dict(name="mixed_degree_fixed", cfg=c.with_(PORT_ARB=0), per_port=mixed_degree(c, NREQ, 2), check=None,
               pat=None, why="same, fixed priority")
    # slow consumer on port 2 (accepts a response 1 cycle in 8) vs the same traffic with a fast consumer
    base_traffic = mixed_degree(c, NREQ, 3)
    yield dict(name="slow_consumer_ref", cfg=c, per_port=base_traffic, check=None, pat=None,
               why="reference run: all consumers fast")
    yield dict(name="slow_consumer", cfg=c, per_port=base_traffic, check=None,
               pat=[(1, 1), (1, 1), (64, 1), (1, 1)], why="port 2 consumes 1 response in 64 cycles (far below its natural rate)")
    yield dict(name="slow_consumer_light", cfg=c, per_port=base_traffic, check=None,
               pat=[(64, 1), (1, 1), (1, 1), (1, 1)],
               why="port 0 (conflict-free traffic) consumes 1 response in 64 cycles (far below its natural rate)")
    for s in (1, 2, 3):
        yield dict(name="fuzz_long_s%d" % s, cfg=c, per_port=rand_trace(random.Random(100 + s), c, NREQ, max_gap=2,
                                                                      p_hot=0.9), check=None, pat=None,
                   why="random mix incl. errors / inactive lanes / partial byte enables, 4 ports")
    yield dict(name="credit_starved", cfg=c.with_(RSP_DEPTH=1, REQ_DEPTH=1), per_port=mixed_degree(c, 1500, 4),
               check=None, pat=[(2, 1), (3, 1), (2, 1), (5, 2)], why="1-deep buffers, stalling consumers")


def window_metrics(res, cfg):
    """per-port completed requests / issue cycles inside the window where every port is
    backlogged: [max first grant, min last grant]."""
    starts, ends = [], []
    for p in range(cfg.NP):
        gs = [c for (pp, _i), c in res.grant.items() if pp == p]
        if not gs:
            return None
        starts.append(min(gs))
        ends.append(max(gs))
    t0, t1 = max(starts), min(ends)
    if t1 <= t0:
        t0, t1 = 0, res.cycles
    reqs = [0] * cfg.NP
    cyc = [0] * cfg.NP
    for (p, i), g in res.grant.items():
        if t0 <= g <= t1:
            reqs[p] += 1
            cyc[p] += res.cost[(p, i)]["d"]
    return dict(t0=t0, t1=t1, grants=reqs, issue_cycles=cyc, jain_requests=M.jain(reqs), jain_cycles=M.jain(cyc))


def run_scenario(exe, sc, tdir):
    cfg = sc["cfg"]
    pat = sc["pat"]
    name = sc["name"]
    r = dict(name=name, why=sc["why"], ok=False, problems=[])
    prefix = os.path.join(tdir, name)
    write_traces(prefix, cfg, sc["per_port"], pat)
    res = simulate(cfg, sc["per_port"], pat, max_cycles=5_000_000)
    rc, out = simlib.verilator_run(exe, ["+TRACE=" + prefix, "+OUT=" + prefix + ".log", "+PHYS", "+MAXCYC=5000000"])
    tb = simlib.parse_result(out)
    if rc != 0 or tb is None or tb["verdict"] != "PASS":
        r["problems"].append("testbench: rc=%s %s %s" % (rc, tb, out[-200:]))
    log = parse_log(prefix + ".log", cfg)
    r["problems"] += compare(cfg, res, log)
    if sc["check"]:
        words = [log["mem"].get(i, -1) for i in range(cfg.cap_words)]
        r["problems"] += ["independent check: " + m for m in sc["check"](words)]
    # ---- metrics from the (RTL-verified) schedule ----
    nreq = [len(x) for x in sc["per_port"]]
    r["requests_per_port"] = nreq
    r["cycles"] = res.cycles
    tp = M.throughput(res, cfg)
    r["req_per_cycle"] = round(tp["req_per_cycle"], 4)
    r["lanes_per_cycle"] = round(tp["lanes_per_cycle"], 3)
    r["bank_util"] = round(tp["bank_util"], 3)
    r["conflict_cycles"] = res.perf["conflict_cycles"]
    r["credit_stall_cycles"] = res.perf["credit_stall_cycles"]
    lat = []
    for p in range(cfg.NP):
        lt = M.latencies(res, p)
        lat.append({k: round(v, 2) for k, v in M.summarize_latency(lt).items()})
    r["latency_per_port"] = lat
    r["first_response_cycle"] = [min(v[0] for k, v in res.rsp.items() if k[0] == p) for p in range(cfg.NP)]
    r["last_response_cycle"] = [max(v[0] for k, v in res.rsp.items() if k[0] == p) for p in range(cfg.NP)]
    w = window_metrics(res, cfg)
    if w:
        r["backlogged_window"] = w
    r["max_other_grants_between_own"] = M.max_wait_between_grants_when_backlogged(res, cfg)
    r["done_cycle_per_port"] = r["last_response_cycle"]
    r["_res"] = res
    return r


def main():
    t0 = time.time()
    tdir = os.path.join(ROOT, "traces", "soak")
    os.makedirs(tdir, exist_ok=True)
    scs = list(scenarios())
    # one build per distinct configuration
    exes = {}
    cfgs = {}
    for sc in scs:
        cfgs.setdefault(tuple(sorted(sc["cfg"].rtl_params().items())), sc["cfg"])
    with ThreadPoolExecutor(max_workers=3) as ex:
        futs = {k: ex.submit(simlib.verilator_build, "soak_%d" % i, "tb_smem_replay", ["tb/tb_smem_replay.sv"],
                             c.rtl_params()) for i, (k, c) in enumerate(cfgs.items())}
        for k, f in futs.items():
            exes[k] = f.result()
    results = []
    for sc in scs:
        k = tuple(sorted(sc["cfg"].rtl_params().items()))
        results.append(run_scenario(exes[k], sc, tdir))

    # ---- cross-scenario invariants ----
    byname = {r["name"]: r for r in results}
    inv = []
    rr, fx = byname["hot_atomics_rr"], byname["hot_atomics_fixed"]
    inv.append(("RR bounded wait: no port waits more than NP-1 = 3 other grants while backlogged",
                max(rr["max_other_grants_between_own"]) <= BASE.NP - 1, rr["max_other_grants_between_own"]))
    inv.append(("RR fairness: Jain index over grants in the backlogged window >= 0.99",
                rr["backlogged_window"]["jain_requests"] >= 0.99, round(rr["backlogged_window"]["jain_requests"], 4)))
    inv.append(("fixed priority starves: port 3 gets no response before port 0 has completed everything",
                fx["first_response_cycle"][3] > fx["last_response_cycle"][0], (fx["first_response_cycle"][3], fx["last_response_cycle"][0])))
    inv.append(("fixed priority: all ports still complete eventually (no deadlock)",
                all(r > 0 for r in fx["last_response_cycle"]), fx["last_response_cycle"]))
    sr, s = byname["slow_consumer_ref"], byname["slow_consumer"]
    for p in (0, 1, 3):
        a, b = sr["last_response_cycle"][p], s["last_response_cycle"][p]
        inv.append(("slow consumer on port 2 does not delay port %d (done at %d vs %d cycles; earlier is fine)" % (p, b, a),
                    b <= a * 1.02 + 5, (a, b)))
    sl = byname["slow_consumer_light"]
    for p in (1, 2, 3):
        a, b = sr["last_response_cycle"][p], sl["last_response_cycle"][p]
        inv.append(("slow consumer on port 0 does not delay port %d (done at %d vs %d cycles with a fast consumer)" % (p, b, a),
                    b <= a * 1.02 + 5, (a, b)))
    inv.append(("slow consumer on port 0 is throttled by its own consumer: >= %d cycles for %d responses" % (64 * NREQ - 64, NREQ),
                sl["last_response_cycle"][0] >= 64 * NREQ - 64, sl["last_response_cycle"][0]))
    inv.append(("slow consumer on port 2 is throttled by its own consumer: >= %d cycles for %d responses" % (64 * NREQ - 64, NREQ),
                s["last_response_cycle"][2] >= 64 * NREQ - 64, s["last_response_cycle"][2]))
    inv.append(("slow consumer on port 0 shows up as credit stalls (back-pressure, not loss)",
                sl["credit_stall_cycles"] > 0 and sr["credit_stall_cycles"] < sl["credit_stall_cycles"],
                (sr["credit_stall_cycles"], sl["credit_stall_cycles"])))
    inv.append(("credit-starved 1-deep buffers: every request still completes",
                all(r == 1500 for r in byname["credit_starved"]["requests_per_port"]) and not byname["credit_starved"]["problems"], None))
    for r in results:
        r["ok"] = not r["problems"]
        r.pop("_res", None)
    ok = all(r["ok"] for r in results) and all(i[1] for i in inv)

    print("%-20s %7s %8s %6s %6s %5s  %s" % ("scenario", "cycles", "req/cyc", "lane/c", "confl", "ok", "per-port done cycle"))
    for r in results:
        print("%-20s %7d %8.3f %6.2f %6d %5s  %s" % (r["name"], r["cycles"], r["req_per_cycle"], r["lanes_per_cycle"],
                                                    r["conflict_cycles"], "PASS" if r["ok"] else "FAIL", r["done_cycle_per_port"]))
        for m in r["problems"][:4]:
            print("     ", m)
    print()
    for name, good, val in inv:
        print("%-5s %s   %s" % ("PASS" if good else "FAIL", name, "" if val is None else val))
    with open(os.path.join(ROOT, "reports", "soak.json"), "w") as f:
        json.dump(dict(scenarios=results, invariants=[dict(name=n, ok=g, value=v) for n, g, v in inv]), f, indent=1, default=str)
    print("\nsoak: %s  (%.0fs)" % ("PASS" if ok else "FAIL", time.time() - t0))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
