#!/usr/bin/env python3
"""Build the distribution zip.  Pure packaging: reads files, writes ../silicaflux-smem.zip and
MANIFEST.sha256.  Performs NO git operation of any kind."""
import hashlib
import os
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
TOP = "silicaflux-smem"
INCLUDE_DIRS = ["rtl", "tb", "py", "sim", "docs", "reports"]
INCLUDE_FILES = ["README.md", "Makefile"]
SKIP_DIRS = {"__pycache__", "build", "traces", ".git"}
SKIP_SUFFIX = (".pyc", ".log", ".vvp")


def files():
    out = list(INCLUDE_FILES)
    for d in INCLUDE_DIRS:
        for dp, dn, fn in os.walk(os.path.join(ROOT, d)):
            dn[:] = sorted(x for x in dn if x not in SKIP_DIRS)
            for f in sorted(fn):
                if f.endswith(SKIP_SUFFIX):
                    continue
                out.append(os.path.relpath(os.path.join(dp, f), ROOT))
    return out


def main():
    fl = [f for f in files() if f != "MANIFEST.sha256"]
    lines = []
    for f in fl:
        h = hashlib.sha256(open(os.path.join(ROOT, f), "rb").read()).hexdigest()
        lines.append("%s  %s" % (h, f))
    manifest = os.path.join(ROOT, "MANIFEST.sha256")
    open(manifest, "w").write("\n".join(lines) + "\n")
    dest = os.path.join(os.path.dirname(ROOT), "silicaflux-smem.zip") if len(sys.argv) < 2 else sys.argv[1]
    if os.path.exists(dest):
        os.remove(dest)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in fl + ["MANIFEST.sha256"]:
            info = zipfile.ZipInfo.from_file(os.path.join(ROOT, f), arcname=os.path.join(TOP, f))
            info.compress_type = zipfile.ZIP_DEFLATED
            if f.endswith(".sh") or f.endswith(".py") and f.startswith("sim/"):
                info.external_attr = (0o755 << 16)
            with open(os.path.join(ROOT, f), "rb") as fh:
                z.writestr(info, fh.read())
    print("wrote %s (%d files, %.1f KiB)" % (dest, len(fl) + 1, os.path.getsize(dest) / 1024.0))


if __name__ == "__main__":
    main()
