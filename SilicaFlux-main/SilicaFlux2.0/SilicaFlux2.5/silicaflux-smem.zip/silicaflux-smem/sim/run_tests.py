#!/usr/bin/env python3
"""Run every self-checking SystemVerilog bench across a configuration matrix, in
Verilator and Icarus Verilog.  A bench passes only if it prints `errors=0 PASS`.

    python3 sim/run_tests.py [--jobs 4] [--sims verilator icarus] [--only directed units ...]
"""
import argparse
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "py"))
import simlib                                   # noqa: E402
from tools import gen_map_tables                # noqa: E402  (py/tools on path below)

sys.path.insert(0, os.path.join(ROOT, "py", "tools"))

D = dict   # shorthand

# (name, bench top, bench file, parameter overrides, extra rtl, plusargs)
SYS = simlib.RTL + simlib.RTL_SYS
TESTS = [
    # hand-written directed tests
    ("directed_base",        "tb_smem_directed", "tb/tb_smem_directed.sv", D(), None, []),
    ("directed_lane_fixed",  "tb_smem_directed", "tb/tb_smem_directed.sv", D(LANE_ARB=0), None, []),
    ("directed_port_fixed",  "tb_smem_directed", "tb/tb_smem_directed.sv", D(PORT_ARB=0), None, []),
    ("directed_no_wcomb",    "tb_smem_directed", "tb/tb_smem_directed.sv", D(WRITE_COMBINE=0), None, []),
    ("directed_nl16",        "tb_smem_directed", "tb/tb_smem_directed.sv", D(NL=16, DEPTH=32), None, []),
    ("directed_nb16",        "tb_smem_directed", "tb/tb_smem_directed.sv", D(NB=16, DEPTH=32), None, []),
    ("directed_buf_1_1",     "tb_smem_directed", "tb/tb_smem_directed.sv", D(REQ_DEPTH=1, RSP_DEPTH=1), None, []),
    ("directed_buf_4_8",     "tb_smem_directed", "tb/tb_smem_directed.sv", D(REQ_DEPTH=4, RSP_DEPTH=8), None, []),
    ("directed_np4",         "tb_smem_directed", "tb/tb_smem_directed.sv", D(NP=4), None, []),
    ("directed_map_xor",     "tb_smem_directed", "tb/tb_smem_directed.sv", D(MAPPING=1), None, []),
    ("directed_map_skew",    "tb_smem_directed", "tb/tb_smem_directed.sv", D(MAPPING=2), None, []),
    ("directed_map_block2",  "tb_smem_directed", "tb/tb_smem_directed.sv", D(MAPPING=3, BLK_LOG2=2), None, []),
    ("directed_init_off",    "tb_smem_directed", "tb/tb_smem_directed.sv", D(INIT_ON_RESET=0), None, ["+verilator+rand+reset+2", "+verilator+seed+7"]),
    # unit tests (ALU, bank forwarding, bank maps vs Python tables)
    ("units",                "tb_smem_units", "tb/tb_smem_units.sv", D(), None, ["+TABLES=traces/maptab"]),
    # reset
    ("reset_init1",          "tb_smem_reset", "tb/tb_smem_reset.sv", D(), None, []),
    ("reset_init0",          "tb_smem_reset", "tb/tb_smem_reset.sv", D(INIT_ON_RESET=0), None, ["+verilator+rand+reset+2", "+verilator+seed+11"]),
    ("reset_buf_2_2",        "tb_smem_reset", "tb/tb_smem_reset.sv", D(RSP_DEPTH=2), None, []),
    ("reset_buf_4_8",        "tb_smem_reset", "tb/tb_smem_reset.sv", D(REQ_DEPTH=4, RSP_DEPTH=8), None, []),
    ("reset_nl16_nb4",       "tb_smem_reset", "tb/tb_smem_reset.sv", D(NL=16, NB=4, DEPTH=64), None, []),
    # barrier / fence system litmus
    ("system_rr",            "tb_smem_system", "tb/tb_smem_system.sv", D(), SYS, []),
    ("system_port_fixed",    "tb_smem_system", "tb/tb_smem_system.sv", D(PORT_ARB=0), SYS, []),
    ("system_lane_fixed",    "tb_smem_system", "tb/tb_smem_system.sv", D(LANE_ARB=0), SYS, []),
]


def run_one(t, sim):
    name, top, f, par, rtl, pa = t
    t0 = time.time()
    tag = "t_%s_%s" % (name, sim)
    try:
        ok, out = simlib.run_tb(tag, top, [f], par, sim=sim, plusargs=pa, rtl=rtl)
        r = simlib.parse_result(out)
        lit = [l for l in out.splitlines() if l.startswith("LITMUS")]
        det = ""
        for l in out.splitlines():
            if "RESULT:" in l:
                det = l.split("RESULT:")[1].strip()
        err_lines = [l for l in out.splitlines() if "ERROR" in l][:5]
        return dict(test=name, sim=sim, ok=bool(ok), detail=det, errors=err_lines, litmus=lit,
                    seconds=round(time.time() - t0, 1))
    except Exception as e:                       # noqa: BLE001
        return dict(test=name, sim=sim, ok=False, detail="exception", errors=[repr(e)[:400]], litmus=[],
                    seconds=round(time.time() - t0, 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--sims", nargs="+", default=["verilator", "icarus"])
    ap.add_argument("--only", nargs="*", default=None)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "tests.json"))
    a = ap.parse_args()
    gen_map_tables.write(os.path.join(ROOT, "traces", "maptab"))
    tests = [t for t in TESTS if not a.only or any(o in t[0] for o in a.only)]
    jobs = [(t, s) for t in tests for s in a.sims]
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(lambda ts: run_one(*ts), jobs))
    print("%-22s %-10s %-6s %-46s %s" % ("test", "sim", "status", "result", "sec"))
    for r in res:
        print("%-22s %-10s %-6s %-46s %5.1f" % (r["test"], r["sim"], "PASS" if r["ok"] else "FAIL", r["detail"][:46], r["seconds"]))
        if not r["ok"]:
            for e in r["errors"]:
                print("      ", e)
    npass = sum(r["ok"] for r in res)
    print("\n%d/%d bench runs passed, %.0fs" % (npass, len(res), time.time() - t0))
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w") as f:
        json.dump(res, f, indent=1)
    return 0 if npass == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
