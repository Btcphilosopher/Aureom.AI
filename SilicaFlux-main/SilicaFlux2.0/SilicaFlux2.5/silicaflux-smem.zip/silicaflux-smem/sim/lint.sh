#!/bin/sh
# Lint the RTL with Verilator (-Wall).  Usage: sim/lint.sh [extra verilator -G options]
cd "$(dirname "$0")/.." || exit 1
verilator --lint-only -Wall -Wno-DECLFILENAME -Wno-PINCONNECTEMPTY -Irtl \
  rtl/sf_smem_bankmap.sv rtl/sf_smem_atomic.sv rtl/sf_smem_bank.sv rtl/sf_smem_fifo.sv \
  rtl/sf_smem_issue.sv rtl/sf_smem_top.sv --top-module sf_smem_top "$@"
