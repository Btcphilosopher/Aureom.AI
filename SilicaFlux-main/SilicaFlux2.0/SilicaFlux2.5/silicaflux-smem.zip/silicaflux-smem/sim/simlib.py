"""Build / run helpers for Verilator (primary) and Icarus Verilog (secondary).

Every build goes into build/<tag>/ ; nothing is reused between configurations.
"""
import os
import re
import subprocess
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "py"))

# The RTL directory can be redirected (mutation testing builds mutated copies):  SF_RTL_DIR=build/mut/m01/rtl
RTLDIR = os.environ.get("SF_RTL_DIR", "rtl")
# builds, traces and logs of a mutated RTL copy must never collide with those of another copy
RTLTAG = "" if RTLDIR == "rtl" else "__" + re.sub(r"[^A-Za-z0-9]+", "_", RTLDIR)
RTL = [RTLDIR + "/" + f for f in ("sf_smem_bankmap.sv", "sf_smem_atomic.sv", "sf_smem_bank.sv",
                                  "sf_smem_fifo.sv", "sf_smem_issue.sv", "sf_smem_top.sv")]
RTL_SYS = ["rtl/sys/sf_wg_barrier.sv"]

VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
          "--assert", "-Wno-DECLFILENAME", "-O1", "--x-assign", "unique", "--x-initial", "unique"]


def _run(cmd, cwd, log=None, timeout=1800):
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       text=True, timeout=timeout)
    if log:
        with open(log, "w") as f:
            f.write(p.stdout)
    return p.returncode, p.stdout


def verilator_build(tag, top, tb_files, params, rtl=None, extra_flags=()):
    """Compile with Verilator --binary.  params: dict of top-level parameter overrides."""
    bdir = os.path.join(ROOT, "build", tag + RTLTAG)
    shutil.rmtree(bdir, ignore_errors=True)
    os.makedirs(bdir)
    cmd = ["verilator"] + VFLAGS + ["-Mdir", bdir, "--top-module", top, "-I" + RTLDIR, "-Itb"]
    for k, v in params.items():
        cmd.append("-G%s=%s" % (k, v))
    cmd += list(extra_flags) + list(rtl if rtl is not None else RTL) + list(tb_files)
    rc, out = _run(cmd, ROOT, os.path.join(bdir, "build.log"))
    exe = os.path.join(bdir, "V" + top)
    if rc != 0 or not os.path.exists(exe):
        raise RuntimeError("verilator build failed for %s:\n%s" % (tag, out[-3000:]))
    return exe


def verilator_run(exe, plusargs=(), timeout=3600):
    rc, out = _run([exe] + list(plusargs), ROOT, None, timeout)
    return rc, out


def icarus_build(tag, top, tb_files, params, rtl=None):
    bdir = os.path.join(ROOT, "build", tag + RTLTAG)
    shutil.rmtree(bdir, ignore_errors=True)
    os.makedirs(bdir)
    exe = os.path.join(bdir, "sim.vvp")
    cmd = ["iverilog", "-g2012", "-o", exe, "-s", top, "-I" + RTLDIR, "-Itb"]
    for k, v in params.items():
        cmd.append("-P%s.%s=%s" % (top, k, v))
    cmd += list(rtl if rtl is not None else RTL) + list(tb_files)
    rc, out = _run(cmd, ROOT, os.path.join(bdir, "build.log"))
    if rc != 0:
        raise RuntimeError("iverilog build failed for %s:\n%s" % (tag, out[-3000:]))
    return exe


def icarus_run(exe, plusargs=(), timeout=3600):
    rc, out = _run(["vvp", "-n", exe] + ["+" + a.lstrip("+") for a in plusargs], ROOT, None, timeout)
    return rc, out


RESULT_RE = re.compile(r"RESULT:\s+(\S+)\s+(.*?)errors=(\d+)\s+(PASS|FAIL)")


def parse_result(out):
    m = RESULT_RE.search(out)
    if not m:
        return None
    return dict(tb=m.group(1), errors=int(m.group(3)), verdict=m.group(4))


def run_tb(tag, top, tb_files, params, sim="verilator", plusargs=(), rtl=None):
    """Build + run one self-checking testbench; returns (ok, output)."""
    if sim == "verilator":
        exe = verilator_build(tag, top, tb_files, params, rtl=rtl)
        rc, out = verilator_run(exe, plusargs)
    else:
        exe = icarus_build(tag, top, tb_files, params, rtl=rtl)
        rc, out = icarus_run(exe, plusargs)
    r = parse_result(out)
    return (rc == 0 and r is not None and r["verdict"] == "PASS" and r["errors"] == 0), out
