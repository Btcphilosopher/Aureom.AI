# SilicaFlux Shared Memory (SFSM)

A banked, lane-parallel **shared-memory subsystem in synthesizable SystemVerilog** with per-lane requests, per-bank arbitration, read broadcast, byte enables, response routing, bounded buffering and **explicitly specified integer atomics (add, compare-and-swap)** - together with a Python reference/measurement framework and a verification suite that compares the RTL with the models **cycle for cycle**.

> **Status in one paragraph.** Everything here was verified by *simulation* (Verilator 5.020, Icarus 12.0) and structurally checked with Yosys 0.33. There is **no silicon, no technology library, no timing/area/power analysis** behind any number, and the subsystem is **not** integrated into the rest of SilicaFlux. Read `docs/KNOWN_LIMITATIONS.md` before relying on anything. Nothing in this package was committed or pushed anywhere; it is delivered as this zip.

## What you get

| | |
|---|---|
| **RTL** (`rtl/`) | `sf_smem_top` (NL lanes, NB banks, NP ports, credits, FIFOs), `sf_smem_issue` (per-bank arbitration, broadcast, write combining), `sf_smem_bank` (1R1W array, write-forwarding RMW pipeline), `sf_smem_atomic` (LOAD/STORE/ADD/CAS), `sf_smem_bankmap` (linear, XOR, skew, block - all bijections), FIFO, and a **separate** reference workgroup barrier `sf_wg_barrier` |
| **Contract** (`docs/SEMANTICS.md`) | atomicity scope, ordering, return values, alignment, signedness of add and CAS; deterministic conflicting writes (per-byte, highest lane wins); explicit rejection rules; reset semantics |
| **Fences** (`docs/FENCES_AND_BARRIERS.md`) | barrier semantics kept out of bank arbitration; the fence a client needs for visibility, with RTL-demonstrated hazards (90/160 randomised trials violate RAW and WAR without a fence, 0/160 with it) |
| **Python** (`py/`) | sequential reference (the architecture, executable), stepwise issue model, cycle-accurate model, workload generators (reductions, histograms, tiled GEMM, transposes, CAS loops, hot-word contention, fuzz), metrics, SVG charts - standard library only |
| **Tests** (`tb/`, `sim/`) | trace replay vs model, hand-computed directed tests, bank/ALU/mapping unit tests, reset tests, barrier/fence litmus, soak and fairness runs, mutation testing, lint, synthesis check |
| **Measurements** (`docs/BENCHMARKS.md`, `reports/`) | bank conflicts, latency, throughput, fairness, buffering, atomics, five bank mappings on 21 workloads |

## Design in one screen

```
 NP ports ->[decode + bank map]->[request FIFO]->[port arbiter (credits)]->[ACTIVE request]
      one request = NL lane operations        |                              |
                                              +--- response FIFO <--- assembly <--- NB banks
 per cycle, per bank: ONE word is served; every lane on that word that may legally share the
 access (loads: broadcast, stores: merged per byte) is served together; atomics one per word per cycle.
 Same-word lanes behave as if executed one after the other in ascending lane order.
```

* **Atomic add**: `new = old + wdata mod 2^32`, returns **old**; **CAS**: `new = (old == cmp) ? wdata : old`, returns **old**; 32-bit, 4-byte-aligned, `be = 4'b1111`; two's complement / bit-pattern semantics (signedness is irrelevant); atomic per word within one SFSM instance; lane-ordered when lanes collide.
* **Conflicting writes are deterministic**, never racy: per byte, the highest-numbered enabling lane wins. Misaligned, out-of-range, reserved-opcode and partial-byte-enable-atomic lanes are **rejected** with a status and no side effect.
* **Timing**: 4 cycles unloaded (accept -> response), `3 + d` for a request needing `d` serialised bank cycles, one request per cycle sustained when conflict free.
* **Mappings change only timing**: the architectural result is identical under all of them (checked on RTL).

## Results at a glance (all RTL runs unless marked MODEL; details and caveats in `docs/`)

* **722 RTL trace-replay runs** (112 179 requests, 395 337 cycles, 48 configuration builds incl. 2-32 lanes, 2-32 banks, non-power-of-two lanes, 1-4 ports, 1-8-deep buffers, both arbiters, no write combining, no init) **match the cycle model exactly** - every accept cycle, response cycle, tag, status, data word, performance counter, memory image and physical bank layout - and pass independent arithmetic checks (sums, histograms, matrix products, transposes, CAS-loop totals). 76 of them in the 4-state Icarus simulator.
* **44 self-checking bench runs** (22 benches x 2 simulators, 339 000+ checks): hand-computed directed tests (~250 checks per configuration, 13 configurations), bank forwarding under 72 000 back-to-back operations, 12 bank-map variants checked over all indices against Python tables, reset, barrier/fence litmus.
* **Fairness (MEASURED)**: 4 saturating ports - round robin: max 3 other grants between two own grants (= NP-1), Jain index 1.00; fixed priority: complete serialisation (finish times 12.3 k / 24.4 k / 36.6 k / 48.9 k cycles). A stalled consumer throttles only its own port.
* **Mapping comparison (MEASURED, 16x16, busy cycles)**: unpadded-tile transpose **5.8x** and stride-16 **15.1x** faster under XOR/skew with the *same architectural addresses* - but stride-17 is **15x slower** under XOR, software-padded transpose gets 3.0x / 1.6x slower under XOR / skew, and a lane-private-column layout gets 1.6x slower under XOR. No mapping wins everywhere (`docs/BENCHMARKS.md` section 10).
* **Atomics (MODEL, RTL-validated)**: independent atomics scale with bank count (32 per cycle at 32 banks); a single hot word is limited to 1 per cycle.
* **Bounded-exhaustive equivalence (Python)**: every combination of lane operations for 4 and 5 lanes over three words - 7 040 000 requests - gives responses, memory and cycle counts identical to the lane-ordered sequential reference, with write combining on and off.
* **Mutation testing**: 26 hand-written RTL bugs; **25 of 25 non-equivalent mutants killed** (by directed, unit, reset, system or replay tests); the 1 equivalent mutant (a stuck rotating lane pointer, which the architecture says is invisible) **survives**, as predicted. An earlier harness run that wrongly reported it killed was traced to build-directory collisions between concurrent mutants and fixed.
* **Synthesis structure (Yosys, generic)**: no latches/loops in 9 configurations; ~37 k generic cells at 8x8, 106 k at 16x16, 367 k at 32x32 (logic only).

## Quick start

Needs Python 3.8+ (standard library only), Verilator >= 5.0, GNU make and g++; Icarus Verilog 12 and Yosys 0.33 are optional (second simulator / synthesis check).

```bash
make pytest        # Python model tests                                  (~4 s)
make lint          # Verilator -Wall
make quick         # RTL vs model, 23 workloads, base configuration      (~25 s)
make soak          # prolonged contention + fairness                     (~45 s)
make verify        # everything: sweeps, Icarus, benches, soak           (~15 min on 4 cores)
make bench         # regenerate the benchmark data and docs/BENCHMARKS.md
make mutate        # mutation testing of the suite                       (~15 min)
```

Single configuration by hand:

```bash
python3 sim/run_regress.py --suite quick                 # build + replay + exact comparison
python3 sim/run_tests.py --only directed_base units      # self-checking benches
```

## Documentation map

| file | read it for |
|---|---|
| `docs/SEMANTICS.md` | **the contract**: operations, atomicity, ordering, return values, alignment, signedness, errors, reset |
| `docs/FENCES_AND_BARRIERS.md` | why barrier != memory ordering, the fence, litmus results |
| `docs/ARCHITECTURE.md` | microarchitecture, pipeline, arbitration algorithm and invariants, bank/atomic unit, mappings |
| `docs/INTEGRATION.md` | ports, timing, client rules, instantiation, sizing guidance |
| `docs/BENCHMARKS.md` | conflicts, latency, throughput, fairness, mappings (generated from `reports/`) |
| `docs/VERIFICATION.md` | strategy, results, mutation table, requirement -> evidence matrix, bug log (generated) |
| `docs/KNOWN_LIMITATIONS.md` | what is not claimed or not done |

## Relationship to the rest of the repository

This is a standalone block. The earlier `silicaflux-memorycore-sram` package defines a controller whose contract explicitly has *no* atomic read-modify-write (`docs/CONTRACT.md` O4); SFSM does not modify it, is not wired to it, and uses its own `sf_smem_*` prefix. No licence is asserted here.
