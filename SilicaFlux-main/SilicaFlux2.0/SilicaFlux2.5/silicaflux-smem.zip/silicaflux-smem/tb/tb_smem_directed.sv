// =============================================================================
// SilicaFlux Shared Memory :: tb_smem_directed
// Hand-written, self-checking tests.  Every expected value below was worked out BY
// HAND from docs/SEMANTICS.md (not produced by any model), so this bench is an
// oracle independent of the Python code.  Timing expectations that depend on which
// words share a bank are only checked for MAPPING == 0 (linear); data expectations
// hold for every mapping.
// Needs NL >= 8, NP >= 2, NB >= 8 and a capacity of at least 128 words.
// =============================================================================
`timescale 1ns/1ps

module tb_smem_directed;
  parameter int NL            = 8;
  parameter int NB            = 8;
  parameter int DEPTH         = 64;
  parameter int NP            = 2;
  parameter int REQ_DEPTH     = 2;
  parameter int RSP_DEPTH     = 4;
  parameter int TAGW          = 8;
  parameter int AW            = 16;
  parameter int MAPPING       = 0;
  parameter int BLK_LOG2      = 1;
  parameter int LANE_ARB      = 1;
  parameter int PORT_ARB      = 1;
  parameter int WRITE_COMBINE = 1;
  parameter int INIT_ON_RESET = 1;

  `include "tb_common.svh"

  localparam bit LIN = (MAPPING == 0) && (NB == 8);     // bank-conflict timing expectations assume 8 linear banks
  // latency of a request that needs d issue cycles on its worst bank
  function automatic integer lat(input integer d); lat = 3 + d; endfunction

  integer i, l, n, nacc, nsend;
  bit acc_now;
  reg [31:0] v;
  reg [31:0] exp_d [0:NL-1];

  function automatic [31:0] mask32(input [3:0] be);
    integer k;
    begin
      mask32 = 32'h0;
      for (k = 0; k < 4; k = k + 1) if (be[k]) mask32[8*k +: 8] = 8'hFF;
    end
  endfunction

  initial begin
    req_valid = '0; req_tag = '0; req_lane_valid = '0; req_op = '0; req_addr = '0;
    req_be = '0; req_wdata = '0; req_cmp = '0; rsp_ready = '1;
    repeat (4) @(posedge clk);
    @(negedge clk);
    rst_n = 1'b1;
    cyc = 0;
    if (INIT_ON_RESET != 0) begin
      #1;
      ck("init_busy right after reset", init_busy, 1'b1);
      ck("req_ready low during init", |req_ready, 1'b0);
    end
    wait_init;
    if (INIT_ON_RESET == 0) begin        // array contents are undefined: initialise what the tests use
      for (i = 0; i < CAPW; i = i + NL) begin
        clear_req(0);
        for (l = 0; l < NL; l = l + 1) if (i + l < CAPW) lane(0, l, OPST, wa(i + l), 4'hF, 32'h0, 0);
        xact(0, 8'h00);
      end
    end
    ck("req_ready after init", &req_ready, 1'b1);
    ck("quiescent after init", quiescent, 1'b1);

    // ---------------------------------------------------------------- D01 basic + byte enables
    section("D01 basic + byte enables");
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) lane(0, l, OPST, wa(l), 4'hF, 32'h1111_1111 * (l + 1), 0);
    xact(0, 8'h01);
    ck("D01 store tag", g_tag, 8'h01);
    ck("D01 store lane_valid", g_lv[7:0], 8'hFF);
    for (l = 0; l < 8; l = l + 1) begin ck("D01 store status", g_st[l], 0); ck("D01 store data is 0", g_data[l], 0); end
    if (LIN) ck("D01 store latency (all banks distinct)", g_lat, lat(1));
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) lane(0, l, OPLD, wa(l), 4'hF, 0, 0);
    xact(0, 8'h02);
    for (l = 0; l < 8; l = l + 1) ck("D01 load", g_data[l], 32'h1111_1111 * (l + 1));
    if (LIN) ck("D01 load latency", g_lat, lat(1));

    wr1(0, 32'hAABB_CCDD);
    clear_req(0); lane(0, 0, OPST, wa(0), 4'b0101, 32'h1122_3344, 0); xact(0, 8'h03);
    rd1(0, v); ck("D01 partial store 0101", v, 32'hAA22_CC44);
    clear_req(0); lane(0, 0, OPLD, wa(0), 4'b0011, 0, 0); xact(0, 8'h04);
    ck("D01 masked load 0011", g_data[0], 32'h0000_CC44);
    clear_req(0); lane(0, 0, OPLD, wa(0), 4'b1000, 0, 0); xact(0, 8'h05);
    ck("D01 masked load 1000", g_data[0], 32'hAA00_0000);

    // ---------------------------------------------------------------- D02 conflicting stores: highest lane wins per byte
    section("D02 conflicting stores: highest lane wins per byte");
    wr1(10, 32'h0);
    clear_req(0);
    lane(0, 0, OPST, wa(10), 4'b0011, 32'h0101_0101, 0);
    lane(0, 1, OPST, wa(10), 4'b0110, 32'h0202_0202, 0);
    lane(0, 2, OPST, wa(10), 4'b1000, 32'h0303_0303, 0);
    junk_lane(0, 3, OPST, wa(10), 4'hF, 32'hEEEE_EEEE);          // inactive: must not win
    lane(0, 4, OPST, wa(10), 4'b0001, 32'h0404_0404, 0);
    xact(0, 8'h10);
    ck("D02 lane_valid", g_lv[7:0], 8'b0001_0111);
    rd1(10, v);
    ck("D02 byte-wise highest lane wins", v, 32'h0302_0204);
    // the same request again, timing only
    wr1(10, 32'h0);
    clear_req(0);
    for (l = 0; l < 4; l = l + 1) lane(0, l, OPST, wa(10), 4'hF, 32'h0000_0010 * (l + 1), 0);
    xact(0, 8'h11);
    ck("D02 timing 4 same-word stores", g_lat, WRITE_COMBINE != 0 ? lat(1) : lat(4));
    rd1(10, v); ck("D02 full-word stores: highest lane wins", v, 32'h0000_0040);

    // ---------------------------------------------------------------- D03 broadcast read
    section("D03 broadcast read");
    wr1(20, 32'hDEAD_BEEF);
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) lane(0, l, OPLD, wa(20), (l == 1) ? 4'h1 : (l == 2) ? 4'hC : (l == 3) ? 4'hA : 4'hF, 0, 0);
    xact(0, 8'h20);
    ck("D03 broadcast lane0", g_data[0], 32'hDEAD_BEEF);
    ck("D03 broadcast lane1 be=0001", g_data[1], 32'h0000_00EF);
    ck("D03 broadcast lane2 be=1100", g_data[2], 32'hDEAD_0000);
    ck("D03 broadcast lane3 be=1010", g_data[3], 32'hDE00_BE00);
    ck("D03 broadcast lane7", g_data[7], 32'hDEAD_BEEF);
    ck("D03 broadcast is one bank access (latency)", g_lat, lat(1));

    // ---------------------------------------------------------------- D04 load/store order inside one request
    section("D04 load/store order inside one request");
    wr1(30, 32'h0000_1111);
    clear_req(0);
    lane(0, 0, OPLD, wa(30), 4'hF, 0, 0);
    lane(0, 1, OPST, wa(30), 4'hF, 32'h0000_2222, 0);
    lane(0, 2, OPLD, wa(30), 4'hF, 0, 0);
    lane(0, 3, OPST, wa(30), 4'h1, 32'h0000_00FF, 0);
    lane(0, 4, OPLD, wa(30), 4'hF, 0, 0);
    xact(0, 8'h30);
    ck("D04 lane0 load sees old", g_data[0], 32'h0000_1111);
    ck("D04 lane2 load sees lane1 store", g_data[2], 32'h0000_2222);
    ck("D04 lane4 load sees lane3 store", g_data[4], 32'h0000_22FF);
    ck("D04 timing: 5 alternating runs", g_lat, lat(5));
    rd1(30, v); ck("D04 final", v, 32'h0000_22FF);
    // loads of the same word that precede any writer are merged into one access
    clear_req(0);
    lane(0, 0, OPLD, wa(30), 4'hF, 0, 0); lane(0, 1, OPLD, wa(30), 4'hF, 0, 0);
    lane(0, 2, OPST, wa(30), 4'hF, 32'h7, 0);
    lane(0, 3, OPLD, wa(30), 4'hF, 0, 0); lane(0, 4, OPLD, wa(30), 4'hF, 0, 0);
    xact(0, 8'h31);
    ck("D04b lane1 (before writer)", g_data[1], 32'h0000_22FF);
    ck("D04b lane3 (after writer)", g_data[3], 32'h7);
    ck("D04b lane4 (after writer)", g_data[4], 32'h7);
    ck("D04b timing LD-run | ST | LD-run", g_lat, lat(3));

    // ---------------------------------------------------------------- D05 simultaneous atomic adds, one word
    section("D05 simultaneous atomic adds, one word");
    wr1(40, 32'd100);
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) lane(0, l, OPADD, wa(40), 4'hF, 32'd1, 0);
    xact(0, 8'h40);
    for (l = 0; l < 8; l = l + 1) ck("D05 old value in lane order", g_data[l], 100 + l);
    ck("D05 timing: one atomic per cycle", g_lat, lat(8));
    rd1(40, v); ck("D05 final", v, 32'd108);
    wr1(40, 32'h10);
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) lane(0, l, OPADD, wa(40), 4'hF, l + 1, 0);
    xact(0, 8'h41);
    exp_d[0] = 32'h10; exp_d[1] = 32'h11; exp_d[2] = 32'h13; exp_d[3] = 32'h16;
    exp_d[4] = 32'h1A; exp_d[5] = 32'h1F; exp_d[6] = 32'h25; exp_d[7] = 32'h2C;
    for (l = 0; l < 8; l = l + 1) ck("D05 distinct addends, prefix sums", g_data[l], exp_d[l]);
    rd1(40, v); ck("D05 distinct addends final", v, 32'h34);

    // ---------------------------------------------------------------- D06 wraparound / signedness
    section("D06 wraparound / signedness");
    wr1(41, 32'hFFFF_FFFF);
    clear_req(0);
    lane(0, 0, OPADD, wa(41), 4'hF, 32'h0000_0001, 0);   // FFFFFFFF + 1 -> 0
    lane(0, 1, OPADD, wa(41), 4'hF, 32'hFFFF_FFFF, 0);   // 0 + (-1) -> FFFFFFFF
    lane(0, 2, OPADD, wa(41), 4'hF, 32'h8000_0000, 0);   // FFFFFFFF + 80000000 -> 7FFFFFFF
    lane(0, 3, OPADD, wa(41), 4'hF, 32'h8000_0000, 0);   // 7FFFFFFF + 80000000 -> FFFFFFFF
    xact(0, 8'h60);
    ck("D06 lane0 old", g_data[0], 32'hFFFF_FFFF);
    ck("D06 lane1 old", g_data[1], 32'h0000_0000);
    ck("D06 lane2 old", g_data[2], 32'hFFFF_FFFF);
    ck("D06 lane3 old", g_data[3], 32'h7FFF_FFFF);
    rd1(41, v); ck("D06 final", v, 32'hFFFF_FFFF);

    // ---------------------------------------------------------------- D07 compare-and-swap
    section("D07 compare-and-swap");
    wr1(50, 32'd7);
    clear_req(0);
    lane(0, 0, OPCAS, wa(50), 4'hF, 32'd8,  32'd7);      // success 7 -> 8
    lane(0, 1, OPCAS, wa(50), 4'hF, 32'd99, 32'd7);      // fails (sees 8)
    lane(0, 2, OPCAS, wa(50), 4'hF, 32'd9,  32'd8);      // success 8 -> 9
    lane(0, 3, OPCAS, wa(50), 4'hF, 32'd9,  32'd9);      // success, same value
    lane(0, 4, OPADD, wa(50), 4'hF, 32'hFFFF_FFFF, 0);   // 9 + (-1) -> 8
    xact(0, 8'h70);
    ck("D07 lane0 old", g_data[0], 7);
    ck("D07 lane1 old (failed CAS)", g_data[1], 8);
    ck("D07 lane2 old", g_data[2], 8);
    ck("D07 lane3 old", g_data[3], 9);
    ck("D07 lane4 old", g_data[4], 9);
    rd1(50, v); ck("D07 final", v, 32'd8);
    wr1(51, 32'h8000_0000);                               // signedness: pure bit-pattern equality
    clear_req(0); lane(0, 0, OPCAS, wa(51), 4'hF, 32'd1, 32'h8000_0000); xact(0, 8'h71);
    ck("D07 CAS on 0x80000000 returns old", g_data[0], 32'h8000_0000);
    rd1(51, v); ck("D07 CAS 0x80000000 -> 1", v, 32'd1);
    wr1(51, 32'hFFFF_FFFF);
    clear_req(0); lane(0, 0, OPCAS, wa(51), 4'hF, 32'd5, 32'h0000_0000); xact(0, 8'h72);
    rd1(51, v); ck("D07 failed CAS leaves memory", v, 32'hFFFF_FFFF);

    // ---------------------------------------------------------------- D08 plain access interleaved with atomics
    section("D08 plain access interleaved with atomics");
    wr1(60, 32'h0);
    clear_req(0);
    lane(0, 0, OPST, wa(60), 4'hF, 32'd5, 0);
    lane(0, 1, OPADD, wa(60), 4'hF, 32'd1, 0);
    lane(0, 2, OPLD, wa(60), 4'hF, 0, 0);
    lane(0, 3, OPCAS, wa(60), 4'hF, 32'd100, 32'd6);
    lane(0, 4, OPLD, wa(60), 4'hF, 0, 0);
    xact(0, 8'h80);
    ck("D08 store returns 0", g_data[0], 0);
    ck("D08 add returns stored 5", g_data[1], 5);
    ck("D08 load sees 6", g_data[2], 6);
    ck("D08 cas returns 6", g_data[3], 6);
    ck("D08 load sees 100", g_data[4], 100);
    ck("D08 timing", g_lat, lat(5));
    rd1(60, v); ck("D08 final", v, 100);

    // ---------------------------------------------------------------- D09 atomics on different words
    section("D09 atomics on different words");
    for (i = 0; i < 4; i = i + 1) wr1(8 * i, 32'd10 * i);
    clear_req(0);
    for (l = 0; l < 4; l = l + 1) lane(0, l, OPADD, wa(8 * l), 4'hF, 32'd1, 0);
    xact(0, 8'h90);
    for (l = 0; l < 4; l = l + 1) ck("D09 old", g_data[l], 10 * l);
    if (LIN) ck("D09 four atomics, one bank (linear): 4 cycles", g_lat, lat(4));
    clear_req(0);
    for (l = 0; l < 4; l = l + 1) lane(0, l, OPADD, wa(l + 1), 4'hF, 32'd1, 0);
    xact(0, 8'h91);
    if (LIN) ck("D09 four atomics, four banks: 1 cycle", g_lat, lat(1));
    for (i = 0; i < 4; i = i + 1) begin rd1(8 * i, v); ck("D09 final", v, 10 * i + 1); end

    // ---------------------------------------------------------------- D10 rejected lanes
    section("D10 rejected lanes");
    wr1(70, 32'h0); wr1(72, 32'h0); wr1(73, 32'h5); wr1(74, 32'h6); wr1(75, 32'h7); wr1(76, 32'h8);
    clear_req(0);
    lane(0, 0, OPLD,  AW'(3),               4'hF, 0, 0);                  // misaligned
    lane(0, 1, OPST,  wa(CAPW),             4'hF, 32'hBAD1, 0);           // out of range
    lane(0, 2, 3'd5,  wa(72),               4'hF, 32'h1234, 0);           // reserved opcode
    lane(0, 3, OPADD, wa(73),               4'h7, 32'h1, 0);              // atomic with partial BE
    lane(0, 4, OPCAS, wa(74),               4'h0, 32'h9, 32'h6);          // atomic with BE = 0
    lane(0, 5, OPST,  wa(70),               4'hF, 32'hCAFE, 0);           // legal, must still execute
    lane(0, 6, 3'd7,  AW'(wa(75) | 3),      4'hF, 32'hDEAD, 0);           // BADOP wins over ALIGN
    lane(0, 7, OPLD,  AW'(wa(CAPW) | 1),    4'hF, 0, 0);                  // ALIGN wins over RANGE
    xact(0, 8'hA0);
    ck("D10 lane0 ALIGN", g_st[0], 3'd1);
    ck("D10 lane1 RANGE", g_st[1], 3'd2);
    ck("D10 lane2 BADOP", g_st[2], 3'd3);
    ck("D10 lane3 BE", g_st[3], 3'd4);
    ck("D10 lane4 BE", g_st[4], 3'd4);
    ck("D10 lane5 OK", g_st[5], 3'd0);
    ck("D10 lane6 BADOP over ALIGN", g_st[6], 3'd3);
    ck("D10 lane7 ALIGN over RANGE", g_st[7], 3'd1);
    for (l = 0; l < 8; l = l + 1) if (l != 5) ck("D10 error lane data is 0", g_data[l], 0);
    ck("D10 lane_valid all active", g_lv[7:0], 8'hFF);
    rd1(70, v); ck("D10 legal lane executed", v, 32'hCAFE);
    rd1(72, v); ck("D10 BADOP no side effect", v, 0);
    rd1(73, v); ck("D10 partial-BE ADD no side effect", v, 5);
    rd1(74, v); ck("D10 BE=0 CAS no side effect", v, 6);
    rd1(75, v); ck("D10 BADOP+ALIGN no side effect", v, 7);
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) lane(0, l, (l & 1) ? 3'd6 : OPLD, AW'(wa(l) + 2), 4'hF, 0, 0);
    xact(0, 8'hA1);
    ck("D10 all-rejected request latency (needs no array access)", g_lat, lat(1));
    // operand on error lanes is ignored: a rejected ADD never touches memory
    wr1(77, 32'h55);
    clear_req(0); lane(0, 0, OPADD, wa(77), 4'hE, 32'h1, 0); xact(0, 8'hA2);
    rd1(77, v); ck("D10 rejected ADD (be=E) leaves word", v, 32'h55);

    // ---------------------------------------------------------------- D11 inactive lanes
    section("D11 inactive lanes");
    wr1(80, 32'h0); wr1(81, 32'h0);
    clear_req(0);
    junk_lane(0, 0, OPADD, wa(80), 4'hF, 32'h1);
    junk_lane(0, 1, OPST,  wa(80), 4'hF, 32'h2);
    lane(0, 2, OPADD, wa(81), 4'hF, 32'd9, 0);
    junk_lane(0, 3, 3'd6,  AW'(5),  4'hF, 32'h3);              // junk bad opcode + misaligned
    junk_lane(0, 4, OPLD,  wa(CAPW + 4), 4'hF, 32'h4);         // junk out of range
    lane(0, 5, OPLD, wa(81), 4'hF, 0, 0);
    junk_lane(0, 6, OPCAS, wa(81), 4'h1, 32'h5);
    junk_lane(0, 7, OPADD, wa(81), 4'hF, 32'h6);
    xact(0, 8'hB0);
    ck("D11 lane_valid mask", g_lv[7:0], 8'b0010_0100);
    ck("D11 lane2 old", g_data[2], 0);
    ck("D11 lane5 sees lane2's add", g_data[5], 9);
    for (l = 0; l < 8; l = l + 1) if (l != 2 && l != 5) begin ck("D11 inactive status", g_st[l], 0); ck("D11 inactive data", g_data[l], 0); end
    rd1(80, v); ck("D11 inactive ADD/ST had no effect", v, 0);
    rd1(81, v); ck("D11 only the active ADD applied", v, 9);
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) junk_lane(0, l, OPADD, wa(80), 4'hF, 32'h1);
    xact(0, 8'hB1);
    ck("D11 all-inactive request still gets a response", g_lv[7:0], 8'h00);
    ck("D11 all-inactive latency", g_lat, lat(1));
    rd1(80, v); ck("D11 all-inactive: no effect", v, 0);

    // ---------------------------------------------------------------- D12 byte enable 0 = accepted no-op
    section("D12 byte enable 0 = accepted no-op");
    for (i = 0; i < 8; i = i + 1) wr1(8 * i + 1, 32'hF00D_0000 + i);
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) lane(0, l, OPLD, wa(8 * l + 1), 4'h0, 0, 0);
    xact(0, 8'hC0);
    for (l = 0; l < 8; l = l + 1) begin ck("D12 be=0 load data", g_data[l], 0); ck("D12 be=0 load status", g_st[l], 0); end
    ck("D12 be=0 loads cost no array cycles (8 same-bank words)", g_lat, lat(1));
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) lane(0, l, OPST, wa(8 * l + 1), 4'h0, 32'hFFFF_FFFF, 0);
    xact(0, 8'hC1);
    ck("D12 be=0 stores cost no array cycles", g_lat, lat(1));
    for (i = 0; i < 8; i = i + 1) begin rd1(8 * i + 1, v); ck("D12 be=0 store did not write", v, 32'hF00D_0000 + i); end

    // ---------------------------------------------------------------- D13 latency / conflict timing (linear mapping)
    section("D13 latency / conflict timing (linear mapping)");
    if (LIN) begin
      for (i = 0; i < 8; i = i + 1) begin
        clear_req(0);
        for (l = 0; l < 8; l = l + 1) lane(0, l, OPLD, wa(l * (1 << i > 8 ? 8 : (1 << i))), 4'hF, 0, 0);
        xact(0, 8'hD0 + i);
        // stride 1,2,4,8,8,8,8,8 words with NB = 8 banks: conflict degree 1,2,4,8,...
        ck("D13 stride conflict degree", g_lat, lat((i == 0) ? 1 : (i == 1) ? 2 : (i == 2) ? 4 : 8));
      end
      clear_req(0);
      for (l = 0; l < 8; l = l + 1) lane(0, l, OPLD, wa(6), 4'hF, 0, 0);
      xact(0, 8'hE0);
      ck("D13 broadcast latency", g_lat, lat(1));
      clear_req(0);
      for (l = 0; l < 8; l = l + 1) lane(0, l, OPST, wa(6), 4'hF, l, 0);
      xact(0, 8'hE1);
      ck("D13 8 same-word stores", g_lat, WRITE_COMBINE != 0 ? lat(1) : lat(8));
    end

    // ---------------------------------------------------------------- D14 response order, tags, back-to-back
    section("D14 response order, tags, back-to-back");
    for (i = 0; i < 8; i = i + 1) wr1(100 + i, 32'hB000_0000 + i);
    rsp_ready = '0;                                              // hold the consumer
    nsend = (REQ_DEPTH + RSP_DEPTH < 4) ? (REQ_DEPTH + RSP_DEPTH) : 4;     // what the buffers can hold
    for (i = 0; i < nsend; i = i + 1) begin
      clear_req(0);
      for (l = 0; l < 8; l = l + 1) lane(0, l, OPLD, wa(100 + (l + i) % 8), 4'hF, 0, 0);
      send(0, 8'hF0 + i);
    end
    repeat (12) tick;
    rsp_ready = '1;
    for (i = 0; i < nsend; i = i + 1) begin
      recv(0);
      ck("D14 tags return in request order", g_tag, 8'hF0 + i);
      for (l = 0; l < 8; l = l + 1) ck("D14 payload belongs to its request", g_data[l], 32'hB000_0000 + (l + i) % 8);
    end

    // ---------------------------------------------------------------- D15 bounded buffering, no head-of-line blocking
    section("D15 bounded buffering, no head-of-line blocking");
    rsp_ready[0] = 1'b0;                                         // port 0 stops consuming responses
    nacc = 0;
    clear_req(0); lane(0, 0, OPLD, wa(100), 4'hF, 0, 0);
    req_tag[0 +: TAGW] = 8'h40;
    req_valid[0] = 1'b1;
    for (i = 0; i < 60; i = i + 1) begin                         // keep presenting; count what is accepted
      #1;
      acc_now = req_ready[0];                                    // accepted by the coming posedge
      tick;                                                      // (payload must stay put until then)
      if (acc_now) begin
        nacc = nacc + 1;
        clear_req(0); lane(0, 0, OPLD, wa(100 + (nacc % 8)), 4'hF, 0, 0);   // stage the next request
        req_tag[0 +: TAGW] = 8'h40 + nacc;
      end
    end
    req_valid[0] = 1'b0;
    repeat (20) tick;
    ck("D15 port 0 accepted exactly REQ_DEPTH + RSP_DEPTH requests", nacc, REQ_DEPTH + RSP_DEPTH);
    ck("D15 outstanding[0]", outstanding[0 +: OW], REQ_DEPTH + RSP_DEPTH);
    ck("D15 port_idle[0] low", port_idle[0], 1'b0);
    ck("D15 req_ready[0] low while buffers are full", req_ready[0], 1'b0);
    ck("D15 quiescent low", quiescent, 1'b0);
    // port 1 must keep working at full speed meanwhile
    n = 0;
    for (i = 0; i < 12; i = i + 1) begin
      clear_req(1);
      lane(1, 0, OPADD, wa(120), 4'hF, 32'd1, 0);
      send(1, 8'h80 + i);
      recv(1);
      ck("D15 port 1 unaffected by stalled port 0: old value", g_data[0], i);
    end
    clear_req(1); lane(1, 0, OPLD, wa(120), 4'hF, 0, 0); xact(1, 8'h7F);   // port 0 is still stalled: read via port 1
    ck("D15 port 1 sum", g_data[0], 12);
    rsp_ready[0] = 1'b1;
    for (i = 0; i < REQ_DEPTH + RSP_DEPTH; i = i + 1) begin
      recv(0);
      ck("D15 stalled responses arrive in order", g_tag, 8'h40 + i);
      ck("D15 stalled response data", g_data[0], 32'hB000_0000 + (i % 8));
    end
    repeat (4) tick;
    ck("D15 drained: quiescent", quiescent, 1'b1);
    ck("D15 drained: outstanding[0]", outstanding[0 +: OW], 0);

    // ---------------------------------------------------------------- D16 perf counters sanity (independent counts)
    section("D16 perf counters sanity (independent counts)");
    // (counters were running since reset; just check monotone consistency)
    ck("D16 requests counter >= 1", perf[1*32 +: 32] > 0, 1'b1);
    ck("D16 error-lane counter counts D10/D11 rejects (>= 8)", perf[6*32 +: 32] >= 8, 1'b1);

    summary("tb_smem_directed");
    $finish;
  end
endmodule
