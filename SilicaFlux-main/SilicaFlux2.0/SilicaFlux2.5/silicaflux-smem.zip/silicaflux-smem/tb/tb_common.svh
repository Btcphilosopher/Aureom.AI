// =============================================================================
// SilicaFlux Shared Memory :: tb_common.svh
// Shared plumbing for the directed / reset / system benches.  `include`d INSIDE a
// module body that declares these parameters first:
//   NL NB DEPTH NP REQ_DEPTH RSP_DEPTH TAGW AW MAPPING BLK_LOG2 LANE_ARB PORT_ARB
//   WRITE_COMBINE INIT_ON_RESET
//
// Discipline (same as tb_smem_replay.sv): a SINGLE process does everything at the
// negedge - sample, drive, count cycles.  `cyc` is the index of the negedge, and a
// request driven at negedge c is accepted by posedge c if req_ready was high.
//   latency = (cycle the response is first visible) - (accept cycle)   [LAT_MIN = 4]
// =============================================================================
  localparam int OW   = $clog2(REQ_DEPTH + RSP_DEPTH + 2);
  localparam int NCNT = 8 + 2*NP + NB;
  localparam int CAPW = NB * DEPTH;

  reg clk   = 1'b0;
  reg rst_n = 1'b0;
  always #5 clk = ~clk;

  reg  [NP-1:0]          req_valid;
  wire [NP-1:0]          req_ready;
  reg  [NP*TAGW-1:0]     req_tag;
  reg  [NP*NL-1:0]       req_lane_valid;
  reg  [NP*NL*3-1:0]     req_op;
  reg  [NP*NL*AW-1:0]    req_addr;
  reg  [NP*NL*4-1:0]     req_be;
  reg  [NP*NL*32-1:0]    req_wdata, req_cmp;
  wire [NP-1:0]          rsp_valid;
  reg  [NP-1:0]          rsp_ready;
  wire [NP*TAGW-1:0]     rsp_tag;
  wire [NP*NL-1:0]       rsp_lane_valid;
  wire [NP*NL*3-1:0]     rsp_status;
  wire [NP*NL*32-1:0]    rsp_data;
  wire                   init_busy;
  wire [NP*OW-1:0]       outstanding;
  wire [NP-1:0]          port_idle;
  wire                   quiescent;
  wire [NCNT*32-1:0]     perf;

  sf_smem_top #(.NL(NL), .NB(NB), .DEPTH(DEPTH), .NP(NP), .REQ_DEPTH(REQ_DEPTH),
                .RSP_DEPTH(RSP_DEPTH), .TAGW(TAGW), .AW(AW), .MAPPING(MAPPING),
                .BLK_LOG2(BLK_LOG2), .LANE_ARB(LANE_ARB), .PORT_ARB(PORT_ARB),
                .WRITE_COMBINE(WRITE_COMBINE), .INIT_ON_RESET(INIT_ON_RESET), .PERF_EN(1)) dut (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_ready(req_ready), .req_tag(req_tag),
    .req_lane_valid(req_lane_valid), .req_op(req_op), .req_addr(req_addr),
    .req_be(req_be), .req_wdata(req_wdata), .req_cmp(req_cmp),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_tag(rsp_tag),
    .rsp_lane_valid(rsp_lane_valid), .rsp_status(rsp_status), .rsp_data(rsp_data),
    .init_busy(init_busy), .outstanding(outstanding), .port_idle(port_idle),
    .quiescent(quiescent), .perf(perf));

  localparam [2:0] OPLD = 3'd0, OPST = 3'd1, OPADD = 3'd2, OPCAS = 3'd3;

  integer cyc    = 0;
  integer errors = 0;
  integer checks = 0;

  // global watchdog: no bench may ever hang a regression run
  localparam integer WATCHDOG_NS = 40000000;      // 4,000,000 cycles
  initial begin
    #(WATCHDOG_NS);
    $display("TB ERROR: watchdog expired at cycle %0d", cyc);
    $display("RESULT: watchdog checks=%0d errors=%0d FAIL", checks, errors + 1);
    $finish;
  end

  // last captured response
  reg [TAGW-1:0]  g_tag;
  reg [NL-1:0]    g_lv;
  reg [2:0]       g_st   [0:NL-1];
  reg [31:0]      g_data [0:NL-1];
  integer         g_acc_cyc, g_rsp_cyc, g_lat;

  task automatic section(input string name);
    begin
      if ($test$plusargs("VERBOSE")) $display("-- %s (cycle %0d, checks %0d, errors %0d)", name, cyc, checks, errors);
    end
  endtask

  task automatic tick;
    begin @(negedge clk); cyc = cyc + 1; end
  endtask

  task automatic fail(input string msg);
    begin
      errors = errors + 1;
      if (errors <= 40) $display("TB ERROR @cycle %0d: %s", cyc, msg);
    end
  endtask

  task automatic ck(input string what, input [63:0] got, input [63:0] exp);
    begin
      checks = checks + 1;
      if (got !== exp) fail($sformatf("%s: got %0h expected %0h", what, got, exp));
    end
  endtask

  task automatic ck_true(input string what, input bit cond);
    begin
      checks = checks + 1;
      if (!cond) fail(what);
    end
  endtask

  // ---- request staging ----------------------------------------------------------------
  task automatic clear_req(input integer p);
    integer l;
    begin
      for (l = 0; l < NL; l = l + 1) begin
        req_lane_valid[p*NL + l]          = 1'b0;
        req_op  [(p*NL+l)*3  +: 3]        = 3'd0;
        req_addr[(p*NL+l)*AW +: AW]       = '0;
        req_be  [(p*NL+l)*4  +: 4]        = 4'h0;
        req_wdata[(p*NL+l)*32 +: 32]      = 32'h0;
        req_cmp [(p*NL+l)*32 +: 32]       = 32'h0;
      end
    end
  endtask

  // byte address of word w
  function automatic [AW-1:0] wa(input integer w);
    wa = AW'(w * 4);
  endfunction

  task automatic lane(input integer p, input integer l, input [2:0] op, input [AW-1:0] addr,
                      input [3:0] be, input [31:0] wd, input [31:0] cm);
    begin
      req_lane_valid[p*NL + l]          = 1'b1;
      req_op  [(p*NL+l)*3  +: 3]        = op;
      req_addr[(p*NL+l)*AW +: AW]       = addr;
      req_be  [(p*NL+l)*4  +: 4]        = be;
      req_wdata[(p*NL+l)*32 +: 32]      = wd;
      req_cmp [(p*NL+l)*32 +: 32]       = cm;
    end
  endtask

  // an INACTIVE lane that carries junk which must be ignored
  task automatic junk_lane(input integer p, input integer l, input [2:0] op, input [AW-1:0] addr,
                           input [3:0] be, input [31:0] wd);
    begin
      lane(p, l, op, addr, be, wd, wd ^ 32'hFFFF_FFFF);
      req_lane_valid[p*NL + l] = 1'b0;
    end
  endtask

  // present the staged request on port p; returns after the accepting posedge
  task automatic send(input integer p, input [TAGW-1:0] tag);
    begin
      req_tag[p*TAGW +: TAGW] = tag;
      req_valid[p] = 1'b1;
      #1;
      while (!req_ready[p]) begin tick; #1; end
      g_acc_cyc = cyc;
      tick;
      req_valid[p] = 1'b0;
      #1;
    end
  endtask

  // wait for (and consume) the next response of port p
  task automatic recv(input integer p);
    integer l;
    begin
      #1;
      while (!(rsp_valid[p] && rsp_ready[p])) begin tick; #1; end
      g_rsp_cyc = cyc;
      g_tag = rsp_tag[p*TAGW +: TAGW];
      g_lv  = rsp_lane_valid[p*NL +: NL];
      for (l = 0; l < NL; l = l + 1) begin
        g_st[l]   = rsp_status[(p*NL+l)*3 +: 3];
        g_data[l] = rsp_data[(p*NL+l)*32 +: 32];
      end
      g_lat = g_rsp_cyc - g_acc_cyc;
      tick;
    end
  endtask

  task automatic xact(input integer p, input [TAGW-1:0] tag);
    begin send(p, tag); recv(p); end
  endtask

  // convenience: single-lane word accesses on port 0
  task automatic wr1(input integer w, input [31:0] v);
    begin clear_req(0); lane(0, 0, OPST, wa(w), 4'hF, v, 0); xact(0, 8'h5A); end
  endtask

  task automatic rd1(input integer w, output [31:0] v);
    begin clear_req(0); lane(0, 0, OPLD, wa(w), 4'hF, 0, 0); xact(0, 8'hA5); v = g_data[0]; end
  endtask

  task automatic wait_init;
    begin
      #1;
      while (init_busy) begin tick; #1; end
    end
  endtask

  task automatic summary(input string name);
    begin
      $display("RESULT: %s checks=%0d errors=%0d %s", name, checks, errors, errors == 0 ? "PASS" : "FAIL");
    end
  endtask
