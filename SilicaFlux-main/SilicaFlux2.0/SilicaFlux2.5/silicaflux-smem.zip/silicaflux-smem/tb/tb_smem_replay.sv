// =============================================================================
// SilicaFlux Shared Memory :: tb_smem_replay
// Trace-driven, cycle-exact client for sf_smem_top.  Replays per-port trace files
// written by py/sfsm/trace.py, logs every accept / response with its cycle, reads
// the memory back through port 0 (architectural view) and dumps the bank arrays
// (physical view).  Expected values live in the Python models; this bench only
// checks protocol invariants itself:
//   * req_ready is low during the init sweep
//   * a response that was not accepted stays valid and unchanged
//   * outstanding[p] == accepted - consumed, every cycle
//   * no X on ports (matters under Icarus; Verilator is two-state)
//   * quiescent / port_idle after drain
// Plusargs:  +TRACE=<prefix>  +OUT=<log file>  [+NOREADBACK] [+PHYS] [+MAXCYC=n]
// Client protocol: see py/sfsm/cycle.py (docstring) - the two must stay identical.
//
// Race-free by construction.  Verilator and Icarus schedule a testbench process
// that wakes on the design's own clock edge differently (found the hard way: a
// bench NBA issued at the posedge was seen by the design's flops at that same
// edge under Verilator).  So the bench does EVERYTHING at the negedge: sample the
// stable design outputs, drive the inputs for the coming posedge, and derive the
// events of that posedge (accept = valid & ready, pop = rsp_valid & rsp_ready)
// from the pair.  Nothing the bench does coincides with a clock edge.
// Cycle `c` is the interval ended by the c-th posedge with rst_n = 1.
// =============================================================================
`timescale 1ns/1ps

module tb_smem_replay;
  parameter int NL            = 8;
  parameter int NB            = 8;
  parameter int DEPTH         = 256;
  parameter int NP            = 2;
  parameter int REQ_DEPTH     = 2;
  parameter int RSP_DEPTH     = 4;
  parameter int TAGW          = 8;
  parameter int AW            = 32;
  parameter int MAPPING       = 0;
  parameter int BLK_LOG2      = 1;
  parameter int LANE_ARB      = 1;
  parameter int PORT_ARB      = 1;
  parameter int WRITE_COMBINE = 1;
  parameter int INIT_ON_RESET = 1;

  localparam int NCNT = 8 + 2*NP + NB;
  localparam int OW   = $clog2(REQ_DEPTH + RSP_DEPTH + 2);

  reg clk   = 1'b0;
  reg rst_n = 1'b0;
  always #5 clk = ~clk;

  reg  [NP-1:0]          req_valid;
  wire [NP-1:0]          req_ready;
  reg  [NP*TAGW-1:0]     req_tag;
  reg  [NP*NL-1:0]       req_lane_valid;
  reg  [NP*NL*3-1:0]     req_op;
  reg  [NP*NL*AW-1:0]    req_addr;
  reg  [NP*NL*4-1:0]     req_be;
  reg  [NP*NL*32-1:0]    req_wdata, req_cmp;
  wire [NP-1:0]          rsp_valid;
  reg  [NP-1:0]          rsp_ready;
  wire [NP*TAGW-1:0]     rsp_tag;
  wire [NP*NL-1:0]       rsp_lane_valid;
  wire [NP*NL*3-1:0]     rsp_status;
  wire [NP*NL*32-1:0]    rsp_data;
  wire                   init_busy;
  wire [NP*OW-1:0]       outstanding;
  wire [NP-1:0]          port_idle;
  wire                   quiescent;
  wire [NCNT*32-1:0]     perf;

  sf_smem_top #(.NL(NL), .NB(NB), .DEPTH(DEPTH), .NP(NP), .REQ_DEPTH(REQ_DEPTH),
                .RSP_DEPTH(RSP_DEPTH), .TAGW(TAGW), .AW(AW), .MAPPING(MAPPING),
                .BLK_LOG2(BLK_LOG2), .LANE_ARB(LANE_ARB), .PORT_ARB(PORT_ARB),
                .WRITE_COMBINE(WRITE_COMBINE), .INIT_ON_RESET(INIT_ON_RESET), .PERF_EN(1)) dut (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_ready(req_ready), .req_tag(req_tag),
    .req_lane_valid(req_lane_valid), .req_op(req_op), .req_addr(req_addr),
    .req_be(req_be), .req_wdata(req_wdata), .req_cmp(req_cmp),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_tag(rsp_tag),
    .rsp_lane_valid(rsp_lane_valid), .rsp_status(rsp_status), .rsp_data(rsp_data),
    .init_busy(init_busy), .outstanding(outstanding), .port_idle(port_idle),
    .quiescent(quiescent), .perf(perf));

  // ---- physical dump (backdoor), triggered by dump_phys ----------------------------
  reg dump_phys = 1'b0;
  integer fo;
  generate
    for (genvar gb = 0; gb < NB; gb++) begin : g_phys
      always @(posedge dump_phys) begin
        for (int r = 0; r < DEPTH; r++)
          $fdisplay(fo, "PHY %0d %0d %08h", gb, r, dut.g_bank[gb].u_bank.mem[r]);
      end
    end
  endgenerate

  // ---- bookkeeping -------------------------------------------------------------------
  integer fd      [0:NP-1];
  integer n_req   [0:NP-1];
  integer per_p   [0:NP-1];
  integer duty_p  [0:NP-1];
  integer acc_n   [0:NP-1];
  integer rsp_n   [0:NP-1];
  integer wcnt    [0:NP-1];
  reg              prev_v   [0:NP-1];
  reg              prev_r   [0:NP-1];
  reg [TAGW+NL+NL*3+NL*32-1:0] prev_pl [0:NP-1];
  reg [TAGW+NL+NL*3+NL*32-1:0] cur_pl;
  reg [OW-1:0]     exp_out;

  // shadow (next-cycle) copies of everything the bench drives
  reg              nx_valid [0:NP-1];
  reg              nx_load  [0:NP-1];
  reg              nx_rdy   [0:NP-1];
  reg [TAGW-1:0]   nx_tag   [0:NP-1];
  reg [NL-1:0]     nx_lv    [0:NP-1];
  reg [NL*3-1:0]   nx_op    [0:NP-1];
  reg [NL*AW-1:0]  nx_addr  [0:NP-1];
  reg [NL*4-1:0]   nx_be    [0:NP-1];
  reg [NL*32-1:0]  nx_wd    [0:NP-1];
  reg [NL*32-1:0]  nx_cmp   [0:NP-1];

  integer cyc, errors, r_, p, l, base, cap_words;
  reg [31:0] t_gap, t_tag, tv, top, tbe, tad, twd, tcm;
  reg a_ok [0:NP-1];
  reg r_ok [0:NP-1];
  bit do_rb, do_phys;
  string prefix, outfile, fname;
  integer maxcyc;
  bit all_done;

  task automatic err(input string msg);
    begin
      errors = errors + 1;
      if (errors <= 20) $display("TB ERROR @cycle %0d: %s", cyc, msg);
    end
  endtask

  // read the next request of port q from its trace into the shadow registers
  task automatic fetch(input integer q);
    integer ll, rr;
    begin
      rr = $fscanf(fd[q], "%h %h", t_gap, t_tag);
      nx_tag[q] = t_tag[TAGW-1:0];
      for (ll = 0; ll < NL; ll = ll + 1) begin
        rr = $fscanf(fd[q], "%h %h %h %h %h %h", tv, top, tbe, tad, twd, tcm);
        nx_lv  [q][ll]                = tv[0];
        nx_op  [q][ll*3 +: 3]         = top[2:0];
        nx_addr[q][ll*AW +: AW]       = tad[AW-1:0];
        nx_be  [q][ll*4 +: 4]         = tbe[3:0];
        nx_wd  [q][ll*32 +: 32]       = twd;
        nx_cmp [q][ll*32 +: 32]       = tcm;
      end
      nx_load[q] = 1'b1;
      if (t_gap == 0) begin
        nx_valid[q] = 1'b1;
        wcnt[q] = 0;
      end else begin
        nx_valid[q] = 1'b0;
        wcnt[q] = t_gap;
      end
    end
  endtask

  // drive the shadow registers into the DUT inputs (called at a negedge)
  task automatic drive;
    integer q;
    begin
      for (q = 0; q < NP; q = q + 1) begin
        req_valid[q] = nx_valid[q];
        rsp_ready[q] = nx_rdy[q];
        if (nx_load[q]) begin
          req_tag       [q*TAGW +: TAGW]   = nx_tag[q];
          req_lane_valid[q*NL +: NL]       = nx_lv[q];
          req_op        [q*NL*3 +: NL*3]   = nx_op[q];
          req_addr      [q*NL*AW +: NL*AW] = nx_addr[q];
          req_be        [q*NL*4 +: NL*4]   = nx_be[q];
          req_wdata     [q*NL*32 +: NL*32] = nx_wd[q];
          req_cmp       [q*NL*32 +: NL*32] = nx_cmp[q];
          nx_load[q] = 1'b0;
        end
      end
    end
  endtask

  task automatic log_rsp(input integer q);
    integer ll;
    begin
      $fwrite(fo, "RSP %0d %0d %0d %0h %0h", q, rsp_n[q], cyc, rsp_tag[q*TAGW +: TAGW],
              rsp_lane_valid[q*NL +: NL]);
      for (ll = 0; ll < NL; ll = ll + 1) $fwrite(fo, " %0h", rsp_status[(q*NL+ll)*3 +: 3]);
      for (ll = 0; ll < NL; ll = ll + 1) $fwrite(fo, " %08h", rsp_data[(q*NL+ll)*32 +: 32]);
      $fwrite(fo, "\n");
    end
  endtask

  // negedge before posedge `cyc`: sample outputs, derive that posedge's events, plan cyc+1
  task automatic sample_and_plan;
    integer q;
    begin
      if (init_busy && (|req_ready)) err("req_ready high during init sweep");
      if ($isunknown(req_ready))   err("X/Z on req_ready");
      if ($isunknown(rsp_valid))   err("X/Z on rsp_valid");
      if ($isunknown(init_busy))   err("X/Z on init_busy");
      if ($isunknown(outstanding)) err("X/Z on outstanding");
      if ($isunknown(port_idle))   err("X/Z on port_idle");
      if ($isunknown(quiescent))   err("X/Z on quiescent");
      for (q = 0; q < NP; q = q + 1) begin
        a_ok[q] = req_valid[q] && req_ready[q];
        r_ok[q] = rsp_valid[q] && rsp_ready[q];
        exp_out = OW'(acc_n[q] - rsp_n[q]);
        if (outstanding[q*OW +: OW] !== exp_out)
          err($sformatf("outstanding[%0d]=%0d expected %0d", q, outstanding[q*OW +: OW], exp_out));
        if (port_idle[q] !== (exp_out == 0)) err("port_idle inconsistent with outstanding");
        cur_pl = {rsp_tag[q*TAGW +: TAGW], rsp_lane_valid[q*NL +: NL],
                  rsp_status[q*NL*3 +: NL*3], rsp_data[q*NL*32 +: NL*32]};
        if (rsp_valid[q] && $isunknown(cur_pl)) err($sformatf("X/Z in response payload port %0d", q));
        if (prev_v[q] && !prev_r[q]) begin
          if (!rsp_valid[q])             err($sformatf("response dropped without being accepted, port %0d", q));
          else if (cur_pl !== prev_pl[q]) err($sformatf("response changed while stalled, port %0d", q));
        end
        prev_v[q]  = rsp_valid[q];
        prev_r[q]  = rsp_ready[q];
        prev_pl[q] = cur_pl;
        if (a_ok[q]) $fdisplay(fo, "ACC %0d %0d %0d", q, acc_n[q], cyc);
        if (r_ok[q]) log_rsp(q);
      end
      for (q = 0; q < NP; q = q + 1) begin
        if (a_ok[q]) acc_n[q] = acc_n[q] + 1;
        if (r_ok[q]) rsp_n[q] = rsp_n[q] + 1;
      end
      // plan the next cycle
      for (q = 0; q < NP; q = q + 1) begin
        nx_valid[q] = req_valid[q];
        if (a_ok[q]) begin
          if (acc_n[q] < n_req[q]) fetch(q);
          else                     nx_valid[q] = 1'b0;
        end else if (!req_valid[q] && wcnt[q] > 0) begin
          wcnt[q] = wcnt[q] - 1;
          if (wcnt[q] == 0) nx_valid[q] = 1'b1;
        end
        nx_rdy[q] = ((cyc + 1) % per_p[q]) < duty_p[q];
      end
    end
  endtask

  // ---- global watchdog (covers the drain, read-back and dump phases as well) -------------
  initial begin : watchdog
    integer wm;
    wm = 5000000;
    void'($value$plusargs("MAXCYC=%d", wm));
    #(((wm + 2000) + 60 * (NB * DEPTH / NL + 16)) * 10);
    $display("TB ERROR: watchdog expired at cycle %0d", cyc);
    $display("RESULT: tb_smem_replay cycles=%0d errors=%0d FAIL (watchdog)", cyc, errors + 1);
    $finish;
  end

  // ---- main sequence -------------------------------------------------------------------
  initial begin
    errors = 0; cyc = 0; all_done = 0;
    cap_words = NB * DEPTH;
    maxcyc = 5000000;
    if (!$value$plusargs("TRACE=%s", prefix)) begin $display("TB FATAL: +TRACE missing"); $finish; end
    if (!$value$plusargs("OUT=%s", outfile))  begin $display("TB FATAL: +OUT missing");   $finish; end
    void'($value$plusargs("MAXCYC=%d", maxcyc));
    do_rb   = !$test$plusargs("NOREADBACK");
    do_phys = $test$plusargs("PHYS");
    fo = $fopen(outfile, "w");

    req_valid = '0; req_tag = '0; req_lane_valid = '0; req_op = '0; req_addr = '0;
    req_be = '0; req_wdata = '0; req_cmp = '0; rsp_ready = '0;

    for (p = 0; p < NP; p = p + 1) begin
      $sformat(fname, "%s.p%0d.trace", prefix, p);
      fd[p] = $fopen(fname, "r");
      if (fd[p] == 0) begin $display("TB FATAL: cannot open %s", fname); $finish; end
      r_ = $fscanf(fd[p], "%h %h %h", n_req[p], per_p[p], duty_p[p]);
      acc_n[p] = 0; rsp_n[p] = 0; wcnt[p] = 0;
      prev_v[p] = 0; prev_r[p] = 0; prev_pl[p] = '0;
      nx_valid[p] = 0; nx_load[p] = 0; nx_rdy[p] = 0;
      nx_tag[p] = '0; nx_lv[p] = '0; nx_op[p] = '0; nx_addr[p] = '0; nx_be[p] = '0;
      nx_wd[p] = '0; nx_cmp[p] = '0;
    end

    repeat (4) @(posedge clk);
    @(negedge clk);
    // ---- release reset: this negedge precedes posedge 0 (cycle 0) ----
    rst_n = 1'b1;
    for (p = 0; p < NP; p = p + 1) begin
      if (n_req[p] > 0) fetch(p);
      nx_rdy[p] = (0 % per_p[p]) < duty_p[p];
    end
    cyc = 0;
    while (!all_done) begin
      drive;                                // inputs seen by posedge `cyc`
      #1;
      sample_and_plan;
      all_done = 1;
      for (p = 0; p < NP; p = p + 1)
        if (rsp_n[p] < n_req[p]) all_done = 0;
      if (cyc > maxcyc) begin
        err("timeout - model did not drain");
        all_done = 1;
      end
      if (!all_done) begin
        @(negedge clk);
        cyc = cyc + 1;
      end
    end
    $fdisplay(fo, "DONE %0d", cyc);

    // ---- drain checks, performance counters ----
    @(negedge clk);
    for (p = 0; p < NP; p = p + 1) req_valid[p] = 1'b0;
    rsp_ready = '1;
    repeat (4) @(negedge clk);
    if (!quiescent || !(&port_idle)) err("not quiescent after drain");
    for (p = 0; p < NCNT; p = p + 1) $fdisplay(fo, "PERF %0d %0h", p, perf[p*32 +: 32]);

    // ---- architectural read-back through port 0 (rsp_ready is 1 on every port) ----
    if (do_rb) begin
      for (base = 0; base < cap_words; base = base + NL) begin
        for (l = 0; l < NL; l = l + 1) begin
          req_lane_valid[l]       = (base + l) < cap_words;
          req_op [l*3 +: 3]       = 3'd0;
          req_be [l*4 +: 4]       = 4'hF;
          req_addr[l*AW +: AW]    = AW'((base + l) * 4);
          req_wdata[l*32 +: 32]   = 32'h0;
          req_cmp[l*32 +: 32]     = 32'h0;
        end
        req_tag[0 +: TAGW] = TAGW'(base);
        req_valid[0] = 1'b1;
        #1;
        while (!req_ready[0]) begin @(negedge clk); #1; end   // posedge between negedges accepts
        @(negedge clk);
        req_valid[0] = 1'b0;
        #1;
        while (!rsp_valid[0]) begin @(negedge clk); #1; end
        for (l = 0; l < NL; l = l + 1)
          if ((base + l) < cap_words)
            $fdisplay(fo, "MEM %0d %0h", base + l, rsp_data[l*32 +: 32]);
        @(negedge clk);
      end
      repeat (2) @(negedge clk);
    end
    if (do_phys) begin
      dump_phys = 1'b1;
      #1;
      dump_phys = 1'b0;
      #1;
    end
    $fclose(fo);
    $display("RESULT: tb_smem_replay cycles=%0d errors=%0d %s", cyc, errors, errors == 0 ? "PASS" : "FAIL");
    $finish;
  end
endmodule
