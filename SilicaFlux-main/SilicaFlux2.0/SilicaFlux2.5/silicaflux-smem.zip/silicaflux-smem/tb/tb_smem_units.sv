// =============================================================================
// SilicaFlux Shared Memory :: tb_smem_units
//   A. sf_smem_atomic   - directed corner cases + random, against an SV model
//   B. sf_smem_bank     - random back-to-back traffic on 2..4 rows (maximises the
//                         write-forwarding distance-1 hazard) against a sequential
//                         behavioural model; final array compared via backdoor
//   C. sf_smem_bankmap  - 12 (NB, DEPTH, mapping) variants, ALL word indices:
//                         bijection (uniqueness + range), inverse(map(w)) == w, and
//                         bit-for-bit equality with tables written by py/sfsm/arch.py
// Plusarg  +TABLES=<dir>  (files map_<v>.tab, lines "widx bank row").
// =============================================================================
`timescale 1ns/1ps

module tb_smem_units;
  reg clk = 1'b0;
  reg rst_n = 1'b0;
  always #5 clk = ~clk;

  integer errors = 0;
  integer checks = 0;
  reg [31:0] xs = 32'h1234_5678;

  function automatic [31:0] rnd();
    begin
      xs = xs ^ (xs << 13);
      xs = xs ^ (xs >> 17);
      xs = xs ^ (xs << 5);
      rnd = xs;
    end
  endfunction

  function automatic [31:0] rword();
    reg [31:0] r;
    begin
      r = rnd();
      case (r[3:0])
        4'd0: rword = 32'h0000_0000;
        4'd1: rword = 32'hFFFF_FFFF;
        4'd2: rword = 32'h8000_0000;
        4'd3: rword = 32'h7FFF_FFFF;
        4'd4: rword = 32'h0000_0001;
        default: rword = rnd();
      endcase
    end
  endfunction

  task automatic fail(input string msg);
    begin errors = errors + 1; if (errors <= 30) $display("TB ERROR: %s", msg); end
  endtask

  // ====================================================================== A. atomic unit
  reg  [1:0]  a_op;
  reg  [31:0] a_old, a_wd, a_cmp;
  reg  [3:0]  a_be;
  wire [31:0] a_new;
  wire        a_wr;
  sf_smem_atomic u_alu (.op(a_op), .old(a_old), .wdata(a_wd), .cmp(a_cmp), .be(a_be),
                        .newword(a_new), .wr(a_wr));

  task automatic alu_check(input [1:0] op, input [31:0] old, input [31:0] wd, input [31:0] cm, input [3:0] be);
    reg [31:0] en;
    reg        ew;
    reg [31:0] m;
    integer k;
    begin
      a_op = op; a_old = old; a_wd = wd; a_cmp = cm; a_be = be;
      #1;
      m = 32'h0;
      for (k = 0; k < 4; k = k + 1) if (be[k]) m[8*k +: 8] = 8'hFF;
      case (op)
        2'd0: begin en = old;                       ew = 1'b0; end
        2'd1: begin en = (old & ~m) | (wd & m);     ew = (be != 4'h0); end
        2'd2: begin en = old + wd;                  ew = 1'b1; end
        default: begin en = (old == cm) ? wd : old; ew = (old == cm); end
      endcase
      checks = checks + 1;
      if (a_new !== en || a_wr !== ew)
        fail($sformatf("ALU op=%0d old=%h wd=%h cmp=%h be=%h : new=%h wr=%b expected new=%h wr=%b",
                       op, old, wd, cm, be, a_new, a_wr, en, ew));
    end
  endtask

  // ====================================================================== B. bank
  localparam int BD = 8;
  localparam int BR = $clog2(BD);
  reg              b_init_we;
  reg  [BR-1:0]    b_init_row;
  reg              b_valid;
  reg  [1:0]       b_op;
  reg  [BR-1:0]    b_row;
  reg  [3:0]       b_be;
  reg  [31:0]      b_wd, b_cmp;
  wire             b_rv;
  wire [31:0]      b_rd;
  sf_smem_bank #(.DEPTH(BD)) u_bank (.clk(clk), .rst_n(rst_n), .init_we(b_init_we), .init_row(b_init_row),
                                     .req_valid(b_valid), .req_op(b_op), .req_row(b_row), .req_be(b_be),
                                     .req_wdata(b_wd), .req_cmp(b_cmp), .rsp_valid(b_rv), .rsp_rdata(b_rd));

  reg [31:0] bm [0:BD-1];            // sequential model of the array
  reg        pend_v;                 // a response is due at the next negedge
  reg [31:0] pend_old;
  integer    i, j, n, nrows, pidle, iss, v;
  reg [31:0] r;

  task automatic bank_cycle(input bit issue);
    // drive the request of this cycle, then (at the following negedge) check the
    // response of the PREVIOUS cycle's request
    reg [31:0] old;
    reg [31:0] m;
    integer k;
    begin
      // response of the request driven one cycle ago is visible now (before we change inputs)
      #1;
      checks = checks + 1;
      if (b_rv !== pend_v) fail($sformatf("bank rsp_valid=%b expected %b", b_rv, pend_v));
      if (pend_v) begin
        checks = checks + 1;
        if (b_rd !== pend_old) fail($sformatf("bank rsp_rdata=%h expected %h", b_rd, pend_old));
      end
      if (issue) begin
        b_valid = 1'b1;
        b_row   = rnd() % nrows;
        r = rnd();
        b_op    = r[1:0];
        b_be    = (b_op == 2'd1) ? ((r[7:4] == 4'd0) ? 4'hF : r[7:4]) : 4'hF;
        b_wd    = rword();
        old     = bm[b_row];
        // CAS: half of the time use the true current value as the expected value
        b_cmp   = (r[12]) ? old : rword();
        pend_old = old;
        case (b_op)
          2'd1: begin
            m = 32'h0;
            for (k = 0; k < 4; k = k + 1) if (b_be[k]) m[8*k +: 8] = 8'hFF;
            bm[b_row] = (old & ~m) | (b_wd & m);
          end
          2'd2: bm[b_row] = old + b_wd;
          2'd3: if (old == b_cmp) bm[b_row] = b_wd;
          default: ;
        endcase
      end else begin
        b_valid = 1'b0;
        b_row = rnd() % BD; b_op = rnd(); b_be = rnd(); b_wd = rnd(); b_cmp = rnd();   // junk while idle
      end
      pend_v = issue;
      @(negedge clk);
    end
  endtask

  // ====================================================================== C. bank mapping variants
  localparam int NV = 12;
  function automatic integer v_nb(input integer v);
    case (v) 5: v_nb = 8; 6: v_nb = 16; 7: v_nb = 4; 8: v_nb = 32; 9: v_nb = 2; 10: v_nb = 4; 11: v_nb = 8; default: v_nb = 8; endcase
  endfunction
  function automatic integer v_depth(input integer v);
    case (v) 6: v_depth = 32; 7: v_depth = 8; 8: v_depth = 8; 9: v_depth = 4; 10: v_depth = 64; 11: v_depth = 4; default: v_depth = 16; endcase
  endfunction
  function automatic integer v_map(input integer v);
    case (v) 0: v_map = 0; 1: v_map = 1; 2: v_map = 2; 3: v_map = 3; 4: v_map = 3; 5: v_map = 3;
             6: v_map = 1; 7: v_map = 1; 8: v_map = 2; 9: v_map = 1; 10: v_map = 3; default: v_map = 1; endcase
  endfunction
  function automatic integer v_blk(input integer v);
    case (v) 3: v_blk = 0; 4: v_blk = 1; 5: v_blk = 3; 10: v_blk = 4; default: v_blk = 1; endcase
  endfunction

  string tabdir;
  integer map_checked = 0;

  generate
    for (genvar gv = 0; gv < NV; gv++) begin : g_map
      localparam int NBv = v_nb(gv);
      localparam int DPv = v_depth(gv);
      localparam int WB  = $clog2(NBv) + $clog2(DPv);
      reg  [WB-1:0]            widx;
      wire [$clog2(NBv)-1:0]   bank;
      wire [$clog2(DPv)-1:0]   row;
      reg  [$clog2(NBv)-1:0]   ib;
      reg  [$clog2(DPv)-1:0]   ir;
      wire [WB-1:0]            iw;
      sf_smem_bankmap #(.NB(NBv), .DEPTH(DPv), .MAPPING(v_map(gv)), .BLK_LOG2(v_blk(gv))) u_map (
        .widx(widx), .bank(bank), .row(row), .ibank(ib), .irow(ir), .iwidx(iw));

      reg seen [0:NBv*DPv-1];
      integer w, fdt, rr, tw, tb_, tr;
      string fn;
      initial begin
        #1;
        if (!$value$plusargs("TABLES=%s", tabdir)) tabdir = "";
        $sformat(fn, "%s/map_%0d.tab", tabdir, gv);
        fdt = 0;
        if (tabdir != "") fdt = $fopen(fn, "r");     // (not in a ternary: Verilator 5.020 miscompiles that)
        for (w = 0; w < NBv*DPv; w = w + 1) seen[w] = 1'b0;
        for (w = 0; w < NBv*DPv; w = w + 1) begin
          widx = w;
          #1;
          checks = checks + 3;
          if (bank >= NBv || row >= DPv) fail($sformatf("map variant %0d: word %0d -> bank %0d row %0d out of range", gv, w, bank, row));
          if (seen[bank*DPv + row]) fail($sformatf("map variant %0d: word %0d collides at bank %0d row %0d", gv, w, bank, row));
          seen[bank*DPv + row] = 1'b1;
          ib = bank; ir = row;
          #1;
          if (iw !== widx) fail($sformatf("map variant %0d: inverse(map(%0d)) = %0d", gv, w, iw));
          if (fdt != 0) begin
            rr = $fscanf(fdt, "%d %d %d", tw, tb_, tr);
            checks = checks + 1;
            if (rr != 3 || tw != w || tb_ != bank || tr != row)
              fail($sformatf("map variant %0d: RTL word %0d -> (%0d,%0d), Python table (%0d,%0d)", gv, w, bank, row, tb_, tr));
          end
        end
        if (fdt != 0) $fclose(fdt);
        map_checked = map_checked + 1;
      end
    end
  endgenerate

  // ====================================================================== main
  initial begin
    a_op = 0; a_old = 0; a_wd = 0; a_cmp = 0; a_be = 0;
    b_init_we = 0; b_init_row = 0; b_valid = 0; b_op = 0; b_row = 0; b_be = 0; b_wd = 0; b_cmp = 0;
    pend_v = 0; pend_old = 0;

    // ---- A. atomic unit ----
    alu_check(2'd2, 32'hFFFF_FFFF, 32'h1, 0, 4'hF);
    alu_check(2'd2, 32'h7FFF_FFFF, 32'h1, 0, 4'hF);
    alu_check(2'd2, 32'h8000_0000, 32'h8000_0000, 0, 4'hF);
    alu_check(2'd2, 32'h0, 32'hFFFF_FFFF, 0, 4'hF);
    alu_check(2'd3, 32'h1234, 32'h9999, 32'h1234, 4'hF);
    alu_check(2'd3, 32'h1234, 32'h9999, 32'h1235, 4'hF);
    alu_check(2'd3, 32'h8000_0000, 32'h1, 32'h8000_0000, 4'hF);
    alu_check(2'd1, 32'hAABBCCDD, 32'h11223344, 0, 4'b0101);
    alu_check(2'd1, 32'hAABBCCDD, 32'h11223344, 0, 4'b0000);
    alu_check(2'd0, 32'hAABBCCDD, 32'h11223344, 0, 4'hF);
    for (i = 0; i < 20000; i = i + 1) begin
      r = rnd();
      alu_check(r[1:0], rword(), rword(), (r[4]) ? a_old : rword(), (r[1:0] == 2'd1) ? r[11:8] : 4'hF);
    end

    // ---- B. bank ----
    @(negedge clk);
    rst_n = 1'b1;
    @(negedge clk);
    // zero-fill sweep (what INIT_ON_RESET does)
    for (i = 0; i < BD; i = i + 1) begin b_init_we = 1'b1; b_init_row = i; @(negedge clk); end
    b_init_we = 1'b0;
    for (i = 0; i < BD; i = i + 1) bm[i] = 32'h0;
    for (n = 0; n < 6; n = n + 1) begin
      nrows = (n % 3) + 2;                 // 2, 3, 4 rows: heavy same-row back-to-back traffic
      pidle = (n < 3) ? 0 : 3;             // 0: every cycle issues ; 3: 1 in 4 cycles is idle
      pend_v = 0;
      for (i = 0; i < 12000; i = i + 1) bank_cycle((pidle == 0) ? 1'b1 : ((rnd() % 4) != 0));
      bank_cycle(1'b0);
      bank_cycle(1'b0);
    end
    for (i = 0; i < BD; i = i + 1) begin
      checks = checks + 1;
      if (u_bank.mem[i] !== bm[i]) fail($sformatf("bank array row %0d = %h expected %h", i, u_bank.mem[i], bm[i]));
    end

    // ---- C is running in parallel (initial blocks of the generate loop) ----
    #20000;
    checks = checks + 1;
    if (map_checked != NV) fail($sformatf("only %0d of %0d mapping variants completed", map_checked, NV));

    $display("RESULT: tb_smem_units checks=%0d errors=%0d %s", checks, errors, errors == 0 ? "PASS" : "FAIL");
    $finish;
  end

  initial begin
    #200000000;
    $display("RESULT: tb_smem_units checks=%0d errors=%0d FAIL (watchdog)", checks, errors + 1);
    $finish;
  end
endmodule
