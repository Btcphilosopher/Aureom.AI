// =============================================================================
// SilicaFlux Shared Memory :: tb_smem_reset
// Reset behaviour (docs/SEMANTICS.md section 9):
//   * rst_n is synchronous, active low; it clears all CONTROL state: FIFOs, the
//     active request, the bank pipeline, credits, outstanding counters, performance
//     counters, arbitration pointers.
//   * every request that was accepted but not yet answered is DROPPED: no response
//     is ever produced for it after reset.
//   * INIT_ON_RESET = 1 : arrays are zero-filled, req_ready stays low for DEPTH cycles
//     (counted exactly here), and a reset during the sweep restarts the sweep.
//   * INIT_ON_RESET = 0 : array contents after reset are UNSPECIFIED; only the
//     control behaviour is checked and the memory is used again after writing it.
// Clients must deassert req_valid while rst_n is low (reset is a system event).
// =============================================================================
`timescale 1ns/1ps

module tb_smem_reset;
  parameter int NL            = 8;
  parameter int NB            = 8;
  parameter int DEPTH         = 64;
  parameter int NP            = 2;
  parameter int REQ_DEPTH     = 2;
  parameter int RSP_DEPTH     = 4;
  parameter int TAGW          = 8;
  parameter int AW            = 16;
  parameter int MAPPING       = 0;
  parameter int BLK_LOG2      = 1;
  parameter int LANE_ARB      = 1;
  parameter int PORT_ARB      = 1;
  parameter int WRITE_COMBINE = 1;
  parameter int INIT_ON_RESET = 1;

  `include "tb_common.svh"

  integer i, l, k, n;
  reg [31:0] v;
  bit any_rsp;

  // assert reset for `ncyc` cycles with idle request inputs, then release it.
  // Leaves the bench at the negedge that precedes the first cycle with rst_n = 1.
  task automatic do_reset(input integer ncyc);
    integer q;
    begin
      for (q = 0; q < NP; q = q + 1) req_valid[q] = 1'b0;
      rst_n = 1'b0;
      repeat (ncyc) tick;
      rst_n = 1'b1;
    end
  endtask

  // verify the whole subsystem looks freshly reset (called right after release)
  task automatic ck_fresh(input string tag_);
    integer q;
    begin
      #1;
      for (q = 0; q < NP; q = q + 1) begin
        ck({tag_, ": no response pending"}, rsp_valid[q], 1'b0);
        ck({tag_, ": outstanding"}, outstanding[q*OW +: OW], 0);
        ck({tag_, ": port_idle"}, port_idle[q], 1'b1);
      end
      for (q = 0; q < NCNT; q = q + 1) ck({tag_, ": perf counter cleared"}, perf[q*32 +: 32], 0);
      ck({tag_, ": init_busy"}, init_busy, INIT_ON_RESET != 0);
      ck({tag_, ": req_ready follows init"}, &req_ready, INIT_ON_RESET == 0);
    end
  endtask

  // zero test: read the first `nw` words back (INIT_ON_RESET = 1 only)
  task automatic ck_zero(input string tag_, input integer nw);
    integer w, ll;
    begin
      for (w = 0; w < nw; w = w + NL) begin
        clear_req(0);
        for (ll = 0; ll < NL; ll = ll + 1) lane(0, ll, OPLD, wa(w + ll), 4'hF, 0, 0);
        xact(0, 8'h00 + w[7:0]);
        for (ll = 0; ll < NL; ll = ll + 1) ck({tag_, ": array zero"}, g_data[ll], 0);
      end
    end
  endtask

  // watch for stray responses for `ncyc` cycles
  task automatic watch_quiet(input string tag_, input integer ncyc);
    integer c, q;
    begin
      for (c = 0; c < ncyc; c = c + 1) begin
        #1;
        for (q = 0; q < NP; q = q + 1) begin
          checks = checks + 1;
          if (rsp_valid[q]) fail({tag_, ": stale response after reset"});
        end
        tick;
      end
    end
  endtask

  initial begin
    req_valid = '0; req_tag = '0; req_lane_valid = '0; req_op = '0; req_addr = '0;
    req_be = '0; req_wdata = '0; req_cmp = '0; rsp_ready = '1;
    repeat (4) @(posedge clk);
    @(negedge clk);
    rst_n = 1'b1;
    cyc = 0;
    wait_init;

    // ---------------------------------------------------------------- R1 reset while idle, after writing
    section("R1 idle reset");
    for (i = 0; i < 16; i = i + 1) wr1(i, 32'hC0DE_0000 + i);
    do_reset(3);
    ck_fresh("R1");
    if (INIT_ON_RESET != 0) begin
      n = 0;
      while (init_busy) begin n = n + 1; tick; #1; end
      ck("R1 init_busy cycles", n, DEPTH);
      ck("R1 req_ready after init", &req_ready, 1'b1);
      ck_zero("R1", 16);
    end else begin
      wait_init;
      wr1(3, 32'h1357_9BDF); rd1(3, v); ck("R1 memory usable after reset (INIT_ON_RESET=0)", v, 32'h1357_9BDF);
    end

    // ---------------------------------------------------------------- R2 reset with requests in every stage
    section("R2 reset with traffic in flight");
    for (i = 0; i < 8; i = i + 1) wr1(8 * i, 32'hAAAA_0000 + i);
    rsp_ready = '0;                                          // responses pile up
    // port 0: a long conflicting request (8 issue cycles) followed by more requests
    clear_req(0);
    for (l = 0; l < 8; l = l + 1) lane(0, l, OPLD, wa(8 * l), 4'hF, 0, 0);
    send(0, 8'h11);
    clear_req(0); for (l = 0; l < 8; l = l + 1) lane(0, l, OPADD, wa(200), 4'hF, 32'd1, 0);
    send(0, 8'h12);
    clear_req(0); for (l = 0; l < 8; l = l + 1) lane(0, l, OPST, wa(8 * l + 1), 4'hF, 32'hDEAD_BEEF, 0);
    send(0, 8'h13);
    // port 1: requests queued behind
    clear_req(1); for (l = 0; l < 8; l = l + 1) lane(1, l, OPADD, wa(201), 4'hF, 32'd1, 0);
    send(1, 8'h21);
    clear_req(1); for (l = 0; l < 8; l = l + 1) lane(1, l, OPST, wa(202 + l), 4'hF, 32'h1111_1111, 0);
    send(1, 8'h22);
    repeat (3) tick;
    ck("R2 traffic is in flight before reset", quiescent, 1'b0);
    ck("R2 outstanding[0] before reset > 0", outstanding[0 +: OW] != 0, 1'b1);
    rsp_ready = '1;
    do_reset(2);
    ck_fresh("R2");
    watch_quiet("R2", DEPTH + 60);
    if (INIT_ON_RESET != 0) begin
      wait_init;
      ck_zero("R2 (dropped stores never land)", 24);
      rd1(200, v); ck("R2 half-done atomic add word is zero", v, 0);
      rd1(201, v); ck("R2 port-1 atomic add word is zero", v, 0);
    end else wait_init;
    // the subsystem works normally afterwards, with fresh tags and fresh credits
    wr1(40, 32'd5);
    clear_req(0); for (l = 0; l < 8; l = l + 1) lane(0, l, OPADD, wa(40), 4'hF, 32'd1, 0);
    xact(0, 8'h99);
    ck("R2 tag after reset", g_tag, 8'h99);
    for (l = 0; l < 8; l = l + 1) ck("R2 atomic result after reset", g_data[l], 5 + l);
    ck("R2 outstanding after use", outstanding[0 +: OW], 0);

    // ---------------------------------------------------------------- R3 reset during the init sweep
    section("R3 reset during init sweep");
    if (INIT_ON_RESET != 0) begin
      for (i = 0; i < 8; i = i + 1) wr1(i, 32'hBEEF_0000 + i);
      do_reset(1);
      repeat (DEPTH / 2) tick;
      #1;
      ck("R3 sweep still running", init_busy, 1'b1);
      do_reset(1);                                           // second reset half way through
      n = 0;
      #1;
      while (init_busy) begin n = n + 1; tick; #1; end
      ck("R3 sweep restarted: full DEPTH cycles after the second reset", n, DEPTH);
      ck_zero("R3", 16);
    end

    // ---------------------------------------------------------------- R4 reset inside an atomic burst
    section("R4 reset inside an atomic RMW burst");
    wait_init;
    wr1(50, 32'd1000);
    clear_req(0); for (l = 0; l < 8; l = l + 1) lane(0, l, OPADD, wa(50), 4'hF, 32'd1, 0);
    send(0, 8'h31);
    repeat (5) tick;                                         // 8-cycle burst: about half done
    do_reset(1);
    ck_fresh("R4");
    watch_quiet("R4", DEPTH + 30);
    wait_init;
    if (INIT_ON_RESET != 0) begin rd1(50, v); ck("R4 interrupted atomic: word is zero (array re-initialised)", v, 0); end
    wr1(50, 32'd7);
    clear_req(0); lane(0, 0, OPADD, wa(50), 4'hF, 32'd1, 0); xact(0, 8'h32);
    ck("R4 atomic works after reset", g_data[0], 7);

    // ---------------------------------------------------------------- R5 reset with unread responses
    section("R5 reset with unread responses");
    wait_init;
    rsp_ready = '0;
    for (i = 0; i < 3; i = i + 1) begin clear_req(0); lane(0, 0, OPLD, wa(i), 4'hF, 0, 0); send(0, 8'h50 + i); end
    repeat (10) tick;
    #1;
    ck("R5 responses waiting", rsp_valid[0], 1'b1);
    rsp_ready = '1;
    do_reset(1);
    ck_fresh("R5");
    watch_quiet("R5", DEPTH + 20);
    wait_init;
    clear_req(0); lane(0, 0, OPST, wa(9), 4'hF, 32'h600D, 0); xact(0, 8'h60);
    ck("R5 first response after reset has the new tag", g_tag, 8'h60);

    // ---------------------------------------------------------------- R6 long reset, repeated pulses
    section("R6 repeated resets");
    for (k = 0; k < 6; k = k + 1) begin
      do_reset(1 + (k % 3));
      repeat (k * 3) tick;
    end
    ck_fresh("R6 (after the last pulse)");
    wait_init;
    wr1(5, 32'hFACE_FEED); rd1(5, v); ck("R6 memory usable", v, 32'hFACE_FEED);
    ck("R6 quiescent", quiescent, 1'b1);

    summary("tb_smem_reset");
    $finish;
  end
endmodule
