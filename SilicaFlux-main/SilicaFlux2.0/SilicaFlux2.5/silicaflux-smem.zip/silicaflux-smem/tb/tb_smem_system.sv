// =============================================================================
// SilicaFlux Shared Memory :: tb_smem_system
// Workgroup-barrier / memory-visibility litmus tests.
//
//   warp 0 = CONSUMER on request port 0        warp 1 = PRODUCER on request port 1
//   sf_wg_barrier (rtl/sys) is instantiated here and is NOT connected to the memory
//   subsystem in any way: the memory arbitrates banks and ports exactly the same
//   whether a barrier exists or not.  Visibility around a barrier is therefore the
//   CLIENT's responsibility:   fence (port_idle) ; arrive ; wait release.
//
//   RAW  producer: store X ; [fence] ; arrive    consumer: wait ; load X   (must see the store)
//   WAR  consumer: load X ; [fence] ; arrive     producer: wait ; store X  (load must NOT see it)
//
//   Without the fence both orderings are violated by this implementation when one
//   port's earlier request occupies the issue stage (a WITNESS of allowed behaviour,
//   not a bug).  With the fence there must be zero violations in every trial.
// =============================================================================
`timescale 1ns/1ps

module tb_smem_system;
  parameter int NL            = 8;
  parameter int NB            = 8;
  parameter int DEPTH         = 64;
  parameter int NP            = 2;
  parameter int REQ_DEPTH     = 2;
  parameter int RSP_DEPTH     = 4;
  parameter int TAGW          = 8;
  parameter int AW            = 16;
  parameter int MAPPING       = 0;
  parameter int BLK_LOG2      = 1;
  parameter int LANE_ARB      = 1;
  parameter int PORT_ARB      = 1;
  parameter int WRITE_COMBINE = 1;
  parameter int INIT_ON_RESET = 1;

  `include "tb_common.svh"

  // ---- the barrier: separate block, no connection to dut ------------------------------
  reg  [1:0] bar_arrive = 2'b00;
  wire [1:0] bar_wait, bar_rel;
  sf_wg_barrier #(.NW(2)) u_bar (.clk(clk), .rst_n(rst_n), .member(2'b11), .arrive(bar_arrive),
                                 .waiting(bar_wait), .release_o(bar_rel));

  // ---- response monitor: records every response that is consumed ---------------------
  integer    mon_n    [0:NP-1];
  reg [31:0] mon_d0   [0:NP-1][0:15];
  integer    mon_cyc  [0:NP-1][0:15];
  integer    q_;
  always @(negedge clk) begin
    for (q_ = 0; q_ < NP; q_ = q_ + 1)
      if (rsp_valid[q_] && rsp_ready[q_]) begin
        if (mon_n[q_] < 16) begin
          mon_d0[q_][mon_n[q_]]  = rsp_data[(q_*NL)*32 +: 32];
          mon_cyc[q_][mon_n[q_]] = cyc;
        end
        mon_n[q_] = mon_n[q_] + 1;
      end
  end
  task automatic mon_clear; integer q; begin for (q = 0; q < NP; q = q + 1) mon_n[q] = 0; end endtask

  task automatic arrive(input integer w);
    // whole-vector writes: Verilator 5.020 does not propagate a constant bit-select blocking
    // write from a timing process to a design input at the next edge (Icarus does)
    begin bar_arrive = (2'b01 << w); tick; bar_arrive = 2'b00; #1; end
  endtask
  task automatic wait_release(input integer w);
    begin #1; while (!bar_rel[w]) begin tick; #1; end end
  endtask
  task automatic fence(input integer p);                 // FENCE.SMEM : wait for all own responses
    begin #1; while (!port_idle[p]) begin tick; #1; end end
  endtask
  task automatic wait_resp(input integer p, input integer cnt);
    begin #1; while (mon_n[p] < cnt) begin tick; #1; end end
  endtask
  task automatic settle;                                 // let everything drain
    begin repeat (4) tick; #1; while (!quiescent) begin tick; #1; end end
  endtask

  // aggressor request: `d` lanes on d different words of ONE bank (linear: bank 4) -> d issue cycles
  task automatic aggressor(input integer p, input integer d, input [2:0] op, input [7:0] tg);
    integer ll;
    begin
      clear_req(p);
      for (ll = 0; ll < d; ll = ll + 1) lane(p, ll, op, wa(300 + 8 * ll), 4'hF, 32'h0A0A_0000 + ll, 0);
      send(p, tg);
    end
  endtask

  localparam [31:0] OLD = 32'h1111_1111;
  localparam [31:0] NEW = 32'hAAAA_AAAA;
  localparam int    X   = 200;

  // ---- RAW: returns the value the consumer read -----------------------------------------------
  task automatic litmus_raw(input integer dprod, input bit use_fence, input integer extra, output [31:0] seen);
    begin
      wr1(X, OLD);
      settle; mon_clear;
      arrive(0);                                           // consumer already waiting
      if (dprod > 0) aggressor(1, dprod, OPST, 8'h01);     // producer: an earlier long request ...
      clear_req(1); lane(1, 0, OPST, wa(X), 4'hF, NEW, 0); send(1, 8'h02);   // ... then the data store
      repeat (extra) tick;
      if (use_fence) fence(1);
      arrive(1);
      wait_release(0);
      clear_req(0); lane(0, 0, OPLD, wa(X), 4'hF, 0, 0); send(0, 8'h03);
      wait_resp(0, 1);
      seen = mon_d0[0][0];
      settle;
    end
  endtask

  // ---- WAR: returns the value the consumer's PRE-barrier load observed --------------------------
  task automatic litmus_war(input integer dcons, input bit use_fence, input integer extra, output [31:0] seen);
    begin
      wr1(X, OLD);
      settle; mon_clear;
      arrive(1);                                           // producer already waiting
      if (dcons > 0) aggressor(0, dcons, OPLD, 8'h11);     // consumer: an earlier long request ...
      clear_req(0); lane(0, 0, OPLD, wa(X), 4'hF, 0, 0); send(0, 8'h12);     // ... then the load of X
      repeat (extra) tick;
      if (use_fence) fence(0);
      arrive(0);
      wait_release(1);
      clear_req(1); lane(1, 0, OPST, wa(X), 4'hF, NEW, 0); send(1, 8'h13);   // post-barrier store
      wait_resp(0, (dcons > 0) ? 2 : 1);
      seen = mon_d0[0][(dcons > 0) ? 1 : 0];
      settle;
    end
  endtask

  integer t, viol_raw_nf, viol_raw_f, viol_war_nf, viol_war_f, trials, dd, ex;
  reg [31:0] seen, v;
  integer lat_sum, k;

  initial begin
    req_valid = '0; req_tag = '0; req_lane_valid = '0; req_op = '0; req_addr = '0;
    req_be = '0; req_wdata = '0; req_cmp = '0; rsp_ready = '1;
    mon_clear;
    repeat (4) @(posedge clk);
    @(negedge clk);
    rst_n = 1'b1;
    cyc = 0;
    wait_init;

    // ------------------------------------------------------------ S1 the barrier does not touch memory traffic
    section("S1 barrier independence");
    arrive(0);                                             // consumer waits for the producer, forever (for now)
    ck("S1 consumer is waiting at the barrier", bar_wait[0], 1'b1);
    for (k = 0; k < 6; k = k + 1) begin
      clear_req(1); lane(1, 0, OPLD, wa(k), 4'hF, 0, 0); xact(1, 8'h20 + k);
      if (MAPPING == 0) ck("S1 memory latency unaffected by a waiting barrier", g_lat, 4);
      ck("S1 still waiting", bar_wait[0], 1'b1);
    end
    arrive(1);
    wait_release(0);                                       // (a hang here would trip the watchdog)
    ck("S1 barrier released the waiting warp and cleared its wait flag", bar_wait[0], 1'b0);
    settle;

    // ------------------------------------------------------------ S2 crafted RAW: barrier alone is NOT enough
    section("S2 RAW crafted");
    litmus_raw(8, 1'b0, 0, seen);
    $display("INFO S2 RAW  no fence : consumer read %h  (%s)", seen, seen == OLD ? "STALE - hazard witnessed" : "fresh");
    ck("S2 RAW without fence: stale value witnessed (barrier does not order memory)", seen, OLD);
    litmus_raw(8, 1'b1, 0, seen);
    $display("INFO S2 RAW  fence    : consumer read %h", seen);
    ck("S2 RAW with fence: fresh value", seen, NEW);

    // ------------------------------------------------------------ S3 crafted WAR (needs round-robin ports)
    section("S3 WAR crafted");
    litmus_war(8, 1'b0, 0, seen);
    $display("INFO S3 WAR  no fence : pre-barrier load saw %h  (%s)", seen, seen == NEW ? "post-barrier store VISIBLE - hazard witnessed" : "old");
    if (PORT_ARB != 0) ck("S3 WAR without fence: load observed the later store (RR arbitration)", seen, NEW);
    litmus_war(8, 1'b1, 0, seen);
    $display("INFO S3 WAR  fence    : pre-barrier load saw %h", seen);
    ck("S3 WAR with fence: load completed before the barrier", seen, OLD);

    // ------------------------------------------------------------ S4 randomised litmus sweep
    section("S4 randomised litmus");
    viol_raw_nf = 0; viol_raw_f = 0; viol_war_nf = 0; viol_war_f = 0; trials = 160;
    for (t = 0; t < trials; t = t + 1) begin
      dd = 1 + (rnd_(8));
      ex = rnd_(4);
      litmus_raw(dd, 1'b0, ex, seen); if (seen != NEW) viol_raw_nf = viol_raw_nf + 1;
      litmus_raw(dd, 1'b1, ex, seen); if (seen != NEW) viol_raw_f  = viol_raw_f  + 1;
      litmus_war(dd, 1'b0, ex, seen); if (seen != OLD) viol_war_nf = viol_war_nf + 1;
      litmus_war(dd, 1'b1, ex, seen); if (seen != OLD) viol_war_f  = viol_war_f  + 1;
    end
    $display("LITMUS trials=%0d raw_unfenced_violations=%0d raw_fenced_violations=%0d war_unfenced_violations=%0d war_fenced_violations=%0d",
             trials, viol_raw_nf, viol_raw_f, viol_war_nf, viol_war_f);
    ck("S4 RAW with fence: zero violations", viol_raw_f, 0);
    ck("S4 WAR with fence: zero violations", viol_war_f, 0);
    ck("S4 RAW without fence: violations exist", viol_raw_nf > 0, 1'b1);
    if (PORT_ARB != 0) ck("S4 WAR without fence: violations exist", viol_war_nf > 0, 1'b1);

    summary("tb_smem_system");
    $finish;
  end

  // small deterministic PRNG for the sweep
  reg [31:0] xs_ = 32'hC0FFEE11;
  function automatic integer rnd_(input integer m);
    begin
      xs_ = xs_ ^ (xs_ << 13); xs_ = xs_ ^ (xs_ >> 17); xs_ = xs_ ^ (xs_ << 5);
      rnd_ = (xs_ >> 4) % m;
    end
  endfunction
endmodule
