// =============================================================================
// SilicaFlux Shared Memory :: sf_smem_fifo
// Small synchronous FIFO, first-word-fall-through (dout is the head whenever
// !empty).  Register-array storage: used for request and response buffering.
// push when full / pop when empty are protocol violations (sim-time $fatal);
// the top level guarantees neither can happen (ready / credit scheme).
// Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_smem_fifo #(
  parameter int W     = 8,
  parameter int DEPTH = 2          // >= 1
) (
  input  logic                         clk,
  input  logic                         rst_n,
  input  logic                         push,
  input  logic [W-1:0]                 din,
  input  logic                         pop,
  output logic [W-1:0]                 dout,
  output logic                         empty,
  output logic                         full,
  output logic [$clog2(DEPTH+1)-1:0]   count
);
  localparam int PW = (DEPTH > 1) ? $clog2(DEPTH) : 1;

  logic [W-1:0]  mem [0:DEPTH-1];
  logic [PW-1:0] wp, rp;
  logic [$clog2(DEPTH+1)-1:0] cnt;

  wire do_push = push && !full;
  wire do_pop  = pop  && !empty;

  assign empty = (cnt == 0);
  assign full  = (cnt == ($clog2(DEPTH+1))'(DEPTH));
  assign count = cnt;
  assign dout  = mem[rp];

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      wp  <= '0;
      rp  <= '0;
      cnt <= '0;
    end else begin
      if (do_push) begin
        mem[wp] <= din;
        wp <= (wp == PW'(DEPTH-1)) ? '0 : wp + 1'b1;
      end
      if (do_pop)
        rp <= (rp == PW'(DEPTH-1)) ? '0 : rp + 1'b1;
      cnt <= cnt + {{($clog2(DEPTH+1)-1){1'b0}}, do_push}
                 - {{($clog2(DEPTH+1)-1){1'b0}}, do_pop};
    end
  end

`ifndef SYNTHESIS
  always @(posedge clk) begin
    if (rst_n && push && full && !pop)
      $fatal(1, "sf_smem_fifo: push into full FIFO (W=%0d DEPTH=%0d)", W, DEPTH);
    if (rst_n && pop && empty)
      $fatal(1, "sf_smem_fifo: pop from empty FIFO (W=%0d DEPTH=%0d)", W, DEPTH);
  end
`endif
endmodule

`default_nettype wire
