// =============================================================================
// SilicaFlux Shared Memory :: sf_smem_bankmap
// Architectural word index  ->  (bank, row).  Purely combinational.
//
// The architectural address space is NOT changed by the mapping: every mapping
// is a BIJECTION between word indices [0, NB*DEPTH) and (bank,row) pairs, so
// software sees the same memory whatever MAPPING is selected; only which words
// share a bank (hence which accesses conflict) changes.  The inverse function
// is provided so that testbenches can prove the bijection exhaustively.
//
//   w = word index, NB = 2**B banks, DEPTH = 2**R rows, lo = w[B-1:0], hi = w >> B
//
//   LINEAR : bank = lo                         row = hi
//   XOR    : bank = lo ^ fold(hi)              row = hi
//            fold(hi) = hi[B-1:0] ^ hi[2B-1:B] ^ ...   (B-bit chunks, zero padded)
//   SKEW   : bank = (lo + hi) mod NB           row = hi
//   BLOCK  : G = BLK_LOG2; 2**G consecutive words stay in one bank
//            bank = (w >> G) mod NB
//            row  = ((w >> (G+B)) << G) | w[G-1:0]
//
// Classification: SYNTHESIZABLE.
// =============================================================================
`include "sf_smem_defs.svh"
`default_nettype none

module sf_smem_bankmap #(
  parameter int NB       = 8,     // banks, power of two >= 2
  parameter int DEPTH    = 256,   // rows per bank, power of two >= 2
  parameter int MAPPING  = 0,
  parameter int BLK_LOG2 = 1
) (
  // forward map
  input  logic [$clog2(NB)+$clog2(DEPTH)-1:0] widx,
  output logic [$clog2(NB)-1:0]               bank,
  output logic [$clog2(DEPTH)-1:0]            row,
  // inverse map (verification / debug; unused logic is removed by synthesis)
  input  logic [$clog2(NB)-1:0]               ibank,
  input  logic [$clog2(DEPTH)-1:0]            irow,
  output logic [$clog2(NB)+$clog2(DEPTH)-1:0] iwidx
);
  localparam int B = $clog2(NB);
  localparam int R = $clog2(DEPTH);
  // clamped copy so that the (unused) BLOCK branch always elaborates; the raw
  // parameter is range-checked below when MAPPING == BLOCK
  localparam int G = (BLK_LOG2 > R) ? R : ((BLK_LOG2 < 0) ? 0 : BLK_LOG2);

  // ---- elaboration-time configuration checks ---------------------------------
  initial begin
    if (NB < 2 || (NB & (NB-1)) != 0)
      $fatal(1, "sf_smem_bankmap: NB=%0d must be a power of two >= 2", NB);
    if (DEPTH < 2 || (DEPTH & (DEPTH-1)) != 0)
      $fatal(1, "sf_smem_bankmap: DEPTH=%0d must be a power of two >= 2", DEPTH);
    if (MAPPING < 0 || MAPPING > 3)
      $fatal(1, "sf_smem_bankmap: MAPPING=%0d out of range", MAPPING);
    if (MAPPING == `SF_MAP_BLOCK && (BLK_LOG2 < 0 || BLK_LOG2 > R))
      $fatal(1, "sf_smem_bankmap: BLK_LOG2=%0d must be in [0,%0d]", BLK_LOG2, R);
  end

  // fold(): XOR of B-bit chunks of a row index (zero padded)
  function automatic logic [B-1:0] fold(input logic [R-1:0] h);
    logic [B-1:0] acc;
    integer i, j;
    begin
      acc = '0;
      for (i = 0; i < R; i = i + B)
        for (j = 0; j < B; j = j + 1)
          if (i + j < R) acc[j] = acc[j] ^ h[i + j];
      fold = acc;
    end
  endfunction

  logic [B-1:0] lo;
  logic [R-1:0] hi;
  logic [B-1:0] ilo;
  localparam logic [B+R-1:0] GMASK = (({{(B+R-1){1'b0}}, 1'b1}) << G) - 1'b1;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [B+R-1:0] row_full, irow_e, ibank_e;
  /* verilator lint_on UNUSEDSIGNAL */

  always_comb begin
    lo  = widx[B-1:0];
    hi  = widx[B+R-1:B];
    ilo = '0;
    bank = '0; row = '0; iwidx = '0;
    row_full = '0; irow_e = '0; ibank_e = '0;

    case (MAPPING)
      `SF_MAP_LINEAR: begin
        bank  = lo;
        row   = hi;
        iwidx = {irow, ibank};
      end

      `SF_MAP_XOR: begin
        bank  = lo ^ fold(hi);
        row   = hi;
        ilo   = ibank ^ fold(irow);
        iwidx = {irow, ilo};
      end

      `SF_MAP_SKEW: begin
        // (lo + hi) mod NB : only the low B bits of hi matter
        bank  = lo + hi[(R<B?R:B)-1:0];
        row   = hi;
        ilo   = ibank - irow[(R<B?R:B)-1:0];
        iwidx = {irow, ilo};
      end

      default: begin // SF_MAP_BLOCK
        // forward: blk = w >> G ; bank = blk mod NB ; row = ((w >> (G+B)) << G) | w[G-1:0]
        bank     = widx[G +: B];
        row_full = ((widx >> (G + B)) << G) | (widx & GMASK);
        row      = row_full[R-1:0];
        // inverse
        irow_e   = {{B{1'b0}}, irow};
        ibank_e  = {{R{1'b0}}, ibank};
        iwidx    = ((irow_e >> G) << (G + B)) | (ibank_e << G) | (irow_e & GMASK);
      end
    endcase
  end
endmodule

`default_nettype wire
