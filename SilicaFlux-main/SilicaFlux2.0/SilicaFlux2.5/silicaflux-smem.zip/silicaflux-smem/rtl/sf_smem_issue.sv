// =============================================================================
// SilicaFlux Shared Memory :: sf_smem_issue
// Per-cycle bank arbitration for the ACTIVE request.  Combinational except for
// the per-bank rotating lane pointers.
//
// Inputs are the lanes of one request that still need a bank access (`pend`).
// Each cycle every bank serves at most ONE GROUP: a set of lanes that all
// address the same word, are served by a single array access and are merged
// into one bank operation.  Definitions (lane order = ascending lane index):
//
//   same[j][k]   lanes j,k pending and addressing the same word (same bank,row)
//   class        LOAD=0  STORE=1  ATOMIC(ADD,CAS)=2
//   mergeable    LOAD/LOAD always; STORE/STORE only if WRITE_COMBINE; ATOMIC never
//   blocked[k]   some LOWER pending lane j on the same word is NOT mergeable with k
//   ready[k]     pend[k] & ~blocked[k]   (k is in the homogeneous run at the head
//                                         of the pending same-word sequence)
//   anchor[k]    pend[k] & no lower pending lane on the same word
//                (the lowest pending lane of every word; always ready)
//
// Per bank: the arbitration policy (LANE_ARB: 0 = lowest lane first, 1 = rotating
// priority) picks ONE anchor among that bank's anchors; the group served is
// every ready lane on the anchor's word.  Consequences (all checked in
// simulation and in the Python model, docs/SEMANTICS.md section 5):
//   * read broadcast : consecutive loads at the head of a word's pending
//                      sequence share one array read;
//   * write combine  : consecutive stores merge per byte, HIGHEST lane wins;
//   * atomics        : exactly one per word per cycle, in lane order;
//   * lane order     : a lane is never served before a lower lane that is
//                      pending on the same word and not mergeable with it, so
//                      the result equals sequential execution in lane order.
// Each bank with at least one pending lane serves one group per cycle (an anchor
// always exists), so the request completes in max over banks of
// (sum over words of the number of runs) cycles, and progress is guaranteed.
// The lane arbitration policy changes only the ORDER in which different words of
// one bank are served, never the number of cycles nor any architectural result.
//
// Classification: SYNTHESIZABLE.  Cost is O(NL^2) word comparators.
// =============================================================================
`include "sf_smem_defs.svh"
`default_nettype none

module sf_smem_issue #(
  parameter int NL            = 8,
  parameter int NB            = 8,
  parameter int ROW_W         = 8,
  parameter int LANE_ARB      = 1,   // 0 fixed (lowest lane), 1 rotating
  parameter int WRITE_COMBINE = 1
) (
  input  logic                         clk,
  input  logic                         rst_n,
  input  logic                         issuing,   // an active request is being issued
  input  logic [NL-1:0]                pend,
  input  logic [NL*2-1:0]              op,        // 0 LOAD 1 STORE 2 ADD 3 CAS
  input  logic [NL*$clog2(NB)-1:0]     bank,
  input  logic [NL*ROW_W-1:0]          row,
  input  logic [NL*4-1:0]              be,
  input  logic [NL*32-1:0]             wdata,
  input  logic [NL*32-1:0]             cmp,
  // one bank request per bank
  output logic [NB-1:0]                b_valid,
  output logic [NB*2-1:0]              b_op,
  output logic [NB*ROW_W-1:0]          b_row,
  output logic [NB*4-1:0]              b_be,
  output logic [NB*32-1:0]             b_wdata,
  output logic [NB*32-1:0]             b_cmp,
  // lane bookkeeping
  output logic [NL-1:0]                served,    // lanes served this cycle
  output logic [NL*4-1:0]              rmask,     // byte mask applied to returned data
  output logic                         last       // nothing left pending after this cycle
);
  localparam int BW = $clog2(NB);
  localparam int LW = $clog2(NL);

  // ---- unpacked views ----------------------------------------------------------
  logic [1:0]      l_op   [0:NL-1];
  logic [1:0]      l_cls  [0:NL-1];
  logic [BW-1:0]   l_bank [0:NL-1];
  logic [ROW_W-1:0] l_row [0:NL-1];
  logic [3:0]      l_be   [0:NL-1];
  logic [31:0]     l_wd   [0:NL-1];
  logic [31:0]     l_cmp  [0:NL-1];

  logic [NL-1:0]   same   [0:NL-1];   // same[j][k]
  logic [NL-1:0]   lower_same, blocked, anchor, ready;

  logic [NL-1:0]   cand   [0:NB-1];
  logic [NL-1:0]   sel_oh [0:NB-1];
  logic [NL-1:0]   grp    [0:NB-1];
  logic [LW-1:0]   aidx   [0:NB-1];
  logic [LW-1:0]   lptr   [0:NB-1];   // rotating priority pointer per bank
  // per-bank temporaries for the bank operation under construction
  logic [1:0]       t_op;
  logic [ROW_W-1:0] t_row;
  logic [3:0]       t_be;
  logic [31:0]      t_wd, t_cmp;

  // lowest-set-bit-at-or-after-ptr (rotating) or lowest set bit (fixed)
  function automatic logic [NL-1:0] pick_oh(input logic [NL-1:0] c, input logic [LW-1:0] ptr);
    logic [NL-1:0] res;
    logic          found;
    integer        i;
    begin
      res = '0; found = 1'b0;
      if (LANE_ARB != 0) begin
        for (i = 0; i < NL; i = i + 1)
          if (!found && c[i] && (i >= ptr)) begin res[i] = 1'b1; found = 1'b1; end
      end
      for (i = 0; i < NL; i = i + 1)
        if (!found && c[i]) begin res[i] = 1'b1; found = 1'b1; end
      pick_oh = res;
    end
  endfunction

  function automatic logic mrg(input logic [1:0] c);
    mrg = (c == 2'd0) || (c == 2'd1 && WRITE_COMBINE != 0);
  endfunction

  integer j, k, b, m;
  always_comb begin
    m = 0;                       // loop variables are initialised unconditionally (no latch inference)
    // unpack
    for (k = 0; k < NL; k = k + 1) begin
      l_op[k]   = op[k*2 +: 2];
      l_cls[k]  = op[k*2+1] ? 2'd2 : op[k*2 +: 2];
      l_bank[k] = bank[k*BW +: BW];
      l_row[k]  = row[k*ROW_W +: ROW_W];
      l_be[k]   = be[k*4 +: 4];
      l_wd[k]   = wdata[k*32 +: 32];
      l_cmp[k]  = cmp[k*32 +: 32];
    end

    // same-word matrix
    for (j = 0; j < NL; j = j + 1)
      for (k = 0; k < NL; k = k + 1)
        same[j][k] = (j != k) && pend[j] && pend[k] &&
                     (l_bank[j] == l_bank[k]) && (l_row[j] == l_row[k]);

    // lane-order hazards
    for (k = 0; k < NL; k = k + 1) begin
      lower_same[k] = 1'b0;
      blocked[k]    = 1'b0;
      for (j = 0; j < NL; j = j + 1) begin
        if (j < k && same[j][k]) begin
          lower_same[k] = 1'b1;
          if (!(l_cls[j] == l_cls[k] && mrg(l_cls[k]))) blocked[k] = 1'b1;
        end
      end
      anchor[k] = pend[k] & ~lower_same[k];
      ready[k]  = pend[k] & ~blocked[k];
    end

    // per-bank arbitration and group formation
    served = '0;
    for (b = 0; b < NB; b = b + 1) begin
      for (k = 0; k < NL; k = k + 1) cand[b][k] = anchor[k] && (l_bank[k] == BW'(b));
      sel_oh[b]  = pick_oh(cand[b], lptr[b]);
      b_valid[b] = |cand[b];

      aidx[b] = '0;
      for (k = 0; k < NL; k = k + 1) if (sel_oh[b][k]) aidx[b] = LW'(k);

      for (k = 0; k < NL; k = k + 1)
        grp[b][k] = ready[k] && b_valid[b] && (sel_oh[b][k] || (|(sel_oh[b] & same[k])));

      // bank operation = operation of the anchor ...
      t_op = 2'd0; t_row = '0; t_be = 4'h0; t_wd = 32'h0; t_cmp = 32'h0;
      for (k = 0; k < NL; k = k + 1) begin
        if (sel_oh[b][k]) begin
          t_op  = l_op[k];
          t_row = l_row[k];
          t_be  = (l_cls[k] == 2'd1) ? 4'h0 : l_be[k];
          t_wd  = l_wd[k];
          t_cmp = l_cmp[k];
        end
      end
      // ... except STORE groups, which merge all lanes of the group per byte,
      // ascending lane order so that the HIGHEST lane overrides.
      if (t_op == 2'd1) begin
        for (k = 0; k < NL; k = k + 1)
          if (grp[b][k])
            for (m = 0; m < 4; m = m + 1)
              if (l_be[k][m]) begin
                t_be[m]            = 1'b1;
                t_wd[8*m +: 8]     = l_wd[k][8*m +: 8];
              end
      end
      b_op[b*2 +: 2]          = t_op;
      b_row[b*ROW_W +: ROW_W] = t_row;
      b_be[b*4 +: 4]          = t_be;
      b_wdata[b*32 +: 32]     = t_wd;
      b_cmp[b*32 +: 32]       = t_cmp;

      for (k = 0; k < NL; k = k + 1) if (grp[b][k]) served[k] = 1'b1;
    end

    for (k = 0; k < NL; k = k + 1)
      rmask[k*4 +: 4] = (l_cls[k] == 2'd0) ? l_be[k] :
                        (l_cls[k] == 2'd2) ? 4'hF    : 4'h0;

    last = ((pend & ~served) == '0);
  end

  // ---- rotating pointers ---------------------------------------------------------
  integer fb;
  always_ff @(posedge clk) begin
    for (fb = 0; fb < NB; fb = fb + 1) begin
      if (!rst_n)
        lptr[fb] <= '0;
      else if (issuing && b_valid[fb] && LANE_ARB != 0)
        lptr[fb] <= (aidx[fb] == LW'(NL-1)) ? '0 : aidx[fb] + 1'b1;
    end
  end
endmodule

`default_nettype wire
