// =============================================================================
// SilicaFlux Shared Memory :: sf_smem_bank
// One 32-bit-wide bank: 1R1W array + two-stage pipeline with write forwarding
// and the word-level atomic unit.
//
//   cycle t   (S0) request presented  : row, op, be, wdata, cmp ; array READ of row
//   cycle t+1 (S1) old word available : forward-mux -> sf_smem_atomic -> array WRITE
//                  rsp_rdata = old word (value BEFORE this operation), valid in t+1
//
// Throughput: one operation per cycle, INCLUDING back-to-back atomics on the
// same word.  This needs a 1R1W array (read of the next operation and write of
// the current one happen at the same edge) and the forward registers below:
// an operation in S1 reads `old` from the forward register when the previous
// operation wrote the same row at the previous edge.  Correctness therefore does
// not depend on the array's read-during-write behaviour (read-first, write-first
// and "undefined" RAMs all work) because a forward hit always overrides rd_q.
//
// A single-port (1RW) macro would force every atomic to occupy its bank for two
// cycles; that variant is NOT implemented here (docs/KNOWN_LIMITATIONS.md).
//
// The array is not reset.  INIT_ON_RESET in the top level zero-fills it through
// init_we/init_row; the testbenches never rely on array contents otherwise.
//
// Classification: SYNTHESIZABLE (array infers a 1R1W memory; byte write mask).
// =============================================================================
`include "sf_smem_defs.svh"
`default_nettype none

module sf_smem_bank #(
  parameter int DEPTH = 256
) (
  input  logic                         clk,
  input  logic                         rst_n,
  // initialisation sweep (top level guarantees req_valid = 0 while it runs)
  input  logic                         init_we,
  input  logic [$clog2(DEPTH)-1:0]     init_row,
  // request, S0
  input  logic                         req_valid,
  input  logic [1:0]                   req_op,
  input  logic [$clog2(DEPTH)-1:0]     req_row,
  input  logic [3:0]                   req_be,
  input  logic [31:0]                  req_wdata,
  input  logic [31:0]                  req_cmp,
  // response, S1 (one cycle after the request)
  output logic                         rsp_valid,
  output logic [31:0]                  rsp_rdata
);
  localparam int R = $clog2(DEPTH);

  logic [31:0] mem [0:DEPTH-1];

  // ---- S1 registers ------------------------------------------------------------
  logic         s1_valid;
  logic [1:0]   s1_op;
  logic [R-1:0] s1_row;
  logic [3:0]   s1_be;
  logic [31:0]  s1_wdata, s1_cmp;
  logic [31:0]  rd_q;

  // ---- forward registers: the write performed at the previous edge --------------
  logic         fwd_valid;
  logic [R-1:0] fwd_row;
  logic [31:0]  fwd_word;

  logic [31:0]  old, newword;
  logic         alu_wr, do_wr, fwd_hit;
  logic [3:0]   wbe;
  logic [31:0]  wdat;
  integer       wi;

  assign fwd_hit = fwd_valid && (fwd_row == s1_row);
  assign old     = fwd_hit ? fwd_word : rd_q;

  sf_smem_atomic u_alu (
    .op(s1_op), .old(old), .wdata(s1_wdata), .cmp(s1_cmp), .be(s1_be),
    .newword(newword), .wr(alu_wr)
  );

  assign do_wr = s1_valid & alu_wr;
  // plain stores write only the enabled bytes; atomics write the whole word
  assign wbe  = (s1_op == 2'd1) ? s1_be : 4'hF;
  assign wdat = (s1_op == 2'd1) ? s1_wdata : newword;

  assign rsp_valid = s1_valid;
  assign rsp_rdata = old;

  // ---- control state (reset) -----------------------------------------------------
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      s1_valid  <= 1'b0;
      fwd_valid <= 1'b0;
    end else begin
      s1_valid  <= req_valid;
      fwd_valid <= do_wr;
    end
  end

  // ---- datapath registers + array (no reset) --------------------------------------
  always_ff @(posedge clk) begin
    if (req_valid) begin
      s1_op    <= req_op;
      s1_row   <= req_row;
      s1_be    <= req_be;
      s1_wdata <= req_wdata;
      s1_cmp   <= req_cmp;
      rd_q     <= mem[req_row];
    end
    if (do_wr) begin
      fwd_row  <= s1_row;
      fwd_word <= newword;   // full post-operation word (for STORE: old merged with enabled bytes)
    end
    if (rst_n && init_we) begin
      mem[init_row] <= 32'h0;
    end else if (rst_n && do_wr) begin
      for (wi = 0; wi < 4; wi = wi + 1)
        if (wbe[wi]) mem[s1_row][8*wi +: 8] <= wdat[8*wi +: 8];
    end
  end

`ifndef SYNTHESIS
  // sim-only protocol checks
  always @(posedge clk) begin
    if (rst_n && init_we && req_valid)
      $fatal(1, "sf_smem_bank: request presented during initialisation sweep");
  end
`endif
endmodule

`default_nettype wire
