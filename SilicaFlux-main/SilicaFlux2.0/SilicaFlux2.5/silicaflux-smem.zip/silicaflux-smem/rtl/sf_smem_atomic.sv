// =============================================================================
// SilicaFlux Shared Memory :: sf_smem_atomic
// The word-level read-modify-write unit that sits behind every bank read.
// Purely combinational.  This module IS the definition of the supported
// operations; adding an atomic means adding one case here, one opcode in
// sf_smem_defs.svh, one clause in the decode legality check and one line in
// docs/SEMANTICS.md.  Everything else (arbitration, forwarding, routing) is
// operation-agnostic.
//
//   op        new word                           returned value   array write
//   LOAD      old                                old              none
//   STORE     old with enabled bytes replaced    (not used)       if be != 0
//   ADD       old + wdata  (mod 2**32)           old              always
//   CAS       (old == cmp) ? wdata : old         old              only on match
//
// ADD is plain two's-complement modular addition: bit-identical for signed and
// unsigned interpretations, no overflow flag, no saturation.  CAS compares the
// full 32-bit pattern for equality (so signedness is irrelevant).  A CAS that
// fails leaves memory untouched; success is observable to software as
// (returned value == cmp).
//
// Classification: SYNTHESIZABLE.
// =============================================================================
`include "sf_smem_defs.svh"
`default_nettype none

module sf_smem_atomic (
  input  logic [1:0]  op,        // low two bits of the lane opcode (0..3 only reach here)
  input  logic [31:0] old,       // current word, after write-forwarding
  input  logic [31:0] wdata,     // STORE data / ADD addend / CAS desired value
  input  logic [31:0] cmp,       // CAS expected value
  input  logic [3:0]  be,        // STORE byte enables (atomics are always 4'b1111)
  output logic [31:0] newword,   // word value in the array after this operation
  output logic        wr         // array must be written
);
  logic [31:0] merged;
  logic        hit;
  integer      ai;

  always_comb begin
    merged = old;
    for (ai = 0; ai < 4; ai = ai + 1)
      if (be[ai]) merged[8*ai +: 8] = wdata[8*ai +: 8];
    hit = (old == cmp);

    newword = old;
    wr      = 1'b0;
    case (op)
      2'd0: begin newword = old;                   wr = 1'b0;     end // LOAD
      2'd1: begin newword = merged;                wr = |be;      end // STORE
      2'd2: begin newword = old + wdata;           wr = 1'b1;     end // ADD
      2'd3: begin newword = hit ? wdata : old;     wr = hit;      end // CAS
      default: begin newword = old;                wr = 1'b0;     end
    endcase
  end
endmodule

`default_nettype wire
