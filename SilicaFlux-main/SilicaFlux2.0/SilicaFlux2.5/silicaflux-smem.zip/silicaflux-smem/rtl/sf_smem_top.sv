// =============================================================================
// SilicaFlux Shared Memory (SFSM) :: sf_smem_top
//
//   NP request ports --decode--> [req FIFO per port] --port arbiter--> ACTIVE
//   request register --issue/bank arbitration--> NB banks (1R1W, atomic unit)
//   --> response assembly --> [rsp FIFO per port] --> NP response ports
//
// One request = up to NL lane operations with per-lane valid.  The request is
// the unit of arbitration between ports; within a request the lanes are
// arbitrated per bank every cycle (sf_smem_issue).  Requests are executed one at
// a time, in grant order, and each request is executed completely (all its lane
// groups are issued in consecutive cycles) before the next one starts.  This is a
// property of THIS implementation, not an architectural guarantee: software must
// not rely on it (docs/SEMANTICS.md section 5.3).
//
// Normative semantics: docs/SEMANTICS.md.  Microarchitecture: docs/ARCHITECTURE.md.
//
// Timing (no conflicts, no backpressure): a request accepted at the end of cycle
// A is granted at A+1, issued at A+2, returns bank data at A+3, and its response
// is visible at the port in cycle A+4  (LAT_MIN = 4).  A request whose worst
// bank serves d groups (d >= 1) responds in cycle A+3+d.
//
// Bounded buffering: req FIFO (REQ_DEPTH) per port, rsp FIFO (RSP_DEPTH) per
// port, one active request register, a one-stage bank pipeline, one response
// assembly register.  A request is granted only if its port holds a response
// credit, so response FIFOs can never overflow and the bank pipeline never
// stalls; a port that stops draining responses only blocks itself.
//
// Barriers are NOT handled here.  The only visibility aid is the per-port
// `outstanding` count (accepted requests whose response was not yet consumed),
// from which a client builds its fence (docs/FENCES_AND_BARRIERS.md).
//
// Interfaces are flattened packed vectors: field of port p / lane l lives at
//   index (p*NL + l) * WIDTH +: WIDTH       (per-lane fields)
//   index  p * WIDTH         +: WIDTH       (per-port fields)
//
// Reset (rst_n, synchronous, active low): all control state is cleared, all
// outstanding requests are DROPPED without response, and - if INIT_ON_RESET - the
// arrays are zero-filled (init_busy high, req_ready low for DEPTH cycles).
//
// Classification: SYNTHESIZABLE (simulation-only checks under `ifndef SYNTHESIS`).
// =============================================================================
`include "sf_smem_defs.svh"
`default_nettype none

module sf_smem_top #(
  parameter int NL            = 8,     // lanes per request, >= 2
  parameter int NB            = 8,     // banks, power of two >= 2
  parameter int DEPTH         = 256,   // words per bank, power of two >= 2
  parameter int NP            = 2,     // request ports, >= 1
  parameter int REQ_DEPTH     = 2,     // request FIFO entries per port, >= 1
  parameter int RSP_DEPTH     = 4,     // response FIFO entries / credits per port, >= 1
  parameter int TAGW          = 8,     // request tag width
  parameter int AW            = 32,    // lane byte-address width
  parameter int MAPPING       = 0,     // SF_MAP_*
  parameter int BLK_LOG2      = 1,     // granule for SF_MAP_BLOCK
  parameter int LANE_ARB      = 1,     // 0 lowest lane first, 1 rotating (per bank)
  parameter int PORT_ARB      = 1,     // 0 fixed priority (port 0 highest), 1 round robin
  parameter int WRITE_COMBINE = 1,     // merge same-word store runs into one bank write
  parameter int INIT_ON_RESET = 1,     // zero-fill arrays after reset
  parameter int PERF_EN       = 1      // performance counters
) (
  input  logic                         clk,
  input  logic                         rst_n,

  // ---- request ports --------------------------------------------------------------
  input  logic [NP-1:0]                req_valid,
  output logic [NP-1:0]                req_ready,
  input  logic [NP*TAGW-1:0]           req_tag,
  input  logic [NP*NL-1:0]             req_lane_valid,
  input  logic [NP*NL*3-1:0]           req_op,
  input  logic [NP*NL*AW-1:0]          req_addr,
  input  logic [NP*NL*4-1:0]           req_be,
  input  logic [NP*NL*32-1:0]          req_wdata,
  input  logic [NP*NL*32-1:0]          req_cmp,

  // ---- response ports (in order per port; held stable until accepted) --------------
  output logic [NP-1:0]                rsp_valid,
  input  logic [NP-1:0]                rsp_ready,
  output logic [NP*TAGW-1:0]           rsp_tag,
  output logic [NP*NL-1:0]             rsp_lane_valid,
  output logic [NP*NL*3-1:0]           rsp_status,
  output logic [NP*NL*32-1:0]          rsp_data,

  // ---- status / fence helpers ---------------------------------------------------------
  output logic                         init_busy,
  output logic [NP*$clog2(REQ_DEPTH+RSP_DEPTH+2)-1:0] outstanding,
  output logic [NP-1:0]                port_idle,     // outstanding == 0
  output logic                         quiescent,     // everything idle, init done

  // ---- performance counters (PERF_EN) ---------------------------------------------------
  // index: 0 active_cycles  1 requests  2 conflict_cycles  3 bank_groups
  //        4 lanes_served   5 atomic_lanes  6 error_lanes   7 credit_stall_cycles
  //        8+p grants[p]    8+NP+p wait_cycles[p]    8+2NP+b bank_busy[b]
  output logic [(8+2*NP+NB)*32-1:0]    perf
);
  // ---- derived constants -----------------------------------------------------------------
  localparam int BW     = $clog2(NB);
  localparam int RW     = $clog2(DEPTH);
  localparam int WIDX_W = BW + RW;
  localparam int PW     = (NP > 1) ? $clog2(NP) : 1;
  localparam int CW     = $clog2(RSP_DEPTH + 1);
  localparam int OW     = $clog2(REQ_DEPTH + RSP_DEPTH + 2);
  localparam int NCNT   = 8 + 2*NP + NB;
  /* verilator lint_off UNUSEDPARAM */
  localparam int LAT_MIN = 4;     // documented latency, request accept -> response visible
  /* verilator lint_on UNUSEDPARAM */

  // request-entry layout (field major)
  localparam int W_CMP = NL*32,  O_CMP  = 0;
  localparam int W_WD  = NL*32,  O_WD   = O_CMP  + W_CMP;
  localparam int W_BE  = NL*4,   O_BE   = O_WD   + W_WD;
  localparam int W_ROW = NL*RW,  O_ROW  = O_BE   + W_BE;
  localparam int W_BNK = NL*BW,  O_BNK  = O_ROW  + W_ROW;
  localparam int W_OP  = NL*2,   O_OP   = O_BNK  + W_BNK;
  localparam int W_ST  = NL*3,   O_ST   = O_OP   + W_OP;
  localparam int W_ACT = NL,     O_ACT  = O_ST   + W_ST;
  localparam int W_PND = NL,     O_PND  = O_ACT  + W_ACT;
  localparam int W_TAG = TAGW,   O_TAG  = O_PND  + W_PND;
  localparam int EW    = O_TAG + W_TAG;

  localparam int RSPW  = TAGW + NL + NL*3 + NL*32;

  // ---- elaboration-time checks ---------------------------------------------------------------
  initial begin
    if (NL < 2)                       $fatal(1, "sf_smem_top: NL=%0d must be >= 2", NL);
    if (NB < 2 || (NB & (NB-1)) != 0) $fatal(1, "sf_smem_top: NB=%0d must be a power of two >= 2", NB);
    if (DEPTH < 2 || (DEPTH & (DEPTH-1)) != 0)
                                      $fatal(1, "sf_smem_top: DEPTH=%0d must be a power of two >= 2", DEPTH);
    if (NP < 1 || REQ_DEPTH < 1 || RSP_DEPTH < 1)
                                      $fatal(1, "sf_smem_top: NP/REQ_DEPTH/RSP_DEPTH must be >= 1");
    if (AW < WIDX_W + 2)              $fatal(1, "sf_smem_top: AW=%0d too small, need >= %0d", AW, WIDX_W + 2);
    if (MAPPING == `SF_MAP_BLOCK && (BLK_LOG2 < 0 || BLK_LOG2 > RW))
                                      $fatal(1, "sf_smem_top: BLK_LOG2=%0d must be in [0,%0d]", BLK_LOG2, RW);
  end

  // ===========================================================================================
  // Per-port decode + request FIFO
  // ===========================================================================================
  logic [NP-1:0]  rf_full, rf_empty;
  wire  [EW-1:0]  h_data [0:NP-1];
  logic [NP-1:0]  rf_pop;

  genvar p, l;
  generate
    for (p = 0; p < NP; p++) begin : g_port
      logic [NL-1:0]    d_pend, d_act;
      logic [NL*3-1:0]  d_stat;
      logic [NL*2-1:0]  d_op;
      logic [NL*BW-1:0] d_bank;
      logic [NL*RW-1:0] d_row;
      logic [EW-1:0]    d_entry;
      logic             push;

      for (l = 0; l < NL; l++) begin : g_lane
        wire [AW-1:0] a    = req_addr[(p*NL+l)*AW +: AW];
        wire [2:0]    o    = req_op  [(p*NL+l)*3  +: 3];
        wire [3:0]    be_l = req_be  [(p*NL+l)*4  +: 4];
        wire          lv   = req_lane_valid[p*NL + l];

        wire [BW-1:0] bnk;
        wire [RW-1:0] rw;
        /* verilator lint_off PINCONNECTEMPTY */
        sf_smem_bankmap #(.NB(NB), .DEPTH(DEPTH), .MAPPING(MAPPING), .BLK_LOG2(BLK_LOG2)) u_map (
          .widx(a[2 +: WIDX_W]), .bank(bnk), .row(rw),
          .ibank('0), .irow('0), .iwidx()
        );
        /* verilator lint_on PINCONNECTEMPTY */

        wire misal = |a[1:0];
        wire oor;
        if (AW > WIDX_W + 2) begin : g_hi
          assign oor = |a[AW-1 : WIDX_W+2];
        end else begin : g_nohi
          assign oor = 1'b0;
        end
        wire isatom = (o == `SF_OP_ADD) || (o == `SF_OP_CAS);
        wire badop  = o[2];
        wire bebad  = isatom && (be_l != 4'hF);

        // status precedence: BADOP > ALIGN > RANGE > BE
        wire [2:0] st = !lv    ? `SF_ST_OK    :
                        badop  ? `SF_ST_BADOP :
                        misal  ? `SF_ST_ALIGN :
                        oor    ? `SF_ST_RANGE :
                        bebad  ? `SF_ST_BE    : `SF_ST_OK;
        // plain load/store with no byte enabled is an accepted no-op: no bank access
        wire nop = lv && (st == `SF_ST_OK) && !isatom && (be_l == 4'h0);

        assign d_act [l]            = lv;
        assign d_stat[l*3 +: 3]     = st;
        assign d_pend[l]            = lv && (st == `SF_ST_OK) && !nop;
        assign d_op  [l*2 +: 2]     = o[1:0];
        assign d_bank[l*BW +: BW]   = bnk;
        assign d_row [l*RW +: RW]   = rw;
      end

      assign d_entry = { req_tag[p*TAGW +: TAGW],
                         d_pend, d_act, d_stat, d_op, d_bank, d_row,
                         req_be   [p*NL*4  +: NL*4],
                         req_wdata[p*NL*32 +: NL*32],
                         req_cmp  [p*NL*32 +: NL*32] };

      assign push         = req_valid[p] && req_ready[p];
      assign req_ready[p] = !init_busy && !rf_full[p];

      sf_smem_fifo #(.W(EW), .DEPTH(REQ_DEPTH)) u_reqf (
        .clk(clk), .rst_n(rst_n),
        .push(push), .din(d_entry),
        .pop(rf_pop[p]), .dout(h_data[p]),
        .empty(rf_empty[p]), .full(rf_full[p]), .count()
      );
    end
  endgenerate

  // ===========================================================================================
  // Port arbitration (request granularity) with response credits
  // ===========================================================================================
  logic [CW-1:0]  cred   [0:NP-1];
  logic [NP-1:0]  elig;
  logic [PW-1:0]  port_ptr;
  logic [PW-1:0]  sel;
  logic           any_elig;
  logic           act_valid, act_last, load;
  logic [EW-1:0]  sel_data;

  integer aq;
  always_comb begin
    for (aq = 0; aq < NP; aq = aq + 1)
      elig[aq] = !rf_empty[aq] && (cred[aq] != '0);

    sel = '0; any_elig = 1'b0;
    if (PORT_ARB != 0) begin
      for (aq = 0; aq < NP; aq = aq + 1)
        if (!any_elig && elig[aq] && (aq >= port_ptr)) begin sel = PW'(aq); any_elig = 1'b1; end
    end
    for (aq = 0; aq < NP; aq = aq + 1)
      if (!any_elig && elig[aq]) begin sel = PW'(aq); any_elig = 1'b1; end

    sel_data = '0;
    for (aq = 0; aq < NP; aq = aq + 1)
      if (sel == PW'(aq)) sel_data = h_data[aq];
  end

  assign load = any_elig && (!act_valid || act_last);

  generate
    for (p = 0; p < NP; p++) begin : g_pop
      assign rf_pop[p] = load && (sel == PW'(p));
    end
  endgenerate

  // ===========================================================================================
  // Active request register
  // ===========================================================================================
  logic [PW-1:0]    act_port;
  logic [TAGW-1:0]  act_tag;
  logic [NL-1:0]    act_act, pend_q;
  logic [NL*3-1:0]  act_stat;
  logic [NL*2-1:0]  act_op;
  logic [NL*BW-1:0] act_bank;
  logic [NL*RW-1:0] act_row;
  logic [NL*4-1:0]  act_be;
  logic [NL*32-1:0] act_wd, act_cmp;
  logic             first_q;

  // issue outputs
  logic [NB-1:0]       b_valid;
  logic [NB*2-1:0]     b_op;
  logic [NB*RW-1:0]    b_row;
  logic [NB*4-1:0]     b_be;
  logic [NB*32-1:0]    b_wdata, b_cmp;
  logic [NL-1:0]       served;
  logic [NL*4-1:0]     rmask;
  logic                iss_last;

  assign act_last = act_valid && iss_last;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      act_valid <= 1'b0;
      first_q   <= 1'b0;
      port_ptr  <= '0;
    end else begin
      if (load) begin
        act_valid <= 1'b1;
        first_q   <= 1'b1;
        port_ptr  <= (sel == PW'(NP-1)) ? '0 : sel + 1'b1;
      end else if (act_last) begin
        act_valid <= 1'b0;
      end else if (act_valid) begin
        first_q   <= 1'b0;
      end
    end
  end

  always_ff @(posedge clk) begin
    if (load) begin
      act_port <= sel;
      act_tag  <= sel_data[O_TAG +: W_TAG];
      act_act  <= sel_data[O_ACT +: W_ACT];
      act_stat <= sel_data[O_ST  +: W_ST];
      act_op   <= sel_data[O_OP  +: W_OP];
      act_bank <= sel_data[O_BNK +: W_BNK];
      act_row  <= sel_data[O_ROW +: W_ROW];
      act_be   <= sel_data[O_BE  +: W_BE];
      act_wd   <= sel_data[O_WD  +: W_WD];
      act_cmp  <= sel_data[O_CMP +: W_CMP];
      pend_q   <= sel_data[O_PND +: W_PND];
    end else if (act_valid) begin
      pend_q   <= pend_q & ~served;
    end
  end

  // ===========================================================================================
  // Issue / bank arbitration
  // ===========================================================================================
  sf_smem_issue #(.NL(NL), .NB(NB), .ROW_W(RW), .LANE_ARB(LANE_ARB), .WRITE_COMBINE(WRITE_COMBINE)) u_issue (
    .clk(clk), .rst_n(rst_n), .issuing(act_valid),
    .pend(act_valid ? pend_q : {NL{1'b0}}),
    .op(act_op), .bank(act_bank), .row(act_row), .be(act_be), .wdata(act_wd), .cmp(act_cmp),
    .b_valid(b_valid), .b_op(b_op), .b_row(b_row), .b_be(b_be), .b_wdata(b_wdata), .b_cmp(b_cmp),
    .served(served), .rmask(rmask), .last(iss_last)
  );

  // ===========================================================================================
  // Initialisation sweep
  // ===========================================================================================
  logic [RW-1:0] init_row;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      init_busy <= (INIT_ON_RESET != 0);
      init_row  <= '0;
    end else if (init_busy) begin
      if (init_row == RW'(DEPTH-1)) begin
        init_busy <= 1'b0;
        init_row  <= '0;
      end else begin
        init_row  <= init_row + 1'b1;
      end
    end
  end

  // ===========================================================================================
  // Banks
  // ===========================================================================================
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NB-1:0]    bk_rv;          // bank response valid (== registered b_valid); informational
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NB*32-1:0] bk_rdata;

  generate
    for (genvar b = 0; b < NB; b++) begin : g_bank
      sf_smem_bank #(.DEPTH(DEPTH)) u_bank (
        .clk(clk), .rst_n(rst_n),
        .init_we(init_busy), .init_row(init_row),
        .req_valid(b_valid[b]),
        .req_op(b_op[b*2 +: 2]), .req_row(b_row[b*RW +: RW]), .req_be(b_be[b*4 +: 4]),
        .req_wdata(b_wdata[b*32 +: 32]), .req_cmp(b_cmp[b*32 +: 32]),
        .rsp_valid(bk_rv[b]), .rsp_rdata(bk_rdata[b*32 +: 32])
      );
    end
  endgenerate

  // ===========================================================================================
  // Group record (aligned with the bank S1 stage) and response assembly
  // ===========================================================================================
  logic              g1_valid, g1_first, g1_last;
  logic [PW-1:0]     g1_port;
  logic [TAGW-1:0]   g1_tag;
  logic [NL-1:0]     g1_served, g1_act;
  logic [NL*4-1:0]   g1_rmask;
  logic [NL*BW-1:0]  g1_bank;
  logic [NL*3-1:0]   g1_stat;

  always_ff @(posedge clk) begin
    if (!rst_n) g1_valid <= 1'b0;
    else        g1_valid <= act_valid;
  end
  always_ff @(posedge clk) begin
    g1_first  <= first_q;
    g1_last   <= act_last;
    g1_port   <= act_port;
    g1_tag    <= act_tag;
    g1_served <= served;
    g1_rmask  <= rmask;
    g1_bank   <= act_bank;
    g1_act    <= act_act;
    g1_stat   <= act_stat;
  end

  logic [NL*32-1:0] asm_q, asm_nxt;
  logic [31:0]      t_ld, t_base, t_m;
  integer ak, ai;
  always_comb begin
    for (ak = 0; ak < NL; ak = ak + 1) begin
      t_ld = bk_rdata[g1_bank[ak*BW +: BW] * 32 +: 32];
      for (ai = 0; ai < 4; ai = ai + 1) t_m[8*ai +: 8] = {8{g1_rmask[ak*4 + ai]}};
      t_base = g1_first ? 32'h0 : asm_q[ak*32 +: 32];
      asm_nxt[ak*32 +: 32] = g1_served[ak] ? (t_ld & t_m) : t_base;
    end
  end
  always_ff @(posedge clk) if (g1_valid) asm_q <= asm_nxt;

  // ===========================================================================================
  // Response FIFOs, credits, outstanding counters
  // ===========================================================================================
  logic [NP-1:0] rf_rsp_empty, rf_rsp_full, rsp_pop, rsp_push;
  logic [OW-1:0] outst  [0:NP-1];

  generate
    for (p = 0; p < NP; p++) begin : g_rsp
      logic [RSPW-1:0] dout;
      assign rsp_push[p] = g1_valid && g1_last && (g1_port == PW'(p));
      sf_smem_fifo #(.W(RSPW), .DEPTH(RSP_DEPTH)) u_rspf (
        .clk(clk), .rst_n(rst_n),
        .push(rsp_push[p]), .din({g1_tag, g1_act, g1_stat, asm_nxt}),
        .pop(rsp_pop[p]),   .dout(dout),
        .empty(rf_rsp_empty[p]), .full(rf_rsp_full[p]), .count()
      );
      assign rsp_valid[p]                  = !rf_rsp_empty[p];
      assign rsp_pop[p]                    = rsp_valid[p] && rsp_ready[p];
      assign rsp_data[p*NL*32 +: NL*32]    = dout[0 +: NL*32];
      assign rsp_status[p*NL*3 +: NL*3]    = dout[NL*32 +: NL*3];
      assign rsp_lane_valid[p*NL +: NL]    = dout[NL*32 + NL*3 +: NL];
      assign rsp_tag[p*TAGW +: TAGW]       = dout[NL*32 + NL*3 + NL +: TAGW];

      assign outstanding[p*OW +: OW]       = outst[p];
      assign port_idle[p]                  = (outst[p] == '0);
    end
  endgenerate

  integer fq;
  always_ff @(posedge clk) begin
    for (fq = 0; fq < NP; fq = fq + 1) begin
      if (!rst_n) begin
        cred[fq]  <= CW'(RSP_DEPTH);
        outst[fq] <= '0;
      end else begin
        cred[fq]  <= cred[fq]  - CW'(rf_pop[fq])  + CW'(rsp_pop[fq]);
        outst[fq] <= outst[fq] + OW'(req_valid[fq] && req_ready[fq]) - OW'(rsp_pop[fq]);
      end
    end
  end

  logic q_all_idle;
  integer iq;
  always_comb begin
    q_all_idle = 1'b1;
    for (iq = 0; iq < NP; iq = iq + 1) if (outst[iq] != '0) q_all_idle = 1'b0;
  end
  assign quiescent = !init_busy && !act_valid && !g1_valid && q_all_idle;

  // ===========================================================================================
  // Performance counters
  // ===========================================================================================
  generate
    if (PERF_EN != 0) begin : g_perf
      logic [31:0] c [0:NCNT-1];

      function automatic [31:0] popc_l(input logic [NL-1:0] v);
        integer i; reg [31:0] n;
        begin
          n = 0;
          for (i = 0; i < NL; i = i + 1) n = n + {31'b0, v[i]};
          popc_l = n;
        end
      endfunction
      function automatic [31:0] popc_b(input logic [NB-1:0] v);
        integer i; reg [31:0] n;
        begin
          n = 0;
          for (i = 0; i < NB; i = i + 1) n = n + {31'b0, v[i]};
          popc_b = n;
        end
      endfunction

      logic [NL-1:0] atomic_srv, err_l;
      logic          stall_any;
      integer        pq, pk;
      always_comb begin
        stall_any = 1'b0;
        for (pq = 0; pq < NP; pq = pq + 1) if (!rf_empty[pq] && cred[pq] == '0) stall_any = 1'b1;
        for (pk = 0; pk < NL; pk = pk + 1) atomic_srv[pk] = served[pk] && act_op[pk*2+1];
        for (pk = 0; pk < NL; pk = pk + 1)
          err_l[pk] = sel_data[O_ACT + pk] && (sel_data[O_ST + pk*3 +: 3] != 3'd0);
      end

      integer fi, fqq, fbb;
      always_ff @(posedge clk) begin
        if (!rst_n) begin
          for (fi = 0; fi < NCNT; fi = fi + 1) c[fi] <= 32'h0;
        end else begin
          if (act_valid)             c[0] <= c[0] + 32'd1;
          if (act_last)              c[1] <= c[1] + 32'd1;
          if (act_valid && !act_last) c[2] <= c[2] + 32'd1;
          c[3] <= c[3] + popc_b(b_valid);
          c[4] <= c[4] + popc_l(served);
          c[5] <= c[5] + popc_l(atomic_srv);
          if (load)                  c[6] <= c[6] + popc_l(err_l);
          if (stall_any)            c[7] <= c[7] + 32'd1;
          for (fqq = 0; fqq < NP; fqq = fqq + 1) begin
            if (rf_pop[fqq])                        c[8+fqq]    <= c[8+fqq] + 32'd1;
            if (!rf_empty[fqq] && !rf_pop[fqq])     c[8+NP+fqq] <= c[8+NP+fqq] + 32'd1;
          end
          for (fbb = 0; fbb < NB; fbb = fbb + 1)
            if (b_valid[fbb])                       c[8+2*NP+fbb] <= c[8+2*NP+fbb] + 32'd1;
        end
      end

      integer pi;
      always_comb for (pi = 0; pi < NCNT; pi = pi + 1) perf[pi*32 +: 32] = c[pi];
    end else begin : g_noperf
      assign perf = '0;
    end
  endgenerate

`ifndef SYNTHESIS
  // sim-only invariants
  integer cq;
  always @(posedge clk) begin
    if (rst_n) begin
      for (cq = 0; cq < NP; cq = cq + 1) begin
        if (rf_rsp_full[cq] && rsp_push[cq] && !rsp_pop[cq])
          $fatal(1, "sf_smem_top: response FIFO overflow on port %0d (credit scheme violated)", cq);
      end
      if (g1_valid && g1_last && ({{(32-PW){1'b0}}, g1_port} >= NP))
        $fatal(1, "sf_smem_top: response routed to non-existent port");
    end
  end
`endif
endmodule

`default_nettype wire
