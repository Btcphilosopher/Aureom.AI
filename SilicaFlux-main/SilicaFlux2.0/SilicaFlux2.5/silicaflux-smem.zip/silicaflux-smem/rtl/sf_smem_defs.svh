// =============================================================================
// SilicaFlux Shared Memory (SFSM) :: sf_smem_defs.svh
// Architectural encodings.  Macros (not a package) so that every tool in the
// flow (Verilator, Icarus, Yosys) sees the same constants without package
// support differences.  Normative text: docs/SEMANTICS.md.
// =============================================================================
`ifndef SF_SMEM_DEFS_SVH
`define SF_SMEM_DEFS_SVH

// ---- lane operation codes (3-bit field on the request interface) ------------
`define SF_OP_LOAD   3'd0   // load word, masked by byte enables
`define SF_OP_STORE  3'd1   // store enabled bytes
`define SF_OP_ADD    3'd2   // atomic integer add, returns old value
`define SF_OP_CAS    3'd3   // atomic compare-and-swap, returns old value
                            // 3'd4 .. 3'd7 : reserved -> ST_BADOP, no side effect

// ---- per-lane response status ------------------------------------------------
`define SF_ST_OK     3'd0
`define SF_ST_ALIGN  3'd1   // address not 4-byte aligned
`define SF_ST_RANGE  3'd2   // address >= capacity
`define SF_ST_BADOP  3'd3   // reserved / unsupported opcode
`define SF_ST_BE     3'd4   // atomic with byte enables != 4'b1111

// ---- bank mapping selectors (parameter MAPPING) -------------------------------
`define SF_MAP_LINEAR 0     // bank = w mod NB                  row = w / NB
`define SF_MAP_XOR    1     // bank = (w mod NB) ^ fold(w / NB) row = w / NB
`define SF_MAP_SKEW   2     // bank = (w + w / NB) mod NB       row = w / NB
`define SF_MAP_BLOCK  3     // 2**BLK_LOG2 consecutive words per bank

`define SF_DW 32            // word width (fixed: atomics are 32-bit)

`endif
