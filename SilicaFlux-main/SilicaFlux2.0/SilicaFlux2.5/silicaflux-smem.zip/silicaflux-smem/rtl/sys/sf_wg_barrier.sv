// =============================================================================
// SilicaFlux :: sf_wg_barrier   (reference workgroup barrier - NOT part of SFSM)
//
// A counter-free arrival-mask barrier for NW warps.  It is deliberately a
// separate block with NO connection to the shared-memory subsystem: bank
// arbitration never looks at barrier state and the barrier never looks at bank
// state.  Memory visibility around a barrier is the client's job:
//
//     fence (wait for SFSM `port_idle`)  ->  arrive  ->  wait for release
//
// See docs/FENCES_AND_BARRIERS.md.
//
//   member[w]   warp w takes part in the barrier (static while a barrier is open)
//   arrive[w]   one-cycle pulse: warp w reached the barrier (ignored if !member[w])
//   waiting[w]  level: warp w has arrived and the barrier has not released yet
//   release[w]  one-cycle pulse, the cycle AFTER the last member arrived
//
// Classification: SYNTHESIZABLE (sim-only check under `ifndef SYNTHESIS`).
// =============================================================================
`default_nettype none

module sf_wg_barrier #(
  parameter int NW = 4
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic [NW-1:0] member,
  input  logic [NW-1:0] arrive,
  output logic [NW-1:0] waiting,
  output logic [NW-1:0] release_o
);
  logic [NW-1:0] arrived_q, rel_q;
  wire  [NW-1:0] arr_eff   = arrive & member;
  wire  [NW-1:0] arrived_n = arrived_q | arr_eff;
  wire           complete  = (member != '0) && (arrived_n == member);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      arrived_q <= '0;
      rel_q     <= '0;
    end else begin
      rel_q     <= complete ? member : '0;
      arrived_q <= complete ? '0 : arrived_n;
    end
  end

  assign waiting   = arrived_q;
  assign release_o = rel_q;

`ifndef SYNTHESIS
  always @(posedge clk)
    if (rst_n && ((arrive & member & arrived_q) != '0))
      $fatal(1, "sf_wg_barrier: warp arrived twice at an open barrier");
`endif
endmodule

`default_nettype wire
