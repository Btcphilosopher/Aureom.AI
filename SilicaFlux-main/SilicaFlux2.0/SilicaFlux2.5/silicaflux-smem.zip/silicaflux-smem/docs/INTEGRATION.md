# Integrating SFSM (`rtl/sf_smem_top.sv`)

## 1. Files

```
rtl/sf_smem_defs.svh      opcode / status / mapping constants (macros, no package)
rtl/sf_smem_bankmap.sv    word index -> (bank,row) and inverse
rtl/sf_smem_atomic.sv     word-level LOAD/STORE/ADD/CAS unit
rtl/sf_smem_bank.sv       1R1W array + 2-stage pipeline + write forwarding
rtl/sf_smem_fifo.sv       FWFT FIFO (request and response buffering)
rtl/sf_smem_issue.sv      per-bank arbitration / broadcast / write combining
rtl/sf_smem_top.sv        the subsystem                      <- instantiate this
rtl/sys/sf_wg_barrier.sv  reference workgroup barrier (separate, optional)
```

Compile order: any (`defs.svh` via `-I rtl`). Tested with Verilator 5.020, Icarus 12.0, Yosys 0.33. All vectors on the port list are **flattened packed vectors** so no tool needs interface or struct support.

## 2. Ports

`NP` ports, `NL` lanes. `OW = clog2(REQ_DEPTH + RSP_DEPTH + 2)`.

| port | dir | width | meaning |
|---|---|---|---|
| `clk`, `rst_n` | in | 1 | clock; synchronous active-low reset |
| `req_valid[p]` | in | `NP` | request valid on port `p` |
| `req_ready[p]` | out | `NP` | accepted when `req_valid && req_ready`. **Registered-state function only** (never depends on `req_valid`). Low during the init sweep and when the port's request FIFO is full |
| `req_tag[p]` | in | `NP*TAGW` | echoed in the response |
| `req_lane_valid[p*NL+l]` | in | `NP*NL` | lane `l` active |
| `req_op[(p*NL+l)*3 +: 3]` | in | `NP*NL*3` | `0` LOAD, `1` STORE, `2` ADD, `3` CAS, `4-7` rejected |
| `req_addr[(p*NL+l)*AW +: AW]` | in | `NP*NL*AW` | **byte** address, 4-byte aligned |
| `req_be[(p*NL+l)*4 +: 4]` | in | `NP*NL*4` | byte enables (atomics: must be `4'hF`) |
| `req_wdata[(p*NL+l)*32 +: 32]` | in | `NP*NL*32` | store data / ADD addend / CAS desired value |
| `req_cmp[(p*NL+l)*32 +: 32]` | in | `NP*NL*32` | CAS expected value (ignored otherwise) |
| `rsp_valid[p]` | out | `NP` | response available; payload **held stable** until accepted |
| `rsp_ready[p]` | in | `NP` | consumer accepts (`rsp_valid && rsp_ready`) |
| `rsp_tag[p]` | out | `NP*TAGW` | tag of the request |
| `rsp_lane_valid[p*NL+l]` | out | `NP*NL` | lane was active in the request |
| `rsp_status[(p*NL+l)*3 +: 3]` | out | `NP*NL*3` | `0` OK, `1` ALIGN, `2` RANGE, `3` BADOP, `4` BE |
| `rsp_data[(p*NL+l)*32 +: 32]` | out | `NP*NL*32` | LOAD: masked word; ADD/CAS: old value; STORE and errors: 0 |
| `init_busy` | out | 1 | init sweep running (`INIT_ON_RESET`), `req_ready` is low |
| `outstanding[p*OW +: OW]` | out | `NP*OW` | requests accepted whose response has not been consumed |
| `port_idle[p]` | out | `NP` | `outstanding == 0` - the **fence** condition |
| `quiescent` | out | 1 | everything idle, init done |
| `perf[i*32 +: 32]` | out | `(8+2NP+NB)*32` | performance counters (`ARCHITECTURE.md` 10) |

There is **no combinational path** from any input to any output.

## 3. Handshake timing

```
 cycle        :  0     1     2     3     4     5
 req_valid[p] :  1     0     0     0     0     0
 req_ready[p] :  1                             (accept in cycle 0)
 rsp_valid[p] :  0     0     0     0     1     0       <- unloaded, conflict free: LAT_MIN = 4
 rsp_ready[p] :  x     x     x     x     1     x
                                          ^ response consumed in cycle 4
```

A request whose worst bank must serve `d` groups answers `3 + d` cycles after the accept. The consumer may delay `rsp_ready`; the response stays valid and unchanged, the port's credit stays used, other ports are unaffected.

## 4. How a load/store unit uses it

* **32-bit word access** at byte address `a` (a multiple of 4): `op = LOAD/STORE`, `be = 4'hF`.
* **Byte / half-word access** at byte address `a`: send `addr = a & ~3`, shift the data into the right byte lanes yourself and set `be` accordingly (`STORE byte at a+2`: `be = 4'b0100`, `wdata = {8'h0, v, 16'h0}`); a `LOAD` returns the whole word masked by `be`, shift it back down. The memory never shifts or sign-extends.
* **64-bit access** = two lane operations, or two requests; there is no 64-bit atomicity.
* **Atomics**: `ADD`: `wdata` = addend (two's complement; add `0xFFFFFFFF` to decrement). `CAS`: `cmp` = expected, `wdata` = desired; success iff the returned value equals `cmp`.
* **Partial warps**: clear `lane_valid` of the idle lanes. Their other fields may hold anything.
* **Errors** come back per lane in `rsp_status`; a request with an error lane still executes its other lanes.

## 5. Client rules

1. Hold `req_valid` and the whole payload stable until `req_ready` is seen. Do not raise `req_valid` while `rst_n` is low.
2. You may have up to `REQ_DEPTH + RSP_DEPTH` requests outstanding per port; beyond that `req_ready` stays low. Consume responses (`rsp_ready`) or your own port stops - other ports are not affected.
3. Responses of a port come back **in request order** with the request's tag.
4. **Visibility across ports / before a barrier: use the fence** (`port_idle`), see `FENCES_AND_BARRIERS.md`. A barrier alone does not order memory operations.
5. After a reset every outstanding request is lost; re-initialise your own bookkeeping. With `INIT_ON_RESET = 0` initialise the memory before reading it.

## 6. Instantiation

```systemverilog
sf_smem_top #(.NL(32), .NB(32), .DEPTH(256), .NP(2), .REQ_DEPTH(2), .RSP_DEPTH(4),
              .TAGW(8), .AW(20), .MAPPING(`SF_MAP_XOR),          // see docs/BENCHMARKS.md section 10
              .PORT_ARB(1), .WRITE_COMBINE(1), .INIT_ON_RESET(1)) smem (
  .clk(clk), .rst_n(rst_n),
  .req_valid(req_valid), .req_ready(req_ready), .req_tag(req_tag),
  .req_lane_valid(req_lane_valid), .req_op(req_op), .req_addr(req_addr),
  .req_be(req_be), .req_wdata(req_wdata), .req_cmp(req_cmp),
  .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_tag(rsp_tag),
  .rsp_lane_valid(rsp_lane_valid), .rsp_status(rsp_status), .rsp_data(rsp_data),
  .init_busy(init_busy), .outstanding(outstanding), .port_idle(port_idle),
  .quiescent(quiescent), .perf(perf));
```

`tb/tb_common.svh` is a complete, working example of driving the interface (tasks `lane`, `send`, `recv`, `xact`, fence waits in `tb_smem_system.sv`); `tb/tb_smem_replay.sv` shows a trace-driven client.

## 7. Sizing guidance (from `BENCHMARKS.md`)

| parameter | recommendation |
|---|---|
| `RSP_DEPTH` | **4** - the credit loop is 4 cycles; less than 4 limits one port to `RSP_DEPTH/4` requests per cycle |
| `REQ_DEPTH` | **2** - 1 halves the rate |
| `NB` | equal to `NL` for conventional 1 lane : 1 bank; random-address traffic averages 3.5 issue cycles per request at 32x32 and 2.7 at 64 banks |
| `MAPPING` | `LINEAR` unless the software accesses power-of-two strides / unpadded tile columns (`XOR`/`SKEW`); never combine software padding with a hashed mapping |
| `PORT_ARB` | `1` (round robin) unless strict priority is wanted; fixed priority starves lower ports |
| `PERF_EN` | `0` in a product build (saves ~7 % of the logic cells) |
