# SFSM architecture contract (normative)

This page defines what software and clients may rely on. `rtl/` implements it; `py/sfsm/ref.py` is its executable form (a ~40 line sequential interpreter); `tb/tb_smem_directed.sv` checks it with hand-computed expectations. Where a statement is a property of **this implementation only** and not of the architecture, it is labelled **[impl]**.

Labels used in all documents: **RTL-SIMULATION** (Verilator 5.020 and Icarus 12 runs in this package), **MODEL** (Python), **ASSUMED** (a choice with no external data behind it), **MEASURED** (a number printed by a run in this package). There is no silicon, no technology library and no timing signoff behind any statement in this package.

---------------------------------------------------------------------------------------------

## 1. Terms

| term | meaning |
|---|---|
| **request** | one transfer on a request port: up to `NL` lane operations, one tag. Lane `l` is *active* iff its `lane_valid` bit is set. |
| **lane operation** | `{op, addr, be, wdata, cmp}` of an active lane. |
| **word** | an aligned 32-bit location. The only unit that is ever atomic. |
| **port** | a request/response channel pair of one client (a warp scheduler, a DMA engine ...). `NP` ports. |
| **response** | exactly one per accepted request, on the same port, in request order, carrying the request's tag, a per-lane valid mask, per-lane status and per-lane data. |
| **performed** | the lane operation has taken its effect in the memory; see 5.4. |

## 2. Address space

* Lane addresses are **byte addresses** and must be **4-byte aligned** for every opcode. A sub-word access is expressed with the byte enables `be[3:0]` (bit *i* selects byte *i*, bits 7:0 being byte 0); there is no address-based byte shifting - that is the load/store unit's job.
* Capacity = `NB * DEPTH * 4` bytes. `addr >= capacity` is rejected (`ST_RANGE`).
* **The architectural address space does not depend on the bank mapping.** `MAPPING`/`BLK_LOG2` choose which words share a bank (and therefore which accesses conflict) but every mapping is a bijection of word index onto (bank,row), so a program observes the same memory under every mapping. **RTL-SIMULATION**: identical responses and memory images under six mappings for 20 workloads (`reports/regress_mappings.json`); bijection and bit-exact agreement with `py/sfsm/arch.py` for 12 (NB,DEPTH,mapping) variants over *all* word indices (`tb_smem_units`).
* After reset the array content is **zero** if `INIT_ON_RESET = 1`, otherwise **undefined** (section 9).

## 3. Operations

`op` is a 3-bit field. All four operations are single-copy atomic on their word (section 4).

| op | code | operands | effect on the word | value returned in `rsp_data` | `be` rule |
|---|---|---|---|---|---|
| `LOAD` | 0 | `be` | none | the word with the **disabled bytes forced to zero** (`word & expand(be)`) | any; `be = 0` is an accepted no-op returning 0 |
| `STORE` | 1 | `wdata`, `be` | the enabled bytes are replaced | **0** (the response is an acknowledgement) | any; `be = 0` is an accepted no-op |
| `ATOMIC_ADD` | 2 | `wdata` | `new = (old + wdata) mod 2^32` | **`old`** | must be `4'b1111`, else `ST_BE` |
| `ATOMIC_CAS` | 3 | `cmp` (expected), `wdata` (desired) | `new = (old == cmp) ? wdata : old` | **`old`**, always | must be `4'b1111`, else `ST_BE` |
| reserved | 4-7 | - | none | 0, `ST_BADOP` | - |

### 3.1 Atomic add

* **Arithmetic**: two's-complement modular addition on 32 bits. The result is bit-identical whether software reads the operands as signed or unsigned. There is **no overflow/carry flag, no trap and no saturation**; `0xFFFFFFFF + 1 = 0` and `0x7FFFFFFF + 0x80000000 = 0xFFFFFFFF` (tested, D06). A decrement is an add of `0xFFFFFFFF`.
* **Return value**: the word as it was immediately before this lane's add, *including the effect of every lower lane of the same request on the same word* (section 5.1).
* **Signedness**: not applicable to ADD. Operations whose result depends on signedness (min, max, saturating add, compare-and-update) are **not provided** (section 12).

### 3.2 Compare-and-swap

* **Comparison**: full 32-bit **bit-pattern equality** (`old == cmp`). Signedness plays no role; `0x80000000` and `0xFFFFFFFF` are ordinary patterns (tested, D07).
* **Return value**: always `old`. A CAS has succeeded **iff** the returned value equals `cmp`; a failed CAS leaves the word unmodified and still returns the value that made it fail. There is no separate success flag (it would carry no information that software does not already have).
* **Idempotent success**: `desired == expected` is a success that rewrites the same value (and is observable by lanes behind it in lane order only through the value, which does not change).
* **ABA**: not detected. CAS compares values only.

### 3.3 Alignment and width

Atomics are exactly one aligned word wide. There is no 8/16/64-bit atomic, no atomic across two words, and no atomic on a partially enabled word (`ST_BE`). An unaligned atomic is `ST_ALIGN`.

## 4. Atomicity scope

1. **Granularity: one word.** While a lane operation executes, no other access to the same word - from any lane of any request on any port of this SFSM instance - is ordered between its read and its write. Plain loads and stores are word-atomic in the same sense: a load never observes some bytes of one store and some of another store to the same word *unless* the stores were separate operations (e.g. `be = 0011` from one lane then `be = 1100` from another) and the load is ordered between them by section 5.
2. **Scope: one SFSM instance.** Atomicity is with respect to accesses made through this instance's ports. It does not extend to another SM's shared memory, to global memory, or to a DMA path that bypasses the ports.
3. **No multi-word atomicity** of any kind (no double-word CAS, no transactions, no locks other than ones software builds from CAS).
4. **No ordering of plain loads/stores versus other words** is implied by an atomic: there is no acquire/release effect attached to the atomic opcodes (section 10).

## 5. Ordering

### 5.1 Within one request: ascending lane order

> The lane operations of a request that address the **same word** take effect **as if executed one after the other in ascending lane index**. Each lane observes the effect of every lower active lane on that word and of no higher lane. Operations on **different** words are unordered with respect to each other (this is unobservable).

Consequences, all **RTL-SIMULATION** checked (directed tests D02-D08, 722 trace-replay runs against the cycle model, and 11 320 random requests against the sequential reference in `py/tests`):

| lanes (same word, in lane order) | result |
|---|---|
| `ADD 1` x 8 on 100 | lanes return 100, 101, ... 107; final 108 |
| `ST 5`, `ADD 1`, `LD`, `CAS(6->100)`, `LD` | returns 0, 5, 6, 6, 100; final 100 |
| `LD`, `ST 2222`, `LD`, `ST(byte0=FF)`, `LD` | the loads return old, `2222`, `22FF` |
| `CAS(7->8)`, `CAS(7->99)`, `CAS(8->9)`, `CAS(9->9)`, `ADD -1` | returns 7, 8, 8, 9, 9; final 8 |

### 5.2 Between requests of one port

Requests of one port take effect in **acceptance order** and their **responses are returned in the same order**. An implementation may overlap them but must be indistinguishable from executing them one after the other.

### 5.3 Between ports

* **Per word there is one total order** of all operations from all ports, consistent with 5.1 and 5.2 (coherence order). This is the only cross-port ordering the *architecture* promises, apart from causality through responses (5.4).
* **[impl] Request atomicity / sequential consistency.** This implementation executes **whole requests one at a time** in a single global order (the grant order). Hence it is also sequentially consistent at request granularity across words, and a request is never interleaved with another port's request. Software **must not** rely on this - a future implementation may issue several requests concurrently. The fence rules of section 10 are the portable way to order accesses.
* Which port is granted next is the port arbiter's choice (`PORT_ARB`: fixed priority or round robin). It is deterministic, and **no ordering between ports follows from it**.

### 5.4 Performed, responses and causality

* A lane operation is *performed* when it takes effect on the word. Every access whose request is **granted** later in the global order observes it.
* **A response is returned only after every lane operation of its request has been performed.** For a store, the response is therefore the acknowledgement that the data is visible.
* **Causal visibility rule (portable):** if client A observes the response of an operation X, and then (causally after) any client presents a request Y, then Y observes X or something later in the word's order. This is what a fence relies on (section 10).

## 6. Conflicting writes - deterministic, nothing rejected

Writes to one word from several lanes of one request are **not** an error and **not** a race: they are resolved by 5.1.

| situation | result |
|---|---|
| several `STORE` lanes, overlapping byte enables | **per byte, the highest active lane that enables that byte wins** (equivalently: the last store in ascending lane order). Example D02: lanes 0..4 store `0101..`/`be 0011`, `0202..`/`0110`, `0303..`/`1000`, (lane 3 inactive, ignored), `0404..`/`0001` -> `0x03020204`. |
| `STORE` and `ADD`/`CAS` on one word in one request | executed in lane order (the atomic sees the store if the store is a lower lane). |
| several `ADD`/`CAS` on one word | executed one after the other in lane order; each returns the value it saw. |
| across requests (same port) | the later request wins (5.2). |
| across requests (different ports) | the later one in the word's total order wins; which one that is depends on arbitration, see 5.3. |

Byte-level mixing is the only place where "last writer wins" is per *byte*: two stores with disjoint byte enables both take effect. Merging same-word store runs into a single array write (`WRITE_COMBINE`) is a performance optimisation that is **indistinguishable** from serial execution (`py/tests`: stepwise-equals-sequential on random requests for every configuration with `WRITE_COMBINE` 0 and 1; directed test D02 with `WRITE_COMBINE` 0 and 1).

**Rejected, with no side effect** (section 7): misaligned address, address out of range, reserved opcode, atomic with `be != 4'b1111`. There is no other unsupported case.

## 7. Rejection and status

Every active lane gets a 3-bit status. A rejected lane has **no side effect on memory**, returns data 0 and does **not** disturb the other lanes of its request (they execute normally; D10).

| status | code | condition |
|---|---|---|
| `ST_OK` | 0 | executed (including accepted no-ops) |
| `ST_ALIGN` | 1 | `addr[1:0] != 0` |
| `ST_RANGE` | 2 | `addr >= capacity` |
| `ST_BADOP` | 3 | `op` in 4..7 |
| `ST_BE` | 4 | `ADD`/`CAS` with `be != 4'b1111` (including `be = 0`) |

**Precedence when several apply: `BADOP` > `ALIGN` > `RANGE` > `BE`** (tested with lanes that violate two rules at once, D10). Plain `LOAD`/`STORE` with `be = 0` is not an error: it is an accepted no-op that costs no bank cycle.

## 8. Inactive lanes

A lane with `lane_valid = 0` is **completely ignored**: its opcode, address, data and byte enables are never examined, it takes no part in conflict detection (a junk misaligned or out-of-range address on an inactive lane is harmless), it costs no bank cycle and its response bits are `lane_valid = 0, status = 0, data = 0`. A request with **no** active lane is legal; it occupies one issue slot and returns an empty response (D11).

## 9. Reset

`rst_n` is synchronous, active low. While and after it:

* all control state is cleared: request/response FIFOs, the active request, the bank pipelines, response credits, outstanding counters, performance counters, arbiter pointers;
* **every request that was accepted but not yet answered is dropped**: no response for it is ever produced, even if its store was half-way through the banks (R2, R4, R5);
* with `INIT_ON_RESET = 1` the arrays are zero-filled in `DEPTH` cycles during which `req_ready` is low and `init_busy` is high; a reset during the sweep restarts it (R3). With `INIT_ON_RESET = 0` the array contents are **undefined** - software must initialise before it reads (the Icarus 4-state runs exposed a bench that had silently relied on zeros, now fixed);
* clients must deassert `req_valid` while `rst_n` is low (reset is a system event) and must treat every outstanding request as lost.

## 10. Visibility, fences and barriers (summary; full text in FENCES_AND_BARRIERS.md)

* The memory has **no barrier input**; bank arbitration never depends on barrier state, and the barrier (`rtl/sys/sf_wg_barrier.sv`) has no connection to the memory.
* **FENCE.SMEM** = wait until the port's `port_idle` (= outstanding responses == 0). After it, every earlier request of this client has been performed.
* A workgroup barrier must be implemented as **`FENCE.SMEM ; arrive ; wait`**, in that order, by every participating warp. Without the fence a store issued before the barrier can still be waiting behind another port's long request when a consumer's post-barrier load is granted (RAW), and a load issued before the barrier can be granted after a producer's post-barrier store (WAR). Both were produced in **RTL-SIMULATION**: 90 of 160 randomised trials each without the fence, 0 of 160 with it (`tb_smem_system`).
* No acquire fence is needed after the barrier: a request is only *presented* after the release, and 5.4 orders it after everything performed earlier.

## 11. Timing contract (not architectural)

| quantity | value | label |
|---|---|---|
| minimum latency, accept -> response visible | `LAT_MIN = 4` cycles | RTL-SIMULATION (D01, replays) |
| request whose worst bank serves `d` groups | `3 + d` cycles | RTL-SIMULATION (D04-D09, D13) |
| throughput | one request per cycle when `d = 1` and credits allow | RTL-SIMULATION |
| one group per bank per cycle | includes back-to-back atomics on one word | RTL-SIMULATION (bank unit test: 72 000 issue slots on 2-4 rows) |

`d` = max over banks of the number of **runs** the bank must serve: a run is a maximal sequence of mergeable lane operations on one word (consecutive loads; consecutive stores if `WRITE_COMBINE`); every atomic is its own run (`py/sfsm/issue.py:request_cost`, proved equal to the stepwise RTL algorithm and to the RTL).

## 12. Adding an atomic

The datapath is deliberately open to extension. A new opcode needs: (1) a code in `sf_smem_defs.svh` (codes 4-7 are free and currently rejected), (2) a case in `sf_smem_atomic.sv` giving `newword` and `wr`, (3) a clause in the legality check of `sf_smem_top.sv` (`be` rule), (4) its lane class in `sf_smem_issue.sv` (all atomics are class 2 = "never merge", which is always correct), (5) a row in section 3 here that states atomicity, return value, alignment and signedness, (6) the same line in `py/sfsm/ref.py` and a directed test. Signed min/max, unsigned min/max, and/or/xor, exchange and add-with-wrap-detect fit this scheme unchanged; none of them is implemented.
