# SFSM microarchitecture

Normative behaviour is in `SEMANTICS.md`; this page explains how `rtl/` achieves it and why. Labels: **RTL-SIMULATION**, **MODEL**, **ASSUMED**, **MEASURED** as defined there.

## 1. Block diagram

```
             NP request ports (valid/ready, tag, NL lanes: valid op addr be wdata cmp)
                 |                         |                                  |
        +--------v--------+       +--------v--------+                 (one decode per port)
        | lane decode     |       | lane decode     |   status, alignment, range, no-op, bank map
        |  + bankmap x NL |       |  + bankmap x NL |   (entry = decoded request, field-major)
        +--------+--------+       +--------+--------+
                 | push                    | push
        +--------v--------+       +--------v--------+
        | request FIFO    |       | request FIFO    |   REQ_DEPTH entries / port   <- bounded
        +--------+--------+       +--------+--------+
                 | head (valid, credit>0)  |
              +--v-------------------------v--+
              |  port arbiter (fixed | RR)    |   one request granted per free issue slot
              +---------------+---------------+   credit[p]-- on grant
                              | load (no bubble when the active request ends this cycle)
              +---------------v---------------+
              | ACTIVE request register       |   fields + pend mask (lanes still to serve)
              +---------------+---------------+
                              |  pend
              +---------------v----------------------------------------------+
              | sf_smem_issue   (combinational, one cycle)                    |
              |  same-word matrix -> anchors, ready lanes                     |
              |  per-bank pick of ONE word (fixed | rotating)                 |
              |  group = ready lanes on that word  (broadcast / store merge)  |
              +---+---------+---------+---------+---------+-----------+-------+
                  | bank 0  | bank 1  |  ...    | bank NB-1           | group record g1
              +---v--+  +---v--+  +---v--+  +---v--+                  | (port, tag, served,
              |S0 rd |  |S0 rd |  |      |  |      |  1R1W array      |  lane->bank, rmask,
              |S1 RMW|  |S1 RMW|  | ...  |  | ...  |  + forward reg   |  first, last, status)
              +---+--+  +---+--+  +------+  +------+                  |
                  |  old word per bank (bank_rdata)                    |
              +---v---------------------------------------------------v--+
              | response assembly: lane <- bank_rdata[lane_bank] & mask   |   routes data to lanes
              +---------------------------+------------------------------+
                                          | push on the request's last group
                    +---------------------v---------------------+
                    | response FIFO per port (RSP_DEPTH = credits)| <- bounded
                    +---------------------+---------------------+
                                          v
                        NP response ports (valid/ready, tag, lane_valid, status, data)

   side: init sweep (INIT_ON_RESET) | outstanding[p] / port_idle[p] / quiescent | perf counters
   separate, NOT connected:  sf_wg_barrier
```

Everything between "request FIFO" and "response FIFO" has fixed latency and **never stalls**; flow control exists only at the two FIFOs and is reserved up front by credits.

## 2. Parameters

| parameter | default | constraint | meaning |
|---|---|---|---|
| `NL` | 8 | >= 2, any | lanes per request (not necessarily a power of two; tested 2, 4, 6, 8, 16, 32) |
| `NB` | 8 | power of two >= 2 | banks |
| `DEPTH` | 256 | power of two >= 2 | words per bank; capacity `NB*DEPTH*4` bytes |
| `NP` | 2 | >= 1 | request/response ports |
| `REQ_DEPTH` | 2 | >= 1 | request FIFO entries per port |
| `RSP_DEPTH` | 4 | >= 1 | response FIFO entries = credits per port |
| `TAGW`, `AW` | 8, 32 | `AW >= log2(NB*DEPTH)+2` | tag width, lane address width |
| `MAPPING`, `BLK_LOG2` | 0 (linear), 1 | 0..3 | bank mapping (section 8) |
| `LANE_ARB` | 1 | 0 fixed, 1 rotating | choice among *different words of one bank* |
| `PORT_ARB` | 1 | 0 fixed (port 0 first), 1 round robin | choice among ports |
| `WRITE_COMBINE` | 1 | 0/1 | merge same-word store runs into one array write |
| `INIT_ON_RESET` | 1 | 0/1 | zero-fill arrays after reset |
| `PERF_EN` | 1 | 0/1 | performance counters |

Elaboration-time `$fatal` checks reject illegal combinations (`NB`, `DEPTH` not powers of two, `AW` too small, `BLK_LOG2` out of range).

## 3. Interface rules

* Request: `req_valid[p] && req_ready[p]` transfers. `req_ready[p] = !init_busy && !request_fifo_full[p]` - a function of **registered state only** (never of `req_valid`), so there is no combinational path from any input to any output of the subsystem.
* Response: `rsp_valid[p]` is high while the response FIFO is non-empty; the head is **held stable** until `rsp_ready[p]` (checked every cycle by the replay bench). Responses of a port come out in request order.
* `outstanding[p]` counts requests accepted and not yet consumed; `port_idle[p] = (outstanding == 0)`; `quiescent` is everything idle. These exist for fences only.

## 4. Pipeline and timing (MEASURED: `tb_smem_directed` D01, D13; every replay)

For a request accepted at the end of cycle A (`req_valid && req_ready` in cycle A):

| cycle | what happens |
|---|---|
| A | accept: lane decode (status, alignment, range, no-op, bank/row) is **pre-computed** and the decoded entry is pushed |
| A+1 | entry is at the FIFO head; the port arbiter grants it into the ACTIVE register (credit--) |
| A+2 | first issue cycle: `sf_smem_issue` forms the groups; each bank registers its operation and reads its array (S0) |
| A+3 | S1: bank forwarding mux, atomic unit, array write; response assembly merges lane data; if this was the last group the response is pushed |
| A+4 | response visible at the port (`LAT_MIN = 4`) |

A request whose worst bank must serve `d` groups issues in cycles `A+2 .. A+1+d` and responds in `A+3+d`. The next request is loaded into the ACTIVE register in the *same cycle* in which the previous one issues its last group, so independent requests stream at **one per cycle** with no bubble (MODEL, replay-validated: 0.993 requests/cycle for a conflict-free stream, `BENCHMARKS.md` section 5; the 64-request RTL `stride_1` run takes 68 busy cycles = 64 + the 4-cycle pipeline fill).

## 5. Port arbitration, credits and bounded buffering

State per port: request FIFO (`REQ_DEPTH`), response FIFO (`RSP_DEPTH`), `cred[p]` (initially `RSP_DEPTH`), `outstanding[p]`.

* A port is **eligible** iff its request FIFO is non-empty **and** `cred[p] > 0`.
* On a grant `cred[p]--`; when the client consumes a response `cred[p]++`.
* `PORT_ARB=1`: round robin, pointer = granted port + 1. `PORT_ARB=0`: lowest port number first.

**Invariants** (asserted in simulation, argued here):

1. `granted_not_consumed[p] = RSP_DEPTH - cred[p]  >=  response_fifo_occupancy[p] + in_flight[p]`, hence **the response FIFO can never overflow** and the bank pipeline never needs to stall (the simulation-time check `response FIFO overflow` never fired in the ~1.2 M simulated cycles of the replay and soak suites).
2. `outstanding[p] <= REQ_DEPTH + RSP_DEPTH` (MEASURED: D15 accepts exactly `REQ_DEPTH + RSP_DEPTH` requests from a stalled port and then deasserts `req_ready`, for buffer sizes 1/1, 2/4 and 4/8).
3. **No head-of-line blocking across ports**: a port whose client stops consuming responses runs out of credits and is skipped by the arbiter; everyone else continues at full speed (MEASURED: soak `slow_consumer*`, other ports finish at the same cycle or earlier).
4. **Deadlock freedom**: the issue stage always retires the active request (section 6, progress), a credit is returned whenever a client consumes a response, and a request already granted owns a credit - so a granted request can always finish.
5. **Round-robin bound** (MEASURED, 4 saturating ports, 3 000 requests each): between two grants of one backlogged port at most `NP-1 = 3` other grants occur; Jain index of grants in the backlogged window = 1.0.
6. **Fixed priority starves by construction** (MEASURED): with port 0 saturating, port 3 receives its first response only after port 0 has finished (cycle 36 635 vs 12 292), though everything eventually completes.

**Credit loop and throughput (MODEL, proven equal to RTL by replay).** A credit is taken at the grant (cycle `t`), the response is visible in `t+3`, the client consumes it in `t+3` and the credit is usable by the arbiter in `t+4`: a **4-cycle loop**. With `RSP_DEPTH` below 4 a port cannot sustain one request per cycle: throughput is `RSP_DEPTH / 4` requests per cycle up to 4 (benchmark B5, `BENCHMARKS.md` section 6). Default `RSP_DEPTH = 4` is the minimum that sustains full rate.

## 6. Bank arbitration (`sf_smem_issue`)

Input: the lanes of the active request that still need a bank access (`pend`). Per lane: bank, row, class (`LOAD`, `STORE`, `ATOMIC`).

Definitions, with "lower" meaning a smaller lane index:

* `same[j][k]` - lanes *j* and *k* are pending and address the same word (same bank and row).
* **mergeable** pair: both `LOAD`; or both `STORE` and `WRITE_COMBINE`; atomics never merge.
* `blocked[k]` - some lower pending lane on the same word is **not** mergeable with *k*.
* `ready[k] = pend[k] & !blocked[k]` - *k* belongs to the homogeneous run at the head of its word's pending sequence.
* `anchor[k]` - *k* is the lowest pending lane of its word (always `ready`).

Each cycle, for every bank: pick **one anchor** among that bank's anchors (`LANE_ARB`: lowest lane, or rotating pointer per bank), then serve the **group** = all `ready` lanes on the anchor's word with **one** array access:

* `LOAD` group -> one read, the word is broadcast to every lane of the group (each lane masks it with its own `be`);
* `STORE` group -> one write; per byte the **highest** lane of the group that enables it supplies the data;
* `ATOMIC` -> exactly one lane (never merged); the atomic unit executes it.

**Correctness** (claim: indistinguishable from ascending-lane sequential execution). A lane is served only when every lower pending lane on its word is either already served or in the same mergeable run; a run is served by a single access whose result equals the serial one (broadcast data is identical for loads that are not separated by a writer; merged stores = last-writer-wins per byte = serial order). Different words never interact. **MODEL**: stepwise model == sequential reference on every random request of `py/tests` (all configurations, `WRITE_COMBINE` 0/1, `LANE_ARB` 0/1), and the test is shown to fail when either ordering rule is broken (mutants: 1190 / 1134 of 1600 requests differ). **RTL-SIMULATION**: the same equality on 722 trace-replay runs (112 179 requests) and in the directed tests.

**Progress and cost.** An anchor exists whenever anything is pending, so every bank with pending lanes serves a group every cycle (work-conserving). A request therefore needs exactly `d = max over banks of (sum over its words of #runs)` cycles (at least 1), independent of `LANE_ARB`. That makes `LANE_ARB` **performance-neutral per request** (MODEL: 1 000 requests with identical cycle counts under both policies; the RTL replays pass for both); it only changes the order of different words inside a bank. It is kept because the order matters if responses are ever returned per lane - see `KNOWN_LIMITATIONS.md`.

Implementation cost: the same-word matrix is `O(NL^2)` comparators of `log2(NB*DEPTH)` bits and the group formation `O(NB*NL^2)` AND terms. Yosys generic synthesis (MODEL of cost, no library): 37 k cells at 8x8, 106 k at 16x16, 367 k at 32x32 (`reports/synth_summary.txt`; `DEPTH = 4`, i.e. logic without the array). For `NL` beyond 32 a hierarchical comparison would be needed.

## 7. Bank, atomic unit and forwarding (`sf_smem_bank`, `sf_smem_atomic`)

```
 S0 (issue cycle)            S1 (next cycle)
 row, op, be, wdata, cmp --> regs ; array READ(row) --> rd_q
                             old = (fwd_valid && fwd_row==row) ? fwd_word : rd_q
                             atomic unit(op, old, wdata, cmp, be) -> newword, wr
                             array WRITE (be mask for STORE, full word for ADD/CAS)
                             fwd_* <= {wr, row, newword}          rsp_rdata = old
```

* One operation per bank per cycle, **including back-to-back atomics on the same word**: the operation in S1 may be on the row written by its predecessor one edge earlier; the **forward registers** supply that value, so the result does not depend on the array's read-during-write behaviour.
* Requires a **1R1W array** (S0 read and S1 write in the same cycle). A single-port macro would need two cycles per atomic; that variant is not implemented (`KNOWN_LIMITATIONS.md`).
* `rsp_rdata` is the value **before** the operation (the architectural return value for loads and atomics); the new value never leaves the bank except through the array/forward registers.
* **RTL-SIMULATION**: `tb_smem_units` drives 72 000 random operations on 2-4 rows (so most consecutive operations hit the same row), comparing every response with a sequential model and the final array through a backdoor; mutation `no forwarding` makes it fail (see `VERIFICATION.md`).

## 8. Bank mappings (`sf_smem_bankmap`)

`w` = word index, `lo = w mod NB`, `hi = w / NB`, `B = log2 NB`.

| mapping | bank | row | character |
|---|---|---|---|
| `LINEAR` | `lo` | `hi` | consecutive words in consecutive banks; stride `NB` -> one bank |
| `XOR` | `lo ^ fold(hi)` (XOR of the `B`-bit chunks of `hi`) | `hi` | breaks power-of-two strides; hardware = a few XORs |
| `SKEW` | `(lo + hi) mod NB` | `hi` | the hardware equivalent of padding every row by one word |
| `BLOCK(G)` | `(w >> G) mod NB` | `((w >> (G+B)) << G) \| w[G-1:0]` | `2^G` consecutive words per bank (wide-element friendly, hurts unit stride) |

Every mapping is a bijection and ships its inverse (`ibank, irow -> iwidx`) so that it can be proven exhaustively. Mappings affect **only timing**: see `BENCHMARKS.md` section B1/B2 and `SEMANTICS.md` section 2.

## 9. Response routing

Each issue cycle records, per lane, the bank that serves it (`g1_bank`), the byte mask (`rmask`: `be` for loads, all ones for atomics, zero for stores), and which lanes were served. In the bank's S1 cycle every served lane takes `bank_rdata[lane_bank] & mask`; lanes not served keep their previous value (or 0 on the first group). One assembly register holds the partial response; on the last group the vector is pushed, together with the request tag, lane-valid mask and statuses, into **the response FIFO of the requesting port** (`g1_port`). Groups of different requests are never interleaved in the pipeline, so a single assembly register suffices.

## 10. Reset, initialisation, counters

* Synchronous reset clears control state only; the arrays are initialised by a `DEPTH`-cycle sweep (`INIT_ON_RESET`) in which `req_ready = 0`.
* Performance counters (32-bit, cleared by reset), index map: 0 `active_cycles`, 1 `requests`, 2 `conflict_cycles` (= sum of `d-1`), 3 `bank_groups`, 4 `lanes_served`, 5 `atomic_lanes`, 6 `error_lanes`, 7 `credit_stall_cycles`, `8+p` `grants[p]`, `8+NP+p` `wait_cycles[p]`, `8+2NP+b` `bank_busy[b]`. They match the cycle model exactly in every replay.

## 11. Alternatives considered

* **Lane-decoupled design** (independent per-lane queues, per-bank arbitration of lane heads): rejected - it would give up the lock-step request that makes "same-address lanes are ordered by lane index", broadcast and atomic serialisation simple and exactly specifiable, and it needs a response reorder network.
* **Overlapping the next request into idle banks**: rejected for this version - it needs same-word hazard tracking between requests and would weaken the single global order (section 5.3 of the contract keeps the door open).
* **Per-lane early responses**: not provided; the response vector is returned once, so the order in which lanes are served inside a request is not observable (which is why `LANE_ARB` is performance-neutral here).
* **Single-port (1RW) banks** with a two-cycle atomic: not implemented; would halve same-bank atomic throughput.
* **Warp-aggregated atomics** (combining lanes' addends into one array update, returning prefix sums): not implemented; it would turn the `d = NL` serialisation of `hot_add` into `d = 1` and is the natural next optimisation. It must return exactly the lane-ordered prefix values required by `SEMANTICS.md` 5.1.
