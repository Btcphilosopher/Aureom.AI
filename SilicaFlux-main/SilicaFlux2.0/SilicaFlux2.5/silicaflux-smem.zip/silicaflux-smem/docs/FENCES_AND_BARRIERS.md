# Fences, barriers and visibility

**Rule of thumb: the shared memory never waits for a barrier, and a barrier never looks at the shared memory. The client makes them meet with a fence.**

```
        warp (client)                              SFSM                       barrier unit
   store/atomic ...  --request-->  [req FIFO]-->[arbiter]-->[banks]
   FENCE.SMEM  : wait until port_idle[p]  <----- responses (performed) ------+
   arrive      ------------------------------------------------------------->  sf_wg_barrier
   wait        <------------------------------------------------------------  release
   load/store ...    --request-->
```

## 1. Why the two are separate

* **Bank arbitration** decides, every cycle, which lane/word each bank serves and which port's request is granted next. Its inputs are addresses, opcodes, FIFO occupancy and credits. It has **no barrier input**, so it cannot be stalled, reordered or deadlocked by barrier state, and a barrier with a hundred waiting warps costs the memory nothing (RTL-SIMULATION, `tb_smem_system` S1: memory latency stays at its unloaded 4 cycles while a warp waits at a barrier).
* **The workgroup barrier** (`rtl/sys/sf_wg_barrier.sv`, reference implementation: arrival mask, release the cycle after the last member arrives) only counts arrivals. It has **no connection to the memory subsystem**. Which warps participate, divergence, `bar.arrive` / `bar.sync` variants and named barriers are the core's business, not the memory's.
* The only thing the memory exports to help is `outstanding[p]` / `port_idle[p]` / `quiescent` - counters of requests accepted but whose response has not yet been consumed.

## 2. What the memory guarantees about visibility (summary of `SEMANTICS.md` 5.4)

1. Operations are performed in a per-word total order; a request is only answered after **all** its lane operations were performed.
2. Hence **a response is an acknowledgement of visibility**: any request *presented after* the response was observed - by any client - observes the operation (or something later in the word's order).
3. Without a response there is **no promise**: a request sitting in a request FIFO, or still in the pipeline, has not been performed; another port's request may be granted before it. [impl] The port arbiter (fixed or round robin) picks between ports by its own rule; arrival order at the barrier is not an input.

## 3. The two hazards a barrier alone does not cure

Both witnessed in **RTL-SIMULATION** (`tb/tb_smem_system.sv`, both simulators, identical results). `X` is a shared word; an earlier long (8-way-conflicting) request of one warp keeps the issue stage busy.

**RAW (store -> barrier -> load).** Producer: *long request; store X; arrive*. Consumer: *wait; load X*. The store sits in the producer's request FIFO behind the long request; the barrier releases; the consumer's load reaches the arbiter first and is granted first -> the consumer reads the **old** value. (Crafted case: `0x11111111` instead of `0xAAAAAAAA`, with fixed-priority and with round-robin ports.)

**WAR (load -> barrier -> store).** Consumer: *long request; load X; arrive*. Producer: *wait; store X*. The load is queued behind the long request; after the barrier the producer's store is granted first (round-robin) -> the consumer's **pre-barrier load returns the post-barrier value**. (Crafted case: `0xAAAAAAAA` instead of `0x11111111`.) With **fixed** port priority this particular witness does not occur because the consumer is port 0 - proof that a correct program must not rely on the arbitration policy.

Randomised sweep (160 trials with random conflict degree and delays, per variant):

| variant | RAW violations | WAR violations |
|---|---|---|
| no fence, round-robin ports | 90 / 160 | 90 / 160 |
| no fence, fixed-priority ports | 90 / 160 | 0 / 160 (policy happens to hide it) |
| **with fence, either arbiter** | **0 / 160** | **0 / 160** |

## 4. What a client must do

```
bar.sync (workgroup barrier), per participating warp, in this order:

    1. FENCE.SMEM         wait until port_idle[p] == 1      (every earlier request has been answered)
    2. arrive             pulse to the barrier unit
    3. wait               until the barrier releases this warp
    4. continue           later requests are presented after the release
```

* **Release (before the barrier):** step 1 covers both stores/atomics (RAW) **and loads** (WAR: a load that has not been answered has not been performed).
* **Acquire (after the barrier):** none needed. A request is *presented* only after the release, so by 2.2 it observes everything that was acknowledged before the barrier.
* `port_idle` counts *all* of a port's traffic. If several warps share one port, a warp's fence also waits for the others' requests - conservative but correct. A client that needs finer granularity can track its own tags (every response returns the request tag).
* **A fence is not needed between two requests of the same port** (5.2 of the contract: per-port order), nor to separate a store from a load of the same word by the same warp.
* **Atomics** are ordered like any other operation. An atomic is not a fence: it neither flushes earlier requests nor delays later ones. Use the fence when the data protected by an atomic flag (e.g. a lock released with a CAS) must be visible before the flag.
* **Cost:** the fence waits the memory round trip of the last request (>= 4 cycles plus conflicts). It is the only price; nothing is added to the memory datapath.

## 5. Examples: producer/consumer through a flag

**A - data and flag written by the same port: no fence.** Requests of one port take effect in acceptance order across *all* words (contract 5.2), so no other port can observe the flag store before the data store.

```
producer (port 1)                          consumer (port 0)
  STORE data[0..31]                           loop: LOAD flag ; until flag != 0
  STORE flag = 1                              LOAD data[0..31]      # presented after the flag response
```

The consumer sees `flag = 1` only through a response, and by 2.2 its later `LOAD data` observes the data.

**B - data and flag written through different ports: fence the data port first.** For instance a DMA engine on port 2 writes the data and a warp on port 1 then sets the flag. The warp must not store the flag until the DMA's stores have been *acknowledged* (their responses consumed, i.e. `port_idle[2]`), otherwise the flag store can be granted ahead of a data store that is still queued on the other port.

```
DMA (port 2)                  warp (port 1)                          consumer (port 0)
  STORE data ... (n requests)   wait: port_idle[2]  (DMA fence)         LOAD flag until != 0
                                STORE flag = 1                          LOAD data
```

**C - workgroup barrier**: sections 3 and 4 (`FENCE.SMEM ; arrive ; wait`). The barrier supplies the *ordering of the warps*, the fence supplies the *visibility of their memory operations*.

## 6. Reset interaction

Reset drops outstanding requests without responses (contract section 9): a fence must never be waiting across a reset. The system benches (`tb_smem_reset`) assert `quiescent` and `port_idle` after reset.
