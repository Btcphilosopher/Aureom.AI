#!/usr/bin/env python3
"""SFSM benchmark driver: bank conflicts, latency, throughput, fairness and the
comparison of bank mappings.  Everything here runs on the cycle model that
sim/run_regress.py proves cycle-identical to the RTL (reports/regress_*.json); the
NL=NB=8/16 workload x mapping tables are ADDITIONALLY replayed on the RTL (suite
`bench`) and the RTL cycle counts are merged into the tables when present.

    python3 py/tools/bench.py            -> reports/bench/*.csv|json|svg, reports/bench_tables.md
"""
import csv
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PY = os.path.dirname(HERE)
ROOT = os.path.dirname(PY)
sys.path.insert(0, PY)

from sfsm.arch import (Config, Lane, Req, MAP_LINEAR, MAP_XOR, MAP_SKEW, MAP_BLOCK, OP_LOAD, OP_ADD,  # noqa: E402
                       OP_STORE, M32, INACTIVE, LAT_MIN)
from sfsm.issue import request_cost, decode_request                                              # noqa: E402
from sfsm.cycle import simulate                                                                  # noqa: E402
from sfsm import metrics as M                                                                    # noqa: E402
from sfsm import svg                                                                             # noqa: E402
from sfsm import benchlib                                                                        # noqa: E402

OUT = os.path.join(ROOT, "reports", "bench")


def csvw(name, header, rows):
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


# --------------------------------------------------------------------------- B1 stride sweep
def b1_stride_sweep(n=32, maxs=64):
    cfgs = [(name, benchlib.bench_config(n, kw)) for name, kw in benchlib.MAPPINGS]
    rows, grid = [], []
    for name, cfg in cfgs:
        ds = []
        for s in range(1, maxs + 1):
            lanes = [Lane(1, OP_LOAD, ((l * s) % cfg.cap_words) * 4, 0xF, 0, 0) for l in range(cfg.NL)]
            ds.append(request_cost(cfg, lanes)["d"])
        grid.append(ds)
        rows.append((name, ds))
    csvw("b1_stride_sweep_n%d.csv" % n, ["mapping"] + list(range(1, maxs + 1)), [[nm] + ds for nm, ds in rows])
    svg.heatmap(os.path.join(OUT, "b1_stride_heatmap_n%d.svg" % n),
                "Conflict degree d (issue cycles) of one %d-lane unit-word load, lane l -> word l*stride" % n,
                [nm for nm, _ in rows], list(range(1, maxs + 1)), grid, "stride (words)", "", fmt="%d")
    summary = {}
    for nm, ds in rows:
        summary[nm] = dict(mean=round(sum(ds) / len(ds), 2), max=max(ds),
                           conflict_free_strides=sum(1 for d in ds if d == 1),
                           worst_strides=[i + 1 for i, d in enumerate(ds) if d == max(ds)][:8])
    # power-of-two strides, the usual suspects
    p2 = {nm: {s: ds[s - 1] for s in (1, 2, 4, 8, 16, 32, 64) if s <= maxs} for nm, ds in rows}
    return dict(n=n, summary=summary, pow2=p2)


# --------------------------------------------------------------------------- B2 workload x mapping
def run_workloads(n, np_=1):
    out = {}
    for name, kw in benchlib.MAPPINGS:
        cfg = benchlib.bench_config(n, kw, np_)
        for w in benchlib.workload_list(cfg):
            res = simulate(cfg, w.per_port)
            bad = w.check(res.mem.w)
            tp = M.throughput(res, cfg)
            reqs = sum(len(x) for x in w.per_port)
            hist = M.conflict_hist(res)
            avg_d = sum(d * c for d, c in hist.items()) / max(1, reqs)
            busy = res.cycles - min(res.acc.values()) + 1        # first accept -> last response (init sweep excluded)
            out.setdefault(w.name, {})[name] = dict(
                requests=reqs, cycles=busy, abs_cycles=res.cycles, conflict_cycles=res.perf["conflict_cycles"],
                avg_d=round(avg_d, 3), lanes_per_cycle=round(tp["lanes_per_cycle"], 3),
                req_per_cycle=round(tp["req_per_cycle"], 4), bank_util=round(tp["bank_util"], 3),
                groups=res.perf["bank_groups"], lanes=res.perf["lanes_served"], ok=not bad,
                lat_mean=round(M.summarize_latency(M.latencies(res))["mean"], 2),
                lat_p99=M.summarize_latency(M.latencies(res))["p99"])
    return out


def b2_tables(n):
    res = run_workloads(n)
    names = list(benchlib.MAPPINGS)
    maps = [m for m, _ in names]
    rows = []
    for wl, per in res.items():
        rows.append([wl] + [per[m]["cycles"] for m in maps] + [per["linear"]["requests"]])
    csvw("b2_cycles_n%d.csv" % n, ["workload"] + maps + ["requests"], rows)
    rows = []
    for wl, per in res.items():
        rows.append([wl] + [per[m]["avg_d"] for m in maps])
    csvw("b2_avg_conflict_degree_n%d.csv" % n, ["workload"] + maps, rows)
    # speed-up over linear for the bar chart: ALL workloads (including those where a hashed or
    # blocked mapping is slower than linear - a value below 1 means slower than linear)
    sel = list(res)
    series = {m: [res[wl]["linear"]["cycles"] / res[wl][m]["cycles"] for wl in sel] for m in maps}
    svg.bar_chart(os.path.join(OUT, "b2_speedup_vs_linear_n%d.svg" % n),
                  "Speed-up vs. the linear mapping (cycles_linear / cycles; <1 = slower), %d lanes x %d banks, all workloads" % (n, n),
                  sel, series, "speed-up (x)", w=1180, h=480, logy=True)
    allok = all(v["ok"] for per in res.values() for v in per.values())
    return dict(n=n, results=res, all_independent_checks_ok=allok)


# --------------------------------------------------------------------------- B3 atomic contention
def b3_atomic_contention(n=32, nreq=64):
    """k lanes add to ONE word (bank 0); the other n-k lanes add to distinct words in distinct
    banks.  Atomics on one word are serialised (one per cycle); atomics on different banks are not."""
    cfg = benchlib.bench_config(n, dict(MAPPING=MAP_LINEAR))
    rows = []
    for k in [0, 1, 2, 4, 8, 16, 24, n]:
        if k > n:
            continue
        lanes = []
        for l in range(n):
            if l < k:
                word = 0                                        # the hot word, bank 0
            else:
                b = l if k == 0 else 1 + ((l - k) % (n - 1))      # distinct banks (bank 0 is the hot bank)
                word = n * 2 + b
            lanes.append(Lane(1, OP_ADD, word * 4, 0xF, 1, 0))
        res = simulate(cfg, [[Req(0, 0, lanes) for _ in range(nreq)]])
        issue_cycles = res.perf["active_cycles"] / nreq
        rows.append((k, issue_cycles, res.cycles / nreq, n * nreq / res.perf["active_cycles"]))
    csvw("b3_atomic_hotspot_n%d.csv" % n, ["lanes_on_hot_word", "issue_cycles_per_request", "cycles_per_request",
                                              "atomics_per_issue_cycle"], rows)
    svg.line_chart(os.path.join(OUT, "b3_atomic_hotspot_n%d.svg" % n),
                   "Atomic add throughput vs. lanes hitting one word (%d lanes, %d banks)" % (n, n),
                   [r[0] for r in rows], {"atomics / issue cycle": [r[3] for r in rows],
                                           "issue cycles / request": [r[1] for r in rows]},
                   "lanes of the request that target the same word", "")
    return dict(n=n, rows=[dict(hot=r[0], issue_cycles=round(r[1], 2), atomics_per_issue_cycle=round(r[3], 2)) for r in rows])


# --------------------------------------------------------------------------- B4 latency / queueing
def conflict_request(cfg, d, op=OP_LOAD):
    """one request whose worst bank serves exactly d distinct words (linear map)."""
    lanes = []
    for l in range(cfg.NL):
        if l < d:
            lanes.append(Lane(1, op, (cfg.NB * l) * 4, 0xF, 1, 0))                    # d words, bank 0
        else:
            lanes.append(Lane(1, op, (1 + (l - d) % (cfg.NB - 1)) * 4, 0xF, 1, 0))      # spread over banks 1..NB-1
    return lanes


def b4_latency_throughput(n=16, nreq=400):
    rows = []
    for np_ in (1, 2, 4):
        for d in (1, 2, 4, 8, n):
            cfg = Config(NL=n, NB=n, DEPTH=128, NP=np_, AW=20)
            per = [[Req(0, i & 0xFF, conflict_request(cfg, d)) for i in range(nreq)] for _ in range(np_)]
            res = simulate(cfg, per)
            lat = M.latencies(res)
            sm = M.summarize_latency(lat)
            tp = M.throughput(res, cfg)
            rows.append(dict(ports=np_, d=d, req_per_cycle=round(tp["req_per_cycle"], 3),
                             lanes_per_cycle=round(tp["lanes_per_cycle"], 2), lat_mean=round(sm["mean"], 1),
                             lat_p95=sm["p95"], lat_max=sm["max"]))
    csvw("b4_latency_throughput_n%d.csv" % n, list(rows[0].keys()), [list(r.values()) for r in rows])
    # unloaded latency: one request at a time
    unl = []
    for d in (1, 2, 4, 8, n):
        cfg = Config(NL=n, NB=n, DEPTH=128, NP=1, AW=20)
        res = simulate(cfg, [[Req(0, 0, conflict_request(cfg, d))]])
        unl.append((d, M.latencies(res)[0]))
    series = {"1 port": [r["lat_mean"] for r in rows if r["ports"] == 1],
              "2 ports": [r["lat_mean"] for r in rows if r["ports"] == 2],
              "4 ports": [r["lat_mean"] for r in rows if r["ports"] == 4]}
    svg.line_chart(os.path.join(OUT, "b4_loaded_latency_n%d.svg" % n),
                   "Mean request latency, saturating ports (%d lanes, %d banks)" % (n, n),
                   [1, 2, 4, 8, n], series, "conflict degree d of every request", "cycles (accept -> response visible)")
    return dict(n=n, unloaded=[dict(d=d, latency=l, formula=LAT_MIN - 1 + d) for d, l in unl], loaded=rows)


# --------------------------------------------------------------------------- B5 buffering
def b5_buffering(n=16, nreq=600):
    cfg0 = Config(NL=n, NB=n, DEPTH=128, NP=1, AW=20)
    rows = []
    for np_ in (1, 2):
        for req_d in (1, 2, 4):
            vals = []
            for rsp_d in range(1, 9):
                cfg = cfg0.with_(NP=np_, REQ_DEPTH=req_d, RSP_DEPTH=rsp_d)
                per = [[Req(0, i & 0xFF, conflict_request(cfg, 1)) for i in range(nreq)] for _ in range(np_)]
                res = simulate(cfg, per)
                tp = M.throughput(res, cfg)
                vals.append(round(tp["req_per_cycle"], 3))
            rows.append((np_, req_d, vals))
    csvw("b5_buffering.csv", ["ports", "REQ_DEPTH"] + ["RSP_DEPTH=%d" % i for i in range(1, 9)],
         [[a, b] + v for a, b, v in rows])
    svg.line_chart(os.path.join(OUT, "b5_buffering.svg"),
                   "Sustained conflict-free throughput vs. response buffering (1 port)",
                   list(range(1, 9)), {"REQ_DEPTH=%d" % b: v for a, b, v in rows if a == 1},
                   "RSP_DEPTH (= response credits per port)", "requests / cycle")
    # consumer back-pressure: consumer accepts 1 response every K cycles
    rows2 = []
    for rsp_d in (1, 2, 4, 8):
        vals = []
        for per_k in (1, 2, 3, 4, 8):
            cfg = cfg0.with_(RSP_DEPTH=rsp_d, REQ_DEPTH=2)
            per = [[Req(0, i & 0xFF, conflict_request(cfg, 1)) for i in range(nreq)]]
            res = simulate(cfg, per, rsp_pat=[(per_k, 1)])
            vals.append(round(M.throughput(res, cfg)["req_per_cycle"], 3))
        rows2.append((rsp_d, vals))
    csvw("b5_consumer_rate.csv", ["RSP_DEPTH"] + ["consumer 1/%d" % k for k in (1, 2, 3, 4, 8)], [[a] + v for a, v in rows2])
    return dict(n=n, depth_sweep=[dict(ports=a, req_depth=b, throughput=v) for a, b, v in rows],
                consumer_rate=[dict(rsp_depth=a, throughput=v) for a, v in rows2])


# --------------------------------------------------------------------------- B6 broadcast / combining value
def b6_merge_value(n=16):
    rows = []
    cfg = benchlib.bench_config(n, dict(MAPPING=MAP_LINEAR))
    for wc in (1, 0):
        c = cfg.with_(WRITE_COMBINE=wc)
        for w in (W_hist(c), W_gemm(c)):
            res = simulate(c, w.per_port)
            rows.append(dict(write_combine=wc, workload=w.name, cycles=res.cycles,
                             lanes=res.perf["lanes_served"], bank_accesses=res.perf["bank_groups"],
                             lanes_per_access=round(res.perf["lanes_served"] / res.perf["bank_groups"], 3)))
    # same-word store/load requests
    for wc in (1, 0):
        c = cfg.with_(WRITE_COMBINE=wc)
        for opn, op in (("all lanes store one word", OP_STORE), ("all lanes load one word", OP_LOAD)):
            lanes = [Lane(1, op, 40, 0xF, l, 0) for l in range(n)]
            rows.append(dict(write_combine=wc, workload=opn, cycles=request_cost(c, lanes)["d"],
                             lanes=n, bank_accesses=sum(request_cost(c, lanes)["groups"]),
                             lanes_per_access=n / sum(request_cost(c, lanes)["groups"])))
    csvw("b6_merge_value.csv", list(rows[0].keys()), [list(r.values()) for r in rows])
    return rows


def W_hist(c):
    from sfsm import workloads as W
    return W.histogram(c, "uniform")


def W_gemm(c):
    from sfsm import workloads as W
    return W.gemm_tiled(c, T=c.NL)


# --------------------------------------------------------------------------- B7 random access vs bank count
def b7_bank_scaling(nl=32, trials=3000):
    rng = random.Random(3)
    banks = [8, 16, 32, 64, 128]
    avg, p99 = [], []
    for nb in banks:
        cfg = Config(NL=nl, NB=nb, DEPTH=64, NP=1, AW=24)
        ds = []
        for _ in range(trials):
            lanes = [Lane(1, OP_LOAD, rng.randrange(cfg.cap_words) * 4, 0xF, 0, 0) for _ in range(nl)]
            ds.append(request_cost(cfg, lanes)["d"])
        avg.append(round(sum(ds) / len(ds), 3))
        p99.append(M.percentile(ds, 99))
    csvw("b7_random_access_bank_scaling.csv", ["banks", "avg_d", "p99_d"], list(zip(banks, avg, p99)))
    svg.line_chart(os.path.join(OUT, "b7_random_access_bank_scaling.svg"),
                   "Random word access, %d lanes: conflict degree vs. bank count" % nl, banks,
                   {"mean d": avg, "p99 d": p99}, "banks", "issue cycles per request")
    return dict(lanes=nl, banks=banks, avg_d=avg, p99_d=p99)


# --------------------------------------------------------------------------- B8 2-D tile access patterns
def b8_tile_patterns(n=32):
    """row / column / diagonal access of an RxC tile with row pitch P, per mapping."""
    out = {}
    for name, kw in benchlib.MAPPINGS:
        cfg = benchlib.bench_config(n, kw)
        res = {}
        for pitch in (n, n + 1, n // 2, 2 * n):
            def cost(addr_fn):
                return request_cost(cfg, [Lane(1, OP_LOAD, addr_fn(l) * 4, 0xF, 0, 0) for l in range(n)])["d"]
            res["pitch %d" % pitch] = dict(row=cost(lambda l: l), col=cost(lambda l: l * pitch),
                                           diag=cost(lambda l: l * (pitch + 1)),
                                           antidiag=cost(lambda l: l * (pitch - 1)))
        out[name] = res
    rows = []
    for name, res in out.items():
        for pitch, v in res.items():
            rows.append([name, pitch, v["row"], v["col"], v["diag"], v["antidiag"]])
    csvw("b8_tile_patterns_n%d.csv" % n, ["mapping", "pitch", "row", "column", "diagonal", "anti-diagonal"], rows)
    return out


def main():
    t0 = time.time()
    os.makedirs(OUT, exist_ok=True)
    R = {}
    print("B1 stride sweep ...")
    R["b1_n32"] = b1_stride_sweep(32)
    R["b1_n16"] = b1_stride_sweep(16)
    print("B2 workload x mapping ...")
    R["b2_n16"] = b2_tables(16)
    R["b2_n32"] = b2_tables(32)
    print("B3 atomics ...")
    R["b3"] = b3_atomic_contention(32)
    print("B4 latency ...")
    R["b4"] = b4_latency_throughput(16)
    print("B5 buffering ...")
    R["b5"] = b5_buffering(16)
    print("B6 merging ...")
    R["b6"] = b6_merge_value(16)
    print("B7 bank scaling ...")
    R["b7"] = b7_bank_scaling(32)
    print("B8 tile patterns ...")
    R["b8"] = b8_tile_patterns(32)
    with open(os.path.join(ROOT, "reports", "bench_results.json"), "w") as f:
        json.dump(R, f, indent=1)
    print("done in %.0fs" % (time.time() - t0))


if __name__ == "__main__":
    main()
