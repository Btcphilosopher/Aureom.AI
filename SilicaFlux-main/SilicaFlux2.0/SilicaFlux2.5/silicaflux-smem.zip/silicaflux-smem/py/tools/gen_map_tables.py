#!/usr/bin/env python3
"""Write the Python mapping tables that tb/tb_smem_units.sv compares the RTL against.
Variant list must match v_nb / v_depth / v_map / v_blk in the testbench."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from sfsm.arch import Config, map_word

VARIANTS = [  # (NB, DEPTH, MAPPING, BLK_LOG2)
    (8, 16, 0, 1), (8, 16, 1, 1), (8, 16, 2, 1), (8, 16, 3, 0), (8, 16, 3, 1), (8, 16, 3, 3),
    (16, 32, 1, 1), (4, 8, 1, 1), (32, 8, 2, 1), (2, 4, 1, 1), (4, 64, 3, 4), (8, 4, 1, 1)]

def write(outdir):
    os.makedirs(outdir, exist_ok=True)
    for v, (nb, depth, m, g) in enumerate(VARIANTS):
        cfg = Config(NB=nb, DEPTH=depth, MAPPING=m, BLK_LOG2=g, AW=16)
        text = "".join("%d %d %d\n" % ((w,) + map_word(cfg, w)) for w in range(cfg.cap_words))
        path = os.path.join(outdir, "map_%d.tab" % v)
        if os.path.exists(path) and open(path).read() == text:
            continue                                   # unchanged: never rewrite a file another run may be reading
        tmp = "%s.%d.tmp" % (path, os.getpid())
        with open(tmp, "w") as f:
            f.write(text)
        os.replace(tmp, path)                           # atomic
    return len(VARIANTS)

if __name__ == "__main__":
    print("wrote", write(sys.argv[1] if len(sys.argv) > 1 else "traces/maptab"), "tables")
