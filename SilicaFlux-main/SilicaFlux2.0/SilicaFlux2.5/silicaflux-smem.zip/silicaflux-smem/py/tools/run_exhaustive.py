#!/usr/bin/env python3
"""Bounded-exhaustive equivalence check (stepwise RTL algorithm == sequential reference).
    python3 py/tools/run_exhaustive.py [--five]     -> reports/exhaustive.json
4 lanes: 4 policy combinations x 20^4 requests (~45 s).  --five adds 5 lanes: 2 combinations x 20^5 (~25 min)."""
import argparse
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PY = os.path.dirname(HERE)
ROOT = os.path.dirname(PY)
sys.path.insert(0, PY)
from tests import test_exhaustive as T   # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--five", action="store_true")
    a = ap.parse_args()
    res = dict(options_per_lane=len(T.lane_options(0)), words="3 words: two in one bank (different rows), one in another bank",
               runs=[])
    ok = True
    t0 = time.time()
    plan = [(4, wc, la) for wc in (1, 0) for la in (1, 0)]
    if a.five:
        plan += [(5, 1, 1), (5, 0, 0)]
    for nl, wc, la in plan:
        t1 = time.time()
        try:
            n = T.run(nl, wc, la)
            res["runs"].append(dict(lanes=nl, write_combine=wc, lane_arb=la, requests=n, ok=True, seconds=round(time.time() - t1, 1)))
        except AssertionError as e:
            ok = False
            res["runs"].append(dict(lanes=nl, write_combine=wc, lane_arb=la, ok=False, error=str(e)[:400]))
        print(res["runs"][-1], flush=True)
    res["total_requests"] = sum(r.get("requests", 0) for r in res["runs"])
    res["ok"] = ok
    res["seconds"] = round(time.time() - t0, 1)
    with open(os.path.join(ROOT, "reports", "exhaustive.json"), "w") as f:
        json.dump(res, f, indent=1)
    print("exhaustive: %s, %d requests, %.0fs" % ("PASS" if ok else "FAIL", res["total_requests"], res["seconds"]))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
