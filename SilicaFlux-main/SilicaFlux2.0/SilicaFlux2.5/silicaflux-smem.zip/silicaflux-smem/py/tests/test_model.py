"""Unit tests for the Python models: mappings, stepwise issue vs sequential
reference, closed-form cost vs stepwise.  Run:  python3 -m unittest discover -s py/tests -t py"""
import itertools
import random
import unittest

from sfsm.arch import (Config, Lane, MAP_LINEAR, MAP_XOR, MAP_SKEW, MAP_BLOCK, map_word,
                       unmap_word, OP_LOAD, OP_STORE, OP_ADD, OP_CAS, ST_OK, ST_ALIGN,
                       ST_RANGE, ST_BADOP, ST_BE, M32, decode_lane)
from sfsm.ref import RefMem
from sfsm.issue import IssueModel, PhysMem, execute_request, request_cost, decode_request
from sfsm.randgen import rand_request, hot_set


def all_configs():
    for NL, NB, DEPTH in [(2, 2, 4), (4, 4, 8), (8, 8, 16), (16, 8, 8), (8, 4, 16), (32, 32, 4), (6, 4, 8)]:
        for m, g in [(MAP_LINEAR, 1), (MAP_XOR, 1), (MAP_SKEW, 1), (MAP_BLOCK, 0), (MAP_BLOCK, 1), (MAP_BLOCK, 2)]:
            for wc, la in [(1, 1), (0, 0), (1, 0), (0, 1)]:
                try:
                    yield Config(NL=NL, NB=NB, DEPTH=DEPTH, MAPPING=m, BLK_LOG2=g,
                                 WRITE_COMBINE=wc, LANE_ARB=la, AW=16)
                except ValueError:
                    continue


class TestMapping(unittest.TestCase):
    def test_bijection_exhaustive(self):
        for NB in (2, 4, 8, 16, 32):
            for DEPTH in (2, 4, 8, 32, 64):
                for m, g in [(MAP_LINEAR, 1), (MAP_XOR, 1), (MAP_SKEW, 1), (MAP_BLOCK, 0),
                             (MAP_BLOCK, 1), (MAP_BLOCK, 2), (MAP_BLOCK, 3)]:
                    try:
                        cfg = Config(NB=NB, DEPTH=DEPTH, MAPPING=m, BLK_LOG2=g, AW=20)
                    except ValueError:
                        continue
                    seen = set()
                    for w in range(cfg.cap_words):
                        b, r = map_word(cfg, w)
                        self.assertTrue(0 <= b < NB and 0 <= r < DEPTH, (cfg, w, b, r))
                        self.assertNotIn((b, r), seen, (cfg, w))
                        seen.add((b, r))
                        self.assertEqual(unmap_word(cfg, b, r), w, (cfg, w))
                    self.assertEqual(len(seen), cfg.cap_words)

    def test_known_values(self):
        c = Config(NB=8, DEPTH=16, MAPPING=MAP_LINEAR)
        self.assertEqual(map_word(c, 0x2B), (0x2B & 7, 0x2B >> 3))
        c = Config(NB=4, DEPTH=16, MAPPING=MAP_SKEW)       # w = 4*row + lo
        self.assertEqual(map_word(c, 4 * 3 + 1), ((1 + 3) & 3, 3))
        c = Config(NB=4, DEPTH=16, MAPPING=MAP_XOR)        # fold of 4 bit row in 2-bit chunks
        self.assertEqual(map_word(c, 4 * 0b1101 + 1), (1 ^ (0b01 ^ 0b11), 0b1101))
        c = Config(NB=4, DEPTH=16, MAPPING=MAP_BLOCK, BLK_LOG2=2)
        self.assertEqual(map_word(c, 0b1_01_10), (1, 0b1_10))   # w=22: bank (22>>2)&3 = 1, row = (22>>4)<<2 | 2 = 6
        self.assertEqual(map_word(c, 22), (1, 6))


class TestDecode(unittest.TestCase):
    def test_status_precedence(self):
        cfg = Config(NB=4, DEPTH=16, AW=16)       # capacity 64 words = 256 bytes
        L = lambda **k: Lane(**{**dict(v=1, op=OP_LOAD, addr=0, be=0xF, wd=0, cmp=0), **k})
        self.assertEqual(decode_lane(cfg, L()), (ST_OK, True))
        self.assertEqual(decode_lane(cfg, L(v=0, op=7, addr=3)), (ST_OK, False))
        self.assertEqual(decode_lane(cfg, L(op=5, addr=3)), (ST_BADOP, False))       # BADOP > ALIGN
        self.assertEqual(decode_lane(cfg, L(addr=3)), (ST_ALIGN, False))
        self.assertEqual(decode_lane(cfg, L(addr=3 + 256)), (ST_ALIGN, False))       # ALIGN > RANGE
        self.assertEqual(decode_lane(cfg, L(addr=256)), (ST_RANGE, False))
        self.assertEqual(decode_lane(cfg, L(op=OP_ADD, addr=256, be=3)), (ST_RANGE, False))  # RANGE > BE
        self.assertEqual(decode_lane(cfg, L(op=OP_CAS, be=0xE)), (ST_BE, False))
        self.assertEqual(decode_lane(cfg, L(op=OP_ADD, be=0)), (ST_BE, False))
        self.assertEqual(decode_lane(cfg, L(op=OP_LOAD, be=0)), (ST_OK, False))      # accepted no-op
        self.assertEqual(decode_lane(cfg, L(op=OP_STORE, be=0)), (ST_OK, False))


class TestRef(unittest.TestCase):
    def test_atomics_lane_order(self):
        cfg = Config(NL=4, NB=4, DEPTH=8, AW=16)
        m = RefMem(cfg)
        m.w[5] = 100
        lanes = [Lane(1, OP_ADD, 20, 0xF, 1, 0) for _ in range(4)]
        r = m.exec_request(lanes)
        self.assertEqual([x[2] for x in r], [100, 101, 102, 103])
        self.assertEqual(m.w[5], 104)

    def test_cas_chain(self):
        cfg = Config(NL=4, NB=4, DEPTH=8, AW=16)
        m = RefMem(cfg)
        m.w[1] = 7
        lanes = [Lane(1, OP_CAS, 4, 0xF, 8, 7),     # succeeds: 7 -> 8
                 Lane(1, OP_CAS, 4, 0xF, 99, 7),    # fails (sees 8)
                 Lane(1, OP_CAS, 4, 0xF, 9, 8),     # succeeds 8 -> 9
                 Lane(1, OP_ADD, 4, 0xF, M32, 0)]   # add -1 -> 8
        r = m.exec_request(lanes)
        self.assertEqual([x[2] for x in r], [7, 8, 8, 9])
        self.assertEqual(m.w[1], 8)

    def test_wrap_and_signed(self):
        cfg = Config(NL=2, NB=2, DEPTH=4, AW=16)
        m = RefMem(cfg)
        m.w[0] = M32
        m.exec_request([Lane(1, OP_ADD, 0, 0xF, 1, 0), Lane(1, OP_ADD, 0, 0xF, M32, 0)])
        self.assertEqual(m.w[0], M32)          # M32 + 1 = 0 ; 0 + (-1) = M32

    def test_store_highest_lane_wins_per_byte(self):
        cfg = Config(NL=4, NB=4, DEPTH=8, AW=16)
        m = RefMem(cfg)
        lanes = [Lane(1, OP_STORE, 8, 0x3, 0x11111111, 0), Lane(1, OP_STORE, 8, 0x6, 0x22222222, 0),
                 Lane(1, OP_STORE, 8, 0x8, 0x33333333, 0), Lane(0, OP_STORE, 8, 0xF, 0x44444444, 0)]
        m.exec_request(lanes)
        self.assertEqual(m.w[2], 0x33222211)


class TestStepwiseEqualsReference(unittest.TestCase):
    """The central claim: broadcast + write combining + per-bank arbitration are
    indistinguishable from lane-ordered sequential execution."""

    def _run(self, cfg, nreq, seed, **kw):
        rng = random.Random(seed)
        ref, phys, iss = RefMem(cfg), PhysMem(), IssueModel(cfg)
        hot = hot_set(rng, cfg, 5)
        for i in range(nreq):
            lanes = rand_request(rng, cfg, hot, **kw)
            want = ref.exec_request(lanes)
            got, cycles, _ = execute_request(cfg, iss, phys, lanes)
            self.assertEqual(got, want, (cfg.label(), seed, i))
            self.assertEqual(request_cost(cfg, lanes)["d"], cycles, (cfg.label(), seed, i))
        for w in range(cfg.cap_words):
            b, r = map_word(cfg, w)
            self.assertEqual(phys.get(b, r), ref.w[w], (cfg.label(), "final", w))

    def test_random_all_configs(self):
        n = 0
        for cfg in all_configs():
            self._run(cfg, 40, seed=hash((cfg.label(), cfg.WRITE_COMBINE, cfg.LANE_ARB)) & 0xFFFF)
            n += 1
        self.assertGreater(n, 100)

    def test_heavy_same_word_mix(self):
        for wc in (0, 1):
            cfg = Config(NL=16, NB=4, DEPTH=8, AW=16, WRITE_COMBINE=wc)
            for seed in range(30):
                self._run(cfg, 60, seed, p_hot=0.95, p_inactive=0.05, op_w=(3, 3, 2, 2))

    def test_lane_arb_policy_is_performance_neutral(self):
        """LANE_ARB changes only the order of different words inside one bank."""
        for seed in range(20):
            rng = random.Random(seed)
            c0 = Config(NL=16, NB=4, DEPTH=16, AW=16, LANE_ARB=0)
            c1 = c0.with_(LANE_ARB=1)
            r0, r1, p0, p1 = RefMem(c0), RefMem(c1), PhysMem(), PhysMem()
            i0, i1 = IssueModel(c0), IssueModel(c1)
            hot = hot_set(rng, c0, 6)
            for _ in range(50):
                lanes = rand_request(rng, c0, hot)
                a, ca, _ = execute_request(c0, i0, p0, lanes)
                b, cb, _ = execute_request(c1, i1, p1, lanes)
                self.assertEqual(a, b)
                self.assertEqual(ca, cb)


class TestCost(unittest.TestCase):
    def test_unit_stride_conflict_free(self):
        cfg = Config(NL=8, NB=8, DEPTH=16, AW=16)
        lanes = [Lane(1, OP_LOAD, 4 * i, 0xF, 0, 0) for i in range(8)]
        self.assertEqual(request_cost(cfg, lanes)["d"], 1)

    def test_stride_nb_is_nb_way(self):
        cfg = Config(NL=8, NB=8, DEPTH=16, AW=16)
        lanes = [Lane(1, OP_LOAD, 4 * 8 * i, 0xF, 0, 0) for i in range(8)]
        self.assertEqual(request_cost(cfg, lanes)["d"], 8)
        self.assertEqual(request_cost(cfg.with_(MAPPING=MAP_XOR), lanes)["d"], 1)
        self.assertEqual(request_cost(cfg.with_(MAPPING=MAP_SKEW), lanes)["d"], 1)

    def test_broadcast_and_atomic_chain(self):
        cfg = Config(NL=8, NB=8, DEPTH=16, AW=16)
        self.assertEqual(request_cost(cfg, [Lane(1, OP_LOAD, 40, 0xF, 0, 0)] * 8)["d"], 1)
        self.assertEqual(request_cost(cfg, [Lane(1, OP_ADD, 40, 0xF, 1, 0)] * 8)["d"], 8)
        seq = [Lane(1, OP_LOAD, 40, 0xF, 0, 0), Lane(1, OP_STORE, 40, 0xF, 1, 0),
               Lane(1, OP_LOAD, 40, 0xF, 0, 0), Lane(1, OP_ADD, 40, 0xF, 1, 0),
               Lane(1, OP_LOAD, 40, 0xF, 0, 0)]
        seq += [Lane(0, 0, 0, 0, 0, 0)] * 3
        self.assertEqual(request_cost(cfg, seq)["d"], 5)
        stores = [Lane(1, OP_STORE, 40, 0xF, i, 0) for i in range(8)]
        self.assertEqual(request_cost(cfg, stores)["d"], 1)
        self.assertEqual(request_cost(cfg.with_(WRITE_COMBINE=0), stores)["d"], 8)

    def test_empty_request_costs_one(self):
        cfg = Config(NL=4, NB=4, DEPTH=8, AW=16)
        self.assertEqual(request_cost(cfg, [Lane(0, 0, 0, 0, 0, 0)] * 4)["d"], 1)


if __name__ == "__main__":
    unittest.main()
