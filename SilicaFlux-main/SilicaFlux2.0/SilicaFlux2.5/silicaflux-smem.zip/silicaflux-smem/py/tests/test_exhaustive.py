"""Bounded-exhaustive check of the central claim:

    broadcast + write combining + per-bank arbitration  ==  lane-ordered sequential execution

Every combination of lane operations of a 4-lane request (5-lane with SFSM_EXHAUSTIVE5=1) over a
three-word address space is enumerated: two words in ONE bank (same-bank / different-row conflicts),
one word in another bank, from a fixed non-zero initial memory.  Each lane is independently one of
  inactive (junk fields) | LOAD (full, partial be) | STORE (full, partial be) | ADD | CAS (two
  different expected values) on one of the three words.
For every combination the stepwise model (the RTL algorithm) must reproduce the sequential
reference exactly - responses AND final memory through the bank mapping - and the closed-form
cycle count must equal the stepwise one.   Data values are distinct per lane so that any mix-up of
lanes, bytes or order is visible.
"""
import itertools
import os
import unittest

from sfsm.arch import Config, Lane, map_word, OP_LOAD, OP_STORE, OP_ADD, OP_CAS
from sfsm.ref import RefMem
from sfsm.issue import IssueModel, PhysMem, execute_request, request_cost

WORDS = (0, 2, 1)                        # NB=2: words 0 and 2 share bank 0 (rows 0,1), word 1 is in bank 1
INIT = {0: 0xA0A0A0A0, 2: 0xB0B0B0B0, 1: 0xC0C0C0C0}


def lane_options(lane_idx):
    opts = [Lane(0, 5, 0xFFC, 0x5, 0x12345678, 0x9ABCDEF0)]                       # inactive, junk
    for w in WORDS:
        opts.append(Lane(1, OP_LOAD, w * 4, 0xF, 0, 0))
    opts.append(Lane(1, OP_LOAD, 0, 0x5, 0, 0))                                    # partial byte mask
    for w in WORDS:
        for be in (0xF, 0x3):
            opts.append(Lane(1, OP_STORE, w * 4, be, 0x11111111 * (lane_idx + 1), 0))
    for w in WORDS:
        opts.append(Lane(1, OP_ADD, w * 4, 0xF, lane_idx + 1, 0))
    for w in WORDS:
        for cmp_ in (INIT[w], 0x11111111):
            opts.append(Lane(1, OP_CAS, w * 4, 0xF, 0xDEAD0000 + lane_idx, cmp_))
    return opts


def run(nl, wc, la):
    cfg = Config(NL=nl, NB=2, DEPTH=4, AW=12, WRITE_COMBINE=wc, LANE_ARB=la)
    per_lane = [lane_options(l) for l in range(nl)]
    n = 0
    for combo in itertools.product(*per_lane):
        ref = RefMem(cfg)
        phys = PhysMem()
        for w, v in INIT.items():
            ref.w[w] = v
            b, r = map_word(cfg, w)
            phys.m[(b, r)] = v
        want = ref.exec_request(list(combo))
        got, cycles, _ = execute_request(cfg, IssueModel(cfg), phys, list(combo))
        if got != want:
            raise AssertionError("response mismatch for %r:\n want %r\n got  %r" % (combo, want, got))
        for w in range(cfg.cap_words):
            b, r = map_word(cfg, w)
            if phys.get(b, r) != ref.w[w]:
                raise AssertionError("memory mismatch at word %d for %r" % (w, combo))
        if request_cost(cfg, list(combo))["d"] != cycles:
            raise AssertionError("closed-form cycle count mismatch for %r" % (combo,))
        n += 1
    return n


class TestExhaustive(unittest.TestCase):
    def test_four_lanes_all_policies(self):
        total = 0
        for wc in (1, 0):
            for la in (1, 0):
                total += run(4, wc, la)
        self.assertEqual(total, 4 * len(lane_options(0)) ** 4)

    @unittest.skipUnless(os.environ.get("SFSM_EXHAUSTIVE5"), "set SFSM_EXHAUSTIVE5=1 for the 5-lane enumeration (minutes)")
    def test_five_lanes(self):
        self.assertEqual(run(5, 1, 1), len(lane_options(0)) ** 5)
        self.assertEqual(run(5, 0, 0), len(lane_options(0)) ** 5)


if __name__ == "__main__":
    unittest.main()
