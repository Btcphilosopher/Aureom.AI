"""Architectural definitions shared by every Python model of the SilicaFlux
Shared Memory (SFSM).  Normative text: docs/SEMANTICS.md.  Standard library only.
"""
from collections import namedtuple
from dataclasses import dataclass, replace

M32 = 0xFFFFFFFF

# lane opcodes (3-bit field; 4..7 reserved)
OP_LOAD, OP_STORE, OP_ADD, OP_CAS = 0, 1, 2, 3
OP_NAMES = {OP_LOAD: "LD", OP_STORE: "ST", OP_ADD: "ADD", OP_CAS: "CAS"}

# per-lane status
ST_OK, ST_ALIGN, ST_RANGE, ST_BADOP, ST_BE = 0, 1, 2, 3, 4
ST_NAMES = {0: "OK", 1: "ALIGN", 2: "RANGE", 3: "BADOP", 4: "BE"}

# bank mappings
MAP_LINEAR, MAP_XOR, MAP_SKEW, MAP_BLOCK = 0, 1, 2, 3
MAP_NAMES = {0: "linear", 1: "xor", 2: "skew", 3: "block"}

LAT_MIN = 4   # request accept -> response visible, unloaded, conflict free


def clog2(n):
    return (n - 1).bit_length() if n > 1 else 0


def is_pow2(n):
    return n > 0 and (n & (n - 1)) == 0


# One lane of a request.  v = lane active.  Inactive lanes may carry any values.
Lane = namedtuple("Lane", "v op addr be wd cmp")
INACTIVE = Lane(0, 0, 0, 0, 0, 0)

# One request on one port.  gap = idle cycles after the previous request of the same
# port was accepted before this one is presented (first request: cycles after reset
# release).
Req = namedtuple("Req", "gap tag lanes")


@dataclass(frozen=True)
class Config:
    NL: int = 8
    NB: int = 8
    DEPTH: int = 256
    NP: int = 2
    REQ_DEPTH: int = 2
    RSP_DEPTH: int = 4
    TAGW: int = 8
    AW: int = 32
    MAPPING: int = MAP_LINEAR
    BLK_LOG2: int = 1
    LANE_ARB: int = 1
    PORT_ARB: int = 1
    WRITE_COMBINE: int = 1
    INIT_ON_RESET: int = 1

    def __post_init__(self):
        if self.NL < 2:
            raise ValueError("NL must be >= 2")
        if self.NB < 2 or not is_pow2(self.NB):
            raise ValueError("NB must be a power of two >= 2")
        if self.DEPTH < 2 or not is_pow2(self.DEPTH):
            raise ValueError("DEPTH must be a power of two >= 2")
        if self.AW < self.WIDX_W + 2:
            raise ValueError("AW too small")
        if self.MAPPING == MAP_BLOCK and not (0 <= self.BLK_LOG2 <= self.RW):
            raise ValueError("BLK_LOG2 out of range")

    # ---- derived ----
    @property
    def BW(self):
        return clog2(self.NB)

    @property
    def RW(self):
        return clog2(self.DEPTH)

    @property
    def WIDX_W(self):
        return self.BW + self.RW

    @property
    def cap_words(self):
        return self.NB * self.DEPTH

    @property
    def cap_bytes(self):
        return 4 * self.NB * self.DEPTH

    def with_(self, **kw):
        return replace(self, **kw)

    def rtl_params(self):
        """Parameters forwarded to the RTL (Verilator -G / Icarus -P)."""
        return {k: getattr(self, k) for k in (
            "NL", "NB", "DEPTH", "NP", "REQ_DEPTH", "RSP_DEPTH", "TAGW", "AW", "MAPPING",
            "BLK_LOG2", "LANE_ARB", "PORT_ARB", "WRITE_COMBINE", "INIT_ON_RESET")}

    def label(self):
        m = MAP_NAMES[self.MAPPING] + (str(self.BLK_LOG2) if self.MAPPING == MAP_BLOCK else "")
        return "NL%d_NB%d_D%d_NP%d_%s" % (self.NL, self.NB, self.DEPTH, self.NP, m)


# --------------------------------------------------------------------------- mappings
def fold(cfg, hi):
    """XOR of B-bit chunks of a row index."""
    B, R = cfg.BW, cfg.RW
    acc, i = 0, 0
    while i < R:
        acc ^= (hi >> i) & ((1 << B) - 1)
        i += B
    return acc


def map_word(cfg, w):
    """architectural word index -> (bank, row)"""
    B, R, NB = cfg.BW, cfg.RW, cfg.NB
    m = cfg.MAPPING
    lo, hi = w & (NB - 1), w >> B
    if m == MAP_LINEAR:
        return lo, hi
    if m == MAP_XOR:
        return lo ^ fold(cfg, hi), hi
    if m == MAP_SKEW:
        return (lo + (hi & (NB - 1))) & (NB - 1), hi
    G = cfg.BLK_LOG2
    bank = (w >> G) & (NB - 1)
    row = ((w >> (G + B)) << G) | (w & ((1 << G) - 1))
    return bank, row


def unmap_word(cfg, bank, row):
    """inverse of map_word"""
    B, NB = cfg.BW, cfg.NB
    m = cfg.MAPPING
    if m == MAP_LINEAR:
        return (row << B) | bank
    if m == MAP_XOR:
        return (row << B) | (bank ^ fold(cfg, row))
    if m == MAP_SKEW:
        return (row << B) | ((bank - (row & (NB - 1))) & (NB - 1))
    G = cfg.BLK_LOG2
    return ((row >> G) << (G + B)) | (bank << G) | (row & ((1 << G) - 1))


# --------------------------------------------------------------------------- lane decode
def bytemask(be):
    m = 0
    for i in range(4):
        if (be >> i) & 1:
            m |= 0xFF << (8 * i)
    return m


def merge_bytes(old, new, be):
    m = bytemask(be)
    return (old & ~m & M32) | (new & m)


def is_atomic(op):
    return op in (OP_ADD, OP_CAS)


def decode_lane(cfg, ln):
    """Validate one lane.  Returns (status, pend).
    status precedence: BADOP > ALIGN > RANGE > BE.
    pend = the lane needs a bank access (valid, legal, and not a no-op).
    A plain LOAD/STORE with no byte enabled is an accepted no-op (OK, data 0)."""
    if not ln.v:
        return ST_OK, False
    if ln.op >= 4:
        st = ST_BADOP
    elif ln.addr & 3:
        st = ST_ALIGN
    elif (ln.addr >> 2) >= cfg.cap_words:
        st = ST_RANGE
    elif is_atomic(ln.op) and ln.be != 0xF:
        st = ST_BE
    else:
        st = ST_OK
    if st != ST_OK:
        return st, False
    nop = (not is_atomic(ln.op)) and ln.be == 0
    return ST_OK, (not nop)
