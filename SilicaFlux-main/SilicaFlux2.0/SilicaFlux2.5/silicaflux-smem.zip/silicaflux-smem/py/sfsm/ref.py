"""Sequential reference model = the architectural definition of SFSM semantics.

A request is executed lane 0, 1, ..., NL-1 in order, each lane operation being a
single indivisible read-modify-write on one 32-bit word.  Nothing about banks,
mappings, buffering or timing appears here: this is what the hardware must be
indistinguishable from.  (docs/SEMANTICS.md section 3.)
"""
from .arch import (M32, OP_LOAD, OP_STORE, OP_ADD, OP_CAS, ST_OK, bytemask,
                   merge_bytes, decode_lane)


class RefMem:
    """Word-addressed architectural memory (mapping independent)."""

    def __init__(self, cfg, init=0):
        self.cfg = cfg
        self.w = [init] * cfg.cap_words

    def copy(self):
        m = RefMem(self.cfg)
        m.w = list(self.w)
        return m

    def exec_lane(self, ln):
        """Execute one lane operation.  Returns (valid, status, data)."""
        if not ln.v:
            return (0, 0, 0)
        st, pend = decode_lane(self.cfg, ln)
        if st != ST_OK:
            return (1, st, 0)
        if not pend:                       # accepted no-op
            return (1, ST_OK, 0)
        i = ln.addr >> 2
        old = self.w[i]
        if ln.op == OP_LOAD:
            return (1, ST_OK, old & bytemask(ln.be))
        if ln.op == OP_STORE:
            self.w[i] = merge_bytes(old, ln.wd, ln.be)
            return (1, ST_OK, 0)
        if ln.op == OP_ADD:
            self.w[i] = (old + ln.wd) & M32
            return (1, ST_OK, old)
        # OP_CAS
        if old == (ln.cmp & M32):
            self.w[i] = ln.wd & M32
        return (1, ST_OK, old)

    def exec_request(self, lanes):
        """Execute a whole request in ascending lane order.  Returns the per-lane
        list of (valid, status, data)."""
        return [self.exec_lane(ln) for ln in lanes]
