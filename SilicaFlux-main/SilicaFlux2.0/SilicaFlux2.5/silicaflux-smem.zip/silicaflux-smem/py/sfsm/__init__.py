"""SilicaFlux Shared Memory (SFSM) Python models: architecture, sequential
reference, stepwise issue model, cycle model, workloads, metrics.  Stdlib only."""
