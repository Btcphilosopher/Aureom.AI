"""Benchmark configurations and workload lists shared by py/tools/bench.py (model
sweeps) and sim/run_regress.py --suite bench (the same traces replayed on the RTL).
"""
from .arch import (Config, MAP_LINEAR, MAP_XOR, MAP_SKEW, MAP_BLOCK, Lane, OP_LOAD, OP_ADD, Req)
from . import workloads as W

MAPPINGS = [
    ("linear", dict(MAPPING=MAP_LINEAR)),
    ("xor", dict(MAPPING=MAP_XOR)),
    ("skew", dict(MAPPING=MAP_SKEW)),
    ("block1", dict(MAPPING=MAP_BLOCK, BLK_LOG2=1)),
    ("block2", dict(MAPPING=MAP_BLOCK, BLK_LOG2=2)),
]


def bench_config(n, mapping_kw, np_=1, depth=None):
    """n lanes = n banks (the conventional 1 lane : 1 bank design point)."""
    depth = depth or (128 if n <= 16 else 256)
    return Config(NL=n, NB=n, DEPTH=depth, NP=np_, AW=20, **mapping_kw)


def workload_list(cfg):
    """The workloads of the benchmark table (tile size = lane count)."""
    T = cfg.NL
    ws = [
        W.reduction(cfg, "interleaved"), W.reduction(cfg, "sequential"),
        W.reduction(cfg, "atomic_flat"), W.reduction(cfg, "atomic_private"),
        W.histogram(cfg, "uniform"), W.histogram(cfg, "skewed"), W.histogram(cfg, "single"),
        W.histogram(cfg, "lane"), W.histogram(cfg, "uniform", privatized=True),
        W.gemm_tiled(cfg, T=T), W.transpose_tile(cfg, T=T), W.transpose_tile(cfg, T=T, pitch=T + 1),
        W.cas_increment(cfg), W.cas_max(cfg), W.hot_add(cfg, nreq=100),
        W.strided_stream(cfg, 1), W.strided_stream(cfg, 2), W.strided_stream(cfg, cfg.NB),
        W.strided_stream(cfg, cfg.NB + 1), W.strided_stream(cfg, 2 * cfg.NB),
        W.fuzz(cfg.with_(NP=1), seed=7, p_hot=0.3, p_inactive=0.1),
    ]
    return ws
