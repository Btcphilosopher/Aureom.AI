"""Random request generation shared by the unit tests, the RTL fuzz traces and the
benchmarks.  Deterministic for a given random.Random seed."""
import random
from .arch import (Lane, INACTIVE, Req, M32, OP_LOAD, OP_STORE, OP_ADD, OP_CAS)

BE_CHOICES = [0xF] * 8 + [0x3, 0xC, 0x1, 0x2, 0x4, 0x8, 0x5, 0xA, 0x7, 0xE, 0x0]


def rand_word(rng):
    r = rng.random()
    if r < 0.15:
        return rng.choice([0, 1, M32, 0x80000000, 0x7FFFFFFF, 0xFFFFFFFE])
    return rng.getrandbits(32)


def rand_lane(rng, cfg, hot, p_hot=0.6, p_inactive=0.15, p_err=0.04,
              op_w=(4, 3, 2, 2)):
    """One random lane.  hot = list of word indices that attract traffic."""
    if rng.random() < p_inactive:
        # inactive lanes carry arbitrary junk that must be ignored
        return Lane(0, rng.randrange(8), rng.getrandbits(cfg.AW), rng.getrandbits(4),
                    rng.getrandbits(32), rng.getrandbits(32))
    op = rng.choices([OP_LOAD, OP_STORE, OP_ADD, OP_CAS], weights=op_w)[0]
    w = rng.choice(hot) if rng.random() < p_hot else rng.randrange(cfg.cap_words)
    addr = w << 2
    be = rng.choice(BE_CHOICES)
    if op in (OP_ADD, OP_CAS):
        be = 0xF if rng.random() < 0.97 else rng.choice([0, 1, 7, 0xE])
    wd = rand_word(rng)
    cmp_ = rand_word(rng)
    if rng.random() < p_err:
        k = rng.randrange(4)
        if k == 0:
            op = rng.randrange(4, 8)
        elif k == 1:
            addr |= rng.randrange(1, 4)
        elif k == 2:
            addr = (cfg.cap_words + rng.randrange(0, 1 << 10)) << 2
            addr &= (1 << cfg.AW) - 1
        else:
            if op in (OP_ADD, OP_CAS):
                be = rng.choice([0, 1, 3, 0xE])
    return Lane(1, op, addr & ((1 << cfg.AW) - 1), be, wd, cmp_)


def rand_request(rng, cfg, hot, **kw):
    return [rand_lane(rng, cfg, hot, **kw) for _ in range(cfg.NL)]


def hot_set(rng, cfg, n=6):
    """A few words, deliberately packed into few banks (via the architectural address)."""
    base = rng.randrange(cfg.cap_words)
    words = {base}
    while len(words) < n:
        r = rng.random()
        if r < 0.4:
            words.add((base + rng.randrange(1, 4)) % cfg.cap_words)
        elif r < 0.8:
            words.add((base + cfg.NB * rng.randrange(1, 5)) % cfg.cap_words)  # same bank (linear)
        else:
            words.add(rng.randrange(cfg.cap_words))
    return sorted(words)


def rand_trace(rng, cfg, nreq_per_port, max_gap=3, **kw):
    """List (per port) of list[Req]."""
    out = []
    for _p in range(cfg.NP):
        hot = hot_set(rng, cfg)
        reqs = []
        for i in range(nreq_per_port):
            gap = rng.choice([0, 0, 0, 0, 1, 2, max_gap]) if max_gap else 0
            reqs.append(Req(gap, rng.getrandbits(cfg.TAGW), rand_request(rng, cfg, hot, **kw)))
        out.append(reqs)
    return out
