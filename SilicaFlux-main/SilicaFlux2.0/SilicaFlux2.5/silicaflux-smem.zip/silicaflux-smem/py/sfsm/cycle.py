"""Cycle-accurate system model of sf_smem_top.

It reproduces, cycle for cycle, what the RTL does at its ports: request FIFO
back-pressure, response credits, request arbitration between ports, the number of
issue cycles of every request (closed form, validated against the stepwise issue
model and against the RTL), the one-cycle bank stage, response FIFOs, the init
sweep and the performance counters.  Data results come from the sequential
reference executed in GRANT order (the RTL executes requests one at a time, in
grant order, each completely before the next).

Client protocol (identical in tb/tb_smem_replay.sv):
  * cycle 0 is the first cycle after reset release; the init sweep keeps
    req_ready low during cycles [0, DEPTH) when INIT_ON_RESET.
  * port p presents request i in cycle  gap_0  (i = 0)  or  accept_cycle(i-1) + 1 + gap_i,
    holds it until req_ready, i.e. it may wait in the init sweep.
  * rsp_ready[p] in cycle c is  (c mod period_p) < duty_p.
"""
from collections import deque
from .arch import Config, LAT_MIN
from .ref import RefMem
from .issue import decode_request, request_cost

PERF_NAMES_BASE = ["active_cycles", "requests", "conflict_cycles", "bank_groups",
                   "lanes_served", "atomic_lanes", "error_lanes", "credit_stall_cycles"]


def perf_names(cfg):
    return (PERF_NAMES_BASE + ["grants_p%d" % p for p in range(cfg.NP)]
            + ["wait_p%d" % p for p in range(cfg.NP)] + ["bank_busy_b%d" % b for b in range(cfg.NB)])


class SimResult:
    def __init__(self):
        self.acc = {}          # (p, i) -> accept cycle
        self.grant = {}        # (p, i) -> cycle in which the request was loaded into the active register
        self.first_issue = {}  # (p, i) -> first issue cycle
        self.last_issue = {}   # (p, i) -> last issue cycle
        self.rsp = {}          # (p, i) -> (cycle, tag, lane_valid[], status[], data[])
        self.rsp_vis = {}      # (p, i) -> first cycle rsp_valid was visible
        self.order = []        # grant order [(p, i)]
        self.perf = None
        self.mem = None        # RefMem after the run
        self.cycles = 0        # cycle at which the last response was consumed
        self.cost = {}         # (p, i) -> request_cost dict


def simulate(cfg, per_port, rsp_pat=None, max_cycles=2_000_000, mem=None, record_cost=False):
    """per_port: list (len NP) of list[Req].  rsp_pat: list of (period, duty) per port."""
    NP = cfg.NP
    assert len(per_port) == NP
    rsp_pat = rsp_pat or [(1, 1)] * NP
    ref = mem if mem is not None else RefMem(cfg)
    res = SimResult()

    fifo = [deque() for _ in range(NP)]
    rspq = [deque() for _ in range(NP)]
    cred = [cfg.RSP_DEPTH] * NP
    outst = [0] * NP
    act = None                       # dict: port, idx, rem, resp, cost
    g1 = None                        # record travelling with the bank stage
    port_ptr = 0
    nxt = [0] * NP
    t_avail = [reqs[0].gap if reqs else None for reqs in per_port]
    total = sum(len(r) for r in per_port)
    done = 0
    perf = {n: 0 for n in perf_names(cfg)}
    seen_rsp_vis = set()

    c = 0
    while done < total:
        if c > max_cycles:
            raise RuntimeError("simulation did not drain (deadlock?)")
        init_busy = bool(cfg.INIT_ON_RESET) and c < cfg.DEPTH

        # ---- outputs (functions of state only) ----
        req_ready = [(not init_busy) and len(fifo[p]) < cfg.REQ_DEPTH for p in range(NP)]
        rsp_valid = [len(rspq[p]) > 0 for p in range(NP)]
        # ---- client ----
        req_valid = [nxt[p] < len(per_port[p]) and t_avail[p] is not None and c >= t_avail[p]
                     for p in range(NP)]
        rsp_ready = [(c % rsp_pat[p][0]) < rsp_pat[p][1] for p in range(NP)]

        for p in range(NP):
            if rsp_valid[p] and (p, rspq[p][0][0]) not in seen_rsp_vis:
                seen_rsp_vis.add((p, rspq[p][0][0]))
                res.rsp_vis[(p, rspq[p][0][0])] = c

        # ---- combinational control ----
        elig = [len(fifo[p]) > 0 and cred[p] > 0 for p in range(NP)]
        sel = None
        if cfg.PORT_ARB != 0:
            for p in range(NP):
                if elig[p] and p >= port_ptr:
                    sel = p
                    break
        if sel is None:
            for p in range(NP):
                if elig[p]:
                    sel = p
                    break
        act_valid = act is not None
        act_last = act_valid and act["rem"] == 1
        load = sel is not None and ((not act_valid) or act_last)

        # ---- performance counters (state before the edge) ----
        if act_valid:
            perf["active_cycles"] += 1
            if act_last:
                perf["requests"] += 1
            else:
                perf["conflict_cycles"] += 1
        if any(len(fifo[p]) > 0 and cred[p] == 0 for p in range(NP)):
            perf["credit_stall_cycles"] += 1
        for p in range(NP):
            if len(fifo[p]) > 0 and not (load and sel == p):
                perf["wait_p%d" % p] += 1
        # per-group counters are charged when the request is issued (see below)

        # ---- edge: compute next state from the old state ----
        # response pop
        pops = []
        for p in range(NP):
            if rsp_valid[p] and rsp_ready[p]:
                pops.append(p)
        # push from the bank stage record
        push = None
        if g1 is not None and g1["last"]:
            push = g1
        # new FIFO head popped by load
        loaded = None
        if load:
            loaded = fifo[sel].popleft()
        # accepts
        accepts = [p for p in range(NP) if req_valid[p] and req_ready[p]]

        for p in pops:
            idx, tag, lv, st, data = rspq[p].popleft()
            res.rsp[(p, idx)] = (c, tag, lv, st, data)
            cred[p] += 1
            outst[p] -= 1
            done += 1
            res.cycles = c
        if push is not None:
            rspq[push["port"]].append(push["item"])
            assert len(rspq[push["port"]]) <= cfg.RSP_DEPTH, "credit scheme violated"
        for p in accepts:
            i = nxt[p]
            req = per_port[p][i]
            fifo[p].append((i, req))
            res.acc[(p, i)] = c
            outst[p] += 1
            nxt[p] += 1
            t_avail[p] = (c + 1 + per_port[p][nxt[p]].gap) if nxt[p] < len(per_port[p]) else None

        # active register / bank stage record
        g1_new = None
        if act_valid:
            g1_new = dict(port=act["port"], last=act_last, item=act["item"] if act_last else None)
            if act["first"]:
                res.first_issue[(act["port"], act["idx"])] = c
                act["first"] = False
            if act_last:
                res.last_issue[(act["port"], act["idx"])] = c
        act_new = act
        if act_valid and not act_last:
            act["rem"] -= 1
        if act_last:
            act_new = None
        if load:
            i, req = loaded
            cost = request_cost(cfg, decode_request(cfg, req.lanes))
            resp = ref.exec_request(req.lanes)
            item = (i, req.tag, [r[0] for r in resp], [r[1] for r in resp], [r[2] for r in resp])
            act_new = dict(port=sel, idx=i, rem=cost["d"], item=item, first=True)
            cred[sel] -= 1
            port_ptr = 0 if sel == NP - 1 else sel + 1
            res.grant[(sel, i)] = c
            res.order.append((sel, i))
            res.cost[(sel, i)] = cost
            perf["grants_p%d" % sel] += 1
            perf["error_lanes"] += cost["err"]
            perf["lanes_served"] += cost["lanes"]
            perf["atomic_lanes"] += cost["atomic"]
            perf["bank_groups"] += sum(cost["groups"])
            for b in range(cfg.NB):
                perf["bank_busy_b%d" % b] += cost["groups"][b]
        act, g1 = act_new, g1_new
        c += 1

    res.perf = perf
    res.mem = ref
    return res
