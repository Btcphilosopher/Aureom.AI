"""Trace files for tb/tb_smem_replay.sv and comparison of RTL logs with the models.

Per-port trace file  <prefix>.p<k>.trace   (all numbers hexadecimal):
    line 1 :  N PERIOD DUTY
    line i :  GAP TAG  then per lane:  V OP BE ADDR WDATA CMP

RTL log written by the testbench (one record per line):
    ACC  p i cycle
    RSP  p i cycle tag lane_valid_mask st_0..st_{NL-1} data_0..data_{NL-1}
    PERF idx value
    MEM  word value            (architectural read-back through port 0)
    PHY  bank row value        (backdoor dump of the bank arrays)
    DONE cycle
"""
import os
from .arch import map_word, M32
from .cycle import perf_names


def write_port_trace(path, reqs, period=1, duty=1):
    with open(path, "w") as f:
        f.write("%x %x %x\n" % (len(reqs), period, duty))
        for r in reqs:
            toks = ["%x" % r.gap, "%x" % r.tag]
            for ln in r.lanes:
                toks += ["%x" % ln.v, "%x" % ln.op, "%x" % ln.be, "%x" % ln.addr,
                         "%x" % (ln.wd & M32), "%x" % (ln.cmp & M32)]
            f.write(" ".join(toks) + "\n")


def write_traces(prefix, cfg, per_port, rsp_pat=None):
    rsp_pat = rsp_pat or [(1, 1)] * cfg.NP
    os.makedirs(os.path.dirname(prefix) or ".", exist_ok=True)
    for p in range(cfg.NP):
        write_port_trace("%s.p%d.trace" % (prefix, p), per_port[p], *rsp_pat[p])


def parse_log(path, cfg):
    """Parse the testbench log into a dict of dicts."""
    out = dict(acc={}, rsp={}, perf={}, mem={}, phy={}, done=None, other=[])
    NL = cfg.NL
    with open(path) as f:
        for line in f:
            t = line.split()
            if not t:
                continue
            k = t[0]
            if k == "ACC":
                out["acc"][(int(t[1]), int(t[2]))] = int(t[3])
            elif k == "RSP":
                p, i, cyc = int(t[1]), int(t[2]), int(t[3])
                tag, lv = int(t[4], 16), int(t[5], 16)
                st = [int(x, 16) for x in t[6:6 + NL]]
                data = [int(x, 16) for x in t[6 + NL:6 + 2 * NL]]
                out["rsp"][(p, i)] = (cyc, tag, [(lv >> l) & 1 for l in range(NL)], st, data)
            elif k == "PERF":
                out["perf"][int(t[1])] = int(t[2], 16)
            elif k == "MEM":
                out["mem"][int(t[1])] = int(t[2], 16)
            elif k == "PHY":
                out["phy"][(int(t[1]), int(t[2]))] = int(t[3], 16)
            elif k == "DONE":
                out["done"] = int(t[1])
            else:
                out["other"].append(line.rstrip())
    return out


def compare(cfg, res, log, check_phys=True, check_perf=True, max_report=8):
    """Compare a cycle-model SimResult with a parsed RTL log.  Returns a list of
    mismatch descriptions (empty = identical)."""
    bad = []

    def rep(msg):
        if len(bad) < max_report:
            bad.append(msg)
        elif len(bad) == max_report:
            bad.append("... further mismatches suppressed")

    if log["done"] is None:
        rep("RTL log has no DONE record (testbench did not finish)")
    for key, c in sorted(res.acc.items()):
        got = log["acc"].get(key)
        if got != c:
            rep("ACC %s: model cycle %s, RTL %s" % (key, c, got))
    for key, (c, tag, lv, st, data) in sorted(res.rsp.items()):
        got = log["rsp"].get(key)
        if got is None:
            rep("RSP %s missing in RTL log" % (key,))
            continue
        gc, gtag, glv, gst, gdata = got
        if (gc, gtag, glv, gst, gdata) != (c, tag, lv, st, data):
            rep("RSP %s: model cyc=%d tag=%x lv=%s st=%s data=%s | RTL cyc=%d tag=%x lv=%s st=%s data=%s" % (
                key, c, tag, lv, st, ["%08x" % x for x in data], gc, gtag, glv, gst,
                ["%08x" % x for x in gdata]))
    extra = set(log["rsp"]) - set(res.rsp)
    if extra:
        rep("RTL produced responses the model did not: %s" % sorted(extra)[:4])
    if check_perf and log["perf"]:
        names = perf_names(cfg)
        for i, n in enumerate(names):
            if log["perf"].get(i) != res.perf[n]:
                rep("PERF %s: model %d, RTL %s" % (n, res.perf[n], log["perf"].get(i)))
    if log["mem"]:
        for w in range(cfg.cap_words):
            if log["mem"].get(w) != res.mem.w[w]:
                rep("MEM word %d: model %08x, RTL %s" % (w, res.mem.w[w],
                    "none" if w not in log["mem"] else "%08x" % log["mem"][w]))
    if check_phys and log["phy"]:
        for w in range(cfg.cap_words):
            b, r = map_word(cfg, w)
            if log["phy"].get((b, r)) != res.mem.w[w]:
                rep("PHY bank %d row %d (word %d): expected %08x, RTL %s" % (
                    b, r, w, res.mem.w[w], log["phy"].get((b, r))))
    return bad
