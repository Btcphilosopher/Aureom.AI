"""Stepwise model of the per-bank arbitration (rtl/sf_smem_issue.sv) and of the
bank operation, plus the closed-form cycle count it implies.

Three things are provided and cross-checked by py/tests:

  IssueModel.step()      one issue cycle: anchors, ready lanes, per-bank group,
                         merged bank operation, rotating pointers.  Mirrors the RTL.
  execute_request()      run a request to completion through IssueModel + a physical
                         bank model; result must equal sfsm.ref (the architecture).
  request_cost()         closed form: cycles and bank-group counts without stepping.
"""
from .arch import (M32, OP_LOAD, OP_STORE, OP_ADD, OP_CAS, ST_OK, decode_lane,
                   map_word, merge_bytes, bytemask, is_atomic)

CLS_LOAD, CLS_STORE, CLS_ATOM = 0, 1, 2


def op_class(op):
    return CLS_ATOM if op in (OP_ADD, OP_CAS) else op       # LOAD 0, STORE 1


def mergeable(cfg, cls):
    return cls == CLS_LOAD or (cls == CLS_STORE and cfg.WRITE_COMBINE != 0)


class DLane:
    """A decoded lane of a request as held in the request FIFO / active register."""
    __slots__ = ("v", "st", "pend", "op", "bank", "row", "be", "wd", "cmp")

    def __init__(self, cfg, ln):
        self.v = ln.v
        self.st, self.pend = decode_lane(cfg, ln)
        self.op = ln.op & 3
        self.be = ln.be & 0xF
        self.wd = ln.wd & M32
        self.cmp = ln.cmp & M32
        if self.pend:
            self.bank, self.row = map_word(cfg, ln.addr >> 2)
        else:
            self.bank, self.row = 0, 0


def decode_request(cfg, lanes):
    return [DLane(cfg, ln) for ln in lanes]


class IssueModel:
    """Mirror of sf_smem_issue.  Holds the per-bank rotating lane pointers."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.lptr = [0] * cfg.NB

    def step(self, dec, pend):
        """One issue cycle.  dec: list of DLane, pend: list[bool].
        Returns (groups, served) with groups = list of dict per busy bank."""
        cfg, NL, NB = self.cfg, self.cfg.NL, self.cfg.NB
        cls = [op_class(d.op) for d in dec]
        same = [[(j != k) and pend[j] and pend[k] and dec[j].bank == dec[k].bank
                 and dec[j].row == dec[k].row for k in range(NL)] for j in range(NL)]
        anchor, ready = [False] * NL, [False] * NL
        for k in range(NL):
            lower_same = blocked = False
            for j in range(k):
                if same[j][k]:
                    lower_same = True
                    if not (cls[j] == cls[k] and mergeable(cfg, cls[k])):
                        blocked = True
            anchor[k] = pend[k] and not lower_same
            ready[k] = pend[k] and not blocked

        groups, served = [], [False] * NL
        for b in range(NB):
            cand = [k for k in range(NL) if anchor[k] and dec[k].bank == b]
            if not cand:
                continue
            if cfg.LANE_ARB != 0:
                hi = [k for k in cand if k >= self.lptr[b]]
                a = min(hi) if hi else min(cand)
            else:
                a = min(cand)
            lanes = [k for k in range(NL) if ready[k] and (k == a or same[a][k])]
            op = dec[a].op
            be, wd, cmp_ = dec[a].be, dec[a].wd, dec[a].cmp
            if cls[a] == CLS_STORE:
                be, wd = 0, 0
                for k in lanes:                    # ascending: highest lane overrides
                    for m in range(4):
                        if (dec[k].be >> m) & 1:
                            be |= 1 << m
                            wd = (wd & ~(0xFF << 8 * m)) | (dec[k].wd & (0xFF << 8 * m))
            elif cls[a] == CLS_LOAD:
                be = 0
            groups.append(dict(bank=b, anchor=a, lanes=lanes, op=op, row=dec[a].row,
                               be=be, wd=wd, cmp=cmp_))
            for k in lanes:
                served[k] = True
            self.lptr[b] = 0 if a == NL - 1 else a + 1
        return groups, served


class PhysMem:
    """Physical (bank,row) storage, zero initialised (INIT_ON_RESET)."""

    def __init__(self):
        self.m = {}

    def get(self, bank, row):
        return self.m.get((bank, row), 0)

    def bank_op(self, g):
        """Perform one bank operation (what sf_smem_bank + sf_smem_atomic do).
        Returns the OLD word (the value returned by the bank)."""
        key = (g["bank"], g["row"])
        old = self.m.get(key, 0)
        op = g["op"]
        if op == OP_STORE:
            if g["be"]:
                self.m[key] = merge_bytes(old, g["wd"], g["be"])
        elif op == OP_ADD:
            self.m[key] = (old + g["wd"]) & M32
        elif op == OP_CAS:
            if old == g["cmp"]:
                self.m[key] = g["wd"]
        return old


def execute_request(cfg, issue, phys, lanes):
    """Run a request to completion with the stepwise algorithm.
    Returns (responses, cycles, per_cycle_groups); responses = list of
    (valid, status, data) per lane in the same format as RefMem.exec_request."""
    dec = decode_request(cfg, lanes)
    pend = [d.pend for d in dec]
    data = [0] * cfg.NL
    cycles, trace = 0, []
    while True:
        groups, served = issue.step(dec, pend)
        cycles += 1
        trace.append(groups)
        for g in groups:
            old = phys.bank_op(g)
            for k in g["lanes"]:
                c = op_class(dec[k].op)
                if c == CLS_LOAD:
                    data[k] = old & bytemask(dec[k].be)
                elif c == CLS_ATOM:
                    data[k] = old
                else:
                    data[k] = 0
        pend = [p and not s for p, s in zip(pend, served)]
        if not any(pend):
            break
        if cycles > 4 * cfg.NL + 4:
            raise RuntimeError("issue model failed to make progress")
    resp = []
    for k, d in enumerate(dec):
        if not d.v:
            resp.append((0, 0, 0))
        elif d.st != ST_OK:
            resp.append((1, d.st, 0))
        else:
            resp.append((1, ST_OK, data[k]))
    return resp, cycles, trace


def request_cost(cfg, lanes_or_dec):
    """Closed form for one request.

    A bank with pending lanes always serves exactly one group per cycle (an
    anchor always exists), so it needs  sum over its words of the number of
    maximal mergeable runs in the lane-ordered op sequence of that word.  The
    request needs the maximum over banks, and at least one cycle (a request with
    nothing to do still occupies one issue slot to produce its response).

    Returns dict(d=cycles, groups=[per-bank group count], lanes=#pending lanes,
    atomic=#pending atomic lanes, err=#active lanes with status != OK)."""
    dec = lanes_or_dec
    if dec and not isinstance(dec[0], DLane):
        dec = decode_request(cfg, dec)
    per_word = {}
    for d in dec:
        if d.pend:
            per_word.setdefault((d.bank, d.row), []).append(op_class(d.op))
    groups = [0] * cfg.NB
    for (bank, _row), seq in per_word.items():
        runs, prev = 0, None
        for c in seq:
            if mergeable(cfg, c) and c == prev:
                continue
            runs += 1
            prev = c if mergeable(cfg, c) else None
        groups[bank] += runs
    return dict(
        d=max(1, max(groups) if groups else 1),
        groups=groups,
        lanes=sum(1 for d in dec if d.pend),
        atomic=sum(1 for d in dec if d.pend and op_class(d.op) == CLS_ATOM),
        err=sum(1 for d in dec if d.v and d.st != ST_OK),
    )
