"""Metrics over simulation results (cycle model or RTL log - both give accept /
response cycles per request).  Definitions are fixed here so that every report uses
the same ones.

  latency(p,i)      response-visible cycle - accept cycle              (request latency)
  service(p,i)      last_issue - first_issue + 1 = d                   (issue cycles = conflict degree)
  conflict cycles   sum over requests of (d - 1)   == perf 'conflict_cycles'
  throughput        requests / cycle  and  lanes / cycle  over the busy window
  jain(x)           (sum x)^2 / (n * sum x^2)   1.0 = perfectly even, 1/n = one winner
"""
import math


def jain(xs):
    xs = [float(x) for x in xs]
    n = len(xs)
    s2 = sum(x * x for x in xs)
    if n == 0 or s2 == 0:
        return 1.0
    return (sum(xs) ** 2) / (n * s2)


def percentile(xs, q):
    if not xs:
        return float("nan")
    xs = sorted(xs)
    k = (len(xs) - 1) * q / 100.0
    lo, hi = math.floor(k), math.ceil(k)
    return xs[lo] if lo == hi else xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def latencies(res, port=None):
    """Request latency = cycle the response was first visible - accept cycle.
    (rsp_vis is the cycle rsp_valid first went high, i.e. before any consumer stall.)"""
    out = []
    for key, acc in res.acc.items():
        if port is not None and key[0] != port:
            continue
        v = res.rsp_vis.get(key)
        if v is not None:
            out.append(v - acc)
    return out


def summarize_latency(xs):
    return dict(n=len(xs), mean=sum(xs) / len(xs) if xs else float("nan"), p50=percentile(xs, 50),
                p95=percentile(xs, 95), p99=percentile(xs, 99), max=max(xs) if xs else float("nan"))


def conflict_hist(res):
    """histogram of request issue-cycle counts d"""
    h = {}
    for c in res.cost.values():
        h[c["d"]] = h.get(c["d"], 0) + 1
    return dict(sorted(h.items()))


def window(res):
    """(first grant cycle, last response cycle) of the run"""
    first = min(res.grant.values()) if res.grant else 0
    return first, res.cycles


def throughput(res, cfg):
    first, last = window(res)
    span = max(1, last - first + 1)
    nreq = len(res.rsp)
    lanes = sum(c["lanes"] for c in res.cost.values())
    groups = sum(sum(c["groups"]) for c in res.cost.values())
    return dict(cycles=span, requests=nreq, req_per_cycle=nreq / span, lanes_per_cycle=lanes / span,
                bank_util=groups / (cfg.NB * span))


def port_shares(res, cfg):
    """per-port requests granted and issue cycles consumed"""
    reqs = [0] * cfg.NP
    cyc = [0] * cfg.NP
    for (p, _i), c in res.cost.items():
        reqs[p] += 1
        cyc[p] += c["d"]
    return reqs, cyc


def starvation(res, cfg):
    """per port: first-grant cycle and the longest gap between consecutive grants while
    it had a request waiting (approximated by the longest gap between grants)."""
    out = []
    for p in range(cfg.NP):
        gs = sorted(c for (pp, _i), c in res.grant.items() if pp == p)
        gaps = [b - a for a, b in zip(gs, gs[1:])]
        out.append(dict(port=p, first_grant=gs[0] if gs else None, last_grant=gs[-1] if gs else None,
                        max_gap=max(gaps) if gaps else 0, grants=len(gs)))
    return out


def max_wait_between_grants_when_backlogged(res, cfg):
    """For each port, the maximum number of OTHER-port grants between two consecutive grants
    of that port while it was continuously backlogged.  Round robin bounds this by NP-1."""
    order = res.order
    worst = [0] * cfg.NP
    last_pos = [None] * cfg.NP
    for pos, (p, _i) in enumerate(order):
        if last_pos[p] is not None:
            worst[p] = max(worst[p], pos - last_pos[p] - 1)
        last_pos[p] = pos
    return worst
