"""Workload generators: reductions, histograms, tiled matrix operations and
contention-heavy kernels, expressed as request streams for the SFSM ports.

Every workload returns a Workload(name, per_port, check, notes):
  per_port : list (per port) of list[Req]   - what the RTL / cycle model replay
  check    : function(words) -> list[str]   - INDEPENDENT numeric expectation
             (plain Python arithmetic on the input data, no memory model); `words`
             is the architectural memory image (list of 32-bit words) after the run.
Client-side arithmetic (the adds of a reduction, the multiply-accumulates of a
GEMM, the retry decisions of a CAS loop) is done here with the values the
sequential reference returns - exactly what a real client would do with the
responses; for a single port the responses do not depend on timing, so the
unrolled request stream is exact.
"""
import random
from collections import Counter, namedtuple

from .arch import (Lane, INACTIVE, Req, M32, OP_LOAD, OP_STORE, OP_ADD, OP_CAS)
from .ref import RefMem

Workload = namedtuple("Workload", "name per_port check notes")


class Builder:
    """Accumulates the requests of one logical program and executes them against a
    private reference memory so that the program can use the returned values."""

    def __init__(self, cfg, port=0, seed=0):
        self.cfg = cfg
        self.port = port
        self.ref = RefMem(cfg)
        self.reqs = []
        self.rng = random.Random(seed)
        self._tag = 0

    def issue(self, lanes, gap=0):
        lanes = list(lanes) + [INACTIVE] * (self.cfg.NL - len(lanes))
        assert len(lanes) == self.cfg.NL
        resp = self.ref.exec_request(lanes)
        self.reqs.append(Req(gap, self._tag & ((1 << self.cfg.TAGW) - 1), lanes))
        self._tag += 1
        return [r[2] for r in resp]            # data per lane

    def load(self, addrs, be=0xF, gap=0):
        return self.issue([Lane(1, OP_LOAD, a * 4, be, 0, 0) if a is not None else INACTIVE
                           for a in addrs], gap)

    def store(self, addrs, vals, be=0xF, gap=0):
        return self.issue([Lane(1, OP_STORE, a * 4, be, v & M32, 0) if a is not None else INACTIVE
                           for a, v in zip(addrs, vals)], gap)

    def add(self, addrs, vals, gap=0):
        return self.issue([Lane(1, OP_ADD, a * 4, 0xF, v & M32, 0) if a is not None else INACTIVE
                           for a, v in zip(addrs, vals)], gap)

    def cas(self, addrs, expect, new, gap=0):
        return self.issue([Lane(1, OP_CAS, a * 4, 0xF, n & M32, e & M32) if a is not None else INACTIVE
                           for a, e, n in zip(addrs, expect, new)], gap)

    def per_port(self):
        pp = [[] for _ in range(self.cfg.NP)]
        pp[self.port] = self.reqs
        return pp


def _need(cfg, words, what):
    if words > cfg.cap_words:
        raise ValueError("%s needs %d words, capacity is %d" % (what, words, cfg.cap_words))


def _chunks(n, size):
    for i in range(0, n, size):
        yield i, min(size, n - i)


# ------------------------------------------------------------------------------ reductions
def reduction(cfg, variant="interleaved", n=None, seed=1):
    """Shared-memory tree reduction of n words (CUDA 'reduce' kernels).
    variant: 'interleaved' (stride 2s, divergent, conflicting), 'sequential'
    (stride s halving, conflict free), 'atomic_flat' (every lane atomically adds to
    ONE word - maximum contention), 'atomic_private' (per-lane accumulators, then
    one combine)."""
    NL = cfg.NL
    n = n or (1 << (4 * NL - 1).bit_length())        # power of two >= 4*NL (tree reductions need it)
    assert n & (n - 1) == 0
    rng = random.Random(seed)
    xs = [rng.getrandbits(32) for _ in range(n)]
    want = sum(xs) & M32
    b = Builder(cfg, seed=seed)
    base = 0
    out = n + NL                                      # result word, away from data
    _need(cfg, out + 1, "reduction")
    for i, m in _chunks(n, NL):                       # global -> shared copy
        b.store([base + i + l for l in range(m)], xs[i:i + m])

    if variant == "interleaved":
        s = 1
        while s < n:
            nthreads = n // (2 * s)
            for t0, m in _chunks(nthreads, NL):
                idx = [2 * s * (t0 + l) for l in range(m)]
                a = b.load([base + i for i in idx])
                c = b.load([base + i + s for i in idx])
                b.store([base + i for i in idx], [x + y for x, y in zip(a, c)])
            s *= 2
        res = b.load([base])[0]
        b.store([out], [res])
    elif variant == "sequential":
        s = n // 2
        while s >= 1:
            for t0, m in _chunks(s, NL):
                idx = [t0 + l for l in range(m)]
                a = b.load([base + i for i in idx])
                c = b.load([base + i + s for i in idx])
                b.store([base + i for i in idx], [x + y for x, y in zip(a, c)])
            s //= 2
        res = b.load([base])[0]
        b.store([out], [res])
    elif variant == "atomic_flat":
        for i, m in _chunks(n, NL):
            b.add([out] * m, xs[i:i + m])
    elif variant == "atomic_private":
        acc = n + 2 * NL
        _need(cfg, acc + NL, "reduction")
        for i, m in _chunks(n, NL):
            b.add([acc + l for l in range(m)], xs[i:i + m])
        parts = b.load([acc + l for l in range(NL)])
        b.add([out], [sum(parts)])
    else:
        raise ValueError(variant)

    def check(words):
        bad = []
        if words[out] != want:
            bad.append("%s reduction: result word %08x != sum %08x" % (variant, words[out], want))
        return bad
    return Workload("reduce_" + variant, b.per_port(), check,
                    "n=%d tree/atomic reduction, result at word %d" % (n, out))


# ------------------------------------------------------------------------------ histograms
def histogram(cfg, dist="uniform", nsamples=None, nbins=None, seed=2, privatized=False):
    """Atomic-add histogram.  dist: uniform | skewed | single | lane | sorted."""
    NL = cfg.NL
    nbins = nbins or 4 * NL
    nsamples = nsamples or 64 * NL
    rng = random.Random(seed)
    if dist == "uniform":
        vals = [rng.randrange(nbins) for _ in range(nsamples)]
    elif dist == "skewed":                              # ~75% of samples in two bins
        vals = [rng.choice([3, 4]) if rng.random() < 0.75 else rng.randrange(nbins)
                for _ in range(nsamples)]
    elif dist == "single":                              # worst case: every lane, one bin
        vals = [nbins // 2] * nsamples
    elif dist == "lane":                                # bin = lane: contention free
        vals = [i % NL for i in range(nsamples)]
    elif dist == "sorted":                              # long runs of equal bins
        vals = sorted(rng.randrange(nbins) for _ in range(nsamples))
    else:
        raise ValueError(dist)
    want = Counter(vals)
    b = Builder(cfg, seed=seed)
    if not privatized:
        _need(cfg, nbins, "histogram")
        for i, m in _chunks(nsamples, NL):
            b.add([vals[i + l] for l in range(m)], [1] * m)
        base = 0

        def check(words):
            bad = []
            for k in range(nbins):
                if words[base + k] != want.get(k, 0):
                    bad.append("hist[%d] = %d, expected %d" % (k, words[base + k], want.get(k, 0)))
            return bad
        return Workload("hist_" + dist, b.per_port(), check,
                        "%d samples into %d bins (atomic add)" % (nsamples, nbins))
    # privatized: bin*NL + lane  -> every lane owns a private copy, then merge
    _need(cfg, nbins * NL + nbins, "privatized histogram")
    merged = nbins * NL
    for i, m in _chunks(nsamples, NL):
        b.add([vals[i + l] * NL + l for l in range(m)], [1] * m)
    for k in range(nbins):
        parts = b.load([k * NL + l for l in range(NL)])
        b.store([merged + k], [sum(parts)])

    def check_p(words):
        bad = []
        for k in range(nbins):
            if words[merged + k] != want.get(k, 0):
                bad.append("merged hist[%d] = %d, expected %d" % (k, words[merged + k], want.get(k, 0)))
        return bad
    return Workload("hist_%s_priv" % dist, b.per_port(), check_p,
                    "privatised histogram, %d samples, %d bins" % (nsamples, nbins))


# ------------------------------------------------------------------------------ tiled matrix
def gemm_tiled(cfg, M=None, N=None, K=None, T=None, seed=3):
    """C = A x B with T x T shared-memory tiles (lanes = output columns).
    Shared layout: As[T][T], Bs[T][T] re-loaded per k-tile, C[M][N] results."""
    T = T or cfg.NL
    assert T <= cfg.NL
    M, N, K = M or 2 * T, N or 2 * T, K or 2 * T
    assert M % T == 0 and N % T == 0 and K % T == 0
    rng = random.Random(seed)
    A = [[rng.randrange(1 << 12) for _ in range(K)] for _ in range(M)]
    B = [[rng.randrange(1 << 12) for _ in range(N)] for _ in range(K)]
    As, Bs, Cb = 0, T * T, 2 * T * T
    _need(cfg, Cb + M * N, "gemm")
    b = Builder(cfg, seed=seed)
    for bi in range(0, M, T):
        for bj in range(0, N, T):
            acc = [[0] * T for _ in range(T)]
            for bk in range(0, K, T):
                for r in range(T):                                  # global -> shared
                    b.store([As + r * T + l for l in range(T)], [A[bi + r][bk + l] for l in range(T)])
                    b.store([Bs + r * T + l for l in range(T)], [B[bk + r][bj + l] for l in range(T)])
                for r in range(T):                                  # compute row r of the tile
                    for k in range(T):
                        a = b.load([As + r * T + k] * T)            # broadcast across lanes
                        bb = b.load([Bs + k * T + l for l in range(T)])   # unit stride
                        for l in range(T):
                            acc[r][l] = (acc[r][l] + a[l] * bb[l]) & M32
            for r in range(T):                                      # write the C tile
                b.store([Cb + (bi + r) * N + bj + l for l in range(T)], acc[r])

    want = [[sum(A[i][k] * B[k][j] for k in range(K)) & M32 for j in range(N)] for i in range(M)]

    def check(words):
        bad = []
        for i in range(M):
            for j in range(N):
                if words[Cb + i * N + j] != want[i][j]:
                    bad.append("C[%d][%d] = %08x, expected %08x" % (i, j, words[Cb + i * N + j], want[i][j]))
        return bad[:10]
    return Workload("gemm_tiled", b.per_port(), check,
                    "C[%dx%d] = A[%dx%d] x B[%dx%d], tile %d" % (M, N, M, K, K, N, T))


def transpose_tile(cfg, T=None, pitch=None, ntiles=2, seed=4):
    """In-shared-memory tile transpose.  Rows are written unit-stride, columns are
    read with stride = pitch words (the classic bank-conflict case).  pitch > T is
    the SOFTWARE padding remedy, which changes the architectural layout; a bank
    mapping instead changes nothing the program can see."""
    T = T or cfg.NL
    pitch = pitch or T
    rng = random.Random(seed)
    tile, outb = 0, pitch * T
    _need(cfg, outb + T * T, "transpose")
    b = Builder(cfg, seed=seed)
    expect = []
    for _ in range(ntiles):
        inp = [[rng.getrandbits(32) for _ in range(T)] for _ in range(T)]
        for r in range(T):
            b.store([tile + r * pitch + l for l in range(T)], inp[r])
        for c in range(T):
            col = b.load([tile + l * pitch + c for l in range(T)])           # strided column read
            b.store([outb + c * T + l for l in range(T)], col)
        expect = [[inp[l][c] for l in range(T)] for c in range(T)]           # last tile survives

    def check(words):
        bad = []
        for c in range(T):
            for l in range(T):
                if words[outb + c * T + l] != expect[c][l]:
                    bad.append("out[%d][%d] = %08x, expected %08x" % (c, l, words[outb + c * T + l], expect[c][l]))
        return bad[:10]
    return Workload("transpose_p%d" % pitch, b.per_port(), check, "tile %dx%d, pitch %d" % (T, T, pitch))


# ------------------------------------------------------------------------------ strides
def stride_sweep_request(cfg, stride, op=OP_LOAD, base=0):
    """One request: lane l accesses word base + l*stride."""
    return [Lane(1, op, ((base + l * stride) % cfg.cap_words) * 4, 0xF, l + 1, 0) for l in range(cfg.NL)]


def strided_stream(cfg, stride, nreq=64, seed=5):
    b = Builder(cfg, seed=seed)
    for _ in range(nreq):
        b.issue(stride_sweep_request(cfg, stride))
    return Workload("stride_%d" % stride, b.per_port(), lambda w: [], "unit loads, stride %d words" % stride)


# ------------------------------------------------------------------------------ contention
def hot_add(cfg, nreq=200, seed=6, start=None):
    """Every lane of every request adds to the SAME word; value wraps modulo 2^32."""
    rng = random.Random(seed)
    start = 0xFFFFFF00 if start is None else start
    b = Builder(cfg, seed=seed)
    hot = 5
    b.store([hot], [start])
    total = start
    for _ in range(nreq):
        vals = [rng.choice([1, 1, 7, M32, 0x80000000, rng.getrandbits(32)]) for _ in range(cfg.NL)]
        b.add([hot] * cfg.NL, vals)
        total = (total + sum(vals)) & M32

    def check(words):
        return [] if words[hot] == total else ["hot word %08x != expected %08x" % (words[hot], total)]
    return Workload("hot_add", b.per_port(), check, "%d requests x %d lanes atomic add on one word" % (nreq, cfg.NL))


def bank_hammer(cfg, nreq=100, seed=7):
    """All lanes address different words of ONE bank (linear stride NB): NL-way conflict
    under the linear mapping."""
    b = Builder(cfg, seed=seed)
    for _ in range(nreq):
        base = b.rng.randrange(cfg.NB)
        b.load([(base + cfg.NB * l) % cfg.cap_words for l in range(cfg.NL)])
    return Workload("bank_hammer", b.per_port(), lambda w: [], "stride-NB loads")


def cas_increment(cfg, per_lane=3, seed=8):
    """CAS retry loop, one counter, every lane increments it per_lane times.
    Round: LOAD counter (broadcast), then CAS(expected=loaded, desired=loaded+1) on
    every lane still working.  Lane order lets exactly the lowest active lane win a
    round; the others fail and retry."""
    NL = cfg.NL
    b = Builder(cfg, seed=seed)
    ctr = 9
    left = [per_lane] * NL
    rounds = 0
    while any(left):
        act = [l for l in range(NL) if left[l]]
        v = b.load([ctr] * NL)[0]
        old = b.cas([ctr if l in act else None for l in range(NL)], [v] * NL, [v + 1] * NL)
        for l in act:
            if old[l] == v:
                left[l] -= 1
        rounds += 1
        assert rounds < 10 * NL * per_lane
    want = NL * per_lane

    def check(words):
        return [] if words[ctr] == want else ["counter %d != %d" % (words[ctr], want)]
    return Workload("cas_increment", b.per_port(), check,
                    "%d lanes x %d increments by CAS loop, %d rounds" % (NL, per_lane, rounds))


def cas_max(cfg, nvals=None, seed=9):
    """Atomic max emulated by a CAS loop.  Each lane owns a value; it loops
    LOAD -> (val > cur ? CAS(cur -> val) : done) until it is done."""
    NL = cfg.NL
    nvals = nvals or 4 * NL
    rng = random.Random(seed)
    vals = [rng.getrandbits(32) for _ in range(nvals)]
    b = Builder(cfg, seed=seed)
    mx = 11
    for i, m in _chunks(nvals, NL):
        mine = vals[i:i + m] + [0] * (NL - m)
        working = [l < m for l in range(NL)]
        while any(working):
            cur = b.load([mx] * NL)[0]
            want_l = [working[l] and mine[l] > cur for l in range(NL)]
            for l in range(NL):
                if working[l] and not want_l[l]:
                    working[l] = False          # nothing to do for this lane
            if not any(want_l):
                continue
            old = b.cas([mx if want_l[l] else None for l in range(NL)], [cur] * NL, mine)
            for l in range(NL):
                if want_l[l] and old[l] == cur:
                    working[l] = False          # won the CAS
    want = max(vals)

    def check(words):
        return [] if words[mx] == want else ["max word %08x != %08x" % (words[mx], want)]
    return Workload("cas_max", b.per_port(), check, "%d values, CAS-loop atomic max" % nvals)


def multiport_hammer(cfg, nreq=150, nwords=6, seed=10, rsp_pat=None):
    """Every port issues random-lane-mask atomic adds on the same few words.  Adds
    commute, so the final sums are independent of the arbitration order."""
    rng = random.Random(seed)
    words = [3 + 2 * i for i in range(nwords)]
    totals = {w: 0 for w in words}
    per_port = []
    for p in range(cfg.NP):
        reqs = []
        for i in range(nreq):
            lanes = []
            for l in range(cfg.NL):
                if rng.random() < 0.8:
                    w, v = rng.choice(words), rng.getrandbits(32)
                    totals[w] = (totals[w] + v) & M32
                    lanes.append(Lane(1, OP_ADD, w * 4, 0xF, v, 0))
                else:
                    lanes.append(INACTIVE)
            reqs.append(Req(rng.choice([0, 0, 0, 1]), (p << 4 | i) & ((1 << cfg.TAGW) - 1), lanes))
        per_port.append(reqs)

    def check(w_):
        return ["word %d: %08x != %08x" % (w, w_[w], t) for w, t in totals.items() if w_[w] != t]
    return Workload("multiport_hammer", per_port, check, "%d ports x %d requests on %d words" % (cfg.NP, nreq, nwords))


def fuzz(cfg, nreq=120, seed=11, **kw):
    from .randgen import rand_trace
    rng = random.Random(seed)
    return Workload("fuzz_s%d" % seed, rand_trace(rng, cfg, nreq, **kw), lambda w: [],
                    "random mix incl. errors, inactive lanes, partial byte enables")


def standard_set(cfg):
    """The workload list run by the regression on one configuration."""
    ws = [
        reduction(cfg, "interleaved"), reduction(cfg, "sequential"),
        reduction(cfg, "atomic_flat"), reduction(cfg, "atomic_private"),
        histogram(cfg, "uniform"), histogram(cfg, "skewed"), histogram(cfg, "single"),
        histogram(cfg, "lane"), histogram(cfg, "sorted"), histogram(cfg, "uniform", privatized=True),
        gemm_tiled(cfg), transpose_tile(cfg), transpose_tile(cfg, pitch=cfg.NL + 1),
        hot_add(cfg), bank_hammer(cfg), cas_increment(cfg), cas_max(cfg),
        strided_stream(cfg, 1), strided_stream(cfg, cfg.NB), strided_stream(cfg, 2),
        multiport_hammer(cfg), fuzz(cfg, seed=11), fuzz(cfg, seed=12, p_hot=0.95),
    ]
    return ws
