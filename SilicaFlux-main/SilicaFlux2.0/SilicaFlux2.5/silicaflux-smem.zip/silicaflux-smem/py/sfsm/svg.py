"""Tiny dependency-free SVG charts (line, grouped bar, heatmap).  Colours are a
colour-blind-safe categorical set; every chart carries a title, axis labels and a
legend, and works on a light or dark page (explicit background rectangle)."""
from xml.sax.saxutils import escape

PALETTE = ["#1f77b4", "#d95f02", "#1b9e77", "#7570b3", "#e7298a", "#66a61e", "#a6761d", "#666666"]
BG, FG, GRID = "#ffffff", "#222222", "#dddddd"


def _frame(w, h, title):
    return ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" '
            'font-family="Helvetica,Arial,sans-serif" font-size="12">' % (w, h, w, h),
            '<rect width="%d" height="%d" fill="%s"/>' % (w, h, BG),
            '<text x="%d" y="22" font-size="15" font-weight="bold" fill="%s">%s</text>' % (14, FG, escape(title))]


def _legend(names, x, y, parts):
    for i, n in enumerate(names):
        parts.append('<rect x="%d" y="%d" width="12" height="12" fill="%s"/>' % (x, y + i * 18, PALETTE[i % len(PALETTE)]))
        parts.append('<text x="%d" y="%d" fill="%s">%s</text>' % (x + 18, y + 11 + i * 18, FG, escape(str(n))))


def _nice_max(v):
    if v <= 0:
        return 1.0
    import math
    e = 10 ** math.floor(math.log10(v))
    for m in (1, 2, 2.5, 5, 10):
        if v <= m * e:
            return m * e
    return 10 * e


def line_chart(path, title, xs, series, xlabel, ylabel, logy=False, w=760, h=420):
    """series: dict name -> list of y (same length as xs)."""
    import math
    L, R, T, B = 64, 190, 40, 56
    pw, ph = w - L - R, h - T - B
    ys = [y for s in series.values() for y in s if y is not None]
    ymax = _nice_max(max(ys))
    ymin = 0.0
    if logy:
        ymin = 10 ** math.floor(math.log10(max(min(ys), 1e-9)))
    parts = _frame(w, h, title)

    def X(i):
        return L + (pw * i / max(1, len(xs) - 1))

    def Y(v):
        if logy:
            return T + ph - ph * (math.log10(max(v, ymin)) - math.log10(ymin)) / (math.log10(ymax) - math.log10(ymin))
        return T + ph - ph * (v - ymin) / (ymax - ymin)
    ticks = 5
    for k in range(ticks + 1):
        if logy:
            v = 10 ** (math.log10(ymin) + (math.log10(ymax) - math.log10(ymin)) * k / ticks)
        else:
            v = ymin + (ymax - ymin) * k / ticks
        y = Y(v)
        parts.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="%s"/>' % (L, y, L + pw, y, GRID))
        parts.append('<text x="%d" y="%.1f" text-anchor="end" fill="%s">%s</text>' % (L - 6, y + 4, FG, ("%.3g" % v)))
    step = max(1, len(xs) // 12)
    for i, xv in enumerate(xs):
        if i % step == 0 or i == len(xs) - 1:
            parts.append('<text x="%.1f" y="%d" text-anchor="middle" fill="%s">%s</text>' % (X(i), T + ph + 18, FG, escape(str(xv))))
    parts.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s"/>' % (L, T + ph, L + pw, T + ph, FG))
    parts.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s"/>' % (L, T, L, T + ph, FG))
    parts.append('<text x="%d" y="%d" text-anchor="middle" fill="%s">%s</text>' % (L + pw / 2, h - 12, FG, escape(xlabel)))
    parts.append('<text transform="translate(16,%d) rotate(-90)" text-anchor="middle" fill="%s">%s</text>' % (T + ph / 2, FG, escape(ylabel)))
    for si, (name, s) in enumerate(series.items()):
        pts = " ".join("%.1f,%.1f" % (X(i), Y(v)) for i, v in enumerate(s) if v is not None)
        c = PALETTE[si % len(PALETTE)]
        parts.append('<polyline points="%s" fill="none" stroke="%s" stroke-width="2"/>' % (pts, c))
        for i, v in enumerate(s):
            if v is not None:
                parts.append('<circle cx="%.1f" cy="%.1f" r="2.6" fill="%s"/>' % (X(i), Y(v), c))
    _legend(list(series), L + pw + 16, T + 6, parts)
    parts.append("</svg>")
    open(path, "w").write("\n".join(parts))


def bar_chart(path, title, cats, series, ylabel, w=900, h=440, logy=False):
    """grouped bars: series dict name -> list over cats."""
    import math
    L, R, T, B = 64, 170, 40, 92
    pw, ph = w - L - R, h - T - B
    vals = [v for s in series.values() for v in s]
    ymax = _nice_max(max(vals))
    ymin = 0.0
    if logy:
        ymin = 10 ** math.floor(math.log10(max(min(v for v in vals if v > 0), 1e-9)))
    parts = _frame(w, h, title)

    def Y(v):
        if logy:
            return T + ph - ph * (math.log10(max(v, ymin)) - math.log10(ymin)) / (math.log10(ymax) - math.log10(ymin))
        return T + ph - ph * v / ymax
    if logy:
        tick_vals = [t for t in (0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000) if ymin <= t <= ymax]
    else:
        tick_vals = [ymax * k / 5 for k in range(6)]
    for v in tick_vals:
        y = Y(v)
        parts.append('<line x1="%d" y1="%.1f" x2="%d" y2="%.1f" stroke="%s"/>' % (L, y, L + pw, y, GRID))
        parts.append('<text x="%d" y="%.1f" text-anchor="end" fill="%s">%s</text>' % (L - 6, y + 4, FG, "%.3g" % v))
    n, m = len(cats), len(series)
    gw = pw / n
    bw = gw * 0.8 / m
    for ci, cat in enumerate(cats):
        gx = L + ci * gw + gw * 0.1
        for si, (name, s) in enumerate(series.items()):
            v = s[ci]
            y = Y(v)
            parts.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s"><title>%s / %s: %.4g</title></rect>' % (
                gx + si * bw, y, bw, T + ph - y, PALETTE[si % len(PALETTE)], escape(str(cat)), escape(str(name)), v))
        parts.append('<text transform="translate(%.1f,%d) rotate(-35)" text-anchor="end" fill="%s">%s</text>' % (
            gx + gw * 0.4, T + ph + 14, FG, escape(str(cat))))
    parts.append('<line x1="%d" y1="%d" x2="%d" y2="%d" stroke="%s"/>' % (L, T + ph, L + pw, T + ph, FG))
    parts.append('<text transform="translate(16,%d) rotate(-90)" text-anchor="middle" fill="%s">%s</text>' % (T + ph / 2, FG, escape(ylabel)))
    _legend(list(series), L + pw + 14, T + 6, parts)
    parts.append("</svg>")
    open(path, "w").write("\n".join(parts))


def heatmap(path, title, rows, cols, grid, xlabel, ylabel, w=820, h=None, fmt="%d"):
    """grid[r][c] numeric; sequential single-hue colour scale, value printed in each cell."""
    cw, ch = max(26, min(46, (w - 150) // max(1, len(cols)))), 24
    L, T = 130, 70
    h = h or (T + ch * len(rows) + 30)
    w = L + cw * len(cols) + 30
    flat = [v for r in grid for v in r]
    lo, hi = min(flat), max(flat)
    parts = _frame(w, h, title)

    def colour(v):
        t = 0.0 if hi == lo else (v - lo) / (hi - lo)
        r = int(255 - t * (255 - 8))
        g = int(255 - t * (255 - 81))
        b = int(255 - t * (255 - 156))
        return "#%02x%02x%02x" % (r, g, b), (FG if t < 0.55 else "#ffffff")
    for ci, c in enumerate(cols):
        parts.append('<text x="%d" y="%d" text-anchor="middle" fill="%s">%s</text>' % (L + ci * cw + cw // 2, T - 8, FG, escape(str(c))))
    for ri, r in enumerate(rows):
        parts.append('<text x="%d" y="%d" text-anchor="end" fill="%s">%s</text>' % (L - 8, T + ri * ch + 16, FG, escape(str(r))))
        for ci, v in enumerate(grid[ri]):
            fillc, txt = colour(v)
            parts.append('<rect x="%d" y="%d" width="%d" height="%d" fill="%s" stroke="#ffffff"/>' % (L + ci * cw, T + ri * ch, cw, ch, fillc))
            parts.append('<text x="%d" y="%d" text-anchor="middle" font-size="10" fill="%s">%s</text>' % (L + ci * cw + cw // 2, T + ri * ch + 16, txt, fmt % v))
    parts.append('<text x="%d" y="%d" text-anchor="middle" fill="%s">%s</text>' % (L + cw * len(cols) // 2, 44, FG, escape(xlabel)))
    parts.append('<text x="12" y="%d" fill="%s">%s</text>' % (T + ch * len(rows) + 22, FG, escape(ylabel)))
    parts.append("</svg>")
    open(path, "w").write("\n".join(parts))
