# AlbionCore -- foundational cloud-semiconductor architecture

**SilicaFlux Albion** common hardware foundation: a reusable, synthesizable, verifiable SystemVerilog library -- one shared
transaction protocol, common buffering, tag tracking, width conversion, error handling, clock/reset contract, memory map and a
complete open-source build/verification flow -- on which a cloud DPU, HPC accelerator, storage controller and edge-compute SoC can be built.

* **Protocol (ALP v1):** 64-bit address, 128-bit data, 16-bit byte mask, 8-bit tag, 8-bit domain; independent valid/ready request and
  response channels; READ and WRITE only; in-order completion; bounded outstanding requests; explicit reset and cancellation rules.
  **No atomics** (reserved and rejected until an atomicity specification is written and verified).
* **Library:** `sf_albion_pkg`, `sf_albion_fifo`, `sf_albion_skid`, `sf_albion_regslice`, `sf_albion_width_adapter`,
  `sf_albion_tag_tracker`, `sf_albion_err_resp`; optional CDC modules (`cdc_bit_sync`, `reset_sync`, `cdc_pulse`, `async_fifo`);
  a reference target subsystem; three hardware profiles (`albion_min`, `albion_cloud`, `albion_hpc`).
* **Evidence, not assertions of quality:** self-checking randomised testbenches with independent reference models and a protocol
  checker, **unbounded formal proofs** of the buffering stages, tracker and error responder, a mutation campaign that injects real bugs,
  line and functional coverage with enforced goals, and a traceability matrix from every contract rule to the check that enforces it.

## Quick start

```bash
sudo apt-get install -y make build-essential python3 python3-yaml verilator yosys rustc    # rustc optional
make doctor      # tool versions
make ci          # check + lint + sim + formal + synth + report   (reports in build/reports/)
```

Everything needs only open-source tools (tested: Verilator 5.020, Yosys 0.33, Python 3.13).  See
[docs/albion/BUILD.md](docs/albion/BUILD.md).  The reports of the delivered version (produced by a clean-checkout `make ci` and
`make mutate`) are in `reports/albion/`: 20.5 M simulation checks, 55 functional-coverage goals met, 99.5 % RTL line coverage, 18 formal
jobs proved, 67 of 67 injected bugs detected.

## Documentation (`docs/albion/`)

| Document | Content |
|---|---|
| [ARCHITECTURE_CONTRACT.md](docs/albion/ARCHITECTURE_CONTRACT.md) | the protocol and every rule (acceptance, completion, backpressure, ordering, outstanding limits, tags, reset, cancellation, legality) |
| [INTERFACE_SPEC.md](docs/albion/INTERFACE_SPEC.md) | every module: contract, parameters, ports (generated from the RTL) |
| [MEMORY_MAP.md](docs/albion/MEMORY_MAP.md) | region catalogue, rules, profiles, C / Rust / SV usage |
| [RESET_CLOCK_CONTRACT.md](docs/albion/RESET_CLOCK_CONTRACT.md) | reset conventions, CDC primitives, what is and is not verified |
| [ERROR_CODES.md](docs/albion/ERROR_CODES.md) | status codes, precedence, who produces what |
| [NAMING_RULES.md](docs/albion/NAMING_RULES.md) | coding style, naming, Yosys/Verilator compatibility rules (mechanically checked) |
| [REPO_STRUCTURE.md](docs/albion/REPO_STRUCTURE.md), [BUILD.md](docs/albion/BUILD.md), [DEPENDENCIES.md](docs/albion/DEPENDENCIES.md) | layout, build, dependency manifest |
| [REPO_AUDIT.md](docs/albion/REPO_AUDIT.md) | audit of the existing SilicaFlux IP: compatibility, missing dependencies, naming conflicts |
| [VERIFICATION.md](docs/albion/VERIFICATION.md) | verification strategy, results of the delivered version, limitations |
| [generated/TRACEABILITY.md](docs/albion/generated/TRACEABILITY.md) | rule -> evidence matrix |

## Status and scope

Version **0.1.0** (protocol 1.0).  Verified by simulation, formal proof and generic synthesis only.  **No FPGA, place-and-route, timing,
power or silicon result exists and none is claimed**; synthesis figures are technology-independent gate counts used as regression
budgets.  The foundation does not include a protection unit, atomics, bursts, coherence or bridges to the older SFB2 / `sram_if` /
NoC protocols (listed as missing dependencies in the audit).  No licence file is included; add one before publishing.
