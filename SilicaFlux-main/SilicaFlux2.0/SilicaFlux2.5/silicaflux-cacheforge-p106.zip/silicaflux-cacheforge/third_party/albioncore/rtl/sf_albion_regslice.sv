// =============================================================================
//  sf_albion_regslice.sv  --  configurable valid/ready register slice
// -----------------------------------------------------------------------------
//  Inserts pipeline registers into a valid/ready channel for timing closure.
//  MODE chooses which paths are registered:
//
//    MODE  name    registered paths                  storage      comb. paths left
//    ----  ------  --------------------------------  -----------  -------------------------
//     0    BYPASS  none (wires)                      none         all
//     1    FWD     valid + data  (forward)           1 entry      ready: out_ready -> in_ready
//     2    BWD     ready         (backward)          1 spill      valid/data: in -> out
//     3    FULL    valid, data and ready             2 entries    none (this is a skid buffer)
//
//  All modes are loss-free, order-preserving and allow one transfer per cycle
//  in steady state.  Output valid and data are stable while
//  out_valid_o && !out_ready_i in every mode.
//
//  In no mode is there a combinational path from any valid or data input to
//  an in_ready_o output, so chains of slices can never form a combinational
//  loop between valid and ready.
//
//  Parameters
//    WIDTH  payload width in bits (>= 1)
//    MODE   0..3 as above
// =============================================================================
`default_nettype none

module sf_albion_regslice #(
  parameter int unsigned WIDTH = 8,
  parameter int unsigned MODE  = 3
) (
  input  wire logic             clk_i,
  input  wire logic             rst_ni,
  input  wire logic             in_valid_i,
  output logic                  in_ready_o,
  input  wire logic [WIDTH-1:0] in_data_i,
  output logic                  out_valid_o,
  input  wire logic             out_ready_i,
  output logic [WIDTH-1:0]      out_data_o
);
  if (WIDTH < 1)  begin : gen_param_check_width
    $error("sf_albion_regslice: WIDTH must be >= 1");
  end
  if (MODE > 3) begin : gen_param_check_mode
    $error("sf_albion_regslice: MODE must be 0 (bypass), 1 (fwd), 2 (bwd) or 3 (full)");
  end

  if (MODE == 0) begin : gen_bypass
    assign out_valid_o = in_valid_i;
    assign out_data_o  = in_data_i;
    assign in_ready_o  = out_ready_i;
    // The bypass slice is combinational: clock and reset are intentionally unused.
    logic unused_clk_rst;
    assign unused_clk_rst = &{1'b0, clk_i, rst_ni};

  end else if (MODE == 1) begin : gen_fwd
    // One register on valid + data.  The register is free when it is empty
    // or when it is being drained in this cycle.
    logic             valid_q;
    logic [WIDTH-1:0] data_q;

    assign out_valid_o = valid_q;
    assign out_data_o  = data_q;
    assign in_ready_o  = !valid_q || out_ready_i;

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni)                         valid_q <= 1'b0;
      else if (in_ready_o)                 valid_q <= in_valid_i;
    end
    always_ff @(posedge clk_i) begin
      if (in_ready_o && in_valid_i) data_q <= in_data_i;
    end

  end else if (MODE == 2) begin : gen_bwd
    // Combinational valid/data pass-through plus a one-entry spill register
    // that catches the item the upstream was told it could send.
    logic             spill_valid_q;
    logic [WIDTH-1:0] spill_data_q;

    assign in_ready_o  = !spill_valid_q;
    assign out_valid_o = spill_valid_q || in_valid_i;
    assign out_data_o  = spill_valid_q ? spill_data_q : in_data_i;

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni)                                  spill_valid_q <= 1'b0;
      else if (spill_valid_q && out_ready_i)        spill_valid_q <= 1'b0;
      else if (!spill_valid_q && in_valid_i && !out_ready_i) spill_valid_q <= 1'b1;
    end
    always_ff @(posedge clk_i) begin
      if (!spill_valid_q && in_valid_i && !out_ready_i) spill_data_q <= in_data_i;
    end

  end else begin : gen_full
    sf_albion_skid #(.WIDTH(WIDTH)) u_skid (
      .clk_i, .rst_ni,
      .in_valid_i, .in_ready_o, .in_data_i,
      .out_valid_o, .out_ready_i, .out_data_o
    );
  end
endmodule

`default_nettype wire
