#!/usr/bin/env python3
"""Run the formal tasks and write reports/final/formal.log (one line per task).

usage: run_formal.py [--quick] [--out reports/final/formal.log]     (needs sby + z3 on PATH; see scripts/make_shims.sh)
Classification: 'PROVED (unbounded, k-induction)', 'BOUNDED PASS to depth N (k-induction did not close)', 'COVER: n/m points reached', 'FAIL'.
"""
import os, re, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
F = os.path.join(ROOT, "formal")
JOBS = [("fv_cache_addr.sby", t, 600) for t in ("dflt", "small", "l16", "l256", "p48")] + \
       [("fv_replacement.sby", t, 600) for t in ("plru2", "plru4", "plru8", "plru16", "rr2", "rr4", "rr8", "way1")] + \
       [("fv_mshr.sby", t, 1800) for t in ("n1", "n2", "n3", "n4")]
SLOW = [("fv_memport.sby", t, 1500) for t in ("out1", "out2")] + [("fv_llc.sby", t, 3600) for t in ("cover1", "bmc1", "bmc2")]

def depth_of(sby, task):
    d = None
    for l in open(os.path.join(F, sby)):
        m = re.match(r"^(?:(\w+):\s*)?depth\s+(\d+)", l.strip())
        if m and (m.group(1) in (None, task)):
            d = int(m.group(2))
    return d

def run(sby, task, to):
    t0 = time.time()
    try:
        r = subprocess.run(["sby", "-f", sby, task], cwd=F, capture_output=True, text=True, timeout=to)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        return f"TIMEOUT after {to} s (no result)", time.time() - t0
    dt = time.time() - t0
    if "successful proof by k-induction" in out:
        v = "PROVED (unbounded, k-induction)"
    elif "returned pass for basecase" in out and "FAIL for induction" in out:
        v = f"BOUNDED PASS to depth {depth_of(sby, task)} (k-induction did not close)"
    elif "DONE (PASS" in out and "cover" in out.lower() and "reached cover statement" in out:
        n = len(set(re.findall(r"summary:\s+reached cover statement (\S+)", out)))
        v = f"COVER: {n} cover points reached (assumptions not vacuous)"
    elif "DONE (PASS" in out:
        v = f"BOUNDED PASS to depth {depth_of(sby, task)}"
    elif "DONE (FAIL" in out or "returned FAIL" in out:
        v = "FAIL"
    else:
        v = "NO RESULT: " + out.strip().splitlines()[-1][:100]
    return v, dt

def main(argv):
    jobs = JOBS + ([] if "--quick" in argv else SLOW)
    if "--only" in argv:                                   # --only file.sby:task,file.sby:task  (to run batches in parallel)
        want = set(argv[argv.index("--only") + 1].split(","))
        jobs = [j for j in JOBS + SLOW if f"{j[0]}:{j[1]}" in want]
    out = argv[argv.index("--out") + 1] if "--out" in argv else os.path.join(ROOT, "reports/final/formal.log")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    lines = []
    for sby, task, to in jobs:
        v, dt = run(sby, task, to)
        line = f"{sby[:-4]:16s} {task:8s} {v}   [{dt:.0f} s]"
        print(line, flush=True); lines.append(line)
    open(out, "w").write("\n".join(lines) + "\n")
    return 1 if any(" FAIL" in l or "NO RESULT" in l for l in lines) else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
