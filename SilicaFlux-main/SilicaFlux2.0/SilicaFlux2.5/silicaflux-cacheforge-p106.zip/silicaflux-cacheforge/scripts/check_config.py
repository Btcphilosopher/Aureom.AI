#!/usr/bin/env python3
"""Validate sf_llc_cache parameter sets (JSON files in configs/ or --set NAME=VALUE ...).

The rules are exactly the elaboration-time $error checks of rtl/cache/sf_llc_cache.sv and sf_cache_addr.sv;
scripts/test_config_rejection.py proves they agree with Verilator's elaboration on legal and illegal sets.
usage: check_config.py configs/*.json        |  check_config.py --set WAYS=3 CACHE_BYTES=32768
exit status 0 = every set legal, 1 = at least one rejected (reasons printed)
"""
import json, math, sys

DEFAULTS = dict(CACHE_BYTES=32768, LINE_BYTES=64, WAYS=4, PADDR_W=64, NUM_MSHR=1, REPL_POLICY=1, RAM_LATENCY=1,
                MEM_MAX_OUT=4, ECC_EN=1, ECC_SCRUB=1, MEMORY_TECH=0, CNT_W=64)

def pow2(v):
    return v > 0 and (v & (v - 1)) == 0

def check(p):
    q = dict(DEFAULTS); q.update(p)
    why = []
    if not pow2(q["LINE_BYTES"]) or not 16 <= q["LINE_BYTES"] <= 256: why.append("LINE_BYTES must be a power of two in 16..256")
    if not pow2(q["WAYS"]) or q["WAYS"] > 16: why.append("WAYS must be a power of two in 1..16")
    if not pow2(q["CACHE_BYTES"]): why.append("CACHE_BYTES must be a power of two")
    if q["CACHE_BYTES"] < 2 * q["LINE_BYTES"] * q["WAYS"]: why.append("fewer than 2 sets: CACHE_BYTES >= 2*LINE_BYTES*WAYS")
    if not 32 <= q["PADDR_W"] <= 64: why.append("PADDR_W must be 32..64")
    if not why:
        off = int(math.log2(q["LINE_BYTES"])); sets = q["CACHE_BYTES"] // (q["LINE_BYTES"] * q["WAYS"]); idx = int(math.log2(sets))
        if q["PADDR_W"] <= off + idx: why.append("PADDR_W too small: the tag would be empty")
    if not 1 <= q["NUM_MSHR"] <= 8: why.append("NUM_MSHR must be 1..8")
    if q["REPL_POLICY"] not in (0, 1): why.append("REPL_POLICY must be 0 (round-robin) or 1 (tree PLRU)")
    if not 1 <= q["RAM_LATENCY"] <= 4: why.append("RAM_LATENCY must be 1..4")
    if not 1 <= q["MEM_MAX_OUT"] <= 16: why.append("MEM_MAX_OUT must be 1..16")
    if not 32 <= q["CNT_W"] <= 64: why.append("CNT_W must be 32..64")
    return why

def derived(p):
    q = dict(DEFAULTS); q.update(p)
    sets = q["CACHE_BYTES"] // (q["LINE_BYTES"] * q["WAYS"]); off = int(math.log2(q["LINE_BYTES"])); idx = int(math.log2(sets))
    return dict(SETS=sets, BEATS=q["LINE_BYTES"] // 16, OFF_W=off, IDX_W=idx, TAG_W=q["PADDR_W"] - off - idx)

def main(argv):
    bad = 0
    if argv and argv[0] == "--set":
        p = {}
        for kv in argv[1:]:
            k, v = kv.split("="); p[k] = int(v)
        sets = [("command line", p)]
    else:
        sets = []
        for f in argv:
            j = json.load(open(f)); sets.append((j.get("name", f), j["params"]))
    for name, p in sets:
        why = check(p)
        if why:
            bad += 1; print(f"REJECT {name}: " + "; ".join(why))
        else:
            print(f"ok     {name}: " + ", ".join(f"{k}={v}" for k, v in derived(p).items()))
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
