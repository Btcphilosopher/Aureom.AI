#!/usr/bin/env bash
# Build the regression bench for one configuration.  usage: build_tb.sh <builddir> [-G... overrides] 
# Needs verilator on PATH (or VERILATOR_ROOT).  Run from the package root.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
OUT="$1"; shift
VL="${VERILATOR:-verilator}"
grep -v '^//' rtl/files.f > "$OUT.files.f" 2>/dev/null || { mkdir -p "$(dirname "$OUT")"; grep -v '^//' rtl/files.f > "$OUT.files.f"; }
"$VL" --binary --timing --assert -Wno-fatal -Werror-USERERROR -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-WIDTH -CFLAGS -std=c++20 -j "${VJOBS:-8}" -MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include -Wno-INITIALDLY \
  --top-module "${TOP:-tb_sf_llc_cache}" -Mdir "$OUT" -o sim "$@" \
  -f rtl/incdirs.f -f "$OUT.files.f" \
  third_party/albioncore/tests/sf_albion_chan_checker.sv third_party/albioncore/tests/sf_albion_link_checker.sv \
  tb/sf_tb_alp_mem.sv ${TBFILES:-tb/tb_sf_llc_cache.sv} > "$OUT.build.log" 2>&1 || { tail -40 "$OUT.build.log"; exit 1; }
