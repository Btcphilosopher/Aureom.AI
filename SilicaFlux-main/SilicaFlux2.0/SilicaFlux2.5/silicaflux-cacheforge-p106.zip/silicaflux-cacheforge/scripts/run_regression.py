#!/usr/bin/env python3
"""Model-vs-RTL regression: build each configuration once, run every scenario x seed.

usage: run_regression.py [--configs A,B,...] [--scenarios s1,s2] [--seeds N] [--count K]
                         [--jobs J] [--out reports/regression] [--list]

For every (config, scenario, seed) the independent Python model (model/gen_stimulus.py)
writes the stimulus and every expectation; the Verilator-built bench executes it against
the RTL and compares responses, memory trace, counters, CMO results and the final memory
image.  Exit status is non-zero if anything fails.  Needs `verilator` (or $VERILATOR).
"""
import argparse, concurrent.futures as cf, json, os, re, subprocess, sys, time, shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# name: (cache_bytes, line, ways, paddr, repl, ram_lat, mem_max_out, ecc, mem_lat_max, extra -G flags)
CONFIGS = {
    # the initial configuration of the brief: 32 KiB, 64 B lines, 4 ways, 64-bit addresses, 128-bit fabric
    "A_default":  dict(cache=32768, line=64, ways=4,  paddr=64, repl=1, ramlat=1, memout=4, ecc=1),
    # small / odd geometries (these are the ones that expose corner cases)
    "B_rr_small": dict(cache=512,   line=64, ways=2,  paddr=32, repl=0, ramlat=2, memout=1, ecc=1),
    "C_l32":      dict(cache=1024,  line=32, ways=4,  paddr=48, repl=1, ramlat=3, memout=2, ecc=1),
    "D_direct":   dict(cache=32,    line=16, ways=1,  paddr=40, repl=1, ramlat=1, memout=1, ecc=0),
    "E_8way":     dict(cache=2048,  line=64, ways=8,  paddr=64, repl=1, ramlat=1, memout=4, ecc=1),
    "F_16way_rr": dict(cache=1024,  line=32, ways=16, paddr=64, repl=0, ramlat=1, memout=2, ecc=1),
    "G_l256":     dict(cache=4096,  line=256, ways=2, paddr=36, repl=1, ramlat=1, memout=16, ecc=1),
    "H_noecc":    dict(cache=4096,  line=64, ways=4,  paddr=64, repl=1, ramlat=2, memout=4, ecc=0),
    # ---- MSHR extension (NUM_MSHR > 1): multiple outstanding misses, responses still in order
    "I_mshr2":     dict(cache=4096,  line=64, ways=4,  paddr=48, repl=1, ramlat=1, memout=4,  ecc=1, mshr=2),
    "J_mshr4_rr":  dict(cache=2048,  line=32, ways=4,  paddr=64, repl=0, ramlat=2, memout=8,  ecc=1, mshr=4),
    "K_mshr8":     dict(cache=32768, line=64, ways=4,  paddr=64, repl=1, ramlat=1, memout=16, ecc=1, mshr=8),
    "L_mshr2_dm":  dict(cache=256,   line=32, ways=1,  paddr=40, repl=1, ramlat=1, memout=2,  ecc=1, mshr=2),
    "N_mshr3":     dict(cache=1024,  line=16, ways=2,  paddr=36, repl=1, ramlat=1, memout=3,  ecc=0, mshr=3),
    "O_mshr4_ram3": dict(cache=512,  line=64, ways=2,  paddr=32, repl=1, ramlat=3, memout=1,  ecc=1, mshr=4),
}
BLOCKING = ["A_default", "B_rr_small", "C_l32", "D_direct", "E_8way", "F_16way_rr", "G_l256", "H_noecc"]
SCENARIOS = ["cold", "assoc", "replace", "partial", "raw", "sameline", "illegal", "bypass", "dma", "cmo", "merr", "random"]
# bench stress profiles (idle%, rsp_ready%, mreq_ready%, mrsp_valid%, lat_min, lat_max)
STRESS = [dict(idle=0, rsp=100, mrq=100, mrs=100, lmin=1, lmax=1),     # best case: no back-pressure
          dict(idle=20, rsp=70, mrq=70, mrs=80, lmin=1, lmax=6),       # moderate
          dict(idle=50, rsp=30, mrq=30, mrs=40, lmin=1, lmax=12)]      # heavy


def sets_of(c):
    return c["cache"] // (c["line"] * c["ways"])


def build(name, c, bdir, env):
    out = os.path.join(bdir, name)
    sim = os.path.join(out, "sim")
    if os.path.exists(sim):
        return sim
    os.makedirs(bdir, exist_ok=True)
    g = [f"-GCACHE_BYTES={c['cache']}", f"-GLINE_BYTES={c['line']}", f"-GWAYS={c['ways']}", f"-GPADDR_W={c['paddr']}",
         f"-GREPL={c['repl']}", f"-GRAM_LAT={c['ramlat']}", f"-GMEM_MAX_OUT={c['memout']}", f"-GECC={c['ecc']}",
         f"-GNUM_MSHR={c.get('mshr', 1)}"]
    r = subprocess.run([os.path.join(ROOT, "scripts/build_tb.sh"), out] + g, cwd=ROOT, env=env, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(sim):
        raise RuntimeError(f"build {name} failed:\n{r.stdout[-3000:]}{r.stderr[-3000:]}")
    return sim


def run_one(job):
    cname, c, scen, seed, count, sim, outdir, env = job
    tag = f"{cname}.{scen}.s{seed}"
    sdir = os.path.join(outdir, "stim", tag)
    os.makedirs(sdir, exist_ok=True)
    st = STRESS[seed % len(STRESS)]
    g = subprocess.run([sys.executable, "-I", os.path.join(ROOT, "model/gen_stimulus.py"), "--name", scen, "--seed", str(seed),
                        "--sets", str(sets_of(c)), "--ways", str(c["ways"]), "--line", str(c["line"]), "--paddr", str(c["paddr"]),
                        "--repl", str(c["repl"]), "--scenario", scen, "--count", str(count), "--outdir", sdir],
                       capture_output=True, text=True)
    if g.returncode != 0:
        return dict(tag=tag, ok=False, msg="generator failed: " + (g.stderr or g.stdout)[-400:])
    # stress profile is passed as plusargs through $value$plusargs? -> compile-time parameters are fixed per build,
    # so the profile is applied through run-time plusargs handled by the bench.
    t0 = time.time()
    cmd = [sim, f"+DIR={sdir}", f"+NAME={scen}", f"+SEED={seed}", f"+IDLE={st['idle']}", f"+RSPRDY={st['rsp']}",
           f"+MRQRDY={st['mrq']}", f"+MRSVAL={st['mrs']}", f"+LATMIN={st['lmin']}", f"+LATMAX={st['lmax']}"]
    if seed % 2 == 0:
        cmd.append("+CMONB")          # even seeds: CMOs are issued without the idle barrier (CMO port waits for the cache)
    r = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=1800)
    out = r.stdout + r.stderr
    m = re.search(r"TB PASS: .*", out)
    ok = (r.returncode == 0) and bool(m)
    detail = m.group(0) if m else "\n".join([l for l in out.splitlines() if "ERROR" in l or "FAIL" in l or "%Error" in l][:8])
    if ok:
        shutil.rmtree(sdir, ignore_errors=True)
    return dict(tag=tag, ok=ok, msg=detail, secs=round(time.time() - t0, 2), stress=st)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default=",".join(CONFIGS))   # blocking + MSHR configurations
    ap.add_argument("--scenarios", default=",".join(SCENARIOS))
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--count", type=int, default=400)
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 4)
    ap.add_argument("--out", default=os.path.join(ROOT, "sim_build/regression"))
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        for k, v in CONFIGS.items():
            print(k, v, "sets=", sets_of(v))
        return 0
    env = dict(os.environ)
    os.makedirs(a.out, exist_ok=True)
    bdir = os.path.join(ROOT, "sim_build", "cfg")
    sims = {}
    for cn in a.configs.split(","):
        sims[cn] = build(cn, CONFIGS[cn], bdir, env)
    jobs = []
    for cn in a.configs.split(","):
        for sc in a.scenarios.split(","):
            for sd in range(1, a.seeds + 1):
                jobs.append((cn, CONFIGS[cn], sc, sd, a.count, sims[cn], a.out, env))
    results = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(run_one, jobs):
            results.append(r)
            print(("PASS " if r["ok"] else "FAIL ") + r["tag"] + (("  " + r["msg"].splitlines()[0]) if not r["ok"] else ""), flush=True)
    bad = [r for r in results if not r["ok"]]
    json.dump(results, open(os.path.join(a.out, "results.json"), "w"), indent=1)
    print(f"\n{len(results) - len(bad)}/{len(results)} runs passed")
    for r in bad:
        print("---", r["tag"]); print(r["msg"])
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
