#!/usr/bin/env python3
"""Fill the result-dependent placeholders (@TOKEN@) of docs/06, docs/07 and the README from the files under reports/.
Run once at packaging time; refuses to leave an unfilled token behind.  Survivors that are not in the explained list
are written as UNEXPLAINED so a reader cannot mistake them for justified."""
import collections, json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, "reports")

def rd(p):
    p = os.path.join(R, p)
    return open(p).read() if os.path.exists(p) else ""

EXPLAINED = {
 "P2": "equivalent under the ALP contract: it only differs when the memory returns a response while NO request is outstanding, which ALP v1 forbids (ALP-RSP-03).  The cache still raises `proto_err_o` for that case.",
 "F4": "equivalent: the destination way was invalidated before the refill started, so data written there by a failed beat is unobservable (an invalid line's data is a don't-care).",
 "X9": "deliberate **no-op control mutant** (the replacement text equals the original): it must survive, which shows the harness does not kill mutants blindly.",
}

def mut_rows():
    rows, surv = [], []
    for f, t in (("mutation_blocking.md", "blocking cache"), ("mutation_mshr.md", "MSHR extension"), ("mutation_ecc.md", "ECC / error policy")):
        m = rd(f)
        h = re.search(r"\*\*(\d+) / (\d+) mutants killed\*\*, (\d+) survived, (\d+) invalid", m)
        if not h:
            rows.append(f"| {t} | not run | | |"); continue
        rows.append(f"| {t} | {h.group(1)} / {h.group(2)} | {h.group(3)} | {h.group(4)} |")
        for l in m.splitlines():
            c = [x.strip() for x in l.split("|")]
            if len(c) > 4 and c[2] in ("SURVIVED", "INVALID"):
                surv.append((t, c[1], c[2], c[3]))
    tab = "| suite | killed / total | survived | invalid |\n|---|---|---|---|\n" + "\n".join(rows)
    sv = []
    for t, i, st, d in surv:
        sv.append(f"* **{i}** ({t}, {st}): {d} — " + (EXPLAINED[i] if i in EXPLAINED else "**UNEXPLAINED — see the report; treat as a verification gap**"))
    return tab, ("\n".join(sv) if sv else "none")

def reg():
    rs = json.loads(rd("final/regression_results.json") or "[]")
    by = collections.OrderedDict(); checks = 0
    ov = collections.defaultdict(lambda: [0, 0, 0, 0, 0])
    for r in rs:
        cfg = r["tag"].split(".")[0]
        d = by.setdefault(cfg, [0, 0]); d[1] += 1; d[0] += bool(r["ok"])
        m = re.search(r"checks=(\d+)", r.get("msg", "")); checks += int(m.group(1)) if m else 0
        m = re.search(r"MSHR=(\d+).*maxMSHR=(\d+) maxResp=(\d+) maxMemOut=(\d+) parked=(\d+)", r.get("msg", ""))
        if m and int(m.group(1)) > 1:
            a = ov[cfg]; a[0] = int(m.group(1)); a[1] = max(a[1], int(m.group(2))); a[2] = max(a[2], int(m.group(3))); a[3] = max(a[3], int(m.group(4))); a[4] += int(m.group(5))
    tot_ok = sum(v[0] for v in by.values()); tot = sum(v[1] for v in by.values())
    cfgdesc = {"A_default": "32 KiB / 64 B / 4-way / 64-bit (the brief), PLRU, ECC", "B_rr_small": "512 B, 2-way, round-robin, 32-bit addr, RAM lat 2, 1 outstanding", "C_l32": "1 KiB, 32 B lines, 4-way, 48-bit, RAM lat 3",
               "D_direct": "direct-mapped, 16 B lines (1 beat), 40-bit, no ECC", "E_8way": "2 KiB, 8-way", "F_16way_rr": "16-way round-robin", "G_l256": "256 B lines, 36-bit, 16 outstanding",
               "H_noecc": "4 KiB, no ECC, RAM lat 2", "I_mshr2": "2 MSHRs, 48-bit", "J_mshr4_rr": "4 MSHRs, round-robin, RAM lat 2", "K_mshr8": "default geometry, 8 MSHRs, 16 outstanding memory requests",
               "L_mshr2_dm": "2 MSHRs, direct-mapped", "N_mshr3": "3 MSHRs (non-power-of-two), 16 B lines, no ECC", "O_mshr4_ram3": "4 MSHRs, RAM lat 3, 1 outstanding memory request"}
    t = f"**{tot_ok} / {tot} runs pass** ({checks} scoreboard checks).\n\n| configuration | what it is | runs passed |\n|---|---|---|\n" + "\n".join(f"| {k} | {cfgdesc.get(k, '')} | {v[0]} / {v[1]} |" for k, v in by.items())
    o = "| configuration | NUM_MSHR | peak MSHRs in use | peak queued responses | peak outstanding memory requests | parked requests (total) |\n|---|---|---|---|---|---|\n" + \
        "\n".join(f"| {k} | {v[0]} | {v[1]} | {v[2]} | {v[3]} | {v[4]} |" for k, v in sorted(ov.items()))
    return t, o, tot_ok, tot, checks

def synth():
    s = rd("synth.md")
    tab = s.split("## Hierarchy")[0].split("\n\n", 2)[-1].strip() if s else "(not run)"
    obs = []
    m = re.search(r"\| default_32KiB_4way_64B \| (\d+) \| (\d+) \|", s)
    p = re.search(r"(\d+) \$paramod\\sf_cache_perf", s)
    mm = re.search(r"\| mshr4 \| (\d+) \| (\d+) \|", s)
    if m:
        obs.append(f"* default configuration: **{m.group(1)}** generic logic cells, **{m.group(2)}** flip-flops (excluding the 8 RAM macros).")
    if m and p:
        obs.append(f"* the performance counters alone are {p.group(1)} of those cells ({100*int(p.group(1))/int(m.group(1)):.0f} %): `CNT_W = 32` halves them.")
    if m and mm:
        obs.append(f"* the MSHR extension with 4 entries costs +{int(mm.group(1)) - int(m.group(1))} cells and +{int(mm.group(2)) - int(m.group(2))} flip-flops (parked requests, response-order queue, refill descriptor queue); the RAMs are unchanged.")
    obs.append("* ECC encoders / decoders sit in the RAM wrappers (one SECDED encoder + decoder per tag entry and per data lane); removing ECC (`default_noecc`) shows their cost.")
    return tab, "\n".join(obs)

def formal():
    f = rd("final/formal.log").strip()
    if not f:
        return "(not run)"
    rows = []
    for l in f.splitlines():
        m = re.match(r"(\S+)\s+(\S+)\s+(.*?)\s+\[(\d+) s\]", l)
        if m:
            rows.append(f"| `{m.group(1)}` | {m.group(2)} | {m.group(3)} | {m.group(4)} s |")
    return "| harness | task | result | time |\n|---|---|---|---|\n" + "\n".join(rows)

def ecc():
    e = rd("final/ecc_tests.log").strip().splitlines()
    rows = []
    for l in e:
        m = re.match(r"\[(.*?)\]\s+(.*)", l)
        if m:
            rows.append(f"| {m.group(1)} | {m.group(2)[:110]} |")
    return "| variant | result |\n|---|---|\n" + "\n".join(rows)

def main():
    mt, sv = mut_rows(); rt, ot, ok, tot, checks = reg(); st, so = synth()
    subs = {"@REG_TABLE@": rt, "@OVERLAP_TABLE@": ot, "@ECC_TABLE@": ecc(), "@MUT_TABLE@": mt, "@SURVIVORS@": sv, "@FORMAL_TABLE@": formal(), "@SYNTH_TABLE@": st, "@SYNTH_OBS@": so}
    mb = re.search(r"\*\*(\d+) / (\d+) mutants killed\*\*", rd("mutation_blocking.md")); mm = re.search(r"\*\*(\d+) / (\d+) mutants killed\*\*", rd("mutation_mshr.md")); me = re.search(r"\*\*(\d+) / (\d+) mutants killed\*\*", rd("mutation_ecc.md"))
    fl = rd("final/formal.log")
    res = [f"* **Model-vs-RTL regression: {ok} / {tot} runs pass** ({checks} scoreboard checks) over 14 configurations (8 blocking, 6 MSHR), 12 scenarios, 3 seeds, 3 stress profiles; ALP link checkers on both links in every run.",
           f"* **Directed ECC / error-policy / reset tests: {len(re.findall('TB PASS', rd('final/ecc_tests.log')))} / {len(rd('final/ecc_tests.log').strip().splitlines())} variants pass** (RAM latency 1–4, memory link 1–8, MSHR 1–4).",
           "* **Mutation campaigns:** " + "; ".join(f"{n} {m.group(1)} / {m.group(2)}" for n, m in (("blocking", mb), ("MSHR", mm), ("ECC", me)) if m) + " killed (survivors explained in docs/06).",
           "* **Formal:** " + f"{len(re.findall('PROVED', fl))} tasks proved unboundedly (address slicing, replacement policy, MSHR table); " + f"{len(re.findall('BOUNDED PASS', fl))} bounded passes (memory port, whole cache); the address and replacement proofs were shown to fail against deliberately broken copies (docs/06 §5); the MSHR, memory-port and whole-cache harnesses were not separately sensitivity-tested.",
           "* **Measured, with a 1-cycle memory and no back-pressure:** read hit 6 cycles, full-beat write hit 5, clean-victim miss 16, dirty miss up to ~37 (docs/03).",
           "* **Synthesis (generic Yosys, RAMs black-boxed):** default configuration " + (re.search(r"\| default_32KiB_4way_64B \| (\d+) \| (\d+)", rd("synth.md")).expand(r"\1 logic cells, \2 flip-flops") if re.search(r"\| default_32KiB_4way_64B \| (\d+) \| (\d+)", rd("synth.md")) else "n/a") + "; RAMs: 4 × 128×60 tag + 4 × 512×144 data (325 632 bits).  No SRAM timing / area / power claimed."]
    subs["@RESULTS@"] = "\n".join(res)
    for f in ("docs/06_verification.md", "docs/07_physical_design.md", "README.md"):
        p = os.path.join(ROOT, f); s = open(p).read()
        for k, v in subs.items():
            s = s.replace(k, v)
        if re.search(r"@[A-Z_]+@", s):
            print("UNFILLED TOKEN in", f, re.findall(r"@[A-Z_]+@", s)); return 1
        open(p, "w").write(s)
    print("docs filled"); return 0

if __name__ == "__main__":
    sys.exit(main())
