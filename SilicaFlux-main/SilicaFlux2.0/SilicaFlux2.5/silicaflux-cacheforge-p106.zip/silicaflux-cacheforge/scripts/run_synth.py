#!/usr/bin/env python3
"""Generic Yosys synthesis statistics for sf_llc_cache (technology independent).

usage: run_synth.py [--configs a,b] [--out reports/synth.md] [--yosys yosys]

For each configuration: hierarchy check, `synth -flatten` (generic gates, internal ABC), `stat`.
The RAM arrays are BLACK BOXES (synth/sf_sram_be_generic_bb.sv): the reported cells / flip-flops are
the controller, ECC encoders/decoders, replacement metadata, counters and glue ONLY; the RAMs appear as
macro instances with their exact organisation (words x bits).  Cell counts are generic-gate counts for
regression and comparison - they are NOT area, timing or power, and no SRAM access time, area or power
is stated anywhere.
"""
import argparse, json, os, re, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = """third_party/albioncore/rtl/sf_albion_pkg.sv
third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_enc.sv third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_dec.sv
synth/sf_sram_be_generic_bb.sv third_party/srammacrobridge/rtl/backends/sf_sram_be_fpga.sv
third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_ihp1p.sv third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_gf180.sv
third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_sky130.sv third_party/srammacrobridge/rtl/backends/asic/stubs/sf_sram_macro_blackboxes.sv
third_party/srammacrobridge/rtl/backends/sf_sram_be_asic.sv third_party/srammacrobridge/rtl/sf_sram_macro_wrapper.sv
rtl/cache/sf_cache_pkg.sv rtl/cache/sf_cache_addr.sv rtl/cache/sf_cache_replacement.sv rtl/cache/sf_cache_tag_array.sv
rtl/cache/sf_cache_data_array.sv rtl/cache/sf_cache_mshr.sv rtl/cache/sf_cache_memport.sv rtl/cache/sf_cache_refill.sv
rtl/cache/sf_cache_writeback.sv rtl/cache/sf_cache_perf.sv rtl/cache/sf_llc_cache.sv""".split()

CONFIGS = {  # name: parameter overrides of sf_llc_cache
    "default_32KiB_4way_64B": {},
    "default_noecc":          {"ECC_EN": 0},
    "rr_policy":              {"REPL_POLICY": 0},
    "8way_64KiB":             {"CACHE_BYTES": 65536, "WAYS": 8},
    "paddr48":                {"PADDR_W": 48},
    "line128B":               {"LINE_BYTES": 128},
    "mshr4":                  {"NUM_MSHR": 4},
}


def run(name, ov, yosys):
    os.makedirs(os.path.join(ROOT, "sim_build"), exist_ok=True)
    stat_rel, hier_rel, json_rel = (f"sim_build/synth_{name}.{e}" for e in ("stat", "hier", "json"))
    ys = ["read_verilog -sv -D SYNTHESIS -Ithird_party/srammacrobridge/rtl -Ithird_party/srammacrobridge/rtl/ecc "
          "-Ithird_party/srammacrobridge/rtl/backends " + " ".join(RTL)]
    for k, v in ov.items():
        ys.append(f"chparam -set {k} {v} sf_llc_cache")
    # NOTE: the YoWASP Yosys build cannot spawn ABC, so no ABC mapping/optimisation is run: the counts are
    # Yosys generic gates after `synth -noabc` (word-level cells techmapped to $_AND_/$_MUX_/$_DFF*...).
    ys += ["hierarchy -check -top sf_llc_cache", "synth -top sf_llc_cache -noabc -run coarse:", f"tee -o {hier_rel} stat -width",
           "flatten", "opt_clean", f"tee -o {stat_rel} stat -width", f"write_json {json_rel}"]
    r = subprocess.run([yosys, "-q", "-p", "; ".join(ys)], cwd=ROOT, capture_output=True, text=True)
    warn = [l for l in (r.stdout + r.stderr).splitlines() if re.search(r"warning|error", l, re.I) and "Replacing memory" not in l]
    if not os.path.exists(os.path.join(ROOT, stat_rel)):
        return dict(name=name, ok=False, msg=(r.stdout + r.stderr)[-1500:])
    return dict(name=name, ok=True, stat=open(os.path.join(ROOT, stat_rel)).read(), hier=open(os.path.join(ROOT, hier_rel)).read(),
                json=json.load(open(os.path.join(ROOT, json_rel))), warnings=warn, overrides=ov)


def rams(js):
    """RAM black boxes of the flattened design: list of (words, bits, lanes)."""
    out = []
    mods = js["modules"]
    top = next((m for m in mods.values() if str(m.get("attributes", {}).get("top", "0")).strip("0") != ""), None)
    if top is None:   # after chparam the top is renamed $paramod...; fall back to the only module of the flattened design
        top = next(iter(mods.values()))
    for cn, c in top["cells"].items():
        if c["type"].endswith("sf_sram_be_generic"):
            p = {k: int(v, 2) if isinstance(v, str) else int(v) for k, v in c["parameters"].items() if k in ("PW", "DEPTH", "NL", "PLW")}
            out.append((p.get("DEPTH", 0), p.get("PW", 0), p.get("NL", 0), cn))
    return out


def parse(stat):
    d = {"cells": None, "gates": {}}
    for line in stat.splitlines():
        m = re.match(r"\s+(\d+)\s+cells\s*$", line)
        if m and d["cells"] is None:
            d["cells"] = int(m.group(1))
        mm = re.match(r"\s+(\d+)\s+(\$_[A-Z0-9_]+_)\s*$", line)
        if mm:
            d["gates"][mm.group(2)] = d["gates"].get(mm.group(2), 0) + int(mm.group(1))
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default=",".join(CONFIGS))
    ap.add_argument("--out", default=os.path.join(ROOT, "reports/synth.md"))
    ap.add_argument("--yosys", default="yosys")
    a = ap.parse_args()
    rows, raw = [], []
    for n in a.configs.split(","):
        r = run(n, CONFIGS[n], a.yosys)
        if not r["ok"]:
            print("FAIL", n, r["msg"]); rows.append((n, None)); continue
        d = parse(r["stat"])
        d["rams"] = rams(r["json"])
        rows.append((n, (r, d)))
        print(f"{n}: logic cells={d['cells']} RAM instances={len(d['rams'])} ram bits={sum(w*b for w,b,_,_ in d['rams'])} warnings={len(r['warnings'])}")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w") as f:
        f.write("# Generic synthesis statistics (Yosys, technology-independent)\n\n")
        f.write("Cell counts are generic-gate counts of the **controller, ECC logic, replacement metadata, counters and glue**; "
                "the RAMs are black boxes and are listed by organisation.  They are **not** area, timing or power, and no SRAM "
                "access time, die area or power figure is stated or implied.\n\n")
        f.write("| configuration | logic cells (excl. RAM) | flip-flops | RAM instances | RAM organisation | RAM bits (incl. ECC) |\n|---|---|---|---|---|---|\n")
        for n, v in rows:
            if v is None:
                f.write(f"| {n} | SYNTHESIS FAILED | | | | |\n"); continue
            r, d = v
            ff = sum(c for t, c in d["gates"].items() if "DFF" in t or "DLATCH" in t)
            org = {}
            for w, b, nl, _ in d["rams"]:
                org[(w, b)] = org.get((w, b), 0) + 1
            orgs = "; ".join(f"{k}x {w} words x {b} bits" for (w, b), k in sorted(org.items()))
            f.write(f"| {n} | {d['cells']} | {ff} | {len(d['rams'])} | {orgs} | {sum(w*b for w,b,_,_ in d['rams'])} |\n")
        f.write("\n## Hierarchy (cells including submodules) per configuration\n")
        for n, v in rows:
            if v is None:
                continue
            h = v[0]["hier"]
            blk = h.split("design hierarchy ===")[1].split("Count including submodules")[0:2]
            lines = [l for l in h.split("=== design hierarchy ===")[1].splitlines()[4:20] if re.match(r"\s+\d+\s+\S", l) and "$_" not in l][:16]
            f.write(f"\n### {n}\n\n```\n" + "\n".join(l[:130] for l in lines) + "\n```\n")
        f.write("\n## Raw `stat` output per configuration\n")
        for n, v in rows:
            if v is None:
                continue
            f.write(f"\n### {n}\n\n```\n{v[0]['stat']}\n```\n")
    return 0

if __name__ == "__main__":
    sys.exit(main())
