#!/usr/bin/env python3
"""Build the delivery archive: MANIFEST.sha256 + silicaflux-cacheforge-p106.zip (nothing is committed to git).

usage: make_package.py [--out DIR]     (default: the directory above the package root)
Excluded: sim_build/, __pycache__/, SymbiYosys working directories (formal/fv_*_*/), *.pyc, previous archives.
"""
import hashlib, os, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = os.path.basename(ROOT)
SKIP_DIRS = {"sim_build", "__pycache__", ".git"}

def keep(rel, is_dir):
    parts = rel.split(os.sep)
    if any(p in SKIP_DIRS for p in parts):
        return False
    if parts[0] == "formal" and len(parts) > 1 and is_dir and parts[1].startswith("fv_") and "." not in parts[1]:
        return False                                    # sby task directory
    if parts[0] == "formal" and len(parts) > 1 and parts[1].startswith("fv_") and "." not in parts[1]:
        return False
    return not (rel.endswith(".pyc") or rel.endswith(".zip") or rel == "MANIFEST.sha256")

def main(argv):
    out = argv[argv.index("--out") + 1] if "--out" in argv else os.path.dirname(ROOT)
    files = []
    for d, ds, fs in os.walk(ROOT):
        rel_d = os.path.relpath(d, ROOT)
        ds[:] = sorted(x for x in ds if keep(os.path.normpath(os.path.join(rel_d, x)), True))
        for f in sorted(fs):
            rel = os.path.normpath(os.path.join(rel_d, f))
            if keep(rel, False):
                files.append(rel)
    with open(os.path.join(ROOT, "MANIFEST.sha256"), "w") as m:
        for rel in files:
            m.write(f"{hashlib.sha256(open(os.path.join(ROOT, rel), 'rb').read()).hexdigest()}  {rel}\n")
    files.append("MANIFEST.sha256")
    zpath = os.path.join(out, "silicaflux-cacheforge-p106.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in sorted(files):
            z.write(os.path.join(ROOT, rel), os.path.join("silicaflux-cacheforge", rel))
    print(f"{len(files)} files -> {zpath} ({os.path.getsize(zpath)//1024} KiB)")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
