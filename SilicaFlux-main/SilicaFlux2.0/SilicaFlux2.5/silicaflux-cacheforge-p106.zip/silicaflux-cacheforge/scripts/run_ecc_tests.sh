#!/usr/bin/env bash
# Directed ECC / error-policy / reset tests over several RAM-latency / memory-link / stress variants.
# usage: scripts/run_ecc_tests.sh   (needs verilator on PATH or $VERILATOR)
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
VAR=("RAM_LAT=1 MEM_MAX_OUT=4 P_STRESS=1" "RAM_LAT=1 MEM_MAX_OUT=1 P_STRESS=0" "RAM_LAT=2 MEM_MAX_OUT=2 P_STRESS=1" "RAM_LAT=3 MEM_MAX_OUT=4 P_STRESS=1" "RAM_LAT=4 MEM_MAX_OUT=1 P_STRESS=1" "ECC=0 RAM_LAT=1 MEM_MAX_OUT=4 P_STRESS=1" "NUM_MSHR=2 RAM_LAT=1 MEM_MAX_OUT=4 P_STRESS=1" "NUM_MSHR=4 RAM_LAT=2 MEM_MAX_OUT=8 P_STRESS=1" "NUM_MSHR=3 RAM_LAT=3 MEM_MAX_OUT=1 P_STRESS=1")
fail=0; mkdir -p reports
: > reports/ecc_tests.log
for i in "${!VAR[@]}"; do
  G=(); for kv in ${VAR[$i]}; do G+=("-G${kv}"); done
  B="sim_build/ecc_v$i"
  TOP=tb_sf_llc_ecc TBFILES=tb/tb_sf_llc_ecc.sv ./scripts/build_tb.sh "$B" "${G[@]}" >/dev/null 2>&1 || { echo "BUILD FAIL ${VAR[$i]}" | tee -a reports/ecc_tests.log; fail=1; continue; }
  out=$("$B/sim" 2>&1); line=$(echo "$out" | grep -E 'TB (PASS|FAIL)' | head -1)
  echo "[${VAR[$i]}] ${line:-NO RESULT}" | tee -a reports/ecc_tests.log
  echo "$out" | grep -q 'TB PASS' || { echo "$out" | grep -E 'ERROR|Error' | head -5 | tee -a reports/ecc_tests.log; fail=1; }
done
exit $fail
