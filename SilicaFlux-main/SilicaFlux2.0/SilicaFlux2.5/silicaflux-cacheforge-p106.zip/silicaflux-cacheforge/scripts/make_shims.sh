#!/bin/sh
# Create `yosys`, `yosys-smtbmc`, `yosys-witness` and `sby` wrapper scripts for the YoWASP wheels
# (pip install yowasp-yosys z3-solver) in <dir>, then put <dir> on PATH.  Not needed with a native Yosys / SymbiYosys.
# usage: scripts/make_shims.sh <dir>
set -eu
D="${1:?usage: make_shims.sh <dir>}"; mkdir -p "$D"
for pair in yosys:yowasp-yosys yosys-smtbmc:yowasp-yosys-smtbmc yosys-witness:yowasp-yosys-witness sby:yowasp-sby; do
  n="${pair%%:*}"; b="${pair##*:}"
  printf '#!/bin/sh\nexec %s "$@"\n' "$(command -v "$b")" > "$D/$n"; chmod +x "$D/$n"
done
echo "shims written to $D  (export PATH=$D:\$PATH)"
