#!/usr/bin/env python3
"""Verify the vendored third-party files.

  check_vendor.py                 verify third_party/SHA256SUMS against the files on disk
  check_vendor.py --update        (re)write third_party/SHA256SUMS
  check_vendor.py --repo <root>   additionally compare every vendored file BYTE FOR BYTE with the member of the original
                                  archive in a checkout of the Aureom.AI repository (AlbionCore 0.1.0, SRAMMacroBridge P79)
Exit status 0 = everything matches.
"""
import hashlib, os, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TP = os.path.join(ROOT, "third_party")
SUMS = os.path.join(TP, "SHA256SUMS")
ARCH = {  # vendored prefix -> (archive path inside the repository, member prefix, member-path rewriting)
    "albioncore": ("SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/albioncore-0.1.0.zip", "albioncore-0.1.0/"),
    "srammacrobridge": ("SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-srammacrobridge-p79.zip", "silicaflux-srammacrobridge/"),
}

def files():
    out = []
    for d, _, fs in os.walk(TP):
        for f in fs:
            if f != "SHA256SUMS":
                out.append(os.path.relpath(os.path.join(d, f), TP))
    return sorted(out)

def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()

def member(rel):
    top, rest = rel.split(os.sep, 1)
    arch, pre = ARCH[top]
    if top == "albioncore":
        if rest.startswith("rtl/"):   m = pre + "rtl/albion/" + rest[4:]
        elif rest.startswith("tests/"): m = pre + "tests/albion/common/" + rest[6:]
        elif rest == "README_albioncore.md": m = pre + "README.md"
        else: raise KeyError(rel)
    else:
        m = pre + ("rtl/files.f" if rest == "files.f.orig" else rest)
    return arch, m

def main(argv):
    if "--update" in argv:
        with open(SUMS, "w") as f:
            for r in files():
                f.write(f"{sha(os.path.join(TP, r))}  {r}\n")
        print(f"wrote {SUMS} ({len(files())} files)"); return 0
    bad = 0
    want = dict((l.split("  ", 1)[1].strip(), l.split("  ", 1)[0]) for l in open(SUMS) if l.strip())
    for r in files():
        if want.get(r) != sha(os.path.join(TP, r)):
            print("MISMATCH", r); bad += 1
    for r in want:
        if not os.path.exists(os.path.join(TP, r)):
            print("MISSING ", r); bad += 1
    print(f"SHA256SUMS: {len(want)} files, {bad} problems")
    if "--repo" in argv:
        repo = argv[argv.index("--repo") + 1]
        zips = {}
        n = 0
        for r in files():
            arch, m = member(r)
            if arch not in zips:
                zips[arch] = zipfile.ZipFile(os.path.join(repo, arch))
            data = zips[arch].read(m)
            n += 1
            if data != open(os.path.join(TP, r), "rb").read():
                print("DIFFERS FROM ARCHIVE:", r, "<-", arch + "!" + m); bad += 1
        print(f"archive comparison: {n} files byte-identical to the original archives" if not bad else f"archive comparison: {bad} problems")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
