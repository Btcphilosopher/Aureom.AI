#!/usr/bin/env python3
"""Replace the INVALID rows of a mutation report by the rows of a re-run (same ids) and recompute the header.
usage: merge_mutation.py base.md rerun.md out.md"""
import re, sys

def rows(path):
    return [l for l in open(path).read().splitlines() if l.startswith("| ") and not l.startswith("| id") and not l.startswith("|---")]

def rid(l):
    return l.split("|")[1].strip()

base, rerun, out = sys.argv[1:4]
re_rows = {rid(l): l for l in rows(rerun)}
merged = [re_rows.get(rid(l), l) if "| INVALID |" in l and rid(l) in re_rows else l for l in rows(base)]
k = sum("| KILLED |" in l for l in merged); sv = sum("| SURVIVED |" in l for l in merged); iv = sum("| INVALID |" in l for l in merged)
cfg = re.search(r"Configurations:.*", open(base).read()).group(0)
with open(out, "w") as f:
    f.write(f"# Mutation campaign (model-vs-RTL regression)\n\n{cfg}  (rows that were INVALID in the first pass because the mutation pattern no longer matched renamed RTL were re-run after updating the pattern).\n\n")
    f.write(f"**{k} / {len(merged)} mutants killed**, {sv} survived, {iv} invalid.\n\n| id | status | defect injected | evidence |\n|---|---|---|---|\n")
    f.write("\n".join(merged) + "\n")
print(f"{k}/{len(merged)} killed, {sv} survived, {iv} invalid")
