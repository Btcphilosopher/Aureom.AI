#!/usr/bin/env python3
"""Prove scripts/check_config.py == Verilator elaboration of sf_llc_cache for legal and illegal parameter sets.
Every illegal set must make Verilator FAIL to elaborate (the RTL rejects it, nothing is silently rounded);
every legal set must elaborate.  usage: test_config_rejection.py   (needs verilator on PATH or $VERILATOR)"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import check_config as cc

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VL = os.environ.get("VERILATOR", "verilator")
files = [l.strip() for l in open(os.path.join(ROOT, "rtl/files.f")) if l.strip() and not l.startswith("//")]
inc = open(os.path.join(ROOT, "rtl/incdirs.f")).read().split()

CASES = [  # (label, overrides, expect_legal)
 ("default", {}, True), ("direct-mapped", dict(WAYS=1, CACHE_BYTES=4096), True), ("16-way", dict(WAYS=16, CACHE_BYTES=16384, LINE_BYTES=32), True),
 ("line 16 B", dict(LINE_BYTES=16, CACHE_BYTES=1024), True), ("line 256 B", dict(LINE_BYTES=256, CACHE_BYTES=8192), True), ("PADDR 32", dict(PADDR_W=32), True),
 ("MSHR 8", dict(NUM_MSHR=8), True), ("round-robin", dict(REPL_POLICY=0), True), ("RAM latency 4", dict(RAM_LATENCY=4), True), ("MEM_MAX_OUT 16", dict(MEM_MAX_OUT=16), True),
 ("2 sets exactly", dict(CACHE_BYTES=512, WAYS=4, LINE_BYTES=64), True),
 ("LINE_BYTES 48", dict(LINE_BYTES=48), False), ("LINE_BYTES 8", dict(LINE_BYTES=8), False), ("LINE_BYTES 512", dict(LINE_BYTES=512), False),
 ("WAYS 3", dict(WAYS=3), False), ("WAYS 32", dict(WAYS=32, CACHE_BYTES=65536), False), ("CACHE_BYTES 3000", dict(CACHE_BYTES=3000), False),
 ("1 set", dict(CACHE_BYTES=256, WAYS=4, LINE_BYTES=64), False), ("PADDR 31", dict(PADDR_W=31), False), ("PADDR 65", dict(PADDR_W=65), False),
 ("empty tag", dict(PADDR_W=32, CACHE_BYTES=2**32, WAYS=1), False),
 ("MSHR 0", dict(NUM_MSHR=0), False), ("MSHR 9", dict(NUM_MSHR=9), False), ("REPL 2", dict(REPL_POLICY=2), False),
 ("RAM latency 0", dict(RAM_LATENCY=0), False), ("RAM latency 5", dict(RAM_LATENCY=5), False),
 ("MEM_MAX_OUT 0", dict(MEM_MAX_OUT=0), False), ("MEM_MAX_OUT 17", dict(MEM_MAX_OUT=17), False), ("CNT_W 16", dict(CNT_W=16), False),
]

bad = 0
for label, ov, legal in CASES:
    py_legal = not cc.check(ov)
    g = [f"-G{k}={v}" for k, v in ov.items()]
    r = subprocess.run([VL, "--lint-only", "-Wno-fatal", "-Werror-USERERROR", "--top-module", "sf_llc_cache"] + g + inc + files, cwd=ROOT, capture_output=True, text=True)
    # a generate-time $error is reported as %Warning-USERERROR (fatal unless -Wno-fatal), a $fatal as %Error
    rtl_legal = (r.returncode == 0) and ("%Error" not in r.stderr) and ("USERERROR" not in r.stderr)
    ok = (py_legal == legal) and (rtl_legal == legal)
    bad += (not ok)
    print(("ok   " if ok else "FAIL ") + f"{label:18s} expected {'legal' if legal else 'rejected'}; checker: {'legal' if py_legal else 'rejected'}; RTL elaboration: {'legal' if rtl_legal else 'rejected'}")
print(f"\n{len(CASES) - bad}/{len(CASES)} agree")
sys.exit(1 if bad else 0)
