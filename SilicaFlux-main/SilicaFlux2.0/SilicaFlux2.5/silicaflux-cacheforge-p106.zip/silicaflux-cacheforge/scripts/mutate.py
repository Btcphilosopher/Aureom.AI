#!/usr/bin/env python3
"""Mutation campaign: prove the regression can fail.

Each mutant applies ONE small deliberate defect to a private copy of the package, rebuilds the
bench and runs the model-vs-RTL regression (a subset: two configurations x every scenario x 2
seeds).  A mutant is KILLED if at least one run fails (or the build/elaboration rejects it as an
illegal design); it SURVIVES if every run passes - a hole in the verification that must be closed
(or the mutant proven equivalent).

usage: mutate.py [--jobs N] [--only id,id] [--suite blocking|ecc] [--out reports/mutation.md]
"""
import argparse, concurrent.futures as cf, json, os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
C = "rtl/cache/"
# (id, file, old, new, description)
MUTANTS = [
 ("R1",  C+"sf_cache_replacement.sv", "touch_nxt[node] = ~touch_way_i[WAY_W-1-l];", "touch_nxt[node] = touch_way_i[WAY_W-1-l];", "PLRU touch points TOWARDS the accessed way"),
 ("R2",  C+"sf_cache_replacement.sv", "assign victim_o         = any_inv ? first_inv : pol_vic;", "assign victim_o         = pol_vic;", "invalid ways not preferred"),
 ("R3",  C+"sf_cache_replacement.sv", "st_q[touch_set_i] <= touch_way_i + 1'b1;", "st_q[touch_set_i] <= touch_way_i;", "round-robin counter does not advance"),
 ("R4",  C+"sf_cache_replacement.sv", "node = 2 * node + 1 + (q_st[node] ? 1 : 0);", "node = 2 * node + 1 + (q_st[node] ? 0 : 1);", "PLRU victim walk goes the wrong way"),
 ("T1",  C+"sf_llc_cache.sv", "hit_vec[w] = v_valid_q[w] && (v_tag_q[w*TAG_W +: TAG_W] == tag_q);", "hit_vec[w] = (v_tag_q[w*TAG_W +: TAG_W] == tag_q);", "hit ignores the valid bit"),
 ("T2",  C+"sf_llc_cache.sv", "hit_vec[w] = v_valid_q[w] && (v_tag_q[w*TAG_W +: TAG_W] == tag_q);", "hit_vec[w] = v_valid_q[w] && (v_tag_q[w*TAG_W +: TAG_W][TAG_W-1:1] == tag_q[TAG_W-1:1]);", "tag compare ignores bit 0"),
 ("W1",  C+"sf_llc_cache.sv", "          if (hit_dirty_q) begin\n            rsp_load  = 1'b1;\n            rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b1, corr_q, 128'd0);\n            lat_valid = miss_q;\n            ms_free_en = miss_q;\n            state_d   = S_IDLE;\n          end else begin\n            state_d   = S_WDIRTY;\n          end\n        end else begin\n          da_rd_en = 1'b1;",
         "          if (1'b1) begin\n            rsp_load  = 1'b1;\n            rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b1, corr_q, 128'd0);\n            lat_valid = miss_q;\n            ms_free_en = miss_q;\n            state_d   = S_IDLE;\n          end else begin\n            state_d   = S_WDIRTY;\n          end\n        end else begin\n          da_rd_en = 1'b1;", "full-beat write hit never sets dirty"),
 ("W2",  C+"sf_llc_cache.sv", "        tag_wr_valid = 1'b1;\n        tag_wr_dirty = 1'b1;\n        tag_wr_tag   = tag_q;\n        rsp_load     = 1'b1;", "        tag_wr_valid = 1'b1;\n        tag_wr_dirty = 1'b0;\n        tag_wr_tag   = tag_q;\n        rsp_load     = 1'b1;", "dirty bit written as 0 on write"),
 ("W3",  C+"sf_llc_cache.sv", "assign merged = (req_q.data & lane_mask(req_q.be)) | (da_rd_data & ~lane_mask(req_q.be));", "assign merged = (req_q.data & ~lane_mask(req_q.be)) | (da_rd_data & lane_mask(req_q.be));", "partial-write merge mask inverted"),
 ("W4",  C+"sf_llc_cache.sv", "        end else if (full_be_q) begin\n          fe_wr      = 1'b1;", "        end else if (full_be_q || (req_q.be[15:8] == 8'hFF)) begin\n          fe_wr      = 1'b1;", "write with only the upper half enabled treated as full-beat"),
 ("E1",  C+"sf_llc_cache.sv", "if (vic_valid_q && vic_dirty_q) begin\n          wb_start = 1'b1;", "if (vic_valid_q && vic_dirty_q && 1'b0) begin\n          wb_start = 1'b1;", "dirty victim is not written back (data lost)"),
 ("E2",  C+"sf_llc_cache.sv", "        ev[sf_cache_pkg::EV_EVICT] = 1'b1;\n        state_d      = S_RFS;", "        state_d      = S_RFS;", "eviction not counted"),
 ("E3",  C+"sf_llc_cache.sv", "          if (wb_err) begin\n            // writeback rejected", "          if (1'b0) begin\n            // writeback rejected", "writeback error ignored: victim invalidated, data lost"),
 ("E4",  C+"sf_llc_cache.sv", "          if (rf_err) begin\n            ev[sf_cache_pkg::EV_REFILL_ERR]", "          if (1'b0) begin\n            ev[sf_cache_pkg::EV_REFILL_ERR]", "refill error ignored: garbage line installed"),
 ("E5",  C+"sf_llc_cache.sv", "        tag_wr_valid = 1'b1;\n        tag_wr_dirty = 1'b0;\n        tag_wr_tag   = tag_q;\n        touch_en     = 1'b1;", "        tag_wr_valid = 1'b1;\n        tag_wr_dirty = 1'b1;\n        tag_wr_tag   = tag_q;\n        touch_en     = 1'b1;", "line installed dirty (spurious writebacks)"),
 ("E6",  C+"sf_llc_cache.sv", "            touch_en    = 1'b1;\n            touch_way   = way_q;\n            touch_alloc = 1'b1;\n            ev[sf_cache_pkg::EV_WB_ERR]", "            touch_en    = 1'b0;\n            touch_way   = way_q;\n            touch_alloc = 1'b1;\n            ev[sf_cache_pkg::EV_WB_ERR]", "no replacement touch after a writeback error"),
 ("H1",  C+"sf_llc_cache.sv", "          touch_en    = 1'b1;\n          touch_way   = hit_idx;", "          touch_en    = 1'b0;\n          touch_way   = hit_idx;", "hit does not update replacement state"),
 ("H2",  C+"sf_llc_cache.sv", "rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b0, corr_q | da_rd_ce, da_rd_data & lane_mask(req_q.be));", "rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b0, corr_q | da_rd_ce, da_rd_data);", "read response not masked by byte enables"),
 ("H3",  C+"sf_llc_cache.sv", "rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b0, corr_q | da_rd_ce, da_rd_data & lane_mask(req_q.be));", "rsp_d     = mk_rsp(req_q.tag ^ 8'h01, sf_albion_pkg::SF_ST_OKAY, 1'b0, corr_q | da_rd_ce, da_rd_data & lane_mask(req_q.be));", "response tag corrupted"),
 ("B1",  C+"sf_llc_cache.sv", "wire logic              cacheable = cfg_en_i && (req_q.attr[1:0] == 2'(sf_albion_pkg::SF_MEM_NORMAL_WB)) && !nc_hit;", "wire logic              cacheable = cfg_en_i && !nc_hit;", "non-cacheable memory type ignored"),
 ("B2",  C+"sf_llc_cache.sv", "(a_q < cfg_nc_limit_i);", "(a_q <= cfg_nc_limit_i);", "NC window limit inclusive"),
 ("B3",  C+"sf_llc_cache.sv", "wire logic              cacheable = cfg_en_i &&", "wire logic              cacheable = 1'b1 &&", "cache-enable configuration ignored"),
 ("B4",  C+"sf_llc_cache.sv", "rsp_d    = mk_rsp(req_q.tag, mc_cpl.status, is_wr_q, mc_cpl.meta[3], mc_cpl.data & lane_mask(req_q.be));", "rsp_d    = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, is_wr_q, mc_cpl.meta[3], mc_cpl.data & lane_mask(req_q.be));", "bypass error status swallowed"),
 ("L1",  C+"sf_cache_addr.sv", "assign out_of_range_o = |addr_i[63:PADDR_W];", "assign out_of_range_o = 1'b0;", "address above PADDR_W not rejected"),
 ("L3",  C+"sf_cache_addr.sv", "assign set_o = addr_i[OFF_W +: IDX_W];", "assign set_o = addr_i[OFF_W+1 +: IDX_W];", "set index slice shifted by one bit"),
 ("L4",  C+"sf_cache_addr.sv", "assign rbase_o = (rt << (OFF_W + IDX_W)) | (rs << OFF_W);", "assign rbase_o = (rt << (OFF_W + IDX_W)) | (rs << (OFF_W + 1));", "victim address reconstruction wrong"),
 ("L2",  C+"sf_llc_cache.sv", "        if (legal_st != sf_albion_pkg::SF_ST_OKAY) begin\n          rsp_load = 1'b1;", "        if (1'b0) begin\n          rsp_load = 1'b1;", "illegal requests not rejected"),
 ("C1",  C+"sf_llc_cache.sv", "              tag_wr_valid = 1'b1; tag_wr_dirty = 1'b0;\n            end else begin", "              tag_wr_valid = 1'b1; tag_wr_dirty = 1'b1;\n            end else begin", "CMO CLEAN leaves the line dirty"),
 ("C2",  C+"sf_llc_cache.sv", "cmo_in_range  = !cmo_empty_q && (cmo_line_base < cmo_end_q) && (cmo_line_end > {1'b0, cmo_start_q});", "cmo_in_range  = !cmo_empty_q && (cmo_line_end > {1'b0, cmo_start_q});", "CMO range end ignored"),
 ("C3",  C+"sf_llc_cache.sv", "cmo_in_range  = !cmo_empty_q &&", "cmo_in_range  = ", "CMO size 0 treated as a non-empty range"),
 ("C4",  C+"sf_llc_cache.sv", "            wb_start  = 1'b1;\n            cmo_way_d = cmo_way_q;          // stay on this way until its writeback completes\n            cmo_set_d = cmo_set_q;\n", "            wb_start  = 1'b1;\n", "CMO moves to the next way before its writeback finishes"),
 ("C5",  C+"sf_llc_cache.sv", "            if (cmo_ent_dirty) ev[sf_cache_pkg::EV_CMO_DISCARD] = 1'b1;\n", "", "INVAL does not count discarded dirty lines"),
 ("C6",  C+"sf_llc_cache.sv", "if (cmo_op_q == sf_cache_pkg::CMO_INVAL) begin\n            if (cmo_ent_dirty)", "if (cmo_op_q == sf_cache_pkg::CMO_INVAL && 1'b0) begin\n            if (cmo_ent_dirty)", "INVAL behaves like CLEAN (writes dirty data back)"),
 ("C7",  C+"sf_llc_cache.sv", "          if (cmo_set_q == IDX_W'(SETS - 1)) state_d = S_CMO_DONE;\n          else begin cmo_set_d = cmo_set_q + 1'b1; state_d = S_CMO_RD; end\n        end else begin\n          cmo_way_d = cmo_way_q + 1'b1;\n          state_d   = S_CMO_CHK;\n        end\n        if (cmo_ent_ue)", "          if (cmo_set_q == IDX_W'(SETS - 2)) state_d = S_CMO_DONE;\n          else begin cmo_set_d = cmo_set_q + 1'b1; state_d = S_CMO_RD; end\n        end else begin\n          cmo_way_d = cmo_way_q + 1'b1;\n          state_d   = S_CMO_CHK;\n        end\n        if (cmo_ent_ue)", "CMO walk stops one set early"),
 ("P1",  C+"sf_cache_memport.sv", "sel_req.tag = 8'(tail_q);", "sel_req.tag = 8'd0;", "memory tags not unique (all zero)"),
 ("P2",  C+"sf_cache_memport.sv", "assign mrsp_ready_o = q_nonempty && c_cpl_ready_i[head_client];", "assign mrsp_ready_o = c_cpl_ready_i[head_client];", "response accepted with an empty order queue"),
 ("P3",  C+"sf_cache_memport.sv", "wire logic full  = (cnt_q == CNT_W'(MEM_MAX_OUT));", "wire logic full  = 1'b0;", "outstanding limit not enforced"),
 ("F1",  C+"sf_cache_refill.sv", "m_req_o.addr = d_addr[iss_ptr_q] + 64'(iss_beat_q) * 64'd16;", "m_req_o.addr = d_addr[iss_ptr_q] + 64'(iss_beat_q) * 64'd8;", "refill beat address stride wrong"),
 ("F2",  C+"sf_cache_refill.sv", "assign da_wr_beat_o = BEAT_W'(cpl_beat_q);", "assign da_wr_beat_o = BEAT_W'(iss_beat_q);", "refill data written to the wrong beat"),
 ("F3",  C+"sf_cache_refill.sv", "        if (!cpl_ok && !acc_err_q) begin", "        if (1'b0) begin", "refill error status never recorded"),
 ("F4",  C+"sf_cache_refill.sv", "assign da_wr_en_o   = cpl_fire && cpl_ok;", "assign da_wr_en_o   = cpl_fire;", "failed refill beat still written"),
 ("K1",  C+"sf_cache_writeback.sv", "m_req_o.addr = addr_q + 64'(beat_q) * 64'd16;", "m_req_o.addr = addr_q + 64'(beat_q) * 64'd8;", "writeback beat address stride wrong"),
 ("K2",  C+"sf_cache_writeback.sv", "m_req_o.be   = 16'hFFFF;\n    m_req_o.data = data_q;", "m_req_o.be   = 16'h7FFF;\n    m_req_o.data = data_q;", "writeback byte enables wrong"),
 ("K3",  C+"sf_cache_writeback.sv", "if (m_cpl_i.status != sf_albion_pkg::SF_ST_OKAY && !err_q) begin", "if (1'b0) begin", "writeback error status never recorded"),
 ("K4",  C+"sf_cache_writeback.sv", "          if (cpl_q == sent_q) begin", "          if (1'b1) begin", "writeback does not wait for its responses"),
 ("A1",  C+"sf_cache_tag_array.sv", "wire logic ce = wr_en_i ? wr_way_i[w] : rd_en_i;", "wire logic ce = wr_en_i ? (wr_way_i[w] || w == 0) : rd_en_i;", "tag write also hits way 0"),
 ("A2",  C+"sf_cache_data_array.sv", "wire logic [DIDX_W-1:0] rd_idx = DIDX_W'(rd_set_i) * DIDX_W'(BEATS) + DIDX_W'(rd_beat_i);", "wire logic [DIDX_W-1:0] rd_idx = DIDX_W'(rd_set_i) * DIDX_W'(BEATS);", "data read ignores the beat index"),
 ("A3",  C+"sf_cache_data_array.sv", "wire logic sel_wr = wr_en_i && (wr_way_i == WAY_W'(w));", "wire logic sel_wr = wr_en_i && (wr_way_i == WAY_W'(w)) && (w != 1);", "data array way 1 cannot be written"),
 ("S1",  C+"sf_llc_cache.sv", "        else if (rsp_valid_q && rsp_ready_i) rsp_valid_q <= 1'b0;", "        else                                 rsp_valid_q <= 1'b0;", "response dropped without waiting for ready"),
 ("S2",  C+"sf_llc_cache.sv", "                          : ((state_q == S_IDLE) && !rsp_valid_q);", "                          : (state_q == S_IDLE);", "new request accepted while a response is pending"),
 ("N1",  C+"sf_cache_perf.sv", "if (ev_i[i]) c_q[i] <= c_q[i] + 1'b1;", "if (ev_i[i] && i != sf_cache_pkg::EV_WR_HIT) c_q[i] <= c_q[i] + 1'b1;", "write-hit counter never counts"),
]
MUTANTS = [m for m in MUTANTS]

# MSHR-extension mutants (NUM_MSHR > 1): run on the MSHR configurations
NB_MUTANTS = [
 ("M1",  C+"sf_llc_cache.sv", "        if (NB && !ms_alloc_ready) begin\n          // the set is owned", "        if (NB && !ms_alloc_ready && 1'b0) begin\n          // the set is owned", "request to a set owned by an outstanding miss is not parked"),
 ("M2",  C+"sf_llc_cache.sv", "        if (NB && replay_avail) begin\n          // a miss has completed", "        if (NB && replay_avail && 1'b0) begin\n          // a miss has completed", "completed misses are never replayed (deadlock)"),
 ("M3",  C+"sf_llc_cache.sv", "if (NB && inst_any && !tag_rd_en && !tag_wr_en && !touch_en) begin", "if (NB && inst_any) begin", "installer ignores tag / replacement port conflicts"),
 ("M4",  C+"sf_llc_cache.sv", "      touch_en     = 1'b1;\n      touch_set    = ms_set_o[inst_id*IDX_W +: IDX_W];", "      touch_en     = 1'b0;\n      touch_set    = ms_set_o[inst_id*IDX_W +: IDX_W];", "installer does not update the replacement state"),
 ("M5",  C+"sf_llc_cache.sv", "if (NB && rsp_load)  roq_rsp_q[roq_idx_q] <= rsp_d;", "if (NB && rsp_load)  roq_rsp_q[roq_head_q] <= rsp_d;", "response written to the wrong order-queue slot"),
 ("M6",  C+"sf_llc_cache.sv", "state_d     = ms_err_q[rid_sel] ? S_RERR : S_HIT;", "state_d     = S_HIT;", "failed miss replayed as a hit"),
 ("M7",  C+"sf_llc_cache.sv", "    if (NB && rf_done && rf_err) ms_estat_q[rf_done_id] <= rf_status;", "", "refill error status not recorded in the MSHR"),
 ("M8",  C+"sf_llc_cache.sv", "    rf_grant = !(da_rd_en || fe_wr);", "    rf_grant = 1'b1;", "refill beats not held off while the front end uses the data array"),
 ("M10", C+"sf_llc_cache.sv", "wire  logic              roq_room = (roq_cnt_q != ROQC_W'(ROQ_N));", "wire  logic              roq_room = 1'b1;", "response-order queue overflow not prevented"),
 ("M11", C+"sf_llc_cache.sv", "ms_free_id   = (NB && replay_q) ? rid_q : mid_q;", "ms_free_id   = mid_q;", "wrong MSHR freed after a replay"),
 ("M12", C+"sf_llc_cache.sv", "      ms_roq_q[mid_q]  <= roq_idx_q;", "      ms_roq_q[mid_q]  <= '0;", "parked request loses its response-queue slot"),
 ("M13", C+"sf_cache_refill.sv", "          cpl_ptr_q  <= inc(cpl_ptr_q);", "          cpl_ptr_q  <= cpl_ptr_q;", "refill completions not advanced to the next descriptor"),
 ("M14", C+"sf_cache_refill.sv", "if (iss_last) begin iss_beat_q <= '0; iss_ptr_q <= inc(iss_ptr_q); end", "if (iss_last) begin iss_beat_q <= '0; end", "refill issue pointer not advanced (same line re-issued)"),
 ("M15", C+"sf_cache_mshr.sv", "      if (v_q[i] && set_q[i] == look_set_i) sb = 1'b1;\n", "", "MSHR table ignores set ownership"),
 ("M17", C+"sf_llc_cache.sv", "          ms_err_q[rf_done_id]  <= 1'b1;\n          ms_done_q[rf_done_id] <= 1'b1;", "          ms_err_q[rf_done_id]  <= 1'b1;\n          ms_done_q[rf_done_id] <= 1'b1;\n          inst_pend_q[rf_done_id] <= 1'b1;", "failed refill still installed"),
 ("M18", C+"sf_llc_cache.sv", "((state_q == S_IDLE) && roq_room && !replay_avail && !park_valid_q)", "((state_q == S_IDLE) && roq_room && !replay_avail)", "new request accepted while one is parked"),
 ("M19", C+"sf_llc_cache.sv", "assign cmo_ready_o = (state_q == S_IDLE) && no_work && !req_valid_i;", "assign cmo_ready_o = (state_q == S_IDLE) && !req_valid_i;", "CMO starts while misses are still outstanding"),
 ("M20", C+"sf_llc_cache.sv", "          way_d       = ms_way_o[rid_sel*WAY_W +: WAY_W];", "          way_d       = '0;", "replay uses the wrong way"),
 ("M21", C+"sf_llc_cache.sv", "            roq_idx_d   = park_roq_q;", "            roq_idx_d   = roq_tail_q;", "parked request loses its response-queue slot on reload"),
]

# ECC / error-policy mutants, killed by tb_sf_llc_ecc (directed fault-injection bench)
ECC_MUTANTS = [
 ("X1",  C+"sf_llc_cache.sv", "state_d   = (ECC_SCRUB && da_rd_ce) ? S_DSCRUB : S_IDLE;", "state_d   = S_IDLE;", "data scrub after a corrected error disabled"),
 ("X2",  C+"sf_llc_cache.sv", "if (!hit_dirty_q && !refetched_q) begin\n              // clean line", "if (1'b0) begin\n              // clean line", "clean-line uncorrectable error not refetched"),
 ("X3",  C+"sf_llc_cache.sv", "      S_RDW: begin\n        if (da_rd_vld) begin\n          if (da_rd_ue) begin", "      S_RDW: begin\n        if (da_rd_vld) begin\n          if (da_rd_ue && !is_wr_q) begin", "poison laundered: partial write merges uncorrectable data"),
 ("X4",  C+"sf_cache_writeback.sv", "            if (da_rd_ue_i) begin\n              // uncorrectable: skip this beat, move on", "            if (da_rd_ue_i && 1'b0) begin\n              // uncorrectable: skip this beat, move on", "corrupt beat written back to memory"),
 ("X5",  C+"sf_llc_cache.sv", "state_d = (ECC_SCRUB && (|tag_rd_ce)) ? S_SCRUBT : S_CMP;", "state_d = S_CMP;", "tag scrub disabled"),
 ("X6",  C+"sf_llc_cache.sv", "rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b0, corr_q | da_rd_ce, da_rd_data & lane_mask(req_q.be));", "rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b0, 1'b0, da_rd_data & lane_mask(req_q.be));", "corrected flag not reported"),
 ("X7",  C+"sf_llc_cache.sv", "if (!hit_dirty_q && !refetched_q) begin\n              // clean line", "if (!hit_dirty_q) begin\n              // clean line", "persistent uncorrectable error refetched forever (livelock)"),
 ("X8",  C+"sf_llc_cache.sv", "rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_ECC_UNCORR, is_wr_q, corr_q, 128'd0);", "rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, is_wr_q, corr_q, 128'd0);", "uncorrectable error answered OKAY"),
 ("X9",  C+"sf_llc_cache.sv", "    .MEMORY_TECH(MEMORY_TECH), .MACRO_ID(MACRO_ID_DATA)\n  ) u_data (", "    .MEMORY_TECH(MEMORY_TECH), .MACRO_ID(MACRO_ID_DATA)\n  ) u_data (", "(no-op control mutant: must SURVIVE)"),
 ("X10", C+"sf_llc_cache.sv", "  sf_cache_data_array #(\n    .SETS(SETS), .WAYS(WAYS), .BEATS(BEATS), .RAM_LATENCY(RAM_LATENCY), .ECC_EN(ECC_EN),", "  sf_cache_data_array #(\n    .SETS(SETS), .WAYS(WAYS), .BEATS(BEATS), .RAM_LATENCY(RAM_LATENCY), .ECC_EN(1'b0),", "data array built without ECC"),
 ("X11", C+"sf_cache_tag_array.sv", "assign rd_valid_o[w] = ent_w[w][0] & ~unc_w[w];", "assign rd_valid_o[w] = ent_w[w][0];", "uncorrectable tag entry still trusted as valid"),
 ("X12", C+"sf_llc_cache.sv", "      ev[sf_cache_pkg::EV_DIRTY_LOST]       = 1'b1;\n      err_evt[sf_cache_pkg::ERR_DIRTY_LOST] = 1'b1;", "      ev[sf_cache_pkg::EV_DIRTY_LOST]       = 1'b1;", "dirty-data loss not reported as an error event"),
]

def copy_tree(dst):
    if os.path.exists(dst):
        shutil.rmtree(dst)
    os.makedirs(dst)
    for d in ("rtl", "tb", "third_party", "scripts", "model"):
        shutil.copytree(os.path.join(ROOT, d), os.path.join(dst, d), ignore=shutil.ignore_patterns("__pycache__", "sim_build"))

def run_mutant(args):
    mid, f, old, new, desc, work, configs, seeds, count, jobs = args
    mdir = os.path.join(work, mid)
    copy_tree(mdir)
    suite = os.environ.get("MUT_SUITE", "blocking")
    p = os.path.join(mdir, f)
    s = open(p).read()
    if s.count(old) != 1:
        return dict(id=mid, desc=desc, status="INVALID", detail=f"pattern occurs {s.count(old)} times in {f}")
    open(p, "w").write(s.replace(old, new))
    t0 = time.time()
    if suite == "ecc":
        env = dict(os.environ)
        b = subprocess.run([os.path.join(mdir, "scripts/build_tb.sh"), os.path.join(mdir, "sim_build/ecc")], cwd=mdir, env=dict(env, TOP="tb_sf_llc_ecc", TBFILES="tb/tb_sf_llc_ecc.sv", VJOBS="2"), capture_output=True, text=True)
        simp = os.path.join(mdir, "sim_build/ecc/sim")
        if b.returncode != 0 or not os.path.exists(simp):
            res = dict(id=mid, desc=desc, status="KILLED", detail="build/elaboration rejected the mutant", secs=round(time.time() - t0))
        else:
            try:
                r = subprocess.run([simp], capture_output=True, text=True, timeout=600)
                out = r.stdout + r.stderr
                ok = bool(re.search(r"TB PASS", out)) and r.returncode == 0
                first = next((l for l in out.splitlines() if "ERROR" in l or "FAIL" in l or "%Error" in l), "")
            except subprocess.TimeoutExpired:
                ok, first = False, "timeout (livelock)"
            res = dict(id=mid, desc=desc, status="SURVIVED" if ok else "KILLED", detail=("all directed tests passed" if ok else first[:130]), secs=round(time.time() - t0))
        shutil.rmtree(mdir, ignore_errors=True)
        return res
    r = subprocess.run([sys.executable, "-I", os.path.join(mdir, "scripts/run_regression.py"), "--configs", configs, "--seeds", str(seeds),
                        "--count", str(count), "--jobs", str(jobs), "--out", os.path.join(mdir, "sim_build/regression")],
                       capture_output=True, text=True, cwd=mdir, env=dict(os.environ))
    out = r.stdout + r.stderr
    m = re.search(r"(\d+)/(\d+) runs passed", out)
    if m is None:
        status, detail = "KILLED", "build/elaboration rejected the mutant: " + out.strip().splitlines()[-1][:120] if out.strip() else "no output"
    elif m.group(1) == m.group(2):
        status, detail = "SURVIVED", f"{m.group(1)}/{m.group(2)} runs passed"
    else:
        first = next((l for l in out.splitlines() if l.startswith("FAIL")), "")
        status, detail = "KILLED", f"{int(m.group(2)) - int(m.group(1))}/{m.group(2)} runs failed; first: {first[:100]}"
    shutil.rmtree(mdir, ignore_errors=True)
    return dict(id=mid, desc=desc, status=status, detail=detail, secs=round(time.time() - t0))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--inner-jobs", type=int, default=2)
    ap.add_argument("--only", default="")
    ap.add_argument("--configs", default="")
    ap.add_argument("--seeds", type=int, default=2)
    ap.add_argument("--count", type=int, default=300)
    ap.add_argument("--out", default="")
    a = ap.parse_args()
    if not a.configs:
        a.configs = "I_mshr2,N_mshr3" if os.environ.get("MUT_SUITE") == "nb" else "A_default,B_rr_small"
    if not a.out:
        a.out = os.path.join(ROOT, {"ecc": "reports/mutation_ecc.md", "nb": "reports/mutation_mshr.md"}.get(os.environ.get("MUT_SUITE", ""), "reports/mutation_blocking.md"))
    work = os.path.join(ROOT, "sim_build/mut")
    os.makedirs(work, exist_ok=True)
    suite = os.environ.get("MUT_SUITE", "blocking")
    pool = {"ecc": ECC_MUTANTS, "nb": NB_MUTANTS}.get(suite, MUTANTS)
    sel = [m for m in pool if not a.only or m[0] in a.only.split(",")]
    jobs = [(m[0], m[1], m[2], m[3], m[4], work, a.configs, a.seeds, a.count, a.inner_jobs) for m in sel]
    res = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(run_mutant, jobs):
            res.append(r)
            print(f"{r['status']:9s} {r['id']:4s} {r['desc']}  [{r['detail']}]", flush=True)
    killed = sum(r["status"] == "KILLED" for r in res)
    surv = [r for r in res if r["status"] == "SURVIVED"]
    inval = [r for r in res if r["status"] == "INVALID"]
    print(f"\n{killed}/{len(res)} mutants killed, {len(surv)} survived, {len(inval)} invalid")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w") as f:
        f.write(f"# Mutation campaign (model-vs-RTL regression)\n\nConfigurations: {a.configs}; scenarios: all; seeds: {a.seeds}; count: {a.count}.\n\n")
        f.write(f"**{killed} / {len(res)} mutants killed**, {len(surv)} survived, {len(inval)} invalid.\n\n| id | status | defect injected | evidence |\n|---|---|---|---|\n")
        for r in res:
            f.write(f"| {r['id']} | {r['status']} | {r['desc']} | {r['detail']} |\n")
    return 1 if (surv or inval) else 0

if __name__ == "__main__":
    sys.exit(main())
