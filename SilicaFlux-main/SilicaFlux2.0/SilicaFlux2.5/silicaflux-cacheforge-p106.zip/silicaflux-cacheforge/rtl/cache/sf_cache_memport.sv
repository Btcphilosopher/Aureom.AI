// =============================================================================
//  sf_cache_memport.sv  --  CacheForge memory-side ALP v1 initiator port
// -----------------------------------------------------------------------------
//  Merges the memory requests of the three clients (writeback engine, refill
//  engine, bypass access; sf_cache_pkg::MC_*) onto ONE Albion Link Protocol v1
//  initiator link and routes the in-order responses back to the client that
//  issued each request.
//
//  ALP obligations realised here (rule ids from AlbionCore ARCHITECTURE_CONTRACT):
//   ALP-REQ-02  mreq is a registered stage: valid and payload are held until accepted.
//   ALP-REQ-03  no ready output depends combinationally on a valid input of the
//               opposite channel (mrsp_ready_o depends on registered queue state and
//               on the clients' completion-ready, never on mrsp_valid_i).
//   ALP-OUT-01  at most MEM_MAX_OUT requests are outstanding (counted from the moment
//               a request is loaded into the output register, i.e. conservatively).
//   ALP-TAG-01  the tag of a request is its slot in the order queue; outstanding
//               requests occupy distinct slots, so tags are unique.
//   ALP-ORD-01  the target answers in order; the order queue gives the client of each
//               response and the tag it must carry (checked: proto_err_o).
//   ALP-RSP-06  responses are accepted independently of request progress.
//
//  Client protocol: c_valid_i[k] with c_req_i[k] held stable until c_ready_o[k]
//  (one transfer).  Completions: c_cpl_valid_o[k] with the shared payload c_cpl_o
//  until c_cpl_ready_i[k].  Priority between simultaneous clients: lowest index.
//  The tag field of c_req_i is ignored (overwritten by the slot number).
// =============================================================================
`default_nettype none

module sf_cache_memport #(
  parameter int unsigned MEM_MAX_OUT = 4,
  localparam int unsigned NC     = sf_cache_pkg::MC_NUM,
  localparam int unsigned REQ_W  = sf_albion_pkg::SF_REQ_W,
  localparam int unsigned Q_W    = (MEM_MAX_OUT > 1) ? $clog2(MEM_MAX_OUT) : 1,
  localparam int unsigned CNT_W  = $clog2(MEM_MAX_OUT + 1)
) (
  input  wire logic                       clk_i,
  input  wire logic                       rst_ni,
  // clients
  input  wire logic [NC-1:0]              c_valid_i,
  output logic [NC-1:0]                   c_ready_o,
  input  wire logic [NC*REQ_W-1:0]        c_req_i,
  output logic [NC-1:0]                   c_cpl_valid_o,
  input  wire logic [NC-1:0]              c_cpl_ready_i,
  output sf_albion_pkg::sf_rsp_t          c_cpl_o,
  // memory link (ALP v1 initiator)
  output logic                            mreq_valid_o,
  input  wire logic                       mreq_ready_i,
  output sf_albion_pkg::sf_req_t          mreq_o,
  input  wire logic                       mrsp_valid_i,
  output logic                            mrsp_ready_o,
  input  sf_albion_pkg::sf_rsp_t          mrsp_i,
  // observation
  output logic [CNT_W-1:0]                outstanding_o,
  output logic [7:0]                      ld_tag_o,       // tag assigned to the request loaded this cycle
  output logic                            acc_rd_o,
  output logic                            acc_wr_o,
  output logic                            proto_err_o
);
  if (MEM_MAX_OUT < 1 || MEM_MAX_OUT > 16) begin : g_chk
    $error("sf_cache_memport: MEM_MAX_OUT must be 1..16");
  end

  // ------------------------------------------------------------- order queue
  logic [1:0]       ord_client [MEM_MAX_OUT];
  logic [Q_W-1:0]   head_q, tail_q;
  logic [CNT_W-1:0] cnt_q;

  function automatic logic [Q_W-1:0] inc(input logic [Q_W-1:0] p);
    inc = (p == Q_W'(MEM_MAX_OUT - 1)) ? '0 : p + 1'b1;
  endfunction

  // ------------------------------------------------------------- request side
  logic                         v_q;
  sf_albion_pkg::sf_req_t       r_q;

  wire logic full  = (cnt_q == CNT_W'(MEM_MAX_OUT));
  wire logic can_ld = (!v_q || mreq_ready_i) && !full;

  logic [NC-1:0] grant;
  always_comb begin
    grant = '0;
    for (int k = NC - 1; k >= 0; k--) begin
      if (c_valid_i[k]) begin
        grant = '0;
        grant[k] = 1'b1;
      end
    end
  end
  assign c_ready_o = grant & {NC{can_ld}};
  wire logic ld = can_ld && (|(grant & c_valid_i));

  sf_albion_pkg::sf_req_t sel_req;
  logic [1:0]             sel_id;
  always_comb begin
    sel_req = '0;
    sel_id  = 2'd0;
    for (int k = 0; k < NC; k++) begin
      if (grant[k]) begin
        sel_req = c_req_i[k*REQ_W +: REQ_W];
        sel_id  = 2'(k);
      end
    end
    sel_req.tag = 8'(tail_q);
  end

  // ------------------------------------------------------------- response side
  wire logic [1:0] head_client = ord_client[head_q];
  wire logic       q_nonempty  = (cnt_q != '0);

  always_comb begin
    c_cpl_valid_o = '0;
    for (int k = 0; k < NC; k++) begin
      c_cpl_valid_o[k] = mrsp_valid_i && q_nonempty && (head_client == 2'(k));
    end
  end
  assign c_cpl_o      = mrsp_i;
  assign mrsp_ready_o = q_nonempty && c_cpl_ready_i[head_client];
  wire logic rsp_fire = mrsp_valid_i && mrsp_ready_o;

  // ------------------------------------------------------------- state
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      v_q    <= 1'b0;
      head_q <= '0;
      tail_q <= '0;
      cnt_q  <= '0;
    end else begin
      if (ld) begin
        v_q    <= 1'b1;
        tail_q <= inc(tail_q);
      end else if (v_q && mreq_ready_i) begin
        v_q    <= 1'b0;
      end
      if (rsp_fire) head_q <= inc(head_q);
      case ({ld, rsp_fire})
        2'b10:   cnt_q <= cnt_q + 1'b1;
        2'b01:   cnt_q <= cnt_q - 1'b1;
        default: cnt_q <= cnt_q;
      endcase
    end
  end

  // payload registers (not reset: only meaningful with v_q)
  always_ff @(posedge clk_i) begin
    if (ld) begin
      r_q <= sel_req;
      ord_client[tail_q] <= sel_id;
    end
  end

  assign mreq_valid_o  = v_q;
  assign mreq_o        = r_q;
  assign outstanding_o = cnt_q;
  assign ld_tag_o      = 8'(tail_q);
  assign acc_rd_o      = v_q && mreq_ready_i && (r_q.op == sf_albion_pkg::SF_OP_READ);
  assign acc_wr_o      = v_q && mreq_ready_i && (r_q.op == sf_albion_pkg::SF_OP_WRITE);
  assign proto_err_o   = mrsp_valid_i && (!q_nonempty || (rsp_fire && (mrsp_i.tag != 8'(head_q))));
endmodule

`default_nettype wire
