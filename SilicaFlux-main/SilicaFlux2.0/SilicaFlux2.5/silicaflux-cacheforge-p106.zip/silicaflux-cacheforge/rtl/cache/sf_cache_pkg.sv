// =============================================================================
//  sf_cache_pkg.sv  --  CacheForge (Project 106) common constants
// -----------------------------------------------------------------------------
//  Aureom.AI | SilicaFlux Cloud Semiconductor Systems
//  Role      : maintenance opcodes, performance-event indices, error-event
//              indices and the pure address-slicing helper used by tests.
//              Geometry-dependent widths are computed by each module from its
//              own parameters (no parameterised functions live here), so every
//              module elaborates in Verilator and Yosys without surprises.
//  Rules     : follows the AlbionCore tool rules (docs/albion/NAMING_RULES.md):
//              no wildcard import - consumers write sf_cache_pkg::NAME.
//  Claims    : none about timing, area or power.
// =============================================================================
`default_nettype none

/* verilator lint_off UNUSEDPARAM */
package sf_cache_pkg;

  // ---------------------------------------------------------------- CMO opcodes
  localparam logic [1:0] CMO_NONE      = 2'd0;
  localparam logic [1:0] CMO_CLEAN     = 2'd1;   // write back dirty lines, keep valid
  localparam logic [1:0] CMO_INVAL     = 2'd2;   // drop lines, dirty data DISCARDED
  localparam logic [1:0] CMO_CLEAN_INV = 2'd3;   // write back dirty lines, then drop

  // ---------------------------------------------------------------- replacement
  localparam int unsigned REPL_RR   = 0;         // per-set round-robin counter
  localparam int unsigned REPL_PLRU = 1;         // tree pseudo-LRU

  // ---------------------------------------------------------------- memory-side client ids
  localparam int unsigned MC_WB     = 0;         // writeback engine
  localparam int unsigned MC_REFILL = 1;         // refill engine
  localparam int unsigned MC_BYPASS = 2;         // uncached / bypass access
  localparam int unsigned MC_NUM    = 3;

  // ---------------------------------------------------------------- performance events
  //  One pulse per event on the ev_i vector of sf_cache_perf.
  localparam int unsigned EV_RD_HIT        = 0;
  localparam int unsigned EV_RD_MISS       = 1;
  localparam int unsigned EV_WR_HIT        = 2;
  localparam int unsigned EV_WR_MISS       = 3;
  localparam int unsigned EV_REFILL        = 4;  // line installed
  localparam int unsigned EV_EVICT         = 5;  // valid victim replaced
  localparam int unsigned EV_WRITEBACK     = 6;  // dirty line written back (replacement or CMO)
  localparam int unsigned EV_MEM_RD_BEAT   = 7;  // memory-side READ request accepted
  localparam int unsigned EV_MEM_WR_BEAT   = 8;  // memory-side WRITE request accepted
  localparam int unsigned EV_BYPASS_RD     = 9;
  localparam int unsigned EV_BYPASS_WR     = 10;
  localparam int unsigned EV_CMO_LINE      = 11;
  localparam int unsigned EV_CMO_DISCARD   = 12; // dirty line dropped by INVAL
  localparam int unsigned EV_ERR_RSP       = 13; // response with status != OKAY
  localparam int unsigned EV_REFILL_ERR    = 14;
  localparam int unsigned EV_WB_ERR        = 15;
  localparam int unsigned EV_TAG_CE        = 16;
  localparam int unsigned EV_TAG_UE        = 17;
  localparam int unsigned EV_DATA_CE       = 18;
  localparam int unsigned EV_DATA_UE       = 19; // uncorrectable data error seen on a read of a resident line
  localparam int unsigned EV_DIRTY_LOST    = 20; // dirty beat dropped at writeback (uncorrectable)
  localparam int unsigned EV_STALL         = 21; // req_valid && !req_ready
  localparam int unsigned EV_BUSY          = 22; // cache not idle
  localparam int unsigned EV_PARK          = 23;  // request parked (set owned by an MSHR / table full)
  localparam int unsigned EV_NUM           = 24;

  // ---------------------------------------------------------------- error-event bus (err_evt_o)
  localparam int unsigned ERR_TAG_CE       = 0;
  localparam int unsigned ERR_TAG_UE       = 1;
  localparam int unsigned ERR_DATA_CE      = 2;
  localparam int unsigned ERR_DATA_UE_CLEAN= 3;  // clean line: invalidated and refetched (transparent)
  localparam int unsigned ERR_DATA_UE_POIS = 4;  // poisoned response returned to the requester
  localparam int unsigned ERR_DIRTY_LOST   = 5;  // dirty data lost (writeback beat uncorrectable)
  localparam int unsigned ERR_WB           = 6;  // memory rejected a writeback (line retained)
  localparam int unsigned ERR_REFILL       = 7;  // memory rejected a refill (no allocation)
  localparam int unsigned ERR_NUM          = 8;

  // ---------------------------------------------------------------- performance counter ids (sf_cache_perf outputs)
  //  The counter array is  EV_NUM event counters followed by 4 latency registers.
  localparam int unsigned PERF_N_EVENT     = EV_NUM;
  localparam int unsigned PERF_LAT_SUM     = EV_NUM;      // sum of miss latencies (cycles)
  localparam int unsigned PERF_LAT_MAX     = EV_NUM + 1;  // largest miss latency
  localparam int unsigned PERF_LAT_CNT     = EV_NUM + 2;  // number of latency samples
  localparam int unsigned PERF_LAT_MIN     = EV_NUM + 3;  // smallest miss latency (all-ones until first sample)
  localparam int unsigned PERF_N_TOTAL     = EV_NUM + 4;

  // ---------------------------------------------------------------- address slicing (reference function for tests)
  //  Returns {tag, set, offset} packed MSB..LSB for a 64-bit address.  Pure bit
  //  slicing, valid for power-of-two geometries (checked by the callers).
  function automatic logic [63:0] sf_cache_line_base(input logic [63:0] addr, input int unsigned off_w);
    logic [63:0] m;
    begin
      m = ~((64'd1 << off_w) - 64'd1);
      sf_cache_line_base = addr & m;
    end
  endfunction

endpackage
/* verilator lint_on UNUSEDPARAM */

`default_nettype wire
