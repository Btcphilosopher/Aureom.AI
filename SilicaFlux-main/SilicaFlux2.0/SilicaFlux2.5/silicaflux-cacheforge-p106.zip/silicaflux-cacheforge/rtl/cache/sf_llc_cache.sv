// =============================================================================
//  sf_llc_cache.sv  --  CacheForge (Project 106): last-level cache controller
// -----------------------------------------------------------------------------
//  Aureom.AI | SilicaFlux Cloud Semiconductor Systems          PRIMARY RTL
//
//  A synthesizable, configurable, set-associative, write-back / write-allocate
//  last-level cache for SilicaFlux cloud processors.  BOTH interfaces are
//  Albion Link Protocol v1 (AlbionCore 0.1.0, sf_albion_pkg): 64-bit address,
//  128-bit data, 16-bit byte enables, 8-bit tag, single beat, in-order, non-posted
//  writes.  A 64-byte line therefore moves as 4 beats.
//
//        initiator  --(ALP v1)-->  [ req | rsp ]  sf_llc_cache  [ mreq | mrsp ]  --(ALP v1)-->  DataFabric / memory
//                                       cmo / cfg / status / perf  (side ports)
//
//  THIS REVISION: the BLOCKING cache (one outstanding miss, NUM_MSHR = 1).  The
//  functional behaviour is specified in docs/02_functional_spec.md, the micro-
//  architecture in docs/03_microarchitecture.md.  Highlights
//   * hit / miss / refill / eviction / writeback with dirty tracking, byte-enable
//     writes (read-modify-write inside the cache), full-beat writes,
//   * tree-PLRU or round-robin replacement, invalid ways first,
//   * SECDED on every tag entry (valid+dirty+tag) and on every 64-bit data lane,
//     with documented policies for corrected / uncorrectable / dirty / refill
//     errors (docs/04_ecc_and_errors.md),
//   * uncached (bypass) path for non-cacheable / device accesses and an optional
//     non-cacheable window,
//   * software-managed visibility for DMA: CLEAN / INVAL / CLEAN_INVAL maintenance
//     port.  NOT hardware-coherent: no snooping, no coherence claim,
//   * performance counters (sf_cache_perf), error log, capability word.
//
//  Ports (summary; full table in docs/05_integration.md)
//   req/rsp      upstream ALP target link          mreq/mrsp   downstream ALP initiator link
//   cmo_*        maintenance command port          cfg_*       static configuration
//   err_*, perf_*, caps_o, init_done_o, busy_o     status
//
//  Reset: active-low rst_ni, asynchronous assertion, synchronous release (supplied
//  by the platform, ALP-RST-*).  After reset the tag array is initialised by a
//  SETS-cycle walk; req_ready_o stays low until init_done_o.  Reset abandons any
//  outstanding transaction (ALP-RST-02); a write accepted before reset may or may
//  not have reached memory.
// =============================================================================
`default_nettype none

module sf_llc_cache #(
  parameter int unsigned CACHE_BYTES   = 32768,
  parameter int unsigned LINE_BYTES    = 64,
  parameter int unsigned WAYS          = 4,
  parameter int unsigned PADDR_W       = 64,
  parameter int unsigned NUM_MSHR      = 1,       // 1 = blocking cache (this revision)
  parameter int unsigned REPL_POLICY   = 1,       // 0 round-robin, 1 tree-PLRU
  parameter int unsigned RAM_LATENCY   = 1,       // read latency of the tag / data RAMs (1..4)
  parameter int unsigned MEM_MAX_OUT   = 4,       // outstanding requests allowed on the memory link (1..16)
  parameter bit          ECC_EN        = 1'b1,
  parameter bit          ECC_SCRUB     = 1'b1,    // write corrected entries back after a correctable error
  parameter int unsigned MEMORY_TECH   = 0,       // sf_sram_macro_defs.svh: 0 GENERIC, 1 FPGA, 10.. ASIC
  parameter int unsigned MACRO_ID_DATA = 0,
  parameter int unsigned MACRO_ID_TAG  = 0,
  parameter int unsigned CNT_W         = 64,
  // ---- derived (do not override)
  localparam int unsigned SETS   = CACHE_BYTES / (LINE_BYTES * WAYS),
  localparam int unsigned BEATS  = LINE_BYTES / 16,
  localparam int unsigned OFF_W  = $clog2(LINE_BYTES),
  localparam int unsigned IDX_W  = (SETS > 1) ? $clog2(SETS) : 1,
  localparam int unsigned TAG_W  = PADDR_W - OFF_W - IDX_W,
  localparam int unsigned WAY_W  = (WAYS > 1) ? $clog2(WAYS) : 1,
  localparam int unsigned BEAT_W = (BEATS > 1) ? $clog2(BEATS) : 1,
  localparam int unsigned NERR   = sf_cache_pkg::ERR_NUM,
  localparam int unsigned NEV    = sf_cache_pkg::EV_NUM,
  localparam int unsigned NPERF  = sf_cache_pkg::PERF_N_TOTAL,
  localparam int unsigned REQ_W  = sf_albion_pkg::SF_REQ_W
) (
  input  wire logic                         clk_i,
  input  wire logic                         rst_ni,
  // ---- upstream ALP v1 target link
  input  wire logic                         req_valid_i,
  output logic                              req_ready_o,
  input  sf_albion_pkg::sf_req_t            req_i,
  output logic                              rsp_valid_o,
  input  wire logic                         rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t            rsp_o,
  // ---- downstream ALP v1 initiator link
  output logic                              mreq_valid_o,
  input  wire logic                         mreq_ready_i,
  output sf_albion_pkg::sf_req_t            mreq_o,
  input  wire logic                         mrsp_valid_i,
  output logic                              mrsp_ready_o,
  input  sf_albion_pkg::sf_rsp_t            mrsp_i,
  // ---- maintenance (software-managed visibility)
  input  wire logic                         cmo_valid_i,
  output logic                              cmo_ready_o,
  input  wire logic [1:0]                   cmo_op_i,       // sf_cache_pkg::CMO_*
  input  wire logic                         cmo_all_i,
  input  wire logic [63:0]                  cmo_addr_i,
  input  wire logic [63:0]                  cmo_size_i,
  output logic                              cmo_busy_o,
  output logic                              cmo_done_o,     // 1-cycle pulse
  output logic [31:0]                       cmo_lines_o,    // valid with / after cmo_done_o
  output logic                              cmo_err_o,
  // ---- static configuration (change only while the cache is idle)
  input  wire logic                         cfg_en_i,       // 0: every access is uncached
  input  wire logic                         cfg_nc_en_i,    // non-cacheable window enable
  input  wire logic [63:0]                  cfg_nc_base_i,
  input  wire logic [63:0]                  cfg_nc_limit_i, // [base, limit)
  input  wire logic [7:0]                   cfg_wb_dom_i,   // domain / attributes used for writebacks
  input  wire logic [7:0]                   cfg_wb_attr_i,
  // ---- status
  output logic                              init_done_o,
  output logic                              busy_o,
  output logic [NERR-1:0]                   err_evt_o,      // 1-cycle pulses
  output logic [NERR-1:0]                   err_sticky_o,
  input  wire logic                         err_clear_i,
  output logic [63:0]                       err_addr_o,     // address of the last error event
  input  wire logic                         perf_clear_i,
  output logic [NPERF*CNT_W-1:0]            perf_o,
  output logic [63:0]                       caps_o,         // sf_albion_pkg::sf_caps_t
  output logic                              proto_err_o     // memory link protocol violation (tag / unexpected response)
);
  // ===========================================================================
  // Elaboration-time rejection of unsupported configurations
  // ===========================================================================
  function automatic bit is_pow2(input int unsigned v);
    is_pow2 = (v != 0) && ((v & (v - 1)) == 0);
  endfunction

  if (!is_pow2(LINE_BYTES) || LINE_BYTES < 16 || LINE_BYTES > 256) begin : g_e_line
    $error("sf_llc_cache: LINE_BYTES must be a power of two in 16..256");
  end
  if (!is_pow2(WAYS) || WAYS > 16) begin : g_e_ways
    $error("sf_llc_cache: WAYS must be a power of two in 1..16");
  end
  if (!is_pow2(CACHE_BYTES)) begin : g_e_cap
    $error("sf_llc_cache: CACHE_BYTES must be a power of two");
  end
  if (CACHE_BYTES < 2 * LINE_BYTES * WAYS) begin : g_e_sets
    $error("sf_llc_cache: CACHE_BYTES must give at least 2 sets (CACHE_BYTES >= 2*LINE_BYTES*WAYS)");
  end
  if (PADDR_W < 32 || PADDR_W > 64) begin : g_e_pa
    $error("sf_llc_cache: PADDR_W must be 32..64");
  end
  if (PADDR_W <= OFF_W + IDX_W) begin : g_e_tag
    $error("sf_llc_cache: PADDR_W too small: the tag would be empty");
  end
  if (NUM_MSHR < 1 || NUM_MSHR > 8) begin : g_e_mshr
    $error("sf_llc_cache: NUM_MSHR must be 1..8 (1 = blocking cache)");
  end
  if (REPL_POLICY > 1) begin : g_e_repl
    $error("sf_llc_cache: REPL_POLICY must be 0 (round-robin) or 1 (tree PLRU)");
  end
  if (RAM_LATENCY < 1 || RAM_LATENCY > 4) begin : g_e_lat
    $error("sf_llc_cache: RAM_LATENCY must be 1..4");
  end
  if (MEM_MAX_OUT < 1 || MEM_MAX_OUT > 16) begin : g_e_mo
    $error("sf_llc_cache: MEM_MAX_OUT must be 1..16");
  end
  if (CNT_W < 32 || CNT_W > 64) begin : g_e_cnt
    $error("sf_llc_cache: CNT_W must be 32..64");
  end

  // ===========================================================================
  // Non-blocking (MSHR) configuration constants
  //   NUM_MSHR = 1 : blocking cache.  NUM_MSHR > 1 : up to NUM_MSHR outstanding misses, hit-under-miss,
  //   responses returned in request order through a response-order queue of ROQ_N entries.
  // ===========================================================================
  localparam bit          NB     = (NUM_MSHR > 1);
  localparam int unsigned ID_W   = (NUM_MSHR > 1) ? $clog2(NUM_MSHR) : 1;
  localparam int unsigned ROQ_N  = NB ? 2 * NUM_MSHR : 1;
  localparam int unsigned ROQ_W  = (ROQ_N > 1) ? $clog2(ROQ_N) : 1;
  localparam int unsigned ROQC_W = $clog2(ROQ_N + 1);

  // ===========================================================================
  // State encoding
  // ===========================================================================
  typedef enum logic [4:0] {
    S_INIT, S_IDLE, S_DECODE, S_TAG, S_SCRUBT, S_CMP, S_MISS, S_WB, S_EVICT, S_RFS, S_RFW,
    S_INSTALL, S_HIT, S_RDW, S_WRITE, S_WDIRTY, S_DSCRUB, S_UEINV, S_BYP, S_BYPW,
    S_CMO_RD, S_CMO_TAG, S_CMO_CHK, S_CMO_WB, S_CMO_DONE, S_RERR
  } state_e;

  state_e                 state_q, state_d;

  // ===========================================================================
  // Request registers and decode
  // ===========================================================================
  sf_albion_pkg::sf_req_t req_q;
  wire logic [63:0]       a_q       = req_q.addr;
  logic [IDX_W-1:0]       set_q;
  logic [TAG_W-1:0]       tag_q;
  logic [BEAT_W-1:0]      beat_q;
  logic [63:0]            line_q;
  logic                   range_bad;
  logic [63:0]            vic_base, cmo_base, unused_rb;
  logic [TAG_W-1:0]       cmo_ent_tag;                // tag of the way visited by the CMO walk
  logic [TAG_W-1:0]       vic_tag_q;                  // tag of the victim line
  logic [TAG_W-1:0]       unused_t;
  logic [IDX_W-1:0]       unused_s;
  logic [BEAT_W-1:0]      unused_b;
  logic [63:0]            unused_l;
  logic                   unused_o;
  logic [IDX_W-1:0]       cmo_set_q;

  // address decomposition of the request, and two reconstruction paths (victim writeback, CMO walk)
  sf_cache_addr #(.LINE_BYTES(LINE_BYTES), .SETS(SETS), .PADDR_W(PADDR_W)) u_adr (
    .addr_i(a_q), .beat_o(beat_q), .set_o(set_q), .tag_o(tag_q), .line_o(line_q), .out_of_range_o(range_bad),
    .rtag_i(vic_tag_q), .rset_i(set_q), .rbase_o(vic_base));
  sf_cache_addr #(.LINE_BYTES(LINE_BYTES), .SETS(SETS), .PADDR_W(PADDR_W)) u_adr_cmo (
    .addr_i(64'd0), .beat_o(unused_b), .set_o(unused_s), .tag_o(unused_t), .line_o(unused_l), .out_of_range_o(unused_o),
    .rtag_i(cmo_ent_tag), .rset_i(cmo_set_q), .rbase_o(cmo_base));
  assign unused_rb = 64'd0;
  wire logic              is_wr_q   = (req_q.op == sf_albion_pkg::SF_OP_WRITE);
  wire logic              full_be_q = (req_q.be == 16'hFFFF);
  wire logic [3:0]        legal_st  = sf_albion_pkg::sf_req_check_bits(req_q);
  wire logic              nc_hit    = cfg_nc_en_i && (a_q >= cfg_nc_base_i) && (a_q < cfg_nc_limit_i);
  wire logic              cacheable = cfg_en_i && (req_q.attr[1:0] == 2'(sf_albion_pkg::SF_MEM_NORMAL_WB)) && !nc_hit;
  wire logic              go_cache  = (legal_st == sf_albion_pkg::SF_ST_OKAY) && !range_bad && cacheable;

  // ===========================================================================
  // Datapath registers
  // ===========================================================================
  logic [WAY_W-1:0]       way_q, way_d;
  logic                   hit_dirty_q, hit_dirty_d;
  logic                   replay_q, replay_d;
  logic                   refetched_q, refetched_d;
  logic                   miss_q, miss_d;
  logic                   corr_q, corr_d;
  // tag-read buffer
  logic [WAYS-1:0]        v_valid_q, v_dirty_q, v_ce_q, v_ue_q;
  logic [WAYS*TAG_W-1:0]  v_tag_q;
  logic [WAYS-1:0]        v_ce_d;
  // victim description
  logic                   vic_valid_q, vic_dirty_q, vic_valid_d, vic_dirty_d;
  logic [TAG_W-1:0]       vic_tag_d;
  // data buffers
  logic [127:0]           wdata_q, wdata_d;
  // response register
  logic                   rsp_valid_q;
  sf_albion_pkg::sf_rsp_t rsp_q;
  logic                   rsp_load;
  sf_albion_pkg::sf_rsp_t rsp_d;
  // latency: cycles since the request was accepted (cyc_q - t0_q), sampled when its response is produced
  logic [31:0]            cyc_q, t0_q, t0_d;
  wire  logic [31:0]      lat_q = cyc_q - t0_q;
  // ---- non-blocking state
  logic [ID_W-1:0]        mid_q, mid_d;          // MSHR owned by the request in the front end
  logic [ID_W-1:0]        rid_q, rid_d;          // MSHR being replayed
  logic [ROQ_W-1:0]       roq_idx_q, roq_idx_d;  // response-order-queue slot of the request in the front end
  logic [REQ_W-1:0]       ms_req_q  [NUM_MSHR];  // the request parked in each MSHR (flat vector: sf_albion_pkg::sf_req_t layout)
  logic [ROQ_W-1:0]       ms_roq_q  [NUM_MSHR];
  logic [31:0]            ms_t0_q   [NUM_MSHR];
  logic [3:0]             ms_estat_q[NUM_MSHR];  // first non-OKAY refill status
  logic [NUM_MSHR-1:0]    ms_ref_q, ms_done_q, ms_err_q, inst_pend_q;
  logic                   park_valid_q, park_load, park_clear;
  sf_albion_pkg::sf_req_t park_q;
  logic [ROQ_W-1:0]       park_roq_q;
  logic [31:0]            park_t0_q;
  logic                   ms_h_wr;               // front-end hand-off of the miss to its MSHR
  logic                   replay_go, park_reload, inst_go, fe_wr;
  logic [ID_W-1:0]        inst_id, rid_sel;
  logic                   replay_avail, inst_any;
  // init
  logic [IDX_W-1:0]       init_q, init_d;
  // sticky errors
  logic [NERR-1:0]        err_sticky_q;
  logic [63:0]            err_addr_q;
  // CMO
  logic [1:0]             cmo_op_q;
  logic                   cmo_all_q, cmo_empty_q, cmo_err_q, cmo_err_d, cmo_done_q, cmo_done_d;
  logic [63:0]            cmo_start_q;
  logic [64:0]            cmo_end_q;
  logic [IDX_W-1:0]       cmo_set_d;
  logic [WAY_W-1:0]       cmo_way_q, cmo_way_d;
  logic [31:0]            cmo_lines_q, cmo_lines_d;
  logic                   cmo_load;

  wire logic cmo_active = (state_q == S_CMO_RD) || (state_q == S_CMO_TAG) || (state_q == S_CMO_CHK) ||
                          (state_q == S_CMO_WB) || (state_q == S_CMO_DONE);

  // ===========================================================================
  // Array / engine wiring
  // ===========================================================================
  // tag array
  logic                   tag_rd_en;
  logic [IDX_W-1:0]       tag_rd_set;
  logic                   tag_rd_vld;
  logic [WAYS-1:0]        tag_rd_valid, tag_rd_dirty, tag_rd_ce, tag_rd_ue;
  logic [WAYS*TAG_W-1:0]  tag_rd_tag;
  logic                   tag_wr_en;
  logic [IDX_W-1:0]       tag_wr_set;
  logic [WAYS-1:0]        tag_wr_way;
  logic                   tag_wr_valid, tag_wr_dirty;
  logic [TAG_W-1:0]       tag_wr_tag;

  sf_cache_tag_array #(
    .SETS(SETS), .WAYS(WAYS), .TAG_W(TAG_W), .RAM_LATENCY(RAM_LATENCY), .ECC_EN(ECC_EN),
    .MEMORY_TECH(MEMORY_TECH), .MACRO_ID(MACRO_ID_TAG)
  ) u_tag (
    .clk_i(clk_i),
    .rd_en_i(tag_rd_en), .rd_set_i(tag_rd_set), .rd_vld_o(tag_rd_vld),
    .rd_valid_o(tag_rd_valid), .rd_dirty_o(tag_rd_dirty), .rd_tag_o(tag_rd_tag),
    .rd_ce_o(tag_rd_ce), .rd_ue_o(tag_rd_ue),
    .wr_en_i(tag_wr_en), .wr_set_i(tag_wr_set), .wr_way_i(tag_wr_way),
    .wr_valid_i(tag_wr_valid), .wr_dirty_i(tag_wr_dirty), .wr_tag_i(tag_wr_tag)
  );

  // data array
  logic                   da_rd_en;
  logic [WAY_W-1:0]       da_rd_way;
  logic [IDX_W-1:0]       da_rd_set;
  logic [BEAT_W-1:0]      da_rd_beat;
  logic                   da_rd_vld, da_rd_ce, da_rd_ue;
  logic [127:0]           da_rd_data;
  logic                   da_wr_en;
  logic [WAY_W-1:0]       da_wr_way;
  logic [IDX_W-1:0]       da_wr_set;
  logic [BEAT_W-1:0]      da_wr_beat;
  logic [127:0]           da_wr_data;

  sf_cache_data_array #(
    .SETS(SETS), .WAYS(WAYS), .BEATS(BEATS), .RAM_LATENCY(RAM_LATENCY), .ECC_EN(ECC_EN),
    .MEMORY_TECH(MEMORY_TECH), .MACRO_ID(MACRO_ID_DATA)
  ) u_data (
    .clk_i(clk_i),
    .rd_en_i(da_rd_en), .rd_way_i(da_rd_way), .rd_set_i(da_rd_set), .rd_beat_i(da_rd_beat),
    .rd_vld_o(da_rd_vld), .rd_data_o(da_rd_data), .rd_ce_o(da_rd_ce), .rd_ue_o(da_rd_ue),
    .wr_en_i(da_wr_en), .wr_way_i(da_wr_way), .wr_set_i(da_wr_set), .wr_beat_i(da_wr_beat),
    .wr_data_i(da_wr_data), .wr_lanes_i(2'b11)
  );

  // replacement
  logic [WAY_W-1:0]       victim_way, policy_victim;
  logic                   victim_inv;
  logic                   touch_en, touch_alloc;
  logic [WAY_W-1:0]       touch_way;
  logic [IDX_W-1:0]       touch_set;

  sf_cache_replacement #(.SETS(SETS), .WAYS(WAYS), .POLICY(REPL_POLICY)) u_repl (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .q_set_i(set_q), .q_valid_i(v_valid_q), .victim_o(victim_way),
    .victim_invalid_o(victim_inv), .policy_victim_o(policy_victim),
    .touch_en_i(touch_en), .touch_set_i(touch_set), .touch_way_i(touch_way), .touch_alloc_i(touch_alloc)
  );

  // memory port + engines
  logic [sf_cache_pkg::MC_NUM-1:0]       mc_valid, mc_ready, mc_cpl_valid, mc_cpl_ready;
  logic [sf_cache_pkg::MC_NUM*REQ_W-1:0] mc_req;
  sf_albion_pkg::sf_rsp_t                mc_cpl;
  logic [$clog2(MEM_MAX_OUT+1)-1:0]      mem_outstanding;
  logic                                  mem_acc_rd, mem_acc_wr;
  logic [7:0]                            mem_ld_tag;

  sf_cache_memport #(.MEM_MAX_OUT(MEM_MAX_OUT)) u_mem (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .c_valid_i(mc_valid), .c_ready_o(mc_ready), .c_req_i(mc_req),
    .c_cpl_valid_o(mc_cpl_valid), .c_cpl_ready_i(mc_cpl_ready), .c_cpl_o(mc_cpl),
    .mreq_valid_o(mreq_valid_o), .mreq_ready_i(mreq_ready_i), .mreq_o(mreq_o),
    .mrsp_valid_i(mrsp_valid_i), .mrsp_ready_o(mrsp_ready_o), .mrsp_i(mrsp_i),
    .outstanding_o(mem_outstanding), .ld_tag_o(mem_ld_tag), .acc_rd_o(mem_acc_rd), .acc_wr_o(mem_acc_wr), .proto_err_o(proto_err_o)
  );

  // writeback engine
  logic                   wb_start, wb_busy, wb_done, wb_err, wb_lost;
  logic [63:0]            wb_addr;
  logic [3:0]             wb_status;
  logic                   wb_rd_en;
  logic [BEAT_W-1:0]      wb_rd_beat;
  logic                   wb_m_valid;
  sf_albion_pkg::sf_req_t wb_m_req;
  logic                   wb_cpl_ready;

  sf_cache_writeback #(.BEATS(BEATS)) u_wb (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .start_i(wb_start), .line_addr_i(wb_addr), .dom_i(cfg_wb_dom_i), .attr_i(cfg_wb_attr_i),
    .busy_o(wb_busy), .done_o(wb_done), .err_o(wb_err), .status_o(wb_status), .lost_o(wb_lost),
    .da_rd_en_o(wb_rd_en), .da_rd_beat_o(wb_rd_beat),
    .da_rd_vld_i(da_rd_vld), .da_rd_data_i(da_rd_data), .da_rd_ue_i(da_rd_ue),
    .m_valid_o(wb_m_valid), .m_ready_i(mc_ready[sf_cache_pkg::MC_WB]), .m_req_o(wb_m_req),
    .m_cpl_valid_i(mc_cpl_valid[sf_cache_pkg::MC_WB]), .m_cpl_ready_o(wb_cpl_ready), .m_cpl_i(mc_cpl)
  );

  // refill engine
  logic                   rf_start, rf_busy, rf_done, rf_err, rf_full, rf_m_first, rf_grant;
  logic [3:0]             rf_status;
  logic [ID_W-1:0]        rf_m_id, rf_done_id;
  logic                   rf_m_valid;
  sf_albion_pkg::sf_req_t rf_m_req;
  logic                   rf_cpl_ready;
  logic                   rf_wr_en;
  logic [WAY_W-1:0]       rf_wr_way;
  logic [IDX_W-1:0]       rf_wr_set;
  logic [BEAT_W-1:0]      rf_wr_beat;
  logic [127:0]           rf_wr_data;

  sf_cache_refill #(.BEATS(BEATS), .DEPTH(NUM_MSHR), .SETS(SETS), .WAYS(WAYS)) u_rf (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .start_i(rf_start), .line_addr_i(line_q), .set_i(set_q), .way_i(way_q), .id_i(mid_q),
    .dom_i(req_q.dom), .attr_i(req_q.attr),
    .full_o(rf_full), .busy_o(rf_busy), .done_o(rf_done), .done_id_o(rf_done_id), .err_o(rf_err), .status_o(rf_status),
    .m_valid_o(rf_m_valid), .m_first_o(rf_m_first), .m_id_o(rf_m_id),
    .m_ready_i(mc_ready[sf_cache_pkg::MC_REFILL]), .m_req_o(rf_m_req),
    .m_cpl_valid_i(mc_cpl_valid[sf_cache_pkg::MC_REFILL]), .m_cpl_ready_o(rf_cpl_ready), .m_cpl_i(mc_cpl),
    .da_wr_grant_i(rf_grant), .da_wr_en_o(rf_wr_en), .da_wr_way_o(rf_wr_way), .da_wr_set_o(rf_wr_set),
    .da_wr_beat_o(rf_wr_beat), .da_wr_data_o(rf_wr_data)
  );

  // bypass client
  logic                   byp_valid;

  assign mc_valid = {byp_valid, rf_m_valid, wb_m_valid};
  assign mc_req   = {req_q, rf_m_req, wb_m_req};
  assign mc_cpl_ready = {(state_q == S_BYPW), rf_cpl_ready, wb_cpl_ready};

  // ---- MSHR tracker (one entry in the blocking cache; observation + invariants)
  logic                   ms_alloc_en, ms_free_en, ms_upd_en, ms_err_en, ms_mtag_en;
  logic [1:0]             ms_upd_state;
  logic                   ms_alloc_ready, ms_hit, ms_merge_ok, ms_set_busy, ms_wfull;
  logic [ID_W-1:0]        ms_alloc_id, ms_hit_id, ms_upd_id, ms_err_id, ms_free_id;
  logic [NUM_MSHR-1:0]    ms_valid, ms_err;
  logic [IDX_W-1:0]       look_set, park_set;
  logic [$clog2(NUM_MSHR+1)-1:0] ms_occ;
  logic [2*NUM_MSHR-1:0]  ms_state_o;
  logic [NUM_MSHR*WAY_W-1:0]  ms_way_o;
  logic [NUM_MSHR*IDX_W-1:0]  ms_set_o;
  logic [NUM_MSHR*8-1:0]  ms_mtag_o;
  logic [NUM_MSHR*4-1:0]  ms_estat_o;
  logic [NUM_MSHR*4-1:0]  ms_wait_o;
  logic [NUM_MSHR*64-1:0] ms_line_o;
  logic [NUM_MSHR-1:0]    ms_write_o;
  logic [NUM_MSHR*8-1:0]  ms_dom_o, ms_attr_o;

  sf_cache_mshr #(.NUM_MSHR(NUM_MSHR), .SETS(SETS), .WAYS(WAYS), .MAX_WAIT(8)) u_mshr (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .alloc_en_i(ms_alloc_en), .alloc_line_i(line_q), .alloc_set_i(set_q), .alloc_way_i((state_q == S_UEINV) ? way_q : victim_way),
    .alloc_write_i(is_wr_q), .alloc_dom_i(req_q.dom), .alloc_attr_i(req_q.attr),
    .alloc_ready_o(ms_alloc_ready), .alloc_id_o(ms_alloc_id),
    .upd_en_i(ms_upd_en), .upd_id_i(ms_upd_id), .upd_state_i(ms_upd_state),
    .mtag_en_i(ms_mtag_en), .mtag_id_i(rf_m_id), .mtag_i(mem_ld_tag),
    .err_en_i(ms_err_en), .err_id_i(ms_err_id), .err_status_i((state_q == S_WB) ? wb_status : rf_status),
    .wait_inc_i(1'b0), .wait_id_i('0),
    .free_en_i(ms_free_en), .free_id_i(ms_free_id),
    .look_line_i(line_q), .look_set_i(look_set), .look_write_i(is_wr_q), .look_dom_i(req_q.dom), .look_attr_i(req_q.attr),
    .hit_o(ms_hit), .hit_id_o(ms_hit_id), .merge_ok_o(ms_merge_ok), .set_busy_o(ms_set_busy), .waiters_full_o(ms_wfull),
    .valid_o(ms_valid), .occupancy_o(ms_occ), .err_o(ms_err), .state_o(ms_state_o), .way_o(ms_way_o),
    .set_o(ms_set_o), .mtag_o(ms_mtag_o), .estat_o(ms_estat_o), .waiters_o(ms_wait_o),
    .line_o(ms_line_o), .write_o(ms_write_o), .dom_o(ms_dom_o), .attr_o(ms_attr_o)
  );

  // ===========================================================================
  // Helper functions
  // ===========================================================================
  function automatic sf_albion_pkg::sf_rsp_t mk_rsp(input logic [7:0] tag, input logic [3:0] status,
                                                    input logic is_write, input logic corrected,
                                                    input logic [127:0] data);
    sf_albion_pkg::sf_rsp_t r;
    begin
      r        = '0;
      r.tag    = tag;
      r.status = status;
      r.meta   = {4'b0000, corrected, (status == sf_albion_pkg::SF_ST_ECC_UNCORR), 1'b1, is_write};
      r.data   = (status == sf_albion_pkg::SF_ST_OKAY && !is_write) ? data : 128'd0;
      mk_rsp   = r;
    end
  endfunction

  function automatic logic [127:0] lane_mask(input logic [15:0] be);
    logic [127:0] m;
    begin
      for (int i = 0; i < 16; i++) m[8*i +: 8] = {8{be[i]}};
      lane_mask = m;
    end
  endfunction

  // ===========================================================================
  // Combinational control
  // ===========================================================================
  logic [NEV-1:0]  ev;
  logic [NERR-1:0] err_evt;
  logic            req_load;
  logic            v_cap;
  logic            lat_valid;
  logic [WAYS-1:0] hit_vec;
  logic            hit_any;
  logic [WAY_W-1:0] hit_idx;
  logic [WAY_W-1:0] sc_way;
  logic            sc_any;
  logic [WAY_W-1:0] cw;      // CMO way as index
  logic [64:0]     cmo_line_base, cmo_line_end;
  logic            cmo_in_range, cmo_in_scope, cmo_ent_valid, cmo_ent_dirty, cmo_ent_ue;
  logic [TAG_W-1:0] sc_tag;
  logic            sc_valid, sc_dirty;
  logic [127:0]    merged;

  // ---- non-blocking helpers: park decode, installer address, replay selection, response-order queue
  logic [IDX_W-1:0]  unused_ps;
  logic [TAG_W-1:0]  inst_tag, unused_pt;
  logic [BEAT_W-1:0] unused_pb1, unused_pb2;
  logic [63:0]       unused_pl1, unused_pl2, unused_pr1, unused_pr2, unused_ir;
  logic              unused_po1, unused_po2;
  logic [IDX_W-1:0]  unused_is;
  sf_cache_addr #(.LINE_BYTES(LINE_BYTES), .SETS(SETS), .PADDR_W(PADDR_W)) u_adr_park (
    .addr_i(park_q.addr), .beat_o(unused_pb1), .set_o(park_set), .tag_o(unused_pt), .line_o(unused_pl1), .out_of_range_o(unused_po1),
    .rtag_i('0), .rset_i('0), .rbase_o(unused_pr1));
  logic [63:0] inst_addr;
  always_comb begin
    inst_addr = '0;
    for (int i = 0; i < NUM_MSHR; i++) begin
      if (inst_id == ID_W'(i)) inst_addr = ms_req_q[i][sf_albion_pkg::SF_REQ_ADDR_LSB +: 64];
    end
  end
  sf_cache_addr #(.LINE_BYTES(LINE_BYTES), .SETS(SETS), .PADDR_W(PADDR_W)) u_adr_inst (
    .addr_i(inst_addr), .beat_o(unused_pb2), .set_o(unused_is), .tag_o(inst_tag), .line_o(unused_pl2), .out_of_range_o(unused_po2),
    .rtag_i('0), .rset_i('0), .rbase_o(unused_pr2));
  assign unused_ir = 64'd0;
  assign unused_ps = '0;

  assign look_set = (NB && state_q == S_IDLE && park_valid_q) ? park_set : set_q;

  always_comb begin
    replay_avail = |ms_done_q;
    rid_sel      = '0;
    for (int i = NUM_MSHR - 1; i >= 0; i--) if (ms_done_q[i]) rid_sel = ID_W'(i);
    inst_any     = |inst_pend_q;
    inst_id      = '0;
    for (int i = NUM_MSHR - 1; i >= 0; i--) if (inst_pend_q[i]) inst_id = ID_W'(i);
  end

  logic [ROQC_W-1:0]       roq_cnt_q;
  logic [ROQ_W-1:0]        roq_head_q, roq_tail_q;
  logic [ROQ_N-1:0]        roq_done_q;
  logic [sf_albion_pkg::SF_RSP_W-1:0] roq_rsp_q [ROQ_N];   // queued responses (flat vector: sf_albion_pkg::sf_rsp_t layout)
  wire  logic              roq_room = (roq_cnt_q != ROQC_W'(ROQ_N));
  logic                    no_work;     // nothing queued, parked or pending: the cache is quiescent when also in S_IDLE

  assign no_work = NB ? ((roq_cnt_q == '0) && (ms_valid == '0) && !park_valid_q) : !rsp_valid_q;

  // convenience
  assign req_ready_o = NB ? ((state_q == S_IDLE) && roq_room && !replay_avail && !park_valid_q)
                          : ((state_q == S_IDLE) && !rsp_valid_q);
  assign cmo_ready_o = (state_q == S_IDLE) && no_work && !req_valid_i;

  // hit detection on the registered tag buffer
  always_comb begin
    hit_vec = '0;
    for (int w = 0; w < WAYS; w++) begin
      hit_vec[w] = v_valid_q[w] && (v_tag_q[w*TAG_W +: TAG_W] == tag_q);
    end
    hit_any = |hit_vec;
    hit_idx = '0;
    for (int w = WAYS - 1; w >= 0; w--) begin
      if (hit_vec[w]) hit_idx = WAY_W'(w);
    end
  end

  // scrub target: lowest way with a pending corrected entry
  always_comb begin
    sc_any = |v_ce_q;
    sc_way = '0;
    for (int w = WAYS - 1; w >= 0; w--) begin
      if (v_ce_q[w]) sc_way = WAY_W'(w);
    end
    sc_valid = v_valid_q[sc_way];
    sc_dirty = v_dirty_q[sc_way];
    sc_tag   = v_tag_q[sc_way*TAG_W +: TAG_W];
  end

  // CMO range test for the way being visited
  always_comb begin
    cw            = cmo_way_q;
    cmo_ent_valid = v_valid_q[cw];
    cmo_ent_dirty = v_dirty_q[cw];
    cmo_ent_ue    = v_ue_q[cw];
    cmo_ent_tag   = v_tag_q[cw*TAG_W +: TAG_W];
    cmo_line_base = {1'b0, cmo_base};
    cmo_line_end  = cmo_line_base + 65'(LINE_BYTES);
    cmo_in_range  = !cmo_empty_q && (cmo_line_base < cmo_end_q) && (cmo_line_end > {1'b0, cmo_start_q});
    cmo_in_scope  = cmo_ent_valid && (cmo_all_q || cmo_in_range);
  end

  assign merged = (req_q.data & lane_mask(req_q.be)) | (da_rd_data & ~lane_mask(req_q.be));

  // end of the CMO range: min(start + size, 2^64) in 65-bit arithmetic
  wire logic [65:0] cmo_sum   = {2'b00, cmo_addr_i} + {2'b00, cmo_size_i};
  wire logic [64:0] cmo_end_d = cmo_sum[64] ? {1'b1, 64'd0} : {1'b0, cmo_sum[63:0]};

  always_comb begin
    // ---- defaults (hold)
    state_d      = state_q;
    way_d        = way_q;
    hit_dirty_d  = hit_dirty_q;
    replay_d     = replay_q;
    refetched_d  = refetched_q;
    miss_d       = miss_q;
    corr_d       = corr_q;
    v_ce_d       = v_ce_q;
    vic_valid_d  = vic_valid_q;
    vic_dirty_d  = vic_dirty_q;
    vic_tag_d    = vic_tag_q;
    wdata_d      = wdata_q;
    t0_d         = t0_q;
    mid_d        = mid_q;
    rid_d        = rid_q;
    roq_idx_d    = roq_idx_q;
    park_load    = 1'b0;
    park_clear   = 1'b0;
    park_reload  = 1'b0;
    replay_go    = 1'b0;
    inst_go      = 1'b0;
    ms_h_wr      = 1'b0;
    init_d       = init_q;
    cmo_set_d    = cmo_set_q;
    cmo_way_d    = cmo_way_q;
    cmo_lines_d  = cmo_lines_q;
    cmo_err_d    = cmo_err_q;
    cmo_done_d   = 1'b0;
    cmo_load     = 1'b0;
    req_load     = 1'b0;
    v_cap        = 1'b0;
    rsp_load     = 1'b0;
    rsp_d        = '0;
    ev           = '0;
    err_evt      = '0;
    lat_valid    = 1'b0;

    tag_rd_en    = 1'b0;
    tag_rd_set   = set_q;
    tag_wr_en    = 1'b0;
    tag_wr_set   = set_q;
    tag_wr_way   = '0;
    tag_wr_valid = 1'b0;
    tag_wr_dirty = 1'b0;
    tag_wr_tag   = tag_q;

    da_rd_en     = wb_rd_en;
    da_rd_way    = cmo_active ? cmo_way_q : way_q;
    da_rd_set    = cmo_active ? cmo_set_q : set_q;
    da_rd_beat   = wb_busy ? wb_rd_beat : beat_q;
    fe_wr        = 1'b0;
    da_wr_way    = way_q;
    da_wr_set    = set_q;
    da_wr_beat   = beat_q;
    da_wr_data   = req_q.data;

    wb_start     = 1'b0;
    wb_addr      = vic_base;
    rf_start     = 1'b0;
    byp_valid    = 1'b0;
    touch_en     = 1'b0;
    touch_alloc  = 1'b0;
    touch_way    = way_q;
    touch_set    = set_q;

    ms_upd_id    = mid_q;
    ms_err_id    = mid_q;
    ms_free_id   = (NB && replay_q) ? rid_q : mid_q;
    ms_alloc_en  = 1'b0;
    ms_free_en   = 1'b0;
    ms_upd_en    = 1'b0;
    ms_upd_state = 2'd0;
    ms_err_en    = 1'b0;
    ms_mtag_en   = mc_ready[sf_cache_pkg::MC_REFILL] && rf_m_valid && rf_m_first;

    // ---- uncorrectable beat dropped by the writeback engine (any state)
    if (wb_lost) begin
      ev[sf_cache_pkg::EV_DIRTY_LOST]       = 1'b1;
      err_evt[sf_cache_pkg::ERR_DIRTY_LOST] = 1'b1;
    end

    unique case (state_q)
      // -------------------------------------------------------------- reset initialisation walk
      S_INIT: begin
        tag_wr_en    = 1'b1;
        tag_wr_set   = init_q;
        tag_wr_way   = '1;
        tag_wr_valid = 1'b0;
        tag_wr_dirty = 1'b0;
        tag_wr_tag   = '0;
        init_d       = init_q + 1'b1;
        if (init_q == IDX_W'(SETS - 1)) state_d = S_IDLE;
      end

      // -------------------------------------------------------------- idle: accept a request or a CMO
      S_IDLE: begin
        if (NB && replay_avail) begin
          // a miss has completed: replay its parked request on the freshly installed line (or answer its error)
          replay_go   = 1'b1;
          req_load    = 1'b1;
          rid_d       = rid_sel;
          way_d       = ms_way_o[rid_sel*WAY_W +: WAY_W];
          roq_idx_d   = ms_roq_q[rid_sel];
          t0_d        = ms_t0_q[rid_sel];
          refetched_d = ms_ref_q[rid_sel];
          replay_d    = 1'b1;
          miss_d      = 1'b1;
          hit_dirty_d = 1'b0;
          corr_d      = 1'b0;
          state_d     = ms_err_q[rid_sel] ? S_RERR : S_HIT;
        end else if (NB && park_valid_q) begin
          // a parked request retries once its set is free and an MSHR is available (look_set = its set)
          if (ms_alloc_ready) begin
            park_reload = 1'b1;
            park_clear  = 1'b1;
            req_load    = 1'b1;
            roq_idx_d   = park_roq_q;
            t0_d        = park_t0_q;
            replay_d    = 1'b0;
            refetched_d = 1'b0;
            miss_d      = 1'b0;
            corr_d      = 1'b0;
            state_d     = S_DECODE;
          end
        end else if (req_valid_i && req_ready_o) begin
          req_load    = 1'b1;
          state_d     = S_DECODE;
          t0_d        = cyc_q;
          roq_idx_d   = roq_tail_q;
          replay_d    = 1'b0;
          refetched_d = 1'b0;
          miss_d      = 1'b0;
          corr_d      = 1'b0;
        end else if (cmo_valid_i && cmo_ready_o) begin
          cmo_load    = 1'b1;
          state_d     = S_CMO_RD;
          cmo_set_d   = '0;
          cmo_way_d   = '0;
          cmo_lines_d = 32'd0;
          cmo_err_d   = 1'b0;
        end
      end

      // -------------------------------------------------------------- classify
      S_DECODE: begin
        if (legal_st != sf_albion_pkg::SF_ST_OKAY) begin
          rsp_load = 1'b1;
          rsp_d    = mk_rsp(req_q.tag, legal_st, is_wr_q, 1'b0, 128'd0);
          state_d  = S_IDLE;
        end else if (range_bad) begin
          rsp_load = 1'b1;
          rsp_d    = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_DECODE_ERR, is_wr_q, 1'b0, 128'd0);
          state_d  = S_IDLE;
        end else if (!cacheable) begin
          state_d  = S_BYP;
        end else begin
          tag_rd_en = 1'b1;
          state_d   = S_TAG;
        end
      end

      // -------------------------------------------------------------- tag read returns
      S_TAG: begin
        if (tag_rd_vld) begin
          v_cap  = 1'b1;
          v_ce_d = ECC_SCRUB ? tag_rd_ce : '0;
          if (|tag_rd_ce) begin
            ev[sf_cache_pkg::EV_TAG_CE]       = 1'b1;
            err_evt[sf_cache_pkg::ERR_TAG_CE] = 1'b1;
            corr_d                            = 1'b1;
          end
          if (|tag_rd_ue) begin
            ev[sf_cache_pkg::EV_TAG_UE]       = 1'b1;
            err_evt[sf_cache_pkg::ERR_TAG_UE] = 1'b1;
          end
          state_d = (ECC_SCRUB && (|tag_rd_ce)) ? S_SCRUBT : S_CMP;
        end
      end

      // -------------------------------------------------------------- write corrected tag entries back
      S_SCRUBT: begin
        tag_wr_en    = 1'b1;
        tag_wr_set   = set_q;
        tag_wr_way   = WAYS'(1) << sc_way;
        tag_wr_valid = sc_valid;
        tag_wr_dirty = sc_dirty;
        tag_wr_tag   = sc_tag;
        v_ce_d       = v_ce_q & ~(WAYS'(1) << sc_way);
        if ((v_ce_q & ~(WAYS'(1) << sc_way)) == '0) state_d = S_CMP;
      end

      // -------------------------------------------------------------- compare: hit or miss
      S_CMP: begin
        if (NB && !ms_alloc_ready) begin
          // the set is owned by an outstanding miss, or the MSHR table is full: park the request
          park_load   = 1'b1;
          ev[sf_cache_pkg::EV_PARK] = 1'b1;
          state_d     = S_IDLE;
        end else if (hit_any) begin
          way_d       = hit_idx;
          hit_dirty_d = v_dirty_q[hit_idx];
          touch_en    = 1'b1;
          touch_way   = hit_idx;
          touch_alloc = 1'b0;
          ev[is_wr_q ? sf_cache_pkg::EV_WR_HIT : sf_cache_pkg::EV_RD_HIT] = 1'b1;
          state_d     = S_HIT;
        end else begin
          miss_d      = 1'b1;
          way_d       = victim_way;
          vic_valid_d = v_valid_q[victim_way];
          vic_dirty_d = v_dirty_q[victim_way];
          vic_tag_d   = v_tag_q[victim_way*TAG_W +: TAG_W];
          ev[is_wr_q ? sf_cache_pkg::EV_WR_MISS : sf_cache_pkg::EV_RD_MISS] = 1'b1;
          ms_alloc_en = 1'b1;
          mid_d       = ms_alloc_id;
          state_d     = S_MISS;
        end
      end

      // -------------------------------------------------------------- miss: evict if needed
      S_MISS: begin
        ms_upd_en    = 1'b1;
        ms_upd_state = (vic_valid_q && vic_dirty_q) ? 2'd0 : 2'd1;
        if (vic_valid_q && vic_dirty_q) begin
          wb_start = 1'b1;
          state_d  = S_WB;
        end else if (vic_valid_q) begin
          state_d  = S_EVICT;
        end else begin
          state_d  = S_RFS;
        end
      end

      S_WB: begin
        if (wb_done) begin
          if (wb_err) begin
            // writeback rejected: the victim STAYS valid and dirty, the miss is aborted
            touch_en    = 1'b1;
            touch_way   = way_q;
            touch_alloc = 1'b1;
            ev[sf_cache_pkg::EV_WB_ERR]       = 1'b1;
            err_evt[sf_cache_pkg::ERR_WB]     = 1'b1;
            ms_err_en   = 1'b1;
            ms_free_en  = 1'b1;
            rsp_load    = 1'b1;
            rsp_d       = mk_rsp(req_q.tag, wb_status, is_wr_q, corr_q, 128'd0);
            lat_valid   = 1'b1;
            state_d     = S_IDLE;
          end else begin
            ev[sf_cache_pkg::EV_WRITEBACK] = 1'b1;
            state_d = S_EVICT;
          end
        end
      end

      S_EVICT: begin
        tag_wr_en    = 1'b1;
        tag_wr_set   = set_q;
        tag_wr_way   = WAYS'(1) << way_q;
        tag_wr_valid = 1'b0;
        tag_wr_dirty = 1'b0;
        tag_wr_tag   = '0;
        ev[sf_cache_pkg::EV_EVICT] = 1'b1;
        state_d      = S_RFS;
      end

      S_RFS: begin
        rf_start     = 1'b1;
        ms_upd_en    = 1'b1;
        ms_upd_state = 2'd1;
        if (NB) begin
          ms_h_wr = 1'b1;               // park the request in its MSHR; the front end is free again
          state_d = S_IDLE;
        end else begin
          state_d = S_RFW;
        end
      end

      S_RFW: begin
        if (rf_done) begin
          if (rf_err) begin
            ev[sf_cache_pkg::EV_REFILL_ERR]   = 1'b1;
            err_evt[sf_cache_pkg::ERR_REFILL] = 1'b1;
            ms_err_en   = 1'b1;
            ms_free_en  = 1'b1;
            rsp_load    = 1'b1;
            rsp_d       = mk_rsp(req_q.tag, rf_status, is_wr_q, corr_q, 128'd0);
            lat_valid   = 1'b1;
            state_d     = S_IDLE;
          end else begin
            state_d = S_INSTALL;
          end
        end
      end

      S_INSTALL: begin
        tag_wr_en    = 1'b1;
        tag_wr_set   = set_q;
        tag_wr_way   = WAYS'(1) << way_q;
        tag_wr_valid = 1'b1;
        tag_wr_dirty = 1'b0;
        tag_wr_tag   = tag_q;
        touch_en     = 1'b1;
        touch_way    = way_q;
        touch_alloc  = 1'b1;
        ev[sf_cache_pkg::EV_REFILL] = 1'b1;
        replay_d     = 1'b1;
        hit_dirty_d  = 1'b0;
        ms_upd_en    = 1'b1;
        ms_upd_state = 2'd2;
        state_d      = S_HIT;
      end

      // -------------------------------------------------------------- the line is resident in way_q
      S_HIT: begin
        if (!is_wr_q) begin
          da_rd_en = 1'b1;
          state_d  = S_RDW;
        end else if (full_be_q) begin
          fe_wr      = 1'b1;
          da_wr_data = req_q.data;
          if (hit_dirty_q) begin
            rsp_load  = 1'b1;
            rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b1, corr_q, 128'd0);
            lat_valid = miss_q;
            ms_free_en = miss_q;
            state_d   = S_IDLE;
          end else begin
            state_d   = S_WDIRTY;
          end
        end else begin
          da_rd_en = 1'b1;
          state_d  = S_RDW;
        end
      end

      // -------------------------------------------------------------- data read returns
      S_RDW: begin
        if (da_rd_vld) begin
          if (da_rd_ue) begin
            if (!hit_dirty_q && !refetched_q) begin
              // clean line: invalidate and refetch from memory (transparent to the requester)
              ev[sf_cache_pkg::EV_DATA_UE]             = 1'b1;
              err_evt[sf_cache_pkg::ERR_DATA_UE_CLEAN] = 1'b1;
              state_d = S_UEINV;
            end else begin
              // dirty (or already refetched): poison is returned, never laundered
              ev[sf_cache_pkg::EV_DATA_UE]             = 1'b1;
              err_evt[sf_cache_pkg::ERR_DATA_UE_POIS]  = 1'b1;
              rsp_load  = 1'b1;
              rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_ECC_UNCORR, is_wr_q, corr_q, 128'd0);
              lat_valid = miss_q;
              ms_free_en = miss_q;
              state_d   = S_IDLE;
            end
          end else begin
            if (da_rd_ce) begin
              ev[sf_cache_pkg::EV_DATA_CE]       = 1'b1;
              err_evt[sf_cache_pkg::ERR_DATA_CE] = 1'b1;
              corr_d = 1'b1;
            end
            if (!is_wr_q) begin
              rsp_load  = 1'b1;
              rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b0, corr_q | da_rd_ce, da_rd_data & lane_mask(req_q.be));
              lat_valid = miss_q;
              ms_free_en = miss_q;
              wdata_d   = da_rd_data;
              state_d   = (ECC_SCRUB && da_rd_ce) ? S_DSCRUB : S_IDLE;
            end else begin
              wdata_d   = merged;
              state_d   = S_WRITE;
            end
          end
        end
      end

      // -------------------------------------------------------------- partial write: write the merged beat back
      S_WRITE: begin
        fe_wr      = 1'b1;
        da_wr_data = wdata_q;
        if (hit_dirty_q) begin
          rsp_load  = 1'b1;
          rsp_d     = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b1, corr_q, 128'd0);
          lat_valid = miss_q;
          ms_free_en = miss_q;
          state_d   = S_IDLE;
        end else begin
          state_d   = S_WDIRTY;
        end
      end

      S_WDIRTY: begin
        tag_wr_en    = 1'b1;
        tag_wr_set   = set_q;
        tag_wr_way   = WAYS'(1) << way_q;
        tag_wr_valid = 1'b1;
        tag_wr_dirty = 1'b1;
        tag_wr_tag   = tag_q;
        rsp_load     = 1'b1;
        rsp_d        = mk_rsp(req_q.tag, sf_albion_pkg::SF_ST_OKAY, 1'b1, corr_q, 128'd0);
        lat_valid    = miss_q;
        ms_free_en   = miss_q;
        state_d      = S_IDLE;
      end

      // -------------------------------------------------------------- scrub the corrected data beat (response already sent)
      S_DSCRUB: begin
        fe_wr      = 1'b1;
        da_wr_data = wdata_q;
        state_d    = S_IDLE;
      end

      // -------------------------------------------------------------- clean line with an uncorrectable beat: drop and refetch
      S_UEINV: begin
        tag_wr_en    = 1'b1;
        tag_wr_set   = set_q;
        tag_wr_way   = WAYS'(1) << way_q;
        tag_wr_valid = 1'b0;
        tag_wr_dirty = 1'b0;
        tag_wr_tag   = '0;
        refetched_d  = 1'b1;
        miss_d       = 1'b1;
        ms_alloc_en  = !miss_q;          // a request that already missed still owns its entry
        if (!miss_q) mid_d = ms_alloc_id;
        vic_valid_d  = 1'b0;
        vic_dirty_d  = 1'b0;
        state_d      = S_RFS;
      end

      // -------------------------------------------------------------- uncached access
      S_BYP: begin
        byp_valid = 1'b1;
        if (mc_ready[sf_cache_pkg::MC_BYPASS]) begin
          ev[is_wr_q ? sf_cache_pkg::EV_BYPASS_WR : sf_cache_pkg::EV_BYPASS_RD] = 1'b1;
          state_d = S_BYPW;
        end
      end

      S_BYPW: begin
        if (mc_cpl_valid[sf_cache_pkg::MC_BYPASS]) begin
          rsp_load = 1'b1;
          rsp_d    = mk_rsp(req_q.tag, mc_cpl.status, is_wr_q, mc_cpl.meta[3], mc_cpl.data & lane_mask(req_q.be));
          state_d  = S_IDLE;
        end
      end

      // -------------------------------------------------------------- maintenance walk
      S_CMO_RD: begin
        tag_rd_en  = 1'b1;
        tag_rd_set = cmo_set_q;
        state_d    = S_CMO_TAG;
      end

      S_CMO_TAG: begin
        if (tag_rd_vld) begin
          v_cap  = 1'b1;
          v_ce_d = '0;
          if (|tag_rd_ce) begin
            ev[sf_cache_pkg::EV_TAG_CE]       = 1'b1;
            err_evt[sf_cache_pkg::ERR_TAG_CE] = 1'b1;
          end
          if (|tag_rd_ue) begin
            ev[sf_cache_pkg::EV_TAG_UE]       = 1'b1;
            err_evt[sf_cache_pkg::ERR_TAG_UE] = 1'b1;
          end
          cmo_way_d = '0;
          state_d   = S_CMO_CHK;
        end
      end

      S_CMO_CHK: begin
        tag_wr_set = cmo_set_q;
        tag_wr_way = WAYS'(1) << cmo_way_q;
        tag_wr_tag = cmo_ent_tag;
        wb_addr    = cmo_base;
        // default: visit the next way
        if (cmo_way_q == WAY_W'(WAYS - 1)) begin
          cmo_way_d = '0;
          if (cmo_set_q == IDX_W'(SETS - 1)) state_d = S_CMO_DONE;
          else begin cmo_set_d = cmo_set_q + 1'b1; state_d = S_CMO_RD; end
        end else begin
          cmo_way_d = cmo_way_q + 1'b1;
          state_d   = S_CMO_CHK;
        end
        if (cmo_ent_ue) begin
          // an entry that cannot be trusted: INVAL / CLEAN_INVAL clear it, CLEAN leaves it
          if (cmo_op_q != sf_cache_pkg::CMO_CLEAN) begin
            tag_wr_en = 1'b1; tag_wr_valid = 1'b0; tag_wr_dirty = 1'b0; tag_wr_tag = '0;
          end
        end else if (cmo_in_scope) begin
          ev[sf_cache_pkg::EV_CMO_LINE] = 1'b1;
          cmo_lines_d = cmo_lines_q + 32'd1;
          if (cmo_op_q == sf_cache_pkg::CMO_INVAL) begin
            if (cmo_ent_dirty) ev[sf_cache_pkg::EV_CMO_DISCARD] = 1'b1;
            tag_wr_en = 1'b1; tag_wr_valid = 1'b0; tag_wr_dirty = 1'b0; tag_wr_tag = '0;
          end else if (cmo_ent_dirty) begin
            wb_start  = 1'b1;
            cmo_way_d = cmo_way_q;          // stay on this way until its writeback completes
            cmo_set_d = cmo_set_q;
            state_d   = S_CMO_WB;
          end else if (cmo_op_q == sf_cache_pkg::CMO_CLEAN_INV) begin
            tag_wr_en = 1'b1; tag_wr_valid = 1'b0; tag_wr_dirty = 1'b0; tag_wr_tag = '0;
          end
        end
      end

      S_CMO_WB: begin
        tag_wr_set = cmo_set_q;
        tag_wr_way = WAYS'(1) << cmo_way_q;
        tag_wr_tag = cmo_ent_tag;
        wb_addr    = cmo_base;
        if (wb_done) begin
          if (wb_err) begin
            ev[sf_cache_pkg::EV_WB_ERR]   = 1'b1;
            err_evt[sf_cache_pkg::ERR_WB] = 1'b1;
            cmo_err_d = 1'b1;
          end else begin
            ev[sf_cache_pkg::EV_WRITEBACK] = 1'b1;
            tag_wr_en = 1'b1;
            if (cmo_op_q == sf_cache_pkg::CMO_CLEAN) begin
              tag_wr_valid = 1'b1; tag_wr_dirty = 1'b0;
            end else begin
              tag_wr_valid = 1'b0; tag_wr_dirty = 1'b0; tag_wr_tag = '0;
            end
          end
          if (cmo_way_q == WAY_W'(WAYS - 1)) begin
            cmo_way_d = '0;
            if (cmo_set_q == IDX_W'(SETS - 1)) state_d = S_CMO_DONE;
            else begin cmo_set_d = cmo_set_q + 1'b1; state_d = S_CMO_RD; end
          end else begin
            cmo_way_d = cmo_way_q + 1'b1;
            state_d   = S_CMO_CHK;
          end
        end
      end

      S_CMO_DONE: begin
        cmo_done_d = 1'b1;
        state_d    = S_IDLE;
      end

      // -------------------------------------------------------------- replay of a failed miss: answer the refill error
      S_RERR: begin
        rsp_load   = 1'b1;
        rsp_d      = mk_rsp(req_q.tag, ms_estat_q[rid_q], is_wr_q, 1'b0, 128'd0);
        lat_valid  = 1'b1;
        ms_free_en = 1'b1;
        state_d    = S_IDLE;
      end

      default: state_d = S_IDLE;
    endcase

    // ---- non-blocking: a refill finished (autonomous of the front end)
    if (NB && rf_done) begin
      ms_err_id = rf_done_id;
      if (rf_err) begin
        ev[sf_cache_pkg::EV_REFILL_ERR]   = 1'b1;
        err_evt[sf_cache_pkg::ERR_REFILL] = 1'b1;
        ms_err_en                         = 1'b1;
      end
    end

    // ---- non-blocking installer: when the tag / replacement ports are free, make a refilled line valid
    if (NB && inst_any && !tag_rd_en && !tag_wr_en && !touch_en) begin
      inst_go      = 1'b1;
      tag_wr_en    = 1'b1;
      tag_wr_set   = ms_set_o[inst_id*IDX_W +: IDX_W];
      tag_wr_way   = WAYS'(1) << ms_way_o[inst_id*WAY_W +: WAY_W];
      tag_wr_valid = 1'b1;
      tag_wr_dirty = 1'b0;
      tag_wr_tag   = inst_tag;
      touch_en     = 1'b1;
      touch_set    = ms_set_o[inst_id*IDX_W +: IDX_W];
      touch_way    = ms_way_o[inst_id*WAY_W +: WAY_W];
      touch_alloc  = 1'b1;
      ev[sf_cache_pkg::EV_REFILL] = 1'b1;
      ms_upd_en    = 1'b1;
      ms_upd_id    = inst_id;
      ms_upd_state = 2'd2;
    end

    // ---- data-array port: the front end has priority; a refill beat is accepted only in a cycle the front end leaves free
    rf_grant = !(da_rd_en || fe_wr);
    da_wr_en = fe_wr || rf_wr_en;
    if (rf_wr_en) begin
      da_wr_way  = rf_wr_way;
      da_wr_set  = rf_wr_set;
      da_wr_beat = rf_wr_beat;
      da_wr_data = rf_wr_data;
    end

    // ---- cross-state events
    ev[sf_cache_pkg::EV_MEM_RD_BEAT] = mem_acc_rd;
    ev[sf_cache_pkg::EV_MEM_WR_BEAT] = mem_acc_wr;
    ev[sf_cache_pkg::EV_ERR_RSP]     = rsp_load && (rsp_d.status != sf_albion_pkg::SF_ST_OKAY);
    ev[sf_cache_pkg::EV_STALL]       = req_valid_i && !req_ready_o;
    ev[sf_cache_pkg::EV_BUSY]        = (state_q != S_IDLE) || !no_work;
  end

  // ===========================================================================
  // Sequential state
  // ===========================================================================
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q      <= S_INIT;
      init_q       <= '0;
      rsp_valid_q  <= 1'b0;
      way_q        <= '0;
      hit_dirty_q  <= 1'b0;
      replay_q     <= 1'b0;
      refetched_q  <= 1'b0;
      miss_q       <= 1'b0;
      corr_q       <= 1'b0;
      v_ce_q       <= '0;
      vic_valid_q  <= 1'b0;
      vic_dirty_q  <= 1'b0;
      cmo_set_q    <= '0;
      cmo_way_q    <= '0;
      cmo_lines_q  <= 32'd0;
      cmo_err_q    <= 1'b0;
      cmo_done_q   <= 1'b0;
      err_sticky_q <= '0;
    end else begin
      state_q      <= state_d;
      init_q       <= init_d;
      way_q        <= way_d;
      hit_dirty_q  <= hit_dirty_d;
      replay_q     <= replay_d;
      refetched_q  <= refetched_d;
      miss_q       <= miss_d;
      corr_q       <= corr_d;
      v_ce_q       <= v_ce_d;
      vic_valid_q  <= vic_valid_d;
      vic_dirty_q  <= vic_dirty_d;
      cmo_set_q    <= cmo_set_d;
      cmo_way_q    <= cmo_way_d;
      cmo_lines_q  <= cmo_lines_d;
      cmo_err_q    <= cmo_err_d;
      cmo_done_q   <= cmo_done_d;
      if (!NB) begin
        if (rsp_load)                        rsp_valid_q <= 1'b1;
        else if (rsp_valid_q && rsp_ready_i) rsp_valid_q <= 1'b0;
      end
      if (err_clear_i) err_sticky_q <= err_evt;
      else             err_sticky_q <= err_sticky_q | err_evt;
    end
  end

  // payload registers: no reset (meaningful only under their qualifier)
  always_ff @(posedge clk_i) begin
    if (req_load) req_q <= replay_go ? ms_req_q[rid_sel] : (park_reload ? park_q : req_i);
    if (!NB && rsp_load) rsp_q <= rsp_d;
    if (NB && rsp_load)  roq_rsp_q[roq_idx_q] <= rsp_d;
    if (park_load) begin
      park_q     <= req_q;
      park_roq_q <= roq_idx_q;
      park_t0_q  <= t0_q;
    end
    if (ms_h_wr) begin
      ms_req_q[mid_q]  <= req_q;
      ms_roq_q[mid_q]  <= roq_idx_q;
      ms_t0_q[mid_q]   <= t0_q;
    end
    if (NB && rf_done && rf_err) ms_estat_q[rf_done_id] <= rf_status;
    vic_tag_q <= vic_tag_d;
    wdata_q   <= wdata_d;
    if (v_cap) begin
      v_valid_q <= tag_rd_valid;
      v_dirty_q <= tag_rd_dirty;
      v_tag_q   <= tag_rd_tag;
      v_ue_q    <= tag_rd_ue;
    end
    if (cmo_load) begin
      cmo_op_q    <= cmo_op_i;
      cmo_all_q   <= cmo_all_i;
      cmo_start_q <= cmo_addr_i;
      cmo_empty_q <= (cmo_size_i == 64'd0);
      cmo_end_q   <= cmo_end_d;
    end
    if (|err_evt) err_addr_q <= cmo_active ? cmo_base : a_q;
  end

  // ===========================================================================
  // Outputs
  // ===========================================================================
  assign rsp_valid_o  = NB ? ((roq_cnt_q != '0) && roq_done_q[roq_head_q]) : rsp_valid_q;
  assign rsp_o        = NB ? roq_rsp_q[roq_head_q] : rsp_q;
  assign cmo_busy_o   = cmo_active;
  assign cmo_done_o   = cmo_done_q;
  assign cmo_lines_o  = cmo_lines_q;
  assign cmo_err_o    = cmo_err_q;
  assign init_done_o  = (state_q != S_INIT);
  assign busy_o       = (state_q != S_IDLE) || !no_work;

  // ---- non-blocking sequential state: cycle counter, hand-off bookkeeping, response-order queue
  function automatic logic [ROQ_W-1:0] roq_inc(input logic [ROQ_W-1:0] p);
    roq_inc = (p == ROQ_W'(ROQ_N - 1)) ? '0 : p + 1'b1;
  endfunction

  wire logic roq_acc = req_valid_i && req_ready_o;
  wire logic roq_pop = rsp_valid_o && rsp_ready_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cyc_q        <= 32'd0;
      t0_q         <= 32'd0;
      mid_q        <= '0;
      rid_q        <= '0;
      roq_idx_q    <= '0;
      park_valid_q <= 1'b0;
      ms_ref_q     <= '0;
      ms_done_q    <= '0;
      ms_err_q     <= '0;
      inst_pend_q  <= '0;
      roq_head_q   <= '0;
      roq_tail_q   <= '0;
      roq_cnt_q    <= '0;
      roq_done_q   <= '0;
    end else begin
      cyc_q     <= cyc_q + 32'd1;
      t0_q      <= t0_d;
      mid_q     <= mid_d;
      rid_q     <= rid_d;
      roq_idx_q <= roq_idx_d;
      if (park_load)       park_valid_q <= 1'b1;
      else if (park_clear) park_valid_q <= 1'b0;
      if (ms_h_wr) ms_ref_q[mid_q] <= refetched_q;
      if (ms_alloc_en && ms_alloc_ready) begin
        ms_err_q[ms_alloc_id]    <= 1'b0;
        ms_done_q[ms_alloc_id]   <= 1'b0;
        inst_pend_q[ms_alloc_id] <= 1'b0;
      end
      if (NB && rf_done) begin
        if (rf_err) begin
          ms_err_q[rf_done_id]  <= 1'b1;
          ms_done_q[rf_done_id] <= 1'b1;
        end else begin
          inst_pend_q[rf_done_id] <= 1'b1;
        end
      end
      if (inst_go) begin
        inst_pend_q[inst_id] <= 1'b0;
        ms_done_q[inst_id]   <= 1'b1;
      end
      if (replay_go) ms_done_q[rid_sel] <= 1'b0;
      if (NB) begin
        if (roq_acc) begin
          roq_tail_q              <= roq_inc(roq_tail_q);
          roq_done_q[roq_tail_q]  <= 1'b0;
        end
        if (roq_pop) begin
          roq_head_q              <= roq_inc(roq_head_q);
          roq_done_q[roq_head_q]  <= 1'b0;
        end
        if (rsp_load) roq_done_q[roq_idx_q] <= 1'b1;
        case ({roq_acc, roq_pop})
          2'b10:   roq_cnt_q <= roq_cnt_q + 1'b1;
          2'b01:   roq_cnt_q <= roq_cnt_q - 1'b1;
          default: roq_cnt_q <= roq_cnt_q;
        endcase
      end
    end
  end
  assign err_evt_o    = err_evt;
  assign err_sticky_o = err_sticky_q;
  assign err_addr_o   = err_addr_q;

  sf_cache_perf #(.CNT_W(CNT_W)) u_perf (
    .clk_i(clk_i), .rst_ni(rst_ni), .clear_i(perf_clear_i), .ev_i(ev),
    .lat_valid_i(lat_valid), .lat_cycles_i(lat_q), .cnt_o(perf_o)
  );

  // capability word: what this block really implements (ALP v1)
  sf_albion_pkg::sf_caps_t caps_c;
  always_comb begin
    caps_c                 = '0;
    caps_c.proto_major     = 4'(sf_albion_pkg::SF_ALP_VERSION_MAJOR);
    caps_c.proto_minor     = 4'(sf_albion_pkg::SF_ALP_VERSION_MINOR);
    caps_c.addr_w          = 8'(sf_albion_pkg::SF_ADDR_W);
    caps_c.data_bytes_log2 = 4'd4;
    caps_c.tag_w           = 4'(sf_albion_pkg::SF_TAG_W);
    caps_c.dom_w           = 4'(sf_albion_pkg::SF_DOM_W);
    caps_c.max_outstanding = 16'(ROQ_N);                  // blocking cache: 1; MSHR cache: the response-queue depth
    caps_c.features        = 16'((1 << sf_albion_pkg::SF_FEAT_READ) | (1 << sf_albion_pkg::SF_FEAT_WRITE)
                              | (ECC_EN ? ((1 << sf_albion_pkg::SF_FEAT_ECC) | (1 << sf_albion_pkg::SF_FEAT_POISON)) : 0));
  end
  assign caps_o = caps_c;

  // ===========================================================================
  // Simulation-time self checks (excluded from synthesis)
  // ===========================================================================
`ifndef SYNTHESIS
  always @(posedge clk_i) begin
    if (rst_ni) begin
      if (state_q == S_CMP && $countones(hit_vec) > 1)
        $error("sf_llc_cache: more than one way matches the tag (set %0d)", set_q);
      if (!NB && ms_occ > 1)
        $error("sf_llc_cache: more than one MSHR entry occupied in the blocking cache");
      if (!NB && rsp_load && rsp_valid_q && !rsp_ready_i)
        $error("sf_llc_cache: response register overwritten before it was accepted");
      if (NB && roq_cnt_q > ROQC_W'(ROQ_N))
        $error("sf_llc_cache: response-order queue overflow");
      if (NB && rsp_load && roq_done_q[roq_idx_q])
        $error("sf_llc_cache: response slot filled twice");
      if (state_q != S_IDLE && state_q != S_INIT && req_valid_i && req_ready_o)
        $error("sf_llc_cache: request accepted while busy");
    end
  end
`endif
endmodule

`default_nettype wire
