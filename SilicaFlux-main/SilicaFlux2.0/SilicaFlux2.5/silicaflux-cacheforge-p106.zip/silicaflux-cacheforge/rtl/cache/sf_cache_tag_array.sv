// =============================================================================
//  sf_cache_tag_array.sv  --  CacheForge tag / state array
// -----------------------------------------------------------------------------
//  One RAM per way, built on the existing sf_sram_macro_wrapper (SRAMMacroBridge
//  P79), so the same RTL maps to a behavioural array, FPGA block RAM or an ASIC
//  macro through MEMORY_TECH / MACRO_ID.  Entry layout (stored word):
//
//      { tag[TAG_W-1:0], dirty, valid }          width E = TAG_W + 2
//
//  With ECC_EN = 1 the wrapper stores a Hsiao SECDED codeword over the whole
//  entry (ECC_MODE SECDED_WORD), so valid, dirty and tag are all protected.
//  An all-zero stored word is a valid codeword and decodes to "invalid", so the
//  reset initialisation walk of sf_llc_cache simply writes zeros.
//
//  Port discipline (single-port RAM per way): at most ONE of rd_en_i / wr_en_i
//  per cycle; a write wins and the read is dropped (the controller never does
//  both; a simulation check flags it).
//
//  Read   : rd_en_i with rd_set_i reads ALL ways.  RAM_LATENCY cycles later
//           rd_vld_o pulses for one cycle and the per-way outputs are valid for
//           that cycle only.  rd_ue_o[w] marks an uncorrectable entry: its
//           valid / dirty outputs are forced to 0 (an entry that cannot be
//           trusted never hits); rd_ce_o[w] marks a corrected entry (outputs
//           are the corrected values).
//  Write  : wr_en_i writes the entry of every way selected by wr_way_i (one RAM
//           access per selected way, same cycle).
//
//  Classification: SYNTHESIZABLE (storage via the wrapper).
// =============================================================================
`include "sf_sram_macro_defs.svh"
`default_nettype none

module sf_cache_tag_array #(
  parameter int unsigned SETS        = 128,
  parameter int unsigned WAYS        = 4,
  parameter int unsigned TAG_W       = 51,
  parameter int unsigned RAM_LATENCY = 1,
  parameter bit          ECC_EN      = 1'b1,
  parameter int unsigned MEMORY_TECH = 0,       // SF_MEM_TECH_GENERIC / _FPGA / _ASIC_*
  parameter int unsigned MACRO_ID    = 0,
  localparam int unsigned IDX_W      = (SETS > 1) ? $clog2(SETS) : 1,
  localparam int unsigned ENT_W      = TAG_W + 2
) (
  input  wire logic                   clk_i,
  // read (all ways)
  input  wire logic                   rd_en_i,
  input  wire logic [IDX_W-1:0]       rd_set_i,
  output logic                        rd_vld_o,
  output logic [WAYS-1:0]             rd_valid_o,
  output logic [WAYS-1:0]             rd_dirty_o,
  output logic [WAYS*TAG_W-1:0]       rd_tag_o,
  output logic [WAYS-1:0]             rd_ce_o,
  output logic [WAYS-1:0]             rd_ue_o,
  // write (selected ways)
  input  wire logic                   wr_en_i,
  input  wire logic [IDX_W-1:0]       wr_set_i,
  input  wire logic [WAYS-1:0]        wr_way_i,
  input  wire logic                   wr_valid_i,
  input  wire logic                   wr_dirty_i,
  input  wire logic [TAG_W-1:0]       wr_tag_i
);
  if (SETS < 2 || (SETS & (SETS - 1)) != 0) begin : g_chk_sets
    $error("sf_cache_tag_array: SETS must be a power of two >= 2");
  end
  if (WAYS < 1 || WAYS > 16) begin : g_chk_ways
    $error("sf_cache_tag_array: WAYS must be 1..16");
  end

  localparam int ECC_MODE_I = ECC_EN ? `SF_ECC_SECDED_WORD : `SF_ECC_NONE;

  wire logic [ENT_W-1:0] wr_ent = {wr_tag_i, wr_dirty_i, wr_valid_i};

  logic [WAYS-1:0] vld_w, cor_w, unc_w;
  logic [ENT_W-1:0] ent_w [WAYS];

  for (genvar w = 0; w < WAYS; w++) begin : g_way
    wire logic ce = wr_en_i ? wr_way_i[w] : rd_en_i;
    wire logic we = wr_en_i;
    logic [ENT_W-1:0] q;
    sf_sram_macro_wrapper #(
      .DATA_WIDTH(ENT_W), .DEPTH_WORDS(SETS), .READ_LATENCY(RAM_LATENCY),
      .BYTE_ENABLE(0), .BYTE_WIDTH(ENT_W),
      .MEMORY_TECH(MEMORY_TECH), .MACRO_ID(MACRO_ID),
      .ECC_MODE(ECC_MODE_I), .TEST_MODE(0), .POWER_CTRL(0)
    ) u_ram (
      .clk(clk_i), .ce(ce), .we(we), .wmask(1'b1),
      .idx(wr_en_i ? wr_set_i : rd_set_i), .wdata(wr_ent),
      .rdata(q), .rd_vld(vld_w[w]), .ecc_corrected(cor_w[w]), .ecc_uncorrectable(unc_w[w]),
      .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_idx('0), .tst_wdata('0),
      .tst_rdata(), .tst_rd_vld(), .pwr_sleep(1'b0), .pwr_active()
    );
    assign ent_w[w] = q;
  end

  // ---- decode (outputs are meaningful only while rd_vld_o)
  assign rd_vld_o = vld_w[0];
  for (genvar w = 0; w < WAYS; w++) begin : g_dec
    assign rd_ue_o[w]    = unc_w[w];
    assign rd_ce_o[w]    = cor_w[w];
    assign rd_valid_o[w] = ent_w[w][0] & ~unc_w[w];
    assign rd_dirty_o[w] = ent_w[w][1] & ~unc_w[w];
    assign rd_tag_o[w*TAG_W +: TAG_W] = ent_w[w][ENT_W-1:2];
  end

`ifndef SYNTHESIS
  always @(posedge clk_i) begin
    if (wr_en_i && rd_en_i) $error("sf_cache_tag_array: read and write in the same cycle (single-port RAM)");
  end
`endif
endmodule

`default_nettype wire
