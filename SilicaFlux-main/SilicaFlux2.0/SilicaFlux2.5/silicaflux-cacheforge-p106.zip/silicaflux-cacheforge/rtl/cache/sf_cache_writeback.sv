// =============================================================================
//  sf_cache_writeback.sv  --  CacheForge writeback controller
// -----------------------------------------------------------------------------
//  Writes one cache line back to memory: for beat b = 0..BEATS-1 (ascending) the
//  beat is read from the data array and sent as a single-beat 128-bit WRITE
//  (line base + 16*b, byte enables FFFF) through the memory port.
//
//  Behaviour
//   * start_i (when idle) latches the line base address, domain and attributes.
//   * ALL BEATS beats are processed.  A WRITE response whose status is not OKAY
//     sets err_o and records the FIRST failing status (status_o); the remaining
//     beats are still attempted and every response is consumed (the link is left
//     clean).  The caller decides what a failed writeback means (sf_llc_cache:
//     the line stays valid and dirty, no data is lost).
//   * a beat whose array read reports an UNCORRECTABLE ECC error is NOT written
//     (corrupt data is never propagated to memory); lost_o pulses once per such
//     beat.  The beat's memory location keeps its previous contents.
//   * done_o pulses one cycle after the last response has been consumed.
//
//  The array read port is owned by this engine while busy_o is high.
//  Throughput: one beat per (1 + RAM_LATENCY + 1) cycles; the next array read
//  does not overlap the previous send (kept simple; the memory latency dominates).
// =============================================================================
`default_nettype none

module sf_cache_writeback #(
  parameter int unsigned BEATS = 4,
  localparam int unsigned BEAT_W = (BEATS > 1) ? $clog2(BEATS) : 1,
  localparam int unsigned CW     = $clog2(BEATS + 1)
) (
  input  wire logic                     clk_i,
  input  wire logic                     rst_ni,
  // command
  input  wire logic                     start_i,
  input  wire logic [63:0]              line_addr_i,
  input  wire logic [7:0]               dom_i,
  input  wire logic [7:0]               attr_i,
  output logic                          busy_o,
  output logic                          done_o,
  output logic                          err_o,
  output logic [3:0]                    status_o,
  output logic                          lost_o,
  // data-array read
  output logic                          da_rd_en_o,
  output logic [BEAT_W-1:0]             da_rd_beat_o,
  input  wire logic                     da_rd_vld_i,
  input  wire logic [127:0]             da_rd_data_i,
  input  wire logic                     da_rd_ue_i,
  // memory-port client
  output logic                          m_valid_o,
  input  wire logic                     m_ready_i,
  output sf_albion_pkg::sf_req_t        m_req_o,
  input  wire logic                     m_cpl_valid_i,
  output logic                          m_cpl_ready_o,
  input  sf_albion_pkg::sf_rsp_t        m_cpl_i
);
  if (BEATS < 1 || (BEATS & (BEATS - 1)) != 0 || BEATS > 16) begin : g_chk
    $error("sf_cache_writeback: BEATS must be a power of two in 1..16");
  end

  typedef enum logic [2:0] {W_IDLE, W_RD, W_WAIT, W_SEND, W_DRAIN} wstate_e;
  wstate_e state_q;

  logic [63:0]    addr_q;
  logic [7:0]     dom_q, attr_q;
  logic [127:0]   data_q;
  logic [CW-1:0]  beat_q, sent_q, cpl_q;
  logic           err_q, done_q;
  logic [3:0]     status_q;

  assign busy_o       = (state_q != W_IDLE);
  assign done_o       = done_q;
  assign err_o        = err_q;
  assign status_o     = status_q;

  assign da_rd_en_o   = (state_q == W_RD);
  assign da_rd_beat_o = BEAT_W'(beat_q);

  assign m_valid_o    = (state_q == W_SEND);
  always_comb begin
    m_req_o      = '0;
    m_req_o.op   = sf_albion_pkg::SF_OP_WRITE;
    m_req_o.dom  = dom_q;
    m_req_o.attr = attr_q;
    m_req_o.addr = addr_q + 64'(beat_q) * 64'd16;
    m_req_o.be   = 16'hFFFF;
    m_req_o.data = data_q;
  end

  assign m_cpl_ready_o = 1'b1;
  wire logic cpl_fire  = m_cpl_valid_i && m_cpl_ready_o;
  wire logic last_beat = (beat_q == CW'(BEATS - 1));

  assign lost_o = (state_q == W_WAIT) && da_rd_vld_i && da_rd_ue_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q  <= W_IDLE;
      done_q   <= 1'b0;
      err_q    <= 1'b0;
      status_q <= 4'd0;
      beat_q   <= '0;
      sent_q   <= '0;
      cpl_q    <= '0;
    end else begin
      done_q <= 1'b0;
      if (cpl_fire) begin
        cpl_q <= cpl_q + 1'b1;
        if (m_cpl_i.status != sf_albion_pkg::SF_ST_OKAY && !err_q) begin
          err_q    <= 1'b1;
          status_q <= m_cpl_i.status;
        end
      end
      case (state_q)
        W_IDLE: begin
          if (start_i) begin
            state_q  <= W_RD;
            beat_q   <= '0;
            sent_q   <= '0;
            cpl_q    <= '0;
            err_q    <= 1'b0;
            status_q <= 4'd0;
          end
        end
        W_RD: state_q <= W_WAIT;
        W_WAIT: begin
          if (da_rd_vld_i) begin
            if (da_rd_ue_i) begin
              // uncorrectable: skip this beat, move on
              if (last_beat) state_q <= W_DRAIN;
              else begin beat_q <= beat_q + 1'b1; state_q <= W_RD; end
            end else begin
              state_q <= W_SEND;
            end
          end
        end
        W_SEND: begin
          if (m_ready_i) begin
            sent_q <= sent_q + 1'b1;
            if (last_beat) state_q <= W_DRAIN;
            else begin beat_q <= beat_q + 1'b1; state_q <= W_RD; end
          end
        end
        W_DRAIN: begin
          if (cpl_q == sent_q) begin
            done_q  <= 1'b1;
            state_q <= W_IDLE;
          end
        end
        default: state_q <= W_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk_i) begin
    if (state_q == W_IDLE && start_i) begin
      addr_q <= line_addr_i;
      dom_q  <= dom_i;
      attr_q <= attr_i;
    end
    if (state_q == W_WAIT && da_rd_vld_i) data_q <= da_rd_data_i;
  end
endmodule

`default_nettype wire
