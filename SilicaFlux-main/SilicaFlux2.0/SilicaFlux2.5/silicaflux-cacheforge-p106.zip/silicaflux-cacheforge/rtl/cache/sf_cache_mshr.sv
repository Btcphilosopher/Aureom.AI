// =============================================================================
//  sf_cache_mshr.sv  --  CacheForge miss-status holding registers
// -----------------------------------------------------------------------------
//  A table of NUM_MSHR entries.  Each entry tracks ONE outstanding line miss:
//
//      miss address    line_q   (line base address)
//      set / way       set_q, way_q   (the way RESERVED as the replacement victim)
//      refill status   state_q  MS_WB / MS_REFILL / MS_DONE
//      memory tag      mtag_q   (tag of the first refill request on the memory link)
//      error state     err_q + estat_q (first non-OKAY memory status)
//      waiting txns    waiters_q (the primary request + merged secondary requests)
//      request class   write_q, dom_q, attr_q   (what a later request must match to merge)
//
//  The blocking cache (NUM_MSHR = 1) uses the table as the one-entry tracker of its
//  single miss; the MSHR extension (NUM_MSHR > 1) uses the same module as its miss
//  table.  The table never merges by itself: it reports, for a candidate request,
//
//      hit_o      an entry for the same LINE exists
//      merge_ok_o ...and the request is COMPATIBLE: both are READs, same domain, same
//                 privilege / security / memory-type attribute bits.  A hit with
//                 merge_ok_o = 0 is a CONFLICT: the caller must stall the request
//                 (a write never merges into a pending line, a read never merges into
//                 a write-miss entry, requests of different permission class never
//                 merge - the "incompatible ordering or permissions" rule).
//      set_busy_o some entry already owns the SET (one in-flight miss per set keeps
//                 victim selection and the sequential-execution contract exact).
//
//  Allocation: alloc_en_i takes the lowest free entry (alloc_id_o) unless the table is
//  full or the ALLOCATION set (alloc_set_i) is already owned, in which case it is
//  refused (and flagged by a simulation check).  alloc_ready_o reports the same test
//  for the LOOKUP set so a caller can look before it allocates.  The table therefore
//  never holds two entries for one set, whatever the caller drives.
// =============================================================================
`default_nettype none

module sf_cache_mshr #(
  parameter int unsigned NUM_MSHR = 1,
  parameter int unsigned SETS     = 128,
  parameter int unsigned WAYS     = 4,
  parameter int unsigned MAX_WAIT = 8,
  localparam int unsigned ID_W    = (NUM_MSHR > 1) ? $clog2(NUM_MSHR) : 1,
  localparam int unsigned IDX_W   = (SETS > 1) ? $clog2(SETS) : 1,
  localparam int unsigned WAY_W   = (WAYS > 1) ? $clog2(WAYS) : 1,
  localparam int unsigned WT_W    = $clog2(MAX_WAIT + 1),
  localparam int unsigned OCC_W   = $clog2(NUM_MSHR + 1)
) (
  input  wire logic                clk_i,
  input  wire logic                rst_ni,
  // allocate
  input  wire logic                alloc_en_i,
  input  wire logic [63:0]         alloc_line_i,
  input  wire logic [IDX_W-1:0]    alloc_set_i,
  input  wire logic [WAY_W-1:0]    alloc_way_i,
  input  wire logic                alloc_write_i,
  input  wire logic [7:0]          alloc_dom_i,
  input  wire logic [7:0]          alloc_attr_i,
  output logic                     alloc_ready_o,
  output logic [ID_W-1:0]          alloc_id_o,
  // entry updates (one per cycle each)
  input  wire logic                upd_en_i,
  input  wire logic [ID_W-1:0]     upd_id_i,
  input  wire logic [1:0]          upd_state_i,      // sf_cache_mshr::MS_*
  input  wire logic                mtag_en_i,
  input  wire logic [ID_W-1:0]     mtag_id_i,
  input  wire logic [7:0]          mtag_i,
  input  wire logic                err_en_i,
  input  wire logic [ID_W-1:0]     err_id_i,
  input  wire logic [3:0]          err_status_i,
  input  wire logic                wait_inc_i,
  input  wire logic [ID_W-1:0]     wait_id_i,
  input  wire logic                free_en_i,
  input  wire logic [ID_W-1:0]     free_id_i,
  // lookup of a candidate request
  input  wire logic [63:0]         look_line_i,
  input  wire logic [IDX_W-1:0]    look_set_i,
  input  wire logic                look_write_i,
  input  wire logic [7:0]          look_dom_i,
  input  wire logic [7:0]          look_attr_i,
  output logic                     hit_o,
  output logic [ID_W-1:0]          hit_id_o,
  output logic                     merge_ok_o,
  output logic                     set_busy_o,
  output logic                     waiters_full_o,
  // observation
  output logic [NUM_MSHR-1:0]      valid_o,
  output logic [OCC_W-1:0]         occupancy_o,
  output logic [NUM_MSHR-1:0]      err_o,
  output logic [NUM_MSHR*2-1:0]    state_o,
  output logic [NUM_MSHR*WAY_W-1:0] way_o,
  output logic [NUM_MSHR*IDX_W-1:0] set_o,
  output logic [NUM_MSHR*8-1:0]    mtag_o,
  output logic [NUM_MSHR*4-1:0]    estat_o,
  output logic [NUM_MSHR*WT_W-1:0] waiters_o,
  output logic [NUM_MSHR*64-1:0]   line_o,     // miss line address of each entry
  output logic [NUM_MSHR-1:0]      write_o,    // entry is a write miss
  output logic [NUM_MSHR*8-1:0]    dom_o,
  output logic [NUM_MSHR*8-1:0]    attr_o
);
  // entry states
  localparam logic [1:0] MS_WB = 2'd0, MS_REFILL = 2'd1, MS_DONE = 2'd2;

  if (NUM_MSHR < 1 || NUM_MSHR > 16) begin : g_chk
    $error("sf_cache_mshr: NUM_MSHR must be 1..16");
  end

  logic [NUM_MSHR-1:0]  v_q, e_q, w_q;
  logic [63:0]          line_q   [NUM_MSHR];
  logic [IDX_W-1:0]     set_q    [NUM_MSHR];
  logic [WAY_W-1:0]     way_q    [NUM_MSHR];
  logic [1:0]           state_q  [NUM_MSHR];
  logic [7:0]           mtag_q   [NUM_MSHR];
  logic [3:0]           estat_q  [NUM_MSHR];
  logic [WT_W-1:0]      wait_q   [NUM_MSHR];
  logic [7:0]           dom_q    [NUM_MSHR];
  logic [7:0]           attr_q   [NUM_MSHR];

  // ---- first free entry
  logic              any_free;
  logic [ID_W-1:0]   free_id;
  always_comb begin
    any_free = 1'b0;
    free_id  = '0;
    for (int i = NUM_MSHR - 1; i >= 0; i--) begin
      if (!v_q[i]) begin any_free = 1'b1; free_id = ID_W'(i); end
    end
  end

  // ---- lookup
  logic            h, sb, mok, wfull;
  logic [ID_W-1:0] hid;
  always_comb begin
    h = 1'b0; sb = 1'b0; mok = 1'b0; wfull = 1'b0; hid = '0;
    for (int i = 0; i < NUM_MSHR; i++) begin
      if (v_q[i] && set_q[i] == look_set_i) sb = 1'b1;
      if (v_q[i] && line_q[i] == look_line_i) begin
        h   = 1'b1;
        hid = ID_W'(i);
        // compatible: both reads, same domain, same permission-relevant attribute bits
        // (attr[1:0] memory type, attr[2] priv, attr[3] secure); qos / instr may differ
        mok   = !w_q[i] && !look_write_i && (dom_q[i] == look_dom_i)
                && (attr_q[i][3:0] == look_attr_i[3:0]);
        wfull = (wait_q[i] == WT_W'(MAX_WAIT));
      end
    end
  end
  assign hit_o          = h;
  assign hit_id_o       = hid;
  assign merge_ok_o     = h && mok && !wfull;
  assign set_busy_o     = sb;
  assign waiters_full_o = h && wfull;

  // allocation guard: evaluated on the ALLOCATION set itself, so the table can never hold two entries for
  // one set whatever the caller drives on the lookup port (the one-in-flight-miss-per-set invariant is
  // enforced by construction).  alloc_ready_o is the same test on the LOOKUP set, for the caller's use.
  logic sb_alloc;
  always_comb begin
    sb_alloc = 1'b0;
    for (int i = 0; i < NUM_MSHR; i++) begin
      if (v_q[i] && set_q[i] == alloc_set_i) sb_alloc = 1'b1;
    end
  end
  wire logic alloc_go = alloc_en_i && any_free && !sb_alloc;

  assign alloc_ready_o  = any_free && !sb;
  assign alloc_id_o     = free_id;

  // ---- state
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      v_q <= '0;
      e_q <= '0;
      w_q <= '0;
    end else begin
      if (alloc_go) begin
        v_q[free_id] <= 1'b1;
        e_q[free_id] <= 1'b0;
        w_q[free_id] <= alloc_write_i;
      end
      if (err_en_i) e_q[err_id_i] <= 1'b1;
      if (free_en_i) v_q[free_id_i] <= 1'b0;
    end
  end

  always_ff @(posedge clk_i) begin
    if (alloc_go) begin
      line_q[free_id]  <= alloc_line_i;
      set_q[free_id]   <= alloc_set_i;
      way_q[free_id]   <= alloc_way_i;
      state_q[free_id] <= MS_WB;
      mtag_q[free_id]  <= 8'd0;
      estat_q[free_id] <= 4'd0;
      wait_q[free_id]  <= WT_W'(1);
      dom_q[free_id]   <= alloc_dom_i;
      attr_q[free_id]  <= alloc_attr_i;
    end
    if (upd_en_i)  state_q[upd_id_i] <= upd_state_i;
    if (mtag_en_i) mtag_q[mtag_id_i] <= mtag_i;
    if (err_en_i && !e_q[err_id_i]) estat_q[err_id_i] <= err_status_i;   // first error wins
    if (wait_inc_i && (wait_q[wait_id_i] != WT_W'(MAX_WAIT))) wait_q[wait_id_i] <= wait_q[wait_id_i] + 1'b1;
  end

  // ---- observation
  assign valid_o = v_q;
  assign write_o = w_q;
  assign err_o   = e_q;
  always_comb begin
    int unsigned occ;
    occ = 0;
    for (int i = 0; i < NUM_MSHR; i++) begin
      if (v_q[i]) occ = occ + 1;
      state_o[i*2 +: 2]            = state_q[i];
      way_o[i*WAY_W +: WAY_W]      = way_q[i];
      set_o[i*IDX_W +: IDX_W]      = set_q[i];
      mtag_o[i*8 +: 8]             = mtag_q[i];
      estat_o[i*4 +: 4]            = estat_q[i];
      waiters_o[i*WT_W +: WT_W]    = wait_q[i];
      line_o[i*64 +: 64]           = line_q[i];
      dom_o[i*8 +: 8]              = dom_q[i];
      attr_o[i*8 +: 8]             = attr_q[i];
    end
    occupancy_o = OCC_W'(occ);
  end

`ifndef SYNTHESIS
  always @(posedge clk_i) begin
    if (rst_ni && alloc_en_i && !alloc_go) $error("sf_cache_mshr: allocation refused (table full, or the set is already owned)");
  end
`endif
endmodule

`default_nettype wire
