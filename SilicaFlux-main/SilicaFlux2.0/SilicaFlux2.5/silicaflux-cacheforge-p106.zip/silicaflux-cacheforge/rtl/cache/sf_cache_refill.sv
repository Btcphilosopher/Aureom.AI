// =============================================================================
//  sf_cache_refill.sv  --  CacheForge refill controller (queue of line refills)
// -----------------------------------------------------------------------------
//  Fetches cache lines: for every accepted descriptor BEATS single-beat 128-bit READ
//  requests (line base + 16*b, byte enables FFFF, ascending) go out through the memory
//  port, and every successful beat is written into the data array as it returns.
//
//  DEPTH = 1  : one refill at a time (the blocking cache).
//  DEPTH > 1  : up to DEPTH line refills are queued; the reads of the next line are issued
//               while the responses of the previous line are still returning (the memory
//               link is in order, so the responses are matched to the descriptors in the
//               order the descriptors were issued).  This is what overlaps the memory latency
//               of several misses (memory-level parallelism).
//
//  Descriptor  : start_i with line_addr_i, set_i / way_i (destination), id_i (owner, e.g. the
//                MSHR index) and the requester's dom_i / attr_i.  start_i is ignored while
//                full_o is high.
//  Completion  : done_o pulses for one cycle when the LAST beat of the oldest descriptor has
//                been consumed; done_id_o is its id, err_o / status_o its result (the FIRST
//                non-OKAY beat status; err_o stays low if every beat was OKAY).  A beat whose
//                status is not OKAY is NOT written; all beats are always consumed so the link is
//                left clean.
//  Data array  : the write happens in the cycle the completion is accepted; da_wr_grant_i = 0
//                holds the completion off (response-channel back-pressure) so the owner of
//                the array can use the port.  da_wr_grant_i must not depend on m_cpl_valid_i.
// =============================================================================
`default_nettype none

module sf_cache_refill #(
  parameter int unsigned BEATS = 4,
  parameter int unsigned DEPTH = 1,
  parameter int unsigned SETS  = 128,
  parameter int unsigned WAYS  = 4,
  localparam int unsigned BEAT_W = (BEATS > 1) ? $clog2(BEATS) : 1,
  localparam int unsigned CW     = $clog2(BEATS + 1),
  localparam int unsigned IDX_W  = (SETS > 1) ? $clog2(SETS) : 1,
  localparam int unsigned WAY_W  = (WAYS > 1) ? $clog2(WAYS) : 1,
  localparam int unsigned ID_W   = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int unsigned DC_W   = $clog2(DEPTH + 1)
) (
  input  wire logic                     clk_i,
  input  wire logic                     rst_ni,
  // descriptor enqueue
  input  wire logic                     start_i,
  input  wire logic [63:0]              line_addr_i,
  input  wire logic [IDX_W-1:0]         set_i,
  input  wire logic [WAY_W-1:0]         way_i,
  input  wire logic [ID_W-1:0]          id_i,
  input  wire logic [7:0]               dom_i,
  input  wire logic [7:0]               attr_i,
  output logic                          full_o,
  output logic                          busy_o,
  // completion of the oldest descriptor
  output logic                          done_o,
  output logic [ID_W-1:0]               done_id_o,
  output logic                          err_o,
  output logic [3:0]                    status_o,
  // memory-port client
  output logic                          m_valid_o,
  output logic                          m_first_o,      // the presented request is beat 0 of its line
  output logic [ID_W-1:0]               m_id_o,         // descriptor id of the presented request
  input  wire logic                     m_ready_i,
  output sf_albion_pkg::sf_req_t        m_req_o,
  input  wire logic                     m_cpl_valid_i,
  output logic                          m_cpl_ready_o,
  input  sf_albion_pkg::sf_rsp_t        m_cpl_i,
  // data-array write
  input  wire logic                     da_wr_grant_i,
  output logic                          da_wr_en_o,
  output logic [WAY_W-1:0]              da_wr_way_o,
  output logic [IDX_W-1:0]              da_wr_set_o,
  output logic [BEAT_W-1:0]             da_wr_beat_o,
  output logic [127:0]                  da_wr_data_o
);
  if (BEATS < 1 || (BEATS & (BEATS - 1)) != 0 || BEATS > 16) begin : g_chk
    $error("sf_cache_refill: BEATS must be a power of two in 1..16");
  end
  if (DEPTH < 1 || DEPTH > 16) begin : g_chk_d
    $error("sf_cache_refill: DEPTH must be 1..16");
  end

  // ---- descriptor store (circular)
  logic [63:0]       d_addr [DEPTH];
  logic [7:0]        d_dom  [DEPTH];
  logic [7:0]        d_attr [DEPTH];
  logic [IDX_W-1:0]  d_set  [DEPTH];
  logic [WAY_W-1:0]  d_way  [DEPTH];
  logic [ID_W-1:0]   d_id   [DEPTH];

  logic [ID_W-1:0]   wr_ptr_q, iss_ptr_q, cpl_ptr_q;
  logic [DC_W-1:0]   cnt_q;          // descriptors queued and not yet completed
  logic [DC_W-1:0]   unis_q;         // descriptors with beats still to issue
  logic [CW-1:0]     iss_beat_q, cpl_beat_q;
  logic              acc_err_q;
  logic [3:0]        acc_stat_q;
  logic              done_q, err_q;
  logic [3:0]        status_q;
  logic [ID_W-1:0]   done_id_q;

  function automatic logic [ID_W-1:0] inc(input logic [ID_W-1:0] p);
    inc = (p == ID_W'(DEPTH - 1)) ? '0 : p + 1'b1;
  endfunction

  assign full_o  = (cnt_q == DC_W'(DEPTH));
  assign busy_o  = (cnt_q != '0);
  wire logic enq = start_i && !full_o;

  // ---- request side
  assign m_valid_o = (unis_q != '0);
  assign m_first_o = (iss_beat_q == '0);
  assign m_id_o    = d_id[iss_ptr_q];
  always_comb begin
    m_req_o      = '0;
    m_req_o.op   = sf_albion_pkg::SF_OP_READ;
    m_req_o.dom  = d_dom[iss_ptr_q];
    m_req_o.attr = d_attr[iss_ptr_q];
    m_req_o.addr = d_addr[iss_ptr_q] + 64'(iss_beat_q) * 64'd16;
    m_req_o.be   = 16'hFFFF;
  end
  wire logic iss_fire = m_valid_o && m_ready_i;
  wire logic iss_last = iss_fire && (iss_beat_q == CW'(BEATS - 1));

  // ---- completion side
  assign m_cpl_ready_o = (cnt_q != '0) && da_wr_grant_i;
  wire logic cpl_fire  = m_cpl_valid_i && m_cpl_ready_o;
  wire logic cpl_ok    = (m_cpl_i.status == sf_albion_pkg::SF_ST_OKAY);
  wire logic cpl_last  = cpl_fire && (cpl_beat_q == CW'(BEATS - 1));

  assign da_wr_en_o   = cpl_fire && cpl_ok;
  assign da_wr_way_o  = d_way[cpl_ptr_q];
  assign da_wr_set_o  = d_set[cpl_ptr_q];
  assign da_wr_beat_o = BEAT_W'(cpl_beat_q);
  assign da_wr_data_o = m_cpl_i.data;

  assign done_o    = done_q;
  assign done_id_o = done_id_q;
  assign err_o     = err_q;
  assign status_o  = status_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      wr_ptr_q   <= '0;
      iss_ptr_q  <= '0;
      cpl_ptr_q  <= '0;
      cnt_q      <= '0;
      unis_q     <= '0;
      iss_beat_q <= '0;
      cpl_beat_q <= '0;
      acc_err_q  <= 1'b0;
      acc_stat_q <= 4'd0;
      done_q     <= 1'b0;
      err_q      <= 1'b0;
      status_q   <= 4'd0;
      done_id_q  <= '0;
    end else begin
      done_q <= 1'b0;
      if (enq) wr_ptr_q <= inc(wr_ptr_q);
      case ({enq, cpl_last})
        2'b10:   cnt_q <= cnt_q + 1'b1;
        2'b01:   cnt_q <= cnt_q - 1'b1;
        default: cnt_q <= cnt_q;
      endcase
      case ({enq, iss_last})
        2'b10:   unis_q <= unis_q + 1'b1;
        2'b01:   unis_q <= unis_q - 1'b1;
        default: unis_q <= unis_q;
      endcase
      if (iss_fire) begin
        if (iss_last) begin iss_beat_q <= '0; iss_ptr_q <= inc(iss_ptr_q); end
        else          iss_beat_q <= iss_beat_q + 1'b1;
      end
      if (cpl_fire) begin
        if (!cpl_ok && !acc_err_q) begin
          acc_err_q  <= 1'b1;
          acc_stat_q <= m_cpl_i.status;
        end
        if (cpl_last) begin
          cpl_beat_q <= '0;
          cpl_ptr_q  <= inc(cpl_ptr_q);
          done_q     <= 1'b1;
          done_id_q  <= d_id[cpl_ptr_q];
          err_q      <= acc_err_q | !cpl_ok;
          status_q   <= acc_err_q ? acc_stat_q : (cpl_ok ? 4'd0 : m_cpl_i.status);
          acc_err_q  <= 1'b0;
          acc_stat_q <= 4'd0;
        end else begin
          cpl_beat_q <= cpl_beat_q + 1'b1;
        end
      end
    end
  end

  always_ff @(posedge clk_i) begin
    if (enq) begin
      d_addr[wr_ptr_q] <= line_addr_i;
      d_dom[wr_ptr_q]  <= dom_i;
      d_attr[wr_ptr_q] <= attr_i;
      d_set[wr_ptr_q]  <= set_i;
      d_way[wr_ptr_q]  <= way_i;
      d_id[wr_ptr_q]   <= id_i;
    end
  end

`ifndef SYNTHESIS
  always @(posedge clk_i) begin
    if (rst_ni && start_i && full_o) $error("sf_cache_refill: descriptor offered while full");
  end
`endif
endmodule

`default_nettype wire
