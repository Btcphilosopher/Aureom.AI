// =============================================================================
//  sf_cache_perf.sv  --  CacheForge performance counters
// -----------------------------------------------------------------------------
//  One CNT_W-bit counter per event of sf_cache_pkg::EV_* (hits, misses, refills,
//  evictions, writebacks, memory beats, bypass accesses, CMO lines, errors, ECC
//  events, stall cycles, busy cycles) plus four miss-latency registers:
//
//      PERF_LAT_SUM  sum of the sampled latencies (cycles)
//      PERF_LAT_MAX  largest sample
//      PERF_LAT_CNT  number of samples
//      PERF_LAT_MIN  smallest sample (all-ones until the first sample)
//
//  Average miss latency = SUM / CNT (software).  A latency sample is the number of
//  cycles from acceptance of a request that missed to the cycle its response is
//  loaded into the response register (sf_llc_cache supplies lat_valid_i/lat_cycles_i).
//
//  Memory bytes transferred = 16 * (EV_MEM_RD_BEAT + EV_MEM_WR_BEAT)  (bus bytes;
//  every memory-side request is one 16-byte beat).
//
//  clear_i zeroes everything synchronously (events in the clearing cycle are lost).
//  Counters wrap at 2^CNT_W (64-bit by default: no wrap in any realistic run).
//  All counters are read through cnt_o: counter i occupies bits [i*CNT_W +: CNT_W].
// =============================================================================
`default_nettype none

module sf_cache_perf #(
  parameter int unsigned CNT_W = 64,
  localparam int unsigned NEV   = sf_cache_pkg::EV_NUM,
  localparam int unsigned NTOT  = sf_cache_pkg::PERF_N_TOTAL
) (
  input  wire logic                    clk_i,
  input  wire logic                    rst_ni,
  input  wire logic                    clear_i,
  input  wire logic [NEV-1:0]          ev_i,
  input  wire logic                    lat_valid_i,
  input  wire logic [31:0]             lat_cycles_i,
  output logic [NTOT*CNT_W-1:0]        cnt_o
);
  logic [CNT_W-1:0] c_q [NTOT];

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      for (int i = 0; i < NTOT; i++) c_q[i] <= '0;
      c_q[sf_cache_pkg::PERF_LAT_MIN] <= '1;
    end else if (clear_i) begin
      for (int i = 0; i < NTOT; i++) c_q[i] <= '0;
      c_q[sf_cache_pkg::PERF_LAT_MIN] <= '1;
    end else begin
      for (int i = 0; i < NEV; i++) begin
        if (ev_i[i]) c_q[i] <= c_q[i] + 1'b1;
      end
      if (lat_valid_i) begin
        c_q[sf_cache_pkg::PERF_LAT_SUM] <= c_q[sf_cache_pkg::PERF_LAT_SUM] + CNT_W'(lat_cycles_i);
        c_q[sf_cache_pkg::PERF_LAT_CNT] <= c_q[sf_cache_pkg::PERF_LAT_CNT] + 1'b1;
        if (CNT_W'(lat_cycles_i) > c_q[sf_cache_pkg::PERF_LAT_MAX])
          c_q[sf_cache_pkg::PERF_LAT_MAX] <= CNT_W'(lat_cycles_i);
        if (CNT_W'(lat_cycles_i) < c_q[sf_cache_pkg::PERF_LAT_MIN])
          c_q[sf_cache_pkg::PERF_LAT_MIN] <= CNT_W'(lat_cycles_i);
      end
    end
  end

  always_comb begin
    for (int i = 0; i < NTOT; i++) cnt_o[i*CNT_W +: CNT_W] = c_q[i];
  end
endmodule

`default_nettype wire
