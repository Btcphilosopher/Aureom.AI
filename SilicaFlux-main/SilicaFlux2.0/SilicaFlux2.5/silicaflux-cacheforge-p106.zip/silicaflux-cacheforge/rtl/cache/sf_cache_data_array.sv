// =============================================================================
//  sf_cache_data_array.sv  --  CacheForge data array
// -----------------------------------------------------------------------------
//  One RAM per way (depth SETS*BEATS, width 128 data bits), each an
//  sf_sram_macro_wrapper (SRAMMacroBridge P79).  The word is two 64-bit lanes;
//  with ECC_EN = 1 each lane is its own SECDED codeword (ECC_MODE SECDED_LANE,
//  72 stored bits per lane, 144 per beat), so a lane can be rewritten alone.
//  Byte-granular partial writes are NOT done in the RAM: the controller does a
//  read-modify-write of the beat and writes the lanes back (an ECC granule is
//  64 bits, so a sub-lane write needs the old bytes anyway).
//
//  Address of a beat inside a way RAM:  index = set * BEATS + beat.
//
//  Read   : rd_en_i + (way, set, beat).  RAM_LATENCY cycles later rd_vld_o pulses
//           for one cycle; rd_data_o is the (corrected) 128-bit beat, rd_ce_o a
//           corrected single-bit error in either lane, rd_ue_o an uncorrectable
//           error in either lane (then rd_data_o holds the raw stored bits and
//           MUST NOT be used).
//  Write  : wr_en_i + (way, set, beat, data, lanes).  Lanes written = wr_lanes_i.
//  One access (read XOR write) per cycle; a write wins over a read.
//
//  Classification: SYNTHESIZABLE (storage via the wrapper).
// =============================================================================
`include "sf_sram_macro_defs.svh"
`default_nettype none

module sf_cache_data_array #(
  parameter int unsigned SETS        = 128,
  parameter int unsigned WAYS        = 4,
  parameter int unsigned BEATS       = 4,
  parameter int unsigned RAM_LATENCY = 1,
  parameter bit          ECC_EN      = 1'b1,
  parameter int unsigned MEMORY_TECH = 0,
  parameter int unsigned MACRO_ID    = 0,
  localparam int unsigned WAY_W      = (WAYS > 1) ? $clog2(WAYS) : 1,
  localparam int unsigned IDX_W      = (SETS > 1) ? $clog2(SETS) : 1,
  localparam int unsigned BEAT_W     = (BEATS > 1) ? $clog2(BEATS) : 1,
  localparam int unsigned DEPTH      = SETS * BEATS,
  localparam int unsigned DIDX_W     = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                clk_i,
  // read
  input  wire logic                rd_en_i,
  input  wire logic [WAY_W-1:0]    rd_way_i,
  input  wire logic [IDX_W-1:0]    rd_set_i,
  input  wire logic [BEAT_W-1:0]   rd_beat_i,
  output logic                     rd_vld_o,
  output logic [127:0]             rd_data_o,
  output logic                     rd_ce_o,
  output logic                     rd_ue_o,
  // write
  input  wire logic                wr_en_i,
  input  wire logic [WAY_W-1:0]    wr_way_i,
  input  wire logic [IDX_W-1:0]    wr_set_i,
  input  wire logic [BEAT_W-1:0]   wr_beat_i,
  input  wire logic [127:0]        wr_data_i,
  input  wire logic [1:0]          wr_lanes_i
);
  if (SETS < 2 || (SETS & (SETS - 1)) != 0) begin : g_chk_sets
    $error("sf_cache_data_array: SETS must be a power of two >= 2");
  end
  if (BEATS < 1 || (BEATS & (BEATS - 1)) != 0) begin : g_chk_beats
    $error("sf_cache_data_array: BEATS must be a power of two >= 1");
  end

  localparam int ECC_MODE_I = ECC_EN ? `SF_ECC_SECDED_LANE : `SF_ECC_NONE;

  wire logic [DIDX_W-1:0] rd_idx = DIDX_W'(rd_set_i) * DIDX_W'(BEATS) + DIDX_W'(rd_beat_i);
  wire logic [DIDX_W-1:0] wr_idx = DIDX_W'(wr_set_i) * DIDX_W'(BEATS) + DIDX_W'(wr_beat_i);

  logic [WAYS-1:0]  vld_w, cor_w, unc_w;
  logic [127:0]     dat_w [WAYS];

  for (genvar w = 0; w < WAYS; w++) begin : g_way
    wire logic sel_wr = wr_en_i && (wr_way_i == WAY_W'(w));
    wire logic sel_rd = rd_en_i && !wr_en_i && (rd_way_i == WAY_W'(w));
    logic [127:0] q;
    sf_sram_macro_wrapper #(
      .DATA_WIDTH(128), .DEPTH_WORDS(DEPTH), .READ_LATENCY(RAM_LATENCY),
      .BYTE_ENABLE(1), .BYTE_WIDTH(64),
      .MEMORY_TECH(MEMORY_TECH), .MACRO_ID(MACRO_ID),
      .ECC_MODE(ECC_MODE_I), .TEST_MODE(0), .POWER_CTRL(0)
    ) u_ram (
      .clk(clk_i), .ce(sel_wr | sel_rd), .we(sel_wr), .wmask(wr_lanes_i),
      .idx(sel_wr ? wr_idx : rd_idx), .wdata(wr_data_i),
      .rdata(q), .rd_vld(vld_w[w]), .ecc_corrected(cor_w[w]), .ecc_uncorrectable(unc_w[w]),
      .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_idx('0), .tst_wdata('0),
      .tst_rdata(), .tst_rd_vld(), .pwr_sleep(1'b0), .pwr_active()
    );
    assign dat_w[w] = q;
  end

  // exactly one way answers per read: AND-OR select on the per-way valid pulse
  always_comb begin
    rd_data_o = '0;
    for (int w = 0; w < WAYS; w++) begin
      rd_data_o = rd_data_o | (vld_w[w] ? dat_w[w] : 128'd0);
    end
  end
  assign rd_vld_o = |vld_w;
  assign rd_ce_o  = |(cor_w & vld_w);
  assign rd_ue_o  = |(unc_w & vld_w);

`ifndef SYNTHESIS
  always @(posedge clk_i) begin
    if (wr_en_i && rd_en_i) $error("sf_cache_data_array: read and write in the same cycle (write wins, read dropped)");
  end
`endif
endmodule

`default_nettype wire
