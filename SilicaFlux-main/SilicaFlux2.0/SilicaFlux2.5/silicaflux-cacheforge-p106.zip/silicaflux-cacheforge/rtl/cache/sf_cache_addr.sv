// =============================================================================
//  sf_cache_addr.sv  --  CacheForge address decomposition and reconstruction
// -----------------------------------------------------------------------------
//  Pure bit slicing for power-of-two geometries (no arithmetic, no division):
//
//      63 ......... PADDR_W | PADDR_W-1 ..... OFF_W+IDX_W | OFF_W+IDX_W-1 .. OFF_W | OFF_W-1 .. 4 | 3 .. 0
//      out_of_range_o        |          tag               |          set           |     beat      |  lane (0)
//                                                         \_________ line index ___/\______ byte offset in line ______/
//
//   beat_o   16-byte beat inside the line   (addr[OFF_W-1:4]; BEATS = LINE_BYTES/16)
//   set_o    set index                      (addr[OFF_W+IDX_W-1:OFF_W])
//   tag_o    tag                            (addr[PADDR_W-1:OFF_W+IDX_W])
//   line_o   line base address              (addr with the low OFF_W bits cleared)
//   out_of_range_o  any address bit at or above PADDR_W is set (the cache cannot represent it)
//
//   rbase_o  reconstruction: the line base address of (rtag_i, rset_i), i.e. what a victim's
//            writeback address is built from.  decompose(reconstruct(t, s)) == (t, s) for
//            every (t, s), and reconstruct(decompose(a)) == line_o for every in-range address
//            (both proved in formal/fv_cache_addr.sv).
//
//  addr_i[3:0] is not used: ALP v1 requires the address to be 16-byte aligned and the
//  cache rejects a request that is not (sf_albion_pkg::sf_req_check_bits) before it looks
//  at the slices.
//
//  Unsupported parameter combinations are rejected at elaboration: LINE_BYTES not a power
//  of two or outside 16..256, SETS not a power of two or < 2, PADDR_W outside 32..64, or a
//  geometry that leaves no tag bit.
// =============================================================================
`default_nettype none

module sf_cache_addr #(
  parameter int unsigned LINE_BYTES = 64,
  parameter int unsigned SETS       = 128,
  parameter int unsigned PADDR_W    = 64,
  localparam int unsigned OFF_W     = $clog2(LINE_BYTES),
  localparam int unsigned IDX_W     = $clog2(SETS),
  localparam int unsigned TAG_W     = PADDR_W - OFF_W - IDX_W,
  localparam int unsigned BEATS     = LINE_BYTES / 16,
  localparam int unsigned BEAT_W    = (BEATS > 1) ? $clog2(BEATS) : 1
) (
  input  wire logic [63:0]         addr_i,
  output logic [BEAT_W-1:0]        beat_o,
  output logic [IDX_W-1:0]         set_o,
  output logic [TAG_W-1:0]         tag_o,
  output logic [63:0]              line_o,
  output logic                     out_of_range_o,
  input  wire logic [TAG_W-1:0]    rtag_i,
  input  wire logic [IDX_W-1:0]    rset_i,
  output logic [63:0]              rbase_o
);
  if (LINE_BYTES < 16 || LINE_BYTES > 256 || (LINE_BYTES & (LINE_BYTES - 1)) != 0) begin : g_e_line
    $error("sf_cache_addr: LINE_BYTES must be a power of two in 16..256");
  end
  if (SETS < 2 || (SETS & (SETS - 1)) != 0) begin : g_e_sets
    $error("sf_cache_addr: SETS must be a power of two >= 2");
  end
  if (PADDR_W < 32 || PADDR_W > 64) begin : g_e_pa
    $error("sf_cache_addr: PADDR_W must be 32..64");
  end
  if (PADDR_W <= OFF_W + IDX_W) begin : g_e_tag
    $error("sf_cache_addr: PADDR_W too small, the tag would be empty");
  end

  if (BEATS > 1) begin : g_beat
    assign beat_o = addr_i[4 +: BEAT_W];
  end else begin : g_nobeat
    assign beat_o = '0;
  end
  assign set_o = addr_i[OFF_W +: IDX_W];
  assign tag_o = addr_i[OFF_W + IDX_W +: TAG_W];

  logic [63:0] low_mask;
  assign low_mask = (64'd1 << OFF_W) - 64'd1;
  assign line_o   = addr_i & ~low_mask;

  if (PADDR_W < 64) begin : g_oor
    assign out_of_range_o = |addr_i[63:PADDR_W];
  end else begin : g_nooor
    assign out_of_range_o = 1'b0;
  end

  logic [63:0] rt, rs;
  assign rt      = {{(64 - TAG_W){1'b0}}, rtag_i};
  assign rs      = {{(64 - IDX_W){1'b0}}, rset_i};
  assign rbase_o = (rt << (OFF_W + IDX_W)) | (rs << OFF_W);

  // addr_i[OFF_W-1:0] below the beat field is intentionally unused (lane bits, ALP-aligned)
  logic unused;
  assign unused = &{1'b0, addr_i[3:0]};
endmodule

`default_nettype wire
