// =============================================================================
//  sf_cache_replacement.sv  --  CacheForge replacement policy (victim choice + metadata)
// -----------------------------------------------------------------------------
//  Deterministic.  Two policies (parameter POLICY, see sf_cache_pkg):
//
//   REPL_PLRU (1) - tree pseudo-LRU.  WAYS-1 bits per set, heap-indexed:
//        node 0 is the root, node n has children 2n+1 (left) and 2n+2 (right);
//        leaves are ways 0..WAYS-1 left to right.  A node bit of 0 means "the
//        LEFT subtree is least recently used", 1 means the right one.
//        victim      : walk from the root, at node n with bit b go to child 2n+1+b.
//        touch(w)    : every node on the path to leaf w is set to point AWAY from w
//                      (w went left -> bit 1, w went right -> bit 0).
//        reset state : all zero -> victim way 0.
//   REPL_RR (0)   - one log2(WAYS)-bit counter per set.
//        victim      : the counter.
//        touch(w)    : only when touch_alloc_i (install / writeback-error): counter <= w+1
//                      (mod WAYS).  A HIT does not move the counter.
//
//  Invalid ways are preferred over the policy: the victim is the lowest-numbered
//  invalid way when q_valid_i has a zero bit, else the policy victim.  The policy
//  therefore only ever chooses among valid ways.
//
//  Corner cases (all asserted in formal/fv_replacement.sv):
//   * WAYS = 1: no state, victim is always way 0.
//   * the victim index is always < WAYS, whatever the metadata value (so a
//     corrupted metadata bit can change PERFORMANCE but never correctness);
//   * immediately after touch(w) the policy victim is never w (WAYS >= 2, PLRU).
//
//  The metadata is held in flip-flops (reset) and is NOT ECC protected; see
//  docs/04_ecc_and_errors.md for why that is acceptable.
// =============================================================================
`default_nettype none

module sf_cache_replacement #(
  parameter int unsigned SETS   = 128,
  parameter int unsigned WAYS   = 4,
  parameter int unsigned POLICY = 1,
  localparam int unsigned IDX_W = (SETS > 1) ? $clog2(SETS) : 1,
  localparam int unsigned WAY_W = (WAYS > 1) ? $clog2(WAYS) : 1,
  localparam int unsigned ST_W  = (POLICY == 1) ? ((WAYS > 1) ? WAYS - 1 : 1) : WAY_W
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  // query (combinational)
  input  wire logic [IDX_W-1:0]  q_set_i,
  input  wire logic [WAYS-1:0]   q_valid_i,
  output logic [WAY_W-1:0]       victim_o,
  output logic                   victim_invalid_o,   // victim chosen because a way was invalid
  output logic [WAY_W-1:0]       policy_victim_o,    // what the policy alone would choose (debug / formal)
  // update
  input  wire logic              touch_en_i,
  input  wire logic [IDX_W-1:0]  touch_set_i,
  input  wire logic [WAY_W-1:0]  touch_way_i,
  input  wire logic              touch_alloc_i
);
  if (SETS < 2 || (SETS & (SETS - 1)) != 0) begin : g_chk_sets
    $error("sf_cache_replacement: SETS must be a power of two >= 2");
  end
  if (WAYS < 1 || WAYS > 16 || (WAYS & (WAYS - 1)) != 0) begin : g_chk_ways
    $error("sf_cache_replacement: WAYS must be a power of two in 1..16");
  end
  if (POLICY > 1) begin : g_chk_pol
    $error("sf_cache_replacement: POLICY must be 0 (RR) or 1 (PLRU)");
  end

  logic [ST_W-1:0] st_q [SETS];

  // ------------------------------------------------------------ policy victim
  logic [WAY_W-1:0] pol_vic;
  logic [ST_W-1:0]  q_st;
  assign q_st = st_q[q_set_i];

  if (WAYS == 1) begin : g_v1
    assign pol_vic = '0;
  end else if (POLICY == 1) begin : g_vplru
    always_comb begin
      int unsigned node;
      node = 0;
      for (int l = 0; l < WAY_W; l++) begin
        node = 2 * node + 1 + (q_st[node] ? 1 : 0);
      end
      pol_vic = WAY_W'(node - (WAYS - 1));
    end
  end else begin : g_vrr
    assign pol_vic = q_st[WAY_W-1:0];
  end

  assign policy_victim_o = pol_vic;

  // ------------------------------------------------------------ invalid-first
  logic             any_inv;
  logic [WAY_W-1:0] first_inv;
  always_comb begin
    any_inv   = 1'b0;
    first_inv = '0;
    for (int w = WAYS - 1; w >= 0; w--) begin
      if (!q_valid_i[w]) begin
        any_inv   = 1'b1;
        first_inv = WAY_W'(w);
      end
    end
  end
  assign victim_o         = any_inv ? first_inv : pol_vic;
  assign victim_invalid_o = any_inv;

  // ------------------------------------------------------------ metadata update
  if (WAYS == 1) begin : g_u1
    // no state; keep the array constant so the tool prunes it
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        for (int s = 0; s < SETS; s++) st_q[s] <= '0;
      end
    end
  end else if (POLICY == 1) begin : g_uplru
    // next metadata of the touched set: every node on the path to the touched leaf points AWAY from it
    logic [ST_W-1:0] touch_nxt;
    always_comb begin
      int unsigned node;
      touch_nxt = st_q[touch_set_i];
      node      = 0;
      for (int l = 0; l < WAY_W; l++) begin
        touch_nxt[node] = ~touch_way_i[WAY_W-1-l];
        node            = 2 * node + 1 + (touch_way_i[WAY_W-1-l] ? 1 : 0);
      end
    end
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        for (int s = 0; s < SETS; s++) st_q[s] <= '0;
      end else if (touch_en_i) begin
        st_q[touch_set_i] <= touch_nxt;
      end
    end
  end else begin : g_urr
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        for (int s = 0; s < SETS; s++) st_q[s] <= '0;
      end else if (touch_en_i && touch_alloc_i) begin
        st_q[touch_set_i] <= touch_way_i + 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
