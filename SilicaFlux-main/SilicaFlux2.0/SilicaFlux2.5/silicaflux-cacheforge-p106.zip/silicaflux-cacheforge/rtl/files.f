// CacheForge RTL file list (relative to the package root).  Include dirs: see rtl/incdirs.f
// ---- AlbionCore (vendored unmodified): ALP v1 package and stages
third_party/albioncore/rtl/sf_albion_pkg.sv
third_party/albioncore/rtl/sf_albion_skid.sv
third_party/albioncore/rtl/sf_albion_fifo.sv
// ---- SRAMMacroBridge P79 (vendored unmodified): ECC + backends + wrapper
third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_enc.sv
third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_dec.sv
third_party/srammacrobridge/rtl/backends/sf_sram_be_generic.sv
third_party/srammacrobridge/rtl/backends/sf_sram_be_fpga.sv
third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_ihp1p.sv
third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_gf180.sv
third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_sky130.sv
third_party/srammacrobridge/rtl/backends/asic/stubs/sf_sram_macro_blackboxes.sv
third_party/srammacrobridge/rtl/backends/sf_sram_be_asic.sv
third_party/srammacrobridge/rtl/sf_sram_macro_wrapper.sv
// ---- CacheForge
rtl/cache/sf_cache_pkg.sv
rtl/cache/sf_cache_addr.sv
rtl/cache/sf_cache_replacement.sv
rtl/cache/sf_cache_tag_array.sv
rtl/cache/sf_cache_data_array.sv
rtl/cache/sf_cache_mshr.sv
rtl/cache/sf_cache_memport.sv
rtl/cache/sf_cache_refill.sv
rtl/cache/sf_cache_writeback.sv
rtl/cache/sf_cache_perf.sv
rtl/cache/sf_llc_cache.sv
