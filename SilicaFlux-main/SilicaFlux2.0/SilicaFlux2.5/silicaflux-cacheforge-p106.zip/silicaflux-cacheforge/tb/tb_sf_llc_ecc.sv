// =============================================================================
//  tb_sf_llc_ecc.sv  --  directed ECC / error-policy / reset tests for sf_llc_cache
// -----------------------------------------------------------------------------
//  Faults are injected into the RAW stored codewords of the tag and data RAMs by
//  hierarchical reference (the generic backend array of sf_sram_macro_wrapper), so a
//  single-bit flip is a real correctable upset and two flips in one 64-bit lane / one
//  tag entry are a real uncorrectable upset.  Expected behaviour is the policy of
//  docs/04_ecc_and_errors.md:
//
//   T1  data CE  on a read hit    : corrected data, meta.corrected, scrub repairs the stored word
//   T2  data CE  on a partial write: merged correctly, stored word repaired
//   T3  data UE  on a CLEAN line  : invalidated and refetched transparently (data correct, OKAY)
//   T4  data UE  on a DIRTY line  : ECC_UNCORR + poisoned, zero data; poison is never laundered by
//                                   a partial write; a full-beat write repairs the beat
//   T5  dirty UE beat at eviction : that beat is NOT written to memory (memory keeps the old
//                                   value), the other beats are; event + sticky flag
//   T6  tag CE                    : hit still works, corrected flag, entry scrubbed
//   T7  tag UE                    : the entry is untrusted -> treated as invalid (miss + refill);
//                                   error event raised
//   T8  persistent UE on a clean line : one refetch only, then ECC_UNCORR (no livelock)
//   T9  reset in the middle of a refill / writeback / CMO / pending response: clean recovery,
//       no response for pre-reset requests, cache invalid afterwards, memory still consistent
//   T10 ECC_EN = 0 build elaborates (checked by the regression)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_llc_ecc;
  parameter int ECC         = 1;
  parameter int RAM_LAT     = 1;
  parameter int MEM_MAX_OUT = 4;
  parameter int P_STRESS    = 1;     // 1: random back-pressure / latency
  parameter int NUM_MSHR    = 1;

  localparam int SETS = 128, WAYS = 4, BEATS = 4;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic                      req_valid, req_ready, rsp_valid, rsp_ready;
  sf_albion_pkg::sf_req_t    req;
  sf_albion_pkg::sf_rsp_t    rsp;
  logic                      mreq_valid, mreq_ready, mrsp_valid, mrsp_ready;
  sf_albion_pkg::sf_req_t    mreq;
  sf_albion_pkg::sf_rsp_t    mrsp;
  logic                      cmo_valid, cmo_ready, cmo_busy, cmo_done, cmo_err, cmo_all;
  logic [1:0]                cmo_op;
  logic [63:0]               cmo_addr, cmo_size;
  logic [31:0]               cmo_lines;
  logic                      init_done, busy, err_clear, perf_clear, proto_err;
  logic [sf_cache_pkg::ERR_NUM-1:0] err_evt, err_sticky;
  logic [63:0]               err_addr, caps;
  localparam int CNT_W = 64;
  logic [sf_cache_pkg::PERF_N_TOTAL*CNT_W-1:0] perf;

  sf_llc_cache #(.RAM_LATENCY(RAM_LAT), .MEM_MAX_OUT(MEM_MAX_OUT), .ECC_EN(ECC != 0), .NUM_MSHR(NUM_MSHR)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(req_valid), .req_ready_o(req_ready), .req_i(req),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp),
    .mreq_valid_o(mreq_valid), .mreq_ready_i(mreq_ready), .mreq_o(mreq),
    .mrsp_valid_i(mrsp_valid), .mrsp_ready_o(mrsp_ready), .mrsp_i(mrsp),
    .cmo_valid_i(cmo_valid), .cmo_ready_o(cmo_ready), .cmo_op_i(cmo_op), .cmo_all_i(cmo_all),
    .cmo_addr_i(cmo_addr), .cmo_size_i(cmo_size),
    .cmo_busy_o(cmo_busy), .cmo_done_o(cmo_done), .cmo_lines_o(cmo_lines), .cmo_err_o(cmo_err),
    .cfg_en_i(1'b1), .cfg_nc_en_i(1'b0), .cfg_nc_base_i(64'd0), .cfg_nc_limit_i(64'd0),
    .cfg_wb_dom_i(8'h01), .cfg_wb_attr_i(8'h04),
    .init_done_o(init_done), .busy_o(busy), .err_evt_o(err_evt), .err_sticky_o(err_sticky),
    .err_clear_i(err_clear), .err_addr_o(err_addr), .perf_clear_i(perf_clear), .perf_o(perf),
    .caps_o(caps), .proto_err_o(proto_err)
  );

  sf_tb_alp_mem #(.LAT_MIN(1), .LAT_MAX(P_STRESS ? 6 : 1), .P_RDY(P_STRESS ? 60 : 100), .P_VAL(P_STRESS ? 70 : 100),
                  .LINE_BYTES(64), .MAX_OUT(MEM_MAX_OUT)) mem (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(mreq_valid), .req_ready_o(mreq_ready), .req_i(mreq),
    .rsp_valid_o(mrsp_valid), .rsp_ready_i(mrsp_ready), .rsp_o(mrsp)
  );

  logic [15:0] up_out, dn_out;
  sf_albion_link_checker #(.MAX_OUTSTANDING((NUM_MSHR > 1) ? 2 * NUM_MSHR : 1), .CHECK_LEGALITY(1'b1)) u_chk_up (
    .clk_i(clk), .rst_ni(rst_n), .req_valid_i(req_valid), .req_ready_i(req_ready), .req_i(req),
    .rsp_valid_i(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_i(rsp), .waive_req_i(1'b0), .outstanding_o(up_out));
  sf_albion_link_checker #(.MAX_OUTSTANDING(MEM_MAX_OUT), .CHECK_LEGALITY(1'b0)) u_chk_dn (
    .clk_i(clk), .rst_ni(rst_n), .req_valid_i(mreq_valid), .req_ready_i(mreq_ready), .req_i(mreq),
    .rsp_valid_i(mrsp_valid), .rsp_ready_i(mrsp_ready), .rsp_i(mrsp), .waive_req_i(1'b0), .outstanding_o(dn_out));

  // ---------------------------------------------------------------- bookkeeping
  int unsigned errors = 0, checks = 0;
  task automatic check(input bit cond, input string msg);
    begin
      checks++;
      if (!cond) begin errors++; if (errors <= 30) $display("TB ERROR @%0t: %s", $time, msg); end
    end
  endtask

  // ---------------------------------------------------------------- monitors (rising edge) / driver (falling edge)
  logic up_fire_q = 1'b0;
  logic rsp_got = 1'b0;
  sf_albion_pkg::sf_rsp_t last_rsp;
  int unsigned evt_cnt [sf_cache_pkg::ERR_NUM];
  bit   cmo_done_seen = 1'b0;
  logic [31:0] cmo_lines_cap;
  logic        cmo_err_cap;
  always @(posedge clk) begin
    up_fire_q <= rst_n && req_valid && req_ready;
    if (rst_n && rsp_valid && rsp_ready) begin last_rsp = rsp; rsp_got = 1'b1; end
    for (int i = 0; i < sf_cache_pkg::ERR_NUM; i++) if (rst_n && err_evt[i]) evt_cnt[i]++;
    if (rst_n && cmo_done) begin cmo_done_seen = 1'b1; cmo_lines_cap = cmo_lines; cmo_err_cap = cmo_err; end
  end
  bit hold_rsp = 1'b0;     // T9b: hold the upstream response channel so that responses queue up
  always @(negedge clk) rsp_ready = (rst_n && !hold_rsp) ? ((P_STRESS != 0) ? (mem.rnd(99) < 60) : 1'b1) : 1'b0;

  task automatic idle(input int n);
    repeat (n) @(negedge clk);
  endtask

  // one blocking transaction through the upstream link
  task automatic xact(input logic [3:0] op, input logic [63:0] addr, input logic [15:0] be, input logic [127:0] data,
                      output sf_albion_pkg::sf_rsp_t r, input logic [7:0] tag = 8'h5A);
    int guard;
    begin
      rsp_got = 1'b0;
      req = '0; req.op = op; req.tag = tag; req.dom = 8'h10; req.attr = 8'h00; req.addr = addr; req.be = be; req.data = data;
      req_valid = 1'b1;
      do @(negedge clk); while (!up_fire_q);
      req_valid = 1'b0;
      guard = 0;
      while (!rsp_got && guard < 100000) begin @(negedge clk); guard++; end
      check(rsp_got, "no response (timeout)");
      r = last_rsp;
      check(r.tag == tag, "response tag echo");
      @(negedge clk);
    end
  endtask

  task automatic wr(input logic [63:0] a, input logic [127:0] d, input logic [15:0] be, output sf_albion_pkg::sf_rsp_t r);
    xact(sf_albion_pkg::SF_OP_WRITE, a, be, d, r);
  endtask
  task automatic rd(input logic [63:0] a, input logic [15:0] be, output sf_albion_pkg::sf_rsp_t r);
    xact(sf_albion_pkg::SF_OP_READ, a, be, 128'd0, r);
  endtask

  task automatic wait_idle();
    do @(negedge clk); while (busy || mem.outstanding() != 0);
    idle(2);
  endtask

  task automatic cmo(input logic [1:0] op, input bit all, input logic [63:0] a, input logic [63:0] sz);
    begin
      wait_idle();
      cmo_op = op; cmo_all = all; cmo_addr = a; cmo_size = sz; cmo_done_seen = 1'b0;
      cmo_valid = 1'b1;
      do @(negedge clk); while (!cmo_busy);
      cmo_valid = 1'b0;
      while (!cmo_done_seen) @(negedge clk);
      idle(2);
    end
  endtask

  // ---------------------------------------------------------------- helpers: raw array access
  localparam int PLW_D = 72;      // 64 data + 8 check
  function automatic int dset(input logic [63:0] a); dset = int'((a >> 6) & 64'(SETS - 1)); endfunction
  function automatic int dbeat(input logic [63:0] a); dbeat = int'((a >> 4) & 64'(BEATS - 1)); endfunction

  // flip raw bit `b` (0..143) of the data word of (way, address)
  task automatic flip_data(input int way, input logic [63:0] a, input int b);
    int idx;
    begin
      idx = dset(a) * BEATS + dbeat(a);
      case (way)
        0: dut.u_data.g_way[0].u_ram.g_gen.u_be.mem[idx][b] = ~dut.u_data.g_way[0].u_ram.g_gen.u_be.mem[idx][b];
        1: dut.u_data.g_way[1].u_ram.g_gen.u_be.mem[idx][b] = ~dut.u_data.g_way[1].u_ram.g_gen.u_be.mem[idx][b];
        2: dut.u_data.g_way[2].u_ram.g_gen.u_be.mem[idx][b] = ~dut.u_data.g_way[2].u_ram.g_gen.u_be.mem[idx][b];
        default: dut.u_data.g_way[3].u_ram.g_gen.u_be.mem[idx][b] = ~dut.u_data.g_way[3].u_ram.g_gen.u_be.mem[idx][b];
      endcase
    end
  endtask

  function automatic logic [143:0] raw_data(input int way, input logic [63:0] a);
    int idx;
    begin
      idx = dset(a) * BEATS + dbeat(a);
      case (way)
        0: raw_data = dut.u_data.g_way[0].u_ram.g_gen.u_be.mem[idx];
        1: raw_data = dut.u_data.g_way[1].u_ram.g_gen.u_be.mem[idx];
        2: raw_data = dut.u_data.g_way[2].u_ram.g_gen.u_be.mem[idx];
        default: raw_data = dut.u_data.g_way[3].u_ram.g_gen.u_be.mem[idx];
      endcase
    end
  endfunction

  task automatic flip_tag(input int way, input logic [63:0] a, input int b);
    int s;
    begin
      s = dset(a);
      case (way)
        0: dut.u_tag.g_way[0].u_ram.g_gen.u_be.mem[s][b] = ~dut.u_tag.g_way[0].u_ram.g_gen.u_be.mem[s][b];
        1: dut.u_tag.g_way[1].u_ram.g_gen.u_be.mem[s][b] = ~dut.u_tag.g_way[1].u_ram.g_gen.u_be.mem[s][b];
        2: dut.u_tag.g_way[2].u_ram.g_gen.u_be.mem[s][b] = ~dut.u_tag.g_way[2].u_ram.g_gen.u_be.mem[s][b];
        default: dut.u_tag.g_way[3].u_ram.g_gen.u_be.mem[s][b] = ~dut.u_tag.g_way[3].u_ram.g_gen.u_be.mem[s][b];
      endcase
    end
  endtask

  function automatic logic [127:0] pat(input logic [63:0] a, input logic [7:0] salt);
    logic [127:0] w;
    begin
      for (int i = 0; i < 16; i++) w[8*i +: 8] = salt ^ a[11:4] ^ 8'(i * 17);
      pat = w;
    end
  endfunction

  function automatic int cnt(input int idx);
    cnt = int'(perf[idx*CNT_W +: CNT_W]);
  endfunction

  // ---------------------------------------------------------------- persistent corruption (T8)
  bit          stuck_en = 1'b0;
  int          stuck_way;
  logic [63:0] stuck_addr;
  always @(negedge clk) begin
    if (stuck_en) begin
      flip_data_if_clean(stuck_way, stuck_addr);
    end
  end
  // force two bits of the raw word to a fixed wrong value (stuck-at behaviour): re-applied every cycle
  task automatic flip_data_if_clean(input int way, input logic [63:0] a);
    int idx;
    begin
      idx = dset(a) * BEATS + dbeat(a);
      case (way)
        0: begin dut.u_data.g_way[0].u_ram.g_gen.u_be.mem[idx][3] = 1'b1; dut.u_data.g_way[0].u_ram.g_gen.u_be.mem[idx][5] = 1'b1; end
        default: begin dut.u_data.g_way[0].u_ram.g_gen.u_be.mem[idx][3] = 1'b1; dut.u_data.g_way[0].u_ram.g_gen.u_be.mem[idx][5] = 1'b1; end
      endcase
      // lane 0 data bits 3 and 5 stuck at 1; the written value has them as 0 in the pattern used by T8
    end
  endtask

  // ---------------------------------------------------------------- the tests
  sf_albion_pkg::sf_rsp_t r;
  logic [63:0] A0, A1, A2;
  logic [127:0] w;
  int  n0, n1;

  initial begin
    req_valid = 1'b0; req = '0; rsp_ready = 1'b0;
    cmo_valid = 1'b0; cmo_op = '0; cmo_all = 1'b0; cmo_addr = '0; cmo_size = '0;
    err_clear = 1'b0; perf_clear = 1'b0;
    for (int i = 0; i < sf_cache_pkg::ERR_NUM; i++) evt_cnt[i] = 0;
    mem.seed_lfsr = 32'hBADC0DE1;
    repeat (6) @(negedge clk);
    rst_n = 1'b1;
    do @(negedge clk); while (!init_done);
    idle(3);

    // ================= T0: capability word describes what the block implements =================================
    check(caps[63:60] == 4'd1 && caps[59:56] == 4'd0, "T0 caps: ALP 1.0");
    check(caps[55:48] == 8'd64, "T0 caps: 64-bit address");
    check(caps[47:44] == 4'd4, "T0 caps: 16-byte data word");
    check(caps[43:40] == 4'd8 && caps[39:36] == 4'd8, "T0 caps: 8-bit tag / domain");
    check(caps[31:16] == 16'((NUM_MSHR > 1) ? 2 * NUM_MSHR : 1), $sformatf("T0 caps: max_outstanding %0d", caps[31:16]));
    check(caps[15:0] == ((ECC != 0) ? 16'h0033 : 16'h0003), $sformatf("T0 caps: features %h (READ|WRITE%s)", caps[15:0], ECC != 0 ? "|ECC|POISON" : ""));

    if (ECC == 0) begin
      $display("TB PASS: ecc build without ECC elaborates and runs (caps checked, no fault tests)");
      $finish;
    end

    // ================= T1: data CE on a read hit, scrub repairs the stored word ==================
    A0 = 64'h0000_0000_0010_0040;                 // set 1, way 0 (first allocation), beat 0
    w = pat(A0, 8'h11);
    wr(A0, w, 16'hFFFF, r);                        // write miss -> refill -> merge; line dirty
    check(r.status == 4'd0, "T1 write status");
    flip_data(0, A0, 3);                           // 1 bit in lane 0 data
    rd(A0, 16'hFFFF, r);
    check(r.status == 4'd0 && r.data == w, $sformatf("T1 corrected read data %h exp %h st=%h", r.data, w, r.status));
    check(r.meta[3] == 1'b1, "T1 meta.corrected set");
    check(evt_cnt[sf_cache_pkg::ERR_DATA_CE] == 1, "T1 ERR_DATA_CE event once");
    wait_idle();
    rd(A0, 16'hFFFF, r);
    check(r.data == w && r.meta[3] == 1'b0, "T1 second read clean (scrubbed)");
    check(evt_cnt[sf_cache_pkg::ERR_DATA_CE] == 1, "T1 no second CE event (scrub repaired the stored word)");
    flip_data(0, A0, 70);                          // flip a CHECK bit of lane 0 (also a correctable error)
    rd(A0, 16'hFFFF, r);
    check(r.data == w && r.meta[3] == 1'b1, "T1b check-bit error corrected");

    // ================= T2: CE found while merging a partial write =================================
    A1 = 64'h0000_0000_0010_0050;                  // same line, beat 1
    wr(A1, pat(A1, 8'h22), 16'hFFFF, r);
    flip_data(0, A1, 100);                         // lane 1 data bit
    wr(A1, 128'hAAAA_BBBB_CCCC_DDDD_0000_0000_0000_0000, 16'hFF00, r);   // partial: upper 8 bytes
    check(r.status == 4'd0, "T2 partial write status");
    wait_idle();
    rd(A1, 16'hFFFF, r);
    check(r.status == 4'd0 && r.data[127:64] == 64'hAAAA_BBBB_CCCC_DDDD && r.data[63:0] == pat(A1, 8'h22)[63:0],
          $sformatf("T2 merged data %h", r.data));

    // ================= T3: UE on a CLEAN line -> transparent refetch ===============================
    A2 = 64'h0000_0000_0020_0080;                  // set 2, beat 0, way 0
    rd(A2, 16'hFFFF, r);                           // cold read: clean line
    w = r.data;
    n0 = mem.tr_addr.size();
    flip_data(0, A2, 3); flip_data(0, A2, 5);      // two bits in lane 0 -> uncorrectable
    rd(A2, 16'hFFFF, r);
    check(r.status == 4'd0 && r.data == w, $sformatf("T3 refetched data %h exp %h st=%h", r.data, w, r.status));
    check(evt_cnt[sf_cache_pkg::ERR_DATA_UE_CLEAN] == 1, "T3 clean-UE refetch event");
    wait_idle();
    check(mem.tr_addr.size() - n0 == BEATS, $sformatf("T3 memory refetched exactly one line (%0d beats)", mem.tr_addr.size() - n0));
    rd(A2, 16'hFFFF, r);
    check(r.status == 4'd0 && r.data == w, "T3 line healthy afterwards");

    // ================= T4: UE on a DIRTY line -> poison, never laundered =========================
    A0 = 64'h0000_0000_0030_00C0;                  // set 3
    w = pat(A0, 8'h44);
    wr(A0, w, 16'hFFFF, r);                        // dirty, way 0
    flip_data(0, A0, 3); flip_data(0, A0, 5);
    rd(A0, 16'hFFFF, r);
    check(r.status == sf_albion_pkg::SF_ST_ECC_UNCORR, $sformatf("T4 read status %h", r.status));
    check(r.meta[2] == 1'b1 && r.data == 128'd0, "T4 poisoned, zero data");
    check(evt_cnt[sf_cache_pkg::ERR_DATA_UE_POIS] == 1, "T4 poison event");
    wr(A0, 128'h1111, 16'h000F, r);                // partial write to the poisoned beat
    check(r.status == sf_albion_pkg::SF_ST_ECC_UNCORR, "T4 partial write to poisoned beat is refused");
    wait_idle();
    rd(A0, 16'hFFFF, r);
    check(r.status == sf_albion_pkg::SF_ST_ECC_UNCORR, "T4 poison persists (not laundered)");
    wr(A0, pat(A0, 8'h45), 16'hFFFF, r);           // full-beat write replaces the beat
    check(r.status == 4'd0, "T4 full-beat write accepted");
    rd(A0, 16'hFFFF, r);
    check(r.status == 4'd0 && r.data == pat(A0, 8'h45), "T4 beat healthy after a full write");

    // ================= T5: dirty UE beat at eviction: not written, others are =====================
    begin
      logic [63:0] B [5];
      logic [127:0] oldmem;
      B[0] = 64'h0000_0000_0040_0100;               // set 4 ; same set, tags differ: + k*0x2000 (128 sets * 64 B)
      for (int k = 1; k < 5; k++) B[k] = B[0] + 64'(k) * 64'h2000;
      for (int k = 0; k < 4; k++) begin             // fill all 4 ways dirty (4 beats each: write beat 0 and 2 only)
        wr(B[k],       pat(B[k], 8'h50 + 8'(k)),       16'hFFFF, r);
        wr(B[k] + 8'h20, pat(B[k] + 8'h20, 8'h60 + 8'(k)), 16'hFFFF, r);
      end
      oldmem = mem.read_word(B[0] + 64'h20);        // memory still holds the initial pattern for beat 2 of line 0
      flip_data(0, B[0] + 64'h20, 3); flip_data(0, B[0] + 64'h20, 5);   // UE in beat 2 of the line in way 0
      // touch ways 1..3 so that way 0 is the PLRU victim, then miss on a 5th line of the set
      for (int k = 1; k < 4; k++) begin rd(B[k], 16'hFFFF, r); end
      n0 = mem.tr_addr.size();
      rd(B[4], 16'hFFFF, r);                        // evicts line 0 (dirty): beats 0,1,3 written, beat 2 lost
      wait_idle();
      check(r.status == 4'd0, "T5 miss after dirty-UE eviction completes OK");
      check(evt_cnt[sf_cache_pkg::ERR_DIRTY_LOST] == 1, $sformatf("T5 dirty-lost event count %0d", evt_cnt[sf_cache_pkg::ERR_DIRTY_LOST]));
      check(mem.read_word(B[0]) == pat(B[0], 8'h50), "T5 beat 0 reached memory");
      check(mem.read_word(B[0] + 64'h20) == oldmem, "T5 corrupted beat 2 was NOT written to memory (old value kept)");
      check((err_sticky >> sf_cache_pkg::ERR_DIRTY_LOST) & 1'b1, "T5 sticky flag set");
    end

    // ================= T10: err_clear_i / perf_clear_i ==================================================
    check(((err_sticky >> sf_cache_pkg::ERR_DIRTY_LOST) & 1'b1) == 1'b1, "T10 sticky flag still set before clear");
    check(cnt(sf_cache_pkg::EV_RD_MISS) > 0 && cnt(sf_cache_pkg::PERF_LAT_CNT) > 0, "T10 counters non-zero before clear");
    err_clear = 1'b1; @(negedge clk); err_clear = 1'b0; @(negedge clk);
    check(err_sticky == '0, "T10 err_clear_i clears the sticky flags");
    perf_clear = 1'b1; @(negedge clk); perf_clear = 1'b0; @(negedge clk);
    check(cnt(sf_cache_pkg::EV_RD_MISS) == 0 && cnt(sf_cache_pkg::EV_REFILL) == 0 && cnt(sf_cache_pkg::PERF_LAT_CNT) == 0 && cnt(sf_cache_pkg::PERF_LAT_SUM) == 0,
          "T10 perf_clear_i zeroes the counters");
    check(perf[sf_cache_pkg::PERF_LAT_MIN*CNT_W +: CNT_W] == {CNT_W{1'b1}}, "T10 min-latency register returns to all-ones");

    // ================= T6: tag CE =================================================================
    A0 = 64'h0000_0000_0050_0140;                   // set 5, way 0
    w = pat(A0, 8'h66);
    wr(A0, w, 16'hFFFF, r);
    flip_tag(0, A0, 10);                             // one bit of the stored tag entry
    rd(A0, 16'hFFFF, r);
    check(r.status == 4'd0 && r.data == w, "T6 hit through a corrected tag");
    check(r.meta[3] == 1'b1, "T6 corrected flag");
    check(evt_cnt[sf_cache_pkg::ERR_TAG_CE] >= 1, "T6 tag CE event");
    wait_idle();
    n0 = evt_cnt[sf_cache_pkg::ERR_TAG_CE];
    rd(A0, 16'hFFFF, r);
    check(evt_cnt[sf_cache_pkg::ERR_TAG_CE] == n0, "T6 tag entry scrubbed (no second event)");

    // ================= T7: tag UE: entry untrusted -> miss + refill ====================================
    A0 = 64'h0000_0000_0060_0180;                   // set 6
    rd(A0, 16'hFFFF, r);                             // clean line in way 0
    w = r.data;
    flip_tag(0, A0, 10); flip_tag(0, A0, 12);
    n0 = mem.tr_addr.size();
    rd(A0, 16'hFFFF, r);
    check(r.status == 4'd0 && r.data == w, "T7 data correct after tag UE (refetched)");
    check(evt_cnt[sf_cache_pkg::ERR_TAG_UE] >= 1, "T7 tag UE event");
    wait_idle();
    check(mem.tr_addr.size() - n0 >= BEATS, "T7 the line was refilled");

    // ================= T7b: uncorrectable tag entry whose DATA bits are intact (two CHECK bits flipped) =======
    //   the stored tag still matches the request, but the entry cannot be trusted: it must NOT hit
    A0 = 64'h0000_0000_00A0_0280;                   // set 10, way 0
    rd(A0, 16'hFFFF, r);
    w = r.data;
    wait_idle();
    flip_tag(0, A0, 53); flip_tag(0, A0, 54);       // raw bits 53,54 are check bits of the 53-bit entry
    n0 = mem.tr_addr.size();
    n1 = evt_cnt[sf_cache_pkg::ERR_TAG_UE];
    rd(A0, 16'hFFFF, r);
    check(r.status == 4'd0 && r.data == w, "T7b data correct");
    wait_idle();
    check(evt_cnt[sf_cache_pkg::ERR_TAG_UE] == n1 + 1, "T7b tag UE event for a check-bit-only double error");
    check(mem.tr_addr.size() - n0 == BEATS, "T7b untrusted entry did not hit: the line was refilled");

    // ================= T8: persistent UE on a clean line: one refetch, then poison ========================
    A0 = 64'h0000_0000_0070_01C0;                   // set 7, way 0 -> lane0 bits 3,5 stuck at 1
    rd(A0, 16'hFFFF, r);
    wait_idle();
    stuck_way = 0; stuck_addr = A0;
    // the memory pattern must have bit 3 and 5 of the lane-0 data equal to 0 for the stuck bits to matter:
    // make sure by writing zeros via a full-beat write FIRST, flushing, then re-reading with stuck bits applied
    wr(A0, 128'd0, 16'hFFFF, r);
    cmo(sf_cache_pkg::CMO_CLEAN_INV, 1'b0, A0, 64'd64);
    stuck_en = 1'b1;
    n0 = mem.tr_addr.size();
    rd(A0, 16'hFFFF, r);                             // refill installs zeros, the stuck bits corrupt them: UE -> refetch -> UE again
    stuck_en = 1'b0;
    check(r.status == sf_albion_pkg::SF_ST_ECC_UNCORR, $sformatf("T8 persistent UE returns ECC_UNCORR (got %h)", r.status));
    wait_idle();
    check(mem.tr_addr.size() - n0 >= BEATS && mem.tr_addr.size() - n0 <= 2 * BEATS, "T8 at most one refetch attempt");
    check(!busy, "T8 cache idle (no livelock)");

    // ================= T9: reset in the middle of traffic ============================================
    begin
      logic [63:0] D0, D1;
      D0 = 64'h0000_0000_0080_0200; D1 = 64'h0000_0000_0090_0240;
      wr(D0, pat(D0, 8'h99), 16'hFFFF, r);           // dirty line, only in the cache
      // start a miss and reset while the refill is in flight
      req = '0; req.op = sf_albion_pkg::SF_OP_READ; req.tag = 8'h77; req.dom = 8'h10; req.addr = D1; req.be = 16'hFFFF;
      req_valid = 1'b1;
      do @(negedge clk); while (!up_fire_q);
      req_valid = 1'b0;
      idle(4);
      check(busy, "T9 refill in flight");
      #3 rst_n = 1'b0;                               // asynchronous assertion, not aligned to an edge
      #17 ;
      check(!rsp_valid && !mreq_valid, "T9 valids low in reset");
      @(negedge clk); @(negedge clk);
      rst_n = 1'b1;
      do @(negedge clk); while (!init_done);
      idle(3);
      check(!rsp_valid, "T9 no response for the pre-reset request");
      // the dirty line written before the reset lived only in the cache: it is gone, memory is authoritative
      rd(D0, 16'hFFFF, r);
      check(r.status == 4'd0 && r.data == mem.read_word(D0), "T9 after reset the cache is empty (reads return memory)");
      // reset during a CMO walk and during a writeback
      wr(D0 + 64'h40, pat(D0, 8'hAB), 16'hFFFF, r);
      wait_idle();
      cmo_op = sf_cache_pkg::CMO_CLEAN_INV; cmo_all = 1'b1; cmo_addr = '0; cmo_size = '0; cmo_valid = 1'b1; cmo_done_seen = 1'b0;
      do @(negedge clk); while (!cmo_busy);
      cmo_valid = 1'b0;
      idle(20);
      check(cmo_busy, "T9 CMO walk in progress");
      #2 rst_n = 1'b0;
      repeat (3) @(negedge clk);
      rst_n = 1'b1;
      do @(negedge clk); while (!init_done);
      idle(3);
      check(!cmo_busy && !busy, "T9 idle after reset during CMO");
      rd(D0 + 64'h40, 16'hFFFF, r);
      check(r.status == 4'd0, "T9 normal operation resumes");
    end

    // ================= T9b: reset with SEVERAL requests queued / parked / outstanding =====================
    begin
      logic [63:0] Q [6];
      int fired, guard2;
      for (int k = 0; k < 6; k++) Q[k] = 64'h0000_0000_00B0_0000 + 64'(k) * 64'h40;     // 6 different sets: every one misses
      hold_rsp = 1'b1;                                   // responses cannot drain: they pile up in the response queue
      fired = 0;
      for (int k = 0; k < 6; k++) begin
        req = '0; req.op = sf_albion_pkg::SF_OP_READ; req.tag = 8'(8'h80 + k); req.dom = 8'h10; req.addr = Q[k]; req.be = 16'hFFFF;
        req_valid = 1'b1;
        guard2 = 0;
        do begin @(negedge clk); guard2++; end while (!up_fire_q && guard2 < 60);
        if (up_fire_q) fired++;
        else break;                                       // not accepted: keep this request (valid, payload unchanged) until reset
      end
      check(fired >= 1, "T9b at least one request accepted");
      if (NUM_MSHR > 1) check(fired >= 2, $sformatf("T9b the MSHR build accepts several requests while responses are held (%0d)", fired));
      idle(6);
      #2 rst_n = 1'b0;                                   // asynchronous reset with requests in flight; the initiator drops valid with it (ALP-RST-01)
      req_valid = 1'b0;
      repeat (3) @(negedge clk);
      hold_rsp = 1'b0;
      check(!rsp_valid && !mreq_valid, "T9b valids low in reset");
      rst_n = 1'b1;
      do @(negedge clk); while (!init_done);
      idle(4);
      check(!busy && !rsp_valid, "T9b nothing left over after reset (MSHRs, parked request, response queue, engines)");
      rd(Q[0], 16'hFFFF, r);
      check(r.status == 4'd0 && r.data == mem.read_word(Q[0]) && r.tag == 8'h5A, "T9b normal operation after reset, no stale response");
      wait_idle();
    end

    idle(10);
    check(!proto_err, "no memory-link protocol error");
    if (errors == 0) begin
      $display("TB PASS: ecc/error-policy/reset directed tests  checks=%0d (ECC=%0d RAMLAT=%0d MEMOUT=%0d stress=%0d MSHR=%0d)", checks, ECC, RAM_LAT, MEM_MAX_OUT, P_STRESS, NUM_MSHR);
      $finish;
    end else begin
      $display("TB FAIL: ecc directed tests errors=%0d of %0d checks", errors, checks);
      $fatal(1, "ecc test failed");
    end
  end

  longint unsigned cyc = 0;
  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (cyc > 3000000) begin $display("TB FAIL: timeout"); $fatal(1, "timeout"); end
  end
endmodule

`default_nettype wire
