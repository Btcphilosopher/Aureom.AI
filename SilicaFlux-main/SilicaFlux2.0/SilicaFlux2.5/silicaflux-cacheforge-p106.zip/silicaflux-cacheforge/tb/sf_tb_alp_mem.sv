// =============================================================================
//  sf_tb_alp_mem.sv  --  testbench-only ALP v1 memory target (simulation model, not RTL)
// -----------------------------------------------------------------------------
//  A sparse 64-bit-addressed memory behind an Albion Link Protocol v1 TARGET port.
//    * obeys the target rules: one in-order response per accepted request, never in
//      the acceptance cycle, held until accepted; read data zero in non-enabled lanes
//      and zero on any error / write completion; writes are applied at acceptance
//    * random request back-pressure (P_RDY %), random response delay (LAT_MIN..LAT_MAX
//      cycles after acceptance) and random response gating (P_VAL %)
//    * error injection: arm_error(kind, line, status, count) - the next `count`
//      requests of that kind (R/W) on that line fail with `status` (count 0 = forever);
//      a failing write is not performed
//    * backdoor: backdoor_write() (a DMA agent writing behind the cache's back),
//      backdoor_read_word()
//    * a trace of every accepted request in issue order (kind, addr, be, wdata, status)
//    * never-written memory reads a deterministic address hash (docs/02 section 9.2)
//  Status codes are plain 4-bit values (ALP sf_status_e).
// =============================================================================
`default_nettype none

module sf_tb_alp_mem #(
  parameter int LAT_MIN    = 1,
  parameter int LAT_MAX    = 6,
  parameter int P_RDY      = 70,
  parameter int P_VAL      = 80,
  parameter int LINE_BYTES = 64,
  parameter int MAX_OUT    = 8
) (
  input  wire logic                  clk_i,
  input  wire logic                  rst_ni,
  input  wire logic                  req_valid_i,
  output logic                       req_ready_o,
  input  sf_albion_pkg::sf_req_t     req_i,
  output logic                       rsp_valid_o,
  input  wire logic                  rsp_ready_i,
  output sf_albion_pkg::sf_rsp_t     rsp_o
);
  // run-time knobs (initialised from the parameters, may be overwritten by the bench)
  int cfg_p_rdy   = P_RDY;
  int cfg_p_val   = P_VAL;
  int cfg_lat_min = LAT_MIN;
  int cfg_lat_max = LAT_MAX;

  // ---------------------------------------------------------------- storage
  logic [127:0] mem     [longint unsigned];   // key: 16-byte word index
  bit           written [longint unsigned];

  function automatic logic [7:0] init_byte(input logic [63:0] a);
    logic [63:0] h;
    begin
      h = a * 64'h9E3779B97F4A7C15;
      init_byte = h[63:56];
    end
  endfunction

  function automatic logic [127:0] init_word(input logic [63:0] a);
    logic [127:0] w;
    begin
      w = '0;
      for (int i = 0; i < 16; i++) w[8*i +: 8] = init_byte((a & ~64'hF) + 64'(i));
      init_word = w;
    end
  endfunction

  function automatic logic [127:0] read_word(input logic [63:0] a);
    longint unsigned k;
    begin
      k = longint'(a >> 4);
      read_word = mem.exists(k) ? mem[k] : init_word(a);
    end
  endfunction

  task automatic write_word(input logic [63:0] a, input logic [127:0] d, input logic [15:0] be);
    longint unsigned k;
    logic [127:0] w;
    begin
      k = longint'(a >> 4);
      w = read_word(a);
      for (int i = 0; i < 16; i++) if (be[i]) w[8*i +: 8] = d[8*i +: 8];
      mem[k]     = w;
      written[k] = 1'b1;
    end
  endtask

  // ---------------------------------------------------------------- backdoor
  task automatic backdoor_write(input logic [63:0] a, input int nbytes, input logic [511:0] bytes_lsb_first);
    logic [63:0] ba;
    logic [127:0] w;
    longint unsigned k;
    begin
      for (int i = 0; i < nbytes; i++) begin
        ba = a + 64'(i);
        k  = longint'(ba >> 4);
        w  = read_word(ba);
        w[8*int'(ba[3:0]) +: 8] = bytes_lsb_first[8*i +: 8];
        mem[k]     = w;
        written[k] = 1'b1;
      end
    end
  endtask

  // ---------------------------------------------------------------- error injection
  localparam int NERR = 1024;
  bit            e_used   [NERR];
  bit            e_isrd   [NERR];
  logic [63:0]   e_line   [NERR];
  logic [3:0]    e_status [NERR];
  int            e_count  [NERR];   // remaining; -1 = forever

  task automatic arm_error(input bit is_read, input logic [63:0] line, input logic [3:0] status, input int count);
    int slot;
    begin
      slot = -1;
      for (int i = 0; i < NERR; i++) if (!e_used[i] && slot < 0) slot = i;
      if (slot < 0) $fatal(1, "sf_tb_alp_mem: out of error slots");
      e_used[slot]   = 1'b1;
      e_isrd[slot]   = is_read;
      e_line[slot]   = line;
      e_status[slot] = status;
      e_count[slot]  = (count == 0) ? -1 : count;
    end
  endtask

  task automatic clear_errors();
    for (int i = 0; i < NERR; i++) e_used[i] = 1'b0;
  endtask

  // ---------------------------------------------------------------- trace
  logic [63:0]  tr_addr  [$];
  logic [15:0]  tr_be    [$];
  logic [127:0] tr_wdata [$];
  bit           tr_isrd  [$];
  logic [3:0]   tr_status[$];
  logic [7:0]   tr_dom   [$];
  logic [7:0]   tr_attr  [$];
  int unsigned  n_accept = 0;
  int unsigned  max_outstanding_seen = 0;

  // ---------------------------------------------------------------- engine
  typedef struct {
    logic [7:0]   tag;
    logic [3:0]   status;
    bit           is_write;
    logic [127:0] data;
    longint       due;
  } pend_t;
  pend_t pend [$];
  longint cycle = 0;
  int unsigned seed_lfsr = 32'hC0FFEE01;

  function automatic int rnd(input int hi);   // 0..hi
    begin
      seed_lfsr = seed_lfsr * 32'd1664525 + 32'd1013904223;
      rnd = (hi <= 0) ? 0 : int'((seed_lfsr >> 8) % unsigned'(hi + 1));
    end
  endfunction

  logic rdy_q, vld_q;
  bit   vld_next;
  sf_albion_pkg::sf_rsp_t rsp_q;
  assign req_ready_o = rdy_q;
  assign rsp_valid_o = vld_q;
  assign rsp_o       = rsp_q;

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rdy_q <= 1'b0;
      vld_q <= 1'b0;
      pend.delete();
      cycle = 0;
    end else begin
      cycle = cycle + 1;
      // ---- request acceptance (pre-edge values)
      if (req_valid_i && req_ready_o) begin
        automatic logic [63:0] a  = req_i.addr;
        automatic logic [63:0] ln = a & ~64'(LINE_BYTES - 1);
        automatic bit          is_rd = (req_i.op == sf_albion_pkg::SF_OP_READ);
        automatic logic [3:0]  st = 4'd0;
        automatic pend_t       p;
        for (int i = 0; i < NERR; i++) begin
          if (st == 4'd0 && e_used[i] && e_isrd[i] == is_rd && e_line[i] == ln) begin
            st = e_status[i];
            if (e_count[i] > 0) begin
              e_count[i] = e_count[i] - 1;
              if (e_count[i] == 0) e_used[i] = 1'b0;
            end
          end
        end
        p.tag      = req_i.tag;
        p.status   = st;
        p.is_write = !is_rd;
        p.data     = '0;
        p.due      = cycle + cfg_lat_min + rnd(cfg_lat_max - cfg_lat_min);
        if (is_rd && st == 4'd0) begin
          automatic logic [127:0] w = read_word(a);
          for (int i = 0; i < 16; i++) p.data[8*i +: 8] = req_i.be[i] ? w[8*i +: 8] : 8'h00;
        end
        if (!is_rd && st == 4'd0) write_word(a, req_i.data, req_i.be);
        tr_addr.push_back(a);
        tr_be.push_back(req_i.be);
        tr_wdata.push_back(is_rd ? 128'd0 : req_i.data);
        tr_isrd.push_back(is_rd);
        tr_status.push_back(st);
        tr_dom.push_back(req_i.dom);
        tr_attr.push_back(req_i.attr);
        n_accept++;
        pend.push_back(p);
        if ((pend.size() + (vld_q ? 1 : 0)) > max_outstanding_seen) max_outstanding_seen = pend.size() + (vld_q ? 1 : 0);
      end
      // ---- response channel: a response leaves `pend` when it is presented and stays on rsp_q until accepted
      vld_next = vld_q && !rsp_ready_i;
      if (vld_q && rsp_ready_i) vld_q <= 1'b0;
      if ((!vld_q || rsp_ready_i) && pend.size() > 0) begin
        if (pend[0].due <= cycle && rnd(99) < cfg_p_val) begin
          rsp_q        <= '0;
          rsp_q.tag    <= pend[0].tag;
          rsp_q.status <= pend[0].status;
          rsp_q.meta   <= {4'b0, 1'b0, (pend[0].status == sf_albion_pkg::SF_ST_ECC_UNCORR), 1'b1, pend[0].is_write};
          rsp_q.data   <= pend[0].data;
          vld_q        <= 1'b1;
          vld_next      = 1'b1;
          void'(pend.pop_front());
        end
      end
      // request ready for the NEXT cycle: a pure flop (no race with the DUT sampling it at the same
      // edge).  Room is checked against the occupancy AFTER this edge (pending + presented), so the
      // target never has more than MAX_OUT accepted-but-unanswered requests.
      rdy_q <= (rnd(99) < cfg_p_rdy) && ((pend.size() + (vld_next ? 1 : 0)) < MAX_OUT);
    end
  end

  // outstanding count seen by this target = requests accepted and not yet answered-and-accepted
  function automatic int unsigned outstanding();
    outstanding = pend.size() + (vld_q ? 1 : 0);
  endfunction
endmodule

`default_nettype wire
