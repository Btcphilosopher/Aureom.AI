// =============================================================================
//  tb_sf_llc_cache.sv  --  self-checking regression bench for sf_llc_cache
// -----------------------------------------------------------------------------
//  Executes a stimulus file produced by the independent Python reference model
//  (model/gen_stimulus.py) against the RTL and compares EVERYTHING the model
//  predicts (docs/02_functional_spec.md section 9):
//     * every upstream response   (tag, status, meta, data)
//     * the full memory-side request trace, in order (kind, address, byte enables,
//       write data, injected status)
//     * every performance counter of the timing-independent set
//     * the per-CMO line / discard / error results
//     * the final backing-memory image after the closing CLEAN_INVAL-all
//  and, independently of the model, the Albion Link Protocol rules on BOTH links
//  (sf_albion_link_checker, assertions abort the run).
//
//  Stress: random request idle gaps, random response back-pressure, random memory
//  request back-pressure, random memory latency, selectable RAM / memory-link
//  parameters.  Timing differs run to run; behaviour must not.
//
//  Plusargs: +DIR=<dir with stim/exp files> +NAME=<scenario> [+SEED=<n>] [+VERBOSE]
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_llc_cache;
  parameter int CACHE_BYTES = 32768;
  parameter int LINE_BYTES  = 64;
  parameter int WAYS        = 4;
  parameter int PADDR_W     = 64;
  parameter int REPL        = 1;
  parameter int RAM_LAT     = 1;
  parameter int MEM_MAX_OUT = 4;
  parameter int ECC         = 1;
  parameter int NUM_MSHR    = 1;
  parameter int P_REQ_IDLE  = 20;
  parameter int P_RSP_RDY   = 70;
  parameter int P_MREQ_RDY  = 70;
  parameter int P_MRSP_VAL  = 80;
  parameter int MEM_LAT_MIN = 1;
  parameter int MEM_LAT_MAX = 6;
  parameter longint unsigned TIMEOUT_CYCLES = 64'd40000000;

  // ---------------------------------------------------------------- clock / reset
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT hookup
  logic                      req_valid, req_ready, rsp_valid, rsp_ready;
  sf_albion_pkg::sf_req_t    req;
  sf_albion_pkg::sf_rsp_t    rsp;
  logic                      mreq_valid, mreq_ready, mrsp_valid, mrsp_ready;
  sf_albion_pkg::sf_req_t    mreq;
  sf_albion_pkg::sf_rsp_t    mrsp;
  logic                      cmo_valid, cmo_ready, cmo_busy, cmo_done, cmo_err, cmo_all;
  logic [1:0]                cmo_op;
  logic [63:0]               cmo_addr, cmo_size;
  logic [31:0]               cmo_lines;
  logic                      cfg_en, cfg_nc_en;
  logic [63:0]               cfg_nc_base, cfg_nc_limit;
  logic [7:0]                cfg_wb_dom, cfg_wb_attr;
  logic                      init_done, busy, err_clear, perf_clear, proto_err;
  logic [sf_cache_pkg::ERR_NUM-1:0] err_evt, err_sticky;
  logic [63:0]               err_addr, caps;
  localparam int CNT_W = 64;
  logic [sf_cache_pkg::PERF_N_TOTAL*CNT_W-1:0] perf;

  sf_llc_cache #(
    .CACHE_BYTES(CACHE_BYTES), .LINE_BYTES(LINE_BYTES), .WAYS(WAYS), .PADDR_W(PADDR_W),
    .NUM_MSHR(NUM_MSHR), .REPL_POLICY(REPL), .RAM_LATENCY(RAM_LAT), .MEM_MAX_OUT(MEM_MAX_OUT),
    .ECC_EN(ECC != 0), .CNT_W(CNT_W)
  ) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(req_valid), .req_ready_o(req_ready), .req_i(req),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_o(rsp),
    .mreq_valid_o(mreq_valid), .mreq_ready_i(mreq_ready), .mreq_o(mreq),
    .mrsp_valid_i(mrsp_valid), .mrsp_ready_o(mrsp_ready), .mrsp_i(mrsp),
    .cmo_valid_i(cmo_valid), .cmo_ready_o(cmo_ready), .cmo_op_i(cmo_op), .cmo_all_i(cmo_all),
    .cmo_addr_i(cmo_addr), .cmo_size_i(cmo_size),
    .cmo_busy_o(cmo_busy), .cmo_done_o(cmo_done), .cmo_lines_o(cmo_lines), .cmo_err_o(cmo_err),
    .cfg_en_i(cfg_en), .cfg_nc_en_i(cfg_nc_en), .cfg_nc_base_i(cfg_nc_base), .cfg_nc_limit_i(cfg_nc_limit),
    .cfg_wb_dom_i(cfg_wb_dom), .cfg_wb_attr_i(cfg_wb_attr),
    .init_done_o(init_done), .busy_o(busy), .err_evt_o(err_evt), .err_sticky_o(err_sticky),
    .err_clear_i(err_clear), .err_addr_o(err_addr), .perf_clear_i(perf_clear), .perf_o(perf),
    .caps_o(caps), .proto_err_o(proto_err)
  );

  sf_tb_alp_mem #(
    .LAT_MIN(MEM_LAT_MIN), .LAT_MAX(MEM_LAT_MAX), .P_RDY(P_MREQ_RDY), .P_VAL(P_MRSP_VAL),
    .LINE_BYTES(LINE_BYTES), .MAX_OUT(MEM_MAX_OUT)
  ) mem (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(mreq_valid), .req_ready_o(mreq_ready), .req_i(mreq),
    .rsp_valid_o(mrsp_valid), .rsp_ready_i(mrsp_ready), .rsp_o(mrsp)
  );

  // ---------------------------------------------------------------- Albion Link Protocol checkers
  logic [15:0] up_out, dn_out;
  localparam int UP_MAXOUT = (NUM_MSHR > 1) ? 2 * NUM_MSHR : 1;   // response-order queue depth of the MSHR cache
  sf_albion_link_checker #(.MAX_OUTSTANDING(UP_MAXOUT), .CHECK_LEGALITY(1'b1), .CHECK_LANES(1'b1)) u_chk_up (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(req_valid), .req_ready_i(req_ready), .req_i(req),
    .rsp_valid_i(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_i(rsp), .waive_req_i(1'b0), .outstanding_o(up_out));
  sf_albion_link_checker #(.MAX_OUTSTANDING(MEM_MAX_OUT), .CHECK_LEGALITY(1'b0), .CHECK_LANES(1'b1)) u_chk_dn (
    .clk_i(clk), .rst_ni(rst_n),
    .req_valid_i(mreq_valid), .req_ready_i(mreq_ready), .req_i(mreq),
    .rsp_valid_i(mrsp_valid), .rsp_ready_i(mrsp_ready), .rsp_i(mrsp), .waive_req_i(1'b0), .outstanding_o(dn_out));

  // ---------------------------------------------------------------- bookkeeping
  int unsigned errors = 0;
  int unsigned checks = 0;
  bit          verbose = 1'b0;
  string       dir, name;
  int          seed = 1;
  bit          cmo_nobarrier = 1'b0;   // +CMONB: issue CMOs without waiting for idle (the CMO port itself must wait)
  int          p_req_idle = P_REQ_IDLE;
  int          p_rsp_rdy  = P_RSP_RDY;

  task automatic fail(input string msg);
    begin
      errors++;
      if (errors <= 20) $display("TB ERROR @%0t: %s", $time, msg);
    end
  endtask

  // ---------------------------------------------------------------- record storage
  typedef struct {
    int           kind;      // 0 REQ 1 CFG 2 CMO 3 DMAW 4 MERR
    int           seq;
    logic [3:0]   op;
    logic [7:0]   tag, dom, attr;
    logic [63:0]  a, b;      // REQ/DMAW: address ; CMO: start,size ; CFG: nc_base,nc_limit ; MERR: line
    logic [15:0]  be;
    logic [127:0] d;
    int           flag1, flag2;   // CFG: en,nc_en ; CMO: all ; MERR: isread, count
    int           nbytes;
    logic [511:0] bytes;
    logic [3:0]   st;
  } rec_t;
  rec_t recs [$];

  typedef struct { int seq; logic [7:0] tag; logic [3:0] st; logic [7:0] meta; logic [127:0] data; } erp_t;
  erp_t exp_rsp [$];
  typedef struct { bit isrd; logic [63:0] a; logic [15:0] be; logic [127:0] d; logic [3:0] st; } emm_t;
  emm_t exp_mem [$];
  typedef struct { int seq; int lines; int disc; int err; } ecm_t;
  ecm_t exp_cmo [$];
  typedef struct { logic [63:0] a; logic [127:0] d; } eim_t;
  eim_t exp_img [$];
  longint exp_cnt [string];

  function automatic logic [7:0] hexbyte(input string s, input int i);
    logic [7:0] v;
    byte c0, c1;
    begin
      c0 = s.getc(2*i); c1 = s.getc(2*i + 1);
      v[7:4] = (c0 >= "a") ? (c0 - "a" + 10) : (c0 >= "A") ? (c0 - "A" + 10) : (c0 - "0");
      v[3:0] = (c1 >= "a") ? (c1 - "a" + 10) : (c1 >= "A") ? (c1 - "A" + 10) : (c1 - "0");
      hexbyte = v;
    end
  endfunction

  task automatic load_stim(input string path);
    integer fd, r;
    string  kw, line, s;
    rec_t   rc;
    int     sq, v1, v2, nb;
    logic [3:0] hop; logic [7:0] htag, hdom, hattr; logic [63:0] ha, hb; logic [15:0] hbe; logic [127:0] hd;
    logic [3:0] hst; byte kc;
    begin
      fd = $fopen(path, "r");
      if (fd == 0) begin fail($sformatf("cannot open %s", path)); return; end
      while (!$feof(fd)) begin
        r = $fscanf(fd, " %s", kw);
        if (r != 1) break;
        if (kw.len() == 0) continue;
        if (kw.getc(0) == "#") begin r = $fgets(line, fd); continue; end
        rc = '{default: 0};
        if (kw == "REQ") begin
          r = $fscanf(fd, "%d %h %h %h %h %h %h %h", sq, hop, htag, hdom, hattr, ha, hbe, hd);
          rc.kind = 0; rc.seq = sq; rc.op = hop; rc.tag = htag; rc.dom = hdom; rc.attr = hattr; rc.a = ha; rc.be = hbe; rc.d = hd;
        end else if (kw == "CFG") begin
          r = $fscanf(fd, "%d %d %d %h %h", sq, v1, v2, ha, hb);
          rc.kind = 1; rc.seq = sq; rc.flag1 = v1; rc.flag2 = v2; rc.a = ha; rc.b = hb;
        end else if (kw == "CMO") begin
          r = $fscanf(fd, "%d %h %d %h %h", sq, hop, v1, ha, hb);
          rc.kind = 2; rc.seq = sq; rc.op = hop; rc.flag1 = v1; rc.a = ha; rc.b = hb;
        end else if (kw == "DMAW") begin
          r = $fscanf(fd, "%d %h %d %s", sq, ha, nb, s);
          rc.kind = 3; rc.seq = sq; rc.a = ha; rc.nbytes = nb;
          for (int i = 0; i < nb; i++) rc.bytes[8*i +: 8] = hexbyte(s, i);
        end else if (kw == "MERR") begin
          r = $fscanf(fd, "%d %s %h %h %d", sq, s, ha, hst, v2);
          rc.kind = 4; rc.seq = sq; rc.a = ha; rc.st = hst; rc.flag2 = v2;
          kc = s.getc(0); rc.flag1 = (kc == "R") ? 1 : 0;
        end else begin
          fail($sformatf("unknown stimulus keyword '%s'", kw));
          r = $fgets(line, fd);
          continue;
        end
        recs.push_back(rc);
      end
      $fclose(fd);
    end
  endtask

  task automatic load_expected(input string d, input string n);
    integer fd, r;
    string  kw, s;
    int     sq, idx, ln, di, er;
    longint cv;
    logic [7:0] tg, mt; logic [3:0] st; logic [127:0] dt; logic [63:0] ad; logic [15:0] be;
    erp_t e1; emm_t e2; ecm_t e3; eim_t e4; byte kc;
    begin
      fd = $fopen({d, "/exp_rsp_", n, ".txt"}, "r");
      if (fd == 0) fail("cannot open exp_rsp"); else begin
        while (!$feof(fd)) begin
          r = $fscanf(fd, " %d %h %h %h %h", sq, tg, st, mt, dt);
          if (r != 5) break;
          e1.seq = sq; e1.tag = tg; e1.st = st; e1.meta = mt; e1.data = dt; exp_rsp.push_back(e1);
        end
        $fclose(fd);
      end
      fd = $fopen({d, "/exp_mem_", n, ".txt"}, "r");
      if (fd == 0) fail("cannot open exp_mem"); else begin
        while (!$feof(fd)) begin
          r = $fscanf(fd, " %d %s %h %h %h %h", idx, s, ad, be, dt, st);
          if (r != 6) break;
          kc = s.getc(0);
          e2.isrd = (kc == "R"); e2.a = ad; e2.be = be; e2.d = dt; e2.st = st; exp_mem.push_back(e2);
        end
        $fclose(fd);
      end
      fd = $fopen({d, "/exp_cnt_", n, ".txt"}, "r");
      if (fd == 0) fail("cannot open exp_cnt"); else begin
        while (!$feof(fd)) begin
          r = $fscanf(fd, " %s %d", kw, cv);
          if (r != 2) break;
          exp_cnt[kw] = cv;
        end
        $fclose(fd);
      end
      fd = $fopen({d, "/exp_cmo_", n, ".txt"}, "r");
      if (fd == 0) fail("cannot open exp_cmo"); else begin
        while (!$feof(fd)) begin
          r = $fscanf(fd, " %d %d %d %d", sq, ln, di, er);
          if (r != 4) break;
          e3.seq = sq; e3.lines = ln; e3.disc = di; e3.err = er; exp_cmo.push_back(e3);
        end
        $fclose(fd);
      end
      fd = $fopen({d, "/exp_img_", n, ".txt"}, "r");
      if (fd == 0) fail("cannot open exp_img"); else begin
        while (!$feof(fd)) begin
          r = $fscanf(fd, " %h %h", ad, dt);
          if (r != 2) break;
          e4.a = ad; e4.d = dt; exp_img.push_back(e4);
        end
        $fclose(fd);
      end
    end
  endtask

  // ---------------------------------------------------------------- tag allocation (a legal ALP initiator)
  //  The model's tags are arbitrary; an initiator must never reuse a tag that is still outstanding
  //  (ALP-TAG-01), so the driver substitutes a free tag when the requested one is busy and the
  //  response checker compares the echoed tag with the tag actually issued.
  bit          tag_busy [256];
  logic [7:0]  issued_tags [$];

  // ---------------------------------------------------------------- response checker (upstream)
  int unsigned rsp_idx = 0;
  always @(posedge clk) begin
    if (rst_n && rsp_valid && rsp_ready) begin
      if (rsp_idx >= exp_rsp.size()) fail($sformatf("unexpected extra response #%0d tag=%h", rsp_idx, rsp.tag));
      else begin
        checks++;
        if (issued_tags.size() == 0) fail("response with no issued request");
        else begin
          automatic logic [7:0] it = issued_tags.pop_front();
          tag_busy[it] = 1'b0;
          exp_rsp[rsp_idx].tag = it;                 // the echoed tag must be the tag that was issued
        end
        if (rsp.tag !== exp_rsp[rsp_idx].tag || rsp.status !== exp_rsp[rsp_idx].st ||
            rsp.meta !== exp_rsp[rsp_idx].meta || rsp.data !== exp_rsp[rsp_idx].data)
          fail($sformatf("response #%0d (stim seq %0d): got tag=%h st=%h meta=%h data=%h  expected tag=%h st=%h meta=%h data=%h",
                         rsp_idx, exp_rsp[rsp_idx].seq, rsp.tag, rsp.status, rsp.meta, rsp.data,
                         exp_rsp[rsp_idx].tag, exp_rsp[rsp_idx].st, exp_rsp[rsp_idx].meta, exp_rsp[rsp_idx].data));
      end
      rsp_idx++;
    end
  end

  // ---------------------------------------------------------------- race-free handshake monitors
  //  Monitors sample at the rising edge exactly like RTL (they see the values the DUT sees); the
  //  driver below acts at the FALLING edge and learns about handshakes from these flags.
  logic up_fire_q = 1'b0, cmo_acc_q = 1'b0;
  bit   cmo_done_seen = 1'b0;
  logic [31:0] cmo_lines_cap;
  logic        cmo_err_cap;
  always @(posedge clk) begin
    up_fire_q <= rst_n && req_valid && req_ready;
    cmo_acc_q <= rst_n && cmo_valid && cmo_ready;
    if (rst_n && cmo_done) begin cmo_done_seen = 1'b1; cmo_lines_cap = cmo_lines; cmo_err_cap = cmo_err; end
  end

  // ---------------------------------------------------------------- random response back-pressure (driven at negedge)
  always @(negedge clk) begin
    if (!rst_n) rsp_ready = 1'b0;
    else        rsp_ready = (mem.rnd(99) < p_rsp_rdy);
  end

  // ---------------------------------------------------------------- stimulus execution
  int unsigned reqs_sent = 0;

  task automatic idle(input int n);
    repeat (n) @(negedge clk);
  endtask

  task automatic send_req(input rec_t rc);
    begin
      while (mem.rnd(99) < p_req_idle) @(negedge clk);
      begin
        automatic logic [7:0] t = rc.tag;
        for (int k = 0; k < 256 && tag_busy[t]; k++) t = t + 8'd1;
        tag_busy[t] = 1'b1;
        issued_tags.push_back(t);
        req       = '0;
        req.tag   = t;
      end
      req.op    = rc.op;
      req.dom   = rc.dom;
      req.attr  = rc.attr;
      req.addr  = rc.a;
      req.be    = rc.be;
      req.data  = rc.d;
      req_valid = 1'b1;
      do @(negedge clk); while (!up_fire_q);      // up_fire_q: valid && ready at the rising edge in between
      req_valid = 1'b0;
      reqs_sent++;
    end
  endtask

  task automatic barrier();
    begin
      // all responses back, cache idle, memory idle
      do @(negedge clk); while (rsp_idx != reqs_sent || busy || mem.outstanding() != 0);
      idle(2 + mem.rnd(3));
    end
  endtask

  int unsigned cmo_idx = 0;
  task automatic do_cmo(input rec_t rc);
    begin
      cmo_op    = rc.op[1:0];
      cmo_all   = (rc.flag1 != 0);
      cmo_addr  = rc.a;
      cmo_size  = rc.b;
      cmo_done_seen = 1'b0;
      cmo_valid = 1'b1;
      do @(negedge clk); while (!cmo_acc_q);
      cmo_valid = 1'b0;
      while (!cmo_done_seen) @(negedge clk);
      if (cmo_idx >= exp_cmo.size()) fail("extra CMO");
      else begin
        checks++;
        if (int'(cmo_lines_cap) != exp_cmo[cmo_idx].lines || int'(cmo_err_cap) != exp_cmo[cmo_idx].err)
          fail($sformatf("CMO #%0d (stim seq %0d): lines=%0d err=%0d expected lines=%0d err=%0d",
                         cmo_idx, rc.seq, cmo_lines_cap, cmo_err_cap, exp_cmo[cmo_idx].lines, exp_cmo[cmo_idx].err));
      end
      cmo_idx++;
    end
  endtask

  function automatic longint cnt_get(input int idx);
    cnt_get = longint'(perf[idx*CNT_W +: CNT_W]);
  endfunction

  task automatic check_counter(input string nm, input int idx);
    longint got;
    begin
      if (!exp_cnt.exists(nm)) begin fail($sformatf("model has no counter %s", nm)); return; end
      got = cnt_get(idx);
      checks++;
      if (got != exp_cnt[nm]) fail($sformatf("counter %s: RTL %0d, model %0d", nm, got, exp_cnt[nm]));
    end
  endtask

  task automatic final_checks();
    int unsigned nw;
    begin
      // ---- counters
      check_counter("rd_hit",            sf_cache_pkg::EV_RD_HIT);
      check_counter("rd_miss",           sf_cache_pkg::EV_RD_MISS);
      check_counter("wr_hit",            sf_cache_pkg::EV_WR_HIT);
      check_counter("wr_miss",           sf_cache_pkg::EV_WR_MISS);
      check_counter("refills",           sf_cache_pkg::EV_REFILL);
      check_counter("evictions",         sf_cache_pkg::EV_EVICT);
      check_counter("writebacks",        sf_cache_pkg::EV_WRITEBACK);
      check_counter("mem_rd_beats",      sf_cache_pkg::EV_MEM_RD_BEAT);
      check_counter("mem_wr_beats",      sf_cache_pkg::EV_MEM_WR_BEAT);
      check_counter("bypass_rd",         sf_cache_pkg::EV_BYPASS_RD);
      check_counter("bypass_wr",         sf_cache_pkg::EV_BYPASS_WR);
      check_counter("cmo_lines",         sf_cache_pkg::EV_CMO_LINE);
      check_counter("cmo_dirty_discard", sf_cache_pkg::EV_CMO_DISCARD);
      check_counter("err_rsp",           sf_cache_pkg::EV_ERR_RSP);
      check_counter("refill_errors",     sf_cache_pkg::EV_REFILL_ERR);
      check_counter("wb_errors",         sf_cache_pkg::EV_WB_ERR);
      // ---- sanity of the timing-dependent counters (this bench injects no ECC faults:
      //      every miss yields exactly one latency sample)
      checks++;
      if (cnt_get(sf_cache_pkg::PERF_LAT_CNT) != cnt_get(sf_cache_pkg::EV_RD_MISS) + cnt_get(sf_cache_pkg::EV_WR_MISS))
        fail($sformatf("latency samples %0d != misses %0d", cnt_get(sf_cache_pkg::PERF_LAT_CNT),
                       cnt_get(sf_cache_pkg::EV_RD_MISS) + cnt_get(sf_cache_pkg::EV_WR_MISS)));
      // ---- memory trace
      checks++;
      if (mem.tr_addr.size() != exp_mem.size())
        fail($sformatf("memory trace length: RTL %0d, model %0d", mem.tr_addr.size(), exp_mem.size()));
      if (NUM_MSHR > 1) begin
        // overlapping misses: the GLOBAL order of memory requests legitimately differs from the blocking model,
        // but the order of the operations on every LINE must match exactly (set-serialised misses)
        bit seen [longint unsigned];
        logic [63:0] lmask;
        lmask = ~64'(LINE_BYTES - 1);
        foreach (exp_mem[i]) seen[longint'(exp_mem[i].a & lmask)] = 1'b1;
        foreach (mem.tr_addr[j]) begin
          checks++;
          if (!seen.exists(longint'(mem.tr_addr[j] & lmask))) fail($sformatf("memory request to a line the model never touched: %h", mem.tr_addr[j]));
        end
        foreach (seen[ln]) begin
          int ei, ai;
          ei = 0; ai = 0;
          forever begin
            while (ei < int'(exp_mem.size()) && longint'(exp_mem[ei].a & lmask) != ln) ei++;
            while (ai < int'(mem.tr_addr.size()) && longint'(mem.tr_addr[ai] & lmask) != ln) ai++;
            if (ei >= int'(exp_mem.size()) || ai >= int'(mem.tr_addr.size())) begin
              checks++;
              if (ei < int'(exp_mem.size()) != ai < int'(mem.tr_addr.size()))
                fail($sformatf("line %h: operation count differs (model %s, RTL %s)", ln, ei < int'(exp_mem.size()) ? "has more" : "done", ai < int'(mem.tr_addr.size()) ? "has more" : "done"));
              break;
            end
            checks++;
            if (mem.tr_isrd[ai] !== exp_mem[ei].isrd || mem.tr_addr[ai] !== exp_mem[ei].a || mem.tr_be[ai] !== exp_mem[ei].be ||
                mem.tr_wdata[ai] !== exp_mem[ei].d || mem.tr_status[ai] !== exp_mem[ei].st)
              fail($sformatf("per-line trace, line %h: RTL %s a=%h be=%h d=%h st=%h  model %s a=%h be=%h d=%h st=%h", ln,
                             mem.tr_isrd[ai] ? "R" : "W", mem.tr_addr[ai], mem.tr_be[ai], mem.tr_wdata[ai], mem.tr_status[ai],
                             exp_mem[ei].isrd ? "R" : "W", exp_mem[ei].a, exp_mem[ei].be, exp_mem[ei].d, exp_mem[ei].st));
            ei++; ai++;
          end
        end
      end else
      for (int i = 0; i < int'(exp_mem.size()) && i < int'(mem.tr_addr.size()); i++) begin
        checks++;
        if (mem.tr_isrd[i] !== exp_mem[i].isrd || mem.tr_addr[i] !== exp_mem[i].a || mem.tr_be[i] !== exp_mem[i].be ||
            mem.tr_wdata[i] !== exp_mem[i].d || mem.tr_status[i] !== exp_mem[i].st)
          fail($sformatf("memory trace #%0d: RTL %s a=%h be=%h d=%h st=%h  model %s a=%h be=%h d=%h st=%h", i,
                         mem.tr_isrd[i] ? "R" : "W", mem.tr_addr[i], mem.tr_be[i], mem.tr_wdata[i], mem.tr_status[i],
                         exp_mem[i].isrd ? "R" : "W", exp_mem[i].a, exp_mem[i].be, exp_mem[i].d, exp_mem[i].st));
      end
      // ---- final backing-memory image
      nw = 0;
      foreach (mem.written[k]) nw++;
      checks++;
      if (nw != exp_img.size()) fail($sformatf("final image: %0d words written in RTL run, model says %0d", nw, exp_img.size()));
      foreach (exp_img[i]) begin
        checks++;
        if (mem.read_word(exp_img[i].a) !== exp_img[i].d)
          fail($sformatf("final image @%h: RTL %h, model %h", exp_img[i].a, mem.read_word(exp_img[i].a), exp_img[i].d));
      end
      // ---- structural end state
      checks++;
      if (rsp_idx != exp_rsp.size()) fail($sformatf("responses: %0d received, %0d expected", rsp_idx, exp_rsp.size()));
      checks++;
      if (cmo_idx != exp_cmo.size()) fail($sformatf("CMOs: %0d executed, %0d expected", cmo_idx, exp_cmo.size()));
      checks++;
      if (proto_err) fail("memory-link protocol error flagged by the cache");
    end
  endtask

  // ---------------------------------------------------------------- overlap statistics (proves the MSHR cache really overlaps misses)
  int unsigned max_mshr = 0, max_roq = 0;
  always @(posedge clk) begin
    if (rst_n) begin
      if (int'(dut.ms_occ) > int'(max_mshr)) max_mshr = int'(dut.ms_occ);
      if (NUM_MSHR > 1 && int'(dut.roq_cnt_q) > int'(max_roq)) max_roq = int'(dut.roq_cnt_q);
    end
  end

  // ---------------------------------------------------------------- request latency (acceptance edge -> response handshake)
  longint acc_cyc [$];
  longint lat_min = 1 << 30, lat_max = 0, lat_sum = 0, lat_n = 0, cyc2 = 0;
  always @(posedge clk) begin
    cyc2 <= cyc2 + 1;
    if (rst_n && req_valid && req_ready) acc_cyc.push_back(cyc2);
    if (rst_n && rsp_valid && rsp_ready && acc_cyc.size() > 0) begin
      automatic longint l = cyc2 - acc_cyc.pop_front();
      if (l < lat_min) lat_min = l;
      if (l > lat_max) lat_max = l;
      lat_sum += l; lat_n++;
    end
  end

  // ---------------------------------------------------------------- watchdog
  longint unsigned cyc = 0;
  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (cyc > TIMEOUT_CYCLES) begin
      $display("TB FAIL: timeout after %0d cycles (responses %0d/%0d)", cyc, rsp_idx, exp_rsp.size());
      $fatal(1, "timeout");
    end
    if (proto_err) fail("proto_err_o asserted");
  end

  // ---------------------------------------------------------------- main
  initial begin
    string path;
    if (!$value$plusargs("DIR=%s", dir))   dir  = ".";
    if (!$value$plusargs("NAME=%s", name)) name = "random";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    verbose = $test$plusargs("VERBOSE");
    cmo_nobarrier = $test$plusargs("CMONB");
    void'($value$plusargs("IDLE=%d",   p_req_idle));
    void'($value$plusargs("RSPRDY=%d", p_rsp_rdy));
    void'($value$plusargs("MRQRDY=%d", mem.cfg_p_rdy));
    void'($value$plusargs("MRSVAL=%d", mem.cfg_p_val));
    void'($value$plusargs("LATMIN=%d", mem.cfg_lat_min));
    void'($value$plusargs("LATMAX=%d", mem.cfg_lat_max));
    mem.seed_lfsr = 32'hC0FFEE01 ^ 32'(seed * 32'h9E3779B1);

    req_valid = 1'b0; req = '0; rsp_ready = 1'b0;
    cmo_valid = 1'b0; cmo_op = '0; cmo_all = 1'b0; cmo_addr = '0; cmo_size = '0;
    cfg_en = 1'b1; cfg_nc_en = 1'b0; cfg_nc_base = '0; cfg_nc_limit = '0;
    cfg_wb_dom = 8'h01; cfg_wb_attr = 8'h04;       // management domain, privileged, normal-WB
    err_clear = 1'b0; perf_clear = 1'b0;

    load_stim({dir, "/stim_", name, ".txt"});
    load_expected(dir, name);

    repeat (6) @(negedge clk);
    rst_n = 1'b1;
    do @(negedge clk); while (!init_done);
    idle(3);

    foreach (recs[i]) begin
      case (recs[i].kind)
        0: send_req(recs[i]);
        1: begin
          barrier();
          cfg_en = (recs[i].flag1 != 0); cfg_nc_en = (recs[i].flag2 != 0);
          cfg_nc_base = recs[i].a; cfg_nc_limit = recs[i].b;
          idle(2);
        end
        2: begin if (!cmo_nobarrier) barrier(); do_cmo(recs[i]); idle(2); end
        3: begin barrier(); mem.backdoor_write(recs[i].a, recs[i].nbytes, recs[i].bytes); end
        4: begin barrier(); mem.arm_error(recs[i].flag1 != 0, recs[i].a, recs[i].st, recs[i].flag2); end
        default: fail("bad record kind");
      endcase
    end
    barrier();
    idle(10);
    final_checks();
    if (errors == 0) begin
      $display("LATENCY %s req->rsp cycles: min=%0d avg=%0.2f max=%0d n=%0d ; miss latency (perf): avg=%0.2f min=%0d max=%0d n=%0d", name, lat_min, real'(lat_sum)/real'(lat_n), lat_max, lat_n,
               real'(cnt_get(sf_cache_pkg::PERF_LAT_SUM))/real'(cnt_get(sf_cache_pkg::PERF_LAT_CNT)), cnt_get(sf_cache_pkg::PERF_LAT_MIN), cnt_get(sf_cache_pkg::PERF_LAT_MAX), cnt_get(sf_cache_pkg::PERF_LAT_CNT));
      $display("TB PASS: %s  responses=%0d memory-trace=%0d checks=%0d cycles=%0d  (CACHE=%0d LINE=%0d WAYS=%0d PADDR=%0d REPL=%0d RAMLAT=%0d MEMOUT=%0d ECC=%0d MSHR=%0d seed=%0d)  overlap: maxMSHR=%0d maxResp=%0d maxMemOut=%0d parked=%0d",
               name, rsp_idx, mem.tr_addr.size(), checks, cyc, CACHE_BYTES, LINE_BYTES, WAYS, PADDR_W, REPL, RAM_LAT, MEM_MAX_OUT, ECC, NUM_MSHR, seed,
               max_mshr, max_roq, mem.max_outstanding_seen, cnt_get(sf_cache_pkg::EV_PARK));
      $finish;
    end else begin
      $display("TB FAIL: %s  errors=%0d (of %0d checks)", name, errors, checks);
      $fatal(1, "regression failed");
    end
  end
endmodule

`default_nettype wire
