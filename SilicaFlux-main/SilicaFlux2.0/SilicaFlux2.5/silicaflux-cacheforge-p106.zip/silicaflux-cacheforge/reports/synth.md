# Generic synthesis statistics (Yosys, technology-independent)

Cell counts are generic-gate counts of the **controller, ECC logic, replacement metadata, counters and glue**; the RAMs are black boxes and are listed by organisation.  They are **not** area, timing or power, and no SRAM access time, die area or power figure is stated or implied.

| configuration | logic cells (excl. RAM) | flip-flops | RAM instances | RAM organisation | RAM bits (incl. ECC) |
|---|---|---|---|---|---|
| default_32KiB_4way_64B | 31335 | 3813 | 8 | 4x 128 words x 60 bits; 4x 512 words x 144 bits | 325632 |
| default_noecc | 23196 | 3810 | 8 | 4x 128 words x 53 bits; 4x 512 words x 128 bits | 289280 |
| rr_policy | 30314 | 3685 | 8 | 4x 128 words x 60 bits; 4x 512 words x 144 bits | 325632 |
| 8way_64KiB | 44644 | 4556 | 16 | 8x 128 words x 60 bits; 8x 512 words x 144 bits | 651264 |
| paddr48 | 30102 | 3733 | 8 | 4x 128 words x 44 bits; 4x 512 words x 144 bits | 317440 |
| line128B | 30049 | 3623 | 8 | 4x 64 words x 60 bits; 4x 512 words x 144 bits | 310272 |
| mshr4 | 38062 | 6561 | 8 | 4x 128 words x 60 bits; 4x 512 words x 144 bits | 325632 |

## Hierarchy (cells including submodules) per configuration

### default_32KiB_4way_64B

```
    31650 sf_llc_cache
     2650 $paramod$51a7d65d4e8ee3bc5fede5f231db2fac0afb5836\sf_cache_replacement
      341 $paramod$6acc00150dcbd2577e92c624aa48d509d5b72a07\sf_cache_mshr
      355 $paramod$a3e27287304a0db6b16edd1af5fb4fb2322ceb60\sf_cache_refill
       23 $paramod$bb1c231b98659745932648e746cba62511b231cb\sf_cache_tag_array
        6   $paramod$402ef009c1de07ea41cfe6cd8d20f71d04225521\sf_sram_macro_wrapper
      302     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000000110101
      147       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
      147     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
      983 $paramod$efd196ff11e0cf58a64ad090b79fd6851a3407e1\sf_cache_data_array
        8   $paramod$10e8fb007cabbb31dd9b7d0ba63453f11d1b698c\sf_sram_macro_wrapper
      357     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000001000000
      177       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
      177     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
     1033 $paramod\sf_cache_memport\MEM_MAX_OUT=32'00000000000000000000000000000100
     8641 $paramod\sf_cache_perf\CNT_W=32'00000000000000000000000001000000
```

### default_noecc

```
    23558 $paramod\sf_llc_cache\ECC_EN=s32'00000000000000000000000000000000
     2650 $paramod$51a7d65d4e8ee3bc5fede5f231db2fac0afb5836\sf_cache_replacement
      983 $paramod$52965eb48e432774cf46d2785f48dab50185e01e\sf_cache_data_array
        4   $paramod$4eeb6054997014c76fa6963cbeef83bbf109f052\sf_sram_macro_wrapper
      341 $paramod$6acc00150dcbd2577e92c624aa48d509d5b72a07\sf_cache_mshr
      355 $paramod$a3e27287304a0db6b16edd1af5fb4fb2322ceb60\sf_cache_refill
       23 $paramod$bf4800ddaf36b5d74e236bb01f25eedeacfdfce8\sf_cache_tag_array
        4   $paramod$e84eb9cedd4d0740039d2d0a97bd3789667a31f2\sf_sram_macro_wrapper
     1033 $paramod\sf_cache_memport\MEM_MAX_OUT=32'00000000000000000000000000000100
     8641 $paramod\sf_cache_perf\CNT_W=32'00000000000000000000000001000000
      521 $paramod\sf_cache_writeback\BEATS=32'00000000000000000000000000000100
     7009 wires
    52167 wire bits
```

### rr_policy

```
    30628 $paramod\sf_llc_cache\REPL_POLICY=s32'00000000000000000000000000000000
      341 $paramod$6acc00150dcbd2577e92c624aa48d509d5b72a07\sf_cache_mshr
      355 $paramod$a3e27287304a0db6b16edd1af5fb4fb2322ceb60\sf_cache_refill
     1628 $paramod$a652df361aac8cc8e07cdeca36904dc746f37e0f\sf_cache_replacement
       23 $paramod$bb1c231b98659745932648e746cba62511b231cb\sf_cache_tag_array
        6   $paramod$402ef009c1de07ea41cfe6cd8d20f71d04225521\sf_sram_macro_wrapper
      302     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000000110101
      147       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
      147     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
      983 $paramod$efd196ff11e0cf58a64ad090b79fd6851a3407e1\sf_cache_data_array
        8   $paramod$10e8fb007cabbb31dd9b7d0ba63453f11d1b698c\sf_sram_macro_wrapper
      357     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000001000000
      177       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
      177     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
     1033 $paramod\sf_cache_memport\MEM_MAX_OUT=32'00000000000000000000000000000100
     8641 $paramod\sf_cache_perf\CNT_W=32'00000000000000000000000001000000
```

### 8way_64KiB

```
    44917 $paramod\sf_llc_cache\WAYS=s32'00000000000000000000000000001000
     2101 $paramod$104f77d27be8107e011e6d6ab959150ed2a8cc42\sf_cache_data_array
        8   $paramod$10e8fb007cabbb31dd9b7d0ba63453f11d1b698c\sf_sram_macro_wrapper
      357     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000001000000
      177       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
      177     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
      342 $paramod$3d7e847780be44655ec55333acb5492d670ee748\sf_cache_mshr
      356 $paramod$71572b5576b2d46174445e73be0b8058a4d85f15\sf_cache_refill
     5282 $paramod$76e36052c3b2557e1eba05afb32cdae88d39e5f9\sf_cache_replacement
       39 $paramod$ddfbe90ef04e583b25a99f4bea03ac3d2de51bf3\sf_cache_tag_array
        6   $paramod$402ef009c1de07ea41cfe6cd8d20f71d04225521\sf_sram_macro_wrapper
      302     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000000110101
      147       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
      147     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
     1033 $paramod\sf_cache_memport\MEM_MAX_OUT=32'00000000000000000000000000000100
     8641 $paramod\sf_cache_perf\CNT_W=32'00000000000000000000000001000000
```

### paddr48

```
    30432 $paramod\sf_llc_cache\PADDR_W=s32'00000000000000000000000000110000
     2650 $paramod$51a7d65d4e8ee3bc5fede5f231db2fac0afb5836\sf_cache_replacement
      341 $paramod$6acc00150dcbd2577e92c624aa48d509d5b72a07\sf_cache_mshr
       23 $paramod$a254267a6ebf031c25a38fddc0f15738102a6399\sf_cache_tag_array
        6   $paramod$425c604a2134315dfb7dbfb266098bfd6f5a1bcb\sf_sram_macro_wrapper
      236     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000000100101
       96       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000100101
       96     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000100101
      355 $paramod$a3e27287304a0db6b16edd1af5fb4fb2322ceb60\sf_cache_refill
       15 $paramod$aab3b12981ff9271723fc528fae0a5b3980b7237\sf_cache_addr
      983 $paramod$efd196ff11e0cf58a64ad090b79fd6851a3407e1\sf_cache_data_array
        8   $paramod$10e8fb007cabbb31dd9b7d0ba63453f11d1b698c\sf_sram_macro_wrapper
      357     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000001000000
      177       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
      177     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
     1033 $paramod\sf_cache_memport\MEM_MAX_OUT=32'00000000000000000000000000000100
```

### line128B

```
    30362 $paramod\sf_llc_cache\LINE_BYTES=s32'00000000000000000000000010000000
      983 $paramod$1301120209a5f540e4f106014c737a4c7a287335\sf_cache_data_array
        8   $paramod$10e8fb007cabbb31dd9b7d0ba63453f11d1b698c\sf_sram_macro_wrapper
      357     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000001000000
      177       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
      177     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
     1352 $paramod$389682070d9aa9df3503d8b82408fd9f93a55b47\sf_cache_replacement
      370 $paramod$7c85a9d499019130b2e9c3167d913d05008f47b6\sf_cache_refill
      336 $paramod$d1925f0f64c8e5904c9266fafc2e547e0a8432df\sf_cache_mshr
       22 $paramod$dd30775b88212ce886ec8ac3587beed257f7a30f\sf_cache_tag_array
        6   $paramod$d50600210073716af40794c1d8ea20dd6c5a7de4\sf_sram_macro_wrapper
      302     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000000110101
      147       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
      147     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
     1033 $paramod\sf_cache_memport\MEM_MAX_OUT=32'00000000000000000000000000000100
     8641 $paramod\sf_cache_perf\CNT_W=32'00000000000000000000000001000000
```

### mshr4

```
    39307 $paramod\sf_llc_cache\NUM_MSHR=s32'00000000000000000000000000000100
      967 $paramod$2c23b2e0221cb9f380e83e720b94006ccfa7c87f\sf_cache_refill
     2650 $paramod$51a7d65d4e8ee3bc5fede5f231db2fac0afb5836\sf_cache_replacement
     1456 $paramod$a71968e0ca33e56e48326e18f4cb13b489867aa6\sf_cache_mshr
       23 $paramod$bb1c231b98659745932648e746cba62511b231cb\sf_cache_tag_array
        6   $paramod$402ef009c1de07ea41cfe6cd8d20f71d04225521\sf_sram_macro_wrapper
      302     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000000110101
      147       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
      147     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000000110101
      983 $paramod$efd196ff11e0cf58a64ad090b79fd6851a3407e1\sf_cache_data_array
        8   $paramod$10e8fb007cabbb31dd9b7d0ba63453f11d1b698c\sf_sram_macro_wrapper
      357     $paramod\sf_ecc_secded_dec\K=s32'00000000000000000000000001000000
      177       $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
      177     $paramod\sf_ecc_secded_enc\K=s32'00000000000000000000000001000000
     1033 $paramod\sf_cache_memport\MEM_MAX_OUT=32'00000000000000000000000000000100
     8646 $paramod\sf_cache_perf\CNT_W=32'00000000000000000000000001000000
```

## Raw `stat` output per configuration

### default_32KiB_4way_64B

```

28. Printing statistics.

=== sf_llc_cache ===

        +----------Local Count, excluding submodules.
        | 
     9485 wires
    79686 wire bits
     1391 public wires
    44156 public wire bits
       40 ports
     3033 port bits
    31335 cells
     7073   $_AND_
     2214   $_DFFE_PN0P_
       33   $_DFFE_PN1P_
     1303   $_DFFE_PP_
       51   $_DFF_PN0_
        8   $_DFF_P_
     5610   $_MUX_
     1733   $_NOT_
     5478   $_OR_
      140   $_SDFFCE_PN0P_
       64   $_SDFFCE_PP0P_
     7566   $_XOR_
       54   $scopeinfo
        8   sf_sram_be_generic


```

### default_noecc

```

29. Printing statistics.

=== $paramod\sf_llc_cache\ECC_EN=s32'00000000000000000000000000000000 ===

        +----------Local Count, excluding submodules.
        | 
     6820 wires
    51465 wire bits
      990 public wires
    28271 public wire bits
       40 ports
     3033 port bits
    23196 cells
     6821   $_AND_
     2214   $_DFFE_PN0P_
       33   $_DFFE_PN1P_
     1303   $_DFFE_PP_
       51   $_DFF_PN0_
        5   $_DFF_P_
     5610   $_MUX_
      878   $_NOT_
     3389   $_OR_
      140   $_SDFFCE_PN0P_
       64   $_SDFFCE_PP0P_
     2662   $_XOR_
       18   $scopeinfo
        8   sf_sram_be_generic


```

### rr_policy

```

29. Printing statistics.

=== $paramod\sf_llc_cache\REPL_POLICY=s32'00000000000000000000000000000000 ===

        +----------Local Count, excluding submodules.
        | 
     9076 wires
    78666 wire bits
     1392 public wires
    44026 public wire bits
       40 ports
     3033 port bits
    30314 cells
     6691   $_AND_
     2086   $_DFFE_PN0P_
       33   $_DFFE_PN1P_
     1303   $_DFFE_PP_
       51   $_DFF_PN0_
        8   $_DFF_P_
     5605   $_MUX_
     1732   $_NOT_
     4972   $_OR_
      140   $_SDFFCE_PN0P_
       64   $_SDFFCE_PP0P_
     7567   $_XOR_
       54   $scopeinfo
        8   sf_sram_be_generic


```

### 8way_64KiB

```

30. Printing statistics.

=== $paramod\sf_llc_cache\WAYS=s32'00000000000000000000000000001000 ===

        +----------Local Count, excluding submodules.
        | 
    13693 wires
   122085 wire bits
     2119 public wires
    69610 public wire bits
       40 ports
     3033 port bits
    44644 cells
     8392   $_AND_
     2732   $_DFFE_PN0P_
       33   $_DFFE_PN1P_
     1520   $_DFFE_PP_
       51   $_DFF_PN0_
       16   $_DFF_P_
     6930   $_MUX_
     2629   $_NOT_
     9344   $_OR_
      140   $_SDFFCE_PN0P_
       64   $_SDFFCE_PP0P_
    12679   $_XOR_
       98   $scopeinfo
       16   sf_sram_be_generic


```

### paddr48

```

29. Printing statistics.

=== $paramod\sf_llc_cache\PADDR_W=s32'00000000000000000000000000110000 ===

        +----------Local Count, excluding submodules.
        | 
     9318 wires
    75794 wire bits
     1389 public wires
    41850 public wire bits
       40 ports
     3033 port bits
    30102 cells
     7025   $_AND_
     2214   $_DFFE_PN0P_
       33   $_DFFE_PN1P_
     1223   $_DFFE_PP_
       51   $_DFF_PN0_
        8   $_DFF_P_
     5322   $_MUX_
     1669   $_NOT_
     5261   $_OR_
      140   $_SDFFCE_PN0P_
       64   $_SDFFCE_PP0P_
     7030   $_XOR_
       54   $scopeinfo
        8   sf_sram_be_generic


```

### line128B

```

29. Printing statistics.

=== $paramod\sf_llc_cache\LINE_BYTES=s32'00000000000000000000000010000000 ===

        +----------Local Count, excluding submodules.
        | 
     8755 wires
    78339 wire bits
     1327 public wires
    43945 public wire bits
       40 ports
     3033 port bits
    30049 cells
     6688   $_AND_
     2024   $_DFFE_PN0P_
       33   $_DFFE_PN1P_
     1302   $_DFFE_PP_
       52   $_DFF_PN0_
        8   $_DFF_P_
     5613   $_MUX_
     1604   $_NOT_
     4888   $_OR_
      140   $_SDFFCE_PN0P_
       64   $_SDFFCE_PP0P_
     7571   $_XOR_
       54   $scopeinfo
        8   sf_sram_be_generic


```

### mshr4

```

29. Printing statistics.

=== $paramod\sf_llc_cache\NUM_MSHR=s32'00000000000000000000000000000100 ===

        +----------Local Count, excluding submodules.
        | 
    10079 wires
    88098 wire bits
     1523 public wires
    48493 public wire bits
       40 ports
     3033 port bits
    38062 cells
     7282   $_AND_
     2248   $_DFFE_PN0P_
       33   $_DFFE_PN1P_
     4133   $_DFFE_PP_
       75   $_DFF_PN0_
        8   $_DFF_P_
     8986   $_MUX_
     1856   $_NOT_
     5656   $_OR_
       64   $_SDFFCE_PP0P_
     7657   $_XOR_
       56   $scopeinfo
        8   sf_sram_be_generic


```
