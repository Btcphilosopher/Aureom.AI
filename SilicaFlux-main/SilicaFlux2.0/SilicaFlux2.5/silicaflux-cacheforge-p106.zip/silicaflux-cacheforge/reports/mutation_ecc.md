# Mutation campaign (model-vs-RTL regression)

Configurations: A_default,B_rr_small; scenarios: all; seeds: 2; count: 300.

**11 / 12 mutants killed**, 1 survived, 0 invalid.

| id | status | defect injected | evidence |
|---|---|---|---|
| X1 | KILLED | data scrub after a corrected error disabled | TB ERROR @1840000: T1 second read clean (scrubbed) |
| X2 | KILLED | clean-line uncorrectable error not refetched | TB ERROR @2600000: T3 refetched data 00000000000000000000000000000000 exp 98f95bbd1f81e244a6086acb2d8ff152 st=a |
| X3 | KILLED | poison laundered: partial write merges uncorrectable data | TB ERROR @3360000: T4 partial write to poisoned beat is refused |
| X4 | KILLED | corrupt beat written back to memory | TB ERROR @5850000: T5 corrupted beat 2 was NOT written to memory (old value kept) |
| X5 | KILLED | tag scrub disabled | TB ERROR @6390000: T6 tag entry scrubbed (no second event) |
| X6 | KILLED | corrected flag not reported | TB ERROR @1730000: T1 meta.corrected set |
| X7 | KILLED | persistent uncorrectable error refetched forever (livelock) | TB ERROR @1015950000: no response (timeout) |
| X8 | KILLED | uncorrectable error answered OKAY | TB ERROR @3250000: T4 read status 0 |
| X9 | SURVIVED | (no-op control mutant: must SURVIVE) | all directed tests passed |
| X10 | KILLED | data array built without ECC | TB ERROR @1730000: T1 corrected read data eafbc8d9aebf8c9d627340512637041d exp eafbc8d9aebf8c9d6273405126370415 st=0 |
| X11 | KILLED | uncorrectable tag entry still trusted as valid | TB ERROR @7340000: T7b untrusted entry did not hit: the line was refilled |
| X12 | KILLED | dirty-data loss not reported as an error event | TB ERROR @5830000: T5 dirty-lost event count 0 |
