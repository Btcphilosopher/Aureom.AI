# Mutation campaign (model-vs-RTL regression)

Configurations: A_default,B_rr_small; scenarios: all; seeds: 2; count: 300.  (rows that were INVALID in the first pass because the mutation pattern no longer matched renamed RTL were re-run after updating the pattern).

**49 / 51 mutants killed**, 2 survived, 0 invalid.

| id | status | defect injected | evidence |
|---|---|---|---|
| R1 | KILLED | PLRU touch points TOWARDS the accessed way | 23/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @51230000: counter rd_hit: RTL 186, model 195 |
| R2 | KILLED | invalid ways not preferred | 30/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @78130000: counter rd_hit: RTL 61, model 58 |
| R3 | KILLED | round-robin counter does not advance | 24/48 runs failed; first: FAIL B_rr_small.cold.s1  TB ERROR @101910000: counter rd_hit: RTL 81, model 191 |
| R4 | KILLED | PLRU victim walk goes the wrong way | 23/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @51230000: counter rd_hit: RTL 186, model 195 |
| T1 | KILLED | hit ignores the valid bit | 29/48 runs failed; first: FAIL A_default.cold.s1  [24855000] %Error: sf_llc_cache.sv:1380: Assertion failed in tb_sf_llc_cache |
| T2 | KILLED | tag compare ignores bit 0 | 18/48 runs failed; first: FAIL A_default.cold.s2  TB ERROR @46055000: response #227 (stim seq 228): got tag=f7 st=0 meta=02 da |
| W1 | KILLED | full-beat write hit never sets dirty | 39/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @35975000: response #153 (stim seq 154): got tag=12 st=0 meta=02 d |
| W2 | KILLED | dirty bit written as 0 on write | 44/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @35125000: response #153 (stim seq 154): got tag=12 st=0 meta=02 d |
| W3 | KILLED | partial-write merge mask inverted | 44/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @64075000: response #271 (stim seq 272): got tag=c4 st=0 meta=02 d |
| W4 | KILLED | write with only the upper half enabled treated as full-beat | 37/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @79120000: memory trace #266: RTL W a=d10cd09258f6b860 be=ffff d=f |
| E1 | KILLED | dirty victim is not written back (data lost) | 43/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @35125000: response #153 (stim seq 154): got tag=12 st=0 meta=02 d |
| E2 | KILLED | eviction not counted | 47/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @49600000: counter evictions: RTL 0, model 14 |
| E3 | KILLED | writeback error ignored: victim invalidated, data lost | 5/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @8175000: response #31 (stim seq 35): got tag=9a st=0 meta=02 data= |
| E4 | KILLED | refill error ignored: garbage line installed | 7/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @1715000: response #0 (stim seq 2): got tag=a9 st=0 meta=02 data=00 |
| E5 | KILLED | line installed dirty (spurious writebacks) | 46/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @71200000: counter writebacks: RTL 104, model 0 |
| E6 | KILLED | no replacement touch after a writeback error | 5/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @99815000: response #74 (stim seq 95): got tag=4b st=7 meta=03 data |
| H1 | KILLED | hit does not update replacement state | 21/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @68850000: counter rd_hit: RTL 116, model 58 |
| H2 | KILLED | read response not masked by byte enables | 44/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=49 st=0 meta=02 data=a9 |
| H3 | KILLED | response tag corrupted | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=48 st=0 meta=02 data=00 |
| B1 | KILLED | non-cacheable memory type ignored | 16/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @16495000: response #85 (stim seq 97): got tag=46 st=0 meta=02 da |
| B2 | KILLED | NC window limit inclusive | 5/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @16645000: response #83 (stim seq 95): got tag=5d st=0 meta=02 da |
| B3 | KILLED | cache-enable configuration ignored | 6/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @6625000: response #28 (stim seq 32): got tag=4f st=0 meta=02 dat |
| B4 | KILLED | bypass error status swallowed | 5/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @179225000: response #142 (stim seq 181): got tag=d7 st=0 meta=02 d |
| L1 | KILLED | address above PADDR_W not rejected | 4/48 runs failed; first: FAIL B_rr_small.illegal.s1  TB ERROR @4505000: response #25 (stim seq 26): got tag=fc st=0 meta=03 d |
| L3 | KILLED | set index slice shifted by one bit | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @27045000: response #205 (stim seq 206): got tag=85 st=0 meta=02 da |
| L4 | KILLED | victim address reconstruction wrong | 44/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @36765000: response #153 (stim seq 154): got tag=12 st=0 meta=02 d |
| L2 | KILLED | illegal requests not rejected | 7/48 runs failed; first: FAIL A_default.illegal.s1  TB ERROR @1535000: response #0 (stim seq 1): got tag=0e st=0 meta=02 data |
| C1 | KILLED | CMO CLEAN leaves the line dirty | 19/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @111400000: counter writebacks: RTL 58, model 56 |
| C2 | KILLED | CMO range end ignored | 20/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @30740000: CMO #0 (stim seq 141): lines=6 err=0 expected lines=1  |
| C3 | KILLED | CMO size 0 treated as a non-empty range | 1/48 runs failed; first: FAIL B_rr_small.cmo.s1  TB ERROR @32480000: CMO #5 (stim seq 93): lines=1 err=0 expected lines=0 err |
| C4 | KILLED | CMO moves to the next way before its writeback finishes | 41/48 runs failed; first: FAIL A_default.assoc.s2  TB ERROR @121330000: memory trace #1060: RTL W a=000000000001b900 be=ffff d |
| C5 | KILLED | INVAL does not count discarded dirty lines | 10/48 runs failed; first: FAIL A_default.dma.s1  TB ERROR @412430000: counter cmo_dirty_discard: RTL 0, model 3 |
| C6 | KILLED | INVAL behaves like CLEAN (writes dirty data back) | 10/48 runs failed; first: FAIL A_default.dma.s1  TB ERROR @31805000: response #30 (stim seq 37): got tag=9a st=0 meta=02 data= |
| C7 | KILLED | CMO walk stops one set early | 33/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @49370000: CMO #0 (stim seq 300): lines=86 err=0 expected lines=90  |
| P1 | KILLED | memory tags not unique (all zero) | 24/48 runs failed; first: FAIL A_default.cold.s1  [1515000] %Error: sf_albion_link_checker.sv:162: Assertion failed in tb_sf_l |
| P2 | SURVIVED | response accepted with an empty order queue | 48/48 runs passed |
| P3 | KILLED | outstanding limit not enforced | 24/48 runs failed; first: FAIL B_rr_small.cold.s1  TB ERROR @335000: proto_err_o asserted |
| F1 | KILLED | refill beat address stride wrong | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=49 st=0 meta=02 data=00 |
| F2 | KILLED | refill data written to the wrong beat | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=49 st=0 meta=02 data=00 |
| F3 | KILLED | refill error status never recorded | 7/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @2425000: response #4 (stim seq 7): got tag=da st=0 meta=03 data=00 |
| F4 | SURVIVED | failed refill beat still written | 48/48 runs passed |
| K1 | KILLED | writeback beat address stride wrong | 44/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @13555000: response #50 (stim seq 51): got tag=d9 st=0 meta=02 dat |
| K2 | KILLED | writeback byte enables wrong | 44/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @36765000: response #153 (stim seq 154): got tag=12 st=0 meta=02 d |
| K3 | KILLED | writeback error status never recorded | 5/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @8175000: response #31 (stim seq 35): got tag=9a st=0 meta=02 data= |
| K4 | KILLED | writeback does not wait for its responses | 3/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @182195000: response #173 (stim seq 216): got tag=d8 st=0 meta=02 d |
| A1 | KILLED | tag write also hits way 0 | 48/48 runs failed; first: FAIL A_default.cold.s1  [6315000] %Error: sf_llc_cache.sv:1380: Assertion failed in tb_sf_llc_cache. |
| A2 | KILLED | data read ignores the beat index | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=49 st=0 meta=02 data=00 |
| A3 | KILLED | data array way 1 cannot be written | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @3955000: response #9 (stim seq 10): got tag=55 st=0 meta=02 data=0 |
| S1 | KILLED | response dropped without waiting for ready | 48/48 runs failed; first: FAIL A_default.cold.s1  [1975000] %Error: sf_albion_link_checker.sv:161: Assertion failed in tb_sf_l |
| S2 | KILLED | new request accepted while a response is pending | 48/48 runs failed; first: FAIL A_default.cold.s1  [1685000] %Error: sf_albion_link_checker.sv:161: Assertion failed in tb_sf_l |
| N1 | KILLED | write-hit counter never counts | 42/48 runs failed; first: FAIL A_default.replace.s1  TB ERROR @101940000: counter wr_hit: RTL 0, model 39 |
