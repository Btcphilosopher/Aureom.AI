# Mutation campaign (model-vs-RTL regression)

Configurations: I_mshr2,N_mshr3; scenarios: all; seeds: 2; count: 300.

**19 / 19 mutants killed**, 0 survived, 0 invalid.

| id | status | defect injected | evidence |
|---|---|---|---|
| M1 | KILLED | request to a set owned by an outstanding miss is not parked | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  [465000] %Error: sf_cache_mshr.sv:226: Assertion failed in tb_sf_llc_cache.dut |
| M2 | KILLED | completed misses are never replayed (deadlock) | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  TB FAIL: timeout after 40000001 cycles (responses 0/299) |
| M3 | KILLED | installer ignores tag / replacement port conflicts | 32/48 runs failed; first: FAIL I_mshr2.cold.s1  [905000] %Error: sf_cache_tag_array.sv:107: Assertion failed in tb_sf_llc_cach |
| M4 | KILLED | installer does not update the replacement state | 43/48 runs failed; first: FAIL I_mshr2.cold.s1  TB ERROR @31450000: counter rd_hit: RTL 148, model 199 |
| M5 | KILLED | response written to the wrong order-queue slot | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  TB ERROR @1325000: response #7 (stim seq 8): got tag=66 st=0 meta=02 data=d000 |
| M6 | KILLED | failed miss replayed as a hit | 6/48 runs failed; first: FAIL I_mshr2.merr.s1  TB ERROR @595000: response #0 (stim seq 2): got tag=a9 st=0 meta=03 data=00000 |
| M7 | KILLED | refill error status not recorded in the MSHR | 6/48 runs failed; first: FAIL I_mshr2.merr.s1  TB ERROR @595000: response #0 (stim seq 2): got tag=a9 st=0 meta=03 data=00000 |
| M8 | KILLED | refill beats not held off while the front end uses the data array | 42/48 runs failed; first: FAIL I_mshr2.cold.s1  [565000] %Error: sf_cache_data_array.sv:106: Assertion failed in tb_sf_llc_cac |
| M10 | KILLED | response-order queue overflow not prevented | 17/48 runs failed; first: FAIL I_mshr2.cold.s2  [6215000] %Error: sf_albion_link_checker.sv:161: Assertion failed in tb_sf_llc |
| M11 | KILLED | wrong MSHR freed after a replay | 44/48 runs failed; first: FAIL I_mshr2.cold.s1  [1055000] %Error: sf_llc_cache.sv:1388: Assertion failed in tb_sf_llc_cache.du |
| M12 | KILLED | parked request loses its response-queue slot | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  [935000] %Error: sf_llc_cache.sv:1388: Assertion failed in tb_sf_llc_cache.dut |
| M13 | KILLED | refill completions not advanced to the next descriptor | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  [1055000] %Error: sf_llc_cache.sv:1388: Assertion failed in tb_sf_llc_cache.du |
| M14 | KILLED | refill issue pointer not advanced (same line re-issued) | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  TB ERROR @695000: response #1 (stim seq 2): got tag=a6 st=0 meta=02 data=cf000 |
| M15 | KILLED | MSHR table ignores set ownership | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  [5735000] %Error: sf_cache_mshr.sv:225: Assertion failed in tb_sf_llc_cache.du |
| M17 | KILLED | failed refill still installed | 6/48 runs failed; first: FAIL I_mshr2.merr.s1  TB ERROR @655000: response #1 (stim seq 3): got tag=08 st=0 meta=02 data=00000 |
| M18 | KILLED | new request accepted while one is parked | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  TB FAIL: timeout after 40000001 cycles (responses 3/299) |
| M19 | KILLED | CMO starts while misses are still outstanding | 19/48 runs failed; first: FAIL I_mshr2.cold.s2  TB FAIL: timeout after 40000001 cycles (responses 299/299) |
| M20 | KILLED | replay uses the wrong way | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  TB ERROR @1185000: response #5 (stim seq 6): got tag=06 st=0 meta=02 data=0000 |
| M21 | KILLED | parked request loses its response-queue slot on reload | 48/48 runs failed; first: FAIL I_mshr2.cold.s1  [955000] %Error: sf_llc_cache.sv:1388: Assertion failed in tb_sf_llc_cache.dut |
