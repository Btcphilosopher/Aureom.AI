# Mutation campaign (model-vs-RTL regression)

Configurations: A_default,B_rr_small; scenarios: all; seeds: 2; count: 300.

**47 / 49 mutants killed**, 2 survived, 0 invalid.

| id | status | defect injected | evidence |
|---|---|---|---|
| R1 | KILLED | PLRU touch points TOWARDS the accessed way | 22/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @55410000: counter rd_hit: RTL 163, model 167 |
| R2 | KILLED | invalid ways not preferred | 30/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @82110000: counter rd_hit: RTL 55, model 56 |
| R3 | KILLED | round-robin counter does not advance | 24/48 runs failed; first: FAIL B_rr_small.cold.s1  TB ERROR @101320000: counter rd_hit: RTL 80, model 191 |
| R4 | KILLED | PLRU victim walk goes the wrong way | 22/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @55410000: counter rd_hit: RTL 163, model 167 |
| T1 | KILLED | hit ignores the valid bit | 42/48 runs failed; first: FAIL A_default.cold.s1  [10785000] %Error: sf_llc_cache.sv:1098: Assertion failed in tb_sf_llc_cache |
| T2 | KILLED | tag compare ignores bit 0 | 14/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @74065000: response #297 (stim seq 298): got tag=ad st=0 meta=02 d |
| W1 | KILLED | full-beat write hit never sets dirty | 39/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @19545000: response #81 (stim seq 82): got tag=f1 st=0 meta=02 dat |
| W2 | KILLED | dirty bit written as 0 on write | 44/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @13015000: response #53 (stim seq 54): got tag=c7 st=0 meta=02 dat |
| W3 | KILLED | partial-write merge mask inverted | 44/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @10595000: response #38 (stim seq 39): got tag=9e st=0 meta=02 dat |
| W4 | KILLED | write with only the upper half enabled treated as full-beat | 34/48 runs failed; first: FAIL A_default.replace.s1  TB ERROR @93510000: memory trace #238: RTL W a=000000000000bfe0 be=ffff d |
| E1 | KILLED | dirty victim is not written back (data lost) | 42/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @13015000: response #53 (stim seq 54): got tag=c7 st=0 meta=02 dat |
| E2 | KILLED | eviction not counted | 46/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @54650000: counter evictions: RTL 0, model 12 |
| E3 | KILLED | writeback error ignored: victim invalidated, data lost | 4/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @45585000: response #61 (stim seq 80): got tag=30 st=0 meta=02 data |
| E4 | KILLED | refill error ignored: garbage line installed | 7/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @1715000: response #0 (stim seq 2): got tag=82 st=0 meta=03 data=00 |
| E5 | KILLED | line installed dirty (spurious writebacks) | 46/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @81930000: counter writebacks: RTL 132, model 0 |
| E6 | KILLED | no replacement touch after a writeback error | 4/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @45665000: response #62 (stim seq 81): got tag=c0 st=7 meta=02 data |
| H1 | KILLED | hit does not update replacement state | 19/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @71410000: counter rd_hit: RTL 116, model 56 |
| H2 | KILLED | read response not masked by byte enables | 44/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=c9 st=0 meta=02 data=3a |
| H3 | KILLED | response tag corrupted | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=c8 st=0 meta=02 data=00 |
| B1 | KILLED | non-cacheable memory type ignored | 15/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @21645000: response #63 (stim seq 71): got tag=ef st=0 meta=02 da |
| B2 | KILLED | NC window limit inclusive | 6/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @75335000: response #182 (stim seq 203): got tag=50 st=0 meta=02  |
| B3 | KILLED | cache-enable configuration ignored | 5/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @6755000: response #36 (stim seq 42): got tag=58 st=0 meta=02 dat |
| B4 | KILLED | bypass error status swallowed | 4/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @3435000: response #9 (stim seq 15): got tag=57 st=0 meta=02 data=0 |
| L1 | KILLED | address above PADDR_W not rejected | 5/48 runs failed; first: FAIL B_rr_small.illegal.s1  TB ERROR @575000: response #0 (stim seq 1): got tag=61 st=0 meta=03 data |
| L2 | KILLED | illegal requests not rejected | 8/48 runs failed; first: FAIL A_default.illegal.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=38 st=0 meta=03 data |
| C1 | KILLED | CMO CLEAN leaves the line dirty | 16/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @118830000: counter writebacks: RTL 58, model 56 |
| C2 | KILLED | CMO range end ignored | 20/48 runs failed; first: FAIL A_default.bypass.s1  TB ERROR @21050000: CMO #0 (stim seq 70): lines=6 err=0 expected lines=1 e |
| C3 | KILLED | CMO size 0 treated as a non-empty range | 2/48 runs failed; first: FAIL A_default.cmo.s1  TB ERROR @127430000: CMO #11 (stim seq 171): lines=1 err=0 expected lines=0 e |
| C4 | KILLED | CMO moves to the next way before its writeback finishes | 42/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @82490000: CMO #0 (stim seq 300): lines=31 err=0 expected lines=32 |
| C5 | KILLED | INVAL does not count discarded dirty lines | 8/48 runs failed; first: FAIL A_default.dma.s1  TB ERROR @416890000: counter cmo_dirty_discard: RTL 0, model 6 |
| C6 | KILLED | INVAL behaves like CLEAN (writes dirty data back) | 10/48 runs failed; first: FAIL A_default.dma.s1  TB ERROR @9695000: response #2 (stim seq 5): got tag=0f st=0 meta=02 data=117 |
| C7 | KILLED | CMO walk stops one set early | 34/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @54430000: CMO #0 (stim seq 300): lines=116 err=0 expected lines=12 |
| P1 | KILLED | memory tags not unique (all zero) | 24/48 runs failed; first: FAIL A_default.cold.s1  [1515000] %Error: sf_albion_link_checker.sv:162: Assertion failed in tb_sf_l |
| P2 | SURVIVED | response accepted with an empty order queue | 48/48 runs passed |
| P3 | KILLED | outstanding limit not enforced | 24/48 runs failed; first: FAIL B_rr_small.cold.s1  TB ERROR @335000: proto_err_o asserted |
| F1 | KILLED | refill beat address stride wrong | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=49 st=0 meta=02 data=00 |
| F2 | KILLED | refill data written to the wrong beat | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=49 st=0 meta=02 data=00 |
| F3 | KILLED | refill error status never recorded | 7/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @1715000: response #0 (stim seq 2): got tag=a9 st=0 meta=02 data=00 |
| F4 | SURVIVED | failed refill beat still written | 48/48 runs passed |
| K1 | KILLED | writeback beat address stride wrong | 44/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @13555000: response #50 (stim seq 51): got tag=d9 st=0 meta=02 dat |
| K2 | KILLED | writeback byte enables wrong | 44/48 runs failed; first: FAIL A_default.assoc.s1  TB ERROR @36765000: response #153 (stim seq 154): got tag=12 st=0 meta=02 d |
| K3 | KILLED | writeback error status never recorded | 5/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @8175000: response #31 (stim seq 35): got tag=9a st=0 meta=02 data= |
| K4 | KILLED | writeback does not wait for its responses | 3/48 runs failed; first: FAIL A_default.merr.s1  TB ERROR @182195000: response #173 (stim seq 216): got tag=d8 st=0 meta=02 d |
| A1 | KILLED | tag write also hits way 0 | 48/48 runs failed; first: FAIL A_default.cold.s1  [6315000] %Error: sf_llc_cache.sv:1098: Assertion failed in tb_sf_llc_cache. |
| A2 | KILLED | data read ignores the beat index | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @1685000: response #0 (stim seq 1): got tag=49 st=0 meta=02 data=00 |
| A3 | KILLED | data array way 1 cannot be written | 48/48 runs failed; first: FAIL A_default.cold.s1  TB ERROR @3955000: response #9 (stim seq 10): got tag=55 st=0 meta=02 data=0 |
| S1 | KILLED | response dropped without waiting for ready | 48/48 runs failed; first: FAIL A_default.cold.s1  [1975000] %Error: sf_albion_link_checker.sv:161: Assertion failed in tb_sf_l |
| S2 | KILLED | new request accepted while a response is pending | 48/48 runs failed; first: FAIL A_default.cold.s1  [1685000] %Error: sf_albion_link_checker.sv:161: Assertion failed in tb_sf_l |
| N1 | KILLED | write-hit counter never counts | 42/48 runs failed; first: FAIL A_default.replace.s1  TB ERROR @101940000: counter wr_hit: RTL 0, model 39 |
