// =============================================================================
//  fv_llc.sv  --  bounded formal check of the WHOLE cache on a tiny geometry
// -----------------------------------------------------------------------------
//  Geometry: 128 B, 32 B lines (2 beats), 2 ways (2 sets), 32-bit addresses.  The environment is a legal ALP v1
//  INITIATOR upstream and a legal ALP v1 TARGET downstream: AlbionCore's sf_albion_link_checker is used in
//  ASSUME mode on the side it constrains and in ASSERT mode on the side that is the cache's responsibility:
//
//    upstream link  : ASSUME_REQ = 1  -> the initiator's rules are assumed; the cache's response-channel rules are ASSERTED
//                     ALP-RSP-02 held until accepted, ALP-RSP-03 no unsolicited response / >= 1 cycle latency,
//                     ALP-ORD-01 / TAG-02 in-order, tag echo, ALP-RSP-04 operation echo, ALP-RSP-05 well-formed,
//                     ALP-RSP-07 read data only in enabled lanes, ALP-LEG-01 illegal request answered with its status,
//                     ALP-RST-01/02 reset behaviour, ALP-OUT-01 (cache never needs more than its limit)
//    memory link    : ASSUME_RSP = 1  -> the target's rules are assumed; the cache's request-channel rules are ASSERTED
//                     ALP-REQ-02 request held until accepted, ALP-OUT-01 limit, ALP-TAG-01 tag uniqueness
//  plus  F1  proto_err_o never fires      F2  no response before init_done_o
//
//  This is a BOUNDED proof (depth in the .sby file): it shows no ALP violation by the cache within that many cycles
//  from reset for ANY legal environment behaviour; it is not an unbounded proof.  The cover task shows that the
//  interesting events (a refill, a writeback, a response) are reachable inside the depth, i.e. the assumptions are
//  not vacuous.  ECC is off in this harness (the wrapper's ECC logic only adds proof cost); NUM_MSHR is a parameter.
// =============================================================================
module fv_llc #(
  parameter int unsigned NUM_MSHR = 1,
  parameter int unsigned MEM_OUT  = 2
) (
  input wire logic                    clk_i,
  input wire logic                    req_valid_i,
  input sf_albion_pkg::sf_req_t       req_i,
  input wire logic                    rsp_ready_i,
  input wire logic                    mreq_ready_i,
  input wire logic                    mrsp_valid_i,
  input sf_albion_pkg::sf_rsp_t       mrsp_i
);
  localparam int unsigned UP_OUT = (NUM_MSHR > 1) ? 2 * NUM_MSHR : 1;

  logic init = 1'b1;
  always_ff @(posedge clk_i) init <= 1'b0;
  wire rst_ni = !init;

  logic                   req_ready, rsp_valid, mreq_valid, mrsp_ready;
  sf_albion_pkg::sf_rsp_t rsp;
  sf_albion_pkg::sf_req_t mreq;
  logic                   init_done, busy, proto_err, cmo_ready, cmo_busy, cmo_done, cmo_err;
  logic [31:0]            cmo_lines;
  logic [sf_cache_pkg::ERR_NUM-1:0] err_evt, err_sticky;
  logic [63:0]            err_addr, caps;
  logic [sf_cache_pkg::PERF_N_TOTAL*32-1:0] perf;

  sf_llc_cache #(.CACHE_BYTES(128), .LINE_BYTES(32), .WAYS(2), .PADDR_W(32), .NUM_MSHR(NUM_MSHR), .REPL_POLICY(1),
                 .RAM_LATENCY(1), .MEM_MAX_OUT(MEM_OUT), .ECC_EN(1'b0), .ECC_SCRUB(1'b0), .CNT_W(32)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .req_valid_i(req_valid_i), .req_ready_o(req_ready), .req_i(req_i),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready_i), .rsp_o(rsp),
    .mreq_valid_o(mreq_valid), .mreq_ready_i(mreq_ready_i), .mreq_o(mreq),
    .mrsp_valid_i(mrsp_valid_i), .mrsp_ready_o(mrsp_ready), .mrsp_i(mrsp_i),
    .cmo_valid_i(1'b0), .cmo_ready_o(cmo_ready), .cmo_op_i(2'd0), .cmo_all_i(1'b0), .cmo_addr_i(64'd0), .cmo_size_i(64'd0),
    .cmo_busy_o(cmo_busy), .cmo_done_o(cmo_done), .cmo_lines_o(cmo_lines), .cmo_err_o(cmo_err),
    .cfg_en_i(1'b1), .cfg_nc_en_i(1'b0), .cfg_nc_base_i(64'd0), .cfg_nc_limit_i(64'd0), .cfg_wb_dom_i(8'h01), .cfg_wb_attr_i(8'h04),
    .init_done_o(init_done), .busy_o(busy), .err_evt_o(err_evt), .err_sticky_o(err_sticky), .err_clear_i(1'b0), .err_addr_o(err_addr),
    .perf_clear_i(1'b0), .perf_o(perf), .caps_o(caps), .proto_err_o(proto_err));

  logic [15:0] up_out, dn_out;
  sf_albion_link_checker #(.MAX_OUTSTANDING(UP_OUT), .CHECK_LEGALITY(1'b1), .CHECK_LANES(1'b1), .ASSUME_REQ(1'b1)) u_up (
    .clk_i(clk_i), .rst_ni(rst_ni), .req_valid_i(req_valid_i), .req_ready_i(req_ready), .req_i(req_i),
    .rsp_valid_i(rsp_valid), .rsp_ready_i(rsp_ready_i), .rsp_i(rsp), .waive_req_i(1'b0), .outstanding_o(up_out));
  sf_albion_link_checker #(.MAX_OUTSTANDING(MEM_OUT), .CHECK_LEGALITY(1'b0), .CHECK_LANES(1'b0), .ASSUME_RSP(1'b1)) u_dn (
    .clk_i(clk_i), .rst_ni(rst_ni), .req_valid_i(mreq_valid), .req_ready_i(mreq_ready_i), .req_i(mreq),
    .rsp_valid_i(mrsp_valid_i), .rsp_ready_i(mrsp_ready), .rsp_i(mrsp_i), .waive_req_i(1'b0), .outstanding_o(dn_out));

  always_comb begin
    if (!init) begin
      assert (!proto_err);                              // F1
      assert (!(rsp_valid && !init_done));              // F2
    end
  end

  // ---- reachability (cover task): a miss goes to memory, a line returns, a response is delivered
  always_ff @(posedge clk_i) begin
    cover (!init && init_done && mreq_valid && mreq_ready_i && mreq.op == sf_albion_pkg::SF_OP_READ);
    cover (!init && init_done && mreq_valid && mreq_ready_i && mreq.op == sf_albion_pkg::SF_OP_WRITE);
    cover (!init && rsp_valid && rsp_ready_i && rsp.status == sf_albion_pkg::SF_ST_OKAY && !rsp.meta.is_write);
    cover (!init && rsp_valid && rsp_ready_i && rsp.status == sf_albion_pkg::SF_ST_OKAY && rsp.meta.is_write);
  end
endmodule
