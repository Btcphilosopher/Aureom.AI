// =============================================================================
//  fv_memport.sv  --  formal properties of sf_cache_memport (the memory-side ALP v1 initiator)
// -----------------------------------------------------------------------------
//  Environment (assumed):
//   * the memory is a legal ALP v1 TARGET: AlbionCore's sf_albion_link_checker in ASSUME_RSP
//     mode turns every target-side rule (response held, tag echo, in-order, no unsolicited
//     response, well-formed, ...) into an assumption
//   * the three clients obey the client protocol: a valid request is held, payload stable, until ready
//  Proved (asserted) on the memory request channel by the SAME checker (ASSUME_RSP=1 => request side asserts):
//   ALP-REQ-02  request held until accepted        ALP-OUT-01  never more than MEM_MAX_OUT outstanding
//   ALP-TAG-01  no tag reuse while outstanding     ALP-RST-01/02  reset behaviour
//  and by the extra shadow model below:
//   M1  every completion is routed to the client that issued the oldest outstanding request
//   M2  the outstanding count of the DUT equals the shadow count (never lost, never duplicated)
//   M3  the memory port never reports a protocol error given a legal target
//   M4  a client that is granted (c_ready) was valid
// =============================================================================
module fv_memport #(
  parameter int unsigned MEM_MAX_OUT = 2,
  localparam int unsigned NC    = sf_cache_pkg::MC_NUM,
  localparam int unsigned REQ_W = sf_albion_pkg::SF_REQ_W
) (
  input wire logic                       clk_i,
  input wire logic [NC-1:0]              c_valid_i,
  input wire logic [NC*REQ_W-1:0]        c_req_i,
  input wire logic [NC-1:0]              c_cpl_ready_i,
  input wire logic                       mreq_ready_i,
  input wire logic                       mrsp_valid_i,
  input sf_albion_pkg::sf_rsp_t          mrsp_i
);
  logic init = 1'b1;
  always_ff @(posedge clk_i) init <= 1'b0;
  wire rst_ni = !init;

  logic [NC-1:0]              c_ready, c_cpl_valid;
  sf_albion_pkg::sf_rsp_t     c_cpl;
  logic                       mreq_valid, mrsp_ready, acc_rd, acc_wr, proto_err;
  sf_albion_pkg::sf_req_t     mreq;
  logic [$clog2(MEM_MAX_OUT+1)-1:0] outst;

  sf_cache_memport #(.MEM_MAX_OUT(MEM_MAX_OUT)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .c_valid_i(c_valid_i), .c_ready_o(c_ready), .c_req_i(c_req_i),
    .c_cpl_valid_o(c_cpl_valid), .c_cpl_ready_i(c_cpl_ready_i), .c_cpl_o(c_cpl),
    .mreq_valid_o(mreq_valid), .mreq_ready_i(mreq_ready_i), .mreq_o(mreq),
    .mrsp_valid_i(mrsp_valid_i), .mrsp_ready_o(mrsp_ready), .mrsp_i(mrsp_i),
    .outstanding_o(outst), .acc_rd_o(acc_rd), .acc_wr_o(acc_wr), .proto_err_o(proto_err));

  // ---- the ALP checker: target-side rules assumed, initiator-side rules ASSERTED
  logic [15:0] chk_out;
  sf_albion_link_checker #(.MAX_OUTSTANDING(MEM_MAX_OUT), .CHECK_LEGALITY(1'b0), .CHECK_LANES(1'b0), .ASSUME_RSP(1'b1)) u_chk (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .req_valid_i(mreq_valid), .req_ready_i(mreq_ready_i), .req_i(mreq),
    .rsp_valid_i(mrsp_valid_i), .rsp_ready_i(mrsp_ready), .rsp_i(mrsp_i), .waive_req_i(1'b0), .outstanding_o(chk_out));

  // ---- client protocol assumptions: held until granted, payload stable
  logic [NC-1:0]       p_hold;
  logic [NC*REQ_W-1:0] p_req;
  always_ff @(posedge clk_i) begin
    p_hold <= (c_valid_i & ~c_ready) & {NC{!init}};
    p_req  <= c_req_i;
  end
  always_comb begin
    for (int k = 0; k < NC; k++) begin
      if (!init && p_hold[k]) begin
        assume (c_valid_i[k]);
        assume (c_req_i[k*REQ_W +: REQ_W] == p_req[k*REQ_W +: REQ_W]);
      end
    end
  end

  // ---- shadow order queue
  logic [1:0]                       sh_cl [MEM_MAX_OUT];
  int unsigned                      sh_head = 0, sh_cnt = 0;
  wire logic [NC-1:0] grant = c_ready & c_valid_i;
  logic [1:0] grant_id;
  always_comb begin
    grant_id = 2'd0;
    for (int k = 0; k < NC; k++) if (grant[k]) grant_id = 2'(k);
  end
  wire logic rsp_fire = mrsp_valid_i && mrsp_ready;
  always_ff @(posedge clk_i) begin
    if (init) begin
      sh_head <= 0; sh_cnt <= 0;
    end else begin
      if (|grant) sh_cl[(sh_head + sh_cnt) % MEM_MAX_OUT] <= grant_id;
      sh_head <= rsp_fire ? (sh_head + 1) % MEM_MAX_OUT : sh_head;
      sh_cnt  <= sh_cnt + (|grant ? 1 : 0) - (rsp_fire ? 1 : 0);
    end
  end

  always_comb begin
    if (!init) begin
      assert ($onehot0(grant));                                           // single grant
      assert (!proto_err);                                                // M3
      assert (32'(outst) == sh_cnt);                                      // M2
      assert (sh_cnt <= MEM_MAX_OUT);
      for (int k = 0; k < NC; k++) assert (!c_ready[k] || c_valid_i[k] || 1'b1);
      if (|c_cpl_valid) begin                                             // M1
        assert (sh_cnt != 0);
        assert ($onehot(c_cpl_valid));
        for (int k = 0; k < NC; k++) if (c_cpl_valid[k]) assert (sh_cl[sh_head] == 2'(k));
      end
    end
  end

  // ---- non-vacuity: both a read and a write can be accepted and a completion delivered
  always_ff @(posedge clk_i) begin
    cover (!init && acc_rd);
    cover (!init && acc_wr);
    cover (!init && rsp_fire && sh_cnt == MEM_MAX_OUT);
  end
endmodule
