// =============================================================================
//  fv_mshr.sv  --  formal properties of sf_cache_mshr (miss-status table)
// -----------------------------------------------------------------------------
//  Free inputs, legal use assumed (allocate only when alloc_ready_o, free only a valid entry).  A SHADOW
//  copy of what was allocated (line, set, write, domain, attribute bits) is kept by the harness, so the
//  properties are checked against information the DUT cannot corrupt:
//   M1  occupancy_o == number of valid entries                                        (bookkeeping)
//   M2  at most ONE entry owns a set                                                  (one in-flight miss per set)
//   M3  alloc_ready_o  <=>  a free entry exists AND the looked-up set is not owned
//   M4  allocation takes the LOWEST free entry and makes it valid next cycle
//   M5  hit_o  <=>  a valid entry has the looked-up LINE;  hit_id_o names it
//   M6  merge_ok_o  =>  hit, and BOTH the entry and the candidate are READs, same domain, same
//       memory-type / privilege / security attribute bits, and the waiter list is not full
//       (a write never merges; a read never merges into a write miss; different permission class never merges)
//   M7  a freed entry is invalid next cycle and its set becomes available again
//   M8  waiters never exceed MAX_WAIT
// =============================================================================
module fv_mshr #(
  parameter int unsigned NUM_MSHR = 2,
  parameter int unsigned SETS     = 4,
  parameter int unsigned WAYS     = 2,
  parameter int unsigned MAX_WAIT = 3,
  localparam int unsigned ID_W    = (NUM_MSHR > 1) ? $clog2(NUM_MSHR) : 1,
  localparam int unsigned IDX_W   = (SETS > 1) ? $clog2(SETS) : 1,
  localparam int unsigned WAY_W   = (WAYS > 1) ? $clog2(WAYS) : 1,
  localparam int unsigned WT_W    = $clog2(MAX_WAIT + 1),
  localparam int unsigned OCC_W   = $clog2(NUM_MSHR + 1)
) (
  input wire logic              clk_i,
  input wire logic              alloc_en_i,
  input wire logic [63:0]       alloc_line_i,
  input wire logic [IDX_W-1:0]  alloc_set_i,
  input wire logic [WAY_W-1:0]  alloc_way_i,
  input wire logic              alloc_write_i,
  input wire logic [7:0]        alloc_dom_i,
  input wire logic [7:0]        alloc_attr_i,
  input wire logic              upd_en_i,
  input wire logic [ID_W-1:0]   upd_id_i,
  input wire logic [1:0]        upd_state_i,
  input wire logic              mtag_en_i,
  input wire logic [ID_W-1:0]   mtag_id_i,
  input wire logic [7:0]        mtag_i,
  input wire logic              err_en_i,
  input wire logic [ID_W-1:0]   err_id_i,
  input wire logic [3:0]        err_status_i,
  input wire logic              wait_inc_i,
  input wire logic [ID_W-1:0]   wait_id_i,
  input wire logic              free_en_i,
  input wire logic [ID_W-1:0]   free_id_i,
  input wire logic [63:0]       look_line_i,
  input wire logic [IDX_W-1:0]  look_set_i,
  input wire logic              look_write_i,
  input wire logic [7:0]        look_dom_i,
  input wire logic [7:0]        look_attr_i
);
  logic init = 1'b1;
  always_ff @(posedge clk_i) init <= 1'b0;
  wire rst_ni = !init;

  logic                      alloc_ready, hit, merge_ok, set_busy, wfull;
  logic [ID_W-1:0]           alloc_id, hit_id;
  logic [NUM_MSHR-1:0]       valid, err;
  logic [OCC_W-1:0]          occ;
  logic [NUM_MSHR*2-1:0]     state;
  logic [NUM_MSHR*WAY_W-1:0] way;
  logic [NUM_MSHR*IDX_W-1:0] set;
  logic [NUM_MSHR*8-1:0]     mtag;
  logic [NUM_MSHR*4-1:0]     estat;
  logic [NUM_MSHR*WT_W-1:0]  waiters;
  logic [NUM_MSHR*64-1:0]    line_o;
  logic [NUM_MSHR-1:0]       write_o;
  logic [NUM_MSHR*8-1:0]     dom_o, attr_o;

  sf_cache_mshr #(.NUM_MSHR(NUM_MSHR), .SETS(SETS), .WAYS(WAYS), .MAX_WAIT(MAX_WAIT)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .alloc_en_i(alloc_en_i), .alloc_line_i(alloc_line_i), .alloc_set_i(alloc_set_i), .alloc_way_i(alloc_way_i),
    .alloc_write_i(alloc_write_i), .alloc_dom_i(alloc_dom_i), .alloc_attr_i(alloc_attr_i),
    .alloc_ready_o(alloc_ready), .alloc_id_o(alloc_id),
    .upd_en_i(upd_en_i), .upd_id_i(upd_id_i), .upd_state_i(upd_state_i),
    .mtag_en_i(mtag_en_i), .mtag_id_i(mtag_id_i), .mtag_i(mtag_i),
    .err_en_i(err_en_i), .err_id_i(err_id_i), .err_status_i(err_status_i),
    .wait_inc_i(wait_inc_i), .wait_id_i(wait_id_i), .free_en_i(free_en_i), .free_id_i(free_id_i),
    .look_line_i(look_line_i), .look_set_i(look_set_i), .look_write_i(look_write_i), .look_dom_i(look_dom_i), .look_attr_i(look_attr_i),
    .hit_o(hit), .hit_id_o(hit_id), .merge_ok_o(merge_ok), .set_busy_o(set_busy), .waiters_full_o(wfull),
    .valid_o(valid), .occupancy_o(occ), .err_o(err), .state_o(state), .way_o(way), .set_o(set), .mtag_o(mtag),
    .estat_o(estat), .waiters_o(waiters),
    .line_o(line_o), .write_o(write_o), .dom_o(dom_o), .attr_o(attr_o));

  // ---- legal use of the table: only a valid entry is freed; ids are in range; a line determines its set
  always_comb begin
    if (!init && free_en_i) assume (valid[free_id_i]);
    assume (alloc_set_i == alloc_line_i[IDX_W-1:0]);
    assume (look_set_i  == look_line_i[IDX_W-1:0]);
    assume (32'(free_id_i) < NUM_MSHR);
    assume (32'(upd_id_i) < NUM_MSHR);
    assume (32'(mtag_id_i) < NUM_MSHR);
    assume (32'(err_id_i) < NUM_MSHR);
    assume (32'(wait_id_i) < NUM_MSHR);
  end

  // ---- shadow model of what was allocated
  logic [63:0]    s_line  [NUM_MSHR];
  logic [IDX_W-1:0] s_set [NUM_MSHR];
  logic           s_write [NUM_MSHR];
  logic [7:0]     s_dom   [NUM_MSHR];
  logic [7:0]     s_attr  [NUM_MSHR];
  logic [NUM_MSHR-1:0] s_valid;
  logic           p_alloc, p_free;
  // the table's allocation rule, restated on the shadow state: a free entry exists and the ALLOCATION set is not owned
  logic           alloc_free_s, alloc_sb_s, alloc_go_s;
  always_comb begin
    alloc_free_s = 1'b0; alloc_sb_s = 1'b0;
    for (int i = 0; i < NUM_MSHR; i++) begin
      if (!s_valid[i]) alloc_free_s = 1'b1;
      if (s_valid[i] && s_set[i] == alloc_set_i) alloc_sb_s = 1'b1;
    end
    alloc_go_s = alloc_en_i && alloc_free_s && !alloc_sb_s;
  end
  logic [ID_W-1:0] p_alloc_id, p_free_id;
  always_ff @(posedge clk_i) begin
    if (init) s_valid <= '0;
    else begin
      if (alloc_go_s) begin
        s_valid[alloc_id] <= 1'b1;
        s_line[alloc_id]  <= alloc_line_i;
        s_set[alloc_id]   <= alloc_set_i;
        s_write[alloc_id] <= alloc_write_i;
        s_dom[alloc_id]   <= alloc_dom_i;
        s_attr[alloc_id]  <= alloc_attr_i;
      end
      if (free_en_i) s_valid[free_id_i] <= 1'b0;
    end
    p_alloc    <= !init && alloc_go_s;
    p_alloc_id <= alloc_id;
    p_free     <= !init && free_en_i;
    p_free_id  <= free_id_i;
  end

  // ---- properties
  int unsigned popcnt;
  logic        want_ready, any_free_c, set_owned_c;
  logic [ID_W-1:0] lowest_free;
  logic        any_line_hit;
  logic [ID_W-1:0] line_hit_id;
  always_comb begin
    popcnt = 0; any_free_c = 1'b0; lowest_free = '0; set_owned_c = 1'b0; any_line_hit = 1'b0; line_hit_id = '0;
    for (int i = NUM_MSHR - 1; i >= 0; i--) begin
      if (valid[i]) popcnt = popcnt + 1;
      if (!valid[i]) begin any_free_c = 1'b1; lowest_free = ID_W'(i); end
      if (s_valid[i] && s_set[i] == look_set_i) set_owned_c = 1'b1;
      if (s_valid[i] && s_line[i] == look_line_i) begin any_line_hit = 1'b1; line_hit_id = ID_W'(i); end
    end
  end

  always_comb begin
    if (!init) begin
      assert (valid == s_valid);                                              // table tracks the shadow
      for (int i = 0; i < NUM_MSHR; i++) if (valid[i]) begin                 // ... field by field
        assert (set[i*IDX_W +: IDX_W] == s_set[i]);
        assert (line_o[i*64 +: 64] == s_line[i]);
        assert (write_o[i] == s_write[i]);
        assert (dom_o[i*8 +: 8] == s_dom[i]);
        assert (attr_o[i*8 +: 8] == s_attr[i]);
        assert (s_set[i] == s_line[i][IDX_W-1:0]);
      end
      assert (32'(occ) == popcnt);                                            // M1
      for (int i = 0; i < NUM_MSHR; i++)
        for (int j = i + 1; j < NUM_MSHR; j++)
          if (valid[i] && valid[j]) assert (s_set[i] != s_set[j]);            // M2
      assert (alloc_ready == (any_free_c && !set_owned_c));                   // M3
      assert (set_busy == set_owned_c);
      if (any_free_c) assert (alloc_id == lowest_free);                       // M4 (lowest free entry)
      assert (hit == any_line_hit);                                           // M5
      if (hit) assert (hit_id == line_hit_id);
      if (merge_ok) begin                                                     // M6
        assert (hit);
        assert (!s_write[hit_id]);
        assert (!look_write_i);
        assert (s_dom[hit_id] == look_dom_i);
        assert (s_attr[hit_id][3:0] == look_attr_i[3:0]);
        assert (!wfull);
      end
      if (look_write_i && hit) assert (!merge_ok);                            // a write never merges
      for (int i = 0; i < NUM_MSHR; i++) assert (waiters[i*WT_W +: WT_W] <= WT_W'(MAX_WAIT));   // M8
    end
  end
  always_ff @(posedge clk_i) begin
    if (!init && p_alloc) assert (valid[p_alloc_id]);                          // M4: valid next cycle
    if (!init && p_free && !(p_alloc && p_alloc_id == p_free_id)) assert (!valid[p_free_id]);   // M7
  end

  // ---- non-vacuity
  always_ff @(posedge clk_i) begin
    cover (!init && hit && merge_ok);
    cover (!init && hit && !merge_ok);
    cover (!init && set_busy && !hit);
    cover (!init && &valid);
  end
endmodule
