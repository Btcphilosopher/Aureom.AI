// =============================================================================
//  fv_cache_addr.sv  --  formal proof of the address decomposition (sf_cache_addr)
// -----------------------------------------------------------------------------
//  For EVERY 64-bit address pair (a, b) and EVERY (tag, set) pair:
//   P1  bit coverage     {tag, set, addr[OFF_W-1:0]} == addr[PADDR_W-1:0] for in-range addresses
//   P2  line base        line == addr with the low OFF_W bits cleared
//   P3  round trip       reconstruct(tag(a), set(a)) == line(a)               (in range)
//   P4  inverse          decompose(reconstruct(t, s)) == (t, s), in range, line offset 0
//   P5  injective        two in-range addresses are in the same line  <=>  same (tag, set)
//   P6  range flag       out_of_range == |addr[63:PADDR_W]
//   P7  beat             beat == addr[OFF_W-1:4]
//   P8  reconstruction never sets a bit at or above PADDR_W or below OFF_W
//  Geometry is a parameter; the sby file proves several (incl. the brief's 64-bit / 64 B / 128-set).
// =============================================================================
module fv_cache_addr #(
  parameter int unsigned LINE_BYTES = 64,
  parameter int unsigned SETS       = 128,
  parameter int unsigned PADDR_W    = 64,
  localparam int unsigned OFF_W     = $clog2(LINE_BYTES),
  localparam int unsigned IDX_W     = $clog2(SETS),
  localparam int unsigned TAG_W     = PADDR_W - OFF_W - IDX_W,
  localparam int unsigned BEATS     = LINE_BYTES / 16,
  localparam int unsigned BEAT_W    = (BEATS > 1) ? $clog2(BEATS) : 1
) (
  input wire logic [63:0]      a,
  input wire logic [63:0]      b,
  input wire logic [TAG_W-1:0] t,
  input wire logic [IDX_W-1:0] s
);
  logic [BEAT_W-1:0] a_beat, b_beat, x_beat;
  logic [IDX_W-1:0]  a_set, b_set, x_set;
  logic [TAG_W-1:0]  a_tag, b_tag, x_tag;
  logic [63:0]       a_line, b_line, x_line, a_rb, b_rb, x_rb;
  logic              a_oor, b_oor, x_oor;

  sf_cache_addr #(.LINE_BYTES(LINE_BYTES), .SETS(SETS), .PADDR_W(PADDR_W)) u_a (
    .addr_i(a), .beat_o(a_beat), .set_o(a_set), .tag_o(a_tag), .line_o(a_line), .out_of_range_o(a_oor),
    .rtag_i(a_tag), .rset_i(a_set), .rbase_o(a_rb));
  sf_cache_addr #(.LINE_BYTES(LINE_BYTES), .SETS(SETS), .PADDR_W(PADDR_W)) u_b (
    .addr_i(b), .beat_o(b_beat), .set_o(b_set), .tag_o(b_tag), .line_o(b_line), .out_of_range_o(b_oor),
    .rtag_i(b_tag), .rset_i(b_set), .rbase_o(b_rb));
  // x: reconstruct an arbitrary (t, s) and decompose the result
  logic [63:0] x_addr;
  sf_cache_addr #(.LINE_BYTES(LINE_BYTES), .SETS(SETS), .PADDR_W(PADDR_W)) u_r (
    .addr_i(x_addr), .beat_o(x_beat), .set_o(x_set), .tag_o(x_tag), .line_o(x_line), .out_of_range_o(x_oor),
    .rtag_i(t), .rset_i(s), .rbase_o(x_rb));
  assign x_addr = x_rb;

  wire logic [63:0] low = (64'd1 << OFF_W) - 64'd1;

  always_comb begin
    // P6
    assert (a_oor == (|(a >> PADDR_W)));
    // P7
    assert (a_beat == ((BEATS > 1) ? a[OFF_W-1:4] : '0));
    // P2
    assert (a_line == (a & ~low));
    if (!a_oor) begin
      // P1
      assert ({a_tag, a_set, a[OFF_W-1:0]} == a[PADDR_W-1:0]);
      // P3
      assert (a_rb == a_line);
    end
    // P4 : x_rb is the reconstruction of (t,s); decomposing it returns (t,s)
    assert (x_tag == t);
    assert (x_set == s);
    assert (!x_oor);
    assert ((x_rb & low) == 64'd0);
    assert ((x_rb >> PADDR_W) == 64'd0);              // P8
    // P5
    if (!a_oor && !b_oor)
      assert ((a_line == b_line) == ({a_tag, a_set} == {b_tag, b_set}));
  end
endmodule
