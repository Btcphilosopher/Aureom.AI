// =============================================================================
//  fv_replacement.sv  --  formal properties of sf_cache_replacement
// -----------------------------------------------------------------------------
//  Inputs are completely free (reset only in cycle 0).  Proved by k-induction:
//   R1  victim index < WAYS, for any metadata value reachable or not (a flipped metadata bit
//       can cost performance, never correctness)
//   R2  if some way is invalid, the victim is the LOWEST-numbered invalid way and is invalid
//   R3  if every way is valid, the victim is the policy victim
//   R4  (PLRU, WAYS >= 2) in the cycle after touch(set s, way w) the policy victim of s is not w
//   R5  (RR) after an install touch (touch_alloc) of way w, the policy victim of that set is (w+1) mod WAYS
//   R6  (RR) a hit touch (touch_alloc = 0) leaves the policy victim unchanged
//   R7  (WAYS = 1) the victim is always way 0
//  Reachability covers: the policy can pick every way.
// =============================================================================
module fv_replacement #(
  parameter int unsigned SETS   = 2,
  parameter int unsigned WAYS   = 4,
  parameter int unsigned POLICY = 1,
  localparam int unsigned IDX_W = (SETS > 1) ? $clog2(SETS) : 1,
  localparam int unsigned WAY_W = (WAYS > 1) ? $clog2(WAYS) : 1
) (
  input wire logic              clk_i,
  input wire logic [IDX_W-1:0]  q_set_i,
  input wire logic [WAYS-1:0]   q_valid_i,
  input wire logic              touch_en_i,
  input wire logic [IDX_W-1:0]  touch_set_i,
  input wire logic [WAY_W-1:0]  touch_way_i,
  input wire logic              touch_alloc_i
);
  logic init = 1'b1;
  always_ff @(posedge clk_i) init <= 1'b0;
  wire rst_ni = !init;

  logic [WAY_W-1:0] victim, pol;
  logic             vinv;
  sf_cache_replacement #(.SETS(SETS), .WAYS(WAYS), .POLICY(POLICY)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni), .q_set_i(q_set_i), .q_valid_i(q_valid_i), .victim_o(victim),
    .victim_invalid_o(vinv), .policy_victim_o(pol),
    .touch_en_i(touch_en_i), .touch_set_i(touch_set_i), .touch_way_i(touch_way_i), .touch_alloc_i(touch_alloc_i));

  // legal inputs only: the touched way is a real way
  always_comb assume (32'(touch_way_i) < WAYS);

  // ---- combinational properties
  always_comb begin
    assert (32'(victim) < WAYS);                                   // R1
    assert (32'(pol) < WAYS);
    if (WAYS == 1) assert (victim == '0);                          // R7
    if (!(&q_valid_i)) begin                                       // R2
      assert (vinv);
      assert (!q_valid_i[victim]);
      for (int w = 0; w < WAYS; w++) if (w < 32'(victim)) assert (q_valid_i[w]);
    end else begin                                                 // R3
      assert (!vinv);
      assert (victim == pol);
    end
  end

  // ---- one-cycle-after properties
  logic              p_touch, p_alloc;
  logic [IDX_W-1:0]  p_set;
  logic [WAY_W-1:0]  p_way;
  logic [WAY_W-1:0]  p_pol_other;     // policy victim of p_set sampled in the touch cycle (only meaningful if q_set_i == touch_set_i)
  logic              p_same;
  always_ff @(posedge clk_i) begin
    p_touch     <= touch_en_i && !init;
    p_alloc     <= touch_alloc_i;
    p_set       <= touch_set_i;
    p_way       <= touch_way_i;
    p_pol_other <= pol;
    p_same      <= (q_set_i == touch_set_i);
  end

  always_ff @(posedge clk_i) begin
    if (!init && p_touch && q_set_i == p_set && WAYS >= 2) begin
      if (POLICY == 1) assert (pol != p_way);                                              // R4
      if (POLICY == 0 && p_alloc) assert (pol == WAY_W'((32'(p_way) + 1) % WAYS));          // R5
      if (POLICY == 0 && !p_alloc && p_same) assert (pol == p_pol_other);                   // R6
    end
  end

  // ---- the policy can choose every way (non-vacuity)
  for (genvar w = 0; w < WAYS; w++) begin : g_cov
    always_ff @(posedge clk_i) cover (!init && &q_valid_i && victim == WAY_W'(w));
  end
endmodule
