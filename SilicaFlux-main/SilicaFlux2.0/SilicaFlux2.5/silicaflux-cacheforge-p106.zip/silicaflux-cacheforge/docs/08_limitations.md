# 08 — Limitations and honest status

## What this package is
Synthesizable SystemVerilog RTL for a configurable last-level cache (blocking, plus an MSHR extension), an independent reference model, self-checking
simulation, mutation campaigns, formal proofs of selected blocks, generic synthesis statistics and documentation.  **It is not tape-out ready and makes no
timing, area, power or silicon claim.**

## Architectural limits
* **Not hardware-coherent.**  No snooping, no directory (none exists in the repository).  DMA visibility is software-managed (docs/05 §2).  Mismatched attributes on one address are
  not reconciled by hardware.
* **ALP v1 carries one 16-byte beat per request**: a 64-byte line is four transactions in each direction.  There are no bursts, atomics, QoS arbitration or per-domain enforcement
  (the ALP contract's own non-claims).  "Full-line writes" are therefore: full-beat (16-byte) writes that update a resident line without read-modify-write, and full-line *writebacks*.
  A write miss always **fetches** the line first (write-allocate "refill before partial update"); a *write-without-fetch* (allocate-zero) operation is not implemented.
* **Writebacks use a configured domain / attribute pair** (`cfg_wb_*`), not the original writer's; no per-line domain or security tag is kept.  A writeback the memory side rejects is a
  *writeback error* (line retained).
* **SFB2 DataFabric (P03) is not connected**: the SFB2 ↔ ALP bridge is a missing dependency of the repository (AlbionCore's audit) and is not provided here (docs/00 §3).
* **Blocking cache**: one outstanding request; a dirty miss serialises writeback, refill and replay.
* **MSHR extension**: one in-flight miss per **set** (a request to a busy set, or any cacheable request when the MSHR table is full, is *parked*, and no younger request is accepted
  until it retries); **no request merging** (the table can test merge compatibility; the controller does not use it); a dirty victim's writeback still blocks the front end;
  CMO needs a quiescent cache; `NUM_MSHR` ≤ 8.  Gains therefore come from overlapping **refill latency of misses to different sets**, not from same-line bursts.
* **Hit path is conservative**: serial tag-then-data access with a registered compare (read hit = `4 + 2·RAM_LATENCY` cycles).  No parallel tag/data read, no critical-word-first, no prefetch.
* PLRU requires a power-of-two way count (all supported way counts are powers of two).  Replacement metadata is held in flip-flops (`SETS × (WAYS-1)` bits for PLRU): for very large set counts it
  should move into a RAM (not done).
* After reset the tag array takes `SETS` cycles to initialise; `INVAL`/flush-all are walks, not single-cycle flashes.
* Performance counters are 64-bit by default and account for **27 % of the default configuration's generic logic cells** (docs/07): use `CNT_W = 32` where area matters.

## Verification limits
* **Simulation only**: Verilator 5.49 (two-state: no X-propagation, no metastability), Yosys 0.71 / SymbiYosys / z3.  The repository's earlier projects used Verilator 5.020 and Yosys 0.33; this package was **not** run with those.
  There is no gate-level simulation, no commercial simulator, no FPGA run, no silicon.
* **The reference model and the RTL are checked against one specification** that the same engineer wrote; independence comes from a separate implementation (a different agent that never saw the RTL),
  a different language, and a mutation-tested bench — not from an independent specification.  Ambiguities the model author found were resolved in docs/02 §11.
* **Equivalence of the MSHR build to the blocking model** relies on the set-serialisation argument (docs/03 §4) and is *tested* on 6 MSHR configurations, not proved.  Memory-trace equality is checked per
  line, because the global order of memory requests legitimately differs when misses overlap.
* **Formal results**: `sf_cache_addr`, `sf_cache_replacement` and `sf_cache_mshr` are proved **unboundedly** (k-induction) for the sizes listed in docs/06.  `sf_cache_memport` is proved only to a **bounded depth**
  (k-induction did not close; no strengthening invariants were written).  The **whole cache** (`fv_llc`: 128 B, 2 ways, 2 sets, 32-bit addresses, ECC off, `NUM_MSHR` 1 and 2) is only **bounded-model-checked to depth 14**
  against the AlbionCore link-checker rules on both links (plus `proto_err_o` never fires), with a cover task showing the assumptions are not vacuous; it is not an unbounded proof, it does not include ECC, and it says nothing
  about data correctness — that is covered by simulation against the independent model.
* **ECC tests are directed** (single / double faults injected into raw codewords at chosen places), not a random fault-injection campaign.  ≥ 3-bit errors are outside the SECDED guarantee.
  The wrapper's codec was verified by its own package for K = 8…128; the 53-bit tag-entry code is covered only by the injection tests here.
* **Mutation campaigns** show the benches can fail; the surviving mutants are listed and justified in docs/06 — a survivor means "not distinguishable by these tests", and two of them are equivalent by argument.
* **`ECC_SCRUB = 0` is not exercised**: every simulation, mutation and synthesis run uses the default `ECC_SCRUB = 1` (the scrub paths are mutation-tested, X1 / X5, but the opt-out configuration was never built and run).
* Random stimulus is **seeded and bounded** (400 requests per run, 3 seeds, 14 configurations); it is not a coverage-closed constrained-random environment, and no code-coverage tool was run.

## Physical-design limits
* The **64-bit performance counters are a large share of the generic logic** (about 8.6 k of 31 k cells in the default configuration, from 28 adders / registers): `CNT_W` is a parameter, and a narrower counter or removing the module is the first thing to try if area matters.  This is a cell count, not an area.
* The synthesis statistics are **technology-independent Yosys generic-gate counts without ABC optimisation** (the YoWASP build used here cannot spawn ABC); they are useful for comparing configurations, not as area.
* RAMs are black-boxed and reported by organisation.  **No SRAM access time, area or power is stated.**  The FPGA and open-PDK macro paths of the wrapper were **not** exercised by this package; OpenROAD, STA, DRC and LVS were not run.
* `MACRO_ID` selection for ASIC macros needs the SRAMMacroBridge planning tool (not vendored).

## Not implemented (future work)
Coherence (needs a verified CoherenceDirectory), read-merge into MSHRs, write-no-allocate / allocate-zero, parallel tag/data read, prefetch, per-line domain tags, RAM-based replacement metadata,
SFB2 bridge, bursts (when ALP gains them), per-initiator counters, an interrupt wrapper for the error log.
