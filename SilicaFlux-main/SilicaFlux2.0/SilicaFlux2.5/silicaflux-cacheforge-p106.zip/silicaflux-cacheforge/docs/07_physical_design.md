# 07 — Physical design: what was measured and what was not

## 1. Flow

`scripts/run_synth.py` runs **Yosys 0.71** on the RTL (`synth -noabc`, then `flatten; stat`) for a set of configurations.  The RAM arrays are **black boxes** (`synth/sf_sram_be_generic_bb.sv`): the logic counts are the
controller, ECC encoders / decoders, replacement metadata, counters and glue only, and the RAMs are reported as instances with their exact organisation, **never as flip-flops**.

Limits of this flow (read before using any number):
* The YoWASP Yosys build used here **cannot run ABC**, so the counts are Yosys generic gates (`$_AND_`, `$_MUX_`, `$_DFF*`, …) **without ABC optimisation or technology mapping**.  They are good for comparing configurations, not for estimating area.
* No liberty / PDK was used; no timing, area, power or frequency is derived or claimed.
* **No SRAM access time, die area or power is stated anywhere in this package.**

## 2. Results

| configuration | logic cells (excl. RAM) | flip-flops | RAM instances | RAM organisation | RAM bits (incl. ECC) |
|---|---|---|---|---|---|
| default_32KiB_4way_64B | 31335 | 3813 | 8 | 4x 128 words x 60 bits; 4x 512 words x 144 bits | 325632 |
| default_noecc | 23196 | 3810 | 8 | 4x 128 words x 53 bits; 4x 512 words x 128 bits | 289280 |
| rr_policy | 30314 | 3685 | 8 | 4x 128 words x 60 bits; 4x 512 words x 144 bits | 325632 |
| 8way_64KiB | 44644 | 4556 | 16 | 8x 128 words x 60 bits; 8x 512 words x 144 bits | 651264 |
| paddr48 | 30102 | 3733 | 8 | 4x 128 words x 44 bits; 4x 512 words x 144 bits | 317440 |
| line128B | 30049 | 3623 | 8 | 4x 64 words x 60 bits; 4x 512 words x 144 bits | 310272 |
| mshr4 | 38062 | 6561 | 8 | 4x 128 words x 60 bits; 4x 512 words x 144 bits | 325632 |

Observations (all from the table / hierarchy in `reports/synth.md`):
* default configuration: **31335** generic logic cells, **3813** flip-flops (excluding the 8 RAM macros).
* the performance counters alone are 8641 of those cells (28 %): `CNT_W = 32` halves them.
* the MSHR extension with 4 entries costs +6727 cells and +2748 flip-flops (parked requests, response-order queue, refill descriptor queue); the RAMs are unchanged.
* ECC encoders / decoders sit in the RAM wrappers (one SECDED encoder + decoder per tag entry and per data lane); removing ECC (`default_noecc`) shows their cost.

## 3. Memory organisation (measured)

For the default configuration (32 KiB, 64 B lines, 4 ways, 64-bit addresses, ECC on) the synthesis flow finds exactly these RAMs:

| Array | Instances | Organisation each | Meaning |
|---|---|---|---|
| tag | 4 (one per way) | 128 words × 60 bit | `{tag 51, dirty, valid}` = 53 bit + 7 SECDED check bits |
| data | 4 (one per way) | 512 words × 144 bit | 128 data bit + 2 × 8 SECDED check bits (two 64-bit lanes); 512 = 128 sets × 4 beats |

Total stored bits 325 632 = 262 144 data bit + 32 768 data check bit + 30 720 tag-entry bit (incl. check bits); the ECC overhead is 12.5 % on data.  These sizes follow from the parameters
(`SETS × WAYS × …`); they were *measured* from the synthesised netlist, not assumed.

## 4. Mapping the RAMs

Every RAM is an `sf_sram_macro_wrapper` instance (SRAMMacroBridge P79).  `MEMORY_TECH = 0` (GENERIC, used for all results here) is behavioural; `1` infers FPGA block RAM; `10/11/12` select open-PDK macro families with a
`MACRO_ID` from the wrapper's own planning tool, which also checks that the macro supports the requested width, byte-write granularity and read latency.
**Only GENERIC was simulated and synthesised by CacheForge.**  The data array needs a write mask at 64-bit granularity (two lanes) and the tag array none; whether a given macro offers that is the wrapper's check (its error codes E23 / E24).
A macro with a native read latency greater than `RAM_LATENCY` is rejected by the wrapper (E27): set `RAM_LATENCY` accordingly (the controller handles 1–4).

## 5. What a physical flow still has to do

Technology mapping with ABC / a liberty, timing constraints (the tag-compare and ECC-decode paths are the first places to look), floorplanning of 8 RAMs around the controller, power analysis, DFT / MBIST (the wrapper provides a
raw-word test port; CacheForge does not expose it at its top level), and a SFB2 bridge if the cache is to attach to DataFabric.  None of this was attempted.
