# 05 — Integration, DMA visibility and DataFabric

## 1. Interfaces

Both links are **Albion Link Protocol v1** (`sf_albion_pkg`): `sf_req_t` 236 bit / `sf_rsp_t` 148 bit, one-beat, in order, non-posted writes.

| Port group | Signals | Notes |
|---|---|---|
| clock / reset | `clk_i`, `rst_ni` | rising edge; active-low, asynchronous assert, **synchronous release supplied by the platform** (AlbionCore `sf_albion_reset_sync`); both links and the cache are reset together |
| upstream target | `req_valid_i / req_ready_o / req_i`, `rsp_valid_o / rsp_ready_i / rsp_o` | `req_ready_o` depends on registered state only; a response is never visible in the acceptance cycle; max outstanding = `caps_o.max_outstanding` (1 blocking, `2·NUM_MSHR` MSHR) |
| downstream initiator | `mreq_*`, `mrsp_*` | at most `MEM_MAX_OUT` outstanding — **set it ≤ the target's advertised limit**; tags are `0 … MEM_MAX_OUT-1` |
| maintenance | `cmo_valid_i / cmo_ready_o`, `cmo_op_i`, `cmo_all_i`, `cmo_addr_i`, `cmo_size_i`; `cmo_busy_o`, `cmo_done_o` (pulse), `cmo_lines_o`, `cmo_err_o` | `cmo_ready_o` is high only when the cache is idle and `req_valid_i` is low (a request wins a same-cycle tie: stop issuing requests before a CMO) |
| configuration (static) | `cfg_en_i`, `cfg_nc_en_i`, `cfg_nc_base_i`, `cfg_nc_limit_i`, `cfg_wb_dom_i`, `cfg_wb_attr_i` | change only while idle; **after changing `cfg_en` or the window, `CLEAN_INVAL` the affected range** (the cache does not) |
| status | `init_done_o`, `busy_o`, `err_evt_o`, `err_sticky_o`, `err_clear_i`, `err_addr_o`, `proto_err_o` | `proto_err_o` flags a memory-link protocol violation (response with no outstanding request, or wrong tag) |
| performance | `perf_o`, `perf_clear_i` | counter *i* in bits `[i*CNT_W +: CNT_W]`, indices in `sf_cache_pkg` |
| capability | `caps_o` | `sf_albion_pkg::sf_caps_t`: ALP 1.0, 64-bit address, 128-bit data, 8-bit tag, `max_outstanding`, features READ / WRITE (+ ECC / POISON only if `ECC_EN`) |

### Parameters

`CACHE_BYTES` (32768), `LINE_BYTES` (64), `WAYS` (4), `PADDR_W` (64), `NUM_MSHR` (1), `REPL_POLICY` (1 = PLRU, 0 = round-robin), `RAM_LATENCY` (1),
`MEM_MAX_OUT` (4), `ECC_EN` (1), `ECC_SCRUB` (1), `MEMORY_TECH` / `MACRO_ID_DATA` / `MACRO_ID_TAG` (RAM technology via the wrapper), `CNT_W` (64).
**Unsupported combinations are rejected at elaboration** (generate-time `$error`; Verilator reports it as `%Warning-USERERROR`, which `-Wno-fatal` would silently demote, so build with `-Werror-USERERROR` — `scripts/build_tb.sh` does — and treat `scripts/check_config.py`, which applies the same rules and is verified against the RTL on 29 cases by `scripts/test_config_rejection.py`, as the flag-independent gate): non-power-of-two `LINE_BYTES`, `WAYS`, `CACHE_BYTES`; `LINE_BYTES` outside 16–256;
`WAYS` > 16; fewer than 2 sets; `PADDR_W` outside 32–64 or leaving no tag bit; `NUM_MSHR` outside 1–8; `RAM_LATENCY` outside 1–4; `MEM_MAX_OUT`
outside 1–16.  `scripts/check_config.py` applies the same rules to the JSON files in `configs/` before a build.

### Request handling summary

| Request | Behaviour |
|---|---|
| illegal (ALP-LEG-01: bad opcode / alignment / zero byte enable / reserved attribute / domain 0xFF) | answered with its status, never touches arrays or memory |
| address ≥ 2^`PADDR_W` | `DECODE_ERR` |
| `attr.mem_type` = NORMAL_NC or DEVICE, address in the NC window, or `cfg_en_i` = 0 | **bypass**: one memory request, in order, response from memory; no lookup, no state change |
| cacheable | write-back, write-allocate cache path |

Domain / attribute handling: refills carry the requester's domain and attributes; **writebacks carry the configured `cfg_wb_dom_i` / `cfg_wb_attr_i`**
(the cache keeps no per-line domain).  A writeback to a region the configured attributes cannot access fails as a *writeback error* (line retained).
No domain enforcement exists in ALP v1; none is claimed.

## 2. DMA visibility — software-managed, **not** hardware-coherent

There is **no CoherenceDirectory in the repository** and no snooping: **this cache is not coherent and nothing here claims it is.**  DMA masters and other
cached agents see the cache only through memory.  The policy mirrors the repository's MemoryCore ControlCore cache (docs 03/04):

| Situation | Software must |
|---|---|
| CPU wrote a buffer that a device will read | `CLEAN` the range (writes back dirty lines, keeps them valid) before starting the device |
| a device will write a buffer the CPU reads afterwards | **before** the device starts: `CLEAN_INVAL` the range (no dirty line may later be evicted over device data); **after** completion: `INVAL` the range (drop lines fetched meanwhile) |
| device reads and writes a buffer | `CLEAN_INVAL` before, `INVAL` after |
| fine-grained shared structures (descriptors, mailboxes, flags) | place them in a **non-cacheable window** (`cfg_nc_*`) or access them with `attr.mem_type` ≠ NORMAL_WB: no maintenance is needed |
| buffers | line-aligned and a multiple of `LINE_BYTES`, so that a CPU variable never shares a line with a device buffer |
| an address accessed both cached and uncached (mismatched attributes) | `CLEAN_INVAL` it first: the uncached access sees **memory**, not the cache |

`INVAL` **discards dirty data** (counted in `cmo_dirty_discard`).  The CMO walk visits every set and filters by the range, so a CMO costs about the same for any
range size (docs/03 §3.1).  The `dma` scenario of the regression shows the documented stale-data behaviour (the model predicts the stale reads) and its repair by `INVAL` / `CLEAN`.

## 3. DataFabric

See docs/00 §3.  In short: the cache speaks ALP v1.  Connecting it to AlbionCore-based fabric or memory is direct and protocol-checked.  **Connecting it to the
SFB2 DataFabric (P03) needs the SFB2 ↔ ALP bridge that AlbionCore's own audit lists as missing; this package does not provide or claim it.**
A bridge must (a) reject or split addresses ≥ 2^32 (SFB2 `AW` = 32), (b) respect SFB2's one-outstanding-per-port rule (`MEM_MAX_OUT` = 1), and (c) map ALP statuses onto SFB2's
single error bit (the cache then reports every failure class as the same status).

## 4. Reset and bring-up sequence

1. Hold `rst_ni` low ≥ 2 clock edges; release it synchronously (`sf_albion_reset_sync`).
2. Wait for `init_done_o` (`SETS` cycles); `req_ready_o` stays low until then.
3. Program `cfg_*` while idle; the default tie-offs are `cfg_en_i = 1`, NC window off, `cfg_wb_dom_i = 8'h01` (management), `cfg_wb_attr_i = 8'h04` (privileged, normal WB).
4. Reset abandons every outstanding transaction on both links; dirty data held only in the cache is lost.

## 5. Choosing `MEMORY_TECH`

`0` GENERIC (behavioural array: simulation / formal / tiny designs), `1` FPGA (inferred block RAM), `10`/`11`/`12` open-PDK macro families with a
`MACRO_ID` planned by the SRAMMacroBridge tooling.  **Only GENERIC was simulated and synthesised here**; the FPGA and ASIC paths are the wrapper's own, were not exercised by
CacheForge, and no macro timing, area or power is stated (docs/07).
