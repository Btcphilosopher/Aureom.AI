# 03 — Microarchitecture

## 1. Block diagram

```
                           upstream ALP v1 target                         downstream ALP v1 initiator
                         req ──►┌──────────────────────────────────────────────┐──► mreq
                         rsp ◄──│                 sf_llc_cache                 │◄── mrsp
                                │                                              │
  cmo_* (maintenance) ─────────►│  front-end FSM  ◄── sf_cache_addr (slicing)  │
  cfg_* (static config) ───────►│  (decode, lookup, hit/miss, bypass, CMO walk)│
  err_* perf_* caps_o ◄─────────│        │         │          │                │
                                │        ▼         ▼          ▼                │
                                │  sf_cache_    sf_cache_   sf_cache_          │
                                │  tag_array    data_array  replacement        │
                                │  (WAYS RAMs)  (WAYS RAMs) (PLRU / RR flops)  │
                                │        ▲         ▲                           │
                                │        │   ┌─────┴──────┐                    │
                                │        │   │ sf_cache_  │ sf_cache_  sf_cache_mshr (NUM_MSHR entries)
                                │        │   │ writeback  │ refill     + park register + response-order queue
                                │        │   └─────┬──────┘ (queue of line refills)       (NUM_MSHR > 1)
                                │        │         ▼          ▼                │
                                │        │      sf_cache_memport  (3 clients, order queue, ALP initiator rules)
                                │        │                                     │
                                │        └─ sf_cache_perf (counters, latency)  │
                                └──────────────────────────────────────────────┘
        every RAM = sf_sram_macro_wrapper (SRAMMacroBridge P79): GENERIC / FPGA / ASIC macro, optional SECDED
```

## 2. Modules

| File | Role | Key facts |
|---|---|---|
| `sf_cache_pkg.sv` | opcodes, event / error indices | no geometry-dependent functions (tool-portable) |
| `sf_cache_addr.sv` | address decomposition and reconstruction | pure bit slicing; rejects unsupported geometry; formally proved (`formal/fv_cache_addr`) |
| `sf_cache_tag_array.sv` | tag / valid / dirty storage | one RAM per way, entry `{tag, dirty, valid}`, SECDED over the whole entry; one read of all ways per access; per-way write |
| `sf_cache_data_array.sv` | line storage | one RAM per way, `SETS × BEATS` words of 128 bit (2 × 64-bit SECDED lanes = 144 stored bits) |
| `sf_cache_replacement.sv` | victim choice + metadata | tree-PLRU or round-robin; invalid ways first; formally proved (`formal/fv_replacement`) |
| `sf_cache_mshr.sv` | miss-status table | miss line / set / **reserved way**, refill phase, first memory tag, error + status, waiter count, request class (write / domain / attributes); merge-compatibility and set-ownership tests; formally proved (`formal/fv_mshr`) |
| `sf_cache_memport.sv` | memory-side ALP v1 initiator | 3 clients (writeback, refill, bypass), registered request stage, tag = order-queue slot, in-order completion routing |
| `sf_cache_refill.sv` | refill controller | `BEATS` reads per line, queue of `DEPTH` line refills (overlap), writes beats into the data array as they return |
| `sf_cache_writeback.sv` | writeback controller | `BEATS` array reads → `BEATS` writes; skips uncorrectable beats; collects every response |
| `sf_cache_perf.sv` | performance counters | 24 event counters + 4 latency registers, 64-bit |
| `sf_llc_cache.sv` | top: front-end FSM, CMO walk, ECC policy, response path | `NUM_MSHR = 1` blocking; `> 1` MSHR extension |

## 3. Blocking front-end FSM (`NUM_MSHR = 1`)

```
S_INIT ─(SETS cycles: write zero entries)─► S_IDLE
S_IDLE ─ accept req ─► S_DECODE ─┬─ illegal / out-of-range ─► respond ─► S_IDLE
                                 ├─ not cacheable ─► S_BYP ─► S_BYPW ─► respond ─► S_IDLE
                                 └─ cacheable: tag read ─► S_TAG ─► [S_SCRUBT] ─► S_CMP
S_CMP ─ hit ─► S_HIT ─► (read) S_RDW ─► respond            (partial write) S_RDW ─► S_WRITE ─► [S_WDIRTY] ─► respond
      └ miss ─► S_MISS ─┬─ dirty victim ─► S_WB ─► (error: abort, victim kept, respond error)
                        │                     └─► S_EVICT ─┐
                        ├─ clean victim ─► S_EVICT ────────┤ invalidate the victim way
                        └─ invalid way ────────────────────┴─► S_RFS ─► S_RFW ─► (error: respond) ─► S_INSTALL ─► S_HIT (replay)
S_IDLE ─ accept CMO ─► S_CMO_RD ─► S_CMO_TAG ─► S_CMO_CHK ─(dirty)─► S_CMO_WB ─► … next way / set … ─► S_CMO_DONE ─► S_IDLE
```

* **Tags are read, then compared from a registered buffer** (`S_TAG` captures, `S_CMP` compares): the compare is not on the RAM-output path.
* **Refill-then-replay**: after a refill the request executes through the same `S_HIT` path as a hit; no second lookup is needed.
* The **victim way is invalidated before the refill** starts, so a failed or interrupted refill can never leave a half-written valid line.
* Replacement is touched on every hit, on every install and after a writeback error (docs/02 §6).

### 3.1 Cycle counts (measured, Verilator, RAM latency 1, memory latency 1 cycle, no back-pressure)

Let `L = RAM_LATENCY`.  Request-to-response means *acceptance edge → first cycle with `rsp_valid_o`*.

| Case | Cycles | Provenance |
|---|---|---|
| read hit | `4 + 2L` = **6** | derived from the FSM (DECODE 1 + tag wait L + CMP 1 + HIT 1 + data wait L + response register 1); **measured** minimum on read-only traffic: 6 |
| full-beat write hit, line already dirty | `4 + L` = **5** | derived; **measured** overall minimum: 5 |
| full-beat write hit, line clean | `5 + L` = 6 | derived (one extra `S_WDIRTY` tag write); not separately measured |
| partial-write hit | `5 + 2L` (dirty line), `6 + 2L` (clean) | derived (read-modify-write of the beat); not separately measured |
| read miss, clean / invalid victim | **16** | **measured**: `PERF_LAT_MIN` = 16 on every successful miss in the `cold` scenario with a 1-cycle memory (the memory's own latency adds on top).  A *refill-failure* response skips the install and is also sampled: 13 cycles observed in `random` (its one injected refill error) |
| read miss, dirty victim | up to **37** | **measured** maximum request→response over the `replace` scenario with no back-pressure (adds the writeback of `BEATS` beats, ≈ 3 cycles per beat); `PERF_LAT_MAX` = 36 (the perf sample ends one cycle before the response handshake) |
| CMO over all sets | ≈ `SETS × (2 + L + WAYS)` + writebacks | derived; not measured |
| reset initialisation | `SETS` cycles | derived (tag RAM zero-fill); `req_ready_o` low until `init_done_o` |

These are **cycle counts of this RTL in simulation**, not times: no clock frequency and no SRAM access time is claimed.  The hit path is
deliberately conservative (registered tag compare, serial tag-then-data access); a parallel tag/data read is a documented future
optimisation.

## 4. MSHR extension (`NUM_MSHR > 1`)

Goal: overlap the memory latency of several misses **without breaking ALP v1's in-order contract** and without changing the functional
behaviour of the blocking cache.

```
 accept ─► ROQ slot allocated (in order) ─► front end (as above)
   hit            ─► respond into its ROQ slot (may complete before older misses)
   miss, set free ─► S_MISS … S_EVICT ─► S_RFS: enqueue refill, park the request in its MSHR ─► front end FREE
   set owned by an outstanding miss, or MSHR table full ─► PARK (one parked request; no younger request is accepted)
   refill returns ─► beats written ─► installer makes the line valid (tag write + replacement touch, when the ports are free)
   MSHR "done" ─► REPLAY in S_IDLE (priority over parked and new requests) ─► S_HIT ─► respond into the parked request's ROQ slot ─► free MSHR
   refill failed ─► S_RERR ─► error response into the ROQ slot, no install
 ROQ head with a completed response ─► upstream response (strictly in acceptance order, ALP-ORD-01)
```

Rules, and why they are safe:

1. **One in-flight miss per set.**  A request to a set owned by an MSHR is *parked* until the MSHR is freed.  Hits and misses to
   *different* sets proceed (hit-under-miss, miss-under-miss).  Consequence: the per-set history of lookups, victim choices and
   replacement touches is **identical to the blocking cache's** — which is why the same independent Python model is a valid oracle for
   the MSHR build (identical responses, counters and final memory) and why "do not merge requests with incompatible ordering or
   permissions" holds by construction: **no request is ever merged**.  `sf_cache_mshr` still computes `merge_ok_o`
   (read-only, same domain, same memory-type / privilege / security bits; a write never merges; formally proved) for a future
   read-merge extension.
2. **Replay order is irrelevant to correctness** (each MSHR owns its set), and **response order is restored by the ROQ** (`2 × NUM_MSHR`
   entries = the advertised `max_outstanding`).
3. **The memory link stays in order**: refills of several lines are issued back-to-back through the refill queue; the memory port's order
   queue routes each response to the writeback engine, the refill engine or a bypass access.
4. **Port arbitration without deadlock**: the front end has priority on the data array; a refill beat is accepted only in a cycle the
   front end leaves free (`rf_grant` depends on registered state only, never on a valid).  The installer writes the tag RAM and touches
   the replacement state only in cycles the front end leaves free.  Replays have priority over parked and new requests, so a parked
   request can never starve the MSHR it waits for.
5. **CMO** is accepted only when nothing is queued, parked or outstanding (`no_work`), preserving "ordered after all earlier requests".
6. **Writeback of a dirty victim still blocks the front end** (it owns the data-array read port); only the refill latency is overlapped.
7. Uncorrectable data on a clean hit is refetched through the same MSHR path (`refetched` flag → a second uncorrectable error is
   poisoned, never an endless loop).

Measured overlap (blocking vs MSHR build, same stimulus) and area are in docs/06 and docs/07.

## 5. Memory-side ordering and ALP obligations

`sf_cache_memport` registers the request (ALP-REQ-02), counts outstanding requests conservatively from the moment a request is loaded
(ALP-OUT-01, `MEM_MAX_OUT` ≤ the target's advertised limit), uses the order-queue slot as the tag (unique among outstanding requests,
ALP-TAG-01) and accepts responses independently of request progress (ALP-RSP-06).  Memory tags are therefore `0 … MEM_MAX_OUT-1`.
The AlbionCore link checker is attached to **both** links in every simulation and the memory port is formally checked against the same
checker (docs/06).
