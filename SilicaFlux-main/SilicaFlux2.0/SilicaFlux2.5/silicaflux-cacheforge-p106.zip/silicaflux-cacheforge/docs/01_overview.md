# 01 — Overview, decisions and traceability to the brief

## 1. What CacheForge is

`sf_llc_cache` is a synthesizable, parameterisable, set-associative, write-back / write-allocate **last-level cache controller** for SilicaFlux cloud
processors.  It sits between an initiator (CPU cluster, accelerator) and a memory-side fabric; **both interfaces are Albion Link Protocol v1** (AlbionCore 0.1.0:
64-bit address, 128-bit data, 16-byte byte-enables, 8-bit tag, in-order, non-posted writes).  Storage is built from the repository's **SRAMMacroBridge wrapper**.
The initial configuration is the brief's: 32 KiB, 64-byte lines, 4 ways, 64-bit physical addresses, 128-bit link, one outstanding miss — and every one of those is a parameter.

Delivery order followed the brief: the **blocking cache was built and verified first** (evidence frozen in `reports/stage1_frozen/` before any MSHR code was written), then the
MSHR extension was added behind `NUM_MSHR`, and the blocking regression was re-run on the shared RTL (still 100 %).

## 2. Key decisions and why

| Decision | Reason |
|---|---|
| ALP v1 on both sides | the only protocol in the repository with 64-bit address + 128-bit data and a machine-checkable contract (link checkers); DataFabric P03 is 32-bit SFB2 and Meridian P83 uses an older format (docs/00) |
| RAMs through `sf_sram_macro_wrapper` | one RTL for behavioural / FPGA / open-PDK macro storage and the repository's verified SECDED; no SRAM is invented |
| tags + valid + dirty in ECC-protected RAM (no flop copies) | one protection domain for all state that can lose data; price: SETS-cycle init and walk-based flush |
| serial tag-then-data access, registered compare | simple, low-power, timing-friendly; hit latency 6 cycles (docs/03) — optimisation left for later |
| replacement: tree-PLRU / round-robin, invalid-way first | deterministic, 3 bits/set (4-way), formally proved (docs/02 §6) |
| victim invalidated **before** the refill | a failed refill can never leave a half-written valid line |
| refill-then-replay | the request executes through the ordinary hit path; no second lookup |
| writeback error keeps the line dirty | dirty data is never dropped because memory said no |
| uncorrectable data is **poisoned, not laundered** | corrupt data never becomes valid data (docs/04) |
| DMA: software-managed (CLEAN / INVAL / CLEAN_INVAL + non-cacheable window) | no CoherenceDirectory exists; the policy mirrors MemoryCore's ControlCore cache |
| MSHR: one miss per **set**, no merging, in-order response queue | preserves ALP's in-order contract and keeps per-set behaviour identical to the blocking cache, so one independent model verifies both |
| independent model by a separate agent from the spec only | a model written from the RTL would only restate it |

## 3. Traceability

| Brief section | Implemented in | Evidence |
|---|---|---|
| 1 Repository inspection | docs/00 | every named dependency read; what exists / is verified stated per item; CoherenceDirectory does not exist; SFB2 bridge missing |
| 2 Organisation: tag, data, valid, dirty, replacement metadata, refill, writeback, MSHR; 32 KiB / 64 B / 4-way / 1 miss / 64-bit / 128-bit — all configurable | `sf_cache_tag_array`, `sf_cache_data_array`, `sf_cache_replacement`, `sf_cache_refill`, `sf_cache_writeback`, `sf_cache_mshr`, `sf_llc_cache` | 14 configurations in the regression (docs/06); unsupported parameter combinations rejected (docs/05, `test_config_rejection.py`: 29/29 agree with RTL elaboration) |
| 3 Address decomposition, reconstruction, rejection of unsupported geometry | `sf_cache_addr` | proved for 5 geometries (`formal/fv_cache_addr`), 4 injected defects caught |
| 4 Read path (accept, tag lookup, hit, extract, respond, miss, refill, install, complete; identity preserved) | `sf_llc_cache` states `S_DECODE … S_RDW` | regression + ALP checkers (tag echo, ordering) in every run |
| 5 Write path: write-back / write-allocate; full-beat, partial, byte enables, dirty tracking, eviction, writeback, refill before partial update | `S_HIT`, `S_RDW → S_WRITE → S_WDIRTY`, `S_MISS … S_INSTALL` | `partial`, `raw`, `replace`, `assoc`, `sameline` scenarios; mutants W1–W4, E1–E6 killed.  *"Full-line writes"*: see docs/08 (ALP v1 is one 16-byte beat per request; write-without-fetch not implemented) |
| 6 Replacement: deterministic, invalid first, documented metadata updates and corner cases | `sf_cache_replacement`, docs/02 §6 | unbounded proofs (8 configurations), 6 injected defects caught, mutants R1–R4 killed |
| 7 Miss management: blocking first, then configurable MSHR with miss address, waiters, refill status, way, memory tag, error state; no incompatible merges | `sf_cache_mshr` + MSHR path in `sf_llc_cache` | MSHR table proved unboundedly for 1–4 entries (never merges writes / different class); 6 MSHR configurations; mutation campaign (docs/06) |
| 8 DMA visibility: safe policy, no coherence claim | docs/05 §2, CMO port, NC window / `mem_type` bypass | `dma` + `cmo` + `bypass` scenarios incl. the documented stale-data behaviour predicted by the model |
| 9 ECC: data, tags; correctable / uncorrectable / dirty / refill errors | docs/04, wrapper SECDED | directed injection into raw codewords (T1–T9), 12 ECC-policy mutants |
| 10 Performance counters: read/write hits+misses, refills, evictions, writebacks, stall cycles, miss latency, memory bytes | `sf_cache_perf` (24 events + 4 latency registers) | 16 counters compared exactly with the model; stall / latency sanity-checked; bytes = 16 × memory beats |
| 11 Verification list: cold, repeated hits, associativity, replacement, partial writes, dirty eviction, RAW, refill failure, random back-pressure, reset and flush, same-line conflicts, non-coherent DMA; compare with an independent model | `tb/`, `model/` | 12 scenarios × 14 configurations × 3 seeds, random back-pressure in all, reset in the middle of refill / CMO (T9) |
| 12 Physical design: macros or FPGA inference through existing wrappers; measure synthesised logic and memory organisation; **do not invent** SRAM time / area / power | `synth/`, `scripts/run_synth.py`, docs/07 | measured generic cell counts and RAM organisation; **no** SRAM timing, area or power stated |
| Deliverable files | `rtl/cache/sf_llc_cache.sv`, `sf_cache_tag_array.sv`, `sf_cache_data_array.sv`, `sf_cache_replacement.sv`, `sf_cache_mshr.sv`, `sf_cache_refill.sv`, `sf_cache_writeback.sv`, `sf_cache_perf.sv` (+ `sf_cache_pkg.sv`, `sf_cache_addr.sv`, `sf_cache_memport.sv`) | self-checking tests `tb/`; formal `formal/`; configs `configs/`; synthesis reports `reports/synth.md`; docs `docs/` |
| Definition of done: hits, misses, refills, writebacks, replacement and back-pressure without losing or corrupting acknowledged data | — | the model compares **every** acknowledged response and the **final memory image** after a closing flush (docs/06) |
