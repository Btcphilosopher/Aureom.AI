# 00 — Repository audit: which dependencies exist, and which are verified

Scope: `btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/` (HDL is delivered as ~140 archives; `.sf` files are plain
SystemVerilog with a custom extension).  Method: every archive named in the brief was extracted into a scratch
directory and **read** (README, interface documents, verification reports, RTL headers); a name search over *every*
archive in the repository looked for caches, coherence and directory IP.  Nothing in the repository was modified.

"Verified" below means **what the dependency's own report claims**, plus — where stated — **what was independently
re-run or exercised in this project**.  Claims from a dependency's own reports were *not* re-derived.

## 1. Summary table

| Brief item | Exists? | What it is | Used by CacheForge | Evidence |
|---|---|---|---|---|
| AlbionCore transaction interface | **Yes** — `albioncore-0.1.0.zip` | **ALP v1**: 64-bit address, 128-bit data, 16-bit byte enables, 8-bit tag, 8-bit domain, 4-bit status, single-beat, in-order, non-posted writes, one clock, async-assert/sync-release active-low reset | **Yes — both cache interfaces are ALP v1**; vendored: `sf_albion_pkg`, `skid`, `fifo`; test-only: `link_checker`, `chan_checker` | Its report: 14 Verilator simulations, 20.5 M checks, 19 formal jobs, 67/67 mutants killed. **Here:** the package and link checkers compiled and ran unmodified; the checkers sat on both CacheForge links in every simulation and did not raise a false alarm; the mutation campaign (docs/06) shows they do catch protocol defects |
| Meridian | **Yes** — P83 `silicaflux-meridian-p83.zip`, P102 `meridianqos` | Cloud crossbar with its **own** Albion transaction format, written **before** AlbionCore existed (2-bit op, 3-bit status, `tc`, `priv`) — **not wire-compatible with ALP v1** | No (no bridge exists) | Its report: bounded formal only (1 unbounded proof), 48/48 sims, 31/31 mutants; Citadel and endpoints are models |
| DataFabric | **Yes** — P03 `silicaflux-datafabric.zip` (+ `-noc`, `-noc-v2`) | Crossbar + DMA on **SFB2**: **32-bit address**, DW 32/64/128, one outstanding transaction per crossbar port, no tag/ID, 1-bit `rsp_error` | **Not directly** — see §3 | Its report: simulation, **unbounded** formal for the interconnect (ABC PDR), bounded for the DMA, gate-level; not tape-out ready |
| SRAMCore | **Yes** — P71 | 1RW synchronous SRAM, byte enables, fixed read latency | indirectly (the wrapper replaces it for caches) | own report: Verilator + Icarus + Yosys |
| SRAMBank | **Yes** — P72 | N banks of SRAMCore, 2..64 | No (a cache way is one RAM) | own report |
| MemoryMatrix | **Yes** — P101 | Banked SRAM for CPU / tensor / DMA, 64-bit words, arbitration, ECC | No (different job) | own report; not ASIC-ready |
| SRAMMacroBridge | **Yes** — P79 `sf_sram_macro_wrapper` | One logical SRAM in front of GENERIC / FPGA / real open-PDK macros (IHP, GF180, SKY130); optional Hsiao SECDED per word or per lane; MBIST port | **Yes — every cache RAM is an instance of it** (vendored unmodified, SHA-256 in `third_party/SHA256SUMS`) | Its report: 28/28 generic, 12/12 FPGA, 20/20 ASIC-model sims, ECC RTL == independent Python golden model (726 vectors for K = 8…128, incl. K = 64), 20/23 mutants killed. **OpenROAD / DRC / LVS / STA not run; silicon qualification not established.** ECC of the **53-bit tag-entry codeword** is *not* in its vector list: CacheForge's own injection tests cover it |
| ECCMemory | **Yes** — P77 | Extended-Hamming (72,64) codec + RAS wrapper; **SAT-proved** codec | **No.** CacheForge uses the Hsiao SECDED that is *built into the P79 wrapper*; P77's codec is a different code. Not mixed | Its report: 298/298 SAT proofs for the codec |
| Existing CPU caches | **Yes, but not reusable as an LLC** | (a) `memory_cache_repo` `set_assoc_cache`: generic educational cache, no byte enables, no IDs, no ECC, one-word memory port; (b) MemoryCore `sfmem_cache` (ControlCore D/I-cache): 32-bit words, ControlCore-specific; (c) `sf_sram_ex_cpu_dcache_data`: a 4 KiB SRAM example | **Design vocabulary only**: the maintenance operations (CLEAN / INVAL / CLEAN_INVAL), the software-managed DMA protocol and the "non-cacheable window" idea follow MemoryCore docs 03/04 | MemoryCore's own report: model-compared tests, 10 cache mutants killed |
| DMA | **Yes** — DataFabric DMA, CloudDMA P64, StreamDMA P103, HPC DMA adapter | DMA masters (SFB2 / AXI4) | No | own reports |
| MemoryGuard | **Yes** — P104 | Region-based protection (not translation); 4 ingress ports | No | own report; "protection, not an IOMMU" |
| Clock / reset conventions | **Yes** | AlbionCore: `clk_i`, `rst_ni`, async-assert / sync-release, one reset per clock domain, datapath storage not reset. Legacy IP: `clk`, `rst_n`, same polarity | **Yes** (AlbionCore convention) | `RESET_CLOCK_CONTRACT.md` |
| **CoherenceDirectory** | **No.** Searched every archive (names and file lists) for *coheren*, *directory*, *snoop*, *MESI*: nothing | — | **Not claimed anywhere** | — |

## 2. What this means for the design

1. **One protocol, both sides: ALP v1.**  It is the only protocol in the repository that natively carries 64-bit addresses and
   a 128-bit data word, which is exactly the brief's configuration ("64-bit physical addresses, 128-bit DataFabric interface").
   A 64-byte line is **four single-beat transfers** because ALP v1 has no bursts; the refill and writeback engines issue them
   back to back (up to `MEM_MAX_OUT` in flight).
2. **Storage = the existing wrapper.**  `sf_cache_tag_array` and `sf_cache_data_array` are thin policy layers over
   `sf_sram_macro_wrapper`, so GENERIC / FPGA inference and the open-PDK macro path are selected by `MEMORY_TECH` /
   `MACRO_ID` without touching the cache RTL.  No SRAM is invented.
3. **ECC = the wrapper's SECDED**: one codeword per tag entry (valid + dirty + tag), one per 64-bit data lane.
4. **Not hardware-coherent.**  There is no CoherenceDirectory.  Visibility to DMA and other agents is **software-managed**
   (docs/05), identical in spirit to the MemoryCore ControlCore cache.

## 3. DataFabric: what "connects correctly" can honestly mean today

* The cache is an ALP v1 **target** on its request side and an ALP v1 **initiator** on its memory side.  The memory side is
  what attaches to DataFabric / memory.
* DataFabric (P03) speaks **SFB2**: 32-bit address, 1 outstanding transaction per crossbar port, no tag.  AlbionCore's own
  audit lists an **SFB2 ↔ ALP bridge as a missing dependency** (it needs a decision on the domain id of each legacy master).
  Meridian P83 speaks a third, older, format.  Therefore:
  * **CacheForge ⇄ AlbionCore-based fabric / memory: native, checked** by the ALP link checkers in simulation (and formally for
    the checker properties, docs/06).
  * **CacheForge ⇄ SFB2 DataFabric: needs the SFB2 ↔ ALP bridge, which does not exist in the repository.**  This package does
    **not** claim that connection; a bridge would also have to reject or split addresses above 2^32 (SFB2 `AW` = 32) and map
    ALP statuses onto SFB2's single error bit.
* Capability word (`caps_o`): `max_outstanding` = 1 for the blocking cache, ECC / POISON feature bits set only when `ECC_EN`.

## 4. Tools actually used (and their versions)

Verilator 5.49 (PyPI wheel `verilator 5.48.0`), Yosys 0.71 (YoWASP wheel) with SymbiYosys, z3 (PyPI `z3-solver`), Python 3.13.
The repository's earlier projects report Verilator 5.020 / Yosys 0.33; this package was **not** run with those versions.
No vendor tool, PDK or FPGA board was available or used.
