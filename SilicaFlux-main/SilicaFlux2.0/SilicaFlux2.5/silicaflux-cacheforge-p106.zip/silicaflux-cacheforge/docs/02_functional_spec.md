# 02 — Functional specification (timing-independent behaviour)

This is the normative, **timing-independent** behaviour of `sf_llc_cache`.  The RTL implements it; the Python reference
model (`model/`) implements it independently; the testbench compares the two.  Cycle-level timing is *not* specified
here (see `03_microarchitecture.md`) — everything below is a function of the **sequence** of accepted requests, never of
back-pressure or latency.

All interfaces are **Albion Link Protocol v1** (`sf_albion_pkg`, AlbionCore 0.1.0): 64-bit address, 128-bit data,
16-bit byte enable, 8-bit tag, single-beat, in-order, non-posted writes.  A *beat* is 16 bytes.

## 1. Geometry

| Symbol | Meaning | Default | Rule |
|---|---|---|---|
| `CACHE_BYTES` | data capacity | 32768 | power of two |
| `LINE_BYTES` | line size | 64 | power of two, 16 ≤ `LINE_BYTES` ≤ 256 |
| `WAYS` | associativity | 4 | power of two, 1..16 |
| `SETS = CACHE_BYTES / (LINE_BYTES·WAYS)` | sets | 128 | power of two, ≥ 2 |
| `BEATS = LINE_BYTES / 16` | beats per line | 4 | 1..16 |
| `PADDR_W` | implemented physical address bits | 64 | 32..64 |
| `OFF_W = log2(LINE_BYTES)`, `IDX_W = log2(SETS)` | | 6, 7 | |
| `TAG_W = PADDR_W − OFF_W − IDX_W` | | 51 | |

Unsupported combinations (non-power-of-two, `SETS < 2`, `WAYS > 16`, `PADDR_W` outside 32..64, …) are **rejected at
elaboration**; they are never silently rounded.

## 2. Address decomposition

For a request address `A` (64-bit, `A[3:0] == 0` is enforced by ALP legality):

```
beat   = A[OFF_W-1 : 4]                     (0 .. BEATS-1)
set    = A[OFF_W+IDX_W-1 : OFF_W]
tag    = A[PADDR_W-1 : OFF_W+IDX_W]
line   = A with the low OFF_W bits cleared  ("line base address")
```

Reconstruction: `line_base(tag, set) = (tag << (OFF_W+IDX_W)) | (set << OFF_W)`.  If `PADDR_W < 64` and
`A[63:PADDR_W] != 0` the request is answered `SF_ST_DECODE_ERR` (§4 step 2).

## 3. Cache state

Per `(set, way)`: `valid`, `dirty`, `tag`, `LINE_BYTES` bytes of data.  Per set: replacement metadata (§6).
After reset every line is invalid (`valid = dirty = 0`) and every replacement state is 0.

## 4. Processing of one upstream request (strictly sequential, in acceptance order)

1. **Legality** (`sf_albion_pkg::sf_req_check_bits`, ALP-LEG-01).  Not legal → response with that status, zero data,
   no state change, no memory traffic.  Counter `err_rsp` += 1.
2. **Range.** `PADDR_W < 64` and `A[63:PADDR_W] != 0` → status `DECODE_ERR`, same treatment as step 1.
3. **Cacheable?**  `cacheable = cfg_en && attr.mem_type == NORMAL_WB(0) && !(cfg_nc_en && cfg_nc_base ≤ A < cfg_nc_limit)`.
   (The window compare is unsigned on the full 64-bit address.)  Not cacheable → **bypass** (§4.1).
4. **Lookup.**  Hit ⇔ some way of `set` has `valid && tag match`.  At most one way can match (invariant).
5. **Read hit:** response data = the 16-byte beat of the line, lanes not enabled by `be` forced to zero (ALP-RSP-07);
   `touch(set, way)`; counter `rd_hit`.
6. **Write hit:** enabled byte lanes of the beat are overwritten with request data; `dirty ← 1`; `touch`; counter
   `wr_hit`; response status OKAY, `is_write = 1`, zero data.
7. **Miss** (read or write; counter `rd_miss` / `wr_miss` incremented at lookup):
   1. **Victim**: the lowest-numbered invalid way if any, otherwise the replacement-policy victim (§6).
   2. **Eviction** of a valid victim:
      * *dirty*: write back the whole line — `BEATS` WRITE requests (address `victim_base + 16·b`, `be = FFFF`,
        data = line beat `b`, `b = 0..BEATS-1` ascending).  All `BEATS` requests are always issued.  If **any** of
        them completes with a status other than OKAY the miss is **aborted** (§4.2 *writeback error*).
        On success: counters `writebacks` += 1, `evictions` += 1.
      * *clean*: nothing is written; `evictions` += 1.
      The victim way becomes **invalid** (valid = dirty = 0).
   3. **Refill**: `BEATS` READ requests (`line_base + 16·b`, `be = FFFF`, ascending); all are always issued.  If every
      response is OKAY the data is installed, `valid ← 1`, `dirty ← 0`, `tag ← tag(A)`, `touch(set, way)`, counter
      `refills` += 1, and the original request **then executes exactly as a hit on that way** (steps 5/6, *without*
      incrementing `rd_hit`/`wr_hit`).  If any response is not OKAY: **refill error** (§4.2).
8. Counter `err_rsp` is incremented for every response whose status is not OKAY.

### 4.1 Bypass (uncacheable) requests
The request is forwarded **unchanged** (op, dom, attr, address, be, data) as one memory-side request; no lookup, no state
change, no `touch`.  The response carries the memory status; read data is masked with `be`; non-OKAY → zero data.
Counters: `bypass_rd` or `bypass_wr`.  *Mismatched attributes are not hardware-reconciled*: if a line is cached and the
same address is also accessed uncached, the uncached access sees memory, not the cache (software must `CLEAN_INVAL`
first; MemoryCore rule K7).

### 4.2 Error handling (memory-side failures)
* **Writeback error** (dirty victim, a WB beat failed): the **victim stays valid and dirty with its data intact** (no
  data is lost); no refill is issued; `touch(set, victim)` is applied so the next miss picks a different way; response
  status = status of the **first** failing WB beat (ascending beat order); zero data; counter `wb_errors` += 1.
  `writebacks` and `evictions` are *not* incremented.  (Beats that succeeded before the failure remain written in
  memory; that is harmless because the line is still dirty and will be written again.)
* **Refill error**: the victim was already evicted/invalidated; **no line is installed** (the way stays invalid); no
  `touch`; response status = status of the first failing refill beat; zero data; counter `refill_errors` += 1.
  A *write* miss whose refill failed is **not performed** (write-allocate needs the line).

### 4.3 Memory-side traffic (for trace checking)
Each memory-side request is a single-beat, 16-byte, 16-byte-aligned READ or WRITE.  The model emits them in the order
the cache issues them: for a miss `[WB beats] [refill beats]`, for a bypass the one forwarded request, for a CMO the WB
beats of each cleaned line in walk order (§7).  Counters `mem_rd_beats`/`mem_wr_beats` count **every** memory-side
request issued (including ones that fail); bytes = beats × 16.

## 5. Responses (ALP v1)
`tag` = request tag, `status` as above, `meta = {4'b0, corrected, poisoned, last=1, is_write}`; in this functional
model `corrected = poisoned = 0` (ECC events are tested separately, §8).  Read data (OKAY only) is masked by `be`;
every other response has zero data.  Responses are returned in request order.

## 6. Replacement

State per set; `touch(set, way)` is called on **every hit**, on every **install**, and after a **writeback error**
(§4.2).  Invalid ways are always preferred (§4.7.1); the policy only chooses among valid ways.

* **`REPL_POLICY = 1`, tree pseudo-LRU** (`WAYS` power of two).  `WAYS − 1` bits per set, heap-indexed (node 0 = root,
  children of node `n` are `2n+1` (left) and `2n+2` (right)); leaves are ways `0..WAYS-1` left to right.  A bit value
  `0` means "the **left** subtree is least-recently-used", `1` means the right.
  * *victim*: start at the root; at node `n` with bit `b` go to child `2n+1+b`; the leaf reached is the victim.
  * *touch(way w)*: for every node on the root-to-leaf path of `w`, set the node bit to point **away** from `w`
    (`w` went left → bit ← 1; `w` went right → bit ← 0).
  * reset state: all zero (victim 0).  `WAYS = 1`: no state, victim 0.
* **`REPL_POLICY = 0`, round-robin.**  One `log2(WAYS)`-bit counter per set (none for `WAYS = 1`).
  *victim* = counter.  *touch(way w)*: `counter ← (w + 1) mod WAYS` **only for an install or writeback-error touch**; a
  **hit does not change** the counter.  Reset: 0.

Corner cases: `WAYS = 1` → direct-mapped, victim always way 0.  The chosen victim is never an invalid way while an
invalid way exists.  A touch never selects a different way than the one touched.

## 7. Maintenance operations (CMO)

Issued through the separate `cmo_*` port **only when the cache is idle** (no request in flight, response channel
empty); the cache is **blocked** (accepts no request) while a CMO runs, so the CMO is ordered after all earlier and
before all later requests.  Operations: `CLEAN(1)`, `INVAL(2)`, `CLEAN_INVAL(3)`.

Scope: `all = 1` → every valid line; otherwise a range `[start, end)` with `end = min(start + size, 2^64)` (65-bit
arithmetic, `size = 0` → nothing): a line is in scope iff it is valid and
`line_base < end && line_base + LINE_BYTES > start`.

The walk visits sets `0..SETS-1` ascending, ways `0..WAYS-1` ascending, and for every line in scope:

| op | dirty line | clean line |
|---|---|---|
| CLEAN | write back the line (`BEATS` WRITEs as §4.7.2), `dirty ← 0`, line stays valid; `writebacks` += 1 | nothing |
| INVAL | `valid ← 0`, `dirty ← 0`, **data discarded**; `cmo_dirty_discard` += 1 | `valid ← 0` |
| CLEAN_INVAL | write back, then `valid ← 0`; `writebacks` += 1 | `valid ← 0` |

`cmo_lines` += 1 per line in scope.  A CMO writeback that fails: the line **stays valid and dirty** (CLEAN /
CLEAN_INVAL) and `wb_errors` += 1; the walk continues with the next line; the CMO reports `cmo_err`.  `touch` is **not**
applied by a CMO.  `evictions` is not incremented by a CMO.

## 8. Not covered by the timing-independent model (tested directly)
ECC corrections/uncorrectable events (injected faults), reset in the middle of traffic, `RAM_LATENCY` /
`MEM_MAX_OUT` variations (they change timing, not behaviour), stall-cycle and latency counters.

## 9. Interchange file formats (model ↔ testbench)

All files are text, one record per line, fields separated by single spaces, **hex without `0x`** unless marked `(dec)`.
`#` starts a comment line.

### 9.1 Stimulus `stim_<name>.txt`
```
CFG  <seq> <en 0/1> <nc_en 0/1> <nc_base 16hex> <nc_limit 16hex>
REQ  <seq> <op 1hex> <tag 2hex> <dom 2hex> <attr 2hex> <addr 16hex> <be 4hex> <data 32hex>
CMO  <seq> <op 1hex> <all 0/1> <start 16hex> <size 16hex>
DMAW <seq> <addr 16hex> <nbytes (dec) 1..64> <bytes: 2*nbytes hex, byte0 first>   # backdoor (DMA) write to memory
MERR <seq> <kind R|W> <line 16hex> <status 1hex> <count (dec)>                   # arm memory error injection
```
`<seq>` is a running record number (dec) starting at 0.  The testbench issues records **in file order**; before every
`CFG`, `CMO`, `DMAW` and `MERR` it waits until all earlier requests have completed (barrier).  Consecutive `REQ`
records may be issued back-to-back (the cache accepts them one at a time).  The generator always ends the file with
`CMO 3 1 0 0` (CLEAN_INVAL all) so that the final memory image is complete.

`MERR`: the next `<count>` memory-side requests of kind `<kind>` (R = READ, W = WRITE) whose 64-byte-aligned
**line base** (`addr & ~(LINE_BYTES-1)`) equals `<line>` complete with status `<status>` (data zero, and for a WRITE the
write is **not** performed).  `count` = 0 means *forever*.  Several `MERR` may be armed at once (independent
counters, first match in file order wins).

### 9.2 Initial memory contents
A memory-side 16-byte word that has never been written holds, for byte address `a` (64-bit):
`byte(a) = ((a * 0x9E3779B97F4A7C15) mod 2^64) >> 56` (top byte of the 64-bit product).  Both model and testbench use this.

### 9.3 Expected files (written by the model)
* `exp_rsp_<name>.txt`: one line per `REQ` in order: `<seq> <tag 2hex> <status 1hex> <meta 2hex> <data 32hex>`
* `exp_mem_<name>.txt`: one line per memory-side request in issue order:
  `<idx (dec)> <R|W> <addr 16hex> <be 4hex> <wdata 32hex (0 for R)> <status 1hex>` (`status` = injected status, 0 normally)
* `exp_cnt_<name>.txt`: `<counter name> <value (dec)>` lines for the counters of §10
* `exp_img_<name>.txt`: after the final CMO: one line `<addr 16hex> <data 32hex>` for every 16-byte word that was
  ever written to memory (by a DMAW, a bypass write or a writeback), sorted by address.
* `exp_cmo_<name>.txt`: one line per `CMO` record: `<seq> <lines (dec)> <dirty_discard (dec)> <err 0/1>`

## 10. Counters (names are normative)
`rd_hit rd_miss wr_hit wr_miss refills evictions writebacks mem_rd_beats mem_wr_beats bypass_rd bypass_wr cmo_lines
cmo_dirty_discard err_rsp refill_errors wb_errors`.

## 11. Ambiguities found by the independent model author, and how they were resolved

The Python model was written by a separate agent from §1–§10 **only** (it never saw the RTL).  It tagged every point where the text was ambiguous, contradictory or
under-specified; the RTL, the model and the testbench all use the choices below, and the 504-run regression confirms they agree.

| # | Question | Resolution (normative) |
|---|---|---|
| 1 | CMO `size = 0` "selects nothing" versus the scope formula selecting the line containing an unaligned `start` | `size = 0` selects **nothing** |
| 2 | width of `line_base + LINE_BYTES` | computed in **65 bits**; the line at the very top of the 2^64 space is in range of a CMO that covers it |
| 3 | `err_rsp` stated in steps 1/2 and again in step 8 | counted **once per non-OKAY response** |
| 4 | `is_write` in an error response to a bad opcode | `is_write = (op == WRITE)` |
| 5 | MERR line base: "64-byte-aligned" versus the `LINE_BYTES` formula | `addr & ~(LINE_BYTES-1)` |
| 6 | reset values of `CFG` | `en = 1`, window off; the generator always emits an explicit `CFG` first |
| 7 | does a `cfg_en` / window change flush anything? do CMOs depend on `cfg_en`? | **no flush**; CMOs always run |
| 8 | MERR with status 0 | meaningless; rejected |
| 9 | MERR bookkeeping | a count-0 entry shadows later entries for the same kind and line; an exhausted entry is skipped; only the matching entry that is used is decremented; **bypass requests and CMO writeback beats also consume counts** |
| 10 | bypass forwarding "unchanged" versus `wdata` shown as 0 for reads in `exp_mem` | a bypass **read** is forwarded with the request `be`, memory-side `wdata` is *recorded* as 0; a bypass **write** forwards the unmasked request data |
| 11 | do `bypass_rd` / `bypass_wr` count failing requests? | **yes** |
| 12 | the cross-references "§4.7.1 / §4.7.2" | read as step 7.1 / 7.2; CMO writebacks also issue all `BEATS` beats |
| 13 | `writebacks` for a failing CMO writeback | **not** counted; only `wb_errors` |
| 14 | file conventions | lower-case hex; `exp_rsp` `<seq>` is the REQ's own seq; `exp_cmo` values per CMO; partially written words in `exp_img` show merged content |
| 15 | a CMO range beyond `PADDR_W` | not an error; it covers nothing |
| 16 | after an install the replayed request touches again | idempotent for PLRU, a no-op for round-robin: not observable |
