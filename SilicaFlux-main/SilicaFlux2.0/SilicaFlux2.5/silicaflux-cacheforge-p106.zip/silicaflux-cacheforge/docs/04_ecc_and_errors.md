# 04 — ECC and error policy

## 1. What is protected

| Storage | Protection | Granule | Stored bits (default) |
|---|---|---|---|
| tag array entry `{tag, dirty, valid}` | Hsiao SECDED (the SRAMMacroBridge wrapper's `SECDED_WORD`), per way | one codeword per entry, `K = TAG_W + 2` (= 53 for 64-bit / 32 KiB / 4-way) | 60 |
| data array | Hsiao SECDED (`SECDED_LANE`) | one codeword per **64-bit lane**, two lanes per 128-bit beat | 144 per beat |
| replacement metadata (PLRU / RR) | **none** (flip-flops) | — | 3 bits / set |
| FSM, buffers, counters, MSHR table, order queue | **none** (flip-flops) | — | — |

* `valid` and `dirty` live **inside** the protected tag entry (there is no unprotected flop copy), so a flipped dirty bit is corrected or
  detected like any other bit.  The price is that reset initialisation is a SETS-cycle write walk and `INVAL`/flush-all are walks.
* A flipped replacement-metadata bit can only change **which** valid way is replaced (performance), never correctness: the victim index is
  proved `< WAYS` for **every** metadata value, and invalid ways are always preferred (`formal/fv_replacement`, R1–R3).
* ECC behaviour is that of the wrapper's codec: every single-bit error is corrected, every double-bit error is detected; **no claim is made
  for ≥ 3 bit errors** (they may be detected, miscorrected or missed).  The wrapper's codec was verified by its own package for
  `K = 8…128` (incl. 64); the **53-bit tag-entry codeword is exercised by the injection tests here** (T6, T7, T7b), not by that package.
* `ECC_EN = 0` removes all check bits and decoders (the policies below that need ECC then do not exist); `caps_o` then does not advertise ECC / POISON.

## 2. Policy table

| Event | What the hardware does | Requester sees | Reported |
|---|---|---|---|
| **tag, correctable** | corrected entry is used; with `ECC_SCRUB` the corrected entry is written back before the compare | normal response, `meta.corrected = 1` | `ERR_TAG_CE`, `EV_TAG_CE` |
| **tag, uncorrectable** | the way is treated as **invalid**: it can never hit and is the preferred victim; the damaged entry is overwritten by the refill | a miss (data refetched from memory) | `ERR_TAG_UE`, `EV_TAG_UE` |
| ↳ if that line was **dirty** | its data cannot be written back (the dirty bit is part of the lost entry): **dirty data lost**, not silently — see §3 | stale memory data on the refetch | same events; sticky flag; **software must treat a tag UE as a possible data-loss event** |
| **data, correctable** (read, partial-write RMW) | corrected beat returned / merged; with `ECC_SCRUB` the corrected beat is written back | normal response, `meta.corrected = 1` | `ERR_DATA_CE`, `EV_DATA_CE` |
| **data, uncorrectable, line clean** | line **invalidated and refetched** from memory, then the request is replayed (transparent) | correct data, `OKAY` | `ERR_DATA_UE_CLEAN`, `EV_DATA_UE`, extra refill |
| ↳ the refetched line is **again** uncorrectable | no further refetch (no livelock) | `ECC_UNCORR`, `meta.poisoned = 1`, zero data | `ERR_DATA_UE_POIS` |
| **data, uncorrectable, line dirty** | the line is kept; the beat stays poisoned | `ECC_UNCORR`, `meta.poisoned = 1`, zero data | `ERR_DATA_UE_POIS` |
| ↳ **partial write** to a poisoned beat | **refused** (no merge with corrupt data: poison is never laundered) | `ECC_UNCORR`, no update | same |
| ↳ **full-beat write** to a poisoned beat | overwrites and re-encodes the beat: the beat is healed | `OKAY` | — |
| **dirty beat uncorrectable at eviction / CLEAN** | that beat is **not written to memory** (corrupt data never propagates; memory keeps the previous value for those 16 bytes); the other beats are written | the requester of the miss is unaffected | `ERR_DIRTY_LOST`, `EV_DIRTY_LOST`, sticky |
| **refill error** (any beat's memory status ≠ OKAY, incl. a memory-side `ECC_UNCORR`) | **no line is installed** (the way stays invalid); a write miss is *not performed* | the memory's first failing status, zero data | `ERR_REFILL`, `refill_errors` |
| **writeback error** (any beat's memory status ≠ OKAY) | **the victim stays valid and dirty — no data is lost**; the miss is aborted; the replacement state is touched so the next miss picks another way | the memory's first failing status | `ERR_WB`, `wb_errors` |
| **CMO writeback error** | the line stays valid and dirty; the walk continues | `cmo_err_o` | `ERR_WB` |
| **reset** | all outstanding transactions are abandoned (ALP-RST-02); dirty data held **only** in the cache is **lost** (documented, tested: T9) | — | — |

## 3. Dirty-line errors — what can and cannot be promised

* **Writeback failure** is lossless: the data stays in the cache until a writeback succeeds.
* **Uncorrectable data in a dirty line** loses that 64-bit lane's value; it is *always* reported (poison response while resident; `ERR_DIRTY_LOST`
  when it would have been written back) and never turned into plausible-looking data.
* **Uncorrectable tag entry** loses the knowledge that a line existed and was dirty: the hardware cannot do better than reporting
  `ERR_TAG_UE`.  A platform that cannot tolerate this must treat the event as fatal for the affected data (or run with a write-through
  upstream).
* Errors are logged in `err_evt_o` (pulse), `err_sticky_o` (until `err_clear_i`), `err_addr_o` (address of the last event) and the performance counters.

## 4. How it is tested

`tb/tb_sf_llc_ecc.sv` injects faults into the **raw stored codewords** (hierarchical access to the wrapper's array) and checks every row above:
T1/T1b data CE (incl. a check-bit flip) and scrub; T2 CE during a partial write; T3 UE on a clean line (transparent refetch, exactly one
extra line fetched); T4 UE on a dirty line (poison, partial write refused, full write heals); T5 UE beat at eviction (beat not written,
others written, event + sticky); T6 tag CE + scrub; T7 tag UE (data bits); **T7b tag UE with the data bits intact (two check bits)** — added after
the mutation campaign showed T7 alone cannot tell a trusted from an untrusted entry; T8 persistent UE (stuck bits) → at most one refetch,
no livelock; T9 asynchronous reset in the middle of a refill and of a CMO walk.  Each is run for RAM latency 1–4, `MEM_MAX_OUT` 1–8,
with and without random memory back-pressure, and for `NUM_MSHR` 1–4.  Twelve ECC-policy mutants are killed (docs/06).
