// Black-box stand-in for the behavioural RAM array of the SRAMMacroBridge GENERIC backend.
// Used ONLY by the synthesis-statistics flow so that the report separates controller / ECC logic
// (measured) from the memory organisation (reported as macro instances, never as flip-flops).
(* blackbox *)
module sf_sram_be_generic #(
  parameter int PW = 32, parameter int NL = 4, parameter int PLW = 8, parameter int DEPTH = 1024,
  parameter int INIT_MODE = 0, parameter INIT_FILE = "",
  localparam int IDXW = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic            clk,
  input  wire logic            ce,
  input  wire logic            we,
  input  wire logic [NL-1:0]   wlane,
  input  wire logic [IDXW-1:0] idx,
  input  wire logic [PW-1:0]   wdata,
  input  wire logic            tst_active,
  input  wire logic            tst_ce,
  input  wire logic            tst_we,
  input  wire logic [IDXW-1:0] tst_idx,
  input  wire logic [PW-1:0]   tst_wdata,
  output logic      [PW-1:0]   rdata
);
endmodule
