#!/usr/bin/env python3
"""gen_stimulus.py -- directed/random stimulus generator for the sf_llc_cache reference model.

    python3 -I gen_stimulus.py --name N --seed S --sets 128 --ways 4 --line 64 --paddr 64 --repl 1 \
            --scenario random --count 2000 --outdir DIR [--avoid-ambiguous]

Writes DIR/stim_N.txt (spec 9.1) and, by running sf_cache_model on that file, DIR/exp_{rsp,mem,cnt,img,cmo}_N.txt.
Every scenario is deterministic for a seed (a single random.Random(seed) is the only entropy source), starts with an
explicit `CFG 1 0 0 0` (so the stimulus never relies on CFG reset values) and ends with `CMO 3 1 0 0`.

The generator keeps a *shadow* CacheModel only to steer the stimulus (e.g. "pick a line that is cached and dirty",
"find the next victim of a set").  The expected files come from a fresh run of the model on the written file.

--avoid-ambiguous: suppress stimulus that depends on a still-open spec question (see README_model.md):
    * CMO size 0 with a start that is not line aligned (SPEC-Q 1)
    * range CMOs while the top line of the 2^64 space is cached (SPEC-Q 2)
    * illegal opcodes other than 0 (SPEC-Q 4: is_write bit of the response)
    * non-zero data field on read requests (SPEC-Q 10)
"""
import argparse
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sf_cache_model as sfm                      # noqa: E402

M64 = sfm.M64
RD, WR = sfm.OP_READ, sfm.OP_WRITE
CLEAN, INVAL, CLEAN_INVAL = sfm.OP_CLEAN, sfm.OP_INVAL, sfm.OP_CLEAN_INVAL

PARTIAL_BES = [0x00FF, 0xFF00, 0x0F0F, 0xF0F0, 0x5555, 0xAAAA, 0x8001, 0x0001, 0x8000, 0xFFFE, 0x7FFF, 0x0FF0,
               0x00F0, 0x0F00, 0x3333, 0xCCCC]


class Finished(Exception):
    """Raised when the record budget (--count) is exhausted; any record prefix is a valid stimulus."""


class Gen:
    def __init__(self, seed, sets, ways, line, paddr, repl, count, avoid_ambiguous=False):
        self.rng = random.Random(seed)
        self.sets, self.ways, self.line, self.paddr, self.repl = sets, ways, line, paddr, repl
        self.beats = line // 16
        self.off_w = line.bit_length() - 1
        self.idx_w = sets.bit_length() - 1
        self.tag_w = paddr - self.off_w - self.idx_w
        self.count = count
        self.avoid = avoid_ambiguous
        self.m = sfm.CacheModel(sets, ways, line, paddr, repl)     # shadow model, steering only
        self.recs = []
        self.pool = {}
        self.perm_w_used = False
        self.perm_r = 0
        # permanent (count 0) refill errors are budgeted so that they cannot starve a small cache
        pool_lines = sets * min(max(ways * 6, 12), (1 << self.tag_w))
        self.perm_budget = max(1, pool_lines // 40)
        self.dctr = 0
        hot = {0, sets - 1}
        want = min(sets, 8)
        while len(hot) < want:
            hot.add(self.rng.randrange(sets))
        self.hot = sorted(hot)

    # ------------------------------------------------------------------ record emission
    def _emit(self, kind, rest):
        """Append one record `<kind> <seq> <rest>`; raises Finished when the budget is used up.  Always called
        BEFORE the shadow model is updated, so the shadow never runs ahead of the file."""
        if len(self.recs) >= self.count:
            raise Finished()
        self.recs.append("%s %d %s" % (kind, len(self.recs), rest))

    def cfg(self, en, nc_en, base, limit):
        assert en in (0, 1) and nc_en in (0, 1) and 0 <= base <= M64 and 0 <= limit <= M64
        self._emit("CFG", "%d %d %016x %016x" % (en, nc_en, base, limit))
        self.m.cfg(en, nc_en, base, limit)

    def raw_req(self, op, tag, dom, attr, addr, be, data):
        assert 0 <= op < 16 and 0 <= tag < 256 and 0 <= dom < 256 and 0 <= attr < 256
        assert 0 <= addr <= M64 and 0 <= be <= 0xFFFF and 0 <= data < (1 << 128)
        self._emit("REQ", "%x %02x %02x %02x %016x %04x %032x" % (op, tag, dom, attr, addr, be, data))
        return self.m.req(op, tag, dom, attr, addr, be, data)

    def cmo(self, op, all_, start, size):
        assert op in (1, 2, 3) and all_ in (0, 1) and 0 <= start <= M64 and 0 <= size <= M64
        if self.avoid and not all_ and any(b + self.line >= (1 << 64) for b in self.m.valid_lines()):
            self.cmo(CLEAN_INVAL, 1, 0, 0)          # SPEC-Q 2: keep the top line out of range-CMO scope
        self._emit("CMO", "%x %d %016x %016x" % (op, all_, start, size))
        return self.m.cmo(op, all_, start, size)

    def dmaw(self, addr, data):
        assert 1 <= len(data) <= 64 and addr + len(data) <= (1 << 64)
        self._emit("DMAW", "%016x %d %s" % (addr, len(data), bytes(data).hex()))
        self.m.dmaw(addr, data)

    def merr(self, kind, line, status, count):
        assert kind in ("R", "W") and 0 <= line <= M64 and 1 <= status <= 15 and count >= 0
        self._emit("MERR", "%s %016x %x %d" % (kind, line, status, count))
        self.m.merr(kind, line, status, count)

    # ------------------------------------------------------------------ random field helpers
    def tag(self):
        return self.rng.randrange(256)

    def dom(self):
        return self.rng.randrange(0xFF)             # never 0xFF for legal requests

    def attr(self, mt=0):
        r = self.rng
        return (r.randrange(4) << 5) | (r.randrange(2) << 4) | (r.randrange(2) << 3) | (r.randrange(2) << 2) | mt

    def be(self):
        r = self.rng.random()
        if r < 0.45:
            return 0xFFFF
        if r < 0.58:
            return 1 << self.rng.randrange(16)
        if r < 0.72:
            return self.rng.choice(PARTIAL_BES)
        return self.rng.randrange(1, 0x10000)

    def partial_be(self):
        b = self.be()
        while b == 0xFFFF:
            b = self.be()
        return b

    def data(self):
        r = self.rng.random()
        if r < 0.55:
            return self.rng.getrandbits(128)
        if r < 0.65:
            return (1 << 128) - 1
        if r < 0.70:
            return 0
        if r < 0.85:                                # byte i = counter + i : makes lane mix-ups visible
            self.dctr = (self.dctr + 16) & 0xFF
            return int.from_bytes(bytes((self.dctr + i) & 0xFF for i in range(16)), "little")
        return self.rng.getrandbits(128) | (0xA5 << 120)

    def rd(self, addr, be=None, mt=0, data=None):
        be = self.be() if be is None else be
        attr = self.attr(mt)
        if data is None:
            if self.avoid or not self.m.cacheable(attr, addr) or self.rng.random() < 0.75:
                data = 0                            # SPEC-Q 10
            else:
                data = self.rng.getrandbits(128)    # read data field must be ignored
        return self.raw_req(RD, self.tag(), self.dom(), attr, addr, be, data)

    def wr(self, addr, data=None, be=None, mt=0):
        be = self.be() if be is None else be
        data = self.data() if data is None else data
        return self.raw_req(WR, self.tag(), self.dom(), self.attr(mt), addr, be, data)

    def rdwr(self, addr, wprob=0.5, **kw):
        return self.wr(addr, **kw) if self.rng.random() < wprob else self.rd(addr, **kw)

    # ------------------------------------------------------------------ address pool
    def line_of(self, s, tag):
        return (tag << (self.off_w + self.idx_w)) | (s << self.off_w)

    def set_of(self, line_base):
        return (line_base >> self.off_w) & (self.sets - 1)

    def tags(self, s):
        """Per-set tag pool: max(6*WAYS, 12) distinct tags (>= 6x the capacity over all sets) including the extremes
        (tag 0 and the all-ones tag, i.e. the top of the 2^PADDR range) at random positions.  The first WAYS
        entries are the 'hot' ones (picked more often => hits), the rest cause the conflicts."""
        t = self.pool.get(s)
        if t is None:
            maxtag = (1 << self.tag_w) - 1
            n = min(max(self.ways * 6, 12), maxtag + 1)
            chosen = {0, maxtag}
            while len(chosen) < n:
                if self.rng.random() < 0.3:
                    chosen.add(self.rng.randrange(min(maxtag + 1, 64)))
                else:
                    chosen.add(self.rng.randrange(maxtag + 1))
            t = sorted(chosen)
            self.rng.shuffle(t)
            self.pool[s] = t
        return t

    def extra_tags(self, s, n, exclude=()):
        """n distinct tags of set s (pool tags first, then new random ones appended to the pool)."""
        t = self.tags(s)
        maxtag = (1 << self.tag_w) - 1
        ex = set(exclude)
        while len([x for x in t if x not in ex]) < n and len(t) < maxtag + 1:
            x = self.rng.randrange(maxtag + 1)
            if x not in t:
                t.append(x)
        avail = [x for x in t if x not in ex]
        return self.rng.sample(avail, min(n, len(avail)))

    def pick_set(self, hot_p=0.7):
        if self.rng.random() < hot_p:
            return self.rng.choice(self.hot)
        return self.rng.randrange(self.sets)

    def pick_tag(self, s, pref=0.55):
        t = self.tags(s)
        if self.rng.random() < pref:
            return t[self.rng.randrange(min(self.ways, len(t)))]
        return self.rng.choice(t)

    def pick_line(self, hot_p=0.7, pref=0.55):
        s = self.pick_set(hot_p)
        return self.line_of(s, self.pick_tag(s, pref))

    def pick_uncached_line(self, tries=20):
        L = self.pick_line()
        for _ in range(tries):
            if not self.m.is_cached(L):
                return L
            L = self.pick_line()
        return L

    def conflict_lines(self, s, n, exclude=()):
        ex = {self.m.decompose(x)[0] for x in exclude}
        return [self.line_of(s, t) for t in self.extra_tags(s, n, ex)]

    def beat_addr(self, L):
        return L + 16 * self.rng.randrange(self.beats)

    def status(self):
        return 7 if self.rng.random() < 0.6 else 1


# ====================================================================== snippets (each emits >= 1 record)
def sn_access(g, n=None):
    """Plain cacheable traffic concentrated on hot sets."""
    for _ in range(n or g.rng.randint(4, 24)):
        g.rdwr(g.beat_addr(g.pick_line()), 0.45)


def sn_cold(g):
    """Cold misses to distinct lines (<= WAYS per set, so nothing is evicted inside the batch), then re-reads."""
    B = g.rng.randint(4, 32)
    per_set, lines, tries = {}, [], 0
    while len(lines) < B and tries < 20 * B:
        tries += 1
        s = g.pick_set(0.35)
        L = g.line_of(s, g.rng.choice(g.tags(s)))
        if L in lines or per_set.get(s, 0) >= g.ways or (g.m.is_cached(L) and tries < 10 * B):
            continue
        per_set[s] = per_set.get(s, 0) + 1
        lines.append(L)
    if not lines:
        lines = [g.pick_line()]
    for L in lines:
        g.rd(g.beat_addr(L))
    for _ in range(g.rng.randint(1, 3)):
        order = lines[:]
        g.rng.shuffle(order)
        for L in order:
            g.rd(g.beat_addr(L))


def sn_assoc(g):
    """Fill every way of a set, set a recency order, then WAYS+1 conflicting lines; re-read the old lines after
    each replacement so that the (PLRU / round-robin) victim order becomes visible."""
    s = g.pick_set(0.5)
    W = g.ways
    tl = g.extra_tags(s, 2 * W + 1)
    old = [g.line_of(s, t) for t in tl[:W]]
    new = [g.line_of(s, t) for t in tl[W:W + W + 1]]
    for L in old:
        g.rdwr(g.beat_addr(L), 0.3)
    perm = old[:]
    g.rng.shuffle(perm)
    for L in perm:
        g.rd(g.beat_addr(L))
    for N in new:
        g.rdwr(g.beat_addr(N), 0.3)
        for L in old:
            g.rd(g.beat_addr(L))


def sn_replace(g):
    """Random lines concentrated on a few sets, reads+writes: clean and dirty victims."""
    sets = [g.pick_set(0.8) for _ in range(g.rng.randint(1, min(3, g.sets)))]
    wprob = g.rng.choice([0.3, 0.5, 0.7])
    for _ in range(g.rng.randint(12, 48)):
        s = g.rng.choice(sets)
        g.rdwr(g.line_of(s, g.pick_tag(s, 0.4)) + 16 * g.rng.randrange(g.beats), wprob)


def sn_partial(g):
    """Partial/sparse byte enables: write-miss with partial BE, several partial writes + masked reads of one beat."""
    L = g.pick_uncached_line()
    beat = g.rng.randrange(g.beats)
    a = L + 16 * beat
    g.wr(a, be=g.partial_be())                                   # write miss, partial BE
    for _ in range(g.rng.randint(1, 4)):
        g.wr(a, be=g.partial_be())                               # partial hits (disjoint / overlapping lanes)
    g.rd(a, be=0xFFFF)
    for _ in range(g.rng.randint(1, 3)):
        g.rd(a, be=g.partial_be())                               # masked reads
    g.wr(a, be=0xFFFF)
    g.rd(a, be=g.partial_be())
    for _ in range(2):
        lane = 1 << g.rng.randrange(16)
        g.wr(a, be=lane)
        g.rd(a, be=lane)
    if g.beats > 1:
        other = (beat + 1 + g.rng.randrange(g.beats - 1)) % g.beats
        g.rd(L + 16 * other, be=0xFFFF)                          # untouched beat: pure memory pattern
        g.wr(L + 16 * other, be=g.partial_be())
    if g.rng.random() < 0.5:                                     # evict (dirty) and read the merged data back
        for N in g.conflict_lines(g.set_of(L), g.ways + 1, exclude=[L]):
            g.rd(g.beat_addr(N))
        g.rd(a, be=0xFFFF)


def sn_raw(g):
    """Read-after-write to the same beat/line, interleaved with other lines."""
    for _ in range(g.rng.randint(3, 8)):
        L = g.pick_line()
        a = g.beat_addr(L)
        be = g.be()
        g.wr(a, be=be)
        g.rd(a, be=0xFFFF if g.rng.random() < 0.5 else be)
        if g.rng.random() < 0.4:
            g.rd(g.beat_addr(L))
        if g.rng.random() < 0.5:
            g.rdwr(g.beat_addr(g.pick_line()), 0.5)
        if g.rng.random() < 0.25:                                # push the dirty line out, then RAW through memory
            for N in g.conflict_lines(g.set_of(L), g.ways + 1, exclude=[L]):
                g.rd(g.beat_addr(N))
        g.rd(a)


def sn_sameline(g):
    """Burst of requests to one line, different beats, mixed R/W."""
    L = g.pick_line()
    n = g.rng.randint(4, 16)
    seq_order = g.rng.random() < 0.5
    wprob = g.rng.choice([0.3, 0.5, 0.7])
    for i in range(n):
        beat = (i % g.beats) if seq_order else g.rng.randrange(g.beats)
        g.rdwr(L + 16 * beat, wprob)


def sn_illegal(g):
    """Illegal requests (every legality class, combinations for the ordering, DECODE_ERR) between legal ones."""
    r = g.rng
    kinds = ["badop", "align", "zerobe", "attr", "dom"] + (["decode"] if g.paddr < 64 else [])
    for _ in range(r.randint(3, 12)):
        L = g.pick_line()
        a = g.beat_addr(L)
        if r.random() < 0.6:
            g.wr(a)                                              # make the target cached/dirty
        op, addr, be, attr, dom, data = r.choice([RD, WR]), a, g.be(), g.attr(r.choice([0, 0, 1, 2])), g.dom(), g.data()
        k = r.choice(kinds + ["combo"])
        picks = [k] if k != "combo" else r.sample(kinds, r.randint(2, min(5, len(kinds))))
        for p in picks:
            if p == "badop":
                op = 0 if g.avoid else r.choice([0] + list(range(3, 16)))
            elif p == "align":
                addr |= r.randrange(1, 16)                       # low nibble != 0
            elif p == "zerobe":
                be = 0
            elif p == "attr":
                attr = r.choice([attr | 0x80, (attr & ~3) | 3, attr | 0x83, r.randrange(0x80, 0x100)])
            elif p == "dom":
                dom = 0xFF
            elif p == "decode":                                  # some bit >= PADDR_W set (1 = alias of line a)
                hi = r.choice([1, 1, r.randrange(1, 1 << (64 - g.paddr)), 1 << (63 - g.paddr)])
                addr = (addr & ((1 << g.paddr) - 1)) | (hi << g.paddr)
        if op == RD and g.avoid:
            data = 0
        g.raw_req(op, g.tag(), dom, attr, addr, be, data)
        if r.random() < 0.5:
            g.rd(a, be=0xFFFF)                                   # legal read afterwards: state unchanged


def sn_window(g):
    """NC window: boundary probes (base, base-16, limit-16, limit), lines that are also cached."""
    r = g.rng
    L = g.pick_line()
    nl = max(1, min(r.randint(1, 4), ((1 << g.paddr) - L) // g.line))      # window lines stay below 2^PADDR
    base = L
    limit = min(base + nl * g.line, M64)
    variant = r.randrange(6)
    if variant == 0:
        limit = base                                             # empty window
    elif variant == 1:
        limit = max(base - 16, 0)                                # inverted window (base > limit): matches nothing
    elif variant == 2 and base + 8 <= M64:
        base += 8                                                # unaligned base: first 16B-aligned hit is base+8 up
    for off in range(0, nl * g.line, g.line):                    # pre-cache (and dirty some) lines in the window
        P = L + off
        if P + g.line <= (1 << g.paddr):
            if r.random() < 0.6:
                g.wr(P + 16 * r.randrange(g.beats), be=g.be())
            else:
                g.rd(P + 16 * r.randrange(g.beats))
    g.cfg(1, 1, base, limit)
    probes = {base & ~0xF, (base & ~0xF) + 16, (limit & ~0xF) - 16, limit & ~0xF, (base & ~0xF) - 16,
              (limit & ~0xF) + 16, L + 16 * r.randrange(g.beats)}
    for A in sorted(probes):
        if 0 <= A <= M64 - 15:
            g.rdwr(A, 0.4)
    g.rd(L + 16 * r.randrange(g.beats), mt=r.choice([1, 2]))     # NC/DEVICE attr inside/outside the window
    if r.random() < 0.8:
        g.cfg(1, 0, 0, 0)                                        # window off: cached copies visible again
        for off in range(0, nl * g.line, g.line):
            g.rd(L + off + 16 * r.randrange(g.beats))


def sn_cfg(g):
    """cfg_en 0/1 transitions: cached lines stay (stale/dirty), requests bypass while disabled."""
    r = g.rng
    L = g.pick_line()
    a = g.beat_addr(L)
    g.wr(a)                                                      # cached dirty
    g.cfg(0, r.randrange(2), 0, 0)
    for _ in range(r.randint(2, 8)):
        A = g.beat_addr(L) if r.random() < 0.6 else g.beat_addr(g.pick_line())
        g.rdwr(A, 0.5, mt=r.choice([0, 0, 1, 2]))
    g.rd(a)
    g.cfg(1, 0, 0, 0)
    g.rd(a)                                                      # hits the (dirty) cached copy again
    g.rd(g.beat_addr(L))


def sn_bypass(g):
    """NC / DEVICE traffic incl. lines that are ALSO cached (documented mismatched-attribute behaviour)."""
    r = g.rng
    L = g.pick_line()
    a = g.beat_addr(L)
    mt = r.choice([1, 2])
    c = r.random()
    if c < 0.25:       # dirty cached line: NC read sees stale memory until CLEAN
        g.wr(a)
        g.rd(a, mt=mt)
        g.cmo(CLEAN, 0, L, g.line)
        g.rd(a, mt=mt)
        g.rd(a)
    elif c < 0.5:      # clean cached line: NC write is invisible to cache hits until CLEAN_INVAL
        g.rd(a)
        g.wr(a, mt=mt)
        g.rd(a)
        g.rd(a, mt=mt)
        g.cmo(CLEAN_INVAL, 0, L, g.line)
        g.rd(a)
    elif c < 0.6:      # dirty cached line + NC write to the same address: the later writeback wins
        g.wr(a, be=0xFFFF)
        g.wr(a, mt=mt, be=g.be())
        g.cmo(CLEAN_INVAL, 0, L, g.line)
        g.rd(a, mt=mt)
    else:              # pure bypass traffic with byte-enable masks
        for _ in range(r.randint(3, 10)):
            A = g.beat_addr(g.pick_line())
            g.rdwr(A, 0.5, mt=r.choice([1, 2]))


def _dmaw_in(g, L):
    r = g.rng
    off = r.choice([0, 0, r.randrange(g.line), r.randrange(g.line)])
    a = L + off
    n = r.choice([1, 4, 16, min(64, g.line), r.randint(1, 64), r.randint(1, 64)])
    n = max(1, min(n, (1 << g.paddr) - a, 64))
    g.dmaw(a, bytes(r.getrandbits(8) for _ in range(n)))
    return a


def sn_dma(g):
    """DMAW to lines that are not cached / cached clean / cached dirty; stale reads until CMO."""
    r = g.rng
    L = g.pick_line()
    a = g.beat_addr(L)
    c = r.randrange(4)
    if c == 0:         # not cached
        g.cmo(CLEAN_INVAL, 0, L, g.line)
        _dmaw_in(g, L)
        g.rd(a)
    elif c == 1:       # clean cached: stale read, then CMO makes it visible (except CLEAN: clean is a no-op)
        g.rd(a)
        _dmaw_in(g, L)
        g.rd(a)
        g.cmo(r.choice([INVAL, CLEAN_INVAL, CLEAN]), 0, L, g.line)
        g.rd(a)
    elif c == 2:       # dirty cached: writeback clobbers the DMA data (whole line), INVAL discards the dirty data
        g.wr(a, be=g.be())
        _dmaw_in(g, L)
        g.rd(a)
        g.cmo(r.choice([CLEAN, CLEAN_INVAL, INVAL]), 0, L, g.line)
        g.rd(a)
        g.rd(a, mt=1)
    else:              # CLEAN before a device read
        g.wr(a)
        g.rd(a, mt=r.choice([1, 2]))
        g.cmo(CLEAN, 0, L, g.line)
        g.rd(a, mt=r.choice([1, 2]))
        _dmaw_in(g, L)
        g.rd(a)
        g.rd(a, mt=1)


def sn_cmo(g):
    """CLEAN / INVAL / CLEAN_INVAL, all=1 and ranges (aligned, unaligned, size 0, huge, near 2^64)."""
    r = g.rng
    sn_access(g, r.randint(4, 16))
    op = r.choice([CLEAN, INVAL, CLEAN_INVAL])
    valid = g.m.valid_lines()
    L = r.choice(valid) if valid else g.pick_line()
    LB = g.line
    top = (1 << g.paddr)
    v = r.randrange(14)
    if v == 0:
        g.cmo(op, 1, r.getrandbits(64), r.getrandbits(64))       # all=1: start/size are ignored
    elif v == 1:
        g.cmo(op, 0, L, LB * r.randint(1, 4))
    elif v == 2:
        g.cmo(op, 0, L + r.randrange(1, LB), r.randint(1, 3 * LB))        # unaligned start and size
    elif v == 3:
        g.cmo(op, 0, min(L + LB, M64), LB)                       # starts exactly at the line end: excludes L
    elif v == 4:
        g.cmo(op, 0, max(L - LB, 0), LB if L >= LB else 0)       # ends exactly at L: excludes L
    elif v == 5:
        g.cmo(op, 0, L + LB - 1, 1)                              # last byte of L: includes L
    elif v == 6:
        g.cmo(op, 0, L, 1)                                       # first byte of L: includes L
    elif v == 7:
        start = L if (g.avoid or r.random() < 0.4) else L + r.randrange(LB)
        g.cmo(op, 0, start, 0)                                   # size 0: nothing (SPEC-Q 1 if unaligned)
    elif v == 8:
        g.cmo(op, 0, 0, M64)                                     # huge range: end = 2^64-1
    elif v == 9:
        start = r.randrange(top >> 1) & ~(LB - 1)
        g.cmo(op, 0, start, min(M64, (1 << 64) - start))         # up to exactly 2^64
    elif v == 10:
        g.cmo(op, 0, M64 - r.choice([15, 31, 63, 255, 4095]), r.choice([1, 16, 0x100, 0x10000, M64]))   # near 2^64
    elif v == 11:
        g.cmo(op, 0, top - r.choice([LB, 2 * LB, 3 * LB]), r.choice([1, LB, 4 * LB, M64]))              # top of 2^PADDR
    elif v == 12:
        g.cmo(op, 0, M64, 1)                                     # last byte of the address space
    else:
        s = g.pick_set(0.5)                                      # many lines: a wide window covering a set's pool
        g.cmo(op, 0, r.randrange(1 << 20) * LB, r.choice([LB * g.sets * g.ways, LB * g.sets * 64, 1 << 40]))
    for _ in range(r.randint(2, 6)):                             # observe: hit / miss / data
        g.rd(g.beat_addr(r.choice(valid) if valid and r.random() < 0.7 else g.pick_line()))


def _uncache(g, L):
    if g.m.is_cached(L):
        g.cmo(CLEAN_INVAL, 0, L, g.line)


def _fill_set_dirty(g, s):
    """Make every way of set s valid and dirty (writes); returns True if it worked."""
    for N in g.conflict_lines(s, g.ways + 2):
        if all(ln.valid for ln in g.m.lines[s]):
            break
        if not g.m.is_cached(N):
            g.wr(g.beat_addr(N), be=g.be())
    for ln in g.m.lines[s]:
        if ln.valid and not ln.dirty:
            g.wr(g.m.line_base(ln.tag, s) + 16 * g.rng.randrange(g.beats), be=g.be())
    return all(ln.valid and ln.dirty for ln in g.m.lines[s])


def sn_merr(g):
    """Memory error injection: refill failures, writeback failures, CMO writeback failures, bypass failures."""
    r = g.rng
    L = g.pick_line()
    a = g.beat_addr(L)
    mt = r.choice([1, 2])
    case = r.randrange(9)
    if case == 0:      # transient refill failure(s), then success
        _uncache(g, L)
        c = r.randint(1, g.beats + 1)
        g.merr("R", L, g.status(), c)
        for _ in range(c // g.beats + 2):
            g.rdwr(g.beat_addr(L), 0.4)
        g.rd(g.beat_addr(L))
    elif case == 1:    # permanent refill failure on one line; other lines unaffected; hits are fine
        _uncache(g, L)
        perm = g.perm_r < g.perm_budget
        g.perm_r += perm
        g.merr("R", L, g.status(), 0 if perm else r.randint(1, 2 * g.beats))
        for _ in range(r.randint(2, 5)):
            g.rdwr(g.beat_addr(L), 0.4)
        g.rdwr(g.beat_addr(g.pick_line()), 0.4)
    elif case == 2:    # status of the FIRST failing beat is reported: two armed entries with different statuses
        _uncache(g, L)
        s1, s2 = (7, 1) if r.random() < 0.5 else (1, 7)
        g.merr("R", L, s1, 1)
        g.merr("R", L, s2, r.randint(1, 2))
        for _ in range(3):
            g.rdwr(g.beat_addr(L), 0.5)
    elif case in (3, 4):   # writeback failure of the next victim of a full dirty set
        s = g.set_of(L)
        if _fill_set_dirty(g, s):
            vic = g.m.victim_way(s)
            vl = g.m.line_base(g.m.lines[s][vic].tag, s)
            permanent = case == 4 and not g.perm_w_used and g.sets * g.ways >= 16
            c = 0 if permanent else r.randint(1, g.beats + 1)
            g.perm_w_used |= permanent
            g.merr("W", vl, g.status(), c)
            N = g.conflict_lines(s, 3, exclude=[vl])
            for _ in range(g.ways + 2):                           # misses: first one hits the failing victim
                g.rdwr(g.beat_addr(r.choice(N)), 0.3)
            g.rd(g.beat_addr(vl))                                 # the failed victim's data must be intact
            g.cmo(CLEAN, 0, vl, g.line)                           # CLEAN of it: fails while MERR is armed
            g.cmo(CLEAN, 0, vl, g.line)
    elif case == 5:    # CMO writeback failure: walk continues, failing line stays dirty
        for _ in range(3):
            g.wr(g.beat_addr(g.pick_line()), be=g.be())
        dl = [b for b in g.m.valid_lines() if g.m.is_dirty(b)]
        if dl:
            g.merr("W", r.choice(dl), g.status(), r.randint(1, g.beats + 1))
        g.cmo(r.choice([CLEAN, CLEAN_INVAL]), 1, 0, 0)
        g.cmo(r.choice([CLEAN, CLEAN_INVAL]), 1, 0, 0)
    elif case == 6:    # bypass failures: read -> zero data, write not performed
        g.merr("R", L, g.status(), r.randint(1, 2))
        g.rd(a, mt=mt)
        g.rd(a, mt=mt)
        g.merr("W", L, g.status(), 1)
        g.wr(a, mt=mt)
        g.wr(a, mt=mt)
        g.rd(a, mt=mt)
    elif case == 7:    # MERR armed on a line that is currently cached: no effect until eviction / CMO
        g.rd(a)
        g.merr("R", L, g.status(), r.randint(1, 3))
        g.rd(a)
        g.cmo(CLEAN_INVAL, 0, L, g.line)
        for _ in range(3):
            g.rd(g.beat_addr(L))
    else:              # write-miss whose refill fails is not performed
        _uncache(g, L)
        g.merr("R", L, g.status(), r.randint(1, g.beats))
        g.wr(a, be=0xFFFF)
        g.rd(a, be=0xFFFF)
        g.rd(a, be=0xFFFF)


# ====================================================================== scenarios
def _loop(g, parts):
    """parts: list of (weight, snippet).  Runs until the record budget is exhausted."""
    total = sum(w for w, _ in parts)
    stall = 0
    while True:
        n0 = len(g.recs)
        x = g.rng.random() * total
        for w, fn in parts:
            x -= w
            if x < 0:
                fn(g)
                break
        stall = stall + 1 if len(g.recs) == n0 else 0
        if stall > 50:
            g.rd(g.beat_addr(g.pick_line()))


SCENARIOS = {
    "cold": [(1, sn_cold)],
    "assoc": [(1, sn_assoc)],
    "replace": [(1, sn_replace)],
    "partial": [(1, sn_partial)],
    "raw": [(1, sn_raw)],
    "sameline": [(1, sn_sameline)],
    "illegal": [(1, sn_illegal)],
    "bypass": [(5, sn_bypass), (3, sn_window), (2, sn_cfg), (2, sn_access)],
    "dma": [(6, sn_dma), (1, sn_access)],
    "cmo": [(1, sn_cmo)],
    "merr": [(6, sn_merr), (1, sn_access)],
    "random": [(30, sn_access), (6, sn_cold), (4, sn_assoc), (8, sn_replace), (6, sn_partial), (5, sn_raw),
               (5, sn_sameline), (6, sn_illegal), (4, sn_bypass), (2, sn_window), (2, sn_cfg), (7, sn_dma),
               (5, sn_cmo), (7, sn_merr)],
}


def generate(name, seed, sets, ways, line, paddr, repl, scenario, count, outdir, avoid_ambiguous=False):
    g = Gen(seed, sets, ways, line, paddr, repl, count, avoid_ambiguous)
    try:
        g.cfg(1, 0, 0, 0)                      # explicit default configuration (SPEC-Q 6)
        _loop(g, SCENARIOS[scenario])
    except Finished:
        pass
    g.count = len(g.recs) + 1                  # the closing CMO is outside the budget
    g.cmo(CLEAN_INVAL, 1, 0, 0)
    os.makedirs(outdir, exist_ok=True)
    stim = os.path.join(outdir, "stim_%s.txt" % name)
    with open(stim, "w") as f:
        f.write("# stim_%s scenario=%s seed=%d sets=%d ways=%d line=%d paddr=%d repl=%d count=%d%s\n" % (
            name, scenario, seed, sets, ways, line, paddr, repl, count, " avoid_ambiguous" if avoid_ambiguous else ""))
        for r in g.recs:
            f.write(r + "\n")
    m = sfm.run_stimulus(stim, outdir, name, sets, ways, line, paddr, repl, check=False)
    # the shadow model saw exactly the same inputs: results must agree (guards against format/parse slips)
    assert m.cnt == g.m.cnt and len(m.trace) == len(g.m.trace), "shadow/file model mismatch"
    return m


def main(argv=None):
    ap = argparse.ArgumentParser(description="sf_llc_cache stimulus generator + expected files")
    ap.add_argument("--name", required=True)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--sets", type=int, default=128)
    ap.add_argument("--ways", type=int, default=4)
    ap.add_argument("--line", type=int, default=64)
    ap.add_argument("--paddr", type=int, default=64)
    ap.add_argument("--repl", type=int, default=1)
    ap.add_argument("--scenario", required=True, choices=sorted(SCENARIOS))
    ap.add_argument("--count", type=int, default=2000, help="number of records before the closing CMO")
    ap.add_argument("--outdir", default=".")
    ap.add_argument("--avoid-ambiguous", action="store_true")
    a = ap.parse_args(argv)
    if a.count < 1:
        ap.error("--count must be >= 1")
    m = generate(a.name, a.seed, a.sets, a.ways, a.line, a.paddr, a.repl, a.scenario, a.count, a.outdir,
                 a.avoid_ambiguous)
    print(" ".join("%s=%d" % (k, m.cnt[k]) for k in sfm.COUNTER_NAMES))
    return 0


if __name__ == "__main__":
    sys.exit(main())
