#!/usr/bin/env python3
"""sf_cache_model.py -- independent reference model of the sf_llc_cache functional spec.

Derived ONLY from docs/02_functional_spec.md (sections 1-10) plus the extra facts given with the task
(op codes, legality order, attr layout, response meta layout).  It is deliberately simple and un-optimised:
every method cites the spec step it implements.  See README_model.md for the list of spec ambiguities and
the choice taken for each one (search for "SPEC-Q" tags in this file).

Public API
----------
    m = CacheModel(sets, ways, line_bytes, paddr_w, repl)      repl: 1 = tree-PLRU, 0 = round-robin
    m.cfg(en, nc_en, nc_base, nc_limit)
    rsp = m.req(op, tag, dom, attr, addr, be, data)            -> Rsp(tag, status, meta, data)
    (lines, dirty_discard, err) = m.cmo(op, all_, start, size)
    m.dmaw(addr, bytes_obj)                                    backdoor write to memory
    m.merr(kind, line, status, count)                          arm memory error injection
    run_stimulus(stim_path, outdir, name, sets, ways, line_bytes, paddr_w, repl) -> CacheModel
        processes a stim_<name>.txt and writes exp_{rsp,mem,cnt,img,cmo}_<name>.txt (spec 9.3)

Command line:
    python3 -I sf_cache_model.py --stim stim_x.txt --outdir DIR [--name x] --sets 128 --ways 4 --line 64 \
            --paddr 64 --repl 1
"""
import os
import sys
from collections import namedtuple

M64 = (1 << 64) - 1
M128 = (1 << 128) - 1

# ALP v1 status codes
OKAY, DECODE_ERR, ACCESS_DENIED, BAD_OPCODE, BAD_BE, ALIGN_ERR, BAD_ATTR, TARGET_ERR = range(8)
OP_READ, OP_WRITE = 1, 2
OP_CLEAN, OP_INVAL, OP_CLEAN_INVAL = 1, 2, 3
MT_NORMAL_WB, MT_NORMAL_NC, MT_DEVICE = 0, 1, 2
REPL_RR, REPL_PLRU = 0, 1

COUNTER_NAMES = (
    "rd_hit", "rd_miss", "wr_hit", "wr_miss", "refills", "evictions", "writebacks",
    "mem_rd_beats", "mem_wr_beats", "bypass_rd", "bypass_wr", "cmo_lines", "cmo_dirty_discard",
    "err_rsp", "refill_errors", "wb_errors",
)

Rsp = namedtuple("Rsp", "tag status meta data")
MemReq = namedtuple("MemReq", "idx kind addr be wdata status")


def _is_pow2(x):
    return x > 0 and (x & (x - 1)) == 0


def _log2(x):
    return x.bit_length() - 1


def init_byte(a):
    """Spec 9.2: initial content of memory byte address a."""
    return ((a * 0x9E3779B97F4A7C15) & M64) >> 56


def lane_mask(be):
    """128-bit mask with 0xFF in every byte lane enabled by be (lane i = bits [8i+7:8i])."""
    m = 0
    for i in range(16):
        if (be >> i) & 1:
            m |= 0xFF << (8 * i)
    return m


class Memory:
    """Flat byte-addressed backing memory with the spec 9.2 initial pattern."""

    def __init__(self):
        self.bytes = {}          # byte address -> value, only for bytes ever written
        self.written = set()     # 16-byte-aligned word addresses ever written (for exp_img)

    def read_byte(self, a):
        v = self.bytes.get(a)
        return init_byte(a) if v is None else v

    def read_word(self, a):
        assert a & 0xF == 0
        return int.from_bytes(bytes(self.read_byte(a + i) for i in range(16)), "little")

    def write_word(self, a, word, be):
        assert a & 0xF == 0
        for i in range(16):
            if (be >> i) & 1:
                self.bytes[a + i] = (word >> (8 * i)) & 0xFF
        self.written.add(a)

    def write_bytes(self, a, data):
        for i, v in enumerate(data):
            self.bytes[a + i] = v
            self.written.add((a + i) & ~0xF)


class Line:
    __slots__ = ("valid", "dirty", "tag", "data")

    def __init__(self, line_bytes):
        self.valid = False
        self.dirty = False
        self.tag = 0
        self.data = bytearray(line_bytes)


class _Merr:
    __slots__ = ("kind", "line", "status", "count", "left")

    def __init__(self, kind, line, status, count):
        self.kind, self.line, self.status, self.count, self.left = kind, line, status, count, count


class CacheModel:
    # ------------------------------------------------------------------ construction (spec 1, 3)
    def __init__(self, sets, ways, line_bytes, paddr_w, repl):
        # Spec 1: unsupported combinations are rejected, never rounded.
        if not _is_pow2(line_bytes) or not 16 <= line_bytes <= 256:
            raise ValueError("LINE_BYTES must be a power of two in 16..256")
        if not _is_pow2(ways) or not 1 <= ways <= 16:
            raise ValueError("WAYS must be a power of two in 1..16")
        if not _is_pow2(sets) or sets < 2:
            raise ValueError("SETS must be a power of two >= 2")
        if not 32 <= paddr_w <= 64:
            raise ValueError("PADDR_W must be in 32..64")
        if repl not in (REPL_RR, REPL_PLRU):
            raise ValueError("REPL_POLICY must be 0 (round-robin) or 1 (tree-PLRU)")
        self.sets, self.ways, self.line_bytes, self.paddr_w, self.repl = sets, ways, line_bytes, paddr_w, repl
        self.beats = line_bytes // 16
        self.off_w = _log2(line_bytes)
        self.idx_w = _log2(sets)
        self.tag_w = paddr_w - self.off_w - self.idx_w
        if self.tag_w < 1:
            raise ValueError("TAG_W < 1")
        self.way_bits = _log2(ways)

        # Spec 3: after reset every line invalid, every replacement state 0.
        self.lines = [[Line(line_bytes) for _ in range(ways)] for _ in range(sets)]
        self.plru = [[0] * (ways - 1) for _ in range(sets)]     # heap-indexed, WAYS-1 bits
        self.rr = [0] * sets                                     # round-robin counters
        self.mem = Memory()
        self.trace = []                  # memory-side requests, issue order (spec 4.3)
        self.merrs = []                  # armed injections, file order (spec 9.1)
        self.cnt = dict.fromkeys(COUNTER_NAMES, 0)
        # SPEC-Q 6: reset values of the CFG registers are not in the spec; assumed en=1, nc window off.
        self.cfg_en, self.cfg_nc_en, self.cfg_nc_base, self.cfg_nc_limit = 1, 0, 0, 0

    # ------------------------------------------------------------------ address decomposition (spec 2)
    def decompose(self, addr):
        beat = (addr & (self.line_bytes - 1)) >> 4
        set_ = (addr >> self.off_w) & (self.sets - 1)
        tag = (addr & ((1 << self.paddr_w) - 1)) >> (self.off_w + self.idx_w)
        return tag, set_, beat

    def line_base(self, tag, set_):
        return (tag << (self.off_w + self.idx_w)) | (set_ << self.off_w)

    # ------------------------------------------------------------------ configuration
    def cfg(self, en, nc_en, nc_base, nc_limit):
        # SPEC-Q 7: a CFG record only changes the four registers.  It does not flush/invalidate anything (cached
        # lines stay valid and dirty while cfg_en = 0 / inside the NC window) and CMOs ignore cfg_en.
        self.cfg_en, self.cfg_nc_en = int(en), int(nc_en)
        self.cfg_nc_base, self.cfg_nc_limit = nc_base & M64, nc_limit & M64

    # ------------------------------------------------------------------ memory-side access (spec 4.3, 9.1 MERR)
    def merr(self, kind, line, status, count):
        if kind not in ("R", "W"):
            raise ValueError("MERR kind must be R or W")
        if not 1 <= status <= 15:
            # SPEC-Q 8: status 0 (OKAY) injection is meaningless/undefined -> rejected.
            raise ValueError("MERR status must be 1..15")
        if count < 0:
            raise ValueError("MERR count must be >= 0")
        self.merrs.append(_Merr(kind, line & M64, status, count))

    def _merr_lookup(self, kind, addr):
        """Spec 9.1: first armed entry (file order) of this kind whose line base matches and that is not
        exhausted wins; only that entry's counter is consumed.  count 0 = forever."""
        base = addr & ~(self.line_bytes - 1)     # SPEC-Q 5: LINE_BYTES (formula) not a literal 64
        for e in self.merrs:
            if e.kind == kind and e.line == base:
                if e.count == 0:
                    return e.status
                if e.left > 0:
                    e.left -= 1
                    return e.status
        return OKAY

    def mem_access(self, kind, addr, be, wdata):
        """One memory-side request.  Returns (status, rdata).  Counts the request even if it fails."""
        assert addr & 0xF == 0 and 0 <= addr <= M64
        status = self._merr_lookup(kind, addr)
        self.cnt["mem_rd_beats" if kind == "R" else "mem_wr_beats"] += 1
        rdata = 0
        if kind == "R":
            if status == OKAY:
                rdata = self.mem.read_word(addr)
        else:
            if status == OKAY:                       # a failing WRITE is not performed
                self.mem.write_word(addr, wdata, be)
        self.trace.append(MemReq(len(self.trace), kind, addr, be, wdata if kind == "W" else 0, status))
        return status, rdata

    def dmaw(self, addr, data):
        """DMAW backdoor write (spec 9.1): no cache interaction, no trace entry, no counters."""
        assert 1 <= len(data) <= 64 and addr + len(data) <= (1 << 64)
        self.mem.write_bytes(addr, bytes(data))

    # ------------------------------------------------------------------ replacement (spec 6)
    def _plru_victim(self, s):
        bits, n = self.plru[s], 0
        for _ in range(self.way_bits):
            n = 2 * n + 1 + bits[n]                  # bit b at node n -> child 2n+1+b
        return n - (self.ways - 1)                   # leaves are ways 0..WAYS-1 left to right

    def _plru_touch(self, s, w):
        bits, n = self.plru[s], 0
        for lvl in range(self.way_bits):
            went_right = (w >> (self.way_bits - 1 - lvl)) & 1
            bits[n] = 0 if went_right else 1         # point AWAY from w
            n = 2 * n + 1 + went_right

    def _policy_victim(self, s):
        return self._plru_victim(s) if self.repl == REPL_PLRU else self.rr[s]

    def _touch(self, s, w, is_hit):
        """touch(set, way): every hit, every install, after a writeback error (spec 6).
        Round-robin only moves its counter for install / writeback-error touches, never for a hit."""
        if self.repl == REPL_PLRU:
            self._plru_touch(s, w)
        elif not is_hit:
            self.rr[s] = (w + 1) % self.ways

    def victim_way(self, s):
        """Spec 4 step 7.1 (pure peek, no state change)."""
        for w in range(self.ways):
            if not self.lines[s][w].valid:
                return w
        return self._policy_victim(s)

    # ------------------------------------------------------------------ queries (used by tests / generator)
    def find_way(self, s, tag):
        for w in range(self.ways):
            ln = self.lines[s][w]
            if ln.valid and ln.tag == tag:
                return w
        return None

    def is_cached(self, line_base):
        tag, s, _ = self.decompose(line_base)
        return self.find_way(s, tag) is not None

    def is_dirty(self, line_base):
        tag, s, _ = self.decompose(line_base)
        w = self.find_way(s, tag)
        return w is not None and self.lines[s][w].dirty

    def valid_lines(self):
        """Line bases of all valid lines in walk order (set asc, way asc)."""
        return [self.line_base(self.lines[s][w].tag, s) for s in range(self.sets)
                for w in range(self.ways) if self.lines[s][w].valid]

    def cacheable(self, attr, addr):
        """Spec 4 step 3."""
        in_nc = self.cfg_nc_en and self.cfg_nc_base <= addr < self.cfg_nc_limit
        return bool(self.cfg_en and (attr & 3) == MT_NORMAL_WB and not in_nc)

    # ------------------------------------------------------------------ legality (spec 4 steps 1-2)
    def legality(self, op, dom, attr, addr, be):
        """ALP v1 sf_req_check order (given with the task); first failure wins, then the PADDR range."""
        if op not in (OP_READ, OP_WRITE):
            return BAD_OPCODE
        if addr & 0xF:
            return ALIGN_ERR
        if be == 0:
            return BAD_BE
        if (attr & 0x80) or (attr & 3) == 3:
            return BAD_ATTR
        if dom == 0xFF:
            return ACCESS_DENIED
        if self.paddr_w < 64 and (addr >> self.paddr_w) != 0:
            return DECODE_ERR
        return OKAY

    # ------------------------------------------------------------------ one upstream request (spec 4)
    def req(self, op, tag, dom, attr, addr, be, data):
        assert 0 <= addr <= M64 and 0 <= be <= 0xFFFF and 0 <= data <= M128
        is_write = 1 if op == OP_WRITE else 0        # SPEC-Q 4: is_write of illegal-opcode responses
        meta = 0x02 | is_write                       # {4'b0, corrected=0, poisoned=0, last=1, is_write}
        status = self.legality(op, dom, attr, addr, be)
        if status != OKAY:                           # steps 1/2: zero data, no state change, no traffic
            return self._finish(tag, status, meta, 0)
        if not self.cacheable(attr, addr):           # step 3
            return self._bypass(op, tag, dom, attr, addr, be, data, meta)

        atag, s, beat = self.decompose(addr)
        is_read = op == OP_READ
        way = self.find_way(s, atag)                 # step 4
        if way is not None:                          # steps 5/6
            self.cnt["rd_hit" if is_read else "wr_hit"] += 1
            return self._finish(tag, OKAY, meta, self._exec_on_line(op, s, way, beat, be, data))
        self.cnt["rd_miss" if is_read else "wr_miss"] += 1       # step 7
        status, way = self._miss(s, atag)
        if status != OKAY:
            return self._finish(tag, status, meta, 0)
        # step 7.3: the request now executes exactly as a hit on the new way, without rd_hit/wr_hit.
        return self._finish(tag, OKAY, meta, self._exec_on_line(op, s, way, beat, be, data))

    def _finish(self, tag, status, meta, data):
        """Step 8 / steps 1-2: err_rsp counted ONCE per non-OKAY response (SPEC-Q 3)."""
        if status != OKAY:
            self.cnt["err_rsp"] += 1
            data = 0
        return Rsp(tag, status, meta, data)

    def _exec_on_line(self, op, s, way, beat, be, data):
        """Steps 5 / 6 on a resident line (including its touch)."""
        ln = self.lines[s][way]
        off = beat * 16
        if op == OP_READ:
            word = int.from_bytes(ln.data[off:off + 16], "little") & lane_mask(be)
            self._touch(s, way, True)
            return word
        for i in range(16):
            if (be >> i) & 1:
                ln.data[off + i] = (data >> (8 * i)) & 0xFF
        ln.dirty = True
        self._touch(s, way, True)
        return 0

    # ------------------------------------------------------------------ bypass (spec 4.1)
    def _bypass(self, op, tag, dom, attr, addr, be, data, meta):
        is_read = op == OP_READ
        self.cnt["bypass_rd" if is_read else "bypass_wr"] += 1   # SPEC-Q 11: counted even if it fails
        if is_read:
            status, rdata = self.mem_access("R", addr, be, 0)
            return self._finish(tag, status, meta, rdata & lane_mask(be))
        # SPEC-Q 10: the WRITE is forwarded with the request's be and the request's data UNMASKED.
        status, _ = self.mem_access("W", addr, be, data)
        return self._finish(tag, status, meta, 0)

    # ------------------------------------------------------------------ miss handling (spec 4 step 7, 4.2)
    def _writeback_line(self, s, way):
        """BEATS WRITEs, always all issued, ascending.  Returns status of the first failing beat (0 = ok)."""
        ln = self.lines[s][way]
        base = self.line_base(ln.tag, s)
        first_err = OKAY
        for b in range(self.beats):
            word = int.from_bytes(ln.data[16 * b:16 * b + 16], "little")
            st, _ = self.mem_access("W", base + 16 * b, 0xFFFF, word)
            if st != OKAY and first_err == OKAY:
                first_err = st
        return first_err

    def _miss(self, s, atag):
        """Returns (status, way).  On OKAY the line is installed (valid, clean, touched)."""
        way = self.victim_way(s)                                     # 7.1
        ln = self.lines[s][way]
        if ln.valid:                                                 # 7.2
            if ln.dirty:
                err = self._writeback_line(s, way)
                if err != OKAY:                                      # 4.2 writeback error
                    self._touch(s, way, False)
                    self.cnt["wb_errors"] += 1
                    return err, None                                 # victim stays valid+dirty, intact
                self.cnt["writebacks"] += 1
                self.cnt["evictions"] += 1
            else:
                self.cnt["evictions"] += 1
            ln.valid = False
            ln.dirty = False
        base = self.line_base(atag, s)                               # 7.3 refill
        buf = bytearray(self.line_bytes)
        first_err = OKAY
        for b in range(self.beats):
            st, rdata = self.mem_access("R", base + 16 * b, 0xFFFF, 0)
            if st != OKAY:
                if first_err == OKAY:
                    first_err = st
            else:
                buf[16 * b:16 * b + 16] = rdata.to_bytes(16, "little")
        if first_err != OKAY:                                        # 4.2 refill error: nothing installed
            self.cnt["refill_errors"] += 1
            return first_err, None
        ln.valid, ln.dirty, ln.tag, ln.data = True, False, atag, buf
        self._touch(s, way, False)                                   # install touch
        self.cnt["refills"] += 1
        return OKAY, way

    # ------------------------------------------------------------------ CMO (spec 7)
    def cmo(self, op, all_, start, size):
        if op not in (OP_CLEAN, OP_INVAL, OP_CLEAN_INVAL):
            raise ValueError("CMO op must be 1..3")
        lines = discards = err = 0
        end = min(start + size, 1 << 64)             # 65-bit arithmetic
        for s in range(self.sets):                   # walk: sets asc, ways asc
            for w in range(self.ways):
                ln = self.lines[s][w]
                if not ln.valid:
                    continue
                if not all_:
                    base = self.line_base(ln.tag, s)
                    # SPEC-Q 1: "size = 0 -> nothing" is applied explicitly (the formula alone would select
                    # the line containing an unaligned start).  SPEC-Q 2: base + LINE_BYTES is computed in
                    # unbounded arithmetic (65-bit), so the top line of the address space can be in scope.
                    if size == 0 or not (base < end and base + self.line_bytes > start):
                        continue
                lines += 1
                self.cnt["cmo_lines"] += 1
                if op == OP_INVAL:
                    if ln.dirty:
                        discards += 1
                        self.cnt["cmo_dirty_discard"] += 1
                    ln.valid = ln.dirty = False
                    continue
                if ln.dirty:                                         # CLEAN / CLEAN_INVAL
                    if self._writeback_line(s, w) != OKAY:
                        self.cnt["wb_errors"] += 1                   # stays valid and dirty, walk continues
                        err = 1
                        continue
                    self.cnt["writebacks"] += 1                      # SPEC-Q 13: only on success
                    ln.dirty = False
                if op == OP_CLEAN_INVAL:
                    ln.valid = False
                # no touch, no evictions += 1 for CMOs
        return lines, discards, err

    # ------------------------------------------------------------------ self-checks
    def check_invariants(self):
        """Raises AssertionError on any violation of the spec 4/6 structural invariants."""
        valid_count = 0
        for s in range(self.sets):
            tags = []
            for w in range(self.ways):
                ln = self.lines[s][w]
                assert len(ln.data) == self.line_bytes
                if ln.dirty:
                    assert ln.valid, "dirty without valid (set %d way %d)" % (s, w)
                if ln.valid:
                    valid_count += 1
                    assert 0 <= ln.tag < (1 << self.tag_w)
                    tags.append(ln.tag)
            assert len(tags) == len(set(tags)), "two valid ways with the same tag in set %d" % s
            assert all(b in (0, 1) for b in self.plru[s]) and len(self.plru[s]) == self.ways - 1
            assert 0 <= self.rr[s] < self.ways
        assert valid_count <= self.sets * self.ways
        c = self.cnt
        # structural counter identities (follow from "all BEATS requests are always issued")
        assert c["mem_rd_beats"] == self.beats * (c["refills"] + c["refill_errors"]) + c["bypass_rd"]
        assert c["mem_wr_beats"] == self.beats * (c["writebacks"] + c["wb_errors"]) + c["bypass_wr"]
        assert all(v >= 0 for v in c.values())


# ====================================================================== stimulus file processing (spec 9)
def _hex(s):
    return int(s, 16)


def parse_stimulus(path):
    """Returns a list of tuples (kind, seq, fields...).  Lines starting with '#' and blank lines are skipped;
    a trailing '# ...' on a record is tolerated."""
    recs = []
    with open(path) as f:
        for ln, raw in enumerate(f, 1):
            s = raw.split("#", 1)[0].strip()
            if not s:
                continue
            t = s.split()
            k = t[0]
            try:
                if k == "CFG":
                    assert len(t) == 6
                    recs.append(("CFG", int(t[1]), _hex(t[2]), _hex(t[3]), _hex(t[4]), _hex(t[5])))
                elif k == "REQ":
                    assert len(t) == 9            # REQ seq op tag dom attr addr be data
                    recs.append(("REQ", int(t[1]), _hex(t[2]), _hex(t[3]), _hex(t[4]), _hex(t[5]),
                                 _hex(t[6]), _hex(t[7]), _hex(t[8])))
                elif k == "CMO":
                    assert len(t) == 6
                    recs.append(("CMO", int(t[1]), _hex(t[2]), int(t[3]), _hex(t[4]), _hex(t[5])))
                elif k == "DMAW":
                    assert len(t) == 5
                    n = int(t[3])
                    assert 1 <= n <= 64 and len(t[4]) == 2 * n
                    recs.append(("DMAW", int(t[1]), _hex(t[2]), n, bytes.fromhex(t[4])))
                elif k == "MERR":
                    assert len(t) == 6
                    recs.append(("MERR", int(t[1]), t[2], _hex(t[3]), _hex(t[4]), int(t[5])))
                else:
                    raise AssertionError("unknown record kind")
            except (AssertionError, ValueError, IndexError) as e:
                raise ValueError("%s:%d: malformed record %r (%s)" % (path, ln, s, e))
    return recs


def run_stimulus(stim_path, outdir, name, sets, ways, line_bytes, paddr_w, repl, check=False):
    m = CacheModel(sets, ways, line_bytes, paddr_w, repl)
    rsp_lines, cmo_lines = [], []
    for expect_seq, r in enumerate(parse_stimulus(stim_path)):
        kind, seq = r[0], r[1]
        if seq != expect_seq:
            raise ValueError("record seq %d, expected running number %d" % (seq, expect_seq))
        if kind == "CFG":
            m.cfg(r[2], r[3], r[4], r[5])
        elif kind == "REQ":
            _, _, op, tag, dom, attr, addr, be, data = r
            rsp = m.req(op, tag, dom, attr, addr, be, data)
            rsp_lines.append("%d %02x %x %02x %032x" % (seq, rsp.tag, rsp.status, rsp.meta, rsp.data))
        elif kind == "CMO":
            lines, disc, err = m.cmo(r[2], r[3], r[4], r[5])
            cmo_lines.append("%d %d %d %d" % (seq, lines, disc, err))
        elif kind == "DMAW":
            m.dmaw(r[2], r[4])
        elif kind == "MERR":
            m.merr(r[2], r[3], r[4], r[5])
        if check:
            m.check_invariants()
    write_expected(m, rsp_lines, cmo_lines, outdir, name)
    return m


def write_expected(m, rsp_lines, cmo_lines, outdir, name):
    os.makedirs(outdir, exist_ok=True)

    def w(prefix, lines):
        with open(os.path.join(outdir, "exp_%s_%s.txt" % (prefix, name)), "w") as f:
            for ln in lines:
                f.write(ln + "\n")

    w("rsp", rsp_lines)
    w("mem", ["%d %s %016x %04x %032x %x" % (t.idx, t.kind, t.addr, t.be, t.wdata, t.status) for t in m.trace])
    w("cnt", ["%s %d" % (k, m.cnt[k]) for k in COUNTER_NAMES])
    w("img", ["%016x %032x" % (a, m.mem.read_word(a)) for a in sorted(m.mem.written)])
    w("cmo", cmo_lines)


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description="sf_llc_cache reference model: stimulus -> expected files")
    ap.add_argument("--stim", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--name", default=None, help="default: derived from stim_<name>.txt")
    ap.add_argument("--sets", type=int, default=128)
    ap.add_argument("--ways", type=int, default=4)
    ap.add_argument("--line", type=int, default=64)
    ap.add_argument("--paddr", type=int, default=64)
    ap.add_argument("--repl", type=int, default=1)
    a = ap.parse_args(argv)
    name = a.name
    if name is None:
        b = os.path.basename(a.stim)
        name = b[len("stim_"):-len(".txt")] if b.startswith("stim_") and b.endswith(".txt") else b
    m = run_stimulus(a.stim, a.outdir, name, a.sets, a.ways, a.line, a.paddr, a.repl)
    print(" ".join("%s=%d" % (k, m.cnt[k]) for k in COUNTER_NAMES))
    return 0


if __name__ == "__main__":
    sys.exit(main())
