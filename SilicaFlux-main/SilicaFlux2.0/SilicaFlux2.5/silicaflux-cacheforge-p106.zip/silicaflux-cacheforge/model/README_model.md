# sf_llc_cache reference model and stimulus generator

Independent Python model of `docs/02_functional_spec.md` sections 1-10 (plus the extra facts given with the task:
op codes, legality order/status codes, attr and response-meta layout).  Written from the spec only; no RTL was read.
Python 3.13, standard library only, run everything with `python3 -I`.

## Files

| file | purpose |
|---|---|
| `sf_cache_model.py` | `CacheModel(sets, ways, line_bytes, paddr_w, repl)` (repl 1 = tree-PLRU, 0 = round-robin), `run_stimulus()`, CLI |
| `gen_stimulus.py` | scenario generator: writes `stim_<N>.txt` and (by running the model on it) the five `exp_*_<N>.txt` files |
| `selftest.py` | hand-computed directed tests, invariants after every record, flat-memory cross-check, generator smoke test |

## Usage

```
# generate stimulus + expected files
python3 -I gen_stimulus.py --name N --seed S --sets 128 --ways 4 --line 64 --paddr 64 --repl 1 \
        --scenario random --count 5000 --outdir DIR [--avoid-ambiguous]
# scenarios: cold assoc replace partial raw sameline illegal bypass dma cmo merr random

# model alone on an existing stimulus file (writes exp_{rsp,mem,cnt,img,cmo}_<name>.txt, prints counters)
python3 -I sf_cache_model.py --stim DIR/stim_N.txt --outdir DIR --sets 128 --ways 4 --line 64 --paddr 64 --repl 1

# self test (exit status 0 = pass)
python3 -I selftest.py
```

* `--count K` = number of records before the closing `CMO 3 1 0 0` (a scenario is cut at exactly K records; any prefix
  of a scenario is valid stimulus).  Deterministic for a seed (single `random.Random(seed)`).
* Every stimulus starts with an explicit `CFG 0 1 0 0 0` (so it never depends on the CFG reset values, SPEC-Q 6) and
  has one `#` header comment line (spec 9: `#` lines are comments).
* Expected files: lower-case hex, exactly the formats of spec 9.3, no comments, trailing newline after every line.
* Address pool: per set `max(6*WAYS, 12)` distinct tags (>= 6x capacity over all sets) incl. tag 0 and the all-ones tag
  (top of the `2^PADDR` range, e.g. `0xFFFFFFFFFFFFFFC0` for PADDR=64); a few "hot" sets get most of the traffic and
  each set favours its first WAYS tags, so hits and conflicts both occur even for short runs.
* `--avoid-ambiguous` removes stimulus that depends on an unresolved question below (SPEC-Q 1, 2, 4, 10).  Use it
  until the questions are resolved if the RTL and model disagree only there.
* Selftest components: directed tests with hand-derived expectations (PLRU 2/4/8-way state tables, round-robin incl.
  invalid-way interplay, dirty-eviction beat trace, write-miss partial merge, INVAL discard, CLEAN keeps valid, MERR
  refill / writeback / CMO-writeback failure for both policies, illegal-status ordering, DMA stale read, bypass /
  NC-window / cfg_en, CMO range arithmetic incl. 2^64, file round trip with literal expected files); a recursive
  tree oracle for PLRU; `check_invariants()` after every record of long `random` runs on 7 geometries (<= 1 matching
  way per set, dirty implies valid, valid lines <= capacity, PLRU/RR state ranges, `mem_rd_beats == BEATS*(refills +
  refill_errors) + bypass_rd`, `mem_wr_beats == BEATS*(writebacks + wb_errors) + bypass_wr`); generator smoke test
  (5 geometries x 12 scenarios, determinism, file well-formedness, counter identities, scenario coverage); a 60-run fuzz over odd geometries (PADDR 33/63, LINE 128/256, 16 ways ...) with invariants after every record.
* Flat-memory check (`coherent_run`): exact only for a restricted workload -- cached and uncached lines are disjoint
  (no mismatched attributes), DMAW only to uncached lines, MERR transient only, final CLEAN_INVAL repeated until
  `err = 0`.  The architectural image is built by applying every OKAY write in order; an INVAL resets each in-scope
  *dirty* line to what memory holds at that moment (that is precisely what the next refill returns, so it covers
  "writes discarded by INVAL" and, together with "failed writes are not applied", "writes lost to failed refills").
  Every OKAY read must equal the image, and after the final flush memory must equal the image byte for byte.
  It is **not** applicable to the general `random` scenario (DMAW under cached lines, bypass to cached lines, permanent
  MERR W), which is why it lives only in the selftest.
* The selftest was mutation-checked (about 60 deliberately broken copies of the model: PLRU direction/victim, RR
  hit/touch, wb-error touch/invalidate, refill-error install, CMO touch/walk order/65-bit scope, signed NC compare,
  MERR kind/ordering/exhaustion, counters, lane order ...): all non-equivalent mutants are caught.

## Spec questions (ambiguities / contradictions / under-specification) -- please resolve

Each is tagged `SPEC-Q n` at the corresponding place in `sf_cache_model.py`.

1. **CMO `size = 0`.**  §7 says "`size = 0` -> nothing" but the scope formula `line_base < end && line_base + LINE_BYTES > start`
   with `end = start` selects the line that contains an *unaligned* `start`.  *Model:* size 0 selects nothing (the explicit
   statement wins).  `gen_stimulus` emits unaligned size-0 CMOs unless `--avoid-ambiguous`.
2. **Width of `line_base + LINE_BYTES`.**  Only `end` is said to use 65-bit arithmetic.  For the top line of the
   64-bit space `line_base + LINE_BYTES = 2^64`; with 64-bit wrap-around that is 0 and the line would never be in scope
   of any range CMO.  *Model:* unbounded arithmetic (top line can be in scope).  (`--avoid-ambiguous` flushes with
   `CMO 3 1` before any range CMO while the top line is cached.)
3. **`err_rsp` double counting.**  Steps 1/2 say "`err_rsp` += 1" for an illegal request and step 8 says "incremented for every
   response whose status is not OKAY" (which includes it).  *Model:* once per non-OKAY response.
4. **`is_write` bit of error responses.**  Meta is `{4'b0, corrected, poisoned, last, is_write}`; for BAD_OPCODE (op 0, 3..F)
   the op is neither read nor write.  *Model:* `is_write = (op == 2)` (so op 0/3..F -> meta 0x02; illegal WRITE -> 0x03).
5. **MERR line granularity.**  §9.1 says "64-byte-aligned line base (`addr & ~(LINE_BYTES-1)`)": 64 vs `LINE_BYTES` differ for
   LINE_BYTES 16/32/128/256.  *Model:* `addr & ~(LINE_BYTES-1)`; the `<line>` operand is compared as given (an unaligned
   `<line>` never matches).  The generator only emits line-aligned operands.
6. **CFG reset values** (`cfg_en`, `cfg_nc_en`, base, limit) are not in the spec.  *Model:* en=1, nc off, base=limit=0.
   Generated stimulus always begins with an explicit CFG.
7. **CFG side effects.**  Nothing says that clearing `cfg_en` or changing the NC window flushes or invalidates cached lines, or that CMOs
   depend on `cfg_en`.  *Model:* no flush; cached (possibly dirty) lines stay and become visible again when re-enabled; CMOs always run.
8. **MERR with status 0** (OKAY) is meaningless ("data zero, write not performed" yet OKAY).  *Model:* rejected with
   `ValueError`; the generator emits only 1 and 7 (statuses 1..15 are accepted by the model).
9. **MERR bookkeeping.**  (a) there is no way to disarm: with a count-0 entry armed for (kind, line), later entries for the same
   pair are shadowed forever; (b) "first match in file order wins" -- *model:* exhausted entries are skipped and only the
   matching entry that is used has its counter decremented; (c) bypass requests and CMO writeback beats consume MERR counts like any
   other memory-side request (spec §9.1 says "memory-side request").
10. **Bypass memory request fields.**  §4.1 says forwarded "unchanged (op, dom, attr, address, be, data)" but §9.3 says `wdata` is 0 for R.
    *Model:* exp_mem of a bypass READ has `be` = request `be` and `wdata` = 0; a bypass WRITE has `be` = request `be` and `wdata` = the request
    data **unmasked** (disabled lanes keep whatever the request carried -- a testbench should probably compare `wdata` only on enabled
    lanes).  Memory itself only changes the enabled lanes.  Generated bypass reads carry data = 0; cacheable reads carry a random non-zero data field
    ~25% of the time (must be ignored) unless `--avoid-ambiguous`.
11. **Counters on failing bypass.**  *Model:* `bypass_rd`/`bypass_wr` count every forwarded request, including ones that fail (spec only
    says `mem_*_beats` count failing requests).
12. **Cross-references.**  §4.2/§6/§7 refer to "§4.7.1"/"§4.7.2", which do not exist; read as step 7.1 (victim) and 7.2 (eviction).
    §7's "BEATS WRITEs as §4.7.2" is taken to include "all BEATS requests are always issued even after a failing one" for CMO
    writebacks too.
13. **`writebacks` for a failing CMO writeback.**  §7 lists `writebacks += 1` in the table but only the miss path (§4.2) says it is not
    counted on failure.  *Model:* not counted on failure (only `wb_errors`), consistent with §4.2.
14. **File conventions not spelled out:** hex case (model writes lower case); `<seq>` of `exp_rsp` = the REQ record's own seq;
    `exp_cmo` values are per-CMO (not cumulative); `exp_img` words that were only partially written (DMAW / bypass lanes) show the
    merged content with the §9.2 pattern in untouched lanes; DMAW is limited by the model to `addr + nbytes <= 2^64` (the generator
    also keeps it below `2^PADDR`).
15. **CMO range beyond `PADDR_W`** (e.g. `start = 0xFFFF...`) is not a DECODE_ERR (CMOs have no response); it simply covers nothing.
16. **Remark (no action needed):** after an install the replayed request executes "as a hit" and therefore touches again; this is
    idempotent for PLRU and a no-op for round-robin, so the double touch is not observable.

## Not modelled
ECC events, reset in mid-traffic, latency/stall counters, `RAM_LATENCY`/`MEM_MAX_OUT` (spec §8); the model is timing independent.
