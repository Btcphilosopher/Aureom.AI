#!/usr/bin/env python3
"""selftest.py -- self-test of the sf_llc_cache reference model and stimulus generator.

Run:  python3 -I selftest.py            (exit status != 0 on any failure)

Hand-computed expectations: every directed test states in comments how the expected value was derived from the
spec (PLRU state tables, round-robin counters, beat traces).  Hex words for the initial memory pattern (spec 9.2,
byte(a) = top byte of a*0x9E3779B97F4A7C15 mod 2^64) are written as literals (MSB-first: byte lane 15 first,
lane 0 = last two digits) and cross-checked against an independent re-implementation of the formula in
test_pattern().
"""
import filecmp
import os
import random
import re
import sys
import tempfile
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sf_cache_model as sfm                     # noqa: E402
import gen_stimulus as gs                        # noqa: E402
from sf_cache_model import CacheModel            # noqa: E402

FAILS = []
NCHECK = [0]


def check(cond, msg):
    NCHECK[0] += 1
    if not cond:
        FAILS.append(msg)
        print("FAIL: " + msg)


def eq(got, exp, msg):
    NCHECK[0] += 1
    if got != exp:
        FAILS.append(msg)
        print("FAIL: %s\n   got      %r\n   expected %r" % (msg, got, exp))


def mk(sets, ways, line, paddr=32, repl=1):
    return CacheModel(sets, ways, line, paddr, repl)


def rd(m, a, be=0xFFFF, attr=0, dom=0, tag=1, data=0):
    return m.req(1, tag, dom, attr, a, be, data)


def wr(m, a, d, be=0xFFFF, attr=0, dom=0, tag=1):
    return m.req(2, tag, dom, attr, a, be, d)


def H(s):
    return int(s, 16)


def hx(n):
    return "%032x" % n


def tr(m):
    return [(t.kind, t.addr, t.be, t.wdata, t.status) for t in m.trace]


def R_(addr, st=0):
    return ("R", addr, 0xFFFF, 0, st)


def W_(addr, data, st=0):
    return ("W", addr, 0xFFFF, data, st)


def way_tags(m, s):
    return [(ln.tag if ln.valid else None) for ln in m.lines[s]]


# Initial memory words (spec 9.2), MSB-first strings, derived from the formula (see test_pattern()).
I00 = "45a7086acc2e8ff153b51778da3c9e00"
I10 = "288aec4eaf1173d53698fa5cbe1f81e3"
I20 = "0c6dcf3193f556b81a7cde3fa10365c6"
I30 = "ef51b31576d83a9cfd5fc12385e648aa"
I40 = "d33496f85abc1d7fe143a40668ca2c8d"
I50 = "b6187adb3d9f0163c42688ea4bad0f71"
D1 = H("00112233445566778899aabbccddeeff")      # lane 0 = ff, lane 1 = ee, ..., lane 15 = 00


def pat(a):
    return ((a * 0x9E3779B97F4A7C15) % (1 << 64)) >> 56


def pat_word(a):
    return "".join("%02x" % pat(a + i) for i in reversed(range(16)))


# ---------------------------------------------------------------------------------------------- tests
def test_pattern():
    # by hand: K = 0x9E3779B97F4A7C15 ; byte(0)=0 ; byte(1)=K>>56=0x9e ; 2K mod 2^64 = 0x3C6EF372FE94F82A -> 0x3c
    m = mk(2, 1, 16)
    eq([m.mem.read_byte(i) for i in range(3)], [0x00, 0x9E, 0x3C], "init pattern bytes 0..2")
    for a, s in ((0x00, I00), (0x10, I10), (0x20, I20), (0x30, I30), (0x40, I40), (0x50, I50)):
        eq(pat_word(a), s, "literal init word 0x%x vs independent formula" % a)
        eq(hx(m.mem.read_word(a)), s, "model init word 0x%x" % a)
    eq(hx(m.mem.read_word(0xFFFFFFFFFFFFFFF0)), pat_word(0xFFFFFFFFFFFFFFF0), "init word near 2^64")
    # lane order: lane 0 is the last byte of the MSB-first string
    eq(I00[-2:], "%02x" % pat(0), "lane 0 = last hex byte")


def test_constructor_rejects():
    bad = [(3, 4, 64, 64), (1, 4, 64, 64), (128, 3, 64, 64), (128, 32, 64, 64), (128, 4, 8, 64), (128, 4, 512, 64),
           (128, 4, 48, 64), (128, 4, 64, 31), (128, 4, 64, 65), (128, 0, 64, 64)]
    for sets, ways, line, paddr in bad:
        try:
            CacheModel(sets, ways, line, paddr, 1)
            check(False, "constructor accepted illegal geometry %r" % ((sets, ways, line, paddr),))
        except ValueError:
            check(True, "")
    for ways in (1, 2, 4, 8, 16):
        CacheModel(2, ways, 16, 32, 0)


def test_plru_4way():
    # sets=2 ways=4 line=16 -> OFF_W=4 IDX_W=1; set 0 line for tag t is addr t*0x20.  bits = [b0,b1,b2]
    # (node0 root, node1 = ways0/1, node2 = ways2/3).  touch(w) points every path node AWAY from w.
    m = mk(2, 4, 16, 32, 1)
    exp_state = [([1, 1, 0], 0), ([1, 0, 0], 1), ([0, 0, 1], 2), ([0, 0, 0], 3)]
    for t in range(4):                               # lowest invalid way first: tags 0..3 -> ways 0..3
        rd(m, t * 0x20)
        eq(m.plru[0], exp_state[t][0], "plru bits after installing way %d" % t)
        eq(way_tags(m, 0)[t], t, "install way %d" % t)
    eq(m.victim_way(0), 0, "victim after in-order fill is way 0 (root 0 -> left, node1 0 -> way 0)")
    rd(m, 2 * 0x20)                                  # hit way 2 : b0=0 (right taken), b2=1
    eq(m.plru[0], [0, 0, 1], "plru after hit way 2")
    eq(m.victim_way(0), 0, "victim after hit way 2")
    rd(m, 0 * 0x20)                                  # hit way 0 : b0=1, b1=1
    eq(m.plru[0], [1, 1, 1], "plru after hit way 0")
    eq(m.victim_way(0), 3, "victim after hit way 0 (root 1 -> right, node2 1 -> way 3)")
    wr(m, 3 * 0x20, D1, be=0x0001)                   # WRITE hit way 3 (must touch too) : b0=0, b2=0
    eq(m.plru[0], [0, 1, 0], "plru after write hit way 3")
    eq(m.victim_way(0), 1, "victim after hit way 3 (root 0 -> left, node1 1 -> way 1)")
    # four misses: evicted ways must be 1, 2, 0, 3 (hand-derived: states [1,0,0] [0,0,1] [1,1,1] [0,1,0])
    evicted_tags = []
    for t, (st, nxt) in zip((4, 5, 6, 7), (([1, 0, 0], 2), ([0, 0, 1], 0), ([1, 1, 1], 3), ([0, 1, 0], 1))):
        before = way_tags(m, 0)
        rd(m, t * 0x20)
        after = way_tags(m, 0)
        w = [i for i in range(4) if before[i] != after[i]]
        evicted_tags.append((w, before[w[0]]))
        eq(m.plru[0], st, "plru after install of tag %d" % t)
        eq(m.victim_way(0), nxt, "next victim after install of tag %d" % t)
    eq(evicted_tags, [([1], 1), ([2], 2), ([0], 0), ([3], 3)], "eviction order of ways 1,2,0,3 (with their old tags)")
    eq(way_tags(m, 0), [6, 4, 5, 7], "final tags per way")
    eq((m.cnt["rd_hit"], m.cnt["wr_hit"], m.cnt["rd_miss"], m.cnt["refills"], m.cnt["evictions"], m.cnt["writebacks"]),
       (2, 1, 8, 8, 4, 1), "plru4 counters (way 3 was dirtied by the write hit and is written back when evicted)")
    eq(tr(m)[-2:], [W_(0x60, (H(pat_word(0x60)) & ~0xFF) | 0xFF), R_(0xE0)],
       "last miss: writeback of the dirty way-3 line (lane 0 = ff) then refill of line 0xE0")
    eq(m.plru[1], [0, 0, 0], "other set's plru untouched")


def test_plru_other_sizes():
    # 2 ways: one bit; touch 0 -> 1 (victim 1); touch 1 -> 0 (victim 0)
    m = mk(2, 2, 16, 32, 1)
    rd(m, 0x00)
    eq((m.plru[0], m.victim_way(0)), ([1], 1), "2-way after install way0 (way 1 still invalid -> chosen)")
    rd(m, 0x20)
    eq((m.plru[0], m.victim_way(0)), ([0], 0), "2-way after install way1")
    rd(m, 0x00)
    eq((m.plru[0], m.victim_way(0)), ([1], 1), "2-way after hit way0")
    rd(m, 0x40)                                      # evicts way 1 (tag 1) -> way1 = tag 2, touch 1 -> bit 0
    eq((way_tags(m, 0), m.plru[0]), ([0, 2], [0]), "2-way replacement")
    # 1 way: direct mapped, no replacement state, victim always 0
    m = mk(2, 1, 16, 32, 1)
    rd(m, 0x00)
    rd(m, 0x20)
    eq((m.plru[0], m.victim_way(0), way_tags(m, 0), m.cnt["evictions"]), ([], 0, [1], 1), "1-way direct mapped")
    # 8 ways: heap nodes 0..6: 0 root, 1 = ways0-3, 2 = ways4-7, 3 = w0/1, 4 = w2/3, 5 = w4/5, 6 = w6/7
    m = mk(2, 8, 16, 32, 1)
    for t in range(8):
        rd(m, t * 0x20)
    eq(m.plru[0], [0] * 7, "8-way state after in-order fill is all zero (hand-derived)")
    eq(m.victim_way(0), 0, "8-way victim after fill")
    rd(m, 6 * 0x20)                                  # root->right(b0=0), node2->right (b2=0), node6->left (b6=1)
    eq(m.plru[0], [0, 0, 0, 0, 0, 0, 1], "8-way after hit way 6")
    eq(m.victim_way(0), 0, "8-way victim after hit way 6")
    rd(m, 0 * 0x20)                                  # b0=1, b1=1, b3=1
    eq(m.plru[0], [1, 1, 0, 1, 0, 0, 1], "8-way after hit way 0")
    eq(m.victim_way(0), 4, "8-way victim: root 1 -> node2 (0) -> node5 (0) -> way 4")


def test_plru_oracle():
    """Cross-check the heap-indexed implementation against a recursive tree oracle for 1..16 ways."""
    class Node:
        def __init__(self, lo, hi):
            self.lo, self.hi, self.bit = lo, hi, 0
            if hi - lo > 1:
                mid = (lo + hi) // 2
                self.l, self.r = Node(lo, mid), Node(mid, hi)

        def victim(self):
            if self.hi - self.lo == 1:
                return self.lo
            return (self.r if self.bit else self.l).victim()

        def touch(self, w):
            if self.hi - self.lo == 1:
                return
            mid = (self.lo + self.hi) // 2
            if w < mid:
                self.bit = 1
                self.l.touch(w)
            else:
                self.bit = 0
                self.r.touch(w)
    rng = random.Random(7)
    for ways in (1, 2, 4, 8, 16):
        m = mk(2, ways, 16, 32, 1)
        orc = Node(0, ways)
        for _ in range(3000):
            w = rng.randrange(ways)
            m._plru_touch(0, w)
            orc.touch(w)
            if m._plru_victim(0) != orc.victim():
                check(False, "plru oracle mismatch ways=%d" % ways)
                break
        else:
            check(True, "")


def test_round_robin():
    # sets=2 ways=4 line=16 repl=0.  Install touches set counter = (w+1) mod 4; hits do not change it.
    m = mk(2, 4, 16, 32, 0)
    for t, exp_rr in zip(range(4), (1, 2, 3, 0)):
        rd(m, t * 0x20)
        eq(m.rr[0], exp_rr, "rr counter after installing way %d" % t)
        eq(way_tags(m, 0)[t], t, "rr: lowest invalid way used")
    rd(m, 2 * 0x20)                                  # hit: counter unchanged
    eq(m.rr[0], 0, "rr unchanged by hit")
    seq = []
    for t, exp_rr in zip((4, 5, 6, 7), (1, 2, 3, 0)):         # victims ways 0,1,2,3
        before = way_tags(m, 0)
        rd(m, t * 0x20)
        seq.append([i for i in range(4) if way_tags(m, 0)[i] != before[i]][0])
        eq(m.rr[0], exp_rr, "rr counter after miss tag %d" % t)
    eq(seq, [0, 1, 2, 3], "round-robin victim sequence")
    rd(m, 8 * 0x20)                                  # way 0 ; rr -> 1
    rd(m, 7 * 0x20)                                  # hit way 3 ; rr stays 1
    eq(m.rr[0], 1, "rr unchanged by hit on way 3")
    rd(m, 9 * 0x20)                                  # way 1 ; rr -> 2
    eq((way_tags(m, 0), m.rr[0]), ([8, 9, 6, 7], 2), "rr state")
    # invalidate ways 1 and 3 (tags 9 and 7); invalid ways are preferred, counter becomes w+1 (not counter+1)
    m.cmo(2, 0, 9 * 0x20, 0x10)
    m.cmo(2, 0, 7 * 0x20, 0x10)
    eq((way_tags(m, 0), m.rr[0]), ([8, None, 6, None], 2), "rr after invalidations (CMO does not touch)")
    rd(m, 10 * 0x20)                                 # lowest invalid = way 1 (counter says 2!) ; counter <- 2
    eq((way_tags(m, 0), m.rr[0]), ([8, 10, 6, None], 2), "rr: invalid way 1 chosen, counter <- 2")
    rd(m, 11 * 0x20)                                 # invalid way 3 ; counter <- 0
    eq((way_tags(m, 0), m.rr[0]), ([8, 10, 6, 11], 0), "rr: invalid way 3 chosen, counter <- 0")
    rd(m, 12 * 0x20)                                 # all valid: victim = counter 0
    eq((way_tags(m, 0), m.rr[0]), ([12, 10, 6, 11], 1), "rr: policy victim way 0")
    # 1 way and 2 ways
    m = mk(2, 1, 16, 32, 0)
    rd(m, 0x00)
    rd(m, 0x20)
    eq((m.rr[0], way_tags(m, 0)), (0, [1]), "rr 1-way")
    m = mk(2, 2, 16, 32, 0)
    rd(m, 0x00)
    rd(m, 0x20)
    rd(m, 0x40)
    eq((m.rr[0], way_tags(m, 0)), (1, [2, 1]), "rr 2-way: after fill counter 0 -> victim way 0")


def test_dirty_eviction_trace():
    # sets=2 ways=1 line=32 (BEATS=2, OFF_W=5, IDX_W=1): set = A[5], tag = A[31:6].  0x00,0x40,0x80 all map to set 0.
    m = mk(2, 1, 32, 32, 1)
    r = wr(m, 0x10, D1)                              # write miss, beat 1 of line 0x00
    eq(tuple(r), (1, 0, 0x03, 0), "write-miss response (OKAY, meta 03, zero data)")
    eq(tr(m), [R_(0x00), R_(0x10)], "write-miss refill beats ascending")
    r = rd(m, 0x40)                                  # read miss: dirty victim line 0x00 -> WB 2 beats, then refill
    eq(tuple(r), (1, 0, 0x02, H(I40)), "read-miss response data = init word 0x40")
    eq(tr(m), [R_(0x00), R_(0x10), W_(0x00, H(I00)), W_(0x10, D1), R_(0x40), R_(0x50)],
       "dirty-eviction trace: WB beats (victim base + 16b, be FFFF) then refill beats")
    eq((m.cnt["wr_miss"], m.cnt["rd_miss"], m.cnt["refills"], m.cnt["evictions"], m.cnt["writebacks"]),
       (1, 1, 2, 1, 1), "dirty eviction counters")
    eq((m.cnt["mem_rd_beats"], m.cnt["mem_wr_beats"]), (4, 2), "dirty eviction beat counters")
    eq(hx(m.mem.read_word(0x10)), hx(D1), "written-back data in memory")
    eq(sorted(m.mem.written), [0x00, 0x10], "only written-back words are 'written'")
    rd(m, 0x80)                                      # clean victim: no WB, evictions += 1
    eq(tr(m)[6:], [R_(0x80), R_(0x90)], "clean eviction: refill only")
    eq((m.cnt["evictions"], m.cnt["writebacks"]), (2, 1), "clean eviction counters")
    m.check_invariants()


def test_write_miss_partial_merge():
    # sets=2 ways=2 line=32.  addr 0x30 = set 1, beat 1, line base 0x20.  be=00F0 -> lanes 4..7 = D lanes 4..7.
    # merged (MSB first) = I30[0:16] + D1[16:24] + I30[24:32] ; D1 string = 00112233445566778899aabbccddeeff
    m = mk(2, 2, 32, 32, 1)
    data_str = "00112233445566778899aabbccddeeff"
    merged = I30[0:16] + data_str[16:24] + I30[24:32]
    eq(merged, "ef51b31576d83a9c8899aabb85e648aa", "hand-built merged word")
    r = wr(m, 0x30, D1, be=0x00F0)
    eq(tuple(r), (1, 0, 0x03, 0), "partial write-miss response")
    eq((m.cnt["wr_miss"], m.cnt["refills"], m.cnt["wr_hit"]), (1, 1, 0), "no wr_hit for the replayed write")
    eq(tr(m), [R_(0x20), R_(0x30)], "refill of line 0x20")
    eq(m.lines[1][0].dirty, True, "line dirty after write")
    eq(hx(rd(m, 0x30).data), merged, "read back merged beat")
    eq(hx(rd(m, 0x30, be=0x0010).data), "0" * 22 + "bb" + "0" * 8, "be=0010 -> lane 4 only")
    eq(hx(rd(m, 0x30, be=0x0001).data), "0" * 30 + "aa", "be=0001 -> lane 0 only (init byte 0xaa)")
    eq(hx(rd(m, 0x30, be=0x8000).data), "ef" + "0" * 30, "be=8000 -> lane 15 only")
    eq(hx(rd(m, 0x20).data), I20, "untouched beat 0 holds the refilled memory pattern")
    eq(m.cnt["rd_hit"], 5, "5 read hits")
    m.cmo(3, 1, 0, 0)
    eq(tr(m)[2:], [W_(0x20, H(I20)), W_(0x30, H(merged))], "CLEAN_INVAL writes back both beats")
    # full-beat write on a hit and byte-lane exactness
    m = mk(2, 2, 32, 32, 1)
    rd(m, 0x20)
    wr(m, 0x20, D1, be=0x0001)
    wr(m, 0x20, D1, be=0x8000)
    exp = list(bytes.fromhex(I20))                  # MSB-first byte list
    exp[15] = 0xFF                                  # lane 0 <- D lane 0 (0xff)
    exp[0] = 0x00                                   # lane 15 <- D lane 15 (0x00)
    eq(hx(rd(m, 0x20).data), bytes(exp).hex(), "single-lane writes")
    eq(m.cnt["wr_hit"], 2, "two write hits")


def test_inval_discards_dirty():
    m = mk(2, 2, 16, 32, 1)
    wr(m, 0x00, D1)
    eq(m.cmo(2, 1, 0, 0), (1, 1, 0), "INVAL all: 1 line, 1 dirty discard")
    eq((m.cnt["cmo_lines"], m.cnt["cmo_dirty_discard"], m.cnt["mem_wr_beats"], m.cnt["writebacks"]),
       (1, 1, 0, 0), "INVAL counters: no writeback")
    eq(len(m.mem.written), 0, "memory untouched")
    eq(m.lines[0][0].valid, False, "line invalid")
    eq(hx(rd(m, 0x00).data), I00, "re-read returns memory data, not the discarded write")
    eq(m.cnt["rd_miss"], 1, "re-read is a miss")
    # INVAL of a clean line: no discard count
    eq(m.cmo(2, 0, 0, 16), (1, 0, 0), "INVAL clean line")
    eq(m.cmo(3, 1, 0, 0), (0, 0, 0), "nothing valid left")
    eq(m.cnt["cmo_dirty_discard"], 1, "dirty discard counter unchanged")


def test_clean_keeps_valid():
    m = mk(2, 2, 16, 32, 1)
    wr(m, 0x00, D1)
    plru, rr = [x[:] for x in m.plru], m.rr[:]
    eq(m.cmo(1, 0, 0, 16), (1, 0, 0), "CLEAN range [0,16): 1 line")
    eq(tr(m), [R_(0x00), W_(0x00, D1)], "CLEAN writes the line back")
    eq((m.lines[0][0].valid, m.lines[0][0].dirty), (True, False), "CLEAN: valid stays, dirty cleared")
    eq((m.cnt["writebacks"], m.cnt["evictions"]), (1, 0), "CLEAN: writebacks=1, evictions untouched")
    eq((m.plru, m.rr), (plru, rr), "CMO applies no touch")
    eq(tuple(rd(m, 0x00)), (1, 0, 0x02, D1), "read hit after CLEAN returns the written data")
    eq(m.cnt["rd_hit"], 1, "rd_hit after CLEAN")
    eq(m.cmo(1, 1, 0, 0), (1, 0, 0), "CLEAN of a clean line: in scope, no traffic")
    eq(m.cnt["mem_wr_beats"], 1, "no second writeback")
    eq(m.cmo(2, 1, 0, 0), (1, 0, 0), "INVAL after CLEAN: no dirty data to discard")
    eq(m.cnt["cmo_dirty_discard"], 0, "no discard after CLEAN")
    # CLEAN_INVAL of a dirty line: writeback and invalidate
    wr(m, 0x20, D1)
    eq(m.cmo(3, 0, 0x20, 1), (1, 0, 0), "CLEAN_INVAL dirty line")
    eq((m.lines[0][0].valid, m.lines[0][1].valid, m.cnt["writebacks"]), (False, False, 2), "CLEAN_INVAL result")
    eq(tr(m)[-1], W_(0x20, D1), "CLEAN_INVAL writeback beat")


def test_merr_refill():
    # sets=2 ways=2 line=32 (BEATS=2).  line 0x00: set 0.
    m = mk(2, 2, 32, 32, 1)
    m.merr("R", 0x00, 7, 1)
    r = rd(m, 0x10)
    eq(tuple(r), (1, 7, 0x02, 0), "refill failure response: status 7, zero data")
    eq(tr(m), [R_(0x00, 7), R_(0x10, 0)], "both refill beats issued, first one failed")
    eq((m.cnt["refill_errors"], m.cnt["refills"], m.cnt["rd_miss"], m.cnt["err_rsp"], m.cnt["mem_rd_beats"]),
       (1, 0, 1, 1, 2), "refill error counters")
    eq([ln.valid for ln in m.lines[0]], [False, False], "no line installed, way stays invalid")
    eq((m.plru[0], m.rr[0]), ([0], 0), "no touch after refill error")
    r = rd(m, 0x10)
    eq(tuple(r), (1, 0, 0x02, H(I10)), "retry succeeds (count exhausted)")
    eq((m.lines[0][0].valid, m.plru[0], m.cnt["refills"], m.cnt["mem_rd_beats"]), (True, [1], 1, 4), "retry installs")
    # write miss whose refill fails is not performed; status 1; other statuses
    m.merr("R", 0x40, 1, 1)
    r = wr(m, 0x40, D1)
    eq(tuple(r), (1, 1, 0x03, 0), "write-miss refill failure: status 1, meta 03")
    eq(([ln.valid for ln in m.lines[0]], m.plru[0]), ([True, False], [1]), "write-miss refill failure: nothing installed")
    r = rd(m, 0x40)
    eq(tuple(r), (1, 0, 0x02, H(I40)), "write was NOT performed (memory pattern read back)")
    # first failing beat's status is reported; MERR consumed in file order, one counter per request
    m.merr("R", 0xA0, 7, 1)
    m.merr("R", 0xA0, 1, 1)
    r = rd(m, 0xB0)                                  # set 1, beats R 0xA0 (st 7, entry 1) R 0xB0 (st 1, entry 2)
    eq(r.status, 7, "status of the FIRST failing beat")
    eq([t.status for t in m.trace[-2:]], [7, 1], "statuses per beat from two armed entries")
    eq(rd(m, 0xB0).status, 0, "both entries exhausted")
    # count 2 with BEATS 2: one whole refill fails, next works.  count 0 = forever.
    m.merr("R", 0x120, 7, 2)
    eq((rd(m, 0x120).status, rd(m, 0x120).status), (7, 0), "count 2 spans exactly one refill")
    m.merr("R", 0x160, 1, 0)
    eq([rd(m, 0x160).status for _ in range(4)], [1, 1, 1, 1], "count 0 = forever")
    eq(rd(m, 0x1A0).status, 0, "other lines unaffected")
    m.merr("W", 0x1C0, 7, 0)                         # a permanent WRITE error must not affect READ beats of that line
    eq(rd(m, 0x1C0).status, 0, "MERR W does not fail refill reads")
    m.merr("R", 0x1E0, 7, 0)                         # and a permanent READ error must not affect WRITE beats
    eq(wr(m, 0x1E0, D1, attr=1).status, 0, "MERR R does not fail bypass writes")
    m.check_invariants()


def _merr_wb(repl):
    m = mk(2, 2, 32, 32, repl)
    A, B, C = H("a0" * 16), H("b1" * 16), H("c2" * 16)
    wr(m, 0x00, A)                                   # set 0 way 0, tag 0, dirty
    wr(m, 0x10, B)
    wr(m, 0x40, C)                                   # set 0 way 1, tag 1, dirty
    eq(way_tags(m, 0), [0, 1], "fill")
    eq(m.victim_way(0), 0, "victim is way 0 (PLRU bit 0 / rr counter 0)")
    n_rd = m.cnt["mem_rd_beats"]
    m.merr("W", 0x00, 7, 1)
    r = rd(m, 0x80)                                  # tag 2 -> victim way 0 (dirty): WB beat0 fails, beat1 ok
    eq(tuple(r), (1, 7, 0x02, 0), "writeback-error response: status of first failing WB beat")
    eq(tr(m)[-2:], [W_(0x00, A, 7), W_(0x10, B, 0)], "both WB beats issued, first failed")
    eq(m.cnt["mem_rd_beats"], n_rd, "no refill issued after a writeback error")
    eq((m.cnt["wb_errors"], m.cnt["writebacks"], m.cnt["evictions"], m.cnt["err_rsp"], m.cnt["rd_miss"]),
       (1, 0, 0, 1, 1), "wb error counters")
    eq((m.lines[0][0].valid, m.lines[0][0].dirty, m.lines[0][0].tag), (True, True, 0), "victim stays valid+dirty")
    eq(bytes(m.lines[0][0].data), (A.to_bytes(16, "little") + B.to_bytes(16, "little")), "victim data intact")
    eq(sorted(m.mem.written), [0x10], "beat 0 not performed, beat 1 (succeeded) is in memory")
    eq(hx(m.mem.read_word(0x00)), I00, "failed write left memory untouched")
    eq(m.victim_way(0), 1, "victim touched: next miss picks a different way")
    # touch(set, victim): PLRU bit <- 1 (way 0 went left); round-robin counter <- (0+1) mod 2 = 1
    eq((m.plru[0], m.rr[0]), (([1], 0) if repl else ([0], 1)), "touch state after wb error")
    r = rd(m, 0x80)                                  # now victim way 1 (tag 1, dirty): WB ok, refill ok
    eq(tuple(r), (1, 0, 0x02, H(pat_word(0x80))), "second attempt succeeds on the other way")
    eq(tr(m)[-4:], [W_(0x40, C), W_(0x50, H(pat_word(0x50))), R_(0x80), R_(0x90)], "WB way 1 then refill")
    eq(way_tags(m, 0), [0, 2], "way 1 replaced, way 0 still holds the dirty line")
    eq((m.cnt["writebacks"], m.cnt["evictions"], m.cnt["refills"]), (1, 1, 3), "counters after second attempt")
    eq(hx(rd(m, 0x00).data), hx(A), "dirty line data survives and is readable (hit)")
    # CMO writeback failure: line stays valid+dirty, walk continues, wb_errors counted, err flag set
    m.merr("W", 0x00, 1, 2)
    plru, rr = [x[:] for x in m.plru], m.rr[:]
    n_wr = m.cnt["mem_wr_beats"]
    eq(m.cmo(1, 0, 0x00, 0x20), (1, 0, 1), "CLEAN with failing writeback: err=1")
    eq(m.cnt["mem_wr_beats"], n_wr + 2, "both CMO WB beats issued")
    eq((m.lines[0][0].valid, m.lines[0][0].dirty), (True, True), "line stays valid+dirty")
    eq((m.cnt["wb_errors"], m.cnt["writebacks"]), (2, 1), "cmo wb error counters")
    eq((m.plru, m.rr), (plru, rr), "no touch by CMO")
    eq(m.cmo(1, 0, 0x00, 0x20), (1, 0, 0), "second CLEAN succeeds (count 2 exhausted)")
    eq((m.lines[0][0].valid, m.lines[0][0].dirty, m.cnt["writebacks"]), (True, False, 2), "now clean")
    # walk continues after a failing line: set 0 way 0 fails (permanent), set 1 line is written back
    m.merr("W", 0x00, 7, 0)
    wr(m, 0x00, B)
    wr(m, 0x20, C)                                   # set 1
    r = m.cmo(3, 1, 0, 0)
    eq(r, (3, 0, 1), "CLEAN_INVAL all: 3 lines in scope (set0: tag0, tag2; set1: tag0), err 1")
    eq([(ln.valid, ln.dirty) for ln in m.lines[0]], [(True, True), (False, False)], "failed line kept, other gone")
    eq(m.lines[1][0].valid, False, "set 1 line written back and invalidated despite the earlier failure")
    m.check_invariants()


def test_merr_wb():
    _merr_wb(1)
    _merr_wb(0)


def test_illegal_ordering():
    m = mk(2, 2, 32, 32, 1)
    cases = [
        # (op, dom, attr, addr, be)           expected status
        ((0, 0xFF, 0x83, 0x1, 0), 3), ((3, 0xFF, 0x83, 0x1, 0), 3), ((0xF, 0x00, 0x00, 0x10, 0xFFFF), 3),
        ((1, 0xFF, 0x83, 0x1, 0), 5), ((2, 0xFF, 0x83, 0xF, 0), 5),
        ((2, 0xFF, 0x83, 0x10, 0), 4), ((1, 0x00, 0x00, 0x10, 0), 4),
        ((2, 0xFF, 0x80, 0x10, 1), 6), ((1, 0xFF, 0x03, 0x10, 1), 6), ((1, 0x00, 0x7F, 0x10, 1), 6),
        ((1, 0x00, 0x80, 0x10, 1), 6), ((2, 0x00, 0xFC | 0, 0x10, 1), 6),
        ((1, 0xFF, 0x00, 0x10, 1), 2),
        ((1, 0x00, 0x00, 0x1_0000_0000, 1), 1), ((2, 0x00, 0x00, 0xFFFFFFFFFFFFFFF0, 1), 1),
        ((1, 0xFF, 0x00, 0x1_0000_0000, 1), 2),     # legality beats the range check
        ((1, 0x00, 0x00, 0x1_0000_0001, 1), 5),
        ((1, 0x00, 0x00, 0x1_0000_0000, 0), 4),
        ((1, 0x00, 0x03, 0x1_0000_0000, 1), 6),
        ((1, 0x00, 0x00, 0x8000_0000_0000_0000, 1), 1),
    ]
    n_err = 0
    for (op, dom, attr, addr, be), st in cases:
        r = m.req(op, 0x5A, dom, attr, addr, be, H("ff" * 16))
        n_err += 1
        eq((r.tag, r.status, r.data), (0x5A, st, 0), "illegal case op=%x dom=%02x attr=%02x addr=%x be=%x" % (op, dom, attr, addr, be))
        eq(r.meta, 0x03 if op == 2 else 0x02, "error response meta for op %x" % op)
    eq(len(m.trace), 0, "no memory traffic for illegal requests")
    eq(m.cnt["err_rsp"], n_err, "err_rsp counted once per illegal request")
    eq(sum(v for k, v in m.cnt.items() if k != "err_rsp"), 0, "no other counter moved")
    eq(m.valid_lines(), [], "no state change")
    rd(m, 0x10)                                      # cache line 0x00, then addresses aliasing it above PADDR_W
    n_hit, n_err = m.cnt["rd_hit"], m.cnt["err_rsp"]
    r = rd(m, 0x1_0000_0010)
    eq((r.status, r.data, m.cnt["rd_hit"], m.cnt["err_rsp"]), (1, 0, n_hit, n_err + 1), "alias above PADDR_W: DECODE_ERR, no hit")
    r = wr(m, 0x1_0000_0010, D1)
    eq((r.status, m.lines[0][0].dirty, m.cnt["wr_hit"]), (1, False, 0), "alias write: DECODE_ERR, cached line untouched")
    # legal attr bits: qos/instr/secure/priv in any combination, mem_type 0..2
    for attr in (0x7C, 0x7D, 0x7E, 0x1C, 0x00, 0x60):
        eq(rd(m, 0x10, attr=attr, dom=0xFE).status, 0, "legal attr 0x%02x" % attr)
    m64 = mk(2, 2, 32, 64, 1)                       # PADDR_W = 64: nothing can be a DECODE_ERR
    eq(rd(m64, 0xFFFFFFFFFFFFFFF0).status, 0, "no decode error possible with PADDR_W=64")


def test_dma_stale_read():
    m = mk(2, 2, 32, 32, 1)
    eq(hx(rd(m, 0x00).data), I00, "initial read caches line 0x00 (clean)")
    dma = bytes(range(16))                           # byte i = i  -> lane 0 = 00 ... lane 15 = 0f
    m.dmaw(0x00, dma)
    dma_str = "0f0e0d0c0b0a09080706050403020100"
    eq(hx(rd(m, 0x00).data), I00, "cacheable read hits and is STALE after DMAW")
    eq(hx(rd(m, 0x00, attr=1).data), dma_str, "NC read sees the DMA data")
    eq((m.cnt["bypass_rd"], m.cnt["mem_rd_beats"], m.cnt["rd_hit"]), (1, 3, 1), "counters after stale read")
    eq(m.cmo(2, 0, 0x00, 0x20), (1, 0, 0), "INVAL the clean line")
    eq(hx(rd(m, 0x00).data), dma_str, "after INVAL the read refills the DMA data")
    # dirty line: DMAW is overwritten by the writeback of the WHOLE line
    wr(m, 0x40, D1, be=0x000F)                       # lanes 0..3 <- ff ee dd cc
    merged = I40[:24] + "ccddeeff"
    dma2 = bytes(0xA0 + i for i in range(16))
    m.dmaw(0x40, dma2)
    dma2_str = "afaeadacabaaa9a8a7a6a5a4a3a2a1a0"
    eq(hx(rd(m, 0x40).data), merged, "dirty line hit returns the cached (merged) data")
    eq(hx(rd(m, 0x40, attr=2).data), dma2_str, "DEVICE read before CLEAN sees DMA (stale w.r.t. cache) data")
    eq(m.cmo(1, 0, 0x40, 0x20), (1, 0, 0), "CLEAN the dirty line")
    eq(tr(m)[-2:], [W_(0x40, H(merged)), W_(0x50, H(I50))], "CLEAN writes back the WHOLE line over the DMA data")
    eq(hx(rd(m, 0x40, attr=2).data), merged, "device read after CLEAN sees the cache data (DMA bytes clobbered)")
    eq(hx(rd(m, 0x40).data), merged, "cached read still hits (CLEAN keeps the line)")
    # device read of dirty data before CLEAN returns OLD memory
    wr(m, 0x00, D1)                                  # line 0x00 is clean-valid (refilled) -> now dirty
    eq(hx(rd(m, 0x00, attr=1).data), dma_str, "NC read sees stale memory while the cache line is dirty")
    m.cmo(1, 0, 0x00, 1)
    eq(hx(rd(m, 0x00, attr=1).data), hx(D1), "after CLEAN the NC read sees the new data")
    # unaligned DMAW spanning two 16-byte words
    m = mk(2, 2, 32, 32, 1)
    m.dmaw(0x0C, bytes([0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88]))
    eq(hx(m.mem.read_word(0x00)), "44332211" + I00[8:], "DMAW lanes 12..15 of word 0x00")
    eq(hx(m.mem.read_word(0x10)), I10[:24] + "88776655", "DMAW lanes 0..3 of word 0x10")
    eq(sorted(m.mem.written), [0x00, 0x10], "both touched words count as written")
    eq(len(m.trace) + sum(m.cnt.values()), 0, "DMAW: no trace, no counters")


def test_bypass_and_cfg():
    m = mk(2, 2, 32, 32, 1)
    m.cfg(1, 1, 0x100, 0x200)
    rd(m, 0xF0)                                      # below window: cached (miss, 2 refill beats)
    r = rd(m, 0x100, be=0x00FF, attr=0x1C)           # base is inclusive -> bypass (instr/secure/priv bits ignored)
    eq((r.status, hx(r.data)), (0, "0" * 16 + pat_word(0x100)[16:]), "bypass read masked with be")
    eq(tr(m)[-1], ("R", 0x100, 0x00FF, 0, 0), "bypass read forwarded unchanged (be as given)")
    rd(m, 0x1F0)                                     # limit-16 -> bypass
    rd(m, 0x200)                                     # limit exclusive -> cached
    eq((m.cnt["bypass_rd"], m.cnt["rd_miss"], m.cnt["mem_rd_beats"]), (2, 2, 6), "window counters")
    w = wr(m, 0x100, D1, be=0x0F0F)
    eq(tuple(w), (1, 0, 0x03, 0), "bypass write response")
    eq(tr(m)[-1], ("W", 0x100, 0x0F0F, D1, 0), "bypass write forwarded with be and unmasked data")
    eq(hx(m.mem.read_word(0x100)),
       "".join(("%02x" % b) for b in reversed([(D1 >> (8 * i)) & 0xFF if (0x0F0F >> i) & 1 else pat(0x100 + i)
                                                for i in range(16)])), "bypass write only changes enabled lanes")
    eq(m.cnt["bypass_wr"], 1, "bypass_wr")
    # NC / DEVICE attr bypass even without window; mem_type 3 illegal; cfg_en = 0 bypasses everything
    m.cfg(1, 0, 0, 0)
    n = m.cnt["bypass_rd"]
    rd(m, 0xF0, attr=1)
    rd(m, 0xF0, attr=2)
    eq(m.cnt["bypass_rd"], n + 2, "mem_type NC/DEVICE bypass (line 0xE0 is cached, cache ignored)")
    eq(rd(m, 0xF0, attr=3).status, 6, "mem_type 3 -> BAD_ATTR")
    hits = m.cnt["rd_hit"]
    m.cfg(0, 0, 0, 0)
    eq(hx(rd(m, 0xF0).data), pat_word(0xF0), "cfg_en=0: bypass")
    eq((m.cnt["rd_hit"], m.cnt["bypass_rd"]), (hits, n + 3), "cfg_en=0 counters")
    m.cfg(1, 0, 0, 0)
    eq(m.cnt["rd_hit"], hits, "no flush on cfg change")
    rd(m, 0xF0)
    eq(m.cnt["rd_hit"], hits + 1, "cached line still valid after cfg_en 0 -> 1")
    # unsigned 64-bit window compare
    m = mk(2, 2, 32, 64, 1)
    m.cfg(1, 1, 0xFFFFFFFFFFFFFF00, 0xFFFFFFFFFFFFFFF0)
    for a, byp in ((0xFFFFFFFFFFFFFF00, 1), (0xFFFFFFFFFFFFFFE0, 1), (0xFFFFFFFFFFFFFFF0, 0), (0xFFFFFFFFFFFFFEF0, 0),
                   (0x0000000000000100, 0)):
        b0 = m.cnt["bypass_rd"]
        rd(m, a)
        eq(m.cnt["bypass_rd"] - b0, byp, "window compare for 0x%x" % a)
    m.cfg(1, 1, 0x7FFFFFFFFFFFFF00, 0x8000000000000100)     # straddles 2^63: only an UNSIGNED compare sees it
    for a, byp in ((0x7FFFFFFFFFFFFEF0, 0), (0x7FFFFFFFFFFFFF00, 1), (0x7FFFFFFFFFFFFFF0, 1), (0x8000000000000000, 1),
                   (0x80000000000000F0, 1), (0x8000000000000100, 0)):
        b0 = m.cnt["bypass_rd"]
        rd(m, a)
        eq(m.cnt["bypass_rd"] - b0, byp, "2^63-straddling window for 0x%x" % a)
    m.cfg(1, 1, 0x200, 0x100)                        # inverted window: matches nothing
    b0 = m.cnt["bypass_rd"]
    for a in (0x100, 0x200, 0x180, 0x1F0):
        rd(m, a)
    eq(m.cnt["bypass_rd"], b0, "base > limit matches nothing")
    # bypass is not a touch / state change; bypass errors
    m = mk(2, 2, 32, 32, 1)
    rd(m, 0x00)
    plru, lines = [x[:] for x in m.plru], m.valid_lines()
    rd(m, 0x00, attr=1)
    wr(m, 0x00, D1, attr=2)
    eq((m.plru, m.valid_lines()), (plru, lines), "bypass: no touch, no state change")
    for repl in (1, 0):                              # bypass to a cached line must not touch (way 0 vs last-touched way 1)
        mt = mk(2, 2, 32, 32, repl)
        rd(mt, 0x00)
        rd(mt, 0x40)
        snap = ([x[:] for x in mt.plru], mt.rr[:], mt.victim_way(0))
        rd(mt, 0x00, attr=1)
        wr(mt, 0x00, D1, attr=2)
        rd(mt, 0x10, attr=1, be=0x1)
        eq(([x[:] for x in mt.plru], mt.rr[:], mt.victim_way(0)), snap, "bypass: no touch (repl=%d)" % repl)
        eq((mt.cnt["rd_hit"], mt.cnt["wr_hit"], mt.lines[0][0].dirty), (0, 0, False), "bypass: not a hit, no dirty")
    m.merr("R", 0x40, 7, 1)
    r = rd(m, 0x40, attr=1)
    eq((r.status, r.data), (7, 0), "bypass read error: status from memory, zero data")
    m.merr("W", 0x40, 1, 1)
    r = wr(m, 0x40, D1, attr=1)
    eq((r.status, r.meta), (1, 0x03), "bypass write error")
    eq(hx(m.mem.read_word(0x40)), I40, "failed bypass write not performed")
    eq((m.cnt["bypass_rd"], m.cnt["bypass_wr"], m.cnt["err_rsp"]), (2, 2, 2), "bypass counters incl. failures")
    eq(wr(m, 0x40, D1, attr=1).status, 0, "next bypass write ok")
    eq(hx(m.mem.read_word(0x40)), hx(D1), "bypass write performed")


def test_cmo_ranges():
    m = mk(4, 2, 32, 64, 1)                          # LINE 32; set = A[6:5]
    for a in (0x00, 0x20, 0x40, 0x60, 0xFFFFFFFFFFFFFFF0):
        rd(m, a)
    eq(sorted(m.valid_lines()), [0, 0x20, 0x40, 0x60, 0xFFFFFFFFFFFFFFE0], "five lines cached")
    top = 0xFFFFFFFFFFFFFFE0
    M = 0xFFFFFFFFFFFFFFFF
    cases = [
        ((0x30, 0x20), 2),                           # [0x30,0x50): lines 0x20 and 0x40
        ((0x40, 0), 0), ((0x45, 0), 0),              # size 0 -> nothing (SPEC-Q 1 for the unaligned start)
        ((0x20, 0x20), 1),                           # end 0x40 excludes line 0x40
        ((0x3F, 1), 1), ((0x40, 1), 1), ((0x1F, 1), 1), ((0x20, 1), 1),
        ((0x40, 0x20), 1), ((0x41, 0x1F), 1), ((0x5F, 1), 1), ((0x60, 1), 1), ((0x80, 0x100), 0),
        ((0x00, 0x80), 4),
        ((0xFFFFFFFFFFFFFFF0, 0x100), 1),            # end capped to 2^64 (65-bit arithmetic): top line in scope
        ((M, 1), 1), ((top, 0x10), 1), ((top, 0), 0), ((top - 0x20, 0x20), 0),
        ((0, M), 5),                                 # end = 2^64-1, top line base < end
        ((0xFFFFFFFFFFFFFF00, M), 1),                # start+size overflows 2^64 -> end = 2^64
        ((0xFFFFFFFFFFFFFFE0, 0x20), 1),
    ]
    for (start, size), n in cases:
        eq(m.cmo(1, 0, start, size)[0], n, "CLEAN range start=%x size=%x" % (start, size))
    eq(m.cmo(1, 1, 0x1234, 0x5678)[0], 5, "all=1 ignores start/size")
    eq(m.cnt["cmo_lines"], sum(n for _, n in cases) + 5, "cmo_lines counts every in-scope line")
    # INVAL a partial range, others stay
    m.cmo(2, 0, 0x30, 0x20)
    eq(sorted(m.valid_lines()), [0, 0x60, top], "INVAL [0x30,0x50) removed lines 0x20 and 0x40")
    # walk order of writebacks: sets ascending, ways ascending, beats ascending
    m = mk(4, 2, 32, 64, 1)
    for a in (0x60, 0xFFFFFFFFFFFFFFF0, 0x20, 0x00):
        wr(m, a, D1)                                 # set3 way0=0x60, set3 way1=top, set1 way0=0x20, set0 way0=0x00
    n0 = len(m.trace)
    m.cmo(3, 1, 0, 0)
    eq([t.addr for t in m.trace[n0:]],
       [0x00, 0x10, 0x20, 0x30, 0x60, 0x70, 0xFFFFFFFFFFFFFFE0, 0xFFFFFFFFFFFFFFF0],
       "CMO walk order: set asc, way asc, beat asc")
    eq(m.cnt["writebacks"], 4, "four lines written back")


def test_file_roundtrip():
    stim = """# comment
CFG 0 1 0 0000000000000000 0000000000000000
REQ 1 2 05 00 00 0000000000000010 0003 00112233445566778899aabbccddeeff
REQ 2 1 06 00 00 0000000000000010 ffff 00000000000000000000000000000000
REQ 3 1 07 00 00 0000000000000010 0001 00000000000000000000000000000000
DMAW 4 0000000000000030 3 aabbcc
CMO 5 3 1 0000000000000000 0000000000000000
"""
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, "stim_rt.txt")
        open(p, "w").write(stim)
        sfm.run_stimulus(p, d, "rt", 2, 1, 16, 32, 1, check=True)
        merged = "288aec4eaf1173d53698fa5cbe1feeff"          # I10 with lanes 1,0 <- ee, ff
        exp = {
            "rsp": ["1 05 0 03 " + "0" * 32, "2 06 0 02 " + merged, "3 07 0 02 " + "0" * 30 + "ff"],
            "mem": ["0 R 0000000000000010 ffff %s 0" % ("0" * 32),
                    "1 W 0000000000000010 ffff %s 0" % merged],
            "img": ["0000000000000010 " + merged, "0000000000000030 ef51b31576d83a9cfd5fc12385ccbbaa"],
            "cmo": ["5 1 0 0"],
            "cnt": ["rd_hit 2", "rd_miss 0", "wr_hit 0", "wr_miss 1", "refills 1", "evictions 0", "writebacks 1",
                    "mem_rd_beats 1", "mem_wr_beats 1", "bypass_rd 0", "bypass_wr 0", "cmo_lines 1",
                    "cmo_dirty_discard 0", "err_rsp 0", "refill_errors 0", "wb_errors 0"],
        }
        for k, v in exp.items():
            got = open(os.path.join(d, "exp_%s_rt.txt" % k)).read().split("\n")
            eq(got, v + [""], "exp_%s file content" % k)
        # malformed / out-of-sequence records are rejected
        bad = os.path.join(d, "stim_bad.txt")
        open(bad, "w").write("CFG 1 1 0 0000000000000000 0000000000000000\n")
        try:
            sfm.run_stimulus(bad, d, "bad", 2, 1, 16, 32, 1)
            check(False, "out-of-sequence record accepted")
        except ValueError:
            check(True, "")


def test_merr_status_zero_rejected():
    m = mk(2, 1, 16, 32, 1)
    try:
        m.merr("R", 0, 0, 1)
        check(False, "MERR status 0 accepted")
    except ValueError:
        check(True, "")


# ---------------------------------------------------------------------------------------------- random runs
def _in_scope(base, line, start, size, all_):
    """Independent restatement of the spec 7 scope rule (with the explicit size 0 rule)."""
    if all_:
        return True
    end = min(start + size, 1 << 64)
    return size != 0 and base < end and base + line > start


def coherent_run(seed, sets, ways, line, paddr, repl, nops):
    """Flat-memory ('architectural') cross-check.

    Workload restrictions that make a flat memory an EXACT reference:
      * cacheable lines (even tags) and uncached lines (odd tags, always accessed with mem_type NC/DEVICE or
        DMAW) are disjoint, so the 'mismatched attribute' behaviour never occurs;
      * DMAW only goes to uncached lines;
      * MERR is armed only with finite counts, and the final CLEAN_INVAL-all is repeated until it reports no
        error, so every dirty line eventually reaches memory.
    'arch' = byte image of what software should observe.
      * a write that completed OKAY is applied to arch (a write whose miss failed was not performed: skipped);
      * every OKAY read must equal arch (masked by be);
      * INVAL discards the dirty data of lines in scope: for each such line arch is reset to the bytes that
        MEMORY holds for that line at that moment (that is exactly what a later refill will return); all other
        discards are covered by this rule because dirty data only ever exists in cached lines;
      * at the end memory must equal arch byte for byte, and must hold nothing that is not in arch.
    """
    rng = random.Random(seed)
    m = CacheModel(sets, ways, line, paddr, repl)
    off_w, idx_w = line.bit_length() - 1, sets.bit_length() - 1
    tag_w = paddr - off_w - idx_w
    maxtag = (1 << tag_w) - 1
    arch = {}

    def ab(a):
        return arch.get(a, pat(a))

    def base_of(s, t):
        return (t << (off_w + idx_w)) | (s << off_w)

    def tag_pool(parity):
        ts = {t for t in (0, 1, 2, 3, maxtag, maxtag - 1, maxtag - 2) if 0 <= t <= maxtag and t % 2 == parity}
        while len(ts) < ways * 5:
            t = rng.randrange(maxtag + 1)
            if t % 2 == parity or maxtag == 0:
                ts.add(t)
        return sorted(ts)
    cpool = {s: tag_pool(0) for s in range(sets)}
    upool = {s: tag_pool(1) for s in range(sets)}
    hot = sorted({0, sets - 1, rng.randrange(sets), rng.randrange(sets)})

    def pick(pool):
        s = rng.choice(hot) if rng.random() < 0.8 else rng.randrange(sets)
        t = rng.choice(pool[s][:ways + 1]) if rng.random() < 0.6 else rng.choice(pool[s])
        return base_of(s, t)

    def rbe():
        return 0xFFFF if rng.random() < 0.4 else (rng.randrange(1, 0x10000))

    def lm(be):
        return sum(0xFF << (8 * i) for i in range(16) if (be >> i) & 1)

    def access(L, uncached):
        a = L + 16 * rng.randrange(line // 16)
        be = rbe()
        attr = rng.choice([1, 2]) if uncached else 0
        if rng.random() < 0.5:
            d = rng.getrandbits(128)
            r = m.req(2, 0, 0, attr, a, be, d)
            if r.status == 0:
                for i in range(16):
                    if (be >> i) & 1:
                        arch[a + i] = (d >> (8 * i)) & 0xFF
        else:
            r = m.req(1, 0, 0, attr, a, be, 0)
            if r.status == 0:
                word = int.from_bytes(bytes(ab(a + i) for i in range(16)), "little") & lm(be)
                if r.data != word:
                    check(False, "coherent run seed %d: read 0x%x be=%04x got %032x expected %032x"
                          % (seed, a, be, r.data, word))
                    raise AssertionError("read mismatch")

    for _ in range(nops):
        x = rng.random()
        if x < 0.52:
            access(pick(cpool), False)
        elif x < 0.64:
            access(pick(upool), True)
        elif x < 0.69:
            L = pick(upool)
            off = rng.randrange(line)
            n = rng.randint(1, min(64, line - off))
            data = bytes(rng.getrandbits(8) for _ in range(n))
            m.dmaw(L + off, data)
            for i, v in enumerate(data):
                arch[L + off + i] = v
        elif x < 0.78:
            L = pick(cpool if rng.random() < 0.7 else upool)
            m.merr(rng.choice("RW"), L, rng.choice([7, 1]), rng.randint(1, 4))
        else:
            op = rng.choice([1, 2, 3])
            if rng.random() < 0.3:
                all_, start, size = 1, 0, 0
            else:
                all_ = 0
                v = m.valid_lines()
                L = rng.choice(v) if v and rng.random() < 0.8 else pick(cpool)
                start = max(0, L + rng.choice([0, 0, 1, line - 1, line, -1, -line]))
                size = rng.choice([1, line, 2 * line, 4 * line, line // 2, 0, rng.randrange(1 << 12), (1 << 64) - 1])
                if size == 0 and start & (line - 1):
                    start &= ~(line - 1)             # keep clear of SPEC-Q 1
            scope = [(b, m.is_dirty(b)) for b in m.valid_lines() if _in_scope(b, line, start, size, all_)]
            lines, disc, err = m.cmo(op, all_, start, size)
            eq(lines, len(scope), "coherent run: cmo lines == independent scope count")
            if op == 2:
                eq(disc, sum(1 for _, d in scope if d), "coherent run: INVAL discards == dirty in scope")
                for b, d in scope:
                    if d:
                        for i in range(line):
                            arch[b + i] = m.mem.read_byte(b + i)
        m.check_invariants()
    for _ in range(500):
        if m.cmo(3, 1, 0, 0)[2] == 0:
            break
    else:
        check(False, "coherent run: final flush never succeeded")
    eq(m.valid_lines(), [], "coherent run: everything flushed")
    bad = [a for a in arch if m.mem.read_byte(a) != arch[a]]
    check(not bad, "coherent run seed %d (%d,%d,%d,%d,%d): memory != architectural image at %d bytes, e.g. 0x%x"
          % (seed, sets, ways, line, paddr, repl, len(bad), bad[0] if bad else 0))
    extra = [w for w in m.mem.written if any(m.mem.read_byte(w + i) != ab(w + i) for i in range(16))]
    check(not extra, "coherent run: memory holds data that is not architectural at 0x%x" % (extra[0] if extra else 0))


def test_coherent_runs():
    geos = [(128, 4, 64, 64, 1), (4, 2, 64, 32, 0), (8, 4, 32, 48, 1), (2, 1, 16, 40, 1), (4, 8, 64, 64, 1),
            (2, 2, 16, 32, 0), (4, 4, 256, 64, 1)]
    for i, g in enumerate(geos):
        coherent_run(1000 + i, *g, nops=2500)
    for seed in range(5):
        coherent_run(seed, 4, 4, 32, 40, seed % 2, nops=3000)


def test_random_invariants():
    """Invariants after EVERY record on long 'random' scenario runs (run_stimulus(check=True))."""
    geos = [(128, 4, 64, 64, 1), (4, 2, 64, 32, 0), (8, 4, 32, 48, 1), (2, 1, 16, 40, 1), (4, 8, 64, 64, 1),
            (2, 16, 16, 32, 1), (16, 2, 256, 64, 0)]
    with tempfile.TemporaryDirectory() as d:
        for i, (sets, ways, line, paddr, repl) in enumerate(geos):
            m = gs.generate("inv%d" % i, 100 + i, sets, ways, line, paddr, repl, "random", 5000, d)
            sfm.run_stimulus(os.path.join(d, "stim_inv%d.txt" % i), d, "inv%d" % i, sets, ways, line, paddr, repl,
                             check=True)
            check(m.cnt["rd_hit"] > 0 and m.cnt["evictions"] > 0, "random run %d exercised hits and evictions" % i)


# ---------------------------------------------------------------------------------------------- generator smoke
HEXRE = lambda n: "[0-9a-f]{%d}" % n          # noqa: E731
RE_REC = {
    "CFG": re.compile(r"^CFG (\d+) [01] [01] %s %s$" % (HEXRE(16), HEXRE(16))),
    "REQ": re.compile(r"^REQ (\d+) [0-9a-f] %s %s %s %s %s %s$" % (HEXRE(2), HEXRE(2), HEXRE(2), HEXRE(16), HEXRE(4), HEXRE(32))),
    "CMO": re.compile(r"^CMO (\d+) [1-3] [01] %s %s$" % (HEXRE(16), HEXRE(16))),
    "DMAW": re.compile(r"^DMAW (\d+) %s (\d+) ([0-9a-f]+)$" % HEXRE(16)),
    "MERR": re.compile(r"^MERR (\d+) [RW] %s [0-9a-f] (\d+)$" % HEXRE(16)),
}
CNT_NAMES = ("rd_hit rd_miss wr_hit wr_miss refills evictions writebacks mem_rd_beats mem_wr_beats bypass_rd "
             "bypass_wr cmo_lines cmo_dirty_discard err_rsp refill_errors wb_errors").split()
GEOS = [(128, 4, 64, 64, 1), (4, 2, 64, 32, 0), (8, 4, 32, 48, 1), (2, 1, 16, 40, 1), (4, 8, 64, 64, 1)]
SCEN = ["cold", "assoc", "replace", "partial", "raw", "sameline", "illegal", "bypass", "dma", "cmo", "merr", "random"]
COVER = {"replace": ["evictions", "writebacks", "wr_hit", "rd_hit"], "bypass": ["bypass_rd", "bypass_wr"],
         "illegal": ["err_rsp"], "cmo": ["cmo_lines", "cmo_dirty_discard"], "merr": ["refill_errors", "wb_errors"],
         "dma": ["cmo_lines", "bypass_rd"], "cold": ["rd_hit", "rd_miss"], "assoc": ["evictions"],
         "partial": ["wr_hit", "wr_miss"], "raw": ["wr_hit"], "sameline": ["wr_hit", "rd_hit"],
         "random": ["rd_hit", "evictions", "writebacks", "err_rsp", "bypass_rd", "cmo_lines"]}


def validate_files(d, name, geo, scen):
    sets, ways, line, paddr, repl = geo
    beats = line // 16
    lines = [l for l in open(os.path.join(d, "stim_%s.txt" % name)).read().split("\n") if l]
    recs = [l for l in lines if not l.startswith("#")]
    reqs, cmos = [], []
    for i, l in enumerate(recs):
        k = l.split()[0]
        mt = RE_REC[k].match(l)
        if not mt:
            check(False, "%s: malformed stim line %r" % (name, l))
            return
        if int(mt.group(1)) != i:
            check(False, "%s: stim seq %d expected %d" % (name, int(mt.group(1)), i))
            return
        if k == "DMAW" and (not 1 <= int(mt.group(2)) <= 64 or len(mt.group(3)) != 2 * int(mt.group(2))):
            check(False, "%s: DMAW length mismatch" % name)
        if k == "REQ":
            reqs.append((i, l.split()))
        if k == "CMO":
            cmos.append(i)
    check(recs[0].startswith("CFG 0 1 0 "), "%s: first record must be CFG 0 1 0 ..." % name)
    check(recs[-1].endswith(" 3 1 0000000000000000 0000000000000000") and recs[-1].startswith("CMO"),
          "%s: must end with CMO 3 1 0 0" % name)

    def lines_of(k):
        return [l for l in open(os.path.join(d, "exp_%s_%s.txt" % (k, name))).read().split("\n") if l]
    rsp = lines_of("rsp")
    eq(len(rsp), len(reqs), "%s: one exp_rsp line per REQ" % name)
    nonok = 0
    for l, (seq, t) in zip(rsp, reqs):
        mt = re.match(r"^(\d+) (%s) ([0-7]) (02|03) (%s)$" % (HEXRE(2), HEXRE(32)), l)
        if not mt or int(mt.group(1)) != seq or mt.group(2) != t[3]:
            check(False, "%s: bad exp_rsp line %r for req %r" % (name, l, t))
            break
        if mt.group(3) != "0":
            nonok += 1
            if int(mt.group(5), 16) != 0:
                check(False, "%s: non-OKAY response with data: %r" % (name, l))
        if mt.group(4) != ("03" if int(t[2], 16) == 2 else "02"):
            check(False, "%s: response meta %r for op %s" % (name, l, t[2]))
    mem = lines_of("mem")
    nr = nw = 0
    for i, l in enumerate(mem):
        mt = re.match(r"^(\d+) ([RW]) (%s) (%s) (%s) ([0-9a-f])$" % (HEXRE(16), HEXRE(4), HEXRE(32)), l)
        if not mt or int(mt.group(1)) != i or int(mt.group(3), 16) & 0xF or int(mt.group(4), 16) == 0:
            check(False, "%s: bad exp_mem line %r" % (name, l))
            break
        if mt.group(2) == "R":
            nr += 1
            if int(mt.group(5), 16) != 0:
                check(False, "%s: R with wdata" % name)
        else:
            nw += 1
    cnt = {}
    cl = lines_of("cnt")
    eq([l.split()[0] for l in cl], CNT_NAMES, "%s: counter names/order" % name)
    for l in cl:
        k, v = l.split()
        cnt[k] = int(v)
    eq((nr, nw), (cnt["mem_rd_beats"], cnt["mem_wr_beats"]), "%s: mem trace vs beat counters" % name)
    eq(cnt["err_rsp"], nonok, "%s: err_rsp vs non-OKAY responses" % name)
    eq(cnt["mem_rd_beats"], beats * (cnt["refills"] + cnt["refill_errors"]) + cnt["bypass_rd"], "%s: rd beats identity" % name)
    eq(cnt["mem_wr_beats"], beats * (cnt["writebacks"] + cnt["wb_errors"]) + cnt["bypass_wr"], "%s: wr beats identity" % name)
    check(cnt["rd_hit"] + cnt["rd_miss"] + cnt["wr_hit"] + cnt["wr_miss"] + cnt["bypass_rd"] + cnt["bypass_wr"]
          <= len(reqs), "%s: accepted requests <= REQ records" % name)
    img = lines_of("img")
    addrs = []
    for l in img:
        mt = re.match(r"^(%s) (%s)$" % (HEXRE(16), HEXRE(32)), l)
        if not mt or int(mt.group(1), 16) & 0xF:
            check(False, "%s: bad exp_img line %r" % (name, l))
            break
        addrs.append(int(mt.group(1), 16))
    check(addrs == sorted(set(addrs)), "%s: exp_img sorted and unique" % name)
    cm = lines_of("cmo")
    eq(len(cm), len(cmos), "%s: one exp_cmo line per CMO" % name)
    for l, seq in zip(cm, cmos):
        mt = re.match(r"^(\d+) (\d+) (\d+) ([01])$", l)
        if not mt or int(mt.group(1)) != seq:
            check(False, "%s: bad exp_cmo line %r" % (name, l))
            break
    return cnt


def test_generator_smoke():
    with tempfile.TemporaryDirectory() as d:
        for gi, geo in enumerate(GEOS):
            for sc in SCEN:
                name = "g%d_%s" % (gi, sc)
                cnt = None
                for rep in (0, 1):
                    gs.generate(name, 11 + gi, geo[0], geo[1], geo[2], geo[3], geo[4], sc, 600,
                                os.path.join(d, "r%d" % rep))
                cnt = validate_files(os.path.join(d, "r0"), name, geo, sc)
                for k in ("stim", "exp_rsp", "exp_mem", "exp_cnt", "exp_img", "exp_cmo"):
                    f = "%s_%s.txt" % (k, name)
                    check(filecmp.cmp(os.path.join(d, "r0", f), os.path.join(d, "r1", f), shallow=False),
                          "%s: %s not deterministic" % (name, f))
                if gi == 0 and cnt:
                    for c in COVER.get(sc, []):
                        check(cnt[c] > 0, "scenario %s (geometry 0) never moved counter %s" % (sc, c))
        # --avoid-ambiguous variant and a different seed
        gs.generate("amb", 5, 8, 4, 32, 48, 1, "random", 1500, d, avoid_ambiguous=True)
        validate_files(d, "amb", GEOS[2], "random")
        for l in open(os.path.join(d, "stim_amb.txt")):
            t = l.split()
            if t and t[0] == "CMO" and t[3] == "0" and int(t[5], 16) == 0:
                check(int(t[4], 16) % 32 == 0, "avoid-ambiguous: size-0 CMO with unaligned start")
            if t and t[0] == "REQ":
                check(int(t[2], 16) in (0, 1, 2), "avoid-ambiguous: illegal opcode other than 0")
                if int(t[2], 16) == 1:
                    check(int(t[8], 16) == 0, "avoid-ambiguous: read with non-zero data field")
        # the CLI entry point works end to end
        import contextlib
        import io
        with contextlib.redirect_stdout(io.StringIO()):
            rc = gs.main(["--name", "cli", "--seed", "3", "--sets", "4", "--ways", "2", "--line", "64", "--paddr", "32",
                          "--repl", "0", "--scenario", "merr", "--count", "300", "--outdir", d])
        eq(rc, 0, "gen_stimulus.main returns 0")
        with contextlib.redirect_stdout(io.StringIO()):
            rc = sfm.main(["--stim", os.path.join(d, "stim_cli.txt"), "--outdir", os.path.join(d, "again"),
                           "--sets", "4", "--ways", "2", "--line", "64", "--paddr", "32", "--repl", "0"])
        eq(rc, 0, "sf_cache_model.main returns 0")
        for k in ("rsp", "mem", "cnt", "img", "cmo"):
            check(filecmp.cmp(os.path.join(d, "exp_%s_cli.txt" % k), os.path.join(d, "again", "exp_%s_cli.txt" % k),
                              shallow=False), "model CLI reproduces exp_%s" % k)


def test_generator_fuzz():
    """Many short random (geometry, scenario, seed) runs incl. odd geometries; generator + model must not raise
    (catches e.g. 64-bit overflow of top-of-memory addresses) and the invariants must hold after every record."""
    geos = GEOS + [(2, 16, 16, 32, 1), (16, 2, 256, 64, 0), (2, 2, 16, 64, 1), (2, 4, 64, 33, 0), (64, 1, 128, 63, 1)]
    rng = random.Random(99)
    with tempfile.TemporaryDirectory() as d:
        for i in range(60):
            geo, sc = rng.choice(geos), rng.choice(SCEN)
            seed, cnt, amb = rng.randrange(10 ** 6), rng.choice([50, 200, 800]), rng.random() < 0.2
            try:
                gs.generate("fz", seed, *geo[:4], geo[4], sc, cnt, d, avoid_ambiguous=amb)
                sfm.run_stimulus(os.path.join(d, "stim_fz.txt"), d, "fz", *geo, check=True)
                check(True, "")
            except Exception:
                traceback.print_exc()
                check(False, "fuzz run failed: geo=%r scenario=%s seed=%d count=%d avoid=%r" % (geo, sc, seed, cnt, amb))


TESTS = [test_pattern, test_constructor_rejects, test_plru_4way, test_plru_other_sizes, test_plru_oracle,
         test_round_robin, test_dirty_eviction_trace, test_write_miss_partial_merge, test_inval_discards_dirty,
         test_clean_keeps_valid, test_merr_refill, test_merr_wb, test_illegal_ordering, test_dma_stale_read,
         test_bypass_and_cfg, test_cmo_ranges, test_file_roundtrip, test_merr_status_zero_rejected,
         test_coherent_runs, test_random_invariants, test_generator_smoke, test_generator_fuzz]


def main():
    for t in TESTS:
        n0 = len(FAILS)
        try:
            t()
        except Exception:
            traceback.print_exc()
            FAILS.append("%s raised" % t.__name__)
        print("%-32s %s" % (t.__name__, "ok" if len(FAILS) == n0 else "FAILED"))
    print("\n%d checks, %d failure(s)" % (NCHECK[0], len(FAILS)))
    if FAILS:
        for f in FAILS[:30]:
            print(" - " + f)
        return 1
    print("SELFTEST PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
