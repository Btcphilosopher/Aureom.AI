# SilicaFlux CacheForge (Project 106) — configurable last-level cache

**Primary RTL: `rtl/cache/sf_llc_cache.sv`** · Aureom.AI | SilicaFlux Cloud Semiconductor Systems

A synthesizable, set-associative, write-back / write-allocate **last-level cache controller** for SilicaFlux cloud processors.  Both interfaces are **Albion Link Protocol v1**
(AlbionCore 0.1.0: 64-bit address, 128-bit data, 16-byte byte enables, 8-bit tag).  Every RAM is an instance of the repository's **SRAMMacroBridge wrapper** (GENERIC / FPGA / open-PDK macro,
SECDED ECC).  Initial configuration (all of it parameters): **32 KiB, 64-byte lines, 4 ways, 64-bit physical addresses, one outstanding miss**; plus an **MSHR extension** (`NUM_MSHR` 2–8).

> **Delivered as an archive — nothing was committed to GitHub.**
> **Status:** RTL simulation (Verilator), mutation testing, formal proofs of selected blocks (Yosys / SymbiYosys / z3) and technology-independent Yosys statistics.  **No FPGA, no silicon, no timing / area / power claim, no SRAM access-time claim.**
> **Not hardware-coherent** (there is no CoherenceDirectory in the repository): DMA visibility is software-managed (CLEAN / INVAL / CLEAN_INVAL, non-cacheable window).
> **Not connected to the SFB2 DataFabric (P03)**: the SFB2 ↔ ALP bridge is a missing dependency of the repository (docs/00 §3).

## Results at delivery (all generated; `reports/SUMMARY.md`)

* **Model-vs-RTL regression: 504 / 504 runs pass** (954126 scoreboard checks) over 14 configurations (8 blocking, 6 MSHR), 12 scenarios, 3 seeds, 3 stress profiles; ALP link checkers on both links in every run.
* **Directed ECC / error-policy / reset tests: 9 / 9 variants pass** (RAM latency 1–4, memory link 1–8, MSHR 1–4).
* **Mutation campaigns:** blocking 49 / 51; MSHR 19 / 19; ECC 11 / 12 killed (survivors explained in docs/06).
* **Formal:** 17 tasks proved unboundedly (address slicing, replacement policy, MSHR table); 4 bounded passes (memory port, whole cache); the address and replacement proofs were shown to fail against deliberately broken copies (docs/06 §5); the MSHR, memory-port and whole-cache harnesses were not separately sensitivity-tested.
* **Measured, with a 1-cycle memory and no back-pressure:** read hit 6 cycles, full-beat write hit 5, clean-victim miss 16, dirty miss up to ~37 (docs/03).
* **Synthesis (generic Yosys, RAMs black-boxed):** default configuration 31335 logic cells, 3813 flip-flops; RAMs: 4 × 128×60 tag + 4 × 512×144 data (325 632 bits).  No SRAM timing / area / power claimed.

## Read first

| Document | Content |
|---|---|
| `docs/00_repository_audit.md` | which dependencies exist and are verified; what is missing (SFB2 bridge, CoherenceDirectory) |
| `docs/01_overview.md` | decisions and a **traceability matrix** from every section of the brief to code and evidence |
| `docs/02_functional_spec.md` | the normative, timing-independent behaviour (what the model and the RTL both implement) |
| `docs/03_microarchitecture.md` | block diagram, FSM, measured cycle counts, MSHR design |
| `docs/04_ecc_and_errors.md` | what is protected and what happens on every error class |
| `docs/05_integration.md` | ports, parameters, DMA policy and software sequences, DataFabric status, bring-up |
| `docs/06_verification.md` | strategy, results, mutation campaigns, formal results and their limits |
| `docs/07_physical_design.md` | measured synthesis statistics and memory organisation; what was **not** measured |
| `docs/08_limitations.md` | everything this package does not do or prove |

## Layout

```
rtl/cache/        sf_llc_cache.sv (top) · sf_cache_tag_array · sf_cache_data_array · sf_cache_replacement · sf_cache_mshr · sf_cache_refill ·
                  sf_cache_writeback · sf_cache_perf · sf_cache_memport · sf_cache_addr · sf_cache_pkg          (.sv = SystemVerilog; the repository's .sf files are also plain SV)
rtl/files.f       compile order     rtl/incdirs.f   include directories
third_party/      AlbionCore (pkg, skid, fifo; link checkers for tests) and SRAMMacroBridge P79 — vendored UNMODIFIED, SHA256SUMS, byte-compared with the repository archives
tb/               tb_sf_llc_cache.sv (model-driven regression bench) · tb_sf_llc_ecc.sv (directed ECC / reset bench) · sf_tb_alp_mem.sv (ALP memory target model)
model/            independent Python reference model + stimulus generator + self-test (written from docs/02 only)
formal/           fv_cache_addr · fv_replacement · fv_mshr · fv_memport · fv_llc  (+ .sby)
synth/            black-box RAM stub for the statistics flow
configs/          six parameter sets (JSON)   scripts/check_config.py validates them (rules identical to the RTL's elaboration checks)
scripts/          build_tb.sh · run_regression.py · run_ecc_tests.sh · mutate.py · run_synth.py · check_*.py · make_report.py · make_package.py · make_shims.sh
reports/          every result file;  reports/stage1_frozen/ = blocking-cache evidence recorded before the MSHR work
docs/             as above
Makefile          make help
```

## Quick start

```bash
# tools used for the reported results: Verilator 5.49 (pip wheel verilator 5.48.0), Yosys 0.71 (pip yowasp-yosys), SymbiYosys, z3 (pip z3-solver), Python 3.13
pip install verilator yowasp-yosys z3-solver
scripts/make_shims.sh ./shims && export PATH=$PWD/shims:$PATH      # only for the YoWASP wheels (formal / synth)

make check            # vendored files, configuration checker == RTL elaboration (29 cases)
make regress-quick    # ~1 minute
make regress          # 8 blocking + 6 MSHR configurations x 12 scenarios x 3 seeds
make ecc              # directed ECC / error-policy / reset tests, 9 variants
make formal           # unbounded: address, replacement, MSHR table; bounded: memory port, whole cache
make synth            # reports/synth.md
```

Instantiation (default configuration):

```systemverilog
sf_llc_cache #(.CACHE_BYTES(32768), .LINE_BYTES(64), .WAYS(4), .PADDR_W(64), .NUM_MSHR(1)) u_llc (
  .clk_i, .rst_ni,
  .req_valid_i, .req_ready_o, .req_i,   .rsp_valid_o, .rsp_ready_i, .rsp_o,       // upstream  ALP v1 target
  .mreq_valid_o, .mreq_ready_i, .mreq_o, .mrsp_valid_i, .mrsp_ready_o, .mrsp_i,   // downstream ALP v1 initiator
  .cmo_valid_i, .cmo_ready_o, .cmo_op_i, .cmo_all_i, .cmo_addr_i, .cmo_size_i, .cmo_busy_o, .cmo_done_o, .cmo_lines_o, .cmo_err_o,
  .cfg_en_i(1'b1), .cfg_nc_en_i(1'b0), .cfg_nc_base_i('0), .cfg_nc_limit_i('0), .cfg_wb_dom_i(8'h01), .cfg_wb_attr_i(8'h04),
  .init_done_o, .busy_o, .err_evt_o, .err_sticky_o, .err_clear_i, .err_addr_o, .perf_clear_i, .perf_o, .caps_o, .proto_err_o);
```

## Dependencies on the existing repository (docs/00)

| Dependency | Use | Verified? |
|---|---|---|
| AlbionCore 0.1.0 (ALP v1) | both interfaces; link checkers in every simulation and formal run | its own report: 14 sims, 19 formal jobs, 67/67 mutants; here: checkers ran on both links without a false alarm and killed protocol mutants |
| SRAMMacroBridge P79 | every RAM, SECDED ECC | its own report (sims, ECC golden-model vectors, 20/23 mutants); **ASIC / FPGA paths not exercised here** |
| MemoryCore (ControlCore cache) | DMA-visibility vocabulary only | — |
| DataFabric P03 (SFB2), Meridian P83 | **not connected** (different protocols; no bridge exists) | — |
| CoherenceDirectory | **does not exist** | — |

## What was found along the way (kept, not hidden)

* The independent model and the RTL agreed on the **first** full run; that was treated as a warning, not a result — hence the mutation campaigns, which found real gaps in the *tests* (T7b, the CMO-without-barrier mode, the legal-initiator tag allocation) and in the *RTL robustness* (MSHR allocation guard, elaboration checks that `-Wno-fatal` could mask, constructs Yosys rejects).
* A genuine RTL bug was found by the directed ECC bench: a freshly refilled line that is itself uncorrectable re-allocated an MSHR entry already owned by the request.
* Test-bench races (a driver resuming after the DUT's non-blocking updates at the same edge) were found and removed by driving at the falling edge and monitoring at the rising edge.

See `docs/08_limitations.md` before relying on any of this.
