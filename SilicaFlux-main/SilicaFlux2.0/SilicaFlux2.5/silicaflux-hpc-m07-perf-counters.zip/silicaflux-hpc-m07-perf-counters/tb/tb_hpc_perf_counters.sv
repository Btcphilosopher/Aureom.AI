// =============================================================================
// SilicaFlux-HPC Module 07 :: tb_hpc_perf_counters -- unit testbench of the counter bank
//
// Two independent checks:
//   1. self-checking directed tests (explicit expected values, below);
//   2. a per-cycle trace (+trace=<file>) of every input, every output and every
//      live counter value, replayed by the software reference model
//      model/perf_ref.py, which must agree in EVERY cycle (scripts/run_unit.py).
// Directed tests: reset values, single events, simultaneous multi-valued
// events, long increments, enable/disable, freeze (software, hardware,
// freeze-on-overflow), snapshot consistency and SAMPLE losslessness, overflow
// (wrap and saturate, OVF priority, interrupt), reset during activity,
// back-to-back reads, coherent 64-bit reads while a carry crosses the 32-bit
// boundary, bus errors, error-source flags.  Then a constrained-random phase
// (+cycles=<n>, +seed=<s>) with random events, freezes, snapshots, register
// traffic (valid and invalid), preloads near overflow and asynchronous resets.
// Result line: "TB_PERF RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "hpc_perf_defs.svh"

module tb_hpc_perf_counters #(
  parameter int          NUM_CNT    = `HPC_PERF_NUM_CNT,
  parameter int          CNT_W      = 64,
  parameter int          INC_W      = 32,
  parameter int          NUM_ERR    = `HPC_PERF_NUM_ERR,
  parameter bit          SNAP_EN    = 1'b1,
  parameter bit          PRELOAD_EN = 1'b1,
  parameter bit          EN_RESET   = 1'b1,
  parameter logic [31:0] SAT_RESET  = 32'h0,
  parameter int          PLATFORM   = 0,
  parameter logic [31:0] TILE_CFG   = 32'hA5A5_0F0F,
  parameter int          CLK_KHZ    = 100000,
  parameter logic [31:0] BUILD_ID   = 32'h0700_2026
);
  localparam int NC = NUM_CNT;
  localparam logic [63:0] MAXV = (CNT_W == 64) ? 64'hFFFF_FFFF_FFFF_FFFF : ((64'd1 << CNT_W) - 64'd1);
  localparam logic [63:0] IMAX = (64'd1 << INC_W) - 64'd1;
  localparam logic [31:0] NMASK = (NC == 32) ? 32'hFFFF_FFFF : ((32'd1 << NC) - 32'd1);
  localparam logic [31:0] EMASK = (NUM_ERR == 32) ? 32'hFFFF_FFFF : ((32'd1 << NUM_ERR) - 32'd1);

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic                   rb_sel = 1'b0, rb_we = 1'b0;
  logic [11:0]            rb_addr = '0;
  logic [31:0]            rb_wdata = '0;
  logic [31:0]            rb_rdata;
  logic                   rb_err;
  logic [NC*INC_W-1:0]    inc = '0;
  logic                   freeze = 1'b0, snap = 1'b0;
  logic [NUM_ERR-1:0]     errs = '0;
  logic                   irq, frozen;
  logic [NC*CNT_W-1:0]    cnt;

  hpc_perf_counters #(
    .NUM_CNT(NUM_CNT), .CNT_W(CNT_W), .INC_W(INC_W), .NUM_ERR(NUM_ERR), .SNAP_EN(SNAP_EN), .PRELOAD_EN(PRELOAD_EN),
    .EN_RESET(EN_RESET), .SAT_RESET(SAT_RESET), .PLATFORM(PLATFORM), .TILE_CFG(TILE_CFG), .CLK_KHZ(CLK_KHZ),
    .BUILD_ID(BUILD_ID)
  ) dut (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .inc_i(inc), .freeze_i(freeze), .snap_i(snap), .err_i(errs), .irq_o(irq), .frozen_o(frozen), .cnt_o(cnt));

  // ============================================================ bookkeeping
  int unsigned cyc = 0, errors = 0, checks = 0;
  string       cur_test = "init";
  always @(posedge clk) cyc <= cyc + 1;
  task automatic chk(input bit ok, input string m);
    checks++;
    if (!ok) begin
      errors++;
      if (errors <= 30) $display("TB_PERF ERROR cyc=%0d test=%s: %s", cyc, cur_test, m);
    end
  endtask
  function automatic logic [63:0] c(input int i);   // live value now
    return 64'(cnt[i*CNT_W +: CNT_W]);
  endfunction

  // ============================================================ per-cycle trace for model/perf_ref.py
  int          tf = 0;
  logic [63:0] cnt_pre [0:NC-1];                     // counter values at the START of the last posedge cycle
  logic        t_rst, t_sel, t_we, t_err, t_irq, t_frz, tr_freeze, tr_snap;
  logic [11:0] t_addr;
  logic [31:0] t_wdata, t_rdata;
  logic [NUM_ERR-1:0] t_errs;
  logic [NC*INC_W-1:0] t_inc;
  bit          t_pending = 1'b0;
  always @(posedge clk) begin
    t_rst = rst_n; t_sel = rb_sel; t_we = rb_we; t_addr = rb_addr; t_wdata = rb_wdata;
    t_rdata = rb_rdata; t_err = rb_err; t_irq = irq; t_frz = frozen; tr_freeze = freeze; tr_snap = snap;
    t_errs = errs; t_inc = inc;
    for (int i = 0; i < NC; i++) cnt_pre[i] = c(i);
    t_pending = 1'b1;
  end
  always @(negedge clk) if (tf != 0 && t_pending) begin
    $fwrite(tf, "%0d %0h %0h %0h %03h %08h %08h %0h %0h %0h %0h %0h %0h", cyc - 1, t_rst, t_sel, t_we, t_addr, t_wdata,
            t_rdata, t_err, t_irq, t_frz, tr_freeze, tr_snap, t_errs);
    for (int i = 0; i < NC; i++) $fwrite(tf, " %0h", t_inc[i*INC_W +: INC_W]);
    for (int i = 0; i < NC; i++) $fwrite(tf, " %0h", c(i));
    $fwrite(tf, "\n");
    t_pending = 1'b0;
  end

  // ============================================================ register-bus BFM (tasks start/end just after a negedge)
  logic [63:0] bus_cnt_pre [0:NC-1];                 // counters at the start of the last strobe cycle
  task automatic bus(input bit we, input logic [11:0] a, input logic [31:0] d, output logic [31:0] q, output bit e);
    rb_sel <= 1'b1; rb_we <= we; rb_addr <= a; rb_wdata <= d;
    @(posedge clk);
    q = rb_rdata; e = rb_err;
    for (int i = 0; i < NC; i++) bus_cnt_pre[i] = c(i);
    @(negedge clk);
    rb_sel <= 1'b0; rb_we <= 1'b0;
  endtask
  task automatic wr(input logic [11:0] a, input logic [31:0] d);
    logic [31:0] q; bit e;
    bus(1'b1, a, d, q, e);
    chk(!e, $sformatf("write 0x%03h refused", a));
  endtask
  task automatic rd(input logic [11:0] a, output logic [31:0] q);
    bit e;
    bus(1'b0, a, 32'd0, q, e);
    chk(!e, $sformatf("read 0x%03h refused", a));
  endtask
  task automatic expect_rd(input logic [11:0] a, input logic [31:0] exp, input string what);
    logic [31:0] q;
    rd(a, q);
    chk(q == exp, $sformatf("%s @0x%03h = 0x%08h, expected 0x%08h", what, a, q, exp));
  endtask
  task automatic expect_err(input bit we, input logic [11:0] a, input logic [31:0] d, input string what);
    logic [31:0] q; bit e;
    bus(we, a, d, q, e);
    chk(e, $sformatf("%s @0x%03h not refused", what, a));
  endtask
  task automatic rd_live(input int i, output logic [63:0] v);   // coherent pair: LO then HI, back to back
    logic [31:0] lo, hi;
    rd(12'(`HPC_PR_LIVE_BASE + 8*i), lo);
    rd(12'(`HPC_PR_LIVE_BASE + 8*i + 4), hi);
    v = {hi, lo};
  endtask
  task automatic rd_snap(input int i, output logic [63:0] v);
    logic [31:0] lo, hi;
    rd(12'(`HPC_PR_SNAP_BASE + 8*i), lo);
    rd(12'(`HPC_PR_SNAP_BASE + 8*i + 4), hi);
    v = {hi, lo};
  endtask
  task automatic idle(input int n);
    repeat (n) @(negedge clk);
  endtask
  task automatic ctrl(input bit en, input bit frz, input bit fov, input bit clr, input bit snp, input bit smp);
    wr(`HPC_PR_CTRL, 32'(en) << `HPC_CTRL_ENABLE | 32'(frz) << `HPC_CTRL_FREEZE | 32'(fov) << `HPC_CTRL_FREEZE_ON_OVF |
                     32'(clr) << `HPC_CTRL_CLEAR | 32'(snp) << `HPC_CTRL_SNAPSHOT | 32'(smp) << `HPC_CTRL_SAMPLE);
  endtask
  task automatic clear_all();
    ctrl(1, 0, 0, 1, 0, 0);
    wr(`HPC_PR_OVF, 32'hFFFF_FFFF);
  endtask
  task automatic set_inc(input int i, input logic [63:0] v);
    inc[i*INC_W +: INC_W] <= INC_W'(v);
  endtask
  task automatic preload(input int i, input logic [63:0] v);
    wr(`HPC_PR_PRE_LO, v[31:0]); wr(`HPC_PR_PRE_HI, v[63:32]); wr(`HPC_PR_PRE_LOAD, 32'd1 << i);
  endtask
  // bring counter i to MAXV - gap (preload, or by counting when PRELOAD_EN = 0); other increments 0
  task automatic near_max(input int i, input logic [63:0] gap);
    if (PRELOAD_EN) preload(i, MAXV - gap);
    else begin
      wr(`HPC_PR_CLR, 32'd1 << i);
      while (MAXV - c(i) > IMAX + gap) begin set_inc(i, IMAX); @(negedge clk); end
      set_inc(i, MAXV - gap - c(i)); @(negedge clk);
    end
    inc <= '0;
    @(negedge clk);
  endtask
  function automatic logic [63:0] trunc(input logic [63:0] v);
    return v & MAXV;
  endfunction

  // ============================================================ directed tests
  task automatic t_reset_values();
    logic [31:0] q;
    cur_test = "reset_values";
    expect_rd(`HPC_PR_ID, `HPC_PERF_ID, "ID");
    expect_rd(`HPC_PR_VERSION, `HPC_PERF_VERSION, "VERSION");
    expect_rd(`HPC_PR_INFO, {1'(PRELOAD_EN), 1'(SNAP_EN), 2'(PLATFORM), 6'(NUM_ERR), 6'(INC_W), 8'(CNT_W), 8'(NC)}, "INFO");
    expect_rd(`HPC_PR_TILECFG, TILE_CFG, "TILECFG");
    expect_rd(`HPC_PR_CLK_KHZ, 32'(CLK_KHZ), "CLK_KHZ");
    expect_rd(`HPC_PR_BUILD_ID, BUILD_ID, "BUILD_ID");
    expect_rd(`HPC_PR_CTRL, 32'(EN_RESET), "CTRL");
    expect_rd(`HPC_PR_CNT_EN, NMASK, "CNT_EN");
    expect_rd(`HPC_PR_SAT, SAT_RESET & NMASK, "SAT");
    expect_rd(`HPC_PR_OVF, 0, "OVF");
    expect_rd(`HPC_PR_OVF_IE, 0, "OVF_IE");
    expect_rd(`HPC_PR_ERR_SRC, 0, "ERR_SRC");
    rd(`HPC_PR_STATUS, q);
    chk(q[31:16] == 0 && q[`HPC_ST_SNAP_VALID] == 0 && q[`HPC_ST_OVF_ANY] == 0, "STATUS after reset");
    if (SNAP_EN) for (int i = 0; i < NC; i++) begin
      logic [63:0] v;
      rd_snap(i, v);
      chk(v == 0, $sformatf("SNAP[%0d] after reset = %0h", i, v));
    end
    if (!EN_RESET) for (int i = 0; i < NC; i++) chk(c(i) == 0, "EN_RESET=0: counted before ENABLE");
  endtask

  task automatic t_single_event();
    cur_test = "single_event";
    ctrl(1, 0, 0, 0, 0, 0);
    wr(`HPC_PR_SAT, 0);
    clear_all();
    for (int i = 0; i < NC; i++) begin
      logic [63:0] v;
      set_inc(i, 1);
      @(negedge clk);
      set_inc(i, 0);
      @(negedge clk);
      for (int j = 0; j < NC; j++) chk(c(j) == ((j <= i) ? 64'd1 : 64'd0), $sformatf("after event on %0d: cnt[%0d] = %0d", i, j, c(j)));
      rd_live(i, v);
      chk(v == 1, $sformatf("LIVE[%0d] = %0d, expected 1", i, v));
    end
  endtask

  task automatic t_multi_event();
    logic [63:0] exp [0:NC-1];
    cur_test = "multi_event";
    clear_all();
    for (int i = 0; i < NC; i++) exp[i] = 0;
    // three cycles: every counter receives a different multi-valued increment in the same cycle
    for (int k = 0; k < 3; k++) begin
      for (int i = 0; i < NC; i++) begin
        logic [63:0] v;
        v = (k == 0) ? IMAX : ((k == 1) ? 64'(i + 1) : (IMAX >> 1));
        set_inc(i, v);
        exp[i] = trunc(exp[i] + v);
      end
      @(negedge clk);
    end
    inc <= '0;
    @(negedge clk);
    for (int i = 0; i < NC; i++) chk(c(i) == exp[i], $sformatf("cnt[%0d] = %0h, expected %0h", i, c(i), exp[i]));
  endtask

  task automatic t_increments();
    logic [63:0] exp [0:NC-1];
    int unsigned r;
    cur_test = "increments";
    clear_all();
    for (int i = 0; i < NC; i++) exp[i] = 0;
    r = 32'h1234_5678;
    for (int k = 0; k < 500; k++) begin
      for (int i = 0; i < NC; i++) begin
        logic [63:0] v;
        r = r ^ (r << 13); r = r ^ (r >> 17); r = r ^ (r << 5);
        v = 64'(r) & ((INC_W >= 4) ? 64'hF : IMAX);
        set_inc(i, v);
        exp[i] = trunc(exp[i] + v);
      end
      @(negedge clk);
    end
    inc <= '0;
    @(negedge clk);
    for (int i = 0; i < NC; i++) begin
      logic [63:0] v;
      rd_live(i, v);
      chk(v == exp[i], $sformatf("cnt[%0d] = %0d, expected %0d", i, v, exp[i]));
    end
  endtask

  task automatic t_enable();
    cur_test = "enable_disable";
    clear_all();
    for (int i = 0; i < NC; i++) set_inc(i, 1);
    ctrl(0, 0, 0, 0, 0, 0);                  // effective from the next cycle; this write cycle still counted
    idle(10);
    for (int i = 0; i < NC; i++) chk(c(i) == 1, $sformatf("ENABLE=0: cnt[%0d] = %0d, expected 1", i, c(i)));
    ctrl(1, 0, 0, 0, 0, 0);                  // write cycle not counted (disabled), counting from the next
    idle(4);
    for (int i = 0; i < NC; i++) chk(c(i) == 5, $sformatf("re-enable: cnt[%0d] = %0d, expected 5", i, c(i)));
    wr(`HPC_PR_CNT_EN, 32'h5555_5555 & NMASK);   // counts in its own cycle with the old mask
    idle(4);
    for (int i = 0; i < NC; i++)
      chk(c(i) == ((i % 2 == 0) ? 64'd10 : 64'd6), $sformatf("CNT_EN mask: cnt[%0d] = %0d", i, c(i)));
    expect_rd(`HPC_PR_CNT_EN, 32'h5555_5555 & NMASK, "CNT_EN");
    wr(`HPC_PR_CNT_EN, NMASK);
    inc <= '0;
    @(negedge clk);
  endtask

  task automatic t_freeze();
    logic [31:0] q;
    logic [63:0] base;
    cur_test = "freeze";
    clear_all();
    set_inc(0, 1);
    ctrl(1, 1, 0, 0, 0, 0);                  // software freeze
    idle(5);
    chk(c(0) == 1, $sformatf("FREEZE: cnt0 = %0d, expected 1", c(0)));
    rd(`HPC_PR_STATUS, q);
    chk(q[`HPC_ST_FROZEN] == 1'b1, "STATUS.FROZEN under FREEZE");
    ctrl(1, 0, 0, 0, 0, 0);
    idle(3);
    chk(c(0) == 4, $sformatf("unfreeze: cnt0 = %0d, expected 4", c(0)));
    // hardware freeze: effective in the same cycle
    base = c(0);
    freeze <= 1'b1;
    idle(6);
    rd(`HPC_PR_STATUS, q);
    chk(q[`HPC_ST_HW_FREEZE] && q[`HPC_ST_FROZEN], "STATUS.HW_FREEZE");
    freeze <= 1'b0;
    chk(c(0) == base, $sformatf("freeze_i: cnt0 = %0d, expected %0d", c(0), base));
    idle(2);
    chk(c(0) == base + 2, "freeze_i release");
    // freeze on overflow: counter 1 overflows, everything stops from the next cycle
    set_inc(0, 0);
    if (NC > 1) begin
      wr(`HPC_PR_SAT, 0);
      ctrl(1, 0, 1, 0, 0, 0);
      if (PRELOAD_EN) begin
        preload(1, MAXV - 2);
        set_inc(0, 1); set_inc(1, 1);
        idle(8);
        chk(c(1) == 0, $sformatf("FREEZE_ON_OVF: cnt1 = %0h, expected 0 (wrapped, then frozen)", c(1)));
        rd(`HPC_PR_STATUS, q);
        chk(q[`HPC_ST_OVF_FREEZE] && q[`HPC_ST_FROZEN] && q[`HPC_ST_OVF_ANY], "STATUS.OVF_FREEZE");
        base = c(0);
        idle(3);
        chk(c(0) == base, "FREEZE_ON_OVF: other counters frozen too");
        wr(`HPC_PR_OVF, 32'd2);              // clear the overflow: counting resumes
        idle(2);
        chk(c(0) == base + 2, "FREEZE_ON_OVF released by OVF W1C");
      end
      inc <= '0;
      ctrl(1, 0, 0, 0, 0, 0);
    end
  endtask

  task automatic t_snapshot();
    logic [63:0] v, sum0, tot0;
    logic [63:0] exp_s [0:NC-1];
    logic [31:0] q, seq0;
    cur_test = "snapshot";
    if (!SNAP_EN) begin
      expect_err(1'b1, `HPC_PR_CTRL, 32'd1 | 32'd1 << `HPC_CTRL_SNAPSHOT, "SNAPSHOT without SNAP_EN");
      expect_err(1'b0, `HPC_PR_SNAP_BASE, 0, "snapshot window without SNAP_EN");
      // a refused write has no effect at all: FREEZE in the same refused write must not be applied
      expect_err(1'b1, `HPC_PR_CTRL, 32'd1 | 32'd1 << `HPC_CTRL_FREEZE | 32'd1 << `HPC_CTRL_SAMPLE, "SAMPLE without SNAP_EN");
      expect_rd(`HPC_PR_CTRL, 32'd1, "CTRL unchanged by a refused write");
    end else begin
    clear_all();
    for (int i = 0; i < NC; i++) set_inc(i, 64'(i % 3 + 1));
    idle(7);
    rd(`HPC_PR_STATUS, q); seq0 = 32'(q[31:16]);
    ctrl(1, 0, 0, 0, 1, 0);                  // snapshot: state at the start of the write cycle
    for (int i = 0; i < NC; i++) exp_s[i] = bus_cnt_pre[i];
    idle(5);                                  // counters keep counting; the snapshot must not move
    for (int i = 0; i < NC; i++) begin
      rd_snap(i, v);
      chk(v == exp_s[i], $sformatf("SNAP[%0d] = %0d, counter at the SNAPSHOT cycle = %0d", i, v, exp_s[i]));
      chk(c(i) > v, "live counter moved on after the snapshot");
    end
    rd(`HPC_PR_STATUS, q);
    chk(32'(q[31:16]) == seq0 + 1 && q[`HPC_ST_SNAP_VALID], "SNAP_SEQ / SNAP_VALID");
    // mutual coherence: all counters advanced in lock step, so every snapshot value is (i%3+1)*k for one k
    begin
      logic [63:0] s0, si;
      rd_snap(0, s0);
      for (int i = 1; i < NC; i++) begin
        rd_snap(i, si);
        chk(si * 1 == s0 * 64'(i % 3 + 1), $sformatf("snapshot coherence: SNAP[%0d] = %0d vs SNAP[0] = %0d", i, si, s0));
      end
    end
    // hardware snapshot trigger
    snap <= 1'b1; @(negedge clk); snap <= 1'b0;
    rd(`HPC_PR_STATUS, q);
    chk(32'(q[31:16]) == seq0 + 2, "snap_i increments SNAP_SEQ");
    // SAMPLE: lossless interval sampling.  Sum of intervals == total (total measured by a never-sampled shadow)
    inc <= '0;
    clear_all();
    set_inc(0, 1);
    sum0 = 0;
    for (int k = 0; k < 5; k++) begin
      idle(k + 3);
      ctrl(1, 0, 0, 0, 0, 1);
      rd_snap(0, v);
      sum0 += v;
    end
    set_inc(0, 0);
    @(negedge clk);
    tot0 = sum0 + c(0);
    // cycles with inc=1: the idles (3..7), the 5 SAMPLE write cycles and the 5 rd_snap pairs
    chk(tot0 == 64'((3+4+5+6+7) + 5*1 + 5*2), $sformatf("SAMPLE lost events: intervals %0d + rest %0d = %0d", sum0, c(0), tot0));
    inc <= '0;
    end
  endtask

  task automatic t_overflow();
    logic [31:0] q;
    logic [63:0] v;
    cur_test = "overflow";
    clear_all();
    wr(`HPC_PR_SAT, 0);
    wr(`HPC_PR_OVF_IE, 32'd1);
    // wrap mode: counter 0 crosses 2^CNT_W
    near_max(0, 5);
    v = c(0);
    set_inc(0, 3); @(negedge clk);           // v + 3
    set_inc(0, 9); @(negedge clk);           // v + 12 (wraps when v > MAXV - 12)
    inc <= '0; @(negedge clk);
    chk(c(0) == trunc(v + 12), $sformatf("wrap: cnt0 = %0h, expected %0h", c(0), trunc(v + 12)));
    rd(`HPC_PR_OVF, q);
    chk(q[0] == ({1'b0, v} + 65'd12 > {1'b0, MAXV}), "OVF[0] after wrap");
    chk(irq == ({1'b0, v} + 65'd12 > {1'b0, MAXV}), "irq_o after wrap");
    // W1C clears, but a new overflow in the same cycle wins
    if (PRELOAD_EN && NC > 1) begin
      preload(1, MAXV);
      set_inc(1, 1);
      wr(`HPC_PR_OVF, 32'd2);                // same cycle: counter 1 wraps again -> stays set
      set_inc(1, 0);
      rd(`HPC_PR_OVF, q);
      chk(q[1] == 1'b1, "OVF set wins over W1C in the same cycle");
      wr(`HPC_PR_OVF, 32'd2);
      rd(`HPC_PR_OVF, q);
      chk(q[1] == 1'b0, "OVF W1C");
    end
    wr(`HPC_PR_OVF, 32'hFFFF_FFFF);
    @(negedge clk);
    chk(irq == 1'b0, "irq_o cleared");
    // saturate mode
    wr(`HPC_PR_SAT, 32'd1);
    near_max(0, 2);
    set_inc(0, IMAX); idle(3); inc <= '0; @(negedge clk);
    chk(c(0) == MAXV, $sformatf("saturate: cnt0 = %0h, expected all ones", c(0)));
    rd(`HPC_PR_OVF, q);
    chk(q[0] == 1'b1, "OVF set in saturate mode (never silent)");
    set_inc(0, 1); idle(2); inc <= '0; @(negedge clk);
    chk(c(0) == MAXV, "saturated counter holds");
    if (SNAP_EN) begin
      ctrl(1, 0, 0, 0, 1, 0);
      expect_rd(`HPC_PR_SNAP_OVF, 32'd1, "SNAP_OVF captures OVF");
    end
    wr(`HPC_PR_SAT, SAT_RESET & NMASK);
    wr(`HPC_PR_OVF_IE, 0);
    clear_all();
  endtask

  task automatic t_reset_mid();
    cur_test = "reset_mid";
    for (int i = 0; i < NC; i++) set_inc(i, 1);
    idle(5);
    if (SNAP_EN) ctrl(1, 1, 1, 0, 1, 0);
    wr(`HPC_PR_ERR_SRC, 0);
    errs <= '1; @(negedge clk); errs <= '0;
    rst_n <= 1'b0;                            // asynchronous assert at a negedge, mid-activity
    #2;
    for (int i = 0; i < NC; i++) chk(c(i) == 0, "counter not cleared by asynchronous reset");
    idle(2);
    rst_n <= 1'b1;
    @(negedge clk);
    inc <= '0;
    expect_rd(`HPC_PR_CTRL, 32'(EN_RESET), "CTRL after reset");
    expect_rd(`HPC_PR_ERR_SRC, 0, "ERR_SRC after reset");
    expect_rd(`HPC_PR_OVF, 0, "OVF after reset");
    if (SNAP_EN) expect_rd(`HPC_PR_SNAP_BASE, 0, "SNAP after reset");
    if (!EN_RESET) ctrl(1, 0, 0, 0, 0, 0);
  endtask

  task automatic t_back_to_back();
    logic [31:0] q [0:7];
    logic [31:0] qt;
    bit e;
    cur_test = "back_to_back";
    clear_all();
    set_inc(0, 1);
    // 8 reads in 8 consecutive cycles (no idle cycle between strobes): LIVE_LO[0] advances by exactly 1 each
    for (int k = 0; k < 8; k++) begin bus(1'b0, 12'(`HPC_PR_LIVE_BASE), 0, qt, e); q[k] = qt; end
    for (int k = 1; k < 8; k++) chk(q[k] == q[k-1] + 1, $sformatf("back-to-back LIVE_LO: %0d then %0d", q[k-1], q[k]));
    // LO, HI, LO, HI of two different counters back to back
    if (NC > 1) begin
      logic [31:0] l0, h0, l1, h1;
      rd(12'(`HPC_PR_LIVE_BASE), l0); rd(12'(`HPC_PR_LIVE_BASE + 4), h0);
      rd(12'(`HPC_PR_LIVE_BASE + 8), l1); rd(12'(`HPC_PR_LIVE_BASE + 12), h1);
      chk(h0 == 0 && h1 == 0, "high words");
      // interleaved pairs: LO0, LO1, HI0 -> HI0 misses the latch (LATCH_MISS), HI1 consumed? no: latch holds counter 1
      wr(`HPC_PR_STATUS, 32'd1 << `HPC_ST_LATCH_MISS);
      rd(12'(`HPC_PR_LIVE_BASE), l0); rd(12'(`HPC_PR_LIVE_BASE + 8), l1); rd(12'(`HPC_PR_LIVE_BASE + 4), h0);
      rd(`HPC_PR_STATUS, qt); q[0] = qt;
      chk(q[0][`HPC_ST_LATCH_MISS] == 1'b1, "LATCH_MISS on interleaved pairs");
      wr(`HPC_PR_STATUS, 32'd1 << `HPC_ST_LATCH_MISS);
      rd(`HPC_PR_STATUS, qt); q[0] = qt;
      chk(q[0][`HPC_ST_LATCH_MISS] == 1'b0, "LATCH_MISS W1C");
    end
    // snapshot reads back to back
    if (SNAP_EN) begin
      ctrl(1, 0, 0, 0, 1, 0);
      for (int k = 0; k < 8; k++) begin bus(1'b0, 12'(`HPC_PR_SNAP_BASE), 0, qt, e); q[k] = qt; end
      for (int k = 1; k < 8; k++) chk(q[k] == q[0], "back-to-back SNAP reads stable");
    end
    inc <= '0;
  endtask

  task automatic t_read_during_activity();
    logic [63:0] v, exp_v, prev;
    int unsigned tears;
    cur_test = "read_during_activity";
    if (CNT_W > 32 && PRELOAD_EN) begin
    clear_all();
    preload(0, 64'h0000_0000_FFFF_FFF0);
    set_inc(0, 1);                           // counter 0 counts every cycle: the carry crosses bit 32
    prev = 0;
    for (int k = 0; k < 24; k++) begin
      logic [31:0] lo, hi;
      rd(12'(`HPC_PR_LIVE_BASE), lo);
      exp_v = bus_cnt_pre[0];                // value in the LO-read cycle
      rd(12'(`HPC_PR_LIVE_BASE + 4), hi);
      v = {hi, lo};
      chk(v == exp_v, $sformatf("latched pair %0h, value at LO read %0h", v, exp_v));
      chk(v > prev, "pairs monotonic");
      prev = v;
    end
    // evidence that latching matters: the naive order HI (live) then LO tears near the carry
    tears = 0;
    preload(0, 64'h0000_0001_FFFF_FFFE);
    for (int k = 0; k < 4; k++) begin
      logic [31:0] lo, hi;
      wr(`HPC_PR_STATUS, 32'd1 << `HPC_ST_LATCH_MISS);
      rd(12'(`HPC_PR_LIVE_BASE + 4), hi);    // no latch -> live high word
      exp_v = bus_cnt_pre[0];
      rd(12'(`HPC_PR_LIVE_BASE), lo);
      if ({hi, lo} != exp_v && {hi, lo} != bus_cnt_pre[0]) tears++;
    end
    $display("TB_PERF INFO naive unlatched HI-then-LO reads across the carry: %0d torn of 4", tears);
    inc <= '0;
    end
  endtask

  task automatic t_bus_errors();
    cur_test = "bus_errors";
    expect_err(1'b1, `HPC_PR_ID, 32'h1, "write to ID");
    expect_err(1'b1, `HPC_PR_INFO, 32'h1, "write to INFO");
    expect_err(1'b1, `HPC_PR_LATCH, 32'h1, "write to LATCH");
    expect_err(1'b0, 12'h018, 0, "unmapped read 0x018");
    expect_err(1'b1, 12'h0FC, 0, "unmapped write 0x0FC");
    expect_err(1'b0, 12'h302, 0, "unmapped read 0x302");
    expect_err(1'b0, 12'(`HPC_PR_LIVE_BASE + 1), 0, "misaligned live read");
    expect_err(1'b1, 12'(`HPC_PR_LIVE_BASE), 0, "write to a live counter");
    if (NC < 32) expect_err(1'b0, 12'(`HPC_PR_LIVE_BASE + 8*NC), 0, "live index >= NUM_CNT");
    if (SNAP_EN) expect_err(1'b1, `HPC_PR_SNAP_OVF, 0, "write to SNAP_OVF");
    if (!PRELOAD_EN) begin
      expect_err(1'b1, `HPC_PR_PRE_LO, 1, "PRE_LO without PRELOAD_EN");
      expect_err(1'b1, `HPC_PR_PRE_LOAD, 1, "PRE_LOAD without PRELOAD_EN");
    end
    expect_rd(`HPC_PR_CLR, 0, "CLR reads 0");
  endtask

  task automatic t_err_src();
    logic [31:0] q;
    cur_test = "err_src";
    wr(`HPC_PR_ERR_SRC, 32'hFFFF_FFFF);
    errs <= NUM_ERR'(32'h5 & EMASK); @(negedge clk); errs <= '0;
    expect_rd(`HPC_PR_ERR_SRC, 32'h5 & EMASK, "ERR_SRC sticky");
    errs <= NUM_ERR'(32'h1 & EMASK);
    wr(`HPC_PR_ERR_SRC, 32'h1);              // set wins over the same-cycle clear
    errs <= '0;
    expect_rd(`HPC_PR_ERR_SRC, 32'h5 & EMASK, "ERR_SRC set wins");
    wr(`HPC_PR_ERR_SRC, 32'hFFFF_FFFF);
    rd(`HPC_PR_ERR_SRC, q);
    chk(q == 0, "ERR_SRC W1C");
  endtask

  // ============================================================ constrained-random phase
  int unsigned rs;
  function automatic int unsigned rnd();
    rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5);
    return rs;
  endfunction
  function automatic logic [63:0] rnd64();
    return {32'(rnd()), 32'(rnd())};
  endfunction
  task automatic random_phase(input int unsigned ncyc);
    int unsigned k;
    cur_test = "random";
    k = 0;
    while (k < ncyc) begin
      int unsigned r, mode;
      logic [31:0] q;
      bit e;
      // events of this cycle
      mode = rnd() % 16;
      for (int i = 0; i < NC; i++) begin
        logic [63:0] v;
        r = rnd();
        case (mode)
          0, 1:    v = 0;
          2:       v = IMAX;
          3, 4:    v = 64'(r % 2);
          default: v = 64'(r) & ((r[31]) ? IMAX : 64'h7);
        endcase
        inc[i*INC_W +: INC_W] <= INC_W'(v);
      end
      freeze <= (rnd() % 23 == 0);
      snap   <= (rnd() % 37 == 0);
      errs   <= (rnd() % 11 == 0) ? NUM_ERR'(rnd()) : '0;
      r = rnd() % 100;
      if (r < 45) begin
        logic [11:0] a;
        logic [31:0] d;
        bit w;
        int unsigned s;
        s = rnd() % 40;
        w = 1'b0; d = rnd();
        case (s)
          0, 1, 2:           a = 12'(`HPC_PR_LIVE_BASE + 8 * (rnd() % NC) + 4 * (rnd() % 2));
          3, 4, 5:           begin                                              // proper LO -> HI pair
                               a = 12'(`HPC_PR_LIVE_BASE + 8 * (rnd() % NC));
                               bus(1'b0, a, 32'd0, q, e);
                               a = a + 12'd4;
                             end
          6, 7, 8:           a = 12'(`HPC_PR_SNAP_BASE + 8 * (rnd() % NC) + 4 * (rnd() % 2));
          9:                 begin a = `HPC_PR_CTRL; w = 1'b1;
                                   d = (rnd() % 8 == 0) ? d : (32'd1 | (d & 32'h0000_0700 & ((rnd() % 3 == 0) ? 32'hFFFF : 32'h0)));
                                   if (rnd() % 6 == 0) d[`HPC_CTRL_FREEZE] = 1'b1;
                                   if (rnd() % 6 == 0) d[`HPC_CTRL_FREEZE_ON_OVF] = 1'b1;
                                   if (rnd() % 10 != 0) d[`HPC_CTRL_ENABLE] = 1'b1; end
          10:                begin a = `HPC_PR_CNT_EN; w = 1'b1; d = (rnd() % 2) ? 32'hFFFF_FFFF : d; end
          11:                begin a = `HPC_PR_SAT; w = 1'b1; end
          12:                begin a = `HPC_PR_OVF; w = 1'b1; end
          13:                begin a = `HPC_PR_OVF_IE; w = 1'b1; end
          14:                begin a = `HPC_PR_CLR; w = 1'b1; d = (rnd() % 4 == 0) ? d : 32'd0; end
          15:                begin a = `HPC_PR_PRE_LO; w = 1'b1; d = (rnd() % 2) ? (32'hFFFF_FFFF - (rnd() % 64)) : d; end
          16:                begin a = `HPC_PR_PRE_HI; w = 1'b1;
                                   d = (rnd() % 3 == 0) ? d : ((rnd() % 2) ? 32'hFFFF_FFFF : 32'h0); end
          17:                begin a = `HPC_PR_PRE_LOAD; w = 1'b1; d = 32'd1 << (rnd() % NC); end
          18:                begin a = `HPC_PR_ERR_SRC; w = 1'b1; end
          19:                begin a = `HPC_PR_STATUS; w = (rnd() % 2 == 0); end
          20:                a = 12'(rnd());                                    // anything, including invalid offsets
          21:                begin a = 12'(rnd()); w = 1'b1; end
          22:                begin a = 12'(`HPC_PR_LIVE_BASE + 8 * (rnd() % NC)); w = 1'b1; end
          default:           a = 12'(4 * (rnd() % 21));                        // control-register reads
        endcase
        bus(w, a, d, q, e);
      end else if (r == 99 && (rnd() % 8 == 0)) begin
        rst_n <= 1'b0; idle(1 + rnd() % 3); rst_n <= 1'b1; @(negedge clk);
      end else begin
        @(negedge clk);
      end
      k++;
    end
    inc <= '0; freeze <= 1'b0; snap <= 1'b0; errs <= '0;
    @(negedge clk);
  endtask

  // ============================================================ main
  initial begin
    string fn;
    int unsigned ncyc;
    if (!$value$plusargs("seed=%d", rs)) rs = 1;
    rs = rs * 32'h9E37_79B9 + 32'h7F4A_7C15;
    if (rs == 0) rs = 1;
    if (!$value$plusargs("cycles=%d", ncyc)) ncyc = 20000;
    if ($value$plusargs("trace=%s", fn)) tf = $fopen(fn, "w");
    repeat (3) @(negedge clk);
    rst_n <= 1'b1;
    @(negedge clk);
    t_reset_values();
    if (!EN_RESET) ctrl(1, 0, 0, 0, 0, 0);
    t_single_event();
    t_multi_event();
    t_increments();
    t_enable();
    t_freeze();
    t_snapshot();
    t_overflow();
    t_reset_mid();
    t_back_to_back();
    t_read_during_activity();
    t_bus_errors();
    t_err_src();
    $display("TB_PERF INFO directed tests done: %0d checks, %0d errors", checks, errors);
    random_phase(ncyc);
    idle(2);
    @(posedge clk); #1;                       // close mid-cycle: never during the negedge trace write
    if (tf != 0) begin $fclose(tf); tf = 0; end
    if (errors == 0) $display("TB_PERF RESULT PASS checks=%0d cycles=%0d", checks, cyc);
    else             $display("TB_PERF RESULT FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
  initial begin #50ms; $display("TB_PERF RESULT FAIL timeout"); $finish; end
endmodule

`default_nettype wire
