// =============================================================================
// SilicaFlux-HPC Module 07 :: tb_hpc_perf_events -- event-layer test with synthetic stimulus
//
// The real-module tests (tb_hpc_tile_perf, tb_hpc_perf_varray) prove the event
// definitions on the actual hardware, but the hardware rarely or never produces
// some input combinations: three scratchpad ports losing arbitration in one
// cycle, a full DMA descriptor queue together with a full vector command queue,
// a completion record of an illegal reduction with a non-zero count, a lane
// accepting while it retires at full occupancy.  This test drives
// hpc_perf_events directly with random, protocol-legal stimulus (lanes accept
// and retire in order within ROB_DEPTH; completions never exceed accepted
// commands) at maximal multiplicity, and compares inc_o and err_o in EVERY
// cycle with an independently written expected value per counter.  Coverage of
// the corner combinations is counted and required.  At the end an illegal
// pattern (retire from an empty lane) must raise PERF_TRACK_ERR.
// Result line: "TB_EV RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "hpc_perf_defs.svh"

module tb_hpc_perf_events #(
  parameter int N      = 4,
  parameter int NSP    = 3,
  parameter int ROB    = 8,
  parameter bit EV_REG = 1'b1,
  parameter int NCYC   = 30000
);
  localparam int NC = `HPC_PERF_NUM_CNT, NE = `HPC_PERF_NUM_ERR, IW = 32;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int unsigned errors = 0, cyc = 0;
  int unsigned rs = 32'h0F1E_2D3C;
  function automatic int unsigned rnd();
    rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5);
    return rs;
  endfunction
  function automatic bit pct(input int p);
    return (rnd() % 100) < p;
  endfunction

  // ---------------------------------------------------------------- stimulus
  logic va_cmd_valid = 0, va_cmd_ready = 0, va_cpl_valid = 0, va_cpl_ready = 0, va_cpl_illegal = 0, va_cpl_red = 0;
  logic [15:0] va_cpl_count = '0;
  logic va_res_valid = 0, va_res_ready = 0, va_busy = 0;
  logic [N-1:0] acc = '0, ret = '0;
  logic [4:0]   op = '0;
  logic stl = 0, stt = 0, stv = 0, cqf = 0;
  logic [2:0] cqc = '0;
  logic dcv = 0, dcr = 1, dpv = 0, dpr = 0, dpe = 0, dact = 0, dbe = 0, dte = 0;
  logic [7:0] brd = '0, bwr = '0, dout = '0;
  logic [NSP-1:0] sv = '0, sr = '0, swe = '0, scf = '0, sde = '0, sec = '0;
  logic frz = 0, snp = 0;
  logic [NC*IW-1:0] inc_o;
  logic [NE-1:0]    err_o;
  logic             frz_o, snp_o;

  hpc_perf_events #(.N(N), .VL_W(16), .ROB_DEPTH(ROB), .CQ_W(3), .NSP(NSP), .DMA_CMDQ(1'b1), .FMA_FLOPS(2),
                    .CMP_FLOPS(1), .INC_W(IW), .EV_REG(EV_REG)) dut (
    .clk, .rst_n,
    .va_cmd_valid, .va_cmd_ready, .va_cpl_valid, .va_cpl_ready, .va_cpl_illegal, .va_cpl_red, .va_cpl_count,
    .va_res_valid, .va_res_ready, .va_busy, .va_lane_accept(acc), .va_lane_retire(ret), .va_lane_op(op),
    .va_stall_lane(stl), .va_stall_trk(stt), .va_opnd_starve(stv), .va_cmdq_full(cqf), .va_cmdq_count(cqc),
    .dma_cmd_valid(dcv), .dma_cmd_ready(dcr), .dma_cpl_valid(dpv), .dma_cpl_ready(dpr), .dma_cpl_err(dpe),
    .dma_active(dact), .dma_bytes_rd(brd), .dma_bytes_wr(bwr), .dma_outstanding(dout), .dma_bus_err(dbe),
    .dma_tag_err(dte), .spm_req_valid(sv), .spm_req_ready(sr), .spm_req_we(swe), .spm_conflict(scf),
    .spm_dec_err(sde), .spm_ecc_err(sec), .freeze_i(frz), .snap_i(snp),
    .inc_o, .err_o, .freeze_o(frz_o), .snap_o(snp_o));

  // ---------------------------------------------------------------- independent expected values
  // FLOP convention of this build: FADD/FSUB/FMUL 1, FMA family 2, compares 1 (CMP_FLOPS = 1), FMV / integer / reserved 0
  function automatic int unsigned w_of(input logic [4:0] o);
    if (o == 5'h01 || o == 5'h02 || o == 5'h03) return 1;
    if (o >= 5'h04 && o <= 5'h07) return 2;
    if (o >= 5'h08 && o <= 5'h0C) return 1;
    return 0;
  endfunction
  int unsigned wq [0:N-1][0:15];
  int unsigned wh [0:N-1], wt [0:N-1];
  int unsigned infl = 0;
  int unsigned e_prev [0:NC-1];
  logic [NE-1:0] eerr_prev;
  bit          frz_prev, snp_prev;
  int unsigned cov_conf2 = 0, cov_conf3 = 0, cov_dmaq = 0, cov_illred = 0, cov_fullpush = 0, cov_multi_ret = 0;
  initial for (int l = 0; l < N; l++) begin wh[l] = 0; wt[l] = 0; end

  task automatic compare(input int unsigned exp [0:NC-1], input logic [NE-1:0] eerr, input bit f, input bit s);
    for (int i = 0; i < NC; i++)
      if (inc_o[i*IW +: IW] !== IW'(exp[i])) begin
        errors++;
        if (errors < 20) $display("TB_EV ERROR cyc=%0d counter %0d: inc %0d, expected %0d", cyc, i, inc_o[i*IW +: IW], exp[i]);
      end
    if (err_o !== eerr) begin errors++; if (errors < 20) $display("TB_EV ERROR cyc=%0d err_o %b, expected %b", cyc, err_o, eerr); end
    if (frz_o !== f || snp_o !== s) begin errors++; if (errors < 20) $display("TB_EV ERROR cyc=%0d freeze/snap alignment", cyc); end
  endtask

  initial begin
    repeat (3) @(negedge clk);
    rst_n = 1'b1;
    for (int i = 0; i < NC; i++) e_prev[i] = 0;
    e_prev[`HPC_PC_CYCLES] = 1;                    // the idle cycle before the loop, already registered
    eerr_prev = '0; frz_prev = 0; snp_prev = 0;
    for (int k = 0; k < NCYC + 1; k++) begin
      int unsigned exp [0:NC-1];
      logic [NE-1:0] eerr;
      int unsigned lane_fl, nacc, nret, red, nrd, nwr, nconf, nerr;
      bit vhs, vch, dhs, dch;
      @(negedge clk);
      // -------------------------------------------------------- draw legal stimulus for this cycle
      va_cmd_valid = pct(50); va_cmd_ready = pct(60); dcv = pct(50); dcr = pct(70);
      vhs = va_cmd_valid & va_cmd_ready; dhs = dcv & dcr;
      va_cpl_valid = (infl >= 1) && pct(50); va_cpl_ready = pct(60);
      vch = va_cpl_valid & va_cpl_ready;
      dpv = (infl >= 1 + 32'(vch)) && pct(50); dpr = pct(60);
      dch = dpv & dpr;
      va_cpl_illegal = pct(30); va_cpl_red = pct(50); va_cpl_count = 16'(rnd());
      dpe = pct(30);
      va_res_valid = pct(50); va_res_ready = pct(50); va_busy = pct(70);
      op = 5'(rnd());
      for (int l = 0; l < N; l++) begin
        int unsigned occ;
        occ = wt[l] - wh[l];
        ret[l] = (occ > 0) && pct(60);
        acc[l] = ((occ < ROB) || (occ == ROB && ret[l])) && pct(60);
        if (occ == ROB && ret[l] && acc[l]) cov_fullpush++;
      end
      stl = pct(20); stt = pct(20); stv = pct(20); cqf = pct(30); cqc = 3'(rnd() % 5);
      dact = pct(50); brd = 8'(rnd() % 9); bwr = 8'(rnd() % 9); dout = 8'(rnd()); dbe = pct(5); dte = pct(5);
      sv = NSP'(rnd()); sr = NSP'(rnd()); swe = NSP'(rnd()); scf = pct(40) ? '1 : NSP'(rnd());
      sde = pct(10) ? NSP'(rnd()) : '0; sec = pct(10) ? NSP'(rnd()) : '0;
      frz = pct(10); snp = pct(10);
      if (k == NCYC) begin acc = '0; ret = '0; end
      // -------------------------------------------------------- expected increments of THIS cycle
      lane_fl = 0; nacc = 0; nret = 0;
      for (int l = 0; l < N; l++) begin
        if (ret[l]) begin lane_fl += wq[l][wh[l] % 16]; wh[l]++; nret++; end
        if (acc[l]) begin wq[l][wt[l] % 16] = w_of(op); wt[l]++; nacc++; end
      end
      if (nret > 1) cov_multi_ret++;
      red = (vch && va_cpl_red && !va_cpl_illegal) ? int'(va_cpl_count) : 0;
      if (vch && va_cpl_red && va_cpl_illegal && va_cpl_count != 0) cov_illred++;
      nrd = 0; nwr = 0; nconf = 0;
      for (int p = 0; p < NSP; p++) begin
        if (sv[p] && sr[p]) begin if (swe[p]) nwr++; else nrd++; end
        nconf += int'(scf[p]);
      end
      if (nconf == 2) cov_conf2++;
      if (nconf == 3) cov_conf3++;
      if (!dcr && cqf) cov_dmaq++;
      eerr = '0;
      eerr[0] = vch && va_cpl_illegal; eerr[1] = dch && dpe; eerr[2] = dbe; eerr[3] = dte;
      eerr[4] = |sec; eerr[5] = |sde;
      nerr = int'(eerr[0]) + int'(eerr[1]) + int'(eerr[2]) + int'(eerr[3]) + $countones(sec) + $countones(sde);
      for (int i = 0; i < NC; i++) exp[i] = 0;
      exp[`HPC_PC_CYCLES] = 1;
      exp[`HPC_PC_CMD_ACCEPTED] = int'(vhs) + int'(dhs);
      exp[`HPC_PC_CMD_COMPLETED] = int'(vch) + int'(dch);
      exp[`HPC_PC_VEC_ISSUED] = nacc;
      exp[`HPC_PC_VEC_RETIRED] = nret;
      exp[`HPC_PC_FLOPS_RETIRED] = lane_fl + red;
      exp[`HPC_PC_VEC_STALL] = int'(stl || stt || stv);
      exp[`HPC_PC_DMA_ACTIVE] = dact;
      exp[`HPC_PC_DMA_BYTES_RD] = brd;
      exp[`HPC_PC_DMA_BYTES_WR] = bwr;
      exp[`HPC_PC_SPM_READS] = nrd;
      exp[`HPC_PC_SPM_WRITES] = nwr;
      exp[`HPC_PC_SPM_CONFLICTS] = nconf;
      exp[`HPC_PC_CMDQ_FULL] = int'(cqf || !dcr);
      exp[`HPC_PC_OUT_BP] = int'((va_res_valid && !va_res_ready) || (va_cpl_valid && !va_cpl_ready) || (dpv && !dpr));
      exp[`HPC_PC_HW_ERRORS] = nerr;
      exp[`HPC_PC_VEC_BUSY] = va_busy;
      exp[`HPC_PC_VEC_OPND_STARVE] = stv;
      exp[`HPC_PC_CMD_INFLIGHT_SUM] = infl;
      exp[`HPC_PC_VEC_CMDQ_OCC_SUM] = cqc;
      exp[`HPC_PC_DMA_OUT_SUM] = dout;
      exp[`HPC_PC_RED_ADDS] = red;
      exp[`HPC_PC_VEC_CMD_COMPLETED] = vch;
      infl = infl + int'(vhs) + int'(dhs) - int'(vch) - int'(dch);
      // -------------------------------------------------------- compare (EV_REG: the previous cycle's values appear now)
      #1;
      if (EV_REG) compare(e_prev, eerr_prev, frz_prev, snp_prev);
      else        compare(exp, eerr, frz, snp);
      for (int i = 0; i < NC; i++) e_prev[i] = exp[i];
      eerr_prev = eerr; frz_prev = frz; snp_prev = snp;
      cyc++;
    end
    // -------------------------------------------------------- self-check path: retire from an empty lane
    // drain every lane (legal retirements), then retire once more from lane 0 while it is empty
    for (int d = 0; d < ROB + 2; d++) begin
      @(negedge clk);
      acc = '0;
      for (int l = 0; l < N; l++) begin ret[l] = (wt[l] != wh[l]); if (ret[l]) wh[l]++; end
    end
    @(negedge clk);
    acc = '0; ret = '0; ret[0] = 1'b1;
    #1;
    begin
      bit seen;
      seen = !EV_REG && err_o[`HPC_ERR_PERF_TRACK_ERR];
      @(negedge clk); ret = '0; #1;
      seen = seen | err_o[`HPC_ERR_PERF_TRACK_ERR];
      if (!seen) begin errors++; $display("TB_EV ERROR PERF_TRACK_ERR not raised by a retirement from an empty lane"); end
    end
    $display("TB_EV COVERAGE cycles=%0d conflicts_2=%0d conflicts_3=%0d dma_and_vec_queue_full=%0d illegal_reduction_nonzero_count=%0d push_at_full_with_pop=%0d multi_lane_retire=%0d",
             cyc, cov_conf2, cov_conf3, cov_dmaq, cov_illred, cov_fullpush, cov_multi_ret);
    if ((NSP >= 2 && cov_conf2 == 0) || (NSP >= 3 && cov_conf3 == 0) || cov_dmaq == 0 || cov_illred == 0 ||
        cov_fullpush == 0 || (N > 1 && cov_multi_ret == 0)) begin
      errors++; $display("TB_EV ERROR coverage goal missed");
    end
    if (errors == 0) $display("TB_EV RESULT PASS N=%0d NSP=%0d EV_REG=%0d", N, NSP, EV_REG);
    else             $display("TB_EV RESULT FAIL errors=%0d", errors);
    $finish;
  end
endmodule

`default_nettype wire
