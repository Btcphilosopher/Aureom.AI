// =============================================================================
// SilicaFlux-HPC Module 07 :: tb_hpc_perf_varray -- vector-event definitions on the real array
//
// Drives the Module 03 vector array (with the Module 07 observation port)
// directly, with what the tile workload cannot produce: random elementwise AND
// sum-reduction commands, vector masks (vm), every opcode class (FP
// arithmetic, FMA family, compares, integer, FMV), illegal commands, vl = 0,
// operand gaps, result and completion back-pressure and random lane holds
// (partial issue -> lanes retire in different cycles, or several in the
// same cycle).  The telemetry unit hpc_perf_tile counts.
//
// Checks (exact):
//   * workload semantics: VEC_ISSUED = VEC_RETIRED = sum of active elements
//     (tail, mask and legality applied by the testbench, independently);
//     FLOPS_RETIRED = sum active x weight(op) + sum over legal reductions of
//     active elements; RED_ADDS; CMD_ACCEPTED = CMD_COMPLETED =
//     VEC_CMD_COMPLETED = commands; HW_ERRORS = illegal commands;
//   * the Module 03 counters with the same definitions (ELEM_IN, ELEM_OUT,
//     BUSY, OPND_STARVE, STALL_LANE + STALL_TRK + OPND_STARVE, RES_BP-or-CPL_BP);
//   * periodic coherent snapshots against a per-cycle mirror of the
//     cycle-type counters (VEC_STALL, VEC_BUSY, OUT_BP, CMDQ_FULL, ...).
// Reports the histogram of simultaneous lane retirements per cycle.
// Result line: "TB_VA_PERF RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "hpc_perf_defs.svh"

module tb_hpc_perf_varray #(
  parameter int N         = 4,
  parameter int FMA_FLOPS = 2,
  parameter int CMP_FLOPS = 0,
  parameter bit EV_REG    = 1'b1,
  parameter int HOLD_PCT  = 20,
  parameter int BP_PCT    = 25,
  parameter int GAP_PCT   = 20,
  parameter int NCMD      = 400
);
  localparam int NC = `HPC_PERF_NUM_CNT;
  localparam int CMD_DEPTH = 4;
  localparam int CQW = $clog2(CMD_DEPTH + 1);

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int unsigned cyc = 0, errors = 0, checks = 0;
  always @(posedge clk) cyc <= cyc + 1;
  task automatic chk(input bit ok, input string m);
    checks++;
    if (!ok) begin errors++; if (errors <= 30) $display("TB_VA_PERF ERROR cyc=%0d: %s", cyc, m); end
  endtask
  int unsigned rs = 32'h1234_5679;
  function automatic int unsigned rnd();
    rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5);
    return rs;
  endfunction

  // ============================================================ DUT: vector array + telemetry
  logic             cmd_valid = 1'b0, cmd_ready, cmd_vm = 1'b0, cmd_red = 1'b0;
  logic [4:0]       cmd_op = '0;
  logic [2:0]       cmd_rm = '0, cmd_bc = '0;
  logic [15:0]      cmd_vl = '0;
  logic [31:0]      cmd_sc = '0;
  logic [7:0]       cmd_tid = '0;
  logic             opnd_valid = 1'b0, opnd_ready;
  logic [N*32-1:0]  opnd_a = '0, opnd_b = '0, opnd_c = '0;
  logic [N-1:0]     opnd_mask = '0;
  logic             res_valid, res_ready = 1'b0, res_last, cpl_valid, cpl_ready = 1'b0, cpl_ill, cpl_red, busy;
  logic [N*32-1:0]  res_data;
  logic [N*5-1:0]   res_flags;
  logic [N-1:0]     res_mask, lane_hold = '0;
  logic [7:0]       res_tid, cpl_tid;
  logic [15:0]      res_beat, cpl_count;
  logic [4:0]       cpl_flags;
  logic [31:0]      cpl_result;
  logic [hpc_varray_pkg::PC_N*32-1:0] va_perf;
  logic [N-1:0]     ob_acc, ob_ret;
  logic [4:0]       ob_op;
  logic             ob_stl, ob_stt, ob_starve, ob_cqf;
  logic [CQW-1:0]   ob_cqc;
  hpc_vector_array #(.NUM_LANES(N), .VL_W(16), .TID_W(8), .CMD_DEPTH(CMD_DEPTH)) u_va (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_op_i(cmd_op), .cmd_rm_i(cmd_rm), .cmd_vl_i(cmd_vl),
    .cmd_vm_i(cmd_vm), .cmd_bcast_i(cmd_bc), .cmd_scalar_i(cmd_sc), .cmd_red_i(cmd_red), .cmd_tid_i(cmd_tid),
    .opnd_valid_i(opnd_valid), .opnd_ready_o(opnd_ready), .opnd_a_i(opnd_a), .opnd_b_i(opnd_b), .opnd_c_i(opnd_c),
    .opnd_mask_i(opnd_mask),
    .res_valid_o(res_valid), .res_ready_i(res_ready), .res_data_o(res_data), .res_flags_o(res_flags),
    .res_mask_o(res_mask), .res_tid_o(res_tid), .res_beat_o(res_beat), .res_last_o(res_last),
    .cpl_valid_o(cpl_valid), .cpl_ready_i(cpl_ready), .cpl_tid_o(cpl_tid), .cpl_flags_o(cpl_flags),
    .cpl_illegal_o(cpl_ill), .cpl_count_o(cpl_count), .cpl_red_o(cpl_red), .cpl_result_o(cpl_result),
    .lane_hold_i(lane_hold), .busy_o(busy), .perf_clear_i(1'b0), .perf_cnt_o(va_perf),
    .obs_lane_accept_o(ob_acc), .obs_lane_retire_o(ob_ret), .obs_lane_op_o(ob_op), .obs_stall_lane_o(ob_stl),
    .obs_stall_trk_o(ob_stt), .obs_opnd_starve_o(ob_starve), .obs_cmdq_full_o(ob_cqf), .obs_cmdq_count_o(ob_cqc));
  function automatic int unsigned vpc(input int i);
    return va_perf[i*32 +: 32];
  endfunction

  logic        rb_sel = 1'b0, rb_we = 1'b0, rb_err, irq, frozen;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic [NC*64-1:0] pf_cnt;
  hpc_perf_tile #(.N(N), .VL_W(16), .ROB_DEPTH(8), .CQ_W(CQW), .NSP(1), .DMA_CMDQ(1'b0), .FMA_FLOPS(FMA_FLOPS),
                  .CMP_FLOPS(CMP_FLOPS), .EV_REG(EV_REG)) u_perf (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .va_cmd_valid(cmd_valid), .va_cmd_ready(cmd_ready), .va_cpl_valid(cpl_valid), .va_cpl_ready(cpl_ready),
    .va_cpl_illegal(cpl_ill), .va_cpl_red(cpl_red), .va_cpl_count(cpl_count), .va_res_valid(res_valid),
    .va_res_ready(res_ready), .va_busy(busy), .va_lane_accept(ob_acc), .va_lane_retire(ob_ret), .va_lane_op(ob_op),
    .va_stall_lane(ob_stl), .va_stall_trk(ob_stt), .va_opnd_starve(ob_starve), .va_cmdq_full(ob_cqf),
    .va_cmdq_count(ob_cqc),
    .dma_cmd_valid(1'b0), .dma_cmd_ready(1'b1), .dma_cpl_valid(1'b0), .dma_cpl_ready(1'b1), .dma_cpl_err(1'b0),
    .dma_active(1'b0), .dma_bytes_rd(8'd0), .dma_bytes_wr(8'd0), .dma_outstanding(8'd0), .dma_bus_err(1'b0),
    .dma_tag_err(1'b0), .spm_req_valid(1'b0), .spm_req_ready(1'b0), .spm_req_we(1'b0), .spm_conflict(1'b0),
    .spm_dec_err(1'b0), .spm_ecc_err(1'b0),
    .freeze_i(1'b0), .snap_i(1'b0), .irq_o(irq), .frozen_o(frozen), .cnt_o(pf_cnt));

  // ============================================================ workload bookkeeping (independent of the RTL)
  function automatic int unsigned weight(input logic [4:0] op);
    case (op)
      5'h01, 5'h02, 5'h03:               return 1;
      5'h04, 5'h05, 5'h06, 5'h07:        return FMA_FLOPS;
      5'h08, 5'h09, 5'h0A, 5'h0B, 5'h0C: return CMP_FLOPS;
      default:                           return 0;
    endcase
  endfunction
  function automatic bit legal(input logic [4:0] op, input logic [2:0] rm, input bit red, input logic [2:0] bc);
    bit rm_ok;
    rm_ok = (rm <= 3'd4);
    if (red) return (op <= 5'h07) && rm_ok && (bc == 3'b000);
    case (op)
      5'h00:                             return 1'b1;
      5'h01, 5'h02, 5'h03, 5'h04, 5'h05, 5'h06, 5'h07: return rm_ok;
      5'h08, 5'h09, 5'h0A, 5'h0B, 5'h0C, 5'h10, 5'h11: return 1'b1;
      default:                           return 1'b0;
    endcase
  endfunction
  // per command: number of beats, vm, legality (consumed by the operand driver in command order)
  int unsigned q_beats [0:NCMD-1];
  bit          q_vm [0:NCMD-1], q_leg [0:NCMD-1], q_red [0:NCMD-1];
  logic [15:0] q_vl [0:NCMD-1];
  logic [4:0]  q_op [0:NCMD-1];
  int unsigned n_cmd_sent = 0, n_illegal = 0;
  longint unsigned s_active = 0, s_flops = 0, s_red = 0;
  int unsigned n_cpl = 0, n_res = 0;

  // ============================================================ command driver
  task automatic send_cmds();
    for (int k = 0; k < NCMD; k++) begin
      int unsigned r, vlk;
      logic [4:0] op;
      logic [2:0] rm, bc;
      bit red, vm;
      r = rnd() % 100;
      case (rnd() % 10)
        0:       vlk = 0;
        1:       vlk = 1 + rnd() % N;
        2, 3:    vlk = N * (1 + rnd() % 4);
        default: vlk = 1 + rnd() % (8 * N);
      endcase
      red = (rnd() % 4 == 0);
      case (rnd() % 12)
        0: op = 5'h00; 1: op = 5'h01; 2: op = 5'h02; 3: op = 5'h03; 4: op = 5'h04; 5: op = 5'h05;
        6: op = 5'h06; 7: op = 5'h07;
        8: op = 5'(8 + rnd() % 5);                   // compares / min / max
        9: op = (rnd() % 2) ? 5'h10 : 5'h11;          // integer
        10: op = 5'h04;
        default: op = (rnd() % 3 == 0) ? 5'h1F : 5'h04;   // reserved opcode: illegal
      endcase
      rm = (rnd() % 20 == 0) ? 3'd7 : 3'(rnd() % 5);
      bc = red ? 3'b000 : ((rnd() % 4 == 0) ? 3'(rnd() % 8) : 3'b000);
      if (red && rnd() % 10 == 0) bc = 3'b010;        // illegal: broadcast in a reduction
      vm = (rnd() % 3 == 0);
      q_beats[k] = (vlk + N - 1) / N;
      q_vm[k] = vm; q_leg[k] = legal(op, rm, red, bc); q_red[k] = red; q_vl[k] = 16'(vlk); q_op[k] = op;
      if (!q_leg[k]) n_illegal++;
      cmd_valid <= 1'b1; cmd_op <= op; cmd_rm <= rm; cmd_vl <= 16'(vlk); cmd_vm <= vm; cmd_bc <= bc;
      cmd_sc <= rnd(); cmd_red <= red; cmd_tid <= 8'(k);
      @(posedge clk);
      while (!cmd_ready) @(posedge clk);
      n_cmd_sent++;
      @(negedge clk);
      cmd_valid <= 1'b0;
      if (rnd() % 100 < GAP_PCT) repeat (rnd() % 4) @(negedge clk);
    end
  endtask
  // ============================================================ operand driver (beats in command order, random gaps / masks)
  task automatic send_opnds();
    for (int k = 0; k < NCMD; k++) begin
      while (n_cmd_sent <= k) @(negedge clk);
      for (int g = 0; g < int'(q_beats[k]); g++) begin
        logic [N-1:0] m;
        while (rnd() % 100 < GAP_PCT) @(negedge clk);
        m = N'(rnd());
        opnd_valid <= 1'b1; opnd_mask <= m;
        for (int l = 0; l < N; l++) begin opnd_a[l*32 +: 32] <= rnd(); opnd_b[l*32 +: 32] <= rnd(); opnd_c[l*32 +: 32] <= rnd(); end
        @(posedge clk);
        while (!opnd_ready) @(posedge clk);
        // active elements of this beat: tail, mask (vm), legality
        if (q_leg[k]) for (int l = 0; l < N; l++)
          if (g * N + l < int'(q_vl[k]) && (!q_vm[k] || m[l])) begin
            s_active++; s_flops += weight(q_op[k]);
            if (q_red[k]) begin s_flops++; s_red++; end
          end
        @(negedge clk);
        opnd_valid <= 1'b0;
      end
    end
  endtask
  // consumers with random back-pressure; lane holds
  bit run = 1'b0;
  always @(negedge clk) begin
    res_ready <= !run || (rnd() % 100 >= BP_PCT);
    cpl_ready <= !run || (rnd() % 100 >= BP_PCT);
    for (int l = 0; l < N; l++) lane_hold[l] <= run && (rnd() % 100 < HOLD_PCT);
  end
  always @(posedge clk) if (rst_n) begin
    if (cpl_valid && cpl_ready) n_cpl++;
    if (res_valid && res_ready) n_res++;
  end

  // ============================================================ per-cycle mirror of the cycle-type counters + retirement histogram
  logic [N-1:0] mr_ret;                          // lane retirements from the lane pins (hierarchical)
  for (genvar l = 0; l < N; l++) begin : g_mret
    assign mr_ret[l] = u_va.g_lane[l].u_lane.out_valid_o & u_va.g_lane[l].u_lane.out_ready_i;
  end
  int unsigned hist [0:16];
  logic [63:0] m_cnt [0:NC-1];
  int unsigned m_d [0:NC-1];
  int unsigned m_infl = 0;
  initial for (int i = 0; i < NC; i++) begin m_cnt[i] = 0; m_d[i] = 0; end
  initial for (int i = 0; i <= 16; i++) hist[i] = 0;
  always @(posedge clk) if (rst_n) begin
    int unsigned ev [0:NC-1];
    int unsigned nret;
    for (int i = 0; i < NC; i++) ev[i] = 0;
    nret = 0;
    for (int l = 0; l < N; l++) nret += int'(mr_ret[l]);
    hist[nret]++;
    ev[`HPC_PC_CYCLES]           = 1;
    ev[`HPC_PC_VEC_STALL]        = u_va.u_issue.beat_ph && !(opnd_valid && opnd_ready);
    ev[`HPC_PC_VEC_OPND_STARVE]  = u_va.u_issue.beat_ph && !opnd_valid;
    ev[`HPC_PC_VEC_BUSY]         = busy;
    ev[`HPC_PC_OUT_BP]           = (res_valid && !res_ready) || (cpl_valid && !cpl_ready);
    ev[`HPC_PC_CMDQ_FULL]        = (u_va.u_issue.u_cq.cnt_q == CMD_DEPTH);
    ev[`HPC_PC_VEC_CMDQ_OCC_SUM] = int'(u_va.u_issue.u_cq.cnt_q);
    ev[`HPC_PC_CMD_INFLIGHT_SUM] = m_infl;
    m_infl = m_infl + int'(cmd_valid && cmd_ready) - int'(cpl_valid && cpl_ready);
    for (int i = 0; i < NC; i++) begin
      m_cnt[i] <= m_cnt[i] + 64'(EV_REG ? m_d[i] : ev[i]);
      m_d[i]   <= ev[i];
    end
  end

  // ============================================================ register bus
  logic [63:0] bus_m_pre [0:NC-1];
  task automatic bus(input bit we, input logic [11:0] a, input logic [31:0] d, output logic [31:0] q);
    rb_sel <= 1'b1; rb_we <= we; rb_addr <= a; rb_wdata <= d;
    @(posedge clk);
    q = rb_rdata;
    chk(!rb_err, $sformatf("register access 0x%03h refused", a));
    for (int i = 0; i < NC; i++) bus_m_pre[i] = m_cnt[i];
    @(negedge clk);
    rb_sel <= 1'b0; rb_we <= 1'b0;
  endtask
  logic [63:0] sv [0:NC-1];
  int unsigned n_snap = 0;
  // snapshot; mirrored (cycle-type) counters compared exactly
  task automatic snapshot(input string where);
    logic [31:0] lo, hi;
    logic [63:0] exp [0:NC-1];
    bus(1'b1, `HPC_PR_CTRL, 32'd1 | 32'd1 << `HPC_CTRL_SNAPSHOT, lo);
    for (int i = 0; i < NC; i++) exp[i] = bus_m_pre[i];
    for (int i = 0; i < NC; i++) begin
      bus(1'b0, 12'(`HPC_PR_SNAP_BASE + 8*i), 0, lo);
      bus(1'b0, 12'(`HPC_PR_SNAP_BASE + 8*i + 4), 0, hi);
      sv[i] = {hi, lo};
    end
    foreach (exp[i])
      if (i == `HPC_PC_CYCLES || i == `HPC_PC_VEC_STALL || i == `HPC_PC_VEC_OPND_STARVE || i == `HPC_PC_VEC_BUSY ||
          i == `HPC_PC_OUT_BP || i == `HPC_PC_CMDQ_FULL || i == `HPC_PC_VEC_CMDQ_OCC_SUM || i == `HPC_PC_CMD_INFLIGHT_SUM)
        chk(sv[i] == exp[i], $sformatf("%s: counter %0d = %0d, mirror %0d", where, i, sv[i], exp[i]));
    n_snap++;
  endtask

  initial begin
    logic [31:0] q;
    if (!$value$plusargs("seed=%d", rs)) rs = 7;
    rs = rs * 32'h9E37_79B9 + 32'h1;
    repeat (3) @(negedge clk);
    rst_n <= 1'b1;
    @(negedge clk);
    run = 1'b1;
    fork
      send_cmds();
      send_opnds();
      begin
        repeat (8) begin repeat (200 + rnd() % 600) @(negedge clk); snapshot("during activity"); end
      end
    join
    while (n_cpl < NCMD) @(negedge clk);
    run = 1'b0;
    repeat (20) @(negedge clk);
    snapshot("final");
    // ---- workload semantics
    chk(sv[`HPC_PC_VEC_ISSUED] == s_active, $sformatf("VEC_ISSUED %0d, active elements %0d", sv[`HPC_PC_VEC_ISSUED], s_active));
    chk(sv[`HPC_PC_VEC_RETIRED] == s_active, $sformatf("VEC_RETIRED %0d, active elements %0d", sv[`HPC_PC_VEC_RETIRED], s_active));
    chk(sv[`HPC_PC_FLOPS_RETIRED] == s_flops, $sformatf("FLOPS_RETIRED %0d, workload %0d", sv[`HPC_PC_FLOPS_RETIRED], s_flops));
    chk(sv[`HPC_PC_RED_ADDS] == s_red, $sformatf("RED_ADDS %0d, workload %0d", sv[`HPC_PC_RED_ADDS], s_red));
    chk(sv[`HPC_PC_CMD_ACCEPTED] == NCMD && sv[`HPC_PC_CMD_COMPLETED] == NCMD && sv[`HPC_PC_VEC_CMD_COMPLETED] == NCMD,
        "command counters");
    chk(sv[`HPC_PC_HW_ERRORS] == n_illegal, $sformatf("HW_ERRORS %0d, illegal commands %0d", sv[`HPC_PC_HW_ERRORS], n_illegal));
    bus(1'b0, `HPC_PR_ERR_SRC, 0, q);
    chk(q == ((n_illegal > 0) ? 32'd1 << `HPC_ERR_VEC_ILLEGAL : 32'd0), $sformatf("ERR_SRC = %b", q));
    // ---- Module 03 counters with the same definitions (32-bit, never cleared here)
    chk(sv[`HPC_PC_VEC_ISSUED] == vpc(hpc_varray_pkg::PC_ELEM_IN), "VEC_ISSUED vs M03 ELEM_IN");
    chk(sv[`HPC_PC_VEC_RETIRED] == vpc(hpc_varray_pkg::PC_ELEM_OUT), "VEC_RETIRED vs M03 ELEM_OUT");
    chk(sv[`HPC_PC_VEC_BUSY] == vpc(hpc_varray_pkg::PC_BUSY), "VEC_BUSY vs M03 BUSY");
    chk(sv[`HPC_PC_VEC_OPND_STARVE] == vpc(hpc_varray_pkg::PC_OPND_STARVE), "VEC_OPND_STARVE vs M03 OPND_STARVE");
    chk(sv[`HPC_PC_VEC_STALL] == vpc(hpc_varray_pkg::PC_STALL_LANE) + vpc(hpc_varray_pkg::PC_STALL_TRK) +
        vpc(hpc_varray_pkg::PC_OPND_STARVE), "VEC_STALL vs M03 STALL_LANE + STALL_TRK + OPND_STARVE");
    chk(u_perf.u_ev.err_src[`HPC_ERR_PERF_TRACK_ERR] === 1'b0, "PERF_TRACK_ERR");
    $write("TB_VA_PERF HIST simultaneous_retirements:");
    for (int k = 0; k <= N; k++) $write(" %0d=%0d", k, hist[k]);
    $write("\n");
    $display("TB_VA_PERF COUNTERS cmds=%0d illegal=%0d active=%0d flops=%0d red_adds=%0d stall=%0d busy=%0d out_bp=%0d cmdq_full=%0d snapshots=%0d",
             NCMD, n_illegal, sv[`HPC_PC_VEC_RETIRED], sv[`HPC_PC_FLOPS_RETIRED], sv[`HPC_PC_RED_ADDS], sv[`HPC_PC_VEC_STALL],
             sv[`HPC_PC_VEC_BUSY], sv[`HPC_PC_OUT_BP], sv[`HPC_PC_CMDQ_FULL], n_snap);
    chk(N == 1 || hist[N] > 0, "no cycle with every lane retiring together");
    chk(N == 1 || (hist[1] > 0 && HOLD_PCT > 0) || HOLD_PCT == 0, "no staggered retirement under lane holds");
    if (errors == 0) $display("TB_VA_PERF RESULT PASS N=%0d fma=%0d cmp=%0d ev_reg=%0d checks=%0d", N, FMA_FLOPS, CMP_FLOPS, EV_REG, checks);
    else             $display("TB_VA_PERF RESULT FAIL errors=%0d", errors);
    $finish;
  end
  initial begin #100ms; $display("TB_VA_PERF RESULT FAIL timeout"); $finish; end
endmodule

`default_nettype wire
