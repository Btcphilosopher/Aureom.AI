// =============================================================================
// SilicaFlux-HPC Module 07 :: tb_hpc_tile_perf -- telemetry integration test on the real tile
//
// The Module 05 integration tile (crossbar + 2 external SRAMs, Module 04
// scratchpad, Module 05 DMA adapter, reference sequencer hpc_tile_vseq,
// Module 03 vector array with the Module 07 observation port) plus the Module 07
// telemetry unit hpc_perf_tile on its own register bus.  The workload is the
// Module 05 one (scripts/gen_integ.py data, exact FP32 expectations):
//   phase A  host writes operands -> 3 DMA in -> FMADD / FADD+bcast / IMUL
//            (vl = 1000) -> 3 DMA out;
//   phase B  6 AXPY tiles, double-buffered: DMA in, compute, DMA out overlap,
//            with host background traffic;
// and adds, for the counters:
//   phase C  control under load: freeze_i pulses, CTRL.FREEZE / ENABLE toggles,
//            CNT_EN masking, CLEAR, while DMA and vector jobs run;
//   phase D  error injection: an illegal vector command and a misaligned DMA
//            descriptor (HW_ERRORS, ERR_SRC);
//   phase E  overflow on the real tile: a byte counter preloaded near 2^64 wraps
//            (OVF) and a FLOP counter in saturate mode saturates.
//
// Checks
//   * MIRROR: an independent per-cycle model in this testbench computes every
//     counter from pins and hierarchical signals of the tile (lane pins, the
//     issue stage's beat phase, scratchpad / fabric response queues for the
//     DMA bytes, ...), written from docs/03_event_definitions.md and NOT from
//     hpc_perf_events.  It is compared EXACTLY with the hardware at every
//     snapshot and at every live LO/HI pair read, during activity.
//   * WORKLOAD SEMANTICS at the quiescent point after phase B: issued =
//     retired = sum of vl, FLOPs = sum of vl x weight(op) with FMA = 2,
//     commands, bytes = sum of descriptor lengths (writes) and of whole words
//     (reads), no errors.
//   * EXISTING COUNTERS: the pre-existing 32-bit counters of Modules 03, 04 and
//     05 that share a definition must agree (and CYCLES = M05 CYCLES - EV_REG).
//   * functional result of Module 05 (memory images byte-exact) is unchanged.
// Outputs: "TB_TILE_PERF RESULT PASS|FAIL", regdump.json (raw register dump
// after phase B, the input of host/hpc_perf_telemetry.py).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "hpc_dma_defs.svh"
`include "hpc_perf_defs.svh"

module tb_hpc_tile_perf #(
  parameter int ENGINE      = 0,
  parameter int DUAL_PORT   = 0,
  parameter int FIFO_DEPTH  = 8,
  parameter int MAX_OUT     = 2,
  parameter int CMD_DEPTH   = 4,
  parameter int HOLD_PCT    = 0,      // % of cycles each lane is held (partial issue, staggered retirement)
  parameter int CPL_BP_PCT  = 0,      // % of cycles the DMA completion consumer is not ready
  parameter bit EV_REG      = 1'b1,
  parameter int INSTR_PHASE = 3,
  parameter int CLK_KHZ     = 25000   // configured clock written into CLK_KHZ: 25 MHz, the SilicaFlux-V / ULX3S
                                      // prototype clock (in simulation an assumption, labelled so by the host tool)
);
  `include "integ_cfg.svh"
  localparam int N    = IG_LANES;
  localparam int NP   = (ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1;
  localparam int NM   = NP + 1;
  localparam int NSP  = 1 + NP;
  localparam int NC   = `HPC_PERF_NUM_CNT;
  localparam int EXTB = 65536, SPMB = 65536;
  localparam int VA_CMD_DEPTH = 4;
  localparam logic [31:0] EXT_BASE = 32'h1000_0000, SPM_BASE = 32'h2000_0000;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int unsigned cyc = 0, errors = 0, checks = 0;
  always @(posedge clk) cyc <= cyc + 1;
  task automatic err(input string m);
    errors++;
    if (errors <= 40) $display("TB_TILE_PERF ERROR cyc=%0d: %s", cyc, m);
  endtask
  task automatic chk(input bit ok, input string m);
    checks++;
    if (!ok) err(m);
  endtask
  function automatic int unsigned xs(input int unsigned r);
    int unsigned t;
    t = r ^ (r << 13); t = t ^ (t >> 17); t = t ^ (t << 5);
    return t;
  endfunction

  // ============================================================ fabric + external SRAM (as Module 05)
  wire  [NM-1:0]    m_req_valid, m_req_write, m_rsp_ready;
  wire  [NM*32-1:0] m_req_addr;
  wire  [NM*32-1:0] m_req_wdata;
  wire  [NM*4-1:0]  m_req_wstrb;
  logic [NM-1:0]    m_req_ready, m_rsp_valid, m_rsp_error;
  logic [NM*32-1:0] m_rsp_rdata;
  logic [1:0]       s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [63:0]      s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [7:0]       s_req_wstrb;
  logic [NM-1:0]    x_acc, x_stall, x_loss, x_rstall;
  logic             x_eevt, x_ewr;
  logic [31:0]      x_eaddr;
  logic [((NM > 1) ? $clog2(NM) : 1)-1:0] x_emst;
  sfb_crossbar #(.NM(NM), .NS(2), .AW(32), .DW(32), .ARB_MODE(1), .CHECK_ALIGN(1),
                 .SLV_BASE({32'h1000_8000, 32'h1000_0000}), .SLV_MASK({32'hFFFF_8000, 32'hFFFF_8000})) u_xbar (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt(x_eevt), .err_addr(x_eaddr), .err_master(x_emst), .err_write(x_ewr),
    .ev_req_accept(x_acc), .ev_req_stall(x_stall), .ev_arb_loss(x_loss), .ev_rsp_stall(x_rstall));
  for (genvar s = 0; s < 2; s++) begin : g_sram
    logic [31:0] tr;
    sfb_sram_slave #(.DW(32), .DEPTH(8192), .READ_LATENCY(1)) u_m (
      .clk, .rst_n,
      .req_valid(s_req_valid[s]), .req_ready(s_req_ready[s]), .req_write(s_req_write[s]), .req_addr(s_req_addr[s*32 +: 32]),
      .req_wdata(s_req_wdata[s*32 +: 32]), .req_wstrb(s_req_wstrb[s*4 +: 4]),
      .rsp_valid(s_rsp_valid[s]), .rsp_ready(s_rsp_ready[s]), .rsp_rdata(s_rsp_rdata[s*32 +: 32]), .rsp_error(s_rsp_error[s]),
      .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tr));
  end

  // ============================================================ scratchpad (Module 04)
  wire  [NSP-1:0]     p_req_valid, p_req_we, p_rsp_ready;
  wire  [NSP*32-1:0]  p_req_addr, p_req_wdata;
  wire  [NSP*4-1:0]   p_req_wstrb;
  wire  [NSP*8-1:0]   p_req_tag;
  logic [NSP-1:0]     p_req_ready, p_rsp_valid, p_rsp_err, p_rsp_we;
  logic [NSP*32-1:0]  p_rsp_rdata;
  logic [NSP*8-1:0]   p_rsp_tag;
  logic [NSP*3-1:0]   p_rsp_code;
  logic [NSP*4-1:0]   p_rsp_syn;
  logic [NSP-1:0]     sp_acc, sp_iss, sp_conf, sp_cst, sp_err, sp_ecc;
  logic [7:0]         sp_bops;
  logic [3:0]         sp_bconf;
  logic [31:0]        sp_cyc, sp_eccn;
  logic [NSP*32-1:0]  sp_pacc, sp_piss, sp_pcpl, sp_pconf, sp_pwait, sp_perr;
  logic [127:0]       sp_pbops;
  logic               sp_busy;
  hpc_scratchpad #(.NUM_PORTS(NSP), .CAPACITY_BYTES(SPMB), .NUM_BANKS(4), .DATA_WIDTH(32), .ADDR_WIDTH(32),
                   .BASE_ADDR(64'(SPM_BASE)), .READ_LATENCY(1), .WRITE_ACK(1), .TAG_W(8)) u_spm (
    .clk, .rst_n,
    .req_valid(p_req_valid), .req_ready(p_req_ready), .req_we(p_req_we), .req_addr(p_req_addr),
    .req_wdata(p_req_wdata), .req_wstrb(p_req_wstrb), .req_tag(p_req_tag),
    .rsp_valid(p_rsp_valid), .rsp_ready(p_rsp_ready), .rsp_rdata(p_rsp_rdata), .rsp_err(p_rsp_err),
    .rsp_err_code(p_rsp_code), .rsp_we(p_rsp_we), .rsp_tag(p_rsp_tag), .rsp_ecc_syn(p_rsp_syn),
    .ev_accept(sp_acc), .ev_issue(sp_iss), .ev_conflict(sp_conf), .ev_credit_stall(sp_cst), .ev_error(sp_err),
    .ev_ecc_err(sp_ecc), .ev_bank_ops(sp_bops), .ev_bank_conflict(sp_bconf),
    .perf_clear(1'b0), .perf_cycles(sp_cyc), .perf_accept(sp_pacc), .perf_issue(sp_piss), .perf_complete(sp_pcpl),
    .perf_conflict(sp_pconf), .perf_wait(sp_pwait), .perf_error(sp_perr), .perf_bank_ops(sp_pbops),
    .perf_ecc_err(sp_eccn), .busy(sp_busy));

  // ============================================================ DMA adapter (Module 05)
  logic        cmd_valid = 1'b0, cmd_ready, cpl_valid, cpl_err;
  logic        d_cpl_ready = 1'b1;
  logic [31:0] cmd_src = '0, cmd_dst = '0, cmd_len = '0, cpl_err_addr, cpl_bytes, eng_bytes;
  logic [7:0]  cmd_tag = '0, cpl_tag, cur_tag;
  logic [3:0]  cpl_code;
  logic        d_busy, d_active, ev_cmd, ev_start, ev_cpl, ev_cpl_err, ev_stall, ev_berr, ev_terr;
  logic [1:0]  ctl_state;
  logic [2:0]  eng_state;
  logic [7:0]  fifo_level, ev_brd, ev_bwr, ev_out;
  logic [`HPC_DMA_NUM_PC*32-1:0] perf_cnt;
  hpc_dma_adapter #(.DW(32), .ENGINE(ENGINE), .FIFO_DEPTH(FIFO_DEPTH), .BURST(FIFO_DEPTH), .DUAL_PORT(DUAL_PORT),
                    .MAX_OUT(MAX_OUT), .SPM_BASE(SPM_BASE), .SPM_BYTES(SPMB), .SPM_TAG_W(8), .CMD_DEPTH(CMD_DEPTH),
                    .CPL_DEPTH(4), .TAG_W(8)) u_dma (
    .clk, .rst_n,
    .cmd_valid, .cmd_ready, .cmd_src, .cmd_dst, .cmd_len, .cmd_tag, .cmd_abort(1'b0),
    .cpl_valid, .cpl_ready(d_cpl_ready), .cpl_tag, .cpl_err, .cpl_code, .cpl_err_addr, .cpl_bytes,
    .busy(d_busy), .active(d_active), .cur_tag, .ctl_state, .eng_state, .eng_bytes_done(eng_bytes), .fifo_level,
    .spm_req_valid(p_req_valid[1 +: NP]), .spm_req_ready(p_req_ready[1 +: NP]), .spm_req_we(p_req_we[1 +: NP]),
    .spm_req_addr(p_req_addr[32 +: NP*32]), .spm_req_wdata(p_req_wdata[32 +: NP*32]), .spm_req_wstrb(p_req_wstrb[4 +: NP*4]),
    .spm_req_tag(p_req_tag[8 +: NP*8]), .spm_rsp_valid(p_rsp_valid[1 +: NP]), .spm_rsp_ready(p_rsp_ready[1 +: NP]),
    .spm_rsp_rdata(p_rsp_rdata[32 +: NP*32]), .spm_rsp_err(p_rsp_err[1 +: NP]), .spm_rsp_err_code(p_rsp_code[3 +: NP*3]),
    .spm_rsp_we(p_rsp_we[1 +: NP]), .spm_rsp_tag(p_rsp_tag[8 +: NP*8]),
    .fab_req_valid(m_req_valid[NP-1:0]), .fab_req_ready(m_req_ready[NP-1:0]), .fab_req_write(m_req_write[NP-1:0]),
    .fab_req_addr(m_req_addr[NP*32-1:0]), .fab_req_wdata(m_req_wdata[NP*32-1:0]), .fab_req_wstrb(m_req_wstrb[NP*4-1:0]),
    .fab_rsp_valid(m_rsp_valid[NP-1:0]), .fab_rsp_ready(m_rsp_ready[NP-1:0]), .fab_rsp_rdata(m_rsp_rdata[NP*32-1:0]),
    .fab_rsp_error(m_rsp_error[NP-1:0]),
    .ev_cmd_accept(ev_cmd), .ev_start, .ev_cpl, .ev_cpl_err, .ev_bytes_rd(ev_brd), .ev_bytes_wr(ev_bwr),
    .ev_req_stall(ev_stall), .ev_outstanding(ev_out), .ev_bus_err(ev_berr), .ev_tag_err(ev_terr),
    .perf_clear(1'b0), .perf_cnt);
  function automatic int unsigned pc(input int i);
    return perf_cnt[i*32 +: 32];
  endfunction

  // ============================================================ vector sequencer + vector array (Module 03 + obs port)
  logic        job_valid = 1'b0, job_ready, done_valid, done_illegal, done_err;
  logic [4:0]  job_op = '0, done_flags;
  logic [2:0]  job_rm = '0, job_bcast = '0;
  logic [15:0] job_vl = '0, done_count;
  logic [31:0] job_scalar = '0, job_a = '0, job_b = '0, job_c = '0, job_d = '0;
  logic [7:0]  job_tid = '0, done_tid;
  logic        v_busy;
  logic        c_valid, c_ready, o_valid, o_ready, r_valid, r_ready, k_valid, k_ready;
  logic [4:0]  c_op, k_flags;
  logic [2:0]  c_rm, c_bc;
  logic [15:0] c_vl, r_beat, k_count;
  logic [31:0] c_sc, k_result;
  logic [7:0]  c_tid, r_tid, k_tid;
  logic [N*32-1:0] o_a, o_b, o_c, r_data;
  logic [N*5-1:0]  r_flags;
  logic [N-1:0]    r_mask;
  logic            r_last, k_ill, k_red, va_busy;
  logic [hpc_varray_pkg::PC_N*32-1:0] va_perf;
  logic [N-1:0]    lane_hold = '0;
  logic [N-1:0]    ob_acc, ob_ret;
  logic [4:0]      ob_op;
  logic            ob_stl, ob_stt, ob_starve, ob_cqf;
  logic [$clog2(VA_CMD_DEPTH+1)-1:0] ob_cqc;
  hpc_tile_vseq #(.N(N), .VL_W(16), .TID_W(8), .SPM_TAG_W(8)) u_vseq (
    .clk, .rst_n,
    .job_valid, .job_ready, .job_op, .job_rm, .job_vl, .job_bcast, .job_scalar, .job_a, .job_b, .job_c, .job_d, .job_tid,
    .done_valid, .done_ready(1'b1), .done_tid, .done_flags, .done_illegal, .done_count, .done_err,
    .spm_req_valid(p_req_valid[0]), .spm_req_ready(p_req_ready[0]), .spm_req_we(p_req_we[0]), .spm_req_addr(p_req_addr[31:0]),
    .spm_req_wdata(p_req_wdata[31:0]), .spm_req_wstrb(p_req_wstrb[3:0]), .spm_req_tag(p_req_tag[7:0]),
    .spm_rsp_valid(p_rsp_valid[0]), .spm_rsp_ready(p_rsp_ready[0]), .spm_rsp_rdata(p_rsp_rdata[31:0]),
    .spm_rsp_err(p_rsp_err[0]), .spm_rsp_tag(p_rsp_tag[7:0]),
    .cmd_valid(c_valid), .cmd_ready(c_ready), .cmd_op(c_op), .cmd_rm(c_rm), .cmd_vl(c_vl), .cmd_bcast(c_bc),
    .cmd_scalar(c_sc), .cmd_tid(c_tid), .opnd_valid(o_valid), .opnd_ready(o_ready), .opnd_a(o_a), .opnd_b(o_b),
    .opnd_c(o_c), .res_valid(r_valid), .res_ready(r_ready), .res_data(r_data), .res_mask(r_mask),
    .cpl_valid(k_valid), .cpl_ready(k_ready), .cpl_flags(k_flags), .cpl_illegal(k_ill), .cpl_count(k_count),
    .busy(v_busy));
  hpc_vector_array #(.NUM_LANES(N), .VL_W(16), .TID_W(8), .CMD_DEPTH(VA_CMD_DEPTH)) u_va (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(c_valid), .cmd_ready_o(c_ready), .cmd_op_i(c_op), .cmd_rm_i(c_rm), .cmd_vl_i(c_vl), .cmd_vm_i(1'b0),
    .cmd_bcast_i(c_bc), .cmd_scalar_i(c_sc), .cmd_red_i(1'b0), .cmd_tid_i(c_tid),
    .opnd_valid_i(o_valid), .opnd_ready_o(o_ready), .opnd_a_i(o_a), .opnd_b_i(o_b), .opnd_c_i(o_c), .opnd_mask_i({N{1'b1}}),
    .res_valid_o(r_valid), .res_ready_i(r_ready), .res_data_o(r_data), .res_flags_o(r_flags), .res_mask_o(r_mask),
    .res_tid_o(r_tid), .res_beat_o(r_beat), .res_last_o(r_last),
    .cpl_valid_o(k_valid), .cpl_ready_i(k_ready), .cpl_tid_o(k_tid), .cpl_flags_o(k_flags), .cpl_illegal_o(k_ill),
    .cpl_count_o(k_count), .cpl_red_o(k_red), .cpl_result_o(k_result),
    .lane_hold_i(lane_hold), .busy_o(va_busy), .perf_clear_i(1'b0), .perf_cnt_o(va_perf),
    .obs_lane_accept_o(ob_acc), .obs_lane_retire_o(ob_ret), .obs_lane_op_o(ob_op), .obs_stall_lane_o(ob_stl),
    .obs_stall_trk_o(ob_stt), .obs_opnd_starve_o(ob_starve), .obs_cmdq_full_o(ob_cqf), .obs_cmdq_count_o(ob_cqc));
  function automatic int unsigned vpc(input int i);
    return va_perf[i*32 +: 32];
  endfunction

  // ============================================================ Module 07 telemetry unit
  logic        rb_sel = 1'b0, rb_we = 1'b0;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic        rb_err, pf_irq, pf_frozen, t_freeze = 1'b0;
  logic [NC*64-1:0] pf_cnt;
  hpc_perf_tile #(.N(N), .VL_W(16), .ROB_DEPTH(8), .CQ_W($clog2(VA_CMD_DEPTH+1)), .NSP(NSP), .DMA_NP(NP),
                  .DMA_BEAT_B(4), .DMA_CMDQ(CMD_DEPTH > 0), .FMA_FLOPS(2), .CMP_FLOPS(0), .EV_REG(EV_REG),
                  .INSTR_PHASE(INSTR_PHASE), .CNT_W(64), .INC_W(32), .SNAP_EN(1'b1), .PRELOAD_EN(1'b1),
                  .EN_RESET(1'b1), .PLATFORM(0), .CLK_KHZ(CLK_KHZ), .BUILD_ID(32'h0007_0001)) u_perf (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .va_cmd_valid(c_valid), .va_cmd_ready(c_ready), .va_cpl_valid(k_valid), .va_cpl_ready(k_ready),
    .va_cpl_illegal(k_ill), .va_cpl_red(k_red), .va_cpl_count(k_count), .va_res_valid(r_valid), .va_res_ready(r_ready),
    .va_busy, .va_lane_accept(ob_acc), .va_lane_retire(ob_ret), .va_lane_op(ob_op), .va_stall_lane(ob_stl),
    .va_stall_trk(ob_stt), .va_opnd_starve(ob_starve), .va_cmdq_full(ob_cqf), .va_cmdq_count(ob_cqc),
    .dma_cmd_valid(cmd_valid), .dma_cmd_ready(cmd_ready), .dma_cpl_valid(cpl_valid), .dma_cpl_ready(d_cpl_ready),
    .dma_cpl_err(cpl_err), .dma_active(d_active), .dma_bytes_rd(ev_brd), .dma_bytes_wr(ev_bwr),
    .dma_outstanding(ev_out), .dma_bus_err(ev_berr), .dma_tag_err(ev_terr),
    .spm_req_valid(p_req_valid), .spm_req_ready(p_req_ready), .spm_req_we(p_req_we), .spm_conflict(sp_conf),
    .spm_dec_err(sp_err), .spm_ecc_err(sp_ecc),
    .freeze_i(t_freeze), .snap_i(1'b0), .irq_o(pf_irq), .frozen_o(pf_frozen), .cnt_o(pf_cnt));

  // ============================================================ protocol checkers on every SFB2 link (as Module 05)
  logic [31:0] viol [0:NM+1];
  for (genvar g = 0; g < NM; g++) begin : g_cm
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(1), .NAME("tile_xbar_master")) u_c (
      .clk, .rst_n, .req_valid(m_req_valid[g]), .req_ready(m_req_ready[g]), .req_write(m_req_write[g]),
      .req_addr(m_req_addr[g*32 +: 32]), .req_wdata(m_req_wdata[g*32 +: 32]), .req_wstrb(m_req_wstrb[g*4 +: 4]),
      .rsp_valid(m_rsp_valid[g]), .rsp_ready(m_rsp_ready[g]), .rsp_rdata(m_rsp_rdata[g*32 +: 32]),
      .rsp_error(m_rsp_error[g]), .violations(viol[g]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  for (genvar g = 0; g < 2; g++) begin : g_cs
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(1), .NAME("tile_xbar_slave")) u_c (
      .clk, .rst_n, .req_valid(s_req_valid[g]), .req_ready(s_req_ready[g]), .req_write(s_req_write[g]),
      .req_addr(s_req_addr[g*32 +: 32]), .req_wdata(s_req_wdata[g*32 +: 32]), .req_wstrb(s_req_wstrb[g*4 +: 4]),
      .rsp_valid(s_rsp_valid[g]), .rsp_ready(s_rsp_ready[g]), .rsp_rdata(s_rsp_rdata[g*32 +: 32]),
      .rsp_error(s_rsp_error[g]), .violations(viol[NM+g]), .n_req(a), .n_rsp(b), .outstanding(c));
  end

  // ============================================================ stimulus disturbances (lane holds, DMA completion back-pressure)
  int unsigned dist_r = 32'h2468_ACE1;
  bit          dist_on = 1'b0;
  always @(negedge clk) begin
    dist_r = xs(dist_r);
    for (int l = 0; l < N; l++) begin
      dist_r = xs(dist_r);
      lane_hold[l] <= dist_on && (HOLD_PCT > 0) && ((dist_r % 100) < HOLD_PCT);
    end
    dist_r = xs(dist_r);
    d_cpl_ready <= !(dist_on && (CPL_BP_PCT > 0) && ((dist_r % 100) < CPL_BP_PCT));
  end

  // =====================================================================================================
  // MIRROR -- independent per-cycle model of every counter (docs/03_event_definitions.md)
  // =====================================================================================================
  // ---- raw lane pins (hierarchical: verifies the observation-port wiring too)
  logic [N-1:0] mr_acc, mr_ret;
  logic [4:0]   mr_op [0:N-1];
  for (genvar l = 0; l < N; l++) begin : g_mlane
    assign mr_acc[l] = u_va.g_lane[l].u_lane.in_valid_i & u_va.g_lane[l].u_lane.in_ready_o & u_va.g_lane[l].u_lane.lane_en_i;
    assign mr_ret[l] = u_va.g_lane[l].u_lane.out_valid_o & u_va.g_lane[l].u_lane.out_ready_i;
    assign mr_op[l]  = u_va.g_lane[l].u_lane.in_op_i;
  end
  function automatic int unsigned weight(input logic [4:0] op);   // the documented FLOP convention
    case (op)
      5'h01, 5'h02, 5'h03:        return 1;     // FADD FSUB FMUL
      5'h04, 5'h05, 5'h06, 5'h07: return 2;     // FMA family: 2 FLOPs (FMA_FLOPS = 2)
      default:                    return 0;     // FMV, compares (CMP_FLOPS = 0), integer
    endcase
  endfunction
  // in-order bookkeeping rings (portable: no queues).  Depth 16 > lane ROB_DEPTH 8 and > MAX_OUT.
  localparam int RQ = 16;
  int unsigned mw_b [0:N-1][0:RQ-1];             // per lane: FLOP weights of accepted, not yet retired ops
  int unsigned mw_h [0:N-1], mw_t [0:N-1];
  int unsigned fq_b [0:NP-1][0:RQ-1];            // per DMA fabric port: strobe bytes of outstanding requests
  bit          fq_w [0:NP-1][0:RQ-1];            //                       ... and whether each is a write
  int unsigned fq_h [0:NP-1], fq_t [0:NP-1];
  int unsigned sq_b [0:NP-1][0:RQ-1];            // per DMA scratchpad port: strobe bytes of outstanding writes
  int unsigned sq_h [0:NP-1], sq_t [0:NP-1];
  initial begin
    for (int l = 0; l < N; l++) begin mw_h[l] = 0; mw_t[l] = 0; end
    for (int q = 0; q < NP; q++) begin fq_h[q] = 0; fq_t[q] = 0; sq_h[q] = 0; sq_t[q] = 0; end
  end
  // ---- commands in flight
  int unsigned m_infl = 0;
  // ---- state of the mirrored bank (all updated with non-blocking assignments, like the hardware)
  logic [63:0] m_cnt [0:NC-1];
  logic [63:0] m_snp [0:NC-1];
  logic        m_ovf [0:NC-1];
  logic [31:0] m_ev_d [0:NC-1];                  // EV_REG stage
  logic        m_frz_d = 1'b0;
  logic        m_en = 1'b1, m_frz = 1'b0;
  logic [31:0] m_cnt_en = 32'hFFFF_FFFF, m_sat = 32'h0;
  logic [63:0] m_pre = '0;
  logic [7:0]  m_errsrc = '0, m_errsrc_d = '0;
  initial for (int i = 0; i < NC; i++) begin m_cnt[i] = '0; m_snp[i] = '0; m_ovf[i] = 1'b0; m_ev_d[i] = '0; end

  function automatic int phase_of(input int i);
    if (i == `HPC_PC_CYCLES || i == `HPC_PC_VEC_RETIRED || i == `HPC_PC_FLOPS_RETIRED || i == `HPC_PC_VEC_STALL ||
        i == `HPC_PC_DMA_BYTES_RD || i == `HPC_PC_DMA_BYTES_WR) return 1;
    if (i <= `HPC_PC_HW_ERRORS) return 2;
    return 3;
  endfunction

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NC; i++) begin m_cnt[i] <= '0; m_snp[i] <= '0; m_ovf[i] <= 1'b0; m_ev_d[i] <= '0; end
      m_frz_d <= 1'b0; m_en <= 1'b1; m_frz <= 1'b0; m_cnt_en <= 32'hFFFF_FFFF; m_sat <= '0; m_pre <= '0;
      m_errsrc <= '0; m_errsrc_d <= '0;
      for (int l = 0; l < N; l++) begin mw_h[l] = 0; mw_t[l] = 0; end
      for (int q = 0; q < NP; q++) begin fq_h[q] = 0; fq_t[q] = 0; sq_h[q] = 0; sq_t[q] = 0; end
      m_infl = 0;
    end else begin
      int unsigned ev [0:NC-1];
      int unsigned lane_fl, n_ret, n_acc, red, n_rd, n_wr, b_rd, b_wr, n_err;
      bit          bstall, starve, cqfull, outbp, acc_v, acc_d, cpl_v, cpl_d;
      logic [7:0]  esrc;
      // -------------------------------------------------------------- raw events of this cycle
      lane_fl = 0; n_ret = 0; n_acc = 0;
      for (int l = 0; l < N; l++) begin
        if (mr_ret[l]) begin
          if (mw_h[l] == mw_t[l]) err($sformatf("mirror: lane %0d retired with nothing accepted", l));
          else begin lane_fl += mw_b[l][mw_h[l] % RQ]; mw_h[l]++; end
          n_ret++;
        end
        if (mr_acc[l]) begin
          if (mw_t[l] - mw_h[l] >= RQ) err("mirror: lane ring overflow");
          mw_b[l][mw_t[l] % RQ] = weight(mr_op[l]); mw_t[l]++; n_acc++;
        end
      end
      red = (k_valid && k_ready && k_red && !k_ill) ? int'(k_count) : 0;
      // issue stage: a beat is due (beat phase) and is not released this cycle
      bstall = u_va.u_issue.beat_ph && !(o_valid && o_ready);
      starve = u_va.u_issue.beat_ph && !o_valid;
      // DMA bytes, from the adapter's bus responses (scratchpad ports 1.., fabric ports 0..NP-1)
      b_rd = 0; b_wr = 0;
      for (int p = 0; p < NP; p++) begin
        if (p_rsp_valid[1+p] && p_rsp_ready[1+p]) begin
          int unsigned nbw;
          nbw = 0;
          if (p_rsp_we[1+p]) begin                              // every write acknowledgement retires its request
            if (sq_h[p] == sq_t[p]) err("mirror: scratchpad write acknowledgement without request");
            else begin nbw = sq_b[p][sq_h[p] % RQ]; sq_h[p]++; end
          end
          if (!p_rsp_err[1+p]) begin
            if (p_rsp_we[1+p]) b_wr += nbw;
            else b_rd += 4;
          end
        end
        if (m_rsp_valid[p] && m_rsp_ready[p]) begin
          int unsigned nb;
          bit w;
          if (fq_h[p] == fq_t[p]) err("mirror: fabric response without request");
          else begin
            nb = fq_b[p][fq_h[p] % RQ]; w = fq_w[p][fq_h[p] % RQ]; fq_h[p]++;
            if (!m_rsp_error[p]) begin if (w) b_wr += nb; else b_rd += 4; end
          end
        end
        if (m_req_valid[p] && m_req_ready[p]) begin
          fq_b[p][fq_t[p] % RQ] = $countones(m_req_wstrb[p*4 +: 4]); fq_w[p][fq_t[p] % RQ] = m_req_write[p]; fq_t[p]++;
        end
        if (p_req_valid[1+p] && p_req_ready[1+p] && p_req_we[1+p]) begin
          sq_b[p][sq_t[p] % RQ] = $countones(p_req_wstrb[(1+p)*4 +: 4]); sq_t[p]++;
        end
      end
      n_rd = 0; n_wr = 0;
      for (int p = 0; p < NSP; p++) if (p_req_valid[p] && p_req_ready[p]) begin if (p_req_we[p]) n_wr++; else n_rd++; end
      cqfull = (u_va.u_issue.u_cq.cnt_q == VA_CMD_DEPTH) || (CMD_DEPTH > 0 && !cmd_ready);
      outbp  = (r_valid && !r_ready) || (k_valid && !k_ready) || (cpl_valid && !d_cpl_ready);
      acc_v  = c_valid && c_ready;  acc_d = cmd_valid && cmd_ready;
      cpl_v  = k_valid && k_ready;  cpl_d = cpl_valid && d_cpl_ready;
      esrc = '0;
      esrc[`HPC_ERR_VEC_ILLEGAL]    = cpl_v && k_ill;
      esrc[`HPC_ERR_DMA_CPL_ERR]    = cpl_d && cpl_err;
      esrc[`HPC_ERR_DMA_BUS_ERR]    = ev_berr;
      esrc[`HPC_ERR_DMA_TAG_ERR]    = ev_terr;
      esrc[`HPC_ERR_SPM_ECC_ERR]    = |sp_ecc;
      esrc[`HPC_ERR_SPM_DECODE_ERR] = |sp_err;
      n_err = int'(esrc[0]) + int'(esrc[1]) + int'(esrc[2]) + int'(esrc[3]) + $countones(sp_ecc) + $countones(sp_err);
      ev[`HPC_PC_CYCLES]            = 1;
      ev[`HPC_PC_CMD_ACCEPTED]      = int'(acc_v) + int'(acc_d);
      ev[`HPC_PC_CMD_COMPLETED]     = int'(cpl_v) + int'(cpl_d);
      ev[`HPC_PC_VEC_ISSUED]        = n_acc;
      ev[`HPC_PC_VEC_RETIRED]       = n_ret;
      ev[`HPC_PC_FLOPS_RETIRED]     = lane_fl + red;
      ev[`HPC_PC_VEC_STALL]         = bstall;
      ev[`HPC_PC_DMA_ACTIVE]        = d_active;
      ev[`HPC_PC_DMA_BYTES_RD]      = b_rd;
      ev[`HPC_PC_DMA_BYTES_WR]      = b_wr;
      ev[`HPC_PC_SPM_READS]         = n_rd;
      ev[`HPC_PC_SPM_WRITES]        = n_wr;
      ev[`HPC_PC_SPM_CONFLICTS]     = $countones(sp_conf);
      ev[`HPC_PC_CMDQ_FULL]         = cqfull;
      ev[`HPC_PC_OUT_BP]            = outbp;
      ev[`HPC_PC_HW_ERRORS]         = n_err;
      ev[`HPC_PC_VEC_BUSY]          = va_busy;
      ev[`HPC_PC_VEC_OPND_STARVE]   = starve;
      ev[`HPC_PC_CMD_INFLIGHT_SUM]  = m_infl;
      ev[`HPC_PC_VEC_CMDQ_OCC_SUM]  = int'(u_va.u_issue.u_cq.cnt_q);
      ev[`HPC_PC_DMA_OUT_SUM]       = int'(ev_out);
      ev[`HPC_PC_RED_ADDS]          = red;
      ev[`HPC_PC_VEC_CMD_COMPLETED] = cpl_v;
      for (int i = 0; i < NC; i++) if (phase_of(i) > INSTR_PHASE) ev[i] = 0;
      m_infl = m_infl + int'(acc_v) + int'(acc_d) - int'(cpl_v) - int'(cpl_d);
      // -------------------------------------------------------------- the mirrored bank
      begin
        bit          w, clr_all, snap;
        logic [31:0] clr_m, pre_m, w1c_m;
        bit          go;
        w = rb_sel && rb_we;
        clr_all = w && rb_addr == `HPC_PR_CTRL && rb_wdata[`HPC_CTRL_CLEAR];
        snap    = w && rb_addr == `HPC_PR_CTRL && rb_wdata[`HPC_CTRL_SNAPSHOT];
        clr_m   = (w && rb_addr == `HPC_PR_CLR) ? rb_wdata : '0;
        pre_m   = (w && rb_addr == `HPC_PR_PRE_LOAD) ? rb_wdata : '0;
        w1c_m   = (w && rb_addr == `HPC_PR_OVF) ? rb_wdata : '0;
        go = m_en && !m_frz && !(EV_REG ? m_frz_d : t_freeze);
        for (int i = 0; i < NC; i++) begin
          logic [64:0] s;
          logic [31:0] e;
          e = EV_REG ? m_ev_d[i] : 32'(ev[i]);
          if (!(go && m_cnt_en[i])) e = 0;
          s = {1'b0, m_cnt[i]} + 65'(e);
          if (snap) m_snp[i] <= m_cnt[i];
          if (clr_all || clr_m[i]) begin m_cnt[i] <= '0; m_ovf[i] <= 1'b0; end
          else if (pre_m[i]) m_cnt[i] <= m_pre;
          else begin
            m_cnt[i] <= (s[64] && m_sat[i]) ? 64'hFFFF_FFFF_FFFF_FFFF : s[63:0];
            m_ovf[i] <= (m_ovf[i] && !w1c_m[i]) || s[64];
          end
          m_ev_d[i] <= 32'(ev[i]);
        end
        m_frz_d <= t_freeze;
        if (w && rb_addr == `HPC_PR_CTRL) begin m_en <= rb_wdata[`HPC_CTRL_ENABLE]; m_frz <= rb_wdata[`HPC_CTRL_FREEZE]; end
        if (w && rb_addr == `HPC_PR_CNT_EN) m_cnt_en <= rb_wdata;
        if (w && rb_addr == `HPC_PR_SAT) m_sat <= rb_wdata;
        if (w && rb_addr == `HPC_PR_PRE_LO) m_pre[31:0] <= rb_wdata;
        if (w && rb_addr == `HPC_PR_PRE_HI) m_pre[63:32] <= rb_wdata;
        m_errsrc <= (m_errsrc & ~((w && rb_addr == `HPC_PR_ERR_SRC) ? rb_wdata[7:0] : 8'd0)) | (EV_REG ? m_errsrc_d : esrc);
        m_errsrc_d <= esrc;
      end
    end
  end
  // ============================================================ register-bus BFM (tasks start / end just after a negedge)
  logic [63:0] bus_m_pre [0:NC-1];               // mirror at the start of the last strobe cycle
  logic [63:0] bus_hw_pre [0:NC-1];              // hardware live counters at the start of the last strobe cycle
  bit          rb_lock = 1'b0;
  int unsigned bus_m05_cyc = 0;                  // Module 05 cycle counter in the last strobe cycle
  task automatic bus(input bit we, input logic [11:0] a, input logic [31:0] d, output logic [31:0] q);
    while (rb_lock) @(negedge clk);
    rb_lock = 1'b1;
    rb_sel <= 1'b1; rb_we <= we; rb_addr <= a; rb_wdata <= d;
    @(posedge clk);
    q = rb_rdata;
    if (rb_err) err($sformatf("register access %s 0x%03h refused", we ? "write" : "read", a));
    for (int i = 0; i < NC; i++) begin bus_m_pre[i] = m_cnt[i]; bus_hw_pre[i] = pf_cnt[i*64 +: 64]; end
    bus_m05_cyc = pc(`HPC_DMA_PC_CYCLES);
    @(negedge clk);
    rb_sel <= 1'b0; rb_we <= 1'b0;
    rb_lock = 1'b0;
  endtask
  task automatic rwr(input logic [11:0] a, input logic [31:0] d);
    logic [31:0] q;
    bus(1'b1, a, d, q);
  endtask
  task automatic rrd(input logic [11:0] a, output logic [31:0] q);
    bus(1'b0, a, 32'd0, q);
  endtask

  // ============================================================ perf checks against the mirror
  int unsigned n_snap_chk = 0, n_live_chk = 0, n_b2b_chk = 0;
  function automatic string cname(input int i);
    case (i)
      0: return "CYCLES"; 1: return "CMD_ACCEPTED"; 2: return "CMD_COMPLETED"; 3: return "VEC_ISSUED";
      4: return "VEC_RETIRED"; 5: return "FLOPS_RETIRED"; 6: return "VEC_STALL"; 7: return "DMA_ACTIVE";
      8: return "DMA_BYTES_RD"; 9: return "DMA_BYTES_WR"; 10: return "SPM_READS"; 11: return "SPM_WRITES";
      12: return "SPM_CONFLICTS"; 13: return "CMDQ_FULL"; 14: return "OUT_BP"; 15: return "HW_ERRORS";
      16: return "VEC_BUSY"; 17: return "VEC_OPND_STARVE"; 18: return "CMD_INFLIGHT_SUM"; 19: return "VEC_CMDQ_OCC_SUM";
      20: return "DMA_OUT_SUM"; 21: return "RED_ADDS"; default: return "VEC_CMD_COMPLETED";
    endcase
  endfunction
  // coherent snapshot of every counter, compared with the mirror at the snapshot cycle
  logic [63:0] last_snap [0:NC-1];
  int unsigned snap_m05_cyc = 0;
  task automatic snap_check(input string where);
    logic [63:0] exp [0:NC-1];
    logic [31:0] lo, hi;
    rwr(`HPC_PR_CTRL, 32'(m_en) << `HPC_CTRL_ENABLE | 32'(m_frz) << `HPC_CTRL_FREEZE | 32'd1 << `HPC_CTRL_SNAPSHOT);
    for (int i = 0; i < NC; i++) exp[i] = bus_m_pre[i];
    snap_m05_cyc = bus_m05_cyc;
    for (int i = 0; i < NC; i++) begin
      rrd(12'(`HPC_PR_SNAP_BASE + 8*i), lo);
      rrd(12'(`HPC_PR_SNAP_BASE + 8*i + 4), hi);
      last_snap[i] = {hi, lo};
      chk({hi, lo} == exp[i], $sformatf("%s: SNAP %s = %0d, mirror %0d", where, cname(i), {hi, lo}, exp[i]));
      if (phase_of(i) > INSTR_PHASE) chk({hi, lo} == 0, $sformatf("%s: %s counted above INSTR_PHASE", where, cname(i)));
    end
    n_snap_chk++;
  endtask
  // one live LO/HI pair of counter i, compared with the mirror at the LO-read cycle
  task automatic live_check(input int i, input string where);
    logic [31:0] lo, hi;
    logic [63:0] exp;
    rrd(12'(`HPC_PR_LIVE_BASE + 8*i), lo);
    exp = bus_m_pre[i];
    rrd(12'(`HPC_PR_LIVE_BASE + 8*i + 4), hi);
    chk({hi, lo} == exp, $sformatf("%s: LIVE %s = %0d, mirror %0d", where, cname(i), {hi, lo}, exp));
    n_live_chk++;
  endtask
  // back-to-back reads (consecutive cycles) of LIVE_LO[CYCLES]: +1 per cycle while counting
  task automatic b2b_check();
    logic [31:0] q [0:5];
    logic [31:0] qt;                              // scalar temporary: Icarus 12 cannot return into q[k]
    for (int k = 0; k < 6; k++) begin rrd(12'(`HPC_PR_LIVE_BASE + 8*`HPC_PC_CYCLES), qt); q[k] = qt; end
    if (m_en && !m_frz && !t_freeze)
      for (int k = 1; k < 6; k++) chk(q[k] == q[k-1] + 1, $sformatf("back-to-back CYCLES reads %0d, %0d", q[k-1], q[k]));
    n_b2b_chk++;
  endtask
  // background checker during the workload (does not disturb counting)
  bit mon_run = 1'b0;
  task automatic perf_monitor();
    int unsigned r;
    r = 32'h0BAD_5EED;
    while (mon_run) begin
      r = xs(r);
      repeat (40 + r % 300) @(negedge clk);
      if (mon_run) begin
        r = xs(r);
        case (r % 4)
          0:       snap_check("during activity");
          1, 2:    live_check(int'(xs(r) % NC), "during activity");
          default: b2b_check();
        endcase
      end
    end
  endtask

  // ============================================================ memory images and backdoors (as Module 05)
  logic [31:0] ext_init [0:EXTB/4-1];
  logic [31:0] spm_init [0:SPMB/4-1];
  logic [31:0] exp_ext  [0:EXTB/4-1];
  logic [31:0] exp_spm  [0:SPMB/4-1];
  logic [63:0] host_ops [0:IG_NOPS-1];
  int  bd_seq = 0, bd_cmd = 0;
  logic [3:0] bd_ack;
  logic [31:0] spm_dump [0:SPMB/4-1];
  for (genvar b = 0; b < 4; b++) begin : g_bd
    int ack_seq = 0;
    assign bd_ack[b] = (ack_seq == bd_seq);
    always @(bd_seq) if (bd_seq != 0) begin
      for (int r = 0; r < SPMB / 16; r++)
        if (bd_cmd == 1) u_spm.g_core.g_bank[b].u_bank.g_ram.u_ram.g_generic.u_mem.mem[r] = spm_init[r*4 + b];
        else spm_dump[r*4 + b] = u_spm.g_core.g_bank[b].u_bank.g_ram.u_ram.g_generic.u_mem.mem[r];
      ack_seq = bd_seq;
    end
  end
  task automatic bd_do(input int c);
    bd_cmd = c; bd_seq = bd_seq + 1; #0.001; wait (bd_ack == 4'hF);
  endtask
  function automatic logic [31:0] ext_word(input int w);
    if (w < 8192) return g_sram[0].u_m.u_sram.u_array.g_generic.u_mem.mem[w];
    return g_sram[1].u_m.u_sram.u_array.g_generic.u_mem.mem[w - 8192];
  endfunction

  // ============================================================ host BFM (crossbar master NP)
  logic        h_v = 1'b0, h_w = 1'b0;
  logic [31:0] h_a = '0, h_d = '0;
  logic [3:0]  h_s = '0;
  assign m_req_valid[NP] = h_v;
  assign m_req_write[NP] = h_w;
  assign m_req_addr[NP*32 +: 32] = h_a;
  assign m_req_wdata[NP*32 +: 32] = h_d;
  assign m_req_wstrb[NP*4 +: 4] = h_s;
  assign m_rsp_ready[NP] = 1'b1;
  int unsigned h_req_n = 0, h_rsp_n = 0;
  logic [31:0] h_rdata = '0;
  logic        h_rerr = 1'b0;
  always @(posedge clk) if (rst_n) begin
    if (h_v && m_req_ready[NP]) h_req_n++;
    if (m_rsp_valid[NP]) begin h_rsp_n++; h_rdata = m_rsp_rdata[NP*32 +: 32]; h_rerr = m_rsp_error[NP]; end
  end
  task automatic host_access(input logic w, input logic [31:0] a, input logic [31:0] d, input logic [3:0] s,
                             output logic [31:0] rd);
    int unsigned k, r;
    k = h_req_n; r = h_rsp_n;
    h_v <= 1'b1; h_w <= w; h_a <= a; h_d <= d; h_s <= s;
    while (h_req_n == k) @(posedge clk or negedge clk);
    h_v <= 1'b0;
    while (h_rsp_n == r) @(posedge clk or negedge clk);
    if (h_rerr) err($sformatf("host access %h answered with an error", a));
    rd = h_rdata;
  endtask

  // ============================================================ DMA driver + completion collector (handshake based)
  int unsigned d_hs_n = 0, n_cpl = 0, bytes_moved = 0, bytes_read_words = 0, n_cpl_err = 0;
  bit          cpl_seen [0:255];
  logic [31:0] cpl_len  [0:255];
  bit          cpl_expect_err [0:255];
  int unsigned dma_tag = 0;
  always @(posedge clk) if (rst_n && cmd_valid && cmd_ready) d_hs_n++;
  always @(posedge clk) if (rst_n && cpl_valid && d_cpl_ready) begin
    if (cpl_seen[cpl_tag]) err($sformatf("duplicate completion for tag %0d", cpl_tag));
    if (cpl_expect_err[cpl_tag]) begin
      if (cpl_code == 0) err($sformatf("DMA tag %0d: expected an error completion", cpl_tag));
      n_cpl_err++;
    end else begin
      if (cpl_code != 0) err($sformatf("DMA tag %0d failed: code %0d at %h", cpl_tag, cpl_code, cpl_err_addr));
      if (cpl_bytes != cpl_len[cpl_tag]) err($sformatf("DMA tag %0d: %0d bytes of %0d", cpl_tag, cpl_bytes, cpl_len[cpl_tag]));
      bytes_moved += cpl_bytes;
      bytes_read_words += 4 * ((cpl_len[cpl_tag] + 3) / 4);
    end
    cpl_seen[cpl_tag] = 1'b1; n_cpl++;
  end
  bit dma_lock = 1'b0;
  task automatic dma_x(input logic [31:0] s, input logic [31:0] d, input logic [31:0] n, input bit expect_err,
                       output int unsigned tag);
    int unsigned k;
    while (dma_lock) @(posedge clk);
    dma_lock = 1'b1;
    tag = dma_tag % 256; dma_tag++;
    cpl_seen[tag] = 1'b0; cpl_len[tag] = n; cpl_expect_err[tag] = expect_err;
    k = d_hs_n;
    cmd_valid <= 1'b1; cmd_src <= s; cmd_dst <= d; cmd_len <= n; cmd_tag <= 8'(tag);
    while (d_hs_n == k) @(posedge clk or negedge clk);
    cmd_valid <= 1'b0;
    @(negedge clk);
    dma_lock = 1'b0;
  endtask
  task automatic dma(input logic [31:0] s, input logic [31:0] d, input logic [31:0] n, output int unsigned tag);
    dma_x(s, d, n, 1'b0, tag);
  endtask
  task automatic dma_wait(input int unsigned tag);
    while (!cpl_seen[tag]) @(posedge clk);
  endtask

  // ============================================================ vector job driver
  int unsigned j_hs_n = 0, j_done_n = 0, sum_vl = 0, sum_flops = 0, n_jobs = 0;
  logic [7:0]  j_last_tid;
  bit          j_expect_ill = 1'b0;
  always @(posedge clk) if (rst_n && job_valid && job_ready) j_hs_n++;
  always @(posedge clk) if (rst_n && done_valid) begin
    j_done_n++; j_last_tid = done_tid;
    if (done_err) err($sformatf("vector job %0d: scratchpad error", done_tid));
    if (done_illegal != j_expect_ill) err($sformatf("vector job %0d: illegal = %0d", done_tid, done_illegal));
  end
  task automatic vjob(input logic [4:0] op, input logic [2:0] bc, input logic [31:0] sc, input logic [31:0] a,
                      input logic [31:0] b, input logic [31:0] c, input logic [31:0] d, input int vl, input logic [7:0] tid);
    int unsigned k, dn;
    k = j_hs_n; dn = j_done_n;
    job_valid <= 1'b1; job_op <= op; job_rm <= 3'd0; job_vl <= 16'(vl); job_bcast <= bc; job_scalar <= sc;
    job_a <= a; job_b <= b; job_c <= c; job_d <= d; job_tid <= tid;
    while (j_hs_n == k) @(posedge clk or negedge clk);
    job_valid <= 1'b0;
    while (j_done_n == dn) @(posedge clk);
    if (j_last_tid !== tid) err("vector done record out of order");
    if (!j_expect_ill && int'(done_count) != vl) err($sformatf("vector job %0d: %0d elements computed of %0d", tid, done_count, vl));
    if (!j_expect_ill) begin sum_vl += vl; sum_flops += vl * weight(op); end
    n_jobs++;
  endtask

  // ============================================================ phase B: host background traffic + double-buffered AXPY (as Module 05)
  bit          bg_run = 1'b0;
  int unsigned bg_ops = 0;
  logic [31:0] bg_sh [0:IG_HSCR_BYTES/4-1];
  task automatic host_background();
    int unsigned r;
    logic [31:0] rd;
    r = 32'h1357;
    for (int i = 0; i < IG_HSCR_BYTES / 4; i++) bg_sh[i] = ext_word(int'(IG_HSCR - EXT_BASE) / 4 + i);
    while (bg_run) begin
      int w;
      r = xs(r); w = int'(r % (IG_HSCR_BYTES / 4));
      r = xs(r);
      if (r[0]) begin host_access(1'b1, IG_HSCR + 32'(w * 4), r, 4'hF, rd); bg_sh[w] = r; end
      else begin
        host_access(1'b0, IG_HSCR + 32'(w * 4), '0, 4'h0, rd);
        if (rd !== bg_sh[w]) err($sformatf("host background read %h = %h, expected %h", IG_HSCR + 32'(w*4), rd, bg_sh[w]));
      end
      bg_ops++;
    end
  endtask
  bit in_done [0:15];
  bit comp_done [0:15];
  bit out_done [0:15];
  task automatic th_in();
    for (int k = 0; k < IG_K; k++) begin
      int unsigned tx, ty;
      if (k >= 2) while (!comp_done[k-2]) @(posedge clk);
      dma(IG_X + 32'(k * IG_TILE_STRIDE), IG_SX + 32'((k % 2) * IG_TILE_STRIDE), 32'(4 * IG_T), tx);
      dma(IG_Y + 32'(k * IG_TILE_STRIDE), IG_SY + 32'((k % 2) * IG_TILE_STRIDE), 32'(4 * IG_T), ty);
      dma_wait(tx); dma_wait(ty);
      in_done[k] = 1'b1;
    end
  endtask
  task automatic th_comp();
    for (int k = 0; k < IG_K; k++) begin
      while (!in_done[k]) @(posedge clk);
      if (k >= 2) while (!out_done[k-2]) @(posedge clk);
      vjob(5'h04, 3'b001, IG_ALPHA, 32'd0, IG_SX + 32'((k % 2) * IG_TILE_STRIDE), IG_SY + 32'((k % 2) * IG_TILE_STRIDE),
           IG_SZ + 32'((k % 2) * IG_TILE_STRIDE), IG_T, 8'(16 + k));
      comp_done[k] = 1'b1;
    end
  endtask
  task automatic th_out();
    for (int k = 0; k < IG_K; k++) begin
      int unsigned tz;
      while (!comp_done[k]) @(posedge clk);
      dma(IG_SZ + 32'((k % 2) * IG_TILE_STRIDE), IG_Z + 32'(k * IG_TILE_STRIDE), 32'(4 * IG_T), tz);
      dma_wait(tz);
      out_done[k] = 1'b1;
    end
  endtask

  // burst of 6 descriptors issued back to back (re-copies operand data already in place)
  int unsigned burst_tag [0:5];
  task automatic dma_burst();
    int unsigned qt;
    for (int k = 0; k < 6; k++) begin dma(IG_A + 32'(256 * k), IG_SA + 32'(256 * k), 32'd256, qt); burst_tag[k] = qt; end
    for (int k = 0; k < 6; k++) dma_wait(burst_tag[k]);
  endtask
  int unsigned cov_dma_qfull = 0;
  always @(posedge clk) if (rst_n && CMD_DEPTH > 0 && !cmd_ready) cov_dma_qfull++;

  // ============================================================ helpers for the end-of-test checks
  task automatic wait_quiet();
    int unsigned q;
    q = 0;
    while (q < 20) begin
      @(negedge clk);
      if (d_busy || v_busy || va_busy || sp_busy || cpl_valid || cmd_valid || job_valid) q = 0; else q++;
    end
  endtask
  function automatic logic [63:0] sv(input int i);
    return last_snap[i];
  endfunction
  // raw register dump (JSON) for host/hpc_perf_telemetry.py
  task automatic dump_json(input string fn, input string label);
    int fd;
    logic [31:0] q;
    fd = $fopen(fn, "w");
    $fwrite(fd, "{\n  \"format\": \"hpc_perf_regdump/1\",\n  \"producer\": \"tb/tb_hpc_tile_perf.sv\",\n");
    $fwrite(fd, "  \"label\": \"%s\",\n  \"simulator_cycle\": %0d,\n", label, cyc);
    $fwrite(fd, "  \"tb_config\": {\"ENGINE\": %0d, \"DUAL_PORT\": %0d, \"NUM_LANES\": %0d, \"HOLD_PCT\": %0d, \"CPL_BP_PCT\": %0d, \"EV_REG\": %0d, \"INSTR_PHASE\": %0d},\n",
            ENGINE, DUAL_PORT, N, HOLD_PCT, CPL_BP_PCT, EV_REG, INSTR_PHASE);
    $fwrite(fd, "  \"workload\": {\"vector_jobs\": %0d, \"sum_vl\": %0d, \"dma_descriptors\": %0d, \"dma_bytes_written\": %0d},\n",
            n_jobs, sum_vl, dma_tag, bytes_moved);
    $fwrite(fd, "  \"registers\": {\n");
    rrd(`HPC_PR_ID, q);       $fwrite(fd, "    \"ID\": %0d,\n", q);
    rrd(`HPC_PR_VERSION, q);  $fwrite(fd, "    \"VERSION\": %0d,\n", q);
    rrd(`HPC_PR_INFO, q);     $fwrite(fd, "    \"INFO\": %0d,\n", q);
    rrd(`HPC_PR_TILECFG, q);  $fwrite(fd, "    \"TILECFG\": %0d,\n", q);
    rrd(`HPC_PR_CLK_KHZ, q);  $fwrite(fd, "    \"CLK_KHZ\": %0d,\n", q);
    rrd(`HPC_PR_BUILD_ID, q); $fwrite(fd, "    \"BUILD_ID\": %0d,\n", q);
    rrd(`HPC_PR_CTRL, q);     $fwrite(fd, "    \"CTRL\": %0d,\n", q);
    rrd(`HPC_PR_STATUS, q);   $fwrite(fd, "    \"STATUS\": %0d,\n", q);
    rrd(`HPC_PR_CNT_EN, q);   $fwrite(fd, "    \"CNT_EN\": %0d,\n", q);
    rrd(`HPC_PR_SAT, q);      $fwrite(fd, "    \"SAT\": %0d,\n", q);
    rrd(`HPC_PR_SNAP_OVF, q); $fwrite(fd, "    \"SNAP_OVF\": %0d,\n", q);
    rrd(`HPC_PR_ERR_SRC, q);  $fwrite(fd, "    \"ERR_SRC\": %0d\n  },\n", q);
    $fwrite(fd, "  \"snapshot\": {\n");
    for (int i = 0; i < NC; i++) $fwrite(fd, "    \"%s\": %0d%s\n", cname(i), sv(i), (i == NC - 1) ? "" : ",");
    $fwrite(fd, "  }\n}\n");
    $fclose(fd);
  endtask

  // ============================================================ main
  initial begin
    int unsigned t0, t1, t2, t3, t4, tc, td, ta;
    logic [31:0] rd;
    $readmemh("ext_init.hex", ext_init);
    $readmemh("spm_init.hex", spm_init);
    $readmemh("exp_ext.hex", exp_ext);
    $readmemh("exp_spm.hex", exp_spm);
    $readmemh("host_ops.hex", host_ops);
    #1;
    for (int w = 0; w < 8192; w++) begin
      g_sram[0].u_m.u_sram.u_array.g_generic.u_mem.mem[w] = ext_init[w];
      g_sram[1].u_m.u_sram.u_array.g_generic.u_mem.mem[w] = ext_init[8192 + w];
    end
    bd_do(1);
    for (int i = 0; i < 256; i++) begin cpl_seen[i] = 1'b0; cpl_expect_err[i] = 1'b0; end
    for (int i = 0; i < 16; i++) begin in_done[i] = 0; comp_done[i] = 0; out_done[i] = 0; end
    repeat (3) @(negedge clk);
    rst_n = 1'b1;
    @(negedge clk);
    dist_on = 1'b1;
    mon_run = 1'b1;
    fork perf_monitor(); join_none

    // ---------------------------------------------------------- phase A (Module 05 sequence)
    t0 = cyc;
    for (int i = 0; i < IG_NOPS; i++) host_access(1'b1, host_ops[i][63:32], host_ops[i][31:0], 4'hF, rd);
    t1 = cyc;
    begin
      int unsigned qa, qb, qc;
      dma(IG_A, IG_SA, 32'(4 * IG_VA), qa); dma(IG_B, IG_SB, 32'(4 * IG_VA), qb); dma(IG_C, IG_SC, 32'(4 * IG_VA), qc);
      dma_wait(qa); dma_wait(qb); dma_wait(qc);
    end
    t2 = cyc;
    vjob(5'h04, 3'b000, 32'd0, IG_SA, IG_SB, IG_SC, IG_SD, IG_VA, 8'd1);          // D = A*B + C  (FMADD)
    vjob(5'h01, 3'b010, IG_SCALAR, IG_SA, 32'd0, 32'd0, IG_SE, IG_VA, 8'd2);     // E = A + s    (FADD, bcast b)
    vjob(5'h11, 3'b000, 32'd0, IG_SA, IG_SB, 32'd0, IG_SF, IG_VA, 8'd3);         // F = A*B mod 2^32 (IMUL)
    t3 = cyc;
    begin
      int unsigned qd, qe, qf;
      dma(IG_SD, IG_D, 32'(4 * IG_VA), qd); dma(IG_SE, IG_E, 32'(IG_E_LEN), qe); dma(IG_SF, IG_F, 32'(4 * IG_VA), qf);
      dma_wait(qd); dma_wait(qe); dma_wait(qf);
    end
    t4 = cyc;
    snap_check("after phase A");
    dump_json("regdump_phaseA.json", "after phase A (sequential: host writes, DMA in, 3 vector jobs, DMA out)");
    // ---------------------------------------------------------- phase B (Module 05 concurrent AXPY)
    bg_run = 1'b1;
    tc = cyc;
    fork
      th_in();
      th_comp();
      th_out();
      host_background();
      begin while (!out_done[IG_K - 1]) @(posedge clk); bg_run = 1'b0; end
    join
    td = cyc;
    mon_run = 1'b0;
    dist_on = 1'b0;
    wait_quiet();

    // ---------------------------------------------------------- quiescent point: exact checks
    snap_check("after phase B");
    // (1) workload semantics
    chk(sv(`HPC_PC_VEC_RETIRED) == 64'(sum_vl), $sformatf("VEC_RETIRED %0d, sum of vl %0d", sv(`HPC_PC_VEC_RETIRED), sum_vl));
    chk(sv(`HPC_PC_FLOPS_RETIRED) == 64'(sum_flops), $sformatf("FLOPS_RETIRED %0d, workload %0d", sv(`HPC_PC_FLOPS_RETIRED), sum_flops));
    chk(sv(`HPC_PC_DMA_BYTES_WR) == 64'(bytes_moved), $sformatf("DMA_BYTES_WR %0d, descriptor bytes %0d", sv(`HPC_PC_DMA_BYTES_WR), bytes_moved));
    chk(sv(`HPC_PC_DMA_BYTES_RD) == 64'(bytes_read_words), $sformatf("DMA_BYTES_RD %0d, whole words %0d", sv(`HPC_PC_DMA_BYTES_RD), bytes_read_words));
    if (INSTR_PHASE >= 2) begin
      chk(sv(`HPC_PC_VEC_ISSUED) == 64'(sum_vl), $sformatf("VEC_ISSUED %0d, sum of vl %0d", sv(`HPC_PC_VEC_ISSUED), sum_vl));
      chk(sv(`HPC_PC_CMD_ACCEPTED) == 64'(n_jobs + dma_tag), $sformatf("CMD_ACCEPTED %0d, %0d jobs + %0d descriptors", sv(`HPC_PC_CMD_ACCEPTED), n_jobs, dma_tag));
      chk(sv(`HPC_PC_CMD_COMPLETED) == sv(`HPC_PC_CMD_ACCEPTED), "CMD_COMPLETED != CMD_ACCEPTED at idle");
      chk(sv(`HPC_PC_HW_ERRORS) == 0, "HW_ERRORS in an error-free workload");
      // (2) the pre-existing 32-bit counters of Modules 03 / 04 / 05 with the same definitions
      chk(sv(`HPC_PC_DMA_ACTIVE) == 64'(pc(`HPC_DMA_PC_ACTIVE)), $sformatf("DMA_ACTIVE %0d vs M05 ACTIVE %0d", sv(`HPC_PC_DMA_ACTIVE), pc(`HPC_DMA_PC_ACTIVE)));
      begin
        int unsigned sc, sa;
        sc = 0; sa = 0;
        for (int p = 0; p < NSP; p++) begin sc += sp_pconf[p*32 +: 32]; sa += sp_pacc[p*32 +: 32]; end
        chk(sv(`HPC_PC_SPM_CONFLICTS) == 64'(sc), $sformatf("SPM_CONFLICTS %0d vs M04 conflict %0d", sv(`HPC_PC_SPM_CONFLICTS), sc));
        chk(sv(`HPC_PC_SPM_READS) + sv(`HPC_PC_SPM_WRITES) == 64'(sa), $sformatf("SPM reads+writes %0d vs M04 accept %0d", sv(`HPC_PC_SPM_READS) + sv(`HPC_PC_SPM_WRITES), sa));
      end
      chk(sv(`HPC_PC_VEC_ISSUED) == 64'(vpc(hpc_varray_pkg::PC_ELEM_IN)), "VEC_ISSUED vs M03 ELEM_IN");
      chk(sv(`HPC_PC_VEC_RETIRED) == 64'(vpc(hpc_varray_pkg::PC_ELEM_OUT)), "VEC_RETIRED vs M03 ELEM_OUT");
    end
    chk(sv(`HPC_PC_DMA_BYTES_RD) == 64'(pc(`HPC_DMA_PC_BYTES_RD)), $sformatf("DMA_BYTES_RD %0d vs M05 BYTES_RD %0d", sv(`HPC_PC_DMA_BYTES_RD), pc(`HPC_DMA_PC_BYTES_RD)));
    chk(sv(`HPC_PC_DMA_BYTES_WR) == 64'(pc(`HPC_DMA_PC_BYTES_WR)), "DMA_BYTES_WR vs M05 BYTES_WR");
    chk(sv(`HPC_PC_VEC_STALL) == 64'(vpc(hpc_varray_pkg::PC_STALL_LANE) + vpc(hpc_varray_pkg::PC_STALL_TRK) + vpc(hpc_varray_pkg::PC_OPND_STARVE)),
        $sformatf("VEC_STALL %0d vs M03 STALL_LANE+STALL_TRK+OPND_STARVE %0d", sv(`HPC_PC_VEC_STALL),
                  vpc(hpc_varray_pkg::PC_STALL_LANE) + vpc(hpc_varray_pkg::PC_STALL_TRK) + vpc(hpc_varray_pkg::PC_OPND_STARVE)));
    if (INSTR_PHASE >= 3) begin
      chk(sv(`HPC_PC_VEC_BUSY) == 64'(vpc(hpc_varray_pkg::PC_BUSY)), "VEC_BUSY vs M03 BUSY");
      chk(sv(`HPC_PC_VEC_OPND_STARVE) == 64'(vpc(hpc_varray_pkg::PC_OPND_STARVE)), "VEC_OPND_STARVE vs M03 OPND_STARVE");
      chk(sv(`HPC_PC_DMA_OUT_SUM) == 64'(pc(`HPC_DMA_PC_OUT_SUM)), "DMA_OUT_SUM vs M05 OUT_SUM");
      chk(sv(`HPC_PC_VEC_CMD_COMPLETED) == 64'(n_jobs), "VEC_CMD_COMPLETED vs jobs");
      chk(sv(`HPC_PC_RED_ADDS) == 0, "RED_ADDS without reductions");
    end
    // CYCLES runs exactly EV_REG cycles behind the Module 05 cycle counter (both count from reset, never stopped here)
    chk(sv(`HPC_PC_CYCLES) == 64'(snap_m05_cyc) - 64'(EV_REG),
        $sformatf("CYCLES %0d vs Module 05 CYCLES %0d at the snapshot cycle (EV_REG = %0d)", sv(`HPC_PC_CYCLES), snap_m05_cyc, EV_REG));
    dump_json("regdump.json", "after phase B (Module 05 workload)");
    $display("TB_TILE_PERF COUNTERS cycles=%0d vec_issued=%0d vec_retired=%0d flops=%0d vec_stall=%0d vec_busy=%0d opnd_starve=%0d dma_active=%0d bytes_rd=%0d bytes_wr=%0d spm_rd=%0d spm_wr=%0d spm_conf=%0d cmdq_full=%0d out_bp=%0d cmd_acc=%0d cmd_cpl=%0d inflight_sum=%0d",
             sv(0), sv(3), sv(4), sv(5), sv(6), sv(16), sv(17), sv(7), sv(8), sv(9), sv(10), sv(11), sv(12), sv(13), sv(14), sv(1), sv(2), sv(18));

    // ---------------------------------------------------------- phase C: control under load
    // a burst of 6 descriptors first: fills the CMD_DEPTH-deep descriptor queue (CMDQ_FULL). Sequential, outside the
    // fork below (Verilator 5.020 crashes in its coroutine runtime when a fork branch nests this task).
    dma_burst();
    begin
      int unsigned qa, qb;
      fork
        begin
          dma(IG_A, IG_SA, 32'(4 * IG_VA), qa); dma(IG_SD, IG_D, 32'(4 * IG_VA), qb);
          dma_wait(qa); dma_wait(qb);
        end
        vjob(5'h03, 3'b000, 32'd0, IG_SA, IG_SB, 32'd0, IG_SF + 32'h800, 200, 8'd40);  // FMUL into a scratch area
        begin
          repeat (150) @(negedge clk);
          t_freeze <= 1'b1; repeat (37) @(negedge clk); t_freeze <= 1'b0;        // hardware freeze pulse
          live_check(`HPC_PC_CYCLES, "after freeze_i");
          rwr(`HPC_PR_CTRL, 32'd1 << `HPC_CTRL_ENABLE | 32'd1 << `HPC_CTRL_FREEZE);   // software freeze
          repeat (25) @(negedge clk);
          snap_check("frozen (CTRL.FREEZE)");
          rwr(`HPC_PR_CTRL, 32'd1 << `HPC_CTRL_ENABLE);
          rwr(`HPC_PR_CNT_EN, 32'h0055_AA55);                                     // mask half the counters
          repeat (60) @(negedge clk);
          snap_check("CNT_EN masked");
          rwr(`HPC_PR_CNT_EN, 32'hFFFF_FFFF);
          rwr(`HPC_PR_CTRL, 32'd0);                                               // disable
          repeat (30) @(negedge clk);
          live_check(`HPC_PC_DMA_BYTES_RD, "disabled");
          rwr(`HPC_PR_CTRL, 32'd1 << `HPC_CTRL_ENABLE | 32'd1 << `HPC_CTRL_CLEAR); // clear under load
          repeat (40) @(negedge clk);
          snap_check("cleared under load");
        end
      join
    end
    wait_quiet();
    snap_check("after phase C");

    // ---------------------------------------------------------- phase D: error injection
    begin
      int unsigned qe;
      logic [31:0] es;
      logic [63:0] e0;
      rwr(`HPC_PR_ERR_SRC, 32'hFFFF_FFFF);
      e0 = m_cnt[`HPC_PC_HW_ERRORS];
      j_expect_ill = 1'b1;
      vjob(5'h1F, 3'b000, 32'd0, 32'd0, 32'd0, 32'd0, 32'd0, 0, 8'd50);            // reserved opcode, vl = 0
      j_expect_ill = 1'b0;
      dma_x(IG_A + 32'd2, IG_SA, 32'd64, 1'b1, qe);                              // misaligned source: rejected
      dma_wait(qe);
      wait_quiet();
      snap_check("after error injection");
      if (INSTR_PHASE >= 2) begin
        chk(sv(`HPC_PC_HW_ERRORS) - e0 == 2, $sformatf("HW_ERRORS +%0d, expected +2", sv(`HPC_PC_HW_ERRORS) - e0));
        rrd(`HPC_PR_ERR_SRC, es);
        chk(es == (32'd1 << `HPC_ERR_VEC_ILLEGAL | 32'd1 << `HPC_ERR_DMA_CPL_ERR), $sformatf("ERR_SRC = %b", es));
        chk(es[7:0] == m_errsrc, "ERR_SRC vs mirror");
      end
      rwr(`HPC_PR_ERR_SRC, 32'hFFFF_FFFF);
      rrd(`HPC_PR_ERR_SRC, es);
      chk(es == 0, "ERR_SRC W1C");
    end

    // ---------------------------------------------------------- phase E: overflow on the real tile
    begin
      int unsigned qa;
      logic [31:0] ovf;
      logic [63:0] b0, f0;
      rwr(`HPC_PR_PRE_LO, 32'hFFFF_FF00); rwr(`HPC_PR_PRE_HI, 32'hFFFF_FFFF);
      rwr(`HPC_PR_PRE_LOAD, 32'd1 << `HPC_PC_DMA_BYTES_RD | 32'd1 << `HPC_PC_FLOPS_RETIRED);
      rwr(`HPC_PR_SAT, 32'd1 << `HPC_PC_FLOPS_RETIRED);                         // FLOPs saturate, bytes wrap
      rwr(`HPC_PR_OVF, 32'hFFFF_FFFF);
      b0 = 64'hFFFF_FFFF_FFFF_FF00;
      fork
        begin dma(IG_A, IG_SA, 32'(4 * IG_VA), qa); dma_wait(qa); end         // 4000 B: wraps the byte counter
        vjob(5'h04, 3'b000, 32'd0, IG_SA, IG_SB, IG_SC, IG_SF + 32'h800, 300, 8'd60);   // 600 FLOPs: saturates
      join
      wait_quiet();
      snap_check("after overflow");
      rrd(`HPC_PR_OVF, ovf);
      chk(ovf[`HPC_PC_DMA_BYTES_RD] && ovf[`HPC_PC_FLOPS_RETIRED], $sformatf("OVF = %h", ovf));
      chk(sv(`HPC_PC_DMA_BYTES_RD) < 64'd4096, $sformatf("wrapped byte counter = %0d", sv(`HPC_PC_DMA_BYTES_RD)));
      chk(sv(`HPC_PC_DMA_BYTES_RD) == b0 + 64'(4000), "wrapped byte counter = (preload + 4000) mod 2^64");
      chk(sv(`HPC_PC_FLOPS_RETIRED) == 64'hFFFF_FFFF_FFFF_FFFF, "saturated FLOP counter");
      rrd(`HPC_PR_SNAP_OVF, ovf);
      chk(ovf[`HPC_PC_DMA_BYTES_RD] && ovf[`HPC_PC_FLOPS_RETIRED], "SNAP_OVF");
      for (int i = 0; i < NC; i++) chk(m_ovf[i] == ovf[i], $sformatf("OVF[%0d] vs mirror", i));
      rwr(`HPC_PR_SAT, 32'd0);
    end

    // ---------------------------------------------------------- Module 05 functional checks (unchanged by Module 07)
    for (int i = 0; i < IG_VA; i++) begin
      host_access(1'b0, IG_D + 32'(4*i), '0, 4'h0, rd);
      if (rd !== exp_ext[int'(IG_D - EXT_BASE)/4 + i]) err($sformatf("D[%0d] = %h, expected %h", i, rd, exp_ext[int'(IG_D - EXT_BASE)/4 + i]));
      host_access(1'b0, IG_E + 32'(4*i), '0, 4'h0, rd);
      if (rd !== exp_ext[int'(IG_E - EXT_BASE)/4 + i]) err($sformatf("E[%0d] = %h, expected %h", i, rd, exp_ext[int'(IG_E - EXT_BASE)/4 + i]));
      host_access(1'b0, IG_F + 32'(4*i), '0, 4'h0, rd);
      if (rd !== exp_ext[int'(IG_F - EXT_BASE)/4 + i]) err($sformatf("F[%0d] = %h, expected %h", i, rd, exp_ext[int'(IG_F - EXT_BASE)/4 + i]));
    end
    for (int k = 0; k < IG_K; k++) for (int i = 0; i < IG_T; i++) begin
      int w;
      w = int'(IG_Z - EXT_BASE) / 4 + k * IG_TILE_STRIDE / 4 + i;
      host_access(1'b0, IG_Z + 32'(k * IG_TILE_STRIDE + 4*i), '0, 4'h0, rd);
      if (rd !== exp_ext[w]) err($sformatf("Z[%0d][%0d] = %h, expected %h", k, i, rd, exp_ext[w]));
    end
    for (int i = 0; i < NM + 2; i++) if (viol[i] != 0) err($sformatf("SFB2 protocol violations on link %0d: %0d", i, viol[i]));
    if (bg_ops == 0) err("host background traffic did not run");
    if (u_perf.u_ev.err_src[`HPC_ERR_PERF_TRACK_ERR] !== 1'b0) err("PERF_TRACK_ERR raised");
    chk(CMD_DEPTH == 0 || cov_dma_qfull > 0, "coverage: the DMA descriptor queue was never full");
    snap_check("final");
    $display("TB_TILE_PERF PHASES host_write=%0d dma_in=%0d compute=%0d dma_out=%0d phaseB=%0d", t1 - t0, t2 - t1, t3 - t2, t4 - t3, td - tc);
    $display("TB_TILE_PERF CHECKS snapshots=%0d live_pairs=%0d back_to_back=%0d checks=%0d dma_queue_full_cycles=%0d", n_snap_chk, n_live_chk, n_b2b_chk, checks, cov_dma_qfull);
    if (errors == 0) $display("TB_TILE_PERF RESULT PASS engine=%0d dual=%0d hold=%0d cplbp=%0d ev_reg=%0d phase=%0d", ENGINE, DUAL_PORT, HOLD_PCT, CPL_BP_PCT, EV_REG, INSTR_PHASE);
    else             $display("TB_TILE_PERF RESULT FAIL errors=%0d", errors);
    $finish;
  end
  initial begin #200ms; $display("TB_TILE_PERF RESULT FAIL timeout"); $finish; end
endmodule

`default_nettype wire
