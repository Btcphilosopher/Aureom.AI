// =============================================================================
// SilicaFlux-HPC Module 07 :: tb_hpc_perf_cdc -- verification of hpc_perf_cdc_count
//
// Two unrelated clocks (periods in ps, independent random jitter on every half
// period), random event bursts in the source domain, the simulation
// metastability model of the synchronisers (+define+HPC_CDC_META), and the
// destination increments feeding a real hpc_perf_counters bank.
// Checks:
//   * conservation: after draining, events delivered == events produced, and
//     the counter bank's live value equals them (no loss, no duplication);
//   * no creation at any time: delivered <= produced in every dst cycle;
//   * bounded latency: the drain completes within a fixed number of cycles;
//   * capacity: with EXPECT_OVF = 1 (accumulator deliberately too small) the
//     sticky ovf_o is raised and delivered < produced (loss is reported, never
//     silent); with EXPECT_OVF = 0 ovf_o must stay 0.
// Result line: "TB_CDC RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_hpc_perf_cdc #(
  parameter int SRC_PS     = 3100,     // source clock period (ps)
  parameter int DST_PS     = 10000,    // destination clock period (ps)
  parameter int JIT_PS     = 300,      // max jitter per half period (ps)
  parameter int EW         = 8,
  parameter int AW         = 16,
  parameter int NCYC       = 40000,    // source cycles of stimulus
  parameter int MAX_EV     = 255,      // largest event count per source cycle
  parameter bit EXPECT_OVF = 1'b0
);
  logic src_clk = 1'b0, dst_clk = 1'b0, src_rst_n = 1'b0, dst_rst_n = 1'b0;
  int unsigned rj = 32'h51F1_5EED;
  function automatic int unsigned rnd();
    rj = rj ^ (rj << 13); rj = rj ^ (rj >> 17); rj = rj ^ (rj << 5);
    return rj;
  endfunction
  int src_half, dst_half;
  initial forever begin
    src_half = SRC_PS / 2 + int'(rnd() % (2 * JIT_PS + 1)) - JIT_PS;
    #(src_half * 1ps); src_clk = ~src_clk;
  end
  initial forever begin
    dst_half = DST_PS / 2 + int'(rnd() % (2 * JIT_PS + 1)) - JIT_PS;
    #(dst_half * 1ps); dst_clk = ~dst_clk;
  end

  logic [EW-1:0] ev = '0;
  logic [AW-1:0] inc;
  logic          ovf;
  hpc_perf_cdc_count #(.EW(EW), .AW(AW)) dut (
    .src_clk, .src_rst_n, .ev_i(ev), .dst_clk, .dst_rst_n, .inc_o(inc), .ovf_o(ovf));

  // destination counter bank (one 64-bit counter)
  logic [63:0] cnt;
  logic [31:0] rdata;
  logic        rerr, irq, frz;
  hpc_perf_counters #(.NUM_CNT(1), .CNT_W(64), .INC_W(AW), .NUM_ERR(1)) u_bank (
    .clk(dst_clk), .rst_n(dst_rst_n), .rb_sel(1'b0), .rb_we(1'b0), .rb_addr(12'h0), .rb_wdata(32'h0),
    .rb_rdata(rdata), .rb_err(rerr), .inc_i(inc), .freeze_i(1'b0), .snap_i(1'b0), .err_i(ovf), .irq_o(irq),
    .frozen_o(frz), .cnt_o(cnt));

  longint unsigned produced = 0, delivered = 0;
  int unsigned errors = 0, transfers = 0, max_gap = 0;
  always @(posedge src_clk) if (src_rst_n) produced += ev;
  always @(posedge dst_clk) if (dst_rst_n) begin
    delivered += inc;
    if (inc != 0) transfers++;
    if (delivered > produced) begin
      errors++;
      if (errors < 10) $display("TB_CDC ERROR delivered %0d > produced %0d (events created)", delivered, produced);
    end
  end

  initial begin
    int unsigned mode;
    repeat (3) @(negedge src_clk);
    src_rst_n = 1'b1;
    @(negedge dst_clk);
    dst_rst_n = 1'b1;
    mode = 0;
    for (int k = 0; k < NCYC; k++) begin
      @(negedge src_clk);
      if (k % 500 == 0) mode = rnd() % 4;
      case (mode)
        0: ev <= EW'(rnd() % (MAX_EV + 1));                        // random
        1: ev <= EW'(MAX_EV);                                      // sustained maximum
        2: ev <= (rnd() % 8 == 0) ? EW'(rnd() % (MAX_EV + 1)) : '0;  // sparse
        default: ev <= '0;                                         // idle
      endcase
    end
    @(negedge src_clk);
    ev <= '0;
    begin
      int unsigned w;
      w = 0;
      while (delivered != produced && w < 64) begin @(posedge dst_clk); w++; end
      repeat (8) @(posedge dst_clk);
      max_gap = w;
    end
    if (EXPECT_OVF) begin
      if (!ovf) begin errors++; $display("TB_CDC ERROR accumulator overflow not reported"); end
      if (delivered >= produced) begin errors++; $display("TB_CDC ERROR expected a reported loss"); end
    end else begin
      if (ovf) begin errors++; $display("TB_CDC ERROR unexpected accumulator overflow"); end
      if (delivered != produced) begin
        errors++; $display("TB_CDC ERROR conservation: produced %0d delivered %0d", produced, delivered);
      end
      if (cnt != delivered) begin errors++; $display("TB_CDC ERROR counter bank %0d vs delivered %0d", cnt, delivered); end
      if (max_gap >= 64) begin errors++; $display("TB_CDC ERROR drain did not complete in 64 dst cycles"); end
    end
    $display("TB_CDC INFO src=%0dps dst=%0dps jitter=%0dps produced=%0d delivered=%0d transfers=%0d drain=%0d ovf=%0d",
             SRC_PS, DST_PS, JIT_PS, produced, delivered, transfers, max_gap, ovf);
`ifdef HPC_CDC_META
    $display("TB_CDC META injected_resolutions_to_old_value req=%0d ack=%0d ovf=%0d",
             dut.u_req.n_meta, dut.u_ack.n_meta, dut.u_ovf.n_meta);
    if (dut.u_req.n_meta == 0 || dut.u_ack.n_meta == 0) begin errors++; $display("TB_CDC ERROR metastability model inactive"); end
`endif
    if (errors == 0) $display("TB_CDC RESULT PASS");
    else             $display("TB_CDC RESULT FAIL errors=%0d", errors);
    $finish;
  end
  initial begin #2s; $display("TB_CDC RESULT FAIL timeout"); $finish; end
endmodule

`default_nettype wire
