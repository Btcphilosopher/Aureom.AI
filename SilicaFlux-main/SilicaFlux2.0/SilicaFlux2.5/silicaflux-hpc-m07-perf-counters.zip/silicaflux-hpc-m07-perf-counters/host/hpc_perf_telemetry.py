#!/usr/bin/env python3
"""SilicaFlux-HPC Module 07 -- host-side telemetry extraction and performance derivation.

Subcommands
  read        read the counter page of a running system into a register dump (format hpc_perf_regdump/1):
              takes a coherent SNAPSHOT first, then reads every register.  Backends:
                --backend devmem --base ADDR   Linux /dev/mem mapping of the register page (FPGA SoC / silicon board)
              (the RTL testbench writes the same dump format directly: tb/tb_hpc_tile_perf.sv -> regdump.json)
  derive      turn one dump (or an interval: --baseline earlier.json + the later dump) into derived metrics (JSON)
  analytical  analytical estimate for a configuration and workload description (no hardware involved)

Provenance rules (enforced, not advisory)
  * --source is mandatory: rtl_simulation | fpga | asic | emulation.  It must equal what the hardware itself reports in
    INFO.PLATFORM (the netlist was built for that platform); a mismatch is refused.  An FPGA dump can therefore never be
    reported as ASIC, and a simulation never as hardware.
  * asic additionally requires --silicon-id and --process (die / lot identification of the measured part).
  * Seconds are derived ONLY from an explicit clock: --clock-hz (the actual configured clock, with --clock-basis
    pll_config | measured | nominal) or, if absent, the build-configured CLK_KHZ register (basis "nominal_register").
    For rtl_simulation the clock is by definition an assumption (a simulation has no physical clock) and is labelled so.
  * Analytical estimates are a separate kind ("analytical_estimate") and are never merged into measured metrics; derive
    --with-analytical adds them side by side in a separately labelled block.
  * A counter whose OVF bit is set is reported as "wrapped" (value invalid: modulo 2^CNT_W) or "saturated" (value is a
    lower bound); metrics that depend on it carry that status instead of a silently wrong number.
"""
from __future__ import annotations

import argparse
import json
import math
import mmap
import os
import struct
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
import perfmap as M  # noqa: E402

TOOL = "host/hpc_perf_telemetry.py"
SCHEMA = "hpc_perf_telemetry/1"
KIND_OF_PLATFORM = {0: "rtl_simulation", 1: "fpga", 2: "asic", 3: "emulation"}
STATEMENT = {
    "rtl_simulation": "Cycle counts from a cycle-accurate RTL simulation of the SilicaFlux-HPC tile. Seconds and rates "
                      "are derived from an ASSUMED clock (a simulation has no physical clock). This is not a measurement "
                      "of FPGA or ASIC hardware.",
    "fpga": "Counter values read from an FPGA implementation of the SilicaFlux-HPC tile. FPGA results: they are NOT ASIC "
            "performance and must not be reported as such.",
    "asic": "Counter values read from fabricated SilicaFlux-HPC silicon (part identified below).",
    "emulation": "Counter values read from an emulation / other platform; neither FPGA nor ASIC performance.",
    "analytical_estimate": "Analytical estimate computed from the configuration and a workload description. Not a "
                           "measurement of anything.",
}


class TelemetryError(Exception):
    pass


# ============================================================================================ register access
class DevMem:
    """32-bit register access through /dev/mem (Linux).  Not exercised in this repository's environment."""

    def __init__(self, base: int, size: int = 0x1000):
        self.fd = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
        page = mmap.PAGESIZE
        self.off = base % page
        self.mm = mmap.mmap(self.fd, size + self.off, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE,
                            offset=base - self.off)

    def rd(self, a: int) -> int:
        return struct.unpack_from("<I", self.mm, self.off + a)[0]

    def wr(self, a: int, v: int) -> None:
        struct.pack_into("<I", self.mm, self.off + a, v & 0xFFFF_FFFF)


def read_dump(reg, label: str) -> dict:
    """The coherent read protocol of docs/02 section 5: one SNAPSHOT, then the snapshot window."""
    if reg.rd(M.REG_ID) != M.PERF_ID:
        raise TelemetryError(f"ID register reads 0x{reg.rd(M.REG_ID):08x}, expected 0x{M.PERF_ID:08x}: wrong base?")
    ctrl = reg.rd(M.REG_CTRL) & 0x7
    seq0 = reg.rd(M.REG_STATUS) >> 16
    reg.wr(M.REG_CTRL, ctrl | 1 << M.CTRL_SNAPSHOT)
    regs = {n: reg.rd(off) for off, n, acc, *_ in M.REGISTERS if acc not in ("WO",)}
    info = regs["INFO"]
    n = M.field(info, M.INFO_FIELDS, "NUM_CNT")
    snap = {}
    for idx, name, *_ in M.COUNTERS[:n]:
        snap[name] = reg.rd(M.snap_lo(idx)) | reg.rd(M.snap_lo(idx) + 4) << 32
    seq1 = reg.rd(M.REG_STATUS) >> 16
    if seq1 != ((seq0 + 1) & 0xFFFF):
        raise TelemetryError("another agent took a snapshot during the read (SNAP_SEQ moved): retry")
    return {"format": "hpc_perf_regdump/1", "producer": TOOL + " read", "label": label,
            "host_time_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "registers": regs, "snapshot": snap}


# ============================================================================================ decoding
def decode(dump: dict) -> dict:
    if dump.get("format") != "hpc_perf_regdump/1":
        raise TelemetryError(f"unknown dump format {dump.get('format')!r}")
    r = dump["registers"]
    if r["ID"] != M.PERF_ID:
        raise TelemetryError(f"ID 0x{r['ID']:08x} is not a SilicaFlux performance-counter page")
    if r["VERSION"] >> 16 != M.PERF_VERSION >> 16:
        raise TelemetryError(f"register-map major version {r['VERSION'] >> 16}, this tool understands "
                             f"{M.PERF_VERSION >> 16}")
    info = {n: M.field(r["INFO"], M.INFO_FIELDS, n) for n, *_ in M.INFO_FIELDS}
    tile = {n: M.field(r["TILECFG"], M.TILECFG_FIELDS, n) for n, *_ in M.TILECFG_FIELDS}
    n = info["NUM_CNT"]
    names = [c[1] for c in M.COUNTERS[:n]]
    vals = {k: int(dump["snapshot"][k]) for k in names}
    en = r["CNT_EN"]
    sat = r["SAT"]
    ovf = r["SNAP_OVF"]
    status = {}
    phase = {c[1]: c[2] for c in M.COUNTERS}
    for i, k in enumerate(names):
        if phase[k] > tile["INSTR_PHASE"]:
            status[k] = f"not_instrumented (INSTR_PHASE = {tile['INSTR_PHASE']})"
        elif not (en >> i) & 1:
            status[k] = "not_counted (CNT_EN = 0)"
        elif (ovf >> i) & 1:
            status[k] = "saturated (lower bound)" if (sat >> i) & 1 else f"wrapped (value modulo 2^{info['CNT_W']}: invalid)"
        else:
            status[k] = "valid"
    errs = [name for idx, name, _ in M.ERR_SOURCES if (r["ERR_SRC"] >> idx) & 1]
    return dict(info=info, tile=tile, values=vals, status=status, regs=r, err_sources=errs,
                snap_seq=r["STATUS"] >> M.ST_SNAP_SEQ_LSB, frozen=bool(r["STATUS"] & 1))


def interval(after: dict, before: dict) -> dict:
    """Counter deltas between two dumps of the same build (wrap-aware for counters that wrapped once at most)."""
    for k in ("INFO", "TILECFG", "BUILD_ID"):
        if after["regs"][k] != before["regs"][k]:
            raise TelemetryError(f"baseline and dump come from different builds ({k} differs)")
    w = after["info"]["CNT_W"]
    out = dict(after)
    vals, status = {}, {}
    for k, v in after["values"].items():
        b = before["values"][k]
        st_a, st_b = after["status"][k], before["status"][k]
        if st_a.startswith("not_") or st_b.startswith("not_"):
            vals[k], status[k] = None, st_a if st_a.startswith("not_") else st_b
        elif st_a.startswith("saturated") or st_b.startswith("saturated"):
            vals[k], status[k] = None, "saturated: interval undefined"
        elif v < b or st_a.startswith("wrapped"):
            vals[k], status[k] = (v - b) % (1 << w), "valid (modular delta: assumes fewer than one wrap in the interval)"
        else:
            vals[k], status[k] = v - b, "valid"
    out["values"], out["status"] = vals, status
    return out


# ============================================================================================ derivation
def _mul(*xs):
    if any(x is None for x in xs):
        return None
    r = 1
    for x in xs:
        r *= x
    return r


def _sub(a, b):
    return None if a is None or b is None else a - b


def _add(a, b):
    return None if a is None or b is None else a + b


def _ratio(num, den, scale=1.0):
    if num is None or den is None or den == 0:
        return None
    return num * scale / den


def derive(d: dict, clock_hz: float, deps_status: dict) -> dict:  # noqa: C901
    v, st = d["values"], d["status"]
    n_l = d["tile"]["NUM_LANES"]
    fma = d["tile"]["FMA_FLOPS"]
    t = None if not v.get("CYCLES") else v["CYCLES"] / clock_hz
    ck = lambda x: _mul(x, clock_hz)  # noqa: E731
    m = {}

    def put(name, value, unit, formula, uses):
        bad = [u for u in uses if not st.get(u, "").startswith("valid")]
        entry = {"value": value, "unit": unit, "formula": formula}
        if bad:
            entry["status"] = "unavailable: " + ", ".join(f"{u} {st.get(u, 'absent')}" for u in bad)
            if any("saturated (lower" in st.get(u, "") for u in bad) and not any(
                    "wrapped" in st.get(u, "") or "not_" in st.get(u, "") or "undefined" in st.get(u, "") for u in bad):
                entry["status"] = "bound only (saturated input): " + ", ".join(bad)
            else:
                entry["value"] = None
        else:
            entry["status"] = "valid"
        m[name] = entry
        deps_status[name] = entry["status"]

    put("elapsed_cycles", v.get("CYCLES"), "cycles", "CYCLES", ["CYCLES"])
    put("elapsed_time", t, "s", "CYCLES / f_clk", ["CYCLES"])
    # ---- cycles per operation
    put("cycles_per_vector_element_op", _ratio(v.get("CYCLES"), v.get("VEC_RETIRED")), "cycles/element-op",
        "CYCLES / VEC_RETIRED", ["CYCLES", "VEC_RETIRED"])
    put("busy_cycles_per_vector_element_op", _ratio(v.get("VEC_BUSY"), v.get("VEC_RETIRED")), "cycles/element-op",
        "VEC_BUSY / VEC_RETIRED", ["VEC_BUSY", "VEC_RETIRED"])
    put("cycles_per_command", _ratio(v.get("CYCLES"), v.get("CMD_COMPLETED")), "cycles/command",
        "CYCLES / CMD_COMPLETED", ["CYCLES", "CMD_COMPLETED"])
    put("elements_per_vector_command", _ratio(v.get("VEC_RETIRED"), v.get("VEC_CMD_COMPLETED")), "elements/command",
        "VEC_RETIRED / VEC_CMD_COMPLETED", ["VEC_RETIRED", "VEC_CMD_COMPLETED"])
    # ---- lane utilisation
    put("lane_utilisation_while_busy", _ratio(v.get("VEC_ISSUED"), _mul(n_l, v.get("VEC_BUSY"))), "fraction",
        "VEC_ISSUED / (NUM_LANES x VEC_BUSY)", ["VEC_ISSUED", "VEC_BUSY"])
    put("lane_utilisation_window", _ratio(v.get("VEC_ISSUED"), _mul(n_l, v.get("CYCLES"))), "fraction",
        "VEC_ISSUED / (NUM_LANES x CYCLES)", ["VEC_ISSUED", "CYCLES"])
    put("issued_minus_retired", _sub(v.get("VEC_ISSUED"), v.get("VEC_RETIRED")),
        "element-ops", "VEC_ISSUED - VEC_RETIRED (in flight at the snapshot)", ["VEC_ISSUED", "VEC_RETIRED"])
    # ---- compute throughput
    put("flops_per_cycle", _ratio(v.get("FLOPS_RETIRED"), v.get("CYCLES")), "FLOP/cycle", "FLOPS_RETIRED / CYCLES",
        ["FLOPS_RETIRED", "CYCLES"])
    put("compute_throughput", _ratio(v.get("FLOPS_RETIRED"), t), "FLOP/s", "FLOPS_RETIRED / elapsed_time",
        ["FLOPS_RETIRED", "CYCLES"])
    put("compute_throughput_while_busy", _ratio(ck(v.get("FLOPS_RETIRED")), v.get("VEC_BUSY")), "FLOP/s",
        "FLOPS_RETIRED x f_clk / VEC_BUSY", ["FLOPS_RETIRED", "VEC_BUSY"])
    put("reduction_add_share", _ratio(v.get("RED_ADDS"), v.get("FLOPS_RETIRED")), "fraction",
        "RED_ADDS / FLOPS_RETIRED", ["RED_ADDS", "FLOPS_RETIRED"])
    # ---- DMA bandwidth
    rdwr = _add(v.get("DMA_BYTES_RD"), v.get("DMA_BYTES_WR"))
    put("dma_read_bandwidth", _ratio(v.get("DMA_BYTES_RD"), t), "B/s", "DMA_BYTES_RD / elapsed_time",
        ["DMA_BYTES_RD", "CYCLES"])
    put("dma_write_bandwidth", _ratio(v.get("DMA_BYTES_WR"), t), "B/s", "DMA_BYTES_WR / elapsed_time",
        ["DMA_BYTES_WR", "CYCLES"])
    put("dma_effective_bandwidth", _ratio(rdwr, t), "B/s", "(DMA_BYTES_RD + DMA_BYTES_WR) / elapsed_time",
        ["DMA_BYTES_RD", "DMA_BYTES_WR", "CYCLES"])
    put("dma_bandwidth_while_active", _ratio(ck(rdwr), v.get("DMA_ACTIVE")), "B/s",
        "(DMA_BYTES_RD + DMA_BYTES_WR) x f_clk / DMA_ACTIVE", ["DMA_BYTES_RD", "DMA_BYTES_WR", "DMA_ACTIVE"])
    put("dma_bytes_per_active_cycle", _ratio(rdwr, v.get("DMA_ACTIVE")), "B/cycle",
        "(DMA_BYTES_RD + DMA_BYTES_WR) / DMA_ACTIVE", ["DMA_BYTES_RD", "DMA_BYTES_WR", "DMA_ACTIVE"])
    put("dma_active_fraction", _ratio(v.get("DMA_ACTIVE"), v.get("CYCLES")), "fraction", "DMA_ACTIVE / CYCLES",
        ["DMA_ACTIVE", "CYCLES"])
    # ---- stalls
    put("memory_stall_pct_of_vector_busy", _ratio(v.get("VEC_OPND_STARVE"), v.get("VEC_BUSY"), 100.0), "%",
        "100 x VEC_OPND_STARVE / VEC_BUSY", ["VEC_OPND_STARVE", "VEC_BUSY"])
    put("memory_stall_pct_of_window", _ratio(v.get("VEC_OPND_STARVE"), v.get("CYCLES"), 100.0), "%",
        "100 x VEC_OPND_STARVE / CYCLES", ["VEC_OPND_STARVE", "CYCLES"])
    put("vector_stall_pct_of_vector_busy", _ratio(v.get("VEC_STALL"), v.get("VEC_BUSY"), 100.0), "%",
        "100 x VEC_STALL / VEC_BUSY", ["VEC_STALL", "VEC_BUSY"])
    put("structural_stall_pct_of_vector_busy",
        _ratio(_sub(v.get("VEC_STALL"), v.get("VEC_OPND_STARVE")), v.get("VEC_BUSY"), 100.0),
        "%", "100 x (VEC_STALL - VEC_OPND_STARVE) / VEC_BUSY", ["VEC_STALL", "VEC_OPND_STARVE", "VEC_BUSY"])
    put("output_backpressure_pct", _ratio(v.get("OUT_BP"), v.get("CYCLES"), 100.0), "%", "100 x OUT_BP / CYCLES",
        ["OUT_BP", "CYCLES"])
    # ---- scratchpad
    acc = _add(v.get("SPM_READS"), v.get("SPM_WRITES"))
    put("spm_accesses_per_cycle", _ratio(acc, v.get("CYCLES")), "accesses/cycle", "(SPM_READS + SPM_WRITES) / CYCLES",
        ["SPM_READS", "SPM_WRITES", "CYCLES"])
    put("spm_conflicts_per_access", _ratio(v.get("SPM_CONFLICTS"), acc), "conflict-port-cycles/access",
        "SPM_CONFLICTS / (SPM_READS + SPM_WRITES)", ["SPM_CONFLICTS", "SPM_READS", "SPM_WRITES"])
    # ---- queues (Little's law)
    exact = v.get("CMD_ACCEPTED") == v.get("CMD_COMPLETED")
    put("mean_commands_in_flight", _ratio(v.get("CMD_INFLIGHT_SUM"), v.get("CYCLES")), "commands",
        "CMD_INFLIGHT_SUM / CYCLES", ["CMD_INFLIGHT_SUM", "CYCLES"])
    put("mean_command_latency", _ratio(v.get("CMD_INFLIGHT_SUM"), v.get("CMD_COMPLETED")), "cycles",
        "CMD_INFLIGHT_SUM / CMD_COMPLETED (Little's law; exact when nothing is in flight at both window edges"
        + ("" if exact else " -- NOT the case here: approximate") + ")", ["CMD_INFLIGHT_SUM", "CMD_COMPLETED"])
    put("mean_vector_cmdq_occupancy", _ratio(v.get("VEC_CMDQ_OCC_SUM"), v.get("CYCLES")), "entries",
        "VEC_CMDQ_OCC_SUM / CYCLES", ["VEC_CMDQ_OCC_SUM", "CYCLES"])
    put("cmdq_full_pct", _ratio(v.get("CMDQ_FULL"), v.get("CYCLES"), 100.0), "%", "100 x CMDQ_FULL / CYCLES",
        ["CMDQ_FULL", "CYCLES"])
    put("dma_mean_outstanding_requests", _ratio(v.get("DMA_OUT_SUM"), v.get("CYCLES")), "requests",
        "DMA_OUT_SUM / CYCLES", ["DMA_OUT_SUM", "CYCLES"])
    put("hardware_error_events", v.get("HW_ERRORS"), "events", "HW_ERRORS", ["HW_ERRORS"])
    # ---- the configuration's arithmetic ceiling (analytical, used only as a labelled ratio)
    peak = n_l * fma
    put("flops_per_cycle_vs_lane_peak", _ratio(v.get("FLOPS_RETIRED"), _mul(peak, v.get("CYCLES"))), "fraction",
        f"FLOPS_RETIRED / (NUM_LANES x FMA_FLOPS x CYCLES) -- peak {peak} FLOP/cycle is ANALYTICAL (every lane retiring "
        "an FMA every cycle), the numerator is counted", ["FLOPS_RETIRED", "CYCLES"])
    return m


def analytical(cfg: dict, workload: dict, clock_hz: float) -> dict:
    """Ideal-case estimate: 1 beat per cycle per command (Module 03 measured ceil(vl/N) cycles per command, steady
    state), DMA at DMA_PORTS x bytes_per_beat per cycle, no stalls, no overlap assumptions beyond the stated one."""
    n_l, fma = cfg["NUM_LANES"], cfg.get("FMA_FLOPS", 2)
    w = {"FADD": 1, "FSUB": 1, "FMUL": 1, "FMADD": fma, "FMSUB": fma, "FNMSUB": fma, "FNMADD": fma}
    beats = sum(math.ceil(c["vl"] / n_l) for c in workload.get("vector", []))
    flops = sum(c["vl"] * (w.get(c["op"], 0) + (1 if c.get("reduction") else 0)) for c in workload.get("vector", []))
    dma_b = workload.get("dma_bytes", 0)
    dma_cyc = math.ceil(dma_b / (cfg.get("DMA_PORTS", 1) * cfg.get("DMA_BYTES_PER_BEAT", 4)))
    serial = beats + dma_cyc
    return {"assumptions": ["vector array issues one beat per cycle (Module 03 measured initiation interval)",
                            "DMA moves DMA_PORTS x DMA_BYTES_PER_BEAT bytes every cycle",
                            "no operand starvation, no back-pressure, no bank conflicts",
                            f"clock {clock_hz:g} Hz as given"],
            "vector_beats": beats, "dma_cycles": dma_cyc, "flops": flops,
            "cycles_serial_lower_bound": serial, "cycles_full_overlap_lower_bound": max(beats, dma_cyc),
            "peak_flops_per_cycle": n_l * fma, "peak_flop_rate": n_l * fma * clock_hz,
            "peak_dma_bandwidth": cfg.get("DMA_PORTS", 1) * cfg.get("DMA_BYTES_PER_BEAT", 4) * clock_hz}


# ============================================================================================ CLI
def clock_of(a, d) -> dict:
    if a.clock_hz:
        basis = a.clock_basis or ("assumed" if a.source == "rtl_simulation" else None)
        if basis is None:
            raise TelemetryError("--clock-basis {pll_config,measured,nominal} is required with --clock-hz")
        return {"hz": float(a.clock_hz), "basis": basis}
    khz = d["regs"]["CLK_KHZ"]
    if khz == 0:
        raise TelemetryError("no clock: CLK_KHZ register is 0 and --clock-hz was not given")
    if a.source in ("fpga", "asic"):
        print("WARNING: using the build-configured nominal CLK_KHZ register; give --clock-hz with the actual "
              "configured clock (--clock-basis pll_config or measured)", file=sys.stderr)
    return {"hz": khz * 1000.0, "basis": "assumed (build-configured CLK_KHZ register; a simulation has no physical "
                                          "clock)" if a.source == "rtl_simulation" else "nominal_register"}


def cmd_derive(a) -> dict:
    dump = json.loads(Path(a.dump).read_text())
    d = decode(dump)
    plat = d["info"]["PLATFORM"]
    if KIND_OF_PLATFORM[plat] != a.source:
        raise TelemetryError(f"--source {a.source} refused: the hardware reports INFO.PLATFORM = {plat} "
                             f"({KIND_OF_PLATFORM[plat]}). A measurement is reported only as what it is.")
    if a.source == "asic" and not (a.silicon_id and a.process):
        raise TelemetryError("--source asic requires --silicon-id and --process (identification of the measured part)")
    base = None
    if a.baseline:
        base = decode(json.loads(Path(a.baseline).read_text()))
        d = interval(d, base)
    clk = clock_of(a, d)
    deps: dict = {}
    metrics = derive(d, clk["hz"], deps)
    out = {
        "schema": SCHEMA, "tool": TOOL, "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "measurement": {"kind": a.source, "is_hardware_measurement": a.source in ("fpga", "asic"),
                        "is_silicon": a.source == "asic", "platform_register": KIND_OF_PLATFORM[plat],
                        "statement": STATEMENT[a.source]},
        "source_dump": {"file": Path(a.dump).name, "label": dump.get("label"), "producer": dump.get("producer"),
                        "baseline": Path(a.baseline).name if a.baseline else None, "snap_seq": d["snap_seq"],
                        "tb_config": dump.get("tb_config"), "workload": dump.get("workload")},
        "clock": clk,
        "hardware": {"build_id": f"0x{d['regs']['BUILD_ID']:08x}", "counter_bank": d["info"], "tile": d["tile"],
                     "frozen_at_snapshot": d["frozen"]},
        "counters": {k: {"value": v, "status": d["status"][k]} for k, v in d["values"].items()},
        "errors": {"hw_error_events": d["values"].get("HW_ERRORS"), "sources_flagged": d["err_sources"]},
        "derived": metrics,
        "conventions": {"fma_flops": d["tile"]["FMA_FLOPS"], "compare_flops": d["tile"]["CMP_FLOPS"],
                        "flop_definition": "FLOPS_RETIRED: lane FLOP weights at retirement (FADD/FSUB/FMUL 1, FMA "
                                           f"family {d['tile']['FMA_FLOPS']}, compares {d['tile']['CMP_FLOPS']}, FMV and "
                                           "integer 0) + reduction additions (one per active element) at completion",
                        "issued_vs_retired": "VEC_ISSUED counts lane acceptances, VEC_RETIRED lane result handovers"},
    }
    if a.source == "asic":
        out["measurement"]["silicon"] = {"silicon_id": a.silicon_id, "process": a.process}
    if a.source == "fpga":
        out["measurement"]["fpga"] = {"part": a.fpga_part, "bitstream": a.bitstream}
    if a.with_analytical:
        wl = json.loads(Path(a.with_analytical).read_text())
        cfg = {"NUM_LANES": d["tile"]["NUM_LANES"], "FMA_FLOPS": d["tile"]["FMA_FLOPS"],
               "DMA_PORTS": d["tile"]["DMA_PORTS"], "DMA_BYTES_PER_BEAT": d["tile"]["DMA_BYTES_PER_BEAT"]}
        an = analytical(cfg, wl, clk["hz"])
        out["analytical_reference"] = {"kind": "analytical_estimate", "statement": STATEMENT["analytical_estimate"],
                                       "estimate": an,
                                       "measured_over_ideal_cycles": _ratio(d["values"].get("CYCLES"),
                                                                            an["cycles_serial_lower_bound"])}
    return out


def cmd_analytical(a) -> dict:
    cfg = json.loads(Path(a.config).read_text())
    wl = json.loads(Path(a.workload).read_text())
    if not a.clock_hz:
        raise TelemetryError("analytical: --clock-hz is required (state the clock the estimate assumes)")
    return {"schema": SCHEMA, "tool": TOOL, "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "measurement": {"kind": "analytical_estimate", "is_hardware_measurement": False, "is_silicon": False,
                            "statement": STATEMENT["analytical_estimate"]},
            "clock": {"hz": float(a.clock_hz), "basis": "assumed"}, "configuration": cfg, "workload": wl,
            "estimate": analytical(cfg, wl, float(a.clock_hz))}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("read", help="snapshot + read a live register page into a dump")
    r.add_argument("--backend", choices=["devmem"], required=True)
    r.add_argument("--base", type=lambda x: int(x, 0), required=True)
    r.add_argument("--label", default="")
    r.add_argument("--out", required=True)
    d = sub.add_parser("derive", help="derive metrics from a dump")
    d.add_argument("dump")
    d.add_argument("--source", required=True, choices=["rtl_simulation", "fpga", "asic", "emulation"])
    d.add_argument("--clock-hz", type=float)
    d.add_argument("--clock-basis", choices=["pll_config", "measured", "nominal", "assumed"])
    d.add_argument("--baseline", help="earlier dump of the same build: report the interval")
    d.add_argument("--silicon-id")
    d.add_argument("--process")
    d.add_argument("--fpga-part")
    d.add_argument("--bitstream")
    d.add_argument("--with-analytical", metavar="WORKLOAD_JSON", help="add a separately labelled analytical reference")
    d.add_argument("--out")
    n = sub.add_parser("analytical", help="analytical estimate (no hardware)")
    n.add_argument("--config", required=True)
    n.add_argument("--workload", required=True)
    n.add_argument("--clock-hz", type=float)
    n.add_argument("--out")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "read":
            res = read_dump(DevMem(a.base), a.label)
        elif a.cmd == "derive":
            res = cmd_derive(a)
        else:
            res = cmd_analytical(a)
    except TelemetryError as e:
        print(f"REFUSED: {e}", file=sys.stderr)
        return 2
    text = json.dumps(res, indent=2) + "\n"
    if getattr(a, "out", None):
        Path(a.out).write_text(text)
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
