#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC Module 07 :: run_formal.sh -- formal checks of hpc_perf_counters
# Properties A1..A6 live in rtl/hpc_perf_counters.sv under `ifdef HPC_PERF_FORMAL (never defined for simulation or
# synthesis).  yosys 0.33 -> SMT2 -> yosys-smtbmc + z3 (>= 5; z3 4.8.12 from the Debian package hangs on the
# yosys-smtbmc pipe in this environment, the pip z3-solver 5.3.3 binary works):
#   BMC: DEPTH steps from reset, every input unconstrained (events, freeze, snapshot, error pulses and ARBITRARY
#        register-bus traffic, including invalid offsets and refused writes);
#   k-induction of the same depth: an unbounded proof where it closes.
# Negative controls: three mutants of the RTL must be REFUTED (a counterexample found), proving that the properties
# are not vacuous.
# usage: formal/run_formal.sh [DEPTH]
# =============================================================================
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/formal"; BLD="$ROOT/build/formal"
mkdir -p "$OUT" "$BLD"
D="${1:-20}"
SOLVER="${SOLVER:-z3}"
: > "$OUT/summary.txt"
"$SOLVER" --version | head -1 | sed 's/^/solver: /' | tee -a "$OUT/summary.txt"

smt() {  # src tag "chparams"
  yosys -q -l "$BLD/$2.yosys.log" -p "read_verilog -sv -formal -DHPC_PERF_FORMAL -I$ROOT/rtl $1;
     hierarchy -check -top hpc_perf_counters $3; prep -top hpc_perf_counters; async2sync; dffunmap;
     write_smt2 -wires $BLD/$2.smt2" >/dev/null 2>&1
}
for cfg in "NUM_CNT=2 CNT_W=40 INC_W=4 NUM_ERR=1" "NUM_CNT=3 CNT_W=8 INC_W=8 NUM_ERR=2" \
           "NUM_CNT=2 CNT_W=12 INC_W=4 NUM_ERR=1 SNAP_EN=0 PRELOAD_EN=0"; do
  tag=$(echo "$cfg" | tr ' =' '__')
  ch=$(for kv in $cfg; do echo -n " -chparam ${kv%%=*} ${kv##*=}"; done)
  smt "$ROOT/rtl/hpc_perf_counters.sv" "$tag" "$ch" || { echo "$cfg : yosys FAILED" | tee -a "$OUT/summary.txt"; continue; }
  t0=$SECONDS
  yosys-smtbmc -s "$SOLVER" -t "$D" "$BLD/$tag.smt2" > "$OUT/${tag}_bmc.log" 2>&1; b=$?
  t1=$SECONDS
  yosys-smtbmc -s "$SOLVER" -i -t "$D" "$BLD/$tag.smt2" > "$OUT/${tag}_induction.log" 2>&1; k=$?
  t2=$SECONDS
  bs=$([ $b -eq 0 ] && echo "PASS (no counterexample in $D steps)" || echo "FAIL")
  ks=$([ $k -eq 0 ] && echo "PROVEN (k-induction, k=$D)" || echo "not closed at k=$D")
  echo "$cfg : BMC $bs [$((t1 - t0)) s] ; induction $ks [$((t2 - t1)) s]" | tee -a "$OUT/summary.txt"
done
# ---------------------------------------------------------------- negative controls (must be refuted)
neg() {  # id description old new
  mkdir -p "$BLD/neg_$1"
  python3 - "$ROOT/rtl/hpc_perf_counters.sv" "$BLD/neg_$1/hpc_perf_counters.sv" "$3" "$4" <<'PY'
import sys
s = open(sys.argv[1]).read(); assert s.count(sys.argv[3]) == 1, sys.argv[3]
open(sys.argv[2], "w").write(s.replace(sys.argv[3], sys.argv[4]))
PY
  smt "$BLD/neg_$1/hpc_perf_counters.sv" "neg_$1" " -chparam NUM_CNT 2 -chparam CNT_W 40 -chparam INC_W 4 -chparam NUM_ERR 1"
  yosys-smtbmc -s "$SOLVER" -t "$D" "$BLD/neg_$1.smt2" > "$OUT/neg_$1.log" 2>&1 && r="NOT refuted (vacuous!)" || \
    r="refuted: $(grep -o 'Assert failed in [^:]*: [^ ]*' "$OUT/neg_$1.log" | head -1)"
  echo "negative control $1 ($2): $r" | tee -a "$OUT/summary.txt"
}
neg silent_sat "OVF not set in saturate mode" "| carry;   // a new overflow wins over W1C" "| (carry & ~sat_q[i]);"
neg snap_late "snapshot corrupted" "        snp_q       <= cnt_q;" "        snp_q       <= cnt_q ^ 'd1;"
neg latch_idx "latch hit ignores the counter index" "wire logic lat_hit = lat_v_q && (lat_idx_q == w_idx);" "wire logic lat_hit = lat_v_q;"
