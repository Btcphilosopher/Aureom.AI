// =============================================================================
// SilicaFlux-HPC Module 07 :: fv_hpc_perf_counters -- formal properties of the counter bank
//
// Unconstrained inputs (events, freeze, snapshot, error pulses, ANY register
// bus traffic) drive hpc_perf_counters (2 counters of 40 bits, so the high word
// is non-trivial, INC_W 4).  Properties (immediate assertions, checked by
// yosys-smtbmc + z3: bounded model check, then k-induction where it closes):
//   A1 no silent overflow: a counting cycle whose increment carries out of
//      CNT_W bits sets OVF[i] (unless the same cycle clears / preloads /
//      samples the counter, which is the documented priority);
//   A2 exact arithmetic: in a plain counting cycle the counter becomes
//      (value + increment) mod 2^CNT_W in wrap mode and min(value + increment,
//      MAX) in saturate mode; with counting off it holds;
//   A3 snapshot coherence: after a SNAPSHOT strobe or snap_i, EVERY snapshot
//      register equals the value its counter had at the start of that cycle;
//   A4 latched pair coherence: a LIVE_LO[i] read followed by the LIVE_HI[i] read
//      in the next cycle returns {HI, LO} = the counter value in the LO cycle;
//   A5 reset: one cycle after reset every counter and OVF bit is zero;
//   A6 OVF is sticky: once set it only clears by OVF W1C, CLEAR / CLR, SAMPLE or
//      reset.
// =============================================================================
`include "hpc_perf_defs.svh"
`default_nettype none

module fv_hpc_perf_counters (
  input wire logic        clk,
  input wire logic        rst_n,
  input wire logic        rb_sel,
  input wire logic        rb_we,
  input wire logic [11:0] rb_addr,
  input wire logic [31:0] rb_wdata,
  input wire logic [7:0]  inc_i,
  input wire logic        freeze_i,
  input wire logic        snap_i,
  input wire logic        err_i
);
  localparam int NC = 2, W = 40, IW = 4;
  localparam logic [W-1:0] MAXV = {W{1'b1}};
  logic [31:0]     rb_rdata;
  logic            rb_err, irq, frozen;
  logic [NC*W-1:0] cnt;

  hpc_perf_counters #(.NUM_CNT(NC), .CNT_W(W), .INC_W(IW), .NUM_ERR(1)) dut (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .inc_i, .freeze_i, .snap_i,
    .err_i, .irq_o(irq), .frozen_o(frozen), .cnt_o(cnt));

  // reset is asserted in the first cycle (initial state), afterwards unconstrained
  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);

  // ------------------------------------------------------------ per-cycle facts of the PREVIOUS cycle
  logic          p_valid = 1'b0;
  logic [W-1:0]  p_cnt [0:NC-1];
  logic [IW-1:0] p_inc [0:NC-1];
  logic [NC-1:0] p_go, p_sat, p_ovf, p_clr, p_pre, p_w1c;
  logic          p_sample, p_snap, p_lo_rd;
  logic [4:0]    p_lo_idx;
  wire  logic    acc_wr = rb_sel & rb_we & ~rb_err;
  wire  logic    acc_rd = rb_sel & ~rb_we & ~rb_err;
  wire  logic    w_ctrl = acc_wr && rb_addr == `HPC_PR_CTRL;
  always @(posedge clk) begin
    p_valid  <= rst_n;
    for (int i = 0; i < NC; i++) begin
      p_cnt[i] <= cnt[i*W +: W];
      p_inc[i] <= inc_i[i*IW +: IW];
    end
    p_go     <= dut.cnt_go;
    p_sat    <= dut.sat_q;
    p_ovf    <= dut.ovf_q;
    p_clr    <= dut.clr_v;
    p_pre    <= dut.pre_v;
    p_w1c    <= dut.ovf_w1c;
    p_sample <= dut.c_sample;
    p_snap   <= dut.c_snap;
    p_lo_rd  <= acc_rd && rb_addr[11:8] == 4'(`HPC_PR_LIVE_BASE >> 8) && !rb_addr[2];
    p_lo_idx <= rb_addr[7:3];
  end

  always @(posedge clk) if (p_valid && rst_n) begin
    for (int i = 0; i < NC; i++) begin
      logic [W:0] s;
      logic       plain;
      s = {1'b0, p_cnt[i]} + (W+1)'(p_go[i] ? p_inc[i] : '0);
      plain = !p_clr[i] && !p_pre[i] && !p_sample;
      // A1 no silent overflow
      if (plain && s[W]) A1: assert (dut.ovf_q[i]);
      // A2 exact arithmetic (wrap / saturate / hold)
      if (plain) A2: assert (cnt[i*W +: W] == ((s[W] && p_sat[i]) ? MAXV : s[W-1:0]));
      // A3 snapshot coherence (every counter, same cycle)
      if (p_snap) A3: assert (dut.snp_q[i*W +: W] == p_cnt[i]);
      // A6 OVF sticky
      if (p_ovf[i] && !p_w1c[i] && !p_clr[i] && !p_sample) A6: assert (dut.ovf_q[i]);
    end
    // A4 latched pair: LO read in the previous cycle, HI read of the same counter now
    if (p_lo_rd && p_lo_idx < 5'(NC) && rb_sel && !rb_we && rb_addr == 12'(`HPC_PR_LIVE_BASE + 8 * p_lo_idx + 4))
      A4: assert ({rb_rdata, dut.lat_hi_q} != 64'hx && rb_rdata == 32'(p_cnt[p_lo_idx[0]] >> 32));
  end
  // A5 reset
  logic p_rst = 1'b1;
  always @(posedge clk) p_rst <= !rst_n;
  always @(posedge clk) if (!init && p_rst && rst_n) A5: assert (cnt == '0 && dut.ovf_q == '0);
endmodule

`default_nettype wire
