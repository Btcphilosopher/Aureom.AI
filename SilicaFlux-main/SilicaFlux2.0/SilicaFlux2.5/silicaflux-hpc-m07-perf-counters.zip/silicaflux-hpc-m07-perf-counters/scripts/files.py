"""File lists for the SilicaFlux-HPC Module 07 builds (single source for every script)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TP = ROOT / "third_party"
DF = TP / "silicaflux-datafabric"
SL = TP / "silicaflux-sramlib/rtl/mem"
SPM = TP / "silicaflux-hpc-m04-scratchpad/rtl"
VA = TP / "silicaflux-hpc-m03-vector-array/rtl"
M05 = TP / "silicaflux-hpc-m05-dma-adapter"
RTL = ROOT / "rtl"

# ------------------------------------------------------------------ Module 07 RTL
PERF_CORE = [RTL / "hpc_perf_counters.sv"]
PERF_TILE = [RTL / "hpc_perf_wtrack.sv", RTL / "hpc_perf_events.sv", RTL / "hpc_perf_counters.sv", RTL / "hpc_perf_tile.sv"]
PERF_CDC = [RTL / "hpc_perf_cdc_sync.sv", RTL / "hpc_perf_cdc_count.sv"]

# ------------------------------------------------------------------ reused modules
SRAMLIB = [SL / f for f in [
    "sram_rsp_path.sv", "sram_backend_1rw.sv", "sram_backend_1r1w.sv", "sram_backend_2rw.sv", "sram_sp.sv",
    "backends/generic/sram_generic_1rw.sv", "backends/generic/sram_generic_1r1w.sv", "backends/generic/sram_generic_2rw.sv",
    "backends/fpga/sram_fpga_1rw.sv", "backends/fpga/sram_fpga_1r1w.sv", "backends/fpga/sram_fpga_2rw.sv",
    "backends/asic/sram_asic_array.sv", "backends/asic/sram_leaf_sky130.sv", "backends/asic/sram_leaf_gf180.sv",
    "backends/asic/sram_leaf_ihp1p.sv", "backends/asic/sram_leaf_ihp2p.sv", "backends/asic/stubs/sram_macro_blackboxes.sv"]]
DMA = [DF / "rtl/dma" / f for f in ["dma_fifo.sv", "dma_validate.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv"]]
XBAR = [DF / "rtl/interconnect" / f for f in [
    "sfb_addr_decoder.sv", "sfb_arbiter.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv", "sfb_error_slave.sv",
    "sfb_crossbar.sv", "sfb_skid_buffer.sv", "sfb_reg_slice.sv"]]
SFB_MEM = [DF / "rtl/mem/sfb_sram_slave.sv"]
SCRATCHPAD = [SPM / f for f in ["hpc_spm_addr_map.sv", "hpc_spm_bank_arb.sv", "hpc_spm_bank.sv", "hpc_spm_perf.sv",
                                "hpc_scratchpad.sv"]]
VA_PKG = [VA / "lane/hpc_vector_pkg.sv", VA / "hpc_varray_pkg.sv"]
VA_LANE = [VA / f for f in ["lane/hpc_pipe.sv", "lane/hpc_lzc.sv", "lane/hpc_fp32_round.sv", "lane/hpc_fp32_add.sv",
                            "lane/hpc_fp32_mul.sv", "lane/hpc_fp32_fma.sv", "lane/hpc_fp32_misc.sv",
                            "lane/hpc_int32_mul.sv", "lane/hpc_vector_lane.sv"]]
# Module 03 with the Module 07 observation port: the two patched files replace their originals
VARRAY_OBS = VA_PKG + VA_LANE + [VA / "hpc_varray_fifo.sv", RTL / "m03_obs/hpc_varray_issue.sv",
                                 VA / "hpc_varray_collect.sv", VA / "hpc_varray_reduce.sv", VA / "hpc_varray_perf.sv",
                                 RTL / "m03_obs/hpc_vector_array.sv"]
ADAPTER = [M05 / "rtl" / f for f in ["hpc_dma_perf.sv", "hpc_dma_spm_port.sv", "hpc_dma_route.sv", "hpc_dma_adapter.sv"]]
VSEQ = [M05 / "rtl/hpc_tile_vseq.sv"]
CHECKER = [DF / "tb/common/sfb_protocol_checker.sv"]

INCDIRS = [RTL, M05 / "rtl", DF / "rtl/dma", SL, SL / "backends/asic", SPM]
SIM_DEFINES = ["HPC_DMA_ASSERT", "HPC_SPM_ASSERT", "SRAMLIB_ASSERT", "SRAMLIB_POISON"]

UNIT_FILES = PERF_CORE + [ROOT / "tb/tb_hpc_perf_counters.sv"]
VARRAY_TB_FILES = VARRAY_OBS + PERF_TILE + [ROOT / "tb/tb_hpc_perf_varray.sv"]
CDC_TB_FILES = PERF_CDC + [ROOT / "tb/tb_hpc_perf_cdc.sv"]
EVENTS_TB_FILES = VA_PKG + PERF_TILE + [ROOT / "tb/tb_hpc_perf_events.sv"]
INTEG_DIR = ROOT / "build/integ"
TILE_FILES = SRAMLIB + DMA + XBAR + SFB_MEM + SCRATCHPAD + VARRAY_OBS + ADAPTER + VSEQ + CHECKER + PERF_TILE + \
             [ROOT / "tb/tb_hpc_tile_perf.sv"]
