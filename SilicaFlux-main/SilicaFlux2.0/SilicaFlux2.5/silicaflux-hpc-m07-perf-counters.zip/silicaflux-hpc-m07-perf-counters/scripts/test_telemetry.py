#!/usr/bin/env python3
"""Regression of host/hpc_perf_telemetry.py on the real RTL-simulation dumps (examples/regdump_rtl_sim*.json) and on
variants derived from them (platform codes, overflow / saturation / disabled counters, missing clock, foreign build).
Checks the provenance refusals, status propagation, interval arithmetic and the formulas (recomputed here
independently).  Writes reports/telemetry_tests.{md,json}; also regenerates the example outputs in examples/."""
from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "model"))
import perfmap as M  # noqa: E402

TOOL = ROOT / "host/hpc_perf_telemetry.py"
EX = ROOT / "examples"
results = []


def tool(*args):
    r = subprocess.run([sys.executable, str(TOOL), *map(str, args)], capture_output=True, text=True)
    out = json.loads(r.stdout) if r.returncode == 0 and r.stdout.strip() else None
    return r.returncode, out, r.stderr.strip()


def check(name, ok, detail=""):
    results.append(dict(test=name, ok=bool(ok), detail=detail))
    print("PASS" if ok else "FAIL", name, detail if not ok else "", sep="  ")


def variant(dump, tmp, name, **edit):
    d = copy.deepcopy(dump)
    for k, v in edit.items():
        if k == "platform":
            d["registers"]["INFO"] = (d["registers"]["INFO"] & ~(3 << 28)) | v << 28
        elif k == "snap":
            d["snapshot"].update(v)
        else:
            d["registers"][k] = v
    p = Path(tmp) / f"{name}.json"
    p.write_text(json.dumps(d))
    return p


def main() -> int:  # noqa: C901
    final, phase_a = EX / "regdump_rtl_sim.json", EX / "regdump_rtl_sim_phaseA.json"
    dump = json.loads(final.read_text())
    s = dump["snapshot"]
    with tempfile.TemporaryDirectory() as tmp:
        # ---------------------------------------------------------------- provenance
        rc, out, _ = tool("derive", final, "--source", "rtl_simulation")
        check("simulation dump derives as rtl_simulation", rc == 0 and out["measurement"]["kind"] == "rtl_simulation"
              and not out["measurement"]["is_hardware_measurement"] and out["clock"]["basis"].startswith("assumed"))
        for src in ("fpga", "asic", "emulation"):
            rc, _, err = tool("derive", final, "--source", src, "--clock-hz", "25e6", "--clock-basis", "pll_config",
                              "--silicon-id", "X", "--process", "Y")
            check(f"simulation dump refused as {src}", rc == 2 and "refused" in err, err)
        fpga = variant(dump, tmp, "fpga", platform=1)
        rc, out, _ = tool("derive", fpga, "--source", "fpga", "--clock-hz", "25e6", "--clock-basis", "pll_config",
                          "--fpga-part", "LFE5U-85F", "--bitstream", "test")
        check("FPGA dump derives as fpga, labelled not-ASIC", rc == 0 and out["measurement"]["kind"] == "fpga" and
              not out["measurement"]["is_silicon"] and "NOT ASIC" in out["measurement"]["statement"])
        rc, _, err = tool("derive", fpga, "--source", "asic", "--clock-hz", "1e9", "--clock-basis", "pll_config",
                          "--silicon-id", "X", "--process", "Y")
        check("FPGA dump refused as ASIC", rc == 2 and "PLATFORM = 1" in err, err)
        asic = variant(dump, tmp, "asic", platform=2)
        rc, _, err = tool("derive", asic, "--source", "asic", "--clock-hz", "1e9", "--clock-basis", "measured")
        check("ASIC without silicon identification refused", rc == 2 and "silicon-id" in err, err)
        rc, out, _ = tool("derive", asic, "--source", "asic", "--clock-hz", "1e9", "--clock-basis", "measured",
                          "--silicon-id", "lot7-w3-d12", "--process", "example")
        check("ASIC dump with identification accepted", rc == 0 and out["measurement"]["is_silicon"] and
              out["measurement"]["silicon"]["silicon_id"] == "lot7-w3-d12")
        rc, _, err = tool("derive", fpga, "--source", "fpga", "--clock-hz", "25e6")
        check("hardware clock without basis refused", rc == 2 and "clock-basis" in err, err)
        noclk = variant(dump, tmp, "noclk", CLK_KHZ=0)
        rc, _, err = tool("derive", noclk, "--source", "rtl_simulation")
        check("no clock at all refused", rc == 2 and "no clock" in err, err)
        # ---------------------------------------------------------------- formulas (recomputed independently)
        rc, out, _ = tool("derive", final, "--source", "rtl_simulation")
        dv = out["derived"]
        f = 25e6
        exp = {"elapsed_time": s["CYCLES"] / f,
               "lane_utilisation_while_busy": s["VEC_ISSUED"] / (4 * s["VEC_BUSY"]),
               "compute_throughput": s["FLOPS_RETIRED"] / (s["CYCLES"] / f),
               "dma_effective_bandwidth": (s["DMA_BYTES_RD"] + s["DMA_BYTES_WR"]) / (s["CYCLES"] / f),
               "memory_stall_pct_of_vector_busy": 100 * s["VEC_OPND_STARVE"] / s["VEC_BUSY"],
               "cycles_per_vector_element_op": s["CYCLES"] / s["VEC_RETIRED"],
               "mean_command_latency": s["CMD_INFLIGHT_SUM"] / s["CMD_COMPLETED"]}
        for k, v in exp.items():
            check(f"formula {k}", abs(dv[k]["value"] - v) <= 1e-9 * abs(v), f"{dv[k]['value']} vs {v}")
        check("FLOP convention recorded (FMA = 2)", out["conventions"]["fma_flops"] == 2)
        # ---------------------------------------------------------------- overflow / saturation / disabled
        wr = variant(dump, tmp, "wrapped", SNAP_OVF=1 << M.CNT["VEC_RETIRED"])
        rc, out, _ = tool("derive", wr, "--source", "rtl_simulation")
        check("wrapped counter reported as invalid", rc == 0 and out["counters"]["VEC_RETIRED"]["status"].startswith("wrapped"))
        check("metric on a wrapped counter withheld", out["derived"]["cycles_per_vector_element_op"]["value"] is None and
              out["derived"]["cycles_per_vector_element_op"]["status"].startswith("unavailable"))
        sat = variant(dump, tmp, "saturated", SNAP_OVF=1 << M.CNT["FLOPS_RETIRED"], SAT=1 << M.CNT["FLOPS_RETIRED"],
                      snap={"FLOPS_RETIRED": (1 << 64) - 1})
        rc, out, _ = tool("derive", sat, "--source", "rtl_simulation")
        check("saturated counter reported as lower bound", out["counters"]["FLOPS_RETIRED"]["status"].startswith("saturated"))
        check("metric on a saturated counter is a bound", out["derived"]["compute_throughput"]["status"].startswith("bound only"))
        dis = variant(dump, tmp, "disabled", CNT_EN=((1 << M.NUM_CNT) - 1) & ~(1 << M.CNT["SPM_CONFLICTS"]))
        rc, out, _ = tool("derive", dis, "--source", "rtl_simulation")
        check("disabled counter reported as not counted", out["counters"]["SPM_CONFLICTS"]["status"].startswith("not_counted")
              and out["derived"]["spm_conflicts_per_access"]["value"] is None)
        ph = variant(dump, tmp, "phase1", TILECFG=(dump["registers"]["TILECFG"] & ~(3 << 29)) | 1 << 29)
        rc, out, _ = tool("derive", ph, "--source", "rtl_simulation")
        check("counter above INSTR_PHASE reported as not instrumented",
              out["counters"]["SPM_READS"]["status"].startswith("not_instrumented") and
              out["counters"]["VEC_RETIRED"]["status"] == "valid")
        # ---------------------------------------------------------------- interval
        a = json.loads(phase_a.read_text())["snapshot"]
        rc, out, _ = tool("derive", final, "--source", "rtl_simulation", "--baseline", phase_a)
        check("interval mode: deltas", rc == 0 and all(out["counters"][k]["value"] == s[k] - a[k] for k in s))
        other = variant(dump, tmp, "otherbuild", BUILD_ID=dump["registers"]["BUILD_ID"] ^ 1)
        rc, _, err = tool("derive", final, "--source", "rtl_simulation", "--baseline", other)
        check("interval across different builds refused", rc == 2 and "different builds" in err, err)
        wrapdelta = variant(dump, tmp, "wrapdelta", snap={"CYCLES": 5})
        basebig = variant(json.loads(phase_a.read_text()), tmp, "basebig", snap={"CYCLES": (1 << 64) - 10})
        rc, out, _ = tool("derive", wrapdelta, "--source", "rtl_simulation", "--baseline", basebig)
        check("interval across a 64-bit wrap is modular", rc == 0 and out["counters"]["CYCLES"]["value"] == 15)
        # ---------------------------------------------------------------- analytical stays separate
        rc, out, _ = tool("analytical", "--config", EX / "config_tile_n4.json", "--workload", EX / "workload_m05_tile.json",
                          "--clock-hz", "25e6")
        check("analytical estimate labelled as such", rc == 0 and out["measurement"]["kind"] == "analytical_estimate"
              and not out["measurement"]["is_hardware_measurement"] and "counters" not in out)
        rc, _, err = tool("analytical", "--config", EX / "config_tile_n4.json", "--workload", EX / "workload_m05_tile.json")
        check("analytical without a stated clock refused", rc == 2, err)
    # ---------------------------------------------------------------- example outputs (regenerated from the real dumps)
    tool("derive", final, "--source", "rtl_simulation", "--with-analytical", EX / "workload_m05_tile.json",
         "--out", EX / "telemetry_rtl_sim.json")
    tool("derive", final, "--source", "rtl_simulation", "--baseline", phase_a, "--out", EX / "telemetry_rtl_sim_phaseB_interval.json")
    tool("analytical", "--config", EX / "config_tile_n4.json", "--workload", EX / "workload_m05_tile.json",
         "--clock-hz", "25e6", "--out", EX / "telemetry_analytical.json")
    lines = []
    for src in ("fpga", "asic"):
        r = subprocess.run([sys.executable, str(TOOL), "derive", str(final), "--source", src, "--clock-hz", "25e6",
                            "--clock-basis", "pll_config", "--silicon-id", "X", "--process", "Y"], capture_output=True, text=True)
        lines.append(f"$ hpc_perf_telemetry.py derive examples/regdump_rtl_sim.json --source {src} ...\n{r.stderr.strip()}\n"
                     f"(exit status {r.returncode})\n")
    (EX / "provenance_refusals.txt").write_text("\n".join(lines))
    n = sum(r["ok"] for r in results)
    md = ["# Telemetry tool tests", "", f"Generated by `scripts/test_telemetry.py` ({time.strftime('%Y-%m-%d %H:%M')}).", "",
          f"**{n} / {len(results)} pass.** Inputs: the real RTL-simulation dumps written by `tb/tb_hpc_tile_perf.sv` and "
          "variants of them (platform code, OVF / SAT / CNT_EN bits, TILECFG.INSTR_PHASE, clock register, build id).", "",
          "| Test | Result | Detail |", "|---|---|---|"] + \
         [f"| {r['test']} | {'PASS' if r['ok'] else 'FAIL'} | {r['detail'] if not r['ok'] else ''} |" for r in results] + [""]
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports/telemetry_tests.md").write_text("\n".join(md))
    (ROOT / "reports/telemetry_tests.json").write_text(json.dumps(results, indent=1))
    print(f"{n}/{len(results)} PASS")
    return 0 if n == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
