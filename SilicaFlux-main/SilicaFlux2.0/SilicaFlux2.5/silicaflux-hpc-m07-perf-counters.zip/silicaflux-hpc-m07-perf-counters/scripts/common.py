"""Shared build / run helpers for the SilicaFlux-HPC Module 07 scripts (house pattern of Module 05)."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import time
from pathlib import Path

import files as F

ROOT = F.ROOT
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"

VERILATOR_FLAGS = ["--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style",
                   "-Wno-MULTIDRIVEN", "-Wno-INITIALDLY"]


def cfg_key(cfg: dict) -> str:
    return "_".join(f"{k}{v}" for k, v in sorted(cfg.items())) or "default"


def _digest(files, cfg, defines, extra, incdirs) -> str:
    h = hashlib.sha256(json.dumps([sorted(str(f) for f in files), cfg, defines, extra]).encode())
    for f in list(files) + [p for inc in incdirs for p in sorted(Path(inc).glob("*.svh"))]:
        h.update(Path(f).read_bytes())
    return h.hexdigest()


def verilator_build(top: str, files: list[Path], cfg: dict, tag: str = "", defines: list[str] | None = None,
                    extra: list[str] | None = None, incdirs: list[Path] | None = None, src_override=None) -> Path:
    """Builds (cached by content digest) and returns the executable. src_override: {original: replacement}."""
    incdirs = list(F.INCDIRS if incdirs is None else incdirs)
    files = [src_override.get(f, f) if src_override else f for f in files]
    d = BUILD / "vl" / (top + "_" + (tag or cfg_key(cfg)))
    exe = d / "sim"
    stamp = d / "stamp.json"
    digest = _digest(files, cfg, defines, extra, incdirs)
    if exe.exists() and stamp.exists() and json.loads(stamp.read_text()).get("digest") == digest:
        return exe
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    cmd = ["verilator"] + VERILATOR_FLAGS + ["-j", "2", "--top-module", top, "-Mdir", str(d), "-o", "sim"]
    cmd += [f"-I{p}" for p in incdirs]
    cmd += [f"+define+{x}" for x in (F.SIM_DEFINES if defines is None else defines)]
    cmd += [f"-G{k}={v}" for k, v in cfg.items()]
    cmd += (extra or []) + [str(f) for f in files]
    r = subprocess.run(cmd, capture_output=True, text=True)
    (d / "build.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0 or not exe.exists():
        raise RuntimeError(f"verilator build failed ({top} {cfg}): see {d / 'build.log'}")
    stamp.write_text(json.dumps({"digest": digest}))
    return exe


def icarus_build(top: str, files: list[Path], cfg: dict, tag: str = "", defines: list[str] | None = None,
                 incdirs: list[Path] | None = None) -> Path:
    incdirs = list(F.INCDIRS if incdirs is None else incdirs)
    d = BUILD / "ivl" / (top + "_" + (tag or cfg_key(cfg)))
    d.mkdir(parents=True, exist_ok=True)
    out = d / "sim.vvp"
    cmd = ["iverilog", "-g2012", "-o", str(out), "-s", top]
    cmd += [f"-I{p}" for p in incdirs]
    cmd += [f"-D{x}" for x in (F.SIM_DEFINES if defines is None else defines)]
    cmd += [f"-P{top}.{k}={v}" for k, v in cfg.items()]
    cmd += [str(f) for f in files]
    r = subprocess.run(cmd, capture_output=True, text=True)
    (d / "build.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0 or not out.exists():
        raise RuntimeError(f"icarus build failed ({top} {cfg}): see {d / 'build.log'}")
    return out


def run_sim(sim: str, exe: Path, args: list[str], timeout: int = 3600, cwd: Path | None = None,
            tag: str = "TB_PERF") -> tuple[bool, str, float]:
    cmd = ([str(exe)] if sim == "verilator" else ["vvp", "-n", str(exe)]) + args
    t0 = time.time()
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        out += "\nTIMEOUT"
    dt = time.time() - t0
    ok = re.search(rf"{tag} RESULT PASS", out) is not None and \
        re.search(r"RESULT FAIL|%Error|Assertion failed|ERROR", out) is None
    return ok, out, dt


def tool_versions() -> dict:
    v = {}
    for tool, args in [("verilator", ["--version"]), ("iverilog", ["-V"]), ("yosys", ["-V"]), ("z3", ["--version"])]:
        try:
            r = subprocess.run([tool] + args, capture_output=True, text=True, timeout=30)
            v[tool] = (r.stdout or r.stderr).strip().splitlines()[0]
        except Exception:  # noqa: BLE001
            v[tool] = "not available"
    v["python"] = platform.python_version()
    v["host"] = f"{platform.system()} {platform.machine()}, {os.cpu_count()} CPUs"
    return v


def write_report(name: str, md: str, data: dict) -> None:
    REPORTS.mkdir(exist_ok=True)
    (REPORTS / f"{name}.md").write_text(md)
    (REPORTS / f"{name}.json").write_text(json.dumps(data, indent=1))
