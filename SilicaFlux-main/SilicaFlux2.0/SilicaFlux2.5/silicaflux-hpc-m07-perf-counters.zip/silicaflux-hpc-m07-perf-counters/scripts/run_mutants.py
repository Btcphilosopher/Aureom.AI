#!/usr/bin/env python3
"""Mutation testing of the Module 07 RTL: each mutant is one plausible bug; the regression must FAIL ("killed").
  hpc_perf_counters  -> unit testbench (default x 2 seeds, lean configuration x 1) + reference-model trace replay
  hpc_perf_events / hpc_perf_wtrack -> event-layer testbench (synthetic) + vector-array testbench (2 seeds)
                                       + tile testbench (stress configuration)
  hpc_perf_cdc_count -> CDC testbench (two ratios)
Writes reports/mutants.{md,json}.  usage: run_mutants.py [--jobs J]"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import files as F  # noqa: E402
from common import BUILD, run_sim, tool_versions, verilator_build, write_report  # noqa: E402

C, E, W, X = F.RTL / "hpc_perf_counters.sv", F.RTL / "hpc_perf_events.sv", F.RTL / "hpc_perf_wtrack.sv", \
    F.RTL / "hpc_perf_cdc_count.sv"
MUTANTS = [
    # ---------------------------------------------------------------- counter bank
    ("C01", C, "multi-valued events counted as one", "+ (CNT_W+1)'(inc);", "+ (CNT_W+1)'(inc != '0);"),
    ("C02", C, "silent saturation: OVF not set in saturate mode", "| carry;   // a new overflow wins over W1C",
     "| (carry & ~sat_q[i]);"),
    ("C03", C, "saturate mode ignored (always wraps)", "(carry && sat_q[i]) ? MAXV", "(1'b0) ? MAXV"),
    ("C04", C, "always saturates", "(carry && sat_q[i]) ? MAXV", "(carry) ? MAXV"),
    ("C05", C, "W1C beats a same-cycle overflow", "(ovf_q[i] & ~ovf_w1c[i]) | carry", "(ovf_q[i] | carry) & ~ovf_w1c[i]"),
    ("C06", C, "snapshot does not capture OVF", "snp_ovf_q   <= ovf_q;", "snp_ovf_q   <= '0;"),
    ("C07", C, "snapshot sequence not advanced", "snp_seq_q   <= snp_seq_q + 16'd1;", "snp_seq_q   <= snp_seq_q;"),
    ("C08", C, "latched high word not captured", "lat_hi_q  <= live64[63:32];", "lat_hi_q  <= lat_hi_q;"),
    ("C09", C, "latch hit ignores the counter index", "wire logic lat_hit = lat_v_q && (lat_idx_q == w_idx);",
     "wire logic lat_hit = lat_v_q;"),
    ("C10", C, "hardware freeze ignored", "assign frozen_o = ctl_frz_q | freeze_i |", "assign frozen_o = ctl_frz_q |"),
    ("C11", C, "freeze-on-overflow ignored", "(ctl_fov_q & (|ovf_q));", "1'b0;"),
    ("C12", C, "per-counter enable ignored", "{NC{ctl_en_q & ~frozen_o}} & cnt_en_q;", "{NC{ctl_en_q & ~frozen_o}};"),
    ("C13", C, "CLEAR leaves OVF set", """      end else if (clr_v[i]) begin
        cnt_q[i*CNT_W +: CNT_W] <= '0;
        ovf_q[i]                <= 1'b0;""", """      end else if (clr_v[i]) begin
        cnt_q[i*CNT_W +: CNT_W] <= '0;"""),
    ("C14", C, "SAMPLE loses the events of its own cycle", "cnt_q[i*CNT_W +: CNT_W] <= CNT_W'(inc);",
     "cnt_q[i*CNT_W +: CNT_W] <= '0;"),
    ("C15", C, "preload halves swapped", "wire logic [63:0]   pre_val = {pre_hi_q, pre_lo_q};",
     "wire logic [63:0]   pre_val = {pre_lo_q, pre_hi_q};"),
    ("C16", C, "write to ID not refused", "`HPC_PR_ID:       begin rb_rdata = `HPC_PERF_ID;      rb_err = rb_we; end",
     "`HPC_PR_ID:       begin rb_rdata = `HPC_PERF_ID;      rb_err = 1'b0; end"),
    ("C17", C, "refused writes still take effect", "wire logic acc_wr = wr & ~rb_err;", "wire logic acc_wr = wr;"),
    ("C18", C, "error-source W1C beats a same-cycle error", "err_q <= (err_q & ~((acc_wr && rb_addr == `HPC_PR_ERR_SRC) ? "
     "rb_wdata[NUM_ERR-1:0] : '0)) | err_i;", "err_q <= (err_q | err_i) & ~((acc_wr && rb_addr == `HPC_PR_ERR_SRC) ? "
     "rb_wdata[NUM_ERR-1:0] : '0);"),
    ("C19", C, "out-of-range counter index accepted", "wire logic        w_ok     = (rb_addr[1:0] == 2'b00) && (32'(w_idx) < NC);",
     "wire logic        w_ok     = (rb_addr[1:0] == 2'b00);"),
    ("C20", C, "interrupt ignores OVF_IE", "assign irq_o = |(ovf_q & ovf_ie_q);", "assign irq_o = |ovf_q;"),
    ("C21", C, "snapshot value corrupted (off by one in counter 0)", "        snp_q       <= cnt_q;",
     "        snp_q       <= cnt_q + 'd1;"),
    ("C22", C, "latch not consumed by its HI read", "        lat_v_q   <= 1'b0;                                               // a latch is consumed by its HI read",
     "        lat_v_q   <= lat_v_q;"),
    # ---------------------------------------------------------------- event binding
    ("E01", E, "VEC_RETIRED counts one per cycle (multi-lane retirement lost)",
     "INC_W'(popcnt_n(va_lane_retire));", "INC_W'(|va_lane_retire);"),
    ("E02", E, "FLOPs credited with the op being issued now, not the retiring one",
     "if (va_lane_retire[l]) lane_flops = lane_flops + 8'(w_head[l*2 +: 2]);",
     "if (va_lane_retire[l]) lane_flops = lane_flops + 8'(flop_w(va_lane_op));"),
    ("E03", E, "FMA counted as one FLOP", "hpc_vector_pkg::OP_FNMSUB, hpc_vector_pkg::OP_FNMADD: flop_w = 2'(FMA_FLOPS);",
     "hpc_vector_pkg::OP_FNMSUB, hpc_vector_pkg::OP_FNMADD: flop_w = 2'd1;"),
    ("E04", E, "reduction additions not counted", "INC_W'(lane_flops) + INC_W'(red_adds);", "INC_W'(lane_flops);"),
    ("E05", E, "reduction adds of illegal commands counted", "(va_cpl_hs & va_cpl_red & ~va_cpl_illegal)",
     "(va_cpl_hs & va_cpl_red)"),
    ("E06", E, "VEC_STALL excludes operand starvation", "va_stall_lane | va_stall_trk | va_opnd_starve;   // beat due",
     "va_stall_lane | va_stall_trk;   // beat due"),
    ("E07", E, "DMA read / write bytes swapped", "inc[`HPC_PC_DMA_BYTES_RD  *INC_W +: INC_W] = INC_W'(dma_bytes_rd);",
     "inc[`HPC_PC_DMA_BYTES_RD  *INC_W +: INC_W] = INC_W'(dma_bytes_wr);"),
    ("E08", E, "SPM_READS counts writes too", "INC_W'(popcnt_p(spm_req_valid & spm_req_ready & ~spm_req_we));",
     "INC_W'(popcnt_p(spm_req_valid & spm_req_ready));"),
    ("E09", E, "bank conflicts counted once per cycle", "INC_W'(popcnt_p(spm_conflict));", "INC_W'(|spm_conflict);"),
    ("E10", E, "OUT_BP misses the DMA completion port", """(va_cpl_valid & ~va_cpl_ready) |
                            (dma_cpl_valid & ~dma_cpl_ready);""", """(va_cpl_valid & ~va_cpl_ready);"""),
    ("E11", E, "CMDQ_FULL misses the DMA descriptor queue", "va_cmdq_full | (DMA_CMDQ & ~dma_cmd_ready);",
     "va_cmdq_full;"),
    ("E12", E, "in-flight count ignores DMA completions", "- 18'(va_cpl_hs) - 18'(dm_cpl_hs);", "- 18'(va_cpl_hs);"),
    ("E13", E, "freeze request not carried through the event register", "        freeze_o <= freeze_i;",
     "        freeze_o <= 1'b0;"),
    ("E14", E, "illegal vector completions not counted as errors", "8'(err_src[`HPC_ERR_VEC_ILLEGAL]) +", "8'(0) +"),
    ("E15", E, "CMD_COMPLETED counts valid, not handshake", "inc[`HPC_PC_CMD_COMPLETED *INC_W +: INC_W] = INC_W'(va_cpl_hs)",
     "inc[`HPC_PC_CMD_COMPLETED *INC_W +: INC_W] = INC_W'(va_cpl_valid)"),
    ("E16", E, "VEC_ISSUED counts retirements", "INC_W'(popcnt_n(va_lane_accept));", "INC_W'(popcnt_n(va_lane_retire));"),
    ("E17", E, "DMA_ACTIVE counts DMA completions", "INC_W'(dma_active);", "INC_W'(dm_cpl_hs);"),
    ("W01", W, "weight tracker pops the newest entry (LIFO)", "assign head_o = empty ? '0 : mem_q[rd_q*W +: W];",
     "assign head_o = empty ? '0 : mem_q[((wr_q == '0) ? IW'(DEPTH - 1) : wr_q - IW'(1))*W +: W];"),
    ("W02", W, "weight tracker drops a push when popping while full", "wire logic do_push = push_i & (~full | do_pop);",
     "wire logic do_push = push_i & ~full;"),
    # ---------------------------------------------------------------- CDC
    ("X01", X, "source overwrites the transfer register while busy", "wire logic        idle = !busy_q || done;",
     "wire logic        idle = 1'b1;"),
    ("X02", X, "accumulator not cleared on send (duplication)", "        acc_q   <= '0;\n        req_tgl <= ~req_tgl;",
     "        req_tgl <= ~req_tgl;"),
    ("X03", X, "events of the send cycle dropped", "hold_q  <= sum[AW] ? {AW{1'b1}} : sum[AW-1:0];", "hold_q  <= acc_q;"),
    ("X04", X, "destination never acknowledges", "if (req_s != req_seen) ack_tgl <= req_s;", "ack_tgl <= ack_tgl;"),
    ("X05", X, "overflow flag never raised", "if (sum[AW]) sovf_q <= 1'b1;", "if (1'b0) sovf_q <= 1'b1;"),
]
TB_UNIT = dict(TILE_CFG=0xA5A50F0F, CLK_KHZ=100000, BUILD_ID=0x07002026)


def mutate(mid, path, old, new):
    src = path.read_text()
    if src.count(old) != 1:
        return None
    d = BUILD / "mut" / mid
    d.mkdir(parents=True, exist_ok=True)
    m = d / path.name
    m.write_text(src.replace(old, new))
    return m


def unit_check(mid, ov):
    lean = dict(SNAP_EN=0, PRELOAD_EN=0, CNT_W=32)
    for seed, cfg in ((1, {}), (2, {}), (3, lean)):
        exe = verilator_build("tb_hpc_perf_counters", F.UNIT_FILES, dict(TB_UNIT, **cfg), tag=f"mut_{mid}_{len(cfg)}",
                              src_override=ov)
        trc = BUILD / "mut" / mid / f"s{seed}.trc"
        ok, out, _ = run_sim("verilator", exe, [f"+seed={seed}", "+cycles=8000", f"+trace={trc}"], tag="TB_PERF")
        margs = ["--snap-en", "0", "--preload-en", "0", "--cnt-w", "32"] if cfg else []
        r = subprocess.run([sys.executable, str(F.ROOT / "model/perf_ref.py"), str(trc), "--tile-cfg", "0xA5A50F0F",
                            "--clk-khz", "100000", "--build-id", "0x07002026"] + margs, capture_output=True, text=True)
        trc.unlink(missing_ok=True)
        if not ok:
            return "testbench"
        if r.returncode != 0:
            return "reference model"
    return None


def event_check(mid, ov):
    for cfg in ({}, dict(N=16, NSP=3)):
        exe = verilator_build("tb_hpc_perf_events", F.EVENTS_TB_FILES, cfg, tag=f"mut_{mid}_{len(cfg)}", src_override=ov)
        ok, _, _ = run_sim("verilator", exe, [], tag="TB_EV")
        if not ok:
            return "event-layer testbench (synthetic stimulus)"
    for seed in (1, 2):
        exe = verilator_build("tb_hpc_perf_varray", F.VARRAY_TB_FILES, {}, tag=f"mut_{mid}", src_override=ov)
        ok, _, _ = run_sim("verilator", exe, [f"+seed={seed}"], tag="TB_VA_PERF")
        if not ok:
            return "vector-array testbench"
    cfg = dict(ENGINE=1, DUAL_PORT=1, HOLD_PCT=25, CPL_BP_PCT=30)
    exe = verilator_build("tb_hpc_tile_perf", F.TILE_FILES, cfg, tag=f"mut_{mid}", src_override=ov, extra=[f"-I{F.INTEG_DIR}"])
    wd = BUILD / "mut" / mid / "tile"
    wd.mkdir(parents=True, exist_ok=True)
    for f in F.INTEG_DIR.glob("*.hex"):
        shutil.copy(f, wd / f.name)
    ok, _, _ = run_sim("verilator", exe, [], cwd=wd, tag="TB_TILE_PERF")
    return None if ok else "tile testbench"


def cdc_check(mid, ov):
    for cfg in ({}, dict(SRC_PS=17300, DST_PS=10000)):
        exe = verilator_build("tb_hpc_perf_cdc", F.CDC_TB_FILES + F.PERF_CORE, cfg, tag=f"mut_{mid}_{len(cfg)}",
                              src_override=ov, defines=["HPC_CDC_META"])
        ok, _, _ = run_sim("verilator", exe, [], tag="TB_CDC", timeout=600)
        if not ok:
            return "CDC testbench"
    # the overflow mutant needs the undersized configuration
    exe = verilator_build("tb_hpc_perf_cdc", F.CDC_TB_FILES + F.PERF_CORE, dict(SRC_PS=2000, DST_PS=25000, AW=4, EW=4,
                          MAX_EV=15, EXPECT_OVF=1), tag=f"mut_{mid}_ovf", src_override=ov, defines=["HPC_CDC_META"])
    ok, _, _ = run_sim("verilator", exe, [], tag="TB_CDC", timeout=600)
    return None if ok else "CDC testbench (undersized accumulator)"


def run(m):
    mid, path, desc, old, new = m
    mp = mutate(mid, path, old, new)
    if mp is None:
        return dict(id=mid, file=path.name, desc=desc, status="NOT APPLIED (pattern not found)", by=None)
    ov = {path: mp}
    try:
        by = (unit_check if path == C else cdc_check if path == X else event_check)(mid, ov)
    except RuntimeError as e:
        return dict(id=mid, file=path.name, desc=desc, status="stillborn (does not compile)", by=str(e)[:80])
    return dict(id=mid, file=path.name, desc=desc, status="killed" if by else "SURVIVED", by=by)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    t0 = time.time()
    ms = [m for m in MUTANTS if not a.only or m[0].startswith(a.only)]
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run, ms))
    for r in res:
        print(r["id"], r["status"], r["by"] or "", r["desc"], sep="  ")
    killed = sum(r["status"] == "killed" for r in res)
    md = ["# Mutation testing", "", f"Generated by `scripts/run_mutants.py` ({time.strftime('%Y-%m-%d %H:%M')}), "
          f"{round(time.time() - t0)} s.", "", "Tools: " + ", ".join(f"{k} = {v}" for k, v in tool_versions().items()), "",
          f"**{killed} / {len(res)} mutants killed.** Each mutant is one plausible bug injected into one RTL file; it is "
          "killed when any check fails: unit testbench + reference-model replay (counter bank), vector-array and tile "
          "testbenches and the synthetic event-layer testbench (event binding, weight tracker), CDC testbench (crossing).", "",
          "| Id | File | Injected bug | Result | Detected by |", "|---|---|---|---|---|"]
    for r in res:
        md.append(f"| {r['id']} | `{r['file']}` | {r['desc']} | {r['status']} | {r['by'] or '-'} |")
    md.append("")
    write_report("mutants", "\n".join(md), dict(mutants=res))
    return 0 if killed == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
