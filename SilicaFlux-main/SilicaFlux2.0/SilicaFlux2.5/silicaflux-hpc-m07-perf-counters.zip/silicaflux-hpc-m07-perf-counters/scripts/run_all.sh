#!/usr/bin/env bash
# Full regression in dependency order; each step's log in build/all/<step>.log; overall status in build/all/STATUS.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
mkdir -p build/all; : > build/all/STATUS
step() { local n=$1; shift; local t0=$SECONDS; "$@" > "build/all/$n.log" 2>&1; local rc=$?
         echo "$n exit=$rc $((SECONDS - t0)) s" | tee -a build/all/STATUS; }
step lint      python3 scripts/run_lint.py
step unit      python3 scripts/run_unit.py --jobs 4
step integ     python3 scripts/run_integ.py --jobs 4
step cdc       python3 scripts/run_cdc.py --jobs 4
step formal    bash formal/run_formal.sh 20
step telemetry python3 scripts/test_telemetry.py
step mutants   python3 scripts/run_mutants.py --jobs 3
step synth     python3 scripts/run_synth.py --jobs 2
echo DONE | tee -a build/all/STATUS
