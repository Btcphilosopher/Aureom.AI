#!/usr/bin/env python3
"""Integration regression of the telemetry unit on real hardware blocks.

  stage 1  phase-1 bring-up: INSTR_PHASE = 1 (cycle, vector-retirement, DMA-byte and stall counters only) on the tile;
           every other stage runs only if stage 1 passes
  stage 2  tile (tb/tb_hpc_tile_perf.sv): Module 05 workload on the three DMA engine variants, a stress variant (lane
           holds + DMA completion back-pressure), no event register, INSTR_PHASE = 2; Icarus on the baseline
  stage 3  vector array (tb/tb_hpc_perf_varray.sv): reductions, masks, all opcode classes, illegal commands, lane
           holds and back-pressure for NUM_LANES 1 / 2 / 4 / 8 / 16 and the FLOP-convention variants
Writes reports/integration.{md,json}; copies the baseline run's regdump.json to examples/regdump_rtl_sim.json.
usage: run_integ.py [--seed S] [--no-icarus] [--jobs J]"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import files as F  # noqa: E402
from common import BUILD, icarus_build, run_sim, tool_versions, verilator_build, write_report  # noqa: E402

STAGE1 = [("phase-1 bring-up (INSTR_PHASE=1), simple engine", dict(INSTR_PHASE=1))]
TILE = [("simple engine (baseline)", {}),
        ("buffered engine, single port", dict(ENGINE=1)),
        ("buffered engine, dual port", dict(ENGINE=1, DUAL_PORT=1)),
        ("stress: dual port, 25 % lane holds, 30 % DMA completion back-pressure",
         dict(ENGINE=1, DUAL_PORT=1, HOLD_PCT=25, CPL_BP_PCT=30)),
        ("no event register (EV_REG=0), buffered single port", dict(ENGINE=1, EV_REG=0)),
        ("phase 2 (INSTR_PHASE=2), stress", dict(ENGINE=1, HOLD_PCT=25, CPL_BP_PCT=30, INSTR_PHASE=2))]
VARRAY = [("N=1", dict(N=1)), ("N=2", dict(N=2)), ("N=4", {}), ("N=8", dict(N=8)), ("N=16, 5 % holds", dict(N=16, HOLD_PCT=5)),
          ("N=4, FMA=1 FLOP, compares=1 FLOP", dict(FMA_FLOPS=1, CMP_FLOPS=1)),
          ("N=8, EV_REG=0, no holds, no back-pressure", dict(N=8, EV_REG=0, HOLD_PCT=0, BP_PCT=0, GAP_PCT=0)),
          ("N=4, heavy back-pressure 70 %", dict(BP_PCT=70, HOLD_PCT=40))]
EVENTS = [("N=4, 3 SPM ports", {}), ("N=4, EV_REG=0", dict(EV_REG=0)), ("N=16, 3 SPM ports", dict(N=16, NSP=3)),
          ("N=1, 1 SPM port", dict(N=1, NSP=1)), ("N=8, 2 SPM ports, ROB 4", dict(N=8, NSP=2, ROB=4))]


def guarded(fn):
    def run(*a):
        try:
            return fn(*a)
        except Exception as e:  # noqa: BLE001  -- a build failure is a FAIL of that run, not a crash of the regression
            return dict(kind="tile" if fn is tile_run else "varray", label=a[0], cfg=a[1], sim=a[2] if fn is tile_run
                        else "verilator", ok=False, secs=0, counters={}, checks={}, phases={}, hist={}, errors=[str(e)])
    return run


def tile_run(label, cfg, sim):
    if sim == "verilator":
        exe = verilator_build("tb_hpc_tile_perf", F.TILE_FILES, cfg, extra=[f"-I{F.INTEG_DIR}"])
    else:
        exe = icarus_build("tb_hpc_tile_perf", F.TILE_FILES, cfg, incdirs=list(F.INCDIRS) + [F.INTEG_DIR])
    wd = BUILD / "integ_runs" / f"{sim}_{'_'.join(f'{k}{v}' for k, v in sorted(cfg.items())) or 'default'}"
    wd.mkdir(parents=True, exist_ok=True)
    for f in F.INTEG_DIR.glob("*.hex"):
        shutil.copy(f, wd / f.name)
    ok, out, dt = run_sim(sim, exe, [], cwd=wd, tag="TB_TILE_PERF", timeout=7200)
    (wd / "log.txt").write_text(out)
    get = lambda k: next((l for l in out.splitlines() if l.startswith(f"TB_TILE_PERF {k}")), "")  # noqa: E731
    return dict(kind="tile", label=label, cfg=cfg, sim=sim, ok=ok, secs=round(dt, 1), wd=str(wd),
                counters={k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", get("COUNTERS"))},
                checks={k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", get("CHECKS"))},
                phases={k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", get("PHASES"))},
                errors=[l for l in out.splitlines() if "ERROR" in l][:8])


def varray_run(label, cfg, seed):
    exe = verilator_build("tb_hpc_perf_varray", F.VARRAY_TB_FILES, cfg)
    ok, out, dt = run_sim("verilator", exe, [f"+seed={seed}"], tag="TB_VA_PERF")
    hist = next((l for l in out.splitlines() if "HIST" in l), "")
    return dict(kind="varray", label=label, cfg=cfg, sim="verilator", seed=seed, ok=ok, secs=round(dt, 1),
                hist={int(k): int(v) for k, v in re.findall(r" (\d+)=(\d+)", hist)},
                counters={k: int(v) for k, v in re.findall(r"(\w+)=(\d+)",
                                                           next((l for l in out.splitlines() if "COUNTERS" in l), ""))},
                errors=[l for l in out.splitlines() if "ERROR" in l][:8])


def events_run(label, cfg, seed):
    exe = verilator_build("tb_hpc_perf_events", F.EVENTS_TB_FILES, cfg)
    ok, out, dt = run_sim("verilator", exe, [], tag="TB_EV")
    cov = {k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", next((l for l in out.splitlines() if "COVERAGE" in l), ""))}
    return dict(kind="events", label=label, cfg=cfg, sim="verilator", seed=seed, ok=ok, secs=round(dt, 1), cov=cov,
                counters={}, errors=[l for l in out.splitlines() if "ERROR" in l][:8])


def main() -> int:  # noqa: C901
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--no-icarus", action="store_true")
    a = ap.parse_args()
    g = subprocess.run([sys.executable, str(F.M05 / "scripts/gen_integ.py"), str(F.INTEG_DIR), "--seed", str(a.seed)],
                       capture_output=True, text=True, check=True).stdout.strip()
    t0 = time.time()
    res = []
    # ---------------------------------------------------------------- stage 1 gates everything else
    for label, cfg in STAGE1:
        r = guarded(tile_run)(label, cfg, "verilator")
        r["stage"] = 1
        res.append(r)
        print("PASS" if r["ok"] else "FAIL", "stage 1", label, *r["errors"], sep="  ")
    if all(r["ok"] for r in res):
        for label, cfg in TILE:            # build serially (shared cache), run in parallel
            verilator_build("tb_hpc_tile_perf", F.TILE_FILES, cfg, extra=[f"-I{F.INTEG_DIR}"])
        for label, cfg in VARRAY:
            verilator_build("tb_hpc_perf_varray", F.VARRAY_TB_FILES, cfg)
        for label, cfg in EVENTS:
            verilator_build("tb_hpc_perf_events", F.EVENTS_TB_FILES, cfg)
        jobs = [("t", l, c, "verilator") for l, c in TILE] + ([] if a.no_icarus else [("t", TILE[0][0], TILE[0][1], "icarus")])
        jobs += [("v", l, c, s) for l, c in VARRAY for s in (1, 2, 3)]
        jobs += [("e", l, c, 1) for l, c in EVENTS]
        with cf.ThreadPoolExecutor(a.jobs) as ex:
            out = list(ex.map(lambda j: guarded(tile_run)(j[1], j[2], j[3]) if j[0] == "t"
                              else guarded(varray_run if j[0] == "v" else events_run)(j[1], j[2], j[3]), jobs))
        for r in out:
            r["stage"] = 2 if r["kind"] == "tile" else 3
            print("PASS" if r["ok"] else "FAIL", f"stage {r['stage']}", r["label"], r["sim"], *r["errors"], sep="  ")
        res += out
    npass = sum(r["ok"] for r in res)
    base = next((r for r in res if r["kind"] == "tile" and r["cfg"] == {} and r["sim"] == "verilator" and r["ok"]), None)
    if base:
        (F.ROOT / "examples").mkdir(exist_ok=True)
        shutil.copy(Path(base["wd"]) / "regdump.json", F.ROOT / "examples/regdump_rtl_sim.json")
        shutil.copy(Path(base["wd"]) / "regdump_phaseA.json", F.ROOT / "examples/regdump_rtl_sim_phaseA.json")
    md = ["# Integration regression — telemetry on the real tile and the real vector array", "",
          f"Generated by `scripts/run_integ.py` ({time.strftime('%Y-%m-%d %H:%M')}), {round(time.time() - t0)} s. "
          f"Data: `gen_integ.py --seed {a.seed}`: {g}.", "",
          "Tools: " + ", ".join(f"{k} = {v}" for k, v in tool_versions().items()), "",
          f"**{npass} / {len(res)} runs pass.**", "",
          "## Stage 1 + 2 — tile (`tb/tb_hpc_tile_perf.sv`)", "",
          "Every snapshot (all 23 counters) and every live LO/HI pair is compared exactly with the testbench's independent "
          "per-cycle mirror, during activity; at the quiescent point the counters are also checked against the workload "
          "(Σ vl, FLOPs with FMA = 2, descriptor bytes) and against the pre-existing Module 03 / 04 / 05 counters.", "",
          "| Stage | Configuration | Sim | Snapshots | Live pairs | Back-to-back bursts | Checks | Result |",
          "|---|---|---|---|---|---|---|---|"]
    for r in [r for r in res if r["kind"] == "tile"]:
        c = r["checks"]
        md.append(f"| {r['stage']} | {r['label']} | {r['sim']} | {c.get('snapshots', '-')} | {c.get('live_pairs', '-')} | "
                  f"{c.get('back_to_back', '-')} | {c.get('checks', '-')} | {'PASS' if r['ok'] else 'FAIL'} |")
    md += ["", "Counter values after phase B (Module 05 workload), per configuration:", "",
           "| Configuration | cycles | vec_issued | vec_retired | flops | vec_stall | opnd_starve | vec_busy | dma_active | "
           "bytes_rd | bytes_wr | spm_rd | spm_wr | spm_conf | out_bp | cmd_acc |", "|---|" + "---|" * 15]
    for r in [r for r in res if r["kind"] == "tile" and r["counters"]]:
        c = r["counters"]
        md.append(f"| {r['label']} ({r['sim']}) | " + " | ".join(str(c.get(k, "-")) for k in [
            "cycles", "vec_issued", "vec_retired", "flops", "vec_stall", "opnd_starve", "vec_busy", "dma_active", "bytes_rd",
            "bytes_wr", "spm_rd", "spm_wr", "spm_conf", "out_bp", "cmd_acc"]) + " |")
    md += ["", "## Stage 3a — event layer, synthetic stimulus (`tb/tb_hpc_perf_events.sv`)", "",
           "Random protocol-legal stimulus at maximal multiplicity; `inc_o` / `err_o` compared with an independent "
           "expected value in every cycle. Coverage of combinations the real tile rarely produces is required.", "",
           "| Configuration | Cycles | 2 conflicts / cycle | 3 conflicts / cycle | DMA + vector queue full | Illegal reduction "
           "with count != 0 | Lane push at full with pop | Multi-lane retire cycles | Result |", "|---|---|---|---|---|---|---|---|---|"]
    for r in [r for r in res if r["kind"] == "events"]:
        c = r["cov"]
        md.append(f"| {r['label']} | {c.get('cycles', '-')} | {c.get('conflicts_2', '-')} | {c.get('conflicts_3', '-')} | "
                  f"{c.get('dma_and_vec_queue_full', '-')} | {c.get('illegal_reduction_nonzero_count', '-')} | "
                  f"{c.get('push_at_full_with_pop', '-')} | {c.get('multi_lane_retire', '-')} | {'PASS' if r['ok'] else 'FAIL'} |")
    md += ["", "## Stage 3b — vector array (`tb/tb_hpc_perf_varray.sv`)", "",
           "Exact workload semantics (active elements after tail / mask / legality, FLOPs incl. reduction adds, commands, "
           "illegal-command errors), Module 03 counter agreement, and periodic snapshots against a per-cycle mirror.", "",
           "| Configuration | Seed | Active elements | FLOPs | Reduction adds | Illegal cmds | Cycles with k lanes retiring "
           "together (k = 1 .. N) | Result |", "|---|---|---|---|---|---|---|---|"]
    for r in [r for r in res if r["kind"] == "varray"]:
        c, h = r["counters"], r["hist"]
        hs = " ".join(f"{k}:{v}" for k, v in sorted(h.items()) if k > 0)
        md.append(f"| {r['label']} | {r['seed']} | {c.get('active', '-')} | {c.get('flops', '-')} | {c.get('red_adds', '-')} | "
                  f"{c.get('illegal', '-')} | {hs} | {'PASS' if r['ok'] else 'FAIL'} |")
    write_report("integration", "\n".join(md) + "\n", dict(runs=res))
    print(f"{npass}/{len(res)} PASS")
    return 0 if npass == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
