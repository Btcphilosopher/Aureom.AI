#!/usr/bin/env python3
"""SilicaFlux-HPC Module 07 -- software reference model of the hpc_perf_counters bank.

Written from the specification (docs/01_architecture.md, docs/02_register_map.md), not from the RTL.
It is cycle based: `step()` takes the inputs of one clock cycle, returns the outputs the hardware must
produce in that cycle (computed from the state at the START of the cycle), then advances the state to the
end of the cycle.

Trace checking (used by scripts/run_unit.py):
    perf_ref.py <trace> --num-cnt N --cnt-w W --inc-w I --num-err E [--snap-en 0|1] [--preload-en 0|1]
                [--en-reset 0|1] [--sat-reset X] [--platform P] [--tile-cfg X] [--clk-khz K] [--build-id X]
Trace line (hex fields, one per cycle, written by tb/tb_hpc_perf_counters.sv):
    cyc rst_n sel we addr wdata | rdata err irq frozen | freeze snap err_i | inc[0..N-1] | cnt[0..N-1]
Every output and every live counter value is compared in every cycle.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import perfmap as M  # noqa: E402


class PerfBank:
    def __init__(self, num_cnt=M.NUM_CNT, cnt_w=64, inc_w=32, num_err=M.NUM_ERR, snap_en=1, preload_en=1,
                 en_reset=1, sat_reset=0, platform=0, tile_cfg=0, clk_khz=0, build_id=0):
        assert 1 <= num_cnt <= 32 and 8 <= cnt_w <= 64 and 1 <= inc_w <= min(32, cnt_w) and 1 <= num_err <= 32
        self.n, self.w, self.iw, self.ne = num_cnt, cnt_w, inc_w, num_err
        self.snap_en, self.preload_en, self.en_reset = snap_en, preload_en, en_reset
        self.sat_reset, self.platform, self.tile_cfg, self.clk_khz, self.build_id = \
            sat_reset, platform, tile_cfg, clk_khz, build_id
        self.mod = 1 << cnt_w
        self.nmask = (1 << num_cnt) - 1
        self.emask = (1 << num_err) - 1
        self.cov = {}
        self.reset()

    def hit(self, k, n=1):
        if n:
            self.cov[k] = self.cov.get(k, 0) + n

    # ------------------------------------------------------------------------------------------- state
    def reset(self):
        n = self.n
        self.cnt = [0] * n
        self.ovf = [0] * n
        self.snp = [0] * n
        self.snp_ovf = 0
        self.snp_seq = 0
        self.snp_valid = 0
        self.ctl_en, self.ctl_frz, self.ctl_fov = self.en_reset, 0, 0
        self.cnt_en = self.nmask
        self.sat = self.sat_reset & self.nmask
        self.ovf_ie = 0
        self.pre = 0
        self.err = 0
        self.lat_hi, self.lat_idx, self.lat_v, self.lat_miss = 0, 0, 0, 0

    def ovf_word(self):
        return sum(b << i for i, b in enumerate(self.ovf))

    def frozen(self, freeze_i):
        return int(bool(self.ctl_frz or freeze_i or (self.ctl_fov and any(self.ovf))))

    def info(self):
        return (self.n | self.w << 8 | self.iw << 16 | self.ne << 22 | self.platform << 28 |
                self.snap_en << 30 | self.preload_en << 31)

    # ------------------------------------------------------------------------------------------- bus read / error
    def access(self, we, addr, wdata, freeze_i):
        """Returns (rdata, err) of a strobe in the current state (no side effects)."""
        ro_const = {M.REG_ID: M.PERF_ID, M.REG_VERSION: M.PERF_VERSION, M.REG_INFO: self.info(),
                    M.REG_TILECFG: self.tile_cfg, M.REG_CLK_KHZ: self.clk_khz, M.REG_BUILD_ID: self.build_id}
        if addr in ro_const:
            return ro_const[addr], int(we)
        if addr == M.REG_CTRL:
            cmd_snap = (wdata >> M.CTRL_SNAPSHOT) & 1 or (wdata >> M.CTRL_SAMPLE) & 1
            return self.ctl_en | self.ctl_frz << 1 | self.ctl_fov << 2, int(bool(we and not self.snap_en and cmd_snap))
        if addr == M.REG_STATUS:
            ovf_any = int(any(self.ovf))
            v = (self.frozen(freeze_i) | int(bool(freeze_i)) << 1 | (self.ctl_fov & ovf_any) << 2 | ovf_any << 3 |
                 self.snp_valid << 4 | self.lat_miss << 5 | self.snp_seq << 16)
            return v, 0
        if addr == M.REG_CNT_EN:
            return self.cnt_en, 0
        if addr == M.REG_SAT:
            return self.sat, 0
        if addr == M.REG_OVF:
            return self.ovf_word(), 0
        if addr == M.REG_OVF_IE:
            return self.ovf_ie, 0
        if addr == M.REG_CLR:
            return 0, 0
        if addr == M.REG_SNAP_OVF:
            return (self.snp_ovf if self.snap_en else 0), int(bool(we or not self.snap_en))
        if addr == M.REG_PRE_LO:
            return (self.pre & 0xFFFF_FFFF if self.preload_en else 0), int(not self.preload_en)
        if addr == M.REG_PRE_HI:
            return (self.pre >> 32 if self.preload_en else 0), int(not self.preload_en)
        if addr == M.REG_PRE_LOAD:
            return 0, int(not self.preload_en)
        if addr == M.REG_ERR_SRC:
            return self.err, 0
        if addr == M.REG_LATCH:
            return self.lat_idx | self.lat_v << 8, int(we)
        page, idx, hi = addr >> 8, (addr >> 3) & 31, (addr >> 2) & 1
        ok = (addr & 3) == 0 and idx < self.n
        if page == (M.SNAP_BASE >> 8) and self.snap_en and ok and not we:
            v = self.snp[idx]
            return ((v >> 32) & 0xFFFF_FFFF if hi else v & 0xFFFF_FFFF), 0
        if page == (M.LIVE_BASE >> 8) and ok and not we:
            v = self.cnt[idx]
            if hi:
                return (self.lat_hi if (self.lat_v and self.lat_idx == idx) else (v >> 32) & 0xFFFF_FFFF), 0
            return v & 0xFFFF_FFFF, 0
        return 0, 1

    # ------------------------------------------------------------------------------------------- one cycle
    def step(self, rst_n, sel, we, addr, wdata, inc, freeze_i, snap_i, err_i):
        """Outputs of this cycle, then the state update at its end."""
        if not rst_n:
            self.hit("reset_cycles")
            self.reset()
            rdata, rerr = self.access(we, addr, wdata, freeze_i) if sel else (0, 0)
            out = dict(rdata=rdata, err=rerr, irq=0, frozen=self.frozen(freeze_i))
            self.reset()
            return out
        rdata, rerr = self.access(we, addr, wdata, freeze_i) if sel else (0, 0)
        frozen = self.frozen(freeze_i)
        irq = int(any(o and (self.ovf_ie >> i) & 1 for i, o in enumerate(self.ovf)))
        out = dict(rdata=rdata, err=rerr, irq=irq, frozen=frozen)
        if sel:
            self.hit("bus_refused" if rerr else ("bus_write" if we else "bus_read"))
        self.hit("frozen_cycles", frozen)
        self.hit("irq_cycles", irq)
        self.hit("multi_event_cycles", int(sum(1 for e in inc if e > 1) > 0))
        self.hit("max_increment_events", sum(1 for e in inc if e == (1 << self.iw) - 1))

        acc_wr = sel and we and not rerr
        acc_rd = sel and not we and not rerr
        wm = wdata & self.nmask
        w_ctrl = acc_wr and addr == M.REG_CTRL
        c_clear = w_ctrl and (wdata >> M.CTRL_CLEAR) & 1
        c_sample = w_ctrl and (wdata >> M.CTRL_SAMPLE) & 1 and self.snap_en
        c_snap = self.snap_en and ((w_ctrl and ((wdata >> M.CTRL_SNAPSHOT) & 1 or (wdata >> M.CTRL_SAMPLE) & 1))
                                   or snap_i)
        clr = (self.nmask if c_clear else 0) | (wm if acc_wr and addr == M.REG_CLR else 0)
        pre = wm if (self.preload_en and acc_wr and addr == M.REG_PRE_LOAD) else 0
        w1c = wm if acc_wr and addr == M.REG_OVF else 0

        # snapshot: the state at the start of the cycle
        self.hit("snapshot", int(bool(c_snap)))
        self.hit("sample", int(bool(c_sample)))
        self.hit("clear_all", int(bool(c_clear)))
        self.hit("clr_mask_counters", bin(clr).count("1") if not c_clear else 0)
        self.hit("preload_counters", bin(pre).count("1"))
        if c_snap:
            self.snp = list(self.cnt)
            self.snp_ovf = self.ovf_word()
            self.snp_seq = (self.snp_seq + 1) & 0xFFFF
            self.snp_valid = 1

        # counters
        go = self.ctl_en and not frozen
        idx_live = (addr >> 3) & 31
        old_cnt = list(self.cnt)
        for i in range(self.n):
            e = inc[i] if (go and (self.cnt_en >> i) & 1) else 0
            assert 0 <= e < (1 << self.iw)
            if (clr >> i) & 1:
                self.cnt[i], self.ovf[i] = 0, 0
            elif (pre >> i) & 1:
                self.cnt[i] = self.pre % self.mod
            elif c_sample:
                self.cnt[i], self.ovf[i] = e, 0
            else:
                s = self.cnt[i] + e
                carry = s >= self.mod
                if carry:
                    self.hit("overflow_saturate" if (self.sat >> i) & 1 else "overflow_wrap")
                if carry and (w1c >> i) & 1:
                    self.hit("overflow_same_cycle_as_w1c")
                self.cnt[i] = (self.mod - 1) if (carry and (self.sat >> i) & 1) else s % self.mod
                self.ovf[i] = int((self.ovf[i] and not (w1c >> i) & 1) or carry)

        # control / status registers
        if w_ctrl:
            self.ctl_en = (wdata >> M.CTRL_ENABLE) & 1
            self.ctl_frz = (wdata >> M.CTRL_FREEZE) & 1
            self.ctl_fov = (wdata >> M.CTRL_FREEZE_ON_OVF) & 1
        if acc_wr and addr == M.REG_CNT_EN:
            self.cnt_en = wm
        if acc_wr and addr == M.REG_SAT:
            self.sat = wm
        if acc_wr and addr == M.REG_OVF_IE:
            self.ovf_ie = wm
        if self.preload_en and acc_wr and addr == M.REG_PRE_LO:
            self.pre = (self.pre & ~0xFFFF_FFFF) | wdata
        if self.preload_en and acc_wr and addr == M.REG_PRE_HI:
            self.pre = (self.pre & 0xFFFF_FFFF) | wdata << 32
        ew1c = (wdata & self.emask) if acc_wr and addr == M.REG_ERR_SRC else 0
        self.err = (self.err & ~ew1c) | (err_i & self.emask)
        in_live = (addr >> 8) == (M.LIVE_BASE >> 8)
        hi = (addr >> 2) & 1
        if acc_rd and in_live:
            hit = self.lat_v and self.lat_idx == idx_live
            if not hi:
                self.lat_hi, self.lat_idx, self.lat_v = (old_cnt[idx_live] >> 32) & 0xFFFF_FFFF, idx_live, 1
                self.hit("live_lo_read")
            else:
                self.lat_v = 0
                self.hit("live_hi_latched" if hit else "live_hi_latch_miss")
                if not hit:
                    self.lat_miss = 1
        elif acc_wr and addr == M.REG_STATUS and (wdata >> M.ST_LATCH_MISS) & 1:
            self.lat_miss = 0
        return out


def check_trace(path: Path, bank: PerfBank, max_report: int = 10) -> tuple[int, int]:  # noqa: C901
    """Replays a trace; returns (cycles, mismatches)."""
    n = bank.n
    bad = cycles = 0
    with open(path) as f:
        lines = f.readlines()
    for ln, line in enumerate(lines):
        if True:
            if not line.strip() or line.startswith("#"):
                continue
            t = line.split()
            if len(t) != 13 + 2 * n:
                if ln == len(lines) - 1:
                    print(f"PERF_REF NOTE ignoring a truncated final trace line ({len(t)} fields)")
                    continue
                bad += 1
                print(f"PERF_REF MISMATCH line {ln + 1}: {len(t)} fields, expected {13 + 2 * n}")
                continue
            cyc = int(t[0])
            rst_n, sel, we = int(t[1], 16), int(t[2], 16), int(t[3], 16)
            addr, wdata = int(t[4], 16), int(t[5], 16)
            if not rst_n and any("x" in x.lower() or "z" in x.lower() for x in t[6:10]):
                # 4-state simulators: before the first clocked reset the outputs are unknown while rst_n = 0
                # (no negedge of rst_n at time 0).  Allowed ONLY under reset; X anywhere else is a mismatch.
                t[6:10] = ["0"] * 4
                xreset = True
            else:
                xreset = False
            rdata, rerr, irq, frozen = (int(x, 16) for x in t[6:10])
            freeze_i, snap_i, err_i = int(t[10], 16), int(t[11], 16), int(t[12], 16)
            inc = [int(x, 16) for x in t[13:13 + n]]
            cnt = [int(x, 16) for x in t[13 + n:13 + 2 * n]]
            exp = bank.step(rst_n, sel, we, addr, wdata, inc, freeze_i, snap_i, err_i)
            msgs = []
            if sel and (exp["rdata"] != rdata or exp["err"] != rerr):
                msgs.append(f"bus {'wr' if we else 'rd'} 0x{addr:03x}: rdata 0x{rdata:08x} err {rerr}, "
                            f"model 0x{exp['rdata']:08x} err {exp['err']}")
            if xreset:
                exp["irq"], exp["frozen"] = irq, frozen
            if exp["irq"] != irq:
                msgs.append(f"irq {irq}, model {exp['irq']}")
            if exp["frozen"] != frozen:
                msgs.append(f"frozen {frozen}, model {exp['frozen']}")
            # cnt[] in the trace is the live value at the END of the cycle (after the update)
            for i in range(n):
                if bank.cnt[i] != cnt[i]:
                    msgs.append(f"cnt[{i}] = 0x{cnt[i]:x}, model 0x{bank.cnt[i]:x}")
            if msgs:
                bad += 1
                if bad <= max_report:
                    print(f"PERF_REF MISMATCH cyc={cyc}: " + "; ".join(msgs[:4]))
            cycles += 1
    return cycles, bad


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("trace", type=Path)
    for k, d in [("num-cnt", M.NUM_CNT), ("cnt-w", 64), ("inc-w", 32), ("num-err", M.NUM_ERR), ("snap-en", 1),
                 ("preload-en", 1), ("en-reset", 1), ("platform", 0), ("clk-khz", 0)]:
        ap.add_argument(f"--{k}", type=int, default=d)
    for k in ["sat-reset", "tile-cfg", "build-id"]:
        ap.add_argument(f"--{k}", type=lambda x: int(x, 0), default=0)
    a = ap.parse_args()
    bank = PerfBank(a.num_cnt, a.cnt_w, a.inc_w, a.num_err, a.snap_en, a.preload_en, a.en_reset, a.sat_reset,
                    a.platform, a.tile_cfg, a.clk_khz, a.build_id)
    cycles, bad = check_trace(a.trace, bank)
    print("PERF_REF COVERAGE " + " ".join(f"{k}={v}" for k, v in sorted(bank.cov.items())))
    print(f"PERF_REF {'PASS' if bad == 0 and cycles > 0 else 'FAIL'} cycles={cycles} mismatching_cycles={bad}")
    return 0 if bad == 0 and cycles > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
