"""SilicaFlux-HPC Module 07 -- single source of truth for the performance-counter map.

Everything that names a counter, a register offset or a register field is generated from this file:
  * rtl/hpc_perf_defs.svh          (scripts/gen_defs.py)
  * docs/02_register_map.md        (scripts/gen_defs.py)
  * host/hpc_perf_telemetry.py     (imports this module, or its embedded copy -- checked identical)
  * model/perf_ref.py              (reference model of the counter bank)
The regression re-runs the generator and fails if a checked-in generated file differs.
"""
from __future__ import annotations

# --------------------------------------------------------------------------------------------- identification
PERF_ID = 0x5346_5043            # ASCII "SFPC": SilicaFlux Performance Counters
PERF_VERSION = 0x0001_0000       # [31:16] major, [15:0] minor

PLATFORMS = {0: "rtl_simulation", 1: "fpga", 2: "asic", 3: "emulation_or_other"}

# --------------------------------------------------------------------------------------------- counters
# (index, name, phase, max increment per cycle, short definition)
#   phase 1 = the first instrumentation set ("cycle, vector-retirement, DMA-byte and stall counters"),
#             brought up and verified before anything else was added;
#   phase 2 = the remaining mandatory counters;
#   phase 3 = extended counters (denominators and queue-occupancy statistics for the host derivations).
# Exact event definitions with source signals: docs/03_event_definitions.md.
COUNTERS = [
    (0,  "CYCLES",            1, "1",            "active clock cycles: rising edges of clk while the bank is counting"),
    (1,  "CMD_ACCEPTED",      2, "2",            "commands accepted: vector-command + DMA-descriptor handshakes"),
    (2,  "CMD_COMPLETED",     2, "2",            "completion records handed over: vector + DMA completion handshakes"),
    (3,  "VEC_ISSUED",        2, "N",            "element operations issued: enabled ops accepted by lanes (sum over lanes)"),
    (4,  "VEC_RETIRED",       1, "N",            "element operations retired: lane results handed over (sum over lanes)"),
    (5,  "FLOPS_RETIRED",     1, "2N + 2^VL_W-1", "FP operations retired: lane FLOP weights at retirement + reduction adds at completion"),
    (6,  "VEC_STALL",         1, "1",            "vector issue-stage stall cycles: a beat is due but not released"),
    (7,  "DMA_ACTIVE",        2, "1",            "cycles the DMA engine executes a transfer"),
    (8,  "DMA_BYTES_RD",      1, "NP*DW/8",      "bytes delivered by error-free DMA read responses"),
    (9,  "DMA_BYTES_WR",      1, "NP*DW/8",      "bytes committed by error-free DMA write responses (byte strobes)"),
    (10, "SPM_READS",         2, "P",            "scratchpad read requests accepted (sum over ports)"),
    (11, "SPM_WRITES",        2, "P",            "scratchpad write requests accepted (sum over ports)"),
    (12, "SPM_CONFLICTS",     2, "P",            "scratchpad port-cycles in which an issuable request lost bank arbitration"),
    (13, "CMDQ_FULL",         2, "1",            "cycles in which at least one tile command queue is full"),
    (14, "OUT_BP",            2, "1",            "cycles in which at least one tile output is presented and not taken"),
    (15, "HW_ERRORS",         2, "sum of sources", "hardware-detected error events (sum over error sources)"),
    (16, "VEC_BUSY",          3, "1",            "cycles the vector array reports busy"),
    (17, "VEC_OPND_STARVE",   3, "1",            "vector memory-stall cycles: a beat is due and no operand beat is offered"),
    (18, "CMD_INFLIGHT_SUM",  3, "in-flight",    "sum over cycles of commands accepted and not yet completed"),
    (19, "VEC_CMDQ_OCC_SUM",  3, "CMD_DEPTH",    "sum over cycles of the vector command-queue occupancy"),
    (20, "DMA_OUT_SUM",       3, "255",          "sum over cycles of outstanding DMA bus requests"),
    (21, "RED_ADDS",          3, "2^VL_W-1",     "reduction FP additions retired (subset of FLOPS_RETIRED)"),
    (22, "VEC_CMD_COMPLETED", 3, "1",            "vector completion records handed over (subset of CMD_COMPLETED)"),
]
NUM_CNT = len(COUNTERS)
CNT = {name: idx for idx, name, *_ in COUNTERS}
PHASE1 = [name for _, name, ph, *_ in COUNTERS if ph == 1]

# --------------------------------------------------------------------------------------------- error sources
# err_i[k] of the counter bank (sticky flags in ERR_SRC); the tile binding drives them (hpc_perf_events).
ERR_SOURCES = [
    (0, "VEC_ILLEGAL",   "vector completion handed over with cpl_illegal = 1"),
    (1, "DMA_CPL_ERR",   "DMA completion handed over with cpl_err = 1 (any completion code but NONE)"),
    (2, "DMA_BUS_ERR",   "DMA adapter received an error response (fabric or scratchpad), any port"),
    (3, "DMA_TAG_ERR",   "DMA adapter response-ownership violation (scratchpad tag/type mismatch, unsolicited)"),
    (4, "SPM_ECC_ERR",   "scratchpad read data failed the integrity check (parity), any port"),
    (5, "SPM_DECODE_ERR", "scratchpad request issued to the decode-error path (address outside the array)"),
    (6, "PERF_TRACK_ERR", "telemetry self-check: FLOP-weight tracker or in-flight counter over/underflow"),
    (7, "RESERVED7",     "reserved, always 0"),
]
NUM_ERR = len(ERR_SOURCES)
ERR = {name: idx for idx, name, _ in ERR_SOURCES}

# --------------------------------------------------------------------------------------------- registers
# 12-bit offsets in a 4 KiB register page (SilicaFlux-V peripheral register bus, as DataFabric DFPERF).
# access: RO, RW, W1C (read; write 1 clears), WO (write-only; reads 0), W1S (command bits; read 0)
REG_ID, REG_VERSION, REG_INFO, REG_TILECFG, REG_CLK_KHZ, REG_BUILD_ID = 0x000, 0x004, 0x008, 0x00C, 0x010, 0x014
REG_CTRL, REG_STATUS, REG_CNT_EN, REG_SAT, REG_OVF, REG_OVF_IE = 0x020, 0x024, 0x028, 0x02C, 0x030, 0x034
REG_CLR, REG_SNAP_OVF, REG_PRE_LO, REG_PRE_HI, REG_PRE_LOAD, REG_ERR_SRC, REG_LATCH = \
    0x038, 0x03C, 0x040, 0x044, 0x048, 0x04C, 0x050
SNAP_BASE = 0x100        # SNAP_LO[i] = SNAP_BASE + 8*i, SNAP_HI[i] = SNAP_BASE + 8*i + 4
LIVE_BASE = 0x200        # LIVE_LO[i] = LIVE_BASE + 8*i, LIVE_HI[i] = LIVE_BASE + 8*i + 4
WIN_BYTES = 0x100        # 32 counters x 8 bytes

# CTRL bits
CTRL_ENABLE, CTRL_FREEZE, CTRL_FREEZE_ON_OVF = 0, 1, 2
CTRL_CLEAR, CTRL_SNAPSHOT, CTRL_SAMPLE = 8, 9, 10
# STATUS bits / fields
ST_FROZEN, ST_HW_FREEZE, ST_OVF_FREEZE, ST_OVF_ANY, ST_SNAP_VALID, ST_LATCH_MISS = 0, 1, 2, 3, 4, 5
ST_SNAP_SEQ_LSB = 16     # [31:16]
# INFO fields (lsb, width)
INFO_FIELDS = [("NUM_CNT", 0, 8), ("CNT_W", 8, 8), ("INC_W", 16, 6), ("NUM_ERR", 22, 6), ("PLATFORM", 28, 2),
               ("SNAP_EN", 30, 1), ("PRELOAD_EN", 31, 1)]
# TILECFG fields (tile binding, hpc_perf_events)
TILECFG_FIELDS = [("NUM_LANES", 0, 8), ("SPM_PORTS", 8, 4), ("DMA_PORTS", 12, 4), ("DMA_BYTES_PER_BEAT", 16, 8),
                  ("FMA_FLOPS", 24, 2), ("CMP_FLOPS", 26, 2), ("EV_REG", 28, 1), ("INSTR_PHASE", 29, 2), ("RSVD", 31, 1)]
# LATCH fields
LATCH_FIELDS = [("IDX", 0, 5), ("VALID", 8, 1)]

REGISTERS = [
    # (offset, name, access, reset, description)
    (REG_ID, "ID", "RO", f"0x{PERF_ID:08X}", "Identification: ASCII \"SFPC\"."),
    (REG_VERSION, "VERSION", "RO", f"0x{PERF_VERSION:08X}", "[31:16] major, [15:0] minor register-map version."),
    (REG_INFO, "INFO", "RO", "param", "[7:0] NUM_CNT; [15:8] CNT_W; [21:16] INC_W; [27:22] NUM_ERR; "
                                       "[29:28] PLATFORM (0 RTL simulation, 1 FPGA, 2 ASIC, 3 emulation/other: what this "
                                       "netlist was built for); [30] SNAP_EN; [31] PRELOAD_EN."),
    (REG_TILECFG, "TILECFG", "RO", "param", "Tile binding parameters: [7:0] NUM_LANES; [11:8] SPM_PORTS; [15:12] DMA_PORTS; "
                                             "[23:16] DMA_BYTES_PER_BEAT; [25:24] FMA_FLOPS (FLOPs counted per fused "
                                             "multiply-add); [27:26] CMP_FLOPS (per FMIN/FMAX/compare); [28] EV_REG "
                                             "(events reach the counters one cycle late); [30:29] INSTR_PHASE "
                                             "(counters of a higher phase receive no events)."),
    (REG_CLK_KHZ, "CLK_KHZ", "RO", "param", "Build-configured nominal clock in kHz (0 = not specified). A configured value, "
                                             "not a measurement."),
    (REG_BUILD_ID, "BUILD_ID", "RO", "param", "Free 32-bit build identifier supplied at elaboration."),
    (REG_CTRL, "CTRL", "RW/W1S", "0x00000001 (EN_RESET=1)",
     "[0] ENABLE (rw); [1] FREEZE (rw); [2] FREEZE_ON_OVF (rw); [8] CLEAR (w1s: zero every counter and OVF bit; "
     "events of the write cycle are discarded); [9] SNAPSHOT (w1s: copy every counter and OVF into the snapshot "
     "registers in one cycle); [10] SAMPLE (w1s: SNAPSHOT and restart every counter from the events of the write "
     "cycle, losing nothing). Command bits read 0."),
    (REG_STATUS, "STATUS", "RO/W1C", "0x00000000",
     "[0] FROZEN (counting stopped by FREEZE, freeze_i or FREEZE_ON_OVF this cycle); [1] HW_FREEZE (freeze_i); "
     "[2] OVF_FREEZE (stopped by FREEZE_ON_OVF); [3] OVF_ANY; [4] SNAP_VALID (a snapshot was taken since reset); "
     "[5] LATCH_MISS (w1c, sticky: a LIVE_HI read did not follow the LIVE_LO read of the same counter); "
     "[31:16] SNAP_SEQ (snapshots taken since reset, wraps)."),
    (REG_CNT_EN, "CNT_EN", "RW", "all ones", "Per-counter enable, bit i = counter i."),
    (REG_SAT, "SAT", "RW", "SAT_RESET (0)", "Per-counter overflow mode: 0 = wrap modulo 2^CNT_W, 1 = saturate at "
                                            "2^CNT_W - 1. OVF is set in both modes: no overflow is ever silent."),
    (REG_OVF, "OVF", "W1C", "0", "Per-counter sticky overflow flag. A new overflow in the same cycle as a write-1-"
                                 "to-clear wins (the bit stays set)."),
    (REG_OVF_IE, "OVF_IE", "RW", "0", "Per-counter overflow interrupt enable: irq_o = |(OVF & OVF_IE)."),
    (REG_CLR, "CLR", "WO", "-", "Write 1 to bit i: counter i and OVF[i] are zeroed; its events of that cycle are "
                                "discarded."),
    (REG_SNAP_OVF, "SNAP_OVF", "RO", "0", "OVF as captured by the last snapshot (coherent with SNAP_*)."),
    (REG_PRE_LO, "PRE_LO", "RW", "0", "Preload staging value, bits [31:0] (PRELOAD_EN = 1)."),
    (REG_PRE_HI, "PRE_HI", "RW", "0", "Preload staging value, bits [63:32] (PRELOAD_EN = 1)."),
    (REG_PRE_LOAD, "PRE_LOAD", "WO", "-", "Write 1 to bit i: counter i := {PRE_HI, PRE_LO} (truncated to CNT_W) "
                                          "atomically; its events of that cycle are discarded; OVF unchanged."),
    (REG_ERR_SRC, "ERR_SRC", "W1C", "0", "Sticky flag per error source (err_i). Set wins over a same-cycle clear."),
    (REG_LATCH, "LATCH", "RO", "0", "[4:0] IDX of the counter whose high word is latched; [8] VALID."),
]

COUNTER_WINDOWS = [
    (SNAP_BASE, "SNAP_LO[i] / SNAP_HI[i]", "RO", "Snapshot of counter i, low / high word (SNAP_EN = 1). Every "
                                                "counter was copied in the same cycle: mutually coherent."),
    (LIVE_BASE, "LIVE_LO[i] / LIVE_HI[i]", "RO", "Live counter i. Reading LIVE_LO[i] returns the low word and "
                                                "latches the high word of the same cycle; the next LIVE_HI[i] "
                                                "returns that latched word (a coherent 64-bit value). LIVE_HI[i] "
                                                "without a latch for i returns the current high word and sets "
                                                "STATUS.LATCH_MISS."),
]


def reg_offset(name: str) -> int:
    for off, n, *_ in REGISTERS:
        if n == name:
            return off
    raise KeyError(name)


def snap_lo(i: int) -> int:
    return SNAP_BASE + 8 * i


def live_lo(i: int) -> int:
    return LIVE_BASE + 8 * i


def field(value: int, fields: list, name: str) -> int:
    for n, lsb, w in fields:
        if n == name:
            return (value >> lsb) & ((1 << w) - 1)
    raise KeyError(name)
