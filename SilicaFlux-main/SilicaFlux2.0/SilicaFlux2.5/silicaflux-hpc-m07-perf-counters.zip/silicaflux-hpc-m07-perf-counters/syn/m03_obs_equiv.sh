#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC Module 07 :: m03_obs_equiv.sh -- proof that the Module 03 observation-port patch
# (rtl/m03_obs/) changes no behaviour.
#   gold = unmodified Module 03 (third_party/), gate = patched copy with the obs_* outputs removed.
#   Yosys equivalence: equiv_make / equiv_struct / equiv_simple -seq / equiv_induct, then
#   equiv_status -assert: every pre-existing output and every register is proven equal (sequentially,
#   by induction over the matched state), for each NUM_LANES given (default 1 2 4).
# usage: syn/m03_obs_equiv.sh [N ...]
# =============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VA="$ROOT/third_party/silicaflux-hpc-m03-vector-array/rtl"
OUT="$ROOT/reports/m03_obs_equiv"
mkdir -p "$OUT"
COMMON="$VA/lane/hpc_vector_pkg.sv $VA/hpc_varray_pkg.sv $VA/lane/hpc_pipe.sv $VA/lane/hpc_lzc.sv
  $VA/lane/hpc_fp32_round.sv $VA/lane/hpc_fp32_add.sv $VA/lane/hpc_fp32_mul.sv $VA/lane/hpc_fp32_fma.sv
  $VA/lane/hpc_fp32_misc.sv $VA/lane/hpc_int32_mul.sv $VA/lane/hpc_vector_lane.sv $VA/hpc_varray_fifo.sv
  $VA/hpc_varray_collect.sv $VA/hpc_varray_reduce.sv $VA/hpc_varray_perf.sv"
COMMON="$(echo $COMMON | tr -s "\n " " ")"
GOLD="$COMMON $VA/hpc_varray_issue.sv $VA/hpc_vector_array.sv"
GATE="$COMMON $ROOT/rtl/m03_obs/hpc_varray_issue.sv $ROOT/rtl/m03_obs/hpc_vector_array.sv"
PREP="proc; flatten; memory -nomap; memory_map; async2sync; opt_clean"
LANES="${*:-1 2 4}"
: > "$OUT/summary.txt"
for n in $LANES; do
  t0=$SECONDS
  yosys -q -l "$OUT/equiv_n${n}.log" -p "
    read_verilog -sv -DSYNTHESIS $GOLD; hierarchy -check -top hpc_vector_array -chparam NUM_LANES $n; $PREP;
    rename hpc_vector_array gold; design -stash gold;
    read_verilog -sv -DSYNTHESIS $GATE; hierarchy -check -top hpc_vector_array -chparam NUM_LANES $n; $PREP;
    delete -port hpc_vector_array/w:obs_*; opt_clean; rename hpc_vector_array gate; design -stash gate;
    design -copy-from gold -as gold gold; design -copy-from gate -as gate gate;
    equiv_make gold gate equiv; hierarchy -top equiv; equiv_struct; equiv_simple -seq 2; equiv_induct;
    tee -o $OUT/equiv_n${n}_status.txt equiv_status -assert" >/dev/null 2>&1 && rc=0 || rc=$?
  st=$( (grep -E "Found [0-9]+ .equiv cells|Of those cells [0-9]+ are proven" "$OUT/equiv_n${n}_status.txt" || true) | tr '\n' ' ')
  echo "NUM_LANES=$n exit=$rc $((SECONDS - t0)) s : $st" | tee -a "$OUT/summary.txt"
done
