# 01 — Counter architecture

## 1. Block structure

```
 Module 03 vector array (+ observation port) ─┐
 Module 04 scratchpad  (ev_* ports)          ─┼─► hpc_perf_events ──inc[23 x 32b], err[8], freeze, snap──► hpc_perf_counters ──► rb_* register page
 Module 05 DMA adapter (ev_* ports, active)  ─┘   (tile binding:              (EV_REG: one register stage)     (23 x 64-bit counters,
 tile freeze_i (debug halt) / snap_i (marker) ─►   event definitions,                                         snapshot, latch, OVF,
                                                   FLOP weight trackers,                                       preload, control)
                                                   in-flight counter)
                                         hpc_perf_tile = hpc_perf_events + hpc_perf_counters (one instance per tile)
```

* **`hpc_perf_counters`** (`rtl/hpc_perf_counters.sv`, the primary source) is generic. It has `NUM_CNT` counters of
  `CNT_W` bits, each taking an `INC_W`-bit increment per cycle, plus the register interface and all control. It does not
  know what it counts.
* **`hpc_perf_events`** (`rtl/hpc_perf_events.sv`) is the tile binding. Every counter definition is one expression there
  (`docs/03_event_definitions.md`). It holds the per-lane FLOP-weight trackers (`hpc_perf_wtrack`) and the
  commands-in-flight counter.
* **`hpc_perf_tile`** wires the two together. It publishes the binding parameters in `TILECFG` so that host software
  can interpret the counts.
* **`hpc_perf_cdc_count`** (optional) brings an event count from another clock domain (`docs/04_clock_domains.md`).

Defaults: 23 counters × 64 bits, `INC_W` = 32 (up to 2³² − 1 events per counter per cycle), snapshot and preload present,
counting enabled from reset.

## 2. Counting

In every cycle, counter *i* adds `inc_i[i]` (the number of its events in that cycle) if and only if

```
CTRL.ENABLE  &  CNT_EN[i]  &  !frozen,      frozen = CTRL.FREEZE | freeze_i | (CTRL.FREEZE_ON_OVF & |OVF)
```

* **Multiple events per cycle** are added in one step: four lanes retiring together add 4, two scratchpad ports add 2,
  a 4-byte beat adds 4 bytes, and a reduction completion adds its whole element count. No event is lost because a
  counter could only step by one. (Mutant E01, "multi-lane retirement counted once", is killed by the regression.)
* **Register writes take effect from the next cycle.** In the write cycle the old ENABLE / FREEZE / CNT_EN still apply.
  `freeze_i` acts in its own cycle, after the event register (with `EV_REG = 1` it is delayed together with the events,
  so it freezes exactly the events of the cycles in which it was high).
* **`EV_REG = 1`** (tile default) registers every increment once, so a counter shows the events of cycle *t* from cycle
  *t* + 2 on, all counters alike. This costs one cycle of visibility and no accuracy. It keeps the tile's handshake logic
  out of the 64-bit adders.

### Enable vs. freeze

Both stop counting. They exist separately so that hardware stop sources (`freeze_i`, e.g. a debug halt, and
`FREEZE_ON_OVF`) and the software freeze can be released without touching the software's enable configuration
(`ENABLE`, `CNT_EN`). Events that occur while counting is stopped are **not** counted, by design. To read many counters
consistently **without** losing events, use SNAPSHOT (§4), not FREEZE.

## 3. Overflow — wraparound is defined, never silent

| `SAT[i]` | On a carry out of `CNT_W` bits | Value afterwards | `OVF[i]` |
|---|---|---|---|
| 0 (reset default) | wraps | (old + increment) mod 2^CNT_W, exact modular count | set (sticky) |
| 1 | saturates | 2^CNT_W − 1 and stays there (lower bound of the true count) | set (sticky) |

* `OVF[i]` is write-1-to-clear. An overflow in the same cycle as its W1C wins, so the bit stays set.
* `OVF_IE[i]` routes `OVF[i]` to `irq_o`. `CTRL.FREEZE_ON_OVF` stops every counter from the cycle after any overflow
  (the overflowing counter has already wrapped by its last increment). Clearing OVF releases the freeze.
* `SNAP_OVF` captures OVF with the snapshot, so a snapshot carries its own validity.
* The host tool (`host/hpc_perf_telemetry.py`) reports a counter with OVF set as *wrapped (invalid)* or
  *saturated (lower bound)*, and withholds or bounds every metric derived from it.
* At 64 bits, wrap is a practical non-event for cycle counts (2⁶⁴ cycles is 584 years at 1 GHz). It can be reached by
  byte counters only after about 9 years at 64 B/cycle and 1 GHz. It is defined and tested anyway: preload and the
  narrow configurations overflow in the unit tests, and on the real tile phase E preloads a byte counter to
  2⁶⁴ − 256 and lets a 4000-byte DMA wrap it.

The previous SilicaFlux counters (Modules 03–05, DFPERF) saturate silently at 32 bits. That is deliberately not the
default here: a 32-bit byte counter saturates after 4 GiB, which is about 43 s at 25 MHz and 4 B/cycle, and the result
then looks like a valid number.

## 4. Reset, clear, preload, snapshot, sample

Priority per counter and cycle: **reset > CLEAR / CLR > PRE_LOAD > SAMPLE > count**.

| Operation | Counter afterwards | OVF | Events of that cycle |
|---|---|---|---|
| `rst_n` low (asynchronous assert) | 0 | 0 | — (every register at its reset value) |
| `CTRL.CLEAR` (all) / `CLR` (mask) | 0 | 0 | discarded (house convention of Modules 03–05 and DFPERF) |
| `PRE_LOAD` (mask) | `{PRE_HI, PRE_LO}` truncated to CNT_W, atomically | unchanged | discarded |
| `CTRL.SAMPLE` | the events of that cycle (restart from them) | 0 | **kept** in the new interval |
| `CTRL.SNAPSHOT` / `snap_i` | unchanged (keeps counting) | unchanged | counted normally |

**Snapshot semantics.** `SNAPSHOT`, `SAMPLE` or `snap_i` copy **every** counter and OVF into the snapshot registers in one
clock edge. Each copy is the counter's value at the **start** of the strobe cycle: all events of earlier cycles and none
of that cycle. Every snapshot register therefore belongs to the same instant, which makes ratios such as FLOPs / cycles
or retired / issued coherent. `STATUS.SNAP_SEQ` counts snapshots, so a reader can detect that another agent snapshotted
in between. SNAPSHOT never disturbs counting.

**SAMPLE** is snapshot plus restart in one edge. The restart value is the counter's own events of that cycle, so the
sampled intervals add up exactly to the total. The unit test checks this, and mutant C14 "SAMPLE loses the events of its
own cycle" is killed.

**Preload** exists for context save and restore, for checking overflow behaviour on the real 64-bit hardware, and for
offset measurements. `PRE_LO` / `PRE_HI` are staging registers, and the load is atomic for all selected counters.

## 5. Readback on a 32-bit bus

Two coherent paths:

1. **Snapshot window** (preferred, coherent across all counters, safe with several readers): write SNAPSHOT, then read
   `SNAP_LO[i]` / `SNAP_HI[i]` at leisure.
2. **Latched live pair** (one counter, one reader): reading `LIVE_LO[i]` returns the low word and latches the high word
   **of the same cycle**. The next `LIVE_HI[i]` returns that latched word, so `{HI, LO}` is the exact 64-bit value in
   the LO-read cycle even while the counter carries across bit 32. The latch is consumed by its HI read. A `LIVE_HI[i]`
   that does not follow its LO read returns the current live high word and sets the sticky `STATUS.LATCH_MISS` (W1C).
   Only one latch exists: interleaving two readers' pairs breaks the pairing, and LATCH_MISS reports it.

Evidence that latching matters: in the unit test, unlatched HI-then-LO reads across a carry tore in 7 of 28 attempts.
Every latched pair, and every pair read during activity on the real tile, matched the reference exactly.

Read side effects exist only on `LIVE_LO` (the latch). Everything else is side-effect free. Back-to-back strobes in
consecutive cycles are supported. The tests read `LIVE_LO[CYCLES]` in up to 8 consecutive cycles and require +1 per
cycle.

## 6. Timing summary (EV_REG = 0 view of the bank; add one cycle for events with EV_REG = 1)

```
cycle            t-1          t                 t+1
event inc_i      e(t-1)       e(t)              e(t+1)
counter value    c            c + e(t-1)        c + e(t-1) + e(t)          (register output during the cycle)
SNAPSHOT strobe               ^ copies c+e(t-1) (value at the start of t; e(t) is counted, not copied)
LIVE_LO read                  ^ returns low(c+e(t-1)), latches high(c+e(t-1))
LIVE_HI read                                    ^ returns the latched high word -> {HI,LO} = c+e(t-1)
CTRL write (ENABLE=0)         ^ e(t) still counted                 e(t+1) not counted
CLEAR                         ^ counter := 0, e(t) discarded       counts e(t+1)
SAMPLE                        ^ snapshot := c+e(t-1), counter := e(t)
```

## 7. Verification of these semantics

* the software reference model `model/perf_ref.py` encodes this document and is compared with the RTL in every cycle of
  every unit run (5 configurations, Verilator and Icarus);
* formal (`formal/run_formal.sh`): no silent overflow, exact wrap / saturate / hold arithmetic, snapshot coherence, latch
  specification, reset and OVF stickiness, all proven by k-induction, with three negative controls refuted;
* 22 counter-bank mutants, all killed (`reports/mutants.md`).

Results: `docs/05_verification.md`.
