# 06 — Host-side telemetry: extraction and derived performance

Tool: `host/hpc_perf_telemetry.py` (Python ≥ 3.10, standard library only; imports `model/perfmap.py`, the same map the
RTL header is generated from). Tests: `scripts/test_telemetry.py` (`reports/telemetry_tests.md`).

## 1. Workflow

```
running system ──read──► regdump.json ──derive──► telemetry.json
 (FPGA / board: --backend devmem --base ADDR)      (--source, --clock-hz, --clock-basis, optional --baseline / --with-analytical)
 (RTL simulation: tb/tb_hpc_tile_perf.sv writes regdump.json itself)
configuration + workload ──analytical──► estimate.json        (never mixed into measured results)
```

* `read` takes a coherent snapshot (`CTRL.SNAPSHOT`, then the snapshot window). It checks `ID`, and checks `SNAP_SEQ`
  to detect another agent's snapshot during the read. The `devmem` backend maps `/dev/mem` on a Linux SoC. It is
  implemented but **not exercised in this repository** (no hardware here); the RTL testbench writes the identical dump
  format.
* `derive` decodes INFO / TILECFG, assigns every counter a status, and computes the metrics of §3 with their formula and
  unit. `--baseline earlier.json` reports an interval: deltas between two dumps of the same build. Deltas are modular
  across a 64-bit wrap, and are refused across different builds.
* `analytical` computes an ideal-case estimate from a configuration and a workload description.

## 2. Provenance rules (enforced)

| Rule | Enforcement |
|---|---|
| Every result states what it is | `measurement.kind` ∈ {`rtl_simulation`, `fpga`, `asic`, `emulation`, `analytical_estimate`}, plus `is_hardware_measurement`, `is_silicon` and a plain-language `statement` |
| A measurement is reported only as what it is | `--source` must equal the hardware's own `INFO.PLATFORM` (a build parameter: what the netlist was built for). A simulation dump is refused as fpga / asic / emulation; an FPGA dump is refused as ASIC. **An FPGA result can never be reported as ASIC performance** |
| ASIC results identify the part | `--source asic` requires `--silicon-id` and `--process` |
| Seconds come from the actual configured clock | `--clock-hz` with `--clock-basis` (`pll_config` / `measured` / `nominal`); without it, the build-configured `CLK_KHZ` register is used and labelled (`nominal_register`, or `assumed` for simulation). No clock at all → refused. For `rtl_simulation` the clock is by definition an assumption (a simulation has no physical clock) |
| Analytical numbers stay separate | `analytical` output has its own kind and no counters; `derive --with-analytical` adds an `analytical_reference` block labelled `analytical_estimate`. The only analytical quantity inside `derived` is the lane-peak ratio, whose formula text says so |
| Invalid counters do not produce numbers | OVF set + SAT = 0 → *wrapped (invalid)*, metrics using it have value `null`; OVF + SAT = 1 → *saturated (lower bound)*, metrics are marked *bound only*; CNT_EN = 0 → *not counted*; above `TILECFG.INSTR_PHASE` → *not instrumented* |

`examples/provenance_refusals.txt` shows the refusals produced on the real simulation dump.

## 3. Derived metrics

`f` = clock in Hz, `N` = TILECFG.NUM_LANES, `T = CYCLES / f`.

| Metric | Formula | Unit |
|---|---|---|
| elapsed_time | CYCLES / f | s |
| cycles_per_vector_element_op | CYCLES / VEC_RETIRED | cycles / element-op |
| busy_cycles_per_vector_element_op | VEC_BUSY / VEC_RETIRED | cycles / element-op |
| cycles_per_command | CYCLES / CMD_COMPLETED | cycles / command |
| elements_per_vector_command | VEC_RETIRED / VEC_CMD_COMPLETED | elements |
| lane_utilisation_while_busy | VEC_ISSUED / (N · VEC_BUSY) | fraction (the Module 03 definition) |
| lane_utilisation_window | VEC_ISSUED / (N · CYCLES) | fraction |
| flops_per_cycle, compute_throughput | FLOPS_RETIRED / CYCLES, FLOPS_RETIRED / T | FLOP/cycle, FLOP/s |
| compute_throughput_while_busy | FLOPS_RETIRED · f / VEC_BUSY | FLOP/s |
| reduction_add_share | RED_ADDS / FLOPS_RETIRED | fraction |
| dma_read / write / effective_bandwidth | DMA_BYTES_RD / T, DMA_BYTES_WR / T, (RD + WR) / T | B/s |
| dma_bandwidth_while_active, dma_bytes_per_active_cycle | (RD + WR) · f / DMA_ACTIVE, (RD + WR) / DMA_ACTIVE | B/s, B/cycle |
| dma_active_fraction | DMA_ACTIVE / CYCLES | fraction |
| memory_stall_pct_of_vector_busy | 100 · VEC_OPND_STARVE / VEC_BUSY | % (vector array waiting for operand data) |
| memory_stall_pct_of_window | 100 · VEC_OPND_STARVE / CYCLES | % |
| vector_stall_pct / structural_stall_pct | 100 · VEC_STALL / VEC_BUSY, 100 · (VEC_STALL − VEC_OPND_STARVE) / VEC_BUSY | % |
| output_backpressure_pct | 100 · OUT_BP / CYCLES | % |
| spm_accesses_per_cycle, spm_conflicts_per_access | (SPM_READS + SPM_WRITES) / CYCLES, SPM_CONFLICTS / (READS + WRITES) | — |
| mean_commands_in_flight | CMD_INFLIGHT_SUM / CYCLES | commands |
| mean_command_latency | CMD_INFLIGHT_SUM / CMD_COMPLETED (Little's law; flagged *approximate* unless accepted = completed) | cycles |
| mean_vector_cmdq_occupancy, cmdq_full_pct | VEC_CMDQ_OCC_SUM / CYCLES, 100 · CMDQ_FULL / CYCLES | entries, % |
| dma_mean_outstanding_requests | DMA_OUT_SUM / CYCLES | requests |
| flops_per_cycle_vs_lane_peak | FLOPS_RETIRED / (N · FMA_FLOPS · CYCLES): the denominator is **analytical** (every lane retiring an FMA every cycle) | fraction |

## 4. The example outputs (RTL simulation of the Module 05 workload, 4 lanes, simple DMA engine)

| File | What it is |
|---|---|
| `examples/regdump_rtl_sim.json` | raw register dump after phase B, written by `tb/tb_hpc_tile_perf.sv` |
| `examples/regdump_rtl_sim_phaseA.json` | raw dump after phase A (sequential part) |
| `examples/telemetry_rtl_sim.json` | `derive --source rtl_simulation --with-analytical examples/workload_m05_tile.json` |
| `examples/telemetry_rtl_sim_phaseB_interval.json` | `derive --baseline regdump_rtl_sim_phaseA.json`: phase B alone (DMA and compute overlapping) |
| `examples/telemetry_analytical.json` | `analytical` for the same configuration and workload |
| `examples/provenance_refusals.txt` | the tool refusing to label the simulation dump as FPGA or ASIC |

Reading them (`kind = rtl_simulation`; seconds at the assumed 25 MHz SilicaFlux-V / ULX3S clock):

* **The vector array is starved.** About 95 % of vector-busy cycles are operand-starvation stalls, and lane
  utilisation while busy is under 5 %. The cause is the Module 05 reference sequencer `hpc_tile_vseq`, which loads
  operands one word at a time and is documented as about 25× slower than the array. The counters measure what the
  hardware does: this tile is load/store-bound, not compute-bound.
* **The simple DMA engine** moves 2.0 bytes per active cycle (read + write), i.e. one 4-byte word every two cycles,
  matching Module 05's own measurement (12 000 B in 12 014 cycles).
* **In the phase-B interval** the bank-conflict rate per scratchpad access rises about 2.6× against the whole run,
  because DMA and vector traffic overlap on the scratchpad, and FLOP throughput rises 1.87× from the overlap.
* **Analytical reference:** the measured cycle count is about 6× the analytical serial lower bound (1 beat per cycle,
  4 B DMA per cycle, no stalls). The gap is the sequencer, and the comparison is labelled as such.

None of these numbers is an FPGA or ASIC result.
