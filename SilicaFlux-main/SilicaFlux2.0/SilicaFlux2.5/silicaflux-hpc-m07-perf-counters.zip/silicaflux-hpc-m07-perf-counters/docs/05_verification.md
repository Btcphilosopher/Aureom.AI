# 05 — Verification

Results of the last full run: **`reports/SUMMARY.md`**. Per-step reports are in `reports/`. Everything is reproducible
with `make all`, plus `make equiv` for the Module 03 patch proof.

## 1. Strategy: independent checks at three levels

| Level | Device under test | Independent reference | Where |
|---|---|---|---|
| Counter bank | `hpc_perf_counters` | (a) **software reference model** `model/perf_ref.py`, written from the specification: every input, output and live counter value of every cycle of every run is replayed and compared; (b) directed tests with explicit expected values; (c) formal properties | `tb/tb_hpc_perf_counters.sv`, `scripts/run_unit.py`, `formal/` |
| Event definitions | `hpc_perf_events` on the **real** Module 03 / 04 / 05 | (a) a per-cycle **mirror** in the testbench computed from pins and hierarchical signals (lane pins, issue-stage beat phase, bus response queues), not from the RTL event code; (b) **workload semantics** (Σ vl, FLOPs per op, descriptor bytes, commands, injected errors); (c) the **pre-existing 32-bit counters** of Modules 03 / 04 / 05 with the same definitions | `tb/tb_hpc_tile_perf.sv`, `tb/tb_hpc_perf_varray.sv`, `scripts/run_integ.py` |
| Event arithmetic at full multiplicity | `hpc_perf_events` alone | random protocol-legal stimulus that the real tile rarely or never produces (3 ports losing arbitration in one cycle, both command queues full, illegal reductions with a non-zero count, lane push at full occupancy with a pop); every increment compared with an independent expected value in every cycle; coverage of each combination required | `tb/tb_hpc_perf_events.sv` (stage 3a) |
| Clock crossing | `hpc_perf_cdc_count` | conservation, causality and latency checks under random phase, jitter and a metastability model | `tb/tb_hpc_perf_cdc.sv`, `scripts/run_cdc.py` |

How sensitive the checks are is measured: 46 injected bugs (`scripts/run_mutants.py`), formal negative controls, and
the Module 03 patch proven equivalent (`syn/m03_obs_equiv.sh`).

**What mutation testing found.** The first full mutation run killed 42 of 46. Two survivors were coverage gaps on the
real tile: no cycle with two scratchpad ports losing arbitration, and a DMA descriptor queue that never filled. Two
were unreachable with the real modules: an illegal command always completes with count 0, and a lane never accepts at
full occupancy because its `in_ready` is registered. The response was to add tests, not waivers. The tile test now
issues a 6-descriptor burst (the queue is full for hundreds of cycles, checked exactly), and the synthetic event-layer
test (stage 3a) drives every such combination deliberately. All 46 mutants are killed in the final run.

## 2. Requirement → test

| Requirement (brief §7) | Test | Check |
|---|---|---|
| single events | unit `single_event`: one event on each counter in turn | that counter = 1, all others 0, LIVE read = 1 |
| multiple simultaneous events | unit `multi_event`: every counter, different values incl. 2^INC_W − 1, same cycle; random phase (over 200 000 multi-event cycles) | exact sums, every cycle vs model |
| counter increments | unit `increments` (500 cycles of random small increments); random phase | exact |
| enable / disable | unit `enable_disable` (CTRL.ENABLE, CNT_EN mask, write-cycle semantics); tile phase C (ENABLE = 0 and CNT_EN masking under load) | exact vs mirror |
| freeze | unit `freeze`: CTRL.FREEZE, `freeze_i` (same cycle), FREEZE_ON_OVF and its release; tile phase C (`freeze_i` pulse, CTRL.FREEZE under load) | exact |
| snapshot consistency | unit `snapshot` (values = counters at the SNAPSHOT cycle; lock-step coherence across counters; SNAP_SEQ; snap_i; SAMPLE losslessness); tile: 65–104 snapshots of all 23 counters per run, taken during activity | exact vs mirror at the snapshot cycle; formal A3 |
| overflow | unit `overflow` (wrap, saturate, OVF set-wins-over-W1C, IRQ, SNAP_OVF; natural overflow in the 16- and 8-bit builds); random phase (100 000s of wrap and saturate events); tile phase E (64-bit byte counter preloaded to 2^64 − 256 wraps on a real DMA; a FLOP counter saturates) | exact; formal A1, A2, A6 |
| reset | unit `reset_mid` (asynchronous reset during counting with freeze and snapshot active); random asynchronous resets; first-cycle 4-state behaviour (Icarus) | all registers at reset values; formal A5 |
| back-to-back reads | unit `back_to_back` (8 LIVE_LO reads in consecutive cycles: +1 each; interleaved pairs → LATCH_MISS; consecutive SNAP reads stable); tile: bursts of 6 consecutive CYCLES reads during activity | exact |
| multi-lane retirement | vector-array test N = 1, 2, 4, 8, 16 with lane holds: histogram of simultaneous retirements covers 1..N; tile with 25 % lane holds; event-layer test with up to 16 lanes retiring and accepting at full occupancy | exact VEC_RETIRED / FLOPS vs workload and Module 03 ELEM_OUT; every cycle vs expected |
| counter read during active operation | unit `read_during_activity` (latched pairs while the carry crosses bit 32: exact; unlatched reads shown to tear); tile: every snapshot and live pair taken while DMA, vector and host traffic run | exact vs mirror at the read cycle; formal A4, A7 |
| software reference counter model | `model/perf_ref.py` (bank); testbench mirrors (events); `examples/` derived by `host/hpc_perf_telemetry.py` | 0 mismatching cycles required |

## 3. Bring-up order (brief: phase-1 counters first)

`scripts/run_integ.py` stage 1 builds the tile with `INSTR_PHASE = 1` and verifies CYCLES, VEC_RETIRED, FLOPS_RETIRED,
VEC_STALL, DMA_BYTES_RD and DMA_BYTES_WR against the mirror, the workload and the Module 03 / 05 counters. It also
checks that every other counter stays 0. Stages 2 and 3 run only if stage 1 passes (`docs/03` §0).

## 4. Formal

`formal/run_formal.sh` (yosys-smtbmc + z3 5.3.3). Every input is unconstrained, including arbitrary register-bus
traffic, refused writes and invalid offsets. A1 no silent overflow · A2 exact wrap / saturate / hold arithmetic ·
A3 snapshot = pre-cycle counter values, for every counter · A4 latched-readback specification · A5 reset · A6 OVF
sticky · A7 latch state equals its specification model (the strengthening invariant). BMC depth 20 and **k-induction
(k = 20) proven** in three configurations (2 × 40 bit, 3 × 8 bit, 2 × 12 bit without snapshot / preload). Negative
controls (silent saturation, corrupted snapshot, latch index ignored) are each refuted with a counterexample.

## 5. Tools and their quirks (found during this work)

| Tool | Quirk | Handling |
|---|---|---|
| Icarus 12 | output argument of an automatic task cannot target an unpacked-array element (`q[k]`); no `break`; no `return` in tasks | testbenches use scalar temporaries, flags, and if-blocks |
| Icarus 12 | X on outputs before the first clocked reset (no `negedge rst_n` at time 0) | the reference model accepts X only while `rst_n = 0` |
| Verilator 5.020 | arrays of queues indexed by a variable miscompile; function calls in delay expressions crash; a `fork` branch of the main `initial` that calls a timing task containing loops of task calls segfaults in the coroutine runtime | rings instead of queues; delays computed into variables; the DMA burst runs outside the fork |
| Yosys equivalence | `$adff` cells are not handled by `equiv_simple` / `equiv_induct` | `async2sync` before `equiv_make` |
| z3 4.8.12 (Debian) | hangs on the yosys-smtbmc pipe (0 CPU) | z3 5.3.3 from `pip install z3-solver` |
| Yosys ABC vs ABC9 | wide read-mux LUT counts differ ~2× | both reported, flip-flop counts are the firm number |
