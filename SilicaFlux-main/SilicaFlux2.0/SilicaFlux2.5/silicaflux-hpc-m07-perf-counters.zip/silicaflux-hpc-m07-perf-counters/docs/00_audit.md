# 00 — Audit of the existing performance-monitoring infrastructure

Repository: `btcphilosopher/Aureom.AI`. The SilicaFlux-HPC modules exist only as archives in
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` (`silicaflux-hpc-fp32-fma.zip`, `-m02-vector-lane`, `-m03-vector-array`,
`-m04-scratchpad`, `-m05-dma-adapter`) plus the DataFabric (`SilicaFlux-main/silicaflux-datafabric.zip`). There is no
Module 06 archive in the repository; this module builds on Modules 02–05 and on the Module 05 integration tile.
Every file read for this audit is listed with the conclusion drawn from it.

## 1. What exists

| Source | What it counts | Width / overflow | Readout | Event pulses exported? |
|---|---|---|---|---|
| **M02** `hpc_vector_lane` | — (no counters) | — | — | **yes**: `ev_accept_o` (enabled op accepted), `ev_retire_o` (result handed over), `ev_pipe_stall_o`, `ev_backpressure_o`, `ev_illegal_o`, `ev_masked_o`; documented as "intended for an `hpc_perf_counters`-style counter block" (LANE_INTERFACE.md §7b) |
| **M03** `hpc_varray_perf` (in `hpc_vector_array`) | 16: CYCLES, BUSY, CMD_IN, CMD_DONE, BEAT_IN/OUT, ELEM_IN/OUT, STALL_LANE, STALL_TRK, LANE_STALL, OPND_STARVE, RES_BP, COLL_WAIT, RED_WAIT, CPL_BP | 32-bit, **saturating** | flat output vector `perf_cnt_o`, no register interface, no snapshot | **no**: the lane `ev_*` pins are left unconnected and the issue/collector events feed only `hpc_varray_perf` |
| **M04** `hpc_spm_perf` (in `hpc_scratchpad`) | cycles, accept / issue / complete / conflict / wait / error per port, ops per bank, ECC errors | 32-bit, saturating | flat outputs | **yes**: `ev_accept`, `ev_issue`, `ev_conflict`, `ev_credit_stall`, `ev_error`, `ev_ecc_err`, `ev_bank_ops`, `ev_bank_conflict` |
| **M05** `hpc_dma_perf` (in `hpc_dma_adapter`) | 16: CYCLES, ACTIVE, BYTES_RD, BYTES_WR, READS, WRITES, REQ_STALL, RSP_WAIT, OUT_SUM, OUT_MAX, CPL_OK/ERR, BUS_ERR, TAG_ERR, SPM_REQ, FAB_REQ | 32-bit, saturating | flat output vector | **yes**: `ev_cmd_accept`, `ev_start`, `ev_cpl`, `ev_cpl_err`, `ev_bytes_rd`, `ev_bytes_wr` (8-bit per-cycle byte counts), `ev_req_stall`, `ev_outstanding`, `ev_bus_err`, `ev_tag_err`; `active` |
| **DataFabric** `sfb_perf_counters` (page DFPERF) | per-master reads / writes / stalls / arbitration losses / errors, DMA bytes / busy / idle, FIFO max, **64-bit cycle counter** | 32-bit saturating + 64-bit cycles | register page on the SilicaFlux-V peripheral bus; **CTRL.SNAPSHOT** copies all counters atomically; CTRL.CLEAR, CTRL.ENABLE | — |
| **DataFabric** `dma_control_regs` | ACTIVE_CYCLES, STALL_CYCLES, TRANSFERS | 32-bit, **wrap** | register page | — |
| CPU (`cpu_core.zip`, `RISC-V CPU.zip`, `pipelined_cpu.zip`, `.sf` sources) | no `mcycle`/`minstret`-style counters found | — | — | — |
| Debug registers | none in the HPC modules; DataFabric pages are the only memory-mapped status | — | — | — |

## 2. Conclusions that shaped Module 07

1. **Reuse event definitions, do not re-derive them.** M04 and M05 already export per-cycle event values whose
   definitions are documented and verified there (bytes of error-free responses, issuable-request-lost-arbitration,
   integrity errors). Module 07 consumes them unchanged. M02's lane events are used for issue and retirement; M03's issue
   stage events for stalls. The definitions are restated in `docs/03_event_definitions.md` with their source.
2. **The vector array must expose its events.** M03 hides them. Module 07 adds an *observation port* to a copy of two M03
   files (`rtl/m03_obs/`), connecting the lanes' own `ev_accept_o`/`ev_retire_o` pins and the existing issue-stage events
   and command-queue status to new outputs. No existing logic changes; `syn/m03_obs_equiv.sh` proves the patched array
   equivalent to the original on every pre-existing output and register (Yosys `equiv_*` + induction, NUM_LANES 1, 2, 4).
3. **Register convention.** The house register bus is the SilicaFlux-V peripheral bus (`rb_sel` strobe, combinational
   `rb_rdata`/`rb_err`), and DFPERF already uses SNAPSHOT for coherent multi-word reads. Module 07 follows both.
4. **Overflow policy differs from the house default on purpose.** Every existing HPC counter saturates silently at 32 bits
   (no flag). The brief requires 64-bit counters that do not silently saturate. Module 07 wraps modulo 2^64 by default,
   saturates only where software selects it (SAT register), and sets a sticky OVF bit in both cases (plus an optional
   interrupt and freeze-on-overflow).
5. **The existing 32-bit counters stay** (they are part of the verified Modules 03–05). They serve as an independent
   cross-check: where a Module 07 counter has the same definition, the integration test requires equality.
6. **Single clock.** Modules 03, 04 and 05 and the crossbar share the SoC functional clock (M05 doc 08 §1); the counter
   bank is single-clock. For future event sources in another domain, `hpc_perf_cdc_count` is provided and verified
   (`docs/04_clock_domains.md`).
7. **What the existing sequencer implies for measurements.** `hpc_tile_vseq` (M05) is a deliberately serial reference
   sequencer, about 25× slower than the array. Measured lane utilisation on the tile is therefore low and is
   dominated by operand starvation. The counters report this as it is.
