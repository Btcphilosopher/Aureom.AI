# 03 — Event definitions (tile binding `hpc_perf_events`)

Every counter is one expression in `rtl/hpc_perf_events.sv`, evaluated once per tile clock cycle. "Handshake" means
`valid & ready` in the same cycle. Signals named `obs_*` come from the Module 03 observation port (`rtl/m03_obs/`,
additive, proven not to change the array). `ev_*` signals are the existing event ports of Modules 04 / 05, used with
their own documented definitions.

## 0. Staged bring-up (phase 1 first)

The brief asked for the cycle, vector-retirement, DMA-byte and stall counters to be implemented and their definitions
verified before any further instrumentation. The bring-up is reproducible:

* `INSTR_PHASE = 1` builds the tile with **only** the phase-1 counters live: CYCLES, VEC_RETIRED, FLOPS_RETIRED,
  VEC_STALL, DMA_BYTES_RD, DMA_BYTES_WR. Every other counter receives no events, and the testbench checks that they
  stay 0. `INSTR_PHASE = 2` adds the remaining mandatory counters; `3` (default) adds the extended counters. The value
  is published in `TILECFG.INSTR_PHASE`, and the host tool reports higher-phase counters as *not instrumented*, not as 0.
* `scripts/run_integ.py` **stage 1** runs the phase-1 build on the real tile first. Every other stage runs only if
  stage 1 passes.
* What stage 1 establishes for each phase-1 definition, on the real Modules 03 / 04 / 05:

| Counter | Verified against | Result (`reports/integration.md`) |
|---|---|---|
| CYCLES | testbench mirror at every snapshot; Module 05 cycle counter: CYCLES = M05_CYCLES − EV_REG exactly | exact |
| VEC_RETIRED | lane pins (hierarchical, not the obs port); Σ vl of the workload; Module 03 ELEM_OUT | exact |
| FLOPS_RETIRED | per-lane weight queues in the testbench; workload Σ vl × weight(op) = 2·1000 (FMADD) + 1000 (FADD) + 0 (IMUL) + 6·256·2 (AXPY FMADD) = 6072 | exact |
| VEC_STALL | issue-stage beat phase and operand handshake (hierarchical); Module 03 STALL_LANE + STALL_TRK + OPND_STARVE | exact |
| DMA_BYTES_RD | bytes of error-free read responses on the adapter's fabric and scratchpad ports (testbench response queues); Σ descriptor lengths rounded up to whole words; Module 05 BYTES_RD | exact |
| DMA_BYTES_WR | strobe bytes of error-free write acknowledgements (testbench queues); Σ descriptor lengths, including a 3997-byte transfer with a partial final word; Module 05 BYTES_WR | exact |

Phase-2 and phase-3 counters were enabled only with the stage-1 checks in place, and are verified the same way
(stage 2: tile; stage 3: vector array).

## 1. Counter definitions

`N` = lanes, `P` = scratchpad ports, `NP` = DMA ports. Increment ranges are per cycle.

| # | Counter | Increment in a cycle | Range | Source and reused definition |
|---|---|---|---|---|
| 0 | **CYCLES** — total active clock cycles | 1 | 1 | every rising edge of the tile clock while counting (the measurement window; the tile clock is not gated) |
| 1 | **CMD_ACCEPTED** | vector-command handshake + DMA-descriptor handshake | 0..2 | M03 `cmd_valid_i & cmd_ready_o`; M05 `cmd_valid & cmd_ready` (= `ev_cmd_accept`) |
| 2 | **CMD_COMPLETED** | vector-completion handshake + DMA-completion handshake | 0..2 | M03 `cpl_valid_o & cpl_ready_i`; M05 `cpl_valid & cpl_ready`. Error completions are completions (and also HW_ERRORS events) |
| 3 | **VEC_ISSUED** | Σ over lanes of M02 `ev_accept_o` = `in_valid & in_ready & lane_en` | 0..N | an element operation is *issued* when a lane accepts it. Masked-off elements are consumed but not issued; illegal commands issue nothing (M03 filters them) |
| 4 | **VEC_RETIRED** | Σ over lanes of M02 `ev_retire_o` = `out_valid & out_ready` | 0..N | an element operation is *retired* when its lane hands over the result. Every issued operation retires exactly once, in order (M02 §5), so issued − retired = in flight |
| 5 | **FLOPS_RETIRED** | Σ over retiring lanes of the FLOP weight of the retiring operation + reduction additions of a completion handed over | 0..2N + 2^VL_W−1 | §2 below |
| 6 | **VEC_STALL** — vector stall cycles | 1 if the issue stage is in a beat phase and does **not** release the operand beat this cycle | 0/1 | = M03 STALL_LANE ∨ STALL_TRK ∨ OPND_STARVE (mutually exclusive). Causes: no operand beat (memory starvation), a lane cannot take its element, beat-tracking queue full |
| 7 | **DMA_ACTIVE** | 1 while the engine executes a transfer (validation → terminal) | 0/1 | M05 `active` (= HPC_DMA_PC_ACTIVE) |
| 8 | **DMA_BYTES_RD** | bytes delivered by error-free read responses (full words) | 0..NP·DW/8 | M05 `ev_bytes_rd` (= HPC_DMA_PC_BYTES_RD) |
| 9 | **DMA_BYTES_WR** | bytes committed: byte strobes of error-free write acknowledgements | 0..NP·DW/8 | M05 `ev_bytes_wr` (= HPC_DMA_PC_BYTES_WR) |
| 10 | **SPM_READS** | Σ over scratchpad ports of read-request handshakes (`req_valid & req_ready & !req_we`) | 0..P | at the accept point; every accepted request is issued exactly once (M04). Decode-error requests are included and are also HW_ERRORS events |
| 11 | **SPM_WRITES** | the same with `req_we` | 0..P | as above |
| 12 | **SPM_CONFLICTS** | Σ over ports of M04 `ev_conflict` (an issuable request lost bank arbitration) | 0..P | port-cycles of delay due to bank conflicts (= Σ M04 perf_conflict) |
| 13 | **CMDQ_FULL** | 1 if the vector command queue holds CMD_DEPTH entries **or** the DMA descriptor queue cannot accept (`!cmd_ready`, a full queue when CMD_DEPTH > 0) | 0/1 | cycles in which tile command intake is (at least partly) blocked |
| 14 | **OUT_BP** — output back-pressure cycles | 1 if any tile output is presented and not taken: vector result beat, vector completion, DMA completion | 0/1 | consumer-side back-pressure |
| 15 | **HW_ERRORS** | number of error events this cycle over the error sources of §3 | 0..8 | events, not root causes: one fault can raise several sources (a parity error on a DMA read is an SPM_ECC_ERR and later a DMA_CPL_ERR) |
| 16 | VEC_BUSY | 1 if the vector array reports `busy_o` | 0/1 | M03 BUSY, the denominator of lane utilisation |
| 17 | VEC_OPND_STARVE — memory stall | 1 if a beat is due and no operand beat is offered | 0/1 | M03 OPND_STARVE |
| 18 | CMD_INFLIGHT_SUM | commands accepted and not yet completed, at the start of the cycle | 0..65535 | Little's law: mean latency = SUM / CMD_COMPLETED (exact when nothing is in flight at both window edges) |
| 19 | VEC_CMDQ_OCC_SUM | vector command-queue occupancy | 0..CMD_DEPTH | mean occupancy = SUM / CYCLES |
| 20 | DMA_OUT_SUM | outstanding DMA bus requests | 0..255 | M05 `ev_outstanding` (= HPC_DMA_PC_OUT_SUM) |
| 21 | RED_ADDS | reduction FP additions retired (completion handshake of a legal reduction: + its active-element count) | 0..2^VL_W−1 | subset of FLOPS_RETIRED |
| 22 | VEC_CMD_COMPLETED | vector-completion handshake | 0/1 | DMA completions = CMD_COMPLETED − VEC_CMD_COMPLETED |

**Issued vs completed.** Commands: CMD_ACCEPTED is the handshake at the queue entry, CMD_COMPLETED the completion-record
handshake at the output. Element operations: VEC_ISSUED is lane acceptance, VEC_RETIRED is result handover. No counter
mixes the two, and the difference of each pair is the work in flight at the snapshot.

## 2. Floating-point operations

**Convention (FMA = 2 FLOPs).** FLOPs are credited when an operation **retires**, never at issue:

| Element operation | FLOPs (parameter) |
|---|---|
| FADD, FSUB, FMUL | 1 |
| FMADD, FMSUB, FNMSUB, FNMADD (fused multiply-add family) | **2** (`FMA_FLOPS`, 1..3; default 2 = one multiply + one add, the usual HPC / LINPACK convention) |
| FMIN, FMAX, FEQ, FLT, FLE | 0 (`CMP_FLOPS`, 0..3; not arithmetic in the default convention) |
| FMV, IADD, IMUL | 0 (not floating-point arithmetic) |
| sum-reduction of k active elements | **+k** additions at the completion handshake: per beat with a ≥ 1 active elements the reduction performs (a − 1) tree additions + 1 accumulator addition (Module 03 REDUCTION.md §1); summed over beats that is exactly k |

So a dot product of n elements counts n (FMUL) + n (reduction adds) = 2n, and an AXPY (FMADD) of n elements counts 2n.
Both conventions (`FMA_FLOPS`, `CMP_FLOPS`) are published in TILECFG and recorded in every telemetry JSON.

**Mechanism.** A retiring lane result does not carry its opcode. `hpc_perf_wtrack` (one per lane, depth = the lane's
ROB_DEPTH, exactly sufficient) records the weight of every accepted operation and returns it when that operation
retires. This is exact because each lane completes in acceptance order. The FLOP counter is therefore correct under
partial issue, lane holds, back-pressure and mixed operations in flight. Mutant E02 credits the weight of the operation
being issued now instead; the regression kills it. A tracker over- or underflow means the binding no
longer matches the lane's behaviour; it raises error source PERF_TRACK_ERR, which never fired in any run.

## 3. Hardware error sources (`ERR_SRC`, sticky, W1C)

| Bit | Source | Event |
|---|---|---|
| 0 | VEC_ILLEGAL | vector completion handed over with `cpl_illegal` |
| 1 | DMA_CPL_ERR | DMA completion handed over with `cpl_err` (any code but NONE: validation, region, bus error, abort) |
| 2 | DMA_BUS_ERR | M05 `ev_bus_err`: an error response was received (cycle-level, any port) |
| 3 | DMA_TAG_ERR | M05 `ev_tag_err`: response-ownership violation |
| 4 | SPM_ECC_ERR | M04 `ev_ecc_err` (parity), counted per port |
| 5 | SPM_DECODE_ERR | M04 `ev_error` (request outside the array), counted per port |
| 6 | PERF_TRACK_ERR | telemetry self-check: weight-tracker or in-flight-counter inconsistency |
| 7 | reserved | 0 |

HW_ERRORS increments by the number of sources raised in the cycle, with per-port multiplicity for sources 4 and 5. The
tile test injects an illegal vector command and a misaligned DMA descriptor and requires HW_ERRORS += 2 with exactly
bits 0 and 1 in ERR_SRC.

## 4. Multiple events per cycle — where they occur and how they are verified

| Counter | Max per cycle (tested) | Evidence |
|---|---|---|
| VEC_ISSUED / VEC_RETIRED | N (up to 16) | vector-array test, N = 16: the histogram of lanes retiring together covers every k from 1 to 16 in every seed (582–628 cycles per run with all 16 lanes retiring in the same cycle) |
| FLOPS_RETIRED | 2N + reduction count | vector-array test: exact against the workload with reductions of up to 8N elements |
| DMA_BYTES_* | NP·4 | dual-port DMA configurations |
| SPM_* | P (up to 3) | dual-port DMA: 3 scratchpad ports; event-layer test (stage 3a): 2 and 3 ports losing arbitration in the same cycle, thousands of cycles each |
| CMD_ACCEPTED / COMPLETED | 2 | concurrent vector and DMA activity (phase B); event-layer test |
| CMDQ_FULL | 1 (OR of both queues) | tile phase C: a 6-descriptor burst keeps the DMA queue full for hundreds of cycles; event-layer test: both queues full together |
| any counter (bank) | 2³² − 1 | unit test: maximum increments on every counter in the same cycle (337 293 maximum-increment events, 242 781 multi-event cycles in the regression) |
