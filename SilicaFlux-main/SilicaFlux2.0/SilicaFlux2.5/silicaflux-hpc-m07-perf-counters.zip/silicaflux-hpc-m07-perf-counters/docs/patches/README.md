# Module 03 observation-port patch

`m03_observation_port.diff` is the complete difference between the unmodified Module 03 files
(`third_party/silicaflux-hpc-m03-vector-array/rtl/`) and the copies Module 07 builds with (`rtl/m03_obs/`).

| File | Change |
|---|---|
| `hpc_varray_issue.sv` | two new outputs: `cq_full_o` (= the existing internal `cq_full`), `cq_count_o` (the command FIFO's `count_o`, previously left unconnected) |
| `hpc_vector_array.sv` | eight new outputs `obs_*`: the lanes' own `ev_accept_o` / `ev_retire_o` pins (previously unconnected), `ln_op` (operation offered to the lanes), the three issue-stage stall events that already fed `hpc_varray_perf`, and the two command-queue signals above |

Nothing else changes: no existing expression, register, port or parameter. `syn/m03_obs_equiv.sh` proves it. It
removes the new ports from the patched netlist and checks the result against the original with Yosys
(`equiv_make`, `equiv_struct`, `equiv_simple -seq 2`, `equiv_induct`, `equiv_status -assert`, after `async2sync`). All
equivalence points are proven for NUM_LANES = 1, 2 and 4 (`reports/m03_obs_equiv/`):

| NUM_LANES | Equivalence points | Proven | Time |
|---|---|---|---|
| 1 | 7 195 | 7 195 | 163 s |
| 2 | 11 975 | 11 975 | 501 s |
| 4 | 21 270 | 21 270 | 1 564 s |

Recommendation for Module 03: adopt the observation port upstream. It is the clean way for any external counter block
to see lane-level issue and retirement.
