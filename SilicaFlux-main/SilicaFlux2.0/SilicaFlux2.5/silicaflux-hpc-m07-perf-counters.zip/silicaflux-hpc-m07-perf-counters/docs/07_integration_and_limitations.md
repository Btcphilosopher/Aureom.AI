# 07 — Integration, known limitations, next actions

## 1. Integrating the telemetry unit in a tile

1. **Vector array.** Use the Module 03 files with the observation port: `rtl/m03_obs/hpc_vector_array.sv` and
   `rtl/m03_obs/hpc_varray_issue.sv` replace their Module 03 originals; every other Module 03 / 02 file stays as it is.
   The patch (`docs/patches/m03_observation_port.diff`) only adds output ports wired to existing signals: the lanes'
   own `ev_accept_o` / `ev_retire_o`, the operation offered to the lanes, the three issue-stage stall events, and
   command-queue full / count. `syn/m03_obs_equiv.sh` proves the patched array equivalent to the original on every
   pre-existing output and register: Yosys `equiv_make` / `equiv_simple` / `equiv_induct`, all equivalence points
   proven for NUM_LANES = 1 (7 195), 2 (11 975) and 4 (21 270) (`reports/m03_obs_equiv/`).
2. **Instantiate `hpc_perf_tile`** with the tile's parameters: `N` = NUM_LANES, `VL_W`, `ROB_DEPTH` = the lane
   ROB_DEPTH, `CQ_W` = $clog2(CMD_DEPTH + 1) of the array, `NSP` = scratchpad ports, `DMA_NP`, `DMA_BEAT_B`,
   `DMA_CMDQ` = (DMA CMD_DEPTH > 0). Connect the ports as in `tb/tb_hpc_tile_perf.sv`: array handshakes and obs
   port; DMA `cmd_*` / `cpl_*` handshakes, `active`, `ev_bytes_rd` / `ev_bytes_wr` / `ev_outstanding` / `ev_bus_err` /
   `ev_tag_err`; scratchpad `req_valid` / `req_ready` / `req_we` of **all** ports and `ev_conflict` / `ev_error` /
   `ev_ecc_err`.
3. **Register page.** One 4 KiB page on the SilicaFlux-V peripheral register bus, the same protocol as DataFabric DFPERF
   (e.g. a free peripheral slot next to DFPERF at `0x40007000`). `irq_o` to the interrupt controller if overflow
   interrupts are wanted.
4. **Build parameters that describe the build:** `PLATFORM` (0 simulation, 1 FPGA bitstream, 2 ASIC netlist),
   `CLK_KHZ` (the configured functional clock), `BUILD_ID` (e.g. the git hash). The host tool trusts `PLATFORM` to
   refuse mislabelled results, so the FPGA and ASIC flows must set it.
5. **`freeze_i`** can be tied to the CPU debug-halt signal (counting stops while halted). **`snap_i`** can be pulsed by a
   sequencer at a kernel boundary (a hardware-timed coherent snapshot).
6. The existing Module 03 / 04 / 05 counters can stay (they are the cross-check of §2) or be removed with their
   `PERF_EN = 0` to save area. Module 07 counts everything they count that is listed in `docs/03`.

## 2. Cost (Yosys 0.33, pre-place-and-route; `reports/synth.md`)

| Configuration | Flip-flops (exact) | ECP5 LUT4 (ABC / ABC9 estimate) | Xilinx-7 LUT |
|---|---|---|---|
| `hpc_perf_tile`, N = 4, default (23 × 64 bit, snapshot, preload) | 3 427 | 18 968 / 10 841 | 7 251 |
| `hpc_perf_counters` default | 3 190 | 18 262 / 17 618 | 9 341 |
| `hpc_perf_counters` without snapshot | 1 678 | 8 148 | — |
| `hpc_perf_counters` 16 × 48 bit | 1 731 | 10 695 | — |
| `hpc_perf_counters` lean: 32 bit, no snapshot, no preload | 846 | 4 520 | — |
| `hpc_perf_events` alone (N = 4) | 233 | — | — |
| `hpc_perf_cdc_count` (8 → 16 bit) | 59 | 123 | — |

**FPGA budget warning.** The ULX3S ECP5-85F has about 84 k LUT4, and Module 03 at NUM_LANES = 8 already uses 97 % of them
(Module 03 synthesis report). The default telemetry unit is an estimated 13–23 % of that device, so it will not fit next
to an 8-lane array. The cost sits in the snapshot registers and the wide read multiplexer, not in the counting. For an
FPGA prototype with a large array, use `SNAP_EN = 0` (coherent reads then rely on the latched pair per counter plus
FREEZE for cross-counter consistency), `CNT_W = 48` or `32`, or fewer counters (`INSTR_PHASE = 2` leaves the phase-3
counters idle but still instantiated: reduce `NUM_CNT` in a custom binding to remove them). The ASIC cost is dominated
by about 3.4 k flip-flops.

## 3. What the measurements on this tile show (RTL simulation, not hardware)

See `docs/06_telemetry.md` §4. In short: with the Module 05 reference sequencer the vector array spends about 95 % of
its busy cycles waiting for operands. That is the bottleneck the counters were built to expose. A streaming vector
load/store unit (Module 05 next action 3) is the change these counters should be used to evaluate.

## 4. Known limitations

| # | Limitation | Consequence / mitigation |
|---|---|---|
| L1 | **No FPGA or ASIC measurement exists.** All results are RTL simulation; synthesis numbers are Yosys pre-place-and-route; no Fmax / timing is claimed | the telemetry tool's FPGA / ASIC paths, the `devmem` reader and the provenance checks on hardware dumps are tested only on fabricated dumps |
| L2 | Wide combinational register-read multiplexer (house bus protocol: answer in the strobe cycle) and snapshot registers dominate the area (§2) | LUT counts vary up to ~2× between mappers; use the lean options of §2 on small FPGAs; if the multiplexer limits timing, register the read data (a one-cycle-later bus variant) |
| L3 | One live-read latch | two agents interleaving LIVE pairs break the pairing (STATUS.LATCH_MISS reports it); multi-agent software must use the snapshot window |
| L4 | `CMDQ_FULL` and `OUT_BP` are OR-aggregated over the tile's queues / outputs | per-source cycles are not separated; add per-queue counters if needed (map has 9 free slots) |
| L5 | `HW_ERRORS` counts events, not faults | one fault can raise several sources; ERR_SRC shows which |
| L6 | `DMA_BUS_ERR` is cycle-level (M05 aggregates ports to one bit) | two ports erroring in one cycle count once in that source |
| L7 | Little's-law latency is exact only if nothing is in flight at both window edges | the tool marks it approximate otherwise |
| L8 | `INC_W` = 32 for every counter (one adder width) | no counter can lose events in a cycle; a per-counter INC_W would save a little area |
| L9 | CDC verified in simulation (arbitrary phase, metastability model), not by a structural CDC tool | add a netlist CDC check and the §2 constraints of docs/04 in the implementation flow |
| L10 | The FLOP convention is a parameter, not a runtime choice | FMA_FLOPS / CMP_FLOPS are published in TILECFG and in every telemetry JSON |
| L11 | The `read --backend devmem` path is untested here | needs a Linux SoC with the tile mapped (e.g. Zynq PS + PL), or a UART / JTAG register bridge backend |
| L12 | Icarus 12 prints `sorry: constant selects in always_* processes` for the read multiplexer | informational (sensitivity uses whole vectors); simulation results are identical to Verilator's |

## 5. Next actions (prioritised)

1. **FPGA bring-up on the ULX3S (ECP5-85F)** with `PLATFORM = 1`, `CLK_KHZ` = the PLL output, and a UART register
   bridge backend for `hpc_perf_telemetry.py read`. Report as `--source fpga --clock-basis pll_config`. Compare with
   the RTL-simulation telemetry of the same workload (cycle counts should match exactly for a synchronous design).
2. Place-and-route (nextpnr-ecp5) of `hpc_perf_tile` to replace L2's mapper ranges with a real utilisation and timing
   report; register the read path if it is critical.
3. Use the counters to evaluate the streaming vector load/store unit that replaces `hpc_tile_vseq`. The expected
   signature: VEC_OPND_STARVE falls, lane utilisation rises, SPM_CONFLICTS per access rises.
4. Firmware: a SilicaFlux-V C driver for the register sequences of `docs/02` §5 (snapshot read, SAMPLE intervals,
   overflow IRQ handler), and a firmware test like DataFabric's D8.
5. Per-queue / per-port extended counters (L4, L6) if the analyses need them.
