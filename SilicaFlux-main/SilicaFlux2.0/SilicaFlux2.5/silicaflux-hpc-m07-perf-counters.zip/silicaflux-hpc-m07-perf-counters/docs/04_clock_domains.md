# 04 — Clock domains

## 1. The tile is one clock domain, so the counter bank is single-clock

Every event source counted by `hpc_perf_events` runs on the tile clock: the Module 03 vector array, the Module 04
scratchpad, the Module 05 DMA adapter and the DataFabric crossbar share the SoC functional clock and `sys_rst_n` (Module 05
doc 08 §1, SFB2 rule R11). The register bus (SilicaFlux-V peripheral bridge) is on the same clock. `hpc_perf_counters`
and `hpc_perf_events` are therefore purely synchronous single-clock logic. No signal crosses a clock boundary inside
`hpc_perf_tile`. The integration test runs the whole tile, counters included, on one clock.

Reset: asynchronous assert, synchronous release outside the block (house rule; `sfv_rst_sync` in the SoC).

## 2. Events from another clock domain: `hpc_perf_cdc_count`

**Rule: never connect an unsynchronised multi-bit counter or event bus across domains.** A counter sampled live in
another domain can be captured mid-increment with bits from two different values, so a value like `0x0FF → 0x100` can
be read as anything from `0x000` to `0x1FF`. Gray coding does not fix multi-event increments either, because a jump by
more than one changes more than one bit.

A future event source in another domain (for example a NoC router or an I/O PHY clock) must enter through
`hpc_perf_cdc_count`, whose `inc_o` drives one `inc_i` slot of the bank in the counter clock domain.

```
src_clk:  ev_i ─► acc_q (accumulates; sticky ovf if it ever overflows)
                     │ send (when idle and acc+ev != 0): hold_q := acc_q + ev_i ; acc_q := 0 ; req_tgl ^= 1 ; busy := 1
                     ▼
          hold_q ════════════════════════════(multi-bit, held constant)═══════════════► sampled only after the req edge
          req_tgl ──► [2-FF] ──► dst: on req edge: inc_o := hold_q (one cycle); ack_tgl := req
          busy cleared when [2-FF](ack_tgl) == req_tgl ◄─────────────────────────────────── ack_tgl
          sovf_q  ──► [2-FF] ──► ovf_o (sticky level: events were lost, the count is a lower bound)
```

What crosses the boundary:

| Signal | Width | How it crosses |
|---|---|---|
| `req_tgl`, `ack_tgl` | 1 | 2-FF synchroniser (`hpc_perf_cdc_sync`), toggle protocol |
| `sovf_q` | 1 | 2-FF synchroniser, sticky level |
| `hold_q` | AW | **not synchronised, and does not need to be**: it is written in the same source edge as the request toggle and is held constant until the acknowledgement returns. The destination samples it only after seeing the synchronised request edge, when it has been stable for at least one destination period |

Properties:

* **No loss, no duplication, any ratio or phase.** Events arriving during a transfer accumulate in `acc_q` and travel
  in the next transfer.
* **Capacity.** `acc_q` must hold every event of one round trip, about (3 + 1) destination cycles + 3 source cycles
  including one cycle of metastability resolution per synchroniser: `2^AW − 1 ≥ MAX_EV × round trip in source cycles`.
  If it ever overflows, `ovf_o` reports the loss (sticky); it is never silent.
* **Latency.** One round trip, bounded: the drain completed within 0–9 destination cycles in every test.

Implementation constraints (for the netlist; simulation cannot check them):

* `set_max_delay -datapath_only` (one destination period) from `hold_q` to its destination capture flops, and keep its
  bits together (no skew larger than that);
* false path to the first stage of every `hpc_perf_cdc_sync`; the two stages adjacent (`ASYNC_REG` / dont-touch);
* no logic between `req_tgl` / `ack_tgl` / `sovf_q` and their synchronisers.

## 3. How the crossing was verified

`tb/tb_hpc_perf_cdc.sv`, `scripts/run_cdc.py`, `reports/cdc.md`:

* two unrelated clocks generated in picoseconds with independent random jitter on every half period: fast→slow
  (3.1 → 10 ns, 1 → 40 ns), slow→fast (17.3 → 10 ns, 40 → 1 ns), near-equal with slow phase drift (10.01 / 10 ns, no
  jitter: every phase relation is visited), equal nominal with ±1 ns jitter (random phase walk);
* random event streams up to the maximum every cycle, with bursts, sparse and idle periods;
* **metastability model** (`+define+HPC_CDC_META`, simulation only): on the first edge after a synchroniser input
  changes, the flop resolves to the **old** value with probability ½, so delivery is one cycle later. The model is
  one-cycle bounded, as a real metastable flop resolves by the next edge. Every run reports how many late resolutions
  were injected (thousands per run);
* checks: exact conservation after draining, and the destination counter bank's value equal to it; no event ever
  created (delivered ≤ produced in every cycle); bounded drain; an undersized accumulator must raise `ovf_o`;
* 5 CDC mutants (overwrite while busy, accumulator not cleared, events of the send cycle dropped, no acknowledgement,
  overflow flag missing) are all killed.

This is protocol-level verification under arbitrary phase and modelled metastability. A structural CDC check of the
final netlist (that only these four signals cross, through these synchronisers) belongs to the implementation flow and
is listed in `docs/07_integration_and_limitations.md`.
