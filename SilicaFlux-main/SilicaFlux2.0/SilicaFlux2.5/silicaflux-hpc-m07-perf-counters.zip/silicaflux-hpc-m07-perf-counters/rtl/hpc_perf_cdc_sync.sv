// =============================================================================
// SilicaFlux-HPC Module 07 :: hpc_perf_cdc_sync -- two-flop single-bit synchroniser
//
// The only synchroniser used by hpc_perf_cdc_count.  Single-bit inputs only
// (toggle / sticky level).  `define HPC_CDC_META (simulation only) enables a
// metastability model: a CHANGING input randomly resolves to its OLD value in
// the first stage for one cycle; n_meta counts the injections.
// Implementation: keep s1/s2 adjacent (ASYNC_REG / dont_touch), false-path the
// input of s1.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module hpc_perf_cdc_sync (
  input  wire logic clk,
  input  wire logic rst_n,
  input  wire logic d,
  output logic      q
);
  logic s1, s2;
`ifdef HPC_CDC_META
  // A flop whose input changed close to the edge may resolve to EITHER value at that edge; it is stable by the
  // next edge.  Model: on the first edge after an input change (d differs from the value seen at the previous
  // edge), capture the old value with probability 1/2.  At most one cycle of extra delay per input transition.
  /* verilator lint_off BLKSEQ */
  int unsigned rs = 32'h3C6E_F372;
  int unsigned n_meta = 0;                             // injected "resolved to old value" events
  logic d_prev = 1'b0;
  logic d_cap;
  wire  logic late = (d != d_prev) && (d != s1) && rs[7];
  always @(posedge clk) begin
    if (late) n_meta++;
    d_prev = d;
    rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5);
  end
  assign d_cap = late ? s1 : d;
  /* verilator lint_on BLKSEQ */
`else
  wire logic d_cap = d;
`endif
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin s1 <= 1'b0; s2 <= 1'b0; end
    else        begin s1 <= d_cap; s2 <= s1; end
  end
  assign q = s2;
endmodule

`default_nettype wire
