// =============================================================================
// SilicaFlux-HPC Module 07 :: hpc_perf_wtrack -- per-lane retirement-weight tracker
//
// A lane (Module 02) completes its enabled operations strictly in acceptance
// order and holds at most ROB_DEPTH of them (executing or awaiting handover).
// FLOPs must be credited when an operation RETIRES, but the retiring result
// does not carry its opcode.  This FIFO therefore records the FLOP weight of
// every accepted operation (push = lane ev_accept) and returns it when that
// operation retires (pop = lane ev_retire): head_o is the weight of the
// operation retiring in this cycle.  DEPTH = the lane's ROB_DEPTH is exact,
// never too small.
//
// err_o (telemetry self-check, error source PERF_TRACK_ERR) pulses for a pop
// while empty or a push while full without a pop: either means the event
// binding no longer matches the lane's documented behaviour.  A lane cannot
// retire an operation in the cycle it accepts it (latency >= 1), so a pop of an
// empty tracker is an error even when a push happens in the same cycle.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module hpc_perf_wtrack #(
  parameter int DEPTH = 8,
  parameter int W     = 2
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          push_i,
  input  wire logic [W-1:0]  wdata_i,
  input  wire logic          pop_i,
  output logic      [W-1:0]  head_o,
  output logic               err_o
);
  localparam int IW = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int CW = $clog2(DEPTH + 1);

  if (DEPTH < 1) begin : g_bad_depth
    hpc_param_error_WTRACK_DEPTH_below_1 u_err ();
  end

  logic [DEPTH*W-1:0] mem_q;
  logic [IW-1:0]      rd_q, wr_q;
  logic [CW-1:0]      cnt_q;

  wire logic empty = (cnt_q == '0);
  wire logic full  = (cnt_q == CW'(DEPTH));
  wire logic do_pop  = pop_i & ~empty;
  wire logic do_push = push_i & (~full | do_pop);

  function automatic logic [IW-1:0] inc_ptr(input logic [IW-1:0] p);
    inc_ptr = (p == IW'(DEPTH - 1)) ? '0 : p + IW'(1);
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_q  <= '0;
      wr_q  <= '0;
      cnt_q <= '0;
      mem_q <= '0;
    end else begin
      if (do_push) begin
        mem_q[wr_q*W +: W] <= wdata_i;
        wr_q <= inc_ptr(wr_q);
      end
      if (do_pop) rd_q <= inc_ptr(rd_q);
      cnt_q <= cnt_q + CW'(do_push) - CW'(do_pop);
    end
  end

  assign head_o = empty ? '0 : mem_q[rd_q*W +: W];
  assign err_o  = (pop_i & empty) | (push_i & full & ~do_pop);
endmodule

`default_nettype wire
