// =============================================================================
// SilicaFlux-HPC Module 07 :: hpc_perf_cdc_count -- event-count clock-domain crossing
//
// Carries an event COUNT from a source clock domain into the counter-bank
// domain without losing or duplicating events, for any frequency ratio and
// phase.  The counter bank itself stays single-clock; this block produces a
// per-cycle increment in the destination domain (connect inc_o to one inc_i
// slot of hpc_perf_counters).
//
//   src_clk domain                                   dst_clk domain
//   ev_i --> acc_q (accumulates) --+                  req (2-FF sync) --edge--> inc_o = hold_q (1 cycle)
//                                  +--> hold_q ======= (stable, sampled only after the req edge)
//                                  +--> req_tgl -----> 2-FF ----------------->  ack_tgl
//   busy <-- 2-FF <---------------------------------------------------------- ack_tgl
//
// Protocol (two-phase toggle handshake, the "MCP" formulation):
//   * src: when not busy, hold_q := acc_q + ev_i (everything up to and
//     including this cycle), acc_q := 0, toggle req_tgl, busy := 1.  While
//     busy, events keep accumulating in acc_q.  busy clears when the
//     synchronised ack equals req_tgl.  A transfer is started only when there
//     is something to send.
//   * dst: when the synchronised req differs from the last one seen, hold_q has
//     been stable for >= 1 dst cycle: inc_o := hold_q for that cycle and
//     ack_tgl := req.
// What crosses domains: req_tgl, ack_tgl and ovf_q (single bits, each through a
// 2-FF synchroniser) and hold_q (multi-bit, held constant from before the req
// toggle until after the ack returns -- never sampled while it can change).
// No multi-bit counter is ever sampled live across the boundary.
// Timing constraint for implementation: max delay hold_q -> dst capture <
// one dst_clk period (set_max_delay -datapath_only), plus the usual
// synchroniser false paths on the *_s1 flops.
//
// Capacity: acc_q (AW bits) must hold every event of one round trip
// (~2 dst + 3 src cycles + the busy cycle).  ovf_o (sticky, dst domain) reports
// an accumulator overflow: events were lost and the count is a lower bound.
//
// Simulation-only metastability model (`define HPC_CDC_META, never in
// synthesis): the first synchroniser stage randomly resolves a changing input
// to its OLD value for one cycle, as a metastable flop may.  The testbench
// runs with it enabled.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module hpc_perf_cdc_count #(
  parameter int EW = 8,     // events per source cycle: 0 .. 2^EW - 1
  parameter int AW = 16     // accumulator / transfer width (>= EW)
) (
  // source domain
  input  wire logic           src_clk,
  input  wire logic           src_rst_n,
  input  wire logic [EW-1:0]  ev_i,
  // destination domain (counter bank)
  input  wire logic           dst_clk,
  input  wire logic           dst_rst_n,
  output logic      [AW-1:0]  inc_o,       // events delivered in this dst cycle
  output logic                ovf_o        // sticky: source accumulator overflowed (events lost)
);
  if (AW < EW || EW < 1 || AW > 32) begin : g_bad
    hpc_param_error_CDC_widths u_err ();
  end

  // ---------------------------------------------------------------- source domain
  logic [AW-1:0] acc_q, hold_q;
  logic          req_tgl, busy_q, sovf_q;
  logic          ack_s;
  hpc_perf_cdc_sync u_ack (.clk(src_clk), .rst_n(src_rst_n), .d(ack_tgl), .q(ack_s));

  wire logic [AW:0] sum  = {1'b0, acc_q} + (AW+1)'(ev_i);
  wire logic        done = busy_q && (ack_s == req_tgl);
  wire logic        idle = !busy_q || done;
  wire logic        send = idle && (sum != '0);

  always_ff @(posedge src_clk or negedge src_rst_n) begin
    if (!src_rst_n) begin
      acc_q <= '0; hold_q <= '0; req_tgl <= 1'b0; busy_q <= 1'b0; sovf_q <= 1'b0;
    end else begin
      if (sum[AW]) sovf_q <= 1'b1;                                // events lost: sticky
      if (send) begin
        hold_q  <= sum[AW] ? {AW{1'b1}} : sum[AW-1:0];
        acc_q   <= '0;
        req_tgl <= ~req_tgl;
        busy_q  <= 1'b1;
      end else begin
        acc_q <= sum[AW] ? {AW{1'b1}} : sum[AW-1:0];
        if (done) busy_q <= 1'b0;
      end
    end
  end

  // ---------------------------------------------------------------- destination domain
  logic req_s, req_seen, ack_tgl;
  hpc_perf_cdc_sync u_req (.clk(dst_clk), .rst_n(dst_rst_n), .d(req_tgl), .q(req_s));
  hpc_perf_cdc_sync u_ovf (.clk(dst_clk), .rst_n(dst_rst_n), .d(sovf_q), .q(ovf_o));
  always_ff @(posedge dst_clk or negedge dst_rst_n) begin
    if (!dst_rst_n) begin
      req_seen <= 1'b0; ack_tgl <= 1'b0; inc_o <= '0;
    end else begin
      req_seen <= req_s;
      inc_o    <= (req_s != req_seen) ? hold_q : '0;            // hold_q stable: sampled after the req edge
      if (req_s != req_seen) ack_tgl <= req_s;
    end
  end
endmodule

`default_nettype wire
