// =============================================================================
// SilicaFlux-HPC Module 07 :: hpc_perf_events -- event definitions of the SilicaFlux-HPC tile
//
// The tile binding of hpc_perf_counters: turns the synchronous handshakes and
// event pulses of the Module 03 vector array (with its observation port), the
// Module 04 scratchpad and the Module 05 DMA adapter into one increment per
// counter per cycle (map: hpc_perf_defs.svh, model/perfmap.py).  Every
// definition is a single expression below; docs/03_event_definitions.md states
// it in words with the source module's own definition.
//
// Multiple events per cycle are added in one step: lanes retiring together,
// several scratchpad ports, bytes per beat, both command ports.  Nothing is
// counted "at most once per cycle" unless the definition says "cycles".
//
// FLOPs (FLOPS_RETIRED): credited at RETIREMENT, never at issue.
//   lane part      : for every lane that hands over a result this cycle, the
//                    FLOP weight of that operation (hpc_perf_wtrack per lane):
//                    FADD, FSUB, FMUL = 1; FMADD, FMSUB, FNMSUB, FNMADD =
//                    FMA_FLOPS (default 2: an FMA counts as TWO FLOPs, a
//                    multiply and an add); FMIN, FMAX, FEQ, FLT, FLE =
//                    CMP_FLOPS (default 0); FMV, IADD, IMUL = 0 (not FP
//                    arithmetic).
//   reduction part : a sum-reduction of k active elements performs exactly k
//                    FP32 additions (per beat: (a-1) tree adds + 1 accumulator
//                    add for a >= 1 active elements; REDUCTION.md section 1),
//                    credited when its completion record is handed over
//                    (+cpl_count, also counted alone in RED_ADDS).
//   A dot product of n elements therefore counts n (FMUL) + n (adds) = 2n.
//
// EV_REG = 1 registers every increment (and freeze / snapshot requests, so
// they stay aligned): all counters see their events exactly one cycle late,
// which keeps the tile's handshake logic out of the 64-bit adders.  It does
// not change any count, only when it becomes visible.
//
// INSTR_PHASE (staged bring-up, docs/03 section 0): 1 = only the phase-1 set
// (CYCLES, VEC_RETIRED, FLOPS_RETIRED, VEC_STALL, DMA_BYTES_RD, DMA_BYTES_WR);
// 2 = + the remaining mandatory counters; 3 = + extended counters (default).
// Counters above the selected phase receive no events.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_perf_defs.svh"
`default_nettype none

module hpc_perf_events #(
  parameter int N           = 4,       // vector lanes (Module 03 NUM_LANES)
  parameter int VL_W        = 16,      // Module 03 VL_W (completion count width)
  parameter int ROB_DEPTH   = 8,       // Module 02 lane ROB_DEPTH (weight-tracker depth)
  parameter int CQ_W        = 3,       // width of the vector command-queue count ($clog2(CMD_DEPTH+1))
  parameter int NSP         = 2,       // scratchpad ports
  parameter bit DMA_CMDQ    = 1'b1,    // DMA adapter has a descriptor queue (CMD_DEPTH > 0)
  parameter int FMA_FLOPS   = 2,       // FLOPs credited per fused multiply-add (1 .. 3)
  parameter int CMP_FLOPS   = 0,       // FLOPs credited per FMIN / FMAX / compare (0 .. 3)
  parameter int INC_W       = 32,
  parameter bit EV_REG      = 1'b1,
  parameter int INSTR_PHASE = 3
) (
  input  wire logic                                  clk,
  input  wire logic                                  rst_n,
  // ---------------------------------------------------------------- vector array (Module 03 + obs port)
  input  wire logic                                  va_cmd_valid,
  input  wire logic                                  va_cmd_ready,
  input  wire logic                                  va_cpl_valid,
  input  wire logic                                  va_cpl_ready,
  input  wire logic                                  va_cpl_illegal,
  input  wire logic                                  va_cpl_red,
  input  wire logic [VL_W-1:0]                       va_cpl_count,
  input  wire logic                                  va_res_valid,
  input  wire logic                                  va_res_ready,
  input  wire logic                                  va_busy,
  input  wire logic [N-1:0]                          va_lane_accept,
  input  wire logic [N-1:0]                          va_lane_retire,
  input  wire logic [hpc_vector_pkg::OP_W-1:0]       va_lane_op,
  input  wire logic                                  va_stall_lane,
  input  wire logic                                  va_stall_trk,
  input  wire logic                                  va_opnd_starve,
  input  wire logic                                  va_cmdq_full,
  input  wire logic [CQ_W-1:0]                       va_cmdq_count,
  // ---------------------------------------------------------------- DMA adapter (Module 05)
  input  wire logic                                  dma_cmd_valid,
  input  wire logic                                  dma_cmd_ready,
  input  wire logic                                  dma_cpl_valid,
  input  wire logic                                  dma_cpl_ready,
  input  wire logic                                  dma_cpl_err,
  input  wire logic                                  dma_active,
  input  wire logic [7:0]                            dma_bytes_rd,
  input  wire logic [7:0]                            dma_bytes_wr,
  input  wire logic [7:0]                            dma_outstanding,
  input  wire logic                                  dma_bus_err,
  input  wire logic                                  dma_tag_err,
  // ---------------------------------------------------------------- scratchpad (Module 04), all ports
  input  wire logic [NSP-1:0]                        spm_req_valid,
  input  wire logic [NSP-1:0]                        spm_req_ready,
  input  wire logic [NSP-1:0]                        spm_req_we,
  input  wire logic [NSP-1:0]                        spm_conflict,     // ev_conflict
  input  wire logic [NSP-1:0]                        spm_dec_err,      // ev_error
  input  wire logic [NSP-1:0]                        spm_ecc_err,      // ev_ecc_err
  // ---------------------------------------------------------------- tile freeze / snapshot requests
  input  wire logic                                  freeze_i,
  input  wire logic                                  snap_i,
  // ---------------------------------------------------------------- to hpc_perf_counters
  output logic [`HPC_PERF_NUM_CNT*INC_W-1:0]         inc_o,
  output logic [`HPC_PERF_NUM_ERR-1:0]               err_o,
  output logic                                       freeze_o,
  output logic                                       snap_o
);
  localparam int NC = `HPC_PERF_NUM_CNT;
  localparam int NE = `HPC_PERF_NUM_ERR;

  if (FMA_FLOPS < 1 || FMA_FLOPS > 3 || CMP_FLOPS < 0 || CMP_FLOPS > 3) begin : g_bad_flops
    hpc_param_error_FMA_FLOPS_1_to_3_CMP_FLOPS_0_to_3 u_err ();
  end
  if (INC_W < VL_W + 2) begin : g_bad_incw
    hpc_param_error_INC_W_too_small_for_reduction_counts u_err ();
  end
  if (INSTR_PHASE < 1 || INSTR_PHASE > 3) begin : g_bad_phase
    hpc_param_error_INSTR_PHASE_must_be_1_2_or_3 u_err ();
  end

  function automatic logic [7:0] popcnt_n(input logic [N-1:0] v);
    popcnt_n = '0;
    for (int i = 0; i < N; i++) popcnt_n = popcnt_n + 8'(v[i]);
  endfunction
  function automatic logic [7:0] popcnt_p(input logic [NSP-1:0] v);
    popcnt_p = '0;
    for (int i = 0; i < NSP; i++) popcnt_p = popcnt_p + 8'(v[i]);
  endfunction
  // FLOP weight of an element operation (hpc_vector_pkg opcodes)
  function automatic logic [1:0] flop_w(input logic [hpc_vector_pkg::OP_W-1:0] op);
    case (op)
      hpc_vector_pkg::OP_FADD,  hpc_vector_pkg::OP_FSUB,
      hpc_vector_pkg::OP_FMUL:                              flop_w = 2'd1;
      hpc_vector_pkg::OP_FMADD, hpc_vector_pkg::OP_FMSUB,
      hpc_vector_pkg::OP_FNMSUB, hpc_vector_pkg::OP_FNMADD: flop_w = 2'(FMA_FLOPS);
      hpc_vector_pkg::OP_FMIN,  hpc_vector_pkg::OP_FMAX, hpc_vector_pkg::OP_FEQ,
      hpc_vector_pkg::OP_FLT,   hpc_vector_pkg::OP_FLE:     flop_w = 2'(CMP_FLOPS);
      default:                                              flop_w = 2'd0;   // FMV, IADD, IMUL
    endcase
  endfunction

  // ================================================================ handshakes
  wire logic va_cmd_hs = va_cmd_valid & va_cmd_ready;
  wire logic va_cpl_hs = va_cpl_valid & va_cpl_ready;
  wire logic dm_cmd_hs = dma_cmd_valid & dma_cmd_ready;
  wire logic dm_cpl_hs = dma_cpl_valid & dma_cpl_ready;

  // ================================================================ FLOP weights at retirement
  logic [N-1:0]   trk_err;
  logic [N*2-1:0] w_head;
  for (genvar l = 0; l < N; l++) begin : g_wt
    hpc_perf_wtrack #(.DEPTH(ROB_DEPTH), .W(2)) u_wt (
      .clk, .rst_n,
      .push_i (va_lane_accept[l]),
      .wdata_i(flop_w(va_lane_op)),
      .pop_i  (va_lane_retire[l]),
      .head_o (w_head[l*2 +: 2]),
      .err_o  (trk_err[l])
    );
  end
  logic [7:0] lane_flops;
  always_comb begin
    lane_flops = '0;
    for (int l = 0; l < N; l++) if (va_lane_retire[l]) lane_flops = lane_flops + 8'(w_head[l*2 +: 2]);
  end
  wire logic [VL_W-1:0] red_adds = (va_cpl_hs & va_cpl_red & ~va_cpl_illegal) ? va_cpl_count : '0;

  // ================================================================ commands in flight (accepted, not completed)
  logic [15:0] infl_q;
  wire  logic [17:0] infl_nx = {2'b0, infl_q} + 18'(va_cmd_hs) + 18'(dm_cmd_hs) - 18'(va_cpl_hs) - 18'(dm_cpl_hs);
  wire  logic        infl_err = infl_nx[17] | infl_nx[16];         // more completions than accepted (or > 65535 in flight)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)        infl_q <= '0;
    else if (infl_err) infl_q <= '0;
    else               infl_q <= infl_nx[15:0];
  end

  // ================================================================ error sources
  logic [NE-1:0] err_src;
  always_comb begin
    err_src = '0;
    err_src[`HPC_ERR_VEC_ILLEGAL]    = va_cpl_hs & va_cpl_illegal;
    err_src[`HPC_ERR_DMA_CPL_ERR]    = dm_cpl_hs & dma_cpl_err;
    err_src[`HPC_ERR_DMA_BUS_ERR]    = dma_bus_err;
    err_src[`HPC_ERR_DMA_TAG_ERR]    = dma_tag_err;
    err_src[`HPC_ERR_SPM_ECC_ERR]    = |spm_ecc_err;
    err_src[`HPC_ERR_SPM_DECODE_ERR] = |spm_dec_err;
    err_src[`HPC_ERR_PERF_TRACK_ERR] = (|trk_err) | infl_err;
  end
  wire logic [7:0] n_err = 8'(err_src[`HPC_ERR_VEC_ILLEGAL]) + 8'(err_src[`HPC_ERR_DMA_CPL_ERR]) +
                           8'(err_src[`HPC_ERR_DMA_BUS_ERR]) + 8'(err_src[`HPC_ERR_DMA_TAG_ERR]) +
                           popcnt_p(spm_ecc_err) + popcnt_p(spm_dec_err) + 8'(err_src[`HPC_ERR_PERF_TRACK_ERR]);

  // ================================================================ one-bit cycle events
  wire logic ev_vec_stall = va_stall_lane | va_stall_trk | va_opnd_starve;   // beat due, not released
  wire logic ev_cmdq_full = va_cmdq_full | (DMA_CMDQ & ~dma_cmd_ready);        // a command queue is full
  wire logic ev_out_bp    = (va_res_valid & ~va_res_ready) | (va_cpl_valid & ~va_cpl_ready) |
                            (dma_cpl_valid & ~dma_cpl_ready);                  // an output is not taken

  // ================================================================ increments of this cycle
  logic [NC*INC_W-1:0] inc;
  always_comb begin
    inc = '0;
    // ---- phase 1: cycle, vector-retirement, DMA-byte and stall counters
    inc[`HPC_PC_CYCLES        *INC_W +: INC_W] = INC_W'(1);
    inc[`HPC_PC_VEC_RETIRED   *INC_W +: INC_W] = INC_W'(popcnt_n(va_lane_retire));
    inc[`HPC_PC_FLOPS_RETIRED *INC_W +: INC_W] = INC_W'(lane_flops) + INC_W'(red_adds);
    inc[`HPC_PC_VEC_STALL     *INC_W +: INC_W] = INC_W'(ev_vec_stall);
    inc[`HPC_PC_DMA_BYTES_RD  *INC_W +: INC_W] = INC_W'(dma_bytes_rd);
    inc[`HPC_PC_DMA_BYTES_WR  *INC_W +: INC_W] = INC_W'(dma_bytes_wr);
    if (INSTR_PHASE >= 2) begin
      // ---- phase 2: the remaining mandatory counters
      inc[`HPC_PC_CMD_ACCEPTED  *INC_W +: INC_W] = INC_W'(va_cmd_hs) + INC_W'(dm_cmd_hs);
      inc[`HPC_PC_CMD_COMPLETED *INC_W +: INC_W] = INC_W'(va_cpl_hs) + INC_W'(dm_cpl_hs);
      inc[`HPC_PC_VEC_ISSUED    *INC_W +: INC_W] = INC_W'(popcnt_n(va_lane_accept));
      inc[`HPC_PC_DMA_ACTIVE    *INC_W +: INC_W] = INC_W'(dma_active);
      inc[`HPC_PC_SPM_READS     *INC_W +: INC_W] = INC_W'(popcnt_p(spm_req_valid & spm_req_ready & ~spm_req_we));
      inc[`HPC_PC_SPM_WRITES    *INC_W +: INC_W] = INC_W'(popcnt_p(spm_req_valid & spm_req_ready & spm_req_we));
      inc[`HPC_PC_SPM_CONFLICTS *INC_W +: INC_W] = INC_W'(popcnt_p(spm_conflict));
      inc[`HPC_PC_CMDQ_FULL     *INC_W +: INC_W] = INC_W'(ev_cmdq_full);
      inc[`HPC_PC_OUT_BP        *INC_W +: INC_W] = INC_W'(ev_out_bp);
      inc[`HPC_PC_HW_ERRORS     *INC_W +: INC_W] = INC_W'(n_err);
    end
    if (INSTR_PHASE >= 3) begin
      // ---- phase 3: extended counters (denominators, queue-occupancy statistics)
      inc[`HPC_PC_VEC_BUSY          *INC_W +: INC_W] = INC_W'(va_busy);
      inc[`HPC_PC_VEC_OPND_STARVE   *INC_W +: INC_W] = INC_W'(va_opnd_starve);
      inc[`HPC_PC_CMD_INFLIGHT_SUM  *INC_W +: INC_W] = INC_W'(infl_q);
      inc[`HPC_PC_VEC_CMDQ_OCC_SUM  *INC_W +: INC_W] = INC_W'(va_cmdq_count);
      inc[`HPC_PC_DMA_OUT_SUM       *INC_W +: INC_W] = INC_W'(dma_outstanding);
      inc[`HPC_PC_RED_ADDS          *INC_W +: INC_W] = INC_W'(red_adds);
      inc[`HPC_PC_VEC_CMD_COMPLETED *INC_W +: INC_W] = INC_W'(va_cpl_hs);
    end
  end

  // ================================================================ optional event register stage
  if (EV_REG) begin : g_reg
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        inc_o    <= '0;
        err_o    <= '0;
        freeze_o <= 1'b0;
        snap_o   <= 1'b0;
      end else begin
        inc_o    <= inc;
        err_o    <= err_src;
        freeze_o <= freeze_i;
        snap_o   <= snap_i;
      end
    end
  end else begin : g_comb
    assign inc_o    = inc;
    assign err_o    = err_src;
    assign freeze_o = freeze_i;
    assign snap_o   = snap_i;
  end
endmodule

`default_nettype wire
