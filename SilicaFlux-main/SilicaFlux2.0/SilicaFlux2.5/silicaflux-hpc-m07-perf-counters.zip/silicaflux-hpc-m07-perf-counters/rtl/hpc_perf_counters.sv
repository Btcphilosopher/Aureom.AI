// =============================================================================
// SilicaFlux-HPC Module 07 :: hpc_perf_counters -- hardware performance-counter bank
//
// NUM_CNT event counters, CNT_W bits each (default 64), behind a 32-bit
// register page of the SilicaFlux-V peripheral register bus (the protocol of
// DataFabric sfb_perf_counters / dma_control_regs).  Register map:
// docs/02_register_map.md, generated with rtl/hpc_perf_defs.svh from
// model/perfmap.py.  Behaviour, timing and every corner case:
// docs/01_architecture.md.  Event definitions belong to the tile binding
// (hpc_perf_events); this block only accumulates.
//
// Counting.  inc_i[i*INC_W +: INC_W] is the number of events of counter i in
// THIS cycle (0 .. 2^INC_W-1: several lanes / ports / bytes per cycle are
// added in one step, nothing is lost).  Counter i adds it at the end of the
// cycle iff  CTRL.ENABLE & CNT_EN[i] & !frozen,
//   frozen = CTRL.FREEZE | freeze_i | (CTRL.FREEZE_ON_OVF & |OVF).
// Overflow.  SAT[i] = 0 (default): the counter wraps modulo 2^CNT_W.
//   SAT[i] = 1: it saturates at 2^CNT_W - 1.  In BOTH modes the carry-out sets
//   the sticky OVF[i] (W1C) and can raise irq_o (OVF_IE): no overflow is ever
//   silent.  A wrapped value is the true count modulo 2^CNT_W; a saturated
//   value is a lower bound.
// Priority per counter and cycle: reset > CLEAR/CLR > PRE_LOAD > SAMPLE > count.
//   CLEAR, CLR and PRE_LOAD discard the counter's events of the write cycle
//   (house convention of Modules 03-05 and DFPERF); SAMPLE restarts the
//   counter FROM those events (lossless interval sampling).
// Snapshot (SNAP_EN).  CTRL.SNAPSHOT, CTRL.SAMPLE or the hardware input
//   snap_i copy every counter and OVF into the snapshot registers in the same
//   cycle: the copy is the state at the START of that cycle (all events of
//   earlier cycles, none of that cycle), for every counter at once.
// Latched readback.  A read of LIVE_LO[i] latches the high word of the same
//   cycle; the following LIVE_HI[i] returns it (coherent 64-bit pair).
// Reset: rst_n asynchronous assert (house rule: synchronous release outside).
//
// Coding rules: SilicaFlux RTL subset (Verilator 5.020 / Icarus 12 / Yosys
// 0.33): no import / return / inside / structs; flat vectors.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_perf_defs.svh"
`default_nettype none

module hpc_perf_counters #(
  parameter int          NUM_CNT    = `HPC_PERF_NUM_CNT,  // 1 .. 32
  parameter int          CNT_W      = 64,                 // 8 .. 64
  parameter int          INC_W      = 32,                 // 1 .. min(32, CNT_W): max events per cycle = 2^INC_W - 1
  parameter int          NUM_ERR    = `HPC_PERF_NUM_ERR,  // 1 .. 32 sticky error-source flags
  parameter bit          SNAP_EN    = 1'b1,               // snapshot registers (NUM_CNT x CNT_W flops)
  parameter bit          PRELOAD_EN = 1'b1,               // PRE_LO / PRE_HI / PRE_LOAD
  parameter bit          EN_RESET   = 1'b1,               // CTRL.ENABLE after reset (count from reset)
  parameter logic [31:0] SAT_RESET  = 32'h0,              // SAT after reset (0: every counter wraps)
  parameter int          PLATFORM   = 0,                  // INFO.PLATFORM: 0 sim, 1 FPGA, 2 ASIC, 3 other
  parameter logic [31:0] TILE_CFG   = 32'h0,              // TILECFG register (tile binding parameters)
  parameter int          CLK_KHZ    = 0,                  // CLK_KHZ register (build-configured nominal clock)
  parameter logic [31:0] BUILD_ID   = 32'h0               // BUILD_ID register
) (
  input  wire logic                       clk,
  input  wire logic                       rst_n,
  // ------------------------------------------------ register bus (one-cycle strobe, combinational answer)
  input  wire logic                       rb_sel,
  input  wire logic                       rb_we,
  input  wire logic [11:0]                rb_addr,
  input  wire logic [31:0]                rb_wdata,
  output logic      [31:0]                rb_rdata,
  output logic                            rb_err,
  // ------------------------------------------------ events (synchronous to clk)
  input  wire logic [NUM_CNT*INC_W-1:0]   inc_i,
  input  wire logic                       freeze_i,      // hardware freeze, effective in the same cycle
  input  wire logic                       snap_i,        // hardware snapshot trigger
  input  wire logic [NUM_ERR-1:0]         err_i,         // error-source pulses -> sticky ERR_SRC
  // ------------------------------------------------ status
  output logic                            irq_o,         // |(OVF & OVF_IE)
  output logic                            frozen_o,      // counting stopped this cycle by a freeze source
  output logic      [NUM_CNT*CNT_W-1:0]   cnt_o          // live counter values (debug / trace)
);
  localparam int NC = NUM_CNT;
  localparam logic [CNT_W-1:0] MAXV = {CNT_W{1'b1}};

  // --------------------------------------------------- elaboration checks
  if (NUM_CNT < 1 || NUM_CNT > 32) begin : g_bad_nc
    hpc_param_error_NUM_CNT_must_be_1_to_32 u_err ();
  end
  if (CNT_W < 8 || CNT_W > 64) begin : g_bad_cw
    hpc_param_error_CNT_W_must_be_8_to_64 u_err ();
  end
  if (INC_W < 1 || INC_W > 32 || INC_W > CNT_W) begin : g_bad_iw
    hpc_param_error_INC_W_must_be_1_to_min_32_CNT_W u_err ();
  end
  if (NUM_ERR < 1 || NUM_ERR > 32) begin : g_bad_ne
    hpc_param_error_NUM_ERR_must_be_1_to_32 u_err ();
  end
  if (PLATFORM < 0 || PLATFORM > 3) begin : g_bad_pf
    hpc_param_error_PLATFORM_must_be_0_to_3 u_err ();
  end

  // --------------------------------------------------- state
  logic [NC*CNT_W-1:0] cnt_q;                  // live counters
  logic [NC*CNT_W-1:0] snp_q;                  // snapshot registers (SNAP_EN)
  logic [NC-1:0]       cnt_en_q, sat_q, ovf_q, ovf_ie_q, snp_ovf_q;
  logic                ctl_en_q, ctl_frz_q, ctl_fov_q;
  logic [31:0]         pre_lo_q, pre_hi_q;
  logic [NUM_ERR-1:0]  err_q;
  logic [31:0]         lat_hi_q;
  logic [4:0]          lat_idx_q;
  logic                lat_v_q, lat_miss_q, snp_valid_q;
  logic [15:0]         snp_seq_q;

  // --------------------------------------------------- address decode
  wire logic        wr       = rb_sel & rb_we;
  wire logic        rd       = rb_sel & ~rb_we;
  wire logic [3:0]  a_page   = rb_addr[11:8];
  wire logic [4:0]  w_idx    = rb_addr[7:3];
  wire logic        w_hi     = rb_addr[2];
  wire logic        w_ok     = (rb_addr[1:0] == 2'b00) && (32'(w_idx) < NC);
  wire logic        in_snap  = (a_page == 4'(`HPC_PR_SNAP_BASE >> 8));
  wire logic        in_live  = (a_page == 4'(`HPC_PR_LIVE_BASE >> 8));
  wire logic        ctrl_cmd_snap = rb_wdata[`HPC_CTRL_SNAPSHOT] | rb_wdata[`HPC_CTRL_SAMPLE];

  // register-bus answer (combinational in the strobe cycle) and acceptance
  logic [CNT_W-1:0] cnt_arr [0:NC-1];          // unpacked views of the flat vectors, indexed by w_idx
  logic [CNT_W-1:0] snp_arr [0:NC-1];
  for (genvar i = 0; i < NC; i++) begin : g_view
    assign cnt_arr[i] = cnt_q[i*CNT_W +: CNT_W];
    assign snp_arr[i] = snp_q[i*CNT_W +: CNT_W];
  end
  localparam int IXW = (NC > 1) ? $clog2(NC) : 1;          // index width of the counter arrays
  wire logic [IXW-1:0]   a_idx    = IXW'(w_idx);             // in range whenever w_ok (w_idx < NC)
  wire logic [CNT_W-1:0] live_sel = (32'(w_idx) < NC) ? cnt_arr[a_idx] : '0;
  wire logic [CNT_W-1:0] snap_sel = (32'(w_idx) < NC) ? snp_arr[a_idx] : '0;

  // 64-bit zero-extended views (CNT_W <= 32: every high word is 0)
  wire logic [63:0] live64 = 64'(live_sel);
  wire logic [63:0] snap64 = 64'(snap_sel);

  wire logic lat_hit = lat_v_q && (lat_idx_q == w_idx);

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (rb_sel) begin
      case (rb_addr)
        `HPC_PR_ID:       begin rb_rdata = `HPC_PERF_ID;      rb_err = rb_we; end
        `HPC_PR_VERSION:  begin rb_rdata = `HPC_PERF_VERSION; rb_err = rb_we; end
        `HPC_PR_INFO:     begin
                            rb_rdata = {1'(PRELOAD_EN), 1'(SNAP_EN), 2'(PLATFORM), 6'(NUM_ERR), 6'(INC_W),
                                        8'(CNT_W), 8'(NC)};
                            rb_err = rb_we;
                          end
        `HPC_PR_TILECFG:  begin rb_rdata = TILE_CFG;          rb_err = rb_we; end
        `HPC_PR_CLK_KHZ:  begin rb_rdata = 32'(CLK_KHZ);      rb_err = rb_we; end
        `HPC_PR_BUILD_ID: begin rb_rdata = BUILD_ID;          rb_err = rb_we; end
        `HPC_PR_CTRL:     begin
                            rb_rdata = {29'd0, ctl_fov_q, ctl_frz_q, ctl_en_q};
                            rb_err   = rb_we && !SNAP_EN && ctrl_cmd_snap;   // refused write: no effect at all
                          end
        `HPC_PR_STATUS:   rb_rdata = {snp_seq_q, 10'd0, lat_miss_q, snp_valid_q, |ovf_q,
                                      ctl_fov_q & (|ovf_q), freeze_i, frozen_o};
        `HPC_PR_CNT_EN:   rb_rdata = 32'(cnt_en_q);
        `HPC_PR_SAT:      rb_rdata = 32'(sat_q);
        `HPC_PR_OVF:      rb_rdata = 32'(ovf_q);
        `HPC_PR_OVF_IE:   rb_rdata = 32'(ovf_ie_q);
        `HPC_PR_CLR:      rb_rdata = 32'd0;                                 // write-only
        `HPC_PR_SNAP_OVF: begin rb_rdata = SNAP_EN ? 32'(snp_ovf_q) : 32'd0; rb_err = rb_we || !SNAP_EN; end
        `HPC_PR_PRE_LO:   begin rb_rdata = PRELOAD_EN ? pre_lo_q : 32'd0;   rb_err = !PRELOAD_EN; end
        `HPC_PR_PRE_HI:   begin rb_rdata = PRELOAD_EN ? pre_hi_q : 32'd0;   rb_err = !PRELOAD_EN; end
        `HPC_PR_PRE_LOAD: begin rb_rdata = 32'd0;                           rb_err = !PRELOAD_EN; end
        `HPC_PR_ERR_SRC:  rb_rdata = 32'(err_q);
        `HPC_PR_LATCH:    begin rb_rdata = {23'd0, lat_v_q, 3'd0, lat_idx_q}; rb_err = rb_we; end
        default: begin
          if (in_snap && SNAP_EN && w_ok && !rb_we)
            rb_rdata = w_hi ? snap64[63:32] : snap64[31:0];
          else if (in_live && w_ok && !rb_we)
            rb_rdata = w_hi ? (lat_hit ? lat_hi_q : live64[63:32]) : live64[31:0];
          else
            rb_err = 1'b1;
        end
      endcase
    end
  end

  // accepted accesses only have side effects
  wire logic acc_wr = wr & ~rb_err;
  wire logic acc_rd = rd & ~rb_err;
  wire logic w_ctrl = acc_wr && (rb_addr == `HPC_PR_CTRL);
  wire logic c_clear  = w_ctrl & rb_wdata[`HPC_CTRL_CLEAR];
  wire logic c_sample = w_ctrl & rb_wdata[`HPC_CTRL_SAMPLE] & SNAP_EN;
  wire logic c_snap   = SNAP_EN & ((w_ctrl & (rb_wdata[`HPC_CTRL_SNAPSHOT] | rb_wdata[`HPC_CTRL_SAMPLE])) | snap_i);
  wire logic [NC-1:0] wmask   = rb_wdata[NC-1:0];
  wire logic [NC-1:0] clr_v   = {NC{c_clear}} | ((acc_wr && rb_addr == `HPC_PR_CLR) ? wmask : '0);
  wire logic [NC-1:0] pre_v   = (PRELOAD_EN && acc_wr && rb_addr == `HPC_PR_PRE_LOAD) ? wmask : '0;
  wire logic [NC-1:0] ovf_w1c = (acc_wr && rb_addr == `HPC_PR_OVF) ? wmask : '0;
  wire logic [63:0]   pre_val = {pre_hi_q, pre_lo_q};

  // --------------------------------------------------- counting condition
  assign frozen_o = ctl_frz_q | freeze_i | (ctl_fov_q & (|ovf_q));
  wire logic [NC-1:0] cnt_go = {NC{ctl_en_q & ~frozen_o}} & cnt_en_q;

  // --------------------------------------------------- counters
  for (genvar i = 0; i < NC; i++) begin : g_cnt
    wire logic [INC_W-1:0] inc   = cnt_go[i] ? inc_i[i*INC_W +: INC_W] : '0;
    wire logic [CNT_W:0]   sum   = {1'b0, cnt_q[i*CNT_W +: CNT_W]} + (CNT_W+1)'(inc);
    wire logic             carry = sum[CNT_W];
    wire logic [CNT_W-1:0] nxt   = (carry && sat_q[i]) ? MAXV : sum[CNT_W-1:0];
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        cnt_q[i*CNT_W +: CNT_W] <= '0;
        ovf_q[i]                <= 1'b0;
      end else if (clr_v[i]) begin
        cnt_q[i*CNT_W +: CNT_W] <= '0;
        ovf_q[i]                <= 1'b0;
      end else if (pre_v[i]) begin
        cnt_q[i*CNT_W +: CNT_W] <= CNT_W'(pre_val);
      end else if (c_sample) begin
        cnt_q[i*CNT_W +: CNT_W] <= CNT_W'(inc);
        ovf_q[i]                <= 1'b0;
      end else begin
        cnt_q[i*CNT_W +: CNT_W] <= nxt;
        ovf_q[i]                <= (ovf_q[i] & ~ovf_w1c[i]) | carry;   // a new overflow wins over W1C
      end
    end
  end
  assign cnt_o = cnt_q;

  // --------------------------------------------------- snapshot registers
  if (SNAP_EN) begin : g_snap
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        snp_q       <= '0;
        snp_ovf_q   <= '0;
        snp_seq_q   <= '0;
        snp_valid_q <= 1'b0;
      end else if (c_snap) begin
        snp_q       <= cnt_q;
        snp_ovf_q   <= ovf_q;
        snp_seq_q   <= snp_seq_q + 16'd1;
        snp_valid_q <= 1'b1;
      end
    end
  end else begin : g_nosnap
    assign snp_q       = '0;
    assign snp_ovf_q   = '0;
    assign snp_seq_q   = '0;
    assign snp_valid_q = 1'b0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_snap = ^{snap_i, c_snap, c_sample, snap_sel};
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // --------------------------------------------------- preload staging
  if (PRELOAD_EN) begin : g_pre
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        pre_lo_q <= '0;
        pre_hi_q <= '0;
      end else begin
        if (acc_wr && rb_addr == `HPC_PR_PRE_LO) pre_lo_q <= rb_wdata;
        if (acc_wr && rb_addr == `HPC_PR_PRE_HI) pre_hi_q <= rb_wdata;
      end
    end
  end else begin : g_nopre
    assign pre_lo_q = '0;
    assign pre_hi_q = '0;
  end

  // --------------------------------------------------- control / status registers
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ctl_en_q   <= EN_RESET;
      ctl_frz_q  <= 1'b0;
      ctl_fov_q  <= 1'b0;
      cnt_en_q   <= '1;
      sat_q      <= SAT_RESET[NC-1:0];
      ovf_ie_q   <= '0;
      err_q      <= '0;
      lat_hi_q   <= '0;
      lat_idx_q  <= '0;
      lat_v_q    <= 1'b0;
      lat_miss_q <= 1'b0;
    end else begin
      if (w_ctrl) begin
        ctl_en_q  <= rb_wdata[`HPC_CTRL_ENABLE];
        ctl_frz_q <= rb_wdata[`HPC_CTRL_FREEZE];
        ctl_fov_q <= rb_wdata[`HPC_CTRL_FREEZE_ON_OVF];
      end
      if (acc_wr && rb_addr == `HPC_PR_CNT_EN) cnt_en_q <= wmask;
      if (acc_wr && rb_addr == `HPC_PR_SAT)    sat_q    <= wmask;
      if (acc_wr && rb_addr == `HPC_PR_OVF_IE) ovf_ie_q <= wmask;
      err_q <= (err_q & ~((acc_wr && rb_addr == `HPC_PR_ERR_SRC) ? rb_wdata[NUM_ERR-1:0] : '0)) | err_i;
      // latched readback of live counters
      if (acc_rd && in_live && !w_hi) begin
        lat_hi_q  <= live64[63:32];
        lat_idx_q <= w_idx;
        lat_v_q   <= 1'b1;
      end else if (acc_rd && in_live && w_hi) begin
        lat_v_q   <= 1'b0;                                               // a latch is consumed by its HI read
      end
      if (acc_rd && in_live && w_hi && !lat_hit) lat_miss_q <= 1'b1;
      else if (acc_wr && rb_addr == `HPC_PR_STATUS && rb_wdata[`HPC_ST_LATCH_MISS]) lat_miss_q <= 1'b0;
    end
  end

  assign irq_o = |(ovf_q & ovf_ie_q);


`ifdef HPC_PERF_FORMAL
  // ===========================================================================================================
  // Formal properties (formal/run_formal.sh: yosys-smtbmc + z3, bounded model check + k-induction).
  // Never compiled for simulation or synthesis.  The previous cycle's facts are registered here explicitly.
  //   A1 no silent overflow   A2 exact wrap / saturate / hold arithmetic   A3 snapshot coherence
  //   A4 latched LO/HI pair coherence   A5 reset   A6 OVF sticky   A7 latch state = specification model
  // ===========================================================================================================
  logic                f_init = 1'b1;
  logic                f_pv = 1'b0, f_prst = 1'b1;
  logic [NC*CNT_W-1:0] f_cnt;
  logic [NC*INC_W-1:0] f_inc;
  logic [NC-1:0]       f_go, f_sat, f_ovf, f_clr, f_pre, f_w1c;
  logic                f_sample, f_snap;
  always @(posedge clk) begin
    f_init <= 1'b0;
    f_pv   <= rst_n;
    f_prst <= !rst_n;
    f_cnt  <= cnt_q;
    f_inc  <= inc_i;
    f_go   <= cnt_go;
    f_sat  <= sat_q;
    f_ovf  <= ovf_q;
    f_clr  <= clr_v;
    f_pre  <= pre_v;
    f_w1c  <= ovf_w1c;
    f_sample <= c_sample;
    f_snap   <= c_snap;
  end
  always @(*) if (f_init) assume (!rst_n);
  for (genvar i = 0; i < NC; i++) begin : g_fv
    wire logic [CNT_W:0] f_s     = {1'b0, f_cnt[i*CNT_W +: CNT_W]} + (CNT_W+1)'(f_go[i] ? f_inc[i*INC_W +: INC_W] : '0);
    wire logic           f_plain = !f_clr[i] && !f_pre[i] && !f_sample;
    always @(posedge clk) if (f_pv && rst_n) begin
      if (f_plain && f_s[CNT_W]) assert (ovf_q[i]);                                                   // A1
      if (f_plain) assert (cnt_q[i*CNT_W +: CNT_W] == ((f_s[CNT_W] && f_sat[i]) ? MAXV : f_s[CNT_W-1:0])); // A2
      if (f_snap) assert (snp_q[i*CNT_W +: CNT_W] == f_cnt[i*CNT_W +: CNT_W]);                        // A3
      if (f_ovf[i] && !f_w1c[i] && !f_clr[i] && !f_sample) assert (ovf_q[i]);                         // A6
    end
    // A4 latched readback, specification model: a LIVE_HI[i] read returns the high word captured by the most
    // recent LIVE_LO read if that read was of counter i (and no HI read consumed it since), else the live high word.
    wire logic [63:0] f_live64 = 64'(cnt_q[i*CNT_W +: CNT_W]);
    always @(*) if (f_pv && rst_n && rb_sel && !rb_we && rb_addr == 12'(`HPC_PR_LIVE_BASE + 8 * i + 4))
      assert (rb_rdata == ((f_lv && f_lidx == 5'(i)) ? f_lhi : f_live64[63:32]));                      // A4
  end
  // latch specification state (independent of the implementation's lat_* registers)
  logic        f_lv = 1'b0;
  logic [4:0]  f_lidx;
  logic [31:0] f_lhi;
  wire  logic [63:0] f_sel64 = 64'(live_sel);
  always @(posedge clk) begin
    if (!rst_n) f_lv <= 1'b0;
    else if (rb_sel && !rb_we && in_live && w_ok && !w_hi) begin f_lv <= 1'b1; f_lidx <= w_idx; f_lhi <= f_sel64[63:32]; end
    else if (rb_sel && !rb_we && in_live && w_ok && w_hi) f_lv <= 1'b0;
  end
  // A7 (strengthening invariant for k-induction): the implementation's latch registers equal the specification model
  always @(*) if (!f_init && rst_n) assert (lat_v_q == f_lv && (!f_lv || (lat_idx_q == f_lidx && lat_hi_q == f_lhi)));
  always @(posedge clk) if (!f_init && f_prst && rst_n) assert (cnt_q == '0 && ovf_q == '0);          // A5
`endif

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^{rb_wdata, pre_val};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
