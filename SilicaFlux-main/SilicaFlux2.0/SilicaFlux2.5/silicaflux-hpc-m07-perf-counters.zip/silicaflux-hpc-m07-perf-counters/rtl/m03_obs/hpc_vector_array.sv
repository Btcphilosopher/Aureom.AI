// =============================================================================
// SilicaFlux-HPC :: hpc_vector_array -- scalable parallel vector execution array
// [Module 07 copy: Module 03 file + additive observation port obs_*; see docs/patches/]
//
// Module 03.  NUM_LANES instances of the verified Module 02 lane
// (hpc_vector_lane, unmodified) behind an explicit vector issue controller,
// an in-order result collector, an optional ordered FP32 sum-reduction unit
// and optional performance counters.
//
//   cmd  --> [command queue] --> ISSUE --> lane 0 .. lane N-1 --> COLLECT --> res
//   opnd ---------------------->   |                               ^   |
//                                  +--> [beat-tracking queue] -----+   +--> REDUCE --> [cpl queue] --> cpl
//
// Interfaces (docs/ARRAY_INTERFACE.md)
//   cmd   valid/ready : op, rm, vl, vm, bcast, scalar, red, tid
//   opnd  valid/ready : one beat = N elements: a, b, c (per lane), mask
//   res   valid/ready : one beat = N element results + flags + mask, tid,
//                       beat index, last
//   cpl   valid/ready : one record per command, in command order: tid,
//                       OR-aggregated flags, illegal, active-element count,
//                       reduction result
//
// Element mapping: element e -> beat e / N, lane e % N.  A command of vector
// length vl uses exactly ceil(vl / N) operand beats and (elementwise) produces
// exactly ceil(vl / N) result beats; nothing is truncated, there is no
// maximum other than 2^VL_W - 1.
//
// Operand sourcing: per-lane operands supplied through the streaming opnd
// interface, optionally replaced by a broadcast scalar (cmd_bcast_i).  The
// array has no memory port, no SRAM gather and no cache-coherent interface.
//
// Interface timing: cmd_ready_o, opnd_ready_o and every res_* / cpl_* output
// are functions of registered state only (verified structurally,
// syn/structural_check.ys).
// =============================================================================
`default_nettype none

module hpc_vector_array #(
  parameter int NUM_LANES      = 2,     // 1, 2, 4, 8 or 16
  parameter int VL_W           = 16,    // vl range 0 .. 2^VL_W - 1
  parameter int TID_W          = 8,     // transaction-id width
  parameter int CMD_DEPTH      = 4,     // command queue entries
  parameter int TRK_DEPTH      = 8,     // beats in flight (issue -> collect)
  parameter int CPL_DEPTH      = 4,     // completion queue entries
  parameter bit RED_EN         = 1'b1,  // sum / dot-product reduction unit
  parameter int RED_LAT        = 3,     // reduction adder latency (>= 2)
  parameter bit PERF_EN        = 1'b1,  // performance counters
  parameter int PERF_CW        = 32,    // counter width
  // ------------------------------------------------ lane (Module 02) parameters
  parameter int LANE_ROB_DEPTH = 8,
  parameter int LAT_FADD       = 3,
  parameter int LAT_FMUL       = 3,
  parameter int LAT_FMA        = 4,
  parameter int LAT_MISC       = 1,
  parameter int LAT_IMUL       = 2,
  parameter bit EN_FCMP        = 1'b1,
  parameter bit EN_INT         = 1'b1
) (
  input  wire logic                                   clk_i,
  input  wire logic                                   rst_ni,
  // ---------------------------------------------------------------- command
  input  wire logic                                   cmd_valid_i,
  output logic                                        cmd_ready_o,
  input  wire logic [hpc_vector_pkg::OP_W-1:0]        cmd_op_i,
  input  wire logic [2:0]                             cmd_rm_i,
  input  wire logic [VL_W-1:0]                        cmd_vl_i,
  input  wire logic                                   cmd_vm_i,
  input  wire logic [hpc_varray_pkg::BC_W-1:0]        cmd_bcast_i,
  input  wire logic [31:0]                            cmd_scalar_i,
  input  wire logic                                   cmd_red_i,
  input  wire logic [TID_W-1:0]                       cmd_tid_i,
  // ---------------------------------------------------------------- operand beats
  input  wire logic                                   opnd_valid_i,
  output logic                                        opnd_ready_o,
  input  wire logic [NUM_LANES*32-1:0]                opnd_a_i,
  input  wire logic [NUM_LANES*32-1:0]                opnd_b_i,
  input  wire logic [NUM_LANES*32-1:0]                opnd_c_i,
  input  wire logic [NUM_LANES-1:0]                   opnd_mask_i,
  // ---------------------------------------------------------------- result beats
  output logic                                        res_valid_o,
  input  wire logic                                   res_ready_i,
  output logic [NUM_LANES*32-1:0]                     res_data_o,
  output logic [NUM_LANES*5-1:0]                      res_flags_o,
  output logic [NUM_LANES-1:0]                        res_mask_o,
  output logic [TID_W-1:0]                            res_tid_o,
  output logic [VL_W-1:0]                             res_beat_o,
  output logic                                        res_last_o,
  // ---------------------------------------------------------------- completion
  output logic                                        cpl_valid_o,
  input  wire logic                                   cpl_ready_i,
  output logic [TID_W-1:0]                            cpl_tid_o,
  output logic [4:0]                                  cpl_flags_o,
  output logic                                        cpl_illegal_o,
  output logic [VL_W-1:0]                             cpl_count_o,
  output logic                                        cpl_red_o,
  output logic [31:0]                                 cpl_result_o,
  // ---------------------------------------------------------------- control / status
  input  wire logic [NUM_LANES-1:0]                   lane_hold_i,
  output logic                                        busy_o,
  input  wire logic                                   perf_clear_i,
  output logic [hpc_varray_pkg::PC_N*PERF_CW-1:0]     perf_cnt_o,
  // ---------------------------------------------------------------- Module 07 observation port
  // Additive outputs only (no behavioural change, proven by syn/m03_obs_equiv.ys).  Every signal is a
  // same-cycle event already defined by Module 02 / Module 03:
  output logic [NUM_LANES-1:0]                        obs_lane_accept_o,  // lane ev_accept_o (M02 sec. 7b)
  output logic [NUM_LANES-1:0]                        obs_lane_retire_o,  // lane ev_retire_o (M02 sec. 7b)
  output logic [hpc_vector_pkg::OP_W-1:0]             obs_lane_op_o,      // operation offered to the lanes
  output logic                                        obs_stall_lane_o,   // M03 STALL_LANE event
  output logic                                        obs_stall_trk_o,    // M03 STALL_TRK event
  output logic                                        obs_opnd_starve_o,  // M03 OPND_STARVE event
  output logic                                        obs_cmdq_full_o,    // command queue full
  output logic [$clog2(CMD_DEPTH+1)-1:0]              obs_cmdq_count_o    // command queue occupancy
);
  localparam int N      = NUM_LANES;
  localparam int OPW    = hpc_vector_pkg::OP_W;
  localparam int LTAG_W = 4;                         // lane tag (beat seq, check only)
  localparam int LBS_W  = $clog2(CPL_DEPTH) + 1;     // last-beat sequence width
  localparam int PCW    = $clog2(N + 1);

  // --------------------------------------------------- elaboration checks
  if (!((N == 1) || (N == 2) || (N == 4) || (N == 8) || (N == 16))) begin : g_bad_n
    hpc_param_error_NUM_LANES_must_be_1_2_4_8_or_16 u_err ();
  end
  if (TID_W < 1) begin : g_bad_tid
    hpc_param_error_TID_W_below_1 u_err ();
  end
  if (TRK_DEPTH < 1 || CMD_DEPTH < 1 || CPL_DEPTH < 1) begin : g_bad_depth
    hpc_param_error_queue_depth_below_1 u_err ();
  end

  // ===================================================================
  // Issue controller
  // ===================================================================
  logic [N-1:0]      ln_valid, ln_ready, ln_en;
  logic [OPW-1:0]    ln_op;
  logic [2:0]        ln_rm;
  logic [N*32-1:0]   ln_a, ln_b, ln_c;
  logic [LTAG_W-1:0] ln_tag;

  logic              trk_push, trk_full, trk_empty, trk_pop;
  logic [N-1:0]      tw_act;
  logic              tw_last, tw_nobeat, tw_ill, tw_red;
  logic [2:0]        tw_rm;
  logic [TID_W-1:0]  tw_tid;
  logic [31:0]       tw_scalar;

  logic              iss_busy, ev_stall_lane, ev_stall_trk, ev_opnd_starve;
  logic [PCW-1:0]    ev_lane_stall, ev_elem_in;

  hpc_varray_issue #(
    .N(N), .VL_W(VL_W), .TID_W(TID_W), .CMD_DEPTH(CMD_DEPTH), .LTAG_W(LTAG_W),
    .EN_FCMP(EN_FCMP), .EN_INT(EN_INT), .RED_EN(RED_EN)
  ) u_issue (
    .clk_i, .rst_ni,
    .cmd_valid_i, .cmd_ready_o, .cmd_op_i, .cmd_rm_i, .cmd_vl_i, .cmd_vm_i,
    .cmd_bcast_i, .cmd_scalar_i, .cmd_red_i, .cmd_tid_i,
    .opnd_valid_i, .opnd_ready_o, .opnd_a_i, .opnd_b_i, .opnd_c_i, .opnd_mask_i,
    .lane_hold_i,
    .ln_valid_o(ln_valid), .ln_ready_i(ln_ready), .ln_op_o(ln_op), .ln_rm_o(ln_rm),
    .ln_a_o(ln_a), .ln_b_o(ln_b), .ln_c_o(ln_c), .ln_en_o(ln_en), .ln_tag_o(ln_tag),
    .trk_push_o(trk_push), .trk_full_i(trk_full),
    .trk_act_o(tw_act), .trk_last_o(tw_last), .trk_nobeat_o(tw_nobeat),
    .trk_ill_o(tw_ill), .trk_red_o(tw_red), .trk_rm_o(tw_rm), .trk_tid_o(tw_tid),
    .trk_scalar_o(tw_scalar),
    .busy_o(iss_busy), .ev_stall_lane_o(ev_stall_lane), .ev_stall_trk_o(ev_stall_trk),
    .ev_opnd_starve_o(ev_opnd_starve), .ev_lane_stall_o(ev_lane_stall),
    .ev_elem_o(ev_elem_in),
    .cq_full_o(obs_cmdq_full_o), .cq_count_o(obs_cmdq_count_o)
  );

  // ===================================================================
  // Beat-tracking queue (issue -> collect, in order)
  // ===================================================================
  localparam int TRKW = N + 7 + TID_W + 32;
  logic [TRKW-1:0] trk_head;

  hpc_varray_fifo #(.W(TRKW), .DEPTH(TRK_DEPTH)) u_trk (
    .clk_i, .rst_ni,
    .push_i (trk_push),
    .wdata_i({tw_scalar, tw_tid, tw_rm, tw_red, tw_ill, tw_nobeat, tw_last, tw_act}),
    .pop_i  (trk_pop),
    .rdata_o(trk_head),
    .empty_o(trk_empty),
    .full_o (trk_full),
    /* verilator lint_off PINCONNECTEMPTY */
    .count_o()
    /* verilator lint_on PINCONNECTEMPTY */
  );

  wire logic [N-1:0]     th_act    = trk_head[0 +: N];
  wire logic             th_last   = trk_head[N];
  wire logic             th_nobeat = trk_head[N+1];
  wire logic             th_ill    = trk_head[N+2];
  wire logic             th_red    = trk_head[N+3];
  wire logic [2:0]       th_rm     = trk_head[N+4 +: 3];
  wire logic [TID_W-1:0] th_tid    = trk_head[N+7 +: TID_W];
  wire logic [31:0]      th_scalar = trk_head[N+7+TID_W +: 32];

  // ===================================================================
  // Lanes (Module 02, unmodified)
  // ===================================================================
  logic [N-1:0]        lo_valid, lo_ready, lo_illegal, lane_busy;
  logic [N*32-1:0]     lo_result;
  logic [N*5-1:0]      lo_flags;
  logic [N*LTAG_W-1:0] lo_tag;

  for (genvar l = 0; l < N; l++) begin : g_lane
    /* verilator lint_off PINCONNECTEMPTY */
    hpc_vector_lane #(
      .DATA_W(32), .TAG_W(LTAG_W), .ROB_DEPTH(LANE_ROB_DEPTH),
      .LAT_FADD(LAT_FADD), .LAT_FMUL(LAT_FMUL), .LAT_FMA(LAT_FMA),
      .LAT_MISC(LAT_MISC), .LAT_IMUL(LAT_IMUL), .EN_FCMP(EN_FCMP), .EN_INT(EN_INT)
    ) u_lane (
      .clk_i, .rst_ni,
      .in_valid_i (ln_valid[l]),
      .in_ready_o (ln_ready[l]),
      .in_op_i    (ln_op),
      .in_a_i     (ln_a[l*32 +: 32]),
      .in_b_i     (ln_b[l*32 +: 32]),
      .in_c_i     (ln_c[l*32 +: 32]),
      .in_rm_i    (ln_rm),
      .in_tag_i   (ln_tag),
      .lane_en_i  (ln_en[l]),
      .out_valid_o  (lo_valid[l]),
      .out_ready_i  (lo_ready[l]),
      .out_result_o (lo_result[l*32 +: 32]),
      .out_flags_o  (lo_flags[l*5 +: 5]),
      .out_tag_o    (lo_tag[l*LTAG_W +: LTAG_W]),
      .out_illegal_o(lo_illegal[l]),
      .busy_o       (lane_busy[l]),
      .ev_accept_o(obs_lane_accept_o[l]), .ev_retire_o(obs_lane_retire_o[l]), .ev_pipe_stall_o(), .ev_backpressure_o(),
      .ev_illegal_o(), .ev_masked_o()
    );
    /* verilator lint_on PINCONNECTEMPTY */
  end

  // ===================================================================
  // Collector
  // ===================================================================
  logic             res_lastpend;
  logic [LBS_W-1:0] res_lbseq;
  logic             it_valid, it_ready, it_grp, it_first, it_last, it_ill, it_wait;
  logic [N*32-1:0]  it_vals;
  logic [N-1:0]     it_act;
  logic [4:0]       it_flags;
  logic [VL_W-1:0]  it_count;
  logic [2:0]       it_rm;
  logic [31:0]      it_init;
  logic [TID_W-1:0] it_tid;
  logic [LBS_W-1:0] it_lbseq;
  logic             ev_res_bp, ev_coll_wait, ev_red_wait;
  logic [PCW-1:0]   ev_elem_out;

  hpc_varray_collect #(
    .N(N), .VL_W(VL_W), .TID_W(TID_W), .LTAG_W(LTAG_W), .LBS_W(LBS_W)
  ) u_collect (
    .clk_i, .rst_ni,
    .trk_empty_i(trk_empty), .trk_pop_o(trk_pop),
    .trk_act_i(th_act), .trk_last_i(th_last), .trk_nobeat_i(th_nobeat),
    .trk_ill_i(th_ill), .trk_red_i(th_red), .trk_rm_i(th_rm), .trk_tid_i(th_tid),
    .trk_scalar_i(th_scalar),
    .ln_ovalid_i(lo_valid), .ln_oready_o(lo_ready), .ln_result_i(lo_result),
    .ln_flags_i(lo_flags), .ln_tag_i(lo_tag), .ln_illegal_i(lo_illegal),
    .res_valid_o, .res_ready_i, .res_data_o, .res_flags_o, .res_mask_o, .res_tid_o,
    .res_beat_o, .res_last_o, .res_lastpend_o(res_lastpend), .res_lbseq_o(res_lbseq),
    .it_valid_o(it_valid), .it_ready_i(it_ready), .it_grp_o(it_grp), .it_vals_o(it_vals),
    .it_act_o(it_act), .it_flags_o(it_flags), .it_count_o(it_count),
    .it_first_o(it_first), .it_last_o(it_last), .it_rm_o(it_rm), .it_init_o(it_init),
    .it_tid_o(it_tid), .it_ill_o(it_ill), .it_wait_o(it_wait), .it_lbseq_o(it_lbseq),
    .ev_res_bp_o(ev_res_bp), .ev_coll_wait_o(ev_coll_wait), .ev_red_wait_o(ev_red_wait),
    .ev_elem_o(ev_elem_out)
  );

  // ===================================================================
  // Reduction unit / in-order completion-token stage
  // ===================================================================
  logic             tk_valid, tk_ill, tk_red, tk_wait, red_busy;
  logic [TID_W-1:0] tk_tid;
  logic [4:0]       tk_flags;
  logic [VL_W-1:0]  tk_count;
  logic [31:0]      tk_result;
  logic [LBS_W-1:0] tk_lbseq;
  logic             cpl_pop;

  hpc_varray_reduce #(
    .N(N), .VL_W(VL_W), .TID_W(TID_W), .LBS_W(LBS_W), .RED_EN(RED_EN),
    .RLAT(RED_LAT), .CPL_DEPTH(CPL_DEPTH)
  ) u_reduce (
    .clk_i, .rst_ni,
    .it_valid_i(it_valid), .it_ready_o(it_ready), .it_grp_i(it_grp), .it_vals_i(it_vals),
    .it_act_i(it_act), .it_flags_i(it_flags), .it_count_i(it_count),
    .it_first_i(it_first), .it_last_i(it_last), .it_rm_i(it_rm), .it_init_i(it_init),
    .it_tid_i(it_tid), .it_ill_i(it_ill), .it_wait_i(it_wait), .it_lbseq_i(it_lbseq),
    .tk_valid_o(tk_valid), .tk_tid_o(tk_tid), .tk_flags_o(tk_flags), .tk_count_o(tk_count),
    .tk_ill_o(tk_ill), .tk_red_o(tk_red), .tk_result_o(tk_result), .tk_wait_o(tk_wait),
    .tk_lbseq_o(tk_lbseq),
    .cpl_pop_i(cpl_pop), .busy_o(red_busy)
  );

  // ===================================================================
  // Completion queue and output gating
  //   A completion record is presented only after the last result beat of
  //   its command has been handed over: a record whose command still has its
  //   last beat in the result register (same last-beat sequence number) is
  //   held back.  Once presented, a record stays valid until taken.
  // ===================================================================
  localparam int CPLW = LBS_W + 1 + 32 + 1 + 1 + VL_W + 5 + TID_W;
  logic [CPLW-1:0] cq_head;
  logic            cq_empty;

  hpc_varray_fifo #(.W(CPLW), .DEPTH(CPL_DEPTH)) u_cplq (
    .clk_i, .rst_ni,
    .push_i (tk_valid),
    .wdata_i({tk_lbseq, tk_wait, tk_result, tk_red, tk_ill, tk_count, tk_flags, tk_tid}),
    .pop_i  (cpl_pop),
    .rdata_o(cq_head),
    .empty_o(cq_empty),
    /* verilator lint_off PINCONNECTEMPTY */
    .full_o (),
    .count_o()
    /* verilator lint_on PINCONNECTEMPTY */
  );

  wire logic [TID_W-1:0] ch_tid    = cq_head[0 +: TID_W];
  wire logic [4:0]       ch_flags  = cq_head[TID_W +: 5];
  wire logic [VL_W-1:0]  ch_count  = cq_head[TID_W+5 +: VL_W];
  wire logic             ch_ill    = cq_head[TID_W+5+VL_W];
  wire logic             ch_red    = cq_head[TID_W+6+VL_W];
  wire logic [31:0]      ch_result = cq_head[TID_W+7+VL_W +: 32];
  wire logic             ch_wait   = cq_head[TID_W+39+VL_W];
  wire logic [LBS_W-1:0] ch_lbseq  = cq_head[TID_W+40+VL_W +: LBS_W];

  wire logic cpl_block = ch_wait & res_lastpend & (res_lbseq == ch_lbseq);
  assign cpl_valid_o   = ~cq_empty & ~cpl_block;
  assign cpl_pop       = cpl_valid_o & cpl_ready_i;
  assign cpl_tid_o     = cpl_valid_o ? ch_tid    : '0;
  assign cpl_flags_o   = cpl_valid_o ? ch_flags  : '0;
  assign cpl_illegal_o = cpl_valid_o & ch_ill;
  assign cpl_count_o   = cpl_valid_o ? ch_count  : '0;
  assign cpl_red_o     = cpl_valid_o & ch_red;
  assign cpl_result_o  = cpl_valid_o ? ch_result : '0;

  // ===================================================================
  // Status and performance counters
  // ===================================================================
  assign busy_o = iss_busy | ~trk_empty | (|lane_busy) | res_valid_o | red_busy | ~cq_empty;

  // Module 07 observation port
  assign obs_lane_op_o     = ln_op;
  assign obs_stall_lane_o  = ev_stall_lane;
  assign obs_stall_trk_o   = ev_stall_trk;
  assign obs_opnd_starve_o = ev_opnd_starve;

  if (PERF_EN) begin : g_perf
    hpc_varray_perf #(.N(N), .CW(PERF_CW)) u_perf (
      .clk_i, .rst_ni,
      .clear_i         (perf_clear_i),
      .ev_busy_i       (busy_o),
      .ev_cmd_in_i     (cmd_valid_i & cmd_ready_o),
      .ev_cmd_done_i   (cpl_valid_o & cpl_ready_i),
      .ev_beat_in_i    (opnd_valid_i & opnd_ready_o),
      .ev_beat_out_i   (res_valid_o & res_ready_i),
      .ev_elem_in_i    (ev_elem_in),
      .ev_elem_out_i   (ev_elem_out),
      .ev_stall_lane_i (ev_stall_lane),
      .ev_stall_trk_i  (ev_stall_trk),
      .ev_lane_stall_i (ev_lane_stall),
      .ev_opnd_starve_i(ev_opnd_starve),
      .ev_res_bp_i     (ev_res_bp),
      .ev_coll_wait_i  (ev_coll_wait),
      .ev_red_wait_i   (ev_red_wait),
      .ev_cpl_bp_i     (cpl_valid_o & ~cpl_ready_i),
      .perf_cnt_o
    );
  end else begin : g_noperf
    assign perf_cnt_o = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_perf = ^{perf_clear_i, ev_stall_lane, ev_stall_trk, ev_lane_stall,
                         ev_opnd_starve, ev_res_bp, ev_coll_wait, ev_red_wait,
                         ev_elem_in, ev_elem_out};
    /* verilator lint_on UNUSEDSIGNAL */
  end
endmodule
