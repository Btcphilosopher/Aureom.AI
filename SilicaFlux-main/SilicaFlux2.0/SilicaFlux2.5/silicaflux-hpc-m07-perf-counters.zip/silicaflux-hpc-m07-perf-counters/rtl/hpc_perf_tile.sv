// =============================================================================
// SilicaFlux-HPC Module 07 :: hpc_perf_tile -- telemetry unit of the SilicaFlux-HPC tile
//
//   tile handshakes / ev_* pulses --> hpc_perf_events --(inc, err, freeze, snap)--> hpc_perf_counters --> rb_*
//
// One register page (docs/02_register_map.md) on the SilicaFlux-V peripheral
// register bus.  Single clock domain: every event source (Modules 03, 04, 05)
// runs on the tile clock `clk` (docs/04_clock_domains.md); events from another
// clock domain must enter through hpc_perf_cdc_count, never directly.
// TILECFG publishes the binding parameters the host needs to interpret the
// counters (lanes, ports, bytes per beat, FLOP convention).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_perf_defs.svh"
`default_nettype none

module hpc_perf_tile #(
  // ------------------------------------------------ tile binding
  parameter int          N           = 4,
  parameter int          VL_W        = 16,
  parameter int          ROB_DEPTH   = 8,
  parameter int          CQ_W        = 3,
  parameter int          NSP         = 2,
  parameter int          DMA_NP      = 1,          // DMA adapter ports (TILECFG only)
  parameter int          DMA_BEAT_B  = 4,          // bytes per DMA beat (TILECFG only)
  parameter bit          DMA_CMDQ    = 1'b1,
  parameter int          FMA_FLOPS   = 2,
  parameter int          CMP_FLOPS   = 0,
  parameter bit          EV_REG      = 1'b1,
  parameter int          INSTR_PHASE = 3,
  // ------------------------------------------------ counter bank
  parameter int          CNT_W       = 64,
  parameter int          INC_W       = 32,
  parameter bit          SNAP_EN     = 1'b1,
  parameter bit          PRELOAD_EN  = 1'b1,
  parameter bit          EN_RESET    = 1'b1,
  parameter logic [31:0] SAT_RESET   = 32'h0,
  parameter int          PLATFORM    = 0,
  parameter int          CLK_KHZ     = 0,
  parameter logic [31:0] BUILD_ID    = 32'h0
) (
  input  wire logic                                  clk,
  input  wire logic                                  rst_n,
  // register bus
  input  wire logic                                  rb_sel,
  input  wire logic                                  rb_we,
  input  wire logic [11:0]                           rb_addr,
  input  wire logic [31:0]                           rb_wdata,
  output logic      [31:0]                           rb_rdata,
  output logic                                       rb_err,
  // vector array (Module 03 + obs port)
  input  wire logic                                  va_cmd_valid,
  input  wire logic                                  va_cmd_ready,
  input  wire logic                                  va_cpl_valid,
  input  wire logic                                  va_cpl_ready,
  input  wire logic                                  va_cpl_illegal,
  input  wire logic                                  va_cpl_red,
  input  wire logic [VL_W-1:0]                       va_cpl_count,
  input  wire logic                                  va_res_valid,
  input  wire logic                                  va_res_ready,
  input  wire logic                                  va_busy,
  input  wire logic [N-1:0]                          va_lane_accept,
  input  wire logic [N-1:0]                          va_lane_retire,
  input  wire logic [hpc_vector_pkg::OP_W-1:0]       va_lane_op,
  input  wire logic                                  va_stall_lane,
  input  wire logic                                  va_stall_trk,
  input  wire logic                                  va_opnd_starve,
  input  wire logic                                  va_cmdq_full,
  input  wire logic [CQ_W-1:0]                       va_cmdq_count,
  // DMA adapter (Module 05)
  input  wire logic                                  dma_cmd_valid,
  input  wire logic                                  dma_cmd_ready,
  input  wire logic                                  dma_cpl_valid,
  input  wire logic                                  dma_cpl_ready,
  input  wire logic                                  dma_cpl_err,
  input  wire logic                                  dma_active,
  input  wire logic [7:0]                            dma_bytes_rd,
  input  wire logic [7:0]                            dma_bytes_wr,
  input  wire logic [7:0]                            dma_outstanding,
  input  wire logic                                  dma_bus_err,
  input  wire logic                                  dma_tag_err,
  // scratchpad (Module 04)
  input  wire logic [NSP-1:0]                        spm_req_valid,
  input  wire logic [NSP-1:0]                        spm_req_ready,
  input  wire logic [NSP-1:0]                        spm_req_we,
  input  wire logic [NSP-1:0]                        spm_conflict,
  input  wire logic [NSP-1:0]                        spm_dec_err,
  input  wire logic [NSP-1:0]                        spm_ecc_err,
  // control / status
  input  wire logic                                  freeze_i,     // e.g. debug halt
  input  wire logic                                  snap_i,       // e.g. end-of-kernel marker
  output logic                                       irq_o,
  output logic                                       frozen_o,
  output logic [`HPC_PERF_NUM_CNT*CNT_W-1:0]         cnt_o
);
  localparam logic [31:0] TILE_CFG = {1'b0, 2'(INSTR_PHASE), 1'(EV_REG), 2'(CMP_FLOPS), 2'(FMA_FLOPS), 8'(DMA_BEAT_B),
                                      4'(DMA_NP), 4'(NSP), 8'(N)};

  logic [`HPC_PERF_NUM_CNT*INC_W-1:0] inc;
  logic [`HPC_PERF_NUM_ERR-1:0]       err;
  logic                               frz, snp;

  hpc_perf_events #(
    .N(N), .VL_W(VL_W), .ROB_DEPTH(ROB_DEPTH), .CQ_W(CQ_W), .NSP(NSP), .DMA_CMDQ(DMA_CMDQ),
    .FMA_FLOPS(FMA_FLOPS), .CMP_FLOPS(CMP_FLOPS), .INC_W(INC_W), .EV_REG(EV_REG), .INSTR_PHASE(INSTR_PHASE)
  ) u_ev (
    .clk, .rst_n,
    .va_cmd_valid, .va_cmd_ready, .va_cpl_valid, .va_cpl_ready, .va_cpl_illegal, .va_cpl_red, .va_cpl_count,
    .va_res_valid, .va_res_ready, .va_busy, .va_lane_accept, .va_lane_retire, .va_lane_op,
    .va_stall_lane, .va_stall_trk, .va_opnd_starve, .va_cmdq_full, .va_cmdq_count,
    .dma_cmd_valid, .dma_cmd_ready, .dma_cpl_valid, .dma_cpl_ready, .dma_cpl_err, .dma_active,
    .dma_bytes_rd, .dma_bytes_wr, .dma_outstanding, .dma_bus_err, .dma_tag_err,
    .spm_req_valid, .spm_req_ready, .spm_req_we, .spm_conflict, .spm_dec_err, .spm_ecc_err,
    .freeze_i, .snap_i,
    .inc_o(inc), .err_o(err), .freeze_o(frz), .snap_o(snp)
  );

  hpc_perf_counters #(
    .NUM_CNT(`HPC_PERF_NUM_CNT), .CNT_W(CNT_W), .INC_W(INC_W), .NUM_ERR(`HPC_PERF_NUM_ERR), .SNAP_EN(SNAP_EN),
    .PRELOAD_EN(PRELOAD_EN), .EN_RESET(EN_RESET), .SAT_RESET(SAT_RESET), .PLATFORM(PLATFORM), .TILE_CFG(TILE_CFG),
    .CLK_KHZ(CLK_KHZ), .BUILD_ID(BUILD_ID)
  ) u_cnt (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .inc_i(inc), .freeze_i(frz), .snap_i(snp), .err_i(err), .irq_o, .frozen_o, .cnt_o
  );
endmodule

`default_nettype wire
