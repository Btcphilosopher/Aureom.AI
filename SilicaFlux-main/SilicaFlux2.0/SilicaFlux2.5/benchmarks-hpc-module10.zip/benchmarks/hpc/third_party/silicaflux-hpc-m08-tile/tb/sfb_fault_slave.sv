// =============================================================================
// SilicaFlux-HPC Module 08 :: sfb_fault_slave  (VERIFICATION ONLY)
// SFB2 slave memory model with fault and timing injection, used as a second
// "host-visible" memory in the tile integration testbench.
//   * memory of DEPTH DW-bit words, byte strobes, no side effect on errors (R8)
//   * req_ready randomly low with probability stall_pct % (R3: may depend on req_valid)
//   * response after a random latency of 1 .. lat_max cycles (R5: never in the accept cycle)
//   * response held until rsp_ready (R4); one transaction at a time (crossbar slave port, R6)
//   * byte addresses in [err_lo, err_hi) answer rsp_error = 1 with rdata 0 (R8);
//     a failing write has no effect
// Knobs are inputs so the testbench program can change them at run time.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfb_fault_slave #(
  parameter int DW    = 32,
  parameter int DEPTH = 4096,
  localparam int SB   = DW / 8,
  localparam int OFF  = $clog2(SB),
  localparam int AW   = $clog2(DEPTH)
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          req_valid,
  output logic               req_ready,
  input  wire logic          req_write,
  input  wire logic [31:0]   req_addr,
  input  wire logic [DW-1:0] req_wdata,
  input  wire logic [SB-1:0] req_wstrb,
  output logic               rsp_valid,
  input  wire logic          rsp_ready,
  output logic [DW-1:0]      rsp_rdata,
  output logic               rsp_error,
  // run-time knobs
  input  wire int            stall_pct,
  input  wire int            lat_max,
  input  wire logic [31:0]   err_lo,
  input  wire logic [31:0]   err_hi
);
  logic [DW-1:0] mem [DEPTH];
  logic          busy_q, rsp_v_q, stall_q;
  int            wait_q;
  logic [DW-1:0] rdata_q;
  logic          err_q;

  assign req_ready = !busy_q && !stall_q;
  assign rsp_valid = rsp_v_q;
  assign rsp_rdata = rsp_v_q ? rdata_q : '0;
  assign rsp_error = rsp_v_q && err_q;

  wire [AW-1:0] widx = req_addr[OFF +: AW];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy_q <= 1'b0; rsp_v_q <= 1'b0; stall_q <= 1'b0; wait_q <= 0; err_q <= 1'b0; rdata_q <= '0;
    end else begin
      stall_q <= ($urandom_range(99) < stall_pct);
      if (req_valid && req_ready) begin
        busy_q <= 1'b1;
        wait_q <= (lat_max > 1) ? $urandom_range(lat_max - 1) : 0;
        err_q  <= (req_addr >= err_lo) && (req_addr < err_hi);
        if (req_write) begin
          rdata_q <= '0;
          if (!((req_addr >= err_lo) && (req_addr < err_hi)))
            for (int i = 0; i < SB; i++) if (req_wstrb[i]) mem[widx][i*8 +: 8] <= req_wdata[i*8 +: 8];
        end else begin
          rdata_q <= ((req_addr >= err_lo) && (req_addr < err_hi)) ? '0 : mem[widx];
        end
      end else if (busy_q && !rsp_v_q) begin
        if (wait_q == 0) rsp_v_q <= 1'b1;
        else wait_q <= wait_q - 1;
      end else if (rsp_v_q && rsp_ready) begin
        rsp_v_q <= 1'b0;
        busy_q  <= 1'b0;
      end
    end
  end
endmodule

`default_nettype wire
