// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_norm.sv -- STEP 6: normalisation
//
// 1. Leading-zero count of the 75-bit magnitude and a left shift that moves
//    the leading one to bit 74. Its biased exponent is e_norm = X0 - lzc.
// 2. Exponent range classification of e_norm (everything that depends only
//    on the exponent, so step 7 can start directly with the shift):
//      subn    e_norm < 1  -> result below 2^-126 before rounding; its LSB
//              must sit at 2^-149, i.e. a right shift by 1 - e_norm
//              (saturated at 26: beyond that every bit is sticky) and an
//              exponent field of 1 (0 after packing unless rounding carries
//              into the hidden bit)
//      e_lt0 / e_eq0   inputs of the tininess-after-rounding test
//      e_ge255         overflow whatever the rounding
//      e_eq254         overflow iff the rounding increment carries out
// The full normalisation (then denormalisation) is kept because step 7 needs
// the fully normalised significand to detect tininess after rounding.
// =============================================================================
`default_nettype none

module fp32_fma_norm (
  input  wire logic [74:0] mag,
  input  wire logic [11:0] x0,       // signed
  output logic      [74:0] mn,
  output logic      [7:0]  e_pk,
  output logic      [4:0]  dsh,
  output logic             subn,
  output logic             e_lt0,
  output logic             e_eq0,
  output logic             e_ge255,
  output logic             e_eq254,
  output logic             zero
);
  logic [6:0]         lz;
  logic signed [11:0] e_norm, dsh_full;

  fp32_fma_lzc #(.W(75), .CW(7)) u_lzc (.x(mag), .cnt(lz), .zero(zero));

  assign mn       = mag << lz;
  assign e_norm   = $signed(x0) - $signed({5'd0, lz});
  assign dsh_full = 12'sd1 - e_norm;

  assign subn    = (e_norm < 12'sd1);
  assign e_lt0   = (e_norm < 12'sd0);
  assign e_eq0   = (e_norm == 12'sd0);
  assign e_ge255 = (e_norm >= 12'sd255);
  assign e_eq254 = (e_norm == 12'sd254);
  assign e_pk    = subn ? 8'd1 : e_norm[7:0];

  always_comb begin
    if (!subn)                    dsh = 5'd0;
    else if (dsh_full > 12'sd26)  dsh = 5'd26;        // DSH_MAX
    else                          dsh = dsh_full[4:0];
  end
endmodule

`default_nettype wire
