# SilicaFlux-V + DataFabric memory map

Generated from `soc/memmap/silicaflux_v_hpc.yaml` by `python/datafabric/memmap_gen.py` -- edit the YAML, not this file.  Little-endian, 32-bit byte addresses.  Unlisted addresses are **unmapped and return a bus error** (never aliased to SRAM).

## Regions (crossbar slave ports)

| # | Region | Base | Size | End | Access | Slave | New | Note |
|---|---|---|---|---|---|---|---|---|
| 0 | BOOT_ROM | `0x00000000` | 4 KiB | `0x00000FFF` | rx | ROM |  | 4 KiB decode window (sfv_soc f_mask = ~(ROM_BYTES-1)); writes -> bus error from the ROM |
| 1 | SRAM_BANK0 | `0x10000000` | 32 KiB | `0x10007FFF` | rwx | SRAM0 |  |  |
| 2 | SRAM_BANK1 | `0x10008000` | 32 KiB | `0x1000FFFF` | rwx | SRAM1 |  |  |
| 3 | SRAM_BANK2 | `0x10010000` | 32 KiB | `0x10017FFF` | rwx | SRAM2 |  |  |
| 4 | SRAM_BANK3 | `0x10018000` | 32 KiB | `0x1001FFFF` | rwx | SRAM3 |  |  |
| 5 | TSPM | `0x20000000` | 16 KiB | `0x20003FFF` | rwx | TSPM |  | tile scratchpad, 4-way word-interleaved banks (sfv_tile) |
| 6 | HPC_SPM | `0x60000000` | 64 KiB | `0x6000FFFF` | rw | HSPM | yes | SilicaFlux-HPC tile scratchpad (host window; the tile DMA reaches it internally) |
| 7 | PERIPH | `0x40000000` | 128 KiB | `0x4001FFFF` | rw | PERIPH |  | register bus behind sfv_periph_bridge, 32 pages of 4 KiB, word access only |

## Peripheral pages (4 KiB each, inside PERIPH)

| Page | Index | Base | New | Register block |
|---|---|---|---|---|
| SYSCTRL | 0 | `0x40000000` |  |  |
| INTC | 1 | `0x40001000` |  |  |
| TIMER | 2 | `0x40002000` |  |  |
| UART | 3 | `0x40003000` |  |  |
| SPI | 4 | `0x40004000` |  |  |
| GPIO | 5 | `0x40005000` |  |  |
| DMA | 6 | `0x40006000` | yes | dma |
| DFPERF | 7 | `0x40007000` | yes | dfperf |
| HPC | 8 | `0x40008000` | yes |  |
| VE | 16 | `0x40010000` |  |  |
| TE | 17 | `0x40011000` |  |  |

## Bus masters and access matrix

| Master | Index | Denied regions (decode error) | Note |
|---|---|---|---|
| DBG | 0 | - | JTAG system-bus access |
| CPUD | 1 | - | CPU data port |
| CPUI | 2 | PERIPH | CPU instruction port; execute-never peripherals |
| DMA | 3 | PERIPH | DataFabric DMA; MMIO side effects not reviewed -> no peripheral access |
| HPC | 4 | PERIPH, HPC_SPM | SilicaFlux-HPC tile DMA; scratchpad window routed inside the tile; no peripheral access |

## Interrupt sources (INTC)

| Source | Index | New |
|---|---|---|
| UART | 0 |  |
| SPI | 1 |  |
| GPIO | 2 |  |
| VE | 3 |  |
| TE | 4 |  |
| MBIST | 5 |  |
| BUSERR | 6 |  |
| DBG | 7 |  |
| DMA | 8 | yes |
| HPC | 9 | yes |

## Register block `dma` (page DMA, `0x40006000`)

| Offset | Register | Access | Reset | Fields / description |
|---|---|---|---|---|
| 0x000 | CONTROL | wo | 0x0 | [0] START (w1s): Start the configured transfer. Refused (bus error, no effect) while BUSY.; [1] ABORT (w1s): Stop at the next beat boundary; outstanding transaction completes. No effect when idle. |
| 0x004 | STATUS | ro | 0x0 | [0] BUSY (ro): Transfer in progress.; [1] DONE (ro): Last transfer completed; cleared by START.; [2] ERROR (ro): Last transfer ended with an error (see ERROR_CODE); cleared by START.; [3] ABORTED (ro): Last transfer was aborted.; [10:8] STATE (ro): Engine FSM state (debug). |
| 0x008 | SRC_ADDR | rw | 0x0 | Source byte address (DW-aligned). Write refused while BUSY. |
| 0x00C | DST_ADDR | rw | 0x0 | Destination byte address (DW-aligned). Write refused while BUSY. |
| 0x010 | LENGTH | rw | 0x0 | Transfer length in bytes (1 .. 2^MAX_LEN_LOG2). Write refused while BUSY. |
| 0x014 | BYTES_DONE | ro | 0x0 | Bytes written and acknowledged (contiguous prefix). |
| 0x018 | INT_ENABLE | rw | 0x0 | [0] DONE (rw): Completion interrupt enable.; [1] ERROR (rw): Error interrupt enable. |
| 0x01C | INT_STATUS | rw | 0x0 | [0] DONE (w1c): Completion pending (write 1 to clear).; [1] ERROR (w1c): Error pending (write 1 to clear). |
| 0x020 | ERROR_CODE | ro | 0x0 | Cause of the last error (enum dma_error). |
| 0x024 | ERROR_ADDR | ro | 0x0 | Bus address of the failing access (bus errors). |
| 0x028 | INFO | ro | 0x0 | [7:0] DW_BYTES (ro): Data width in bytes.; [8] BUFFERED (ro): 1 = buffered/burst engine.; [15:12] FIFO_LOG2 (ro): log2 FIFO depth (buffered engine).; [23:16] MAX_LEN_LOG2 (ro): log2 of the maximum transfer length.; [31:24] VERSION (ro): Register-map version (1). |
| 0x02C | ID | ro | 0x53464446 | Identification 'SFDF'. |
| 0x030 | ACTIVE_CYCLES | ro | 0x0 | Cycles BUSY during the current/last transfer (PERF build; wraps). |
| 0x034 | STALL_CYCLES | ro | 0x0 | Cycles a DMA request waited for acceptance (PERF build; wraps). |
| 0x038 | TRANSFERS | ro | 0x0 | Completed transfers since reset (PERF build; wraps). |

`dma.error` values: 0 = NONE, 1 = ZERO_LENGTH, 2 = LENGTH, 3 = SRC_ALIGN, 4 = DST_ALIGN, 5 = SRC_OVERFLOW, 6 = DST_OVERFLOW, 7 = OVERLAP, 8 = READ_BUS, 9 = WRITE_BUS, 10 = ABORTED

`dma.state` values: 0 = IDLE, 1 = VALIDATE, 2 = ISSUE_READ, 3 = WAIT_READ, 4 = ISSUE_WRITE, 5 = WAIT_WRITE, 6 = COMPLETE, 7 = ERROR

## Register block `dfperf` (page DFPERF, `0x40007000`)

| Offset | Register | Access | Reset | Fields / description |
|---|---|---|---|---|
| 0x000 | CTRL | rw | 0x1 | [0] ENABLE (rw): Counting enabled.; [1] CLEAR (w1s): Zero all live counters (self-clearing).; [2] SNAPSHOT (w1s): Copy all live counters to the read registers in one cycle (atomic). |
| 0x004 | INFO | ro | 0x0 | [7:0] MASTERS (ro): Number of crossbar masters counted.; [15:8] WIDTH (ro): Event counter width (saturating). |
| 0x008 | CYCLES_LO | ro | 0x0 | Snapshot of the 64-bit cycle counter, low word. |
| 0x00C | CYCLES_HI | ro | 0x0 | Snapshot of the 64-bit cycle counter, high word. |
| 0x010 | DMA_BYTES | ro | 0x0 | Bytes moved by completed DMA transfers. |
| 0x014 | DMA_BUSY | ro | 0x0 | Cycles the DMA was busy. |
| 0x018 | DMA_IDLE | ro | 0x0 | Cycles the DMA was idle. |
| 0x01C | FIFO_MAX | ro | 0x0 | Maximum observed DMA FIFO occupancy (buffered engine; 0 otherwise). |
| 0x040 + 0x20*m + 0x00 | READS[m] | ro | 0x0 | Accepted read requests. |
| 0x040 + 0x20*m + 0x04 | WRITES[m] | ro | 0x0 | Accepted write requests. |
| 0x040 + 0x20*m + 0x08 | REQ_STALL[m] | ro | 0x0 | Cycles req_valid && !req_ready. |
| 0x040 + 0x20*m + 0x0C | ARB_LOSS[m] | ro | 0x0 | Cycles the master lost arbitration (contention). |
| 0x040 + 0x20*m + 0x10 | RSP_STALL[m] | ro | 0x0 | Cycles rsp_valid && !rsp_ready. |
| 0x040 + 0x20*m + 0x14 | ERRORS[m] | ro | 0x0 | Error responses received. |
