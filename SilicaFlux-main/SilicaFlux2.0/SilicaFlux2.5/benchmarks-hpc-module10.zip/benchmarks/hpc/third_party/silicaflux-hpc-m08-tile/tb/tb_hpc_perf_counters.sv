// =============================================================================
// SilicaFlux-HPC Module 08 :: tb_hpc_perf_counters
// Self-checking unit test of hpc_perf_counters: random multi-bit increments
// against a 64-bit model with saturation, freeze (enable = 0), clear (wins
// over increments) and reset.  Small CW so that saturation is reached.
// Prints "TB_PC RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_hpc_perf_counters;
  parameter int NUM = 5;
  parameter int CW  = 10;
  parameter int IW  = 4;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  logic              clear, enable;
  logic [NUM*IW-1:0] inc;
  logic [NUM*CW-1:0] cnt;

  hpc_perf_counters #(.NUM(NUM), .CW(CW), .IW(IW)) dut (.*);

  longint unsigned model[NUM];
  int unsigned errors = 0, sat_seen = 0, clears = 0, frozen = 0, seed = 1, seed0;
  localparam longint unsigned MAXV = (64'd1 << CW) - 1;

  initial begin
    void'($value$plusargs("seed=%d", seed));
    seed0 = seed;
    void'($urandom(seed));
    clear = 0; enable = 1; inc = '0;
    foreach (model[i]) model[i] = 0;
    repeat (2) @(posedge clk);
    rst_n = 1;
    for (int cyc = 0; cyc < 30000; cyc++) begin
      @(negedge clk);
      for (int i = 0; i < NUM; i++)
        if (int'(cnt[i*CW +: CW]) != int'(model[i])) begin
          errors++;
          if (errors < 10) $display("ERROR cyc %0d counter %0d = %0d model %0d", cyc, i, cnt[i*CW +: CW], model[i]);
        end
      for (int i = 0; i < NUM; i++) inc[i*IW +: IW] = ($urandom_range(3) == 0) ? '0 : IW'($urandom());
      enable = ($urandom_range(19) != 0);
      clear  = ($urandom_range(4999) == 0) || (cyc % 10000 == 7777);    // random + guaranteed clears
      @(posedge clk);
      if (clear) begin foreach (model[i]) model[i] = 0; clears++; end
      else if (enable) begin
        for (int i = 0; i < NUM; i++) begin
          model[i] += longint'(inc[i*IW +: IW]);
          if (model[i] > MAXV) begin model[i] = MAXV; sat_seen++; end
        end
      end else frozen++;
    end
    if (sat_seen == 0 || clears == 0 || frozen == 0) begin errors++; $display("ERROR coverage sat=%0d clr=%0d frz=%0d", sat_seen, clears, frozen); end
    $display("TB_PC saturations=%0d clears=%0d frozen_cycles=%0d", sat_seen, clears, frozen);
    $display("TB_PC RESULT %s", errors ? "FAIL" : "PASS");
    $finish;
  end
endmodule

`default_nettype wire
