#!/usr/bin/env python3
"""reports/SUMMARY.md from the JSON / Markdown reports written by the other scripts (no number is typed by hand)."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402

R = C.REPORTS


def j(name):
    p = R / name
    return json.loads(p.read_text()) if p.exists() else None


def main():
    rows = []
    ms = (R / "model_selftest.md").read_text() if (R / "model_selftest.md").exists() else ""
    m = re.search(r"\*\*Total mismatches: (\d+)\*\*", ms)
    sf = sum(int(x) for x in re.findall(r"^\| \w+ \| (\d+) \|$", ms, re.M))
    rows.append(("Reference model vs SoftFloat-3e (RISC-V) + numpy + spec corner cases",
                 f"{sf:,} SoftFloat vectors, mismatches **{m.group(1) if m else '?'}**", "model_selftest.md"))
    u = j("unit.json")
    if u:
        rows.append(("Unit tests: command queue (M06), counters (M07), Verilator + Icarus",
                     f"**{sum(x['ok'] for x in u)} / {len(u)}**", "unit.md"))
    lint = j("lint.json")
    if lint:
        rows.append(("Lint: Verilator -Wall on the new RTL, parameter sweep",
                     f"**{sum(x['own'] == 0 for x in lint['verilator'])} / {len(lint['verilator'])}** clean", "lint.md"))
        rows.append(("Elaboration: Icarus / Yosys (+ latch check), parameter sweep",
                     f"**{sum(x['ok'] for x in lint['icarus'])} / {len(lint['icarus'])}** / "
                     f"**{sum(x['ok'] for x in lint['yosys'])} / {len(lint['yosys'])}**", "lint.md"))
        rows.append(("Illegal parameters rejected by the tile (Verilator + Icarus + Yosys)",
                     f"**{sum(x['ok'] for x in lint['negative'])} / {len(lint['negative'])}**", "lint.md"))
    reg = j("regression.json")
    if reg:
        for s in reg["stages"]:
            rows.append((f"Integration: {s['title']}", f"**{s['passed']} / {s['total']}**", "regression.md"))
        tot = sum(s["passed"] for s in reg["stages"]), sum(s["total"] for s in reg["stages"])
        rows.append(("Integration regression, total", f"**{tot[0]} / {tot[1]}**", "regression.md"))
    mu = j("mutation.json")
    if mu:
        k = sum(x["killed"] for x in mu)
        eq = sum(1 for x in mu if not x["killed"] and x.get("equivalent"))
        rows.append(("Mutation testing of the new RTL", f"**{k} / {len(mu) - eq}** killed (+{eq} equivalent)", "mutation.md"))
    soc = j("soc.json")
    if soc:
        rows.append(("Firmware on the SilicaFlux-V CPU (SoC simulation)",
                     f"**{sum(x['ok'] for x in soc['runs'])} / {len(soc['runs'])}** scenarios", "soc.md"))
    pf = j("perf.json")
    if pf:
        rows.append(("Measured performance runs (each self-checking)", "all PASS" if pf.get("all_runs_self_checked_pass") else "FAIL", "perf.md"))
    sy = j("synth.json")
    if sy:
        for r in sy["results"]:
            e = r.get("ecp5") or {}
            if e.get("fmax_mhz"):
                u2 = e.get("util", {}).get("TRELLIS_COMB")
                rows.append((f"ECP5-85F place and route ({r['config']})",
                             f"routed; {u2[0]:,} / {u2[1]:,} TRELLIS_COMB; Fmax {e['fmax_mhz']} MHz (nextpnr estimate)" if u2 else "routed",
                             "synth.md"))
    L = ["# SilicaFlux-HPC Module 08: results summary", "",
         "Every entry is parsed from the named report, which records the tool versions and the raw data.", "",
         "| check | result | report |", "|---|---|---|"]
    L += [f"| {a} | {b} | [{c}]({c}) |" for a, b, c in rows]
    (R / "SUMMARY.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
