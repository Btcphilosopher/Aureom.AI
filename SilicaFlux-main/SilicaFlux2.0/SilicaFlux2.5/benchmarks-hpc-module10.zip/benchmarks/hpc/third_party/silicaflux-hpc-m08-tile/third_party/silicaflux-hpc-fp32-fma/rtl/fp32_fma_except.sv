// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_except.sv -- STEP 8: IEEE 754 exception classification
//
// Default (non-trapping) exception handling, flags in out_flags order
// {NV, DZ, OF, UF, NX}:
//   NV invalid      : decided in step 2 for special cases (sNaN operand,
//                     0 x inf, inf - inf); never raised by the finite path.
//   DZ div-by-zero  : constant 0 -- no FMA operand combination divides.
//   OF overflow     : rounded exponent >= 255, i.e. e_norm >= 255, or
//                     e_norm == 254 and the rounding carries out (always
//                     accompanied by NX).
//   UF underflow    : tiny AND inexact (IEEE 754-2019 sec. 7.5 default
//                     handling: an exact tiny result raises no flag).
//   NX inexact      : any discarded nonzero bit, or overflow.
// An exact zero sum raises nothing; special-case results raise NV only.
// =============================================================================
`default_nettype none

module fp32_fma_except (
  input  wire logic        e_ge255,
  input  wire logic        e_eq254,
  input  wire logic        carry,
  input  wire logic        inexact,
  input  wire logic        tiny,
  input  wire logic        zero,
  input  wire logic        spec_valid,
  input  wire logic        spec_nv,
  output logic             overflow,
  output logic [4:0]       flags
);
  logic nx, uf;

  assign overflow = ~zero & (e_ge255 | (e_eq254 & carry));
  assign nx       = ~zero & (inexact | overflow);
  assign uf       = ~zero & ~overflow & tiny & inexact;

  always_comb begin
    flags = 5'd0;
    if (spec_valid) begin
      flags[fp32_fma_pkg::FLG_NV] = spec_nv;
    end else begin
      flags[fp32_fma_pkg::FLG_OF] = overflow;
      flags[fp32_fma_pkg::FLG_UF] = uf;
      flags[fp32_fma_pkg::FLG_NX] = nx;
    end
  end
endmodule

`default_nettype wire
