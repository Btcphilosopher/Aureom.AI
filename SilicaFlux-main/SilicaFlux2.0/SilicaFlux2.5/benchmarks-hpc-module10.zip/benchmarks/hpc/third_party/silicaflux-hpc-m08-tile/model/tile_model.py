"""Reference model of the SilicaFlux-HPC compute tile (Module 08) -- command semantics.

Independent of the RTL: written from docs/02_commands.md, docs/05_errors.md, the DataFabric DMA
specification (dma_validate rules, DMA.md) and the Module 05 REGION rule.  It executes commands one at a
time, in submission order, against a byte-accurate memory model -- the semantics the tile must reproduce
whatever its internal overlap (the hazard rule guarantees that concurrent execution is equivalent to
sequential execution).  FP32 arithmetic: fp32_model (exact, self-tested against SoftFloat).

Outputs per command: the expected completion record (fields may be None = "don't care" when the value is
timing dependent, e.g. the byte count of a buffered DMA transfer that stopped on a bus error), memory side
effects, and deterministic performance-counter increments.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import fp32_model as F
import tile_defs as D

DMA_ZERO_LENGTH, DMA_LENGTH, DMA_SRC_ALIGN, DMA_DST_ALIGN = 1, 2, 3, 4
DMA_SRC_OVERFLOW, DMA_DST_OVERFLOW, DMA_OVERLAP, DMA_READ_BUS, DMA_WRITE_BUS = 5, 6, 7, 8, 9
DMA_ABORTED, DMA_REGION = 10, 11
MAX_LEN = 1 << 24


class BusError(Exception):
    def __init__(self, addr):
        super().__init__(f"bus error at {addr:#x}")
        self.addr = addr


class UndefinedRead(Exception):
    pass


@dataclass
class Region:
    name: str
    base: int
    size: int
    err_lo: int = 0          # [err_lo, err_hi): accesses answer with an error (fault slave)
    err_hi: int = 0

    def contains(self, a: int) -> bool:
        return self.base <= a < self.base + self.size


@dataclass
class Cfg:
    n_lanes: int = 4
    dw: int = 32
    spm_base: int = 0x2000_0000
    spm_bytes: int = 65536
    num_banks: int = 4
    buffered_dma: bool = False

    @property
    def sb(self):
        return self.dw // 8

    @property
    def vl_max(self):
        return self.spm_bytes // 4

    @property
    def lpw(self):
        return min(self.n_lanes, self.dw // 32)


@dataclass
class Record:
    tag: int
    status: int
    typ: int
    detail: int | None = 0
    flags: int | None = 0
    step: int | None = 0
    seq: int = 0
    count: int | None = 0
    result: int | None = 0
    eaddr: int | None = 0

    def fields(self):
        return [self.tag, self.status, self.typ, self.detail, self.flags, self.step, self.seq, self.count,
                self.result, self.eaddr]


@dataclass
class Perf:
    submitted: int = 0
    completed: int = 0
    errors: int = 0
    cancelled: int = 0
    dma_bytes_rd: int | None = 0
    dma_bytes_wr: int | None = 0
    vec_elems: int = 0
    vec_flops: int = 0
    lsu_loads: int | None = 0
    lsu_stores: int | None = 0
    dma_cmds: int = 0
    vec_cmds: int = 0
    kernel_cmds: int = 0

    def add(self, k, v):
        cur = getattr(self, k)
        setattr(self, k, None if (cur is None or v is None) else cur + v)


class Memory:
    """Byte-accurate memory of the testbench system: external regions + the tile scratchpad."""

    def __init__(self, regions: list[Region]):
        self.regions = regions
        self.mem: dict[int, int] = {}
        self.cmd_written: set[int] = set()        # word addresses written by commands (initial-image guard)

    def region(self, a):
        for r in self.regions:
            if r.contains(a):
                return r
        return None

    def check(self, a):
        r = self.region(a)
        if r is None or (r.err_lo <= a < r.err_hi):
            raise BusError(a)

    def rd8(self, a):
        if a not in self.mem:
            raise UndefinedRead(f"read of never-written byte {a:#x}")
        return self.mem[a]

    def rd32(self, a):
        return sum(self.rd8(a + i) << (8 * i) for i in range(4))

    def wr32(self, a, v, by_cmd=True):
        for i in range(4):
            self.mem[a + i] = (v >> (8 * i)) & 0xFF
        if by_cmd:
            self.cmd_written.add(a & ~3)

    def defined(self, a, n):
        return all((a + i) in self.mem for i in range(n))


class TileModel:
    def __init__(self, cfg: Cfg, regions: list[Region]):
        self.cfg = cfg
        self.mem = Memory(regions + [Region("SPM", cfg.spm_base, cfg.spm_bytes)])
        self.seq = 0
        self.perf = Perf()
        self.halted = False
        self.halt_on_error = True

    # ------------------------------------------------------------ helpers
    def in_spm(self, a, n):
        return a >= self.cfg.spm_base and a + n <= self.cfg.spm_base + self.cfg.spm_bytes

    def aligned(self, a):
        return a % self.cfg.sb == 0

    # ------------------------------------------------------------ DMA (DataFabric dma_validate + REGION + simple engine)
    def dma(self, src, dst, ln):
        """Returns (code, err_addr, bytes_acked, bytes_rd, bytes_wr) -- bytes are exact for the simple engine."""
        sb = self.cfg.sb
        if ln == 0:
            return DMA_ZERO_LENGTH, 0, 0, 0, 0
        if ln > MAX_LEN:
            return DMA_LENGTH, 0, 0, 0, 0
        if src % sb:
            return DMA_SRC_ALIGN, 0, 0, 0, 0
        if dst % sb:
            return DMA_DST_ALIGN, 0, 0, 0, 0
        if src + ln > 1 << 32:
            return DMA_SRC_OVERFLOW, 0, 0, 0, 0
        if dst + ln > 1 << 32:
            return DMA_DST_OVERFLOW, 0, 0, 0, 0
        if src < dst + ln and dst < src + ln:
            return DMA_OVERLAP, 0, 0, 0, 0
        lo, hi = self.cfg.spm_base, self.cfg.spm_base + self.cfg.spm_bytes

        def region_ok(a):
            return (a >= lo and a + ln <= hi) or (a + ln <= lo or a >= hi)

        def boundary(a):
            return hi if (a >> (self.cfg.spm_bytes.bit_length() - 1)) == (lo >> (self.cfg.spm_bytes.bit_length() - 1)) else lo

        if not region_ok(src) or not region_ok(dst):
            return DMA_REGION, (boundary(dst) if region_ok(src) else boundary(src)), 0, 0, 0
        acked = rd = wr = 0
        for off in range(0, ln, sb):
            nbytes = min(sb, ln - off)
            try:
                self.mem.check(src + off)
            except BusError as e:
                return DMA_READ_BUS, e.addr, acked, rd, wr
            data = [self.mem.rd8(src + off + i) if (src + off + i) in self.mem.mem else None for i in range(sb)]
            rd += sb
            try:
                self.mem.check(dst + off)
            except BusError as e:
                return DMA_WRITE_BUS, e.addr, acked, rd, wr
            for i in range(nbytes):
                if data[i] is None:
                    self.mem.mem.pop(dst + off + i, None)     # copying undefined bytes keeps them undefined
                else:
                    self.mem.mem[dst + off + i] = data[i]
                self.mem.cmd_written.add((dst + off + i) & ~3)
            acked += nbytes
            wr += nbytes
        return 0, 0, acked, rd, wr

    # ------------------------------------------------------------ vector execution on the scratchpad
    def vec_exec(self, op, rm, bc, red, vl, sc, a, b, c, d):
        """Returns (flags, count, result, loads, stores)."""
        rdm = F.reads(op, bc)
        res, flags = [], 0
        for e in range(vl):
            opa = sc if bc & 1 else (self.mem.rd32(a + 4 * e) if rdm & 1 else 0)
            opb = sc if bc & 2 else (self.mem.rd32(b + 4 * e) if rdm & 2 else 0)
            opc = sc if bc & 4 else (self.mem.rd32(c + 4 * e) if rdm & 4 else 0)
            r, f = F.elem(op, opa, opb, opc, rm)
            res.append(r)
            flags |= f
        groups = -(-vl // self.cfg.lpw)
        loads = groups * bin(rdm).count("1")
        if red:
            r, f = F.reduce_sum(res, self.cfg.n_lanes, sc, rm)
            flags |= f
            self.mem.wr32(d, r)
            return flags, vl, r, loads, 1
        for e in range(vl):
            self.mem.wr32(d + 4 * e, res[e])
        return flags, vl, 0, loads, groups

    # ------------------------------------------------------------ one command
    def execute(self, w):
        """Execute descriptor words w[0..7]; returns the expected Record (sequential semantics)."""
        cfg = self.cfg
        w0 = w[0]
        typ, op, rm, bc = w0 & 0xF, (w0 >> 4) & 0x1F, (w0 >> 9) & 7, (w0 >> 12) & 7
        red, tag, rsvd = (w0 >> 15) & 1, (w0 >> 16) & 0xFF, w0 >> 25
        vl, sc, A, B, C, Dd, stage = w[1], w[2], w[3], w[4], w[5], w[6], w[7]
        rec = Record(tag=tag, status=D.ST_OK, typ=typ, seq=self.seq & 0xFFFF)
        self.seq += 1
        self.perf.submitted += 1
        rdm = F.reads(op, bc)
        nbytes = vl * 4
        # ---------------- validation (docs/05_errors.md sec. 2, first failing rule wins)
        st = D.ST_OK
        if typ > D.CT_LAST:
            st = D.ST_BAD_TYPE
        elif rsvd:
            st = D.ST_BAD_RSVD
        elif typ in (D.CT_VEC, D.CT_KERNEL):
            if not F.cmd_legal(op, rm, red, bc):
                st = D.ST_BAD_OP
            elif vl == 0 or vl > cfg.vl_max:
                st = D.ST_BAD_VL
            else:
                used = [x for k, x in enumerate((A, B, C)) if rdm >> k & 1] + [Dd]
                if typ == D.CT_KERNEL:
                    used.append(stage)
                if any(not self.aligned(x) for x in used):
                    st = D.ST_ALIGN
                elif typ == D.CT_VEC:
                    dbytes = 4 if red else nbytes
                    srcs = [x for k, x in enumerate((A, B, C)) if rdm >> k & 1]
                    if any(not self.in_spm(x, nbytes) for x in srcs) or not self.in_spm(Dd, dbytes):
                        st = D.ST_SPM_RANGE
                    elif not red and any(x != Dd and x < Dd + nbytes and Dd < x + nbytes for x in srcs):
                        st = D.ST_OVERLAP
                else:
                    stride = -(-nbytes // cfg.sb) * cfg.sb
                    if not self.in_spm(stage, 4 * stride):
                        st = D.ST_SPM_RANGE
        if st != D.ST_OK:
            rec.status = st
            return self._retire(rec)
        if typ == D.CT_NOP:
            return self._retire(rec)
        if typ == D.CT_DMA:
            code, ea, acked, brd, bwr = self.dma(A, B, vl)
            rec.count = acked
            if code:
                rec.status, rec.detail, rec.eaddr = D.ST_DMA_ERR, code, ea
                if cfg.buffered_dma and code in (DMA_READ_BUS, DMA_WRITE_BUS):
                    rec.count, brd, bwr = None, None, None
            self.perf.add("dma_bytes_rd", brd)
            self.perf.add("dma_bytes_wr", bwr)
            return self._retire(rec)
        if typ == D.CT_VEC:
            fl, cnt, r, ld, stc = self.vec_exec(op, rm, bc, red, vl, sc, A, B, C, Dd)
            rec.flags, rec.count, rec.result = fl, cnt, r
            self.perf.vec_elems += cnt
            self.perf.vec_flops += cnt * F.flops_per_elem(op)
            self.perf.add("lsu_loads", ld)
            self.perf.add("lsu_stores", stc)
            return self._retire(rec)
        # ---------------- KERNEL: LOAD_A, LOAD_B, LOAD_C, COMPUTE, STORE_D
        stride = -(-nbytes // cfg.sb) * cfg.sb
        reg = [stage + k * stride for k in range(4)]
        for k, (x, step) in enumerate(((A, D.KS_LOAD_A), (B, D.KS_LOAD_B), (C, D.KS_LOAD_C))):
            if not rdm >> k & 1:
                continue
            code, ea, acked, brd, bwr = self.dma(x, reg[k], nbytes)
            self.perf.add("dma_bytes_rd", None if (code and cfg.buffered_dma) else brd)
            self.perf.add("dma_bytes_wr", None if (code and cfg.buffered_dma) else bwr)
            if code:
                rec.status, rec.detail, rec.eaddr, rec.step = D.ST_DMA_ERR, code, ea, step
                return self._retire(rec)
        fl, cnt, r, ld, stc = self.vec_exec(op, rm, bc, red, vl, sc, reg[0], reg[1], reg[2], reg[3])
        self.perf.vec_elems += cnt
        self.perf.vec_flops += cnt * F.flops_per_elem(op)
        self.perf.add("lsu_loads", ld)
        self.perf.add("lsu_stores", stc)
        rec.flags, rec.count, rec.result = fl, cnt, r
        code, ea, acked, brd, bwr = self.dma(reg[3], Dd, 4 if red else nbytes)
        self.perf.add("dma_bytes_rd", None if (code and cfg.buffered_dma) else brd)
        self.perf.add("dma_bytes_wr", None if (code and cfg.buffered_dma) else bwr)
        if code:
            rec.status, rec.detail, rec.eaddr, rec.step = D.ST_DMA_ERR, code, ea, D.KS_STORE_D
        return self._retire(rec)

    def cancel(self, w):
        rec = Record(tag=(w[0] >> 16) & 0xFF, status=D.ST_CANCELLED, typ=w[0] & 0xF, seq=self.seq & 0xFFFF)
        self.seq += 1
        self.perf.submitted += 1
        return self._retire(rec)

    def _retire(self, rec):
        self.perf.completed += 1
        if rec.status == D.ST_CANCELLED:
            self.perf.cancelled += 1
        elif rec.status != D.ST_OK:
            self.perf.errors += 1
            if self.halt_on_error:
                self.halted = True
        else:
            if rec.typ == D.CT_DMA:
                self.perf.dma_cmds += 1
            elif rec.typ == D.CT_VEC:
                self.perf.vec_cmds += 1
            elif rec.typ == D.CT_KERNEL:
                self.perf.kernel_cmds += 1
        return rec


# ------------------------------------------------------------------ descriptor builders
def w0(typ, op=0, rm=0, bc=0, red=0, tag=0, fence=0, rsvd=0):
    return (typ & 0xF) | (op & 0x1F) << 4 | (rm & 7) << 9 | (bc & 7) << 12 | (red & 1) << 15 | \
        (tag & 0xFF) << 16 | (fence & 1) << 24 | (rsvd & 0x7F) << 25


def nop(tag=0, fence=0):
    return [w0(D.CT_NOP, tag=tag, fence=fence), 0, 0, 0, 0, 0, 0, 0]


def dma(src, dst, ln, tag=0, fence=0):
    return [w0(D.CT_DMA, tag=tag, fence=fence), ln, 0, src, dst, 0, 0, 0]


def vec(op, vl, a, b, c, d, rm=0, bc=0, red=0, sc=0, tag=0, fence=0):
    return [w0(D.CT_VEC, op, rm, bc, red, tag, fence), vl, sc, a, b, c, d, 0]


def kernel(op, vl, a, b, c, d, stage, rm=0, bc=0, red=0, sc=0, tag=0, fence=0):
    return [w0(D.CT_KERNEL, op, rm, bc, red, tag, fence), vl, sc, a, b, c, d, stage]
