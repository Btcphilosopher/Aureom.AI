#!/usr/bin/env bash
# Build SoftFloat-3e (vendored unmodified, third_party/berkeley-softfloat-3, RISCV specialisation)
# and the ctypes shim used by scripts/selftest_model.py.  Output: build/softfloat/libsfshim.so
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SF="$ROOT/third_party/berkeley-softfloat-3"
OUT="$ROOT/build/softfloat"
mkdir -p "$OUT"
if [ ! -f "$OUT/riscv/softfloat.a" ]; then
  rm -rf "$OUT/riscv"; cp -r "$SF/build/Linux-x86_64-GCC" "$OUT/riscv"
  make -s -C "$OUT/riscv" -j"$(nproc)" SOURCE_DIR="$SF/source" SPECIALIZE_TYPE=RISCV \
    COMPILE_C="gcc -c -fPIC -Werror-implicit-function-declaration -DSOFTFLOAT_FAST_INT64 \
      -DSOFTFLOAT_ROUND_ODD -DINLINE_LEVEL=5 -DSOFTFLOAT_FAST_DIV32TO16 -DSOFTFLOAT_FAST_DIV64TO32 \
      -I. -I$SF/source/RISCV -I$SF/source/include -O2 -o \$@" softfloat.a
fi
gcc -O2 -fPIC -shared -I"$SF/source/include" -I"$OUT/riscv" "$ROOT/model/softfloat/sf_shim.c" \
    "$OUT/riscv/softfloat.a" -o "$OUT/libsfshim.so"
echo "$OUT/libsfshim.so"
