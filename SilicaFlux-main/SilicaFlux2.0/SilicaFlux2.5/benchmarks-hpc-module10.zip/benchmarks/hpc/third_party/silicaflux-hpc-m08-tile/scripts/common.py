"""Shared build / run helpers for the Module 08 scripts (Verilator 5.020, Icarus 12, Yosys 0.33)."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

import files as F

ROOT = F.ROOT
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"


def tool_versions() -> dict:
    def ver(cmd):
        try:
            return subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout.strip().splitlines()[0]
        except Exception as e:  # noqa: BLE001
            return f"unavailable ({e.__class__.__name__})"
    return {"verilator": ver(["verilator", "--version"]), "icarus": ver(["iverilog", "-V"]),
            "yosys": ver(["yosys", "-V"]), "python": ver(["python3", "--version"])}


def _key(*parts) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update(json.dumps(p, sort_keys=True, default=str).encode())
    for f in sorted(set(str(x) for x in F.TILE_TB + list(ROOT.glob("rtl/*.svh")))):
        h.update(Path(f).read_bytes())
    return h.hexdigest()[:12]


def verilator_build(top: str, files: list, params: dict, defines: list, name: str, jobs: int = 4) -> Path:
    """Build (or reuse) a Verilator binary; returns the executable path."""
    key = _key(top, [str(f) for f in files], params, defines)
    d = BUILD / "vl" / f"{name}_{key}"
    exe = d / "sim"
    if exe.exists():
        return exe
    d.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "-j", str(jobs), "-Wno-fatal", "-Wno-lint", "-Wno-style",
           "-Wno-MULTIDRIVEN", "-Wno-TIMESCALEMOD", "--x-assign", "unique", "--x-initial", "unique",
           "--top-module", top, "-Mdir", str(d), "-o", "sim", "-O2"]
    cmd += [f"-G{k}={v}" for k, v in params.items()]
    cmd += [f"+define+{x}" for x in defines]
    cmd += [f"+incdir+{x}" for x in F.INCDIRS]
    cmd += [str(f) for f in files]
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True)
    (d / "build.log").write_text(" ".join(cmd) + "\n\n" + r.stdout + r.stderr)
    if r.returncode != 0 or not exe.exists():
        raise RuntimeError(f"verilator build {name} failed, see {d / 'build.log'}\n{r.stderr[-3000:]}")
    (d / "build_time.txt").write_text(f"{time.time() - t0:.1f}\n")
    return exe


def icarus_build(top: str, files: list, params: dict, defines: list, name: str) -> Path:
    key = _key("icarus", top, [str(f) for f in files], params, defines)
    d = BUILD / "iv" / f"{name}_{key}"
    vvp = d / "sim.vvp"
    if vvp.exists():
        return vvp
    d.mkdir(parents=True, exist_ok=True)
    cmd = ["iverilog", "-g2012", "-o", str(vvp), "-s", top]
    cmd += [f"-P{top}.{k}={v}" for k, v in params.items()]
    cmd += [f"-D{x}" for x in defines]
    cmd += [f"-I{x}" for x in F.INCDIRS]
    cmd += [str(f) for f in files]
    r = subprocess.run(cmd, capture_output=True, text=True)
    (d / "build.log").write_text(" ".join(cmd) + "\n\n" + r.stdout + r.stderr)
    if r.returncode != 0:
        raise RuntimeError(f"icarus build {name} failed, see {d / 'build.log'}\n{r.stderr[-3000:]}")
    return vvp


def run(cmd: list, timeout: int = 3600, cwd=None) -> tuple[int, str, float]:
    t0 = time.time()
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        out = r.stdout + r.stderr
        rc = r.returncode
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        out += "\nTIMEOUT"
        rc = -1
    return rc, out, time.time() - t0
