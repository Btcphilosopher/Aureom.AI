# SilicaFlux-HPC · Module 08 — Complete compute tile

**Primary source:** `rtl/silicaflux_hpc_tile.sv` · Aureom.AI | SilicaFlux-HPC

One synthesizable compute tile. It integrates the verified SilicaFlux-HPC components and executes commands,
moves data, performs FP32 vector arithmetic and returns results.

| Part | Source |
|---|---|
| FP32 lanes | Module 02, unmodified |
| Vector array | Module 03, unmodified |
| Banked scratchpad | Module 04, unmodified |
| DMA adapter on the DataFabric DMA engine | Module 05, unmodified |
| Command queue | new (Module 06) |
| Performance counters | new (Module 07) |
| Scheduler, vector load/store unit, host register block | new |

**Definition of done: met in RTL simulation.**
* *Memory → compute → memory, one command.* A KERNEL command DMA-loads vectors from host-visible memory,
  computes FADD / FMUL / FMADD / … on the array, and DMA-stores the results.
* *Correct results.* The results are bit-exact, flags included, against an independent software reference.
* *Two hosts.* This works with the testbench host and with **firmware on the real SilicaFlux-V CPU**.
* *Not covered by that claim.* FPGA hardware validation is a separate gate. It was **not** performed
  (no board): see §4.

## Results (final run on the frozen sources; every number is from `reports/`)

| Check | Result | Report |
|---|---|---|
| Independent FP32 reference model vs Berkeley SoftFloat-3e (RISC-V) + numpy + spec corner cases | 600 000 + 166 140 vectors, **0 mismatches** | [model_selftest](reports/model_selftest.md) |
| Unit tests of the new command queue (M06) and counters (M07), Verilator + Icarus | **120 / 120** | [unit](reports/unit.md) |
| Lint, Verilator `-Wall`, new RTL, 14 parameter sets | **14 / 14 clean** (0 warnings) | [lint](reports/lint.md) |
| Elaboration Icarus / Yosys + latch check, 14 parameter sets | **14 / 14** / **14 / 14** | [lint](reports/lint.md) |
| Illegal parameters rejected by the tile (3 tools) | **20 / 20** | [lint](reports/lint.md) |
| **Stage 1**: queue + scratchpad + **2-lane** vector engine | **4 / 4** | [regression](reports/regression.md) |
| **Stage 2**: full **4-lane baseline**, all 15 tests × 2 seeds | **30 / 30** | [regression](reports/regression.md) |
| **Stage 3**: 10 further configurations (1 / 8 / 16 lanes, 64 / 128-bit, buffered DMA, RL 2 / 4, parity, no counters, depth-2 queues) | **111 / 111** | [regression](reports/regression.md) |
| **Integration regression total** | **145 / 145** | [regression](reports/regression.md) |
| Mutation testing of the new RTL | **27 / 27** non-equivalent killed (+1 equivalent, explained) | [mutation](reports/mutation.md) |
| **Firmware on the SilicaFlux-V CPU** controlling the tile (SoC simulation): demo 104 / 104 checks on 2 SoC variants; unmodified SilicaFlux-V app, ROM POST and DataFabric DMA demo on the same SoC | **5 / 5** scenarios | [soc](reports/soc.md) |
| SFB2 protocol violations (checkers on every tile bus port, all runs) | **0** | [regression](reports/regression.md) |
| ECP5-85F place and route, baseline (tile + harness) | routed, 55 992 / 83 640 TRELLIS_COMB, 32 DP16KD, 45 MULT18; **31.24 MHz** post-route estimate (25 MHz: PASS) | [synth](reports/synth.md) |
| ECP5-85F place and route, 2 lanes | routed, 34 292 / 83 640 TRELLIS_COMB; **34.65 MHz** post-route estimate | [synth](reports/synth.md) |
| Xilinx-7 mapping (Yosys, no Vivado), baseline | 29 091 LUT, 10 136 FF, 16 RAMB36, 29 DSP48 | [synth](reports/synth.md) |
| FPGA **hardware** validation | **not performed** (no board) | [doc 08](docs/08_fpga_synthesis.md) |

Measured (RTL cycles, self-checking runs, [perf](reports/perf.md)):
* The vector unit reaches 1.32 FADD / 0.99 FMADD elements per cycle at 4 lanes / 32-bit, and 5.1 / 3.85 at
  16 lanes / 128-bit. That is ≥ 95 % of the scratchpad-port bound.
* A KERNEL FMADD from host memory to host memory takes 17.0 cycles per element (simple DMA) or 11.0
  (buffered). It is DMA-bound on the 32-bit fabric.
* DMA / compute overlap with double buffering: 1.07–1.10×.
* Command overhead: NOP 1 cycle, vl = 1 FADD 14 cycles.


## 1. What the tile does

```
host ──rb page (0x4000_8000 in the SoC)──▶ registers ──▶ command queue ──▶ scheduler ──▶ completion queue ──▶ host
                                                              │   validate → dispatch (hazard check) → ROB
                                         ┌────────────────────┴───────────────┐
                                  DMA adapter (M05)                    load/store unit ─▶ vector array (M03/M02)
                          SFB2 master ▲    │ SPM port                     │ 4 SPM ports
                   host-visible memory    ▼                               ▼
                                     banked scratchpad (M04) ◀── host scratchpad window (SFB2 slave)
```

* **Commands** (8 words): NOP, DMA, VEC (scratchpad-resident vector operation), and KERNEL (load A/B/C,
  compute, store D, in one command). Every Module 02 operation is available, in five rounding modes, with
  broadcast scalars and sum / dot-product reduction (`docs/02_commands.md`).
* **Validation before any side effect.** An unsupported opcode, a bad length, misalignment, a scratchpad
  range error or an overlap is rejected and never executes.
* **In-order completion.** Each command produces exactly one record, carrying TAG, SEQ, STATUS, DETAIL,
  FFLAGS, STEP, COUNT, RESULT, ERR_ADDR and CYCLES.
* **Concurrency.** One DMA and one vector command may execute at the same time only if their address ranges
  are independent (hazard check), so every interleaving equals sequential execution
  (`docs/04_memory_and_ordering.md`).
* **Errors** propagate to the command that caused them:
  * a DMA failure is never reported as success;
  * a scratchpad error is reported with its code and word address;
  * the tile halts on error and supports RESUME and FLUSH (`docs/05_errors.md`).
* **Resets.** Hard reset, and a soft reset that first quiesces the tile's bus ports.
* **Counters.** 24 performance counters.
* **One clock domain.** The SilicaFlux reset convention: asynchronous assert, synchronous release.

## 2. Parameters (validated at elaboration)

| Parameter | Baseline | Legal |
|---|---|---|
| `NUM_LANES` | **4** | 1, 2, 4, 8, 16 |
| `DATA_WIDTH` | 32 | 32, 64, 128 |
| `SCRATCHPAD_BYTES` | 65536 | power of two, 1 KiB – 16 MiB |
| `NUM_BANKS` | 4 | 1, 2, 4, 8, 16 |
| `CMD_QUEUE_DEPTH` | 8 | power of two, 2 – 128 |
| `DMA_BUFFER_DEPTH` | **0 = simple engine (single DMA path)** | 0, or a power of two 2 – 128 (buffered engine) |
| `ENABLE_PERF_COUNTERS` | 1 | 0, 1 |

Secondary parameters: `SPM_BASE`, `CPL_QUEUE_DEPTH`, `HOST_SPM_PORT`, `LSU_MAX_PORTS`, scratchpad read
latency, ECC, backend. An illegal value stops elaboration with a message from the tile itself, checked by
20 negative tests on 3 tools. No FPGA device is hardcoded (`docs/01_architecture.md`).

## 3. Quick start

```bash
make stage1
```

```bash
make regress
```

```bash
make soc
```

```bash
make lint
```

```bash
make perf
```

```bash
make fpga
```

```bash
make test CONFIG=baseline TESTS=vec_fma,dma SEEDS=1,2
```

* `make stage1` — queue + scratchpad + 2-lane engine (bring-up stage).
* `make regress` — stage 1 → baseline → 10-configuration sweep.
* `make soc` — firmware on the SilicaFlux-V CPU drives the tile.
* `make lint` — Verilator / Icarus / Yosys checks plus the illegal-parameter tests.
* `make perf` — measured cycle counts.
* `make fpga` — Yosys ECP5 / Xilinx-7 synthesis plus nextpnr-ecp5 P&R.

Tools: Verilator 5.020, Icarus 12, Yosys 0.33, Python ≥ 3.10 with numpy, gcc, clang/lld (RV32I firmware),
optional nextpnr-ecp5 (`pip install yowasp-nextpnr-ecp5`). The directory is self-contained: `third_party/`
holds every reused source, unmodified, with SHA-256 sums.

## 4. What is not claimed

* **No PCIe** or other off-chip host link. The host interfaces are the SilicaFlux-V register bus page and
  SFB2 ports. The two hosts used are the SilicaFlux-V CPU (RTL) and a documented simulation host adapter.
* **No FPGA hardware run.** No board, no bitstream programmed. FPGA numbers are Yosys / nextpnr estimates:
  utilisation and nextpnr's post-route Fmax estimate. They are not a measured clock.
* **No ASIC area, power or timing.** No PDK is available.
* **No formal proof** of the new RTL. **No gate-level simulation.**
* **No Icarus cross-simulation of the integration testbench**, because of Icarus 12 language limitations.
  Icarus does run the unit tests and the elaboration sweep.
* **FPGAFlow does not exist** in the repository. The flow used is the repository's own practice
  (Yosys + nextpnr-ecp5, ULX3S).
* **Module 01 `fp32_fma`** is verified but not in the datapath. The Module 02 lane brings its own verified FMA.

## 5. Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_hpc_tile.sv` | `rtl/silicaflux_hpc_tile.sv` + `rtl/hpc_tile_sched.sv`, `rtl/hpc_tile_lsu.sv`, `rtl/hpc_tile_regs.sv`, `rtl/hpc_command_queue.sv` (M06), `rtl/hpc_perf_counters.sv` (M07) |
| Shared interfaces / packages | `rtl/hpc_tile_defs.svh` (the single source) → generated `sw/include/hpc_tile_regs.h`, `model/tile_defs.py`; reused `hpc_vector_pkg`, `hpc_varray_pkg`, `hpc_spm_defs.svh`, `hpc_dma_defs.svh` |
| Integration testbench | `tb/tb_silicaflux_hpc_tile.sv` (+ `tb/sfb_fault_slave.sv`), unit testbenches `tb/tb_hpc_command_queue.sv`, `tb/tb_hpc_perf_counters.sv`, SoC testbench `soc/tb/tb_soc_hpc.sv` |
| Independent software reference | `model/fp32_model.py`, `model/tile_model.py` (self-test: `scripts/selftest_model.py`) |
| Host control example | driver `sw/drivers/silicaflux_hpc.c` + `sw/include/silicaflux_hpc.h`; firmware `sw/examples/hpc_demo/main.c`; SoC `soc/` |
| Build scripts | `Makefile`, `scripts/*.py`, `sw/Makefile`, `soc/derive_soc.py`, `scripts/package.sh` |
| Architecture documentation | `docs/01`–`docs/10` (index below) |
| Actual synthesis reports | `reports/synth.md` + raw `reports/synth/<config>/` (Yosys statistics, nextpnr log and report) |
| Dependency status report | `docs/09_dependency_status.md`; repository audit and integration readiness table: `docs/00_repository_audit.md` |
| All results | `reports/SUMMARY.md` and the reports it links |

## 6. Documentation

| Document | Content |
|---|---|
| [00 Repository audit](docs/00_repository_audit.md) | what exists, what was re-verified here, **integration readiness table** |
| [01 Architecture](docs/01_architecture.md) | block diagram, subsystems, clock / reset, parameters and legality, data layout, LSU |
| [02 Commands](docs/02_commands.md) | descriptor format, command types, validation order, completion record, status codes |
| [03 Register map](docs/03_register_map.md) | every register, counter map |
| [04 Memory and ordering](docs/04_memory_and_ordering.md) | bank ports, arbitration and fairness, hazards, **required DMA / compute ordering** |
| [05 Errors](docs/05_errors.md) | error propagation, halt / resume / flush, hard and soft reset |
| [06 Host software](docs/06_host_software.md) | driver API, firmware example on the SilicaFlux-V CPU, SoC variant, simulation host adapter |
| [07 Verification](docs/07_verification.md) | method, test list → tests, staged bring-up, mutation testing |
| [08 FPGA and synthesis](docs/08_fpga_synthesis.md) | flows, FPGAFlow status, reading the numbers, hardware validation status |
| [09 Dependency status](docs/09_dependency_status.md) | every dependency: version, use, verification, open issues |
| [10 Performance](docs/10_performance.md) | measured throughput, bottlenecks, overlap, command overhead |
