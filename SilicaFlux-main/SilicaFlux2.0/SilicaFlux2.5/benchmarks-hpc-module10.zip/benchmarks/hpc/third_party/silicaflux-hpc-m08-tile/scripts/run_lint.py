#!/usr/bin/env python3
"""Lint and elaboration checks of the Module 08 RTL.

  1. Verilator 5.020 --lint-only -Wall on silicaflux_hpc_tile in a parameter sweep: the NEW RTL (rtl/) must
     produce 0 warnings; warnings inside vendored, unmodified third_party/ sources are listed, not fixed.
  2. Icarus 12 elaboration of the tile in the same sweep (0 errors).
  3. Yosys 0.33 elaboration (read, hierarchy -check, proc) + latch check in the sweep.
  4. Negative elaboration: every illegal parameter value / combination must STOP elaboration with the
     tile's own message (Verilator: message text; Icarus: time-0 $fatal; Yosys: abort).
  5. Generated headers (C, Python) up to date with rtl/hpc_tile_defs.svh.
Writes reports/lint.md / lint.json; exit 1 on any failure.
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402
import files as F  # noqa: E402

SWEEP = [
    {}, {"NUM_LANES": 2, "NUM_BANKS": 2}, {"NUM_LANES": 1, "NUM_BANKS": 1, "SCRATCHPAD_BYTES": 16384},
    {"NUM_LANES": 8, "NUM_BANKS": 8}, {"NUM_LANES": 16, "NUM_BANKS": 16, "SCRATCHPAD_BYTES": 131072},
    {"DATA_WIDTH": 64}, {"NUM_LANES": 2, "DATA_WIDTH": 128}, {"NUM_LANES": 16, "DATA_WIDTH": 128, "NUM_BANKS": 8},
    {"DMA_BUFFER_DEPTH": 8}, {"DMA_BUFFER_DEPTH": 128, "CMD_QUEUE_DEPTH": 128, "CPL_QUEUE_DEPTH": 2},
    {"ENABLE_PERF_COUNTERS": 0, "HOST_SPM_PORT": 0, "LSU_MAX_PORTS": 1},
    {"SPM_ECC": 1, "SPM_READ_LATENCY": 3}, {"SCRATCHPAD_BYTES": 1 << 24, "NUM_BANKS": 16},
    {"SCRATCHPAD_BYTES": 1024, "NUM_BANKS": 1},
]
# (parameters, text the tile's message must contain)
NEGATIVE = [
    ({"NUM_LANES": 3}, "NUM_LANES must be"), ({"NUM_LANES": 32}, "NUM_LANES must be"),
    ({"DATA_WIDTH": 16}, "DATA_WIDTH must be"), ({"DATA_WIDTH": 256}, "DATA_WIDTH must be"),
    ({"NUM_BANKS": 3}, "NUM_BANKS must be"), ({"NUM_BANKS": 32}, "NUM_BANKS must be"),
    ({"SCRATCHPAD_BYTES": 48000}, "SCRATCHPAD_BYTES must be"), ({"SCRATCHPAD_BYTES": 512}, "SCRATCHPAD_BYTES must be"),
    ({"SCRATCHPAD_BYTES": 1 << 25}, "SCRATCHPAD_BYTES must be"),
    ({"SPM_BASE": "32'h20001000"}, "SPM_BASE must be aligned"),
    ({"CMD_QUEUE_DEPTH": 3}, "CMD_QUEUE_DEPTH must be"), ({"CMD_QUEUE_DEPTH": 1}, "CMD_QUEUE_DEPTH must be"),
    ({"CMD_QUEUE_DEPTH": 256}, "CMD_QUEUE_DEPTH must be"), ({"CPL_QUEUE_DEPTH": 5}, "CPL_QUEUE_DEPTH must be"),
    ({"DMA_BUFFER_DEPTH": 1}, "DMA_BUFFER_DEPTH must be"), ({"DMA_BUFFER_DEPTH": 6}, "DMA_BUFFER_DEPTH must be"),
    ({"DMA_BUFFER_DEPTH": 256}, "DMA_BUFFER_DEPTH must be"), ({"ENABLE_PERF_COUNTERS": 2}, "ENABLE_PERF_COUNTERS must be"),
    ({"HOST_SPM_PORT": 2}, "HOST_SPM_PORT must be"), ({"LSU_MAX_PORTS": 3}, "LSU_MAX_PORTS must be"),
]


def flist():
    p = C.BUILD / "lint" / "tile.f"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\n".join([f"+incdir+{d}" for d in F.INCDIRS] + [str(f) for f in F.TILE_SYNTH]) + "\n")
    return p


def gflags(params):
    return [f"-G{k}={v}" for k, v in params.items()]


def verilator_lint(params):
    r = subprocess.run(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-f", str(flist()),
                        "--top-module", "silicaflux_hpc_tile"] + gflags(params), capture_output=True, text=True)
    out = r.stdout + r.stderr
    warns = [l for l in out.splitlines() if l.startswith("%Warning") or (l.startswith("%Error") and "Exiting" not in l)]
    own = [l for l in warns if "/rtl/" in l and "third_party" not in l]
    tp = [l for l in warns if "third_party" in l]
    return dict(params=params, own=len(own), own_list=own[:20], third_party=sorted(set(re.sub(r":\d+:\d+:", ":", l) for l in tp)))


def icarus_elab(params):
    d = C.BUILD / "lint"
    name = "iv_" + ("_".join(f"{k}{v}" for k, v in params.items()) or "default").replace("'", "")
    cmd = ["iverilog", "-g2012", "-o", str(d / f"{name}.vvp"), "-s", "silicaflux_hpc_tile"]
    cmd += [f"-Psilicaflux_hpc_tile.{k}={v}" for k, v in params.items()]
    cmd += [f"-I{x}" for x in F.INCDIRS] + [str(f) for f in F.TILE_SYNTH]
    r = subprocess.run(cmd, capture_output=True, text=True)
    errs = [l for l in (r.stdout + r.stderr).splitlines() if re.search(r"\berror:", l, re.I)]
    return dict(params=params, ok=r.returncode == 0 and not errs, errors=errs[:5], vvp=str(d / f"{name}.vvp"))


def yosys_elab(params):
    inc = " ".join(f"-I{p}" for p in F.INCDIRS)
    d = C.BUILD / "lint"
    name = "ys_" + ("_".join(f"{k}{v}" for k, v in params.items()) or "default").replace("'", "")
    wrap = d / f"{name}_top.sv"
    wrap.write_text(F.tile_wrapper(params))
    rd = f"read_verilog -defer -sv -DSYNTHESIS {inc} " + " ".join(str(f) for f in list(F.TILE_SYNTH) + [wrap])
    script = f"{rd}\nhierarchy -check -top cfg_top\nproc\nselect -assert-none t:$dlatch t:$adlatch t:$dlatchsr\n"
    (d / f"{name}.ys").write_text(script)
    r = subprocess.run(["yosys", "-q", "-s", str(d / f"{name}.ys")], capture_output=True, text=True, timeout=3600)
    return dict(params=params, ok=r.returncode == 0, tail=(r.stdout + r.stderr)[-300:])


def negative(params, text):
    res = dict(params=params, expect=text)
    r = subprocess.run(["verilator", "--lint-only", "-f", str(flist()), "--top-module", "silicaflux_hpc_tile"] + gflags(params),
                       capture_output=True, text=True)
    out = r.stdout + r.stderr
    msgs = [l for l in out.splitlines() if l.startswith("%Warning-USERFATAL") or l.startswith("%Error-USERFATAL")]
    res["verilator"] = r.returncode != 0 and len(msgs) >= 1 and all("silicaflux_hpc_tile:" in m for m in msgs) and text in out
    iv = icarus_elab(params)
    if iv["ok"]:
        rr = subprocess.run(["vvp", "-n", iv["vvp"]], capture_output=True, text=True, timeout=120)
        res["icarus"] = "FATAL" in (rr.stdout + rr.stderr).upper() and text in (rr.stdout + rr.stderr)
    else:
        res["icarus"] = text in " ".join(iv["errors"])
    y = yosys_elab(params)
    # Yosys 0.33 aborts on $fatal without printing its message; the abort must point at the tile's check
    res["yosys"] = (not y["ok"]) and "silicaflux_hpc_tile.sv" in y["tail"]
    res["ok"] = res["verilator"] and res["icarus"] and res["yosys"]
    return res


def main():
    out = {"tools": C.tool_versions()}
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        lint = list(ex.map(verilator_lint, SWEEP))
        iv = list(ex.map(icarus_elab, SWEEP))
        ys = list(ex.map(yosys_elab, SWEEP))
        neg = list(ex.map(lambda a: negative(*a), NEGATIVE))
    hdr = subprocess.run([sys.executable, str(C.ROOT / "scripts/gen_headers.py"), "--check"], capture_output=True, text=True)
    out.update(verilator=lint, icarus=iv, yosys=ys, negative=neg, headers_ok=hdr.returncode == 0)
    ok_l = all(x["own"] == 0 for x in lint)
    ok_i = all(x["ok"] for x in iv)
    ok_y = all(x["ok"] for x in ys)
    ok_n = all(x["ok"] for x in neg)
    L = ["# Lint and elaboration", "", f"Tools: {out['tools']}", "",
         "| check | result |", "|---|---|",
         f"| Verilator `-Wall`, new RTL (`rtl/`), {len(SWEEP)} parameter sets | **{sum(x['own'] == 0 for x in lint)} / {len(SWEEP)} clean** (0 warnings) |",
         f"| Icarus 12 elaboration, {len(SWEEP)} parameter sets | **{sum(x['ok'] for x in iv)} / {len(SWEEP)}** |",
         f"| Yosys 0.33 elaboration + latch check, {len(SWEEP)} parameter sets | **{sum(x['ok'] for x in ys)} / {len(SWEEP)}** latch-free |",
         f"| Illegal parameters rejected by the tile (Verilator message + Icarus $fatal + Yosys abort) | **{sum(x['ok'] for x in neg)} / {len(NEGATIVE)}** |",
         f"| Generated C / Python headers up to date | {'yes' if out['headers_ok'] else 'NO'} |", "",
         "## Parameter sets", ""]
    for x in lint:
        L.append(f"* `{x['params'] or 'baseline'}`: own warnings {x['own']}")
    L += ["", "## Negative elaboration tests", "", "| parameters | expected message | Verilator | Icarus | Yosys |", "|---|---|---|---|---|"]
    for x in neg:
        L.append(f"| `{x['params']}` | {x['expect']} | {'ok' if x['verilator'] else 'FAIL'} | {'ok' if x['icarus'] else 'FAIL'} | {'ok' if x['yosys'] else 'FAIL'} |")
    tp = sorted(set(w for x in lint for w in x["third_party"]))
    L += ["", "## Warnings inside vendored third-party sources (unmodified, not fixed here)", ""]
    L += [f"* `{w.split('third_party/')[-1][:160]}`" for w in tp] or ["none"]
    (C.REPORTS / "lint.md").write_text("\n".join(L) + "\n")
    (C.REPORTS / "lint.json").write_text(json.dumps(out, indent=1))
    print("\n".join(L[:12]))
    for x in neg:
        if not x["ok"]:
            print("NEGATIVE FAIL", x)
    sys.exit(0 if (ok_l and ok_i and ok_y and ok_n and out["headers_ok"]) else 1)


if __name__ == "__main__":
    main()
