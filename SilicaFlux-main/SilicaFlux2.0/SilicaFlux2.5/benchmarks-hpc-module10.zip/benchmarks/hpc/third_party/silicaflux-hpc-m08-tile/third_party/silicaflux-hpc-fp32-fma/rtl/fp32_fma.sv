// =============================================================================
// SilicaFlux-HPC :: Module 01
// fp32_fma.sv -- pipelined IEEE 754 binary32 fused multiply-add
//
//   out_result = round(in_a * in_b + in_c)        (single rounding)
//
// Interface
//   * valid/ready on both sides; a transfer happens when valid && ready.
//   * out_result/out_flags/out_tag are register outputs: they stay stable
//     while out_valid && !out_ready.
//   * in_tag is returned unchanged with the matching result; results leave in
//     issue order (the pipeline never reorders).
//   * in_rm selects the rounding attribute per operation (RISC-V frm encoding:
//     0 RNE, 1 RTZ, 2 RDN, 3 RUP, 4 RMM; 5..7 execute as RNE).
//   * out_flags = {NV, DZ, OF, UF, NX} (RISC-V fflags bit order).
//   * rst_n: asynchronous assert, active low; the caller provides synchronous
//     de-assertion (SilicaFlux-V sfv_rst_sync). Reset clears every stage's
//     valid bit, i.e. discards all outstanding operations; datapath flops are
//     not reset.
//
// Pipeline (docs/PIPELINE.md). Nine functional steps in six combinational
// segments, separated by elastic boundaries R1..R5 (enabled per PIPE_CFG bit)
// and the always-present output register R6:
//
//   in -> [1 unpack] R1 [2 prep] R2 [3 mul || 4 align] R3 [5 add] R4
//         [6 norm] R5 [7 round, 8 except, 9 pack] R6 -> out
//
//   PIPE_CFG[0]=R1 ... PIPE_CFG[4]=R5.  LATENCY = 1 + popcount(PIPE_CFG).
//   Default 5'b11110 -> 5-cycle latency.
//   Initiation interval: 1 operation per cycle while out_ready is high
//   (verified, docs/LATENCY_THROUGHPUT.md).
//
// Parameters
//   TAG_W                    transaction tag width (>= 1)
//   PIPE_CFG                 pipeline boundary enables (see above)
//   NAN_PROPAGATE            0: canonical NaN 7FC00000 (RISC-V);
//                            1: payload propagation (SoftFloat ARM-VFPv2 rules)
//   TININESS_AFTER_ROUNDING  1: RISC-V/x86 convention; 0: Arm convention
// =============================================================================
`default_nettype none

module fp32_fma #(
  parameter int       TAG_W                   = 8,
  parameter bit [4:0] PIPE_CFG                = 5'b11110,
  parameter bit       NAN_PROPAGATE           = 1'b0,
  parameter bit       TININESS_AFTER_ROUNDING = 1'b1
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // request
  input  wire logic             in_valid,
  output logic                  in_ready,
  input  wire logic [31:0]      in_a,
  input  wire logic [31:0]      in_b,
  input  wire logic [31:0]      in_c,
  input  wire logic [2:0]       in_rm,
  input  wire logic [TAG_W-1:0] in_tag,
  // response
  output logic                  out_valid,
  input  wire logic             out_ready,
  output logic      [31:0]      out_result,
  output logic      [4:0]       out_flags,
  output logic      [TAG_W-1:0] out_tag
);
  /* verilator lint_off UNUSEDPARAM */
  localparam int LATENCY = 1 + {31'd0, PIPE_CFG[0]} + {31'd0, PIPE_CFG[1]} + {31'd0, PIPE_CFG[2]}
                             + {31'd0, PIPE_CFG[3]} + {31'd0, PIPE_CFG[4]};
  /* verilator lint_on UNUSEDPARAM */

  localparam int W1 = fp32_fma_pkg::P_UNPACK_W + TAG_W;
  localparam int W2 = fp32_fma_pkg::P_PREP_W   + TAG_W;
  localparam int W3 = fp32_fma_pkg::P_MUL_W    + TAG_W;
  localparam int W4 = fp32_fma_pkg::P_ADD_W    + TAG_W;
  localparam int W5 = fp32_fma_pkg::P_NORM_W   + TAG_W;
  localparam int W6 = 32 + 5 + TAG_W;

  // handshake chain: v[k]/r[k] are the valid/ready entering boundary k+1
  logic v0, r0, v1, r1, v2, r2, v3, r3, v4, r4, v5, r5;
  logic [TAG_W-1:0] tag1, tag2, tag3, tag4, tag5;

  assign v0       = in_valid;
  assign in_ready = r0;

  // ===========================================================================
  // STEP 1 -- classification and unpacking
  // ===========================================================================
  fp32_fma_pkg::p_unpack_t s1_d, s1_q;

  fp32_fma_unpack u_unpack_a (.x(in_a), .sign(s1_d.a_sign), .exp_eff(s1_d.a_exp),
    .sig(s1_d.a_sig), .is_zero(s1_d.a_zero), .is_inf(s1_d.a_inf),
    .is_nan(s1_d.a_nan), .is_snan(s1_d.a_snan));
  fp32_fma_unpack u_unpack_b (.x(in_b), .sign(s1_d.b_sign), .exp_eff(s1_d.b_exp),
    .sig(s1_d.b_sig), .is_zero(s1_d.b_zero), .is_inf(s1_d.b_inf),
    .is_nan(s1_d.b_nan), .is_snan(s1_d.b_snan));
  fp32_fma_unpack u_unpack_c (.x(in_c), .sign(s1_d.c_sign), .exp_eff(s1_d.c_exp),
    .sig(s1_d.c_sig), .is_zero(s1_d.c_zero), .is_inf(s1_d.c_inf),
    .is_nan(s1_d.c_nan), .is_snan(s1_d.c_snan));
  assign s1_d.rm = in_rm;

  logic [W1-1:0] r1_dn;
  fp32_fma_stage #(.W(W1), .REG(PIPE_CFG[0])) u_r1 (
    .clk(clk), .rst_n(rst_n),
    .up_valid(v0), .up_ready(r0), .up_data({in_tag, s1_d}),
    .dn_valid(v1), .dn_ready(r1), .dn_data(r1_dn));
  assign {tag1, s1_q} = r1_dn;

  // ===========================================================================
  // STEP 2 -- exponent and significand preparation, special cases
  // ===========================================================================
  fp32_fma_pkg::p_prep_t s2_d, s2_q;

  fp32_fma_prep #(.NAN_PROPAGATE(NAN_PROPAGATE)) u_prep (
    .a_sign(s1_q.a_sign),    .b_sign(s1_q.b_sign),    .c_sign(s1_q.c_sign),
    .a_exp(s1_q.a_exp),  .b_exp(s1_q.b_exp),  .c_exp(s1_q.c_exp),
    .a_sig(s1_q.a_sig),      .b_sig(s1_q.b_sig),      .c_sig(s1_q.c_sig),
    .a_zero(s1_q.a_zero), .b_zero(s1_q.b_zero), .c_zero(s1_q.c_zero),
    .a_inf(s1_q.a_inf),   .b_inf(s1_q.b_inf),   .c_inf(s1_q.c_inf),
    .a_nan(s1_q.a_nan),   .b_nan(s1_q.b_nan),   .c_nan(s1_q.c_nan),
    .a_snan(s1_q.a_snan), .b_snan(s1_q.b_snan), .c_snan(s1_q.c_snan),
    .rm_in(s1_q.rm),
    .ma(s2_d.ma), .mb(s2_d.mb), .mc(s2_d.mc), .shamt(s2_d.shamt), .x0(s2_d.x0),
    .sp(s2_d.sp), .sc(s2_d.sc), .rm(s2_d.rm),
    .spec_valid(s2_d.spec_valid), .spec_nv(s2_d.spec_nv), .spec_result(s2_d.spec_result));

  logic [W2-1:0] r2_dn;
  fp32_fma_stage #(.W(W2), .REG(PIPE_CFG[1])) u_r2 (
    .clk(clk), .rst_n(rst_n),
    .up_valid(v1), .up_ready(r1), .up_data({tag1, s2_d}),
    .dn_valid(v2), .dn_ready(r2), .dn_data(r2_dn));
  assign {tag2, s2_q} = r2_dn;

  // ===========================================================================
  // STEP 3 -- multiplication   ||   STEP 4 -- addend alignment
  // ===========================================================================
  fp32_fma_pkg::p_mul_t s3_d, s3_q;

  fp32_fma_mul   u_mul   (.a(s2_q.ma), .b(s2_q.mb), .p(s3_d.prod));
  fp32_fma_align u_align (.mc(s2_q.mc), .shamt(s2_q.shamt),
                          .aligned(s3_d.addend), .sticky(s3_d.sticky));
  assign s3_d.x0   = s2_q.x0;
  assign s3_d.sp   = s2_q.sp;
  assign s3_d.sc   = s2_q.sc;
  assign s3_d.rm   = s2_q.rm;
  assign s3_d.spec_valid  = s2_q.spec_valid;
  assign s3_d.spec_nv     = s2_q.spec_nv;
  assign s3_d.spec_result = s2_q.spec_result;

  logic [W3-1:0] r3_dn;
  fp32_fma_stage #(.W(W3), .REG(PIPE_CFG[2])) u_r3 (
    .clk(clk), .rst_n(rst_n),
    .up_valid(v2), .up_ready(r2), .up_data({tag2, s3_d}),
    .dn_valid(v3), .dn_ready(r3), .dn_data(r3_dn));
  assign {tag3, s3_q} = r3_dn;

  // ===========================================================================
  // STEP 5 -- signed accumulation
  // ===========================================================================
  fp32_fma_pkg::p_add_t s4_d, s4_q;

  fp32_fma_add u_add (.prod(s3_q.prod), .addend(s3_q.addend), .sticky(s3_q.sticky),
                      .sp(s3_q.sp), .sc(s3_q.sc), .mag(s4_d.mag), .sign(s4_d.sign));
  assign s4_d.sticky = s3_q.sticky;
  assign s4_d.x0     = s3_q.x0;
  assign s4_d.rm     = s3_q.rm;
  assign s4_d.spec_valid  = s3_q.spec_valid;
  assign s4_d.spec_nv     = s3_q.spec_nv;
  assign s4_d.spec_result = s3_q.spec_result;

  logic [W4-1:0] r4_dn;
  fp32_fma_stage #(.W(W4), .REG(PIPE_CFG[3])) u_r4 (
    .clk(clk), .rst_n(rst_n),
    .up_valid(v3), .up_ready(r3), .up_data({tag3, s4_d}),
    .dn_valid(v4), .dn_ready(r4), .dn_data(r4_dn));
  assign {tag4, s4_q} = r4_dn;

  // ===========================================================================
  // STEP 6 -- normalisation
  // ===========================================================================
  fp32_fma_pkg::p_norm_t s5_d, s5_q;

  fp32_fma_norm u_norm (.mag(s4_q.mag), .x0(s4_q.x0),
                        .mn(s5_d.mn), .e_pk(s5_d.e_pk), .dsh(s5_d.dsh), .subn(s5_d.subn),
                        .e_lt0(s5_d.e_lt0), .e_eq0(s5_d.e_eq0), .e_ge255(s5_d.e_ge255),
                        .e_eq254(s5_d.e_eq254), .zero(s5_d.zero));
  assign s5_d.sticky = s4_q.sticky;
  assign s5_d.sign   = s4_q.sign;
  assign s5_d.rm     = s4_q.rm;
  assign s5_d.spec_valid  = s4_q.spec_valid;
  assign s5_d.spec_nv     = s4_q.spec_nv;
  assign s5_d.spec_result = s4_q.spec_result;

  logic [W5-1:0] r5_dn;
  fp32_fma_stage #(.W(W5), .REG(PIPE_CFG[4])) u_r5 (
    .clk(clk), .rst_n(rst_n),
    .up_valid(v4), .up_ready(r4), .up_data({tag4, s5_d}),
    .dn_valid(v5), .dn_ready(r5), .dn_data(r5_dn));
  assign {tag5, s5_q} = r5_dn;

  // ===========================================================================
  // STEP 7 -- rounding,  STEP 8 -- exceptions,  STEP 9 -- packing
  // ===========================================================================
  logic [23:0] sig_f;
  logic [7:0]  exp_f;
  logic        carry, inexact, tiny, overflow;
  logic [31:0] result_d;
  logic [4:0]  flags_d;

  fp32_fma_round #(.TININESS_AFTER_ROUNDING(TININESS_AFTER_ROUNDING)) u_round (
    .mn(s5_q.mn), .e_pk(s5_q.e_pk), .dsh(s5_q.dsh), .subn(s5_q.subn),
    .e_lt0(s5_q.e_lt0), .e_eq0(s5_q.e_eq0), .sticky(s5_q.sticky), .sign(s5_q.sign),
    .rm(s5_q.rm), .sig_f(sig_f), .exp_f(exp_f), .carry(carry), .inexact(inexact),
    .tiny(tiny));

  fp32_fma_except u_except (
    .e_ge255(s5_q.e_ge255), .e_eq254(s5_q.e_eq254), .carry(carry),
    .inexact(inexact), .tiny(tiny), .zero(s5_q.zero),
    .spec_valid(s5_q.spec_valid), .spec_nv(s5_q.spec_nv),
    .overflow(overflow), .flags(flags_d));

  fp32_fma_pack u_pack (
    .sign(s5_q.sign), .sig_f(sig_f), .exp_f(exp_f), .overflow(overflow),
    .zero(s5_q.zero), .rm(s5_q.rm), .spec_valid(s5_q.spec_valid),
    .spec_result(s5_q.spec_result), .result(result_d));

  // output register (always present)
  logic [W6-1:0] r6_dn;
  fp32_fma_stage #(.W(W6), .REG(1'b1)) u_r6 (
    .clk(clk), .rst_n(rst_n),
    .up_valid(v5), .up_ready(r5), .up_data({tag5, flags_d, result_d}),
    .dn_valid(out_valid), .dn_ready(out_ready), .dn_data(r6_dn));
  assign {out_tag, out_flags, out_result} = r6_dn;

  // ===========================================================================
  // Datapath invariants (simulation only; enabled with +define+FP32_FMA_ASSERT)
  // ===========================================================================
`ifdef FP32_FMA_ASSERT
  // sticky from alignment implies the product dominates (fp32_fma_align),
  // hence the sum magnitude keeps its leading one at bit 45 or above, and an
  // effective subtraction never needs the (exact) C - P path.
  always_comb begin
    if (v3 && !s3_q.spec_valid && s3_q.sticky) begin
      assert (s4_d.mag[74:45] != '0)
        else $error("fp32_fma: sticky set but magnitude below 2^45");
      assert (!((s3_q.sp ^ s3_q.sc) && (s4_d.sign == s3_q.sc)))
        else $error("fp32_fma: sticky set on the C - P path");
    end
    if (v5 && !s5_q.spec_valid && s5_q.zero)
      assert (!s5_q.sticky) else $error("fp32_fma: zero sum with sticky");
  end
`endif

endmodule

`default_nettype wire
