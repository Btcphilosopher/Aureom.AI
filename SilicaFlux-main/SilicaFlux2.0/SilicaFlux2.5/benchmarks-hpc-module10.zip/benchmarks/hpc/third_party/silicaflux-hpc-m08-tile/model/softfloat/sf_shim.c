/* =============================================================================
 * SilicaFlux-HPC Module 08 :: SoftFloat-3e shim for the model self-test
 * (scripts/selftest_model.py).  Berkeley SoftFloat Release 3e, RISC-V
 * specialisation (canonical NaN 0x7FC00000), tininess after rounding.
 * Used ONLY to cross-check model/fp32_model.py; the RTL is compared against
 * the Python model.
 * flags out: {NV,DZ,OF,UF,NX} = bits 4..0
 * ========================================================================== */
#include <stdint.h>
#include "softfloat.h"

static uint_fast8_t rmap(unsigned rm) {
    switch (rm) { case 1: return softfloat_round_minMag; case 2: return softfloat_round_min;
                  case 3: return softfloat_round_max; case 4: return softfloat_round_near_maxMag;
                  default: return softfloat_round_near_even; }
}
static unsigned fmap(uint_fast8_t f) {
    unsigned r = 0;
    if (f & softfloat_flag_inexact)   r |= 1u;
    if (f & softfloat_flag_underflow) r |= 2u;
    if (f & softfloat_flag_overflow)  r |= 4u;
    if (f & softfloat_flag_infinite)  r |= 8u;
    if (f & softfloat_flag_invalid)   r |= 16u;
    return r;
}
static void pre(unsigned rm) {
    softfloat_roundingMode = rmap(rm);
    softfloat_detectTininess = softfloat_tininess_afterRounding;
    softfloat_exceptionFlags = 0;
}
static float32_t F(uint32_t v) { float32_t r; r.v = v; return r; }

/* op: 1 add 2 sub 3 mul 4 fmadd 5 fmsub 6 fnmsub 7 fnmadd 10 eq 11 lt 12 le */
uint32_t sf_op(unsigned op, uint32_t a, uint32_t b, uint32_t c, unsigned rm, unsigned *flags) {
    uint32_t r = 0;
    pre(rm);
    switch (op) {
    case 1:  r = f32_add(F(a), F(b)).v; break;
    case 2:  r = f32_sub(F(a), F(b)).v; break;
    case 3:  r = f32_mul(F(a), F(b)).v; break;
    case 4:  r = f32_mulAdd(F(a), F(b), F(c)).v; break;
    case 5:  r = f32_mulAdd(F(a), F(b), F(c ^ 0x80000000u)).v; break;
    case 6:  r = f32_mulAdd(F(a ^ 0x80000000u), F(b), F(c)).v; break;
    case 7:  r = f32_mulAdd(F(a ^ 0x80000000u), F(b), F(c ^ 0x80000000u)).v; break;
    case 10: r = f32_eq(F(a), F(b)); break;
    case 11: r = f32_lt(F(a), F(b)); break;
    case 12: r = f32_le(F(a), F(b)); break;
    default: break;
    }
    *flags = fmap(softfloat_exceptionFlags);
    return r;
}
