#!/usr/bin/env python3
"""Firmware-level SoC simulation: the SilicaFlux-V CPU (RV32I) controls the HPC tile.

Builds soc/tb/tb_soc_hpc.sv (Verilator, same flags as DataFabric scripts/datafabric/soc_regress.py) around
soc/rtl/sfv_soc_hpc.sv = unmodified SilicaFlux-V CPU, boot ROM, peripherals, DataFabric crossbar and DMA,
plus silicaflux_hpc_tile; runs
  * hpc_demo (sw/examples/hpc_demo): the host-control example -- the CPU drives the tile through its
    registers and its scratchpad window only; every result checked against the reference model;
  * the unmodified SilicaFlux-V acceptance app and the DataFabric DMA demo on the same SoC (the original
    system still works with the tile added).
Writes reports/soc.{md,json} and UART logs to reports/soc_logs/.  Exit 1 on any failure.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402
import files as F  # noqa: E402

ROOT = C.ROOT
DF = F.DF
LOGS = C.REPORTS / "soc_logs"


def soc_files():
    sfv = [DF / "third_party/silicaflux-v" / l.strip() for l in (DF / "third_party/silicaflux-v/rtl/files.f").read_text().split() if l.strip()]
    df = [ROOT / "soc/gen/generated/sfb_memmap_pkg.sv"] + [DF / "rtl/interconnect" / f for f in (
        "sfb_arbiter.sv", "sfb_addr_decoder.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv", "sfb_error_slave.sv",
        "sfb_skid_buffer.sv", "sfb_reg_slice.sv", "sfb_v1_slave_adapter.sv", "sfb_crossbar.sv",
        "sfb_perf_counters.sv")] + [DF / "rtl/dma" / f for f in (
        "dma_validate.sv", "dma_fifo.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv", "dma_irq.sv",
        "dma_control_regs.sv", "silicaflux_dma.sv")] + [DF / "rtl/mem/sfb_sram_slave.sv", DF / "rtl/mem/sfb_sram_1r1w_slave.sv"]
    tile = [f for f in F.TILE_SYNTH if f not in F.DMA_ENGINE]       # dma engines already listed above
    return F.SRAMLIB + sfv + df + tile + [ROOT / "soc/rtl/sfv_soc_hpc.sv", C.BUILD / "fw/sfv_bootrom_image.sv",
                                          DF / "tb/common/sfb_trace_monitor.sv", ROOT / "soc/tb/tb_soc_hpc.sv"]


def build(params: dict, name: str) -> Path:
    obj = C.BUILD / "soc" / name
    obj.mkdir(parents=True, exist_ok=True)
    inc = [f"-I{p}" for p in [DF / "rtl/dma", DF / "rtl/interconnect"] + F.INCDIRS]
    cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-O2", "-j", "4", "-Wno-fatal",
           "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "--top-module", "tb_soc_hpc", "-Mdir", str(obj),
           "-o", "vtb"] + inc + [f"-G{k}={v}" for k, v in params.items()] + [str(f) for f in soc_files()]
    r = subprocess.run(cmd, capture_output=True, text=True)
    (obj / "build.log").write_text(" ".join(cmd) + "\n" + r.stdout + r.stderr)
    if r.returncode != 0:
        raise RuntimeError(f"SoC build failed: {obj / 'build.log'}\n{r.stderr[-2500:]}")
    return obj / "vtb"


SCEN = [
    ("baseline", "hpc_demo_sram_boot", ["+boot=3", "+sram=build/fw/hpc_demo_sram.hex", "+maxcyc=40000000"]),
    ("baseline", "sfv_app_sram_boot (unmodified SilicaFlux-V acceptance app)", ["+boot=3", "+sram=build/fw/sfv_app_sram.hex"]),
    ("baseline", "dma_demo_sram_boot (unmodified DataFabric DMA demo)", ["+boot=3", "+sram=build/fw/dma_demo_sram.hex"]),
    ("baseline", "rom_post_selftest (boot ROM POST, MBIST)", ["+boot=2"]),
    ("lanes2_buffered", "hpc_demo_sram_boot", ["+boot=3", "+sram=build/fw/hpc_demo_sram.hex", "+maxcyc=40000000"]),
]
VARIANTS = {"baseline": {}, "lanes2_buffered": {"HPC_LANES": 2, "HPC_BANKS": 2, "HPC_DMA_BUFFER": 8}}


def main():
    subprocess.run([sys.executable, str(ROOT / "scripts/gen_fw_data.py")], check=True)
    subprocess.run(["make", "-C", str(ROOT / "sw")], check=True, capture_output=True)
    subprocess.run([sys.executable, str(ROOT / "soc/derive_soc.py")], check=True)
    LOGS.mkdir(parents=True, exist_ok=True)
    exes = {v: build(p, v) for v, p in VARIANTS.items()}
    res = []
    for v, name, args in SCEN:
        tag = (v + "__" + name.split()[0])
        log = LOGS / f"{tag}.uart.log"
        t0 = time.time()
        r = subprocess.run([str(exes[v])] + args + [f"+log={log}"], cwd=ROOT, capture_output=True, text=True, timeout=7200)
        (LOGS / f"{tag}.sim.log").write_text(r.stdout[-30000:] + r.stderr[-5000:])
        line = next((l for l in r.stdout.splitlines() if "TB_SOC RESULT" in l), "NO RESULT")
        uart = log.read_text() if log.exists() else ""
        fw = [l for l in uart.splitlines() if l.startswith("[") or "RESULT" in l or "PASS" in l or "FAIL" in l]
        ok = "RESULT PASS" in line
        note = ""
        if not ok and name.startswith("dma_demo"):
            # The ONE expected deviation: dma_demo check 0x105 asserts that the DataFabric performance block
            # counts 4 crossbar masters; sfv_soc_hpc has 5 by design (master 4 = the HPC tile DMA).
            fails = [l.strip() for l in uart.splitlines() if l.strip().startswith("FAIL id=")]
            if fails == ["FAIL id=00000105 got=00000005 exp=00000004"] and "status=00000102" in line:
                ok, note = True, "PASS except the expected check 0x105 (crossbar master count 5, not 4)"
        res.append(dict(variant=v, params=VARIANTS[v], scenario=name, ok=ok, result=line, note=note,
                        firmware=fw[-14:], secs=round(time.time() - t0, 1)))
        print(f"{'PASS' if res[-1]['ok'] else 'FAIL'} {v:16s} {name:60s} {line} {note}")
    n = sum(r["ok"] for r in res)
    (C.REPORTS / "soc.json").write_text(json.dumps(dict(tools=C.tool_versions(), runs=res), indent=1))
    L = ["# Firmware-level SoC simulation (SilicaFlux-V CPU + DataFabric + HPC tile)", "",
         f"Tools: {C.tool_versions()['verilator']}; firmware: clang/lld (RV32I_Zicsr).", "",
         "| SoC variant | scenario | result | wall time |", "|---|---|---|---|"]
    for r in res:
        L.append(f"| {r['variant']} {r['params'] or ''} | {r['scenario']} | {'PASS' if r['ok'] else 'FAIL'}: `{r['result']}` "
                 f"{r['note']} | {r['secs']} s |")
    L += ["", f"**{n} / {len(res)} passed.**", "", "## Firmware transcripts (UART, last lines)", ""]
    for r in res:
        L += [f"### {r['variant']} / {r['scenario']}", "", "```"] + r["firmware"] + ["```", ""]
    (C.REPORTS / "soc.md").write_text("\n".join(L) + "\n")
    sys.exit(0 if n == len(res) else 1)


if __name__ == "__main__":
    main()
