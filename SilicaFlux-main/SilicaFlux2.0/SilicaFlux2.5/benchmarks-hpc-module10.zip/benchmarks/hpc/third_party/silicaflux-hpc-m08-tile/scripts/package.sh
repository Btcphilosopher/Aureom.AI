#!/usr/bin/env bash
# Package the Module 08 deliverable as a zip (sources, scripts, docs, reports, vendored third-party subset).
# Excludes build outputs and the large intermediate P&R netlists (ecp5.json, pnr.config); their logs,
# statistics and critical-path reports are kept.  usage: scripts/package.sh [OUT.zip]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NAME="$(basename "$ROOT")"
OUT="${1:-$ROOT/../$NAME.zip}"
cd "$ROOT/.."
rm -f "$OUT"
python3 "$ROOT/scripts/gen_headers.py" --check
python3 "$ROOT/soc/derive_soc.py" --check
(cd "$ROOT/third_party" && sha256sum -c --quiet SHA256SUMS)
find "$NAME" -type f \
  ! -path "$NAME/build/*" ! -name '*.pyc' ! -path '*/__pycache__/*' \
  ! -name 'ecp5.json' ! -name 'pnr.config' ! -name '*.ok' \
  | sort > "$NAME/MANIFEST.txt.tmp"
( cd "$NAME" && sed "s|^$NAME/||" MANIFEST.txt.tmp | grep -v '^MANIFEST' | xargs sha256sum > MANIFEST.sha256 )
rm "$NAME/MANIFEST.txt.tmp"
find "$NAME" -type f ! -path "$NAME/build/*" ! -name '*.pyc' ! -path '*/__pycache__/*' \
  ! -name 'ecp5.json' ! -name 'pnr.config' ! -name '*.ok' | sort | zip -q -X "$OUT" -@
echo "wrote $OUT ($(du -h "$OUT" | cut -f1), $(unzip -l "$OUT" | tail -1 | awk '{print $2}') files)"
