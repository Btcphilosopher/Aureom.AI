#!/usr/bin/env python3
"""Self-test of the independent FP32 reference model (model/fp32_model.py).

1. numpy float32 (host IEEE hardware, RNE, no FTZ): FADD / FSUB / FMUL results on random + subnormal
   operands (finite inputs, finite or infinite results).
2. Berkeley SoftFloat-3e (RISC-V specialisation, tininess after rounding): FADD, FSUB, FMUL, the four FMA
   forms, FEQ / FLT / FLE -- results AND flags, all five rounding modes, random + special operands
   (zeros, subnormals, min-normal boundary, max finite, infinities, quiet and signalling NaNs).
3. Hand-written corner cases from Module 02 docs/FP_SEMANTICS.md (tininess-after-rounding examples, zero
   signs, FMA zero product, 0 x inf with a quiet-NaN addend).
Writes reports/model_selftest.md; exit 1 on any mismatch.
"""
import ctypes
import random
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "model"))
import fp32_model as M  # noqa: E402

N_RANDOM = int(sys.argv[1]) if len(sys.argv) > 1 else 40000

SPECIALS = [0x00000000, 0x80000000, 0x00000001, 0x80000001, 0x007FFFFF, 0x807FFFFF, 0x00800000, 0x80800000,
            0x00800001, 0x3F800000, 0xBF800000, 0x7F7FFFFF, 0xFF7FFFFF, 0x7F800000, 0xFF800000, 0x7FC00000,
            0xFFC00000, 0x7F800001, 0xFFA00000, 0x7FBFFFFF, 0x34000000, 0x33800000, 0x4B800000, 0x3F7FFFFF,
            0x01000000, 0x0C000000, 0x73800000, 0x5F000000]


def rnd_operand(rng):
    k = rng.random()
    if k < 0.15:
        return rng.choice(SPECIALS)
    if k < 0.30:
        return (rng.getrandbits(1) << 31) | rng.getrandbits(23)                       # subnormal
    if k < 0.45:                                                                      # near min normal / overflow
        e = rng.choice([1, 2, 3, 24, 25, 252, 253, 254])
        return (rng.getrandbits(1) << 31) | (e << 23) | rng.getrandbits(23)
    if k < 0.65:                                                                      # similar exponents (cancellation)
        e = rng.randint(120, 134)
        return (rng.getrandbits(1) << 31) | (e << 23) | rng.getrandbits(23)
    return rng.getrandbits(32)


def main():
    rep = ["# FP32 reference model self-test", "",
           f"Model: `model/fp32_model.py`. Run: {time.strftime('%Y-%m-%d %H:%M:%S')}", ""]
    bad = 0
    rng = random.Random(20261107)

    # ---------------------------------------------------------------- 1. numpy
    import numpy as np
    n_np = 0
    with np.errstate(all="ignore"):
        for _ in range(N_RANDOM):
            a, b = rnd_operand(rng), rnd_operand(rng)
            if M.is_nan(a) or M.is_nan(b) or M.is_inf(a) or M.is_inf(b):
                continue
            fa = np.array([a], dtype=np.uint32).view(np.float32)
            fb = np.array([b], dtype=np.uint32).view(np.float32)
            for op, ref in ((M.OP_FADD, fa + fb), (M.OP_FSUB, fa - fb), (M.OP_FMUL, fa * fb)):
                r = int(ref.view(np.uint32)[0])
                m, _ = M.elem(op, a, b, 0, M.RNE)
                if M.is_nan(r) and M.is_nan(m):
                    r = m
                n_np += 1
                if r != m:
                    bad += 1
                    if bad < 20:
                        print(f"numpy mismatch op {op:#x} a={a:08x} b={b:08x} hw={r:08x} model={m:08x}")
    rep += [f"## 1. numpy float32 (hardware, RNE)", "", f"{n_np} FADD/FSUB/FMUL results compared, "
            f"{'0 mismatches' if bad == 0 else str(bad) + ' MISMATCHES'}.", ""]

    # ---------------------------------------------------------------- 2. SoftFloat
    lib_path = subprocess.run(["bash", str(ROOT / "model/softfloat/build.sh")], check=True,
                              capture_output=True, text=True).stdout.strip().splitlines()[-1]
    lib = ctypes.CDLL(lib_path)
    lib.sf_op.restype = ctypes.c_uint32
    lib.sf_op.argtypes = [ctypes.c_uint, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint,
                          ctypes.POINTER(ctypes.c_uint)]
    ops = [M.OP_FADD, M.OP_FSUB, M.OP_FMUL, M.OP_FMADD, M.OP_FMSUB, M.OP_FNMSUB, M.OP_FNMADD,
           M.OP_FEQ, M.OP_FLT, M.OP_FLE]
    bad_sf = 0
    per_op = {op: 0 for op in ops}
    fl = ctypes.c_uint(0)
    for i in range(N_RANDOM):
        a, b, c = rnd_operand(rng), rnd_operand(rng), rnd_operand(rng)
        if i % 7 == 0:                                   # force exact cancellation / zero products
            c = (M.fmul(a, b, M.RTZ)[0] ^ 0x80000000) if not M.is_nan(a) else c
        for op in ops:
            rm = rng.randint(0, 4)
            r = lib.sf_op(op, a, b, c, rm, ctypes.byref(fl))
            m, mf = M.elem(op, a, b, c, rm)
            per_op[op] += 1
            if r != m or fl.value != mf:
                bad_sf += 1
                if bad_sf < 30:
                    print(f"softfloat mismatch {M.OP_NAMES[op]} rm={rm} a={a:08x} b={b:08x} c={c:08x} "
                          f"sf={r:08x}/{fl.value:05b} model={m:08x}/{mf:05b}")
    bad += bad_sf
    rep += ["## 2. Berkeley SoftFloat-3e (RISC-V specialisation), results and flags", "",
            "| op | vectors (random rounding mode) |", "|---|---|"]
    rep += [f"| {M.OP_NAMES[op]} | {per_op[op]} |" for op in ops]
    rep += ["", f"Mismatches: **{bad_sf}**.", ""]

    # ---------------------------------------------------------------- 3. corner cases
    corner = [
        # (op, a, b, c, rm, expected bits, expected flags, note)
        (M.OP_FMUL, 0x00FFFFFF, 0x3F000000, 0, M.RNE, 0x00800000, M.UF | M.NX,
         "(2^24-1)*2^-150 rounds to min normal and IS tiny after rounding"),
        (M.OP_FADD, 0x3F800000, 0xBF800000, 0, M.RNE, 0x00000000, 0, "x - x = +0"),
        (M.OP_FADD, 0x3F800000, 0xBF800000, 0, M.RDN, 0x80000000, 0, "x - x = -0 under RDN"),
        (M.OP_FADD, 0x80000000, 0x80000000, 0, M.RNE, 0x80000000, 0, "-0 + -0 = -0"),
        (M.OP_FMADD, 0x00000000, 0x7F800000, 0x7FC00000, M.RNE, 0x7FC00000, M.NV, "0 x inf + qNaN raises NV"),
        (M.OP_FMADD, 0x00000000, 0x3F800000, 0x80000000, M.RNE, 0x00000000, 0, "(+0)*1 + (-0) = +0 (zero product, opposite signs)"),
        (M.OP_FMADD, 0x80000000, 0x3F800000, 0x80000000, M.RNE, 0x80000000, 0, "(-0)*1 + (-0) = -0 (zero product, equal signs)"),
        (M.OP_FMADD, 0x00000000, 0x3F800000, 0x80000000, M.RDN, 0x80000000, 0, "(+0)*1 + (-0) = -0 under RDN"),
        (M.OP_FMSUB, 0x80000000, 0x3F800000, 0x00000000, M.RNE, 0x80000000, 0, "-0*1 - +0 = -0"),
        (M.OP_FMIN, 0x00000000, 0x80000000, 0, M.RNE, 0x80000000, 0, "min(+0, -0) = -0"),
        (M.OP_FMAX, 0x7F800001, 0x3F800000, 0, M.RNE, 0x3F800000, M.NV, "max(sNaN, 1) = 1, NV"),
        (M.OP_FEQ, 0x7FC00000, 0x7FC00000, 0, M.RNE, 0, 0, "FEQ quiet on qNaN"),
        (M.OP_FLT, 0x7FC00000, 0x3F800000, 0, M.RNE, 0, M.NV, "FLT signalling on qNaN"),
        (M.OP_FADD, 0x7F7FFFFF, 0x7F7FFFFF, 0, M.RTZ, 0x7F7FFFFF, M.OF | M.NX, "overflow under RTZ -> max finite"),
        (M.OP_FMUL, 0x7F7FFFFF, 0x40000000, 0, M.RNE, 0x7F800000, M.OF | M.NX, "overflow under RNE -> inf"),
    ]
    rep += ["## 3. Specification corner cases (Module 02 FP_SEMANTICS.md)", "", "| case | result |", "|---|---|"]
    for op, a, b, c, rm, eb, ef, note in corner:
        m, mf = M.elem(op, a, b, c, rm)
        ok = (m == eb and mf == ef)
        bad += 0 if ok else 1
        rep.append(f"| {note} | {'PASS' if ok else f'FAIL ({m:08x}/{mf:05b})'} |")
    # reduction order example: N = 1 equals the sequential loop
    xs = [M.f2b(v) for v in (1e8, 1.0, -1e8, 3.5)]
    seq = M.f2b(0.0)
    for x in xs:
        seq = M.fadd(seq, x, M.RNE)[0]
    red, _ = M.reduce_sum(xs, 1, M.f2b(0.0), M.RNE)
    ok = red == seq
    bad += 0 if ok else 1
    rep.append(f"| reduction with N = 1 equals the sequential FP32 loop | {'PASS' if ok else 'FAIL'} |")
    rep += ["", f"**Total mismatches: {bad}** -> {'PASS' if bad == 0 else 'FAIL'}"]
    out = ROOT / "reports/model_selftest.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(rep) + "\n")
    print(f"model self-test: numpy {n_np} vectors, SoftFloat {sum(per_op.values())} vectors, "
          f"{len(corner) + 1} corner cases; mismatches {bad} -> {'PASS' if bad == 0 else 'FAIL'}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
