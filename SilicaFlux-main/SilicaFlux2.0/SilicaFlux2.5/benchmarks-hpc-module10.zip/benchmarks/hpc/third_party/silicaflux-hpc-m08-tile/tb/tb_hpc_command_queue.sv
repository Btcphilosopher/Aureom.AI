// =============================================================================
// SilicaFlux-HPC Module 08 :: tb_hpc_command_queue
// Self-checking unit test of hpc_command_queue: random push/pop with random
// back-pressure against a SystemVerilog queue model; checks FIFO order, no
// loss / duplication, level / full / empty every cycle, out_data stability
// under back-pressure, simultaneous push+pop, and asynchronous reset in the
// middle of traffic.  Prints "TB_CQ RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_hpc_command_queue;
  parameter int WIDTH = 37;
  parameter int DEPTH = 4;
  localparam int CW = $clog2(DEPTH + 1);

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic             in_valid, in_ready, out_valid, out_ready, full, empty;
  logic [WIDTH-1:0] in_data, out_data;
  logic [CW-1:0]    level;

  hpc_command_queue #(.WIDTH(WIDTH), .DEPTH(DEPTH)) dut (.*);

  logic [WIDTH-1:0] model[$];
  int unsigned seed0, seed = 1, errors = 0, pushes = 0, pops = 0, resets = 0, both = 0;
  logic [WIDTH-1:0] held;
  logic             held_v;

  function automatic logic [WIDTH-1:0] rnd_word();
    logic [WIDTH-1:0] w;
    for (int i = 0; i < WIDTH; i += 32) w[i +: 32] = $urandom();
    rnd_word = w;
  endfunction

  task automatic fail(input string msg);
    errors++;
    if (errors < 10) $display("ERROR @%0t: %s", $time, msg);
  endtask

  int cycle = 0;
  int unsigned p_in, p_out;
  initial begin
    void'($value$plusargs("seed=%d", seed));
    seed0 = seed;
    void'($urandom(seed));
    in_valid = 0; out_ready = 0; in_data = '0; held_v = 0;
    repeat (3) @(posedge clk);
    rst_n = 1'b1;
    for (cycle = 0; cycle < 20000; cycle++) begin
      // traffic phases with different push / pop probabilities
      p_in  = (cycle / 1000) % 3 == 0 ? 90 : (cycle / 1000) % 3 == 1 ? 30 : 60;
      p_out = (cycle / 1000) % 3 == 0 ? 30 : (cycle / 1000) % 3 == 1 ? 90 : 60;
      @(negedge clk);
      // H2-style: an offered word is held until accepted
      if (!in_valid || in_ready) begin
        in_valid = ($urandom_range(99) < p_in);
        in_data  = rnd_word();
      end
      out_ready = ($urandom_range(99) < p_out);
      // combinational outputs are functions of state only
      if (in_ready  != (int'(level) < DEPTH)) fail("in_ready != !full");
      if (out_valid != (level != 0))          fail("out_valid != !empty");
      if (full  != (int'(level) == DEPTH))    fail("full flag");
      if (empty != (level == 0))              fail("empty flag");
      if (int'(level) != model.size())        fail($sformatf("level %0d model %0d", level, model.size()));
      if (out_valid && out_data !== model[0]) fail("out_data != oldest entry");
      if (held_v && out_valid && out_data !== held) fail("out_data changed under back-pressure");
      @(posedge clk);
      #1;
      if (out_valid && !out_ready) begin held_v = 1; held = out_data; end else held_v = 0;
      // random asynchronous reset in the middle of traffic (rare)
      if ($urandom_range(2999) == 0) begin
        #2 rst_n = 1'b0; #1; model.delete(); resets++; held_v = 0;
        if (out_valid || level != 0) fail("queue not cleared by asynchronous reset");
        @(negedge clk); rst_n = 1'b1;
        in_valid = 1'b0;
        if (level != 0 || out_valid) fail("queue not empty after reset");
      end
    end
    $display("TB_CQ pushes=%0d pops=%0d push+pop=%0d resets=%0d", pushes, pops, both, resets);
    if (pushes < 1000 || pops < 1000 || both < 100) fail("insufficient coverage");
    $display("TB_CQ RESULT %s WIDTH=%0d DEPTH=%0d seed=%0d", errors ? "FAIL" : "PASS", WIDTH, DEPTH, seed0);
    $finish;
  end

  // model update at the active edge, from the values sampled at that edge
  bit pu, po;
  always @(posedge clk) if (rst_n) begin
    pu = in_valid && in_ready; po = out_valid && out_ready;
    if (po) begin
      if (model.size() == 0) fail("pop from empty model");
      else void'(model.pop_front());
      pops++;
    end
    if (pu) begin model.push_back(in_data); pushes++; end
    if (pu && po) both++;
  end
endmodule

`default_nettype wire
