#!/usr/bin/env python3
"""Mutation testing of the NEW Module 08 RTL: inject one realistic bug at a time and check that the
regression detects it (a mutant is KILLED when at least one test fails or times out).

Each mutant is a textual edit that must apply exactly once.  The mutated copy is built in build/mut/<id>/;
the original RTL is never touched.  Integration mutants run a fixed subset of the integration tests on
the stated configuration; queue / counter mutants also run their unit testbenches.
Writes reports/mutation.{md,json}.
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402
import files as F  # noqa: E402
from run_tests import cfg_of, run_one  # noqa: E402

TESTS = ["s1_vec_random", "s1_vec_reduce", "vec_fma", "dma", "ordering", "contention", "invalid", "reset", "perf",
         "backpressure", "kernels_many"]

MUTANTS = [
    # id, file, old, new, description, config
    ("Q1", "hpc_command_queue.sv", "      if (pop)  rp_q <= rp_q + 1'b1;\n", "", "queue: pop does not advance the read pointer", "baseline"),
    ("Q2", "hpc_command_queue.sv", "  assign in_ready  = !full;", "  assign in_ready  = 1'b1;", "queue: accepts a push while full (overwrites)", "baseline"),
    ("P1", "hpc_perf_counters.sv", "        c_q <= sum[CW] ? {CW{1'b1}} : sum[CW-1:0];", "        c_q <= sum[CW-1:0];", "counters: wrap instead of saturating", "unit"),
    ("P2", "hpc_perf_counters.sv", "      else if (clear)                    c_q <= '0;\n", "", "counters: clear ignored", "baseline"),
    ("S1", "hpc_tile_sched.sv", "  wire hz_vec = dma_busy_q && dma_own_q == OWN_DISP && (", "  wire hz_vec = 1'b0 && (", "scheduler: no hazard check for a vector command against the DMA in flight", "baseline"),
    ("S2", "hpc_tile_sched.sv", "  wire hz_dma = vec_busy_q && vec_own_q == OWN_DISP && (", "  wire hz_dma = 1'b0 && (", "scheduler: no hazard check for a DMA against the vector command in flight", "baseline"),
    ("S3", "hpc_tile_sched.sv", "  wire blocked = halted_q || (cfg_halt_on_err && err_known) || quiesce;", "  wire blocked = quiesce;", "scheduler: HALT_ON_ERROR ignored", "baseline"),
    ("S4", "hpc_tile_sched.sv", "    else if ((is_vec || is_ker) && !d_legal)                d_err = `HPC_ST_BAD_OP;", "    else if (1'b0)                                          d_err = `HPC_ST_BAD_OP;", "scheduler: unsupported opcode not rejected", "baseline"),
    ("S5", "hpc_tile_sched.sv", "    else if (rg_bad)                                        d_err = `HPC_ST_SPM_RANGE;", "    else if (1'b0)                                          d_err = `HPC_ST_SPM_RANGE;", "scheduler: scratchpad range not validated", "baseline"),
    ("S6", "hpc_tile_sched.sv", "    else if (ov_bad)                                        d_err = `HPC_ST_OVERLAP;", "    else if (1'b0)                                          d_err = `HPC_ST_OVERLAP;", "scheduler: partial destination overlap accepted", "baseline"),
    ("S7", "hpc_tile_sched.sv", "      KS_LB:   k_after = rd[2] ? KS_LC : KS_CMP;", "      KS_LB:   k_after = KS_CMP;", "kernel: operand C never loaded", "baseline"),
    ("S8", "hpc_tile_sched.sv", "  wire go_base  = dcr_v_q && rob_free && !kernel_busy && (!d_fence || rob_empty);", "  wire go_base  = dcr_v_q && rob_free && !kernel_busy;", "scheduler: FENCE ignored", "baseline"),
    ("S9", "hpc_tile_sched.sv", "        r_st  = dma_cpl_err ? `HPC_ST_DMA_ERR : `HPC_ST_OK;", "        r_st  = `HPC_ST_OK;", "a failed DMA is reported as successful", "baseline"),
    ("S10", "hpc_tile_sched.sv", "  wire d_cancel = dcr_v_q && rob_free && flushing_q && !quiesce;", "  wire d_cancel = 1'b0;", "FLUSH never cancels", "baseline"),
    ("S11", "hpc_tile_sched.sv", "  wire d_ker    = !flushing_q && !blocked && go_base && d_err == `HPC_ST_OK && is_ker && rob_empty &&", "  wire d_ker    = !flushing_q && !blocked && go_base && d_err == `HPC_ST_OK && is_ker &&", "KERNEL starts while older commands are in flight", "baseline"),
    ("S12", "hpc_tile_sched.sv", "            if (dma_cpl_err) begin\n              k_st_q <= `HPC_ST_DMA_ERR;", "            if (1'b0) begin\n              k_st_q <= `HPC_ST_DMA_ERR;", "kernel: a failing DMA step does not stop the kernel", "baseline"),
    ("S13", "hpc_tile_sched.sv", "                     k_len = k_red_q ? 32'd4 : (k_vl_q << 2); end", "                     k_len = k_vl_q << 2; end", "kernel: reduction result stored with the vector length", "baseline"),
    ("L1", "hpc_tile_lsu.sv", "        swstrb[(32'(ssg) * LPW + i) * 4 +: 4]   = {4{smask[i]}};", "        swstrb[(32'(ssg) * LPW + i) * 4 +: 4]   = 4'hF;", "LSU: inactive (tail) lanes written (needs >1 lane per word: DATA_WIDTH 64)", "n4_dw64"),
    ("L2", "hpc_tile_lsu.sv", "    wire             ld_cond = run && !lfin_q && lact && (!lfirst || lcred);", "    wire             ld_cond = run && !lfin_q && lact;", "LSU: operand FIFO credit ignored", "baseline"),
    ("L3", "hpc_tile_lsu.sv", "    wire             st_cond = rb_v_q && !sdone_q[gp] && (smask != '0) && !err_q;", "    wire             st_cond = rb_v_q && !sdone_q[gp] && (smask != '0);", "LSU: results still stored after a scratchpad error", "n4_parity"),
    ("L4", "hpc_tile_lsu.sv", "  wire finished  = cpl_got_q && !rb_v_q && (!red_q || red_iss_q || err_q) && (st_out_q == 8'd0) && (st_inc == 8'd0);", "  wire finished  = cpl_got_q && !rb_v_q && (!red_q || red_iss_q || err_q);", "LSU: completes before its stores are acknowledged (visible with SPM read latency 4)", "n4_rl4"),
    ("L5", "hpc_tile_lsu.sv", "    wire red_cond = (gp == 0) && run && cpl_got_q && red_q && !red_iss_q && !err_q;", "    wire red_cond = 1'b0;", "LSU: reduction result never stored", "baseline"),
    ("L6", "hpc_tile_lsu.sv", "  assign done_status   = err_q ? `HPC_ST_SPM_ERR : cpl_ill_q ? `HPC_ST_ARRAY_ILL : `HPC_ST_OK;", "  assign done_status   = cpl_ill_q ? `HPC_ST_ARRAY_ILL : `HPC_ST_OK;", "a scratchpad error is reported as success", "n4_parity"),
    ("R1", "hpc_tile_regs.sv", "  wire can_submit  = (sr_q == SR_IDLE) && sub_ready;", "  wire can_submit  = (sr_q == SR_IDLE);", "DOORBELL accepted when the queue is full (command lost)", "baseline"),
    ("R2", "hpc_tile_regs.sv", "  assign cplq_pop = wr && (rb_addr == `HPC_REG_CPL_POP) && cplq_valid;", "  assign cplq_pop = 1'b0;", "CPL_POP does not pop", "baseline"),
    ("R3", "hpc_tile_regs.sv", "        SR_QUIESCE: if (sr_quiet) begin sr_q <= SR_RESET; sr_cnt_q <= '0; end", "        SR_QUIESCE: begin sr_q <= SR_RESET; sr_cnt_q <= '0; end", "soft reset without quiescing the bus ports", "baseline"),
    ("T1", "silicaflux_hpc_tile.sv", "      inc[`HPC_PC_DMA_BYTES_RD *PIW +: PIW] = PIW'(dma_ev_bytes_rd);", "      inc[`HPC_PC_DMA_BYTES_RD *PIW +: PIW] = PIW'(dma_ev_bytes_wr);", "counter: DMA_BYTES_RD counts written bytes", "baseline"),
    ("T2", "silicaflux_hpc_tile.sv", "      inc[`HPC_PC_VEC_FLOPS    *PIW +: PIW] = done_hs ? PIW'(done_count) * PIW'(fpe) : '0;", "      inc[`HPC_PC_VEC_FLOPS    *PIW +: PIW] = done_hs ? PIW'(done_count) : '0;", "counter: FLOPs ignore the FMA factor 2", "baseline"),
]


# mutants shown to be EQUIVALENT (no observable behaviour can differ); reported, not counted as survivors
EQUIV = {"S11": "the remaining conditions of d_ker (DMA and vector units idle, no unit request pending) already "
                "imply that no older command is executing; an older NOP / rejected record still in the ROB "
                "retires in order anyway -- removing rob_empty changes no observable behaviour (replaced by S13)"}


def mutate(mid, fname, old, new):
    d = C.BUILD / "mut" / mid
    if d.exists():
        shutil.rmtree(d)
    (d / "rtl").mkdir(parents=True)
    src = (C.ROOT / "rtl" / fname).read_text()
    assert src.count(old) == 1, f"mutant {mid}: target found {src.count(old)} times"
    (d / "rtl" / fname).write_text(src.replace(old, new))
    return d / "rtl" / fname


def run_unit(mfile):
    tb = C.ROOT / "tb/tb_hpc_perf_counters.sv"
    d = mfile.parent.parent
    r = subprocess.run(["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
                        f"-I{C.ROOT / 'rtl'}", f"-I{F.SL}", "--top-module", "tb_hpc_perf_counters", "-Mdir", str(d / "unit"),
                        str(mfile), str(tb), "-o", "sim"], capture_output=True, text=True)
    if r.returncode:
        return False, "unit build failed"
    rr = subprocess.run([str(d / "unit/sim"), "+seed=3"], capture_output=True, text=True, timeout=600)
    ok = "TB_PC RESULT PASS" in rr.stdout
    return ok, "unit tb_hpc_perf_counters " + ("PASS" if ok else "FAIL")


def eval_mutant(m):
    mid, fname, old, new, desc, cfgname = m
    mfile = mutate(mid, fname, old, new)
    if cfgname == "unit":
        ok, info = run_unit(mfile)
        return dict(id=mid, file=fname, desc=desc, config="unit", killed=not ok, by=info if not ok else "")
    files = [mfile if Path(f).name == fname and "/rtl/" in str(f) and "third_party" not in str(f) else f for f in F.TILE_TB]
    cfg = cfg_of(cfgname)
    exe = C.verilator_build("tb_silicaflux_hpc_tile", files, cfg, F.SIM_DEFINES, f"mut_{mid}", jobs=2)
    tdir = C.BUILD / "tests" / f"{cfgname}_s1"
    killed_by = []
    for t in TESTS + (["parity"] if cfgname == "n4_parity" else []):
        if not (tdir / t).exists():
            continue
        r = run_one(exe, "verilator", f"mut_{mid}", t, 1, tdir / t, C.BUILD / "mut" / mid)
        if not r["ok"]:
            killed_by.append(t)
            break                                   # one failing test is enough
    return dict(id=mid, file=fname, desc=desc, config=cfgname, killed=bool(killed_by), by=",".join(killed_by),
                equivalent=EQUIV.get(mid, ""))


def main():
    sel = sys.argv[1].split(",") if len(sys.argv) > 1 else None
    muts = [m for m in MUTANTS if not sel or m[0] in sel]
    res = []
    with cf.ThreadPoolExecutor(max_workers=2) as ex:
        for r in ex.map(eval_mutant, muts):
            print(f"{r['id']:4s} {'KILLED' if r['killed'] else 'SURVIVED':8s} {r['desc']:75s} {r['by']}", flush=True)
            res.append(r)
    if sel and (C.REPORTS / "mutation.json").exists():         # subset run: update those entries only
        prev = {r["id"]: r for r in json.loads((C.REPORTS / "mutation.json").read_text())}
        for r in res:
            prev[r["id"]] = r
        order = [m[0] for m in MUTANTS]
        res = [prev[i] for i in order if i in prev]
    k = sum(r["killed"] for r in res)
    eq = sum(1 for r in res if not r["killed"] and r.get("equivalent"))
    (C.REPORTS / "mutation.json").write_text(json.dumps(res, indent=1))
    L = ["# Mutation testing of the new RTL", "",
         "One injected bug per run; KILLED = at least one regression test failed (or timed out).", "",
         "| id | file | injected bug | config | result | first detecting test |", "|---|---|---|---|---|---|"]
    for r in res:
        st = "**killed**" if r["killed"] else ("equivalent" if r.get("equivalent") else "SURVIVED")
        L.append(f"| {r['id']} | `{r['file']}` | {r['desc']} | {r['config']} | {st} | {r['by'] or r.get('equivalent', '')} |")
    L += ["", f"**{k} / {len(res) - eq} non-equivalent mutants killed** ({eq} equivalent mutant(s) identified and explained)."]
    (C.REPORTS / "mutation.md").write_text("\n".join(L) + "\n")
    print(f"mutation: {k}/{len(res)} killed")


if __name__ == "__main__":
    main()
