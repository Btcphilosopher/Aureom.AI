// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_unpack.sv -- STEP 1: operand classification and unpacking
//
// One instance per operand. Classes are mutually exclusive:
//   zero      exp == 0,   frac == 0
//   subnormal exp == 0,   frac != 0   (sig = {0, frac}, exp_eff = 1)
//   normal    0 < exp < 255           (sig = {1, frac}, exp_eff = exp)
//   infinity  exp == 255, frac == 0
//   NaN       exp == 255, frac != 0; signalling iff frac[22] == 0
//             (IEEE 754-2008 sec. 6.2.1 recommended encoding, as used by
//              RISC-V, x86 and Arm)
// Subnormals are carried with their true value (no flush-to-zero).
// =============================================================================
`default_nettype none

module fp32_fma_unpack (
  input  wire logic [31:0] x,
  output logic             sign,
  output logic [7:0]       exp_eff,
  output logic [23:0]      sig,
  output logic             is_zero,
  output logic             is_inf,
  output logic             is_nan,
  output logic             is_snan
);
  logic [7:0]  e;
  logic [22:0] f;
  logic        e_zero, e_ones, f_zero;

  assign sign   = x[31];
  assign e      = x[30:23];
  assign f      = x[22:0];
  assign e_zero = (e == 8'h00);
  assign e_ones = (e == 8'hFF);
  assign f_zero = (f == 23'd0);

  assign is_zero = e_zero &  f_zero;
  assign is_inf  = e_ones &  f_zero;
  assign is_nan  = e_ones & ~f_zero;
  assign is_snan = is_nan & ~f[22];

  assign exp_eff = e_zero ? 8'd1 : e;
  assign sig     = {~e_zero, f};
endmodule

`default_nettype wire
