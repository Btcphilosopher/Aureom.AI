#!/usr/bin/env python3
"""Synthesis, resource analysis and post-route timing of silicaflux_hpc_tile (Yosys 0.33, nextpnr-ecp5 0.11).

  run_fpga.py [--configs baseline,s1_n2,...] [--pnr baseline] [--jobs J]

Per configuration:
  1. GENERIC  -- Yosys elaboration, latch check, flatten, abc to a simple gate library; memories kept as
                 $mem (memory -nomap) and reported in bits.  Technology independent logic size.
  2. XILINX   -- synth_xilinx (7-series cell library, scratchpad BACKEND = FPGA block-RAM inference):
                 LUT / FF / RAMB / DSP48 counts.  A Yosys mapping estimate: no Vivado run, no timing.
  3. ECP5     -- synth_ecp5 on fpga/hpc_tile_fpga_harness.sv, then (configurations in --pnr)
                 nextpnr-ecp5 place and route on LFE5U-85F CABGA381 (ULX3S, the board the repository's
                 SilicaFlux-V FPGA flow targets) with a 25 MHz clock constraint: utilisation and
                 nextpnr's post-route static timing estimate (Fmax).  No bitstream is programmed, nothing
                 is run on hardware.
Reports: reports/synth/*.log|*.txt (raw), reports/synth.md / synth.json (summary).
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import re
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402
import files as F  # noqa: E402
from run_tests import CONFIGS, DEFAULT  # noqa: E402

SYN = C.REPORTS / "synth"
TILE_PARAMS = ["NUM_LANES", "DATA_WIDTH", "SCRATCHPAD_BYTES", "NUM_BANKS", "CMD_QUEUE_DEPTH", "DMA_BUFFER_DEPTH",
               "ENABLE_PERF_COUNTERS", "CPL_QUEUE_DEPTH", "SPM_ECC", "SPM_READ_LATENCY", "LSU_MAX_PORTS"]
HARNESS_PARAMS = ["NUM_LANES", "DATA_WIDTH", "SCRATCHPAD_BYTES", "NUM_BANKS", "CMD_QUEUE_DEPTH", "DMA_BUFFER_DEPTH",
                  "ENABLE_PERF_COUNTERS"]

LPF = """BLOCK RESETPATHS;
LOCATE COMP "clk" SITE "G2";
IOBUF  PORT "clk" PULLMODE=NONE IO_TYPE=LVCMOS33;
FREQUENCY PORT "clk" 25 MHZ;
LOCATE COMP "btn" SITE "R1";
IOBUF  PORT "btn" PULLMODE=DOWN IO_TYPE=LVCMOS33;
""" + "".join(f'LOCATE COMP "led[{i}]" SITE "{s}";\nIOBUF  PORT "led[{i}]" PULLMODE=NONE IO_TYPE=LVCMOS33 DRIVE=4;\n'
              for i, s in enumerate(["B2", "C2", "C1", "D2", "D1", "E2", "E1", "H3"]))


def cfg_of(name):
    c = dict(DEFAULT)
    c.update(CONFIGS[name])
    return c


def reads(extra=()):
    # -defer: modules are elaborated only through the hierarchy with their actual parameters (as Module 04)
    inc = " ".join(f"-I{p}" for p in F.INCDIRS)
    return f"read_verilog -defer -sv -DSYNTHESIS {inc} " + " ".join(str(f) for f in list(F.TILE_SYNTH) + list(extra))


def yosys(script: str, d: Path, name: str, timeout=7200):
    # cache: a finished run (marker file) is reused, so the report can be re-assembled without re-synthesis
    if (d / f"{name}.ok").exists() and (d / f"{name}.log").exists() and (d / f"{name}.ys").exists() \
            and (d / f"{name}.ys").read_text() == script:
        return True, (d / f"{name}.log").read_text(), float((d / f"{name}.ok").read_text() or 0)
    (d / f"{name}.ys").write_text(script)
    t0 = time.time()
    r = subprocess.run(["yosys", "-q", "-l", str(d / f"{name}.log"), "-s", str(d / f"{name}.ys")],
                       capture_output=True, text=True, timeout=timeout)
    log = (d / f"{name}.log").read_text() if (d / f"{name}.log").exists() else ""
    if r.returncode == 0:
        (d / f"{name}.ok").write_text(f"{time.time() - t0:.0f}")
    return r.returncode == 0, log + r.stderr, time.time() - t0


def last_stat(log):
    return log.split("Printing statistics")[-1] if "Printing statistics" in log else ""


def cnt(stat, pat):
    return sum(int(n) for n in re.findall(r"^\s+" + pat + r"\s+(\d+)\s*$", stat, re.M))


def generic_cfg(name):
    return synth_cfg(name, do_generic=True, do_xilinx=False)


def xilinx_cfg(name):
    return synth_cfg(name, do_generic=False, do_xilinx=True)


def synth_cfg(name, do_generic=True, do_xilinx=True):
    cfg = cfg_of(name)
    d = SYN / name
    d.mkdir(parents=True, exist_ok=True)
    res = {"config": name, "cfg": {k: cfg[k] for k in TILE_PARAMS}}
    wgen = d / "cfg_top_generic.sv"
    wgen.write_text(F.tile_wrapper({k: cfg[k] for k in TILE_PARAMS}))
    wfpga = d / "cfg_top_fpga.sv"
    wfpga.write_text(F.tile_wrapper(dict({k: cfg[k] for k in TILE_PARAMS}, SPM_BACKEND=1)))
    # ---------------- 1. generic
    gen = f"""{reads([wgen])}
hierarchy -check -top cfg_top
proc
select -assert-none t:$dlatch t:$adlatch t:$dlatchsr
flatten
opt -full
memory -nomap
opt -full
techmap
opt -fast
abc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX
opt_clean
stat
"""
    if not do_generic:
        res["generic"] = None
    ok, log, dt = yosys(gen, d, "generic") if do_generic else (False, "", 0)
    st = last_stat(log)
    if do_generic:
      res["generic"] = dict(ok=ok, secs=round(dt), latch_free=ok,
                          cells=int((re.findall(r"Number of cells:\s+(\d+)", st) or [0])[-1]),
                          ffs=cnt(st, r"\$_[A-Z]*DFF[A-Z0-9_]*"),
                          gates=cnt(st, r"\$_(?:AND|NAND|OR|NOR|XOR|XNOR|ANDNOT|ORNOT|MUX|NOT)_"),
                          mem_bits=0)
    if do_generic:
        mems = re.findall(r"Number of memory bits:\s+(\d+)", st)
        res["generic"]["mem_bits"] = int(mems[-1]) if mems else 0
        (d / "generic_stat.txt").write_text(st)
    # ---------------- 2. xilinx 7-series (FPGA block-RAM backend)
    xil = f"""{reads([wfpga])}
hierarchy -check -top cfg_top
synth_xilinx -flatten -top cfg_top
stat
"""
    if not do_xilinx:
        res["xilinx"] = None
        return res
    ok, log, dt = yosys(xil, d, "xilinx")
    st = last_stat(log)
    res["xilinx"] = dict(ok=ok, secs=round(dt), luts=cnt(st, r"LUT\d"), lutram=cnt(st, r"RAM\d+[MSX]\w*"),
                         ffs=cnt(st, r"FD\w+"), bram=cnt(st, r"RAMB\w+"), dsp=cnt(st, r"DSP48E1"),
                         carry=cnt(st, r"CARRY4"))
    (d / "xilinx_stat.txt").write_text(st)
    return res


def ecp5_cfg(name, pnr, seed=1):
    cfg = cfg_of(name)
    d = SYN / name
    d.mkdir(parents=True, exist_ok=True)
    wh = d / "fpga_top.sv"
    wh.write_text(F.harness_wrapper({k: cfg[k] for k in HARNESS_PARAMS}))
    script = f"""{reads([F.ROOT / 'fpga/hpc_tile_fpga_harness.sv', wh])}
hierarchy -check -top fpga_top
synth_ecp5 -top fpga_top -json {d / 'ecp5.json'}
stat
"""
    ok, log, dt = yosys(script, d, "ecp5")
    st = last_stat(log)
    res = dict(synth_ok=ok, synth_secs=round(dt), comb=cnt(st, r"LUT4") + 2 * cnt(st, r"CCU2C"),
               lut4=cnt(st, r"LUT4"), ccu2c=cnt(st, r"CCU2C"), ff=cnt(st, r"TRELLIS_FF"),
               ebr=cnt(st, r"DP16KD"), mult=cnt(st, r"MULT18X18D"), dpram=cnt(st, r"TRELLIS_DPR16X4"))
    (d / "ecp5_stat.txt").write_text(st)
    if not (ok and pnr):
        return res
    (d / "ulx3s.lpf").write_text(LPF)
    t0 = time.time()
    done = d / "pnr.ok"
    if done.exists() and (d / "pnr.log").exists():
        plog = (d / "pnr.log").read_text()
        rc = 0
        res["pnr_secs"] = int(done.read_text() or 0)
    else:
        # YoWASP nextpnr runs in a WASM sandbox that only sees the current directory: relative paths, cwd = d
        r = subprocess.run(["yowasp-nextpnr-ecp5", "--85k", "--package", "CABGA381", "--json", "ecp5.json",
                            "--lpf", "ulx3s.lpf", "--freq", "25", "--seed", str(seed),
                            "--report", "pnr_report.json", "--textcfg", "pnr.config"],
                           capture_output=True, text=True, timeout=6 * 3600, cwd=d)
        plog = r.stdout + r.stderr
        rc = r.returncode
        (d / "pnr.log").write_text(plog)
        res["pnr_secs"] = round(time.time() - t0)
        if rc == 0:
            done.write_text(str(res["pnr_secs"]))
    res["pnr_ok"] = rc == 0
    fm = re.findall(r"Max frequency for clock\s+'[^']+':\s+([\d.]+) MHz \((PASS|FAIL) at ([\d.]+) MHz\)", plog)
    if fm:
        res["fmax_mhz"], res["timing_25mhz"] = float(fm[-1][0]), fm[-1][1]
    util = {}
    for m in re.finditer(r"^Info:\s+(\w+):\s+(\d+)/\s*(\d+)\s+(\d+)%", plog, re.M):
        util[m.group(1)] = (int(m.group(2)), int(m.group(3)))
    res["util"] = util
    crit = re.findall(r"Info: Critical path report for clock '[^']+'.*?(?=Info: (?:Critical path report|Max frequency))",
                      plog, re.S)
    if crit:
        (d / "pnr_critical_path.txt").write_text(crit[-1])
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default="s1_n2,baseline,n1_b1,n8_b8,n4_dw64,n4_buffered,n4_noperf",
                    help="Xilinx-7 mapping and ECP5 synthesis")
    ap.add_argument("--generic", default="s1_n2,baseline", help="generic gate-level synthesis (slow: abc)")
    ap.add_argument("--pnr", default="baseline,s1_n2", help="nextpnr-ecp5 place and route")
    ap.add_argument("--jobs", type=int, default=2)
    a = ap.parse_args()
    names = a.configs.split(",")
    gens = [x for x in a.generic.split(",") if x]
    pnr = [x for x in a.pnr.split(",") if x]
    SYN.mkdir(parents=True, exist_ok=True)
    out = {"tools": C.tool_versions(), "nextpnr": subprocess.run(["yowasp-nextpnr-ecp5", "--version"],
                                                                 capture_output=True, text=True).stderr.strip()}
    # priority: place and route first (longest), then ECP5 synthesis, Xilinx mapping, generic gates
    plan = [("ecp5", n, True) for n in pnr] + [("ecp5", n, False) for n in names if n not in pnr] + \
           [("xil", n, None) for n in names] + [("gen", n, None) for n in gens]
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = {(k, n): ex.submit(ecp5_cfg, n, p) if k == "ecp5" else ex.submit(xilinx_cfg if k == "xil" else generic_cfg, n)
                for k, n, p in plan}
        res = []
        for n in names:
            r = futs[("xil", n)].result()
            r["generic"] = futs[("gen", n)].result()["generic"] if ("gen", n) in futs else None
            r["ecp5"] = futs[("ecp5", n)].result()
            res.append(r)
            print(json.dumps(r), flush=True)
    out["results"] = res
    (C.REPORTS / "synth.json").write_text(json.dumps(out, indent=1))
    L = ["# Synthesis, resources and timing (actual tool runs)", "",
         f"Tools: {out['tools']['yosys']}; {out['nextpnr']}.", "",
         "Raw logs and statistics: `reports/synth/<config>/`.  Every number below is parsed from those files.", "",
         "## 1. Generic (technology independent; latch check; memories reported as bits, not mapped)", "",
         "| config | parameters | latch-free | cells | flip-flops | gates | memory bits |", "|---|---|---|---|---|---|---|"]
    for r in res:
        g = r["generic"]
        if not g:
            continue
        diff = {k: v for k, v in r["cfg"].items() if DEFAULT.get(k) != v}
        L.append(f"| {r['config']} | {diff or 'baseline'} | {'yes' if g['ok'] else 'FAILED'} | {g['cells']:,} | "
                 f"{g['ffs']:,} | {g['gates']:,} | {g['mem_bits']:,} |")
    if not any(r["generic"] for r in res):
        L += ["", "Not part of the final run: mapping the flattened tile with abc to a simple gate library took more "
              "than 10 minutes per configuration and was cut for time.  Technology-independent elaboration and the "
              "latch check of 14 parameter sets are in `reports/lint.md`; the ECP5 / Xilinx mappings below are "
              "the resource analysis."]
    L += ["", "## 2. Xilinx 7-series mapping estimate (Yosys synth_xilinx; scratchpad BACKEND = FPGA)", "",
          "No Vivado run: device fit, packing and timing are not claimed.", "",
          "| config | LUT | LUTRAM | FF | CARRY4 | RAMB | DSP48E1 |", "|---|---|---|---|---|---|---|"]
    for r in res:
        x = r["xilinx"]
        L.append(f"| {r['config']} | {x['luts']:,} | {x['lutram']:,} | {x['ffs']:,} | {x['carry']:,} | {x['bram']} | {x['dsp']} |"
                 if x["ok"] else f"| {r['config']} | FAILED | | | | | |")
    L += ["", "## 3. Lattice ECP5 (tile + timing harness; synth_ecp5, nextpnr-ecp5 on LFE5U-85F CABGA381)", "",
          "Fmax is nextpnr's post-route static timing estimate for the speed-6 device at seed 1 -- a property "
          "of this implementation run, not a measured hardware clock.  The harness registers are included.", "",
          "| config | LUT4 | CCU2C | TRELLIS_FF | DP16KD (EBR) | MULT18X18D | DPR16X4 | P&R | TRELLIS_COMB used/avail | Fmax |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for r in res:
        e = r["ecp5"]
        u = e.get("util", {})
        comb = u.get("TRELLIS_COMB")
        L.append(f"| {r['config']} | {e['lut4']:,} | {e['ccu2c']:,} | {e['ff']:,} | {e['ebr']} | {e['mult']} | {e['dpram']} | "
                 f"{('routed' if e.get('pnr_ok') else 'FAILED') if 'pnr_ok' in e else 'not run'} | "
                 f"{f'{comb[0]:,} / {comb[1]:,}' if comb else '-'} | "
                 f"{str(e.get('fmax_mhz', '-')) + ' MHz' if 'fmax_mhz' in e else '-'} |")
    (C.REPORTS / "synth.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
