// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_align.sv -- STEP 4: alignment of the addend with the product
//
// The addend significand is placed at frame bits [73:50] and shifted right by
// shamt (0..75). Bits shifted below frame bit 0 are ORed into `sticky`.
// Runs concurrently with the multiplier (classic FMA organisation: the
// alignment shift amount depends only on exponents, not on the product).
//
// Invariant used by step 5 (proof in docs/PIPELINE.md): sticky can only be
// set when shamt > 50, in which case |addend| < 2^23 <= 2^46 <= |product| in
// frame units, i.e. the product strictly dominates.
// =============================================================================
`default_nettype none

module fp32_fma_align (
  input  wire logic [23:0] mc,
  input  wire logic [6:0]  shamt,
  output logic      [73:0] aligned,
  output logic             sticky
);
  logic [149:0] ext, sh;

  assign ext     = {mc, 126'd0};      // mc at [149:126]; frame = [149:76]
  assign sh      = ext >> shamt;
  assign aligned = sh[149:76];
  assign sticky  = |sh[75:0];
endmodule

`default_nettype wire
