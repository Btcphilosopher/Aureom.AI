// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_round.sv -- STEP 7: rounding (with gradual-underflow denormalisation)
//
// Inputs from step 6: normalised magnitude mn (leading one at bit 74), the
// denormalisation shift dsh and pre-rounding exponent field e_pk (both from
// e_norm), the exponent-range flags, and the sticky bit of everything below
// the alignment frame.
//
// 1. Denormalisation: mn >> dsh with sticky jamming (dsh = 0 for normal
//    results). Subnormal results are produced, never flushed to zero.
// 2. Rounding: 24 retained bits, round bit, sticky -> increment decision per
//    rounding attribute (fp32_fma_pkg::round_up). A carry out of the 24-bit
//    significand renormalises to 1.000 and bumps the exponent; a subnormal
//    rounding up into bit 23 becomes the smallest normal number naturally.
// 3. Tininess (IEEE 754-2019 sec. 7.5, parameter TININESS_AFTER_ROUNDING):
//      before rounding : e_norm < 1                     (subn)
//      after  rounding : the result rounded to 24 bits with unbounded
//                        exponent is < 2^-126, i.e. e_norm < 0, or
//                        e_norm == 0 and the normal-precision rounding does
//                        not carry into 2^-126.
//    RISC-V and x86 detect tininess after rounding (default); Arm before.
// =============================================================================
`default_nettype none

module fp32_fma_round #(
  parameter bit TININESS_AFTER_ROUNDING = 1'b1
) (
  input  wire logic [74:0] mn,
  input  wire logic [7:0]  e_pk,
  input  wire logic [4:0]  dsh,
  input  wire logic        subn,
  input  wire logic        e_lt0,
  input  wire logic        e_eq0,
  input  wire logic        sticky,
  input  wire logic        sign,
  input  wire logic [2:0]  rm,
  output logic      [23:0] sig_f,    // significand incl. hidden bit
  output logic      [7:0]  exp_f,    // exponent field before packing (mod 256)
  output logic             carry,    // rounding carried out of 24 bits
  output logic             inexact,
  output logic             tiny
);
  // ---------------------------------------------------------------------------
  // 1. denormalisation
  // ---------------------------------------------------------------------------
  logic [100:0] t;
  logic [23:0]  sig_d;
  logic         rnd_d, stk_d;

  assign t     = {mn, 26'd0} >> dsh;
  assign sig_d = t[100:77];
  assign rnd_d = t[76];
  assign stk_d = (|t[75:0]) | sticky;

  // ---------------------------------------------------------------------------
  // 2. rounding
  // ---------------------------------------------------------------------------
  logic        inc;
  logic [24:0] sig_r;

  assign inc     = fp32_fma_pkg::round_up(rm, sign, sig_d[0], rnd_d, stk_d);
  assign sig_r   = {1'b0, sig_d} + {24'd0, inc};
  assign carry   = sig_r[24];
  assign sig_f   = carry ? 24'h80_0000 : sig_r[23:0];
  assign exp_f   = e_pk + {7'd0, carry};
  assign inexact = rnd_d | stk_d;

  // ---------------------------------------------------------------------------
  // 3. tininess
  // ---------------------------------------------------------------------------
  logic inc_n, carry_n, tiny_after;

  assign inc_n      = fp32_fma_pkg::round_up(rm, sign, mn[51], mn[50],
                                             (|mn[49:0]) | sticky);
  assign carry_n    = inc_n & (&mn[74:51]);
  assign tiny_after = e_lt0 | (e_eq0 & ~carry_n);
  assign tiny       = TININESS_AFTER_ROUNDING ? tiny_after : subn;
endmodule

`default_nettype wire
