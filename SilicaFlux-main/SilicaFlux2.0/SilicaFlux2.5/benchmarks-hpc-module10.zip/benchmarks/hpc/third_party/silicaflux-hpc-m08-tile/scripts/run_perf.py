#!/usr/bin/env python3
"""Measured performance of silicaflux_hpc_tile (RTL simulation cycles, Verilator).

Every measurement program is generated with gen_tests.Prog, i.e. it is ALSO a self-checking test: the
completion records and the final memory are compared with the reference model, so a number is only
reported for a run that produced correct results.  Cycle counts come from the tile itself (CPL_CYCLES =
dispatch -> retirement, measured by the hardware) and from testbench cycle stamps (MARK).

  E1 vector unit on scratchpad data: FADD / FMUL / FMADD, vl = 1024, per configuration -> elements/cycle
  E2 KERNEL end to end (host memory -> scratchpad -> compute -> host memory), simple vs buffered DMA
  E3 DMA / compute overlap: 8 tiles serialised with FENCE vs double-buffered (independent DMA-in)
  E4 DMA bandwidth: host -> scratchpad, scratchpad -> host, scratchpad -> scratchpad
  E5 command overhead: NOP and vl = 1 vector command latency
Writes reports/perf.{md,json}.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
import common as C  # noqa: E402
import files as F  # noqa: E402
import fp32_model as FP  # noqa: E402
from gen_tests import EXT0, Prog  # noqa: E402
from run_tests import CONFIGS, DEFAULT  # noqa: E402
from tile_model import Cfg, dma, kernel, nop, vec  # noqa: E402

CONFIGS = dict(CONFIGS)
CONFIGS["n16_dw128"] = dict(NUM_LANES=16, DATA_WIDTH=128, NUM_BANKS=8)


def cfg_of(name):
    c = dict(DEFAULT)
    c.update(CONFIGS[name])
    return c


def mcfg(c):
    return Cfg(n_lanes=c["NUM_LANES"], dw=c["DATA_WIDTH"], spm_bytes=c["SCRATCHPAD_BYTES"], num_banks=c["NUM_BANKS"],
               buffered_dma=c["DMA_BUFFER_DEPTH"] != 0)


def run_prog(cfgname, p: Prog, name):
    c = cfg_of(cfgname)
    p.qdepth, p.cplq, p.ecc = c["CMD_QUEUE_DEPTH"], c["CPL_QUEUE_DEPTH"], False
    d = C.BUILD / "perf" / cfgname / name
    p.write(d)
    exe = C.verilator_build("tb_silicaflux_hpc_tile", F.TILE_TB, c, F.SIM_DEFINES, f"tile_{cfgname}", jobs=2)
    rc, out, _ = C.run([str(exe), f"+prog={d / 'prog.txt'}", f"+init={d / 'init.hex'}", f"+final={d / 'final.hex'}",
                        f"+name={name}", "+trace_cpl"], timeout=7200)
    (d / "sim.log").write_text(out)
    ok = "TB_TILE RESULT PASS" in out
    cpl = {int(m.group(2), 16): dict(seq=int(m.group(1)), type=int(m.group(3)), count=int(m.group(5)), cycles=int(m.group(6)))
           for m in re.finditer(r"TB_TILE CPL seq=(\d+) tag=([0-9a-f]+) type=(\d+) status=(\d+) count=(\d+) cycles=(\d+)", out)}
    marks = {m.group(1): int(m.group(2)) for m in re.finditer(r"TB_TILE MARK (\S+) cycle=(\d+)", out)}
    return ok, cpl, marks


def e1(cfgname):
    c = cfg_of(cfgname)
    p = Prog(mcfg(c), "e1", 11)
    sb = p.cfg.sb
    vl = min(1024, c["SCRATCHPAD_BYTES"] // 16)
    regs = [p.spm + k * (c["SCRATCHPAD_BYTES"] // 4) for k in range(4)]
    for r in regs[:3]:
        p.put(r, p.rand_vec(vl))
    for tag, op in ((1, FP.OP_FADD), (2, FP.OP_FMUL), (3, FP.OP_FMADD)):
        p.sub(vec(op, vl, regs[0], regs[1], regs[2], regs[3], tag=tag))
        p.drain()
    p.check(regs[3], 4 * vl)
    ok, cpl, _ = run_prog(cfgname, p, "e1")
    lpw = min(c["NUM_LANES"], c["DATA_WIDTH"] // 32)
    ports = min(c["NUM_LANES"] // lpw, c["LSU_MAX_PORTS"])
    out = dict(config=cfgname, lanes=c["NUM_LANES"], dw=c["DATA_WIDTH"], banks=c["NUM_BANKS"], lsu_ports=ports, vl=vl, ok=ok)
    for tag, nm, ops in ((1, "FADD", 2), (2, "FMUL", 2), (3, "FMADD", 3)):
        cyc = cpl.get(tag, {}).get("cycles", 0)
        out[nm] = dict(cycles=cyc, elem_per_cycle=round(vl / cyc, 3) if cyc else None,
                       lsu_bound=round(ports * lpw / (ops + 1), 3), array_peak=c["NUM_LANES"])
    return out


def e2(cfgname):
    c = cfg_of(cfgname)
    res = dict(config=cfgname, dma=("buffered " + str(c["DMA_BUFFER_DEPTH"])) if c["DMA_BUFFER_DEPTH"] else "simple", rows=[])
    for vl in (64, 256, 1024):
        p = Prog(mcfg(c), "e2", 12)
        nb = 4 * vl
        a, b, cc, d = EXT0, EXT0 + nb, EXT0 + 2 * nb, EXT0 + 3 * nb
        for x in (a, b, cc):
            p.put(x, p.rand_vec(vl))
        p.sub(kernel(FP.OP_FMADD, vl, a, b, cc, d, p.spm, tag=1))
        p.drain()
        p.check(d, nb)
        ok, cpl, _ = run_prog(cfgname, p, f"e2_vl{vl}")
        cyc = cpl.get(1, {}).get("cycles", 0)
        res["rows"].append(dict(vl=vl, ok=ok, cycles=cyc, bytes_moved=4 * nb, cycles_per_elem=round(cyc / vl, 2) if cyc else None,
                                flop_per_cycle=round(2 * vl / cyc, 3) if cyc else None))
    return res


def e3(cfgname):
    c = cfg_of(cfgname)
    out = dict(config=cfgname)
    vl, tiles = 512, 8
    nb = 4 * vl
    for mode in ("serial", "double"):
        p = Prog(mcfg(c), "e3", 13)
        for t in range(tiles):
            p.put(EXT0 + t * nb, p.rand_vec(vl))
        s = p.spm
        buf = [s, s + 0x1000 * (nb // 0x1000 + 1)]                       # two scratchpad input buffers
        outb = [s + 0x8000, s + 0x8000 + 0x1000 * (nb // 0x1000 + 1)]   # two output buffers
        p.op("MARK start")
        sc = FP.f2b(1.5)
        if mode == "serial":
            for t in range(tiles):
                p.sub(dma(EXT0 + t * nb, buf[0], nb, tag=3 * t, fence=1))
                p.sub(vec(FP.OP_FMUL, vl, buf[0], 0, 0, outb[0], bc=2, sc=sc, tag=3 * t + 1, fence=1))
                p.sub(dma(outb[0], EXT0 + 0x20000 + t * nb, nb, tag=3 * t + 2, fence=1))
        else:
            p.sub(dma(EXT0, buf[0], nb, tag=0))
            for t in range(tiles):
                cur, nxt = buf[t % 2], buf[(t + 1) % 2]
                p.sub(vec(FP.OP_FMUL, vl, cur, 0, 0, outb[t % 2], bc=2, sc=sc, tag=3 * t + 1))
                if t + 1 < tiles:
                    p.sub(dma(EXT0 + (t + 1) * nb, nxt, nb, tag=3 * t + 3))      # independent of the VEC: overlaps
                p.sub(dma(outb[t % 2], EXT0 + 0x20000 + t * nb, nb, tag=3 * t + 2))
        p.drain()
        p.op("MARK end")
        p.check(EXT0 + 0x20000, tiles * nb)
        ok, cpl, marks = run_prog(cfgname, p, f"e3_{mode}")
        out[mode] = dict(ok=ok, cycles=marks.get("end", 0) - marks.get("start", 0))
    if out["serial"]["cycles"]:
        out["speedup"] = round(out["serial"]["cycles"] / out["double"]["cycles"], 3)
    return out


def e4(cfgname):
    c = cfg_of(cfgname)
    p = Prog(mcfg(c), "e4", 14)
    n = 16384
    p.put(EXT0, [p.rng.getrandbits(32) for _ in range(n // 4)])
    p.sub(dma(EXT0, p.spm, n, tag=1)); p.drain()
    p.sub(dma(p.spm, EXT0 + 0x10000, n, tag=2)); p.drain()
    p.sub(dma(p.spm, p.spm + 0x8000, n, tag=3)); p.drain()
    p.check(EXT0 + 0x10000, n)
    ok, cpl, _ = run_prog(cfgname, p, "e4")
    r = dict(config=cfgname, ok=ok, bytes=n)
    for tag, nm in ((1, "host->SPM"), (2, "SPM->host"), (3, "SPM->SPM")):
        cyc = cpl.get(tag, {}).get("cycles", 0)
        r[nm] = dict(cycles=cyc, bytes_per_cycle=round(n / cyc, 3) if cyc else None)
    return r


def e5(cfgname):
    c = cfg_of(cfgname)
    p = Prog(mcfg(c), "e5", 15)
    p.put(p.spm, p.rand_vec(64)); p.put(p.spm + 0x100, p.rand_vec(64))
    p.sub(nop(tag=1)); p.drain()
    p.sub(vec(FP.OP_FADD, 1, p.spm, p.spm + 0x100, 0, p.spm + 0x200, tag=2)); p.drain()
    p.sub(vec(FP.OP_FMADD, 1, p.spm, p.spm + 0x100, p.spm, p.spm + 0x300, tag=3)); p.drain()
    p.sub(dma(p.spm, p.spm + 0x400, 4, tag=4)); p.drain()
    p.check(p.spm + 0x200, 4)
    ok, cpl, _ = run_prog(cfgname, p, "e5")
    return dict(config=cfgname, ok=ok, NOP=cpl.get(1, {}).get("cycles"), FADD_vl1=cpl.get(2, {}).get("cycles"),
                FMADD_vl1=cpl.get(3, {}).get("cycles"), DMA_4B=cpl.get(4, {}).get("cycles"))


def main():
    R = dict(tools=C.tool_versions())
    R["e1"] = [e1(c) for c in ("n1_b1", "s1_n2", "baseline", "n8_b8", "n16_b16", "n4_dw64", "n16_dw128")]
    R["e2"] = [e2(c) for c in ("baseline", "n4_buffered")]
    R["e3"] = [e3(c) for c in ("baseline", "n4_buffered")]
    R["e4"] = [e4(c) for c in ("baseline", "n4_buffered")]
    R["e5"] = [e5("baseline")]
    allok = all(x["ok"] for x in R["e1"] + R["e4"] + R["e5"]) and all(r["ok"] for x in R["e2"] for r in x["rows"]) and \
        all(x[m]["ok"] for x in R["e3"] for m in ("serial", "double"))
    R["all_runs_self_checked_pass"] = allok
    (C.REPORTS / "perf.json").write_text(json.dumps(R, indent=1))
    L = ["# Measured performance (RTL simulation cycles)", "",
         "Every run below is also a self-checking test against the reference model "
         f"(all passed: **{'yes' if allok else 'NO'}**).  Cycles = the tile's own CPL_CYCLES (dispatch -> retirement) "
         "or testbench cycle stamps.  No clock frequency is implied (see docs/08_fpga_synthesis.md for the "
         "post-route estimate).", "",
         "## E1 Vector unit on scratchpad-resident data (one command, vl elements)", "",
         "LSU bound = scratchpad accesses available per element: LSU ports x lanes per word / (operands read + 1 store).", "",
         "| config | lanes | DW | banks | LSU ports | vl | FADD cyc (elem/cyc) | FMUL cyc (elem/cyc) | FMADD cyc (elem/cyc) | LSU bound FADD / FMADD | array peak |",
         "|---|---|---|---|---|---|---|---|---|---|---|"]
    for x in R["e1"]:
        L.append(f"| {x['config']} | {x['lanes']} | {x['dw']} | {x['banks']} | {x['lsu_ports']} | {x['vl']} | "
                 f"{x['FADD']['cycles']} ({x['FADD']['elem_per_cycle']}) | {x['FMUL']['cycles']} ({x['FMUL']['elem_per_cycle']}) | "
                 f"{x['FMADD']['cycles']} ({x['FMADD']['elem_per_cycle']}) | {x['FADD']['lsu_bound']} / {x['FMADD']['lsu_bound']} | "
                 f"{x['FADD']['array_peak']} |")
    L += ["", "## E2 KERNEL FMADD end to end (host memory -> scratchpad -> compute -> host memory)", "",
          "| config | DMA engine | vl | cycles | bytes moved | cycles / element | FLOP / cycle |", "|---|---|---|---|---|---|---|"]
    for x in R["e2"]:
        for r in x["rows"]:
            L.append(f"| {x['config']} | {x['dma']} | {r['vl']} | {r['cycles']} | {r['bytes_moved']} | {r['cycles_per_elem']} | {r['flop_per_cycle']} |")
    L += ["", "## E3 DMA / compute overlap, 8 tiles x 512 elements (scale by a broadcast scalar)", "",
          "| config | serialised (FENCE) cycles | double-buffered cycles | speed-up |", "|---|---|---|---|"]
    for x in R["e3"]:
        L.append(f"| {x['config']} | {x['serial']['cycles']} | {x['double']['cycles']} | {x.get('speedup')} |")
    L += ["", "## E4 DMA bandwidth, 16 KiB transfers", "", "| config | host -> SPM B/cyc | SPM -> host B/cyc | SPM -> SPM B/cyc |",
          "|---|---|---|---|"]
    for x in R["e4"]:
        L.append(f"| {x['config']} | {x['host->SPM']['bytes_per_cycle']} | {x['SPM->host']['bytes_per_cycle']} | {x['SPM->SPM']['bytes_per_cycle']} |")
    L += ["", "## E5 Command overhead (dispatch -> retirement, cycles)", "", "| NOP | FADD vl = 1 | FMADD vl = 1 | DMA 4 bytes |", "|---|---|---|---|"]
    for x in R["e5"]:
        L.append(f"| {x['NOP']} | {x['FADD_vl1']} | {x['FMADD_vl1']} | {x['DMA_4B']} |")
    (C.REPORTS / "perf.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    sys.exit(0 if allok else 1)


if __name__ == "__main__":
    main()
