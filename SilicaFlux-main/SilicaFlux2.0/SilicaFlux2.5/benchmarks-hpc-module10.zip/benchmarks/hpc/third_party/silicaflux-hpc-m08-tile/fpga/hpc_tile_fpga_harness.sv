// =============================================================================
// SilicaFlux-HPC Module 08 :: hpc_tile_fpga_harness  -- place-and-route harness
//
// The tile has ~3*DATA_WIDTH + 200 I/O signals, more than an FPGA board
// offers.  To place and route the COMPLETE tile and obtain a real post-route
// timing estimate, this harness (same method as Module 03's
// hpc_varray_fpga_harness):
//   * drives EVERY tile input from registers loaded from a 64-bit LFSR, so
//     every input path starts at a flip-flop and no logic is constant;
//   * XOR-folds EVERY tile output into a registered 64-bit signature reduced
//     to 8 LEDs, so no tile logic can be removed;
//   * synchronises the reset button (asynchronous assert, synchronous release).
// It is NOT a functional test (handshake rules are not respected); the tile's
// function is verified in simulation.  The harness adds ~DATA_WIDTH*3 + 300
// flip-flops, included in the reported utilisation.
// The board pins (ULX3S: 25 MHz clock G2, button R1, LEDs) appear only in the
// constraint file written by scripts/run_fpga.py -- the generic tile carries
// no device or vendor primitive.
// =============================================================================
`default_nettype none

module hpc_tile_fpga_harness #(
  parameter int NUM_LANES            = 4,
  parameter int DATA_WIDTH           = 32,
  parameter int SCRATCHPAD_BYTES     = 65536,
  parameter int NUM_BANKS            = 4,
  parameter int CMD_QUEUE_DEPTH      = 8,
  parameter int DMA_BUFFER_DEPTH     = 0,
  parameter int ENABLE_PERF_COUNTERS = 1,
  parameter int SPM_BACKEND          = 1          // FPGA block-RAM inference (SRAM Wrapper Library)
) (
  input  wire logic       clk,
  input  wire logic       btn,                  // reset, active high
  output logic      [7:0] led
);
  localparam int DW = DATA_WIDTH, SB = DW / 8;
  localparam int NIN  = 1 + 1 + 12 + 32 + 1 + 1 + 32 + DW + SB + 1 + 1 + 1 + DW + 1;
  localparam int NOUT = 32 + 1 + 1 + 1 + DW + 1 + 1 + 1 + 32 + DW + SB + 1 + 3;

  logic [1:0] rs_q;
  always_ff @(posedge clk or posedge btn)
    if (btn) rs_q <= 2'b00; else rs_q <= {rs_q[0], 1'b1};
  wire rst_n = rs_q[1];

  // stimulus: 64-bit LFSR shifted into an NIN-bit register chain
  logic [63:0]    lfsr_q;
  logic [NIN-1:0] in_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin lfsr_q <= 64'h1; in_q <= '0; end
    else begin
      lfsr_q <= {lfsr_q[62:0], lfsr_q[63] ^ lfsr_q[62] ^ lfsr_q[60] ^ lfsr_q[59]};
      in_q   <= {in_q[NIN-65:0], lfsr_q};
    end
  end

  logic [31:0]   rb_rdata;
  logic          rb_err, hs_req_ready, hs_rsp_valid, hs_rsp_error, fab_req_valid, fab_req_write, fab_rsp_ready;
  logic [DW-1:0] hs_rsp_rdata, fab_req_wdata;
  logic [31:0]   fab_req_addr;
  logic [SB-1:0] fab_req_wstrb;
  logic          irq, busy, halted;

  int unsigned k;
  silicaflux_hpc_tile #(
    .NUM_LANES(NUM_LANES), .DATA_WIDTH(DATA_WIDTH), .SCRATCHPAD_BYTES(SCRATCHPAD_BYTES), .NUM_BANKS(NUM_BANKS),
    .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .DMA_BUFFER_DEPTH(DMA_BUFFER_DEPTH),
    .ENABLE_PERF_COUNTERS(ENABLE_PERF_COUNTERS), .SPM_BACKEND(SPM_BACKEND)
  ) u_tile (
    .clk, .rst_n,
    .rb_sel(in_q[0]), .rb_we(in_q[1]), .rb_addr(in_q[2 +: 12]), .rb_wdata(in_q[14 +: 32]),
    .rb_rdata, .rb_err,
    .hs_req_valid(in_q[46]), .hs_req_ready, .hs_req_write(in_q[47]), .hs_req_addr(in_q[48 +: 32]),
    .hs_req_wdata(in_q[80 +: DW]), .hs_req_wstrb(in_q[80 + DW +: SB]),
    .hs_rsp_valid, .hs_rsp_ready(in_q[80 + DW + SB]), .hs_rsp_rdata, .hs_rsp_error,
    .fab_req_valid, .fab_req_ready(in_q[81 + DW + SB]), .fab_req_write, .fab_req_addr, .fab_req_wdata,
    .fab_req_wstrb, .fab_rsp_valid(in_q[82 + DW + SB]), .fab_rsp_ready, .fab_rsp_rdata(in_q[83 + DW + SB +: DW]),
    .fab_rsp_error(in_q[83 + 2 * DW + SB]),
    .irq, .busy, .halted
  );

  // signature: every output folded into 64 registered bits
  wire [NOUT-1:0] outs = {rb_rdata, rb_err, hs_req_ready, hs_rsp_valid, hs_rsp_rdata, hs_rsp_error, fab_req_valid,
                          fab_req_write, fab_req_addr, fab_req_wdata, fab_req_wstrb, fab_rsp_ready, irq, busy, halted};
  logic [63:0] sig_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) sig_q <= '0;
    else begin
      logic [63:0] f;
      f = {sig_q[62:0], sig_q[63]};
      for (int i = 0; i < NOUT; i++) f[i % 64] = f[i % 64] ^ outs[i];
      sig_q <= f;
    end
  end
  always_ff @(posedge clk) led <= sig_q[7:0] ^ sig_q[15:8] ^ sig_q[23:16] ^ sig_q[31:24] ^
                                 sig_q[39:32] ^ sig_q[47:40] ^ sig_q[55:48] ^ sig_q[63:56];
endmodule

`default_nettype wire
