// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_mul.sv -- STEP 3: full-precision significand multiplication
//
// Exact 24 x 24 -> 48-bit unsigned product; nothing is truncated or rounded
// here (fused semantics: the only rounding happens in step 7).
//
// This is the generic, technology-independent implementation: the `*`
// operator is mapped by the synthesis tool (gate-level multiplier for ASIC
// flows, hard DSP blocks for FPGA flows -- see synth/). A technology-specific
// multiplier (e.g. a vendor DSP primitive or a hand-built Booth/Wallace array)
// can replace this module behind the same ports without touching the rest of
// the datapath; it must remain purely combinational, or the extra latency
// must be absorbed by disabling a PIPE_CFG boundary.
// =============================================================================
`default_nettype none

module fp32_fma_mul (
  input  wire logic [23:0] a,
  input  wire logic [23:0] b,
  output logic      [47:0] p
);
  assign p = {24'd0, a} * {24'd0, b};
endmodule

`default_nettype wire
