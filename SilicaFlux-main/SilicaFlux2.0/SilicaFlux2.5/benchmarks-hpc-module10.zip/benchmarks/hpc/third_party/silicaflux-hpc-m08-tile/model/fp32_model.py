"""Exact IEEE 754 binary32 reference for the SilicaFlux-HPC tile (Module 08).

Independent software reference: written from the specification (Module 02
docs/FP_SEMANTICS.md, Module 03 docs/REDUCTION.md, RISC-V F), not from any RTL.
Every finite operand is converted to an exact fractions.Fraction, the exact
result is formed and rounded ONCE with the requested rounding attribute.

  * rounding: RNE 0, RTZ 1, RDN 2, RUP 3, RMM 4
  * flags   : {NV, DZ, OF, UF, NX} as a 5-bit int, NV = bit 4 ... NX = bit 0
  * tininess detected AFTER rounding (RISC-V); UF = tiny AND inexact
  * NaN     : every NaN produced by an arithmetic op is canonical 0x7FC00000
  * zeros   : exact zero sums / differences / cancellations give +0 (-0 under RDN);
              (+-0) + (+-0) with equal signs keeps the sign; an exact zero product
              in FMA returns the addend exactly
  * FMA     : FNMSUB = -(a*b) + c, FNMADD = -(a*b) - c, by negating the inputs

selftest() checks the model against numpy's hardware float32 add / multiply
(RNE, results) and, when available, against Berkeley SoftFloat-3e built with
the RISC-V specialisation (all ops, all rounding modes, results AND flags):
scripts/selftest_model.py.
"""
from __future__ import annotations

import math
import struct
from fractions import Fraction

RNE, RTZ, RDN, RUP, RMM = 0, 1, 2, 3, 4
NV, DZ, OF, UF, NX = 16, 8, 4, 2, 1
QNAN = 0x7FC00000
MAXF = 0x7F7FFFFF
TWO = Fraction(2)
MIN_NORMAL = TWO ** -126
OVF = TWO ** 128

# Module 02 hpc_vector_pkg opcodes
OP_FMV, OP_FADD, OP_FSUB, OP_FMUL = 0x00, 0x01, 0x02, 0x03
OP_FMADD, OP_FMSUB, OP_FNMSUB, OP_FNMADD = 0x04, 0x05, 0x06, 0x07
OP_FMIN, OP_FMAX, OP_FEQ, OP_FLT, OP_FLE = 0x08, 0x09, 0x0A, 0x0B, 0x0C
OP_IADD, OP_IMUL = 0x10, 0x11
OP_NAMES = {OP_FMV: "FMV", OP_FADD: "FADD", OP_FSUB: "FSUB", OP_FMUL: "FMUL", OP_FMADD: "FMADD",
            OP_FMSUB: "FMSUB", OP_FNMSUB: "FNMSUB", OP_FNMADD: "FNMADD", OP_FMIN: "FMIN", OP_FMAX: "FMAX",
            OP_FEQ: "FEQ", OP_FLT: "FLT", OP_FLE: "FLE", OP_IADD: "IADD", OP_IMUL: "IMUL"}
ROUNDING_OPS = {OP_FADD, OP_FSUB, OP_FMUL, OP_FMADD, OP_FMSUB, OP_FNMSUB, OP_FNMADD}
FMA_OPS = {OP_FMADD, OP_FMSUB, OP_FNMSUB, OP_FNMADD}


# ------------------------------------------------------------------ classification
def sign(b: int) -> int: return (b >> 31) & 1
def expo(b: int) -> int: return (b >> 23) & 0xFF
def mant(b: int) -> int: return b & 0x7FFFFF
def is_nan(b: int) -> bool: return expo(b) == 0xFF and mant(b) != 0
def is_snan(b: int) -> bool: return is_nan(b) and not (b >> 22) & 1
def is_inf(b: int) -> bool: return expo(b) == 0xFF and mant(b) == 0
def is_zero(b: int) -> bool: return (b & 0x7FFFFFFF) == 0


def value(b: int) -> Fraction:
    """Exact value of a finite binary32."""
    e, m = expo(b), mant(b)
    v = Fraction(m, 1 << 149) if e == 0 else Fraction((1 << 23) | m) * TWO ** (e - 150)
    return -v if sign(b) else v


def zero(s: int) -> int: return s << 31
def inf(s: int) -> int: return (s << 31) | 0x7F800000


# ------------------------------------------------------------------ rounding
def _round_int(n: Fraction, rm: int, s: int) -> tuple[int, bool]:
    """Round a non-negative rational to an integer magnitude. Returns (k, inexact)."""
    fl = n.numerator // n.denominator
    r = n - fl
    if r == 0:
        return fl, False
    if rm == RNE:
        up = r > Fraction(1, 2) or (r == Fraction(1, 2) and fl & 1)
    elif rm == RTZ:
        up = False
    elif rm == RDN:
        up = s == 1
    elif rm == RUP:
        up = s == 0
    elif rm == RMM:
        up = r >= Fraction(1, 2)
    else:
        raise ValueError("illegal rounding mode")
    return fl + (1 if up else 0), True


def _floor_log2(q: Fraction) -> int:
    e = q.numerator.bit_length() - q.denominator.bit_length()
    if TWO ** e > q:
        e -= 1
    elif TWO ** (e + 1) <= q:
        e += 1
    return e


def round_pack(s: int, q: Fraction, rm: int) -> tuple[int, int]:
    """Round the exact non-zero magnitude q (> 0) with sign s to binary32. Returns (bits, flags)."""
    assert q > 0
    e = _floor_log2(q)
    # tininess after rounding: round to 24 bits with an unbounded exponent range
    k_unb, _ = _round_int(q / TWO ** (e - 23), rm, s)
    tiny = k_unb * TWO ** (e - 23) < MIN_NORMAL
    # actual rounding
    qe = (e - 23) if e >= -126 else -149
    k, inexact = _round_int(q / TWO ** qe, rm, s)
    mag = k * TWO ** qe
    flags = NX if inexact else 0
    if inexact and tiny:
        flags |= UF
    if mag >= OVF:
        flags |= OF | NX
        to_inf = rm in (RNE, RMM) or (rm == RUP and s == 0) or (rm == RDN and s == 1)
        return (inf(s) if to_inf else (s << 31) | MAXF), flags
    if mag == 0:                         # cannot happen for q > 0 except RTZ/RDN/RUP underflow to zero
        return zero(s), flags
    # encode
    if k >= (1 << 24) and qe >= -149:   # carry into the next binade
        k >>= 1
        qe += 1
    if qe == -149 and k < (1 << 23):     # subnormal
        return (s << 31) | k, flags
    be = qe + 150
    return (s << 31) | (be << 23) | (k & 0x7FFFFF), flags


def _exact_or_zero(s_q: Fraction, rm: int, zsign_rule: int | None) -> tuple[int, int]:
    """Round an exact rational; zero results take sign zsign_rule (None: +0, -0 under RDN)."""
    if s_q == 0:
        if zsign_rule is None:
            return zero(1 if rm == RDN else 0), 0
        return zero(zsign_rule), 0
    return round_pack(1 if s_q < 0 else 0, abs(s_q), rm)


# ------------------------------------------------------------------ arithmetic
def fadd(a: int, b: int, rm: int) -> tuple[int, int]:
    if is_nan(a) or is_nan(b):
        return QNAN, NV if (is_snan(a) or is_snan(b)) else 0
    if is_inf(a) or is_inf(b):
        if is_inf(a) and is_inf(b) and sign(a) != sign(b):
            return QNAN, NV
        return (a if is_inf(a) else b), 0
    if is_zero(a) and is_zero(b):
        if sign(a) == sign(b):
            return a, 0
        return zero(1 if rm == RDN else 0), 0
    return _exact_or_zero(value(a) + value(b), rm, None)


def fsub(a: int, b: int, rm: int) -> tuple[int, int]:
    nb = b if is_nan(b) else b ^ 0x80000000
    if is_nan(b):
        return fadd(a, b, rm)
    return fadd(a, nb, rm)


def fmul(a: int, b: int, rm: int) -> tuple[int, int]:
    if is_nan(a) or is_nan(b):
        return QNAN, NV if (is_snan(a) or is_snan(b)) else 0
    s = sign(a) ^ sign(b)
    if is_inf(a) or is_inf(b):
        if is_zero(a) or is_zero(b):
            return QNAN, NV
        return inf(s), 0
    if is_zero(a) or is_zero(b):
        return zero(s), 0
    return round_pack(s, abs(value(a) * value(b)), rm)


def fma_generic(a: int, b: int, c: int, rm: int, neg_prod: bool, neg_add: bool) -> tuple[int, int]:
    """round(+-(a*b) +- c) with a single rounding."""
    nv = is_snan(a) or is_snan(b) or is_snan(c)
    zero_inf = (is_zero(a) and is_inf(b)) or (is_inf(a) and is_zero(b))
    if zero_inf:
        return QNAN, NV                                   # even if c is a quiet NaN (RISC-V)
    if is_nan(a) or is_nan(b) or is_nan(c):
        return QNAN, NV if nv else 0
    sp = sign(a) ^ sign(b) ^ (1 if neg_prod else 0)
    sc = sign(c) ^ (1 if neg_add else 0)
    if is_inf(a) or is_inf(b):
        if is_inf(c) and sc != sp:
            return QNAN, NV
        return inf(sp), 0
    if is_inf(c):
        return inf(sc), 0
    p = value(a) * value(b)
    if neg_prod:
        p = -p
    cv = value(c)
    if neg_add:
        cv = -cv
    if p == 0:
        # exact zero product: the result is the addend exactly (sign rule for zero + zero)
        if not is_zero(c):
            return (c ^ (0x80000000 if neg_add else 0)), 0
        if sp == sc:
            return zero(sp), 0
        return zero(1 if rm == RDN else 0), 0
    return _exact_or_zero(p + cv, rm, None)


def fma_op(op: int, a: int, b: int, c: int, rm: int) -> tuple[int, int]:
    return {OP_FMADD: lambda: fma_generic(a, b, c, rm, False, False),
            OP_FMSUB: lambda: fma_generic(a, b, c, rm, False, True),
            OP_FNMSUB: lambda: fma_generic(a, b, c, rm, True, False),
            OP_FNMADD: lambda: fma_generic(a, b, c, rm, True, True)}[op]()


def _lt_total(a: int, b: int) -> bool:
    """a < b for non-NaN operands with -0 < +0 (minimumNumber ordering)."""
    if is_zero(a) and is_zero(b):
        return sign(a) == 1 and sign(b) == 0
    return value_or_inf(a) < value_or_inf(b)


def value_or_inf(b: int):
    if is_inf(b):
        return math.inf if sign(b) == 0 else -math.inf
    return value(b)


def fminmax(a: int, b: int, is_max: bool) -> tuple[int, int]:
    fl = NV if (is_snan(a) or is_snan(b)) else 0
    if is_nan(a) and is_nan(b):
        return QNAN, fl
    if is_nan(a):
        return b, fl
    if is_nan(b):
        return a, fl
    if is_max:
        return (b if _lt_total(a, b) else a), fl
    return (b if _lt_total(b, a) else a), fl


def fcmp(op: int, a: int, b: int) -> tuple[int, int]:
    if is_nan(a) or is_nan(b):
        if op == OP_FEQ:
            return 0, NV if (is_snan(a) or is_snan(b)) else 0
        return 0, NV
    va, vb = value_or_inf(a), value_or_inf(b)
    if op == OP_FEQ:
        return int(va == vb), 0
    if op == OP_FLT:
        return int(va < vb), 0
    return int(va <= vb), 0


def elem(op: int, a: int, b: int, c: int, rm: int) -> tuple[int, int]:
    """One element operation of the vector array (Module 02 semantics)."""
    if op == OP_FMV:
        return a, 0
    if op == OP_FADD:
        return fadd(a, b, rm)
    if op == OP_FSUB:
        return fsub(a, b, rm)
    if op == OP_FMUL:
        return fmul(a, b, rm)
    if op in FMA_OPS:
        return fma_op(op, a, b, c, rm)
    if op == OP_FMIN:
        return fminmax(a, b, False)
    if op == OP_FMAX:
        return fminmax(a, b, True)
    if op in (OP_FEQ, OP_FLT, OP_FLE):
        return fcmp(op, a, b)
    if op == OP_IADD:
        return (a + b) & 0xFFFFFFFF, 0
    if op == OP_IMUL:
        return (a * b) & 0xFFFFFFFF, 0
    raise ValueError(f"no such op {op}")


def elem_legal(op: int, rm: int) -> bool:
    if op == OP_FMV:
        return True
    if op in ROUNDING_OPS:
        return rm <= 4
    return op in (OP_FMIN, OP_FMAX, OP_FEQ, OP_FLT, OP_FLE, OP_IADD, OP_IMUL)


def cmd_legal(op: int, rm: int, red: int, bcast: int) -> bool:
    """Array legality rule (Module 03 docs/ARRAY_INTERFACE.md sec. 4.3; RED_EN = 1, EN_FCMP = EN_INT = 1)."""
    if red:
        return op <= 0x07 and rm <= 4 and bcast == 0
    return elem_legal(op, rm)


def reads(op: int, bcast: int) -> int:
    """Operand mask {c,b,a} an operation reads, minus broadcast operands."""
    r = 0b001
    if op != OP_FMV:
        r |= 0b010
    if op in FMA_OPS:
        r |= 0b100
    return r & ~bcast & 0b111


def flops_per_elem(op: int) -> int:
    if op in FMA_OPS:
        return 2
    if op in (OP_FADD, OP_FSUB, OP_FMUL):
        return 1
    return 0


def reduce_sum(xs: list, n_lanes: int, init: int, rm: int) -> tuple[int, int]:
    """Module 03 reduction (docs/REDUCTION.md sec. 1): per-beat pairwise tree over lane index
    (absent leaves skipped, never replaced by an identity), then strict beat-order accumulation.
    xs: element results (bits) of the active elements in element order, or None for absent."""
    flags = 0
    acc = init

    def tree(leaves):
        nonlocal flags
        if len(leaves) == 1:
            return leaves[0]
        half = len(leaves) // 2
        l, r = tree(leaves[:half]), tree(leaves[half:])
        if l is None:
            return r
        if r is None:
            return l
        v, f = fadd(l, r, rm)
        flags |= f
        return v

    for g in range(0, len(xs), n_lanes):
        leaves = xs[g:g + n_lanes]
        leaves += [None] * (n_lanes - len(leaves))
        s = tree(leaves)
        if s is not None:
            acc, f = fadd(acc, s, rm)
            flags |= f
    return acc, flags


# ------------------------------------------------------------------ helpers
def f2b(x: float) -> int:
    return struct.unpack("<I", struct.pack("<f", x))[0]


def b2f(b: int) -> float:
    return struct.unpack("<f", struct.pack("<I", b & 0xFFFFFFFF))[0]
