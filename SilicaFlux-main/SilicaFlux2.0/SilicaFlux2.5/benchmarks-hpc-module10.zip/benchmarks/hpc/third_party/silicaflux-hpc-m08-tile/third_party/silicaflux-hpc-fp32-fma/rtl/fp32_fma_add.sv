// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_add.sv -- STEP 5: signed accumulation
//
// Produces |P +/- C| as a 75-bit magnitude and the sign of the exact sum.
//
// Effective addition  (sp == sc): mag = P + C, sign = sp. No overflow:
//   P < 2^48, C < 2^74  =>  P + C < 2^75.
// Effective subtraction (sp != sc): two 76-bit adders run in parallel
//   d_pc = P + ~C + !sticky  = P - C_hi - sticky
//   d_cp = C + ~P + 1        = C_hi - P
// When sticky = 1 the true addend is C_hi + f with 0 < f < 1 frame LSB, so
//   P - C = (P - C_hi - 1) + (1 - f): integer part d_pc, fraction kept as
//   sticky. sticky = 1 implies P > C (see fp32_fma_align), so d_pc >= 0 and
//   d_cp is only selected when sticky = 0, where it is exact.
// =============================================================================
`default_nettype none

module fp32_fma_add (
  input  wire logic [47:0] prod,
  input  wire logic [73:0] addend,
  input  wire logic        sticky,
  input  wire logic        sp,
  input  wire logic        sc,
  output logic      [74:0] mag,
  output logic             sign
);
  logic [75:0] p_ext, c_ext, s_add, d_pc, d_cp;
  logic        eff_sub, neg;

  assign eff_sub = sp ^ sc;
  assign p_ext   = {28'd0, prod};
  assign c_ext   = {2'd0, addend};

  assign s_add = p_ext + c_ext;
  assign d_pc  = p_ext + ~c_ext + {75'd0, ~sticky};
  assign d_cp  = c_ext + ~p_ext + 76'd1;
  assign neg   = d_pc[75];

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_msb;
  assign unused_msb = s_add[75] ^ d_cp[75];   // provably zero / sign only
  /* verilator lint_on UNUSEDSIGNAL */

  always_comb begin
    if (!eff_sub) begin
      mag  = s_add[74:0];
      sign = sp;
    end else if (neg) begin
      mag  = d_cp[74:0];
      sign = sc;
    end else begin
      mag  = d_pc[74:0];
      sign = sp;
    end
  end
endmodule

`default_nettype wire
