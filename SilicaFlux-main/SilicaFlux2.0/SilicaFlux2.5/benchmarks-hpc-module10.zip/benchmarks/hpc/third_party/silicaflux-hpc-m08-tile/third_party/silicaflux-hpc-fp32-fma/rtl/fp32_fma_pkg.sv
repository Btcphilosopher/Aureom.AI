// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_pkg.sv -- constants, inter-stage payload types, shared functions
//
// Tool-portability rules followed by every file of this module (so the same
// sources elaborate unmodified in Yosys 0.33, Verilator 5.020 and Icarus 12,
// the tool baseline documented by SilicaFlux-V):
//   * package items are referenced with explicit pkg:: scope (no `import`),
//   * functions assign their own name (no `return`),
//   * no $bits(type) / type casts -- struct widths are explicit constants
//     below and are cross-checked by Verilator -Wall WIDTH lint,
//   * module ports are plain vectors; packed structs are used internally.
// =============================================================================
`default_nettype none

package fp32_fma_pkg;

  /* verilator lint_off UNUSEDPARAM */
  // ---------------------------------------------------------------------------
  // IEEE 754 binary32
  // ---------------------------------------------------------------------------
  localparam int          SIG_W         = 24;           // precision p
  localparam logic [31:0] CANONICAL_NAN = 32'h7FC0_0000; // RISC-V canonical qNaN

  // ---------------------------------------------------------------------------
  // Rounding mode encoding (RISC-V frm; SoftFloat uses the same numbering).
  // Reserved encodings 3'b101..3'b111 are executed as RNE.
  // ---------------------------------------------------------------------------
  localparam logic [2:0] RM_RNE = 3'b000;  // to nearest, ties to even
  localparam logic [2:0] RM_RTZ = 3'b001;  // toward zero
  localparam logic [2:0] RM_RDN = 3'b010;  // toward -infinity
  localparam logic [2:0] RM_RUP = 3'b011;  // toward +infinity
  localparam logic [2:0] RM_RMM = 3'b100;  // to nearest, ties away from zero

  // ---------------------------------------------------------------------------
  // Exception flag bit positions in out_flags. Identical to RISC-V fflags and
  // to the SoftFloat softfloat_flag_* bit values.
  // ---------------------------------------------------------------------------
  localparam int FLG_NX = 0;  // inexact
  localparam int FLG_UF = 1;  // underflow
  localparam int FLG_OF = 2;  // overflow
  localparam int FLG_DZ = 3;  // divide-by-zero (never raised by an FMA)
  localparam int FLG_NV = 4;  // invalid operation

  // ---------------------------------------------------------------------------
  // Alignment frame (derivation: docs/PIPELINE.md section 3).
  //   * multiplicand significands are pre-normalised, so the 48-bit product
  //     has its leading one at frame bit 46 or 47 and occupies [47:0];
  //   * the addend significand starts at frame bits [73:50] (shamt = 0) and is
  //     shifted right by shamt in [0, SHAMT_MAX]; bits leaving bit 0 are ORed
  //     into a sticky bit;
  //   * the signed sum is 76 bits, its magnitude 75 bits [74:0].
  // Exponent bookkeeping: "X0" is the biased exponent that frame bit 74 would
  // carry, so the normalised result exponent is e_norm = X0 - lzc(sum).
  // ---------------------------------------------------------------------------
  localparam int PROD_W      = 48;   // 2p
  localparam int ALN_W       = 74;   // 3p + 2
  localparam int ACC_W       = 75;   // 3p + 3
  localparam int SHAMT_W     = 7;
  localparam int SHAMT_MAX   = 75;   // > ALN_W - 1 : addend entirely in sticky
  localparam int XW          = 12;   // signed internal exponent width
  localparam int LZC_W       = 7;    // clog2(ACC_W + 1)
  localparam int SH_OFS      = 100;  // shamt_raw = ea + eb - ec - SH_OFS
  localparam int X0_PROD_OFS = 99;   // X0 = ea + eb - X0_PROD_OFS (product anchor)
                                     // X0 = ec + 1                 (addend anchor)
  localparam int DSH_MAX     = 26;   // denormalisation shift saturation
  /* verilator lint_on UNUSEDPARAM */

  // ---------------------------------------------------------------------------
  // Inter-stage payloads. Structs are deliberately flat (no nested structs:
  // Icarus 12 mis-resolves nested member selects) and the tag travels
  // separately because TAG_W is a module parameter. Each *_W constant equals
  // the sum of its member widths (checked by Verilator -Wall WIDTH lint).
  // Common tail of every payload after step 2 -- special-case resolution:
  //   spec_valid  : result fully determined by operand classes (step 2)
  //   spec_nv     : invalid-operation flag of that result
  //   spec_result : the result
  // ---------------------------------------------------------------------------
  // after step 1 (unpack): 3 x 37 + 3 = 114
  //   per operand: sign, exp_eff (biased; 1 for zero/subnormal), sig (with
  //   hidden bit), is_zero, is_inf, is_nan, is_snan
  typedef struct packed {
    logic        a_sign;  logic [7:0] a_exp;  logic [23:0] a_sig;
    logic        a_zero;  logic       a_inf;  logic        a_nan;  logic a_snan;
    logic        b_sign;  logic [7:0] b_exp;  logic [23:0] b_sig;
    logic        b_zero;  logic       b_inf;  logic        b_nan;  logic b_snan;
    logic        c_sign;  logic [7:0] c_exp;  logic [23:0] c_sig;
    logic        c_zero;  logic       c_inf;  logic        c_nan;  logic c_snan;
    logic [2:0]  rm;
  } p_unpack_t;
  localparam int P_UNPACK_W = 114;

  // after step 2 (prepare): 24*3 + 7 + 12 + 1 + 1 + 3 + 34 = 130
  typedef struct packed {
    logic [23:0]   ma;      // normalised multiplicand significands
    logic [23:0]   mb;
    logic [23:0]   mc;      // addend significand (not normalised)
    logic [6:0]    shamt;   // addend right-shift in the alignment frame
    logic [11:0]   x0;      // signed: biased exponent of frame bit 74
    logic          sp;      // product sign
    logic          sc;      // addend sign
    logic [2:0]    rm;
    logic          spec_valid;
    logic          spec_nv;
    logic [31:0]   spec_result;
  } p_prep_t;
  localparam int P_PREP_W = 130;

  // after steps 3+4 (multiply || align): 48 + 74 + 1 + 12 + 1 + 1 + 3 + 34 = 174
  typedef struct packed {
    logic [47:0]   prod;
    logic [73:0]   addend;
    logic          sticky;
    logic [11:0]   x0;
    logic          sp;
    logic          sc;
    logic [2:0]    rm;
    logic          spec_valid;
    logic          spec_nv;
    logic [31:0]   spec_result;
  } p_mul_t;
  localparam int P_MUL_W = 174;

  // after step 5 (signed accumulation): 75 + 1 + 1 + 12 + 3 + 34 = 126
  typedef struct packed {
    logic [74:0]   mag;
    logic          sticky;
    logic          sign;
    logic [11:0]   x0;
    logic [2:0]    rm;
    logic          spec_valid;
    logic          spec_nv;
    logic [31:0]   spec_result;
  } p_add_t;
  localparam int P_ADD_W = 126;

  // after step 6 (normalisation + exponent range classification):
  // 75 + 8 + 5 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 3 + 34 = 133
  // All decisions that depend only on the normalised exponent e_norm are
  // made in step 6 so that step 7 starts directly with the shift.
  typedef struct packed {
    logic [74:0]   mn;      // normalised magnitude, bit 74 set unless zero
    logic [7:0]    e_pk;    // pre-rounding exponent field: e_norm, or 1 if subnormal
    logic [4:0]    dsh;     // denormalisation right shift (0 if normal, <= 26)
    logic          subn;    // e_norm < 1  (tiny before rounding)
    logic          e_lt0;   // e_norm < 0
    logic          e_eq0;   // e_norm == 0
    logic          e_ge255; // e_norm >= 255 (overflow regardless of rounding)
    logic          e_eq254; // e_norm == 254 (overflow iff rounding carries out)
    logic          sticky;
    logic          sign;
    logic          zero;    // exact zero sum
    logic [2:0]    rm;
    logic          spec_valid;
    logic          spec_nv;
    logic [31:0]   spec_result;
  } p_norm_t;
  localparam int P_NORM_W = 133;

  // ---------------------------------------------------------------------------
  // Rounding increment decision for the five IEEE 754 rounding attributes.
  //   lsb : least significant retained bit
  //   rnd : first discarded bit (round bit)
  //   stk : OR of all further discarded bits (sticky)
  // ---------------------------------------------------------------------------
  function automatic logic round_up(input logic [2:0] rm, input logic sign,
                                    input logic lsb, input logic rnd,
                                    input logic stk);
    case (rm)
      RM_RTZ:  round_up = 1'b0;
      RM_RDN:  round_up = sign & (rnd | stk);
      RM_RUP:  round_up = ~sign & (rnd | stk);
      RM_RMM:  round_up = rnd;
      default: round_up = rnd & (stk | lsb);   // RNE
    endcase
  endfunction

  // On overflow: does the rounding attribute deliver infinity (1) or the
  // largest finite magnitude (0)?
  function automatic logic overflow_to_inf(input logic [2:0] rm, input logic sign);
    case (rm)
      RM_RTZ:  overflow_to_inf = 1'b0;
      RM_RDN:  overflow_to_inf = sign;
      RM_RUP:  overflow_to_inf = ~sign;
      default: overflow_to_inf = 1'b1;          // RNE, RMM
    endcase
  endfunction

endpackage

`default_nettype wire
