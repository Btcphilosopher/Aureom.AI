"""File lists for every SilicaFlux-HPC Module 08 build (single source for all scripts)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TP = ROOT / "third_party"
DF = TP / "silicaflux-datafabric"
SL = TP / "silicaflux-sramlib/rtl/mem"
SPM = TP / "silicaflux-hpc-m04-scratchpad/rtl"
VA = TP / "silicaflux-hpc-m03-vector-array"
M05 = TP / "silicaflux-hpc-m05-dma-adapter/rtl"
M01 = TP / "silicaflux-hpc-fp32-fma/rtl"

SRAMLIB = [SL / f for f in [
    "sram_rsp_path.sv", "sram_backend_1rw.sv", "sram_backend_1r1w.sv", "sram_backend_2rw.sv", "sram_sp.sv",
    "backends/generic/sram_generic_1rw.sv", "backends/generic/sram_generic_1r1w.sv", "backends/generic/sram_generic_2rw.sv",
    "backends/fpga/sram_fpga_1rw.sv", "backends/fpga/sram_fpga_1r1w.sv", "backends/fpga/sram_fpga_2rw.sv",
    "backends/asic/sram_asic_array.sv", "backends/asic/sram_leaf_sky130.sv", "backends/asic/sram_leaf_gf180.sv",
    "backends/asic/sram_leaf_ihp1p.sv", "backends/asic/sram_leaf_ihp2p.sv", "backends/asic/stubs/sram_macro_blackboxes.sv"]]
DMA_ENGINE = [DF / "rtl/dma" / f for f in ["dma_fifo.sv", "dma_validate.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv"]]
XBAR = [DF / "rtl/interconnect" / f for f in [
    "sfb_addr_decoder.sv", "sfb_arbiter.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv", "sfb_error_slave.sv",
    "sfb_crossbar.sv", "sfb_skid_buffer.sv", "sfb_reg_slice.sv", "sfb_v1_slave_adapter.sv"]]
SFB_MEM = [DF / "rtl/mem/sfb_sram_slave.sv"]
SCRATCHPAD = [SPM / f for f in ["hpc_spm_addr_map.sv", "hpc_spm_bank_arb.sv", "hpc_spm_bank.sv", "hpc_spm_perf.sv",
                                "hpc_scratchpad.sv"]]
VARRAY = [VA / l.strip() for l in (VA / "rtl/files.f").read_text().split() if l.strip()]
ADAPTER = [M05 / f for f in ["hpc_dma_perf.sv", "hpc_dma_spm_port.sv", "hpc_dma_route.sv", "hpc_dma_adapter.sv"]]
PERIPH_BRIDGE = [DF / "third_party/silicaflux-v/rtl/bus/sfv_periph_bridge.sv"]
CHECKER = [DF / "tb/common/sfb_protocol_checker.sv"]
TILE_RTL = [ROOT / "rtl" / f for f in ["hpc_command_queue.sv", "hpc_perf_counters.sv", "hpc_tile_regs.sv",
                                       "hpc_tile_sched.sv", "hpc_tile_lsu.sv", "silicaflux_hpc_tile.sv"]]
INCDIRS = [ROOT / "rtl", M05, DF / "rtl/dma", SL, SL / "backends/asic", SPM]

# synthesizable tile (no testbench / checker)
TILE_SYNTH = SRAMLIB + DMA_ENGINE + SCRATCHPAD + VARRAY + ADAPTER + TILE_RTL
# integration testbench: the tile, the real DataFabric crossbar + SRAM slaves + peripheral bridge as the host
# side, the SFB2 protocol checker on every SFB2 link
TILE_TB = TILE_SYNTH + XBAR + SFB_MEM + PERIPH_BRIDGE + CHECKER + [ROOT / "tb/sfb_fault_slave.sv",
                                                                   ROOT / "tb/tb_silicaflux_hpc_tile.sv"]
SIM_DEFINES = ["HPC_TILE_ASSERT", "HPC_DMA_ASSERT", "HPC_SPM_ASSERT", "SRAMLIB_ASSERT", "SRAMLIB_POISON"]


def tile_wrapper(params: dict, name: str = "cfg_top") -> str:
    """A top module that instantiates silicaflux_hpc_tile with literal parameters (Yosys 0.33 trips an internal
    assertion when the top is re-derived through `hierarchy -chparam`, so synthesis never uses chparam)."""
    dw = int(params.get("DATA_WIDTH", 32))
    sb = max(dw // 8, 1)
    plist = ", ".join(f".{k}({v})" for k, v in params.items())
    return f"""`default_nettype none
module {name} (
  input  wire logic clk, rst_n, rb_sel, rb_we, input wire logic [11:0] rb_addr, input wire logic [31:0] rb_wdata,
  output logic [31:0] rb_rdata, output logic rb_err,
  input  wire logic hs_req_valid, output logic hs_req_ready, input wire logic hs_req_write,
  input  wire logic [31:0] hs_req_addr, input wire logic [{dw - 1}:0] hs_req_wdata, input wire logic [{sb - 1}:0] hs_req_wstrb,
  output logic hs_rsp_valid, input wire logic hs_rsp_ready, output logic [{dw - 1}:0] hs_rsp_rdata, output logic hs_rsp_error,
  output logic fab_req_valid, input wire logic fab_req_ready, output logic fab_req_write, output logic [31:0] fab_req_addr,
  output logic [{dw - 1}:0] fab_req_wdata, output logic [{sb - 1}:0] fab_req_wstrb, input wire logic fab_rsp_valid,
  output logic fab_rsp_ready, input wire logic [{dw - 1}:0] fab_rsp_rdata, input wire logic fab_rsp_error,
  output logic irq, busy, halted
);
  silicaflux_hpc_tile #({plist}) u_tile (.*);
endmodule
`default_nettype wire
"""


def harness_wrapper(params: dict, name: str = "fpga_top") -> str:
    plist = ", ".join(f".{k}({v})" for k, v in params.items())
    return f"""`default_nettype none
module {name} (input wire logic clk, input wire logic btn, output logic [7:0] led);
  hpc_tile_fpga_harness #({plist}) u_h (.*);
endmodule
`default_nettype wire
"""
