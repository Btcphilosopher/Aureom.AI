// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_pack.sv -- STEP 9: output packing
//
// Result priority:
//   1. special-case result from step 2 (NaN, infinity, zero product)
//   2. exact zero sum: +0, or -0 when rounding toward -infinity
//      (IEEE 754-2019 sec. 6.3)
//   3. overflow: infinity or the largest finite magnitude, per rounding
//      attribute (fp32_fma_pkg::overflow_to_inf)
//   4. rounded finite result; the exponent field is 0 when the rounded
//      significand has no hidden bit (subnormal result).
// =============================================================================
`default_nettype none

module fp32_fma_pack (
  input  wire logic        sign,
  input  wire logic [23:0] sig_f,
  input  wire logic [7:0]  exp_f,
  input  wire logic        overflow,
  input  wire logic        zero,
  input  wire logic [2:0]  rm,
  input  wire logic        spec_valid,
  input  wire logic [31:0] spec_result,
  output logic      [31:0] result
);
  always_comb begin
    if (spec_valid)
      result = spec_result;
    else if (zero)
      result = {(rm == fp32_fma_pkg::RM_RDN), 31'd0};
    else if (overflow)
      result = fp32_fma_pkg::overflow_to_inf(rm, sign) ? {sign, 8'hFF, 23'd0}
                                                       : {sign, 8'hFE, 23'h7F_FFFF};
    else
      result = {sign, (sig_f[23] ? exp_f : 8'h00), sig_f[22:0]};
  end
endmodule

`default_nettype wire
