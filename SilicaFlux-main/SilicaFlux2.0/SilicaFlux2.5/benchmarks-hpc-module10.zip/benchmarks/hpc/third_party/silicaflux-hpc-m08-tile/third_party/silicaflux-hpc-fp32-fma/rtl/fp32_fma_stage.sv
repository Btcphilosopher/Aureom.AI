// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_stage.sv -- elastic pipeline boundary (valid/ready)
//
// REG = 1 : one register slot.
//   up_ready = !full || dn_ready      (a full slot accepts when it drains)
//   The payload register loads only on an upstream handshake, so it holds
//   its value -- the downstream payload is stable -- for as long as
//   dn_valid && !dn_ready. Bubbles collapse: an empty slot always accepts.
//   Only the valid bit is reset (asynchronous, active low, SilicaFlux-V
//   convention); the payload flops are not reset because nothing observes
//   them while valid is low.
// REG = 0 : combinational pass-through (used to merge adjacent steps into
//   one pipeline stage through the PIPE_CFG parameter of fp32_fma).
// =============================================================================
`default_nettype none

module fp32_fma_stage #(
  parameter int W   = 1,
  parameter bit REG = 1'b1
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         up_valid,
  output logic              up_ready,
  input  wire logic [W-1:0] up_data,
  output logic              dn_valid,
  input  wire logic         dn_ready,
  output logic      [W-1:0] dn_data
);
  if (REG) begin : g_reg
    logic         full_q;
    logic [W-1:0] data_q;

    assign up_ready = !full_q || dn_ready;

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n)        full_q <= 1'b0;
      else if (up_ready) full_q <= up_valid;
    end

    always_ff @(posedge clk) begin
      if (up_valid && up_ready) data_q <= up_data;
    end

    assign dn_valid = full_q;
    assign dn_data  = data_q;
  end else begin : g_wire
    /* verilator lint_off UNUSEDSIGNAL */
    logic unused_clk_rst;
    assign unused_clk_rst = clk ^ rst_n;
    /* verilator lint_on UNUSEDSIGNAL */
    assign up_ready = dn_ready;
    assign dn_valid = up_valid;
    assign dn_data  = up_data;
  end
endmodule

`default_nettype wire
