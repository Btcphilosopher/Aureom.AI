// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_prep.sv -- STEP 2: exponent and significand preparation
//
// Datapath preparation (derivation in docs/PIPELINE.md section 3):
//   * Multiplicand significands are left-normalised (subnormal inputs get
//     their leading one moved to bit 23 and their exponent lowered by the
//     same amount, possibly below 1). This keeps the product leading one at
//     frame bit 46/47 for *every* nonzero product, which the alignment and
//     rounding analysis relies on. The addend is not normalised.
//   * shamt_raw = ea + eb - ec - 100 places the addend relative to the
//     product. shamt_raw <= 0 (addend dominates, product < 1/4 ulp of the
//     addend) clamps to 0 and anchors the frame on the addend; otherwise the
//     frame is anchored on the product and shamt saturates at 75.
//   * X0 is the biased exponent of frame bit 74 under the chosen anchor.
//
// Special cases (fully decided here, carried to the end of the pipeline and
// selected over the datapath result by step 9):
//   NaN result  : a or b NaN, c NaN, 0 x inf, or inf x y - inf (eff. sub)
//   inf result  : inf product (no NaN, no 0 x inf), or inf addend
//   zero product: a or b zero (other operand finite) -> c, or a signed zero
// Invalid (NV) : any signalling NaN operand, 0 x inf (even when c is a quiet
//                NaN -- the RISC-V/SoftFloat choice of the option left open
//                by IEEE 754-2019 sec. 7.2(c)), or inf - inf.
//
// NaN results (parameter NAN_PROPAGATE):
//   0 : always the canonical quiet NaN 32'h7FC00000 (RISC-V F extension;
//       reference: SoftFloat-3e RISCV specialisation)
//   1 : payload propagation with the priority of the SoftFloat-3e
//       ARM-VFPv2 specialisation:
//         sNaN c -> quiet(c)
//         else NaN in a/b -> quiet(first sNaN of a,b) else first qNaN of a,b
//         else invalid 0 x inf / inf - inf -> canonical NaN
//         else (qNaN c) -> c
// =============================================================================
`default_nettype none

module fp32_fma_prep #(
  parameter bit NAN_PROPAGATE = 1'b0
) (
  // unpacked operands (step 1)
  input  wire logic        a_sign, b_sign, c_sign,
  input  wire logic [7:0]  a_exp,  b_exp,  c_exp,
  input  wire logic [23:0] a_sig,  b_sig,  c_sig,
  input  wire logic        a_zero, b_zero, c_zero,
  input  wire logic        a_inf,  b_inf,  c_inf,
  input  wire logic        a_nan,  b_nan,  c_nan,
  input  wire logic        a_snan, b_snan, c_snan,
  input  wire logic [2:0]  rm_in,
  // datapath preparation
  output logic [23:0]      ma,
  output logic [23:0]      mb,
  output logic [23:0]      mc,
  output logic [6:0]       shamt,
  output logic [11:0]      x0,        // signed
  output logic             sp,
  output logic             sc,
  output logic [2:0]       rm,
  // special-case resolution
  output logic             spec_valid,
  output logic             spec_nv,
  output logic [31:0]      spec_result
);
  // ---------------------------------------------------------------------------
  // Rounding mode: reserved encodings execute as RNE.
  // ---------------------------------------------------------------------------
  assign rm = (rm_in > fp32_fma_pkg::RM_RMM) ? fp32_fma_pkg::RM_RNE : rm_in;

  // ---------------------------------------------------------------------------
  // Multiplicand pre-normalisation
  // ---------------------------------------------------------------------------
  logic [4:0] lza, lzb;
  logic       unused_za, unused_zb;

  fp32_fma_lzc #(.W(24), .CW(5)) u_lza (.x(a_sig), .cnt(lza), .zero(unused_za));
  fp32_fma_lzc #(.W(24), .CW(5)) u_lzb (.x(b_sig), .cnt(lzb), .zero(unused_zb));

  assign ma = a_sig << lza;
  assign mb = b_sig << lzb;
  assign mc = c_sig;

  // ---------------------------------------------------------------------------
  // Exponent arithmetic (12-bit two's complement; ranges in PIPELINE.md)
  // ---------------------------------------------------------------------------
  // Re-associated so that the two 24-bit LZCs run in parallel with the
  // exponent sums: shamt_raw = (ea + eb - ec - 100) - (lza + lzb),
  //                X0_prod   = (ea + eb - 99)      - (lza + lzb).
  logic signed [11:0] ec, base_sh, base_x0, lzs, shamt_raw, x0_prod;
  logic               anchor_c;

  assign ec        = $signed({4'd0, c_exp});
  assign base_sh   = $signed({4'd0, a_exp}) + $signed({4'd0, b_exp}) - ec - 12'sd100;  // SH_OFS
  assign base_x0   = $signed({4'd0, a_exp}) + $signed({4'd0, b_exp}) - 12'sd99;        // X0_PROD_OFS
  assign lzs       = $signed({7'd0, lza}) + $signed({7'd0, lzb});
  assign shamt_raw = base_sh - lzs;
  assign x0_prod   = base_x0 - lzs;

  // A zero addend never anchors the frame (it contributes nothing).
  assign anchor_c  = ~c_zero & (shamt_raw <= 12'sd0);

  always_comb begin
    if (c_zero)                    shamt = 7'd75;          // SHAMT_MAX
    else if (anchor_c)             shamt = 7'd0;
    else if (shamt_raw >= 12'sd75) shamt = 7'd75;
    else                           shamt = shamt_raw[6:0];
  end

  assign x0 = anchor_c ? (ec + 12'sd1) : x0_prod;

  assign sp = a_sign ^ b_sign;
  assign sc = c_sign;

  // ---------------------------------------------------------------------------
  // Special cases
  // ---------------------------------------------------------------------------
  logic prod_nan, prod_inv, prod_inf, add_inv, zero_prod, any_snan, res_nan;

  assign prod_nan  = a_nan | b_nan;
  assign prod_inv  = (a_zero & b_inf) | (a_inf & b_zero);          // 0 x inf
  assign prod_inf  = (a_inf | b_inf) & ~prod_nan & ~prod_inv;
  assign add_inv   = prod_inf & c_inf & (sp ^ sc);                 // inf - inf
  assign zero_prod = (a_zero | b_zero) & ~prod_nan & ~prod_inv;
  assign any_snan  = a_snan | b_snan | c_snan;
  assign res_nan   = prod_nan | c_nan | prod_inv | add_inv;

  // NaN payload selection
  logic [31:0] nan_result;
  logic [31:0] qa, qb, qc, na, nb;
  assign na = {a_sign, 8'hFF, a_sig[22:0]};
  assign nb = {b_sign, 8'hFF, b_sig[22:0]};
  assign qa = {a_sign, 8'hFF, 1'b1, a_sig[21:0]};
  assign qb = {b_sign, 8'hFF, 1'b1, b_sig[21:0]};
  assign qc = {c_sign, 8'hFF, 1'b1, c_sig[21:0]};   // = c when c is a qNaN

  if (!NAN_PROPAGATE) begin : g_nan_canonical
    /* verilator lint_off UNUSEDSIGNAL */
    logic unused_payload;
    assign unused_payload = ^{qa, qb, qc, na, nb};
    /* verilator lint_on UNUSEDSIGNAL */
    assign nan_result = fp32_fma_pkg::CANONICAL_NAN;
  end else begin : g_nan_propagate
    always_comb begin
      if (c_snan)                    nan_result = qc;
      else if (prod_nan) begin
        if (a_snan)                  nan_result = qa;
        else if (b_snan)             nan_result = qb;
        else if (a_nan)              nan_result = na;
        else                         nan_result = nb;
      end
      else if (prod_inv || add_inv)  nan_result = fp32_fma_pkg::CANONICAL_NAN;
      else                           nan_result = qc;
    end
  end

  // Zero-product result: c itself, or the IEEE sum-of-zeros sign rule
  // (x + -x = +0, except -0 when rounding toward -infinity).
  logic zz_sign;
  assign zz_sign = (sp == sc) ? sp : (rm == fp32_fma_pkg::RM_RDN);

  always_comb begin
    spec_valid  = 1'b1;
    spec_nv     = 1'b0;
    spec_result = {c_sign, 8'hFF, c_sig[22:0]};      // c (inf / finite)
    if (res_nan) begin
      spec_nv     = any_snan | prod_inv | add_inv;
      spec_result = nan_result;
    end else if (prod_inf) begin
      spec_result = {sp, 8'hFF, 23'd0};
    end else if (c_inf) begin
      spec_result = {c_sign, 8'hFF, 23'd0};
    end else if (zero_prod) begin
      if (c_zero) spec_result = {zz_sign, 31'd0};
      else        spec_result = {c_sign, (c_sig[23] ? c_exp : 8'h00), c_sig[22:0]};
    end else begin
      spec_valid  = 1'b0;
    end
  end
endmodule

`default_nettype wire
