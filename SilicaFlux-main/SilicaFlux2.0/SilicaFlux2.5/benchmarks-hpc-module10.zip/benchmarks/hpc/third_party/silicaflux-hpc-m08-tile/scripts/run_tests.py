#!/usr/bin/env python3
"""Run integration tests of silicaflux_hpc_tile in one or more configurations.

  run_tests.py --config baseline --tests vec_add,dma --seeds 1,2 [--sim verilator|icarus] [--jobs 4]
  run_tests.py --stage 1          (stage 1 bring-up: 2 lanes, command queue + scratchpad + vector engine)
  run_tests.py --stage all        (stage 1, then the full baseline, then the configuration sweep;
                                   a failing stage stops the run)
Writes reports/regression.{md,json} (stage runs) and logs to build/logs/.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import re
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402
import files as F  # noqa: E402

DEFAULT = dict(NUM_LANES=4, DATA_WIDTH=32, SCRATCHPAD_BYTES=65536, NUM_BANKS=4, CMD_QUEUE_DEPTH=8,
               DMA_BUFFER_DEPTH=0, ENABLE_PERF_COUNTERS=1, CPL_QUEUE_DEPTH=8, SPM_ECC=0, SPM_READ_LATENCY=1,
               LSU_MAX_PORTS=4, EXT0_LATENCY=1)

CONFIGS = {
    # stage 1: the two-lane path first
    "s1_n2":        dict(NUM_LANES=2, NUM_BANKS=2),
    # stage 2: the brief's baseline (4 FP32 lanes, banked scratchpad, single DMA path, in-order completion)
    "baseline":     dict(),
    # stage 3: parameter sweep
    "n1_b1":        dict(NUM_LANES=1, NUM_BANKS=1, SCRATCHPAD_BYTES=16384, CMD_QUEUE_DEPTH=2, CPL_QUEUE_DEPTH=2),
    "n8_b8":        dict(NUM_LANES=8, NUM_BANKS=8),
    "n16_b16":      dict(NUM_LANES=16, NUM_BANKS=16, SCRATCHPAD_BYTES=131072),
    "n4_dw64":      dict(DATA_WIDTH=64, NUM_BANKS=4),
    "n2_dw128":     dict(NUM_LANES=2, DATA_WIDTH=128, NUM_BANKS=2),
    "n4_buffered":  dict(DMA_BUFFER_DEPTH=8, CMD_QUEUE_DEPTH=4, CPL_QUEUE_DEPTH=4),
    "n4_rl2_ext2":  dict(SPM_READ_LATENCY=2, EXT0_LATENCY=2, LSU_MAX_PORTS=2, CMD_QUEUE_DEPTH=16, CPL_QUEUE_DEPTH=16),
    "n4_rl4":       dict(SPM_READ_LATENCY=4, NUM_BANKS=8),
    "n4_parity":    dict(SPM_ECC=1),
    "n4_noperf":    dict(ENABLE_PERF_COUNTERS=0, LSU_MAX_PORTS=1),
}
STAGE1_TESTS = ["s1_vec_basic", "s1_vec_random", "s1_vec_reduce", "s1_vec_long"]
FULL_TESTS = STAGE1_TESTS + ["vec_add", "vec_mul", "vec_fma", "dma", "ordering", "contention", "perf", "reset",
                             "invalid", "backpressure", "kernels_many", "parity"]
SWEEP_TESTS = ["s1_vec_random", "s1_vec_reduce", "vec_fma", "dma", "ordering", "contention", "invalid", "reset",
               "backpressure", "kernels_many", "parity", "perf"]


def cfg_of(name):
    c = dict(DEFAULT)
    c.update(CONFIGS[name])
    return c


def build(name, cfg, sim):
    params = {k: v for k, v in cfg.items()}
    if sim == "verilator":
        return C.verilator_build("tb_silicaflux_hpc_tile", F.TILE_TB, params, F.SIM_DEFINES, f"tile_{name}")
    return C.icarus_build("tb_silicaflux_hpc_tile", F.TILE_TB, params, F.SIM_DEFINES, f"tile_{name}")


def run_one(exe, sim, cfgname, test, seed, tdir, logdir):
    args = [f"+prog={tdir / 'prog.txt'}", f"+init={tdir / 'init.hex'}", f"+final={tdir / 'final.hex'}",
            f"+name={test}", f"+seed={seed}"]
    cmd = ([str(exe)] if sim == "verilator" else ["vvp", "-n", str(exe)]) + args
    rc, out, dt = C.run(cmd, timeout=7200)
    log = logdir / f"{sim}__{cfgname}__{test}__s{seed}.log"
    log.write_text(" ".join(cmd) + "\n" + out)
    m = re.search(r"TB_TILE RESULT (PASS|FAIL)", out)
    st = re.search(r"TB_TILE stats .*", out)
    ok = bool(m and m.group(1) == "PASS" and rc == 0)
    return dict(sim=sim, config=cfgname, test=test, seed=seed, ok=ok, secs=round(dt, 1),
                stats=st.group(0)[len("TB_TILE stats "):] if st else "", log=str(log.relative_to(C.ROOT)))


def run_config(cfgname, tests, seeds, sim, jobs, logdir):
    cfg = cfg_of(cfgname)
    exe = build(cfgname, cfg, sim)
    jobs_l = []
    for seed in seeds:
        tdir = C.BUILD / "tests" / f"{cfgname}_s{seed}"
        tl = [t for t in tests if t != "parity" or cfg["SPM_ECC"]]
        r = subprocess.run([sys.executable, str(C.ROOT / "scripts/gen_tests.py"), "--cfg", json.dumps(cfg),
                            "--out", str(tdir), "--tests", ",".join(tl), "--seed", str(seed)],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError(f"test generation failed for {cfgname}:\n{r.stdout}{r.stderr}")
        for t in tl:
            jobs_l.append((exe, sim, cfgname, t, seed, tdir / t, logdir))
    res = []
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        for r in ex.map(lambda a: run_one(*a), jobs_l):
            print(f"  {'PASS' if r['ok'] else 'FAIL'} {r['sim']:9s} {r['config']:12s} {r['test']:15s} seed {r['seed']} "
                  f"{r['secs']:7.1f}s  {r['stats'][:110]}", flush=True)
            res.append(r)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="baseline")
    ap.add_argument("--tests", default=",".join(FULL_TESTS))
    ap.add_argument("--seeds", default="1")
    ap.add_argument("--sim", default="verilator")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--stage", default="")
    ap.add_argument("--report", action="store_true")
    a = ap.parse_args()
    logdir = C.BUILD / "logs"
    logdir.mkdir(parents=True, exist_ok=True)
    seeds = [int(s) for s in a.seeds.split(",")]
    plan = []
    if a.stage in ("1", "all"):
        plan.append(("stage 1: two-lane vector path (queue + scratchpad + 2-lane array)", "s1_n2", STAGE1_TESTS, seeds))
    if a.stage in ("2", "all"):
        plan.append(("stage 2: full baseline tile, every test", "baseline", FULL_TESTS, seeds + [s + 100 for s in seeds]))
    if a.stage in ("3", "all"):
        for c in CONFIGS:
            if c not in ("s1_n2", "baseline"):
                plan.append((f"stage 3: configuration sweep ({c})", c, SWEEP_TESTS, seeds))
    if not plan:
        plan.append((f"{a.config}", a.config, a.tests.split(","), seeds))
    allres, stages = [], []
    t0 = time.time()
    for title, cfgname, tests, sd in plan:
        print(f"== {title}", flush=True)
        res = run_config(cfgname, tests, sd, a.sim, a.jobs, logdir)
        npass = sum(r["ok"] for r in res)
        stages.append(dict(title=title, config=cfgname, cfg=cfg_of(cfgname), passed=npass, total=len(res)))
        allres += res
        print(f"   {npass}/{len(res)} passed", flush=True)
        if npass != len(res) and a.stage:
            print("stage failed: stopping", flush=True)
            break
    tot = sum(r["ok"] for r in allres)
    print(f"TOTAL {tot}/{len(allres)} in {time.time() - t0:.0f} s")
    if a.report or a.stage == "all":
        out = C.REPORTS / ("regression" if a.sim == "verilator" else "regression_icarus")
        out.with_suffix(".json").write_text(json.dumps(dict(tools=C.tool_versions(), stages=stages, runs=allres), indent=1))
        lines = [f"# Integration regression ({a.sim})", "", f"Tools: {C.tool_versions()}", "",
                 "| stage | configuration | passed |", "|---|---|---|"]
        for s in stages:
            diff = {k: v for k, v in s["cfg"].items() if DEFAULT.get(k) != v}
            lines.append(f"| {s['title']} | `{s['config']}` {diff if diff else '(baseline)'} | **{s['passed']} / {s['total']}** |")
        lines += ["", f"**Total: {tot} / {len(allres)}**", "", "| config | test | seed | result | sim time | statistics |",
                  "|---|---|---|---|---|---|"]
        for r in allres:
            lines.append(f"| {r['config']} | {r['test']} | {r['seed']} | {'PASS' if r['ok'] else 'FAIL'} | {r['secs']} s | {r['stats']} |")
        out.with_suffix(".md").write_text("\n".join(lines) + "\n")
    sys.exit(0 if tot == len(allres) else 1)


if __name__ == "__main__":
    main()
