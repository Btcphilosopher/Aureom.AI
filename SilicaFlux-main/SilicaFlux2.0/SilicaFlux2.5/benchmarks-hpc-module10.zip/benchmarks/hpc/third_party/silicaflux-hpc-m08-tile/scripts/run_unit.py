#!/usr/bin/env python3
"""Unit tests of the two new building blocks, before the tile uses them:
  hpc_command_queue (Module 06): 6 depths x 3 widths, Verilator + Icarus, 3 seeds each
  hpc_perf_counters (Module 07): 2 parameter sets, Verilator + Icarus, 3 seeds each
Writes reports/unit.{md,json}; exit 1 on any failure."""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common as C  # noqa: E402
import files as F  # noqa: E402

INC = [C.ROOT / "rtl", F.SL]


def vl_build(top, src, params, name):
    d = C.BUILD / "unit" / name
    d.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "-Wall", "-Wno-fatal", "-Wno-DECLFILENAME", "-Wno-UNUSEDSIGNAL",
           "-Wno-TIMESCALEMOD", "--top-module", top, "-Mdir", str(d), "-o", "sim"] + \
          [f"-I{x}" for x in INC] + [f"-G{k}={v}" for k, v in params.items()] + [str(s) for s in src]
    r = subprocess.run(cmd, capture_output=True, text=True)
    own = [l for l in (r.stdout + r.stderr).splitlines() if l.startswith("%Warning") and "/rtl/" in l]
    return d / "sim", r.returncode == 0, own


def iv_build(top, src, params, name):
    d = C.BUILD / "unit" / name
    d.mkdir(parents=True, exist_ok=True)
    cmd = ["iverilog", "-g2012", "-o", str(d / "sim.vvp"), "-s", top] + [f"-I{x}" for x in INC] + \
          [f"-P{top}.{k}={v}" for k, v in params.items()] + [str(s) for s in src]
    r = subprocess.run(cmd, capture_output=True, text=True)
    return d / "sim.vvp", r.returncode == 0


def main():
    res = []
    jobs = [("tb_hpc_command_queue", [C.ROOT / "rtl/hpc_command_queue.sv", C.ROOT / "tb/tb_hpc_command_queue.sv"],
             dict(WIDTH=w, DEPTH=d), "TB_CQ") for d in (2, 4, 8, 16, 32, 64) for w in (1, 37, 272)]
    jobs += [("tb_hpc_perf_counters", [C.ROOT / "rtl/hpc_perf_counters.sv", C.ROOT / "tb/tb_hpc_perf_counters.sv"],
              p, "TB_PC") for p in (dict(NUM=5, CW=10, IW=4), dict(NUM=24, CW=8, IW=8))]
    for top, src, params, tag in jobs:
        name = top + "_" + "_".join(f"{k}{v}" for k, v in params.items())
        vexe, vok, own = vl_build(top, src, params, "vl_" + name)
        iexe, iok = iv_build(top, src, params, "iv_" + name)
        for seed in (1, 2, 3):
            for sim, exe, ok in (("verilator", vexe, vok), ("icarus", iexe, iok)):
                if not ok:
                    res.append(dict(top=top, params=params, sim=sim, seed=seed, ok=False, note="build failed"))
                    continue
                cmd = [str(exe), f"+seed={seed}"] if sim == "verilator" else ["vvp", "-n", str(exe), f"+seed={seed}"]
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
                ok2 = f"{tag} RESULT PASS" in r.stdout
                st = re.search(rf"{tag} (pushes|saturations)=.*", r.stdout)
                res.append(dict(top=top, params=params, sim=sim, seed=seed, ok=ok2, lint_warnings=len(own),
                                note=st.group(0) if st else ""))
    n = sum(r["ok"] for r in res)
    (C.REPORTS / "unit.json").write_text(json.dumps(res, indent=1))
    L = ["# Unit tests: hpc_command_queue (M06), hpc_perf_counters (M07)", "",
         f"**{n} / {len(res)} runs passed** (Verilator and Icarus, 3 seeds per parameter set).  Verilator -Wall "
         f"warnings in the RTL: {sum(r.get('lint_warnings', 0) for r in res)}.", "",
         "| unit | parameters | simulator | seed | result | coverage |", "|---|---|---|---|---|---|"]
    for r in res:
        L.append(f"| {r['top']} | {r['params']} | {r['sim']} | {r['seed']} | {'PASS' if r['ok'] else 'FAIL'} | {r['note']} |")
    (C.REPORTS / "unit.md").write_text("\n".join(L) + "\n")
    print(L[2])
    sys.exit(0 if n == len(res) else 1)


if __name__ == "__main__":
    main()
