#!/usr/bin/env python3
"""Generate integration-test programs for tb_silicaflux_hpc_tile from the reference model.

Every expected value (completion records, final memory, deterministic counters) comes from
model/tile_model.py + model/fp32_model.py -- an implementation independent of the RTL.

Usage: gen_tests.py --cfg '<json>' --out DIR [--tests a,b,...] [--seed N]
Each test directory gets prog.txt (program), init.hex (initial memory: external words loaded by backdoor,
scratchpad words written through the host scratchpad port) and final.hex (expected final words).

Determinism rule used throughout (docs/04_memory_and_ordering.md sec. 5): a command that can FAIL AT RUN
TIME (DMA bus error, scratchpad parity error) is followed by a DRAIN before any further submission, so the
point at which HALT_ON_ERROR stops dispatching is the same in the model and in the hardware.  Commands
rejected by the scheduler's validation stop younger commands deterministically (no DRAIN needed).
"""
from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "model"))
import fp32_model as F  # noqa: E402
import tile_defs as D  # noqa: E402
from tile_model import Cfg, Region, TileModel, Record, Perf, dma, vec, kernel, nop, w0  # noqa: E402

EXT0, EXT0_BYTES = 0x1000_0000, 262144
EXT1, EXT1_BYTES = 0x1800_0000, 16384
UNMAPPED = 0x3000_0000
NO_ERR = 0xFFFF_FFFF

SPECIALS = [0x00000000, 0x80000000, 0x00000001, 0x807FFFFF, 0x00800000, 0x7F7FFFFF, 0xFF7FFFFF, 0x7F800000,
            0xFF800000, 0x7FC00000, 0x7F800001, 0xFFA00000, 0x3F800000, 0xBF800000, 0x34000000, 0x0C000000]
ELEM_OPS = [F.OP_FMV, F.OP_FADD, F.OP_FSUB, F.OP_FMUL, F.OP_FMADD, F.OP_FMSUB, F.OP_FNMSUB, F.OP_FNMADD,
            F.OP_FMIN, F.OP_FMAX, F.OP_FEQ, F.OP_FLT, F.OP_FLE, F.OP_IADD, F.OP_IMUL]


def fpv(rng, special=0.0, wide=False):
    if rng.random() < special:
        return rng.choice(SPECIALS)
    if wide and rng.random() < 0.2:
        return rng.getrandbits(32)
    e = rng.randint(112, 142) if not wide else rng.randint(1, 254)
    return (rng.getrandbits(1) << 31) | (e << 23) | rng.getrandbits(23)


class Prog:
    def __init__(self, cfg: Cfg, name: str, seed: int):
        self.cfg, self.name = cfg, name
        self.rng = random.Random(seed)
        self.m = TileModel(cfg, [Region("EXT0", EXT0, EXT0_BYTES), Region("EXT1", EXT1, EXT1_BYTES)])
        for base, size in ((EXT0, EXT0_BYTES), (EXT1, EXT1_BYTES)):      # external memories start at 0 (TB does this)
            for a in range(base, base + size):
                self.m.mem.mem[a] = 0
        self.lines: list[str] = []
        self.init: dict[int, int] = {}
        self.checks: list[tuple[int, int]] = []
        self.pending: list[list[int]] = []
        self.nexp = 0
        self.ecc = False

    # ---------------------------------------------------------- memory
    @property
    def spm(self):
        return self.cfg.spm_base

    def put(self, addr, words):
        """Initial memory (init.hex): external words by backdoor, scratchpad words via the host port."""
        for i, wv in enumerate(words):
            a = addr + 4 * i
            # the initial image is loaded once before the program runs: it must not overlap an earlier
            # initialisation or anything a command of this program already wrote
            assert a not in self.init, f"{self.name}: address {a:#x} initialised twice"
            assert a not in self.m.mem.cmd_written, f"{self.name}: initial word {a:#x} already written by a command"
            self.init[a] = wv & 0xFFFFFFFF
            self.m.mem.wr32(a, wv, by_cmd=False)

    def host_wr(self, addr, wv):
        self.lines.append(f"HWR {addr:08x} {wv:08x}")
        self.m.mem.wr32(addr, wv)

    def check(self, addr, nbytes):
        self.checks.append((addr, nbytes))

    def forget(self, addr, nbytes):
        """Bytes whose final value is timing dependent (reset / partial-error tests): never compared."""
        for a in range(addr, addr + nbytes):
            self.m.mem.mem.pop(a, None)

    def rand_vec(self, n, special=0.0, wide=False):
        return [fpv(self.rng, special, wide) for _ in range(n)]

    # ---------------------------------------------------------- commands
    def _exp(self, rec: Record):
        f = ["X" if v is None else f"{v:x}" for v in rec.fields()]
        self.lines.append("EXP " + " ".join(f))
        self.nexp += 1

    def sub(self, w):
        self.lines.append("SUB " + " ".join(f"{x & 0xFFFFFFFF:08x}" for x in w))
        if self.m.halted:
            self.pending.append(w)
            # the model consumes the SEQ number now (assigned at submission)
            self.pending[-1] = (w, self.m.seq)
            self.m.seq += 1
            self.m.perf.submitted += 1
            return None
        rec = self.m.execute(w)
        self._exp(rec)
        return rec

    def subx(self, w):
        """Submission expected to be REFUSED (queue full): no SEQ consumed."""
        self.lines.append("SUBX " + " ".join(f"{x & 0xFFFFFFFF:08x}" for x in w))

    def _run_pending(self, cancel=False):
        rest = []
        for w, sq in self.pending:
            if cancel:
                rec = Record(tag=(w[0] >> 16) & 0xFF, status=D.ST_CANCELLED, typ=w[0] & 0xF, seq=sq & 0xFFFF)
                self.m.perf.completed += 1
                self.m.perf.cancelled += 1
                self._exp(rec)
            elif self.m.halted:
                rest.append((w, sq))
            else:
                save = self.m.seq
                self.m.seq = sq
                self.m.perf.submitted -= 1                 # already counted at submission
                rec = self.m.execute(w)
                self.m.seq = save
                self._exp(rec)
        self.pending = rest

    def resume(self):
        self.lines.append("RESUME")
        self.m.halted = False
        self._run_pending()

    def flush(self):
        self.lines.append("FLUSH")
        self._run_pending(cancel=True)
        self.m.halted = False

    def cfg_reg(self, halt=1, freeze=0):
        self.lines.append(f"CFG {(freeze << 1) | halt:x}")
        self.m.halt_on_error = bool(halt)

    def drain(self):
        self.lines.append("DRAIN")

    def op(self, s):
        self.lines.append(s)

    def lose(self, w):
        """A command submitted and then destroyed by a soft reset: SEQ consumed, no completion, outputs unknown."""
        self.lines.append("SUB " + " ".join(f"{x & 0xFFFFFFFF:08x}" for x in w))
        self.m.seq += 1
        self.m.perf.submitted += 1
        typ, vl = w[0] & 0xF, w[1]
        red = (w[0] >> 15) & 1
        if typ == D.CT_DMA:
            self.forget(w[4], vl)
        elif typ == D.CT_VEC:
            self.forget(w[6], 4 if red else 4 * vl)
        elif typ == D.CT_KERNEL:
            st = -(-4 * vl // self.cfg.sb) * self.cfg.sb
            self.forget(w[7], 4 * st)
            self.forget(w[6], 4 if red else 4 * vl)

    def perf_expect(self):
        p = self.m.perf
        pairs = [(D.PC_SUBMITTED, p.submitted), (D.PC_COMPLETED, p.completed), (D.PC_ERRORS, p.errors),
                 (D.PC_CANCELLED, p.cancelled), (D.PC_DMA_BYTES_RD, p.dma_bytes_rd),
                 (D.PC_DMA_BYTES_WR, p.dma_bytes_wr), (D.PC_VEC_ELEMS, p.vec_elems), (D.PC_VEC_FLOPS, p.vec_flops),
                 (D.PC_LSU_LOADS, p.lsu_loads), (D.PC_LSU_STORES, p.lsu_stores), (D.PC_DMA_CMDS, p.dma_cmds),
                 (D.PC_VEC_CMDS, p.vec_cmds), (D.PC_KERNEL_CMDS, p.kernel_cmds)]
        for idx, v in pairs:
            self.lines.append(f"PERF {idx:x} {'X' if v is None else f'{v:x}'}")

    # ---------------------------------------------------------- output
    def write(self, d: Path):
        d.mkdir(parents=True, exist_ok=True)
        if self.ecc:
            # byte-parity scratchpad: software initialises the whole scratchpad before use (Module 04 doc 01
            # sec. 7: never-written words read back as parity errors); remaining words are zero-filled
            for a in range(self.cfg.spm_base, self.cfg.spm_base + self.cfg.spm_bytes, 4):
                self.init.setdefault(a, 0)
        (d / "prog.txt").write_text(f"# test {self.name}\n" + "\n".join(self.lines) + "\nEND\n")
        (d / "init.hex").write_text("".join(f"{a:08x} {v:08x}\n" for a, v in sorted(self.init.items())))
        fin = []
        for a0, n in self.checks:
            for a in range(a0 & ~3, a0 + n, 4):
                if self.m.mem.defined(a, 4):
                    fin.append((a, self.m.mem.rd32(a)))
        (d / "final.hex").write_text("".join(f"{a:08x} {v:08x}\n" for a, v in sorted(set(fin))))
        return {"name": self.name, "commands": self.nexp, "final_words": len(fin), "init_words": len(self.init)}


# ====================================================================== recipes
def spm_layout(cfg, nreg):
    """nreg equal scratchpad buffers (word aligned to DW), returns (bases, bytes_each)."""
    each = (cfg.spm_bytes // nreg) // cfg.sb * cfg.sb
    return [cfg.spm_base + k * each for k in range(nreg)], each


def t_s1_vec_basic(p: Prog):
    """Stage 1: scratchpad-resident FADD / FMUL / FMADD (host writes operands through the host port)."""
    (a, b, c, d1, d2, d3, _, _), each = spm_layout(p.cfg, 8)
    vl = min(64, each // 4)
    p.put(a, p.rand_vec(vl)); p.put(b, p.rand_vec(vl)); p.put(c, p.rand_vec(vl))
    p.sub(vec(F.OP_FADD, vl, a, b, 0, d1, tag=1))
    p.sub(vec(F.OP_FMUL, vl, a, b, 0, d2, tag=2))
    p.sub(vec(F.OP_FMADD, vl, a, b, c, d3, tag=3))
    p.drain()
    for x in (d1, d2, d3):
        p.check(x, 4 * vl)


def t_s1_vec_random(p: Prog, n=40):
    """Every element operation, rounding mode, broadcast form, tails, in-place, special values."""
    bufs, each = spm_layout(p.cfg, 8)
    maxvl = min(each // 4, 300)
    for x in bufs:
        p.put(x, p.rand_vec(each // 4, special=0.15, wide=True))
    for i in range(n):
        op = p.rng.choice(ELEM_OPS)
        rm = p.rng.randint(0, 4)
        vl = p.rng.choice([1, 2, 3, p.cfg.n_lanes, p.cfg.n_lanes + 1, p.rng.randint(1, maxvl)])
        srcs = p.rng.sample(bufs, 4)
        bc = p.rng.choice([0, 0, 0, 1, 2, 4, 3, 6])
        d = srcs[3]
        if p.rng.random() < 0.2:
            d = srcs[0]                                  # exact in place
        p.sub(vec(op, vl, srcs[0], srcs[1], srcs[2], d, rm=rm, bc=bc, sc=fpv(p.rng, 0.2), tag=i & 0xFF))
        if p.rng.random() < 0.3:
            p.drain()
    p.drain()
    for x in bufs:
        p.check(x, each)


def t_s1_vec_reduce(p: Prog, n=16):
    """Sum and dot-product reductions (Module 03 defined order), all rounding modes."""
    bufs, each = spm_layout(p.cfg, 8)
    for x in bufs[:4]:
        p.put(x, p.rand_vec(each // 4, special=0.02))
    for i in range(n):
        op = p.rng.choice([F.OP_FMV, F.OP_FMUL, F.OP_FADD, F.OP_FMADD, F.OP_FSUB])
        vl = p.rng.choice([1, 2, p.cfg.n_lanes + 3, p.rng.randint(1, min(each // 4, 1000))])
        d = bufs[4] + i * p.cfg.sb
        p.sub(vec(op, vl, bufs[0], bufs[1], bufs[2], d, rm=p.rng.randint(0, 4), red=1, sc=fpv(p.rng), tag=0x40 + i))
    p.drain()
    p.check(bufs[4], n * p.cfg.sb)


def t_s1_vec_long(p: Prog):
    """One long vector command per mandatory operation: vl = as large as the scratchpad allows."""
    bufs, each = spm_layout(p.cfg, 4)
    vl = each // 4
    p.put(bufs[0], p.rand_vec(vl)); p.put(bufs[1], p.rand_vec(vl)); p.put(bufs[2], p.rand_vec(vl))
    p.sub(vec(F.OP_FMADD, vl, bufs[0], bufs[1], bufs[2], bufs[3], tag=0x11))
    p.drain()
    p.check(bufs[3], 4 * vl)
    p.sub(vec(F.OP_FADD, vl, bufs[0], bufs[1], 0, bufs[0], tag=0x12))        # in place
    p.sub(vec(F.OP_FMUL, vl, bufs[0], bufs[2], 0, bufs[1], tag=0x13))
    p.drain()
    p.check(bufs[0], 4 * vl); p.check(bufs[1], 4 * vl)


def _kernel_test(p: Prog, ops, n, maxvl=1500, special=0.0, ext0=EXT0):
    """Memory -> compute -> memory: host vectors in EXT0, KERNEL commands, results back in EXT0."""
    cfg = p.cfg
    stage = cfg.spm_base
    cap = cfg.spm_bytes // 4 // 4                       # elements per staging region
    maxvl = min(maxvl, cap - cfg.sb)
    ext = ext0
    for i in range(n):
        op = ops[i % len(ops)]
        vl = p.rng.choice([1, cfg.n_lanes - 1 or 1, cfg.n_lanes + 1, p.rng.randint(1, maxvl)])
        nb = -(-4 * vl // cfg.sb) * cfg.sb
        assert ext + 4 * nb <= EXT0 + EXT0_BYTES, "kernel test exceeds the external memory"
        a, b, c, d = ext, ext + nb, ext + 2 * nb, ext + 3 * nb
        ext += 4 * nb
        p.put(a, p.rand_vec(vl, special)); p.put(b, p.rand_vec(vl, special)); p.put(c, p.rand_vec(vl, special))
        p.sub(kernel(op, vl, a, b, c, d, stage, rm=p.rng.randint(0, 4) if i % 3 else 0, tag=i & 0xFF))
        p.check(d, 4 * vl)
    p.drain()


def t_vec_add(p): _kernel_test(p, [F.OP_FADD], 6)
def t_vec_mul(p): _kernel_test(p, [F.OP_FMUL], 6)
def t_vec_fma(p): _kernel_test(p, [F.OP_FMADD, F.OP_FMSUB, F.OP_FNMADD, F.OP_FNMSUB], 8)


def t_kernels_many(p: Prog):
    """Many consecutive kernels (random operation, length, rounding, broadcast, reductions)."""
    cfg = p.cfg
    stage = cfg.spm_base
    cap = cfg.spm_bytes // 16
    ext = EXT0
    for i in range(40):
        op = p.rng.choice(ELEM_OPS)
        red = 1 if (op <= 7 and p.rng.random() < 0.2) else 0
        bc = 0 if red else p.rng.choice([0, 0, 1, 2, 4])
        vl = p.rng.randint(1, min(400, cap - cfg.sb))
        nb = -(-4 * vl // cfg.sb) * cfg.sb
        assert ext + 4 * nb <= EXT0 + EXT0_BYTES, "kernels_many exceeds the external memory"
        a, b, c, d = ext, ext + nb, ext + 2 * nb, ext + 3 * nb
        ext += 4 * nb
        for x in (a, b, c):
            p.put(x, p.rand_vec(vl, 0.05))
        p.sub(kernel(op, vl, a, b, c, d, stage, rm=p.rng.randint(0, 4), bc=bc, red=red, sc=fpv(p.rng),
                     tag=i, fence=int(p.rng.random() < 0.2)))
        p.check(d, nb)          # the whole destination region: nothing beyond the result may be written
    p.drain()


def t_dma(p: Prog):
    """DMA load / store: ext->SPM, SPM->ext, SPM->SPM, ext->ext; 1-byte, tails, both external slaves."""
    cfg = p.cfg
    bufs, each = spm_layout(cfg, 4)
    src0 = EXT0 + 0x8000
    p.put(src0, [p.rng.getrandbits(32) for _ in range(2048)])
    p.put(EXT1, [p.rng.getrandbits(32) for _ in range(512)])
    lens = [1, 2, 3, 4, 5, cfg.sb - 1 or 1, cfg.sb, cfg.sb + 1, 31, 64, 255, 1000, 4096]
    for i, ln in enumerate(lens):
        ln = min(ln, each)
        p.sub(dma(src0 + 16 * cfg.sb * i, bufs[0] + 0, ln, tag=i))          # ext -> SPM
        p.sub(dma(bufs[0], EXT0 + 0x20000 + 0x1000 * i, ln, tag=0x20 + i))  # SPM -> ext
        p.check(EXT0 + 0x20000 + 0x1000 * i, ln + 8)
    p.sub(dma(EXT1 + 64, bufs[1], 1500, tag=0x40))                       # fault slave (no faults) -> SPM
    p.sub(dma(bufs[1], bufs[2], 1500, tag=0x41))                        # SPM -> SPM
    p.sub(dma(bufs[2], EXT1 + 0x2000, 1500, tag=0x42))                  # SPM -> fault slave
    p.sub(dma(EXT0 + 0x8000, EXT0 + 0x30000, 777, tag=0x43))            # ext -> ext
    p.drain()
    p.check(EXT1 + 0x2000, 1504); p.check(EXT0 + 0x30000, 780); p.check(bufs[2], 1500)


def t_ordering(p: Prog, n=60):
    """Random DMA / VEC / NOP / FENCE sequences over a few shared buffers: RAW, WAR and WAW hazards between
    the DMA and vector units, and independent pairs that may overlap.  Completion order and final memory
    must equal sequential execution."""
    cfg = p.cfg
    bufs, each = spm_layout(cfg, 8)
    blen = min(each, 2048)
    for x in bufs:
        p.put(x, p.rand_vec(blen // 4))
    exts = [EXT0 + 0x1000 * k for k in range(16)]
    for x in exts:
        p.put(x, p.rand_vec(blen // 4))
    for i in range(n):
        k = p.rng.random()
        fence = int(p.rng.random() < 0.1)
        if k < 0.35:
            ln = p.rng.choice([4, 64, 4 * p.rng.randint(1, blen // 4), p.rng.randint(1, blen)]) // cfg.sb * cfg.sb or cfg.sb
            if p.rng.random() < 0.5:
                p.sub(dma(p.rng.choice(exts), p.rng.choice(bufs), ln, tag=i, fence=fence))
            else:
                p.sub(dma(p.rng.choice(bufs), p.rng.choice(exts), ln, tag=i, fence=fence))
        elif k < 0.85:
            op = p.rng.choice([F.OP_FADD, F.OP_FMUL, F.OP_FMADD, F.OP_FSUB, F.OP_FMV])
            vl = p.rng.randint(1, blen // 4)
            s = p.rng.sample(bufs, 4)
            d = s[0] if p.rng.random() < 0.2 else s[3]
            p.sub(vec(op, vl, s[0], s[1], s[2], d, tag=i, fence=fence))
        else:
            p.sub(nop(tag=i, fence=fence))
        if p.rng.random() < 0.1:
            p.drain()
    p.drain()
    for x in bufs:
        p.check(x, blen)
    for x in exts:
        p.check(x, blen)


def t_contention(p: Prog):
    """DMA, vector unit and host traffic on the scratchpad at the same time (disjoint regions): bank
    conflicts are arbitrated, results stay exact."""
    cfg = p.cfg
    bufs, each = spm_layout(cfg, 8)
    vl = min(each // 4, 2048)
    for x in bufs[:3]:
        p.put(x, p.rand_vec(vl))
    p.put(EXT0, p.rand_vec(vl))
    p.put(EXT0 + 0x20000, p.rand_vec(vl))
    p.op("PERFCLR"); p.m.perf = Perf()
    p.sub(vec(F.OP_FMADD, vl, bufs[0], bufs[1], bufs[2], bufs[3], tag=1))
    p.sub(dma(EXT0, bufs[4], 4 * vl, tag=2))                             # independent of the VEC -> overlaps
    p.sub(vec(F.OP_FADD, vl, bufs[0], bufs[1], 0, bufs[5], tag=3))
    p.sub(dma(bufs[4], EXT0 + 0x10000, 4 * vl, tag=4))                   # RAW on bufs[4]
    for i in range(64):                                                  # host traffic during execution
        p.host_wr(bufs[6] + 4 * i, p.rng.getrandbits(32))
    p.drain()
    p.op(f"PERFMIN {D.PC_SPM_CONFLICTS:x} 1")
    p.op(f"PERFMIN {D.PC_OVERLAP:x} 1")             # the independent DMA really overlapped the vector command
    # FENCE: the same independent pair, but the DMA is fenced -> it may only start after the vector command
    # retired, so the DMA engine and the vector unit are never active in the same cycle (exactly 0)
    p.op("PERFCLR")
    p.sub(vec(F.OP_FMADD, vl, bufs[0], bufs[1], bufs[2], bufs[7], tag=5))
    p.sub(dma(EXT0 + 0x20000, bufs[4], 4 * vl, tag=6, fence=1))
    p.drain()
    p.op(f"PERF {D.PC_OVERLAP:x} 0")
    p.check(bufs[7], 4 * vl)
    for x in bufs[3:7]:
        p.check(x, 4 * vl if x != bufs[6] else 256)
    p.check(EXT0 + 0x10000, 4 * vl)


def t_perf(p: Prog):
    """Counter correctness: deterministic counters against the model, timing counters against the
    testbench's port monitors, with freeze and clear."""
    cfg = p.cfg
    p.op("PERFCLR"); p.m.perf = Perf()
    t_ordering(p, n=25)
    _kernel_test(p, [F.OP_FMADD, F.OP_FMUL], 3, maxvl=300, ext0=EXT0 + 0x20000)
    # a length that is not a multiple of the word: whole words are read, only LEN bytes are written
    p.sub(dma(EXT0 + 0x20000, EXT0 + 0x38000, 1001, tag=0x70))
    p.check(EXT0 + 0x38000, 1008)
    p.sub([w0(9, tag=0x77)] + [0] * 7)                                                # BAD_TYPE: 1 error
    p.drain()
    p.op("WAITHALT")
    p.resume()
    p.cfg_reg(halt=1, freeze=1)
    p.op("DELAY 40")
    p.op("PERFMON")
    p.perf_expect()
    p.cfg_reg(halt=1, freeze=0)
    p.op("PERFCLR"); p.m.perf = Perf()
    p.op("DELAY 5")
    p.cfg_reg(halt=1, freeze=1)
    p.op("PERFMON")
    p.perf_expect()
    p.cfg_reg(halt=1, freeze=0)


def t_reset(p: Prog):
    """Soft reset and hard reset in the middle of execution; the tile recovers and computes exactly."""
    cfg = p.cfg
    stage = cfg.spm_base
    cap = cfg.spm_bytes // 16
    vl = min(1200, cap - cfg.sb)
    nb = -(-4 * vl // cfg.sb) * cfg.sb
    for k in range(3):
        a = EXT0 + 4 * nb * k
        p.put(a, p.rand_vec(vl)); p.put(a + nb, p.rand_vec(vl)); p.put(a + 2 * nb, p.rand_vec(vl))
    for rnd in range(6):
        a = EXT0 + 4 * nb * (rnd % 2)
        p.lose(kernel(F.OP_FMADD, vl, a, a + nb, a + 2 * nb, a + 3 * nb, stage, tag=0xA0 + rnd))
        p.lose(dma(a, stage + 0x100 * cfg.sb, 4 * vl // 2, tag=0xB0 + rnd))
        p.op(f"DELAY {p.rng.randint(5, 6000):x}")
        if rnd % 3 != 2:                                 # rounds 0, 1, 3, 4: soft reset; 2, 5: hard reset
            p.op("SRST")
        else:
            p.op("HRST 7")
            p.m.seq = 0
            p.m.perf = Perf()
            p.m.halt_on_error = True
        p.op("CHKIDLE")
        # recovery workload with known results
        a2 = EXT0 + 4 * nb * 2
        p.sub(kernel(F.OP_FMADD, vl, a2, a2 + nb, a2 + 2 * nb, a2 + 3 * nb, stage, tag=0xC0 + rnd))
        p.drain()
        p.check(a2 + 3 * nb, 4 * vl)


def t_invalid(p: Prog):
    """Every validation rule, DMA validation / region / bus errors, halt + resume + flush, submission
    overflow, register-map errors.  Destinations of failed commands must be untouched."""
    cfg = p.cfg
    sb = cfg.sb
    bufs, each = spm_layout(cfg, 8)
    vl = 64
    for x in bufs[:4]:
        p.put(x, p.rand_vec(each // 4))
    p.put(EXT0, p.rand_vec(1024))
    p.put(EXT1, p.rand_vec(1024))
    # -- register map
    p.op(f"REGRD {D.REG_ID:x} {D.TILE_ID:x}")
    p.op(f"REGRD {D.REG_VERSION:x} {D.TILE_VERSION:x}")
    p.op(f"REGWR {D.REG_ID:x} 0 E")
    p.op("REGRD 7fc E")
    p.op("REGWR 7fc 0 E")
    p.op(f"REGRD {D.REG_SPM_BASE:x} {cfg.spm_base:x}")
    p.op(f"REGRD {D.REG_VL_MAX:x} {cfg.vl_max:x}")
    # -- halt disabled: every command reports its own status
    p.cfg_reg(halt=0)
    good = lambda t: vec(F.OP_FADD, vl, bufs[0], bufs[1], 0, bufs[4], tag=t)
    bad = [
        [w0(0xF, tag=1)] + [0] * 7,                                                   # BAD_TYPE
        [w0(D.CT_VEC, F.OP_FADD, tag=2, rsvd=1), vl, 0, bufs[0], bufs[1], 0, bufs[5], 0],   # BAD_RSVD
        vec(0x1F, vl, bufs[0], bufs[1], 0, bufs[5], tag=3),                           # BAD_OP (reserved opcode)
        vec(F.OP_FADD, vl, bufs[0], bufs[1], 0, bufs[5], rm=5, tag=4),                # BAD_OP (rm 5)
        vec(F.OP_FEQ, vl, bufs[0], bufs[1], 0, bufs[5], red=1, tag=5),                # BAD_OP (reduce FEQ)
        vec(F.OP_FADD, vl, bufs[0], bufs[1], 0, bufs[5], red=1, bc=1, tag=6),         # BAD_OP (reduce + bcast)
        vec(F.OP_FADD, 0, bufs[0], bufs[1], 0, bufs[5], tag=7),                       # BAD_VL (0)
        vec(F.OP_FADD, cfg.vl_max + 1, bufs[0], bufs[1], 0, bufs[5], tag=8),          # BAD_VL (> max)
        vec(F.OP_FADD, vl, bufs[0] + (4 if sb > 4 else 2), bufs[1], 0, bufs[5], tag=9),   # ALIGN
        vec(F.OP_FADD, vl, EXT0, bufs[1], 0, bufs[5], tag=10),                        # SPM_RANGE (source outside)
        vec(F.OP_FADD, vl, bufs[0], bufs[1], 0, cfg.spm_base + cfg.spm_bytes - 8 * sb, tag=11),  # SPM_RANGE (end)
        vec(F.OP_FADD, vl, bufs[0], bufs[1], 0, bufs[0] + 4 * sb, tag=12),            # OVERLAP (partial)
        kernel(F.OP_FADD, vl, EXT0, EXT0 + 0x400, 0, EXT0 + 0x800, cfg.spm_base + cfg.spm_bytes - 64, tag=13),  # SPM_RANGE (stage)
        kernel(F.OP_FADD, vl, EXT0 + 2, EXT0 + 0x400, 0, EXT0 + 0x800, cfg.spm_base, tag=14),     # ALIGN (ext)
        dma(EXT0, bufs[6], 0, tag=15),                                                # DMA ZERO_LENGTH
        dma(EXT0, bufs[6], (1 << 24) + 4, tag=16),                                    # DMA LENGTH
        dma(EXT0 + 2, bufs[6], 8, tag=17),                                            # DMA SRC_ALIGN
        dma(EXT0, bufs[6] + 2, 8, tag=18),                                            # DMA DST_ALIGN
        dma(0xFFFF_FFF0 // sb * sb, bufs[6], 0x100, tag=19),                          # DMA SRC_OVERFLOW
        dma(bufs[6], bufs[6] + 16, 64, tag=20),                                       # DMA OVERLAP
        dma(EXT0, cfg.spm_base + cfg.spm_bytes - 16, 64, tag=21),                     # DMA REGION (crosses the window end)
        dma(UNMAPPED, bufs[6], 64, tag=22),                                           # DMA READ_BUS (decode error)
        dma(bufs[0], UNMAPPED + 0x100, 64, tag=23),                                   # DMA WRITE_BUS (decode error)
    ]
    for i, wv in enumerate(bad):
        p.sub(wv)
        p.sub(good(0x80 + i))                       # a valid command after every failure still executes
    p.drain()
    # fault slave error window: read error in the middle of a transfer, write error, kernel step errors
    p.op(f"FAULT {EXT1 + 0x200:08x} {EXT1 + 0x204:08x}")
    p.m.mem.regions[1].err_lo, p.m.mem.regions[1].err_hi = EXT1 + 0x200, EXT1 + 0x204
    p.sub(dma(EXT1, bufs[6], 0x400, tag=0x30)); p.drain()                         # READ_BUS at 0x200
    p.forget(bufs[6], 0x400)                                                       # partially written (buffered engine)
    p.sub(dma(bufs[0], EXT1 + 0x100, 0x200, tag=0x31)); p.drain()                 # WRITE_BUS at 0x200
    p.forget(EXT1 + 0x100, 0x200)
    kst = bufs[7]                                                                 # kernel staging (own buffer)
    p.sub(kernel(F.OP_FADD, vl, EXT0, EXT1 + 0x1F0, 0, EXT0 + 0x2000, kst, tag=0x32)); p.drain()  # LOAD_B fails
    p.forget(kst, 4 * (-(-4 * vl // sb) * sb))
    p.sub(kernel(F.OP_FMUL, vl, EXT0, EXT0 + 0x400, 0, EXT1 + 0x1C0, kst, tag=0x33)); p.drain()   # STORE_D fails
    p.forget(EXT1 + 0x1C0, 4 * vl)
    p.forget(kst, 4 * 4 * (-(-4 * vl // sb) * sb))
    p.op(f"FAULT {NO_ERR:08x} {NO_ERR:08x}")
    p.m.mem.regions[1].err_lo = p.m.mem.regions[1].err_hi = 0
    # -- halt enabled: the first error halts; queued commands wait; RESUME / FLUSH
    p.cfg_reg(halt=1)
    p.op("IRQCHK 0")
    p.op("REGWR 30 7 OK")                           # IRQ_EN = CPL | ERR | HALT
    p.sub(vec(0x1F, vl, bufs[0], bufs[1], 0, bufs[5], tag=0x50))                  # BAD_OP -> halt
    p.sub(good(0x51)); p.sub(good(0x52))
    p.op("WAITHALT")
    p.op("IRQCHK 1")
    p.drain()                                        # only the failing record arrives
    p.op(f"CHKSTAT 82 82")                           # HALTED, ERR sticky
    p.resume()
    p.drain()
    p.op("REGWR 34 7 OK")                           # clear IRQ status
    p.op("REGWR 28 c0 OK")                          # clear sticky STATUS bits
    p.op("IRQCHK 0")
    # flush: halt again, queue fills, overflow, flush cancels everything queued
    p.sub(dma(EXT0, bufs[6], 0, tag=0x60)); p.drain()                             # DMA ZERO_LENGTH -> halt
    p.op("WAITHALT")
    q = cfg_qdepth(p)
    for i in range(q + 1):                            # queue + DCR
        p.sub(good(0x61 + i))
    p.subx(good(0x7F))                                # refused: SUBMIT_OVF
    p.op("CHKSTAT 52 52")                             # HALTED, CMDQ_FULL, SUBMIT_OVF
    p.flush()
    p.drain()
    p.op("REGWR 28 c0 OK")
    p.sub(good(0x7E))
    p.drain()
    p.op("REGWR 34 7 OK")
    p.op("REGWR 30 0 OK")
    for x in bufs:
        p.check(x, each)
    p.check(EXT0, 0x3000)
    p.check(EXT1, 0x800)


def cfg_qdepth(p):
    return p.qdepth


def t_backpressure(p: Prog):
    """Fabric back-pressure (slow, stalling slave), host response back-pressure, completion queue full,
    command queue full with DOORBELL retries."""
    cfg = p.cfg
    stage = cfg.spm_base
    bufs, each = spm_layout(cfg, 8)
    vl = 200
    nb = -(-4 * vl // cfg.sb) * cfg.sb
    for k in range(4):
        a = EXT1 + 4 * nb * k
        p.put(a, p.rand_vec(vl)); p.put(a + nb, p.rand_vec(vl)); p.put(a + 2 * nb, p.rand_vec(vl))
    p.put(bufs[4], p.rand_vec(64)); p.put(bufs[5], p.rand_vec(64))
    nk = p.qdepth + 6
    for i in range(nk):
        a = EXT0 + 0x800 * i
        p.put(a, p.rand_vec(128)); p.put(a + 0x200, p.rand_vec(128))
    p.op("FSLAVE 46 9")                               # 70 % request stalls, latency 1..9
    p.op("HOSTBP 32")                                 # host delays 50 % of its responses
    for k in range(4):
        a = EXT1 + 4 * nb * k
        p.sub(kernel(F.OP_FMADD, vl, a, a + nb, a + 2 * nb, a + 3 * nb, stage, tag=k))
        p.check(a + 3 * nb, 4 * vl)
    p.drain()
    # completion queue full: many quick commands, no popping for a while
    k = p.cplq + 3
    for i in range(k):
        p.sub(vec(F.OP_FADD, 16, bufs[4], bufs[5], 0, bufs[6] + 64 * i, tag=0x40 + i))
        p.check(bufs[6] + 64 * i, 64)
    p.op("DELAY 800")
    p.op(f"PERFMIN {D.PC_CPLQ_STALL:x} 1")
    p.drain()
    # command queue full with long kernels: DOORBELL refused and retried by the host
    p.op("FSLAVE 0 1")
    for i in range(nk):
        a = EXT0 + 0x800 * i
        p.sub(kernel(F.OP_FMUL, 128, a, a + 0x200, 0, a + 0x400, stage, tag=0x60 + i))
        p.check(a + 0x400, 512)
    p.drain()
    p.op("HOSTBP 0")


def t_parity(p: Prog):
    """(SPM_ECC = 1 only) a scratchpad parity error during vector execution is reported as SPM_ERR
    (code PARITY, failing word address) on the command that read it; DMA reads report READ_BUS."""
    cfg = p.cfg
    bufs, each = spm_layout(cfg, 8)
    vl = 100
    for x in bufs[:3]:
        p.put(x, p.rand_vec(vl))
    old_d = p.rand_vec(vl)
    p.put(bufs[4], old_d)                                   # destination pre-initialised
    bad_e = 37
    bad = bufs[1] + 4 * bad_e
    p.op(f"INJ {bad:08x} 3")
    rec = p.sub(vec(F.OP_FADD, vl, bufs[0], bufs[1], 0, bufs[4], tag=1))
    # replace the model's record: SPM_ERR, detail PARITY (4), err_addr = word address of the failing load
    p.lines.pop()
    p.nexp -= 1
    p._exp(Record(tag=1, status=D.ST_SPM_ERR, typ=D.CT_VEC, detail=4, flags=None, step=0, seq=rec.seq,
                  count=None, result=None, eaddr=bad & ~(cfg.sb - 1)))
    p.m.perf.errors += 1
    p.m.halted = True
    # No store is issued after the error is recorded.  The beat containing the failing element can only be
    # computed after that load returned, so from that beat on the destination keeps its old contents
    # (deterministic); earlier beats may or may not have been stored (timing dependent -> not compared).
    first_kept = (bad_e // cfg.n_lanes) * cfg.n_lanes
    p.forget(bufs[4], 4 * first_kept)
    for e in range(first_kept, vl):
        p.m.mem.wr32(bufs[4] + 4 * e, old_d[e], by_cmd=False)
    p.check(bufs[4], 4 * vl)
    p.drain()
    p.op("WAITHALT")
    p.resume()
    p.sub(vec(F.OP_FMUL, vl, bufs[0], bufs[2], 0, bufs[5], tag=2))                # unaffected command
    p.drain()
    p.check(bufs[5], 4 * vl)


TESTS = {
    # stage 1: command queue + scratchpad + vector engine (no DMA)
    "s1_vec_basic": t_s1_vec_basic, "s1_vec_random": t_s1_vec_random, "s1_vec_reduce": t_s1_vec_reduce,
    "s1_vec_long": t_s1_vec_long,
    # full tile
    "vec_add": t_vec_add, "vec_mul": t_vec_mul, "vec_fma": t_vec_fma, "dma": t_dma, "ordering": t_ordering,
    "contention": t_contention, "perf": t_perf, "reset": t_reset, "invalid": t_invalid,
    "backpressure": t_backpressure, "kernels_many": t_kernels_many, "parity": t_parity,
}
STAGE1 = ["s1_vec_basic", "s1_vec_random", "s1_vec_reduce", "s1_vec_long"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", required=True, help="JSON: NUM_LANES DATA_WIDTH SCRATCHPAD_BYTES NUM_BANKS ...")
    ap.add_argument("--out", required=True)
    ap.add_argument("--tests", default=",".join(TESTS))
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    c = json.loads(a.cfg)
    cfg = Cfg(n_lanes=c.get("NUM_LANES", 4), dw=c.get("DATA_WIDTH", 32), spm_bytes=c.get("SCRATCHPAD_BYTES", 65536),
              num_banks=c.get("NUM_BANKS", 4), buffered_dma=c.get("DMA_BUFFER_DEPTH", 0) != 0)
    out = Path(a.out)
    summary = []
    for i, name in enumerate(a.tests.split(",")):
        if name == "parity" and not c.get("SPM_ECC", 0):
            continue
        p = Prog(cfg, name, a.seed * 1000 + i)
        p.ecc = bool(c.get("SPM_ECC", 0))
        p.qdepth = c.get("CMD_QUEUE_DEPTH", 8)
        p.cplq = c.get("CPL_QUEUE_DEPTH", 8)
        TESTS[name](p)
        summary.append(p.write(out / name))
    (out / "tests.json").write_text(json.dumps(summary, indent=1))
    for s in summary:
        print(f"{s['name']:16s} commands={s['commands']:4d} final_words={s['final_words']:6d}")


if __name__ == "__main__":
    main()
