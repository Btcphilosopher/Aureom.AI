// =============================================================================
// SilicaFlux-HPC :: Module 01 :: FP32 fused multiply-add
// fp32_fma_lzc.sv -- logarithmic-depth leading-zero counter
//
// cnt = number of leading zeros of x (x[W-1] is the most significant bit);
// cnt = W when x == 0. Requires 2**CW >= W + 1.
//
// The input is padded to P = 2**CW bits as {x, 1'b1, 0...}; the padding one
// makes the count saturate at exactly W for x == 0 and guarantees every tree
// node below the root sees a defined value. Each tree level merges two
// children (valid, count) pairs: count = vl ? {0, cl} : {1, cr}. Depth is
// CW mux levels instead of the W-deep chain of a priority loop.
// Equivalence with the obvious priority loop is proven with Yosys SAT
// (formal/lzc_equiv.ys) for both instantiated widths.
// =============================================================================
`default_nettype none

module fp32_fma_lzc #(
  parameter int W  = 24,
  parameter int CW = 5
) (
  input  wire logic [W-1:0]  x,
  output logic      [CW-1:0] cnt,
  output logic               zero
);
  localparam int P = 1 << CW;

  logic [P-1:0] y;
  if (P - W - 1 > 0) begin : g_pad
    assign y = {x, 1'b1, {(P - W - 1){1'b0}}};
  end else begin : g_nopad
    assign y = {x, 1'b1};
  end

  // Level k has N = P >> k nodes; node j covers y[(j+1)*2^k-1 : j*2^k].
  // Each node owns a (k+1)-bit slot of c: its k-bit leading-zero count,
  // zero-extended by one spare bit (avoids zero-width vectors at k = 0).
  for (genvar k = 0; k <= CW; k++) begin : g_lvl
    localparam int N = P >> k;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [N-1:0]       v;                   // node contains a one
    logic [N*(k+1)-1:0] c;                   // per-node count slots
    /* verilator lint_on UNUSEDSIGNAL */
    if (k == 0) begin : g_leaf
      assign v = y;
      assign c = '0;
    end else begin : g_node
      for (genvar j = 0; j < N; j++) begin : g_j
        logic         vl, vr;                // vl: more significant child
        logic [k-1:0] cl, cr;                // child counts (< 2^(k-1))
        logic [k-1:0] cn;
        assign vl = g_lvl[k-1].v[2*j+1];
        assign vr = g_lvl[k-1].v[2*j];
        assign cl = g_lvl[k-1].c[(2*j+1)*k +: k];
        assign cr = g_lvl[k-1].c[(2*j)*k   +: k];
        // upper child non-empty: its count; else 2^(k-1) + lower count
        always_comb begin
          cn = vl ? cl : cr;
          if (!vl) cn[k-1] = 1'b1;
        end
        assign v[j]              = vl | vr;
        assign c[j*(k+1) +: k+1] = {1'b0, cn};
      end
    end
  end

  assign cnt  = g_lvl[CW].c[CW-1:0];
  assign zero = ~|x;
endmodule

`default_nettype wire
