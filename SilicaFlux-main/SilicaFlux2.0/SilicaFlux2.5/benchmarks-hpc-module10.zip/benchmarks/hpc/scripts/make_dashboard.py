#!/usr/bin/env python3
"""Build reports/dashboard.html: a self-contained (offline, no external requests) scientific dashboard.

All data is embedded from reports/runs/**.json and reports/analysis.json at build time; the page computes
nothing it does not show the source of.  Views: 1 summary, 2 compute throughput, 3 memory bandwidth, 4 lane
utilisation, 5 pipeline stalls, 6 DMA activity, 7 SRAM bank conflicts, 8 roofline, 9 configuration scaling,
10 simulation vs FPGA, 11 numerical correctness, 12 experiment provenance.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bench import analysis as A  # noqa: E402
from bench import paths as P  # noqa: E402


def compact(r: dict) -> dict:
    pt = r["experiment"]["point"]
    hwd = r.get("hardware") or {}
    prm = hwd.get("params", {})
    row = dict(id=r["run_id"], exp=r["experiment"]["id"], seed=r["experiment"]["seed"], b=r["benchmark"]["id"],
               name=r["benchmark"].get("name", ""), var=r["benchmark"].get("variant", ""), cfg=hwd.get("name"),
               p=dict(lanes=prm.get("NUM_LANES"), dw=prm.get("DATA_WIDTH"), banks=prm.get("NUM_BANKS"),
                      dma=prm.get("DMA_BUFFER_DEPTH"), lat=prm.get("EXT0_LATENCY"), ports=prm.get("LSU_MAX_PORTS"),
                      rl=prm.get("SPM_READ_LATENCY")),
               pt={k: v for k, v in pt.items() if not k.startswith("_") and k != "not_run"},
               st=r["status"], why=r["status_reason"], rep=r.get("reproduce"))
    if r["status"] != "VALID":
        return row
    m = r["metrics"]
    c = r["correctness"]
    outs = list(c.get("outputs", {}).values())
    row.update(
        op=r["benchmark"].get("operation", ""), cyc=r["timing"]["cycles"], e2e=r["timing"]["cycles_host_e2e"],
        busy=r["timing"]["cycles_tile_busy"], tsrc=r["timing"]["source"].split(":")[0], ncmd=r["timing"]["commands"],
        flops=r["operations"]["flops"], elems=r["operations"]["elements"],
        epc=m["elements_per_cycle"], fpc=m["flop_per_cycle"], peak=m["peak_flop_per_cycle"],
        lsu=m.get("lsu_bound_elements_per_cycle"),
        bnd=[[b["boundary"], b["bytes_per_cycle"], b["useful_bytes_per_cycle"], b["ai_useful"], b["path"]]
             for b in m["boundaries"]],
        lu=m["vector_unit"]["lane_utilisation"], occ=m["vector_unit"]["issue_occupancy"],
        va=m["vector_unit"]["active_cycles"],
        stall=[m["vector_unit"]["stall_breakdown"][k] for k in ("issue", "operand_starvation", "array_backpressure")],
        fma=m["vector_unit"]["fma_retired"],
        dma=dict(act=m["dma"]["active_cycles"], bpa=m["dma"]["fabric_beats_per_active_cycle"],
                 out=m["dma"]["mean_outstanding"], rd=m["dma"]["bytes_rd"], wr=m["dma"]["bytes_wr"],
                 ovl=m["dma"]["overlap_cycles"], rs=m["dma"]["fabric_req_stall_cycles"]),
        spm=dict(conf=m["scratchpad"]["conflicts"], cpa=m["scratchpad"]["conflicts_per_access"],
                 banks=m["scratchpad"]["bank_ops"], lsuc=m["scratchpad"]["lsu_conflicts"],
                 dmac=m["scratchpad"]["dma_conflicts"], hostc=m["scratchpad"]["host_conflicts"],
                 bu=m["scratchpad"]["bank_utilisation_vec_active"]),
        q=[m["queues"]["cmdq_full_cycles"], m["queues"]["cplq_stall_cycles"], m["queues"]["hazard_stall_cycles"]],
        mf25=(m["per_second"]["flops"].get("fpga_constraint_25mhz") or 0) / 1e6 or None,
        corr=dict(words=sum(o.get("compared", 0) for o in outs), mis=sum(o.get("mismatches", 0) for o in outs),
                  ulp=max([o.get("max_ulp", 0) for o in outs] or [0]),
                  fl=next((o.get("flags_match") for o in outs if "flags_match" in o), None),
                  flhw=next((o.get("flags_hw") for o in outs if "flags_hw" in o), None),
                  nan=sum(o.get("nan_count", 0) for o in outs), inf=sum(o.get("inf_count", 0) for o in outs),
                  sub=sum(max(o.get("subnormal_count", 0), 0) for o in outs),
                  tol=(dict(rel=c["tolerance"]["max_rel_err"], ratio=c["tolerance"]["max_err_over_bound"],
                            ok=c["tolerance"]["passed"]) if "tolerance" in c else None),
                  orders=c.get("orders")),
        xc=[r["cross_check"]["n_checks"], r["cross_check"]["n_failed"], "csv" in r["cross_check"]],
        rtl=r["rtl"]["tile_rtl_sha256"][:12], bk=r["rtl"]["build_key"])
    return row


def main():
    recs = A.load_records()
    an = json.loads((P.REPORTS / "analysis.json").read_text())
    synth = json.loads((P.M08 / "reports" / "synth.json").read_text())
    data = dict(runs=[compact(r) for r in recs], an=an, synth=synth)
    blob = json.dumps(data, separators=(",", ":"), default=str).replace("</", "<\\/")
    html = TEMPLATE.replace("__DATA__", blob)
    (P.REPORTS / "dashboard.html").write_text(html)
    print(f"reports/dashboard.html ({len(html) / 1024:.0f} KiB, {len(recs)} runs embedded)")


TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SilicaFlux-HPC Benchmarks</title>
<style>
:root {
  color-scheme: light;
  --bg: #f4f2ec; --panel: #ffffff; --panel-2: #f8f6f0; --line: #dcd8cc; --grid: #e6e2d8;
  --ink: #0e1730; --ink-2: #3c4660; --ink-3: #6a7390;
  --accent: #8f6a0e; --accent-2: #0083b0; --navy: #0b1530;
  --s1: #0083b0; --s2: #8f6a0e; --s3: #6a4fd8; --s4: #b8306f;
  --ok: #0a7d32; --warn: #9a6400; --bad: #b3261e; --na: #6a7390;
  --chip: #ece8de;
}
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) {
    color-scheme: dark;
    --bg: #070e22; --panel: #0b1530; --panel-2: #0f1c3d; --line: #22305a; --grid: #1b2850;
    --ink: #e8ecf4; --ink-2: #a9b4c8; --ink-3: #7d89a3;
    --accent: #d4af37; --accent-2: #22d3ee;
    --s1: #0aa2c0; --s2: #b38a1d; --s3: #8f6ff0; --s4: #d24c8e;
    --ok: #3fbf6f; --warn: #e0a83a; --bad: #ef6b63; --na: #7d89a3; --chip: #14224a;
  }
}
:root[data-theme="dark"] {
  color-scheme: dark;
  --bg: #070e22; --panel: #0b1530; --panel-2: #0f1c3d; --line: #22305a; --grid: #1b2850;
  --ink: #e8ecf4; --ink-2: #a9b4c8; --ink-3: #7d89a3;
  --accent: #d4af37; --accent-2: #22d3ee;
  --s1: #0aa2c0; --s2: #b38a1d; --s3: #8f6ff0; --s4: #d24c8e;
  --ok: #3fbf6f; --warn: #e0a83a; --bad: #ef6b63; --na: #7d89a3; --chip: #14224a;
}
* { box-sizing: border-box; }
html, body { margin: 0; background: var(--bg); color: var(--ink);
  font: 14px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif; }
code, .mono { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12px; }
header { padding: 20px 24px 14px; border-bottom: 1px solid var(--line); background: var(--panel);
  display: flex; flex-wrap: wrap; gap: 12px 24px; align-items: flex-end; justify-content: space-between; }
header h1 { margin: 0; font-size: 21px; letter-spacing: .2px; font-weight: 650; }
header h1 .rule { display: block; width: 44px; height: 3px; background: var(--accent); margin-bottom: 9px; border-radius: 2px; }
header .sub { color: var(--ink-2); font-size: 13px; margin-top: 2px; }
.chips { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.chip { background: var(--chip); border: 1px solid var(--line); border-radius: 999px; padding: 3px 10px; font-size: 12px;
  color: var(--ink-2); white-space: nowrap; }
.chip b { color: var(--ink); font-weight: 600; }
.chip .dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; vertical-align: 1px; }
button.theme { background: transparent; color: var(--ink-2); border: 1px solid var(--line); border-radius: 8px;
  padding: 4px 10px; cursor: pointer; font: inherit; font-size: 12px; }
.layout { display: grid; grid-template-columns: 228px minmax(0, 1fr); min-height: calc(100vh - 90px); }
nav { border-right: 1px solid var(--line); padding: 14px 10px; background: var(--panel); }
nav a { display: flex; gap: 10px; align-items: baseline; padding: 7px 10px; border-radius: 8px; color: var(--ink-2);
  text-decoration: none; font-size: 13.5px; cursor: pointer; }
nav a .n { color: var(--ink-3); font-variant-numeric: tabular-nums; width: 18px; font-size: 12px; }
nav a:hover { background: var(--panel-2); color: var(--ink); }
nav a.on { background: var(--panel-2); color: var(--ink); box-shadow: inset 3px 0 0 var(--accent); }
main { padding: 22px 26px 60px; min-width: 0; }
.view { display: none; } .view.on { display: block; }
.view > h2 { margin: 0 0 4px; font-size: 19px; font-weight: 650; }
.lede { color: var(--ink-2); margin: 0 0 18px; max-width: 980px; }
.grid { display: grid; gap: 16px; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); }
.card { background: var(--panel); border: 1px solid var(--line); border-radius: 12px; padding: 16px 18px; min-width: 0; }
.card h3 { margin: 0 0 2px; font-size: 14.5px; font-weight: 620; }
.card .note { color: var(--ink-3); font-size: 12px; margin: 2px 0 10px; }
.kpis { display: grid; gap: 12px; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); margin-bottom: 16px; }
.kpi { background: var(--panel); border: 1px solid var(--line); border-radius: 12px; padding: 14px 16px; }
.kpi .k { color: var(--ink-2); font-size: 12.5px; }
.kpi .v { font-size: 26px; font-weight: 650; margin: 2px 0; font-variant-numeric: tabular-nums; letter-spacing: -.3px; }
.kpi .v small { font-size: 13px; color: var(--ink-2); font-weight: 500; }
.kpi .s { color: var(--ink-3); font-size: 12px; }
.kpi.gold { border-top: 3px solid var(--accent); }
.status { font-weight: 600; font-size: 12px; padding: 1px 8px; border-radius: 6px; white-space: nowrap; display: inline-block; }
.status.VALID, .status.ok { color: var(--ok); background: color-mix(in srgb, var(--ok) 13%, transparent); }
.status.NOT_RUN, .status.na { color: var(--na); background: color-mix(in srgb, var(--na) 15%, transparent); }
.status.FAILED, .status.bad { color: var(--bad); background: color-mix(in srgb, var(--bad) 14%, transparent); }
table { border-collapse: collapse; width: 100%; font-size: 12.5px; font-variant-numeric: tabular-nums; }
th, td { text-align: left; padding: 6px 8px; border-bottom: 1px solid var(--line); vertical-align: top; }
th { color: var(--ink-2); font-weight: 600; background: var(--panel-2); position: sticky; top: 0; }
td.num, th.num { text-align: right; }
.tablewrap { overflow: auto; max-height: 460px; border: 1px solid var(--line); border-radius: 8px; }
details.tbl { margin-top: 8px; } details.tbl summary { cursor: pointer; color: var(--ink-3); font-size: 12px; }
.chart { width: 100%; position: relative; }
.chart svg { display: block; width: 100%; height: auto; overflow: visible; }
.chart text { fill: var(--ink-2); font-size: 11px; }
.chart .axis line, .chart .axis path { stroke: var(--line); }
.chart .gridl { stroke: var(--grid); stroke-width: 1; }
.chart .ref { stroke: var(--ink-3); stroke-dasharray: 5 4; stroke-width: 1.2; fill: none; }
.chart .roof { stroke: var(--ink); stroke-width: 2; fill: none; }
.chart .lbl { fill: var(--ink-2); font-size: 11px; }
.chart .lbl3 { fill: var(--ink-3); font-size: 10.5px; }
.legend { display: flex; flex-wrap: wrap; gap: 6px 16px; margin: 4px 0 6px; font-size: 12px; color: var(--ink-2); }
.legend i { display: inline-block; width: 12px; height: 12px; border-radius: 3px; margin-right: 6px; vertical-align: -2px; }
#tip { position: fixed; pointer-events: none; background: var(--panel); color: var(--ink); border: 1px solid var(--line);
  border-radius: 8px; padding: 8px 10px; font-size: 12px; box-shadow: 0 6px 20px rgba(0,0,0,.25); display: none;
  max-width: 340px; z-index: 10; }
#tip b { font-weight: 620; } #tip .t { color: var(--ink-3); }
.bn { border-left: 3px solid var(--accent); padding: 8px 12px; margin: 10px 0; background: var(--panel-2); border-radius: 0 8px 8px 0; }
.bn h4 { margin: 0 0 4px; font-size: 13.5px; }
.bn p { margin: 4px 0; color: var(--ink-2); font-size: 13px; }
.cellgrid { display: grid; gap: 3px; }
.cell { padding: 4px 2px; border-radius: 4px; text-align: center; font-size: 11px; font-weight: 600; }
.cell.ok { background: color-mix(in srgb, var(--ok) 18%, transparent); color: var(--ok); }
.cell.bad { background: color-mix(in srgb, var(--bad) 20%, transparent); color: var(--bad); }
.cell.h { color: var(--ink-3); font-weight: 500; background: transparent; }
input.search { width: 100%; max-width: 420px; padding: 7px 10px; border-radius: 8px; border: 1px solid var(--line);
  background: var(--panel-2); color: var(--ink); font: inherit; margin-bottom: 10px; }
select { background: var(--panel-2); color: var(--ink); border: 1px solid var(--line); border-radius: 8px; padding: 4px 8px; font: inherit; font-size: 12.5px; }
.muted { color: var(--ink-3); }
.warnbox { border: 1px dashed var(--line); border-radius: 10px; padding: 10px 14px; color: var(--ink-2); background: var(--panel-2); }
@media (max-width: 860px) {
  .layout { grid-template-columns: 1fr; }
  nav { display: flex; overflow-x: auto; border-right: 0; border-bottom: 1px solid var(--line); padding: 8px; gap: 4px; }
  nav a { white-space: nowrap; }
  nav a.on { box-shadow: inset 0 -3px 0 var(--accent); }
  main { padding: 16px; }
  header { padding: 16px; }
}
</style>
</head>
<body>
<header>
  <div>
    <h1><span class="rule"></span>SilicaFlux-HPC · Benchmarks</h1>
    <div class="sub">Module 10 · silicaflux_hpc_tile RTL (Module 08) · Verilator RTL simulation · time base: tile clock cycles</div>
  </div>
  <div class="chips" id="chips"></div>
</header>
<div class="layout">
  <nav id="nav"></nav>
  <main id="main"></main>
</div>
<div id="tip"></div>
<script id="data" type="application/json">__DATA__</script>
<script>
"use strict";
const D = JSON.parse(document.getElementById("data").textContent);
const RUNS = D.runs, AN = D.an;
const V = RUNS.filter(r => r.st === "VALID");
const S1 = V.filter(r => r.seed === 1);
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const fmt = (x, d = 3) => x == null || isNaN(x) ? "–" : (Math.abs(x) >= 1e4 ? Math.round(x).toLocaleString("en") : (+x).toFixed(d));
const pct = x => x == null ? "–" : (100 * x).toFixed(1) + " %";
const css = v => getComputedStyle(document.documentElement).getPropertyValue(v).trim();
const SER = ["--s1", "--s2", "--s3", "--s4"];
const pick = (exp, f = () => true) => S1.filter(r => r.exp === exp && f(r));
const one = (exp, f) => pick(exp, f)[0];
const B = (r, name) => (r.bnd || []).find(b => b[0] === name);

// ---------------------------------------------------------------- theme
function setTheme(t) { document.documentElement.setAttribute("data-theme", t); try { localStorage.setItem("sfhpc-theme", t); } catch (e) {} redraw(); }
(function () { let t = null; try { t = localStorage.getItem("sfhpc-theme"); } catch (e) {}
  if (t) document.documentElement.setAttribute("data-theme", t); })();

// ---------------------------------------------------------------- tooltip
const tip = $("#tip");
function showTip(ev, html) { tip.innerHTML = html; tip.style.display = "block";
  const w = tip.offsetWidth, h = tip.offsetHeight; let x = ev.clientX + 14, y = ev.clientY + 14;
  if (x + w > innerWidth - 8) x = ev.clientX - w - 14; if (y + h > innerHeight - 8) y = ev.clientY - h - 14;
  tip.style.left = x + "px"; tip.style.top = y + "px"; }
function hideTip() { tip.style.display = "none"; }
function bindTips(root) {
  root.querySelectorAll("[data-tip]").forEach(el => {
    el.addEventListener("mousemove", ev => showTip(ev, el.getAttribute("data-tip")));
    el.addEventListener("mouseleave", hideTip);
  });
}

// ---------------------------------------------------------------- scales
function scale(dom, rng, log) {
  if (log) { const l0 = Math.log2(dom[0]), l1 = Math.log2(dom[1]);
    const f = v => rng[0] + (Math.log2(v) - l0) / (l1 - l0) * (rng[1] - rng[0]);
    f.ticks = () => { const t = []; for (let e = Math.ceil(l0); e <= Math.floor(l1); e++) t.push(2 ** e);
      const step = Math.max(1, Math.ceil(t.length / 9)); return t.filter((_, i) => i % step === 0); }; return f; }
  const f = v => rng[0] + (v - dom[0]) / (dom[1] - dom[0]) * (rng[1] - rng[0]);
  f.ticks = () => { const span = dom[1] - dom[0]; const raw = span / 5; const p = 10 ** Math.floor(Math.log10(raw));
    const st = [1, 2, 2.5, 5, 10].map(m => m * p).find(s => span / s <= 6); const t = [];
    for (let v = Math.ceil(dom[0] / st) * st; v <= dom[1] + 1e-9; v += st) t.push(+v.toFixed(10)); return t; };
  return f;
}
const tickLabel = v => v >= 1024 && Math.log2(v) % 1 === 0 && v >= 2048 ? (v / 1024) + "K" : (v < 1 && v > 0 ? (v >= 0.01 ? +v.toPrecision(2) : "2^" + Math.log2(v)) : v);

// ---------------------------------------------------------------- generic XY chart (lines + scatter + roofs)
const cw = el => Math.max(320, Math.min(1180, Math.floor(el.clientWidth || 760)));
function xyChart(el, o) {
  const W = cw(el), H = o.height || 340, m = {l: 62, r: o.rpad || 120, t: 14, b: 46};
  const pts = o.series.flatMap(s => s.points);
  const xs = pts.map(p => p.x).concat(o.xExtra || []), ys = pts.map(p => p.y).concat(o.yExtra || []);
  let x0 = o.xmin ?? Math.min(...xs), x1 = o.xmax ?? Math.max(...xs), y0 = o.ymin ?? (o.ylog ? Math.min(...ys) : 0), y1 = o.ymax ?? Math.max(...ys);
  if (o.xlog) { x0 = 2 ** Math.floor(Math.log2(x0)); x1 = 2 ** Math.ceil(Math.log2(x1)); }
  if (o.ylog) { y0 = 2 ** Math.floor(Math.log2(y0)); y1 = 2 ** Math.ceil(Math.log2(y1 * 1.05)); } else y1 = y1 * 1.12;
  const X = scale([x0, x1], [m.l, W - m.r], o.xlog), Y = scale([y0, y1], [H - m.b, m.t], o.ylog);
  let g = "";
  for (const t of Y.ticks()) g += `<line class="gridl" x1="${m.l}" x2="${W - m.r}" y1="${Y(t)}" y2="${Y(t)}"/><text x="${m.l - 8}" y="${Y(t) + 4}" text-anchor="end">${tickLabel(t)}</text>`;
  for (const t of X.ticks()) g += `<text x="${X(t)}" y="${H - m.b + 17}" text-anchor="middle">${tickLabel(t)}</text>`;
  g += `<line class="axis" stroke="${css("--line")}" x1="${m.l}" x2="${W - m.r}" y1="${H - m.b}" y2="${H - m.b}"/>`;
  g += `<text x="${(m.l + W - m.r) / 2}" y="${H - 8}" text-anchor="middle">${esc(o.xLabel)}</text>`;
  g += `<text transform="translate(14 ${(m.t + H - m.b) / 2}) rotate(-90)" text-anchor="middle">${esc(o.yLabel)}</text>`;
  for (const rf of (o.roofs || [])) {
    const n = 80, path = []; for (let i = 0; i <= n; i++) { const xv = o.xlog ? 2 ** (Math.log2(x0) + i / n * (Math.log2(x1) - Math.log2(x0))) : x0 + i / n * (x1 - x0);
      const yv = Math.max(y0, Math.min(y1, rf.f(xv))); path.push(`${i ? "L" : "M"}${X(xv).toFixed(1)},${Y(yv).toFixed(1)}`); }
    g += `<path class="${rf.cls || "roof"}" d="${path.join("")}" data-tip="${esc(rf.tip || rf.name)}"/>`;
    if (rf.label) g += `<text class="lbl3" x="${X(rf.lx ?? x1) + (rf.dx || 4)}" y="${Y(Math.max(y0, Math.min(y1, rf.f(rf.lx ?? x1)))) + (rf.dy || 4)}" text-anchor="${rf.anchor || "start"}">${esc(rf.label)}</text>`;
  }
  for (const r of (o.hrefs || [])) {
    g += `<line class="ref" x1="${m.l}" x2="${W - m.r}" y1="${Y(r.y)}" y2="${Y(r.y)}"/><text class="lbl3" x="${W - m.r + 4}" y="${Y(r.y) + 4}">${esc(r.label)}</text>`;
  }
  o.series.forEach((s, i) => {
    const col = css(s.color || SER[i % 4]);
    const sp = s.points.slice().sort((a, b) => a.x - b.x);
    if (s.line !== false && sp.length > 1) g += `<path d="${sp.map((p, j) => `${j ? "L" : "M"}${X(p.x).toFixed(1)},${Y(p.y).toFixed(1)}`).join("")}" fill="none" stroke="${col}" stroke-width="2"/>`;
    for (const p of sp) {
      const cx = X(p.x).toFixed(1), cy = Y(p.y).toFixed(1), sh = s.shape || "circle";
      const mark = sh === "square" ? `<rect x="${cx - 4.5}" y="${cy - 4.5}" width="9" height="9" rx="1.5"` :
        sh === "tri" ? `<path d="M${cx},${cy - 6}L${+cx + 5.5},${+cy + 4}L${cx - 5.5},${+cy + 4}Z"` : `<circle cx="${cx}" cy="${cy}" r="4.5"`;
      g += `${mark} fill="${col}" stroke="${css("--panel")}" stroke-width="2"/>`;
      g += `<circle cx="${cx}" cy="${cy}" r="11" fill="transparent" data-tip="${esc(p.tip || `${s.name}: ${fmt(p.y)}`)}"/>`;
    }
    if (s.endLabel && sp.length) { const p = sp[sp.length - 1]; g += `<text class="lbl" x="${X(p.x) + 9}" y="${Y(p.y) + 4}">${esc(s.endLabel)}</text>`; }
  });
  for (const a of (o.annot || [])) g += `<text class="lbl" x="${X(a.x) + (a.dx || 8)}" y="${Y(a.y) + (a.dy || -8)}" text-anchor="${a.anchor || "start"}">${esc(a.text)}</text>`;
  el.innerHTML = legend(o.series) + `<div class="chart"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(o.title || o.yLabel)}">${g}</svg></div>`;
  bindTips(el);
}
function legend(series) {
  if (series.length < 2) return "";
  return `<div class="legend">${series.map((s, i) => `<span><i style="background:${css(s.color || SER[i % 4])}"></i>${esc(s.name)}</span>`).join("")}</div>`;
}

// ---------------------------------------------------------------- bar chart (grouped / stacked, vertical / horizontal)
function barChart(el, o) {
  const horiz = !!o.horizontal, cats = o.cats, ser = o.series;
  const W = cw(el), rowH = 30, H = horiz ? cats.length * rowH + 60 : (o.height || 320);
  const m = horiz ? {l: o.lpad || 170, r: o.rightLabels ? 104 : 70, t: 8, b: 40} : {l: 62, r: 20, t: 14, b: o.bpad || 64};
  const totals = cats.map((_, i) => o.stacked ? ser.reduce((a, s) => a + (s.values[i] || 0), 0) : Math.max(...ser.map(s => s.values[i] || 0)));
  const vmax = o.max ?? Math.max(...totals, ...(o.refs || []).map(r => r.y)) * 1.12;
  const V_ = scale([0, vmax], horiz ? [m.l, W - m.r] : [H - m.b, m.t], false);
  const band = (horiz ? H - m.t - m.b : W - m.l - m.r) / cats.length, gw = band * 0.72;
  let g = "";
  for (const t of V_.ticks()) g += horiz ? `<line class="gridl" y1="${m.t}" y2="${H - m.b}" x1="${V_(t)}" x2="${V_(t)}"/><text x="${V_(t)}" y="${H - m.b + 16}" text-anchor="middle">${o.percent ? (100 * t).toFixed(0) + "%" : tickLabel(t)}</text>`
    : `<line class="gridl" x1="${m.l}" x2="${W - m.r}" y1="${V_(t)}" y2="${V_(t)}"/><text x="${m.l - 8}" y="${V_(t) + 4}" text-anchor="end">${o.percent ? (100 * t).toFixed(0) + "%" : tickLabel(t)}</text>`;
  cats.forEach((c, i) => {
    const c0 = (horiz ? m.t : m.l) + i * band + (band - gw) / 2;
    let acc = 0;
    ser.forEach((s, j) => {
      const v = s.values[i]; if (v == null) return;
      const col = css(s.color || SER[j % 4]);
      const w = o.stacked ? gw : (gw - 2 * (ser.length - 1)) / ser.length;
      const off = o.stacked ? 0 : j * (w + 2);
      const a = o.stacked ? acc : 0, b = a + v; acc = b;
      const p0 = V_(a), p1 = V_(b);
      const tipTxt = esc(s.tips ? s.tips[i] : `${c} · ${s.name}: ${o.percent ? pct(v) : fmt(v)}`);
      if (horiz) g += `<rect x="${Math.min(p0, p1) + (o.stacked && j ? 1 : 0)}" y="${c0 + off}" width="${Math.max(0, Math.abs(p1 - p0) - (o.stacked ? 2 : 0))}" height="${w}" rx="3" fill="${col}" data-tip="${tipTxt}"/>`;
      else g += `<rect x="${c0 + off}" y="${Math.min(p0, p1)}" width="${w}" height="${Math.max(0, Math.abs(p1 - p0) - (o.stacked && j ? 2 : 0))}" rx="3" fill="${col}" data-tip="${tipTxt}"/>`;
      if (o.valueLabels && !o.stacked) g += horiz ? `<text class="lbl" x="${p1 + 5}" y="${c0 + off + w / 2 + 4}">${o.percent ? pct(v) : fmt(v, o.vd ?? 2)}</text>`
        : `<text class="lbl" x="${c0 + off + w / 2}" y="${p1 - 5}" text-anchor="middle">${o.percent ? pct(v) : fmt(v, o.vd ?? 2)}</text>`;
    });
    if (o.rightLabels) g += `<text class="lbl" x="${W - m.r + 6}" y="${c0 + gw / 2 + 4}">${esc(o.rightLabels[i])}</text>`;
    if (horiz) g += `<text x="${m.l - 8}" y="${c0 + gw / 2 + 4}" text-anchor="end">${esc(c)}</text>`;
    else { const lines = String(c).split("\n"); lines.forEach((ln, k) => g += `<text x="${c0 + gw / 2}" y="${H - m.b + 16 + 13 * k}" text-anchor="middle">${esc(ln)}</text>`); }
  });
  for (const r of (o.refs || [])) g += horiz ? `<line class="ref" y1="${m.t}" y2="${H - m.b}" x1="${V_(r.y)}" x2="${V_(r.y)}"/>`
    : `<line class="ref" x1="${m.l}" x2="${W - m.r}" y1="${V_(r.y)}" y2="${V_(r.y)}"/><text class="lbl3" x="${W - m.r}" y="${V_(r.y) - 5}" text-anchor="end">${esc(r.label)}</text>`;
  if (o.yLabel) g += horiz ? `<text x="${(m.l + W - m.r) / 2}" y="${H - 6}" text-anchor="middle">${esc(o.yLabel)}</text>` : `<text transform="translate(14 ${(m.t + H - m.b) / 2}) rotate(-90)" text-anchor="middle">${esc(o.yLabel)}</text>`;
  el.innerHTML = legend(ser) + `<div class="chart"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(o.yLabel)}">${g}</svg></div>`;
  bindTips(el);
}

// ---------------------------------------------------------------- tables
function tableHTML(cols, rows, opts = {}) {
  return `<div class="tablewrap"${opts.maxh ? ` style="max-height:${opts.maxh}px"` : ""}><table><thead><tr>${cols.map(c => `<th class="${c.num ? "num" : ""}">${esc(c.h)}</th>`).join("")}</tr></thead><tbody>${rows.map(r => `<tr>${cols.map((c, i) => `<td class="${c.num ? "num" : ""}">${c.raw ? r[i] : esc(r[i])}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}
function withTable(cols, rows) { return `<details class="tbl"><summary>Data table</summary>${tableHTML(cols, rows)}</details>`; }
const stat = s => `<span class="status ${s}">${s.replace("_", " ")}</span>`;

// ---------------------------------------------------------------- views
const VIEWS = [
  ["summary", "Benchmark summary"], ["compute", "Compute throughput"], ["memory", "Memory bandwidth"],
  ["lanes", "Lane utilisation"], ["stalls", "Pipeline stalls"], ["dma", "DMA activity"],
  ["banks", "SRAM bank conflicts"], ["roofline", "Roofline"], ["scaling", "Configuration scaling"],
  ["fpga", "Simulation vs FPGA"], ["correct", "Numerical correctness"], ["prov", "Experiment provenance"]];
let current = "summary";
function nav() {
  $("#nav").innerHTML = VIEWS.map(([k, t], i) => `<a data-v="${k}" class="${k === current ? "on" : ""}"><span class="n">${i + 1}</span>${t}</a>`).join("");
  $("#nav").querySelectorAll("a").forEach(a => a.onclick = () => { current = a.dataset.v; try { history.replaceState(null, "", "#" + current); } catch (e) {} redraw(); });
}
function redraw() { nav(); const v = VIEWS.find(x => x[0] === current); $("#main").innerHTML = `<section class="view on" id="v-${current}"></section>`; R[current]($("#v-" + current)); window.scrollTo(0, 0); }
function chips() {
  const c = AN.counts;
  $("#chips").innerHTML = `<span class="chip"><span class="dot" style="background:var(--ok)"></span><b>${c.VALID || 0}</b> valid runs</span>
  <span class="chip"><span class="dot" style="background:var(--na)"></span><b>${c.NOT_RUN || 0}</b> not run</span>
  <span class="chip"><span class="dot" style="background:var(--bad)"></span><b>${c.FAILED || 0}</b> failed</span>
  <span class="chip">FPGA <b>NOT RUN</b></span><span class="chip">Energy <b>NOT AVAILABLE</b></span>
  <button class="theme" onclick="setTheme((document.documentElement.getAttribute('data-theme')||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'))==='dark'?'light':'dark')">Theme</button>`;
}
const card = (title, note, body, id, wide) => `<div class="card"${id ? ` id="${id}"` : ""}${wide ? ' style="grid-column:1/-1"' : ""}><h3>${esc(title)}</h3>${note ? `<div class="note">${note}</div>` : ""}${body || ""}</div>`;

const R = {};
R.summary = el => {
  const h = AN.headline, sb = AN.sustained_bandwidth, c = AN.correctness;
  el.innerHTML = `<h2>Benchmark summary</h2><p class="lede">Every number on this page was measured by executing the workload on the RTL of the SilicaFlux-HPC compute tile (Module 08) in Verilator, checked against an independent reference, and cross-checked against simulation traces. Cycles are tile-clock cycles; no clock frequency was measured. Per-second values appear only at the labelled 25 MHz place-and-route constraint.</p>
  <div class="kpis">
    <div class="kpi gold"><div class="k">FMA on scratchpad data</div><div class="v">${fmt(h.fma_spm.flop_per_cycle, 2)} <small>FLOP / cycle</small></div><div class="s">${pct(h.fma_spm.fraction_of_peak)} of P_peak ${fmt(h.fma_spm.peak, 0)} · ${fmt(h.fma_spm.mflops_25mhz, 1)} MFLOP/s at 25 MHz (constraint, not measured)</div></div>
    <div class="kpi"><div class="k">FMA end to end (host memory)</div><div class="v">${fmt(h.fma_kernel.flop_per_cycle, 3)} <small>FLOP / cycle</small></div><div class="s">${fmt(h.fma_kernel.flop_per_cycle_buffered, 3)} with buffered DMA · ${fmt(h.fma_kernel.ratio_spm_over_kernel, 1)}× below scratchpad-resident</div></div>
    <div class="kpi"><div class="k">Sustained scratchpad bandwidth</div><div class="v">${fmt(sb.scratchpad.bytes_per_cycle, 2)} <small>B / cycle</small></div><div class="s">of ${fmt(sb.scratchpad.peak_bytes_per_cycle, 0)} B/cycle LSU-port peak · STREAM-inspired</div></div>
    <div class="kpi"><div class="k">Sustained DMA bandwidth</div><div class="v">${fmt(sb.host_memory_base.bytes_per_cycle, 2)} <small>B / cycle</small></div><div class="s">${fmt((sb.host_memory_d8 || {}).bytes_per_cycle, 2)} buffered · of ${fmt(sb.host_memory_base.peak_bytes_per_cycle, 0)} B/cycle fabric port</div></div>
    <div class="kpi"><div class="k">Output words checked</div><div class="v">${(c.bitwise_words).toLocaleString("en")}</div><div class="s"><b>${c.bitwise_mismatches}</b> mismatches · flags identical on ${c.flags_matched}/${c.flags_compared} commands</div></div>
  </div>
  <div class="grid">
    ${card("Bottlenecks, in order", "Identified from the core runs (vector add, FMA, bandwidth) before the suite was expanded.",
      AN.bottlenecks.map(b => `<div class="bn"><h4>${b.rank}. ${esc(b.where)}</h4><p>${esc(b.evidence)}</p><p><b>Next step:</b> ${esc(b.next_step)}</p></div>`).join(""))}
    ${card("Benchmark status", "A benchmark is valid only when it executed, its output was checked, and its timing provenance is known.", statusTable())}
  </div>`;
};
function statusTable() {
  const rowsDef = [
    ["A", "Vector addition", "A1_vadd_spm", r => `${fmt(r.epc)} elem/cycle (scratchpad)`],
    ["B", "Vector FMA", "B1_fma_spm", r => `${fmt(r.fpc)} FLOP/cycle (scratchpad)`],
    ["C", "Dot product", "C1_dot", r => `${fmt(r.fpc)} FLOP/cycle (${r.cfg})`],
    ["D", "GEMM, vector forms", "D1_gemm", r => `${fmt(r.fpc)} FLOP/cycle (${r.pt.form} n=${r.pt.n})`],
    ["E", "STREAM-inspired bandwidth", "E1_stream_spm", r => `${fmt(B(r, "scratchpad")[2], 2)} B/cycle (${r.name})`],
    ["F", "Stencil 1-D / 2-D", "F1_stencil1d", r => `${fmt(r.fpc)} FLOP/cycle (${r.cfg})`]];
  const rows = rowsDef.map(([b, n, e, f]) => { const rs = S1.filter(r => r.exp === e); const best = rs.sort((a, b) => b.fpc - a.fpc || b.epc - a.epc)[0];
    return [b, n, stat(best ? "VALID" : "NOT_RUN"), best ? f(best) : "–"]; });
  rows.push(["D", "GEMM on a tensor engine", stat("NOT_RUN"), "no tensor engine in the tile"]);
  rows.push(["F", "Sparse matrix-vector", stat("NOT_RUN"), "no gather (indexed) loads in the LSU"]);
  rows.push(["–", "FPGA measurement", stat("NOT_RUN"), "no board attached"]);
  rows.push(["–", "Energy efficiency", stat("NOT_RUN"), "no defensible power figure"]);
  return tableHTML([{h: "ID"}, {h: "Benchmark"}, {h: "Status", raw: 1}, {h: "Best measured"}], rows);
}

R.compute = el => {
  const ks = [
    ["FADD", one("A1_vadd_spm", r => r.pt.vl === 4096)], ["FMUL (scale)", one("E1_stream_spm", r => r.pt.op === "FMUL")],
    ["FMADD", one("B1_fma_spm", r => r.pt.vl === 4096)], ["FMADD triad", one("E1_stream_spm", r => r.pt.op === "FMADD")],
    ["dot", one("C1_dot", r => r.cfg === "base" && r.pt.dist === "unit")], ["GEMM axpy n=64", one("D1_gemm", r => r.pt.form === "axpy" && r.pt.n === 64)],
    ["GEMM dot n=64", one("D1_gemm", r => r.pt.form === "dot" && r.pt.n === 64)], ["stencil 1-D", one("F1_stencil1d", r => r.cfg === "base")],
    ["stencil 2-D", one("F2_stencil2d", r => r.cfg === "base")], ["FMADD KERNEL", one("B2_fma_kernel", r => r.cfg === "base" && r.pt.vl === 4096)],
    ["FMADD KERNEL buf.", one("B2_fma_kernel", r => r.cfg === "d8" && r.pt.vl === 4096)]].filter(k => k[1]);
  el.innerHTML = `<h2>Compute throughput</h2><p class="lede">Achieved FLOP per cycle on the base tile (4 lanes, P_peak = 4 × 2 × 1 = 8 FLOP/cycle with the lanes' initiation interval of 1). FLOP convention: add/mul 1, FMA 2, dot product 2n, GEMM 2n³, 3-point stencil 5 and 5-point stencil 9 per point.</p>
  <div class="grid"><div class="card" style="grid-column:1/-1"><h3>FLOP / cycle by kernel</h3><div class="note">Dashed line: P_peak. Hover a bar for the run and its timing source.</div><div id="c-flops"></div>${withTable(
    [{h: "kernel"}, {h: "run"}, {h: "FLOP/cycle", num: 1}, {h: "of P_peak", num: 1}, {h: "MFLOP/s @25 MHz (constraint)", num: 1}, {h: "timing source"}],
    ks.map(([k, r]) => [k, r.id, fmt(r.fpc, 4), pct(r.fpc / r.peak), r.mf25 ? fmt(r.mf25, 2) : "–", r.tsrc]))}</div>
  ${card("FMA retirement (B1, vl 4096)", "From the trace monitor: results of FMA-family operations retired by the array.", fmaTable())}
  ${card("Peak FMA throughput", "P_peak = lanes × 2 × f × FMA_per_lane_per_cycle; the M02 lane has initiation interval 1 (one FMA per lane per cycle).", peakTable(), null, true)}
  </div>`;
  barChart($("#c-flops"), {cats: ks.map(k => k[0]), series: [{name: "FLOP / cycle", values: ks.map(k => k[1].fpc), tips: ks.map(([k, r]) => `<b>${k}</b><br>${fmt(r.fpc, 4)} FLOP/cycle · ${pct(r.fpc / r.peak)} of peak<br><span class='t'>${r.id}<br>${r.tsrc}</span>`)}],
    refs: [{y: 8, label: "P_peak 8 FLOP/cycle"}], valueLabels: true, yLabel: "FLOP / cycle  (dashed: P_peak = 8)", horizontal: true, lpad: 150, max: 9});
};
function fmaTable() { const r = one("B1_fma_spm", r => r.pt.vl === 4096); if (!r) return "";
  return tableHTML([{h: "quantity"}, {h: "value", num: 1}], [["FMA operations retired (trace)", r.fma.toLocaleString("en")], ["PERF[VEC_FLOPS] / 2", (r.flops / 2).toLocaleString("en")],
    ["cycles (CPL_CYCLES)", r.cyc.toLocaleString("en")], ["FMA / cycle", fmt(r.fma / r.cyc, 4)], ["FMA / cycle / lane", fmt(r.fma / r.cyc / r.p.lanes, 4)], ["lane utilisation", pct(r.lu)]]); }
function peakTable() { const rows = []; const seen = new Set();
  for (const r of S1.filter(r => r.exp === "S1_lanes" && r.pt.op === "FMADD" && r.pt.variant === "spm")) { if (seen.has(r.cfg)) continue; seen.add(r.cfg);
    rows.push([r.cfg, r.p.lanes, r.p.dw, fmt(r.peak, 0), fmt(r.fpc, 3), pct(r.fpc / r.peak), r.mf25 ? fmt(r.peak * 25, 0) : "no clock"]); }
  rows.sort((a, b) => a[1] - b[1] || a[2] - b[2]);
  return tableHTML([{h: "config"}, {h: "lanes", num: 1}, {h: "word bits", num: 1}, {h: "P_peak FLOP/cyc", num: 1}, {h: "FMA achieved", num: 1}, {h: "of peak", num: 1}, {h: "P_peak MFLOP/s @25 MHz", num: 1}], rows); }

R.memory = el => {
  const st = ["FMV", "FMUL", "FADD", "FMADD"].map(op => one("E1_stream_spm", r => r.pt.op === op)).filter(Boolean);
  const names = {FMV: "copy", FMUL: "scale", FADD: "add", FMADD: "triad"};
  const dirs = ["h2s", "s2h", "s2s", "h2h"];
  const dl = {h2s: "host→SPM", s2h: "SPM→host", s2s: "SPM→SPM", h2h: "host→host"};
  el.innerHTML = `<h2>Memory bandwidth</h2><p class="lede">Each chart names its memory boundary. Scratchpad (LSU) and DMA bandwidths are never mixed on one axis. STREAM-inspired, not official STREAM: single command per kernel, FP32, STREAM byte convention (copy/scale 8 B, add/triad 12 B per element).</p>
  <div class="grid">
   <div class="card" style="grid-column:1/-1"><h3>Scratchpad boundary · STREAM-inspired (E1)</h3><div class="note">4096-element arrays resident in the scratchpad; one VEC command each. Dashed line: LSU-port peak, 4 ports × 4 B = 16 B/cycle.</div><div id="c-st"></div>${withTable([{h: "kernel"}, {h: "B/cycle", num: 1}, {h: "elem/cycle", num: 1}, {h: "run"}], st.map(r => [names[r.pt.op], fmt(B(r, "scratchpad")[2], 3), fmt(r.epc, 3), r.id]))}</div>
   <div class="card" style="grid-column:1/-1"><h3>DMA boundary · copy bandwidth (E3)</h3><div class="note">16 KiB per command, bytes delivered per cycle; simple engine vs 8-deep buffered engine. Dashed: 32-bit fabric port, 4 B/cycle.</div><div id="c-dma"></div></div>
   <div class="card" style="grid-column:1/-1"><h3>DMA boundary · transfer size (S4b)</h3><div class="note">Host → scratchpad. Fixed command cost dominates small transfers (Hockney fit in Configuration scaling).</div><div id="c-dsize"></div></div>
  </div>`;
  barChart($("#c-st"), {cats: st.map(r => names[r.pt.op]), series: [{name: "B / cycle", values: st.map(r => B(r, "scratchpad")[2])}], refs: [{y: 16, label: ""}], valueLabels: true, yLabel: "useful bytes / cycle", horizontal: true, lpad: 90, max: 20,
    rightLabels: st.map(r => `${pct(B(r, "scratchpad")[2] / 16)} of peak`)});
  const ser = ["base", "d8"].map((c, j) => ({name: c === "base" ? "simple engine" : "buffered, depth 8", color: SER[j * 2],
    values: dirs.map(d => { const r = one("E3_dma_copy", r => r.cfg === c && r.pt.dir === d); return r ? 16384 / r.cyc : null; })}));
  barChart($("#c-dma"), {cats: dirs.map(d => dl[d]), series: ser, refs: [{y: 4, label: "fabric port 4 B/cycle"}], valueLabels: true, yLabel: "bytes delivered / cycle", height: 280});
  const sz = ["base", "d8"].map((c, j) => ({name: c === "base" ? "simple engine" : "buffered, depth 8", color: SER[j * 2], shape: j ? "square" : "circle",
    points: pick("S4b_dma_size", r => r.cfg === c).map(r => ({x: r.pt.bytes, y: r.pt.bytes / r.cyc, tip: `<b>${r.pt.bytes} B</b> ${c}<br>${fmt(r.pt.bytes / r.cyc, 3)} B/cycle · ${r.cyc} cycles`}))}));
  sz.forEach(s => s.endLabel = s.name);
  xyChart($("#c-dsize"), {series: sz, xlog: true, xLabel: "transfer size (bytes)", yLabel: "bytes / cycle", height: 300, rpad: 130});
};

R.lanes = el => {
  const ls = AN.lane_scaling;
  const defs = [["FMADD|spm|DW32", "FMADD · scratchpad · 32-bit", "circle"], ["FADD|spm|DW32", "FADD · scratchpad · 32-bit", "square"],
    ["FMADD|spm|DW128", "FMADD · scratchpad · 128-bit", "tri"], ["FMADD|kernel|DW32", "FMADD · end to end · 32-bit", "circle"]];
  const ser = defs.filter(d => ls[d[0]]).map(([k, n, sh], i) => ({name: n, shape: sh, endLabel: fmt(ls[k].rows.at(-1).elem_per_cycle, 2),
    points: ls[k].rows.map(r => ({x: r.lanes, y: r.elem_per_cycle, tip: `<b>${r.config}</b> · ${n}<br>${fmt(r.elem_per_cycle, 3)} elem/cycle<br>lane utilisation ${pct(r.lane_utilisation)}<br>LSU ports ${r.lsu_ports} · bound ${fmt(r.lsu_bound, 2)}<br>efficiency vs ${ls[k].reference}: ${pct(r.efficiency_vs_ref)}`}))}));
  const rows = [];
  for (const [k] of defs) if (ls[k]) for (const r of ls[k].rows) rows.push([k.replace(/\|/g, " · "), r.config, r.lanes, r.lsu_ports, fmt(r.elem_per_cycle, 3), fmt(r.lsu_bound, 3), pct(r.lane_utilisation), pct(r.efficiency_vs_ref)]);
  el.innerHTML = `<h2>Lane utilisation</h2><p class="lede">Lane utilisation = PERF[VEC_ELEMS] / (lanes × PERF[VEC_ACTIVE]). With 32-bit scratchpad words at most 4 LSU ports exist, so more than 4 lanes adds no throughput. 128-bit words lift the port bound.</p>
  <div class="grid"><div class="card" style="grid-column:1/-1"><h3>Elements per cycle vs lanes (S1, vl 1024)</h3><div class="note">Dashed diagonal: array peak, one element per lane per cycle.</div><div id="c-lanes"></div>${withTable(
    [{h: "series"}, {h: "config"}, {h: "lanes", num: 1}, {h: "LSU ports", num: 1}, {h: "elem/cyc", num: 1}, {h: "LSU bound", num: 1}, {h: "lane util.", num: 1}, {h: "scaling eff.", num: 1}], rows)}</div>
  ${card("Utilisation by kernel (base)", "Issue occupancy = fraction of vector-active cycles in which a beat entered the lanes.", tableHTML([{h: "kernel"}, {h: "lane util.", num: 1}, {h: "issue occupancy", num: 1}, {h: "vector-active cycles", num: 1}],
    [["FADD (A1)", one("A1_vadd_spm", r => r.pt.vl === 4096)], ["FMADD (B1)", one("B1_fma_spm", r => r.pt.vl === 4096)], ["copy (E1)", one("E1_stream_spm", r => r.pt.op === "FMV")],
     ["dot (C1)", one("C1_dot", r => r.cfg === "base" && r.pt.dist === "unit")], ["GEMM axpy n=64", one("D1_gemm", r => r.pt.form === "axpy" && r.pt.n === 64)]].filter(x => x[1]).map(([k, r]) => [k, pct(r.lu), pct(r.occ), r.va.toLocaleString("en")])), null, true)}</div>`;
  xyChart($("#c-lanes"), {series: ser, xlog: true, ylog: true, xLabel: "FP32 lanes", yLabel: "elements / cycle", height: 360,
    roofs: [{f: x => x, cls: "ref", name: "array peak: lanes elements/cycle", label: "array peak", lx: 16, dy: 14, anchor: "end", dx: -4}], yExtra: [16, 0.04], xmin: 1, xmax: 16});
};

R.stalls = el => {
  const ks = [["FADD", one("A1_vadd_spm", r => r.pt.vl === 4096)], ["FMADD", one("B1_fma_spm", r => r.pt.vl === 4096)],
    ["copy", one("E1_stream_spm", r => r.pt.op === "FMV")], ["scale", one("E1_stream_spm", r => r.pt.op === "FMUL")],
    ["triad", one("E1_stream_spm", r => r.pt.op === "FMADD")], ["dot", one("C1_dot", r => r.cfg === "base" && r.pt.dist === "unit")],
    ["GEMM axpy n=64", one("D1_gemm", r => r.pt.form === "axpy" && r.pt.n === 64)], ["GEMM dot n=64", one("D1_gemm", r => r.pt.form === "dot" && r.pt.n === 64)],
    ["stencil 1-D", one("F1_stencil1d", r => r.cfg === "base")], ["stencil 2-D", one("F2_stencil2d", r => r.cfg === "base")]].filter(k => k[1]);
  const lab = ["beat issued", "operand starvation", "array back-pressure"];
  const ser = lab.map((n, j) => ({name: n, values: ks.map(([, r]) => r.stall[j] / r.va), tips: ks.map(([k, r]) => `<b>${k}</b> · ${n}<br>${r.stall[j].toLocaleString("en")} of ${r.va.toLocaleString("en")} vector-active cycles (${pct(r.stall[j] / r.va)})`)}));
  const mc = S1.filter(r => ["D1_gemm", "F1_stencil1d", "F2_stencil2d", "D2_gemm_lanes"].includes(r.exp));
  el.innerHTML = `<h2>Pipeline stalls</h2><p class="lede">Every vector-active cycle is exactly one of: a beat issued to the lanes, operand starvation (the LSU has no complete operand beat: scratchpad port bandwidth or latency), or array back-pressure. The three parts are cross-checked to sum to PERF[VEC_ACTIVE] in every run. Trace-derived from RTL handshakes.</p>
  <div class="grid"><div class="card" style="grid-column:1/-1"><h3>Where the vector-active cycles go (base tile)</h3><div id="c-stall"></div>${withTable([{h: "kernel"}, {h: "issue", num: 1}, {h: "starvation", num: 1}, {h: "back-pressure", num: 1}, {h: "VEC_ACTIVE", num: 1}],
    ks.map(([k, r]) => [k, r.stall[0], r.stall[1], r.stall[2], r.va]))}</div>
  ${card("Queue and command-path stalls (multi-command workloads)", "Tile busy vs host end-to-end: when the tile is idle between commands, the host command path (9 register writes per command) is the limit.",
    tableHTML([{h: "run"}, {h: "commands", num: 1}, {h: "host e2e cycles", num: 1}, {h: "tile busy", num: 1}, {h: "busy share", num: 1}, {h: "CMDQ full", num: 1}, {h: "CPLQ stall", num: 1}, {h: "hazard stall", num: 1}],
      mc.map(r => [r.id.split("__")[0] + " " + r.id.split("__")[1], r.ncmd, r.e2e, r.busy, pct(r.busy / r.e2e), r.q[0], r.q[1], r.q[2]])))}</div>`;
  barChart($("#c-stall"), {cats: ks.map(k => k[0]), series: ser, stacked: true, horizontal: true, percent: true, max: 1, yLabel: "share of PERF[VEC_ACTIVE]", lpad: 120,
    rightLabels: ks.map(([, r]) => `lanes ${pct(r.lu)}`)});
};

R.dma = el => {
  const order = ["base", "d2", "d4", "d8", "d16", "d32", "x4", "x4_d8", "x8", "x8_d8", "l16_w128", "l16_w128_d8"];
  const dr = order.map(c => one("S4_dma_depth", r => r.cfg === c)).filter(Boolean);
  const kr = order.map(c => one("S4c_kernel_dma", r => r.cfg === c)).filter(Boolean);
  const lab = r => `${r.cfg} (${r.p.dma ? "buffered " + r.p.dma : "simple"}, latency ${r.p.lat}${r.p.dw !== 32 ? ", " + r.p.dw + "-bit" : ""})`;
  const stalls = dr.filter(r => r.dma.rs > 0);
  el.innerHTML = `<h2>DMA activity</h2><p class="lede">The DMA engine is the path between host-visible memory and the scratchpad. Mean outstanding = Σ outstanding transactions / DMA-active cycles (trace). The DataFabric crossbar accepts at most one outstanding transaction per master port, so each word costs a full request–response round trip. ${stalls.length ? `Fabric request-stall cycles occur only in ${stalls.map(r => r.cfg + " (" + r.dma.rs.toLocaleString("en") + ")").join(", ")}: the buffered engine's extra requests wait for the outstanding one.` : "No fabric request-stall cycles occurred."}</p>
  <div class="grid"><div class="card" style="grid-column:1/-1"><h3>16 KiB host → scratchpad: bytes per cycle (S4)</h3><div class="note">Simple engine = one transaction in flight. Latency = host SRAM read latency in cycles. 128-bit configurations have a 16 B/cycle port.</div><div id="c-dd"></div>${withTable(
    [{h: "config"}, {h: "engine"}, {h: "host latency", num: 1}, {h: "word bits", num: 1}, {h: "cycles", num: 1}, {h: "B/cycle", num: 1}, {h: "mean outstanding", num: 1}, {h: "fabric req stalls", num: 1}],
    dr.map(r => [r.cfg, r.p.dma ? "buffered " + r.p.dma : "simple", r.p.lat, r.p.dw, r.cyc, fmt(16384 / r.cyc, 3), fmt(r.dma.out, 3), r.dma.rs]))}</div>
  <div class="card" style="grid-column:1/-1"><h3>End-to-end FMA (KERNEL, vl 1024) vs DMA path (S4c)</h3><div class="note">FLOP per cycle of the complete host → scratchpad → compute → host command.</div><div id="c-dk"></div></div></div>`;
  barChart($("#c-dd"), {cats: dr.map(lab), series: [{name: "B/cycle", values: dr.map(r => 16384 / r.cyc), tips: dr.map(r => `<b>${r.cfg}</b><br>${fmt(16384 / r.cyc, 3)} B/cycle · ${r.cyc} cycles<br>mean outstanding ${fmt(r.dma.out, 2)}<br>port peak ${r.p.dw / 8} B/cycle`)}],
    valueLabels: true, yLabel: "bytes / cycle", horizontal: true, lpad: 270, rightLabels: dr.map(r => `${pct(16384 / r.cyc / (r.p.dw / 8))} of port`)});
  barChart($("#c-dk"), {cats: kr.map(lab), series: [{name: "FLOP/cycle", color: "--s3", values: kr.map(r => r.fpc), tips: kr.map(r => `<b>${r.cfg}</b><br>${fmt(r.fpc, 4)} FLOP/cycle · ${r.cyc} cycles<br>DMA active ${r.dma.act} cycles, vector ${r.va}`)}],
    valueLabels: true, vd: 3, yLabel: "FLOP / cycle", horizontal: true, lpad: 270});
};

R.banks = el => {
  const order = ["b1", "b2", "base", "b8"];
  const s2 = op => [0, 1].map((sg, j) => ({name: sg ? "staggered by one word" : "aligned bases", color: SER[j * 2],
    values: order.map(c => (one("S2_banks", r => r.cfg === c && r.pt.op === op && r.pt.stagger_words === sg) || {}).epc ?? null),
    tips: order.map(c => { const r = one("S2_banks", r => r.cfg === c && r.pt.op === op && r.pt.stagger_words === sg); return r ? `<b>${c}</b> ${op} ${sg ? "staggered" : "aligned"}<br>${fmt(r.epc, 3)} elem/cycle<br>${r.spm.conf.toLocaleString("en")} conflicts (${fmt(r.spm.cpa, 3)} per access)` : ""; })}));
  const cont = S1.filter(r => r.exp === "S5_contention");
  const iso = c => one("S5_contention", r => r.cfg === c && r.pt.contention === "none" && r.pt.stagger_words === 0);
  el.innerHTML = `<h2>SRAM bank conflicts</h2><p class="lede">The scratchpad has NUM_BANKS single-port (1RW) banks, word-interleaved; each bank serves one access per cycle and round-robin arbitrates the LSU ports, the DMA port and the host window. PERF[SPM_CONFLICTS] counts port-cycles lost to arbitration; the per-port split comes from the trace.</p>
  <div class="grid"><div class="card" style="grid-column:1/-1"><h3>FMADD, banks × operand placement (S2)</h3><div class="note">4 lanes, 4 LSU ports, vl 1024. Dashed: LSU bound 1.0.</div><div id="c-b1"></div></div>
  <div class="card" style="grid-column:1/-1"><h3>FADD, banks × operand placement (S2)</h3><div class="note">Dashed: LSU bound 1.33.</div><div id="c-b2"></div></div>
  <div class="card" style="grid-column:1/-1"><h3>Contention patterns (S5): VEC FMADD with concurrent DMA and host traffic</h3><div class="note">Slowdown = cycles / cycles of the isolated aligned run on the same configuration.</div>${tableHTML(
    [{h: "config"}, {h: "pattern"}, {h: "layout"}, {h: "cycles", num: 1}, {h: "slowdown", num: 1}, {h: "conflicts", num: 1}, {h: "LSU / DMA / host", num: 1}, {h: "DMA–vector overlap", num: 1}],
    cont.sort((a, b) => a.cfg.localeCompare(b.cfg) || a.pt.contention.localeCompare(b.pt.contention) || a.pt.stagger_words - b.pt.stagger_words)
      .map(r => [r.cfg, r.pt.contention, r.pt.stagger_words ? "staggered" : "aligned", r.cyc, iso(r.cfg) ? fmt(r.cyc / iso(r.cfg).cyc, 3) : "–", r.spm.conf, `${r.spm.lsuc} / ${r.spm.dmac} / ${r.spm.hostc}`, r.dma.ovl]))}</div>
  ${card("Bank accesses per bank (FMADD, base, vl 4096)", "Accesses performed by each bank during the command, and the share of vector-active cycles each bank was busy.", (() => { const r = one("B1_fma_spm", r => r.pt.vl === 4096); return r ? tableHTML([{h: "bank"}, {h: "accesses", num: 1}, {h: "busy share", num: 1}], r.spm.banks.map((b, i) => [i, b.toLocaleString("en"), pct(r.spm.bu[i])])) : ""; })())}</div>`;
  barChart($("#c-b1"), {cats: ["1 bank", "2 banks", "4 (base)", "8 banks"], series: s2("FMADD"), refs: [{y: 1, label: ""}], valueLabels: true, yLabel: "elements / cycle", height: 280});
  barChart($("#c-b2"), {cats: ["1 bank", "2 banks", "4 (base)", "8 banks"], series: s2("FADD"), refs: [{y: 4 / 3, label: ""}], valueLabels: true, yLabel: "elements / cycle", height: 280});
};

R.roofline = el => {
  const rf = AN.roofline, lv = Object.keys(rf.levels);
  el.innerHTML = `<h2>Roofline</h2><p class="lede">P_roofline = min(P_peak, AI × B_sustained), with B_sustained <b>measured</b> at the selected boundary (STREAM-inspired runs) — never a datasheet number, and never mixed across boundaries. AI uses the useful bytes the algorithm must move across that boundary.</p>
  <div class="card"><h3>Boundary <select id="lvl">${lv.map(l => `<option>${esc(l)}</option>`).join("")}</select></h3><div class="note" id="rf-note"></div><div id="c-rf"></div><div id="rf-tbl"></div></div>`;
  const draw = () => {
    const L = rf.levels[$("#lvl").value], peak = rf.peak_flop_per_cycle, bw = L.sustained_bytes_per_cycle;
    $("#rf-note").innerHTML = `Measured sustained bandwidth ${fmt(bw, 3)} B/cycle (${esc(L.bandwidth_source)}). Port peak ${fmt(L.port_peak_bytes_per_cycle, 0)} B/cycle (sustained = ${pct(bw / L.port_peak_bytes_per_cycle)} of it${L.port_peak_bytes_per_cycle > bw * 1.05 ? ", shown dashed" : ""}). Ridge AI ${fmt(L.ridge_ai, 3)} FLOP/B. Base tile, P_peak ${peak} FLOP/cycle. RTL-simulation cycles; bandwidth MEASURED, not modelled.`;
    const grp = p => p.experiment.startsWith("C") || p.label.includes("dot") ? 1 : (["D", "F"].includes(p.benchmark) ? 2 : 0);
    const names = ["single elementwise command (A, B, E)", "reduction (C, D dot form)", "multi-command (D axpy, F)"];
    const shapes = ["circle", "square", "tri"];
    const ser = names.map((n, i) => ({name: n, line: false, shape: shapes[i], color: SER[i],
      points: L.points.filter(p => grp(p) === i).map(p => ({x: p.ai, y: p.flop_per_cycle, tip: `<b>${esc(p.label)}</b><br>AI ${fmt(p.ai, 4)} FLOP/B · ${fmt(p.flop_per_cycle, 4)} FLOP/cycle<br>roofline ${fmt(p.roofline_bound, 4)} · ${pct(p.fraction_of_roofline)} of it<br><span class='t'>${esc(p.run_id)}</span>`}))})).filter(s => s.points.length);
    const xmin = Math.min(...L.points.map(p => p.ai), 0.05) / 2, xmax = Math.max(L.ridge_ai * 4, ...L.points.map(p => p.ai * 2));
    const showPort = L.port_peak_bytes_per_cycle > bw * 1.05;
    xyChart($("#c-rf"), {series: ser, xlog: true, ylog: true, xLabel: "arithmetic intensity (useful FLOP / useful byte)", yLabel: "FLOP / cycle", height: 400, rpad: 150,
      xmin, xmax, yExtra: [peak * 1.5, Math.min(...L.points.map(p => p.flop_per_cycle)) / 2],
      roofs: [{f: x => Math.min(peak, x * bw), name: `roofline: min(${peak}, AI × ${fmt(bw, 3)})`, label: `P_peak ${peak}`, lx: xmax, dy: -6, anchor: "end", dx: 0},
              ...(showPort ? [{f: x => Math.min(peak, x * L.port_peak_bytes_per_cycle), cls: "ref", name: `port peak ${L.port_peak_bytes_per_cycle} B/cycle (not sustained)`, label: `port peak ${L.port_peak_bytes_per_cycle} B/cycle (not reached)`, lx: peak / L.port_peak_bytes_per_cycle / 4, dy: -8, anchor: "end", dx: -4}] : [])]});
    $("#rf-tbl").innerHTML = withTable([{h: "kernel"}, {h: "AI", num: 1}, {h: "FLOP/cycle", num: 1}, {h: "roofline", num: 1}, {h: "of roofline", num: 1}, {h: "run"}],
      L.points.sort((a, b) => a.ai - b.ai).map(p => [p.label, fmt(p.ai, 4), fmt(p.flop_per_cycle, 4), fmt(p.roofline_bound, 4), pct(p.fraction_of_roofline), p.run_id]));
  };
  $("#lvl").onchange = draw; draw();
};

R.scaling = el => {
  const hk = AN.hockney;
  const vl = ["FADD", "FMADD"].map((op, i) => ({name: op + " (scratchpad)", shape: i ? "circle" : "square", color: SER[i ? 0 : 1],
    points: pick("S3_vl", r => r.pt.op === op).map(r => ({x: r.pt.vl, y: r.epc, tip: `<b>${op} vl ${r.pt.vl}</b><br>${r.cyc} cycles · ${fmt(r.epc, 3)} elem/cycle`}))}));
  const pl = ["p1", "p2", "base", "rl2", "rl4"];
  el.innerHTML = `<h2>Configuration scaling</h2><p class="lede">Arithmetic scaling (scratchpad-resident, one VEC command) and end-to-end scaling (host-resident, KERNEL) are reported separately. Scaling efficiency = (P/P_ref)/(units/units_ref).</p>
  <div class="grid"><div class="card" style="grid-column:1/-1"><h3>Vector length (S3, base)</h3><div class="note">Dotted: LSU bounds (FADD 1.33, FMADD 1.0 elements/cycle). Short vectors pay the fixed command latency.</div><div id="c-vl"></div></div>
  ${card("Hockney fits T(n) = t0 + n / r∞", "r∞ = asymptotic rate; n½ = length reaching half of it. Least squares on n ≥ 64.",
    tableHTML([{h: "series"}, {h: "r∞ per cycle", num: 1}, {h: "t0 cycles", num: 1}, {h: "n½", num: 1}, {h: "unit"}], Object.entries(hk).map(([k, v]) => [k, fmt(v.r_inf, 4), fmt(v.t0, 1), fmt(v.n_half, 1), v.unit])))}
  ${card("LSU ports and scratchpad latency (S6)", "4 lanes, vl 1024.", tableHTML([{h: "config"}, {h: "LSU ports", num: 1}, {h: "read latency", num: 1}, {h: "FADD elem/cyc", num: 1}, {h: "FMADD elem/cyc", num: 1}],
    pl.map(c => { const a = one("S6_ports_latency", r => r.cfg === c && r.pt.op === "FADD"), b = one("S6_ports_latency", r => r.cfg === c && r.pt.op === "FMADD");
      return a && b ? [c, Math.min(4, a.p.ports), a.p.rl, fmt(a.epc, 3), fmt(b.epc, 3)] : null; }).filter(Boolean)))}
  ${card("Lane-count scaling efficiency (S1)", "Reference = smallest configuration of each series.", tableHTML([{h: "series"}, {h: "lanes 1→16 speed-up", num: 1}, {h: "efficiency at max lanes", num: 1}],
    Object.values(AN.lane_scaling).map(d => [`${d.op} · ${d.variant} · ${d.family}`, fmt(d.rows.at(-1).speedup_vs_ref, 2) + "×", pct(d.rows.at(-1).efficiency_vs_ref)])))}
  ${card("Multi-command scaling: GEMM axpy n=32 across lanes (D2)", "End to end incl. host command submission.", tableHTML([{h: "config"}, {h: "lanes", num: 1}, {h: "cycles", num: 1}, {h: "FLOP/cyc", num: 1}, {h: "tile busy share", num: 1}],
    pick("D2_gemm_lanes").sort((a, b) => a.p.lanes - b.p.lanes || a.p.dw - b.p.dw).map(r => [r.cfg, r.p.lanes, r.cyc, fmt(r.fpc, 3), pct(r.busy / r.e2e)])))}</div>`;
  xyChart($("#c-vl"), {series: vl, xlog: true, xLabel: "vector length (elements)", yLabel: "elements / cycle", height: 320, hrefs: [{y: 4 / 3, label: "FADD bound"}, {y: 1, label: "FMADD bound"}], rpad: 110});
};

R.fpga = el => {
  const core = S1.filter(r => ["A1_vadd_spm", "A2_vadd_kernel", "B1_fma_spm", "B2_fma_kernel", "E3_dma_copy"].includes(r.exp));
  const sy = D.synth;
  el.innerHTML = `<h2>Simulation vs FPGA</h2><div class="warnbox"><b>FPGA results: NOT RUN.</b> No FPGA board is attached to this environment, no bitstream was programmed, and no counter was read from hardware. No synthetic hardware measurement is shown. The FPGA columns stay empty until a board run fills them.</div><p></p>
  <div class="grid"><div class="card" style="grid-column:1/-1"><h3>Core workloads: RTL simulation vs FPGA</h3>${tableHTML([{h: "run"}, {h: "RTL simulation cycles", num: 1}, {h: "FPGA cycles", num: 1}, {h: "discrepancy"}, {h: "FPGA clock"}],
    core.map(r => [r.id.split("__")[0] + " · " + r.id.split("__")[1], r.cyc.toLocaleString("en"), "NOT RUN", "n/a", "not measured"]))}</div>
  ${card("Place-and-route estimates (Module 08, labelled)", "Yosys 0.33 + nextpnr-ecp5 0.11.1, ULX3S LFE5U-85F, 25 MHz constraint. Fmax = tool estimate, not a measured clock.", `<pre class="mono" style="white-space:pre-wrap;max-height:380px;overflow:auto">${esc(JSON.stringify(sy, null, 1))}</pre>`)}
  ${card("Board procedure (not performed)", "", `<ol style="margin:0;padding-left:18px;color:var(--ink-2)"><li>Build a functional harness bitstream (the M08 harness is timing-only).</li><li>Run the archived command programs from SilicaFlux-V firmware; read PERF[0..23] and CPL_CYCLES.</li><li>Record the measured clock; diff every counter against the run record; report discrepancies.</li></ol>`)}</div>`;
};

R.correct = el => {
  const c = AN.correctness;
  const ops = ["FADD", "FSUB", "FMUL", "FMADD", "FMSUB", "FNMSUB", "FNMADD"], rms = [0, 1, 2, 3], rmn = ["RNE", "RTZ", "RDN", "RUP"], dists = ["special_mix", "full_range"];
  let grid = `<div class="cellgrid" style="grid-template-columns: 90px repeat(${rms.length * dists.length}, minmax(44px,1fr))"><div class="cell h"></div>`;
  for (const d of dists) for (const m of rmn) grid += `<div class="cell h">${m}<br>${d === "special_mix" ? "special" : "full"}</div>`;
  for (const op of ops) { grid += `<div class="cell h" style="text-align:right">${op}</div>`;
    for (const d of dists) for (const m of rms) { const r = RUNS.find(r => r.exp === "X1_ieee" && r.pt.op === op && r.pt.rm === m && r.pt.dist === d);
      const ok = r && r.st === "VALID" && r.corr.mis === 0 && r.corr.fl;
      grid += `<div class="cell ${ok ? "ok" : "bad"}" data-tip="${r && r.corr ? esc(`<b>${op} ${rmn[m]} ${d}</b><br>${r.corr.words} words, ${r.corr.mis} mismatches<br>NaN ${r.corr.nan} · Inf ${r.corr.inf} · subnormal ${r.corr.sub}<br>flags hw ${r.corr.flhw} (match: ${r.corr.fl})`) : "not run"}">${ok ? "✓" : "✗"}</div>`; } }
  grid += "</div>";
  const dots = S1.filter(r => r.exp === "C1_dot" && r.pt.dist === "unit").sort((a, b) => a.p.lanes - b.p.lanes);
  const nDot = dots.length ? dots[0].pt.vl : "–";
  el.innerHTML = `<h2>Numerical correctness</h2><p class="lede">A fast but incorrect result is a failed benchmark. Elementwise IEEE results are compared <b>bitwise</b> (flags included; NaN must be the canonical 0x7FC00000) with an independent reference that runs on the host CPU's IEEE hardware and shares no code with the RTL or the Module 08 model. Reductions are compared bitwise with the architecturally defined order and, separately, against the exact sum with an a-priori error bound.</p>
  <div class="kpis"><div class="kpi"><div class="k">Words compared bitwise</div><div class="v">${c.bitwise_words.toLocaleString("en")}</div><div class="s">${c.bitwise_mismatches} mismatches</div></div>
  <div class="kpi"><div class="k">Exception flags</div><div class="v">${c.flags_matched}/${c.flags_compared}</div><div class="s">commands with identical FFLAGS</div></div>
  <div class="kpi"><div class="k">Special values checked</div><div class="v">${(c.nan_words + c.inf_words + c.subnormal_words).toLocaleString("en")}</div><div class="s">NaN ${c.nan_words} · Inf ${c.inf_words} · subnormal ${c.subnormal_words}</div></div>
  <div class="kpi"><div class="k">Within error bound</div><div class="v">${c.tolerance_passed}/${c.tolerance_checks}</div><div class="s">dot, GEMM, stencil vs float64 / exact</div></div>
  <div class="kpi"><div class="k">Counter cross-checks</div><div class="v">${c.counter_cross_checks.toLocaleString("en")}</div><div class="s">${c.counter_cross_checks_failed} failed · ${c.csv_trace_recounts} CSV recounts</div></div></div>
  <div class="grid"><div class="card" style="grid-column:1/-1"><h3>IEEE-754 at speed (X1): operation × rounding mode × data</h3><div class="note">512 elements per cell, one VEC command; ✓ = every word bit-identical and FFLAGS identical.</div>${grid}</div>
  <div class="card" style="grid-column:1/-1"><h3>Dot product accuracy, signed uniform data, n = ${nDot} (C1, seed 1)</h3><div class="note">Absolute error vs the exact sum (log scale). Hardware order = pairwise tree over the lanes of each beat + sequential FP32 accumulation over beats; the reference replays that order bit-exactly. Different orders give different, equally legitimate FP32 results.</div><div id="c-dot"></div>${withTable(
    [{h: "config"}, {h: "exact", num: 1}, {h: "|err| hardware", num: 1}, {h: "|err| sequential FP32", num: 1}, {h: "|err| numpy float32", num: 1}, {h: "err / bound", num: 1}],
    dots.map(r => [r.cfg, r.corr.orders.exact.toExponential(6), r.corr.orders.abs_err.hardware.toExponential(2), r.corr.orders.abs_err.sequential_fp32.toExponential(2), r.corr.orders.abs_err.numpy_float32.toExponential(2), fmt(r.corr.tol.ratio, 3)]))}</div></div>`;
  bindTips(el);
  const errs = [["hardware order", r => r.corr.orders.abs_err.hardware, "circle"], ["sequential FP32 loop", r => r.corr.orders.abs_err.sequential_fp32, "square"],
    ["numpy float32 sum", r => r.corr.orders.abs_err.numpy_float32, "tri"]];
  xyChart($("#c-dot"), {series: errs.map(([n, f, sh], i) => ({name: n, shape: sh, color: SER[i],
      points: dots.map(r => ({x: r.p.lanes, y: Math.max(f(r), 1e-12), tip: `<b>${r.cfg}</b> · ${n}<br>|err| = ${f(r).toExponential(3)}<br>exact ${r.corr.orders.exact.toExponential(6)}`}))})),
    xlog: true, ylog: true, xLabel: "lanes (tree width of the hardware order)", yLabel: "|error| vs exact sum", height: 300, rpad: 40});
};

R.prov = el => {
  const pv = AN.provenance;
  el.innerHTML = `<h2>Experiment provenance</h2><p class="lede">Every run record carries its dataset hashes, hardware parameters, RTL and testbench hashes, tool versions, timing source and a reproduction command. <code>python3 scripts/bench.py reproduce &lt;run_id&gt;</code> re-executes a run and compares cycles, all 24 counters, outputs and datasets.</p>
  <div class="grid">${card("Sources", "", tableHTML([{h: "item"}, {h: "value"}], [["tile RTL SHA-256 (" + pv.rtl.n_rtl_files + " files)", pv.rtl.tile_rtl_sha256], ["benchmark testbench SHA-256", pv.rtl.testbench_sha256],
    ["Module 08 archive", pv.m08_zip_repo_path], ["Module 08 archive SHA-256", pv.m08_zip_sha256], ["vendored M08 matches its manifest", String(pv.m08_manifest_verified)],
    ["Module 10 suite SHA-256", pv.suite_sha256], ["datasets", pv.datasets + " files (data/MANIFEST.json)"], ["generated (UTC)", pv.environment.utc]].map(r => [r[0], `<code>${esc(r[1])}</code>`]).map(r => [r[0], r[1]]), {}).replace(/&lt;code&gt;|&lt;\/code&gt;/g, ""))}
  ${card("Tools and machine", "", tableHTML([{h: "tool"}, {h: "version"}], Object.entries(pv.environment.tools).concat(Object.entries(pv.environment.machine))))}
  ${card("Clock policy", "", `<p class="muted" style="margin:0">${esc(pv.clocks.policy)}</p>` + tableHTML([{h: "clock"}, {h: "Hz", num: 1}, {h: "kind"}, {h: "applies to"}], Object.entries(pv.clocks.clocks).map(([k, v]) => [k, v.hz.toLocaleString("en"), v.kind, v.applies_to.join(", ")])))}
  ${card("Power policy", "", `<p class="muted" style="margin:0"><b>${esc(pv.power.status)}</b> — ${esc(pv.power.reason)}</p>`)}
  <div class="card" style="grid-column:1/-1"><h3>All runs</h3><input class="search" id="q" placeholder="Filter by run id, experiment, config or status"><div id="runs"></div></div></div>`;
  const draw = () => { const q = ($("#q").value || "").toLowerCase();
    const rows = RUNS.filter(r => !q || (r.id + r.st + r.exp + r.cfg).toLowerCase().includes(q)).slice(0, 400);
    $("#runs").innerHTML = tableHTML([{h: "run id"}, {h: "status", raw: 1}, {h: "cycles", num: 1}, {h: "timing source"}, {h: "checks", num: 1}, {h: "reproduce"}],
      rows.map(r => [r.id, stat(r.st), r.cyc ?? "–", r.tsrc || r.why, r.xc ? `${r.xc[0] - r.xc[1]}/${r.xc[0]}${r.xc[2] ? " +csv" : ""}` : "–", r.rep]), {maxh: 520}); };
  $("#q").oninput = draw; draw();
};

chips();
const h0 = (location.hash || "").slice(1); if (VIEWS.some(v => v[0] === h0)) current = h0;
redraw();
matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change", () => { if (!document.documentElement.getAttribute("data-theme")) redraw(); });
let rz = null, lastW = innerWidth;
addEventListener("resize", () => { clearTimeout(rz); rz = setTimeout(() => { if (Math.abs(innerWidth - lastW) > 40) { lastW = innerWidth; const y = scrollY; redraw(); scrollTo(0, y); } }, 200); });
</script>
</body>
</html>
"""


if __name__ == "__main__":
    main()
