#!/usr/bin/env python3
"""Self-test of the Module 10 independent reference kernels (kernels/ref/sfref.c).

Two independent implementations must agree bit for bit, flags included:
  * sfref.c        -- host x86-64 IEEE hardware arithmetic (SSE + FMA3) through <fenv.h> (this module)
  * fp32_model.py  -- Module 08's pure-Python integer model, itself validated against Berkeley SoftFloat-3e
                      (RISC-V specialisation) on 600 000 + 166 140 vectors (M08 reports/model_selftest.md)
Covered: FMV FADD FSUB FMUL FMADD FMSUB FNMSUB FNMADD x RNE RTZ RDN RUP x 5 operand distributions, and the
Module 03 defined-order reduction for 1, 2, 4, 8, 16 lanes.  Also measured: how often a fused FMADD differs
from the unfused round(round(a*b) + c), which shows the FMA really is fused (one rounding).

Usage: selftest_ref.py [N_PER_CASE]      writes reports/ref_selftest.{md,json}
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bench import paths as P  # noqa: E402
from bench import ref as R  # noqa: E402
from bench import provenance as V  # noqa: E402

import fp32_model as FM  # noqa: E402  (Module 08)

OPS = [(FM.OP_FMV, "FMV"), (FM.OP_FADD, "FADD"), (FM.OP_FSUB, "FSUB"), (FM.OP_FMUL, "FMUL"),
       (FM.OP_FMADD, "FMADD"), (FM.OP_FMSUB, "FMSUB"), (FM.OP_FNMSUB, "FNMSUB"), (FM.OP_FNMADD, "FNMADD")]
RMS = [(0, "RNE"), (1, "RTZ"), (2, "RDN"), (3, "RUP")]
SPECIALS = np.array([0x00000000, 0x80000000, 0x00000001, 0x80000001, 0x007FFFFF, 0x807FFFFF, 0x00800000,
                     0x80800000, 0x7F7FFFFF, 0xFF7FFFFF, 0x7F800000, 0xFF800000, 0x7FC00000, 0xFFC00000,
                     0x7F800001, 0xFFA00000, 0x3F800000, 0xBF800000, 0x34000000, 0x0C000000, 0x00400000,
                     0x33800000, 0x4B800000], dtype=np.uint32)


def gen(dist: str, n: int, rng: np.random.Generator):
    def mk(sign, exp, man):
        return ((sign.astype(np.uint32) << 31) | (exp.astype(np.uint32) << 23) | man.astype(np.uint32))
    s = lambda: rng.integers(0, 2, n)  # noqa: E731
    m = lambda: rng.integers(0, 1 << 23, n)  # noqa: E731
    if dist == "moderate":       # |x| in [2^-15, 2^16): the benchmark data distribution
        return [mk(s(), rng.integers(112, 143, n), m()) for _ in range(3)]
    if dist == "full_range":     # every bit pattern (NaNs, Infs, subnormals included)
        return [rng.integers(0, 1 << 32, n, dtype=np.uint64).astype(np.uint32) for _ in range(3)]
    if dist == "special":        # IEEE corner cases mixed with normal values
        out = []
        for _ in range(3):
            v = mk(s(), rng.integers(100, 155, n), m())
            sel = rng.random(n) < 0.5
            v[sel] = rng.choice(SPECIALS, sel.sum())
            out.append(v)
        return out
    if dist == "underflow":      # products and sums landing around the normal / subnormal boundary
        ea = rng.integers(1, 127, n)
        eb = np.clip(127 - ea + rng.integers(-28, 4, n) + 1, 1, 254)
        c = mk(s(), rng.integers(0, 4, n), m())
        return [mk(s(), ea, m()), mk(s(), eb, m()), c]
    if dist == "cancellation":   # c close to -(a*b), a close to -b: massive cancellation, exact zeros
        a, b = mk(s(), rng.integers(110, 145, n), m()), mk(s(), rng.integers(110, 145, n), m())
        p = (R.f32(a).astype(np.float64) * R.f32(b).astype(np.float64)).astype(np.float32).view(np.uint32)
        c = (p ^ np.uint32(0x80000000)) + rng.integers(-2, 3, n).astype(np.uint32)
        b2 = a ^ np.uint32(0x80000000)
        sel = rng.random(n) < 0.5
        b = np.where(sel, b2 + rng.integers(-2, 3, n).astype(np.uint32), b)
        return [a, b, c]
    raise ValueError(dist)


DISTS = ["moderate", "full_range", "special", "underflow", "cancellation"]


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 4000
    rng = np.random.default_rng(20261107)
    rows, total, bad = [], 0, 0
    t0 = time.time()
    fused_differs = {}
    for op, opn in OPS:
        for rm, rmn in RMS:
            for dist in DISTS:
                a, b, c = gen(dist, n, rng)
                d, _, ef = R.vec(op, rm, a, b, c, per_elem=True)
                mism = fmis = 0
                first = None
                for i in range(n):
                    r, f = FM.elem(op, int(a[i]), int(b[i]), int(c[i]), rm)
                    if r != int(d[i]):
                        mism += 1
                        first = first or dict(a=f"{a[i]:08x}", b=f"{b[i]:08x}", c=f"{c[i]:08x}",
                                              model=f"{r:08x}", sfref=f"{int(d[i]):08x}")
                    if f != int(ef[i]):
                        fmis += 1
                        first = first or dict(a=f"{a[i]:08x}", b=f"{b[i]:08x}", c=f"{c[i]:08x}",
                                              model_flags=f"{f:05b}", sfref_flags=f"{int(ef[i]):05b}")
                total += n
                bad += (mism > 0 or fmis > 0)
                rows.append(dict(op=opn, rm=rmn, dist=dist, n=n, result_mismatches=mism, flag_mismatches=fmis,
                                 first=first))
                if op == FM.OP_FMADD:
                    p, _ = R.vec(FM.OP_FMUL, rm, a, b)
                    unf, _ = R.vec(FM.OP_FADD, rm, p, c)
                    fused_differs[f"{rmn}/{dist}"] = int((unf != d).sum())
    # reductions
    red_rows = []
    for lanes in (1, 2, 4, 8, 16):
        for op, opn in ((FM.OP_FMUL, "FMUL"), (FM.OP_FMV, "FMV"), (FM.OP_FADD, "FADD"), (FM.OP_FMADD, "FMADD")):
            for rm, rmn in RMS:
                mism = 0
                cases = 60
                first = None
                for k in range(cases):
                    vl = int(rng.integers(1, 260))
                    dist = DISTS[k % len(DISTS)]
                    a, b, c = gen(dist, vl, rng)
                    init = int(gen("special", 1, rng)[0][0]) if k % 3 == 0 else 0
                    res, fl = R.reduce(op, rm, lanes, a, b, c, init)
                    xs, ef = [], 0
                    for i in range(vl):
                        r, f = FM.elem(op, int(a[i]), int(b[i]), int(c[i]), rm)
                        xs.append(r)
                        ef |= f
                    mr, mf = FM.reduce_sum(xs, lanes, init, rm)
                    if mr != res or (mf | ef) != fl:
                        mism += 1
                        first = first or dict(vl=vl, dist=dist, model=f"{mr:08x}/{mf | ef:05b}", sfref=f"{res:08x}/{fl:05b}")
                red_rows.append(dict(lanes=lanes, op=opn, rm=rmn, cases=cases, mismatches=mism, first=first))
                bad += mism > 0
    elapsed = time.time() - t0
    elem_mis = sum(r["result_mismatches"] + r["flag_mismatches"] for r in rows)
    red_mis = sum(r["mismatches"] for r in red_rows)
    out = dict(title="Module 10 reference kernels self-test", n_per_case=n, element_vectors=total,
               element_mismatches=elem_mis, reduction_cases=sum(r["cases"] for r in red_rows),
               reduction_mismatches=red_mis, passed=(elem_mis == 0 and red_mis == 0), seconds=round(elapsed, 1),
               fused_vs_unfused_differences=fused_differs, rows=rows, reduction_rows=red_rows,
               compiler_flags=R.CFLAGS, provenance=V.environment())
    P.REPORTS.mkdir(parents=True, exist_ok=True)
    (P.REPORTS / "ref_selftest.json").write_text(json.dumps(out, indent=1))
    L = ["# Reference-kernel self-test (sfref.c vs Module 08 fp32_model.py)", "",
         "Two independent implementations: `kernels/ref/sfref.c` (host x86-64 IEEE hardware through `<fenv.h>`, "
         "FMA3 `vfmadd`) and Module 08's integer model (validated against Berkeley SoftFloat-3e RISC-V). "
         "Every result word **and** every per-element flag set is compared.", "",
         f"* Element operations: **{total:,} vectors, {elem_mis} mismatches** "
         f"(8 operations x 4 rounding modes x 5 distributions x {n}).",
         f"* Defined-order reductions (Module 03 REDUCTION.md sec. 1): **{out['reduction_cases']} cases, "
         f"{red_mis} mismatches** (lanes 1/2/4/8/16 x FMUL/FMV/FADD/FMADD x 4 rounding modes).",
         f"* Result: **{'PASS' if out['passed'] else 'FAIL'}** ({elapsed:.0f} s).", "",
         "RMM (round to nearest, ties away) has no `<fenv.h>` mode and is not implemented by sfref.c; the "
         "benchmarks use RNE.", "",
         "## Fused FMA evidence", "",
         "Number of FMADD results (out of each case) that differ from the unfused `round(round(a*b)+c)`: a "
         "non-zero count on data where the two differ shows that one rounding is performed.", "",
         "| rm / distribution | fused != unfused |", "|---|---|"]
    L += [f"| {k} | {v} / {n} |" for k, v in fused_differs.items()]
    L += ["", "## Element operations", "", "| op | rm | distribution | n | result mismatches | flag mismatches |",
          "|---|---|---|---|---|---|"]
    L += [f"| {r['op']} | {r['rm']} | {r['dist']} | {r['n']} | {r['result_mismatches']} | {r['flag_mismatches']} |"
          for r in rows]
    L += ["", "## Reductions", "", "| lanes | op | rm | cases | mismatches |", "|---|---|---|---|---|"]
    L += [f"| {r['lanes']} | {r['op']} | {r['rm']} | {r['cases']} | {r['mismatches']} |" for r in red_rows]
    (P.REPORTS / "ref_selftest.md").write_text("\n".join(L) + "\n")
    print("\n".join(L[:12]))
    for r in rows + red_rows:
        if r.get("first"):
            print("MISMATCH", r)
    sys.exit(0 if out["passed"] else 1)


if __name__ == "__main__":
    main()
