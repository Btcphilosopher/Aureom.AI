#!/usr/bin/env python3
"""Module 10 benchmark runner CLI.

  bench.py list                               experiments and their points
  bench.py run EXP [EXP ...] [--jobs N]       run every point x seed of the experiments, write run records
  bench.py run EXP --run RUN_ID               run one point of an experiment
  bench.py reproduce RUN_ID                   re-execute a recorded run and compare it with the record
  bench.py validate                           validate every run record against schema/run_record.schema.json
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bench import hw as H  # noqa: E402
from bench import paths as P  # noqa: E402
from bench import runner as RN  # noqa: E402


def validator():
    import jsonschema
    return jsonschema.Draft202012Validator(json.loads(P.SCHEMA.read_text()))


def jobs_of(exp_ids, only=None):
    out = []
    for e in exp_ids:
        exp = RN.load_experiment(e)
        pts = RN.expand(exp)
        for i, pt in enumerate(pts):
            for s in exp.get("seeds", [1]):
                rid = RN.run_id(exp["id"], pt, s)
                if only and rid != only:
                    continue
                csv = bool(exp.get("csv_trace")) and s == exp.get("seeds", [1])[0] and \
                    (exp.get("csv_trace") is True or i in exp.get("csv_trace", []))
                out.append((exp, pt, s, csv))
    return out


def prebuild(jobs_l, par=2):
    names = sorted({pt["hw"] for _, pt, _, _ in jobs_l if pt.get("hw") and not pt.get("not_run")})
    t0 = time.time()

    def b(n):
        H.build(H.HwConfig.get(n), jobs=2)
        return n
    with cf.ThreadPoolExecutor(max_workers=par) as ex:
        for n in ex.map(b, names):
            print(f"  built {n}", flush=True)
    print(f"  {len(names)} configuration(s) ready in {time.time() - t0:.0f} s", flush=True)


def clean(exp_id: str):
    """Remove an experiment's previous results so a re-run never mixes stale records with new ones."""
    import shutil
    for sub in (P.RUNS, P.LOGS, P.COUNTERS, P.TRACES, P.REPORTS / "programs"):
        shutil.rmtree(sub / exp_id, ignore_errors=True)
    for d in (P.REPORTS / "outputs").glob(f"{exp_id}__*"):
        shutil.rmtree(d, ignore_errors=True)


def cmd_run(a):
    jl = jobs_of(a.exp, a.run)
    if not a.run:
        for e in a.exp:
            clean(e)
    if not jl:
        sys.exit(f"nothing to run for {a.exp} {a.run or ''}")
    prebuild(jl)
    v = validator()
    res = []

    def one(j):
        exp, pt, s, csv = j
        rec = RN.run_point(exp, pt, s, csv=csv)
        errs = [e.message for e in v.iter_errors(json.loads(json.dumps(rec, default=RN._json_default)))]
        if errs:
            rec["status"] = "FAILED"
            rec["status_reason"] = "schema: " + "; ".join(errs[:3])
        RN.write_record(rec)
        return rec
    t0 = time.time()
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for rec in ex.map(one, jl):
            m = rec.get("metrics", {})
            print(f"  {rec['status']:8s} {rec['run_id']:60s} cycles={m.get('cycles', '-')!s:>7} "
                  f"elem/cyc={_f(m.get('elements_per_cycle'))} FLOP/cyc={_f(m.get('flop_per_cycle'))} "
                  f"{'' if rec['status'] == 'VALID' else rec['status_reason'][:90]}", flush=True)
            res.append(rec)
    n = {s: sum(r["status"] == s for r in res) for s in ("VALID", "FAILED", "NOT_RUN")}
    print(f"{len(res)} runs in {time.time() - t0:.0f} s: {n}")
    sys.exit(1 if n["FAILED"] else 0)


def _f(x):
    return f"{x:7.3f}" if isinstance(x, (int, float)) else "      -"


def cmd_reproduce(a):
    rid = a.run_id
    f = next(P.RUNS.glob(f"*/{rid}.json"), None)
    if f is None:
        sys.exit(f"no record {rid}")
    old = json.loads(f.read_text())
    exp = RN.load_experiment(old["experiment"]["id"])
    # never touch the stored results: the re-execution archives into build/reproduce/
    scratch = P.BUILD / "reproduce" / rid
    P.REPORTS, P.LOGS, P.COUNTERS, P.TRACES = scratch, scratch / "logs", scratch / "counters", scratch / "traces"
    new = RN.run_point(exp, old["experiment"]["point"], old["experiment"]["seed"], csv=False)
    diffs = []
    if new["status"] != old["status"]:
        diffs.append(f"status {old['status']} -> {new['status']}")
    if old["status"] == "VALID":
        if new["timing"]["cycles"] != old["timing"]["cycles"]:
            diffs.append(f"cycles {old['timing']['cycles']} -> {new['timing']['cycles']}")
        for k, v in old["counters"]["hw"].items():
            if new["counters"]["hw"][k] != v:
                diffs.append(f"PERF[{k}] {v} -> {new['counters']['hw'][k]}")
        for nm, o in old["artifacts"]["outputs"].items():
            if new["artifacts"]["outputs"].get(nm, {}).get("sha256") != o["sha256"]:
                diffs.append(f"output {nm} differs")
        for d_old, d_new in zip(old["dataset"]["files"], new["dataset"]["files"]):
            if d_old["sha256"] != d_new["sha256"]:
                diffs.append(f"dataset {d_old['role']} differs")
        if old["rtl"]["tile_rtl_sha256"] != new["rtl"]["tile_rtl_sha256"]:
            diffs.append("RTL sources differ from the recorded ones")
    print(f"{rid}: {'REPRODUCED (cycles, all 24 counters, outputs and datasets identical)' if not diffs else 'DIFFERS'}")
    for d in diffs:
        print("   ", d)
    sys.exit(1 if diffs else 0)


def cmd_validate(a):
    v = validator()
    bad = n = 0
    for f in sorted(P.RUNS.glob("*/*.json")):
        n += 1
        errs = list(v.iter_errors(json.loads(f.read_text())))
        if errs:
            bad += 1
            print(f"INVALID {f.relative_to(P.HPC)}: {errs[0].message[:160]}")
    print(f"{n} records, {bad} schema violations")
    sys.exit(1 if bad else 0)


def cmd_list(a):
    for e in RN.all_experiments():
        exp = RN.load_experiment(e)
        pts = RN.expand(exp)
        print(f"{e:22s} {len(pts):3d} points x {len(exp.get('seeds', [1]))} seeds  {exp['title']}")


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    r = sp.add_parser("run")
    r.add_argument("exp", nargs="+")
    r.add_argument("--jobs", type=int, default=4)
    r.add_argument("--run", default=None)
    rp = sp.add_parser("reproduce")
    rp.add_argument("run_id")
    sp.add_parser("validate")
    sp.add_parser("list")
    a = ap.parse_args()
    {"run": cmd_run, "reproduce": cmd_reproduce, "validate": cmd_validate, "list": cmd_list}[a.cmd](a)


if __name__ == "__main__":
    main()
