#!/usr/bin/env python3
"""Static charts (PNG + the plotted data as CSV) from the run records -> reports/charts/.

Palette (validated with the dataviz validator, dark mode on the midnight-navy surface #0b1530, all checks pass;
the first three slots also pass all-pairs, so scatter charts use at most three colours plus marker shape):
  1 electric cyan #0aa2c0   2 metallic gold #b38a1d   3 violet #8f6ff0   4 rose #d24c8e
"""
from __future__ import annotations

import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bench import analysis as A  # noqa: E402
from bench import hw as H  # noqa: E402
from bench import paths as P  # noqa: E402

NAVY, PANEL, GRID = "#0b1530", "#0f1c3d", "#26345e"
INK, INK2, INK3 = "#e8ecf4", "#a9b4c8", "#7d89a3"
S = ["#0aa2c0", "#b38a1d", "#8f6ff0", "#d24c8e"]
GOLD_ACCENT = "#d4af37"

plt.rcParams.update({
    "figure.facecolor": NAVY, "axes.facecolor": NAVY, "savefig.facecolor": NAVY, "axes.edgecolor": GRID,
    "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "text.color": INK, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False, "axes.spines.right": False,
    "font.family": "DejaVu Sans", "font.size": 9.5, "axes.titlesize": 11.5, "axes.titleweight": "bold",
    "axes.titlecolor": INK, "legend.frameon": False, "legend.labelcolor": INK2, "lines.linewidth": 2,
    "lines.markersize": 7})


def save(fig, name, rows, header):
    P.CHARTS.mkdir(parents=True, exist_ok=True)
    fig.savefig(P.CHARTS / f"{name}.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    with open(P.CHARTS / f"{name}.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    print(f"  reports/charts/{name}.png")


def footer(fig, text):
    fig.text(0.01, -0.02, text, color=INK3, fontsize=7.5, ha="left", va="top", wrap=True)


def roofline_chart(rf, level, name, title, extra_roofs=()):
    L = rf["levels"].get(level)
    if not L:
        return
    peak, bw = rf["peak_flop_per_cycle"], L["sustained_bytes_per_cycle"]
    fig, ax = plt.subplots(figsize=(7.6, 4.8))
    import math
    pa = [p["ai"] for p in L["points"]] or [L["ridge_ai"]]
    lo = 2 ** math.floor(math.log2(min(pa) / 2))
    hi = 2 ** math.ceil(math.log2(max(max(pa) * 2, L["ridge_ai"] * 4)))
    ai = [lo * 2 ** (k / 8) for k in range(int(8 * math.log2(hi / lo)) + 1)]
    ax.plot(ai, [min(peak, a * bw) for a in ai], color=INK, lw=2, zorder=3)
    ax.text(ai[-1], peak * 1.12, f"P_peak = {peak:g} FLOP/cycle (4 lanes x 2 x II 1)", ha="right", color=INK2, fontsize=8)
    xm = lo * 2
    ax.text(xm, xm * bw * 0.62, f"measured sustained {bw:.2f} B/cycle", color=INK2, fontsize=8, ha="left", va="top")
    for lab, b, ls in extra_roofs:
        ax.plot(ai, [min(peak, a * b) for a in ai], color=INK3, lw=1.2, ls=ls, zorder=2)
        xl = peak / b / 5                       # near the knee of the dashed roof, away from the measured points
        ax.text(xl, xl * b * 1.25, lab, color=INK3, fontsize=7.5, ha="right", va="bottom")
    groups = {"single elementwise command (A, B, E)": ([], "o", S[0]),
              "reduction (C, D dot form)": ([], "s", S[1]),
              "multi-command (D axpy form, F)": ([], "^", S[2])}
    for p in L["points"]:
        g = ("reduction (C, D dot form)" if p["benchmark"] == "C" or "dot" in p["label"] else
             "multi-command (D axpy form, F)" if p["benchmark"] in ("D", "F") else
             "single elementwise command (A, B, E)")
        groups[g][0].append(p)
    rows = []
    for g, (pts, mk, col) in groups.items():
        if not pts:
            continue
        ax.scatter([p["ai"] for p in pts], [p["flop_per_cycle"] for p in pts], marker=mk, s=46, color=col,
                   edgecolor=NAVY, linewidth=1.5, zorder=5, label=g)
        for p in pts:
            rows.append([level, g, p["label"], p["config"], f"{p['ai']:.5f}", f"{p['flop_per_cycle']:.5f}",
                         f"{p['roofline_bound']:.5f}", f"{p['fraction_of_roofline']:.4f}", p["run_id"]])
    # selective direct labels: the best point of each group, placed below-right of its mark
    done = set()
    offs = {0: ((-9, 6), "right"), 1: ((9, 4), "left"), 2: ((9, -13), "left")}
    for p in sorted(L["points"], key=lambda p: -p["flop_per_cycle"]):
        g = 1 if (p["benchmark"] == "C" or "dot" in p["label"]) else 2 if p["benchmark"] in ("D", "F") else 0
        if g in done:
            continue
        done.add(g)
        (dx, dy), ha = offs[g]
        if ha == "right" and p["ai"] < lo * 16:          # too close to the left edge: label to the right instead
            (dx, dy), ha = (9, -13), "left"
        ax.annotate(p["label"], (p["ai"], p["flop_per_cycle"]), xytext=(dx, dy), textcoords="offset points",
                    color=INK2, fontsize=7.5, ha=ha)
    ax.set_xscale("log", base=2)
    ax.set_yscale("log", base=2)
    ax.set_xlim(lo, hi)
    py = [p["flop_per_cycle"] for p in L["points"]] or [peak]
    ax.set_ylim(min(min(py), lo * bw) / 2, peak * 2.2)
    ax.set_xlabel("arithmetic intensity at this boundary (useful FLOP / useful byte)")
    ax.set_ylabel("achieved FLOP / cycle")
    ax.set_title(title, loc="left")
    ax.legend(loc="lower right", fontsize=8)
    ax.axvline(L["ridge_ai"], color=GRID, lw=1, ls=":")
    footer(fig, f"RTL simulation cycles (Verilator), tile config base. Bandwidth roof MEASURED: {L['bandwidth_source']}. "
                f"Port peak at this boundary {L['port_peak_bytes_per_cycle']:.0f} B/cycle (sustained = "
                f"{100 * bw / L['port_peak_bytes_per_cycle']:.1f} %). Ridge AI = {L['ridge_ai']:.2f} FLOP/B. "
                f"No clock frequency implied.")
    save(fig, name, rows, ["level", "group", "kernel", "config", "ai", "flop_per_cycle", "roofline_bound",
                           "fraction_of_roofline", "run_id"])


def lanes_chart(ls):
    fig, ax = plt.subplots(figsize=(7.6, 4.6))
    series = [("FMADD|spm|DW32", "FMADD, scratchpad, 32-bit words", S[0], "o"),
              ("FADD|spm|DW32", "FADD, scratchpad, 32-bit words", S[1], "s"),
              ("FMADD|spm|DW128", "FMADD, scratchpad, 128-bit words", S[2], "D"),
              ("FMADD|kernel|DW32", "FMADD, end to end (KERNEL), 32-bit", S[3], "^")]
    rows = []
    for key, lab, col, mk in series:
        d = ls.get(key)
        if not d:
            continue
        xs = [r["lanes"] for r in d["rows"]]
        ys = [r["elem_per_cycle"] for r in d["rows"]]
        ax.plot(xs, ys, color=col, marker=mk, label=lab, markeredgecolor=NAVY, markeredgewidth=1.2)
        ax.annotate(f"{ys[-1]:.2f}", (xs[-1], ys[-1]), xytext=(6, 0), textcoords="offset points", color=INK2,
                    fontsize=7.5, va="center")
        for r in d["rows"]:
            rows.append([lab, r["config"], r["lanes"], r["dw"], r["lsu_ports"], f"{r['elem_per_cycle']:.4f}",
                         f"{r['speedup_vs_ref']:.3f}", f"{r['efficiency_vs_ref']:.3f}", r["run_id"]])
    xs = [1, 2, 4, 8, 16]
    ax.plot(xs, xs, color=INK3, lw=1.2, ls="--")
    ax.text(5.6, 8.6, "array peak (lanes)", color=INK3, fontsize=7.5, ha="right")
    ax.set_xscale("log", base=2)
    ax.set_yscale("log", base=2)
    ax.set_xticks(xs, [str(x) for x in xs])
    ax.set_xlabel("FP32 lanes")
    ax.set_ylabel("elements / cycle")
    ax.set_title("Lane scaling: arithmetic (scratchpad) vs end to end (host memory)", loc="left")
    ax.legend(loc="upper left", fontsize=8)
    footer(fig, "vl = 1024. 32-bit words: banks = lanes. 128-bit words: 4 / 8 / 8 banks. RTL simulation cycles.")
    save(fig, "lane_scaling", rows, ["series", "config", "lanes", "dw", "lsu_ports", "elem_per_cycle",
                                     "speedup_vs_ref", "efficiency_vs_ref", "run_id"])


def vl_chart(recs):
    fig, ax = plt.subplots(figsize=(7.6, 4.4))
    rows = []
    hwc = H.HwConfig.get("base")
    for (op, col, mk, reads) in (("FADD", S[1], "s", 2), ("FMADD", S[0], "o", 3)):
        rs = sorted([r for r in recs if r["experiment"]["id"] == "S3_vl" and r["experiment"]["point"]["op"] == op],
                    key=lambda r: r["experiment"]["point"]["vl"])
        if not rs:
            continue
        xs = [r["experiment"]["point"]["vl"] for r in rs]
        ys = [r["metrics"]["elements_per_cycle"] for r in rs]
        ax.plot(xs, ys, color=col, marker=mk, label=f"{op} (scratchpad)", markeredgecolor=NAVY, markeredgewidth=1.2)
        lb = hwc.lsu_bound(reads)
        ax.axhline(lb, color=col, lw=1, ls=":")
        ax.text(4096, lb * 1.025, f"{op} LSU bound {lb:.2f}", color=INK3, fontsize=7.5, ha="right")
        fit = A.hockney(xs, [r["timing"]["cycles"] for r in rs])
        for r in rs:
            rows.append([op, r["experiment"]["point"]["vl"], r["timing"]["cycles"],
                         f"{r['metrics']['elements_per_cycle']:.4f}", f"{fit.get('r_inf', 0):.4f}",
                         f"{fit.get('n_half', 0):.1f}", r["run_id"]])
    ax.set_xscale("log", base=2)
    ax.set_ylim(0, 1.5)
    ax.set_xlabel("vector length (elements, one VEC command)")
    ax.set_ylabel("elements / cycle")
    ax.set_title("Vector length: fixed command latency vs streaming rate", loc="left")
    ax.legend(loc="center right", fontsize=8)
    footer(fig, "Cycles = CPL_CYCLES (dispatch to retirement). Base tile: 4 lanes, 4 banks, 4 LSU ports.")
    save(fig, "vector_length", rows, ["op", "vl", "cycles", "elem_per_cycle", "hockney_r_inf", "hockney_n_half",
                                      "run_id"])


def dma_chart(recs):
    rs = [r for r in recs if r["experiment"]["id"] == "S4_dma_depth"]
    order = ["base", "d2", "d4", "d8", "d16", "d32", "x4", "x4_d8", "x8", "x8_d8", "l16_w128", "l16_w128_d8"]
    rs = sorted(rs, key=lambda r: order.index(r["hardware"]["name"]) if r["hardware"]["name"] in order else 99)
    if not rs:
        return
    fig, ax = plt.subplots(figsize=(7.8, 0.42 * len(rs) + 1.4))
    labels, vals, rows = [], [], []
    for r in rs:
        p = r["hardware"]["params"]
        eng = "simple" if p["DMA_BUFFER_DEPTH"] == 0 else f"buffered {p['DMA_BUFFER_DEPTH']}"
        labels.append(f"{r['hardware']['name']}  ({eng}, latency {p['EXT0_LATENCY']}, {p['DATA_WIDTH']}-bit)")
        bpc = 16384 / r["timing"]["cycles"]
        vals.append((bpc, r["hardware"]["derived"]["dma_port_peak_bytes_per_cycle"]))
        rows.append([r["hardware"]["name"], p["DMA_BUFFER_DEPTH"], p["EXT0_LATENCY"], p["DATA_WIDTH"],
                     r["timing"]["cycles"], f"{bpc:.4f}", r["hardware"]["derived"]["dma_port_peak_bytes_per_cycle"],
                     f"{r['metrics']['dma']['mean_outstanding']:.3f}", r["run_id"]])
    y = range(len(vals))
    ax.barh(list(y), [v for v, _ in vals], color=S[0], height=0.66, edgecolor=NAVY, linewidth=2)
    for i, (v, pk) in enumerate(vals):
        ax.text(v + 0.08, i, f"{v:.2f} B/cycle  ({100 * v / pk:.0f} % of its {pk:.0f} B/cycle port)", va="center",
                color=INK2, fontsize=7.5)
    ax.set_yticks(list(y), labels, fontsize=8)
    ax.invert_yaxis()
    ax.set_xlim(0, max(v for v, _ in vals) * 1.55)
    ax.set_xlabel("bytes / cycle, one 16 KiB host -> scratchpad DMA command")
    ax.set_title("DMA bandwidth: engine buffer depth and host-memory latency", loc="left")
    ax.grid(axis="y", visible=False)
    footer(fig, "Cycles = CPL_CYCLES. Port peak = DATA_WIDTH/8 bytes per cycle on the tile's single SFB2 master port "
                "(at most one outstanding transaction: sfb_crossbar).")
    save(fig, "dma_depth_latency", rows, ["config", "dma_buffer_depth", "ext_latency", "dw", "cycles",
                                          "bytes_per_cycle", "port_peak", "mean_outstanding", "run_id"])


def stall_chart(recs):
    pick = [("A1_vadd_spm", "FADD vl 4096"), ("B1_fma_spm", "FMADD vl 4096"), ("E1_stream_spm", None),
            ("C1_dot", "dot (base) vl 4096"), ("D1_gemm", "GEMM axpy n=32"), ("F1_stencil1d", "stencil 1-D (base)")]
    rows, bars = [], []
    for exp, lab in pick:
        rs = [r for r in recs if r["experiment"]["id"] == exp and r["experiment"]["seed"] == 1]
        if exp == "E1_stream_spm":
            for r in rs:
                bars.append((r["benchmark"]["name"].replace("stream_", "STREAM ") , r))
            continue
        if exp in ("A1_vadd_spm", "B1_fma_spm"):
            rs = [r for r in rs if r["experiment"]["point"]["vl"] == 4096]
        if exp == "C1_dot":
            rs = [r for r in rs if r["hardware"]["name"] == "base" and r["experiment"]["point"].get("dist") == "unit"]
        if exp == "D1_gemm":
            rs = [r for r in rs if r["experiment"]["point"].get("form") == "axpy" and r["experiment"]["point"].get("n") == 32]
        if exp == "F1_stencil1d":
            rs = [r for r in rs if r["hardware"]["name"] == "base"]
        if rs:
            bars.append((lab, rs[0]))
    if not bars:
        return
    fig, ax = plt.subplots(figsize=(7.8, 0.52 * len(bars) + 1.6))
    cats = [("issue", "beat issued to the lanes", S[0]), ("operand_starvation", "operand starvation (no beat ready)", S[1]),
            ("array_backpressure", "array back-pressure", S[2])]
    for i, (lab, r) in enumerate(bars):
        sb = r["metrics"]["vector_unit"]["stall_breakdown"]
        tot = sum(sb[c] for c, _, _ in cats)
        left = 0.0
        for c, cl, col in cats:
            w = sb[c] / tot if tot else 0
            ax.barh(i, w, left=left, color=col, edgecolor=NAVY, linewidth=2, height=0.62,
                    label=cl if i == 0 else None)
            left += w
        ax.text(1.01, i, f"{r['metrics']['vector_unit']['lane_utilisation'] * 100:.0f}% lanes", va="center",
                color=INK2, fontsize=7.5)
        rows.append([lab, r["metrics"]["vector_unit"]["active_cycles"], sb["issue"], sb["operand_starvation"],
                     sb["array_backpressure"], f"{r['metrics']['vector_unit']['lane_utilisation']:.4f}", r["run_id"]])
    ax.set_yticks(range(len(bars)), [b[0] for b in bars])
    ax.invert_yaxis()
    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    ax.set_xlabel("share of vector-unit active cycles (PERF[VEC_ACTIVE])")
    ax.set_title("Vector pipeline: where the active cycles go", loc="left")
    ax.legend(loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=3, fontsize=7.5)
    ax.set_title("Vector pipeline: where the active cycles go", loc="left", pad=24)
    ax.grid(axis="y", visible=False)
    footer(fig, "Trace-derived (tb_hpc_bench event monitor); the three parts sum exactly to PERF[VEC_ACTIVE] "
                "(cross-checked in every run). Base tile.")
    save(fig, "pipeline_stalls", rows, ["kernel", "vec_active", "issue", "operand_starvation",
                                        "array_backpressure", "lane_utilisation", "run_id"])


def banks_chart(recs):
    rs = [r for r in recs if r["experiment"]["id"] == "S2_banks" and r["experiment"]["point"]["op"] == "FMADD"]
    if not rs:
        return
    fig, ax = plt.subplots(figsize=(7.4, 4.2))
    order = ["b1", "b2", "base", "b8"]
    rows = []
    w = 0.38
    for j, (stg, lab, col) in enumerate(((0, "aligned operand bases", S[0]), (1, "staggered by one word", S[2]))):
        vals = []
        for i, c in enumerate(order):
            r = next((r for r in rs if r["hardware"]["name"] == c and r["experiment"]["point"]["stagger_words"] == stg), None)
            v = r["metrics"]["elements_per_cycle"] if r else 0
            vals.append(v)
            if r:
                sp = r["metrics"]["scratchpad"]
                rows.append([c, r["hardware"]["params"]["NUM_BANKS"], stg, f"{v:.4f}", sp["conflicts"],
                             f"{sp['conflicts_per_access']:.4f}", r["run_id"]])
                ax.text(i + (j - 0.5) * w, v + 0.02, f"{v:.2f}", ha="center", color=INK2, fontsize=7.5)
        ax.bar([i + (j - 0.5) * w for i in range(len(order))], vals, width=w, color=col, edgecolor=NAVY,
               linewidth=2, label=lab)
    ax.axhline(1.0, color=INK3, lw=1, ls="--")
    ax.text(-0.45, 1.025, "LSU bound 1.0", color=INK3, fontsize=7.5, ha="left")
    ax.set_ylim(0, 1.18)
    ax.set_xticks(range(len(order)), ["1 bank", "2 banks", "4 banks (base)", "8 banks"])
    ax.set_ylabel("FMADD elements / cycle")
    ax.set_title("Scratchpad banks and operand placement (4 lanes, 4 LSU ports)", loc="left", pad=24)
    ax.legend(loc="lower left", bbox_to_anchor=(0.0, 1.0), ncol=2, fontsize=8)
    ax.grid(axis="x", visible=False)
    footer(fig, "vl = 1024. Conflicts per access in the CSV (PERF[SPM_CONFLICTS] / accepted port requests).")
    save(fig, "bank_scaling", rows, ["config", "banks", "stagger_words", "elem_per_cycle", "spm_conflicts",
                                     "conflicts_per_access", "run_id"])


def main():
    recs = A.load_records("VALID")
    rf = A.roofline(recs)
    roofline_chart(rf, "scratchpad", "roofline_scratchpad",
                   "Roofline at the scratchpad (LSU) boundary, base tile")
    roofline_chart(rf, "host_memory (simple DMA)", "roofline_host_simple",
                   "Roofline at the host-memory (DMA) boundary, simple engine",
                   extra_roofs=[("fabric port peak 4 B/cycle (not reached)", 4.0, "--")])
    roofline_chart(rf, "host_memory (buffered DMA, depth 8)", "roofline_host_buffered",
                   "Roofline at the host-memory (DMA) boundary, buffered engine (depth 8)",
                   extra_roofs=[("fabric port peak 4 B/cycle (not reached)", 4.0, "--")])
    lanes_chart(A.lane_scaling(recs))
    vl_chart(recs)
    dma_chart(recs)
    stall_chart(recs)
    banks_chart(recs)


if __name__ == "__main__":
    main()
