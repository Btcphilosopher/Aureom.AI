#!/usr/bin/env python3
"""Analysis of every run record -> reports/analysis.json and the markdown reports.

Every number in the generated reports is read from reports/runs/**.json or derived from those values
(bench/analysis.py, bench/equations.py).  Nothing is typed in by hand.
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bench import analysis as A  # noqa: E402
from bench import equations as E  # noqa: E402
from bench import hw as H  # noqa: E402
from bench import paths as P  # noqa: E402
from bench import provenance as V  # noqa: E402


def f(x, d=3):
    if x is None:
        return "-"
    if isinstance(x, float):
        return f"{x:.{d}f}"
    return str(x)


def pct(x):
    return "-" if x is None else f"{100 * x:.1f} %"


def table(head, rows):
    out = ["| " + " | ".join(head) + " |", "|" + "---|" * len(head)]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def get(recs, exp, **kw):
    out = []
    for r in recs:
        if r["experiment"]["id"] != exp:
            continue
        pt = r["experiment"]["point"]
        if all((r["hardware"]["name"] if k == "hw" else pt.get(k)) == v for k, v in kw.items()):
            out.append(r)
    return out


def one(recs, exp, **kw):
    rs = [r for r in get(recs, exp, **kw) if r["experiment"]["seed"] == 1] or get(recs, exp, **kw)
    return rs[0] if rs else None


def bnd(r, name):
    return next((b for b in r["metrics"]["boundaries"] if b["boundary"] == name), None)


def per_s(r, which="fpga_constraint_25mhz"):
    v = r["metrics"]["per_second"]["flops"].get(which)
    return None if v is None else v / 1e6


def main():
    allrecs = A.load_records()
    recs = [r for r in allrecs if r["status"] == "VALID"]
    counts = defaultdict(int)
    for r in allrecs:
        counts[r["status"]] += 1
    an = dict(counts=dict(counts), total=len(allrecs))
    an["sustained_bandwidth"] = A.sustained_bandwidths(recs)
    an["roofline"] = A.roofline(recs)
    an["lane_scaling"] = A.lane_scaling(recs)
    an["seed_statistics"] = A.seed_statistics(recs)
    # Hockney fits
    fits = {}
    for op in ("FADD", "FMADD"):
        rs = sorted(get(recs, "S3_vl", op=op), key=lambda r: r["experiment"]["point"]["vl"])
        if rs:
            fits[f"{op} scratchpad (base)"] = dict(**A.hockney([r["experiment"]["point"]["vl"] for r in rs],
                                                                [r["timing"]["cycles"] for r in rs]), unit="elements")
    for cfg in ("base", "d8"):
        rs = sorted(get(recs, "S3b_vl_kernel", hw=cfg), key=lambda r: r["experiment"]["point"]["vl"])
        if rs:
            fits[f"FMADD KERNEL end to end ({cfg})"] = dict(**A.hockney([r["experiment"]["point"]["vl"] for r in rs],
                                                                        [r["timing"]["cycles"] for r in rs]), unit="elements")
        rs = sorted(get(recs, "S4b_dma_size", hw=cfg), key=lambda r: r["experiment"]["point"]["bytes"])
        if rs:
            fits[f"DMA host->scratchpad ({cfg})"] = dict(**A.hockney([r["experiment"]["point"]["bytes"] for r in rs],
                                                                     [r["timing"]["cycles"] for r in rs]), unit="bytes")
    an["hockney"] = fits

    # ------------------------------------------------------------ headline numbers (core: A, B, E)
    H_ = {}
    a1 = one(recs, "A1_vadd_spm", vl=4096)
    b1 = one(recs, "B1_fma_spm", vl=4096)
    a2 = one(recs, "A2_vadd_kernel", vl=4096, hw="base")
    a2b = one(recs, "A2_vadd_kernel", vl=4096, hw="d8")
    b2 = one(recs, "B2_fma_kernel", vl=4096, hw="base")
    b2b = one(recs, "B2_fma_kernel", vl=4096, hw="d8")
    if a1 and b1 and b2:
        H_ = dict(
            vadd_spm=dict(elem_per_cycle=a1["metrics"]["elements_per_cycle"],
                          lsu_bound=a1["metrics"]["lsu_bound_elements_per_cycle"],
                          fraction_of_lsu_bound=a1["metrics"]["fraction_of_lsu_bound"],
                          lane_utilisation=a1["metrics"]["vector_unit"]["lane_utilisation"],
                          spm_bytes_per_cycle=bnd(a1, "scratchpad")["bytes_per_cycle"], run=a1["run_id"]),
            fma_spm=dict(flop_per_cycle=b1["metrics"]["flop_per_cycle"], peak=b1["metrics"]["peak_flop_per_cycle"],
                         fraction_of_peak=b1["metrics"]["fraction_of_peak"],
                         fraction_of_lsu_bound=b1["metrics"]["fraction_of_lsu_bound"],
                         lane_utilisation=b1["metrics"]["vector_unit"]["lane_utilisation"],
                         fma_retired=b1["metrics"]["vector_unit"]["fma_retired"],
                         bank_utilisation=b1["metrics"]["scratchpad"]["bank_utilisation_vec_active"],
                         mflops_25mhz=per_s(b1), run=b1["run_id"]),
            fma_kernel=dict(flop_per_cycle=b2["metrics"]["flop_per_cycle"],
                            flop_per_cycle_buffered=b2b["metrics"]["flop_per_cycle"] if b2b else None,
                            host_bytes_per_cycle=bnd(b2, "host_memory")["bytes_per_cycle"],
                            host_bytes_per_cycle_buffered=bnd(b2b, "host_memory")["bytes_per_cycle"] if b2b else None,
                            fraction_of_peak=b2["metrics"]["fraction_of_peak"],
                            ratio_spm_over_kernel=b1["metrics"]["flop_per_cycle"] / b2["metrics"]["flop_per_cycle"],
                            mflops_25mhz=per_s(b2), run=b2["run_id"]),
            vadd_kernel=dict(elem_per_cycle=a2["metrics"]["elements_per_cycle"] if a2 else None,
                             elem_per_cycle_buffered=a2b["metrics"]["elements_per_cycle"] if a2b else None))
    an["headline"] = H_

    # ------------------------------------------------------------ bottleneck evidence (every number computed)
    an["bottlenecks"] = bottlenecks(recs, an) if H_ else []

    # ------------------------------------------------------------ correctness summary
    corr = dict(valid_runs=len(recs), bitwise_outputs=0, bitwise_words=0, bitwise_mismatches=0, flags_compared=0,
                flags_matched=0, tolerance_checks=0, tolerance_passed=0, nan_words=0, inf_words=0, subnormal_words=0)
    for r in recs:
        for o in r["correctness"].get("outputs", {}).values():
            corr["bitwise_outputs"] += 1
            corr["bitwise_words"] += o.get("compared", 0)
            corr["bitwise_mismatches"] += o.get("mismatches", 0)
            corr["nan_words"] += o.get("nan_count", 0)
            corr["inf_words"] += o.get("inf_count", 0)
            corr["subnormal_words"] += max(o.get("subnormal_count", 0), 0)
            if "flags_match" in o:
                corr["flags_compared"] += 1
                corr["flags_matched"] += bool(o["flags_match"])
        if "tolerance" in r["correctness"]:
            corr["tolerance_checks"] += 1
            corr["tolerance_passed"] += bool(r["correctness"]["tolerance"]["passed"])
    corr["counter_cross_checks"] = sum(r["cross_check"]["n_checks"] for r in recs)
    corr["counter_cross_checks_failed"] = sum(r["cross_check"]["n_failed"] for r in recs)
    corr["csv_trace_recounts"] = sum(1 for r in recs if "csv" in r["cross_check"])
    an["correctness"] = corr

    # ------------------------------------------------------------ provenance
    an["provenance"] = dict(environment=V.environment(), suite_sha256=V.suite_digest(), rtl=H.rtl_digest(),
                            m08_zip=V.M08_ZIP_NAME, m08_zip_sha256=V.M08_ZIP_SHA256,
                            m08_zip_repo_path=V.M08_ZIP_REPO_PATH, m08_manifest_verified=V.m08_manifest_ok(),
                            datasets=len(json.loads((P.DATA / "MANIFEST.json").read_text())),
                            clocks=E.clocks(), power=json.loads((P.CONFIGS / "power.json").read_text()))
    (P.REPORTS / "analysis.json").write_text(json.dumps(an, indent=1, default=str))
    write_markdown(allrecs, recs, an)
    print(f"analysis: {an['counts']} -> reports/analysis.json, reports/*.md")


# ====================================================================== bottlenecks
def bottlenecks(recs, an):
    hd, sb = an["headline"], an["sustained_bandwidth"]
    ev = {}
    # 1. DMA: transaction rate / memory-level parallelism
    dma_runs = [r for r in recs if r["experiment"]["id"] in ("E3_dma_copy", "S4_dma_depth", "S4b_dma_size")]
    ev["dma_runs"] = len(dma_runs)
    ev["fabric_req_stall_cycles"] = sum(r["metrics"]["dma"]["fabric_req_stall_cycles"] for r in dma_runs)
    ev["fabric_req_stall_cycles_latency1"] = sum(r["metrics"]["dma"]["fabric_req_stall_cycles"] for r in dma_runs
                                                 if r["hardware"]["params"]["EXT0_LATENCY"] == 1)
    ev["dma_runs_latency1"] = sum(r["hardware"]["params"]["EXT0_LATENCY"] == 1 for r in dma_runs)
    ev["fabric_req_stall_by_config"] = {r["hardware"]["name"]: r["metrics"]["dma"]["fabric_req_stall_cycles"]
                                        for r in get(recs, "S4_dma_depth") if r["metrics"]["dma"]["fabric_req_stall_cycles"]}
    lat = {}
    for cfg in ("base", "x4", "x8", "d8", "x4_d8", "x8_d8"):
        r = one(recs, "S4_dma_depth", hw=cfg)
        if r:
            lat[cfg] = dict(latency=r["hardware"]["params"]["EXT0_LATENCY"], cycles_per_word=r["timing"]["cycles"] / 4096,
                            mean_outstanding=r["metrics"]["dma"]["mean_outstanding"])
    ev["dma_latency"] = lat
    outs = [r["metrics"]["dma"]["mean_outstanding"] for r in get(recs, "S4_dma_depth") if r["metrics"]["dma"]["mean_outstanding"]]
    ev["max_mean_outstanding"] = max(outs) if outs else None
    w = one(recs, "S4c_kernel_dma", hw="l16_w128")
    b0 = one(recs, "S4c_kernel_dma", hw="base")
    ev["dw128_kernel_gain"] = (w["metrics"]["flop_per_cycle"] / b0["metrics"]["flop_per_cycle"]) if w and b0 else None
    d32 = one(recs, "S4_dma_depth", hw="d32")
    ev["d32_bytes_per_cycle"] = 16384 / d32["timing"]["cycles"] if d32 else None
    simple = [lat[c] for c in ("base", "x4", "x8") if c in lat]
    if len(simple) >= 2:
        ev["simple_cpw_slope_per_latency_cycle"] = (simple[-1]["cycles_per_word"] - simple[0]["cycles_per_word"]) / \
            (simple[-1]["latency"] - simple[0]["latency"])
    # 2. LSU ports
    ports = {c: one(recs, "S6_ports_latency", hw=c, op="FADD") for c in ("p1", "p2", "base")}
    ev["fadd_by_lsu_ports"] = {c: r["metrics"]["elements_per_cycle"] for c, r in ports.items() if r}
    l16 = one(recs, "S1_lanes", hw="l16", op="FMADD", variant="spm")
    l4 = one(recs, "S1_lanes", hw="base", op="FMADD", variant="spm")
    l16w = one(recs, "S1_lanes", hw="l16_w128", op="FMADD", variant="spm")
    ev["l16_over_l4_dw32"] = l16["metrics"]["elements_per_cycle"] / l4["metrics"]["elements_per_cycle"] if l16 and l4 else None
    ev["l16w128_over_l4_dw32"] = l16w["metrics"]["elements_per_cycle"] / l4["metrics"]["elements_per_cycle"] if l16w and l4 else None
    # 3. reduction recurrence
    dots = {c: one(recs, "C1_dot", hw=c, dist="unit") for c in ("base", "l8", "l16")}
    ev["dot"] = {c: dict(elem_per_cycle=r["metrics"]["elements_per_cycle"], lanes=r["hardware"]["params"]["NUM_LANES"],
                         red_bound=r["hardware"]["derived"]["reduction_elems_per_cycle_bound"],
                         lsu_bound=r["hardware"]["derived"]["lsu_ports"] * r["hardware"]["derived"]["lanes_per_word_group"] / 2)
                 for c, r in dots.items() if r}
    # 4. command path
    g8 = one(recs, "D1_gemm", form="axpy", n=8)
    g64 = one(recs, "D1_gemm", form="axpy", n=64)
    ev["gemm8"] = dict(busy_share=g8["timing"]["cycles_tile_busy"] / g8["timing"]["cycles_host_e2e"],
                       e2e_per_cmd=g8["timing"]["cycles_host_e2e"] / g8["timing"]["commands"],
                       exec_per_cmd=g8["timing"]["cycles_cmd_sum"] / g8["timing"]["commands"],
                       flop_per_cycle=g8["metrics"]["flop_per_cycle"]) if g8 else None
    ev["gemm64"] = dict(flop_per_cycle=g64["metrics"]["flop_per_cycle"], fraction_of_peak=g64["metrics"]["fraction_of_peak"],
                        busy_share=g64["timing"]["cycles_tile_busy"] / g64["timing"]["cycles_host_e2e"]) if g64 else None
    hk = an["hockney"]
    # 5. latent: scratchpad latency and contention
    rl4 = one(recs, "S6_ports_latency", hw="rl4", op="FADD")
    base_f = one(recs, "S6_ports_latency", hw="base", op="FADD")
    ev["rl4_fadd_loss"] = 1 - rl4["metrics"]["elements_per_cycle"] / base_f["metrics"]["elements_per_cycle"] if rl4 and base_f else None
    cont = {}
    for k, kw in (("aligned_dma", dict(contention="dma", stagger_words=0)), ("staggered_dma", dict(contention="dma", stagger_words=1)),
                  ("aligned_none", dict(contention="none", stagger_words=0))):
        r = one(recs, "S5_contention", hw="base", **kw)
        if r:
            cont[k] = r["timing"]["cycles"]
    ev["contention"] = cont
    an["bottleneck_evidence"] = ev

    L = []
    if lat:
        latxt = ", ".join(f"{v['cycles_per_word']:.1f} cycles/word at latency {v['latency']}" for k, v in lat.items()
                          if k in ("base", "x4", "x8"))
        L.append(dict(rank=1, where="host memory <-> scratchpad: DMA memory-level parallelism",
                      evidence=f"End-to-end FMA reaches {hd['fma_kernel']['flop_per_cycle']:.3f} FLOP/cycle "
                               f"({pct(hd['fma_kernel']['fraction_of_peak'])} of P_peak), "
                               f"{hd['fma_kernel']['ratio_spm_over_kernel']:.1f}x below the same FMA on scratchpad data. "
                               f"The DMA path sustains {sb['host_memory_base']['bytes_per_cycle']:.2f} B/cycle (simple engine) "
                               f"and {sb.get('host_memory_d8', {}).get('bytes_per_cycle', 0):.2f} B/cycle (buffered, depth 8) "
                               f"of a {sb['host_memory_base']['peak_bytes_per_cycle']:.0f} B/cycle fabric port. The DataFabric "
                               f"crossbar allows at most ONE outstanding transaction per master port (sfb_crossbar.sv header), "
                               f"so the DMA path is round-trip bound: the simple engine costs {latxt} (slope "
                               f"{ev.get('simple_cpw_slope_per_latency_cycle', 0):.2f} cycle per cycle of latency); no buffered "
                               f"depth raised the mean outstanding transactions above {ev['max_mean_outstanding']:.2f} "
                               f"(depth 32: {ev['d32_bytes_per_cycle']:.2f} B/cycle). At host latency 1 the fabric never "
                               f"back-pressured the engine ({ev['fabric_req_stall_cycles_latency1']} stall cycles in "
                               f"{ev['dma_runs_latency1']} runs); at higher latency the buffered engine's extra requests are "
                               f"held by the one-outstanding rule ("
                               + ", ".join(f"{k}: {v:,} stall cycles" for k, v in ev["fabric_req_stall_by_config"].items())
                               + f"). A 128-bit word moves 4x the bytes per round trip: end-to-end FMA "
                               f"x{ev['dw128_kernel_gain']:.2f}.",
                      next_step="memory-level parallelism on the tile's host path: an interconnect port that accepts "
                                "several outstanding (in-order or ID-tagged) transactions, or separate read / write master "
                                "ports; wider fabric words multiply the bytes per round trip. Software double buffering "
                                "only hides the compute share, which is small for streaming kernels"))
    fp = ev["fadd_by_lsu_ports"]
    L.append(dict(rank=2, where="vector unit <-> scratchpad: LSU port bandwidth",
                  evidence=f"On scratchpad data FADD runs at {pct(hd['vadd_spm']['fraction_of_lsu_bound'])} and FMADD at "
                           f"{pct(hd['fma_spm']['fraction_of_lsu_bound'])} of the LSU bound P x LPW / (operands + 1); lane "
                           f"utilisation {pct(hd['fma_spm']['lane_utilisation'])}; every bank busy "
                           f"{pct(min(hd['fma_spm']['bank_utilisation']))} of vector-active cycles. FADD with 1 / 2 / 4 LSU "
                           f"ports: {fp.get('p1', 0):.3f} / {fp.get('p2', 0):.3f} / {fp.get('base', 0):.3f} elements/cycle. "
                           f"16 lanes with 32-bit words: x{ev['l16_over_l4_dw32']:.2f} over 4 lanes; 16 lanes with 128-bit "
                           f"words: x{ev['l16w128_over_l4_dw32']:.2f}. FMA delivers {hd['fma_spm']['flop_per_cycle']:.2f} of "
                           f"{hd['fma_spm']['peak']:.0f} FLOP/cycle.",
                  next_step="wider scratchpad words or more banks + ports per lane group; operand reuse "
                            "(register blocking) for kernels that have it (GEMM, stencils)"))
    if "base" in ev["dot"]:
        d = ev["dot"]
        L.append(dict(rank=3, where="dot product / reductions: accumulator recurrence",
                      evidence=f"At 4 lanes the dot product runs at {d['base']['elem_per_cycle']:.3f} elements/cycle against "
                               f"a reduction bound of N / RED_LAT = {d['base']['red_bound']:.3f} (LSU bound "
                               f"{d['base']['lsu_bound']:.1f}): the single FP32 accumulator with one add in flight limits it. "
                               + (f"At 8 / 16 lanes it reaches {d['l8']['elem_per_cycle']:.3f} / {d['l16']['elem_per_cycle']:.3f} "
                                  f"(LSU bound {d['l8']['lsu_bound']:.1f})." if "l8" in d and "l16" in d else ""),
                      next_step="K interleaved partial accumulators (Module 03 REDUCTION.md sec. 6; changes the defined order)"))
    if ev.get("gemm8"):
        g = ev["gemm8"]
        L.append(dict(rank=4, where="command path for short vectors and multi-command kernels",
                      evidence=f"Fixed command cost: Hockney n_half = {hk['FADD scratchpad (base)']['n_half']:.0f} (FADD) / "
                               f"{hk['FMADD scratchpad (base)']['n_half']:.0f} (FMADD) elements. GEMM n = 8 (64 commands of 8 "
                               f"elements): the tile is busy {pct(g['busy_share'])} of the time; the host needs "
                               f"{g['e2e_per_cmd']:.0f} cycles per command end to end vs {g['exec_per_cmd']:.0f} cycles of "
                               f"execution. GEMM n = 64 reaches {ev['gemm64']['flop_per_cycle']:.2f} FLOP/cycle "
                               f"({pct(ev['gemm64']['fraction_of_peak'])} of P_peak) with the tile busy "
                               f"{pct(ev['gemm64']['busy_share'])}: no operand reuse in the vector forms.",
                      next_step="batched / chained commands or a descriptor ring fetched by DMA; a register-blocked "
                                "GEMM (or a tensor engine) for operand reuse"))
    if ev.get("rl4_fadd_loss") is not None and len(cont) == 3:
        L.append(dict(rank=5, where="latent: scratchpad read latency and port lock-step under contention",
                      evidence=f"Scratchpad read latency 4 costs {pct(ev['rl4_fadd_loss'])} of FADD throughput (latency 2: "
                               f"none): the 2-beat operand FIFOs no longer cover the latency. A concurrent DMA slows a VEC FMADD "
                               f"from {cont['aligned_none']} to {cont['aligned_dma']} cycles with aligned operand bases but to "
                               f"{cont['staggered_dma']} cycles with bases staggered by one word.",
                      next_step="deeper operand FIFOs before slower SRAM macros are adopted; allocate operands bank-aligned "
                                "(documented software rule) or decouple the LSU ports"))
    return L


# ====================================================================== markdown
def write_markdown(allrecs, recs, an):
    R = P.REPORTS
    hd = an["headline"]
    # -------------------------------------------------- per benchmark
    L = ["# Benchmark results (per benchmark)", "",
         "Generated by `scripts/analyse.py` from `reports/runs/**.json`. Cycles are RTL-simulation cycles of the "
         "tile clock; per-second values only where a labelled clock exists (`configs/clocks.json`).", ""]
    groups = [("A", "Vector addition C[i] = A[i] + B[i]"), ("B", "Vector FMA C[i] = A[i] x B[i] + C[i]"),
              ("C", "Dot product"), ("D", "Dense matrix multiplication"),
              ("E", "STREAM-inspired bandwidth (NOT official STREAM)"), ("F", "Stencil / sparse")]
    for bid, title in groups:
        rs = [r for r in allrecs if r["benchmark"]["id"] == bid and r["experiment"]["seed"] == 1]
        if not rs:
            continue
        L += [f"## {bid} - {title}", ""]
        rows = []
        for r in sorted(rs, key=lambda r: r["run_id"]):
            if r["status"] != "VALID":
                rows.append([r["experiment"]["id"], r["run_id"].split("__")[1], r["status"], "-", "-", "-", "-", "-",
                             r["status_reason"][:140]])
                continue
            m = r["metrics"]
            bb = m["boundaries"][0]
            c = r["correctness"]
            cm = "; ".join(f"{k}: {v['mismatches']} / {v['compared']} mismatches" for k, v in c.get("outputs", {}).items())
            if "tolerance" in c:
                cm += f"; max rel err {c['tolerance']['max_rel_err']:.2e} (bound ok: {c['tolerance']['passed']})"
            rows.append([r["experiment"]["id"], r["run_id"].split("__")[1], r["status"], r["timing"]["cycles"],
                         f(m["elements_per_cycle"]), f(m["flop_per_cycle"]),
                         f"{f(bb['bytes_per_cycle'], 2)} ({bb['boundary']})", f(bb["ai_useful"], 4), cm])
        L += [table(["experiment", "point", "status", "cycles", "elem/cyc", "FLOP/cyc", "B/cyc (boundary)",
                     "AI useful", "correctness"], rows), ""]
    (R / "BENCHMARKS.md").write_text("\n".join(L) + "\n")

    # -------------------------------------------------- statistics
    L = ["# Repeatability across seeds", "",
         "Each seed changes the input data (dataset seed) and the testbench host's polling jitter (simulation seed). "
         "`deterministic = yes` means every seed gave the identical value.", "",
         table(["point", "seeds", "distinct datasets", "cycles mean", "cycles min..max", "stdev", "deterministic",
                "host e2e mean", "host e2e stdev", "95 % CI (e2e)"],
               [[s["point"], len(s["seeds"]), s["datasets_distinct"], f(s["cycles"]["mean"], 1),
                 f"{s['cycles']['min']}..{s['cycles']['max']}", f(s["cycles"]["stdev"], 2),
                 "yes" if s["cycles"]["deterministic"] else "no", f(s["host_e2e_cycles"]["mean"], 1),
                 f(s["host_e2e_cycles"]["stdev"], 2), f(s["host_e2e_cycles"]["ci95"], 2)]
                for s in an["seed_statistics"]])]
    (R / "STATISTICS.md").write_text("\n".join(L) + "\n")

    # -------------------------------------------------- scaling
    L = ["# Scaling experiments", "",
         "Scaling efficiency = (P / P_ref) / (units / units_ref), relative to the smallest configuration of the "
         "series. **Arithmetic scaling** = scratchpad-resident data (one VEC command). **End-to-end scaling** = "
         "host-resident data (one KERNEL: DMA in, compute, DMA out).", "", "## Lanes", ""]
    for k, d in an["lane_scaling"].items():
        L += [f"### {d['op']} - {d['variant']} - {d['family']} (reference {d['reference']})", "",
              table(["config", "lanes", "LSU ports", "elem/cyc", "LSU bound", "lane util.", "speed-up", "efficiency"],
                    [[x["config"], x["lanes"], x["lsu_ports"], f(x["elem_per_cycle"]), f(x["lsu_bound"]),
                      pct(x["lane_utilisation"]), f(x["speedup_vs_ref"], 2), pct(x["efficiency_vs_ref"])]
                     for x in d["rows"]]), ""]
    for exp, title, key in (("S2_banks", "Banks and operand placement", None),
                            ("S6_ports_latency", "LSU ports and scratchpad read latency", None),
                            ("S5_contention", "Contention patterns", None)):
        rs = sorted(get(recs, exp), key=lambda r: r["run_id"])
        if not rs:
            continue
        L += [f"## {title} ({exp})", "",
              table(["point", "cycles", "elem/cyc", "SPM conflicts", "conflicts / access", "LSU / DMA / host conflicts",
                     "DMA-vec overlap cycles", "lane util."],
                    [[r["run_id"].split("__")[1], r["timing"]["cycles"], f(r["metrics"]["elements_per_cycle"]),
                      r["metrics"]["scratchpad"]["conflicts"], f(r["metrics"]["scratchpad"]["conflicts_per_access"], 4),
                      f"{r['metrics']['scratchpad']['lsu_conflicts']} / {r['metrics']['scratchpad']['dma_conflicts']} / "
                      f"{r['metrics']['scratchpad']['host_conflicts']}", r["metrics"]["dma"]["overlap_cycles"],
                      pct(r["metrics"]["vector_unit"]["lane_utilisation"])] for r in rs]), ""]
    L += ["## Vector length and transfer size (Hockney model T(n) = t0 + n / r_inf)", "",
          table(["series", "r_inf (per cycle)", "t0 (cycles)", "n_half", "unit", "max residual (cycles)"],
                [[k, f(v.get("r_inf"), 4), f(v.get("t0"), 1), f(v.get("n_half"), 1), v["unit"],
                  f(v.get("max_residual_cycles"), 1)] for k, v in an["hockney"].items()]), ""]
    for exp, title in (("S3_vl", "Vector length, scratchpad (base)"), ("S3b_vl_kernel", "Vector length, KERNEL end to end"),
                       ("S4_dma_depth", "DMA engine depth and host latency (16 KiB h2s)"),
                       ("S4b_dma_size", "DMA transfer size (h2s)"), ("S4c_kernel_dma", "KERNEL FMADD vs DMA path")):
        rs = sorted(get(recs, exp), key=lambda r: (r["hardware"]["name"], r["run_id"]))
        if rs:
            L += [f"## {title} ({exp})", "",
                  table(["point", "cycles", "elem/cyc", "FLOP/cyc", "host B/cyc", "DMA mean outstanding",
                         "DMA active cycles"],
                        [[r["run_id"].split("__")[1], r["timing"]["cycles"], f(r["metrics"]["elements_per_cycle"]),
                          f(r["metrics"]["flop_per_cycle"]),
                          f(bnd(r, "host_memory")["bytes_per_cycle"], 3) if bnd(r, "host_memory") else "-",
                          f(r["metrics"]["dma"]["mean_outstanding"], 3), r["metrics"]["dma"]["active_cycles"]]
                         for r in rs]), ""]
    (R / "SCALING.md").write_text("\n".join(L) + "\n")

    # -------------------------------------------------- roofline
    rf = an["roofline"]
    L = ["# Roofline analysis", "",
         f"P_peak = {rf['peak_flop_per_cycle']:g} FLOP/cycle ({rf['peak_source']}). Each level uses the bandwidth "
         "**measured** at that boundary; values from different boundaries are never mixed in one roof.", ""]
    for lvl, d in rf["levels"].items():
        L += [f"## {lvl}", "",
              f"* sustained bandwidth: **{d['sustained_bytes_per_cycle']:.3f} B/cycle** (measured: {d['bandwidth_source']})",
              f"* port peak at this boundary: {d['port_peak_bytes_per_cycle']:.0f} B/cycle (architectural, not sustained)",
              f"* ridge point: AI = {d['ridge_ai']:.3f} FLOP/B", "",
              table(["kernel", "experiment", "AI (FLOP/B)", "achieved FLOP/cyc", "roofline bound", "of roofline"],
                    [[p["label"], p["experiment"], f(p["ai"], 4), f(p["flop_per_cycle"], 4), f(p["roofline_bound"], 4),
                      pct(p["fraction_of_roofline"])] for p in sorted(d["points"], key=lambda p: p["ai"])]), ""]
    L += ["Charts: `charts/roofline_scratchpad.png`, `charts/roofline_host_simple.png`, "
          "`charts/roofline_host_buffered.png` (data in the matching `.csv`)."]
    (R / "ROOFLINE.md").write_text("\n".join(L) + "\n")

    # -------------------------------------------------- correctness
    c = an["correctness"]
    L = ["# Numerical correctness", "",
         f"* VALID runs: {c['valid_runs']}; every one passed the Module 08 self-check AND the Module 10 independent "
         f"reference (a run that fails either is FAILED, not reported as a result).",
         f"* Bitwise comparisons: {c['bitwise_outputs']} outputs, {c['bitwise_words']:,} words, "
         f"**{c['bitwise_mismatches']} mismatches**; exception flags compared on {c['flags_compared']} commands, "
         f"{c['flags_matched']} identical.",
         f"* Special values in compared outputs: {c['nan_words']:,} NaN, {c['inf_words']:,} infinities, "
         f"{c['subnormal_words']:,} subnormals (NaN compared bitwise: the contract requires 0x7FC00000).",
         f"* Tolerance comparisons against float64 / exact references: {c['tolerance_checks']} runs, "
         f"{c['tolerance_passed']} within their a-priori bound.",
         f"* Counter cross-checks: {c['counter_cross_checks']:,} checks, {c['counter_cross_checks_failed']} failed; "
         f"{c['csv_trace_recounts']} runs also recounted from a per-cycle event trace.", "",
         "## Reference self-test", "", "See `ref_selftest.md` (sfref.c vs the Module 08 model: element operations "
         "and reductions, all rounding modes RNE/RTZ/RDN/RUP).", "", "## Dot product accuracy (C1)", ""]
    rows = []
    for r in sorted(get(recs, "C1_dot"), key=lambda r: r["run_id"]):
        t = r["correctness"]["tolerance"]
        o = r["correctness"]["orders"]
        rows.append([r["run_id"].split("__")[1] + f" s{r['experiment']['seed']}", f"{o['exact']:.6e}",
                     f"{o['abs_err']['hardware']:.2e}", f"{o['abs_err']['sequential_fp32']:.2e}",
                     f"{o['abs_err']['numpy_float32']:.2e}", f"{t['max_err_over_bound']:.3f}",
                     f"{t['condition_number']:.1f}", r["correctness"]["outputs"]["D"]["mismatches"]])
    L += [table(["point", "exact sum", "|err| hardware", "|err| sequential FP32", "|err| numpy float32",
                 "err / bound", "condition", "bitwise vs defined order"], rows), ""]
    for exp, ttl in (("D1_gemm", "GEMM"), ("D2_gemm_lanes", "GEMM across lanes"), ("F1_stencil1d", "1-D stencil"),
                     ("F2_stencil2d", "2-D stencil")):
        rs = sorted(get(recs, exp), key=lambda r: r["run_id"])
        if rs:
            L += [f"## {ttl} ({exp})", "",
                  table(["point", "bitwise mismatches (vs replayed sequence)", "max rel err vs float64",
                         "max err / bound", "within bound"],
                        [[r["run_id"].split("__")[1], next(iter(r["correctness"]["outputs"].values()))["mismatches"],
                          f"{r['correctness']['tolerance']['max_rel_err']:.2e}",
                          f"{r['correctness']['tolerance']['max_err_over_bound']:.3f}",
                          r["correctness"]["tolerance"]["passed"]] for r in rs]), ""]
    rs = get(recs, "X1_ieee")
    if rs:
        L += ["## IEEE-754 at speed (X1)", "",
              table(["point", "words", "mismatches", "NaN", "Inf", "subnormal", "flags hw", "flags ref"],
                    [[r["run_id"].split("__")[1], r["correctness"]["outputs"]["D"]["compared"],
                      r["correctness"]["outputs"]["D"]["mismatches"], r["correctness"]["outputs"]["D"]["nan_count"],
                      r["correctness"]["outputs"]["D"]["inf_count"], r["correctness"]["outputs"]["D"]["subnormal_count"],
                      r["correctness"]["outputs"]["D"].get("flags_hw"), r["correctness"]["outputs"]["D"].get("flags_ref")]
                     for r in sorted(rs, key=lambda r: r["run_id"])]), ""]
    (R / "CORRECTNESS.md").write_text("\n".join(L) + "\n")

    # -------------------------------------------------- FPGA, energy
    synth = json.loads((P.M08 / "reports" / "synth.json").read_text())
    L = ["# Simulation vs FPGA", "",
         "**FPGA results: NOT RUN.** No FPGA board is attached to this environment; no bitstream was generated or "
         "programmed; no hardware counter was read from silicon. Module 10 does not generate synthetic hardware "
         "measurements. The table lists, for each core workload, the RTL-simulation value and the FPGA column that a "
         "board run would fill.", "",
         table(["workload", "RTL simulation (cycles)", "FPGA (cycles)", "discrepancy", "FPGA clock"],
               [[r["run_id"].split("__")[0] + " " + r["run_id"].split("__")[1], r["timing"]["cycles"], "NOT RUN",
                 "n/a", "NOT MEASURED"]
                for r in recs if r["experiment"]["id"] in ("A1_vadd_spm", "A2_vadd_kernel", "B1_fma_spm",
                                                           "B2_fma_kernel", "E3_dma_copy")
                and r["experiment"]["seed"] == 1]), "",
         "## What exists instead (Module 08, labelled estimates)", "",
         "Yosys 0.33 + nextpnr-ecp5 0.11.1 place and route for the ULX3S (LFE5U-85F), copied unmodified in "
         "`third_party/silicaflux-hpc-m08-tile/reports/synth.md`. Post-route Fmax is a tool estimate, not a measured "
         "clock. These are the only clock figures Module 10 uses to express per-second numbers (configs/clocks.json).", "",
         "```", json.dumps(synth, indent=1)[:3000], "```", "",
         "## To run on a board (procedure, not performed)", "",
         "1. Generate a bitstream with a functional harness (the Module 08 FPGA harness is a timing harness only).",
         "2. Run the same command programs (`reports/programs/**.prog.txt.gz`) from firmware on the SilicaFlux-V CPU, "
         "read PERF[0..23] and CPL_CYCLES over the register bus exactly as the simulation host does.",
         "3. Record the measured clock, compare every counter with the matching run record and report discrepancies."]
    (R / "FPGA.md").write_text("\n".join(L) + "\n")
    pw = an["provenance"]["power"]
    L = ["# Energy efficiency", "", f"**Status: {pw['status']}.**", "", pw["reason"], "",
         "GFLOP/s/W is computed only from an entry in `configs/power.json`, which must name its category:", ""]
    L += [f"* **{k}** - {v}" for k, v in pw["categories"].items()]
    L += ["", "FPGA power is never presented as an ASIC prediction; an ASIC estimate requires a validated model. "
              "With no entry, no efficiency figure is produced anywhere in this suite."]
    (R / "ENERGY.md").write_text("\n".join(L) + "\n")

    # -------------------------------------------------- summary
    sb = an["sustained_bandwidth"]
    L = ["# SilicaFlux-HPC Module 10 - benchmark summary", "",
         f"Runs: **{an['counts'].get('VALID', 0)} VALID**, {an['counts'].get('FAILED', 0)} FAILED, "
         f"{an['counts'].get('NOT_RUN', 0)} NOT RUN (unsupported on that configuration, with the reason recorded). "
         "Every VALID run executed on the RTL of `silicaflux_hpc_tile` (Verilator), passed the Module 08 self-check, "
         "matched the Module 10 independent reference and passed every counter cross-check.", "",
         "Time base: RTL-simulation cycles. **FPGA: NOT RUN. Energy: NOT AVAILABLE.**", ""]
    if hd:
        L += ["## Core results (start set: vector add, FMA, bandwidth)", "",
              table(["quantity", "value", "source run"],
                    [["FADD on scratchpad, elements/cycle (LSU bound)",
                      f"{hd['vadd_spm']['elem_per_cycle']:.3f} ({hd['vadd_spm']['lsu_bound']:.3f}) = "
                      f"{pct(hd['vadd_spm']['fraction_of_lsu_bound'])}", hd["vadd_spm"]["run"]],
                     ["FMADD on scratchpad, FLOP/cycle (P_peak)",
                      f"{hd['fma_spm']['flop_per_cycle']:.3f} ({hd['fma_spm']['peak']:.0f}) = "
                      f"{pct(hd['fma_spm']['fraction_of_peak'])}", hd["fma_spm"]["run"]],
                     ["FMADD on scratchpad at the 25 MHz constraint clock (not measured)",
                      f"{hd['fma_spm']['mflops_25mhz']:.1f} MFLOP/s" if hd["fma_spm"]["mflops_25mhz"] else "-",
                      hd["fma_spm"]["run"]],
                     ["lane utilisation, FMADD on scratchpad", pct(hd["fma_spm"]["lane_utilisation"]), hd["fma_spm"]["run"]],
                     ["FMADD end to end (KERNEL), FLOP/cycle simple / buffered DMA",
                      f"{hd['fma_kernel']['flop_per_cycle']:.3f} / {f(hd['fma_kernel']['flop_per_cycle_buffered'])}",
                      hd["fma_kernel"]["run"]],
                     ["sustained scratchpad bandwidth (STREAM-inspired, LSU level)",
                      f"{sb['scratchpad']['bytes_per_cycle']:.2f} B/cycle of {sb['scratchpad']['peak_bytes_per_cycle']:.0f}",
                      sb["scratchpad"]["source"]],
                     ["sustained DMA bandwidth host <-> scratchpad, simple / buffered",
                      f"{sb['host_memory_base']['bytes_per_cycle']:.2f} / {sb.get('host_memory_d8', {}).get('bytes_per_cycle', 0):.2f} "
                      f"B/cycle of {sb['host_memory_base']['peak_bytes_per_cycle']:.0f}", "E3_dma_copy"]]), ""]
    L += ["## Bottlenecks (identified from the core results, in order)", ""]
    for b in an["bottlenecks"]:
        L += [f"{b['rank']}. **{b['where']}** - {b['evidence']} *Next step:* {b['next_step']}.", ""]
    L += ["See `docs/11_bottleneck_analysis.md` for the reasoning and the expansion experiments that test it.", "",
          "## Reports", "", "* `BENCHMARKS.md` - every run, per benchmark", "* `SCALING.md` - lanes, banks, ports, "
          "latency, vector length, DMA depth / size, contention", "* `ROOFLINE.md` + `charts/roofline_*.png`",
          "* `CORRECTNESS.md`, `ref_selftest.md`", "* `STATISTICS.md` - repeatability over seeds",
          "* `FPGA.md` (NOT RUN), `ENERGY.md` (NOT AVAILABLE)", "* `PROVENANCE.md`", "* `dashboard.html`"]
    (R / "SUMMARY.md").write_text("\n".join(L) + "\n")

    # -------------------------------------------------- provenance
    pv = an["provenance"]
    L = ["# Experiment provenance", "",
         f"* Module 10 suite SHA-256 (bench/, kernels/, tb/, scripts/, configs/, schema/): `{pv['suite_sha256']}`",
         f"* Tile RTL SHA-256 ({pv['rtl']['n_rtl_files']} synthesizable files, `files.TILE_SYNTH`): `{pv['rtl']['tile_rtl_sha256']}`",
         f"* Benchmark testbench SHA-256: `{pv['rtl']['testbench_sha256']}`",
         f"* Module 08 source: `{pv['m08_zip_repo_path']}` SHA-256 `{pv['m08_zip_sha256']}`; vendored copy verified "
         f"against its MANIFEST.sha256: **{pv['m08_manifest_verified']}**",
         f"* Datasets: {pv['datasets']} distinct files in `data/` (`data/MANIFEST.json`)",
         f"* Tools: {pv['environment']['tools']}", f"* Machine: {pv['environment']['machine']}",
         f"* Generated: {pv['environment']['utc']}", "", "## Reproduce", "",
         "Each experiment: `make run EXP=<id>` (or `python3 scripts/bench.py run <id>`). Each run: "
         "`python3 scripts/bench.py reproduce <run_id>` re-executes it and compares cycles, all 24 counters, "
         "output hashes and dataset hashes with the record.", "",
         table(["experiment", "runs", "VALID", "NOT_RUN", "FAILED", "command"],
               [[e, len(rs), sum(r["status"] == "VALID" for r in rs), sum(r["status"] == "NOT_RUN" for r in rs),
                 sum(r["status"] == "FAILED" for r in rs), f"`make run EXP={e}`"]
                for e, rs in sorted(A.by_exp(allrecs).items())])]
    (R / "PROVENANCE.md").write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    main()
