/* =============================================================================
 * SilicaFlux-HPC Module 10 :: sfref.c -- independent FP32 reference kernels
 *
 * Implementation strategy: the HOST CPU's IEEE-754 binary32 hardware arithmetic (x86-64 SSE / FMA3), driven
 * through <fenv.h> for the rounding mode and the exception flags.  This shares no code with the SilicaFlux
 * RTL, with the Module 08 Python reference model (model/fp32_model.py) or with Berkeley SoftFloat, so an
 * agreement between this file and the tile is an agreement between two independent implementations.
 *
 * Contract implemented (the RISC-V F-extension semantics documented by Modules 01-03):
 *   * binary32, five flags {NV, DZ, OF, UF, NX} = RISC-V fflags bits 4..0, tininess after rounding;
 *   * subnormals preserved (no FTZ / DAZ: MXCSR.FTZ = MXCSR.DAZ = 0 is checked by sf_env_check);
 *   * every arithmetic NaN result is the canonical quiet NaN 0x7FC00000;
 *   * FMA family fused, ONE rounding: FMADD a*b+c, FMSUB a*b-c, FNMSUB -(a*b)+c, FNMADD -(a*b)-c;
 *     inf*0 in a fused op raises NV even when the addend is a quiet NaN (RISC-V rule, enforced explicitly);
 *   * FMV is a bit copy (no flags);
 *   * rounding modes RNE 0, RTZ 1, RDN 2, RUP 3.  RMM (4, ties-away) has no <fenv.h> equivalent and is NOT
 *     implemented here: sf_vec returns -1 for it (the benchmark suite runs RNE; RMM coverage stays with the
 *     Module 08 SoftFloat-validated model).
 *
 * Reduction order (sf_reduce): Module 03 docs/REDUCTION.md section 1, implemented from the text:
 *   per beat g of N = NUM_LANES elements, a pairwise tree over lane index in which an absent leaf / child is
 *   skipped (never replaced by +-0); then acc = init; acc = acc + S_g strictly in beat order.  Every tree add
 *   and accumulator add rounds to FP32 in the command's rounding mode.  For FMUL this is an UNFUSED dot
 *   product (each product rounded to FP32 before it is summed).
 *
 * Build: gcc -O2 -std=c11 -mfma -ffp-contract=off -frounding-math -fno-fast-math -shared -fPIC
 * ============================================================================= */
#include <fenv.h>
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <xmmintrin.h>

#pragma STDC FENV_ACCESS ON

enum { OP_FMV = 0x00, OP_FADD = 0x01, OP_FSUB = 0x02, OP_FMUL = 0x03,
       OP_FMADD = 0x04, OP_FMSUB = 0x05, OP_FNMSUB = 0x06, OP_FNMADD = 0x07 };
enum { FL_NX = 1, FL_UF = 2, FL_OF = 4, FL_DZ = 8, FL_NV = 16 };
#define CANON_NAN 0x7FC00000u

static inline float u2f(uint32_t u) { float f; memcpy(&f, &u, 4); return f; }
static inline uint32_t f2u(float f) { uint32_t u; memcpy(&u, &f, 4); return u; }

static int set_rm(int rm) {
  switch (rm) {
    case 0: return fesetround(FE_TONEAREST);
    case 1: return fesetround(FE_TOWARDZERO);
    case 2: return fesetround(FE_DOWNWARD);
    case 3: return fesetround(FE_UPWARD);
    default: return -1;
  }
}

static uint32_t flags_now(void) {
  int e = fetestexcept(FE_ALL_EXCEPT);
  return ((e & FE_INVALID) ? FL_NV : 0) | ((e & FE_DIVBYZERO) ? FL_DZ : 0) | ((e & FE_OVERFLOW) ? FL_OF : 0) |
         ((e & FE_UNDERFLOW) ? FL_UF : 0) | ((e & FE_INEXACT) ? FL_NX : 0);
}

/* 0 = environment as required (no FTZ/DAZ), else the MXCSR value */
uint32_t sf_env_check(void) {
  uint32_t m = _mm_getcsr();
  return (m & 0x8040u) ? m : 0u;   /* bit 15 FTZ, bit 6 DAZ */
}

int sf_op_supported(int op, int rm) {
  if (rm < 0 || rm > 3) return 0;
  return op >= OP_FMV && op <= OP_FNMADD;
}

static uint32_t elem(int op, uint32_t a, uint32_t b, uint32_t c, uint32_t *fl) {
  volatile float x = u2f(a), y = u2f(b), z = u2f(c);
  volatile float r = 0.0f;
  if (op == OP_FMV) { *fl = 0; return a; }
  feclearexcept(FE_ALL_EXCEPT);
  switch (op) {
    case OP_FADD:   r = x + y; break;
    case OP_FSUB:   r = x - y; break;
    case OP_FMUL:   r = x * y; break;
    case OP_FMADD:  r = fmaf(x, y, z); break;
    case OP_FMSUB:  r = fmaf(x, y, -z); break;
    case OP_FNMSUB: r = fmaf(-x, y, z); break;
    case OP_FNMADD: r = fmaf(-x, y, -z); break;
    default: break;
  }
  uint32_t f = flags_now();
  if (op >= OP_FMADD && ((isinf(x) && y == 0.0f) || (x == 0.0f && isinf(y)))) f |= FL_NV;
  uint32_t ru = f2u(r);
  if (isnan(r)) ru = CANON_NAN;
  *fl = f;
  return ru;
}

static uint32_t add32(uint32_t a, uint32_t b, uint32_t *fl) { return elem(OP_FADD, a, b, 0, fl); }

/* elementwise D[e] = op(A[e], B[e], C[e]); eflags (optional) per element; *cmd_flags = OR.
 * Returns 0, or -1 if (op, rm) is not implemented by this reference. */
int sf_vec(int op, int rm, int n, const uint32_t *a, const uint32_t *b, const uint32_t *c, uint32_t *d,
           uint32_t *eflags, uint32_t *cmd_flags) {
  if (!sf_op_supported(op, rm)) return -1;
  int saved = fegetround();
  if (set_rm(rm) != 0) return -1;
  uint32_t acc = 0;
  for (int e = 0; e < n; e++) {
    uint32_t f;
    d[e] = elem(op, a[e], b ? b[e] : 0, c ? c[e] : 0, &f);
    if (eflags) eflags[e] = f;
    acc |= f;
  }
  fesetround(saved);
  *cmd_flags = acc;
  return 0;
}

/* Module 03 reduction (see header).  n_lanes in {1,2,4,8,16}. */
int sf_reduce(int op, int rm, int n_lanes, int n, const uint32_t *a, const uint32_t *b, const uint32_t *c,
              uint32_t init, uint32_t *result, uint32_t *cmd_flags) {
  if (!sf_op_supported(op, rm) || n_lanes < 1 || n_lanes > 16 || (n_lanes & (n_lanes - 1))) return -1;
  int saved = fegetround();
  if (set_rm(rm) != 0) return -1;
  uint32_t acc = init, F = 0;
  for (int g = 0; g * n_lanes < n; g++) {
    uint32_t v[16], t[16];
    int p[16], q[16];
    for (int l = 0; l < n_lanes; l++) {
      int e = g * n_lanes + l;
      p[l] = e < n;
      if (p[l]) { uint32_t f; v[l] = elem(op, a[e], b ? b[e] : 0, c ? c[e] : 0, &f); F |= f; }
    }
    for (int w = n_lanes; w > 1; w /= 2) {
      for (int i = 0; i < w / 2; i++) {
        int L = 2 * i, R = 2 * i + 1;
        if (p[L] && p[R]) { uint32_t f; t[i] = add32(v[L], v[R], &f); F |= f; q[i] = 1; }
        else if (p[L])    { t[i] = v[L]; q[i] = 1; }
        else if (p[R])    { t[i] = v[R]; q[i] = 1; }
        else              { q[i] = 0; }
      }
      for (int i = 0; i < w / 2; i++) { v[i] = t[i]; p[i] = q[i]; }
    }
    if (p[0]) { uint32_t f; acc = add32(acc, v[0], &f); F |= f; }
  }
  fesetround(saved);
  *result = acc;
  *cmd_flags = F;
  return 0;
}
