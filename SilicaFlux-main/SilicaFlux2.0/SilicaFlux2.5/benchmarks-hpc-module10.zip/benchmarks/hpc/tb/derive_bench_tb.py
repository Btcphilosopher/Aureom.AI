#!/usr/bin/env python3
"""Derive the Module 10 benchmark testbench tb/tb_hpc_bench.sv from the UNMODIFIED Module 08 integration
testbench (third_party/silicaflux-hpc-m08-tile/tb/tb_silicaflux_hpc_tile.sv).

Why a derived file instead of an edited copy: the M08 testbench is the verified host + fabric environment of
the tile (real DataFabric crossbar, SRAM slaves, peripheral bridge, SFB2 protocol checkers, self-checking
completion / memory / counter comparison against the M08 reference model).  Module 10 keeps all of that and
only ADDS observation:

  * PERFDUMP <label>      read all 24 PERF[i] registers over the register bus (the real host path) and print
                          them next to the testbench's independent port monitors (M08 `mon[]`) and the new
                          trace monitor below.  Programs freeze the counters first (CFG 3) so the dump is a
                          coherent snapshot.
  * DUMP <addr> <bytes> <name>
                          write the tile's actual output words to <dumpdir>/<name>.hex.  External memory is
                          read through the backdoor; scratchpad words are read by the host through the SFB2
                          scratchpad window.  These words are compared by Module 10 with its own independent
                          reference kernels (benchmarks/hpc/kernels/ref/sfref.c), not with the M08 model.
  * TB_BENCH CPLX         with +trace_cpl, every completion record's FFLAGS and RESULT as read by the host (the
                          independent reference compares flags and reduction results with them)
  * CSVON / CSVOFF        per-cycle event trace (+evtrace=<file>) for the counter cross-check.
  * an event-trace monitor that observes RTL handshakes directly (array operand / result channels, LSU job
    state, scratchpad ports and banks, DMA adapter fabric port).  Its window is the counter window: cleared by
    PERF_CLEAR, held while PERF_FREEZE.

Every insertion is anchored on an exact line of the M08 file, and the input file's SHA-256 is checked, so the
derivation fails loudly if the vendored testbench ever changes.  Nothing of the M08 testbench is removed.
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "third_party/silicaflux-hpc-m08-tile/tb/tb_silicaflux_hpc_tile.sv"
DST = HERE / "tb_hpc_bench.sv"
SRC_SHA256 = None  # filled from the M08 MANIFEST below (single source of truth)


def manifest_sha(rel: str) -> str:
    man = HERE.parent / "third_party/silicaflux-hpc-m08-tile/MANIFEST.sha256"
    for line in man.read_text().splitlines():
        h, p = line.split(None, 1)
        if p.strip() == rel:
            return h
    raise SystemExit(f"{rel} not in the M08 manifest")


TRACE_BLOCK = r"""
  // ============================================================ M10: independent event-trace monitor
  // Observes RTL handshakes and events directly; it does NOT read the tile's counter block.  Window = the
  // hardware counters' window (cleared by PERF_CLEAR, held while PERF_FREEZE), so every count below is
  // directly comparable with a PERF[i] register value.  Names are printed by PERFDUMP.
  localparam int TR_N = 26;
  localparam int TR_CYC = 0, TR_LSU_BUSY = 1, TR_BEAT_IN = 2, TR_ELEM_IN = 3, TR_OPND_STALL = 4,
                 TR_LSU_STARVE = 5, TR_BEAT_OUT = 6, TR_ELEM_OUT = 7, TR_RES_BP = 8, TR_FMA_RET = 9,
                 TR_FLOP_RET = 10, TR_ARR_CPL = 11, TR_ARR_CPL_ELEMS = 12, TR_BANK_OPS = 13,
                 TR_LSU_ACC = 14, TR_LSU_CONF = 15, TR_DMA_SPM_ACC = 16, TR_DMA_SPM_CONF = 17,
                 TR_HOST_SPM_CONF = 18, TR_FAB_REQ = 19, TR_FAB_REQ_STALL = 20, TR_FAB_RSP = 21,
                 TR_FAB_WAIT = 22, TR_DMA_ACTIVE = 23, TR_DMA_OUT_SUM = 24, TR_DMA_REQ_STALL = 25;
  longint unsigned tr [TR_N];
  longint unsigned tr_bank [NB];
  localparam int TR_NP = T_NPORTS;
  longint unsigned tr_port_acc [TR_NP];
  longint unsigned tr_port_conf [TR_NP];
  int              tr_fab_out = 0;
  int              csv_fd = 0;
  bit              csv_on = 1'b0;
  function automatic int tr_pop(input logic [NUM_LANES-1:0] m);
    tr_pop = 0;
    for (int i = 0; i < NUM_LANES; i++) tr_pop += int'(m[i]);
  endfunction
  function automatic int tr_flop_w(input logic [4:0] op);
    // the operation-count convention of PERF[VEC_FLOPS] (hpc_tile_defs.svh): FADD/FSUB/FMUL 1, FMA family 2
    if (op == 5'h01 || op == 5'h02 || op == 5'h03) tr_flop_w = 1;
    else if (op >= 5'h04 && op <= 5'h07)            tr_flop_w = 2;
    else                                            tr_flop_w = 0;
  endfunction
  logic [4:0]  tr_op;
  int          tr_ein, tr_eout, tr_bops, tr_ld, tr_st;
  logic [7:0]  tr_conf;
  always @(posedge clk) begin
    if (!rst_n) begin
      foreach (tr[i]) tr[i] = 0;
      foreach (tr_bank[i]) tr_bank[i] = 0;
      foreach (tr_port_acc[i]) begin tr_port_acc[i] = 0; tr_port_conf[i] = 0; end
      tr_fab_out = 0;
    end else begin
      tr_op   = dut.g_core.u_lsu.op_q;
      tr_ein  = (dut.g_core.a_opnd_valid && dut.g_core.a_opnd_ready) ? tr_pop(dut.g_core.a_opnd_mask) : 0;
      tr_eout = (dut.g_core.a_res_valid && dut.g_core.a_res_ready) ? tr_pop(dut.g_core.a_res_mask) : 0;
      tr_bops = 0;
      tr_ld = 0; tr_st = 0; tr_conf = '0;
      for (int b = 0; b < NB; b++) tr_bops += int'(dut.g_core.u_spm.ev_bank_ops[b*2 +: 2]);
      for (int p = 0; p < T_LSUP; p++) begin
        tr_ld += int'(dut.g_core.s_req_valid[p] && dut.g_core.s_req_ready[p] && !dut.g_core.s_req_we[p]);
        tr_st += int'(dut.g_core.s_req_valid[p] && dut.g_core.s_req_ready[p] &&  dut.g_core.s_req_we[p]);
      end
      for (int p = 0; p < T_NPORTS; p++) tr_conf[p] = dut.g_core.s_ev_conflict[p];
      if (csv_on && csv_fd != 0 && pclear) $fdisplay(csv_fd, "CLR,%0d", cyc);
      if (csv_on && csv_fd != 0 && !pclear && !frozen &&
          (dut.g_core.dma_active || dut.g_core.lsu_busy || tr_conf != 0 || tr_ld != 0 || tr_st != 0 || tr_bops != 0))
        $fdisplay(csv_fd, "%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
                  cyc, dut.g_core.dma_active, dut.g_core.lsu_busy, dut.g_core.a_opnd_valid, dut.g_core.a_opnd_ready,
                  tr_ein, dut.g_core.a_res_valid, dut.g_core.a_res_ready, tr_eout, tr_ld, tr_st,
                  tr_conf, tr_bops, m_req_valid[1] && m_req_ready[1], m_rsp_valid[1] && m_rsp_ready[1],
                  m_req_valid[1] && !m_req_ready[1], tr_flop_w(tr_op) * tr_eout);
      if (pclear) begin
        foreach (tr[i]) tr[i] = 0;
        foreach (tr_bank[i]) tr_bank[i] = 0;
        foreach (tr_port_acc[i]) begin tr_port_acc[i] = 0; tr_port_conf[i] = 0; end
      end else if (!frozen) begin
        tr[TR_CYC]++;
        tr[TR_LSU_BUSY]      += dut.g_core.lsu_busy;
        tr[TR_BEAT_IN]       += (dut.g_core.a_opnd_valid && dut.g_core.a_opnd_ready);
        tr[TR_ELEM_IN]       += tr_ein;
        tr[TR_OPND_STALL]    += (dut.g_core.a_opnd_valid && !dut.g_core.a_opnd_ready);
        tr[TR_LSU_STARVE]    += (dut.g_core.lsu_busy && !dut.g_core.a_opnd_valid);
        tr[TR_BEAT_OUT]      += (dut.g_core.a_res_valid && dut.g_core.a_res_ready);
        tr[TR_ELEM_OUT]      += tr_eout;
        tr[TR_RES_BP]        += (dut.g_core.a_res_valid && !dut.g_core.a_res_ready);
        tr[TR_FMA_RET]       += (tr_op >= 5'h04 && tr_op <= 5'h07) ? tr_eout : 0;
        tr[TR_FLOP_RET]      += tr_flop_w(tr_op) * tr_eout;
        tr[TR_ARR_CPL]       += (dut.g_core.a_cpl_valid && dut.g_core.a_cpl_ready);
        tr[TR_ARR_CPL_ELEMS] += (dut.g_core.a_cpl_valid && dut.g_core.a_cpl_ready) ? dut.g_core.a_cpl_count : 0;
        tr[TR_BANK_OPS]      += tr_bops;
        tr[TR_LSU_ACC]       += tr_ld + tr_st;
        for (int p = 0; p < T_LSUP; p++) tr[TR_LSU_CONF] += dut.g_core.s_ev_conflict[p];
        tr[TR_DMA_SPM_ACC]   += (dut.g_core.s_req_valid[PD] && dut.g_core.s_req_ready[PD]);
        tr[TR_DMA_SPM_CONF]  += dut.g_core.s_ev_conflict[PD];
        tr[TR_HOST_SPM_CONF] += dut.g_core.s_ev_conflict[PD + 1];
        tr[TR_FAB_REQ]       += (m_req_valid[1] && m_req_ready[1]);
        tr[TR_FAB_REQ_STALL] += (m_req_valid[1] && !m_req_ready[1]);
        tr[TR_FAB_RSP]       += (m_rsp_valid[1] && m_rsp_ready[1]);
        tr[TR_FAB_WAIT]      += (tr_fab_out > 0 && !(m_rsp_valid[1] && m_rsp_ready[1]) && !(m_req_valid[1]));
        tr[TR_DMA_ACTIVE]    += dut.g_core.dma_active;
        tr[TR_DMA_OUT_SUM]   += dut.g_core.u_dma.ev_outstanding;
        tr[TR_DMA_REQ_STALL] += dut.g_core.u_dma.ev_req_stall;
        for (int b = 0; b < NB; b++) tr_bank[b] += dut.g_core.u_spm.ev_bank_ops[b*2 +: 2];
        for (int p = 0; p < T_NPORTS; p++) begin
          tr_port_acc[p]  += (dut.g_core.s_req_valid[p] && dut.g_core.s_req_ready[p]);
          tr_port_conf[p] += dut.g_core.s_ev_conflict[p];
        end
      end
      if (!dut.g_core.tile_rst_n) tr_fab_out = 0;
      else tr_fab_out += int'(m_req_valid[1] && m_req_ready[1]) - int'(m_rsp_valid[1] && m_rsp_ready[1]);
    end
  end
"""

OPS_BLOCK = r"""      end else if (op == "PERFDUMP") begin   // M10: coherent counter snapshot (program froze the counters)
        string s_hw, s_mon, s_tr, s_bank, s_pacc, s_pconf;
        s_hw = ""; s_mon = ""; s_tr = ""; s_bank = ""; s_pacc = ""; s_pconf = "";
        for (int i = 0; i < NPC; i++) begin
          reg_rd(`HPC_REG_PERF0 + 12'(4 * i), v, e);
          if (e) fail($sformatf("PERFDUMP: PERF[%0d] read error", i));
          if (i != 0) begin s_hw = {s_hw, ","}; s_mon = {s_mon, ","}; end
          s_hw  = {s_hw,  $sformatf("%0d", v)};
          s_mon = {s_mon, $sformatf("%0d", monitored(i) ? longint'(mon[i]) : -64'sd1)};
        end
        for (int i = 0; i < TR_N; i++) begin if (i != 0) s_tr = {s_tr, ","}; s_tr = {s_tr, $sformatf("%0d", tr[i])}; end
        for (int b = 0; b < NB; b++) begin if (b != 0) s_bank = {s_bank, ","}; s_bank = {s_bank, $sformatf("%0d", tr_bank[b])}; end
        for (int p = 0; p < TR_NP; p++) begin
          if (p != 0) begin s_pacc = {s_pacc, ","}; s_pconf = {s_pconf, ","}; end
          s_pacc  = {s_pacc,  $sformatf("%0d", tr_port_acc[p])};
          s_pconf = {s_pconf, $sformatf("%0d", tr_port_conf[p])};
        end
        $display("TB_BENCH PERFDUMP %s cycle=%0d hw=%s mon=%s trace=%s bank_ops=%s port_acc=%s port_conf=%s",
                 t[1], cyc, s_hw, s_mon, s_tr, s_bank, s_pacc, s_pconf);
      end else if (op == "DUMP") begin       // M10: actual output words -> <dumpdir>/<name>.hex
        int dfd;
        logic [31:0] da, dn, dv;
        bit de;
        da = hx(t[1]); dn = hx(t[2]);
        dfd = $fopen({dump_dir, "/", t[3], ".hex"}, "w");
        if (dfd == 0) fail({"DUMP: cannot open ", dump_dir, "/", t[3], ".hex"});
        else begin
          for (int unsigned k = 0; k < dn; k += 4) begin
            logic [31:0] a;
            a = da + k;
            if (is_spm(a)) begin host32_rd(a, dv, de); if (de) fail($sformatf("DUMP: host read %h error", a)); end
            else dv = ext_bd_rd(a);
            $fdisplay(dfd, "%08h %08h", a, dv);
          end
          $fclose(dfd);
          $display("TB_BENCH DUMP %s addr=%08h bytes=%0d", t[3], da, dn);
        end
      end else if (op == "CSVON") begin
        if (evtrace_file != "" && csv_fd == 0) begin
          csv_fd = $fopen(evtrace_file, "w");
          $fdisplay(csv_fd, "cyc,dma_active,lsu_busy,opnd_valid,opnd_ready,elem_in,res_valid,res_ready,elem_out,lsu_loads,lsu_stores,conflict_mask,bank_ops,fab_req,fab_rsp,fab_req_stall,flop_ret");
        end
        csv_on = 1'b1;
      end else if (op == "CSVOFF") begin
        csv_on = 1'b0;
        if (csv_fd != 0) begin $fclose(csv_fd); csv_fd = 0; end
"""

DECL_BLOCK = r"""  string dump_dir = ".", evtrace_file = "";     // M10
"""

PLUSARG_BLOCK = r"""    void'($value$plusargs("dumpdir=%s", dump_dir));          // M10
    void'($value$plusargs("evtrace=%s", evtrace_file));      // M10
"""

CPLX_BLOCK = r"""      $display("TB_BENCH CPLX seq=%0d flags=%0h result=%08h step=%0d detail=%0d", f[6], f[4], f[8], f[5], f[3]);   // M10
"""

HEADER = """// =============================================================================
// SilicaFlux-HPC Module 10 :: tb_hpc_bench  (GENERATED -- do not edit)
// Generated by benchmarks/hpc/tb/derive_bench_tb.py from the unmodified Module 08 testbench
//   third_party/silicaflux-hpc-m08-tile/tb/tb_silicaflux_hpc_tile.sv  sha256 {sha}
// Additions are marked "M10".  Nothing of the M08 testbench is removed or changed: the tile, the DataFabric
// crossbar, the SRAM slaves, the peripheral bridge, the SFB2 protocol checkers and every M08 self-check
// (completion records, final memory, counters vs the M08 reference model) are exactly as verified in M08.
// =============================================================================
"""


def insert_after(text: str, anchor: str, block: str) -> str:
    n = text.count(anchor)
    if n != 1:
        raise SystemExit(f"anchor found {n} times (need 1): {anchor!r}")
    return text.replace(anchor, anchor + block, 1)


def insert_before(text: str, anchor: str, block: str) -> str:
    n = text.count(anchor)
    if n != 1:
        raise SystemExit(f"anchor found {n} times (need 1): {anchor!r}")
    return text.replace(anchor, block + anchor, 1)


def main() -> int:
    raw = SRC.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    want = manifest_sha("tb/tb_silicaflux_hpc_tile.sv")
    if sha != want:
        raise SystemExit(f"M08 testbench hash {sha} != manifest {want}: refusing to derive")
    t = raw.decode()
    t = t.replace("module tb_silicaflux_hpc_tile", "module tb_hpc_bench", 1)
    t = insert_before(t, "  // completion contract of the vector unit: when the LSU reports done", TRACE_BLOCK + "\n")
    t = insert_before(t, "      end else if (op == \"END\") done = 1'b1;", OPS_BLOCK)
    t = insert_after(t, "  bit          trace_cpl = 0;\n", DECL_BLOCK)
    t = insert_after(t, "    trace_cpl = $test$plusargs(\"trace_cpl\");\n", PLUSARG_BLOCK)
    t = insert_after(t, '      $display("TB_TILE CPL seq=%0d tag=%0h type=%0d status=%0d count=%0d cycles=%0d", f[6], f[0], f[2], f[1], f[7], v);\n',
                     CPLX_BLOCK)
    DST.write_text(HEADER.format(sha=sha) + t)
    print(f"wrote {DST.relative_to(HERE.parent)} from M08 testbench sha256 {sha[:16]}...")
    return 0


if __name__ == "__main__":
    sys.exit(main())
