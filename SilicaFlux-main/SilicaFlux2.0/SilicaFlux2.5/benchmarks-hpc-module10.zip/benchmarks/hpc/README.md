# SilicaFlux-HPC · Module 10 — Scientific computing benchmark and performance analysis suite

Aureom.AI | SilicaFlux-HPC · target directory `benchmarks/hpc/`

A reproducible benchmark framework for the SilicaFlux-HPC compute tile (`silicaflux_hpc_tile`, Module 08). It
measures useful computation, memory performance, arithmetic efficiency and architectural bottlenecks by
**executing real workloads on the tile's RTL**:

* every output is checked against an independent reference;
* every counter is cross-checked against simulation traces;
* every run is stored as a schema-validated record with its datasets, logs and a reproduction command.

Nothing on the dashboard is fabricated: it is generated from the run records.

**Time base: RTL-simulation clock cycles (Verilator). FPGA: NOT RUN (no board). Energy: NOT AVAILABLE (no
defensible power figure).** Per-second values appear only at the labelled 25 MHz place-and-route constraint
(an estimate, not a measured clock), and only for the two configurations that were placed and routed.

## Results at a glance (`reports/SUMMARY.md`, `reports/dashboard.html`)

364 runs: **361 VALID, 0 FAILED, 3 NOT RUN** (tensor engine absent; stencil on 128-bit words; SpMV needs
gather).

| Base tile (4 FP32 lanes, 32-bit words, 64 KiB / 4 banks, simple DMA) | Measured |
|---|---|
| FADD, scratchpad-resident (A1) | 1.329 elements/cycle = 99.7 % of the LSU port bound |
| FMADD in place, scratchpad-resident (B1) | 1.995 FLOP/cycle = 24.9 % of P_peak (8); 49.9 MFLOP/s at the 25 MHz constraint |
| FMADD end to end, host memory (B2) | 0.118 FLOP/cycle (simple DMA), 0.182 (buffered) |
| sustained scratchpad bandwidth (E1, STREAM-inspired) | 15.96 B/cycle of 16 |
| sustained DMA bandwidth (E3) | 1.00 B/cycle (simple), 1.60 (buffered) of a 4 B/cycle port |
| dot product (C1), 4 / 16 lanes | 2.60 / 3.79 FLOP/cycle; bitwise equal to the defined reduction order |
| GEMM n = 64, vector axpy form (D1) | 2.21 FLOP/cycle (28 % of P_peak) |
| 1-D stencil (F1) | 2.49 FLOP/cycle |
| correctness | 561,029 output words bitwise, 0 mismatches; FFLAGS identical on 293 / 293 commands; 67 / 67 runs within a-priori error bounds |
| counter cross-checks | 10,993 checks, 0 failed (+ 12 per-cycle trace recounts) |

**Next architectural bottleneck** (doc 11): the host-memory path's memory-level parallelism.

* The DataFabric crossbar allows one outstanding transaction per master port, so DMA is round-trip bound:
  3 + latency cycles per word (simple engine), never more than 0.95 transactions in flight (buffered).
* Host-resident streaming runs at 1.5–2.3 % of P_peak.
* On the compute side, the scratchpad LSU ports bind: FMA reaches 25 % of P_peak, and more than 4 lanes are
  idle with 32-bit words; 128-bit words lift it ×3.89.

## Quick start

```bash
make all
```

```bash
make core
```

```bash
make reproduce RUN=B1_fma_spm__base_opFMADD_variantspm_inplace_vl4096__s1
```

```bash
make report
```

Requirements: Verilator 5.020, Python ≥ 3.10 (numpy, jsonschema, matplotlib), gcc with x86-64 FMA3. See
`docs/10_reproducibility.md`.

## Layout

| Path | Content |
|---|---|
| `bench/` | framework: hardware configs and build (`hw.py`), programs and runs (`sim.py`), workload drivers (`workloads.py`), reference bindings and comparison metrics (`ref.py`), counter collector and cross-checks (`counters.py`), performance equations (`equations.py`), runner and record writer (`runner.py`), statistics, scaling, roofline (`analysis.py`), datasets, provenance |
| `kernels/ref/sfref.c` | independent reference kernels (host IEEE-754 hardware, `<fenv.h>`) |
| `tb/` | `derive_bench_tb.py` → `tb_hpc_bench.sv` (the M08 testbench plus observation) |
| `scripts/` | `bench.py` (run / reproduce / validate / list), `selftest_ref.py`, `analyse.py`, `plots.py`, `make_dashboard.py` |
| `configs/` | `hardware.json` (26 configurations), `experiments/*.json` (24 experiments), `clocks.json`, `power.json` |
| `schema/run_record.schema.json` | machine-readable run-record schema (JSON Schema 2020-12) |
| `data/` | every input dataset (content-addressed binary32) + manifest |
| `reports/` | run records, counter dumps, logs, programs, outputs, traces, charts, markdown reports, `dashboard.html` |
| `docs/` | 00 audit … 11 bottleneck analysis |
| `third_party/silicaflux-hpc-m08-tile/` | Module 08, unmodified (verified against its MANIFEST.sha256; raw synthesis logs omitted, summaries kept) |

## Documentation

| Doc | Topic |
|---|---|
| [00](docs/00_repository_audit.md) | repository audit: what exists, which measurements are genuinely possible |
| [01](docs/01_methodology.md) | methodology, testbench derivation, timing sources, acceptance criteria |
| [02](docs/02_workloads.md) | workloads A–F, X1: commands, operation counts, data movement, verification |
| [03](docs/03_performance_equations.md) | P_peak, P_effective, B_effective, AI, roofline; memory boundaries; clocks |
| [04](docs/04_counters_and_traces.md) | hardware counters, trace monitor, cross-checks |
| [05](docs/05_numerical_correctness.md) | bitwise and tolerance policy, error bounds, NaN / Inf rules |
| [06](docs/06_scaling.md) | lanes, banks, vector length, DMA buffer, contention, ports, latency |
| [07](docs/07_roofline.md) | hierarchical roofline with measured bandwidths |
| [08](docs/08_energy.md) | energy efficiency: NOT AVAILABLE, and why |
| [09](docs/09_fpga.md) | FPGA: NOT RUN; labelled estimates; board procedure |
| [10](docs/10_reproducibility.md) | commands, saved artifacts, determinism |
| [11](docs/11_bottleneck_analysis.md) | from the start set to the next architectural bottleneck |

## What is not claimed

* no FPGA or silicon measurement, and no measured clock frequency;
* no power or energy figure;
* no tensor-engine result (there is no tensor engine in the tile);
* no SpMV (no gather support);
* not official STREAM;
* RMM rounding is not covered by the Module 10 reference (the benchmarks use RNE);
* the modelled results of BandwidthLab / MemoryLab are not used anywhere.
