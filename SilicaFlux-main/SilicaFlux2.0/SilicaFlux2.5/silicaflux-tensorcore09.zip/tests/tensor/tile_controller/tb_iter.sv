// =============================================================================
// SilicaFlux TENSORCORE 09 :: tb_iter -- cocotb wrapper of the tile iterator
// DUT: TENSORCORE 06 ttc_tile_iter (both scheduler streams of TC08 use it), unmodified.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_iter #(
  parameter int TILE_M = 4,
  parameter int TILE_N = 4,
  localparam int MW = $clog2(TILE_M + 1),
  localparam int NW = $clog2(TILE_N + 1)
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        init,
  input  wire logic        adv,
  input  wire logic        nmajor,
  input  wire logic [15:0] m,
  input  wire logic [15:0] n,
  input  wire logic [16:0] k,
  input  wire logic [16:0] kc,
  output logic [15:0]      m0,
  output logic [15:0]      n0,
  output logic [16:0]      k0,
  output logic [15:0]      kidx,
  output logic [MW-1:0]    eff_m,
  output logic [NW-1:0]    eff_n,
  output logic [16:0]      eff_k,
  output logic             first_k,
  output logic             last_k,
  output logic             last_step,
  output logic             done,
  output logic [31:0]      step_idx
);
  ttc_tile_iter #(.TILE_M(TILE_M), .TILE_N(TILE_N)) dut (.*);
  chk_reset #(.N(1), .NK(3)) chk_rst (.clk(clk), .rst_n(rst_n), .quiet(done), .known({done, last_step, first_k}));
endmodule
`default_nettype wire
