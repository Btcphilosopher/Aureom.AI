"""Scheduler (tile controller) verification on the complete unit: TC08 tsu_sched driving the
TC06 iterators, the TC07 DMA adapter and compute sequencer.

The scheduler's outputs are observed directly (common/tsu_env.py stream monitor): every DMA
descriptor (kind, source / destination, strides, row length, rows, SEAL), every compute job
(eff_m, eff_n, eff_k, K, chunk count / index, local strides) and every TC05 OPEN must equal
the tile schedule of reference_models/tsu_model.py, in order.  Records, memory and traffic
scoreboards as in the integration suite.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
try:
    import cocotb  # noqa: F401
    from common.harness import tensor_test, pick, FallingEdge
    from common.tsu_tests import setup, finish, gemm_cmd, HW, CHECKERS, Alloc, make_gemm, Cmd, T
except ImportError:
    tensor_test = None
from common.tsu_tests import cfg, cfg_id, run_tsu  # noqa: E402


async def hard_reset(env, cycles=3):
    """Hard reset mid-run (SFB2 R11: every transaction in flight is cancelled).  Commands that
    did not produce a record before the reset produce none; their C becomes undefined."""
    d = env.dut
    await env.collect()
    done = len(env.records)
    d.rst_n.value = 0
    for _ in range(cycles):
        await FallingEdge(d.clk)
    d.rst_n.value = 1
    await FallingEdge(d.clk)
    lost = env.cmds[done:]
    for c in lost:
        if c.gemm is not None:
            env.undef |= T.c_footprint(c.gemm)
    env.cmds = env.cmds[:done]
    env.check_records()
    env.n_sub = 0
    env.sticky = False
    await env.set_ctrl(env.err_cont)
    env.records, env.cmds = [], []
    if env.streams is not None:
        env.streams = dict(desc=[], job=[], q=[])
    return lost


if tensor_test is not None:

    @tensor_test(checkers=CHECKERS, timeout_us=60000)
    async def tiles_and_chunks(dut, rng, cov):
        """One tile; multiple tiles (M-major and N-major); multiple K chunks (default KC, small KC,
        KC = 1); partial edge tiles in M, N and K; streams compared field by field."""
        env = await setup(dut, rng, cov, streams=True)
        al = Alloc(HW, rng)
        R, C, TK = HW.rows, HW.cols, HW.tile_k
        shapes = [(R, C, 16, 0, False, "one_tile"), (3 * R, 2 * C + 1, 10, 0, False, "tiles_mmajor"),
                  (2 * R + 1, 3 * C, 10, 0, True, "tiles_nmajor"), (R, C, 3 * TK + 5, 0, False, "k_chunks"),
                  (R + 1, C - 1 if C > 1 else 1, 50, 7, False, "small_kc"), (2, 3, 9, 1, False, "kc_1"),
                  (R + 3, C + 2, TK + 1, 0, True, "partial_all")]
        cmds = []
        for m, n, k, kc, nm, label in shapes:
            cmds.append(gemm_cmd(make_gemm(HW, al, rng, m, n, k, kc=kc, nmajor=nm, prefetch=HW.dbuf), label))
            cov.hit("sched", label)
        await env.run(cmds)
        await finish(env)

    @tensor_test(checkers=CHECKERS, timeout_us=60000)
    async def invalid_commands_have_no_side_effect(dut, rng, cov):
        """Every validation rule at its boundary: ERROR record with the rule's code, and no bus
        transaction, no DMA descriptor, no compute job for the rejected command."""
        env = await setup(dut, rng, cov, streams=True)
        lo, hi = HW.mem_lo, HW.mem_hi
        ok = T.Gemm(a=lo + 0x100, b=lo + 0x1000, c=lo + 0x2000, m=4, n=4, k=8, lda=8, ldb=4, ldc=16)
        W = T.with_
        bad = [("version", W(ok, version=3)), ("opcode", W(ok, opcode=0x41)), ("flags", W(ok, flags_raw=0x10)),
               ("rsvd_h15", W(ok, poke_or={0: 1 << 15})), ("rsvd_w9", W(ok, poke_or={9: 1 << 20})),
               ("rsvd_int32_relu", W(ok, relu=True)), ("layout", W(ok, layouts=(0, 1, 0))),
               ("precision_type", W(ok, a_type=1)), ("precision_ofmt", W(ok, ofmt_raw=2)),
               ("dim_zero_m", W(ok, m=0)), ("dim_zero_k", W(ok, k=0)), ("chunk", W(ok, kc=HW.tile_k + 1)),
               ("ld_a", W(ok, lda=7)), ("ld_c", W(ok, ldc=15)), ("align", W(ok, c=lo + 0x2002, ldc=20)),
               ("addr_ovf", W(ok, a=(1 << 32) - 8, lda=8)), ("range_low", W(ok, a=lo - 4)),
               ("range_high", W(ok, c=hi - 60)), ("alias", W(ok, c=lo + 0x1000 + 8)),
               ("ld_b", W(ok, ldb=3))]
        if not HW.dbuf:
            bad.append(("flags_prefetch", W(ok, prefetch=True)))
        if not HW.quant:
            bad.append(("precision_int8", W(ok, out_int8=True, ldc=4)))
        else:
            bad.append(("rm_int8", W(ok, out_int8=True, ldc=4, rm=6)))
        if HW.k_max < 131071:
            bad.append(("dim_range", W(ok, k=HW.k_max + 1, lda=HW.k_max + 1)))
        bad.append(("nop_rsvd", None))
        cmds = []
        for label, g in bad:
            if g is None:
                w = T.nop(tid=7)
                w[3] = 1
                cmds.append(Cmd(w, None, label))
            else:
                cmds.append(Cmd(g.words(), g, label))
        cmds.append(gemm_cmd(ok, "valid_after"))                     # the unit still works afterwards
        await env.run(cmds)
        for c in cmds[:-1]:
            assert c.record["status"] == T.ST_ERROR and c.record["count"] == 0, (c.label, c.record)
            cov.hit("rule", T.E_NAMES[c.record["err"]])
        # the only traffic of the whole run is the final valid command
        assert len(env.mem.reads) == len(T.read_words(ok, HW)) and len(env.mem.writes) == len(T.write_words(ok, HW))
        await finish(env)

    @tensor_test(checkers=CHECKERS, timeout_us=80000)
    async def completion_queue_backpressure(dut, rng, cov):
        """The host does not pop records while many commands complete: the completion queue fills,
        the scheduler waits (CPL_STALL), nothing is lost or reordered; memory backpressure too."""
        env = await setup(dut, rng, cov, streams=True)
        env.mem.bp_p = 0.6
        env.mem.lat = (1, 6)
        al = Alloc(HW, rng)
        cmds = [gemm_cmd(make_gemm(HW, al, rng, rng.randint(1, 6), rng.randint(1, 6), rng.randint(1, 20)))
                for _ in range(HW.cmdq + HW.cplq + 2)]
        for c in cmds[:HW.cmdq]:
            await env.submit(c)
        for _ in range(6000):                                   # let them all finish, records pile up
            await FallingEdge(dut.clk)
        st = await env.status()
        assert st & (1 << T.SB_CPL_VALID)
        await env.submit(cmds[HW.cmdq])                         # runs, then waits in RECORD: queue full
        for _ in range(3000):
            await FallingEdge(dut.clk)
        st = await env.status()
        assert (st >> 8) & 0xF == 6, f"scheduler not waiting in RECORD (TSU_S_RECORD = 6): STATUS {st:#x}"
        for c in cmds[HW.cmdq + 1:]:
            await env.submit(c)                                 # submit() collects only when the queue is full
        await env.wait_done()
        env.check_records()
        p = await env.perf()
        assert p["CPL_STALL"] - env.perf0["CPL_STALL"] > 0, "the completion queue never back-pressured the scheduler"
        cov.hit("sched", "cpl_backpressure")
        await finish(env)

    @tensor_test(checkers=CHECKERS, timeout_us=80000)
    async def reset_during_execution(dut, rng, cov):
        """Hard reset at a random point of a multi-tile GEMM (twice): no record for the destroyed
        commands, SEQ restarts at 0, the following GEMMs are exact."""
        env = await setup(dut, rng, cov, streams=False)
        al = Alloc(HW, rng)
        for trial in range(2):
            big = gemm_cmd(make_gemm(HW, al, rng, 3 * HW.rows, 3 * HW.cols, 2 * HW.tile_k + 3), "victim")
            queued = gemm_cmd(make_gemm(HW, al, rng, 4, 4, 9), "queued")
            await env.submit(big)
            await env.submit(queued)
            for _ in range(rng.randint(200, 3000)):
                await FallingEdge(dut.clk)
            lost = await hard_reset(env)
            cov.hit("reset", f"lost_{len(lost)}")
            after = [gemm_cmd(make_gemm(HW, al, rng, rng.randint(1, 9), rng.randint(1, 9), rng.randint(1, 70)))
                     for _ in range(3)]
            await env.run(after)
            assert [c.record["seq"] for c in after] == [0, 1, 2]
        env.mem.reads, env.mem.writes = [], []
        await finish(env, traffic=False, counters=False)

    @tensor_test(checkers=CHECKERS, timeout_us=80000)
    async def error_propagation_stop_and_continue(dut, rng, cov):
        """Stop-on-error: after an ERROR, queued commands are SKIPPED (PRIOR) until ERR_CLEAR;
        continue mode executes them.  An execution error (DMA read error) soft-resets the datapath
        and the next command is exact."""
        env = await setup(dut, rng, cov, streams=False, err_cont=False)
        al = Alloc(HW, rng)
        good = lambda: gemm_cmd(make_gemm(HW, al, rng, rng.randint(1, 8), rng.randint(1, 8), rng.randint(1, 40)))  # noqa
        badc = Cmd(T.with_(make_gemm(HW, al, rng, 4, 4, 4), m=0).words(), None, "invalid")
        cmds = [good(), badc, good(), good()]
        await env.run(cmds)
        assert [c.record["status"] for c in cmds] == [T.ST_OK, T.ST_ERROR, T.ST_SKIPPED, T.ST_SKIPPED]
        assert all(c.record["err"] == T.E_PRIOR for c in cmds[2:])
        st = await env.status()
        assert st & (1 << T.SB_ERR_STICKY)
        await env.err_clear()
        assert not ((await env.status()) & (1 << T.SB_ERR_STICKY))
        cmds2 = [good(), good()]
        await env.run(cmds2)
        cov.hit("errors", "stop_mode_skip")
        # continue mode: an execution error, then commands keep executing on a clean datapath
        await env.set_ctrl(True)
        await env.err_clear()
        victim = make_gemm(HW, al, rng, 2 * HW.rows, HW.cols, HW.tile_k + 9)
        wa = T.read_words(victim, HW)[len(T.read_words(victim, HW)) // 2][0]
        from common.sfb2 import Window
        env.mem.windows = [Window(wa, wa + 4, read=True)]
        await env.submit(gemm_cmd(victim, "dma_read_error"))
        await env.wait_done()
        env.mem.windows = []
        cmds3 = [good(), good()]
        await env.run(cmds3)
        assert env.records[-3]["err"] == T.E_DMA_READ and env.records[-3]["err_addr"] == wa
        cov.hit("errors", "continue_after_execution_error")
        env.mem.reads, env.mem.writes = [], []
        await finish(env, traffic=False, counters=False)

    @tensor_test(checkers=CHECKERS, timeout_us=80000)
    async def abort_running_and_queued(dut, rng, cov):
        """CTRL.ABORT while a long command runs and others are queued: the running one completes
        ERROR (ABORTED), the queued ones SKIPPED (ABORTED); then a clean command is exact."""
        env = await setup(dut, rng, cov, streams=False)
        al = Alloc(HW, rng)
        long_ = gemm_cmd(make_gemm(HW, al, rng, 3 * HW.rows, 3 * HW.cols, 3 * HW.tile_k), "long")
        q1 = gemm_cmd(make_gemm(HW, al, rng, 4, 4, 9), "q1")
        q2 = gemm_cmd(make_gemm(HW, al, rng, 4, 4, 9), "q2")
        for c in (long_, q1, q2):
            await env.submit(c)
        for _ in range(rng.randint(300, 1500)):
            await FallingEdge(dut.clk)
        await env.wr(T.R_CTRL, int(env.err_cont) | (1 << T.CTRL_ABORT))
        while (await env.status()) & (1 << T.SB_ABORTING):
            await env.collect()
        await env.wait_done()
        recs = env.records
        assert len(recs) == 3
        st = [r["status"] for r in recs]
        assert st[0] in (T.ST_OK, T.ST_ERROR) and all(r["err"] == T.E_ABORTED for r in recs if r["status"] != T.ST_OK)
        assert any(r["err"] == T.E_ABORTED for r in recs), recs
        first_ab = next(i for i, r in enumerate(recs) if r["status"] != T.ST_OK)
        assert recs[first_ab]["status"] in (T.ST_ERROR, T.ST_SKIPPED)
        assert all(r["status"] == T.ST_SKIPPED for r in recs[first_ab + 1:])
        for c in (long_, q1, q2):
            env.undef |= T.c_footprint(c.gemm)
        env.records, env.cmds, env.sticky = [], [], False
        await env.err_clear()
        env.n_sub = 3
        clean = [gemm_cmd(make_gemm(HW, al, rng, 5, 5, 20))]
        await env.run(clean)
        assert clean[0].record["seq"] == 3
        cov.hit("abort", f"first_aborted_{first_ab}")
        env.mem.reads, env.mem.writes = [], []
        await finish(env, traffic=False, counters=False)

    @tensor_test(checkers=CHECKERS, timeout_us=60000)
    async def interrupts(dut, rng, cov):
        """INT_ENABLE / INT_STATUS (W1C) / irq level for IRQ-flagged, failing and plain commands."""
        env = await setup(dut, rng, cov, streams=False)
        al = Alloc(HW, rng)
        await env.wr(T.R_INT_ENABLE, 0b111)
        await env.run([gemm_cmd(make_gemm(HW, al, rng, 4, 4, 4, irq=True))])
        assert (await env.rd(T.R_INT_STATUS)) & 0b101 == 0b101 and int(dut.irq.value) == 1
        await env.wr(T.R_INT_STATUS, 0b111)
        assert (await env.rd(T.R_INT_STATUS)) == 0
        await FallingEdge(dut.clk)                       # sample the level output between edges
        assert int(dut.irq.value) == 0
        await env.run([Cmd(T.with_(make_gemm(HW, al, rng, 4, 4, 4), k=0).words(), None, "bad")])
        assert (await env.rd(T.R_INT_STATUS)) & 0b110 == 0b110
        await FallingEdge(dut.clk)
        assert int(dut.irq.value) == 1
        await env.wr(T.R_INT_ENABLE, 0)
        await FallingEdge(dut.clk)
        assert int(dut.irq.value) == 0                   # masked: INT_STATUS still set, irq low
        await env.wr(T.R_INT_STATUS, 0b111)
        cov.hit("irq", "all")
        env.mem.reads, env.mem.writes = [], []
        await finish(env, traffic=False, counters=False)


CONFIGS = [cfg(), cfg(dbuf=1, opb=4096), cfg(rows=2, cols=2, opb=1024, nb=2, cplq=2),
           cfg(tk=16, opb=1024, kmax=4096, quant=1)]


@pytest.mark.parametrize("c", CONFIGS, ids=cfg_id)
def test_scheduler(c):
    run_tsu("tile_controller", "test_scheduler", c, TT / "tile_controller")
