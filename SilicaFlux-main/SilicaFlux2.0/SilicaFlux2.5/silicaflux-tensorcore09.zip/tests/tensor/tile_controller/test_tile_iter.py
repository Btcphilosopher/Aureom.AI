"""Tile iterator verification: TENSORCORE 06 ttc_tile_iter.

Every step of every traversal is compared with reference_models.tsu_model.schedule
(the tile / K-chunk order of TC08 doc 04): coordinates, effective sizes of partial
edge tiles, chunk index, first / last chunk, last step, done, step index.  Also: adv
ignored after done, init restarting mid-sequence, adv gaps (backpressure of the
consumer), 16-bit coordinate boundaries (M = 65535).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
try:
    from common.harness import tensor_test, FallingEdge, ReadOnly, PARAMS, pick
except ImportError:
    tensor_test = None

from reference_models import tsu_model as T  # noqa: E402

TM = int(PARAMS.get("TILE_M", 4))
TN = int(PARAMS.get("TILE_N", 4))


async def check_sequence(dut, rng, cov, m, n, k, kc, nmajor, gap_p=0.0, restart_at=None):
    d = dut
    hw = T.HwConfig(rows=TM, cols=TN, tile_k=max(kc, 1))
    g = T.Gemm(a=0, b=0, c=0, m=m, n=n, k=k, lda=k, ldb=n, ldc=4 * n, kc=kc, nmajor=nmajor)
    steps = T.schedule(g, hw)
    d.m.value, d.n.value, d.k.value, d.kc.value, d.nmajor.value = m, n, k, kc, int(nmajor)
    d.init.value, d.adv.value = 1, 0
    await FallingEdge(d.clk)
    d.init.value = 0
    i = 0
    restarted = False
    while i < len(steps):
        s = steps[i]
        d.adv.value = 0
        await ReadOnly()
        got = (int(d.m0.value), int(d.n0.value), int(d.k0.value), int(d.kidx.value), int(d.eff_m.value),
               int(d.eff_n.value), int(d.eff_k.value), int(d.first_k.value), int(d.last_k.value),
               int(d.last_step.value), int(d.done.value), int(d.step_idx.value))
        exp = (s.m0, s.n0, s.k0, s.kidx, s.em, s.en, s.ek, int(s.first_k), int(s.last_k), int(i == len(steps) - 1),
               0, i)
        assert got == exp, f"step {i} of {m}x{n}x{k} kc={kc} nmajor={nmajor}: got {got} expected {exp}"
        if s.em < TM or s.en < TN:
            cov.hit("tile", "partial_edge")
        if s.ek < kc:
            cov.hit("tile", "partial_k")
        await FallingEdge(d.clk)
        if restart_at is not None and i == restart_at and not restarted:
            d.init.value = 1                        # restart mid-sequence: back to step 0
            await FallingEdge(d.clk)
            d.init.value = 0
            restarted, i = True, 0
            cov.hit("ctl", "restart")
            continue
        if rng.random() < gap_p:
            continue                                # no advance this cycle: must hold
        d.adv.value = 1
        await FallingEdge(d.clk)
        d.adv.value = 0
        i += 1
    await ReadOnly()
    assert int(d.done.value) == 1 and int(d.step_idx.value) == len(steps)
    await FallingEdge(d.clk)
    d.adv.value = 1                                 # adv after done is ignored
    await FallingEdge(d.clk)
    d.adv.value = 0
    await ReadOnly()
    assert int(d.done.value) == 1 and int(d.step_idx.value) == len(steps)
    await FallingEdge(d.clk)
    cov.hit("order", "nmajor" if nmajor else "mmajor")
    return len(steps)


if tensor_test is not None:

    async def setup(dut):
        for s in ("init", "adv", "nmajor", "m", "n", "k", "kc"):
            getattr(dut, s).value = 0
        for _ in range(2):
            await FallingEdge(dut.clk)
        dut.rst_n.value = 1
        await FallingEdge(dut.clk)

    @tensor_test(checkers=["chk_rst"])
    async def directed_shapes(dut, rng, cov):
        """The brief's GEMM shapes and degenerate ones, both orders, K chunk sizes 1 / 64 / >= K."""
        await setup(dut)
        for m, n, k in ((1, 1, 1), (4, 4, 4), (5, 7, 3), (8, 8, 8), (17, 13, 29), (31, 19, 257), (1, 37, 5),
                        (37, 1, 5), (TM, TN, 1)):
            for kc in sorted({1, 3, 64, k, k + 5}):
                for nm in (False, True):
                    await check_sequence(dut, rng, cov, m, n, k, kc, nm)

    @tensor_test(checkers=["chk_rst"])
    async def random_with_gaps_and_restart(dut, rng, cov):
        await setup(dut)
        for _ in range(pick(40, 300)):
            m, n, k = rng.randint(1, 50), rng.randint(1, 50), rng.randint(1, 300)
            kc = rng.choice([1, rng.randint(1, k), k, 64])
            n_steps = T.schedule(T.Gemm(0, 0, 0, m, n, k, k, n, 4 * n, kc=kc),
                                 T.HwConfig(rows=TM, cols=TN, tile_k=kc))
            if len(n_steps) > 3000:
                continue
            await check_sequence(dut, rng, cov, m, n, k, kc, rng.random() < 0.5, gap_p=0.3,
                                 restart_at=rng.randint(0, len(n_steps) - 1) if rng.random() < 0.2 else None)

    @tensor_test(checkers=["chk_rst"])
    async def coordinate_boundaries(dut, rng, cov):
        """M or N = 65535 (16-bit fields, m0 + TILE_M crosses 2^16 in the end comparison) and
        K = 131071 in one chunk."""
        await setup(dut)
        await check_sequence(dut, rng, cov, 65535, 1, 1, 1, False)
        await check_sequence(dut, rng, cov, 1, 65535, 1, 1, True)
        await check_sequence(dut, rng, cov, 1, 1, 131071, 131071, False)
        await check_sequence(dut, rng, cov, 3, 2, 131071, 32767, False)
        cov.hit("tile", "max_coordinates")


CONFIGS = [dict(TILE_M=4, TILE_N=4), dict(TILE_M=2, TILE_N=2), dict(TILE_M=8, TILE_N=8), dict(TILE_M=3, TILE_N=5)]


@pytest.mark.parametrize("cfg", CONFIGS, ids=lambda c: f"{c['TILE_M']}x{c['TILE_N']}")
def test_tile_iterator(cfg):
    from common import sim
    srcs, incs = sim.tc08_subset("ttc_tile_iter.sv")
    sim.run("tile_controller", "tb_iter", "test_tile_iter",
            srcs + sim.checker_sources() + [TT / "tile_controller" / "tb_iter.sv"], cfg, includes=incs,
            tag=f"{cfg['TILE_M']}x{cfg['TILE_N']}")
