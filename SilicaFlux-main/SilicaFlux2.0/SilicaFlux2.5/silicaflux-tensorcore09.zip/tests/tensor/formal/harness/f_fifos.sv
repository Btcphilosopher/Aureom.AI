// =============================================================================
// SilicaFlux TENSORCORE 09 :: formal harnesses -- FIFO control
// Yosys 0.33 read_verilog -formal; driven by formal/run_formal.py (yosys-smtbmc).
// Port-level properties only (Yosys 0.33 does not resolve hierarchical references).
// Reset is assumed low in the first step and is FREE afterwards: every property also
// holds across arbitrary resets.
// =============================================================================

// ---------------------------------------------------------------- M08 hpc_command_queue
// Q1 level == shadow occupancy   Q2 full / empty / in_ready / out_valid consistent with it
// Q3 out_data == oldest shadow entry (ORDER / no loss / no duplication)  [data: BMC]
module f_cmdq #(parameter int W = 3, parameter int D = 4, parameter bit CHECK_DATA = 1) (
  input wire logic         clk,
  input wire logic         rst_n,
  input wire logic         in_valid,
  input wire logic [W-1:0] in_data,
  input wire logic         out_ready
);
  localparam int CW = $clog2(D + 1);
  logic in_ready, out_valid, full, empty;
  logic [W-1:0]  out_data;
  logic [CW-1:0] level;
  hpc_command_queue #(.WIDTH(W), .DEPTH(D)) dut (.clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(in_ready),
    .in_data(in_data), .out_valid(out_valid), .out_ready(out_ready), .out_data(out_data), .level(level),
    .full(full), .empty(empty));

  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);

  // shadow FIFO: sh[0] = oldest
  logic [D*W-1:0] sh;
  logic [CW-1:0]  sc;
  wire push = in_valid && in_ready;
  wire pop  = out_valid && out_ready;
  logic [D*W-1:0] sh_pop;
  always @(*) sh_pop = pop ? (sh >> W) : sh;
  always @(posedge clk) begin
    if (!rst_n) begin
      sc <= '0;
    end else begin
      sc <= sc + CW'(push) - CW'(pop);
      // clear the slot before inserting: the shadow storage itself is not reset
      sh <= push ? ((sh_pop & ~((D*W)'({W{1'b1}}) << (W * (sc - CW'(pop))))) |
                    ((D*W)'(in_data) << (W * (sc - CW'(pop))))) : sh_pop;
    end
  end
  always @(*) begin
    if (!init && rst_n) begin
      assert (level == sc);                                       // Q1
      assert (full == (sc == CW'(D)) && empty == (sc == '0));     // Q2
      assert (in_ready == !full && out_valid == !empty);          // Q2
      assert (sc <= CW'(D));
      if (CHECK_DATA && out_valid) assert (out_data == sh[W-1:0]); // Q3
    end
  end
endmodule

// ---------------------------------------------------------------- DataFabric dma_fifo (credit FIFO)
// Environment: the user never pushes into a full FIFO without popping, never pops an empty one.
// C1 count <= DEPTH   C2 count == shadow occupancy   C3 clr empties   C4 rdata == oldest [BMC]
module f_dmafifo #(parameter int W = 3, parameter int D = 4, parameter bit CHECK_DATA = 1) (
  input wire logic         clk,
  input wire logic         rst_n,
  input wire logic         clr,
  input wire logic         push,
  input wire logic [W-1:0] wdata,
  input wire logic         pop
);
  localparam int AW = $clog2(D);
  logic [W-1:0] rdata;
  logic [AW:0]  count;
  dma_fifo #(.WIDTH(W), .DEPTH(D)) dut (.clk(clk), .rst_n(rst_n), .clr(clr), .push(push), .wdata(wdata),
                                        .pop(pop), .rdata(rdata), .count(count));
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);

  logic [D*W-1:0] sh;
  logic [AW:0]    sc;
  always @(*) begin
    if (rst_n && !clr) begin
      assume (!(pop && sc == '0));
      assume (!(push && !pop && sc == (AW+1)'(D)));
    end
  end
  logic [D*W-1:0] sh_pop;
  always @(*) sh_pop = pop ? (sh >> W) : sh;
  always @(posedge clk) begin
    if (!rst_n || clr) begin
      sc <= '0;
    end else begin
      sc <= sc + (AW+1)'(push) - (AW+1)'(pop);
      sh <= push ? ((sh_pop & ~((D*W)'({W{1'b1}}) << (W * (sc - (AW+1)'(pop))))) |
                    ((D*W)'(wdata) << (W * (sc - (AW+1)'(pop))))) : sh_pop;
    end
  end
  always @(*) begin
    if (!init && rst_n) begin
      assert (count == sc);                                       // C2 (C3 through the clr branch)
      assert (count <= (AW+1)'(D));                               // C1
      if (CHECK_DATA && count != '0) assert (rdata == sh[W-1:0]); // C4
    end
  end
endmodule
