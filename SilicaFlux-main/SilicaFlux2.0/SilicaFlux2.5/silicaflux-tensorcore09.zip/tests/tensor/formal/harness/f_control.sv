// =============================================================================
// SilicaFlux TENSORCORE 09 :: formal harnesses -- arbitration, ownership, bus gate
// =============================================================================

// ---------------------------------------------------------------- TC03 tob_bank_arb
// Environment: wr_go only when this bank's wr_ok (single-bank system; in TC03 wr_go is the AND
// of wr_ok over every bank a write targets).
// G1 grant subset of request   G2 at most one grant   G3 work conservation
// G4 rd_any / rd_idx / rd_row_g consistent with the grant
// G5 no read and write of the same row in one cycle (1R1W) / no read with a write (1RW)
// G6 a forced write is always allowed
// G7 bounded waiting: requester 0, urgent, requesting and not blocked by a write, is granted
//    within NR cycles (round-robin pointer)
module f_bank_arb #(parameter int NR = 4, parameter int PORT_MODE = 1, parameter int RW = 3) (
  input wire logic             clk,
  input wire logic             rst_n,
  input wire logic [NR-1:0]    rd_req,
  input wire logic [NR-1:0]    rd_urg,
  input wire logic [NR*RW-1:0] rd_row,
  input wire logic             wr_req,
  input wire logic [RW-1:0]    wr_row,
  input wire logic             wr_force,
  input wire logic             wr_go
);
  localparam int PW = (NR > 1) ? $clog2(NR) : 1;
  logic          wr_ok, rd_any, conflict;
  logic [NR-1:0] rd_gnt, rd_wr_blk;
  logic [PW-1:0] rd_idx;
  logic [RW-1:0] rd_row_g;
  tob_bank_arb #(.NR(NR), .PORT_MODE(PORT_MODE), .RW(RW)) dut (.clk(clk), .rst_n(rst_n), .rd_req(rd_req),
    .rd_urg(rd_urg), .rd_row(rd_row), .wr_req(wr_req), .wr_row(wr_row), .wr_force(wr_force), .wr_ok(wr_ok),
    .wr_go(wr_go), .rd_gnt(rd_gnt), .rd_any(rd_any), .rd_idx(rd_idx), .rd_row_g(rd_row_g), .conflict(conflict),
    .rd_wr_blk(rd_wr_blk));
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  always @(*) if (wr_go) assume (wr_ok);

  // requester 0 keeps an urgent request up until granted, never blocked by a write
  logic [7:0] wait0;
  always @(*) if (!init && rst_n && wait0 != 0) assume (rd_req[0] && rd_urg[0]);
  always @(*) assume (!(wr_go && wr_req && rd_wr_blk[0]));
  always @(posedge clk) begin
    if (!rst_n) wait0 <= 0;
    else if (rd_req[0] && rd_urg[0] && !rd_gnt[0]) wait0 <= wait0 + 8'd1;
    else wait0 <= 0;
  end

  logic [NR-1:0] gl;
  always @(*) gl = rd_gnt & (rd_gnt - 1'b1);
  always @(*) begin
    if (!init && rst_n) begin
      assert ((rd_gnt & ~rd_req) == '0);                                       // G1
      assert (gl == '0);                                                       // G2
      assert (((rd_req & ~rd_wr_blk) == '0) || (rd_gnt != '0));                // G3
      assert (rd_any == (rd_gnt != '0));                                       // G4
      if (rd_any) begin
        assert (rd_gnt[rd_idx]);
        assert (rd_row_g == rd_row[rd_idx*RW +: RW]);
      end
      if (PORT_MODE == 1) assert (!(wr_go && wr_req && rd_any && rd_row_g == wr_row));   // G5 (1R1W)
      else                assert (!(wr_go && wr_req && rd_any));                         // G5 (1RW)
      if (wr_force) assert (wr_ok);                                            // G6
      assert (wait0 < NR);                                                     // G7
    end
  end
endmodule

// ---------------------------------------------------------------- TC03 tob_dbuf_ctrl (buffer ownership)
// B1 every set changes state only EMPTY->FILL->READY->COMPUTE->EMPTY
// B2 at most one set owned by the DMA (FILL) and at most one by compute (COMPUTE)
// B3 every ready signal is exactly its documented precondition
// B4 a set is sealed (FILL->READY) only with no DMA request in flight (dma_idle at the handshake),
//    released (COMPUTE->EMPTY) only with the operand engine drained (engine_idle)
// B5 strict ping-pong: fill_set / cmp_set advance by one exactly at fill_end / cmp_end
// B6 (2 sets) ordering: the set at cmp_set is the oldest and the most advanced; the younger one is
//    EMPTY, FILL or READY (never COMPUTE); a FILL set is always the one at fill_set; fill_set is
//    cmp_set plus the number of sets past FILL (mod 2)
module f_dbuf #(parameter int NUM_SETS = 2) (
  input wire logic clk,
  input wire logic rst_n,
  input wire logic fill_begin_valid,
  input wire logic fill_end_valid,
  input wire logic cmp_begin_valid,
  input wire logic cmp_end_valid,
  input wire logic dma_idle,
  input wire logic engine_idle
);
  localparam int SW = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1;
  logic fbr, fer, cbr, cer, cmp_owned;
  logic [SW-1:0] fill_set, cmp_set;
  logic [NUM_SETS*2-1:0] st;
  tob_dbuf_ctrl #(.NUM_SETS(NUM_SETS)) dut (.clk(clk), .rst_n(rst_n), .fill_begin_valid(fill_begin_valid),
    .fill_begin_ready(fbr), .fill_end_valid(fill_end_valid), .fill_end_ready(fer), .cmp_begin_valid(cmp_begin_valid),
    .cmp_begin_ready(cbr), .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cer), .dma_idle(dma_idle),
    .engine_idle(engine_idle), .fill_set(fill_set), .cmp_set(cmp_set), .set_state(st), .cmp_owned(cmp_owned));
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);

  logic [NUM_SETS*2-1:0] st_q;
  logic [SW-1:0] efs, ecs;
  logic fe_q, ce_q, fb_q, cb_q, live_q;
  always @(posedge clk) begin
    st_q <= st;
    fe_q <= fill_end_valid && fer;
    ce_q <= cmp_end_valid && cer;
    fb_q <= fill_begin_valid && fbr;
    cb_q <= cmp_begin_valid && cbr;
    live_q <= rst_n && !init;
    if (!rst_n) begin
      efs <= '0; ecs <= '0;
    end else begin
      if (fill_end_valid && fer) efs <= (NUM_SETS > 1) ? efs + 1'b1 : efs;
      if (cmp_end_valid && cer)  ecs <= (NUM_SETS > 1) ? ecs + 1'b1 : ecs;
    end
  end
  integer nf, nc;
  always @(*) begin
    nf = 0; nc = 0;
    for (int i = 0; i < NUM_SETS; i++) begin
      if (st[2*i +: 2] == 2'd1) nf = nf + 1;
      if (st[2*i +: 2] == 2'd3) nc = nc + 1;
    end
  end
  always @(*) begin
    if (!init && rst_n) begin
      assert (nf <= 1 && nc <= 1);                                                       // B2
      assert (fbr == (st[2*fill_set +: 2] == 2'd0));                                     // B3
      assert (fer == (st[2*fill_set +: 2] == 2'd1 && dma_idle));
      assert (cbr == (st[2*cmp_set +: 2] == 2'd2));
      assert (cer == (st[2*cmp_set +: 2] == 2'd3 && engine_idle));
      assert (cmp_owned == (st[2*cmp_set +: 2] == 2'd3));
      assert (fill_set == efs && cmp_set == ecs);                                        // B5

      if (live_q) begin
        for (int i = 0; i < NUM_SETS; i++) begin
          if (st[2*i +: 2] != st_q[2*i +: 2]) begin
            assert (st[2*i +: 2] == st_q[2*i +: 2] + 2'd1);                              // B1
          end
        end
      end
    end
  end
  // B6 (2 sets): ordering invariant (also what makes the property set inductive).  Written as one
  // combinational term: z3 4.8.12 stalls on the equivalent set of separate guarded assertions.
  wire [1:0] b6_sa = cmp_set[0] ? st[2*NUM_SETS-1 -: 2] : st[1:0];      // oldest set (at cmp_set)
  wire [1:0] b6_sb = cmp_set[0] ? st[1:0] : st[2*NUM_SETS-1 -: 2];      // younger set
  wire b6_ok = (NUM_SETS != 2) ||
               ((b6_sb != 2'd3) &&                                      // the younger set is never computing
                (!(b6_sb == 2'd1 || b6_sb == 2'd2) || b6_sa[1]) &&      // ... and only filled once the oldest is
                (b6_sa[1] || (fill_set == cmp_set && b6_sb == 2'd0)) && // oldest EMPTY / FILL: it is the fill set
                (!(b6_sa[1] && !b6_sb[1]) || (fill_set != cmp_set)) &&  // one set past FILL: pointers one apart
                (!(b6_sa[1] && b6_sb == 2'd2) || (fill_set == cmp_set)));   // two: pointers equal
  always @(*) if (!init && rst_n) assert (b6_ok);                                        // B6
  // B4: seal / release only through their guarded handshakes (which require the idle inputs)
  always @(*) begin
    if (!init && rst_n && live_q) begin
      for (int i = 0; i < NUM_SETS; i++) begin
        if (st_q[2*i +: 2] == 2'd1 && st[2*i +: 2] == 2'd2) assert (fe_q);
        if (st_q[2*i +: 2] == 2'd3 && st[2*i +: 2] == 2'd0) assert (ce_q);
        if (st_q[2*i +: 2] == 2'd0 && st[2*i +: 2] == 2'd1) assert (fb_q);
        if (st_q[2*i +: 2] == 2'd2 && st[2*i +: 2] == 2'd3) assert (cb_q);
      end
    end
  end
endmodule

// ---------------------------------------------------------------- TC08 tsu_bus_gate (request conservation, quiesce)
// Environment: the upstream master obeys SFB2 R2 and never has more than 6 transactions
// outstanding (the gate's counter is OUT_W = 4 bits here); the fabric may answer at any time,
// including with a response nobody asked for (the gate must absorb it).
// R1 outstanding == accepted - answered (conservation; unsolicited responses excluded)
// R2 an unsolicited response never reaches the adapter
// R3 downstream SFB2 R2: a presented request stays presented and unchanged until accepted,
//    also when the quiesce request rises meanwhile (no withdrawal)
// R4 not quiescing: fully transparent (valid, ready, payload)
// R5 quiescing: no NEW request leaves; quiesced => nothing presented, nothing outstanding
module f_bus_gate #(parameter int DW = 8, parameter int OUT_W = 4) (
  input wire logic            clk,
  input wire logic            rst_n,
  input wire logic            q_req,
  input wire logic            u_req_valid,
  input wire logic            u_req_write,
  input wire logic [31:0]     u_req_addr,
  input wire logic [DW-1:0]   u_req_wdata,
  input wire logic [DW/8-1:0] u_req_wstrb,
  input wire logic            u_rsp_ready,
  input wire logic            d_req_ready,
  input wire logic            d_rsp_valid,
  input wire logic [DW-1:0]   d_rsp_rdata,
  input wire logic            d_rsp_error
);
  logic quiesced, ev_unsol, u_req_ready, u_rsp_valid, u_rsp_error, d_req_valid, d_req_write, d_rsp_ready;
  logic [OUT_W-1:0] outstanding;
  logic [DW-1:0] u_rsp_rdata, d_req_wdata;
  logic [31:0] d_req_addr;
  logic [DW/8-1:0] d_req_wstrb;
  tsu_bus_gate #(.DW(DW), .OUT_W(OUT_W)) dut (.clk(clk), .rst_n(rst_n), .q_req(q_req), .quiesced(quiesced),
    .outstanding(outstanding), .ev_unsolicited(ev_unsol), .u_req_valid(u_req_valid), .u_req_ready(u_req_ready),
    .u_req_write(u_req_write), .u_req_addr(u_req_addr), .u_req_wdata(u_req_wdata), .u_req_wstrb(u_req_wstrb),
    .u_rsp_valid(u_rsp_valid), .u_rsp_ready(u_rsp_ready), .u_rsp_rdata(u_rsp_rdata), .u_rsp_error(u_rsp_error),
    .d_req_valid(d_req_valid), .d_req_ready(d_req_ready), .d_req_write(d_req_write), .d_req_addr(d_req_addr),
    .d_req_wdata(d_req_wdata), .d_req_wstrb(d_req_wstrb), .d_rsp_valid(d_rsp_valid), .d_rsp_ready(d_rsp_ready),
    .d_rsp_rdata(d_rsp_rdata), .d_rsp_error(d_rsp_error));
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);

  logic [OUT_W-1:0] cnt;
  logic up_hold, dn_hold, q_q, live_q;
  logic [32+DW+DW/8:0] up_pay, dn_pay;
  wire  [32+DW+DW/8:0] u_pay = {u_req_write, u_req_addr, u_req_wdata, u_req_wstrb};
  wire  [32+DW+DW/8:0] d_pay = {d_req_write, d_req_addr, d_req_wdata, d_req_wstrb};
  wire acc = d_req_valid && d_req_ready;
  wire ret = u_rsp_valid && u_rsp_ready;
  always @(posedge clk) begin
    live_q  <= rst_n && !init;
    up_hold <= rst_n && u_req_valid && !u_req_ready;
    dn_hold <= rst_n && d_req_valid && !d_req_ready;
    up_pay  <= u_pay;
    dn_pay  <= d_pay;
    q_q     <= rst_n && q_req;
    if (!rst_n) cnt <= '0;
    else        cnt <= cnt + OUT_W'(acc) - OUT_W'(ret);
  end
  // environment: upstream R2, bounded outstanding
  always @(*) begin
    if (!init && rst_n && up_hold) assume (u_req_valid && u_pay == up_pay);
    if (!init && rst_n) assume (!(acc && cnt >= OUT_W'(6)));
  end
  always @(*) begin
    if (!init && rst_n) begin
      assert (outstanding == cnt);                                              // R1
      if (u_rsp_valid) assert (cnt != '0);                                      // R2
      if (live_q && dn_hold) assert (d_req_valid && d_pay == dn_pay);           // R3
      if (!q_q) assert (d_req_valid == u_req_valid && u_req_ready == d_req_ready && d_pay == u_pay);   // R4
      if (live_q && q_q && !dn_hold) assert (!d_req_valid);                     // R5: nothing new
      if (quiesced) assert (!d_req_valid && outstanding == '0);                 // R5
    end
  end
endmodule
