// =============================================================================
// SilicaFlux TENSORCORE 09 :: formal harness -- TC02 tensor_pe accumulator invariants
// Environment: at most KMAX MACs between two tile clears (the tensor unit guarantees this:
// K <= K_MAX = 131071 and the array clears every PE at each launch).
// A1 a commit adds exactly the sign-extended product of the paired operands (MUL_PIPE = 0)
// A2 without a commit (and without clear / reset) the accumulator holds
// A3 (overflow-freedom) |acc| stays inside [n*P_MIN, n*P_MAX] where n = MACs since the clear,
//    so for n <= 131071 the 32-bit accumulator never wraps
// A4 done is sticky until clear / reset and rises only on the commit of a last-tagged pair
// A5 en = 0 freezes the accumulator, done and the forwarded tokens
// A6 forwarding: one registered hop of valid / last / data per enabled cycle
// =============================================================================
module f_pe #(parameter int MUL_PIPE = 0, parameter int KMAX = 131071) (
  input wire logic              clk,
  input wire logic              rst_n,
  input wire logic              clr,
  input wire logic              en,
  input wire logic              a_valid_i,
  input wire logic              a_last_i,
  input wire logic signed [7:0] a_data_i,
  input wire logic              b_valid_i,
  input wire logic              b_last_i,
  input wire logic signed [7:0] b_data_i
);
  logic a_valid_o, a_last_o, b_valid_o, b_last_o, done_o, fire_o, commit_o, err_o;
  logic signed [7:0] a_data_o, b_data_o;
  logic [3:0] a_kidx_o, b_kidx_o;
  logic signed [31:0] acc_o;
  tensor_pe #(.DATA_WIDTH(8), .ACC_WIDTH(32), .KIDX_WIDTH(4), .MUL_PIPE(MUL_PIPE), .CHECK_ALIGN(0)) dut (
    .clk(clk), .rst_n(rst_n), .clr(clr), .en(en), .chk_en(1'b0),
    .a_valid_i(a_valid_i), .a_last_i(a_last_i), .a_data_i(a_data_i), .a_kidx_i(4'd0),
    .b_valid_i(b_valid_i), .b_last_i(b_last_i), .b_data_i(b_data_i), .b_kidx_i(4'd0),
    .a_valid_o(a_valid_o), .a_last_o(a_last_o), .a_data_o(a_data_o), .a_kidx_o(a_kidx_o),
    .b_valid_o(b_valid_o), .b_last_o(b_last_o), .b_data_o(b_data_o), .b_kidx_o(b_kidx_o),
    .acc_o(acc_o), .done_o(done_o), .fire_o(fire_o), .commit_o(commit_o), .err_o(err_o));
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);

  // MACs since the last clear; the environment never exceeds KMAX
  logic [17:0] n;
  always @(posedge clk) begin
    if (!rst_n || clr) n <= '0;
    else if (commit_o)  n <= n + 18'd1;
  end
  always @(*) if (!init && rst_n && !clr && n >= 18'(KMAX)) assume (!commit_o);

  logic live_q, commit_q, clr_q, en_q, last_q, done_q, av_q, bv_q, al_q, bl_q;
  logic signed [31:0] acc_q;
  logic signed [15:0] prod_q, prod_pipe;
  logic               pipe_last;
  logic signed [7:0]  ad_q, bd_q;
  always @(posedge clk) begin
    live_q   <= rst_n && !init;
    commit_q <= commit_o;
    clr_q    <= clr;
    en_q     <= en;
    acc_q    <= acc_o;
    done_q   <= done_o;
    av_q <= a_valid_i; bv_q <= b_valid_i; al_q <= a_last_i; bl_q <= b_last_i; ad_q <= a_data_i; bd_q <= b_data_i;
    if (en && fire_o) prod_pipe <= a_data_i * b_data_i;
    if (en) pipe_last <= fire_o && a_last_i && b_last_i;   // last tag travelling with the registered product
    prod_q   <= (MUL_PIPE == 0) ? a_data_i * b_data_i : prod_pipe;
    last_q   <= (MUL_PIPE == 0) ? (a_last_i && b_last_i) : pipe_last;
  end

  wire signed [63:0] lo = -64'sd16256 * $signed({46'd0, n});
  wire signed [63:0] hi =  64'sd16384 * $signed({46'd0, n});
  always @(*) begin
    if (!init && rst_n) begin
      assert (64'(acc_o) >= lo && 64'(acc_o) <= hi);                                   // A3
      if (live_q && rst_n && !clr_q) begin
        if (MUL_PIPE == 0 && commit_q) assert (acc_o == acc_q + 32'(prod_q));           // A1
        if (!commit_q) assert (acc_o == acc_q);                                         // A2
        if (done_q) assert (done_o);                                                    // A4 sticky
        if (!done_q && done_o) assert (commit_q && last_q);                             // A4 rises on last
        if (!en_q) assert (acc_o == acc_q && done_o == done_q);                         // A5
        if (en_q) assert (a_valid_o == av_q && b_valid_o == bv_q && a_last_o == al_q && b_last_o == bl_q
                          && a_data_o == ad_q && b_data_o == bd_q);                     // A6
      end
    end
  end
endmodule
