#!/usr/bin/env python3
"""Formal verification of TensorCore control blocks: Yosys 0.33 + yosys-smtbmc (z3).

SymbiYosys is not available in this environment, so this script performs the flow sby's
`smtbmc` engine performs: read_verilog -formal, prep, async2sync, dffunmap, write_smt2, then

  bmc   yosys-smtbmc -t N            : every assertion holds in every execution of <= N steps
                                       from reset (BOUNDED - nothing is claimed beyond N)
  prove yosys-smtbmc -t K (base)     : bounded base case, and
        yosys-smtbmc -i -t K (step)  : K-induction step.  Both passing = the assertions hold in
                                       EVERY reachable state (unbounded), under the harness
                                       assumptions, for the stated parameters only.

Every harness also has seeded bugs (a one-line change to a COPY of the RTL) that must make
the same check fail with a counterexample; otherwise a passing proof could be vacuous.

Results: build/results/formal/results.json (consumed by scripts/make_report.py), counter-
example traces under build/formal/<job>/.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

HERE = Path(__file__).resolve().parent
TT = HERE.parent
TC08 = TT / "build" / "rtl" / "tc08"
TP = TC08 / "third_party"
OUT = TT / "build" / "formal"
RES = TT / "build" / "results" / "formal"

INC = [TP / "silicaflux-tensorcore03" / "rtl", TP / "silicaflux-sramlib" / "rtl" / "mem",
       TP / "silicaflux-datafabric" / "rtl" / "dma", TC08 / "rtl"]
F_CMDQ = TP / "silicaflux-hpc-m08-tile" / "rtl" / "hpc_command_queue.sv"
F_DMAFIFO = TP / "silicaflux-datafabric" / "rtl" / "dma" / "dma_fifo.sv"
F_ARB = TP / "silicaflux-tensorcore03" / "rtl" / "tob_bank_arb.sv"
F_DBUF = TP / "silicaflux-tensorcore03" / "rtl" / "tob_dbuf_ctrl.sv"
F_GATE = TC08 / "rtl" / "tsu_bus_gate.sv"
F_PE = TP / "silicaflux-tensorcore02" / "rtl" / "tensor_pe.sv"
H = HERE / "harness"


@dataclass
class Job:
    name: str
    top: str
    rtl: list
    harness: Path
    params: dict
    mode: str               # "prove" (base + induction) or "bmc"
    depth: int
    what: str
    assumptions: str
    mutants: list = field(default_factory=list)   # (description, rtl file, old, new)


JOBS = [
    Job("cmdq_ctl_d4", "f_cmdq", [F_CMDQ], H / "f_fifos.sv", dict(W=3, D=4, CHECK_DATA=0), "prove", 6,
        "M08 hpc_command_queue (DEPTH 4): level / full / empty / ready / valid equal a shadow occupancy model "
        "(no overflow, no underflow, no phantom entry, never stuck)",
        "free inputs; reset free after step 0",
        [("count update dropped on simultaneous push+pop", F_CMDQ, "2'b10:   cnt_q <= cnt_q + 1'b1;",
          "2'b10, 2'b11: cnt_q <= cnt_q + 1'b1;")]),
    Job("cmdq_ctl_d16", "f_cmdq", [F_CMDQ], H / "f_fifos.sv", dict(W=2, D=16, CHECK_DATA=0), "prove", 4,
        "M08 hpc_command_queue (DEPTH 16): the same control invariants", "free inputs"),
    Job("cmdq_data_d2", "f_cmdq", [F_CMDQ], H / "f_fifos.sv", dict(W=3, D=2, CHECK_DATA=1), "bmc", 16,
        "M08 hpc_command_queue (DEPTH 2): out_data is always the oldest entry, 7 fill / drain rounds",
        "free inputs (bounded: the storage array is not port-visible)"),
    Job("cmdq_data_d4", "f_cmdq", [F_CMDQ], H / "f_fifos.sv", dict(W=3, D=4, CHECK_DATA=1), "bmc", 12,
        "M08 hpc_command_queue (DEPTH 4): out_data is always the oldest entry (order, no loss / duplication)",
        "free inputs (data integrity needs the storage array, which is not port-visible: bounded)",
        [("read pointer advances by two", F_CMDQ, "if (pop)  rp_q <= rp_q + 1'b1;", "if (pop)  rp_q <= rp_q + 2'd2;")]),
    Job("dmafifo_ctl_d4", "f_dmafifo", [F_DMAFIFO], H / "f_fifos.sv", dict(W=3, D=4, CHECK_DATA=0), "prove", 6,
        "DataFabric dma_fifo (DEPTH 4, used by TC03 / TC07): count == shadow occupancy <= DEPTH, clr empties",
        "user never pushes a full FIFO without popping, never pops an empty one (its documented contract)",
        [("count off by one", F_DMAFIFO, "assign count = wp - rp;", "assign count = wp - rp + 1'b1;")]),
    Job("dmafifo_data_d2", "f_dmafifo", [F_DMAFIFO], H / "f_fifos.sv", dict(W=3, D=2, CHECK_DATA=1), "bmc", 16,
        "DataFabric dma_fifo (DEPTH 2): rdata is the oldest entry", "as above"),
    Job("dmafifo_data_d4", "f_dmafifo", [F_DMAFIFO], H / "f_fifos.sv", dict(W=3, D=4, CHECK_DATA=1), "bmc", 12,
        "DataFabric dma_fifo (DEPTH 4): rdata is the oldest entry", "as above",
        [("write ignores the pointer", F_DMAFIFO, "mem[wp[AW-1:0]] <= wdata;", "mem[rp[AW-1:0]] <= wdata;")]),
    Job("bank_arb_1r1w", "f_bank_arb", [F_ARB], H / "f_control.sv", dict(NR=4, PORT_MODE=1, RW=3), "prove", 7,
        "TC03 tob_bank_arb, 4 readers, 1R1W: one-hot grant to requesters only, work conserving, no same-row "
        "read/write in one cycle, forced writes allowed, round-robin: a persistent urgent requester is granted "
        "within 4 cycles",
        "wr_go only with wr_ok; requester 0 keeps its urgent request until granted and is not write-blocked",
        [("write hazard not blocked", F_ARB, "assign rd_wr_blk = (wr_go && wr_req) ? hz : '0;",
          "assign rd_wr_blk = '0;"),
         ("round-robin pointer frozen", F_ARB, "else if (rd_any) ptr_q <= (rd_idx == LAST) ? '0 : rd_idx + 1'b1;",
          "else if (rd_any) ptr_q <= ptr_q;")]),
    Job("bank_arb_1rw", "f_bank_arb", [F_ARB], H / "f_control.sv", dict(NR=4, PORT_MODE=0, RW=3), "prove", 7,
        "TC03 tob_bank_arb, 4 readers, 1RW: the same, and no read in a cycle with a write", "as above",
        [("1RW hazard computed as 1R1W", F_ARB, "if (PORT_MODE == `TOB_PORT_1RW) hz[i] = rd_req[i];",
          "if (PORT_MODE == 99) hz[i] = rd_req[i];")]),
    Job("bank_arb_1r1w_nr8", "f_bank_arb", [F_ARB], H / "f_control.sv", dict(NR=8, PORT_MODE=1, RW=2), "prove", 11,
        "TC03 tob_bank_arb, 8 readers (the 8x8 array): the same properties, granted within 8 cycles", "as above"),
    Job("dbuf_2sets", "f_dbuf", [F_DBUF], H / "f_control.sv", dict(NUM_SETS=2), "prove", 6,
        "TC03 tob_dbuf_ctrl, ping-pong (2 sets): legal ownership transitions only, at most one DMA-owned and one "
        "compute-owned set, readies exactly their preconditions, seal only with no DMA write in flight, release "
        "only when drained, strict alternation, oldest set always the most advanced (ordering invariant)",
        "free handshakes and idle inputs",
        [("seal ignores the in-flight write", F_DBUF,
          "assign fill_end_ready   = (st_f == `TOB_ST_FILL) && dma_idle;",
          "assign fill_end_ready   = (st_f == `TOB_ST_FILL);"),
         ("compute may start on a set being filled", F_DBUF,
          "assign cmp_begin_ready  = (st_c == `TOB_ST_READY);",
          "assign cmp_begin_ready  = (st_c == `TOB_ST_READY) || (st_c == `TOB_ST_FILL);")]),
    Job("dbuf_1set", "f_dbuf", [F_DBUF], H / "f_control.sv", dict(NUM_SETS=1), "prove", 4,
        "TC03 tob_dbuf_ctrl, single buffer (the sequential baseline): the same properties", "as above"),
    Job("bus_gate", "f_bus_gate", [F_GATE], H / "f_control.sv", dict(DW=8, OUT_W=4), "prove", 5,
        "TC08 tsu_bus_gate: request conservation (outstanding = accepted - answered), unsolicited responses "
        "absorbed, SFB2 R2 preserved downstream even when quiesce rises, transparent when not quiescing, no new "
        "request while quiescing, quiesced => nothing presented / outstanding",
        "upstream obeys SFB2 R2 and keeps <= 6 transactions outstanding; the fabric is unconstrained",
        [("quiesce withdraws a presented request", F_GATE, "assign pass = !q_q || held_q;", "assign pass = !q_q;"),
         ("unsolicited response forwarded", F_GATE, "assign u_rsp_valid = d_rsp_valid && !unsol;",
          "assign u_rsp_valid = d_rsp_valid;")]),
    Job("pe_mp0", "f_pe", [F_PE], H / "f_pe.sv", dict(MUL_PIPE=0, KMAX=131071), "prove", 3,
        "TC02 tensor_pe (MUL_PIPE 0): exact MAC step, hold without commit, |acc| <= n*16384 so no wrap for "
        "n <= 131071 MACs, sticky done raised by the last pair, stall freeze, one-hop forwarding",
        "at most 131071 MACs between clears (guaranteed by the tensor unit: K <= K_MAX, clear at every launch)",
        [("accumulator subtracts", F_PE, "acc_q <= acc_q + mac_prod_ext;", "acc_q <= acc_q - mac_prod_ext;"),
         ("product zero-extended", F_PE, "assign mac_prod_ext = ACC_WIDTH'($signed(mac_prod_c));",
          "assign mac_prod_ext = ACC_WIDTH'($unsigned(mac_prod_c));")]),
    Job("pe_mp1", "f_pe", [F_PE], H / "f_pe.sv", dict(MUL_PIPE=1, KMAX=131071), "bmc", 16,
        "TC02 tensor_pe (MUL_PIPE 1): hold without commit, overflow-free bound, sticky done, freeze, forwarding",
        "as above; BOUNDED because the product register is not port-visible and can hold under a stall for "
        "any number of cycles, so no port-level k-induction closes the overflow bound",
        [("done raised by any MAC, not only the last", F_PE, "if (mac_last_c) done_q <= 1'b1;",
          "if (mac_last_c || 1'b1) done_q <= 1'b1;"),
         ("last tag lost in the product stage", F_PE, "prod_last_q <= fire_c & a_last_i & b_last_i;",
          "prod_last_q <= fire_c & a_last_i;")]),
]


def sh(cmd, log, timeout=900):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        out = p.stdout + p.stderr
        rc = p.returncode
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or "") if isinstance(e.stdout, str) else ""
        out += "\nTIMEOUT"
        rc = -1
    log.write_text(" ".join(map(str, cmd)) + "\n" + out)
    return rc, out, time.time() - t0


def build(job: Job, d: Path, rtl_files: list[Path]) -> tuple[bool, str]:
    d.mkdir(parents=True, exist_ok=True)
    inc = " ".join(f"-I{p}" for p in INC)
    files = " ".join(str(f) for f in rtl_files + [job.harness])
    chp = " ".join(f"-set {k} {v}" for k, v in job.params.items())
    script = (f"read_verilog -sv -formal -DFORMAL -DSYNTHESIS {inc} {files}; "
              f"chparam {chp} {job.top}; prep -top {job.top}; async2sync; dffunmap; "
              f"write_smt2 -wires {d / 'model.smt2'}")
    rc, out, _ = sh(["yosys", "-q", "-p", script], d / "yosys.log")
    return rc == 0, out


def smtbmc(d: Path, depth: int, induction: bool, tag: str):
    cmd = ["yosys-smtbmc", "-s", "z3", "--presat", "-t", str(depth), "--dump-vcd", str(d / f"{tag}.vcd")]
    if induction:
        cmd.insert(3, "-i")
    rc, out, t = sh(cmd + [str(d / "model.smt2")], d / f"{tag}.log")
    m = re.findall(r"Status: (\w+)", out)
    return (m[-1] if m else "ERROR"), round(t, 2), out


def run_job(job: Job, mutants: bool) -> dict:
    d = OUT / job.name
    if d.exists():
        shutil.rmtree(d)
    ok, out = build(job, d, job.rtl)
    res = dict(name=job.name, top=job.top, params=job.params, mode=job.mode, depth=job.depth, what=job.what,
               assumptions=job.assumptions, mutants=[])
    if not ok:
        res.update(status="ERROR", detail=out[-1500:])
        return res
    base, tb, _ = smtbmc(d, job.depth, False, "base")
    res["base"] = dict(status=base, seconds=tb)
    if job.mode == "prove":
        step, ts, _ = smtbmc(d, job.depth, True, "induction")
        res["induction"] = dict(status=step, seconds=ts)
        res["status"] = "PROVEN" if base == "PASSED" and step == "PASSED" else (
            "BOUNDED" if base == "PASSED" else "FAILED")
        res["claim"] = (f"unbounded (k-induction, k={job.depth})" if res["status"] == "PROVEN" else
                        f"bounded to {job.depth} steps (induction step {step})" if base == "PASSED" else
                        "assertion violated (see base.vcd)")
    else:
        res["status"] = "BOUNDED" if base == "PASSED" else "FAILED"
        res["claim"] = f"bounded: all executions of <= {job.depth} clock cycles from reset" if base == "PASSED" \
            else "assertion violated (see base.vcd)"
    if mutants:
        for desc, f, old, new in job.mutants:
            md = OUT / job.name / ("mut_" + re.sub(r"\W+", "_", desc)[:40])
            md.mkdir(parents=True, exist_ok=True)
            src = f.read_text()
            if old not in src:
                res["mutants"].append(dict(desc=desc, status="INVALID (pattern not found)"))
                continue
            mf = md / f.name
            mf.write_text(src.replace(old, new, 1))
            rtl = [mf if x == f else x for x in job.rtl]
            ok, _ = build(job, md, rtl)
            if not ok:
                res["mutants"].append(dict(desc=desc, status="INVALID (does not elaborate)"))
                continue
            st, t, _ = smtbmc(md, min(max(job.depth, 10), 16), False, "base")
            if st == "PASSED" and job.mode == "prove":
                st2, _, _ = smtbmc(md, job.depth, True, "induction")
                st = "FAILED" if st2 == "FAILED" else st
            res["mutants"].append(dict(desc=desc, status="DETECTED" if st == "FAILED" else "NOT DETECTED",
                                       seconds=t))
    return res


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--no-mutants", action="store_true")
    a = ap.parse_args()
    if not (TC08 / "rtl").exists():
        print("run scripts/stage_rtl.py first", file=sys.stderr)
        return 2
    RES.mkdir(parents=True, exist_ok=True)
    results = []
    for job in JOBS:
        if a.only and job.name not in a.only:
            continue
        r = run_job(job, not a.no_mutants)
        results.append(r)
        muts = ", ".join(f"{m['desc']}: {m['status']}" for m in r["mutants"])
        print(f"formal {job.name:20s} {r['status']:8s} {r.get('claim', '')}" + (f"  | mutants: {muts}" if muts else ""))
    tools = {}
    for name, cmd in (("yosys", ["yosys", "-V"]), ("z3", ["z3", "--version"])):
        try:
            tools[name] = subprocess.run(cmd, capture_output=True, text=True).stdout.strip()
        except OSError:
            tools[name] = "missing"
    (RES / "results.json").write_text(json.dumps(dict(tools=tools, jobs=results), indent=1))
    bad = [r for r in results if r["status"] in ("FAILED", "ERROR")]
    bad_m = [m for r in results for m in r["mutants"] if m["status"] != "DETECTED"]
    print(f"formal: {sum(r['status'] == 'PROVEN' for r in results)} proven, "
          f"{sum(r['status'] == 'BOUNDED' for r in results)} bounded, {len(bad)} failed; "
          f"mutants detected {sum(m['status'] == 'DETECTED' for r in results for m in r['mutants'])}/"
          f"{sum(len(r['mutants']) for r in results)}")
    return 1 if bad or bad_m else 0


if __name__ == "__main__":
    sys.exit(main())
