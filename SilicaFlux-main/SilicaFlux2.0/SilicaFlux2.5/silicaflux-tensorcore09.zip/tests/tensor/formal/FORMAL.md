# Formal verification: what is proven, under which assumptions, and to what bound

Run with `make tensor-formal` (`formal/run_formal.py`). Tools: Yosys 0.33 (`read_verilog -formal`, `prep`,
`async2sync`, `dffunmap`, `write_smt2`) and yosys-smtbmc with z3 4.8.12. SymbiYosys is not installed in
the reference environment, so the script performs the steps of sby's `smtbmc` engine itself.
Results: `build/results/formal/results.json`. Counterexample traces, if any:
`build/formal/<job>/{base,induction}.vcd`.

## Vocabulary

- **PROVEN.** The BMC base case to depth k passes, and the k-induction step passes. The assertions
  then hold in every reachable state, for the stated parameters, under the stated assumptions. The
  result is unbounded in time.
- **BOUNDED.** BMC only. The assertions hold in every execution of at most N clock cycles from reset.
  **Nothing is claimed beyond N.**
- **Reset.** Every harness forces `rst_n = 0` in the first step and leaves it free afterwards. Every
  property is therefore also checked across arbitrary resets.
- **Port-level.** Yosys 0.33 does not resolve hierarchical references, so the harnesses observe only
  the ports of the unmodified RTL. Properties that need an internal register to be inductive are
  bounded and marked so below.
- **Seeded bugs.** Each harness has one or two one-line bugs applied to a copy of the RTL. The same
  check must find a counterexample for each, which shows the passing result is not vacuous.

## Jobs

| Job | Unit, parameters | Kind, bound | Properties | Assumptions |
|---|---|---|---|---|
| `cmdq_ctl_d4`, `cmdq_ctl_d16` | M08 `hpc_command_queue`, DEPTH 4 / 16 | PROVEN, k = 6 / 4 | Q1 level equals a shadow occupancy. Q2 full / empty / in_ready / out_valid consistent with it: no overflow, no underflow, no phantom entry, never stuck. | None (free inputs) |
| `cmdq_data_d2`, `cmdq_data_d4` | same, DEPTH 2 / 4, 3-bit data | BOUNDED, 16 / 12 cycles | Q3 `out_data` is always the oldest entry: order, no loss, no duplication. | None. Bounded because the storage array is not port-visible. 16 cycles = 7 complete fill / drain rounds of the 2-deep FIFO; 12 cycles include pointer wrap-around of the 4-deep one. |
| `dmafifo_ctl_d4` | DataFabric `dma_fifo`, DEPTH 4 | PROVEN, k = 6 | C1 count ≤ DEPTH. C2 count equals the shadow occupancy. C3 `clr` empties. | The user never pushes a full FIFO without popping and never pops an empty one: the module's documented contract, which TC03 / TC07 honour. |
| `dmafifo_data_d2`, `dmafifo_data_d4` | same | BOUNDED, 16 / 12 cycles | C4 `rdata` is always the oldest entry. | As above |
| `bank_arb_1r1w`, `bank_arb_1rw`, `bank_arb_1r1w_nr8` | TC03 `tob_bank_arb`, 4 / 4 / 8 readers | PROVEN, k = 7 / 7 / 11 | G1 grant only to a requester. G2 at most one grant. G3 work conserving. G4 index / row consistent with the grant. G5 never a read and a write of the same row in one cycle (1R1W), or a read with a write (1RW). G6 a forced write is always allowed. G7 a persistent urgent requester is granted within NR cycles (round-robin fairness). | `wr_go` only with `wr_ok` (single-bank system). For G7: requester 0 keeps its urgent request until granted and is not blocked by a write. Write starvation is bounded separately by TC03's force counter. |
| `dbuf_2sets`, `dbuf_1set` | TC03 `tob_dbuf_ctrl`, 2 sets / 1 set (the double-buffer and the sequential configurations of the unit) | PROVEN, k = 6 / 4 | B1 only EMPTY → FILL → READY → COMPUTE → EMPTY. B2 at most one DMA-owned and one compute-owned set. B3 every `*_ready` is exactly its precondition. B4 FILL → READY only through `fill_end` (which requires `dma_idle`, i.e. no DMA write in flight), and COMPUTE → EMPTY only through `cmp_end` (which requires `engine_idle`). B5 strict ping-pong. B6 (2 sets) the set at `cmp_set` is the oldest and the most advanced; the younger set is never COMPUTE; FILL is always at `fill_set`; the pointer distance equals the number of sets past FILL. | None (free handshakes and idle inputs) |
| `bus_gate` | TC08 `tsu_bus_gate`, 8-bit data, 4-bit counter | PROVEN, k = 5 | R1 outstanding = accepted − answered (request conservation). R2 an unsolicited response never reaches the adapter. R3 downstream SFB2 R2: a presented request stays presented and unchanged until accepted, also when quiesce rises. R4 transparent when not quiescing. R5 no new request while quiescing; `quiesced` ⇒ nothing presented, nothing outstanding. | The upstream master obeys SFB2 R2 and keeps ≤ 6 transactions outstanding (the 4-bit counter's range; the unit uses MAX_OUT ≤ 16 with a 6-bit counter). The fabric is unconstrained. |
| `pe_mp0` | TC02 `tensor_pe`, INT8 / INT32, MUL_PIPE 0 (the integrated configuration) | PROVEN, k = 3 | A1 a commit adds exactly the sign-extended product. A2 no change without a commit. **A3 `n·(−16 256) ≤ acc ≤ n·16 384` for n MACs since the clear, so for n ≤ 131 071 the 32-bit accumulator never wraps.** A4 done is sticky and rises only on the commit of a last-tagged pair. A5 `en = 0` freezes. A6 one-hop forwarding. | At most 131 071 MACs between clears. This is the TSU contract: K ≤ K_MAX, with a clear at every array launch. |
| `pe_mp1` | same, MUL_PIPE 1 | BOUNDED, 16 cycles | A2–A6 with the pipelined product and last tag | As above. Bounded because the product register is internal and can hold under a stall indefinitely, which defeats port-level k-induction. |

## Seeded-bug results

All 15 seeded bugs give a counterexample: dropped count update, read pointer +2, count off by one, write
at the read pointer, write hazard not blocked, frozen round-robin pointer, 1RW hazard computed as 1R1W,
seal ignoring the in-flight write, compute claiming a FILLING set, quiesce withdrawing a presented
request, unsolicited response forwarded, accumulator subtracting, product zero-extended, done raised by
any MAC, and last tag lost in the product stage.

## Not covered by formal

TC04 accumulator, TC05 quantiser, TC07 DMA channels and TC08 scheduler / validator. These are verified
by simulation against independent reference models (see `docs/VERIFICATION_PLAN.md`).
