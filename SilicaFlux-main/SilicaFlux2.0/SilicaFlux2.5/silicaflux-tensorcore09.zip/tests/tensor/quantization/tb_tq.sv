// =============================================================================
// SilicaFlux TENSORCORE 09 :: tb_tq -- cocotb wrapper of the quantiser
// DUT: TENSORCORE 05 tensor_quantize, unmodified.
// Checkers: chk_out (output payload stable under backpressure), chk_txn (one
// output beat per accepted input beat, never more), chk_rst.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_tq #(
  parameter int ROWS = 4, COLS = 4, IN_W = 32, NUM_CTX = 2, NUM_GRP = 1, ASYM_EN = 0,
  localparam int CTX_W = (NUM_CTX > 1) ? $clog2(NUM_CTX) : 1,
  localparam int RIDW = (ROWS > 1) ? $clog2(ROWS) : 1
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 desc_valid,
  output logic                      desc_ready,
  input  wire logic [255:0]         desc_data,
  output logic                      desc_ok,
  output logic                      desc_rej,
  output logic [3:0]                desc_rej_code,
  input  wire logic                 p_valid,
  output logic                      p_ready,
  input  wire logic [15:0]          p_grp,
  input  wire logic [COLS-1:0]      p_lane_mask,
  input  wire logic [4:0]           p_fmask,
  input  wire logic [COLS*32-1:0]   p_bias,
  input  wire logic [COLS*32-1:0]   p_mult,
  input  wire logic [COLS*6-1:0]    p_shift,
  input  wire logic [COLS*32-1:0]   p_zp,
  input  wire logic [COLS*IN_W-1:0] p_cs,
  output logic                      p_err,
  output logic [1:0]                p_err_code,
  input  wire logic                 in_valid,
  output logic                      in_ready,
  input  wire logic [CTX_W-1:0]     in_ctx,
  input  wire logic [15:0]          in_tag,
  input  wire logic [RIDW-1:0]      in_row,
  input  wire logic [COLS-1:0]      in_col_mask,
  input  wire logic                 in_last,
  input  wire logic [COLS*IN_W-1:0] in_data,
  input  wire logic [COLS-1:0]      in_ovf,
  input  wire logic                 in_err,
  output logic                      out_valid,
  input  wire logic                 out_ready,
  output logic [15:0]               out_tag,
  output logic [CTX_W-1:0]          out_ctx,
  output logic [RIDW-1:0]           out_row,
  output logic [31:0]               out_m,
  output logic [31:0]               out_ch0,
  output logic [COLS-1:0]           out_col_mask,
  output logic                      out_last,
  output logic [3:0]                out_fmt,
  output logic [COLS*32-1:0]        out_data,
  output logic [COLS*8-1:0]         out_q8,
  output logic [COLS-1:0]           out_sat,
  output logic [COLS-1:0]           out_iovf,
  output logic                      out_err,
  output logic [2:0]                out_err_code,
  output logic                      idle
);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NUM_CTX-1:0] ctx_open, ctx_poison;
  logic [15:0] desc_err_sticky;
  logic [7:0]  beat_err_sticky;
  logic [3:0]  param_err_sticky;
  logic [tensor_quantize_pkg::NPERF*32-1:0] perf_o;
  /* verilator lint_on UNUSEDSIGNAL */
  logic perf_clr = 1'b0;
  tensor_quantize #(.ROWS(ROWS), .COLS(COLS), .IN_W(IN_W), .NUM_CTX(NUM_CTX), .NUM_GRP(NUM_GRP),
                    .ASYM_EN(ASYM_EN), .OFIFO_DEPTH(4), .PERF_EN(1), .PERF_W(32)) dut (.*);

  localparam int OW = 16 + CTX_W + RIDW + 32 + 32 + COLS + 1 + 4 + COLS*32 + COLS*8 + COLS + COLS + 1 + 3;
  chk_handshake #(.W(OW)) chk_out (.clk(clk), .rst_n(rst_n), .valid(out_valid), .ready(out_ready),
    .data({out_tag, out_ctx, out_row, out_m, out_ch0, out_col_mask, out_last, out_fmt, out_data, out_q8, out_sat,
           out_iovf, out_err, out_err_code}));
  integer t_out, t_in, t_ret;
  chk_req_rsp #(.MAX_OUT(8)) chk_txn (.clk(clk), .rst_n(rst_n), .req_valid(in_valid), .req_ready(in_ready),
    .rsp_valid(out_valid), .rsp_ready(out_ready), .outstanding(t_out), .n_req(t_in), .n_rsp(t_ret));
  chk_reset #(.N(4), .NK(3)) chk_rst (.clk(clk), .rst_n(rst_n), .quiet({out_valid, desc_ok, desc_rej, p_err}),
    .known({in_ready, desc_ready, idle}));
endmodule
`default_nettype wire
