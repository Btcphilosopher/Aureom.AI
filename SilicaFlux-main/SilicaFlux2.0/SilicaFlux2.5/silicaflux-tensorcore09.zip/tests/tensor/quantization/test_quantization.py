"""Quantisation verification: TENSORCORE 05 tensor_quantize.

Element values come from reference_models/quant_ref.py (floor-divmod rounding, a
formulation independent of both the RTL's guard / sticky algorithm and TC05's own
Fraction model); descriptor validation follows the TC05 NUMERIC_FORMAT §8.2 rule
table.  Scoreboard: every output beat (lanes, packed INT8 view, saturation flags,
upstream-overflow passthrough, element indices, error codes).

Brief items: requantisation rounding (all five modes, exact ties of both signs, the
maximum shift 63, negative multipliers), saturation (exactly at and one past
-128 / 127 and the INT32 rails), ReLU at the zero-point, bias (INT32 + table bias,
wrap), per-channel tables, descriptor rejects / poisoned contexts, beat errors,
context waiting and output backpressure.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
try:
    import cocotb
    from common.harness import tensor_test, FallingEdge, RisingEdge, ReadOnly, PARAMS, pick
except ImportError:
    tensor_test = None

from reference_models.quant_ref import QParams, requant, round_shift, OFMT_INT32, OFMT_INT8, QRANGE  # noqa: E402
from reference_models.gemm_ref import to_signed, srange  # noqa: E402

R = int(PARAMS.get("ROWS", 4))
C = int(PARAMS.get("COLS", 4))
IN_W = int(PARAMS.get("IN_W", 32))
NCTX = int(PARAMS.get("NUM_CTX", 2))
NGRP = int(PARAMS.get("NUM_GRP", 1))
IMIN, IMAX = srange(IN_W)
FL_BIAS, FL_RQ, FL_PC, FL_RELU, FL_WRAP = 1, 2, 4, 8, 16
QR = dict(OK=0, VERSION=1, OPCODE=2, CTX=3, RSVD=4, STATE=5, FMT=6, RM=7, FLAGS=8, UNSUP=9, DIM=10, ZP=11,
          CHAN=12, PARAM=13, PZP=14)
BE = dict(NONE=0, NOCTX=1, TAG=2, POISON=3, FRAME=4, UPSTREAM=5)
FM_BIAS, FM_MULT, FM_SHIFT, FM_ZP = 1, 2, 4, 8
CHECKERS = ["chk_out", "chk_txn", "chk_rst"]


def desc(op=0x40, ver=1, rm=0, flags=0, ofmt=0, tag=0, ctx=0, m=1, n=1, grp=0, m0=0, mult=0, shift=0, za=0, zb=0,
         zp=0, rsvd=None):
    w = [0] * 8
    w[0] = (op & 0xFF) | (ver & 0xF) << 8 | (rm & 7) << 12 | (flags & 0xFF) << 16 | (ofmt & 0xF) << 24
    w[1] = (tag & 0xFFFF) | (ctx & 0xFF) << 16
    w[2] = (m & 0xFF) | (n & 0xFF) << 8 | (grp & 0xFFFF) << 16
    w[3] = m0 & 0xFFFF_FFFF
    w[4] = mult & 0xFFFF_FFFF
    w[5] = (shift & 0x3F) | (za & 0xFF) << 8 | (zb & 0xFF) << 16
    w[6] = zp & 0xFFFF_FFFF
    for k, v in (rsvd or {}).items():
        w[k] |= v
    return w


class TqModel:
    """Descriptor rules of TC05 NUMERIC_FORMAT §8.2 and the element contract (quant_ref)."""

    def __init__(self):
        self.ctx = [None] * NCTX
        self.tab = [[dict(bias=0, mult=0, shift=0, zp=0, vld=0) for _ in range(C)] for _ in range(NGRP)]

    def param(self, grp, lane_mask, fmask, bias, mult, shift, zp):
        if grp >= NGRP:
            return 1
        for j in range(C):
            if (lane_mask >> j) & 1:
                e = self.tab[grp][j]
                for f, key, val in ((FM_BIAS, "bias", bias[j]), (FM_MULT, "mult", mult[j]),
                                    (FM_SHIFT, "shift", shift[j]), (FM_ZP, "zp", zp[j])):
                    if fmask & f:
                        e[key] = val
                        e["vld"] |= f
        return 0

    def open(self, d):
        """-> (code, kind) and updates the context table."""
        op, ver, rm, fl, ofmt, tag, ctx = d["op"], d["ver"], d["rm"], d["flags"], d["ofmt"], d["tag"], d["ctx"]
        if ver != 1:
            return QR["VERSION"], "none"
        if op not in (0x40, 0x41):
            return QR["OPCODE"], "none"
        if ctx >= NCTX:
            return QR["CTX"], "none"
        if op == 0x41:
            if any(d[k] for k in ("rm", "flags", "ofmt", "m", "n", "grp", "m0", "mult", "shift", "za", "zb", "zp")) \
                    or d["rsvd"]:
                return QR["RSVD"], "none"
            if self.ctx[ctx] is None or self.ctx[ctx]["tag"] != tag:
                return QR["STATE"], "none"
            self.ctx[ctx] = None
            return QR["OK"], "close"
        bias, rq, pc, relu, wrap = (bool(fl & f) for f in (FL_BIAS, FL_RQ, FL_PC, FL_RELU, FL_WRAP))
        m, n, grp = d["m"], d["n"], d["grp"]
        table = bias or pc or d["za"] != 0
        need = (FM_BIAS if bias else 0) | ((FM_MULT | FM_SHIFT | FM_ZP) if pc else 0)
        qlo, qhi = QRANGE.get(ofmt, (0, 0))
        code = QR["OK"]
        if d["rsvd"] or fl & 0xE0:
            code = QR["RSVD"]
        elif ofmt not in (OFMT_INT32, OFMT_INT8):
            code = QR["FMT"]
        elif rm > 4:
            code = QR["RM"]
        elif (pc and not rq) or (wrap and ofmt != OFMT_INT32):
            code = QR["FLAGS"]
        elif (not rq and (rm or d["mult"] or d["shift"] or d["zp"])) or (pc and (d["mult"] or d["shift"] or d["zp"])):
            code = QR["RSVD"]
        elif d["zb"] != 0 or d["za"] != 0:
            code = QR["UNSUP"]
        elif not (1 <= m <= R) or not (1 <= n <= C) or d["m0"] + m - 1 > 0xFFFF_FFFF:
            code = QR["DIM"]
        elif rq and not pc and not (qlo <= d["zp"] <= qhi):
            code = QR["ZP"]
        elif table and grp >= NGRP:
            code = QR["CHAN"]
        elif table and any((self.tab[grp][j]["vld"] & need) != need for j in range(n)):
            code = QR["PARAM"]
        elif pc and any(not (qlo <= self.tab[grp][j]["zp"] <= qhi) for j in range(n)):
            code = QR["PZP"]
        lanes = []
        if code == QR["OK"]:
            for j in range(n):
                e = self.tab[grp][j] if table else None
                lanes.append(dict(bias=e["bias"] if bias else 0,
                                  q=QParams(mult=(e["mult"] if pc else d["mult"]) if rq else 1,
                                            shift=(e["shift"] if pc else d["shift"]) if rq else 0,
                                            zp=(e["zp"] if pc else d["zp"]) if rq else 0, rm=rm, relu=relu,
                                            ofmt=ofmt, rq=rq, wrap=wrap)))
        self.ctx[ctx] = dict(tag=tag, poison=code != QR["OK"], m=m, n=n, m0=d["m0"], ch0=grp * C, ofmt=ofmt,
                             lanes=lanes)
        return code, ("open" if code == QR["OK"] else "poison")

    def beat(self, ctx, tag, row, cmask, last, err, data, ovf):
        cm = (1 << C) - 1
        out = dict(tag=tag, ctx=ctx, row=row, cmask=cmask & cm, last=last, iovf=ovf & cmask & cm, data=[0] * C,
                   sat=0, m=0, ch0=0, fmt=0, err=0, code=BE["NONE"])
        if ctx >= NCTX:
            out.update(err=1, code=BE["NOCTX"])
            return out
        s = self.ctx[ctx]
        if s["tag"] != tag:
            out.update(err=1, code=BE["TAG"])
            return out
        if s["poison"]:
            out.update(err=1, code=BE["POISON"])
            if last:
                self.ctx[ctx] = None
            return out
        tm = (1 << s["n"]) - 1
        code = BE["NONE"]
        if row >= s["m"] or (cmask & cm) != tm or bool(last) != (row == s["m"] - 1):
            code = BE["FRAME"]
        elif err:
            code = BE["UPSTREAM"]
        out.update(err=int(code != 0), code=code, m=(s["m0"] + row) & 0xFFFF_FFFF, ch0=s["ch0"], fmt=s["ofmt"])
        for j in range(C):
            if (cmask >> j) & 1 and (tm >> j) & 1:
                ln = s["lanes"][j]
                q, sat = requant(data[j], ln["q"], bias=ln["bias"])
                out["data"][j] = q
                out["sat"] |= int(sat) << j
        if last:
            self.ctx[ctx] = None
        return out


def decode(w):
    return dict(op=w[0] & 0xFF, ver=(w[0] >> 8) & 0xF, rm=(w[0] >> 12) & 7, flags=(w[0] >> 16) & 0xFF,
                ofmt=(w[0] >> 24) & 0xF, tag=w[1] & 0xFFFF, ctx=(w[1] >> 16) & 0xFF, m=w[2] & 0xFF,
                n=(w[2] >> 8) & 0xFF, grp=w[2] >> 16, m0=w[3], mult=to_signed(w[4], 32), shift=w[5] & 0x3F,
                za=to_signed((w[5] >> 8) & 0xFF, 8), zb=(w[5] >> 16) & 0xFF, zp=to_signed(w[6], 32),
                rsvd=bool((w[0] >> 15) & 1 or w[0] >> 28 or w[1] >> 24 or (w[5] >> 6) & 3 or w[5] >> 24 or w[7]))


def pk(vals, w):
    return sum((v & ((1 << w) - 1)) << (i * w) for i, v in enumerate(vals))


class Tq:
    def __init__(self, dut, rng, cov):
        self.dut, self.rng, self.cov, self.m = dut, rng, cov, TqModel()
        self.exp, self.bp = [], 0.3
        self.n_out = 0
        for s in ("desc_valid", "p_valid", "in_valid", "in_err", "in_last"):
            getattr(dut, s).value = 0
        for s in ("desc_data", "p_grp", "p_lane_mask", "p_fmask", "p_bias", "p_mult", "p_shift", "p_zp", "p_cs",
                  "in_ctx", "in_tag", "in_row", "in_col_mask", "in_data", "in_ovf"):
            getattr(dut, s).value = 0
        dut.out_ready.value = 1

    async def start(self):
        for _ in range(3):
            await FallingEdge(self.dut.clk)
        self.dut.rst_n.value = 1
        await FallingEdge(self.dut.clk)
        self.mon = cocotb.start_soon(self._out())

    async def _hs(self, v, r):
        d = self.dut
        v.value = 1
        n = 0
        while True:
            await RisingEdge(d.clk)
            if int(r.value):
                break
            n += 1
            assert n < 50000, "handshake timeout"
            await FallingEdge(d.clk)
        await FallingEdge(d.clk)
        v.value = 0

    async def descriptor(self, **kw):
        d = self.dut
        w = desc(**kw)
        code, kind = self.m.open(decode(w))
        d.desc_data.value = sum(x << (32 * i) for i, x in enumerate(w))
        d.desc_valid.value = 1
        while True:
            await RisingEdge(d.clk)
            if int(d.desc_ready.value):
                break
            await FallingEdge(d.clk)
        await FallingEdge(d.clk)
        d.desc_valid.value = 0
        await ReadOnly()
        got = (int(d.desc_ok.value), int(d.desc_rej.value), int(d.desc_rej_code.value))
        assert got == (int(code == 0), int(code != 0), code), f"descriptor {kw}: (ok, rej, code) {got}, expected {code}"
        self.cov.hit("desc", [k for k, v in QR.items() if v == code][0])
        await FallingEdge(d.clk)
        return code

    async def param(self, grp, lane_mask, fmask, bias=None, mult=None, shift=None, zp=None):
        d = self.dut
        z = [0] * C
        bias, mult, shift, zp = bias or z, mult or z, shift or z, zp or z
        e = self.m.param(grp, lane_mask, fmask, bias, mult, shift, zp)
        d.p_grp.value, d.p_lane_mask.value, d.p_fmask.value = grp, lane_mask, fmask
        d.p_bias.value, d.p_mult.value, d.p_shift.value, d.p_zp.value = pk(bias, 32), pk(mult, 32), pk(shift, 6), \
            pk(zp, 32)
        await self._hs(d.p_valid, d.p_ready)
        await ReadOnly()
        assert int(d.p_err.value) == int(e != 0)
        await FallingEdge(d.clk)

    async def beat(self, ctx, tag, row, data, cmask=None, last=None, err=0, ovf=0):
        d = self.dut
        s = self.m.ctx[ctx] if ctx < NCTX else None
        cmask = ((1 << s["n"]) - 1) if cmask is None else cmask
        last = int(row == s["m"] - 1) if last is None else last
        d.in_ctx.value, d.in_tag.value, d.in_row.value = ctx % (1 << len(d.in_ctx)), tag, row
        d.in_col_mask.value, d.in_last.value, d.in_err.value, d.in_ovf.value = cmask, last, err, ovf
        d.in_data.value = pk(data, IN_W)
        self.exp.append(self.m.beat(ctx, tag, row, cmask, last, err, data, ovf))
        await self._hs(d.in_valid, d.in_ready)

    async def _out(self):
        d = self.dut
        while True:
            d.out_ready.value = int(self.rng.random() >= self.bp)
            await RisingEdge(d.clk)
            if int(d.out_valid.value) and int(d.out_ready.value):
                assert self.exp, "output beat without an input beat"
                e = self.exp.pop(0)
                od, q8 = int(d.out_data.value), int(d.out_q8.value)
                data = [to_signed((od >> (32 * j)) & 0xFFFF_FFFF, 32) for j in range(C)]
                got = dict(tag=int(d.out_tag.value), ctx=int(d.out_ctx.value), row=int(d.out_row.value),
                           cmask=int(d.out_col_mask.value), last=int(d.out_last.value), iovf=int(d.out_iovf.value),
                           data=data, sat=int(d.out_sat.value), m=int(d.out_m.value), ch0=int(d.out_ch0.value),
                           fmt=int(d.out_fmt.value), err=int(d.out_err.value), code=int(d.out_err_code.value))
                if e["err"]:
                    for k in ("data", "sat", "m", "ch0", "fmt"):          # payload of a flagged beat: don't care
                        got.pop(k)
                        e = {kk: vv for kk, vv in e.items() if kk != k}
                assert got == e, f"output beat:\n got {got}\n exp {e}"
                if not e["err"] and e.get("fmt") == OFMT_INT8:
                    for j in range(C):
                        assert to_signed((q8 >> (8 * j)) & 0xFF, 8) == (data[j] if j < 32 else 0)
                self.n_out += 1
            await FallingEdge(d.clk)

    async def drain(self):
        n = 0
        while self.exp or not int(self.dut.idle.value):
            await FallingEdge(self.dut.clk)
            n += 1
            assert n < 100000, "quantiser never drained"


def tie_acc(rng, mult, shift):
    """An accumulator value whose product with mult is an exact tie at 2^-1 after the shift
    (when one exists in the input range)."""
    if shift == 0 or mult == 0:
        return rng.randint(IMIN, IMAX)
    for _ in range(64):
        q = rng.randint(-(1 << 20), 1 << 20)
        p = (q << shift) + (1 << (shift - 1))
        if p % mult == 0 and IMIN <= p // mult <= IMAX:
            return p // mult
    return rng.randint(IMIN, IMAX)


if tensor_test is not None:

    async def setup(dut, rng, cov):
        cov.define("desc", [k for k in QR])
        cov.define("rm", ["RNE", "RTZ", "RDN", "RUP", "RMM"])
        t = Tq(dut, rng, cov)
        await t.start()
        return t

    @tensor_test(checkers=CHECKERS)
    async def int8_requant_random(dut, rng, cov):
        """Per-tensor INT8 requantisation: random M (incl. negative / 0 / extremes), S 0..63, zp,
        rounding mode, ReLU; accumulators biased to the rails and to exact rounding ties."""
        t = await setup(dut, rng, cov)
        for it in range(pick(60, 400)):
            mult = rng.choice([0, 1, -1, (1 << 31) - 1, -(1 << 31), rng.randint(-(1 << 31), (1 << 31) - 1),
                               rng.randint(1, 1 << 16)])
            shift = rng.choice([0, 1, 2, 31, 32, 63, rng.randint(0, 63)])
            zp, rm, relu = rng.randint(-128, 127), rng.randint(0, 4), rng.random() < 0.3
            m, n, ctx, tag = rng.randint(1, R), rng.randint(1, C), it % NCTX, it & 0xFFFF
            await t.descriptor(tag=tag, ctx=ctx, m=m, n=n, m0=rng.randint(0, 1000), rm=rm, ofmt=OFMT_INT8,
                               flags=FL_RQ | (FL_RELU if relu else 0), mult=mult, shift=shift, zp=zp)
            cov.hit("rm", ["RNE", "RTZ", "RDN", "RUP", "RMM"][rm])
            for r in range(m):
                data = [rng.choice([IMIN, IMAX, 0, -1, 1, tie_acc(rng, mult, shift), rng.randint(IMIN, IMAX)])
                        for _ in range(C)]
                await t.beat(ctx, tag, r, data, ovf=rng.randint(0, (1 << C) - 1))
        await t.drain()

    @tensor_test(checkers=CHECKERS)
    async def rounding_ties_every_mode(dut, rng, cov):
        """v = k + 1/2 for positive and negative k, and v = k +- 1/4, in all five modes (M = 1)."""
        t = await setup(dut, rng, cov)
        tag = 0
        for rm in range(5):
            for shift in (1, 2, 5, 31, 63 if IN_W >= 64 else 30):
                vals = []
                for k in (-3, -2, -1, 0, 1, 2, 3):
                    base = k << shift
                    for frac in ((1 << (shift - 1)), (1 << (shift - 2)) if shift >= 2 else 0,
                                 3 << (shift - 2) if shift >= 2 else 0):
                        v = base + frac
                        if IMIN <= v <= IMAX:
                            vals.append(v)
                for i in range(0, len(vals), C):
                    chunk = (vals[i:i + C] + [0] * C)[:C]
                    tag += 1
                    await t.descriptor(tag=tag, ctx=0, m=1, n=C, rm=rm, ofmt=OFMT_INT8, flags=FL_RQ, mult=1,
                                       shift=shift)
                    await t.beat(0, tag, 0, chunk)
            cov.hit("rm", ["RNE", "RTZ", "RDN", "RUP", "RMM"][rm])
        await t.drain()

    @tensor_test(checkers=CHECKERS)
    async def saturation_boundaries(dut, rng, cov):
        """y exactly 127 / 128 / -128 / -129 (with and without zp), INT32 rails with bias,
        wrap (INT32 only), ReLU floor at a non-zero zero-point."""
        t = await setup(dut, rng, cov)
        tag = 0
        for zp in (0, -128, 127, 5, -5):
            ys = [127, 128, -128, -129, 0, 1000, -1000]
            accs = [y - zp for y in ys]
            for i in range(0, len(accs), C):
                tag += 1
                await t.descriptor(tag=tag, ctx=0, m=1, n=C, ofmt=OFMT_INT8, flags=FL_RQ, mult=1, shift=0, zp=zp)
                await t.beat(0, tag, 0, (accs[i:i + C] + [0] * C)[:C])
                tag += 1
                await t.descriptor(tag=tag, ctx=1 % NCTX, m=1, n=C, ofmt=OFMT_INT8, flags=FL_RQ | FL_RELU, mult=1,
                                   shift=0, zp=zp)
                await t.beat(1 % NCTX, tag, 0, (accs[i:i + C] + [0] * C)[:C])
        cov.hit("sat", "int8_boundaries")
        if NGRP >= 1:
            await t.param(0, (1 << C) - 1, FM_BIAS, bias=[1, -1, (1 << 31) - 1, -(1 << 31)][:C] + [0] * max(0, C - 4))
            for wrap in (0, FL_WRAP):
                tag += 1
                await t.descriptor(tag=tag, ctx=0, m=1, n=C, ofmt=OFMT_INT32, flags=FL_BIAS | wrap)
                await t.beat(0, tag, 0, ([IMAX, IMIN, IMAX, IMIN] + [0] * C)[:C])
            cov.hit("sat", "int32_bias_wrap")
        await t.drain()

    @tensor_test(checkers=CHECKERS)
    async def int32_passthrough_exact(dut, rng, cov):
        """INT32 output without requantisation is the accumulator bit for bit (IN_W = 32) or its
        saturated value (IN_W > 32), with the saturation flag."""
        t = await setup(dut, rng, cov)
        for it in range(pick(30, 200)):
            m, n = rng.randint(1, R), rng.randint(1, C)
            await t.descriptor(tag=it, ctx=it % NCTX, m=m, n=n, ofmt=OFMT_INT32)
            for r in range(m):
                await t.beat(it % NCTX, it, r, [rng.choice([IMIN, IMAX, rng.randint(IMIN, IMAX)]) for _ in range(C)])
        await t.drain()

    @tensor_test(checkers=CHECKERS, skip_if=(NGRP < 2))
    async def per_channel_tables(dut, rng, cov):
        """Per-channel M / S / zp / bias loaded through the parameter port with lane masks;
        lane j of group g uses channel g*COLS + j."""
        t = await setup(dut, rng, cov)
        for g in range(NGRP):
            await t.param(g, (1 << C) - 1, FM_BIAS | FM_MULT | FM_SHIFT | FM_ZP,
                          bias=[rng.randint(-5000, 5000) for _ in range(C)],
                          mult=[rng.randint(-(1 << 31), (1 << 31) - 1) for _ in range(C)],
                          shift=[rng.randint(20, 40) for _ in range(C)], zp=[rng.randint(-128, 127) for _ in range(C)])
        await t.param(NGRP, 1, FM_BIAS, bias=[1] * C)               # PW_GRP: group out of range
        for it in range(pick(20, 100)):
            g = rng.randint(0, NGRP - 1)
            m = rng.randint(1, R)
            await t.descriptor(tag=it, ctx=it % NCTX, m=m, n=C, grp=g, ofmt=OFMT_INT8, rm=rng.randint(0, 4),
                               flags=FL_RQ | FL_PC | FL_BIAS)
            for r in range(m):
                await t.beat(it % NCTX, it, r, [rng.randint(IMIN, IMAX) for _ in range(C)])
        cov.hit("desc", "per_channel")
        # PZP: lane 0 of group 0 gets a zero point outside the INT8 output range (the table field is 32 bits)
        await t.param(0, 1, FM_ZP, zp=[200] + [0] * (C - 1))
        tag = 200
        assert await t.descriptor(tag=tag, ctx=0, m=1, n=C, grp=0, ofmt=OFMT_INT8, rm=0,
                                  flags=FL_RQ | FL_PC | FL_BIAS) == QR["PZP"]
        await t.beat(0, tag, 0, [7] * C)                             # poisoned context drains, flagged
        await t.drain()

    @tensor_test(checkers=CHECKERS)
    async def descriptor_rejects_and_poison(dut, rng, cov):
        """Every reachable rule of the validation table; hard rejects open nothing, soft rejects
        open the context POISONED and its beats drain flagged; CLOSE semantics."""
        t = await setup(dut, rng, cov)
        T = t.descriptor
        assert await T(ver=2, tag=1) == QR["VERSION"]
        assert await T(op=0x42, tag=1) == QR["OPCODE"]
        if NCTX < 256:
            assert await T(ctx=NCTX, tag=1) == QR["CTX"]
        soft = [dict(rsvd={0: 1 << 15}), dict(ofmt=2), dict(ofmt=OFMT_INT8, flags=FL_RQ, rm=5),
                dict(flags=FL_PC), dict(ofmt=OFMT_INT8, flags=FL_WRAP), dict(mult=3), dict(flags=FL_RQ | FL_PC,
                                                                                         ofmt=OFMT_INT8, shift=2),
                dict(zb=1), dict(za=1), dict(m=0), dict(n=C + 1), dict(m0=0xFFFF_FFFF, m=2 if R > 1 else 1),
                dict(ofmt=OFMT_INT8, flags=FL_RQ, zp=128), dict(flags=FL_BIAS, grp=NGRP),
                dict(flags=FL_BIAS, grp=0)]               # PARAM: bias table not loaded since reset
        exp_codes = []
        for i, kw in enumerate(soft):
            kw = dict(kw)
            kw.setdefault("m", 1)
            tag = 100 + i
            code = await T(tag=tag, ctx=0, n=kw.pop("n", 1), **kw)
            exp_codes.append(code)
            if code in (QR["VERSION"], QR["OPCODE"], QR["CTX"]):
                continue
            if code != 0:
                await t.beat(0, tag, 0, [7] * C, cmask=1, last=1)     # poisoned context drains, flagged
            else:
                await t.beat(0, tag, 0, [7] * C, cmask=1, last=1)
        # PARAM: bias table needed but never loaded for group 0 (fresh reset)
        assert {QR["RSVD"], QR["DIM"], QR["UNSUP"], QR["PARAM"], QR["CHAN"], QR["ZP"]} <= set(exp_codes)
        # CLOSE: of an open context (OK), of a closed one (STATE), with a field set (RSVD)
        await T(tag=7, ctx=0, m=1, n=1)
        assert await T(op=0x41, tag=7, ctx=0, m=1, n=0) == QR["RSVD"]          # CLOSE with a field set: kept open
        assert await T(op=0x41, tag=6, ctx=0, m=0, n=0) == QR["STATE"]         # wrong tag
        assert await T(op=0x41, tag=7, ctx=0, m=0, n=0) == QR["OK"]
        assert await T(op=0x41, tag=7, ctx=0, m=0, n=0) == QR["STATE"]         # already closed
        await t.drain()

    @tensor_test(checkers=CHECKERS)
    async def beat_errors_and_context_wait(dut, rng, cov):
        """TAG mismatch, FRAME (row >= M, wrong mask, wrong last) and UPSTREAM (TC04 o_err) beats are
        delivered flagged, never dropped; a beat whose context is not open waits for its descriptor."""
        t = await setup(dut, rng, cov)
        d = dut
        m = min(2, R)
        await t.descriptor(tag=5, ctx=0, m=m, n=1, ofmt=OFMT_INT32)
        await t.beat(0, 6, 0, [1] * C, cmask=1, last=0)                      # TAG
        await t.beat(0, 5, 0, [1] * C, cmask=3 if C > 1 else 1, last=0)      # FRAME (mask) when C > 1
        await t.beat(0, 5, 0, [2] * C, cmask=1, last=0, err=1)               # UPSTREAM
        await t.beat(0, 5, m - 1, [3] * C, cmask=1, last=1)                  # closes the context
        await t.drain()
        # the beat arrives first and must wait (in_ready low) until the descriptor opens the context
        d.in_ctx.value, d.in_tag.value, d.in_row.value, d.in_col_mask.value, d.in_last.value = 0, 9, 0, 1, 1
        d.in_data.value, d.in_err.value, d.in_ovf.value = 77, 0, 0
        d.in_valid.value = 1
        for _ in range(10):
            await RisingEdge(d.clk)
            assert int(d.in_ready.value) == 0, "beat accepted before its context was opened"
            await FallingEdge(d.clk)
        d.in_valid.value = 0
        await t.descriptor(tag=9, ctx=0, m=1, n=1, ofmt=OFMT_INT32)
        await t.beat(0, 9, 0, [77] + [0] * (C - 1))
        await t.drain()
        cov.hit("beat", "context_wait")


# =============================================================================== pytest runner

def cfg(rows=4, cols=4, in_w=32, nctx=2, ngrp=1):
    return dict(ROWS=rows, COLS=cols, IN_W=in_w, NUM_CTX=nctx, NUM_GRP=ngrp, ASYM_EN=0)


CONFIGS = [cfg(),                         # integrated: per-tensor INT8, 2 contexts, one table group
           cfg(rows=2, cols=2), cfg(rows=8, cols=8),
           cfg(ngrp=4, nctx=3),           # per-channel tables (not reachable from the TSU ABI)
           cfg(in_w=40)]                  # wide accumulator input (TC04 ACC_W = 40)


def _id(c):
    return f"{c['ROWS']}x{c['COLS']}_in{c['IN_W']}_ctx{c['NUM_CTX']}_grp{c['NUM_GRP']}"


@pytest.mark.parametrize("cfg", CONFIGS, ids=_id)
def test_quantization(cfg):
    from common import sim
    srcs, incs = sim.tc08_subset("tensor_acc_fifo.sv", "tensor_quantize_pkg.sv", "tensor_quant_params.sv", "tensor_quant_lane.sv",
                                 "tensor_quantize.sv")
    sim.run("quantization", "tb_tq", "test_quantization",
            srcs + sim.checker_sources() + [TT / "quantization" / "tb_tq.sv"], cfg, includes=incs, tag=_id(cfg))
