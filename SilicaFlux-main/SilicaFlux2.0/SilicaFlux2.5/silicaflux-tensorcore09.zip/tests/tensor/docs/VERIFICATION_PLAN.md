# Verification plan and traceability (brief §3–§13 → tests)

Notation: `suite.test` is a cocotb test in `tests/tensor/<suite>/test_*.py`, and runs once per configuration of
that suite. `chk_*` are SV checkers in `assertions/`, bound in the suite's `tb_*.sv`. Formal jobs are in
`formal/FORMAL.md`.

## §3 Independent mathematical reference — `reference_models/`

| Requirement | Implementation | Self-test evidence (`reference_models/test_reference_models.py`) |
|---|---|---|
| Exact integer GEMM, no NumPy INT8 matmul | `gemm_ref.gemm`: triple loop over Python ints | Equals the chunked and tiled forms (25 random shapes); NumPy **int64** cross-check; the INT8 matmul pitfall is demonstrated (the result differs) |
| Overflow policy | `AccPolicy.EXACT / WRAP / SATURATE` with explicit order (`accumulate`, `gemm_policy` per MAC or per chunk) | Policy and order-dependence tests; `max_exact_k` by corner division = closed form (DW 2..8, ACC up to 64) = exhaustive enumeration (5 small widths) |
| Row-major, leading dimensions | `ByteMemory` load / store with byte LD, unaligned bases | Round-trip test (gaps untouched) |
| Partial tiles | `output_tiles`, `tsu_model.schedule` | Every element covered exactly once (200 random shapes × 2 orders) |
| K chunking | `k_chunks`, `gemm_chunked`, TC04 chunk model | Chunked = direct |
| Bias | `gemm(bias=)`, `gemm_policy(bias=)` (once, with chunk 0) | Literal test; accumulator suite |
| Quantisation | `quant_ref.round_shift` (floor divmod), `requant` | Exhaustive \|p\| ≤ 2^11, S ≤ 10, all 5 modes, three independent formulations; 20 000 random full-width; spec tables; ReLU/saturation commutation; 5 000 random vs TC05's own model |
| Command semantics | `tsu_model`: encoding, 15 validation rules, schedule, DMA descriptors, exact SFB2 traffic, expected records and memory (incl. DMA errors) | Published encodings, ABI constants vs `tsu_defs.svh`, 90 000 fuzzed descriptors vs TC08 `tsu_ref` |

## §4 Arithmetic verification

| Case | Where |
|---|---|
| All-zero | `systolic_array.directed_values` (zero), `integration.arithmetic_extremes` (zero_a, zero_b) |
| Identity-like | `systolic_array.directed_values` (I·B, A·I, −I, permutation), `integration.arithmetic_extremes` |
| Max positive / max negative | `pe.corner_products`, `systolic_array.directed_values` (max / min / mixed), `integration.arithmetic_extremes` (max_positive = (−128)², max_negative = −128·127, max_127) |
| Random signed INT8 | everywhere; `pe.all_products` (all 65 536 products at full level, 4 096 at quick) |
| Cancellation | `pe.cancellation`, `systolic_array.long_k_reduction`, `integration.arithmetic_extremes` |
| Long K | `pe.longest_exact_reduction` / `tc01 long_reduction_exact_int32` (K = 131 071), `systolic_array.long_k_reduction` (1 000 / 4 096; 131 071 at full), `integration.arithmetic_extremes` (4 096 quick / 131 071 full) |
| Accumulator overflow boundaries | `tc01 overflow_boundary_positive/negative` (K = MAX_EXACT_K exact, +1 overflows; SAT and WRAP); `pe.accumulator_wrap_boundary` (TC02 wrap); `accumulator.strict_range_boundaries` (131 071 / 131 072, bias 16 383 / 16 384 / −16 793 472 / −16 793 473, one column); formal `pe_mp0` A3 (no wrap within 131 071 MACs) |
| Bias | `accumulator.chunked_accumulation_exact`, `.host_operations` (once per element, again after CLEAR), `quantization.saturation_boundaries` (INT32 bias + wrap) |
| Requantisation rounding | `quantization.rounding_ties_every_mode` (exact ties ± ¼, both signs, all modes, shifts up to 30/63), `.int8_requant_random`, `integration.quantised_output` |
| Saturation | `tc01 saturation_recovery_and_sticky_flag`, `accumulator.overflow_policy_via_preload`, `quantization.saturation_boundaries` (127 / 128 / −128 / −129 with zp), `integration.quantised_output` (SAT record bit) |
| Exact comparison | Every output element of every tile / command against the reference; whole memory image in the unit-level suites |

## §5 Systolic timing — `systolic_array/` (+ `chk_pe`, `chk_array_core`)

| Item | Check |
|---|---|
| Operand skew, wavefront propagation | Python wavefront monitor: every PE input on every enabled cycle = A[i][k], B[k][j] with k = e−1−i−j |
| K alignment | Same monitor (k index, last tag); `chk_pe` P1 pairing, P1b k sequence 0..K−1 |
| Pipeline fill / drain | All active PEs done after exactly K+M+N−1+MUL_PIPE enabled cycles; busy = 1+K+M+N+MP+stalls |
| Tile completion | `chk_array_core` Y2 (no readout before every active PE committed K MACs), Y5 (rows in order, M beats) |
| Global stalls | `global_stall_freeze` (full internal snapshot frozen), random `stall_i` in RUN and DRAIN |
| Reset | `reset_during_tile` (RUN / DRAIN / READOUT), `chk_reset` |
| No duplicated / omitted MAC | `chk_pe` P4 (no MAC after the last), commit counts = K per active PE and 0 per padding PE (Y2), perf MACs = M·N·K |
| Transaction scoreboards | Result-row scoreboard, slice handshake scoreboard (`s_k`), perf-counter scoreboard |

## §6 Memory — `operand_buffer/`, `dma/`

| Item | Test |
|---|---|
| Bank conflicts | `operand_buffer.bank_conflicts_and_simultaneous_reads` (conflict counter > 0, data exact); formal `bank_arb_*` |
| Simultaneous reads | Same; every A lane and the B fetcher in parallel; `chk_arb` G1–G3 per physical bank |
| DMA writes | `operand_buffer.fill_and_compute_strided` (gaps, strobes, response backpressure), `dma.*` (exact SFB2 traffic) |
| Buffer ownership | `operand_buffer.dma_errors_no_side_effect` (OWNER in EMPTY / READY / COMPUTE, no side effect), `chk_ownership` O1–O6, `dma.internal_errors_by_fault_injection` (BUF_ACCESS / 6), formal `dbuf_*` |
| Double-buffer transitions | `operand_buffer.double_buffer_ping_pong` (overlap counter > 0, strict alternation), `integration.double_buffering` |
| Address boundaries | `operand_buffer.tile_validation_boundaries` (last byte SET−1 / SET, 2^32 overflow), `.dma_errors_no_side_effect` (hole, past B, misaligned, read), `chk_addr_range` on the SFB2 port |
| Read / write hazards | `operand_buffer.write_read_contention` (1RW banks, forced writes), TOB_ASSERT same-row check, formal `bank_arb` G5 |
| Strided matrix access | `operand_buffer.fill_and_compute_strided`, `dma.strided_unaligned_operands` (every base and LD residue mod 4; exact traffic) |

## §7 Scheduler — `tile_controller/` (+ stream monitor in `common/tsu_env.py`)

| Item | Test |
|---|---|
| One tile / multiple tiles / multiple K chunks / partial edge tiles | `test_scheduler.tiles_and_chunks` (descriptor + job + TC05 OPEN streams field by field); `test_tile_iter.*` |
| Invalid dimensions | `test_scheduler.invalid_commands_have_no_side_effect` (every rule at its boundary; no bus traffic) |
| Backpressure | `test_scheduler.completion_queue_backpressure` (CPL_STALL > 0, scheduler in RECORD), memory backpressure in every TSU suite |
| Reset during execution | `test_scheduler.reset_during_execution` |
| Consecutive GEMMs | `integration.consecutive_commands` (queue-full doorbell refusals, NOPs, invalid commands, RAW chain) |
| Error propagation | `test_scheduler.error_propagation_stop_and_continue`, `.abort_running_and_queued`, `.interrupts`; `dma.read/write_error_injection` (incl. stop-on-error: commands queued behind a DMA write error are SKIPPED), `dma.internal_errors_by_fault_injection`, `dma.watchdog_slow_and_dead_memory`; `integration.consecutive_commands` (invalid commands mixed into a GEMM stream in continue mode, then a stop-mode tail) |

## §8 System level — `integration/`

`brief_shapes`: 1×1×1, 4×4×4, 5×7×3, 8×8×8, 17×13×29, 31×19×257, strided and unaligned. `random_shapes`
covers random M, N, K, KC, order, latency and backpressure. Every element is compared through the
whole-memory image, plus exact traffic, records, counters and streams. Seven configurations: 4×4
baseline, 2×2, 8×8, INT8, double buffering, MAX_OUT = 1, and TILE_K 16 / K_MAX 4096 / INT8 / double
buffering.

## §9 Assertions

| Brief assertion | Checker | Bound in |
|---|---|---|
| FIFO safety | `chk_fifo` (F1–F5), `chk_fifo_credit` | TSU command / completion queues; formal `cmdq_*`, `dmafifo_*` |
| Stable payload under backpressure | `chk_handshake` (H1–H3) | every stream of every bench; DataFabric `sfb_protocol_checker` on SFB2 |
| No duplicate completion | `chk_once` (DMA descriptor ids), `chk_seq` (record SEQ), `chk_inorder` | `tb_tsu` |
| No dropped accepted request | `chk_req_rsp` (outstanding → 0), `chk_seq` (n_cmd = n_rec), `chk_once` (pending → 0); end-of-test closure | `tb_tsu`, `tb_tob`, `tb_tq` |
| Buffer ownership | `chk_ownership` (O1–O6) | `tb_tob`, `tb_tsu` (operand and output buffers) |
| Memory address bounds | `chk_addr_range` | SFB2 port of `tb_tsu` |
| Valid MAC operand pairing | `chk_pe` (P1–P7) per PE | `tb_pe`, `tb_array` (every PE); `chk_never` on the integrated array's alignment flag |
| No output commit before final accumulation | `chk_array_core` Y2; `chk_precedes` (TC04 commit before DMA drain); accumulator scoreboard | `tb_array`, `tb_tsu`, accumulator suite |
| Reset behaviour | `chk_reset` (Z1–Z3) | every bench |

Every checker counts its evaluations, so a vacuous checker fails the test (`n_chk = 0`). RTL-internal
`$error`s also fail the test.

## §10 Formal — see `formal/FORMAL.md` (bounds and assumptions)

## §11 Randomised testing

Deterministic seeds: `TENSOR_SEED`, with each test drawing `Random(f"{seed}:{suite}:{test}")`. The
following are randomised:

- matrix dimensions
- operand values (biased to extremes and ties)
- memory latency (`Sfb2Memory.lat`)
- DMA stalls (request backpressure, fill gaps, response backpressure)
- array stalls (`stall_i`, slice gaps, readout backpressure)
- command sequences (NOP / GEMM / invalid mixes, RAW chains)
- buffer availability (output / host / completion-queue backpressure, ping-pong sets)

Failing seeds and waveforms are saved under `regression/failures/` (see its README).

## §12 Commands / reports — see `README.md`

## Ambiguities resolved — see `docs/FINDINGS.md`
