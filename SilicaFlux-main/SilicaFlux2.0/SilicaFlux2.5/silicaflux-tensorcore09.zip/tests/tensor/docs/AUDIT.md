# Audit: tensor RTL and verification infrastructure in the repository (before TENSORCORE 09)

## 1. Where the tensor RTL lives

The repository has no top-level RTL tree. Each TENSORCORE stage was delivered as a ZIP archive:

| Stage | Archive (repository path) | Content |
|---|---|---|
| TC01 | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore01-tensor_pe.zip` | Standalone INT8 PE with a selectable SAT / WRAP overflow policy, plus its own SV bench, Yosys SAT proof and coverage. **Not integrated** in later stages. |
| TC02 | `…/silicaflux-tensorcore02.zip` | A new PE (silent wrap at ACC_WIDTH), skew, output collection, `tensor_systolic_array`. SV benches, mutation testing. |
| TC03 | `…/silicaflux-tensorcore03.zip` | `tensor_operand_buffer`: banked A / B buffers, ownership controller, DMA fill port, tile AGU |
| TC04 | `…/silicaflux-tensorcore04.zip` | `tensor_acc_subsystem`: K-chunk accumulator, STRICT_RANGE, SAT / WRAP |
| TC05 | `…/silicaflux-tensorcore05.zip` | `tensor_quantize`: requantisation (five rounding modes), bias, ReLU, per-channel tables; a Fraction-based Python reference |
| TC06 | `…/silicaflux-tensorcore06.zip` | `ttc_tile_iter` plus a tile controller (TC08 keeps only the iterator) |
| TC07 | `…/silicaflux-tensorcore07.zip` | `tensor_dma_adapter`, `tensor_output_buffer`, `tdma_compute_seq` |
| TC08 | `SilicaFlux-main/silicaflux-tensorcore08.zip` | `silicaflux_tensor_unit`, the complete accelerator. It vendors TC02–TC07, HPC M04 / M08 and DataFabric **byte for byte** under `third_party/`, with checksum lists. |

TENSORCORE 09 therefore verifies the TC08 tree as **the** RTL of the TensorCore. `scripts/stage_rtl.py`
extracts it into `build/rtl/tc08`, never edits it, and verifies all 342 checksummed files, including the
114 vendored ones. It also stages TC01 (overflow-policy PE) and TC02 (to re-run its shipped regression).
The archive SHA-256 values and the repository commit form the "RTL revision" in every report.

## 2. Existing verification, and what was reused

| Existing item | Kind | Reused how |
|---|---|---|
| TC01–TC08 SV testbenches + Python vector generators | Self-checking SV benches (Icarus + Verilator), file driven | Re-run unchanged by `scripts/run_legacy.py` (TC08 ABI check, lint, stages 1–2(–3); TC02 lint and 2×2 stage), as an independent second line of evidence. Not used as the TC09 oracle. |
| TC05 `model/tq_ref.py` (Fraction rounding) | Reference model | Cross-checked against the new `quant_ref.py` (floor-divmod rounding) in the reference self-tests. Not used as the oracle. |
| TC08 `model/tsu_ref.py` | Validator, schedule, traffic reference | Cross-checked against the new `tsu_model.py`: 90 000 fuzzed descriptors through both validators, 300 random schedules. Its two resolutions of ambiguous ABI text are adopted and documented (FINDINGS D3). |
| TC08 `tb/tb_tsu.sv` host / memory protocol | SV bench | Its register-bus timing (doorbell sampled in the strobe cycle) and SFB2 memory semantics (write performed when answered, R7) are re-implemented in cocotb (`common/tsu_env.py`, `common/sfb2.py`). |
| DataFabric `tb/common/sfb_protocol_checker.sv` | SV protocol checker | Instantiated unchanged in `integration/tb_tsu.sv` beside the new checkers. |
| RTL-internal assertions (`TOB_ASSERT`, `SRAMLIB_ASSERT`, TC07 / TC08 `$error` checks) | Simulation assertions | Enabled in every build. The runner scans the log and fails the cocotb test during which an RTL `$error` fired. |
| RTL fault hooks (`FAULT_INJ`) | Verification hooks | Used by the DMA suite to provoke ownership violations and accumulator-range refusals. |
| TC01 `formal/run_formal.py` (Yosys `sat -prove-asserts`) | Formal | The approach (Yosys, seeded bugs for vacuity) is reused. TC09 adds temporal BMC / k-induction proofs with yosys-smtbmc. |
| cocotb | — | **None existed** in the tensor stages. TC09 introduces it. |
| CI | — | **None existed.** TC09 adds `.github/workflows/tensor-verification.yml`. |
| Repository Makefile | — | **None existed.** TC09 adds the root `Makefile` delegating `tensor-*`. |

## 3. Tools found / installed

The container had none of the HDL tools. The Ubuntu 24.04 packages were installed: Verilator 5.020,
Icarus Verilog 12.0, Yosys 0.33 (with yosys-smtbmc), z3 4.8.12, boolector 1.5. These are the versions
TC01–TC08 report. cocotb 2.1.0, pytest 9 and pytest-xdist 3.8 come from PyPI. TC08's own `make quick`
was re-run first and passes with these tools (lint 11/11, illegal configurations 18/18, stage 1 2/2).

Constraints that shaped the framework:

- cocotb 2.1 supports Verilator ≥ 5.036 only, so the cocotb suites run on Icarus. Verilator is used for
  lint and for the legacy SV regressions.
- Yosys 0.33 has no hierarchical references in formal, so harnesses are port-level.
- boolector 1.5 does not accept yosys-smtbmc's output, so z3 is used.

## 4. Gaps in the earlier verification that TC09 addresses

- No single framework or command covered all blocks; each stage verified itself in isolation, with its
  own vectors.
- No formal proof of the TC08 control blocks (TC08 doc 09: "no formal proof of the new RTL").
- The TC01 PE's overflow policy had no relation to the integrated (TC02) PE's silent wrap. TC09
  verifies both and proves (`pe_mp0`, A3) that the integrated PE cannot wrap within K_MAX MACs.
- No machine-generated report combining results, coverage, seeds, tool versions and RTL revision; no CI.
