# Known verification gaps

These are stated plainly so that a passing report is not read as more than it is.

**Kind of evidence**

- **RTL simulation only, with Icarus Verilog 12 through cocotb 2.1.** cocotb 2.x needs Verilator
  ≥ 5.036, and Ubuntu 24.04 ships 5.020. Verilator is therefore used for lint / elaboration of every RTL
  configuration and testbench, and in the optional re-run of the shipped TC02 / TC08 SV regressions
  (`make tensor-legacy`). It does not run the cocotb suites.
- No gate-level simulation, static timing, power, FPGA bitstream or silicon.

**Formal**

- Formal covers control blocks only: the two FIFO types, the bank arbiter, buffer ownership, the bus
  gate and the PE MAC step.
- Yosys 0.33 cannot resolve hierarchical references, so every property is port-level:
  - FIFO data integrity (order, no loss, no duplication) is **bounded**: 12 cycles for DEPTH 4, 16 for
    DEPTH 2. Only the control invariants are proven unbounded.
  - The MUL_PIPE = 1 PE is **bounded** (16 cycles). Its product register is not port-visible and can
    hold under a stall indefinitely.
- No formal proof of the accumulator (TC04), quantiser (TC05), DMA adapter (TC07) or scheduler
  (TC08). These are verified by simulation with independent reference models only.
- Every proof holds only for the stated parameters, for example arbiters with 4 and 8 readers.

**Functional scope**

- Each feature is tested where it is reachable:
  - The TC05 per-channel tables, the TC04 40-bit accumulator with INT32 clipping, `STRICT_RANGE = 0`
    and `OVF_POLICY = WRAP` are verified at unit level only. The TENSORCORE 08 ABI cannot reach them:
    requantisation is per tensor and TC04 is integrated with `SATURATE` and `STRICT_RANGE = 1`.
  - TC01's PE (SAT / WRAP policy) is verified standalone. It is not part of TC08.
- The integration suites cover the verified shapes 2×2, 4×4 and 8×8, plus TILE_K 16 / 64, MAX_OUT
  1 / 2 / 4 / 16, quantised output and double buffering. Shapes accepted only with `ALLOW_UNVERIFIED` are
  out of scope.
- `K = 131 071` end to end, the longest overflow-free reduction, runs at the **full** level only. The
  quick level uses `K = 4096` end to end. Both PE suites (TC02 and TC01) run K = 131 071 at quick
  level; the 2×2 array runs it at the full level only.
- The DataFabric crossbar with a competing master is not instantiated by these suites. TC08's own
  `contention` and `system` tests cover it in the legacy re-run with `--full`. Here, memory contention is
  modelled by request backpressure and latency.
- Hard reset is applied at random points of multi-tile GEMMs. Reset is not swept exhaustively over
  every scheduler state.
- Abort is checked against the set of legal outcomes, because the abort point is timing dependent.
  Its exact record is not predicted.
- After a DMA **read** error, COUNT / TILES are checked for consistency with each other and with the
  memory image, not for exact values: the overlap of the STORE of earlier tiles with later loads is
  timing dependent. Write errors are predicted exactly.

**Coverage**

- Functional coverage is the set of coverpoints these suites declare (report §7).
- No structural (line / toggle / branch) coverage is collected. Icarus provides none, and Verilator
  coverage would need the cocotb-on-Verilator flow above.

**Seeds**

- The quick level (`make tensor-test`) runs one seed.
- `make tensor-regression` runs three seeds at the full level.
- The numbers in this delivery's report come from the run recorded in its §1.
