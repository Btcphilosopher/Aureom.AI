// =============================================================================
// SilicaFlux TENSORCORE 09 :: tb_pe_tc01 -- cocotb wrapper of the TC01 PE
// DUT: TENSORCORE 01 tensor_pe (standalone PE with an explicit SAT / WRAP
// accumulator overflow policy and a sticky overflow flag; not integrated in
// TC08, verified here for its overflow policy), unmodified.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_pe_tc01 #(
  parameter int unsigned ACC_W      = 32,
  parameter int unsigned MUL_STAGES = 1,
  parameter int unsigned OVF_POLICY = 0
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                enable_i,
  input  wire logic                clear_acc_i,
  input  wire logic signed [7:0]   operand_a_i,
  input  wire logic signed [7:0]   operand_b_i,
  input  wire logic                operand_valid_i,
  output logic signed [ACC_W-1:0]  acc_result_o,
  output logic                     acc_valid_o,
  output logic                     overflow_o,
  output logic signed [7:0]        a_fwd_o,
  output logic signed [7:0]        b_fwd_o,
  output logic                     valid_fwd_o,
  output logic                     clear_fwd_o
);
  tensor_pe #(.A_W(8), .B_W(8), .ACC_W(ACC_W), .MUL_STAGES(MUL_STAGES), .OVF_POLICY(OVF_POLICY),
              .OPERAND_GATING(1'b1), .K_LIMIT_SEVERITY(0)) dut (
    .clk_i(clk), .rst_ni(rst_n), .enable_i(enable_i), .clear_acc_i(clear_acc_i), .operand_a_i(operand_a_i),
    .operand_b_i(operand_b_i), .operand_valid_i(operand_valid_i), .acc_result_o(acc_result_o),
    .acc_valid_o(acc_valid_o), .overflow_o(overflow_o), .a_fwd_o(a_fwd_o), .b_fwd_o(b_fwd_o),
    .valid_fwd_o(valid_fwd_o), .clear_fwd_o(clear_fwd_o));

  // the PE resets asynchronously: everything is quiet immediately
  chk_reset #(.N(3), .NK(3)) chk_rst (.clk(clk), .rst_n(rst_n), .quiet({acc_valid_o, overflow_o, valid_fwd_o}),
                                      .known({acc_valid_o, overflow_o, valid_fwd_o}));
endmodule
`default_nettype wire
