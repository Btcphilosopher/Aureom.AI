"""Accumulator overflow policy: TENSORCORE 01 tensor_pe (SAT / WRAP, sticky overflow flag).

The TC01 PE is the only PE in the repository with a selectable overflow policy
(the integrated TC02 PE wraps silently and relies on K <= K_MAX).  Its contract
(TC01 docs/INTERFACE_SPEC.md) is modelled independently:

    acc_next = policy((clear ? 0 : acc) + a*b),  overflow sticky until the next clear,
    one result token per accepted command, L = MUL_STAGES + 2 enabled cycles later,
    the token shows the prefix result including its command.

Tests: the exact boundary K = MAX_EXACT_K (no overflow) / MAX_EXACT_K + 1 (overflow)
on the positive and the negative side, saturation clamping and recovery, wrap
modulo 2^ACC_W, flag stickiness and its clearing by clear-and-load, random streams
with stalls / clears / asynchronous reset compared cycle by cycle.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
try:
    import cocotb  # noqa: F401
    from cocotb.triggers import ClockCycles
    from common.harness import tensor_test, FallingEdge, ReadOnly, PARAMS, pick
except ImportError:
    tensor_test = None

from reference_models.gemm_ref import fits, saturate, wrap, max_exact_k, srange  # noqa: E402

ACC_W = int(PARAMS.get("ACC_W", 32))
MS = int(PARAMS.get("MUL_STAGES", 1))
SAT = int(PARAMS.get("OVF_POLICY", 0)) == 0
L = MS + 2
KX = max_exact_k(8, ACC_W)
AMIN, AMAX = srange(ACC_W)


class Tc01Model:
    def __init__(self):
        self.reset()

    def reset(self):
        self.pipe = [None] * L
        self.acc, self.ovf, self.tok = 0, 0, 0
        self.run_acc, self.run_ovf = 0, 0          # in-order architectural state at the ACC stage
        self.s0 = dict(v=0, c=0)
        self.a_fwd = self.b_fwd = None

    def step(self, rst_n, en, clr, v, a, b):
        if not rst_n:
            self.reset()
            return
        if not en:
            return
        cmd = (clr, v, a, b) if (v or clr) else None
        self.pipe = [cmd] + self.pipe[:-1]
        # S0 .. S_MS .. ACC are L registers: the command accepted at this edge is pipe[0]; the one
        # in pipe[L-1] is applied to the accumulator at this edge and is the visible token after it
        self.tok = 0
        t = self.pipe[L - 1]
        if t is not None:
            c, vv, aa, bb = t
            base = 0 if c else self.acc
            ob = 0 if c else self.ovf
            s = base + (aa * bb if vv else 0)
            o = not fits(s, ACC_W)
            self.acc = (saturate(s, ACC_W) if SAT else wrap(s, ACC_W)) if o else s
            self.ovf = int(ob or o)
            self.tok = 1
        self.s0 = dict(v=int(v), c=int(clr))
        if v:
            self.a_fwd, self.b_fwd = a, b


async def drive_cycle(dut, m, rst_n=1, en=1, clr=0, v=0, a=0, b=0, check=True):
    dut.rst_n.value, dut.enable_i.value, dut.clear_acc_i.value = rst_n, en, clr
    dut.operand_valid_i.value, dut.operand_a_i.value, dut.operand_b_i.value = v, a & 0xFF, b & 0xFF
    await ReadOnly()
    if check and rst_n:
        got = (dut.acc_result_o.value.to_signed(), int(dut.acc_valid_o.value), int(dut.overflow_o.value),
               int(dut.valid_fwd_o.value), int(dut.clear_fwd_o.value))
        exp = (m.acc, m.tok, m.ovf, m.s0["v"], m.s0["c"])
        assert got == exp, f"RTL (acc, tok, ovf, vfwd, cfwd) {got} != model {exp}"
        if m.a_fwd is not None:
            assert (dut.a_fwd_o.value.to_signed(), dut.b_fwd_o.value.to_signed()) == (m.a_fwd, m.b_fwd)
    m.step(rst_n, en, clr, v, a, b)
    await FallingEdge(dut.clk)


async def start(dut):
    m = Tc01Model()
    await FallingEdge(dut.clk)
    for _ in range(3):
        await drive_cycle(dut, m, rst_n=0, check=False)
    await drive_cycle(dut, m, check=False)
    return m


async def stream(dut, m, pairs, clear_first=True):
    if len(pairs) > 4096 and len(set(pairs)) == 1:
        # long constant stream: hold the inputs, let the simulator run, apply the model in bulk
        a, b = pairs[0]
        await drive_cycle(dut, m, clr=int(clear_first), v=1, a=a, b=b)
        dut.clear_acc_i.value = 0
        await ClockCycles(dut.clk, len(pairs) - 1, rising=False)
        for _ in range(len(pairs) - 1):
            m.step(1, 1, 0, 1, a, b)
        for _ in range(L):
            await drive_cycle(dut, m)
        return m.acc, m.ovf
    for i, (a, b) in enumerate(pairs):
        await drive_cycle(dut, m, clr=int(clear_first and i == 0), v=1, a=a, b=b)
    for _ in range(L):
        await drive_cycle(dut, m)
    return m.acc, m.ovf


if tensor_test is not None:

    @tensor_test(checkers=["chk_rst"])
    async def overflow_boundary_positive(dut, rng, cov):
        """K = MAX_EXACT_K products of (-128)(-128) are exact; one more overflows."""
        m = await start(dut)
        if KX > 140000:
            cov.hit("boundary_pos", "too_long_for_simulation")
            return
        acc, ovf = await stream(dut, m, [(-128, -128)] * KX)
        assert (acc, ovf) == (KX * 16384, 0)
        acc, ovf = await stream(dut, m, [(-128, -128)] * (KX + 1))
        assert ovf == 1
        assert acc == (AMAX if SAT else wrap((KX + 1) * 16384, ACC_W))
        cov.hit("boundary_pos", "sat" if SAT else "wrap")

    @tensor_test(checkers=["chk_rst"])
    async def overflow_boundary_negative(dut, rng, cov):
        """Negative side: the most negative product -16256 = (-128)(127)."""
        m = await start(dut)
        k_neg = (-AMIN) // 16256
        if k_neg > 140000:
            cov.hit("boundary_neg", "too_long_for_simulation")
            return
        acc, ovf = await stream(dut, m, [(-128, 127)] * k_neg)
        assert (acc, ovf) == (-16256 * k_neg, 0)
        acc, ovf = await stream(dut, m, [(127, -128)] * (k_neg + 1))
        assert ovf == 1 and acc == (AMIN if SAT else wrap(-16256 * (k_neg + 1), ACC_W))

    @tensor_test(checkers=["chk_rst"])
    async def saturation_recovery_and_sticky_flag(dut, rng, cov):
        """After saturating, later products move the value away from the rail again (saturation
        is per step, not a sticky value) while the overflow flag stays set until a clear."""
        m = await start(dut)
        if KX > 4096:
            cov.hit("sticky", "skipped_large_acc")
            return
        pairs = [(-128, -128)] * (KX + 3) + [(-128, 127)] * 5 + [(1, 1)]
        acc, ovf = await stream(dut, m, pairs)
        exp, flag = 0, False
        for a, b in pairs:
            s = exp + a * b
            if not fits(s, ACC_W):
                flag = True
                s = saturate(s, ACC_W) if SAT else wrap(s, ACC_W)
            exp = s
        assert (acc, ovf) == (exp, 1) and flag
        # clear-and-load: a new accumulation starts with the flag cleared, no bubble
        acc, ovf = await stream(dut, m, [(3, 5), (2, 2)])
        assert (acc, ovf) == (19, 0)
        cov.hit("sticky", "cleared_by_clear_and_load")

    @tensor_test(checkers=["chk_rst"])
    async def long_reduction_exact_int32(dut, rng, cov):
        """ACC_W = 32: K = 131071 worst-case products stay exact (inputs held constant)."""
        m = await start(dut)
        if ACC_W != 32:
            return
        await drive_cycle(dut, m, clr=1, v=1, a=-128, b=-128)
        dut.operand_valid_i.value = 1
        dut.clear_acc_i.value = 0
        await ClockCycles(dut.clk, KX - 1, rising=False)
        dut.operand_valid_i.value = 0
        for _ in range(L + 1):
            await FallingEdge(dut.clk)
        await ReadOnly()
        assert dut.acc_result_o.value.to_signed() == KX * 16384 and int(dut.overflow_o.value) == 0
        await FallingEdge(dut.clk)
        m2 = await start(dut)
        await stream(dut, m2, [(1, 1)])

    @tensor_test(checkers=["chk_rst"])
    async def random_stream_policy(dut, rng, cov):
        """Random operands biased to extremes, clears, stalls and asynchronous resets; every
        output compared every cycle with the policy model."""
        m = await start(dut)
        for _ in range(pick(5000, 50000)):
            rst = 0 if rng.random() < 0.003 else 1
            en = int(rng.random() > 0.15)
            clr = int(rng.random() < 0.03)
            v = int(rng.random() < 0.8)
            if rng.random() < 0.6:
                a, b = rng.choice([-128, 127]), rng.choice([-128, 127])
            else:
                a, b = rng.randint(-128, 127), rng.randint(-128, 127)
            if m.ovf:
                cov.hit("random", "overflow_seen")
            await drive_cycle(dut, m, rst_n=rst, en=en, clr=clr, v=v, a=a, b=b, check=bool(rst))
        await drive_cycle(dut, m)


CONFIGS = [dict(ACC_W=16, MUL_STAGES=1, OVF_POLICY=0), dict(ACC_W=16, MUL_STAGES=1, OVF_POLICY=1),
           dict(ACC_W=20, MUL_STAGES=2, OVF_POLICY=0), dict(ACC_W=20, MUL_STAGES=2, OVF_POLICY=1),
           dict(ACC_W=24, MUL_STAGES=4, OVF_POLICY=0), dict(ACC_W=32, MUL_STAGES=1, OVF_POLICY=0),
           dict(ACC_W=32, MUL_STAGES=1, OVF_POLICY=1), dict(ACC_W=40, MUL_STAGES=1, OVF_POLICY=1)]


def _id(c):
    return f"acc{c['ACC_W']}_ms{c['MUL_STAGES']}_{'sat' if c['OVF_POLICY'] == 0 else 'wrap'}"


@pytest.mark.parametrize("cfg", CONFIGS, ids=_id)
def test_tc01_pe_overflow_policy(cfg):
    from common import sim
    srcs = [sim.TC01 / "rtl" / "tensor_pe_pkg.sv", sim.TC01 / "rtl" / "tensor_pe.sv"]
    sim.run("pe", "tb_pe_tc01", "test_pe_tc01", srcs + sim.checker_sources() + [TT / "pe" / "tb_pe_tc01.sv"],
            cfg, tag=_id(cfg))
