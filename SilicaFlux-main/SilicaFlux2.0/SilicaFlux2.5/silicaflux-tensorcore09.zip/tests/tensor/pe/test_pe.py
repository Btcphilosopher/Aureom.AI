"""PE verification: TENSORCORE 02 tensor_pe (the PE integrated in silicaflux_tensor_unit).

Independent cycle model (PeModel) written from the PE's documented contract
(TC02 tensor_pe header: forwarding, MUL_PIPE latency, stall / clear / done
semantics, ACC_WIDTH wrap) is compared with every output on every cycle; the SV
checker chk_pe adds pairing / MAC-exactness / duplicate-MAC assertions on top.

Arithmetic cases: corner products, every INT8 x INT8 product (full level; a
deterministic sample at quick level), cancellation, the longest overflow-free
reduction K = 131071 of (-128)(-128), and the documented silent wrap of the PE
accumulator when ACC_WIDTH is too small.  Protocol cases: stalls (en), one-sided
tokens, clear overriding en, reset in the middle of an accumulation, alignment
checker (CHECK_ALIGN).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))

try:
    import cocotb  # noqa: F401
    from cocotb.triggers import ClockCycles
    from common.harness import (tensor_test, reset, FallingEdge, RisingEdge, ReadOnly, PARAMS, pick, full,
                                corner_bin, CORNER_BINS)
except ImportError:                      # collected by pytest outside a simulator: only the runner is used
    tensor_test = None

from reference_models.gemm_ref import wrap, accumulate, AccPolicy  # noqa: E402

DW = int(PARAMS.get("DATA_WIDTH", 8))
AW = int(PARAMS.get("ACC_WIDTH", 32))
KW = int(PARAMS.get("KIDX_WIDTH", 17))
MP = int(PARAMS.get("MUL_PIPE", 0))
CA = int(PARAMS.get("CHECK_ALIGN", 1))
LO, HI = -(1 << (DW - 1)), (1 << (DW - 1)) - 1
CHECKERS = ["chk_mac", "chk_rst"]


class PeModel:
    """Cycle model of tensor_pe written from its interface contract."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.fa = dict(v=0, last=0, data=0, kidx=0)
        self.fb = dict(v=0, last=0, data=0, kidx=0)
        self.acc = 0
        self.done = 0
        self.pv, self.plast, self.prod = 0, 0, 0

    def comb(self, en, chk_en, a, b):
        fire = a["v"] and b["v"]
        mac = fire if MP == 0 else self.pv
        err = 0
        if CA:
            err = (fire and a["kidx"] != b["kidx"]) or (fire and a["last"] != b["last"]) or (chk_en and a["v"] != b["v"])
        return dict(fire=int(en and fire), commit=int(en and mac), err=int(bool(en and err)))

    def step(self, rst_n, clr, en, a, b):
        if not rst_n or clr:
            self.reset()
            return
        if not en:
            return
        fire = a["v"] and b["v"]
        if MP == 0:
            mac, mlast, mprod = fire, a["last"] and b["last"], a["data"] * b["data"]
        else:
            mac, mlast, mprod = self.pv, self.plast, self.prod
            self.pv, self.plast = int(fire), int(fire and a["last"] and b["last"])
            if fire:
                self.prod = a["data"] * b["data"]
        self.fa, self.fb = dict(a), dict(b)
        if mac:
            self.acc = wrap(self.acc + mprod, AW)
            if mlast:
                self.done = 1


def tok(v=0, last=0, data=0, kidx=0):
    # the k index is a KIDX_WIDTH-bit field carried through the PE: it wraps on reductions longer
    # than 2^KIDX_WIDTH (full-level streams on narrow configurations), in the RTL and here alike
    return dict(v=int(v), last=int(last), data=int(data), kidx=int(kidx) & ((1 << KW) - 1))


IDLE = tok()


class Bench:
    def __init__(self, dut, cov=None):
        self.dut, self.m, self.cov, self.cycles, self.checked = dut, PeModel(), cov, 0, 0
        self.rst_n, self.clr, self.en, self.chk_en = 1, 0, 1, 0
        self.a, self.b = IDLE, IDLE

    def drive(self):
        d = self.dut
        d.rst_n.value, d.clr.value, d.en.value, d.chk_en.value = self.rst_n, self.clr, self.en, self.chk_en
        for side, t in (("a", self.a), ("b", self.b)):
            getattr(d, f"{side}_valid_i").value = t["v"]
            getattr(d, f"{side}_last_i").value = t["last"]
            getattr(d, f"{side}_data_i").value = t["data"] & ((1 << DW) - 1)
            getattr(d, f"{side}_kidx_i").value = t["kidx"] & ((1 << KW) - 1)

    async def cycle(self, check=True):
        """Present the current inputs for one cycle (set at the falling edge), compare, advance."""
        self.drive()
        await ReadOnly()
        d, m = self.dut, self.m
        if check and self.rst_n:
            c = m.comb(self.en, self.chk_en, self.a, self.b)
            got = dict(acc=d.acc_o.value.to_signed(), done=int(d.done_o.value), fire=int(d.fire_o.value),
                       commit=int(d.commit_o.value), err=int(d.err_o.value),
                       av=int(d.a_valid_o.value), bv=int(d.b_valid_o.value))
            exp = dict(acc=m.acc, done=m.done, fire=c["fire"], commit=c["commit"], err=c["err"],
                       av=m.fa["v"], bv=m.fb["v"])
            if exp["av"]:
                got["ad"], exp["ad"] = d.a_data_o.value.to_signed(), m.fa["data"]
                got["ak"], exp["ak"] = int(d.a_kidx_o.value), m.fa["kidx"]
                got["al"], exp["al"] = int(d.a_last_o.value), m.fa["last"]
            if exp["bv"]:
                got["bd"], exp["bd"] = d.b_data_o.value.to_signed(), m.fb["data"]
                got["bk"], exp["bk"] = int(d.b_kidx_o.value), m.fb["kidx"]
                got["bl"], exp["bl"] = int(d.b_last_o.value), m.fb["last"]
            assert got == exp, f"cycle {self.cycles}: RTL {got} != model {exp}"
            self.checked += 1
        m.step(self.rst_n, self.clr, self.en, self.a, self.b)
        if self.cov is not None and self.en and self.a["v"] and self.b["v"] and self.rst_n and not self.clr:
            self.cov.hit("mac.a_corner", corner_bin(self.a["data"], DW))
            self.cov.hit("mac.b_corner", corner_bin(self.b["data"], DW))
            self.cov.hit("mac.cross", f"{corner_bin(self.a['data'], DW)}x{corner_bin(self.b['data'], DW)}")
        self.cycles += 1
        await FallingEdge(self.dut.clk)

    async def tile(self, pairs, stall_p=0.0, rng=None):
        """One tile: clear, then the (a, b) pairs with last on the final pair, then drain."""
        self.clr = 1
        await self.cycle()
        self.clr = 0
        k = len(pairs)
        i = 0
        while i < k:
            if rng is not None and rng.random() < stall_p:
                self.en = 0
                await self.cycle()
                self.en = 1
                continue
            a, b = pairs[i]
            last = int(i == k - 1)
            self.a, self.b = tok(1, last, a, i), tok(1, last, b, i)
            await self.cycle()
            i += 1
        self.a, self.b = IDLE, IDLE
        for _ in range(2 + MP):
            await self.cycle()
        return self.m.acc


def define_cov(cov):
    cov.define("mac.a_corner", CORNER_BINS)
    cov.define("mac.b_corner", CORNER_BINS)
    cov.define("mac.cross", [f"{x}x{y}" for x in CORNER_BINS for y in CORNER_BINS])


async def start(dut, cov):
    b = Bench(dut, cov)
    dut.chk_off.value = 0
    b.rst_n = 0
    b.drive()
    await FallingEdge(dut.clk)
    for _ in range(3):
        await b.cycle(check=False)
    b.rst_n = 1
    await b.cycle(check=False)
    return b


if tensor_test is not None:

    @tensor_test(checkers=CHECKERS)
    async def corner_products(dut, rng, cov):
        """Every corner pair as its own K=1 tile, then as long same-value reductions."""
        define_cov(cov)
        b = await start(dut, cov)
        corners = sorted({LO, LO + 1, -1, 0, 1, HI - 1, HI})
        for x in corners:
            for y in corners:
                acc = await b.tile([(x, y)])
                assert acc == wrap(x * y, AW) and b.m.done == 1
        for x, y in ((LO, LO), (HI, HI), (LO, HI), (HI, LO)):
            k = 40
            acc = await b.tile([(x, y)] * k)
            assert acc == wrap(k * x * y, AW)

    @tensor_test(checkers=CHECKERS)
    async def all_products(dut, rng, cov):
        """Every INT8 x INT8 product (65 536) streamed through one accumulation; the per-cycle
        model checks each single increment, the final sum is checked against exact arithmetic."""
        define_cov(cov)
        b = await start(dut, cov)
        pairs = [(x, y) for x in range(LO, HI + 1) for y in range(LO, HI + 1)]
        if not full() and len(pairs) > 4096:
            pairs = rng.sample(pairs, 4096) + [(LO, LO), (HI, HI), (LO, HI), (0, 0)]
        acc = await b.tile(pairs)
        assert acc == accumulate([x * y for x, y in pairs], AW, AccPolicy.WRAP).value
        cov.hit("products", "exhaustive" if len(pairs) >= 65536 else "sampled")

    @tensor_test(checkers=CHECKERS)
    async def cancellation(dut, rng, cov):
        """Large positive and negative products that cancel exactly (sum 0, sum +-1)."""
        b = await start(dut, cov)
        for tail in (0, 1, -1):
            pairs = []
            for _ in range(pick(50, 400)):
                x, y = rng.randint(LO, HI), rng.randint(LO, HI)
                pairs += [(x, y), (x, -y if y != LO else HI) if y != LO else (x, y)]
            exact = sum(x * y for x, y in pairs)
            pairs.append((1, -exact + tail) if LO <= -exact + tail <= HI else (0, 0))
            acc = await b.tile(pairs)
            assert acc == wrap(sum(x * y for x, y in pairs), AW)

    @tensor_test(checkers=CHECKERS, skip_if=(DW != 8 or AW != 32))
    async def longest_exact_reduction(dut, rng, cov):
        """K = 131071 products of (-128)(-128): 2 147 467 264, the largest K that cannot overflow
        INT32 (TSU K_MAX).  Inputs are held constant, so the stream runs at full simulator speed."""
        b = await start(dut, cov)
        b.clr = 1
        await b.cycle()
        b.clr = 0
        k = 131071
        d = b.dut
        b.a, b.b = tok(1, 0, LO, 0), tok(1, 0, LO, 0)
        b.drive()
        await ClockCycles(d.clk, k - 1, rising=False)
        b.a, b.b = tok(1, 1, LO, 0), tok(1, 1, LO, 0)
        b.drive()
        await FallingEdge(d.clk)
        b.a, b.b = IDLE, IDLE
        b.drive()
        for _ in range(2 + MP):
            await FallingEdge(d.clk)
        await ReadOnly()
        assert d.acc_o.value.to_signed() == k * 16384 == 2147467264
        assert int(d.done_o.value) == 1
        cov.hit("longk", k)

    @tensor_test(checkers=CHECKERS)
    async def accumulator_wrap_boundary(dut, rng, cov):
        """Drive the accumulator across +max / -min: the TC02 PE keeps the low ACC_WIDTH bits
        (documented: the integrator bounds K so this never happens in the tensor unit)."""
        b = await start(dut, cov)
        pmax = LO * LO
        k_fit = ((1 << (AW - 1)) - 1) // pmax
        if k_fit > 3000:
            cov.hit("wrap", "unreachable_quickly")
            return
        acc = await b.tile([(LO, LO)] * k_fit)
        assert acc == k_fit * pmax                      # no wrap at the bound
        acc = await b.tile([(LO, LO)] * (k_fit + 1))
        assert acc == wrap((k_fit + 1) * pmax, AW) and acc < 0
        acc = await b.tile([(LO, HI)] * (k_fit + 2))
        assert acc == wrap((k_fit + 2) * LO * HI, AW)
        cov.hit("wrap", "crossed")

    @tensor_test(checkers=CHECKERS)
    async def random_protocol(dut, rng, cov):
        """Random token streams: one-sided tokens (padding), stalls, clears, resets, compared
        cycle by cycle with the model (forwarding registers, latency, done, accumulator)."""
        define_cov(cov)
        b = await start(dut, cov)
        k = 0
        closed = False                   # a last-tagged pair was accepted: no pair until the next clear
        for n in range(pick(6000, 60000)):
            r = rng.random()
            b.en = int(rng.random() > 0.2)
            b.clr = int(rng.random() < (0.3 if closed else 0.02))
            if rng.random() < 0.004:
                b.rst_n = 0
                cov.hit("event", "reset_mid")
            else:
                b.rst_n = 1
            if b.clr or not b.rst_n:
                cov.hit("event", "clear_mid" if b.clr else "reset_mid")
                k = 0
            last = int(rng.random() < 0.05)
            x, y = rng.randint(LO, HI), rng.randint(LO, HI)
            if rng.random() < 0.1:
                x, y = rng.choice([LO, HI, 0]), rng.choice([LO, HI, 0])
            if closed and r < 0.6:
                r = 0.9                  # tile protocol: nothing may follow the last pair
            if r < 0.6:
                b.a, b.b = tok(1, last, x, k), tok(1, last, y, k)
            elif r < 0.7:
                b.a, b.b = tok(1, 0, x, k), IDLE
                cov.hit("event", "a_only")
            elif r < 0.8:
                b.a, b.b = IDLE, tok(1, 0, y, k)
                cov.hit("event", "b_only")
            else:
                b.a, b.b = IDLE, IDLE
            if b.en and b.a["v"] and b.b["v"] and b.rst_n and not b.clr:
                k += 1
                closed = closed or bool(last)
            if b.clr or not b.rst_n:
                closed = False
            if not b.en:
                cov.hit("event", "stall")
            await b.cycle(check=b.rst_n == 1)
            if not b.rst_n:
                k = 0
        b.rst_n, b.clr, b.en, b.a, b.b = 1, 0, 1, IDLE, IDLE
        await b.cycle()
        assert b.checked > 1000

    @tensor_test(checkers=CHECKERS)
    async def stall_freeze_and_clear_priority(dut, rng, cov):
        """en = 0 freezes everything even with valid tokens at the pins; clr overrides en."""
        b = await start(dut, cov)
        b.clr = 1
        await b.cycle()
        b.clr = 0
        b.a, b.b = tok(1, 0, min(7, HI), 0), tok(1, 0, max(-9, LO), 0)
        await b.cycle()
        before = b.m.acc
        b.en = 0
        for _ in range(10):
            b.a, b.b = tok(1, 1, rng.randint(LO, HI), 1), tok(1, 1, rng.randint(LO, HI), 1)
            await b.cycle()
        assert b.m.acc == before
        b.clr = 1                                        # clear while stalled
        await b.cycle()
        b.clr, b.en = 0, 1
        b.a, b.b = IDLE, IDLE
        await b.cycle()
        assert b.m.acc == 0 and b.m.done == 0 and int(dut.acc_o.value) == 0

    @tensor_test(checkers=CHECKERS, skip_if=(CA == 0))
    async def alignment_checker(dut, rng, cov):
        """CHECK_ALIGN: k-index mismatch, last mismatch and orphan tokens raise err_o; matched
        pairs and padding outside the active region do not.  (The independent SV pairing
        checker is suspended here: these are deliberate protocol violations.)"""
        b = await start(dut, cov)
        dut.chk_off.value = 1
        cases = [(tok(1, 0, 1, 3), tok(1, 0, 1, 4), 0, 1, "kidx"),
                 (tok(1, 1, 1, 3), tok(1, 0, 1, 3), 0, 1, "last"),
                 (tok(1, 0, 1, 3), IDLE, 1, 1, "orphan_active"),
                 (tok(1, 0, 1, 3), IDLE, 0, 0, "padding_inactive"),
                 (tok(1, 0, 5, 3), tok(1, 0, 6, 3), 1, 0, "matched")]
        for a, bb, chk_en, exp, name in cases:
            b.a, b.b, b.chk_en = a, bb, chk_en
            b.drive()
            await ReadOnly()
            assert int(dut.err_o.value) == exp, name
            cov.hit("align", name)
            await FallingEdge(dut.clk)
            b.m.step(1, 0, 1, a, bb)
        b.a, b.b, b.chk_en = IDLE, IDLE, 0
        b.clr = 1
        await b.cycle(check=False)
        b.clr = 0
        dut.chk_off.value = 0
        await b.cycle(check=False)


# =============================================================================== pytest runner

CONFIGS = [
    dict(DATA_WIDTH=8, ACC_WIDTH=32, KIDX_WIDTH=17, MUL_PIPE=0, CHECK_ALIGN=1),   # integrated configuration
    dict(DATA_WIDTH=8, ACC_WIDTH=32, KIDX_WIDTH=17, MUL_PIPE=1, CHECK_ALIGN=1),
    dict(DATA_WIDTH=8, ACC_WIDTH=32, KIDX_WIDTH=17, MUL_PIPE=0, CHECK_ALIGN=0),
    dict(DATA_WIDTH=8, ACC_WIDTH=16, KIDX_WIDTH=17, MUL_PIPE=0, CHECK_ALIGN=1),   # wrap boundary reachable
    dict(DATA_WIDTH=8, ACC_WIDTH=20, KIDX_WIDTH=17, MUL_PIPE=1, CHECK_ALIGN=1),
    dict(DATA_WIDTH=4, ACC_WIDTH=8, KIDX_WIDTH=8, MUL_PIPE=1, CHECK_ALIGN=1),
]


def _id(c):
    return f"dw{c['DATA_WIDTH']}_acc{c['ACC_WIDTH']}_mp{c['MUL_PIPE']}_ca{c['CHECK_ALIGN']}"


@pytest.mark.parametrize("cfg", CONFIGS, ids=_id)
def test_tensor_pe(cfg):
    from common import sim
    srcs, incs = sim.tc08_subset("tensor_pe.sv")
    sim.run("pe", "tb_pe", "test_pe", srcs + sim.checker_sources() + [TT / "pe" / "tb_pe.sv"], cfg,
            includes=incs, tag=_id(cfg))
