// =============================================================================
// SilicaFlux TENSORCORE 09 :: tb_pe -- cocotb wrapper of the integrated PE
// DUT: TENSORCORE 02 tensor_pe (the PE inside silicaflux_tensor_unit), unmodified.
// Checkers: chk_pe (pairing, MAC exactness, no duplicate MAC, clear/reset),
//           chk_reset (forward tokens quiet in reset).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_pe #(
  parameter int DATA_WIDTH  = 8,
  parameter int ACC_WIDTH   = 32,
  parameter int KIDX_WIDTH  = 17,
  parameter int MUL_PIPE    = 0,
  parameter int CHECK_ALIGN = 1
) (
  input  wire logic                          clk,
  input  wire logic                          rst_n,
  input  wire logic                          clr,
  input  wire logic                          en,
  input  wire logic                          chk_en,
  input  wire logic                          chk_off,
  input  wire logic                          a_valid_i,
  input  wire logic                          a_last_i,
  input  wire logic signed [DATA_WIDTH-1:0]  a_data_i,
  input  wire logic [KIDX_WIDTH-1:0]         a_kidx_i,
  input  wire logic                          b_valid_i,
  input  wire logic                          b_last_i,
  input  wire logic signed [DATA_WIDTH-1:0]  b_data_i,
  input  wire logic [KIDX_WIDTH-1:0]         b_kidx_i,
  output logic                               a_valid_o,
  output logic                               a_last_o,
  output logic signed [DATA_WIDTH-1:0]       a_data_o,
  output logic [KIDX_WIDTH-1:0]              a_kidx_o,
  output logic                               b_valid_o,
  output logic                               b_last_o,
  output logic signed [DATA_WIDTH-1:0]       b_data_o,
  output logic [KIDX_WIDTH-1:0]              b_kidx_o,
  output logic signed [ACC_WIDTH-1:0]        acc_o,
  output logic                               done_o,
  output logic                               fire_o,
  output logic                               commit_o,
  output logic                               err_o
);
  tensor_pe #(.DATA_WIDTH(DATA_WIDTH), .ACC_WIDTH(ACC_WIDTH), .KIDX_WIDTH(KIDX_WIDTH), .MUL_PIPE(MUL_PIPE),
              .CHECK_ALIGN(CHECK_ALIGN)) dut (.*);

  integer commits, last_commits;
  chk_pe #(.DATA_WIDTH(DATA_WIDTH), .ACC_WIDTH(ACC_WIDTH), .KIDX_WIDTH(KIDX_WIDTH), .MUL_PIPE(MUL_PIPE),
           .CHECK_KSEQ(1'b0)) chk_mac (
    .clk(clk), .rst_n(rst_n), .clr(clr), .en(en), .chk_en(chk_en), .chk_off(chk_off),
    .a_valid_i(a_valid_i), .a_last_i(a_last_i), .a_data_i(a_data_i), .a_kidx_i(a_kidx_i),
    .b_valid_i(b_valid_i), .b_last_i(b_last_i), .b_data_i(b_data_i), .b_kidx_i(b_kidx_i),
    .a_valid_o(a_valid_o), .b_valid_o(b_valid_o), .acc_o(acc_o), .done_o(done_o), .fire_o(fire_o),
    .commit_o(commit_o), .commits(commits), .last_commits(last_commits));

  // commit_o / fire_o are combinational from the inputs (en & valid) and may be high during reset;
  // the accumulator is not updated then (reset wins) - checked by chk_mac P7, not here.
  chk_reset #(.N(3), .NK(4)) chk_rst (.clk(clk), .rst_n(rst_n), .quiet({a_valid_o, b_valid_o, done_o}),
                                      .known({a_valid_o, b_valid_o, done_o, err_o}));
endmodule
`default_nettype wire
