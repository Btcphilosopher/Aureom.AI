"""End-to-end GEMM verification of silicaflux_tensor_unit (TENSORCORE 08).

Every command goes through the register page exactly like software; every run is
checked by the scoreboards of common/tsu_env.py (records, the whole memory window,
the exact SFB2 traffic, performance counters, scheduler streams) and the SV
assertions of integration/tb_tsu.sv.  Every output element of every GEMM is
compared (the memory image comparison covers all of C and everything around it).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
try:
    import cocotb  # noqa: F401
    from common.harness import tensor_test, pick, full, PARAMS
    from common.tsu_tests import setup, finish, gemm_cmd, HW, CHECKERS, Alloc, make_gemm, Cmd, T
except ImportError:
    tensor_test = None
from common.tsu_tests import cfg, cfg_id, run_tsu  # noqa: E402

BRIEF_SHAPES = [(1, 1, 1), (4, 4, 4), (5, 7, 3), (8, 8, 8), (17, 13, 29), (31, 19, 257)]


def shape_bin(m, n, k):
    return f"{'1' if m == 1 else 'part' if m % HW.rows else 'full'}M_{'1' if n == 1 else 'part' if n % HW.cols else 'full'}N_" \
           f"{'1' if k == 1 else 'chunked' if k > HW.tile_k else 'single'}K"


if tensor_test is not None:

    @tensor_test(checkers=CHECKERS, timeout_us=60000)
    async def brief_shapes(dut, rng, cov):
        """1x1x1, 4x4x4, 5x7x3, 8x8x8, 17x13x29, 31x19x257: strided, unaligned operands, random
        values; every element, the whole memory image and the exact bus traffic checked."""
        env = await setup(dut, rng, cov, streams=True)
        al = Alloc(HW, rng)
        cmds = []
        for m, n, k in BRIEF_SHAPES:
            g = make_gemm(HW, al, rng, m, n, k, int8=False, prefetch=HW.dbuf)
            cmds.append(gemm_cmd(g))
            cov.hit("shape", f"{m}x{n}x{k}")
        await env.run(cmds)
        await finish(env)

    @tensor_test(checkers=CHECKERS, timeout_us=80000)
    async def random_shapes(dut, rng, cov):
        """Random M, N, K, KC, traversal order and layout within the memory limits; random memory
        latency and request backpressure."""
        env = await setup(dut, rng, cov, streams=True)
        env.mem.lat = rng.choice([(1, 1), (1, 4), (2, 9)])
        env.mem.bp_p = rng.choice([0.0, 0.2, 0.5])
        al = Alloc(HW, rng)
        cmds = []
        for _ in range(pick(8, 40)):
            m, n = rng.randint(1, 3 * HW.rows + 3), rng.randint(1, 3 * HW.cols + 3)
            k = rng.choice([1, rng.randint(1, HW.tile_k), rng.randint(HW.tile_k, 3 * HW.tile_k + 7)])
            kc = rng.choice([0, 0, rng.randint(1, HW.tile_k)])
            g = make_gemm(HW, al, rng, m, n, k, kc=kc, nmajor=rng.random() < 0.3,
                          int8=HW.quant and rng.random() < 0.5, prefetch=HW.dbuf and rng.random() < 0.7)
            cmds.append(gemm_cmd(g))
            cov.hit("shape_class", shape_bin(m, n, k))
        await env.run(cmds)
        await finish(env)

    @tensor_test(checkers=CHECKERS, timeout_us=200000)
    async def arithmetic_extremes(dut, rng, cov):
        """All zero, identity-like, maximum positive (-128*-128 everywhere), maximum negative
        (-128*127), cancellation, and the longest reduction: K = 4096 (quick) / K_MAX (full)."""
        env = await setup(dut, rng, cov, streams=False)
        al = Alloc(HW, rng)
        cmds = []

        def place(m, n, k, A, B, label, **kw):
            g = make_gemm(HW, al, rng, m, n, k, **kw)
            for i in range(m):
                env.poke(g.a + i * g.lda, bytes(v & 0xFF for v in A[i]))
            for kk in range(k):
                env.poke(g.b + kk * g.ldb, bytes(v & 0xFF for v in B[kk]))
            cmds.append(gemm_cmd(g, label))
            cov.hit("values", label)

        m, n, k = 9, 6, 70
        place(m, n, k, [[0] * k] * m, [[rng.randint(-128, 127) for _ in range(n)] for _ in range(k)], "zero_a")
        place(m, n, k, [[rng.randint(-128, 127) for _ in range(k)] for _ in range(m)], [[0] * n] * k, "zero_b")
        kk = 12
        I = [[int(i == j) for j in range(kk)] for i in range(kk)]
        place(kk, n, kk, I, [[rng.randint(-128, 127) for _ in range(n)] for _ in range(kk)], "identity_a")
        place(m, kk, kk, [[rng.randint(-128, 127) for _ in range(kk)] for _ in range(m)], I, "identity_b")
        place(m, n, k, [[-128] * k] * m, [[-128] * n] * k, "max_positive")
        place(m, n, k, [[-128] * k] * m, [[127] * n] * k, "max_negative")
        place(m, n, k, [[127] * k] * m, [[127] * n] * k, "max_127")
        A = [[rng.randint(-128, 127) for _ in range(k)] for _ in range(m)]
        A = [[r[2 * (j // 2)] for j in range(k)] for r in A]
        B = [[(1 if (kk2 % 2 == 0) else -1) * 99 for _ in range(n)] for kk2 in range(k)]
        place(m, n, k, A, B, "cancellation")
        long_k = HW.k_max if full() else min(HW.k_max, 4096)
        place(1, 2, long_k, [[-128] * long_k], [[-128, 127] for _ in range(long_k)], "long_k_extreme")
        await env.run(cmds)
        await finish(env, streams=False)

    @tensor_test(checkers=CHECKERS, timeout_us=80000)
    async def consecutive_commands(dut, rng, cov):
        """Commands submitted back to back (queue-full doorbell refusals), NOPs with IRQ, invalid
        commands mixed in (continue mode: ERROR, no side effect, the stream goes on), and a
        read-after-write chain: the A operand of command n+1 is the C output of command n.  Then a
        stop-on-error tail: invalid command, GEMM SKIPPED (PRIOR), ERR_CLEAR, exact GEMM."""
        env = await setup(dut, rng, cov, streams=True)
        al = Alloc(HW, rng)
        cmds = []
        prev = None
        for i in range(pick(10, 30)):
            invalid = i == 3 or rng.random() < 0.1
            if not invalid and rng.random() < 0.2:
                cmds.append(Cmd(T.nop(tid=i, irq=rng.random() < 0.5), None, "nop"))
                continue
            m, n, k = rng.randint(1, 10), rng.randint(1, 10), rng.randint(1, 80)
            g = make_gemm(HW, al, rng, m, n, k, irq=rng.random() < 0.3, tid=i)
            if invalid:
                # invalid command in continue mode: ERROR with no side effect, the stream goes on
                bad = rng.choice([dict(m=0), dict(n=0), dict(k=0)] + ([dict(lda=k - 1)] if k > 1 else []))
                cmds.append(Cmd(T.with_(g, **bad).words(), None, "invalid"))
                cov.hit("chain", "invalid")
                continue
            if prev is not None and rng.random() < 0.5 and prev.m * prev.ldc >= m * k:
                g.a, g.lda = prev.c, k            # RAW: consume the previous result bytes as INT8 operands
                cov.hit("chain", "raw")
            cmds.append(gemm_cmd(g))
            prev = g
        await env.run(cmds)
        assert any(c.record["status"] == T.ST_ERROR for c in cmds)
        # stop-on-error tail: an invalid command, then a GEMM that must be SKIPPED (PRIOR); after
        # ERR_CLEAR the next GEMM is exact
        await env.err_clear()
        await env.set_ctrl(False)
        tail = [Cmd(T.with_(make_gemm(HW, al, rng, 3, 3, 3), m=0).words(), None, "invalid"),
                gemm_cmd(make_gemm(HW, al, rng, 3, 4, 5), "skipped")]
        await env.run(tail)
        assert [c.record["status"] for c in tail] == [T.ST_ERROR, T.ST_SKIPPED]
        await env.err_clear()
        await env.set_ctrl(True)
        last = [gemm_cmd(make_gemm(HW, al, rng, 4, 5, 9), "after_err_clear")]
        await env.run(last)
        assert last[0].record["status"] == T.ST_OK
        cov.hit("chain", "stop_mode_skip")
        await finish(env)

    @tensor_test(checkers=CHECKERS, timeout_us=80000, skip_if=not HW.quant)
    async def quantised_output(dut, rng, cov):
        """INT8 requantised output: every rounding mode, ReLU, negative scales, saturating cases,
        unaligned C, mixed with INT32 commands."""
        env = await setup(dut, rng, cov, streams=True)
        al = Alloc(HW, rng)
        cmds = []
        for i in range(pick(10, 40)):
            m, n, k = rng.randint(1, 12), rng.randint(1, 12), rng.randint(1, 140)
            int8 = rng.random() < 0.8
            q = None
            if int8 and rng.random() < 0.3:
                q = dict(mult=(1 << 31) - 1, shift=rng.randint(0, 8))      # saturates heavily
            g = make_gemm(HW, al, rng, m, n, k, int8=int8, q=q, prefetch=HW.dbuf and rng.random() < 0.5)
            cmds.append(gemm_cmd(g))
            if int8:
                cov.hit("rm", g.rm)
        await env.run(cmds)
        await finish(env)
        for c in cmds:
            if c.gemm.out_int8:
                cov.hit("sat", "saturated" if c.record["sat"] else "exact")

    @tensor_test(checkers=CHECKERS, timeout_us=80000, skip_if=not HW.dbuf)
    async def double_buffering(dut, rng, cov):
        """PREFETCH (operand fill overlapped with compute, two output sets) mixed with sequential
        commands; the overlap counter must show real overlap."""
        env = await setup(dut, rng, cov, streams=True)
        al = Alloc(HW, rng)
        cmds = []
        for i in range(pick(6, 20)):
            m, n, k = rng.randint(4, 20), rng.randint(4, 20), rng.randint(HW.tile_k, 3 * HW.tile_k)
            cmds.append(gemm_cmd(make_gemm(HW, al, rng, m, n, k, prefetch=rng.random() < 0.7)))
        await env.run(cmds)
        p = await env.perf()
        assert p["OVERLAP"] - env.perf0["OVERLAP"] > 0, "no DMA / compute overlap with PREFETCH"
        await finish(env)
        cov.hit("dbuf", "overlap")


# =============================================================================== pytest runner

CONFIGS = [cfg(),                                   # TC08 baseline: 4x4 INT8 / INT32, sequential
           cfg(rows=2, cols=2, opb=1024, nb=2),     # verified 2x2 array
           cfg(rows=8, cols=8),                     # verified 8x8 array
           cfg(quant=1),                            # INT8 requantised output
           cfg(dbuf=1, opb=4096),                   # double buffering
           cfg(maxout=1),                           # one SFB2 transaction at a time
           cfg(tk=16, opb=1024, kmax=4096, quant=1, dbuf=1)]


@pytest.mark.parametrize("c", CONFIGS, ids=cfg_id)
def test_integration(c):
    run_tsu("integration", "test_integration", c, TT / "integration")
