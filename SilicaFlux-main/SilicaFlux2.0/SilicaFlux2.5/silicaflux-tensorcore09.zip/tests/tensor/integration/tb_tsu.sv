// =============================================================================
// SilicaFlux TENSORCORE 09 :: tb_tsu -- cocotb wrapper of the complete tensor unit
// DUT: TENSORCORE 08 silicaflux_tensor_unit, unmodified (TOB_ASSERT / SRAMLIB_ASSERT on).
// The host BFM (common/tsu_env.py) drives rb_*; the SFB2 memory model drives m_req_ready
// and the response channel.
//
// Assertions bound here (brief §9)
//   FIFO safety              chk_cq / chk_cplq: shadow-model FIFO checks of the command and
//                            completion queues (M08 hpc_command_queue)
//   stable payload           chk_sfb_req (SFB2 R2) ; DataFabric sfb_protocol_checker (R2/R4/R5/R6/R8)
//   request conservation     chk_sfb_txn: no unsolicited response, <= MAX_OUT outstanding
//   memory address bounds    chk_sfb_addr: every request inside [MEM_LO, MEM_HI), word aligned
//   no duplicate completion  chk_desc (DMA descriptor ids complete exactly once),
//                            chk_rec (records numbered 0,1,2.. exactly once, never more than commands)
//   no dropped request       chk_rec.n_cmd == n_rec and chk_desc.pending == 0 at the end (cocotb)
//   buffer ownership         chk_op_own (operand sets), chk_ob_own (output sets)
//   no commit before final   chk_commit: the DMA starts draining output tile n only after TC04
//   accumulation             committed tile n
//   valid MAC pairing        chk_pairing: the integrated array never raises its own alignment flag
//                            (unit-level per-PE pairing checks: systolic_array suite)
//   reset behaviour          chk_rst: no SFB2 request, interrupt, busy or halt in reset
// =============================================================================
`timescale 1ns/1ps
`include "tsu_defs.svh"
`include "chk_defs.svh"
`default_nettype none
module tb_tsu #(
  parameter int ROWS = 4, COLS = 4, TK = 64, OPB = 2048, NB = 4, QUANT = 0, DBUF = 0, MAXOUT = 4,
  parameter int KMAX = 131071, CMDQ = 4, CPLQ = 4, WDOG = 16, FI = 0,
  parameter longint MEM_LO = 64'h1000_0000, MEM_HI = 64'h1010_0000,
  localparam int NPC = `TSU_NUM_PC,
  localparam int NSETS = (DBUF != 0) ? 2 : 1
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  output logic             m_req_valid,
  input  wire logic        m_req_ready,
  output logic             m_req_write,
  output logic [31:0]      m_req_addr,
  output logic [31:0]      m_req_wdata,
  output logic [3:0]       m_req_wstrb,
  input  wire logic        m_rsp_valid,
  output logic             m_rsp_ready,
  input  wire logic [31:0] m_rsp_rdata,
  input  wire logic        m_rsp_error,
  output logic             irq,
  output logic             busy,
  output logic             halted,
  input  wire logic [1:0]  fi_mode
);
  logic [NPC*32-1:0] perf_ev;
  silicaflux_tensor_unit #(
    .ARRAY_ROWS(ROWS), .ARRAY_COLS(COLS), .DATA_WIDTH(8), .ACC_WIDTH(32), .TILE_K(TK), .OPERAND_BUFFER_BYTES(OPB),
    .NUM_MEMORY_BANKS(NB), .ENABLE_QUANTIZATION(QUANT), .ENABLE_DOUBLE_BUFFERING(DBUF), .CMD_QUEUE_DEPTH(CMDQ),
    .CPL_QUEUE_DEPTH(CPLQ), .MEM_LO(33'(MEM_LO)), .MEM_HI(33'(MEM_HI)), .MAX_OUT(MAXOUT), .K_MAX(KMAX),
    .WDOG_LOG2(WDOG), .PERF_EN(1), .FAULT_INJ(FI)
  ) dut (.*);

  // ---------------------------------------------------------------- queues (FIFO safety)
  chk_fifo #(.W(`TSU_DESC_W), .DEPTH(CMDQ), .CW($clog2(CMDQ + 1))) chk_cq (
    .clk(clk), .rst_n(rst_n), .in_valid(dut.u_cq.in_valid), .in_ready(dut.u_cq.in_ready), .in_data(dut.u_cq.in_data),
    .out_valid(dut.u_cq.out_valid), .out_ready(dut.u_cq.out_ready), .out_data(dut.u_cq.out_data),
    .level(dut.u_cq.level), .full(dut.u_cq.full), .empty(dut.u_cq.empty));
  chk_fifo #(.W(`TSU_CPL_W), .DEPTH(CPLQ), .CW($clog2(CPLQ + 1))) chk_cplq (
    .clk(clk), .rst_n(rst_n), .in_valid(dut.u_cplq.in_valid), .in_ready(dut.u_cplq.in_ready),
    .in_data(dut.u_cplq.in_data), .out_valid(dut.u_cplq.out_valid), .out_ready(dut.u_cplq.out_ready),
    .out_data(dut.u_cplq.out_data), .level(dut.u_cplq.level), .full(dut.u_cplq.full), .empty(dut.u_cplq.empty));

  // ---------------------------------------------------------------- SFB2 master port
  chk_handshake #(.W(1+32+4+32)) chk_sfb_req (.clk(clk), .rst_n(rst_n), .valid(m_req_valid), .ready(m_req_ready),
    .data({m_req_write, m_req_addr, m_req_wstrb, m_req_write ? m_req_wdata : 32'd0}));
  integer sfb_out, sfb_nreq, sfb_nrsp;
  chk_req_rsp #(.MAX_OUT(MAXOUT)) chk_sfb_txn (.clk(clk), .rst_n(rst_n), .req_valid(m_req_valid),
    .req_ready(m_req_ready), .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready), .outstanding(sfb_out),
    .n_req(sfb_nreq), .n_rsp(sfb_nrsp));
  chk_addr_range #(.AW(32), .ALIGN(4)) chk_sfb_addr (.clk(clk), .rst_n(rst_n), .valid(m_req_valid),
    .addr(m_req_addr), .lo(33'(MEM_LO)), .hi(33'(MEM_HI)));
  logic [31:0] pc_viol, pc_nreq, pc_nrsp, pc_out;
  sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(MAXOUT), .NAME("tsu_sfb")) df_sfb_chk (
    .clk(clk), .rst_n(rst_n), .req_valid(m_req_valid), .req_ready(m_req_ready), .req_write(m_req_write),
    .req_addr(m_req_addr), .req_wdata(m_req_wdata), .req_wstrb(m_req_wstrb), .rsp_valid(m_rsp_valid),
    .rsp_ready(m_rsp_ready), .rsp_rdata(m_rsp_rdata), .rsp_error(m_rsp_error),
    .violations(pc_viol), .n_req(pc_nreq), .n_rsp(pc_nrsp), .outstanding(pc_out));

  // ---------------------------------------------------------------- completions
  integer desc_pending;
  chk_once #(.IDW(8)) chk_desc (.clk(clk), .rst_n(dut.dp_rst_n),
    .iss_v(dut.u_dp.desc_valid && dut.u_dp.desc_ready), .iss_id(dut.u_dp.desc_data[167:160]),
    .cpl_v(dut.u_dp.cpl_valid && dut.u_dp.cpl_ready), .cpl_id(dut.u_dp.cpl_id), .pending(desc_pending));
  integer n_cmd, n_rec;
  chk_seq chk_rec (.clk(clk), .rst_n(rst_n), .cmd_v(dut.cq_in_v && dut.cq_in_r), .rec_v(dut.rec_v && dut.rec_r),
    .rec_seq(dut.rec_d[127:96]), .n_cmd(n_cmd), .n_rec(n_rec));

  // ---------------------------------------------------------------- buffer ownership
  chk_ownership #(.NSETS(NSETS), .SW((NSETS > 1) ? 1 : 1)) chk_op_own (.clk(clk), .rst_n(dut.dp_rst_n),
    .state(dut.u_dp.op_state), .wr_v(dut.u_dp.u_tob.wr_go), .wr_set(dut.u_dp.u_tob.wr_set),
    .rd_v(dut.u_dp.s_valid && dut.u_dp.s_ready), .rd_set(dut.u_dp.s_set), .pend(dut.u_dp.u_tob.u_dma.hold_valid));
  chk_ownership #(.NSETS(NSETS), .SW(1)) chk_ob_own (.clk(clk), .rst_n(dut.dp_rst_n),
    .state(dut.u_dp.ob_state), .wr_v(1'b0), .wr_set(1'b0),
    .rd_v(dut.u_dp.b_rq_v && dut.u_dp.b_rq_r && !dut.u_dp.b_rq_we), .rd_set(dut.u_dp.ob_rd_set), .pend(1'b0));

  // ---------------------------------------------------------------- no output before final accumulation
  chk_precedes chk_commit (.clk(clk), .rst_n(dut.dp_rst_n), .ev_ready(dut.u_dp.c_cmt),
    .ev_use(dut.u_dp.rb_v && dut.u_dp.rb_r));

  // ---------------------------------------------------------------- MAC pairing inside the unit
  chk_never #(.N(2)) chk_pairing (.clk(clk), .rst_n(dut.dp_rst_n),
    .bad({dut.u_dp.a_align, dut.u_dp.a_cfg_rej}));

  // ---------------------------------------------------------------- reset
  chk_reset #(.N(4), .NK(4)) chk_rst (.clk(clk), .rst_n(rst_n), .quiet({m_req_valid, irq, busy, halted}),
    .known({m_req_valid, m_rsp_ready, busy, irq}));
endmodule

// a set of conditions that must never hold (sticky flags the RTL raises on internal faults)
module chk_never #(parameter int N = 1) (
  input wire logic clk, rst_n,
  input wire logic [N-1:0] bad
);
  `CHK_DECL
  always @(posedge clk) if (rst_n) `CHK(bad == '0, ("internal fault flag(s) raised: %b", bad))
endmodule
`default_nettype wire
