"""Accumulator verification: TENSORCORE 04 tensor_acc_subsystem.

Model (AccModel) written from TC04 ARCHITECTURE §2/§5/§6 and NUMERIC_RANGE §4/§5:
  * configuration checks SLOT > DIM > CHUNKS > DEST > RANGE (STRICT_RANGE: exact
    bias + k_total*P_MAX <= ACC_MAX and bias + k_total*P_MIN >= ACC_MIN per column)
  * partial-sum beat checks in priority order NO_TILE > ROW > MASK > CHUNK_K >
    (replay: dropped silently) > ORDER > K_OVERRUN > RANGE (PSUM_GUARD), then
    acc = policy(base + psum + [bias on chunk 0]) with a sticky per-lane overflow bit
  * commit when every active row applied every chunk; o_wide exact ACC_W value,
    o_data narrowed to OUT_W (o_clip), o_ovf, o_err
  * host READ / WRITE (preload) / CLEAR / ABORT with HS_* status
Scoreboards: every output beat on every selected port (values, flags, row order,
contiguity per tile), every cmt_done pulse, every err_pulse / cfg_reject code in
order, and "no output before final accumulation" (a tile's first beat must find
the model's tile complete).
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
try:
    import cocotb
    from common.harness import tensor_test, FallingEdge, RisingEdge, ReadOnly, PARAMS, pick, full
except ImportError:
    tensor_test = None

from reference_models.gemm_ref import fits, saturate, wrap, srange, max_exact_k, to_signed  # noqa: E402

R = int(PARAMS.get("ROWS", 4))
C = int(PARAMS.get("COLS", 4))
ACC_W = int(PARAMS.get("ACC_W", 32))
OUT_W = int(PARAMS.get("OUT_W", 32))
NT = int(PARAMS.get("NUM_TILES", 2))
SAT = int(PARAMS.get("OVF_POLICY", 0)) == 0
STRICT = int(PARAMS.get("STRICT_RANGE", 1)) == 1
GUARD = int(PARAMS.get("PSUM_GUARD", 1)) == 1
PMAX, PMIN = 16384, -16256
PSUM_KMAX = max_exact_k(8, 32)
AMIN, AMAX = srange(ACC_W)
FREE, ACCUM, COMMIT = 0, 1, 2
CR = dict(OK=0, SLOT=1, DIM=2, CHUNKS=3, DEST=4, RANGE=5)
PE = dict(NONE=0, NO_TILE=1, ROW=2, MASK=3, CHUNK_K=4, ORDER=5, K_OVERRUN=6, RANGE=7)
HC_READ, HC_WRITE, HC_CLEAR, HC_ABORT = 0, 1, 2, 3
HS = dict(OK=0, SLOT=1, ROW=2, ORDER=3)
CHECKERS = ["chk_osram", "chk_oquant", "chk_odma", "chk_hr", "chk_rst", "chk_slot"]


def pol(v, w):
    return v if fits(v, w) else (saturate(v, w) if SAT else wrap(v, w))


class Slot:
    def __init__(self):
        self.state = FREE

    def open(self, tag, m, n, kt, nch, bias_en, bias, dest):
        self.state, self.tag, self.m, self.n, self.kt, self.nchunks = ACCUM, tag, m, n, kt, nch
        self.bias = [b if bias_en else 0 for b in bias]
        self.dest = dest
        self.nch = [0] * R
        self.kacc = [0] * R
        self.vld = [False] * R
        self.val = [[0] * C for _ in range(R)]
        self.ovf = [[0] * C for _ in range(R)]
        self.err = False

    def complete(self):
        return all(self.nch[r] == self.nchunks for r in range(self.m))


class AccModel:
    def __init__(self):
        self.slots = [Slot() for _ in range(NT)]

    def cfg_code(self, slot, m, n, kt, nch, bias_en, bias, dest):
        if slot >= NT:
            return CR["SLOT"]
        if m == 0 or m > R or n == 0 or n > C:
            return CR["DIM"]
        if nch == 0 or nch > kt:
            return CR["CHUNKS"]
        if dest == 0:
            return CR["DEST"]
        if STRICT:
            for j in range(n):
                b = bias[j] if bias_en else 0
                if b + kt * PMAX > AMAX or b + kt * PMIN < AMIN:
                    return CR["RANGE"]
        return CR["OK"]

    def beat(self, slot, tag, c, ck, row, data, cmask, last):
        """-> (error code or None, completed slot or None)"""
        # NO_TILE = slot out of range, slot FREE, or tag mismatch (tensor_acc_pkg; TC04 ARCHITECTURE §2 says
        # "not accumulating" - a documented ambiguity, see docs/VERIFICATION_PLAN.md).  A replay that reaches a
        # COMMIT slot is a duplicate; the tests never send one after completion (timing dependent).
        if slot >= NT or self.slots[slot].state == FREE or tag != self.slots[slot].tag:
            return PE["NO_TILE"], None
        s = self.slots[slot]
        e = None
        if row >= s.m:
            e = PE["ROW"]
        elif cmask != (1 << s.n) - 1 or last != (row == s.m - 1):
            e = PE["MASK"]
        elif ck == 0 or ck > PSUM_KMAX:
            e = PE["CHUNK_K"]
        elif c < s.nch[row]:
            return None, None                                   # replay: dropped, not an error
        elif c > s.nch[row] or c >= s.nchunks:
            e = PE["ORDER"]
        elif s.kacc[row] + ck > s.kt or (c == s.nchunks - 1 and s.kacc[row] + ck != s.kt):
            e = PE["K_OVERRUN"]
        elif GUARD and any(not (ck * PMIN <= data[j] <= ck * PMAX) for j in range(s.n)):
            e = PE["RANGE"]
        if e is not None:
            s.err = True
            return e, None
        for j in range(s.n):
            base = s.val[row][j] if s.vld[row] else 0
            v = base + data[j] + (s.bias[j] if c == 0 else 0)
            if not fits(v, ACC_W):
                s.ovf[row][j] = 1
            s.val[row][j] = pol(v, ACC_W)
        s.vld[row] = True
        s.nch[row] += 1
        s.kacc[row] += ck
        if s.complete():
            s.state = COMMIT
            return None, slot
        return None, None

    def host(self, op, slot, row, wdata):
        """-> (status, data, ovf, vld, nch, kacc) of the response"""
        z = (HS["OK"], [0] * C, 0, 0, 0, 0)
        if slot >= NT:
            return (HS["SLOT"],) + z[1:]
        s = self.slots[slot]
        if op == HC_READ:
            if s.state not in (ACCUM, COMMIT):
                return (HS["SLOT"],) + z[1:]
            if row >= s.m:
                return (HS["ROW"],) + z[1:]
            v = s.val[row] if s.vld[row] else [0] * C
            return (HS["OK"], [v[j] if j < s.n else 0 for j in range(C)],
                    sum(s.ovf[row][j] << j for j in range(C)) if s.vld[row] else 0,
                    int(s.vld[row]), s.nch[row], s.kacc[row])
        if s.state != ACCUM:
            return (HS["SLOT"],) + z[1:]
        if op == HC_ABORT:
            s.state = FREE
            return z
        if row >= s.m:
            return (HS["ROW"],) + z[1:]
        if op == HC_WRITE:
            if s.nch[row] != 0:
                return (HS["ORDER"],) + z[1:]
            # spec clarification (docs/VERIFICATION_PLAN.md): like READ and CLEAR, the WRITE response
            # carries the PRE-op metadata (vld / nchunk / kacc); its data field is the written value
            pre_vld = int(s.vld[row])
            s.val[row] = [wdata[j] if j < s.n else 0 for j in range(C)]
            s.ovf[row] = [0] * C
            s.vld[row] = True
            return (HS["OK"], list(s.val[row]), 0, pre_vld, 0, 0)
        pre = (int(s.vld[row]), s.nch[row], s.kacc[row])
        s.vld[row], s.nch[row], s.kacc[row] = False, 0, 0          # HC_CLEAR
        s.ovf[row] = [0] * C
        return (HS["OK"], [0] * C, 0) + pre

    def outputs(self, slot):
        s = self.slots[slot]
        beats = []
        for r in range(s.m):
            wide = [s.val[r][j] if j < s.n else 0 for j in range(C)]
            data, clip = [], 0
            for j, v in enumerate(wide):
                if j < s.n and not fits(v, OUT_W):
                    clip |= 1 << j
                data.append(pol(v, OUT_W) if j < s.n else 0)
            beats.append(dict(tag=s.tag, slot=slot, row=r, last=int(r == s.m - 1), cmask=(1 << s.n) - 1,
                              wide=wide, data=data, ovf=sum(s.ovf[r][j] << j for j in range(s.n)), clip=clip,
                              err=int(s.err)))
        return beats


def packs(vals, w):
    return sum((v & ((1 << w) - 1)) << (i * w) for i, v in enumerate(vals))


def unpacks(x, n, w):
    return [to_signed((x >> (i * w)) & ((1 << w) - 1), w) for i in range(n)]


class Acc:
    def __init__(self, dut, rng, cov):
        self.dut, self.rng, self.cov = dut, rng, cov
        self.m = AccModel()
        self.bp = 0.3
        self.expect = {}               # (slot, tag) -> beats, appended at completion
        self.got = {0: [], 1: [], 2: []}
        self.errs_exp, self.errs_got = [], []
        self.cmt_exp, self.cmt_got = [], []
        self.rej_exp, self.rej_got = [], []
        self.hr_exp, self.done_tags = [], set()
        for s in ("cfg_valid", "ps_valid", "hc_valid", "cfg_bias_en"):
            getattr(dut, s).value = 0
        for s in ("cfg_slot", "cfg_tag", "cfg_m", "cfg_n", "cfg_k_total", "cfg_n_chunks", "cfg_bias", "cfg_dest",
                  "ps_slot", "ps_tag", "ps_chunk", "ps_chunk_k", "ps_row", "ps_data", "ps_col_mask", "ps_last",
                  "hc_op", "hc_slot", "hc_row", "hc_wdata"):
            getattr(dut, s).value = 0
        dut.osram_ready.value = dut.oquant_ready.value = dut.odma_ready.value = dut.hr_ready.value = 1

    async def start(self):
        d = self.dut
        for _ in range(3):
            await FallingEdge(d.clk)
        d.rst_n.value = 1
        await FallingEdge(d.clk)
        self.mons = [cocotb.start_soon(self._out(p, n)) for p, n in ((0, "osram"), (1, "oquant"), (2, "odma"))]
        self.mons.append(cocotb.start_soon(self._status()))
        self.mons.append(cocotb.start_soon(self._hr()))

    async def _out(self, port, name):
        d = self.dut
        v, r = getattr(d, f"{name}_valid"), getattr(d, f"{name}_ready")
        while True:
            r.value = int(self.rng.random() >= self.bp)
            await RisingEdge(d.clk)
            if int(v.value) and int(r.value):
                b = dict(tag=int(d.o_tag.value), slot=int(d.o_slot.value), row=int(d.o_row.value),
                         last=int(d.o_last.value), cmask=int(d.o_col_mask.value),
                         wide=unpacks(int(d.o_wide.value), C, ACC_W), data=unpacks(int(d.o_data.value), C, OUT_W),
                         ovf=int(d.o_ovf.value), clip=int(d.o_clip.value), err=int(d.o_err.value))
                key = (b["slot"], b["tag"])
                assert key in self.expect, f"output beat of tile {key} before its final accumulation (port {name})"
                self.got[port].append(b)
            await FallingEdge(d.clk)

    async def _status(self):
        d = self.dut
        while True:
            await RisingEdge(d.clk)
            if int(d.err_pulse.value):
                self.errs_got.append(int(d.err_code.value))
            if int(d.cfg_reject.value):
                self.rej_got.append(int(d.cfg_reject_code.value))
            if int(d.cmt_done.value):
                self.cmt_got.append((int(d.cmt_slot.value), int(d.cmt_tag.value), int(d.cmt_ovf.value),
                                     int(d.cmt_clip.value), int(d.cmt_err.value)))

    async def _hr(self):
        d = self.dut
        while True:
            await RisingEdge(d.clk)
            if int(d.hr_valid.value) and int(d.hr_ready.value):
                assert self.hr_exp, "host response without request"
                e = self.hr_exp.pop(0)
                got = (int(d.hr_status.value), unpacks(int(d.hr_data.value), C, ACC_W), int(d.hr_ovf.value),
                       int(d.hr_vld.value), int(d.hr_nchunk.value), int(d.hr_kacc.value))
                assert got == e, f"host response {got}, expected {e}"
            await FallingEdge(d.clk)

    async def _hs(self, valid, ready):
        d = self.dut
        valid.value = 1
        n = 0
        while True:
            await RisingEdge(d.clk)
            if int(ready.value):
                break
            n += 1
            assert n < 100000, "handshake timeout"
            await FallingEdge(d.clk)
        await FallingEdge(d.clk)
        valid.value = 0

    async def cfg(self, slot, tag, m, n, kt, nch, bias=None, dest=1):
        d = self.dut
        bias_en = bias is not None
        bias = bias or [0] * C
        code = self.m.cfg_code(slot, m, n, kt, nch, bias_en, bias, dest)
        d.cfg_slot.value, d.cfg_tag.value, d.cfg_m.value, d.cfg_n.value = slot % (1 << len(d.cfg_slot)), tag, m, n
        d.cfg_k_total.value, d.cfg_n_chunks.value, d.cfg_bias_en.value = kt, nch, int(bias_en)
        d.cfg_bias.value, d.cfg_dest.value = packs(bias, 32), dest
        await self._hs(d.cfg_valid, d.cfg_ready)
        if code == CR["OK"]:
            self.m.slots[slot].open(tag, m, n, kt, nch, bias_en, bias, dest)
        else:
            self.rej_exp.append(code)
        self.cov.hit("cfg", [k for k, v in CR.items() if v == code][0])
        return code

    async def ps(self, slot, tag, c, ck, row, data, cmask=None, last=None):
        d = self.dut
        s = self.m.slots[slot] if slot < NT else None
        if cmask is None:
            cmask = (1 << s.n) - 1
        if last is None:
            last = int(row == s.m - 1)
        d.ps_slot.value, d.ps_tag.value, d.ps_chunk.value, d.ps_chunk_k.value = slot % (1 << len(d.ps_slot)), \
            tag, c, ck
        d.ps_row.value, d.ps_data.value, d.ps_col_mask.value, d.ps_last.value = row, packs(data, 32), cmask, last
        await self._hs(d.ps_valid, d.ps_ready)
        e, done = self.m.beat(slot, tag, c, ck, row, data, cmask, last)
        if e is not None:
            self.errs_exp.append(e)
            self.cov.hit("beat", [k for k, v in PE.items() if v == e][0])
        if done is not None:
            sl = self.m.slots[done]
            self.expect[(done, sl.tag)] = (sl.dest, self.m.outputs(done))
            self.cmt_exp.append((done, sl.tag, int(any(b["ovf"] for b in self.m.outputs(done))),
                                 int(any(b["clip"] for b in self.m.outputs(done))), int(sl.err)))
            self.m.slots[done].state = FREE                     # freed after its last commit read
        return e

    async def host(self, op, slot, row=0, wdata=None):
        d = self.dut
        wdata = wdata or [0] * C
        d.hc_op.value, d.hc_slot.value, d.hc_row.value = op, slot % (1 << len(d.hc_slot)), row
        d.hc_wdata.value = packs(wdata, ACC_W)
        self.hr_exp.append(self.m.host(op, slot, row, wdata))
        await self._hs(d.hc_valid, d.hc_ready)
        self.cov.hit("host", ["read", "write", "clear", "abort"][op])

    async def run_tile(self, slot, tag, A, B, chunks, bias=None, dest=1, dup_p=0.0, interleave=True):
        """Open a tile, then send every row's chunk partial sums (rows interleaved at random,
        chunks of one row in order, replays inserted with probability dup_p)."""
        m, k, n = len(A), len(B), len(B[0])
        assert sum(chunks) == k
        code = await self.cfg(slot, tag, m, n, k, len(chunks), bias, dest)
        assert code == CR["OK"]
        bounds, k0 = [], 0
        for ck in chunks:
            bounds.append((k0, ck))
            k0 += ck
        nxt = [0] * m
        while any(nxt[r] < len(chunks) for r in range(m)):
            r = self.rng.choice([r for r in range(m) if nxt[r] < len(chunks)]) if interleave else \
                min(r for r in range(m) if nxt[r] < len(chunks))
            c = nxt[r]
            k0, ck = bounds[c]
            ps = [sum(A[r][kk] * B[kk][j] for kk in range(k0, k0 + ck)) for j in range(n)] + [0] * (C - n)
            await self.ps(slot, tag, c, ck, r, ps)
            nxt[r] += 1
            if c > 0 and self.rng.random() < dup_p and self.m.slots[slot].state == ACCUM:
                pc = self.rng.randint(0, c)
                k0p, ckp = bounds[pc]
                psp = [sum(A[r][kk] * B[kk][j] for kk in range(k0p, k0p + ckp)) for j in range(n)] + [0] * (C - n)
                await self.ps(slot, tag, pc, ckp, r, psp)        # replay: must not be counted twice
                self.cov.hit("beat", "replay")

    async def finish(self):
        d = self.dut
        n = 0
        while (not int(d.idle.value)) or self.hr_exp:
            await FallingEdge(d.clk)
            n += 1
            assert n < 200000, "accumulator never became idle"
        for _ in range(8):
            await FallingEdge(d.clk)
        # every port that a tile selected received exactly that tile's beats, contiguous, in row order
        for port in (0, 1, 2):
            got = list(self.got[port])
            exp_tiles = [(key, beats) for key, (dest, beats) in self.expect.items() if (dest >> port) & 1]
            by = {}
            order = []
            for b in got:
                key = (b["slot"], b["tag"])
                if not order or order[-1] != key:
                    assert key not in by, f"port {port}: beats of tile {key} not contiguous"
                    order.append(key)
                by.setdefault(key, []).append(b)
            assert set(by) == {k for k, _ in exp_tiles}, f"port {port}: tiles {set(by)} != {[k for k, _ in exp_tiles]}"
            for key, beats in exp_tiles:
                assert by[key] == beats, f"port {port} tile {key}:\n got {by[key]}\n exp {beats}"
        assert sorted(self.cmt_got) == sorted(self.cmt_exp), (self.cmt_got, self.cmt_exp)
        assert self.errs_got == self.errs_exp, f"err pulses {self.errs_got} != {self.errs_exp}"
        assert self.rej_got == self.rej_exp, f"cfg rejects {self.rej_got} != {self.rej_exp}"
        self.cov.hit("tiles", "committed", len(self.cmt_got))
        self.expect.clear()
        self.got = {0: [], 1: [], 2: []}
        self.cmt_exp, self.cmt_got, self.errs_exp, self.errs_got, self.rej_exp, self.rej_got = [], [], [], [], [], []


def rmat(rng, m, n, lo=-128, hi=127):
    return [[rng.randint(lo, hi) for _ in range(n)] for _ in range(m)]


def partition(rng, k, maxn=6):
    n = rng.randint(1, min(maxn, k))
    cuts = sorted(rng.sample(range(1, k), n - 1)) if n > 1 else []
    pts = [0] + cuts + [k]
    return [pts[i + 1] - pts[i] for i in range(n)]


if tensor_test is not None:

    async def setup(dut, rng, cov):
        for cp, bins in (("cfg", CR), ("beat", list(PE) + ["replay"]), ("host", ["read", "write", "clear", "abort"])):
            cov.define(cp, [b for b in bins if b != "NONE"])
        a = Acc(dut, rng, cov)
        await a.start()
        return a

    @tensor_test(checkers=CHECKERS)
    async def chunked_accumulation_exact(dut, rng, cov):
        """Random tiles, random K partitions, interleaved rows, two slots in flight, replays,
        bias, every destination subset, output backpressure: committed == bias + sum A*B."""
        a = await setup(dut, rng, cov)
        for t in range(pick(30, 200)):
            m, n, k = rng.randint(1, R), rng.randint(1, C), rng.randint(1, 120)
            A, B = rmat(rng, m, k), rmat(rng, k, n)
            bias = [rng.randint(-100000, 100000) for _ in range(C)] if rng.random() < 0.5 else None
            dest = rng.randint(1, 7)
            slot = t % NT
            await a.run_tile(slot, 0x100 + t, A, B, partition(rng, k), bias, dest, dup_p=0.2)
            if t % 7 == 6:
                await a.finish()
        await a.finish()

    @tensor_test(checkers=CHECKERS)
    async def strict_range_boundaries(dut, rng, cov):
        """TC04 NUMERIC_RANGE §4 table: K = 131071 / 131072, bias 16383 / 16384 / -16793472 /
        -16793473, one column alone out of range; then the extreme tile reaching exactly
        INT32_MAX through three chunks."""
        a = await setup(dut, rng, cov)
        if ACC_W != 32:
            return
        K = 131071
        cases = [(K, None, CR["OK"]), (K + 1, None, CR["RANGE"] if STRICT else CR["OK"]),
                 (K, [16383] * C, CR["OK"]), (K, [16384] * C, CR["RANGE"] if STRICT else CR["OK"]),
                 (K, [-16793472] * C, CR["OK"]), (K, [-16793473] * C, CR["RANGE"] if STRICT else CR["OK"]),
                 (K, [0] * (C - 1) + [16384], CR["RANGE"] if STRICT else CR["OK"])]
        for kt, bias, exp in cases:
            code = await a.cfg(0, 7, 1, C, kt, 1, bias, 1)
            assert code == exp, (kt, bias, code)
            if code == CR["OK"]:
                await a.host(HC_ABORT, 0)
        # bias 16383 + 131071 * 16384 = INT32_MAX exactly, in chunks of 65536 + 65535 (PSUM_GUARD max)
        await a.cfg(0, 9, 1, C, K, 2, [16383] * C, 1)
        await a.ps(0, 9, 0, 65536, 0, [65536 * PMAX] * C)
        await a.ps(0, 9, 1, 65535, 0, [65535 * PMAX] * C)
        await a.finish()
        cov.hit("range", "int32_max_exact")
        # illegal configurations: slot (encodable only if NUM_TILES < 2^SLOT_W), dimensions, chunk count,
        # destination; the slot check has the highest priority
        if NT < (1 << len(dut.cfg_slot)):
            assert await a.cfg(NT, 1, 0, 1, 4, 0, dest=0) == CR["SLOT"]
        assert await a.cfg(0, 1, 0, 1, 4, 1) == CR["DIM"]
        assert await a.cfg(0, 1, 1, C + 1 if C + 1 < (1 << len(dut.cfg_n)) else 0, 4, 1) == CR["DIM"]
        assert await a.cfg(0, 1, 1, 1, 4, 0) == CR["CHUNKS"]
        assert await a.cfg(0, 1, 1, 1, 4, 5) == CR["CHUNKS"]
        assert await a.cfg(0, 1, 1, 1, 4, 1, dest=0) == CR["DEST"]
        await a.finish()

    @tensor_test(checkers=CHECKERS)
    async def overflow_policy_via_preload(dut, rng, cov):
        """A host preload next to ACC_MAX / ACC_MIN, then a chunk that crosses it: the lane
        overflow bit is set and sticky, the value saturates (OVF_SATURATE, integrated) or wraps
        (OVF_WRAP, explicitly selected); later chunks continue from the policy value."""
        a = await setup(dut, rng, cov)
        for side in (1, -1):
            await a.cfg(0, 3, 1, C, 3, 3, None, 1)
            pre = [AMAX - 5 if side > 0 else AMIN + 5] * C
            pre[0] = 0                                       # one lane stays in range
            await a.host(HC_WRITE, 0, 0, pre)
            await a.host(HC_READ, 0, 0)
            await a.ps(0, 3, 0, 1, 0, [side * 100] * C)       # crosses the rail on lanes 1..
            await a.ps(0, 3, 1, 1, 0, [-side * 7] * C)        # moves back from the rail
            await a.host(HC_READ, 0, 0)
            await a.ps(0, 3, 2, 1, 0, [0] * C)
            await a.finish()
            cov.hit("policy", ("sat" if SAT else "wrap") + ("_pos" if side > 0 else "_neg"))

    @tensor_test(checkers=CHECKERS, skip_if=STRICT)
    async def runtime_overflow_without_strict_range(dut, rng, cov):
        """STRICT_RANGE = 0: K beyond the exact bound is accepted; the add that leaves the range is
        detected exactly (sticky o_ovf) and follows the policy - never silent."""
        a = await setup(dut, rng, cov)
        kt = 131071 * 2
        await a.cfg(0, 5, 1, C, kt, 2, None, 1)
        await a.ps(0, 5, 0, 131071, 0, [131071 * PMAX] * C)
        await a.ps(0, 5, 1, 131071, 0, [131071 * PMAX] * C)
        await a.finish()
        cov.hit("policy", "runtime_overflow")

    @tensor_test(checkers=CHECKERS)
    async def malformed_beats_dropped(dut, rng, cov):
        """Every beat error class is dropped without touching storage, reported in order, and
        flags the tile (o_err / cmt_err) when it hits an open tile; the correct beats then
        complete the tile with the exact value."""
        a = await setup(dut, rng, cov)
        m, n, k = min(2, R), min(3, C), 10
        A, B = rmat(rng, m, k), rmat(rng, k, n)
        await a.cfg(0, 0x55, m, n, k, 2, None, 1)
        ps0 = [[sum(A[r][kk] * B[kk][j] for kk in range(0, 4)) for j in range(n)] + [0] * (C - n) for r in range(m)]
        ps1 = [[sum(A[r][kk] * B[kk][j] for kk in range(4, 10)) for j in range(n)] + [0] * (C - n) for r in range(m)]
        await a.ps(0, 0x66, 0, 4, 0, ps0[0])                                 # NO_TILE (tag)
        if NT > 1:
            await a.ps(1, 0x55, 0, 4, 0, ps0[0], cmask=(1 << n) - 1, last=0)  # NO_TILE (slot not open)
        if m < R:
            await a.ps(0, 0x55, 0, 4, m, ps0[0], last=0)                     # ROW
        await a.ps(0, 0x55, 0, 4, 0, ps0[0], cmask=1)                        # MASK
        await a.ps(0, 0x55, 0, 0, 0, ps0[0])                                 # CHUNK_K
        await a.ps(0, 0x55, 1, 6, 0, ps1[0])                                 # ORDER (skips chunk 0)
        await a.ps(0, 0x55, 0, 5, 0, ps0[0])                                 # K_OVERRUN? 5 != 4 is legal on chunk 0
        # (chunk 0 with K 5 is accepted: K bookkeeping only fails at the last chunk) -> clear the row
        await a.host(HC_CLEAR, 0, 0)
        if GUARD:
            await a.ps(0, 0x55, 0, 4, 0, [4 * PMAX + 1] + ps0[0][1:])        # RANGE (impossible psum)
        for r in range(m):
            await a.ps(0, 0x55, 0, 4, r, ps0[r])
        await a.ps(0, 0x55, 1, 5, 0, ps1[0])                                 # K_OVERRUN on the last chunk
        for r in range(m):
            await a.ps(0, 0x55, 1, 6, r, ps1[r])
        await a.finish()

    @tensor_test(checkers=CHECKERS)
    async def host_operations(dut, rng, cov):
        """READ during accumulation (forwarded partial value + metadata), WRITE preload before
        chunk 0 and refused after it, CLEAR restarting a row (bias applied again exactly once),
        ABORT freeing a slot, illegal slot / row."""
        a = await setup(dut, rng, cov)
        m, n, k = min(3, R), min(4, C), 12
        A, B = rmat(rng, m, k), rmat(rng, k, n)
        bias = [rng.randint(-500, 500) for _ in range(C)]
        await a.cfg(0, 0x21, m, n, k, 3, bias, 3)
        ch = [(0, 4), (4, 4), (8, 4)]

        def psum(r, c):
            k0, ck = ch[c]
            return [sum(A[r][kk] * B[kk][j] for kk in range(k0, k0 + ck)) for j in range(n)] + [0] * (C - n)
        await a.host(HC_WRITE, 0, 1, [1000, -1000, 7, 0][:C] + [0] * max(0, C - 4))
        await a.ps(0, 0x21, 0, 4, 0, psum(0, 0))
        await a.host(HC_READ, 0, 0)
        await a.host(HC_WRITE, 0, 0, [5] * C)                 # refused: chunk 0 already landed (ORDER)
        await a.ps(0, 0x21, 1, 4, 0, psum(0, 1))
        await a.host(HC_CLEAR, 0, 0)                          # row 0 restarts from chunk 0
        for c in range(3):
            await a.ps(0, 0x21, c, 4, 0, psum(0, c))
        for r in range(1, m):
            for c in range(3):
                await a.ps(0, 0x21, c, 4, r, psum(r, c))
        await a.host(HC_READ, NT, 0)                          # illegal slot
        await a.finish()
        await a.cfg(0, 0x22, 1, 1, 4, 2, None, 1)
        await a.host(HC_READ, 0, 1 if R > 1 else 0)           # row >= M (or legal on 1-row arrays)
        await a.host(HC_ABORT, 0)
        await a.host(HC_ABORT, 0)                             # not open any more
        await a.finish()

    @tensor_test(checkers=CHECKERS)
    async def reset_during_accumulation(dut, rng, cov):
        """Synchronous reset with tiles open, beats in flight and a tile committing; every slot
        returns to FREE and re-running the tiles gives exact results."""
        a = await setup(dut, rng, cov)
        d = dut
        m, n, k = R, C, 20
        A, B = rmat(rng, m, k), rmat(rng, k, n)
        a.bp = 0.9
        await a.run_tile(0, 1, A, B, [10, 10], None, 7)
        d.rst_n.value = 0
        await FallingEdge(d.clk)
        await FallingEdge(d.clk)
        d.rst_n.value = 1
        await FallingEdge(d.clk)
        a.m = AccModel()
        a.expect.clear()
        a.got = {0: [], 1: [], 2: []}
        a.cmt_exp, a.cmt_got, a.errs_exp, a.errs_got = [], [], [], []
        a.bp = 0.2
        assert int(d.slot_state.value) == 0 and int(d.idle.value) == 1
        cov.hit("reset", "mid_accumulation")
        for t in range(4):
            await a.run_tile(t % NT, 10 + t, A, B, partition(rng, k), None, 1)
        await a.finish()


# =============================================================================== pytest runner

def cfg(rows=4, cols=4, acc=32, out=32, nt=2, rd=1, pol=0, strict=1, guard=1):
    return dict(ROWS=rows, COLS=cols, ACC_W=acc, OUT_W=out, NUM_TILES=nt, RD_LAT=rd, OVF_POLICY=pol,
                STRICT_RANGE=strict, PSUM_GUARD=guard)


CONFIGS = [cfg(),                                  # integrated: 4x4, INT32, SATURATE, STRICT_RANGE, 2 slots
           cfg(rows=2, cols=2), cfg(rows=8, cols=8),
           cfg(pol=1),                             # explicitly selected wrap
           cfg(strict=0, nt=3, rd=3),              # range check off: run-time overflow detection
           cfg(acc=40, out=32, rd=2),              # wide accumulator, INT32 output with clip
           cfg(rows=3, cols=5, nt=1, guard=0)]


def _id(c):
    return (f"{c['ROWS']}x{c['COLS']}_acc{c['ACC_W']}_out{c['OUT_W']}_t{c['NUM_TILES']}_rd{c['RD_LAT']}"
            f"_{'sat' if c['OVF_POLICY'] == 0 else 'wrap'}_s{c['STRICT_RANGE']}_g{c['PSUM_GUARD']}")


@pytest.mark.parametrize("cfg", CONFIGS, ids=_id)
def test_accumulator(cfg):
    from common import sim
    srcs, incs = sim.tc08_subset("tensor_acc_pkg.sv", "tensor_acc_fifo.sv", "tensor_acc_storage.sv",
                                 "tensor_acc_out_router.sv", "tensor_accumulator.sv", "tensor_acc_subsystem.sv")
    sim.run("accumulator", "tb_acc", "test_accumulator",
            srcs + sim.checker_sources() + [TT / "accumulator" / "tb_acc.sv"], cfg, includes=incs, tag=_id(cfg))
