// =============================================================================
// SilicaFlux TENSORCORE 09 :: tb_acc -- cocotb wrapper of the accumulator
// DUT: TENSORCORE 04 tensor_acc_subsystem, unmodified.
// Checkers
//   chk_osram / chk_oquant / chk_odma / chk_hr : result payload stable under backpressure
//   chk_rst  : no result / response / commit pulse in reset
//   chk_slot : slot state machine FREE -> ACCUM -> COMMIT -> FREE (ACCUM -> FREE on abort)
// =============================================================================
`timescale 1ns/1ps
`include "chk_defs.svh"
`default_nettype none
module tb_acc #(
  parameter int ROWS = 4, COLS = 4, ACC_W = 32, OUT_W = 32, NUM_TILES = 2, RD_LAT = 1,
  parameter int OVF_POLICY = 0, STRICT_RANGE = 1, PSUM_GUARD = 1,
  localparam int SLOT_W = (NUM_TILES > 1) ? $clog2(NUM_TILES) : 1,
  localparam int RIDW = (ROWS > 1) ? $clog2(ROWS) : 1,
  localparam int MW = $clog2(ROWS + 1), NW = $clog2(COLS + 1)
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  input  wire logic                   cfg_valid,
  output logic                        cfg_ready,
  input  wire logic [SLOT_W-1:0]      cfg_slot,
  input  wire logic [15:0]            cfg_tag,
  input  wire logic [MW-1:0]          cfg_m,
  input  wire logic [NW-1:0]          cfg_n,
  input  wire logic [39:0]            cfg_k_total,
  input  wire logic [15:0]            cfg_n_chunks,
  input  wire logic                   cfg_bias_en,
  input  wire logic [COLS*32-1:0]     cfg_bias,
  input  wire logic [2:0]             cfg_dest,
  output logic                        cfg_reject,
  output logic [2:0]                  cfg_reject_code,
  input  wire logic                   ps_valid,
  output logic                        ps_ready,
  input  wire logic [SLOT_W-1:0]      ps_slot,
  input  wire logic [15:0]            ps_tag,
  input  wire logic [15:0]            ps_chunk,
  input  wire logic [16:0]            ps_chunk_k,
  input  wire logic [RIDW-1:0]        ps_row,
  input  wire logic [COLS*32-1:0]     ps_data,
  input  wire logic [COLS-1:0]        ps_col_mask,
  input  wire logic                   ps_last,
  input  wire logic                   hc_valid,
  output logic                        hc_ready,
  input  wire logic [1:0]             hc_op,
  input  wire logic [SLOT_W-1:0]      hc_slot,
  input  wire logic [RIDW-1:0]        hc_row,
  input  wire logic [COLS*ACC_W-1:0]  hc_wdata,
  output logic                        hr_valid,
  input  wire logic                   hr_ready,
  output logic [2:0]                  hr_status,
  output logic [COLS*ACC_W-1:0]       hr_data,
  output logic [COLS-1:0]             hr_ovf,
  output logic                        hr_vld,
  output logic [15:0]                 hr_nchunk,
  output logic [39:0]                 hr_kacc,
  output logic                        osram_valid,
  input  wire logic                   osram_ready,
  output logic                        oquant_valid,
  input  wire logic                   oquant_ready,
  output logic                        odma_valid,
  input  wire logic                   odma_ready,
  output logic [15:0]                 o_tag,
  output logic [SLOT_W-1:0]           o_slot,
  output logic [RIDW-1:0]             o_row,
  output logic                        o_last,
  output logic [COLS-1:0]             o_col_mask,
  output logic [COLS*ACC_W-1:0]       o_wide,
  output logic [COLS*OUT_W-1:0]       o_data,
  output logic [COLS-1:0]             o_ovf,
  output logic [COLS-1:0]             o_clip,
  output logic                        o_err,
  output logic                        cmt_done,
  output logic [SLOT_W-1:0]           cmt_slot,
  output logic [15:0]                 cmt_tag,
  output logic                        cmt_ovf,
  output logic                        cmt_clip,
  output logic                        cmt_err,
  output logic [NUM_TILES*2-1:0]      slot_state,
  output logic                        idle,
  output logic                        err_pulse,
  output logic [2:0]                  err_code,
  output logic [7:0]                  err_sticky
);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [tensor_acc_pkg::NPERF*$clog2(COLS+1)-1:0] ev_inc;
  logic [tensor_acc_pkg::NPERF*40-1:0]             perf_o;
  logic st_en, st_rd_req, st_rd_ready, st_wr_req, st_wr_ready;
  /* verilator lint_on UNUSEDSIGNAL */
  logic st_rd_block = 1'b0, st_wr_block = 1'b0, perf_clr = 1'b0;

  tensor_acc_subsystem #(
    .ROWS(ROWS), .COLS(COLS), .DATA_W(8), .PSUM_W(32), .ACC_W(ACC_W), .OUT_W(OUT_W), .BIAS_W(32),
    .NUM_TILES(NUM_TILES), .TAG_W(16), .CHUNK_W(16), .KC_W(17), .KTOT_W(40), .RD_LAT(RD_LAT),
    .OVF_POLICY(OVF_POLICY), .STRICT_RANGE(STRICT_RANGE), .PSUM_GUARD(PSUM_GUARD), .OFIFO_DEPTH(4),
    .HFIFO_DEPTH(4), .PERF_EN(1), .PERF_W(40)
  ) dut (.*);

  localparam int OW = 16 + SLOT_W + RIDW + 1 + COLS + COLS*ACC_W + COLS*OUT_W + COLS + COLS + 1;
  wire [OW-1:0] opay = {o_tag, o_slot, o_row, o_last, o_col_mask, o_wide, o_data, o_ovf, o_clip, o_err};
  chk_handshake #(.W(OW)) chk_osram  (.clk(clk), .rst_n(rst_n), .valid(osram_valid),  .ready(osram_ready),  .data(opay));
  chk_handshake #(.W(OW)) chk_oquant (.clk(clk), .rst_n(rst_n), .valid(oquant_valid), .ready(oquant_ready), .data(opay));
  chk_handshake #(.W(OW)) chk_odma   (.clk(clk), .rst_n(rst_n), .valid(odma_valid),   .ready(odma_ready),   .data(opay));
  chk_handshake #(.W(3 + COLS*ACC_W + COLS + 1 + 16 + 40)) chk_hr (.clk(clk), .rst_n(rst_n), .valid(hr_valid),
    .ready(hr_ready), .data({hr_status, hr_data, hr_ovf, hr_vld, hr_nchunk, hr_kacc}));
  chk_reset #(.N(6), .NK(4)) chk_rst (.clk(clk), .rst_n(rst_n),
    .quiet({osram_valid, oquant_valid, odma_valid, hr_valid, cmt_done, err_pulse}),
    .known({cfg_ready, ps_ready, hc_ready, idle}));

  // slot state machine: FREE(0) -> ACCUM(1) -> COMMIT(2) -> FREE, ACCUM -> FREE (host abort)
  chk_slot_fsm #(.N(NUM_TILES)) chk_slot (.clk(clk), .rst_n(rst_n), .state(slot_state));
endmodule

module chk_slot_fsm #(parameter int N = 2) (
  input wire logic clk, rst_n,
  input wire logic [N*2-1:0] state
);
  `CHK_DECL
  logic [N*2-1:0] q;
  initial q = '0;
  always @(posedge clk) begin
    if (!rst_n) q <= '0;
    else begin
      for (int i = 0; i < N; i++) begin
        logic [1:0] a, b;
        a = q[2*i +: 2]; b = state[2*i +: 2];
        `CHK(b != 2'd3, ("slot %0d in the unused state 3", i))
        if (a != b) `CHK((a == 0 && b == 1) || (a == 1 && b == 2) || (a == 2 && b == 0) || (a == 1 && b == 0),
                         ("slot %0d illegal transition %0d -> %0d", i, a, b))
      end
      q <= state;
    end
  end
endmodule
`default_nettype wire
