"""Command-level reference of silicaflux_tensor_unit (TENSORCORE 08).

Written for TENSORCORE 09 from TC08 doc 02 (command ABI), doc 04 (execution) and
doc 05 (errors).  It provides

* ``Gemm`` / ``nop()``      - descriptor encoding (12 x 32-bit words, VERSION 2)
* ``validate()``            - the 15 validation rules, first failing rule wins, in
                              unbounded integer arithmetic (an address overflow is
                              detected, never computed modulo 2^32)
* ``schedule()``            - the tile / K-chunk step sequence (TC06 iterator order)
* ``dma_descriptors()``     - LOAD_A / LOAD_B / STORE descriptors in issue order,
                              including the local layouts (lda_loc, ldb_loc)
* ``read_words()`` / ``write_words()`` - the exact SFB2 word traffic of the schedule
* ``expected_outcome()``    - record fields and the expected memory image, for
                              success, validation errors and injected DMA errors.

Two resolutions of the ABI text are explicit here (both documented in
docs/VERIFICATION_PLAN.md §ambiguities):
  (a) for NOP, any FLAGS bit other than IRQ / BARRIER is a FLAGS error;
  (b) the INT32-only reserved-field checks of rule 4 apply only when OUT_FMT = INT32;
      a reserved OUT_FMT (2, 3) is reported by rule 7 (PRECISION).
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace

from .gemm_ref import ByteMemory, Matrix, ceil_div, gemm, output_tiles, k_chunks, to_unsigned
from .quant_ref import QParams, requant, OFMT_INT8 as Q_OFMT_INT8

# ----------------------------------------------------------------------------- ABI constants (doc 02)
ABI_VERSION = 2
OP_NOP, OP_GEMM = 0x00, 0x40
FL_IRQ, FL_BARRIER, FL_PREFETCH, FL_NMAJOR = 0, 1, 2, 3
OFMT_INT32, OFMT_INT8 = 0, 1
ST_OK, ST_ERROR, ST_SKIPPED = 0, 1, 2

E_NONE = 0x00
E_VERSION, E_OPCODE, E_FLAGS, E_RSVD, E_RM, E_LAYOUT, E_PRECISION = 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07
E_DIM_ZERO, E_DIM_RANGE, E_CHUNK, E_LD, E_ALIGN, E_ADDR_OVF, E_RANGE, E_ALIAS = (
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F)
E_DMA_READ, E_DMA_WRITE, E_DMA_REJECT, E_DMA_PROTO = 0x18, 0x19, 0x1A, 0x1B
E_BUF_ACCESS, E_COMPUTE, E_OUTBUF, E_ACC_OVF, E_QUANT = 0x20, 0x21, 0x22, 0x28, 0x29
E_TIMEOUT, E_ABORTED, E_PRIOR = 0x30, 0x38, 0x40
E_NAMES = {0: "NONE", 1: "VERSION", 2: "OPCODE", 3: "FLAGS", 4: "RSVD", 5: "RM", 6: "LAYOUT", 7: "PRECISION",
           8: "DIM_ZERO", 9: "DIM_RANGE", 10: "CHUNK", 11: "LD", 12: "ALIGN", 13: "ADDR_OVF", 14: "RANGE",
           15: "ALIAS", 0x18: "DMA_READ", 0x19: "DMA_WRITE", 0x1A: "DMA_REJECT", 0x1B: "DMA_PROTO",
           0x20: "BUF_ACCESS", 0x21: "COMPUTE", 0x22: "OUTBUF", 0x28: "ACC_OVF", 0x29: "QUANT",
           0x30: "TIMEOUT", 0x38: "ABORTED", 0x40: "PRIOR"}
TDMA_C_RD_BUS, TDMA_C_WR_BUS = 7, 8
W9_RSVD_MASK = 0xFFFF_80C0
W11_RSVD_MASK = 0xFFFF_00C0

# register page (doc 03 / tsu_defs.svh)
R_ID, R_INFO, R_CAPS, R_OPBUF, R_MEM_LO, R_MEM_LAST = 0x000, 0x004, 0x008, 0x00C, 0x010, 0x014
R_CTRL, R_STATUS, R_INT_ENABLE, R_INT_STATUS, R_SUBMITTED, R_KMAX = 0x018, 0x01C, 0x020, 0x024, 0x028, 0x02C
R_DESC0, R_DOORBELL, R_CPL0, R_CPL_POP, R_PERF0, R_DMA_PERF0 = 0x040, 0x070, 0x080, 0x098, 0x100, 0x200
ID_VALUE = 0x5346_5443
SB_BUSY, SB_ERR_STICKY, SB_Q_FULL, SB_Q_EMPTY, SB_CPL_VALID, SB_ABORTING, SB_HALTED = 0, 1, 2, 3, 4, 5, 6
CTRL_ERR_CONT, CTRL_ERR_CLEAR, CTRL_PERF_CLEAR, CTRL_ABORT = 0, 1, 2, 3
PC = dict(CYCLES=0, BUSY=1, CMD_ACCEPT=2, CMD_DONE=3, CMD_ERR=4, GEMM_OK=5, TILES=6, CHUNKS=7, MACS=8,
          COMPUTE_CYC=9, DMA_ACTIVE=10, OVERLAP=11, RD_WORDS=12, WR_WORDS=13, BUS_STALL=14, DESC=15,
          Q_FULL=16, CPL_STALL=17, SAT=18, ABORTS=19)


@dataclass(frozen=True)
class HwConfig:
    rows: int = 4
    cols: int = 4
    tile_k: int = 64
    opb: int = 2048
    banks: int = 4
    quant: bool = False
    dbuf: bool = False
    mem_lo: int = 0x1000_0000
    mem_hi: int = 0x1000_0000 + (1 << 20)
    k_max: int = 131071
    max_out: int = 4
    cmdq: int = 4
    cplq: int = 4
    wdog_log2: int = 16

    def params(self) -> dict:
        """HDL parameters of the integration testbench wrapper."""
        return dict(ROWS=self.rows, COLS=self.cols, TK=self.tile_k, OPB=self.opb, NB=self.banks,
                    QUANT=int(self.quant), DBUF=int(self.dbuf), MAXOUT=self.max_out, KMAX=self.k_max,
                    CMDQ=self.cmdq, CPLQ=self.cplq, WDOG=self.wdog_log2,
                    MEM_LO=self.mem_lo, MEM_HI=self.mem_hi)


# ----------------------------------------------------------------------------- descriptor


@dataclass
class Gemm:
    a: int
    b: int
    c: int
    m: int
    n: int
    k: int
    lda: int
    ldb: int
    ldc: int
    kc: int = 0
    tid: int = 0
    irq: bool = False
    barrier: bool = False
    prefetch: bool = False
    nmajor: bool = False
    out_int8: bool = False
    rm: int = 0
    relu: bool = False
    q_mult: int = 0
    q_shift: int = 0
    q_zp: int = 0
    # raw overrides for negative tests: word index -> value OR-ed in / replaced
    poke_or: dict = field(default_factory=dict)
    version: int = ABI_VERSION
    opcode: int = OP_GEMM
    a_type: int = 0
    b_type: int = 0
    ofmt_raw: int | None = None
    layouts: tuple = (0, 0, 0)
    flags_raw: int | None = None

    @property
    def esz(self) -> int:
        return 1 if self.out_int8 else 4

    @property
    def ofmt(self) -> int:
        return self.ofmt_raw if self.ofmt_raw is not None else (OFMT_INT8 if self.out_int8 else OFMT_INT32)

    @property
    def flags(self) -> int:
        if self.flags_raw is not None:
            return self.flags_raw
        return (self.irq << FL_IRQ) | (self.barrier << FL_BARRIER) | (self.prefetch << FL_PREFETCH) | \
               (self.nmajor << FL_NMAJOR)

    def words(self) -> list[int]:
        w = [0] * 12
        w[0] = (self.opcode & 0xFF) | (self.version & 0xF) << 8 | (self.rm & 7) << 12 | \
               (self.flags & 0xFF) << 16 | (self.tid & 0xFF) << 24
        w[1], w[2], w[3] = self.a, self.b, self.c
        w[4] = (self.m & 0xFFFF) | (self.n & 0xFFFF) << 16
        w[5] = (self.k & 0x1FFFF) | (self.kc & 0x7FFF) << 17
        w[6], w[7], w[8] = self.lda, self.ldb, self.ldc
        la, lb, lc = self.layouts
        w[9] = (self.a_type & 3) | (self.b_type & 3) << 2 | (self.ofmt & 3) << 4 | (la & 3) << 8 | \
               (lb & 3) << 10 | (lc & 3) << 12 | int(self.relu) << 14
        w[10] = to_unsigned(self.q_mult, 32)
        w[11] = (self.q_shift & 0x3F) | (self.q_zp & 0xFF) << 8
        for i, v in self.poke_or.items():
            w[i] |= v
        return [x & 0xFFFF_FFFF for x in w]

    def qparams(self) -> QParams:
        zp = self.q_zp - 256 if self.q_zp >= 128 else self.q_zp
        return QParams(mult=self.q_mult, shift=self.q_shift, zp=zp, rm=self.rm, relu=self.relu,
                       ofmt=Q_OFMT_INT8, rq=True)


def nop(tid: int = 0, irq: bool = False) -> list[int]:
    return [(OP_NOP | ABI_VERSION << 8 | (int(irq) << FL_IRQ) << 16 | (tid & 0xFF) << 24)] + [0] * 11


def decode(w: list[int]) -> dict:
    return dict(op=w[0] & 0xFF, ver=(w[0] >> 8) & 0xF, rm=(w[0] >> 12) & 7, h15=(w[0] >> 15) & 1,
                flags=(w[0] >> 16) & 0xFF, tid=(w[0] >> 24) & 0xFF, a=w[1], b=w[2], c=w[3],
                m=w[4] & 0xFFFF, n=w[4] >> 16, k=w[5] & 0x1FFFF, kc=w[5] >> 17, lda=w[6], ldb=w[7], ldc=w[8],
                a_type=w[9] & 3, b_type=(w[9] >> 2) & 3, ofmt=(w[9] >> 4) & 3,
                layouts=((w[9] >> 8) & 3, (w[9] >> 10) & 3, (w[9] >> 12) & 3), relu=(w[9] >> 14) & 1,
                q_mult=w[10], q_shift=w[11] & 0x3F, q_zp=(w[11] >> 8) & 0xFF)


# ----------------------------------------------------------------------------- validation (doc 02 §4)


def validate(w: list[int], hw: HwConfig) -> int:
    """Error code of the first failing rule (0 = valid).  Pure integer arithmetic."""
    d = decode(w)
    if d["ver"] != ABI_VERSION:
        return E_VERSION                                                   # rule 1
    if d["op"] not in (OP_NOP, OP_GEMM):
        return E_OPCODE                                                    # rule 2
    if d["op"] == OP_NOP:
        if d["flags"] & ~((1 << FL_IRQ) | (1 << FL_BARRIER)):
            return E_FLAGS                                                 # rule 3 (resolution a)
        if d["h15"] or d["rm"] or any(w[1:12]):
            return E_RSVD                                                  # rule 4
        return E_NONE
    fl = d["flags"]
    if fl & 0xF0 or ((fl >> FL_PREFETCH) & 1 and not hw.dbuf):
        return E_FLAGS                                                     # rule 3
    int32 = d["ofmt"] == OFMT_INT32
    int8 = d["ofmt"] == OFMT_INT8
    if d["h15"] or (w[9] & W9_RSVD_MASK) or (w[11] & W11_RSVD_MASK):
        return E_RSVD                                                      # rule 4
    if int32 and (d["rm"] or d["relu"] or w[10] or w[11]):
        return E_RSVD                                                      # rule 4 (resolution b)
    if int8 and d["rm"] >= 5:
        return E_RM                                                        # rule 5
    if any(d["layouts"]):
        return E_LAYOUT                                                    # rule 6
    if d["a_type"] or d["b_type"] or not (int32 or (int8 and hw.quant)):
        return E_PRECISION                                                 # rule 7
    m, n, k, kc = d["m"], d["n"], d["k"], d["kc"]
    if m == 0 or n == 0 or k == 0:
        return E_DIM_ZERO                                                  # rule 8
    if k > hw.k_max:
        return E_DIM_RANGE                                                 # rule 9
    kce = kc if kc else hw.tile_k
    if kc > hw.tile_k or ceil_div(k, kce) > 65535:
        return E_CHUNK                                                     # rule 10
    esz = 1 if int8 else 4
    if d["lda"] < k or d["ldb"] < n or d["ldc"] < n * esz:
        return E_LD                                                        # rule 11
    if int32 and (d["c"] % 4 or d["ldc"] % 4):
        return E_ALIGN                                                     # rule 12
    fa = (d["a"], d["a"] + (m - 1) * d["lda"] + k - 1)
    fb = (d["b"], d["b"] + (k - 1) * d["ldb"] + n - 1)
    fc = (d["c"], d["c"] + (m - 1) * d["ldc"] + n * esz - 1)
    if max(fa[1], fb[1], fc[1]) >= 1 << 32:
        return E_ADDR_OVF                                                  # rule 13
    for lo, hi in (fa, fb, fc):
        if lo < hw.mem_lo or hi >= hw.mem_hi:
            return E_RANGE                                                 # rule 14
    for lo, hi in (fa, fb):
        if fc[0] <= hi and lo <= fc[1]:
            return E_ALIAS                                                 # rule 15
    return E_NONE


# ----------------------------------------------------------------------------- schedule (doc 04 §4)


@dataclass(frozen=True)
class Step:
    m0: int
    n0: int
    k0: int
    em: int
    en: int
    ek: int
    kidx: int
    first_k: bool
    last_k: bool
    tile_idx: int


def schedule(g: Gemm, hw: HwConfig) -> list[Step]:
    kc = g.kc if g.kc else hw.tile_k
    steps = []
    for t_idx, t in enumerate(output_tiles(g.m, g.n, hw.rows, hw.cols, g.nmajor)):
        ch = k_chunks(g.k, kc)
        for ci, (k0, ek) in enumerate(ch):
            steps.append(Step(t.m0, t.n0, k0, t.em, t.en, ek, ci, ci == 0, ci == len(ch) - 1, t_idx))
    return steps


def lda_loc(ek: int) -> int:
    """Local A row stride: ek rounded up to 4 bytes, plus 4 if that is a multiple of 8
    (odd word stride, so the A rows of a slice fall in different operand-buffer banks)."""
    r4 = ceil_div(ek, 4) * 4
    return r4 + 4 if r4 % 8 == 0 else r4


def ldb_loc(hw: HwConfig) -> int:
    return ceil_div(hw.cols, 4) * 4


KIND_LOAD_A, KIND_LOAD_B, KIND_STORE = 0, 1, 2


@dataclass(frozen=True)
class Xfer:
    kind: int
    src: int
    dst: int
    sstride: int
    dstride: int
    row_len: int
    rows: int
    seal: bool
    step: int               # index of the step (LOADs) / of the last step of the tile (STORE)
    tile: int


def dma_descriptors(g: Gemm, hw: HwConfig) -> list[Xfer]:
    o_ld = 4 * hw.cols
    out = []
    for si, s in enumerate(schedule(g, hw)):
        out.append(Xfer(KIND_LOAD_A, g.a + s.m0 * g.lda + s.k0, 0, g.lda, lda_loc(s.ek), s.ek, s.em, False, si,
                        s.tile_idx))
        out.append(Xfer(KIND_LOAD_B, g.b + s.k0 * g.ldb + s.n0, 0, g.ldb, ldb_loc(hw), s.en, s.ek, True, si,
                        s.tile_idx))
        if s.last_k:
            out.append(Xfer(KIND_STORE, 0, g.c + s.m0 * g.ldc + g.esz * s.n0, o_ld, g.ldc, s.en * g.esz, s.em,
                            True, si, s.tile_idx))
    return out


def row_words(addr: int, length: int) -> list[tuple[int, int]]:
    """[(word_address, strobe)] covering bytes [addr, addr+length) of one row."""
    out = []
    for wa in range(addr & ~3, addr + length, 4):
        st = 0
        for b in range(4):
            if addr <= wa + b < addr + length:
                st |= 1 << b
        out.append((wa, st))
    return out


def read_words(g: Gemm, hw: HwConfig) -> list[tuple[int, int]]:
    """[(word_address, descriptor_index)] of every SFB2 read in issue order."""
    out = []
    for di, x in enumerate(dma_descriptors(g, hw)):
        if x.kind == KIND_STORE:
            continue
        for r in range(x.rows):
            out += [(wa, di) for wa, _ in row_words(x.src + r * x.sstride, x.row_len)]
    return out


def write_words(g: Gemm, hw: HwConfig) -> list[tuple[int, int, int, int]]:
    """[(word_address, strobe, tile, bytes_before_in_tile)] of every SFB2 write in store order."""
    out = []
    for x in dma_descriptors(g, hw):
        if x.kind != KIND_STORE:
            continue
        before = 0
        for r in range(x.rows):
            d = x.dst + r * x.dstride
            for wa, st in row_words(d, x.row_len):
                out.append((wa, st, x.tile, before + max(0, wa - d)))
            before += x.row_len
    return out


# ----------------------------------------------------------------------------- results


def result_matrix(g: Gemm, mem: ByteMemory) -> tuple[Matrix, bool]:
    """Exact C (INT32) or requantised C (INT8) and the SAT flag."""
    a = mem.load_int8(g.a, g.lda, g.m, g.k)
    b = mem.load_int8(g.b, g.ldb, g.k, g.n)
    c = gemm(a, b)
    if not g.out_int8:
        return c, False
    p = g.qparams()
    q, sat = [], False
    for row in c:
        r = []
        for v in row:
            x, s = requant(v, p)
            r.append(x)
            sat |= s
        q.append(r)
    return q, sat


def write_result(g: Gemm, mem: ByteMemory, c: Matrix, tiles: set[int] | None = None,
                 hw: HwConfig | None = None) -> None:
    """Write C (all of it, or only the given output tiles) into the memory image."""
    sel = None
    if tiles is not None:
        sel = set()
        for ti, t in enumerate(output_tiles(g.m, g.n, hw.rows, hw.cols, g.nmajor)):
            if ti in tiles:
                sel |= {(i, j) for i in range(t.m0, t.m0 + t.em) for j in range(t.n0, t.n0 + t.en)}
    for i in range(g.m):
        for j in range(g.n):
            if sel is not None and (i, j) not in sel:
                continue
            if g.out_int8:
                mem[g.c + i * g.ldc + j] = c[i][j] & 0xFF
            else:
                mem.write_word(g.c + i * g.ldc + 4 * j, to_unsigned(c[i][j], 32))


def c_footprint(g: Gemm) -> set[int]:
    return {g.c + i * g.ldc + j for i in range(g.m) for j in range(g.n * g.esz)}


def tile_bytes(g: Gemm, hw: HwConfig) -> list[int]:
    return [t.em * t.en * g.esz for t in output_tiles(g.m, g.n, hw.rows, hw.cols, g.nmajor)]


def counters(g: Gemm, hw: HwConfig) -> dict:
    """Expected per-command counter increments of a successful GEMM."""
    st = schedule(g, hw)
    return dict(TILES=sum(1 for s in st if s.last_k), CHUNKS=len(st), MACS=sum(s.em * s.en * s.ek for s in st),
                DESC=2 * len(st) + sum(1 for s in st if s.last_k),
                RD_WORDS=len(read_words(g, hw)), WR_WORDS=len(write_words(g, hw)))


@dataclass
class Poison:
    """Bus error windows on WORD addresses [lo, hi) of the memory model (read and/or write)."""
    lo: int
    hi: int
    read: bool = False
    write: bool = False

    def hits(self, wa: int, is_write: bool) -> bool:
        return self.lo <= wa < self.hi and (self.write if is_write else self.read)


@dataclass
class Outcome:
    status: int
    err: int
    count: int | None            # None: only a range is known (see count_range)
    tiles: int | None
    err_addr: int
    sat: bool
    detail: int = 0
    count_range: tuple[int, int] | None = None
    tiles_range: tuple[int, int] | None = None
    # bytes whose final value is defined (address -> value); every other byte of the C
    # footprint is "don't care", every byte outside it must keep its initial value
    defined_c: dict = field(default_factory=dict)
    undefined_c: set = field(default_factory=set)


def expected_outcome(w: list[int], g: Gemm | None, hw: HwConfig, mem: ByteMemory,
                     poison: list[Poison] | None = None) -> Outcome:
    """Expected record and memory effect of one command executed on `mem` (not modified)."""
    code = validate(w, hw)
    if code != E_NONE:
        return Outcome(ST_ERROR, code, 0, 0, 0, False)
    if g is None or (w[0] & 0xFF) == OP_NOP:
        return Outcome(ST_OK, E_NONE, 0, 0, 0, False)
    c, sat = result_matrix(g, mem)
    final = mem.copy()
    write_result(g, final, c)
    cfp = c_footprint(g)
    poison = poison or []
    rd = read_words(g, hw)
    wr = write_words(g, hw)
    tb = tile_bytes(g, hw)
    first_rd = next(((wa, di) for wa, di in rd if any(p.hits(wa, False) for p in poison)), None)
    first_wr = next(((wa, st, t, bb) for wa, st, t, bb in wr if any(p.hits(wa, True) for p in poison)), None)
    if first_rd is None and first_wr is None:
        return Outcome(ST_OK, E_NONE, sum(tb), len(tb), 0, sat, defined_c={a: final[a] for a in cfp})
    # The LOAD stream (reads) and the STORE stream (writes) overlap in time: the STORE of tile t
    # runs while later steps load.  When both a read and a write would fail, which error is
    # reported first depends on timing, so tests inject one kind per command; the model
    # refuses to predict a mixed injection rather than guess.
    if first_rd is not None and first_wr is not None:
        raise ValueError("mixed read and write error injection: outcome is timing dependent")
    descs = dma_descriptors(g, hw)
    if first_wr is not None:
        # Write error: the STORE channel executes one descriptor at a time in tile order, so every
        # earlier tile was stored and acknowledged; the record counts the contiguous acknowledged
        # prefix of the failing tile (bytes before the failing word).  The failing word has no
        # side effect (SFB2 R8).  Writes issued after it may or may not have been performed.
        wa, st, t, bb = first_wr
        defined = defined_after_tiles(g, hw, mem, t)
        for wa2, st2, t2, bb2 in wr:
            if t2 == t and wa2 != wa and bb2 < bb:
                for i in range(4):
                    if (st2 >> i) & 1:
                        defined[wa2 + i] = final[wa2 + i]
            if t2 == t and wa2 == wa:
                break
        for i in range(4):
            if (st >> i) & 1:
                defined[wa + i] = mem[wa + i]
        # doc 05: "nothing after it" - tiles after the failing one keep their initial bytes
        later = footprint_of_tiles(g, hw, set(range(t + 1, len(tb))))
        for a in later:
            defined[a] = mem[a]
        return Outcome(ST_ERROR, E_DMA_WRITE, sum(tb[:t]) + bb, t, wa, sat, detail=TDMA_C_WR_BUS,
                       defined_c=defined, undefined_c=cfp - set(defined))
    # Read error: ERR_ADDR is the first poisoned word of the read sequence (reads are issued and
    # answered in order).  The STOREs of tiles before the failing step's tile may or may not have
    # completed, so COUNT / TILES are only bounded; the checker requires them to be consistent
    # with each other and with the memory image (tiles < TILES exact).
    wa, di = first_rd
    t = descs[di].tile
    return Outcome(ST_ERROR, E_DMA_READ, None, None, wa, sat, detail=TDMA_C_RD_BUS,
                   count_range=(0, sum(tb[:t])), tiles_range=(0, t), defined_c={}, undefined_c=cfp)


def footprint_of_tiles(g: Gemm, hw: HwConfig, tiles: set[int]) -> set[int]:
    out = set()
    for ti, t in enumerate(output_tiles(g.m, g.n, hw.rows, hw.cols, g.nmajor)):
        if ti in tiles:
            for i in range(t.m0, t.m0 + t.em):
                out |= {g.c + i * g.ldc + g.esz * t.n0 + j for j in range(t.en * g.esz)}
    return out


def defined_after_tiles(g: Gemm, hw: HwConfig, mem: ByteMemory, n_tiles: int) -> dict:
    """Bytes of C fully defined once the first n_tiles STOREs completed OK."""
    c, _ = result_matrix(g, mem)
    part = mem.copy()
    write_result(g, part, c, set(range(n_tiles)), hw)
    return {a: part[a] for a in footprint_of_tiles(g, hw, set(range(n_tiles)))}


def with_(g: Gemm, **kw) -> Gemm:
    return replace(g, **kw)
