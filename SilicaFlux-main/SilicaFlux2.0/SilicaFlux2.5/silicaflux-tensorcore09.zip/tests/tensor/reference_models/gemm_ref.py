"""Exact integer GEMM reference for SilicaFlux TensorCore verification.

Written for TENSORCORE 09 from the documented contracts (TC08 doc 02 "Command ABI",
TC04 NUMERIC_RANGE, TC01 INTERFACE_SPEC), not from the RTL.

Design rules of this module
---------------------------
* Every value is a Python ``int`` (arbitrary precision).  No NumPy, no fixed-width
  integer type is used anywhere on the arithmetic path, so no intermediate can wrap
  or lose precision.  Fixed-width behaviour (wrap modulo 2^W, saturation, overflow
  detection) is applied explicitly and only where the contract says so.
* Matrices are read from / written to a *byte memory* exactly as the hardware sees
  them: row-major, every address and leading dimension in bytes, INT8 elements as
  signed two's complement bytes, INT32 elements little-endian.
* The accumulation *order* is explicit where it matters.  Exact accumulation is
  order independent, but saturating accumulation is not: a saturating accumulator
  that clamps at every step (TC01 PE) and one that clamps once per K chunk (TC04)
  give different results once a prefix leaves the range.  The policy functions
  below therefore take the sequence of addends, not just the final sum.

Overflow policies modelled (``AccPolicy``)
------------------------------------------
EXACT     unbounded; the mathematical value.  The TSU contract (K <= K_MAX = 131071)
          guarantees this is representable in INT32, so the TSU result must equal it.
WRAP      two's complement modulo 2^W, overflow flagged (TC01 OVF_POLICY=WRAP,
          TC04 OVF_WRAP, TC02 PE inside a launch: silent wrap at ACC_WIDTH).
SATURATE  clamp to [-2^(W-1), 2^(W-1)-1] at every add of the given granularity,
          overflow flagged and sticky (TC01 OVF_POLICY=SATURATE, TC04 OVF_SATURATE).
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Sequence

# ----------------------------------------------------------------------------- integer helpers


def srange(w: int) -> tuple[int, int]:
    """Inclusive range of a signed w-bit two's complement integer."""
    return -(1 << (w - 1)), (1 << (w - 1)) - 1


def fits(v: int, w: int) -> bool:
    lo, hi = srange(w)
    return lo <= v <= hi


def to_signed(v: int, w: int) -> int:
    """Interpret the low w bits of v as a signed two's complement number."""
    v &= (1 << w) - 1
    return v - (1 << w) if v >> (w - 1) else v


def to_unsigned(v: int, w: int) -> int:
    return v & ((1 << w) - 1)


def wrap(v: int, w: int) -> int:
    """v modulo 2^w, as a signed w-bit value."""
    return to_signed(v, w)


def saturate(v: int, w: int) -> int:
    lo, hi = srange(w)
    return lo if v < lo else hi if v > hi else v


def ceil_div(a: int, b: int) -> int:
    return -(-a // b)


def round_up(v: int, q: int) -> int:
    return ceil_div(v, q) * q


# ----------------------------------------------------------------------------- numeric bounds


def product_extremes(data_w: int) -> tuple[int, int]:
    """(P_MIN, P_MAX) of signed data_w x data_w products, by enumerating the four corners."""
    lo, hi = srange(data_w)
    corners = [a * b for a in (lo, hi) for b in (lo, hi)]
    return min(corners), max(corners)


def max_exact_k(data_w: int, acc_w: int, bias_max: int = 0, bias_min: int = 0) -> int:
    """Largest K such that every prefix of every K-term sum (plus bias) fits acc_w bits.

    Derived by integer division from the corner products - deliberately *not* from the
    closed form 2^(acc_w - 2*data_w + 1) - 1, so the two can be cross-checked."""
    pmin, pmax = product_extremes(data_w)
    lo, hi = srange(acc_w)
    if bias_max > hi or bias_min < lo:
        return 0
    k_pos = (hi - bias_max) // pmax
    k_neg = (bias_min - lo) // (-pmin) if pmin < 0 else k_pos
    return max(0, min(k_pos, k_neg))


# ----------------------------------------------------------------------------- accumulation policies


class AccPolicy(Enum):
    EXACT = "exact"
    WRAP = "wrap"
    SATURATE = "saturate"


@dataclass
class AccResult:
    value: int
    overflow: bool          # sticky: some add left the representable range


def accumulate(addends: Iterable[int], width: int | None = None, policy: AccPolicy = AccPolicy.EXACT,
               start: int = 0) -> AccResult:
    """Apply ``acc = policy(acc + x)`` for each addend in order, starting from ``start``.

    For EXACT, ``width`` (if given) is only used to report whether the exact value
    would overflow; the value itself is unbounded."""
    acc, ovf = start, False
    for x in addends:
        s = acc + x
        if width is not None and not fits(s, width):
            ovf = True
            if policy is AccPolicy.WRAP:
                s = wrap(s, width)
            elif policy is AccPolicy.SATURATE:
                s = saturate(s, width)
        acc = s
    return AccResult(acc, ovf)


# ----------------------------------------------------------------------------- matrices


Matrix = list[list[int]]


def zeros(m: int, n: int) -> Matrix:
    return [[0] * n for _ in range(m)]


def transpose(a: Matrix) -> Matrix:
    return [list(r) for r in zip(*a)] if a else []


def check_int8(a: Matrix) -> None:
    for r in a:
        for v in r:
            if not -128 <= v <= 127:
                raise ValueError(f"operand {v} is not INT8")


def gemm(a: Matrix, b: Matrix, bias: Sequence[int] | None = None) -> Matrix:
    """C = A x B (+ bias[n]) exactly, by the textbook triple loop over Python ints."""
    m, k = len(a), len(a[0]) if a else 0
    if len(b) != k:
        raise ValueError(f"inner dimensions differ: A is {m}x{k}, B has {len(b)} rows")
    n = len(b[0]) if b else 0
    c = zeros(m, n)
    for i in range(m):
        ai = a[i]
        for j in range(n):
            s = bias[j] if bias is not None else 0
            for kk in range(k):
                s += ai[kk] * b[kk][j]
            c[i][j] = s
    return c


def gemm_terms(a: Matrix, b: Matrix, i: int, j: int) -> list[int]:
    """The K products of element (i, j) in reduction order k = 0 .. K-1."""
    return [a[i][kk] * b[kk][j] for kk in range(len(b))]


def gemm_policy(a: Matrix, b: Matrix, width: int, policy: AccPolicy, bias: Sequence[int] | None = None,
                chunk: int | None = None) -> tuple[Matrix, list[list[bool]]]:
    """C under a fixed-width accumulator policy.

    chunk=None: the policy is applied at every MAC (per-product granularity, TC01 PE).
    chunk=kc  : partial sums of kc products are formed exactly and the policy is applied
                once per chunk add (TC04 granularity); bias is folded into the first add."""
    m, n, k = len(a), len(b[0]) if b else 0, len(b)
    c, f = zeros(m, n), [[False] * n for _ in range(m)]
    for i in range(m):
        for j in range(n):
            t = gemm_terms(a, b, i, j)
            if chunk is None:
                adds = t
                start = bias[j] if bias is not None else 0
            else:
                adds = [sum(t[k0:k0 + chunk]) for k0 in range(0, k, chunk)]
                if bias is not None and adds:
                    adds[0] += bias[j]
                start = 0
            r = accumulate(adds, width, policy, start)
            c[i][j], f[i][j] = r.value, r.overflow
    return c, f


# ----------------------------------------------------------------------------- K chunking and tiling


def k_chunks(k: int, kc: int) -> list[tuple[int, int]]:
    """[(k0, eff_k)] for a reduction of length k in chunks of kc."""
    if k <= 0 or kc <= 0:
        raise ValueError("k and kc must be positive")
    return [(k0, min(kc, k - k0)) for k0 in range(0, k, kc)]


def gemm_chunked(a: Matrix, b: Matrix, kc: int, bias: Sequence[int] | None = None) -> Matrix:
    """C computed as the sum of K-chunk partial products (must equal gemm() exactly)."""
    m, n, k = len(a), len(b[0]), len(b)
    c = [[(bias[j] if bias is not None else 0) for j in range(n)] for _ in range(m)]
    for k0, ek in k_chunks(k, kc):
        for i in range(m):
            for j in range(n):
                c[i][j] += sum(a[i][kk] * b[kk][j] for kk in range(k0, k0 + ek))
    return c


@dataclass(frozen=True)
class Tile:
    m0: int
    n0: int
    em: int                 # effective rows    (partial at the bottom edge)
    en: int                 # effective columns (partial at the right edge)


def output_tiles(m: int, n: int, tm: int, tn: int, nmajor: bool = False) -> list[Tile]:
    """Output tiles in traversal order: M-major (n inner) or N-major (m inner)."""
    if nmajor:
        order = [(m0, n0) for n0 in range(0, n, tn) for m0 in range(0, m, tm)]
    else:
        order = [(m0, n0) for m0 in range(0, m, tm) for n0 in range(0, n, tn)]
    return [Tile(m0, n0, min(tm, m - m0), min(tn, n - n0)) for m0, n0 in order]


def gemm_tiled(a: Matrix, b: Matrix, tm: int, tn: int, kc: int, nmajor: bool = False) -> Matrix:
    """C assembled tile by tile and chunk by chunk (must equal gemm() exactly)."""
    m, n, k = len(a), len(b[0]), len(b)
    c = zeros(m, n)
    seen = [[0] * n for _ in range(m)]
    for t in output_tiles(m, n, tm, tn, nmajor):
        acc = zeros(t.em, t.en)
        for k0, ek in k_chunks(k, kc):
            for i in range(t.em):
                for j in range(t.en):
                    acc[i][j] += sum(a[t.m0 + i][kk] * b[kk][t.n0 + j] for kk in range(k0, k0 + ek))
        for i in range(t.em):
            for j in range(t.en):
                c[t.m0 + i][t.n0 + j] = acc[i][j]
                seen[t.m0 + i][t.n0 + j] += 1
    if any(v != 1 for r in seen for v in r):
        raise AssertionError("tiling does not cover every output element exactly once")
    return c


# ----------------------------------------------------------------------------- byte memory


class ByteMemory:
    """Sparse little-endian byte memory (missing bytes read as `fill`)."""

    def __init__(self, fill: int = 0):
        self.b: dict[int, int] = {}
        self.fill = fill & 0xFF

    def __getitem__(self, a: int) -> int:
        return self.b.get(a, self.fill)

    def __setitem__(self, a: int, v: int) -> None:
        self.b[a] = v & 0xFF

    def copy(self) -> "ByteMemory":
        m = ByteMemory(self.fill)
        m.b = dict(self.b)
        return m

    def read_word(self, a: int) -> int:
        return self[a] | self[a + 1] << 8 | self[a + 2] << 16 | self[a + 3] << 24

    def write_word(self, a: int, v: int, strb: int = 0xF) -> None:
        for i in range(4):
            if (strb >> i) & 1:
                self[a + i] = (v >> (8 * i)) & 0xFF

    def store_int8(self, base: int, ld: int, mat: Matrix) -> None:
        for i, row in enumerate(mat):
            for j, v in enumerate(row):
                self[base + i * ld + j] = v & 0xFF

    def load_int8(self, base: int, ld: int, m: int, n: int) -> Matrix:
        return [[to_signed(self[base + i * ld + j], 8) for j in range(n)] for i in range(m)]

    def store_int32(self, base: int, ld: int, mat: Matrix) -> None:
        for i, row in enumerate(mat):
            for j, v in enumerate(row):
                self.write_word(base + i * ld + 4 * j, to_unsigned(v, 32))

    def load_int32(self, base: int, ld: int, m: int, n: int) -> Matrix:
        return [[to_signed(self.read_word(base + i * ld + 4 * j), 32) for j in range(n)] for i in range(m)]


def footprint(base: int, ld: int, rows: int, row_bytes: int) -> set[int]:
    """Set of byte addresses of a row-major matrix region."""
    return {base + i * ld + j for i in range(rows) for j in range(row_bytes)}


def gemm_from_memory(mem: ByteMemory, a_base: int, lda: int, b_base: int, ldb: int,
                     m: int, n: int, k: int, bias: Sequence[int] | None = None) -> Matrix:
    """C = A x B with A and B read from the byte memory (row-major, byte leading dimensions)."""
    a = mem.load_int8(a_base, lda, m, k)
    b = mem.load_int8(b_base, ldb, k, n)
    return gemm(a, b, bias)
