"""Requantisation reference (TENSORCORE 05 output-conversion contract).

Contract (TC05 docs/NUMERIC_FORMAT.md §2, TC08 doc 02 §2):

    x   = acc + bias[n]
    y   = R_rm( x * M / 2^S ) + zp            (INT8 output / RQ mode)
    q   = clamp(y, qmin, qmax)                (saturation; y mod 2^32 only with WRAP, INT32)
    sat = y < qmin or y > qmax
    q   = max(q, zp)                          (ReLU in the quantised domain: floor = zero-point)

Independence: TC05's own model rounds an exact ``fractions.Fraction``; the RTL uses
an arithmetic shift with guard / sticky bits.  This module uses a third method:
Python's floor ``divmod`` by 2^S and an explicit comparison of the remainder with
one half.  The self-tests compare all three where available.
"""
from __future__ import annotations

from dataclasses import dataclass

RM_RNE, RM_RTZ, RM_RDN, RM_RUP, RM_RMM = 0, 1, 2, 3, 4
RM_NAMES = {RM_RNE: "RNE", RM_RTZ: "RTZ", RM_RDN: "RDN", RM_RUP: "RUP", RM_RMM: "RMM"}
OFMT_INT32, OFMT_INT8 = 0, 1
QRANGE = {OFMT_INT32: (-(1 << 31), (1 << 31) - 1), OFMT_INT8: (-128, 127)}


def round_shift(p: int, s: int, rm: int) -> int:
    """R_rm(p / 2^s) for an exact integer p and 0 <= s, one rounding."""
    if s < 0:
        raise ValueError("negative shift")
    if s == 0:
        return p
    d = 1 << s
    q, r = divmod(p, d)             # q = floor(p / d), 0 <= r < d
    half2 = 2 * r                   # compare r with d/2 without fractions: 2r vs d
    if rm == RM_RDN:                # toward -inf
        return q
    if rm == RM_RUP:                # toward +inf
        return q + (r != 0)
    if rm == RM_RTZ:                # toward zero: floor for positives, ceil for negatives
        return q + (r != 0 and p < 0)
    if rm == RM_RNE:                # nearest, ties to even
        if half2 > d:
            return q + 1
        if half2 < d:
            return q
        return q + (q & 1)
    if rm == RM_RMM:                # nearest, ties away from zero
        if half2 > d:
            return q + 1
        if half2 < d:
            return q
        return q + 1 if p > 0 else q
    raise ValueError(f"illegal rounding mode {rm}")


@dataclass(frozen=True)
class QParams:
    mult: int = 1           # signed 32-bit multiplier M
    shift: int = 0          # 0..63
    zp: int = 0             # output zero-point, inside the output range
    rm: int = RM_RNE
    relu: bool = False
    ofmt: int = OFMT_INT8
    rq: bool = True         # requantise (INT8 path of the TSU always does)
    wrap: bool = False      # INT32 only


def requant(acc: int, p: QParams, bias: int = 0) -> tuple[int, bool]:
    """(q, sat) for one element."""
    if not -(1 << 31) <= p.mult < (1 << 31):
        raise ValueError("Q_MULT must be a signed 32-bit integer")
    if not 0 <= p.shift <= 63:
        raise ValueError("Q_SHIFT must be 0..63")
    qmin, qmax = QRANGE[p.ofmt]
    if p.rq and not qmin <= p.zp <= qmax:
        raise ValueError("zero-point outside the output range (rejected by the hardware)")
    x = acc + bias
    y = round_shift(x * p.mult, p.shift, p.rm) + p.zp if p.rq else x
    sat = y < qmin or y > qmax
    if p.wrap:
        if p.ofmt != OFMT_INT32:
            raise ValueError("WRAP is INT32 only")
        q = ((y + (1 << 31)) % (1 << 32)) - (1 << 31)
    else:
        q = min(max(y, qmin), qmax)
    if p.relu:
        q = max(q, p.zp if p.rq else 0)
    return q, sat


def requant_matrix(c: list[list[int]], p: QParams) -> tuple[list[list[int]], bool]:
    """Element-wise requantisation of an exact INT32 GEMM result; returns (Q, any_sat)."""
    out, any_sat = [], False
    for row in c:
        r = []
        for v in row:
            q, s = requant(v, p)
            r.append(q)
            any_sat |= s
        out.append(r)
    return out, any_sat


def quantize_multiplier(scale_num: int, scale_den: int, shift_max: int = 63) -> tuple[int, int]:
    """Host-side conversion of a positive rational scale num/den to (M, S), |M| < 2^31,
    S as large as possible (most precise), rounding M to nearest.  Integer-only."""
    if scale_num <= 0 or scale_den <= 0:
        raise ValueError("positive scale required")
    best = None
    for s in range(shift_max, -1, -1):
        m, r = divmod(scale_num << s, scale_den)
        if 2 * r >= scale_den:
            m += 1
        if m < (1 << 31):
            best = (m, s)
            break
    if best is None:
        raise ValueError("scale too large")
    return best
