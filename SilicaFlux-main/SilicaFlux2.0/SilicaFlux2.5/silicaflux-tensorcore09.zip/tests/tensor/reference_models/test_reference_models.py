"""Self-tests of the TENSORCORE 09 reference models.

A reference is only useful if it is itself right.  These tests establish that by
(1) first-principles checks, (2) exhaustive enumeration where the space is small,
(3) agreement of independent formulations (triple loop vs chunked vs tiled GEMM;
divmod rounding vs Fraction rounding vs the hardware guard/sticky algorithm), and
(4) agreement with the earlier stages' own, independently written models (TC05
tq_ref, TC08 tsu_ref) when the RTL archive is staged.

Run:  pytest tests/tensor/reference_models
"""
from __future__ import annotations

import importlib.util
import itertools
import random
import re
import sys
from fractions import Fraction
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
if str(TT) not in sys.path:
    sys.path.insert(0, str(TT))

from reference_models import gemm_ref as G          # noqa: E402
from reference_models import quant_ref as Q         # noqa: E402
from reference_models import tsu_model as T         # noqa: E402

TC08 = TT / "build" / "rtl" / "tc08"
SEED = 0x7E9509


def rng(tag: str) -> random.Random:
    return random.Random(f"{SEED}:{tag}")


def rand_mat(r: random.Random, m: int, n: int, lo: int = -128, hi: int = 127) -> G.Matrix:
    return [[r.randint(lo, hi) for _ in range(n)] for _ in range(m)]


def load_module(name: str, path: Path):
    if not path.exists():
        pytest.skip(f"{path} not staged (run scripts/stage_rtl.py)")
    if name in sys.modules:
        return sys.modules[name]
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod                     # dataclasses resolve annotations through sys.modules
    spec.loader.exec_module(mod)
    return mod


# =============================================================================== integer helpers

def test_signed_helpers():
    assert G.srange(8) == (-128, 127) and G.srange(32) == (-(1 << 31), (1 << 31) - 1)
    assert G.to_signed(0xFF, 8) == -1 and G.to_signed(0x7F, 8) == 127 and G.to_signed(0x80, 8) == -128
    assert G.wrap(1 << 31, 32) == -(1 << 31) and G.wrap(-(1 << 31) - 1, 32) == (1 << 31) - 1
    assert G.saturate(1 << 40, 32) == (1 << 31) - 1 and G.saturate(-(1 << 40), 32) == -(1 << 31)
    for v in range(-300, 300):
        assert G.wrap(v, 8) == ((v + 128) % 256) - 128


def test_product_extremes_int8():
    pmin, pmax = G.product_extremes(8)
    allp = [a * b for a in range(-128, 128) for b in range(-128, 128)]
    assert (pmin, pmax) == (min(allp), max(allp)) == (-16256, 16384)


@pytest.mark.parametrize("dw", range(2, 9))
def test_max_exact_k_formula(dw):
    for acc_w in range(2 * dw, 65):
        assert G.max_exact_k(dw, acc_w) == (1 << (acc_w - 2 * dw + 1)) - 1
    assert G.max_exact_k(8, 32) == 131071           # the TSU K_MAX
    assert 131071 * 16384 < 1 << 31 <= 131072 * 16384


@pytest.mark.parametrize("dw,acc_w", [(2, 4), (2, 5), (2, 6), (3, 6), (3, 7)])
def test_max_exact_k_exhaustive(dw, acc_w):
    """Enumerate every product sequence: no prefix overflows for K <= bound, some does at bound+1."""
    lo, hi = G.srange(dw)
    prods = sorted({a * b for a in range(lo, hi + 1) for b in range(lo, hi + 1)})
    kb = G.max_exact_k(dw, acc_w)

    def overflows(k):
        for seq in itertools.product(prods, repeat=k):
            s = 0
            for p in seq:
                s += p
                if not G.fits(s, acc_w):
                    return True
        return False
    assert kb >= 1 and not overflows(kb) and overflows(kb + 1)


# =============================================================================== GEMM

def test_gemm_small_literal():
    a = [[1, 2], [3, 4]]
    b = [[5, 6], [7, 8]]
    assert G.gemm(a, b) == [[19, 22], [43, 50]]
    assert G.gemm(a, b, bias=[100, -100]) == [[119, -78], [143, -50]]


def test_gemm_extremes_exact():
    k = 131071
    a = [[-128] * k]
    b = [[-128] for _ in range(k)]
    assert G.gemm(a, b) == [[k * 16384]] and k * 16384 == 2147467264
    a2 = [[127] * k]
    b2 = [[-128] for _ in range(k)]
    assert G.gemm(a2, b2) == [[-16256 * k]]


@pytest.mark.parametrize("trial", range(25))
def test_gemm_chunked_and_tiled_equal_direct(trial):
    r = rng(f"tile{trial}")
    m, n, k = r.randint(1, 13), r.randint(1, 13), r.randint(1, 70)
    a, b = rand_mat(r, m, k), rand_mat(r, k, n)
    c = G.gemm(a, b)
    kc = r.randint(1, k)
    assert G.gemm_chunked(a, b, kc) == c
    tm, tn = r.choice([1, 2, 4, 8]), r.choice([1, 2, 4, 8])
    assert G.gemm_tiled(a, b, tm, tn, kc, nmajor=bool(trial & 1)) == c


def test_numpy_int64_cross_check_and_int8_pitfall():
    np = pytest.importorskip("numpy")
    r = rng("numpy")
    m, n, k = 9, 7, 300
    a, b = rand_mat(r, m, k), rand_mat(r, k, n)
    # explicit 64-bit accumulation: exact because 300 * 16384 << 2^63
    ref = np.matmul(np.array(a, dtype=np.int64), np.array(b, dtype=np.int64))
    assert ref.tolist() == G.gemm(a, b)
    # the pitfall the brief warns about: an INT8 matmul accumulates in INT8 and wraps
    naive = np.matmul(np.array(a, dtype=np.int8), np.array(b, dtype=np.int8))
    assert naive.dtype == np.int8 and naive.astype(np.int64).tolist() != G.gemm(a, b)


def test_accumulate_policies():
    big = [16384] * 131072                          # exactly 2^31: one past INT32_MAX
    assert G.accumulate(big, 32, G.AccPolicy.EXACT).value == 1 << 31
    assert G.accumulate(big, 32, G.AccPolicy.EXACT).overflow
    assert G.accumulate(big, 32, G.AccPolicy.WRAP) == G.AccResult(-(1 << 31), True)
    assert G.accumulate(big, 32, G.AccPolicy.SATURATE) == G.AccResult((1 << 31) - 1, True)
    assert G.accumulate(big[:-1], 32, G.AccPolicy.SATURATE) == G.AccResult(2147467264, False)
    # saturation is order dependent: clamp-then-subtract differs from subtract-then-clamp
    seq = [100, 100, -150]                          # exact sum 50
    assert G.accumulate(seq, 8, G.AccPolicy.SATURATE).value == 127 - 150      # 200 -> 127, then -150
    assert G.accumulate(sorted(seq), 8, G.AccPolicy.SATURATE).value == -128 + 200  # -150 -> -128, then +200
    assert G.accumulate(seq, 8, G.AccPolicy.EXACT).value == 50


def test_gemm_policy_granularity():
    # per-MAC saturation clamps the prefix; per-chunk saturation sees the exact chunk sum
    a = [[127, 127, -128]]
    b = [[127], [127], [127]]
    exact = 127 * 127 * 2 - 128 * 127               # 16002, fits 15 bits; the prefix 32258 does not
    c_mac, f_mac = G.gemm_policy(a, b, 15, G.AccPolicy.SATURATE)
    c_chk, f_chk = G.gemm_policy(a, b, 15, G.AccPolicy.SATURATE, chunk=3)
    assert G.gemm(a, b) == [[exact]]
    assert f_mac[0][0] and c_mac[0][0] == 16383 - 128 * 127
    assert not f_chk[0][0] and c_chk[0][0] == exact
    c_w, f_w = G.gemm_policy(a, b, 15, G.AccPolicy.WRAP)
    assert f_w[0][0] and c_w[0][0] == exact          # wrap is a ring homomorphism: exact again


def test_output_tiles_cover_once():
    r = rng("tiles")
    for _ in range(200):
        m, n, tm, tn = r.randint(1, 40), r.randint(1, 40), r.randint(1, 9), r.randint(1, 9)
        for nmajor in (False, True):
            cov = {}
            for t in G.output_tiles(m, n, tm, tn, nmajor):
                assert 1 <= t.em <= tm and 1 <= t.en <= tn
                for i in range(t.m0, t.m0 + t.em):
                    for j in range(t.n0, t.n0 + t.en):
                        cov[(i, j)] = cov.get((i, j), 0) + 1
            assert len(cov) == m * n and set(cov.values()) == {1}


def test_k_chunks():
    assert G.k_chunks(257, 64) == [(0, 64), (64, 64), (128, 64), (192, 64), (256, 1)]
    assert G.k_chunks(1, 64) == [(0, 1)]
    assert sum(e for _, e in G.k_chunks(131071, 64)) == 131071 and len(G.k_chunks(131071, 64)) == 2048


def test_memory_leading_dimensions_roundtrip():
    r = rng("mem")
    mem = G.ByteMemory(fill=0xA5)
    a = rand_mat(r, 5, 7)
    mem.store_int8(0x1001, 11, a)                    # odd base, ld > n
    assert mem.load_int8(0x1001, 11, 5, 7) == a
    assert mem[0x1001 + 7] == 0xA5                   # the row gap is untouched
    c = [[r.randint(-(1 << 31), (1 << 31) - 1) for _ in range(3)] for _ in range(4)]
    mem.store_int32(0x2000, 20, c)
    assert mem.load_int32(0x2000, 20, 4, 3) == c
    b = rand_mat(r, 7, 3)
    mem.store_int8(0x3003, 5, b)
    assert G.gemm_from_memory(mem, 0x1001, 11, 0x3003, 5, 5, 3, 7) == G.gemm(a, b)


# =============================================================================== requantisation

def round_fraction(p: int, s: int, rm: int) -> int:
    """Third, textbook formulation: exact rational + mode definition."""
    v = Fraction(p, 1 << s)
    fl = v.numerator // v.denominator
    if v == fl:
        return fl
    if rm == Q.RM_RDN:
        return fl
    if rm == Q.RM_RUP:
        return fl + 1
    if rm == Q.RM_RTZ:
        return fl if v > 0 else fl + 1
    frac = v - fl
    if frac != Fraction(1, 2):
        return fl + (frac > Fraction(1, 2))
    if rm == Q.RM_RNE:
        return fl + (fl & 1)
    return fl + 1 if v > 0 else fl                    # RMM


def round_hw(p: int, s: int, rm: int) -> int:
    """The RTL's algorithm (TC05 doc §3.2): floor + increment from guard / sticky / sign / lsb."""
    if s == 0:
        return p
    fl = p >> s
    g = (p >> (s - 1)) & 1
    st = int((p & ((1 << (s - 1)) - 1)) != 0)
    neg, lsb = int(p < 0), fl & 1
    inc = {Q.RM_RNE: g & (st | lsb), Q.RM_RTZ: neg & (g | st), Q.RM_RDN: 0, Q.RM_RUP: g | st,
           Q.RM_RMM: g & (st | (1 - neg))}[rm]
    return fl + inc


def test_round_shift_exhaustive_three_ways():
    for s in range(0, 11):
        for p in range(-(1 << 11), (1 << 11) + 1):
            for rm in range(5):
                x = Q.round_shift(p, s, rm)
                assert x == round_fraction(p, s, rm) == round_hw(p, s, rm), (p, s, rm)


def test_round_shift_random_full_width():
    r = rng("round")
    for _ in range(20000):
        s = r.randint(0, 63)
        p = r.randint(-(1 << 104), 1 << 104)
        if r.random() < 0.4 and s > 0:              # force ties and ties +- 1
            p = (r.randint(-(1 << 60), 1 << 60) << s) + (1 << (s - 1)) + r.choice([-1, 0, 0, 1])
        rm = r.randint(0, 4)
        assert Q.round_shift(p, s, rm) == round_fraction(p, s, rm) == round_hw(p, s, rm)


def test_round_table_from_spec():
    # TC05 NUMERIC_FORMAT §3.2 table: v -> (RNE, RTZ, RDN, RUP, RMM)
    table = {Fraction(5, 2): (2, 2, 2, 3, 3), Fraction(7, 2): (4, 3, 3, 4, 4), Fraction(-5, 2): (-2, -2, -3, -2, -3),
             Fraction(-7, 2): (-4, -3, -4, -3, -4), Fraction(3, 4): (1, 0, 0, 1, 1), Fraction(-1, 4): (0, 0, -1, 0, 0)}
    for v, exp in table.items():
        p, s = v.numerator * (4 // v.denominator), 2
        assert tuple(Q.round_shift(p, s, rm) for rm in range(5)) == exp, v


def test_requant_spec_examples():
    P = Q.QParams
    assert Q.requant(777, P(mult=0, shift=5, zp=-3)) == (-3, False)
    assert Q.requant(5, P(mult=1, shift=1)) == (2, False)
    assert Q.requant(-5, P(mult=1, shift=1, rm=Q.RM_RMM)) == (-3, False)
    assert Q.requant(-(1 << 31), P(mult=-(1 << 31), shift=63)) == (0, False)
    assert Q.requant(1000, P(mult=1, shift=0)) == (127, True)
    assert Q.requant(-1000, P(mult=1, shift=0, zp=-10, relu=True)) == (-10, True)
    assert Q.requant(1, P(mult=-(1 << 31), shift=31)) == (-1, False)
    # INT32 pass-through / bias / wrap (TC05 modes)
    assert Q.requant((1 << 31) - 1, P(ofmt=Q.OFMT_INT32, rq=False), bias=1) == ((1 << 31) - 1, True)
    assert Q.requant((1 << 31) - 1, P(ofmt=Q.OFMT_INT32, rq=False, wrap=True), bias=1) == (-(1 << 31), True)


def test_relu_commutes_with_saturation():
    """max(clamp(y), zp) == clamp(max(y, zp)) whenever zp lies in the output range."""
    for zp in range(-128, 128, 7):
        for y in range(-400, 400, 3):
            assert max(min(max(y, -128), 127), zp) == min(max(max(y, zp), -128), 127)


def test_requant_vs_tc05_reference():
    tq = load_module("tq_ref", TC08 / "third_party" / "silicaflux-tensorcore05" / "model" / "tq_ref.py")
    r = rng("tq")
    for _ in range(5000):
        acc = r.randint(-(1 << 31), (1 << 31) - 1)
        mult = r.randint(-(1 << 31), (1 << 31) - 1)
        shift = r.randint(0, 63)
        zp = r.randint(-128, 127)
        rm = r.randint(0, 4)
        relu = r.random() < 0.3
        mine = Q.requant(acc, Q.QParams(mult=mult, shift=shift, zp=zp, rm=rm, relu=relu))
        q, sat = tq.element(acc, mult=mult, shift=shift, zp=zp, rq=True, ofmt=tq.OFMT_INT8, rm=rm, relu=relu)[:2]
        assert mine == (q, bool(sat)), (acc, mult, shift, zp, rm, relu)


# =============================================================================== TSU command model

def test_descriptor_encoding_spec_examples():
    # TC08 doc 02 §3 (three encodings published in the ABI document)
    g = T.Gemm(a=0x10000100, b=0x10000400, c=0x10001000, m=17, n=13, k=29, lda=29, ldb=13, ldc=60, tid=7,
               irq=True, prefetch=True)
    assert " ".join(f"{x:08x}" for x in g.words()) == \
        "07050240 10000100 10000400 10001000 000d0011 0000001d 0000001d 0000000d 0000003c 00000000 00000000 00000000"
    g = T.Gemm(a=0x10002000, b=0x10003000, c=0x10004001, m=9, n=11, k=40, lda=40, ldb=11, ldc=13, tid=8,
               out_int8=True, rm=0, relu=True, q_mult=0x5a82799a, q_shift=41, q_zp=-3 & 0xFF)
    assert " ".join(f"{x:08x}" for x in g.words()) == \
        "08000240 10002000 10003000 10004001 000b0009 00000028 00000028 0000000b 0000000d 00004010 5a82799a 0000fd29"
    assert " ".join(f"{x:08x}" for x in T.nop(tid=9, irq=True)) == \
        "09010200 " + " ".join(["00000000"] * 11)


def test_abi_constants_match_rtl_header():
    hdr = TC08 / "rtl" / "tsu_defs.svh"
    if not hdr.exists():
        pytest.skip("RTL not staged")
    defs = {}
    for line in hdr.read_text().splitlines():
        mt = re.match(r"`define\s+(TSU_\w+)\s+(\d+'h[0-9A-Fa-f_]+|\d+'d\d+|32'h[0-9A-Fa-f_]+|\d+)", line)
        if mt:
            v = mt.group(2).replace("_", "")
            defs[mt.group(1)] = int(v.split("'")[1][1:], 16 if "'h" in v else 10) if "'" in v else int(v)
    assert defs["TSU_OP_GEMM"] == T.OP_GEMM and defs["TSU_OP_NOP"] == T.OP_NOP
    for name, code in T.E_NAMES.items():
        if code != "NONE":
            assert defs[f"TSU_E_{code}"] == name, code
    for k in ("ID", "INFO", "CAPS", "CTRL", "STATUS", "SUBMITTED", "KMAX", "DESC0", "DOORBELL", "CPL0", "CPL_POP",
              "PERF0", "DMA_PERF0"):
        assert defs[f"TSU_R_{k}"] == getattr(T, f"R_{k}"), k
    for k, v in T.PC.items():
        assert defs[f"TSU_PC_{k}"] == v, k
    assert defs["TSU_ID_VALUE"] == T.ID_VALUE
    assert defs["TSU_W9_RSVD_MASK"] == T.W9_RSVD_MASK and defs["TSU_W11_RSVD_MASK"] == T.W11_RSVD_MASK


def _valid_then_mutate(r: random.Random, hw: T.HwConfig) -> list[int]:
    """A valid descriptor, then (usually) one field pushed across one rule boundary."""
    lo = hw.mem_lo
    out8 = hw.quant and r.random() < 0.4
    esz = 1 if out8 else 4
    m, n, k = r.randint(1, 30), r.randint(1, 30), r.randint(1, min(hw.k_max, 2000))
    g = T.Gemm(a=lo + r.randint(0, 64), b=lo + 0x40000 + r.randint(0, 64), c=lo + 0x80000 + 4 * r.randint(0, 16),
               m=m, n=n, k=k, lda=k + r.randint(0, 3), ldb=n + r.randint(0, 3), ldc=esz * n + 4 * r.randint(0, 2),
               kc=r.choice([0, r.randint(1, hw.tile_k)]), out_int8=out8, rm=r.randint(0, 4) if out8 else 0,
               relu=out8 and r.random() < 0.5, q_mult=r.randint(-99, 99) if out8 else 0,
               q_shift=r.randint(0, 63) if out8 else 0, prefetch=hw.dbuf and r.random() < 0.5)
    mut = r.randint(0, 14)
    if mut == 0:
        pass
    elif mut == 1:
        g = T.with_(g, k=hw.k_max + 1 if hw.k_max < 131071 else 0, lda=max(g.lda, hw.k_max + 1))
    elif mut == 2:
        g = T.with_(g, kc=hw.tile_k + 1)
    elif mut == 3:
        g = T.with_(g, lda=g.k - 1)
    elif mut == 4:
        g = T.with_(g, c=g.c + 1) if not out8 else T.with_(g, ldc=g.n - 1)
    elif mut == 5:
        g = T.with_(g, a=(1 << 32) - 2)
    elif mut == 6:
        g = T.with_(g, b=hw.mem_hi - 1)
    elif mut == 7:
        g = T.with_(g, c=g.a + 4 * r.randint(0, 3) & ~3)
    elif mut == 8:
        g = T.with_(g, m=0)
    elif mut == 9:
        g = T.with_(g, layouts=(0, 1, 0))
    elif mut == 10:
        g = T.with_(g, b_type=2)
    elif mut == 11:
        g = T.with_(g, rm=5, out_int8=True)
    elif mut == 12:
        g = T.with_(g, flags_raw=g.flags | 0x40)
    elif mut == 13:
        g = T.with_(g, version=3)
    else:
        g = T.with_(g, opcode=0x41)
    return g.words()


def _rand_desc(r: random.Random, hw: T.HwConfig) -> list[int]:
    """Random descriptor biased toward rule boundaries."""
    if r.random() < 0.5:
        return _valid_then_mutate(r, hw)
    lo, hi = hw.mem_lo, hw.mem_hi
    m, n, k = (r.choice([0, 1, 2, 5, 17, 65535, r.randint(1, 40)]) for _ in range(3))
    k = r.choice([k, hw.k_max, hw.k_max + 1, r.randint(1, 300)])
    out8 = r.random() < 0.3
    esz = 1 if out8 else 4
    g = T.Gemm(a=r.choice([lo, lo + r.randint(0, 4000), hi - 64, lo - 1, (1 << 32) - 16]),
               b=r.choice([lo + 0x8000, lo + r.randint(0, 9000), hi - 1]),
               c=r.choice([lo + 0x10000, lo + 0x10001, lo + r.randint(0, 9000) * 4, hi - 256]),
               m=m, n=n, k=k & 0x1FFFF,
               lda=r.choice([k, k - 1, k + r.randint(0, 9), 1 << 31]),
               ldb=r.choice([n, n - 1, n + 3, 1 << 30]),
               ldc=r.choice([n * esz, n * esz - 1, n * esz + 4, n * esz + 1]),
               kc=r.choice([0, 0, 1, hw.tile_k, hw.tile_k + 1, r.randint(1, 80)]),
               tid=r.randint(0, 255), out_int8=out8, rm=r.choice([0, 0, 0, 1, 4, 5, 7]),
               relu=r.random() < 0.2, q_mult=r.choice([0, 0, 12345, -7]), q_shift=r.choice([0, 3, 63]),
               q_zp=r.choice([0, 3, 0xFD]), prefetch=r.random() < 0.15, nmajor=r.random() < 0.2,
               version=r.choice([2] * 20 + [1, 3]), opcode=r.choice([0x40] * 20 + [0x00, 0x41, 0xFF]),
               a_type=r.choice([0] * 20 + [1]), ofmt_raw=r.choice([None] * 20 + [2, 3]),
               layouts=r.choice([(0, 0, 0)] * 20 + [(1, 0, 0), (0, 0, 2)]))
    w = g.words()
    if r.random() < 0.08:
        w[r.choice([0, 9, 11])] |= r.choice([1 << 15, 1 << 31, 1 << 6, 1 << 20])
    if r.random() < 0.05:
        w[0] |= r.choice([0x10, 0x80]) << 16
    w = [x & 0xFFFF_FFFF for x in w]
    w[4] = w[4] & 0xFFFF_FFFF
    w[5] = (w[5] & ~0x1FFFF) | (k & 0x1FFFF)
    return w


@pytest.mark.parametrize("cfg", ["base", "quant_dbuf", "tk16_kmax4096"])
def test_validate_vs_tc08_reference(cfg):
    ref = load_module("tsu_ref", TC08 / "model" / "tsu_ref.py")
    hw = {"base": T.HwConfig(), "quant_dbuf": T.HwConfig(quant=True, dbuf=True),
          "tk16_kmax4096": T.HwConfig(tile_k=16, k_max=4096)}[cfg]
    rhw = ref.HwCfg(tile_k=hw.tile_k, quant=int(hw.quant), dbuf=int(hw.dbuf), k_max=hw.k_max,
                    mem_lo=hw.mem_lo, mem_hi=hw.mem_hi)
    r = rng(f"val{cfg}")
    seen = {}
    for _ in range(30000):
        w = _rand_desc(r, hw)
        mine, theirs = T.validate(w, hw), ref.validate(w, rhw)
        assert mine == theirs, ([f"{x:08x}" for x in w], mine, theirs)
        seen[mine] = seen.get(mine, 0) + 1
    # every reachable rule is exercised by the fuzzer.  With K_MAX = 131071 (the 17-bit K field
    # maximum) rule 9 DIM_RANGE cannot be expressed in a descriptor at all.
    want = set(range(0, 16))
    if hw.k_max == 131071:
        want.discard(T.E_DIM_RANGE)
    missing = want - set(seen)
    assert not missing, f"rules never hit: {sorted(missing)}"


def test_validate_directed_boundaries():
    hw = T.HwConfig()
    lo = hw.mem_lo
    ok = T.Gemm(a=lo, b=lo + 0x1000, c=lo + 0x2000, m=4, n=4, k=4, lda=4, ldb=4, ldc=16)
    assert T.validate(ok.words(), hw) == T.E_NONE
    v = T.validate
    kmax = T.with_(ok, m=1, k=hw.k_max, lda=hw.k_max, b=lo + 0x20000, c=lo + 0xC0000)
    assert v(kmax.words(), hw) == T.E_NONE
    # K = 131072 does not fit the 17-bit field (it encodes as 0): with K_MAX = 131071 rule 9 is
    # unreachable; it is reachable only in a build with a smaller K_MAX
    assert v(T.with_(ok, k=(hw.k_max + 1) & 0x1FFFF).words(), hw) == T.E_DIM_ZERO
    hw_small = T.HwConfig(k_max=4096)
    assert v(T.with_(kmax, k=4097, lda=4097).words(), hw_small) == T.E_DIM_RANGE
    assert v(T.with_(kmax, k=4096, lda=4096).words(), hw_small) == T.E_NONE
    assert v(T.with_(ok, kc=64).words(), hw) == T.E_NONE and v(T.with_(ok, kc=65).words(), hw) == T.E_CHUNK
    assert v(T.with_(ok, lda=3).words(), hw) == T.E_LD and v(T.with_(ok, ldc=15).words(), hw) == T.E_LD
    assert v(T.with_(ok, ldc=20, c=lo + 0x2002).words(), hw) == T.E_ALIGN
    # last byte exactly at MEM_HI - 1 is legal, at MEM_HI it is RANGE
    last_ok = T.with_(ok, c=hw.mem_hi - 64, ldc=16)
    assert v(last_ok.words(), hw) == T.E_NONE
    assert v(T.with_(ok, c=hw.mem_hi - 60, ldc=16).words(), hw) == T.E_RANGE
    assert v(T.with_(ok, a=lo - 1).words(), hw) == T.E_RANGE
    assert v(T.with_(ok, a=(1 << 32) - 8, lda=4).words(), hw) == T.E_ADDR_OVF
    assert v(T.with_(ok, c=lo + 0x1000 + 12, ldc=16).words(), hw) == T.E_ALIAS
    assert v(T.with_(ok, out_int8=True).words(), hw) == T.E_PRECISION        # no quantiser in this build
    assert v(T.with_(ok, out_int8=True).words(), T.HwConfig(quant=True)) == T.E_NONE
    assert v(T.with_(ok, prefetch=True).words(), hw) == T.E_FLAGS
    assert v(T.with_(ok, relu=True).words(), hw) == T.E_RSVD
    assert v(T.with_(ok, m=0).words(), hw) == T.E_DIM_ZERO


def test_schedule_and_traffic_vs_tc08_reference():
    ref = load_module("tsu_ref", TC08 / "model" / "tsu_ref.py")
    r = rng("sched")
    for _ in range(300):
        hw = T.HwConfig(rows=r.choice([2, 4, 8]), cols=r.choice([2, 4, 8]), tile_k=r.choice([16, 64]))
        m, n, k = r.randint(1, 40), r.randint(1, 40), r.randint(1, 300)
        g = T.Gemm(a=hw.mem_lo + r.randint(0, 99), b=hw.mem_lo + 0x8000 + r.randint(0, 99),
                   c=hw.mem_lo + 0x20000, m=m, n=n, k=k, lda=k + r.randint(0, 5), ldb=n + r.randint(0, 5),
                   ldc=4 * n + 4 * r.randint(0, 3), kc=r.choice([0, r.randint(1, hw.tile_k)]),
                   nmajor=r.random() < 0.5)
        rg = ref.Gemm(a=g.a, b=g.b, c=g.c, m=m, n=n, k=k, lda=g.lda, ldb=g.ldb, ldc=g.ldc, kc=g.kc,
                      flags=g.flags)
        rhw = ref.HwCfg(rows=hw.rows, cols=hw.cols, tile_k=hw.tile_k)
        mine = [(s.m0, s.n0, s.k0, s.em, s.en, s.ek, s.last_k) for s in T.schedule(g, hw)]
        assert mine == [tuple(x) for x in ref.schedule(rg, rhw)]
    for ek in range(1, 200):
        assert T.lda_loc(ek) == ref.lda_loc(ek)
        assert T.lda_loc(ek) >= ek and T.lda_loc(ek) % 8 == 4


def test_traffic_words_cover_exactly_the_operands():
    """Every SFB2 read word holds at least one operand byte; every operand byte is read."""
    hw = T.HwConfig()
    r = rng("traffic")
    for _ in range(40):
        m, n, k = r.randint(1, 20), r.randint(1, 20), r.randint(1, 150)
        g = T.Gemm(a=hw.mem_lo + r.randint(0, 50), b=hw.mem_lo + 0x8000 + r.randint(0, 50),
                   c=hw.mem_lo + 0x20000 + 4 * r.randint(0, 9), m=m, n=n, k=k, lda=k + r.randint(0, 9),
                   ldb=n + r.randint(0, 9), ldc=4 * n + 4 * r.randint(0, 2))
        a_fp = G.footprint(g.a, g.lda, m, k)
        b_fp = G.footprint(g.b, g.ldb, k, n)
        words = {wa for wa, _ in T.read_words(g, hw)}
        assert all(any(wa + i in a_fp | b_fp for i in range(4)) for wa in words)
        assert {x & ~3 for x in a_fp | b_fp} == words
        wr = T.write_words(g, hw)
        assert sum(bin(st).count("1") for _, st, _, _ in wr) == m * n * 4
        cnt = T.counters(g, hw)
        assert cnt["MACS"] == m * n * k


def test_expected_outcome_write_error_prefix():
    hw = T.HwConfig()
    lo = hw.mem_lo
    mem = G.ByteMemory()
    r = rng("oute")
    g = T.Gemm(a=lo, b=lo + 0x1000, c=lo + 0x2000, m=9, n=5, k=7, lda=7, ldb=5, ldc=20)
    mem.store_int8(g.a, g.lda, rand_mat(r, 9, 7))
    mem.store_int8(g.b, g.ldb, rand_mat(r, 7, 5))
    wr = T.write_words(g, hw)
    wa, st, t, bb = wr[13]
    o = T.expected_outcome(g.words(), g, hw, mem, [T.Poison(wa, wa + 4, write=True)])
    assert o.err == T.E_DMA_WRITE and o.err_addr == wa and o.tiles == t
    assert o.count == sum(T.tile_bytes(g, hw)[:t]) + bb
    ok = T.expected_outcome(g.words(), g, hw, mem)
    assert ok.status == T.ST_OK and ok.count == 9 * 5 * 4 and ok.tiles == 6
    with pytest.raises(ValueError):
        T.expected_outcome(g.words(), g, hw, mem, [T.Poison(lo, lo + 0x3000, read=True, write=True)])
