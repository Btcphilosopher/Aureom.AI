// =============================================================================
// SilicaFlux TENSORCORE 09 :: tb_array -- cocotb wrapper of the systolic array
// DUT: TENSORCORE 02 tensor_systolic_array (as integrated in TC08), unmodified.
//
// Assertions
//   chk_pe per PE (g_pe[i].g_pj[j].chk): operand pairing, k sequence 0..K-1,
//      MAC exactness, no MAC after the last one, orphan tokens, clear
//   chk_m (chk_handshake): result stream payload stable under m_ready backpressure
//   chk_rst (chk_reset): no slice accepted / result presented in reset
//   chk_arr (this module, always block):
//     Y1 slices accepted per tile <= K, and == K when the readout starts
//     Y2 no result before final accumulation: at READOUT entry every active PE
//        is done and committed exactly K MACs; inactive (padding) PEs committed 0
//     Y3 accumulators frozen during READOUT
//     Y4 m_data lane j == accumulator of PE(m_row, j) (0 outside the column mask)
//     Y5 rows streamed in order 0..M-1, m_last on row M-1, exactly M beats
//     Y6 tile_done == m_valid; busy outside IDLE
// =============================================================================
`timescale 1ns/1ps
`include "chk_defs.svh"
`default_nettype none
module tb_array #(
  parameter int ARRAY_ROWS  = 2,
  parameter int ARRAY_COLS  = 2,
  parameter int DATA_WIDTH  = 8,
  parameter int ACC_WIDTH   = 32,
  parameter int K_WIDTH     = 17,
  parameter int MUL_PIPE    = 0,
  parameter int CHECK_ALIGN = 1,
  parameter int PERF_EN     = 1,
  localparam int RIDW = (ARRAY_ROWS > 1) ? $clog2(ARRAY_ROWS) : 1,
  localparam int NPE  = ARRAY_ROWS * ARRAY_COLS
) (
  input  wire logic                             clk,
  input  wire logic                             rst_n,
  input  wire logic                             cfg_valid,
  output logic                                  cfg_ready,
  input  wire logic [$clog2(ARRAY_ROWS+1)-1:0]  cfg_m,
  input  wire logic [$clog2(ARRAY_COLS+1)-1:0]  cfg_n,
  input  wire logic [K_WIDTH-1:0]               cfg_k,
  output logic                                  cfg_reject,
  input  wire logic                             s_valid,
  output logic                                  s_ready,
  input  wire logic [ARRAY_ROWS*DATA_WIDTH-1:0] s_a,
  input  wire logic [ARRAY_COLS*DATA_WIDTH-1:0] s_b,
  output logic [K_WIDTH-1:0]                    s_k,
  input  wire logic                             stall_i,
  output logic                                  m_valid,
  input  wire logic                             m_ready,
  output logic [RIDW-1:0]                       m_row,
  output logic [ARRAY_COLS*ACC_WIDTH-1:0]       m_data,
  output logic [ARRAY_COLS-1:0]                 m_col_mask,
  output logic                                  m_last,
  output logic                                  busy,
  output logic                                  tile_done,
  output logic                                  align_err,
  output logic [39:0]                           perf_busy, perf_issue, perf_stall_up, perf_stall_ext,
  output logic [39:0]                           perf_mac, perf_pad
);
  tensor_systolic_array #(.ARRAY_ROWS(ARRAY_ROWS), .ARRAY_COLS(ARRAY_COLS), .DATA_WIDTH(DATA_WIDTH),
    .ACC_WIDTH(ACC_WIDTH), .K_WIDTH(K_WIDTH), .MUL_PIPE(MUL_PIPE), .CHECK_ALIGN(CHECK_ALIGN), .PERF_EN(PERF_EN)
  ) dut (.*);

  localparam int AWB = ARRAY_COLS + 1;
  logic [NPE*32-1:0] commits_flat;
  logic              chk_off = 1'b0;            // cocotb sets it only in fault-injection tests

  for (genvar i = 0; i < ARRAY_ROWS; i++) begin : g_pe
    for (genvar j = 0; j < ARRAY_COLS; j++) begin : g_pj
      localparam int AI = i * AWB + j;
      localparam int BI = i * ARRAY_COLS + j;
      localparam int PI = i * ARRAY_COLS + j;
      integer cm, lcm;
      chk_pe #(.DATA_WIDTH(DATA_WIDTH), .ACC_WIDTH(ACC_WIDTH), .KIDX_WIDTH(K_WIDTH), .MUL_PIPE(MUL_PIPE),
               .CHECK_KSEQ(1'b1)) chk (
        .clk(clk), .rst_n(rst_n), .clr(dut.clr_c), .en(dut.pipe_en),
        .chk_en(dut.row_mask_q[i] & dut.col_mask_q[j]), .chk_off(chk_off),
        .a_valid_i(dut.a_valid_bus[AI]), .a_last_i(dut.a_last_bus[AI]),
        .a_data_i(dut.a_data_bus[AI*DATA_WIDTH +: DATA_WIDTH]), .a_kidx_i(dut.a_kidx_bus[AI*K_WIDTH +: K_WIDTH]),
        .b_valid_i(dut.b_valid_bus[BI]), .b_last_i(dut.b_last_bus[BI]),
        .b_data_i(dut.b_data_bus[BI*DATA_WIDTH +: DATA_WIDTH]), .b_kidx_i(dut.b_kidx_bus[BI*K_WIDTH +: K_WIDTH]),
        .a_valid_o(dut.a_valid_bus[AI+1]), .b_valid_o(dut.b_valid_bus[BI+ARRAY_COLS]),
        .acc_o(dut.acc_flat[PI*ACC_WIDTH +: ACC_WIDTH]), .done_o(dut.done_flat[PI]),
        .fire_o(dut.fire_flat[PI]), .commit_o(dut.commit_flat[PI]), .commits(cm), .last_commits(lcm));
      assign commits_flat[PI*32 +: 32] = cm;
    end
  end

  chk_handshake #(.W(RIDW + ARRAY_COLS*ACC_WIDTH + ARRAY_COLS + 1)) chk_m (
    .clk(clk), .rst_n(rst_n), .valid(m_valid), .ready(m_ready), .data({m_row, m_data, m_col_mask, m_last}));
  chk_reset #(.N(3), .NK(5)) chk_rst (.clk(clk), .rst_n(rst_n), .quiet({s_ready, m_valid, tile_done}),
                                      .known({s_ready, m_valid, busy, cfg_ready, align_err}));

  // ------------------------------------------------------------------ array-level checker
  chk_array_core #(.R(ARRAY_ROWS), .C(ARRAY_COLS), .ACC(ACC_WIDTH), .KW(K_WIDTH), .RIDW(RIDW)) chk_arr (
    .clk(clk), .rst_n(rst_n), .cfg_go(dut.cfg_go), .cfg_m(32'(cfg_m)), .cfg_n(32'(cfg_n)), .cfg_k(32'(cfg_k)),
    .s_go(s_valid && s_ready), .m_valid(m_valid), .m_ready(m_ready), .m_row(m_row), .m_data(m_data),
    .m_last(m_last), .tile_done(tile_done), .busy(busy), .idle(dut.state_q == 3'd0),
    .acc_flat(dut.acc_flat), .done_flat(dut.done_flat), .commits_flat(commits_flat));
endmodule

module chk_array_core #(
  parameter int R = 2, C = 2, ACC = 32, KW = 17, RIDW = 1
) (
  input wire logic                 clk, rst_n, cfg_go,
  input wire logic [31:0]          cfg_m, cfg_n, cfg_k,
  input wire logic                 s_go, m_valid, m_ready,
  input wire logic [RIDW-1:0]      m_row,
  input wire logic [C*ACC-1:0]     m_data,
  input wire logic                 m_last, tile_done, busy, idle,
  input wire logic [R*C*ACC-1:0]   acc_flat,
  input wire logic [R*C-1:0]       done_flat,
  input wire logic [R*C*32-1:0]    commits_flat
);
  `CHK_DECL
  integer m_q = 0, n_q = 0, k_q = 0, slices = 0, beats = 0, tiles = 0;
  logic   in_ro = 1'b0;
  logic [R*C*ACC-1:0] snap;
  always @(posedge clk) begin
    if (!rst_n) begin
      slices = 0; beats = 0; in_ro <= 1'b0;
    end else begin
      `CHK(tile_done == m_valid, ("Y6 tile_done %b != m_valid %b", tile_done, m_valid))
      `CHK(busy == !idle, ("Y6 busy %b outside IDLE", busy))
      if (s_go) begin
        slices = slices + 1;
        `CHK(slices <= k_q, ("Y1 slice %0d accepted for K=%0d", slices, k_q))
      end
      if (m_valid && !in_ro) begin                          // READOUT entry
        `CHK(slices == k_q, ("Y2 readout after %0d of %0d slices", slices, k_q))
        for (int i = 0; i < R; i++)
          for (int j = 0; j < C; j++) begin
            if (i < m_q && j < n_q) begin
              `CHK(done_flat[i*C+j] && 32'(commits_flat[(i*C+j)*32 +: 32]) == k_q,
                   ("Y2 PE(%0d,%0d) done=%b commits=%0d at readout, K=%0d", i, j, done_flat[i*C+j],
                    commits_flat[(i*C+j)*32 +: 32], k_q))
            end else begin
              `CHK(commits_flat[(i*C+j)*32 +: 32] == 0, ("Y2 padding PE(%0d,%0d) committed %0d MACs", i, j,
                                                           commits_flat[(i*C+j)*32 +: 32]))
            end
          end
        snap = acc_flat;
        beats = 0;
      end
      if (m_valid) begin
        `CHK(acc_flat === snap, ("Y3 accumulators changed during READOUT"))
        `CHK(32'(m_row) == beats, ("Y5 row %0d streamed, expected %0d", m_row, beats))
        `CHK(m_last == (32'(m_row) == m_q - 1), ("Y5 m_last=%b on row %0d of %0d", m_last, m_row, m_q))
        for (int j = 0; j < C; j++)
          `CHK(m_data[j*ACC +: ACC] === ((j < n_q) ? acc_flat[(32'(m_row)*C + j)*ACC +: ACC] : {ACC{1'b0}}),
               ("Y4 m_data lane %0d row %0d", j, m_row))
        if (m_ready) beats = beats + 1;
        if (m_ready && m_last) begin
          `CHK(beats == m_q, ("Y5 %0d beats for M=%0d", beats, m_q))
          tiles = tiles + 1;
        end
      end
      in_ro <= m_valid && !(m_ready && m_last);
      if (cfg_go) begin
        m_q = cfg_m; n_q = cfg_n; k_q = cfg_k; slices = 0;
      end
    end
  end
endmodule
`default_nettype wire
