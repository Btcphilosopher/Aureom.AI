"""Systolic array verification: TENSORCORE 02 tensor_systolic_array.

Brief order: the 2x2 array first, then every shape up to the integrated 8x8.

Scoreboards / monitors (Python):
  * result scoreboard  every row of every tile vs the exact reference GEMM
  * wavefront monitor  every enabled cycle, every PE input: the A token must be
                       A[i][k] and the B token B[k][j] with k = e - 1 - i - j
                       (e = enabled cycles since the tile started), valid exactly
                       for 0 <= k < K inside the active M x N region, all-zero
                       (valid, data, k, last) everywhere else -> operand skew,
                       wavefront propagation, K alignment, padding
  * timing             all active PEs done after exactly K + M + N - 1 + MUL_PIPE
                       enabled cycles (pipeline fill + drain), busy-cycle identity
                       busy = 1 + K + M + N + MUL_PIPE + stall cycles
  * perf counters      MACs = M*N*K, slices = K, padding slots = (R*C - M*N)*K
SV assertions (tb_array.sv): per-PE pairing / MAC exactness / no duplicate MAC,
no result before every active PE committed exactly K MACs, padding PEs commit
nothing, accumulators frozen in READOUT, payload stable under backpressure, reset.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
try:
    import cocotb
    from cocotb.triggers import ClockCycles
    from common.harness import tensor_test, FallingEdge, RisingEdge, ReadOnly, PARAMS, pick, full, corner_bin
except ImportError:
    tensor_test = None

from reference_models.gemm_ref import gemm, wrap  # noqa: E402

R = int(PARAMS.get("ARRAY_ROWS", 2))
C = int(PARAMS.get("ARRAY_COLS", 2))
DW = int(PARAMS.get("DATA_WIDTH", 8))
AW = int(PARAMS.get("ACC_WIDTH", 32))
KW = int(PARAMS.get("K_WIDTH", 17))
MP = int(PARAMS.get("MUL_PIPE", 0))
LO, HI = -(1 << (DW - 1)), (1 << (DW - 1)) - 1
MASK = (1 << DW) - 1
KMAX = (1 << KW) - 1


def checkers(dut):
    return ["chk_m", "chk_rst", "chk_arr"] + [f"g_pe[{i}].g_pj[{j}].chk" for i in range(R) for j in range(C)]


def pack(vals, w):
    x = 0
    for i, v in enumerate(vals):
        x |= (v & ((1 << w) - 1)) << (i * w)
    return x


def field(x, i, w):
    return (x >> (i * w)) & ((1 << w) - 1)


def sfield(x, i, w):
    v = field(x, i, w)
    return v - (1 << w) if v >> (w - 1) else v


def kbin(k):
    for lim, name in ((1, "1"), (4, "2-4"), (16, "5-16"), (64, "17-64"), (256, "65-256"), (4096, "257-4096")):
        if k <= lim:
            return name
    return ">4096"


class Array:
    def __init__(self, dut, rng, cov):
        self.dut, self.rng, self.cov = dut, rng, cov
        self.gap_p, self.stall_p, self.bp_p = 0.0, 0.0, 0.0
        self.wave = True
        self.wave_now = True
        self.tiles = 0
        self.stall_cycles = 0
        dut.cfg_valid.value = 0
        dut.s_valid.value = 0
        dut.stall_i.value = 0
        dut.m_ready.value = 1
        dut.s_a.value = 0
        dut.s_b.value = 0
        dut.cfg_m.value = 0
        dut.cfg_n.value = 0
        dut.cfg_k.value = 0

    async def reset(self, n=3):
        d = self.dut
        await FallingEdge(d.clk)
        d.rst_n.value = 0
        for _ in range(n):
            await FallingEdge(d.clk)
        d.rst_n.value = 1
        await FallingEdge(d.clk)

    # ------------------------------------------------------------------ drivers
    async def _stall_driver(self, stop):
        d = self.dut
        while not stop[0]:
            s = int(self.rng.random() < self.stall_p)
            d.stall_i.value = s
            await FallingEdge(d.clk)
        d.stall_i.value = 0

    async def _slices(self, A, B, m, n, k):
        d = self.dut
        kk = 0
        while kk < k:
            if self.rng.random() < self.gap_p:
                d.s_valid.value = 0
                self.cov.hit("stim", "slice_gap")
            else:
                # live lanes carry A[:,k] / B[k,:]; dead lanes carry garbage that the array must mask
                av = [A[i][kk] if i < m else self.rng.randint(LO, HI) for i in range(R)]
                bv = [B[kk][j] if j < n else self.rng.randint(LO, HI) for j in range(C)]
                d.s_a.value = pack(av, DW)
                d.s_b.value = pack(bv, DW)
                d.s_valid.value = 1
            await RisingEdge(d.clk)
            if int(d.s_valid.value) and int(d.s_ready.value):
                assert int(d.s_k.value) == kk, f"s_k {int(d.s_k.value)} != {kk}"
                kk += 1
            await FallingEdge(d.clk)
        d.s_valid.value = 0

    async def _collect(self, m, rows):
        d = self.dut
        while True:
            d.m_ready.value = int(self.rng.random() >= self.bp_p)
            await RisingEdge(d.clk)
            if int(d.m_valid.value) and int(d.m_ready.value):
                r = int(d.m_row.value)
                data = int(d.m_data.value)
                rows[r] = [sfield(data, j, AW) for j in range(C)]
                if int(d.m_last.value):
                    await FallingEdge(d.clk)
                    d.m_ready.value = 1
                    return
            elif int(d.m_valid.value):
                self.cov.hit("stim", "readout_backpressure")
            await FallingEdge(d.clk)

    async def _wavefront(self, A, B, m, n, k, stop, res):
        """Every PE input on every cycle of RUN / DRAIN vs the skew formula."""
        d = self.dut.dut
        AWB = C + 1
        e = 0
        done_at = None
        while not stop[0]:
            await RisingEdge(self.dut.clk)
            st = int(d.state_q.value)
            if st not in (2, 3):
                if st == 4 and done_at is None:
                    done_at = e
                continue
            if self.wave_now:
                av, ad, ak = int(d.a_valid_bus.value), int(d.a_data_bus.value), int(d.a_kidx_bus.value)
                bv, bd, bk = int(d.b_valid_bus.value), int(d.b_data_bus.value), int(d.b_kidx_bus.value)
                al, bl = int(d.a_last_bus.value), int(d.b_last_bus.value)
                for i in range(R):
                    for j in range(C):
                        kk = e - 1 - i - j
                        ai, bi = i * AWB + j, i * C + j
                        ea = i < m and 0 <= kk < k
                        eb = j < n and 0 <= kk < k
                        got = (field(av, ai, 1), sfield(ad, ai, DW), field(ak, ai, KW), field(al, ai, 1),
                               field(bv, bi, 1), sfield(bd, bi, DW), field(bk, bi, KW), field(bl, bi, 1))
                        exp = (int(ea), A[i][kk] if ea else 0, kk if ea else 0, int(ea and kk == k - 1),
                               int(eb), B[kk][j] if eb else 0, kk if eb else 0, int(eb and kk == k - 1))
                        assert got == exp, (f"wavefront e={e} PE({i},{j}) k={kk}: got (aV,aD,aK,aL,bV,bD,bK,bL)="
                                            f"{got} expected {exp}")
            # all active PEs done -> record the enabled-cycle count (fill + drain latency)
            done = int(d.done_flat.value)
            act = all((done >> (i * C + j)) & 1 for i in range(m) for j in range(n))
            if act and res.get("done_e") is None:
                res["done_e"] = e
            if int(d.pipe_en.value):
                e += 1
            elif int(d.stall_i.value):
                self.stall_cycles += 1
        res["e"] = e

    # ------------------------------------------------------------------ one tile
    async def tile(self, A, B, m=None, n=None, k=None, check=True):
        d = self.dut
        m = m if m is not None else len(A)
        k = k if k is not None else len(B)
        n = n if n is not None else len(B[0])
        # cfg handshake
        d.cfg_m.value, d.cfg_n.value, d.cfg_k.value = m, n, k
        d.cfg_valid.value = 1
        while True:
            await RisingEdge(d.clk)
            if int(d.cfg_ready.value):
                break
            await FallingEdge(d.clk)
        await FallingEdge(d.clk)
        d.cfg_valid.value = 0
        stop = [False]
        res = {}
        rows = {}
        # the Python wavefront check is O(R*C) per cycle: on arrays above 4x4 at quick level it samples
        # every third tile (full level: every tile); the SV per-PE checkers run on every cycle regardless
        self.wave_now = self.wave and (full() or R * C <= 16 or self.tiles % 3 == 0)
        if self.wave_now:
            self.cov.hit("wavefront", "checked")
        st = cocotb.start_soon(self._stall_driver(stop))
        wv = cocotb.start_soon(self._wavefront(A, B, m, n, k, stop, res))
        col = cocotb.start_soon(self._collect(m, rows))
        await self._slices(A, B, m, n, k)
        await col
        # read the per-tile performance counters (stable once the tile reached READOUT)
        stop[0] = True
        await st
        await wv
        perf = {x: int(getattr(d, f"perf_{x}").value) for x in ("busy", "issue", "stall_up", "stall_ext", "mac",
                                                                 "pad")}
        self.tiles += 1
        assert int(d.align_err.value) == 0
        if check:
            exp = gemm([r[:k] for r in A[:m]], [r[:n] for r in B[:k]])
            for i in range(m):
                assert i in rows, f"row {i} never streamed"
                got = rows[i][:n]
                assert got == [wrap(v, AW) for v in exp[i]], f"row {i}: {got} != {exp[i]}"
                assert rows[i][n:] == [0] * (C - n), f"row {i} lanes beyond N not zero: {rows[i]}"
            assert sorted(rows) == list(range(m))
            assert res.get("done_e") == k + m + n - 1 + MP, \
                f"fill+drain: active PEs done after {res.get('done_e')} enabled cycles, expected {k + m + n - 1 + MP}"
            if int(PARAMS.get("PERF_EN", 1)):
                assert perf["issue"] == k and perf["mac"] == m * n * k and perf["pad"] == (R * C - m * n) * k, perf
                assert perf["busy"] == 1 + k + m + n + MP + perf["stall_up"] + perf["stall_ext"], perf
            self.cov.hit("shape", f"{m}x{n}")
            self.cov.hit("k", kbin(k))
        return rows

    def rand_tile(self, m, n, k, mode="random"):
        g = self.rng
        if mode == "max":
            return [[HI] * k for _ in range(m)], [[HI] * n for _ in range(k)]
        if mode == "min":
            return [[LO] * k for _ in range(m)], [[LO] * n for _ in range(k)]
        if mode == "mixed":
            return ([[g.choice([LO, HI]) for _ in range(k)] for _ in range(m)],
                    [[g.choice([LO, HI]) for _ in range(n)] for _ in range(k)])
        if mode == "zero":
            return [[0] * k for _ in range(m)], [[g.randint(LO, HI) for _ in range(n)] for _ in range(k)]
        return ([[g.randint(LO, HI) for _ in range(k)] for _ in range(m)],
                [[g.randint(LO, HI) for _ in range(n)] for _ in range(k)])


def define_cov(cov):
    cov.define("shape", [f"{m}x{n}" for m in range(1, R + 1) for n in range(1, C + 1)])
    cov.define("k", ["1", "2-4", "5-16", "17-64", "65-256", "257-4096"])
    cov.define("stim", ["slice_gap", "readout_backpressure"])


if tensor_test is not None:

    async def setup(dut, rng, cov):
        define_cov(cov)
        a = Array(dut, rng, cov)
        await a.reset()
        return a

    @tensor_test(checkers=checkers)
    async def directed_values(dut, rng, cov):
        """Zero, identity-like, maximum positive, maximum negative, mixed extremes, K sweep."""
        a = await setup(dut, rng, cov)
        for k in (1, 2, 3, 4, 7, 16):
            for mode in ("zero", "max", "min", "mixed", "random"):
                A, B = a.rand_tile(R, C, k, mode)
                await a.tile(A, B)
                cov.hit("values", mode)
        # identity-like: A = I (K = R), B = I (K = C), negated and permuted identities
        for k in (R, C):
            I = [[int(i == j) for j in range(k)] for i in range(k)]
            A, B = a.rand_tile(R, C, k)
            await a.tile(I[:R] if k == R else [r[:k] for r in A], B if k == R else I[:k])
            negI = [[-int(i == j) for j in range(k)] for i in range(k)]
            if k == R:
                await a.tile(negI, B)
            perm = [[int(j == (i + 1) % k) for j in range(k)] for i in range(k)]
            if k == C:
                await a.tile(A, perm)
        cov.hit("values", "identity")

    @tensor_test(checkers=checkers)
    async def all_partial_shapes(dut, rng, cov):
        """Every M x N with 1 <= M <= ROWS, 1 <= N <= COLS (partial tiles at every edge)."""
        a = await setup(dut, rng, cov)
        for m in range(1, R + 1):
            for n in range(1, C + 1):
                k = rng.choice([1, 2, 5, rng.randint(1, 40)])
                A, B = a.rand_tile(m, n, k)
                await a.tile(A, B, m, n, k)

    @tensor_test(checkers=checkers)
    async def random_tiles_stalls_backpressure(dut, rng, cov):
        """Random shapes / K with upstream gaps, global stalls in RUN and DRAIN, readout backpressure."""
        a = await setup(dut, rng, cov)
        for t in range(pick(25, 200)):
            a.gap_p = rng.choice([0, 0.1, 0.5])
            a.stall_p = rng.choice([0, 0.1, 0.3])
            a.bp_p = rng.choice([0, 0.3, 0.7])
            m, n = rng.randint(1, R), rng.randint(1, C)
            k = rng.choice([1, rng.randint(1, 20), rng.randint(20, 150)])
            A, B = a.rand_tile(m, n, k, rng.choice(["random", "random", "mixed"]))
            await a.tile(A, B, m, n, k)
        assert a.stall_cycles > 0

    @tensor_test(checkers=checkers)
    async def long_k_reduction(dut, rng, cov):
        """Long reductions: K = 1000 / 4096 random, and the INT32 limit K = 131071 of
        (-128)(-128) (full level, on the 2x2 array), cancellation over long K."""
        a = await setup(dut, rng, cov)
        a.wave = False                                   # wavefront monitor is O(K*R*C); results + SV checks stay
        for k in pick((1000,), (1000, 4096)):
            k = min(k, KMAX)                             # cfg_k is K_WIDTH bits wide
            A, B = a.rand_tile(R, C, k)
            await a.tile(A, B)
        k = min(pick(2000, 6000), KMAX & ~1)             # even: the cancellation pairs (k, k+1)
        A = [[rng.randint(LO, HI) for _ in range(k)] for _ in range(R)]
        B = [[(-1) ** (kk & 1) * 100 if j == 0 else rng.randint(LO, HI) for j in range(C)] for kk in range(k)]
        A2 = [[A[i][kk - (kk & 1)] for kk in range(k)] for i in range(R)]   # pairs cancel exactly in column 0
        rows = await a.tile(A2, B)
        assert all(rows[i][0] == 0 for i in range(R))
        cov.hit("values", "cancellation")
        if full() and R * C <= 4 and DW == 8 and AW == 32 and KW >= 17:
            k = KMAX
            A = [[LO] * k for _ in range(R)]
            B = [[LO] * C for _ in range(k)]
            rows = await a.tile(A, B)
            assert rows[0][0] == k * 16384 == 2147467264
            cov.hit("k", "131071")

    @tensor_test(checkers=checkers)
    async def back_to_back_tiles(dut, rng, cov):
        """Consecutive tiles with no idle cycle in between: no stale token, no MAC of the previous
        tile reaches the next one (launch flush), every MAC exactly once."""
        a = await setup(dut, rng, cov)
        for t in range(pick(20, 100)):
            m, n, k = rng.randint(1, R), rng.randint(1, C), rng.randint(1, 30)
            A, B = a.rand_tile(m, n, k)
            await a.tile(A, B, m, n, k)

    @tensor_test(checkers=checkers)
    async def illegal_configuration(dut, rng, cov):
        """M = 0, N = 0, K = 0 (and M > ROWS / N > COLS where the field can express it) are
        consumed with a one-cycle cfg_reject and leave the array idle; a legal tile follows."""
        a = await setup(dut, rng, cov)
        d = dut
        bad = [(0, 1, 1), (1, 0, 1), (1, 1, 0)]
        if R + 1 < (1 << len(d.cfg_m)):
            bad.append((R + 1, 1, 1))
        if C + 1 < (1 << len(d.cfg_n)):
            bad.append((1, C + 1, 1))
        for m, n, k in bad:
            d.cfg_m.value, d.cfg_n.value, d.cfg_k.value, d.cfg_valid.value = m, n, k, 1
            await RisingEdge(d.clk)
            assert int(d.cfg_ready.value) == 1
            await FallingEdge(d.clk)
            d.cfg_valid.value = 0
            await RisingEdge(d.clk)
            assert int(d.cfg_reject.value) == 1 and int(d.busy.value) == 0, (m, n, k)
            await FallingEdge(d.clk)
            await RisingEdge(d.clk)
            assert int(d.cfg_reject.value) == 0
            await FallingEdge(d.clk)
            cov.hit("illegal", f"{'M' if m == 0 else 'N' if n == 0 else 'K' if k == 0 else 'big'}")
        A, B = a.rand_tile(R, C, 5)
        await a.tile(A, B)

    @tensor_test(checkers=checkers)
    async def reset_during_tile(dut, rng, cov):
        """Hard reset in RUN (tokens in flight), DRAIN and READOUT; the next tiles are exact and
        the counters / flags restart clean."""
        a = await setup(dut, rng, cov)
        d = dut
        for phase, target in (("run", 2), ("drain", 3), ("readout", 4)):
            m, n, k = R, C, 12
            A, B = a.rand_tile(m, n, k)
            d.cfg_m.value, d.cfg_n.value, d.cfg_k.value, d.cfg_valid.value = m, n, k, 1
            await RisingEdge(d.clk)
            await FallingEdge(d.clk)
            d.cfg_valid.value = 0
            kk = 0
            d.m_ready.value = 0
            for _ in range(400):
                st = int(d.dut.state_q.value)
                if st == target and (target != 2 or kk >= 3):
                    break
                if kk < k:
                    d.s_a.value = pack([A[i][kk] for i in range(R)], DW)
                    d.s_b.value = pack([B[kk][j] for j in range(C)], DW)
                    d.s_valid.value = 1
                await RisingEdge(d.clk)
                if int(d.s_valid.value) and int(d.s_ready.value):
                    kk += 1
                await FallingEdge(d.clk)
                if kk >= k:
                    d.s_valid.value = 0
            assert int(d.dut.state_q.value) == target, phase
            d.s_valid.value = 0
            d.rst_n.value = 0
            await ClockCycles(d.clk, 2, rising=False)
            d.rst_n.value = 1
            d.m_ready.value = 1
            await FallingEdge(d.clk)
            assert int(d.busy.value) == 0 and int(d.m_valid.value) == 0 and int(d.align_err.value) == 0
            cov.hit("reset", phase)
            for _ in range(2):
                m2, n2, k2 = rng.randint(1, R), rng.randint(1, C), rng.randint(1, 20)
                A2, B2 = a.rand_tile(m2, n2, k2)
                await a.tile(A2, B2, m2, n2, k2)

    @tensor_test(checkers=checkers)
    async def global_stall_freeze(dut, rng, cov):
        """stall_i held for long stretches in RUN and in DRAIN: nothing moves (all PE inputs and
        accumulators are frozen), then the tile completes exactly."""
        a = await setup(dut, rng, cov)
        d = dut
        m, n, k = R, C, 9
        A, B = a.rand_tile(m, n, k)
        d.m_ready.value = 0                  # the readout waits for the collector below
        d.cfg_m.value, d.cfg_n.value, d.cfg_k.value, d.cfg_valid.value = m, n, k, 1
        await RisingEdge(d.clk)
        await FallingEdge(d.clk)
        d.cfg_valid.value = 0
        kk = 0
        frozen_checks = 0
        while int(d.m_valid.value) == 0:
            st = int(d.dut.state_q.value)
            if st in (2, 3) and rng.random() < 0.3:
                # freeze for a few cycles and compare complete internal snapshots
                d.stall_i.value = 1
                await RisingEdge(d.clk)
                snap = [int(getattr(d.dut, x).value) for x in ("a_data_bus", "a_valid_bus", "b_data_bus",
                                                                "b_valid_bus", "acc_flat", "done_flat")]
                for _ in range(rng.randint(2, 6)):
                    await FallingEdge(d.clk)
                    await RisingEdge(d.clk)
                    now = [int(getattr(d.dut, x).value) for x in ("a_data_bus", "a_valid_bus", "b_data_bus",
                                                                   "b_valid_bus", "acc_flat", "done_flat")]
                    assert now == snap, "array state moved during a global stall"
                    frozen_checks += 1
                await FallingEdge(d.clk)
                d.stall_i.value = 0
                cov.hit("stall", "run" if st == 2 else "drain")
                continue
            if kk < k:
                d.s_a.value = pack([A[i][kk] for i in range(R)], DW)
                d.s_b.value = pack([B[kk][j] for j in range(C)], DW)
                d.s_valid.value = 1
            await RisingEdge(d.clk)
            if int(d.s_valid.value) and int(d.s_ready.value):
                kk += 1
            await FallingEdge(d.clk)
            if kk >= k:
                d.s_valid.value = 0
        rows = {}
        await a._collect(m, rows)
        exp = gemm(A, B)
        assert [rows[i] for i in range(m)] == exp and frozen_checks > 0


# =============================================================================== pytest runner

def cfg(r, c, mp=0, ca=1, perf=1, dw=8, acc=32, kw=17):
    return dict(ARRAY_ROWS=r, ARRAY_COLS=c, DATA_WIDTH=dw, ACC_WIDTH=acc, K_WIDTH=kw, MUL_PIPE=mp,
                CHECK_ALIGN=ca, PERF_EN=perf)


# 2x2 first (brief), then the integrated shapes, then non-square / degenerate / pipelined variants
CONFIGS = [cfg(2, 2), cfg(2, 2, mp=1), cfg(4, 4), cfg(4, 4, mp=1), cfg(8, 8), cfg(1, 1), cfg(3, 5),
           cfg(4, 4, ca=0, perf=0), cfg(2, 4, acc=24, kw=12)]


def _id(c):
    return (f"{c['ARRAY_ROWS']}x{c['ARRAY_COLS']}_mp{c['MUL_PIPE']}_ca{c['CHECK_ALIGN']}_p{c['PERF_EN']}"
            f"_acc{c['ACC_WIDTH']}_kw{c['K_WIDTH']}")


@pytest.mark.parametrize("cfg", CONFIGS, ids=_id)
def test_systolic_array(cfg):
    from common import sim
    srcs, incs = sim.tc08_subset("tensor_pe.sv", "tensor_skew.sv", "tensor_output_collect.sv",
                                 "tensor_systolic_array.sv")
    sim.run("systolic_array", "tb_array", "test_array",
            srcs + sim.checker_sources() + [TT / "systolic_array" / "tb_array.sv"], cfg, includes=incs, tag=_id(cfg))
