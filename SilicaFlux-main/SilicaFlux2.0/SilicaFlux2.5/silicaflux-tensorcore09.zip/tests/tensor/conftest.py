"""pytest configuration of tests/tensor: make `common` and `reference_models` importable from every suite."""
import sys
from pathlib import Path

TT = Path(__file__).resolve().parent
if str(TT) not in sys.path:
    sys.path.insert(0, str(TT))
