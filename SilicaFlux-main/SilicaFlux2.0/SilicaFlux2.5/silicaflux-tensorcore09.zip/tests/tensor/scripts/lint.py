#!/usr/bin/env python3
"""Lint / portability checks of TENSORCORE 09.

1. RTL: Verilator 5.020 --lint-only -Wall of silicaflux_tensor_unit in every configuration the
   suites simulate (warnings are counted and reported; an error fails).
2. Testbench sources: every cocotb wrapper (tests/tensor/*/tb_*.sv) together with its RTL and the
   assertion library must elaborate in Verilator too (they run in Icarus in the suites), so the
   checkers are portable between both simulators.  Errors fail; warnings are reported.
3. The assertion library must parse in Yosys with -formal -DFORMAL (the same checkers can be
   used in formal harnesses).
Writes build/results/lint/results.json.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
from common import sim  # noqa: E402

OUT = TT / "build" / "results" / "lint"
WAIVE_TB = ["-Wno-fatal", "-Wno-DECLFILENAME", "-Wno-UNUSEDSIGNAL", "-Wno-BLKSEQ", "-Wno-UNUSEDPARAM",
            "-Wno-SYNCASYNCNET", "-Wno-MULTIDRIVEN", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-Wno-INITIALDLY",
            "-Wno-TIMESCALEMOD", "-Wno-PINCONNECTEMPTY", "-Wno-UNDRIVEN", "-Wno-CASEINCOMPLETE",
            "-Wno-UNOPTFLAT", "-Wno-VARHIDDEN", "-Wno-GENUNNAMED", "-Wno-IMPLICITSTATIC", "-Wno-LATCH"]

TSU_CFGS = {
    "baseline_4x4": {},
    "2x2": dict(ARRAY_ROWS=2, ARRAY_COLS=2, OPERAND_BUFFER_BYTES=1024, NUM_MEMORY_BANKS=2),
    "8x8": dict(ARRAY_ROWS=8, ARRAY_COLS=8),
    "quant_dbuf": dict(ENABLE_QUANTIZATION=1, ENABLE_DOUBLE_BUFFERING=1, OPERAND_BUFFER_BYTES=4096),
    "tk16_kmax4096": dict(TILE_K=16, OPERAND_BUFFER_BYTES=1024, K_MAX=4096, ENABLE_QUANTIZATION=1),
    "maxout1": dict(MAX_OUT=1),
}


def verilator(args, log):
    p = subprocess.run(["verilator", "--lint-only", *args], capture_output=True, text=True, cwd=TT)
    out = p.stdout + p.stderr
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(out)
    warns = len(re.findall(r"^%Warning", out, re.M))
    kinds = sorted(set(re.findall(r"^%Warning-(\w+): (\S+?):", out, re.M)))
    errs = len(re.findall(r"^%Error", out, re.M))
    return p.returncode, warns, errs, kinds


def main() -> int:
    srcs, incs = sim.tc08_files_f()
    inc = [f"-I{i}" for i in incs] + [f"-I{sim.ASSERT}"]
    res = dict(rtl={}, tb={}, formal_parse={})
    # 1. RTL in every simulated configuration
    for name, params in TSU_CFGS.items():
        args = ["-Wall", "-Wno-fatal", "--timescale", "1ns/1ps", "-Wno-TIMESCALEMOD", "--top-module",
                "silicaflux_tensor_unit", *inc, *[f"-G{k}={v}" for k, v in params.items()],
                "+define+TOB_ASSERT", "+define+SRAMLIB_ASSERT", *map(str, srcs)]
        rc, w, e, kinds = verilator(args, OUT / f"rtl_{name}.log")
        res["rtl"][name] = dict(rc=rc, warnings=w, errors=e, kinds=[f"{k} {Path(f).name}" for k, f in kinds])
    # 2. testbench wrappers + assertion library in Verilator
    df_chk = sim.TC08 / "third_party" / "silicaflux-datafabric" / "tb" / "common" / "sfb_protocol_checker.sv"
    tbs = {
        "tb_pe": (sim.tc08_subset("tensor_pe.sv")[0], TT / "pe" / "tb_pe.sv"),
        "tb_array": (sim.tc08_subset("tensor_pe.sv", "tensor_skew.sv", "tensor_output_collect.sv",
                                     "tensor_systolic_array.sv")[0], TT / "systolic_array" / "tb_array.sv"),
        "tb_acc": (sim.tc08_subset("tensor_acc_pkg.sv", "tensor_acc_fifo.sv", "tensor_acc_storage.sv",
                                   "tensor_acc_out_router.sv", "tensor_accumulator.sv",
                                   "tensor_acc_subsystem.sv")[0], TT / "accumulator" / "tb_acc.sv"),
        "tb_tq": (sim.tc08_subset("tensor_acc_fifo.sv", "tensor_quantize_pkg.sv", "tensor_quant_params.sv",
                                  "tensor_quant_lane.sv", "tensor_quantize.sv")[0], TT / "quantization" / "tb_tq.sv"),
        "tb_iter": (sim.tc08_subset("ttc_tile_iter.sv")[0], TT / "tile_controller" / "tb_iter.sv"),
        "tb_tsu": (srcs + [df_chk], TT / "integration" / "tb_tsu.sv"),
    }
    tob_src = [s for s in srcs if "sramlib" in str(s) or s.name in ("dma_fifo.sv",) or "tensorcore03" in str(s)]
    tbs["tb_tob"] = (tob_src, TT / "operand_buffer" / "tb_tob.sv")
    for top, (rtl, tb) in tbs.items():
        args = [*WAIVE_TB, "--top-module", top, *inc, "+define+TOB_ASSERT", "+define+SRAMLIB_ASSERT",
                *map(str, rtl), *map(str, sim.checker_sources()), str(tb)]
        rc, w, e, kinds = verilator(args, OUT / f"{top}.log")
        res["tb"][top] = dict(rc=rc, warnings=w, errors=e, kinds=[f"{k} {Path(f).name}" for k, f in kinds])
    # 3. assertion library in Yosys formal mode
    for f in sim.checker_sources():
        p = subprocess.run(["yosys", "-q", "-p", f"read_verilog -sv -formal -DFORMAL -I{sim.ASSERT} {f}"],
                           capture_output=True, text=True)
        res["formal_parse"][f.name] = dict(rc=p.returncode, msg=(p.stdout + p.stderr)[-300:])
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "results.json").write_text(json.dumps(res, indent=1))
    bad = [k for g in res.values() for k, v in g.items() if v["rc"] != 0]
    for g, d in res.items():
        for k, v in d.items():
            print(f"lint {g:12s} {k:16s} rc={v['rc']} " + (f"warnings={v.get('warnings')} errors={v.get('errors')}"
                                                           if "warnings" in v else ""))
    print(f"lint: {sum(len(d) for d in res.values()) - len(bad)}/{sum(len(d) for d in res.values())} clean of errors"
          + (f"; failing: {bad}" if bad else ""))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
