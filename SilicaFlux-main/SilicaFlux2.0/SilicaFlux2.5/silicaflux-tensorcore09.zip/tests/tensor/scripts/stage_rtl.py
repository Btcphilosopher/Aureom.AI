#!/usr/bin/env python3
"""Stage the TensorCore RTL under test from the repository archives.

The SilicaFlux TensorCore RTL is delivered in the repository as ZIP archives
(one per TENSORCORE stage).  TENSORCORE 08 vendors every earlier stage byte
for byte under third_party/, so it is the single RTL source of the integrated
unit.  TENSORCORE 01 is a separate, independently designed PE (not integrated
in TC08) that carries an explicit SAT / WRAP accumulator overflow policy; it is
staged so its overflow policy can be verified too.  TENSORCORE 02 is staged
only so its own shipped regression can be re-run (scripts/run_legacy.py).

For every archive this script
  * extracts it into build/rtl/<name>/ (fresh copy, never edited),
  * verifies every file listed in the archive's own SHA256SUMS,
  * for TC08 also verifies third_party/SHA256SUMS (vendored sources),
and writes build/rtl/manifest.json: archive SHA-256, sizes, verified file
counts and the git revision of the repository.  The report generator uses the
manifest as the "RTL revision" of every run.

Standard library only.  Exit code 0 on success, 2 when an archive is missing,
3 on any checksum mismatch.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TT = HERE.parent                      # tests/tensor
REPO = TT.parent.parent               # repository root
BUILD = TT / "build" / "rtl"

# name -> (path relative to the repository root, top folder inside the archive, checksum file)
ARCHIVES = {
    "tc08": ("SilicaFlux-main/silicaflux-tensorcore08.zip", "silicaflux-tensorcore08", "SHA256SUMS"),
    "tc01": ("SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore01-tensor_pe.zip",
             "silicaflux-tensorcore01", "SHA256SUMS.txt"),
    "tc02": ("SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore02.zip",
             "silicaflux-tensorcore02", None),
}


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


SKIPPED: list[str] = []


def verify_sums(root: Path, sums: Path) -> tuple[int, list[str]]:
    ok, bad = 0, []
    for line in sums.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        digest, name = line.split(None, 1)
        name = name.lstrip("*").strip()
        if name.startswith("./"):
            name = name[2:]
        if "__pycache__/" in name:
            # Python byte-code listed by an earlier stage's checksum file but never shipped in the
            # archive: generated, not source.  Recorded in the manifest, not treated as a failure.
            SKIPPED.append(f"{sums.parent.name}/{name}")
            continue
        f = root / name
        if not f.exists():
            bad.append(f"missing {name}")
        elif sha256(f) != digest:
            bad.append(f"mismatch {name}")
        else:
            ok += 1
    return ok, bad


def git_rev() -> dict:
    def g(*args):
        try:
            return subprocess.run(["git", "-C", str(REPO), *args], capture_output=True, text=True,
                                  timeout=30).stdout.strip()
        except Exception:                                   # noqa: BLE001 - git is optional
            return ""
    return {"commit": g("rev-parse", "HEAD"), "branch": g("rev-parse", "--abbrev-ref", "HEAD"),
            "date": g("log", "-1", "--format=%cI")}


def stage(name: str, rel: str, top: str, sums: str | None, force: bool) -> dict:
    arc = Path(os.environ.get(f"TENSOR_{name.upper()}_ZIP", REPO / rel))
    if not arc.exists():
        print(f"stage_rtl: archive for {name} not found: {arc}", file=sys.stderr)
        print("  set TENSOR_%s_ZIP=/path/to/archive.zip or run from inside the Aureom.AI repository"
              % name.upper(), file=sys.stderr)
        sys.exit(2)
    digest = sha256(arc)
    dst = BUILD / name
    stamp = dst / ".archive_sha256"
    if force or not stamp.exists() or stamp.read_text().strip() != digest:
        if dst.exists():
            shutil.rmtree(dst)
        tmp = BUILD / f".{name}.tmp"
        if tmp.exists():
            shutil.rmtree(tmp)
        with zipfile.ZipFile(arc) as z:
            z.extractall(tmp)
        shutil.move(str(tmp / top), str(dst))
        shutil.rmtree(tmp)
        stamp.write_text(digest + "\n")
    info = {"archive": str(arc.relative_to(REPO)) if arc.is_relative_to(REPO) else str(arc),
            "sha256": digest, "bytes": arc.stat().st_size, "verified_files": 0}
    bad: list[str] = []
    if sums:
        n, b = verify_sums(dst, dst / sums)
        info["verified_files"] += n
        bad += b
    tp = dst / "third_party" / "SHA256SUMS"
    if name == "tc08" and tp.exists():
        n, b = verify_sums(dst / "third_party", tp)
        info["verified_files"] += n
        info["verified_third_party"] = n
        bad += b
    if bad:
        print(f"stage_rtl: {name}: {len(bad)} checksum problems:", file=sys.stderr)
        for x in bad[:20]:
            print("   ", x, file=sys.stderr)
        sys.exit(3)
    return info


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--force", action="store_true", help="re-extract even if the archive is unchanged")
    ap.add_argument("--only", nargs="*", default=list(ARCHIVES), help="archives to stage")
    a = ap.parse_args()
    BUILD.mkdir(parents=True, exist_ok=True)
    man = {"repo": git_rev(), "archives": {}}
    for name in a.only:
        rel, top, sums = ARCHIVES[name]
        man["archives"][name] = stage(name, rel, top, sums, a.force)
    man["skipped_checksum_entries"] = SKIPPED
    (BUILD / "manifest.json").write_text(json.dumps(man, indent=2) + "\n")
    for k, v in man["archives"].items():
        print(f"stage_rtl: {k}: {v['archive']} sha256={v['sha256'][:16]}... verified {v['verified_files']} files")
    return 0


if __name__ == "__main__":
    sys.exit(main())
