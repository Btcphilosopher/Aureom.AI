#!/usr/bin/env python3
"""Package TENSORCORE 09 as a ZIP with repository-relative paths (unzip at the repository root).

Contents: tests/tensor/** (without build/, caches), the root Makefile and the CI workflow, plus
tests/tensor/SHA256SUMS listing every packaged file.  Usage: package.py [output.zip]
"""
from __future__ import annotations

import hashlib
import sys
import zipfile
from pathlib import Path

TT = Path(__file__).resolve().parents[1]
REPO = TT.parent.parent
SKIP_DIRS = {"build", "__pycache__", ".pytest_cache"}


def files():
    out = []
    for p in sorted(TT.rglob("*")):
        rel = p.relative_to(TT)
        if p.is_dir() or any(part in SKIP_DIRS for part in rel.parts) or p.suffix == ".pyc" or p.name == "SHA256SUMS":
            continue
        out.append(p)
    return out + [REPO / "Makefile", REPO / ".github" / "workflows" / "tensor-verification.yml"]


def main() -> int:
    dst = Path(sys.argv[1]) if len(sys.argv) > 1 else REPO / "silicaflux-tensorcore09.zip"
    fl = files()
    sums = "".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(REPO)}\n" for p in fl)
    (TT / "SHA256SUMS").write_text(sums)
    fl.append(TT / "SHA256SUMS")
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in fl:
            z.write(p, p.relative_to(REPO).as_posix())
    print(f"package: {dst} ({dst.stat().st_size / 1024:.0f} KiB, {len(fl)} files)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
