#!/usr/bin/env python3
"""Generate reports/VERIFICATION_REPORT.md and reports/report.json from build/results.

Sources: run_meta.json (tools, RTL revision, seeds, steps), <suite>/<run>-<seed>.json (cocotb
results per configuration), coverage/<suite>/<run>/*.json (functional coverage + SV checker
activity), formal/results.json, lint/results.json, legacy/results.json, junit/reference_models.xml,
regression/failures/failing_seeds.json; static text from docs/GAPS.md and docs/FINDINGS.md.
Nothing in the report is typed by hand: every number comes from these files.
"""
from __future__ import annotations

import json
import time
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

TT = Path(__file__).resolve().parents[1]
RES = TT / "build" / "results"
REP = TT / "reports"
SUITE_ORDER = ["pe", "systolic_array", "operand_buffer", "accumulator", "quantization", "tile_controller", "dma",
               "integration"]
SUITE_TITLE = {"pe": "PE (TC02 integrated PE, TC01 overflow-policy PE)", "systolic_array": "Systolic array (TC02)",
               "operand_buffer": "Operand buffer (TC03)", "accumulator": "Accumulator (TC04)",
               "quantization": "Quantisation (TC05)", "tile_controller": "Tile iterator (TC06) + scheduler (TC08)",
               "dma": "DMA adapter + bus gate (TC07 / TC08)", "integration": "End-to-end tensor unit (TC08)"}


def load(p: Path, default=None):
    try:
        return json.loads(p.read_text())
    except Exception:                                      # noqa: BLE001
        return default


def junit_counts(p: Path):
    if not p.exists():
        return None
    r = ET.parse(p).getroot()
    tot = dict(tests=0, failures=0, errors=0, skipped=0)
    for ts in r.iter("testsuite"):
        for k in tot:
            tot[k] += int(ts.get(k, 0))
    return tot


def main() -> int:
    REP.mkdir(parents=True, exist_ok=True)
    meta = load(RES / "run_meta.json", {}) or {}
    rtl = meta.get("rtl") or load(TT / "build" / "rtl" / "manifest.json", {}) or {}
    runs = []
    for s in SUITE_ORDER:
        for f in sorted((RES / s).glob("*.json")) if (RES / s).exists() else []:
            d = load(f)
            if d:
                runs.append(d)
    # ------------------------------------------------------------------ test counts
    per_suite = defaultdict(lambda: dict(configs=set(), passed=0, failed=0, blocked=0, sim_ns=0.0, wall=0.0,
                                         seeds=set()))
    failures = []
    blocked = []
    for r in runs:
        ps = per_suite[r["suite"]]
        ps["configs"].add(r["run"])
        ps["seeds"].add(r["seed"])
        ps["wall"] += r.get("wall_s", 0)
        for t in r["tests"]:
            ps["sim_ns"] += t.get("sim_time_ns", 0)
            if t["status"] == "passed":
                ps["passed"] += 1
            elif t["status"] == "skipped":
                ps["blocked"] += 1
                blocked.append((r["suite"], r["run"], t["name"]))
            else:
                ps["failed"] += 1
                failures.append((r["suite"], r["run"], r["seed"], t["name"], t.get("message", "")[:300]))
    # ------------------------------------------------------------------ coverage + checker activity
    cov = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))
    chk = defaultdict(lambda: dict(n_chk=0, n_err=0))
    cdir = RES / "coverage"
    for f in cdir.rglob("*.json") if cdir.exists() else []:
        d = load(f)
        if not d:
            continue
        for cp, bins in d.get("coverpoints", {}).items():
            for b, n in bins.items():
                cov[d["suite"]][cp][b] += n
        for path, v in d.get("checkers", {}).items():
            kind = path.split(".")[-1] if "." in path else path
            key = f"{d['suite']}:{kind}"
            chk[key]["n_chk"] += v.get("n_chk", 0)
            chk[key]["n_err"] += v.get("n_err", 0)
    formal = load(RES / "formal" / "results.json", {}) or {}
    lint = load(RES / "lint" / "results.json", {}) or {}
    legacy = load(RES / "legacy" / "results.json", []) or []
    ref = junit_counts(TT / "build" / "junit" / "reference_models.xml")
    fails_saved = load(TT / "regression" / "failures" / "failing_seeds.json", {}) or {}

    tot_p = sum(v["passed"] for v in per_suite.values())
    tot_f = sum(v["failed"] for v in per_suite.values())
    tot_b = sum(v["blocked"] for v in per_suite.values())
    f_jobs = formal.get("jobs", [])
    f_bad = [j for j in f_jobs if j["status"] in ("FAILED", "ERROR")]
    m_tot = sum(len(j.get("mutants", [])) for j in f_jobs)
    m_det = sum(1 for j in f_jobs for m in j.get("mutants", []) if m["status"] == "DETECTED")
    lint_bad = [k for g in lint.values() for k, v in g.items() if v.get("rc")] if lint else []
    ref_bad = ref and (ref["failures"] or ref["errors"])
    legacy_bad = [x for x in legacy if x["rc"] != 0]
    sim_muts = load(RES / "mutants" / "results.json", []) or []
    muts_det = sum(m["status"] == "DETECTED" for m in sim_muts)
    overall = "PASS" if (tot_f == 0 and not f_bad and m_det == m_tot and not lint_bad and not ref_bad
                         and not legacy_bad and runs) else "FAIL"

    L = []
    w = L.append
    w("# SilicaFlux TENSORCORE 09 — TensorCore verification report")
    w("")
    w(f"Generated {time.strftime('%Y-%m-%d %H:%M:%S %Z')} by `tests/tensor/scripts/make_report.py` from "
      "`tests/tensor/build/results` (no number below is typed by hand).")
    w("")
    w(f"**Overall: {overall}** — {tot_p} cocotb tests passed, **{tot_f} failed**, {tot_b} blocked / not applicable "
      f"across {sum(len(v['configs']) for v in per_suite.values())} suite configurations; formal "
      f"{sum(j['status'] == 'PROVEN' for j in f_jobs)} proven (unbounded), "
      f"{sum(j['status'] == 'BOUNDED' for j in f_jobs)} bounded, {len(f_bad)} failed; seeded formal bugs detected "
      f"{m_det}/{m_tot}; reference self-tests "
      + (f"{ref['tests'] - ref['failures'] - ref['errors'] - ref['skipped']}/{ref['tests']}" if ref else "not run")
      + f"; lint {'clean of errors' if not lint_bad else 'FAILED: ' + ', '.join(lint_bad)}"
      + (f"; seeded simulation bugs detected {muts_det}/{len(sim_muts)}"
         + (" (survivors explained in §9)" if muts_det < len(sim_muts) else "") if sim_muts else "")
      + (f"; legacy re-runs {len(legacy) - len(legacy_bad)}/{len(legacy)}" if legacy else "") + ".")
    w("")
    w("Evidence type: RTL simulation (Icarus Verilog through cocotb), Verilator lint, and Yosys / yosys-smtbmc formal "
      "checks with stated bounds. No gate-level simulation, no FPGA or silicon.")
    w("")
    # ------------------------------------------------------------------ revision
    w("## 1. RTL revision, tools, seeds")
    w("")
    rep = rtl.get("repo", {})
    w(f"* Repository commit `{rep.get('commit', '?')}` (branch `{rep.get('branch', '?')}`, {rep.get('date', '?')}).")
    for k, v in rtl.get("archives", {}).items():
        if v["verified_files"]:
            w(f"* RTL archive `{v['archive']}` — SHA-256 `{v['sha256']}`, {v['verified_files']} files verified "
              "against the archive's own checksum lists.")
        else:
            w(f"* Archive `{v['archive']}` — SHA-256 `{v['sha256']}` (ships no checksum list; staged only to re-run "
              "its own regression).")
    if rtl.get("skipped_checksum_entries"):
        w(f"* Checksum entries skipped (generated byte-code listed but not shipped): "
          f"{', '.join('`%s`' % x for x in rtl['skipped_checksum_entries'])}.")
    tools = meta.get("tools", {})
    if tools:
        w("* Tools: " + "; ".join(f"{k} `{v}`" for k, v in tools.items()) + ".")
    if formal.get("tools"):
        w("* Formal: " + "; ".join(f"{k} `{v}`" for k, v in formal["tools"].items()) + ".")
    seeds = sorted({s for v in per_suite.values() for s in v["seeds"]})
    w(f"* Level `{meta.get('level', '?')}`; seeds {', '.join(map(str, seeds)) or '?'} "
      "(each cocotb test draws its own stream `Random(f\"{seed}:{suite}:{test}\")`, so any test re-runs alone "
      "bit-identically).")
    w(f"* Run started {meta.get('started', '?')}, finished {meta.get('finished', '?')}.")
    w("")
    # ------------------------------------------------------------------ summary
    w("## 2. Results by suite")
    w("")
    w("| Suite | Configurations | Passed | Failed | Blocked / n.a. | Simulated time | Wall time |")
    w("|---|---|---|---|---|---|---|")
    for s in SUITE_ORDER:
        if s not in per_suite:
            w(f"| {SUITE_TITLE[s]} | — | — | — | not run | — | — |")
            continue
        v = per_suite[s]
        w(f"| {SUITE_TITLE[s]} | {len(v['configs'])} | {v['passed']} | {v['failed']} | {v['blocked']} | "
          f"{v['sim_ns'] / 1e6:.2f} ms | {v['wall']:.0f} s |")
    w(f"| **Total** | {sum(len(v['configs']) for v in per_suite.values())} | **{tot_p}** | **{tot_f}** | {tot_b} | | |")
    w("")
    w("Blocked / n.a. = a cocotb test skipped because the configuration does not have the feature it targets "
      "(e.g. the double-buffer test in a single-buffer build); listed in §8.")
    w("")
    w("### 2.1 Per configuration")
    w("")
    w("| Suite | Run (top-configuration) | Seed | Tests | Failed | Skipped | Sim time |")
    w("|---|---|---|---|---|---|---|")
    for r in runs:
        n = len(r["tests"])
        nf = sum(t["status"] == "failed" for t in r["tests"])
        nsk = sum(t["status"] == "skipped" for t in r["tests"])
        w(f"| {r['suite']} | `{r['run']}` | {r['seed']} | {n} | {nf} | {nsk} | "
          f"{sum(t.get('sim_time_ns', 0) for t in r['tests']) / 1e3:.0f} µs |")
    w("")
    if failures:
        w("### 2.2 Failures")
        w("")
        for s, run, seed, name, msg in failures:
            w(f"* `{s}` / `{run}` seed {seed}: **{name}** — {msg}")
        for x in fails_saved.get("saved", []):
            w(f"  * saved (waves, log, repro.json): `tests/tensor/{x.get('dir')}`")
        w("")
    # ------------------------------------------------------------------ reference
    w("## 3. Reference models")
    w("")
    if ref:
        w(f"`reference_models/test_reference_models.py`: {ref['tests']} tests, {ref['failures']} failures, "
          f"{ref['errors']} errors, {ref['skipped']} skipped. They establish the exact GEMM (triple loop = chunked = "
          "tiled, NumPy int64 cross-check, INT8-matmul pitfall demonstrated), the K bound by exhaustive enumeration, "
          "rounding exhaustively three ways, agreement with TC05's and TC08's own models (requantisation, 90 000 "
          "fuzzed descriptors through both validators, tile schedule), and the ABI constants against `tsu_defs.svh`.")
    else:
        w("Not run.")
    w("")
    # ------------------------------------------------------------------ formal
    w("## 4. Formal verification")
    w("")
    if f_jobs:
        w("PROVEN = BMC base case **and** k-induction step pass: the assertions hold in every reachable state for "
          "the stated parameters, under the stated assumptions. BOUNDED = BMC only: every execution up to the "
          "stated number of cycles from reset — nothing is claimed beyond it.")
        w("")
        w("| Job | Status | Claim | Property set | Assumptions | Seeded bugs |")
        w("|---|---|---|---|---|---|")
        for j in f_jobs:
            muts = "; ".join(f"{m['desc']}: {m['status']}" for m in j.get("mutants", [])) or "—"
            w(f"| `{j['name']}` | **{j['status']}** | {j.get('claim', '')} | {j['what']} | {j['assumptions']} | {muts} |")
    else:
        w("Not run.")
    w("")
    # ------------------------------------------------------------------ lint
    w("## 5. Lint and portability")
    w("")
    if lint:
        w("| Group | Item | Result | Warnings |")
        w("|---|---|---|---|")
        for g, d in lint.items():
            for k, v in d.items():
                kinds = ", ".join(v.get("kinds", [])[:6])
                w(f"| {g} | `{k}` | {'ok' if v['rc'] == 0 else 'ERROR'} | {v.get('warnings', '')} {kinds} |")
    else:
        w("Not run.")
    w("")
    if sim_muts:
        w("### 5.1 Simulation mutation campaign (do the suites catch real bugs?)")
        w("")
        w(f"{muts_det}/{len(sim_muts)} seeded RTL bugs detected "
          "(`scripts/run_mutants.py`: one-line change to a copy of the staged RTL, then the named tests).")
        w("")
        w("| Id | Seeded bug | Suite: tests | Result | First failure |")
        w("|---|---|---|---|---|")
        for m in sim_muts:
            w(f"| {m['id']} | {m['desc']} | {m.get('suite', '')}: {m.get('tests', '')} | **{m['status']}** | "
              f"{m.get('why', '').replace(str(TT.parent.parent) + '/', '')[:160].replace(chr(10), ' ').replace('|', '/')} |")
        w("")
    w("## 6. Re-run of the shipped TC02 / TC08 regressions")
    w("")
    if not legacy:
        w("Not part of this run. `make tensor-regression` (or `make tensor-legacy`) re-runs the shipped TC08 ABI check, "
          "lint and regression stages and the TC02 lint and 2×2 stage as an independent second line of evidence.")
        w("")
    else:
        for st in meta.get("steps", []):
            if st.get("step") == "legacy" and st.get("note"):
                w(f"Note: {st['note']}.")
                w("")
        w("| Step | Result | Time | Last lines |")
        w("|---|---|---|---|")
        for x in legacy:
            w(f"| `{x['name']}` | {'PASS' if x['rc'] == 0 else 'FAIL'} | {x['seconds']:.0f} s | "
              f"{' / '.join(x.get('tail', []))[:200]} |")
        w("")
    # ------------------------------------------------------------------ coverage
    w("## 7. Functional coverage (merged over configurations and seeds)")
    w("")
    w("Coverpoints declare their bins up front, so a bin never reached counts as a miss.")
    w("")
    w("| Suite | Coverpoint | Bins hit | Missed bins |")
    w("|---|---|---|---|")
    cov_json = {}
    for s in SUITE_ORDER:
        for cp in sorted(cov.get(s, {})):
            bins = cov[s][cp]
            hit = [b for b, n in bins.items() if n]
            miss = [b for b, n in bins.items() if not n]
            cov_json[f"{s}.{cp}"] = dict(bins=dict(bins), hit=len(hit), total=len(bins))
            w(f"| {s} | `{cp}` | {len(hit)}/{len(bins)} | {', '.join(miss[:12])}{' …' if len(miss) > 12 else ''} |")
    w("")
    w("### 7.1 Assertion activity (SV checkers; evaluations summed over all tests)")
    w("")
    w("| Suite : checker | Evaluations | Errors |")
    w("|---|---|---|")
    for k in sorted(chk):
        w(f"| `{k}` | {chk[k]['n_chk']} | {chk[k]['n_err']} |")
    w("")
    # ------------------------------------------------------------------ gaps
    w("## 8. Not applicable / blocked tests")
    w("")
    if blocked:
        agg = defaultdict(list)
        for s, run, name in blocked:
            agg[(s, name)].append(run.split("-", 1)[-1])
        for (s, name), rr in sorted(agg.items()):
            w(f"* `{s}.{name}` — not applicable in: {', '.join(sorted(set(rr)))}")
    else:
        w("None.")
    w("")
    for title, fn in (("## 9. Findings and specification clarifications", "FINDINGS.md"),
                      ("## 10. Known verification gaps", "GAPS.md")):
        w(title)
        w("")
        p = TT / "docs" / fn
        w(p.read_text().split("\n", 2)[2].strip() if p.exists() else "(missing)")
        w("")
    (REP / "VERIFICATION_REPORT.md").write_text("\n".join(L) + "\n")
    (REP / "report.json").write_text(json.dumps(dict(
        overall=overall, totals=dict(passed=tot_p, failed=tot_f, blocked=tot_b),
        suites={s: dict(configs=sorted(v["configs"]), passed=v["passed"], failed=v["failed"], blocked=v["blocked"],
                        sim_ms=round(v["sim_ns"] / 1e6, 3)) for s, v in per_suite.items()},
        failures=[dict(suite=a, run=b, seed=c, test=d, message=e) for a, b, c, d, e in failures],
        formal=f_jobs, lint=lint, legacy=legacy, reference=ref, coverage=cov_json,
        mutants=load(RES / "mutants" / "results.json", []),
        checkers=chk, meta=meta), indent=1, default=str))
    print(f"report: {overall} - {tot_p} passed, {tot_f} failed, {tot_b} blocked -> {REP / 'VERIFICATION_REPORT.md'}")
    return 0 if overall == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
