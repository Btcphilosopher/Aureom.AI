#!/usr/bin/env python3
"""Mutation campaign of the TENSORCORE 09 simulation suites: do the tests catch real bugs?

Each mutant is a one-line change to a COPY of the staged TC08 RTL tree (build/mutants/<id>/tc08);
the suite / configuration / cocotb tests named for it run against the copy (TENSOR_RTL_TC08) with
their results kept apart (TENSOR_RESULTS_DIR).  A mutant is DETECTED if at least one test fails,
INVALID if the copy does not build.  The unmutated RTL passes the same tests in the regression.

Writes build/results/mutants/results.json (summarised in the verification report).
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

TT = Path(__file__).resolve().parents[1]
SRC = TT / "build" / "rtl" / "tc08"
WORK = TT / "build" / "mutants"
OUT = TT / "build" / "results" / "mutants"
P02, P03, P04, P05, P06, P07 = (f"third_party/silicaflux-tensorcore0{i}/rtl" for i in (2, 3, 4, 5, 6, 7))

# id, description, file, old, new, suite dir, pytest -k, cocotb tests
MUTANTS = [
    ("M01", "PE accumulates when only the A token is valid", f"{P02}/tensor_pe.sv",
     "assign fire_c = a_valid_i & b_valid_i;", "assign fire_c = a_valid_i;",
     "pe", "test_tensor_pe and dw8_acc32_mp0_ca1", "random_protocol"),
    ("M02", "PE product zero-extended instead of sign-extended", f"{P02}/tensor_pe.sv",
     "assign mac_prod_ext = ACC_WIDTH'($signed(mac_prod_c));", "assign mac_prod_ext = ACC_WIDTH'($unsigned(mac_prod_c));",
     "pe", "test_tensor_pe and dw8_acc32_mp0_ca1", "corner_products"),
    ("M03", "skew one stage too deep on lane 2 (operands misaligned)", f"{P02}/tensor_skew.sv",
     "localparam int D = BASE + l;", "localparam int D = BASE + l + ((l == 2) ? 1 : 0);",
     "systolic_array", "4x4_mp0_ca1_p1_acc32", "directed_values"),
    ("M04", "array leaves DRAIN before the wavefront drained", f"{P02}/tensor_systolic_array.sv",
     "S_DRAIN:   if (all_done)", "S_DRAIN:   if (1'b1)",
     "systolic_array", "2x2_mp0_ca1_p1_acc32", "directed_values"),
    ("M05", "operand buffer B row stride off by one byte", f"{P03}/tensor_operand_buffer.sv",
     "bb_q <= bb_q + f_ldb;", "bb_q <= bb_q + f_ldb + 1'b1;",
     "operand_buffer", "4x4_s1_a1024", "fill_and_compute_strided"),
    ("M06", "compute may claim an operand set the DMA is still filling", f"{P03}/tob_dbuf_ctrl.sv",
     "assign cmp_begin_ready  = (st_c == `TOB_ST_READY);",
     "assign cmp_begin_ready  = (st_c == `TOB_ST_READY) || (st_c == `TOB_ST_FILL);",
     "integration", "test_integration and 4x4_tk64_opb2048 and not q8 and not dbuf and not mo1", "brief_shapes"),
    ("M07", "accumulator adds the bias on every K chunk", f"{P04}/tensor_accumulator.sv",
     "assign ps_bias_first = (ps_nch == '0) & s_bias_en_q[ps_si];", "assign ps_bias_first = s_bias_en_q[ps_si];",
     "accumulator", "4x4_acc32_out32_t2_rd1_sat_s1_g1", "chunked_accumulation_exact"),
    ("M08", "requantisation RNE rounds ties down", f"{P05}/tensor_quant_lane.sv",
     "tensor_quantize_pkg::RM_RNE: inc = g & (st | fl[0]);", "tensor_quantize_pkg::RM_RNE: inc = g & st;",
     "quantization", "4x4_in32_ctx2_grp1", "rounding_ties_every_mode"),
    ("M09", "requantisation RMM rounds ties toward zero", f"{P05}/tensor_quant_lane.sv",
     "tensor_quantize_pkg::RM_RMM: inc = g & (st | ~neg);", "tensor_quantize_pkg::RM_RMM: inc = g & (st | neg);",
     "quantization", "4x4_in32_ctx2_grp1", "rounding_ties_every_mode"),
    ("M10", "tile iterator: last K chunk not shortened", f"{P06}/ttc_tile_iter.sv",
     "assign eff_k = last_k ? (k - k0)    : kc;", "assign eff_k = kc;",
     "tile_controller", "test_tile_iterator and 4x4", "directed_shapes"),
    ("M11", "scheduler: local A stride rule changed (job / descriptor layout)", "rtl/tsu_sched.sv",
     "lda_loc = r4[2] ? 32'(r4) : 32'(r4) + 32'd4;", "lda_loc = 32'(r4) + 32'd4;",
     "tile_controller", "test_scheduler and 4x4_tk64_opb2048 and not dbuf", "tiles_and_chunks"),
    ("M12", "validator: LDB < N no longer rejected", "rtl/tsu_validate.sv",
     "else if (lda < 32'(k) || ldb < 32'(n) || 34'(ldc) < esz_n)", "else if (lda < 32'(k) || 34'(ldc) < esz_n)",
     "tile_controller", "test_scheduler and 4x4_tk64_opb2048 and not dbuf", "invalid_commands_have_no_side_effect"),
    ("M13", "DMA address generator: row stride added twice", f"{P07}/tdma_agu.sv",
     "s <= s + str;", "s <= s + str + str;",
     "dma", "test_dma and 4x4_tk64_opb2048 and not mo and not dbuf and not q8", "strided_unaligned_operands"),
    ("M14", "bus gate never quiesces (requests keep leaving after an error)", "rtl/tsu_bus_gate.sv",
     "assign pass = !q_q || held_q;", "assign pass = 1'b1;",
     "dma", "test_dma and 4x4_tk64_opb2048 and not mo and not dbuf and not q8", "read_error_injection"),
]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--only", nargs="*")
    a = ap.parse_args()
    if not SRC.exists():
        print("run scripts/stage_rtl.py first", file=sys.stderr)
        return 2
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for mid, desc, f, old, new, suite, sel, tests in MUTANTS:
        if a.only and mid not in a.only:
            continue
        t0 = time.time()
        d = WORK / mid
        if d.exists():
            shutil.rmtree(d)
        shutil.copytree(SRC, d / "tc08", ignore=shutil.ignore_patterns("reports", "logs", "build", "waves", "vectors"))
        tgt = d / "tc08" / f
        src = tgt.read_text()
        if src.count(old) != 1:
            results.append(dict(id=mid, desc=desc, status="INVALID", why=f"pattern found {src.count(old)} times"))
            print(f"{mid} INVALID ({desc}): pattern count {src.count(old)}")
            continue
        tgt.write_text(src.replace(old, new))
        rdir = d / "results"
        env = dict(os.environ, TENSOR_RTL_TC08=str(d / "tc08"), TENSOR_MUTANT=mid, TENSOR_RESULTS_DIR=str(rdir),
                   TENSOR_NO_RERUN="1", TENSOR_TESTCASE=tests, TENSOR_LEVEL="quick")
        p = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", suite, "-k", sel],
                           cwd=TT, env=env, capture_output=True, text=True, timeout=3600)
        (d / "pytest.log").write_text(p.stdout + p.stderr)
        runs = [json.loads(x.read_text()) for x in rdir.rglob("*.json") if x.parent.parent == rdir]
        failed = [(r["run"], t["name"], t["message"][:200]) for r in runs for t in r["tests"] if t["status"] == "failed"]
        ran = sum(len(r["tests"]) for r in runs)
        if not runs:
            status, why = "INVALID", "no results (build failed or nothing selected): see pytest.log"
        elif failed:
            status, why = "DETECTED", f"{failed[0][1]}: {failed[0][2]}"
        else:
            status, why = "SURVIVED", f"{ran} tests passed"
        results.append(dict(id=mid, desc=desc, file=f, suite=suite, tests=tests, status=status, why=why,
                            seconds=round(time.time() - t0, 1)))
        print(f"{mid} {status:9s} {desc} [{suite}: {tests}] ({time.time() - t0:.0f} s) {why[:140]}")
    (OUT / "results.json").write_text(json.dumps(results, indent=1))
    det = sum(r["status"] == "DETECTED" for r in results)
    print(f"mutants: {det}/{len(results)} detected")
    return 0 if det == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
