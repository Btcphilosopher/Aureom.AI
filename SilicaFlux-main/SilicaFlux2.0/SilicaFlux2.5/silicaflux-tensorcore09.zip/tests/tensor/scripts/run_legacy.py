#!/usr/bin/env python3
"""Re-run the regressions the earlier TENSORCORE stages shipped (reuse of existing infrastructure).

The TENSORCORE 09 suites are independent of these (own reference, own testbenches); re-running
the shipped SV / Verilator regressions on the same staged RTL with the same tools is a second,
independent line of evidence, and shows that the earlier stages' claims still reproduce.

  TC08  scripts/gen_abi.py --check, scripts/run_lint.py, scripts/run_regress.py --stages 1,2
        (--full: --stages 1,2,3)
  TC02  make lint, tools/run_regress.py --only 2x2_L1 (--full: also 4x4_L2)

Each archive tree is copied to build/legacy/<name> first (the shipped scripts write into their own
tree; the staged RTL under build/rtl stays pristine).  Writes build/results/legacy/results.json.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

TT = Path(__file__).resolve().parents[1]
RTL = TT / "build" / "rtl"
WORK = TT / "build" / "legacy"
OUT = TT / "build" / "results" / "legacy"


def step(name, cmd, cwd, timeout):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        rc, out = p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired:
        rc, out = -1, "TIMEOUT"
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"{name}.log").write_text(" ".join(cmd) + "\n" + out)
    tail = [ln for ln in out.strip().splitlines() if ln.strip()][-3:]
    print(f"[{'PASS' if rc == 0 else 'FAIL'}] legacy {name} ({time.time() - t0:.0f} s): {' | '.join(tail)}")
    return dict(name=name, rc=rc, seconds=round(time.time() - t0, 1), tail=tail)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--full", action="store_true")
    ap.add_argument("--jobs", default="4")
    a = ap.parse_args()
    res = []
    for name in ("tc08", "tc02"):
        src = RTL / name
        if not src.exists():
            print(f"legacy: {name} not staged", file=sys.stderr)
            return 2
        dst = WORK / name
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(src, dst)
    t8, t2 = WORK / "tc08", WORK / "tc02"
    res.append(step("tc08_abi", [sys.executable, "scripts/gen_abi.py", "--check"], t8, 600))
    res.append(step("tc08_lint", [sys.executable, "scripts/run_lint.py"], t8, 3600))
    res.append(step("tc08_regress", [sys.executable, "scripts/run_regress.py", "--stages", "1,2,3" if a.full else "1,2",
                                     "--jobs", a.jobs, "--out", "regression_legacy"], t8, 4 * 3600))
    res.append(step("tc02_lint", ["make", "lint"], t2, 1800))
    res.append(step("tc02_stage1", [sys.executable, "tools/run_regress.py", "--only", "2x2_L1", "--skip-pe", "--out",
                                    "reports/legacy_stage1.md"], t2, 3600))
    if a.full:
        res.append(step("tc02_stage2", [sys.executable, "tools/run_regress.py", "--only", "4x4_L2", "--skip-pe",
                                        "--out", "reports/legacy_stage2.md"], t2, 3 * 3600))
    (OUT / "results.json").write_text(json.dumps(res, indent=1))
    return 0 if all(r["rc"] == 0 for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
