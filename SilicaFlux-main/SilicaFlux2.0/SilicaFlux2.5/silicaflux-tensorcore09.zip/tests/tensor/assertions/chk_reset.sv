// =============================================================================
// SilicaFlux TENSORCORE 09 :: chk_reset  -- reset behaviour
//   Z1  every signal of `quiet` is 0 at every clock edge while rst_n = 0,
//       from the second reset edge on (synchronous-reset blocks such as the
//       TC02 PE and TC04 / TC05 clear their registers AT the first reset edge;
//       asynchronous-reset blocks satisfy the check trivially)
//   Z2  ... and still 0 at the first edge after rst_n is released (all
//       outputs restart from their reset values; nothing is presented early)
//   Z3  no signal of `known` is X/Z out of reset (simulation only)
// =============================================================================
`include "chk_defs.svh"
`default_nettype none
module chk_reset #(
  parameter int N  = 1,
  parameter int NK = 1
) (
  input wire logic          clk,
  input wire logic          rst_n,
  input wire logic [N-1:0]  quiet,
  input wire logic [NK-1:0] known
);
  `CHK_DECL
  logic rst_q;
  integer n_reset_edges = 0;
  initial rst_q = 1'b1;
  always @(posedge clk) begin
    if (!rst_q) begin              // previous edge was a reset edge: during reset, or first edge after it
      `CHK(quiet === '0, ("Z1/Z2 signal active during / right after reset: %b", quiet))
      n_reset_edges = n_reset_edges + 1;
    end
`ifndef FORMAL
    if (rst_n && rst_q) `CHK((^known) !== 1'bx, ("Z3 X/Z on a status / control signal: %b", known))
`endif
    rst_q <= rst_n;
  end
endmodule
`default_nettype wire
