// =============================================================================
// SilicaFlux TENSORCORE 09 :: chk_arb  -- arbitration safety of one arbiter
//   G1  a grant only goes to a requester            (gnt subset of req)
//   G2  at most one grant per cycle                  (one-hot or zero)
//   G3  work conservation: an eligible request (req & ~blk) gets some grant
//   G4  bounded waiting: a requester that keeps requesting and is eligible is
//       granted within MAX_WAIT cycles (MAX_WAIT = 0 disables the check)
// =============================================================================
`include "chk_defs.svh"
`default_nettype none
module chk_arb #(
  parameter int N        = 4,
  parameter int MAX_WAIT = 0
) (
  input wire logic         clk,
  input wire logic         rst_n,
  input wire logic [N-1:0] req,
  input wire logic [N-1:0] blk,      // requesters legitimately blocked this cycle (tie 0 if none)
  input wire logic [N-1:0] gnt
);
  `CHK_DECL
  integer wait_c [0:N-1];
  integer max_wait_seen = 0;
  initial for (int i = 0; i < N; i++) wait_c[i] = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int i = 0; i < N; i++) wait_c[i] = 0;
    end else begin
      `CHK((gnt & ~req) == '0, ("G1 grant %b without request %b", gnt, req))
      `CHK((gnt & (gnt - 1'b1)) == '0, ("G2 more than one grant: %b", gnt))
      `CHK(((req & ~blk) == '0) || (gnt != '0), ("G3 eligible requests %b, no grant", req & ~blk))
      for (int i = 0; i < N; i++) begin
        if (req[i] && !gnt[i]) wait_c[i] = wait_c[i] + 1;
        else wait_c[i] = 0;
        if (wait_c[i] > max_wait_seen) max_wait_seen = wait_c[i];
        if (MAX_WAIT > 0) `CHK(wait_c[i] <= MAX_WAIT, ("G4 requester %0d waited %0d cycles", i, wait_c[i]))
      end
    end
  end
endmodule
`default_nettype wire
