// =============================================================================
// SilicaFlux TENSORCORE 09 :: chk_pe  -- MAC checker of one TC02 tensor_pe
//
// Connected to the PE's ports (from a wrapper or, inside an array, through
// hierarchical references).  Independent of the PE's own CHECK_ALIGN logic.
//   P1  valid MAC operand pairing: when both tokens are valid they carry the
//       same reduction index k and the same `last` tag
//   P2  fire_o == en & a_valid & b_valid  (a MAC is never taken from one token)
//   P3  inside the active region (chk_en) tokens arrive in pairs (no orphan)
//   P4  no MAC after the last-tagged MAC of the tile (no duplicated MAC)
//   P5  the accumulator changes only on a commit, and then by exactly the
//       sign-extended product of the paired operands (modulo 2^ACC_WIDTH,
//       the documented PE wrap; MUL_PIPE product stage modelled)
//   P6  done_o rises exactly at the commit of the last-tagged pair
//   P7  rst_n / clr clear the accumulator, done and the forward tokens
// commits / last_commits count MACs of the current / previous tile (outputs,
// used by chk_array for "no omitted MAC").
// =============================================================================
`include "chk_defs.svh"
`default_nettype none
module chk_pe #(
  parameter int DATA_WIDTH = 8,
  parameter int ACC_WIDTH  = 32,
  parameter int KIDX_WIDTH = 17,
  parameter int MUL_PIPE   = 0,
  parameter bit CHECK_KSEQ = 1'b1          // P1b: k indices 0,1,2,.. per tile (array use)
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  input  wire logic                         clr,
  input  wire logic                         en,
  input  wire logic                         chk_en,
  input  wire logic                         chk_off,   // 1: suspend P1-P6 (negative tests)
  input  wire logic                         a_valid_i,
  input  wire logic                         a_last_i,
  input  wire logic signed [DATA_WIDTH-1:0] a_data_i,
  input  wire logic [KIDX_WIDTH-1:0]        a_kidx_i,
  input  wire logic                         b_valid_i,
  input  wire logic                         b_last_i,
  input  wire logic signed [DATA_WIDTH-1:0] b_data_i,
  input  wire logic [KIDX_WIDTH-1:0]        b_kidx_i,
  input  wire logic                         a_valid_o,
  input  wire logic                         b_valid_o,
  input  wire logic signed [ACC_WIDTH-1:0]  acc_o,
  input  wire logic                         done_o,
  input  wire logic                         fire_o,
  input  wire logic                         commit_o,
  output integer                            commits,
  output integer                            last_commits
);
  `CHK_DECL
  logic signed [ACC_WIDTH-1:0] acc_q, exp_acc;
  logic                        prev_ok, done_q;
  logic signed [2*DATA_WIDTH-1:0] prod_pipe;      // MUL_PIPE = 1: product of the previous fire
  logic                           pipe_v, pipe_last;
  integer last_k = -1;
  initial begin commits = 0; last_commits = 0; prev_ok = 1'b0; pipe_v = 1'b0; end

  always @(posedge clk) begin : p
    logic signed [2*DATA_WIDTH-1:0] prod;
    logic signed [ACC_WIDTH-1:0]    add;
    logic                           cmt_last;
    if (!rst_n || clr) begin
      if (commits > 0) last_commits = commits;
      commits = 0;
      prev_ok <= 1'b0;
      pipe_v  <= 1'b0;
      last_k  = -1;
    end else if (chk_off) begin
      prev_ok <= 1'b0;
    end else begin
      // P1 pairing (independent of the PE's own alignment checker)
      if (en && a_valid_i && b_valid_i)
        `CHK(a_kidx_i == b_kidx_i && a_last_i == b_last_i,
             ("P1 pairing: A(k=%0d,last=%b) with B(k=%0d,last=%b)", a_kidx_i, a_last_i, b_kidx_i, b_last_i))
      // P2 MAC only from a token pair
      `CHK(fire_o == (en && a_valid_i && b_valid_i), ("P2 fire_o=%b with en=%b a_v=%b b_v=%b", fire_o, en,
                                                         a_valid_i, b_valid_i))
      if (MUL_PIPE == 0) `CHK(commit_o == fire_o, ("P2 commit_o != fire_o with MUL_PIPE=0"))
      // P3 no orphan token in the active region
      if (en && chk_en) `CHK(a_valid_i == b_valid_i, ("P3 orphan token in the active region: a_v=%b b_v=%b",
                                                         a_valid_i, b_valid_i))
      // P4 no MAC after the last one
      if (commit_o) `CHK(!done_o, ("P4 MAC committed after the tile's last MAC (duplicate)"))
      // P1b reduction indices strictly increase from 0 (no skipped / repeated k)
      if (fire_o && CHECK_KSEQ) begin
        `CHK(32'(a_kidx_i) == last_k + 1, ("P1b k index %0d after %0d (skipped or repeated MAC)", a_kidx_i,
                                            last_k))
        last_k = 32'(a_kidx_i);
      end
      // P5 / P6 accumulator update
      prod = a_data_i * b_data_i;
      if (MUL_PIPE == 0) begin
        add = ACC_WIDTH'($signed(prod));
        cmt_last = a_last_i & b_last_i;
      end else begin
        add = ACC_WIDTH'($signed(prod_pipe));
        cmt_last = pipe_last;
      end
      if (prev_ok) begin
        `CHK(acc_o === exp_acc, ("P5 accumulator %0d, expected %0d", acc_o, exp_acc))
        `CHK(done_o === done_q, ("P6 done %b, expected %b", done_o, done_q))
      end
      exp_acc = acc_o + ((commit_o) ? add : '0);
      done_q  = done_o | (commit_o & cmt_last);
      if (en && MUL_PIPE != 0) begin
        if (fire_o) prod_pipe <= prod;
        pipe_v    <= fire_o;
        pipe_last <= fire_o & a_last_i & b_last_i;
      end
      if (MUL_PIPE != 0) `CHK(commit_o == (en && pipe_v), ("P2 MUL_PIPE commit without a registered product"))
      if (commit_o) commits = commits + 1;
      prev_ok <= 1'b1;
    end
  end

  // P7 reset / clear values (sampled one edge after the clearing edge)
  logic clr_q;
  initial clr_q = 1'b0;
  always @(posedge clk) begin
    if (clr_q) `CHK(acc_o == '0 && !done_o && !a_valid_o && !b_valid_o,
                    ("P7 state not cleared: acc=%0d done=%b fwd=%b%b", acc_o, done_o, a_valid_o, b_valid_o))
    clr_q <= !rst_n || clr;
  end
endmodule
`default_nettype wire
