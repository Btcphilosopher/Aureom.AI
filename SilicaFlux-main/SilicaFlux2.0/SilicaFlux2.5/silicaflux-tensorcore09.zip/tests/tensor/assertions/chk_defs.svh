// =============================================================================
// SilicaFlux TENSORCORE 09 :: chk_defs.svh  -- assertion macros of the checkers
//
// Every checker in tests/tensor/assertions is written with immediate assertions
// inside clocked processes, so the SAME source runs in
//   * Icarus Verilog 12 (cocotb suites; 4-state, X detection),
//   * Verilator 5.020 (lint, legacy SV benches),
//   * Yosys 0.33 read_verilog -formal (formal harnesses, `define FORMAL).
// Concurrent SVA (assert property) is avoided on purpose: Icarus 12 does not
// evaluate it and Yosys open-source supports only a subset.
//
// Simulation: a failing check increments the checker's n_err, prints one
// $error line (first CHK_MAX_PRINT per checker) and the cocotb test fails at
// its end when any checker reports n_err != 0.  n_chk counts evaluated checks
// so a vacuous checker (never exercised) is visible in the report.
// Formal: CHK becomes a plain `assert`.
// =============================================================================
`ifndef CHK_DEFS_SVH
`define CHK_DEFS_SVH

`ifndef CHK_MAX_PRINT
`define CHK_MAX_PRINT 20
`endif

`ifdef FORMAL
  `define CHK_DECL
  `define CHK(cond, msg) assert (cond);
  `define CHK_COUNT
`else
  `define CHK_DECL integer n_err = 0; integer n_chk = 0;
  // msg is a parenthesised $display argument list: ("fmt %0d", x)
  `define CHK(cond, msg) begin n_chk = n_chk + 1; if (!(cond)) begin n_err = n_err + 1; \
      if (n_err <= `CHK_MAX_PRINT) begin $write("CHECKER_ERROR %m t=%0t: ", $time); $display msg ; end end end
  `define CHK_COUNT n_chk = n_chk + 1;
`endif

`endif
