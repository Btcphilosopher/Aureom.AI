// =============================================================================
// SilicaFlux TENSORCORE 09 :: chk_handshake
// Valid/ready channel checker:  "stable payload under backpressure".
//   H1  once valid is high and ready low at a clock edge, valid stays high at
//       the next edge (no withdrawal; SFB2 R2, Module 04 H2, TC02/TC03 streams)
//   H2  ... and the payload is unchanged (compared with ===, so X counts)
//   H3  valid / ready are never X or Z out of reset (simulation only)
// Counters (simulation): n_xfer transfers, n_bp backpressure cycles.
// =============================================================================
`include "chk_defs.svh"
`default_nettype none
module chk_handshake #(
  parameter int W        = 1,
  parameter bit CHECK_X  = 1'b1
) (
  input wire logic         clk,
  input wire logic         rst_n,
  input wire logic         valid,
  input wire logic         ready,
  input wire logic [W-1:0] data
);
  `CHK_DECL
  logic         pend_q;
  logic [W-1:0] data_q;
`ifndef FORMAL
  integer n_xfer = 0, n_bp = 0;
`endif
  initial pend_q = 1'b0;

  always @(posedge clk) begin
    if (!rst_n) begin
      pend_q <= 1'b0;
    end else begin
`ifndef FORMAL
      if (CHECK_X) `CHK((^{valid, ready}) !== 1'bx, ("valid/ready X or Z: valid=%b ready=%b", valid, ready))
      if (valid === 1'b1 && ready === 1'b1) n_xfer = n_xfer + 1;
      if (valid === 1'b1 && ready === 1'b0) n_bp = n_bp + 1;
`endif
      if (pend_q) begin
        `CHK(valid === 1'b1, ("valid withdrawn under backpressure"))
        `CHK(data === data_q, ("payload changed under backpressure: %h -> %h", data_q, data))
      end
      pend_q <= (valid === 1'b1) && (ready !== 1'b1);
      data_q <= data;
    end
  end
endmodule
`default_nettype wire
