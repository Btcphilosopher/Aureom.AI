// =============================================================================
// SilicaFlux TENSORCORE 09 :: chk_fifo / chk_fifo_credit  -- FIFO safety
//
// chk_fifo        valid/ready FIFO (e.g. M08 hpc_command_queue):
//   F1  no push accepted when the shadow model is full   (overflow)
//   F2  out_valid only when the shadow model is non-empty (underflow / phantom entry)
//   F3  level / full / empty agree with the shadow occupancy
//   F4  out_data equals the oldest pushed entry           (order, no loss, no duplication)
//   F5  in_ready whenever not full, out_valid whenever not empty (no stuck queue)
// chk_fifo_credit credit-controlled push/pop FIFO without handshakes
//   (DataFabric dma_fifo: the user must never push when full / pop when empty):
//   C1  no push when full without a pop, C2 no pop when empty, C3 count agrees,
//   C4  rdata equals the oldest entry while non-empty.
// The shadow model is a plain array updated with blocking assignments (it is
// a checker, not hardware).
// =============================================================================
`include "chk_defs.svh"
`default_nettype none
module chk_fifo #(
  parameter int W     = 8,
  parameter int DEPTH = 4,
  parameter int CW    = 3,
  parameter bit STRICT_READY = 1'b1     // F5: ready/valid exactly track occupancy
) (
  input wire logic          clk,
  input wire logic          rst_n,
  input wire logic          in_valid,
  input wire logic          in_ready,
  input wire logic [W-1:0]  in_data,
  input wire logic          out_valid,
  input wire logic          out_ready,
  input wire logic [W-1:0]  out_data,
  input wire logic [CW-1:0] level,
  input wire logic          full,
  input wire logic          empty
);
  `CHK_DECL
  logic [W-1:0] q [0:DEPTH];
  integer cnt = 0;
`ifndef FORMAL
  integer n_push = 0, n_pop = 0, max_level = 0;
`endif
  always @(posedge clk) begin : p
    logic push, pop;
    if (!rst_n) begin
      cnt = 0;
    end else begin
      push = in_valid && in_ready;
      pop  = out_valid && out_ready;
      `CHK(!(in_ready && cnt >= DEPTH), ("F1 accepts while full (cnt=%0d)", cnt))
      `CHK(!(out_valid && cnt == 0), ("F2 out_valid while empty"))
      `CHK(32'(level) == cnt, ("F3 level %0d != shadow %0d", level, cnt))
      `CHK(full == (cnt == DEPTH) && empty == (cnt == 0), ("F3 full/empty %b%b at cnt %0d", full, empty, cnt))
      if (STRICT_READY) begin
        `CHK(in_ready == (cnt < DEPTH), ("F5 in_ready %b at cnt %0d", in_ready, cnt))
        `CHK(out_valid == (cnt > 0), ("F5 out_valid %b at cnt %0d", out_valid, cnt))
      end
      if (out_valid && cnt > 0) `CHK(out_data === q[0], ("F4 head %h, expected %h", out_data, q[0]))
      if (pop && cnt > 0) begin
        for (int i = 0; i < DEPTH; i++) q[i] = q[i+1];
        cnt = cnt - 1;
      end
      if (push && cnt < DEPTH + 1) begin
        q[cnt] = in_data;
        cnt = cnt + 1;
      end
`ifndef FORMAL
      if (push) n_push = n_push + 1;
      if (pop) n_pop = n_pop + 1;
      if (cnt > max_level) max_level = cnt;
`endif
    end
  end
endmodule

module chk_fifo_credit #(
  parameter int W     = 8,
  parameter int DEPTH = 4,
  parameter int CW    = 3
) (
  input wire logic          clk,
  input wire logic          rst_n,
  input wire logic          clr,
  input wire logic          push,
  input wire logic [W-1:0]  wdata,
  input wire logic          pop,
  input wire logic [W-1:0]  rdata,
  input wire logic [CW-1:0] count
);
  `CHK_DECL
  logic [W-1:0] q [0:DEPTH];
  integer cnt = 0;
  always @(posedge clk) begin
    if (!rst_n || clr) begin
      cnt = 0;
    end else begin
      `CHK(!(push && !pop && cnt >= DEPTH), ("C1 push while full"))
      `CHK(!(pop && cnt == 0), ("C2 pop while empty"))
      `CHK(32'(count) == cnt, ("C3 count %0d != shadow %0d", count, cnt))
      if (cnt > 0) `CHK(rdata === q[0], ("C4 head %h, expected %h", rdata, q[0]))
      if (pop && cnt > 0) begin
        for (int i = 0; i < DEPTH; i++) q[i] = q[i+1];
        cnt = cnt - 1;
      end
      if (push && cnt <= DEPTH) begin
        q[cnt] = wdata;
        cnt = cnt + 1;
      end
    end
  end
endmodule
`default_nettype wire
