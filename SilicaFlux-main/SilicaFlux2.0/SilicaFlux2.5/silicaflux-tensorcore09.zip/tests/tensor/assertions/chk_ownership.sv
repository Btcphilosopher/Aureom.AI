// =============================================================================
// SilicaFlux TENSORCORE 09 :: chk_ownership  -- buffer ownership protocol
//
// Watches the 2-bit-per-set state vector of a TC03 tob_dbuf_ctrl instance
// (operand buffer, or the output buffer that reuses it) and the accesses made
// to the sets.  States: 0 FREE/EMPTY, 1 FILL(ING) = producer owns,
// 2 READY, 3 IN_USE/COMPUTE = consumer owns.
//   O1  only legal transitions per set: stay, 0->1, 1->2, 2->3, 3->0
//   O2  sets are filled and consumed in strict ping-pong order
//   O3  at most one set is producer-owned and at most one consumer-owned
//   O4  a producer write targets a set the producer owns  (state 1)
//   O5  a consumer read targets a set the consumer owns   (state 3)
//   O6  a set enters READY only when no producer write is pending in it
//       (pend input: the producer has an unacknowledged write)
// Simulation counters: n_fill (sets sealed), n_use (sets released).
// =============================================================================
`include "chk_defs.svh"
`default_nettype none
module chk_ownership #(
  parameter int NSETS = 2,
  parameter int SW    = 1
) (
  input wire logic               clk,
  input wire logic               rst_n,
  input wire logic [NSETS*2-1:0] state,
  input wire logic               wr_v,     // producer write performed this cycle
  input wire logic [SW-1:0]      wr_set,
  input wire logic               rd_v,     // consumer read performed this cycle
  input wire logic [SW-1:0]      rd_set,
  input wire logic               pend      // producer has a write in flight (for O6), tie 0 if unknown
);
  `CHK_DECL
  logic [NSETS*2-1:0] st_q;
  integer next_fill = 0, next_use = 0;
`ifndef FORMAL
  integer n_fill = 0, n_use = 0;
`endif
  initial st_q = '0;
  // (counted in a process, not a function: Yosys 0.33 rejects `return`)
  integer n_fill_now, n_use_now;
  always @(*) begin
    n_fill_now = 0;
    n_use_now  = 0;
    for (int i = 0; i < NSETS; i++) begin
      if (state[2*i +: 2] == 2'd1) n_fill_now = n_fill_now + 1;
      if (state[2*i +: 2] == 2'd3) n_use_now  = n_use_now + 1;
    end
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      st_q <= '0;
      next_fill = 0;
      next_use = 0;
    end else begin
      for (int i = 0; i < NSETS; i++) begin
        logic [1:0] a, b;
        a = st_q[2*i +: 2];
        b = state[2*i +: 2];
        if (a != b) begin
          `CHK(b == a + 2'd1, ("O1 set %0d illegal transition %0d -> %0d", i, a, b))
          if (b == 2'd1) begin
            `CHK(i == next_fill, ("O2 set %0d filled out of order (expected %0d)", i, next_fill))
            next_fill = (next_fill + 1) % NSETS;
          end
          if (b == 2'd3) begin
            `CHK(i == next_use, ("O2 set %0d consumed out of order (expected %0d)", i, next_use))
            next_use = (next_use + 1) % NSETS;
          end
          if (b == 2'd2) `CHK(!pend, ("O6 set %0d sealed with a producer write in flight", i))
`ifndef FORMAL
          if (b == 2'd2) n_fill = n_fill + 1;
          if (b == 2'd0) n_use = n_use + 1;
`endif
        end
      end
      `CHK(n_fill_now <= 1 && n_use_now <= 1,
           ("O3 more than one set owned by one side: %b", state))
      if (wr_v) `CHK(state[2*wr_set +: 2] == 2'd1, ("O4 producer write into set %0d in state %0d",
                                                       wr_set, state[2*wr_set +: 2]))
      if (rd_v) `CHK(state[2*rd_set +: 2] == 2'd3, ("O5 consumer read of set %0d in state %0d",
                                                       rd_set, state[2*rd_set +: 2]))
      st_q <= state;
    end
  end
endmodule
`default_nettype wire
