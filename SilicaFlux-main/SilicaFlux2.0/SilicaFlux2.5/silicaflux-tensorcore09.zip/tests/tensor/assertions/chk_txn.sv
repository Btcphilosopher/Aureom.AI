// =============================================================================
// SilicaFlux TENSORCORE 09 :: transaction checkers
//
// chk_req_rsp     request conservation on a request/response interface (SFB2,
//                 Module 04 local ports):
//   R1  no response while nothing is outstanding (unsolicited / duplicated response)
//   R2  outstanding never exceeds MAX_OUT
//   R3  reset cancels everything (the count restarts at 0, SFB2 R11)
//   outstanding / n_req / n_rsp are outputs: the cocotb test requires
//   outstanding == 0 at the end ("no dropped accepted request").
//
// chk_inorder     issue / completion pairing by identifier:
//   I1  every completion matches the oldest outstanding issue (in order, right id)
//   I2  no completion without an outstanding issue (no duplicate completion)
//   I3  at most DEPTH issues outstanding
//   pending is an output (0 at the end of a test = nothing dropped).
//
// chk_addr_range  address bounds of every accepted request:
//   A1  lo <= addr < hi        A2  addr is a multiple of ALIGN
// =============================================================================
`include "chk_defs.svh"
`default_nettype none
module chk_req_rsp #(
  parameter int MAX_OUT = 4
) (
  input  wire logic clk,
  input  wire logic rst_n,
  input  wire logic req_valid,
  input  wire logic req_ready,
  input  wire logic rsp_valid,
  input  wire logic rsp_ready,
  output integer    outstanding,
  output integer    n_req,
  output integer    n_rsp
);
  `CHK_DECL
  integer max_seen = 0;
  initial begin outstanding = 0; n_req = 0; n_rsp = 0; end
  always @(posedge clk) begin : p
    logic acc, ret;
    if (!rst_n) begin
      outstanding = 0;
    end else begin
      acc = req_valid && req_ready;
      ret = rsp_valid && rsp_ready;
      `CHK(!(ret && outstanding == 0), ("R1 response with nothing outstanding"))
      outstanding = outstanding + (acc ? 1 : 0) - ((ret && outstanding > 0) ? 1 : 0);
      `CHK(outstanding <= MAX_OUT, ("R2 %0d outstanding > MAX_OUT %0d", outstanding, MAX_OUT))
      if (acc) n_req = n_req + 1;
      if (ret) n_rsp = n_rsp + 1;
      if (outstanding > max_seen) max_seen = outstanding;
    end
  end
endmodule

module chk_inorder #(
  parameter int IDW   = 8,
  parameter int DEPTH = 64
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           iss_v,
  input  wire logic [IDW-1:0] iss_id,
  input  wire logic           cpl_v,
  input  wire logic [IDW-1:0] cpl_id,
  output integer              pending
);
  `CHK_DECL
  logic [IDW-1:0] q [0:DEPTH];
  integer n_iss = 0, n_cpl = 0;
  initial pending = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      pending = 0;
    end else begin
      if (cpl_v) begin
        `CHK(pending > 0, ("I2 completion %h without an outstanding issue", cpl_id))
        if (pending > 0) begin
          `CHK(cpl_id === q[0], ("I1 completion id %h, oldest outstanding %h", cpl_id, q[0]))
          for (int i = 0; i < DEPTH; i++) q[i] = q[i+1];
          pending = pending - 1;
        end
        n_cpl = n_cpl + 1;
      end
      if (iss_v) begin
        `CHK(pending < DEPTH, ("I3 more than %0d outstanding", DEPTH))
        if (pending <= DEPTH) begin q[pending] = iss_id; pending = pending + 1; end
        n_iss = n_iss + 1;
      end
    end
  end
endmodule

module chk_addr_range #(
  parameter int AW    = 32,
  parameter int ALIGN = 1
) (
  input wire logic          clk,
  input wire logic          rst_n,
  input wire logic          valid,
  input wire logic [AW-1:0] addr,
  input wire logic [AW:0]   lo,
  input wire logic [AW:0]   hi
);
  `CHK_DECL
  always @(posedge clk) begin
    if (rst_n && valid) begin
      `CHK({1'b0, addr} >= lo && {1'b0, addr} < hi, ("A1 address %h outside [%h, %h)", addr, lo, hi))
      if (ALIGN > 1) `CHK((addr % ALIGN) == 0, ("A2 address %h not %0d-aligned", addr, ALIGN))
    end
  end
endmodule

// "no output before its inputs are final": the n-th `use` event (e.g. the DMA starting to
// drain output tile n) must come after the n-th `ready` event (TC04 committing tile n).
//   P1 n_use < n_ready at every use event
module chk_precedes (
  input wire logic clk,
  input wire logic rst_n,
  input wire logic ev_ready,
  input wire logic ev_use
);
  `CHK_DECL
  integer n_ready = 0, n_use = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      n_ready = 0; n_use = 0;
    end else begin
      if (ev_use) begin
        `CHK(n_use < n_ready, ("P1 item %0d used before it was final (%0d final)", n_use, n_ready))
        n_use = n_use + 1;
      end
      if (ev_ready) n_ready = n_ready + 1;
    end
  end
endmodule
`default_nettype wire

// =============================================================================
// chk_once     identifier-based completion without ordering (the TC07 adapter's load and
//              store channels complete independently):
//   U1 an issued identifier is not issued again while outstanding
//   U2 every completion carries an outstanding identifier (no duplicate / phantom completion)
//   pending = outstanding identifiers (0 at the end: nothing dropped)
// chk_seq      completion records numbered 0, 1, 2 ... since reset, each exactly once:
//   S1 record n carries SEQ n          S2 never more records than accepted commands
// =============================================================================
`default_nettype none
module chk_once #(
  parameter int IDW = 8
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           iss_v,
  input  wire logic [IDW-1:0] iss_id,
  input  wire logic           cpl_v,
  input  wire logic [IDW-1:0] cpl_id,
  output integer              pending
);
  `CHK_DECL
  logic [(1<<IDW)-1:0] out_q;
  initial begin out_q = '0; pending = 0; end
  always @(posedge clk) begin
    if (!rst_n) begin
      out_q = '0; pending = 0;
    end else begin
      if (cpl_v) begin
        `CHK(out_q[cpl_id], ("U2 completion of identifier %0d which is not outstanding", cpl_id))
        if (out_q[cpl_id]) begin out_q[cpl_id] = 1'b0; pending = pending - 1; end
      end
      if (iss_v) begin
        `CHK(!out_q[iss_id], ("U1 identifier %0d issued while outstanding", iss_id))
        if (!out_q[iss_id]) begin out_q[iss_id] = 1'b1; pending = pending + 1; end
      end
    end
  end
endmodule

module chk_seq (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        cmd_v,       // command accepted
  input  wire logic        rec_v,       // record pushed
  input  wire logic [31:0] rec_seq,
  output integer           n_cmd,
  output integer           n_rec
);
  `CHK_DECL
  initial begin n_cmd = 0; n_rec = 0; end
  always @(posedge clk) begin
    if (!rst_n) begin
      n_cmd = 0; n_rec = 0;
    end else begin
      if (cmd_v) n_cmd = n_cmd + 1;
      if (rec_v) begin
        `CHK(rec_seq == 32'(n_rec), ("S1 record SEQ %0d, expected %0d (duplicate or skipped record)", rec_seq, n_rec))
        n_rec = n_rec + 1;
        `CHK(n_rec <= n_cmd, ("S2 %0d records for %0d accepted commands", n_rec, n_cmd))
      end
    end
  end
endmodule
`default_nettype wire
