"""Operand buffer verification: TENSORCORE 03 tensor_operand_buffer.

Model: a byte-exact image of every set's A and B region, updated only by DMA writes
the model predicts to be legal; the expected response code of every DMA request
(RANGE > ALIGN > UNSUP > OWNER) and of every tile (OWNER > EMPTY > LD > A_OVF >
A_RANGE > B_OVF > B_RANGE) is computed from TC03 doc 02 independently of the RTL.
Every delivered k-slice is compared with the model (lanes, masks, k, global k,
origin, first / last, tag, set) - a scoreboard of exact operand bytes, so bank
conflicts, staging, read latency or a lost / reordered word show up as data errors.

Memory scenarios of the brief:
  bank conflicts       lda with an even word stride puts all A lanes in one bank
  simultaneous reads   all lanes and the B row fetcher read every cycle
  DMA writes           fills with random gaps, strobes and response backpressure
  buffer ownership     writes into a set not in FILL -> OWNER, no side effect
  double buffering     fill of set 1 while set 0 is computed, strict ping-pong
  address boundaries   last byte = SET_BYTES-1 accepted, SET_BYTES refused, the hole
                       between the regions, 2^32 overflow, misaligned, reads (UNSUP)
  read/write hazards   1RW banks: DMA writes compete with compute reads (bounded
                       wait, forced writes); TOB_ASSERT checks same-row collisions
  strided access       arbitrary lda / ldb >= matrix width, unaligned bases
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
try:
    import cocotb
    from common.harness import tensor_test, FallingEdge, RisingEdge, ReadOnly, PARAMS, pick, full
except ImportError:
    tensor_test = None

R = int(PARAMS.get("ARRAY_ROWS", 4))
C = int(PARAMS.get("ARRAY_COLS", 4))
ASET = int(PARAMS.get("A_SET_BYTES", 1024))
BSET = int(PARAMS.get("B_SET_BYTES", 1024))
NSETS = int(PARAMS.get("NUM_SETS", 1))
PORT = int(PARAMS.get("PORT_MODE", 1))
A_BANKS = int(PARAMS.get("A_BANKS", 4))
REGION = max(NSETS * ASET, NSETS * BSET)
OK, RANGE, ALIGN, OWNER, UNSUP = 0, 1, 2, 6, 7
T_OK, T_EMPTY, T_LD, T_AOVF, T_ARANGE, T_BOVF, T_BRANGE, T_OWNER = 0, 1, 2, 3, 4, 5, 6, 7
EMPTY, FILL, READY, COMPUTE = 0, 1, 2, 3


def checkers(dut):
    npa = (2 if PARAMS.get("SET_MAP", 0) == 1 and NSETS == 2 else 1) * int(PARAMS.get("A_REPL", 1)) * A_BANKS
    return ["chk_dreq", "chk_drsp", "chk_trsp", "chk_slice", "chk_dtxn", "chk_own", "chk_rst"] + \
        [f"g_arb[{p}].chk_arb_a" for p in range(npa)]


def s8(v):
    return v - 256 if v >= 128 else v


def a_addr(s, off):
    return s * ASET + off


def b_addr(s, off):
    return REGION + s * BSET + off


class Tob:
    def __init__(self, dut, rng, cov):
        self.dut, self.rng, self.cov = dut, rng, cov
        self.A = [bytearray(ASET) for _ in range(NSETS)]
        self.B = [bytearray(BSET) for _ in range(NSETS)]
        self.state = [EMPTY] * NSETS
        self.fp = self.cp = 0
        self.gap_p, self.rbp_p, self.sbp_p = 0.2, 0.2, 0.2
        self.slices_exp, self.tiles_exp = [], []
        self.n_slices = self.n_tiles = self.n_dma = 0
        for s in ("dma_req_valid", "fill_begin_valid", "fill_end_valid", "cmp_begin_valid", "cmp_end_valid",
                  "tile_valid", "perf_clear"):
            getattr(dut, s).value = 0
        dut.dma_rsp_ready.value = 1
        dut.tile_rsp_ready.value = 1
        dut.s_ready.value = 1
        for s in ("dma_req_we", "dma_req_addr", "dma_req_wdata", "dma_req_wstrb", "dma_req_tag", "tile_a_addr",
                  "tile_lda", "tile_b_addr", "tile_ldb", "tile_m0", "tile_n0", "tile_k0", "tile_mat_m",
                  "tile_mat_n", "tile_mat_k", "tile_k", "tile_tag"):
            getattr(dut, s).value = 0
        self.rsp_exp = []
        self.stop = False

    async def start(self):
        d = self.dut
        d.rst_n.value = 0
        for _ in range(3):
            await FallingEdge(d.clk)
        d.rst_n.value = 1
        for _ in range(2):
            await FallingEdge(d.clk)
        self.mon = [cocotb.start_soon(self._rsp_mon()), cocotb.start_soon(self._slice_mon()),
                    cocotb.start_soon(self._tile_mon())]

    # ------------------------------------------------------------------ model
    def dma_code(self, addr, we):
        off = addr
        if off < NSETS * ASET:
            s, reg = off // ASET, "A"
        elif REGION <= off < REGION + NSETS * BSET:
            s, reg = (off - REGION) // BSET, "B"
        else:
            return RANGE, None, None
        if addr % 4:
            return ALIGN, None, None
        if not we:
            return UNSUP, None, None
        if self.state[s] != FILL:
            return OWNER, None, None
        return OK, s, reg

    # ------------------------------------------------------------------ DMA fill port
    async def dma(self, addr, data=0, strb=0xF, we=1, tag=None):
        d = self.dut
        tag = self.n_dma & 0xFF if tag is None else tag
        self.n_dma += 1
        while self.rng.random() < self.gap_p:
            await FallingEdge(d.clk)
        code, s, reg = self.dma_code(addr, we)
        d.dma_req_valid.value, d.dma_req_we.value, d.dma_req_addr.value = 1, we, addr
        d.dma_req_wdata.value, d.dma_req_wstrb.value, d.dma_req_tag.value = data, strb, tag
        while True:
            await RisingEdge(d.clk)
            if int(d.dma_req_ready.value):
                break
            await FallingEdge(d.clk)
        self.rsp_exp.append((tag, code, we))
        if code == OK:
            mem = self.A[s] if reg == "A" else self.B[s]
            base = (addr % ASET) if reg == "A" else ((addr - REGION) % BSET)
            for i in range(4):
                if (strb >> i) & 1:
                    mem[base + i] = (data >> (8 * i)) & 0xFF
        self.cov.hit("dma_code", {OK: "ok", RANGE: "range", ALIGN: "align", OWNER: "owner", UNSUP: "unsup"}[code])
        await FallingEdge(d.clk)
        d.dma_req_valid.value = 0
        return code

    async def _rsp_mon(self):
        d = self.dut
        while True:
            d.dma_rsp_ready.value = int(self.rng.random() >= self.rbp_p)
            await RisingEdge(d.clk)
            if int(d.dma_rsp_valid.value) and int(d.dma_rsp_ready.value):
                assert self.rsp_exp, "DMA response without request"
                tag, code, we = self.rsp_exp.pop(0)
                got = (int(d.dma_rsp_tag.value), int(d.dma_rsp_err_code.value), int(d.dma_rsp_err.value),
                       int(d.dma_rsp_we.value), int(d.dma_rsp_rdata.value))
                assert got == (tag, code, int(code != OK), we, 0), f"DMA response {got}, expected tag/code {tag}/{code}"
            await FallingEdge(d.clk)

    async def fill(self, s_expect, a_img=None, b_img=None, strb_rand=False):
        """Fill the next set: fill_begin, word writes of the given images (random order of
        A and B rows), fill_end."""
        await self.own("fill_begin")
        s = self.fp_open
        words = []
        if a_img is not None:
            words += [("A", o) for o in range(0, min(len(a_img), ASET), 4)]
        if b_img is not None:
            words += [("B", o) for o in range(0, min(len(b_img), BSET), 4)]
        self.rng.shuffle(words)
        for reg, o in words:
            img = a_img if reg == "A" else b_img
            v = int.from_bytes(bytes(img[o:o + 4]).ljust(4, b"\0"), "little")
            st = 0xF
            if strb_rand and self.rng.random() < 0.3:
                st = self.rng.randint(1, 15)
                # write the full word later anyway: model and RTL stay comparable
            addr = a_addr(s, o) if reg == "A" else b_addr(s, o)
            await self.dma(addr, v, st)
            if st != 0xF:
                await self.dma(addr, v, 0xF)
        await self.own("fill_end")
        assert s == s_expect

    # ------------------------------------------------------------------ ownership
    async def own(self, cmd):
        d = self.dut
        v, r = getattr(d, f"{cmd}_valid"), getattr(d, f"{cmd}_ready")
        v.value = 1
        n = 0
        while True:
            await RisingEdge(d.clk)
            if int(r.value):
                break
            n += 1
            assert n < 20000, f"{cmd} never accepted (state {self.state})"
            await FallingEdge(d.clk)
        if cmd == "fill_begin":
            assert self.state[self.fp] == EMPTY
            self.state[self.fp] = FILL
            self.fp_open = self.fp
        elif cmd == "fill_end":
            self.state[self.fp] = READY
            self.fp = (self.fp + 1) % NSETS
        elif cmd == "cmp_begin":
            assert self.state[self.cp] == READY
            self.state[self.cp] = COMPUTE
        else:
            self.state[self.cp] = EMPTY
            self.cp = (self.cp + 1) % NSETS
        await FallingEdge(d.clk)
        v.value = 0
        exp = sum(st << (2 * i) for i, st in enumerate(self.state))
        await ReadOnly()
        assert int(d.set_state.value) == exp, f"set_state {int(d.set_state.value):b}, model {exp:b}"
        await FallingEdge(d.clk)

    # ------------------------------------------------------------------ tiles
    def tile_expect(self, t):
        own = COMPUTE in self.state
        s = self.cp
        eff_m = min(R, t["mat_m"] - t["m0"])
        eff_n = min(C, t["mat_n"] - t["n0"])
        eff_k = min(t["k"], t["mat_k"] - t["k0"])
        if not own:
            return T_OWNER, None
        if t["k"] == 0 or t["m0"] >= t["mat_m"] or t["n0"] >= t["mat_n"] or t["k0"] >= t["mat_k"]:
            return T_EMPTY, None
        if t["lda"] < t["mat_k"] or t["ldb"] < t["mat_n"]:
            return T_LD, None
        alast = t["a"] + (t["m0"] + eff_m - 1) * t["lda"] + t["k0"] + eff_k - 1
        blast = t["b"] + (t["k0"] + eff_k - 1) * t["ldb"] + t["n0"] + eff_n - 1
        if alast >= 1 << 32:
            return T_AOVF, None
        if alast >= ASET:
            return T_ARANGE, None
        if blast >= 1 << 32:
            return T_BOVF, None
        if blast >= BSET:
            return T_BRANGE, None
        sl = []
        for k in range(eff_k):
            av = [s8(self.A[s][t["a"] + (t["m0"] + i) * t["lda"] + t["k0"] + k]) if i < eff_m else 0
                  for i in range(R)]
            bv = [s8(self.B[s][t["b"] + (t["k0"] + k) * t["ldb"] + t["n0"] + j]) if j < eff_n else 0
                  for j in range(C)]
            sl.append(dict(a=av, b=bv, k=k, kg=t["k0"] + k, m0=t["m0"], n0=t["n0"],
                           rm=(1 << eff_m) - 1, cm=(1 << eff_n) - 1, first=int(k == 0), last=int(k == eff_k - 1),
                           tag=t["tag"], set=s))
        return T_OK, (sl, eff_m, eff_n, eff_k)

    async def tile(self, **t):
        d = self.dut
        t.setdefault("tag", self.n_tiles & 0xFF)
        self.n_tiles += 1
        code, info = self.tile_expect(t)
        d.tile_valid.value = 1
        d.tile_a_addr.value, d.tile_lda.value = t["a"], t["lda"]
        d.tile_b_addr.value, d.tile_ldb.value = t["b"], t["ldb"]
        d.tile_m0.value, d.tile_n0.value, d.tile_k0.value = t["m0"], t["n0"], t["k0"]
        d.tile_mat_m.value, d.tile_mat_n.value, d.tile_mat_k.value = t["mat_m"], t["mat_n"], t["mat_k"]
        d.tile_k.value, d.tile_tag.value = t["k"], t["tag"]
        while True:
            await RisingEdge(d.clk)
            if int(d.tile_ready.value):
                break
            await FallingEdge(d.clk)
        self.tiles_exp.append((t["tag"], code, info))
        if code == T_OK:
            self.slices_exp += info[0]
        self.cov.hit("tile_code", ["ok", "empty", "ld", "a_ovf", "a_range", "b_ovf", "b_range", "owner"][code])
        await FallingEdge(d.clk)
        d.tile_valid.value = 0
        return code

    async def _tile_mon(self):
        d = self.dut
        while True:
            d.tile_rsp_ready.value = int(self.rng.random() >= self.rbp_p)
            await RisingEdge(d.clk)
            if int(d.tile_rsp_valid.value) and int(d.tile_rsp_ready.value):
                assert self.tiles_exp, "tile response without tile"
                tag, code, info = self.tiles_exp.pop(0)
                got = (int(d.tile_rsp_tag.value), int(d.tile_rsp_code.value), int(d.tile_rsp_err.value))
                assert got == (tag, code, int(code != T_OK)), f"tile response {got}, expected {(tag, code)}"
                if code == T_OK:
                    _, m, n, k = info
                    assert (int(d.tile_rsp_m.value), int(d.tile_rsp_n.value), int(d.tile_rsp_k.value)) == (m, n, k)
            await FallingEdge(d.clk)

    async def _slice_mon(self):
        d = self.dut
        while True:
            d.s_ready.value = int(self.rng.random() >= self.sbp_p)
            await RisingEdge(d.clk)
            if int(d.s_valid.value) and int(d.s_ready.value):
                assert self.slices_exp, "slice without an accepted tile"
                e = self.slices_exp.pop(0)
                sa, sb = int(d.s_a.value), int(d.s_b.value)
                got = dict(a=[s8((sa >> (8 * i)) & 0xFF) for i in range(R)],
                           b=[s8((sb >> (8 * j)) & 0xFF) for j in range(C)], k=int(d.s_k.value),
                           kg=int(d.s_kg.value), m0=int(d.s_m0.value), n0=int(d.s_n0.value),
                           rm=int(d.s_row_mask.value), cm=int(d.s_col_mask.value), first=int(d.s_first.value),
                           last=int(d.s_last.value), tag=int(d.s_tag.value), set=int(d.s_set.value))
                assert got == e, f"slice mismatch:\n got {got}\n exp {e}"
                self.n_slices += 1
            await FallingEdge(d.clk)

    async def drain(self, limit=200000):
        d = self.dut
        n = 0
        while self.slices_exp or self.tiles_exp or self.rsp_exp:
            await FallingEdge(d.clk)
            n += 1
            assert n < limit, f"drain timeout: {len(self.slices_exp)} slices, {len(self.tiles_exp)} tiles pending"
        while not int(d.engine_idle.value):
            await FallingEdge(d.clk)

    def perf(self, ev):
        return (int(self.dut.perf_cnt.value) >> (32 * ev)) & 0xFFFF_FFFF

    # ------------------------------------------------------------------ helpers
    def rand_img(self, n):
        return bytearray(self.rng.getrandbits(8) for _ in range(n))

    async def matrix_tiles(self, a0, lda, b0, ldb, mm, nn, kk, tk, s_ready_p=None):
        """Issue every (m0, n0, k0) tile of an mm x nn x kk problem with K chunks of tk."""
        for m0 in range(0, mm, R):
            for n0 in range(0, nn, C):
                for k0 in range(0, kk, tk):
                    await self.tile(a=a0, lda=lda, b=b0, ldb=ldb, m0=m0, n0=n0, k0=k0, mat_m=mm, mat_n=nn, mat_k=kk,
                                    k=tk)


if tensor_test is not None:

    async def setup(dut, rng, cov):
        cov.define("dma_code", ["ok", "range", "align", "owner", "unsup"])
        cov.define("tile_code", ["ok", "empty", "ld", "a_ovf", "a_range", "b_ovf", "b_range", "owner"])
        t = Tob(dut, rng, cov)
        await t.start()
        return t

    def problem(rng):
        """A random strided problem that fits one set."""
        while True:
            mm, nn, kk = rng.randint(1, 3 * R), rng.randint(1, 3 * C), rng.randint(1, 60)
            lda = kk + rng.choice([0, 0, 1, 3, 4, 7])
            ldb = nn + rng.choice([0, 1, 2, 5])
            a0, b0 = rng.randint(0, 9), rng.randint(0, 9)
            if a0 + (mm - 1) * lda + kk <= ASET and b0 + (kk - 1) * ldb + nn <= BSET:
                return a0, lda, b0, ldb, mm, nn, kk

    @tensor_test(checkers=checkers)
    async def fill_and_compute_strided(dut, rng, cov):
        """Random strided problems (unaligned bases, lda / ldb > width, partial edge tiles,
        K chunks): every slice exact; DMA fills with gaps, strobes and backpressure."""
        t = await setup(dut, rng, cov)
        for it in range(pick(6, 30)):
            a0, lda, b0, ldb, mm, nn, kk = problem(rng)
            await t.fill(t.fp, t.rand_img(ASET), t.rand_img(BSET), strb_rand=(it % 3 == 0))
            await t.own("cmp_begin")
            tk = rng.choice([1, 3, kk, rng.randint(1, kk)])
            await t.matrix_tiles(a0, lda, b0, ldb, mm, nn, kk, tk)
            await t.drain()
            await t.own("cmp_end")
            cov.hit("problem", "strided")
        assert t.n_slices > 0

    @tensor_test(checkers=checkers)
    async def dma_errors_no_side_effect(dut, rng, cov):
        """RANGE (below / above / the hole between A and B), ALIGN, UNSUP (reads) and OWNER
        (set not in FILL: EMPTY, READY, COMPUTE) are refused and change nothing."""
        t = await setup(dut, rng, cov)
        img_a, img_b = t.rand_img(ASET), t.rand_img(BSET)
        # OWNER while EMPTY
        assert await t.dma(a_addr(0, 0), 0xDEADBEEF) == OWNER
        await t.fill(0, img_a, img_b)
        # OWNER while READY
        assert await t.dma(a_addr(0, 4), 0x11111111) == OWNER
        await t.own("cmp_begin")
        assert await t.dma(b_addr(0, 8), 0x22222222) == OWNER        # OWNER while COMPUTE
        bad = [(NSETS * ASET + 4 if NSETS * ASET < REGION else REGION + NSETS * BSET, RANGE),   # hole / past B
               (REGION + NSETS * BSET + 64, RANGE), ((1 << 32) - 4, RANGE), (a_addr(0, 2), ALIGN),
               (b_addr(0, 1), ALIGN)]
        for addr, code in bad:
            assert await t.dma(addr, 0x33333333) == code, hex(addr)
        assert await t.dma(a_addr(0, 0), 0, we=0) == UNSUP
        assert await t.dma(b_addr(0, 0), 0, we=0) == UNSUP
        # the set content is unchanged: compute reads back exactly the fill image
        await t.tile(a=0, lda=16, b=0, ldb=C, m0=0, n0=0, k0=0, mat_m=R, mat_n=C, mat_k=16, k=16)
        await t.drain()
        await t.own("cmp_end")

    @tensor_test(checkers=checkers)
    async def tile_validation_boundaries(dut, rng, cov):
        """OWNER / EMPTY / LD / A_RANGE / B_RANGE / A_OVF / B_OVF, last byte at SET_BYTES-1."""
        t = await setup(dut, rng, cov)
        assert await t.tile(a=0, lda=4, b=0, ldb=4, m0=0, n0=0, k0=0, mat_m=1, mat_n=1, mat_k=1, k=1) == T_OWNER
        await t.fill(0, t.rand_img(ASET), t.rand_img(BSET))
        await t.own("cmp_begin")
        T = t.tile
        assert await T(a=0, lda=8, b=0, ldb=4, m0=0, n0=0, k0=0, mat_m=4, mat_n=4, mat_k=8, k=0) == T_EMPTY
        assert await T(a=0, lda=8, b=0, ldb=4, m0=4, n0=0, k0=0, mat_m=4, mat_n=4, mat_k=8, k=8) == T_EMPTY
        assert await T(a=0, lda=8, b=0, ldb=4, m0=0, n0=0, k0=8, mat_m=4, mat_n=4, mat_k=8, k=8) == T_EMPTY
        assert await T(a=0, lda=7, b=0, ldb=4, m0=0, n0=0, k0=0, mat_m=4, mat_n=4, mat_k=8, k=8) == T_LD
        assert await T(a=0, lda=8, b=0, ldb=3, m0=0, n0=0, k0=0, mat_m=4, mat_n=4, mat_k=8, k=8) == T_LD
        # exact fit: the last A byte is ASET-1, then one byte more
        k = 16
        a_fit = ASET - ((R - 1) * k + k)
        assert await T(a=a_fit, lda=k, b=0, ldb=C, m0=0, n0=0, k0=0, mat_m=R, mat_n=C, mat_k=k, k=k) == T_OK
        assert await T(a=a_fit + 1, lda=k, b=0, ldb=C, m0=0, n0=0, k0=0, mat_m=R, mat_n=C, mat_k=k, k=k) == T_ARANGE
        b_fit = BSET - ((k - 1) * C + C)
        assert await T(a=0, lda=k, b=b_fit, ldb=C, m0=0, n0=0, k0=0, mat_m=R, mat_n=C, mat_k=k, k=k) == T_OK
        assert await T(a=0, lda=k, b=b_fit + 1, ldb=C, m0=0, n0=0, k0=0, mat_m=R, mat_n=C, mat_k=k, k=k) == T_BRANGE
        assert await T(a=0, lda=(1 << 32) - 1, b=0, ldb=C, m0=0, n0=0, k0=0, mat_m=R, mat_n=C, mat_k=4, k=4) \
            in (T_AOVF,)
        assert await T(a=0, lda=k, b=0, ldb=(1 << 32) - 1, m0=0, n0=0, k0=0, mat_m=R, mat_n=C, mat_k=4, k=4) \
            in (T_BOVF,)
        await t.drain()
        await t.own("cmp_end")

    @tensor_test(checkers=checkers)
    async def bank_conflicts_and_simultaneous_reads(dut, rng, cov):
        """A rows R words apart in the same bank (even word stride) vs an odd word stride: the
        data are exact either way; the conflicting layout records bank conflicts."""
        t = await setup(dut, rng, cov)
        await t.fill(0, t.rand_img(ASET), t.rand_img(BSET))
        await t.own("cmp_begin")
        t.sbp_p = 0.0
        k = 32
        res = {}
        for name, lda in (("same_bank", 4 * A_BANKS * max(1, 32 // (4 * A_BANKS))), ("odd_words", 36)):
            if (R - 1) * lda + k > ASET:
                continue
            c0 = t.perf(11)
            await t.tile(a=0, lda=lda, b=0, ldb=C, m0=0, n0=0, k0=0, mat_m=R, mat_n=C, mat_k=k, k=k)
            await t.drain()
            res[name] = t.perf(11) - c0
            cov.hit("banks", name)
        if R > 1 and A_BANKS > 1 and "same_bank" in res:
            assert res["same_bank"] > 0, f"no bank conflict recorded for the conflicting layout: {res}"
        await t.own("cmp_end")

    @tensor_test(checkers=checkers, skip_if=(NSETS != 2))
    async def double_buffer_ping_pong(dut, rng, cov):
        """Fill set n+1 while set n is computed (DMA writes overlap slice delivery), strict
        alternation, writes into the computed set refused (OWNER), set reuse after release."""
        t = await setup(dut, rng, cov)
        imgs = [(t.rand_img(ASET), t.rand_img(BSET)) for _ in range(pick(6, 16))]
        await t.fill(0, *imgs[0])
        overlap0 = t.perf(19)
        for i in range(len(imgs)):
            await t.own("cmp_begin")
            a0, lda, b0, ldb, mm, nn, kk = problem(rng)
            tiles = cocotb.start_soon(t.matrix_tiles(a0, lda, b0, ldb, mm, nn, kk, rng.randint(1, kk)))
            if i + 1 < len(imgs):
                await t.fill((t.fp), *imgs[i + 1])           # the other set, concurrently
            # a write into the set being computed must be refused
            assert await t.dma(a_addr(t.cp, 0), 0x55AA55AA) == OWNER
            await tiles
            await t.drain()
            await t.own("cmp_end")
            cov.hit("dbuf", "transition")
        assert t.perf(19) > overlap0, "no cycle with a fill write AND a delivered slice: no overlap happened"

    @tensor_test(checkers=checkers)
    async def write_read_contention(dut, rng, cov):
        """1RW banks: a fill of the other set (or of the same set before sealing, NUM_SETS=1:
        sequential) competing with compute reads; writes wait at most WR_STARVE_LIMIT and are
        forced; TOB_ASSERT checks that no same-row read/write is issued in one cycle."""
        t = await setup(dut, rng, cov)
        t.gap_p = 0.0
        t.sbp_p = 0.0
        await t.fill(0, t.rand_img(ASET), t.rand_img(BSET))
        await t.own("cmp_begin")
        k = min(60, ASET // R - 4)
        tiles = cocotb.start_soon(t.matrix_tiles(0, k + 4, 0, C, R, C, k, k))
        if NSETS == 2:
            await t.fill(1, t.rand_img(ASET), t.rand_img(BSET))
        await tiles
        await t.drain()
        await t.own("cmp_end")
        if PORT == 0 and NSETS == 2:
            cov.hit("contention", "forced" if t.perf(15) else "waited")

    @tensor_test(checkers=checkers)
    async def reset_mid_delivery(dut, rng, cov):
        """Hard reset while slices are being delivered: all sets EMPTY, nothing presented, the
        next fill / compute is exact."""
        t = await setup(dut, rng, cov)
        d = dut
        await t.fill(0, t.rand_img(ASET), t.rand_img(BSET))
        await t.own("cmp_begin")
        t.sbp_p = 0.5
        await t.tile(a=0, lda=40, b=0, ldb=C, m0=0, n0=0, k0=0, mat_m=R, mat_n=C, mat_k=40, k=40)
        for _ in range(12):
            await FallingEdge(d.clk)
        d.rst_n.value = 0
        await FallingEdge(d.clk)
        await FallingEdge(d.clk)
        d.rst_n.value = 1
        t.slices_exp.clear()
        t.tiles_exp.clear()
        t.rsp_exp.clear()
        t.state = [EMPTY] * NSETS
        t.fp = t.cp = 0
        await FallingEdge(d.clk)
        await FallingEdge(d.clk)
        assert int(d.set_state.value) == 0 and int(d.s_valid.value) == 0
        await t.fill(0, t.rand_img(ASET), t.rand_img(BSET))
        await t.own("cmp_begin")
        await t.matrix_tiles(0, 16, 0, C, R, C, 16, 8)
        await t.drain()
        await t.own("cmp_end")
        cov.hit("reset", "mid_delivery")


# =============================================================================== pytest runner

def cfg(r=4, c=4, aset=1024, bset=1024, ab=4, bb=2, repl=1, sets=1, smap=0, port=1, rl=1):
    return dict(ARRAY_ROWS=r, ARRAY_COLS=c, A_SET_BYTES=aset, B_SET_BYTES=bset, A_BANKS=ab, B_BANKS=bb,
                A_REPL=repl, NUM_SETS=sets, SET_MAP=smap, PORT_MODE=port, READ_LATENCY=rl)


CONFIGS = [cfg(),                                           # TC08 baseline (4x4, OPB 2048, 1 set)
           cfg(aset=512, bset=512, sets=2),                 # TC08 double buffering
           cfg(r=2, c=2, aset=256, bset=256, ab=2, bb=1, sets=2),   # TC08 2x2
           cfg(r=8, c=8, aset=2048, bset=2048),             # TC08 8x8 sizing
           cfg(aset=512, bset=512, sets=2, port=0, rl=2),   # 1RW banks, 2-cycle SRAM (variant)
           cfg(aset=512, bset=512, sets=2, smap=1, repl=2)]  # split sets, replicated A banks (variant)


def _id(c):
    return (f"{c['ARRAY_ROWS']}x{c['ARRAY_COLS']}_s{c['NUM_SETS']}_a{c['A_SET_BYTES']}_b{c['A_BANKS']}"
            f"_{'1rw' if c['PORT_MODE'] == 0 else '1r1w'}_rl{c['READ_LATENCY']}_map{c['SET_MAP']}_r{c['A_REPL']}")


@pytest.mark.parametrize("cfg", CONFIGS, ids=_id)
def test_operand_buffer(cfg):
    from common import sim
    srcs, incs = sim.tc08_subset(
        "sram_rsp_path.sv", "sram_backend_1rw.sv", "sram_backend_1r1w.sv", "sram_backend_2rw.sv", "sram_sp.sv",
        "sram_generic_1rw.sv", "sram_generic_1r1w.sv", "sram_generic_2rw.sv", "sram_fpga_1rw.sv", "sram_fpga_1r1w.sv",
        "sram_fpga_2rw.sv", "sram_asic_array.sv", "sram_leaf_sky130.sv", "sram_leaf_gf180.sv", "sram_leaf_ihp1p.sv",
        "sram_leaf_ihp2p.sv", "sram_macro_blackboxes.sv", "dma_fifo.sv", "tob_bank_arb.sv", "tob_bank.sv",
        "tob_dbuf_ctrl.sv", "tob_dma_port.sv", "tob_tile_agu.sv", "tob_perf.sv", "tensor_operand_buffer.sv")
    sim.run("operand_buffer", "tb_tob", "test_operand_buffer",
            srcs + sim.checker_sources() + [TT / "operand_buffer" / "tb_tob.sv"], cfg, includes=incs, tag=_id(cfg))
