// =============================================================================
// SilicaFlux TENSORCORE 09 :: tb_tob -- cocotb wrapper of the operand buffer
// DUT: TENSORCORE 03 tensor_operand_buffer, unmodified (TOB_ASSERT on: the
// RTL's own same-row read/write and write-retire assertions report via $error,
// which the runner turns into test failures).
// Checkers
//   chk_dreq / chk_drsp / chk_trsp / chk_slice : stable payload under backpressure
//   chk_dtxn  : DMA-port request conservation (no unsolicited / lost response)
//   chk_own   : ownership protocol, writes only into a FILL set, slices only
//               from the COMPUTE set, a set sealed with no write in flight
//   chk_arb_a[p] : per physical A bank: grant safety (one-hot, only to
//               requesters, work conserving)
//   chk_rst   : nothing presented in reset
// =============================================================================
`timescale 1ns/1ps
`include "tob_defs.svh"
`default_nettype none
module tb_tob #(
  parameter int ARRAY_ROWS   = 4,
  parameter int ARRAY_COLS   = 4,
  parameter int A_SET_BYTES  = 1024,
  parameter int B_SET_BYTES  = 1024,
  parameter int A_BANKS      = 4,
  parameter int B_BANKS      = 2,
  parameter int A_REPL       = 1,
  parameter int NUM_SETS     = 1,
  parameter int SET_MAP      = 0,
  parameter int PORT_MODE    = 1,
  parameter int READ_LATENCY = 1,
  localparam int R = ARRAY_ROWS, C = ARRAY_COLS,
  localparam int SW  = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int RMW = $clog2(R + 1), CNW = $clog2(C + 1),
  localparam int NPA = ((SET_MAP == 1 && NUM_SETS == 2) ? 2 : 1) * A_REPL * A_BANKS
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             dma_req_valid,
  output logic                  dma_req_ready,
  input  wire logic             dma_req_we,
  input  wire logic [31:0]      dma_req_addr,
  input  wire logic [31:0]      dma_req_wdata,
  input  wire logic [3:0]       dma_req_wstrb,
  input  wire logic [7:0]       dma_req_tag,
  output logic                  dma_rsp_valid,
  input  wire logic             dma_rsp_ready,
  output logic [31:0]           dma_rsp_rdata,
  output logic                  dma_rsp_err,
  output logic [2:0]            dma_rsp_err_code,
  output logic                  dma_rsp_we,
  output logic [7:0]            dma_rsp_tag,
  input  wire logic             fill_begin_valid,
  output logic                  fill_begin_ready,
  input  wire logic             fill_end_valid,
  output logic                  fill_end_ready,
  input  wire logic             cmp_begin_valid,
  output logic                  cmp_begin_ready,
  input  wire logic             cmp_end_valid,
  output logic                  cmp_end_ready,
  output logic [SW-1:0]         fill_set,
  output logic [SW-1:0]         cmp_set,
  output logic [NUM_SETS*2-1:0] set_state,
  input  wire logic             tile_valid,
  output logic                  tile_ready,
  input  wire logic [31:0]      tile_a_addr,
  input  wire logic [31:0]      tile_lda,
  input  wire logic [31:0]      tile_b_addr,
  input  wire logic [31:0]      tile_ldb,
  input  wire logic [15:0]      tile_m0,
  input  wire logic [15:0]      tile_n0,
  input  wire logic [16:0]      tile_k0,
  input  wire logic [15:0]      tile_mat_m,
  input  wire logic [15:0]      tile_mat_n,
  input  wire logic [16:0]      tile_mat_k,
  input  wire logic [16:0]      tile_k,
  input  wire logic [7:0]       tile_tag,
  output logic                  tile_rsp_valid,
  input  wire logic             tile_rsp_ready,
  output logic [7:0]            tile_rsp_tag,
  output logic                  tile_rsp_err,
  output logic [3:0]            tile_rsp_code,
  output logic [RMW-1:0]        tile_rsp_m,
  output logic [CNW-1:0]        tile_rsp_n,
  output logic [16:0]           tile_rsp_k,
  output logic                  s_valid,
  input  wire logic             s_ready,
  output logic [R*8-1:0]        s_a,
  output logic [C*8-1:0]        s_b,
  output logic [16:0]           s_k,
  output logic [16:0]           s_kg,
  output logic [15:0]           s_m0,
  output logic [15:0]           s_n0,
  output logic [R-1:0]          s_row_mask,
  output logic [C-1:0]          s_col_mask,
  output logic                  s_first,
  output logic                  s_last,
  output logic [7:0]            s_tag,
  output logic [SW-1:0]         s_set,
  output logic                  busy,
  output logic                  engine_idle,
  input  wire logic             perf_clear,
  output logic [`TOB_NUM_EV*32-1:0] perf_cnt
);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [`TOB_NUM_EV*8-1:0] ev_inc;
  logic [NPA-1:0]           ev_bank_conflict_a;
  /* verilator lint_on UNUSEDSIGNAL */
  tensor_operand_buffer #(
    .ARRAY_ROWS(R), .ARRAY_COLS(C), .WORD_BYTES(4), .A_SET_BYTES(A_SET_BYTES), .B_SET_BYTES(B_SET_BYTES),
    .A_BANKS(A_BANKS), .B_BANKS(B_BANKS), .A_REPL(A_REPL), .NUM_SETS(NUM_SETS), .SET_MAP(SET_MAP),
    .PORT_MODE(PORT_MODE), .READ_LATENCY(READ_LATENCY), .A_STAGE(2), .B_STAGE(4), .WR_STARVE_LIMIT(8),
    .ADDR_W(32), .DMA_BASE(64'h0), .IDX_W(16), .K_W(17), .TAG_W(8), .DMA_RSP_DEPTH(4), .PERF_EN(1), .CNT_W(32)
  ) dut (.*);

  chk_handshake #(.W(1+32+32+4+8)) chk_dreq (.clk(clk), .rst_n(rst_n), .valid(dma_req_valid), .ready(dma_req_ready),
    .data({dma_req_we, dma_req_addr, dma_req_wdata, dma_req_wstrb, dma_req_tag}));
  chk_handshake #(.W(32+1+3+1+8)) chk_drsp (.clk(clk), .rst_n(rst_n), .valid(dma_rsp_valid), .ready(dma_rsp_ready),
    .data({dma_rsp_rdata, dma_rsp_err, dma_rsp_err_code, dma_rsp_we, dma_rsp_tag}));
  chk_handshake #(.W(8+1+4+RMW+CNW+17)) chk_trsp (.clk(clk), .rst_n(rst_n), .valid(tile_rsp_valid),
    .ready(tile_rsp_ready), .data({tile_rsp_tag, tile_rsp_err, tile_rsp_code, tile_rsp_m, tile_rsp_n, tile_rsp_k}));
  chk_handshake #(.W(R*8+C*8+17+17+16+16+R+C+2+8+SW)) chk_slice (.clk(clk), .rst_n(rst_n), .valid(s_valid),
    .ready(s_ready), .data({s_a, s_b, s_k, s_kg, s_m0, s_n0, s_row_mask, s_col_mask, s_first, s_last, s_tag, s_set}));
  integer d_out, d_req, d_rsp;
  chk_req_rsp #(.MAX_OUT(6)) chk_dtxn (.clk(clk), .rst_n(rst_n), .req_valid(dma_req_valid), .req_ready(dma_req_ready),
    .rsp_valid(dma_rsp_valid), .rsp_ready(dma_rsp_ready), .outstanding(d_out), .n_req(d_req), .n_rsp(d_rsp));
  chk_ownership #(.NSETS(NUM_SETS), .SW(SW)) chk_own (.clk(clk), .rst_n(rst_n), .state(set_state),
    .wr_v(dut.wr_go), .wr_set(dut.wr_set), .rd_v(s_valid && s_ready), .rd_set(s_set), .pend(dut.u_dma.hold_valid));
  chk_reset #(.N(3), .NK(4)) chk_rst (.clk(clk), .rst_n(rst_n), .quiet({dma_rsp_valid, tile_rsp_valid, s_valid}),
    .known({dma_req_ready, tile_ready, s_valid, engine_idle}));

  for (genvar p = 0; p < NPA; p++) begin : g_arb
    chk_arb #(.N(R)) chk_arb_a (.clk(clk), .rst_n(rst_n), .req(dut.g_abank[p].req), .blk(dut.a_blk[p*R +: R]),
                                .gnt(dut.a_gnt[p*R +: R]));
  end
endmodule
`default_nettype wire
