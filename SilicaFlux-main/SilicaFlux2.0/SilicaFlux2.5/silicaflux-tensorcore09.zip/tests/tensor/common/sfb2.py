"""SFB2 slave memory model (DataFabric PROTOCOL.md) for the cocotb benches.

Implements the slave side of the rules the master is checked against:
  R5  exactly one response per accepted request, in acceptance order, >= 1 cycle later
  R7  a write is performed only when it is answered (so completion == written)
  R8  an error response has no side effect and carries rdata = 0
  R4  a presented response is held until rsp_ready
Knobs (all deterministic from the test's RNG): latency range, request backpressure
probability, error windows (word addresses, read and/or write), "black hole"
windows (never answered until reset) and "late" windows (extra delay).
Every accepted transaction is logged for the DMA scoreboards:
  reads  -> [(cycle, addr, error)]
  writes -> [(cycle, addr, strobe, wdata, error)]
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass

from cocotb.triggers import FallingEdge, RisingEdge


@dataclass
class Window:
    lo: int
    hi: int
    read: bool = False
    write: bool = False
    black: bool = False      # never answered
    delay: int = 0           # extra latency

    def hit(self, a: int) -> bool:
        return self.lo <= a < self.hi


class Txn:
    __slots__ = ("write", "addr", "wdata", "wstrb", "due", "cycle", "idx")

    def __init__(self, write, addr, wdata, wstrb, due, cycle):
        self.write, self.addr, self.wdata, self.wstrb, self.due, self.cycle = write, addr, wdata, wstrb, due, cycle
        self.idx = -1


class Sfb2Memory:
    QMAX = 64

    def __init__(self, dut, lo: int, hi: int, rng, prefix: str = "m_"):
        self.dut, self.lo, self.hi, self.rng, self.p = dut, lo, hi, rng, prefix
        self.mem = bytearray(hi - lo)
        self.lat = (1, 1)
        self.bp_p = 0.0
        self.windows: list[Window] = []
        self.q: deque[Txn] = deque()
        self.cur = None
        self.cycle = 0
        self.reads, self.writes = [], []
        self.n_err = 0
        self.max_outstanding = 0
        self._sig = {n: getattr(dut, prefix + n) for n in ("req_valid", "req_ready", "req_write", "req_addr",
                                                            "req_wdata", "req_wstrb", "rsp_valid", "rsp_ready",
                                                            "rsp_rdata", "rsp_error")}
        self._sig["req_ready"].value = 0
        self._sig["rsp_valid"].value = 0
        self._sig["rsp_rdata"].value = 0
        self._sig["rsp_error"].value = 0

    # ------------------------------------------------------------------ memory helpers
    def inwin(self, a: int) -> bool:
        return self.lo <= a < self.hi

    def write_bytes(self, addr: int, data: bytes) -> None:
        self.mem[addr - self.lo:addr - self.lo + len(data)] = data

    def read_bytes(self, addr: int, n: int) -> bytes:
        return bytes(self.mem[addr - self.lo:addr - self.lo + n])

    def reset_windows(self) -> None:
        self.windows = []

    def _error(self, t: Txn) -> bool:
        if not self.inwin(t.addr) or t.addr % 4:
            return True
        return any(w.hit(t.addr) and (w.write if t.write else w.read) for w in self.windows)

    def _extra(self, a: int) -> int | None:
        for w in self.windows:
            if w.hit(a):
                if w.black:
                    return None
                if w.delay:
                    return w.delay
        return 0

    # ------------------------------------------------------------------ the slave process
    async def run(self):
        s = self._sig
        rst = self.dut.rst_n
        while True:
            await FallingEdge(self.dut.clk)
            self.cycle += 1
            if not int(rst.value):
                self.q.clear()
                self.cur = None
                s["rsp_valid"].value = 0
                s["req_ready"].value = 0
                continue
            if self.cur is None and self.q and self.q[0].due is not None and self.q[0].due <= self.cycle:
                t = self.q.popleft()
                err = self._error(t)
                rdata = 0
                if err:
                    self.n_err += 1
                elif t.write:
                    o = t.addr - self.lo
                    for i in range(4):
                        if (t.wstrb >> i) & 1:
                            self.mem[o + i] = (t.wdata >> (8 * i)) & 0xFF        # R7: performed when answered
                else:
                    o = t.addr - self.lo
                    rdata = int.from_bytes(self.mem[o:o + 4], "little")
                (self.writes if t.write else self.reads)[t.idx][-1] = err          # log: answered with error?
                self.cur = t
                s["rsp_valid"].value = 1
                s["rsp_rdata"].value = rdata
                s["rsp_error"].value = int(err)
            elif self.cur is None:
                s["rsp_valid"].value = 0
            ready = int(len(self.q) < self.QMAX - 2 and self.rng.random() >= self.bp_p)
            s["req_ready"].value = ready
            await RisingEdge(self.dut.clk)
            if self.cur is not None and int(s["rsp_ready"].value):
                self.cur = None
            if ready and int(s["req_valid"].value):
                w = int(s["req_write"].value)
                a = int(s["req_addr"].value)
                lat = self.rng.randint(*self.lat)
                ex = self._extra(a)
                due = None if ex is None else self.cycle + max(1, lat) + ex
                t = Txn(w, a, int(s["req_wdata"].value) if w else 0, int(s["req_wstrb"].value) if w else 0, due,
                        self.cycle)
                if w:
                    self.writes.append([self.cycle, a, t.wstrb, t.wdata, None])
                    t.idx = len(self.writes) - 1
                else:
                    self.reads.append([self.cycle, a, None])
                    t.idx = len(self.reads) - 1
                self.q.append(t)
                self.max_outstanding = max(self.max_outstanding, len(self.q) + (self.cur is not None))
