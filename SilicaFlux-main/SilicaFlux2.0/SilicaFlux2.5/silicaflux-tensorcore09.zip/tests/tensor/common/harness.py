"""In-simulation helpers shared by every cocotb test of TENSORCORE 09.

* ``tensor_test``  decorator: deterministic per-test RNG, clock, end-of-test
  collection of the SV checker counters, coverage dump.
* ``Checkers``     reads n_err / n_chk of the SV assertion checkers by instance path.
* ``Coverage``     a small functional-coverage collector (named coverpoints with
  declared bins); every test writes build/results/coverage/<run>/<test>.json and the
  report merges them.
Driving discipline: testbench inputs change only at the FALLING clock edge; monitors
sample at the RISING edge (pre-update values = what the RTL sampled).  This removes
every race between cocotb writes and RTL processes.
"""
from __future__ import annotations

import functools
import json
import os
import random
import re
from pathlib import Path

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import FallingEdge, RisingEdge, ReadOnly, Timer

SEED = int(os.environ.get("TENSOR_SEED", "20261108"), 0)
LEVEL = os.environ.get("TENSOR_LEVEL", "quick")
SUITE = os.environ.get("TENSOR_SUITE", "unknown")
RUN = os.environ.get("TENSOR_RUN_NAME", "run")
RESULTS = Path(os.environ.get("TENSOR_RESULTS", "build/results"))
PARAMS = json.loads(os.environ.get("TENSOR_PARAMS", "{}"))


def full() -> bool:
    return LEVEL == "full"


def pick(quick, full_):
    return full_ if LEVEL == "full" else quick


# ----------------------------------------------------------------------------- handles

def resolve(dut, path: str):
    """'a.b[3].c' -> handle."""
    h = dut
    for part in path.split("."):
        m = re.fullmatch(r"(\w+)((?:\[\d+\])*)", part)
        if not m:
            raise ValueError(path)
        h = getattr(h, m.group(1))
        for idx in re.findall(r"\[(\d+)\]", m.group(2)):
            h = h[int(idx)]
    return h


def sval(h) -> int:
    """Signed integer value of a handle."""
    return h.value.to_signed()


def uval(h) -> int:
    return int(h.value)


# ----------------------------------------------------------------------------- SV checkers

class Checkers:
    """SV checker counters are global to the simulation; a test looks at the increase
    since its own start, so one failing test cannot make the following ones fail."""

    def __init__(self, dut, paths: list[str]):
        self.dut = dut
        self.paths = list(paths)
        self.base = self._read()

    def _read(self) -> dict:
        out = {}
        for p in self.paths:
            h = resolve(self.dut, p)
            out[p] = dict(n_err=int(h.n_err.value), n_chk=int(h.n_chk.value))
        return out

    def report(self) -> dict:
        now = self._read()
        return {p: dict(n_err=now[p]["n_err"] - self.base[p]["n_err"], n_chk=now[p]["n_chk"] - self.base[p]["n_chk"])
                for p in self.paths}

    def assert_clean(self, require_active: bool = True) -> dict:
        rep = self.report()
        bad = {p: r for p, r in rep.items() if r["n_err"]}
        assert not bad, f"SV checkers reported errors: {bad}"
        if require_active:
            idle = [p for p, r in rep.items() if r["n_chk"] == 0]
            assert not idle, f"vacuous checkers (never evaluated): {idle}"
        return rep


# ----------------------------------------------------------------------------- coverage

class Coverage:
    """cp -> {bin: hits}; bins declared up front so the denominator is honest."""

    def __init__(self):
        self.cps: dict[str, dict[str, int]] = {}

    def define(self, cp: str, bins) -> None:
        d = self.cps.setdefault(cp, {})
        for b in bins:
            d.setdefault(str(b), 0)

    def hit(self, cp: str, b, n: int = 1) -> None:
        d = self.cps.setdefault(cp, {})
        d[str(b)] = d.get(str(b), 0) + n

    def dump(self, test: str, extra: dict | None = None) -> None:
        d = RESULTS / "coverage" / SUITE / RUN
        d.mkdir(parents=True, exist_ok=True)
        (d / f"{test}-{SEED}.json").write_text(json.dumps(dict(suite=SUITE, run=RUN, test=test, seed=SEED,
                                                               coverpoints=self.cps, checkers=extra or {}),
                                                          indent=0))


def corner_bin(v: int, w: int = 8) -> str:
    lo, hi = -(1 << (w - 1)), (1 << (w - 1)) - 1
    if v == lo:
        return "min"
    if v == hi:
        return "max"
    if v == 0:
        return "zero"
    if v in (1, -1):
        return "pm1"
    return "neg" if v < 0 else "pos"


CORNER_BINS = ("min", "max", "zero", "pm1", "neg", "pos")


# ----------------------------------------------------------------------------- test decorator

def tensor_test(checkers=None, clock: str = "clk", period_ns: int = 10, timeout_us: float | None = 20000,
                skip_if=None, reset_sig: str | None = "rst_n"):
    """Decorate `async def body(dut, rng, cov)`; `checkers` = list of paths or callable(dut)->list."""
    def deco(body):
        @functools.wraps(body)
        async def wrapper(dut):
            rng = random.Random(f"{SEED}:{SUITE}:{body.__name__}")
            cov = Coverage()
            if reset_sig and hasattr(dut, reset_sig):
                getattr(dut, reset_sig).value = 0          # defined reset level before the first edge
            if clock and hasattr(dut, clock):
                Clock(getattr(dut, clock), period_ns, unit="ns").start()
            chk = None
            if checkers is not None:
                chk = Checkers(dut, checkers(dut) if callable(checkers) else checkers)
            await body(dut, rng, cov)
            rep = {}
            if chk is not None:
                await FallingEdge(getattr(dut, clock))        # let the last edge's checks run
                rep = chk.assert_clean()
            cov.dump(body.__name__, rep)
        kw = {}
        if timeout_us:
            # simulated-time watchdog: a hung test fails instead of blocking the regression
            kw = dict(timeout_time=timeout_us * (10 if LEVEL == "full" else 1), timeout_unit="us")
        if skip_if is not None:
            kw["skip"] = bool(skip_if)
        return cocotb.test(**kw)(wrapper)
    return deco


async def reset(dut, cycles: int = 4, sig: str = "rst_n") -> None:
    r = getattr(dut, sig)
    await FallingEdge(dut.clk)
    r.value = 0
    for _ in range(cycles):
        await FallingEdge(dut.clk)
    r.value = 1
    await FallingEdge(dut.clk)


async def cycles(dut, n: int) -> None:
    for _ in range(n):
        await FallingEdge(dut.clk)


__all__ = ["tensor_test", "Checkers", "Coverage", "reset", "cycles", "resolve", "sval", "uval", "full", "pick",
           "FallingEdge", "RisingEdge", "ReadOnly", "Timer", "corner_bin", "CORNER_BINS", "SEED", "LEVEL", "PARAMS"]
