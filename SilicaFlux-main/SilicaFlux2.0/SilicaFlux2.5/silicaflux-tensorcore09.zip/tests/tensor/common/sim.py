"""Simulation runner of the TENSORCORE 09 suites (cocotb 2.x + Icarus Verilog 12).

``run()`` builds a testbench wrapper once per parameter set, runs one cocotb test
module on it with a deterministic seed, records the result and, when a test fails,
re-runs exactly that test with the same seed and waveform dumping enabled, saving
under regression/failures/<suite>/... :
    waves.fst, sim.log, repro.json (seed, parameters, testcase, re-run command).

Environment
  TENSOR_SEED    base seed (default 20261108).  Every cocotb test derives its own
                 stream as Random(f"{seed}:{suite}:{test}"), so tests are independent
                 and reproducible one by one.
  TENSOR_LEVEL   quick (default) | full - the amount of randomisation per test.
  TENSOR_WAVES   1: dump waves for every run (not only failures).
  TENSOR_NO_RERUN 1: do not re-run failures with waves.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

TT = Path(__file__).resolve().parents[1]
RTL = TT / "build" / "rtl"
# TENSOR_RTL_TC08 points the suites at another copy of the TC08 tree (mutation campaign only)
TC08 = Path(os.environ.get("TENSOR_RTL_TC08", RTL / "tc08"))
TC01 = RTL / "tc01"
ASSERT = TT / "assertions"
FAIL_DIR = TT / "regression" / "failures"
RESULTS = Path(os.environ.get("TENSOR_RESULTS_DIR", TT / "build" / "results"))
MUTANT = os.environ.get("TENSOR_MUTANT", "")
DEFAULT_SEED = 20261108


def seed() -> int:
    return int(str(os.environ.get("TENSOR_SEED", DEFAULT_SEED)), 0)


def level() -> str:
    lv = os.environ.get("TENSOR_LEVEL", "quick")
    if lv not in ("quick", "full"):
        raise ValueError("TENSOR_LEVEL must be quick or full")
    return lv


def require_rtl() -> None:
    if not (TC08 / "rtl" / "silicaflux_tensor_unit.sv").exists():
        import pytest
        pytest.fail("RTL not staged: run `make tensor-rtl` (tests/tensor/scripts/stage_rtl.py)", pytrace=False)


# ----------------------------------------------------------------------------- RTL file lists

def tc08_files_f() -> tuple[list[Path], list[Path]]:
    """(sources, include dirs) of the complete tensor unit, from TC08 rtl/files.f."""
    srcs, incs = [], []
    for line in (TC08 / "rtl" / "files.f").read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("//") or line.startswith("#"):
            continue
        if line.startswith("+incdir+"):
            incs.append(TC08 / line[len("+incdir+"):])
        else:
            srcs.append(TC08 / line)
    return srcs, incs


def tc08_subset(*names: str) -> tuple[list[Path], list[Path]]:
    """Sources of files.f whose file name is in `names` (dependency order kept)."""
    srcs, incs = tc08_files_f()
    want = set(names)
    got = [s for s in srcs if s.name in want]
    missing = want - {s.name for s in got}
    if missing:
        raise FileNotFoundError(f"not in TC08 files.f: {sorted(missing)}")
    return got, incs


def checker_sources() -> list[Path]:
    return sorted(p for p in ASSERT.glob("chk_*.sv"))


# ----------------------------------------------------------------------------- results

def _parse_xml(xml: Path) -> list[dict]:
    out = []
    if not xml.exists():
        return out
    for tc in ET.parse(xml).getroot().iter("testcase"):
        st = "passed"
        msg = ""
        for child in tc:
            if child.tag in ("failure", "error"):
                st = "failed"
                msg = (child.get("message") or "")[:400]
            elif child.tag == "skipped":
                st = "skipped"
        props = {p.get("name"): p.get("value") for p in tc.iter("property")}
        sim_ns = 0.0
        if "sim_time_start" in props and "sim_time_stop" in props:
            sim_ns = float(props["sim_time_stop"]) - float(props["sim_time_start"])
        out.append(dict(name=tc.get("name"), status=st, time=float(tc.get("time") or 0),
                        sim_time_ns=sim_ns, message=msg))
    return out


_RTL_ERR = re.compile(r"^(ERROR|FATAL): \S+:\d+:")
_RUNNING = re.compile(r"running (\S+) \(\d+/\d+\)")


def rtl_errors(log: Path) -> dict[str, list[str]]:
    """RTL $error / $fatal lines printed by Icarus, attributed to the cocotb test running then.
    The RTL's own assertions (TOB_ASSERT, SRAMLIB_ASSERT, DataFabric / TC07 / TC08 checks) report
    this way; a cocotb test does not see them unless the log is scanned."""
    out: dict[str, list[str]] = {}
    if not log.exists():
        return out
    cur = "<elaboration>"
    for line in log.read_text(errors="replace").splitlines():
        m = _RUNNING.search(line)
        if m:
            cur = m.group(1).split(".")[-1]
            continue
        if _RTL_ERR.match(line):
            out.setdefault(cur, []).append(line.strip())
    return out


def _test(runner, **kw) -> None:
    """runner.test() exits with SystemExit(1) when a cocotb test fails; the XML is what counts."""
    try:
        runner.test(**kw)
    except SystemExit:
        pass


def _key(d: dict) -> str:
    return hashlib.sha1(json.dumps(d, sort_keys=True, default=str).encode()).hexdigest()[:10]


def run(suite: str, toplevel: str, test_module: str, sources: list[Path], parameters: dict | None = None,
        includes: list[Path] | None = None, defines: dict | None = None, testcase: str | list | None = None,
        tag: str = "", extra_env: dict | None = None, test_dir: Path | None = None) -> list[dict]:
    """Build + run one cocotb module; returns the per-test results; raises on any failure."""
    from cocotb_tools.runner import get_runner
    require_rtl()
    parameters = dict(parameters or {})
    includes = [Path(p) for p in (includes or [])] + [ASSERT]
    defines = dict(defines or {})
    defines.setdefault("TOB_ASSERT", 1)
    defines.setdefault("SRAMLIB_ASSERT", 1)
    test_dir = Path(test_dir or (TT / suite))
    key = _key(dict(top=toplevel, p=parameters, d=defines, s=[str(s) for s in sources]))
    name = f"{toplevel}-{tag or key}"
    build_dir = TT / "build" / ("sim" if not MUTANT else f"mutants/{MUTANT}/sim") / suite / name
    waves_all = os.environ.get("TENSOR_WAVES") == "1"
    sd = seed()
    if testcase is None and os.environ.get("TENSOR_TESTCASE"):
        testcase = os.environ["TENSOR_TESTCASE"].split(",")
    env = {"TENSOR_SEED": str(sd), "TENSOR_LEVEL": level(), "TENSOR_SUITE": suite,
           "TENSOR_PARAMS": json.dumps(parameters), "TENSOR_RESULTS": str(RESULTS),
           "TENSOR_RUN_NAME": name, "PYTHONPATH": os.pathsep.join([str(TT), str(test_dir),
                                                                   os.environ.get("PYTHONPATH", "")]),
           "COCOTB_ANSI_OUTPUT": "0"}
    env.update(extra_env or {})
    runner = get_runner("icarus")
    t0 = time.time()
    runner.build(sources=[str(s) for s in sources], includes=[str(i) for i in includes], defines=defines,
                 parameters=parameters, hdl_toplevel=toplevel, build_dir=str(build_dir),
                 build_args=["-g2012"], timescale=("1ns", "1ps"), waves=True, always=False,
                 log_file=str(build_dir / "build.log"))
    xml = build_dir / f"results_{sd}.xml"
    if xml.exists():
        xml.unlink()
    _test(runner, test_module=test_module, hdl_toplevel=toplevel, test_dir=str(test_dir), build_dir=str(build_dir),
          seed=sd, extra_env=env, results_xml=str(xml), testcase=testcase, waves=waves_all,
          log_file=str(build_dir / f"sim_{sd}.log"))
    res = _parse_xml(xml)
    errs = rtl_errors(build_dir / f"sim_{sd}.log")
    for r in res:
        e = errs.get(r["name"].split(".")[-1])
        if e and r["status"] != "skipped":
            r["status"] = "failed"
            r["message"] = (f"{len(e)} RTL $error line(s): " + " | ".join(e[:3]) + " ; " + r["message"])[:600]
    if "<elaboration>" in errs:
        res.append(dict(name="<elaboration>", status="failed", time=0, sim_time_ns=0,
                        message="RTL $error during elaboration: " + " | ".join(errs["<elaboration>"][:3])))
    wall = time.time() - t0
    failed = [r for r in res if r["status"] == "failed"]
    rec = dict(suite=suite, toplevel=toplevel, run=name, module=test_module, seed=sd, level=level(),
               parameters=parameters, tests=res, wall_s=round(wall, 2), failures=[])
    if not res:
        failed = [dict(name="<no results: simulator crashed or test module failed to import>", status="failed",
                       message="see " + str(build_dir / f"sim_{sd}.log"))]
        rec["tests"] = failed
    if failed and os.environ.get("TENSOR_NO_RERUN") != "1":
        for f in failed:
            rec["failures"].append(_capture_failure(runner, suite, toplevel, test_module, test_dir, build_dir,
                                                    name, parameters, f["name"], env, sd))
    RESULTS.mkdir(parents=True, exist_ok=True)
    out = RESULTS / suite
    out.mkdir(parents=True, exist_ok=True)
    (out / f"{name}-{sd}.json").write_text(json.dumps(rec, indent=1))
    if failed:
        lines = [f"{len(failed)}/{len(res) or 1} cocotb tests failed in {name} (seed {sd}):"]
        for f in failed:
            lines.append(f"  {f['name']}: {f.get('message', '')}")
        for c in rec["failures"]:
            lines.append(f"  saved: {c.get('dir')}")
        raise AssertionError("\n".join(lines))
    return res


def _capture_failure(runner, suite, toplevel, test_module, test_dir, build_dir, name, params, test, env, sd) -> dict:
    """Re-run one failing test with waves; keep waves + log + repro.json."""
    dst = FAIL_DIR / suite / name / f"{test.split('.')[-1]}-seed{sd}"
    if dst.exists():
        shutil.rmtree(dst)
    dst.mkdir(parents=True)
    info = dict(suite=suite, toplevel=toplevel, module=test_module, test=test, seed=sd, level=env["TENSOR_LEVEL"],
                parameters=params,
                rerun=f"TENSOR_SEED={sd} TENSOR_LEVEL={env['TENSOR_LEVEL']} TENSOR_TESTCASE={test.split('.')[-1]} "
                      f"TENSOR_WAVES=1 python3 -m pytest tests/tensor/{suite} -k '{name.split('-', 1)[-1]}'")
    try:
        xml = build_dir / f"rerun_{sd}.xml"
        _test(runner, test_module=test_module, hdl_toplevel=toplevel, test_dir=str(test_dir),
              build_dir=str(build_dir), seed=sd, extra_env=env, results_xml=str(xml),
              testcase=test.split(".")[-1], waves=True, log_file=str(dst / "sim.log"))
        for ext in ("fst", "vcd"):
            for w in build_dir.glob(f"*.{ext}"):
                shutil.copy(w, dst / f"waves.{ext}")
        info["rerun_result"] = _parse_xml(xml)
    except Exception as e:                                # noqa: BLE001 - keep the evidence we have
        info["rerun_error"] = repr(e)
    (dst / "repro.json").write_text(json.dumps(info, indent=1))
    return dict(test=test, dir=str(dst.relative_to(TT)))
