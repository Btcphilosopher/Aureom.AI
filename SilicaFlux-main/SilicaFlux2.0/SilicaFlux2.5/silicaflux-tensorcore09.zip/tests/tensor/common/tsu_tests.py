"""Shared pieces of the suites that run on the complete tensor unit (integration/, tile_controller/
test_scheduler.py, dma/): configuration, setup, the end-of-test closure checks, and the pytest
runner that builds integration/tb_tsu.sv."""
from __future__ import annotations

from pathlib import Path

from common.harness import FallingEdge, PARAMS
from common.tsu_env import TsuEnv, Cmd, Alloc, make_gemm, Window, T

TT = Path(__file__).resolve().parents[1]

CHECKERS = ["chk_cq", "chk_cplq", "chk_sfb_req", "chk_sfb_txn", "chk_sfb_addr", "chk_desc", "chk_rec",
            "chk_op_own", "chk_ob_own", "chk_commit", "chk_pairing", "chk_rst"]


def hw_from_params(p=PARAMS) -> T.HwConfig:
    return T.HwConfig(rows=int(p.get("ROWS", 4)), cols=int(p.get("COLS", 4)), tile_k=int(p.get("TK", 64)),
                      opb=int(p.get("OPB", 2048)), banks=int(p.get("NB", 4)), quant=bool(int(p.get("QUANT", 0))),
                      dbuf=bool(int(p.get("DBUF", 0))), mem_lo=int(p.get("MEM_LO", 0x1000_0000)),
                      mem_hi=int(p.get("MEM_HI", 0x1010_0000)), k_max=int(p.get("KMAX", 131071)),
                      max_out=int(p.get("MAXOUT", 4)), cmdq=int(p.get("CMDQ", 4)), cplq=int(p.get("CPLQ", 4)),
                      wdog_log2=int(p.get("WDOG", 16)))


HW = hw_from_params()


async def setup(dut, rng, cov, streams=False, err_cont=True, fill=True) -> TsuEnv:
    for cp, bins in (("records", ["ok", "error", "skipped"]),):
        cov.define(cp, bins)
    env = TsuEnv(dut, rng, cov, HW)
    if fill:
        env.fill_random()
    await env.start(monitor_streams=streams)
    await env.set_ctrl(err_cont)
    env.perf0 = await env.perf()
    return env


async def finish(env: TsuEnv, traffic=True, counters=True, streams=True):
    """Closure checks: memory image, exact bus traffic, counters, scheduler streams, and the
    SV-side conservation counters (no accepted command / descriptor / bus transaction lost)."""
    env.check_memory()
    if traffic:
        env.check_traffic()
    if counters:
        await env.check_counters(env.perf0)
    if streams and env.streams is not None:
        env.check_streams()
    d = env.dut
    for _ in range(4):
        await FallingEdge(d.clk)
    assert int(d.chk_rec.n_cmd.value) == int(d.chk_rec.n_rec.value) == env.n_sub, \
        f"accepted {int(d.chk_rec.n_cmd.value)} commands, {int(d.chk_rec.n_rec.value)} records, host {env.n_sub}"
    assert int(d.desc_pending.value) == 0, "DMA descriptors accepted and never completed"
    assert int(d.sfb_out.value) == 0 and not env.mem.q and env.mem.cur is None, "SFB2 transactions left outstanding"
    assert int(d.pc_viol.value) == 0, f"DataFabric sfb_protocol_checker: {int(d.pc_viol.value)} violations"


def gemm_cmd(g: T.Gemm, label="") -> Cmd:
    return Cmd(g.words(), g, label or f"{g.m}x{g.n}x{g.k}")


def cfg(rows=4, cols=4, tk=64, opb=2048, nb=4, quant=0, dbuf=0, maxout=4, kmax=131071, cmdq=4, cplq=4, wdog=16,
        mem_lo=0x1000_0000, mem_bytes=1 << 20, fi=0):
    return dict(ROWS=rows, COLS=cols, TK=tk, OPB=opb, NB=nb, QUANT=quant, DBUF=dbuf, MAXOUT=maxout, KMAX=kmax,
                CMDQ=cmdq, CPLQ=cplq, WDOG=wdog, FI=fi, MEM_LO=mem_lo, MEM_HI=mem_lo + mem_bytes)


def cfg_id(c):
    s = f"{c['ROWS']}x{c['COLS']}_tk{c['TK']}_opb{c['OPB']}"
    if c["QUANT"]:
        s += "_q8"
    if c["DBUF"]:
        s += "_dbuf"
    if c["MAXOUT"] != 4:
        s += f"_mo{c['MAXOUT']}"
    if c["KMAX"] != 131071:
        s += f"_kmax{c['KMAX']}"
    if c["WDOG"] != 16:
        s += f"_wd{c['WDOG']}"
    if c["CPLQ"] != 4 or c["CMDQ"] != 4:
        s += f"_q{c['CMDQ']}{c['CPLQ']}"
    if c["FI"]:
        s += "_fi"
    return s


def run_tsu(suite: str, module: str, c: dict, test_dir: Path):
    from common import sim
    srcs, incs = sim.tc08_files_f()
    df_chk = sim.TC08 / "third_party" / "silicaflux-datafabric" / "tb" / "common" / "sfb_protocol_checker.sv"
    sim.run(suite, "tb_tsu", module, srcs + sim.checker_sources() + [df_chk, TT / "integration" / "tb_tsu.sv"], c,
            includes=incs, tag=cfg_id(c), test_dir=test_dir)


__all__ = ["setup", "finish", "gemm_cmd", "cfg", "cfg_id", "run_tsu", "HW", "CHECKERS", "Alloc", "make_gemm", "Cmd",
           "Window", "T", "TsuEnv"]
