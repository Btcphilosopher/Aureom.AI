"""Verification environment of silicaflux_tensor_unit (TENSORCORE 08) for cocotb.

  host BFM ── register page (rb_*) ──► DUT ── SFB2 ──► Sfb2Memory (latency, backpressure, error windows)
             ▲ records (CPL0..5)                  │
             └── scoreboards ◄── monitors ◄───────┘  (+ SV checkers in integration/tb_tsu.sv)

Scoreboards (all against reference_models/tsu_model.py, never against the RTL):
  records   every field of every completion record (TID, OPCODE, ERR_CODE, STATUS, IRQ, SAT,
            DETAIL, COUNT, ERR_ADDR, SEQ, TILES; CYCLES > 0), stop-on-error / SKIPPED rules
  memory    the whole memory window after the run: every byte equals the expected image
            (C of successful commands exact, every byte outside the C footprints unchanged;
            only bytes the contract leaves undefined after a failed command are excluded)
  traffic   the exact SFB2 read word sequence and write word sequence (address, strobe, data)
            predicted from the tile schedule: no gap byte read, no stray write, exact tails
  counters  PERF GEMM_OK / TILES / CHUNKS / MACS / DESC / RD_WORDS / WR_WORDS / CMD_* deltas
  streams   (optional) the scheduler's DMA descriptor stream, compute-job stream and TC05
            OPEN descriptors, field by field
"""
from __future__ import annotations

import cocotb
from cocotb.triggers import FallingEdge, RisingEdge, ReadOnly

from reference_models import tsu_model as T
from reference_models.gemm_ref import ByteMemory, output_tiles
from common.sfb2 import Sfb2Memory, Window

M32 = 0xFFFF_FFFF


class Record(dict):
    @classmethod
    def from_words(cls, w):
        return cls(tid=w[0] & 0xFF, opcode=(w[0] >> 8) & 0xFF, err=(w[0] >> 16) & 0xFF, status=(w[0] >> 24) & 3,
                   irq=(w[0] >> 26) & 1, sat=(w[0] >> 27) & 1, detail=(w[0] >> 28) & 0xF, count=w[1], err_addr=w[2],
                   seq=w[3], cycles=w[4], tiles=w[5], words=list(w))


class Cmd:
    def __init__(self, words, gemm=None, label=""):
        self.words, self.gemm, self.label = list(words), gemm, label
        self.expect = None
        self.record = None


class _MemView(ByteMemory):
    """ByteMemory facade over the expected-memory bytearray (for the reference model)."""

    def __init__(self, arr, lo):
        super().__init__()
        self.arr, self.lo = arr, lo

    def __getitem__(self, a):
        return self.arr[a - self.lo]

    def __setitem__(self, a, v):
        self.arr[a - self.lo] = v & 0xFF

    def copy(self):
        return _MemView(bytearray(self.arr), self.lo)


class TsuEnv:
    def __init__(self, dut, rng, cov, hw: T.HwConfig):
        self.dut, self.rng, self.cov, self.hw = dut, rng, cov, hw
        self.mem = Sfb2Memory(dut, hw.mem_lo, hw.mem_hi, rng)
        self.exp = bytearray(hw.mem_hi - hw.mem_lo)
        self.undef: set[int] = set()
        self.cmds: list[Cmd] = []
        self.n_sub = 0                 # accepted since the last hard reset (= next SEQ)
        self.sticky = False
        self.err_cont = False
        self.records: list[Record] = []
        self.streams = None
        for s in ("rb_sel", "rb_we", "rb_addr", "rb_wdata", "fi_mode"):
            getattr(dut, s).value = 0

    # ------------------------------------------------------------------ bring-up
    async def start(self, monitor_streams=False):
        d = self.dut
        d.rst_n.value = 0
        for _ in range(4):
            await FallingEdge(d.clk)
        d.rst_n.value = 1
        for _ in range(2):
            await FallingEdge(d.clk)
        self.mem_task = cocotb.start_soon(self.mem.run())
        if monitor_streams:
            self.streams = dict(desc=[], job=[], q=[])
            self.mon_task = cocotb.start_soon(self._stream_monitor())
        assert await self.rd(T.R_ID) == T.ID_VALUE
        info = await self.rd(T.R_INFO)
        assert info & 0xF == T.ABI_VERSION and (info >> 8) & 0xFF == self.hw.rows and (info >> 16) & 0xFF == self.hw.cols
        assert await self.rd(T.R_KMAX) == self.hw.k_max
        assert await self.rd(T.R_MEM_LO) == self.hw.mem_lo and await self.rd(T.R_MEM_LAST) == self.hw.mem_hi - 1

    def fill_random(self, lo=None, hi=None):
        lo = self.hw.mem_lo if lo is None else lo
        hi = self.hw.mem_hi if hi is None else hi
        data = self.rng.randbytes(hi - lo)
        self.mem.write_bytes(lo, data)
        self.exp[lo - self.hw.mem_lo:hi - self.hw.mem_lo] = data

    def poke(self, addr, data: bytes):
        self.mem.write_bytes(addr, data)
        self.exp[addr - self.hw.mem_lo:addr - self.hw.mem_lo + len(data)] = data

    # ------------------------------------------------------------------ register bus
    async def access(self, we, addr, data=0):
        d = self.dut
        await FallingEdge(d.clk)
        d.rb_sel.value, d.rb_we.value, d.rb_addr.value, d.rb_wdata.value = 1, int(we), addr, data & M32
        await ReadOnly()
        q, e = int(d.rb_rdata.value), int(d.rb_err.value)
        self.full_at_strobe = int(d.dut.u_cq.full.value)      # queue state in the strobe cycle itself
        await RisingEdge(d.clk)
        d.rb_sel.value, d.rb_we.value = 0, 0
        return q, e

    async def wr(self, addr, data):
        _, e = await self.access(1, addr, data)
        assert not e, f"register write {addr:#x} refused"

    async def rd(self, addr):
        q, e = await self.access(0, addr)
        assert not e, f"register read {addr:#x} refused"
        return q

    async def status(self):
        return await self.rd(T.R_STATUS)

    async def perf(self):
        return {k: await self.rd(T.R_PERF0 + 4 * i) for k, i in T.PC.items()}

    async def set_ctrl(self, err_cont: bool):
        self.err_cont = err_cont
        await self.wr(T.R_CTRL, int(err_cont))

    async def err_clear(self):
        await self.wr(T.R_CTRL, int(self.err_cont) | (1 << T.CTRL_ERR_CLEAR))
        self.sticky = False

    # ------------------------------------------------------------------ commands
    def _predict(self, c: Cmd):
        """Expected outcome of command c executed now on the expected memory (updates it)."""
        hw = self.hw
        w = c.words
        tid, op, irq = (w[0] >> 24) & 0xFF, w[0] & 0xFF, (w[0] >> 16) & 1
        base = dict(tid=tid, opcode=op, irq=irq, seq=self.n_sub)
        if self.sticky and not self.err_cont:
            return dict(base, status=T.ST_SKIPPED, err=T.E_PRIOR, sat=0, detail=0, count=0, tiles=0, err_addr=0)
        view = _MemView(self.exp, hw.mem_lo)
        poison = [T.Poison(x.lo, x.hi, x.read, x.write) for x in self.mem.windows if x.read or x.write]
        o = T.expected_outcome(w, c.gemm, hw, view, poison)
        if o.status == T.ST_OK and c.gemm is not None and op == T.OP_GEMM:
            cmat, _ = T.result_matrix(c.gemm, view)
            T.write_result(c.gemm, view, cmat)
        elif o.status == T.ST_ERROR and c.gemm is not None and o.err in (T.E_DMA_READ, T.E_DMA_WRITE):
            for a, v in o.defined_c.items():
                view[a] = v
            self.undef |= o.undefined_c
        if o.status == T.ST_ERROR:
            self.sticky = True
        return dict(base, status=o.status, err=o.err, sat=int(o.sat) if o.status == T.ST_OK else 0,
                    detail=o.detail, count=o.count, tiles=o.tiles, err_addr=o.err_addr, count_range=o.count_range,
                    tiles_range=o.tiles_range, outcome=o)

    async def submit(self, c: Cmd):
        for i, x in enumerate(c.words):
            await self.wr(T.R_DESC0 + 4 * i, x)
        while True:
            _, e = await self.access(1, T.R_DOORBELL, 1)
            if not e:
                break
            # refused: must be because the queue was full in that very cycle (sampled at the strobe)
            assert self.full_at_strobe, "DOORBELL refused although the queue was not full"
            self.cov.hit("host", "doorbell_refused_full")
            await self.collect()
        c.expect = self._predict(c)
        self.n_sub += 1
        self.cmds.append(c)

    async def collect(self):
        while (await self.status()) & (1 << T.SB_CPL_VALID):
            w = [await self.rd(T.R_CPL0 + 4 * i) for i in range(6)]
            _, e = await self.access(1, T.R_CPL_POP, 1)
            assert not e, "CPL_POP refused with a record present"
            self.records.append(Record.from_words(w))

    async def wait_done(self, max_cycles=5_000_000):
        n = 0
        while len(self.records) < len(self.cmds):
            await self.collect()
            n += 1
            assert n < max_cycles, "records missing"
        while (await self.status()) & (1 << T.SB_BUSY):
            await self.collect()
        await self.collect()

    async def run(self, cmds, check=True):
        for c in cmds:
            await self.submit(c)
        await self.wait_done()
        if check:
            self.check_records()

    # ------------------------------------------------------------------ checks
    def check_records(self):
        assert len(self.records) == len(self.cmds), f"{len(self.records)} records for {len(self.cmds)} commands"
        for i, (c, r) in enumerate(zip(self.cmds, self.records)):
            c.record = r
            e = c.expect
            ctx = f"command {i} ({c.label}) words={[hex(x) for x in c.words]}"
            for k in ("tid", "opcode", "status", "err", "irq", "seq"):
                assert r[k] == e[k], f"{ctx}: record {k} = {r[k]:#x}, expected {e[k]:#x}  (record {r})"
            if e["status"] == T.ST_OK:
                assert (r["count"], r["tiles"], r["sat"], r["err_addr"], r["detail"]) == \
                       (e["count"], e["tiles"], e["sat"], 0, 0), f"{ctx}: record {r}, expected {e}"
                assert r["cycles"] > 0, f"{ctx}: CYCLES = 0"
            elif e["status"] == T.ST_ERROR:
                assert r["detail"] == e["detail"], f"{ctx}: DETAIL {r['detail']} expected {e['detail']}"
                assert r["err_addr"] == e["err_addr"], f"{ctx}: ERR_ADDR {r['err_addr']:#x} expected {e['err_addr']:#x}"
                if e["count"] is not None:
                    assert (r["count"], r["tiles"]) == (e["count"], e["tiles"]), \
                        f"{ctx}: COUNT/TILES {(r['count'], r['tiles'])} expected {(e['count'], e['tiles'])}"
                else:
                    g = c.gemm
                    tb = T.tile_bytes(g, self.hw)
                    lo_t, hi_t = e["tiles_range"]
                    assert lo_t <= r["tiles"] <= hi_t, f"{ctx}: TILES {r['tiles']} outside {e['tiles_range']}"
                    done = sum(tb[:r["tiles"]])
                    nxt = tb[r["tiles"]] if r["tiles"] < len(tb) else 0
                    assert done <= r["count"] <= done + nxt, f"{ctx}: COUNT {r['count']} inconsistent with TILES"
                    # the tiles the record reports stored must be exact in memory
                    view = _MemView(self.exp, self.hw.mem_lo)
                    for a, v in T.defined_after_tiles(g, self.hw, self._pre_mem(i), r["tiles"]).items():
                        view[a] = v
                        self.undef.discard(a)
                self.cov.hit("errors", T.E_NAMES[e["err"]])
            self.cov.hit("records", {0: "ok", 1: "error", 2: "skipped"}[e["status"]])

    def _pre_mem(self, i):
        # operands of command i are untouched by its own C writes (ALIAS rule), so the current
        # expected image still holds them
        return _MemView(self.exp, self.hw.mem_lo)

    def check_memory(self):
        m, e, lo = self.mem.mem, self.exp, self.hw.mem_lo
        if m == e:
            return
        bad = [i for i in range(len(m)) if m[i] != e[i] and (i + lo) not in self.undef]
        assert not bad, (f"{len(bad)} memory bytes differ from the expected image, first at "
                         f"{bad[0] + lo:#x}: got {m[bad[0]]:#04x} expected {e[bad[0]]:#04x}; "
                         f"{self._who(bad[0] + lo)}")

    def _who(self, a):
        for c in self.cmds:
            g = c.gemm
            if g is None:
                continue
            if a in T.c_footprint(g):
                return f"inside the C footprint of '{c.label}'"
        return "outside every C footprint (stray write)"

    def check_traffic(self):
        """Exact SFB2 read and write sequences for runs in which every GEMM completed OK."""
        exp_r, exp_w = [], []
        for c in self.cmds:
            if c.gemm is None or c.expect["status"] != T.ST_OK or (c.words[0] & 0xFF) != T.OP_GEMM:
                continue
            exp_r += [wa for wa, _ in T.read_words(c.gemm, self.hw)]
            exp_w += [(wa, st) for wa, st, _, _ in T.write_words(c.gemm, self.hw)]
        got_r = [a for _, a, _ in self.mem.reads]
        got_w = [(a, st) for _, a, st, _, _ in self.mem.writes]
        assert len(got_r) == len(exp_r), f"{len(got_r)} SFB2 reads, expected {len(exp_r)}"
        for i, (g, x) in enumerate(zip(got_r, exp_r)):
            assert g == x, f"SFB2 read {i}: address {g:#x}, expected {x:#x}"
        assert len(got_w) == len(exp_w), f"{len(got_w)} SFB2 writes, expected {len(exp_w)}"
        for i, (g, x) in enumerate(zip(got_w, exp_w)):
            assert g == x, f"SFB2 write {i}: (address, strobe) {g}, expected {x}"
        self.cov.hit("traffic", "exact", len(got_r) + len(got_w))

    async def check_counters(self, before: dict):
        after = await self.perf()
        ok = [c for c in self.cmds if c.expect["status"] == T.ST_OK and c.gemm is not None
              and (c.words[0] & 0xFF) == T.OP_GEMM]
        exp = dict(GEMM_OK=len(ok), CMD_DONE=len(self.cmds), CMD_ACCEPT=len(self.cmds))
        for k in ("TILES", "CHUNKS", "MACS", "DESC", "RD_WORDS", "WR_WORDS"):
            exp[k] = sum(T.counters(c.gemm, self.hw)[k] for c in ok)
        got = {k: (after[k] - before[k]) & M32 for k in exp}
        assert got == exp, f"performance counters {got}, expected {exp}"

    # ------------------------------------------------------------------ internal streams (scheduler view)
    async def _stream_monitor(self):
        d = self.dut.dut
        dp = d.u_dp
        while True:
            await RisingEdge(self.dut.clk)
            if not int(self.dut.rst_n.value):
                continue
            if int(dp.desc_valid.value) and int(dp.desc_ready.value):
                x = int(dp.desc_data.value)
                f = lambda lo, w: (x >> lo) & ((1 << w) - 1)      # noqa: E731
                self.streams["desc"].append(dict(src=f(0, 32), dst=f(32, 32), sstride=f(64, 32), dstride=f(96, 32),
                                                 row_len=f(128, 16), rows=f(144, 16), kind=f(168, 2),
                                                 seal=f(170, 1), ver=f(184, 8), rsvd=f(176, 8)))
            if int(dp.job_valid.value) and int(dp.job_ready.value):
                self.streams["job"].append(dict(tag=int(dp.job_tag.value), m=int(dp.job_m.value),
                                                n=int(dp.job_n.value), k=int(dp.job_k.value),
                                                k_total=int(dp.job_k_total.value), nch=int(dp.job_n_chunks.value),
                                                chunk=int(dp.job_chunk.value), lda=int(dp.job_lda.value),
                                                ldb=int(dp.job_ldb.value)))
            if int(dp.tq_desc_valid.value) and int(dp.tq_desc_ready.value):
                self.streams["q"].append(int(dp.tq_desc_data.value))

    def check_streams(self):
        """Scheduler output vs the tile schedule of every successful GEMM (in order)."""
        exp_d, exp_j, exp_q = [], [], []
        for c in self.cmds:
            g = c.gemm
            if g is None or c.expect["status"] != T.ST_OK or (c.words[0] & 0xFF) != T.OP_GEMM:
                continue
            for x in T.dma_descriptors(g, self.hw):
                exp_d.append(dict(src=x.src, dst=x.dst, sstride=x.sstride, dstride=x.dstride, row_len=x.row_len,
                                  rows=x.rows, kind=x.kind, seal=int(x.seal), ver=0x07, rsvd=0))
            nch = len(set(s.kidx for s in T.schedule(g, self.hw)))
            for s in T.schedule(g, self.hw):
                exp_j.append(dict(m=s.em, n=s.en, k=s.ek, k_total=g.k, nch=nch, chunk=s.kidx, lda=T.lda_loc(s.ek),
                                  ldb=T.ldb_loc(self.hw), tile=s.tile_idx, cmd=id(c)))
                if g.out_int8 and s.first_k:
                    exp_q.append(g)
        got_d = self.streams["desc"]
        assert len(got_d) == len(exp_d), f"{len(got_d)} DMA descriptors issued, expected {len(exp_d)}"
        for i, (a, b) in enumerate(zip(got_d, exp_d)):
            assert a == b, f"DMA descriptor {i}: got {a}\n expected {b}"
        got_j = self.streams["job"]
        assert len(got_j) == len(exp_j), f"{len(got_j)} compute jobs, expected {len(exp_j)}"
        tags = {}
        for i, (a, b) in enumerate(zip(got_j, exp_j)):
            key = (b.pop("cmd"), b.pop("tile"))
            tag = a.pop("tag")
            assert a == b, f"compute job {i}: got {a}\n expected {b}"
            tags.setdefault(key, set()).add(tag)
        assert all(len(v) == 1 for v in tags.values()), "a tile's chunks carry different tags"
        assert len(self.streams["q"]) == len(exp_q), f"{len(self.streams['q'])} TC05 OPENs, expected {len(exp_q)}"
        for x, g in zip(self.streams["q"], exp_q):
            w = [(x >> (32 * i)) & M32 for i in range(8)]
            p = g.qparams()
            assert (w[0] & 0xFF, (w[0] >> 8) & 0xF, (w[0] >> 12) & 7, (w[0] >> 16) & 0xFF, (w[0] >> 24) & 0xF) == \
                (0x40, 1, g.rm, 2 | (8 if g.relu else 0), 1), f"TC05 OPEN header {w[0]:#x}"
            assert (w[4], w[5] & 0x3F, w[6]) == (g.q_mult & M32, g.q_shift, p.zp & M32), "TC05 OPEN scale fields"
        self.cov.hit("streams", "checked", len(got_d) + len(got_j))


# ----------------------------------------------------------------------------- workload placement

class Alloc:
    """Bump allocator inside the memory window (keeps A, B, C of different commands apart)."""

    def __init__(self, hw: T.HwConfig, rng, base_off=0x100):
        self.hw, self.rng = hw, rng
        self.p = hw.mem_lo + base_off

    def take(self, nbytes, align=1, gap=True):
        p = self.p + (self.rng.randint(0, 40) if gap else 0)
        p = (p + align - 1) // align * align
        assert p + nbytes <= self.hw.mem_hi, "workload does not fit the memory window"
        self.p = p + nbytes
        return p


def make_gemm(hw: T.HwConfig, alloc: Alloc, rng, m, n, k, *, int8=False, kc=0, pad=True, tid=None, nmajor=False,
              prefetch=False, irq=False, unaligned=True, q=None) -> T.Gemm:
    lda = k + (rng.choice([0, 0, 1, 3, 4, 13]) if pad else 0)
    ldb = n + (rng.choice([0, 0, 1, 2, 7]) if pad else 0)
    esz = 1 if int8 else 4
    ldc = n * esz + (rng.choice([0, 0, 4, 8]) if pad else 0) + (rng.choice([0, 1, 3]) if int8 and pad else 0)
    a = alloc.take((m - 1) * lda + k, 1 if unaligned else 4)
    b = alloc.take((k - 1) * ldb + n, 1 if unaligned else 4)
    c = alloc.take((m - 1) * ldc + n * esz, 1 if (int8 and unaligned) else 4)
    g = T.Gemm(a=a, b=b, c=c, m=m, n=n, k=k, lda=lda, ldb=ldb, ldc=ldc, kc=kc,
               tid=rng.randint(0, 255) if tid is None else tid, nmajor=nmajor, prefetch=prefetch, irq=irq,
               out_int8=int8)
    if int8:
        q = q or {}
        g.rm = q.get("rm", rng.randint(0, 4))
        g.relu = q.get("relu", rng.random() < 0.4)
        g.q_mult = q.get("mult", rng.choice([rng.randint(1 << 28, (1 << 31) - 1), rng.randint(-(1 << 31), -1),
                                             rng.randint(1, 1 << 14)]))
        g.q_shift = q.get("shift", rng.randint(20, 40))
        g.q_zp = q.get("zp", rng.randint(-20, 20)) & 0xFF
    return g


__all__ = ["TsuEnv", "Cmd", "Record", "Alloc", "make_gemm", "Window", "T"]
