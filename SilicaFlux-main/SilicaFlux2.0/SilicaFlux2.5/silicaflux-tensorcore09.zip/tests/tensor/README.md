# SilicaFlux TENSORCORE 09: TensorCore verification framework

Aureom.AI | SilicaFlux-HPC. This framework checks the SilicaFlux TensorCore, the complete
`silicaflux_tensor_unit` of TENSORCORE 08 and every block it integrates. It aims to show that the
accelerator:

- computes correct results,
- preserves data, and
- obeys its control and memory protocols.

Each check uses an independent exact-integer reference, cocotb scoreboards, bound SystemVerilog
assertions and formal proofs.

**Results** are in [`reports/VERIFICATION_REPORT.md`](reports/VERIFICATION_REPORT.md), generated from the
final run (machine-readable form: `reports/report.json`). Evidence is RTL simulation, lint and formal
proofs with stated bounds. No gate-level, FPGA or silicon claims are made.

## Quick start (from the repository root)

```bash
sudo apt-get install -y verilator iverilog yosys z3     # Ubuntu 24.04: Verilator 5.020, Icarus 12, Yosys 0.33
pip install -r tests/tensor/requirements.txt            # cocotb 2.1, pytest (+ pytest-xdist, numpy: optional)
make tensor-test                                        # every suite at quick level + formal + lint + report
```

The delivery ZIP unpacks at the repository root (`unzip silicaflux-tensorcore09.zip`); check it with
`sha256sum -c tests/tensor/SHA256SUMS`. `python3 tests/tensor/scripts/package.py` rebuilds it.

| Command | What it runs |
|---|---|
| `make tensor-test` | Everything at quick level (one seed), then the report. Exit code ≠ 0 if anything failed. |
| `make tensor-test-pe` | PE: the integrated TC02 PE (6 configurations) and the TC01 PE's SAT / WRAP policy (8) |
| `make tensor-test-array` | Systolic array: 2×2 first, then 4×4, 8×8, 1×1, 3×5, MUL_PIPE, narrow accumulators |
| `make tensor-test-memory` | Operand buffer (6 configurations) + DMA on the complete unit (6) |
| `make tensor-test-quant` | Quantisation (5 configurations) |
| `make tensor-test-integration` | End-to-end GEMMs on the complete unit (7 configurations) |
| `make tensor-test-acc`, `tensor-test-sched` | Accumulator; tile iterator + scheduler |
| `make tensor-formal` | Formal proofs and bounded checks with seeded-bug vacuity checks |
| `make tensor-lint` | Verilator lint of every RTL configuration and testbench; checker library in Yosys formal mode |
| `make tensor-regression` | Full level, seeds `20261108 1 2`, formal, simulation mutants, lint, re-run of the shipped TC02 / TC08 regressions, report |
| `make tensor-report` | Regenerate the report from `build/results` |
| `make tensor-legacy` | Only the shipped TC02 / TC08 regressions |

Knobs: `TENSOR_SEED=<n>`, `TENSOR_LEVEL=quick|full`, `JOBS=<n|auto>` (pytest-xdist), `SEEDS="…"`.
A single suite: `cd tests/tensor && python3 -m pytest pe -k dw8_acc32_mp0_ca1`.
A single cocotb test: add `TENSOR_TESTCASE=random_protocol`. Waves for every run: `TENSOR_WAVES=1`.

## Where the RTL comes from

`scripts/stage_rtl.py` (run by every target) extracts the RTL from the repository archives into
`build/rtl/`:

- `SilicaFlux-main/silicaflux-tensorcore08.zip`, which vendors TC02–TC07 unmodified;
- the TC01 and TC02 archives.

It verifies every file against the archives' own checksum lists and records the archive SHA-256 values
and the git commit in `build/rtl/manifest.json`; that is the "RTL revision" of the report. The RTL is
never edited. Override an archive with `TENSOR_TC08_ZIP=…`.

## Layout

```
tests/tensor/
  reference_models/   exact integer GEMM, requantisation, TSU command model (+ self-tests)
  assertions/         portable SV checkers (Icarus, Verilator, Yosys -formal)
  common/             cocotb runner (seeds, failure capture), harness, SFB2 memory model, TSU environment
  pe/ systolic_array/ operand_buffer/ accumulator/ quantization/ tile_controller/ dma/ integration/
                      one tb_*.sv wrapper (DUT + checkers) and cocotb tests per suite
  formal/             harnesses + run_formal.py + FORMAL.md (bounds and assumptions)
  regression/         run_regression.py; failures/ (failing seeds, waveforms, repro.json)
  scripts/            stage_rtl, lint, run_mutants, run_legacy, make_report
  docs/               AUDIT, VERIFICATION_PLAN (brief -> tests), FINDINGS, GAPS
  reports/            VERIFICATION_REPORT.md, report.json (final run)
```

The repository root gets a `Makefile` (delegating `tensor-*`) and `.github/workflows/tensor-verification.yml`:
quick on push / PR, full nightly; reports and failure artefacts are uploaded.

## How a test decides pass / fail

A cocotb test fails if any of these happens:

- a scoreboard mismatches its reference model;
- an SV checker records an error, or never evaluates (vacuous);
- the RTL prints a `$error` / `$fatal` while the test runs;
- the simulated-time watchdog expires.

The runner then re-runs exactly that test with the same seed and waveforms, and saves `waves.fst`,
`sim.log` and `repro.json` under `regression/failures/`.

Simulation discipline: inputs change on the falling clock edge; monitors sample at the rising edge.
