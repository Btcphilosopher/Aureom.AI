# Failing seeds and waveforms

When a cocotb test fails, `common/sim.py` re-runs exactly that test with the same seed and waveform
dumping enabled and keeps the evidence here:

    <suite>/<toplevel>-<configuration>/<test>-seed<seed>/
        waves.fst     Icarus waveform of the failing test (open with GTKWave / Surfer)
        sim.log       simulator + cocotb log of the re-run
        repro.json    suite, configuration parameters, seed, level, and the command that reproduces it

`run_regression.py` also writes `failing_seeds.json` (every failing step / seed and every saved
directory).  Reproduce one failure, with waves, using the `rerun` command from its `repro.json`, e.g.

    TENSOR_SEED=20261108 TENSOR_LEVEL=quick TENSOR_TESTCASE=random_protocol TENSOR_WAVES=1 \
        python3 -m pytest tests/tensor/pe -k 'dw8_acc32_mp0_ca1'

The final qualification run of this delivery produced no failures (see reports/VERIFICATION_REPORT.md).
