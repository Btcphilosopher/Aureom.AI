#!/usr/bin/env python3
"""TensorCore regression runner (TENSORCORE 09).

    run_regression.py --level quick|full --seeds S1 [S2 ...] [--suites ...] [--jobs N|auto] [--legacy]

For every seed, every simulation suite runs under pytest with TENSOR_SEED / TENSOR_LEVEL set
(deterministic: each cocotb test derives its own stream from the seed); the reference-model
self-tests, the formal proofs and the lint run once.  Results go to build/results (per run JSON,
coverage, formal) and build/junit; a failing cocotb test is re-run with waves by the runner and
saved under regression/failures/<suite>/...; this script writes
regression/failures/failing_seeds.json and finally regenerates reports/VERIFICATION_REPORT.md.
Exit code: 0 only if nothing failed.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

TT = Path(__file__).resolve().parents[1]
BUILD = TT / "build"
SUITES = ["pe", "systolic_array", "operand_buffer", "accumulator", "quantization", "tile_controller", "dma",
          "integration"]


def run(cmd, env=None, log=None, timeout=None):
    t0 = time.time()
    p = subprocess.run(cmd, cwd=TT, env=env, capture_output=True, text=True, timeout=timeout)
    if log:
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(" ".join(cmd) + "\n\n" + p.stdout + p.stderr)
    return p.returncode, time.time() - t0, p.stdout + p.stderr


def tool_versions() -> dict:
    v = {}
    for name, cmd in (("python", [sys.executable, "--version"]), ("verilator", ["verilator", "--version"]),
                      ("iverilog", ["iverilog", "-V"]), ("yosys", ["yosys", "-V"]), ("z3", ["z3", "--version"]),
                      ("make", ["make", "--version"]), ("gcc", ["gcc", "--version"])):
        try:
            out = subprocess.run(cmd, capture_output=True, text=True).stdout.strip().splitlines()
            v[name] = out[0] if out else "?"
        except OSError:
            v[name] = "missing"
    for mod in ("cocotb", "pytest", "xdist", "numpy"):
        try:
            v[mod] = __import__(mod).__version__
        except Exception:                                  # noqa: BLE001
            v[mod] = "missing"
    return v


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--level", default="quick", choices=["quick", "full"])
    ap.add_argument("--seeds", nargs="+", default=["20261108"])
    ap.add_argument("--suites", nargs="+", default=SUITES)
    ap.add_argument("--jobs", default="auto")
    ap.add_argument("--legacy", action="store_true", help="also re-run the shipped TC02 / TC08 regressions")
    ap.add_argument("--keep", action="store_true", help="keep earlier results in build/results")
    ap.add_argument("--no-formal", action="store_true")
    ap.add_argument("--no-mutants", action="store_true")
    a = ap.parse_args()

    if not a.keep:
        for d in (BUILD / "results", BUILD / "junit"):
            if d.exists():
                shutil.rmtree(d)
        fd = TT / "regression" / "failures"
        for x in fd.iterdir() if fd.exists() else []:
            if x.is_dir():
                shutil.rmtree(x)
            elif x.name != "README.md":
                x.unlink()
    (BUILD / "results").mkdir(parents=True, exist_ok=True)
    rc, _, out = run([sys.executable, "scripts/stage_rtl.py"])
    if rc:
        print(out)
        return rc
    meta = dict(level=a.level, seeds=a.seeds, suites=a.suites, started=time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                tools=tool_versions(), rtl=json.loads((BUILD / "rtl" / "manifest.json").read_text()))
    steps = []
    xdist = []
    try:
        import xdist  # noqa: F401
        xdist = ["-n", str(a.jobs)]
    except ImportError:
        pass

    # reference models (once)
    rc, t, out = run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "reference_models",
                      f"--junitxml={BUILD / 'junit' / 'reference_models.xml'}"], log=BUILD / "logs" / "ref.log")
    steps.append(dict(step="reference_models", rc=rc, seconds=round(t, 1)))
    print(f"[{'PASS' if rc == 0 else 'FAIL'}] reference models ({t:.0f} s)")

    failing = []
    for seed in a.seeds:
        env = dict(os.environ, TENSOR_SEED=str(seed), TENSOR_LEVEL=a.level)
        for s in a.suites:
            xml = BUILD / "junit" / f"{s}-{seed}-{a.level}.xml"
            rc, t, out = run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", *xdist, s,
                              f"--junitxml={xml}"], env=env, log=BUILD / "logs" / f"{s}-{seed}.log")
            steps.append(dict(step=f"{s}", seed=seed, rc=rc, seconds=round(t, 1)))
            tail = [ln for ln in out.strip().splitlines() if ln.strip()][-1:] or [""]
            print(f"[{'PASS' if rc == 0 else 'FAIL'}] {s:16s} seed {seed} ({t:.0f} s) {tail[0]}")
            if rc:
                failing.append(dict(suite=s, seed=seed, log=str((BUILD / 'logs' / f'{s}-{seed}.log').relative_to(TT))))

    if not a.no_formal:
        rc, t, out = run([sys.executable, "formal/run_formal.py"], log=BUILD / "logs" / "formal.log")
        steps.append(dict(step="formal", rc=rc, seconds=round(t, 1)))
        print(f"[{'PASS' if rc == 0 else 'FAIL'}] formal ({t:.0f} s) {out.strip().splitlines()[-1] if out.strip() else ''}")
    if not a.no_mutants:
        rc, t, out = run([sys.executable, "scripts/run_mutants.py"], log=BUILD / "logs" / "mutants.log")
        # survivors are reported (and explained in docs/FINDINGS.md), not a regression failure by themselves
        steps.append(dict(step="mutants", rc=0, raw_rc=rc, seconds=round(t, 1)))
        print(f"[INFO] simulation mutants ({t:.0f} s) {out.strip().splitlines()[-1] if out.strip() else ''}")
    rc, t, out = run([sys.executable, "scripts/lint.py"], log=BUILD / "logs" / "lint.log")
    steps.append(dict(step="lint", rc=rc, seconds=round(t, 1)))
    print(f"[{'PASS' if rc == 0 else 'FAIL'}] lint ({t:.0f} s) {out.strip().splitlines()[-1] if out.strip() else ''}")
    if a.legacy:
        rc, t, out = run([sys.executable, "scripts/run_legacy.py"], log=BUILD / "logs" / "legacy.log")
        steps.append(dict(step="legacy", rc=rc, seconds=round(t, 1)))
        print(f"[{'PASS' if rc == 0 else 'FAIL'}] legacy re-runs ({t:.0f} s)")

    # failing seeds and the saved failure directories (waves + repro.json)
    saved = []
    for f in sorted((BUILD / "results").glob("*/*.json")):
        try:
            d = json.loads(f.read_text())
        except Exception:                                  # noqa: BLE001
            continue
        if isinstance(d, dict) and d.get("failures"):
            for x in d["failures"]:
                saved.append(dict(suite=d["suite"], run=d["run"], seed=d["seed"], test=x["test"], dir=x.get("dir")))
    fd = TT / "regression" / "failures"
    fd.mkdir(parents=True, exist_ok=True)
    (fd / "failing_seeds.json").write_text(json.dumps(dict(level=a.level, failing_steps=failing, saved=saved),
                                                      indent=1))
    meta["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    meta["steps"] = steps
    (BUILD / "results" / "run_meta.json").write_text(json.dumps(meta, indent=1))
    rc_rep, _, out = run([sys.executable, "scripts/make_report.py"])
    print(out.strip().splitlines()[-1] if out.strip() else "report: no output")
    bad = [s for s in steps if s["rc"] != 0]
    print(f"regression: {len(steps) - len(bad)}/{len(steps)} steps passed")
    return 1 if bad or rc_rep else 0


if __name__ == "__main__":
    sys.exit(main())
