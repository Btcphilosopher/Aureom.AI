"""DMA verification on the complete unit: TC07 tensor_dma_adapter + tsu_bus_gate behind the
SFB2 master port.

The DMA is checked where it matters - at the memory boundary - by the exact traffic
scoreboard (every read word / write word / strobe predicted from the 2-D descriptors of the
schedule: strided rows, unaligned starts, byte tails, no gap byte read, no stray write), the
SV bus assertions (R2 stable payload, conservation, <= MAX_OUT outstanding, address bounds,
DataFabric protocol checker) and the ownership checkers on the operand / output buffers.

Error cases (TC08 doc 05): a read error gives DMA_READ with the exact failing word address
and COUNT / TILES consistent with the C prefix in memory; a write error gives DMA_WRITE with
the exact address, COUNT = the acknowledged prefix, TILES = tiles before, tiles after the
failing one untouched; the datapath is soft-reset and the next command is exact.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

TT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(TT))
try:
    import cocotb  # noqa: F401
    from common.harness import tensor_test, pick, FallingEdge
    from common.tsu_tests import setup, finish, gemm_cmd, HW, CHECKERS, Alloc, make_gemm, Cmd, T, Window
except ImportError:
    tensor_test = None
from common.tsu_tests import cfg, cfg_id, run_tsu  # noqa: E402


if tensor_test is not None:

    @tensor_test(checkers=CHECKERS, timeout_us=80000)
    async def strided_unaligned_operands(dut, rng, cov):
        """Every residue of the A / B base address modulo 4, leading dimensions with every residue,
        C row padding; exact traffic (strided matrix access)."""
        env = await setup(dut, rng, cov, streams=True)
        al = Alloc(HW, rng)
        cmds = []
        for ra in range(4):
            for rl in range(4):
                m, n, k = rng.randint(1, 9), rng.randint(1, 9), rng.randint(1, 40)
                g = make_gemm(HW, al, rng, m, n, k, pad=False)
                g.lda = k + rl
                g.a = al.take((m - 1) * g.lda + k + 8, 4) + ra
                g.ldb = n + (3 - rl)
                g.b = al.take((k - 1) * g.ldb + n + 8, 4) + (3 - ra)
                g.c = al.take(m * (4 * n + 8), 4)
                g.ldc = 4 * n + 4 * (rl & 1)
                cmds.append(gemm_cmd(g, f"a%4={ra} lda%4={rl}"))
                cov.hit("residue", f"a{ra}_lda{rl}")
        if HW.quant:
            for rc in range(4):
                g = make_gemm(HW, al, rng, 5, 7, 11, int8=True)
                g.c = al.take(5 * 16, 4) + rc
                g.ldc = 7 + rc
                cmds.append(gemm_cmd(g, f"int8 c%4={rc}"))
        await env.run(cmds)
        await finish(env)

    @tensor_test(checkers=CHECKERS, timeout_us=200000)
    async def latency_backpressure_sweep(dut, rng, cov):
        """Memory latency 1 / 1..8 / 4..24 cycles x request backpressure 0 / 0.5 / 0.85: results and
        traffic exact; outstanding transactions bounded by MAX_OUT and the limit is reached."""
        env = await setup(dut, rng, cov, streams=False)
        al = Alloc(HW, rng)
        sweep = [((1, 1), 0.0), ((1, 8), 0.5), ((4, 24), 0.0), ((2, 6), 0.85)]
        if not pick(False, True):
            sweep = sweep[:3]
        for lat, bp in sweep:
            env.mem.lat, env.mem.bp_p = lat, bp
            cmds = [gemm_cmd(make_gemm(HW, al, rng, rng.randint(2, 12), rng.randint(2, 12), rng.randint(20, 100)))
                    for _ in range(2)]
            await env.run(cmds)
            cov.hit("memory", f"lat{lat[0]}-{lat[1]}_bp{bp}")
        assert env.mem.max_outstanding <= HW.max_out
        if HW.max_out > 1:
            assert env.mem.max_outstanding > 1, "multiple outstanding transactions never happened"
        cov.hit("outstanding", f"max_{env.mem.max_outstanding}")
        await finish(env)

    @tensor_test(checkers=CHECKERS, timeout_us=120000)
    async def read_error_injection(dut, rng, cov):
        """A read error in A, in B, and on a word that only holds bytes adjacent to an A row (SFB2
        reads whole words): DMA_READ / DETAIL RD_BUS / exact ERR_ADDR; COUNT, TILES and the C prefix
        consistent; the next command runs exact on the soft-reset datapath."""
        env = await setup(dut, rng, cov, streams=False)
        al = Alloc(HW, rng)
        for where in ("A", "B", "A_adjacent", "last_step"):
            g = make_gemm(HW, al, rng, 2 * HW.rows + 1, 2 * HW.cols, HW.tile_k + 9, pad=True)
            rd = T.read_words(g, HW)
            descs = T.dma_descriptors(g, HW)
            if where == "A":
                wa = next(w for w, di in rd[len(rd) // 3:] if descs[di].kind == T.KIND_LOAD_A)
            elif where == "B":
                wa = next(w for w, di in rd[len(rd) // 2:] if descs[di].kind == T.KIND_LOAD_B)
            elif where == "last_step":
                wa = rd[-1][0]
            else:
                # a word that holds only bytes next to an A row, if the layout has one
                fp = T.c_footprint(g)
                a_fp = {g.a + i * g.lda + j for i in range(g.m) for j in range(g.k)}
                cand = [w for w, di in rd if descs[di].kind == T.KIND_LOAD_A
                        and any((w + i) not in a_fp for i in range(4))]
                wa = cand[0] if cand else rd[0][0]
            env.mem.windows = [Window(wa, wa + 4, read=True)]
            await env.run([gemm_cmd(g, f"read_error_{where}")])
            env.mem.windows = []
            r = env.records[-1]
            assert (r["err"], r["detail"], r["err_addr"]) == (T.E_DMA_READ, T.TDMA_C_RD_BUS, wa), r
            cov.hit("dma_error", f"read_{where}")
            await env.run([gemm_cmd(make_gemm(HW, al, rng, 5, 6, 30), "after_read_error")])
            assert env.records[-1]["status"] == T.ST_OK
        env.mem.reads, env.mem.writes = [], []
        await finish(env, traffic=False, counters=False)

    @tensor_test(checkers=CHECKERS, timeout_us=120000)
    async def write_error_injection(dut, rng, cov):
        """A write error in the first, a middle and the last output tile, at the first, a middle and
        the last word of the tile: DMA_WRITE / WR_BUS / exact ERR_ADDR, COUNT = acknowledged prefix,
        TILES = tiles before; tiles after the failing one untouched; next command exact.  In
        stop-on-error mode the commands queued behind a write error are SKIPPED (PRIOR)."""
        env = await setup(dut, rng, cov, streams=False)
        al = Alloc(HW, rng)
        for tsel in ("first", "middle", "last"):
            for wsel in ("first", "middle", "last"):
                g = make_gemm(HW, al, rng, 3 * HW.rows - 1, 2 * HW.cols + 1, 23, pad=True,
                              int8=HW.quant and rng.random() < 0.5)
                wr = T.write_words(g, HW)
                ntiles = len(T.tile_bytes(g, HW))
                t = {"first": 0, "middle": ntiles // 2, "last": ntiles - 1}[tsel]
                words = [x for x in wr if x[2] == t]
                pick_w = {"first": words[0], "middle": words[len(words) // 2], "last": words[-1]}[wsel]
                wa = pick_w[0]
                env.mem.windows = [Window(wa, wa + 4, write=True)]
                await env.run([gemm_cmd(g, f"write_error_{tsel}_{wsel}")])
                env.mem.windows = []
                r = env.records[-1]
                assert (r["err"], r["detail"], r["err_addr"]) == (T.E_DMA_WRITE, T.TDMA_C_WR_BUS, wa), r
                cov.hit("dma_error", f"write_tile_{tsel}_word_{wsel}")
        # stop-on-error: a DMA write error with two GEMMs queued behind it.  Both are SKIPPED (PRIOR) and
        # touch no memory (checked by the memory image at the end); ERR_CLEAR resumes execution.
        await env.err_clear()
        await env.set_ctrl(False)
        g = make_gemm(HW, al, rng, 2 * HW.rows, HW.cols + 1, 17, pad=True)
        wa = T.write_words(g, HW)[0][0]
        env.mem.windows = [Window(wa, wa + 4, write=True)]
        q = [gemm_cmd(g, "write_error_stop_mode"), gemm_cmd(make_gemm(HW, al, rng, 4, 4, 9), "queued_1"),
             gemm_cmd(make_gemm(HW, al, rng, 3, 5, 7), "queued_2")]
        await env.run(q)
        env.mem.windows = []
        assert [c.record["status"] for c in q] == [T.ST_ERROR, T.ST_SKIPPED, T.ST_SKIPPED], [c.record for c in q]
        assert q[0].record["err"] == T.E_DMA_WRITE and all(c.record["err"] == T.E_PRIOR for c in q[1:])
        cov.hit("dma_error", "stop_mode_skips_queued")
        await env.err_clear()
        await env.set_ctrl(True)
        await env.run([gemm_cmd(make_gemm(HW, al, rng, 6, 5, 33), "after_write_errors")])
        env.mem.reads, env.mem.writes = [], []
        await finish(env, traffic=False, counters=False)

    @tensor_test(checkers=CHECKERS, timeout_us=200000, skip_if=(HW.wdog_log2 > 12))
    async def watchdog_slow_and_dead_memory(dut, rng, cov):
        """Slow memory (answers late, below the watchdog limit): the command completes OK.  Dead
        memory (a read is never answered): TIMEOUT record, the port cannot be drained, HALTED;
        only a hard reset recovers, after which commands are exact again."""
        env = await setup(dut, rng, cov, streams=False)
        al = Alloc(HW, rng)
        lim = 1 << HW.wdog_log2
        g = make_gemm(HW, al, rng, HW.rows, HW.cols, 20)
        wa = T.read_words(g, HW)[3][0]
        env.mem.windows = [Window(wa, wa + 4, delay=lim // 4)]
        await env.run([gemm_cmd(g, "slow")])
        assert env.records[-1]["status"] == T.ST_OK
        cov.hit("watchdog", "slow_ok")
        g2 = make_gemm(HW, al, rng, HW.rows, HW.cols, 20)
        wa2 = T.read_words(g2, HW)[2][0]
        env.mem.windows = [Window(wa2, wa2 + 4, black=True)]
        c2 = Cmd(g2.words(), g2, "dead")
        for i, x in enumerate(c2.words):
            await env.wr(T.R_DESC0 + 4 * i, x)
        await env.wr(T.R_DOORBELL, 1)
        n = 0
        while not ((await env.status()) & (1 << T.SB_HALTED)):
            n += 1
            assert n < 20 * lim, "unit never halted on a dead memory"
        await env.collect()
        assert env.records[-1]["err"] == T.E_TIMEOUT and env.records[-1]["status"] == T.ST_ERROR
        assert int(dut.halted.value) == 1
        cov.hit("watchdog", "dead_halt")
        # hard reset recovers
        env.mem.windows = []
        d = dut
        d.rst_n.value = 0
        for _ in range(3):
            await FallingEdge(d.clk)
        d.rst_n.value = 1
        await FallingEdge(d.clk)
        env.undef |= T.c_footprint(g2)
        env.records, env.cmds, env.n_sub, env.sticky = [], [], 0, False
        await env.set_ctrl(env.err_cont)
        await env.run([gemm_cmd(make_gemm(HW, al, rng, 7, 7, 30), "after_halt")])
        assert int(d.halted.value) == 0
        env.mem.reads, env.mem.writes = [], []
        await finish(env, traffic=False, counters=False)


    @tensor_test(checkers=CHECKERS, timeout_us=80000, skip_if=not int(__import__("common.harness",
                                                                           fromlist=["PARAMS"]).PARAMS.get("FI", 0)))
    async def internal_errors_by_fault_injection(dut, rng, cov):
        """Verification-only fault hooks of the RTL (FAULT_INJ = 1): operand fill writes redirected into
        the set the DMA does not own (BUF_ACCESS, local code 6 = ownership), output-buffer drain reads
        redirected to the other set (BUF_ACCESS / 6), TC04 K forced beyond the INT32 bound (ACC_OVF,
        DETAIL 5).  Each failing command leaves no C write; the next clean command is exact.
        (Needs two operand / output sets: with one set the flipped set bit maps a fill write into the
        B region of the same, legitimately FILLING set - no ownership violation exists to detect.)"""
        env = await setup(dut, rng, cov, streams=False)
        al = Alloc(HW, rng)
        for mode, err, detail in ((1, T.E_BUF_ACCESS, 6), (3, T.E_BUF_ACCESS, 6), (2, T.E_ACC_OVF, 5)):
            g = make_gemm(HW, al, rng, HW.rows, HW.cols, 17)
            n_wr = len(env.mem.writes)
            dut.fi_mode.value = mode
            c = Cmd(g.words(), None, f"fault_{mode}")
            for i, x in enumerate(c.words):
                await env.wr(T.R_DESC0 + 4 * i, x)
            await env.wr(T.R_DOORBELL, 1)
            env.n_sub += 1
            while not ((await env.status()) & (1 << T.SB_CPL_VALID)):
                pass
            await env.collect()
            r = env.records.pop()
            dut.fi_mode.value = 0
            assert (r["status"], r["err"], r["detail"], r["count"], r["tiles"], r["err_addr"]) == \
                (T.ST_ERROR, err, detail, 0, 0, 0), (mode, r)
            assert len(env.mem.writes) == n_wr, "a failing command wrote C"
            cov.hit("fault", f"mode{mode}")
            env.sticky = True
            await env.err_clear()
            env.records, env.cmds = [], []
            seq0 = env.n_sub
            ok = [gemm_cmd(make_gemm(HW, al, rng, 5, 6, 30), f"after_fault_{mode}")]
            env.n_sub = seq0
            await env.run(ok)
        env.mem.reads, env.mem.writes = [], []
        await finish(env, traffic=False, counters=False)


CONFIGS = [cfg(), cfg(maxout=1), cfg(maxout=16, dbuf=1, opb=4096), cfg(quant=1, wdog=10),
           cfg(rows=8, cols=8, maxout=2), cfg(fi=1, dbuf=1, opb=4096)]


@pytest.mark.parametrize("c", CONFIGS, ids=cfg_id)
def test_dma(c):
    run_tsu("dma", "test_dma", c, TT / "dma")
