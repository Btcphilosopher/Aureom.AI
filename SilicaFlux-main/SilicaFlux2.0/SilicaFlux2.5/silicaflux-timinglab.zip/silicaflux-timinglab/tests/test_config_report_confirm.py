"""Configuration, dashboard generation and hypothesis confirmation (no EDA tools needed)."""
import json
from pathlib import Path

import pytest

from conftest import DATA, ROOT
from timinglab.config import ConfigError, load_designs, load_pdk, list_pdks, expand
from timinglab.confirm import confirm
from timinglab.parsers.sta_text import parse_stage
from timinglab.report.dashboard import build_dashboard
from timinglab.flow.pnr import core_side_for_pins


def test_design_catalogue_is_consistent():
    ds = load_designs()
    for name, d in ds.items():
        for f in d.files:
            assert f.exists(), f"{name}: missing {f}"
        if d.variant_of:
            assert d.variant_of in ds, name
        if d.sdc:
            assert d.sdc.exists()
    # every TimingLab alternative is compared against an upstream block
    assert ds["tensor_unit_pipe"].variant_of == "tensor_unit"
    assert ds["vector_engine_pipe_ctx"].variant_of == "vector_engine_ctx"


def test_commercial_pdks_are_templates_only():
    assert "commercial_65nm" not in list_pdks()
    with pytest.raises(ConfigError, match="template"):
        load_pdk("commercial_65nm", check_files=False)
    tmpl = (ROOT / "flow" / "pdk" / "commercial_28nm.toml.template").read_text()
    assert "${COMM28_LIB}" in tmpl          # nothing proprietary is shipped


def test_env_expansion_strict():
    with pytest.raises(ConfigError):
        expand("${TL_SURELY_UNSET_VARIABLE_42}")
    assert expand("${TL_X}/a", {"TL_X": "q"}) == "q/a"


def test_pin_limited_floorplan_rule():
    # tensor_unit: 1541 I/O bits but only ~76k um^2 of cells
    assert core_side_for_pins(75858, 0.45, 1541, 0.68) is None or core_side_for_pins(75858, 0.45, 1541, 0.68) > 0
    assert core_side_for_pins(1000, 0.45, 2000, 0.68) == round(2000 * 0.68 * 1.25 / 4, 1)
    assert core_side_for_pins(1e6, 0.45, 100, 0.68) is None


def _fake_run(tmp_path, design, variant_of, fmax_slack, area, ffmap=None):
    rd = tmp_path / "runs" / "sky130hd" / design
    rd.mkdir(parents=True)
    st = parse_stage(DATA / "sta_grt", 10.0)
    st = json.loads(json.dumps(st))
    st["reg2reg_wns"] = fmax_slack
    st["reg2reg_fmax_mhz_derived"] = round(1000 / (10 - fmax_slack), 2)
    rec = {"design": design, "top": design, "group": "g", "variant_of": variant_of, "pdk": "sky130hd",
           "period_ns": 10.0, "status": "ok", "rundir": str(rd), "latency_cycles": 1,
           "synth": {"cells": 100, "area_um2": area, "seq_cells": 10, "yosys": "Yosys test"},
           "sta": {"timing": st, "opensta": "3.1.0"}, "pnr": {"stages": {"grt": st}, "openroad": "test",
                                                               "routing": {"total_overflow": 0}}}
    (rd / "result.json").write_text(json.dumps(rec))
    if ffmap:
        (rd / "ff_src_map.json").write_text(json.dumps(ffmap))
    return rec


def test_dashboard_exports(tmp_path):
    _fake_run(tmp_path, "tensor_unit", None, -2.0, 1000.0)
    _fake_run(tmp_path, "tensor_unit_pipe", "tensor_unit", 1.0, 1100.0)
    out = build_dashboard(tmp_path / "runs", tmp_path / "dash")
    html = out.read_text()
    assert "<svg" in html and "tensor_unit_pipe" in html
    comps = json.loads((tmp_path / "dash" / "timinglab_results.json").read_text())["comparisons"]
    assert len(comps) == 1
    c = comps[0]
    assert c["fmax_before_mhz"] == round(1000 / 12, 2) and c["fmax_after_mhz"] == round(1000 / 9, 2)
    assert c["area_delta_pct"] == 10.0
    for f in ("summary.csv", "critical_paths.csv", "comparisons.csv"):
        assert (tmp_path / "dash" / f).stat().st_size > 0


def test_confirm_maps_sta_endpoints_to_rtl_lines(tmp_path):
    st = parse_stage(DATA / "sta_grt", 10.0)
    worst = [p for p in st["paths_max"] if p["group"] == "reg2reg"][0]
    inst = worst["endpoint"].rsplit("/", 1)[0]
    rec = _fake_run(tmp_path, "tensor_unit", None, -2.9, 1000.0, ffmap={inst: "tensor_unit.sv:121"})
    audit = {"design": "tensor_unit", "findings": [
        {"id": "CRITICAL_PATH-001", "category": "critical_path", "title": "t", "endpoint_src": "tensor_unit.sv:121"},
        {"id": "CRITICAL_PATH-002", "category": "critical_path", "title": "t", "endpoint_src": "nowhere.sv:1"},
        {"id": "HIGH_FANOUT-001", "category": "high_fanout", "title": "t"}]}
    res = confirm(audit, rec)
    st_ = {f["id"]: f["status"] for f in res["findings"]}
    assert st_ == {"CRITICAL_PATH-001": "confirmed", "CRITICAL_PATH-002": "not-observable",
                   "HIGH_FANOUT-001": "unverified"}
