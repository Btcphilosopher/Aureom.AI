import os
import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DATA = Path(__file__).resolve().parent / "data"
UPSTREAM = ROOT / "upstream" / "silicaflux"


def have(tool: str) -> bool:
    return shutil.which(tool) is not None


slow = pytest.mark.skipif(not os.environ.get("RUN_SLOW"), reason="slow tier: set RUN_SLOW=1")
needs_verilator = pytest.mark.skipif(not have("verilator"), reason="verilator not installed")


def needs_eda(*names):
    from timinglab.config import Tools
    t = Tools.discover()
    missing = [n for n in names if not getattr(t, n)]
    return pytest.mark.skipif(bool(missing), reason=f"missing EDA tools: {missing}")
