"""Functional acceptance gates for the TimingLab RTL alternatives:
equivalence against unmodified upstream RTL, mutation sensitivity of the
equivalence testbenches, reproduction of the functional findings, lint,
and (slow tier) the formal multicycle-path proof and a synthesis+STA smoke run."""
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

from conftest import ROOT, needs_verilator, needs_eda, slow
from timinglab import regress

U = ROOT / "upstream" / "silicaflux" / "rtl"


@needs_verilator
def test_equivalence_tensor_and_vector():
    n = int(os.environ.get("TL_EQ_SCALE", "1"))
    r = regress.equiv(ntrans=300 * n, ncyc=20000 * n, seed=3)
    assert r["tensor"]["pass"], r["tensor"]["log"]
    assert r["vector_l4"]["pass"] and r["vector_l4"]["upstream_deviations"] == 0
    assert r["vector_l8"]["pass"] and r["vector_l8"]["upstream_deviations"] == 0
    # LANES=16: TimingLab matches the model; upstream does not (finding F-VEC-1)
    assert r["vector_l16"]["pass"] and r["vector_l16"]["upstream_deviations"] > 0


@needs_verilator
@pytest.mark.parametrize("mutant", [
    ("rtl/opt/sf_mul_lo_pipe.sv", "assign pp_mid = hl[H-1:0] + lh[H-1:0];", "assign pp_mid = hl[H-1:0] - lh[H-1:0];"),
    ("rtl/opt/sf_tensor_unit_pipe.sv", "first1 <= (k_cnt == 2'd0);", "first1 <= (k_cnt == 2'd1);"),
    ("rtl/opt/sf_tensor_unit_pipe.sv", "DRAIN: if (v2 && fin2) begin", "DRAIN: if (v2) begin"),
])
def test_tensor_equivalence_tb_detects_mutants(tmp_path, mutant):
    rel, old, new = mutant
    src = (ROOT / rel).read_text()
    assert old in src
    mut = tmp_path / Path(rel).name
    mut.write_text(src.replace(old, new))
    opt = [ROOT / "rtl/opt" / f for f in ("sf_mul_lo_pipe.sv", "sf_reduce_tree.sv", "sf_tensor_unit_pipe.sv")]
    opt = [mut if p.name == mut.name else p for p in opt]
    mdir = tmp_path / "obj"
    cmd = ["verilator", *regress.VFLAGS, "--top-module", "tb_eq_tensor", f"-I{U}", "-Mdir", str(mdir), "-o", "m",
           str(U / "silicaflux_pkg.sv"), str(U / "tensor_unit.sv"), *map(str, opt), str(ROOT / "tb/equiv/tb_eq_tensor.sv")]
    subprocess.run(cmd, check=True, capture_output=True)
    out = subprocess.run([str(mdir / "m"), "+NTRANS=40"], capture_output=True, text=True).stdout
    assert "[FAIL]" in out, "mutant survived the equivalence testbench"


@needs_verilator
def test_vector_equivalence_tb_detects_mutant(tmp_path):
    src = (ROOT / "rtl/opt/sf_vector_engine_pipe.sv").read_text()
    old = "REDUCE_MIN: return ($signed(a) < $signed(b)) ? a : b;"
    assert old in src
    mut = tmp_path / "sf_vector_engine_pipe.sv"
    mut.write_text(src.replace(old, "REDUCE_MIN: return (a < b) ? a : b;"))   # unsigned compare
    opt = [ROOT / "rtl/opt/sf_mul_lo_pipe.sv", ROOT / "rtl/opt/sf_reduce_tree.sv", mut]
    mdir = tmp_path / "obj"
    cmd = ["verilator", *regress.VFLAGS, "-GLANES=4", "--top-module", "tb_eq_vector", f"-I{U}", "-Mdir", str(mdir),
           "-o", "m", str(U / "silicaflux_pkg.sv"), str(U / "vector_engine.sv"), *map(str, opt),
           str(ROOT / "tb/equiv/tb_eq_vector.sv")]
    subprocess.run(cmd, check=True, capture_output=True)
    out = subprocess.run([str(mdir / "m"), "+NCYC=5000"], capture_output=True, text=True).stdout
    assert "[FAIL]" in out


@needs_verilator
def test_functional_findings_reproduce():
    r = regress.bugs()
    for name, v in r.items():
        assert v["reproduced"], f"{name}: {v}"


@needs_verilator
def test_timinglab_rtl_is_lint_clean():
    pkg = U / "silicaflux_pkg.sv"
    opt = [ROOT / "rtl/opt" / f for f in ("sf_mul_lo_pipe.sv", "sf_reduce_tree.sv", "sf_tensor_unit_pipe.sv",
                                           "sf_vector_engine_pipe.sv")]
    for top in ("sf_tensor_unit_pipe", "sf_vector_engine_pipe"):
        p = subprocess.run(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-Wno-UNUSEDSIGNAL",
                            "-Wno-UNUSEDPARAM", f"-I{U}", "--top-module", top, str(pkg), *map(str, opt)],
                           capture_output=True, text=True)
        assert p.returncode == 0, p.stderr[-2000:]


@slow
@needs_eda("yosys")
def test_formal_mcp_proof_and_vacuity():
    assert regress.formal()["proven"]
    assert regress.formal(negative=True)["negative_check_found_counterexample"]


@slow
@needs_eda("yosys", "sta")
def test_synth_sta_smoke(tmp_path):
    from timinglab.config import load_designs, load_pdk, Tools
    from timinglab.flow.runner import run_design
    rec = run_design(load_designs()["tensor_unit_pipe"], load_pdk("sky130hd"), Tools.discover(), tmp_path,
                     steps=("synth", "sta"))
    assert rec["synth"]["returncode"] == 0 and rec["synth"]["cells"] > 1000
    assert rec["sta"]["timing"]["paths_max"]
