"""RTL audit: delay model and graph analyses on hand-built Yosys-JSON netlists,
plus (when Yosys is available) the real audit of the upstream tensor_unit."""
import json

import pytest

from conftest import needs_eda, ROOT
from timinglab.audit import delay_model as dm
from timinglab.audit.netlist import Graph
from timinglab.audit.rtl_audit import AuditConfig, analyse, scope_of_net, top_block


def test_delay_model_monotonic_and_log_depth():
    assert dm.dadda_stages(2) == 0 and dm.dadda_stages(3) == 1 and dm.dadda_stages(32) == 8
    assert [dm.adder_bit_delay(i) for i in (0, 1, 3, 31)] == [2, 4, 6, 12]
    # low bits of a product settle earlier than high bits
    assert dm.multiplier_bit_delay(0, 32, 32) < dm.multiplier_bit_delay(31, 32, 32)
    # 16x16 split product is shallower than the 32x32 low half
    assert dm.multiplier_bit_delay(31, 16, 16) < dm.multiplier_bit_delay(31, 32, 32)


def _cell(t, conns, dirs, params=None, src="x.sv:1"):
    return {"type": t, "connections": conns, "port_directions": dirs, "parameters": params or {},
            "attributes": {"src": src}}


def _netlist(cells, ports, netnames=None):
    return {"modules": {"top": {"attributes": {"top": 1}, "ports": ports, "cells": cells,
                                "netnames": netnames or {}}}}


def test_longest_path_ff_mul_add_ff_and_fanout():
    W = 4
    a, b, p, s, q = list(range(2, 6)), list(range(6, 10)), list(range(10, 14)), list(range(14, 18)), list(range(18, 22))
    clk, en = 30, 31
    cells = {
        "ra": _cell("$dff", {"CLK": [clk], "D": [40, 41, 42, 43], "Q": a}, {"CLK": "input", "D": "input", "Q": "output"},
                    {"WIDTH": W}, "t.sv:10"),
        "rb": _cell("$dff", {"CLK": [clk], "D": [44, 45, 46, 47], "Q": b}, {"CLK": "input", "D": "input", "Q": "output"},
                    {"WIDTH": W}, "t.sv:11"),
        "mul": _cell("$mul", {"A": a, "B": b, "Y": p}, {"A": "input", "B": "input", "Y": "output"},
                     {"A_WIDTH": W, "B_WIDTH": W, "Y_WIDTH": W}, "t.sv:20"),
        "add": _cell("$add", {"A": p, "B": q, "Y": s}, {"A": "input", "B": "input", "Y": "output"},
                     {"A_WIDTH": W, "B_WIDTH": W, "Y_WIDTH": W}, "t.sv:21"),
        "rq": _cell("$dffe", {"CLK": [clk], "EN": [en], "D": s, "Q": q},
                    {"CLK": "input", "EN": "input", "D": "input", "Q": "output"}, {"WIDTH": W}, "t.sv:30"),
    }
    ports = {"clk": {"direction": "input", "bits": [clk]}, "en": {"direction": "input", "bits": [en]},
             "di": {"direction": "input", "bits": list(range(40, 48))}, "o": {"direction": "output", "bits": q}}
    nn = {"acc": {"bits": q, "hide_name": 0}, "a": {"bits": a, "hide_name": 0}}
    g = Graph.from_yosys_json(_netlist(cells, ports, nn))
    rep = analyse(g, AuditConfig(top="top", files=[], fanout_threshold=4))
    worst = rep["critical_paths"][0]
    assert worst["endpoint"] == "rq"
    exp = dm.multiplier_bit_delay(3, W, W) + dm.adder_bit_delay(3)
    assert worst["est_depth_ugd"] == exp
    assert [s["type"] for s in worst["stages"][1:]] == ["$mul", "$add"]
    assert worst["endpoint_bit"].startswith("acc")
    # EN of a 4-bit $dffe fans out to 4 flops
    assert g.physical_fanout(en) == 4
    cats = {f["category"] for f in rep["findings"]}
    assert "arithmetic_chain" in cats


def test_latch_and_comb_loop_detection():
    cells = {
        "l": _cell("$dlatch", {"EN": [2], "D": [3], "Q": [4]}, {"EN": "input", "D": "input", "Q": "output"}, {"WIDTH": 1}),
        "x1": _cell("$and", {"A": [5], "B": [6], "Y": [7]}, {"A": "input", "B": "input", "Y": "output"},
                    {"A_WIDTH": 1, "B_WIDTH": 1, "Y_WIDTH": 1}),
        "x2": _cell("$or", {"A": [7], "B": [2], "Y": [5]}, {"A": "input", "B": "input", "Y": "output"},
                    {"A_WIDTH": 1, "B_WIDTH": 1, "Y_WIDTH": 1}),
    }
    ports = {"en": {"direction": "input", "bits": [2]}, "d": {"direction": "input", "bits": [3, 6]},
             "q": {"direction": "output", "bits": [4]}}
    g = Graph.from_yosys_json(_netlist(cells, ports))
    rep = analyse(g, AuditConfig(top="top", files=[]))
    cats = [f["category"] for f in rep["findings"]]
    assert "latch" in cats and "comb_loop" in cats


def test_scope_helpers():
    assert scope_of_net("g_tiles[0].u_tile.u_vec.lane_result[28]") == "g_tiles[0].u_tile.u_vec"
    assert scope_of_net("$g_tiles[1].u_tile.u_vec.scalar_result$768[0]") == "g_tiles[1].u_tile.u_vec"
    assert scope_of_net("$726y[28]") == ""
    assert top_block("g_tiles[0].u_tile.u_vec") == "g_tiles[0].u_tile"
    assert top_block("u_ctrl") == "u_ctrl"


@needs_eda("yosys")
def test_real_audit_of_upstream_tensor_unit(tmp_path):
    from timinglab.config import load_designs
    from timinglab.audit.rtl_audit import run_audit
    d = load_designs()["tensor_unit"]
    cfg = AuditConfig(top=d.top, files=[str(f) for f in d.files], incdirs=[str(i) for i in d.incdirs],
                      frontend="read_slang --threads 1 " + " ".join(d.slang_args))
    from timinglab.config import Tools
    cfg.yosys = Tools.discover().yosys
    rep = run_audit(cfg, tmp_path)
    top = rep["critical_paths"][0]
    types = [s["type"] for s in top["stages"]]
    # counter -> 16:1 operand mux -> multiply -> accumulate add -> C register
    assert "$mul" in types and "$add" in types and "$pmux" in types
    assert top["endpoint_src"].startswith("tensor_unit.sv")
    assert any(f["category"] == "rdc" for f in rep["findings"])     # unsynchronised async reset
