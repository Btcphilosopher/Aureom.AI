"""Repository discovery and the dependency-graph scanner."""
from pathlib import Path

from conftest import ROOT, UPSTREAM
from timinglab.svscan import scan_text, strip_comments_and_strings
from timinglab.discovery import discover, hierarchy_tree, roots, write_dot


def test_comments_and_strings_are_blanked_preserving_lines():
    src = 'a // x(\n/* module fake (\n */ b "u_x (" c\n'
    out = strip_comments_and_strings(src)
    assert out.count("\n") == src.count("\n")
    assert "fake" not in out and "x(" not in out.split("\n")[0]
    assert '"u_x ("' in out          # string literals are kept (needed for `include "file")


def test_function_header_is_not_an_instance():
    # noc_interconnect.sv declares `function automatic noc_flit_t up(` - not an instance
    txt = (UPSTREAM / "rtl" / "noc_interconnect.sv").read_text()
    fs = scan_text(txt, "noc_interconnect.sv")
    (u,) = [x for x in fs.units if x.name == "noc_interconnect"]
    types = {i.module_type for i in u.instances}
    assert types == {"noc_router"}
    assert len(u.instances) == 4                      # r00, r01, r10, r11
    assert {i.instance_name for i in u.instances} == {"r00", "r01", "r10", "r11"}


def test_generate_block_instance_with_label_is_found():
    fs = scan_text((UPSTREAM / "rtl" / "silicaflux_top.sv").read_text(), "silicaflux_top.sv")
    (u,) = fs.units
    names = {(i.module_type, i.instance_name) for i in u.instances}
    assert ("compute_tile", "u_tile") in names        # inside `begin : g_tiles`
    assert ("tile_interface", "u_tif") in names
    assert len(names) == 9


def test_clock_and_reset_edges_are_recorded():
    fs = scan_text((UPSTREAM / "rtl" / "tensor_unit.sv").read_text(), "tensor_unit.sv")
    (u,) = fs.units
    edges = {(e.signal, e.edge) for b in u.blocks for e in b.edges}
    assert ("clk", "posedge") in edges and ("rst_n", "negedge") in edges
    # A_flat/B_flat load process has no reset (tensor_unit.sv:149)
    assert any(b.kind == "always_ff" and [e.signal for e in b.edges] == ["clk"] for b in u.blocks)


def test_discovery_on_upstream_tree_matches_known_hierarchy():
    res = discover(UPSTREAM)
    tree = [(d, inst, mod) for d, inst, mod, _ in hierarchy_tree(res, "silicaflux_top")]
    insts = {inst for _, inst, _ in tree}
    assert {"u_fetch", "u_regs", "u_dec", "u_ctrl", "u_ctrl_mem", "u_sched", "u_tile",
            "u_noc", "u_tif", "u_vec", "u_tensor", "u_mem", "r00", "r11"} <= insts
    assert res.unresolved == []
    # alu and forwarding_unit exist but are never instantiated (control_core inlines them)
    r = set(roots(res))
    assert {"alu", "forwarding_unit"} <= r
    # silicaflux_top is instantiated only by its testbench
    parents = {e["parent"] for e in res.edges if e["child"] == "silicaflux_top"}
    assert parents == {"tb_silicaflux_top"}
    # .sfx assembly sources are inventoried
    assert sum(1 for e in res.inventory if e.kind == "asm") == 4


def test_every_edge_has_file_line_evidence(tmp_path):
    res = discover(UPSTREAM)
    for e in res.edges:
        f, line = e["evidence"].rsplit(":", 1)
        assert int(line) > 0 and f.endswith(".sv")
        text = (UPSTREAM / f).read_text().splitlines()
        assert e["instance"] in text[int(line) - 1] or e["module_type"] in text[int(line) - 1]
    write_dot(res, tmp_path / "g.dot")
    assert "->" in (tmp_path / "g.dot").read_text()
