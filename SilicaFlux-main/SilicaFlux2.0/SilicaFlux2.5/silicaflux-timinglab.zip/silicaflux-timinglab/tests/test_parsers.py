"""Timing-report parsers, against real OpenROAD/OpenSTA output (tests/data/sta_grt,
taken from the tensor_unit SKY130 global-route stage)."""
from conftest import DATA
from timinglab.parsers.sta_text import (parse_paths, parse_end, parse_summary, parse_skew,
                                        parse_power, parse_stage)
from timinglab.parsers.openroad import parse_grt_log

D = DATA / "sta_grt"


def test_paths_are_parsed_with_slack_and_depth():
    ps = parse_paths((D / "paths_max.rpt").read_text())
    assert len(ps) == 6
    r2r = [p for p in ps if p.group == "reg2reg"]
    assert r2r[0].slack == -2.8962
    assert r2r[0].logic_depth == 43                     # cell output pins minus launch FF
    assert abs(r2r[0].cell_delay + r2r[0].wire_delay - r2r[0].data_delay) < 0.05
    assert r2r[0].clock_kind == "propagated"
    # arrival - required == slack (consistency of the parsed numbers)
    assert abs((r2r[0].required - r2r[0].arrival) - r2r[0].slack) < 1e-3


def test_end_format_groups_and_slacks():
    g = parse_end((D / "viol_max.rpt").read_text())
    assert "reg2reg" in g
    assert all(v["slack"] < 0 for v in g["reg2reg"])


def test_summary_skew_power():
    s = parse_summary((D / "summary.rpt").read_text())
    assert s["wns"] == -2.8962 and s["tns"] == -272.6428
    sk = parse_skew((D / "skew.rpt").read_text())
    assert abs(sk["setup_skew"] - 0.1272) < 1e-9
    assert parse_skew("Clock clk\n 0.10 source latency\n 0.05 setup skew\n 0.02 hold skew\n") == \
        {"setup_skew": 0.05, "hold_skew": 0.02}
    pw = parse_power((D / "power.rpt").read_text())
    assert pw["total_w"] > 0


def test_stage_summary_derives_fmax_from_reg2reg_slack():
    st = parse_stage(D, 10.0)
    assert st["reg2reg_wns"] == -2.8962
    assert st["reg2reg_fmax_mhz_derived"] == round(1000 / (10.0 + 2.8962), 2)


def test_grt_congestion_table():
    log = """[INFO GRT-0096] Final congestion report:
Layer         Resource        Demand        Usage (%)    Max H / Max V / Total Overflow
---------------------------------------------------------------------------------------
li1                  0             0            0.00%             0 /  0 /  0
met1             46219          9213           19.93%             0 /  0 /  0
Total           181424         38145           21.03%             0 /  0 /  0
---------------------------------------------------------------------------------------

[INFO GRT-0018] Total wirelength: 158920 um
"""
    r = parse_grt_log(log)
    assert r["total_overflow"] == 0 and r["wirelength_um"] == 158920.0
    assert r["layers"]["met1"]["usage_pct"] == 19.93
