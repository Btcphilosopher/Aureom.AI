// =============================================================================
// SilicaFlux TimingLab — formal evidence for the tensor_unit multicycle path
// formal/tensor_unit_mcp.sv
//
// Claim used by constraints/tensor_unit.sdc and constraints/silicaflux_top.sdc:
//     set_multicycle_path -setup 2 -from {A_flat, B_flat} -to {C_flat}
//
// Proof obligations on the UNMODIFIED upstream tensor_unit (hierarchical refs):
//   P1  If any A_flat/B_flat register changed at the last clock edge, the FSM
//       is not in CALC now, so C_flat cannot capture an A/B-dependent value at
//       the next edge (C_flat captures MAC results only in CALC).
//   P2  C_flat changes only (a) in CALC (MAC write), (b) on an accepted start
//       (clear to 0, independent of A/B), or (c) under reset.
// Together: data launched into A_flat/B_flat at edge t is first consumed by
// C_flat at edge t+2 or later -> setup multicycle 2 (hold multiplier 1).
//
// Run:  make formal-mcp   (Yosys `sat -tempinduct`, unbounded k-induction)
// =============================================================================
`include "silicaflux_pkg.sv"

module tensor_unit_mcp_formal
  import silicaflux_pkg::*;
(
  input logic clk,
  input logic rst_n,
  input logic start,
  input logic [4*XLEN-1:0] a0, a1, a2, a3, b0, b1, b2, b3
);
  logic done, busy;
  logic [4*XLEN-1:0] r0, r1, r2, r3;

  tensor_unit dut (
    .clk, .rst_n, .start,
    .mat_a_row0(a0), .mat_a_row1(a1), .mat_a_row2(a2), .mat_a_row3(a3),
    .mat_b_col0(b0), .mat_b_col1(b1), .mat_b_col2(b2), .mat_b_col3(b3),
    .done, .busy, .result_row0(r0), .result_row1(r1), .result_row2(r2), .result_row3(r3));

  localparam logic [1:0] S_IDLE = 2'b00, S_CALC = 2'b10;

  logic [32*XLEN-1:0] ab_now;
  logic [16*XLEN-1:0] c_now;
  for (genvar i = 0; i < 16; i++) begin : g_tap
    assign ab_now[i*XLEN +: XLEN]        = dut.A_flat[i];
    assign ab_now[(16+i)*XLEN +: XLEN]   = dut.B_flat[i];
    assign c_now[i*XLEN +: XLEN]         = dut.C_flat[i];
  end

  logic [32*XLEN-1:0] ab_prev;
  logic [16*XLEN-1:0] c_prev;
  logic [1:0]         state_prev;
  logic               start_prev, rst_prev;
  logic               past_valid = 1'b0;

  always_ff @(posedge clk) begin
    ab_prev    <= ab_now;
    c_prev     <= c_now;
    state_prev <= dut.state;
    start_prev <= start;
    rst_prev   <= rst_n;
    past_valid <= 1'b1;
  end

  wire ab_changed = past_valid && (ab_now != ab_prev);
  wire c_changed  = past_valid && (c_now  != c_prev);

  always_comb begin
    if (past_valid && rst_n) begin
      // P1
`ifndef TL_NEGATIVE
      if (ab_changed) assert (dut.state != S_CALC);
`else
      // Vacuity check (regress.py formal --negative): this is FALSE — after an
      // operand load the FSM is in LOAD — so the solver must find a counterexample.
      if (ab_changed) assert (dut.state != 2'b01);
`endif
      // P2
      if (c_changed && rst_prev)
        assert (state_prev == S_CALC || (state_prev == S_IDLE && start_prev));
    end
  end
endmodule
