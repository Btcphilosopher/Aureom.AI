# Findings in the upstream SilicaFlux v1.0 RTL

Everything here was found while auditing `upstream/silicaflux/` (unmodified,
commit `1244025`). Each finding states **how it was established**:

* **reproduced** — a testbench in `tb/bugs/` (or `tb/equiv/`) demonstrates it; run
  `python -m timinglab.regress bugs`. Each reproduction was run under Verilator 5.020;
  F-PIPE-1 and F-NOC-1 were also run under Icarus 12 with the same result.
* **tool-reported** — a lint, elaboration or synthesis tool reports it (command given).
* **inspection** — read from source only; stated as such.

None of these were fixed in `upstream/`. The TimingLab alternatives in `rtl/opt/`
deliberately preserve upstream behaviour (including bugs) except where noted, so that
equivalence checks compare like with like.

## Functional findings (reproduced)

### F-PIPE-1 — a load-use dependency deadlocks the scalar pipeline
`control_core.sv:114-121` raises `id_stall` when the instruction in IS/EX is a LOAD
whose `rd` matches a source of the instruction in ID/IS. While `id_stall` is high
neither `is_ex` (`control_core.sv:131`) nor `id_is` (`decoder.sv:112`) advances, so the
hazard is re-evaluated on unchanged registers and never clears.
`tb/bugs/tb_bug_load_use.sv` runs `LOAD r2,[r0]; ADD r3,r2,r2; MOV r4,7; HALT` on
`silicaflux_top`: 196 of 200 cycles stalled, PC stuck at 4, `r4` never written.
Control experiment (`+NODEP`, same program with `ADD r3,r1,r1`): completes, `r4 = 7`.
The README's "RAW (load-use): 1-cycle stall" is therefore not what the RTL does.
Fix direction: insert the bubble into EX (let `is_ex` advance with `valid=0`) instead of
freezing IS/EX.

### F-ISA-1 — STORE cannot store a register (always stores 0)
ISA: `STORE  MEM[rs1 + sext(imm17)] = rs2`, I-format. The I-format has no `rs2` field:
`sim/sfx_asm.py:234-239` parses `rs2` and drops it, and `decoder.sv:69-74` sets `rs2 = 0`.
`tb/bugs/tb_bug_store_data.sv`: after `MOV r1,0x55`, the single STORE request reaching the
scratchpad carries data `0`. BEQ/BNE (also I-format, "if rs1==rs2") likewise can only
compare against `r0` (inspection, same decoder line).

### F-NOC-1 — every NoC flit is delivered twice
`noc_router.sv:94-119` releases an input buffer only when *its routed output* is
accepted downstream, while the output arbiter (`:125-190`) re-loads `obuf` from any
still-valid input buffer in the same cycle `obuf` is accepted. With a ready sink the
same flit is copied into `obuf` twice. `tb/bugs/tb_bug_noc_dup.sv` (router level, flat
ports): one injected flit -> 2 deliveries, for LOCAL->LOCAL and LOCAL->EAST, identical
in Icarus and Verilator. A related consequence (inspection): when two inputs compete
for one output, the losing input is released by the winner's acceptance and its flit
is dropped.

### F-VEC-1 — `vector_engine` with LANES = 16 ignores lanes 8..15 in REDUCE/DOT
`vector_engine.sv:143-144` ("simplified") reduces `reduce_lvl2[0..1]` only; for
LANES = 16 `reduce_lvl2` has four entries. `tb/equiv/tb_eq_vector.sv` with
`-GLANES=16` reports upstream-vs-model deviations on every DOT/REDUCE cycle; LANES = 4
and 8 match the model exactly. `sf_vector_engine_pipe` reduces all lanes (the only
intentional behavioural difference in `rtl/opt/`).

### F-TIF-1 — `tile_interface` delivers a stale, bit-misaligned flit
Two defects in the RX path:
1. `tile_interface.sv:217-233` assigns `rx_assembled <= ...` and `rx_flit_out <= rx_assembled`
   in the same edge, so each delivered flit is the *previous* one (the first delivery
   is the reset value).
2. TX sends `ceil(43/8) = 6` beats (48 bits); RX shifts every beat into the MSBs of a
   43-bit register (`:196-207`), so the assembled flit is misaligned by 5 bits.
`tb/bugs/tb_bug_tif_rx.sv` loops two instances back to back and sends two flits: the
first delivery is all-zero, the second is flit 0 misaligned. A bit-exact model of both
effects predicts the second delivery exactly (`data = 0x80888d54, dst_col = 1` for a
sent `data = 0x1111aaaa, dst_col = 1`).

## Integration findings (tool-reported)

| ID | Finding | Evidence |
|---|---|---|
| I-1 | **Vector register file is never written.** `control_core` drives `v_wr_en = 0` on every path (`control_core.sv:281-299`), so `vregs` keep their reset value. Yosys proves this: after `memory_bmux2rom` the 16x128 vector register read becomes a constant ROM (audit `MEMORY-001/002` of `silicaflux_top`). Tile vector results (`tile_result_vector`) are not consumed at the top either. Consequence for timing: in the synthesised cluster only 136 `vector_engine` flip-flops survive (a stand-alone `compute_tile` keeps 162 per tile), so the cluster netlist does not exercise the vector datapath — block-level runs are the meaningful evidence for it. | `timinglab audit silicaflux_top`; `runs/sky130hd/silicaflux_top/ff_src_map.json` |
| I-2 | **Scheduler write-back targets r0.** `scheduler.sv:164-171` always sets `wb_reg = '0`; `register_bank.sv:63` discards writes to r0, so DOT/REDUCE scalar results never reach the register file. | inspection + I-1 |
| I-3 | **Chiplet RX path is unobservable.** `silicaflux_top` never consumes `tif_rx_flit`/`tif_rx_valid` (`silicaflux_top.sv:433-452`); synthesis removes the whole RX side, so `tile_phy_rx_*` have no sinks. | audit `CDC-001/002` of `silicaflux_top` |
| I-4 | **`compute_tile.noc_flit_out/noc_flit_valid` are driven by two processes** (`compute_tile.sv:198-335` and `:338-349`). Yosys: "multiple conflicting drivers"; Verilator: MULTIDRIVEN. The second process's condition (`tile_done && active_token.opcode == OP_DFEXEC`) is unreachable because DFEXEC never sets `tile_done`, so tiles never inject into the NoC. | `yosys check`, `verilator --lint-only` |
| I-5 | `compute_tile.sv:226` selects `src_col[2:0]` of a 2-bit field: an error for strict front-ends (slang `-Wrange-oob`), a warning for Verilator (SELRANGE). TimingLab compiles with `-Wno-error=range-oob`. | `read_slang` |
| I-6 | The package include guard only works when all files share one compilation unit (`--single-unit`); per-file units report `duplicate definition of 'silicaflux_pkg'`. | `read_slang` |
| I-7 | 471 flip-flops in asynchronous-reset processes are not assigned in the reset branch (e.g. `compute_tile` operand/token registers, `tile_interface.rx_assembled`). Synthesis must gate them with `rst_n` (`asynchronous load value missing` warnings), which puts the reset net in the data-path enable logic. | `read_slang` warnings |
| I-8 | `run_sim.sh` counts results with `grep -c ... \|\| echo 0`, which yields `"0\n0"` when there are no failures and makes the `[[ -gt ]]` test a syntax error (`0: syntax error in expression`); the script still reports success. | running `run_sim.sh` |
| I-9 | The upstream NoC testbench passes 6/6 under Icarus but 0/6 under Verilator 5.020 (`tb_noc_interconnect` drives 2-D unpacked struct-array ports, which the RTL also works around for Icarus). Results involving `noc_interconnect` ports are simulator-dependent; F-NOC-1 is therefore established at router level. | both simulators |

## Timing-relevant structural findings
These come from the RTL audit and are confirmed or refuted against STA in
`reports/audit/*/confirmed_*.json`; see `docs/RTL_AUDIT.md`.

* Every arithmetic datapath consumes only the low 32 bits of a 32x32 product in a single
  cycle: `tensor_unit.sv:112`, `vector_engine.sv:80-81`, `control_core.sv:158`.
* `vector_engine` places the multiply and the full reduction tree (MIN/MAX use signed
  compare + mux per level) in one cycle — the deepest path in the design.
* `tensor_unit` puts a 16:1 operand mux, the multiply, a 16:1 accumulator mux, the add and a
  16-way write demux in one cycle.
* `id_stall` is computed combinationally across control_core -> scheduler -> control_core
  and fans out to ~950 flip-flop enables in fetch, decode and IS/EX.
* The asynchronous reset is used directly from the `rst_n` port by 9,650 flip-flop bits
  with no reset synchroniser; the FPGA SDC false-paths it (see `docs/CONSTRAINTS.md`).
* `tile_interface` synchronises an 8-bit data bus bit-by-bit with 2-FF chains: no
  coherency guarantee if the PHY is truly asynchronous.
* `memory_controller`'s 256x32 array has 1 read and 1 write port per *access* but is
  addressed from several FSM states with offset arithmetic (`burst_addr + 1..3`); as RTL
  it becomes 8,192 flip-flops plus read muxes (it is an SRAM-macro candidate only after
  restructuring). Blocks containing it (`memory_controller`, `compute_tile`) are the only
  ones whose global route leaves overflow.
