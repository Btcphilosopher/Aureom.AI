# Tooling

| Tool | Version used for `reports/` | How it was obtained | Used for |
|---|---|---|---|
| Yosys | 0.70 (git 28ba3cb92), YoWASP build | `pip install yowasp-yosys` | `read_slang` SV front-end, synthesis, audit netlists, formal (`sat`) |
| OpenSTA | 3.1.0 (git 3b80c08c3d, 2026-11-02) | built from source with CUDD (`scripts/install_tools.sh`) | synthesis-stage STA |
| OpenROAD | 2.0-12381-g01bba3695 (embeds OpenSTA 2.5.0) | conda package, `litex-hub` channel, via micromamba | placement, CTS, global route, post-layout STA |
| Verilator | 5.020 | Ubuntu 24.04 apt | lint, equivalence / findings testbenches |
| Icarus Verilog | 12.0 | Ubuntu 24.04 apt | upstream SilicaFlux testbenches (as upstream intends) |
| Graphviz | 2.42 | apt | dependency-graph SVG |
| Python | ≥ 3.11 (3.13 used) | — | TimingLab itself: standard library only; `pytest` for tests |

TimingLab finds tools on `PATH` or at the paths in the table; override with
`TL_YOSYS`, `TL_STA`, `TL_OPENROAD`. `python -m timinglab tools` prints what it found.
A Yosys is accepted only if it provides `read_slang`: Yosys' built-in Verilog parser
cannot read the SilicaFlux package (`silicaflux_pkg.sv:218`).

Not used: SymbiYosys / EQY (the formal check is a single-property k-induction that Yosys
`sat -tempinduct` handles directly), commercial tools of any kind.
