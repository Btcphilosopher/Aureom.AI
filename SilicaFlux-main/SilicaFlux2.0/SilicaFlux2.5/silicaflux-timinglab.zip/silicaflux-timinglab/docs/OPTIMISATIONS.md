# RTL optimisations

Only blocks whose criticality was **verified** by STA were changed. Numbers in this
document are quoted from `docs/RESULTS.md` (generated) — see that file for every PDK.

## Which blocks were critical

Block-level runs on SKY130 (global-route stage, worst reg2reg path) rank the v1.0 blocks
exactly as the RTL audit predicted (`docs/RTL_AUDIT.md`): `vector_engine` (in its
`compute_tile` context) is slowest, then `tensor_unit`, then `control_core`; scheduler,
NoC router, chiplet interface, decoder and register file have 3–6x more slack. The two
compute datapaths were therefore rebuilt; the scalar core's single-cycle MUL is the next
limiter and is left as documented future work (see the end of this page).

## 1. `sf_tensor_unit_pipe` — pipelined MAC (drop-in for `tensor_unit`)

**Upstream critical path** (audit `CRITICAL_PATH-001`, confirmed by STA, 43 logic levels
on SKY130): `k/row/col counter → 16:1 operand mux → 32×32 multiply (low half) → 16:1
accumulator mux → 32-bit add → 16-way write demux → C_flat`, all in one cycle.

**Change** (`rtl/opt/sf_tensor_unit_pipe.sv`):

| Stage | Work | Register |
|---|---|---|
| S0 | counters (unchanged FSM order: row, col, k) | counters |
| S1 | 16:1 operand select | `a_q`, `b_q` |
| S2 | split low-half multiply: `aL·bL` (16×16→32) and `(aH·bL + aL·bH) mod 2^16` | `pp_ll`, `pp_mid` |
| S3 | `acc_next = (first ? 0 : acc) + pp_ll + (pp_mid << 16)`; write `C[row][col]` once, when k = 3 | `acc`, `C_flat` |

The identity `a·b mod 2^32 = aL·bL + ((aH·bL + aL·bH) mod 2^16)·2^16` (the `aH·bH` term
vanishes) replaces the 32×32 multiplier with three 16×16 ones whose outputs are
registered before a single 3-input add. Accumulating in `acc` removes the 16:1
read-back mux on `C_flat`. `sf_mul_lo_pipe.sv` holds the reusable partial-product /
combine helpers.

**Handshake:** same ports, `start` accepted only in IDLE, `done` 1-cycle pulse with
`busy` falling in the same cycle — latency 66 → 67 cycles (+1), one MAC per cycle as
before. `compute_tile` waits for `tensor_done`, so no integration change is needed.
**Observable difference:** upstream exposes running partial sums on `result_row*` while
busy; the pipelined unit exposes 0 or final values. Neither is architecturally visible
(the tile samples on `done` only) — documented in the RTL header.

**Result (SKY130):** reg2reg Fmax\* 77.5 → 109.1 MHz (+40.7 %), 10 ns WNS −2.90 → 0 ns,
area +3.9 %. Same direction on IHP SG13G2 (+36.9 %) and GF180MCU (+28.5 %).

## 2. `sf_vector_engine_pipe` — registered products + hierarchical reduction tree

**Upstream critical path** (audit 71 UGD, the deepest in the design; STA-confirmed):
`operand register → 32×32 multiply → lane op mux → signed compare + mux (MIN/MAX level 1)
→ compare + mux (level 2) → output select → scalar_result`. LANES = 8 adds a third level.

**Change** (`rtl/opt/sf_vector_engine_pipe.sv`, `sf_reduce_tree.sv`):

| Stage | Work |
|---|---|
| S1 | per lane: 16×16 partial products for VMUL/DOT, or the add/sub/broadcast/pass result (encoded as `pp_ll` with `pp_mid = 0`, so every op shares one datapath) |
| S2 | combine partial products; first reduction level (balanced pairs `2i, 2i+1`, as upstream) |
| S3 | remaining levels (`sf_reduce_tree`, `LEVELS_PER_STAGE` inserts registers every k levels for wide LANES) + output select |

**Handshake:** `result_valid` is `issue_valid` delayed by 3 instead of 1; like upstream the
pipeline evaluates every cycle, and every output equals upstream's output two cycles
earlier (checked cycle-by-cycle, not only on valid). `compute_tile` waits for
`vec_result_valid`, so the extra latency is absorbed by the existing token handshake —
verified at tile level (`tb/equiv/tb_eq_tile.sv`, below).
**Intentional fix:** for LANES = 16 upstream reduces only lanes 0..7 (F-VEC-1); the new
tree reduces all lanes. LANES = 4/8 results are identical to upstream.

**Result (SKY130, compute_tile context):** Fmax\* 56.8 → 97.4 MHz (+71.6 %), area +10.1 %;
LANES = 8: 46.9 → 88.5 MHz (+88.9 %). IHP +94.9 %, GF180 +84.7 %.

**Trade-off, stated plainly:** an isolated vector operation now takes 3 cycles instead of 1,
and the clock is less than 3x faster, so a single vector op takes *longer* in nanoseconds.
The change pays off because the vector engine is the slowest block in the cluster: removing
it as the limiter raises the shared clock bound, so scalar instructions and MATMUL get
faster (`docs/RESULTS.md` §1b gives the numbers per PDK). Vector throughput would also gain
if `compute_tile` issued back-to-back operations (the pipelined engine accepts one per
cycle); today the tile FSM waits for each result.

## 3. Tile integration — `sf_compute_tile_pipe`

Generated from the unmodified `compute_tile.sv` by `scripts/gen_tile_variant.py` (three
asserted textual substitutions: module name and the two datapath instances), so the
tile FSM, NoC and scratchpad are byte-identical. `tb/equiv/tb_eq_tile.sv` drives both
tiles with the same random token stream (vector, reduce, dot, broadcast, matmul, scalar /
vector / burst memory ops, dfsync): results identical on every completed token; extra
latency +0 cycles (memory/dfsync), +1 (matmul), +2 (vector ops).

**Result (SKY130, whole tile placed and globally routed):** Fmax\* 56.9 → 78.1 MHz
(+37.2 %), synthesised area −0.8 % (the 8,192-flop scratchpad dominates the tile). The
upstream tile is limited by the vector engine exactly as the block runs predicted
(`compute_tile.sv:198` operand registers → `vector_engine.sv:160` result registers, 61
logic levels). In the pipelined tile the limiter is the vector engine's S2 → S3 stage
(`sf_vector_engine_pipe.sv:116` → `:153`, 33 levels) — slower than in the block run
(97.4 MHz) because the tile is routing-congested: global routing leaves overflow in both
tiles, and 74 % of the nets on the upstream tile's 50 worst reg2reg paths cross overflowing
gcells versus 28 % in the pipelined tile (`docs/RESULTS.md`, `congestion` in the run
records). Mapping the scratchpad to an SRAM macro is the next step for tile-level timing.

## Investigated, not changed (and why)

| Item | Outcome |
|---|---|
| Balanced adder trees | The upstream reduction is already a balanced pairwise tree; the gain came from registering it (hierarchical reduction network) and taking the multiplier out of the same cycle. |
| Registered arbitration (NoC) | `noc_router` arbitration is already registered (`obuf`); router reg2reg slack is ~6x the tensor unit's. The router has a functional defect (F-NOC-1) that must be fixed first; a timing change would be premature. |
| Fan-out mitigation | Inside the measured blocks, high-fan-out nets (e.g. the tensor unit's 1,024-load operand enable) are buffered by `repair_design` and do not appear on the post-route critical paths (largest fan-out on the worst tensor path: 10), so RTL duplication was not needed there. `id_stall` (~950 loads, computed combinationally across control_core → scheduler → control_core) spans three blocks and could only be measured in a placed top level, which was not run; it should be computed from a registered `ready` when F-PIPE-1 is fixed, because that fix rewrites the stall logic anyway. |
| Scalar MUL (`control_core.sv:158`) | Next limiter after this work (SKY130 108.8 MHz). Splitting it needs a multi-cycle EX with a new interlock — a pipeline-hazard change that should be made together with the F-PIPE-1 fix and verified with ISA-level program equivalence; not attempted here so as not to stack a timing change on a known-broken hazard unit. |
| Memories as flip-flops | `imem` (1024×32) and the five 256×32 scratchpads become 41k flip-flops; mapping them to SRAM macros requires PDK macros and, for `memory_controller`, restructuring its multi-offset burst accesses. Flagged by the audit, not changed. |
