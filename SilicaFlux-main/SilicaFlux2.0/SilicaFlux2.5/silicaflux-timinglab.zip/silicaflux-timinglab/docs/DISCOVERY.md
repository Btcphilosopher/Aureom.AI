# Repository discovery

Source: `github.com/Btcphilosopher/SilicaFlux` @ `1244025bd8e0e8ce89619ebe9adcfa20e8086ab8`.
Regenerate everything on this page with

```bash
python -m timinglab discover --repo <SilicaFlux checkout> --out reports/discovery --yosys-crosscheck
```

which writes `reports/discovery/discovery.json` (inventory with SHA-256 per file,
every design unit, every instantiation edge with `file:line` evidence) and the
dependency graphs `silicaflux_v1_dependency_graph.{dot,svg}` and
`repository_dependency_graph.{dot,svg}`.

## 1. What the repository contains

The repository stores its sources as **archives** (16 of them); the tree itself holds
only `README.md` and a PNG. Discovery expands each archive into its own directory and
scans every file. 260 SystemVerilog/Verilog files, 261 modules, 1 `.sf` file and 4 `.sfx` files:

| archive | HDL files | .sf | .sfx | modules | packages | lines |
|---|---|---|---|---|---|---|
| `silicaflux.zip` — **SilicaFlux v1.0 core (analysed)** | 23 | 0 | 4 | 22 | 1 | 4827 |
| `SilicaFlux2.0/silicafluxai.zip` — SilicaFlux-AI tensor/GEMM blocks (MAC, PE, systolic array analysed) | 33 | 0 | 0 | 32 | 0 | 3665 |
| `SilicaFlux2.0/SilicaFluxML.zip` — learning controller (RTL self-described as pseudocode) | 12 | 1 | 0 | 17 | 2 | 1782 |
| `SilicaFlux2.0/silicafluxbitcoinasic.zip` — SHA-256 mining pipeline | 36 | 0 | 0 | 36 | 2 | 3163 |
| `SilicaFlux2.0/sha256-learn-r-asic-ml-optimizer.zip` | 0 | 0 | 0 | 0 | 0 | 0 |
| `RISC-V CPU.zip`, `cpu_core.zip`, `pipelined_cpu.zip` — separate RV32I-style CPUs | 37 | 0 | 0 | 38 | 3 | 4695 |
| `Finite State Machines Library.zip`, `UVM_Inspired_Architecture.zip`, `comm_protocols.zip`, `digital_lib.zip`, `dsp_arithmetic.zip`, `formal verification.zip`, `memory_cache_repo.zip`, `soc_integration.tar.gz` | 119 | 0 | 0 | 116 | 7 | 21491 |

Only `silicaflux.zip` is "the SilicaFlux processor architecture" with CPU, vector,
tensor, SRAM, NoC and chiplet blocks; the other archives are separate projects in the
same repository (they share no module or package with the v1.0 core — discovery finds no
cross-archive instantiation edge). Twelve module names occur in more than one archive
(e.g. `alu`, `memory_controller`, `forwarding_unit`); discovery resolves instantiations
within the instantiating archive first and lists the duplicates in `discovery.json`.

## 2. What `.sf` and `.sfx` actually are

* **`.sf`** — exactly one file, `SilicaFluxML/dsl/silicaflux_ml.sf` (377 lines). Its own
  header says it is "a plausible, strongly-typed, Chisel/Bluespec-flavoured surface syntax
  … an architecture sketch … not a parseable/compiled language", and
  `SilicaFluxML/docs/09_DSL_AND_RTL_MAPPING.md` repeats that "No public SilicaFlux hardware
  description language specification exists". It declares `package`, `fixed`, `type`,
  `struct`, `enum` and `module` blocks with `clock`/`reset`/`input`/`output`/`reg`
  declarations and a `state machine` block. No tool in the repository reads it, so
  TimingLab inventories it but does not (and cannot) synthesise it.
* **`.sfx`** — SilicaFlux **assembly** programs (`silicaflux/sim/programs/*.sfx`:
  fibonacci, dot_product_parallel, matmul_4x4, softmax_inference), assembled by
  `silicaflux/sim/sfx_asm.py` into `.hex/.bin/.mif/.coe` instruction images. These are
  the only programs for the v1.0 ISA. (`tb/bugs/` builds its programs with the same
  encodings as `sfx_asm.py`.)

## 3. SilicaFlux v1.0 — source-backed dependency graph

Scanner result (every edge carries `file:line`), cross-checked against the hierarchy
elaborated by Yosys 0.70 (`read_slang --keep-hierarchy`): **the two agree exactly**
(`yosys_crosscheck.agree = true` in `discovery.json`).

```
silicaflux_top                      silicaflux_top.sv:37
├─ u_fetch     fetch_unit           silicaflux_top.sv:157   PC, 1024x32 instruction memory
├─ u_regs      register_bank        silicaflux_top.sv:190   32x32 scalar + 16x128 vector RF
├─ u_dec       decoder              silicaflux_top.sv:212   4-format decode, RF read
├─ u_ctrl_mem  memory_controller    silicaflux_top.sv:233   256x32 scalar scratchpad
├─ u_ctrl      control_core         silicaflux_top.sv:252   IS/EX/MEM/WB, forwarding, branch
├─ u_sched     scheduler            silicaflux_top.sv:302   token dispatch, DFSYNC barrier
├─ g_tiles[0..3].u_tile compute_tile silicaflux_top.sv:346
│   ├─ u_mem    memory_controller   compute_tile.sv:88      256x32 tile scratchpad
│   ├─ u_vec    vector_engine       compute_tile.sv:120     SIMD ALU, LANES=4
│   └─ u_tensor tensor_unit         compute_tile.sv:143     4x4 INT32 MATMUL
├─ u_noc       noc_interconnect     silicaflux_top.sv:409
│   └─ r00 r01 r10 r11 noc_router   noc_interconnect.sv:71/92/113/134
└─ u_tif       tile_interface       silicaflux_top.sv:433   chiplet SerDes, 2-FF retimer
(all import silicaflux_pkg; alu.sv and forwarding_unit.sv exist but are never instantiated —
 control_core inlines both)
```

![SilicaFlux v1.0 dependency graph](../reports/discovery/silicaflux_v1_dependency_graph.svg)

### Subsystem map (where each requested structure lives)

| Structure | Where (evidence) |
|---|---|
| CPU datapath & pipeline stages | IF `fetch_unit.sv:59-115`; ID `decoder.sv:53-121`; IS/EX/MEM/WB `control_core.sv:126-299`; scalar ALU inlined at `control_core.sv:150-182` (32x32 MUL at :158) |
| Pipeline hazards | load-use stall `control_core.sv:114-121`; forwarding `:86-106`; branch flush `:207-216`; DFSYNC barrier `scheduler.sv:97-108` |
| Vector arithmetic units & registers | `vector_engine.sv` (lane ops :75-86, reduction tree :114-145); vector RF `register_bank.sv:52,92-117`; tile staging regs `compute_tile.sv:72` |
| Tensor multiply-accumulate | `tensor_unit.sv:73-140` (16:1 muxes, `$signed(a)*$signed(b)`, accumulate) |
| SRAM interfaces | instruction SRAM `fetch_unit.sv:45,78-96`; scratchpads `memory_controller.sv:52-230` (5 instances) |
| Network-on-chip / arbitration | `noc_router.sv:125-190` (fixed-priority output arbitration), `noc_interconnect.sv` mesh |
| Chiplet boundary | `tile_interface.sv` (TX serialiser :102-142, RX deserialiser + 2-FF chain :147-242) |
| Clock / reset | one clock `clk`, one active-low async reset `rst_n`, both from top-level ports; no PLL, divider, gater or reset synchroniser in any file |
| Build scripts | `sim/run_sim.sh` (Icarus), `synth/vivado/synth.tcl` (Arty A7), `synth/quartus/synth.tcl` (DE10-Nano), `synth/silicaflux.sdc` (FPGA SDC, 100 MHz) |
| Verification infrastructure | 7 directed testbenches `tb/tb_*.sv`, 61 assertions, all pass under Icarus 12 (re-run by `python -m timinglab.regress upstream-sim`); no formal, lint, coverage or ASIC flow |

### Per-module sequential structure (scanner)

| module | lines | seq. processes | clock | async reset | arrays |
|---|---|---|---|---|---|
| `compute_tile` | compute_tile.sv:24-351 | 2 (1 without reset) | clk | rst_n | vreg_local, tensor_result_row |
| `control_core` | control_core.sv:19-301 | 4 | clk | rst_n | |
| `decoder` | decoder.sv:20-123 | 1 | clk | rst_n | |
| `fetch_unit` | fetch_unit.sv:18-117 | 4 (1 without reset) | clk | rst_n | imem |
| `memory_controller` | memory_controller.sv:22-232 | 2 (1 without reset) | clk | rst_n | sram |
| `noc_router` | noc_router.sv:8-200 | 6 | clk | rst_n | ibuf, ivld, obuf, ovld |
| `register_bank` | register_bank.sv:19-119 | 2 | clk | rst_n | sregs, vregs |
| `scheduler` | scheduler.sv:17-175 | 3 | clk | rst_n | |
| `silicaflux_top` | silicaflux_top.sv:37-467 | 1 | clk | rst_n | |
| `tensor_unit` | tensor_unit.sv:16-260 | 3 (1 without reset) | clk | rst_n | A_flat, B_flat, C_flat |
| `tile_interface` | tile_interface.sv:28-262 | 4 | clk | rst_n | |
| `vector_engine` | vector_engine.sv:27-189 | 1 | clk | rst_n | |

## 4. SilicaFlux 2.0 tensor blocks also analysed

`silicaflux-ai/rtl` is the only other archive with a multiply-accumulate datapath that is
real synthesizable RTL with testbenches: `sfx_mac` (registered INT8 MAC), `sfx_pe` and
`sfx_systolic_array` (weight-stationary array). TimingLab vendors that directory and runs
`sfx_mac` and a 4x4 array through the same flow as a reference point for "well pipelined"
MAC structure.
