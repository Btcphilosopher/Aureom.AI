# Timing flow

```
            flow/designs.toml        flow/pdk/<pdk>.toml        constraints/*.sdc
                   │                         │                          │
 RTL ──► Yosys 0.70 (read_slang) ──► synth -flatten ──► dfflibmap ──► abc -liberty -D T ──► netlist.v
                                                                                │      ff_src_map.json
                                                                                ▼
                                   OpenSTA 3.1  (stage "synth": ideal wires, unbuffered)
                                                                                │
 OpenROAD: floorplan ─► tracks/taps ─► place_pins ─► global_placement ─► estimate_parasitics -placement
           ─► repair_design ─► detailed_placement ─► reports (stage "place")
           ─► clock_tree_synthesis ─► set_propagated_clock ─► repair_design ─► reports (stage "cts")
           ─► global_route ─► estimate_parasitics -global_routing ─► reports (stage "grt")
                                                                                ▼
                    timinglab/parsers ─► run record (result.json) ─► dashboard / CSV / JSON
```

Run it:

```bash
export TL_PLATFORMS=<ORFS>/flow/platforms           # scripts/fetch_pdks.sh
python -m timinglab run tensor_unit tensor_unit_pipe --pdk sky130hd gf180mcu ihp-sg13g2
python -m timinglab report --runs runs --out reports/dashboard --audit reports/audit
```

## Stages and what their numbers mean

| Stage | Wires | Nets | Clock | Use the numbers for |
|---|---|---|---|---|
| `synth` (OpenSTA) | ideal | unbuffered (fan-out up to thousands) | ideal + uncertainty | logic depth and structure only; slews on high-fan-out nets are unphysical (OpenSTA reports thousands of max-slew violations) |
| `place` (OpenROAD) | placement RC estimate (`setRC.tcl` of the PDK) | buffered by `repair_design` | ideal + uncertainty | first physically meaningful timing |
| `cts` | placement RC | buffered | **propagated**, real skew | skew-aware setup/hold |
| `grt` | global-route RC estimate | buffered | propagated | the reported result; congestion evidence |

`repair_timing` is **off** by default (`--repair-timing` turns on setup repair), so
before/after differences come from the RTL, not from the optimiser upsizing one version
harder. **Hold is not repaired either**: after CTS every block shows small negative hold
slack (WHS −0.05 to −1.2 ns in `docs/RESULTS.md`), from propagated skew on short paths.
Hold buffering is a routine sign-off step, independent of the RTL changes, and is not
part of any comparison here.
There is no PDN, detailed routing or parasitic extraction: this is a timing experiment
flow, not sign-off.

## Reports written per stage (`runs/<pdk>/<design>/{synth_sta,pnr/place,pnr/cts,pnr/grt}/`)

`paths_max.rpt` (top 50 paths per path group, with input pins, slew, cap, fan-out),
`paths_min.rpt`, `viol_max.rpt` / `viol_min.rpt` (every violating endpoint, used for
TNS per group), `unconstrained.rpt`, `summary.rpt` (WNS/TNS/worst slack),
`skew.rpt`, `drv.rpt` (max slew/cap/fan-out), `power.rpt` (vectorless estimate),
plus `area_*.rpt`, `cts.rpt`, `congestion.rpt` and the OpenROAD log. The same Tcl
procedure (`flow/sta/tl_report.tcl`) produces every stage so one parser serves all.

## Derived metrics (labelled as such everywhere)

* `reg2reg_fmax_mhz_derived = 1000 / (T − worst reg2reg slack)` — the period at which the
  worst register-to-register path in that report would have zero slack.
* `min_period_ns_derived` — the same, as a period.
* `op_latency_ns_derived = latency_cycles × min period` — time per operation, so a deeper
  pipeline is not credited for frequency it gives back in cycles.

## Engineering details that matter

* **SystemVerilog front-end.** SilicaFlux needs a real SV front-end: Yosys' built-in
  parser rejects `silicaflux_pkg.sv:218` (`return {...}` in an old-style function). The
  flow uses Yosys 0.70's integrated slang front-end (`read_slang --single-unit
  -Wno-error=range-oob`, see `docs/FINDINGS.md` I-5/I-6).
* **YoWASP.** `pip install yowasp-yosys` provides Yosys 0.70 with slang as a WebAssembly
  build; it is what produced `reports/`. It cannot open absolute paths outside the
  working directory, so every Yosys run is executed inside its run directory with
  relative file names.
* **RTL traceability.** Flip-flops keep their Yosys `src` attribute through `dfflibmap`;
  synthesis writes `ff_src_map.json` (instance → `file:line`) so STA start/end points are
  shown as RTL lines in the dashboard and used by `timinglab confirm`.
* **Pin-limited blocks.** Several blocks have more I/O bits than cells can surround at
  45 % utilisation (tensor_unit: 1,541 port bits). `timinglab/flow/pnr.py` sizes the core
  from the pin count when needed (one pin per routing track, 25 % margin) and records
  `floorplan.mode = pin-limited`.
* **Congested blocks.** `compute_tile` and `memory_controller` (8,192 flip-flop scratchpad
  plus wide read muxes) overflow in global routing; for them `grt_congestion_iterations = 5`
  (in `flow/designs.toml`) caps OpenROAD's overflow repair so a run finishes in minutes. The
  cap is identical for both members of a before/after pair and the remaining overflow is
  reported (`GRT overflow` column), which is the routing evidence the dashboard correlates
  with critical paths.
* **OpenSTA 2.x vs 3.x.** OpenROAD 2.0-12381 embeds OpenSTA 2.5, which spells
  `-group_count/-endpoint_count`; `tl_report.tcl` probes and uses whichever exists, and
  `parse_skew` reads both skew-report formats.
* **Characterisation harness.** `vector_engine` has no input registers (its operands are
  `compute_tile` registers), so as a bare block every path is `in2reg`.
  `rtl/harness/tl_vec_ctx.sv` adds exactly those operand registers so both the upstream
  and the pipelined vector engine are measured reg-to-reg in the same context.
