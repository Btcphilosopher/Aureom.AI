# PDK support

| PDK config | Library / corner | Platform files | Status |
|---|---|---|---|
| `sky130hd` | `sky130_fd_sc_hd`, TT 25 °C 1.80 V | ORFS `flow/platforms/sky130hd` | synthesis, STA, place, CTS, global route |
| `ihp-sg13g2` | `sg13g2_stdcell`, TYP 25 °C 1.20 V | ORFS `flow/platforms/ihp-sg13g2` | synthesis, STA, place, CTS, global route |
| `gf180mcu` | `gf180mcu_fd_sc_mcu9t5v0`, TT 25 °C 5.00 V (9-track, 5LM_1TM, K=9) | ORFS `flow/platforms/gf180` | synthesis, STA, place, CTS, global route |
| `commercial_65nm` | — | user supplied | template only |
| `commercial_28nm` | — | user supplied | template only |

All public PDK values in `flow/pdk/*.toml` mirror the corresponding OpenROAD-flow-scripts
`config.mk` (dont-use lists, tie cells, ABC driver/load, site, routing layers, I/O
layers, placement density, RC script). Deviations, all deliberate:

* GF180MCU uses the **TT** library (ORFS defaults to BC) and therefore sets
  `CORNER = TC` for `setRC.tcl`; `min_buf` is `buf_2` (ORFS uses a delay cell, `dlya_4`,
  for the minimum buffer).
* `pin_pitch_um` is TimingLab-specific (I/O-layer track pitch), used only to size
  pin-limited blocks.

Fetch the platform files with `scripts/fetch_pdks.sh` (sparse clone of ORFS) and point
`TL_PLATFORMS` at `.../flow/platforms`. `python -m timinglab pdk list` shows which
configurations resolve; `python -m timinglab pdk check <name>` validates one.

## Commercial 65 nm / 28 nm hooks

`flow/pdk/commercial_65nm.toml.template` and `commercial_28nm.toml.template` define the
exact fields a licensed kit must supply — Liberty files, technology and cell LEF,
tie/buffer cells and pins, site, routing and I/O layers, optional RC/track/tap scripts —
as `${COMMxx_*}` environment variables. **No proprietary content is shipped or assumed**:
cell names, pin names and layer names all come from the user's kit. Copy the template to
`commercial_65nm.toml`, export the variables, and the same flow, SDCs and reports apply.
Until then, `load_pdk("commercial_65nm")` raises "is a template only" (tested). Default
periods in the templates (2.5 ns / 1.25 ns) are placeholders for the user to replace.
