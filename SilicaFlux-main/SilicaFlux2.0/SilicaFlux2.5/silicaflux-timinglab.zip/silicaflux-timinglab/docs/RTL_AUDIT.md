# RTL timing-risk audit

`python -m timinglab audit <design ...> | --all` writes
`reports/audit/<design>/rtl_audit.json` (schema `silicaflux-timinglab/rtl-audit/v1`).
**Every finding is a hypothesis** (`"status": "hypothesis"`) until
`python -m timinglab.regress confirm` matches it with synthesis + STA evidence and
rewrites the status to `confirmed`, `refuted`, `not-observable` or `unverified`
(`reports/audit/<design>/confirmed_<pdk>.json`).

## How it works

1. Yosys elaborates the unmodified RTL (`read_slang`), then `proc; flatten; opt;
   wreduce; memory -nomap` — the *word-level* netlist: `$mul`, `$add`, `$pmux`, `$dff`,
   `$mem_v2`… with `src` attributes pointing to RTL lines.
2. `timinglab/audit/netlist.py` builds a **bit-level** graph over it (per-bit
   dependency rules: bitwise ops are bit-aligned, adders/multipliers depend on lower bits
   only, indexed part-selects are lane-aligned).
3. `timinglab/audit/delay_model.py` assigns a technology-independent delay in **unit-gate
   delays** (UGD, one 2-input gate; XOR and 2:1 mux = 2) assuming the log-depth
   structures synthesis builds under a timing constraint: prefix adders
   (`2⌈log2(i+1)⌉+2` to sum bit *i*), Dadda multipliers (stage count from the column
   height, plus the final adder), AND-OR mux trees, log-depth comparators and shifters.
   Memories are treated as macros: synchronous read data is a start point, async read is a
   decode + mux.
4. Longest-path DP from every start point (flip-flop Q, memory sync-read data, input
   port) to every end point (flip-flop D/EN/SRST, memory write/sync-read address, output
   port), with back-pointers so every reported path lists its operators and RTL lines.

## Categories

| Category | Detection |
|---|---|
| `critical_path` | top-N estimated reg2reg paths, one finding per (start line, end line) pair |
| `arithmetic_chain` | paths containing a multiplier or ≥ 2 arithmetic operators |
| `large_mux` | `$pmux`/`$bmux`/indexed `$shiftx` with ≥ 8 inputs, and `$mux` priority chains |
| `high_fanout` | *physical* fan-out ≥ 64: a 1-bit enable/select of a W-bit word cell counts W loads; grouped by driving RTL line; clocks excluded |
| `latch` | `$dlatch`-family cells and Yosys "Latch inferred" messages |
| `comb_loop` | strongly-connected components of the combinational bit graph + Yosys `check` |
| `multi_driver` | net bits with > 1 driver + Yosys "multiple conflicting drivers" |
| `memory` | every inferred array: size, read/write ports, async reads; ≥ 4 kbit arrays are SRAM-macro candidates (port compatibility checked) |
| `clock_domain`, `cdc` | clock nets per flip-flop; crossings; 2-FF chains behind declared asynchronous inputs (bus width flagged); dead asynchronous inputs |
| `rdc` | asynchronous reset driven straight from a port; mix of reset / non-reset flops |
| `routing` | combinational paths crossing ≥ 3 hierarchy boundaries; ≥ 128-bit buses broadcast to ≥ 3 blocks |
| `pipeline` | stall/flush/valid/ready nets with large physical fan-out, with their arrival time and the scopes they are computed across |

## What it found in SilicaFlux v1.0 (highlights)

| Finding | Hypothesis | STA outcome (SKY130, global route) |
|---|---|---|
| `vector_engine` DOT/REDUCE path, 71 UGD (89 UGD at LANES = 8) | deepest path in the design | confirmed: slowest block, 56.8 MHz (46.9 MHz at LANES = 8) |
| `tensor_unit` MAC chain, 56 UGD | second | confirmed: 77.5 MHz; its 1,024-load operand-enable net is buffered by `repair_design` and is not on the post-route critical path (max fan-out on that path: 10) |
| `control_core` EX-stage MUL, 33 UGD | third | confirmed: 108.8 MHz |
| `compute_tile`: the same vector path, 71 UGD, inside the full tile | tile limiter | confirmed: STA rank 1 of 150 reported paths, 56.9 MHz |
| `memory_controller` 32 UGD; decoder 28; NoC router 24; register bank 19; scheduler 15; tile interface 11 | not critical | 300–680 MHz range |
| `id_stall`: arrival 20 UGD, ~950 enable loads, computed across control_core → scheduler → control_core | pipeline/routing risk | not measurable block-by-block (it spans three blocks); the top level was analysed at synthesis stage only — open |
| async reset on 9,650 flops, no synchroniser | RDC | recovery/removal timed and met; synchroniser still recommended |
| 8-bit PHY bus synchronised bit-by-bit | CDC | structural; no constraint can fix it |
| `compute_tile.noc_flit_valid` two drivers | multi-driver | Yosys `check` reports the conflict |

Across all blocks and PDKs the audit's worst-depth estimate and the measured minimum
period are rank-correlated (Spearman ρ in `docs/RESULTS.md` §3): the audit is useful for
ordering risks before any library is involved, while absolute numbers come only from
STA. The pipelined alternatives are estimated at 33 UGD (tensor) and 33/38 UGD (vector,
LANES 4/8), which STA confirms as the measured speed-ups.

## Known limitations (by design)

* Word-level dependencies are conservative for operators without a bit rule (e.g.
  variable shifts): the estimate can over-state depth, never miss a dependency.
* Delays ignore wire load and fan-out; `high_fanout` / `pipeline` report those
  separately and the PnR stages measure them.
* Register names after flattening come from net names; RTL lines (`src`) are the
  stable identifier and are what confirmation matches on.
