# Timing constraints

Files in `constraints/`:

| File | Used for |
|---|---|
| `tl_common.tcl` | shared helpers; every number comes from `TL_*` environment variables set by the flow, so one SDC serves every PDK |
| `block_generic.sdc` | leaf-block experiments (default for every design in `flow/designs.toml`) |
| `tensor_unit.sdc` | `block_generic.sdc` + the formally proven multicycle path |
| `silicaflux_top.sdc` | the full v1.0 cluster: reset, program-load port, chiplet link, debug outputs |

The FPGA SDC shipped upstream (`upstream/silicaflux/synth/silicaflux.sdc`) is untouched.

## Clock

```
create_clock -name core_clk -period $TL_CLOCK_PERIOD [get_ports clk]
set_clock_uncertainty -setup (TL_UNC_SETUP x period)   # default 5 %: pre-CTS skew + jitter
set_clock_uncertainty -hold  TL_UNC_HOLD                # default 50 ps
set_clock_transition TL_CLK_SLEW                        # ideal clock, pre-CTS only
set_propagated_clock (after CTS, by flow/openroad/pnr.tcl)
```

Periods (`flow/designs.toml`): SKY130 10 ns, IHP SG13G2 8 ns, GF180MCU 20 ns. The same
period is used for an upstream block and its TimingLab alternative.

**Generated clocks:** none. The RTL has a single clock net (audit `CLOCK_DOMAIN-001` for
every design) and no divider, gater, PLL or forwarded clock, so a
`create_generated_clock` would have nothing to attach to. The top SDC says so explicitly
rather than carrying a commented-out template.

## Inputs and outputs

* Block level: inputs/outputs get 30 % of the period (`TL_IN_FRAC`, `TL_OUT_FRAC`),
  modelling a neighbouring block. Paths are split into `reg2reg`, `in2reg`, `reg2out`,
  `in2out` path groups; only `reg2reg` is architecture, and all before/after
  comparisons use it.
* `silicaflux_top`:
  * `rst_n` — input delay 30 %, **timed** (recovery/removal).
  * Program-load port `imem_wr_*` — external loader on `core_clk`, 40 % input budget.
  * Chiplet link `tile_phy_*` — two scenarios via `TL_PHY_MODE`:
    `meso` (default; mesochronous/source-synchronous link, 50 % budget each way) and
    `async` (far die on an unrelated clock: virtual `phy_clk`, `set_clock_groups -asynchronous`,
    and `set_max_delay -datapath_only` on the RX bus to bound bit-to-bit skew).
  * `halt`, `debug_scalar_r1` — 30 % output budget.
* Driving cell = the PDK's `min_buf`; output load = `abc_load_ff` from the PDK config.

## Exceptions — what changed against the FPGA SDC, and why

| FPGA SDC | TimingLab | Reason |
|---|---|---|
| `set_false_path -from rst_n` | removed; reset is timed | `rst_n` drives async clear/set pins of 9,650 flops directly with no synchroniser (`RDC-001`). A false path would hide recovery/removal violations; the audit recommends an assert-async/deassert-sync synchroniser instead. |
| `set_false_path -to *u_tif*phy_rx_*_s1*` | removed in `meso`, modelled in `async` | One clock in the RTL, so those flops are ordinary pipeline stages. In `async` mode the crossing is declared asynchronous, but the 8-bit data bus is a CDC hazard (`CDC-001`) that no constraint can make safe, so it is bounded, not ignored. |
| `set_multicycle_path -setup 2 imem_wr_data -> u_fetch/imem*` ("only active during reset hold") | removed | No functional evidence: `fetch_unit.sv:78-81` writes `imem` whenever `imem_wr_en=1`, independent of reset. |
| — | **added** `set_multicycle_path -setup 2 / -hold 1` from `A_flat`/`B_flat` to `C_flat` in `tensor_unit` | Proven (below). |

No false path is declared anywhere.

## The multicycle path and its proof

Claim: data launched into a `tensor_unit` operand register (`A_flat`, `B_flat`) is first
captured by an accumulator register (`C_flat`) two clock edges later, so the
operand-register-to-accumulator paths may take two cycles. Paths from the row/col/k
counters through the 16:1 mux *selects* remain single-cycle (the exception is per
start/end register pair, and the counters are not in the `-from` set).

Proof obligations, written against the **unmodified** upstream `tensor_unit`
(`formal/tensor_unit_mcp.sv`, hierarchical references into the DUT):

* P1 — if any `A_flat`/`B_flat` bit changed at the last edge, the FSM is not in `CALC`
  now, so `C_flat` cannot capture an A/B-dependent value at the next edge;
* P2 — `C_flat` changes only in `CALC` (MAC write), on an accepted `start` (clear to 0,
  independent of A/B), or under reset.

Run with Yosys `sat -tempinduct` (unbounded k-induction):
`python -m timinglab.regress formal` → `Induction step proven: SUCCESS!`. A vacuity
check (`--negative`) flips P1 to a false statement and requires a counterexample.

Register identification in the SDC is **structural**, not by name (names are not stable
after flattening and mapping): `from` = every register in the fan-out of
`mat_a_row*`/`mat_b_col*` (1,024 registers), `to` = every register in the fan-in of
`result_row*` (512). OpenSTA reports both counts (`TL-SDC: tensor MCP from 1024 … to 512`).
In the flattened top-level netlist the same exception is written with name patterns,
which do not match after flattening; `tl_cells` then prints `TL-SDC-WARN … exception
skipped` instead of silently constraining nothing. The exception does not touch the
critical path (that starts at the counters), so its effect on reported WNS is nil — it is
included as the worked example of an exception "supported by functional evidence".
