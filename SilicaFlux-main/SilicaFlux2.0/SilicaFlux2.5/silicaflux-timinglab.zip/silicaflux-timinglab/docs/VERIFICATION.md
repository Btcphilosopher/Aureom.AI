# Verification and acceptance

Every TimingLab RTL alternative must pass the seven gates below. Commands are what CI
runs (`.github/workflows/timinglab.yml`); results of the run that produced `reports/`
are in `docs/RESULTS.md` §5 and `reports/regression/*.json`.

| # | Gate | How | Kind of evidence |
|---|---|---|---|
| 1 | Syntax & elaboration | Yosys `read_slang` elaborates every design in `flow/designs.toml` (part of `timinglab audit --all` and of synthesis); Verilator builds every testbench | tool |
| 2 | Lint | `verilator --lint-only -Wall` on `rtl/opt/*` must be clean (`tests/test_verification.py::test_timinglab_rtl_is_lint_clean`); upstream lint is reported, not gated (`make lint`) | tool |
| 3 | Functional simulation | upstream testbenches still pass (`regress upstream-sim`, Icarus); tensor, vector (LANES 4/8/16) and tile **equivalence testbenches** against the unmodified upstream RTL plus an independent reference model (`regress equiv`) | simulation |
| 4 | Formal | k-induction proof of the multicycle-path obligations on the upstream `tensor_unit` with a vacuity check (`regress formal`, `--negative`) | proof |
| 5 | Synthesis | Yosys → Liberty mapping for SKY130 / GF180MCU / IHP SG13G2 (`timinglab run`) | tool |
| 6 | Timing analysis | OpenSTA on the netlist; OpenROAD placement, CTS, global route with propagated clocks | tool |
| 7 | Reproducible PPA | `timinglab report` + `scripts/check_ppa.py` (alternative must be ≥ 5 % faster, ≤ 25 % larger); two independent runs of the flow produced identical cell counts, areas and slacks | tool |

## Equivalence testbenches (gate 3)

* **`tb/equiv/tb_eq_tensor.sv`** — transaction level. Random matrices biased to corner
  values (0, 1, −1, `0x7FFFFFFF`, `0x80000000`, 16-bit values); operand inputs are
  scrambled after `start` (both units must have latched them); spurious `start` pulses
  while busy must be ignored. Checks per transaction: both units equal the model
  `C = A·B mod 2^32`; `done` arrives exactly +1 cycle later on the pipelined unit; `busy`
  falls with `done`; results stay stable until the next start.
* **`tb/equiv/tb_eq_vector.sv`** — cycle level. Every cycle (not only valid cycles) all four
  outputs of the pipelined unit equal upstream's outputs two cycles earlier; issue cycles
  are also checked against an independent model. LANES = 16 shows upstream's F-VEC-1
  deviation; the TB requires the pipelined unit to match the model there.
* **`tb/equiv/tb_eq_tile.sv`** — tile level: upstream `compute_tile` vs the generated
  `sf_compute_tile_pipe`, identical random token streams, results compared per token, extra
  latency histogram reported.
* **Mutation sensitivity** — `tests/test_verification.py` injects four mutants (wrong
  partial-product combine, wrong accumulator reset condition, early `done`, unsigned MIN)
  and requires each equivalence TB to fail.

Simulation is not proof; the long CI run uses 5,000 tensor transactions and 200,000
vector cycles per LANES value.

## Why the datapath equivalence is simulation-based

A formal sequential-equivalence proof between a single-cycle 32×32 multiplier and a
split, pipelined one is a SAT problem over two structurally different multipliers, which
does not finish in reasonable time with the open-source solvers available here. The
control-side claim that matters for timing sign-off — the multicycle path — *is* proven
formally (gate 4), and the datapath identity used by the split multiplier is algebraic
(documented in `rtl/opt/sf_mul_lo_pipe.sv`).

## Functional findings

`python -m timinglab.regress bugs` reproduces F-PIPE-1, F-ISA-1, F-NOC-1, F-VEC-1 and
F-TIF-1 (`docs/FINDINGS.md`). They are reported, not gated: TimingLab does not change
upstream behaviour outside the two datapaths it replaces.

## Test tiers

* `pytest -q tests` — fast tier (~75 s): parsers on real OpenSTA/OpenROAD reports, scanner
  and discovery, audit graph algorithms on hand-built netlists, dashboard/CSV/JSON
  export, hypothesis confirmation, equivalence, mutation, findings, lint.
* `RUN_SLOW=1 pytest -q tests` — adds the formal proof + vacuity check (~5 min) and a
  synthesis + STA smoke run.
