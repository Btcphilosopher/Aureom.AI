# Upstream sources (vendored, unmodified)

TimingLab analyses the SilicaFlux RTL exactly as published. Nothing under
`upstream/` has been edited; every TimingLab change lives in `rtl/opt/`,
`rtl/harness/`, `constraints/`, `tb/` and `formal/`.

| Path | Origin | SHA-256 of archive |
|---|---|---|
| `upstream/silicaflux/` | `github.com/Btcphilosopher/SilicaFlux` @ `1244025bd8e0e8ce89619ebe9adcfa20e8086ab8`, archive `silicaflux.zip` | `ccb055b8f292b1580a85523c921084fdcb62c3570060961758c79f93135e9876` |
| `upstream/silicaflux-ai/rtl/` | same commit, archive `SilicaFlux2.0/silicafluxai.zip` (`silicaflux-ai/rtl` only) | `21e200b074cf6ae3b38a17f26fe3dd47791d895a48e7707390cf4f9ef4c3960a` |

Two deviations from a byte-for-byte copy of the archive, both outside the RTL:

* `silicaflux.zip` contains two empty directories literally named `{rtl,tb,sim` and
  `{rtl,tb,sim/programs,docs}` (an unexpanded shell brace pattern). They hold no
  files and were not copied.
* `sim/build/` (simulation outputs created by running `run_sim.sh`) is not shipped.

Reproduce the check:

```bash
git clone https://github.com/Btcphilosopher/SilicaFlux && cd SilicaFlux
git checkout 1244025bd8e0e8ce89619ebe9adcfa20e8086ab8
sha256sum silicaflux.zip SilicaFlux2.0/silicafluxai.zip
unzip -q silicaflux.zip -d /tmp/sf && diff -r /tmp/sf/silicaflux <timinglab>/upstream/silicaflux
```
