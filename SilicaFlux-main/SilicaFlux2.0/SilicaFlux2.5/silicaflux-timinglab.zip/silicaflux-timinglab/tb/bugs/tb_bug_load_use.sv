// =============================================================================
// SilicaFlux TimingLab — functional finding F-PIPE-1 (pipeline hazard)
// Does a load-use dependency make progress through silicaflux_top?
//
// control_core.sv:114-121 raises id_stall when the IS/EX instruction is a LOAD
// whose rd matches a source of the instruction in ID/IS. While id_stall is high
// neither is_ex (control_core.sv:131) nor id_is (decoder.sv:112) advance, so the
// hazard condition is re-evaluated on unchanged registers.
//
// Program:  0: LOAD r2, [r0+0]
//           1: ADD  r3, r2, r2      (load-use dependency on r2)
//           2: MOV  r4, 7
//           3: HALT (opcode 0x1F)
// Expectation (README "RAW (load-use): 1-cycle stall"): r4 == 7 and halt
// within a few cycles. The TB reports what actually happens.
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

module tb_bug_load_use;
  import silicaflux_pkg::*;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic imem_wr_en = 0;
  logic [PC_WIDTH-1:0] imem_wr_addr = '0;
  logic [XLEN-1:0] imem_wr_data = '0;
  logic [7:0] phy_tx_data; logic phy_tx_valid, phy_rx_credit, halt;
  logic [XLEN-1:0] dbg;

  silicaflux_top dut (.clk, .rst_n, .imem_wr_en, .imem_wr_addr, .imem_wr_data,
    .tile_phy_tx_data(phy_tx_data), .tile_phy_tx_valid(phy_tx_valid), .tile_phy_tx_credit(1'b1),
    .tile_phy_rx_data(8'h00), .tile_phy_rx_valid(1'b0), .tile_phy_rx_credit(phy_rx_credit),
    .halt, .debug_scalar_r1(dbg));

  function automatic logic [31:0] enc_i(logic [4:0] op, logic [4:0] rd, logic [4:0] rs1, logic [16:0] imm);
    return {op, rd, rs1, imm};
  endfunction
  function automatic logic [31:0] enc_r(logic [4:0] op, logic [4:0] rd, logic [4:0] rs1, logic [4:0] rs2);
    return {op, rd, rs1, rs2, 12'h0};
  endfunction

  task automatic load(int addr, logic [31:0] w);
    @(negedge clk); imem_wr_en = 1; imem_wr_addr = addr[PC_WIDTH-1:0]; imem_wr_data = w;
    @(negedge clk); imem_wr_en = 0;
  endtask

  int stall_cycles = 0, cyc = 0;
  logic [PC_WIDTH-1:0] pc_prev;
  initial begin
    load(0, enc_i(OP_LOAD, 5'd2, 5'd0, 17'd0));
    // +NODEP control experiment: same program without the dependency
    if ($test$plusargs("NODEP")) load(1, enc_r(OP_ADD, 5'd3, 5'd1, 5'd1));
    else                         load(1, enc_r(OP_ADD, 5'd3, 5'd2, 5'd2));
    load(2, enc_i(OP_MOV, 5'd4, 5'd0, 17'd7));
    load(3, {5'h1F, 27'h0});
    for (int i = 4; i < 16; i++) load(i, 32'h0);
    repeat (2) @(negedge clk);
    rst_n = 1;
    while (cyc < 200 && !halt) begin
      @(posedge clk); cyc++;
      if (dut.u_ctrl.id_stall) stall_cycles++;
    end
    // halt is flagged when HALT reaches IF/ID (silicaflux_top.sv:457-462); let the
    // older instructions drain through IS/EX/MEM/WB before checking state.
    repeat (8) @(posedge clk);
    $display("INFO cycles=%0d stall_cycles=%0d halt=%0b r4=%0d pc=%0d load_use_hazard=%0b",
             cyc, stall_cycles, halt, dut.u_regs.sregs[4], dut.u_fetch.pc_reg, dut.u_ctrl.load_use_hazard);
    if (halt && dut.u_regs.sregs[4] == 7)
      $display("[PASS] program completed: r4=7 (%0d stall cycles)", stall_cycles);
    else
      $display("[FINDING] F-PIPE-1: program did not complete in 200 cycles (halt=%0b, r4=%0d, stall cycles %0d)", halt, dut.u_regs.sregs[4], stall_cycles);
    $finish;
  end
endmodule
