// =============================================================================
// SilicaFlux TimingLab — functional finding F-TIF-1
// Does tile_interface deliver the flit it just received?
//
// tile_interface.sv:217-233: in RX_EJECT the received bits are unpacked into
// rx_assembled with non-blocking assignments and, in the SAME clock edge,
// rx_flit_out <= rx_assembled — i.e. the previous contents of rx_assembled.
// Second defect: TX sends ceil(43/8) = 6 beats (48 bits) but RX shifts every
// beat into the MSBs of a 43-bit register (lines 196-207), so the assembled
// flit is misaligned by 48-43 = 5 bits. A bit-exact model of both effects
// (docs/FINDINGS.md, F-TIF-1) predicts the second delivery exactly.
// Two instances are connected TX->RX (credit looped back) and two different
// flits are sent; the TB compares each delivered flit with the one sent.
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"
module tb_bug_tif_rx;
  import silicaflux_pkg::*;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  noc_flit_t a_tx, b_rx, a_rx_unused, b_tx;
  logic a_tx_v, a_tx_r, b_rx_v, a_rx_v, b_tx_r;
  logic [7:0] a_phy, b_phy;
  logic a_phy_v, b_phy_v, a_credit_out, b_credit_out;

  // A transmits to B; B's RX credit throttles A's TX.
  tile_interface #(.LINK_WIDTH(8)) u_a (.clk, .rst_n,
    .tx_flit_in(a_tx), .tx_flit_valid(a_tx_v), .tx_flit_ready(a_tx_r),
    .rx_flit_out(a_rx_unused), .rx_flit_valid(a_rx_v), .rx_flit_ready(1'b1),
    .phy_tx_data(a_phy), .phy_tx_valid(a_phy_v), .phy_tx_credit(b_credit_out),
    .phy_rx_data(8'h00), .phy_rx_valid(1'b0), .phy_rx_credit(a_credit_out),
    .link_up(), .parity_error());
  tile_interface #(.LINK_WIDTH(8)) u_b (.clk, .rst_n,
    .tx_flit_in('0), .tx_flit_valid(1'b0), .tx_flit_ready(b_tx_r),
    .rx_flit_out(b_rx), .rx_flit_valid(b_rx_v), .rx_flit_ready(1'b1),
    .phy_tx_data(b_phy), .phy_tx_valid(b_phy_v), .phy_tx_credit(1'b1),
    .phy_rx_data(a_phy), .phy_rx_valid(a_phy_v), .phy_rx_credit(b_credit_out),
    .link_up(), .parity_error());

  noc_flit_t sent [2];
  int got = 0, findings = 0;
  always @(posedge clk) if (rst_n && b_rx_v) begin
    if (got < 2) begin
      if (b_rx.data !== sent[got].data || b_rx.dst_col !== sent[got].dst_col) begin
        findings++;
        $display("[FINDING] F-TIF-1 flit %0d: delivered data=%08h dst_col=%0d, sent data=%08h dst_col=%0d",
                 got, b_rx.data, b_rx.dst_col, sent[got].data, sent[got].dst_col);
      end else $display("[PASS] flit %0d delivered intact", got);
    end
    got++;
  end

  task automatic send(noc_flit_t f);
    @(negedge clk); while (!a_tx_r) @(negedge clk);
    a_tx = f; a_tx_v = 1;
    @(negedge clk); a_tx_v = 0;
  endtask

  initial begin
    a_tx = '0; a_tx_v = 0;
    sent[0] = '0; sent[0].flit_type = FLIT_SINGLE; sent[0].dst_col = 2'd1; sent[0].data = 32'h1111_AAAA; sent[0].valid = 1;
    sent[1] = '0; sent[1].flit_type = FLIT_SINGLE; sent[1].dst_col = 2'd2; sent[1].data = 32'h2222_BBBB; sent[1].valid = 1;
    repeat (3) @(negedge clk); rst_n = 1;
    send(sent[0]);
    repeat (40) @(negedge clk);
    send(sent[1]);
    repeat (60) @(negedge clk);
    $display("SUMMARY delivered=%0d findings=%0d", got, findings);
    $finish;
  end
endmodule
