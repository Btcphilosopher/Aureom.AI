// =============================================================================
// SilicaFlux TimingLab — functional finding F-ISA-1
// Can STORE write a register value to memory?
//
// ISA_REFERENCE.md: STORE  MEM[rs1 + sext(imm17)] = rs2 (I-format). The
// I-format has no rs2 field; sfx_asm.py:234-239 parses rs2 and drops it, and
// decoder.sv:69-74 forces rs2 = 0, so the store data is always r0 (= 0).
// Program: MOV r1, 0x55 ; 4x NOP ; STORE [r0+8] <- r1 (assembler encoding) ;
//          6x NOP ; HALT. Expected by the ISA text: control-memory word 2 = 0x55.
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

module tb_bug_store_data;
  import silicaflux_pkg::*;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic imem_wr_en = 0;
  logic [PC_WIDTH-1:0] imem_wr_addr = '0;
  logic [XLEN-1:0] imem_wr_data = '0;
  logic [7:0] phy_tx_data; logic phy_tx_valid, phy_rx_credit, halt;
  logic [XLEN-1:0] dbg;

  silicaflux_top dut (.clk, .rst_n, .imem_wr_en, .imem_wr_addr, .imem_wr_data,
    .tile_phy_tx_data(phy_tx_data), .tile_phy_tx_valid(phy_tx_valid), .tile_phy_tx_credit(1'b1),
    .tile_phy_rx_data(8'h00), .tile_phy_rx_valid(1'b0), .tile_phy_rx_credit(phy_rx_credit),
    .halt, .debug_scalar_r1(dbg));

  function automatic logic [31:0] enc_i(logic [4:0] op, logic [4:0] rd, logic [4:0] rs1, logic [16:0] imm);
    return {op, rd, rs1, imm};
  endfunction
  function automatic logic [31:0] enc_r(logic [4:0] op, logic [4:0] rd, logic [4:0] rs1, logic [4:0] rs2);
    return {op, rd, rs1, rs2, 12'h0};
  endfunction

  task automatic load(int addr, logic [31:0] w);
    @(negedge clk); imem_wr_en = 1; imem_wr_addr = addr[PC_WIDTH-1:0]; imem_wr_data = w;
    @(negedge clk); imem_wr_en = 0;
  endtask

  int cyc = 0;
  int n_store = 0;
  logic [XLEN-1:0] st_data = 'x, st_addr = 'x;
  // observe the store request actually issued to the control-core scratchpad
  always @(posedge clk) if (rst_n && dut.u_ctrl_mem.req_valid && dut.u_ctrl_mem.req_opcode == OP_STORE) begin
    n_store++; st_data = dut.u_ctrl_mem.req_wdata; st_addr = dut.u_ctrl_mem.req_addr;
  end
  initial begin
    load(0, enc_i(OP_MOV, 5'd1, 5'd0, 17'h55));
    for (int i = 1; i <= 4; i++) load(i, 32'h0);
    load(5, enc_i(OP_STORE, 5'd0, 5'd0, 17'd8));     // rd=0, rs1=r0, imm=8 (rs2 unencodable)
    for (int i = 6; i <= 11; i++) load(i, 32'h0);
    load(12, {5'h1F, 27'h0});
    for (int i = 13; i < 20; i++) load(i, 32'h0);
    repeat (2) @(negedge clk);
    rst_n = 1;
    while (cyc < 200 && !halt) begin @(posedge clk); cyc++; end
    repeat (8) @(posedge clk);
    $display("INFO halt=%0b r1=%0h stores_issued=%0d store_addr=%0h store_data=%0h",
             halt, dut.u_regs.sregs[1], n_store, st_addr, st_data);
    if (n_store == 1 && st_data === 32'h55) $display("[PASS] STORE wrote r1");
    else if (n_store == 1)
      $display("[FINDING] F-ISA-1: STORE issued with data %0h instead of r1=%0h (store data register is not encodable)",
               st_data, dut.u_regs.sregs[1]);
    else $display("[FAIL] expected exactly one store request, saw %0d", n_store);
    $finish;
  end
endmodule
