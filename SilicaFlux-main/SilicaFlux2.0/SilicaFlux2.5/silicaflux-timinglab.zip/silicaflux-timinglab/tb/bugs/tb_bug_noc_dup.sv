// =============================================================================
// SilicaFlux TimingLab — functional finding F-NOC-1 (router level)
// How many times is a single injected flit delivered by noc_router?
//
// noc_router.sv releases an input buffer only when the output it routes to is
// accepted downstream (out_accept[rt[i]], lines 94-119), while the output
// arbiter (lines 125-190) re-loads obuf from any still-valid input buffer in the
// same cycle obuf is accepted. With an always-ready sink the same flit can be
// copied into obuf twice before the input buffer clears.
// The router has flat ports only, so this TB gives the same result in Icarus
// and in the Verilator simulator (unlike the 2-D array ports of noc_interconnect).
// Scenarios: LOCAL->LOCAL and LOCAL->EAST, each with one injected flit.
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"
module tb_bug_noc_dup;
  import silicaflux_pkg::*;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic [42:0] lin; logic lin_v, lin_r;
  logic [NOC_WIDTH-1:0] lout; logic lout_v;
  logic [42:0] eout; logic eout_v;
  logic [42:0] nout, sout, wout; logic nout_v, sout_v, wout_v;
  logic nin_r, sin_r, ein_r, win_r;

  noc_router #(.MY_ROW(0), .MY_COL(0)) dut (.clk, .rst_n,
    .local_in_data(lin), .local_in_valid(lin_v), .local_in_ready(lin_r),
    .local_out_data(lout), .local_out_valid(lout_v), .local_out_ready(1'b1),
    .north_in_data(43'd0), .north_in_valid(1'b0), .north_in_ready(nin_r),
    .north_out_data(nout), .north_out_valid(nout_v), .north_out_ready(1'b1),
    .south_in_data(43'd0), .south_in_valid(1'b0), .south_in_ready(sin_r),
    .south_out_data(sout), .south_out_valid(sout_v), .south_out_ready(1'b1),
    .east_in_data(43'd0), .east_in_valid(1'b0), .east_in_ready(ein_r),
    .east_out_data(eout), .east_out_valid(eout_v), .east_out_ready(1'b1),
    .west_in_data(43'd0), .west_in_valid(1'b0), .west_in_ready(win_r),
    .west_out_data(wout), .west_out_valid(wout_v), .west_out_ready(1'b1));

  // flit packing used by noc_interconnect.sv:39-41
  function automatic logic [42:0] pk(logic [1:0] dr, logic [1:0] dc, logic [31:0] d);
    return {FLIT_SINGLE, dr, dc, 2'd0, 2'd0, d, 1'b1};
  endfunction

  int n_local, n_east, findings;
  task automatic run(string name, logic [1:0] dr, logic [1:0] dc);
    n_local = 0; n_east = 0;
    @(negedge clk); lin = pk(dr, dc, 32'hCAFE_0001); lin_v = 1;
    @(negedge clk); lin_v = 0;
    repeat (20) begin
      @(posedge clk); #1;
      if (lout_v) n_local++;
      if (eout_v) n_east++;
    end
    $display("INFO %s: local deliveries=%0d east deliveries=%0d", name, n_local, n_east);
    if ((dc == 0 && n_local == 1 && n_east == 0) || (dc == 1 && n_east == 1 && n_local == 0))
      $display("[PASS] %s: delivered exactly once", name);
    else begin
      findings++;
      $display("[FINDING] F-NOC-1 %s: one injected flit produced local=%0d east=%0d deliveries", name, n_local, n_east);
    end
  endtask

  initial begin
    lin = '0; lin_v = 0; findings = 0;
    repeat (3) @(negedge clk); rst_n = 1;
    run("LOCAL->LOCAL", 2'd0, 2'd0);
    repeat (5) @(negedge clk);
    run("LOCAL->EAST", 2'd0, 2'd1);
    $display("SUMMARY findings=%0d", findings);
    $finish;
  end
endmodule
