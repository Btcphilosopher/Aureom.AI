// =============================================================================
// SilicaFlux TimingLab — transaction-level equivalence: tensor_unit (upstream)
// vs sf_tensor_unit_pipe (TimingLab), plus an independent reference model.
//
// Checks per transaction:
//   * ref result == model, dut result == model (C = A x B mod 2^32)
//   * dut done arrives exactly EXTRA_LAT cycles after ref done
//   * busy falls in the cycle done rises (both units)
//   * dut results stay stable from done until the next accepted start
//   * start pulses while busy are ignored by both
// Plusargs: +NTRANS=<n> +SEED=<s>
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

module tb_eq_tensor;
  import silicaflux_pkg::*;
  localparam int EXTRA_LAT = 1;

  logic clk = 0, rst_n = 0, start = 0;
  always #5 clk = ~clk;

  logic [4*XLEN-1:0] a_row [4];
  logic [4*XLEN-1:0] b_col [4];
  logic [4*XLEN-1:0] sa_row [4];   // operands captured at start, for the model
  logic [4*XLEN-1:0] sb_col [4];
  logic ref_done, ref_busy, dut_done, dut_busy;
  logic [4*XLEN-1:0] ref_row [4];
  logic [4*XLEN-1:0] dut_row [4];

  tensor_unit u_ref (
    .clk, .rst_n, .start,
    .mat_a_row0(a_row[0]), .mat_a_row1(a_row[1]), .mat_a_row2(a_row[2]), .mat_a_row3(a_row[3]),
    .mat_b_col0(b_col[0]), .mat_b_col1(b_col[1]), .mat_b_col2(b_col[2]), .mat_b_col3(b_col[3]),
    .done(ref_done), .busy(ref_busy),
    .result_row0(ref_row[0]), .result_row1(ref_row[1]), .result_row2(ref_row[2]), .result_row3(ref_row[3]));

  sf_tensor_unit_pipe u_dut (
    .clk, .rst_n, .start,
    .mat_a_row0(a_row[0]), .mat_a_row1(a_row[1]), .mat_a_row2(a_row[2]), .mat_a_row3(a_row[3]),
    .mat_b_col0(b_col[0]), .mat_b_col1(b_col[1]), .mat_b_col2(b_col[2]), .mat_b_col3(b_col[3]),
    .done(dut_done), .busy(dut_busy),
    .result_row0(dut_row[0]), .result_row1(dut_row[1]), .result_row2(dut_row[2]), .result_row3(dut_row[3]));

  int unsigned seed;
  int ntrans;
  int errors = 0, checks = 0;

  function automatic logic [XLEN-1:0] rnd_word();
    int unsigned sel = $urandom % 8;
    case (sel)
      0: return 32'h0;
      1: return 32'h1;
      2: return 32'hFFFF_FFFF;
      3: return 32'h7FFF_FFFF;
      4: return 32'h8000_0000;
      5: return {16'h0, 16'($urandom)};
      default: return 32'($urandom);
    endcase
  endfunction

  // Reference model: C[r][c] = sum_k A[r][k]*B[k][c] (mod 2^32)
  function automatic logic [XLEN-1:0] model(int r, int c);
    logic [XLEN-1:0] acc = '0;
    for (int k = 0; k < 4; k++)
      acc += sa_row[r][k*XLEN +: XLEN] * sb_col[c][k*XLEN +: XLEN];
    return acc;
  endfunction

  task automatic check_eq(string what, logic [XLEN-1:0] got, logic [XLEN-1:0] exp);
    checks++;
    if (got !== exp) begin
      errors++;
      if (errors <= 10) $display("[FAIL] %s got=%08h exp=%08h", what, got, exp);
    end
  endtask

  int t_ref_done, t_dut_done, cyc;
  always @(posedge clk) cyc <= cyc + 1;

  // protocol monitors
  always @(posedge clk) if (rst_n) begin
    if (ref_done && ref_busy) begin errors++; $display("[FAIL] ref busy high with done"); end
    if (dut_done && dut_busy) begin errors++; $display("[FAIL] dut busy high with done"); end
  end

  initial begin
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("NTRANS=%d", ntrans)) ntrans = 200;
    void'($urandom(seed));
    cyc = 0;
    for (int i = 0; i < 4; i++) begin a_row[i] = '0; b_col[i] = '0; end
    repeat (3) @(posedge clk);
    rst_n = 1;
    repeat (2) @(posedge clk);

    for (int t = 0; t < ntrans; t++) begin
      // new operands
      for (int i = 0; i < 4; i++)
        for (int k = 0; k < 4; k++) begin
          a_row[i][k*XLEN +: XLEN] = rnd_word();
          b_col[i][k*XLEN +: XLEN] = rnd_word();
        end
      for (int i = 0; i < 4; i++) begin sa_row[i] = a_row[i]; sb_col[i] = b_col[i]; end
      @(negedge clk); start = 1;
      @(negedge clk); start = 0;
      // operands are latched at start: scramble the inputs from now on
      for (int i = 0; i < 4; i++) begin
        a_row[i] = {4{32'($urandom)}};
        b_col[i] = {4{32'($urandom)}};
      end
      // Scramble operand inputs while busy (units must have latched them) and
      // throw in spurious start pulses that must be ignored.
      fork
        begin : wait_ref
          while (!ref_done) @(posedge clk);
          t_ref_done = cyc;
        end
        begin : wait_dut
          while (!dut_done) @(posedge clk);
          t_dut_done = cyc;
        end
        begin : noise
          repeat (20) begin
            @(negedge clk);
            if (($urandom % 4) == 0 && ref_busy && dut_busy) begin start = 1; @(negedge clk); start = 0; end
          end
        end
      join
      // compare both units against the model
      for (int r = 0; r < 4; r++)
        for (int c = 0; c < 4; c++) begin
          check_eq($sformatf("t%0d ref C[%0d][%0d]", t, r, c), ref_row[r][c*XLEN +: XLEN], model(r, c));
          check_eq($sformatf("t%0d dut C[%0d][%0d]", t, r, c), dut_row[r][c*XLEN +: XLEN], model(r, c));
        end
      checks++;
      if (t_dut_done - t_ref_done != EXTRA_LAT) begin
        errors++;
        $display("[FAIL] t%0d latency delta %0d (expected %0d)", t, t_dut_done - t_ref_done, EXTRA_LAT);
      end
      // stability: results must not change while idle
      repeat ($urandom % 5) begin
        @(posedge clk);
        for (int r = 0; r < 4; r++)
          check_eq($sformatf("t%0d dut stable row%0d", t, r), dut_row[r][31:0], model(r, 0));
      end
    end
    if (errors == 0) $display("[PASS] tb_eq_tensor: %0d transactions, %0d checks, seed %0d", ntrans, checks, seed);
    else             $display("[FAIL] tb_eq_tensor: %0d errors in %0d checks, seed %0d", errors, checks, seed);
    $finish;
  end

  initial begin
    #50_000_000;
    $display("[FAIL] tb_eq_tensor: timeout");
    $finish;
  end
endmodule
