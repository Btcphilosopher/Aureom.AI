// =============================================================================
// SilicaFlux TimingLab — tile-level equivalence: compute_tile (upstream) vs
// sf_compute_tile_pipe (same tile with the pipelined vector/tensor units).
//
// Both tiles receive the identical random token stream (vector, reduce, dot,
// broadcast, matmul, scalar/vector/burst memory ops, dfsync, and opcodes the tile
// ignores). For every token the TB waits until each tile reports tile_done (or a
// timeout, for tokens the tile FSM drops) and compares tile_result_scalar /
// tile_result_vector and the done/timeout outcome. Latency differences are
// recorded, not treated as errors: they are absorbed by the token handshake.
// Plusargs: +NTOK=<n> +SEED=<s>
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"
module tb_eq_tile;
  import silicaflux_pkg::*;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic [4:0] op; logic [2:0] tid; logic [4:0] sreg, dreg; logic [3:0] vs, vd;
  logic [13:0] addr; logic [4:0] len; logic [7:0] fn;
  logic tv;
  logic [XLEN-1:0] sc; logic [VLEN-1:0] va, vb;

  logic r_rdy, d_rdy, r_done, d_done, r_err, d_err;
  logic [XLEN-1:0] r_s, d_s; logic [VLEN-1:0] r_v, d_v;
  noc_flit_t r_fo, d_fo; logic r_fv, d_fv, r_fir, d_fir;

  compute_tile #(.TILE_ID(0)) u_ref (.clk, .rst_n, .tok_opcode(op), .tok_tile_id(tid), .tok_src_reg(sreg),
    .tok_dst_reg(dreg), .tok_vsrc_reg(vs), .tok_vdst_reg(vd), .tok_mem_addr(addr), .tok_length(len),
    .tok_func(fn), .token_valid(tv), .token_ready(r_rdy), .scalar_data_in(sc), .vector_data_in(va),
    .vector_data_in_b(vb), .tile_done(r_done), .tile_error(r_err), .tile_result_scalar(r_s),
    .tile_result_vector(r_v), .noc_flit_out(r_fo), .noc_flit_valid(r_fv), .noc_flit_ready(1'b1),
    .noc_flit_in('0), .noc_flit_in_valid(1'b0), .noc_flit_in_ready(r_fir));
  sf_compute_tile_pipe #(.TILE_ID(0)) u_dut (.clk, .rst_n, .tok_opcode(op), .tok_tile_id(tid), .tok_src_reg(sreg),
    .tok_dst_reg(dreg), .tok_vsrc_reg(vs), .tok_vdst_reg(vd), .tok_mem_addr(addr), .tok_length(len),
    .tok_func(fn), .token_valid(tv), .token_ready(d_rdy), .scalar_data_in(sc), .vector_data_in(va),
    .vector_data_in_b(vb), .tile_done(d_done), .tile_error(d_err), .tile_result_scalar(d_s),
    .tile_result_vector(d_v), .noc_flit_out(d_fo), .noc_flit_valid(d_fv), .noc_flit_ready(1'b1),
    .noc_flit_in('0), .noc_flit_in_valid(1'b0), .noc_flit_in_ready(d_fir));

  int cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  int unsigned seed; int ntok, errors = 0, checks = 0, extra_cycles_total = 0, done_tokens = 0;
  int hist_extra [0:127];

  function automatic logic [4:0] rnd_op();
    case ($urandom % 14)
      0: return OP_VADD;   1: return OP_VSUB;   2: return OP_VMUL;   3: return OP_DOT;
      4: return OP_REDUCE; 5: return OP_BCAST;  6: return OP_MATMUL; 7: return OP_LOAD;
      8: return OP_STORE;  9: return OP_VLOAD;  10: return OP_VSTORE; 11: return OP_DFLOAD;
      12: return OP_DFSYNC; default: return OP_DFSTORE;
    endcase
  endfunction

  task automatic wait_done(output bit r_ok, output bit d_ok, output int r_t, output int d_t,
                           output logic [XLEN-1:0] rs, output logic [VLEN-1:0] rv,
                           output logic [XLEN-1:0] ds, output logic [VLEN-1:0] dv);
    int t0 = cyc;
    r_ok = 0; d_ok = 0; r_t = 0; d_t = 0;
    while ((!r_ok || !d_ok) && (cyc - t0) < 300) begin
      @(posedge clk); #1;
      if (r_done && !r_ok) begin r_ok = 1; r_t = cyc - t0; rs = r_s; rv = r_v; end
      if (d_done && !d_ok) begin d_ok = 1; d_t = cyc - t0; ds = d_s; dv = d_v; end
    end
  endtask

  initial begin
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("NTOK=%d", ntok)) ntok = 500;
    void'($urandom(seed));
    op = '0; tid = '0; sreg = '0; dreg = '0; vs = '0; vd = '0; addr = '0; len = '0; fn = '0; tv = 0;
    sc = '0; va = '0; vb = '0;
    for (int i = 0; i < 128; i++) hist_extra[i] = 0;
    repeat (3) @(negedge clk); rst_n = 1;
    repeat (2) @(negedge clk);
    for (int t = 0; t < ntok; t++) begin
      bit r_ok, d_ok; int r_t, d_t;
      logic [XLEN-1:0] rs, ds; logic [VLEN-1:0] rv, dv;
      while (!(r_rdy && d_rdy)) @(negedge clk);
      op = rnd_op(); fn = 8'($urandom); len = 5'($urandom % 5); addr = 14'($urandom % 64);
      sc = 32'($urandom); va = {4{32'($urandom)}} ^ {32'($urandom), 96'h0}; vb = {32'($urandom), 32'($urandom), 32'($urandom), 32'($urandom)};
      tv = 1;
      @(negedge clk); tv = 0;
      wait_done(r_ok, d_ok, r_t, d_t, rs, rv, ds, dv);
      checks++;
      if (r_ok !== d_ok) begin
        errors++; $display("[FAIL] tok %0d op %0h: done ref=%0b dut=%0b", t, op, r_ok, d_ok);
      end else if (r_ok) begin
        done_tokens++;
        if (rs !== ds || rv !== dv) begin
          errors++;
          if (errors <= 10) $display("[FAIL] tok %0d op %0h: scalar ref=%08h dut=%08h vec ref=%032h dut=%032h",
                                     t, op, rs, ds, rv, dv);
        end
        if (d_t - r_t >= 0 && d_t - r_t < 128) hist_extra[d_t - r_t]++;
        extra_cycles_total += d_t - r_t;
      end
      repeat ($urandom % 3) @(negedge clk);
    end
    $display("INFO extra-latency histogram (cycles:count):");
    for (int i = 0; i < 128; i++) if (hist_extra[i]) $display("INFO   +%0d : %0d", i, hist_extra[i]);
    if (errors == 0) $display("[PASS] tb_eq_tile: %0d tokens (%0d completed), %0d checks, seed %0d",
                              ntok, done_tokens, checks, seed);
    else $display("[FAIL] tb_eq_tile: %0d errors / %0d checks, seed %0d", errors, checks, seed);
    $finish;
  end
endmodule
