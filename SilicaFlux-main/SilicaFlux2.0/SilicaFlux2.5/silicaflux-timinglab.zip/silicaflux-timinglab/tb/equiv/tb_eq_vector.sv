// =============================================================================
// SilicaFlux TimingLab — cycle-level equivalence: vector_engine (upstream) vs
// sf_vector_engine_pipe (TimingLab), plus an independent reference model.
//
// Both units evaluate every cycle. After warm-up, for every cycle t:
//     dut.outputs(t) == ref.outputs(t - EXTRA_LAT)        (all four outputs)
// and, on cycles where an issue happened, both are checked against the model.
// For LANES = 16 upstream is KNOWN to disagree with the model on REDUCE/DOT
// (vector_engine.sv:143-144); the TB counts those as upstream deviations,
// not DUT errors, and still requires the DUT to match the model.
// Parameters: LANES. Plusargs: +NCYC=<n> +SEED=<s>
// =============================================================================
`timescale 1ns/1ps
`include "silicaflux_pkg.sv"

module tb_eq_vector #(parameter int LANES = 4);
  import silicaflux_pkg::*;
  localparam int EXTRA_LAT = 2;
  localparam int VW = LANES * XLEN;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic          issue_valid;
  logic [4:0]    opcode;
  logic [7:0]    func;
  logic [VW-1:0] vop_a, vop_b;
  logic [XLEN-1:0] scalar_in;

  logic r_valid, d_valid, r_is, d_is;
  logic [VW-1:0] r_vres, d_vres;
  logic [XLEN-1:0] r_sres, d_sres;

  vector_engine #(.LANES(LANES)) u_ref (.clk, .rst_n, .issue_valid, .opcode, .func, .vop_a, .vop_b,
    .scalar_in, .result_valid(r_valid), .vresult(r_vres), .scalar_result(r_sres), .is_scalar_result(r_is));
  sf_vector_engine_pipe #(.LANES(LANES)) u_dut (.clk, .rst_n, .issue_valid, .opcode, .func, .vop_a, .vop_b,
    .scalar_in, .result_valid(d_valid), .vresult(d_vres), .scalar_result(d_sres), .is_scalar_result(d_is));

  // ---- independent model (computes the expected registered outputs) --------
  function automatic logic [XLEN-1:0] rp(logic [XLEN-1:0] a, logic [XLEN-1:0] b, logic [1:0] op);
    case (op)
      2'd0: return a + b;
      2'd1: return ($signed(a) < $signed(b)) ? a : b;
      2'd2: return ($signed(a) > $signed(b)) ? a : b;
      default: return a & b;
    endcase
  endfunction

  typedef struct {
    logic valid; logic [VW-1:0] v; logic [XLEN-1:0] s; logic is;
  } out_t;

  function automatic out_t model(logic iv, logic [4:0] op, logic [7:0] fn, logic [VW-1:0] a,
                                 logic [VW-1:0] b, logic [XLEN-1:0] sc);
    out_t o;
    logic [XLEN-1:0] lane [LANES];
    logic [XLEN-1:0] red [LANES];
    int n;
    for (int i = 0; i < LANES; i++) begin
      logic [XLEN-1:0] x = a[i*XLEN +: XLEN], y = b[i*XLEN +: XLEN];
      case (op)
        OP_VADD: lane[i] = x + y;
        OP_VSUB: lane[i] = x - y;
        OP_VMUL, OP_DOT: lane[i] = x * y;
        OP_BCAST: lane[i] = sc;
        default: lane[i] = x;
      endcase
      red[i] = lane[i];
    end
    n = LANES;
    while (n > 1) begin
      for (int i = 0; i < n / 2; i++) red[i] = rp(red[2*i], red[2*i+1], fn[1:0]);
      n = n / 2;
    end
    o.valid = iv;
    if (op == OP_DOT || op == OP_REDUCE) begin o.v = '0; o.s = red[0]; o.is = 1'b1; end
    else begin
      for (int i = 0; i < LANES; i++) o.v[i*XLEN +: XLEN] = lane[i];
      o.s = '0; o.is = 1'b0;
    end
    return o;
  endfunction

  // ---- history of ref outputs for the delayed comparison --------------------
  logic          h_valid [EXTRA_LAT+1];
  logic [VW-1:0] h_v     [EXTRA_LAT+1];
  logic [XLEN-1:0] h_s   [EXTRA_LAT+1];
  logic          h_is    [EXTRA_LAT+1];
  out_t          m_hist  [EXTRA_LAT+2];

  int unsigned seed;
  int ncyc, errors = 0, checks = 0, upstream_dev = 0, issues = 0;

  function automatic logic [XLEN-1:0] rnd_word();
    case ($urandom % 8)
      0: return 32'h0;
      1: return 32'h1;
      2: return 32'hFFFF_FFFF;
      3: return 32'h7FFF_FFFF;
      4: return 32'h8000_0000;
      5: return 32'($signed(16'($urandom)));
      default: return 32'($urandom);
    endcase
  endfunction

  task automatic drive_random();
    int unsigned r = $urandom % 16;
    issue_valid = ($urandom % 3) != 0;
    case (r)
      0, 1:   opcode = OP_VADD;
      2, 3:   opcode = OP_VSUB;
      4, 5:   opcode = OP_VMUL;
      6, 7, 8: opcode = OP_DOT;
      9, 10, 11: opcode = OP_REDUCE;
      12:     opcode = OP_BCAST;
      default: opcode = 5'($urandom);   // any other opcode -> pass-through
    endcase
    func = 8'($urandom);
    for (int i = 0; i < LANES; i++) begin
      vop_a[i*XLEN +: XLEN] = rnd_word();
      vop_b[i*XLEN +: XLEN] = rnd_word();
    end
    scalar_in = rnd_word();
  endtask

  int cyc = 0;
  initial begin
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("NCYC=%d", ncyc)) ncyc = 20000;
    void'($urandom(seed));
    issue_valid = 0; opcode = '0; func = '0; vop_a = '0; vop_b = '0; scalar_in = '0;
    repeat (3) @(posedge clk);
    @(negedge clk) rst_n = 1;
    repeat (ncyc) begin
      @(negedge clk);
      drive_random();
      // model of what the REF registers at the next posedge
      for (int k = EXTRA_LAT + 1; k > 0; k--) m_hist[k] = m_hist[k-1];
      m_hist[0] = model(issue_valid, opcode, func, vop_a, vop_b, scalar_in);
      @(posedge clk); #1;
      cyc++;
      for (int k = EXTRA_LAT; k > 0; k--) begin
        h_valid[k] = h_valid[k-1]; h_v[k] = h_v[k-1]; h_s[k] = h_s[k-1]; h_is[k] = h_is[k-1];
      end
      h_valid[0] = r_valid; h_v[0] = r_vres; h_s[0] = r_sres; h_is[0] = r_is;
      if (cyc > EXTRA_LAT + 2) begin
        // DUT vs delayed REF, every cycle, every output
        checks++;
        if (d_valid !== h_valid[EXTRA_LAT] || d_vres !== h_v[EXTRA_LAT] ||
            d_sres !== h_s[EXTRA_LAT] || d_is !== h_is[EXTRA_LAT]) begin
          // a mismatch is only acceptable when REF itself deviates from the model
          out_t m = m_hist[EXTRA_LAT];
          if (d_valid === m.valid && d_vres === m.v && d_sres === m.s && d_is === m.is) begin
            upstream_dev++;
          end else begin
            errors++;
            if (errors <= 10)
              $display("[FAIL] cyc %0d: dut(v=%0b s=%08h is=%0b) ref-%0d(v=%0b s=%08h is=%0b)", cyc,
                       d_valid, d_sres, d_is, EXTRA_LAT, h_valid[EXTRA_LAT], h_s[EXTRA_LAT], h_is[EXTRA_LAT]);
          end
        end
        // REF vs model (ref output now corresponds to the drive one cycle ago)
        if (m_hist[0].valid) issues++;
        checks++;
        if (r_vres !== m_hist[0].v || r_sres !== m_hist[0].s || r_is !== m_hist[0].is) upstream_dev++;
      end
    end
    if (errors == 0)
      $display("[PASS] tb_eq_vector LANES=%0d: %0d cycles, %0d issues, %0d checks, upstream-vs-model deviations %0d, seed %0d",
               LANES, ncyc, issues, checks, upstream_dev, seed);
    else
      $display("[FAIL] tb_eq_vector LANES=%0d: %0d errors in %0d checks (upstream deviations %0d), seed %0d",
               LANES, errors, checks, upstream_dev, seed);
    $finish;
  end
endmodule
