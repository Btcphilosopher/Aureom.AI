"""Parsers for OpenROAD logs/reports (area, global-route resources, congestion)."""
from __future__ import annotations

import re
from pathlib import Path

NUM = r"-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?"


def parse_area(path: Path) -> dict:
    if not path.exists():
        return {}
    m = re.search(rf"Design area ({NUM}) u\^2 ({NUM})% utilization", path.read_text())
    return {"design_area_um2": float(m.group(1)), "utilization_pct": float(m.group(2))} if m else {}


def parse_grt_log(text: str) -> dict:
    out: dict = {}
    m = re.search(rf"Total wirelength: ({NUM}) um", text)
    if m:
        out["wirelength_um"] = float(m.group(1))
    # Final congestion report table
    idx = text.rfind("Final congestion report")
    if idx >= 0:
        layers = {}
        for line in text[idx:].splitlines()[1:60]:
            s = line.strip()
            if not s or s.startswith("-") or s.startswith("Layer"):
                if layers and s.startswith("[INFO"):
                    break
                continue
            m = re.match(rf"^(\S+)\s+(\d+)\s+(\d+)\s+({NUM})%\s+(\d+)\s*/\s*(\d+)\s*/\s*(\d+)", s)
            if m:
                layers[m.group(1)] = {"resource": int(m.group(2)), "demand": int(m.group(3)),
                                      "usage_pct": float(m.group(4)), "max_h_overflow": int(m.group(5)),
                                      "max_v_overflow": int(m.group(6)), "overflow": int(m.group(7))}
            elif s.startswith("[") and layers:
                break
        out["layers"] = layers
        if "Total" in layers:
            out["total_overflow"] = layers["Total"]["overflow"]
            out["total_usage_pct"] = layers["Total"]["usage_pct"]
    return out


def parse_congestion_report(path: Path) -> tuple[dict, set]:
    """Global-route congestion report (marker file): number of overflowing gcell
    regions and the set of nets crossing them (returned separately, it can be
    large). The summary is stored in the run record; the set is used once to
    annotate critical paths."""
    nets: set = set()
    regions = 0
    if path.exists():
        with path.open(errors="replace") as fh:
            for line in fh:
                s = line.strip()
                if s.startswith("bbox"):
                    regions += 1
                elif s.startswith("srcs:"):
                    for tok in s[5:].split():
                        nets.add(tok.replace("net:", ""))
    return {"available": path.exists(), "congested_regions": regions, "n_congested_nets": len(nets)}, nets


def annotate_congestion(stage: dict, nets: set) -> dict:
    """Count, for every reported path, how many of its nets cross overflowing
    gcells; summarise over the reg2reg paths."""
    tot = hit = 0
    for p in stage.get("paths_max", []):
        pn = p.get("nets", [])
        h = sum(1 for n in pn if n in nets)
        p["congested_nets_on_path"] = h if nets else None
        if p.get("group") == "reg2reg":
            tot += len(pn)
            hit += h
    return {"reg2reg_path_nets": tot, "reg2reg_path_nets_congested": hit,
            "fraction": round(hit / tot, 3) if tot else None}
