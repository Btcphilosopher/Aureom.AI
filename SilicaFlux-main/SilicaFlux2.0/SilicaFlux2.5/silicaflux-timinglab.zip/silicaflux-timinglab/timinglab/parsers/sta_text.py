"""Parsers for OpenSTA / OpenROAD text timing reports produced by flow/sta/tl_report.tcl.

Only the stable, long-standing ``report_checks -format full|end``,
``report_worst_slack``, ``report_wns``, ``report_tns``, ``report_clock_skew``,
``report_check_types`` and ``report_power`` text formats are relied upon, so the
same parser works for OpenSTA 2.x (inside OpenROAD) and 3.x.
"""
from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from pathlib import Path

NUM = r"-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?"
_ROW = re.compile(rf"^(?P<nums>(?:\s*{NUM})*)\s+(?P<edge>[\^v])\s+(?P<pin>\S+)(?:\s+\((?P<cell>[^)]*)\))?\s*$")
_CLOCK_LAT = re.compile(rf"^\s*(?P<nums>(?:{NUM}\s+)*){NUM}\s+clock network delay \((?P<kind>\w+)\)")


@dataclass
class PathStage:
    pin: str
    cell: str
    edge: str
    is_output: bool
    fanout: int | None
    cap: float | None
    slew: float | None
    delay: float
    time: float
    net: str = ""


@dataclass
class TimingPath:
    group: str
    path_type: str
    startpoint: str
    startpoint_kind: str
    endpoint: str
    endpoint_kind: str
    slack: float | None = None
    arrival: float | None = None
    required: float | None = None
    launch_latency: float = 0.0
    capture_latency: float = 0.0
    crpr: float = 0.0
    uncertainty: float = 0.0
    lib_setup_hold: float = 0.0
    clock_kind: str = "ideal"
    stages: list[PathStage] = field(default_factory=list)

    @property
    def logic_depth(self) -> int:
        outs = [s for s in self.stages if s.is_output]
        return max(0, len(outs) - 1)

    @property
    def cell_delay(self) -> float:
        return sum(s.delay for s in self.stages if s.is_output)

    @property
    def wire_delay(self) -> float:
        return sum(s.delay for s in self.stages if not s.is_output)

    @property
    def data_delay(self) -> float:
        """Data-path delay from the launching clock pin/port to the endpoint."""
        if not self.stages:
            return 0.0
        return round(self.stages[-1].time - self.stages[0].time + self.stages[0].delay, 4)

    @property
    def skew(self) -> float:
        return round(self.capture_latency - self.launch_latency + self.crpr, 4)

    def to_dict(self) -> dict:
        d = asdict(self)
        d.update(logic_depth=self.logic_depth, cell_delay=round(self.cell_delay, 4),
                 wire_delay=round(self.wire_delay, 4), data_delay=self.data_delay, skew=self.skew)
        d["max_fanout"] = max((s.fanout or 0) for s in self.stages) if self.stages else 0
        d["cells"] = [s.cell for s in self.stages if s.is_output]
        d["nets"] = [s.net for s in self.stages if s.net]
        return d


def _nums(s: str) -> list[float]:
    return [float(x) for x in re.findall(NUM, s)]


def parse_paths(text: str) -> list[TimingPath]:
    blocks = re.split(r"(?m)^(?=Startpoint: )", text)
    out: list[TimingPath] = []
    for b in blocks:
        if not b.startswith("Startpoint:"):
            continue
        m_sp = re.search(r"^Startpoint: (\S+)(?: \((.*)\))?$", b, re.M)
        m_ep = re.search(r"^Endpoint: (\S+)(?: \((.*)\))?$", b, re.M)
        m_g = re.search(r"^Path Group: (\S+)", b, re.M)
        m_t = re.search(r"^Path Type: (\S+)", b, re.M)
        p = TimingPath(m_g.group(1) if m_g else "", m_t.group(1) if m_t else "",
                       m_sp.group(1) if m_sp else "", (m_sp.group(2) or "") if m_sp else "",
                       m_ep.group(1) if m_ep else "", (m_ep.group(2) or "") if m_ep else "")
        lines = b.splitlines()
        section = "pre"
        for line in lines:
            s = line.strip()
            if s.startswith("---") or not s:
                continue
            if "Description" in line and "Time" in line:
                section = "data"
                continue
            if section == "data":
                if s.endswith("data arrival time"):
                    p.arrival = _nums(s)[-1]
                    section = "req"
                    continue
                m = _CLOCK_LAT.match(line)
                if m:
                    p.launch_latency = _nums(line)[-2] if len(_nums(line)) >= 2 else 0.0
                    p.clock_kind = m.group("kind")
                    continue
                mn = re.match(r"^\s*(?:\d+\s+)?(?:[-\d.eE]+\s+)?(\S+) \(net\)\s*$", line)
                if mn:
                    if p.stages:
                        p.stages[-1].net = mn.group(1)
                    continue
                m = _ROW.match(line)
                if m and m.group("pin") not in ("clock",):
                    nums = _nums(m.group("nums"))
                    if len(nums) < 2:
                        continue
                    time, delay = nums[-1], nums[-2]
                    rest = nums[:-2]
                    slew = rest[-1] if len(rest) >= 1 else None
                    cap = rest[-2] if len(rest) >= 2 else None
                    fanout = int(rest[-3]) if len(rest) >= 3 else None
                    cell = m.group("cell") or ""
                    p.stages.append(PathStage(m.group("pin"), cell, m.group("edge"), fanout is not None,
                                              fanout, cap, slew, delay, time))
            elif section == "req":
                if "clock network delay" in s:
                    n = _nums(s)
                    p.capture_latency = n[-2] if len(n) >= 2 else 0.0
                elif "clock reconvergence pessimism" in s:
                    n = _nums(s)
                    p.crpr = n[-2] if len(n) >= 2 else 0.0
                elif "clock uncertainty" in s:
                    n = _nums(s)
                    p.uncertainty = abs(n[-2]) if len(n) >= 2 else 0.0
                elif "library setup time" in s or "library hold time" in s or "library recovery time" in s \
                        or "library removal time" in s:
                    n = _nums(s)
                    p.lib_setup_hold = n[-2] if len(n) >= 2 else 0.0
                elif s.endswith("data required time"):
                    p.required = _nums(s)[-1]
                elif "slack (" in s:
                    p.slack = _nums(s)[0]
                    break
        out.append(p)
    return out


def parse_end(text: str) -> dict[str, list[dict]]:
    """Parse ``-format end`` reports: {group: [{endpoint, cell, required, arrival, slack}]}."""
    groups: dict[str, list[dict]] = defaultdict(list)
    cur = None
    for line in text.splitlines():
        m = re.match(r"^(max_delay/setup|min_delay/hold|recovery|removal)\S* group (\S+)", line.strip())
        if m:
            cur = m.group(2)
            continue
        m = re.match(rf"^(\S+)(?: \(([^)]*)\))?\s+({NUM})\s+({NUM})\s+({NUM})", line.strip())
        if m and cur is not None:
            groups[cur].append({"endpoint": m.group(1), "cell": m.group(2) or "",
                                "required": float(m.group(3)), "arrival": float(m.group(4)),
                                "slack": float(m.group(5))})
    return dict(groups)


def parse_summary(text: str) -> dict:
    out = {}
    ws = re.findall(rf"worst slack(?: (max|min))?\s+({NUM})", text)
    if ws:
        out["worst_slack_max"] = float(ws[0][1])
        if len(ws) > 1:
            out["worst_slack_min"] = float(ws[1][1])
    m = re.search(rf"^wns(?: max)?\s+({NUM})", text, re.M)
    if m:
        out["wns"] = float(m.group(1))
    m = re.search(rf"^tns(?: max)?\s+({NUM})", text, re.M)
    if m:
        out["tns"] = float(m.group(1))
    return out


def parse_skew(text: str) -> dict:
    """report_clock_skew: OpenSTA 3.x prints "<v> setup skew" / "<v> hold skew";
    OpenSTA 2.x (OpenROAD) prints a "Latency CRPR Skew" table per check type."""
    out = {}
    m = re.findall(rf"({NUM})\s+setup skew", text)
    if m:
        out["setup_skew"] = float(m[-1])
    m = re.findall(rf"({NUM})\s+hold skew", text)
    if m:
        out["hold_skew"] = float(m[-1])
    if not out and "Skew" in text:
        vals = []
        lines = text.splitlines()
        for i, line in enumerate(lines):
            if re.match(r"^\s*Latency\s+CRPR\s+Skew", line):
                for l2 in lines[i + 1:i + 8]:
                    n = _nums(l2) if not re.search(r"[A-Za-z_]", l2) else []
                    if len(n) >= 3:
                        vals.append(n[-1])
                        break
        if vals:
            out["setup_skew"] = vals[0]
            if len(vals) > 1:
                out["hold_skew"] = vals[1]
    return out


def parse_drv(text: str) -> dict:
    out = {"max_slew": 0, "max_capacitance": 0, "max_fanout": 0}
    cur = None
    for line in text.splitlines():
        s = line.strip().lower()
        if s in ("max slew", "max capacitance", "max fanout"):
            cur = s.replace(" ", "_")
            continue
        if cur and "(violated)" in s:
            out[cur] += 1
    return out


def parse_power(text: str) -> dict:
    for line in text.splitlines():
        if line.strip().startswith("Total"):
            n = _nums(line)
            if len(n) >= 4:
                return {"internal_w": n[0], "switching_w": n[1], "leakage_w": n[2], "total_w": n[3],
                        "note": "vectorless default-activity estimate (OpenSTA report_power)"}
    return {}


def parse_stage(d: Path, period_ns: float) -> dict:
    """Summarise one stage directory written by tl_reports."""
    rd = lambda n: (d / n).read_text(errors="replace") if (d / n).exists() else ""
    paths_max = parse_paths(rd("paths_max.rpt"))
    paths_min = parse_paths(rd("paths_min.rpt"))
    viol_max = parse_end(rd("viol_max.rpt"))
    viol_min = parse_end(rd("viol_min.rpt"))
    summ = parse_summary(rd("summary.rpt"))
    groups = {}
    for g in sorted({p.group for p in paths_max} | set(viol_max)):
        gp = [p for p in paths_max if p.group == g]
        vl = viol_max.get(g, [])
        groups[g] = {
            "wns": min([p.slack for p in gp if p.slack is not None] or [0.0]),
            "tns": round(sum(v["slack"] for v in vl), 4),
            "violating_endpoints": len(vl),
            "paths_reported": len(gp),
        }
    hold_groups = {}
    for g in sorted({p.group for p in paths_min} | set(viol_min)):
        gp = [p for p in paths_min if p.group == g]
        vl = viol_min.get(g, [])
        hold_groups[g] = {
            "whs": min([p.slack for p in gp if p.slack is not None] or [0.0]),
            "ths": round(sum(v["slack"] for v in vl), 4),
            "violating_endpoints": len(vl),
        }
    unconstrained = len([l for l in rd("unconstrained.rpt").splitlines() if re.match(r"^\S+.*\(.*\)\s", l)])
    setup_wns = summ.get("wns", min([g["wns"] for g in groups.values()] or [0.0]))
    wns_r2r = groups.get("reg2reg", {}).get("wns")
    worst_r2r = next((p for p in paths_max if p.group == "reg2reg"), None)
    fmax = None
    if worst_r2r is not None and worst_r2r.slack is not None:
        # Minimum period at which the worst reg2reg path would just meet setup,
        # derived from this report: T_min = T - slack. Reported as a derived metric.
        tmin = period_ns - worst_r2r.slack
        fmax = round(1000.0 / tmin, 2) if tmin > 0 else None
    return {
        "dir": str(d),
        "summary": summ,
        "setup": {"wns": setup_wns, "tns": summ.get("tns"), "groups": groups},
        "hold": {"whs": summ.get("worst_slack_min"), "groups": hold_groups},
        "reg2reg_wns": wns_r2r,
        "reg2reg_fmax_mhz_derived": fmax,
        "skew": parse_skew(rd("skew.rpt")),
        "drv": parse_drv(rd("drv.rpt")),
        "power": parse_power(rd("power.rpt")),
        "unconstrained_endpoints_sample": unconstrained,
        "paths_max": [p.to_dict() for p in paths_max],
        "paths_min": [p.to_dict() for p in paths_min[:20]],
    }
