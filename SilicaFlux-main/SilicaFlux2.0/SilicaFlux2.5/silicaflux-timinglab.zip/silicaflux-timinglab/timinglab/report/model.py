"""Turn raw run records into report tables (summary, paths, comparisons, congestion).

Every value in these tables is copied from a tool report parsed by
timinglab.parsers, or is arithmetic on such values (labelled "derived").
"""
from __future__ import annotations

from ..config import load_designs

STAGE_ORDER = ("grt", "cts", "place", "synth")


def stage_data(rec: dict, stage: str) -> dict | None:
    if stage == "synth":
        return (rec.get("sta") or {}).get("timing")
    return (rec.get("pnr") or {}).get("stages", {}).get(stage)


def final_stage(rec: dict) -> tuple[str, dict | None]:
    for st in STAGE_ORDER:
        d = stage_data(rec, st)
        if d:
            return st, d
    return "none", None


def _r(x, n=3):
    return None if x is None else round(float(x), n)


def summary_rows(records: list[dict]) -> list[dict]:
    rows = []
    for rec in records:
        st, d = final_stage(rec)
        synth = rec.get("synth") or {}
        pnr = rec.get("pnr") or {}
        row = {
            "pdk": rec["pdk"], "design": rec["design"], "top": rec.get("top"), "group": rec.get("group"),
            "variant_of": rec.get("variant_of") or "", "period_ns": rec.get("period_ns"),
            "latency_cycles": rec.get("latency_cycles"),
            "cells": synth.get("cells"), "seq_cells": synth.get("seq_cells"),
            "synth_area_um2": _r(synth.get("area_um2"), 1),
            "placed_area_um2": (pnr.get("area", {}).get("grt") or {}).get("design_area_um2"),
            "final_stage": st,
        }
        for s in ("synth", "place", "cts", "grt"):
            sd = stage_data(rec, s)
            row[f"wns_{s}"] = _r(sd["setup"]["wns"]) if sd else None
            row[f"tns_{s}"] = _r(sd["setup"]["tns"], 2) if sd and sd["setup"]["tns"] is not None else None
            row[f"r2r_wns_{s}"] = _r(sd.get("reg2reg_wns")) if sd else None
            row[f"r2r_fmax_{s}"] = sd.get("reg2reg_fmax_mhz_derived") if sd else None
        if d:
            row["whs"] = _r(d["hold"].get("whs"))
            row["setup_skew"] = d.get("skew", {}).get("setup_skew")
            row["hold_skew"] = d.get("skew", {}).get("hold_skew")
            drv = d.get("drv", {})
            row["drv_violations"] = sum(drv.values()) if drv else None
            row["power_mw"] = _r((d.get("power") or {}).get("total_w", 0) * 1e3, 3) if d.get("power") else None
            worst = next((p for p in d["paths_max"] if p["group"] == "reg2reg"), d["paths_max"][0] if d["paths_max"] else None)
            if worst:
                row["worst_r2r_logic_depth"] = worst["logic_depth"]
                row["worst_r2r_data_delay_ns"] = worst["data_delay"]
        rt = pnr.get("routing") or {}
        row["wirelength_um"] = rt.get("wirelength_um")
        row["grt_overflow"] = rt.get("total_overflow")
        row["grt_usage_pct"] = rt.get("total_usage_pct")
        cc = (pnr.get("congestion") or {}).get("critical_path_correlation") or {}
        row["r2r_path_nets_in_congestion_pct"] = round(100 * cc["fraction"], 1) if cc.get("fraction") is not None else None
        if row["r2r_fmax_" + st] if st != "none" else None:
            tmin = 1000.0 / row["r2r_fmax_" + st]
            row["min_period_ns_derived"] = round(tmin, 3)
            if rec.get("latency_cycles"):
                row["op_latency_ns_derived"] = round(tmin * rec["latency_cycles"], 2)
        rows.append(row)
    return rows


def _ffmap(rec: dict) -> dict:
    import json
    from pathlib import Path
    p = Path(rec.get("rundir", "")) / "ff_src_map.json"
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}


def _rtl(ffmap: dict, name: str, kind: str) -> str:
    inst = name.rsplit("/", 1)[0] if "/" in name else name
    if inst in ffmap:
        return ffmap[inst]
    if "port" in kind:
        return f"port {name}"
    return ""


def path_rows(records: list[dict], top_n: int = 10) -> list[dict]:
    out = []
    for rec in records:
        st, d = final_stage(rec)
        if not d:
            continue
        ffmap = _ffmap(rec)
        key = lambda p: (p["slack"] if p["slack"] is not None else 1e9)
        r2r = sorted([p for p in d["paths_max"] if p["group"] == "reg2reg"], key=key)[:top_n]
        io = sorted([p for p in d["paths_max"] if p["group"] != "reg2reg"], key=key)[:2]
        for rank, p in enumerate(sorted(r2r + io, key=key), 1):
            out.append({
                "pdk": rec["pdk"], "design": rec["design"], "stage": st, "rank": rank,
                "group": p["group"], "slack_ns": p["slack"],
                "startpoint_rtl": _rtl(ffmap, p["startpoint"], p["startpoint_kind"]),
                "endpoint_rtl": _rtl(ffmap, p["endpoint"], p["endpoint_kind"]),
                "startpoint": p["startpoint"],
                "startpoint_kind": p["startpoint_kind"], "endpoint": p["endpoint"],
                "endpoint_kind": p["endpoint_kind"], "logic_depth": p["logic_depth"],
                "data_delay_ns": p["data_delay"], "cell_delay_ns": p["cell_delay"],
                "wire_delay_ns": p["wire_delay"], "skew_ns": p["skew"], "max_fanout": p["max_fanout"],
                "clock": p["clock_kind"], "congested_nets_on_path": p.get("congested_nets_on_path"),
            })
    return out


def comparison_rows(summary: list[dict]) -> list[dict]:
    designs = load_designs()
    idx = {(r["pdk"], r["design"]): r for r in summary}
    out = []
    for r in summary:
        base_name = r.get("variant_of")
        if not base_name:
            continue
        b = idx.get((r["pdk"], base_name))
        if not b:
            continue
        st = next((s for s in ("grt", "cts", "place", "synth") if r.get(f"r2r_fmax_{s}") and b.get(f"r2r_fmax_{s}")), None)
        if not st:
            continue
        fb, fa = b[f"r2r_fmax_{st}"], r[f"r2r_fmax_{st}"]
        row = {
            "pdk": r["pdk"], "before": base_name, "after": r["design"], "stage": st,
            "period_ns": r["period_ns"],
            "r2r_wns_before": b.get(f"r2r_wns_{st}"), "r2r_wns_after": r.get(f"r2r_wns_{st}"),
            "fmax_before_mhz": fb, "fmax_after_mhz": fa,
            "fmax_gain_pct": round(100.0 * (fa - fb) / fb, 1),
            "wns_before": b.get(f"wns_{st}"), "wns_after": r.get(f"wns_{st}"),
            "tns_before": b.get(f"tns_{st}"), "tns_after": r.get(f"tns_{st}"),
            "area_before_um2": b.get("synth_area_um2"), "area_after_um2": r.get("synth_area_um2"),
            "area_delta_pct": round(100.0 * (r["synth_area_um2"] - b["synth_area_um2"]) / b["synth_area_um2"], 1)
            if r.get("synth_area_um2") and b.get("synth_area_um2") else None,
            "cells_before": b.get("cells"), "cells_after": r.get("cells"),
            "seq_before": b.get("seq_cells"), "seq_after": r.get("seq_cells"),
            "power_before_mw": b.get("power_mw"), "power_after_mw": r.get("power_mw"),
            "latency_before": b.get("latency_cycles"), "latency_after": r.get("latency_cycles"),
            "depth_before": b.get("worst_r2r_logic_depth"), "depth_after": r.get("worst_r2r_logic_depth"),
            "op_time_before_ns": b.get("op_latency_ns_derived"), "op_time_after_ns": r.get("op_latency_ns_derived"),
        }
        out.append(row)
    return out
