"""TimingLab dashboard: self-contained HTML + CSV + JSON exports.

The HTML is a single file (inline CSS/JS/SVG) so it can be archived with a run.
Chart colours (dark surface #0B0D10): upstream #A88A3A, TimingLab #00A3C4 —
validated with the dataviz palette validator (lightness band, chroma, CVD and
contrast checks all pass); brand gold/cyan are used for text accents only.
"""
from __future__ import annotations

import csv
import html
import json
import time
from pathlib import Path

from ..flow.runner import collect_results
from .model import summary_rows, path_rows, comparison_rows

C_BEFORE = "#A88A3A"
C_AFTER = "#00A3C4"


def _csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("")
        return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys:
                keys.append(k)
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow({k: ("" if r.get(k) is None else r.get(k)) for k in keys})


def _fmt(v, nd=3):
    if v is None or v == "":
        return "—"
    if isinstance(v, float):
        return f"{v:.{nd}f}".rstrip("0").rstrip(".") if abs(v) < 1e6 else f"{v:.3g}"
    return html.escape(str(v))


def _table(rows: list[dict], cols: list[tuple[str, str]], tid: str, slack_cols=()) -> str:
    head = "".join(f'<th data-k="{i}">{html.escape(lbl)}</th>' for i, (_, lbl) in enumerate(cols))
    body = []
    for r in rows:
        tds = []
        for k, _ in cols:
            v = r.get(k)
            cls = ""
            if k in slack_cols and isinstance(v, (int, float)):
                cls = ' class="neg"' if v < 0 else ' class="pos"'
            sort = f' data-v="{v}"' if isinstance(v, (int, float)) else ""
            tds.append(f"<td{cls}{sort}>{_fmt(v)}</td>")
        body.append("<tr>" + "".join(tds) + "</tr>")
    return (f'<div class="tw"><table id="{tid}" class="sortable"><thead><tr>{head}</tr></thead>'
            f'<tbody>{"".join(body)}</tbody></table></div>')


def _fmax_chart(comps: list[dict]) -> str:
    """Grouped horizontal bars: derived reg2reg Fmax before/after per (pdk, block)."""
    if not comps:
        return '<p class="muted">No before/after pairs in these runs.</p>'
    rows = comps
    raw = max(max(c["fmax_before_mhz"], c["fmax_after_mhz"]) for c in rows) * 1.08
    step = next(st for st in (5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000) if raw / st <= 6)
    nt = int(-(-raw // step))
    vmax = nt * step
    label_w, bar_w, row_h, bh = 230, 520, 46, 14
    h = 30 + row_h * len(rows)
    out = [f'<svg viewBox="0 0 {label_w + bar_w + 120} {h}" role="img" '
           f'aria-label="Derived reg2reg Fmax before and after" class="chart">']
    # gridlines
    for i in range(0, nt + 1):
        x = label_w + bar_w * i / nt
        val = step * i
        out.append(f'<line x1="{x:.1f}" y1="18" x2="{x:.1f}" y2="{h - 6}" class="grid"/>')
        out.append(f'<text x="{x:.1f}" y="12" class="axis" text-anchor="middle">{val:.0f}</text>')
    for i, c in enumerate(rows):
        y = 26 + i * row_h
        lbl = f'{c["after"]} vs {c["before"]}'
        out.append(f'<text x="{label_w - 10}" y="{y + 12}" class="lbl" text-anchor="end">{html.escape(c["pdk"])}</text>')
        out.append(f'<text x="{label_w - 10}" y="{y + 27}" class="lbl2" text-anchor="end">{html.escape(c["before"])}</text>')
        for j, (key, col, name) in enumerate((("fmax_before_mhz", C_BEFORE, "upstream"),
                                              ("fmax_after_mhz", C_AFTER, "TimingLab"))):
            v = c[key]
            w = max(2.0, bar_w * v / vmax)
            yy = y + j * (bh + 2)
            tip = f'{c["pdk"]} · {c["before" if j == 0 else "after"]} ({name}): {v:.1f} MHz at {c["stage"]}'
            out.append(f'<rect x="{label_w}" y="{yy}" width="{w:.1f}" height="{bh}" rx="4" fill="{col}" '
                       f'class="bar" data-tip="{html.escape(tip)}"><title>{html.escape(tip)}</title></rect>')
            out.append(f'<text x="{label_w + w + 6:.1f}" y="{yy + 11}" class="val">{v:.1f}</text>')
        out.append(f'<text x="{label_w + bar_w + 112}" y="{y + 20}" class="gain" text-anchor="end">'
                   f'{c["fmax_gain_pct"]:+.1f}%</text>')
    out.append("</svg>")
    legend = (f'<div class="legend"><span><i style="background:{C_BEFORE}"></i>upstream RTL</span>'
              f'<span><i style="background:{C_AFTER}"></i>TimingLab alternative</span>'
              f'<span class="muted">derived Fmax = 1 / (T − worst reg2reg slack), from OpenSTA/OpenROAD reports</span></div>')
    return legend + "".join(out)


CSS = """
:root{--bg:#0B0D10;--panel:#12151A;--line:#232832;--ink:#E8E6E1;--ink2:#A9ADB5;--muted:#6E7480;
--gold:#C9A84C;--cyan:#00E5FF;--neg:#FF6B6B;--pos:#7BD88F}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);
font:14px/1.5 "DM Mono",ui-monospace,SFMono-Regular,Menlo,monospace}
header{padding:28px 24px 8px;border-bottom:1px solid var(--line)}
h1{font-family:"Bebas Neue",Impact,sans-serif;letter-spacing:.06em;font-weight:400;font-size:44px;margin:0;color:var(--gold)}
h2{font-family:"Bebas Neue",Impact,sans-serif;letter-spacing:.05em;font-weight:400;font-size:28px;margin:28px 0 8px;color:var(--cyan)}
main{padding:0 24px 48px;max-width:1500px}
.sub{color:var(--ink2)}.muted{color:var(--muted)}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin:18px 0}
.kpi{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:14px}
.kpi b{display:block;font-family:"Bebas Neue",Impact,sans-serif;font-size:34px;font-weight:400;color:var(--ink)}
.kpi span{color:var(--ink2);font-size:12px}
.tw{overflow-x:auto;border:1px solid var(--line);border-radius:8px}
table{border-collapse:collapse;width:100%;font-size:12px}
th,td{padding:6px 10px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}
th{position:sticky;top:0;background:var(--panel);color:var(--ink2);cursor:pointer;font-weight:500}
td:first-child,th:first-child,td:nth-child(2),th:nth-child(2){text-align:left}
tr:hover td{background:#171B21}
td.neg{color:var(--neg)}td.pos{color:var(--pos)}
.chart{width:100%;max-width:900px;height:auto}
.chart .grid{stroke:var(--line);stroke-width:1}.chart .axis{fill:var(--muted);font-size:10px}
.chart .lbl{fill:var(--ink);font-size:12px}.chart .lbl2{fill:var(--ink2);font-size:11px}
.chart .val{fill:var(--ink2);font-size:11px}.chart .gain{fill:var(--ink);font-size:13px}
.chart .bar:hover{opacity:.8}
.legend{display:flex;gap:18px;flex-wrap:wrap;margin:6px 0 10px;color:var(--ink2);font-size:12px}
.legend i{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:6px;vertical-align:-1px}
.note{background:var(--panel);border-left:3px solid var(--gold);padding:10px 14px;border-radius:4px;color:var(--ink2)}
#tip{position:fixed;pointer-events:none;background:#1C2128;border:1px solid var(--line);padding:6px 8px;
border-radius:6px;font-size:12px;display:none;color:var(--ink)}
a{color:var(--cyan)}
@media (max-width:700px){main,header{padding-left:16px;padding-right:16px}h1{font-size:34px}}
"""

JS = """
document.querySelectorAll('table.sortable th').forEach(th=>th.addEventListener('click',()=>{
 const t=th.closest('table'),i=+th.dataset.k,b=t.tBodies[0],rows=[...b.rows];
 const dir=th.dataset.dir==='a'?'d':'a';th.dataset.dir=dir;
 rows.sort((r1,r2)=>{const a=r1.cells[i],c=r2.cells[i];
  const x=a.dataset.v!==undefined?+a.dataset.v:a.textContent,y=c.dataset.v!==undefined?+c.dataset.v:c.textContent;
  return (x>y?1:x<y?-1:0)*(dir==='a'?1:-1)});rows.forEach(r=>b.appendChild(r));}));
const tip=document.getElementById('tip');
document.querySelectorAll('[data-tip]').forEach(el=>{
 el.addEventListener('mousemove',e=>{tip.style.display='block';tip.textContent=el.dataset.tip;
  tip.style.left=(e.clientX+12)+'px';tip.style.top=(e.clientY+12)+'px'});
 el.addEventListener('mouseleave',()=>tip.style.display='none');});
"""


def build_dashboard(runs: Path, out: Path, audit_dir: Path | None = None, extra_json: list[Path] | None = None,
                    title: str = "SilicaFlux TimingLab") -> Path:
    out.mkdir(parents=True, exist_ok=True)
    records = [r for r in collect_results(runs) if r.get("status") == "ok"]
    summ = summary_rows(records)
    paths = path_rows(records, top_n=5)
    comps = comparison_rows(summ)
    confirmations = []
    calib = []
    if audit_dir and audit_dir.exists():
        for p in sorted(audit_dir.rglob("confirmed_*.json")):
            confirmations.append(json.loads(p.read_text()))
        calib = calibration_rows(summ, audit_dir)
    _csv(out / "audit_calibration.csv", calib)
    _csv(out / "summary.csv", summ)
    _csv(out / "critical_paths.csv", paths)
    _csv(out / "comparisons.csv", comps)
    tools = {}
    for r in records:
        tools.setdefault("yosys", (r.get("synth") or {}).get("yosys"))
        tools.setdefault("opensta", (r.get("sta") or {}).get("opensta"))
        tools.setdefault("openroad", (r.get("pnr") or {}).get("openroad"))
    blob = {"schema": "silicaflux-timinglab/dashboard/v1", "generated": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "tools": tools, "summary": summ, "critical_paths": paths, "comparisons": comps,
            "audit_confirmation": confirmations, "audit_calibration": calib,
            "audit_calibration_spearman": {p_: spearman([(c["est_depth_ugd"], c["min_period_ns"]) for c in calib
                                                         if c["pdk"] == p_]) for p_ in sorted({c["pdk"] for c in calib})},
            "notes": [
                "Measured values come from OpenSTA (synth stage) and OpenROAD (place/cts/grt stages) reports.",
                "fmax/min_period/op_latency are derived arithmetically from measured worst reg2reg slack.",
                "Synth-stage numbers use unbuffered nets and ideal wires; place/cts/grt are buffered with estimated RC.",
            ]}
    (out / "timinglab_results.json").write_text(json.dumps(blob, indent=2, default=str) + "\n")

    pdks = sorted({r["pdk"] for r in summ})
    best = max(comps, key=lambda c: c["fmax_gain_pct"]) if comps else None
    kpis = [
        (str(len(summ)), "design × PDK runs"),
        (str(len(pdks)), "PDKs: " + (", ".join(pdks) or "—")),
        (f'{best["fmax_gain_pct"]:+.1f}%' if best else "—",
         f'best reg2reg Fmax change ({best["after"]}, {best["pdk"]})' if best else "best Fmax change"),
        (str(sum(1 for c in comps if c["fmax_gain_pct"] > 0)) + f"/{len(comps)}", "alternatives faster than upstream"),
    ]
    kpi_html = "".join(f'<div class="kpi"><b>{html.escape(v)}</b><span>{html.escape(l)}</span></div>' for v, l in kpis)

    sum_cols = [("design", "design"), ("pdk", "pdk"), ("period_ns", "T [ns]"), ("cells", "cells"),
                ("synth_area_um2", "area [µm²]"), ("wns_synth", "WNS synth"), ("wns_place", "WNS place"),
                ("wns_cts", "WNS cts"), ("wns_grt", "WNS grt"), ("tns_grt", "TNS grt"),
                ("r2r_wns_grt", "r2r WNS grt"), ("r2r_fmax_grt", "r2r Fmax* [MHz]"), ("whs", "WHS"),
                ("setup_skew", "skew [ns]"), ("worst_r2r_logic_depth", "depth"),
                ("worst_r2r_data_delay_ns", "path delay [ns]"), ("drv_violations", "DRV"),
                ("power_mw", "power [mW]†"), ("grt_overflow", "GRT ovfl"),
                ("r2r_path_nets_in_congestion_pct", "r2r nets congested %"), ("latency_cycles", "latency [cyc]")]
    path_cols = [("design", "design"), ("pdk", "pdk"), ("stage", "stage"), ("rank", "#"), ("group", "group"),
                 ("slack_ns", "slack [ns]"), ("startpoint_rtl", "start (RTL)"), ("endpoint_rtl", "end (RTL)"),
                 ("logic_depth", "depth"), ("data_delay_ns", "delay [ns]"), ("cell_delay_ns", "cell"),
                 ("wire_delay_ns", "wire"), ("skew_ns", "skew"), ("max_fanout", "max fo"),
                 ("congested_nets_on_path", "congested nets")]
    comp_cols = [("after", "alternative"), ("pdk", "pdk"), ("before", "upstream"), ("stage", "stage"),
                 ("r2r_wns_before", "r2r WNS before"), ("r2r_wns_after", "after"),
                 ("fmax_before_mhz", "Fmax* before"), ("fmax_after_mhz", "after"), ("fmax_gain_pct", "Δ%"),
                 ("tns_before", "TNS before"), ("tns_after", "after"),
                 ("area_before_um2", "area before"), ("area_after_um2", "after"), ("area_delta_pct", "Δarea %"),
                 ("depth_before", "depth before"), ("depth_after", "after"),
                 ("latency_before", "latency before"), ("latency_after", "after"),
                 ("op_time_before_ns", "op time* before [ns]"), ("op_time_after_ns", "after")]
    cal_html = ""
    if calib:
        rho = blob["audit_calibration_spearman"]
        cal_html = ("<h2>RTL estimate vs. measured timing</h2><p class=\"sub\">Spearman rank correlation between the "
                    "audit's worst estimated depth (unit-gate delays, technology independent) and the measured minimum "
                    "reg2reg period per PDK: " + ", ".join(f"{k}: ρ = {v:.2f}" for k, v in rho.items() if v is not None)
                    + "</p>" + _table(calib, [("design", "design"), ("pdk", "pdk"), ("est_depth_ugd", "audit depth [UGD]"),
                                              ("min_period_ns", "STA min period* [ns]"), ("stage", "stage")], "cal"))
    conf_html = ""
    if confirmations:
        rows = []
        for c in confirmations:
            for f in c.get("findings", []):
                if f.get("status") in ("confirmed", "refuted", "partially-confirmed"):
                    rows.append({"design": c.get("design"), "pdk": c.get("pdk"), "id": f["id"],
                                 "status": f["status"], "title": f["title"][:110],
                                 "evidence": (f.get("sta_evidence") or "")[:120]})
        conf_html = "<h2>RTL hypotheses vs. STA evidence</h2>" + _table(
            rows, [("id", "finding"), ("design", "design"), ("pdk", "pdk"), ("status", "status"),
                   ("title", "hypothesis"), ("evidence", "STA evidence")], "conf")
    body = f"""
<header><h1>{html.escape(title)}</h1>
<div class="sub">Static timing &amp; RTL optimisation dashboard · generated {blob['generated']} ·
yosys: {html.escape(str(tools.get('yosys') or '—'))[:60]} · OpenSTA: {html.escape(str(tools.get('opensta') or '—'))} ·
OpenROAD: {html.escape(str(tools.get('openroad') or '—'))}</div></header>
<main>
<div class="kpis">{kpi_html}</div>
<div class="note">Every timing number below is read from an OpenSTA or OpenROAD report in the run directory.
Columns marked * are derived arithmetically (Fmax = 1/(T − worst reg2reg slack); op time = latency × min period).
† power is OpenSTA's vectorless default-activity estimate. Synth-stage WNS uses unbuffered nets and ideal wires;
place/cts/grt stages are buffered (repair_design) with placement / global-route RC estimates.</div>
<h2>Before / after — reg2reg Fmax</h2>
{_fmax_chart(comps)}
{_table(comps, comp_cols, "comp", slack_cols=("r2r_wns_before", "r2r_wns_after"))}
<h2>Run summary</h2>
{_table(summ, sum_cols, "summ", slack_cols=("wns_synth", "wns_place", "wns_cts", "wns_grt", "r2r_wns_grt", "tns_grt", "whs"))}
<h2>Critical-path ranking (final stage: worst 5 reg2reg + worst 2 I/O paths per run)</h2>
{_table(paths, path_cols, "paths", slack_cols=("slack_ns",))}
{cal_html}
{conf_html}
<h2>Exports</h2>
<p><a href="summary.csv">summary.csv</a> · <a href="critical_paths.csv">critical_paths.csv</a> ·
<a href="comparisons.csv">comparisons.csv</a> · <a href="audit_calibration.csv">audit_calibration.csv</a> ·
<a href="timinglab_results.json">timinglab_results.json</a></p>
</main><div id="tip"></div>"""
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>SilicaFlux TimingLab</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>{CSS}</style></head><body>{body}<script>{JS}</script></body></html>"""
    (out / "dashboard.html").write_text(page)
    return out / "dashboard.html"


def calibration_rows(summ: list[dict], audit_dir: Path) -> list[dict]:
    """Pair each run's measured min reg2reg period with the audit's estimate."""
    rows = []
    for r in summ:
        a = audit_dir / r["design"] / "rtl_audit.json"
        if not a.exists() or not r.get("min_period_ns_derived"):
            continue
        est = json.loads(a.read_text())["summary"]["worst_est_depth_ugd"]
        rows.append({"design": r["design"], "pdk": r["pdk"], "est_depth_ugd": est,
                     "min_period_ns": r["min_period_ns_derived"], "stage": r["final_stage"]})
    return rows


def spearman(pairs: list[tuple[float, float]]) -> float | None:
    if len(pairs) < 3:
        return None

    def ranks(v):
        order = sorted(range(len(v)), key=lambda i: v[i])
        r = [0.0] * len(v)
        i = 0
        while i < len(order):
            j = i
            while j + 1 < len(order) and v[order[j + 1]] == v[order[i]]:
                j += 1
            for k in range(i, j + 1):
                r[order[k]] = (i + j) / 2.0
            i = j + 1
        return r
    x, y = ranks([p[0] for p in pairs]), ranks([p[1] for p in pairs])
    n = len(pairs)
    mx, my = sum(x) / n, sum(y) / n
    cov = sum((a - mx) * (b - my) for a, b in zip(x, y))
    vx = sum((a - mx) ** 2 for a in x) ** 0.5
    vy = sum((b - my) ** 2 for b in y) ** 0.5
    return round(cov / (vx * vy), 3) if vx and vy else None
