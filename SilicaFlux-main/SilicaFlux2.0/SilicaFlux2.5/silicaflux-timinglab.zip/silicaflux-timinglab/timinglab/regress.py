"""Regression helpers shared by the Makefile, CI and pytest.

    python -m timinglab.regress equiv   [--ntrans N --ncyc N --seed S]
    python -m timinglab.regress bugs
    python -m timinglab.regress formal  [--negative]
    python -m timinglab.regress confirm --runs runs --audit reports/audit
    python -m timinglab.regress upstream-sim
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

from .config import ROOT, Tools

U = ROOT / "upstream" / "silicaflux" / "rtl"
BUILD = ROOT / "build" / "sim"
OPT = [ROOT / "rtl" / "opt" / f for f in ("sf_mul_lo_pipe.sv", "sf_reduce_tree.sv",
                                          "sf_tensor_unit_pipe.sv", "sf_vector_engine_pipe.sv")]
V1_ORDER = ["silicaflux_pkg.sv", "fetch_unit.sv", "decoder.sv", "register_bank.sv", "vector_engine.sv",
            "tensor_unit.sv", "memory_controller.sv", "control_core.sv", "scheduler.sv", "compute_tile.sv",
            "noc_router.sv", "noc_interconnect.sv", "tile_interface.sv", "silicaflux_top.sv"]
VFLAGS = ["--binary", "--timing", "--timescale", "1ns/1ps", "-j", "2", "-Wno-fatal", "-Wno-lint", "-Wno-style",
          "-Wno-MULTIDRIVEN", "-Wno-SELRANGE", "-Wno-WIDTHTRUNC", "-Wno-WIDTHEXPAND"]


def _verilator() -> str:
    v = shutil.which("verilator")
    if not v:
        raise RuntimeError("verilator not found")
    return v


def build_verilator(name: str, top: str, sources: list[Path], params: dict | None = None) -> Path:
    mdir = BUILD / name
    exe = mdir / name
    srcs = [str(s) for s in sources]
    cmd = [_verilator(), *VFLAGS, *(f"-G{k}={v}" for k, v in (params or {}).items()),
           "--top-module", top, f"-I{U}", "-Mdir", str(mdir), "-o", name, *srcs]
    newest = max(Path(s).stat().st_mtime for s in srcs)
    if exe.exists() and exe.stat().st_mtime > newest:
        return exe
    mdir.mkdir(parents=True, exist_ok=True)
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0 or not exe.exists():
        raise RuntimeError(f"verilator build of {name} failed:\n{(p.stdout + p.stderr)[-3000:]}")
    return exe


def _run(exe: Path, *args: str, timeout: int = 1800) -> str:
    p = subprocess.run([str(exe), *args], capture_output=True, text=True, timeout=timeout)
    return p.stdout + p.stderr


# ---------------------------------------------------------------------------
def equiv(ntrans: int = 2000, ncyc: int = 50000, seed: int = 1, lanes=(4, 8, 16)) -> dict:
    res = {}
    exe = build_verilator("eq_tensor", "tb_eq_tensor",
                          [U / "silicaflux_pkg.sv", U / "tensor_unit.sv", *OPT, ROOT / "tb/equiv/tb_eq_tensor.sv"])
    out = _run(exe, f"+NTRANS={ntrans}", f"+SEED={seed}")
    res["tensor"] = {"pass": "[PASS]" in out and "[FAIL]" not in out, "log": _last(out)}
    for l in lanes:
        exe = build_verilator(f"eq_vec{l}", "tb_eq_vector",
                              [U / "silicaflux_pkg.sv", U / "vector_engine.sv", *OPT, ROOT / "tb/equiv/tb_eq_vector.sv"],
                              {"LANES": l})
        out = _run(exe, f"+NCYC={ncyc}", f"+SEED={seed}")
        m = re.search(r"upstream-vs-model deviations (\d+)", out)
        res[f"vector_l{l}"] = {"pass": "[PASS]" in out and "[FAIL]" not in out, "log": _last(out),
                               "upstream_deviations": int(m.group(1)) if m else None}
    tile_src = [U / "silicaflux_pkg.sv", U / "vector_engine.sv", U / "tensor_unit.sv", U / "memory_controller.sv",
                U / "compute_tile.sv", *OPT, ROOT / "rtl/opt/sf_compute_tile_pipe.sv", ROOT / "tb/equiv/tb_eq_tile.sv"]
    exe = build_verilator("eq_tile", "tb_eq_tile", tile_src)
    out = _run(exe, f"+NTOK={max(200, ntrans)}", f"+SEED={seed}")
    res["tile"] = {"pass": "[PASS]" in out and "[FAIL]" not in out, "log": _last(out)}
    return res


def _last(out: str) -> str:
    lines = [l for l in out.splitlines() if "[PASS]" in l or "[FAIL]" in l or "[FINDING]" in l or l.startswith("INFO")]
    return "\n".join(lines[-6:])


# ---------------------------------------------------------------------------
def bugs() -> dict:
    v1 = [U / f for f in V1_ORDER]
    res = {}
    exe = build_verilator("bug_load_use", "tb_bug_load_use", [*v1, ROOT / "tb/bugs/tb_bug_load_use.sv"])
    dep, nodep = _run(exe), _run(exe, "+NODEP")
    res["F-PIPE-1 load-use deadlock"] = {
        "reproduced": "[FINDING]" in dep and "[PASS]" in nodep,
        "with_dependency": _last(dep), "control_without_dependency": _last(nodep)}
    exe = build_verilator("bug_store", "tb_bug_store_data", [*v1, ROOT / "tb/bugs/tb_bug_store_data.sv"])
    out = _run(exe)
    res["F-ISA-1 STORE data register not encodable (stores r0)"] = {"reproduced": "[FINDING]" in out,
                                                                    "log": _last(out)}
    exe = build_verilator("bug_noc_dup", "tb_bug_noc_dup",
                          [U / "silicaflux_pkg.sv", U / "noc_router.sv", ROOT / "tb/bugs/tb_bug_noc_dup.sv"])
    out = _run(exe)
    res["F-NOC-1 duplicate flit delivery"] = {"reproduced": "[FINDING]" in out, "log": _last(out)}
    exe = build_verilator("eq_vec16", "tb_eq_vector",
                          [U / "silicaflux_pkg.sv", U / "vector_engine.sv", *OPT, ROOT / "tb/equiv/tb_eq_vector.sv"],
                          {"LANES": 16})
    out = _run(exe, "+NCYC=20000")
    m = re.search(r"upstream-vs-model deviations (\d+)", out)
    res["F-VEC-1 LANES=16 reduction drops lanes 8..15"] = {
        "reproduced": bool(m and int(m.group(1)) > 0), "log": _last(out)}
    exe = build_verilator("bug_tif_rx", "tb_bug_tif_rx",
                          [U / "silicaflux_pkg.sv", U / "tile_interface.sv", ROOT / "tb/bugs/tb_bug_tif_rx.sv"])
    out = _run(exe)
    res["F-TIF-1 RX flit is one flit stale and 5-bit misaligned"] = {"reproduced": "[FINDING]" in out, "log": _last(out)}
    return res


# ---------------------------------------------------------------------------
def formal(negative: bool = False, timeout: int = 3600) -> dict:
    t = Tools.discover()
    t.require("yosys")
    ys = ROOT / "formal" / "tensor_unit_mcp.ys"
    script = ys.read_text()
    log = ROOT / "build" / ("formal_mcp_negative.log" if negative else "formal_mcp.log")
    log.parent.mkdir(parents=True, exist_ok=True)
    if negative:
        # Vacuity check: a deliberately false variant of P1 must produce a counterexample.
        script = script.replace("read_slang --threads 1", "read_slang --threads 1 -DTL_NEGATIVE")
        script = re.sub(r"sat -tempinduct.*", "sat -seq 3 -prove-asserts -set-init-undef -set-def-inputs "
                                              "-set-at 1 rst_n 0 -show-ports", script)
    tmp = ROOT / "build" / ("mcp_neg.ys" if negative else "mcp.ys")
    tmp.write_text(script)
    p = subprocess.run([t.yosys, "-q", "-l", str(log), "-s", str(tmp)], capture_output=True, text=True,
                       timeout=timeout, cwd=ROOT)
    txt = log.read_text(errors="replace") if log.exists() else p.stdout + p.stderr
    if negative:
        ok = "SAT proof finished - model found: FAIL!" in txt or "failed" in txt.lower()
        return {"negative_check_found_counterexample": ok, "log": str(log.relative_to(ROOT))}
    return {"proven": "Induction step proven: SUCCESS!" in txt, "returncode": p.returncode,
            "log": str(log.relative_to(ROOT))}


# ---------------------------------------------------------------------------
def confirm_all(runs: Path, audit_dir: Path) -> list[dict]:
    from .confirm import confirm
    out = []
    for res_path in sorted(runs.rglob("result.json")):
        run = json.loads(res_path.read_text())
        a = audit_dir / run["design"] / "rtl_audit.json"
        if not a.exists():
            continue
        c = confirm(json.loads(a.read_text()), run)
        dst = audit_dir / run["design"] / f"confirmed_{run['pdk']}.json"
        dst.write_text(json.dumps(c, indent=2) + "\n")
        st = [f for f in c["findings"] if f["category"] in ("critical_path", "arithmetic_chain")]
        out.append({"design": run["design"], "pdk": run["pdk"],
                    "statuses": {f["id"]: f["status"] for f in st}, "missed": len(c["missed_by_audit"])})
    return out


def upstream_sim() -> dict:
    p = subprocess.run(["bash", "run_sim.sh"], cwd=ROOT / "upstream" / "silicaflux" / "sim",
                       capture_output=True, text=True, timeout=1800)
    txt = re.sub(r"\x1b\[[0-9;]*m", "", p.stdout + p.stderr)
    passed = re.findall(r"✔ (tb_\w+)", txt)
    failed = re.findall(r"✘ (tb_\w+)", txt)
    return {"passed": passed, "failed": failed, "ok": not failed and bool(passed)}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="timinglab.regress")
    ap.add_argument("what", choices=["equiv", "bugs", "formal", "confirm", "upstream-sim"])
    ap.add_argument("--ntrans", type=int, default=2000)
    ap.add_argument("--ncyc", type=int, default=50000)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--negative", action="store_true")
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--audit", default="reports/audit")
    ap.add_argument("--json")
    a = ap.parse_args(argv)
    if a.what == "equiv":
        r = equiv(a.ntrans, a.ncyc, a.seed)
        ok = all(v["pass"] for v in r.values())
    elif a.what == "bugs":
        r = bugs()
        ok = True   # findings are expected to reproduce; report them
    elif a.what == "formal":
        r = formal(a.negative)
        ok = r.get("proven", r.get("negative_check_found_counterexample", False))
    elif a.what == "confirm":
        r = confirm_all(Path(a.runs), Path(a.audit))
        ok = True
    else:
        r = upstream_sim()
        ok = r["ok"]
    print(json.dumps(r, indent=2))
    if a.json:
        Path(a.json).write_text(json.dumps(r, indent=2) + "\n")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
