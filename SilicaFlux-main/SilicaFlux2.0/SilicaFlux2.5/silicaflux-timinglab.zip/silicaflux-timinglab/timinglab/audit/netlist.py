"""Bit-level graph over a flattened Yosys word-level JSON netlist.

The graph is used by :mod:`timinglab.audit.rtl_audit` for longest-path estimation,
physical-fanout estimation, combinational-loop detection and clock/reset-domain
analysis. Only the Yosys JSON schema (``write_json``) is relied upon.
"""
from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field

from . import delay_model as dm

# --- Sequential cell port roles -------------------------------------------------
SEQ_TYPES = {
    "$dff", "$dffe", "$adff", "$adffe", "$sdff", "$sdffe", "$sdffce", "$aldff", "$aldffe",
    "$dffsr", "$dffsre", "$dlatch", "$adlatch", "$dlatchsr", "$sr", "$ff",
}
LATCH_TYPES = {"$dlatch", "$adlatch", "$dlatchsr"}
MEM_TYPES = {"$mem", "$mem_v2"}
# Pins that are "control" pins: one bit fans out to every bit of the word.
CONTROL_PINS = {"EN", "CLK", "ARST", "SRST", "ALOAD", "SET", "CLR", "S"}

_FINE_SEQ = re.compile(r"^\$_(S?DFFS?R?E?|DFF|ALDFF|DLATCH|SR|SDFFC?E|FF)_")


def is_seq_type(t: str) -> bool:
    return t in SEQ_TYPES or bool(_FINE_SEQ.match(t))


def _bits_of(param) -> str:
    if isinstance(param, int):
        return bin(param)[2:]
    return str(param)


@dataclass
class Pin:
    cell: str
    port: str
    index: int  # bit index within the port


@dataclass
class Graph:
    """Bit-level graph. Net ids are Yosys integer bit ids."""
    top: str
    cells: dict
    ports: dict
    netnames: dict
    drivers: dict = field(default_factory=lambda: defaultdict(list))   # bit -> [Pin|("port",name,idx)]
    sinks: dict = field(default_factory=lambda: defaultdict(list))     # bit -> [Pin]
    bit_name: dict = field(default_factory=dict)                       # bit -> "name[i]"
    port_bits_in: dict = field(default_factory=dict)                   # bit -> (port, idx)
    port_bits_out: dict = field(default_factory=lambda: defaultdict(list))

    # ------------------------------------------------------------------
    @classmethod
    def from_yosys_json(cls, data: dict, top: str | None = None) -> "Graph":
        mods = data["modules"]
        if top is None:
            tops = [m for m, v in mods.items() if v.get("attributes", {}).get("top") in (1, "1", "00000000000000000000000000000001")]
            top = tops[0] if tops else next(iter(mods))
        m = mods[top]
        g = cls(top, m.get("cells", {}), m.get("ports", {}), m.get("netnames", {}))
        g._index()
        return g

    def _index(self) -> None:
        # Best human-readable name per bit: prefer public (no '$'), shortest hierarchy.
        cand: dict[int, tuple[int, str]] = {}
        for name, nn in self.netnames.items():
            hidden = int(nn.get("hide_name", 0)) or name.startswith("$")
            score = (1 if hidden else 0) * 1000 + name.count(".") * 10 + len(name) // 20
            for i, b in enumerate(nn["bits"]):
                if isinstance(b, int):
                    label = name if len(nn["bits"]) == 1 else f"{name}[{i + nn.get('offset', 0)}]"
                    if b not in cand or score < cand[b][0]:
                        cand[b] = (score, label)
        self.bit_name = {b: s for b, (_, s) in cand.items()}
        for pname, p in self.ports.items():
            for i, b in enumerate(p["bits"]):
                if not isinstance(b, int):
                    continue
                if p["direction"] in ("input", "inout"):
                    self.port_bits_in[b] = (pname, i)
                    self.drivers[b].append(("port", pname, i))
                if p["direction"] in ("output", "inout"):
                    self.port_bits_out[b].append((pname, i))
        for cname, c in self.cells.items():
            dirs = c.get("port_directions", {})
            for port, bits in c.get("connections", {}).items():
                d = dirs.get(port, "input")
                for i, b in enumerate(bits):
                    if not isinstance(b, int):
                        continue
                    if d == "output":
                        self.drivers[b].append(Pin(cname, port, i))
                    else:
                        self.sinks[b].append(Pin(cname, port, i))

    # ------------------------------------------------------------------
    def name(self, bit) -> str:
        return self.bit_name.get(bit, f"<bit {bit}>")

    def cell_scope(self, cname: str) -> str:
        """Hierarchical scope of a (flattened) cell, from the names of nets it touches."""
        cache = self.__dict__.setdefault("_scope_cache", {})
        if cname in cache:
            return cache[cname]
        from .rtl_audit import scope_of_net
        c = self.cells[cname]
        dirs = c.get("port_directions", {})
        best = ""
        for want_out in (True, False):
            for port, bits in c.get("connections", {}).items():
                if (dirs.get(port) == "output") != want_out:
                    continue
                for b in bits[:4]:
                    if isinstance(b, int):
                        nm = self.bit_name.get(b, "")
                        if nm and not nm.startswith("$") or "." in nm:
                            sc = scope_of_net(nm)
                            if sc:
                                best = sc
                                break
                if best:
                    break
            if best:
                break
        cache[cname] = best
        return best

    def q_name(self, cname: str, d_bit: int | None = None) -> str:
        """Register name for a sequential cell (its Q net), optionally the bit matching a D bit."""
        c = self.cells.get(cname)
        if not c:
            return cname
        q = c.get("connections", {}).get("Q")
        if not q:
            return cname
        idx = 0
        if d_bit is not None:
            for port in ("D", "EN", "SRST", "AD"):
                bits = c["connections"].get(port, [])
                if d_bit in bits:
                    idx = bits.index(d_bit) if port == "D" else 0
                    break
        b = q[min(idx, len(q) - 1)]
        return self.name(b) if isinstance(b, int) else cname

    def cell_src(self, cname: str) -> str:
        return str(self.cells[cname].get("attributes", {}).get("src", ""))

    def cell_width(self, cname: str) -> int:
        c = self.cells[cname]
        p = c.get("parameters", {})
        for key in ("WIDTH", "Y_WIDTH"):
            if key in p:
                v = p[key]
                return int(v, 2) if isinstance(v, str) else int(v)
        q = c.get("connections", {}).get("Q") or c.get("connections", {}).get("Y")
        return len(q) if q else 1

    def physical_fanout(self, bit) -> int:
        """Estimated number of *gate* input pins driven by this net bit.

        A single-bit control pin (EN, CLK, ARST, SRST, $mux S, ...) of a W-bit
        word-level cell fans out to W gates; each S bit of a $pmux fans out to
        WIDTH gates; all other pins are per-bit.
        """
        n = 0
        for s in self.sinks.get(bit, []):
            c = self.cells[s.cell]
            t = c["type"]
            conn = c.get("connections", {}).get(s.port, [])
            if t in ("$mem", "$mem_v2"):
                n += 1
            elif s.port in CONTROL_PINS and len(conn) == 1:
                n += max(1, self.cell_width(s.cell))
            elif t == "$pmux" and s.port == "S":
                n += max(1, self.cell_width(s.cell))
            else:
                n += 1
        n += len(self.port_bits_out.get(bit, []))
        return n

    # ------------------------------------------------------------------
    def mem_params(self, cname: str) -> dict:
        c = self.cells[cname]
        p = c.get("parameters", {})

        def ip(k, d=0):
            v = p.get(k, d)
            return int(v, 2) if isinstance(v, str) and set(v) <= {"0", "1"} else int(v) if not isinstance(v, str) else d
        rd_ports = ip("RD_PORTS")
        clk_en = _bits_of(p.get("RD_CLK_ENABLE", "0")).zfill(max(rd_ports, 1))
        sync = [clk_en[-1 - i] == "1" for i in range(rd_ports)]
        return {
            "abits": ip("ABITS"), "width": ip("WIDTH"), "size": ip("SIZE"),
            "rd_ports": rd_ports, "wr_ports": ip("WR_PORTS"), "rd_sync": sync,
            "memid": str(p.get("MEMID", cname)),
        }

    def comb_arcs(self, cname: str):
        """Yield (in_port, in_idx, out_port, out_idx, delay) arcs of a comb cell."""
        c = self.cells[cname]
        t = c["type"]
        conns = c.get("connections", {})
        dirs = c.get("port_directions", {})
        outs = [(p, bits) for p, bits in conns.items() if dirs.get(p) == "output"]
        ins = [(p, bits) for p, bits in conns.items() if dirs.get(p) != "output"]
        if t in MEM_TYPES:
            mp = self.mem_params(cname)
            ab, w = mp["abits"], mp["width"]
            for port in range(mp["rd_ports"]):
                if mp["rd_sync"][port]:
                    continue
                for ai in range(ab):
                    for di in range(w):
                        yield ("RD_ADDR", port * ab + ai, "RD_DATA", port * w + di, dm.memory_read_delay(ab))
            return
        for op, obits in outs:
            for oi in range(len(obits)):
                for ip_, ibits in ins:
                    d = dm.cell_delay(t, c, ip_, oi)
                    for ii in range(len(ibits)):
                        if dm.bit_dependency(t, c, ip_, ii, op, oi):
                            yield (ip_, ii, op, oi, d)
