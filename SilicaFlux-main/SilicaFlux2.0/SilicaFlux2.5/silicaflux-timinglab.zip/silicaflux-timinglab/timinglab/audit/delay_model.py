"""Technology-independent delay model for Yosys word-level cells.

Delays are expressed in *unit-gate delays* (UGD): one UGD ~ one 2-input
NAND/NOR/AND/OR stage, an XOR or a 2:1 mux counts 2. The model assumes
synthesis will build log-depth structures (prefix adders, Dadda multiplier
trees, AND-OR mux trees), which is what modern synthesis does under a timing
constraint. It is deliberately simple and is used **only** to rank RTL timing-risk
hypotheses; it is never reported as a timing result. Confirmation comes from
Yosys+ABC mapping to a Liberty library and OpenSTA.

Every function returns the delay from an input bit to an output bit for a cell
whose parameters are given in Yosys JSON form.
"""
from __future__ import annotations

import math

# Dadda reduction heights: max column height reducible in k stages is DADDA[k].
_DADDA = [2]
while _DADDA[-1] < 4096:
    _DADDA.append(int(math.floor(_DADDA[-1] * 1.5)))


def clog2(n: int) -> int:
    return 0 if n <= 1 else int(math.ceil(math.log2(n)))


def dadda_stages(height: int) -> int:
    for k, h in enumerate(_DADDA):
        if height <= h:
            return k
    return len(_DADDA)


def adder_bit_delay(bit: int) -> int:
    """Carry-propagate delay to sum bit *bit* of a prefix adder (UGD)."""
    return 2 * clog2(bit + 1) + 2


def multiplier_bit_delay(bit: int, a_w: int, b_w: int) -> int:
    """Delay to product bit *bit* of an a_w x b_w Dadda multiplier (UGD)."""
    height = min(bit + 1, a_w, b_w)
    return 1 + 2 * dadda_stages(height) + adder_bit_delay(bit)


def _p(cell: dict, name: str, default: int = 0) -> int:
    v = cell.get("parameters", {}).get(name, default)
    if isinstance(v, str):
        try:
            return int(v, 2)
        except ValueError:
            return default
    return int(v)


BITWISE = {"$and", "$or", "$xor", "$xnor", "$not", "$pos", "$buf", "$_AND_", "$_OR_", "$_XOR_",
           "$_NOT_", "$_NAND_", "$_NOR_", "$_XNOR_", "$_ANDNOT_", "$_ORNOT_", "$_BUF_"}
ARITH = {"$add", "$sub", "$neg", "$alu"}
COMPARE_EQ = {"$eq", "$ne", "$eqx", "$nex"}
COMPARE_ORD = {"$lt", "$le", "$gt", "$ge"}
REDUCE = {"$reduce_and", "$reduce_or", "$reduce_xor", "$reduce_xnor", "$reduce_bool"}
LOGIC = {"$logic_not", "$logic_and", "$logic_or"}
SHIFT = {"$shl", "$shr", "$sshl", "$sshr", "$shift", "$shiftx"}
MUXES = {"$mux", "$pmux", "$bmux", "$demux", "$_MUX_", "$bwmux"}
MULDIV = {"$mul", "$div", "$mod", "$divfloor", "$modfloor", "$pow", "$macc", "$macc_v2"}


def bit_dependency(cell_type: str, cell: dict, in_port: str, in_bit: int, out_port: str, out_bit: int) -> bool:
    """Whether output bit depends on input bit (structural, conservative)."""
    if cell_type in ("$and", "$or", "$xor", "$xnor", "$not", "$pos", "$buf", "$mux", "$bwmux") and in_port in ("A", "B"):
        return in_bit == out_bit
    if cell_type == "$mux" and in_port == "S":
        return True
    if cell_type == "$bwmux" and in_port == "S":
        return in_bit == out_bit
    if cell_type == "$pmux" and in_port == "A":
        return in_bit == out_bit
    if cell_type == "$pmux" and in_port == "B":
        width = _p(cell, "WIDTH", 1)
        return (in_bit % width) == out_bit
    if cell_type in ("$add", "$sub", "$neg", "$mul"):
        return in_bit <= out_bit
    if cell_type == "$bmux" and in_port == "A":
        return (in_bit % max(1, _p(cell, "WIDTH", 1))) == out_bit
    if cell_type == "$shiftx" and in_port == "A":
        y_w = max(1, _p(cell, "Y_WIDTH", 1))
        a_w = _p(cell, "A_WIDTH", 1)
        if a_w % y_w == 0 and a_w > y_w:      # indexed part-select a[i*W +: W]
            return (in_bit % y_w) == out_bit
        return True
    if cell_type == "$demux" and in_port == "A":
        return (out_bit % max(1, _p(cell, "WIDTH", 1))) == in_bit
    return True


def cell_delay(cell_type: str, cell: dict, in_port: str, out_bit: int) -> float:
    """UGD from any bit of *in_port* to output bit *out_bit* of the cell."""
    a_w = _p(cell, "A_WIDTH", 1)
    b_w = _p(cell, "B_WIDTH", 1)
    y_w = _p(cell, "Y_WIDTH", _p(cell, "WIDTH", 1))
    if cell_type in ("$pos", "$buf", "$_BUF_"):
        return 0.0
    if cell_type in ("$not", "$_NOT_"):
        return 1.0
    if cell_type in BITWISE:
        return 2.0 if "XOR" in cell_type.upper() or "XNOR" in cell_type.upper() else 1.0
    if cell_type in ARITH:
        return float(adder_bit_delay(out_bit))
    if cell_type == "$mul":
        return float(multiplier_bit_delay(out_bit, a_w, b_w))
    if cell_type in ("$macc", "$macc_v2"):
        return float(multiplier_bit_delay(out_bit, max(a_w, 16), max(a_w, 16)) + 2)
    if cell_type in ("$div", "$mod", "$divfloor", "$modfloor", "$pow"):
        return float(y_w * adder_bit_delay(y_w))   # long sequential subtract chain
    if cell_type in COMPARE_EQ:
        return float(1 + clog2(max(a_w, b_w)))
    if cell_type in COMPARE_ORD:
        return float(2 * clog2(max(a_w, b_w)) + 2)
    if cell_type in REDUCE:
        return float(max(1, clog2(a_w)))
    if cell_type in LOGIC:
        return float(clog2(max(a_w, b_w)) + 1)
    if cell_type in SHIFT:
        stages = min(b_w, clog2(max(a_w, 2)) + 1)
        return float(2 * max(1, stages))
    if cell_type in ("$mux", "$_MUX_", "$bwmux"):
        return 2.0
    if cell_type == "$pmux":
        s_w = _p(cell, "S_WIDTH", 1)
        base = 1 + clog2(s_w + 1)
        return float(base + (1 if in_port == "S" else 0))
    if cell_type == "$bmux":
        s_w = _p(cell, "S_WIDTH", 1)
        return float(2 * s_w)
    if cell_type == "$demux":
        s_w = _p(cell, "S_WIDTH", 1)
        return float(1 + clog2(max(s_w, 1)))
    if cell_type in ("$lut", "$sop"):
        return float(max(1, clog2(_p(cell, "WIDTH", 2))))
    if cell_type == "$tribuf":
        return 1.0
    return 2.0  # unknown combinational cell: small default, flagged by caller


def memory_read_delay(abits: int) -> float:
    """Asynchronous read of a register-file style memory (address decode + mux)."""
    return float(2 * abits + 1)
