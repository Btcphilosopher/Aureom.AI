"""RTL timing-risk audit.

Produces a machine-readable report of *hypotheses* about timing risk, derived from
the Yosys word-level netlist of the RTL (after ``proc; flatten; opt; wreduce;
memory -nomap``). Nothing in this report is a timing result: every finding has
``"status": "hypothesis"`` until :mod:`timinglab.confirm` matches it against
synthesis + OpenSTA evidence.

Categories
----------
critical_path       longest estimated register-to-register paths (unit-gate delays)
arithmetic_chain    paths containing >= 2 arithmetic operators or any multiplier
large_mux           $pmux / $bmux / $shiftx / mux chains with many inputs
high_fanout         nets whose estimated *physical* fanout exceeds a threshold
latch               inferred level-sensitive latches
comb_loop           combinational strongly-connected components
multi_driver        net bits with more than one driver
memory              inferred memories and their port counts (SRAM-macro mappability)
clock_domain        clock nets and the registers they clock
cdc                 crossings between clock domains / synchroniser structures
rdc                 reset structure risks (unsynchronised async reset, mixed reset)
routing             cross-hierarchy combinational paths and wide broadcast buses
pipeline            stall/enable networks and cross-module handshake chains
"""
from __future__ import annotations

import json
import re
import subprocess
from collections import defaultdict, deque, Counter
from dataclasses import dataclass, field
from pathlib import Path

from . import delay_model as dm
from .netlist import Graph, Pin, is_seq_type, LATCH_TYPES, MEM_TYPES

DATA_PINS = {"D", "AD"}
ENABLE_PINS = {"EN", "SRST", "ALOAD", "E", "R"}
ARITH_TYPES = dm.ARITH | {"$mul", "$macc", "$macc_v2", "$div", "$mod"}


@dataclass
class AuditConfig:
    top: str
    files: list[str]
    incdirs: list[str] = field(default_factory=list)
    defines: list[str] = field(default_factory=list)
    frontend: str = "read_verilog -sv"
    yosys: str = "yosys"
    top_n_paths: int = 25
    fanout_threshold: int = 64
    mux_inputs_threshold: int = 8
    wide_bus_threshold: int = 128
    async_inputs: list[str] = field(default_factory=list)   # ports from another clock domain
    clock_period_ugd: float | None = None                   # optional budget for flagging


# ---------------------------------------------------------------------------
# Yosys front-end
# ---------------------------------------------------------------------------

def build_netlist(cfg: AuditConfig, workdir: Path) -> tuple[Path, str]:
    workdir.mkdir(parents=True, exist_ok=True)
    out = workdir / f"{cfg.top}.audit.json"
    inc = " ".join(f"-I{d}" for d in cfg.incdirs)
    dfs = " ".join(f"-D{d}" for d in cfg.defines)
    if cfg.frontend.startswith("read_slang"):
        reads = f"{cfg.frontend} {dfs} {inc} --top {cfg.top} " + " ".join(cfg.files)
    else:
        reads = "; ".join(f"{cfg.frontend} {dfs} {inc} {f}" for f in cfg.files)
    script = (
        f"{reads}\n"
        f"hierarchy -check -top {cfg.top}\n"
        "proc\n"
        "flatten\n"
        "opt_expr\nopt_clean\n"
        "check\n"
        "opt -nodffe -nosdff\n"
        "opt_dff\n"
        "wreduce\n"
        "opt_clean\n"
        "memory -nomap\n"
        "opt_clean\n"
        "check\n"
        "stat\n"
        f"write_json -compat-int {out.name}\n"
    )
    ys = workdir / f"{cfg.top}.audit.ys"
    ys.write_text(script)
    log = workdir / f"{cfg.top}.audit.log"
    # Outputs are written relative to the work directory (YoWASP's WASI sandbox
    # cannot always open absolute paths outside the current directory).
    p = subprocess.run([cfg.yosys, "-l", log.name, "-q", "-s", ys.name], capture_output=True, text=True,
                       cwd=str(workdir))
    if p.returncode != 0:
        raise RuntimeError(f"yosys failed ({p.returncode}); see {log}\n{(p.stdout + p.stderr)[-3000:]}")
    return out, log.read_text(errors="replace")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _src_short(src: str) -> str:
    """'/a/b/tensor_unit.sv:112.22-112.50|...' -> 'tensor_unit.sv:112'."""
    if not src:
        return ""
    first = src.split("|")[0]
    m = re.match(r"(.*?):(\d+)", first)
    if not m:
        return first
    return f"{Path(m.group(1)).name}:{m.group(2)}"


_NET_TAIL = re.compile(r"(\$\d+)?(\[\d+\])?$")


def scope_of_net(name: str) -> str:
    """'g_tiles[0].u_tile.u_vec.lane_result[28]' -> 'g_tiles[0].u_tile.u_vec'."""
    if not name or name.startswith("<"):
        return ""
    n = name.lstrip("\\").lstrip("$")
    n = _NET_TAIL.sub("", n)
    n = re.sub(r"\$\d+$", "", n)
    return n.rsplit(".", 1)[0] if "." in n else ""


def top_block(scope: str) -> str:
    """Top-level block of a scope: generate prefixes are kept with their instance."""
    if not scope:
        return "<top>"
    parts = scope.split(".")
    out = []
    for p in parts:
        out.append(p)
        if not p.startswith("g_"):
            break
    return ".".join(out)


def _src_text(src: str, _cache: dict = {}) -> str:
    """Source line referenced by a Yosys src attribute (stripped), for evidence."""
    if not src:
        return ""
    first = src.split("|")[0]
    m = re.match(r"(.*?):(\d+)", first)
    if not m:
        return ""
    path, line = m.group(1), int(m.group(2))
    if path not in _cache:
        try:
            _cache[path] = Path(path).read_text(errors="replace").splitlines()
        except OSError:
            _cache[path] = []
    lines = _cache[path]
    return lines[line - 1].strip()[:160] if 0 < line <= len(lines) else ""


# ---------------------------------------------------------------------------
# Timing graph and longest paths
# ---------------------------------------------------------------------------

@dataclass
class PathPoint:
    bit: int
    cell: str | None
    cell_type: str
    src: str
    incr: float
    arrival: float
    scope: str


class TimingEstimator:
    def __init__(self, g: Graph):
        self.g = g
        self.adj: dict[int, list[tuple[int, float, str]]] = defaultdict(list)
        self.indeg: Counter = Counter()
        self.startpoints: dict[int, str] = {}
        self.endpoints: dict[int, list[tuple[str, str]]] = defaultdict(list)  # bit -> [(cell, pin)]
        self.unknown_types: Counter = Counter()
        self._build()

    def _build(self) -> None:
        g = self.g
        for cname, c in g.cells.items():
            t = c["type"]
            conns = c.get("connections", {})
            if is_seq_type(t):
                for port, bits in conns.items():
                    d = c.get("port_directions", {}).get(port, "input")
                    for b in bits:
                        if not isinstance(b, int):
                            continue
                        if d == "output":
                            self.startpoints[b] = cname
                        elif port not in ("CLK", "C", "ARST", "SET", "CLR"):
                            self.endpoints[b].append((cname, port))
                continue
            if t in MEM_TYPES:
                mp = g.mem_params(cname)
                ab, w = mp["abits"], mp["width"]
                for port in range(mp["rd_ports"]):
                    data_bits = conns.get("RD_DATA", [])[port * w:(port + 1) * w]
                    if mp["rd_sync"][port]:
                        for b in data_bits:
                            if isinstance(b, int):
                                self.startpoints[b] = cname
                        for pn, wd in (("RD_ADDR", ab), ("RD_EN", 1)):
                            for b in conns.get(pn, [])[port * wd:(port + 1) * wd]:
                                if isinstance(b, int):
                                    self.endpoints[b].append((cname, pn))
                for pn in ("WR_ADDR", "WR_DATA", "WR_EN"):
                    for b in conns.get(pn, []):
                        if isinstance(b, int):
                            self.endpoints[b].append((cname, pn))
            if not t.startswith("$"):
                self.unknown_types[t] += 1   # unresolved blackbox
                continue
            if t not in dm.BITWISE | dm.ARITH | dm.COMPARE_EQ | dm.COMPARE_ORD | dm.REDUCE | dm.LOGIC | \
                    dm.SHIFT | dm.MUXES | dm.MULDIV | MEM_TYPES | {"$lut", "$sop", "$tribuf", "$pos", "$not"}:
                self.unknown_types[t] += 1
            for ip, ii, op, oi, d in g.comb_arcs(cname):
                ib = conns[ip][ii]
                ob = conns[op][oi]
                if isinstance(ib, int) and isinstance(ob, int):
                    self.adj[ib].append((ob, d, cname))
                    self.indeg[ob] += 1
        for b in g.port_bits_in:
            self.startpoints.setdefault(b, "<input>")
        for b, plist in g.port_bits_out.items():
            for pn, i in plist:
                self.endpoints[b].append(("<output>", pn))

    def longest(self):
        """Longest arrival (UGD) to every bit; returns (arrival, pred, loop_bits)."""
        arrival: dict[int, float] = defaultdict(float)
        pred: dict[int, tuple[int, float, str]] = {}
        indeg = Counter(self.indeg)
        nodes = set(self.adj) | set(indeg)
        q = deque(b for b in nodes if indeg[b] == 0)
        seen = 0
        while q:
            u = q.popleft()
            seen += 1
            au = arrival[u]
            for v, d, cname in self.adj.get(u, []):
                if au + d > arrival[v] or v not in pred:
                    if au + d >= arrival[v]:
                        arrival[v] = au + d
                        pred[v] = (u, d, cname)
                indeg[v] -= 1
                if indeg[v] == 0:
                    q.append(v)
        loop_bits = [b for b in nodes if indeg[b] > 0]
        return arrival, pred, loop_bits

    def backtrace(self, bit: int, arrival, pred) -> list[PathPoint]:
        pts: list[PathPoint] = []
        cur = bit
        guard = 0
        while cur in pred and guard < 10000:
            u, d, cname = pred[cur]
            c = self.g.cells[cname]
            pts.append(PathPoint(cur, cname, c["type"], _src_short(self.g.cell_src(cname)), d, arrival[cur],
                                 self.g.cell_scope(cname) or scope_of_net(self.g.name(cur))))
            cur = u
            guard += 1
        sp = self.startpoints.get(cur, "<const/undriven>")
        sp_src = _src_short(self.g.cell_src(sp)) if sp in self.g.cells else ""
        sp_type = self.g.cells[sp]["type"] if sp in self.g.cells else sp
        pts.append(PathPoint(cur, sp if sp in self.g.cells else None, sp_type, sp_src, 0.0, 0.0,
                             (self.g.cell_scope(sp) if sp in self.g.cells else "") or scope_of_net(self.g.name(cur))))
        pts.reverse()
        # anonymous cells inherit the scope of the previous stage from the same source file
        for i in range(1, len(pts)):
            if not pts[i].scope and pts[i - 1].src.split(":")[0] == pts[i].src.split(":")[0]:
                pts[i].scope = pts[i - 1].scope
        return pts


# ---------------------------------------------------------------------------
# Main analysis
# ---------------------------------------------------------------------------

def analyse(g: Graph, cfg: AuditConfig, yosys_log: str = "") -> dict:
    findings: list[dict] = []
    fid = Counter()

    def add(cat: str, severity: str, title: str, evidence: list[str], metrics: dict, recommendation: str, **extra):
        fid[cat] += 1
        f = {
            "id": f"{cat.upper()}-{fid[cat]:03d}",
            "category": cat,
            "severity": severity,
            "status": "hypothesis",
            "title": title,
            "evidence": sorted(set(e for e in evidence if e))[:12],
            "metrics": metrics,
            "recommendation": recommendation,
        }
        f.update(extra)
        findings.append(f)
        return f

    est = TimingEstimator(g)
    arrival, pred, loop_bits = est.longest()

    # ---------------- critical paths (grouped per endpoint register) -------------
    per_ep: dict[str, tuple[float, int, str]] = {}
    for b, eps in est.endpoints.items():
        a = arrival.get(b, 0.0)
        for cname, pin in eps:
            key = cname if cname != "<output>" else f"<output>:{pin}"
            if key not in per_ep or a > per_ep[key][0]:
                per_ep[key] = (a, b, pin)
    ranked = sorted(per_ep.items(), key=lambda kv: -kv[1][0])
    paths = []
    for rank, (ep, (a, b, pin)) in enumerate(ranked[: cfg.top_n_paths], 1):
        pts = est.backtrace(b, arrival, pred)
        ops = [p for p in pts[1:] if p.cell]
        arith = [p for p in ops if p.cell_type in ARITH_TYPES]
        scopes = []
        for p in pts:
            if not scopes or scopes[-1] != p.scope:
                scopes.append(p.scope)
        ep_src = _src_short(g.cell_src(ep)) if ep in g.cells else ep
        ep_name = g.q_name(ep, b) if ep in g.cells and "Q" in g.cells[ep].get("connections", {}) else g.name(b)
        start = pts[0]
        path = {
            "rank": rank,
            "endpoint": ep,
            "endpoint_pin": pin,
            "endpoint_bit": ep_name,
            "endpoint_d_net": g.name(b),
            "endpoint_src": ep_src,
            "startpoint": start.cell or g.name(start.bit),
            "startpoint_bit": g.name(start.bit),
            "startpoint_src": start.src,
            "est_depth_ugd": round(a, 1),
            "word_ops": len(ops),
            "arith_ops": len(arith),
            "multipliers": sum(1 for p in ops if p.cell_type == "$mul"),
            "hier_scopes": scopes,
            "stages": [
                {"type": p.cell_type, "src": p.src, "incr": p.incr, "arrival": round(p.arrival, 1),
                 "net": g.name(p.bit), "scope": p.scope}
                for p in pts
            ],
        }
        paths.append(path)

    # Hypotheses from the ranked paths (unique by endpoint source line)
    seen_src = set()
    worst = paths[0]["est_depth_ugd"] if paths else 0
    for p in paths:
        key = (p["endpoint_src"], p["startpoint_src"])
        if key in seen_src:
            continue
        seen_src.add(key)
        sev = "high" if p["est_depth_ugd"] >= 0.8 * worst else "medium" if p["est_depth_ugd"] >= 0.5 * worst else "low"
        ops_txt = " -> ".join(f"{s['type']}@{s['src']}" for s in p["stages"][1:] if s["type"].startswith("$"))
        add("critical_path", sev,
            f"Deep reg-to-reg path into {p['endpoint_bit']} ({p['est_depth_ugd']} UGD, {p['word_ops']} ops)",
            [p["endpoint_src"], p["startpoint_src"]] + [s["src"] for s in p["stages"]],
            {"est_depth_ugd": p["est_depth_ugd"], "word_ops": p["word_ops"], "multipliers": p["multipliers"],
             "arith_ops": p["arith_ops"], "hier_crossings": max(0, len(p["hier_scopes"]) - 1)},
            "Confirm with synthesis + STA; if confirmed, insert a pipeline register at the "
            "multiplier/adder boundary or split the operator.",
            path_rank=p["rank"], chain=ops_txt, endpoint_src=p["endpoint_src"],
            startpoint_src=p["startpoint_src"], est_depth_ugd=p["est_depth_ugd"])
        if p["multipliers"] or p["arith_ops"] >= 2:
            add("arithmetic_chain", "high" if p["multipliers"] else "medium",
                f"Arithmetic chain ({p['multipliers']} mul, {p['arith_ops']} arith) ending at {p['endpoint_bit']}",
                [s["src"] for s in p["stages"] if s["type"] in ARITH_TYPES],
                {"multipliers": p["multipliers"], "arith_ops": p["arith_ops"], "est_depth_ugd": p["est_depth_ugd"]},
                "Pipeline the multiply and accumulate into separate stages (MAC pipelining) or use a "
                "carry-save accumulator; balance multi-operand adds as a tree.",
                path_rank=p["rank"], chain=ops_txt, endpoint_src=p["endpoint_src"],
                startpoint_src=p["startpoint_src"], est_depth_ugd=p["est_depth_ugd"])

    # ---------------- large multiplexers ----------------
    mux_chain_len = _mux_chain_lengths(g)
    for cname, c in g.cells.items():
        t = c["type"]
        p = c.get("parameters", {})
        def ip(k, d=0):
            v = p.get(k, d)
            return int(v, 2) if isinstance(v, str) else int(v)
        n_in = 0
        if t == "$pmux":
            n_in = ip("S_WIDTH") + 1
        elif t == "$bmux":
            n_in = 2 ** ip("S_WIDTH")
        elif t == "$shiftx":
            n_in = max(1, ip("A_WIDTH") // max(1, ip("Y_WIDTH")))
        elif t == "$mux":
            n_in = mux_chain_len.get(cname, 0) + 1
        if n_in >= cfg.mux_inputs_threshold:
            w = ip("WIDTH", ip("Y_WIDTH", 1))
            add("large_mux", "medium" if n_in < 32 else "high",
                f"{n_in}:1 {'priority mux chain' if t == '$mux' else 'mux'} x {w} bits ({t})",
                [_src_short(g.cell_src(cname))],
                {"inputs": n_in, "width": w, "cell_type": t},
                "Register the select, convert priority chains to one-hot AND-OR, or split into "
                "a two-level mux with a pipeline register.",
                cell=cname, scope=g.cell_scope(cname), src_text=_src_text(g.cell_src(cname)))

    # ---------------- fanout ----------------
    # Clock nets are excluded (CTS builds their trees); the reset net is reported
    # under "rdc". Nets with the same driving source line are grouped.
    clock_bits = set()
    reset_bits = set()
    for cname, c in g.cells.items():
        if is_seq_type(c["type"]):
            for pn in ("CLK", "C"):
                clock_bits.update(b for b in c["connections"].get(pn, []) if isinstance(b, int))
            for pn in ("ARST",):
                reset_bits.update(b for b in c["connections"].get(pn, []) if isinstance(b, int))
    groups: dict[str, dict] = {}
    for b in set(est.adj) | set(g.sinks):
        if b in clock_bits or b in reset_bits:
            continue
        f = g.physical_fanout(b)
        if f < cfg.fanout_threshold:
            continue
        drv = g.drivers.get(b, [])
        if drv and isinstance(drv[0], Pin):
            dsrc = _src_short(g.cell_src(drv[0].cell))
            dtext = _src_text(g.cell_src(drv[0].cell))
            if not dsrc:   # tool-generated logic: attribute to the first sink with a source line
                sk = next((x for x in g.sinks.get(b, []) if g.cell_src(x.cell)), None)
                dsrc = f"(generated) -> {_src_short(g.cell_src(sk.cell))}" if sk else "(generated)"
                dtext = _src_text(g.cell_src(sk.cell)) if sk else ""
        else:
            dsrc, dtext = f"<input port {g.name(b)}>", ""
        key = dsrc
        gr = groups.setdefault(key, {"src": dsrc, "text": dtext, "nets": set(), "bits": 0, "max": 0,
                                     "sum": 0, "scopes": set(), "sink_src": set(), "example": g.name(b)})
        gr["nets"].add(re.sub(r"\[\d+\]$", "", g.name(b)))
        gr["bits"] += 1
        gr["sum"] += f
        if f > gr["max"]:
            gr["max"], gr["example"] = f, g.name(b)
        for s_ in g.sinks.get(b, []):
            gr["scopes"].add(top_block(g.cell_scope(s_.cell)))
            if len(gr["sink_src"]) < 8:
                gr["sink_src"].add(_src_short(g.cell_src(s_.cell)))
    for gr in sorted(groups.values(), key=lambda x: -x["max"])[:30]:
        nets = sorted(gr["nets"])
        label = nets[0] if len(nets) == 1 else f"{len(nets)} nets (e.g. {gr['example']})"
        add("high_fanout", "high" if gr["max"] >= 4 * cfg.fanout_threshold else "medium",
            f"{label} driven at {gr['src']} reaches ~{gr['max']} gate inputs"
            + (f" ({gr['bits']} bits, {gr['sum']} pins total)" if gr["bits"] > 1 else "")
            + (f" across {len(gr['scopes'])} blocks" if len(gr["scopes"]) > 1 else ""),
            [gr["src"]] + sorted(gr["sink_src"]),
            {"physical_fanout_max": gr["max"], "bits": gr["bits"], "pins_total": gr["sum"],
             "sink_blocks": sorted(gr["scopes"])[:16], "nets": nets[:12]},
            "Register/duplicate the driver per consuming block, or let the flow buffer it "
            "(repair_design) and re-check slack and transition.",
            net=gr["example"], src_text=gr["text"])

    # ---------------- latches ----------------
    for cname, c in g.cells.items():
        if c["type"] in LATCH_TYPES or c["type"].startswith("$_DLATCH"):
            add("latch", "high", f"Inferred latch {cname}", [_src_short(g.cell_src(cname))],
                {"width": g.cell_width(cname)},
                "Assign every output in all branches of the combinational block (default assignment).",
                cell=cname)
    for m in re.finditer(r"Latch inferred for signal `([^']+)' from process `([^']+)'", yosys_log):
        add("latch", "high", f"Yosys proc inferred latch for {m.group(1)}", [m.group(2)], {},
            "Add a default assignment.")

    # ---------------- combinational loops ----------------
    if loop_bits:
        sccs = _tarjan(est.adj, set(loop_bits))
        for comp in sccs:
            if len(comp) < 2 and not any(v == comp[0] for v, _, _ in est.adj.get(comp[0], [])):
                continue
            cells = {cn for u in comp for v, _, cn in est.adj.get(u, []) if v in comp}
            add("comb_loop", "high", f"Combinational loop through {len(comp)} net bits",
                [_src_short(g.cell_src(cn)) for cn in cells],
                {"bits": len(comp), "nets": sorted({re.sub(r'\[\d+\]$', '', g.name(b)) for b in comp})[:10]},
                "Break the loop with a register or restructure the handshake.")
    for m in re.finditer(r"found logic loop[^\n]*", yosys_log):
        add("comb_loop", "high", "Yosys check: " + m.group(0), [], {}, "Break the loop.")

    # ---------------- multi-driven nets ----------------
    md = defaultdict(list)
    for b, ds in g.drivers.items():
        if len(ds) > 1:
            nm = re.sub(r"\[\d+\]$", "", g.name(b))
            md[nm].append(ds)
    for nm, lst in md.items():
        srcs = []
        for ds in lst[:1]:
            for d in ds:
                if isinstance(d, Pin):
                    srcs.append(_src_short(g.cell_src(d.cell)))
        add("multi_driver", "high", f"Net {nm} has {len(lst[0])} drivers on {len(lst)} bit(s)", srcs,
            {"bits": len(lst), "drivers": len(lst[0])},
            "Drive the signal from exactly one always block; merge the processes.")
    for m in re.finditer(r"Warning: multiple conflicting drivers for ([^\n]+)", yosys_log):
        add("multi_driver", "high", "Yosys check: multiple conflicting drivers for " + m.group(1).strip(), [], {},
            "Drive the signal from exactly one process.")

    # ---------------- memories ----------------
    # Distinguish SRAM-sized arrays (candidates for a macro) from small register
    # arrays that are expected to become flip-flops anyway.
    for cname, c in g.cells.items():
        if c["type"] in MEM_TYPES:
            mp = g.mem_params(cname)
            bits = mp["width"] * mp["size"]
            ports_ok = (mp["rd_ports"] <= 2 and mp["wr_ports"] <= 1) or (mp["rd_ports"] + mp["wr_ports"] <= 2)
            async_rd = sum(1 for s_ in mp["rd_sync"] if not s_)
            if bits >= 4096:
                kind = "sram-candidate"
                sev = "high" if not ports_ok else "medium"
                rec = ("Restructure accesses to <=1R+1W per cycle so the array maps to an SRAM macro; "
                       "otherwise it synthesises to flip-flops plus wide read muxes." if not ports_ok else
                       "Map to an SRAM macro (or DFFRAM): as RTL it becomes flip-flops plus a "
                       f"{mp['size']}:1 read mux.")
            else:
                kind = "register-array"
                sev = "info"
                rec = "Small array: flip-flop implementation is appropriate."
            add("memory", sev,
                f"{kind}: {mp['memid'].lstrip(chr(92))} {mp['size']}x{mp['width']} ({bits} bits), "
                f"{mp['rd_ports']}R/{mp['wr_ports']}W" + (f", {async_rd} async-read" if async_rd else ""),
                [_src_short(g.cell_src(cname))],
                {**{k: v for k, v in mp.items() if k != "rd_sync"}, "bits": bits, "async_read_ports": async_rd,
                 "macro_compatible_ports": ports_ok, "kind": kind},
                rec, cell=cname)

    # ---------------- clock / reset domains ----------------
    clocks: dict[str, int] = Counter()
    resets: dict[str, int] = Counter()
    reset_src_kind: dict[str, str] = {}
    noreset_bits = 0
    total_ff_bits = 0
    ff_domain: dict[str, str] = {}
    for cname, c in g.cells.items():
        t = c["type"]
        if not is_seq_type(t):
            continue
        conns = c["connections"]
        w = g.cell_width(cname)
        total_ff_bits += w
        clk = conns.get("CLK") or conns.get("C")
        clkname = g.name(clk[0]) if clk and isinstance(clk[0], int) else "<none>"
        clocks[clkname] += w
        ff_domain[cname] = clkname
        ar = conns.get("ARST") or conns.get("R") if t in ("$adff", "$adffe", "$adlatch") or t.startswith("$_DFF_P") else conns.get("ARST")
        if ar and isinstance(ar[0], int):
            rn = g.name(ar[0])
            resets[rn] += w
            reset_src_kind[rn] = "input-port" if ar[0] in g.port_bits_in else "internal"
        elif t in ("$dff", "$dffe"):
            noreset_bits += w
    add("clock_domain", "info", f"{len(clocks)} clock net(s) found", [],
        {"clocks": dict(clocks), "total_ff_bits": total_ff_bits},
        "Each clock needs a create_clock/create_generated_clock in the SDC.")
    if len(clocks) > 1:
        add("cdc", "high", f"{len(clocks)} clock domains: check every crossing", [], {"clocks": dict(clocks)},
            "Use 2-FF synchronisers for single-bit, gray-code/handshake/async FIFO for multi-bit crossings.")
    for rn, n in resets.items():
        if reset_src_kind.get(rn) == "input-port":
            add("rdc", "medium",
                f"Asynchronous reset '{rn}' drives {n} FF bits directly from a primary input (no reset synchroniser)",
                [], {"ff_bits": n},
                "Add an assert-async/deassert-sync reset synchroniser; time recovery/removal in STA "
                "instead of declaring the reset a false path.")
    if noreset_bits and resets:
        add("rdc", "low",
            f"{noreset_bits} FF bits have no reset while {sum(resets.values())} bits use async reset",
            [], {"noreset_bits": noreset_bits, "async_reset_bits": sum(resets.values())},
            "Check that every non-reset register is loaded before use after reset and that async-reset "
            "registers feeding non-reset registers cannot corrupt them during reset assertion.")

    # Synchroniser chains from asynchronous inputs (following $buf/$pos wiring cells)
    def through_wires(bit):
        out, todo, seen = [], [bit], set()
        while todo:
            x = todo.pop()
            if x in seen:
                continue
            seen.add(x)
            for s_ in g.sinks.get(x, []):
                t_ = g.cells[s_.cell]["type"]
                if t_ in ("$buf", "$pos", "$_BUF_"):
                    y = g.cells[s_.cell]["connections"]["Y"][s_.index]
                    if isinstance(y, int):
                        todo.append(y)
                else:
                    out.append(s_)
        return out

    for port in cfg.async_inputs:
        if port not in g.ports:
            continue
        bits = [b for b in g.ports[port]["bits"] if isinstance(b, int)]
        first_ffs, depth2, other_sinks = set(), 0, 0
        for b in bits:
            for s_ in through_wires(b):
                if is_seq_type(g.cells[s_.cell]["type"]) and s_.port == "D":
                    first_ffs.add(s_.cell)
                    q = g.cells[s_.cell]["connections"]["Q"][s_.index]
                    if any(is_seq_type(g.cells[s2.cell]["type"]) and s2.port == "D" for s2 in through_wires(q)):
                        depth2 += 1
                else:
                    other_sinks += 1
        if not bits:
            continue
        if not first_ffs and not other_sinks:
            add("cdc", "info", f"Asynchronous input '{port}' ({len(bits)} bit) has no sinks after optimisation "
                "(the logic it feeds is unobservable and was removed)", [], {"width": len(bits)},
                "Check the integration: the receive path behind this port is not connected to any output.",
                port=port)
            continue
        multi = len(bits) > 1 and depth2 > 0
        sev = "high" if multi or other_sinks else "medium"
        what = "2-FF synchroniser" if depth2 == len(bits) else ("partially synchronised" if depth2 else "a single FF")
        add("cdc", sev,
            f"Asynchronous input '{port}' ({len(bits)} bit) captured by {what}"
            + (" — multi-bit bus synchronised bit-by-bit (no coherency guarantee)" if multi else "")
            + (f"; {other_sinks} unsynchronised combinational sink(s)" if other_sinks else ""),
            [_src_short(g.cell_src(c_)) for c_ in first_ffs],
            {"width": len(bits), "bits_with_2ff": depth2, "unsynchronised_sinks": other_sinks},
            "Synchronise only a single-bit qualifier (valid/toggle) and sample the stable data bus "
            "with it, or use an asynchronous FIFO / gray-coded pointer.", port=port)

    # ---------------- routing-sensitive structures ----------------
    for p in paths[: max(5, cfg.top_n_paths // 2)]:
        if len(p["hier_scopes"]) >= 4:
            add("routing", "medium",
                f"Combinational path crosses {len(p['hier_scopes']) - 1} hierarchy boundaries: "
                + " -> ".join(p["hier_scopes"]),
                [p["startpoint_src"], p["endpoint_src"]],
                {"hier_crossings": len(p["hier_scopes"]) - 1, "est_depth_ugd": p["est_depth_ugd"]},
                "Register at block boundaries (registered outputs) so inter-block wires are not in "
                "series with deep logic.", path_rank=p["rank"])
    # wide buses fanning out to several top-level scopes
    bus_bits = defaultdict(set)
    for b, sinks in g.sinks.items():
        nm = g.name(b)
        base = re.sub(r"\[\d+\]$", "", nm)
        scopes = {top_block(g.cell_scope(s.cell)) for s in sinks}
        if len(scopes) >= 3:
            bus_bits[base].add((b, frozenset(scopes)))
    for base, entries in sorted(bus_bits.items(), key=lambda kv: -len(kv[1])):
        if len(entries) >= cfg.wide_bus_threshold:
            scopes = set().union(*[s for _, s in entries])
            add("routing", "medium",
                f"{len(entries)}-bit bus {base} is broadcast to {len(scopes)} top-level blocks",
                [], {"width": len(entries), "scopes": sorted(scopes)[:12], "wire_sinks": len(entries) * len(scopes)},
                "Floorplan consumers adjacent to the source, or register the bus per destination.", net=base)

    # ---------------- pipeline / stall networks ----------------
    stall_like = []
    for b in g.sinks:
        nm = g.name(b)
        if re.search(r"(stall|flush|ready|valid|hold|en)\b", nm.split(".")[-1]):
            f = g.physical_fanout(b)
            if f >= cfg.fanout_threshold:
                stall_like.append((f, nm, b))
    stall_like.sort(reverse=True)
    seen_names = set()
    for f, nm, b in stall_like:
        base = re.sub(r"\[\d+\]$", "", nm)
        if base in seen_names:
            continue
        a = arrival.get(b, 0.0)
        if a <= 0 and f < 512:
            continue
        seen_names.add(base)
        pts = est.backtrace(b, arrival, pred)
        scopes = []
        for p_ in pts:
            if not scopes or scopes[-1] != p_.scope:
                scopes.append(p_.scope)
        nbits = sum(1 for _, n2, _ in stall_like if re.sub(r"\[\d+\]$", "", n2) == base)
        add("pipeline", "high" if (len(scopes) >= 3 and a > 0) else "medium",
            f"Pipeline control net {base}{f' ({nbits} bits)' if nbits > 1 else ''}: est. arrival {a:.0f} UGD, "
            f"physical fanout ~{f}" + (f", computed across {len(scopes)} scopes" if a > 0 else ", registered"),
            [s_.src for s_ in pts],
            {"arrival_ugd": round(a, 1), "physical_fanout": f, "scopes": scopes, "bits": nbits},
            "Stall/enable nets combine late arrival with large fanout: compute them from registered "
            "signals (registered ready / skid buffer) and replicate per pipeline stage.", net=base)
        if len(seen_names) >= 10:
            break

    summary = {
        "top": g.top,
        "cells": len(g.cells),
        "ff_bits": total_ff_bits,
        "cell_types": dict(Counter(c["type"] for c in g.cells.values()).most_common()),
        "worst_est_depth_ugd": worst,
        "n_findings": len(findings),
        "by_category": dict(Counter(f["category"] for f in findings)),
        "unknown_cell_types": dict(est.unknown_types),
    }
    return {
        "schema": "silicaflux-timinglab/rtl-audit/v1",
        "disclaimer": ("RTL-level estimates in unit-gate delays (UGD) using a technology-independent model; "
                       "all findings are hypotheses until confirmed by synthesis and static timing analysis."),
        "config": {k: v for k, v in cfg.__dict__.items() if k != "files"} | {"files": [Path(f).name for f in cfg.files]},
        "summary": summary,
        "critical_paths": paths,
        "findings": findings,
    }


def _mux_chain_lengths(g: Graph) -> dict[str, int]:
    """Length of $mux priority chains: number of upstream $mux cells feeding A/B."""
    drv_cell = {}
    for b, ds in g.drivers.items():
        for d in ds:
            if isinstance(d, Pin) and g.cells[d.cell]["type"] == "$mux":
                drv_cell[b] = d.cell
    memo: dict[str, int] = {}

    def depth(cn: str, guard=0) -> int:
        if cn in memo:
            return memo[cn]
        if guard > 256:
            return 0
        conns = g.cells[cn]["connections"]
        best = 0
        for port in ("A", "B"):
            ups = {drv_cell.get(b) for b in conns.get(port, []) if isinstance(b, int)}
            for u in ups:
                if u and u != cn:
                    best = max(best, 1 + depth(u, guard + 1))
        memo[cn] = best
        return best

    out = {}
    for cn, c in g.cells.items():
        if c["type"] == "$mux":
            out[cn] = depth(cn)
    # Only report chain heads (not every link of the same chain)
    fed = set()
    for cn in out:
        y = g.cells[cn]["connections"]["Y"]
        for b in y:
            for s in g.sinks.get(b, []):
                if s.cell in out and s.port in ("A", "B"):
                    fed.add(cn)
    return {cn: d for cn, d in out.items() if cn not in fed}


def _tarjan(adj: dict, restrict: set) -> list[list[int]]:
    index = {}
    low = {}
    stack: list[int] = []
    on = set()
    out = []
    counter = [0]
    import sys
    sys.setrecursionlimit(max(10000, sys.getrecursionlimit()))

    def strong(v):
        index[v] = low[v] = counter[0]
        counter[0] += 1
        stack.append(v)
        on.add(v)
        for w, _, _ in adj.get(v, []):
            if w not in restrict:
                continue
            if w not in index:
                strong(w)
                low[v] = min(low[v], low[w])
            elif w in on:
                low[v] = min(low[v], index[w])
        if low[v] == index[v]:
            comp = []
            while True:
                w = stack.pop()
                on.discard(w)
                comp.append(w)
                if w == v:
                    break
            out.append(comp)

    for v in restrict:
        if v not in index:
            strong(v)
    return out


def run_audit(cfg: AuditConfig, workdir: Path) -> dict:
    js, log = build_netlist(cfg, workdir)
    data = json.loads(js.read_text())
    g = Graph.from_yosys_json(data, cfg.top)
    rep = analyse(g, cfg, log)
    rep["yosys_log"] = str(workdir / f"{cfg.top}.audit.log")
    return rep
