"""TimingLab command-line interface.

    timinglab tools                         show discovered EDA tools and versions
    timinglab pdk list | check NAME         list / validate PDK configurations
    timinglab designs                       list the design catalogue
    timinglab discover --repo PATH          repository discovery + dependency graph
    timinglab audit DESIGN [...]            RTL timing-risk audit (hypotheses)
    timinglab run DESIGN [...] --pdk P      synthesis -> STA -> placement/CTS/route
    timinglab confirm --audit A --run R     confirm/refute audit hypotheses with STA
    timinglab report --runs DIR --out DIR   HTML / CSV / JSON dashboard
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .config import ROOT, ConfigError, Tools, list_pdks, load_designs, load_pdk


def _tools(args) -> int:
    from .flow.common import tool_version
    t = Tools.discover()
    for name in ("yosys", "sta", "openroad", "iverilog", "verilator"):
        path = getattr(t, name)
        ver = ""
        if path:
            flag = {"yosys": "-V", "sta": "-version", "openroad": "-version", "iverilog": "-V",
                    "verilator": "--version"}[name]
            ver = tool_version([path, flag])
        print(f"{name:10s} {path or 'NOT FOUND':40s} {ver}")
    return 0


def _pdk(args) -> int:
    if args.action == "list":
        for n in list_pdks():
            try:
                p = load_pdk(n)
                print(f"{n:14s} OK       {p.get('description')}")
            except ConfigError as exc:
                print(f"{n:14s} MISSING  {str(exc).splitlines()[0]}")
        for t in sorted((ROOT / "flow" / "pdk").glob("*.toml.template")):
            print(f"{t.name.replace('.toml.template', ''):14s} TEMPLATE (copy to .toml and fill in licensed kit paths)")
        return 0
    p = load_pdk(args.name)
    print(json.dumps({"name": p.name, "libs": [str(x) for x in p.libs], "tech_lef": str(p.tech_lef),
                      "sc_lef": [str(x) for x in p.sc_lefs], "dont_use_cells": len(p.dont_use_cells())}, indent=2))
    return 0


def _designs(args) -> int:
    for n, d in load_designs().items():
        v = f" (variant of {d.variant_of})" if d.variant_of else ""
        print(f"{n:24s} {d.group:12s} top={d.top}{v}\n{'':24s} {d.description}")
    return 0


def _discover(args) -> int:
    from .discovery import discover, write_dot, render_svg, yosys_hierarchy, crosscheck, hierarchy_tree, roots
    from .flow.common import write_json
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    res = discover(Path(args.repo), Path(args.cache) if args.cache else out / "_expanded")
    if args.yosys_crosscheck:
        t = Tools.discover()
        designs = load_designs()
        d = designs["silicaflux_top"]
        args_s = " ".join(d.slang_args)
        y = yosys_hierarchy(t.yosys, d.files, d.top, d.incdirs,
                            frontend=f"read_slang --threads 1 --keep-hierarchy {args_s} --top {d.top}")
        res.yosys_crosscheck = crosscheck(res, d.top, y["modules"]) if y["ok"] else {"error": y["log"][-2000:]}
    write_json(out / "discovery.json", res.to_dict())
    write_dot(res, out / "silicaflux_v1_dependency_graph.dot", origin_filter="silicaflux.zip",
              title="SilicaFlux v1.0 (silicaflux.zip) — instantiation (solid) and package (dashed) edges")
    write_dot(res, out / "repository_dependency_graph.dot", title="SilicaFlux repository — all design units")
    for f in ("silicaflux_v1_dependency_graph.dot", "repository_dependency_graph.dot"):
        render_svg(out / f)
    print(f"archives={len(res.archives)} files={len(res.inventory)} units={len(res.units)} "
          f"edges={len(res.edges)} unresolved={len(res.unresolved)}")
    for depth, inst, mod, ev in hierarchy_tree(res, "silicaflux_top"):
        print("  " * depth + f"{inst} : {mod}  [{ev.split('::')[-1]}]")
    if res.yosys_crosscheck:
        print("yosys cross-check agree:", res.yosys_crosscheck.get("agree"))
    return 0


def _audit(args) -> int:
    from .audit.rtl_audit import AuditConfig, run_audit
    from .flow.common import write_json
    t = Tools.discover()
    t.require("yosys")
    designs = load_designs()
    names = list(designs) if args.all else args.designs
    out = Path(args.out)
    rc = 0
    for n in names:
        d = designs[n]
        params = " ".join(f"-G {k}={v}" for k, v in d.params.items())
        cfg = AuditConfig(
            top=d.top, files=[str(f) for f in d.files], incdirs=[str(i) for i in d.incdirs],
            frontend=f"read_slang --threads 1 {' '.join(d.slang_args)} {params}", yosys=t.yosys,
            fanout_threshold=args.fanout, async_inputs=d.async_inputs, top_n_paths=args.paths)
        try:
            rep = run_audit(cfg, out / n)
        except Exception as exc:
            print(f"{n}: audit failed: {exc}", file=sys.stderr)
            rc = 1
            continue
        rep["design"] = n
        write_json(out / n / "rtl_audit.json", rep)
        s = rep["summary"]
        print(f"{n:24s} findings={s['n_findings']:3d} worst_est_depth={s['worst_est_depth_ugd']:6.1f} UGD  "
              f"by_cat={s['by_category']}")
    return rc


def _run(args) -> int:
    from .flow.runner import run_design
    t = Tools.discover()
    designs = load_designs()
    steps = tuple(args.steps.split(","))
    base = Path(args.runs)
    rc = 0
    for pdk_name in args.pdk:
        pdk = load_pdk(pdk_name)
        for n in args.designs:
            d = designs[n]
            extra = dict(kv.split("=", 1) for kv in (args.sdc_env or []))
            rec = run_design(d, pdk, t, base, steps=steps, period_ns=args.period, tag=args.tag or "",
                             sdc_extra=extra, repair_timing=args.repair_timing)
            line = f"{pdk_name:12s} {n:24s} {rec.get('status')}"
            if "synth" in rec:
                line += f" cells={rec['synth'].get('cells')} area={rec['synth'].get('area_um2')}"
            for st in ("place", "cts", "grt"):
                tm = rec.get("pnr", {}).get("stages", {}).get(st)
                if tm:
                    line += f" {st}:wns={tm['setup']['wns']} r2r_fmax={tm['reg2reg_fmax_mhz_derived']}"
            print(line)
            rc |= 0 if rec.get("status") == "ok" else 1
    return rc


def _confirm(args) -> int:
    from .confirm import confirm
    from .flow.common import write_json
    audit = json.loads(Path(args.audit).read_text())
    run = json.loads(Path(args.run).read_text())
    res = confirm(audit, run, stage=args.stage)
    write_json(Path(args.out), res)
    for f in res["findings"]:
        if f["category"] in ("critical_path", "arithmetic_chain", "high_fanout", "large_mux", "pipeline"):
            print(f"{f['id']:22s} {f['status']:10s} {f['title'][:90]}")
    return 0


def _report(args) -> int:
    from .report.dashboard import build_dashboard
    out = build_dashboard(Path(args.runs), Path(args.out), audit_dir=Path(args.audit) if args.audit else None,
                          extra_json=[Path(p) for p in (args.extra or [])])
    print(f"dashboard: {out}")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="timinglab", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("tools").set_defaults(fn=_tools)
    p = sub.add_parser("pdk"); p.add_argument("action", choices=["list", "check"]); p.add_argument("name", nargs="?")
    p.set_defaults(fn=_pdk)
    sub.add_parser("designs").set_defaults(fn=_designs)
    p = sub.add_parser("discover")
    p.add_argument("--repo", required=True); p.add_argument("--cache"); p.add_argument("--out", default="reports/discovery")
    p.add_argument("--yosys-crosscheck", action="store_true")
    p.set_defaults(fn=_discover)
    p = sub.add_parser("audit")
    p.add_argument("designs", nargs="*"); p.add_argument("--all", action="store_true")
    p.add_argument("--out", default="reports/audit"); p.add_argument("--fanout", type=int, default=64)
    p.add_argument("--paths", type=int, default=25)
    p.set_defaults(fn=_audit)
    p = sub.add_parser("run")
    p.add_argument("designs", nargs="+"); p.add_argument("--pdk", nargs="+", default=["sky130hd"])
    p.add_argument("--steps", default="synth,sta,pnr"); p.add_argument("--period", type=float)
    p.add_argument("--tag"); p.add_argument("--runs", default="runs")
    p.add_argument("--sdc-env", nargs="*", help="KEY=VALUE overrides for constraints/tl_common.tcl")
    p.add_argument("--repair-timing", action="store_true")
    p.set_defaults(fn=_run)
    p = sub.add_parser("confirm")
    p.add_argument("--audit", required=True); p.add_argument("--run", required=True)
    p.add_argument("--stage", default="grt"); p.add_argument("--out", required=True)
    p.set_defaults(fn=_confirm)
    p = sub.add_parser("report")
    p.add_argument("--runs", default="runs"); p.add_argument("--out", default="reports/dashboard")
    p.add_argument("--audit"); p.add_argument("--extra", nargs="*")
    p.set_defaults(fn=_report)
    args = ap.parse_args(argv)
    try:
        return int(args.fn(args) or 0)
    except ConfigError as exc:
        print(f"timinglab: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
