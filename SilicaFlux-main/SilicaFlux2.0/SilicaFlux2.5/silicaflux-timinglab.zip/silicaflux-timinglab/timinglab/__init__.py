"""SilicaFlux TimingLab — RTL timing-risk audit, synthesis/STA/PnR flow driver and
timing-report analytics for the SilicaFlux processor architecture.

Every number this package reports is either (a) read from a tool log/report
produced by Yosys / OpenSTA / OpenROAD, or (b) explicitly labelled as an RTL-level
*estimate* (hypothesis) produced by :mod:`timinglab.audit`.
"""

__version__ = "1.0.0"
