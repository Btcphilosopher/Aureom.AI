"""Configuration loading: PDKs (``flow/pdk/*.toml``), designs (``flow/designs.toml``)
and tool discovery. Only ``tomllib`` from the standard library is required."""
from __future__ import annotations

import fnmatch
import gzip
import os
import re
import shutil
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FLOW_DIR = ROOT / "flow"
PDK_DIR = FLOW_DIR / "pdk"
CONSTRAINTS_DIR = ROOT / "constraints"

_VAR = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


class ConfigError(RuntimeError):
    pass


def expand(value: str, extra: dict | None = None, strict: bool = True) -> str:
    env = dict(os.environ)
    env.setdefault("TL_ROOT", str(ROOT))
    env.setdefault("TL_PLATFORMS", str(default_platforms_dir()))
    if extra:
        env.update(extra)

    def rep(m):
        k = m.group(1)
        if k in env:
            return env[k]
        if strict:
            raise ConfigError(f"environment variable ${{{k}}} is not set (needed by '{value}')")
        return m.group(0)
    return _VAR.sub(rep, value)


def default_platforms_dir() -> Path:
    for cand in (os.environ.get("TL_PLATFORMS"), ROOT / "third_party" / "orfs-platforms",
                 Path.home() / "eda" / "orfs" / "flow" / "platforms"):
        if cand and Path(cand).is_dir():
            return Path(cand)
    return ROOT / "third_party" / "orfs-platforms"


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@dataclass
class Tools:
    yosys: str | None
    sta: str | None
    openroad: str | None
    iverilog: str | None
    vvp: str | None
    verilator: str | None

    @classmethod
    def discover(cls) -> "Tools":
        def find(env: str, names: list[str], extra: list[str]) -> str | None:
            if os.environ.get(env):
                return os.environ[env]
            for n in names:
                p = shutil.which(n)
                if p:
                    return p
            for e in extra:
                if Path(e).exists():
                    return e
            return None
        yosys = None
        for cand in (os.environ.get("TL_YOSYS"), "/opt/yosys/bin/yosys", shutil.which("yosys"),
                     shutil.which("yowasp-yosys")):
            if cand and _yosys_ok(cand):
                yosys = cand
                break
        return cls(
            yosys=yosys,
            sta=find("TL_STA", [], ["/opt/opensta/bin/sta"]) or shutil.which("sta"),
            openroad=find("TL_OPENROAD", ["openroad"], ["/opt/eda-or/bin/openroad"]),
            iverilog=shutil.which("iverilog"),
            vvp=shutil.which("vvp"),
            verilator=shutil.which("verilator"),
        )

    def require(self, *names: str) -> None:
        missing = [n for n in names if not getattr(self, n)]
        if missing:
            raise ConfigError("required tool(s) not found: " + ", ".join(missing) +
                              " — see docs/TOOLING.md or set TL_<TOOL> environment variables")


def _yosys_ok(path: str | None) -> bool:
    """A Yosys with the slang frontend (read_slang) is required for the SilicaFlux RTL."""
    if not path:
        return False
    import subprocess
    try:
        p = subprocess.run([path, "-p", "help read_slang"], capture_output=True, text=True, timeout=60)
        return p.returncode == 0 and "read_slang [options]" in (p.stdout + p.stderr)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# PDK
# ---------------------------------------------------------------------------

@dataclass
class Pdk:
    name: str
    raw: dict
    platform_dir: Path
    libs: list[Path]
    tech_lef: Path | None
    sc_lefs: list[Path]
    env: dict

    def get(self, key: str, default=None):
        return self.raw.get(key, default)

    @property
    def dont_use(self) -> list[str]:
        return list(self.raw.get("dont_use", []))

    def platform_file(self, key: str) -> Path | None:
        v = self.raw.get(key, "")
        if not v:
            return None
        return self.platform_dir / expand(v)

    def lib_cells(self) -> list[str]:
        names = []
        for lib in self.libs:
            opener = gzip.open if str(lib).endswith(".gz") else open
            with opener(lib, "rt", errors="replace") as f:
                for line in f:
                    m = re.match(r"\s*cell\s*\(\s*\"?([^\"\)\s]+)\"?\s*\)", line)
                    if m:
                        names.append(m.group(1))
        return names

    def dont_use_cells(self) -> list[str]:
        cells = self.lib_cells()
        out = []
        for pat in self.dont_use:
            out.extend(c for c in cells if fnmatch.fnmatchcase(c, pat))
        return sorted(set(out))

    def plain_libs(self, cache: Path) -> list[Path]:
        """Liberty files usable by tools that cannot read gzip (Yosys/ABC)."""
        out = []
        cache.mkdir(parents=True, exist_ok=True)
        for lib in self.libs:
            if str(lib).endswith(".gz"):
                dst = cache / lib.name[:-3]
                if not dst.exists() or dst.stat().st_mtime < lib.stat().st_mtime:
                    with gzip.open(lib, "rb") as fi, open(dst, "wb") as fo:
                        shutil.copyfileobj(fi, fo)
                out.append(dst)
            else:
                out.append(lib)
        return out


def list_pdks() -> list[str]:
    return sorted(p.stem for p in PDK_DIR.glob("*.toml"))


def load_pdk(name: str, check_files: bool = True) -> Pdk:
    path = PDK_DIR / f"{name}.toml"
    if not path.exists():
        tmpl = PDK_DIR / f"{name}.toml.template"
        if tmpl.exists():
            raise ConfigError(f"PDK '{name}' is a template only: copy {tmpl.name} to {name}.toml and fill in your kit paths")
        raise ConfigError(f"unknown PDK '{name}' (available: {', '.join(list_pdks())})")
    raw = tomllib.loads(path.read_text())
    envx = {k: str(v) for k, v in raw.get("env", {}).items()}
    pdir = Path(expand(raw["platform_dir"], envx))
    libs = [pdir / expand(x, envx) if not Path(expand(x, envx)).is_absolute() else Path(expand(x, envx)) for x in raw["lib"]]
    tl = raw.get("tech_lef")
    tech = (pdir / expand(tl, envx)) if tl else None
    scl = [pdir / expand(x, envx) for x in raw.get("sc_lef", [])]
    pdk = Pdk(raw["name"], raw, pdir, libs, tech, scl, envx)
    if check_files:
        missing = [str(p) for p in libs + ([tech] if tech else []) + scl if not p.exists()]
        if missing:
            raise ConfigError(f"PDK '{name}': missing files:\n  " + "\n  ".join(missing) +
                              "\nRun scripts/fetch_pdks.sh or set TL_PLATFORMS.")
    return pdk


# ---------------------------------------------------------------------------
# Designs
# ---------------------------------------------------------------------------

@dataclass
class Design:
    name: str
    top: str
    files: list[Path]
    incdirs: list[Path] = field(default_factory=list)
    params: dict = field(default_factory=dict)
    defines: list[str] = field(default_factory=list)
    slang_args: list[str] = field(default_factory=list)
    sdc: Path | None = None
    clock_port: str = "clk"
    reset_port: str | None = "rst_n"
    period_ns: dict = field(default_factory=dict)
    group: str = ""
    description: str = ""
    variant_of: str | None = None
    utilization: float = 0.45
    async_inputs: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    latency_cycles: int | None = None
    grt_iterations: int | None = None

    def period(self, pdk: Pdk) -> float:
        return float(self.period_ns.get(pdk.name, self.period_ns.get("default", pdk.get("default_period_ns", 10.0))))


def load_designs(path: Path | None = None) -> dict[str, Design]:
    path = path or (FLOW_DIR / "designs.toml")
    raw = tomllib.loads(path.read_text())
    fileset = raw.get("filesets", {})
    out: dict[str, Design] = {}
    common = raw.get("common", {})
    for name, d in raw.get("design", {}).items():
        files: list[str] = []
        for f in d.get("files", []):
            if f.startswith("@"):
                files.extend(fileset[f[1:]])
            else:
                files.append(f)
        sdc = d.get("sdc", common.get("sdc"))
        out[name] = Design(
            name=name,
            top=d["top"],
            files=[ROOT / expand(f) for f in files],
            incdirs=[ROOT / expand(i) for i in d.get("incdirs", common.get("incdirs", []))],
            params=d.get("params", {}),
            defines=d.get("defines", []),
            slang_args=d.get("slang_args", common.get("slang_args", [])),
            sdc=(CONSTRAINTS_DIR / sdc) if sdc else None,
            clock_port=d.get("clock_port", "clk"),
            reset_port=d.get("reset_port", "rst_n"),
            period_ns=d.get("period_ns", common.get("period_ns", {})),
            group=d.get("group", ""),
            description=d.get("description", ""),
            variant_of=d.get("variant_of"),
            utilization=float(d.get("utilization", common.get("utilization", 0.45))),
            async_inputs=d.get("async_inputs", []),
            tags=d.get("tags", []),
            latency_cycles=d.get("latency_cycles"),
            grt_iterations=d.get("grt_congestion_iterations"),
        )
    return out
