"""Lightweight, dependency-free SystemVerilog structural scanner.

This is *not* a full SystemVerilog parser. It extracts the structural facts needed
for a source-backed dependency graph — design units, instantiations, package
imports, includes, clock/reset sensitivity lists and memory-like arrays — and
records the file/line evidence for every fact. Elaboration-accurate hierarchy is
cross-checked separately with Yosys (``hierarchy``), see :mod:`timinglab.discovery`.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from pathlib import Path

# IEEE 1800-2017 reserved words that can never be a module type or instance name.
SV_KEYWORDS = set("""
accept_on alias always always_comb always_ff always_latch and assert assign assume
automatic before begin bind bins binsof bit break buf bufif0 bufif1 byte case casex
casez cell chandle checker class clocking cmos config const constraint context
continue cover covergroup coverpoint cross deassign default defparam design disable
dist do edge else end endcase endchecker endclass endclocking endconfig endfunction
endgenerate endgroup endinterface endmodule endpackage endprimitive endprogram
endproperty endspecify endsequence endtable endtask enum event eventually expect
export extends extern final first_match for force foreach forever fork forkjoin
function generate genvar global highz0 highz1 if iff ifnone ignore_bins
illegal_bins implements implies import incdir include initial inout input inside
instance int integer interconnect interface intersect join join_any join_none
large let liblist library local localparam logic longint macromodule matches
medium modport module nand negedge nettype new nexttime nmos nor noshowcancelled
not notif0 notif1 null or output package packed parameter pmos posedge primitive
priority program property protected pull0 pull1 pulldown pullup
pulsestyle_ondetect pulsestyle_onevent pure rand randc randcase randsequence rcmos
real realtime ref reg reject_on release repeat restrict return rnmos rpmos rtran
rtranif0 rtranif1 s_always s_eventually s_nexttime s_until s_until_with scalared
sequence shortint shortreal showcancelled signed small soft solve specify
specparam static string strong strong0 strong1 struct super supply0 supply1
sync_accept_on sync_reject_on table tagged task this throughout time timeprecision
timeunit tran tranif0 tranif1 tri tri0 tri1 triand trior trireg type typedef union
unique unique0 unsigned until until_with untyped use uwire var vectored virtual void
wait wait_order wand weak weak0 weak1 while wildcard wire with within wor xnor xor
""".split())

UNIT_KINDS = ("module", "macromodule", "interface", "package", "program", "checker")

_TOKEN_RE = re.compile(
    r"""(?P<ws>\s+)
      | (?P<directive>`[A-Za-z_]\w*)
      | (?P<sysid>\$[A-Za-z_]\w*)
      | (?P<number>\d*'[sS]?[bBoOdDhH][0-9a-fA-F_xXzZ?]+|\d+(?:\.\d+)?|'[01xXzZ])
      | (?P<id>[A-Za-z_][\w$]*)
      | (?P<sym>::|\*\*|<<<|>>>|<<=|>>=|<=|>=|==|!=|&&|\|\||\+:|-:|.)
    """,
    re.VERBOSE | re.DOTALL,
)


def strip_comments_and_strings(text: str) -> str:
    """Blank out comments and string literals, preserving line structure."""
    out = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == "/" and i + 1 < n and text[i + 1] == "/":
            j = text.find("\n", i)
            j = n if j < 0 else j
            out.append(" " * (j - i))
            i = j
        elif c == "/" and i + 1 < n and text[i + 1] == "*":
            j = text.find("*/", i + 2)
            j = n if j < 0 else j + 2
            out.append("".join(ch if ch == "\n" else " " for ch in text[i:j]))
            i = j
        elif c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                j += 2 if text[j] == "\\" else 1
            j = min(j + 1, n)
            # keep the quotes so `include "x" remains recognisable
            inner = text[i + 1 : j - 1]
            out.append('"' + inner.replace("\n", " ") + '"')
            i = j
        else:
            out.append(c)
            i += 1
    return "".join(out)


@dataclass
class Token:
    kind: str
    text: str
    line: int


def tokenize(text: str) -> list[Token]:
    toks: list[Token] = []
    line = 1
    pos = 0
    for m in _TOKEN_RE.finditer(text):
        kind = m.lastgroup
        s = m.group(0)
        if kind != "ws":
            toks.append(Token(kind, s, line))
        line += s.count("\n")
        pos = m.end()
    return toks


@dataclass
class Instance:
    module_type: str
    instance_name: str
    line: int
    parameterised: bool = False


@dataclass
class ClockEdge:
    signal: str
    edge: str
    line: int


@dataclass
class ProceduralBlock:
    kind: str           # always_ff | always | always_comb | always_latch
    line: int
    edges: list[ClockEdge] = field(default_factory=list)


@dataclass
class ArrayDecl:
    name: str
    line: int
    text: str


@dataclass
class DesignUnit:
    kind: str
    name: str
    file: str
    line_start: int
    line_end: int
    imports: list[tuple[str, int]] = field(default_factory=list)
    instances: list[Instance] = field(default_factory=list)
    parameters: list[str] = field(default_factory=list)
    blocks: list[ProceduralBlock] = field(default_factory=list)
    arrays: list[ArrayDecl] = field(default_factory=list)
    header: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["imports"] = [{"package": p, "line": l} for p, l in self.imports]
        return d


@dataclass
class FileScan:
    path: str
    units: list[DesignUnit]
    includes: list[tuple[str, int]]
    errors: list[str]


def _skip_balanced(toks: list[Token], i: int, open_s: str = "(", close_s: str = ")") -> int:
    """Given toks[i] == open_s, return index just past the matching close."""
    depth = 0
    n = len(toks)
    while i < n:
        t = toks[i].text
        if t == open_s:
            depth += 1
        elif t == close_s:
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return n


def _file_header(text: str, max_lines: int = 25) -> str:
    """First comment block of the file — used as human-authored evidence."""
    lines = []
    for raw in text.splitlines()[:max_lines]:
        s = raw.strip()
        if s.startswith("//"):
            body = s.lstrip("/").strip()
            if body and not set(body) <= set("=-─━*"):
                lines.append(body)
        elif s and not s.startswith("`"):
            break
    return " | ".join(lines[:6])


_ARRAY_RE = re.compile(
    r"^\s*(?:logic|reg|bit|wire|[A-Za-z_]\w*_t)\s*(?:\[[^\]]+\]\s*)*([A-Za-z_]\w*)\s*\[\s*([^\]:]+?)\s*:\s*([^\]]+?)\s*\]"
)


def scan_text(text: str, path: str) -> FileScan:
    clean = strip_comments_and_strings(text)
    toks = tokenize(clean)
    units: list[DesignUnit] = []
    includes: list[tuple[str, int]] = []
    errors: list[str] = []
    header = _file_header(text)

    # includes
    for idx, t in enumerate(toks):
        if t.kind == "directive" and t.text == "`include" and idx + 1 < len(toks):
            nxt = toks[idx + 1]
            includes.append((nxt.text.strip('"<>'), t.line))

    i, n = 0, len(toks)
    cur: DesignUnit | None = None
    end_kw = {f"end{k}": k for k in UNIT_KINDS}
    end_kw["endmodule"] = "module"
    while i < n:
        t = toks[i]
        if t.kind == "id" and t.text in UNIT_KINDS and cur is None:
            j = i + 1
            while j < n and toks[j].text in ("automatic", "static"):
                j += 1
            if j < n and toks[j].kind == "id":
                kind = "module" if t.text == "macromodule" else t.text
                cur = DesignUnit(kind, toks[j].text, path, t.line, t.line, header=header)
                i = j + 1
                continue
        if t.kind == "id" and t.text in end_kw and cur is not None:
            cur.line_end = t.line
            units.append(cur)
            cur = None
            i += 1
            continue
        if cur is not None:
            i = _scan_unit_token(toks, i, cur)
            continue
        i += 1
    if cur is not None:
        errors.append(f"{path}: unterminated {cur.kind} {cur.name}")
        cur.line_end = toks[-1].line if toks else 0
        units.append(cur)

    # memory-like arrays (unpacked dimension), line based on cleaned text
    clean_lines = clean.splitlines()
    for u in units:
        for ln in range(u.line_start, min(u.line_end, len(clean_lines)) + 1):
            m = _ARRAY_RE.match(clean_lines[ln - 1])
            if m:
                u.arrays.append(ArrayDecl(m.group(1), ln, clean_lines[ln - 1].strip()))
    return FileScan(path, units, includes, errors)


def _scan_unit_token(toks: list[Token], i: int, cur: DesignUnit) -> int:
    n = len(toks)
    t = toks[i]
    # import pkg::*;  (also inside module header: `module x import p::*; (`)
    if t.text == "import" and i + 2 < n and toks[i + 2].text == "::":
        cur.imports.append((toks[i + 1].text, t.line))
        return i + 3
    if t.text in ("parameter", "localparam"):
        j = i + 1
        # skip type tokens until identifier followed by '='
        while j < n and toks[j].text not in (";", ",", ")"):
            if toks[j].kind == "id" and j + 1 < n and toks[j + 1].text == "=":
                if t.text == "parameter":
                    cur.parameters.append(toks[j].text)
                break
            j += 1
        return i + 1
    if t.text in ("always_ff", "always", "always_comb", "always_latch"):
        blk = ProceduralBlock(t.text, t.line)
        j = i + 1
        if j < n and toks[j].text == "@":
            j += 1
            if j < n and toks[j].text == "(":
                end = _skip_balanced(toks, j)
                k = j + 1
                while k < end - 1:
                    if toks[k].text in ("posedge", "negedge") and k + 1 < end:
                        blk.edges.append(ClockEdge(toks[k + 1].text, toks[k].text, toks[k].line))
                        k += 2
                        continue
                    k += 1
                j = end
        cur.blocks.append(blk)
        return j
    # function/task bodies cannot contain instantiations; skip their headers so
    # `function automatic my_t name (` is not mistaken for `my_t name (`.
    if t.text in ("function", "task"):
        j = i + 1
        while j < n and toks[j].text not in (";", "("):
            j += 1
        if j < n and toks[j].text == "(":
            j = _skip_balanced(toks, j)
        return j
    # Instantiation: TYPE [#(...)] NAME [ [range] ] (
    if t.kind == "id" and t.text not in SV_KEYWORDS:
        prev = toks[i - 1].text if i > 0 else ";"
        if prev in (".", "::", "'", "`", "$") or toks[i - 1].kind == "directive":
            return i + 1
        j = i + 1
        parameterised = False
        if j < n and toks[j].text == "#":
            parameterised = True
            j += 1
            if j < n and toks[j].text == "(":
                j = _skip_balanced(toks, j)
            elif j < n:
                j += 1  # #N style
        if j < n and toks[j].kind == "id" and toks[j].text not in SV_KEYWORDS:
            name_tok = toks[j]
            k = j + 1
            while k < n and toks[k].text == "[":
                k = _skip_balanced(toks, k, "[", "]")
            if k < n and toks[k].text == "(" and _statement_start(toks, i):
                cur.instances.append(Instance(t.text, name_tok.text, t.line, parameterised))
                return _skip_balanced(toks, k)
    return i + 1


_STMT_PREV = {";", ")", "begin", "end", "endgenerate", "generate", "else", "endcase",
              "endfunction", "endtask"}


def _statement_start(toks: list[Token], i: int) -> bool:
    """True if toks[i] begins a module item / generate item."""
    if i == 0:
        return True
    prev = toks[i - 1].text
    if prev in _STMT_PREV:
        return True
    # `begin : label` immediately before the item
    if i >= 3 and toks[i - 2].text == ":" and toks[i - 3].text == "begin":
        return True
    # attribute instance `(* ... *)`
    if prev == ")" or (prev == "*" and i >= 2 and toks[i - 2].text == ")"):
        return True
    return False


def scan_file(path: Path) -> FileScan:
    text = path.read_text(errors="replace")
    return scan_text(text, str(path))
