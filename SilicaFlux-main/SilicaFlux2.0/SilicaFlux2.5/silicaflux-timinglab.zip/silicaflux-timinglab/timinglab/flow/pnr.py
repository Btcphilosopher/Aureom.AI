"""OpenROAD placement / CTS / global-route timing experiment."""
from __future__ import annotations

import re
from pathlib import Path

from ..config import Design, Pdk, Tools, FLOW_DIR
from ..parsers.sta_text import parse_stage
from ..parsers.openroad import parse_area, parse_grt_log, parse_congestion_report, annotate_congestion
from .common import RunDir, run_logged, sdc_env, write_json, tool_version
from .sta import resolve_sdc

STAGES = ("place", "cts", "grt")


def core_side_for_pins(cell_area_um2: float, util: float, port_bits: int, pin_pitch_um: float) -> float | None:
    """Return a square core side (um) when the utilisation-based floorplan cannot
    host all I/O pins at one pin per routing track on the four edges; else None."""
    if not cell_area_um2 or not port_bits:
        return None
    side_util = (cell_area_um2 / util) ** 0.5
    side_pins = port_bits * pin_pitch_um * 1.25 / 4.0
    return round(side_pins, 1) if side_pins > side_util else None


def run_pnr(design: Design, pdk: Pdk, tools: Tools, out: RunDir, period_ns: float,
            sdc_extra: dict | None = None, repair_timing: bool = False, npaths: int = 50,
            timeout: int = 7200, synth: dict | None = None) -> dict:
    tools.require("openroad")
    synth = synth or {}
    side = core_side_for_pins(synth.get("area_um2", 0.0), design.utilization, synth.get("port_bits", 0),
                              float(pdk.get("pin_pitch_um", 1.0)))
    pnr_dir = out.p("pnr", ".keep").parent
    env = sdc_env(design, pdk, period_ns, sdc_extra)
    # Placed and later stages: propagated clocks are set explicitly after CTS in
    # pnr.tcl; ideal-clock uncertainty still applies before CTS.
    env.update({
        "TL_TECH_LEF": str(pdk.tech_lef),
        "TL_SC_LEFS": " ".join(str(l) for l in pdk.sc_lefs),
        "TL_LIBS": " ".join(str(l) for l in pdk.libs),
        "TL_NETLIST": str(out.p("netlist.v")),
        "TL_TOP": design.top,
        "TL_SDC": str(resolve_sdc(design)),
        "TL_OUTDIR": str(pnr_dir),
        "TL_PLATFORM_DIR": str(pdk.platform_dir),
        "TL_SITE": pdk.get("place_site"),
        "TL_UTIL": str(int(round(design.utilization * 100))),
        "TL_DENSITY": str(max(pdk.get("place_density", 0.6), design.utilization + 0.1)),
        "TL_IO_H": pdk.get("io_layer_h"),
        "TL_IO_V": pdk.get("io_layer_v"),
        "TL_MIN_LAYER": pdk.get("min_routing_layer"),
        "TL_MAX_LAYER": pdk.get("max_routing_layer"),
        "TL_MAKE_TRACKS": str(pdk.platform_file("make_tracks") or ""),
        "TL_SET_RC": str(pdk.platform_file("set_rc") or ""),
        "TL_TAPCELL": str(pdk.platform_file("tapcell") or ""),
        "TL_REPAIR_TIMING": "1" if repair_timing else "0",
        "TL_CTS_BUFS": " ".join(pdk.get("cts_buf_list", [])),
        "TL_NPATHS": str(npaths),
        "TL_CORE_SIDE": "" if side is None else str(side),
        "TL_GRT_ITERS": str(design.grt_iterations or ""),
    })
    res = run_logged([tools.openroad, "-no_init", "-exit", str(FLOW_DIR / "openroad" / "pnr.tcl")],
                     out.p("pnr.log"), env=env, timeout=timeout)
    log_text = Path(res["log"]).read_text(errors="replace")
    summary = {"step": "pnr", "design": design.name, "pdk": pdk.name, "period_ns": period_ns,
               "openroad": tool_version([tools.openroad, "-version"]), "repair_timing": repair_timing,
               "floorplan": {"mode": "pin-limited" if side else "utilisation", "core_side_um": side,
                             "target_util": design.utilization},
               "grt_congestion_iterations": design.grt_iterations or "tool default", **res}
    errors = re.findall(r"^\[ERROR [^\]]+\].*$", log_text, flags=re.M)
    if errors:
        summary["errors"] = errors[:10]
    summary["stages"] = {}
    for st in STAGES:
        d = pnr_dir / st
        if (d / "summary.rpt").exists():
            summary["stages"][st] = parse_stage(d, period_ns)
    summary["area"] = {k: parse_area(pnr_dir / f"area_{k}.rpt") for k in ("place", "grt")}
    summary["routing"] = parse_grt_log(log_text)
    cong_summary, cong_nets = parse_congestion_report(pnr_dir / "congestion.rpt")
    if "grt" in summary["stages"] and cong_summary["available"]:
        cong_summary["critical_path_correlation"] = annotate_congestion(summary["stages"]["grt"], cong_nets)
    summary["congestion"] = cong_summary
    write_json(out.p("pnr.json"), summary)
    return summary
