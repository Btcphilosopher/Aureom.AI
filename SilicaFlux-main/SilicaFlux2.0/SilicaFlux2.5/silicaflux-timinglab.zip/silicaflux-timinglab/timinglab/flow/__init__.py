"""Flow drivers: Yosys synthesis, OpenSTA static timing analysis, OpenROAD place & route."""
