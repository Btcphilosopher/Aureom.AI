"""Standalone OpenSTA on the synthesised (unplaced) netlist."""
from __future__ import annotations

from pathlib import Path

from ..config import Design, Pdk, Tools, FLOW_DIR, CONSTRAINTS_DIR
from ..parsers.sta_text import parse_stage
from .common import RunDir, run_logged, sdc_env, write_json, tool_version


def resolve_sdc(design: Design) -> Path:
    return design.sdc or (CONSTRAINTS_DIR / "block_generic.sdc")


def run_sta(design: Design, pdk: Pdk, tools: Tools, out: RunDir, period_ns: float,
            sdc_extra: dict | None = None, npaths: int = 50) -> dict:
    tools.require("sta")
    stage_dir = out.p("synth_sta", ".keep").parent
    env = sdc_env(design, pdk, period_ns, sdc_extra)
    env.update({
        "TL_LIBS": " ".join(str(l) for l in pdk.libs),
        "TL_NETLIST": str(out.p("netlist.v")),
        "TL_TOP": design.top,
        "TL_SDC": str(resolve_sdc(design)),
        "TL_OUTDIR": str(stage_dir),
        "TL_NPATHS": str(npaths),
    })
    res = run_logged([tools.sta, "-no_init", "-no_splash", "-exit", str(FLOW_DIR / "sta" / "sta.tcl")],
                     out.p("sta.log"), env=env, timeout=3600)
    summary = {"step": "sta", "stage": "synth", "design": design.name, "pdk": pdk.name,
               "period_ns": period_ns, "sdc": str(resolve_sdc(design).name),
               "opensta": tool_version([tools.sta, "-version"]), **res}
    if res["returncode"] == 0:
        summary["timing"] = parse_stage(stage_dir, period_ns)
    write_json(out.p("sta.json"), summary)
    return summary
