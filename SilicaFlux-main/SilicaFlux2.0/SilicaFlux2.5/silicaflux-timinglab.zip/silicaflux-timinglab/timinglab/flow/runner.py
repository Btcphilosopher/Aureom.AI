"""Run the full per-design flow and collect a single result record."""
from __future__ import annotations

import json
import time
from pathlib import Path

from ..config import Design, Pdk, Tools, load_designs, load_pdk
from .common import RunDir, write_json
from .synth import run_synth
from .sta import run_sta
from .pnr import run_pnr


def run_design(design: Design, pdk: Pdk, tools: Tools, base: Path, steps=("synth", "sta", "pnr"),
               period_ns: float | None = None, tag: str = "", sdc_extra: dict | None = None,
               repair_timing: bool = False) -> dict:
    period = period_ns or design.period(pdk)
    out = RunDir.for_run(base, design, pdk, tag)
    prev = _load(out.p("result.json"))   # keep earlier steps when re-running a subset
    rec = {}
    for k in ("synth", "sta", "pnr"):
        if k not in steps:
            v = prev.get(k) or _load(out.p(f"{k}.json"))
            if v:
                rec[k] = v
    rec.update({"design": design.name, "top": design.top, "group": design.group, "variant_of": design.variant_of,
           "pdk": pdk.name, "period_ns": period, "tag": tag, "started": time.strftime("%Y-%m-%dT%H:%M:%S"),
           "rundir": str(out.root), "params": design.params, "sdc_extra": sdc_extra or {},
           "latency_cycles": design.latency_cycles, "description": design.description,
           "sdc": (design.sdc.name if design.sdc else "block_generic.sdc")})
    if "synth" in steps:
        rec["synth"] = run_synth(design, pdk, tools, out, period)
        if rec["synth"]["returncode"] != 0:
            rec["status"] = "synth_failed"
            write_json(out.p("result.json"), rec)
            return rec
    if "sta" in steps:
        rec["sta"] = run_sta(design, pdk, tools, out, period, sdc_extra)
    if "pnr" in steps:
        rec["pnr"] = run_pnr(design, pdk, tools, out, period, sdc_extra, repair_timing=repair_timing,
                             synth=rec.get("synth") or _load(out.p("synth.json")))
    rec["status"] = "ok"
    rec["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    write_json(out.p("result.json"), rec)
    return rec


def _load(path: Path) -> dict:
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


def load_result(path: Path) -> dict:
    return json.loads(path.read_text())


def collect_results(base: Path) -> list[dict]:
    return [load_result(p) for p in sorted(base.rglob("result.json"))]
