"""Yosys synthesis to a Liberty standard-cell library (timing-driven ABC mapping)."""
from __future__ import annotations

import json
import re
from pathlib import Path

from ..config import Design, Pdk, Tools
from .common import RunDir, run_logged, write_json, rel, tool_version


def slang_read(design: Design, extra_defines: list[str] | None = None) -> str:
    inc = " ".join(f"-I{d}" for d in design.incdirs)
    dfs = " ".join(f"-D{d}" for d in (design.defines + (extra_defines or [])))
    params = " ".join(f"-G {k}={v}" for k, v in design.params.items())
    args = " ".join(design.slang_args)
    files = " ".join(str(f) for f in design.files)
    return f"read_slang --threads 1 {args} {inc} {dfs} --top {design.top} {params} {files}"


def synth_script(design: Design, pdk: Pdk, libs: list[Path], period_ns: float, out: RunDir,
                 dont_use_cells: list[str]) -> str:
    lib_args = " ".join(f"-liberty {l}" for l in libs)
    du = " ".join(f"-dont_use {c}" for c in dont_use_cells)
    hi_c, hi_p = pdk.get("tiehi")
    lo_c, lo_p = pdk.get("tielo")
    buf_c, buf_i, buf_o = pdk.get("min_buf")
    constr = out.p("abc.constr")   # referenced relative to the run directory below
    constr.write_text(f"set_driving_cell {pdk.get('abc_driver_cell')}\nset_load {pdk.get('abc_load_ff')}\n")
    period_ps = int(round(period_ns * 1000))
    return "\n".join([
        f"# SilicaFlux TimingLab synthesis: design={design.name} top={design.top} pdk={pdk.name} period={period_ns}ns",
        slang_read(design),
        f"hierarchy -check -top {design.top}",
        "proc",
        f"tee -o pre_opt_stat.txt stat",
        f"synth -top {design.top} -flatten",
        "opt_clean",
        f"dfflibmap {lib_args} {du}",
        "opt",
        f"abc {lib_args} {du} -D {period_ps} -constr abc.constr",
        "setundef -zero",
        f"hilomap -singleton -hicell {hi_c} {hi_p} -locell {lo_c} {lo_p}",
        "opt_clean -purge",
        f"insbuf -buf {buf_c} {buf_i} {buf_o}",
        "autoname",
        "check",
        f"tee -o synth_stat.json stat -json {lib_args}",
        f"tee -o synth_stat.txt stat {lib_args}",
        f"write_verilog -noattr -noexpr -nohex -nodec netlist.v",
        f"write_json -compat-int netlist.json",
        "",
    ])


def run_synth(design: Design, pdk: Pdk, tools: Tools, out: RunDir, period_ns: float, timeout: int = 7200) -> dict:
    tools.require("yosys")
    libs = pdk.plain_libs((out.root.parent.parent / "_lib_cache").resolve())
    script = synth_script(design, pdk, libs, period_ns, out, pdk.dont_use_cells())
    ys = out.p("synth.ys")
    ys.write_text(script)
    res = run_logged([tools.yosys, "-q", "-l", "synth.log", "-s", "synth.ys"],
                     out.p("synth.stdout"), timeout=timeout, cwd=out.root)
    summary = {"step": "synth", "design": design.name, "pdk": pdk.name, "period_ns": period_ns,
               "yosys": tool_version([tools.yosys, "-V"]), **res}
    if res["returncode"] == 0:
        summary.update(parse_stat(out.p("synth_stat.json"), out.p("synth_stat.txt"), design.top))
        summary["netlist"] = rel(out.p("netlist.v"))
        summary["warnings"] = _warnings(out.p("synth.log"))
        summary["ff_src_map"] = rel(_ff_src_map(out.p("netlist.json"), out.p("ff_src_map.json")))
    write_json(out.p("synth.json"), summary)
    return summary


def parse_stat(js: Path, txt: Path, top: str) -> dict:
    out: dict = {}
    try:
        data = json.loads(js.read_text())
        mods = data.get("modules", {})
        m = mods.get(f"\\{top}") or mods.get(top) or (next(iter(mods.values())) if mods else {})
        out["cells"] = int(m.get("num_cells", 0))
        out["port_bits"] = int(m.get("num_port_bits", 0))
        if "area" in m:
            out["area_um2"] = float(m["area"])
        types = m.get("num_cells_by_type", {})
        out["cell_types"] = {k: int(v) for k, v in types.items()}
        seq = sum(v for k, v in out["cell_types"].items() if re.search(r"(df|dff|latch|sdf|edf|dl)[a-z0-9]*_", k.lower()))
        out["seq_cells"] = int(seq)
    except Exception as exc:
        out["stat_error"] = str(exc)
    if "area_um2" not in out and txt.exists():
        m = re.search(r"Chip area for (?:top )?module '\\?[^']+':\s*([0-9.]+)", txt.read_text())
        if m:
            out["area_um2"] = float(m.group(1))
    return out


def _warnings(log: Path) -> list[str]:
    if not log.exists():
        return []
    ws = []
    for line in log.read_text(errors="replace").splitlines():
        if line.startswith("Warning:") or ": Warning:" in line:
            ws.append(line.strip())
    # de-duplicate per message pattern (strip identifiers)
    seen, uniq = set(), []
    for w in ws:
        k = re.sub(r"'[^']*'|`[^']*'|\d+", "#", w)
        if k not in seen:
            seen.add(k)
            uniq.append(w)
    return uniq[:50]


def _ff_src_map(netlist_json: Path, out: Path) -> Path:
    """instance name -> RTL source line, for sequential cells (they keep Yosys `src`
    attributes through dfflibmap; ABC-mapped combinational cells do not). Lets STA
    endpoints be traced back to RTL registers for hypothesis confirmation."""
    data = json.loads(netlist_json.read_text())
    m = next(iter(data["modules"].values()))
    out_map = {}
    for name, c in m.get("cells", {}).items():
        src = c.get("attributes", {}).get("src")
        pins = set(c.get("connections", {})) | set(c.get("port_directions", {}))
        if src and pins & {"Q", "QN", "Q_N"} and pins & {"CLK", "CK", "C", "GATE", "E", "G"}:
            first = str(src).split("|")[0]
            mm = re.match(r"(.*?):(\d+)", first)
            out_map[name.lstrip("\\")] = f"{Path(mm.group(1)).name}:{mm.group(2)}" if mm else first
    out.write_text(json.dumps(out_map, indent=0))
    netlist_json.unlink()          # large; the map is all we need
    return out
