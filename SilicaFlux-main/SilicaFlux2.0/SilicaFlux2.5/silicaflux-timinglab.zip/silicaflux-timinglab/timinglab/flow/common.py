"""Shared helpers for flow steps: run directories, environment, subprocess logging."""
from __future__ import annotations

import json
import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

from ..config import Design, Pdk, ROOT


@dataclass
class RunDir:
    root: Path

    @classmethod
    def for_run(cls, base: Path, design: Design, pdk: Pdk, tag: str = "") -> "RunDir":
        d = base / pdk.name / (design.name + (f"__{tag}" if tag else ""))
        d.mkdir(parents=True, exist_ok=True)
        return cls(d)

    def p(self, *parts: str) -> Path:
        q = self.root.joinpath(*parts)
        q.parent.mkdir(parents=True, exist_ok=True)
        return q


def sdc_env(design: Design, pdk: Pdk, period_ns: float, extra: dict | None = None) -> dict:
    """Environment consumed by constraints/tl_common.tcl."""
    drv = pdk.get("min_buf", [None, None, None])
    from ..config import FLOW_DIR, CONSTRAINTS_DIR
    env = {
        "TL_FLOW_DIR": str(FLOW_DIR),
        "TL_CONSTRAINTS_DIR": str(CONSTRAINTS_DIR),
        "TL_CLOCK_PERIOD": f"{period_ns:.4f}",
        "TL_CLOCK_PORT": design.clock_port,
        "TL_RESET_PORT": design.reset_port or "",
        "TL_DRIVER_CELL": drv[0] or "",
        "TL_DRIVER_PIN": drv[2] or "",
        "TL_LOAD_PF": f"{pdk.get('abc_load_ff', 5.0) / 1000.0:.5f}",
    }
    env.update({k: str(v) for k, v in pdk.env.items()})
    if extra:
        env.update({k: str(v) for k, v in extra.items()})
    return env


def run_logged(cmd: list[str], log: Path, env: dict | None = None, cwd: Path | None = None,
               timeout: int | None = None) -> dict:
    full_env = dict(os.environ)
    if env:
        full_env.update(env)
    t0 = time.time()
    with open(log, "w") as fh:
        fh.write("# cmd: " + " ".join(cmd) + "\n")
        fh.flush()
        try:
            p = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT, env=full_env,
                               cwd=str(cwd) if cwd else None, timeout=timeout)
            rc = p.returncode
        except subprocess.TimeoutExpired:
            rc = -9
            fh.write(f"\n# TIMEOUT after {timeout}s\n")
    return {"returncode": rc, "seconds": round(time.time() - t0, 2), "log": str(log)}


def write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, default=str) + "\n")


def rel(p: Path) -> str:
    try:
        return str(Path(p).resolve().relative_to(ROOT))
    except ValueError:
        return str(p)


def tool_version(cmd: list[str]) -> str:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        out = (p.stdout + p.stderr).strip().splitlines()
        return out[0] if out else ""
    except Exception as exc:  # pragma: no cover
        return f"unavailable ({exc})"
