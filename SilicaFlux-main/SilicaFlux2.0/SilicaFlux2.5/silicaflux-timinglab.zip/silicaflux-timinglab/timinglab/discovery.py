"""Repository discovery: inventory, design-unit index and source-backed dependency graph.

The SilicaFlux GitHub repository ships most of its source as archives
(``*.zip`` / ``*.tar.gz``). Discovery therefore:

1. unpacks every archive into its own directory under a cache folder,
2. inventories every SystemVerilog / Verilog / ``.sf`` / ``.sfx`` file
   (path, archive of origin, line count, SHA-256),
3. scans each HDL file with :mod:`timinglab.svscan` for design units,
   instantiations, package imports, ``include``s, clock/reset edges and arrays,
4. resolves instantiations against the set of design units *actually found*;
   anything not found is reported as ``unresolved`` — never guessed,
5. optionally cross-checks one or more tops against Yosys ``hierarchy`` output.

Every edge in the graph carries ``file:line`` evidence.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import tarfile
import zipfile
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from .svscan import scan_file

HDL_EXT = {".sv", ".v", ".svh", ".vh", ".sva"}
DSL_EXT = {".sf"}
ASM_EXT = {".sfx"}
ARCHIVE_SUFFIXES = (".zip", ".tar.gz", ".tgz")


@dataclass
class InventoryEntry:
    path: str            # path relative to the discovery root (archive-expanded)
    origin: str          # archive file (relative to repo) or "<tree>"
    kind: str            # hdl | dsl | asm
    lines: int
    sha256: str

    def to_dict(self) -> dict:
        return self.__dict__.copy()


@dataclass
class DiscoveryResult:
    repo: str
    archives: list[dict] = field(default_factory=list)
    inventory: list[InventoryEntry] = field(default_factory=list)
    units: dict[str, dict] = field(default_factory=dict)          # key: unit name
    duplicates: dict[str, list[str]] = field(default_factory=dict)
    edges: list[dict] = field(default_factory=list)                # instantiation edges
    package_edges: list[dict] = field(default_factory=list)
    unresolved: list[dict] = field(default_factory=list)
    yosys_crosscheck: dict = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "repo": self.repo,
            "archives": self.archives,
            "inventory": [e.to_dict() for e in self.inventory],
            "units": self.units,
            "duplicates": self.duplicates,
            "edges": self.edges,
            "package_edges": self.package_edges,
            "unresolved": self.unresolved,
            "yosys_crosscheck": self.yosys_crosscheck,
            "notes": self.notes,
        }


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_extract_zip(zf: zipfile.ZipFile, dest: Path) -> None:
    dest = dest.resolve()
    for m in zf.infolist():
        target = (dest / m.filename).resolve()
        if not str(target).startswith(str(dest)):
            raise ValueError(f"unsafe path in archive: {m.filename}")
    zf.extractall(dest)


def _safe_extract_tar(tf: tarfile.TarFile, dest: Path) -> None:
    dest = dest.resolve()
    for m in tf.getmembers():
        target = (dest / m.name).resolve()
        if not str(target).startswith(str(dest)) or m.issym() or m.islnk():
            raise ValueError(f"unsafe member in archive: {m.name}")
    tf.extractall(dest)


def expand_archives(repo: Path, cache: Path) -> list[dict]:
    """Extract every archive in *repo* into ``cache/<archive-stem>/``."""
    out = []
    cache.mkdir(parents=True, exist_ok=True)
    for p in sorted(repo.rglob("*")):
        if not p.is_file() or ".git" in p.parts:
            continue
        name = p.name.lower()
        if not name.endswith(ARCHIVE_SUFFIXES):
            continue
        stem = p.name
        for suf in ARCHIVE_SUFFIXES:
            if name.endswith(suf):
                stem = p.name[: -len(suf)]
        stem = stem.replace(" ", "_")
        dest = cache / stem
        if dest.exists():
            shutil.rmtree(dest)
        dest.mkdir(parents=True)
        try:
            if name.endswith(".zip"):
                with zipfile.ZipFile(p) as zf:
                    _safe_extract_zip(zf, dest)
            else:
                with tarfile.open(p) as tf:
                    _safe_extract_tar(tf, dest)
            status = "ok"
        except Exception as exc:  # pragma: no cover - defensive
            status = f"error: {exc}"
        out.append({
            "archive": str(p.relative_to(repo)),
            "sha256": _sha256(p),
            "extracted_to": stem,
            "status": status,
        })
    return out


def _classify(path: Path) -> str | None:
    suf = path.suffix.lower()
    if suf in HDL_EXT:
        return "hdl"
    if suf in DSL_EXT:
        return "dsl"
    if suf in ASM_EXT:
        return "asm"
    return None


def discover(repo: Path, cache: Path | None = None, extra_roots: list[Path] | None = None) -> DiscoveryResult:
    """Run discovery over a repository checkout (archives are expanded)."""
    repo = repo.resolve()
    res = DiscoveryResult(repo=str(repo))
    roots: list[tuple[Path, str]] = []
    if cache is not None:
        res.archives = expand_archives(repo, cache)
        for a in res.archives:
            roots.append((cache / a["extracted_to"], a["archive"]))
    roots.append((repo, "<tree>"))
    for r in extra_roots or []:
        roots.append((r.resolve(), "<extra>"))

    scans = []
    seen_hashes: dict[str, str] = {}
    for root, origin in roots:
        if not root.exists():
            continue
        for p in sorted(root.rglob("*")):
            if not p.is_file() or ".git" in p.parts:
                continue
            kind = _classify(p)
            if kind is None:
                continue
            rel = f"{origin}::{p.relative_to(root)}" if origin != "<tree>" else str(p.relative_to(root))
            text = p.read_text(errors="replace")
            digest = _sha256(p)
            res.inventory.append(InventoryEntry(rel, origin, kind, text.count("\n") + (0 if text.endswith("\n") else 1), digest))
            if kind == "hdl":
                fs = scan_file(p)
                scans.append((rel, origin, fs))
                seen_hashes.setdefault(digest, rel)

    # Index design units (name collisions across sub-projects are kept apart by
    # qualifying with the origin archive).
    by_name: dict[str, list[str]] = defaultdict(list)
    for rel, origin, fs in scans:
        for u in fs.units:
            key = u.name if u.name not in res.units else f"{u.name}@{origin}"
            d = u.to_dict()
            d["file"] = rel
            d["origin"] = origin
            d["includes"] = [{"file": f, "line": l} for f, l in fs.includes]
            res.units[key] = d
            by_name[u.name].append(key)
    res.duplicates = {k: v for k, v in by_name.items() if len(v) > 1}

    def resolve(name: str, origin: str) -> str | None:
        keys = by_name.get(name, [])
        same = [k for k in keys if res.units[k]["origin"] == origin]
        if same:
            return same[0]
        return keys[0] if keys else None

    for key, u in res.units.items():
        for inst in u["instances"]:
            tgt = resolve(inst["module_type"], u["origin"])
            edge = {
                "parent": key,
                "child": tgt,
                "module_type": inst["module_type"],
                "instance": inst["instance_name"],
                "evidence": f"{u['file']}:{inst['line']}",
            }
            if tgt is None:
                res.unresolved.append(edge)
            else:
                res.edges.append(edge)
        for imp in u["imports"]:
            tgt = resolve(imp["package"], u["origin"])
            res.package_edges.append({
                "unit": key, "package": imp["package"], "resolved": tgt,
                "evidence": f"{u['file']}:{imp['line']}",
            })
    return res


# ---------------------------------------------------------------------------
# Hierarchy helpers
# ---------------------------------------------------------------------------

def children_of(res: DiscoveryResult) -> dict[str, list[dict]]:
    ch: dict[str, list[dict]] = defaultdict(list)
    for e in res.edges:
        ch[e["parent"]].append(e)
    return ch


def hierarchy_tree(res: DiscoveryResult, top: str, _depth: int = 0, _seen=None) -> list[tuple[int, str, str, str]]:
    """Depth-first (depth, instance, module, evidence) list rooted at *top*."""
    _seen = _seen or set()
    out = [(0, top, top, res.units.get(top, {}).get("file", "?"))] if _depth == 0 else []
    ch = children_of(res)
    for e in ch.get(top, []):
        out.append((_depth + 1, e["instance"], e["child"], e["evidence"]))
        if e["child"] not in _seen:
            out.extend(hierarchy_tree(res, e["child"], _depth + 1, _seen | {top}))
    return out


def roots(res: DiscoveryResult, origin: str | None = None) -> list[str]:
    """Modules never instantiated by another module (candidate tops)."""
    instantiated = {e["child"] for e in res.edges}
    return sorted(k for k, u in res.units.items()
                  if u["kind"] == "module" and k not in instantiated
                  and (origin is None or u["origin"] == origin))


# ---------------------------------------------------------------------------
# Yosys cross-check
# ---------------------------------------------------------------------------

def yosys_hierarchy(yosys: str, files: list[Path], top: str, incdirs: list[Path], frontend: str = "read_verilog -sv",
                    defines: list[str] | None = None, timeout: int = 600) -> dict:
    """Elaborate *top* with Yosys and return the instance hierarchy it reports.

    Returns ``{"ok": bool, "modules": {module: [(cell, type), ...]}, "log": str}``.
    """
    inc = " ".join(f"-I{d}" for d in incdirs)
    dfs = " ".join(f"-D{d}" for d in (defines or []))
    if frontend.startswith("read_slang"):
        reads = f"{frontend} {dfs} {inc} " + " ".join(str(f) for f in files)
    else:
        reads = "; ".join(f"{frontend} {dfs} {inc} {f}" for f in files)
    # JSON on stdout gives a robust, version-independent parse.
    script = f"{reads}; hierarchy -check -top {top}; write_json -compat-int -"
    try:
        p = subprocess.run([yosys, "-q", "-p", script], capture_output=True, text=True, timeout=timeout)
    except Exception as exc:
        return {"ok": False, "modules": {}, "log": str(exc)}
    if p.returncode != 0:
        return {"ok": False, "modules": {}, "log": (p.stdout + p.stderr)[-4000:]}
    txt = p.stdout
    start = txt.find("{")
    try:
        data = json.loads(txt[start:])
    except Exception as exc:
        return {"ok": False, "modules": {}, "log": f"json parse: {exc}\n{txt[-2000:]}"}
    mods = {}
    for mname, m in data.get("modules", {}).items():
        cells = []
        for cname, c in m.get("cells", {}).items():
            if not c["type"].startswith("$"):
                cells.append((cname, c["type"]))
        mods[mname] = cells
    return {"ok": True, "modules": mods, "log": ""}


def crosscheck(res: DiscoveryResult, top: str, yosys_mods: dict) -> dict:
    """Compare scanner-derived instance edges with Yosys-elaborated cells."""
    def base(n: str) -> str:
        # Yosys names parameterised modules "$paramod\\vector_engine\\LANES=..."
        n = n.lstrip("\\")
        if n.startswith("$paramod"):
            parts = n.split("\\")
            return parts[1] if len(parts) > 1 else n
        # yosys-slang --keep-hierarchy names per-instance modules "<module>$<path>"
        return n.split("@")[0].split("$")[0]

    yos_edges = set()
    for m, cells in yosys_mods.items():
        for cname, ctype in cells:
            inst = cname.lstrip("\\").split(".")[-1]
            yos_edges.add((base(m), base(ctype), inst.split("[")[0] if "[" not in inst else inst))
    scan_edges = set()
    reach = {t[2] for t in hierarchy_tree(res, top)}
    for e in res.edges:
        if e["parent"] in reach:
            scan_edges.add((base(e["parent"]), base(e["child"]), e["instance"]))
    # Instance names from generate loops are prefixed by Yosys (g_tiles[0].u_tile).
    def norm(edges):
        return {(p, c) for p, c, _ in edges}
    ys, ss = norm(yos_edges), norm(scan_edges)
    from collections import Counter
    counts = Counter((p, c) for p, c, _ in yos_edges)
    return {
        "yosys_instance_counts": {f"{p}->{c}": n for (p, c), n in sorted(counts.items())},
        "top": top,
        "edges_scanner": sorted(map(list, ss)),
        "edges_yosys": sorted(map(list, ys)),
        "only_in_scanner": sorted(map(list, ss - ys)),
        "only_in_yosys": sorted(map(list, ys - ss)),
        "agree": ss == ys,
    }


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

def write_dot(res: DiscoveryResult, path: Path, origin_filter: str | None = None, title: str = "") -> None:
    keep = {k for k, u in res.units.items() if origin_filter is None or origin_filter in u["origin"]}
    lines = ["digraph silicaflux {", '  rankdir=LR; node [shape=box, fontname="DejaVu Sans Mono", fontsize=10];',
             f'  label="{title}"; labelloc=t;']
    for k in sorted(keep):
        u = res.units[k]
        shape = "box" if u["kind"] == "module" else "note"
        n_ff = sum(1 for b in u["blocks"] if b["edges"])
        lines.append(f'  "{k}" [shape={shape}, label="{u["name"]}\\n{Path(u["file"].split("::")[-1]).name}\\nseq blocks: {n_ff}"];')
    for e in res.edges:
        if e["parent"] in keep and e["child"] in keep:
            lines.append(f'  "{e["parent"]}" -> "{e["child"]}" [label="{e["instance"]}", fontsize=8];')
    for e in res.package_edges:
        if e["unit"] in keep and e["resolved"] in keep:
            lines.append(f'  "{e["unit"]}" -> "{e["resolved"]}" [style=dashed, color=gray50, arrowhead=empty];')
    lines.append("}")
    path.write_text("\n".join(lines) + "\n")


def render_svg(dot_path: Path) -> Path | None:
    exe = shutil.which("dot")
    if not exe:
        return None
    svg = dot_path.with_suffix(".svg")
    subprocess.run([exe, "-Tsvg", str(dot_path), "-o", str(svg)], check=False)
    return svg if svg.exists() else None
