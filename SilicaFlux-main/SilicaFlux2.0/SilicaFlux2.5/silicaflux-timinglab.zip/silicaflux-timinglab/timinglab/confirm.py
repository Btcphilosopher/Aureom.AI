"""Confirm or refute RTL timing-risk hypotheses with synthesis + STA evidence.

Link between the two worlds: sequential cells keep their Yosys ``src``
attribute through flip-flop mapping, so every STA start/end point register can
be traced to an RTL line (``ff_src_map.json`` written by the synthesis step).

Statuses
--------
confirmed            an STA path ending at the hypothesised RTL register line is
                     among the most critical paths (rank < 5, or slack within
                     10 % of the clock period of the worst path)
refuted              registers from that RTL line exist in the netlist, but their
                     worst STA path is not critical
not-observable       no register from that RTL line survived synthesis
unverified           category not checkable by path analysis (fanout, CDC, ...)
The reverse direction is also reported: critical STA paths whose endpoint line
no hypothesis named ("missed_by_audit"), so the audit's recall is visible.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

from .report.model import final_stage, stage_data

PATH_CATS = ("critical_path", "arithmetic_chain")


def _inst(pin: str) -> str:
    return pin.rsplit("/", 1)[0] if "/" in pin else pin


def confirm(audit: dict, run: dict, stage: str = "grt", top_k: int = 5, rel_window: float = 0.10) -> dict:
    rundir = Path(run["rundir"])
    ffmap = {}
    mp = rundir / "ff_src_map.json"
    if mp.exists():
        ffmap = json.loads(mp.read_text())
    d = stage_data(run, stage)
    used_stage = stage
    if not d:
        used_stage, d = final_stage(run)
    period = float(run.get("period_ns") or 0.0)
    paths = sorted([p for p in (d or {}).get("paths_max", []) if p.get("slack") is not None],
                   key=lambda p: p["slack"])
    for p in paths:
        p["_ep_src"] = ffmap.get(_inst(p["endpoint"]))
        p["_sp_src"] = ffmap.get(_inst(p["startpoint"]))
    worst = paths[0]["slack"] if paths else None
    src_lines = set(ffmap.values())

    res = copy.deepcopy(audit)
    res.update({"design": audit.get("design") or run.get("design"), "pdk": run.get("pdk"),
                "stage": used_stage, "period_ns": period, "worst_slack": worst})
    named = set()
    for f in res["findings"]:
        if f["category"] not in PATH_CATS:
            f["status"] = "unverified"
            continue
        ep = f.get("endpoint_src") or ""
        named.add(ep)
        hits = [(i, p) for i, p in enumerate(paths) if p["_ep_src"] == ep]
        if hits:
            i, p = hits[0]
            close = worst is not None and (p["slack"] - worst) <= rel_window * period
            f["status"] = "confirmed" if (i < top_k or close) else "refuted"
            f["sta_evidence"] = (f"{used_stage}: STA rank {i + 1}/{len(paths)}, slack {p['slack']:.3f} ns "
                                 f"(worst {worst:.3f}), logic depth {p['logic_depth']}, "
                                 f"data delay {p['data_delay']:.3f} ns, endpoint {p['endpoint']}")
            f["sta_rank"] = i + 1
            f["sta_slack"] = p["slack"]
        elif ep in src_lines:
            f["status"] = "refuted"
            f["sta_evidence"] = f"{used_stage}: registers from {ep} exist but are not in the top {len(paths)} STA paths"
        else:
            f["status"] = "not-observable"
            f["sta_evidence"] = f"no register from {ep} survived synthesis"
    missed = []
    for i, p in enumerate(paths[:top_k]):
        if p["_ep_src"] and p["_ep_src"] not in named:
            missed.append({"sta_rank": i + 1, "slack": p["slack"], "endpoint": p["endpoint"],
                           "endpoint_src": p["_ep_src"], "startpoint_src": p["_sp_src"], "group": p["group"]})
    res["missed_by_audit"] = missed
    res["sta_top_paths"] = [{"rank": i + 1, "slack": p["slack"], "group": p["group"],
                             "endpoint_src": p["_ep_src"], "startpoint_src": p["_sp_src"],
                             "logic_depth": p["logic_depth"], "data_delay": p["data_delay"]}
                            for i, p in enumerate(paths[:10])]
    return res
