# =============================================================================
# SilicaFlux TimingLab — common timing report procedure.
# Sourced by flow/sta/sta.tcl (OpenSTA) and flow/openroad/pnr.tcl (OpenROAD),
# so every stage produces the same set of text reports, parsed by
# timinglab/parsers/sta_text.py. Works with OpenSTA 2.x (inside OpenROAD,
# which spells the path-count flags -group_count / -endpoint_count) and 3.x
# (-group_path_count / -endpoint_path_count).
# =============================================================================
proc tl_flags {} {
  if {[info exists ::tl_flag_cache]} { return $::tl_flag_cache }
  if {[catch {report_checks -path_delay max -group_path_count 1 -endpoint_path_count 1 > /dev/null}]} {
    set ::tl_flag_cache {-group_count -endpoint_count}
  } else {
    set ::tl_flag_cache {-group_path_count -endpoint_path_count}
  }
  return $::tl_flag_cache
}

proc tl_try {args} {
  # Run a report command; on failure retry without -digits (older versions).
  if {[catch {uplevel 1 $args} err]} {
    set idx [lsearch -exact $args -digits]
    if {$idx >= 0} {
      set a2 [lreplace $args $idx [expr {$idx + 1}]]
      if {[catch {uplevel 1 $a2} err2]} { puts "TL-WARN: $a2: $err2" }
    } else {
      puts "TL-WARN: $args: $err"
    }
  }
}

proc tl_reports {outdir {npaths 50}} {
  file mkdir $outdir
  lassign [tl_flags] gflag eflag
  set fields {input_pins slew cap fanout nets}

  report_checks -path_delay max $gflag $npaths $eflag 1 \
      -fields $fields -digits 4 > $outdir/paths_max.rpt
  report_checks -path_delay min $gflag [expr {$npaths / 2}] $eflag 1 \
      -fields $fields -digits 4 > $outdir/paths_min.rpt
  report_checks -path_delay max $gflag 1000000 $eflag 1 \
      -slack_max 0 -format end -digits 4 > $outdir/viol_max.rpt
  report_checks -path_delay min $gflag 1000000 $eflag 1 \
      -slack_max 0 -format end -digits 4 > $outdir/viol_min.rpt
  # Unconstrained endpoints are a constraint-coverage problem: list a sample.
  report_checks -unconstrained -path_delay max $gflag 5 -format end > $outdir/unconstrained.rpt

  tl_try report_worst_slack -max -digits 4 >  $outdir/summary.rpt
  tl_try report_worst_slack -min -digits 4 >> $outdir/summary.rpt
  tl_try report_wns -digits 4 >> $outdir/summary.rpt
  tl_try report_tns -digits 4 >> $outdir/summary.rpt

  tl_try report_clock_skew -setup -digits 4 >  $outdir/skew.rpt
  tl_try report_clock_skew -hold  -digits 4 >> $outdir/skew.rpt
  tl_try report_check_types -max_slew -max_capacitance -max_fanout -violators > $outdir/drv.rpt
  tl_try report_power > $outdir/power.rpt
  puts "TL-REPORT: wrote $outdir"
}
