# =============================================================================
# SilicaFlux TimingLab — standalone OpenSTA run on a synthesised netlist.
# Inputs (environment): TL_LIBS (space separated), TL_NETLIST, TL_TOP, TL_SDC,
#                       TL_OUTDIR, TL_NPATHS. Clock budgets: see constraints/.
# Wires are ideal (no parasitics) at this stage; nets are NOT yet buffered, so
# max-fanout nets show unrealistic slews — the placed stage (OpenROAD
# repair_design) is the first stage whose numbers are physically meaningful.
# =============================================================================
source [file join $::env(TL_FLOW_DIR) sta tl_report.tcl]

foreach lib $::env(TL_LIBS) { read_liberty $lib }
read_verilog $::env(TL_NETLIST)
link_design $::env(TL_TOP)
read_sdc $::env(TL_SDC)

set npaths 50
if {[info exists ::env(TL_NPATHS)]} { set npaths $::env(TL_NPATHS) }
tl_reports $::env(TL_OUTDIR) $npaths

# Machine-readable copy of the worst paths (OpenSTA >= 2.6 supports json).
if {[catch {report_checks -path_delay max -group_path_count 20 -endpoint_path_count 1 \
              -format json > $::env(TL_OUTDIR)/paths_max.json} err]} {
  puts "TL-INFO: json path report unavailable in this OpenSTA: $err"
}
exit
