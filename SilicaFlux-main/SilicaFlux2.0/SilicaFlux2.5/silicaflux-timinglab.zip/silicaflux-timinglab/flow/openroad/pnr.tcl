# =============================================================================
# SilicaFlux TimingLab — OpenROAD placement / CTS / global-route experiment.
#
# Purpose: obtain *physically meaningful* timing (buffered high-fanout nets,
# placement-based and global-route-based wire parasitics, propagated clock
# skew) and routing-congestion evidence for a synthesised block. This is a
# timing experiment, not a sign-off flow: no PDN, no detailed routing, no
# extraction. Settings are identical for "before" and "after" RTL so that
# comparisons isolate the RTL change.
#
# Environment (set by timinglab/flow/pnr.py):
#   TL_TECH_LEF TL_SC_LEFS TL_LIBS TL_NETLIST TL_TOP TL_SDC TL_OUTDIR
#   TL_PLATFORM_DIR TL_SITE TL_UTIL TL_DENSITY TL_IO_H TL_IO_V
#   TL_MIN_LAYER TL_MAX_LAYER TL_MAKE_TRACKS TL_SET_RC TL_TAPCELL
#   TL_REPAIR_TIMING (0/1) TL_CTS_BUFS (optional) TL_NPATHS
# =============================================================================
source [file join $::env(TL_FLOW_DIR) sta tl_report.tcl]
proc tl_to_file {path args} {
  # Redirect the stdout of an OpenROAD (non-STA) report command to a file.
  sta::redirect_file_begin $path
  if {[catch {uplevel 1 $args} err]} { puts "TL-WARN: $args: $err" }
  sta::redirect_file_end
}
proc env_or {k d} { if {[info exists ::env($k)] && $::env($k) ne ""} { return $::env($k) }; return $d }
set out $::env(TL_OUTDIR)
file mkdir $out
set npaths [env_or TL_NPATHS 50]

read_lef $::env(TL_TECH_LEF)
foreach l $::env(TL_SC_LEFS) { read_lef $l }
foreach l $::env(TL_LIBS)    { read_liberty $l }
read_verilog $::env(TL_NETLIST)
link_design $::env(TL_TOP)
read_sdc $::env(TL_SDC)
if {[env_or TL_SET_RC ""] ne ""} { source $::env(TL_SET_RC) }

# ---------------- floorplan ----------------
if {[env_or TL_CORE_SIDE ""] ne ""} {
  # Pin-limited block: die sized from the I/O count (see timinglab/flow/pnr.py)
  set side $::env(TL_CORE_SIDE)
  initialize_floorplan -die_area [list 0 0 [expr {$side + 8}] [expr {$side + 8}]] \
                       -core_area [list 4 4 [expr {$side + 4}] [expr {$side + 4}]] -site $::env(TL_SITE)
} else {
  initialize_floorplan -utilization $::env(TL_UTIL) -aspect_ratio 1.0 -core_space 4 -site $::env(TL_SITE)
}
if {[env_or TL_MAKE_TRACKS ""] ne ""} { source $::env(TL_MAKE_TRACKS) } else { make_tracks }
if {[env_or TL_TAPCELL ""] ne ""} { source $::env(TL_TAPCELL) }
place_pins -hor_layers $::env(TL_IO_H) -ver_layers $::env(TL_IO_V) -random -min_distance 1 -min_distance_in_tracks
set_routing_layers -signal $::env(TL_MIN_LAYER)-$::env(TL_MAX_LAYER)

# ---------------- placement + electrical repair ----------------
global_placement -density $::env(TL_DENSITY) -skip_io
estimate_parasitics -placement
repair_design
if {[env_or TL_REPAIR_TIMING 0]} { repair_timing -setup }
detailed_placement
check_placement -verbose
estimate_parasitics -placement
tl_to_file $out/area_place.rpt report_design_area
tl_reports $out/place $npaths

# ---------------- clock tree ----------------
set cts_args {-sink_clustering_enable}
if {[env_or TL_CTS_BUFS ""] ne ""} {
  lappend cts_args -buf_list $::env(TL_CTS_BUFS) -root_buf [lindex $::env(TL_CTS_BUFS) end]
}
clock_tree_synthesis {*}$cts_args
set_propagated_clock [all_clocks]
estimate_parasitics -placement
repair_design
detailed_placement
estimate_parasitics -placement
tl_to_file $out/cts.rpt report_cts
tl_reports $out/cts $npaths

# ---------------- global route ----------------
set grt_args [list -congestion_report_file $out/congestion.rpt -allow_congestion -verbose]
if {[env_or TL_GRT_ITERS ""] ne ""} { lappend grt_args -congestion_iterations $::env(TL_GRT_ITERS) }
global_route {*}$grt_args
estimate_parasitics -global_routing
tl_to_file $out/area_grt.rpt report_design_area
tl_reports $out/grt $npaths
write_def $out/grt.def
puts "TL-PNR: done"
exit
