# Sample reports

Outputs of the run documented in `docs/RESULTS.md` (2-core cloud VM, tools as listed in
`docs/TOOLING.md`). Regenerate with `make all` (or the individual commands in the
top-level README).

| Directory | Produced by | Contents |
|---|---|---|
| `discovery/` | `timinglab discover --yosys-crosscheck` | `discovery.json` (inventory with SHA-256, design units, instantiation edges with `file:line`, Yosys cross-check), dependency graphs (`.dot`, `.svg`) |
| `audit/<design>/rtl_audit.json` | `timinglab audit --all` | RTL timing-risk hypotheses (schema `silicaflux-timinglab/rtl-audit/v1`), the Yosys script and log used |
| `audit/<design>/confirmed_<pdk>.json` | `timinglab.regress confirm` | the same findings with `confirmed` / `refuted` / `not-observable` / `unverified` status and STA evidence |
| `runs/<pdk>/<design>/` | `timinglab run` (curated by `scripts/package.py`) | `result.json` (every parsed number, compacted), `ff_src_map.json`, synthesis script and statistics, OpenSTA/OpenROAD logs, per-stage summary / skew / power reports, DRV reports (first 50 rows per section) and the 2 worst paths per group as text |
| `dashboard/` | `timinglab report` | `dashboard.html` (self-contained), `summary.csv`, `critical_paths.csv`, `comparisons.csv`, `audit_calibration.csv`, `timinglab_results.json` |
| `regression/` | `timinglab.regress …` | equivalence, findings, formal, upstream-simulation and PPA-gate results as JSON |

Compaction rules (`scripts/package.py`): in `result.json` every reported path keeps its
summary metrics (slack, arrival, depth, delays, skew, fan-out, congestion hits, start and
end points verbatim); the worst path of each group also keeps its per-pin stages and
ranks 2–3 their cell lists; net lists are reduced to a count. Flattened, auto-named nets
can be kilobytes long, so names over 160 characters inside stages and text reports are
abbreviated as `prefix...[<length>c:<sha1-8>]...suffix`. Full, uncompacted reports are
regenerated in `runs/` by the flow (up to ~50 MB per design). `make report
RUNS=reports/runs` rebuilds the dashboard from the curated records.
