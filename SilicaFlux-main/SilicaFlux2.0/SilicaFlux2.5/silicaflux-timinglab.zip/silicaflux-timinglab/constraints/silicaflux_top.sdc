# =============================================================================
# SilicaFlux TimingLab — ASIC constraints for silicaflux_top (SilicaFlux v1.0)
#
# Replaces nothing in upstream/: the FPGA SDC (upstream/silicaflux/synth/
# silicaflux.sdc) is left untouched. Differences and their justification are in
# docs/CONSTRAINTS.md. Summary of deliberate changes vs. the FPGA SDC:
#
#  * rst_n is NOT a false path. It drives asynchronous clear/set pins directly
#    (no reset synchroniser exists in the RTL — audit finding RDC-001), so its
#    de-assertion is timed via recovery/removal checks.
#  * The multicycle path on imem_wr_data -> u_fetch/imem is REMOVED: nothing in
#    fetch_unit.sv restricts imem writes to reset (imem is written whenever
#    imem_wr_en=1, fetch_unit.sv:78-81), so there is no functional evidence for it.
#  * The false paths on the tile_interface "synchroniser" first stages are
#    REMOVED in the default (mesochronous) scenario: the RTL has a single clock,
#    so these flops are ordinary retiming stages and must be timed. The
#    asynchronous-PHY scenario below models the alternative explicitly.
#  * One multicycle path is ADDED, backed by a formal proof
#    (formal/tensor_unit_mcp.sv): tensor_unit operand registers A_flat/B_flat ->
#    accumulator C_flat, setup 2 / hold 1.
# =============================================================================
source [file join $::env(TL_CONSTRAINTS_DIR) tl_common.tcl]

tl_core_clock

# ---------------------------------------------------------------------------
# Reset — timed (recovery/removal). Budget: reset comes from an on-board
# supervisor/PLL-lock generator synchronous to clk.
# ---------------------------------------------------------------------------
if {$tl_rst_port ne ""} {
  tl_io [get_ports $tl_rst_port] $tl_in_frac $tl_out_frac
}

# ---------------------------------------------------------------------------
# Program-load interface (imem_wr_en / imem_wr_addr / imem_wr_data).
# External loader (debug bridge / boot DMA) launches on core_clk.
# ---------------------------------------------------------------------------
tl_io [get_ports {imem_wr_en imem_wr_addr* imem_wr_data*}] [tl_env TL_PROG_IN_FRAC 0.40] $tl_out_frac

# ---------------------------------------------------------------------------
# Chiplet die-to-die link (tile_interface u_tif, LINK_WIDTH = 8).
# Scenario selected by TL_PHY_MODE:
#   meso  (default) — link is mesochronous/source-synchronous with core_clk:
#                     die-to-die flight + PHY consume TL_PHY_FRAC of the cycle.
#   async            — far die runs on an unrelated clock. Only the single-bit
#                     qualifier phy_rx_valid may cross through the 2-FF chain;
#                     phy_rx_data is a multi-bit bus and is NOT made safe by any
#                     constraint (audit CDC finding). We bound its bit-to-bit
#                     skew with set_max_delay -datapath_only instead of hiding it.
# ---------------------------------------------------------------------------
set tl_phy_mode [tl_env TL_PHY_MODE meso]
set tl_phy_frac [tl_env TL_PHY_FRAC 0.50]
set phy_rx [get_ports {tile_phy_rx_data* tile_phy_rx_valid tile_phy_tx_credit}]
set phy_tx [get_ports {tile_phy_tx_data* tile_phy_tx_valid tile_phy_rx_credit}]
if {$tl_phy_mode eq "async"} {
  set phy_period [tl_env TL_PHY_PERIOD $tl_period]
  create_clock -name phy_clk -period $phy_period
  set_clock_groups -asynchronous -group [get_clocks core_clk] -group [get_clocks phy_clk]
  set_input_delay  -max [expr {0.5 * $phy_period}] -clock phy_clk $phy_rx
  set_input_delay  -min 0.0                        -clock phy_clk $phy_rx
  set_output_delay -max [expr {0.5 * $phy_period}] -clock phy_clk $phy_tx
  set_output_delay -min 0.0                        -clock phy_clk $phy_tx
  set_max_delay -datapath_only $phy_period -from [get_ports {tile_phy_rx_data* tile_phy_rx_valid}]
} else {
  tl_io $phy_rx $tl_phy_frac $tl_phy_frac
  tl_io $phy_tx $tl_phy_frac $tl_phy_frac
}

# ---------------------------------------------------------------------------
# Status / debug outputs (halt, debug_scalar_r1) — observed by a tester or
# debug bridge clocked by core_clk.
# ---------------------------------------------------------------------------
tl_io [get_ports {halt debug_scalar_r1*}] $tl_in_frac $tl_out_frac

# ---------------------------------------------------------------------------
# Multicycle path with functional evidence (formal/tensor_unit_mcp.sv):
#   A_flat/B_flat load only in IDLE&&start; the FSM then spends exactly one
#   cycle in LOAD before CALC, and C_flat is written only in CALC. Hence data
#   launched into A_flat/B_flat is captured by C_flat no earlier than 2 edges
#   later. Paths from the row/col/k counters (mux selects) remain single-cycle.
# ---------------------------------------------------------------------------
if {[tl_env TL_ENABLE_MCP 1]} {
  set mcp_from [tl_cells {.*u_tensor\.(A_flat|B_flat).*}]
  set mcp_to   [tl_cells {.*u_tensor\.C_flat.*}]
  if {[llength $mcp_from] && [llength $mcp_to]} {
    set_multicycle_path -setup 2 -from $mcp_from -to $mcp_to
    set_multicycle_path -hold  1 -from $mcp_from -to $mcp_to
  }
}

# ---------------------------------------------------------------------------
# Generated clocks: none. The RTL has exactly one clock net (audit
# CLOCK_DOMAIN-001); no dividers, gaters or forwarded clocks exist.
# False paths: none (see header).
# ---------------------------------------------------------------------------
tl_path_groups
