# =============================================================================
# SilicaFlux TimingLab — generic block-level constraints
#
# Used for leaf-block experiments (tensor_unit, vector_engine, control_core, ...).
# Only reg->reg paths (group "reg2reg") are architectural; in2reg / reg2out /
# in2out results depend on the TL_IN_FRAC / TL_OUT_FRAC budgets, which model the
# neighbouring block consuming 30 % of the cycle by default.
#
# Exceptions: none. Reset is a timed input (recovery/removal are checked).
# =============================================================================
source [file join $::env(TL_CONSTRAINTS_DIR) tl_common.tcl]

tl_core_clock

set tl_data_ports [delete_from_list [all_inputs] [get_ports $tl_clk_port]]
tl_io $tl_data_ports $tl_in_frac $tl_out_frac
tl_io [all_outputs]  $tl_in_frac $tl_out_frac

tl_path_groups
