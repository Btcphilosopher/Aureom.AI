# =============================================================================
# SilicaFlux TimingLab — shared SDC helpers (sourced by every *.sdc here)
#
# All numeric budgets come from environment variables set by the TimingLab
# flow driver (timinglab/flow/*.py) so the *same* SDC is valid for every PDK:
#
#   TL_CLOCK_PERIOD   core clock period [ns]                       (required)
#   TL_CLOCK_PORT     clock port name                              (default clk)
#   TL_RESET_PORT     reset port name, "" if none                  (default rst_n)
#   TL_UNC_SETUP      setup uncertainty as fraction of period      (default 0.05)
#   TL_UNC_HOLD       hold uncertainty [ns]                        (default 0.05)
#   TL_CLK_SLEW       ideal clock transition [ns], pre-CTS only    (default 0.15)
#   TL_IN_FRAC        input  delay budget as fraction of period    (default 0.30)
#   TL_OUT_FRAC       output delay budget as fraction of period    (default 0.30)
#   TL_DRIVER_CELL / TL_DRIVER_PIN   lib cell driving inputs       (PDK specific)
#   TL_LOAD_PF        load on every output [pF]                    (default 0.01)
#   TL_PROPAGATED     1 after CTS: use propagated clock latency    (default 0)
# =============================================================================

proc tl_env {name default} {
  if {[info exists ::env($name)] && $::env($name) ne ""} { return $::env($name) }
  return $default
}

proc tl_cells {pattern} {
  # Regexp match on (flattened) cell names. Returns {} with a warning when the
  # pattern matches nothing, so no exception is ever silently applied to nothing.
  set c [get_cells -quiet -regexp $pattern]
  if {[llength $c] == 0} {
    puts "TL-SDC-WARN: pattern '$pattern' matched no cells; exception skipped"
  }
  return $c
}

set tl_period   [tl_env TL_CLOCK_PERIOD ""]
if {$tl_period eq ""} { error "TL_CLOCK_PERIOD must be set" }
set tl_clk_port [tl_env TL_CLOCK_PORT clk]
set tl_rst_port [tl_env TL_RESET_PORT rst_n]
set tl_unc_s    [expr {[tl_env TL_UNC_SETUP 0.05] * $tl_period}]
set tl_unc_h    [tl_env TL_UNC_HOLD 0.05]
set tl_clk_slew [tl_env TL_CLK_SLEW 0.15]
set tl_in_frac  [tl_env TL_IN_FRAC 0.30]
set tl_out_frac [tl_env TL_OUT_FRAC 0.30]
set tl_load     [tl_env TL_LOAD_PF 0.01]

proc tl_core_clock {} {
  global tl_period tl_clk_port tl_unc_s tl_unc_h tl_clk_slew
  create_clock -name core_clk -period $tl_period [get_ports $tl_clk_port]
  # Pre-CTS: uncertainty covers expected skew + jitter. Post-CTS the flow sets
  # TL_PROPAGATED=1 and real skew is taken from the clock tree instead.
  set_clock_uncertainty -setup $tl_unc_s [get_clocks core_clk]
  set_clock_uncertainty -hold  $tl_unc_h [get_clocks core_clk]
  if {[tl_env TL_PROPAGATED 0]} {
    set_propagated_clock [get_clocks core_clk]
  } else {
    set_clock_transition $tl_clk_slew [get_clocks core_clk]
  }
}

proc tl_io {ports in_frac out_frac} {
  # Apply input or output budgets to a port collection.
  global tl_period
  set ins  {}
  set outs {}
  foreach p $ports {
    set dir [get_property $p direction]
    if {$dir eq "input"} { lappend ins $p } else { lappend outs $p }
  }
  if {[llength $ins]} {
    set_input_delay  -max [expr {$in_frac * $tl_period}] -clock core_clk $ins
    set_input_delay  -min 0.0                            -clock core_clk $ins
    set drv [tl_env TL_DRIVER_CELL ""]
    if {$drv ne ""} { set_driving_cell -lib_cell $drv -pin [tl_env TL_DRIVER_PIN X] $ins }
  }
  if {[llength $outs]} {
    set_output_delay -max [expr {$out_frac * $tl_period}] -clock core_clk $outs
    set_output_delay -min 0.0                             -clock core_clk $outs
    set_load [tl_env TL_LOAD_PF 0.01] $outs
  }
}

proc tl_path_groups {} {
  # Separate reg->reg (RTL architecture) from I/O paths (budget assumptions).
  set regs [all_registers]
  set ins  [all_inputs]
  set outs [all_outputs]
  group_path -name reg2reg -from $regs -to $regs
  group_path -name in2reg  -from $ins  -to $regs
  group_path -name reg2out -from $regs -to $outs
  group_path -name in2out  -from $ins  -to $outs
}
