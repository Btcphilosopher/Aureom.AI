# =============================================================================
# SilicaFlux TimingLab — tensor_unit block constraints
# Generic block budgets + the formally proven operand-register multicycle path
# (formal/tensor_unit_mcp.sv). Set TL_ENABLE_MCP=0 to measure without it.
# =============================================================================
source [file join $::env(TL_CONSTRAINTS_DIR) block_generic.sdc]

if {[tl_env TL_ENABLE_MCP 1]} {
  # Register sets are identified structurally (names are not stable after
  # flattening/technology mapping):
  #   from = A_flat/B_flat : every register loaded from mat_a_row*/mat_b_col*
  #   to   = C_flat        : every register driving result_row*
  set mcp_from [get_fanout -from [get_ports {mat_a_row* mat_b_col*}] -endpoints_only -only_cells -flat]
  set mcp_to   [get_fanin  -to   [get_ports {result_row*}] -startpoints_only -only_cells -flat]
  puts "TL-SDC: tensor MCP from [llength $mcp_from] operand registers to [llength $mcp_to] accumulator registers"
  if {[llength $mcp_from] && [llength $mcp_to]} {
    set_multicycle_path -setup 2 -from $mcp_from -to $mcp_to
    set_multicycle_path -hold  1 -from $mcp_from -to $mcp_to
  }
}
