// =============================================================================
// SilicaFlux TimingLab — pipelined vector engine (drop-in for vector_engine)
// rtl/opt/sf_vector_engine_pipe.sv
//
// Same ports and operation semantics as upstream vector_engine.sv:
//   lane op   VADD a+b | VSUB a-b | VMUL a*b (low 32) | DOT a*b | BCAST scalar_in
//             | any other opcode: a
//   reduce    DOT / REDUCE reduce the lane results with func[1:0]
//             (SUM / signed MIN / signed MAX / AND), pairing (2i, 2i+1) per level
//   outputs   VADD/VSUB/VMUL/BCAST/other: vresult=lanes, scalar=0, is_scalar=0
//             DOT/REDUCE: vresult=0, scalar=reduction, is_scalar=1
// Like upstream, the pipeline evaluates every cycle; result_valid is
// issue_valid delayed by LATENCY. Upstream LATENCY is 1, this unit's is 3
// (+ tree stages for LANES >= 8 when TREE_LEVELS_PER_STAGE > 0).
//
//   S1  per-lane partial products (16x16 multipliers) or add/sub/bcast/pass
//   S2  combine partial products + first reduction level
//   S3  remaining reduction levels + output select           (output registers)
//
// Intentional difference: for LANES = 16 upstream reduces only lanes 0..7
// (vector_engine.sv:143-144 "simplified" drops reduce_lvl2[2..3]); this unit
// reduces all lanes. For LANES = 4 and 8 results are identical to upstream.
// =============================================================================
`include "silicaflux_pkg.sv"

module sf_vector_engine_pipe
  import silicaflux_pkg::*;
#(
  parameter int LANES                 = LANES_DEFAULT,
  parameter int TREE_LEVELS_PER_STAGE = 0
) (
  input  logic                   clk,
  input  logic                   rst_n,
  input  logic                   issue_valid,
  input  logic [4:0]             opcode,
  input  logic [7:0]             func,
  input  logic [LANES*XLEN-1:0]  vop_a,
  input  logic [LANES*XLEN-1:0]  vop_b,
  input  logic [XLEN-1:0]        scalar_in,
  output logic                   result_valid,
  output logic [LANES*XLEN-1:0]  vresult,
  output logic [XLEN-1:0]        scalar_result,
  output logic                   is_scalar_result
);
  localparam int H = XLEN / 2;
  localparam int HALF = (LANES > 1) ? LANES / 2 : 1;

  function automatic logic [XLEN-1:0] reduce_pair(input logic [XLEN-1:0] a, input logic [XLEN-1:0] b,
                                                  input reduce_op_t op);
    case (op)
      REDUCE_SUM: return a + b;
      REDUCE_MIN: return ($signed(a) < $signed(b)) ? a : b;
      REDUCE_MAX: return ($signed(a) > $signed(b)) ? a : b;
      REDUCE_AND: return a & b;
      default:    return a + b;
    endcase
  endfunction

  // ------------------------------------------------------------------- S1
  logic [LANES*XLEN-1:0] s1_ll;
  logic [LANES*H-1:0]    s1_mid;
  logic [4:0]            s1_op;
  logic [7:0]            s1_func;
  logic                  s1_v;

  for (genvar i = 0; i < LANES; i++) begin : g_lane
    logic [XLEN-1:0] a, b, ll, ll_c;
    logic [H-1:0]    mid, mid_c;
    assign a = vop_a[i*XLEN +: XLEN];
    assign b = vop_b[i*XLEN +: XLEN];
    sf_mul_lo_pp #(.W(XLEN)) u_pp (.a(a), .b(b), .pp_ll(ll), .pp_mid(mid));
    always_comb begin
      mid_c = '0;
      case (opcode)
        OP_VADD:         ll_c = a + b;
        OP_VSUB:         ll_c = a - b;
        OP_VMUL, OP_DOT: begin ll_c = ll; mid_c = mid; end
        OP_BCAST:        ll_c = scalar_in;
        default:         ll_c = a;
      endcase
    end
    always_ff @(posedge clk) begin
      s1_ll [i*XLEN +: XLEN] <= ll_c;
      s1_mid[i*H    +: H]    <= mid_c;
    end
  end

  always_ff @(posedge clk) begin
    s1_op   <= opcode;
    s1_func <= func;
  end
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) s1_v <= 1'b0; else s1_v <= issue_valid;

  // ------------------------------------------------------------------- S2
  logic [LANES*XLEN-1:0] lane_c;
  logic [HALF*XLEN-1:0]  lvl1_c;
  logic [LANES*XLEN-1:0] s2_lane;
  logic [HALF*XLEN-1:0]  s2_lvl1;
  logic [4:0]            s2_op;
  logic [7:0]            s2_func;
  logic                  s2_v;

  for (genvar i = 0; i < LANES; i++) begin : g_comb
    sf_mul_lo_sum #(.W(XLEN)) u_sum (.pp_ll(s1_ll[i*XLEN +: XLEN]), .pp_mid(s1_mid[i*H +: H]),
                                    .p(lane_c[i*XLEN +: XLEN]));
  end
  if (LANES < 2 || (LANES & (LANES - 1)) != 0) begin : g_bad_lanes
    $error("sf_vector_engine_pipe: LANES must be a power of two >= 2");
  end
  always_comb begin
    for (int i = 0; i < HALF; i++)
      lvl1_c[i*XLEN +: XLEN] = reduce_pair(lane_c[(2*i)*XLEN +: XLEN], lane_c[(2*i+1)*XLEN +: XLEN],
                                           reduce_op_t'(s1_func[1:0]));
  end
  always_ff @(posedge clk) begin
    s2_lane <= lane_c;
    s2_lvl1 <= lvl1_c;
    s2_op   <= s1_op;
    s2_func <= s1_func;
  end
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) s2_v <= 1'b0; else s2_v <= s1_v;

  // ------------------------------------------------------------------- S3
  logic        t_v;
  reduce_op_t  t_op;
  logic [XLEN-1:0] t_sum;
  logic [LANES*XLEN-1:0] t_lane;
  logic [4:0]  t_opcode;

  sf_reduce_tree #(.N(HALF), .W(XLEN), .LEVELS_PER_STAGE(TREE_LEVELS_PER_STAGE)) u_tree (
    .clk(clk), .rst_n(rst_n), .in_valid(s2_v), .in_op(reduce_op_t'(s2_func[1:0])),
    .in_data(s2_lvl1), .out_valid(t_v), .out_op(t_op), .out_data(t_sum));

  // Opcode / lanes must stay aligned with the tree when it is pipelined.
  localparam int TREE_LAT = (TREE_LEVELS_PER_STAGE == 0 || HALF <= 1) ? 0
                            : (($clog2(HALF) + TREE_LEVELS_PER_STAGE - 1) / TREE_LEVELS_PER_STAGE) - 1;
  if (TREE_LAT == 0) begin : g_nodelay
    assign t_lane   = s2_lane;
    assign t_opcode = s2_op;
  end else begin : g_delay
    logic [LANES*XLEN-1:0] dl [TREE_LAT];
    logic [4:0]            dop[TREE_LAT];
    always_ff @(posedge clk) begin
      dl[0] <= s2_lane; dop[0] <= s2_op;
      for (int d = 1; d < TREE_LAT; d++) begin dl[d] <= dl[d-1]; dop[d] <= dop[d-1]; end
    end
    assign t_lane   = dl[TREE_LAT-1];
    assign t_opcode = dop[TREE_LAT-1];
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      result_valid     <= 1'b0;
      vresult          <= '0;
      scalar_result    <= '0;
      is_scalar_result <= 1'b0;
    end else begin
      result_valid <= t_v;
      case (t_opcode)
        OP_DOT, OP_REDUCE: begin
          vresult          <= '0;
          scalar_result    <= t_sum;
          is_scalar_result <= 1'b1;
        end
        default: begin
          vresult          <= t_lane;
          scalar_result    <= '0;
          is_scalar_result <= 1'b0;
        end
      endcase
    end
  end
endmodule
