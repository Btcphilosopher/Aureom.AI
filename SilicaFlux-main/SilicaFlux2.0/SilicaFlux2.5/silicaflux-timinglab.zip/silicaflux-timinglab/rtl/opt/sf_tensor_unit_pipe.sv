// =============================================================================
// SilicaFlux TimingLab — pipelined tensor unit (drop-in for tensor_unit)
// rtl/opt/sf_tensor_unit_pipe.sv
//
// Same ports and the same transaction semantics as upstream tensor_unit.sv:
//   * start is accepted only in IDLE; A/B are captured and C is cleared then
//   * result_row0..3 hold C = A x B (low 32 bits, wrap-around) from the cycle in
//     which done=1 until the next accepted start
//   * done is a 1-cycle pulse; busy falls in the same cycle done rises
//   * reset values identical (C=0, done=0, busy=0); A/B are not reset (as upstream)
//
// Timing changes (critical path in upstream: counter -> 16:1 operand mux ->
// 32x32 multiply -> 16:1 C mux + 32-bit add -> C demux, all in one cycle):
//   S1  operand select      counters -> 16:1 mux -> a_q/b_q            (register)
//   S2  partial products    16x16 multipliers  -> pp_ll/pp_mid          (register)
//   S3  accumulate          acc + pp_ll + pp_mid<<16 (3-input add)      (register)
//       C[row][col] is written once per element, when k == 3; the C read mux
//       of upstream disappears because the running sum lives in `acc`.
// Latency: upstream done appears 66 cycles after the start edge; this unit
// takes 67 (+1). Throughput is unchanged (one MAC per cycle). The tile FSM
// (compute_tile.sv:317-330) waits for done, so the extra cycle is absorbed by
// the existing start/done handshake.
// Observable difference: upstream exposes running partial sums on result_row*
// while busy; this unit exposes 0 or final element values. Neither is valid
// before done (compute_tile samples only on done).
// =============================================================================
`include "silicaflux_pkg.sv"

module sf_tensor_unit_pipe
  import silicaflux_pkg::*;
(
  input  logic              clk,
  input  logic              rst_n,
  input  logic              start,
  input  logic [4*XLEN-1:0] mat_a_row0,
  input  logic [4*XLEN-1:0] mat_a_row1,
  input  logic [4*XLEN-1:0] mat_a_row2,
  input  logic [4*XLEN-1:0] mat_a_row3,
  input  logic [4*XLEN-1:0] mat_b_col0,
  input  logic [4*XLEN-1:0] mat_b_col1,
  input  logic [4*XLEN-1:0] mat_b_col2,
  input  logic [4*XLEN-1:0] mat_b_col3,
  output logic              done,
  output logic              busy,
  output logic [4*XLEN-1:0] result_row0,
  output logic [4*XLEN-1:0] result_row1,
  output logic [4*XLEN-1:0] result_row2,
  output logic [4*XLEN-1:0] result_row3
);
  localparam int H = XLEN / 2;

  // Operand storage: A[r][c] -> A_flat[r*4+c]; B[r][c] -> B_flat[r*4+c] (as upstream)
  logic [XLEN-1:0] A_flat [16];
  logic [XLEN-1:0] B_flat [16];
  logic [XLEN-1:0] C_flat [16];

  typedef enum logic [1:0] { IDLE = 2'd0, LOAD = 2'd1, CALC = 2'd2, DRAIN = 2'd3 } state_t;
  state_t state;
  logic [1:0] row_cnt, col_cnt, k_cnt;

  wire accept = (state == IDLE) && start;

  // ---------------------------------------------------------------- A/B load
  always_ff @(posedge clk) begin
    if (accept) begin
      for (int c = 0; c < 4; c++) begin
        A_flat[0*4 + c] <= mat_a_row0[c*XLEN +: XLEN];
        A_flat[1*4 + c] <= mat_a_row1[c*XLEN +: XLEN];
        A_flat[2*4 + c] <= mat_a_row2[c*XLEN +: XLEN];
        A_flat[3*4 + c] <= mat_a_row3[c*XLEN +: XLEN];
        // B column j arrives on mat_b_colj, element r at [r*XLEN +: XLEN]
        B_flat[c*4 + 0] <= mat_b_col0[c*XLEN +: XLEN];
        B_flat[c*4 + 1] <= mat_b_col1[c*XLEN +: XLEN];
        B_flat[c*4 + 2] <= mat_b_col2[c*XLEN +: XLEN];
        B_flat[c*4 + 3] <= mat_b_col3[c*XLEN +: XLEN];
      end
    end
  end

  // ---------------------------------------------------------------- issue (S0)
  wire issue      = (state == CALC);
  wire issue_last = issue && (row_cnt == 2'd3) && (col_cnt == 2'd3) && (k_cnt == 2'd3);

  // ---------------------------------------------------------------- S1
  logic [XLEN-1:0] a_q, b_q;
  logic            v1, first1, last1, fin1;
  logic [3:0]      elem1;
  always_ff @(posedge clk) begin
    a_q <= A_flat[{row_cnt, k_cnt}];
    b_q <= B_flat[{k_cnt, col_cnt}];
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      v1 <= 1'b0; first1 <= 1'b0; last1 <= 1'b0; fin1 <= 1'b0; elem1 <= '0;
    end else begin
      v1     <= issue;
      first1 <= (k_cnt == 2'd0);
      last1  <= (k_cnt == 2'd3);
      fin1   <= issue_last;
      elem1  <= {row_cnt, col_cnt};
    end
  end

  // ---------------------------------------------------------------- S2
  logic [XLEN-1:0] pp_ll_c, pp_ll_q;
  logic [H-1:0]    pp_mid_c, pp_mid_q;
  logic            v2, first2, last2, fin2;
  logic [3:0]      elem2;
  sf_mul_lo_pp #(.W(XLEN)) u_pp (.a(a_q), .b(b_q), .pp_ll(pp_ll_c), .pp_mid(pp_mid_c));
  always_ff @(posedge clk) begin
    pp_ll_q  <= pp_ll_c;
    pp_mid_q <= pp_mid_c;
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      v2 <= 1'b0; first2 <= 1'b0; last2 <= 1'b0; fin2 <= 1'b0; elem2 <= '0;
    end else begin
      v2 <= v1; first2 <= first1; last2 <= last1; fin2 <= fin1; elem2 <= elem1;
    end
  end

  // ---------------------------------------------------------------- S3
  logic [XLEN-1:0] acc, acc_next;
  assign acc_next = (first2 ? '0 : acc) + pp_ll_q + {pp_mid_q, {H{1'b0}}};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      acc <= '0;
      for (int i = 0; i < 16; i++) C_flat[i] <= '0;
    end else begin
      if (accept) begin
        for (int i = 0; i < 16; i++) C_flat[i] <= '0;
      end else if (v2 && last2) begin
        C_flat[elem2] <= acc_next;
      end
      if (v2) acc <= acc_next;
    end
  end

  // ---------------------------------------------------------------- FSM
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= IDLE; done <= 1'b0; busy <= 1'b0;
      row_cnt <= '0; col_cnt <= '0; k_cnt <= '0;
    end else begin
      done <= 1'b0;
      case (state)
        IDLE: if (start) begin
          row_cnt <= '0; col_cnt <= '0; k_cnt <= '0;
          busy    <= 1'b1;
          state   <= LOAD;
        end
        LOAD: state <= CALC;
        CALC: begin
          {row_cnt, col_cnt, k_cnt} <= {row_cnt, col_cnt, k_cnt} + 6'd1;
          if (issue_last) state <= DRAIN;
        end
        DRAIN: if (v2 && fin2) begin
          done  <= 1'b1;
          busy  <= 1'b0;
          state <= IDLE;
        end
        default: state <= IDLE;
      endcase
    end
  end

  assign result_row0 = {C_flat[3],  C_flat[2],  C_flat[1],  C_flat[0]};
  assign result_row1 = {C_flat[7],  C_flat[6],  C_flat[5],  C_flat[4]};
  assign result_row2 = {C_flat[11], C_flat[10], C_flat[9],  C_flat[8]};
  assign result_row3 = {C_flat[15], C_flat[14], C_flat[13], C_flat[12]};
endmodule
