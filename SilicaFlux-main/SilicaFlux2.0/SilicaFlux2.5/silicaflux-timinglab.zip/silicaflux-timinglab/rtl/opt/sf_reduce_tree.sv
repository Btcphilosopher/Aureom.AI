// =============================================================================
// SilicaFlux TimingLab — parameterised balanced reduction tree
// rtl/opt/sf_reduce_tree.sv
//
// Reduces N (power of two) W-bit lanes with the SilicaFlux REDUCE operators
// (silicaflux_pkg::reduce_op_t: SUM / MIN / MAX / AND, signed compare, exactly
// as vector_engine.sv::reduce_pair). Pairing order is the upstream one:
// level l combines elements (2i, 2i+1) of level l-1.
//
// Hierarchical pipelining: a register stage is inserted after every
// LEVELS_PER_STAGE tree levels (0 = fully combinational). The op select and a
// valid bit travel with the data. Latency = number of inserted stages
//   = (LEVELS_PER_STAGE == 0) ? 0 : ceil(log2(N) / LEVELS_PER_STAGE) - 1
// (the final level is left unregistered so the parent can register its output
// together with other results).
// =============================================================================
`include "silicaflux_pkg.sv"

module sf_reduce_tree
  import silicaflux_pkg::*;
#(
  parameter int N                = 4,
  parameter int W                = 32,
  parameter int LEVELS_PER_STAGE = 0
) (
  input  logic               clk,
  input  logic               rst_n,
  input  logic               in_valid,
  input  reduce_op_t         in_op,
  input  logic [N*W-1:0]     in_data,
  output logic               out_valid,
  output reduce_op_t         out_op,
  output logic [W-1:0]       out_data
);
  localparam int LEVELS = (N <= 1) ? 0 : $clog2(N);

  function automatic logic [W-1:0] reduce_pair(input logic [W-1:0] a, input logic [W-1:0] b,
                                               input reduce_op_t op);
    case (op)
      REDUCE_SUM: return a + b;
      REDUCE_MIN: return ($signed(a) < $signed(b)) ? a : b;
      REDUCE_MAX: return ($signed(a) > $signed(b)) ? a : b;
      REDUCE_AND: return a & b;
      default:    return a + b;
    endcase
  endfunction

  // lvl[l] holds N >> l elements (packed); lvl[0] is the input.
  // Lint note: UNOPTFLAT is reported because level l reads element l-1 of the
  // same array; the levels form a DAG and there is no combinational cycle.
  /* verilator lint_off UNOPTFLAT */
  logic [N*W-1:0] lvl     [LEVELS+1];
  logic           lvl_v   [LEVELS+1];
  reduce_op_t     lvl_op  [LEVELS+1];
  /* verilator lint_on UNOPTFLAT */

  assign lvl[0]    = in_data;
  assign lvl_v[0]  = in_valid;
  assign lvl_op[0] = in_op;

  for (genvar l = 1; l <= LEVELS; l++) begin : g_level
    localparam int M = N >> l;
    logic [N*W-1:0] comb;
    always_comb begin
      comb = '0;
      for (int i = 0; i < M; i++)
        comb[i*W +: W] = reduce_pair(lvl[l-1][(2*i)*W +: W], lvl[l-1][(2*i+1)*W +: W], lvl_op[l-1]);
    end
    if (LEVELS_PER_STAGE > 0 && (l % LEVELS_PER_STAGE) == 0 && l != LEVELS) begin : g_reg
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          lvl_v[l]  <= 1'b0;
          lvl_op[l] <= REDUCE_SUM;
        end else begin
          lvl_v[l]  <= lvl_v[l-1];
          lvl_op[l] <= lvl_op[l-1];
        end
      end
      always_ff @(posedge clk) lvl[l] <= comb;
    end else begin : g_wire
      assign lvl[l]    = comb;
      assign lvl_v[l]  = lvl_v[l-1];
      assign lvl_op[l] = lvl_op[l-1];
    end
  end

  assign out_data  = lvl[LEVELS][W-1:0];
  assign out_valid = lvl_v[LEVELS];
  assign out_op    = lvl_op[LEVELS];
endmodule
