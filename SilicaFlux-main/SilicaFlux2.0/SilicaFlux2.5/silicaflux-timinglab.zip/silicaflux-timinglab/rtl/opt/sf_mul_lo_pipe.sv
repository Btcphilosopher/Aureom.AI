// =============================================================================
// SilicaFlux TimingLab — split low-half multiplier helpers
// rtl/opt/sf_mul_lo_pipe.sv
//
// The SilicaFlux datapaths only consume the LOW XLEN bits of an XLEN x XLEN
// product (tensor_unit.sv:112-113, vector_engine.sv:80-81, control_core.sv:158).
// For W = 2H:   a*b mod 2^W = aL*bL + ((aH*bL + aL*bH) mod 2^H) << H
// (aH*bH*2^W vanishes modulo 2^W). Signedness does not affect the low W bits.
//
// sf_mul_lo_pp  : combinational partial products {pp_ll (W bits), pp_mid (H bits)}
// sf_mul_lo_sum : combine partial products back to the W-bit low product
// Registering between the two splits the W x W multiplier into an H x H
// multiplier stage and a W-bit add stage.
// =============================================================================
`ifndef SF_MUL_LO_PIPE_SV
`define SF_MUL_LO_PIPE_SV

module sf_mul_lo_pp #(
  parameter int W = 32
) (
  input  logic [W-1:0]   a,
  input  logic [W-1:0]   b,
  output logic [W-1:0]   pp_ll,   // aL*bL (full 2H = W bits)
  output logic [W/2-1:0] pp_mid   // (aH*bL + aL*bH) mod 2^H
);
  localparam int H = W / 2;
  logic [H-1:0] a_l, a_h, b_l, b_h;
  logic [W-1:0] hl, lh;
  assign {a_h, a_l} = a;
  assign {b_h, b_l} = b;
  assign pp_ll  = W'(a_l) * W'(b_l);
  assign hl     = W'(a_h) * W'(b_l);
  assign lh     = W'(a_l) * W'(b_h);
  assign pp_mid = hl[H-1:0] + lh[H-1:0];
  // synthesis keeps only the low H bits of hl/lh (wreduce)
endmodule

module sf_mul_lo_sum #(
  parameter int W = 32
) (
  input  logic [W-1:0]   pp_ll,
  input  logic [W/2-1:0] pp_mid,
  output logic [W-1:0]   p
);
  localparam int H = W / 2;
  assign p = pp_ll + {pp_mid, {H{1'b0}}};
endmodule

`endif
