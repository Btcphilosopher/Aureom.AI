// =============================================================================
// SilicaFlux TimingLab — characterisation harness for the vector engine
// rtl/harness/tl_vec_ctx.sv
//
// upstream vector_engine has no input registers: in the real design its
// operands come from compute_tile registers (vec_opcode / vec_func / vec_op_a /
// vec_op_b, compute_tile.sv:255-261). Characterising it as a bare block makes
// every path an in2reg path whose slack depends on an assumed input budget.
// This harness reproduces the compute_tile context — registered operands — so
// the vector datapath is measured as reg2reg, identically for both
// implementations:  IMPL = 0 upstream vector_engine, IMPL = 1 sf_vector_engine_pipe.
// It adds no logic beyond those operand registers.
// =============================================================================
`include "silicaflux_pkg.sv"

module tl_vec_ctx
  import silicaflux_pkg::*;
#(
  parameter int LANES = LANES_DEFAULT,
  parameter int IMPL  = 0
) (
  input  logic                   clk,
  input  logic                   rst_n,
  input  logic                   issue_valid,
  input  logic [4:0]             opcode,
  input  logic [7:0]             func,
  input  logic [LANES*XLEN-1:0]  vop_a,
  input  logic [LANES*XLEN-1:0]  vop_b,
  input  logic [XLEN-1:0]        scalar_in,
  output logic                   result_valid,
  output logic [LANES*XLEN-1:0]  vresult,
  output logic [XLEN-1:0]        scalar_result,
  output logic                   is_scalar_result
);
  // operand registers (as in compute_tile)
  logic                  q_valid;
  logic [4:0]            q_opcode;
  logic [7:0]            q_func;
  logic [LANES*XLEN-1:0] q_a, q_b;
  logic [XLEN-1:0]       q_scalar;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) q_valid <= 1'b0;
    else        q_valid <= issue_valid;
  end
  always_ff @(posedge clk) begin
    q_opcode <= opcode; q_func <= func; q_a <= vop_a; q_b <= vop_b; q_scalar <= scalar_in;
  end

  if (IMPL == 0) begin : g_upstream
    vector_engine #(.LANES(LANES)) u_ve (
      .clk, .rst_n, .issue_valid(q_valid), .opcode(q_opcode), .func(q_func), .vop_a(q_a), .vop_b(q_b),
      .scalar_in(q_scalar), .result_valid, .vresult, .scalar_result, .is_scalar_result);
  end else begin : g_pipe
    sf_vector_engine_pipe #(.LANES(LANES)) u_ve (
      .clk, .rst_n, .issue_valid(q_valid), .opcode(q_opcode), .func(q_func), .vop_a(q_a), .vop_b(q_b),
      .scalar_in(q_scalar), .result_valid, .vresult, .scalar_result, .is_scalar_result);
  end
endmodule
