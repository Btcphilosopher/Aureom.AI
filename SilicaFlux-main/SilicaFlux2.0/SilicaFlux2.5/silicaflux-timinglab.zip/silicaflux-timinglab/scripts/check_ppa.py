#!/usr/bin/env python3
"""Acceptance gate 7: reproducible PPA comparison.

Reads reports/dashboard/timinglab_results.json (produced by `timinglab report`) and
fails if any TimingLab alternative is not faster than the upstream block it
replaces, or costs more area than the budget. Thresholds are deliberately
explicit so that a regression in a later RTL revision is caught by CI.

    python scripts/check_ppa.py results.json [--min-gain 5] [--max-area 25]
"""
import argparse
import json
import sys


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--min-gain", type=float, default=5.0, help="minimum reg2reg Fmax gain [%%]")
    ap.add_argument("--max-area", type=float, default=25.0, help="maximum synthesised-area increase [%%]")
    ap.add_argument("--json", help="write the gate result as JSON")
    a = ap.parse_args()
    comps = json.load(open(a.results))["comparisons"]
    if not comps:
        print("PPA gate: no before/after pairs found", file=sys.stderr)
        return 2
    bad = 0
    for c in comps:
        ok = c["fmax_gain_pct"] >= a.min_gain and (c["area_delta_pct"] is None or c["area_delta_pct"] <= a.max_area)
        bad += not ok
        print(f"{'PASS' if ok else 'FAIL'}  {c['pdk']:11s} {c['after']:28s} vs {c['before']:22s} "
              f"Fmax {c['fmax_before_mhz']:8.2f} -> {c['fmax_after_mhz']:8.2f} MHz ({c['fmax_gain_pct']:+6.1f}%)  "
              f"area {c['area_delta_pct']:+6.1f}%  stage {c['stage']}")
    if a.json:
        json.dump({"status": "PASS" if not bad else f"FAIL ({bad} pair(s))", "pairs": len(comps),
                   "min_gain_pct": a.min_gain, "max_area_pct": a.max_area}, open(a.json, "w"), indent=2)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
