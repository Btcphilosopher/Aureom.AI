#!/usr/bin/env bash
# Fetch the public PDK platform files (Liberty, LEF, RC, tracks) used by TimingLab
# from OpenROAD-flow-scripts with a sparse, blob-filtered clone (~250 MB).
set -euo pipefail
DEST="${1:-$(cd "$(dirname "$0")/.." && pwd)/third_party/orfs}"
REF="${ORFS_REF:-master}"
if [[ ! -d "$DEST/.git" ]]; then
  git clone --depth 1 --branch "$REF" --filter=blob:none --sparse \
      https://github.com/The-OpenROAD-Project/OpenROAD-flow-scripts.git "$DEST"
fi
cd "$DEST"
git sparse-checkout set flow/platforms/sky130hd flow/platforms/gf180 flow/platforms/ihp-sg13g2
ln -sfn "$DEST/flow/platforms" "$(dirname "$DEST")/orfs-platforms"
echo "PDK platforms at $(dirname "$DEST")/orfs-platforms  (export TL_PLATFORMS=$(dirname "$DEST")/orfs-platforms)"
git -C "$DEST" log -1 --format='ORFS commit %H (%cd)'
