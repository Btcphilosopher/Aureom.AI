#!/usr/bin/env bash
# Key blocks on GF180MCU and IHP SG13G2
cd "$(dirname "$0")/.."
python3 -m timinglab run tensor_unit tensor_unit_pipe vector_engine_ctx vector_engine_pipe_ctx control_core \
  --pdk ihp-sg13g2 gf180mcu --runs "${RUNS:-runs}"
