#!/usr/bin/env python3
"""Reproducibility check: compare two independent flow runs of the same designs.

    python scripts/check_repro.py runs_a runs_b [--json out.json]

Reports, per (pdk, design) present in both, whether cell count, synthesised area and
the worst slack of every stage are identical.
"""
import argparse
import json
import sys
from pathlib import Path


def key_numbers(rec: dict) -> dict:
    out = {"cells": (rec.get("synth") or {}).get("cells"),
           "area": (rec.get("synth") or {}).get("area_um2")}
    t = (rec.get("sta") or {}).get("timing") or {}
    out["synth_wns"] = (t.get("setup") or {}).get("wns")
    for st, d in ((rec.get("pnr") or {}).get("stages") or {}).items():
        out[f"{st}_wns"] = d["setup"]["wns"]
        out[f"{st}_r2r"] = d.get("reg2reg_wns")
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("a"); ap.add_argument("b"); ap.add_argument("--json")
    a = ap.parse_args()
    A = {(r["pdk"], r["design"]): r for r in (json.loads(p.read_text()) for p in Path(a.a).rglob("result.json"))}
    B = {(r["pdk"], r["design"]): r for r in (json.loads(p.read_text()) for p in Path(a.b).rglob("result.json"))}
    rows = []
    for k in sorted(set(A) & set(B)):
        ka, kb = key_numbers(A[k]), key_numbers(B[k])
        common = {x for x in ka if ka[x] is not None and kb.get(x) is not None}
        same = all(ka[x] == kb[x] for x in common)
        rows.append({"pdk": k[0], "design": k[1], "identical": same, "compared": sorted(common),
                     "diff": {x: [ka[x], kb[x]] for x in common if ka[x] != kb[x]}})
        print(f"{'IDENTICAL' if same else 'DIFFERENT'}  {k[0]:11s} {k[1]:26s} ({len(common)} metrics)")
    if a.json:
        Path(a.json).write_text(json.dumps(rows, indent=2) + "\n")
    return 0 if all(r["identical"] for r in rows) else 1


if __name__ == "__main__":
    sys.exit(main())
