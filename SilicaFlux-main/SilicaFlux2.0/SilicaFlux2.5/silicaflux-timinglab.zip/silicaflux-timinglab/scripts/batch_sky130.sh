#!/usr/bin/env bash
# Block-level baseline + alternatives on SKY130 (used to produce reports/)
cd "$(dirname "$0")/.."
python3 -m timinglab run tensor_unit tensor_unit_pipe vector_engine_ctx vector_engine_pipe_ctx control_core \
  vector_engine_l8_ctx vector_engine_pipe_l8_ctx decoder register_bank scheduler noc_router tile_interface \
  sfx_mac sfx_systolic_4x4 memory_controller compute_tile --pdk sky130hd --runs "${RUNS:-runs}"
