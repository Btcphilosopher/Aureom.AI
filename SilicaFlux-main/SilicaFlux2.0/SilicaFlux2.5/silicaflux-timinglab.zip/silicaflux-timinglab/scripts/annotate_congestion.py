#!/usr/bin/env python3
"""Re-annotate existing run records with the congestion/critical-path correlation
(for runs produced before timinglab/flow/pnr.py did it inline).
    python scripts/annotate_congestion.py runs"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from timinglab.parsers.openroad import parse_congestion_report, annotate_congestion  # noqa: E402

for res in sorted(Path(sys.argv[1]).rglob("result.json")):
    rec = json.loads(res.read_text())
    pnr = rec.get("pnr") or {}
    grt = (pnr.get("stages") or {}).get("grt")
    if not grt:
        continue
    summ, nets = parse_congestion_report(res.parent / "pnr" / "congestion.rpt")
    if summ["available"]:
        summ["critical_path_correlation"] = annotate_congestion(grt, nets)
    pnr["congestion"] = summ
    res.write_text(json.dumps(rec, indent=2, default=str) + "\n")
    c = summ.get("critical_path_correlation") or {}
    print(f"{rec['pdk']:11s} {rec['design']:26s} regions={summ['congested_regions']:6d} "
          f"congested_nets={summ['n_congested_nets']:6d} r2r_nets_in_congestion={c.get('fraction')}")
