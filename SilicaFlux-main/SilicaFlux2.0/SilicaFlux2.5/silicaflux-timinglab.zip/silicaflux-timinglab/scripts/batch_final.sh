#!/usr/bin/env bash
# Produces the sample results in reports/: two parallel streams (2-core machine).
cd "$(dirname "$0")/.."
R="${RUNS:-runs}"
( python3 -m timinglab run tensor_unit tensor_unit_pipe vector_engine_ctx vector_engine_pipe_ctx control_core \
    vector_engine_l8_ctx vector_engine_pipe_l8_ctx decoder register_bank scheduler noc_router tile_interface \
    sfx_mac sfx_systolic_4x4 --pdk sky130hd --runs "$R" > logs_final_a.txt 2>&1 ) &
( python3 -m timinglab run tensor_unit tensor_unit_pipe vector_engine_ctx vector_engine_pipe_ctx control_core \
    --pdk ihp-sg13g2 gf180mcu --runs "$R" > logs_final_b.txt 2>&1 ;
  python3 -m timinglab run compute_tile compute_tile_pipe memory_controller --pdk sky130hd --runs "$R" \
    > logs_final_c.txt 2>&1 ) &
wait
