#!/usr/bin/env bash
# Install the open-source EDA tools TimingLab drives (Ubuntu 22.04/24.04, x86_64).
# Versions used to produce reports/: see docs/TOOLING.md.
set -euo pipefail
PREFIX="${PREFIX:-/opt}"
sudo apt-get update
sudo apt-get install -y iverilog verilator build-essential cmake swig bison flex tcl-dev zlib1g-dev \
     libeigen3-dev libgtest-dev libgmock-dev graphviz git curl python3-pip

# 1) Yosys 0.70 with the integrated slang SystemVerilog frontend (read_slang).
#    YoWASP packages it as a portable WebAssembly binary; SilicaFlux needs read_slang.
python3 -m pip install --user yowasp-yosys pytest

# 2) OpenSTA (standalone, latest) — requires CUDD.
mkdir -p "$HOME/eda" && cd "$HOME/eda"
[[ -d cudd ]] || git clone --depth 1 https://github.com/ivmai/cudd.git
(cd cudd && autoreconf -fi >/dev/null 2>&1 || true; ./configure --prefix="$PREFIX/cudd" && make -j"$(nproc)" && sudo make install)
[[ -d OpenSTA ]] || git clone --depth 1 https://github.com/The-OpenROAD-Project/OpenSTA.git
(cd OpenSTA && mkdir -p build && cd build && cmake -DCUDD_DIR="$PREFIX/cudd" -DCMAKE_BUILD_TYPE=Release .. \
   && make -j"$(nproc)" sta && sudo install -D sta "$PREFIX/opensta/bin/sta")

# 3) OpenROAD — prebuilt conda package from the litex-hub channel, via micromamba.
if [[ ! -x "$PREFIX/eda-or/bin/openroad" ]]; then
  curl -sSL https://conda.anaconda.org/conda-forge/linux-64/micromamba-2.10.0-0.tar.bz2 | tar -xj -C /tmp bin/micromamba
  MAMBA_ROOT_PREFIX="$HOME/.mamba" /tmp/bin/micromamba create -y -p "$PREFIX/eda-or" \
     -c litex-hub -c anaconda -c conda-forge "openroad=2.0_12381_g01bba3695" "python=3.10"
fi
echo "export TL_STA=$PREFIX/opensta/bin/sta TL_OPENROAD=$PREFIX/eda-or/bin/openroad"
