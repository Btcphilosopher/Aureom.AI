// =============================================================================
// tb_multichannel.sv -- SilicaFlux FlashLink, Project 53: multi-channel test
// -----------------------------------------------------------------------------
// silicaflux_nand_multichannel (NUM_CH = 2), each channel with one NANDLab
// target (TARGET_ID = channel), its own SFB2 buffer model and its own
// independent pin monitor. Checks channel isolation and concurrency, the
// round-robin completion merge, per-channel CSR windows and the bad-channel
// path, then zero model / monitor / SFB2 errors on both channels.
// Classification: TESTBENCH
// =============================================================================
`timescale 1ns/1ps

module tb_multichannel;
  parameter int CLK_PS = 10000;
  localparam int NCH = 2;
  localparam int PD = 512, PS = 16, PB = PD + PS;
  localparam int CYC_US = (1000000 + CLK_PS - 1) / CLK_PS;

  logic clk = 1'b0, rst_n = 1'b0, vcc_ok = 1'b1;
  always #(CLK_PS / 2000.0) clk = ~clk;

  logic        req_valid, req_ready;
  logic [2:0]  req_ch, req_ce, req_lun;
  logic [3:0]  req_op;
  logic [7:0]  req_tag, req_faddr;
  logic [23:0] req_block;
  logic [15:0] req_page, req_col, req_len;
  logic [31:0] req_buf, req_fdata;
  logic        cpl_valid, cpl_ready;
  logic [2:0]  cpl_ch, cpl_ce, cpl_lun;
  logic [7:0]  cpl_tag, cpl_nst;
  logic [3:0]  cpl_op, cpl_status;
  logic [31:0] cpl_info0, cpl_info1, cpl_latency, cpl_dev;
  logic        csr_sel, csr_we, csr_err;
  logic [10:0] csr_addr;
  logic [31:0] csr_wdata, csr_rdata;
  logic [NCH-1:0] m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NCH*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NCH*4-1:0]  m_req_wstrb;
  logic [NCH-1:0] c_ce_n, c_cle, c_ale, c_we_n, c_re_n, c_wp_n, c_dq_oe, c_rb_n;
  logic [NCH*8-1:0] c_dq_o, c_dq_i;
  logic irq, busy;

  silicaflux_nand_multichannel #(.NUM_CH(NCH), .CLK_PERIOD_PS(CLK_PS)) dut (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_ready(req_ready), .req_ch(req_ch), .req_op(req_op), .req_tag(req_tag),
    .req_ce(req_ce), .req_lun(req_lun), .req_block(req_block), .req_page(req_page), .req_col(req_col),
    .req_len(req_len), .req_buf(req_buf), .req_faddr(req_faddr), .req_fdata(req_fdata),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_ch(cpl_ch), .cpl_tag(cpl_tag), .cpl_op(cpl_op),
    .cpl_status(cpl_status), .cpl_nand_status(cpl_nst), .cpl_ce(cpl_ce), .cpl_lun(cpl_lun),
    .cpl_info0(cpl_info0), .cpl_info1(cpl_info1), .cpl_latency(cpl_latency), .cpl_dev_time(cpl_dev),
    .csr_sel(csr_sel), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata),
    .csr_err(csr_err),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .nand_ce_n(c_ce_n), .nand_cle(c_cle), .nand_ale(c_ale), .nand_we_n(c_we_n), .nand_re_n(c_re_n),
    .nand_wp_n(c_wp_n), .nand_dq_o(c_dq_o), .nand_dq_oe(c_dq_oe), .nand_dq_i(c_dq_i), .nand_rb_n(c_rb_n),
    .irq(irq), .busy(busy));

  logic pins_live = 1'b0;
  always @(posedge clk) if (!rst_n) pins_live <= 1'b1;

  int ch_proto [0:NCH-1];
  int ch_timing [0:NCH-1];
  for (genvar c = 0; c < NCH; c++) begin : g_ch
    wire p_ce_n, p_cle, p_ale, p_we_n, p_re_n, p_wp_n, p_rb_n, rb;
    tri  [7:0] p_dq;
    wire [7:0] dqi;
    wire g_oe   = pins_live & c_dq_oe[c];
    wire g_ce_n = !pins_live | c_ce_n[c];
    wire g_cle  = pins_live & c_cle[c];
    wire g_ale  = pins_live & c_ale[c];
    wire g_we_n = !pins_live | c_we_n[c];
    wire g_re_n = !pins_live | c_re_n[c];
    wire g_wp_n = pins_live & c_wp_n[c];
    wire [7:0] g_dq_o = c_dq_o[c*8 +: 8];
    wire g_rb_n;
    assign c_rb_n[c] = g_rb_n;
    sfnc_io_sdr #(.DQW(8), .NUM_CE(1), .NUM_RB(1), .TECH("SIM")) u_io (
      .c_ce_n(g_ce_n), .c_cle(g_cle), .c_ale(g_ale),
      .c_we_n(g_we_n), .c_re_n(g_re_n), .c_wp_n(g_wp_n),
      .c_dq_o(g_dq_o), .c_dq_oe(g_oe), .c_dq_i(dqi), .c_rb_n(g_rb_n),
      .pad_ce_n(p_ce_n), .pad_cle(p_cle), .pad_ale(p_ale), .pad_we_n(p_we_n), .pad_re_n(p_re_n),
      .pad_wp_n(p_wp_n), .pad_dq(p_dq), .pad_rb_n(rb));
    assign c_dq_i[c*8 +: 8] = dqi;
    nand_flash_device #(.PAGE_DATA_BYTES(PD), .PAGE_SPARE_BYTES(PS), .PAGES_PER_BLOCK(16), .BLOCKS_PER_PLANE(32),
      .PLANES_PER_LUN(2), .LUNS(2), .TARGET_ID(c)) u_dev (
      .ce_n(p_ce_n), .cle(p_cle), .ale(p_ale), .we_n(p_we_n), .re_n(p_re_n), .wp_n(p_wp_n), .vcc_ok(vcc_ok),
      .dq(p_dq), .rb_n(rb));
    sfnc_onfi_monitor #(.NUM_CE(1), .DQW(8), .PER_CE_RB(1), .NAME("MON"), .INST(c)) u_mon (
      .ce_n(p_ce_n), .cle(p_cle), .ale(p_ale), .we_n(p_we_n), .re_n(p_re_n), .wp_n(p_wp_n), .dq(p_dq),
      .dq_oe(g_oe), .rb_n(rb), .vcc_ok(vcc_ok));
    sfnc_sfb_mem #(.DW(32), .BYTES(65536)) u_mem (
      .clk(clk), .rst_n(rst_n), .req_valid(m_req_valid[c]), .req_ready(m_req_ready[c]),
      .req_write(m_req_write[c]), .req_addr(m_req_addr[c*32 +: 32]), .req_wdata(m_req_wdata[c*32 +: 32]),
      .req_wstrb(m_req_wstrb[c*4 +: 4]), .rsp_valid(m_rsp_valid[c]), .rsp_ready(m_rsp_ready[c]),
      .rsp_rdata(m_rsp_rdata[c*32 +: 32]), .rsp_error(m_rsp_error[c]));
    always @(posedge clk) begin
      ch_proto[c]  = u_dev.u_model.n_proto_errors;
      ch_timing[c] = u_dev.u_model.n_timing_violations;
    end
  end

  // ------------------------------------------------------------ completions
  bit          c_got [0:255];
  logic [3:0]  c_st [0:255];
  logic [2:0]  c_ch [0:255];
  logic [31:0] c_i0 [0:255], c_dev [0:255];
  int          c_seq [0:255];
  int          n_cpl;
  always @(posedge clk) if (cpl_valid && cpl_ready) begin
    c_got[cpl_tag] = 1; c_st[cpl_tag] = cpl_status; c_ch[cpl_tag] = cpl_ch; c_i0[cpl_tag] = cpl_info0;
    c_dev[cpl_tag] = cpl_dev; c_seq[cpl_tag] = n_cpl; n_cpl++;
  end

  string dir, resfile;
  int rfd, n_pass, n_fail, tagc;
  logic [3:0] r_st;
  logic [2:0] r_ch;
  logic [31:0] r_i0, r_dev, rd_val;
  int r_seq;

  task automatic check(input bit cond, input string name);
    if (cond) begin n_pass++; $fdisplay(rfd, "CHECK PASS %s", name); end
    else begin n_fail++; $fdisplay(rfd, "CHECK FAIL %s", name); $display("[TB %0t] FAIL: %s", $realtime, name); end
  endtask
  function automatic bit [7:0] pat(input int seed, input int i);
    bit [63:0] h;
    h = nand_flash_pkg::mix64(64'(seed) * 64'h100000001B3 + 64'(i));
    pat = h[7:0];
  endfunction
  task automatic csr_wr(input int ch, input logic [7:0] a, input logic [31:0] d);
    @(negedge clk); csr_sel = 1; csr_we = 1; csr_addr = {3'(ch), a}; csr_wdata = d;
    @(negedge clk); csr_sel = 0; csr_we = 0;
  endtask
  task automatic csr_rd(input int ch, input logic [7:0] a);
    @(negedge clk); csr_sel = 1; csr_we = 0; csr_addr = {3'(ch), a}; #1; rd_val = csr_rdata;
    @(negedge clk); csr_sel = 0;
  endtask
  task automatic submit(input int ch, input logic [3:0] op, input logic [7:0] tag, input int lun, input int blk,
                        input int pg, input int len, input int bufa, input logic [7:0] fa, input logic [31:0] fd);
    @(negedge clk);
    c_got[tag] = 0;
    req_valid = 1; req_ch = 3'(ch); req_op = op; req_tag = tag; req_ce = 0; req_lun = 3'(lun); req_block = 24'(blk);
    req_page = 16'(pg); req_col = 0; req_len = 16'(len); req_buf = 32'(bufa); req_faddr = fa; req_fdata = fd;
    while (!req_ready) @(negedge clk);
    @(posedge clk); #1;
    req_valid = 0;
  endtask
  task automatic wait_cpl(input logic [7:0] tag, input real max_us);
    real t0;
    t0 = $realtime;
    while (!c_got[tag] && ($realtime - t0) < max_us * 1000.0) @(posedge clk);
    #1;
    if (!c_got[tag]) begin check(0, $sformatf("completion of tag %0d", tag)); r_st = 4'hF; r_seq = -1; end
    else begin r_st = c_st[tag]; r_ch = c_ch[tag]; r_i0 = c_i0[tag]; r_dev = c_dev[tag]; r_seq = c_seq[tag]; end
    c_got[tag] = 0;
  endtask
  task automatic op(input int ch, input logic [3:0] opc, input int lun, input int blk, input int pg, input int len,
                    input int bufa, input logic [7:0] fa, input logic [31:0] fd, input real max_us);
    logic [7:0] t;
    t = 8'(tagc); tagc = (tagc + 1) % 200;
    submit(ch, opc, t, lun, blk, pg, len, bufa, fa, fd);
    wait_cpl(t, max_us);
  endtask
  task automatic fill(input int ch, input int a, input int n, input int seed);
    for (int i = 0; i < n; i++)
      if (ch == 0) g_ch[0].u_mem.mem[a + i] = pat(seed, i); else g_ch[1].u_mem.mem[a + i] = pat(seed, i);
  endtask
  function automatic int cmpb(input int ch, input int a, input int n, input int seed);
    int bad;
    bad = 0;
    for (int i = 0; i < n; i++) begin
      bit [7:0] v;
      if (ch == 0) v = g_ch[0].u_mem.mem[a + i];
      else         v = g_ch[1].u_mem.mem[a + i];
      if (v !== pat(seed, i)) bad++;
    end
    cmpb = bad;
  endfunction

  initial begin
    req_valid = 0; req_ch = 0; req_op = 0; req_tag = 0; req_ce = 0; req_lun = 0; req_block = 0; req_page = 0;
    req_col = 0; req_len = 0; req_buf = 0; req_faddr = 0; req_fdata = 0; cpl_ready = 1; csr_sel = 0; csr_we = 0;
    csr_addr = 0; csr_wdata = 0; n_pass = 0; n_fail = 0; n_cpl = 0; tagc = 0;
    for (int i = 0; i < 256; i++) c_got[i] = 0;
    if (!$value$plusargs("NANDLAB_DIR=%s", dir)) dir = ".";
    if (!$value$plusargs("RESULT=%s", resfile)) resfile = {dir, "/tb_multichannel.result"};
    rfd = $fopen(resfile, "w");
    g_ch[0].u_mem.stall_pct = 15; g_ch[1].u_mem.stall_pct = 30; g_ch[1].u_mem.lat_max = 4;
    repeat (8) @(negedge clk);
    rst_n = 1;
    repeat (4) @(negedge clk);
    $fdisplay(rfd, "CONFIG test multichannel NUM_CH %0d CLK_PS %0d", NCH, CLK_PS);
    // per-channel bring-up
    for (int c = 0; c < NCH; c++) begin
      csr_rd(c, 8'h00); check(rd_val == 32'h5346_3533, $sformatf("channel %0d CSR window", c));
      csr_wr(c, 8'h0C, 32'h0004_17C7);                                   // WP# high + interleave
      op(c, 4'h0, 0, 0, 0, 0, 0, 0, 0, 5000);
      check(r_st == 0 && r_ch == 3'(c), $sformatf("channel %0d RESET (completion tagged with its channel)", c));
      op(c, 4'h2, 0, 0, 0, 0, 0, 0, 0, 500);
      check(r_st == 0, $sformatf("channel %0d parameter page", c));
      op(c, 4'h7, 0, 0, 0, 0, 0, 8'h01, 32'h5, 200);
      check(r_st == 0, $sformatf("channel %0d timing mode 5", c));
    end
    // concurrent erases on both channels: total time ~ one erase
    begin
      real t0, t1;
      t0 = $realtime;
      submit(0, 4'h6, 8'd10, 0, 6, 0, 0, 0, 0, 0);
      submit(1, 4'h6, 8'd11, 0, 6, 0, 0, 0, 0, 0);
      wait_cpl(8'd10, 5000); check(r_st == 0, "channel 0 erase");
      wait_cpl(8'd11, 5000); check(r_st == 0, "channel 1 erase");
      t1 = $realtime;
      check((t1 - t0) < 1500000.0, $sformatf("two 1 ms erases on two channels overlap (%0.1f us total)", (t1 - t0) / 1000.0));
    end
    // concurrent programs with different data, then cross-check reads
    fill(0, 0, PB, 50); fill(1, 0, PB, 51);
    submit(0, 4'h5, 8'd20, 0, 6, 0, PB, 0, 0, 0);
    submit(1, 4'h5, 8'd21, 0, 6, 0, PB, 0, 0, 0);
    wait_cpl(8'd20, 3000); check(r_st == 0, "channel 0 program");
    wait_cpl(8'd21, 3000); check(r_st == 0, "channel 1 program");
    submit(0, 4'h4, 8'd30, 0, 6, 0, PB, 32'h1000, 0, 0);
    submit(1, 4'h4, 8'd31, 0, 6, 0, PB, 32'h1000, 0, 0);
    wait_cpl(8'd30, 3000); check(r_st == 0 && cmpb(0, 32'h1000, PB, 50) == 0, "channel 0 reads its own data");
    wait_cpl(8'd31, 3000); check(r_st == 0 && cmpb(1, 32'h1000, PB, 51) == 0, "channel 1 reads its own data");
    // long operation on channel 1 does not hold up channel 0
    begin
      int se;
      submit(1, 4'h6, 8'd40, 1, 7, 0, 0, 0, 0, 0);
      submit(0, 4'h4, 8'd41, 0, 6, 0, PB, 32'h2000, 0, 0);
      wait_cpl(8'd41, 3000); check(r_st == 0 && cmpb(0, 32'h2000, PB, 50) == 0, "channel 0 read while channel 1 erases");
      se = r_seq;
      wait_cpl(8'd40, 5000); check(r_st == 0 && r_seq > se, "channel 1 erase completes later");
    end
    // completion back-pressure across channels
    cpl_ready = 0;
    submit(0, 4'h3, 8'd50, 0, 0, 0, 0, 0, 0, 0);
    submit(1, 4'h3, 8'd51, 0, 0, 0, 0, 0, 0, 0);
    repeat (400) @(negedge clk);
    check(!c_got[8'd50] && !c_got[8'd51], "completions held while cpl_ready = 0");
    cpl_ready = 1;
    wait_cpl(8'd50, 100); check(r_st == 0 && r_ch == 3'd0, "held completion delivered (channel 0)");
    wait_cpl(8'd51, 100); check(r_st == 0 && r_ch == 3'd1, "held completion delivered (channel 1)");
    // bad channel
    op(5, 4'h4, 0, 6, 0, PB, 0, 0, 0, 100);
    check(r_st == 4'h4 && r_ch == 3'd5, "request for channel 5 -> BAD_ADDR completion");
    @(negedge clk); csr_sel = 1; csr_we = 0; csr_addr = {3'd6, 8'h00}; #1; check(csr_err, "CSR access to a missing channel flags csr_err");
    csr_sel = 0;
    // global
    for (int c = 0; c < NCH; c++) begin
      check(ch_proto[c] == 0, $sformatf("channel %0d model: zero protocol errors", c));
      check(ch_timing[c] == 0, $sformatf("channel %0d model: zero AC timing violations", c));
    end
    check(g_ch[0].u_mon.n_viol == 0 && g_ch[1].u_mon.n_viol == 0,
          $sformatf("monitors: zero violations (%0d + %0d checks)", g_ch[0].u_mon.n_checks, g_ch[1].u_mon.n_checks));
    check(g_ch[0].u_mem.n_proto == 0 && g_ch[1].u_mem.n_proto == 0, "SFB2 ports: zero protocol errors");
    g_ch[0].u_mon.report(rfd);
    g_ch[1].u_mon.report(rfd);
    $fdisplay(rfd, "SUMMARY test multichannel pass %0d fail %0d", n_pass, n_fail);
    $fclose(rfd);
    $display("[TB] multichannel: %0d passed, %0d failed", n_pass, n_fail);
    $finish;
  end
  initial begin
    #(100_000_000);
    $display("[TB] WATCHDOG");
    $fdisplay(rfd, "CHECK FAIL watchdog");
    $fdisplay(rfd, "SUMMARY test multichannel pass %0d fail %0d", n_pass, n_fail + 1);
    $fclose(rfd);
    $finish;
  end
endmodule
