// =============================================================================
// sfnc_onfi_monitor.sv -- SilicaFlux FlashLink, Project 53 (testbench)
// -----------------------------------------------------------------------------
// Independent pin-level monitor of the asynchronous NAND channel. It does not
// use any controller-internal signal except dq_oe (to tell who drives DQ).
//
//   * AC timing, per target, against the ONFI-style table of the timing mode
//     that target is in. The mode is tracked from the bus itself: SET FEATURES
//     (EFh 01h P1..P4) takes effect when the target's R/B# returns high;
//     power loss (vcc_ok low) returns every target to mode 0.
//       write: tWP tWH tWC tCLS tALS tDS tCLH tALH tDH tCS tCH tWW
//       read : tRP tREH tRC tWHR tCLR tAR tRR tCEA
//       turnaround: tRHW (RE# rise -> WE# fall), tRHZ (RE# rise -> controller
//                   drives DQ), DQ released while RE# low
//   * electrical / stability: one CE# at a time, strobes only with a CE#
//     selected, WE#/RE# never low together, CLE and ALE never both high at a
//     WE# rise, no X/Z on control pins or on DQ when it is latched / sampled,
//     DQ unchanged while WE# is low, no contention (controller driving while
//     RE# is low, or X on the resolved bus while the controller drives).
//   * command sequences: 00h-5addr-30h, 80h-5addr-data-10h, 60h-3addr-D0h,
//     90h-1addr-out, ECh-1addr-out, EEh-1addr-out, EFh-1addr-4data, 70h-out,
//     78h-3addr-out, 00h-out (return to data output); data output while the
//     target's R/B# is low after 30h/ECh/EEh (PER_CE_RB only).
//   * transaction log (+MON_LOG=<file>) and per-target command counters.
// The timing table is a separate transcription of the same ONFI-style values
// the controller package uses (see silicaflux_nand_timing_pkg provenance).
// Classification: TESTBENCH
// =============================================================================
`timescale 1ns/1ps

module sfnc_onfi_monitor #(
  parameter int NUM_CE    = 1,
  parameter int DQW       = 8,
  parameter int PER_CE_RB = 1,      // 0: rb_n lines are one shared wired-AND line
  parameter string NAME   = "MON",
  parameter int    INST   = -1       // >= 0: appended to NAME in messages
) (
  input logic [NUM_CE-1:0] ce_n,
  input logic              cle,
  input logic              ale,
  input logic              we_n,
  input logic              re_n,
  input logic              wp_n,
  input wire  [DQW-1:0]    dq,
  input logic              dq_oe,
  input logic [NUM_CE-1:0] rb_n,
  input logic              vcc_ok
);
  // ------------------------------------------------------------ table (ns)
  real T_WP[0:5], T_WH[0:5], T_WC[0:5], T_RP[0:5], T_REH[0:5], T_RC[0:5], T_REA[0:5];
  real T_CLS[0:5], T_ALS[0:5], T_DS[0:5], T_CLH[0:5], T_ALH[0:5], T_DH[0:5], T_CS[0:5], T_CH[0:5];
  real T_WHR[0:5], T_RHW[0:5], T_RR[0:5], T_WW[0:5], T_CLR[0:5], T_AR[0:5], T_RHZ[0:5], T_CEA[0:5];

  // ------------------------------------------------------------ checks
  localparam int V_WP = 0, V_WH = 1, V_WC = 2, V_CLS = 3, V_ALS = 4, V_DS = 5, V_CLH = 6, V_ALH = 7;
  localparam int V_DH = 8, V_CS = 9, V_CH = 10, V_WW = 11, V_RP = 12, V_REH = 13, V_RC = 14, V_WHR = 15;
  localparam int V_CLR = 16, V_AR = 17, V_RR = 18, V_CEA = 19, V_RHW = 20, V_RHZ = 21, V_CONTEND = 22;
  localparam int V_MULTI_CE = 23, V_NOCE = 24, V_WERE = 25, V_CLEALE = 26, V_XCTL = 27, V_XDQ = 28;
  localparam int V_STABLE = 29, V_SEQ = 30, V_BUSYOUT = 31, V_CCS = 32, NV = 33;
  string vname [0:NV-1];
  int    viol  [0:NV-1];
  int    n_viol, n_checks;
  string tag;
  int    inst_v;
  bit    quiet;

  // ------------------------------------------------------------ state
  real t_we_fall, t_we_rise, t_re_fall, t_re_rise, t_cle_rise, t_cle_fall, t_ale_rise, t_ale_fall;
  real t_dq_chg, t_ce_fall, t_wp_chg, t_rb_rise [0:NUM_CE-1];
  real t_ccs;                           // last CHANGE READ COLUMN confirm (E0h)
  real T_CCS;                           // tCCS of the device (parameter page), ns
  bit  we_cle, we_ale, we_drv;          // state at the last WE# rise
  int  sel;                             // selected target, -1 none
  int  mode [0:NUM_CE-1];
  bit  setf_pend [0:NUM_CE-1];
  int  setf_val [0:NUM_CE-1];
  // decoder per target
  bit [7:0] last_cmd [0:NUM_CE-1];
  int  n_addr [0:NUM_CE-1], n_din [0:NUM_CE-1];
  bit [7:0] feat_a [0:NUM_CE-1];
  int  cmd_cnt [0:NUM_CE-1][0:255];
  int  n_dout_total, n_din_total, n_cmd_total;
  // confirm log (arbitration checks)
  bit [7:0] conf_op [0:4095];
  int  conf_ce [0:4095];
  int  conf_n;
  // transaction log
  int  lfd;
  string lkind;
  int  lce, lcount;
  real lt;
  string lbytes;

  function automatic int m_of(input int c);
    if (c < 0 || c >= NUM_CE) m_of = 0;
    else m_of = mode[c];
  endfunction

  task automatic chk(input int id, input real got, input real need);
    n_checks++;
    if (got < need - 0.001) begin
      viol[id]++; n_viol++;
      if (!quiet && viol[id] <= 5)
        $display("[%s %0t] TIMING %s = %0.3f ns < %0.3f ns (CE%0d mode %0d)", tag, $realtime, vname[id], got, need,
                 sel, m_of(sel));
    end
  endtask

  task automatic flag(input int id, input string why);
    viol[id]++; n_viol++;
    if (!quiet && viol[id] <= 5) $display("[%s %0t] %s: %s", tag, $realtime, vname[id], why);
  endtask

  task automatic log_flush();
    if (lfd != 0 && lkind != "") begin
      if (lkind == "DIN" || lkind == "DOUT")
        $fdisplay(lfd, "%12.3f ns  CE%0d %-5s x%0d%s", lt, lce, lkind, lcount, lbytes);
      else
        $fdisplay(lfd, "%12.3f ns  CE%0d %-5s%s", lt, lce, lkind, lbytes);
    end
    lkind = ""; lcount = 0; lbytes = "";
  endtask

  task automatic log_ev(input string kind, input bit [7:0] b);
    if (lfd != 0) begin
      if (kind != lkind || sel != lce || kind == "CMD") begin
        log_flush();
        lkind = kind; lce = sel; lt = $realtime; lcount = 0; lbytes = "";
      end
      lcount++;
      if (kind == "CMD" || kind == "ADDR" || lcount <= 4) lbytes = {lbytes, $sformatf(" %02x", b)};
      else if (lcount == 5) lbytes = {lbytes, " ..."};
    end
  endtask

  initial begin
    T_WP[0] = 50; T_WP[1] = 25; T_WP[2] = 17; T_WP[3] = 15; T_WP[4] = 12; T_WP[5] = 10;  T_WH[0] = 30; T_WH[1] = 15; T_WH[2] = 15; T_WH[3] = 10; T_WH[4] = 10; T_WH[5] = 7;   T_WC[0] = 100; T_WC[1] = 45; T_WC[2] = 35; T_WC[3] = 30; T_WC[4] = 25; T_WC[5] = 20;
    T_RP[0] = 50; T_RP[1] = 25; T_RP[2] = 17; T_RP[3] = 15; T_RP[4] = 12; T_RP[5] = 10;  T_REH[0] = 30; T_REH[1] = 15; T_REH[2] = 15; T_REH[3] = 10; T_REH[4] = 10; T_REH[5] = 7;   T_RC[0] = 100; T_RC[1] = 50; T_RC[2] = 35; T_RC[3] = 30; T_RC[4] = 25; T_RC[5] = 20;
    T_REA[0] = 40; T_REA[1] = 30; T_REA[2] = 25; T_REA[3] = 20; T_REA[4] = 20; T_REA[5] = 16;  T_CLS[0] = 50; T_CLS[1] = 25; T_CLS[2] = 15; T_CLS[3] = 10; T_CLS[4] = 10; T_CLS[5] = 10;  T_ALS[0] = 50; T_ALS[1] = 25; T_ALS[2] = 15; T_ALS[3] = 10; T_ALS[4] = 10; T_ALS[5] = 10;
    T_DS[0] = 40; T_DS[1] = 20; T_DS[2] = 15; T_DS[3] = 10; T_DS[4] = 10; T_DS[5] = 7;   T_CLH[0] = 20; T_CLH[1] = 10; T_CLH[2] = 10; T_CLH[3] = 5; T_CLH[4] = 5; T_CLH[5] = 5;     T_ALH[0] = 20; T_ALH[1] = 10; T_ALH[2] = 10; T_ALH[3] = 5; T_ALH[4] = 5; T_ALH[5] = 5;
    T_DH[0] = 20; T_DH[1] = 10; T_DH[2] = 5; T_DH[3] = 5; T_DH[4] = 5; T_DH[5] = 5;      T_CS[0] = 70; T_CS[1] = 35; T_CS[2] = 25; T_CS[3] = 25; T_CS[4] = 20; T_CS[5] = 15;  T_CH[0] = 20; T_CH[1] = 10; T_CH[2] = 10; T_CH[3] = 5; T_CH[4] = 5; T_CH[5] = 5;
    T_WHR[0] = 120; T_WHR[1] = 80; T_WHR[2] = 80; T_WHR[3] = 80; T_WHR[4] = 80; T_WHR[5] = 80; T_RHW[0] = 200; T_RHW[1] = 100; T_RHW[2] = 100; T_RHW[3] = 100; T_RHW[4] = 100; T_RHW[5] = 100;
    T_RR[0] = 40; T_RR[1] = 20; T_RR[2] = 20; T_RR[3] = 20; T_RR[4] = 20; T_RR[5] = 20;  T_WW[0] = 100; T_WW[1] = 100; T_WW[2] = 100; T_WW[3] = 100; T_WW[4] = 100; T_WW[5] = 100;
    T_CLR[0] = 20; T_CLR[1] = 10; T_CLR[2] = 10; T_CLR[3] = 10; T_CLR[4] = 10; T_CLR[5] = 10;  T_AR[0] = 25; T_AR[1] = 10; T_AR[2] = 10; T_AR[3] = 10; T_AR[4] = 10; T_AR[5] = 10;
    T_RHZ[0] = 200; T_RHZ[1] = 100; T_RHZ[2] = 100; T_RHZ[3] = 100; T_RHZ[4] = 100; T_RHZ[5] = 100; T_CEA[0] = 100; T_CEA[1] = 45; T_CEA[2] = 30; T_CEA[3] = 25; T_CEA[4] = 25; T_CEA[5] = 25;
    vname[0] = "tWP"; vname[1] = "tWH"; vname[2] = "tWC"; vname[3] = "tCLS"; vname[4] = "tALS"; vname[5] = "tDS"; vname[6] = "tCLH"; vname[7] = "tALH"; vname[8] = "tDH"; vname[9] = "tCS"; vname[10] = "tCH"; vname[11] = "tWW"; vname[12] = "tRP"; vname[13] = "tREH"; vname[14] = "tRC"; vname[15] = "tWHR"; vname[16] = "tCLR"; vname[17] = "tAR"; vname[18] = "tRR"; vname[19] = "tCEA"; vname[20] = "tRHW"; vname[21] = "tRHZ"; vname[22] = "CONTENTION"; vname[23] = "MULTI_CE"; vname[24] = "STROBE_NO_CE"; vname[25] = "WE_RE_LOW"; vname[26] = "CLE_ALE"; vname[27] = "X_CONTROL"; vname[28] = "X_DQ"; vname[29] = "DQ_UNSTABLE"; vname[30] = "SEQUENCE"; vname[31] = "OUT_WHILE_BUSY"; vname[32] = "tCCS";
    for (int i = 0; i < NV; i++) viol[i] = 0;
    n_viol = 0; n_checks = 0; n_dout_total = 0; n_din_total = 0; n_cmd_total = 0; conf_n = 0;
    quiet = $test$plusargs("MON_QUIET");
    // (Icarus 12 aborts on $sformatf with a generate-derived parameter argument: copy it to a variable)
    inst_v = INST;
    tag = NAME;
    if (inst_v >= 0) tag = $sformatf("%s%0d", NAME, inst_v);
    t_we_fall = -1e9; t_we_rise = -1e9; t_re_fall = -1e9; t_re_rise = -1e9; t_cle_rise = -1e9;
    t_cle_fall = -1e9; t_ale_rise = -1e9; t_ale_fall = -1e9; t_dq_chg = -1e9; t_ce_fall = -1e9; t_wp_chg = -1e9;
    we_cle = 0; we_ale = 0; we_drv = 0; sel = -1;
    for (int c = 0; c < NUM_CE; c++) begin
      mode[c] = 0; setf_pend[c] = 0; setf_val[c] = 0; last_cmd[c] = 8'h00; n_addr[c] = 0; n_din[c] = 0;
      feat_a[c] = 0; t_rb_rise[c] = -1e9;
      for (int k = 0; k < 256; k++) cmd_cnt[c][k] = 0;
    end
    lkind = ""; lcount = 0; lbytes = ""; lce = 0; lt = 0; t_ccs = -1e9; T_CCS = 500.0;
    begin : open_log
      string fn;
      lfd = 0;
      if ($value$plusargs("MON_LOG=%s", fn)) lfd = $fopen(fn, "w");
    end
  end

  // ------------------------------------------------------------ selection
  always @(ce_n) begin : b_sel
    int n, s;
    n = 0; s = -1;
    for (int c = 0; c < NUM_CE; c++) if (ce_n[c] === 1'b0) begin n++; s = c; end
    if (((^(ce_n)) === 1'bx)) flag(V_XCTL, "CE# unknown");
    if (n > 1) flag(V_MULTI_CE, "more than one CE# low");
    if (n == 1 && sel != s) t_ce_fall = $realtime;
    if (n == 0 && sel >= 0) begin
      // CE# rising: hold after the last WE# rising edge
      if (t_we_rise > t_ce_fall) chk(V_CH, $realtime - t_we_rise, T_CH[m_of(sel)]);
    end
    sel = (n == 1) ? s : -1;
  end

  // ------------------------------------------------------------ edges
  always @(cle) begin
    if (cle === 1'b1) t_cle_rise = $realtime;
    else if (cle === 1'b0) begin
      t_cle_fall = $realtime;
      if (sel >= 0 && we_cle && t_we_rise > t_we_fall) chk(V_CLH, $realtime - t_we_rise, T_CLH[m_of(sel)]);
    end
    if (((^(cle)) === 1'bx) && sel >= 0) flag(V_XCTL, "CLE unknown");
  end
  always @(ale) begin
    if (ale === 1'b1) t_ale_rise = $realtime;
    else if (ale === 1'b0) begin
      t_ale_fall = $realtime;
      if (sel >= 0 && we_ale && t_we_rise > t_we_fall) chk(V_ALH, $realtime - t_we_rise, T_ALH[m_of(sel)]);
    end
    if (((^(ale)) === 1'bx) && sel >= 0) flag(V_XCTL, "ALE unknown");
  end
  always @(wp_n) t_wp_chg = $realtime;

  always @(dq) begin
    if (dq_oe === 1'b1 && sel >= 0) begin
      if (we_drv && we_n === 1'b1 && t_we_rise > t_re_rise && t_we_rise > t_we_fall)
        chk(V_DH, $realtime - t_we_rise, T_DH[m_of(sel)]);
      if (((^(dq)) === 1'bx)) flag(V_CONTEND, "X on DQ while the controller drives (contention)");
    end
    t_dq_chg = $realtime;
  end
  always @(posedge dq_oe) begin
    if (sel >= 0) chk(V_RHZ, $realtime - t_re_rise, T_RHZ[m_of(sel)]);
    if (re_n === 1'b0) flag(V_CONTEND, "controller drives DQ while RE# low");
  end
  always @(negedge dq_oe) begin
    if (sel >= 0 && we_drv && t_we_rise > t_we_fall) chk(V_DH, $realtime - t_we_rise, T_DH[m_of(sel)]);
  end

  always @(negedge we_n) begin
    if (sel < 0) flag(V_NOCE, "WE# low with no CE# selected");
    else begin : b_wf
      int m;
      m = m_of(sel);
      chk(V_WH, $realtime - t_we_rise, T_WH[m]);
      chk(V_WC, $realtime - t_we_fall, T_WC[m]);
      chk(V_RHW, $realtime - t_re_rise, T_RHW[m]);
      chk(V_WW, $realtime - t_wp_chg, T_WW[m]);
    end
    if (re_n === 1'b0) flag(V_WERE, "WE# low while RE# low");
    t_we_fall = $realtime;
  end

  always @(posedge we_n) begin
    if (sel >= 0) begin : b_wr
      int m;
      bit [7:0] b;
      m = m_of(sel);
      chk(V_WP, $realtime - t_we_fall, T_WP[m]);
      if (t_dq_chg > t_we_fall + 0.0005) flag(V_STABLE, "DQ changed while WE# low");
      if (cle === 1'b1) chk(V_CLS, $realtime - t_cle_rise, T_CLS[m]);
      if (ale === 1'b1) chk(V_ALS, $realtime - t_ale_rise, T_ALS[m]);
      chk(V_DS, $realtime - t_dq_chg, T_DS[m]);
      chk(V_CS, $realtime - t_ce_fall, T_CS[m]);
      if (((^({cle, ale})) === 1'bx)) flag(V_XCTL, $sformatf("CLE/ALE unknown at WE# rise (%b%b)", cle, ale));
      if (((^(dq[7:0])) === 1'bx) || dq_oe !== 1'b1) flag(V_XDQ, "DQ not driven / unknown at WE# rise");
      if (cle === 1'b1 && ale === 1'b1) flag(V_CLEALE, "CLE and ALE both high at WE# rise");
      b = dq[7:0];
      if (cle === 1'b1 && ale === 1'b0) on_cmd(b);
      else if (ale === 1'b1 && cle === 1'b0) on_addr(b);
      else if (cle === 1'b0 && ale === 1'b0) on_din(b);
    end
    we_cle = (cle === 1'b1); we_ale = (ale === 1'b1); we_drv = (dq_oe === 1'b1);
    t_we_rise = $realtime;
  end

  always @(negedge re_n) begin
    if (sel < 0) flag(V_NOCE, "RE# low with no CE# selected");
    else begin : b_rf
      int m;
      m = m_of(sel);
      chk(V_REH, $realtime - t_re_rise, T_REH[m]);
      chk(V_RC, $realtime - t_re_fall, T_RC[m]);
      chk(V_WHR, $realtime - t_we_rise, T_WHR[m]);
      if (cle !== 1'b0) flag(V_SEQ, "CLE high at RE# fall");
      else chk(V_CLR, $realtime - t_cle_fall, T_CLR[m]);
      if (ale !== 1'b0) flag(V_SEQ, "ALE high at RE# fall");
      else chk(V_AR, $realtime - t_ale_fall, T_AR[m]);
      chk(V_RR, $realtime - t_rb_rise[sel], T_RR[m]);
      if (last_cmd[sel] == 8'hE0) chk(V_CCS, $realtime - t_ccs, T_CCS);
      if (dq_oe !== 1'b0) flag(V_CONTEND, "RE# low while the controller drives DQ");
      on_dout_start();
    end
    if (we_n === 1'b0) flag(V_WERE, "RE# low while WE# low");
    t_re_fall = $realtime;
  end

  always @(posedge re_n) begin
    if (sel >= 0) begin : b_rr
      int m;
      m = m_of(sel);
      chk(V_RP, $realtime - t_re_fall, T_RP[m]);
      chk(V_CEA, $realtime - t_ce_fall, T_CEA[m]);
      if (((^(dq)) === 1'bx)) flag(V_XDQ, $sformatf("DQ unknown when sampled (%h)", dq));
      n_dout_total++;
      log_ev("DOUT", dq[7:0]);
    end
    t_re_rise = $realtime;
  end

  for (genvar g = 0; g < NUM_CE; g++) begin : g_rb
    always @(posedge rb_n[g]) begin
      t_rb_rise[g] = $realtime;
      if (setf_pend[g]) begin
        mode[g] = setf_val[g];
        setf_pend[g] = 0;
      end
    end
  end

  always @(negedge vcc_ok) for (int c = 0; c < NUM_CE; c++) begin mode[c] = 0; setf_pend[c] = 0; end

  // ------------------------------------------------------------ decoder
  task automatic on_cmd(input bit [7:0] c);
    int t;
    t = sel;
    n_cmd_total++;
    cmd_cnt[t][c]++;
    log_ev("CMD", c);
    case (c)
      8'h30: begin
        if (!(last_cmd[t] == 8'h00 && n_addr[t] == 5)) flag(V_SEQ, "30h without 00h + 5 address cycles");
        conf_log(t, c);
      end
      8'h10: begin
        if (!(last_cmd[t] == 8'h80 && n_addr[t] == 5 && n_din[t] > 0)) flag(V_SEQ, "10h without 80h + 5 addr + data");
        conf_log(t, c);
      end
      8'hD0: begin
        if (!(last_cmd[t] == 8'h60 && n_addr[t] == 3)) flag(V_SEQ, "D0h without 60h + 3 address cycles");
        conf_log(t, c);
      end
      8'hE0: begin
        if (!(last_cmd[t] == 8'h05 && n_addr[t] == 2)) flag(V_SEQ, "E0h without 05h + 2 column cycles");
        t_ccs = $realtime;
      end
      8'h00, 8'h05, 8'h80, 8'h60, 8'h70, 8'h78, 8'h90, 8'hEC, 8'hEE, 8'hEF, 8'hFF: ;
      default: flag(V_SEQ, $sformatf("unexpected command %02x", c));
    endcase
    last_cmd[t] = c; n_addr[t] = 0; n_din[t] = 0;
  endtask

  task automatic conf_log(input int t, input bit [7:0] c);
    if (conf_n < 4096) begin conf_op[conf_n] = c; conf_ce[conf_n] = t; end
    conf_n++;
  endtask

  task automatic on_addr(input bit [7:0] a);
    int t, lim;
    t = sel;
    log_ev("ADDR", a);
    case (last_cmd[t])
      8'h00, 8'h80: lim = 5;
      8'h60, 8'h78: lim = 3;
      8'h05: lim = 2;
      8'h90, 8'hEC, 8'hEE, 8'hEF: lim = 1;
      default: lim = 0;
    endcase
    if (n_addr[t] >= lim) flag(V_SEQ, $sformatf("unexpected address cycle after %02x", last_cmd[t]));
    if (n_addr[t] == 0) feat_a[t] = a;
    n_addr[t]++;
  endtask

  task automatic on_din(input bit [7:0] d);
    int t;
    t = sel;
    n_din_total++;
    log_ev("DIN", d);
    if (last_cmd[t] == 8'h80 && n_addr[t] == 5) n_din[t]++;
    else if (last_cmd[t] == 8'hEF && n_addr[t] == 1 && n_din[t] < 4) begin
      if (n_din[t] == 0) setf_val[t] = d[3:0];
      n_din[t]++;
      if (n_din[t] == 4 && feat_a[t] == 8'h01) setf_pend[t] = 1;
    end else flag(V_SEQ, $sformatf("unexpected data-input cycle after %02x", last_cmd[t]));
  endtask

  task automatic on_dout_start();
    int t;
    bit ok;
    t = sel;
    case (last_cmd[t])
      8'h70, 8'h30, 8'hE0: ok = 1;
      8'h00: ok = (n_addr[t] == 0);
      8'h78: ok = (n_addr[t] == 3);
      8'h90, 8'hEC, 8'hEE: ok = (n_addr[t] == 1);
      default: ok = 0;
    endcase
    if (!ok) flag(V_SEQ, $sformatf("data output after %02x with %0d address cycles", last_cmd[t], n_addr[t]));
    if (PER_CE_RB != 0 && rb_n[t] === 1'b0 && (last_cmd[t] == 8'h30 || last_cmd[t] == 8'hEC || last_cmd[t] == 8'hEE))
      flag(V_BUSYOUT, "data output while R/B# low");
  endtask

  // ------------------------------------------------------------ reporting
  function automatic int cmds(input int c, input bit [7:0] op);
    cmds = cmd_cnt[c][op];
  endfunction

  task automatic report(input int fd);
    log_flush();
    $fdisplay(fd, "MONITOR %s checks %0d violations %0d (cmd %0d din %0d dout %0d)", tag, n_checks, n_viol,
              n_cmd_total, n_din_total, n_dout_total);
    for (int i = 0; i < NV; i++) if (viol[i] != 0) $fdisplay(fd, "MONITOR %s   %s %0d", tag, vname[i], viol[i]);
  endtask
endmodule
