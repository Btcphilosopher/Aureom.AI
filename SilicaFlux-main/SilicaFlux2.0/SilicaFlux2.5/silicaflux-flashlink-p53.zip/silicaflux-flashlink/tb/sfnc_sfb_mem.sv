// =============================================================================
// sfnc_sfb_mem.sv -- SilicaFlux FlashLink, Project 53 (testbench)
// -----------------------------------------------------------------------------
// SFB2 slave memory standing in for the page-buffer SRAM behind the DataFabric.
//   * byte array mem[], little-endian lanes, byte strobes (R10)
//   * random request stalls (stall_pct) and response latency lat_min..lat_max
//   * error window [err_lo, err_hi): rsp_error, rdata 0, no side effect (R8)
//   * one transaction at a time (the controller tracks one outstanding)
//   * protocol checks on the master: R2 (request stable until accepted),
//     R9 (DW alignment); response delivered >= 1 cycle after acceptance (R5)
// Classification: TESTBENCH
// =============================================================================
`timescale 1ns/1ps

module sfnc_sfb_mem #(
  parameter int DW    = 32,
  parameter int BYTES = 65536
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          req_valid,
  output logic          req_ready,
  input  logic          req_write,
  input  logic [31:0]   req_addr,
  input  logic [DW-1:0] req_wdata,
  input  logic [DW/8-1:0] req_wstrb,
  output logic          rsp_valid,
  input  logic          rsp_ready,
  output logic [DW-1:0] rsp_rdata,
  output logic          rsp_error
);
  localparam int WB = DW / 8;
  bit [7:0] mem [0:BYTES-1];
  int stall_pct, lat_min, lat_max;
  int unsigned err_lo, err_hi;
  int n_reads, n_writes, n_errors, n_proto;
  int unsigned seed;

  bit busy;
  int lat_cnt;
  bit p_valid;
  bit [31:0] p_addr;
  bit [DW-1:0] p_wdata;
  bit [WB-1:0] p_wstrb;
  bit p_write;

  initial begin
    stall_pct = 0; lat_min = 1; lat_max = 1; err_lo = 0; err_hi = 0; seed = 32'h5F1C_AF53;
    n_reads = 0; n_writes = 0; n_errors = 0; n_proto = 0;
    for (int i = 0; i < BYTES; i++) mem[i] = 8'h00;
  end

  function automatic int unsigned rnd(input int unsigned m);
    seed = seed * 32'd1664525 + 32'd1013904223;
    rnd = (m == 0) ? 0 : ((seed >> 8) % m);
  endfunction

  bit stall_now;
  always @(negedge clk) stall_now = (stall_pct > 0) && (rnd(100) < stall_pct);
  assign req_ready = rst_n && !busy && !stall_now;

  bit [DW-1:0] rd;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= 0; rsp_valid <= 0; rsp_rdata <= '0; rsp_error <= 0; p_valid <= 0; lat_cnt <= 0;
    end else begin
      // R2: a presented, not accepted request must stay unchanged
      if (p_valid && (!req_valid || req_addr !== p_addr || req_write !== p_write ||
                      (p_write && (req_wdata !== p_wdata || req_wstrb !== p_wstrb)))) begin
        n_proto++;
        $display("[SFBMEM %0t] PROTOCOL R2: request changed or withdrawn before acceptance", $realtime);
      end
      p_valid <= req_valid && !req_ready;
      p_addr <= req_addr; p_write <= req_write; p_wdata <= req_wdata; p_wstrb <= req_wstrb;
      if (rsp_valid && rsp_ready) begin
        rsp_valid <= 0;
        busy <= 0;
      end
      if (req_valid && req_ready) begin
        if (req_addr[$clog2(WB)-1:0] != 0) begin
          n_proto++;
          $display("[SFBMEM %0t] PROTOCOL R9: misaligned address %h", $realtime, req_addr);
        end
        busy <= 1;
        lat_cnt <= lat_min + rnd(lat_max - lat_min + 1);
        if (req_addr >= err_lo && req_addr < err_hi) begin
          rsp_error <= 1; rd = '0; n_errors++;
        end else begin
          rsp_error <= 0;
          for (int b = 0; b < WB; b++) begin
            if (req_write && req_wstrb[b] && (req_addr + b) < BYTES) mem[req_addr + b] = req_wdata[b*8 +: 8];
            rd[b*8 +: 8] = ((req_addr + b) < BYTES) ? mem[req_addr + b] : 8'h00;
          end
          if (req_write) n_writes++; else n_reads++;
        end
        rsp_rdata <= req_write ? '0 : rd;
      end else if (busy && !rsp_valid) begin
        if (lat_cnt <= 1) rsp_valid <= 1;
        else lat_cnt <= lat_cnt - 1;
      end
    end
  end
endmodule
