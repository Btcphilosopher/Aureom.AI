// =============================================================================
// print_timing.sv -- SilicaFlux FlashLink, Project 53 (utility)
// Prints, from silicaflux_nand_timing_pkg itself, the ONFI-style table (ns) and
// the controller cycle counts for several clock periods, as Markdown.
//   iverilog -g2012 -o pt.vvp rtl/silicaflux_nand_timing_pkg.sv tb/print_timing.sv && vvp pt.vvp
// =============================================================================
module print_timing;
  import silicaflux_nand_timing_pkg::*;
  localparam int NCLK = 4;
  int clks [0:NCLK-1];
  string pn [0:24];
  initial begin
    logic [127:0] w;
    clks[0] = 5000; clks[1] = 10000; clks[2] = 20000; clks[3] = 7500;
    pn[0] = "tWP"; pn[1] = "tWH"; pn[2] = "tWC"; pn[3] = "tRP"; pn[4] = "tREH"; pn[5] = "tRC"; pn[6] = "tREA (max)";
    pn[7] = "tCLS"; pn[8] = "tALS"; pn[9] = "tDS"; pn[10] = "tCLH"; pn[11] = "tALH"; pn[12] = "tDH"; pn[13] = "tCS";
    pn[14] = "tCH"; pn[15] = "tWHR"; pn[16] = "tADL"; pn[17] = "tRHW"; pn[18] = "tRR"; pn[19] = "tWB (max)";
    pn[20] = "tWW"; pn[21] = "tCLR"; pn[22] = "tAR"; pn[23] = "tRHZ (max)"; pn[24] = "tCEA (max)";
    $display("## ONFI-style asynchronous timing table used by the controller (ns)\n");
    $display("| Parameter | mode 0 | mode 1 | mode 2 | mode 3 | mode 4 | mode 5 |");
    $display("|---|---|---|---|---|---|---|");
    for (int p = 0; p < 25; p++)
      $display("| %s | %0d | %0d | %0d | %0d | %0d | %0d |", pn[p], onfi_ns(0, p), onfi_ns(1, p), onfi_ns(2, p),
               onfi_ns(3, p), onfi_ns(4, p), onfi_ns(5, p));
    for (int c = 0; c < NCLK; c++) begin
      $display("\n## Controller cycle counts at %0d ps (%0.1f MHz), capture margin 2000 ps, 2-flop R/B# sync\n",
               clks[c], 1.0e6 / clks[c]);
      $display("| Mode | su | wp | wh | rp | reh | whr | adl | rhw | cs | ch | ww | wb | rr | write cycle (ns) | read cycle (ns) |");
      $display("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|");
      for (int m = 0; m < 6; m++) begin
        w = mode_word(m, clks[c], 2000, 2);
        $display("| %0d | %0d | %0d | %0d | %0d | %0d | %0d | %0d | %0d | %0d | %0d | %0d | %0d | %0d | %0.1f | %0.1f |", m,
                 w[F_SU +: 8], w[F_WP +: 8], w[F_WH +: 8], w[F_RP +: 8], w[F_REH +: 8], w[F_WHR +: 8], w[F_ADL +: 8],
                 w[F_RHW +: 8], w[F_CS +: 8], w[F_CH +: 8], w[F_WW +: 8], w[F_WB +: 8], w[F_RR +: 8],
                 (w[F_SU +: 8] + w[F_WP +: 8] + w[F_WH +: 8]) * clks[c] / 1000.0,
                 (w[F_RP +: 8] + w[F_REH +: 8]) * clks[c] / 1000.0);
      end
    end
  end
endmodule
