// =============================================================================
// nand_flash_model.sv -- SilicaFlux NANDLab, Project 52 (Aureom.AI | SilicaFlux-STORE)
// -----------------------------------------------------------------------------
// Behavioural, persistent, fault-injectable model of ONE NAND flash target
// (one CE#) with an ONFI-style asynchronous (SDR) pin interface, for
// verifying the SilicaFlux storage controller.
//
//   * This models EXTERNAL memory devices. It is not a claim that SilicaFlux
//     fabricates NAND cells. All timing/reliability numbers are illustrative
//     (see MODEL_LIMITATIONS.md); the ONFI structures are a subset and no ONFI
//     compliance is claimed.
//   * SLC semantics: erased cells read 1, PROGRAM can only clear 1->0, ERASE
//     works on whole blocks. Invalid 0->1 requests are rejected (configurable).
//   * Array state persists in an NLSF journal (<dir>/target<ID>.nlsf), the same
//     format as nand_flash_twin.py. Controller reset and process restart never
//     restore erased data; power loss leaves partially programmed/erased cells.
//   * Faults (wear, retention, read disturb, read noise, program/erase fail,
//     factory bad blocks, stuck bits, interrupted ops) use the same integer
//     splitmix64 hashing and floating-point formulas as nand_flash_twin.py, so
//     the Python twin reproduces this model bit-exactly from its trace
//     (<dir>/target<ID>.trace) -- see `nand_flash_twin.py sv-regress`.
//
// Plusargs:  +NANDLAB_DIR=<dir>  (store, nandlab.svcfg, trace; default ".")
//            +NANDLAB_BAKE_HOURS=<h> +NANDLAB_BAKE_TEMP_C=<c>  (unpowered time before power-on)
//            +NANDLAB_NOTRACE  +NANDLAB_QUIET
// Supported commands: FFh, 90h, ECh, 00h-30h, 05h-E0h, 80h(-85h)-10h, 60h-D0h,
//            70h, 78h, EFh, EEh.  Not modelled: cache/multi-plane/copyback.
// Portable SV subset: Icarus Verilog 12 (-g2012) and Verilator 5 (--timing).
// =============================================================================
`timescale 1ns/1ps

package nand_flash_pkg;
  // ---- ONFI command opcodes ----
  localparam bit [7:0] CMD_READ1 = 8'h00, CMD_READ2 = 8'h30, CMD_CRC1 = 8'h05, CMD_CRC2 = 8'hE0;
  localparam bit [7:0] CMD_PROG1 = 8'h80, CMD_PROG2 = 8'h10, CMD_CWC = 8'h85;
  localparam bit [7:0] CMD_ERASE1 = 8'h60, CMD_ERASE2 = 8'hD0;
  localparam bit [7:0] CMD_STATUS = 8'h70, CMD_STATUS_ENH = 8'h78, CMD_READID = 8'h90;
  localparam bit [7:0] CMD_PARAM = 8'hEC, CMD_GETF = 8'hEE, CMD_SETF = 8'hEF, CMD_RESET = 8'hFF;
  // ---- status register ----
  localparam bit [7:0] ST_FAIL = 8'h01, ST_FAILC = 8'h02, ST_ARDY = 8'h20, ST_RDY = 8'h40, ST_WP_N = 8'h80;
  // ---- feature addresses ----
  localparam bit [7:0] FEAT_TIMING_MODE = 8'h01, FEAT_READ_RETRY = 8'hA0;
  // ---- page / block flags (identical to nand_flash_twin.py) ----
  localparam bit [7:0] PF_PROG_FAILED = 8'h02, PF_PROG_INTERRUPTED = 8'h04, PF_FACTORY_MARKER = 8'h08;
  localparam bit [7:0] PF_PARTIAL_ERASE = 8'h10, PF_UNSTABLE = 8'h16;
  localparam bit [7:0] BF_FACTORY_BAD = 8'h01, BF_ERASE_FAILED = 8'h02, BF_PROG_FAILED = 8'h04;
  localparam bit [7:0] BF_WORN_OUT = 8'h08, BF_MARGINAL = 8'h10, BF_ERASE_INTERRUPTED = 8'h20;
  // ---- result codes ----
  localparam int RC_OK = 0, RC_FAIL_RANDOM = 1, RC_FAIL_FORCED = 2, RC_FAIL_BAD_BLOCK = 3, RC_FAIL_WORN = 4;
  localparam int RC_REJECT_TRANSITION = 5, RC_REJECT_NOP = 6, RC_REJECT_SEQUENCE = 7;
  localparam int RC_REJECT_ADDRESS = 8, RC_WP = 9;
  localparam int OP_NONE = 0, OP_READ = 1, OP_PROG = 2, OP_ERASE = 3;
  localparam int TOP_NONE = 0, TOP_RESET = 1, TOP_PARAM = 2, TOP_GETF = 3, TOP_SETF = 4;
  localparam int OM_NONE = 0, OM_DATA = 1, OM_STATUS = 2, OM_ID = 3, OM_PARAM = 4, OM_FEAT = 5;
  // ---- hashing (splitmix64) and domains ----
  localparam bit [63:0] GOLDEN = 64'h9E3779B97F4A7C15, MIX1 = 64'hBF58476D1CE4E5B9, MIX2 = 64'h94D049BB133111EB;
  localparam bit [63:0] D_TARGET = 64'h4E414E444C414231, D_PERSIST = 64'h5745414B43454C4C;
  localparam bit [63:0] D_NOISE = 64'h524541444E4F4953, D_PFAIL = 64'h50524F474641494C;
  localparam bit [63:0] D_EFAIL = 64'h4552415345464C30, D_PPART = 64'h50524F4750415254;
  localparam bit [63:0] D_EPART = 64'h4552415350415254, D_FBAD = 64'h464143544F525942;

  function automatic bit [63:0] mix64(input bit [63:0] x);
    bit [63:0] z;
    z = x + GOLDEN;
    z = (z ^ (z >> 30)) * MIX1;
    z = (z ^ (z >> 27)) * MIX2;
    return z ^ (z >> 31);
  endfunction

  function automatic bit [63:0] hk(input bit [63:0] k, input bit [63:0] f);
    return mix64(k ^ f);
  endfunction

  // probability -> 32-bit threshold; cell affected iff (hash >> 32) < thr32(p)
  function automatic bit [63:0] thr32(input real p);
    if (!(p > 0.0)) return 64'd0;
    if (p >= 1.0) return 64'd4294967296;
    return 64'(longint'($floor(p * 4294967296.0)));
  endfunction

  function automatic real arrhenius(input real ea, input real tref_c, input real t_c);
    return $exp((ea / 8.617333262e-5) * (1.0 / (tref_c + 273.15) - 1.0 / (t_c + 273.15)));
  endfunction

  function automatic bit rc_executes(input int rc);
    return (rc == RC_OK) || (rc == RC_FAIL_RANDOM) || (rc == RC_FAIL_FORCED) || (rc == RC_FAIL_WORN);
  endfunction

  function automatic bit [15:0] onfi_crc16_step(input bit [15:0] crc, input bit [7:0] b);
    bit [15:0] c;
    bit fb;
    c = crc;
    for (int i = 7; i >= 0; i--) begin
      fb = c[15] ^ b[i];
      c = {c[14:0], 1'b0};
      if (fb) c = c ^ 16'h8005;
    end
    return c;
  endfunction
endpackage


module nand_flash_model #(
  parameter int PAGE_DATA_BYTES  = 512,
  parameter int PAGE_SPARE_BYTES = 16,
  parameter int PAGES_PER_BLOCK  = 16,
  parameter int BLOCKS_PER_PLANE = 32,
  parameter int PLANES_PER_LUN   = 2,
  parameter int LUNS             = 2,
  parameter int TARGET_ID        = 0,
  parameter int POOL_PAGES       = 0      // 0 -> room for every page of the target
) (
  input  logic       ce_n,
  input  logic       cle,
  input  logic       ale,
  input  logic       we_n,
  input  logic       re_n,
  input  logic       wp_n,
  input  logic [7:0] dq_in,
  output logic [7:0] dq_out,
  output logic       dq_oe,
  output logic       rb_n,
  input  logic       vcc_ok
);
  import nand_flash_pkg::*;

  // ---------------------------------------------------------------- geometry
  localparam int PAGE_BYTES     = PAGE_DATA_BYTES + PAGE_SPARE_BYTES;
  localparam int PAGE_BITS      = PAGE_BYTES * 8;
  localparam int BLOCKS_PER_LUN = PLANES_PER_LUN * BLOCKS_PER_PLANE;
  localparam int TOTAL_BLOCKS   = LUNS * BLOCKS_PER_LUN;
  localparam int TOTAL_PAGES    = TOTAL_BLOCKS * PAGES_PER_BLOCK;
  localparam int NPOOL          = (POOL_PAGES > 0) ? POOL_PAGES : TOTAL_PAGES;
  localparam int RP_BITS        = (PAGES_PER_BLOCK > 1) ? $clog2(PAGES_PER_BLOCK) : 0;
  localparam int RB_BITS        = (BLOCKS_PER_LUN > 1) ? $clog2(BLOCKS_PER_LUN) : 0;
  localparam int LINE_CHARS     = PAGE_BYTES * 3 + 256;
  localparam int MAX_DIRECTED   = 64;

  // ------------------------------------------------------------ array state
  bit [7:0] pool      [0:NPOOL*PAGE_BYTES-1];   // sparse page storage
  int       slot_of   [0:TOTAL_PAGES-1];        // -1 = erased (reads all 1s)
  int       free_list [0:NPOOL-1];
  int       free_top;
  int       pg_nop    [0:TOTAL_PAGES-1];
  bit [7:0] pg_flags  [0:TOTAL_PAGES-1];
  real      pg_tprog  [0:TOTAL_PAGES-1];
  int       blk_ec    [0:TOTAL_BLOCKS-1];
  bit [7:0] blk_flags [0:TOTAL_BLOCKS-1];
  int       blk_reads [0:TOTAL_BLOCKS-1];
  real      clock_base;                         // retention clock (s @ reference temperature)

  // ---------------------------------------------------- per-LUN volatile state
  bit [7:0] preg      [0:LUNS*PAGE_BYTES-1];    // page register (data in / out)
  bit       pmask     [0:LUNS*PAGE_BYTES-1];    // byte loaded since 80h
  bit [7:0] sbuf      [0:LUNS*PAGE_BYTES-1];    // sensed data, moved to preg at completion
  bit [7:0] fmask     [0:PAGE_BYTES-1];         // scratch flip mask
  bit       lun_busy  [0:LUNS-1];
  bit       op_started[0:LUNS-1];
  int       op_kind   [0:LUNS-1];
  int       op_rc     [0:LUNS-1];
  int       op_blk    [0:LUNS-1];
  int       op_pg     [0:LUNS-1];
  int       op_ec     [0:LUNS-1];
  int       op_nop    [0:LUNS-1];
  int       op_gen    [0:LUNS-1];
  int       op_seq    [0:LUNS-1];
  real      op_start  [0:LUNS-1];
  real      op_dur    [0:LUNS-1];
  real      op_ff     [0:LUNS-1];
  bit       fail_b    [0:LUNS-1];
  bit       failc_b   [0:LUNS-1];

  // ------------------------------------------------- interface / target state
  bit       init_done, powered, needs_reset, poweron_pending;
  bit [7:0] cur_cmd;
  bit       cmd_valid;
  int       addr_cnt;
  bit [7:0] addr_b [0:7];
  int       out_mode, data_src_param;
  int       col, out_ptr;
  int       sel_lun, prog_lun, prog_blk, prog_pg, rd_lun, rd_blk, rd_pg, er_lun, er_blk;
  bit       prog_active, prog_first_data, read_overrun_warned;
  bit [7:0] id_addr, feat_addr;
  bit [7:0] feat_in [0:3];
  bit [7:0] feat_out [0:3];
  int       feat_cnt;
  bit       tgt_busy, tgt_busy_started;
  int       tgt_gen, tgt_kind;
  int       timing_mode, retry_level, seq;
  bit [7:0] param_page [0:767];
  bit [7:0] id_bytes [0:4];
  bit       prev_rb_busy;
  bit [7:0] out_v;
  bit       out_valid;
  event     kick_ev;                            // Icarus-only fork dispatcher
  bit       kick_tgt;
  int       kick_lun, kick_gen, kick_tkind;
  real      kick_dur;

  // ---------------------------------------------------------------- config
  string    dir, store_path, cfg_path, trace_path, profile, config_fp, mfr_name, model_name;
  bit [63:0] global_seed, tseed;
  int       nop_max, sequential, invalid_policy, factory_bad_erase, require_reset, bbm_byte;
  int       max_bad_per_lun, ecc_bits, timing_checks, timing_fatal, erase_fail_sticky;
  int       persist_read_counts, retry_max_level;
  real      t_r_ns, t_prog_ns, t_bers_ns, t_rst_idle_ns, t_rst_prog_ns, t_rst_erase_ns, t_rst_poweron_ns;
  real      t_feat_ns, t_reject_ns, t_ccs_ns, prog_time_wear_speedup, prog_time_floor;
  real      erase_time_wear_slowdown, fail_time_factor;
  real      rated_endurance, hard_limit_factor, rber_fresh, rber_wear_at_rated, wear_exponent;
  real      retention_rber_ref, retention_ref_hours, retention_exponent, retention_wear_gain;
  real      read_disturb_rber_ref, read_disturb_ref_reads, read_disturb_wear_gain;
  real      read_noise_rber, interrupted_rber;
  real      prog_fail_fresh, prog_fail_at_rated, prog_fail_exponent;
  real      erase_fail_fresh, erase_fail_at_rated, erase_fail_exponent;
  real      prog_fail_partial, erase_fail_partial, factory_bad_rate, retry_gain;
  real      ea_ev, ref_temp_c, op_temp_c, af_op;
  int       n_fbad, n_fprog, n_ferase, n_stuck;
  int       fbad_l [0:MAX_DIRECTED-1], fbad_b [0:MAX_DIRECTED-1];
  int       fprog_l [0:MAX_DIRECTED-1], fprog_b [0:MAX_DIRECTED-1], fprog_p [0:MAX_DIRECTED-1];
  int       ferase_l [0:MAX_DIRECTED-1], ferase_b [0:MAX_DIRECTED-1];
  int       stuck_l [0:MAX_DIRECTED-1], stuck_b [0:MAX_DIRECTED-1], stuck_p [0:MAX_DIRECTED-1];
  int       stuck_bit [0:MAX_DIRECTED-1], stuck_val [0:MAX_DIRECTED-1];

  // ---------------------------------------------- timing tables (ONFI async)
  real T_WC [0:5], T_WP [0:5], T_WH [0:5], T_RC [0:5], T_RP [0:5], T_REH [0:5], T_REA [0:5];
  real T_CLS [0:5], T_ALS [0:5], T_DS [0:5], T_WB [0:5], T_WHR [0:5], T_ADL [0:5], T_RR [0:5];
  real last_we_fall, last_we_rise, last_re_fall, last_re_rise, last_cle_chg, last_ale_chg;
  real last_dq_chg, last_rb_rise, last_addr_rise, last_ccs_t;
  bit  first_re_after_cmd, ccs_pending;

  // ------------------------------------------------------------- statistics
  int  n_proto_errors, n_timing_violations, n_reads, n_programs, n_erases, n_bit_flips, n_torn;
  bit  quiet, notrace;
  int  jfd, tfd;

  // =========================================================== utilities
  function automatic int bidx(input int lun, input int blk);
    return lun * BLOCKS_PER_LUN + blk;
  endfunction

  function automatic int pidx(input int lun, input int blk, input int pg);
    return (lun * BLOCKS_PER_LUN + blk) * PAGES_PER_BLOCK + pg;
  endfunction

  function automatic bit [7:0] cell_byte(input int pi, input int c);
    if (slot_of[pi] < 0) return 8'hFF;
    return pool[slot_of[pi] * PAGE_BYTES + c];
  endfunction

  function automatic real clock_at(input real t_ns);
    return clock_base + (t_ns * 1.0e-9) * af_op;
  endfunction

  function automatic real cn(input int ec);
    if (rated_endurance > 0.0) return $itor(ec) / rated_endurance;
    return 0.0;
  endfunction

  function automatic real p_wear(input int ec);
    return rber_fresh + rber_wear_at_rated * $pow(cn(ec), wear_exponent);
  endfunction

  function automatic real p_ret(input real age_h, input int ec);
    if (age_h <= 0.0 || retention_ref_hours <= 0.0) return 0.0;
    return retention_rber_ref * $pow(age_h / retention_ref_hours, retention_exponent) *
           (1.0 + retention_wear_gain * cn(ec));
  endfunction

  function automatic real p_rd(input int reads, input int ec);
    if (read_disturb_ref_reads <= 0.0) return 0.0;
    return read_disturb_rber_ref * ($itor(reads) / read_disturb_ref_reads) *
           (1.0 + read_disturb_wear_gain * cn(ec));
  endfunction

  function automatic real p_prog_fail(input int ec);
    return prog_fail_fresh + prog_fail_at_rated * $pow(cn(ec), prog_fail_exponent);
  endfunction

  function automatic real p_erase_fail(input int ec);
    return erase_fail_fresh + erase_fail_at_rated * $pow(cn(ec), erase_fail_exponent);
  endfunction

  function automatic real t_prog_eff(input int ec);
    real f;
    f = 1.0 - prog_time_wear_speedup * cn(ec);
    if (f < prog_time_floor) f = prog_time_floor;
    return t_prog_ns * f;
  endfunction

  function automatic real t_erase_eff(input int ec);
    return t_bers_ns * (1.0 + erase_time_wear_slowdown * cn(ec));
  endfunction

  function automatic bit worn(input int ec);
    return (hard_limit_factor > 0.0) && ($itor(ec) >= hard_limit_factor * rated_endurance);
  endfunction

  function automatic int highest_programmed(input int lun, input int blk);
    int hp;
    hp = -1;
    for (int p = 0; p < PAGES_PER_BLOCK; p++)
      if (pg_nop[pidx(lun, blk, p)] > 0) hp = p;
    return hp;
  endfunction

  function automatic bit is_forced_prog(input int lun, input int blk, input int pg);
    bit f;
    f = 0;
    for (int i = 0; i < n_fprog; i++)
      if (fprog_l[i] == lun && fprog_b[i] == blk && fprog_p[i] == pg) f = 1;
    return f;
  endfunction

  function automatic bit is_forced_erase(input int lun, input int blk);
    bit f;
    f = 0;
    for (int i = 0; i < n_ferase; i++)
      if (ferase_l[i] == lun && ferase_b[i] == blk) f = 1;
    return f;
  endfunction

  function automatic bit [7:0] status_byte(input int lun);
    bit [7:0] st;
    st = wp_n ? ST_WP_N : 8'h00;
    if (!lun_busy[lun] && !tgt_busy) st = st | ST_RDY | ST_ARDY;
    if (fail_b[lun])  st = st | ST_FAIL;
    if (failc_b[lun]) st = st | ST_FAILC;
    return st;
  endfunction

  function automatic real tWB_now();
    return T_WB[timing_mode];
  endfunction

  task automatic msg(input string s);
    if (!quiet) $display("[NANDLAB tgt%0d %0t] %s", TARGET_ID, $realtime, s);
  endtask

  task automatic proto_err(input string s);
    n_proto_errors++;
    $display("[NANDLAB tgt%0d %0t] PROTOCOL: %s", TARGET_ID, $realtime, s);
  endtask

  task automatic timing_err(input string name, input real got, input real need);
    n_timing_violations++;
    if (n_timing_violations <= 20)
      $display("[NANDLAB tgt%0d %0t] TIMING: %s = %0.3f ns < %0.3f ns (mode %0d)",
               TARGET_ID, $realtime, name, got, need, timing_mode);
    if (timing_fatal != 0) $fatal(1, "NANDLAB timing violation");
  endtask

  // ------------------------------------------------------------ page pool
  task automatic ensure_slot(input int pi);
    int s;
    if (slot_of[pi] < 0) begin
      if (free_top == 0) $fatal(1, "NANDLAB: page pool exhausted (raise POOL_PAGES)");
      free_top = free_top - 1;
      s = free_list[free_top];
      slot_of[pi] = s;
      for (int i = 0; i < PAGE_BYTES; i++) pool[s * PAGE_BYTES + i] = 8'hFF;
    end
  endtask

  task automatic free_page(input int pi);
    if (slot_of[pi] >= 0) begin
      free_list[free_top] = slot_of[pi];
      free_top = free_top + 1;
      slot_of[pi] = -1;
    end
    pg_nop[pi] = 0;
    pg_flags[pi] = 8'h00;
    pg_tprog[pi] = 0.0;
  endtask

  // ============================================================== journal
  task automatic j_P(input int lun, input int blk, input int pg);
    int pi;
    pi = pidx(lun, blk, pg);
    $fwrite(jfd, "P %0d %0d %0d %0d %02x %.17g", lun, blk, pg, pg_nop[pi], pg_flags[pi], pg_tprog[pi]);
    for (int i = 0; i < PAGE_BYTES; i++) $fwrite(jfd, " %02x", cell_byte(pi, i));
    $fwrite(jfd, " ;\n");
    $fflush(jfd);
  endtask

  task automatic j_B(input int lun, input int blk);
    int bi;
    bi = bidx(lun, blk);
    $fwrite(jfd, "B %0d %0d %0d %02x %0d ;\n", lun, blk, blk_ec[bi], blk_flags[bi], blk_reads[bi]);
    $fflush(jfd);
  endtask

  task automatic j_R(input int lun, input int blk);
    $fwrite(jfd, "R %0d %0d %0d ;\n", lun, blk, blk_reads[bidx(lun, blk)]);
    $fflush(jfd);
  endtask

  task automatic j_E(input int lun, input int blk, input real clk);
    $fwrite(jfd, "E %0d %0d %.17g ;\n", lun, blk, clk);
    $fflush(jfd);
  endtask

  task automatic j_C(input real clk);
    $fwrite(jfd, "C %.17g ;\n", clk);
    $fflush(jfd);
  endtask

  // ================================================================ trace
  task automatic tr_data(input int lun, input bit use_mask);
    for (int i = 0; i < PAGE_BYTES; i++) begin
      if (use_mask && !pmask[lun * PAGE_BYTES + i]) $fwrite(tfd, " --");
      else if (use_mask) $fwrite(tfd, " %02x", preg[lun * PAGE_BYTES + i]);
      else $fwrite(tfd, " %02x", sbuf[lun * PAGE_BYTES + i]);
    end
  endtask

  // ====================================================== configuration
  task automatic set_defaults();
    nop_max = 4; sequential = 1; invalid_policy = 0; factory_bad_erase = 0; require_reset = 1;
    bbm_byte = 0; max_bad_per_lun = (BLOCKS_PER_LUN / 25 > 1) ? BLOCKS_PER_LUN / 25 : 1; ecc_bits = 4;
    timing_checks = 1; timing_fatal = 0; erase_fail_sticky = 1; persist_read_counts = 1; retry_max_level = 7;
    global_seed = 64'h00005F1CAF10C552; profile = "nominal"; config_fp = "builtin-defaults";
    mfr_name = "SILICAFLUX"; model_name = "NANDLAB-SLC-TWIN";
    id_bytes[0] = 8'h00; id_bytes[1] = 8'h5A; id_bytes[2] = 8'h00; id_bytes[3] = 8'h15; id_bytes[4] = 8'h00;
    timing_mode = 0;
    t_r_ns = 25000.0; t_prog_ns = 200000.0; t_bers_ns = 2000000.0; t_rst_idle_ns = 5000.0;
    t_rst_prog_ns = 10000.0; t_rst_erase_ns = 500000.0; t_rst_poweron_ns = 1000000.0;
    t_feat_ns = 1000.0; t_reject_ns = 2000.0; t_ccs_ns = 500.0;
    prog_time_wear_speedup = 0.2; prog_time_floor = 0.6; erase_time_wear_slowdown = 1.0; fail_time_factor = 3.0;
    rated_endurance = 100000.0; hard_limit_factor = 3.0; rber_fresh = 1.0e-10; rber_wear_at_rated = 1.0e-7;
    wear_exponent = 2.0; retention_rber_ref = 1.0e-8; retention_ref_hours = 8760.0; retention_exponent = 1.0;
    retention_wear_gain = 50.0; read_disturb_rber_ref = 1.0e-8; read_disturb_ref_reads = 100000.0;
    read_disturb_wear_gain = 10.0; read_noise_rber = 0.0; interrupted_rber = 5.0e-3;
    prog_fail_fresh = 1.0e-7; prog_fail_at_rated = 1.0e-4; prog_fail_exponent = 3.0;
    erase_fail_fresh = 1.0e-6; erase_fail_at_rated = 1.0e-3; erase_fail_exponent = 3.0;
    prog_fail_partial = 0.5; erase_fail_partial = 0.7; factory_bad_rate = 0.02; retry_gain = 0.5;
    ea_ev = 1.1; ref_temp_c = 40.0; op_temp_c = 40.0;
    n_fbad = 0; n_fprog = 0; n_ferase = 0; n_stuck = 0;
  endtask

  task automatic set_timing_tables();
    T_WC[0]=100; T_WC[1]=45; T_WC[2]=35; T_WC[3]=30; T_WC[4]=25; T_WC[5]=20;
    T_WP[0]=50;  T_WP[1]=25; T_WP[2]=17; T_WP[3]=15; T_WP[4]=12; T_WP[5]=10;
    T_WH[0]=30;  T_WH[1]=15; T_WH[2]=15; T_WH[3]=10; T_WH[4]=10; T_WH[5]=7;
    T_RC[0]=100; T_RC[1]=50; T_RC[2]=35; T_RC[3]=30; T_RC[4]=25; T_RC[5]=20;
    T_RP[0]=50;  T_RP[1]=25; T_RP[2]=17; T_RP[3]=15; T_RP[4]=12; T_RP[5]=10;
    T_REH[0]=30; T_REH[1]=15; T_REH[2]=15; T_REH[3]=10; T_REH[4]=10; T_REH[5]=7;
    T_REA[0]=40; T_REA[1]=30; T_REA[2]=25; T_REA[3]=20; T_REA[4]=20; T_REA[5]=16;
    T_CLS[0]=50; T_CLS[1]=25; T_CLS[2]=15; T_CLS[3]=10; T_CLS[4]=10; T_CLS[5]=10;
    T_ALS[0]=50; T_ALS[1]=25; T_ALS[2]=15; T_ALS[3]=10; T_ALS[4]=10; T_ALS[5]=10;
    T_DS[0]=40;  T_DS[1]=20; T_DS[2]=15; T_DS[3]=10; T_DS[4]=10; T_DS[5]=7;
    T_WB[0]=200; T_WB[1]=100; T_WB[2]=100; T_WB[3]=100; T_WB[4]=100; T_WB[5]=100;
    T_WHR[0]=120; T_WHR[1]=80; T_WHR[2]=80; T_WHR[3]=80; T_WHR[4]=80; T_WHR[5]=80;
    T_ADL[0]=200; T_ADL[1]=100; T_ADL[2]=100; T_ADL[3]=100; T_ADL[4]=70; T_ADL[5]=70;
    T_RR[0]=40;  T_RR[1]=20; T_RR[2]=20; T_RR[3]=20; T_RR[4]=20; T_RR[5]=20;
  endtask

  task automatic load_cfg();
    int fd, rc, v, a, b, c, d, e, f;
    string key;
    bit done;
    bit [7:0] h8;
    bit [63:0] h64;
    reg [8*512-1:0] skip;
    fd = $fopen(cfg_path, "r");
    if (fd == 0) begin
      msg($sformatf("no %s -- using built-in defaults (nominal profile)", cfg_path));
    end else begin
      done = 0;
      while (!done) begin
        rc = $fscanf(fd, "%s", key);
        if (rc != 1 || key == "end") done = 1;
        else if (key == "nandlab_svcfg") rc = $fscanf(fd, "%d", v);
        else if (key == "page_data_bytes") begin rc = $fscanf(fd, "%d", v); if (v != PAGE_DATA_BYTES) $fatal(1, "svcfg page_data_bytes mismatch"); end
        else if (key == "page_spare_bytes") begin rc = $fscanf(fd, "%d", v); if (v != PAGE_SPARE_BYTES) $fatal(1, "svcfg page_spare_bytes mismatch"); end
        else if (key == "pages_per_block") begin rc = $fscanf(fd, "%d", v); if (v != PAGES_PER_BLOCK) $fatal(1, "svcfg pages_per_block mismatch"); end
        else if (key == "blocks_per_lun") begin rc = $fscanf(fd, "%d", v); if (v != BLOCKS_PER_LUN) $fatal(1, "svcfg blocks_per_lun mismatch"); end
        else if (key == "planes_per_lun") begin rc = $fscanf(fd, "%d", v); if (v != PLANES_PER_LUN) $fatal(1, "svcfg planes_per_lun mismatch"); end
        else if (key == "luns") begin rc = $fscanf(fd, "%d", v); if (v != LUNS) $fatal(1, "svcfg luns mismatch"); end
        else if (key == "seed") rc = $fscanf(fd, "%h", global_seed);
        else if (key == "config_fp") rc = $fscanf(fd, "%s", config_fp);
        else if (key == "profile") rc = $fscanf(fd, "%s", profile);
        else if (key == "nop") rc = $fscanf(fd, "%d", nop_max);
        else if (key == "sequential") rc = $fscanf(fd, "%d", sequential);
        else if (key == "invalid_policy") rc = $fscanf(fd, "%d", invalid_policy);
        else if (key == "factory_bad_erase") rc = $fscanf(fd, "%d", factory_bad_erase);
        else if (key == "require_reset") rc = $fscanf(fd, "%d", require_reset);
        else if (key == "bbm_byte") rc = $fscanf(fd, "%d", bbm_byte);
        else if (key == "max_bad_per_lun") rc = $fscanf(fd, "%d", max_bad_per_lun);
        else if (key == "ecc_bits") rc = $fscanf(fd, "%d", ecc_bits);
        else if (key == "id_mfr") begin rc = $fscanf(fd, "%h", h8); id_bytes[0] = h8; end
        else if (key == "id_dev") begin rc = $fscanf(fd, "%h", h8); id_bytes[1] = h8; end
        else if (key == "id_b3") begin rc = $fscanf(fd, "%h", h8); id_bytes[2] = h8; end
        else if (key == "id_b4") begin rc = $fscanf(fd, "%h", h8); id_bytes[3] = h8; end
        else if (key == "id_b5") begin rc = $fscanf(fd, "%h", h8); id_bytes[4] = h8; end
        else if (key == "mfr_name") rc = $fscanf(fd, "%s", mfr_name);
        else if (key == "model_name") rc = $fscanf(fd, "%s", model_name);
        else if (key == "timing_mode") rc = $fscanf(fd, "%d", timing_mode);
        else if (key == "t_r_ns") rc = $fscanf(fd, "%f", t_r_ns);
        else if (key == "t_prog_ns") rc = $fscanf(fd, "%f", t_prog_ns);
        else if (key == "t_bers_ns") rc = $fscanf(fd, "%f", t_bers_ns);
        else if (key == "t_rst_idle_ns") rc = $fscanf(fd, "%f", t_rst_idle_ns);
        else if (key == "t_rst_prog_ns") rc = $fscanf(fd, "%f", t_rst_prog_ns);
        else if (key == "t_rst_erase_ns") rc = $fscanf(fd, "%f", t_rst_erase_ns);
        else if (key == "t_rst_poweron_ns") rc = $fscanf(fd, "%f", t_rst_poweron_ns);
        else if (key == "t_feat_ns") rc = $fscanf(fd, "%f", t_feat_ns);
        else if (key == "t_reject_ns") rc = $fscanf(fd, "%f", t_reject_ns);
        else if (key == "t_ccs_ns") rc = $fscanf(fd, "%f", t_ccs_ns);
        else if (key == "prog_time_wear_speedup") rc = $fscanf(fd, "%f", prog_time_wear_speedup);
        else if (key == "prog_time_floor") rc = $fscanf(fd, "%f", prog_time_floor);
        else if (key == "erase_time_wear_slowdown") rc = $fscanf(fd, "%f", erase_time_wear_slowdown);
        else if (key == "fail_time_factor") rc = $fscanf(fd, "%f", fail_time_factor);
        else if (key == "timing_checks") rc = $fscanf(fd, "%d", timing_checks);
        else if (key == "timing_fatal") rc = $fscanf(fd, "%d", timing_fatal);
        else if (key == "rated_endurance") rc = $fscanf(fd, "%f", rated_endurance);
        else if (key == "hard_limit_factor") rc = $fscanf(fd, "%f", hard_limit_factor);
        else if (key == "rber_fresh") rc = $fscanf(fd, "%f", rber_fresh);
        else if (key == "rber_wear_at_rated") rc = $fscanf(fd, "%f", rber_wear_at_rated);
        else if (key == "wear_exponent") rc = $fscanf(fd, "%f", wear_exponent);
        else if (key == "retention_rber_ref") rc = $fscanf(fd, "%f", retention_rber_ref);
        else if (key == "retention_ref_hours") rc = $fscanf(fd, "%f", retention_ref_hours);
        else if (key == "retention_exponent") rc = $fscanf(fd, "%f", retention_exponent);
        else if (key == "retention_wear_gain") rc = $fscanf(fd, "%f", retention_wear_gain);
        else if (key == "read_disturb_rber_ref") rc = $fscanf(fd, "%f", read_disturb_rber_ref);
        else if (key == "read_disturb_ref_reads") rc = $fscanf(fd, "%f", read_disturb_ref_reads);
        else if (key == "read_disturb_wear_gain") rc = $fscanf(fd, "%f", read_disturb_wear_gain);
        else if (key == "read_noise_rber") rc = $fscanf(fd, "%f", read_noise_rber);
        else if (key == "interrupted_rber") rc = $fscanf(fd, "%f", interrupted_rber);
        else if (key == "prog_fail_fresh") rc = $fscanf(fd, "%f", prog_fail_fresh);
        else if (key == "prog_fail_at_rated") rc = $fscanf(fd, "%f", prog_fail_at_rated);
        else if (key == "prog_fail_exponent") rc = $fscanf(fd, "%f", prog_fail_exponent);
        else if (key == "erase_fail_fresh") rc = $fscanf(fd, "%f", erase_fail_fresh);
        else if (key == "erase_fail_at_rated") rc = $fscanf(fd, "%f", erase_fail_at_rated);
        else if (key == "erase_fail_exponent") rc = $fscanf(fd, "%f", erase_fail_exponent);
        else if (key == "erase_fail_sticky") rc = $fscanf(fd, "%d", erase_fail_sticky);
        else if (key == "prog_fail_partial") rc = $fscanf(fd, "%f", prog_fail_partial);
        else if (key == "erase_fail_partial") rc = $fscanf(fd, "%f", erase_fail_partial);
        else if (key == "factory_bad_rate") rc = $fscanf(fd, "%f", factory_bad_rate);
        else if (key == "retry_gain") rc = $fscanf(fd, "%f", retry_gain);
        else if (key == "retry_max_level") rc = $fscanf(fd, "%d", retry_max_level);
        else if (key == "ea_ev") rc = $fscanf(fd, "%f", ea_ev);
        else if (key == "ref_temp_c") rc = $fscanf(fd, "%f", ref_temp_c);
        else if (key == "op_temp_c") rc = $fscanf(fd, "%f", op_temp_c);
        else if (key == "persist_read_counts") rc = $fscanf(fd, "%d", persist_read_counts);
        else if (key == "factory_bad") begin
          rc = $fscanf(fd, "%d %d %d", a, b, c);
          if (a == TARGET_ID && n_fbad < MAX_DIRECTED) begin fbad_l[n_fbad] = b; fbad_b[n_fbad] = c; n_fbad++; end
        end else if (key == "force_prog_fail") begin
          rc = $fscanf(fd, "%d %d %d %d", a, b, c, d);
          if (a == TARGET_ID && n_fprog < MAX_DIRECTED) begin fprog_l[n_fprog] = b; fprog_b[n_fprog] = c; fprog_p[n_fprog] = d; n_fprog++; end
        end else if (key == "force_erase_fail") begin
          rc = $fscanf(fd, "%d %d %d", a, b, c);
          if (a == TARGET_ID && n_ferase < MAX_DIRECTED) begin ferase_l[n_ferase] = b; ferase_b[n_ferase] = c; n_ferase++; end
        end else if (key == "stuck_bit") begin
          rc = $fscanf(fd, "%d %d %d %d %d %d", a, b, c, d, e, f);
          if (a == TARGET_ID && n_stuck < MAX_DIRECTED) begin
            stuck_l[n_stuck] = b; stuck_b[n_stuck] = c; stuck_p[n_stuck] = d; stuck_bit[n_stuck] = e; stuck_val[n_stuck] = f; n_stuck++;
          end
        end else begin
          msg($sformatf("svcfg: unknown key '%s' ignored", key));
          rc = $fgets(skip, fd);
        end
      end
      $fclose(fd);
    end
  endtask

  // ==================================================== ONFI parameter page
  task automatic build_param_page();
    bit [15:0] crc;
    int v, m, x;
    longint cyc;
    string vend;
    for (int i = 0; i < 256; i++) param_page[i] = 8'h00;
    param_page[0] = "O"; param_page[1] = "N"; param_page[2] = "F"; param_page[3] = "I";
    param_page[4] = 8'h02;                                            // revision: ONFI 1.0-style
    param_page[6] = ((LUNS > 1) ? 8'h02 : 8'h00) | ((sequential == 0) ? 8'h04 : 8'h00);
    param_page[8] = 8'h0C;                                            // Get/Set Features, Status Enhanced
    for (int i = 0; i < 12; i++) param_page[32 + i] = (i < mfr_name.len()) ? mfr_name[i] : " ";
    for (int i = 0; i < 20; i++) param_page[44 + i] = (i < model_name.len()) ? model_name[i] : " ";
    param_page[64] = id_bytes[0];
    {param_page[83], param_page[82], param_page[81], param_page[80]} = 32'(PAGE_DATA_BYTES);
    {param_page[85], param_page[84]} = 16'(PAGE_SPARE_BYTES);
    {param_page[95], param_page[94], param_page[93], param_page[92]} = 32'(PAGES_PER_BLOCK);
    {param_page[99], param_page[98], param_page[97], param_page[96]} = 32'(BLOCKS_PER_LUN);
    param_page[100] = 8'(LUNS);
    param_page[101] = 8'h23;
    param_page[102] = 8'h01;
    {param_page[104], param_page[103]} = 16'(max_bad_per_lun);
    cyc = longint'(rated_endurance);
    m = 0;
    while (cyc > 255 && (cyc % 10) == 0) begin cyc = cyc / 10; m++; end
    while (cyc > 255) begin cyc = cyc / 10; m++; end
    param_page[105] = 8'(cyc); param_page[106] = 8'(m);
    param_page[107] = 8'h01;
    param_page[110] = 8'(nop_max);
    param_page[112] = 8'(ecc_bits);
    param_page[113] = 8'((PLANES_PER_LUN > 1) ? $clog2(PLANES_PER_LUN) : 0);
    param_page[128] = 8'd10;
    param_page[129] = 8'h3F;
    x = int'($ceil(t_prog_ns * fail_time_factor / 1000.0)); if (x > 65535) x = 65535;
    {param_page[134], param_page[133]} = 16'(x);
    x = int'($ceil(t_bers_ns * (1.0 + erase_time_wear_slowdown) * fail_time_factor / 1000.0)); if (x > 65535) x = 65535;
    {param_page[136], param_page[135]} = 16'(x);
    x = int'($ceil(t_r_ns / 1000.0)); if (x > 65535) x = 65535;
    {param_page[138], param_page[137]} = 16'(x);
    x = int'($ceil(t_ccs_ns)); if (x > 65535) x = 65535;
    {param_page[140], param_page[139]} = 16'(x);
    param_page[164] = 8'h01;
    vend = "NANDLAB SIMULATION MODEL";
    for (int i = 0; i < vend.len(); i++) param_page[166 + i] = vend[i];
    crc = 16'h4F4E;
    for (int i = 0; i < 254; i++) crc = onfi_crc16_step(crc, param_page[i]);
    param_page[254] = crc[7:0]; param_page[255] = crc[15:8];
    for (int i = 0; i < 256; i++) begin param_page[256 + i] = param_page[i]; param_page[512 + i] = param_page[i]; end
  endtask

  // ============================================================ manufacture
  task automatic manufacture();
    int bi, pi, taken, room, nexp;
    bit isexp, hit;
    bit [63:0] thr, u;
    jfd = $fopen(store_path, "w");
    if (jfd == 0) $fatal(1, $sformatf("NANDLAB: cannot create %s", store_path));
    $fwrite(jfd, "NLSF 1 %0d %0d %0d %0d %0d %0d %016x %0d ;\n", PAGE_DATA_BYTES, PAGE_SPARE_BYTES,
            PAGES_PER_BLOCK, BLOCKS_PER_LUN, PLANES_PER_LUN, LUNS, global_seed, TARGET_ID);
    $fwrite(jfd, "M model SilicaFlux-NANDLab ;\nM version 0.1.0 ;\nM creator sv ;\nM config %s ;\n", config_fp);
    j_C(0.0);
    thr = thr32(factory_bad_rate);
    for (int lun = 0; lun < LUNS; lun++) begin
      nexp = 0;
      for (int i = 0; i < n_fbad; i++) if (fbad_l[i] == lun) begin
        nexp++;
        if (fbad_b[i] == 0) $fatal(1, "NANDLAB: block 0 is guaranteed valid; cannot be factory bad");
      end
      room = max_bad_per_lun - nexp; if (room < 0) room = 0;
      taken = 0;
      for (int blk = 1; blk < BLOCKS_PER_LUN; blk++) begin
        isexp = 0;
        for (int i = 0; i < n_fbad; i++) if (fbad_l[i] == lun && fbad_b[i] == blk) isexp = 1;
        hit = 0;
        if (isexp) hit = 1;
        else if (thr != 0) begin
          u = hk(hk(mix64(tseed ^ D_FBAD), 64'(lun)), 64'(blk)) >> 32;
          if (u < thr && taken < room) begin hit = 1; taken++; end
        end
        if (hit) begin
          bi = bidx(lun, blk);
          blk_flags[bi] = BF_FACTORY_BAD;
          j_B(lun, blk);
          for (int k = 0; k < 2; k++) begin
            pi = pidx(lun, blk, (k == 0) ? 0 : PAGES_PER_BLOCK - 1);
            ensure_slot(pi);
            pool[slot_of[pi] * PAGE_BYTES + PAGE_DATA_BYTES + bbm_byte] = 8'h00;
            pg_flags[pi] = PF_FACTORY_MARKER;
            pg_nop[pi] = 0;
            pg_tprog[pi] = 0.0;
            j_P(lun, blk, (k == 0) ? 0 : PAGES_PER_BLOCK - 1);
          end
        end
      end
    end
    $fclose(jfd);
    msg($sformatf("manufactured new device store %s", store_path));
  endtask

  // ============================================================ store load
  task automatic load_store();
    int fd, n, pos, rc, lun, blk, pg, nop, reads, ec, last, i, nrec, pi, bi;
    int h_ver, h_data, h_spare, h_ppb, h_bpl, h_planes, h_luns, h_tgt;
    bit [7:0] fl, by;
    bit [63:0] hseed;
    real r;
    bit ok, eof, nonblank;
    string tag, term;
    reg [8*LINE_CHARS-1:0] lb;
    fd = $fopen(store_path, "r");
    nrec = 0; eof = 0;
    while (!eof) begin
      pos = $ftell(fd);
      lb = 0;
      n = $fgets(lb, fd);
      if (n <= 0) eof = 1;
      else begin
        // the last character of the line sits in the low byte of lb
        i = 0;
        while (i < n && (lb[8*i +: 8] == 8'h0a || lb[8*i +: 8] == 8'h0d || lb[8*i +: 8] == 8'h20)) i++;
        nonblank = (i < n);
        last = nonblank ? lb[8*i +: 8] : 0;
        if (nonblank && last != 59) n_torn++;              // unterminated -> torn write, skip
        else if (nonblank) begin
          rc = $fseek(fd, pos, 0);
          rc = $fscanf(fd, "%s", tag);
          nrec++;
          if (tag == "NLSF") begin
            rc = $fscanf(fd, "%d %d %d %d %d %d %d %h %d", h_ver, h_data, h_spare, h_ppb, h_bpl, h_planes, h_luns,
                         hseed, h_tgt);
            if (h_ver != 1 || h_data != PAGE_DATA_BYTES || h_spare != PAGE_SPARE_BYTES || h_ppb != PAGES_PER_BLOCK ||
                h_bpl != BLOCKS_PER_LUN || h_planes != PLANES_PER_LUN || h_luns != LUNS)
              $fatal(1, $sformatf("NANDLAB: %s geometry does not match model parameters", store_path));
            if (hseed != global_seed) $fatal(1, "NANDLAB: store seed differs from configuration seed");
            if (h_tgt != TARGET_ID) $fatal(1, "NANDLAB: store belongs to another target");
          end else if (tag == "C") begin
            rc = $fscanf(fd, "%f", r);
            if (r > clock_base) clock_base = r;
          end else if (tag == "B") begin
            rc = $fscanf(fd, "%d %d %d %h %d", lun, blk, ec, fl, reads);
            bi = bidx(lun, blk); blk_ec[bi] = ec; blk_flags[bi] = fl; blk_reads[bi] = reads;
          end else if (tag == "R") begin
            rc = $fscanf(fd, "%d %d %d", lun, blk, reads);
            blk_reads[bidx(lun, blk)] = reads;
          end else if (tag == "E") begin
            rc = $fscanf(fd, "%d %d %f", lun, blk, r);
            for (int p = 0; p < PAGES_PER_BLOCK; p++) free_page(pidx(lun, blk, p));
            if (r > clock_base) clock_base = r;
          end else if (tag == "P") begin
            rc = $fscanf(fd, "%d %d %d %d %h %f", lun, blk, pg, nop, fl, r);
            pi = pidx(lun, blk, pg);
            ensure_slot(pi);
            for (int i = 0; i < PAGE_BYTES; i++) begin
              rc = $fscanf(fd, "%h", by);
              pool[slot_of[pi] * PAGE_BYTES + i] = by;
            end
            pg_nop[pi] = nop; pg_flags[pi] = fl; pg_tprog[pi] = r;
            if (r > clock_base) clock_base = r;
          end
          // M and unknown records: nothing to apply
          lb = 0;
          n = $fgets(lb, fd);                                  // consume rest of the line
        end
      end
    end
    $fclose(fd);
    msg($sformatf("loaded %s: %0d records, %0d torn record(s) skipped, clock %.6g s", store_path, nrec, n_torn, clock_base));
  endtask

  // ================================================================= sense
  task automatic sense_page(input int lun, input int blk, input int pg, input real t_start);
    int bi, pi, ec, reads, base, nb;
    bit unstable, sb;
    real age_h, pw, pr, pd, gr;
    bit [63:0] thr0, thr1, thrn, kp, kn, u;
    bit [7:0] v;
    bi = bidx(lun, blk); pi = pidx(lun, blk, pg); base = lun * PAGE_BYTES;
    blk_reads[bi] = blk_reads[bi] + 1;
    if (persist_read_counts != 0) j_R(lun, blk);
    ec = blk_ec[bi]; reads = blk_reads[bi];
    unstable = (blk_flags[bi] & BF_MARGINAL) != 0;
    age_h = 0.0;
    if (slot_of[pi] >= 0) begin
      age_h = (clock_at(t_start) - pg_tprog[pi]) / 3600.0;
      if ((pg_flags[pi] & PF_UNSTABLE) != 0) unstable = 1;
    end
    pw = p_wear(ec);
    if (unstable) pw = pw + interrupted_rber;
    pr = p_ret(age_h, ec);
    pd = p_rd(reads, ec);
    if (retry_level != 0) begin
      gr = $pow(retry_gain, $itor(retry_level));
      pr = pr * gr;
      pd = pd / gr;
    end
    thr0 = thr32(pw + pr);
    thr1 = thr32(pw + pd);
    thrn = thr32(read_noise_rber);
    for (int i = 0; i < PAGE_BYTES; i++) begin sbuf[base + i] = cell_byte(pi, i); fmask[i] = 8'h00; end
    if (thr0 != 0 || thr1 != 0) begin
      kp = hk(hk(hk(hk(mix64(tseed ^ D_PERSIST), 64'(lun)), 64'(blk)), 64'(pg)), 64'(ec));
      for (int b = 0; b < PAGE_BITS; b++) begin
        u = mix64(kp ^ 64'(b)) >> 32;
        sb = sbuf[base + (b >> 3)][b & 7];
        if (u < (sb ? thr1 : thr0)) fmask[b >> 3][b & 7] = 1'b1;
      end
    end
    if (thrn != 0) begin
      kn = hk(hk(hk(hk(hk(mix64(tseed ^ D_NOISE), 64'(lun)), 64'(blk)), 64'(pg)), 64'(ec)), 64'(reads));
      for (int b = 0; b < PAGE_BITS; b++) begin
        u = mix64(kn ^ 64'(b)) >> 32;
        if (u < thrn) fmask[b >> 3][b & 7] = 1'b1;
      end
    end
    nb = 0;
    for (int i = 0; i < PAGE_BYTES; i++) begin
      if (fmask[i] != 0) begin
        sbuf[base + i] = sbuf[base + i] ^ fmask[i];
        for (int k = 0; k < 8; k++) nb = nb + fmask[i][k];
      end
    end
    for (int s = 0; s < n_stuck; s++) begin
      if (stuck_l[s] == lun && stuck_b[s] == blk && stuck_p[s] == pg && stuck_bit[s] >= 0 && stuck_bit[s] < PAGE_BITS) begin
        v = sbuf[base + (stuck_bit[s] >> 3)];
        v[stuck_bit[s] & 7] = (stuck_val[s] != 0);
        sbuf[base + (stuck_bit[s] >> 3)] = v;
      end
    end
    n_bit_flips = n_bit_flips + nb;
  endtask

  // ====================================================== array operations
  // Decisions are taken at op start (t_start = confirm + tWB); effects are
  // committed at completion, or partially at an abort (reset / power loss).
  task automatic begin_op(input int lun);
    int bi, pi, ec, nop, bad, kind, blk, pg, rc;
    real dur, ff;
    bit [7:0] old;
    bit [63:0] u;
    kind = op_kind[lun]; blk = op_blk[lun]; pg = op_pg[lun];
    seq = seq + 1;
    op_seq[lun] = seq;
    op_start[lun] = $realtime;
    ff = 1.0; ec = 0; nop = 0; rc = RC_OK;
    if (blk >= BLOCKS_PER_LUN || pg >= PAGES_PER_BLOCK) begin
      rc = RC_REJECT_ADDRESS; dur = t_reject_ns;
      for (int i = 0; i < PAGE_BYTES; i++) sbuf[lun * PAGE_BYTES + i] = 8'hFF;
    end else begin
      bi = bidx(lun, blk); pi = pidx(lun, blk, pg);
      ec = blk_ec[bi]; nop = pg_nop[pi];
      if (kind == OP_READ) begin
        sense_page(lun, blk, pg, op_start[lun]);
        dur = t_r_ns;
      end else if (kind == OP_PROG) begin
        if (!wp_n) begin rc = RC_WP; dur = 0.0; end
        else if ((blk_flags[bi] & BF_FACTORY_BAD) != 0) begin rc = RC_FAIL_BAD_BLOCK; dur = t_prog_eff(ec) * fail_time_factor; end
        else if (nop >= nop_max) begin rc = RC_REJECT_NOP; dur = t_reject_ns; end
        else if (sequential != 0 && nop == 0 && pg != highest_programmed(lun, blk) + 1) begin
          rc = RC_REJECT_SEQUENCE; dur = t_reject_ns;
        end else begin
          bad = 0;
          for (int i = 0; i < PAGE_BYTES; i++) begin
            old = cell_byte(pi, i);
            if (pmask[lun * PAGE_BYTES + i] && ((preg[lun * PAGE_BYTES + i] & ~old) != 0) &&
                !(invalid_policy == 2 && preg[lun * PAGE_BYTES + i] == 8'hFF)) bad++;
          end
          if (bad != 0 && (invalid_policy == 0 || invalid_policy == 2)) begin rc = RC_REJECT_TRANSITION; dur = t_reject_ns; end
          else if (is_forced_prog(lun, blk, pg)) begin rc = RC_FAIL_FORCED; dur = t_prog_eff(ec) * fail_time_factor; ff = prog_fail_partial; end
          else begin
            u = hk(hk(hk(hk(hk(mix64(tseed ^ D_PFAIL), 64'(lun)), 64'(blk)), 64'(pg)), 64'(ec)), 64'(nop)) >> 32;
            if (u < thr32(p_prog_fail(ec))) begin rc = RC_FAIL_RANDOM; dur = t_prog_eff(ec) * fail_time_factor; ff = prog_fail_partial; end
            else begin rc = RC_OK; dur = t_prog_eff(ec); end
          end
          if (bad != 0 && invalid_policy == 1) proto_err($sformatf("%0d byte(s) request 0->1; AND semantics applied", bad));
        end
        if (rc == RC_REJECT_NOP || rc == RC_REJECT_SEQUENCE || rc == RC_REJECT_TRANSITION)
          msg($sformatf("program rejected (rc=%0d) lun %0d blk %0d pg %0d", rc, lun, blk, pg));
      end else begin // OP_ERASE
        if (!wp_n) begin rc = RC_WP; dur = 0.0; end
        else if ((blk_flags[bi] & BF_FACTORY_BAD) != 0 && factory_bad_erase == 0) begin
          rc = RC_FAIL_BAD_BLOCK; dur = t_erase_eff(ec) * fail_time_factor;
          proto_err($sformatf("erase issued to factory-bad block %0d (lun %0d)", blk, lun));
        end else if (is_forced_erase(lun, blk)) begin rc = RC_FAIL_FORCED; dur = t_erase_eff(ec) * fail_time_factor; ff = erase_fail_partial; end
        else if (worn(ec) || (erase_fail_sticky != 0 && (blk_flags[bi] & BF_ERASE_FAILED) != 0)) begin
          rc = RC_FAIL_WORN; dur = t_erase_eff(ec) * fail_time_factor; ff = erase_fail_partial;
        end else begin
          u = hk(hk(hk(mix64(tseed ^ D_EFAIL), 64'(lun)), 64'(blk)), 64'(ec)) >> 32;
          if (u < thr32(p_erase_fail(ec))) begin rc = RC_FAIL_RANDOM; dur = t_erase_eff(ec) * fail_time_factor; ff = erase_fail_partial; end
          else begin rc = RC_OK; dur = t_erase_eff(ec); end
          if (rc == RC_OK && (blk_flags[bi] & BF_FACTORY_BAD) != 0)
            proto_err($sformatf("factory-bad block %0d erased; marker lost", blk));
        end
      end
    end
    op_rc[lun] = rc; op_dur[lun] = dur; op_ff[lun] = ff; op_ec[lun] = ec; op_nop[lun] = nop;
    op_started[lun] = 1;
    if (!notrace) begin
      if (kind == OP_READ) begin
        $fwrite(tfd, "BEGIN %0d %.17g READ %0d %0d %0d %0d %.17g %0d %0d :", seq, op_start[lun], lun, blk, pg, rc, dur,
                retry_level, (rc == RC_REJECT_ADDRESS) ? 0 : blk_reads[bidx(lun, blk)]);
        tr_data(lun, 0);
      end else if (kind == OP_PROG) begin
        $fwrite(tfd, "BEGIN %0d %.17g PROG %0d %0d %0d %0d %.17g %0d %0d :", seq, op_start[lun], lun, blk, pg, rc, dur, wp_n, nop);
        tr_data(lun, 1);
      end else
        $fwrite(tfd, "BEGIN %0d %.17g ERASE %0d %0d 0 %0d %.17g %0d %0d :", seq, op_start[lun], lun, blk, rc, dur, wp_n, ec);
      $fwrite(tfd, " ;\n");
      $fflush(tfd);
    end
  endtask

  task automatic apply_program(input int lun, input real frac, input bit [7:0] flag);
    int pi, base;
    bit [7:0] old, nw, intended;
    bit [63:0] thr, k, u;
    pi = pidx(lun, op_blk[lun], op_pg[lun]); base = lun * PAGE_BYTES;
    thr = thr32(frac);
    k = hk(hk(hk(hk(hk(mix64(tseed ^ D_PPART), 64'(lun)), 64'(op_blk[lun])), 64'(op_pg[lun])), 64'(op_ec[lun])), 64'(op_nop[lun]));
    for (int i = 0; i < PAGE_BYTES; i++) begin
      old = cell_byte(pi, i);
      if (frac >= 1.0) nw = old & preg[base + i];
      else if (thr == 0) nw = old;
      else begin
        intended = old & ~preg[base + i];
        nw = old;
        for (int b = 0; b < 8; b++) begin
          u = mix64(k ^ 64'(i * 8 + b)) >> 32;
          if (intended[b] && u < thr) nw[b] = 1'b0;
        end
      end
      fmask[i] = nw;
    end
    ensure_slot(pi);
    for (int i = 0; i < PAGE_BYTES; i++) pool[slot_of[pi] * PAGE_BYTES + i] = fmask[i];
    pg_nop[pi] = pg_nop[pi] + 1;
    pg_flags[pi] = pg_flags[pi] | flag;
    pg_tprog[pi] = clock_at(op_start[lun]);
    j_P(lun, op_blk[lun], op_pg[lun]);
  endtask

  task automatic apply_erase_ok(input int lun);
    int bi, blk;
    blk = op_blk[lun]; bi = bidx(lun, blk);
    for (int p = 0; p < PAGES_PER_BLOCK; p++) free_page(pidx(lun, blk, p));
    blk_ec[bi] = blk_ec[bi] + 1;
    blk_reads[bi] = 0;
    blk_flags[bi] = blk_flags[bi] & ~(BF_MARGINAL | BF_ERASE_INTERRUPTED);
    if (worn(blk_ec[bi])) blk_flags[bi] = blk_flags[bi] | BF_WORN_OUT;
    j_E(lun, blk, clock_at(op_start[lun]));
    j_B(lun, blk);
  endtask

  task automatic apply_erase_partial(input int lun, input real frac, input bit [7:0] bflags);
    int bi, blk, pi, ec_before;
    bit [63:0] thr, k, u;
    bit [7:0] v;
    blk = op_blk[lun]; bi = bidx(lun, blk); ec_before = blk_ec[bi];
    thr = thr32(frac);
    for (int p = 0; p < PAGES_PER_BLOCK; p++) begin
      pi = pidx(lun, blk, p);
      if (slot_of[pi] >= 0) begin
        if (thr != 0) begin
          k = hk(hk(hk(hk(mix64(tseed ^ D_EPART), 64'(lun)), 64'(blk)), 64'(p)), 64'(ec_before));
          for (int i = 0; i < PAGE_BYTES; i++) begin
            v = pool[slot_of[pi] * PAGE_BYTES + i];
            for (int b = 0; b < 8; b++) begin
              u = mix64(k ^ 64'(i * 8 + b)) >> 32;
              if (u < thr) v[b] = 1'b1;
            end
            pool[slot_of[pi] * PAGE_BYTES + i] = v;
          end
        end
        pg_flags[pi] = pg_flags[pi] | PF_PARTIAL_ERASE;
        j_P(lun, blk, p);
      end
    end
    blk_ec[bi] = blk_ec[bi] + 1;
    blk_flags[bi] = blk_flags[bi] | bflags;
    if (worn(blk_ec[bi])) blk_flags[bi] = blk_flags[bi] | BF_WORN_OUT;
    j_B(lun, blk);
  endtask

  task automatic finish_op(input int lun);
    int kind, rc;
    kind = op_kind[lun]; rc = op_rc[lun];
    if (kind == OP_READ) begin
      for (int i = 0; i < PAGE_BYTES; i++) preg[lun * PAGE_BYTES + i] = sbuf[lun * PAGE_BYTES + i];
      n_reads++;
    end else if (kind == OP_PROG) begin
      n_programs++;
      if (rc_executes(rc)) begin
        apply_program(lun, op_ff[lun], (rc != RC_OK) ? PF_PROG_FAILED : 8'h00);
        if (rc != RC_OK) begin
          blk_flags[bidx(lun, op_blk[lun])] = blk_flags[bidx(lun, op_blk[lun])] | BF_PROG_FAILED;
          j_B(lun, op_blk[lun]);
        end
      end
    end else if (kind == OP_ERASE) begin
      n_erases++;
      if (rc == RC_OK) apply_erase_ok(lun);
      else if (rc_executes(rc)) apply_erase_partial(lun, op_ff[lun], BF_ERASE_FAILED | BF_MARGINAL);
    end
    failc_b[lun] = fail_b[lun];
    fail_b[lun] = (rc != RC_OK);
    lun_busy[lun] = 0; op_started[lun] = 0; op_kind[lun] = OP_NONE;
    if (!notrace) begin
      $fwrite(tfd, "DONE %0d %.17g %0d %02x ;\n", op_seq[lun], $realtime, lun, status_byte(lun));
      $fflush(tfd);
    end
  endtask

  // abort an in-flight op (frac = elapsed fraction of its busy time)
  task automatic abort_op(input int lun, input string cause);
    real frac;
    frac = 0.0;
    if (op_started[lun]) begin
      if (op_dur[lun] > 0.0) frac = ($realtime - op_start[lun]) / op_dur[lun];
      else frac = 1.0;
      if (frac > 1.0) frac = 1.0;
      if (frac < 0.0) frac = 0.0;
      if (!notrace) begin
        $fwrite(tfd, "ABORT %0d %.17g %0d %.17g %s ;\n", op_seq[lun], $realtime, lun, frac, cause);
        $fflush(tfd);
      end
      if (op_kind[lun] == OP_PROG && rc_executes(op_rc[lun]) && frac > 0.0)
        apply_program(lun, frac * op_ff[lun], PF_PROG_INTERRUPTED);
      else if (op_kind[lun] == OP_ERASE && rc_executes(op_rc[lun]) && frac > 0.0)
        apply_erase_partial(lun, frac * op_ff[lun], BF_MARGINAL | BF_ERASE_INTERRUPTED);
      msg($sformatf("%s aborted op kind %0d on lun %0d at %0.3f of its busy time", cause, op_kind[lun], lun, frac));
    end
    op_gen[lun] = op_gen[lun] + 1;
    lun_busy[lun] = 0; op_started[lun] = 0; op_kind[lun] = OP_NONE;
  endtask

  // ====================================================== busy machinery
  task automatic update_rb();
    bit busy;
    busy = !powered || tgt_busy_started;
    for (int l = 0; l < LUNS; l++) if (op_started[l]) busy = 1;
    if (prev_rb_busy && !busy) last_rb_rise = $realtime;
    prev_rb_busy = busy;
    rb_n = !busy;
  endtask

  task automatic lun_proc(input int lun, input int g);
    #(tWB_now());
    if (op_gen[lun] == g && powered) begin
      begin_op(lun);
      update_rb();
      #(op_dur[lun]);
      if (op_gen[lun] == g && powered) begin
        finish_op(lun);
        update_rb();
      end
    end
  endtask

  task automatic start_lun_op(input int lun, input int kind, input int blk, input int pg);
    int g;
    lun_busy[lun] = 1; op_started[lun] = 0;
    op_kind[lun] = kind; op_blk[lun] = blk; op_pg[lun] = pg;
    op_gen[lun] = op_gen[lun] + 1;
    g = op_gen[lun];
    sel_lun = lun;
`ifdef __ICARUS__
    kick_tgt = 0; kick_lun = lun; kick_gen = g;
    -> kick_ev;
`else
    fork lun_proc(lun, g); join_none
`endif
  endtask

  task automatic apply_setf();
    int v;
    if (feat_addr == FEAT_TIMING_MODE) begin
      if (feat_in[0][3:0] <= 5) timing_mode = feat_in[0][3:0];
      else proto_err($sformatf("unsupported timing mode %0d", feat_in[0][3:0]));
    end else if (feat_addr == FEAT_READ_RETRY) begin
      v = feat_in[0];
      if (v >= 128) v = v - 256;
      if (v > retry_max_level) v = retry_max_level;
      if (v < -retry_max_level) v = -retry_max_level;
      retry_level = v;
    end else proto_err($sformatf("unsupported feature address %02x", feat_addr));
    if (!notrace) begin
      $fwrite(tfd, "SETF %.17g %02x %02x %02x %02x %02x ;\n", $realtime, feat_addr, feat_in[0], feat_in[1], feat_in[2], feat_in[3]);
      $fflush(tfd);
    end
  endtask

  task automatic tgt_proc(input int g, input int kind, input real dur);
    #(tWB_now());
    if (tgt_gen == g && powered) begin
      tgt_busy_started = 1;
      update_rb();
      #(dur);
      if (tgt_gen == g && powered) begin
        if (kind == TOP_SETF) apply_setf();
        tgt_busy = 0; tgt_busy_started = 0;
        update_rb();
      end
    end
  endtask

  task automatic start_tgt_op(input int kind, input real dur);
    tgt_busy = 1; tgt_busy_started = 0; tgt_kind = kind;
    tgt_gen = tgt_gen + 1;
`ifdef __ICARUS__
    kick_tgt = 1; kick_gen = tgt_gen; kick_tkind = kind; kick_dur = dur;
    -> kick_ev;
`else
    fork tgt_proc(tgt_gen, kind, dur); join_none
`endif
  endtask

`ifdef __ICARUS__
  // Icarus 12 asserts (vthread of_JOIN_DETACH) when fork/join_none is executed
  // inside an automatic task, so busy timers are spawned from this static block.
  always @(kick_ev) begin
    if (kick_tgt) fork tgt_proc(kick_gen, kick_tkind, kick_dur); join_none
    else fork lun_proc(kick_lun, kick_gen); join_none
  end
`endif

  function automatic bit any_lun_busy();
    bit b;
    b = 0;
    for (int l = 0; l < LUNS; l++) if (lun_busy[l]) b = 1;
    return b;
  endfunction

  // ================================================================ reset
  task automatic do_reset();
    real dur;
    dur = poweron_pending ? t_rst_poweron_ns : t_rst_idle_ns;
    for (int l = 0; l < LUNS; l++) begin
      if (lun_busy[l]) begin
        if (op_started[l] && op_kind[l] == OP_PROG && t_rst_prog_ns > dur) dur = t_rst_prog_ns;
        if (op_started[l] && op_kind[l] == OP_ERASE && t_rst_erase_ns > dur) dur = t_rst_erase_ns;
        abort_op(l, "RESET");
      end
      fail_b[l] = 0; failc_b[l] = 0;
    end
    if (!notrace) begin
      $fwrite(tfd, "RESET %.17g %.17g ;\n", $realtime, dur);
      $fflush(tfd);
    end
    needs_reset = 0; poweron_pending = 0;
    cmd_valid = 0; prog_active = 0; out_mode = OM_NONE; addr_cnt = 0;
    tgt_gen = tgt_gen + 1; tgt_busy = 0; tgt_busy_started = 0;
    update_rb();
    start_tgt_op(TOP_RESET, dur);
  endtask

  // ================================================================ power
  task automatic power_down();
    for (int l = 0; l < LUNS; l++) if (lun_busy[l]) abort_op(l, "PCUT");
    if (!notrace) begin
      $fwrite(tfd, "POWERDOWN %.17g ;\n", $realtime);
      $fflush(tfd);
    end
    powered = 0;
    tgt_gen = tgt_gen + 1; tgt_busy = 0; tgt_busy_started = 0;
    for (int l = 0; l < LUNS; l++) begin fail_b[l] = 0; failc_b[l] = 0; end
    cmd_valid = 0; prog_active = 0; out_mode = OM_NONE; addr_cnt = 0;
    timing_mode = 0; retry_level = 0;
    dq_oe = 0;
    update_rb();
    msg("power lost: volatile state cleared, array state retained in the journal");
  endtask

  task automatic power_up();
    powered = 1;
    needs_reset = (require_reset != 0);
    poweron_pending = 1;
    if (!notrace) begin
      $fwrite(tfd, "POWERUP %.17g ;\n", $realtime);
      $fflush(tfd);
    end
    update_rb();
    msg("power restored: RESET (FFh) required");
  endtask

  // ============================================================ interface
  task automatic decode_row(input bit [7:0] r0, input bit [7:0] r1, input bit [7:0] r2,
                            output int lun, output int blk, output int pg);
    bit [23:0] row;
    row = {r2, r1, r0};
    pg = (RP_BITS > 0) ? int'(row & ((24'd1 << RP_BITS) - 1)) : 0;
    blk = (RB_BITS > 0) ? int'((row >> RP_BITS) & ((24'd1 << RB_BITS) - 1)) : 0;
    lun = int'(row >> (RP_BITS + RB_BITS));
  endtask

  task automatic on_command(input bit [7:0] c);
    int l;
    if (c == CMD_RESET) do_reset();
    else if (c == CMD_STATUS) begin
      out_mode = OM_STATUS; cmd_valid = 0; first_re_after_cmd = 1;
    end else if (needs_reset) proto_err($sformatf("command %02x before the power-on RESET", c));
    else if (tgt_busy) proto_err($sformatf("command %02x while target busy", c));
    else begin
      case (c)
        CMD_READ1: begin cur_cmd = c; cmd_valid = 1; addr_cnt = 0; out_mode = OM_DATA; prog_active = 0; data_src_param = 0; end
        CMD_READ2: begin
          if (cmd_valid && cur_cmd == CMD_READ1 && addr_cnt == 5) begin
            if (rd_lun >= LUNS) proto_err("READ to non-existent LUN ignored");
            else if (lun_busy[rd_lun]) proto_err($sformatf("READ to busy LUN %0d ignored", rd_lun));
            else begin
              start_lun_op(rd_lun, OP_READ, rd_blk, rd_pg);
              out_mode = OM_DATA; data_src_param = 0; read_overrun_warned = 0;
            end
          end else proto_err("30h without 00h + 5 address cycles");
          cmd_valid = 0;
        end
        CMD_CRC1: begin cur_cmd = c; cmd_valid = 1; addr_cnt = 0; end
        CMD_CRC2: begin
          if (cmd_valid && cur_cmd == CMD_CRC1 && addr_cnt >= 2) begin
            col = {addr_b[1], addr_b[0]};
            out_mode = data_src_param ? OM_PARAM : OM_DATA;
            ccs_pending = 1; last_ccs_t = $realtime; read_overrun_warned = 0;
          end else proto_err("E0h without 05h + 2 column cycles");
          cmd_valid = 0;
        end
        CMD_PROG1: begin cur_cmd = c; cmd_valid = 1; addr_cnt = 0; prog_active = 0; out_mode = OM_NONE; end
        CMD_CWC: begin
          if (prog_active) begin cur_cmd = c; cmd_valid = 1; addr_cnt = 0; end
          else proto_err("85h outside a program data phase");
        end
        CMD_PROG2: begin
          if (prog_active) begin
            if (lun_busy[prog_lun]) proto_err($sformatf("PROGRAM to busy LUN %0d ignored", prog_lun));
            else start_lun_op(prog_lun, OP_PROG, prog_blk, prog_pg);
          end else proto_err("10h without a valid 80h sequence");
          prog_active = 0; cmd_valid = 0;
        end
        CMD_ERASE1: begin cur_cmd = c; cmd_valid = 1; addr_cnt = 0; out_mode = OM_NONE; end
        CMD_ERASE2: begin
          if (cmd_valid && cur_cmd == CMD_ERASE1 && addr_cnt == 3) begin
            if (er_lun >= LUNS) proto_err("ERASE to non-existent LUN ignored");
            else if (lun_busy[er_lun]) proto_err($sformatf("ERASE to busy LUN %0d ignored", er_lun));
            else start_lun_op(er_lun, OP_ERASE, er_blk, 0);
          end else proto_err("D0h without 60h + 3 row cycles");
          cmd_valid = 0;
        end
        CMD_STATUS_ENH, CMD_READID, CMD_PARAM, CMD_GETF, CMD_SETF: begin
          if ((c == CMD_READID || c == CMD_PARAM || c == CMD_GETF || c == CMD_SETF) && any_lun_busy())
            proto_err($sformatf("command %02x requires all LUNs idle", c));
          else begin cur_cmd = c; cmd_valid = 1; addr_cnt = 0; end
        end
        default: begin
          proto_err($sformatf("unsupported command %02x (cache/multi-plane/copyback are not modelled)", c));
          cmd_valid = 0;
        end
      endcase
    end
  endtask

  task automatic on_address(input bit [7:0] a);
    int l, b, p;
    if (needs_reset || tgt_busy) proto_err("address cycle ignored (reset pending or target busy)");
    else if (!cmd_valid) proto_err("address cycle without a command");
    else begin
      if (addr_cnt < 8) addr_b[addr_cnt] = a;
      addr_cnt++;
      last_addr_rise = $realtime;
      case (cur_cmd)
        CMD_READ1: if (addr_cnt == 5) begin
          decode_row(addr_b[2], addr_b[3], addr_b[4], l, b, p);
          rd_lun = l; rd_blk = b; rd_pg = p; col = {addr_b[1], addr_b[0]};
        end
        CMD_PROG1: if (addr_cnt == 5) begin
          decode_row(addr_b[2], addr_b[3], addr_b[4], l, b, p);
          if (l >= LUNS) proto_err("PROGRAM address selects a non-existent LUN");
          else if (lun_busy[l]) proto_err($sformatf("PROGRAM setup to busy LUN %0d ignored", l));
          else begin
            prog_lun = l; prog_blk = b; prog_pg = p; col = {addr_b[1], addr_b[0]};
            for (int i = 0; i < PAGE_BYTES; i++) begin preg[l * PAGE_BYTES + i] = 8'hFF; pmask[l * PAGE_BYTES + i] = 0; end
            prog_active = 1; prog_first_data = 1;
          end
        end
        CMD_CWC: if (addr_cnt == 2) begin col = {addr_b[1], addr_b[0]}; prog_first_data = 1; end
        CMD_ERASE1: if (addr_cnt == 3) begin
          decode_row(addr_b[0], addr_b[1], addr_b[2], l, b, p);
          er_lun = l; er_blk = b;
          if (p != 0) msg("erase row address carries non-zero page bits (ignored)");
        end
        CMD_STATUS_ENH: if (addr_cnt == 3) begin
          decode_row(addr_b[0], addr_b[1], addr_b[2], l, b, p);
          if (l < LUNS) sel_lun = l; else proto_err("78h selects a non-existent LUN");
          out_mode = OM_STATUS; cmd_valid = 0; first_re_after_cmd = 1;
        end
        CMD_READID: if (addr_cnt == 1) begin
          id_addr = a; out_mode = OM_ID; out_ptr = 0; cmd_valid = 0; first_re_after_cmd = 1;
        end
        CMD_PARAM: if (addr_cnt == 1) begin
          if (a != 8'h00) proto_err("READ PARAMETER PAGE address must be 00h");
          out_mode = OM_PARAM; data_src_param = 1; col = 0; cmd_valid = 0;
          start_tgt_op(TOP_PARAM, t_r_ns);
        end
        CMD_GETF: if (addr_cnt == 1) begin
          feat_addr = a; out_mode = OM_FEAT; out_ptr = 0; cmd_valid = 0;
          feat_out[0] = 0; feat_out[1] = 0; feat_out[2] = 0; feat_out[3] = 0;
          if (a == FEAT_TIMING_MODE) feat_out[0] = 8'(timing_mode);
          else if (a == FEAT_READ_RETRY) feat_out[0] = 8'(retry_level);
          start_tgt_op(TOP_GETF, t_feat_ns);
        end
        CMD_SETF: if (addr_cnt == 1) begin feat_addr = a; feat_cnt = 0; prog_first_data = 1; end
        default: ;
      endcase
    end
  endtask

  task automatic on_data_in(input bit [7:0] d);
    if (prog_first_data && (prog_active || (cmd_valid && cur_cmd == CMD_SETF))) begin
      if (timing_checks != 0 && ($realtime - last_addr_rise) < T_ADL[timing_mode])
        timing_err("tADL", $realtime - last_addr_rise, T_ADL[timing_mode]);
      prog_first_data = 0;
    end
    if (prog_active && (cur_cmd == CMD_PROG1 || cur_cmd == CMD_CWC)) begin
      if (col < PAGE_BYTES) begin
        preg[prog_lun * PAGE_BYTES + col] = d;
        pmask[prog_lun * PAGE_BYTES + col] = 1;
      end else proto_err($sformatf("data byte at column %0d beyond page+spare ignored", col));
      col++;
    end else if (cmd_valid && cur_cmd == CMD_SETF && addr_cnt == 1) begin
      if (feat_cnt < 4) feat_in[feat_cnt] = d;
      feat_cnt++;
      if (feat_cnt == 4) begin cmd_valid = 0; start_tgt_op(TOP_SETF, t_feat_ns); end
    end else proto_err($sformatf("unexpected data-input cycle %02x", d));
  endtask

  function automatic bit [7:0] id_byte(input int ptr);
    if (id_addr == 8'h20) begin
      case (ptr) 0: return "O"; 1: return "N"; 2: return "F"; 3: return "I"; default: return 8'h00; endcase
    end
    if (ptr < 5) return id_bytes[ptr];
    return 8'h00;
  endfunction

  task automatic drive_out();
    bit [7:0] v;
    bit valid;
    valid = 1; v = 8'hFF;
    case (out_mode)
      OM_STATUS: v = status_byte(sel_lun);
      OM_ID: v = id_byte(out_ptr);
      OM_FEAT: begin
        if (tgt_busy) begin proto_err("GET FEATURES data read while busy"); valid = 0; end
        v = (out_ptr < 4) ? feat_out[out_ptr] : 8'h00;
      end
      OM_PARAM: begin
        if (tgt_busy) begin proto_err("parameter page read while busy"); valid = 0; end
        v = param_page[col % 768];
      end
      OM_DATA: begin
        if (lun_busy[sel_lun]) begin proto_err($sformatf("data output while LUN %0d busy", sel_lun)); valid = 0; end
        else if (col < PAGE_BYTES) v = preg[sel_lun * PAGE_BYTES + col];
        else begin
          if (!read_overrun_warned) proto_err($sformatf("data output beyond page+spare (column %0d) returns FFh", col));
          read_overrun_warned = 1;
          v = 8'hFF;
        end
      end
      default: begin proto_err("RE# toggled with no output source"); valid = 0; end
    endcase
    dq_oe = 1;
    out_v = v;
    out_valid = valid;
  endtask

  // ----------------------------------------------------- pin-level process
  always @(posedge we_n) begin
    if (init_done && powered && !ce_n) begin
      if (timing_checks != 0) begin
        if ($realtime - last_we_fall < T_WP[timing_mode]) timing_err("tWP", $realtime - last_we_fall, T_WP[timing_mode]);
        if (cle && $realtime - last_cle_chg < T_CLS[timing_mode]) timing_err("tCLS", $realtime - last_cle_chg, T_CLS[timing_mode]);
        if (ale && $realtime - last_ale_chg < T_ALS[timing_mode]) timing_err("tALS", $realtime - last_ale_chg, T_ALS[timing_mode]);
        if ($realtime - last_dq_chg < T_DS[timing_mode]) timing_err("tDS", $realtime - last_dq_chg, T_DS[timing_mode]);
      end
      if (cle && !ale) on_command(dq_in);
      else if (ale && !cle) on_address(dq_in);
      else if (!cle && !ale) on_data_in(dq_in);
      else proto_err("CLE and ALE both high on WE# rising edge");
    end
    last_we_rise = $realtime;
  end

  always @(negedge we_n) begin
    if (init_done && powered && !ce_n) begin
      dq_oe = 0;
      if (timing_checks != 0) begin
        if ($realtime - last_we_rise < T_WH[timing_mode]) timing_err("tWH", $realtime - last_we_rise, T_WH[timing_mode]);
        if ($realtime - last_we_fall < T_WC[timing_mode]) timing_err("tWC", $realtime - last_we_fall, T_WC[timing_mode]);
      end
    end
    last_we_fall = $realtime;
  end

  always @(negedge re_n) begin
    if (init_done && powered && !ce_n) begin
      if (timing_checks != 0) begin
        if ($realtime - last_re_fall < T_RC[timing_mode]) timing_err("tRC", $realtime - last_re_fall, T_RC[timing_mode]);
        if ($realtime - last_re_rise < T_REH[timing_mode]) timing_err("tREH", $realtime - last_re_rise, T_REH[timing_mode]);
        if (first_re_after_cmd && $realtime - last_we_rise < T_WHR[timing_mode])
          timing_err("tWHR", $realtime - last_we_rise, T_WHR[timing_mode]);
        if ((out_mode == OM_DATA || out_mode == OM_PARAM) && $realtime - last_rb_rise < T_RR[timing_mode])
          timing_err("tRR", $realtime - last_rb_rise, T_RR[timing_mode]);
        if (ccs_pending && $realtime - last_ccs_t < t_ccs_ns) timing_err("tCCS", $realtime - last_ccs_t, t_ccs_ns);
      end
      first_re_after_cmd = 0; ccs_pending = 0;
      drive_out();
      // data valid tREA after RE# falls (delayed NBA kept in this static block:
      // Icarus 12 crashes on intra-assignment delays inside automatic tasks)
      if (out_valid) dq_out <= #(T_REA[timing_mode]) out_v;
      else dq_out <= #(T_REA[timing_mode]) 8'hxx;
    end
    last_re_fall = $realtime;
  end

  always @(posedge re_n) begin
    if (init_done && powered && !ce_n) begin
      if (timing_checks != 0 && $realtime - last_re_fall < T_RP[timing_mode])
        timing_err("tRP", $realtime - last_re_fall, T_RP[timing_mode]);
      if (out_mode == OM_DATA || out_mode == OM_PARAM) col++;
      else if (out_mode == OM_ID || out_mode == OM_FEAT) out_ptr++;
    end
    last_re_rise = $realtime;
  end

  always @(posedge ce_n) dq_oe = 0;
  always @(cle)   last_cle_chg = $realtime;
  always @(ale)   last_ale_chg = $realtime;
  always @(dq_in) last_dq_chg = $realtime;

  always @(negedge vcc_ok) if (init_done && powered) power_down();
  always @(posedge vcc_ok) if (init_done && !powered) power_up();

  // ===================================================== back-door API
  // For testbench checking only -- a real controller cannot do any of this.
  function automatic bit [7:0] bd_peek(input int lun, input int blk, input int pg, input int c);
    return cell_byte(pidx(lun, blk, pg), c);
  endfunction
  function automatic int bd_erase_count(input int lun, input int blk); return blk_ec[bidx(lun, blk)]; endfunction
  function automatic int bd_block_flags(input int lun, input int blk); return blk_flags[bidx(lun, blk)]; endfunction
  function automatic int bd_block_reads(input int lun, input int blk); return blk_reads[bidx(lun, blk)]; endfunction
  function automatic int bd_page_flags(input int lun, input int blk, input int pg); return pg_flags[pidx(lun, blk, pg)]; endfunction
  function automatic int bd_page_nop(input int lun, input int blk, input int pg); return pg_nop[pidx(lun, blk, pg)]; endfunction
  function automatic real bd_clock(); return clock_at($realtime); endfunction

  task automatic bd_bake(input real hours, input real temp_c);
    clock_base = clock_base + hours * 3600.0 * arrhenius(ea_ev, ref_temp_c, temp_c);
    j_C(clock_at($realtime));
    if (!notrace) begin
      $fwrite(tfd, "BAKE %.17g %.17g %.17g ;\n", $realtime, hours, temp_c);
      $fflush(tfd);
    end
  endtask

  task automatic bd_checkpoint();
    j_C(clock_at($realtime));
  endtask

  // ============================================================ start-up
  initial begin : init
    real bake_h, bake_t;
    init_done = 0;
    dq_oe = 0; dq_out = 8'hFF; rb_n = 1;
    quiet = $test$plusargs("NANDLAB_QUIET");
    notrace = $test$plusargs("NANDLAB_NOTRACE");
    if (!$value$plusargs("NANDLAB_DIR=%s", dir)) dir = ".";
    store_path = $sformatf("%s/target%0d.nlsf", dir, TARGET_ID);
    cfg_path = $sformatf("%s/nandlab.svcfg", dir);
    trace_path = $sformatf("%s/target%0d.trace", dir, TARGET_ID);
    set_defaults();
    set_timing_tables();
    load_cfg();
    tseed = mix64(global_seed ^ D_TARGET ^ 64'(TARGET_ID));
    af_op = arrhenius(ea_ev, ref_temp_c, op_temp_c);
    for (int i = 0; i < TOTAL_PAGES; i++) begin slot_of[i] = -1; pg_nop[i] = 0; pg_flags[i] = 0; pg_tprog[i] = 0.0; end
    for (int i = 0; i < TOTAL_BLOCKS; i++) begin blk_ec[i] = 0; blk_flags[i] = 0; blk_reads[i] = 0; end
    for (int i = 0; i < NPOOL; i++) free_list[i] = NPOOL - 1 - i;
    free_top = NPOOL;
    for (int l = 0; l < LUNS; l++) begin
      lun_busy[l] = 0; op_started[l] = 0; op_kind[l] = OP_NONE; op_gen[l] = 0; fail_b[l] = 0; failc_b[l] = 0;
    end
    clock_base = 0.0; seq = 0; n_torn = 0;
    n_proto_errors = 0; n_timing_violations = 0; n_reads = 0; n_programs = 0; n_erases = 0; n_bit_flips = 0;
    retry_level = 0; tgt_busy = 0; tgt_busy_started = 0; tgt_gen = 0; cmd_valid = 0; out_mode = OM_NONE;
    prog_active = 0; sel_lun = 0; col = 0; out_ptr = 0; data_src_param = 0; prev_rb_busy = 0;
    first_re_after_cmd = 0; ccs_pending = 0;
    last_we_fall = -1.0e9; last_we_rise = -1.0e9; last_re_fall = -1.0e9; last_re_rise = -1.0e9;
    last_cle_chg = -1.0e9; last_ale_chg = -1.0e9; last_dq_chg = -1.0e9; last_rb_rise = -1.0e9;
    last_addr_rise = -1.0e9; last_ccs_t = -1.0e9;
    jfd = $fopen(store_path, "r");
    if (jfd == 0) begin
      manufacture();
      // state is always rebuilt from what is on disk
      for (int i = 0; i < TOTAL_PAGES; i++) begin slot_of[i] = -1; pg_nop[i] = 0; pg_flags[i] = 0; pg_tprog[i] = 0.0; end
      for (int i = 0; i < TOTAL_BLOCKS; i++) begin blk_ec[i] = 0; blk_flags[i] = 0; blk_reads[i] = 0; end
      for (int i = 0; i < NPOOL; i++) free_list[i] = NPOOL - 1 - i;
      free_top = NPOOL; clock_base = 0.0;
    end else $fclose(jfd);
    load_store();
    build_param_page();
    jfd = $fopen(store_path, "a");
    $fwrite(jfd, "\n");                      // never glue a record onto a torn line
    $fflush(jfd);
    if (!notrace) begin
      tfd = $fopen(trace_path, "w");
      $fwrite(tfd, "NANDLAB-TRACE 1 %0d %0d %0d %0d %0d %0d ;\n", TARGET_ID, PAGE_DATA_BYTES, PAGE_SPARE_BYTES,
              PAGES_PER_BLOCK, BLOCKS_PER_LUN, LUNS);
    end
    if ($value$plusargs("NANDLAB_BAKE_HOURS=%f", bake_h)) begin
      if (!$value$plusargs("NANDLAB_BAKE_TEMP_C=%f", bake_t)) bake_t = ref_temp_c;
      bd_bake(bake_h, bake_t);
      msg($sformatf("unpowered bake: %0.3f h at %0.1f C -> retention clock %.6g s", bake_h, bake_t, clock_base));
    end
    powered = 1;
    needs_reset = (require_reset != 0);
    poweron_pending = 1;
    init_done = 1;
    msg($sformatf("ready: %0d LUN x %0d blk x %0d pg x (%0d+%0d) B, profile %s, seed %016x",
                  LUNS, BLOCKS_PER_LUN, PAGES_PER_BLOCK, PAGE_DATA_BYTES, PAGE_SPARE_BYTES, profile, global_seed));
  end

  final begin
    if (jfd != 0) begin
      $fwrite(jfd, "C %.17g ;\n", clock_at($realtime));   // final checkpoint (tasks not allowed here)
      $fclose(jfd);
    end
    if (!notrace && tfd != 0) $fclose(tfd);
    if (!quiet)
      $display("[NANDLAB tgt%0d] summary: reads %0d programs %0d erases %0d bit_flips %0d protocol_errors %0d timing_violations %0d",
               TARGET_ID, n_reads, n_programs, n_erases, n_bit_flips, n_proto_errors, n_timing_violations);
  end
endmodule


// -----------------------------------------------------------------------------
// Convenience wrapper with a bidirectional DQ bus (for board-level / shared
// channel testbenches). Several instances may share one channel; only the
// target whose CE# is low drives DQ.
// -----------------------------------------------------------------------------
module nand_flash_device #(
  parameter int PAGE_DATA_BYTES  = 512,
  parameter int PAGE_SPARE_BYTES = 16,
  parameter int PAGES_PER_BLOCK  = 16,
  parameter int BLOCKS_PER_PLANE = 32,
  parameter int PLANES_PER_LUN   = 2,
  parameter int LUNS             = 2,
  parameter int TARGET_ID        = 0,
  parameter int POOL_PAGES       = 0
) (
  input  logic ce_n, cle, ale, we_n, re_n, wp_n, vcc_ok,
  inout  wire [7:0] dq,
  output logic rb_n
);
  logic [7:0] dq_out;
  logic dq_oe;
  nand_flash_model #(.PAGE_DATA_BYTES(PAGE_DATA_BYTES), .PAGE_SPARE_BYTES(PAGE_SPARE_BYTES),
    .PAGES_PER_BLOCK(PAGES_PER_BLOCK), .BLOCKS_PER_PLANE(BLOCKS_PER_PLANE), .PLANES_PER_LUN(PLANES_PER_LUN),
    .LUNS(LUNS), .TARGET_ID(TARGET_ID), .POOL_PAGES(POOL_PAGES)) u_model (
    .ce_n(ce_n), .cle(cle), .ale(ale), .we_n(we_n), .re_n(re_n), .wp_n(wp_n), .dq_in(dq),
    .dq_out(dq_out), .dq_oe(dq_oe), .rb_n(rb_n), .vcc_ok(vcc_ok));
  // release DQ shortly after RE# rises (data hold, cf. tRHOH/tRHZ) so the
  // controller or another target can drive the shared bus
  wire re_hold_n;
  assign #15 re_hold_n = re_n;
  assign dq = (dq_oe && !ce_n && (!re_n || !re_hold_n)) ? dq_out : 8'hzz;
endmodule
