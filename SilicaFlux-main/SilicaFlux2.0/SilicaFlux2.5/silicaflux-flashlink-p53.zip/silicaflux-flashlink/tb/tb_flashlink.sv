// =============================================================================
// tb_flashlink.sv -- SilicaFlux FlashLink, Project 53: self-checking testbench
// -----------------------------------------------------------------------------
// silicaflux_nand_controller (RTL)  --pins-->  sfnc_io_sdr (behavioural I/O)
//   --> shared DQ bus, CE# per target --> nand_flash_device x NUM_CE
//       (SilicaFlux NANDLab Project 52 model, UNMODIFIED, persistent store,
//        AC timing checker, protocol checker, fault injection)
// plus an SFB2 buffer SRAM model and an independent pin-level monitor.
//
// Every test checks (a) completion records, (b) data through the buffer
// against the model's back-door array and expected patterns, and at the end
// (c) zero protocol errors and zero AC-timing violations reported by the model,
// zero monitor violations and zero SFB2 protocol errors.
//
//   +TEST=suite      single channel protocol suite (default)
//   +TEST=negative   deliberately mis-programmed timing: checkers must fire
//   +NANDLAB_DIR=<d> store / configuration directory (fresh per run)
//   +RESULT=<file>   CHECK PASS/FAIL lines + summary
//   +VCD=<file>      waveform dump (pins + key controller state)
// Classification: TESTBENCH
// =============================================================================
`timescale 1ns/1ps

module tb_flashlink;
  parameter int NUM_CE    = 1;
  parameter int RB_SHARED = 0;
  parameter int CLK_PS    = 10000;
  parameter int QD        = 4;

  localparam int PD = 512, PS = 16, PB = PD + PS, PPB = 16, BPP = 32, PPL = 2, LUNS = 2, BPL = BPP * PPL;
  localparam int NRB = (RB_SHARED != 0) ? 1 : NUM_CE;
  localparam int CYC_US = (1000000 + CLK_PS - 1) / CLK_PS;

  // ---------------------------------------------------------------- clock / reset
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic vcc_ok = 1'b1;
  always #(CLK_PS / 2000.0) clk = ~clk;

  // ---------------------------------------------------------------- DUT
  logic        req_valid, req_ready;
  logic [3:0]  req_op;
  logic [7:0]  req_tag;
  logic [2:0]  req_ce, req_lun;
  logic [23:0] req_block;
  logic [15:0] req_page, req_col, req_len;
  logic [31:0] req_buf, req_fdata;
  logic [7:0]  req_faddr;
  logic        cpl_valid, cpl_ready;
  logic [7:0]  cpl_tag, cpl_nst;
  logic [3:0]  cpl_op, cpl_status;
  logic [2:0]  cpl_ce, cpl_lun;
  logic [31:0] cpl_info0, cpl_info1, cpl_latency, cpl_dev;
  logic        csr_sel, csr_we, csr_err;
  logic [7:0]  csr_addr;
  logic [31:0] csr_wdata, csr_rdata;
  logic        m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [31:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [3:0]  m_req_wstrb;
  logic [NUM_CE-1:0] c_ce_n;
  logic        c_cle, c_ale, c_we_n, c_re_n, c_wp_n, c_dq_oe, irq, busy;
  logic [7:0]  c_dq_o, c_dq_i;
  logic [NRB-1:0] c_rb_n;
  logic [2:0]  tmode;

`ifdef GLS
  // gate-level netlist from scripts/gls.py (parameters fixed at synthesis: defaults + DEF_LUNS = 1)
  silicaflux_nand_controller dut (
`else
  silicaflux_nand_controller #(
    .DQ_WIDTH(8), .NUM_CE(NUM_CE), .RB_SHARED(RB_SHARED), .NUM_LUN_MAX(2), .QUEUE_DEPTH(QD), .CPL_DEPTH(4),
    .TAG_W(8), .BUF_DW(32), .CLK_PERIOD_PS(CLK_PS), .DEF_LUNS(1)
  ) dut (
`endif
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_ready(req_ready), .req_op(req_op), .req_tag(req_tag), .req_ce(req_ce),
    .req_lun(req_lun), .req_block(req_block), .req_page(req_page), .req_col(req_col), .req_len(req_len),
    .req_buf(req_buf), .req_faddr(req_faddr), .req_fdata(req_fdata),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_tag(cpl_tag), .cpl_op(cpl_op), .cpl_status(cpl_status),
    .cpl_nand_status(cpl_nst), .cpl_ce(cpl_ce), .cpl_lun(cpl_lun), .cpl_info0(cpl_info0), .cpl_info1(cpl_info1),
    .cpl_latency(cpl_latency), .cpl_dev_time(cpl_dev),
    .csr_sel(csr_sel), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata),
    .csr_err(csr_err),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .nand_ce_n(c_ce_n), .nand_cle(c_cle), .nand_ale(c_ale), .nand_we_n(c_we_n), .nand_re_n(c_re_n),
    .nand_wp_n(c_wp_n), .nand_dq_o(c_dq_o), .nand_dq_oe(c_dq_oe), .nand_dq_i(c_dq_i), .nand_rb_n(c_rb_n),
    .irq(irq), .busy(busy), .timing_mode(tmode));

  // ---------------------------------------------------------------- physical I/O + devices
  wire [NUM_CE-1:0] p_ce_n;
  wire p_cle, p_ale, p_we_n, p_re_n, p_wp_n;
  tri  [7:0] p_dq;
  wire [NRB-1:0] p_rb_n;
  wire [NUM_CE-1:0] rb_t;                 // per-target push-pull R/B# of the models
  logic [NUM_CE-1:0] rb_stuck = '0;       // fault injection: hold a target's R/B# low

  // pads idle until the controller has been through reset (2-state simulators start every flop at 0)
  logic pins_live = 1'b0;
  always @(posedge clk) if (!rst_n) pins_live <= 1'b1;
  wire [NUM_CE-1:0] g_ce_n = pins_live ? c_ce_n : '1;
  wire g_cle = pins_live & c_cle, g_ale = pins_live & c_ale, g_we_n = !pins_live | c_we_n;
  wire g_re_n = !pins_live | c_re_n, g_wp_n = pins_live & c_wp_n, g_dq_oe = pins_live & c_dq_oe;

  sfnc_io_sdr #(.DQW(8), .NUM_CE(NUM_CE), .NUM_RB(NRB), .TECH("SIM")) u_io (
    .c_ce_n(g_ce_n), .c_cle(g_cle), .c_ale(g_ale), .c_we_n(g_we_n), .c_re_n(g_re_n), .c_wp_n(g_wp_n),
    .c_dq_o(c_dq_o), .c_dq_oe(g_dq_oe), .c_dq_i(c_dq_i), .c_rb_n(c_rb_n),
    .pad_ce_n(p_ce_n), .pad_cle(p_cle), .pad_ale(p_ale), .pad_we_n(p_we_n), .pad_re_n(p_re_n),
    .pad_wp_n(p_wp_n), .pad_dq(p_dq), .pad_rb_n(p_rb_n));

  int tgt_proto [0:NUM_CE-1];
  int tgt_timing [0:NUM_CE-1];
  for (genvar c = 0; c < NUM_CE; c++) begin : g_tgt
    nand_flash_device #(.PAGE_DATA_BYTES(PD), .PAGE_SPARE_BYTES(PS), .PAGES_PER_BLOCK(PPB),
      .BLOCKS_PER_PLANE(BPP), .PLANES_PER_LUN(PPL), .LUNS(LUNS), .TARGET_ID(c)) u_dev (
      .ce_n(p_ce_n[c]), .cle(p_cle), .ale(p_ale), .we_n(p_we_n), .re_n(p_re_n), .wp_n(p_wp_n),
      .vcc_ok(vcc_ok), .dq(p_dq), .rb_n(rb_t[c]));
    always @(posedge clk) begin
      tgt_proto[c]  = u_dev.u_model.n_proto_errors;
      tgt_timing[c] = u_dev.u_model.n_timing_violations;
    end
  end
  wire [NUM_CE-1:0] rb_line = rb_t & ~rb_stuck;
  if (RB_SHARED != 0) begin : g_rb_shared
    assign p_rb_n = &rb_line;              // open-drain wired-AND with pull-up
  end else begin : g_rb_ce
    assign p_rb_n = rb_line;
  end
  wire [NUM_CE-1:0] mon_rb = (RB_SHARED != 0) ? {NUM_CE{p_rb_n[0]}} : rb_line;

  sfnc_onfi_monitor #(.NUM_CE(NUM_CE), .DQW(8), .PER_CE_RB(RB_SHARED == 0)) u_mon (
    .ce_n(p_ce_n), .cle(p_cle), .ale(p_ale), .we_n(p_we_n), .re_n(p_re_n), .wp_n(p_wp_n), .dq(p_dq),
    .dq_oe(g_dq_oe), .rb_n(mon_rb), .vcc_ok(vcc_ok));

  sfnc_sfb_mem #(.DW(32), .BYTES(65536)) u_mem (
    .clk(clk), .rst_n(rst_n), .req_valid(m_req_valid), .req_ready(m_req_ready), .req_write(m_req_write),
    .req_addr(m_req_addr), .req_wdata(m_req_wdata), .req_wstrb(m_req_wstrb), .rsp_valid(m_rsp_valid),
    .rsp_ready(m_rsp_ready), .rsp_rdata(m_rsp_rdata), .rsp_error(m_rsp_error));

  // ---------------------------------------------------------------- completion collector
  bit          c_got [0:255];
  logic [3:0]  c_st  [0:255];
  logic [7:0]  c_nst [0:255];
  logic [31:0] c_i0 [0:255], c_i1 [0:255], c_lat [0:255], c_dev [0:255];
  int          c_seq [0:255];
  int          n_cpl;
  always @(posedge clk) begin
    if (cpl_valid && cpl_ready) begin
      c_got[cpl_tag] = 1'b1; c_st[cpl_tag] = cpl_status; c_nst[cpl_tag] = cpl_nst;
      c_i0[cpl_tag] = cpl_info0; c_i1[cpl_tag] = cpl_info1; c_lat[cpl_tag] = cpl_latency; c_dev[cpl_tag] = cpl_dev;
      c_seq[cpl_tag] = n_cpl; n_cpl++;
    end
  end

  // ---------------------------------------------------------------- bookkeeping
  string test, dir, resfile;
  int rfd, n_pass, n_fail;
  logic [3:0] r_st;
  logic [7:0] r_nst;
  logic [31:0] r_i0, r_i1, r_lat, r_dev, rd_val;
  int r_seq;
  bit rd_e;
  int tagc;
  int b2next;                     // next sequential page of lun0 blk2 (CE0)

  task automatic check(input bit cond, input string name);
    if (cond) begin n_pass++; $fdisplay(rfd, "CHECK PASS %s", name); end
    else begin n_fail++; $fdisplay(rfd, "CHECK FAIL %s", name); $display("[TB %0t] FAIL: %s", $realtime, name); end
  endtask

  function automatic bit [7:0] pat(input int seed, input int i);
    bit [63:0] h;
    h = nand_flash_pkg::mix64(64'(seed) * 64'h100000001B3 + 64'(i));
    pat = h[7:0];
  endfunction

  // ---------------------------------------------------------------- CSR access
  task automatic csr_wr(input logic [7:0] a, input logic [31:0] d);
    @(negedge clk); csr_sel = 1; csr_we = 1; csr_addr = a; csr_wdata = d;
    @(negedge clk); csr_sel = 0; csr_we = 0;
  endtask

  task automatic csr_rd(input logic [7:0] a);
    @(negedge clk); csr_sel = 1; csr_we = 0; csr_addr = a; #1;
    rd_val = csr_rdata; rd_e = csr_err;
    @(negedge clk); csr_sel = 0;
  endtask

  task automatic ctrl_set(input int bitn, input bit v);
    logic [31:0] cv;
    csr_rd(8'h0C); cv = rd_val;
    cv[bitn] = v;
    csr_wr(8'h0C, cv);
  endtask

  // ---------------------------------------------------------------- request access
  task automatic submit(input logic [3:0] op, input logic [7:0] tag, input int ce, input int lun, input int blk,
                        input int pg, input int col, input int len, input int bufa, input logic [7:0] fa,
                        input logic [31:0] fd);
    @(negedge clk);
    c_got[tag] = 1'b0;
    req_valid = 1; req_op = op; req_tag = tag; req_ce = 3'(ce); req_lun = 3'(lun); req_block = 24'(blk);
    req_page = 16'(pg); req_col = 16'(col); req_len = 16'(len); req_buf = 32'(bufa); req_faddr = fa; req_fdata = fd;
    while (!req_ready) @(negedge clk);
    @(posedge clk); #1;
    req_valid = 0;
  endtask

  task automatic wait_cpl(input logic [7:0] tag, input real max_us);
    real t0;
    t0 = $realtime;
    while (!c_got[tag] && ($realtime - t0) < max_us * 1000.0) @(posedge clk);
    #1;
    if (!c_got[tag]) begin
      check(0, $sformatf("completion of tag %0d within %0.0f us", tag, max_us));
      r_st = 4'hF; r_nst = 0; r_i0 = 0; r_i1 = 0; r_lat = 0; r_dev = 0; r_seq = -1;
    end else begin
      r_st = c_st[tag]; r_nst = c_nst[tag]; r_i0 = c_i0[tag]; r_i1 = c_i1[tag]; r_lat = c_lat[tag];
      r_dev = c_dev[tag]; r_seq = c_seq[tag];
    end
    c_got[tag] = 1'b0;
  endtask

  // blocking operation: submit + wait, returns the tag used
  task automatic op(input logic [3:0] opc, input int ce, input int lun, input int blk, input int pg, input int col,
                    input int len, input int bufa, input logic [7:0] fa, input logic [31:0] fd, input real max_us);
    logic [7:0] t;
    t = 8'(tagc); tagc = (tagc + 1) % 200;
    submit(opc, t, ce, lun, blk, pg, col, len, bufa, fa, fd);
    wait_cpl(t, max_us);
  endtask

  // ---------------------------------------------------------------- buffer helpers
  task automatic buf_fill(input int a, input int n, input int seed);
    for (int i = 0; i < n; i++) u_mem.mem[a + i] = pat(seed, i);
  endtask
  task automatic buf_set(input int a, input int n, input bit [7:0] v);
    for (int i = 0; i < n; i++) u_mem.mem[a + i] = v;
  endtask
  function automatic int buf_cmp(input int a, input int n, input int seed, input int off);
    int bad;
    bad = 0;
    for (int i = 0; i < n; i++) if (u_mem.mem[a + i] !== pat(seed, off + i)) bad++;
    buf_cmp = bad;
  endfunction
  function automatic int buf_cmpv(input int a, input int n, input bit [7:0] v);
    int bad;
    bad = 0;
    for (int i = 0; i < n; i++) if (u_mem.mem[a + i] !== v) bad++;
    buf_cmpv = bad;
  endfunction
  // device array (target 0) vs buffer
  function automatic int dev_cmp0(input int lun, input int blk, input int pg, input int col, input int a, input int n);
    int bad;
    bad = 0;
    for (int i = 0; i < n; i++)
      if (g_tgt[0].u_dev.u_model.bd_peek(lun, blk, pg, col + i) !== u_mem.mem[a + i]) bad++;
    dev_cmp0 = bad;
  endfunction

  function automatic int total_cmds();
    total_cmds = u_mon.n_cmd_total;
  endfunction

  localparam logic [3:0] RST = 4'h0, RID = 4'h1, RPRM = 4'h2, RST_S = 4'h3, RD = 4'h4, PG = 4'h5, ER = 4'h6,
                         SF = 4'h7, GF = 4'h8;
  localparam logic [3:0] OK = 4'h0, DEVF = 4'h1, TMO = 4'h2, BADOP = 4'h3, BADA = 4'h4, ALN = 4'h5, WPS = 4'h6,
                         NRST = 4'h7, PORD = 4'h8, BUFE = 4'h9, UNSUP = 4'hB;
  localparam int BUF_W = 32'h0000, BUF_R = 32'h1000, BUF_P = 32'h2000, BUF_Q = 32'h3000, BUF_E = 32'h8000;

  // =========================================================================
  // tests
  // =========================================================================
  task automatic t_csr();
    logic [127:0] w0;
    csr_rd(8'h00); check(rd_val == 32'h5346_3533, "CSR ID reads SF53");
    csr_rd(8'h04); check(rd_val[7:0] == 8'(NUM_CE) && rd_val[15:8] == 8'd8, "CSR VERSION reports DQ width and CE count");
    csr_rd(8'h0C); check(rd_val == 32'h0004_17C1, "CSR CTRL reset value");
    w0 = silicaflux_nand_timing_pkg::mode_word(0, CLK_PS, 2000, 2);
    csr_rd(8'h18); check(rd_val == w0[31:0], $sformatf("TIM0 = mode-0 word %h", rd_val));
    csr_rd(8'h1C); check(rd_val == w0[63:32], $sformatf("TIM1 = mode-0 word %h", rd_val));
    csr_rd(8'h00); csr_wr(8'h00, 32'h0); // write to RO register
    @(negedge clk); csr_sel = 1; csr_we = 1; csr_addr = 8'h00; #1; check(csr_err == 1'b1, "write to a read-only CSR flags csr_err");
    csr_sel = 0; csr_we = 0;
  endtask

  task automatic t_before_reset();
    int n0;
    n0 = total_cmds();
    op(RD, 0, 0, 2, 0, 0, PB, BUF_R, 0, 0, 50);
    check(r_st == NRST, "READ_PAGE before RESET refused (NOT_RESET)");
    check(total_cmds() == n0, "refused request produced no bus traffic");
    op(RST_S, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50);
    check(r_st == OK && r_nst[6] == 1'b1, $sformatf("READ_STATUS (70h) before RESET allowed: %02h", r_nst));
    check(u_mon.cmds(0, 8'h70) == 1 && u_mon.cmds(0, 8'h78) == 0, "pre-reset status uses 70h, never 78h");
    ctrl_set(1, 1'b1);                                            // WP# high
  endtask

  task automatic t_reset_all();
    for (int c = 0; c < NUM_CE; c++) begin
      op(RST, c, 0, 0, 0, 0, 0, 0, 0, 0, 5000);
      check(r_st == OK && r_nst == 8'hE0, $sformatf("CE%0d power-on RESET completes, status %02h", c, r_nst));
      check(r_dev >= 32'(990 * CYC_US) && r_dev <= 32'(1010 * CYC_US),
            $sformatf("CE%0d RESET busy time %0d cycles ~ 1 ms (model t_rst_poweron)", c, r_dev));
    end
  endtask

  task automatic t_read_id();
    for (int c = 0; c < NUM_CE; c++) begin
      op(RID, c, 0, 0, 0, 0, 5, 0, 8'h00, 0, 100);
      check(r_st == OK && r_i0 == 32'h1500_5A00 && r_i1 == 32'h0, $sformatf("CE%0d READ ID 00h = %h %h", c, r_i1, r_i0));
      op(RID, c, 0, 0, 0, 0, 4, 0, 8'h20, 0, 100);
      check(r_st == OK && r_i0 == 32'h4946_4E4F, $sformatf("CE%0d READ ID 20h = \"ONFI\" (%h)", c, r_i0));
    end
  endtask

  task automatic t_param();
    int bad;
    buf_set(BUF_P, 256, 8'h00);
    op(RPRM, 0, 0, 0, 0, 0, 256, BUF_P, 0, 0, 500);
    check(r_st == OK, $sformatf("READ PARAMETER PAGE status %0d", r_st));
    check(r_i0 == 32'd512, "parameter page: 512 data bytes per page");
    check(r_i1[23:16] == 8'h23 && r_i1[31:24] == 8'd2, $sformatf("parameter page: addr cycles 23h, 2 LUNs (%h)", r_i1));
    check(r_i1[11] && r_i1[10] && r_i1[9] && r_i1[8], "parameter page: signature, CRC-16, supported, geometry loaded");
    bad = 0;
    for (int i = 0; i < 256; i++) if (u_mem.mem[BUF_P + i] !== g_tgt[0].u_dev.u_model.param_page[i]) bad++;
    check(bad == 0, $sformatf("parameter page in the buffer equals the device's (%0d mismatches)", bad));
    csr_rd(8'h28); check(rd_val == 32'h0010_0200, $sformatf("GEO0 page/OOB from the parameter page (%h)", rd_val));
    csr_rd(8'h2C); check(rd_val == 32'd16, "GEO1 pages per block = 16");
    csr_rd(8'h30); check(rd_val == 32'd64, "GEO2 blocks per LUN = 64");
    csr_rd(8'h34); check(rd_val == 32'h003F_2302, $sformatf("GEO3 timing modes 3Fh, 2 col + 3 row cycles, 2 LUNs (%h)", rd_val));
    csr_rd(8'h38); check(rd_val == {16'd500, 16'd25}, $sformatf("GEO4 tCCS 500 ns, tR 25 us (%h)", rd_val));
    csr_rd(8'h0C); check(rd_val[4] && rd_val[5], "parameter page enables READ STATUS ENHANCED and multi-LUN operation");
    csr_rd(8'hC8); check(rd_val == 32'h000C_0002, $sformatf("GEO6 optional commands 000Ch / features 0002h (%h)", rd_val));
    csr_rd(8'h40); check(rd_val == 32'(25 * CYC_US * 4 + 1000), $sformatf("read timeout derived from tR max (%0d)", rd_val));
  endtask

  task automatic t_features();
    op(GF, 0, 0, 0, 0, 0, 0, 0, 8'h01, 0, 200);
    check(r_st == OK && r_i0[7:0] == 8'd0, "GET FEATURES 01h: timing mode 0 after power-on");
    begin
      int n0;
      n0 = total_cmds();
      op(SF, 0, 0, 0, 0, 0, 0, 0, 8'h01, 32'h7, 200);
      check(r_st == UNSUP && total_cmds() == n0, "SET FEATURES timing mode 7 refused without bus traffic");
    end
    if (NUM_CE == 1) begin
      op(SF, 0, 0, 0, 0, 0, 0, 0, 8'h01, 32'h5, 200);
      check(r_st == OK && tmode == 3'd5, $sformatf("SET FEATURES timing mode 5; controller switched (mode %0d)", tmode));
    end else begin
      ctrl_set(7, 1'b0);                                          // AUTO_TIM off: switch all targets first
      for (int c = 0; c < NUM_CE; c++) begin
        op(SF, c, 0, 0, 0, 0, 0, 0, 8'h01, 32'h5, 200);
        check(r_st == OK && tmode == 3'd0, $sformatf("CE%0d SET FEATURES mode 5 at controller mode 0", c));
      end
      csr_wr(8'h14, 32'd5);
      ctrl_set(7, 1'b1);
      check(tmode == 3'd5, "controller switched to mode 5 after every target");
    end
    for (int c = 0; c < NUM_CE; c++) begin
      op(GF, c, 0, 0, 0, 0, 0, 0, 8'h01, 0, 200);
      check(r_st == OK && r_i0[7:0] == 8'd5, $sformatf("CE%0d GET FEATURES 01h reads back 5 at mode-5 timing", c));
    end
  endtask

  task automatic t_erase_prog_read();
    op(ER, 0, 0, 2, 0, 0, 0, 0, 0, 0, 5000);
    check(r_st == OK && r_nst == 8'hE0, $sformatf("ERASE lun0 blk2 OK (status %02h)", r_nst));
    check(r_dev >= 32'(990 * CYC_US) && r_dev <= 32'(1020 * CYC_US), $sformatf("erase busy %0d cycles ~ tBERS 1 ms", r_dev));
    buf_set(BUF_R, PB, 8'h00);
    op(RD, 0, 0, 2, 0, 0, PB, BUF_R, 0, 0, 500);
    check(r_st == OK && buf_cmpv(BUF_R, PB, 8'hFF) == 0, "erased page reads all FFh (528 bytes)");
    buf_fill(BUF_W, PB, 1);
    op(PG, 0, 0, 2, 0, 0, PB, BUF_W, 0, 0, 2000);
    check(r_st == OK && r_nst == 8'hE0, $sformatf("PROGRAM lun0 blk2 pg0 OK (status %02h)", r_nst));
    check(r_dev >= 32'(195 * CYC_US) && r_dev <= 32'(215 * CYC_US), $sformatf("program busy %0d cycles ~ tPROG 200 us", r_dev));
    check(dev_cmp0(0, 2, 0, 0, BUF_W, PB) == 0, "device array holds the programmed page (back door)");
    buf_set(BUF_R, PB, 8'h00);
    op(RD, 0, 0, 2, 0, 0, PB, BUF_R, 0, 0, 500);
    check(r_st == OK && buf_cmp(BUF_R, PB, 1, 0) == 0, "READ_PAGE returns the programmed data + spare");
    check(r_dev >= 32'(25 * CYC_US) && r_dev <= 32'(35 * CYC_US), $sformatf("read busy %0d cycles ~ tR 25 us", r_dev));
  endtask

  task automatic t_partial();
    int cols [0:4];
    int lens [0:4];
    cols[0] = 3; cols[1] = 100; cols[2] = 511; cols[3] = 527; cols[4] = 0;
    lens[0] = 1; lens[1] = 37; lens[2] = 17; lens[3] = 1; lens[4] = 528;
    buf_fill(BUF_W, PB, 2);
    op(PG, 0, 0, 2, 1, 0, PB, BUF_W, 0, 0, 2000);
    check(r_st == OK, "PROGRAM lun0 blk2 pg1 OK");
    for (int k = 0; k < 5; k++) begin
      buf_set(BUF_R, 600, 8'hA5);
      op(RD, 0, 0, 2, 1, cols[k], lens[k], BUF_R + 4, 0, 0, 500);
      check(r_st == OK && buf_cmp(BUF_R + 4, lens[k], 2, cols[k]) == 0 && buf_cmpv(BUF_R, 4, 8'hA5) == 0 &&
            buf_cmpv(BUF_R + 4 + lens[k], 8, 8'hA5) == 0,
            $sformatf("partial read col %0d len %0d: data exact, guard bytes untouched", cols[k], lens[k]));
    end
    // partial program: spare area only
    buf_fill(BUF_W, 16, 3);
    op(PG, 0, 0, 2, 2, 512, 16, BUF_W, 0, 0, 2000);
    check(r_st == OK, "partial PROGRAM of the 16 spare bytes of pg2");
    buf_set(BUF_R, PB, 8'h00);
    op(RD, 0, 0, 2, 2, 0, PB, BUF_R, 0, 0, 500);
    check(r_st == OK && buf_cmpv(BUF_R, PD, 8'hFF) == 0 && buf_cmp(BUF_R + PD, 16, 3, 0) == 0,
          "pg2 reads FFh data + programmed spare");
  endtask

  task automatic t_prog_order();
    int n0;
    n0 = u_mon.cmds(0, 8'h80);
    op(PG, 0, 0, 2, 5, 0, PB, BUF_W, 0, 0, 2000);
    check(r_st == PORD && u_mon.cmds(0, 8'h80) == n0, "out-of-order program (pg5 after pg2) refused by the controller");
    ctrl_set(9, 1'b0);
    op(PG, 0, 0, 2, 5, 0, PB, BUF_W, 0, 0, 2000);      // device's sequential rule: next is pg3
    check(r_st == DEVF && r_nst[0], $sformatf("with the check off the device rejects it: status FAIL (%02h)", r_nst));
    ctrl_set(9, 1'b1);
  endtask

  task automatic t_bad_block();
    buf_set(BUF_R, 8, 8'h55);
    op(RD, 0, 0, 5, 0, PD, 1, BUF_R, 0, 0, 500);
    check(r_st == OK && u_mem.mem[BUF_R] == 8'h00, "factory bad-block marker (00h, spare byte 0) read on lun0 blk5");
    op(PG, 0, 0, 5, 0, 0, PB, BUF_W, 0, 0, 2000);
    check(r_st == DEVF, "PROGRAM to the factory-bad block reports device FAIL");
  endtask

  task automatic t_forced_fail();
    op(ER, 0, 0, 3, 0, 0, 0, 0, 0, 0, 5000);
    check(r_st == OK, "ERASE lun0 blk3 OK");
    op(PG, 0, 0, 3, 0, 0, PB, BUF_W, 0, 0, 3000);
    check(r_st == DEVF && r_nst == 8'hE1, $sformatf("injected program failure: FAIL status %02h", r_nst));
    check(r_dev >= 32'(590 * CYC_US), $sformatf("failed program runs 3x longer (%0d cycles)", r_dev));
    op(ER, 0, 0, 4, 0, 0, 0, 0, 0, 0, 8000);
    check(r_st == DEVF && r_nst[0], $sformatf("injected erase failure: FAIL status %02h", r_nst));
  endtask

  task automatic t_wp();
    int n0;
    ctrl_set(1, 1'b0);
    n0 = total_cmds();
    op(PG, 0, 0, 2, 3, 0, PB, BUF_W, 0, 0, 2000);
    check(r_st == WPS, "PROGRAM refused while WP# is low");
    op(ER, 0, 0, 2, 0, 0, 0, 0, 0, 0, 2000);
    check(r_st == WPS, "ERASE refused while WP# is low");
    check(total_cmds() == n0, "write-protected requests never reach the device");
    op(RST_S, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100);
    check(r_st == OK && r_nst[7] == 1'b0, $sformatf("device status shows WP# low (%02h)", r_nst));
    ctrl_set(1, 1'b1);
    buf_fill(BUF_W, PB, 4);
    op(PG, 0, 0, 2, 3, 0, PB, BUF_W, 0, 0, 2000);
    check(r_st == OK, "PROGRAM accepted again after WP# released (tWW respected)");
  endtask

  task automatic t_validation();
    int n0;
    n0 = total_cmds();
    op(RD, 0, 2, 2, 0, 0, PB, BUF_R, 0, 0, 50); check(r_st == BADA, "LUN 2 out of range -> BAD_ADDR");
    op(RD, 0, 0, 64, 0, 0, PB, BUF_R, 0, 0, 50); check(r_st == BADA, "block 64 out of range -> BAD_ADDR");
    op(RD, 0, 0, 2, 16, 0, PB, BUF_R, 0, 0, 50); check(r_st == BADA, "page 16 out of range -> BAD_ADDR");
    op(RD, 0, 0, 2, 0, 520, 9, BUF_R, 0, 0, 50); check(r_st == BADA, "column + length beyond page + OOB -> BAD_ADDR");
    op(RD, 0, 0, 2, 0, 0, 0, BUF_R, 0, 0, 50); check(r_st == BADA, "zero length -> BAD_ADDR");
    op(RD, 0, 0, 2, 0, 0, 16, BUF_R + 2, 0, 0, 50); check(r_st == ALN, "misaligned buffer address -> ALIGN");
    op(4'h9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50); check(r_st == BADOP, "operation code 9 -> BAD_OP");
    op(4'hF, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50); check(r_st == BADOP, "operation code 15 -> BAD_OP");
    op(RD, NUM_CE, 0, 2, 0, 0, PB, BUF_R, 0, 0, 50); check(r_st == BADA, "CE beyond NUM_CE -> BAD_ADDR");
    op(RID, 0, 0, 0, 0, 0, 9, 0, 0, 0, 50); check(r_st == BADA, "READ ID of 9 bytes -> BAD_ADDR");
    op(RPRM, 0, 0, 0, 0, 0, 256, BUF_P + 1, 0, 0, 50); check(r_st == ALN, "parameter page to a misaligned buffer -> ALIGN");
    check(total_cmds() == n0, "no rejected request reached the bus");
    csr_rd(8'hC0); check(rd_val[4] == 1'b1, "sticky REJECT flag set");
    csr_wr(8'hC0, 32'h1F); csr_rd(8'hC0); check(rd_val == 32'd0, "sticky error flags clear on write-1");
  endtask

  task automatic t_status_enh();
    int n0;
    n0 = u_mon.cmds(0, 8'h78);
    op(RST_S, 0, 1, 0, 0, 0, 0, 0, 0, 0, 100);
    check(r_st == OK && r_nst == 8'hE0 && u_mon.cmds(0, 8'h78) == n0 + 1, "READ STATUS lun1 uses 78h + row address");
  endtask

  task automatic t_interleave();
    logic [7:0] ta, tb, tc, td, te;
    ctrl_set(2, 1'b1);
    ta = 8'd200; tb = 8'd201; tc = 8'd202; td = 8'd203; te = 8'd204;
    buf_fill(BUF_W, PB, 5);
    submit(ER, ta, 0, 1, 10, 0, 0, 0, 0, 0, 0);
    submit(RD, tb, 0, 0, 2, 0, 0, PB, BUF_Q, 0, 0);
    submit(RD, tc, 0, 0, 2, 1, 0, PB, BUF_Q + 32'h400, 0, 0);
    submit(PG, td, 0, 0, 2, 4, 0, PB, BUF_W, 0, 0);
    submit(RD, te, 0, 0, 2, 4, 0, PB, BUF_Q + 32'h800, 0, 0);
    wait_cpl(tb, 3000); check(r_st == OK && buf_cmp(BUF_Q, PB, 1, 0) == 0, "interleave: read lun0 pg0 while lun1 erases");
    begin int sb; sb = r_seq;
      wait_cpl(tc, 3000); check(r_st == OK && buf_cmp(BUF_Q + 32'h400, PB, 2, 0) == 0 && r_seq > sb, "interleave: read lun0 pg1 in order");
    end
    wait_cpl(td, 3000); check(r_st == OK, "interleave: program lun0 pg4 while lun1 erases");
    wait_cpl(te, 3000); check(r_st == OK && buf_cmp(BUF_Q + 32'h800, PB, 5, 0) == 0, "interleave: read-after-program on lun0");
    begin int se; se = r_seq;
      wait_cpl(ta, 5000);
      check(r_st == OK && r_seq > se, $sformatf("erase on lun1 completes after the 4 lun0 operations (seq %0d > %0d)", r_seq, se));
    end
  endtask

  task automatic t_queue();
    int n;
    logic [31:0] stall0;
    csr_rd(8'h64 + 4 * 16); stall0 = rd_val;
    n = QD + 4;
    for (int k = 0; k < n; k++) submit(RD, 8'(100 + k), 0, 0, 2, k % 2, 0, PB, BUF_Q + 32'(k * 32'h240), 0, 0);
    for (int k = 0; k < n; k++) begin
      wait_cpl(8'(100 + k), 5000);
      check(r_st == OK && buf_cmp(BUF_Q + k * 32'h240, PB, 1 + (k % 2), 0) == 0, $sformatf("queued read %0d of %0d correct", k, n));
    end
    csr_rd(8'h64 + 4 * 16); check(rd_val > stall0, $sformatf("request-queue stall cycles counted (%0d)", rd_val - stall0));
  endtask

  task automatic t_buf_err();
    int n10;
    u_mem.err_lo = BUF_E; u_mem.err_hi = BUF_E + 32'h400;
    op(RD, 0, 0, 2, 0, 0, PB, BUF_E, 0, 0, 500);
    check(r_st == BUFE, "READ_PAGE into a failing buffer region -> BUF_ERR");
    n10 = u_mon.cmds(0, 8'h10);
    op(PG, 0, 0, 2, b2next, 0, PB, BUF_E, 0, 0, 2000);
    check(r_st == BUFE, "PROGRAM from a failing buffer region -> BUF_ERR");
    check(u_mon.cmds(0, 8'h10) == n10 && g_tgt[0].u_dev.u_model.bd_page_nop(0, 2, b2next) == 0,
          "aborted program never confirmed: page untouched");
    u_mem.err_lo = 0; u_mem.err_hi = 0;
    buf_fill(BUF_W, PB, 6);
    op(PG, 0, 0, 2, b2next, 0, PB, BUF_W, 0, 0, 2000); b2next++;
    check(r_st == OK, "next program after the aborted load succeeds");
  endtask

  task automatic t_timeout();
    logic [31:0] ntmo0;
    csr_rd(8'h64 + 4 * 18); ntmo0 = rd_val;
    csr_rd(8'h48);
    begin
      logic [31:0] tmo_er;
      tmo_er = rd_val;
      csr_wr(8'h48, 32'(100 * CYC_US));
      op(ER, 0, 0, 12, 0, 0, 0, 0, 0, 0, 2000);
      check(r_st == TMO, "ERASE exceeding a 100 us timeout -> TIMEOUT");
      csr_rd(8'hC4); check(rd_val[24] == 1'b1, "target marked faulted after the timeout");
      op(RD, 0, 0, 2, 0, 0, PB, BUF_R, 0, 0, 500);
      check(r_st == NRST, "faulted target refuses operations until RESET");
      csr_wr(8'h48, tmo_er);
    end
    op(RST, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5000);
    check(r_st == OK, "RESET recovers the target (aborts the device's erase)");
    op(ER, 0, 0, 12, 0, 0, 0, 0, 0, 0, 5000);
    check(r_st == OK, "ERASE after recovery OK");
    // stuck R/B#
    csr_wr(8'h4C, 32'(500 * CYC_US));
    rb_stuck[0] = 1'b1;
    op(RST, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3000);
    check(r_st == TMO, "RESET with R/B# stuck low -> TIMEOUT");
    rb_stuck[0] = 1'b0;
    op(RST, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3000);
    check(r_st == OK, "RESET after R/B# released OK");
    csr_rd(8'h64 + 4 * 18); check(rd_val == ntmo0 + 2, $sformatf("timeout counter recorded both injected timeouts (%0d)", rd_val - ntmo0));
    csr_wr(8'h4C, 32'(10000 * CYC_US));
  endtask

  task automatic t_ctrl_reset();
    logic [7:0] t;
    t = 8'd210;
    submit(ER, t, 0, 0, 13, 0, 0, 0, 0, 0, 0);
    #(100000);                                     // erase in progress on the device
    rst_n = 0;
    repeat (5) @(negedge clk);
    rst_n = 1;
    repeat (5) @(negedge clk);
    check(tmode == 3'd0 && !busy, "controller reset: idle, timing mode 0");
    ctrl_set(1, 1'b1);
    op(RID, 0, 0, 0, 0, 0, 5, 0, 8'h00, 0, 100);
    check(r_st == NRST, "after controller reset every target needs RESET");
    for (int c = 0; c < NUM_CE; c++) begin
      op(RST, c, 0, 0, 0, 0, 0, 0, 0, 0, 5000);
      check(r_st == OK, $sformatf("CE%0d RESET after controller reset (device erase aborted)", c));
    end
    op(RPRM, 0, 0, 0, 0, 0, 0, 0, 0, 0, 500);
    check(r_st == OK, "parameter page re-read: geometry restored");
    if (NUM_CE == 1) begin
      op(SF, 0, 0, 0, 0, 0, 0, 0, 8'h01, 32'h5, 200);
      check(r_st == OK && tmode == 3'd5, "back to timing mode 5");
    end else begin
      csr_wr(8'h14, 32'd5);
    end
    buf_set(BUF_R, PB, 8'h00);
    op(RD, 0, 0, 2, 0, 0, PB, BUF_R, 0, 0, 500);
    check(r_st == OK && buf_cmp(BUF_R, PB, 1, 0) == 0, "data written before the controller reset is intact");
    ctrl_set(2, 1'b1);
  endtask

  task automatic t_modes();
    for (int m = 0; m < 6; m++) begin
      logic [31:0] rlat, plat, rdev, pdev, dc0, dc1, cy0, cy1;
      if (NUM_CE == 1) begin
        op(SF, 0, 0, 0, 0, 0, 0, 0, 8'h01, 32'(m), 200);
        check(r_st == OK && tmode == 3'(m), $sformatf("switch to timing mode %0d", m));
      end else begin
        ctrl_set(7, 1'b0);
        for (int c = 0; c < NUM_CE; c++) op(SF, c, 0, 0, 0, 0, 0, 0, 8'h01, 32'(m), 200);
        csr_wr(8'h14, 32'(m));
        ctrl_set(7, 1'b1);
      end
      if (m == 0) begin
        op(ER, 0, 1, 14, 0, 0, 0, 0, 0, 0, 5000);
        check(r_st == OK, "erase lun1 blk14 for the mode sweep");
      end
      buf_fill(BUF_W, PB, 20 + m);
      op(PG, 0, 1, 14, m, 0, PB, BUF_W, 0, 0, 2000); plat = r_lat; pdev = r_dev;
      check(r_st == OK, $sformatf("mode %0d: program", m));
      buf_set(BUF_R, PB, 8'h00);
      csr_rd(8'h64 + 4 * 2); dc0 = rd_val; csr_rd(8'h64); cy0 = rd_val;
      op(RD, 0, 1, 14, m, 0, PB, BUF_R, 0, 0, 500); rlat = r_lat; rdev = r_dev;
      csr_rd(8'h64 + 4 * 2); dc1 = rd_val; csr_rd(8'h64); cy1 = rd_val;
      check(r_st == OK && buf_cmp(BUF_R, PB, 20 + m, 0) == 0, $sformatf("mode %0d: read back exact", m));
      $fdisplay(rfd, "PERF mode %0d program_latency_cycles %0d program_busy_cycles %0d read_latency_cycles %0d read_busy_cycles %0d read_data_beat_cycles %0d bytes %0d clk_ps %0d",
                m, plat, pdev, rlat, rdev, dc1 - dc0, PB, CLK_PS);
    end
  endtask

  task automatic t_ce_isolation();
    // second target: same address, different data
    op(ER, 1, 0, 2, 0, 0, 0, 0, 0, 0, 5000);
    check(r_st == OK, "CE1 erase lun0 blk2");
    buf_fill(BUF_W, PB, 9);
    op(PG, 1, 0, 2, 0, 0, PB, BUF_W, 0, 0, 2000);
    check(r_st == OK, "CE1 program lun0 blk2 pg0");
    buf_set(BUF_R, PB, 8'h00);
    op(RD, 1, 0, 2, 0, 0, PB, BUF_R, 0, 0, 500);
    check(r_st == OK && buf_cmp(BUF_R, PB, 9, 0) == 0, "CE1 reads its own data");
    op(RD, 0, 0, 2, 0, 0, PB, BUF_R, 0, 0, 500);
    check(r_st == OK && buf_cmp(BUF_R, PB, 1, 0) == 0, "CE0 data at the same address unaffected (CE# isolation)");
    // concurrency across targets
    begin
      logic [7:0] te, tr0, tr1;
      int se;
      te = 8'd220; tr0 = 8'd221; tr1 = 8'd222;
      submit(ER, te, 1, 1, 20, 0, 0, 0, 0, 0, 0);
      submit(RD, tr0, 0, 0, 2, 0, 0, PB, BUF_Q, 0, 0);
      submit(RD, tr1, 0, 0, 2, 1, 0, PB, BUF_Q + 32'h400, 0, 0);
      wait_cpl(tr0, 3000); check(r_st == OK && buf_cmp(BUF_Q, PB, 1, 0) == 0, "CE0 read while CE1 erases");
      wait_cpl(tr1, 3000); check(r_st == OK && buf_cmp(BUF_Q + 32'h400, PB, 2, 0) == 0, "second CE0 read while CE1 erases");
      se = r_seq;
      wait_cpl(te, 5000); check(r_st == OK && r_seq > se, "CE1 erase completes after both CE0 reads");
    end
  endtask

  task automatic t_arbitration();
    // FIFO policy: older program issues first; read priority: read first
    int c0;
    logic [7:0] tp, tr;
    for (int pol = 0; pol < 2; pol++) begin
      ctrl_set(3, pol[0]);
      ctrl_set(0, 1'b0);                                      // hold the scheduler
      tp = 8'(230 + 2 * pol); tr = 8'(231 + 2 * pol);
      buf_fill(BUF_W, PB, 30 + pol);
      submit(PG, tp, 0, 0, 2, b2next, 0, PB, BUF_W, 0, 0); b2next++;
      submit(RD, tr, 0, 1, 10, 0, 0, PB, BUF_Q, 0, 0);
      c0 = u_mon.conf_n;
      ctrl_set(0, 1'b1);
      wait_cpl(tp, 3000); check(r_st == OK, $sformatf("arbitration policy %0d: program OK", pol));
      wait_cpl(tr, 3000); check(r_st == OK && buf_cmpv(BUF_Q, PB, 8'hFF) == 0, $sformatf("arbitration policy %0d: read OK", pol));
      check(u_mon.conf_op[c0] == ((pol == 0) ? 8'h10 : 8'h30),
            $sformatf("policy %s: first confirm on the bus is %02h", (pol == 0) ? "oldest-first" : "read-priority",
                      u_mon.conf_op[c0]));
    end
    ctrl_set(3, 1'b0);
  endtask

  task automatic t_starvation();
    // read priority with starvation limit 2, three LUNs with reads queued, one program
    logic [31:0] cv;
    int c0, pos;
    csr_rd(8'h0C); cv = rd_val;
    cv[3] = 1'b1; cv[19:16] = 4'd2; cv[0] = 1'b0;
    csr_wr(8'h0C, cv);
    buf_fill(BUF_W, PB, 40);
    submit(PG, 8'd240, 0, 0, 2, b2next, 0, PB, BUF_W, 0, 0); b2next++;
    submit(RD, 8'd241, 1, 0, 2, 0, 0, PB, BUF_Q, 0, 0);
    submit(RD, 8'd242, 1, 1, 20, 0, 0, PB, BUF_Q + 32'h400, 0, 0);
    submit(RD, 8'd243, 0, 1, 10, 0, 0, PB, BUF_Q + 32'h800, 0, 0);
    c0 = u_mon.conf_n;
    cv[0] = 1'b1; csr_wr(8'h0C, cv);
    for (int k = 240; k < 244; k++) begin wait_cpl(8'(k), 3000); check(r_st == OK, $sformatf("starvation test op %0d OK", k)); end
    pos = -1;
    for (int k = c0; k < u_mon.conf_n; k++) if (pos < 0 && u_mon.conf_op[k] == 8'h10) pos = k - c0;
    check(pos == 2, $sformatf("program issued after exactly 2 bypassing reads (position %0d)", pos));
    cv[3] = 1'b0; cv[19:16] = 4'd4; csr_wr(8'h0C, cv);
  endtask

  task automatic t_perf();
    logic [31:0] v [0:22];
    for (int p = 0; p < 23; p++) begin csr_rd(8'(8'h64 + 4 * p)); v[p] = rd_val; end
    $fdisplay(rfd, "PERF counters cycles %0d bus_busy %0d bus_data %0d array_busy %0d bytes_rd %0d bytes_wr %0d n_read %0d n_prog %0d n_erase %0d n_other %0d",
              v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9]);
    $fdisplay(rfd, "PERF latency rd_sum %0d rd_max %0d pg_sum %0d pg_max %0d er_sum %0d er_max %0d q_stall %0d cpl_stall %0d n_tmo %0d n_err %0d n_poll %0d n_poll_miss %0d bus_idle %0d",
              v[10], v[11], v[12], v[13], v[14], v[15], v[16], v[17], v[18], v[19], v[20], v[21], v[22]);
    check((v[1] + v[22]) >= v[0] && (v[1] + v[22]) - v[0] < 80,
          $sformatf("bus busy + idle cycles = total cycles (+%0d cycles of CSR reads)", (v[1] + v[22]) - v[0]));
    check(v[4] > 0 && v[5] > 0 && v[6] > 0 && v[7] > 0 && v[8] > 0, "byte and operation counters advanced");
    check(v[11] >= 32'(v[10] / (v[6] == 0 ? 1 : v[6])), "max read latency >= mean read latency");
    check(v[20] >= v[21], "polls >= poll misses");
    csr_wr(8'h60, 32'd1); csr_rd(8'h64 + 4 * 6); check(rd_val == 32'd0, "performance counters clear");
  endtask


  // ---------------------------------------------------------------- waveform demonstration
  int mfd;
  real mk_t0;
  task automatic mark_begin();
    mk_t0 = $realtime;
  endtask
  task automatic mark_end(input string name);
    $fdisplay(mfd, "MARK %s %0.3f %0.3f", name, mk_t0, $realtime);
  endtask
  task automatic t_demo();
    string mf;
    if (!$value$plusargs("MARKS=%s", mf)) mf = {dir, "/marks.txt"};
    mfd = $fopen(mf, "w");
    ctrl_set(1, 1'b1);
    mark_begin(); op(RST, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5000); mark_end("reset");
    check(r_st == OK, "demo: RESET");
    mark_begin(); op(RID, 0, 0, 0, 0, 0, 5, 0, 8'h00, 0, 100); mark_end("read_id_mode0");
    check(r_st == OK && r_i0 == 32'h1500_5A00, "demo: READ ID");
    mark_begin(); op(RPRM, 0, 0, 0, 0, 0, 256, BUF_P, 0, 0, 500); mark_end("read_param_mode0");
    check(r_st == OK, "demo: parameter page");
    mark_begin(); op(ER, 0, 0, 2, 0, 0, 0, 0, 0, 0, 5000); mark_end("erase_mode0");
    check(r_st == OK, "demo: ERASE");
    buf_fill(BUF_W, 16, 77);
    mark_begin(); op(PG, 0, 0, 2, 0, 0, 16, BUF_W, 0, 0, 2000); mark_end("program16_mode0");
    check(r_st == OK, "demo: PROGRAM 16 bytes");
    mark_begin(); op(RD, 0, 0, 2, 0, 0, 16, BUF_R, 0, 0, 500); mark_end("read16_mode0");
    check(r_st == OK && buf_cmp(BUF_R, 16, 77, 0) == 0, "demo: READ 16 bytes");
    mark_begin(); op(SF, 0, 0, 0, 0, 0, 0, 0, 8'h01, 32'h5, 200); mark_end("set_features_mode5");
    check(r_st == OK && tmode == 3'd5, "demo: SET FEATURES timing mode 5");
    mark_begin(); op(GF, 0, 0, 0, 0, 0, 0, 0, 8'h01, 0, 200); mark_end("get_features_mode5");
    check(r_st == OK && r_i0[7:0] == 8'd5, "demo: GET FEATURES");
    buf_fill(BUF_W, 16, 78);
    mark_begin(); op(PG, 0, 0, 2, 1, 0, 16, BUF_W, 0, 0, 2000); mark_end("program16_mode5");
    check(r_st == OK, "demo: PROGRAM at mode 5");
    mark_begin(); op(RD, 0, 0, 2, 1, 0, 16, BUF_R, 0, 0, 500); mark_end("read16_mode5");
    check(r_st == OK && buf_cmp(BUF_R, 16, 78, 0) == 0, "demo: READ at mode 5");
    ctrl_set(2, 1'b1);
    mark_begin();
    submit(ER, 8'd190, 0, 1, 10, 0, 0, 0, 0, 0, 0);
    submit(RD, 8'd191, 0, 0, 2, 0, 0, 16, BUF_Q, 0, 0);
    submit(RD, 8'd192, 0, 0, 2, 1, 0, 16, BUF_Q + 32'h100, 0, 0);
    wait_cpl(8'd191, 2000); check(r_st == OK, "demo: read lun0 during lun1 erase");
    wait_cpl(8'd192, 2000); check(r_st == OK, "demo: second read lun0 during lun1 erase");
    wait_cpl(8'd190, 3000); check(r_st == OK, "demo: lun1 erase");
    mark_end("interleave_mode5");
    $fclose(mfd);
  endtask

  // ---------------------------------------------------------------- negative test
  task automatic t_negative();
    ctrl_set(1, 1'b1);
    op(RST, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5000);
    check(r_st == OK, "negative test: RESET with correct timing");
    check(tgt_timing[0] == 0 && u_mon.n_viol == 0, "negative test: clean before the fault");
    csr_wr(8'h18, 32'h0101_0101);                    // tWP = tWH = tRP = tREH = 1 cycle at mode 0
    op(RID, 0, 0, 0, 0, 0, 5, 0, 8'h00, 0, 100);
    @(negedge clk);
    check(tgt_timing[0] > 0, $sformatf("model AC checker detects the mis-programmed timing (%0d violations)", tgt_timing[0]));
    check(u_mon.viol[u_mon.V_WP] > 0 && u_mon.viol[u_mon.V_RP] > 0,
          $sformatf("monitor detects tWP / tRP violations (%0d / %0d)", u_mon.viol[u_mon.V_WP], u_mon.viol[u_mon.V_RP]));
  endtask

  // =========================================================================
  initial begin
    req_valid = 0; req_op = 0; req_tag = 0; req_ce = 0; req_lun = 0; req_block = 0; req_page = 0; req_col = 0;
    req_len = 0; req_buf = 0; req_faddr = 0; req_fdata = 0; cpl_ready = 1; csr_sel = 0; csr_we = 0; csr_addr = 0;
    csr_wdata = 0; n_pass = 0; n_fail = 0; n_cpl = 0; tagc = 0; b2next = 5;
    for (int i = 0; i < 256; i++) c_got[i] = 0;
    if (!$value$plusargs("TEST=%s", test)) test = "suite";
    if (!$value$plusargs("NANDLAB_DIR=%s", dir)) dir = ".";
    if (!$value$plusargs("RESULT=%s", resfile)) resfile = {dir, "/tb_flashlink.result"};
    rfd = $fopen(resfile, "w");
    begin
      string vcd;
      real vfrom, vlen;
      if ($value$plusargs("VCD=%s", vcd)) begin
        if (!$value$plusargs("VCD_FROM_NS=%f", vfrom)) vfrom = 0.0;
        if (!$value$plusargs("VCD_LEN_NS=%f", vlen)) vlen = 1.0e12;
        $dumpfile(vcd);
        if ($test$plusargs("VCD_PINS")) begin
          $dumpvars(0, p_ce_n, p_cle, p_ale, p_we_n, p_re_n, p_wp_n, p_dq, p_rb_n, g_dq_oe);
          $dumpvars(0, req_valid, req_ready, req_op, cpl_valid, cpl_tag, cpl_status, m_req_valid, m_req_write);
`ifndef GLS
          $dumpvars(0, dut.bst, dut.tmode, dut.lun_busy, dut.tgt_busy);
`endif
        end else begin
          $dumpvars(1, tb_flashlink);
`ifndef GLS
          $dumpvars(1, dut);
          $dumpvars(1, dut.u_eng);
          $dumpvars(1, dut.u_bm);
`endif
        end
        $dumpoff;
        fork
          begin #(vfrom) $dumpon; #(vlen) $dumpoff; end
        join_none
      end
    end
    u_mem.stall_pct = 20; u_mem.lat_min = 1; u_mem.lat_max = 3;
    repeat (8) @(negedge clk);
    rst_n = 1;
    repeat (4) @(negedge clk);
    $fdisplay(rfd, "CONFIG test %s NUM_CE %0d RB_SHARED %0d CLK_PS %0d QUEUE_DEPTH %0d", test, NUM_CE, RB_SHARED, CLK_PS, QD);
    if (test == "negative") begin
      t_negative();
    end else if (test == "demo") begin
      t_demo();
      for (int c = 0; c < NUM_CE; c++) check(tgt_proto[c] == 0 && tgt_timing[c] == 0, "demo: model clean");
      check(u_mon.n_viol == 0, "demo: monitor clean");
    end else begin
      t_csr();
      t_before_reset();
      t_reset_all();
      t_read_id();
      t_param();
      t_features();
      t_erase_prog_read();
      t_partial();
      t_prog_order();
      t_bad_block();
      t_forced_fail();
      t_wp();
      t_validation();
      t_status_enh();
      t_interleave();
      t_queue();
      t_buf_err();
      if (NUM_CE > 1) begin
        t_ce_isolation();
        t_starvation();
      end
      t_arbitration();
      t_timeout();
      t_ctrl_reset();
      t_modes();
      t_perf();
      // global checkers
      for (int c = 0; c < NUM_CE; c++) begin
        check(tgt_proto[c] == 0, $sformatf("CE%0d model: zero protocol errors (%0d)", c, tgt_proto[c]));
        check(tgt_timing[c] == 0, $sformatf("CE%0d model: zero AC timing violations (%0d)", c, tgt_timing[c]));
      end
      check(u_mon.n_viol == 0, $sformatf("monitor: zero timing / electrical / sequence violations (%0d in %0d checks)",
                                        u_mon.n_viol, u_mon.n_checks));
      check(u_mem.n_proto == 0, "SFB2 buffer port: zero protocol errors");
    end
    u_mon.report(rfd);
    $fdisplay(rfd, "MODEL cmds %0d din %0d dout %0d sim_time_ns %0.0f", u_mon.n_cmd_total, u_mon.n_din_total,
              u_mon.n_dout_total, $realtime);
    $fdisplay(rfd, "SUMMARY test %s pass %0d fail %0d", test, n_pass, n_fail);
    $fclose(rfd);
    $display("[TB] %s: %0d passed, %0d failed", test, n_pass, n_fail);
    $finish;
  end

  initial begin
    #(400_000_000);
    $display("[TB] WATCHDOG");
    $fdisplay(rfd, "CHECK FAIL watchdog");
    $fdisplay(rfd, "SUMMARY test %s pass %0d fail %0d", test, n_pass, n_fail + 1);
    $fclose(rfd);
    $finish;
  end
endmodule
