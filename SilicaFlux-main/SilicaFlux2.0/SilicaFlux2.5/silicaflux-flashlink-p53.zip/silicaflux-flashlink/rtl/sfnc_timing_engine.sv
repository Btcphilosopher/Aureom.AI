// =============================================================================
// sfnc_timing_engine.sv -- SilicaFlux FlashLink, Project 53
// -----------------------------------------------------------------------------
// Timing / interface-adaptation layer of the NAND channel controller.
//
// Converts micro-operations from the command sequencer into the pin waveforms
// of the asynchronous (SDR) NAND interface. Every pin output is a flop (ready
// for I/O-cell placement); timing is expressed in controller-clock cycles from
// the timing word (TIM0..TIM3, see silicaflux_nand_timing_pkg).
//
//   write cycle (U_CMD / U_ADDR / U_DIN):
//     [setup su] CLE/ALE/DQ valid, WE# high -> [wp] WE# low -> [wh] WE# high
//     The device latches on the WE# rising edge. CLE/ALE return low at the end
//     of the wh phase unless the next beat starts on that edge.
//   read cycle (U_DOUT):
//     [rp] RE# low; DQ captured on the edge that raises RE# -> [reh] RE# high
//
// Cross-cycle rules enforced here for every sequence (cycle counters since the
// last event, saturating at 255):
//     RE# rise  -> DQ driven / WE# fall   >= rhw  (tRHW, also covers tRHZ)
//     WE# rise  -> RE# fall               >= whr  (tWHR, covers tCLR / tAR)
//     ADDR WE# rise -> DIN cycle start     >= adl  (tADL, conservative)
//     CE# fall  -> first strobe            >= cs   (tCS / tCEA)
//     last strobe -> CE# rise              >= ch   (tCH)
//     CE# high time between two selects    >= ch
//     WP# change -> WE# fall               >= ww   (tWW)
//     DQ released (dq_oe = 0) at least one cycle before RE# falls.
// Command-specific waits (tWB after a confirm, tRR after ready) are issued
// by the sequencer as U_DELAY micro-ops.
//
// Handshake: the sequencer holds uop_valid with stable fields; the engine
// latches the micro-op, executes all of its beats and pulses uop_done for one
// cycle (during which it ignores uop_valid). uop_abort ends a DIN/DOUT burst
// at the next beat boundary.
// R/B# inputs are asynchronous: sfnc_sync (2 flops) per line.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfnc_timing_engine #(
  parameter int DQW         = 8,
  parameter int NUM_CE      = 1,
  parameter int NUM_RB      = 1,
  parameter int SYNC_STAGES = 2,
  localparam int CEW        = (NUM_CE > 1) ? $clog2(NUM_CE) : 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic [87:0]       tw,           // timing word bits used here (TIM0, TIM1, TIM2[23:0])
  input  wire logic              wp_n_req,
  // micro-operation
  input  wire logic              uop_valid,
  input  wire logic [2:0]        uop_kind,
  input  wire logic [39:0]       uop_bytes,    // CMD / ADDR / immediate data, LSB first
  input  wire logic [15:0]       uop_count,    // beats (ADDR bytes, DIN/DOUT units, DELAY cycles)
  input  wire logic [CEW-1:0]    uop_ce,
  input  wire logic              uop_imm,      // DIN from uop_bytes instead of the stream
  input  wire logic              uop_abort,
  output logic                   uop_done,
  // data-in stream (buffer -> NAND)
  input  wire logic              din_valid,
  input  wire logic [DQW-1:0]    din_data,
  output logic                   din_pop,
  // data-out (NAND -> sequencer / buffer)
  input  wire logic              dout_space,
  output logic                   dout_valid,
  output logic [DQW-1:0]         dout_data,
  // status
  output logic [NUM_RB-1:0]      rb_ready,     // synchronised R/B# (1 = ready)
  output logic                   data_beat,
  output logic                   active,
  // NAND pins (registered)
  output logic [NUM_CE-1:0]      ce_n,
  output logic                   cle,
  output logic                   ale,
  output logic                   we_n,
  output logic                   re_n,
  output logic                   wp_n,
  output logic [DQW-1:0]         dq_o,
  output logic                   dq_oe,
  input  wire logic [DQW-1:0]    dq_i,
  input  wire logic [NUM_RB-1:0] rb_n
);
  // ------------------------------------------------------------ timing fields
  wire [7:0] t_wp  = tw[0  +: 8];
  wire [7:0] t_wh  = tw[8  +: 8];
  wire [7:0] t_rp  = tw[16 +: 8];
  wire [7:0] t_reh = tw[24 +: 8];
  wire [7:0] t_su  = tw[32 +: 8];
  wire [7:0] t_whr = tw[40 +: 8];
  wire [7:0] t_adl = tw[48 +: 8];
  wire [7:0] t_rhw = tw[56 +: 8];
  wire [7:0] t_cs  = tw[64 +: 8];
  wire [7:0] t_ch  = tw[72 +: 8];
  wire [7:0] t_ww  = tw[80 +: 8];
  // pulse widths of at least one cycle whatever was programmed
  wire [7:0] wp1  = (t_wp  == 8'd0) ? 8'd1 : t_wp;
  wire [7:0] wh1  = (t_wh  == 8'd0) ? 8'd1 : t_wh;
  wire [7:0] rp1  = (t_rp  == 8'd0) ? 8'd1 : t_rp;
  wire [7:0] reh1 = (t_reh == 8'd0) ? 8'd1 : t_reh;

  // ------------------------------------------------------------ R/B# sync
  for (genvar g = 0; g < NUM_RB; g++) begin : g_rb
    sfnc_sync #(.STAGES(SYNC_STAGES), .RESET_VAL(1'b0)) u_sync (
      .clk(clk), .rst_n(rst_n), .d(rb_n[g]), .q(rb_ready[g]));
  end

  // ------------------------------------------------------------ state
  localparam logic [2:0] E_IDLE = 3'd0, E_WSU = 3'd1, E_WLO = 3'd2, E_WHI = 3'd3,
                         E_RLO  = 3'd4, E_RHI = 3'd5, E_DLY = 3'd6;
  logic [2:0]     st;
  logic [15:0]    cnt;
  logic           act, done_q;
  logic [2:0]     k;
  logic [15:0]    left;
  logic           left_z, left_1;
  logic [DQW-1:0] hold;                    // prefetched data-in unit
  logic           hold_v;          // registered (left == 0), (left == 1): keep the decrement off the start path
  logic [2:0]     bi;
  logic [63:0]    bytes_q;
  logic           imm_q;
  logic [CEW-1:0] tce, ce_act;
  logic           ce_on;
  // elapsed-cycle counters (number of edges since the event, saturating)
  logic [7:0]     c_we, c_adr, c_re, c_cs, c_ceoff, c_ww;

  function automatic logic [7:0] inc8(input logic [7:0] v);
    inc8 = (v == 8'hFF) ? v : v + 8'd1;
  endfunction

  wire is_wr = (k == silicaflux_nand_pkg::U_CMD) || (k == silicaflux_nand_pkg::U_ADDR) ||
               (k == silicaflux_nand_pkg::U_DIN);
  wire is_rd = (k == silicaflux_nand_pkg::U_DOUT);
  wire is_din_stream = (k == silicaflux_nand_pkg::U_DIN) && !imm_q;

  // phase ends
  wire whi_end   = (st == E_WHI) && (cnt == 16'd0);
  wire rhi_end   = (st == E_RHI) && (cnt == 16'd0);
  wire beat_end  = whi_end || rhi_end;
  wire [15:0] left_now = beat_end ? (left - 16'd1) : left;
  wire at_issue  = act && ((st == E_IDLE) || beat_end);
  wire more      = (beat_end ? !left_1 : !left_z) && !uop_abort;

  // beat start conditions (current counter values = cycles elapsed so far)
  wire ok_wr = (c_re >= t_rhw) && (c_cs >= t_cs) && (c_ww >= t_ww) &&
               ((k != silicaflux_nand_pkg::U_DIN) || (c_adr >= t_adl)) &&
               (!is_din_stream || hold_v) && ce_on;
  wire ok_rd = !dq_oe && (c_we >= t_whr) && (c_cs >= t_cs) && dout_space && ce_on;
  wire start_wr = at_issue && more && is_wr && ok_wr;
  wire start_rd = at_issue && more && is_rd && ok_rd;

  wire [2:0]     bi_now   = beat_end ? (bi + 3'd1) : bi;     // byte of the beat being started
  logic [7:0]    cur_byte;
  always_comb begin
    cur_byte = bytes_q[7:0];
    for (int b = 0; b < 8; b++) if (bi_now == 3'(b)) cur_byte = bytes_q[b*8 +: 8];
  end
  wire [DQW-1:0] beat_data = is_din_stream ? hold : {{(DQW-8){1'b0}}, cur_byte};

  // one-unit prefetch: pull the next stream unit whenever the holding register is empty
  // (depends on registers only; a beat start consumes the held unit)
  assign din_pop   = act && is_din_stream && !hold_v && din_valid;
  assign uop_done  = done_q;
  assign data_beat = act && ((k == silicaflux_nand_pkg::U_DIN) || (k == silicaflux_nand_pkg::U_DOUT));
  assign active    = act || (st != E_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= E_IDLE; cnt <= 16'd0; act <= 1'b0; done_q <= 1'b0; k <= 3'd0; left <= 16'd0; bi <= 3'd0;
      left_z <= 1'b1; left_1 <= 1'b0; hold <= '0; hold_v <= 1'b0;
      bytes_q <= 64'd0; imm_q <= 1'b0; tce <= '0; ce_act <= '0; ce_on <= 1'b0;
      c_we <= 8'hFF; c_adr <= 8'hFF; c_re <= 8'hFF; c_cs <= 8'hFF; c_ceoff <= 8'hFF; c_ww <= 8'hFF;
      ce_n <= {NUM_CE{1'b1}}; cle <= 1'b0; ale <= 1'b0; we_n <= 1'b1; re_n <= 1'b1; wp_n <= 1'b0;
      dq_o <= '0; dq_oe <= 1'b0; dout_valid <= 1'b0; dout_data <= '0;
    end else begin
      done_q     <= 1'b0;
      dout_valid <= 1'b0;
      if (din_pop) begin
        hold   <= din_data;
        hold_v <= 1'b1;
      end
      c_we    <= inc8(c_we);
      c_adr   <= inc8(c_adr);
      c_re    <= inc8(c_re);
      c_cs    <= inc8(c_cs);
      c_ceoff <= inc8(c_ceoff);
      c_ww    <= inc8(c_ww);
      wp_n    <= wp_n_req;
      if (wp_n != wp_n_req) c_ww <= 8'd1;

      // ------------------------------------------------ phase progression
      case (st)
        E_WSU: begin
          if (cnt == 16'd0) begin
            we_n <= 1'b0;
            cnt  <= 16'(wp1) - 16'd1;
            st   <= E_WLO;
          end else cnt <= cnt - 16'd1;
        end
        E_WLO: begin
          if (cnt == 16'd0) begin
            we_n <= 1'b1;                          // device latches here
            c_we <= 8'd1;
            if (k == silicaflux_nand_pkg::U_ADDR) c_adr <= 8'd1;
            cnt  <= 16'(wh1) - 16'd1;
            st   <= E_WHI;
          end else cnt <= cnt - 16'd1;
        end
        E_WHI: begin
          if (cnt != 16'd0) cnt <= cnt - 16'd1;
        end
        E_RLO: begin
          if (cnt == 16'd0) begin
            dout_data  <= dq_i;                    // sampled before RE# rises
            dout_valid <= 1'b1;
            re_n <= 1'b1;
            c_re <= 8'd1;
            cnt  <= 16'(reh1) - 16'd1;
            st   <= E_RHI;
          end else cnt <= cnt - 16'd1;
        end
        E_RHI: begin
          if (cnt != 16'd0) cnt <= cnt - 16'd1;
        end
        E_DLY: begin
          if (cnt == 16'd0) begin
            st <= E_IDLE; act <= 1'b0; done_q <= 1'b1;
          end else cnt <= cnt - 16'd1;
        end
        default: ;
      endcase

      // ------------------------------------------------ beat boundary
      if (beat_end) begin
        left   <= left_now;
        left_z <= left_1;
        left_1 <= (left == 16'd2);
        bi   <= bi + 3'd1;
        if (whi_end) begin
          cle <= 1'b0;
          ale <= 1'b0;
        end
        st <= E_IDLE;
        if (!more) begin
          act    <= 1'b0;
          done_q <= 1'b1;
        end
      end

      // ------------------------------------------------ idle: latch / control kinds
      if (st == E_IDLE && !act) begin
        if (uop_valid && !done_q) begin
          act     <= 1'b1;
          k       <= uop_kind;
          left    <= uop_count;
          left_z  <= (uop_count == 16'd0);
          hold_v  <= 1'b0;
          left_1  <= (uop_count == 16'd1);
          bytes_q <= {24'd0, uop_bytes};
          imm_q   <= uop_imm;
          tce     <= uop_ce;
          bi      <= 3'd0;
        end
      end else if (st == E_IDLE && act) begin
        case (k)
          silicaflux_nand_pkg::U_DELAY: begin
            if (left_z) begin
              act <= 1'b0; done_q <= 1'b1;
            end else begin
              cnt <= left - 16'd1;
              st  <= E_DLY;
            end
          end
          silicaflux_nand_pkg::U_CESEL: begin
            if (ce_on && ce_act == tce) begin
              act <= 1'b0; done_q <= 1'b1;
            end else if (ce_on) begin
              if (c_we >= t_ch && c_re >= t_ch) begin
                ce_n    <= {NUM_CE{1'b1}};
                ce_on   <= 1'b0;
                c_ceoff <= 8'd1;
                dq_oe   <= 1'b0;
              end
            end else if (c_ceoff >= t_ch) begin
              for (int i = 0; i < NUM_CE; i++) ce_n[i] <= (CEW'(i) != tce);
              ce_on        <= 1'b1;
              ce_act       <= tce;
              c_cs         <= 8'd1;
              act <= 1'b0; done_q <= 1'b1;
            end
          end
          silicaflux_nand_pkg::U_CEOFF: begin
            if (!ce_on) begin
              dq_oe <= 1'b0;
              act <= 1'b0; done_q <= 1'b1;
            end else if (c_we >= t_ch && c_re >= t_ch) begin
              ce_n    <= {NUM_CE{1'b1}};
              ce_on   <= 1'b0;
              c_ceoff <= 8'd1;
              dq_oe   <= 1'b0;
              act <= 1'b0; done_q <= 1'b1;
            end
          end
          default: begin
            // DIN / DOUT / CMD / ADDR waiting to start a beat
            if (left_z || uop_abort) begin
              act <= 1'b0; done_q <= 1'b1;
            end else if (is_rd && dq_oe) begin
              dq_oe <= 1'b0;                       // release DQ before RE# falls
            end
          end
        endcase
      end

      // ------------------------------------------------ start a beat (overrides)
      if (start_wr) begin
        cle   <= (k == silicaflux_nand_pkg::U_CMD);
        ale   <= (k == silicaflux_nand_pkg::U_ADDR);
        dq_o  <= beat_data;
        if (is_din_stream) hold_v <= 1'b0;
        dq_oe <= 1'b1;
        act   <= 1'b1;
        done_q <= 1'b0;
        if (t_su == 8'd0) begin
          we_n <= 1'b0;
          cnt  <= 16'(wp1) - 16'd1;
          st   <= E_WLO;
        end else begin
          cnt <= 16'(t_su) - 16'd1;
          st  <= E_WSU;
        end
      end
      if (start_rd) begin
        re_n   <= 1'b0;
        act    <= 1'b1;
        done_q <= 1'b0;
        cnt    <= 16'(rp1) - 16'd1;
        st     <= E_RLO;
      end
    end
  end

endmodule

`default_nettype wire
