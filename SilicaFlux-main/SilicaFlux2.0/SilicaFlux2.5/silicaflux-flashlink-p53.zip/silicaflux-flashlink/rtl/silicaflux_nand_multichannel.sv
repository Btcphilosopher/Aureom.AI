// =============================================================================
// silicaflux_nand_multichannel.sv -- SilicaFlux FlashLink, Project 53
// -----------------------------------------------------------------------------
// Optional multi-channel wrapper: NUM_CH independent silicaflux_nand_controller
// instances (one asynchronous NAND channel each) behind one request port and
// one completion port. Channels run concurrently; there is no shared state
// between them other than the request router and the completion merger.
//
//   request   req_ch selects the channel; req_ready is that channel's ready.
//             A request for a channel >= NUM_CH is accepted and answered with
//             a BAD_ADDR completion (cpl_ch = req_ch) without touching a channel.
//   completion round-robin merge of the channel completion queues (+ the
//             error slot); cpl_ch tells the source channel.
//   CSR       csr_addr[10:8] = channel, csr_addr[7:0] = channel CSR offset.
//   buffer    one SFB2 master port per channel (flattened), intended for one
//             DataFabric crossbar master port each.
//   pins      one complete NAND pin set per channel (flattened).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module silicaflux_nand_multichannel #(
  parameter int NUM_CH          = 2,
  parameter int DQ_WIDTH        = 8,
  parameter int NUM_CE          = 1,
  parameter int RB_SHARED       = 0,
  parameter int NUM_LUN_MAX     = 2,
  parameter int QUEUE_DEPTH     = 4,
  parameter int CPL_DEPTH       = 4,
  parameter int TAG_W           = 8,
  parameter int BUF_DW          = 32,
  parameter int CLK_PERIOD_PS   = 10000,
  parameter int DEF_LUNS        = 1,
  localparam int NUM_RB = (RB_SHARED != 0) ? 1 : NUM_CE,
  localparam int WB     = BUF_DW / 8,
  localparam int CHW    = (NUM_CH > 1) ? $clog2(NUM_CH) : 1
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  // requests
  input  wire logic                         req_valid,
  output logic                              req_ready,
  input  wire logic [2:0]                   req_ch,
  input  wire logic [3:0]                   req_op,
  input  wire logic [TAG_W-1:0]             req_tag,
  input  wire logic [2:0]                   req_ce,
  input  wire logic [2:0]                   req_lun,
  input  wire logic [23:0]                  req_block,
  input  wire logic [15:0]                  req_page,
  input  wire logic [15:0]                  req_col,
  input  wire logic [15:0]                  req_len,
  input  wire logic [31:0]                  req_buf,
  input  wire logic [7:0]                   req_faddr,
  input  wire logic [31:0]                  req_fdata,
  // completions
  output logic                              cpl_valid,
  input  wire logic                         cpl_ready,
  output logic [2:0]                        cpl_ch,
  output logic [TAG_W-1:0]                  cpl_tag,
  output logic [3:0]                        cpl_op,
  output logic [3:0]                        cpl_status,
  output logic [7:0]                        cpl_nand_status,
  output logic [2:0]                        cpl_ce,
  output logic [2:0]                        cpl_lun,
  output logic [31:0]                       cpl_info0,
  output logic [31:0]                       cpl_info1,
  output logic [31:0]                       cpl_latency,
  output logic [31:0]                       cpl_dev_time,
  // CSR
  input  wire logic                         csr_sel,
  input  wire logic                         csr_we,
  input  wire logic [10:0]                  csr_addr,
  input  wire logic [31:0]                  csr_wdata,
  output logic [31:0]                       csr_rdata,
  output logic                              csr_err,
  // SFB2 masters, one per channel
  output logic [NUM_CH-1:0]                 m_req_valid,
  input  wire logic [NUM_CH-1:0]            m_req_ready,
  output logic [NUM_CH-1:0]                 m_req_write,
  output logic [NUM_CH*32-1:0]              m_req_addr,
  output logic [NUM_CH*BUF_DW-1:0]          m_req_wdata,
  output logic [NUM_CH*WB-1:0]              m_req_wstrb,
  input  wire logic [NUM_CH-1:0]            m_rsp_valid,
  output logic [NUM_CH-1:0]                 m_rsp_ready,
  input  wire logic [NUM_CH*BUF_DW-1:0]     m_rsp_rdata,
  input  wire logic [NUM_CH-1:0]            m_rsp_error,
  // NAND pins, one set per channel
  output logic [NUM_CH*NUM_CE-1:0]          nand_ce_n,
  output logic [NUM_CH-1:0]                 nand_cle,
  output logic [NUM_CH-1:0]                 nand_ale,
  output logic [NUM_CH-1:0]                 nand_we_n,
  output logic [NUM_CH-1:0]                 nand_re_n,
  output logic [NUM_CH-1:0]                 nand_wp_n,
  output logic [NUM_CH*DQ_WIDTH-1:0]        nand_dq_o,
  output logic [NUM_CH-1:0]                 nand_dq_oe,
  input  wire logic [NUM_CH*DQ_WIDTH-1:0]   nand_dq_i,
  input  wire logic [NUM_CH*NUM_RB-1:0]     nand_rb_n,
  // status
  output logic                              irq,
  output logic                              busy
);
  localparam int CPLW = TAG_W + 4 + 4 + 8 + 3 + 3 + 32 * 4;

  logic [NUM_CH-1:0]      ch_req_ready, ch_cpl_valid, ch_cpl_ready, ch_irq, ch_busy, ch_csr_err;
  logic [CPLW-1:0]        ch_cpl [0:NUM_CH-1];
  logic [31:0]            ch_csr_rdata [0:NUM_CH-1];
  /* verilator lint_off UNUSEDSIGNAL */
  logic [2:0]             ch_tmode [0:NUM_CH-1];
  /* verilator lint_on UNUSEDSIGNAL */

  wire ch_ok = ({1'b0, req_ch} < 4'(NUM_CH));

  for (genvar c = 0; c < NUM_CH; c++) begin : g_ch
    logic [TAG_W-1:0] t_tag;
    logic [3:0]       t_op, t_st;
    logic [7:0]       t_nst;
    logic [2:0]       t_ce, t_lun;
    logic [31:0]      t_i0, t_i1, t_lat, t_dev;
    silicaflux_nand_controller #(
      .DQ_WIDTH(DQ_WIDTH), .NUM_CE(NUM_CE), .RB_SHARED(RB_SHARED), .NUM_LUN_MAX(NUM_LUN_MAX),
      .QUEUE_DEPTH(QUEUE_DEPTH), .CPL_DEPTH(CPL_DEPTH), .TAG_W(TAG_W), .BUF_DW(BUF_DW),
      .CLK_PERIOD_PS(CLK_PERIOD_PS), .DEF_LUNS(DEF_LUNS)
    ) u_ch (
      .clk(clk), .rst_n(rst_n),
      .req_valid(req_valid && ch_ok && req_ch[CHW-1:0] == CHW'(c)), .req_ready(ch_req_ready[c]),
      .req_op(req_op), .req_tag(req_tag), .req_ce(req_ce), .req_lun(req_lun), .req_block(req_block),
      .req_page(req_page), .req_col(req_col), .req_len(req_len), .req_buf(req_buf), .req_faddr(req_faddr),
      .req_fdata(req_fdata),
      .cpl_valid(ch_cpl_valid[c]), .cpl_ready(ch_cpl_ready[c]), .cpl_tag(t_tag), .cpl_op(t_op),
      .cpl_status(t_st), .cpl_nand_status(t_nst), .cpl_ce(t_ce), .cpl_lun(t_lun), .cpl_info0(t_i0),
      .cpl_info1(t_i1), .cpl_latency(t_lat), .cpl_dev_time(t_dev),
      .csr_sel(csr_sel && csr_addr[10:8] == 3'(c)), .csr_we(csr_we), .csr_addr(csr_addr[7:0]),
      .csr_wdata(csr_wdata), .csr_rdata(ch_csr_rdata[c]), .csr_err(ch_csr_err[c]),
      .m_req_valid(m_req_valid[c]), .m_req_ready(m_req_ready[c]), .m_req_write(m_req_write[c]),
      .m_req_addr(m_req_addr[c*32 +: 32]), .m_req_wdata(m_req_wdata[c*BUF_DW +: BUF_DW]),
      .m_req_wstrb(m_req_wstrb[c*WB +: WB]), .m_rsp_valid(m_rsp_valid[c]), .m_rsp_ready(m_rsp_ready[c]),
      .m_rsp_rdata(m_rsp_rdata[c*BUF_DW +: BUF_DW]), .m_rsp_error(m_rsp_error[c]),
      .nand_ce_n(nand_ce_n[c*NUM_CE +: NUM_CE]), .nand_cle(nand_cle[c]), .nand_ale(nand_ale[c]),
      .nand_we_n(nand_we_n[c]), .nand_re_n(nand_re_n[c]), .nand_wp_n(nand_wp_n[c]),
      .nand_dq_o(nand_dq_o[c*DQ_WIDTH +: DQ_WIDTH]), .nand_dq_oe(nand_dq_oe[c]),
      .nand_dq_i(nand_dq_i[c*DQ_WIDTH +: DQ_WIDTH]), .nand_rb_n(nand_rb_n[c*NUM_RB +: NUM_RB]),
      .irq(ch_irq[c]), .busy(ch_busy[c]), .timing_mode(ch_tmode[c]));
    assign ch_cpl[c] = {t_tag, t_op, t_st, t_nst, t_ce, t_lun, t_i0, t_i1, t_lat, t_dev};
  end

  // ------------------------------------------------------------ bad-channel error slot
  logic             e_v;
  logic [2:0]       e_ch;
  logic [TAG_W-1:0] e_tag;
  logic [3:0]       e_op;
  wire e_take = req_valid && !ch_ok && !e_v;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      e_v <= 1'b0; e_ch <= 3'd0; e_tag <= '0; e_op <= 4'd0;
    end else begin
      if (e_take) begin
        e_v <= 1'b1; e_ch <= req_ch; e_tag <= req_tag; e_op <= req_op;
      end else if (e_v && cpl_ready && sel_err) e_v <= 1'b0;
    end
  end
  assign req_ready = ch_ok ? ch_req_ready[req_ch[CHW-1:0]] : !e_v;

  // ------------------------------------------------------------ completion merge (round robin)
  logic [CHW:0] rr;                     // last served source (NUM_CH = error slot)
  logic         sel_err;
  logic [CHW:0] sel_src;
  logic         any_src;
  always_comb begin
    logic [CHW:0] k;
    any_src = 1'b0;
    sel_src = '0;
    for (int n = 1; n <= NUM_CH + 1; n++) begin
      k = (CHW+1)'((32'(rr) + 32'(n)) % 32'(NUM_CH + 1));
      if (!any_src) begin
        if (32'(k) == NUM_CH) begin
          if (e_v) begin any_src = 1'b1; sel_src = k; end
        end else if (ch_cpl_valid[k[CHW-1:0]]) begin
          any_src = 1'b1; sel_src = k;
        end
      end
    end
    sel_err = any_src && (32'(sel_src) == NUM_CH);
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rr <= (CHW+1)'(NUM_CH);
    else if (cpl_valid && cpl_ready) rr <= sel_src;
  end

  always_comb begin
    for (int c = 0; c < NUM_CH; c++) ch_cpl_ready[c] = cpl_ready && any_src && !sel_err && (sel_src[CHW-1:0] == CHW'(c));
  end
  assign cpl_valid = any_src;
  always_comb begin
    if (sel_err) begin
      {cpl_tag, cpl_op, cpl_status, cpl_nand_status, cpl_ce, cpl_lun, cpl_info0, cpl_info1, cpl_latency,
       cpl_dev_time} = {e_tag, e_op, silicaflux_nand_pkg::CS_BAD_ADDR, 8'd0, 3'd0, 3'd0, 32'd0, 32'd0, 32'd0, 32'd0};
      cpl_ch = e_ch;
    end else begin
      {cpl_tag, cpl_op, cpl_status, cpl_nand_status, cpl_ce, cpl_lun, cpl_info0, cpl_info1, cpl_latency,
       cpl_dev_time} = ch_cpl[sel_src[CHW-1:0]];
      cpl_ch = 3'(sel_src[CHW-1:0]);
    end
  end

  // ------------------------------------------------------------ CSR / status
  wire csr_ch_ok = ({1'b0, csr_addr[10:8]} < 4'(NUM_CH));
  assign csr_rdata = csr_ch_ok ? ch_csr_rdata[csr_addr[8 +: CHW]] : 32'd0;
  assign csr_err   = csr_sel && (csr_ch_ok ? ch_csr_err[csr_addr[8 +: CHW]] : 1'b1);
  assign irq       = |ch_irq;
  assign busy      = (|ch_busy) || e_v;
endmodule

`default_nettype wire
