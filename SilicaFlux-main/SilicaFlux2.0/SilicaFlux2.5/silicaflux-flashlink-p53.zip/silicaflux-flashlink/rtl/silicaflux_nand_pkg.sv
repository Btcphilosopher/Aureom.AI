// =============================================================================
// silicaflux_nand_pkg.sv -- SilicaFlux FlashLink, Project 53 (Aureom.AI | SilicaFlux-STORE)
// -----------------------------------------------------------------------------
// Command / state package of the NAND channel controller.
//
//   * Abstract operations accepted on the request interface (OP_*).
//   * The ONFI-style asynchronous (SDR) command opcodes the controller emits
//     (CMD_*). Only this subset is implemented; no ONFI compliance is claimed.
//   * Status-register bit positions (SR_*), completion status codes (CS_*),
//     micro-operation kinds between the sequencer and the timing engine (U_*),
//     request-slot states (SL_*), bus-sequencer states (B_*) and the CSR map.
//
// Coding subset (shared with the rest of SilicaFlux): referenced as
// silicaflux_nand_pkg::NAME (no `import` in synthesizable RTL), no structs,
// no casts other than size casts, functions assign their result to their name.
// Classification: SYNTHESIZABLE (constants and pure functions only)
// =============================================================================
`ifndef SILICAFLUX_NAND_PKG_SV
`define SILICAFLUX_NAND_PKG_SV

// Constants are kept for completeness / documentation even where the RTL does not use them.
/* verilator lint_off UNUSEDPARAM */
package silicaflux_nand_pkg;

  // ---------------------------------------------------------------- identity
  localparam logic [31:0] SFNC_MAGIC   = 32'h5346_3533;  // "SF53"
  localparam logic [15:0] SFNC_VERSION = 16'h0100;       // v1.0

  // ------------------------------------------------- abstract operations
  localparam logic [3:0] OP_RESET        = 4'h0;  // FFh, wait ready, 70h
  localparam logic [3:0] OP_READ_ID      = 4'h1;  // 90h addr, N bytes
  localparam logic [3:0] OP_READ_PARAM   = 4'h2;  // ECh 00h, wait ready, 256 B x up to 3 copies
  localparam logic [3:0] OP_READ_STATUS  = 4'h3;  // 70h (or 78h row) 1 byte
  localparam logic [3:0] OP_READ_PAGE    = 4'h4;  // 00h col row 30h, wait, 70h/78h, 05h col E0h, tCCS, data out
  localparam logic [3:0] OP_PROGRAM_PAGE = 4'h5;  // 80h col row data 10h, wait, status
  localparam logic [3:0] OP_ERASE_BLOCK  = 4'h6;  // 60h row D0h, wait, status
  localparam logic [3:0] OP_SET_FEATURES = 4'h7;  // EFh fa P1..P4, wait
  localparam logic [3:0] OP_GET_FEATURES = 4'h8;  // EEh fa, wait, P1..P4
  localparam logic [3:0] OP_LAST         = 4'h8;

  // ------------------------------------------- NAND command opcodes (subset)
  localparam logic [7:0] CMD_READ_1     = 8'h00;
  localparam logic [7:0] CMD_READ_2     = 8'h30;
  localparam logic [7:0] CMD_CRCOL_1    = 8'h05;  // CHANGE READ COLUMN
  localparam logic [7:0] CMD_CRCOL_2    = 8'hE0;
  localparam logic [7:0] CMD_PROG_1     = 8'h80;
  localparam logic [7:0] CMD_PROG_2     = 8'h10;
  localparam logic [7:0] CMD_ERASE_1    = 8'h60;
  localparam logic [7:0] CMD_ERASE_2    = 8'hD0;
  localparam logic [7:0] CMD_STATUS     = 8'h70;
  localparam logic [7:0] CMD_STATUS_ENH = 8'h78;
  localparam logic [7:0] CMD_READ_ID    = 8'h90;
  localparam logic [7:0] CMD_READ_PARAM = 8'hEC;
  localparam logic [7:0] CMD_GET_FEAT   = 8'hEE;
  localparam logic [7:0] CMD_SET_FEAT   = 8'hEF;
  localparam logic [7:0] CMD_RESET      = 8'hFF;

  // feature addresses the controller interprets
  localparam logic [7:0] FA_TIMING_MODE = 8'h01;

  // ------------------------------------------------- status register bits
  localparam int SR_FAIL  = 0;
  localparam int SR_FAILC = 1;
  localparam int SR_ARDY  = 5;
  localparam int SR_RDY   = 6;
  localparam int SR_WP_N  = 7;

  // ------------------------------------------------ completion status codes
  localparam logic [3:0] CS_OK          = 4'h0;  // success
  localparam logic [3:0] CS_DEV_FAIL    = 4'h1;  // device status FAIL bit after program / erase
  localparam logic [3:0] CS_TIMEOUT     = 4'h2;  // ready not seen within the op-class timeout
  localparam logic [3:0] CS_BAD_OP      = 4'h3;  // unknown operation code
  localparam logic [3:0] CS_BAD_ADDR    = 4'h4;  // CE / LUN / block / page / column / length outside geometry
  localparam logic [3:0] CS_ALIGN       = 4'h5;  // buffer address or x16 column/length alignment
  localparam logic [3:0] CS_WP          = 4'h6;  // program / erase refused: WP# asserted
  localparam logic [3:0] CS_NOT_RESET   = 4'h7;  // target needs RESET (power-on or after a timeout)
  localparam logic [3:0] CS_PROG_ORDER  = 4'h8;  // out-of-order first program inside the tracked block
  localparam logic [3:0] CS_BUF_ERR     = 4'h9;  // buffer (SFB2) error during the data phase
  localparam logic [3:0] CS_PARAM_CRC   = 4'hA;  // no parameter-page copy with signature + valid CRC
  localparam logic [3:0] CS_UNSUPPORTED = 4'hB;  // geometry / timing mode outside what the controller supports
  localparam logic [3:0] CS_NOT_READY   = 4'hC;  // RESET completed but the status byte did not show RDY

  // --------------------------------------------- micro-operation kinds
  localparam logic [2:0] U_CMD   = 3'd0;  // one command latch cycle (CLE)
  localparam logic [2:0] U_ADDR  = 3'd1;  // 1..5 address latch cycles (ALE), bytes LSB first
  localparam logic [2:0] U_DIN   = 3'd2;  // data-input cycles (stream or immediate bytes)
  localparam logic [2:0] U_DOUT  = 3'd3;  // data-output cycles (RE#), captured units to dout
  localparam logic [2:0] U_DELAY = 3'd4;  // idle cycles
  localparam logic [2:0] U_CESEL = 3'd5;  // select one CE# (deselect another first)
  localparam logic [2:0] U_CEOFF = 3'd6;  // deselect every CE#

  // --------------------------------------------------- request-slot states
  localparam logic [1:0] SL_FREE = 2'd0;
  localparam logic [1:0] SL_PEND = 2'd1;  // accepted, not yet on the bus
  localparam logic [1:0] SL_WAIT = 2'd2;  // array / target busy, waiting for ready

  // ------------------------------------------------- bus-sequencer states
  localparam logic [4:0] B_IDLE      = 5'd0;
  localparam logic [4:0] B_CESEL     = 5'd1;
  localparam logic [4:0] B_CMD1      = 5'd2;
  localparam logic [4:0] B_ADDR      = 5'd3;
  localparam logic [4:0] B_DIN_BUF   = 5'd4;
  localparam logic [4:0] B_DIN_IMM   = 5'd5;
  localparam logic [4:0] B_CMD2      = 5'd6;
  localparam logic [4:0] B_WB        = 5'd7;
  localparam logic [4:0] B_DOUT_ID   = 5'd8;
  localparam logic [4:0] B_ST_CMD    = 5'd9;
  localparam logic [4:0] B_ST_ADDR   = 5'd10;
  localparam logic [4:0] B_ST_RD     = 5'd11;
  localparam logic [4:0] B_RESUME    = 5'd12;  // 05h (CHANGE READ COLUMN) after the ready status
  localparam logic [4:0] B_DOUT_DATA = 5'd13;
  localparam logic [4:0] B_RR        = 5'd14;
  localparam logic [4:0] B_DOUT_PRM  = 5'd15;
  localparam logic [4:0] B_DOUT_FEAT = 5'd16;
  localparam logic [4:0] B_CEOFF     = 5'd17;
  localparam logic [4:0] B_WDRAIN    = 5'd18;
  localparam logic [4:0] B_FIN       = 5'd19;
  localparam logic [4:0] B_CHECK     = 5'd20;
  localparam logic [4:0] B_CRC_ADDR  = 5'd21;  // column cycles of CHANGE READ COLUMN
  localparam logic [4:0] B_CRC2      = 5'd22;  // E0h
  localparam logic [4:0] B_CCS       = 5'd23;  // tCCS
  localparam logic [4:0] B_CHECK2    = 5'd24;  // act on the registered validation flags

  // bus-job kinds
  localparam logic [2:0] J_ISSUE = 3'd0;  // command / address / data-in phase
  localparam logic [2:0] J_COMP  = 3'd1;  // ready check + status / data-out phase
  localparam logic [2:0] J_ERR   = 3'd2;  // completes with an error, no bus traffic
  localparam logic [2:0] J_TMO   = 3'd3;  // timeout, no bus traffic

  // -------------------------------------------- CSR map (byte offsets)
  localparam logic [7:0] CSR_ID         = 8'h00;  // RO "SF53"
  localparam logic [7:0] CSR_VERSION    = 8'h04;  // RO {version, DQ_WIDTH, NUM_CE}
  localparam logic [7:0] CSR_CONFIG     = 8'h08;  // RO {QUEUE_DEPTH, NUM_LUN_MAX, TAG_W, BUF_DW/8}
  localparam logic [7:0] CSR_CTRL       = 8'h0C;  // RW control bits (CTRL_*)
  localparam logic [7:0] CSR_STATUS     = 8'h10;  // RO live status
  localparam logic [7:0] CSR_TMODE      = 8'h14;  // RW timing mode (write loads TIM0..3 from the table)
  localparam logic [7:0] CSR_TIM0       = 8'h18;  // RW {reh, rp, wh, wp}
  localparam logic [7:0] CSR_TIM1       = 8'h1C;  // RW {rhw, adl, whr, su}
  localparam logic [7:0] CSR_TIM2       = 8'h20;  // RW {rr, ww, ch, cs}
  localparam logic [7:0] CSR_TIM3       = 8'h24;  // RW {-, -, -, wb}
  localparam logic [7:0] CSR_GEO0       = 8'h28;  // RW {oob bytes, page bytes}
  localparam logic [7:0] CSR_GEO1       = 8'h2C;  // RW pages per block
  localparam logic [7:0] CSR_GEO2       = 8'h30;  // RW blocks per LUN
  localparam logic [7:0] CSR_GEO3       = 8'h34;  // RW {timing-mode mask, addr cycles, LUNs}
  localparam logic [7:0] CSR_GEO4       = 8'h38;  // RO {tCCS ns, tR max us} (parameter page)
  localparam logic [7:0] CSR_GEO5       = 8'h3C;  // RO {tBERS max us, tPROG max us}
  localparam logic [7:0] CSR_TMO_RD     = 8'h40;  // RW read timeout (cycles)
  localparam logic [7:0] CSR_TMO_PG     = 8'h44;  // RW program timeout
  localparam logic [7:0] CSR_TMO_ER     = 8'h48;  // RW erase timeout
  localparam logic [7:0] CSR_TMO_TGT    = 8'h4C;  // RW reset / parameter / feature timeout
  localparam logic [7:0] CSR_POLL_RD    = 8'h50;  // RW first status poll after a read (cycles)
  localparam logic [7:0] CSR_POLL_PG    = 8'h54;  // RW first poll after a program
  localparam logic [7:0] CSR_POLL_ER    = 8'h58;  // RW first poll after an erase
  localparam logic [7:0] CSR_POLL_IV    = 8'h5C;  // RW poll interval after a not-ready poll
  localparam logic [7:0] CSR_PERF_CTRL  = 8'h60;  // W bit0: clear counters
  localparam logic [7:0] CSR_PERF_BASE  = 8'h64;  // RO counters, PC_* index * 4
  localparam logic [7:0] CSR_ERR        = 8'hC0;  // RW1C sticky error flags (ERR_*)
  localparam logic [7:0] CSR_TGT        = 8'hC4;
  localparam logic [7:0] CSR_GEO6       = 8'hC8;  // RO {optional commands, features} (parameter page bytes 8-9, 6-7)  // RO {faulted[7:0], tgt_busy[7:0], reset_done[7:0], rb_ready[7:0]}

  // CTRL bits
  localparam int CTRL_EN         = 0;   // scheduler enabled
  localparam int CTRL_WP_N       = 1;   // WP# pin level (1 = writes allowed)
  localparam int CTRL_INTERLEAVE = 2;   // allow several busy LUNs / targets (else strictly in order)
  localparam int CTRL_RD_PRIO    = 3;   // read-priority arbitration (else oldest first)
  localparam int CTRL_USE_ENH    = 4;   // use READ STATUS ENHANCED (78h) per LUN
  localparam int CTRL_MULTI_LUN  = 5;   // device allows concurrent operations on several LUNs
  localparam int CTRL_AUTO_GEO   = 6;   // load geometry from a valid parameter page
  localparam int CTRL_AUTO_TIM   = 7;   // SET FEATURES 01h also switches the controller timing mode
  localparam int CTRL_AUTO_TMO   = 8;   // derive timeouts from parameter-page tR / tPROG / tBERS
  localparam int CTRL_ORDER_CHK  = 9;   // per-LUN sequential-program check
  localparam int CTRL_POLL_EN    = 10;  // status polling (else R/B# only)
  localparam int CTRL_IRQ_EN     = 11;  // irq = completion available
  localparam int CTRL_TMO_EN     = 12;  // timeouts enabled
  localparam int CTRL_STARVE_LSB = 16;  // [19:16] read-priority starvation limit

  // performance counters (index; CSR address = CSR_PERF_BASE + 4*index)
  localparam int PC_CYCLES      = 0;
  localparam int PC_BUS_BUSY    = 1;   // bus sequencer owns the channel
  localparam int PC_BUS_DATA    = 2;   // data-in / data-out beats in progress
  localparam int PC_ARRAY_BUSY  = 3;   // at least one LUN / target busy
  localparam int PC_BYTES_RD    = 4;   // page / parameter bytes read from NAND
  localparam int PC_BYTES_WR    = 5;   // page bytes written to NAND
  localparam int PC_N_READ      = 6;
  localparam int PC_N_PROG      = 7;
  localparam int PC_N_ERASE     = 8;
  localparam int PC_N_OTHER     = 9;
  localparam int PC_LAT_RD_SUM  = 10;  // accept -> completion, cycles
  localparam int PC_LAT_RD_MAX  = 11;
  localparam int PC_LAT_PG_SUM  = 12;
  localparam int PC_LAT_PG_MAX  = 13;
  localparam int PC_LAT_ER_SUM  = 14;
  localparam int PC_LAT_ER_MAX  = 15;
  localparam int PC_Q_STALL     = 16;  // req_valid && !req_ready
  localparam int PC_CPL_STALL   = 17;  // completion queue full while a completion waits
  localparam int PC_N_TMO       = 18;
  localparam int PC_N_ERR       = 19;  // completions with status != OK
  localparam int PC_N_POLL      = 20;  // status polls issued
  localparam int PC_N_POLL_MISS = 21;  // polls that found the LUN still busy
  localparam int PC_BUS_IDLE    = 22;  // bus sequencer idle
  localparam int PC_NUM         = 23;

  // sticky error flags
  localparam int ERR_TIMEOUT  = 0;
  localparam int ERR_DEV_FAIL = 1;
  localparam int ERR_BUF      = 2;
  localparam int ERR_PARAM    = 3;
  localparam int ERR_REJECT   = 4;  // request refused by validation

  // ------------------------------------------------------------ functions
  // ONFI CRC-16 (polynomial 8005h, MSB first) of one byte
  function automatic logic [15:0] crc16_byte(input logic [15:0] crc, input logic [7:0] b);
    logic [15:0] c;
    logic        fb;
    c = crc;
    for (int i = 7; i >= 0; i--) begin
      fb = c[15] ^ b[i];
      c  = {c[14:0], 1'b0};
      if (fb) c = c ^ 16'h8005;
    end
    crc16_byte = c;
  endfunction

  // ceil(log2(v)) for a run-time value (0 and 1 -> 0), shallow logic without a subtractor:
  //   t[k] = (v > 2^k), a monotone thermometer code (t[0] >= t[1] >= ...), whose number of ones is
  //   ceil(log2(v)); bit i of that count is set iff some t[2^(i+1)m + 2^i - 1] & ~t[2^(i+1)m + 2^(i+1) - 1].
  function automatic logic [4:0] clog2_rt(input logic [23:0] v);
    logic [31:0] t;
    logic        hi, lo;
    logic [4:0]  n;
    t = 32'd0;
    for (int k = 0; k < 24; k++) begin
      hi = 1'b0;
      lo = 1'b0;
      for (int j = k + 1; j < 24; j++) hi = hi | v[j];
      for (int j = 0; j < k; j++)      lo = lo | v[j];
      t[k] = hi | (v[k] & lo);
    end
    n = 5'd0;
    for (int i = 0; i < 5; i++)
      for (int m = 0; m < 32; m++)
        if (((m << (i + 1)) + (1 << (i + 1)) - 1) < 32)
          if (t[(m << (i + 1)) + (1 << i) - 1] && !t[(m << (i + 1)) + (1 << (i + 1)) - 1]) n[i] = 1'b1;
    clog2_rt = n;
  endfunction

  // operation classes
  function automatic logic op_is_tgt(input logic [3:0] op);   // target-level: all LUNs idle
    op_is_tgt = (op == OP_RESET) || (op == OP_READ_ID) || (op == OP_READ_PARAM) ||
                (op == OP_SET_FEATURES) || (op == OP_GET_FEATURES);
  endfunction

  function automatic logic op_is_array(input logic [3:0] op);  // LUN array operation (busy period)
    op_is_array = (op == OP_READ_PAGE) || (op == OP_PROGRAM_PAGE) || (op == OP_ERASE_BLOCK);
  endfunction

endpackage
/* verilator lint_on UNUSEDPARAM */

`endif
