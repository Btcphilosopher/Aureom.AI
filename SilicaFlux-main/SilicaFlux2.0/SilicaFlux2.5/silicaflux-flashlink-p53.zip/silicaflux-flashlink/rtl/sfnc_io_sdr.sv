// =============================================================================
// sfnc_io_sdr.sv -- SilicaFlux FlashLink, Project 53
// -----------------------------------------------------------------------------
// Physical NAND I/O boundary (asynchronous SDR interface).
//
// The controller (silicaflux_nand_controller) exposes a split, registered pin
// interface: ce_n[], cle, ale, we_n, re_n, wp_n, dq_o/dq_oe/dq_i, rb_n[].
// This module is where those signals meet I/O cells. It is NOT part of the
// synthesizable controller and contains no timing logic.
//
//   TECH = "SIM"  behavioural tri-state DQ and straight-through control pins,
//                 for simulation only (same convention as the Project 37 I/O
//                 shell: the behavioural layer is not a pad). Compiling with
//                 SFNC_ASIC_IMPL stops elaboration.
//   any other     stops elaboration: no qualified NAND I/O cells (drive
//                 strength, slew, input thresholds, ESD, on-die termination)
//                 exist in this repository. A technology branch must
//                 instantiate the PDK's characterised bidirectional and output
//                 pads behind this same port list, and the board must provide
//                 the R/B# pull-up (open-drain line).
//
// What a real implementation still needs (not claimed here): pad selection
// and drive strength from board-level signal-integrity analysis, output and
// input delay constraints so that rp*Tclk >= t_out + tREA + t_in + t_setup
// (see docs/03_TIMING.md), and I/O-cell placement of the output/capture flops.
// Modern NV-DDR / NV-DDR2/3 / Toggle interfaces need a DQS-based PHY with
// calibration; that PHY is out of scope and is not modelled here.
// Classification: SIMULATION MODEL (TECH = "SIM") / boundary placeholder
// =============================================================================
`default_nettype none

module sfnc_io_sdr #(
  parameter int    DQW    = 8,
  parameter int    NUM_CE = 1,
  parameter int    NUM_RB = 1,
  parameter string TECH   = "SIM"
) (
  // controller side
  input  wire logic [NUM_CE-1:0] c_ce_n,
  input  wire logic              c_cle,
  input  wire logic              c_ale,
  input  wire logic              c_we_n,
  input  wire logic              c_re_n,
  input  wire logic              c_wp_n,
  input  wire logic [DQW-1:0]    c_dq_o,
  input  wire logic              c_dq_oe,
  output logic [DQW-1:0]         c_dq_i,
  output logic [NUM_RB-1:0]      c_rb_n,
  // pad side
  output logic [NUM_CE-1:0]      pad_ce_n,
  output logic                   pad_cle,
  output logic                   pad_ale,
  output logic                   pad_we_n,
  output logic                   pad_re_n,
  output logic                   pad_wp_n,
  inout  wire  [DQW-1:0]         pad_dq,
  input  wire logic [NUM_RB-1:0] pad_rb_n
);
  if (TECH == "SIM") begin : g_sim
`ifdef SFNC_ASIC_IMPL
    $error("sfnc_io_sdr: the behavioural I/O layer is SIMULATION ONLY and cannot be implemented");
`endif
    assign pad_ce_n = c_ce_n;
    assign pad_cle  = c_cle;
    assign pad_ale  = c_ale;
    assign pad_we_n = c_we_n;
    assign pad_re_n = c_re_n;
    assign pad_wp_n = c_wp_n;
    assign pad_dq   = c_dq_oe ? c_dq_o : {DQW{1'bz}};
    assign c_dq_i   = pad_dq;
    assign c_rb_n   = pad_rb_n;
  end else begin : g_tech
    $error("sfnc_io_sdr: no qualified NAND I/O cells for this technology; provide a PDK pad wrapper");
  end
endmodule

`default_nettype wire
