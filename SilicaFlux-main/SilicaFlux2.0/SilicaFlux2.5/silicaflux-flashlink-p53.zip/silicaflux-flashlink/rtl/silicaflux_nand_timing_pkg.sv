// =============================================================================
// silicaflux_nand_timing_pkg.sv -- SilicaFlux FlashLink, Project 53
// -----------------------------------------------------------------------------
// Timing configuration of the asynchronous (SDR) NAND interface.
//
// 1. onfi_ns(mode, param): minimum (or, for tREA/tWB/tRHZ/tCEA, maximum)
//    values in ns of the ONFI-style asynchronous timing modes 0..5.
//    PROVENANCE: transcribed from the ONFI asynchronous timing table as also
//    used by the SilicaFlux NANDLab model (Project 52, nand_flash_model.sv,
//    set_timing_tables). Where the two transcriptions differ, the larger
//    (more conservative) value is used (tWHR modes 3..5 = 80 ns). These numbers
//    MUST be checked against the ONFI revision and the datasheet of the part
//    actually used; later ONFI revisions and many datasheets specify other
//    values (for example a larger tADL). The table is a starting point, not a
//    compliance statement. All values can be overridden at run time (TIM0..3).
//
// 2. mode_word(mode, clk_ps, capture_ps, sync_stages): converts one mode into
//    the controller's cycle counts (packed exactly like CSR TIM0..TIM3) using
//    the rules documented in docs/03_TIMING.md:
//      wp  = ceil(tWP)                       WE# low
//      su  = ceil(max(tCLS,tALS,tDS)) - wp   CLE/ALE/DQ before WE# falls (>= 0)
//      wh  = max(tWH, tCLH, tALH, tDH, tWC - wp - su)
//      rp  = max(tRP, tREA + capture margin)  RE# low; DQ sampled at its end
//      reh = max(tREH, tRC - rp)
//      whr = max(tWHR, wh + max(tCLR, tAR))   WE# rise -> RE# fall
//      adl = tADL                              address WE# rise -> data cycle
//      rhw = max(tRHW, tRHZ)                   RE# rise -> DQ driven / WE# fall
//      cs  = max(tCS, tCEA)                    CE# fall -> first strobe
//      ch  = tCH                               last strobe -> CE# rise
//      ww  = tWW                               WP# change -> WE# fall
//      wb  = tWB + sync_stages + 2             confirm -> trust R/B# / status
//      rr  = tRR                               ready -> RE# fall
//    Every count is ceil(t * 1000 / clk_ps), saturated to 1..255 (su and the
//    rule-derived terms may be 0). Evaluated only at elaboration time.
// Classification: SYNTHESIZABLE (constant functions)
// =============================================================================
`ifndef SILICAFLUX_NAND_TIMING_PKG_SV
`define SILICAFLUX_NAND_TIMING_PKG_SV

// Constants are kept for completeness / documentation even where the RTL does not use them.
/* verilator lint_off UNUSEDPARAM */
package silicaflux_nand_timing_pkg;

  localparam int NUM_MODES = 6;

  // parameter identifiers
  localparam int P_WP  = 0;   localparam int P_WH  = 1;   localparam int P_WC  = 2;
  localparam int P_RP  = 3;   localparam int P_REH = 4;   localparam int P_RC  = 5;
  localparam int P_REA = 6;   localparam int P_CLS = 7;   localparam int P_ALS = 8;
  localparam int P_DS  = 9;   localparam int P_CLH = 10;  localparam int P_ALH = 11;
  localparam int P_DH  = 12;  localparam int P_CS  = 13;  localparam int P_CH  = 14;
  localparam int P_WHR = 15;  localparam int P_ADL = 16;  localparam int P_RHW = 17;
  localparam int P_RR  = 18;  localparam int P_WB  = 19;  localparam int P_WW  = 20;
  localparam int P_CLR = 21;  localparam int P_AR  = 22;  localparam int P_RHZ = 23;
  localparam int P_CEA = 24;

  // field positions inside the 128-bit timing word {TIM3, TIM2, TIM1, TIM0}
  localparam int F_WP  = 0;   localparam int F_WH  = 8;   localparam int F_RP  = 16;
  localparam int F_REH = 24;  localparam int F_SU  = 32;  localparam int F_WHR = 40;
  localparam int F_ADL = 48;  localparam int F_RHW = 56;  localparam int F_CS  = 64;
  localparam int F_CH  = 72;  localparam int F_WW  = 80;  localparam int F_RR  = 88;
  localparam int F_WB  = 96;

  // six values (modes 0..5) per parameter, in ns
  function automatic integer pick6(input integer mode, input integer v0, input integer v1, input integer v2,
                                   input integer v3, input integer v4, input integer v5);
    case (mode)
      0:       pick6 = v0;
      1:       pick6 = v1;
      2:       pick6 = v2;
      3:       pick6 = v3;
      4:       pick6 = v4;
      default: pick6 = v5;
    endcase
  endfunction

  function automatic integer onfi_ns(input integer mode, input integer p);
    case (p)
      P_WP:    onfi_ns = pick6(mode,  50,  25,  17,  15,  12,  10);
      P_WH:    onfi_ns = pick6(mode,  30,  15,  15,  10,  10,   7);
      P_WC:    onfi_ns = pick6(mode, 100,  45,  35,  30,  25,  20);
      P_RP:    onfi_ns = pick6(mode,  50,  25,  17,  15,  12,  10);
      P_REH:   onfi_ns = pick6(mode,  30,  15,  15,  10,  10,   7);
      P_RC:    onfi_ns = pick6(mode, 100,  50,  35,  30,  25,  20);
      P_REA:   onfi_ns = pick6(mode,  40,  30,  25,  20,  20,  16);   // max
      P_CLS:   onfi_ns = pick6(mode,  50,  25,  15,  10,  10,  10);
      P_ALS:   onfi_ns = pick6(mode,  50,  25,  15,  10,  10,  10);
      P_DS:    onfi_ns = pick6(mode,  40,  20,  15,  10,  10,   7);
      P_CLH:   onfi_ns = pick6(mode,  20,  10,  10,   5,   5,   5);
      P_ALH:   onfi_ns = pick6(mode,  20,  10,  10,   5,   5,   5);
      P_DH:    onfi_ns = pick6(mode,  20,  10,   5,   5,   5,   5);
      P_CS:    onfi_ns = pick6(mode,  70,  35,  25,  25,  20,  15);
      P_CH:    onfi_ns = pick6(mode,  20,  10,  10,   5,   5,   5);
      P_WHR:   onfi_ns = pick6(mode, 120,  80,  80,  80,  80,  80);
      P_ADL:   onfi_ns = pick6(mode, 200, 100, 100, 100,  70,  70);
      P_RHW:   onfi_ns = pick6(mode, 200, 100, 100, 100, 100, 100);
      P_RR:    onfi_ns = pick6(mode,  40,  20,  20,  20,  20,  20);
      P_WB:    onfi_ns = pick6(mode, 200, 100, 100, 100, 100, 100);   // max
      P_WW:    onfi_ns = pick6(mode, 100, 100, 100, 100, 100, 100);
      P_CLR:   onfi_ns = pick6(mode,  20,  10,  10,  10,  10,  10);
      P_AR:    onfi_ns = pick6(mode,  25,  10,  10,  10,  10,  10);
      P_RHZ:   onfi_ns = pick6(mode, 200, 100, 100, 100, 100, 100);   // max
      P_CEA:   onfi_ns = pick6(mode, 100,  45,  30,  25,  25,  25);   // max
      default: onfi_ns = 0;
    endcase
  endfunction

  // ceil(ps / clk_ps)
  function automatic integer ps2cyc(input integer ps, input integer clk_ps);
    ps2cyc = (ps + clk_ps - 1) / clk_ps;
  endfunction

  function automatic integer ns2cyc(input integer ns, input integer clk_ps);
    ns2cyc = ps2cyc(ns * 1000, clk_ps);
  endfunction

  function automatic integer imax(input integer a, input integer b);
    imax = (a > b) ? a : b;
  endfunction

  function automatic logic [7:0] sat8(input integer v, input integer lo);
    integer t;
    t = v;
    if (t < lo) t = lo;
    if (t > 255) t = 255;
    sat8 = t[7:0];
  endfunction

  function automatic logic [127:0] mode_word(input integer mode, input integer clk_ps,
                                             input integer capture_ps, input integer sync_stages);
    integer wp, su, wh, rp, reh, whr, adl, rhw, cs, ch, ww, wb, rr, setup;
    logic [127:0] w;
    wp    = imax(1, ns2cyc(onfi_ns(mode, P_WP), clk_ps));
    setup = imax(onfi_ns(mode, P_CLS), imax(onfi_ns(mode, P_ALS), onfi_ns(mode, P_DS)));
    su    = imax(0, ns2cyc(setup, clk_ps) - wp);
    wh    = imax(1, ns2cyc(onfi_ns(mode, P_WH), clk_ps));
    wh    = imax(wh, ns2cyc(onfi_ns(mode, P_CLH), clk_ps));
    wh    = imax(wh, ns2cyc(onfi_ns(mode, P_ALH), clk_ps));
    wh    = imax(wh, ns2cyc(onfi_ns(mode, P_DH), clk_ps));
    wh    = imax(wh, ns2cyc(onfi_ns(mode, P_WC), clk_ps) - wp - su);
    rp    = imax(1, ns2cyc(onfi_ns(mode, P_RP), clk_ps));
    rp    = imax(rp, ps2cyc(onfi_ns(mode, P_REA) * 1000 + capture_ps, clk_ps));
    reh   = imax(1, ns2cyc(onfi_ns(mode, P_REH), clk_ps));
    reh   = imax(reh, ns2cyc(onfi_ns(mode, P_RC), clk_ps) - rp);
    whr   = imax(ns2cyc(onfi_ns(mode, P_WHR), clk_ps),
                 wh + ns2cyc(imax(onfi_ns(mode, P_CLR), onfi_ns(mode, P_AR)), clk_ps));
    adl   = ns2cyc(onfi_ns(mode, P_ADL), clk_ps);
    rhw   = imax(ns2cyc(onfi_ns(mode, P_RHW), clk_ps), ns2cyc(onfi_ns(mode, P_RHZ), clk_ps));
    cs    = imax(ns2cyc(onfi_ns(mode, P_CS), clk_ps), ns2cyc(onfi_ns(mode, P_CEA), clk_ps));
    ch    = imax(1, ns2cyc(onfi_ns(mode, P_CH), clk_ps));
    ww    = ns2cyc(onfi_ns(mode, P_WW), clk_ps);
    wb    = ns2cyc(onfi_ns(mode, P_WB), clk_ps) + sync_stages + 2;
    rr    = ns2cyc(onfi_ns(mode, P_RR), clk_ps);
    w = 128'd0;
    w[F_WP  +: 8] = sat8(wp, 1);
    w[F_WH  +: 8] = sat8(wh, 1);
    w[F_RP  +: 8] = sat8(rp, 1);
    w[F_REH +: 8] = sat8(reh, 1);
    w[F_SU  +: 8] = sat8(su, 0);
    w[F_WHR +: 8] = sat8(whr, 1);
    w[F_ADL +: 8] = sat8(adl, 1);
    w[F_RHW +: 8] = sat8(rhw, 1);
    w[F_CS  +: 8] = sat8(cs, 1);
    w[F_CH  +: 8] = sat8(ch, 1);
    w[F_WW  +: 8] = sat8(ww, 1);
    w[F_RR  +: 8] = sat8(rr, 1);
    w[F_WB  +: 8] = sat8(wb, 1);
    mode_word = w;
  endfunction

endpackage
/* verilator lint_on UNUSEDPARAM */

`endif
