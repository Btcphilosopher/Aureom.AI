// =============================================================================
// silicaflux_nand_controller.sv -- SilicaFlux FlashLink, Project 53
//                                  (Aureom.AI | SilicaFlux-STORE)
// -----------------------------------------------------------------------------
// NAND flash CHANNEL controller: one asynchronous (SDR) NAND channel with
// NUM_CE targets (chip enables), each with up to NUM_LUN_MAX LUNs.
//
//   request interface  abstract operations (silicaflux_nand_pkg::OP_*):
//                      RESET, READ_ID, READ_PARAM, READ_STATUS, READ_PAGE,
//                      PROGRAM_PAGE, ERASE_BLOCK, SET_FEATURES, GET_FEATURES
//   completion queue   {tag, op, status, NAND status byte, info0/1, latency,
//                      device-busy time}
//   buffer port        SFB2 master (DataFabric) to the page buffer SRAM
//   CSR port           configuration, timing, geometry, timeouts, counters
//   pin interface      registered ce_n[], cle, ale, we_n, re_n, wp_n,
//                      dq_o/dq_oe/dq_i (split for the pad), rb_n[] (async)
//
// Layers (docs/01_ARCHITECTURE.md):
//   digital command / controller logic   this module: request slots, address
//       and geometry validation, scheduler (per-LUN ordering, LUN / target
//       busy rules, optional interleaving, read/program arbitration), command
//       / address sequencer, status interpretation, ready/busy management
//       (R/B# + READ STATUS / READ STATUS ENHANCED polling), timeouts,
//       parameter-page parser (ONFI CRC-16, 3 redundant copies), error
//       reporting and performance counters;
//   timing / interface adaptation        sfnc_timing_engine (cycle counts);
//   data transfer (buffer side)          sfnc_buf_master (SFB2);
//   physical NAND I/O                    sfnc_io_sdr, outside this module.
//
// Only an ONFI-style command subset is implemented (see silicaflux_nand_pkg).
// No ONFI compliance is claimed. No NV-DDR / Toggle / cache / multi-plane /
// copyback / ECC. Verified against the SilicaFlux NANDLab model (Project 52).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module silicaflux_nand_controller #(
  parameter int DQ_WIDTH            = 8,       // 8 or 16
  parameter int NUM_CE              = 1,       // targets on this channel, 1..8
  parameter int RB_SHARED           = 0,       // 1: one wired-AND R/B# line for all targets
  parameter int NUM_LUN_MAX         = 2,       // LUNs per target the tables can track, 1..8
  parameter int QUEUE_DEPTH         = 4,       // outstanding requests (slots), 2..16
  parameter int CPL_DEPTH           = 4,       // completion queue entries (power of two)
  parameter int TAG_W               = 8,
  parameter int BUF_DW              = 32,      // SFB2 data width: 32 or 64
  parameter int CLK_PERIOD_PS       = 10000,   // controller clock period (timing conversion)
  parameter int CAPTURE_MARGIN_PS   = 2000,    // RE# low beyond tREA (pad + board + setup)
  parameter int TIMING_MODE_RST     = 0,       // timing mode after reset (devices power up in 0)
  parameter int PAGE_BYTES_MAX      = 16384,
  parameter int OOB_BYTES_MAX       = 2048,
  parameter int PAGES_PER_BLOCK_MAX = 1024,
  parameter int BLOCKS_PER_LUN_MAX  = 65536,
  parameter int DEF_PAGE_BYTES      = 512,     // geometry used until a parameter page is read
  parameter int DEF_OOB_BYTES       = 16,
  parameter int DEF_PAGES_PER_BLOCK = 16,
  parameter int DEF_BLOCKS_PER_LUN  = 64,
  parameter int DEF_LUNS            = 1,
  parameter int DEF_ROW_CYCLES      = 3,
  parameter int DEF_COL_CYCLES      = 2,
  parameter int TMO_READ_US         = 2000,    // default timeouts (us)
  parameter int TMO_PROG_US         = 10000,
  parameter int TMO_ERASE_US        = 50000,
  parameter int TMO_TGT_US          = 10000,
  parameter int POLL_READ_US        = 10,      // default first status poll (us)
  parameter int POLL_PROG_US        = 100,
  parameter int POLL_ERASE_US       = 1000,
  parameter int POLL_IV_US          = 5,       // default poll interval (us)
  parameter int ENABLE_PERF         = 1,
  localparam int NUM_RB  = (RB_SHARED != 0) ? 1 : NUM_CE,
  localparam int CEW     = (NUM_CE > 1) ? $clog2(NUM_CE) : 1,
  localparam int QD      = QUEUE_DEPTH,
  localparam int QW      = (QD > 1) ? $clog2(QD) : 1,
  localparam int WB      = BUF_DW / 8
) (
  input  wire logic                clk,
  input  wire logic                rst_n,          // async assert, sync release (integrator)
  // ---------------------------------------------------------------- requests
  input  wire logic                req_valid,
  output logic                     req_ready,
  input  wire logic [3:0]          req_op,
  input  wire logic [TAG_W-1:0]    req_tag,
  input  wire logic [2:0]          req_ce,
  input  wire logic [2:0]          req_lun,
  input  wire logic [23:0]         req_block,
  input  wire logic [15:0]         req_page,
  input  wire logic [15:0]         req_col,        // byte column (page data + OOB)
  input  wire logic [15:0]         req_len,        // bytes (READ_ID: count; READ_PARAM: !=0 stores 256 B)
  input  wire logic [31:0]         req_buf,        // buffer byte address (BUF_DW-aligned)
  input  wire logic [7:0]          req_faddr,      // feature address / READ ID address
  input  wire logic [31:0]         req_fdata,      // SET FEATURES P1..P4 (P1 in [7:0])
  // ---------------------------------------------------------------- completions
  output logic                     cpl_valid,
  input  wire logic                cpl_ready,
  output logic [TAG_W-1:0]         cpl_tag,
  output logic [3:0]               cpl_op,
  output logic [3:0]               cpl_status,
  output logic [7:0]               cpl_nand_status,
  output logic [2:0]               cpl_ce,
  output logic [2:0]               cpl_lun,
  output logic [31:0]              cpl_info0,
  output logic [31:0]              cpl_info1,
  output logic [31:0]              cpl_latency,    // accept -> completion, cycles
  output logic [31:0]              cpl_dev_time,   // confirm -> ready detected, cycles
  // ---------------------------------------------------------------- CSR (single cycle)
  input  wire logic                csr_sel,
  input  wire logic                csr_we,
  input  wire logic [7:0]          csr_addr,
  input  wire logic [31:0]         csr_wdata,
  output logic [31:0]              csr_rdata,
  output logic                     csr_err,
  // ---------------------------------------------------------------- SFB2 buffer master
  output logic                     m_req_valid,
  input  wire logic                m_req_ready,
  output logic                     m_req_write,
  output logic [31:0]              m_req_addr,
  output logic [BUF_DW-1:0]        m_req_wdata,
  output logic [WB-1:0]            m_req_wstrb,
  input  wire logic                m_rsp_valid,
  output logic                     m_rsp_ready,
  input  wire logic [BUF_DW-1:0]   m_rsp_rdata,
  input  wire logic                m_rsp_error,
  // ---------------------------------------------------------------- NAND pins
  output logic [NUM_CE-1:0]        nand_ce_n,
  output logic                     nand_cle,
  output logic                     nand_ale,
  output logic                     nand_we_n,
  output logic                     nand_re_n,
  output logic                     nand_wp_n,
  output logic [DQ_WIDTH-1:0]      nand_dq_o,
  output logic                     nand_dq_oe,
  input  wire logic [DQ_WIDTH-1:0] nand_dq_i,
  input  wire logic [NUM_RB-1:0]   nand_rb_n,      // asynchronous
  // ---------------------------------------------------------------- status
  output logic                     irq,
  output logic                     busy,
  output logic [2:0]               timing_mode
);
  // =========================================================================
  // constants
  // =========================================================================
  localparam int LT       = NUM_CE * NUM_LUN_MAX;          // LUN table entries
  localparam int LTW      = (LT > 1) ? $clog2(LT) : 1;
  localparam int UB       = DQ_WIDTH / 8;
  localparam int OFF      = $clog2(WB);
  localparam int CYC_US   = (1000000 + CLK_PERIOD_PS - 1) / CLK_PERIOD_PS;
  localparam int SYNC     = 2;
  localparam int CPLW     = TAG_W + 4 + 4 + 8 + 3 + 3 + 32 * 4;
  localparam int CCS_RECIP = (65536 * 1000 + CLK_PERIOD_PS - 1) / CLK_PERIOD_PS;   // ns -> cycles, x2^16
  localparam logic [31:0] CTRL_RST = 32'h0004_17C1;  // EN, AUTO_GEO/TIM/TMO, ORDER_CHK, POLL_EN, TMO_EN, starve 4

  localparam logic [127:0] TW0 = silicaflux_nand_timing_pkg::mode_word(0, CLK_PERIOD_PS, CAPTURE_MARGIN_PS, SYNC);
  localparam logic [127:0] TW1 = silicaflux_nand_timing_pkg::mode_word(1, CLK_PERIOD_PS, CAPTURE_MARGIN_PS, SYNC);
  localparam logic [127:0] TW2 = silicaflux_nand_timing_pkg::mode_word(2, CLK_PERIOD_PS, CAPTURE_MARGIN_PS, SYNC);
  localparam logic [127:0] TW3 = silicaflux_nand_timing_pkg::mode_word(3, CLK_PERIOD_PS, CAPTURE_MARGIN_PS, SYNC);
  localparam logic [127:0] TW4 = silicaflux_nand_timing_pkg::mode_word(4, CLK_PERIOD_PS, CAPTURE_MARGIN_PS, SYNC);
  localparam logic [127:0] TW5 = silicaflux_nand_timing_pkg::mode_word(5, CLK_PERIOD_PS, CAPTURE_MARGIN_PS, SYNC);

  function automatic logic [127:0] tw_of(input logic [2:0] m);
    case (m)
      3'd0:    tw_of = TW0;
      3'd1:    tw_of = TW1;
      3'd2:    tw_of = TW2;
      3'd3:    tw_of = TW3;
      3'd4:    tw_of = TW4;
      default: tw_of = TW5;
    endcase
  endfunction

  function automatic logic [31:0] us2cyc(input logic [15:0] us);
    us2cyc = 32'(us) * 32'(CYC_US);
  endfunction

  // =========================================================================
  // configuration registers
  // =========================================================================
  logic [31:0]  now;
  logic [31:0]  ctrl;
  logic [2:0]   tmode;
  logic [127:0] tw;
  logic [15:0]  geo_page, geo_oob, geo_ppb;
  logic [23:0]  geo_bpl;
  logic [7:0]   geo_luns;
  logic [3:0]   geo_rowc, geo_colc;
  logic [15:0]  geo_tmodes, geo_tr, geo_tprog, geo_tbers, geo_tccs;
  logic         geo_param;                       // geometry came from a parameter page
  logic [15:0]  geo_feat, geo_opt;               // parameter page: features, optional commands
  logic [31:0]  tmo_rd, tmo_pg, tmo_er, tmo_tgt;
  logic [23:0]  poll_rd, poll_pg, poll_er, poll_iv;
  logic [4:0]   err_sticky;

  assign timing_mode = tmode;
  wire c_en        = ctrl[silicaflux_nand_pkg::CTRL_EN];
  wire c_wp_n      = ctrl[silicaflux_nand_pkg::CTRL_WP_N];
  wire c_inter     = ctrl[silicaflux_nand_pkg::CTRL_INTERLEAVE];
  wire c_rdprio    = ctrl[silicaflux_nand_pkg::CTRL_RD_PRIO];
  wire c_enh       = ctrl[silicaflux_nand_pkg::CTRL_USE_ENH];
  wire c_mlun      = ctrl[silicaflux_nand_pkg::CTRL_MULTI_LUN];
  wire c_auto_geo  = ctrl[silicaflux_nand_pkg::CTRL_AUTO_GEO];
  wire c_auto_tim  = ctrl[silicaflux_nand_pkg::CTRL_AUTO_TIM];
  wire c_auto_tmo  = ctrl[silicaflux_nand_pkg::CTRL_AUTO_TMO];
  wire c_order     = ctrl[silicaflux_nand_pkg::CTRL_ORDER_CHK];
  wire c_poll      = ctrl[silicaflux_nand_pkg::CTRL_POLL_EN];
  wire c_irq       = ctrl[silicaflux_nand_pkg::CTRL_IRQ_EN];
  wire c_tmo       = ctrl[silicaflux_nand_pkg::CTRL_TMO_EN];
  wire [3:0] c_starve = ctrl[silicaflux_nand_pkg::CTRL_STARVE_LSB +: 4];

  // derived row-address layout
  // registered: geometry only changes while the channel is idle, and these sit
  // on the row-address path (one cycle behind a geometry update)
  logic [4:0] pg_bits, blk_bits, lun_sh;

  // =========================================================================
  // request slots
  // =========================================================================
  logic [1:0]       s_st   [0:QD-1];
  logic [3:0]       s_op   [0:QD-1];
  logic [TAG_W-1:0] s_tag  [0:QD-1];
  logic [2:0]       s_ce   [0:QD-1];
  logic [2:0]       s_lun  [0:QD-1];
  logic [23:0]      s_blk  [0:QD-1];
  logic [15:0]      s_pg   [0:QD-1];
  logic [15:0]      s_col  [0:QD-1];
  logic [15:0]      s_len  [0:QD-1];
  logic [31:0]      s_buf  [0:QD-1];
  logic [7:0]       s_fa   [0:QD-1];
  logic [31:0]      s_fd   [0:QD-1];
  logic [31:0]      s_tacc [0:QD-1];
  logic [31:0]      s_tiss [0:QD-1];
  logic [23:0]      s_pt   [0:QD-1];          // poll timer
  logic [QD-1:0]    s_rbmiss;                 // R/B# looked ready but the LUN was busy
  logic [QD-1:0]    s_older [0:QD-1];         // s_older[i][j]: slot i older than slot j

  // per-target / per-LUN state
  logic [LT-1:0]     lun_busy;
  logic [NUM_CE-1:0] tgt_busy, reset_done, faulted;
  logic [LT-1:0]     tr_v, tr_any;            // sequential-program tracker per LUN
  logic [23:0]       tr_blk [0:LT-1];
  logic [15:0]       tr_hp  [0:LT-1];

  logic [NUM_RB-1:0] rb_ready;

  // ------------------------------------------------------------ slot views
  logic [QD-1:0]  v_valid, v_pend, v_wait, v_tgt, v_arr, v_read, v_bad;
  logic [CEW-1:0] v_cei [0:QD-1];
  logic [LTW-1:0] v_li  [0:QD-1];
  logic [QD-1:0]  v_blocked, v_res, v_iss, v_poll, v_tmo, v_oldest_valid, v_nrst;
  logic [QD-1:0]  s_tmo_q;                  // busy time exceeded the op-class timeout (registered)
  logic           any_wait;

  // ready (synchronised R/B#) seen by each target
  logic [NUM_CE-1:0] rb_ce;
  if (RB_SHARED != 0) begin : g_rb_shared
    assign rb_ce = {NUM_CE{rb_ready[0]}};
  end else begin : g_rb_ce
    assign rb_ce = rb_ready;
  end
  function automatic logic rb_of(input logic [NUM_CE-1:0] rbv, input logic [CEW-1:0] c);
    rb_of = rbv[c];
  endfunction

  /* verilator lint_off UNUSEDSIGNAL */      // upper LUN bits unused when NUM_LUN_MAX is small
  function automatic logic [LTW-1:0] lidx(input logic [CEW-1:0] c, input logic [2:0] l);
    lidx = LTW'(c) * LTW'(NUM_LUN_MAX) + LTW'(l);
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */

  function automatic logic any_lun_of(input logic [LT-1:0] v, input logic [CEW-1:0] c);
    any_lun_of = 1'b0;
    for (int l = 0; l < NUM_LUN_MAX; l++)
      if (v[lidx(c, 3'(l))]) any_lun_of = 1'b1;
  endfunction

  function automatic logic [31:0] tmo_of(input logic [3:0] op, input logic [31:0] trd, input logic [31:0] tpg,
                                         input logic [31:0] ter, input logic [31:0] ttg);
    case (op)
      silicaflux_nand_pkg::OP_READ_PAGE:      tmo_of = trd;
      silicaflux_nand_pkg::OP_PROGRAM_PAGE:   tmo_of = tpg;
      silicaflux_nand_pkg::OP_ERASE_BLOCK:    tmo_of = ter;
      default:                                tmo_of = ttg;
    endcase
  endfunction

  // channel quiet (for target-level commands on a shared R/B# line)
  logic chan_busy_nf;            // something busy on a non-faulted target
  always_comb begin
    chan_busy_nf = |tgt_busy;
    for (int c = 0; c < NUM_CE; c++)
      if (!faulted[c] && any_lun_of(lun_busy, CEW'(c))) chan_busy_nf = 1'b1;
  end

  always_comb begin
    any_wait = 1'b0;
    for (int i = 0; i < QD; i++) begin
      v_valid[i] = (s_st[i] != silicaflux_nand_pkg::SL_FREE);
      v_pend[i]  = (s_st[i] == silicaflux_nand_pkg::SL_PEND);
      v_wait[i]  = (s_st[i] == silicaflux_nand_pkg::SL_WAIT);
      v_tgt[i]   = silicaflux_nand_pkg::op_is_tgt(s_op[i]);
      v_arr[i]   = silicaflux_nand_pkg::op_is_array(s_op[i]);
      v_read[i]  = (s_op[i] == silicaflux_nand_pkg::OP_READ_PAGE);
      v_bad[i]   = v_pend[i] && ((s_op[i] > silicaflux_nand_pkg::OP_LAST) ||
                                 ({1'b0, s_ce[i]} >= 4'(NUM_CE)) ||
                                 (!v_tgt[i] && ({1'b0, s_lun[i]} >= 4'(NUM_LUN_MAX))));
      v_cei[i]   = ({1'b0, s_ce[i]} < 4'(NUM_CE)) ? s_ce[i][CEW-1:0] : CEW'(0);
      v_li[i]    = ({1'b0, s_lun[i]} < 4'(NUM_LUN_MAX)) ? lidx(v_cei[i], s_lun[i]) : lidx(v_cei[i], 3'd0);
      if (v_wait[i]) any_wait = 1'b1;
    end
  end

  // ordering, resources, eligibility
  always_comb begin
    for (int i = 0; i < QD; i++) begin
      // an older request on the same target must finish first if either one is
      // target-level or both address the same LUN (per-LUN in-order)
      v_blocked[i] = 1'b0;
      for (int j = 0; j < QD; j++)
        if (j != i && v_valid[j] && s_older[j][i] && s_ce[j] == s_ce[i] &&
            (v_tgt[i] || v_tgt[j] || s_lun[j] == s_lun[i]))
          v_blocked[i] = 1'b1;
      // oldest valid slot overall (strict in-order mode)
      v_oldest_valid[i] = v_valid[i];
      for (int j = 0; j < QD; j++)
        if (j != i && v_valid[j] && s_older[j][i]) v_oldest_valid[i] = 1'b0;
      // resources
      if (v_arr[i])
        v_res[i] = !tgt_busy[v_cei[i]] && !lun_busy[v_li[i]] &&
                   (!any_lun_of(lun_busy, v_cei[i]) || (c_mlun && c_enh && reset_done[v_cei[i]]));
      else if (s_op[i] == silicaflux_nand_pkg::OP_READ_STATUS)
        v_res[i] = !tgt_busy[v_cei[i]];
      else if (s_op[i] == silicaflux_nand_pkg::OP_RESET)
        v_res[i] = !tgt_busy[v_cei[i]] && ((RB_SHARED == 0) || !chan_busy_nf);
      else
        v_res[i] = !tgt_busy[v_cei[i]] && !any_lun_of(lun_busy, v_cei[i]) &&
                   ((RB_SHARED == 0) || !chan_busy_nf);
      // a request to a target that needs RESET fails fast (it may never get its resources)
      v_nrst[i] = v_pend[i] && !v_bad[i] && !v_blocked[i] &&
                  (s_op[i] != silicaflux_nand_pkg::OP_RESET) && (s_op[i] != silicaflux_nand_pkg::OP_READ_STATUS) &&
                  (!reset_done[v_cei[i]] || faulted[v_cei[i]]);
      v_iss[i]  = c_en && v_pend[i] && !v_bad[i] && !v_nrst[i] && !v_blocked[i] && v_res[i] &&
                  (c_inter || (!any_wait && v_oldest_valid[i]));
      v_poll[i] = v_wait[i] && (v_tgt[i] ? rb_of(rb_ce, v_cei[i])
                                         : ((rb_of(rb_ce, v_cei[i]) && !s_rbmiss[i]) ||
                                            (c_poll && s_pt[i] == 24'd0)));
      v_tmo[i]  = s_tmo_q[i] && v_wait[i];        // comparison registered (s_tmo_q)
    end
  end

  // oldest member of a set
  function automatic logic [QW-1:0] oldest_of(input logic [QD-1:0] set, input logic [QD*QD-1:0] older_flat);
    logic hit;
    oldest_of = '0;
    for (int i = QD - 1; i >= 0; i--) begin
      hit = set[i];
      for (int j = 0; j < QD; j++)
        if (j != i && set[j] && older_flat[j * QD + i]) hit = 1'b0;
      if (hit) oldest_of = QW'(i);
    end
  endfunction

  logic [QD*QD-1:0] older_flat;
  always_comb for (int i = 0; i < QD; i++) older_flat[i * QD +: QD] = s_older[i];

  logic [3:0]    starve_cnt;
  logic          pick_v;
  logic [QW-1:0] pick_i;
  logic [2:0]    pick_k;
  logic          pick_rd_bypass;       // a read was chosen over an issuable program/erase/other
  always_comb begin : b_pick
    logic [QD-1:0] rd_set, oth_set;
    pick_v = 1'b0;
    pick_i = '0;
    pick_k = silicaflux_nand_pkg::J_ISSUE;
    pick_rd_bypass = 1'b0;
    rd_set  = v_iss & v_read;
    oth_set = v_iss & ~v_read;
    if (|(v_bad | v_nrst)) begin
      pick_v = 1'b1; pick_k = silicaflux_nand_pkg::J_ERR;  pick_i = oldest_of(v_bad | v_nrst, older_flat);
    end else if (|v_tmo) begin
      pick_v = 1'b1; pick_k = silicaflux_nand_pkg::J_TMO;  pick_i = oldest_of(v_tmo, older_flat);
    end else if (|v_poll) begin
      pick_v = 1'b1; pick_k = silicaflux_nand_pkg::J_COMP; pick_i = oldest_of(v_poll, older_flat);
    end else if (|v_iss) begin
      pick_v = 1'b1; pick_k = silicaflux_nand_pkg::J_ISSUE;
      if (c_rdprio && (|rd_set) && !((starve_cnt >= c_starve) && (|oth_set))) begin
        pick_i = oldest_of(rd_set, older_flat);
        pick_rd_bypass = |oth_set;
      end else pick_i = oldest_of(v_iss, older_flat);
    end
  end

  // Registered pick: the scheduler decision is computed in one cycle and used in a later one.
  // The sequencer uses it only after a full idle cycle (idle_q), so it always reflects the state
  // after the previous job's completion updates (docs/04 section 2).
  logic          pk_v, pk_bypass, pk_rd, pk_hint, idle_q;
  logic [QW-1:0] pk_i;
  logic [2:0]    pk_k;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pk_v <= 1'b0; pk_i <= '0; pk_k <= 3'd0; pk_bypass <= 1'b0; pk_rd <= 1'b0; pk_hint <= 1'b0; idle_q <= 1'b0;
      s_tmo_q <= '0;
    end else begin
      pk_v      <= pick_v;
      pk_i      <= pick_i;
      pk_k      <= pick_k;
      pk_bypass <= pick_rd_bypass;
      pk_rd     <= v_read[pick_i];
      pk_hint   <= rb_of(rb_ce, v_cei[pick_i]) && !s_rbmiss[pick_i];
      idle_q    <= (bst == silicaflux_nand_pkg::B_IDLE);
      for (int i = 0; i < QD; i++)
        s_tmo_q[i] <= c_tmo && v_wait[i] && ((now - s_tiss[i]) > tmo_of(s_op[i], tmo_rd, tmo_pg, tmo_er, tmo_tgt));
    end
  end
  wire pick_go = (bst == silicaflux_nand_pkg::B_IDLE) && idle_q && pk_v;

  // free slot for a new request: lowest free slot, registered one-hot (fr_oh). After an accept
  // the next cycle refuses (acc_q) so the registered choice always reflects the last accept.
  logic [QD-1:0] free_oh, fr_oh;
  logic          acc_q;
  always_comb begin
    free_oh = '0;
    for (int i = QD - 1; i >= 0; i--)
      if (!v_valid[i]) begin free_oh = '0; free_oh[i] = 1'b1; end
  end
  assign req_ready = (|fr_oh) && !acc_q;
  wire accept = req_valid && req_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fr_oh <= '0;
      acc_q <= 1'b0;
    end else begin
      fr_oh <= free_oh;
      acc_q <= accept;
    end
  end

  // =========================================================================
  // timing engine and buffer master
  // =========================================================================
  logic                uop_valid, uop_imm, uop_abort, uop_done;
  logic [2:0]          uop_kind;
  logic [39:0]         uop_bytes;
  logic [15:0]         uop_count;
  logic                din_valid, din_pop, dout_space, dout_valid;
  logic [DQ_WIDTH-1:0] din_data, dout_data;
  logic                eng_beat, eng_active;
  logic [CEW-1:0]      j_cei;

  sfnc_timing_engine #(.DQW(DQ_WIDTH), .NUM_CE(NUM_CE), .NUM_RB(NUM_RB), .SYNC_STAGES(SYNC)) u_eng (
    .clk(clk), .rst_n(rst_n), .tw(tw[87:0]), .wp_n_req(c_wp_n),
    .uop_valid(uop_valid), .uop_kind(uop_kind), .uop_bytes(uop_bytes), .uop_count(uop_count),
    .uop_ce(j_cei), .uop_imm(uop_imm), .uop_abort(uop_abort), .uop_done(uop_done),
    .din_valid(din_valid), .din_data(din_data), .din_pop(din_pop),
    .dout_space(dout_space), .dout_valid(dout_valid), .dout_data(dout_data),
    .rb_ready(rb_ready), .data_beat(eng_beat), .active(eng_active),
    .ce_n(nand_ce_n), .cle(nand_cle), .ale(nand_ale), .we_n(nand_we_n), .re_n(nand_re_n),
    .wp_n(nand_wp_n), .dq_o(nand_dq_o), .dq_oe(nand_dq_oe), .dq_i(nand_dq_i), .rb_n(nand_rb_n));

  logic        bm_err_clr, bm_rd_start, bm_wr_start, bm_wr_en, bm_flush;
  logic        bm_rd_err, bm_wr_err, bm_wr_idle, bm_quiet;
  logic [15:0] j_units;
  logic [31:0] j_buf;

  sfnc_buf_master #(.DQW(DQ_WIDTH), .DW(BUF_DW), .RFIFO(4), .WFIFO(4)) u_bm (
    .clk(clk), .rst_n(rst_n), .err_clr(bm_err_clr),
    .rd_start(bm_rd_start), .rd_addr(j_buf), .rd_units(j_units), .rd_err(bm_rd_err),
    .din_valid(din_valid), .din_data(din_data), .din_pop(din_pop),
    .wr_start(bm_wr_start), .wr_addr(j_buf), .wr_en(bm_wr_en), .wr_flush(bm_flush),
    .wr_idle(bm_wr_idle), .wr_err(bm_wr_err),
    .dout_valid(dout_valid), .dout_data(dout_data), .dout_space(dout_space), .quiet(bm_quiet),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write),
    .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata),
    .m_rsp_error(m_rsp_error));

  // =========================================================================
  // bus sequencer (current job)
  // =========================================================================
  logic [4:0]       bst;
  logic [QW-1:0]    cur;
  logic [2:0]       jk;
  logic [3:0]       j_op;
  logic [TAG_W-1:0] j_tag;
  logic [2:0]       j_ce, j_lun;
  logic [23:0]      j_blk;
  logic [15:0]      j_pg, j_col, j_len;
  logic [7:0]       j_fa;
  logic [31:0]      j_fd;
  logic [3:0]       j_cs;
  logic [7:0]       j_nst;
  logic [31:0]      j_info0, j_info1;
  logic             j_cmpl, j_wr, j_miss, j_hint;
  logic [1:0]       j_copy;
  logic [8:0]       j_pidx;
  logic [15:0]      j_crc;
  logic [63:0]      j_id;
  logic [3:0]       j_idn;
  logic [LTW-1:0]   j_li;                    // LUN-table index of the job (registered at pick)
  logic [31:0]      j_trdy;                  // time ready was detected

  // parameter-page candidate fields (little-endian assembly)
  logic [31:0] pp_sig, pp_page, pp_ppb, pp_bpl;
  logic [15:0] pp_feat, pp_opt, pp_oob, pp_tmodes, pp_tprog, pp_tbers, pp_tr, pp_tccs, pp_crc;
  logic [7:0]  pp_luns, pp_acyc;

  wire        j_ce_in  = ({1'b0, j_ce}  < 4'(NUM_CE));
  wire        j_lun_in = ({1'b0, j_lun} < 4'(NUM_LUN_MAX));
  assign      j_cei    = j_ce_in ? j_ce[CEW-1:0] : CEW'(0);
  wire        j_arr    = silicaflux_nand_pkg::op_is_array(j_op);
  wire        j_rw     = (j_op == silicaflux_nand_pkg::OP_READ_PAGE) || (j_op == silicaflux_nand_pkg::OP_PROGRAM_PAGE);
  wire        j_store  = (j_len != 16'd0);
  wire        enh_eff  = c_enh && reset_done[j_cei];
  assign      j_units  = (DQ_WIDTH == 16) ? {1'b0, j_len[15:1]} : j_len;
  wire [15:0] j_colu   = (DQ_WIDTH == 16) ? {1'b0, j_col[15:1]} : j_col;
  wire [23:0] row_page = 24'(j_pg) | (j_blk << pg_bits) | (24'(j_lun) << lun_sh);   // registered in B_CHECK
  wire [23:0] row_lun  = 24'(j_lun) << lun_sh;
  logic [23:0] j_row, j_rowlun;
  wire [39:0] ab_page  = (geo_colc == 4'd1) ? {8'd0, j_row, j_colu[7:0]} : {j_row, j_colu};
  wire [15:0] an_page  = 16'(geo_colc) + 16'(geo_rowc);
  wire [3:0]  id_n     = (j_len == 16'd0) ? 4'd5 : j_len[3:0];
  wire        st_rdy   = j_nst[silicaflux_nand_pkg::SR_RDY] && j_nst[silicaflux_nand_pkg::SR_ARDY];
  // tCCS from the parameter page (500 ns when unknown), rounded up to cycles without a divider
  // log2 terms are evaluated in always_comb (event driven: simulators re-evaluate them only when the
  // geometry changes) and registered below; same logic as calling the function in always_ff
  logic [4:0] pg_bits_c, blk_bits_c, pp_pb_c, pp_bb_c, pp_lb_c;
  always_comb begin
    pg_bits_c  = silicaflux_nand_pkg::clog2_rt({8'd0, geo_ppb});
    blk_bits_c = silicaflux_nand_pkg::clog2_rt(geo_bpl);
    pp_pb_c    = silicaflux_nand_pkg::clog2_rt(pp_ppb[23:0]);
    pp_bb_c    = silicaflux_nand_pkg::clog2_rt(pp_bpl[23:0]);
    pp_lb_c    = silicaflux_nand_pkg::clog2_rt({16'd0, pp_luns});
  end

  // tCCS ns -> cycles in three registered steps (geometry changes only while the channel is idle)
  logic [15:0] ccs_ns, ccs_cyc;
  logic [47:0] ccs_prod;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pg_bits <= 5'd0; blk_bits <= 5'd0; lun_sh <= 5'd0; ccs_cyc <= 16'd1; ccs_ns <= 16'd500; ccs_prod <= 48'd0;
    end else begin
      pg_bits  <= pg_bits_c;
      blk_bits <= blk_bits_c;
      lun_sh   <= pg_bits + blk_bits;
      ccs_ns   <= (geo_tccs == 16'd0) ? 16'd500 : geo_tccs;
      ccs_prod <= 48'(ccs_ns) * 48'(CCS_RECIP);
      ccs_cyc  <= 16'(ccs_prod >> 16) + 16'd1;
    end
  end

  // ---------------------------------------------------------- parameter-page acceptance
  // address-bit counts of the candidate geometry (registered: stage 1 of the support check)
  logic [4:0] pp_pb, pp_bb, pp_lb;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pp_pb <= 5'd0; pp_bb <= 5'd0; pp_lb <= 5'd0;
    end else begin
      pp_pb <= pp_pb_c;
      pp_bb <= pp_bb_c;
      pp_lb <= pp_lb_c;
    end
  end
  wire [3:0]  pp_rowc = pp_acyc[3:0];
  wire [3:0]  pp_colc = pp_acyc[7:4];
  wire        pp_sig_ok = (pp_sig == 32'h4946_4E4F);                // "ONFI" little-endian
  wire        pp_crc_ok = (pp_crc == j_crc);
  // pp_sup is registered (stage 2): its fields are complete at byte 140, 115 byte cycles before the copy ends
  logic       pp_sup;
  wire        pp_sup_c =
      (pp_page != 32'd0) && (pp_page <= 32'(PAGE_BYTES_MAX)) && (pp_oob <= 16'(OOB_BYTES_MAX)) &&
      ((pp_page + 32'(pp_oob)) <= 32'd65535) &&
      (pp_ppb != 32'd0) && (pp_ppb <= 32'(PAGES_PER_BLOCK_MAX)) &&
      (pp_bpl != 32'd0) && (pp_bpl <= 32'(BLOCKS_PER_LUN_MAX)) && (pp_bpl <= 32'h00FF_FFFF) &&
      (pp_luns != 8'd0) && (32'(pp_luns) <= 32'(NUM_LUN_MAX)) &&
      (pp_rowc == 4'd2 || pp_rowc == 4'd3) && (pp_colc == 4'd1 || pp_colc == 4'd2) &&
      ((6'(pp_pb) + 6'(pp_bb) + 6'(pp_lb)) <= 6'({pp_rowc, 3'b000})) &&
      (pp_feat[0] == (DQ_WIDTH == 16));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) pp_sup <= 1'b0;
    else        pp_sup <= pp_sup_c;
  end

  // ---------------------------------------------------------- validation (B_CHECK)
  logic [3:0] verr;
  // Individual checks are evaluated in B_CHECK and registered (j_vf); B_CHECK2 encodes them
  // in priority order (two short paths instead of one long one).
  localparam int NVF = 14;
  logic [NVF-1:0] vf, j_vf;
  always_comb begin : b_vflags
    logic [16:0] nxt;
    nxt   = tr_any[j_li] ? (17'(tr_hp[j_li]) + 17'd1) : 17'd0;
    vf[0]  = (j_op > silicaflux_nand_pkg::OP_LAST);
    vf[1]  = !j_ce_in;
    vf[2]  = !silicaflux_nand_pkg::op_is_tgt(j_op) && !j_lun_in;
    vf[3]  = j_op != silicaflux_nand_pkg::OP_RESET && j_op != silicaflux_nand_pkg::OP_READ_STATUS &&
             (!reset_done[j_cei] || faulted[j_cei]);
    vf[4]  = (j_arr || (j_op == silicaflux_nand_pkg::OP_READ_STATUS && enh_eff)) && (8'(j_lun) >= geo_luns);
    vf[5]  = j_arr && (j_blk >= geo_bpl);
    vf[6]  = j_rw && (j_pg >= geo_ppb);
    vf[7]  = j_rw && ((j_len == 16'd0) || ((17'(j_col) + 17'(j_len)) > (17'(geo_page) + 17'(geo_oob))));
    vf[8]  = j_rw && (DQ_WIDTH == 16) && (j_col[0] || j_len[0]);
    vf[9]  = (j_rw || (j_op == silicaflux_nand_pkg::OP_READ_PARAM && j_store)) && (j_buf[OFF-1:0] != '0);
    vf[10] = (j_op == silicaflux_nand_pkg::OP_PROGRAM_PAGE || j_op == silicaflux_nand_pkg::OP_ERASE_BLOCK) && !c_wp_n;
    vf[11] = j_op == silicaflux_nand_pkg::OP_PROGRAM_PAGE && c_order && tr_v[j_li] && (tr_blk[j_li] == j_blk) &&
             (17'(j_pg) > nxt);
    vf[12] = j_op == silicaflux_nand_pkg::OP_READ_ID && (j_len > 16'd8);
    vf[13] = j_op == silicaflux_nand_pkg::OP_SET_FEATURES && j_fa == silicaflux_nand_pkg::FA_TIMING_MODE &&
             c_auto_tim && ((j_fd[3:0] > 4'd5) || (geo_param && !geo_tmodes[j_fd[3:0]]));
  end

  always_comb begin : b_verr
    verr = silicaflux_nand_pkg::CS_OK;
    if      (j_vf[0])  verr = silicaflux_nand_pkg::CS_BAD_OP;
    else if (j_vf[1])  verr = silicaflux_nand_pkg::CS_BAD_ADDR;
    else if (j_vf[2])  verr = silicaflux_nand_pkg::CS_BAD_ADDR;
    else if (j_vf[3])  verr = silicaflux_nand_pkg::CS_NOT_RESET;
    else if (j_vf[4])  verr = silicaflux_nand_pkg::CS_BAD_ADDR;
    else if (j_vf[5])  verr = silicaflux_nand_pkg::CS_BAD_ADDR;
    else if (j_vf[6])  verr = silicaflux_nand_pkg::CS_BAD_ADDR;
    else if (j_vf[7])  verr = silicaflux_nand_pkg::CS_BAD_ADDR;
    else if (j_vf[8])  verr = silicaflux_nand_pkg::CS_ALIGN;
    else if (j_vf[9])  verr = silicaflux_nand_pkg::CS_ALIGN;
    else if (j_vf[10]) verr = silicaflux_nand_pkg::CS_WP;
    else if (j_vf[11]) verr = silicaflux_nand_pkg::CS_PROG_ORDER;
    else if (j_vf[12]) verr = silicaflux_nand_pkg::CS_BAD_ADDR;
    else if (j_vf[13]) verr = silicaflux_nand_pkg::CS_UNSUPPORTED;
  end

  // ---------------------------------------------------------- micro-operation for the current state
  always_comb begin
    uop_valid = 1'b0;
    uop_kind  = silicaflux_nand_pkg::U_DELAY;
    uop_bytes = 40'd0;
    uop_count = 16'd1;
    uop_imm   = 1'b0;
    uop_abort = 1'b0;
    case (bst)
      silicaflux_nand_pkg::B_CESEL: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_CESEL;
      end
      silicaflux_nand_pkg::B_CMD1: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_CMD;
        case (j_op)
          silicaflux_nand_pkg::OP_RESET:        uop_bytes[7:0] = silicaflux_nand_pkg::CMD_RESET;
          silicaflux_nand_pkg::OP_READ_ID:      uop_bytes[7:0] = silicaflux_nand_pkg::CMD_READ_ID;
          silicaflux_nand_pkg::OP_READ_PARAM:   uop_bytes[7:0] = silicaflux_nand_pkg::CMD_READ_PARAM;
          silicaflux_nand_pkg::OP_READ_PAGE:    uop_bytes[7:0] = silicaflux_nand_pkg::CMD_READ_1;
          silicaflux_nand_pkg::OP_PROGRAM_PAGE: uop_bytes[7:0] = silicaflux_nand_pkg::CMD_PROG_1;
          silicaflux_nand_pkg::OP_ERASE_BLOCK:  uop_bytes[7:0] = silicaflux_nand_pkg::CMD_ERASE_1;
          silicaflux_nand_pkg::OP_SET_FEATURES: uop_bytes[7:0] = silicaflux_nand_pkg::CMD_SET_FEAT;
          default:                              uop_bytes[7:0] = silicaflux_nand_pkg::CMD_GET_FEAT;
        endcase
      end
      silicaflux_nand_pkg::B_ADDR: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_ADDR;
        if (j_rw) begin
          uop_bytes = ab_page; uop_count = an_page;
        end else if (j_op == silicaflux_nand_pkg::OP_ERASE_BLOCK) begin
          uop_bytes = {16'd0, j_row}; uop_count = 16'(geo_rowc);
        end else if (j_op == silicaflux_nand_pkg::OP_READ_PARAM) begin
          uop_bytes = 40'd0; uop_count = 16'd1;
        end else begin
          uop_bytes = {32'd0, j_fa}; uop_count = 16'd1;          // READ ID / features
        end
      end
      silicaflux_nand_pkg::B_DIN_BUF: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DIN; uop_count = j_units; uop_abort = bm_rd_err;
      end
      silicaflux_nand_pkg::B_DIN_IMM: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DIN; uop_imm = 1'b1;
        uop_bytes = {8'd0, j_fd}; uop_count = 16'd4;
      end
      silicaflux_nand_pkg::B_CMD2: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_CMD;
        uop_bytes[7:0] = (j_op == silicaflux_nand_pkg::OP_READ_PAGE)    ? silicaflux_nand_pkg::CMD_READ_2 :
                         (j_op == silicaflux_nand_pkg::OP_PROGRAM_PAGE) ? silicaflux_nand_pkg::CMD_PROG_2 :
                                                                          silicaflux_nand_pkg::CMD_ERASE_2;
      end
      silicaflux_nand_pkg::B_WB: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DELAY;
        uop_count = 16'(tw[silicaflux_nand_timing_pkg::F_WB +: 8]);
      end
      silicaflux_nand_pkg::B_DOUT_ID: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DOUT; uop_count = 16'(id_n);
      end
      silicaflux_nand_pkg::B_ST_CMD: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_CMD;
        uop_bytes[7:0] = enh_eff ? silicaflux_nand_pkg::CMD_STATUS_ENH : silicaflux_nand_pkg::CMD_STATUS;
      end
      silicaflux_nand_pkg::B_ST_ADDR: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_ADDR;
        uop_bytes = {16'd0, j_rowlun}; uop_count = 16'(geo_rowc);
      end
      silicaflux_nand_pkg::B_ST_RD: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DOUT; uop_count = 16'd1;
      end
      silicaflux_nand_pkg::B_RESUME: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_CMD; uop_bytes[7:0] = silicaflux_nand_pkg::CMD_CRCOL_1;
      end
      silicaflux_nand_pkg::B_CRC_ADDR: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_ADDR;
        uop_bytes = {24'd0, j_colu}; uop_count = 16'(geo_colc);
      end
      silicaflux_nand_pkg::B_CRC2: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_CMD; uop_bytes[7:0] = silicaflux_nand_pkg::CMD_CRCOL_2;
      end
      silicaflux_nand_pkg::B_CCS: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DELAY; uop_count = ccs_cyc;
      end
      silicaflux_nand_pkg::B_DOUT_DATA: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DOUT; uop_count = j_units; uop_abort = bm_wr_err;
      end
      silicaflux_nand_pkg::B_RR: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DELAY;
        uop_count = 16'(tw[silicaflux_nand_timing_pkg::F_RR +: 8]);
      end
      silicaflux_nand_pkg::B_DOUT_PRM: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DOUT; uop_count = 16'd256; uop_abort = bm_wr_err;
      end
      silicaflux_nand_pkg::B_DOUT_FEAT: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_DOUT; uop_count = 16'd4;
      end
      silicaflux_nand_pkg::B_CEOFF: begin
        uop_valid = 1'b1; uop_kind = silicaflux_nand_pkg::U_CEOFF;
      end
      default: ;
    endcase
  end

  assign bm_wr_en = (bst == silicaflux_nand_pkg::B_DOUT_DATA) || (bst == silicaflux_nand_pkg::B_DOUT_PRM && j_store);

  // ---------------------------------------------------------- completion queue
  logic            cq_in_valid, cq_in_ready;
  logic [CPLW-1:0] cq_in, cq_out;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(CPL_DEPTH):0] cq_level;
  /* verilator lint_on UNUSEDSIGNAL */
  sfnc_fifo #(.W(CPLW), .DEPTH(CPL_DEPTH)) u_cq (
    .clk(clk), .rst_n(rst_n), .clr(1'b0),
    .in_valid(cq_in_valid), .in_ready(cq_in_ready), .in_data(cq_in),
    .out_valid(cpl_valid), .out_ready(cpl_ready), .out_data(cq_out), .level(cq_level));
  assign {cpl_tag, cpl_op, cpl_status, cpl_nand_status, cpl_ce, cpl_lun,
          cpl_info0, cpl_info1, cpl_latency, cpl_dev_time} = cq_out;

  wire fin_ok   = (bst == silicaflux_nand_pkg::B_FIN) && bm_quiet;
  wire fin_cmpl = fin_ok && j_cmpl && cq_in_ready;
  wire fin_wait = fin_ok && !j_cmpl;
  wire [31:0] lat_now = now - s_tacc[cur];
  wire [31:0] dev_now = (jk == silicaflux_nand_pkg::J_COMP || jk == silicaflux_nand_pkg::J_TMO) ?
                        (j_trdy - s_tiss[cur]) : 32'd0;
  assign cq_in_valid = fin_ok && j_cmpl;
  assign cq_in = {j_tag, j_op, j_cs, j_nst, j_ce, j_lun, j_info0, j_info1, lat_now, dev_now};

  // ---------------------------------------------------------- sequencer
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      bst <= silicaflux_nand_pkg::B_IDLE; cur <= '0; jk <= 3'd0; j_op <= 4'd0; j_tag <= '0;
      j_ce <= 3'd0; j_lun <= 3'd0; j_blk <= 24'd0; j_pg <= 16'd0; j_col <= 16'd0; j_len <= 16'd0;
      j_buf <= 32'd0; j_fa <= 8'd0; j_fd <= 32'd0; j_cs <= 4'd0; j_nst <= 8'd0;
      j_info0 <= 32'd0; j_info1 <= 32'd0; j_cmpl <= 1'b0; j_wr <= 1'b0; j_miss <= 1'b0; j_hint <= 1'b0;
      j_copy <= 2'd0; j_pidx <= 9'd0; j_crc <= 16'h4F4E; j_id <= 64'd0; j_idn <= 4'd0; j_trdy <= 32'd0;
      j_row <= 24'd0; j_rowlun <= 24'd0; j_vf <= '0; j_li <= '0;
      pp_sig <= 32'd0; pp_page <= 32'd0; pp_ppb <= 32'd0; pp_bpl <= 32'd0; pp_feat <= 16'd0; pp_opt <= 16'd0;
      pp_oob <= 16'd0; pp_tmodes <= 16'd0; pp_tprog <= 16'd0; pp_tbers <= 16'd0; pp_tr <= 16'd0;
      pp_tccs <= 16'd0; pp_crc <= 16'd0; pp_luns <= 8'd0; pp_acyc <= 8'd0;
      bm_err_clr <= 1'b0; bm_rd_start <= 1'b0; bm_wr_start <= 1'b0; bm_flush <= 1'b0;
    end else begin
      bm_err_clr  <= 1'b0;
      bm_rd_start <= 1'b0;
      bm_wr_start <= 1'b0;
      bm_flush    <= 1'b0;
      case (bst)
        // ------------------------------------------------------------ pick a job
        silicaflux_nand_pkg::B_IDLE: begin
          if (pick_go) begin
            cur   <= pk_i;
            jk    <= pk_k;
            j_op  <= s_op[pk_i];  j_tag <= s_tag[pk_i]; j_ce  <= s_ce[pk_i]; j_lun <= s_lun[pk_i];
            j_blk <= s_blk[pk_i]; j_pg  <= s_pg[pk_i];  j_col <= s_col[pk_i]; j_len <= s_len[pk_i];
            j_buf <= s_buf[pk_i]; j_fa  <= s_fa[pk_i];  j_fd  <= s_fd[pk_i];
            j_cs  <= silicaflux_nand_pkg::CS_OK; j_nst <= 8'd0; j_info0 <= 32'd0; j_info1 <= 32'd0;
            j_cmpl <= 1'b1; j_wr <= 1'b0; j_miss <= 1'b0; j_copy <= 2'd0; j_pidx <= 9'd0;
            j_hint <= pk_hint;
            j_li   <= v_li[pk_i];
            j_trdy <= now;
            j_crc <= 16'h4F4E; j_id <= 64'd0; j_idn <= 4'd0;
            bm_err_clr <= 1'b1;
            bst <= silicaflux_nand_pkg::B_CHECK;
          end
        end
        // ------------------------------------------------------------ validate / route
        silicaflux_nand_pkg::B_CHECK: begin
          j_row    <= row_page;
          j_rowlun <= row_lun;
          j_vf     <= vf;
          bst      <= silicaflux_nand_pkg::B_CHECK2;
        end
        silicaflux_nand_pkg::B_CHECK2: begin
          case (jk)
            silicaflux_nand_pkg::J_TMO: begin
              j_cs <= silicaflux_nand_pkg::CS_TIMEOUT; j_cmpl <= 1'b1; bst <= silicaflux_nand_pkg::B_FIN;
            end
            silicaflux_nand_pkg::J_COMP: begin
              j_cmpl <= 1'b1;
              if (j_op == silicaflux_nand_pkg::OP_SET_FEATURES) bst <= silicaflux_nand_pkg::B_FIN;
              else                                              bst <= silicaflux_nand_pkg::B_CESEL;
            end
            default: begin   // J_ISSUE / J_ERR
              if (verr != silicaflux_nand_pkg::CS_OK) begin
                j_cs <= verr; j_cmpl <= 1'b1; bst <= silicaflux_nand_pkg::B_FIN;
              end else begin
                j_cmpl <= (j_op == silicaflux_nand_pkg::OP_READ_ID) || (j_op == silicaflux_nand_pkg::OP_READ_STATUS);
                if (j_op == silicaflux_nand_pkg::OP_PROGRAM_PAGE) bm_rd_start <= 1'b1;
                j_info1 <= {8'd0, j_row};
                bst <= silicaflux_nand_pkg::B_CESEL;
              end
            end
          endcase
        end
        silicaflux_nand_pkg::B_CESEL: if (uop_done) begin
          if (jk == silicaflux_nand_pkg::J_ISSUE)
            bst <= (j_op == silicaflux_nand_pkg::OP_READ_STATUS) ? silicaflux_nand_pkg::B_ST_CMD : silicaflux_nand_pkg::B_CMD1;
          else if (j_op == silicaflux_nand_pkg::OP_READ_PARAM || j_op == silicaflux_nand_pkg::OP_GET_FEATURES)
            bst <= silicaflux_nand_pkg::B_RR;
          else
            bst <= silicaflux_nand_pkg::B_ST_CMD;           // RESET / array: status
        end
        silicaflux_nand_pkg::B_CMD1: if (uop_done) begin
          bst <= (j_op == silicaflux_nand_pkg::OP_RESET) ? silicaflux_nand_pkg::B_WB : silicaflux_nand_pkg::B_ADDR;
        end
        silicaflux_nand_pkg::B_ADDR: if (uop_done) begin
          case (j_op)
            silicaflux_nand_pkg::OP_READ_ID:      bst <= silicaflux_nand_pkg::B_DOUT_ID;
            silicaflux_nand_pkg::OP_READ_PARAM:   bst <= silicaflux_nand_pkg::B_WB;
            silicaflux_nand_pkg::OP_GET_FEATURES: bst <= silicaflux_nand_pkg::B_WB;
            silicaflux_nand_pkg::OP_SET_FEATURES: bst <= silicaflux_nand_pkg::B_DIN_IMM;
            silicaflux_nand_pkg::OP_PROGRAM_PAGE: bst <= silicaflux_nand_pkg::B_DIN_BUF;
            default:                              bst <= silicaflux_nand_pkg::B_CMD2;
          endcase
        end
        silicaflux_nand_pkg::B_DIN_BUF: if (uop_done) begin
          if (bm_rd_err) begin
            // no confirm: the device never programs; the next command cancels the load
            j_cs <= silicaflux_nand_pkg::CS_BUF_ERR; j_cmpl <= 1'b1; bst <= silicaflux_nand_pkg::B_CEOFF;
          end else bst <= silicaflux_nand_pkg::B_CMD2;
        end
        silicaflux_nand_pkg::B_DIN_IMM: if (uop_done) bst <= silicaflux_nand_pkg::B_WB;
        silicaflux_nand_pkg::B_CMD2:    if (uop_done) bst <= silicaflux_nand_pkg::B_WB;
        silicaflux_nand_pkg::B_WB:      if (uop_done) bst <= silicaflux_nand_pkg::B_CEOFF;
        silicaflux_nand_pkg::B_DOUT_ID: begin
          if (dout_valid) begin
            for (int b = 0; b < 8; b++) if (j_idn[2:0] == 3'(b)) j_id[b*8 +: 8] <= dout_data[7:0];
            j_idn <= j_idn + 4'd1;
          end
          if (uop_done) begin
            j_info0 <= j_id[31:0];
            j_info1 <= j_id[63:32];
            bst <= silicaflux_nand_pkg::B_CEOFF;
          end
        end
        silicaflux_nand_pkg::B_ST_CMD: if (uop_done) begin
          bst <= enh_eff ? silicaflux_nand_pkg::B_ST_ADDR : silicaflux_nand_pkg::B_ST_RD;
        end
        silicaflux_nand_pkg::B_ST_ADDR: if (uop_done) bst <= silicaflux_nand_pkg::B_ST_RD;
        silicaflux_nand_pkg::B_ST_RD: begin
          if (dout_valid) j_nst <= dout_data[7:0];
          if (uop_done && st_rdy) j_trdy <= now;
          if (uop_done) begin
            if (jk == silicaflux_nand_pkg::J_ISSUE) begin                  // READ_STATUS
              j_info0 <= {24'd0, j_nst};
              bst <= silicaflux_nand_pkg::B_CEOFF;
            end else if (j_op == silicaflux_nand_pkg::OP_RESET) begin
              j_info0 <= {24'd0, j_nst};
              j_cs <= st_rdy ? silicaflux_nand_pkg::CS_OK : silicaflux_nand_pkg::CS_NOT_READY;
              bst <= silicaflux_nand_pkg::B_CEOFF;
            end else if (!st_rdy) begin                                    // poll miss
              j_cmpl <= 1'b0; j_miss <= 1'b1;
              bst <= silicaflux_nand_pkg::B_CEOFF;
            end else if (j_op == silicaflux_nand_pkg::OP_READ_PAGE) begin
              bm_wr_start <= 1'b1; j_wr <= 1'b1;
              bst <= silicaflux_nand_pkg::B_RESUME;
            end else begin                                                 // program / erase
              j_cs <= j_nst[silicaflux_nand_pkg::SR_FAIL] ? silicaflux_nand_pkg::CS_DEV_FAIL : silicaflux_nand_pkg::CS_OK;
              j_info0 <= {16'd0, (j_op == silicaflux_nand_pkg::OP_PROGRAM_PAGE) ? j_len : 16'd0};
              bst <= silicaflux_nand_pkg::B_CEOFF;
            end
          end
        end
        silicaflux_nand_pkg::B_RESUME:   if (uop_done) bst <= silicaflux_nand_pkg::B_CRC_ADDR;
        silicaflux_nand_pkg::B_CRC_ADDR: if (uop_done) bst <= silicaflux_nand_pkg::B_CRC2;
        silicaflux_nand_pkg::B_CRC2:     if (uop_done) bst <= silicaflux_nand_pkg::B_CCS;
        silicaflux_nand_pkg::B_CCS:      if (uop_done) bst <= silicaflux_nand_pkg::B_DOUT_DATA;
        silicaflux_nand_pkg::B_DOUT_DATA: if (uop_done) begin
          bm_flush <= 1'b1;
          j_info0 <= {16'd0, j_len};
          if (bm_wr_err) j_cs <= silicaflux_nand_pkg::CS_BUF_ERR;
          bst <= silicaflux_nand_pkg::B_CEOFF;
        end
        silicaflux_nand_pkg::B_RR: if (uop_done) begin
          if (j_op == silicaflux_nand_pkg::OP_READ_PARAM) begin
            if (j_store) begin bm_wr_start <= 1'b1; j_wr <= 1'b1; end
            bst <= silicaflux_nand_pkg::B_DOUT_PRM;
          end else bst <= silicaflux_nand_pkg::B_DOUT_FEAT;
        end
        silicaflux_nand_pkg::B_DOUT_PRM: begin
          if (dout_valid) begin : b_pp
            logic [7:0] b;
            b = dout_data[7:0];
            if (j_pidx < 9'd254) j_crc <= silicaflux_nand_pkg::crc16_byte(j_crc, b);
            case (j_pidx[7:0])
              8'd0:   pp_sig[7:0]     <= b;  8'd1:   pp_sig[15:8]    <= b;
              8'd2:   pp_sig[23:16]   <= b;  8'd3:   pp_sig[31:24]   <= b;
              8'd6:   pp_feat[7:0]    <= b;  8'd7:   pp_feat[15:8]   <= b;
              8'd8:   pp_opt[7:0]     <= b;  8'd9:   pp_opt[15:8]    <= b;
              8'd80:  pp_page[7:0]    <= b;  8'd81:  pp_page[15:8]   <= b;
              8'd82:  pp_page[23:16]  <= b;  8'd83:  pp_page[31:24]  <= b;
              8'd84:  pp_oob[7:0]     <= b;  8'd85:  pp_oob[15:8]    <= b;
              8'd92:  pp_ppb[7:0]     <= b;  8'd93:  pp_ppb[15:8]    <= b;
              8'd94:  pp_ppb[23:16]   <= b;  8'd95:  pp_ppb[31:24]   <= b;
              8'd96:  pp_bpl[7:0]     <= b;  8'd97:  pp_bpl[15:8]    <= b;
              8'd98:  pp_bpl[23:16]   <= b;  8'd99:  pp_bpl[31:24]   <= b;
              8'd100: pp_luns         <= b;  8'd101: pp_acyc         <= b;
              8'd129: pp_tmodes[7:0]  <= b;  8'd130: pp_tmodes[15:8] <= b;
              8'd133: pp_tprog[7:0]   <= b;  8'd134: pp_tprog[15:8]  <= b;
              8'd135: pp_tbers[7:0]   <= b;  8'd136: pp_tbers[15:8]  <= b;
              8'd137: pp_tr[7:0]      <= b;  8'd138: pp_tr[15:8]     <= b;
              8'd139: pp_tccs[7:0]    <= b;  8'd140: pp_tccs[15:8]   <= b;
              8'd254: pp_crc[7:0]     <= b;  8'd255: pp_crc[15:8]    <= b;
              default: ;
            endcase
            j_pidx <= j_pidx + 9'd1;
          end
          if (uop_done) begin
            j_info0 <= pp_page;
            j_info1 <= {pp_luns, pp_acyc, 2'b00, j_copy, pp_sig_ok, pp_crc_ok, pp_sup,
                        pp_sig_ok && pp_crc_ok && pp_sup && c_auto_geo, pp_tmodes[7:0]};
            if (bm_wr_err) begin
              j_cs <= silicaflux_nand_pkg::CS_BUF_ERR; bst <= silicaflux_nand_pkg::B_CEOFF;
            end else if (pp_sig_ok && pp_crc_ok) begin
              j_cs <= pp_sup ? silicaflux_nand_pkg::CS_OK : silicaflux_nand_pkg::CS_UNSUPPORTED;
              bst <= silicaflux_nand_pkg::B_CEOFF;
            end else if (j_copy != 2'd2) begin
              j_copy <= j_copy + 2'd1;                 // next redundant copy follows on the bus
              j_pidx <= 9'd0;
              j_crc  <= 16'h4F4E;
              if (j_store) bm_wr_start <= 1'b1;
            end else begin
              j_cs <= silicaflux_nand_pkg::CS_PARAM_CRC; bst <= silicaflux_nand_pkg::B_CEOFF;
            end
          end
        end
        silicaflux_nand_pkg::B_DOUT_FEAT: begin
          if (dout_valid) begin
            for (int b = 0; b < 8; b++) if (j_idn[2:0] == 3'(b)) j_id[b*8 +: 8] <= dout_data[7:0];
            j_idn <= j_idn + 4'd1;
          end
          if (uop_done) begin
            j_info0 <= j_id[31:0];
            bst <= silicaflux_nand_pkg::B_CEOFF;
          end
        end
        silicaflux_nand_pkg::B_CEOFF: if (uop_done) begin
          bst <= j_wr ? silicaflux_nand_pkg::B_WDRAIN : silicaflux_nand_pkg::B_FIN;
        end
        silicaflux_nand_pkg::B_WDRAIN: begin
          if (bm_wr_idle) begin
            if (bm_wr_err) j_cs <= silicaflux_nand_pkg::CS_BUF_ERR;
            bst <= silicaflux_nand_pkg::B_FIN;
          end
        end
        silicaflux_nand_pkg::B_FIN: begin
          if (fin_cmpl || fin_wait) bst <= silicaflux_nand_pkg::B_IDLE;
        end
        default: bst <= silicaflux_nand_pkg::B_IDLE;
      endcase
    end
  end

  // =========================================================================
  // slot table, target / LUN state, configuration
  // =========================================================================
  wire j_is_tgt   = silicaflux_nand_pkg::op_is_tgt(j_op);
  wire fin_issue_wait = fin_wait && (jk == silicaflux_nand_pkg::J_ISSUE);
  wire fin_poll_miss  = fin_wait && (jk == silicaflux_nand_pkg::J_COMP);
  wire fin_comp_done  = fin_cmpl && (jk == silicaflux_nand_pkg::J_COMP);
  wire fin_tmo        = fin_cmpl && (jk == silicaflux_nand_pkg::J_TMO);
  wire csr_wr         = csr_sel && csr_we;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < QD; i++) begin
        s_st[i] <= silicaflux_nand_pkg::SL_FREE;
        s_older[i] <= '0;
        s_pt[i] <= 24'd0;
      end
      s_rbmiss <= '0;
      lun_busy <= '0; tgt_busy <= '0; reset_done <= '0; faulted <= '0; tr_v <= '0; tr_any <= '0;
      starve_cnt <= 4'd0;
    end else begin
      // ------------------------------------------------ poll timers
      for (int i = 0; i < QD; i++)
        if (s_pt[i] != 24'd0) s_pt[i] <= s_pt[i] - 24'd1;
      // ------------------------------------------------ accept
      if (accept) begin
        for (int i = 0; i < QD; i++) begin
          if (fr_oh[i]) begin
            s_st[i]    <= silicaflux_nand_pkg::SL_PEND;
            s_older[i] <= '0;
            s_rbmiss[i] <= 1'b0;
          end else begin
            for (int j = 0; j < QD; j++) if (fr_oh[j]) s_older[i][j] <= v_valid[i];
          end
        end
      end
      // ------------------------------------------------ arbitration bookkeeping
      if (pick_go && pk_k == silicaflux_nand_pkg::J_ISSUE) begin
        if (pk_bypass) begin
          if (starve_cnt != 4'hF) starve_cnt <= starve_cnt + 4'd1;
        end else if (!pk_rd) starve_cnt <= 4'd0;
      end
      // ------------------------------------------------ issue -> WAIT
      if (fin_issue_wait) begin
        for (int i = 0; i < QD; i++) if (QW'(i) == cur) begin
          s_st[i]     <= silicaflux_nand_pkg::SL_WAIT;
          s_rbmiss[i] <= 1'b0;
          case (j_op)
            silicaflux_nand_pkg::OP_READ_PAGE:      s_pt[i] <= poll_rd;
            silicaflux_nand_pkg::OP_PROGRAM_PAGE:   s_pt[i] <= poll_pg;
            silicaflux_nand_pkg::OP_ERASE_BLOCK:    s_pt[i] <= poll_er;
            default:                                s_pt[i] <= poll_iv;
          endcase
        end
        if (j_arr) begin
          lun_busy[j_li] <= 1'b1;
          if (j_op == silicaflux_nand_pkg::OP_ERASE_BLOCK) begin
            tr_v[j_li] <= 1'b1; tr_any[j_li] <= 1'b0;
          end else if (j_op == silicaflux_nand_pkg::OP_PROGRAM_PAGE) begin
            if (!(tr_v[j_li] && tr_blk[j_li] == j_blk && tr_any[j_li] && j_pg <= tr_hp[j_li])) begin
              tr_v[j_li] <= 1'b1; tr_any[j_li] <= 1'b1;
            end
          end
        end else begin
          tgt_busy[j_cei] <= 1'b1;
          if (j_op == silicaflux_nand_pkg::OP_RESET) begin
            reset_done[j_cei] <= 1'b0;
            for (int l = 0; l < NUM_LUN_MAX; l++) begin
              lun_busy[lidx(j_cei, 3'(l))] <= 1'b0;   // RESET aborts any operation in flight
              tr_v[lidx(j_cei, 3'(l))]     <= 1'b0;
            end
          end
        end
      end
      // ------------------------------------------------ poll miss
      if (fin_poll_miss) begin
        for (int i = 0; i < QD; i++) if (QW'(i) == cur) begin
          s_pt[i] <= poll_iv;
          if (j_hint) s_rbmiss[i] <= 1'b1;            // R/B# claimed ready but the LUN was busy
        end
      end
      // ------------------------------------------------ completion
      if (fin_cmpl) begin
        for (int i = 0; i < QD; i++) if (QW'(i) == cur) s_st[i] <= silicaflux_nand_pkg::SL_FREE;
      end
      if (fin_comp_done) begin
        if (j_arr) lun_busy[j_li] <= 1'b0;
        else begin
          tgt_busy[j_cei] <= 1'b0;
          if (j_op == silicaflux_nand_pkg::OP_RESET) begin
            reset_done[j_cei] <= (j_cs == silicaflux_nand_pkg::CS_OK);
            faulted[j_cei]    <= (j_cs != silicaflux_nand_pkg::CS_OK);
          end
        end
      end
      if (fin_tmo) begin
        faulted[j_cei] <= 1'b1;
        if (j_is_tgt) tgt_busy[j_cei] <= 1'b0;
      end
    end
  end

  // tracker block / page (data, no reset needed: qualified by tr_v)
  always_ff @(posedge clk) begin
    if (fin_issue_wait && j_arr) begin
      for (int l = 0; l < LT; l++) if (LTW'(l) == j_li) begin
        if (j_op == silicaflux_nand_pkg::OP_ERASE_BLOCK) begin
          tr_blk[l] <= j_blk;
          tr_hp[l]  <= 16'd0;
        end else if (j_op == silicaflux_nand_pkg::OP_PROGRAM_PAGE) begin
          if (tr_v[l] && tr_blk[l] == j_blk && tr_any[l]) begin
            if (j_pg > tr_hp[l]) tr_hp[l] <= j_pg;
          end else begin
            tr_blk[l] <= j_blk;
            tr_hp[l]  <= j_pg;
          end
        end
      end
    end
  end

  // slot payload (data, qualified by s_st)
  always_ff @(posedge clk) begin
    for (int i = 0; i < QD; i++) begin
      if (accept && fr_oh[i]) begin
        s_op[i]  <= req_op;    s_tag[i] <= req_tag;   s_ce[i]  <= req_ce;    s_lun[i] <= req_lun;
        s_blk[i] <= req_block; s_pg[i]  <= req_page;  s_col[i] <= req_col;   s_len[i] <= req_len;
        s_buf[i] <= req_buf;   s_fa[i]  <= req_faddr; s_fd[i]  <= req_fdata; s_tacc[i] <= now;
      end
      if (fin_issue_wait && QW'(i) == cur) s_tiss[i] <= now;
    end
  end

  // ------------------------------------------------ configuration registers
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      now        <= 32'd0;
      ctrl       <= CTRL_RST;
      tmode      <= 3'(TIMING_MODE_RST);
      tw         <= tw_of(3'(TIMING_MODE_RST));
      geo_page   <= 16'(DEF_PAGE_BYTES);
      geo_oob    <= 16'(DEF_OOB_BYTES);
      geo_ppb    <= 16'(DEF_PAGES_PER_BLOCK);
      geo_bpl    <= 24'(DEF_BLOCKS_PER_LUN);
      geo_luns   <= 8'(DEF_LUNS);
      geo_rowc   <= 4'(DEF_ROW_CYCLES);
      geo_colc   <= 4'(DEF_COL_CYCLES);
      geo_tmodes <= 16'h0001;
      geo_tr     <= 16'd0; geo_tprog <= 16'd0; geo_tbers <= 16'd0; geo_tccs <= 16'd0;
      geo_param  <= 1'b0;
      geo_feat   <= 16'd0; geo_opt <= 16'd0;
      tmo_rd     <= 32'(TMO_READ_US)  * 32'(CYC_US);
      tmo_pg     <= 32'(TMO_PROG_US)  * 32'(CYC_US);
      tmo_er     <= 32'(TMO_ERASE_US) * 32'(CYC_US);
      tmo_tgt    <= 32'(TMO_TGT_US)   * 32'(CYC_US);
      poll_rd    <= 24'(POLL_READ_US  * CYC_US);
      poll_pg    <= 24'(POLL_PROG_US  * CYC_US);
      poll_er    <= 24'(POLL_ERASE_US * CYC_US);
      poll_iv    <= 24'(POLL_IV_US    * CYC_US);
      err_sticky <= 5'd0;
    end else begin
      now <= now + 32'd1;
      // -------------------------------------------- automatic updates at completion
      if (fin_comp_done && j_op == silicaflux_nand_pkg::OP_READ_PARAM && j_cs == silicaflux_nand_pkg::CS_OK &&
          c_auto_geo) begin
        geo_page   <= pp_page[15:0];
        geo_oob    <= pp_oob;
        geo_ppb    <= pp_ppb[15:0];
        geo_bpl    <= pp_bpl[23:0];
        geo_luns   <= pp_luns;
        geo_rowc   <= pp_rowc;
        geo_colc   <= pp_colc;
        geo_tmodes <= pp_tmodes | 16'h0001;
        geo_tr     <= pp_tr;
        geo_tprog  <= pp_tprog;
        geo_tbers  <= pp_tbers;
        geo_tccs   <= pp_tccs;
        geo_param  <= 1'b1;
        geo_feat   <= pp_feat;
        geo_opt    <= pp_opt;
        ctrl[silicaflux_nand_pkg::CTRL_USE_ENH]   <= pp_opt[3];
        ctrl[silicaflux_nand_pkg::CTRL_MULTI_LUN] <= pp_feat[1] && pp_opt[3];
        if (c_auto_tmo) begin
          if (pp_tr    != 16'd0) tmo_rd <= (us2cyc(pp_tr)    << 2) + 32'd1000;
          if (pp_tprog != 16'd0) tmo_pg <= (us2cyc(pp_tprog) << 2) + 32'd1000;
          if (pp_tbers != 16'd0) tmo_er <= (us2cyc(pp_tbers) << 2) + 32'd1000;
        end
      end
      if (fin_comp_done && j_op == silicaflux_nand_pkg::OP_SET_FEATURES && c_auto_tim &&
          j_fa == silicaflux_nand_pkg::FA_TIMING_MODE) begin
        tmode <= j_fd[2:0];
        tw    <= tw_of(j_fd[2:0]);
      end
      // -------------------------------------------- sticky errors
      if (fin_cmpl) begin
        if (j_cs == silicaflux_nand_pkg::CS_TIMEOUT)  err_sticky[silicaflux_nand_pkg::ERR_TIMEOUT]  <= 1'b1;
        if (j_cs == silicaflux_nand_pkg::CS_DEV_FAIL) err_sticky[silicaflux_nand_pkg::ERR_DEV_FAIL] <= 1'b1;
        if (j_cs == silicaflux_nand_pkg::CS_BUF_ERR)  err_sticky[silicaflux_nand_pkg::ERR_BUF]      <= 1'b1;
        if (j_cs == silicaflux_nand_pkg::CS_PARAM_CRC || j_cs == silicaflux_nand_pkg::CS_UNSUPPORTED)
          err_sticky[silicaflux_nand_pkg::ERR_PARAM] <= 1'b1;
        if (j_cs >= silicaflux_nand_pkg::CS_BAD_OP && j_cs <= silicaflux_nand_pkg::CS_PROG_ORDER)
          err_sticky[silicaflux_nand_pkg::ERR_REJECT] <= 1'b1;
      end
      // -------------------------------------------- CSR writes
      if (csr_wr) begin
        case (csr_addr)
          silicaflux_nand_pkg::CSR_CTRL:    ctrl <= csr_wdata;
          silicaflux_nand_pkg::CSR_TMODE: begin
            tmode <= (csr_wdata[2:0] > 3'd5) ? 3'd5 : csr_wdata[2:0];
            tw    <= tw_of(csr_wdata[2:0]);
          end
          silicaflux_nand_pkg::CSR_TIM0:    tw[31:0]   <= csr_wdata;
          silicaflux_nand_pkg::CSR_TIM1:    tw[63:32]  <= csr_wdata;
          silicaflux_nand_pkg::CSR_TIM2:    tw[95:64]  <= csr_wdata;
          silicaflux_nand_pkg::CSR_TIM3:    tw[127:96] <= {24'd0, csr_wdata[7:0]};
          silicaflux_nand_pkg::CSR_GEO0: begin geo_page <= csr_wdata[15:0]; geo_oob <= csr_wdata[31:16]; end
          silicaflux_nand_pkg::CSR_GEO1:    geo_ppb <= csr_wdata[15:0];
          silicaflux_nand_pkg::CSR_GEO2:    geo_bpl <= csr_wdata[23:0];
          silicaflux_nand_pkg::CSR_GEO3: begin
            geo_luns <= csr_wdata[7:0]; geo_rowc <= csr_wdata[11:8]; geo_colc <= csr_wdata[15:12];
            geo_tmodes <= csr_wdata[31:16] | 16'h0001;
          end
          silicaflux_nand_pkg::CSR_TMO_RD:  tmo_rd  <= csr_wdata;
          silicaflux_nand_pkg::CSR_TMO_PG:  tmo_pg  <= csr_wdata;
          silicaflux_nand_pkg::CSR_TMO_ER:  tmo_er  <= csr_wdata;
          silicaflux_nand_pkg::CSR_TMO_TGT: tmo_tgt <= csr_wdata;
          silicaflux_nand_pkg::CSR_POLL_RD: poll_rd <= csr_wdata[23:0];
          silicaflux_nand_pkg::CSR_POLL_PG: poll_pg <= csr_wdata[23:0];
          silicaflux_nand_pkg::CSR_POLL_ER: poll_er <= csr_wdata[23:0];
          silicaflux_nand_pkg::CSR_POLL_IV: poll_iv <= (csr_wdata[23:0] == 24'd0) ? 24'd1 : csr_wdata[23:0];
          silicaflux_nand_pkg::CSR_ERR:     err_sticky <= err_sticky & ~csr_wdata[4:0];
          default: ;
        endcase
      end
    end
  end

  // =========================================================================
  // performance counters
  // =========================================================================
  localparam int NPC = silicaflux_nand_pkg::PC_NUM;
  logic [31:0] pc [0:NPC-1];
  wire pc_clr = csr_wr && csr_addr == silicaflux_nand_pkg::CSR_PERF_CTRL && csr_wdata[0];
  wire [31:0] lat_sum_rd = pc[silicaflux_nand_pkg::PC_LAT_RD_SUM];
  if (ENABLE_PERF != 0) begin : g_perf
    // events are registered first (counters lag by one cycle) so no datapath ends at a counter
    logic        e_busy, e_idle, e_data, e_array, e_rd_data, e_rd_prm, e_din, e_qstall, e_cstall;
    logic        e_fin, e_poll, e_miss;
    logic [3:0]  e_op, e_cs;
    logic [31:0] e_lat;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        e_busy <= 1'b0; e_idle <= 1'b0; e_data <= 1'b0; e_array <= 1'b0; e_rd_data <= 1'b0; e_rd_prm <= 1'b0;
        e_din <= 1'b0; e_qstall <= 1'b0; e_cstall <= 1'b0; e_fin <= 1'b0; e_poll <= 1'b0; e_miss <= 1'b0;
        e_op <= 4'd0; e_cs <= 4'd0; e_lat <= 32'd0;
      end else begin
        e_busy    <= (bst != silicaflux_nand_pkg::B_IDLE);
        e_idle    <= (bst == silicaflux_nand_pkg::B_IDLE);
        e_data    <= eng_beat;
        e_array   <= (|lun_busy) || (|tgt_busy);
        e_rd_data <= dout_valid && bst == silicaflux_nand_pkg::B_DOUT_DATA;
        e_rd_prm  <= dout_valid && bst == silicaflux_nand_pkg::B_DOUT_PRM;
        e_din     <= din_pop;
        e_qstall  <= req_valid && !req_ready;
        e_cstall  <= (bst == silicaflux_nand_pkg::B_FIN) && j_cmpl && !cq_in_ready;
        e_fin     <= fin_cmpl;
        e_op      <= j_op;
        e_cs      <= j_cs;
        e_lat     <= lat_now;
        e_poll    <= bst == silicaflux_nand_pkg::B_ST_RD && uop_done && jk == silicaflux_nand_pkg::J_COMP && j_arr;
        e_miss    <= bst == silicaflux_nand_pkg::B_ST_RD && uop_done && jk == silicaflux_nand_pkg::J_COMP && j_arr && !st_rdy;
      end
    end
    logic [31:0] inc [0:NPC-1];
    always_comb begin
      for (int p = 0; p < NPC; p++) inc[p] = 32'd0;
      inc[silicaflux_nand_pkg::PC_CYCLES]     = 32'd1;
      inc[silicaflux_nand_pkg::PC_BUS_BUSY]   = 32'(e_busy);
      inc[silicaflux_nand_pkg::PC_BUS_IDLE]   = 32'(e_idle);
      inc[silicaflux_nand_pkg::PC_BUS_DATA]   = 32'(e_data);
      inc[silicaflux_nand_pkg::PC_ARRAY_BUSY] = 32'(e_array);
      if (e_rd_data) inc[silicaflux_nand_pkg::PC_BYTES_RD] = 32'(UB);
      if (e_rd_prm)  inc[silicaflux_nand_pkg::PC_BYTES_RD] = 32'd1;
      if (e_din)     inc[silicaflux_nand_pkg::PC_BYTES_WR] = 32'(UB);
      inc[silicaflux_nand_pkg::PC_Q_STALL]    = 32'(e_qstall);
      inc[silicaflux_nand_pkg::PC_CPL_STALL]  = 32'(e_cstall);
      if (e_fin) begin
        case (e_op)
          silicaflux_nand_pkg::OP_READ_PAGE: begin
            inc[silicaflux_nand_pkg::PC_N_READ] = 32'd1; inc[silicaflux_nand_pkg::PC_LAT_RD_SUM] = e_lat;
          end
          silicaflux_nand_pkg::OP_PROGRAM_PAGE: begin
            inc[silicaflux_nand_pkg::PC_N_PROG] = 32'd1; inc[silicaflux_nand_pkg::PC_LAT_PG_SUM] = e_lat;
          end
          silicaflux_nand_pkg::OP_ERASE_BLOCK: begin
            inc[silicaflux_nand_pkg::PC_N_ERASE] = 32'd1; inc[silicaflux_nand_pkg::PC_LAT_ER_SUM] = e_lat;
          end
          default: inc[silicaflux_nand_pkg::PC_N_OTHER] = 32'd1;
        endcase
        if (e_cs == silicaflux_nand_pkg::CS_TIMEOUT) inc[silicaflux_nand_pkg::PC_N_TMO] = 32'd1;
        if (e_cs != silicaflux_nand_pkg::CS_OK)      inc[silicaflux_nand_pkg::PC_N_ERR] = 32'd1;
      end
      inc[silicaflux_nand_pkg::PC_N_POLL]      = 32'(e_poll);
      inc[silicaflux_nand_pkg::PC_N_POLL_MISS] = 32'(e_miss);
    end
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        for (int p = 0; p < NPC; p++) pc[p] <= 32'd0;
      end else if (pc_clr) begin
        for (int p = 0; p < NPC; p++) pc[p] <= 32'd0;
      end else begin
        for (int p = 0; p < NPC; p++)
          if (p != silicaflux_nand_pkg::PC_LAT_RD_MAX && p != silicaflux_nand_pkg::PC_LAT_PG_MAX &&
              p != silicaflux_nand_pkg::PC_LAT_ER_MAX)
            pc[p] <= pc[p] + inc[p];
        if (e_fin && e_op == silicaflux_nand_pkg::OP_READ_PAGE && e_lat > pc[silicaflux_nand_pkg::PC_LAT_RD_MAX])
          pc[silicaflux_nand_pkg::PC_LAT_RD_MAX] <= e_lat;
        if (e_fin && e_op == silicaflux_nand_pkg::OP_PROGRAM_PAGE && e_lat > pc[silicaflux_nand_pkg::PC_LAT_PG_MAX])
          pc[silicaflux_nand_pkg::PC_LAT_PG_MAX] <= e_lat;
        if (e_fin && e_op == silicaflux_nand_pkg::OP_ERASE_BLOCK && e_lat > pc[silicaflux_nand_pkg::PC_LAT_ER_MAX])
          pc[silicaflux_nand_pkg::PC_LAT_ER_MAX] <= e_lat;
      end
    end
  end else begin : g_noperf
    always_comb for (int p = 0; p < NPC; p++) pc[p] = 32'd0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_perf = ^{eng_beat, pc_clr};
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // =========================================================================
  // CSR read, status outputs
  // =========================================================================
  logic [7:0] slots_used;
  always_comb begin
    slots_used = 8'd0;
    for (int i = 0; i < QD; i++) slots_used = slots_used + 8'(v_valid[i]);
  end

  logic [7:0] rb_vec;
  always_comb begin
    rb_vec = 8'd0;
    for (int c = 0; c < NUM_CE; c++) rb_vec[c] = rb_of(rb_ce, CEW'(c));
  end

  always_comb begin : b_csr
    logic [7:0] pidx;
    csr_rdata = 32'd0;
    csr_err   = 1'b0;
    pidx      = (csr_addr - silicaflux_nand_pkg::CSR_PERF_BASE) >> 2;
    case (csr_addr)
      silicaflux_nand_pkg::CSR_ID:      csr_rdata = silicaflux_nand_pkg::SFNC_MAGIC;
      silicaflux_nand_pkg::CSR_VERSION: csr_rdata = {silicaflux_nand_pkg::SFNC_VERSION, 8'(DQ_WIDTH), 8'(NUM_CE)};
      silicaflux_nand_pkg::CSR_CONFIG:  csr_rdata = {8'(QUEUE_DEPTH), 8'(NUM_LUN_MAX), 8'(TAG_W), 7'(WB), 1'(RB_SHARED != 0)};
      silicaflux_nand_pkg::CSR_CTRL:    csr_rdata = ctrl;
      silicaflux_nand_pkg::CSR_STATUS:  csr_rdata = {3'd0, bst, 8'(cq_level), slots_used, 1'b0, tmode,
                                                     c_wp_n, geo_param, cpl_valid, busy};
      silicaflux_nand_pkg::CSR_TMODE:   csr_rdata = {29'd0, tmode};
      silicaflux_nand_pkg::CSR_TIM0:    csr_rdata = tw[31:0];
      silicaflux_nand_pkg::CSR_TIM1:    csr_rdata = tw[63:32];
      silicaflux_nand_pkg::CSR_TIM2:    csr_rdata = tw[95:64];
      silicaflux_nand_pkg::CSR_TIM3:    csr_rdata = tw[127:96];
      silicaflux_nand_pkg::CSR_GEO0:    csr_rdata = {geo_oob, geo_page};
      silicaflux_nand_pkg::CSR_GEO1:    csr_rdata = {16'd0, geo_ppb};
      silicaflux_nand_pkg::CSR_GEO2:    csr_rdata = {8'd0, geo_bpl};
      silicaflux_nand_pkg::CSR_GEO3:    csr_rdata = {geo_tmodes, geo_colc, geo_rowc, geo_luns};
      silicaflux_nand_pkg::CSR_GEO4:    csr_rdata = {geo_tccs, geo_tr};
      silicaflux_nand_pkg::CSR_GEO5:    csr_rdata = {geo_tbers, geo_tprog};
      silicaflux_nand_pkg::CSR_GEO6:    csr_rdata = {geo_opt, geo_feat};
      silicaflux_nand_pkg::CSR_TMO_RD:  csr_rdata = tmo_rd;
      silicaflux_nand_pkg::CSR_TMO_PG:  csr_rdata = tmo_pg;
      silicaflux_nand_pkg::CSR_TMO_ER:  csr_rdata = tmo_er;
      silicaflux_nand_pkg::CSR_TMO_TGT: csr_rdata = tmo_tgt;
      silicaflux_nand_pkg::CSR_POLL_RD: csr_rdata = {8'd0, poll_rd};
      silicaflux_nand_pkg::CSR_POLL_PG: csr_rdata = {8'd0, poll_pg};
      silicaflux_nand_pkg::CSR_POLL_ER: csr_rdata = {8'd0, poll_er};
      silicaflux_nand_pkg::CSR_POLL_IV: csr_rdata = {8'd0, poll_iv};
      silicaflux_nand_pkg::CSR_PERF_CTRL: csr_rdata = 32'd0;
      silicaflux_nand_pkg::CSR_ERR:     csr_rdata = {27'd0, err_sticky};
      silicaflux_nand_pkg::CSR_TGT:     csr_rdata = {8'(faulted), 8'(tgt_busy), 8'(reset_done),
                                                     rb_vec};
      default: begin
        if (csr_addr >= silicaflux_nand_pkg::CSR_PERF_BASE && csr_addr[1:0] == 2'b00 && pidx < 8'(NPC))
          csr_rdata = pc[pidx[4:0]];
        else csr_err = 1'b1;
      end
    endcase
    if (csr_we && (csr_addr == silicaflux_nand_pkg::CSR_ID || csr_addr == silicaflux_nand_pkg::CSR_VERSION ||
                   csr_addr == silicaflux_nand_pkg::CSR_CONFIG || csr_addr == silicaflux_nand_pkg::CSR_STATUS ||
                   csr_addr == silicaflux_nand_pkg::CSR_GEO4 || csr_addr == silicaflux_nand_pkg::CSR_GEO5 ||
                   csr_addr == silicaflux_nand_pkg::CSR_GEO6 ||
                   csr_addr == silicaflux_nand_pkg::CSR_TGT || csr_addr >= silicaflux_nand_pkg::CSR_PERF_BASE &&
                   csr_addr < silicaflux_nand_pkg::CSR_ERR))
      csr_err = 1'b1;
  end

  assign busy = (|v_valid) || (bst != silicaflux_nand_pkg::B_IDLE) || eng_active;
  assign irq  = cpl_valid && c_irq;

  // =========================================================================
  // elaboration checks
  // =========================================================================
  if (DQ_WIDTH != 8 && DQ_WIDTH != 16) begin : g_bad_dqw
    $error("silicaflux_nand_controller: DQ_WIDTH must be 8 or 16");
  end
  if (BUF_DW != 32 && BUF_DW != 64) begin : g_bad_dw
    $error("silicaflux_nand_controller: BUF_DW must be 32 or 64");
  end
  if (NUM_CE < 1 || NUM_CE > 8) begin : g_bad_ce
    $error("silicaflux_nand_controller: NUM_CE must be 1..8");
  end
  if (NUM_LUN_MAX < 1 || NUM_LUN_MAX > 8) begin : g_bad_lun
    $error("silicaflux_nand_controller: NUM_LUN_MAX must be 1..8");
  end
  if (QUEUE_DEPTH < 2 || QUEUE_DEPTH > 16) begin : g_bad_qd
    $error("silicaflux_nand_controller: QUEUE_DEPTH must be 2..16");
  end
  if ((CPL_DEPTH & (CPL_DEPTH - 1)) != 0 || CPL_DEPTH < 2) begin : g_bad_cq
    $error("silicaflux_nand_controller: CPL_DEPTH must be a power of two >= 2");
  end

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = ^{lat_sum_rd, j_miss, pp_tr[0]};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
