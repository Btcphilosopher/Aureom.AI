// =============================================================================
// sfnc_sync.sv -- SilicaFlux FlashLink, Project 53
// N-flop level synchroniser for the asynchronous R/B# input. Technology rule:
// replace the body with the library's characterised synchroniser cell
// (dont_touch) in an ASIC flow.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfnc_sync #(
  parameter int STAGES    = 2,
  parameter bit RESET_VAL = 1'b0
) (
  input  wire logic clk,
  input  wire logic rst_n,
  input  wire logic d,
  output logic      q
);
  logic [STAGES-1:0] s;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) s <= {STAGES{RESET_VAL}};
    else        s <= {s[STAGES-2:0], d};
  end
  assign q = s[STAGES-1];
endmodule

`default_nettype wire
