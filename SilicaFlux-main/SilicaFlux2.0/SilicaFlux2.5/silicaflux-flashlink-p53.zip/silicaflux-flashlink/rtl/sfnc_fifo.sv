// =============================================================================
// sfnc_fifo.sv -- SilicaFlux FlashLink, Project 53
// Flop-based synchronous FIFO, power-of-two depth, valid/ready on both sides.
// Storage flops are not reset (qualified by the pointers).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfnc_fifo #(
  parameter int W     = 8,
  parameter int DEPTH = 4,                 // power of two, >= 2
  localparam int AW   = $clog2(DEPTH)
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         clr,           // synchronous flush
  input  wire logic         in_valid,
  output logic              in_ready,
  input  wire logic [W-1:0] in_data,
  output logic              out_valid,
  input  wire logic         out_ready,
  output logic [W-1:0]      out_data,
  output logic [AW:0]       level
);
  logic [W-1:0] mem [0:DEPTH-1];
  logic [AW:0]  wp, rp;
  wire push = in_valid && in_ready;
  wire pop  = out_valid && out_ready;
  assign level     = wp - rp;
  assign in_ready  = (level != (AW+1)'(DEPTH));
  assign out_valid = (level != '0);
  assign out_data  = mem[rp[AW-1:0]];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0;
      rp <= '0;
    end else if (clr) begin
      wp <= '0;
      rp <= '0;
    end else begin
      if (push) wp <= wp + (AW+1)'(1);
      if (pop)  rp <= rp + (AW+1)'(1);
    end
  end
  always_ff @(posedge clk) begin
    if (push && !clr) mem[wp[AW-1:0]] <= in_data;
  end
endmodule

`default_nettype wire
