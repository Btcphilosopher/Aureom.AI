// =============================================================================
// sfnc_buf_master.sv -- SilicaFlux FlashLink, Project 53
// -----------------------------------------------------------------------------
// Buffer side of the data-transfer engine: an SFB2 master (DataFabric
// PROTOCOL.md rev 2.0) that moves page data between the buffer SRAM and the
// NAND bus.
//
//   reader  (PROGRAM): rd_start{addr, units} -> single-beat SFB2 reads of the
//           DW-aligned words that cover units*DQW/8 bytes -> word FIFO ->
//           serializer -> din stream (one DQW-bit unit per NAND write cycle).
//   writer  (READ_PAGE / READ_PARAM): dout units -> packer -> {addr, data,
//           strobes} FIFO -> SFB2 writes. wr_flush pushes a partial last word
//           with partial byte strobes. wr_idle = everything written (R7: the
//           response of a write arrives after the write was performed).
//
// SFB2 rules honoured: request held stable until accepted (registered request,
// R2), req_valid independent of req_ready (R3), rsp_ready = 1 (R4), one
// outstanding transaction (R6 when connected directly to a slave), DW-aligned
// addresses (R9), single-beat transfers with byte strobes (R10). rsp_error
// sets rd_err / wr_err (sticky until err_clr); the reader stops issuing.
// Byte order is little-endian: unit u of a word sits in bits [u*DQW +: DQW].
// The sequencer starts a new transfer only when quiet = 1.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfnc_buf_master #(
  parameter int DQW   = 8,
  parameter int DW    = 32,
  parameter int RFIFO = 4,
  parameter int WFIFO = 4,
  localparam int WB   = DW / 8,
  localparam int OFF  = $clog2(WB),
  localparam int UPW  = DW / DQW,
  localparam int UIW  = (UPW > 1) ? $clog2(UPW) : 1,
  localparam int UB   = DQW / 8
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           err_clr,
  // reader: buffer -> NAND
  input  wire logic           rd_start,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]    rd_addr,           // [OFF-1:0] ignored: DW-aligned (checked by the controller)
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [15:0]    rd_units,
  output logic                rd_err,
  output logic                din_valid,
  output logic [DQW-1:0]      din_data,
  input  wire logic           din_pop,
  // writer: NAND -> buffer
  input  wire logic           wr_start,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]    wr_addr,           // [OFF-1:0] ignored: DW-aligned
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic           wr_en,
  input  wire logic           wr_flush,
  output logic                wr_idle,
  output logic                wr_err,
  input  wire logic           dout_valid,
  input  wire logic [DQW-1:0] dout_data,
  output logic                dout_space,
  output logic                quiet,
  // SFB2 master
  output logic                m_req_valid,
  input  wire logic           m_req_ready,
  output logic                m_req_write,
  output logic [31:0]         m_req_addr,
  output logic [DW-1:0]       m_req_wdata,
  output logic [WB-1:0]       m_req_wstrb,
  input  wire logic           m_rsp_valid,
  output logic                m_rsp_ready,
  input  wire logic [DW-1:0]  m_rsp_rdata,
  input  wire logic           m_rsp_error
);
  localparam int RAW = $clog2(RFIFO);
  localparam int WAW = $clog2(WFIFO);
  localparam int WEW = 32 + DW + WB;

  // ---------------------------------------------------------------- request port
  logic          req_q, out_q, out_rd;
  assign m_req_valid = req_q;
  assign m_rsp_ready = 1'b1;
  wire req_acc = req_q && m_req_ready;
  wire rsp_acc = m_rsp_valid;            // rsp_ready = 1

  // ---------------------------------------------------------------- reader
  logic [31:0]   r_addr;
  logic [17:0]   r_words;                // words still to request
  logic [15:0]   r_units;                // units still to deliver
  logic [RAW:0]  r_infl;                 // FIFO slots reserved (queued + outstanding)
  logic          rf_in_valid, rf_out_valid, rf_pop;
  logic [DW-1:0] rf_out;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [RAW:0]  rf_level;
  logic          rf_in_ready;
  logic [WAW:0]  wf_level;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [DW-1:0] cur_w;
  logic          cur_v;
  logic [UIW-1:0] cur_i;

  sfnc_fifo #(.W(DW), .DEPTH(RFIFO)) u_rf (
    .clk(clk), .rst_n(rst_n), .clr(rd_start),
    .in_valid(rf_in_valid), .in_ready(rf_in_ready), .in_data(m_rsp_rdata),
    .out_valid(rf_out_valid), .out_ready(rf_pop), .out_data(rf_out), .level(rf_level));
  assign rf_in_valid = rsp_acc && out_rd && !m_rsp_error;

  wire last_unit_of_word = (cur_i == UIW'(UPW - 1));
  assign din_valid = cur_v && (r_units != 16'd0);
  always_comb begin                        // unit select (equality decode, no shifter)
    din_data = cur_w[DQW-1:0];
    for (int u = 0; u < UPW; u++) if (cur_i == UIW'(u)) din_data = cur_w[u*DQW +: DQW];
  end
  wire cur_free    = !cur_v || (din_pop && last_unit_of_word);
  assign rf_pop    = cur_free && rf_out_valid && !rd_start;

  // total words = ceil(units * UB / WB)
  wire [17:0] rd_bytes = 18'(rd_units) * 18'(UB);
  wire [17:0] rd_wcnt  = (rd_bytes + 18'(WB - 1)) >> OFF;

  // ---------------------------------------------------------------- writer
  logic [DW-1:0] p_word;
  logic [WB-1:0] p_strb;
  logic [UIW-1:0] p_idx;
  logic [31:0]   p_addr;
  logic          p_any;                  // packer holds at least one unit
  logic          flush_pend;
  logic          wf_in_valid, wf_in_ready, wf_out_valid, wf_pop;
  logic [WEW-1:0] wf_in, wf_out;

  sfnc_fifo #(.W(WEW), .DEPTH(WFIFO)) u_wf (
    .clk(clk), .rst_n(rst_n), .clr(1'b0),
    .in_valid(wf_in_valid), .in_ready(wf_in_ready), .in_data(wf_in),
    .out_valid(wf_out_valid), .out_ready(wf_pop), .out_data(wf_out), .level(wf_level));

  wire take_unit = dout_valid && wr_en;
  wire word_full = take_unit && (p_idx == UIW'(UPW - 1));
  // unit lane strobes
  logic [DW-1:0] word_next;
  logic [WB-1:0] strb_next;
  always_comb begin
    word_next = p_word;
    strb_next = p_strb;
    if (take_unit) begin
      for (int u = 0; u < UPW; u++)
        if (p_idx == UIW'(u)) begin
          word_next[u*DQW +: DQW] = dout_data;
          strb_next[u*UB +: UB]   = {UB{1'b1}};
        end
    end
  end
  wire do_flush = (flush_pend || wr_flush) && p_any && !take_unit;
  logic p_any_n;                         // packer occupancy after this cycle
  always_comb begin
    p_any_n = p_any;
    if (take_unit) p_any_n = !word_full;
    if (do_flush && wf_in_ready) p_any_n = 1'b0;
    if (wr_start) p_any_n = 1'b0;
  end
  assign wf_in_valid = word_full || (do_flush && wf_in_ready);
  assign wf_in       = {p_addr, word_next, strb_next};
  assign dout_space  = !wr_en || wf_in_ready;

  // ---------------------------------------------------------------- arbitration / request register
  wire w_have = wf_out_valid;
  wire r_have = (r_words != 18'd0) && !rd_err && (r_infl != (RAW+1)'(RFIFO));
  wire issue  = !req_q && !out_q && (w_have || r_have);
  assign wf_pop = issue && w_have;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      req_q <= 1'b0; out_q <= 1'b0; out_rd <= 1'b0;
      m_req_write <= 1'b0; m_req_addr <= 32'd0; m_req_wdata <= '0; m_req_wstrb <= '0;
      r_addr <= 32'd0; r_words <= 18'd0; r_units <= 16'd0; r_infl <= '0;
      cur_w <= '0; cur_v <= 1'b0; cur_i <= '0;
      p_word <= '0; p_strb <= '0; p_idx <= '0; p_addr <= 32'd0; p_any <= 1'b0; flush_pend <= 1'b0;
      rd_err <= 1'b0; wr_err <= 1'b0;
    end else begin
      // -------------------------------------------- request register
      if (issue) begin
        req_q <= 1'b1;
        if (w_have) begin
          m_req_write <= 1'b1;
          m_req_addr  <= wf_out[WEW-1 -: 32];
          m_req_wdata <= wf_out[WB +: DW];
          m_req_wstrb <= wf_out[WB-1:0];
          out_rd      <= 1'b0;
        end else begin
          m_req_write <= 1'b0;
          m_req_addr  <= r_addr;
          m_req_wdata <= '0;
          m_req_wstrb <= '0;
          out_rd      <= 1'b1;
          r_addr      <= r_addr + 32'(WB);
          r_words     <= r_words - 18'd1;
        end
      end
      if (req_acc) begin
        req_q <= 1'b0;
        out_q <= 1'b1;
      end
      if (rsp_acc && out_q) begin
        out_q <= 1'b0;
        if (m_rsp_error) begin
          if (out_rd) begin
            rd_err  <= 1'b1;
            r_words <= 18'd0;                // stop fetching
          end else wr_err <= 1'b1;
        end
      end
      // -------------------------------------------- reader credits / serializer
      begin : rd_credit
        logic inc, dec, dec2;
        inc  = issue && !w_have;
        dec  = rf_pop;
        dec2 = rsp_acc && out_q && out_rd && m_rsp_error;   // reserved slot never filled
        r_infl <= r_infl + (RAW+1)'(inc) - (RAW+1)'(dec) - (RAW+1)'(dec2);
      end
      if (din_pop) begin
        r_units <= r_units - 16'd1;
        cur_i   <= cur_i + UIW'(1);
        if (last_unit_of_word) cur_v <= 1'b0;
      end
      if (rf_pop) begin
        cur_w <= rf_out;
        cur_v <= 1'b1;
        cur_i <= '0;
      end
      if (rd_start) begin
        r_addr  <= {rd_addr[31:OFF], {OFF{1'b0}}};
        r_words <= rd_wcnt;
        r_units <= rd_units;
        r_infl  <= '0;
        cur_v   <= 1'b0;
        cur_i   <= '0;
      end
      // -------------------------------------------- packer
      if (take_unit) begin
        p_any <= 1'b1;
        if (word_full) begin
          p_word <= '0;
          p_strb <= '0;
          p_idx  <= '0;
          p_addr <= p_addr + 32'(WB);
          p_any  <= 1'b0;
        end else begin
          p_word <= word_next;
          p_strb <= strb_next;
          p_idx  <= p_idx + UIW'(1);
        end
      end
      flush_pend <= (flush_pend || wr_flush) && p_any_n;
      if (do_flush && wf_in_ready) begin
        p_word <= '0;
        p_strb <= '0;
        p_idx  <= '0;
        p_addr <= p_addr + 32'(WB);
        p_any  <= 1'b0;
      end
      if (wr_start) begin
        p_addr <= {wr_addr[31:OFF], {OFF{1'b0}}};
        p_word <= '0;
        p_strb <= '0;
        p_idx  <= '0;
        p_any  <= 1'b0;
      end
      if (err_clr) begin
        rd_err <= 1'b0;
        wr_err <= 1'b0;
      end
    end
  end

  assign wr_idle = !wf_out_valid && !(req_q && m_req_write) && !(out_q && !out_rd) && !p_any && !flush_pend;
  assign quiet   = !req_q && !out_q;

endmodule

`default_nettype wire
