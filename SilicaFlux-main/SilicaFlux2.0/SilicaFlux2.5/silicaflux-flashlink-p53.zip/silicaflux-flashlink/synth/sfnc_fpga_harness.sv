// =============================================================================
// sfnc_fpga_harness.sv -- SilicaFlux FlashLink, Project 53 (implementation harness)
// -----------------------------------------------------------------------------
// Wraps silicaflux_nand_controller for FPGA place-and-route evaluation so that
// only the NAND pins and a narrow host register port reach device I/O:
//   * 8-bit host port (h_addr, h_wdata, h_we, h_rdata): request staging bytes,
//     submit, completion bytes + pop, CSR staging + go, buffer pointer + data.
//   * 4 KiB page buffer in block RAM behind an SFB2 slave (1-cycle response).
//   * NAND x8 pins with a bidirectional DQ (tri-state at the top level).
// Used ONLY to obtain utilisation / Fmax from Yosys + nextpnr. Not verified
// in simulation, not a product interface.
// Host map: 0x00..0x1F request staging bytes {op,tag,ce,lun,blk[3],pg[2],col[2],
//   len[2],buf[4],faddr,fdata[4]}, 0x20 submit, 0x30..0x5F completion bytes
//   (read), 0x60 pop, 0x70 CSR addr, 0x74..0x77 CSR data, 0x78 CSR go (bit0 we),
//   0x7C..0x7D buffer pointer, 0x7E buffer data (auto-increment).
// Classification: SYNTHESIZABLE (evaluation harness)
// =============================================================================
`default_nettype none

module sfnc_fpga_harness (
  input  wire logic       clk,
  input  wire logic       rst_n,
  input  wire logic [7:0] h_addr_i,
  input  wire logic [7:0] h_wdata_i,
  input  wire logic       h_we_i,
  output logic [7:0]      h_rdata,
  output logic            irq,
  output logic            nand_ce_n,
  output logic            nand_cle,
  output logic            nand_ale,
  output logic            nand_we_n,
  output logic            nand_re_n,
  output logic            nand_wp_n,
  inout  wire  [7:0]      nand_dq,
  input  wire logic       nand_rb_n
);
  // ------------------------------------------------------------ input registers (host port)
  logic [7:0] h_addr, h_wdata;
  logic       h_we;
  always_ff @(posedge clk) begin
    h_addr  <= h_addr_i;
    h_wdata <= h_wdata_i;
    h_we    <= h_we_i;
  end

  // ------------------------------------------------------------ reset sync
  logic [1:0] rs;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rs <= 2'b00;
    else        rs <= {rs[0], 1'b1};
  end
  wire srst_n = rs[1];

  // ------------------------------------------------------------ host registers
  logic [7:0]  stg [0:31];
  logic [31:0] csr_d;
  logic [7:0]  csr_a;
  logic        csr_go, csr_w;
  logic [11:0] bptr;
  logic        submit_q, pop_q;
  always_ff @(posedge clk or negedge srst_n) begin
    if (!srst_n) begin
      for (int i = 0; i < 32; i++) stg[i] <= 8'd0;
      csr_d <= 32'd0; csr_a <= 8'd0; csr_go <= 1'b0; csr_w <= 1'b0; bptr <= 12'd0; submit_q <= 1'b0; pop_q <= 1'b0;
    end else begin
      csr_go <= 1'b0;
      pop_q  <= 1'b0;
      if (submit_q && req_ready) submit_q <= 1'b0;
      if (h_we) begin
        for (int i = 0; i < 32; i++) if (h_addr == 8'(i)) stg[i] <= h_wdata;
        for (int i = 0; i < 4; i++)  if (h_addr == 8'h74 + 8'(i)) csr_d[i*8 +: 8] <= h_wdata;
        case (h_addr)
          8'h20: submit_q <= 1'b1;
          8'h60: pop_q <= 1'b1;
          8'h70: csr_a <= h_wdata;
          8'h78: begin csr_go <= 1'b1; csr_w <= h_wdata[0]; end
          8'h7C: bptr[7:0] <= h_wdata;
          8'h7D: bptr[11:8] <= h_wdata[3:0];
          8'h7E: bptr <= bptr + 12'd1;
          default: ;
        endcase
      end
    end
  end

  // ------------------------------------------------------------ controller
  logic        req_ready, cpl_valid, csr_err;
  logic [7:0]  cpl_tag, cpl_nst;
  logic [3:0]  cpl_op, cpl_status;
  logic [2:0]  cpl_ce, cpl_lun;
  logic [31:0] cpl_i0, cpl_i1, cpl_lat, cpl_dev, csr_rdata;
  logic        m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] m_req_addr;                 // 4 KiB buffer: bits [11:2] used
  /* verilator lint_on UNUSEDSIGNAL */
  logic [31:0] m_req_wdata, m_rsp_rdata;
  logic [3:0]  m_req_wstrb;
  logic        dq_oe, busy;
  logic [7:0]  dq_o;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [2:0]  tmode;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_nand_controller #(.NUM_CE(1), .QUEUE_DEPTH(4), .CPL_DEPTH(4), .CLK_PERIOD_PS(10000)) u_ctrl (
    .clk(clk), .rst_n(srst_n),
    .req_valid(submit_q), .req_ready(req_ready), .req_op(stg[0][3:0]), .req_tag(stg[1]), .req_ce(stg[2][2:0]),
    .req_lun(stg[3][2:0]), .req_block({stg[6], stg[5], stg[4]}), .req_page({stg[8], stg[7]}),
    .req_col({stg[10], stg[9]}), .req_len({stg[12], stg[11]}), .req_buf({stg[16], stg[15], stg[14], stg[13]}),
    .req_faddr(stg[17]), .req_fdata({stg[21], stg[20], stg[19], stg[18]}),
    .cpl_valid(cpl_valid), .cpl_ready(pop_q), .cpl_tag(cpl_tag), .cpl_op(cpl_op), .cpl_status(cpl_status),
    .cpl_nand_status(cpl_nst), .cpl_ce(cpl_ce), .cpl_lun(cpl_lun), .cpl_info0(cpl_i0), .cpl_info1(cpl_i1),
    .cpl_latency(cpl_lat), .cpl_dev_time(cpl_dev),
    .csr_sel(csr_go), .csr_we(csr_w), .csr_addr(csr_a), .csr_wdata(csr_d), .csr_rdata(csr_rdata), .csr_err(csr_err),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready),
    .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .nand_ce_n(nand_ce_n), .nand_cle(nand_cle), .nand_ale(nand_ale), .nand_we_n(nand_we_n), .nand_re_n(nand_re_n),
    .nand_wp_n(nand_wp_n), .nand_dq_o(dq_o), .nand_dq_oe(dq_oe), .nand_dq_i(nand_dq), .nand_rb_n(nand_rb_n),
    .irq(irq), .busy(busy), .timing_mode(tmode));

  assign nand_dq = dq_oe ? dq_o : 8'hzz;

  // ------------------------------------------------------------ 4 KiB buffer (BRAM), SFB2 slave + host port
  logic [31:0] mem [0:1023];
  logic        rsp_q;
  logic [31:0] rd_q, hrd_q;
  wire         h_bw  = h_we && h_addr == 8'h7E;                       // host byte write wins the port
  assign m_req_ready = (!rsp_q || m_rsp_ready) && !h_bw;
  wire         acc   = m_req_valid && m_req_ready;
  wire         wen   = h_bw || (acc && m_req_write);
  wire  [9:0]  waddr = h_bw ? bptr[11:2] : m_req_addr[11:2];
  wire  [31:0] wdat  = h_bw ? {4{h_wdata}} : m_req_wdata;
  wire  [3:0]  wstb  = h_bw ? (4'b0001 << bptr[1:0]) : m_req_wstrb;
  always_ff @(posedge clk) begin
    for (int b = 0; b < 4; b++)
      if (wen && wstb[b]) mem[waddr][b*8 +: 8] <= wdat[b*8 +: 8];
    if (acc) rd_q <= mem[m_req_addr[11:2]];
    hrd_q <= mem[bptr[11:2]];
  end
  always_ff @(posedge clk or negedge srst_n) begin
    if (!srst_n) rsp_q <= 1'b0;
    else if (acc) rsp_q <= 1'b1;
    else if (m_rsp_ready) rsp_q <= 1'b0;
  end
  assign m_rsp_valid = rsp_q;
  assign m_rsp_rdata = rd_q;
  assign m_rsp_error = 1'b0;

  // ------------------------------------------------------------ host read mux (registered)
  logic [31:0] csr_rd_q;                       // CSR read data captured one cycle after the access
  logic        csr_err_q;
  always_ff @(posedge clk) begin
    csr_rd_q  <= csr_rdata;
    csr_err_q <= csr_err;
  end
  wire [159:0] cpl_flat = {cpl_dev, cpl_lat, cpl_i1, cpl_i0, 2'b00, cpl_lun, cpl_ce, cpl_nst, cpl_status, cpl_op, cpl_tag};
  always_ff @(posedge clk) begin
    h_rdata <= 8'd0;
    for (int i = 0; i < 32; i++) if (h_addr == 8'(i)) h_rdata <= stg[i];
    for (int i = 0; i < 20; i++) if (h_addr == 8'h30 + 8'(i)) h_rdata <= cpl_flat[i*8 +: 8];
    for (int i = 0; i < 4; i++)  if (h_addr == 8'h74 + 8'(i)) h_rdata <= csr_rd_q[i*8 +: 8];
    for (int i = 0; i < 4; i++)  if (h_addr == 8'h7E && bptr[1:0] == 2'(i)) h_rdata <= hrd_q[i*8 +: 8];
    if (h_addr == 8'h21) h_rdata <= {4'd0, busy, csr_err_q, cpl_valid, req_ready};
  end
endmodule

`default_nettype wire
