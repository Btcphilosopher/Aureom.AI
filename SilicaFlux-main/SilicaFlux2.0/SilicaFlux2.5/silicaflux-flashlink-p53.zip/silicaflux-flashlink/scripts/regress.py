#!/usr/bin/env python3
"""SilicaFlux FlashLink (Project 53) regression runner.

Builds every configuration on Verilator and/or Icarus Verilog, runs it in a fresh
NANDLab store directory (run/<sim>_<name>/), parses the testbench result file and
writes reports/regression.json and reports/regression.md.

    python3 scripts/regress.py --sim both
    python3 scripts/regress.py --sim verilator --only ce2
"""
import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = [l.strip() for l in open(os.path.join(ROOT, 'rtl', 'files.f')) if l.strip()]
COMMON = RTL + ['rtl/sfnc_io_sdr.sv', 'tb/models/nand_flash_model.sv', 'tb/sfnc_sfb_mem.sv', 'tb/sfnc_onfi_monitor.sv']
SVCFG = 'config/nandlab_regress.svcfg'

# name, top, extra sources, parameters, plusargs, description
CONFIGS = [
    ('base', 'tb_flashlink', ['tb/tb_flashlink.sv'], {}, ['+TEST=suite'],
     '1 channel, 1 target (2 LUNs), per-CE R/B#, 100 MHz, 4 request slots: full protocol suite'),
    ('negative', 'tb_flashlink', ['tb/tb_flashlink.sv'], {}, ['+TEST=negative', '+MON_QUIET'],
     'deliberately mis-programmed tWP/tWH/tRP/tREH: model and monitor must report violations'),
    ('ce2', 'tb_flashlink', ['tb/tb_flashlink.sv'], {'NUM_CE': 2}, ['+TEST=suite'],
     '2 targets (CE#) on one channel, per-CE R/B#: isolation, cross-target concurrency, starvation bound'),
    ('ce2_rbshared', 'tb_flashlink', ['tb/tb_flashlink.sv'], {'NUM_CE': 2, 'RB_SHARED': 1}, ['+TEST=suite'],
     '2 targets sharing one wired-AND R/B# line (completion by READ STATUS ENHANCED polling)'),
    ('clk200_q8', 'tb_flashlink', ['tb/tb_flashlink.sv'], {'CLK_PS': 5000, 'QD': 8}, ['+TEST=suite'],
     '200 MHz controller clock (timing conversion), 8 request slots'),
    ('clk50', 'tb_flashlink', ['tb/tb_flashlink.sv'], {'CLK_PS': 20000}, ['+TEST=suite'],
     '50 MHz controller clock (coarse cycle quantisation)'),
    ('multichannel', 'tb_multichannel', ['tb/tb_multichannel.sv', 'rtl/silicaflux_nand_multichannel.sv'], {}, [],
     '2 channels x 1 target: concurrency, completion merge, per-channel CSRs, bad channel'),
]


def tool_version(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True).stdout.strip().splitlines()[0]
    except Exception:
        return 'not available'


def build(sim, name, top, srcs, params):
    bdir = os.path.join(ROOT, 'build', f'{sim}_{name}')
    os.makedirs(bdir, exist_ok=True)
    files = COMMON + srcs
    if sim == 'verilator':
        cmd = ['verilator', '--binary', '--timing', '--build-jobs', '4', '--verilate-jobs', '1', '-Wno-fatal', '-Wno-lint', '-Wno-style',
               '-Wno-MULTIDRIVEN', '-Wno-TIMESCALEMOD', '--top-module', top, '-Mdir', os.path.join(bdir, 'obj'),
               '-o', 'sim'] + [f'-G{k}={v}' for k, v in params.items()] + files
        exe = [os.path.join(bdir, 'obj', 'sim')]
    else:
        out = os.path.join(bdir, 'sim.vvp')
        cmd = ['iverilog', '-g2012', '-s', top, '-o', out] + [f'-P{top}.{k}={v}' for k, v in params.items()] + files
        exe = ['vvp', '-n', out]
    t0 = time.time()
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    log = r.stdout + r.stderr
    with open(os.path.join(bdir, 'build.log'), 'w') as f:
        f.write(' '.join(cmd) + '\n' + log)
    return r.returncode == 0, exe, time.time() - t0


def run(sim, name, exe, plusargs, timeout):
    rdir = os.path.join(ROOT, 'run', f'{sim}_{name}')
    shutil.rmtree(rdir, ignore_errors=True)
    os.makedirs(rdir)
    shutil.copy(os.path.join(ROOT, SVCFG), os.path.join(rdir, 'nandlab.svcfg'))
    res = os.path.join(rdir, 'result.txt')
    cmd = exe + [f'+NANDLAB_DIR={rdir}', '+NANDLAB_QUIET', f'+RESULT={res}', f'+MON_LOG={rdir}/bus.log'] + plusargs
    t0 = time.time()
    try:
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b'').decode(errors='replace') if isinstance(e.stdout, bytes) else (e.stdout or '')
        out += '\nTIMEOUT'
    wall = time.time() - t0
    with open(os.path.join(rdir, 'sim.log'), 'w') as f:
        f.write(out)
    info = {'wall_s': round(wall, 1), 'pass': 0, 'fail': 0, 'checks': [], 'monitor': [], 'perf': [], 'sim_time_ns': None}
    if os.path.exists(res):
        for line in open(res):
            line = line.rstrip()
            if line.startswith('CHECK PASS'):
                info['pass'] += 1
            elif line.startswith('CHECK FAIL'):
                info['fail'] += 1
                info['checks'].append(line[11:])
            elif line.startswith('MONITOR'):
                info['monitor'].append(line)
            elif line.startswith('PERF'):
                info['perf'].append(line)
            elif line.startswith('MODEL'):
                m = re.search(r'sim_time_ns (\d+)', line)
                if m:
                    info['sim_time_ns'] = int(m.group(1))
            elif line.startswith('SUMMARY'):
                info['summary'] = line
    if 'summary' not in info:
        info['fail'] += 1
        info['checks'].append('no SUMMARY line (simulation did not finish)')
    return info


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sim', default='verilator', choices=['verilator', 'icarus', 'both'])
    ap.add_argument('--only', default=None)
    ap.add_argument('--timeout', type=int, default=3600)
    ap.add_argument('--out', default=os.path.join(ROOT, 'reports'))
    a = ap.parse_args()
    sims = ['verilator', 'icarus'] if a.sim == 'both' else [a.sim]
    results = []
    for sim in sims:
        for name, top, srcs, params, plus, desc in CONFIGS:
            if a.only and name not in a.only.split(','):
                continue
            ok, exe, bt = build(sim, name, top, srcs, params)
            if not ok:
                results.append({'sim': sim, 'name': name, 'desc': desc, 'params': params, 'build': 'FAILED',
                                'pass': 0, 'fail': 1, 'checks': ['build failed'], 'wall_s': 0})
                print(f'[{sim:9s}] {name:14s} BUILD FAILED')
                continue
            info = run(sim, name, exe, plus, a.timeout)
            info.update({'sim': sim, 'name': name, 'desc': desc, 'params': params, 'build': 'ok', 'build_s': round(bt, 1)})
            results.append(info)
            print(f"[{sim:9s}] {name:14s} pass {info['pass']:4d} fail {info['fail']:3d}  ({info['wall_s']} s)")
            for c in info['checks'][:10]:
                print('      FAIL', c)
    os.makedirs(a.out, exist_ok=True)
    tag = a.sim if not a.only else f'{a.sim}_{a.only.replace(",", "_")}'
    meta = {'verilator': tool_version(['verilator', '--version']), 'icarus': tool_version(['iverilog', '-V']),
            'python': platform.python_version(), 'date': time.strftime('%Y-%m-%d %H:%M:%S')}
    with open(os.path.join(a.out, f'regression_{tag}.json'), 'w') as f:
        json.dump({'meta': meta, 'results': results}, f, indent=1)
    with open(os.path.join(a.out, f'regression_{tag}.md'), 'w') as f:
        f.write(f'# Regression ({tag})\n\nGenerated by `scripts/regress.py` on {meta["date"]}.\n\n')
        f.write(f'* Verilator: {meta["verilator"]}\n* Icarus: {meta["icarus"]}\n\n')
        f.write('| Simulator | Config | Parameters | Checks passed | Failed | Simulated time | Wall time |\n|---|---|---|---|---|---|---|\n')
        for r in results:
            st = f"{r['sim_time_ns'] / 1e6:.2f} ms" if r.get('sim_time_ns') else '-'
            p = ', '.join(f'{k}={v}' for k, v in r['params'].items()) or 'defaults'
            f.write(f"| {r['sim']} | `{r['name']}` | {p} | {r['pass']} | {r['fail']} | {st} | {r['wall_s']} s |\n")
        f.write('\n## Configurations\n\n')
        for name, top, srcs, params, plus, desc in CONFIGS:
            f.write(f'* `{name}` ({top}): {desc}\n')
        f.write('\n## Monitor summaries\n\n```\n')
        for r in results:
            for m in r.get('monitor', []):
                f.write(f"[{r['sim']}/{r['name']}] {m}\n")
        f.write('```\n')
        fails = [(r, c) for r in results for c in r['checks']]
        f.write('\n## Failures\n\n' + ('None.\n' if not fails else ''.join(f"* {r['sim']}/{r['name']}: {c}\n" for r, c in fails)))
    total_fail = sum(r['fail'] for r in results)
    print(f'TOTAL pass {sum(r["pass"] for r in results)} fail {total_fail}')
    sys.exit(1 if total_fail else 0)


if __name__ == '__main__':
    main()
