#!/usr/bin/env python3
"""Minimal VCD reader (SilicaFlux FlashLink, Project 53).

parse(path, wanted=None) -> (signals, timescale_ps)
  signals: {full_name: [(time_ps, value_str), ...]} value_str is a bit string
  ('0', '1', 'x', 'z' or a binary vector) or a real formatted as str.
Only the signals whose full or leaf name matches `wanted` are kept.
"""
import re


def parse(path, wanted=None):
    scope = []
    idmap = {}          # vcd id -> [names]
    sigs = {}
    ts_ps = 1
    t = 0
    in_defs = True
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if in_defs:
                if line.startswith('$timescale'):
                    m = re.search(r'(\d+)\s*(fs|ps|ns|us|ms|s)', line)
                    if not m:
                        nxt = next(f).strip()
                        m = re.search(r'(\d+)\s*(fs|ps|ns|us|ms|s)', nxt)
                    mul = {'fs': 1e-3, 'ps': 1, 'ns': 1e3, 'us': 1e6, 'ms': 1e9, 's': 1e12}[m.group(2)]
                    ts_ps = int(m.group(1)) * mul
                elif line.startswith('$scope'):
                    scope.append(line.split()[2])
                elif line.startswith('$upscope'):
                    scope.pop()
                elif line.startswith('$var'):
                    p = line.split()
                    vid, name = p[3], p[4]
                    full = '.'.join(scope + [name])
                    if wanted is None or full in wanted or name in wanted:
                        idmap.setdefault(vid, []).append(full)
                        sigs.setdefault(full, [])
                elif line.startswith('$enddefinitions'):
                    in_defs = False
                continue
            c = line[0]
            if c == '#':
                t = int(line[1:]) * ts_ps
            elif c in '01xzXZ':
                vid = line[1:]
                for n in idmap.get(vid, ()):
                    sigs[n].append((t, c.lower()))
            elif c in 'bBrR':
                val, vid = line[1:].split()
                for n in idmap.get(vid, ()):
                    sigs[n].append((t, val.lower()))
    return sigs, ts_ps


def value_at(changes, t):
    v = None
    for tt, vv in changes:
        if tt > t:
            break
        v = vv
    return v
