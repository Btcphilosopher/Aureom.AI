#!/usr/bin/env python3
"""SilicaFlux FlashLink (Project 53): synthesis and FPGA place-and-route reports.

1. Yosys generic synthesis (`synth -flatten`) of several controller configurations:
   cell / flip-flop counts and a latch check.
2. Yosys synth_ecp5 + nextpnr-ecp5 place and route of synth/sfnc_fpga_harness.sv
   (controller + 4 KiB block-RAM buffer + 8-bit host port) on LFE5U-25F:
   utilisation and maximum frequency.
Raw tool output goes to reports/synth/, the summary to reports/synth.md.
"""
import json
import os
import re
import subprocess
import sys
import time

REUSE = '--reuse-pnr' in sys.argv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = [l.strip() for l in open(os.path.join(ROOT, 'rtl', 'files.f')) if l.strip()]
OUT = os.path.join(ROOT, 'reports', 'synth')

GENERIC = [
    ('x8_1ce_q4', 'silicaflux_nand_controller', {}, 'baseline: x8, 1 CE, 2 LUNs, 4 slots, perf counters'),
    ('x8_1ce_q4_noperf', 'silicaflux_nand_controller', {'ENABLE_PERF': 0}, 'baseline without performance counters'),
    ('x8_4ce_q8', 'silicaflux_nand_controller', {'NUM_CE': 4, 'QUEUE_DEPTH': 8, 'CPL_DEPTH': 8}, '4 CEs, 8 slots'),
    ('x16_buf64', 'silicaflux_nand_controller', {'DQ_WIDTH': 16, 'BUF_DW': 64}, 'x16 bus, 64-bit buffer port'),
    ('mc_2ch', 'silicaflux_nand_multichannel', {}, '2-channel wrapper (2 x baseline)'),
]


def sh(cmd, log, timeout=3600):
    t0 = time.time()
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    open(log, 'w').write(' '.join(cmd) + '\n\n' + r.stdout + r.stderr)
    return r.returncode, r.stdout + r.stderr, time.time() - t0


def parse_stat(txt):
    # last "design hierarchy"-level or top-level stat block after flatten
    cells = {}
    m = list(re.finditer(r'Number of cells:\s+(\d+)', txt))
    total = int(m[-1].group(1)) if m else None
    blk = txt[m[-1].start():] if m else ''
    for cm in re.finditer(r'^\s+(\$?\w+)\s+(\d+)\s*$', blk, re.M):
        cells[cm.group(1)] = int(cm.group(2))
    ff = sum(v for k, v in cells.items() if 'DFF' in k.upper() or k.startswith('TRELLIS_FF'))
    lat = sum(v for k, v in cells.items() if 'LATCH' in k.upper())
    return total, ff, lat, cells


def main():
    os.makedirs(OUT, exist_ok=True)
    ys_ver = subprocess.run(['yosys', '-V'], capture_output=True, text=True).stdout.strip()
    np_ver = subprocess.run(['nextpnr-ecp5', '--version'], capture_output=True, text=True)
    np_ver = (np_ver.stdout + np_ver.stderr).strip().splitlines()[0] if np_ver.returncode == 0 else 'not available'
    rows = []
    for name, top, params, desc in GENERIC:
        files = RTL + (['rtl/silicaflux_nand_multichannel.sv'] if top == 'silicaflux_nand_multichannel' else [])
        chp = ' '.join(f'-chparam {k} {v}' for k, v in params.items())
        script = (f'read_verilog -sv {" ".join(files)}; hierarchy -check -top {top} {chp}; '
                  f'synth -flatten -top {top}; check -assert; tee -o {OUT}/{name}_stat.txt stat')
        rc, out, dt = sh(['yosys', '-p', script], f'{OUT}/{name}_yosys.log')
        stat = open(f'{OUT}/{name}_stat.txt').read() if os.path.exists(f'{OUT}/{name}_stat.txt') else ''
        total, ff, lat, cells = parse_stat(stat)
        rows.append({'name': name, 'top': top, 'params': params, 'desc': desc, 'rc': rc, 'cells': total, 'ff': ff,
                     'latches': lat, 'time_s': round(dt, 1)})
        print(f'{name:18s} rc={rc} cells={total} ff={ff} latches={lat} ({dt:.0f} s)')

    # ---------------------------------------------------------------- ECP5
    ecp = {}
    files = RTL + ['synth/sfnc_fpga_harness.sv']
    script = (f'read_verilog -sv {" ".join(files)}; synth_ecp5 -top sfnc_fpga_harness -json {OUT}/harness_ecp5.json; '
              f'tee -o {OUT}/harness_ecp5_stat.txt stat')
    rc, out, dt = sh(['yosys', '-p', script], f'{OUT}/harness_ecp5_yosys.log')
    stat = open(f'{OUT}/harness_ecp5_stat.txt').read() if os.path.exists(f'{OUT}/harness_ecp5_stat.txt') else ''
    total, ff, lat, cells = parse_stat(stat)
    ecp['yosys'] = {'rc': rc, 'cells': total, 'cell_types': cells, 'latches': lat}
    print(f'ecp5 yosys rc={rc} cells={total}')
    ecp['attempts'] = []
    if rc == 0 and np_ver != 'not available':
        for dev, speed in [('25k', 6), ('45k', 6), ('45k', 8)]:
            tag = f'_{dev}_s{speed}'
            log = f'{OUT}/harness_ecp5{tag}_nextpnr.log'
            rep = f'{OUT}/harness_ecp5{tag}_report.json'
            if REUSE and os.path.exists(log):
                out2 = open(log).read()
                rc2 = 0 if 'Max frequency for clock' in out2 and 'ERROR' not in out2 else 1
                dt2 = None
            else:
                rc2, out2, dt2 = sh(['nextpnr-ecp5', f'--{dev}', '--speed', str(speed), '--package', 'CABGA381', '--json',
                                     f'{OUT}/harness_ecp5.json', '--freq', '100', '--lpf-allow-unconstrained',
                                     '--timing-allow-fail', '--seed', '1', '--report', rep], log, timeout=7200)
            m = re.findall(r"Max frequency for clock\s+'([^']+)':\s+([\d.]+) MHz \(([A-Z]+) at ([\d.]+) MHz\)", out2)
            util = {}
            for um in re.finditer(r'^Info:\s+(\w+):\s+(\d+)/\s*(\d+)\s+(\d+)%', out2, re.M):
                util[um.group(1)] = (int(um.group(2)), int(um.group(3)), int(um.group(4)))
            err = re.findall(r'^ERROR: (.*)$', out2, re.M)
            att = {'device': f'LFE5U-{dev.upper().replace("K", "F")}-{speed}', 'rc': rc2, 'log': os.path.basename(log),
                   'fmax': [{'clock': c, 'mhz': float(f), 'status': st, 'target': float(t)} for c, f, st, t in m][-1:],
                   'util': util, 'error': err[0] if err else None, 'time_s': round(dt2, 1) if dt2 else None}
            ecp['attempts'].append(att)
            print('ecp5', dev, 'rc', rc2, att['fmax'], att['error'])

    # ---------------------------------------------------------------- report
    with open(os.path.join(ROOT, 'reports', 'synth.md'), 'w') as f:
        f.write('# Synthesis and FPGA implementation report\n\n')
        f.write(f'Generated by `scripts/synth.py` on {time.strftime("%Y-%m-%d %H:%M:%S")}.\n\n* {ys_ver}\n* {np_ver}\n\n')
        f.write('## 1. Yosys generic synthesis (`synth -flatten`, `check -assert`)\n\n'
                'Technology-independent gate counts (Yosys internal cell library). They compare configurations; '
                'they are not ASIC area.\n\n'
                '| Config | Top | Parameters | Cells | Flip-flops | Latches | Yosys exit | Time |\n|---|---|---|---|---|---|---|---|\n')
        for r in rows:
            p = ', '.join(f'{k}={v}' for k, v in r['params'].items()) or 'defaults'
            f.write(f"| `{r['name']}` | {r['top']} | {p} | {r['cells']} | {r['ff']} | {r['latches']} | {r['rc']} | {r['time_s']} s |\n")
        f.write('\n')
        for r in rows:
            f.write(f"* `{r['name']}`: {r['desc']}\n")
        f.write('\n## 2. Lattice ECP5: Yosys `synth_ecp5` + nextpnr-ecp5\n\n'
                'Design: `synth/sfnc_fpga_harness.sv` = baseline controller + 4 KiB block-RAM page buffer + 8-bit '
                'host register port + x8 NAND pins (the harness exists only so the design fits the package I/O). '
                'Placement uses unconstrained pins (`--lpf-allow-unconstrained`), seed 1, 100 MHz target. '
                'No board, no pin constraints, no I/O timing: this measures internal logic only.\n\n')
        for att in ecp.get('attempts', []):
            f.write(f"### {att['device']} (CABGA381)\n\n")
            if att['error']:
                f.write(f"* nextpnr: **failed** — `{att['error']}` (log `reports/synth/{att['log']}`)\n")
            for fm in att['fmax']:
                f.write(f"* Max frequency `{fm['clock']}`: **{fm['mhz']:.2f} MHz** ({fm['status']} at {fm['target']:.0f} MHz target)\n")
            if att['util']:
                f.write('\n| Resource | Used | Available | % |\n|---|---|---|---|\n')
                for k, (u, a_, pc) in att['util'].items():
                    if u:
                        f.write(f'| {k} | {u} | {a_} | {pc}% |\n')
            f.write('\n')
        f.write('\nYosys ECP5 cell counts:\n\n```\n')
        for k, v in sorted(ecp['yosys']['cell_types'].items()):
            f.write(f'{k:24s} {v}\n')
        f.write('```\n\nRaw logs: `reports/synth/*_yosys.log`, `reports/synth/harness_ecp5_<device>_s<speed>_nextpnr.log`, '
                '`reports/synth/harness_ecp5_<device>_s<speed>_report.json`.\n')
    json.dump({'generic': rows, 'ecp5': ecp}, open(os.path.join(ROOT, 'reports', 'synth.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
