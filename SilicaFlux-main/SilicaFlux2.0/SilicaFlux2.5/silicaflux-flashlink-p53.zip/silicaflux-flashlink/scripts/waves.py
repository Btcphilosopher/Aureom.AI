#!/usr/bin/env python3
"""SilicaFlux FlashLink (Project 53): waveform demonstrations.

Reads the VCD of the `+TEST=demo` simulation plus its window markers, writes one
trimmed VCD per demonstration (NAND pins + sequencer state only) to waves/, and
renders annotated SVG waveforms to docs/waveforms/. Every annotated interval is
measured from the VCD, not typed in.

    python3 scripts/waves.py --vcd run/demo/demo.vcd --marks run/demo/marks.txt
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import vcdlib  # noqa: E402

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TB = 'tb_flashlink'
SIGS = [  # (vcd name, label, kind)
    (f'{TB}.p_ce_n', 'CE#', 'bit'),
    (f'{TB}.p_cle', 'CLE', 'bit'),
    (f'{TB}.p_ale', 'ALE', 'bit'),
    (f'{TB}.p_we_n', 'WE#', 'bit'),
    (f'{TB}.p_re_n', 'RE#', 'bit'),
    (f'{TB}.p_dq', 'DQ[7:0]', 'bus'),
    (f'{TB}.g_dq_oe', 'DQ drive (ctrl)', 'bit'),
    (f'{TB}.p_rb_n', 'R/B#', 'bit'),
    (f'{TB}.dut.lun_busy', 'LUN busy [1:0]', 'bus'),
    (f'{TB}.dut.bst', 'sequencer state', 'state'),
]
BST = {0: 'IDLE', 1: 'CESEL', 2: 'CMD1', 3: 'ADDR', 4: 'DIN', 5: 'DIN', 6: 'CMD2', 7: 'tWB', 8: 'DOUT', 9: 'ST_CMD',
       10: 'ST_ADDR', 11: 'ST_RD', 12: '05h', 13: 'DOUT', 14: 'tRR', 15: 'PARAM', 16: 'FEAT', 17: 'CEOFF', 18: 'DRAIN',
       19: 'FIN', 20: 'CHECK', 21: 'COL', 22: 'E0h', 23: 'tCCS'}


def v2int(v):
    try:
        return int(v, 2)
    except ValueError:
        return None


def edges(ch, t0, t1, rising):
    out = []
    prev = None
    for t, v in ch:
        if prev is not None and t0 <= t <= t1:
            if rising and prev == '0' and v == '1':
                out.append(t)
            if not rising and prev == '1' and v == '0':
                out.append(t)
        prev = v
    return out


def write_vcd(path, sigs, t0, t1, ts_ps):
    ids = {}
    with open(path, 'w') as f:
        f.write('$date SilicaFlux FlashLink waveform window $end\n$timescale 1ps $end\n$scope module flashlink $end\n')
        for i, (name, ch) in enumerate(sigs.items()):
            vid = chr(33 + i)
            ids[name] = vid
            width = max((len(v) for _, v in ch), default=1)
            leaf = name.split('.')[-1]
            f.write(f'$var wire {width} {vid} {leaf} $end\n')
        f.write('$upscope $end\n$enddefinitions $end\n')
        events = {}
        for name, ch in sigs.items():
            init = vcdlib.value_at(ch, t0)
            if init is not None:
                events.setdefault(0, []).append((name, init))
            for t, v in ch:
                if t0 < t <= t1:
                    events.setdefault(int(t - t0), []).append((name, v))
        for t in sorted(events):
            f.write(f'#{t}\n')
            for name, v in events[t]:
                f.write((f'{v}{ids[name]}\n') if len(v) == 1 and v in '01xz' else f'b{v} {ids[name]}\n')


def render(path, title, sigs, t0, t1, notes, unit='ns'):
    scale = 1e3 if unit == 'ns' else 1e6
    n = len(SIGS)
    fig, ax = plt.subplots(figsize=(14, 0.55 * n + 1.6))
    span = (t1 - t0) / scale
    for row, (name, label, kind) in enumerate(SIGS):
        y = (n - 1 - row) * 1.0
        ch = sigs.get(name, [])
        pts = [(t0, vcdlib.value_at(ch, t0))] + [(t, v) for t, v in ch if t0 < t <= t1] + [(t1, None)]
        ax.text(-0.01 * span, y + 0.3, label, ha='right', va='center', fontsize=9, family='monospace')
        for (ta, va), (tb, _) in zip(pts[:-1], pts[1:]):
            xa, xb = (ta - t0) / scale, (tb - t0) / scale
            if va is None:
                continue
            if kind == 'bit':
                if va in ('x', 'z'):
                    ax.fill_between([xa, xb], y + 0.1, y + 0.5, color='#d62728' if va == 'x' else '#bbbbbb', alpha=0.4, lw=0)
                    ax.plot([xa, xb], [y + 0.3, y + 0.3], color='#888888', lw=1)
                else:
                    lv = y + (0.6 if va == '1' else 0.0)
                    ax.plot([xa, xb], [lv, lv], color='#1f3b73', lw=1.4)
                    ax.plot([xa, xa], [y, y + 0.6], color='#1f3b73', lw=0.6, alpha=0.5)
            else:
                iv = v2int(va) if va else None
                hiz = va is not None and all(c == 'z' for c in va)
                col = '#bbbbbb' if hiz else ('#d62728' if iv is None else ('#e8f0fb' if kind == 'bus' else '#f5ecd9'))
                ax.fill_between([xa, xb], y, y + 0.6, color=col, lw=0, alpha=0.9)
                ax.plot([xa, xb], [y, y], color='#1f3b73', lw=0.8)
                ax.plot([xa, xb], [y + 0.6, y + 0.6], color='#1f3b73', lw=0.8)
                ax.plot([xa, xa], [y, y + 0.6], color='#1f3b73', lw=0.8)
                if (xb - xa) > span / 45:
                    if kind == 'bus' and iv is not None:
                        txt = f'{iv:02X}'
                    elif kind == 'state' and iv is not None:
                        txt = BST.get(iv, str(iv))
                    else:
                        txt = 'Z' if hiz else ''
                    ax.text((xa + xb) / 2, y + 0.3, txt, ha='center', va='center', fontsize=7, family='monospace')
    for k, (ta, tb, label, row) in enumerate(notes):
        xa, xb = (ta - t0) / scale, (tb - t0) / scale
        yy = (n - 1 - row) * 1.0 + 0.85
        ax.annotate('', xy=(xb, yy), xytext=(xa, yy), arrowprops=dict(arrowstyle='<->', color='#c47f00', lw=1.2))
        ax.text((xa + xb) / 2, yy + 0.12, label, ha='center', va='bottom', fontsize=8, color='#8a5a00')
    ax.set_xlim(-0.12 * span, span * 1.01)
    ax.set_ylim(-0.4, n + 0.4)
    ax.set_yticks([])
    ax.set_xlabel(f'time from window start ({unit})')
    ax.set_title(title, fontsize=11, loc='left')
    for s in ('top', 'right', 'left'):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(path)
    if os.environ.get('WAVES_PNG_DIR'):
        fig.savefig(os.path.join(os.environ['WAVES_PNG_DIR'], os.path.basename(path).replace('.svg', '.png')), dpi=110)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--vcd', required=True)
    ap.add_argument('--marks', required=True)
    a = ap.parse_args()
    names = [s[0] for s in SIGS]
    sigs, ts = vcdlib.parse(a.vcd, wanted=set(names))
    marks = {}
    for line in open(a.marks):
        p = line.split()
        if p and p[0] == 'MARK':
            marks[p[1]] = (float(p[2]) * 1e3, float(p[3]) * 1e3)   # ns -> ps
    os.makedirs(os.path.join(ROOT, 'waves'), exist_ok=True)
    os.makedirs(os.path.join(ROOT, 'docs', 'waveforms'), exist_ok=True)
    ce, we, re_, rb = sigs[f'{TB}.p_ce_n'], sigs[f'{TB}.p_we_n'], sigs[f'{TB}.p_re_n'], sigs[f'{TB}.p_rb_n']
    dq = sigs[f'{TB}.p_dq']
    cle = sigs[f'{TB}.p_cle']
    ale = sigs[f'{TB}.p_ale']

    def ce_windows(t0, t1):
        f = edges(ce, t0, t1, False)
        r = edges(ce, t0, t1, True)
        out = []
        for a_ in f:
            nxt = [b for b in r if b > a_]
            if nxt:
                out.append((a_, nxt[0]))
        return out

    def cmd_rise(t0, t1, code):
        """WE# rising edges with CLE high carrying `code`."""
        return [t for t in edges(we, t0, t1, True)
                if vcdlib.value_at(cle, t - 1) == '1' and v2int(vcdlib.value_at(dq, t - 1) or 'x') == code]

    def addr_rise(t0, t1):
        return [t for t in edges(we, t0, t1, True) if vcdlib.value_at(ale, t - 1) == '1']

    summary = []
    out = []

    def emit(name, title, t0, t1, notes, unit='ns'):
        pad = (t1 - t0) * 0.03
        w0, w1 = t0 - pad, t1 + pad
        write_vcd(os.path.join(ROOT, 'waves', f'{name}.vcd'), sigs, w0, w1, ts)
        render(os.path.join(ROOT, 'docs', 'waveforms', f'{name}.svg'), title, sigs, w0, w1, notes, unit)
        out.append(name)

    # 1. READ ID at mode 0
    t0, t1 = marks['read_id_mode0']
    w = ce_windows(t0, t1)[0]
    c90 = cmd_rise(*w, 0x90)[0]
    a0 = addr_rise(*w)[0]
    rf = edges(re_, *w, False)
    emit('read_id_mode0', 'READ ID (90h 00h, 5 bytes) - timing mode 0, 100 MHz controller clock', w[0], w[1],
         [(a0, rf[0], f'tWHR {(rf[0] - a0) / 1e3:.0f} ns', 3), (w[0], c90, f'CE# to 1st WE# rise {(c90 - w[0]) / 1e3:.0f} ns', 0)])
    summary.append(('READ ID mode 0', f'tWHR measured {(rf[0] - a0) / 1e3:.0f} ns (min 120)'))

    # 2. PROGRAM issue at mode 0 (16 bytes)
    t0, t1 = marks['program16_mode0']
    w = ce_windows(t0, t1)[0]
    alast = addr_rise(*w)[-1]
    c80 = cmd_rise(*w, 0x80)[0]
    c10 = cmd_rise(*w, 0x10)[0]
    wr = [t for t in edges(we, *w, True) if t > alast and vcdlib.value_at(cle, t - 1) == '0' and vcdlib.value_at(ale, t - 1) == '0']
    rbf = edges(rb, c10, t1, False)[0]
    rbr = edges(rb, rbf, t1, True)[0]
    emit('program16_issue_mode0', 'PROGRAM issue (80h, 2 col + 3 row, tADL, 16 data, 10h, tWB) - mode 0', w[0], max(w[1], rbf) + 400e3,
         [(alast, wr[0], f'tADL {(wr[0] - alast) / 1e3:.0f} ns', 3), (c10, rbf, f'tWB {(rbf - c10) / 1e3:.0f} ns', 7)])
    summary.append(('PROGRAM mode 0', f'tADL measured {(wr[0] - alast) / 1e3:.0f} ns (min 200); tWB {(rbf - c10) / 1e3:.0f} ns; '
                    f'R/B# low {(rbr - rbf) / 1e6:.1f} us (tPROG)'))
    # 3. READ completion at mode 0
    t0, t1 = marks['read16_mode0']
    ws = ce_windows(t0, t1)
    w = ws[-1]
    ce0 = cmd_rise(*w, 0xE0)[0]
    rf = edges(re_, *w, False)
    rf2 = [t for t in rf if t > ce0]
    emit('read16_complete_mode0', 'READ completion (78h + LUN row, status, 05h col E0h, tCCS, 16 data) - mode 0', w[0], w[1],
         [(ce0, rf2[0], f'tCCS {(rf2[0] - ce0) / 1e3:.0f} ns', 4)])
    summary.append(('READ mode 0', f'tCCS measured {(rf2[0] - ce0) / 1e3:.0f} ns (parameter page 500 ns); '
                    f'{len(ws)} bus jobs (issue + status polls + data)'))
    # whole READ operation (issue + busy + completion)
    rb_f = edges(rb, t0, t1, False)
    rb_r = edges(rb, t0, t1, True)
    emit('read16_overview_mode0', 'READ_PAGE end to end: issue, tR busy (R/B# low), status poll, data out - mode 0',
         t0, t1, [(rb_f[0], rb_r[0], f'tR {(rb_r[0] - rb_f[0]) / 1e6:.1f} us', 7)], unit='us')
    # 4. SET FEATURES mode 5
    t0, t1 = marks['set_features_mode5']
    w = ce_windows(t0, t1)[0]
    emit('set_features_mode5', 'SET FEATURES 01h (timing mode 5): EFh 01h P1..P4 at mode-0 timing, then tFEAT busy', t0, t1, [])
    # 5. READ completion at mode 5
    t0, t1 = marks['read16_mode5']
    w = ce_windows(t0, t1)[-1]
    rf = edges(re_, *w, False)
    ce0 = cmd_rise(*w, 0xE0)[0]
    data_re = [t for t in rf if t > ce0]
    rc = (data_re[1] - data_re[0]) / 1e3
    emit('read16_complete_mode5', 'READ completion at timing mode 5 (same sequence, 30 ns read cycle at 100 MHz)', w[0], w[1],
         [(data_re[0], data_re[1], f'tRC {rc:.0f} ns', 4)])
    summary.append(('READ mode 5', f'read cycle measured {rc:.0f} ns (tRC min 20; tRP widened to tREA 16 + 2 ns margin)'))
    t0, t1 = marks['program16_mode5']
    w = ce_windows(t0, t1)[0]
    alast = addr_rise(*w)[-1]
    wr = [t for t in edges(we, *w, True) if t > alast and vcdlib.value_at(cle, t - 1) == '0' and vcdlib.value_at(ale, t - 1) == '0']
    wc = (wr[1] - wr[0]) / 1e3
    emit('program16_issue_mode5', 'PROGRAM issue at timing mode 5 (20 ns write cycle)', w[0], w[1],
         [(alast, wr[0], f'tADL {(wr[0] - alast) / 1e3:.0f} ns', 3), (wr[0], wr[1], f'tWC {wc:.0f}', 3)])
    summary.append(('PROGRAM mode 5', f'write cycle measured {wc:.0f} ns (tWC min 20), tADL {(wr[0] - alast) / 1e3:.0f} ns (min 70)'))
    # 6. ERASE overview (us)
    t0, t1 = marks['erase_mode0']
    rbf = edges(rb, t0, t1, False)[0]
    rbr = edges(rb, rbf, t1, True)[0]
    emit('erase_overview_mode0', 'ERASE end to end: 60h + 3 row + D0h, tBERS (R/B# low), status (78h) - mode 0', t0, t1,
         [(rbf, rbr, f'tBERS {(rbr - rbf) / 1e6:.0f} us', 7)], unit='us')
    summary.append(('ERASE mode 0', f'R/B# low {(rbr - rbf) / 1e6:.1f} us (model tBERS 1000 us)'))
    # 7. interleave overview
    t0, t1 = marks['interleave_mode5']
    emit('interleave_mode5', 'Multi-LUN interleaving: ERASE on LUN1 (R/B# low ~1 ms) while two READs on LUN0 complete - mode 5',
         t0, t1, [], unit='us')
    with open(os.path.join(ROOT, 'docs', 'waveforms', 'MEASUREMENTS.md'), 'w') as f:
        f.write('# Waveform measurements\n\nMeasured by `scripts/waves.py` from the demo VCD (`+TEST=demo`, Icarus). '
                'Each SVG has a trimmed VCD of the same window in `waves/`.\n\n| Demonstration | Measured |\n|---|---|\n')
        for k, v in summary:
            f.write(f'| {k} | {v} |\n')
        f.write('\nFiles: ' + ', '.join(f'`{n}.svg`' for n in out) + '\n')
    print('rendered', len(out), 'waveforms;', '; '.join(f'{k}: {v}' for k, v in summary))


if __name__ == '__main__':
    main()
