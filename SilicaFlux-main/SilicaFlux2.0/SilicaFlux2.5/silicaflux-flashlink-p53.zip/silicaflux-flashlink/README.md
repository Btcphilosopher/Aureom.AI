# SilicaFlux FlashLink — NAND flash channel controller (Project 53)

**Primary RTL:** [`rtl/silicaflux_nand_controller.sv`](rtl/silicaflux_nand_controller.sv) — Aureom.AI | SilicaFlux-STORE

A synthesizable NAND **channel** controller for the asynchronous (SDR) NAND interface. It takes abstract
operations (READ_ID, READ_PARAMETER, READ_PAGE, PROGRAM_PAGE, ERASE_BLOCK, READ_STATUS, RESET, plus
SET/GET FEATURES), validates them against the device geometry it reads from the parameter page, turns them into
NAND command / address / data sequences with programmable ONFI-style timing, moves page data to and from a buffer
SRAM over the SilicaFlux DataFabric (SFB2), and reports completions with status, latency and device busy time.
One channel first; multiple chip enables, multi-LUN interleaving, read/program arbitration and a multi-channel
wrapper were added after the single-channel protocol tests passed.

> **Status — read first.**
> * Verified in simulation against the **SilicaFlux NANDLab device model (Project 52)**, unmodified, on Verilator
>   and Icarus. Not run against a physical NAND device or a vendor model.
> * Implements a small **ONFI-style command subset**; **no ONFI compliance is claimed** (ONFI 6.0 or otherwise).
>   Timing values are a transcription to be checked against the targeted ONFI revision and part datasheet.
> * The electrical boundary is a **placeholder**: no NAND PHY, pad cells, I/O timing or NV-DDR support is claimed
>   (`rtl/sfnc_io_sdr.sv`, docs/03 §5). No ECC, no FTL. See [docs/08_LIMITATIONS.md](docs/08_LIMITATIONS.md).

## Results at a glance

* **Protocol regression: 771 / 771 checks pass on Verilator 5.020 and 771 / 771 on Icarus Verilog 12**
  across seven configurations (1 target; 2 targets with per-target and with shared R/B#; 50, 100 and 200 MHz
  controller clocks; 4 and 8 request slots; a deliberate timing-violation test; a 2-channel system). Every run
  ends with **zero** NANDLab protocol errors, **zero** NANDLab AC-timing violations, **zero** violations from an
  independent pin monitor (≈227 000 timing / electrical / sequence checks per suite run) and zero SFB2 protocol
  errors. [reports/regression_both.md](reports/regression_both.md)
* **Definition of done**, shown against the NANDLab device: the controller **identifies the device** (READ ID,
  ONFI parameter page with CRC-16 → geometry, address cycles, timing modes, tR/tPROG/tBERS/tCCS loaded
  automatically), **reads pages** (full and partial, any column / length, byte-exact against the device array),
  **programs data**, **erases blocks**, and **detects errors through the protocol**: status FAIL after injected
  program / erase failures and factory-bad blocks, sequence rejections, timeouts (over-long busy, R/B# stuck low),
  buffer errors, and requests refused before reaching the bus (geometry, alignment, write protect, program
  order, missing RESET).
* **Timing**: ONFI-style asynchronous modes 0–5 with run-time switching through SET FEATURES; measured on the
  waveforms: tWHR 120 ns (min 120), tADL 250 ns (min 200), tCCS 630 ns (device 500), mode-5 write cycle 20 ns,
  read cycle 30 ns. A negative test proves the model's and the monitor's checkers fire on mis-programmed timing.
* **Scaling** after the single-channel tests passed: 2 chip enables (isolation, cross-target concurrency),
  multi-LUN interleaving (four LUN0 operations finish during one LUN1 erase), read-priority arbitration with a
  proven starvation bound, and two concurrent channels.
* **Throughput** (528-byte page, 100 MHz clock): 9.9 MB/s at mode 0 to 32.6 MB/s at mode 5 for the read data
  phase; READ latency 80.9 µs (mode 0) / 42.4 µs (mode 5) including the 25 µs array read.
  [docs/06_PERFORMANCE.md](docs/06_PERFORMANCE.md)
* **Lint**: Verilator `-Wall`, no waiver file, **0 warnings** on 7 parameter configurations (x8 / x16, 1–8 CEs,
  4–16 slots, 64-bit buffer, 2 and 4 channels); all elaborate on Icarus. [reports/lint.md](reports/lint.md)
* **Synthesis**: Yosys 0.33, 0 latches; baseline channel 29 657 generic cells / 4 812 flip-flops.
  **Gate-level simulation of the synthesized netlist passes the full protocol suite (141 / 141)**.
  ECP5 place and route (controller + block-RAM buffer harness): LFE5U-45F **66.2 MHz (−6) / 84.9 MHz (−8)**,
  30 % of the LUTs; does not fit the 25F. **The 100 MHz used in most simulations is not met on ECP5**; the
  controller is parameterised by its clock and is verified at 50 MHz too. [docs/07_LINT_SYNTH.md](docs/07_LINT_SYNTH.md)

## Deliverables

| Requirement | Where |
|---|---|
| `silicaflux_nand_controller.sv` | [rtl/silicaflux_nand_controller.sv](rtl/silicaflux_nand_controller.sv): request slots, address / geometry validation, scheduler (per-LUN order, LUN / target busy rules, interleaving, read/program arbitration), command / address sequencer, data-transfer control, status interpretation, ready/busy management (R/B# + 70h/78h polling), timeouts, parameter-page parser with ONFI CRC-16, error reporting, performance counters, CSRs |
| NAND command / state packages | [rtl/silicaflux_nand_pkg.sv](rtl/silicaflux_nand_pkg.sv) (operations, opcodes, status bits, completion codes, micro-ops, states, CSR map) |
| Timing configuration | [rtl/silicaflux_nand_timing_pkg.sv](rtl/silicaflux_nand_timing_pkg.sv) (mode table + cycle conversion), run-time TIM0..3 / TMODE CSRs, generated tables in [reports/timing_config.md](reports/timing_config.md), [docs/03_TIMING.md](docs/03_TIMING.md) |
| Interface adapters | timing/interface adaptation [rtl/sfnc_timing_engine.sv](rtl/sfnc_timing_engine.sv); DataFabric buffer master [rtl/sfnc_buf_master.sv](rtl/sfnc_buf_master.sv); physical I/O boundary [rtl/sfnc_io_sdr.sv](rtl/sfnc_io_sdr.sv); multi-channel wrapper [rtl/silicaflux_nand_multichannel.sv](rtl/silicaflux_nand_multichannel.sv) |
| Self-checking tests | [tb/tb_flashlink.sv](tb/tb_flashlink.sv), [tb/tb_multichannel.sv](tb/tb_multichannel.sv), independent pin monitor [tb/sfnc_onfi_monitor.sv](tb/sfnc_onfi_monitor.sv), SFB2 memory [tb/sfnc_sfb_mem.sv](tb/sfnc_sfb_mem.sv), device [tb/models/nand_flash_model.sv](tb/models/nand_flash_model.sv) (P52, vendored unmodified); runner [scripts/regress.py](scripts/regress.py) |
| Waveform demonstrations | [docs/waveforms/](docs/waveforms/) (annotated SVGs, measured intervals in [MEASUREMENTS.md](docs/waveforms/MEASUREMENTS.md)), trimmed VCDs in [waves/](waves/), full demo VCD `waves/demo_full.vcd` |
| Actual lint / synthesis reports | [reports/lint.md](reports/lint.md), [reports/synth.md](reports/synth.md), [reports/gls.md](reports/gls.md), regression [reports/regression_both.md](reports/regression_both.md) |

## Documentation

| | |
|---|---|
| [00_AUDIT.md](docs/00_AUDIT.md) | repository inspection: NAND model, DataFabric, DMA, clock/reset, SRAM buffers, existing NAND RTL, PHY/IO support |
| [01_ARCHITECTURE.md](docs/01_ARCHITECTURE.md) | layers, interfaces, parameters, multi-channel wrapper, P51 integration |
| [02_COMMAND_PROTOCOL.md](docs/02_COMMAND_PROTOCOL.md) | operation → NAND sequence mapping, status interpretation, error codes, enforced restrictions |
| [03_TIMING.md](docs/03_TIMING.md) | timing table provenance, cycle conversion, where each rule is enforced, how it was verified, physical timing (not claimed) |
| [04_SCHEDULING.md](docs/04_SCHEDULING.md) | slots, ordering, LUN / target busy rules, ready/busy, timeouts, arbitration, scaling steps |
| [05_VERIFICATION.md](docs/05_VERIFICATION.md) | environment, test plan, configurations, bugs found, not verified |
| [06_PERFORMANCE.md](docs/06_PERFORMANCE.md) | counters and measured throughput / latency / utilisation |
| [07_LINT_SYNTH.md](docs/07_LINT_SYNTH.md) | lint, synthesis, FPGA place and route, gate-level simulation |
| [08_LIMITATIONS.md](docs/08_LIMITATIONS.md) | what is not claimed |
| [REGISTERS.md](docs/REGISTERS.md) | CSR map |

## Quick start

Verilator ≥ 5.020, Icarus Verilog ≥ 12, Yosys 0.33, nextpnr-ecp5 0.6 (synthesis only), Python ≥ 3.8 with
matplotlib (waveforms only).

```bash
make sim
```

```bash
make regress-all
```

```bash
make lint
```

```bash
make synth
```

```bash
make demo
```

## Layout

```
rtl/        silicaflux_nand_controller.sv (primary), packages, timing engine, buffer master, I/O boundary,
            multi-channel wrapper, primitives, files.f
tb/         testbenches, monitor, SFB2 memory, models/nand_flash_model.sv (P52), print_timing.sv
synth/      sfnc_fpga_harness.sv (ECP5 place-and-route harness only)
config/     nandlab_regress.svcfg (device configuration used by every test)
scripts/    regress.py, lint.py, synth.py, gls.py, waves.py, vcdlib.py
reports/    regression, lint, synthesis, gate-level simulation, timing tables (all generated)
docs/       design documentation, waveforms/
waves/      trimmed VCDs of the waveform demonstrations
```

## Provenance

* `tb/models/nand_flash_model.sv` is copied unmodified from `silicaflux-nandlab-v0.1.0.zip` (Project 52),
  SHA-256 `070651e01b6d6bbc2f6374cae2c93e96508a8624e557f8ac56bd8062136652cb`.
* `config/nandlab_regress.svcfg` is derived from NANDLab's `outputs/sv_regression/store_channel/nandlab.svcfg`
  (changes listed in [config/README.md](config/README.md)).
* No ONFI document or vendor datasheet was available; see docs/03 §1.
