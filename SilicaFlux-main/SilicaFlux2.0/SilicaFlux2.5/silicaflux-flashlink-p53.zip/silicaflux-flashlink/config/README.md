# Device configuration for the regression

`nandlab_regress.svcfg` is the run-time configuration of the NANDLab model (Project 52); every test copies it
into a fresh store directory as `nandlab.svcfg`. The svcfg format has no comment syntax, so provenance is here.

Derived from NANDLab `outputs/sv_regression/store_channel/nandlab.svcfg` (geometry 512 + 16 B pages,
16 pages/block, 64 blocks/LUN in 2 planes, 2 LUNs; profile `ideal`: no random bit errors, wear or retention
faults, so every data comparison is exact). Changes:

| Key | NANDLab value | Here | Why |
|---|---|---|---|
| `config_fp` | `8c9045f807860baf` | `flashlink-p53-regress` | label |
| `t_bers_ns` | 2000000 | 1000000 | shorter erase, less simulated time |
| `factory_bad` | target 0: LUN0 blk 5, LUN1 blk 9 | + target 1: LUN0 blk 7 | bad-block marker on the second target too |
| `force_prog_fail` | — | target 0, LUN0, blk 3, page 0 | injected program failure (status FAIL) |
| `force_erase_fail` | — | target 0, LUN0, blk 4 | injected erase failure (status FAIL) |

All timing and reliability values are NANDLab's **illustrative** values (tR 25 µs, tPROG 200 µs, tBERS 1 ms here,
power-on reset 1 ms, tCCS 500 ns), not those of a real part.
