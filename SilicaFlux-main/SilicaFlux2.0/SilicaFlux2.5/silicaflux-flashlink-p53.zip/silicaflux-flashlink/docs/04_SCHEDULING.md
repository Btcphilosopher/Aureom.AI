# 04 — Scheduling, ready/busy management and arbitration

## 1. Request slots

`QUEUE_DEPTH` slots hold accepted requests (`req_ready` = a slot is free). A slot is `PEND` (not on the bus yet)
or `WAIT` (its LUN or target is busy). An **age matrix** (`s_older[i][j]`: slot *i* older than slot *j*) gives
"oldest of a set" in one cycle without sequence-number wrap-around.

## 2. Bus jobs

One bus sequencer owns the channel. Each time it is idle it picks one job, in this priority:

1. **J_ERR** — oldest request that fails without bus traffic: bad op / CE / LUN, or a target that needs RESET
   (power-on, controller reset, or faulted by a timeout) and nothing older on that target is ahead of it.
2. **J_TMO** — oldest `WAIT` request whose busy time exceeds its op-class timeout → `TIMEOUT`, target faulted.
3. **J_COMP** — oldest `WAIT` request that may be complete: target-level ops when the target's synchronised
   R/B# is high; array ops when R/B# is high (hint) or their poll timer expired.
4. **J_ISSUE** — an issuable `PEND` request, chosen by the arbitration policy (§5).

Validation (geometry, alignment, WP#, program order, timing-mode support) runs when an issue job starts, after
ordering has been satisfied, so it always sees the geometry from any earlier parameter-page read on the target.

**Registered decisions (timing closure).** The pick is computed every cycle and registered; the sequencer uses the
registered pick only after it has been idle for a full cycle, so the decision always reflects the state after the
previous job's completion updates. Per-request timeout comparisons, the free-slot choice (one-hot), the job's
LUN-table index and row address, the derived address-bit counts and the tCCS cycle count are registered as well,
and validation is split over two states (CHECK registers the individual checks, CHECK2 encodes them in priority
order). Cost: about three clock cycles per bus job, and at most one accepted request every second cycle. None of
these changes is visible on the NAND pins; the full regression and the gate-level simulation were re-run after them
(docs/07).

## 3. Ordering and resource rules

A `PEND` request is **blocked** while an older request on the same target exists and either one is target-level
or both address the same LUN. It is **issuable** when, in addition:

| Request | Resources required |
|---|---|
| READ / PROGRAM / ERASE | target not busy; LUN not busy; no other LUN busy unless `MULTI_LUN && USE_ENH` (78h needed to tell LUNs apart) |
| READ_STATUS | target not busy (78h is illegal during a target-level operation) |
| RESET | target not busy (array LUNs may be busy: RESET aborts them); with a shared R/B#, the rest of the channel idle |
| READ_ID, READ_PARAM, SET/GET FEATURES | target not busy and all its LUNs idle; with a shared R/B#, the whole channel idle |

With `CTRL.INTERLEAVE = 0` the controller is **strictly in order**: only the oldest request issues, and only when
nothing is in `WAIT`. With `INTERLEAVE = 1`, different LUNs and different targets overlap their busy times.

## 4. Ready / busy management

* **R/B#**: per target (`RB_SHARED = 0`) or one wired-AND line (`RB_SHARED = 1`), 2-flop synchronised. The issue
  job waits `wb` (tWB + synchroniser latency) after the confirm command before the request becomes `WAIT`, so a
  high R/B# seen afterwards really means "finished".
* **Status polling**: a request in `WAIT` gets a poll timer (`POLL_RD / PG / ER`, then `POLL_IV` after a busy
  poll). A poll is `78h` + LUN row (once READ STATUS ENHANCED is enabled) or `70h`, one status byte, CE#
  deselected again — the bus is free between polls for other targets and LUNs.
* **Hints**: R/B# high triggers an immediate poll (R/B# high means every LUN of that target is idle). If such a
  poll finds the LUN busy, hints are ignored for that request (R/B# considered unreliable) and its timer rules.
* **Timeouts**: `TMO_RD / PG / ER / TGT`, derived from the parameter page's tR / tPROG / tBERS maxima (×4 +
  1000 cycles) with `CTRL.AUTO_TMO`. A timeout completes the request with `TIMEOUT`, marks the target faulted
  (only RESET / READ_STATUS accepted) and leaves the LUN marked busy until RESET aborts whatever the device is
  doing. Verified with an over-long erase and with R/B# forced low.

## 5. Read / program arbitration

| `CTRL.RD_PRIO` | Policy |
|---|---|
| 0 | oldest issuable request first |
| 1 | oldest issuable READ first; after `CTRL[19:16]` consecutive reads have bypassed an issuable non-read, the oldest request is taken (starvation bound) |

Verified: with `RD_PRIO = 0` an older PROGRAM confirms before a younger READ on another LUN; with `RD_PRIO = 1`
the READ goes first; with limit 2 and reads queued on three LUNs (two targets), the PROGRAM issues after exactly
two bypassing reads.

## 6. Scaling steps (as the brief orders them)

1. **One channel, one target, in order** (`INTERLEAVE = 0`): the base configuration; all protocol tests first.
2. **Multiple chip enables** (`NUM_CE` up to 8, per-target or shared R/B#): `ce2`, `ce2_rbshared` regressions.
3. **LUN interleaving** (`INTERLEAVE = 1`, `MULTI_LUN`, `USE_ENH` from the parameter page): interleave tests.
4. **Multi-channel concurrency**: `silicaflux_nand_multichannel`, `multichannel` regression.
5. **Read/program arbitration**: `RD_PRIO` with a starvation bound.
