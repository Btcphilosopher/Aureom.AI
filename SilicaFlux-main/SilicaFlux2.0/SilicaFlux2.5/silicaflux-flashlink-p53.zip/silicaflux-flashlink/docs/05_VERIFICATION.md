# 05 — Verification

## 1. Environment

```
 tb_flashlink / tb_multichannel (self-checking, firmware-style driver: requests, completions, CSRs)
   │ requests / completions / CSR                      │ SFB2
   ▼                                                   ▼
 silicaflux_nand_controller (RTL under test) ──► sfnc_sfb_mem   page buffer: random stalls (15–30 %),
   │ registered pins                                   random latency 1–4, error window, R2/R9 checks
   ▼
 sfnc_io_sdr (SIM) ──► shared tri-state DQ bus, CE# per target, R/B# per target or wired-AND
   │                         │
   ▼                         ▼
 nand_flash_device × NUM_CE  sfnc_onfi_monitor  (independent pin-level timing / electrical / sequence checker)
 (NANDLab P52, unmodified: persistent store, AC checker, protocol checker, directed faults)
```

* Device configuration `config/nandlab_regress.svcfg`: NANDLab profile `ideal` (no random bit errors, so data
  compares are exact), tBERS 1 ms, factory-bad blocks (target 0: LUN0 block 5, LUN1 block 9; target 1: LUN0
  block 7), forced program failure (target 0, LUN0, block 3, page 0), forced erase failure (target 0, LUN0,
  block 4). Every run starts from a fresh store directory.
* Data is checked three ways: buffer contents against generated patterns, buffer against the device array via
  the model's back door (`bd_peek`), and guard bytes around partial transfers (byte strobes).
* End-of-run checks (every configuration except `negative`): model protocol errors = 0, model AC-timing
  violations = 0, monitor violations = 0, SFB2 protocol errors = 0.

## 2. Test plan (`tb/tb_flashlink.sv`, `+TEST=suite`)

| Group | What is checked |
|---|---|
| CSR | ID, version, CTRL reset value, TIM0/TIM1 equal the package's mode-0 word, write to a read-only CSR flags `csr_err` |
| Power-on | READ_PAGE before RESET → `NOT_RESET` with no bus traffic; READ_STATUS allowed and uses 70h (never 78h) |
| RESET | every target; status E0h; busy time = model's 1 ms power-on reset (±1 %) |
| READ ID | 00h: `00 5A 00 15 00`; 20h: "ONFI" |
| Parameter page | CRC-16 + signature, info fields, all 256 bytes in the buffer equal the device's, geometry CSRs (512+16 B, 16 pages, 64 blocks, 2 LUNs, 2+3 address cycles, modes 0–5, tR 25 µs, tCCS 500 ns), READ STATUS ENHANCED and multi-LUN enabled, read timeout derived from tR, GEO6 feature words |
| Features / timing mode | GET FEATURES = 0; mode 7 refused without bus traffic; SET FEATURES mode 5 → controller switches after the device; GET FEATURES = 5 at mode-5 timing; multi-target variant switches all targets first |
| Erase / program / read | erase busy ≈ tBERS, erased page reads FFh, program busy ≈ tPROG, back-door array matches, read-back exact, read busy ≈ tR |
| Partial transfers | reads at (col, len) = (3,1), (100,37), (511,17), (527,1), (0,528) exact with untouched guard bytes; spare-only program |
| Program order | out-of-order first program refused (`PROG_ORDER`, no `80h` on the bus); with the check off the device rejects it (status FAIL → `DEV_FAIL`) |
| Bad blocks / injected failures | factory bad-block marker read; program to a bad block → `DEV_FAIL`; forced program failure (status E1h, 3× busy time); forced erase failure |
| Write protect | program / erase refused while WP# low, no bus traffic; device status shows WP# low; accepted again after release (tWW) |
| Validation | 11 malformed requests (LUN, block, page, column + length, zero length, alignment, op codes, CE, READ ID length, parameter-page alignment) rejected with the right code and **no bus traffic**; sticky flags set and cleared |
| Status | READ_STATUS on LUN1 uses 78h + row |
| Interleaving | erase on LUN1 while two reads, a program and a read-after-program run on LUN0; LUN0 operations complete first, in order, with correct data |
| Queue | `QUEUE_DEPTH + 4` reads submitted back to back: back-pressure counted, every read correct |
| Buffer errors | read into a failing buffer region → `BUF_ERR`; program from it → `BUF_ERR`, never confirmed, page untouched; next program succeeds |
| Multi-target (`NUM_CE ≥ 2`) | CE# isolation at the same address; CE0 reads while CE1 erases; starvation bound of read priority |
| Arbitration | oldest-first vs read-priority, checked on the order of confirm commands on the bus |
| Timeouts | erase beyond a 100 µs timeout → `TIMEOUT`, target faulted, requests refused, RESET recovers, erase OK; RESET with R/B# forced low → `TIMEOUT`, recovery after release; timeout counter |
| Controller reset | controller reset while the device erases; every target needs RESET; RESET aborts the erase; parameter page re-read; earlier data intact |
| Timing-mode sweep | modes 0–5: switch, program, read back exact; latency and data-phase cycles recorded (`PERF` lines) |
| Performance counters | busy + idle = cycles, byte / op counters, max ≥ mean latency, polls ≥ misses, clear |

`+TEST=negative`: timing deliberately mis-programmed (1-cycle pulses at mode 0): the model's AC checker and the
monitor must both report violations (proves the checkers are live). `+TEST=demo`: short sequences for the
waveform demonstrations.

`tb/tb_multichannel.sv`: two channels each with its own target, buffer and monitor: per-channel CSR windows,
RESET / parameter page / mode 5 per channel, two 1 ms erases overlapping (< 1.5 ms total), concurrent programs
with different data, a read on channel 0 while channel 1 erases, completion back-pressure across channels, a
request for a missing channel → `BAD_ADDR`, CSR access to a missing channel → `csr_err`.

## 3. Configurations (`scripts/regress.py`)

| Config | Parameters | Purpose |
|---|---|---|
| `base` | defaults (1 CE, 2 LUNs, per-CE R/B#, 100 MHz, 4 slots) | full suite |
| `negative` | defaults | checkers fire on bad timing |
| `ce2` | `NUM_CE=2` | two targets, per-target R/B# |
| `ce2_rbshared` | `NUM_CE=2, RB_SHARED=1` | two targets on one wired-AND R/B# |
| `clk200_q8` | `CLK_PS=5000, QD=8` | 200 MHz timing conversion, 8 slots |
| `clk50` | `CLK_PS=20000` | 50 MHz (coarse quantisation) |
| `multichannel` | `NUM_CH=2` | multi-channel wrapper |

Each runs on **Verilator 5.020** and **Icarus Verilog 12**. Results: `reports/regression_both.md` (summary in the
README).

**Gate-level**: `scripts/gls.py` synthesizes the controller with Yosys and runs the unchanged `base` suite on the
netlist (Verilator + Yosys `simcells.v`): 141 / 141 checks, zero model / monitor violations (`reports/gls.md`).

## 4. Bugs the regression found during development

| Found by | Symptom | Cause | Fix |
|---|---|---|---|
| NANDLab protocol checker + monitor log | address `20 20 00` instead of `20 00 00`; SET FEATURES data `05 05 00 00` | timing engine used the pre-increment byte index when chaining a beat directly from the previous one | byte index of the beat being started |
| NANDLab protocol checker | "data output beyond page+spare" during interleaving | after `78h`, `00h` resumed data output at the column left by another LUN's program | READ completion always uses `05h col E0h` + tCCS |
| test (timeout) | read to a faulted target waited forever, then blocked the recovery RESET | NOT_RESET was checked only after resources were free; a timed-out LUN stays busy | requests to a target needing RESET fail fast once unblocked |
| test (program order) | out-of-order program not refused | CTRL reset constant missed bit 9 | `CTRL_RST = 0x000417C1` |
| test (busy time) | read "busy" 41 µs for tR 25 µs | device time measured to the end of the data phase | measured to ready detection |
| monitor | `DQ_UNSTABLE` at mode 0 | monitor race: DQ and WE# change on the same timestamp | stability checked at the WE# rising edge |
| Verilator only | violations at t = 5 ns | 2-state simulator: pins at 0 before the first reset edge | testbench holds pads idle until reset has been applied |

## 5. Not verified

* x16 (`DQ_WIDTH=16`): no x16 device model exists; elaborated, linted and synthesized only.
* `BUF_DW=64`: linted and synthesized only.
* A physical NAND device, vendor simulation models, real I/O timing.
* Random bit errors / read retry (the controller has no ECC; NANDLab `nominal`/`stress` profiles not used).
* Gate-level *timing* simulation (the gate-level run in §3 is zero-delay).
