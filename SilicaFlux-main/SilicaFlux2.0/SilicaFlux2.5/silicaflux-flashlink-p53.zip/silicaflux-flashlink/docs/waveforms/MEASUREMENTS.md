# Waveform measurements

Measured by `scripts/waves.py` from the demo VCD (`+TEST=demo`, Icarus). Each SVG has a trimmed VCD of the same window in `waves/`.

| Demonstration | Measured |
|---|---|
| READ ID mode 0 | tWHR measured 120 ns (min 120) |
| PROGRAM mode 0 | tADL measured 250 ns (min 200); tWB 200 ns; R/B# low 200.0 us (tPROG) |
| READ mode 0 | tCCS measured 630 ns (parameter page 500 ns); 5 bus jobs (issue + status polls + data) |
| READ mode 5 | read cycle measured 30 ns (tRC min 20; tRP widened to tREA 16 + 2 ns margin) |
| PROGRAM mode 5 | write cycle measured 20 ns (tWC min 20), tADL 80 ns (min 70) |
| ERASE mode 0 | R/B# low 1000.0 us (model tBERS 1000 us) |

Files: `read_id_mode0.svg`, `program16_issue_mode0.svg`, `read16_complete_mode0.svg`, `read16_overview_mode0.svg`, `set_features_mode5.svg`, `read16_complete_mode5.svg`, `program16_issue_mode5.svg`, `erase_overview_mode0.svg`, `interleave_mode5.svg`
