# CSR map (per channel)

Single-cycle port: `csr_sel`, `csr_we`, `csr_addr[7:0]` (byte offset), `csr_wdata`, `csr_rdata` (combinational),
`csr_err` (unmapped address, or write to a read-only register). In the multi-channel wrapper
`csr_addr[10:8]` selects the channel. Source of truth: `rtl/silicaflux_nand_pkg.sv`.

| Offset | Name | Access | Fields |
|---|---|---|---|
| 0x00 | ID | RO | `0x53463533` ("SF53") |
| 0x04 | VERSION | RO | [31:16] version (0x0100), [15:8] DQ_WIDTH, [7:0] NUM_CE |
| 0x08 | CONFIG | RO | [31:24] QUEUE_DEPTH, [23:16] NUM_LUN_MAX, [15:8] TAG_W, [7:1] BUF_DW/8, [0] RB_SHARED |
| 0x0C | CTRL | RW | see below; reset `0x000417C1` |
| 0x10 | STATUS | RO | [28:24] sequencer state, [23:16] completion-queue level, [15:8] slots in use, [6:4] timing mode, [3] WP# level, [2] geometry from parameter page, [1] completion pending, [0] busy |
| 0x14 | TMODE | RW | [2:0] timing mode; a write loads TIM0..TIM3 with that mode's defaults |
| 0x18 | TIM0 | RW | [31:24] reh, [23:16] rp, [15:8] wh, [7:0] wp (cycles) |
| 0x1C | TIM1 | RW | [31:24] rhw, [23:16] adl, [15:8] whr, [7:0] su |
| 0x20 | TIM2 | RW | [31:24] rr, [23:16] ww, [15:8] ch, [7:0] cs |
| 0x24 | TIM3 | RW | [7:0] wb (tWB + synchroniser margin) |
| 0x28 | GEO0 | RW | [31:16] OOB bytes, [15:0] page data bytes |
| 0x2C | GEO1 | RW | [15:0] pages per block |
| 0x30 | GEO2 | RW | [23:0] blocks per LUN |
| 0x34 | GEO3 | RW | [31:16] timing-mode mask, [15:12] column cycles, [11:8] row cycles, [7:0] LUNs |
| 0x38 | GEO4 | RO | [31:16] tCCS (ns), [15:0] tR max (µs) — from the parameter page |
| 0x3C | GEO5 | RO | [31:16] tBERS max (µs), [15:0] tPROG max (µs) |
| 0x40 | TMO_RD | RW | read timeout (cycles) |
| 0x44 | TMO_PG | RW | program timeout |
| 0x48 | TMO_ER | RW | erase timeout |
| 0x4C | TMO_TGT | RW | RESET / parameter page / features timeout |
| 0x50 | POLL_RD | RW | [23:0] first status poll after a READ (cycles) |
| 0x54 | POLL_PG | RW | first poll after a PROGRAM |
| 0x58 | POLL_ER | RW | first poll after an ERASE |
| 0x5C | POLL_IV | RW | poll interval after a busy poll (≥ 1) |
| 0x60 | PERF_CTRL | W | [0] clear performance counters |
| 0x64 + 4·n | PERF[n] | RO | counters, docs/06 §1 (n = 0..22) |
| 0xC0 | ERR | RW1C | [4] request rejected, [3] parameter page, [2] buffer error, [1] device FAIL, [0] timeout |
| 0xC4 | TGT | RO | [31:24] faulted, [23:16] target busy, [15:8] reset done, [7:0] R/B# ready (one bit per target) |
| 0xC8 | GEO6 | RO | [31:16] optional commands, [15:0] features (parameter page bytes 8–9, 6–7) |

## CTRL (0x0C)

| Bit | Name | Reset | Meaning |
|---|---|---|---|
| 0 | EN | 1 | scheduler issues new requests (completions always drain) |
| 1 | WP_N | 0 | WP# pin level; 0 = program / erase refused (`WP`) |
| 2 | INTERLEAVE | 0 | several LUNs / targets busy at once; 0 = strictly in order |
| 3 | RD_PRIO | 0 | read-priority arbitration |
| 4 | USE_ENH | 0 | READ STATUS ENHANCED (78h) — set from the parameter page |
| 5 | MULTI_LUN | 0 | concurrent operations on several LUNs of a target — set from the parameter page |
| 6 | AUTO_GEO | 1 | load geometry from a valid parameter page |
| 7 | AUTO_TIM | 1 | SET FEATURES 01h also switches the controller's timing mode |
| 8 | AUTO_TMO | 1 | derive timeouts from the parameter page |
| 9 | ORDER_CHK | 1 | sequential-program check |
| 10 | POLL_EN | 1 | status polling (else R/B# only) |
| 11 | IRQ_EN | 0 | `irq` = completion available |
| 12 | TMO_EN | 1 | timeouts |
| 19:16 | STARVE | 4 | read-priority starvation limit |

Geometry, timing and timeout registers should be changed only while the channel is idle.
