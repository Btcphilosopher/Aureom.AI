# 06 — Performance instrumentation and measured numbers

## 1. Counters (`CSR_PERF_BASE + 4·index`, 32-bit, cleared by `PERF_CTRL[0]` or reset)

| Index | Counter | Meaning |
|---|---|---|
| 0 | `CYCLES` | controller clock cycles |
| 1 | `BUS_BUSY` | cycles the bus sequencer owns the channel (**channel busy cycles**) |
| 2 | `BUS_DATA` | cycles inside data-in / data-out bursts |
| 3 | `ARRAY_BUSY` | cycles with at least one LUN or target busy |
| 4 / 5 | `BYTES_RD` / `BYTES_WR` | page + parameter bytes read from / written to NAND (**bytes transferred**) |
| 6–9 | `N_READ`, `N_PROG`, `N_ERASE`, `N_OTHER` | completed operations |
| 10–15 | `LAT_RD_SUM/MAX`, `LAT_PG_SUM/MAX`, `LAT_ER_SUM/MAX` | accept → completion latency (**read / program / erase latency**) |
| 16 | `Q_STALL` | cycles with `req_valid && !req_ready` (**request-queue stalls**) |
| 17 | `CPL_STALL` | cycles a finished job waited for completion-queue space |
| 18 | `N_TMO` | **timeout events** |
| 19 | `N_ERR` | completions with status ≠ OK |
| 20 / 21 | `N_POLL` / `N_POLL_MISS` | status polls / polls that found the LUN busy |
| 22 | `BUS_IDLE` | **idle cycles** of the bus sequencer |

Counter events are registered before they are counted, so counters lag the events by one cycle.

**Channel utilisation** = `BUS_BUSY / CYCLES`; data-phase efficiency = `BUS_DATA / BUS_BUSY`; array occupancy =
`ARRAY_BUSY / CYCLES`. Every completion also carries its own `cpl_latency` and `cpl_dev_time` (confirm → ready).

## 2. Measured (simulation against the NANDLab model)

Device timings are NANDLab's illustrative values (tR 25 µs, tPROG 200 µs, tBERS 1 ms in the regression
configuration). Full page = 528 bytes (512 + 16 OOB), x8. Numbers from the `base` (100 MHz) and `clk200_q8`
(200 MHz) runs, `PERF mode` lines of `run/*/result.txt`.

### Data-phase throughput by timing mode

| Mode | Read cycle @100 MHz | 528-B read data phase @100 MHz | MB/s | Read cycle @200 MHz | Data phase @200 MHz | MB/s |
|---|---|---|---|---|---|---|
| 0 | 100 ns | 53.4 µs | 9.9 | 100 ns | 53.5 µs | 9.9 |
| 1 | 60 ns | 32.1 µs | 16.4 | 50 ns | 26.8 µs | 19.7 |
| 2 | 50 ns | 26.8 µs | 19.7 | 45 ns | 24.2 µs | 21.8 |
| 3 | 40 ns | 21.5 µs | 24.6 | 35 ns | 18.9 µs | 28.0 |
| 4 | 40 ns | 21.5 µs | 24.6 | 35 ns | 18.9 µs | 28.0 |
| 5 | 30 ns | 16.2 µs | 32.6 | 30 ns | 16.2 µs | 32.6 |

Read cycles are rp + reh rounded up to whole clocks; at mode 5 tRP is widened to 20 ns so DQ is sampled after
tREA (16 ns) plus the 2 ns capture margin, which limits the asynchronous interface to ~33 MB/s with this capture
scheme (docs/03 §5). Writes reach the full 20 ns tWC at mode 5 (50 MB/s data-in).

### Operation latency at 100 MHz (single request, idle channel)

| Mode | READ (528 B) | of which device busy (confirm → ready seen) | PROGRAM (528 B) | of which busy |
|---|---|---|---|---|
| 0 | 80.9 µs | 25.6 µs | 254.8 µs | 200.6 µs |
| 5 | 42.4 µs | 25.2 µs | 211.4 µs | 200.2 µs |

Ready is detected 0.2–0.6 µs after the device finishes (R/B# synchroniser, job pick, status read). Erase: 1.0 ms
busy (tBERS) + ~1 µs.

### Whole-suite counters (`base`, from the controller reset in the reset test to the end)

`CYCLES 328 999`, `BUS_BUSY 44 569` → **channel utilisation 13.5 %** (the workload is dominated by array busy
time: `ARRAY_BUSY` 95 %), `BUS_DATA / BUS_BUSY` = 83 %, 3 952 bytes read, 3 168 written, 148 polls of which 134
found the LUN busy.

### Concurrency

* Two LUNs (`interleave` tests): four LUN0 operations (two reads, a program, a read) complete while one LUN1
  erase is in progress.
* Two channels (`multichannel`): two 1 ms erases complete in < 1.5 ms total; channel 0 reads during a channel 1
  erase.

## 3. Tuning notes

* With a per-target R/B# line, the R/B# hint completes requests promptly; the poll timers (`POLL_*`) then act
  only as a fallback and can be set large to cut status-poll traffic (most of the 134 misses above are the
  100 µs / 5 µs program polls). With a shared R/B# or several busy LUNs per target, polling is what detects
  completion; `POLL_IV` sets the granularity (5 µs default).
* Faster controller clocks quantise timings more finely (mode 1: 60 ns → 50 ns read cycle from 100 to 200 MHz).
* The buffer port issues one SFB2 transaction at a time (≥ 3 cycles per 32-bit word), still above the NAND data
  rate at every mode.
