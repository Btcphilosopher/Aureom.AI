# 03 — Timing: configuration, enforcement and verification

## 1. Source of the numbers

`rtl/silicaflux_nand_timing_pkg.sv` holds the ONFI-style asynchronous timing modes 0–5 (25 parameters,
`onfi_ns(mode, param)`), transcribed from the ONFI asynchronous timing table **as also used by the NANDLab model
(Project 52)**. Where the two transcriptions differed (tWHR in modes 3–5) the larger value is used. The ONFI
specification and part datasheets are not in the repository, so:

* the table is a **starting point to be checked against the ONFI revision and datasheet of the part used**
  (later revisions and many datasheets differ, e.g. a larger tADL);
* every derived cycle count can be overridden at run time (`TIM0..TIM3`), and `TMODE` reloads a mode's defaults.

The complete table and the derived cycle counts at 50 / 100 / 133 / 200 MHz are generated from the package by
`tb/print_timing.sv` into [`reports/timing_config.md`](../reports/timing_config.md).

## 2. Conversion to controller cycles (`mode_word`)

`cyc(t) = ceil(t · 1000 / CLK_PERIOD_PS)`, evaluated at elaboration (no dividers in hardware):

| Field | Rule | Enforced by |
|---|---|---|
| `wp` | tWP | engine: WE# low |
| `su` | max(tCLS, tALS, tDS) − wp (≥ 0) | engine: CLE/ALE/DQ before WE# falls |
| `wh` | max(tWH, tCLH, tALH, tDH, tWC − wp − su) | engine: WE# high; also hold of CLE/ALE/DQ |
| `rp` | max(tRP, tREA + `CAPTURE_MARGIN_PS`) | engine: RE# low; **DQ sampled on the edge that raises RE#** |
| `reh` | max(tREH, tRC − rp) | engine: RE# high |
| `whr` | max(tWHR, wh + max(tCLR, tAR)) | engine: last WE# rise → RE# fall (CLE/ALE fall at the end of `wh`) |
| `adl` | tADL | engine: address WE# rise → data cycle start (conservative: from the start, not the data WE# rise) |
| `rhw` | max(tRHW, tRHZ) | engine: RE# rise → controller drives DQ / WE# falls (bus turnaround) |
| `cs` | max(tCS, tCEA) | engine: CE# fall → first strobe |
| `ch` | tCH | engine: last strobe → CE# rise; also minimum CE# high time between selections |
| `ww` | tWW | engine: WP# change → WE# fall |
| `wb` | tWB + 2 sync stages + 2 | sequencer: confirm → R/B# / status trusted |
| `rr` | tRR | sequencer: ready → first RE# (parameter page, GET FEATURES) |
| tCCS | parameter-page tCCS (500 ns if unknown), `ceil` via a 2¹⁶ reciprocal | sequencer: `E0h` → first RE# |

DQ is released (`dq_oe = 0`) at least one cycle before RE# falls, and only driven again `rhw` cycles after RE#
rises. Pulses are never shorter than one cycle whatever is programmed.

Example (100 MHz): mode 0 → 100 ns write and read cycles, tWHR 120 ns, tADL 200 ns; mode 5 → 20 ns write cycle,
30 ns read cycle (tRP is widened from 10 to 20 ns because tREA = 16 ns plus the 2 ns capture margin must fit
before the sampling edge).

## 3. Timing-mode management

Devices power up in mode 0 and so does the controller (`TIMING_MODE_RST`). `OP_SET_FEATURES` with feature
address `01h` switches the device; with `CTRL.AUTO_TIM` the controller loads the new mode's timing word **after**
the device has finished (R/B# high), so no cycle is ever driven faster than the device's current mode. Requests
for a mode the parameter page does not advertise are refused (`UNSUPPORTED`). On multi-target channels all
targets must be switched first (docs/02 §5). Controller reset returns the controller to mode 0 while the device
may still be in a faster mode; that is safe because every mode-0 minimum is at least the corresponding faster-mode
minimum and every waited-for maximum (tWB, tREA, tRHZ) is the larger mode-0 value.

## 4. How timing was verified

Three independent checks run on every simulation (docs/05):

1. **NANDLab model's AC checker** (P52, unmodified): tWP, tWH, tWC, tRP, tREH, tRC, tCLS, tALS, tDS, tWHR, tADL,
   tRR, tCCS against the device's *own* current timing mode (it applies SET FEATURES itself). DQ is driven tREA
   after RE# falls, so a too-short tRP returns wrong data.
2. **Independent pin monitor** (`tb/sfnc_onfi_monitor.sv`, its own copy of the table, timing mode tracked by
   decoding SET FEATURES on the pins): additionally tCLH, tALH, tDH, tCS, tCH, tWW, tCLR, tAR, tCEA, tRHW, tRHZ,
   DQ stability while WE# is low, one CE# at a time, WE#/RE# never low together, no contention, no X on control
   pins or latched/sampled DQ, legal command sequences.
3. **Negative test** (`+TEST=negative`): the controller is deliberately mis-programmed (tWP = tWH = tRP = tREH =
   1 cycle at mode 0); both the model and the monitor must report violations. They do, so the checkers are live.

Measured on the demonstration waveforms (`docs/waveforms/MEASUREMENTS.md`): tWHR 120 ns (min 120), tADL 250 ns
(min 200), tCCS 630 ns (device 500), mode-5 write cycle 20 ns (min 20) and read cycle 30 ns.

**Common-mode limitation:** the controller table, the monitor table and the NANDLab model are transcriptions of the
same ONFI-style values. The checks prove the controller meets *that* table at every clock tested (50, 100,
200 MHz); they cannot prove the table matches a particular datasheet.

## 5. Physical timing — not claimed

No I/O cells, board model or SDC exist for the NAND pins, so no physical timing is claimed. What a real
implementation must add:

* pad cells (drive strength, slew, input thresholds) chosen from board signal-integrity analysis
  (`sfnc_io_sdr` TECH branch);
* output and input delay constraints for the NAND pins, and I/O-register placement of the pin flops and the DQ
  capture flop;
* the read-capture budget: `rp · Tclk ≥ t_clk→out + t_out_pad + t_board + tREA + t_board + t_in_pad + t_setup`.
  `CAPTURE_MARGIN_PS` is the knob; 2 ns is a simulation value, not a characterised one;
* above roughly mode 4–5 a real design typically samples on a delayed or calibrated edge (EDO-style capture).
  NV-DDR / NV-DDR2/3 / Toggle need DQS-based capture and a PHY with calibration — out of scope.

The ECP5 place-and-route numbers in `reports/synth.md` cover internal logic only (no pin constraints).
