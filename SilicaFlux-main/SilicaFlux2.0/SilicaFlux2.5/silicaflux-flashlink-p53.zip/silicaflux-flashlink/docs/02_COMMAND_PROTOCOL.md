# 02 — Command protocol

Only the ONFI-style asynchronous command subset below is implemented. Sequences follow the ONFI command-set
structure as modelled by the SilicaFlux NANDLab device (Project 52). **No ONFI compliance is claimed.**

## 1. Abstract operations → bus sequences

`row` = `page | block << ceil(log2(pages_per_block)) | lun << (page bits + block bits)`, sent in `rowc` cycles
(2 or 3, from the parameter page), LSB first. `col` = byte column (x8) or word column (x16), sent in `colc`
cycles (1 or 2). Every bus job selects its target with CE# first and deselects it at the end.

| Operation | Issue phase (bus) | Busy | Completion phase (bus) | Result |
|---|---|---|---|---|
| `OP_RESET` | `FFh`, tWB | target busy (tRST; aborts array ops) | wait R/B#, `70h`, status | OK if RDY; target marked reset; otherwise `NOT_READY` |
| `OP_READ_ID` | `90h` `addr` (00h or 20h), tWHR, N bytes out | — | — | info0/info1 = bytes 0..3 / 4..7 |
| `OP_READ_PARAM` | `ECh` `00h`, tWB | target busy (tR) | wait R/B#, tRR, 256 bytes; if signature or CRC-16 fails, the next 256 bytes (copy 2, then 3) | geometry parsed, checked and (AUTO_GEO) loaded; page optionally stored to the buffer |
| `OP_READ_STATUS` | `70h` (or `78h` + LUN row once the target is reset and READ STATUS ENHANCED is enabled), 1 byte | — | — | info0 = status |
| `OP_READ_PAGE` | `00h` col row `30h`, tWB | LUN busy (tR) | `70h`/`78h` poll → ready: `05h` col `E0h`, tCCS, N units out → buffer | info0 = bytes |
| `OP_PROGRAM_PAGE` | `80h` col row, tADL, N units in ← buffer, `10h`, tWB | LUN busy (tPROG) | `70h`/`78h` poll → ready: status | `DEV_FAIL` if status FAIL bit |
| `OP_ERASE_BLOCK` | `60h` row `D0h`, tWB | LUN busy (tBERS) | `70h`/`78h` poll → ready: status | `DEV_FAIL` if status FAIL bit |
| `OP_SET_FEATURES` | `EFh` `fa`, tADL, P1..P4, tWB | target busy (tFEAT) | wait R/B# | with `fa = 01h` and `AUTO_TIM`: controller switches to timing mode P1 |
| `OP_GET_FEATURES` | `EEh` `fa`, tWB | target busy (tFEAT) | wait R/B#, tRR, 4 bytes out | info0 = P4..P1 |

**Why READ completion uses CHANGE READ COLUMN.** With interleaving, other commands to the same target (for
example a PROGRAM's `80h` + data on another LUN) move the target's column pointer between a READ's `30h` and its
data output. Returning to data output with a bare `00h` after `78h` then reads from the wrong column — the
regression found exactly this against the NANDLab model (which keeps one column pointer per target, as many
devices do). Every READ completion therefore re-establishes the column with `05h col E0h` and waits tCCS
(parameter-page value, 500 ns when unknown) before toggling RE#.

**Programs aborted by a buffer error** are never confirmed: the controller stops loading data, does not send
`10h`, and reports `BUF_ERR`; the next command cancels the device's partial data load (verified: page untouched).

## 2. Status interpretation

| Bit | Name | Use |
|---|---|---|
| 0 | FAIL | after PROGRAM / ERASE: `CS_DEV_FAIL` |
| 1 | FAILC | reported in `cpl_nand_status`, not interpreted |
| 5 | ARDY | ready requires RDY **and** ARDY (no cache operations are used) |
| 6 | RDY | LUN (78h) or target (70h) ready |
| 7 | WP# | reported; the controller refuses program/erase itself while WP# is driven low |

Ready detection: target-level operations (RESET, READ_PARAM, SET/GET FEATURES) use the synchronised R/B# of the
target (with a shared R/B#, they are issued only while the whole channel is idle so the line is unambiguous);
array operations are completed by a status read, triggered either by R/B# high (a *hint*: R/B# high means every
LUN of the target is idle) or by the per-request poll timer. A hint that turns out wrong (R/B# high, status busy)
disables hints for that request.

## 3. Completion status codes (`cpl_status`)

| Code | Name | Cause | Bus traffic? |
|---|---|---|---|
| 0 | `OK` | | yes |
| 1 | `DEV_FAIL` | status FAIL after PROGRAM / ERASE (device-reported: bad block, worn, injected failure, sequence rejection) | yes |
| 2 | `TIMEOUT` | ready not seen within the op-class timeout (TMO_RD / PG / ER / TGT); the target is marked faulted | yes (issue) |
| 3 | `BAD_OP` | operation code > 8 | no |
| 4 | `BAD_ADDR` | CE ≥ NUM_CE, LUN ≥ geometry / table size, block ≥ blocks per LUN, page ≥ pages per block, `col + len` > page + OOB, `len = 0`, READ_ID length > 8 | no |
| 5 | `ALIGN` | buffer address not `BUF_DW`-aligned; x16 column or length odd | no |
| 6 | `WP` | PROGRAM / ERASE while `CTRL.WP_N = 0` | no |
| 7 | `NOT_RESET` | target not reset since power-on / controller reset, or faulted after a timeout (only RESET and READ_STATUS allowed) | no |
| 8 | `PROG_ORDER` | first program of a page skips pages inside the block the LUN's tracker follows (`CTRL.ORDER_CHK`) | no |
| 9 | `BUF_ERR` | SFB2 error response during the data phase | partial |
| 10 | `PARAM_CRC` | no parameter-page copy with signature "ONFI" and a valid CRC-16 | yes |
| 11 | `UNSUPPORTED` | valid parameter page whose geometry exceeds the controller's limits / bus width mismatch; SET FEATURES timing mode not supported by the device or > 5 | parameter page: yes; features: no |
| 12 | `NOT_READY` | RESET finished on R/B# but the status byte did not show RDY | yes |

Sticky flags (`CSR_ERR`, write-1-to-clear): timeout, device fail, buffer error, parameter-page error, rejected request.

## 4. `info0` / `info1`

| Operation | info0 | info1 |
|---|---|---|
| READ_ID | ID bytes 3..0 | ID bytes 7..4 |
| READ_PARAM | page data bytes (from the page) | `{LUNs[31:24], addr cycles[23:16], copy[13:12], sig_ok[11], crc_ok[10], supported[9], loaded[8], timing modes[7:0]}` |
| READ_STATUS, RESET | status byte | — |
| READ_PAGE | bytes transferred | row address |
| PROGRAM_PAGE | bytes programmed | row address |
| ERASE_BLOCK | 0 | row address |
| GET_FEATURES | P4..P1 | — |

## 5. Restrictions the controller enforces (device busy / program / erase rules)

* No command to a busy LUN; no target-level command (READ ID, READ PARAM, SET/GET FEATURES, RESET) while any LUN
  of the target is busy; no command at all to a target while one of its target-level operations is in flight
  (completion waits for R/B#).
* More than one busy LUN per target only when the parameter page advertises multiple-LUN operation **and** READ
  STATUS ENHANCED (`CTRL.MULTI_LUN` and `CTRL.USE_ENH`, set automatically from the parameter page).
* Requests to the same LUN execute in submission order; a target-level request orders against everything on its
  target.
* Power-on / controller reset: every target must receive RESET first.
* WP#: program / erase refused while the controller drives WP# low; tWW is honoured after WP# changes.
* Sequential page programming: the LUN's tracker refuses a first program that skips pages in the block it follows
  (most recently erased / programmed block). This is a partial check (one block per LUN); full per-block tracking
  belongs to the FTL.
* SET FEATURES timing mode: refused if > 5 or not in the device's advertised mode mask.
* Multi-target channels: all targets must be switched to a new timing mode before the controller switches
  (`CTRL.AUTO_TIM = 0`, SET FEATURES to every target, then write `TMODE`). The `ce2` regression does exactly this.
