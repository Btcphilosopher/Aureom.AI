# 07 — Lint, synthesis, FPGA place and route, gate-level simulation

All numbers below come from tool runs in this project; the raw outputs are in `reports/`.

## Lint ([reports/lint.md](../reports/lint.md))

Verilator 5.020 `--lint-only -Wall` with **no waiver file**, and Icarus 12 elaboration, on seven
configurations: x8 1 CE 4 slots; 4 CEs 8 slots shared R/B#; 8 CEs 4 LUNs 16 slots; x16 with a 64-bit buffer
port; perf counters off at 200 MHz; 2-channel and 4-channel × 2-CE wrappers. **0 warnings, 0 errors** on all
seven; all elaborate on Icarus. In-source waivers cover only intentionally unused bits (DW-aligned address LSBs,
upper LUN-index bits in small configurations, package constants kept for documentation) and are listed in the
report.

## Synthesis ([reports/synth.md](../reports/synth.md))

Yosys 0.33 `synth -flatten` + `check -assert` (technology-independent gates; comparisons, not ASIC area):

| Configuration | Cells | Flip-flops | Latches |
|---|---|---|---|
| x8, 1 CE, 2 LUNs, 4 slots, perf counters (baseline) | 29 657 | 4 812 | 0 |
| baseline without perf counters | 23 612 | 4 025 | 0 |
| 4 CEs, 8 slots | 40 739 | 6 792 | 0 |
| x16, 64-bit buffer | 30 437 | 5 205 | 0 |
| 2-channel wrapper | 60 407 | 9 642 | 0 |

### Lattice ECP5 place and route (Yosys `synth_ecp5` + nextpnr-ecp5 0.6)

Harness `synth/sfnc_fpga_harness.sv`: baseline controller + 4 KiB block-RAM buffer + 8-bit host register port +
x8 NAND pins (only 43 I/Os, so the design fits a package). Unconstrained pins, seed 1, 100 MHz target. Internal
logic only — no pin constraints, no I/O timing, no board.

| Device (CABGA381) | Result | LUT4 + carry (TRELLIS_COMB) | FF | Block RAM | Max frequency |
|---|---|---|---|---|---|
| LFE5U-25F-6 | placement **failed** ("unable to find legal placement", 54 % of COMB) | 13 307 / 24 288 | 4 117 | 4 DP16KD | — |
| LFE5U-45F-6 | routed | 13 307 / 43 848 (30 %) | 4 117 (9 %) | 4 / 108 | **66.2 MHz** |
| LFE5U-45F-8 | routed | 13 307 / 43 848 (30 %) | 4 117 (9 %) | 4 / 108 | **84.9 MHz** |

**The 100 MHz target used in most simulations is not met on ECP5.** The controller is parameterised by its clock
(`CLK_PERIOD_PS`) and the `clk50` regression shows correct NAND timing at 50 MHz, so an ECP5 build runs at
50 MHz (−6) or 80 MHz (−8) with the matching `CLK_PERIOD_PS`. The remaining critical path is the scheduler's
eligibility logic (slot state → per-request issuable flags → oldest-first selection), which would need a further
pipeline stage to go faster. No ASIC timing is claimed.

### Timing-closure changes made after the first place and route

The critical paths were reworked one at a time, each followed by lint and the
full Verilator regression (all checks passing every time) and a new place and route:

| # | Critical path found | Change | Fmax after (45F-6) |
|---|---|---|---|
| 0 | first routed build | — | 46.1 MHz |
| 1 | geometry → runtime log2 → row-address barrel shift → address bytes | address-bit counts and the job's row address registered | 43.2 MHz (path moved) |
| 2 | slot state → timeout subtract/compare → pick → job registers | timeout compares registered; pick registered, used after one idle cycle | 47.1 MHz |
| 3 | parameter-page support check (runtime log2 of the block count) | check registered; harness CSR read captured | 52.8 MHz |
| 4 | same check, log2 still serial | log-depth log2, support check in two registered stages; harness input registers | 51.1 MHz |
| 5 | validation priority chain in CHECK | individual checks registered in CHECK, encoded in CHECK2 | 61.9 MHz |
| 6 | LUN-table index multiply-add at FIN | index registered at pick | 61.9 MHz |
| 7 | free-slot priority + age-matrix update | registered one-hot free slot, one accept every other cycle | 58.9 MHz (harness path exposed) |
| 8 | harness host decode | equality decode in the harness | 57.2 MHz |
| 9 | runtime log2 implementation | thermometer-code `clog2_rt` (no subtractor; equal to `$clog2` for every value below 70 000, a sweep to 2²⁴ and every power-of-two edge) | 62.9 MHz |
| 10 | tCCS ns → cycles multiply | three registered steps | 62.8 MHz |
| 11 | beat chaining: 16-bit decrement → start → stream pop → perf counter | registered `left == 0/1` flags; perf events registered | 68.2 MHz |
| 12 | dynamic part-selects (packer, serialiser, byte select) | equality-decoded loops | 66.9 MHz |
| 13 | data-in pop in the same cycle as the beat start | one-unit prefetch register in the timing engine | 64.0 MHz (path now in the scheduler) |
| 14 | — | log2 terms evaluated in `always_comb` and registered (Icarus run time; same function) | **66.2 MHz** (final build) |

Run-to-run differences of a few MHz are placement variation. None of these changes alters the pin-level behaviour:
the waveform measurements and every regression check are unchanged.

## Gate-level simulation ([reports/gls.md](../reports/gls.md))

The final RTL was synthesized with Yosys (`synth -flatten`, 29 557 internal gate cells, testbench parameters) and
the **unchanged `base` protocol suite** was run on the netlist (Verilator, Yosys `simcells.v`) against the
NANDLab model: **141 / 141 checks pass**, zero model protocol errors, zero model AC-timing violations and zero
monitor violations in 226 958 checks. This shows that synthesis preserved the behaviour the RTL regression
verified (the DataFabric project had found a Yosys mis-synthesis exactly this way). The netlist has no timing
annotation: this is a zero-delay functional check, not timing sign-off.
