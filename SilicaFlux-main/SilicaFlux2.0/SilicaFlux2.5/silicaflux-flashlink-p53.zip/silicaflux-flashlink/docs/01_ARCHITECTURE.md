# 01 — Architecture

## 1. Three layers, as the brief separates them

```
 requests (abstract ops)          completions                  CSR (config / timing / geometry / counters)
        │                              ▲                                   │
┌───────▼──────────────────────────────┴───────────────────────────────────▼─────────────────────────────┐
│ silicaflux_nand_controller            DIGITAL COMMAND / CONTROLLER LOGIC                                │
│                                                                                                         │
│  request slots (QUEUE_DEPTH) ── age matrix ── scheduler ───────────► bus sequencer ──► completion FIFO   │
│   validation · per-LUN order ·   LUN / target busy tables,   command + address sequencer,   tag, status,│
│   timeouts · poll timers         R/B# hints, poll timers,    status interpretation,         NAND status,│
│                                  read/program arbitration    parameter-page parser (CRC)    latencies   │
│                                                                    │        ▲                            │
│              data-transfer engine (buffer side): sfnc_buf_master  │uop     │done / DQ units             │
│              SFB2 master ◄──► word FIFOs ◄──► unit (de)serialiser ├────────┤                            │
└──────────────────────┬────────────────────────────────────────────┼────────┼────────────────────────────┘
                       │ SFB2 (DataFabric)                           ▼        │
                       ▼                              ┌──────────────────────────────────────────────────┐
              page buffer SRAM                        │ sfnc_timing_engine   TIMING / INTERFACE ADAPTATION│
                                                      │ micro-ops → registered pin waveforms, cycle      │
                                                      │ counters from TIM0..3, cross-cycle rules,        │
                                                      │ DQ capture, R/B# synchroniser (sfnc_sync)        │
                                                      └──────────────────────┬───────────────────────────┘
                                                        ce_n[] cle ale we_n re_n wp_n dq_o dq_oe │ dq_i rb_n[]
                                                      ┌──────────────────────▼───────────────────────────┐
                                                      │ sfnc_io_sdr          PHYSICAL NAND I/O (boundary) │
                                                      │ SIM: behavioural tri-state; TECH: needs PDK pads  │
                                                      └──────────────────────┬───────────────────────────┘
                                                                             ▼ NAND package pins
```

* **Digital command/controller logic** knows NAND semantics (operations, LUNs, status bits, geometry) and
  nothing about nanoseconds. It speaks *micro-operations* to the timing layer: `U_CMD`, `U_ADDR` (1–5 bytes),
  `U_DIN` (stream or immediate), `U_DOUT` (N units), `U_DELAY`, `U_CESEL`, `U_CEOFF`.
* **Timing/interface adaptation** knows nanoseconds (as clock cycles) and nothing about NAND semantics. All pin
  outputs are flops (placeable in I/O cells). It enforces every rule that holds for any sequence (pulse widths,
  setup/hold, tWHR, tADL, tRHW, tCS, tCH, tWW, DQ release before RE#). Command-specific waits (tWB, tRR, tCCS) are
  `U_DELAY` micro-ops from the sequencer.
* **Physical I/O** is outside the synthesizable controller: `sfnc_io_sdr` is a placeholder boundary with a
  simulation-only behavioural layer (docs/03 §5 lists what a real implementation needs).

## 2. Files

| File | Block | Lines of note |
|---|---|---|
| `rtl/silicaflux_nand_controller.sv` | **primary RTL**: channel controller | request slots, scheduler, sequencer, parser, perf, CSR |
| `rtl/silicaflux_nand_pkg.sv` | command / state package | ops, opcodes, status bits, completion codes, micro-ops, slot / sequencer states, CSR map |
| `rtl/silicaflux_nand_timing_pkg.sv` | timing configuration package | ONFI-style mode table, cycle-conversion rules |
| `rtl/sfnc_timing_engine.sv` | timing / interface adaptation | micro-op → waveform |
| `rtl/sfnc_buf_master.sv` | data-transfer engine (buffer side) | SFB2 master, FIFOs, (de)serialiser |
| `rtl/sfnc_io_sdr.sv` | physical I/O boundary | SIM only; TECH stops elaboration |
| `rtl/silicaflux_nand_multichannel.sv` | optional N-channel wrapper | router, completion merge, CSR windows |
| `rtl/sfnc_sync.sv`, `rtl/sfnc_fifo.sv` | primitives | R/B# synchroniser, FIFO |

## 3. Interfaces

### Request (valid / ready)

| Field | Width | Meaning |
|---|---|---|
| `req_op` | 4 | `OP_RESET 0`, `OP_READ_ID 1`, `OP_READ_PARAM 2`, `OP_READ_STATUS 3`, `OP_READ_PAGE 4`, `OP_PROGRAM_PAGE 5`, `OP_ERASE_BLOCK 6`, `OP_SET_FEATURES 7`, `OP_GET_FEATURES 8` |
| `req_tag` | `TAG_W` | returned with the completion |
| `req_ce`, `req_lun` | 3, 3 | target (chip enable) and LUN |
| `req_block`, `req_page` | 24, 16 | block within the LUN, page within the block |
| `req_col`, `req_len` | 16, 16 | byte column (data + OOB) and length; READ_ID: number of bytes (0 → 5); READ_PARAM: non-zero → store the 256-byte valid copy in the buffer |
| `req_buf` | 32 | buffer byte address (`BUF_DW`-aligned) |
| `req_faddr`, `req_fdata` | 8, 32 | feature address / READ ID address; SET FEATURES P1..P4 (P1 in [7:0]) |

`req_ready` is high while a request slot is free (`QUEUE_DEPTH` outstanding requests); after an accepted request
it is low for one cycle (registered free-slot choice), so the request port accepts at most one request every second
cycle.

### Completion (valid / ready, FIFO of `CPL_DEPTH`)

`cpl_tag, cpl_op, cpl_status (CS_*), cpl_nand_status (status byte), cpl_ce, cpl_lun, cpl_info0, cpl_info1,
cpl_latency (accept → completion, cycles), cpl_dev_time (confirm → ready detected, cycles)`. Field meanings per
operation: docs/02 §3.

### Buffer port — SFB2 master (DataFabric rev 2.0)

`m_req_valid/ready/write/addr/wdata/wstrb`, `m_rsp_valid/ready/rdata/error`. One outstanding transaction, request
held stable until accepted, `rsp_ready = 1`, DW-aligned single-beat transfers, byte strobes for partial words.
Page byte `i` lives at `req_buf + i` (little-endian lanes).

### CSR port

Single-cycle `csr_sel/we/addr[7:0]/wdata/rdata/err`. Map in [REGISTERS.md](REGISTERS.md).

### NAND pins (per channel)

`nand_ce_n[NUM_CE-1:0], nand_cle, nand_ale, nand_we_n, nand_re_n, nand_wp_n, nand_dq_o, nand_dq_oe, nand_dq_i,
nand_rb_n[NUM_RB-1:0]` (`NUM_RB = 1` with `RB_SHARED`, else `NUM_CE`).

## 4. Parameters

| Parameter | Default | Legal / meaning |
|---|---|---|
| `DQ_WIDTH` | 8 | 8 or 16. x16: command / address / ID / status / features on DQ[7:0]; column in words. **x16 is elaborated, linted and synthesized but not simulated** (the NANDLab model is x8). |
| `NUM_CE` | 1 | 1..8 targets per channel |
| `RB_SHARED` | 0 | 1: one wired-AND R/B# for all targets |
| `NUM_LUN_MAX` | 2 | 1..8 LUNs per target the tables track |
| `QUEUE_DEPTH` | 4 | 2..16 outstanding requests |
| `CPL_DEPTH` | 4 | completion FIFO entries (power of two) |
| `TAG_W` | 8 | tag width |
| `BUF_DW` | 32 | SFB2 data width, 32 or 64 |
| `CLK_PERIOD_PS` | 10000 | controller clock period, used to build the timing tables |
| `CAPTURE_MARGIN_PS` | 2000 | extra RE# low time after tREA before DQ is sampled (output + board + input delay + setup) |
| `TIMING_MODE_RST` | 0 | timing mode after reset (devices power up in mode 0) |
| `PAGE_BYTES_MAX`, `OOB_BYTES_MAX`, `PAGES_PER_BLOCK_MAX`, `BLOCKS_PER_LUN_MAX` | 16384, 2048, 1024, 65536 | limits a parameter page must respect to be accepted |
| `DEF_*` | 512 / 16 / 16 / 64 / 1 LUN / 3 row / 2 col | geometry used until a parameter page is read (or written by firmware) |
| `TMO_*_US`, `POLL_*_US` | 2000 / 10000 / 50000 / 10000; 10 / 100 / 1000 / 5 | default timeouts and status-poll delays |
| `ENABLE_PERF` | 1 | performance counters |

Geometry (page, OOB, pages per block, blocks per LUN, LUNs, address cycles, timing-mode mask, tR / tPROG /
tBERS / tCCS) is **read from the device's parameter page** (`OP_READ_PARAM`, ONFI CRC-16, up to 3 copies) and
loaded automatically when `CTRL.AUTO_GEO` is set; firmware may also write it (GEO0..3) for devices without a
parameter page. One geometry per channel (all targets on a channel are expected to be the same part).

## 5. Multi-channel wrapper

`silicaflux_nand_multichannel` instantiates `NUM_CH` independent channel controllers. `req_ch` routes a request;
completions are merged round-robin and carry `cpl_ch`; `csr_addr[10:8]` selects the channel's CSR window; each
channel has its own SFB2 master and pin set. A request for a missing channel completes with `BAD_ADDR` without
touching any channel.

## 6. Integration with the SilicaFlux storage subsystem (P51)

P51's `sfs_nand_ctrl` is driven by firmware through a register page (`OP_ROW/COL/BUF/LEN/SUBMIT`, `CPL_*`) and
masters the storage fabric. The FlashLink controller fits the same place:

* its SFB2 master port replaces `sfs_nand_ctrl`'s (one storage-fabric master per channel);
* a thin register-page adapter (not written here) would map P51's `OP_*` / `CPL_*` registers onto the request
  and completion interfaces — the operation set is a superset of P51's;
* P51's inline SECDED page layout is **not** reproduced: FlashLink moves raw page + OOB bytes. ECC belongs in the
  data path above (BCH/LDPC, docs/08).
