# 08 — Limitations and what is not claimed

Everything here is RTL simulation against a behavioural device model, Yosys synthesis and an ECP5
place-and-route of an evaluation harness. Nothing ran on an FPGA board, on silicon, or against a physical NAND
device or a vendor simulation model.

## Not claimed

* **ONFI compliance** (any revision, including ONFI 6.0). The controller implements a small asynchronous (SDR)
  command subset: RESET, READ ID, READ PARAMETER PAGE, READ STATUS (70h) / READ STATUS ENHANCED (78h), READ PAGE
  with CHANGE READ COLUMN, PROGRAM PAGE, ERASE BLOCK, SET / GET FEATURES. Not implemented: cache read / program,
  multi-plane, copyback, read unique ID, change write column, LUN reset, volume addressing, program / erase
  suspend, ZQ calibration, ODT, the synchronous / NV-DDR / NV-DDR2 / NV-DDR3 / Toggle interfaces, and parameter-page
  fields beyond those listed in docs/02.
* **Timing values for a specific part.** The mode table is a transcription (docs/03 §1); the ONFI specification
  and datasheets were not available in the repository. Check every value against the target part.
* **A NAND PHY or qualified I/O.** `sfnc_io_sdr` is a boundary placeholder with a simulation-only layer; the
  technology branch stops elaboration. No pad cells, drive strengths, SDC, I/O timing, signal integrity or ESD
  work exists. The 2 ns `CAPTURE_MARGIN_PS` is a simulation value.
* **Physical timing closure.** ECP5 results are internal-logic Fmax of a harness with unconstrained pins; generic
  Yosys numbers are gate counts, not ASIC area.
* **Error correction.** The controller transfers raw data + OOB. BCH / LDPC (or P51's SECDED placeholder) belongs
  in the data path above; there is no read-retry policy (the NANDLab A0h read-retry feature is reachable through
  SET FEATURES but not used automatically).
* **An FTL**: no bad-block table, wear levelling, garbage collection or mapping.

## Simplifications that matter

* **x16 and 64-bit buffer are not simulated** — no x16 device model exists. They elaborate, lint and synthesize.
* **One geometry and one timing mode per channel.** All targets on a channel are expected to be the same part;
  the controller's timing mode must not be raised before every target is switched (docs/02 §5).
* **Sequential-program check is partial**: one tracked block per LUN; full per-block state belongs to the FTL.
* **Controller reset during an active strobe** asserts the pin flops asynchronously and can truncate a WE#/RE#
  pulse or CE# mid-cycle; the controller requires RESET (FFh) of every target afterwards, which recovers the
  device, but a truncated WE# pulse could latch a garbage byte first. Only reset while the bus is idle was tested.
* **Ready detection granularity**: polling every `POLL_IV` (5 µs default) when R/B# cannot be used; the R/B#
  hint is per target (it cannot tell LUNs apart).
* **Shared R/B#**: target-level operations (RESET, parameter page, features) wait until the whole channel is idle.
* **Power loss** (device `vcc_ok`) is not handled specially; the controller would see timeouts or wrong status and
  must RESET.
* **Buffer port**: one outstanding SFB2 transaction (sufficient for the asynchronous NAND rates).
* **WP#** changes are not synchronised with operations already on the bus; firmware should change WP# when idle.
* **Common-mode verification risk**: the controller's table, the monitor's table and the NANDLab model are all
  transcriptions of the same ONFI-style values (docs/03 §4).

## Tool notes

* Yosys 0.33 has no `import` and no `int'()` casts: packages are referenced as `pkg::NAME` and only size casts
  are used. Locals in procedural blocks are declared in named blocks.
* Icarus 12 lacks whole-array assignment patterns, task `return`, and widens `always_comb` sensitivity (reported
  as "sorry: constant selects…", harmless). `$isunknown` on a concatenation of ports misreported at a few edges in
  the monitor; the monitor uses `^{…} === 1'bx`.
* Verilator is 2-state: the testbenches hold the pads idle until reset has been applied.
* Icarus is an interpreter: a function with large loops called inside `always_ff` is re-run every clock. Calling
  the thermometer `clog2_rt` that way slowed the Icarus regression about 30×; the log2 terms are therefore computed
  in `always_comb` (re-evaluated only when the geometry changes) and registered. Same hardware either way.
* Icarus 12 aborts in its code generator (`ivl_expr_signal: Assertion`) on `$sformatf` with a generate-derived
  parameter argument, and cannot cast a ternary of string literals to a string parameter; the monitor copies its
  instance number into a variable first.
* Verilator 5.020's multi-threaded front end occasionally aborted with "attempted to destroy locked Thread Pool";
  the scripts verilate single-threaded (`--verilate-jobs 1`) and compile the C++ in parallel.
