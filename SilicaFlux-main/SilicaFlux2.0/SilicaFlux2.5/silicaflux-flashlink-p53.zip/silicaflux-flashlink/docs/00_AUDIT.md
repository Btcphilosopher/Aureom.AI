# 00 — Repository inspection (Project 53 FlashLink)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/confident-allen-miu0em`. As in every earlier SilicaFlux
project, the hardware work lives in zip archives under `SilicaFlux-main/` and
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. The archives relevant to a NAND channel controller were extracted
and read. "Evidence" means what the owning project recorded in its own reports; it was not re-run here unless
stated.

## 1. Findings and decisions

| Area requested | Found | Evidence (owning project) | Decision for Project 53 |
|---|---|---|---|
| **NAND memory model** | `silicaflux-nandlab-v0.1.0.zip` (**Project 52 NANDLab**): `nand_flash_model.sv` — pin-level model of one target (one CE#) with N LUNs and an ONFI-style asynchronous (SDR) interface; persistent NLSF store; SLC semantics; parameter page with ONFI CRC-16 (3 copies); READ ID; SET/GET FEATURES (timing mode, read retry); READ STATUS 70h / 78h; CHANGE READ COLUMN; per-LUN busy and multi-LUN interleaving; AC timing checker (tWP, tWH, tWC, tRP, tREH, tRC, tCLS, tALS, tDS, tWHR, tADL, tRR, tCCS) for the current timing mode; protocol checker; seeded and directed fault injection; `nand_flash_device` wrapper with a bidirectional DQ. A second, simpler model, `tb/models/sfs_nand_flash_model.sv`, is in Project 51. | P52: 128/128 SV checks on Verilator 5.020 and Icarus 12, bit-exact agreement with its Python twin | **Used as the device under the controller, unmodified.** Vendored as `tb/models/nand_flash_model.sv` (SHA-256 `070651e0…652cb`, identical to the archive's copy). Every test asserts its protocol-error and timing-violation counters are zero. The P51 model is not used (one LUN, no parameter page, no timing modes). |
| **DataFabric** | `silicaflux-datafabric.zip`: SFB2 protocol rev 2.0 (PROTOCOL.md rules R1–R12), `sfb_crossbar`, arbiters, register slice, SRAM slaves, protocol checker | formal proofs and regressions (DataFabric) | The buffer port of the controller is an **SFB2 master** honouring R2, R3, R4, R6 (one outstanding), R9, R10. One master port per channel, intended for one crossbar master port each. The testbench SFB2 memory checks R2 and R9. |
| **DMA** | P51 `sfs_dma` (host memory ↔ buffer, descriptor queue, tagged completions); DataFabric DMA engines; MCU-I `mcu_dma` | P51 / DataFabric reports | Not modified and not duplicated. The controller's **own data-transfer engine** (`sfnc_buf_master`) moves page data buffer ↔ NAND; host ↔ buffer remains the job of a storage DMA such as P51 `sfs_dma`. |
| **Clock / reset** | SilicaFlux-V `sfv_sync`, `sfv_rst_sync`; P51 single clock domain with R/B# as the only asynchronous input (2-flop synchroniser) | P51 docs/04 | Same scheme: one controller clock; `rst_n` asserted asynchronously and released synchronously by the integrator's reset synchroniser; R/B# through `sfnc_sync` (2 flops, a placeholder for a characterised library synchroniser). NAND read data is not a CDC: the controller drives RE# and samples DQ at the end of the programmed RE# low time. |
| **SRAM buffers** | `silicaflux-sramlib.zip` (generic / FPGA / ASIC macro back-ends), DataFabric `sfb_sram_slave`, P26 `sfras_sfb_ecc_slave` (the P51 buffer) | per project | The controller is buffer-agnostic (any SFB2 slave). Tests use a behavioural SFB2 memory with random request stalls, random response latency and an error window. The FPGA harness infers ECP5 block RAM. |
| **Existing NAND interface RTL** | P51 `sfs_nand_ctrl.sv` (595 lines): firmware register page + 4-deep op queue; SDR primitive sequencer (CMD / ADDR / DIN / DOUT / WAIT / DELAY); RESET, READ ID, READ STATUS, READ PAGE, PROGRAM, ERASE; inline per-word SECDED; WP#; R/B# timeout. Single CE, single LUN, fixed 2+3 address cycles; no parameter page, no geometry or address validation, no SET/GET FEATURES or timing-mode switch, no multi-LUN; CLE/ALE/DQ change on the same edge WE# falls (so tCLS/tALS/tDS hold only because tWP covers them); no tADL, tRHW, tCCS, tCS handling beyond fixed delays. | P51 regression against its own simplified model | **Not modified** (it belongs to P51 and is verified there). Project 53 is a new, more complete channel controller designed to replace it; the integration path is in docs/01 §6. |
| **PHY / I/O technology** | P37 I/O shell: pad-wrapper convention (behavioural `SIM` layer that refuses implementation, IHP sg13g2 vendor-cell layer); its I/O inventory has **no NAND pins**; its memory-PHY slot is for DDR and is BLOCKED; no NAND / ONFI PHY anywhere in the repository | P37 reports | `sfnc_io_sdr` follows the P37 convention: a behavioural `SIM` layer for simulation that stops elaboration under `SFNC_ASIC_IMPL`, and a technology branch that stops elaboration until qualified pad cells are supplied. **No PHY is invented**; NV-DDR is out of scope. |
| **ONFI specification / datasheets** | Not in the repository. P52 states its ONFI asynchronous timing table is a transcription "to be checked against the ONFI revision or datasheet you target". | — | The controller's timing table (`silicaflux_nand_timing_pkg`) is a transcription of the same ONFI-style values (larger value taken where the two transcriptions differ). It is a starting point that must be checked against the targeted ONFI revision and part datasheet; every value is overridable at run time. **No ONFI compliance is claimed.** |
| **EDA tools** | none installed in the session container | — | Installed from Ubuntu 24.04: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, nextpnr-ecp5 0.6 (the same versions earlier SilicaFlux projects used). |

## 2. Dependency status

| Dependency | Status for this project |
|---|---|
| NAND device model (P52) | implemented and verified upstream; re-exercised here at pin level by the controller RTL on two simulators |
| DataFabric SFB2 protocol | implemented and verified upstream; the controller is a new SFB2 master, checked by the testbench memory |
| Storage DMA, buffer SRAM, ControlCore firmware (P51) | not touched; integration documented |
| NAND channel controller with geometry discovery, timing modes, multi-LUN / multi-CE scheduling | **missing → implemented here** |
| ONFI specification, vendor datasheets, physical NAND device, NAND I/O cells / NV-DDR PHY, ECC (BCH/LDPC) | **missing → not implemented, not claimed** (docs/08) |

## 3. Unverified items inherited

* P52's array timings and reliability numbers are illustrative; its ONFI timing table is a transcription.
* Nothing in SilicaFlux has run against a physical NAND device; nothing here either.
* No licence file exists in the repository.
