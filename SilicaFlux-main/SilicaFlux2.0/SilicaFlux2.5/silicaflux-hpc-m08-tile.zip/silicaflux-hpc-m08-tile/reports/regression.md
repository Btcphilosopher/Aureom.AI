# Integration regression (verilator)

Tools: {'verilator': 'Verilator 5.020 2024-01-01 rev (Debian 5.020-1)', 'icarus': 'Icarus Verilog version 12.0 (stable) ()', 'yosys': 'Yosys 0.33 (git sha1 2584903a060)', 'python': 'Python 3.13.18'}

| stage | configuration | passed |
|---|---|---|
| stage 1: two-lane vector path (queue + scratchpad + 2-lane array) | `s1_n2` {'NUM_LANES': 2, 'NUM_BANKS': 2} | **4 / 4** |
| stage 2: full baseline tile, every test | `baseline` (baseline) | **30 / 30** |
| stage 3: configuration sweep (n1_b1) | `n1_b1` {'NUM_LANES': 1, 'SCRATCHPAD_BYTES': 16384, 'NUM_BANKS': 1, 'CMD_QUEUE_DEPTH': 2, 'CPL_QUEUE_DEPTH': 2} | **11 / 11** |
| stage 3: configuration sweep (n8_b8) | `n8_b8` {'NUM_LANES': 8, 'NUM_BANKS': 8} | **11 / 11** |
| stage 3: configuration sweep (n16_b16) | `n16_b16` {'NUM_LANES': 16, 'SCRATCHPAD_BYTES': 131072, 'NUM_BANKS': 16} | **11 / 11** |
| stage 3: configuration sweep (n4_dw64) | `n4_dw64` {'DATA_WIDTH': 64} | **11 / 11** |
| stage 3: configuration sweep (n2_dw128) | `n2_dw128` {'NUM_LANES': 2, 'DATA_WIDTH': 128, 'NUM_BANKS': 2} | **11 / 11** |
| stage 3: configuration sweep (n4_buffered) | `n4_buffered` {'CMD_QUEUE_DEPTH': 4, 'DMA_BUFFER_DEPTH': 8, 'CPL_QUEUE_DEPTH': 4} | **11 / 11** |
| stage 3: configuration sweep (n4_rl2_ext2) | `n4_rl2_ext2` {'CMD_QUEUE_DEPTH': 16, 'CPL_QUEUE_DEPTH': 16, 'SPM_READ_LATENCY': 2, 'LSU_MAX_PORTS': 2, 'EXT0_LATENCY': 2} | **11 / 11** |
| stage 3: configuration sweep (n4_rl4) | `n4_rl4` {'NUM_BANKS': 8, 'SPM_READ_LATENCY': 4} | **11 / 11** |
| stage 3: configuration sweep (n4_parity) | `n4_parity` {'SPM_ECC': 1} | **12 / 12** |
| stage 3: configuration sweep (n4_noperf) | `n4_noperf` {'ENABLE_PERF_COUNTERS': 0, 'LSU_MAX_PORTS': 1} | **11 / 11** |

**Total: 145 / 145**

| config | test | seed | result | sim time | statistics |
|---|---|---|---|---|---|
| s1_n2 | s1_vec_basic | 1 | PASS | 0.0 s | test=s1_vec_basic cycles=1554 completions=3 (checked 3) mem_words=192 perf=0 monitored=0 overflow_retries=0 host_xacts=474 |
| s1_n2 | s1_vec_random | 1 | PASS | 0.4 s | test=s1_vec_random cycles=101160 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=33546 |
| s1_n2 | s1_vec_reduce | 1 | PASS | 0.1 s | test=s1_vec_reduce cycles=26771 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=0 host_xacts=8680 |
| s1_n2 | s1_vec_long | 1 | PASS | 0.4 s | test=s1_vec_long cycles=94339 completions=3 (checked 3) mem_words=12288 perf=0 monitored=0 overflow_retries=0 host_xacts=27971 |
| baseline | s1_vec_basic | 1 | PASS | 0.0 s | test=s1_vec_basic cycles=1394 completions=3 (checked 3) mem_words=192 perf=0 monitored=0 overflow_retries=0 host_xacts=444 |
| baseline | s1_vec_random | 1 | PASS | 0.8 s | test=s1_vec_random cycles=100540 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=33438 |
| baseline | s1_vec_reduce | 1 | PASS | 0.2 s | test=s1_vec_reduce cycles=25942 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=0 host_xacts=8543 |
| baseline | s1_vec_long | 1 | PASS | 0.7 s | test=s1_vec_long cycles=84097 completions=3 (checked 3) mem_words=12288 perf=0 monitored=0 overflow_retries=0 host_xacts=26295 |
| baseline | vec_add | 1 | PASS | 0.0 s | test=vec_add cycles=4916 completions=6 (checked 6) mem_words=364 perf=0 monitored=0 overflow_retries=0 host_xacts=851 |
| baseline | vec_mul | 1 | PASS | 0.2 s | test=vec_mul cycles=22491 completions=6 (checked 6) mem_words=1743 perf=0 monitored=0 overflow_retries=0 host_xacts=3716 |
| baseline | vec_fma | 1 | PASS | 0.1 s | test=vec_fma cycles=9570 completions=8 (checked 8) mem_words=539 perf=0 monitored=0 overflow_retries=0 host_xacts=1611 |
| baseline | dma | 1 | PASS | 0.2 s | test=dma cycles=18970 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=1 host_xacts=3512 |
| baseline | ordering | 1 | PASS | 0.3 s | test=ordering cycles=37050 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=73 host_xacts=10633 |
| baseline | contention | 1 | PASS | 0.5 s | test=contention cycles=70000 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=18850 |
| baseline | perf | 1 | PASS | 0.3 s | test=perf cycles=34126 completions=30 (checked 30) mem_words=12553 perf=26 monitored=30 overflow_retries=90 host_xacts=9945 |
| baseline | reset | 1 | PASS | 1.0 s | test=reset cycles=135533 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=20275 |
| baseline | invalid | 1 | PASS | 0.4 s | test=invalid cycles=54515 completions=64 (checked 64) mem_words=11712 perf=0 monitored=0 overflow_retries=3 host_xacts=17800 |
| baseline | backpressure | 1 | PASS | 0.5 s | test=backpressure cycles=64511 completions=29 (checked 29) mem_words=2768 perf=0 monitored=0 overflow_retries=197 host_xacts=9108 |
| baseline | kernels_many | 1 | PASS | 0.7 s | test=kernels_many cycles=87074 completions=40 (checked 40) mem_words=7319 perf=0 monitored=0 overflow_retries=2121 host_xacts=13649 |
| baseline | s1_vec_basic | 101 | PASS | 0.0 s | test=s1_vec_basic cycles=1397 completions=3 (checked 3) mem_words=192 perf=0 monitored=0 overflow_retries=0 host_xacts=443 |
| baseline | s1_vec_random | 101 | PASS | 0.8 s | test=s1_vec_random cycles=100601 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=33448 |
| baseline | s1_vec_reduce | 101 | PASS | 0.2 s | test=s1_vec_reduce cycles=26332 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=11 host_xacts=8590 |
| baseline | s1_vec_long | 101 | PASS | 0.6 s | test=s1_vec_long cycles=84097 completions=3 (checked 3) mem_words=12288 perf=0 monitored=0 overflow_retries=0 host_xacts=26291 |
| baseline | vec_add | 101 | PASS | 0.2 s | test=vec_add cycles=30069 completions=6 (checked 6) mem_words=2338 perf=0 monitored=0 overflow_retries=0 host_xacts=4942 |
| baseline | vec_mul | 101 | PASS | 0.1 s | test=vec_mul cycles=16116 completions=6 (checked 6) mem_words=1243 perf=0 monitored=0 overflow_retries=0 host_xacts=2691 |
| baseline | vec_fma | 101 | PASS | 0.1 s | test=vec_fma cycles=11297 completions=8 (checked 8) mem_words=640 perf=0 monitored=0 overflow_retries=0 host_xacts=1916 |
| baseline | dma | 101 | PASS | 0.1 s | test=dma cycles=18969 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=1 host_xacts=3530 |
| baseline | ordering | 101 | PASS | 0.4 s | test=ordering cycles=43778 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=112 host_xacts=11697 |
| baseline | contention | 101 | PASS | 0.5 s | test=contention cycles=69997 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=18784 |
| baseline | perf | 101 | PASS | 0.3 s | test=perf cycles=34435 completions=30 (checked 30) mem_words=12631 perf=26 monitored=30 overflow_retries=0 host_xacts=10054 |
| baseline | reset | 101 | PASS | 1.1 s | test=reset cycles=148426 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=20405 |
| baseline | invalid | 101 | PASS | 0.4 s | test=invalid cycles=54523 completions=64 (checked 64) mem_words=11712 perf=0 monitored=0 overflow_retries=3 host_xacts=17802 |
| baseline | backpressure | 101 | PASS | 0.4 s | test=backpressure cycles=64712 completions=29 (checked 29) mem_words=2768 perf=0 monitored=0 overflow_retries=198 host_xacts=9158 |
| baseline | kernels_many | 101 | PASS | 0.8 s | test=kernels_many cycles=98251 completions=40 (checked 40) mem_words=8469 perf=0 monitored=0 overflow_retries=2579 host_xacts=15377 |
| n1_b1 | s1_vec_random | 1 | PASS | 0.1 s | test=s1_vec_random cycles=29891 completions=40 (checked 40) mem_words=4096 perf=0 monitored=0 overflow_retries=15 host_xacts=9361 |
| n1_b1 | s1_vec_reduce | 1 | PASS | 0.0 s | test=s1_vec_reduce cycles=10059 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=72 host_xacts=2797 |
| n1_b1 | vec_fma | 1 | PASS | 0.1 s | test=vec_fma cycles=32327 completions=8 (checked 8) mem_words=1597 perf=0 monitored=0 overflow_retries=616 host_xacts=5055 |
| n1_b1 | dma | 1 | PASS | 0.1 s | test=dma cycles=19062 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=396 host_xacts=3381 |
| n1_b1 | ordering | 1 | PASS | 0.2 s | test=ordering cycles=57136 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=512 host_xacts=13754 |
| n1_b1 | contention | 1 | PASS | 0.1 s | test=contention cycles=19879 completions=6 (checked 6) mem_words=2624 perf=1 monitored=0 overflow_retries=0 host_xacts=5180 |
| n1_b1 | invalid | 1 | PASS | 0.1 s | test=invalid cycles=20553 completions=58 (checked 58) mem_words=5568 perf=0 monitored=0 overflow_retries=85 host_xacts=5917 |
| n1_b1 | reset | 1 | PASS | 0.4 s | test=reset cycles=149166 completions=6 (checked 6) mem_words=1020 perf=0 monitored=0 overflow_retries=0 host_xacts=20278 |
| n1_b1 | backpressure | 1 | PASS | 0.2 s | test=backpressure cycles=58624 completions=17 (checked 17) mem_words=1904 perf=0 monitored=0 overflow_retries=246 host_xacts=8140 |
| n1_b1 | kernels_many | 1 | PASS | 0.3 s | test=kernels_many cycles=88769 completions=40 (checked 40) mem_words=6586 perf=0 monitored=0 overflow_retries=3011 host_xacts=13562 |
| n1_b1 | perf | 1 | PASS | 0.2 s | test=perf cycles=39914 completions=30 (checked 30) mem_words=12543 perf=26 monitored=30 overflow_retries=284 host_xacts=10813 |
| n8_b8 | s1_vec_random | 1 | PASS | 1.5 s | test=s1_vec_random cycles=100647 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=33460 |
| n8_b8 | s1_vec_reduce | 1 | PASS | 0.4 s | test=s1_vec_reduce cycles=25981 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=17 host_xacts=8539 |
| n8_b8 | vec_fma | 1 | PASS | 0.5 s | test=vec_fma cycles=35119 completions=8 (checked 8) mem_words=2042 perf=0 monitored=0 overflow_retries=0 host_xacts=5796 |
| n8_b8 | dma | 1 | PASS | 0.3 s | test=dma cycles=18970 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=1 host_xacts=3512 |
| n8_b8 | ordering | 1 | PASS | 0.6 s | test=ordering cycles=41345 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=40 host_xacts=11396 |
| n8_b8 | contention | 1 | PASS | 0.9 s | test=contention cycles=70000 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=18850 |
| n8_b8 | invalid | 1 | PASS | 0.8 s | test=invalid cycles=54515 completions=64 (checked 64) mem_words=11712 perf=0 monitored=0 overflow_retries=3 host_xacts=17800 |
| n8_b8 | reset | 1 | PASS | 1.8 s | test=reset cycles=134595 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=20275 |
| n8_b8 | backpressure | 1 | PASS | 0.9 s | test=backpressure cycles=64511 completions=29 (checked 29) mem_words=2768 perf=0 monitored=0 overflow_retries=197 host_xacts=9108 |
| n8_b8 | kernels_many | 1 | PASS | 1.0 s | test=kernels_many cycles=74914 completions=40 (checked 40) mem_words=6586 perf=0 monitored=0 overflow_retries=2057 host_xacts=11841 |
| n8_b8 | perf | 1 | PASS | 0.6 s | test=perf cycles=38249 completions=30 (checked 30) mem_words=12841 perf=26 monitored=30 overflow_retries=90 host_xacts=10620 |
| n16_b16 | s1_vec_random | 1 | PASS | 7.5 s | test=s1_vec_random cycles=198667 completions=40 (checked 40) mem_words=32768 perf=0 monitored=0 overflow_retries=0 host_xacts=66175 |
| n16_b16 | s1_vec_reduce | 1 | PASS | 2.3 s | test=s1_vec_reduce cycles=51416 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=13 host_xacts=16874 |
| n16_b16 | vec_fma | 1 | PASS | 2.3 s | test=vec_fma cycles=59670 completions=8 (checked 8) mem_words=3486 perf=0 monitored=0 overflow_retries=0 host_xacts=9809 |
| n16_b16 | dma | 1 | PASS | 0.7 s | test=dma cycles=18970 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=1 host_xacts=3512 |
| n16_b16 | ordering | 1 | PASS | 1.7 s | test=ordering cycles=41369 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=39 host_xacts=11393 |
| n16_b16 | contention | 1 | PASS | 2.7 s | test=contention cycles=69998 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=18861 |
| n16_b16 | invalid | 1 | PASS | 3.9 s | test=invalid cycles=103675 completions=64 (checked 64) mem_words=19904 perf=0 monitored=0 overflow_retries=3 host_xacts=34188 |
| n16_b16 | reset | 1 | PASS | 4.8 s | test=reset cycles=134595 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=20275 |
| n16_b16 | backpressure | 1 | PASS | 2.3 s | test=backpressure cycles=64466 completions=29 (checked 29) mem_words=2768 perf=0 monitored=0 overflow_retries=202 host_xacts=9124 |
| n16_b16 | kernels_many | 1 | PASS | 2.9 s | test=kernels_many cycles=74908 completions=40 (checked 40) mem_words=6586 perf=0 monitored=0 overflow_retries=2031 host_xacts=11722 |
| n16_b16 | perf | 1 | PASS | 1.4 s | test=perf cycles=34204 completions=30 (checked 30) mem_words=12557 perf=26 monitored=30 overflow_retries=90 host_xacts=9962 |
| n4_dw64 | s1_vec_random | 1 | PASS | 0.9 s | test=s1_vec_random cycles=100090 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=32768 |
| n4_dw64 | s1_vec_reduce | 1 | PASS | 0.3 s | test=s1_vec_reduce cycles=26316 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=43 host_xacts=8208 |
| n4_dw64 | vec_fma | 1 | PASS | 0.1 s | test=vec_fma cycles=10273 completions=8 (checked 8) mem_words=1090 perf=0 monitored=0 overflow_retries=0 host_xacts=0 |
| n4_dw64 | dma | 1 | PASS | 0.1 s | test=dma cycles=10243 completions=30 (checked 30) mem_words=2347 perf=0 monitored=0 overflow_retries=1 host_xacts=375 |
| n4_dw64 | ordering | 1 | PASS | 0.3 s | test=ordering cycles=35543 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=32 host_xacts=8192 |
| n4_dw64 | contention | 1 | PASS | 0.4 s | test=contention cycles=57674 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=14464 |
| n4_dw64 | invalid | 1 | PASS | 0.4 s | test=invalid cycles=52687 completions=64 (checked 64) mem_words=11712 perf=0 monitored=0 overflow_retries=3 host_xacts=16448 |
| n4_dw64 | reset | 1 | PASS | 0.5 s | test=reset cycles=76757 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=0 |
| n4_dw64 | backpressure | 1 | PASS | 0.2 s | test=backpressure cycles=34985 completions=29 (checked 29) mem_words=2768 perf=0 monitored=0 overflow_retries=145 host_xacts=304 |
| n4_dw64 | kernels_many | 1 | PASS | 0.3 s | test=kernels_many cycles=40607 completions=40 (checked 40) mem_words=6604 perf=0 monitored=0 overflow_retries=1271 host_xacts=0 |
| n4_dw64 | perf | 1 | PASS | 0.2 s | test=perf cycles=30602 completions=30 (checked 30) mem_words=12553 perf=26 monitored=30 overflow_retries=66 host_xacts=8192 |
| n2_dw128 | s1_vec_random | 1 | PASS | 0.5 s | test=s1_vec_random cycles=100575 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=32768 |
| n2_dw128 | s1_vec_reduce | 1 | PASS | 0.1 s | test=s1_vec_reduce cycles=27533 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=96 host_xacts=8208 |
| n2_dw128 | vec_fma | 1 | PASS | 0.1 s | test=vec_fma cycles=12720 completions=8 (checked 8) mem_words=2042 perf=0 monitored=0 overflow_retries=0 host_xacts=0 |
| n2_dw128 | dma | 1 | PASS | 0.0 s | test=dma cycles=6026 completions=30 (checked 30) mem_words=2353 perf=0 monitored=0 overflow_retries=1 host_xacts=375 |
| n2_dw128 | ordering | 1 | PASS | 0.2 s | test=ordering cycles=38698 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=52 host_xacts=8192 |
| n2_dw128 | contention | 1 | PASS | 0.3 s | test=contention cycles=57196 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=14464 |
| n2_dw128 | invalid | 1 | PASS | 0.3 s | test=invalid cycles=53420 completions=64 (checked 64) mem_words=11712 perf=0 monitored=0 overflow_retries=27 host_xacts=16448 |
| n2_dw128 | reset | 1 | PASS | 0.3 s | test=reset cycles=55156 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=0 |
| n2_dw128 | backpressure | 1 | PASS | 0.1 s | test=backpressure cycles=22664 completions=29 (checked 29) mem_words=2768 perf=0 monitored=0 overflow_retries=95 host_xacts=304 |
| n2_dw128 | kernels_many | 1 | PASS | 0.1 s | test=kernels_many cycles=27927 completions=40 (checked 40) mem_words=6648 perf=0 monitored=0 overflow_retries=875 host_xacts=0 |
| n2_dw128 | perf | 1 | PASS | 0.2 s | test=perf cycles=30939 completions=30 (checked 30) mem_words=12543 perf=26 monitored=30 overflow_retries=76 host_xacts=8192 |
| n4_buffered | s1_vec_random | 1 | PASS | 0.8 s | test=s1_vec_random cycles=100658 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=1 host_xacts=33462 |
| n4_buffered | s1_vec_reduce | 1 | PASS | 0.2 s | test=s1_vec_reduce cycles=26442 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=38 host_xacts=8615 |
| n4_buffered | vec_fma | 1 | PASS | 0.1 s | test=vec_fma cycles=12449 completions=8 (checked 8) mem_words=1090 perf=0 monitored=0 overflow_retries=430 host_xacts=1903 |
| n4_buffered | dma | 1 | PASS | 0.1 s | test=dma cycles=13590 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=48 host_xacts=2607 |
| n4_buffered | ordering | 1 | PASS | 0.3 s | test=ordering cycles=37175 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=94 host_xacts=10689 |
| n4_buffered | contention | 1 | PASS | 0.5 s | test=contention cycles=60795 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=17361 |
| n4_buffered | invalid | 1 | PASS | 0.4 s | test=invalid cycles=54039 completions=60 (checked 60) mem_words=11712 perf=0 monitored=0 overflow_retries=5 host_xacts=17682 |
| n4_buffered | reset | 1 | PASS | 0.7 s | test=reset cycles=91362 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=13216 |
| n4_buffered | backpressure | 1 | PASS | 0.4 s | test=backpressure cycles=49387 completions=21 (checked 21) mem_words=2192 perf=0 monitored=0 overflow_retries=134 host_xacts=6952 |
| n4_buffered | kernels_many | 1 | PASS | 0.4 s | test=kernels_many cycles=49267 completions=40 (checked 40) mem_words=6586 perf=0 monitored=0 overflow_retries=1484 host_xacts=7655 |
| n4_buffered | perf | 1 | PASS | 0.3 s | test=perf cycles=31605 completions=30 (checked 30) mem_words=12553 perf=26 monitored=30 overflow_retries=86 host_xacts=9541 |
| n4_rl2_ext2 | s1_vec_random | 1 | PASS | 1.0 s | test=s1_vec_random cycles=133905 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=33533 |
| n4_rl2_ext2 | s1_vec_reduce | 1 | PASS | 0.3 s | test=s1_vec_reduce cycles=35012 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=0 host_xacts=8688 |
| n4_rl2_ext2 | vec_fma | 1 | PASS | 0.2 s | test=vec_fma cycles=28767 completions=8 (checked 8) mem_words=1090 perf=0 monitored=0 overflow_retries=0 host_xacts=4755 |
| n4_rl2_ext2 | dma | 1 | PASS | 0.2 s | test=dma cycles=26668 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=0 host_xacts=4713 |
| n4_rl2_ext2 | ordering | 1 | PASS | 0.4 s | test=ordering cycles=59737 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=0 host_xacts=13060 |
| n4_rl2_ext2 | contention | 1 | PASS | 0.7 s | test=contention cycles=98738 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=21200 |
| n4_rl2_ext2 | invalid | 1 | PASS | 0.5 s | test=invalid cycles=72586 completions=72 (checked 72) mem_words=11712 perf=0 monitored=0 overflow_retries=2 host_xacts=18132 |
| n4_rl2_ext2 | reset | 1 | PASS | 1.4 s | test=reset cycles=199409 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=30883 |
| n4_rl2_ext2 | backpressure | 1 | PASS | 0.7 s | test=backpressure cycles=101997 completions=45 (checked 45) mem_words=3920 perf=0 monitored=0 overflow_retries=304 host_xacts=14501 |
| n4_rl2_ext2 | kernels_many | 1 | PASS | 0.8 s | test=kernels_many cycles=113922 completions=40 (checked 40) mem_words=6586 perf=0 monitored=0 overflow_retries=2506 host_xacts=17867 |
| n4_rl2_ext2 | perf | 1 | PASS | 0.4 s | test=perf cycles=47630 completions=30 (checked 30) mem_words=12553 perf=26 monitored=30 overflow_retries=14 host_xacts=10846 |
| n4_rl4 | s1_vec_random | 1 | PASS | 1.9 s | test=s1_vec_random cycles=199160 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=33484 |
| n4_rl4 | s1_vec_reduce | 1 | PASS | 0.6 s | test=s1_vec_reduce cycles=51263 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=39 host_xacts=8641 |
| n4_rl4 | vec_fma | 1 | PASS | 0.3 s | test=vec_fma cycles=32203 completions=8 (checked 8) mem_words=1090 perf=0 monitored=0 overflow_retries=0 host_xacts=5332 |
| n4_rl4 | dma | 1 | PASS | 0.3 s | test=dma cycles=32719 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=1 host_xacts=5578 |
| n4_rl4 | ordering | 1 | PASS | 0.7 s | test=ordering cycles=75581 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=72 host_xacts=12953 |
| n4_rl4 | contention | 1 | PASS | 1.2 s | test=contention cycles=131891 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=21875 |
| n4_rl4 | invalid | 1 | PASS | 1.0 s | test=invalid cycles=105163 completions=64 (checked 64) mem_words=11712 perf=0 monitored=0 overflow_retries=3 host_xacts=18010 |
| n4_rl4 | reset | 1 | PASS | 2.0 s | test=reset cycles=221916 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=34590 |
| n4_rl4 | backpressure | 1 | PASS | 0.8 s | test=backpressure cycles=91421 completions=29 (checked 29) mem_words=2768 perf=0 monitored=0 overflow_retries=344 host_xacts=12712 |
| n4_rl4 | kernels_many | 1 | PASS | 1.1 s | test=kernels_many cycles=128473 completions=40 (checked 40) mem_words=6586 perf=0 monitored=0 overflow_retries=3507 host_xacts=19841 |
| n4_rl4 | perf | 1 | PASS | 0.6 s | test=perf cycles=63479 completions=30 (checked 30) mem_words=12553 perf=26 monitored=30 overflow_retries=164 host_xacts=10709 |
| n4_parity | s1_vec_random | 1 | PASS | 0.8 s | test=s1_vec_random cycles=100630 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=33454 |
| n4_parity | s1_vec_reduce | 1 | PASS | 0.4 s | test=s1_vec_reduce cycles=50907 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=29 host_xacts=16782 |
| n4_parity | vec_fma | 1 | PASS | 0.5 s | test=vec_fma cycles=68093 completions=8 (checked 8) mem_words=1090 perf=0 monitored=0 overflow_retries=0 host_xacts=19535 |
| n4_parity | dma | 1 | PASS | 0.6 s | test=dma cycles=68115 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=1 host_xacts=19876 |
| n4_parity | ordering | 1 | PASS | 0.6 s | test=ordering cycles=78237 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=36 host_xacts=23675 |
| n4_parity | contention | 1 | PASS | 1.1 s | test=contention cycles=100720 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=29101 |
| n4_parity | invalid | 1 | PASS | 0.6 s | test=invalid cycles=79090 completions=64 (checked 64) mem_words=11712 perf=0 monitored=0 overflow_retries=3 host_xacts=25995 |
| n4_parity | reset | 1 | PASS | 1.4 s | test=reset cycles=183734 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=36649 |
| n4_parity | backpressure | 1 | PASS | 0.8 s | test=backpressure cycles=112889 completions=29 (checked 29) mem_words=2768 perf=0 monitored=0 overflow_retries=197 host_xacts=25321 |
| n4_parity | kernels_many | 1 | PASS | 1.0 s | test=kernels_many cycles=124274 completions=40 (checked 40) mem_words=6586 perf=0 monitored=0 overflow_retries=2008 host_xacts=28044 |
| n4_parity | parity | 1 | PASS | 0.4 s | test=parity cycles=49903 completions=2 (checked 2) mem_words=164 perf=0 monitored=0 overflow_retries=0 host_xacts=16607 |
| n4_parity | perf | 1 | PASS | 0.6 s | test=perf cycles=74924 completions=30 (checked 30) mem_words=12997 perf=26 monitored=30 overflow_retries=33 host_xacts=22915 |
| n4_noperf | s1_vec_random | 1 | PASS | 0.8 s | test=s1_vec_random cycles=102145 completions=40 (checked 40) mem_words=16384 perf=0 monitored=0 overflow_retries=0 host_xacts=33702 |
| n4_noperf | s1_vec_reduce | 1 | PASS | 0.2 s | test=s1_vec_reduce cycles=28464 completions=16 (checked 16) mem_words=16 perf=0 monitored=0 overflow_retries=107 host_xacts=8938 |
| n4_noperf | vec_fma | 1 | PASS | 0.1 s | test=vec_fma cycles=22201 completions=8 (checked 8) mem_words=1090 perf=0 monitored=0 overflow_retries=0 host_xacts=3684 |
| n4_noperf | dma | 1 | PASS | 0.1 s | test=dma cycles=18970 completions=30 (checked 30) mem_words=2344 perf=0 monitored=0 overflow_retries=1 host_xacts=3512 |
| n4_noperf | ordering | 1 | PASS | 0.4 s | test=ordering cycles=56544 completions=60 (checked 60) mem_words=12288 perf=0 monitored=0 overflow_retries=111 host_xacts=13838 |
| n4_noperf | contention | 1 | PASS | 0.5 s | test=contention cycles=76142 completions=6 (checked 6) mem_words=10304 perf=1 monitored=0 overflow_retries=0 host_xacts=19871 |
| n4_noperf | invalid | 1 | PASS | 0.4 s | test=invalid cycles=57736 completions=64 (checked 64) mem_words=11712 perf=0 monitored=0 overflow_retries=65 host_xacts=18292 |
| n4_noperf | reset | 1 | PASS | 0.9 s | test=reset cycles=156185 completions=6 (checked 6) mem_words=1200 perf=0 monitored=0 overflow_retries=0 host_xacts=23856 |
| n4_noperf | backpressure | 1 | PASS | 0.5 s | test=backpressure cycles=70949 completions=29 (checked 29) mem_words=2768 perf=0 monitored=0 overflow_retries=238 host_xacts=10033 |
| n4_noperf | kernels_many | 1 | PASS | 0.6 s | test=kernels_many cycles=87816 completions=40 (checked 40) mem_words=6586 perf=0 monitored=0 overflow_retries=2388 host_xacts=13719 |
| n4_noperf | perf | 1 | PASS | 0.3 s | test=perf cycles=39937 completions=30 (checked 30) mem_words=12553 perf=26 monitored=30 overflow_retries=168 host_xacts=10871 |
