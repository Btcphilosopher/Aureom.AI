# FP32 reference model self-test

Model: `model/fp32_model.py`. Run: 2026-11-07 12:31:12

## 1. numpy float32 (hardware, RNE)

166140 FADD/FSUB/FMUL results compared, 0 mismatches.

## 2. Berkeley SoftFloat-3e (RISC-V specialisation), results and flags

| op | vectors (random rounding mode) |
|---|---|
| FADD | 60000 |
| FSUB | 60000 |
| FMUL | 60000 |
| FMADD | 60000 |
| FMSUB | 60000 |
| FNMSUB | 60000 |
| FNMADD | 60000 |
| FEQ | 60000 |
| FLT | 60000 |
| FLE | 60000 |

Mismatches: **0**.

## 3. Specification corner cases (Module 02 FP_SEMANTICS.md)

| case | result |
|---|---|
| (2^24-1)*2^-150 rounds to min normal and IS tiny after rounding | PASS |
| x - x = +0 | PASS |
| x - x = -0 under RDN | PASS |
| -0 + -0 = -0 | PASS |
| 0 x inf + qNaN raises NV | PASS |
| (+0)*1 + (-0) = +0 (zero product, opposite signs) | PASS |
| (-0)*1 + (-0) = -0 (zero product, equal signs) | PASS |
| (+0)*1 + (-0) = -0 under RDN | PASS |
| -0*1 - +0 = -0 | PASS |
| min(+0, -0) = -0 | PASS |
| max(sNaN, 1) = 1, NV | PASS |
| FEQ quiet on qNaN | PASS |
| FLT signalling on qNaN | PASS |
| overflow under RTZ -> max finite | PASS |
| overflow under RNE -> inf | PASS |
| reduction with N = 1 equals the sequential FP32 loop | PASS |

**Total mismatches: 0** -> PASS
