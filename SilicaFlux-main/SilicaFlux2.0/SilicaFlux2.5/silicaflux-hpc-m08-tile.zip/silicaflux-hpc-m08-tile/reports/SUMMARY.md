# SilicaFlux-HPC Module 08: results summary

Every entry is parsed from the named report, which records the tool versions and the raw data.

| check | result | report |
|---|---|---|
| Reference model vs SoftFloat-3e (RISC-V) + numpy + spec corner cases | 600,000 SoftFloat vectors, mismatches **0** | [model_selftest.md](model_selftest.md) |
| Unit tests: command queue (M06), counters (M07), Verilator + Icarus | **120 / 120** | [unit.md](unit.md) |
| Lint: Verilator -Wall on the new RTL, parameter sweep | **14 / 14** clean | [lint.md](lint.md) |
| Elaboration: Icarus / Yosys (+ latch check), parameter sweep | **14 / 14** / **14 / 14** | [lint.md](lint.md) |
| Illegal parameters rejected by the tile (Verilator + Icarus + Yosys) | **20 / 20** | [lint.md](lint.md) |
| Integration: stage 1: two-lane vector path (queue + scratchpad + 2-lane array) | **4 / 4** | [regression.md](regression.md) |
| Integration: stage 2: full baseline tile, every test | **30 / 30** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n1_b1) | **11 / 11** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n8_b8) | **11 / 11** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n16_b16) | **11 / 11** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n4_dw64) | **11 / 11** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n2_dw128) | **11 / 11** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n4_buffered) | **11 / 11** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n4_rl2_ext2) | **11 / 11** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n4_rl4) | **11 / 11** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n4_parity) | **12 / 12** | [regression.md](regression.md) |
| Integration: stage 3: configuration sweep (n4_noperf) | **11 / 11** | [regression.md](regression.md) |
| Integration regression, total | **145 / 145** | [regression.md](regression.md) |
| Mutation testing of the new RTL | **27 / 27** killed (+1 equivalent) | [mutation.md](mutation.md) |
| Firmware on the SilicaFlux-V CPU (SoC simulation) | **5 / 5** scenarios | [soc.md](soc.md) |
| Measured performance runs (each self-checking) | all PASS | [perf.md](perf.md) |
| ECP5-85F place and route (s1_n2) | routed; 34,292 / 83,640 TRELLIS_COMB; Fmax 34.65 MHz (nextpnr estimate) | [synth.md](synth.md) |
| ECP5-85F place and route (baseline) | routed; 55,992 / 83,640 TRELLIS_COMB; Fmax 31.24 MHz (nextpnr estimate) | [synth.md](synth.md) |
