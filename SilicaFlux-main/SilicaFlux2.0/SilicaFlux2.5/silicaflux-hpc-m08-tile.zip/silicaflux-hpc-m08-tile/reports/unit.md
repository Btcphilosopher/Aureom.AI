# Unit tests: hpc_command_queue (M06), hpc_perf_counters (M07)

**120 / 120 runs passed** (Verilator and Icarus, 3 seeds per parameter set).  Verilator -Wall warnings in the RTL: 0.

| unit | parameters | simulator | seed | result | coverage |
|---|---|---|---|---|---|
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 2} | verilator | 1 | PASS | TB_CQ pushes=7050 pops=7048 push+pop=2484 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 2} | icarus | 1 | PASS | TB_CQ pushes=6949 pops=6944 push+pop=2423 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 2} | verilator | 2 | PASS | TB_CQ pushes=7102 pops=7093 push+pop=2547 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 2} | icarus | 2 | PASS | TB_CQ pushes=7016 pops=7010 push+pop=2461 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 2} | verilator | 3 | PASS | TB_CQ pushes=6971 pops=6964 push+pop=2383 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 2} | icarus | 3 | PASS | TB_CQ pushes=7079 pops=7072 push+pop=2518 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 2} | verilator | 1 | PASS | TB_CQ pushes=6980 pops=6968 push+pop=2468 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 2} | icarus | 1 | PASS | TB_CQ pushes=7042 pops=7036 push+pop=2445 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 2} | verilator | 2 | PASS | TB_CQ pushes=7018 pops=7013 push+pop=2421 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 2} | icarus | 2 | PASS | TB_CQ pushes=7071 pops=7061 push+pop=2472 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 2} | verilator | 3 | PASS | TB_CQ pushes=6995 pops=6986 push+pop=2402 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 2} | icarus | 3 | PASS | TB_CQ pushes=6938 pops=6927 push+pop=2356 resets=12 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 2} | verilator | 1 | PASS | TB_CQ pushes=6973 pops=6963 push+pop=2445 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 2} | icarus | 1 | PASS | TB_CQ pushes=6977 pops=6967 push+pop=2391 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 2} | verilator | 2 | PASS | TB_CQ pushes=7011 pops=7003 push+pop=2442 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 2} | icarus | 2 | PASS | TB_CQ pushes=6982 pops=6980 push+pop=2406 resets=3 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 2} | verilator | 3 | PASS | TB_CQ pushes=7002 pops=6996 push+pop=2472 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 2} | icarus | 3 | PASS | TB_CQ pushes=7017 pops=7014 push+pop=2421 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 4} | verilator | 1 | PASS | TB_CQ pushes=7473 pops=7467 push+pop=2971 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 4} | icarus | 1 | PASS | TB_CQ pushes=7337 pops=7333 push+pop=2925 resets=3 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 4} | verilator | 2 | PASS | TB_CQ pushes=7542 pops=7524 push+pop=3107 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 4} | icarus | 2 | PASS | TB_CQ pushes=7526 pops=7511 push+pop=3024 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 4} | verilator | 3 | PASS | TB_CQ pushes=7404 pops=7381 push+pop=3015 resets=10 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 4} | icarus | 3 | PASS | TB_CQ pushes=7543 pops=7523 push+pop=3072 resets=10 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 4} | verilator | 1 | PASS | TB_CQ pushes=7378 pops=7370 push+pop=2925 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 4} | icarus | 1 | PASS | TB_CQ pushes=7388 pops=7376 push+pop=2946 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 4} | verilator | 2 | PASS | TB_CQ pushes=7569 pops=7562 push+pop=3018 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 4} | icarus | 2 | PASS | TB_CQ pushes=7474 pops=7454 push+pop=2965 resets=12 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 4} | verilator | 3 | PASS | TB_CQ pushes=7340 pops=7319 push+pop=2863 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 4} | icarus | 3 | PASS | TB_CQ pushes=7364 pops=7352 push+pop=2907 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 4} | verilator | 1 | PASS | TB_CQ pushes=7463 pops=7450 push+pop=3012 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 4} | icarus | 1 | PASS | TB_CQ pushes=7414 pops=7395 push+pop=2920 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 4} | verilator | 2 | PASS | TB_CQ pushes=7443 pops=7437 push+pop=2976 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 4} | icarus | 2 | PASS | TB_CQ pushes=7437 pops=7436 push+pop=3010 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 4} | verilator | 3 | PASS | TB_CQ pushes=7300 pops=7296 push+pop=2838 resets=2 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 4} | icarus | 3 | PASS | TB_CQ pushes=7384 pops=7370 push+pop=2951 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 8} | verilator | 1 | PASS | TB_CQ pushes=7720 pops=7705 push+pop=3237 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 8} | icarus | 1 | PASS | TB_CQ pushes=7586 pops=7581 push+pop=3142 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 8} | verilator | 2 | PASS | TB_CQ pushes=7785 pops=7743 push+pop=3319 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 8} | icarus | 2 | PASS | TB_CQ pushes=7687 pops=7657 push+pop=3203 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 8} | verilator | 3 | PASS | TB_CQ pushes=7664 pops=7638 push+pop=3327 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 8} | icarus | 3 | PASS | TB_CQ pushes=7772 pops=7737 push+pop=3334 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 8} | verilator | 1 | PASS | TB_CQ pushes=7640 pops=7620 push+pop=3210 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 8} | icarus | 1 | PASS | TB_CQ pushes=7678 pops=7647 push+pop=3186 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 8} | verilator | 2 | PASS | TB_CQ pushes=7755 pops=7704 push+pop=3237 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 8} | icarus | 2 | PASS | TB_CQ pushes=7715 pops=7693 push+pop=3243 resets=10 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 8} | verilator | 3 | PASS | TB_CQ pushes=7613 pops=7577 push+pop=3174 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 8} | icarus | 3 | PASS | TB_CQ pushes=7636 pops=7606 push+pop=3215 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 8} | verilator | 1 | PASS | TB_CQ pushes=7684 pops=7668 push+pop=3219 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 8} | icarus | 1 | PASS | TB_CQ pushes=7648 pops=7626 push+pop=3201 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 8} | verilator | 2 | PASS | TB_CQ pushes=7727 pops=7711 push+pop=3334 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 8} | icarus | 2 | PASS | TB_CQ pushes=7696 pops=7683 push+pop=3251 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 8} | verilator | 3 | PASS | TB_CQ pushes=7612 pops=7578 push+pop=3171 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 8} | icarus | 3 | PASS | TB_CQ pushes=7645 pops=7595 push+pop=3166 resets=12 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 16} | verilator | 1 | PASS | TB_CQ pushes=7872 pops=7849 push+pop=3374 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 16} | icarus | 1 | PASS | TB_CQ pushes=7713 pops=7699 push+pop=3288 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 16} | verilator | 2 | PASS | TB_CQ pushes=7944 pops=7867 push+pop=3433 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 16} | icarus | 2 | PASS | TB_CQ pushes=7813 pops=7766 push+pop=3299 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 16} | verilator | 3 | PASS | TB_CQ pushes=7804 pops=7732 push+pop=3389 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 16} | icarus | 3 | PASS | TB_CQ pushes=7968 pops=7901 push+pop=3508 resets=11 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 16} | verilator | 1 | PASS | TB_CQ pushes=7711 pops=7689 push+pop=3269 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 16} | icarus | 1 | PASS | TB_CQ pushes=7827 pops=7764 push+pop=3318 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 16} | verilator | 2 | PASS | TB_CQ pushes=8003 pops=7930 push+pop=3493 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 16} | icarus | 2 | PASS | TB_CQ pushes=7875 pops=7811 push+pop=3388 resets=11 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 16} | verilator | 3 | PASS | TB_CQ pushes=7725 pops=7677 push+pop=3271 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 16} | icarus | 3 | PASS | TB_CQ pushes=7793 pops=7755 push+pop=3332 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 16} | verilator | 1 | PASS | TB_CQ pushes=7824 pops=7820 push+pop=3349 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 16} | icarus | 1 | PASS | TB_CQ pushes=7749 pops=7715 push+pop=3346 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 16} | verilator | 2 | PASS | TB_CQ pushes=7762 pops=7746 push+pop=3348 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 16} | icarus | 2 | PASS | TB_CQ pushes=7741 pops=7695 push+pop=3298 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 16} | verilator | 3 | PASS | TB_CQ pushes=7763 pops=7683 push+pop=3328 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 16} | icarus | 3 | PASS | TB_CQ pushes=7870 pops=7786 push+pop=3369 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 32} | verilator | 1 | PASS | TB_CQ pushes=7938 pops=7869 push+pop=3432 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 32} | icarus | 1 | PASS | TB_CQ pushes=7784 pops=7758 push+pop=3297 resets=3 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 32} | verilator | 2 | PASS | TB_CQ pushes=8114 pops=8014 push+pop=3569 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 32} | icarus | 2 | PASS | TB_CQ pushes=7950 pops=7855 push+pop=3384 resets=3 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 32} | verilator | 3 | PASS | TB_CQ pushes=8001 pops=7884 push+pop=3528 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 32} | icarus | 3 | PASS | TB_CQ pushes=8148 pops=8014 push+pop=3590 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 32} | verilator | 1 | PASS | TB_CQ pushes=7846 pops=7779 push+pop=3325 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 32} | icarus | 1 | PASS | TB_CQ pushes=7949 pops=7829 push+pop=3471 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 32} | verilator | 2 | PASS | TB_CQ pushes=8018 pops=7878 push+pop=3444 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 32} | icarus | 2 | PASS | TB_CQ pushes=7960 pops=7847 push+pop=3451 resets=11 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 32} | verilator | 3 | PASS | TB_CQ pushes=7999 pops=7870 push+pop=3411 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 32} | icarus | 3 | PASS | TB_CQ pushes=7988 pops=7942 push+pop=3468 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 32} | verilator | 1 | PASS | TB_CQ pushes=7980 pops=7908 push+pop=3460 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 32} | icarus | 1 | PASS | TB_CQ pushes=7938 pops=7876 push+pop=3487 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 32} | verilator | 2 | PASS | TB_CQ pushes=7905 pops=7859 push+pop=3431 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 32} | icarus | 2 | PASS | TB_CQ pushes=7991 pops=7917 push+pop=3468 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 32} | verilator | 3 | PASS | TB_CQ pushes=8059 pops=7944 push+pop=3534 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 32} | icarus | 3 | PASS | TB_CQ pushes=8136 pops=7887 push+pop=3491 resets=11 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 64} | verilator | 1 | PASS | TB_CQ pushes=8222 pops=8059 push+pop=3618 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 64} | icarus | 1 | PASS | TB_CQ pushes=8057 pops=8002 push+pop=3503 resets=3 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 64} | verilator | 2 | PASS | TB_CQ pushes=8408 pops=8244 push+pop=3689 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 64} | icarus | 2 | PASS | TB_CQ pushes=8299 pops=8121 push+pop=3553 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 64} | verilator | 3 | PASS | TB_CQ pushes=8220 pops=8068 push+pop=3659 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 1, 'DEPTH': 64} | icarus | 3 | PASS | TB_CQ pushes=8447 pops=8203 push+pop=3750 resets=12 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 64} | verilator | 1 | PASS | TB_CQ pushes=8018 pops=7961 push+pop=3442 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 64} | icarus | 1 | PASS | TB_CQ pushes=8225 pops=8068 push+pop=3569 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 64} | verilator | 2 | PASS | TB_CQ pushes=8510 pops=8290 push+pop=3844 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 64} | icarus | 2 | PASS | TB_CQ pushes=8243 pops=8086 push+pop=3551 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 64} | verilator | 3 | PASS | TB_CQ pushes=8159 pops=7991 push+pop=3496 resets=9 |
| tb_hpc_command_queue | {'WIDTH': 37, 'DEPTH': 64} | icarus | 3 | PASS | TB_CQ pushes=8341 pops=8147 push+pop=3630 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 64} | verilator | 1 | PASS | TB_CQ pushes=8367 pops=8111 push+pop=3644 resets=7 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 64} | icarus | 1 | PASS | TB_CQ pushes=8184 pops=8052 push+pop=3548 resets=4 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 64} | verilator | 2 | PASS | TB_CQ pushes=8141 pops=8071 push+pop=3592 resets=5 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 64} | icarus | 2 | PASS | TB_CQ pushes=8301 pops=8211 push+pop=3636 resets=6 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 64} | verilator | 3 | PASS | TB_CQ pushes=8423 pops=8103 push+pop=3687 resets=8 |
| tb_hpc_command_queue | {'WIDTH': 272, 'DEPTH': 64} | icarus | 3 | PASS | TB_CQ pushes=8578 pops=8197 push+pop=3718 resets=12 |
| tb_hpc_perf_counters | {'NUM': 5, 'CW': 10, 'IW': 4} | verilator | 1 | PASS | TB_PC saturations=94396 clears=8 frozen_cycles=1515 |
| tb_hpc_perf_counters | {'NUM': 5, 'CW': 10, 'IW': 4} | icarus | 1 | PASS | TB_PC saturations=95789 clears=6 frozen_cycles=1508 |
| tb_hpc_perf_counters | {'NUM': 5, 'CW': 10, 'IW': 4} | verilator | 2 | PASS | TB_PC saturations=92730 clears=11 frozen_cycles=1450 |
| tb_hpc_perf_counters | {'NUM': 5, 'CW': 10, 'IW': 4} | icarus | 2 | PASS | TB_PC saturations=95863 clears=5 frozen_cycles=1513 |
| tb_hpc_perf_counters | {'NUM': 5, 'CW': 10, 'IW': 4} | verilator | 3 | PASS | TB_PC saturations=94194 clears=9 frozen_cycles=1551 |
| tb_hpc_perf_counters | {'NUM': 5, 'CW': 10, 'IW': 4} | icarus | 3 | PASS | TB_PC saturations=93300 clears=9 frozen_cycles=1613 |
| tb_hpc_perf_counters | {'NUM': 24, 'CW': 8, 'IW': 8} | verilator | 1 | PASS | TB_PC saturations=511104 clears=9 frozen_cycles=1465 |
| tb_hpc_perf_counters | {'NUM': 24, 'CW': 8, 'IW': 8} | icarus | 1 | PASS | TB_PC saturations=510465 clears=6 frozen_cycles=1510 |
| tb_hpc_perf_counters | {'NUM': 24, 'CW': 8, 'IW': 8} | verilator | 2 | PASS | TB_PC saturations=510109 clears=9 frozen_cycles=1518 |
| tb_hpc_perf_counters | {'NUM': 24, 'CW': 8, 'IW': 8} | icarus | 2 | PASS | TB_PC saturations=510119 clears=12 frozen_cycles=1494 |
| tb_hpc_perf_counters | {'NUM': 24, 'CW': 8, 'IW': 8} | verilator | 3 | PASS | TB_PC saturations=509683 clears=3 frozen_cycles=1558 |
| tb_hpc_perf_counters | {'NUM': 24, 'CW': 8, 'IW': 8} | icarus | 3 | PASS | TB_PC saturations=509267 clears=12 frozen_cycles=1517 |
