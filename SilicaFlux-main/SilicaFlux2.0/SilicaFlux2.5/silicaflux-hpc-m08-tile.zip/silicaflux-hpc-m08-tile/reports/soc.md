# Firmware-level SoC simulation (SilicaFlux-V CPU + DataFabric + HPC tile)

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); firmware: clang/lld (RV32I_Zicsr).

| SoC variant | scenario | result | wall time |
|---|---|---|---|
| baseline  | hpc_demo_sram_boot | PASS: `TB_SOC RESULT PASS status=00000001 cycles=160381 chars=743`  | 1.4 s |
| baseline  | sfv_app_sram_boot (unmodified SilicaFlux-V acceptance app) | PASS: `TB_SOC RESULT PASS status=00000001 cycles=2086389 chars=709`  | 15.7 s |
| baseline  | dma_demo_sram_boot (unmodified DataFabric DMA demo) | PASS: `TB_SOC RESULT FAIL status=00000102 cycles=3860970 chars=1293` PASS except the expected check 0x105 (crossbar master count 5, not 4) | 28.1 s |
| baseline  | rom_post_selftest (boot ROM POST, MBIST) | PASS: `TB_SOC RESULT PASS status=00000001 cycles=203122 chars=113`  | 1.7 s |
| lanes2_buffered {'HPC_LANES': 2, 'HPC_BANKS': 2, 'HPC_DMA_BUFFER': 8} | hpc_demo_sram_boot | PASS: `TB_SOC RESULT PASS status=00000001 cycles=159396 chars=743`  | 1.0 s |

**5 / 5 passed.**

## Firmware transcripts (UART, last lines)

### baseline / hpc_demo_sram_boot

```
[H1 probe] checks=6 fails=0
[H2 kernels] checks=27 fails=0
[H3 DMA -> VEC -> DMA] checks=57 fails=0
[H4 host window] checks=64 fails=0
[H5 errors] checks=80 fails=0
[H6 counters] checks=94 fails=0
[H7 soft reset] checks=103 fails=0
RESULT checks=104 fails=0 PASS
```

### baseline / sfv_app_sram_boot (unmodified SilicaFlux-V acceptance app)

```
[T1 reset/identity] checks so far=0 fails=0
[T2 uart] checks so far=12 fails=0
[T3 sram] checks so far=17 fails=0
[T4 vector engine] checks so far=25 fails=0
[T5 tensor engine] checks so far=322 fails=0
[T6 traps & interrupts] checks so far=409 fails=0
[T7 gpio] checks so far=430 fails=0
[T8 soft reset] checks so far=432 fails=0
SFV-APP PHASE1 PASS checks=432 fails=0
SFV-APP RESULT PASS checks=3 fails=0
```

### baseline / dma_demo_sram_boot (unmodified DataFabric DMA demo)

```
[D1 identity] checks=0 fails=0
  FAIL id=00000105 got=00000005 exp=00000004
[D2 SRAM->SRAM copies] checks=5 fails=1
[D3 errors and validation] checks=38 fails=1
[D4 busy protection and abort] checks=79 fails=1
[D5 interrupts] checks=92 fails=1
[D6 tensor end-to-end via DMA] checks=100 fails=1
[D7 vector end-to-end via DMA] checks=140 fails=1
[D9 DMA competing with the tensor engine] checks=154 fails=1
[D8 contention and performance] checks=164 fails=1
[done] checks=177 fails=1
SFV-DF RESULT FAIL checks=177 fails=1
```

### baseline / rom_post_selftest (boot ROM POST, MBIST)

```
POST PASS
```

### lanes2_buffered / hpc_demo_sram_boot

```
[H1 probe] checks=6 fails=0
[H2 kernels] checks=27 fails=0
[H3 DMA -> VEC -> DMA] checks=57 fails=0
[H4 host window] checks=64 fails=0
[H5 errors] checks=80 fails=0
[H6 counters] checks=94 fails=0
[H7 soft reset] checks=103 fails=0
RESULT checks=104 fails=0 PASS
```

