`default_nettype none
module cfg_top (
  input  wire logic clk, rst_n, rb_sel, rb_we, input wire logic [11:0] rb_addr, input wire logic [31:0] rb_wdata,
  output logic [31:0] rb_rdata, output logic rb_err,
  input  wire logic hs_req_valid, output logic hs_req_ready, input wire logic hs_req_write,
  input  wire logic [31:0] hs_req_addr, input wire logic [31:0] hs_req_wdata, input wire logic [3:0] hs_req_wstrb,
  output logic hs_rsp_valid, input wire logic hs_rsp_ready, output logic [31:0] hs_rsp_rdata, output logic hs_rsp_error,
  output logic fab_req_valid, input wire logic fab_req_ready, output logic fab_req_write, output logic [31:0] fab_req_addr,
  output logic [31:0] fab_req_wdata, output logic [3:0] fab_req_wstrb, input wire logic fab_rsp_valid,
  output logic fab_rsp_ready, input wire logic [31:0] fab_rsp_rdata, input wire logic fab_rsp_error,
  output logic irq, busy, halted
);
  silicaflux_hpc_tile #(.NUM_LANES(4), .DATA_WIDTH(32), .SCRATCHPAD_BYTES(65536), .NUM_BANKS(4), .CMD_QUEUE_DEPTH(8), .DMA_BUFFER_DEPTH(0), .ENABLE_PERF_COUNTERS(1), .CPL_QUEUE_DEPTH(8), .SPM_ECC(0), .SPM_READ_LATENCY(1), .LSU_MAX_PORTS(4)) u_tile (.*);
endmodule
`default_nettype wire
