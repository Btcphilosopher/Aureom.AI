`default_nettype none
module fpga_top (input wire logic clk, input wire logic btn, output logic [7:0] led);
  hpc_tile_fpga_harness #(.NUM_LANES(4), .DATA_WIDTH(32), .SCRATCHPAD_BYTES(65536), .NUM_BANKS(4), .CMD_QUEUE_DEPTH(8), .DMA_BUFFER_DEPTH(0), .ENABLE_PERF_COUNTERS(1)) u_h (.*);
endmodule
`default_nettype wire
