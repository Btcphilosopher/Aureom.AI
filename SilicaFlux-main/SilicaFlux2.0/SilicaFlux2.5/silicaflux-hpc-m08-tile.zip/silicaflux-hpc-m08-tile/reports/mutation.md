# Mutation testing of the new RTL

One injected bug per run; KILLED = at least one regression test failed (or timed out).

| id | file | injected bug | config | result | first detecting test |
|---|---|---|---|---|---|
| Q1 | `hpc_command_queue.sv` | queue: pop does not advance the read pointer | baseline | **killed** | s1_vec_random |
| Q2 | `hpc_command_queue.sv` | queue: accepts a push while full (overwrites) | baseline | **killed** | dma |
| P1 | `hpc_perf_counters.sv` | counters: wrap instead of saturating | unit | **killed** | unit tb_hpc_perf_counters FAIL |
| P2 | `hpc_perf_counters.sv` | counters: clear ignored | baseline | **killed** | contention |
| S1 | `hpc_tile_sched.sv` | scheduler: no hazard check for a vector command against the DMA in flight | baseline | **killed** | ordering |
| S2 | `hpc_tile_sched.sv` | scheduler: no hazard check for a DMA against the vector command in flight | baseline | **killed** | perf |
| S3 | `hpc_tile_sched.sv` | scheduler: HALT_ON_ERROR ignored | baseline | **killed** | invalid |
| S4 | `hpc_tile_sched.sv` | scheduler: unsupported opcode not rejected | baseline | **killed** | invalid |
| S5 | `hpc_tile_sched.sv` | scheduler: scratchpad range not validated | baseline | **killed** | invalid |
| S6 | `hpc_tile_sched.sv` | scheduler: partial destination overlap accepted | baseline | **killed** | invalid |
| S7 | `hpc_tile_sched.sv` | kernel: operand C never loaded | baseline | **killed** | vec_fma |
| S8 | `hpc_tile_sched.sv` | scheduler: FENCE ignored | baseline | **killed** | contention |
| S9 | `hpc_tile_sched.sv` | a failed DMA is reported as successful | baseline | **killed** | invalid |
| S10 | `hpc_tile_sched.sv` | FLUSH never cancels | baseline | **killed** | invalid |
| S11 | `hpc_tile_sched.sv` | KERNEL starts while older commands are in flight | baseline | equivalent | the remaining conditions of d_ker (DMA and vector units idle, no unit request pending) already imply that no older command is executing; an older NOP / rejected record still in the ROB retires in order anyway -- removing rob_empty changes no observable behaviour (replaced by S13) |
| S12 | `hpc_tile_sched.sv` | kernel: a failing DMA step does not stop the kernel | baseline | **killed** | invalid |
| S13 | `hpc_tile_sched.sv` | kernel: reduction result stored with the vector length | baseline | **killed** | kernels_many |
| L1 | `hpc_tile_lsu.sv` | LSU: inactive (tail) lanes written (needs >1 lane per word: DATA_WIDTH 64) | n4_dw64 | **killed** | s1_vec_random |
| L2 | `hpc_tile_lsu.sv` | LSU: operand FIFO credit ignored | baseline | **killed** | s1_vec_reduce |
| L3 | `hpc_tile_lsu.sv` | LSU: results still stored after a scratchpad error | n4_parity | **killed** | parity |
| L4 | `hpc_tile_lsu.sv` | LSU: completes before its stores are acknowledged (visible with SPM read latency 4) | n4_rl4 | **killed** | s1_vec_random |
| L5 | `hpc_tile_lsu.sv` | LSU: reduction result never stored | baseline | **killed** | s1_vec_reduce |
| L6 | `hpc_tile_lsu.sv` | a scratchpad error is reported as success | n4_parity | **killed** | parity |
| R1 | `hpc_tile_regs.sv` | DOORBELL accepted when the queue is full (command lost) | baseline | **killed** | dma |
| R2 | `hpc_tile_regs.sv` | CPL_POP does not pop | baseline | **killed** | s1_vec_random |
| R3 | `hpc_tile_regs.sv` | soft reset without quiescing the bus ports | baseline | **killed** | reset |
| T1 | `silicaflux_hpc_tile.sv` | counter: DMA_BYTES_RD counts written bytes | baseline | **killed** | perf |
| T2 | `silicaflux_hpc_tile.sv` | counter: FLOPs ignore the FMA factor 2 | baseline | **killed** | perf |

**27 / 27 non-equivalent mutants killed** (1 equivalent mutant(s) identified and explained).
