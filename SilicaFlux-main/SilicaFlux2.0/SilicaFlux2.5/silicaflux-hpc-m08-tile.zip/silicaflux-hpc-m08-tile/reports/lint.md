# Lint and elaboration

Tools: {'verilator': 'Verilator 5.020 2024-01-01 rev (Debian 5.020-1)', 'icarus': 'Icarus Verilog version 12.0 (stable) ()', 'yosys': 'Yosys 0.33 (git sha1 2584903a060)', 'python': 'Python 3.13.18'}

| check | result |
|---|---|
| Verilator `-Wall`, new RTL (`rtl/`), 14 parameter sets | **14 / 14 clean** (0 warnings) |
| Icarus 12 elaboration, 14 parameter sets | **14 / 14** |
| Yosys 0.33 elaboration + latch check, 14 parameter sets | **14 / 14** latch-free |
| Illegal parameters rejected by the tile (Verilator message + Icarus $fatal + Yosys abort) | **20 / 20** |
| Generated C / Python headers up to date | yes |

## Parameter sets

* `baseline`: own warnings 0
* `{'NUM_LANES': 2, 'NUM_BANKS': 2}`: own warnings 0
* `{'NUM_LANES': 1, 'NUM_BANKS': 1, 'SCRATCHPAD_BYTES': 16384}`: own warnings 0
* `{'NUM_LANES': 8, 'NUM_BANKS': 8}`: own warnings 0
* `{'NUM_LANES': 16, 'NUM_BANKS': 16, 'SCRATCHPAD_BYTES': 131072}`: own warnings 0
* `{'DATA_WIDTH': 64}`: own warnings 0
* `{'NUM_LANES': 2, 'DATA_WIDTH': 128}`: own warnings 0
* `{'NUM_LANES': 16, 'DATA_WIDTH': 128, 'NUM_BANKS': 8}`: own warnings 0
* `{'DMA_BUFFER_DEPTH': 8}`: own warnings 0
* `{'DMA_BUFFER_DEPTH': 128, 'CMD_QUEUE_DEPTH': 128, 'CPL_QUEUE_DEPTH': 2}`: own warnings 0
* `{'ENABLE_PERF_COUNTERS': 0, 'HOST_SPM_PORT': 0, 'LSU_MAX_PORTS': 1}`: own warnings 0
* `{'SPM_ECC': 1, 'SPM_READ_LATENCY': 3}`: own warnings 0
* `{'SCRATCHPAD_BYTES': 16777216, 'NUM_BANKS': 16}`: own warnings 0
* `{'SCRATCHPAD_BYTES': 1024, 'NUM_BANKS': 1}`: own warnings 0

## Negative elaboration tests

| parameters | expected message | Verilator | Icarus | Yosys |
|---|---|---|---|---|
| `{'NUM_LANES': 3}` | NUM_LANES must be | ok | ok | ok |
| `{'NUM_LANES': 32}` | NUM_LANES must be | ok | ok | ok |
| `{'DATA_WIDTH': 16}` | DATA_WIDTH must be | ok | ok | ok |
| `{'DATA_WIDTH': 256}` | DATA_WIDTH must be | ok | ok | ok |
| `{'NUM_BANKS': 3}` | NUM_BANKS must be | ok | ok | ok |
| `{'NUM_BANKS': 32}` | NUM_BANKS must be | ok | ok | ok |
| `{'SCRATCHPAD_BYTES': 48000}` | SCRATCHPAD_BYTES must be | ok | ok | ok |
| `{'SCRATCHPAD_BYTES': 512}` | SCRATCHPAD_BYTES must be | ok | ok | ok |
| `{'SCRATCHPAD_BYTES': 33554432}` | SCRATCHPAD_BYTES must be | ok | ok | ok |
| `{'SPM_BASE': "32'h20001000"}` | SPM_BASE must be aligned | ok | ok | ok |
| `{'CMD_QUEUE_DEPTH': 3}` | CMD_QUEUE_DEPTH must be | ok | ok | ok |
| `{'CMD_QUEUE_DEPTH': 1}` | CMD_QUEUE_DEPTH must be | ok | ok | ok |
| `{'CMD_QUEUE_DEPTH': 256}` | CMD_QUEUE_DEPTH must be | ok | ok | ok |
| `{'CPL_QUEUE_DEPTH': 5}` | CPL_QUEUE_DEPTH must be | ok | ok | ok |
| `{'DMA_BUFFER_DEPTH': 1}` | DMA_BUFFER_DEPTH must be | ok | ok | ok |
| `{'DMA_BUFFER_DEPTH': 6}` | DMA_BUFFER_DEPTH must be | ok | ok | ok |
| `{'DMA_BUFFER_DEPTH': 256}` | DMA_BUFFER_DEPTH must be | ok | ok | ok |
| `{'ENABLE_PERF_COUNTERS': 2}` | ENABLE_PERF_COUNTERS must be | ok | ok | ok |
| `{'HOST_SPM_PORT': 2}` | HOST_SPM_PORT must be | ok | ok | ok |
| `{'LSU_MAX_PORTS': 3}` | LSU_MAX_PORTS must be | ok | ok | ok |

## Warnings inside vendored third-party sources (unmodified, not fixed here)

* `silicaflux-hpc-m04-scratchpad/rtl/hpc_scratchpad.sv: Signal is not used: 'b_we_a'`
* `silicaflux-hpc-m04-scratchpad/rtl/hpc_scratchpad.sv: Signal is not used: 'b_we_b'`
