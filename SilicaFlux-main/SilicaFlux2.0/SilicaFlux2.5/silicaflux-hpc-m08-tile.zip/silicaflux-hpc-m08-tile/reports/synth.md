# Synthesis, resources and timing (actual tool runs)

Tools: Yosys 0.33 (git sha1 2584903a060); "yowasp-nextpnr-ecp5" -- Next Generation Place and Route (Version nextpnr-0.11.1).

Raw logs and statistics: `reports/synth/<config>/`.  Every number below is parsed from those files.

## 1. Generic (technology independent; latch check; memories reported as bits, not mapped)

| config | parameters | latch-free | cells | flip-flops | gates | memory bits |
|---|---|---|---|---|---|---|

Not part of the final run: mapping the flattened tile with abc to a simple gate library took more than 10 minutes per configuration and was cut for time.  Technology-independent elaboration and the latch check of 14 parameter sets are in `reports/lint.md`; the ECP5 / Xilinx mappings below are the resource analysis.

## 2. Xilinx 7-series mapping estimate (Yosys synth_xilinx; scratchpad BACKEND = FPGA)

No Vivado run: device fit, packing and timing are not claimed.

| config | LUT | LUTRAM | FF | CARRY4 | RAMB | DSP48E1 |
|---|---|---|---|---|---|---|
| s1_n2 | 16,664 | 186 | 6,710 | 1,349 | 16 | 15 |
| baseline | 29,091 | 206 | 10,136 | 2,162 | 16 | 29 |

## 3. Lattice ECP5 (tile + timing harness; synth_ecp5, nextpnr-ecp5 on LFE5U-85F CABGA381)

Fmax is nextpnr's post-route static timing estimate for the speed-6 device at seed 1 -- a property of this implementation run, not a measured hardware clock.  The harness registers are included.

| config | LUT4 | CCU2C | TRELLIS_FF | DP16KD (EBR) | MULT18X18D | DPR16X4 | P&R | TRELLIS_COMB used/avail | Fmax |
|---|---|---|---|---|---|---|---|---|---|
| s1_n2 | 24,300 | 3,600 | 6,988 | 32 | 23 | 267 | routed | 34,292 / 83,640 | 34.65 MHz |
| baseline | 41,610 | 5,365 | 10,571 | 32 | 45 | 295 | routed | 55,992 / 83,640 | 31.24 MHz |
