# Measured performance (RTL simulation cycles)

Every run below is also a self-checking test against the reference model (all passed: **yes**).  Cycles = the tile's own CPL_CYCLES (dispatch -> retirement) or testbench cycle stamps.  No clock frequency is implied (see docs/08_fpga_synthesis.md for the post-route estimate).

## E1 Vector unit on scratchpad-resident data (one command, vl elements)

LSU bound = scratchpad accesses available per element: LSU ports x lanes per word / (operands read + 1 store).

| config | lanes | DW | banks | LSU ports | vl | FADD cyc (elem/cyc) | FMUL cyc (elem/cyc) | FMADD cyc (elem/cyc) | LSU bound FADD / FMADD | array peak |
|---|---|---|---|---|---|---|---|---|---|---|
| n1_b1 | 1 | 32 | 1 | 1 | 1024 | 3081 (0.332) | 3081 (0.332) | 4106 (0.249) | 0.333 / 0.25 | 1 |
| s1_n2 | 2 | 32 | 2 | 2 | 1024 | 1545 (0.663) | 1545 (0.663) | 2058 (0.498) | 0.667 / 0.5 | 2 |
| baseline | 4 | 32 | 4 | 4 | 1024 | 777 (1.318) | 777 (1.318) | 1034 (0.99) | 1.333 / 1.0 | 4 |
| n8_b8 | 8 | 32 | 8 | 4 | 1024 | 777 (1.318) | 777 (1.318) | 1034 (0.99) | 1.333 / 1.0 | 8 |
| n16_b16 | 16 | 32 | 16 | 4 | 1024 | 779 (1.315) | 779 (1.315) | 1036 (0.988) | 1.333 / 1.0 | 16 |
| n4_dw64 | 4 | 64 | 4 | 2 | 1024 | 777 (1.318) | 777 (1.318) | 1034 (0.99) | 1.333 / 1.0 | 4 |
| n16_dw128 | 16 | 128 | 8 | 4 | 1024 | 201 (5.095) | 201 (5.095) | 266 (3.85) | 5.333 / 4.0 | 16 |

## E2 KERNEL FMADD end to end (host memory -> scratchpad -> compute -> host memory)

| config | DMA engine | vl | cycles | bytes moved | cycles / element | FLOP / cycle |
|---|---|---|---|---|---|---|
| baseline | simple | 64 | 1128 | 1024 | 17.62 | 0.113 |
| baseline | simple | 256 | 4392 | 4096 | 17.16 | 0.117 |
| baseline | simple | 1024 | 17448 | 16384 | 17.04 | 0.117 |
| n4_buffered | buffered 8 | 64 | 740 | 1024 | 11.56 | 0.173 |
| n4_buffered | buffered 8 | 256 | 2852 | 4096 | 11.14 | 0.18 |
| n4_buffered | buffered 8 | 1024 | 11300 | 16384 | 11.04 | 0.181 |

## E3 DMA / compute overlap, 8 tiles x 512 elements (scale by a broadcast scalar)

| config | serialised (FENCE) cycles | double-buffered cycles | speed-up |
|---|---|---|---|
| baseline | 35080 | 32931 | 1.065 |
| n4_buffered | 22770 | 20627 | 1.104 |

## E4 DMA bandwidth, 16 KiB transfers

| config | host -> SPM B/cyc | SPM -> host B/cyc | SPM -> SPM B/cyc |
|---|---|---|---|
| baseline | 1.0 | 1.0 | 1.0 |
| n4_buffered | 1.599 | 1.599 | 1.599 |

## E5 Command overhead (dispatch -> retirement, cycles)

| NOP | FADD vl = 1 | FMADD vl = 1 | DMA 4 bytes |
|---|---|---|---|
| 1 | 14 | 16 | 10 |
