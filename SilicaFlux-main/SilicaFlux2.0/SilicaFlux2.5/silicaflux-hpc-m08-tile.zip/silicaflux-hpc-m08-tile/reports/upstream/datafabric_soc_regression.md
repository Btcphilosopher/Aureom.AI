# SoC regression: SilicaFlux-V + DataFabric (tb_soc_df)

Verilator 5.020 2024-01-01 rev (Debian 5.020-1).  **18/18 PASS**

Variants: `buffered` = -GDMA_ENGINE=1; `default` = defaults; `fixedprio` = -GARB_MODE=0; `noperf` = -GPERF=0; `sramlib` = -GSRAM_IMPL=1 +define+DF_SRAMLIB

| variant | scenario | result | firmware summary |
|---|---|---|---|
| buffered | dma_demo_buffered_engine | PASS: PASS status=00000001 cycles=3841011 chars=1245 | SFV-DF RESULT PASS checks=177 fails=0 |
| buffered | sfv_sram_direct_boot_app | PASS: PASS status=00000001 cycles=2086389 chars=709 | SFV-APP PHASE1 PASS checks=432 fails=0<br>SFV-APP RESULT PASS checks=3 fails=0 |
| default | dma_demo_jtag_boot | PASS: PASS status=00000001 cycles=7570840 chars=1282 | SFV-DF RESULT PASS checks=177 fails=0 |
| default | dma_demo_spi_flash_boot | PASS: PASS status=00000001 cycles=4431919 chars=1296 | SFV-DF RESULT PASS checks=177 fails=0 |
| default | dma_demo_sram_boot | PASS: PASS status=00000001 cycles=3853563 chars=1247 | SFV-DF RESULT PASS checks=177 fails=0 |
| default | sfv_jtag_load_boot_app | PASS: PASS status=00000001 cycles=4273849 chars=773 | SFV-APP PHASE1 PASS checks=432 fails=0<br>SFV-APP RESULT PASS checks=3 fails=0 |
| default | sfv_mbist_fault_bank0 | PASS: PASS expected-failure-detected status=00000102 cycles=195973 |  |
| default | sfv_mbist_fault_detect | PASS: PASS expected-failure-detected status=00000102 cycles=195972 |  |
| default | sfv_rom_post_selftest | PASS: PASS status=00000001 cycles=203122 chars=113 |  |
| default | sfv_spi_flash_boot_app | PASS: PASS status=00000001 cycles=3101307 chars=807 | SFV-APP PHASE1 PASS checks=432 fails=0<br>SFV-APP RESULT PASS checks=3 fails=0 |
| default | sfv_sram_direct_boot_app | PASS: PASS status=00000001 cycles=2086389 chars=709 | SFV-APP PHASE1 PASS checks=432 fails=0<br>SFV-APP RESULT PASS checks=3 fails=0 |
| fixedprio | dma_demo_fixed_priority | PASS: PASS status=00000001 cycles=3853563 chars=1247 | SFV-DF RESULT PASS checks=177 fails=0 |
| fixedprio | sfv_sram_direct_boot_app | PASS: PASS status=00000001 cycles=2086389 chars=709 | SFV-APP PHASE1 PASS checks=432 fails=0<br>SFV-APP RESULT PASS checks=3 fails=0 |
| noperf | sfv_rom_post_selftest | PASS: PASS status=00000001 cycles=203122 chars=113 |  |
| noperf | sfv_sram_direct_boot_app | PASS: PASS status=00000001 cycles=2086389 chars=709 | SFV-APP PHASE1 PASS checks=432 fails=0<br>SFV-APP RESULT PASS checks=3 fails=0 |
| sramlib | dma_demo_sramlib_banks | PASS: PASS status=00000001 cycles=3853563 chars=1247 | SFV-DF RESULT PASS checks=177 fails=0 |
| sramlib | sfv_rom_post_selftest | PASS: PASS status=00000001 cycles=203122 chars=113 |  |
| sramlib | sfv_sram_direct_boot_app | PASS: PASS status=00000001 cycles=2086389 chars=709 | SFV-APP PHASE1 PASS checks=432 fails=0<br>SFV-APP RESULT PASS checks=3 fails=0 |
