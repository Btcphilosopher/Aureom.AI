# 10 — Measured performance and bottlenecks

All figures come from `reports/perf.md`: RTL simulation cycles measured by the tile itself (CPL_CYCLES) or by
testbench cycle stamps. Every measured run is also a self-checking test against the reference model. No
clock frequency is implied by these numbers (see doc 08 for the post-route estimate).

## 1. Vector unit (scratchpad-resident data, vl = 1024)

| Configuration | FADD elem/cycle | FMADD elem/cycle | LSU bound FADD / FMADD | array peak |
|---|---|---|---|---|
| 1 lane, 32-bit, 1 bank | 0.332 | 0.249 | 0.333 / 0.25 | 1 |
| 2 lanes, 32-bit, 2 banks | 0.663 | 0.498 | 0.667 / 0.5 | 2 |
| **4 lanes, 32-bit, 4 banks (baseline)** | **1.318** | **0.990** | 1.333 / 1.0 | 4 |
| 8 lanes, 32-bit, 8 banks | 1.318 | 0.990 | 1.333 / 1.0 | 8 |
| 16 lanes, 32-bit, 16 banks | 1.315 | 0.988 | 1.333 / 1.0 | 16 |
| 4 lanes, 64-bit, 4 banks | 1.318 | 0.990 | 1.333 / 1.0 | 4 |
| 16 lanes, 128-bit, 8 banks | 5.095 | 3.850 | 5.333 / 4.0 | 16 |

* The load/store unit reaches **≥ 95 % of the scratchpad-port bound in every configuration** (lowest: 5.095 / 5.333 at 16 lanes, 128 bit):
  * the bound is `LSU ports × elements per word / (operands read + 1 store)`;
  * there are no bank conflicts in these runs, because word interleaving puts lane l on bank l.
* The array itself could take N elements per cycle. **The tile is limited by scratchpad port bandwidth, not by
  the lanes.**
  * With 32-bit words, more than 4 lanes gives no speed-up, because the scratchpad allows at most 8 ports
    (4 go to the LSU).
  * Wider words help: 128-bit words with 16 lanes give 5.1 FADD / 3.9 FMADD elements per cycle.
  * Next steps: wider LSU words (a 2RW / 1R1W bank port mode), or operand reuse.

## 2. End-to-end KERNEL (FMADD: host → scratchpad → compute → host)

| DMA engine | cycles / element (vl = 1024) | FLOP / cycle |
|---|---|---|
| simple (baseline, one transaction in flight) | 17.0 | 0.117 |
| buffered, 8-word FIFO, 2 outstanding | 11.0 | 0.181 |

A kernel moves 16 bytes per element: 3 operands in and 1 result out. The DMA path moves 1.0 B/cycle
(simple) or 1.6 B/cycle (buffered) on the 32-bit SFB2 fabric (E4). That accounts for ~16 and ~10 cycles per
element; compute adds ~1. **Kernels are DMA-bound.** This is the expected behaviour of a single 32-bit
fabric port (Module 03 already noted the 16 B/element requirement).

## 3. Overlap

Eight tiles of 512 elements, with independent DMA-in of the next tile during compute: **1.065×** (simple)
and **1.104×** (buffered) faster than the FENCE-serialised version. The gain is small for the same reason:
compute is ~1/8 of the DMA time. The mechanism works: OVERLAP > 0, results exact, and FENCE gives
OVERLAP = 0.

## 4. Command overhead

Dispatch → retirement:

| Command | cycles |
|---|---|
| NOP | 1 |
| FADD, vl = 1 | 14 |
| FMADD, vl = 1 | 16 |
| 4-byte DMA | 10 |

Host submission costs more: 9 register writes per command through the bridge, about 30 cycles in the
testbench. So many small commands are host-bound, and KERNEL (one command for the whole sequence) is the
efficient form.
