# 05 — Error model and propagation

## 1. Principle

Every accepted command produces exactly one completion record, and its STATUS says what happened. Two rules
follow:
* A failure is never reported as OK.
* An invalid command never executes.

Each error path is exercised by the `invalid`, `parity` and `reset` tests (status coverage below), and the
mutants S4, S5, S6, S9, S12, L3 and L6 inject exactly these failures (`reports/mutation.md`).

## 2. Errors detected before execution (no side effect)

| Cause | Detected by | STATUS (DETAIL) |
|---|---|---|
| reserved TYPE | scheduler | BAD_TYPE |
| reserved W0 bits | scheduler | BAD_RSVD |
| **unsupported opcode**, illegal RM, illegal reduction | scheduler, with the array's own rule `hpc_varray_pkg::cmd_legal` | BAD_OP |
| VL = 0 or VL > VL_MAX | scheduler | BAD_VL |
| misaligned vector / staging address | scheduler | ALIGN |
| **scratchpad address range outside the window** | scheduler | SPM_RANGE |
| partial destination overlap | scheduler | OVERLAP |
| DMA zero length, length > 2^24, misalignment, 2^32 overflow, src/dst overlap | reused DataFabric `dma_validate` | DMA_ERR (1..7) |
| DMA range crossing the scratchpad window boundary | Module 05 REGION rule | DMA_ERR (11), ERR_ADDR = boundary |

An unsupported opcode is stopped twice:
1. The scheduler never sends it to a unit. The record is created directly in the reorder buffer.
2. Even if a defect let it through, the array would execute nothing and report `cpl_illegal`, mapped to
   ARRAY_ILL.

Tests check that the destination of every rejected command is unchanged.

## 3. Errors during execution

| Cause | Path | STATUS (DETAIL), ERR_ADDR |
|---|---|---|
| DMA read / write answered with an error (unmapped address, fabric decode error, slave error, scratchpad RANGE / PARITY on the DMA port) | DataFabric engine stops at the failing beat → Module 05 completion → scheduler | DMA_ERR (8 READ_BUS / 9 WRITE_BUS), the failing address; COUNT = bytes written and acknowledged (contiguous prefix) |
| KERNEL step failure | kernel sequencer stops at the failing step; later steps never run | DMA_ERR or SPM_ERR, STEP = the step, ERR_ADDR |
| **scratchpad error on a vector access** (parity; any code Module 04 reports) | LSU records the first error (code, word address) and issues no further store of the command; the operand stream continues so that the array's framing rule holds | SPM_ERR (code), ERR_ADDR = word address — on **the command that made the access** |
| array reports illegal | LSU | ARRAY_ILL |

**A DMA failure is never reported as success.**
* A DMA command's record carries the engine's error code.
* In a KERNEL, a failing LOAD step ends the command before COMPUTE, and a failing STORE step reports
  DMA_ERR with STEP = STORE_D.

Mutants S9 (DMA status forced OK) and S12 (kernel continues after a failing step) are both detected.

## 4. Halt, resume, flush

* CFG.HALT_ON_ERROR (reset 1): dispatch stops as soon as an older command is known to have failed, and
  STATUS.HALTED is set when its record retires. Commands stay queued; IRQ_STATUS.HALT is raised.
  * **RESUME** continues with the queued commands.
  * **FLUSH** completes every not-yet-dispatched command with CANCELLED (one record each, in order), then
    clears HALTED.
* With HALT_ON_ERROR = 0 every command executes and reports its own status.
* While halted the DCR and the queue still accept commands, up to their capacity. Then DOORBELL is refused
  (`rb_err`, STATUS.SUBMIT_OVF). The `invalid` test fills the queue in this state, checks the refusal, then
  flushes.

## 5. Host-interface errors

* DOORBELL with a full queue (or during a soft reset): `rb_err`, SUBMIT_OVF, nothing queued. The driver
  checks CMDQ_FREE first, so it never triggers this.
* Unmapped register offsets and writes to read-only registers: `rb_err`, no effect.
* Host scratchpad window: scratchpad RANGE / ALIGN / STROBE / PARITY errors become SFB2 error responses (R8).
  With HOST_SPM_PORT = 0, every access answers an error.

## 6. Resets

* **Hard reset** (`rst_n`, asynchronous assert, synchronous release; shared with the fabric, SFB2 R11):
  * everything in flight is discarded; no record is produced for it;
  * configuration returns to its reset values;
  * counters and SUBMITTED are cleared.
* **Soft reset** (CTRL.SOFT_RESET, status in STATUS.SOFT_RESET):
  1. *Quiesce*: no dispatch; no new DMA descriptor reaches the adapter; the active transfer is aborted at
     its next beat boundary (`cmd_abort`); the host scratchpad window stops accepting. The sequencer waits
     until the DMA engine is idle and **no tile bus transaction is outstanding**, because a master may not be
     reset with a transaction in flight (R11).
  2. *Reset*: the tile domain is held in reset for 4 cycles.
  3. *Release*: synchronous; one more quiesced cycle, then idle.

  After a soft reset:
  * the queues are empty and the tile is idle;
  * memory contents are kept, so writes of interrupted commands may be partially done;
  * configuration, interrupt state, counters and SUBMITTED are kept (always-on domain).

  If an external slave never answers, the soft reset waits for it. Hard reset is the recovery.
* The `reset` test applies 4 soft and 2 hard resets at random points inside a long KERNEL and its queued
  follower, checks that the tile is idle with empty queues, and that a following workload computes exactly.
  A testbench monitor checks the R11 guarantee directly: the tile-domain reset never asserts while a DMA or
  host-window transaction is outstanding (mutant R3, which skips the quiesce, is caught by it).

## 7. Status coverage of the regression (baseline, one seed)

| STATUS | records in the `invalid` test |
|---|---|
| OK | 26 |
| BAD_TYPE / BAD_RSVD / BAD_OP / BAD_VL | 1 / 1 / 5 / 2 |
| ALIGN / SPM_RANGE / OVERLAP | 2 / 3 / 1 |
| DMA_ERR (codes 1, 2, 3, 4, 5, 7, 8, 9, 11; kernel steps LOAD_B and STORE_D) | 14 |
| CANCELLED | 9 |
| SPM_ERR (PARITY) | `parity` test, ECC configuration |
