# 08 — FPGA compatibility, synthesis, resources and timing

## 1. FPGAFlow

**No FPGAFlow exists in the repository** (no file, directory or module of that name in any archive;
`docs/00_repository_audit.md`). No flow was invented under that name.

The repository's actual FPGA practice is:
* the SilicaFlux-V `fpga/ulx3s` build;
* the Module 03 place-and-route of the vector array.

Both are Yosys `synth_ecp5` + `nextpnr-ecp5` on the **ULX3S (Lattice ECP5 LFE5U-85F, CABGA381)** with a
25 MHz clock. Module 08 uses the same tools and board (`scripts/run_fpga.py`):

* **The generic tile names no device.** The board appears only in the harness constraint file the script
  writes (clock pin G2, button R1, LEDs).
* **Memory:** the scratchpad uses the SRAM Wrapper Library's FPGA backend (`SPM_BACKEND = 1`, block-RAM
  inference); the simulations use the GENERIC backend.
* **Harness:** the tile has about 3·DATA_WIDTH + 200 I/O signals, more than the board has. Like Module 03,
  `fpga/hpc_tile_fpga_harness.sv` drives every input from LFSR-loaded registers and folds every output into a
  registered signature on the LEDs, so all paths are register to register and no logic can be removed. It is
  a timing / area harness, **not** a functional test.

## 2. Flows run

| Step | Tool | Configurations | Result source |
|---|---|---|---|
| Elaboration + latch check | Yosys 0.33 (`read_verilog -defer`, `hierarchy -check`, `proc`, select-assert no latches) | 14 parameter sets | `reports/lint.md` |
| Lint | Verilator 5.020 `-Wall` | 14 parameter sets | `reports/lint.md` |
| Functional simulation | Verilator 5.020 | 12 configurations | `reports/regression.md`, `reports/soc.md` |
| Synthesis, Lattice ECP5 | Yosys `synth_ecp5` | baseline, 2-lane | `reports/synth/<config>/ecp5_stat.txt` |
| Synthesis, Xilinx 7-series mapping | Yosys `synth_xilinx` (no Vivado) | 2-lane, baseline | `reports/synth/<config>/xilinx_stat.txt` |
| Place and route + static timing | nextpnr-ecp5 0.11.1, `--85k --package CABGA381 --freq 25` | baseline, 2-lane | `reports/synth/<config>/pnr.log`, `pnr_report.json` |

The summary table with every parsed number is in `reports/synth.md`.

## 3. Results (from `reports/synth.md`)

**Lattice ECP5 LFE5U-85F (ULX3S), tile + harness, nextpnr-ecp5 post-route, 25 MHz constraint**

| Configuration | TRELLIS_COMB | TRELLIS_FF | DP16KD (EBR) | MULT18X18D | Post-route Fmax | 25 MHz |
|---|---|---|---|---|---|---|
| baseline: 4 lanes, 64 KiB, 4 banks, simple DMA | 55,992 / 83,640 (66 %) | 10,571 / 83,640 (12 %) | 32 / 208 (15 %) | 45 / 156 (28 %) | **31.24 MHz** | PASS |
| stage 1: 2 lanes, 64 KiB, 2 banks | 34,292 / 83,640 (41 %) | 6,988 | 32 / 208 | 23 / 156 | **34.65 MHz** | PASS |

* **Block RAM:** the 64 KiB scratchpad maps entirely to block RAM, 32 × DP16KD (= 64 KiB / 2 KiB). The
  command and completion queues map to distributed RAM (DPR16X4).
* **Critical path, both configurations:** inside the Module 02 lane's FMA (`u_array.g_lane[0].u_lane.u_fma`).
  * baseline: 32.0 ns = 10.0 ns logic + 22.0 ns routing;
  * 2-lane: 28.9 ns = 10.8 ns logic + 18.1 ns routing.
  * This is the same limit Module 03 measured for the array alone (32.15 MHz at 4 lanes). The tile's own
    logic (scheduler, LSU, queues, DMA adapter, registers) is not on the critical path.
* **Comparison with the array alone:** Module 03's 4-lane array alone used 41,971 TRELLIS_COMB. The complete
  baseline tile, harness included, uses 55,992.
* **8 lanes:** ECP5 synthesis was not completed in the final run. Module 03's 8-lane array alone already used
  81,007 of 83,640 TRELLIS_COMB, so an 8-lane tile is not expected to fit an ECP5-85F.

**Xilinx 7-series (Yosys `synth_xilinx` mapping; no Vivado)**

| Configuration | LUT | LUTRAM | FF | CARRY4 | RAMB36 | DSP48E1 |
|---|---|---|---|---|---|---|
| baseline | 29,091 | 206 | 10,136 | 2,162 | 16 | 29 |
| 2 lanes | 16,664 | 186 | 6,710 | 1,349 | 16 | 15 |

## 4. Reading the numbers

* **ECP5 utilisation** and **Fmax** are nextpnr's post-route figures for the speed-6 device at seed 1. They
  describe this implementation run. They are **not** a measured hardware clock.
* **Xilinx-7 numbers** are Yosys technology-mapping counts. Without Vivado, no device fit, packing or timing
  is claimed for Xilinx.
* **Generic numbers** were not produced in the final run. Mapping the flattened tile with abc to a simple
  gate library took more than 10 minutes per configuration and was cut for time. The ECP5 and Xilinx
  mappings are the resource analysis.
* No ASIC area, power or timing is claimed (no PDK flow is available).

## 5. Hardware validation

**Not performed.** No FPGA board is attached to this environment, no bitstream was generated or programmed,
and nothing ran on hardware. FPGA hardware validation is a separate gate and remains open.
