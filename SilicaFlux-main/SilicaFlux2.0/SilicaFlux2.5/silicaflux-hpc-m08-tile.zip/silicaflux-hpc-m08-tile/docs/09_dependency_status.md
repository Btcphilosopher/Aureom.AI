# 09 — Dependency status report

The status of every component the tile depends on, how it is used, and what was verified here. "Re-verified"
means the module's own regression was re-run in this environment on a fresh archive extraction
(`reports/upstream/`). "Integration-verified" means it is exercised inside the tile by the Module 08
regression (`reports/regression.md`).

| Dependency | Version / source | Used as | Modified? | Re-verified here | Integration-verified | Open issues relevant to the tile |
|---|---|---|---|---|---|---|
| Module 01 `fp32_fma` | archive `silicaflux-hpc-fp32-fma.zip` | not instantiated; its SoftFloat-3e copy is used by the model self-test | no | lint + Verilator stress vs SoftFloat-3e: 0 mismatches | — | the lane uses its own FMA (M02). Swapping in M01 would need an M02 change and re-verification. |
| Module 02 `hpc_vector_lane` (+ FP units) | via Module 03 `rtl/lane/` (byte-identical to M02 `rtl/`) | inside the array | no | through Module 03 | yes: every element operation, all rounding modes, specials, bit-exact with flags | the lane's FMA segment sets Fmax (Module 03 measured 32 MHz on ECP5) |
| Module 03 `hpc_vector_array` | archive `silicaflux-hpc-m03-vector-array.zip` | vector execution array, `PERF_EN = 0`, `RED_EN = 1` | no | 72 / 72 | yes: N = 1, 2, 4, 8, 16; reductions in defined order | no memory port by design: supplied by the new LSU |
| Module 04 `hpc_scratchpad` | archive `silicaflux-hpc-m04-scratchpad.zip` | banked scratchpad, 1RW banks, LOW map, RR, `WRITE_ACK = 1`, `PERF_EN = 0` | no | 133 / 133 | yes: 1, 2, 4, 8, 16 banks; RL 1, 2, 4; byte parity; 32 / 64 / 128-bit | 8-port maximum limits the LSU to 4 ports. 2 unused-signal lint warnings inside it (not fixed: vendored unmodified). |
| Module 05 `hpc_dma_adapter`, `hpc_dma_spm_port` | archive `silicaflux-hpc-m05-dma-adapter.zip` | single DMA path (`DUAL_PORT = 0`); the host scratchpad window | no | 75 / 75 + integration 4 / 4 | yes: simple and buffered engines; REGION / bus-error paths; abort during soft reset | unaligned transfers rejected, as in DataFabric |
| DataFabric DMA engines, `dma_validate`, `dma_fifo` | archive `silicaflux-datafabric.zip` | inside the adapter | no | SoC regression 18 / 18 | yes | — |
| DataFabric `sfb_crossbar`, `sfb_sram_slave`, `sfb_v1_slave_adapter`, `sfb_protocol_checker` | same | testbench host side; SoC | no | 18 / 18 | yes (protocol checker on every SFB2 link: 0 violations) | SFB2 rev 2.0: one outstanding transaction per crossbar port, which bounds the DMA path |
| DataFabric memory-map generator | same, `python/datafabric/memmap_gen.py` | generates the HPC SoC map from `soc/memmap/silicaflux_v_hpc.yaml` | no | output cross-checked against `sfv_pkg.sv` by the generator | yes (SoC builds) | — |
| SilicaFlux-V CPU, boot ROM, peripherals, firmware library | via DataFabric `third_party/silicaflux-v` | host CPU in `sfv_soc_hpc` | no | 18 / 18 | yes: firmware controls the tile, 104 checks pass; the unmodified acceptance app passes on the new SoC | RV32I without FPU: the firmware compares bit patterns |
| SRAM Wrapper Library | archive `silicaflux-sramlib.zip` | scratchpad banks (GENERIC simulation, FPGA inference), SoC SRAM | no | through M04 / M05 / DataFabric | yes | ASIC macros not exercised here (no PDK) |
| Berkeley SoftFloat-3e | Module 01 archive `third_party/` | reference-model self-test only | no | 600 000 vectors, 0 mismatches against the model | — | — |
| **Module 06 command queue** | **new** (`rtl/hpc_command_queue.sv`) | command and completion queues | — | unit: 108 / 108 runs (Verilator + Icarus) | yes | — |
| **Module 07 performance counters** | **new** (`rtl/hpc_perf_counters.sv`) | 24 tile counters | — | unit: 12 / 12 runs | yes (deterministic and monitored counters) | — |
| **FPGAFlow** | **not present** in the repository | — | — | — | — | Module 08 uses Yosys + nextpnr-ecp5 directly (`scripts/run_fpga.py`). No vendor flow (Vivado / Radiant) is available. |
| PCIe or another off-chip host link | **not present** | — | — | — | — | **not implemented, not claimed** |

## Toolchain

* Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33 (+ yosys-abc): Ubuntu 24.04 packages.
* nextpnr-ecp5 0.11.1: YoWASP build (`pip install yowasp-nextpnr-ecp5`).
* clang / lld 18 for RISC-V (RV32I_Zicsr, ilp32).
* gcc 13 (SoftFloat build), Python 3.13 with numpy.
