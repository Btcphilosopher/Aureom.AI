# 01 — Tile architecture

`rtl/silicaflux_hpc_tile.sv` integrates the verified SilicaFlux-HPC components into one synthesizable compute
tile that executes commands, moves data, performs FP32 vector arithmetic and returns results.

## 1. Block diagram

```
        host register bus (rb_*, one 4 KiB page)              host scratchpad window (hs_*, SFB2 slave)
                 |                                                         |
 +---------------v------------------------------------------------------+  |    ALWAYS-ON DOMAIN (rst_n)
 | hpc_tile_regs   CMD0..7 staging, DOORBELL, CPL_* read-back, CTRL,    |  |
 |                 CFG, STATUS, IRQ, PERF[i] read-back, soft-reset FSM  |  |
 | hpc_perf_counters (M07: 24 saturating 32-bit counters)               |  |
 +----+-----------------------------------------------^-----------------+  |
      | push {SEQ, W7..W0}                            | head / pop          |
 +----v-----------------------+               +-------+-------------+     |    TILE DOMAIN
 | hpc_command_queue (M06)    |               | completion queue    |     |    (rst_n AND soft reset)
 | CMD_QUEUE_DEPTH x 272 bit  |               | (hpc_command_queue) |     |
 +----+-----------------------+               +-------^-------------+     |
      v                                               | in order           |
 +------------------------------------------------------------------+      |
 | hpc_tile_sched   DCR -> validate -> dispatch (hazard check) -> ROB |      |
 |                  KERNEL micro-sequencer, HALT / RESUME / FLUSH   |      |
 +-------+-------------------------------------------+--------------+      |
         | descriptor / completion                   | job / done          |
 +-------v---------------------------+     +---------v-----------------+   |
 | hpc_dma_adapter (M05)             |     | hpc_tile_lsu (new)        |   |
 |  DataFabric dma_transfer_engine / |     |  load walkers, operand    |   |
 |  dma_burst_engine (unmodified)    |     |  FIFOs, store path,       |   |
 +--+-----------------------+--------+     |  reduction store          |   |
    | 1 SPM port            | SFB2         +--+-------------+----------+   |
    |                       | master          | P SPM ports | cmd / operand / result / completion
    |                       |                 |     +-------v-------------------------+
    |                       |                 |     | hpc_vector_array (M03)          |
    |                       |                 |     |  NUM_LANES x hpc_vector_lane    |
    |                       |                 |     |  (M02, FP32 FADD/FMUL/FMA ...)  |
    |                       |                 |     +---------------------------------+
 +--v-----------------------|-----------------v------------------------------v---+
 | hpc_scratchpad (M04): ports 0..P-1 = LSU, P = DMA, P+1 = host (hpc_dma_spm_port)|
 |   NUM_BANKS x 1RW banks, word-interleaved, per-bank round robin, WRITE_ACK = 1  |
 +---------------------------------------------------------------------------------+
                            | fab_* SFB2 master -> DataFabric crossbar -> host-visible memory
```

## 2. Subsystems (the brief's list)

| # | Subsystem | Implementation |
|---|---|---|
| 1 | Host command interface | `hpc_tile_regs`: CMD0..CMD7 staging registers + DOORBELL on the SilicaFlux-V register bus (docs 02, 03) |
| 2 | Command queue | `hpc_command_queue` (Module 06, new), FIFO of `{SEQ, descriptor}` |
| 3 | Scheduler | `hpc_tile_sched` (new): validation before any side effect, in-order dispatch, DMA/vector overlap only for independent commands, reorder buffer for in-order completion, KERNEL sequencing, halt / resume / flush |
| 4 | Vector execution array | `hpc_vector_array` (Module 03, unmodified) fed by `hpc_tile_lsu` (new load/store unit) |
| 5 | Banked scratchpad | `hpc_scratchpad` (Module 04, unmodified) |
| 6 | DMA adapter | `hpc_dma_adapter` (Module 05, unmodified) on the reused DataFabric DMA engine, single DMA path |
| 7 | Completion interface | completion queue + CPL_* registers (tag, status, type, detail, flags, step, seq, count, result, err_addr, cycles) + CPL_POP |
| 8 | Performance counters | `hpc_perf_counters` (Module 07, new), 24 counters (doc 03 §4) |
| 9 | Error / status interface | STATUS (busy, halted, flushing, soft reset, queue levels, sticky ERR / SUBMIT_OVF), IRQ_EN / IRQ_STATUS, `irq` / `busy` / `halted` outputs, per-command status codes (doc 05) |

## 3. Clock and reset

* One clock domain (`clk`). There is no CDC.
* `rst_n` follows the SilicaFlux / DataFabric convention: active low, asynchronous assert, synchronous
  release (`sfv_rst_sync` at SoC level), shared with the fabric (SFB2 R11).
* The **tile domain** reset is `rst_n AND sr_tile_rst_n`. `sr_tile_rst_n` is a register of the soft-reset
  sequencer, so assertion is asynchronous and release is synchronous.
  * It is asserted only after the tile's bus ports are quiet (doc 05 §6).
  * It covers the command and completion queues, the scheduler, the LSU, the array, the scratchpad control
    and the DMA adapter.
  * Scratchpad and host memory contents are not reset (no SRAM has a reset).
* The **always-on domain** (`rst_n` only) holds the register block (configuration, interrupt state,
  SUBMITTED counter) and the performance counters.
* Control registers are reset; datapath registers are not (SilicaFlux rule 4). Queue storage is never
  observable while empty.

## 4. Parameters and legality

| Parameter | Default | Legal | Meaning |
|---|---|---|---|
| `NUM_LANES` | 4 | 1, 2, 4, 8, 16 | FP32 lanes (Module 03) |
| `DATA_WIDTH` | 32 | 32, 64, 128 | scratchpad / DMA / host-bus word (SFB2 widths) |
| `SCRATCHPAD_BYTES` | 65536 | power of two, 1 KiB .. 16 MiB, at least 2 words per bank | scratchpad capacity |
| `NUM_BANKS` | 4 | 1, 2, 4, 8, 16 | scratchpad banks (1RW each) |
| `CMD_QUEUE_DEPTH` | 8 | power of two, 2 .. 128 | queued commands |
| `DMA_BUFFER_DEPTH` | 0 | 0 = simple engine (one transaction in flight); power of two 2 .. 128 = buffered engine (FIFO and burst of that many words, 2 outstanding) | DMA path |
| `ENABLE_PERF_COUNTERS` | 1 | 0, 1 | 0: no counters built, PERF[i] reads 0, CPL_CYCLES reads 0 |
| `SPM_BASE` | `0x2000_0000` | aligned to `SCRATCHPAD_BYTES` | scratchpad window (DataFabric TSPM base; the SoC uses `0x6000_0000`) |
| `CPL_QUEUE_DEPTH` | 8 | power of two, 2 .. 128 | queued completion records |
| `HOST_SPM_PORT` | 1 | 0, 1 | host scratchpad window present (0: every hs access answers an error) |
| `LSU_MAX_PORTS` | 4 | 1, 2, 4 | scratchpad ports used by the LSU (total ports = LSU ports + 2 ≤ 8, the M04 limit) |
| `SPM_READ_LATENCY`, `SPM_ECC`, `SPM_BACKEND`, `SPM_MACRO` | 1, NONE, GENERIC, 0 | as Module 04 | passed to the scratchpad (byte parity, FPGA block-RAM inference, ASIC macros) |

Every illegal value stops elaboration with a message from `silicaflux_hpc_tile` itself. The datapath is only
elaborated when the configuration is legal (`g_core`), so a sub-module never reports first. This is checked
by 20 negative elaboration tests on Verilator, Icarus and Yosys (`reports/lint.md`).

The generic tile instantiates no FPGA device, vendor primitive or ASIC macro. The memory implementation is
the SRAM Wrapper Library's BACKEND choice.

## 5. Vector data layout and the load/store unit

* Vectors are arrays of 32-bit elements at DATA_WIDTH/8-aligned addresses.
* A scratchpad word holds `EPW = DATA_WIDTH/32` elements.
* A **group** is one word access serving `LPW = min(NUM_LANES, EPW)` consecutive lanes. A beat of
  `NUM_LANES` elements is `WPB = NUM_LANES / LPW` groups.
* Group *j* is always served by scratchpad port *j mod P* (`P = min(WPB, LSU_MAX_PORTS)`), so its responses
  arrive in order. Each group has an operand-set FIFO of 2 beats, reserved by a credit before its first load.
* Loads stream ahead of the array, and stores (byte strobes = result mask) have priority on a port. A
  presented request is held until accepted.
* `rsp_ready` is 1 on every LSU port, so the scratchpad never back-pressures the LSU's responses.
* The unit is bounded by scratchpad port bandwidth: per element it needs one access per operand read plus
  one store. The throughput limit is therefore `P · LPW / (operands + 1)` elements per cycle, against an
  array peak of `NUM_LANES` (measured: `reports/perf.md` E1).
* Completion of a vector command means the array's completion record is in and **every store has been
  acknowledged** (scratchpad `WRITE_ACK = 1`).

## 6. What is new and what is reused

| New (this module) | Reused unmodified |
|---|---|
| `silicaflux_hpc_tile`, `hpc_tile_sched`, `hpc_tile_lsu`, `hpc_tile_regs`, `hpc_command_queue` (M06), `hpc_perf_counters` (M07), `hpc_tile_defs.svh` | M02 lane, M03 array, M04 scratchpad, M05 DMA adapter (+ host-port adapter `hpc_dma_spm_port`), DataFabric DMA engines / FIFO / validation, SRAM Wrapper Library |
