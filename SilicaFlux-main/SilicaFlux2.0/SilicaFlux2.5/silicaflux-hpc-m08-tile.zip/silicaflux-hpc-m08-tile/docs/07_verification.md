# 07 — Verification

## 1. Method

1. **Independent software reference.**
   * `model/fp32_model.py` is an exact FP32 model (rational arithmetic, all five rounding modes, flags,
     RISC-V NaN rules, the Module 03 reduction order). It was written from the specification, not the RTL.
   * It is self-tested against Berkeley SoftFloat-3e (RISC-V specialisation) on results **and** flags
     (600 000 vectors) and against numpy's hardware float32 (166 140 vectors): **0 mismatches**
     (`reports/model_selftest.md`).
   * `model/tile_model.py` models the tile's command semantics: validation rules, DMA rules (DataFabric
     `dma_validate` + REGION), KERNEL steps, completion records, memory effects and deterministic counters.
2. **Generated, self-checking programs.**
   * `scripts/gen_tests.py` turns test recipes into programs. Each program holds the initial memory, the host
     operations, the expected completion records in order, the expected counters and the expected final
     memory. Every expected value comes from the model.
   * The model refuses to read never-written memory, and refuses to (re)initialise a word that a command has
     already written. This protects against generator mistakes; it caught two during bring-up.
3. **The real system around the tile.**
   * The testbench host reaches the tile through the unmodified DataFabric crossbar and the SilicaFlux-V
     peripheral bridge.
   * Host memory is a SilicaFlux SRAM Wrapper Library SRAM plus a fault-injecting slave.
   * `sfb_protocol_checker` watches the host port, the tile DMA port and the tile host window: 0 violations
     in every run.
4. **Checks per run.**
   * every completion record: TAG, STATUS, TYPE, DETAIL, FFLAGS, STEP, SEQ, COUNT, RESULT, ERR_ADDR;
   * every word of every checked memory range;
   * deterministic counters against the model;
   * timing-dependent counters against the testbench's own port monitors (exact, with the counters frozen);
   * the vector unit's completion contract, by a monitor: no store outstanding at completion;
   * the soft-reset guarantee, by a monitor: no tile bus transaction outstanding when the tile-domain reset
     asserts.
5. **Negative controls and mutation testing.**
   * A corrupted expected memory word and a corrupted expected flag field are both reported (the testbench
     really compares).
   * Injected RTL bugs are detected (`reports/mutation.md`).

## 2. Brief §9 test list → tests

| Required test | Test recipe(s) | What is checked |
|---|---|---|
| Vector addition | `vec_add`, `s1_vec_basic`, `s1_vec_random` | KERNEL FADD host → host; FADD / FSUB on the scratchpad, every rounding mode, specials, tails |
| Vector multiplication | `vec_mul`, `s1_vec_*` | KERNEL FMUL; FMUL with broadcast |
| Vector FMA | `vec_fma`, `s1_vec_long` | FMADD / FMSUB / FNMSUB / FNMADD kernels, one rounding; scratchpad-filling vector lengths |
| DMA load and store | `dma` | host → SPM, SPM → host, SPM → SPM, host → host; 1-byte to 4 KiB lengths, partial-word tails; both external slaves |
| Command ordering | `ordering`, `kernels_many` (FENCE) | random DMA / VEC / NOP / FENCE over shared buffers (RAW, WAR, WAW, independent pairs): completion order and final memory equal sequential execution |
| Scratchpad contention | `contention` | vector unit, DMA and host traffic on the scratchpad at once: exact results, SPM_CONFLICTS > 0, OVERLAP > 0. With FENCE: OVERLAP exactly 0 |
| Counter correctness | `perf` (+ PERF lines in other tests) | 13 deterministic counters vs the model; 15 timing counters vs port monitors, frozen; clear and freeze |
| Reset during execution | `reset` | soft and hard reset at random points inside a long KERNEL with a queued DMA; idle and empty afterwards; exact recovery workload |
| Invalid commands | `invalid`, `parity` | every validation rule, DMA validation / REGION / bus errors, kernel step errors, HALT / RESUME / FLUSH, DOORBELL overflow, register-map errors; destinations untouched; scratchpad parity error on the command that read it |
| Backpressure | `backpressure` | 70 % request stalls and 1–9 cycle latency on host memory; host response back-pressure; completion queue full (CPLQ_STALL > 0); command queue full with DOORBELL refusals |
| Multiple consecutive kernels | `kernels_many`, `vec_fma` | 40 random kernels (every operation, reductions, broadcasts, rounding modes, FENCE) |

## 3. Staged bring-up (as the brief asks)

1. **Stage 1: command queue + scratchpad + two-lane vector engine.** Configuration `s1_n2` (2 lanes,
   2 banks), tests `s1_vec_*`, 3 seeds: 12 / 12 before any DMA test was run.
2. **Stage 2: full baseline** (4 FP32 lanes, 4 banks, single simple DMA path, in-order completion): all 15
   tests.
3. **Stage 3: configuration sweep** (lane count, data width, banks, DMA buffering, latencies, parity,
   counters off, small scratchpad, depth-2 queues).

`scripts/run_tests.py --stage all` stops at the first failing stage. Final results: `reports/regression.md`.

## 4. Unit tests of the new blocks

`hpc_command_queue` (6 depths × 3 widths) and `hpc_perf_counters` (2 parameter sets) were each tested on
Verilator and Icarus with 3 seeds (`reports/unit.md`). Coverage includes random push/pop with
back-pressure, FIFO order, flags, stability, asynchronous reset, saturation, freeze and clear.

## 5. Mutation testing

`scripts/run_mutants.py` injects 28 bugs into the new RTL, one at a time: queue (2), counters (2), scheduler
(13: hazards, halt, validation, kernel sequencing, fence, flush, status mapping), LSU (6: strobes, credits,
error suppression, completion, reduction), register block (3: doorbell, pop, soft reset) and counter wiring
(2).

**Final result: 27 / 27 non-equivalent mutants killed, plus 1 equivalent mutant identified** (S11: the
condition it removes is implied by the remaining dispatch conditions). Details: `reports/mutation.md`.

The mutation runs found real weaknesses in the tests. Each one was fixed by strengthening the tests, never
the RTL, and the affected mutants were re-run. Logs: `reports/mutation_run1_partial.log`,
`reports/mutation_run2.log`.

| Survivor | Why it survived | Strengthening |
|---|---|---|
| S8 FENCE ignored | with the hazard check, FENCE only changes timing | `contention`: a fenced independent DMA must give OVERLAP = 0 exactly |
| L1 tail lanes written | equivalent at DATA_WIDTH 32 (one lane per word) | run on DATA_WIDTH 64 |
| L3 stores after a parity error | the parity test ignored the whole destination | from the failing beat on, the destination must keep its old contents (deterministic) |
| L4 done before store acks | invisible with read latency 1 (the ack arrives first) | completion-contract monitor + a read-latency-4 configuration (`n4_rl4`) |
| S13 reduction STORE_D length | kernel destinations compared on the result word only | whole destination region compared |
| T1 DMA read / write counters swapped | every DMA length was a multiple of the word | a 1001-byte transfer in `perf` (1004 bytes read, 1001 written) |
| R3 soft reset without quiescing | depended on a transaction being outstanding by chance | monitor: no tile bus transaction may be outstanding when the tile reset asserts; 4 soft resets per `reset` run |

## 6. What is not claimed

* No formal proof of the new RTL. SymbiYosys is not available.
* No gate-level simulation.
* No Icarus cross-simulation of the full integration testbench. The unit tests and the RTL elaboration run
  on Icarus; the integration testbench uses SystemVerilog queues and strings that Verilator supports.
* No FPGA or silicon run (`docs/08_fpga_synthesis.md`).
