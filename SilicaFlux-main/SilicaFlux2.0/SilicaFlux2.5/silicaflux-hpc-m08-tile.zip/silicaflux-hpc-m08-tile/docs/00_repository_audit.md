# 00 — Repository audit and integration readiness

Repository `btcphilosopher/Aureom.AI`, branch `claude/epic-albattani-tv5m7y`, HEAD `03981c2`. The SilicaFlux
material is in `SilicaFlux-main/` as archives; the SilicaFlux-HPC modules are in
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. Every archive used below was extracted into a scratch
directory and read. **Nothing in the repository was modified and nothing was committed.**

Nothing was assumed from the modules' own reports. Each upstream module's regression was **re-run in this
environment** on fresh extractions (logs: `reports/upstream/`), and every vendored file was byte-compared
with its archive.

## 1. Integration readiness table

| Brief item | Found | Archive (SHA-256, first 16 hex) | Re-verified here | Status for Module 08 |
|---|---|---|---|---|
| `fp32_fma.sv` (Module 01) | yes | `silicaflux-hpc-fp32-fma.zip` (`8ca1a6d8c80466632`) | `make lint vtb`: lint clean; Verilator stress vs SoftFloat-3e (RISC-V and ARM specialisations), 6 configurations × 5 runs, millions of operations, **0 mismatches** (`reports/upstream/m01.log`) | **Verified, not in the datapath.** The Module 02 lane has its own verified FMA (`hpc_fp32_fma`). Using M01 inside the lane would mean modifying the verified M02 lane, so it was not done. M01 stays available as an alternative FMA core. Its SoftFloat-3e copy is reused to self-test the reference model. |
| `hpc_vector_lane.sv` (Module 02) | yes | `silicaflux-hpc-m02-vector-lane.zip` (`e76a238e14311`) | Reused through Module 03, whose `rtl/lane/` is byte-identical to M02's `rtl/` (checked) | **Ready**, used unmodified (inside the array) |
| `hpc_vector_array.sv` (Module 03) | yes | `silicaflux-hpc-m03-vector-array.zip` (`c1b6d2946c5bb`) | `make quick`: **72 / 72** (N = 2, 4) | **Ready**, used unmodified. It has no memory port (by design), so the new `hpc_tile_lsu` feeds it. |
| `hpc_scratchpad.sv` (Module 04) | yes | `silicaflux-hpc-m04-scratchpad.zip` (`1457466c57542`) | `make spm-quick`: **133 / 133** | **Ready**, used unmodified: LSU ports + DMA port + host port, `WRITE_ACK = 1` |
| `hpc_dma_adapter.sv` (Module 05) | yes | `silicaflux-hpc-m05-dma-adapter.zip` (`655b66849494`) | `make dma-quick`: **75 / 75**; `make dma-integ`: **4 / 4** | **Ready**, used unmodified (single DMA path). `hpc_dma_spm_port` is also reused for the host scratchpad window. |
| `hpc_command_queue.sv` (Module 06) | **no** | none: no file or module with that name or function in any archive | — | **Missing → implemented** (smallest legitimate version, `rtl/hpc_command_queue.sv`, unit-tested) |
| `hpc_perf_counters.sv` (Module 07) | **no** | none (the modules carry fixed per-block counter sets) | — | **Missing → implemented** (`rtl/hpc_perf_counters.sv`, unit-tested) |
| SilicaFlux CPU | yes | SilicaFlux-V release 1 (`sfv_cpu`, RV32I_Zicsr), vendored in `silicaflux-datafabric.zip` (`9f1f37357c8e2`) | DataFabric SoC firmware regression **18 / 18** (`reports/upstream/datafabric_soc_regression.md`) | **Ready**: the tile is integrated in a derived SoC and driven by firmware on this CPU (`docs/06_host_software.md`) |
| DataFabric | yes | `silicaflux-datafabric.zip` (SFB2 crossbar, DMA engines, SRAM slaves, memory-map generator, protocol checker) | same 18 / 18 SoC run; M05's regression covers the reused engines | **Ready**: the crossbar, SRAM slaves and protocol checker are used unmodified in the testbench and the SoC |
| SRAM wrappers | yes | `silicaflux-sramlib.zip` (`13b1cee1f913d`) | covered by M04 / M05 / DataFabric runs | **Ready** (inside the scratchpad and the SoC SRAM banks) |
| FPGAFlow | **no** | no file, directory or module named FPGAFlow / fpga_flow in any archive | — | **Missing → no flow was invented.** The repository's existing FPGA practice is the ULX3S (ECP5-85F) Yosys + nextpnr-ecp5 build of SilicaFlux-V and Module 03. Module 08 provides the same kind of flow (`scripts/run_fpga.py`) behind a timing harness; the generic tile names no device. |
| Clock / reset convention | yes | DataFabric ARCHITECTURE.md / SFB2 PROTOCOL.md R11 | — | One functional clock; `rst_n` active low, asynchronous assert, synchronous release (`sfv_rst_sync` upstream). Adopted unchanged. |
| Bus protocol | yes | SFB2 (DataFabric PROTOCOL.md): valid/ready request + response, one beat, at most one outstanding per crossbar port | — | Used for the host scratchpad window and the DMA master. **No AXI or PCIe** was introduced. |
| Register bus | yes | SilicaFlux-V `sfv_periph_bridge` register bus (4 KiB pages) | — | The tile's registers are one register-bus page (like every SilicaFlux-V / DataFabric peripheral) |

## 2. Integrity of the vendored sources

`third_party/` holds byte-identical copies of the files Module 08 builds against. All 163 files were
compared with a fresh extraction of their archives (0 differences). `third_party/SHA256SUMS` lists them,
and `third_party/PROVENANCE.md` names each source archive.

## 3. Tools in this environment

Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33 (Ubuntu 24.04 packages, the same versions the earlier
modules used), nextpnr-ecp5 0.11.1 (YoWASP build from PyPI), clang/lld 18 for RV32I firmware, and Python
3.13 with numpy. **Not available:** Vivado / Quartus / Radiant, a PDK or Liberty flow, SymbiYosys, and any
FPGA board or hardware.
