#!/usr/bin/env python3
"""Prove that scheduling policies 0 (round-robin) and 1 (age) are UNCHANGED by the policy-2 work.

The pristine original RTL + testbench (baseline_orig/) and the modified RTL + testbench are built
for the same parameters and driven with the same programs, launch patterns, downstream timing
profiles and seeds.  Everything observable must match exactly:

    global issue order (wg, warp, pc)  -  cycle count  -  every performance counter  -
    per-thread registers  -  global memory  -  fault record  -  assertion maxima

A single differing cycle changes the issue order or the cycle count, so equality is a
cycle-exact equivalence over the whole corpus (directed tests + random programs).

    check_baseline_equiv.py [--random N]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "tests"))
from sfx_isa import assemble
from sfx_gen import gen_program, make_init_mem
from sfx_run import RtlConfig, run_rtl, ROOT
import directed
import random


class OrigConfig(RtlConfig):
    """Same parameters, but built from baseline_orig/ (original RTL and original testbench)."""
    def build(self, force=False):
        b = self.binary()
        if os.path.exists(b) and not force:
            return b
        env = dict(os.environ, SFX_RTL_DIR=os.path.join(ROOT, "baseline_orig", "rtl"),
                   SFX_TB_DIR=os.path.join(ROOT, "baseline_orig", "tb"))
        subprocess.run([os.path.join(ROOT, "build", "build_sim.sh"), self.name] + self.gflags(),
                       check=True, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        return b


PAIRS = {  # name -> (original config, modified config)
    "policy0/32x8": (OrigConfig("orig_rr32"), RtlConfig("rr32")),
    "policy1/32x8": (OrigConfig("orig_age32", sched_policy=1), RtlConfig("age32", sched_policy=1)),
    "policy0/8x4":  (OrigConfig("orig_rr8", num_warps=4, num_wgs=2, warp_size=8), RtlConfig("rr8", num_warps=4, num_wgs=2, warp_size=8)),
    "policy1/8x16": (OrigConfig("orig_age8", num_warps=16, num_wgs=8, warp_size=8, sched_policy=1, starve_limit=24),
                     RtlConfig("age8", num_warps=16, num_wgs=8, warp_size=8, sched_policy=1, starve_limit=24)),
}


def signature(r):
    return dict(ok=r.ok, order=r.order, cycles=r.cycles, cnt=r.cnt, regs=r.regs, mem=r.mem, fault=r.fault,
                chk_max_wait=r.extra.get("chk_max_wait"), chk_bound=r.extra.get("chk_bound"))


def diff(a, b):
    for k in a:
        if a[k] != b[k]:
            if k == "order":
                n = min(len(a[k]), len(b[k]))
                i = next((i for i in range(n) if a[k][i] != b[k][i]), n)
                return f"issue order differs at instruction #{i}: orig={a[k][i] if i < len(a[k]) else None} new={b[k][i] if i < len(b[k]) else None}"
            if k == "cnt":
                bad = [x for x in a[k] if a[k][x] != b[k].get(x)]
                return f"counters differ: {[(x, a[k][x], b[k].get(x)) for x in bad[:4]]}"
            return f"{k} differs: orig={str(a[k])[:80]} new={str(b[k])[:80]}"
    return None


def one(job):
    name, (oc, nc), prog, mem, nth, nwgs, prof, seed, gap, reps, extra = job
    a = run_rtl(oc, prog, mem, nth, nwgs, prof, seed, gap, reps, extra_args=extra)
    b = run_rtl(nc, prog, mem, nth, nwgs, prof, seed, gap, reps, extra_args=extra)
    return name, signature(a), signature(b), (nth, nwgs, prof, seed, gap)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--random", type=int, default=60, help="random programs per policy/geometry")
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()

    for oc, nc in PAIRS.values():
        oc.build(); nc.build()
    jobs = []
    mem0 = make_init_mem(1234)
    twins = {"rr32": "policy0/32x8", "age32": "policy1/32x8", "rr8": "policy0/8x4", "age8": "policy1/8x16"}
    for t in directed.all_tests():
        for cname in t.cfgs:
            pn = twins.get(cname)
            if not pn:
                continue
            lanes = PAIRS[pn][1].warp_size
            prog = assemble(directed._asm(t, lanes)).words
            nth = directed._nth(t, lanes, PAIRS[pn][1].num_warps)
            for prof in t.profiles:
                jobs.append((f"{t.name}", PAIRS[pn], prog, mem0, nth, t.nwgs, prof, 11 + prof, t.launch_gap, t.reps, t.extra_args))
    for pn, pair in PAIRS.items():
        lanes, nw = pair[1].warp_size, pair[1].num_warps
        for s in range(1, a.random + 1):
            rng = random.Random(s * 7919 + lanes)
            nth = max(1, min(rng.randint(1, nw * lanes), nw * lanes))
            nwgs = rng.randint(1, 4)
            prof = rng.choice([0, 1, 2, 2, 3, 4, 5])
            src = gen_program(s, lanes, nth, max_div_depth=rng.choice([2, 3]), size=rng.randint(0, 2))
            prog = assemble(src).words
            jobs.append((f"random#{s}", pair, prog, make_init_mem(s), nth, nwgs, prof, s, rng.choice([0, 3, 20]), 1, ()))
    # the original testbench has no +trace mode, so the comparison uses the original random profiles 0..5
    fails = 0
    done = 0
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for name, sa, sb, par in ex.map(one, jobs):
            done += 1
            d = diff(sa, sb)
            if d or not sa["ok"]:
                fails += 1
                if fails <= 10:
                    print(f"  MISMATCH {name} {par}: {d or 'original run failed'}")
    print(f"[baseline-equiv] {done} runs across {len(PAIRS)} policy/geometry pairs: "
          f"{'IDENTICAL (cycle-exact)' if fails == 0 else str(fails) + ' MISMATCHES'}")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
