#!/usr/bin/env python3
"""Run every workload instance on every scheduling policy and collect metrics.

Equivalence of workloads
  * the SAME program image, initial memory, launch configuration and latency trace file are fed
    to every policy (a sha256 fingerprint of all of them is stored with each run and the report
    refuses to compare runs whose fingerprints differ);
  * every run is checked bit-exactly against the reference model (per-warp issue stream
    (pc, active mask), final registers, global memory, barrier episodes, counters);
    ANY mismatch, assertion failure, trace misalignment or timeout aborts the comparison - a
    policy is never compared on a workload it executed incorrectly;
  * the in-RTL assertions (-DSFX_CHECKS) and the independent monitor (tb/sfx_sched_monitor.sv)
    are active in every run.

Metrics per run: see metrics().  Output: a JSON list (one record per run).

    compare_policies.py --set test --out results/raw_test.json
    compare_policies.py --set dev  --variants rr,age,aware --out results/raw_dev.json
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import hashlib
import json
import math
import os
import pickle
import sys
import time
from typing import Dict, List, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from sfx_run import RtlConfig, run_rtl, compare, ROOT
from sfx_isa import read_hex
from sfx_gen import make_init_mem

DEV_SEEDS = list(range(1, 7))
TEST_SEEDS = list(range(101, 117))

GEOMETRIES = {            # name -> (NUM_WARPS, NUM_WGS)
    "g8":  (8, 4),
    "g16": (16, 8),
}

# policy variants: name -> (SCHED_POLICY, plusargs for policy 2)
ZERO_W = ["+sc_w_cls_alu=0", "+sc_w_cls_mem=0", "+sc_w_cls_br=0", "+sc_w_cls_ctrl=0", "+sc_w_ld=0", "+sc_w_memdep=0",
          "+sc_w_dep=0", "+sc_w_bar=0", "+sc_w_rel=0", "+sc_w_cap=0", "+sc_w_age=0"]
VARIANTS: Dict[str, tuple] = {
    "rr":       (0, []),                       # baseline: deterministic class round-robin (existing default)
    "age":      (1, []),                       # existing age-aware policy with starvation guard
    "aware":    (2, []),                       # policy 2, default weights (fixed before any measurement)
    "aware_w0": (2, ZERO_W),                   # ablation: policy-2 machinery with every weight 0 (rotating priority + guards)
}


def cfg_for(geom: str, policy: int) -> RtlConfig:
    nw, ng = GEOMETRIES[geom]
    return RtlConfig(f"cmp_{geom}_p{policy}", num_warps=nw, num_wgs=ng, sched_policy=policy, starve_limit=2 * nw)


def load_variants_file(path: str):
    """extra variants (e.g. a tuned configuration) from a JSON file {name: {field: value}}"""
    if not path or not os.path.exists(path):
        return
    for name, fields in json.load(open(path)).items():
        VARIANTS[name] = (2, [f"+sc_{k}={v}" for k, v in fields.items()])


def jain(xs: List[float]) -> float:
    xs = [x for x in xs if x is not None]
    if not xs:
        return float("nan")
    s, q = sum(xs), sum(x * x for x in xs)
    return (s * s) / (len(xs) * q) if q > 0 else 1.0


def pct(xs: List[float], p: float) -> float:
    if not xs:
        return float("nan")
    ys = sorted(xs)
    k = (len(ys) - 1) * p
    lo, hi = int(math.floor(k)), int(math.ceil(k))
    return ys[lo] + (ys[hi] - ys[lo]) * (k - lo)


def metrics(r, meta) -> dict:
    c = r.cnt
    cyc = c["cycles"]
    m = dict(cycles=cyc, issued=c["issued"], idle=c["idle"], ipc=c["issued"] / cyc, idle_frac=c["idle"] / cyc)
    for k in ("nowarp", "be", "mem", "dep", "br", "fetch", "bar", "other"):
        m[f"idle_{k}"] = c[f"idle_{k}"]
    for k in ("issue", "notsel", "dep", "mem", "bar", "br", "fetch", "be", "drain", "resident"):
        m[f"wc_{k}"] = c[f"wc_{k}"]
    # ---- tail completion: warp completion times and workgroup latencies ----
    done = [w[4] for w in r.warps.values() if w[4] >= 0]
    m["warp_done_p50"] = pct(done, 0.50)
    m["warp_done_p95"] = pct(done, 0.95)
    m["warp_done_max"] = max(done) if done else 0
    wg_lat = []
    for wg, (lc, nwarps) in r.launch.items():
        ex = [r.warps[(wg, k)][4] for k in range(nwarps) if (wg, k) in r.warps and r.warps[(wg, k)][4] >= 0]
        if ex:
            wg_lat.append(max(ex) - lc)
    m["wg_lat_mean"] = sum(wg_lat) / len(wg_lat) if wg_lat else 0
    m["wg_lat_p95"] = pct(wg_lat, 0.95)
    m["wg_lat_max"] = max(wg_lat) if wg_lat else 0
    # ---- fairness ----
    shares = [w[0] / w[1] for w in r.warps.values() if w[1] >= 20]          # issued / candidate cycles
    m["jain_service"] = jain(shares)
    m["min_service"] = min(shares) if shares else float("nan")
    m["max_wait"] = r.hist["maxwait"][0]                                     # longest run of candidate cycles without a grant
    n_md, s_md, x_md = r.hist["md"]
    n_ot, s_ot, x_ot = r.hist["ot"]
    m["memdep_wait_mean"] = s_md / n_md if n_md else 0.0                     # candidate-to-grant wait of warps that had been
    m["memdep_wait_max"] = x_md                                              # blocked on a memory result
    m["memdep_events"] = n_md
    m["other_wait_mean"] = s_ot / n_ot if n_ot else 0.0
    m["other_wait_max"] = x_ot
    for ci, nm in enumerate(("alu", "mem", "br", "ctrl")):
        g, wc, ws, wx = r.cls_stat.get(ci, (0, 0, 0, 0))
        m[f"grants_{nm}"] = g
        m[f"wait_mean_{nm}"] = ws / wc if wc else 0.0
        m[f"wait_max_{nm}"] = wx
    m["chk_max_wait"] = r.extra.get("chk_max_wait")
    m["chk_bound"] = r.extra.get("chk_bound")
    m["bar_episodes"] = c["bar_episodes"]
    return m


def fingerprint(d: str, meta: dict, geom: str) -> str:
    h = hashlib.sha256()
    for f in ("prog.hex", "trace.hex"):
        h.update(open(os.path.join(d, f), "rb").read())
    h.update(json.dumps({k: meta[k] for k in sorted(meta) if k not in ("desc",)}, sort_keys=True).encode())
    h.update(geom.encode())
    return h.hexdigest()[:16]


def run_one(job: dict) -> dict:
    d, geom, variant = job["dir"], job["geom"], job["variant"]
    meta = json.load(open(os.path.join(d, "meta.json")))
    pol, sargs = VARIANTS[variant] if variant in VARIANTS else job["variant_def"]
    cfg = cfg_for(geom, pol)
    prog = read_hex(os.path.join(d, "prog.hex"))
    mem = make_init_mem(meta["mem_seed"])
    ref = pickle.load(open(os.path.join(d, "ref.pkl"), "rb"))
    args = [f"+trace={os.path.join(d, 'trace.hex')}", f"+tr_k={meta['tr_k']}", f"+tr_wpg={meta['tr_wpg']}",
            f"+tr_wgs={meta['tr_wgs']}", f"+tr_mshr={meta['tr_mshr']}", f"+tr_imem={meta['tr_imem']}"] + list(sargs)
    t0 = time.time()
    r = run_rtl(cfg, prog, mem, meta["nthreads"], meta["nwgs"], 0, 1, 0, 1, extra_args=args)
    rec = dict(workload=os.path.basename(d.rstrip("/")), family=meta["family"], seed=meta["seed"], geom=geom,
               variant=variant, fingerprint=fingerprint(d, meta, geom), sim_s=round(time.time() - t0, 2))
    if not r.ok:
        rec["error"] = "RTL run failed rc=%s: %s" % (r.returncode, " | ".join(r.stdout.strip().splitlines()[-4:]))
        return rec
    errs = compare(r, ref, cfg, mem)
    if errs:
        rec["error"] = "architectural mismatch vs reference: " + "; ".join(errs[:4])
        return rec
    rec["metrics"] = metrics(r, meta)
    rec["demand"] = [r.extra.get("tr_n"), r.extra.get("tr_lat"), r.extra.get("tr_gap")]   # service demand actually consumed
    return rec


def collect_dirs(wl_root: str, seeds: List[int], families: Optional[List[str]]) -> List[str]:
    out = []
    for n in sorted(os.listdir(wl_root)):
        if not os.path.isdir(os.path.join(wl_root, n)) or "_s" not in n:
            continue
        fam, s = n.rsplit("_s", 1)
        if int(s) in seeds and (not families or fam in families):
            out.append(os.path.join(wl_root, n))
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--set", choices=["dev", "test", "both"], default="test")
    ap.add_argument("--workloads", default=os.path.join(ROOT, "workloads"))
    ap.add_argument("--families", default="")
    ap.add_argument("--geoms", default="g8,g16")
    ap.add_argument("--variants", default="rr,age,aware,aware_w0")
    ap.add_argument("--variants-file", default="", help="JSON {name: {cfg field: value}} of extra policy-2 variants")
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "raw.json"))
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    load_variants_file(a.variants_file)

    seeds = (DEV_SEEDS if a.set == "dev" else TEST_SEEDS if a.set == "test" else DEV_SEEDS + TEST_SEEDS)
    dirs = collect_dirs(a.workloads, seeds, a.families.split(",") if a.families else None)
    if not dirs:
        raise SystemExit(f"no workloads for seeds {seeds} in {a.workloads}; run tools/wl_gen.py first")
    geoms, variants = a.geoms.split(","), a.variants.split(",")
    # build every binary once (sequentially, each build is parallel inside)
    for g in geoms:
        for v in variants:
            cfg_for(g, VARIANTS[v][0]).build()
    os.environ["SFX_FROZEN_BUILD"] = "1"          # binaries are up to date now; worker processes must not rebuild
    jobs = [dict(dir=d, geom=g, variant=v) for d in dirs for g in geoms for v in variants]
    t0 = time.time()
    recs, bad = [], []
    with cf.ProcessPoolExecutor(max_workers=a.jobs) as ex:
        for i, rec in enumerate(ex.map(run_one, jobs), 1):
            recs.append(rec)
            if "error" in rec:
                bad.append(rec)
                print(f"  ERROR {rec['workload']} {rec['geom']} {rec['variant']}: {rec['error']}")
            if i % 100 == 0:
                print(f"  {i}/{len(jobs)} runs ({time.time() - t0:.0f}s)")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    json.dump(recs, open(a.out, "w"))
    # workload-equivalence check across policies
    fp: Dict[tuple, set] = {}
    for r in recs:
        fp.setdefault((r["workload"], r["geom"]), set()).add(r["fingerprint"])
    diff = [k for k, v in fp.items() if len(v) != 1]
    dm: Dict[tuple, set] = {}
    for r in recs:
        if "demand" in r:
            dm.setdefault((r["workload"], r["geom"]), set()).add(tuple(r["demand"]))
    ddiff = [k for k, v in dm.items() if len(v) != 1 or None in next(iter(v))]
    print(f"[compare] trace entries / latency / gap totals CONSUMED by the backend identical across variants for "
          f"{len(dm) - len(ddiff)}/{len(dm)} (workload, geometry) pairs")
    diff += ddiff
    print(f"[compare] {len(recs)} runs on {len(dirs)} workload instances x {len(geoms)} geometries x {len(variants)} variants "
          f"in {time.time() - t0:.0f}s -> {a.out}")
    print(f"[compare] workload fingerprints identical across variants for {len(fp) - len(diff)}/{len(fp)} (workload, geometry) pairs")
    if bad or diff:
        print(f"[compare] FAILED: {len(bad)} failing runs, {len(diff)} fingerprint mismatches")
        sys.exit(1)
    print("[compare] every run matched the reference model bit-exactly")


if __name__ == "__main__":
    main()
