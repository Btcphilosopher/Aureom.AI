#!/usr/bin/env python3
"""Compiler-side control-flow pass for the SFX-SIMT reconvergence model.

The hardware never discovers reconvergence points: every BRA/BRZ carries one
(its `rpc_off` field).  The contract with the compiler is

    R(b)  must be a POST-DOMINATOR of the branch instruction b
          (ideally the immediate post-dominator), and R(b) >= b+1.

This module builds the instruction-level CFG of an assembled program, computes
post-dominator sets with a virtual exit node, and either

  * patches `auto` branches with ipdom(b)              (patch_auto_rpc), or
  * lints explicit RPCs against the contract           (lint_program).

Instruction-level CFG successors:
    BRA/BRZ : {pc+1, pc+1+tgt_off}        JMP : {pc+1+tgt_off}
    EXIT    : {virtual exit}              everything else : {pc+1}
Falling off the end of the program is modelled as an edge to the virtual exit
(the hardware raises FAULT_FETCH if that ever happens at run time; the lint
reports it as a warning).
"""
from __future__ import annotations

from typing import Dict, List, Set

from sfx_isa import (OPNAME, Program, decode, enc_br, AsmError, sext, OPS)


class CfgError(AsmError):
    pass


def _succs(prog: Program) -> List[List[int]]:
    n = len(prog.words)
    X = n  # virtual exit node
    succ: List[List[int]] = []
    for pc, w in enumerate(prog.words):
        i = decode(w)
        if not i.legal:
            succ.append([X])      # illegal instruction faults -> terminal
            continue
        name = i.name
        if name == "exit":
            s = [X]
        elif name in ("bra", "brz"):
            s = [pc + 1, pc + 1 + i.tgt_off]
        elif name == "jmp":
            s = [pc + 1 + i.tgt_off]
        else:
            s = [pc + 1]
        s = [X if (t >= n or t < 0) else t for t in s]
        succ.append(list(dict.fromkeys(s)))
    return succ


def postdominators(prog: Program) -> List[Set[int]]:
    """pdom[n] = set of nodes that post-dominate n (including n)."""
    n = len(prog.words)
    X = n
    succ = _succs(prog)
    full = set(range(n + 1))
    pdom: List[Set[int]] = [set(full) for _ in range(n)] + [{X}]
    changed = True
    while changed:
        changed = False
        for v in range(n - 1, -1, -1):
            new = set(full)
            for s in succ[v]:
                new &= pdom[s]
            new.add(v)
            if new != pdom[v]:
                pdom[v] = new
                changed = True
    return pdom


def ipdom(prog: Program, pdom: List[Set[int]], v: int) -> int:
    """Immediate post-dominator of v: the strict post-dominator that is
    post-dominated by every other strict post-dominator."""
    strict = pdom[v] - {v}
    best = None
    for d in strict:
        if len(pdom[d]) == len(strict):   # |pdom(d)| == |strict(v)|  -> closest
            best = d
    if best is None:
        raise CfgError(f"pc {v}: no immediate post-dominator (infinite loop?)")
    return best


def patch_auto_rpc(prog: Program) -> None:
    """Fill in rpc_off for every branch whose reconvergence label was `auto`."""
    pdom = postdominators(prog)
    n = len(prog.words)
    for pc, (tgt, rpc) in sorted(prog.br_info.items()):
        if rpc is not None:
            continue
        r = ipdom(prog, pdom, pc)
        if r >= n:
            raise CfgError(
                f"line {prog.src_lines.get(pc, '?')}: branch at pc {pc} has no real "
                f"reconvergence point (paths end in different EXITs); use a single exit block")
        if r < pc + 1:
            raise CfgError(
                f"line {prog.src_lines.get(pc, '?')}: ipdom of branch at pc {pc} is {r} "
                f"(<= branch); layout must place reconvergence points after the branch")
        i = decode(prog.words[pc])
        prog.words[pc] = enc_br(OPNAME[i.op], i.a, i.tgt_off, r - (pc + 1))
        prog.br_info[pc] = (tgt, r)


def lint_program(prog: Program) -> List[str]:
    """Check every branch's RPC against the compiler contract.  Returns a list
    of human-readable problems (empty == contract satisfied)."""
    problems: List[str] = []
    pdom = postdominators(prog)
    n = len(prog.words)
    exits = 0
    for pc, w in enumerate(prog.words):
        i = decode(w)
        if not i.legal:
            problems.append(f"pc {pc}: illegal opcode")
            continue
        if i.name == "exit":
            exits += 1
        if i.name in ("bra", "brz"):
            R = pc + 1 + i.rpc_off
            T = pc + 1 + i.tgt_off
            if R >= n or R not in pdom[pc]:
                problems.append(f"pc {pc}: RPC {R} is not a post-dominator of the branch")
            elif R != ipdom(prog, pdom, pc):
                # legal but conservative; informational only
                pass
            if not (0 <= T < n):
                problems.append(f"pc {pc}: branch target {T} outside program")
        if i.name == "jmp":
            T = pc + 1 + i.tgt_off
            if not (0 <= T < n):
                problems.append(f"pc {pc}: jump target {T} outside program")
    if exits != 1:
        problems.append(f"program has {exits} EXIT instructions (contract: exactly one, "
                        f"post-dominating everything)")
    if prog.words and decode(prog.words[-1]).name not in ("exit", "jmp"):
        problems.append("last instruction can fall off the end of the program")
    return problems
