#!/usr/bin/env python3
"""SFX-SIMT assembler.

usage: sfx_asm.py prog.s [-o prog.hex] [--list] [--lint]

  -o     write one 32-bit hex word per line (the format the testbench loads with +prog=)
  --list print a disassembly listing with resolved branch targets / reconvergence PCs
  --lint check every branch against the compiler contract (docs/divergence_model.md, C1/C2)
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sfx_isa import assemble, disasm, write_hex, AsmError
from sfx_cfg import lint_program, CfgError


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("-o", dest="out")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--lint", action="store_true")
    a = ap.parse_args()
    try:
        prog = assemble(open(a.src).read())
    except (AsmError, CfgError) as e:
        sys.exit(f"error: {e}")
    if a.list:
        inv = {v: k for k, v in prog.labels.items()}
        for pc, w in enumerate(prog.words):
            lab = f"{inv[pc]}:" if pc in inv else ""
            print(f"{pc:5d}  {w:08x}  {lab:<10s} {disasm(w, pc)}")
    if a.lint:
        problems = lint_program(prog)
        for p in problems:
            print("lint:", p)
        if problems:
            sys.exit(1)
        print("lint: contract satisfied")
    if a.out:
        write_hex(prog.words, a.out)
        print(f"wrote {len(prog.words)} words to {a.out}")


if __name__ == "__main__":
    main()
