#!/usr/bin/env python3
"""SilicaFlux SIMT ISA (SFX-SIMT v1): encoding, decoding, assembler, disassembler.

32-bit fixed-width instructions.  Field layout:

    [31:26] op     [25:21] A     [20:16] B     [15:11] C     [10:0] imm11

  R-type  (ADD..MUL)      rd=A  rs1=B  rs2=C
  I-type  (ADDI, ANDI)    rd=A  rs1=B  imm11 (ADDI sign-ext, ANDI zero-ext)
  LD/LDS                  rd=A  rs1=B  imm11 (sign-ext word offset)
  ST/STS                  rs1=B (base)  rs2=C (data)  imm11
  MOVI                    rd=A  imm16 = instr[15:0] (sign-ext); bits [20:16] = 0
  TID/WGID                rd=A
  BRA/BRZ (format B)      rs1=A (predicate)  rpc_off = instr[20:11] (10b unsigned)
                          tgt_off = instr[10:0] (11b signed)
  JMP                     tgt_off = instr[10:0] (11b signed)
  NOP/BAR/EXIT            no operands

Branch addresses are instruction-word indices.  For a branch at PC b:
    fall-through F = b + 1
    target       T = b + 1 + sext(tgt_off)
    reconv. PC   R = b + 1 + rpc_off          (R >= b + 1 by construction)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

# --------------------------------------------------------------------------
# Opcodes
# --------------------------------------------------------------------------
OPS: Dict[str, int] = {
    "nop": 0x00,
    "add": 0x01, "sub": 0x02, "and": 0x03, "or": 0x04, "xor": 0x05,
    "shl": 0x06, "shr": 0x07, "slt": 0x08, "mul": 0x09,
    "addi": 0x0A, "andi": 0x0B, "movi": 0x0C, "tid": 0x0D, "wgid": 0x0E,
    "ld": 0x10, "st": 0x11, "lds": 0x12, "sts": 0x13,
    "bra": 0x20, "brz": 0x21, "jmp": 0x22, "bar": 0x23, "exit": 0x24,
}
OPNAME = {v: k for k, v in OPS.items()}

CLS_ALU, CLS_MEM, CLS_BR, CLS_CTRL = 0, 1, 2, 3
CLS_OF = {}
for _n in ("add", "sub", "and", "or", "xor", "shl", "shr", "slt", "mul",
           "addi", "andi", "movi", "tid", "wgid"):
    CLS_OF[OPS[_n]] = CLS_ALU
for _n in ("ld", "st", "lds", "sts"):
    CLS_OF[OPS[_n]] = CLS_MEM
for _n in ("bra", "brz"):
    CLS_OF[OPS[_n]] = CLS_BR
for _n in ("nop", "jmp", "bar", "exit"):
    CLS_OF[OPS[_n]] = CLS_CTRL

# fault codes (must match sfx_simt_pkg.sv)
FAULT_NONE = 0
FAULT_DIV_BARRIER = 1
FAULT_DIV_EXIT = 2
FAULT_STACK_OVF = 3
FAULT_ILLEGAL = 4
FAULT_FETCH = 5
FAULT_PC_RANGE = 6
FAULT_BAR_PC = 7
FAULT_LAUNCH = 8
FAULT_NAMES = {
    0: "NONE", 1: "DIV_BARRIER", 2: "DIV_EXIT", 3: "STACK_OVF", 4: "ILLEGAL",
    5: "FETCH", 6: "PC_RANGE", 7: "BAR_PC", 8: "LAUNCH",
}
FAULT_BY_NAME = {v: k for k, v in FAULT_NAMES.items()}

M32 = 0xFFFFFFFF


def sext(v: int, bits: int) -> int:
    v &= (1 << bits) - 1
    return v - (1 << bits) if v & (1 << (bits - 1)) else v


@dataclass
class Instr:
    op: int
    a: int = 0          # field A [25:21]
    b: int = 0          # field B [20:16]
    c: int = 0          # field C [15:11]
    imm11: int = 0      # raw [10:0]
    rpc_off: int = 0    # raw [20:11] (BRA/BRZ)
    imm16: int = 0      # raw [15:0] (MOVI)
    word: int = 0
    legal: bool = True

    # ---- derived ----
    @property
    def name(self) -> str:
        return OPNAME.get(self.op, "???")

    @property
    def cls(self) -> int:
        return CLS_OF[self.op]

    # register usage -------------------------------------------------------
    @property
    def rd(self) -> Optional[int]:
        n = self.name
        if n in ("add", "sub", "and", "or", "xor", "shl", "shr", "slt", "mul",
                 "addi", "andi", "movi", "tid", "wgid", "ld", "lds"):
            return self.a
        return None

    @property
    def rs1(self) -> Optional[int]:
        n = self.name
        if n in ("add", "sub", "and", "or", "xor", "shl", "shr", "slt", "mul",
                 "addi", "andi", "ld", "st", "lds", "sts"):
            return self.b
        if n in ("bra", "brz"):
            return self.a
        return None

    @property
    def rs2(self) -> Optional[int]:
        n = self.name
        if n in ("add", "sub", "and", "or", "xor", "shl", "shr", "slt", "mul",
                 "st", "sts"):
            return self.c
        return None

    @property
    def simm11(self) -> int:
        return sext(self.imm11, 11)

    @property
    def tgt_off(self) -> int:
        return sext(self.imm11, 11)


def decode(word: int) -> Instr:
    word &= M32
    op = (word >> 26) & 0x3F
    i = Instr(op=op, a=(word >> 21) & 31, b=(word >> 16) & 31, c=(word >> 11) & 31,
              imm11=word & 0x7FF, rpc_off=(word >> 11) & 0x3FF, imm16=word & 0xFFFF,
              word=word)
    i.legal = op in OPNAME
    return i


def enc(op: str, a=0, b=0, c=0, imm11=0) -> int:
    return (OPS[op] << 26) | ((a & 31) << 21) | ((b & 31) << 16) | ((c & 31) << 11) | (imm11 & 0x7FF)


def enc_movi(rd: int, imm16: int) -> int:
    return (OPS["movi"] << 26) | ((rd & 31) << 21) | (imm16 & 0xFFFF)


def enc_br(op: str, rs1: int, tgt_off: int, rpc_off: int) -> int:
    assert -1024 <= tgt_off <= 1023, f"branch target offset {tgt_off} out of range"
    assert 0 <= rpc_off <= 1023, f"rpc offset {rpc_off} out of range"
    return (OPS[op] << 26) | ((rs1 & 31) << 21) | ((rpc_off & 0x3FF) << 11) | (tgt_off & 0x7FF)


def enc_jmp(tgt_off: int) -> int:
    assert -1024 <= tgt_off <= 1023, f"jump offset {tgt_off} out of range"
    return (OPS["jmp"] << 26) | (tgt_off & 0x7FF)


# --------------------------------------------------------------------------
# Disassembler
# --------------------------------------------------------------------------
def disasm(word: int, pc: Optional[int] = None) -> str:
    i = decode(word)
    if not i.legal:
        return f".word 0x{word:08x}   ; illegal"
    n = i.name
    if n in ("add", "sub", "and", "or", "xor", "shl", "shr", "slt", "mul"):
        return f"{n} r{i.a}, r{i.b}, r{i.c}"
    if n == "addi":
        return f"addi r{i.a}, r{i.b}, {i.simm11}"
    if n == "andi":
        return f"andi r{i.a}, r{i.b}, {i.imm11}"
    if n == "movi":
        return f"movi r{i.a}, {sext(i.imm16, 16)}"
    if n in ("tid", "wgid"):
        return f"{n} r{i.a}"
    if n in ("ld", "lds"):
        return f"{n} r{i.a}, [r{i.b}{i.simm11:+d}]"
    if n in ("st", "sts"):
        return f"{n} r{i.c}, [r{i.b}{i.simm11:+d}]"
    if n in ("bra", "brz"):
        if pc is not None:
            return f"{n} r{i.a}, @{pc + 1 + i.tgt_off}, @{pc + 1 + i.rpc_off}"
        return f"{n} r{i.a}, {i.tgt_off:+d}, +{i.rpc_off}"
    if n == "jmp":
        return f"jmp @{pc + 1 + i.tgt_off}" if pc is not None else f"jmp {i.tgt_off:+d}"
    return n


# --------------------------------------------------------------------------
# Assembler
# --------------------------------------------------------------------------
class AsmError(Exception):
    pass


_REG = re.compile(r"^r(\d+)$", re.I)
_MEM = re.compile(r"^\[\s*r(\d+)\s*(?:([+-])\s*([^\]]+?))?\s*\]$", re.I)


def _reg(tok: str, ln: int) -> int:
    m = _REG.match(tok.strip())
    if not m or int(m.group(1)) > 31:
        raise AsmError(f"line {ln}: bad register '{tok}'")
    return int(m.group(1))


def _int(tok: str, ln: int) -> int:
    try:
        return int(tok.strip(), 0)
    except ValueError:
        raise AsmError(f"line {ln}: bad integer '{tok}'")


@dataclass
class AsmItem:
    ln: int
    mnem: str
    args: List[str]
    pc: int = 0


@dataclass
class Program:
    words: List[int]
    labels: Dict[str, int] = field(default_factory=dict)
    # per-pc list of (needs_auto_rpc, target_pc, explicit_rpc_pc) for branches
    br_info: Dict[int, Tuple[int, Optional[int]]] = field(default_factory=dict)
    src_lines: Dict[int, int] = field(default_factory=dict)

    def __len__(self):
        return len(self.words)


def assemble(text: str, auto_rpc: bool = True) -> Program:
    """Two-pass assembler.  Branch syntax:
         bra  rP, target, rpc_label      explicit reconvergence label
         bra  rP, target, auto           reconvergence PC computed by the CFG pass
         bra  rP, target                 same as 'auto'
    """
    items: List[AsmItem] = []
    labels: Dict[str, int] = {}
    pc = 0
    for ln, raw in enumerate(text.splitlines(), 1):
        line = raw.split(";")[0].split("#")[0].strip()
        while True:
            m = re.match(r"^([A-Za-z_.$][\w.$]*)\s*:\s*(.*)$", line)
            if not m:
                break
            lab = m.group(1)
            if lab in labels:
                raise AsmError(f"line {ln}: duplicate label '{lab}'")
            labels[lab] = pc
            line = m.group(2).strip()
        if not line:
            continue
        parts = line.split(None, 1)
        mnem = parts[0].lower()
        args = [a.strip() for a in parts[1].split(",")] if len(parts) > 1 else []
        # re-join memory operands that were split by the comma-split
        items.append(AsmItem(ln, mnem, args, pc))
        pc += 1

    words: List[int] = []
    br_info: Dict[int, Tuple[int, Optional[int]]] = {}
    src_lines: Dict[int, int] = {}

    def lab_or_int(tok: str, ln: int) -> int:
        tok = tok.strip()
        if tok in labels:
            return labels[tok]
        if tok.startswith("@"):
            return _int(tok[1:], ln)
        raise AsmError(f"line {ln}: undefined label '{tok}'")

    for it in items:
        ln, m, a, pc = it.ln, it.mnem, it.args, it.pc
        src_lines[pc] = ln
        try:
            if m == ".word":
                words.append(_int(a[0], ln) & M32)
            elif m in ("nop", "bar", "exit"):
                words.append(enc(m))
            elif m in ("add", "sub", "and", "or", "xor", "shl", "shr", "slt", "mul"):
                words.append(enc(m, _reg(a[0], ln), _reg(a[1], ln), _reg(a[2], ln)))
            elif m in ("addi", "andi"):
                imm = _int(a[2], ln)
                if m == "addi" and not -1024 <= imm <= 1023:
                    raise AsmError(f"line {ln}: addi immediate {imm} out of range")
                if m == "andi" and not 0 <= imm <= 2047:
                    raise AsmError(f"line {ln}: andi immediate {imm} out of range")
                words.append(enc(m, _reg(a[0], ln), _reg(a[1], ln), 0, imm))
            elif m == "movi":
                imm = _int(a[1], ln)
                if not -32768 <= imm <= 65535:
                    raise AsmError(f"line {ln}: movi immediate {imm} out of range")
                words.append(enc_movi(_reg(a[0], ln), imm))
            elif m in ("tid", "wgid"):
                words.append(enc(m, _reg(a[0], ln)))
            elif m in ("ld", "lds", "st", "sts"):
                mm = _MEM.match(a[1].strip())
                if not mm:
                    raise AsmError(f"line {ln}: bad memory operand '{a[1]}'")
                base = int(mm.group(1))
                off = 0
                if mm.group(2):
                    off = _int(mm.group(3), ln)
                    if mm.group(2) == "-":
                        off = -off
                if not -1024 <= off <= 1023:
                    raise AsmError(f"line {ln}: memory offset {off} out of range")
                r = _reg(a[0], ln)
                if m in ("ld", "lds"):
                    words.append(enc(m, r, base, 0, off))
                else:
                    words.append(enc(m, 0, base, r, off))
            elif m in ("bra", "brz"):
                rs = _reg(a[0], ln)
                tgt = lab_or_int(a[1], ln)
                rpc: Optional[int] = None
                if len(a) > 2 and a[2].strip().lower() != "auto":
                    rpc = lab_or_int(a[2], ln)
                off = tgt - (pc + 1)
                if rpc is None:
                    words.append(enc_br(m, rs, off, 0))   # patched by CFG pass
                else:
                    roff = rpc - (pc + 1)
                    if roff < 0:
                        raise AsmError(f"line {ln}: reconvergence PC {rpc} precedes branch")
                    words.append(enc_br(m, rs, off, roff))
                br_info[pc] = (tgt, rpc)
            elif m == "jmp":
                tgt = lab_or_int(a[0], ln)
                words.append(enc_jmp(tgt - (pc + 1)))
            else:
                raise AsmError(f"line {ln}: unknown mnemonic '{m}'")
        except IndexError:
            raise AsmError(f"line {ln}: missing operand for '{m}'")
        except AssertionError as e:
            raise AsmError(f"line {ln}: {e}")
    prog = Program(words, labels, br_info, src_lines)
    if auto_rpc:
        from sfx_cfg import patch_auto_rpc
        patch_auto_rpc(prog)
    return prog


def write_hex(words: List[int], path: str) -> None:
    with open(path, "w") as f:
        for w in words:
            f.write(f"{w & M32:08x}\n")


def read_hex(path: str) -> List[int]:
    out = []
    for line in open(path):
        line = line.strip()
        if line:
            out.append(int(line, 16))
    return out
