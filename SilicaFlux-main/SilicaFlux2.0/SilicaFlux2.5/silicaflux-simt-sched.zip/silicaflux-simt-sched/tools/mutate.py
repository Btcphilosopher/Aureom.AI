#!/usr/bin/env python3
"""Mutation testing of the verification environment.

Each mutant injects ONE plausible design bug into a private copy of the RTL
(exact text substitution; the harness aborts if a pattern does not match
exactly once), rebuilds the system testbench against the mutated copy and runs
the checkers in cost order:

    1. unit testbenches that cover the mutated module (arbiters / diverge unit)
    2. the full directed suite on the mutant's base configuration
    3. N random legal programs on the same configuration

A mutant is KILLED when anything fails (reference mismatch, RTL assertion,
assumption monitor, counter invariant, timeout, unit test).  The report says
which kind of checker caught it first.  A SURVIVOR is a hole in the
verification (or an equivalent mutant) and must be explained.

usage: mutate.py [--list] [--only NAME ...] [--random N] [--jobs 4]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import os
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "tests"))
import run_tests as rt
import run_unit as ru
import directed
from sfx_run import RtlConfig

# (name, base cfg, [(file, old, new)], unit-test kind or None, description)
M = []


def mut(name, cfg, edits, unit=None, doc=""):
    M.append(dict(name=name, cfg=cfg, edits=edits, unit=unit, doc=doc))


# ---------------------------------------------------------------- scoreboard / hazards
mut("sb_ignore_waw", "rr32", [("sfx_scoreboard.sv", "hazard[w]     = h1 | h2 | h3;", "hazard[w]     = h1 | h2;")],
    doc="WAW hazard not detected: two writes of one register may complete out of order")
mut("sb_ignore_rs2", "rr32", [("sfx_scoreboard.sv", "hazard[w]     = h1 | h2 | h3;", "hazard[w]     = h1 | h3;")],
    doc="RAW hazard on the second source operand not detected")
mut("sb_clear_wrong_bit", "rr32", [("sfx_scoreboard.sv", "? (32'd1 << clr_rd) : 32'd0;", "? (32'd1 << (clr_rd ^ 5'd1)) : 32'd0;")],
    doc="completion clears the wrong scoreboard bit")
mut("branch_predicate_hazard_ignored", "rr32", [("sfx_simt_pkg.sv", "d.cls = CLS_BR; d.use1 = 1'b1; d.rs1 = i[25:21];", "d.cls = CLS_BR; d.use1 = 1'b0; d.rs1 = i[25:21];")],
    doc="a branch issues before its predicate register is written")
mut("stall_attr_swap_mem_dep", "rr32", [("sfx_simt_ctrl.sv", "if (hazard_mem[w]) m_mem[w] = 1'b1; else m_dep[w] = 1'b1;", "if (hazard_mem[w]) m_dep[w] = 1'b1; else m_mem[w] = 1'b1;")],
    doc="memory and dependency stalls attributed to each other")

# ---------------------------------------------------------------- divergence / reconvergence
mut("div_no_merge", "rr32", [("sfx_diverge_unit.sv", "join_needed = !((sp != '0) && (r[PC_W-1:0] == cur_rpc));", "join_needed = 1'b1;")],
    unit="div", doc="merge optimisation removed: loops with divergent exits grow the stack")
mut("div_no_empty_elision", "rr32", [("sfx_diverge_unit.sv", "both  = !t_empty && !f_empty;", "both  = 1'b1;")],
    unit="div", doc="empty-path elision removed: entries with pc == rpc are pushed")
mut("div_taken_not_masked", "rr32", [("sfx_diverge_unit.sv", "mt = taken_raw & amask;", "mt = taken_raw;")],
    unit="div", doc="taken mask not intersected with the active mask: inactive lanes wake up")
mut("div_nt_mask_wrong", "rr32", [("sfx_diverge_unit.sv", "p1_en = 1'b1; p1_pc = f[PC_W-1:0]; p1_mask = mn; p1_rpc = r[PC_W-1:0];", "p1_en = 1'b1; p1_pc = f[PC_W-1:0]; p1_mask = mt; p1_rpc = r[PC_W-1:0];")],
    unit="div", doc="not-taken stack entry stores the taken lanes")
mut("div_no_pop_on_uniform_nt", "rr32", [("sfx_diverge_unit.sv", "if (sp != '0 && f[PC_W-1:0] == cur_rpc) begin pop = 1'b1; n_sp = sp - 1'b1; end", "if (1'b0 && f[PC_W-1:0] == cur_rpc) begin pop = 1'b1; n_sp = sp - 1'b1; end")],
    unit="div", doc="uniform not-taken branch landing on the reconvergence PC does not pop")
mut("div_overflow_off_by_one", "rr32", [("sfx_diverge_unit.sv", "if (int'(sp) + npush > STACK_DEPTH) begin", "if (int'(sp) + npush > STACK_DEPTH + 1) begin")],
    unit="div", doc="overflow detected one entry too late (writes beyond the stack)")
mut("ctrl_no_pop_after_seq", "rr32", [("sfx_simt_ctrl.sv", "fin_pop = (s_sp != '0) && (s_npc == s_rpc);", "fin_pop = 1'b0;")],
    doc="sequential/JMP flow reaching the reconvergence PC does not pop the stack")

# ---------------------------------------------------------------- barriers
mut("bar_premature_release", "rr32", [("sfx_barrier_unit.sv", "rel_g[g] = !abort[g] && (arr_n[g] != '0) && (arr_n[g] == live_n[g]);", "rel_g[g] = !abort[g] && (arr_n[g] != '0) && ((live_n[g] & ~arr_n[g] & ((live_n[g] & ~arr_n[g]) - 1'b1)) == '0);")],
    doc="barrier releases when ONE live warp is still missing")
mut("bar_exit_not_removed", "rr32", [("sfx_barrier_unit.sv", "live_n[g][exit_w] = 1'b0;", "live_n[g][exit_w] = 1'b1;")],
    doc="exited warps keep counting as participants (barrier never completes)")
mut("bar_arrived_not_cleared", "rr32", [("sfx_barrier_unit.sv", "arrived[g] <= rel_g[g] ? '0 : arr_n[g];", "arrived[g] <= arr_n[g];")],
    doc="arrival mask survives the release: the next episode releases immediately")
mut("bar_no_memory_drain", "rr32", [("sfx_simt_ctrl.sv", "(dec[w].op == OP_BAR)  ? (wmem[w] == '0) :", "(dec[w].op == OP_BAR)  ? 1'b1 :")],
    doc="BAR does not wait for outstanding stores: data not visible after the barrier")
mut("bar_divergent_not_detected", "rr32", [("sfx_simt_ctrl.sv", "s_dec.op == OP_BAR  && s_sp != '0", "s_dec.op == OP_BAR  && 1'b0")],
    doc="a divergent BAR is accepted instead of faulting")
mut("bar_strict_pc_inverted", "strict32", [("sfx_barrier_unit.sv", "(bpc[arr_g] != arr_pc))", "(bpc[arr_g] == arr_pc))")],
    doc="strict-PC check inverted")
mut("bar_live_mask_partial_warp_lost", "rr32", [("sfx_barrier_unit.sv", "live[g]    <= alloc_members;", "live[g]    <= alloc_members & (alloc_members - 1'b1);")],
    doc="the lowest member warp is not a participant (premature release / lost warp)")

# ---------------------------------------------------------------- issue / retirement / lifecycle
mut("exit_no_drain", "rr32", [("sfx_simt_ctrl.sv", "(dec[w].op == OP_EXIT) ? (winf[w] == '0) : 1'b1;", "(dec[w].op == OP_EXIT) ? 1'b1 : 1'b1;")],
    doc="EXIT retires a warp that still has instructions in flight")
mut("duplicate_issue", "rr32", [("sfx_simt_ctrl.sv", "end else begin                          // ALU / MEM / NOP / JMP\n                  wstate[w] <= WS_FETCH;", "end else begin                          // ALU / MEM / NOP / JMP\n                  wstate[w] <= WS_READY;")],
    doc="warp stays READY after issuing: the same instruction issues again")
mut("retire_inactive_context", "rr32", [("sfx_simt_ctrl.sv", "           && (winf[cmp_warp] != '0)\n", "")],
    doc="completions for a context with nothing in flight are accepted")
mut("inflight_never_decrements", "rr32", [("sfx_simt_ctrl.sv", "else if (!inc_inf && dec_inf) winf[w] <= winf[w] - 1'b1;", "else if (1'b0 && dec_inf) winf[w] <= winf[w] - 1'b1;")],
    doc="in-flight counter leaks: EXIT can never issue")
mut("partial_warp_mask_ignored", "rr32", [("sfx_simt_ctrl.sv", "if (tl >= 1 && tl <= WARP_SIZE) mask_last", "if (1'b0 && tl <= WARP_SIZE) mask_last")],
    doc="launch mask of a partial warp is all ones: phantom threads execute")
mut("abort_does_not_kill_siblings", "rr32", [("sfx_simt_ctrl.sv", "end else if (wstate[w] != WS_FREE && wstate[w] != WS_DRAIN && gabort[wwg[w]]) begin", "end else if (1'b0 && wstate[w] != WS_DRAIN && gabort[wwg[w]]) begin")],
    doc="a fault does not abort the other warps of the workgroup")
mut("drain_ignores_inflight", "rr32", [("sfx_simt_ctrl.sv", "drained[w]   = (wstate[w] == WS_DRAIN) && (winf[w] == '0) && !fetch_pend[w];", "drained[w]   = (wstate[w] == WS_DRAIN);")],
    doc="an aborted slot is freed while completions are still in flight")
mut("kernel_done_early", "rr32", [("sfx_simt_ctrl.sv", "if (k_last && !k_done_q && (gvalid == '0)) k_done_q <= 1'b1;", "if (k_last && !k_done_q) k_done_q <= 1'b1;")],
    doc="kernel_done asserts as soon as the last workgroup is launched")

# ---------------------------------------------------------------- arbiters
mut("rr_pointer_sticks", "rr32", [("sfx_rr_arb.sv", "ptr <= PW'((k + 1) % N);", "ptr <= PW'(k % N);")],
    unit="arb", doc="round-robin pointer does not advance past the granted slot (greedy, starves others)")
mut("rr_class_pointers_advance_on_any_grant", "rr32", [("sfx_class_rr_arb.sv", ".adv(cls_grant[c])", ".adv(|cls_grant)")],
    unit="arb", doc="per-class pointers move on every grant (single-pointer behaviour): a ready warp is skipped while its class is busy")
mut("age_counts_class_busy_cycles", "age32", [("sfx_age_arb.sv", "else if (fire && req[i] && (wcnt[i] < CW'(STARVE_LIMIT + 1)))", "else if (fire && (wcnt[i] < CW'(STARVE_LIMIT + 1)))")],
    unit="arb", doc="starvation counter also counts cycles in which the warp's class is busy: an older sibling re-becomes urgent between grants")
mut("age_guard_disabled", "age32", [("sfx_age_arb.sv", "urgent[i] = (STARVE_LIMIT != 0) && (wcnt[i] >= CW'(STARVE_LIMIT));", "urgent[i] = 1'b0;")],
    unit="arb", doc="starvation guard disabled: pure oldest-first")
mut("age_matrix_inverted", "age32", [("sfx_age_arb.sv", "else if (alloc[i] && !alloc[j]) older[i][j] <= 1'b0;", "else if (alloc[i] && !alloc[j]) older[i][j] <= 1'b1;")],
    unit="arb", doc="a newly allocated slot is recorded as older than existing slots")


def apply(m, dst):
    for (f, old, new) in m["edits"]:
        p = os.path.join(dst, f)
        s = open(p).read()
        n = s.count(old)
        if n != 1:
            raise SystemExit(f"mutant {m['name']}: pattern for {f} matches {n} times (must be exactly 1):\n  {old!r}")
        open(p, "w").write(s.replace(old, new))


def base_params(cfgname):
    return rt.CONFIGS[cfgname]


def run_mutant(m, nrand, jobs, use_unit=True):
    t0 = time.time()
    name = m["name"]
    mdir = os.path.join(ROOT, "build", f"mutsrc_{name}")
    shutil.rmtree(mdir, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, "rtl"), mdir)
    apply(m, mdir)
    os.environ["SFX_RTL_DIR"] = mdir
    cfgname = m["cfg"]
    b = base_params(cfgname)
    mc = RtlConfig(name=f"mut_{name}", num_warps=b.num_warps, num_wgs=b.num_wgs, warp_size=b.warp_size,
                   stack_depth=b.stack_depth, sched_policy=b.sched_policy, starve_limit=b.starve_limit,
                   strict_bar_pc=b.strict_bar_pc, max_inflight=b.max_inflight)
    # make the mutated configuration the one the test drivers will use
    saved = rt.CONFIGS[cfgname]
    rt.CONFIGS[cfgname] = mc
    killed_by = None
    detail = ""
    try:
        # ---- 1. unit tests ----
        if m["unit"] == "div" and killed_by is None and use_unit:
            vec = os.path.join(ROOT, "build", "div_vec_32_8.txt")
            exe = ru.build(f"mutunit_{name}", "tb_unit_diverge", [os.path.relpath(os.path.join(mdir, "sfx_diverge_unit.sv"), ROOT),
                                                                "tb/tb_unit_diverge.sv"], ["-GLANES=32", "-GSTACK_DEPTH=8"])
            rc, out = ru.run(exe, [f"+vec={vec}"])
            if rc != 0:
                killed_by, detail = "unit:diverge-vectors", next((l for l in out.splitlines() if "FAIL" in l), "")
        if m["unit"] == "arb" and killed_by is None and use_unit:
            kind = 1 if m["cfg"] == "age32" else 0
            rel = lambda f: os.path.relpath(os.path.join(mdir, f), ROOT)
            exe = ru.build(f"mutunit_{name}", "tb_unit_arb", [rel("sfx_rr_arb.sv"), rel("sfx_class_rr_arb.sv"), rel("sfx_age_arb.sv"),
                                                              "tb/tb_unit_arb.sv"], [f"-GKIND={kind}", "-GN=8", "-GSTARVE_LIMIT=16"])
            rc, out = ru.run(exe)
            if rc != 0:
                killed_by, detail = "unit:arbiter", next((l for l in out.splitlines() if "FAIL" in l), "")
        # ---- 2. directed ----
        if killed_by is None:
            rt.build_all([cfgname])
            tests = [t for t in directed.all_tests() if cfgname in t.cfgs]
            if cfgname in ("rr32", "age32"):
                pass
            work = [(t, cfgname, p) for t in tests for p in t.profiles]
            with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
                futs = {ex.submit(rt.run_directed_one, t, c, p, 11 + p): (t, c, p) for (t, c, p) in work}
                for fu in cf.as_completed(futs):
                    t, c, p = futs[fu]
                    try:
                        errs = fu.result()
                    except Exception as e:      # noqa
                        errs = [f"exception {e}"]
                    if errs and killed_by is None:
                        killed_by = f"directed:{t.name}"
                        detail = errs[0]
                        for f2 in futs:
                            f2.cancel()
        # ---- 3. random ----
        if killed_by is None and nrand:
            with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
                futs = {ex.submit(rt.random_case, cfgname, s): s for s in range(7000, 7000 + nrand)}
                for fu in cf.as_completed(futs):
                    try:
                        r = fu.result()
                    except Exception as e:      # noqa
                        r = ([f"exception {e}"],)
                    if r[0] and killed_by is None:
                        killed_by = f"random:seed{futs[fu]}"
                        detail = r[0][0]
                        for f2 in futs:
                            f2.cancel()
    finally:
        rt.CONFIGS[cfgname] = saved
        os.environ.pop("SFX_RTL_DIR", None)
    kind = "-"
    if killed_by:
        d = detail
        kind = ("RTL-assertion" if "SFX-ASSERT" in d or "SFX assertion" in d else
                "assumption-monitor" if "ASSUMPTION" in d else
                "TB-invariant" if "[TB]" in d else
                "timeout/deadlock" if "TIMEOUT" in d else
                "reference-compare" if killed_by.startswith(("directed", "random")) else "unit-test")
    return dict(name=name, killed_by=killed_by, kind=kind, detail=detail, secs=time.time() - t0, doc=m["doc"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--random", type=int, default=40)
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--no-unit", action="store_true", help="skip the unit testbenches: system tests only")
    a = ap.parse_args()
    sel = [m for m in M if not a.only or m["name"] in a.only]
    # validate every pattern first
    tmp = os.path.join(ROOT, "build", "mut_validate")
    shutil.rmtree(tmp, ignore_errors=True)
    for m in sel:
        shutil.copytree(os.path.join(ROOT, "rtl"), tmp)
        apply(m, tmp)
        shutil.rmtree(tmp)
    print(f"{len(sel)} mutants, all patterns match exactly once")
    if a.list:
        for m in sel:
            print(f"  {m['name']:36s} [{m['cfg']}] {m['doc']}")
        return
    results = []
    for m in sel:
        r = run_mutant(m, a.random, a.jobs, use_unit=not a.no_unit)
        results.append(r)
        status = f"KILLED by {r['killed_by']} ({r['kind']})" if r["killed_by"] else "*** SURVIVED ***"
        print(f"  {r['name']:36s} {status}  [{r['secs']:.0f}s]", flush=True)
        if r["killed_by"]:
            print(f"      {r['detail'][:150]}", flush=True)
    surv = [r for r in results if not r["killed_by"]]
    print(f"\nMUTATION SCORE: {len(results) - len(surv)}/{len(results)} killed")
    for r in surv:
        print(f"  SURVIVOR: {r['name']} - {r['doc']}")
    sys.exit(1 if surv else 0)


if __name__ == "__main__":
    main()
