#!/usr/bin/env python3
"""Deterministic workload generator: programs + schedule-independent latency traces.

For every (family, seed) it writes  workloads/<family>_s<seed>/

    prog.asm      SFX-SIMT assembly (race-free, legal, uniform control flow except `diverge`)
    prog.hex      assembled instruction memory
    trace.hex     latency table read by the testbench ($readmemh), see below
    meta.json     launch configuration, trace geometry, counts, description
    ref.pkl       SimtSim reference result (per-warp issue streams, registers, memory)

WHY A TRACE.  The stock backend model draws every latency from one global random number
generator, so the latency an instruction sees depends on how many random numbers were drawn
before it, i.e. on the schedule.  Two scheduling policies would then not see the same workload.
Here the service demand of the k-th backend instruction of warp (wg, widx) is a pure function of
(seed, wg, widx, k): a stateless 64-bit hash.  The instruction stream of a warp does not depend
on the schedule (programs are race free; the reference model fixes it), so k identifies the same
dynamic instruction under every policy.  The testbench also checks that the opcode in the trace
entry equals the opcode actually issued, so a misaligned trace cannot go unnoticed.

Table word  (index = (wg * 16 + widx) * K + k):
    [31:26] opcode      [23:16] class busy gap after the accept (cycles)     [15:0] latency (cycles)

The same hash drives the program parameters (iteration counts, imbalance, role assignment), so a
seed fully determines a workload instance.  Seeds 1..6 are DEVELOPMENT seeds (used to choose
default weights / sweep configurations), seeds 101.. are held-out TEST seeds (used for the report).

    wl_gen.py --families all --seeds 1-6,101-116 --out workloads --jobs 4
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import pickle
import sys
from typing import Dict, List, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from sfx_isa import assemble, decode, write_hex, CLS_CTRL
from sfx_ref import SimtSim, Cfg

M64 = (1 << 64) - 1
WPG = 16                     # trace stride (warps per workgroup); >= NUM_WARPS of every RTL geometry
LANES = 32
OUT_BASE = 4096              # private per-thread output slots  [4096, 4096 + 256 * nwgs)


# ----------------------------------------------------------------------------- stateless randomness
def mix64(x: int) -> int:
    """splitmix64 finaliser"""
    x = (x + 0x9E3779B97F4A7C15) & M64
    x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & M64
    x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & M64
    return x ^ (x >> 31)


def hrand(seed: int, *keys: int) -> float:
    h = mix64(seed & M64)
    for k in keys:
        h = mix64(h ^ ((k * 0xD6E8FEB86659FD93) & M64))
    return (h >> 11) / float(1 << 53)


def hint(seed: int, lo: int, hi: int, *keys: int) -> int:
    return lo + int(hrand(seed, *keys) * (hi - lo + 1))


# ----------------------------------------------------------------------------- latency profiles
PROFILES: Dict[str, dict] = {
    # hit/miss global loads, posted stores, short ALU
    "default":  dict(p_hit=0.60, hit=(20, 28), miss=(150, 300), st=(30, 50), lds=8, alu=4, mul=8, br=6, imem=2, mshr=4),
    "dram":     dict(p_hit=0.15, hit=(20, 28), miss=(180, 320), st=(30, 50), lds=8, alu=4, mul=8, br=6, imem=2, mshr=4),
    "stream":   dict(p_hit=0.30, hit=(20, 28), miss=(120, 200), st=(60, 120), lds=8, alu=4, mul=8, br=6, imem=2, mshr=2),
}

OPNUM = {"ld": 0x10, "st": 0x11, "lds": 0x12, "sts": 0x13, "mul": 0x09, "bra": 0x20, "brz": 0x21}


def entry_for(op: int, prof: dict, seed: int, wg: int, widx: int, k: int) -> Tuple[int, int]:
    """(latency, gap) of one backend instruction"""
    u = hrand(seed, wg, widx, k, 0x51)
    j = hrand(seed, wg, widx, k, 0x77)
    if op == 0x10:                                   # global load
        if u < prof["p_hit"]:
            lo, hi = prof["hit"]
        else:
            lo, hi = prof["miss"]
        return lo + int(j * (hi - lo + 1)), 0
    if op == 0x11:                                   # global store
        lo, hi = prof["st"]
        return lo + int(j * (hi - lo + 1)), 0
    if op in (0x12, 0x13):                           # shared memory
        return prof["lds"] + int(j * 3), 0
    if op in (0x20, 0x21):                           # branch
        return prof["br"], 0
    if op == 0x09:                                   # multiplier: longer, port busy one more cycle
        return prof["mul"], 1
    return prof["alu"], 0


# ----------------------------------------------------------------------------- program fragments
PRO = """\
    tid  r1
    wgid r2
    movi r6, 5
    shr  r7, r1, r6          ; r7 = warp index inside the workgroup (warp-uniform)
    movi r4, 8
    shl  r3, r2, r4          ; r3 = wgid << 8
    add  r3, r3, r1          ; r3 = (wgid << 8) + tid
    movi r4, %d
    add  r3, r3, r4          ; r3 = private output slot
    addi r12, r1, 3
    addi r13, r1, 5
    addi r14, r1, 7
    addi r15, r1, 11
    movi r5, 1024            ; base of the second read-only input region (offsets are limited to +-1023)
""" % OUT_BASE

EPI = """\
Lend:
    add  r8, r8, r9
    add  r8, r8, r10
    add  r8, r8, r11
    st   r8, [r3+0]
    exit
"""


def alu_body(n: int, ilp: int, mul_every: int = 0) -> List[str]:
    """n ALU instructions over `ilp` independent accumulator chains (r8..)"""
    out = []
    srcs = ["r12", "r13", "r14", "r15"]
    for j in range(n):
        acc = f"r{8 + (j % ilp)}"
        if mul_every and j % mul_every == mul_every - 1:
            out.append(f"    mul  {acc}, {acc}, {srcs[j % 4]}")
        else:
            op = ["add", "xor", "add", "sub"][j % 4]
            out.append(f"    {op}  {acc}, {acc}, {srcs[j % 4]}")
    return out


def loop(label: str, ctr: str, iters: int, body: List[str]) -> List[str]:
    return [f"    movi {ctr}, {iters}", f"{label}:"] + body + [f"    addi {ctr}, {ctr}, -1", f"    bra  {ctr}, {label}"]


def role_compute(tag: str, iters: int, ilp: int = 4) -> List[str]:
    return loop(f"Lc{tag}", "r24", iters, alu_body(8, ilp))


def role_memchain(tag: str, iters: int) -> List[str]:
    """pointer chasing: every load address depends on the previous load; dependent arithmetic per step"""
    body = ["    ld   r16, [r17+0]",
            "    add  r8,  r8,  r16",
            "    mul  r18, r8,  r16",
            "    xor  r9,  r9,  r18",
            "    andi r17, r16, 1023"]
    return ["    andi r17, r1, 1023"] + loop(f"Lm{tag}", "r24", iters, body)


def role_balanced(tag: str, iters: int, nalu: int = 5) -> List[str]:
    body = ["    add  r18, r24, r1",
            "    andi r18, r18, 1023",
            "    add  r18, r18, r5",
            "    ld   r16, [r18+0]",
            "    add  r8,  r8,  r16"] + alu_body(nalu, 2)
    return loop(f"Lb{tag}", "r24", iters, body)


def role_stream(tag: str, iters: int) -> List[str]:
    """independent loads and stores (bandwidth / capacity bound)"""
    body = ["    add  r18, r24, r1",
            "    andi r18, r18, 1023",
            "    ld   r16, [r18+0]",
            "    add  r18, r18, r5",
            "    ld   r17, [r18+0]",
            "    add  r8,  r16, r17",
            "    st   r8,  [r3+0]"]
    return loop(f"Ls{tag}", "r24", iters, body)


def dispatch(nw: int, roles: List[List[str]]) -> List[str]:
    """warp-uniform role dispatch on the warp index r7; roles[k] runs on warp k, then jumps to Lend"""
    out = []
    for k in range(nw - 1):
        out += [f"    movi r10, {k}", "    xor  r9, r7, r10", f"    brz  r9, Lrole{k}"]
    out += [f"    jmp  Lrole{nw - 1}"]
    for k in range(nw):
        out += [f"Lrole{k}:"] + roles[k] + ["    jmp  Lend"]
    return out


def program(lines: List[str]) -> str:
    return PRO + "\n".join(lines) + "\n" + EPI


# ----------------------------------------------------------------------------- families
class WL:
    def __init__(self, family: str, seed: int, nwarps: int, nwgs: int, profile: str, lines: List[str], desc: str):
        self.family, self.seed, self.nwarps, self.nwgs = family, seed, nwarps, nwgs
        self.profile, self.lines, self.desc = profile, lines, desc

    @property
    def asm(self) -> str:
        return program(self.lines)


def fam_ldchain(seed: int) -> WL:
    nw, nwgs = 4, 4
    it = hint(seed, 14, 22, 1)
    lines = ["    andi r17, r1, 1023"] + loop("Lm", "r24", it, [
        "    ld   r16, [r17+0]", "    add  r8,  r8,  r16", "    mul  r18, r8,  r16", "    xor  r9,  r9,  r18",
        "    add  r10, r10, r18", "    andi r17, r16, 1023"])
    return WL("ldchain", seed, nw, nwgs, "dram", lines,
              "every warp chases pointers: long-latency loads feeding dependent arithmetic and the next load")


def fam_depalu(seed: int) -> WL:
    nw, nwgs = 4, 4
    it = hint(seed, 70, 110, 1)
    body = []
    for j in range(8):
        body.append(f"    {['add', 'xor', 'sub', 'add'][j % 4]}  r8, r8, {['r12', 'r13', 'r14', 'r15'][j % 4]}")
    body.append("    mul  r8, r8, r13")
    lines = loop("Ld", "r24", it, body)
    return WL("depalu", seed, nw, nwgs, "default", lines,
              "ALU-only fully dependent chains (every instruction reads the previous result), incl. multiplies")


def fam_compute(seed: int) -> WL:
    nw, nwgs = 8, 2
    it = hint(seed, 55, 80, 1)
    lines = loop("Lc", "r24", it, alu_body(10, 4, mul_every=0))
    return WL("compute", seed, nw, nwgs, "default", lines, "compute heavy, high instruction-level parallelism, no memory")


def fam_mixed(seed: int) -> WL:
    nw, nwgs = 4, 4
    kinds = ["C", "C", "M", "B"]
    order = sorted(range(nw), key=lambda k: hrand(seed, 9, k))
    roles_k = [kinds[order.index(k)] for k in range(nw)]
    itc, itm, itb = hint(seed, 70, 120, 2), hint(seed, 10, 16, 3), hint(seed, 30, 50, 4)
    roles = []
    for k, r in enumerate(roles_k):
        roles.append(role_compute(str(k), itc) if r == "C" else role_memchain(str(k), itm) if r == "M" else role_balanced(str(k), itb))
    return WL("mixed", seed, nw, nwgs, "default", dispatch(nw, roles),
              f"mixed kernel: per-warp roles {''.join(roles_k)} (C compute, M pointer-chasing memory, B balanced)")


def fam_skew(seed: int) -> WL:
    nw, nwgs = 8, 2
    nmem = hint(seed, 1, 2, 5)
    mem_warps = {nw - 1 - i for i in range(nmem)}          # memory-dependent warps are the youngest slots
    itc, itm = hint(seed, 90, 130, 2), hint(seed, 9, 14, 3)
    roles = [role_memchain(str(k), itm) if k in mem_warps else role_compute(str(k), itc) for k in range(nw)]
    return WL("skew", seed, nw, nwgs, "dram", dispatch(nw, roles),
              f"{nw - nmem} compute-heavy warps + {nmem} memory-dependent warps in the youngest slots (starvation probe)")


def fam_memstream(seed: int) -> WL:
    nw, nwgs = 4, 4
    it = hint(seed, 22, 34, 1)
    return WL("memstream", seed, nw, nwgs, "stream", role_stream("", it),
              "streaming loads + stores, only 2 outstanding global operations (downstream capacity bound)")


def fam_barrier(seed: int) -> WL:
    nw, nwgs = 4, 6
    phases = hint(seed, 6, 9, 1)
    a, b = 2 * hint(seed, 1, 9, 2) + 1, 2 * hint(seed, 1, 9, 3) + 1
    base = hint(seed, 2, 4, 4)
    lines = ["    movi r26, 0", "    movi r27, %d" % phases, "Lphase:",
             f"    movi r18, {a}", "    mul  r19, r7, r18", f"    movi r18, {b}", "    mul  r20, r26, r18",
             "    add  r19, r19, r20", "    andi r19, r19, 7", f"    addi r24, r19, {base}", "Lwork:"] \
        + alu_body(6, 3) + ["    addi r24, r24, -1", "    bra  r24, Lwork",
                            "    sts  r8, [r1+0]", "    bar", "    movi r18, 32", "    xor  r19, r1, r18",
                            "    lds  r16, [r19+0]", "    add  r8, r8, r16", "    bar",
                            "    addi r26, r26, 1", "    sub  r28, r27, r26", "    bra  r28, Lphase"]
    return WL("barrier", seed, nw, nwgs, "default", lines,
              f"barrier heavy: {phases} phases x 2 barriers per workgroup, unbalanced per-warp work, shared-memory exchange")


def fam_diverge(seed: int) -> WL:
    nw, nwgs = 4, 4
    it = hint(seed, 18, 30, 1)
    body = ["    add  r18, r24, r1", "    andi r18, r18, 1023", "    andi r19, r1, 1", "    brz  r19, Lelse",
            "    ld   r16, [r18+0]", "    add  r8, r8, r16", "    mul  r9, r8, r16", "    jmp  Ljoin",
            "Lelse:", "    add  r18, r18, r5", "    ld   r17, [r18+0]", "    xor  r10, r10, r17", "    add  r11, r11, r17",
            "Ljoin:", "    add  r8, r8, r9"] + alu_body(4, 2)
    return WL("diverge", seed, nw, nwgs, "default", loop("Ldv", "r24", it, body),
              "half-warp divergence (lane parity) around loads, reconverging every iteration (execution-mask stress)")


FAMILIES = {f.__name__[4:]: f for f in (fam_ldchain, fam_depalu, fam_compute, fam_mixed, fam_skew,
                                        fam_memstream, fam_barrier, fam_diverge)}


# ----------------------------------------------------------------------------- build one workload
def build(family: str, seed: int, outdir: str) -> dict:
    from sfx_gen import make_init_mem
    wl = FAMILIES[family](seed)
    d = os.path.join(outdir, f"{family}_s{seed}")
    os.makedirs(d, exist_ok=True)
    asm = wl.asm
    prog = assemble(asm)
    nthreads = wl.nwarps * LANES
    mem = make_init_mem(seed)
    ref = SimtSim(prog.words, Cfg(lanes=LANES, max_warps=wl.nwarps if wl.nwarps >= 8 else 8, stack_depth=8), mem).run(nthreads, wl.nwgs)
    if ref.faults:
        raise SystemExit(f"{family}_s{seed}: reference faulted: {ref.faults}")
    prof = PROFILES[wl.profile]
    decs = [decode(w) for w in prog.words]
    # --- latency table
    K = 0
    per_warp: Dict[Tuple[int, int], List[Tuple[int, int, int]]] = {}
    for (wg, widx), tr in sorted(ref.trace.items()):
        seq = []
        for (pc, _mask) in tr:
            i = decs[pc]
            if i.cls == CLS_CTRL:
                continue
            lat, gap = entry_for(i.op, prof, seed, wg, widx, len(seq))
            seq.append((i.op, gap, lat))
        per_warp[(wg, widx)] = seq
        K = max(K, len(seq))
    K = ((K + 15) // 16) * 16
    if wl.nwgs * WPG * K > (1 << 20):
        raise SystemExit(f"{family}_s{seed}: trace too large ({wl.nwgs}x{WPG}x{K} words)")
    with open(os.path.join(d, "trace.hex"), "w") as f:
        for (wg, widx), seq in sorted(per_warp.items()):
            f.write(f"@{(wg * WPG + widx) * K:x}\n")
            for (op, gap, lat) in seq:
                f.write(f"{(op << 26) | (gap << 16) | lat:08x}\n")
    write_hex(prog.words, os.path.join(d, "prog.hex"))
    open(os.path.join(d, "prog.asm"), "w").write(asm)
    pickle.dump(ref, open(os.path.join(d, "ref.pkl"), "wb"))
    nbe = sum(len(s) for s in per_warp.values())
    meta = dict(family=family, seed=seed, desc=wl.desc, profile=wl.profile, nthreads=nthreads, nwgs=wl.nwgs,
                warps_per_wg=wl.nwarps, tr_k=K, tr_wpg=WPG, tr_wgs=max(wl.nwgs, 1), tr_mshr=prof["mshr"],
                tr_imem=prof["imem"], proglen=len(prog.words), mem_seed=seed,
                warp_instructions=ref.issued, backend_instructions=nbe, barrier_episodes=ref.barrier_episodes,
                divergent_branches=ref.div_branches)
    json.dump(meta, open(os.path.join(d, "meta.json"), "w"), indent=1)
    return meta


def parse_seeds(s: str) -> List[int]:
    out = []
    for part in s.split(","):
        if "-" in part:
            a, b = part.split("-")
            out += list(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


def _job(a):
    return build(*a)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--families", default="all")
    ap.add_argument("--seeds", default="1-6,101-116")
    ap.add_argument("--out", default=os.path.join(HERE, "..", "workloads"))
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    fams = list(FAMILIES) if a.families == "all" else a.families.split(",")
    jobs = [(f, s, a.out) for f in fams for s in parse_seeds(a.seeds)]
    with cf.ProcessPoolExecutor(max_workers=a.jobs) as ex:
        for m in ex.map(_job, jobs):
            print(f"  {m['family']:10s} seed {m['seed']:3d}: {m['warps_per_wg']}x{m['nwgs']} warps, "
                  f"{m['warp_instructions']:6d} warp-instr, {m['backend_instructions']:6d} backend, trace K={m['tr_k']}")
    print(f"[wl_gen] {len(jobs)} workloads in {os.path.abspath(a.out)}")


if __name__ == "__main__":
    main()
