#!/usr/bin/env python3
"""Random generator of LEGAL, RACE-FREE SFX-SIMT kernels with structured
(compiler-style) control flow.

Legality rules enforced by construction
  * single EXIT at the end of the program; early exits branch to it;
  * every branch is emitted with `auto` reconvergence; the post-dominator pass
    in sfx_cfg.py fills in R = ipdom(branch) exactly as a compiler would;
  * BAR only where the whole warp is converged: top-level code, uniform
    (constant / workgroup-id) loops and workgroup-uniform `if`s; no
    data-dependent break / early exit can precede a BAR;
  * no loop-carried modification of loop counters; all loops terminate;
  * race freedom: global stores only to the thread's own private slots, loads
    only from read-only input regions or the thread's own slots; shared
    memory is used in alternating WRITE phases (own slot only) and READ phases
    (any slot), separated by barriers.
So the per-thread OracleSim result is well defined and must equal the
SimtSim (and RTL) result.

Register conventions
  r1 tid  r2 wgid  r3 gtid=(wgid<<8)+tid  r4/r5 &OUT0/&OUT1 slots  r6 &IN1 slot
  r8..r15 data   r16..r23 temporaries   r24..r29 loop counters   r30 scratch
Memory map (words)  IN0 [0,1024)  IN1 [1024,2048)  OUT0 [2048,3072)  OUT1 [3072,4096)
"""
from __future__ import annotations

import random
from typing import List, Optional

IN0, IN1, OUT0, OUT1 = 0, 1024, 2048, 3072
DATA = list(range(8, 16))
TEMP = list(range(16, 24))
CTRS = list(range(24, 30))


class Gen:
    def __init__(self, seed: int, lanes: int = 32, nthreads: int = 64, *,
                 max_div_depth: int = 3, max_loop_depth: int = 2,
                 shared: bool = True, barriers: bool = True, size: int = 1):
        self.rng = random.Random(seed)
        self.lanes = lanes
        self.nthreads = nthreads
        self.max_div_depth = max_div_depth
        self.max_loop_depth = max_loop_depth
        self.shared = shared
        self.barriers = barriers
        self.size = size
        self.out: List[str] = []
        self.nlabel = 0
        self.free_ctrs = list(CTRS)
        self.loop_exit_labels: List[str] = []   # innermost last

    # -- helpers ---------------------------------------------------------
    def L(self, base="L") -> str:
        self.nlabel += 1
        return f"{base}{self.nlabel}"

    def e(self, s: str, indent=True):
        self.out.append(("    " if indent else "") + s)

    def lab(self, name: str):
        self.out.append(f"{name}:")

    def d(self):
        return self.rng.choice(DATA)

    def t(self):
        return self.rng.choice(TEMP)

    # -- statements --------------------------------------------------------
    def alu(self):
        rng = self.rng
        op = rng.choice(["add", "sub", "and", "or", "xor", "shl", "shr", "slt", "mul",
                         "addi", "andi", "movi", "add", "xor", "tid", "wgid"])
        rd = self.d()
        a, b = self.d(), self.d()
        if op in ("add", "sub", "and", "or", "xor", "shl", "shr", "slt", "mul"):
            if op in ("shl", "shr"):
                # keep shifts interesting: shift amount from a small immediate-derived temp
                tmp = self.t()
                self.e(f"andi r{tmp}, r{b}, 31")
                self.e(f"{op} r{rd}, r{a}, r{tmp}")
            else:
                self.e(f"{op} r{rd}, r{a}, r{b}")
        elif op == "addi":
            self.e(f"addi r{rd}, r{a}, {rng.randint(-100, 100)}")
        elif op == "andi":
            self.e(f"andi r{rd}, r{a}, {rng.choice([1, 3, 7, 15, 255, 1023, 2047])}")
        elif op == "movi":
            self.e(f"movi r{rd}, {rng.randint(-2000, 40000)}")
        else:
            self.e(f"{op} r{rd}")

    def mem(self, shared_mode: str):
        rng = self.rng
        k = rng.random()
        if k < 0.30:
            self.e(f"ld r{self.d()}, [r3{rng.randint(-5, 5):+d}]")
        elif k < 0.45:
            self.e(f"ld r{self.d()}, [r6{rng.randint(-5, 0):+d}]")
        elif k < 0.70:
            self.e(f"st r{self.d()}, [r{rng.choice([4, 5])}+0]")
        elif k < 0.80:
            self.e(f"ld r{self.d()}, [r{rng.choice([4, 5])}+0]")
        elif self.shared and shared_mode == "W":
            if rng.random() < 0.75:
                self.e(f"sts r{self.d()}, [r1+0]")
            else:
                self.e(f"lds r{self.d()}, [r1+0]")
        elif self.shared and shared_mode == "R":
            tmp = self.t()
            self.e(f"addi r{tmp}, r1, {rng.randint(0, 40)}")
            self.e(f"andi r{tmp}, r{tmp}, 255")
            self.e(f"lds r{self.d()}, [r{tmp}+0]")
        else:
            self.alu()

    def cond(self, uniform_ok=True) -> int:
        """Emit code that leaves a predicate (nonzero/zero) in a temp; return it."""
        rng = self.rng
        tmp = self.t()
        k = rng.random()
        if k < 0.45:
            self.e(f"andi r{tmp}, r{self.d()}, {1 << rng.randint(0, 6)}")
        elif k < 0.65:
            self.e(f"slt r{tmp}, r{self.d()}, r{self.d()}")
        elif k < 0.80:
            self.e(f"and r{tmp}, r{self.d()}, r{self.d()}")
            self.e(f"andi r{tmp}, r{tmp}, {rng.choice([3, 7, 15])}")
        elif k < 0.90 and uniform_ok:
            self.e(f"andi r{tmp}, r2, {rng.choice([1, 2, 3])}")       # workgroup-uniform
        else:
            self.e(f"xor r{tmp}, r{self.d()}, r1")
            self.e(f"andi r{tmp}, r{tmp}, {rng.choice([1, 2, 4, 8])}")
        return tmp

    def block(self, n: int, depth: int, ctx: dict):
        for _ in range(n):
            self.stmt(depth, ctx)

    def stmt(self, depth: int, ctx: dict):
        rng = self.rng
        sm = ctx.get("shared", "N")
        choices = [("alu", 8), ("mem", 5)]
        if depth < self.max_div_depth:
            choices += [("ifelse", 4), ("ifthen", 3), ("uif", 1)]
            if self.free_ctrs and ctx["loops"] < self.max_loop_depth:
                choices += [("while", 2), ("dowhile", 2)]
        if ctx["loops"] > 0 and ctx.get("allow_break", False):
            choices += [("break", 2)]
        if ctx.get("allow_exit", False):
            choices += [("exit", 1)]
        kinds, weights = zip(*choices)
        k = rng.choices(kinds, weights)[0]
        if k == "alu":
            self.alu()
        elif k == "mem":
            self.mem(sm)
        elif k == "ifelse":
            tmp = self.cond()
            Lelse, Lend, Lthen = self.L("Lelse"), self.L("Lend"), self.L("Lthen")
            if rng.random() < 0.5:
                self.e(f"brz r{tmp}, {Lelse}")
                self.block(rng.randint(1, 3), depth + 1, ctx)
                self.e(f"jmp {Lend}")
                self.lab(Lelse)
                self.block(rng.randint(0, 3), depth + 1, ctx)
                self.lab(Lend)
            else:
                self.e(f"bra r{tmp}, {Lthen}")
                self.block(rng.randint(0, 3), depth + 1, ctx)
                self.e(f"jmp {Lend}")
                self.lab(Lthen)
                self.block(rng.randint(1, 3), depth + 1, ctx)
                self.lab(Lend)
        elif k == "ifthen":
            tmp = self.cond()
            Lend = self.L("Lend")
            self.e(f"brz r{tmp}, {Lend}")
            self.block(rng.randint(1, 4), depth + 1, ctx)
            self.lab(Lend)
        elif k == "uif":
            tmp = self.t()
            self.e(f"andi r{tmp}, r2, {rng.choice([1, 2])}")
            Lend = self.L("Lend")
            self.e(f"brz r{tmp}, {Lend}")
            self.block(rng.randint(1, 3), depth + 1, ctx)
            self.lab(Lend)
        elif k == "while":
            c = self.free_ctrs.pop()
            self.e(f"andi r{c}, r{self.d()}, 7")
            Lh, Lx = self.L("Lwh"), self.L("Lwx")
            self.lab(Lh)
            self.e(f"brz r{c}, {Lx}")
            ctx2 = dict(ctx, loops=ctx["loops"] + 1)
            self.loop_exit_labels.append(Lx)
            self.block(rng.randint(1, 4), depth + 1, ctx2)
            self.loop_exit_labels.pop()
            self.e(f"addi r{c}, r{c}, -1")
            self.e(f"jmp {Lh}")
            self.lab(Lx)
            self.free_ctrs.append(c)
        elif k == "dowhile":
            c = self.free_ctrs.pop()
            self.e(f"andi r{c}, r{self.d()}, 3")
            self.e(f"addi r{c}, r{c}, 1")
            Lh, Lx = self.L("Ldh"), self.L("Ldx")
            self.lab(Lh)
            ctx2 = dict(ctx, loops=ctx["loops"] + 1)
            self.loop_exit_labels.append(Lx)
            self.block(rng.randint(1, 4), depth + 1, ctx2)
            self.loop_exit_labels.pop()
            self.e(f"addi r{c}, r{c}, -1")
            self.e(f"bra r{c}, {Lh}")
            self.lab(Lx)
            self.free_ctrs.append(c)
        elif k == "break":
            tmp = self.cond(uniform_ok=False)
            op = rng.choice(["bra", "brz"])
            self.e(f"{op} r{tmp}, {self.loop_exit_labels[-1]}")
        elif k == "exit":
            tmp = self.cond(uniform_ok=False)
            op = rng.choice(["bra", "brz"])
            self.e(f"{op} r{tmp}, Lexit")

    # -- whole program -----------------------------------------------------
    def program(self) -> str:
        rng = self.rng
        lanes = self.lanes
        nwarps = (self.nthreads + lanes - 1) // lanes
        e = self.e
        e("tid r1")
        e("wgid r2")
        e("movi r30, 8")
        e("shl r3, r2, r30")
        e("add r3, r3, r1")
        e(f"movi r30, {IN1}")
        e("add r6, r3, r30")
        e(f"movi r30, {OUT0}")
        e("add r4, r3, r30")
        e(f"movi r30, {OUT1}")
        e("add r5, r3, r30")
        e("ld r8, [r3+0]")
        e("ld r9, [r6+0]")
        e("xor r10, r8, r1")
        e("add r11, r9, r8")
        e("addi r12, r8, 7")
        e("sub r13, r9, r1")
        e("xor r14, r8, r9")
        e("add r15, r1, r2")

        # warp-granular early exit (convergent: threshold is a multiple of the warp size)
        if nwarps > 1 and rng.random() < 0.3:
            k = rng.randint(1, nwarps - 1)
            tmp = self.t()
            e(f"movi r{tmp}, {k * lanes}")
            e(f"slt r{tmp}, r1, r{tmp}")
            e(f"brz r{tmp}, Lexit")

        nphase = rng.randint(1, 3 + self.size) if self.barriers else 1
        for ph in range(nphase):
            mode = "W" if ph % 2 == 0 else "R"
            if not self.shared:
                mode = "N"
            ctx = dict(loops=0, shared=mode, allow_break=False, allow_exit=False)
            wrap = self.barriers and rng.random() < 0.3
            if wrap and self.free_ctrs:
                # uniform loop with constant trip count containing a full W/R/BAR/BAR cycle
                c = self.free_ctrs.pop()
                trip = rng.randint(2, 3)
                e(f"movi r{c}, {trip}")
                Lh = self.L("Lbh")
                self.lab(Lh)
                ctxw = dict(ctx, shared="W")
                self.block(rng.randint(1, 2 + self.size), 0, ctxw)
                if self.barriers:
                    e("bar")
                ctxr = dict(ctx, shared="R" if self.shared else "N")
                self.block(rng.randint(1, 2 + self.size), 0, ctxr)
                if self.barriers:
                    e("bar")
                e(f"addi r{c}, r{c}, -1")
                e(f"bra r{c}, {Lh}")
                self.free_ctrs.append(c)
            elif self.barriers and rng.random() < 0.2:
                tmp = self.t()
                Lend = self.L("Lbu")
                e(f"andi r{tmp}, r2, 1")
                e(f"brz r{tmp}, {Lend}")          # workgroup-uniform if
                self.block(rng.randint(1, 3), 0, ctx)
                e("bar")
                self.block(rng.randint(1, 3), 0, dict(ctx, shared="R" if mode == "W" else "W"))
                self.lab(Lend)
            else:
                self.block(rng.randint(2, 4 + self.size * 2), 0, ctx)
            if self.barriers and ph != nphase - 1:
                e("bar")

        # final block: divergent early exits / breaks allowed (no barrier can follow)
        ctx = dict(loops=0, shared="N", allow_break=True, allow_exit=rng.random() < 0.5)
        self.block(rng.randint(2, 4 + self.size * 2), 0, ctx)
        e("st r8, [r4+0]")
        e("st r9, [r5+0]")
        self.lab("Lexit")
        e("exit")
        return "\n".join(self.out) + "\n"


def make_init_mem(seed: int, words: int = 1 << 14) -> List[int]:
    rng = random.Random(seed ^ 0x5F3759DF)
    mem = [0] * words
    for i in range(IN1 + 1024):
        mem[i] = rng.getrandbits(32)
    return mem


def gen_program(seed: int, lanes: int, nthreads: int, **kw) -> str:
    return Gen(seed, lanes, nthreads, **kw).program()
