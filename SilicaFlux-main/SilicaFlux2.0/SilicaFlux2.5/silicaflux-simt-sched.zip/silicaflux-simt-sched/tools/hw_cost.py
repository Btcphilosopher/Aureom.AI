#!/usr/bin/env python3
"""Analytical hardware-cost accounting of the three arbiters (NOT a synthesis result).

Why analytical: the only synthesis tool available here, Yosys 0.33, cannot parse the ORIGINAL
round-robin / age arbiters (package functions with `return`, `automatic` locals, `int'()` casts,
multi-dimensional packed-array ports), so no like-for-like gate count of the three RTL files exists.
Writing separate tool-friendly versions would measure different RTL.  Instead this script counts
exactly what the RTL declares - flip-flops and the arithmetic / comparison / multiplexing operators in
the grant path - from the same parameters the RTL uses.  It claims NO area, delay or power figure.

    hw_cost.py [--out results/hw_cost.md]
"""
import argparse
import math
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))


def clog2(x):
    return max(1, math.ceil(math.log2(x))) if x > 1 else 1


def class_rr(n, sl):
    pw = clog2(n)
    return dict(
        ff=4 * pw + clog2(4),
        ff_note=f"4 class pointers x {pw} + 1 class-level pointer x 2",
        adders="5 pointer increments (<= %d bit)" % pw,
        cmp="none (rotating-priority masks)",
        mux=f"4 per-class + 1 class-level priority selection over {n} / 4 requesters",
        depth="2 priority-select levels (class, then warp) + OR of 4 class grants",
    )


def age(n, sl):
    cw = clog2(sl + 2)
    return dict(
        ff=n * (n - 1) + n * cw,
        ff_note=f"{n}x{n-1} age matrix (diagonal is constant) + {n} lost-grant counters x {cw}",
        adders=f"{n} counter increments ({cw} bit)",
        cmp=f"{n} x ({cw}-bit >= STARVE_LIMIT)",
        mux=f"{n*(n-1)} AND terms + {n} OR-reductions of {n-1} inputs (oldest-first), 1 urgent-mask mux",
        depth="urgent compare -> mask -> one AND/OR matrix level (about log2(N)+3 gate levels)",
    )


def aware(n, sl):
    pw = clog2(n)
    return dict(
        ff=n * 7 + n + n + 4 * 4 + pw,
        ff_note=f"{n} lost-grant counters x 7 + {2*n} sticky flags + 4 class-bypass counters x 4 + pointer {pw}",
        adders=f"{n} x (7 score adders + 3 small multipliers 2b x 3b) + {n} lost-grant increments + {n} index adders ({pw} bit)",
        cmp=f"{n} x 7-bit urgency + {n} x 4-bit class urgency + {n-1} x 16-bit key compares in the tournament tree",
        mux=f"rotation of {n} keys: {n} x {pw} levels x (16+1+{pw}) bits = {n*pw*(17+pw)} mux2 bits; tournament selects: {n-1} x (17+{pw}) bits",
        depth=f"score (4-5 chained small adds) -> key -> {pw} rotation levels -> {pw} compare/select levels",
    )


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "hw_cost.md"))
    a = ap.parse_args()
    rows = []
    out = ["## 9. Scheduling overhead\n"]
    out.append("### 9.1 Cycle overhead (measured)\n")
    out.append("All three arbiters are purely combinational in the issue cycle: the grant is the issue (`be_valid` is asserted in the same cycle). "
               "Policy 2 therefore adds **no pipeline stage and no issue bubble**. Assertion D1 (`grant` subset of legal candidates, and a candidate "
               "implies a grant) is active in every simulation of every policy, so the scheduler never causes an idle issue slot. "
               "Any throughput difference between policies is a consequence of *which* warp is chosen, not of decision latency.\n")
    out.append("### 9.2 State and datapath (analytical count read from the RTL; **not synthesised, no area/delay/power claimed**)\n")
    out.append("Why not synthesised: Yosys 0.33, the only synthesis tool that could be installed in this environment, cannot parse the original "
               "round-robin and age arbiters (package functions using `return`, `automatic` locals in loops, `int'()` casts, multi-dimensional packed ports), "
               "so a like-for-like gate count of the three RTL files could not be obtained. Re-running with a modern SystemVerilog front end "
               "(e.g. a yosys-slang flow) is the recommended next step before any area or timing statement is made.\n")
    for n in (8, 16):
        sl = 2 * n
        out.append(f"**NUM_WARPS = {n}** (STARVE_LIMIT / fair_limit = {sl})\n")
        out.append("| | class round-robin (baseline) | age (oldest-first + guard) | aware (policy 2) |")
        out.append("|---|---|---|---|")
        c, g, w = class_rr(n, sl), age(n, sl), aware(n, sl)
        out.append(f"| flip-flops | **{c['ff']}** ({c['ff_note']}) | **{g['ff']}** ({g['ff_note']}) | **{w['ff']}** ({w['ff_note']}) |")
        out.append(f"| adders / multipliers | {c['adders']} | {g['adders']} | {w['adders']} |")
        out.append(f"| comparators | {c['cmp']} | {g['cmp']} | {w['cmp']} |")
        out.append(f"| selection / muxing | {c['mux']} | {g['mux']} | {w['mux']} |")
        out.append(f"| grant-path depth (qualitative) | {c['depth']} | {g['depth']} | {w['depth']} |")
        out.append("")
    out.append("Additional policy-2 cost outside the arbiter: a 43-bit static configuration register (weights and limits), per-warp feature extraction in "
               "`sfx_simt_ctrl` (a popcount of the workgroup's parked-warp mask and two mask-equality compares per warp for the barrier features, "
               "a 2-bit headroom hint per backend class, and the load flag from the decoder), and an `be_cap` input from the backend (advisory; tie it to a constant to "
               "disable the capacity term).\n")
    out.append("**Reading of the table.** Policy 2 needs more state than round-robin (about 6.5x at 8 warps) but less than the age policy, whose N x N age matrix grows "
               "quadratically; its arithmetic is the dominant new cost and it has the deepest combinational grant path of the three. Because the grant also drives the "
               "backend issue interface in the same cycle, that depth is a **timing-closure risk that this work has not measured**; the mitigation "
               "(computing the score a cycle early from registered features) is not implemented.\n")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    open(a.out, "w").write("\n".join(out) + "\n")
    print(f"[hw_cost] wrote {a.out}")


if __name__ == "__main__":
    main()
