#!/usr/bin/env python3
"""Co-simulation runner: reference simulator vs RTL (Verilator).

  * RtlConfig   : parameter set of the DUT; builds (and caches) a Verilator binary
  * run_rtl()   : run one program on the RTL, parse the dump
  * compare()   : architectural comparison RTL vs SimtSim reference
                    - per-warp issue trace  (pc, active mask) sequence
                    - final per-thread registers, final global memory
                    - kernel fault record
                    - counters: issued, divergent branches, barrier episodes,
                      stack high-water mark, plus the counter invariants
  * CLI         : run one assembly file
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
import threading
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sfx_isa import assemble, write_hex, FAULT_NAMES, FAULT_STACK_OVF
from sfx_ref import Cfg, SimtSim, Result

_BUILD_LOCK = threading.Lock()      # one (re)build at a time; sims themselves run concurrently

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))


@dataclass
class RtlConfig:
    name: str = "rr32"
    num_warps: int = 8
    num_wgs: int = 4
    warp_size: int = 32
    stack_depth: int = 8
    sched_policy: int = 0
    starve_limit: int = 16
    strict_bar_pc: int = 0
    max_inflight: int = 15
    extra: List[str] = field(default_factory=list)

    def gflags(self) -> List[str]:
        return [f"-GNUM_WARPS={self.num_warps}", f"-GNUM_WGS={self.num_wgs}",
                f"-GWARP_SIZE={self.warp_size}", f"-GSTACK_DEPTH={self.stack_depth}",
                f"-GSCHED_POLICY={self.sched_policy}", f"-GSTARVE_LIMIT={self.starve_limit}",
                f"-GSTRICT_BAR_PC=1'b{self.strict_bar_pc}", f"-GMAX_INFLIGHT={self.max_inflight}"] + self.extra

    def ref_cfg(self) -> Cfg:
        return Cfg(lanes=self.warp_size, stack_depth=self.stack_depth, max_warps=self.num_warps,
                   strict_bar_pc=bool(self.strict_bar_pc))

    def binary(self) -> str:
        return os.path.join(ROOT, "build", self.name, "simt_tb")

    def _stale(self, b: str) -> bool:
        if not os.path.exists(b):
            return True
        if os.environ.get("SFX_FROZEN_BUILD") == "1":      # long-running tools: build once, never rebuild mid-run
            return False
        t = os.path.getmtime(b)
        for d in ("rtl", "tb"):
            for f in os.listdir(os.path.join(ROOT, d)):
                if f.endswith((".sv", ".svh")) and os.path.getmtime(os.path.join(ROOT, d, f)) > t:
                    return True
        return os.path.getmtime(os.path.join(ROOT, "build", "build_sim.sh")) > t

    def build(self, force: bool = False) -> str:
        b = self.binary()
        if not (force or self._stale(b)):
            return b
        with _BUILD_LOCK:
            if not (force or self._stale(b)):      # another thread rebuilt it while we waited
                return b
            subprocess.run([os.path.join(ROOT, "build", "build_sim.sh"), self.name] + self.gflags(),
                           check=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        return b


@dataclass
class RtlRun:
    ok: bool
    returncode: int = 0
    stdout: str = ""
    trace: Dict[Tuple[int, int], List[Tuple[int, int]]] = field(default_factory=dict)
    regs: Dict[Tuple[int, int], List[int]] = field(default_factory=dict)
    mem: Dict[int, int] = field(default_factory=dict)
    cnt: Dict[str, int] = field(default_factory=dict)
    fault: Tuple[int, int, int, int, int, int] = (0, 0, 0, 0, 0, 0)  # valid code wg widx pc mask
    cycles: int = 0
    extra: Dict[str, int] = field(default_factory=dict)
    order: List[Tuple[int, int, int]] = field(default_factory=list)    # global issue order (wg, warp, pc)
    # ---- scheduler statistics from tb/sfx_sched_monitor.sv ----
    launch: Dict[int, Tuple[int, int]] = field(default_factory=dict)   # wg -> (launch cycle, warps)
    warps: Dict[Tuple[int, int], Tuple[int, int, int, int, int]] = field(default_factory=dict)  # (wg,widx) -> issued,cand,notsel,maxwait,exit_cycle
    cls_stat: Dict[int, Tuple[int, int, int, int]] = field(default_factory=dict)  # class -> grants, wait count, wait sum, wait max
    hist: Dict[str, Tuple[int, ...]] = field(default_factory=dict)


def run_rtl(cfg: RtlConfig, prog_words: List[int], init_mem: Optional[List[int]], nthreads: int,
            nwgs: int, profile: int = 0, seed: int = 1, launch_gap: int = 0, reps: int = 1,
            entry: int = 0, workdir: Optional[str] = None, maxcyc: int = 3_000_000,
            keep: bool = False, proglen: Optional[int] = None, extra_args=()) -> RtlRun:
    binary = cfg.build()
    tmp = workdir or tempfile.mkdtemp(prefix="sfxrun_")
    os.makedirs(tmp, exist_ok=True)
    ph = os.path.join(tmp, "prog.hex")
    write_hex(prog_words, ph)
    args = [binary, f"+prog={ph}", f"+proglen={proglen if proglen is not None else len(prog_words)}",
            f"+nthreads={nthreads}", f"+nwgs={nwgs}", f"+profile={profile}", f"+seed={seed}",
            f"+launch_gap={launch_gap}", f"+reps={reps}", f"+entry={entry}", f"+maxcyc={maxcyc}",
            f"+out={os.path.join(tmp, 'rtl')}"]
    args += list(extra_args)
    if init_mem is not None:
        mh = os.path.join(tmp, "mem.hex")
        with open(mh, "w") as f:
            for i, v in enumerate(init_mem):
                if v:
                    f.write(f"@{i:x}\n{v:08x}\n")
        args.append(f"+mem={mh}")
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=1200)
    run = RtlRun(ok=(p.returncode == 0), returncode=p.returncode, stdout=p.stdout)
    for line in p.stdout.splitlines():
        if line.startswith("[SFX-CHK] max_wait="):
            kv = dict(x.split("=") for x in line.split()[1:])
            run.extra["chk_max_wait"] = int(kv["max_wait"])
            run.extra["chk_bound"] = int(kv["bound"])
    logf = os.path.join(tmp, "rtl.log")
    if run.ok and os.path.exists(logf):
        for line in open(logf):
            t = line.split()
            if not t:
                continue
            k = t[0]
            if k == "I":
                run.trace.setdefault((int(t[1]), int(t[2])), []).append((int(t[3]), int(t[4], 16)))
                run.order.append((int(t[1]), int(t[2]), int(t[3])))
            elif k == "R":
                run.regs[(int(t[1]), int(t[2]))] = [int(x, 16) for x in t[3:35]]   # r0..r31
            elif k == "M":
                run.mem[int(t[1])] = int(t[2], 16)
            elif k == "C":
                run.cnt[t[1]] = int(t[2])
            elif k == "F":
                run.fault = tuple(int(x) for x in t[1:7])
            elif k == "D":
                run.cycles = int(t[1])
            elif k == "X":
                run.extra[t[1]] = int(t[2])
            elif k == "L":
                run.launch[int(t[1])] = (int(t[2]), int(t[3]))
            elif k == "W":
                run.warps[(int(t[1]), int(t[2]))] = tuple(int(x) for x in t[3:8])
            elif k == "G":
                run.cls_stat[int(t[1])] = tuple(int(x) for x in t[2:6])
            elif k == "H":
                run.hist[t[1]] = tuple(int(x) for x in t[2:])
    if not keep and workdir is None:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    return run


def compare(rtl: RtlRun, ref: Result, cfg: RtlConfig, init_mem: Optional[List[int]], *,
            expect_fault: bool = False, fault_exact_warp: bool = True, check_counters: bool = True,
            allow_proto: bool = False) -> List[str]:
    """Return a list of mismatch descriptions (empty == RTL matches the reference)."""
    errs: List[str] = []
    aborted = set(ref.aborted_wgs)
    c = rtl.cnt
    # -- counter invariants (always) --
    if c:
        idle_sum = sum(c[k] for k in ("idle_nowarp", "idle_be", "idle_mem", "idle_dep", "idle_br",
                                      "idle_fetch", "idle_bar", "idle_other"))
        wc_sum = sum(c[k] for k in ("wc_issue", "wc_notsel", "wc_dep", "wc_mem", "wc_bar", "wc_br",
                                    "wc_fetch", "wc_be", "wc_drain"))
        if c["cycles"] != c["issued"] + c["idle"]:
            errs.append(f"cycles {c['cycles']} != issued {c['issued']} + idle {c['idle']}")
        if idle_sum != c["idle"]:
            errs.append(f"idle causes sum {idle_sum} != idle {c['idle']}")
        if wc_sum != c["wc_resident"]:
            errs.append(f"warp-cycle buckets sum {wc_sum} != resident {c['wc_resident']}")
        if c["issued"] != c["retired"]:
            errs.append(f"issued {c['issued']} != retired {c['retired']}")
        if c["proto_err"] and not allow_proto:
            errs.append(f"proto_err = {c['proto_err']}")
        if allow_proto and not c["proto_err"]:
            errs.append("hostile downstream: expected proto_err > 0 (spurious traffic must be counted)")
        if sum(c[f"warp_issued_{w}"] for w in range(cfg.num_warps)) != c["issued"]:
            errs.append("sum of per-warp issue counters != issued")
        if any(c[f"warp_issued_{w}"] for w in range(cfg.num_warps) if w >= cfg.num_warps):
            errs.append("per-warp counter out of range")

    # -- fault record --
    fv, fcode, fwg, fwidx, fpc, fmask = rtl.fault
    if ref.faults:
        exp = ref.faults[0]            # (wg, widx, code, pc)
        if not fv:
            errs.append(f"expected fault {FAULT_NAMES[exp[2]]} but RTL reported none")
        else:
            if fcode != exp[2]:
                errs.append(f"fault code RTL={FAULT_NAMES.get(fcode, fcode)} ref={FAULT_NAMES[exp[2]]}")
            if fwg != exp[0]:
                errs.append(f"fault wg RTL={fwg} ref={exp[0]}")
            if fault_exact_warp and (fwidx != exp[1] or fpc != exp[3]):
                errs.append(f"fault location RTL=(warp {fwidx}, pc {fpc}) ref=(warp {exp[1]}, pc {exp[3]})")
    else:
        if fv:
            errs.append(f"unexpected RTL fault {FAULT_NAMES.get(fcode, fcode)} wg{fwg} warp{fwidx} pc{fpc}")

    # -- per-warp traces and registers for healthy workgroups --
    for key, tr in sorted(ref.trace.items()):
        wg = key[0]
        if wg in aborted:
            continue
        rt = rtl.trace.get(key, [])
        if rt != tr:
            n = min(len(rt), len(tr))
            first = next((i for i in range(n) if rt[i] != tr[i]), n)
            errs.append(f"trace wg{wg} warp{key[1]} differs at step {first}: "
                        f"rtl={rt[first] if first < len(rt) else None} ref={tr[first] if first < len(tr) else None} "
                        f"(len rtl={len(rt)} ref={len(tr)})")
            if len(errs) > 12:
                return errs
    for key, regs in sorted(ref.regs.items()):
        got = rtl.regs.get(key)
        if got is None:
            errs.append(f"missing register dump for wg{key[0]} tid{key[1]}")
            continue
        if got != regs:
            r = next(i for i in range(32) if got[i] != regs[i])
            errs.append(f"wg{key[0]} tid{key[1]} r{r}: rtl={got[r]:#x} ref={regs[r]:#x}")
        if len(errs) > 12:
            return errs
    extra_regs = [k for k in rtl.regs if k not in ref.regs and k[0] not in aborted]
    if extra_regs:
        errs.append(f"RTL dumped registers for unexpected threads: {extra_regs[:4]}")

    # -- memory --
    if not aborted:
        rm = {i: v for i, v in enumerate(ref.gmem) if v}
        if rtl.mem != rm:
            diff = sorted(set(rm) ^ set(rtl.mem)) + [a for a in rm if a in rtl.mem and rm[a] != rtl.mem[a]]
            a = diff[0]
            errs.append(f"gmem differs at {len(set(diff))} words, e.g. [{a}] rtl={rtl.mem.get(a, 0):#x} ref={rm.get(a, 0):#x}")

    # -- counters tied to architectural behaviour --
    if check_counters and c and not ref.faults:
        if c["issued"] != ref.issued:
            errs.append(f"issued RTL={c['issued']} ref={ref.issued}")
        if c["bar_episodes"] != ref.barrier_episodes:
            errs.append(f"barrier episodes RTL={c['bar_episodes']} ref={ref.barrier_episodes}")
        if c["div_branches"] != ref.div_branches:
            errs.append(f"divergent branches RTL={c['div_branches']} ref={ref.div_branches}")
        hwm = max(ref.max_sp.values()) if ref.max_sp else 0
        if c["stack_hwm"] != hwm:
            errs.append(f"stack high-water RTL={c['stack_hwm']} ref={hwm}")
    return errs


def run_case(cfg: RtlConfig, prog_words: List[int], init_mem, nthreads: int, nwgs: int,
             profile: int = 0, seed: int = 1, launch_gap: int = 0, reps: int = 1, extra_args=(), **kw):
    """Run reference + RTL for one program; return (errors, rtl_run, ref_result)."""
    ref = SimtSim(prog_words, cfg.ref_cfg(), init_mem).run(nthreads, nwgs)
    rtl = run_rtl(cfg, prog_words, init_mem, nthreads, nwgs, profile, seed, launch_gap, reps, extra_args=extra_args)
    if not rtl.ok:
        tail = "\n".join(rtl.stdout.strip().splitlines()[-6:])
        return [f"RTL run failed (rc={rtl.returncode}): {tail}"], rtl, ref
    return compare(rtl, ref, cfg, init_mem, **kw), rtl, ref


def main():
    ap = argparse.ArgumentParser(description="run one assembly program on RTL and compare with the reference")
    ap.add_argument("asm")
    ap.add_argument("--nthreads", type=int, default=64)
    ap.add_argument("--nwgs", type=int, default=1)
    ap.add_argument("--profile", type=int, default=1)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--policy", type=int, default=0)
    ap.add_argument("--lanes", type=int, default=32)
    a = ap.parse_args()
    prog = assemble(open(a.asm).read())
    cfg = RtlConfig(name=f"p{a.policy}_l{a.lanes}", sched_policy=a.policy, warp_size=a.lanes)
    errs, rtl, ref = run_case(cfg, prog.words, None, a.nthreads, a.nwgs, a.profile, a.seed)
    print("PASS" if not errs else "FAIL")
    for e in errs:
        print("  ", e)
    print(f"cycles={rtl.cycles} issued={rtl.cnt.get('issued')} idle={rtl.cnt.get('idle')}")
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
