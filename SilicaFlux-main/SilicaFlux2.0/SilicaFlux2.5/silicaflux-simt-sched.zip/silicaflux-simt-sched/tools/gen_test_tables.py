#!/usr/bin/env python3
"""Print markdown tables of the directed tests and the mutants (generated from the sources)."""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "tests"))
import directed
import mutate


def main():
    print("| directed test | configs | timing profiles | what it checks |")
    print("|---|---|---|---|")
    for t in directed.all_tests():
        print(f"| `{t.name}` | {', '.join(t.cfgs)} | {','.join(map(str, t.profiles))} | {t.doc} |")
    print()
    print("| mutant | config | injected bug |")
    print("|---|---|---|")
    for m in mutate.M:
        print(f"| `{m['name']}` | {m['cfg']} | {m['doc']} |")


if __name__ == "__main__":
    main()
