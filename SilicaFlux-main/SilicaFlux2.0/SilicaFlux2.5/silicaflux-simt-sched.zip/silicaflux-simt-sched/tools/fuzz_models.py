#!/usr/bin/env python3
"""Fuzz OracleSim (per-thread semantics) against SimtSim (reconvergence-stack
model).  Pure Python: no RTL involved.  A mismatch means the architectural
divergence model (or the generator's legality) is wrong.

usage: fuzz_models.py [--n 500] [--seed0 0] [--lanes 8,32] [--stack-depth 8]
"""
import argparse
import collections
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sfx_isa import assemble, AsmError, FAULT_STACK_OVF
from sfx_cfg import lint_program, CfgError
from sfx_gen import gen_program, make_init_mem
from sfx_ref import Cfg, OracleSim, SimtSim, compare_results, SimError


def one(seed: int, lanes: int, depth: int, verbose=False):
    rng = random.Random(seed * 7919 + lanes)
    max_threads = 8 * lanes
    nthreads = rng.choice([1, lanes // 2, lanes - 1, lanes, lanes + 1, 2 * lanes, 3 * lanes + 3,
                           rng.randint(1, max_threads), max_threads])
    nthreads = max(1, min(nthreads, max_threads))
    nwgs = rng.randint(1, 3)
    kw = dict(max_div_depth=rng.choice([2, 3, 3, 4]), size=rng.randint(0, 2))
    src = gen_program(seed, lanes, nthreads, **kw)
    prog = assemble(src)
    problems = lint_program(prog)
    if problems:
        return ("lint", problems, src)
    cfg = Cfg(lanes=lanes, stack_depth=depth)
    mem = make_init_mem(seed)
    try:
        ref = SimtSim(prog.words, cfg, mem).run(nthreads, nwgs)
    except SimError as ex:
        return ("simt-error", str(ex), src)
    if ref.faults:
        if all(f[2] == FAULT_STACK_OVF for f in ref.faults):
            # generator nested deeper than STACK_DEPTH: a defined overflow fault, not a model disagreement
            return ("skipped-overflow", ref.faults, src)
        return ("simt-fault", ref.faults, src)
    try:
        orc = OracleSim(prog.words, cfg, mem).run(nthreads, nwgs)
    except SimError as ex:
        return ("oracle-error", str(ex), src)
    errs = compare_results(orc, ref)
    if orc.barrier_episodes != ref.barrier_episodes:
        errs.append(f"barrier episodes oracle={orc.barrier_episodes} simt={ref.barrier_episodes}")
    if errs:
        return ("mismatch", errs, src)
    return ("ok", dict(max_sp=max(ref.max_sp.values()), div=ref.div_branches,
                       bars=ref.barrier_episodes, issued=ref.issued, n=len(prog)), src)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--seed0", type=int, default=0)
    ap.add_argument("--lanes", default="8,32")
    ap.add_argument("--stack-depth", type=int, default=8)
    a = ap.parse_args()
    bad = 0
    stats = collections.Counter()
    sp_hist = collections.Counter()
    tot_div = tot_bar = 0
    for lanes in [int(x) for x in a.lanes.split(",")]:
        for s in range(a.seed0, a.seed0 + a.n):
            try:
                kind, info, src = one(s, lanes, a.stack_depth)
            except (AsmError, CfgError) as ex:
                kind, info, src = "asm-error", str(ex), ""
            stats[kind] += 1
            if kind == "ok":
                sp_hist[info["max_sp"]] += 1
                tot_div += info["div"]
                tot_bar += info["bars"]
            elif kind == "skipped-overflow":
                pass
            else:
                bad += 1
                if bad <= 3:
                    print(f"--- seed {s} lanes {lanes}: {kind}: {info}")
                    print(src)
    print("results:", dict(stats))
    print("max stack depth histogram (per program):", dict(sorted(sp_hist.items())))
    print(f"divergent branches executed: {tot_div}, barrier episodes: {tot_bar}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
