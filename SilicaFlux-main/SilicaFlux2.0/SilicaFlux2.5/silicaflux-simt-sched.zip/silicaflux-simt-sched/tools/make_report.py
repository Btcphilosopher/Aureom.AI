#!/usr/bin/env python3
"""Turn the raw comparison runs into results/REPORT.md (+ CSV tables).

CLAIM RULE (fixed here, before looking at any number, and printed in the report):
  For a ratio metric (policy / round-robin baseline, lower = better) over a set of workload
  instances the report says
      "better"  only if the 95% cluster-bootstrap CI of the geometric-mean ratio lies entirely
                below 1 AND the geometric mean is below 1 - TIE  (TIE = 0.5 %)
      "worse"   only if the CI lies entirely above 1 AND the geometric mean is above 1 + TIE
      "n.s."    otherwise (no measurable difference)
  Clusters are workload seeds (one cluster holds both geometries of one seed), so the two geometries
  of one seed are not counted as independent evidence.  Only held-out TEST seeds are used.

    make_report.py --test results/raw_test.json [--dev results/raw_dev.json] [--sweep results/sweep_dev.json]
                   [--ablation results/raw_ablation.json] [--hw results/hw_cost.md] --out results/REPORT.md
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
import sys
from collections import defaultdict
from typing import Dict, List, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
TIE = 0.005
NBOOT = 2000

RATIO_METRICS = [            # (key, label, what it measures)
    ("cycles",        "kernel cycles",            "makespan = 1/throughput (same instruction count in every run)"),
    ("idle",          "idle issue cycles",        "cycles in which nothing issued"),
    ("warp_done_p95", "p95 warp completion",      "tail completion time over warps"),
    ("wg_lat_p95",    "p95 workgroup latency",    "launch to last-warp exit, 95th percentile over workgroups"),
    ("wg_lat_max",    "max workgroup latency",    "slowest workgroup"),
]
ABS_METRICS = [              # (key, label, higher_is_better)
    ("jain_service",     "Jain index of per-warp service share", True),
    ("max_wait",         "longest wait as candidate (cycles)", False),
    ("memdep_wait_mean", "mean wake-to-issue wait, memory-dependent warps (cycles)", False),
    ("memdep_wait_max",  "max wake-to-issue wait, memory-dependent warps (cycles)", False),
    ("other_wait_mean",  "mean candidate-to-issue wait, all other issues (cycles)", False),
    ("ipc",              "issue throughput (warp-instr / cycle)", True),
]
LABEL = {"rr": "RR (baseline)", "age": "age", "aware": "aware (default weights)", "aware_w0": "aware, all weights 0",
         "aware_tuned": "aware (dev-tuned weights)"}


def gm(xs: List[float]) -> float:
    return math.exp(sum(math.log(x) for x in xs) / len(xs))


def boot_ci(clusters: List[List[float]], seed: int = 12345) -> Tuple[float, float, float]:
    """geometric mean and 95% cluster-bootstrap CI of ratios"""
    allr = [x for c in clusters for x in c]
    point = gm(allr)
    rng = random.Random(seed)
    n = len(clusters)
    ests = []
    for _ in range(NBOOT):
        pick = [clusters[rng.randrange(n)] for _ in range(n)]
        ests.append(gm([x for c in pick for x in c]))
    ests.sort()
    return point, ests[int(0.025 * NBOOT)], ests[int(0.975 * NBOOT) - 1]


def verdict(point: float, lo: float, hi: float) -> str:
    if hi < 1.0 and point < 1 - TIE:
        return "better"
    if lo > 1.0 and point > 1 + TIE:
        return "worse"
    return "n.s."


def fmt(point, lo, hi) -> str:
    return f"{point:.3f} [{lo:.3f}, {hi:.3f}]"


def load(path: str):
    recs = json.load(open(path))
    bad = [r for r in recs if "error" in r]
    if bad:
        raise SystemExit(f"{path}: {len(bad)} failing runs, e.g. {bad[0]['workload']} {bad[0]['variant']}: {bad[0]['error']}")
    tab: Dict[Tuple[str, int, str], Dict[str, dict]] = defaultdict(dict)    # (family, seed, geom) -> variant -> metrics
    for r in recs:
        tab[(r["family"], r["seed"], r["geom"])][r["variant"]] = r["metrics"]
    return recs, tab


def ratios(tab, variant, metric, fam=None, geom=None):
    """list of clusters (one per (family, seed)), each a list of ratios over geometries"""
    cl: Dict[Tuple[str, int], List[float]] = defaultdict(list)
    for (f, s, g), v in tab.items():
        if (fam and f != fam) or (geom and g != geom) or variant not in v or "rr" not in v:
            continue
        b, x = v["rr"][metric], v[variant][metric]
        if b > 0 and x > 0:
            cl[(f, s)].append(x / b)
    return [c for c in cl.values() if c]


def wlt(tab, variant, metric) -> Tuple[int, int, int]:
    w = l = t = 0
    for v in tab.values():
        if variant in v and "rr" in v and v["rr"][metric] > 0:
            r = v[variant][metric] / v["rr"][metric]
            if r < 1 - TIE: w += 1
            elif r > 1 + TIE: l += 1
            else: t += 1
    return w, t, l


def mean(xs):
    xs = list(xs)
    return sum(xs) / len(xs) if xs else float("nan")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--test", required=True)
    ap.add_argument("--dev")
    ap.add_argument("--sweep")
    ap.add_argument("--hw")
    ap.add_argument("--ablation", help="raw JSON of the post-hoc ablation of the tuned configuration")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    recs, tab = load(a.test)
    variants = [v for v in ("age", "aware", "aware_w0", "aware_tuned") if any(v in x for x in tab.values())]
    fams = sorted({k[0] for k in tab})
    geoms = sorted({k[2] for k in tab})
    seeds = sorted({k[1] for k in tab})
    out = []
    P = out.append
    csv_rows = []

    # ------------------------------------------------------------------ header / validity
    nrun = len(recs)
    P("# Warp scheduler comparison: round-robin vs age-aware vs readiness/capacity-aware\n")
    P("Generated by `tools/make_report.py` from `%s`. Every number below is measured in RTL simulation (Verilator) of the "
      "SilicaFlux SIMT control unit; nothing is estimated unless explicitly labelled." % os.path.basename(a.test))
    P("\n## 1. What was measured, and why the workloads are equivalent\n")
    P(f"* **{len(fams)} workload families x {len(seeds)} held-out seeds x {len(geoms)} geometries = {len(tab)} workload instances**, each run under "
      f"**{len(variants) + 1} scheduler variants** ({nrun} simulations). Geometries: `g8` = 8 warp slots / 4 workgroup slots, `g16` = 16 / 8 (32 lanes).")
    P("* Every instance is generated by `tools/wl_gen.py` from `(family, seed)`: program image, initial memory, launch configuration and a **latency trace** "
      "indexed by `(workgroup, warp, k-th backend instruction)`. The service demand of an instruction therefore does not depend on the schedule. "
      "The stock backend model draws latencies from one global RNG, which *does* depend on the schedule, so it was **not** used for the comparison.")
    P("* Evidence that all policies saw the same workload (checked on every run by `compare_policies.py`, which aborts otherwise): "
      "identical input-file fingerprints; identical **trace entries, latency sum and gap sum actually consumed by the backend**; trace opcode == issued opcode "
      "for every dynamic instruction; every run bit-exact against the reference model (per-warp `(pc, active mask)` stream, all registers, global memory, "
      "barrier episodes, divergent branches, stack high-water mark).")
    P("* In-RTL assertions (`-DSFX_CHECKS`, groups A-D) and the independent monitor `tb/sfx_sched_monitor.sv` (RAW/WAW operand availability, backend "
      "readiness, BAR/EXIT memory drain, barrier-episode ordering, empty masks) were active in every run; none fired.")
    P(f"* **Claim rule** (fixed before measuring): a variant is called *better* / *worse* than the baseline on a metric only if the 95 % cluster-bootstrap confidence "
      f"interval of the geometric-mean ratio excludes 1 **and** the mean differs from 1 by more than {TIE:.1%}; otherwise *n.s.* (no measurable difference). "
      f"Clusters are seeds. Ratios are variant / baseline, so **< 1 is better** for cycles, idle and latency metrics.")
    P("* Weights of the *aware (default)* variant were fixed from first principles before any simulation. *aware (dev-tuned)* was tuned by coordinate descent on "
      "development seeds 1-6 only (`tools/sweep_cfg.py`); the seeds reported here (101-116) were never used for tuning.\n")

    # ------------------------------------------------------------------ headline
    P("## 2. Headline: all workloads together\n")
    P("Geometric-mean ratio vs the round-robin baseline, 95 % CI in brackets, verdict by the claim rule, and paired wins / ties / losses over the "
      f"{len(tab)} instances (tie band {TIE:.1%}).\n")
    P("| metric | " + " | ".join(LABEL[v] for v in variants) + " |")
    P("|---|" + "---|" * len(variants))
    headline = {}
    for key, label, _ in RATIO_METRICS:
        cells = []
        for v in variants:
            cl = ratios(tab, v, key)
            p, lo, hi = boot_ci(cl)
            w, t, l = wlt(tab, v, key)
            headline[(v, key)] = (p, lo, hi, verdict(p, lo, hi), w, t, l)
            cells.append(f"{fmt(p, lo, hi)} **{verdict(p, lo, hi)}** ({w}/{t}/{l})")
            csv_rows.append(["overall", "", v, key, p, lo, hi, verdict(p, lo, hi), w, t, l])
        P(f"| {label} | " + " | ".join(cells) + " |")
    cells = []
    for v in variants:
        d = [m["rr"]["cycles"] - m[v]["cycles"] for m in tab.values() if v in m]
        base = mean(m["rr"]["cycles"] for m in tab.values())
        cells.append(f"{mean(d):+.1f} cycles/run ({mean(d) / base:+.2%} of the baseline mean {base:.0f})")
    P("| mean absolute change in cycles (saved = +) | " + " | ".join(cells) + " |")
    P("\n(w/t/l = instances where the variant is better / tied / worse than the baseline. **Idle-cycle ratios exaggerate small absolute "
      "differences when idle time is a small part of the run; read them together with the cycles row.**)\n")

    # ------------------------------------------------------------------ per family
    P("## 3. Per workload family\n")
    desc = {}
    for r in recs:
        desc.setdefault(r["family"], None)
    FDESC = {
        "ldchain": "pointer chasing: long-latency loads feeding dependent arithmetic and the next load",
        "depalu": "ALU-only fully dependent chains incl. multiplies",
        "compute": "compute-heavy, high ILP, no memory",
        "mixed": "mixed kernel: compute / pointer-chasing / balanced warps in one workgroup",
        "skew": "6-7 compute-heavy warps + 1-2 memory-dependent warps in the youngest slots (starvation probe)",
        "memstream": "streaming loads+stores, 2 outstanding global operations (capacity bound)",
        "barrier": "barrier heavy: 6-9 phases x 2 barriers, unbalanced per-warp work, shared-memory exchange",
        "diverge": "half-warp divergence around loads, reconvergence every iteration (execution masks)",
    }
    for key, label, what in RATIO_METRICS[:4]:
        P(f"### 3.{[k for k, _, _ in RATIO_METRICS].index(key) + 1} {label} (ratio vs baseline; {what})\n")
        P("| family | " + " | ".join(LABEL[v] for v in variants) + " |")
        P("|---|" + "---|" * len(variants))
        for f in fams:
            cells = []
            for v in variants:
                cl = ratios(tab, v, key, fam=f)
                p, lo, hi = boot_ci(cl)
                vd = verdict(p, lo, hi)
                cells.append(f"{p:.3f} [{lo:.3f}, {hi:.3f}] {'**' + vd + '**' if vd != 'n.s.' else vd}")
                csv_rows.append(["family", f, v, key, p, lo, hi, vd, "", "", ""])
            P(f"| {f} | " + " | ".join(cells) + " |")
        P("")
    P("Family definitions: " + "; ".join(f"`{f}` = {FDESC.get(f, '')}" for f in fams) + ".\n")

    # per geometry headline for cycles
    P("### 3.5 Cycles by geometry\n")
    P("| geometry | " + " | ".join(LABEL[v] for v in variants) + " |")
    P("|---|" + "---|" * len(variants))
    for g in geoms:
        cells = []
        for v in variants:
            cl = ratios(tab, v, "cycles", geom=g)
            p, lo, hi = boot_ci(cl)
            cells.append(f"{fmt(p, lo, hi)} {verdict(p, lo, hi)}")
        P(f"| {g} | " + " | ".join(cells) + " |")
    P("")

    # ------------------------------------------------------------------ fairness & wake latency
    P("## 4. Fairness, starvation and memory-dependent wake-up (absolute means over instances)\n")
    P("Definitions: *service share* of a warp = issued instructions / cycles in which it was a legal candidate; Jain index over warps (1 = perfectly equal service when ready). "
      "*Wait* = consecutive cycles a legal candidate was not selected. *Memory-dependent* = a warp that was blocked on a load result since its previous issue.\n")
    allv = ["rr"] + variants
    for key, label, hib in ABS_METRICS:
        P(f"**{label}** ({'higher' if hib else 'lower'} is better)\n")
        P("| family | " + " | ".join(LABEL[v] for v in allv) + " |")
        P("|---|" + "---|" * len(allv))
        for f in fams + ["ALL"]:
            vals = []
            for v in allv:
                xs = [m[v][key] for (ff, s, g), m in tab.items() if (f == "ALL" or ff == f) and v in m and not (isinstance(m[v][key], float) and math.isnan(m[v][key]))]
                vals.append(mean(xs))
                csv_rows.append(["abs", f, v, key, mean(xs), "", "", "", "", "", ""])
            best = (max if hib else min)(vals)
            P(f"| {f} | " + " | ".join(f"**{x:.3f}**" if abs(x - best) < 1e-9 else f"{x:.3f}" for x in vals) + " |")
        P("")
    # observed bound vs asserted bound
    P("**Worst candidate wait seen by the in-RTL bounded-wait assertion C1 vs its bound** (max over instances; the run aborts if exceeded):\n")
    P("| variant | geometry | max wait observed | asserted bound |")
    P("|---|---|---|---|")
    for v in allv:
        for g in geoms:
            ms = [m[v] for (f, s, gg), m in tab.items() if gg == g and v in m]
            if ms:
                P(f"| {LABEL[v]} | {g} | {max(x['chk_max_wait'] for x in ms)} | {ms[0]['chk_bound']} |")
    P("")

    # ------------------------------------------------------------------ idle breakdown
    P("## 5. Where the idle cycles are (mean idle cycles per run, by cause)\n")
    P("| family | variant | idle | be (resource busy) | mem | dep | br | fetch | bar | other/nowarp |")
    P("|---|---|---|---|---|---|---|---|---|---|")
    for f in fams:
        for v in allv:
            ms = [m[v] for (ff, s, g), m in tab.items() if ff == f and v in m]
            P(f"| {f} | {LABEL[v]} | {mean(x['idle'] for x in ms):.0f} | {mean(x['idle_be'] for x in ms):.0f} | {mean(x['idle_mem'] for x in ms):.0f} | "
              f"{mean(x['idle_dep'] for x in ms):.0f} | {mean(x['idle_br'] for x in ms):.0f} | {mean(x['idle_fetch'] for x in ms):.0f} | "
              f"{mean(x['idle_bar'] for x in ms):.0f} | {mean(x['idle_other'] + x['idle_nowarp'] for x in ms):.0f} |")
    P("")

    # ------------------------------------------------------------------ baseline wins
    P("## 6. Where the baseline (round-robin) wins or ties\n")
    P("Automatically extracted: every (variant, scope, metric) whose verdict is **worse** than round-robin, then the cases where nothing beats it.\n")
    worse, better = [], []
    for v in variants:
        for key, label, _ in RATIO_METRICS:
            for scope, kw in [("overall", {})] + [(f, dict(fam=f)) for f in fams]:
                cl = ratios(tab, v, key, **kw)
                if not cl:
                    continue
                p, lo, hi = boot_ci(cl)
                vd = verdict(p, lo, hi)
                if vd == "worse":
                    worse.append((v, scope, label, p, lo, hi))
                elif vd == "better":
                    better.append((v, scope, label, p, lo, hi))
    P("**Variant is measurably WORSE than round-robin:**\n")
    if worse:
        P("| variant | scope | metric | ratio [95% CI] |")
        P("|---|---|---|---|")
        for v, sc, lb, p, lo, hi in worse:
            P(f"| {LABEL[v]} | {sc} | {lb} | {fmt(p, lo, hi)} |")
    else:
        P("_none_")
    P("\n**Variant is measurably BETTER than round-robin:**\n")
    if better:
        P("| variant | scope | metric | ratio [95% CI] |")
        P("|---|---|---|---|")
        for v, sc, lb, p, lo, hi in better:
            P(f"| {LABEL[v]} | {sc} | {lb} | {fmt(p, lo, hi)} |")
    else:
        P("_none_")
    P("")
    P("**Workload families on which no variant beats round-robin on kernel cycles** (verdict *n.s.* or *worse* for every variant):\n")
    none_better = []
    for f in fams:
        if all(verdict(*boot_ci(ratios(tab, v, "cycles", fam=f))) != "better" for v in variants):
            none_better.append(f)
    P(", ".join(f"`{f}`" for f in none_better) if none_better else "_none_")
    P("")
    P("**Baseline wins on worst-case wait**: longest wait of a legal candidate, mean over instances - " +
      ", ".join(f"{LABEL[v]} {mean(m[v]['max_wait'] for m in tab.values() if v in m):.1f}" for v in ['rr'] + variants) + " cycles (lower is better).\n")

    # ------------------------------------------------------------------ tuned / sweep
    if a.sweep and os.path.exists(a.sweep):
        sw = json.load(open(a.sweep))
        P("## 7. Configuration search (development seeds only)\n")
        P(f"Coordinate descent over the 11 weights (values 0,1,2,3,4,5,7; {sw['evaluations']} evaluations), objective = geometric mean of `{sw['metric']}` ratio vs round-robin over "
          f"development instances. Default configuration: **{sw['dev_score_default']:.4f}**; best found: **{sw['dev_score_tuned']:.4f}**.\n")
        P("| weight | default | tuned |")
        P("|---|---|---|")
        for k in sw["default"]:
            P(f"| `{k}` | {sw['default'][k]} | {sw['tuned'][k]} |")
        P("")
    # ------------------------------------------------------------------ ablation (post-hoc analysis)
    if a.ablation and os.path.exists(a.ablation):
        _, atab = load(a.ablation)
        AB = [("abl_tuned", "tuned configuration (reference)"), ("abl_no_cap", "no capacity term (`w_cap`=0)"),
              ("abl_no_barrier", "no barrier terms (`w_bar`=`w_rel`=0)"), ("abl_no_class", "no class bonuses"),
              ("abl_only_class", "class bonuses only"), ("abl_no_ld_dep", "no load / dependency terms"),
              ("abl_no_age", "no aging (`w_age`=0)"), ("abl_no_ctrl_cls", "`w_cls_ctrl`=0"),
              ("abl_guards_off", "both fairness guards OFF")]
        afams = sorted({k[0] for k in atab})
        P("## 7b. Which features carry the tuned gains? (post-hoc ablation, test seeds, analysis only)\n")
        P("Each row switches off part of the tuned configuration and re-runs the held-out instances. Cycles ratio vs round-robin (geometric mean; **< 1 is better**). "
          "This is explanatory analysis on the evaluation seeds: it supports no claim beyond those already made in sections 2-3.\n")
        P("| configuration | overall | " + " | ".join(afams) + " | mean max-wait (cycles) | mean max memory-dependent wake wait (cycles) |")
        P("|---|---|" + "---|" * len(afams) + "---|---|")
        for key, label in AB:
            if not any(key in x for x in atab.values()):
                continue
            g = [gm([m[key]["cycles"] / m["rr"]["cycles"] for (f, sd, ge), m in atab.items() if f == ff]) for ff in afams]
            o = gm([m[key]["cycles"] / m["rr"]["cycles"] for m in atab.values()])
            P(f"| {label} | {o:.4f} | " + " | ".join(f"{x:.4f}" for x in g) +
              f" | {mean(m[key]['max_wait'] for m in atab.values()):.1f} | {mean(m[key]['memdep_wait_max'] for m in atab.values()):.1f} |")
        P(f"| round-robin baseline | 1.0000 | " + " | ".join("1.0000" for _ in afams) +
          f" | {mean(m['rr']['max_wait'] for m in atab.values()):.1f} | {mean(m['rr']['memdep_wait_max'] for m in atab.values()):.1f} |")
        P("")
    # ------------------------------------------------------------------ dev
    if a.dev and os.path.exists(a.dev):
        _, dtab = load(a.dev)
        dv = [v for v in ("age", "aware", "aware_w0") if any(v in x for x in dtab.values())]
        P("## 8. Development seeds (not used for any claim; shown for transparency)\n")
        P("| metric | " + " | ".join(LABEL[v] for v in dv) + " |")
        P("|---|" + "---|" * len(dv))
        for key, label, _ in RATIO_METRICS:
            cells = []
            for v in dv:
                p, lo, hi = boot_ci(ratios(dtab, v, key))
                cells.append(f"{fmt(p, lo, hi)} {verdict(p, lo, hi)}")
            P(f"| {label} | " + " | ".join(cells) + " |")
        P("")

    # ------------------------------------------------------------------ hardware
    if a.hw and os.path.exists(a.hw):
        P(open(a.hw).read() if a.hw.endswith(".md") else "")
    open(a.out, "w").write("\n".join(out) + "\n")
    with open(os.path.splitext(a.out)[0] + "_tables.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["scope", "family", "variant", "metric", "point_or_mean", "ci_lo", "ci_hi", "verdict", "wins", "ties", "losses"])
        w.writerows(csv_rows)
    print(f"[report] wrote {a.out} ({len(out)} lines)")


if __name__ == "__main__":
    main()
