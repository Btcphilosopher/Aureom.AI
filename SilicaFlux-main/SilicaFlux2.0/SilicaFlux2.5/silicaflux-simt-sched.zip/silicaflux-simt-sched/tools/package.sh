#!/bin/bash
# Package the deliverable:  tools/package.sh [output.zip]
# Contains the RTL, testbenches, tools, tests, docs, results and the pristine baseline copy; excludes build products
# (build/<config>/ ... but KEEPS build/build_sim.sh and build/lint.sh), generated workloads (reproduce with `make workloads`)
# and Python caches.  A SHA-256 manifest of everything packaged is written into the archive as MANIFEST.sha256.
set -e
cd "$(dirname "$0")/.."
ROOT="$(pwd)"
NAME="$(basename "$ROOT")"
OUT="${1:-$ROOT/../$NAME.zip}"
case "$OUT" in /*) ;; *) OUT="$PWD/$OUT" ;; esac
( find . -type f \
    -not -path './workloads/*' -not -path '*/__pycache__/*' -not -name '*.pyc' -not -name 'MANIFEST.sha256' \
    -not \( -path './build/*' -not -path './build/build_sim.sh' -not -path './build/lint.sh' \) \
  | sort | sed 's|^\./||' | xargs sha256sum ) > MANIFEST.sha256
cd ..
rm -f "$OUT"
zip -r -q -X "$OUT" "$NAME" \
    -x "$NAME/build/*" "$NAME/workloads/*" "*/__pycache__/*" "*.pyc"
zip -q -X "$OUT" "$NAME/build/build_sim.sh" "$NAME/build/lint.sh"
echo "wrote $OUT ($(du -h "$OUT" | cut -f1), $(unzip -l "$OUT" | tail -1 | awk '{print $2}') files)"
