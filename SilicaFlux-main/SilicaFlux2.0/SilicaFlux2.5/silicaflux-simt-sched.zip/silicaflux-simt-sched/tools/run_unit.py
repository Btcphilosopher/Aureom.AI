#!/usr/bin/env python3
"""Unit-level tests: arbiters vs behavioural models, divergence unit vs Python vectors."""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
FLAGS = ["--binary", "--timing", "--assert", "-O2", "-Wno-fatal", "-Wno-TIMESCALEMOD", "-Wno-WIDTH",
         "-Wno-STMTDLY", "-Wno-INITIALDLY", "-Wno-DECLFILENAME", "-Wno-UNUSEDSIGNAL", "-Wno-UNUSEDPARAM",
         "-Wno-BLKSEQ", "-Wno-CASEINCOMPLETE", "-Wno-VARHIDDEN", "-Wno-PINCONNECTEMPTY", "-Wno-SYMRSVDWORD"]


def build(name, top, srcs, gflags):
    out = os.path.join(ROOT, "build", name)
    os.makedirs(out, exist_ok=True)
    cmd = ["verilator"] + FLAGS + ["--top-module", top, "-Mdir", out, "-o", "unit_tb", "-I" + os.path.join(ROOT, "rtl")] \
        + gflags + [os.path.join(ROOT, s) for s in srcs]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode != 0:
        print(p.stdout[-3000:])
        raise SystemExit(f"build of {name} failed")
    return os.path.join(out, "unit_tb")


def run(binary, args=()):
    p = subprocess.run([binary] + list(args), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=900)
    return p.returncode, p.stdout


def main():
    ok = True
    # ---- arbiters (class round-robin and age policy) ----
    for kind, (n, st) in [(0, (8, 16)), (0, (4, 4)), (0, (16, 32)), (0, (2, 2)),
                          (1, (8, 16)), (1, (4, 4)), (1, (16, 32)), (1, (8, 8)), (1, (2, 2))]:
        b = build(f"unit_arb_k{kind}_{n}_{st}", "tb_unit_arb",
                  ["rtl/sfx_rr_arb.sv", "rtl/sfx_class_rr_arb.sv", "rtl/sfx_age_arb.sv", "tb/tb_unit_arb.sv"],
                  [f"-GKIND={kind}", f"-GN={n}", f"-GSTARVE_LIMIT={st}"])
        rc, out = run(b)
        res = [l for l in out.splitlines() if "[ARB-UNIT]" in l]
        print(f"  arbiter {'class-RR' if kind == 0 else 'age     '} N={n:2d} STARVE_LIMIT={st:2d}: {'PASS' if rc == 0 else 'FAIL'}")
        for l in res[-3:-1] if rc == 0 else res[-4:]:
            print("     ", l)
        ok &= rc == 0
    # ---- policy-2 arbiter: model equivalence, bounds, ablation ----
    for n in (2, 4, 8, 16, 32):
        b = build(f"unit_aware_{n}", "tb_unit_aware", ["rtl/sfx_simt_pkg.sv", "rtl/sfx_aware_arb.sv", "tb/tb_unit_aware.sv"],
                  [f"-GN={n}"])
        rc, out = run(b)
        res = [l for l in out.splitlines() if "[AWARE-UNIT]" in l]
        print(f"  arbiter policy-2 N={n:2d}: {'PASS' if rc == 0 else 'FAIL'}")
        for l in (res[-4:-1] if rc == 0 else res[-6:]):
            print("     ", l)
        ok &= rc == 0
    # ---- divergence unit ----
    for (lanes, depth) in [(32, 8), (8, 4), (16, 6), (32, 2)]:
        vec = os.path.join(ROOT, "build", f"div_vec_{lanes}_{depth}.txt")
        subprocess.run([sys.executable, os.path.join(HERE, "gen_diverge_vectors.py"), vec, "--lanes", str(lanes),
                        "--depth", str(depth), "--n", "40000", "--seed", str(lanes * 10 + depth)],
                       check=True, stdout=subprocess.DEVNULL)
        b = build(f"unit_div_{lanes}_{depth}", "tb_unit_diverge", ["rtl/sfx_diverge_unit.sv", "tb/tb_unit_diverge.sv"],
                  [f"-GLANES={lanes}", f"-GSTACK_DEPTH={depth}"])
        rc, out = run(b, [f"+vec={vec}"])
        res = [l for l in out.splitlines() if "[DIV-UNIT]" in l]
        print(f"  diverge unit LANES={lanes:2d} DEPTH={depth}: {'PASS' if rc == 0 else 'FAIL'}")
        for l in res[-2:]:
            print("     ", l)
        ok &= rc == 0
    print("UNIT RESULT:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
