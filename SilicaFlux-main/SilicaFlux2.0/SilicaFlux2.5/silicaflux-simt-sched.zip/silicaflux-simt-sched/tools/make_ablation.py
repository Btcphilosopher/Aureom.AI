#!/usr/bin/env python3
"""Write results/ablation_variants.json: the tuned configuration with parts of it switched off (post-hoc analysis, see
results/REPORT.md section 7b).  Reads results/tuned_cfg.json.   make_ablation.py [--tuned F] [--out F]"""
import argparse
import json
import os

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tuned", default=os.path.join(ROOT, "results", "tuned_cfg.json"))
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "ablation_variants.json"))
    a = ap.parse_args()
    t = json.load(open(a.tuned))["aware_tuned"]

    def v(**kw):
        c = dict(t)
        c.update(kw)
        return c
    ab = {
        "abl_tuned":       dict(t),
        "abl_no_cap":      v(w_cap=0),
        "abl_no_barrier":  v(w_bar=0, w_rel=0),
        "abl_no_class":    v(w_cls_alu=0, w_cls_mem=0, w_cls_br=0, w_cls_ctrl=0),
        "abl_only_class":  dict(w_cls_alu=t["w_cls_alu"], w_cls_mem=t["w_cls_mem"], w_cls_br=t["w_cls_br"], w_cls_ctrl=t["w_cls_ctrl"],
                                w_ld=0, w_memdep=0, w_dep=0, w_bar=0, w_rel=0, w_cap=0, w_age=0),
        "abl_no_ld_dep":   v(w_ld=0, w_dep=0),
        "abl_no_age":      v(w_age=0),
        "abl_no_ctrl_cls": v(w_cls_ctrl=0),
        "abl_guards_off":  dict(t, fair_limit=0, cls_limit=0),
    }
    json.dump(ab, open(a.out, "w"), indent=1)
    print(f"wrote {a.out} ({len(ab)} variants)")


if __name__ == "__main__":
    main()
