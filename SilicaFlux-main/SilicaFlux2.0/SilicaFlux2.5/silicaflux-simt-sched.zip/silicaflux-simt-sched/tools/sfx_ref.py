#!/usr/bin/env python3
"""Reference simulators for the SFX-SIMT architecture.

Two independent models:

  OracleSim  - per-thread sequential semantics.  Every thread runs on its own
               with no notion of warps, masks or reconvergence.  Threads of a
               workgroup synchronise only at BAR (released when every live
               thread is waiting).  This is the *semantic ground truth* for
               legal, race-free programs.

  SimtSim    - warp-level model that implements the architectural divergence
               model *exactly* as specified in docs/divergence_model.md
               (reconvergence stack with merge optimisation, empty-path
               elision, overflow fault, convergent BAR/EXIT rules).  It is
               the bit-exact reference for the RTL: per-warp (pc, mask)
               issue traces, final registers, memory, fault records.

For every legal program  OracleSim state == SimtSim state  (checked by fuzzing
in tools/fuzz_models.py), and RTL state == SimtSim state (checked by
tools/sfx_run.py).  Neither model has any notion of time.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from sfx_isa import (decode, sext, M32, CLS_ALU, CLS_MEM, CLS_BR, CLS_CTRL,
                     FAULT_NONE, FAULT_DIV_BARRIER, FAULT_DIV_EXIT, FAULT_STACK_OVF,
                     FAULT_ILLEGAL, FAULT_FETCH, FAULT_PC_RANGE, FAULT_BAR_PC,
                     FAULT_LAUNCH, FAULT_NAMES)


@dataclass
class Cfg:
    lanes: int = 32
    pc_w: int = 16
    stack_depth: int = 8
    gmem_words: int = 1 << 14
    smem_words: int = 256
    max_warps: int = 8              # NUM_WARPS of the RTL (launch size check)
    strict_bar_pc: bool = False
    max_steps: int = 2_000_000      # runaway guard (illegal programs)

    @property
    def pc_max(self) -> int:
        return (1 << self.pc_w)


@dataclass
class Result:
    regs: Dict[Tuple[int, int], List[int]] = field(default_factory=dict)   # (wg, tid) -> r[0..31]
    gmem: List[int] = field(default_factory=list)
    trace: Dict[Tuple[int, int], List[Tuple[int, int]]] = field(default_factory=dict)
    faults: List[Tuple[int, int, int, int]] = field(default_factory=list)  # (wg, widx, code, pc)
    issued: int = 0
    max_sp: Dict[Tuple[int, int], int] = field(default_factory=dict)
    barrier_episodes: int = 0
    div_branches: int = 0
    aborted_wgs: List[int] = field(default_factory=list)


class SimError(Exception):
    pass


# ---------------------------------------------------------------------------
# Instruction semantics shared by both models (one lane)
# ---------------------------------------------------------------------------
def alu_exec(i, regs: List[int], tid: int, wg_id: int) -> Optional[int]:
    """Return the value written to rd (for ALU-class instructions)."""
    n = i.name
    r = regs
    if n == "add":
        return (r[i.b] + r[i.c]) & M32
    if n == "sub":
        return (r[i.b] - r[i.c]) & M32
    if n == "and":
        return r[i.b] & r[i.c]
    if n == "or":
        return r[i.b] | r[i.c]
    if n == "xor":
        return r[i.b] ^ r[i.c]
    if n == "shl":
        return (r[i.b] << (r[i.c] & 31)) & M32
    if n == "shr":
        return (r[i.b] & M32) >> (r[i.c] & 31)
    if n == "slt":
        return 1 if sext(r[i.b], 32) < sext(r[i.c], 32) else 0
    if n == "mul":
        return (r[i.b] * r[i.c]) & M32
    if n == "addi":
        return (r[i.b] + i.simm11) & M32
    if n == "andi":
        return r[i.b] & i.imm11
    if n == "movi":
        return sext(i.imm16, 16) & M32
    if n == "tid":
        return tid & M32
    if n == "wgid":
        return wg_id & M32
    raise SimError(f"alu_exec: {n}")


def mem_addr(i, regs: List[int], words: int) -> int:
    return ((regs[i.b] + i.simm11) & M32) & (words - 1)


# ---------------------------------------------------------------------------
# Branch resolution: the architectural divergence function (also used to
# generate unit-test vectors for rtl/sfx_diverge_unit.sv)
# ---------------------------------------------------------------------------
def resolve_branch(b: int, tgt_off: int, rpc_off: int, amask: int, taken_raw: int,
                   sp: int, cur_rpc: int, depth: int, pc_w: int) -> dict:
    """Resolve a conditional branch at pc `b` with active mask `amask`.

    Returns a dict:
      fault : FAULT_NONE | FAULT_PC_RANGE | FAULT_STACK_OVF
      pop   : context finished -> pop one stack entry (new ctx comes from stack)
      pc,mask,rpc : new current context (valid when fault==0 and pop==0)
      sp    : stack depth afterwards
      push0, push1 : (pc, mask, rpc) or None; push0 is written at index `sp`,
                     push1 at index `sp+1`
      kind  : 'uniform_taken' | 'uniform_nt' | 'both_empty' | 'diverge'
    """
    lim = 1 << pc_w
    F = b + 1
    T = b + 1 + tgt_off
    R = b + 1 + rpc_off
    out = dict(fault=FAULT_NONE, pop=False, pc=None, mask=None, rpc=cur_rpc, sp=sp,
               push0=None, push1=None, kind="")
    if not (0 <= F < lim and 0 <= T < lim and 0 <= R < lim):
        out["fault"] = FAULT_PC_RANGE
        return out
    mt = taken_raw & amask
    mn = amask & ~mt
    full = amask

    def advance(npc):
        if sp != 0 and npc == cur_rpc:
            out["pop"] = True
            out["sp"] = sp - 1
        else:
            out["pc"] = npc
            out["mask"] = full
        return out

    if mn == 0:
        out["kind"] = "uniform_taken"
        return advance(T)
    if mt == 0:
        out["kind"] = "uniform_nt"
        return advance(F)
    t_empty = (T == R)
    f_empty = (F == R)
    if t_empty and f_empty:
        out["kind"] = "both_empty"
        return advance(R)
    out["kind"] = "diverge"
    join = not (sp != 0 and R == cur_rpc)         # merge optimisation
    both = (not t_empty) and (not f_empty)
    n = (1 if join else 0) + (1 if both else 0)
    if sp + n > depth:
        out["fault"] = FAULT_STACK_OVF
        return out
    pushes = []
    if join:
        pushes.append((R, amask, cur_rpc))
    if both:
        pushes.append((F, mn, R))
    out["push0"] = pushes[0] if len(pushes) > 0 else None
    out["push1"] = pushes[1] if len(pushes) > 1 else None
    out["sp"] = sp + n
    if not t_empty:
        out["pc"], out["mask"] = T, mt
    else:
        out["pc"], out["mask"] = F, mn
    out["rpc"] = R
    return out


# ---------------------------------------------------------------------------
# Oracle: independent per-thread execution
# ---------------------------------------------------------------------------
class OracleSim:
    def __init__(self, prog: List[int], cfg: Cfg, init_mem: Optional[List[int]] = None):
        self.cfg = cfg
        self.prog = prog
        self.dec = [decode(w) for w in prog]
        self.gmem = list(init_mem) if init_mem else [0] * cfg.gmem_words
        if len(self.gmem) < cfg.gmem_words:
            self.gmem += [0] * (cfg.gmem_words - len(self.gmem))

    def run(self, nthreads: int, nwgs: int) -> Result:
        res = Result()
        for wg in range(nwgs):
            self._run_wg(wg, nthreads, res)
        res.gmem = self.gmem
        return res

    def _run_wg(self, wg: int, nthreads: int, res: Result) -> None:
        cfg = self.cfg
        smem = [0] * cfg.smem_words
        regs = [[0] * 32 for _ in range(nthreads)]
        pc = [0] * nthreads
        state = ["run"] * nthreads          # run | bar | done
        steps = 0
        while True:
            progressed = False
            for t in range(nthreads):
                while state[t] == "run":
                    steps += 1
                    if steps > cfg.max_steps:
                        raise SimError("oracle: step limit exceeded")
                    p = pc[t]
                    if not (0 <= p < len(self.dec)):
                        raise SimError(f"oracle: thread {t} fetch outside program pc={p}")
                    i = self.dec[p]
                    if not i.legal:
                        raise SimError("oracle: illegal instruction")
                    n = i.name
                    r = regs[t]
                    progressed = True
                    if i.cls == CLS_ALU:
                        v = alu_exec(i, r, t, wg)
                        if i.a != 0:
                            r[i.a] = v
                        pc[t] = p + 1
                    elif n == "ld":
                        v = self.gmem[mem_addr(i, r, cfg.gmem_words)]
                        if i.a != 0:
                            r[i.a] = v
                        pc[t] = p + 1
                    elif n == "lds":
                        v = smem[mem_addr(i, r, cfg.smem_words)]
                        if i.a != 0:
                            r[i.a] = v
                        pc[t] = p + 1
                    elif n == "st":
                        self.gmem[mem_addr(i, r, cfg.gmem_words)] = r[i.c]
                        pc[t] = p + 1
                    elif n == "sts":
                        smem[mem_addr(i, r, cfg.smem_words)] = r[i.c]
                        pc[t] = p + 1
                    elif n == "bra":
                        pc[t] = p + 1 + i.tgt_off if r[i.a] != 0 else p + 1
                    elif n == "brz":
                        pc[t] = p + 1 + i.tgt_off if r[i.a] == 0 else p + 1
                    elif n == "jmp":
                        pc[t] = p + 1 + i.tgt_off
                    elif n == "nop":
                        pc[t] = p + 1
                    elif n == "bar":
                        pc[t] = p + 1
                        state[t] = "bar"
                    elif n == "exit":
                        state[t] = "done"
                    else:
                        raise SimError(f"oracle: unhandled {n}")
            live = [t for t in range(nthreads) if state[t] != "done"]
            if not live:
                break
            if all(state[t] == "bar" for t in live):
                for t in live:
                    state[t] = "run"
                res.barrier_episodes += 1
                continue
            if not progressed:
                raise SimError("oracle: deadlock")
        for t in range(nthreads):
            res.regs[(wg, t)] = list(regs[t])


# ---------------------------------------------------------------------------
# Warp-level SIMT model: the bit-exact architectural reference
# ---------------------------------------------------------------------------
class Warp:
    def __init__(self, wg: int, widx: int, lmask: int, lanes: int):
        self.wg, self.widx, self.lmask = wg, widx, lmask
        self.lanes = lanes
        self.pc = 0
        self.mask = lmask
        self.rpc = 0
        self.stack: List[Tuple[int, int, int]] = []
        self.regs = [[0] * 32 for _ in range(lanes)]
        self.state = "run"                # run | bar | done | dead
        self.trace: List[Tuple[int, int]] = []
        self.max_sp = 0


class SimtSim:
    def __init__(self, prog: List[int], cfg: Cfg, init_mem: Optional[List[int]] = None):
        self.cfg = cfg
        self.prog = prog
        self.dec = [decode(w) for w in prog]
        self.gmem = list(init_mem) if init_mem else [0] * cfg.gmem_words
        if len(self.gmem) < cfg.gmem_words:
            self.gmem += [0] * (cfg.gmem_words - len(self.gmem))

    # -- launch ---------------------------------------------------------
    def run(self, nthreads: int, nwgs: int, entry: int = 0) -> Result:
        res = Result()
        cfg = self.cfg
        for wg in range(nwgs):
            if nthreads < 1 or nthreads > cfg.max_warps * cfg.lanes:
                res.faults.append((wg, 0, FAULT_LAUNCH, entry))
                res.aborted_wgs.append(wg)
                continue
            self._run_wg(wg, nthreads, entry, res)
        res.gmem = self.gmem
        return res

    def _run_wg(self, wg: int, nthreads: int, entry: int, res: Result) -> None:
        cfg = self.cfg
        lanes = cfg.lanes
        nw = (nthreads + lanes - 1) // lanes
        warps: List[Warp] = []
        for k in range(nw):
            cnt = lanes if k < nw - 1 else nthreads - (nw - 1) * lanes
            w = Warp(wg, k, (1 << cnt) - 1, lanes)
            w.pc = entry
            warps.append(w)
        smem = [0] * cfg.smem_words
        arrived: set = set()
        self._bar_pc: Optional[int] = None
        steps = 0
        rr = 0
        fault = None
        while True:
            live = [w for w in warps if w.state in ("run", "bar")]
            if not live:
                break
            runnable = [w for w in live if w.state == "run"]
            if not runnable:
                raise SimError("simt: deadlock (all live warps at barrier but not released)")
            # round-robin pick (the order is irrelevant for race-free programs)
            runnable.sort(key=lambda w: (w.widx - rr) % nw)
            w = runnable[0]
            rr = (w.widx + 1) % nw
            steps += 1
            if steps > cfg.max_steps:
                raise SimError("simt: step limit exceeded")
            f = self._step(w, wg, smem, res, arrived)
            if f is not None:
                fault = (wg, w.widx, f[0], f[1])
                break
            live = [x for x in warps if x.state in ("run", "bar")]
            if live and all(x.state == "bar" for x in live):
                for x in live:
                    x.state = "run"
                res.barrier_episodes += 1
                self._bar_pc = None
        for w in warps:
            res.trace[(wg, w.widx)] = w.trace
            res.max_sp[(wg, w.widx)] = w.max_sp
            res.issued += len(w.trace)
        if fault:
            res.faults.append(fault)
            res.aborted_wgs.append(wg)
        else:
            for w in warps:
                for lane in range(bin(w.lmask).count("1")):
                    res.regs[(wg, w.widx * lanes + lane)] = list(w.regs[lane])

    # -- one warp instruction --------------------------------------------
    def _step(self, w: Warp, wg: int, smem: List[int], res: Result, arrived: set):
        """Execute one instruction.  Returns None or (fault_code, fault_pc)."""
        cfg = self.cfg
        pc = w.pc
        if not (0 <= pc < len(self.dec)):
            return (FAULT_FETCH, pc)
        i = self.dec[pc]
        if not i.legal:
            return (FAULT_ILLEGAL, pc)
        n = i.name
        m = w.mask
        lanes_list = [l for l in range(w.lanes) if (m >> l) & 1]
        lim = cfg.pc_max

        def advance(npc: int) -> None:
            if w.stack and npc == w.rpc:
                w.pc, w.mask, w.rpc = w.stack.pop()
            else:
                w.pc = npc

        cls = i.cls
        if cls == CLS_ALU or cls == CLS_MEM or n in ("nop", "jmp"):
            npc = pc + 1 + i.tgt_off if n == "jmp" else pc + 1
            if not (0 <= npc < lim):
                return (FAULT_PC_RANGE, pc)
            for l in lanes_list:
                r = w.regs[l]
                tid = w.widx * w.lanes + l
                if cls == CLS_ALU:
                    v = alu_exec(i, r, tid, wg)
                    if i.a != 0:
                        r[i.a] = v
                elif n == "ld":
                    v = self.gmem[mem_addr(i, r, cfg.gmem_words)]
                    if i.a != 0:
                        r[i.a] = v
                elif n == "lds":
                    v = smem[mem_addr(i, r, cfg.smem_words)]
                    if i.a != 0:
                        r[i.a] = v
            if n == "st":
                for l in lanes_list:
                    self.gmem[mem_addr(i, w.regs[l], cfg.gmem_words)] = w.regs[l][i.c]
            elif n == "sts":
                for l in lanes_list:
                    smem[mem_addr(i, w.regs[l], cfg.smem_words)] = w.regs[l][i.c]
            w.trace.append((pc, m))
            advance(npc)
            return None
        if cls == CLS_BR:
            taken = 0
            for l in lanes_list:
                v = w.regs[l][i.a]
                if (n == "bra" and v != 0) or (n == "brz" and v == 0):
                    taken |= 1 << l
            sp = len(w.stack)
            o = resolve_branch(pc, i.tgt_off, i.rpc_off, m, taken, sp, w.rpc,
                               cfg.stack_depth, cfg.pc_w)
            w.trace.append((pc, m))             # BRA itself issued & retired
            if o["fault"] != FAULT_NONE:
                return (o["fault"], pc)
            if o["kind"] == "diverge":
                res.div_branches += 1
                if o["push0"] is not None:
                    w.stack.append(o["push0"])
                if o["push1"] is not None:
                    w.stack.append(o["push1"])
                w.pc, w.mask = o["pc"], o["mask"]
                w.rpc = o["rpc"]
                w.max_sp = max(w.max_sp, len(w.stack))
            elif o["pop"]:
                w.pc, w.mask, w.rpc = w.stack.pop()
            else:
                w.pc = o["pc"]
            return None
        if n == "bar":
            if w.stack:
                return (FAULT_DIV_BARRIER, pc)
            if not (0 <= pc + 1 < lim):
                return (FAULT_PC_RANGE, pc)
            if cfg.strict_bar_pc:
                if self._bar_pc is not None and self._bar_pc != pc:
                    return (FAULT_BAR_PC, pc)
                self._bar_pc = pc
            w.trace.append((pc, m))
            w.pc = pc + 1
            w.state = "bar"
            return None
        if n == "exit":
            if w.stack:
                return (FAULT_DIV_EXIT, pc)
            w.trace.append((pc, m))
            w.state = "done"
            return None
        raise SimError(f"unhandled {n}")


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------
def compare_results(a: Result, b: Result, mem_a=None, mem_b=None) -> List[str]:
    """Compare architectural state (registers + memory) of two results."""
    errs: List[str] = []
    ka, kb = set(a.regs), set(b.regs)
    if ka != kb:
        errs.append(f"thread sets differ: only-a={sorted(ka - kb)[:4]} only-b={sorted(kb - ka)[:4]}")
    for k in sorted(ka & kb):
        if a.regs[k] != b.regs[k]:
            for r in range(32):
                if a.regs[k][r] != b.regs[k][r]:
                    errs.append(f"wg{k[0]} tid{k[1]} r{r}: {a.regs[k][r]:#x} != {b.regs[k][r]:#x}")
                    break
            if len(errs) > 8:
                return errs
    if a.gmem != b.gmem:
        diff = [i for i in range(min(len(a.gmem), len(b.gmem))) if a.gmem[i] != b.gmem[i]]
        errs.append(f"gmem differs at {len(diff)} words, first {diff[:4]}")
    return errs
