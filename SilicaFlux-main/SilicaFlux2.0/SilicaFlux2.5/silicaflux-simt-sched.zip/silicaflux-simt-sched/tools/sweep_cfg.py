#!/usr/bin/env python3
"""Coordinate-descent search of the policy-2 weights on the DEVELOPMENT seeds only.

Objective: geometric mean, over all development workload instances x geometries, of
    cycles(policy 2 with this configuration) / cycles(round-robin)          (lower is better)
The held-out TEST seeds are never touched here: the tuned configuration is evaluated on them
afterwards by compare_policies.py --variants-file results/tuned_cfg.json, so a reported gain is
not the result of tuning on the evaluation data.

    sweep_cfg.py --baseline results/raw_dev.json --passes 2 --out results/sweep_dev.json
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import math
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import compare_policies as cp
from sfx_run import ROOT

FIELDS = ["w_cls_alu", "w_cls_mem", "w_cls_br", "w_cls_ctrl", "w_ld", "w_memdep", "w_dep", "w_bar", "w_rel", "w_cap", "w_age"]
VALUES = [0, 1, 2, 3, 4, 5, 7]
DEFAULT = dict(w_cls_alu=0, w_cls_mem=1, w_cls_br=2, w_cls_ctrl=1, w_ld=2, w_memdep=2, w_dep=0, w_bar=1, w_rel=7, w_cap=1, w_age=1)


def evaluate(ex, dirs, geoms, cfg, base, metric):
    vd = (2, [f"+sc_{k}={v}" for k, v in cfg.items()])
    jobs = [dict(dir=d, geom=g, variant="sweep", variant_def=vd) for d in dirs for g in geoms]
    ratios, per_fam = [], {}
    for rec in ex.map(cp.run_one, jobs):
        if "error" in rec:
            raise SystemExit(f"sweep run failed: {rec['workload']} {rec['geom']}: {rec['error']}")
        b = base[(rec["workload"], rec["geom"])]
        r = rec["metrics"][metric] / b
        ratios.append(r)
        per_fam.setdefault(rec["family"], []).append(r)
    gm = math.exp(sum(math.log(x) for x in ratios) / len(ratios))
    return gm, {f: math.exp(sum(math.log(x) for x in v) / len(v)) for f, v in per_fam.items()}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--baseline", required=True, help="raw JSON of a development-set run containing the 'rr' variant")
    ap.add_argument("--workloads", default=os.path.join(ROOT, "workloads"))
    ap.add_argument("--geoms", default="g8,g16")
    ap.add_argument("--metric", default="cycles")
    ap.add_argument("--passes", type=int, default=2)
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "sweep_dev.json"))
    ap.add_argument("--tuned-out", default=os.path.join(ROOT, "results", "tuned_cfg.json"))
    a = ap.parse_args()

    geoms = a.geoms.split(",")
    dirs = cp.collect_dirs(a.workloads, cp.DEV_SEEDS, None)
    base = {(r["workload"], r["geom"]): r["metrics"][a.metric] for r in json.load(open(a.baseline)) if r["variant"] == "rr"}
    for g in geoms:
        cp.cfg_for(g, 2).build()
    os.environ["SFX_FROZEN_BUILD"] = "1"          # worker processes must not rebuild
    cur = dict(DEFAULT)
    log = []
    t0 = time.time()
    with cf.ProcessPoolExecutor(max_workers=a.jobs) as ex:
        best, fam = evaluate(ex, dirs, geoms, cur, base, a.metric)
        log.append(dict(cfg=dict(cur), score=best, note="default (a-priori) configuration"))
        print(f"default configuration: dev geomean({a.metric} ratio vs RR) = {best:.4f}")
        for p in range(a.passes):
            improved = False
            for f in FIELDS:
                for v in VALUES:
                    if v == cur[f]:
                        continue
                    cand = dict(cur); cand[f] = v
                    s, fam_c = evaluate(ex, dirs, geoms, cand, base, a.metric)
                    log.append(dict(cfg=cand, score=s))
                    if s < best - 1e-5:
                        best, cur, fam, improved = s, cand, fam_c, True
                        print(f"  pass {p + 1}: {f}={v} -> {best:.4f}  ({time.time() - t0:.0f}s)")
            if not improved:
                break
    print(f"tuned configuration: dev geomean ratio {best:.4f}  {cur}")
    json.dump(dict(default=DEFAULT, tuned=cur, dev_score_default=log[0]["score"], dev_score_tuned=best,
                   per_family_dev=fam, metric=a.metric, evaluations=len(log), trajectory=log),
              open(a.out, "w"), indent=1)
    json.dump({"aware_tuned": cur}, open(a.tuned_out, "w"), indent=1)


if __name__ == "__main__":
    main()
