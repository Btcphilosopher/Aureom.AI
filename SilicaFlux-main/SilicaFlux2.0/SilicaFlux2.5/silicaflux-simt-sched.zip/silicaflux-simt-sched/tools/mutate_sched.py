#!/usr/bin/env python3
"""Mutation testing of the policy-2 logic: does the verification environment notice a broken scheduler?

Each mutant is a single, small, plausible design error applied to a COPY of the RTL (the real RTL is never
touched).  A mutant is KILLED if the relevant test environment fails, SURVIVES otherwise.

  unit   mutants (rtl/sfx_aware_arb.sv)   killed by  tb/tb_unit_aware.sv  (exact grant model, bounds, ablation)
  system mutants (rtl/sfx_simt_ctrl.sv)   killed by  the whole directed suite on a policy-2 build, i.e. the
                                          in-RTL assertions + tb/sfx_sched_monitor.sv (M1-M9) + the reference model
                                          + the configuration-effect test (tests/directed.py: cfg_effect_test)

Survivors are listed with an explanation; they are NOT hidden.

    mutate_sched.py [--only U3,S2] [--jobs 3]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import os
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "tests"))
from sfx_run import RtlConfig, ROOT, run_case
from sfx_isa import assemble
from sfx_gen import make_init_mem
import directed

ARB = "sfx_aware_arb.sv"
CTRL = "sfx_simt_ctrl.sv"
M = [
    # ---- unit-level: the arbiter itself ----------------------------------------------------------------------
    ("U1",  ARB, "(wcnt[i] >= WCW'(cfg.fair_limit))", "(wcnt[i] > WCW'(cfg.fair_limit))", "urgency threshold off by one"),
    ("U2",  ARB, "begin tier = 2'd3; prim = wcnt[i]; end", "begin tier = 2'd1; prim = wcnt[i]; end", "warp-urgent candidates get no priority (guard ineffective)"),
    ("U3",  ARB, "curg[i] = req[i] && (cfg.cls_limit  != 4'd0) && (cb[cls[i]] >= cfg.cls_limit);", "curg[i] = 1'b0;", "class guard removed"),
    ("U4",  ARB, "ptr <= PW'(int'(widx) + 1);", "ptr <= widx;", "tie-break pointer does not move past the granted warp"),
    ("U5",  ARB, "if (cls_gr[c])                              cb[c] <= '0;", "if (1'b0)                              cb[c] <= '0;", "class bypass counter never reset"),
    ("U6",  ARB, "if (alloc[i] || grant[i]) begin\n          md[i] <= 1'b0;", "if (alloc[i]) begin\n          md[i] <= 1'b0;", "sticky memory-wait flag not cleared on issue"),
    ("U7",  ARB, "      s_tmp = s_tmp + 10'(cap[cls[i]]) * 10'(cfg.w_cap);\n", "", "headroom term ignored"),
    ("U8",  ARB, "tk[p + span] > tk[p]", "tk[p + span] >= tk[p]", "tournament breaks ties towards the wrong child (rotation lost)"),
    ("U9",  ARB, "(wcnt[i] > WCW'(3)) ? 2'd3 : wcnt[i][1:0]", "(wcnt[i] > WCW'(3)) ? 2'd2 : wcnt[i][1:0]", "aging term clamps at 2 instead of 3"),
    ("U10", ARB, "if (!wait_en[i] || grant[i] || alloc[i])       wcnt[i] <= '0;", "if (!wait_en[i] || alloc[i])       wcnt[i] <= '0;", "lost-grant counter not cleared when the warp issues"),
    ("U11", ARB, "else if (fire && req[i] && wcnt[i] != {WCW{1'b1}}) wcnt[i] <= wcnt[i] + 1'b1;", "else if (fire && wcnt[i] != {WCW{1'b1}}) wcnt[i] <= wcnt[i] + 1'b1;", "lost-grant counter also counts cycles in which the warp was not a candidate"),
    ("U12", ARB, "ridx  = PW'(int'(ptr) + p);", "ridx  = PW'(p);", "rotating priority replaced by fixed priority"),
    ("U13", ARB, "if (stall_mem[i]) md[i] <= 1'b1;", "if (stall_dep[i]) md[i] <= 1'b1;", "memory-wait flag set by register stalls"),
    ("U14", ARB, "tv[p] = req[ridx];", "tv[p] = 1'b1;", "arbiter ignores the legality gate (grants non-candidates)"),
    ("U15", ARB, "begin tier = 2'd3; prim = wcnt[i]; end", "begin tier = 2'd3; prim = '0; end", "urgent warps no longer ordered by waiting time"),
    ("U16", ARB, "      if (bar_rel[i]) s_tmp = s_tmp + {7'd0, cfg.w_rel};\n", "", "barrier-release bonus ignored"),
    # ---- system-level: controller features and wiring ---------------------------------------------------------
    ("S1",  CTRL, "w_bar_press[w]  = (np > 3) ? 2'd3 : 2'(np);", "w_bar_press[w]  = (np > 2) ? 2'd2 : 2'(np);", "barrier-pressure saturates at 2"),
    ("S2",  CTRL, "((dec[w].op == OP_BAR)  && ((bar_arrived[g] | me) == bar_live[g]))", "((dec[w].op == OP_BAR)  && (bar_arrived[g] == bar_live[g]))", "'releases the barrier' ignores the issuing warp itself"),
    ("S3",  CTRL, "((dec[w].op == OP_EXIT) && (bar_arrived[g] != '0) && (bar_arrived[g] == (bar_live[g] & ~me)))", "((dec[w].op == OP_EXIT) && (bar_arrived[g] == (bar_live[g] & ~me)))", "EXIT of the only remaining warp flagged as releasing"),
    ("S4",  CTRL, "w_stall_mem[w]  = w_ready[w] && (hazard[w] ? hazard_mem[w] :", "w_stall_mem[w]  = w_ready[w] && (hazard[w] ? !hazard_mem[w] :", "memory/register stall classification inverted"),
    ("S5",  CTRL, "w_is_ld[w]      = dec[w].is_ld;", "w_is_ld[w]      = dec[w].is_mem;", "stores flagged as loads"),
    ("S6",  CTRL, "cls_cap[1] = be_cap[1];", "cls_cap[1] = be_cap[0];", "memory-class headroom taken from the ALU class"),
    ("S7",  CTRL, "w_stall_dep[w]  = w_ready[w] && (hazard[w] ? !hazard_mem[w] : (w_drain_blk[w] && (wmem[w] == '0)));", "w_stall_dep[w]  = w_ready[w] && (hazard[w] ? !hazard_mem[w] : (w_drain_blk[w] && (wmem[w] != '0)));", "BAR/EXIT drain stall attributed to the wrong cause"),
    ("S8",  CTRL, ".cfg(sched_cfg), .is_ld(w_is_ld)", ".cfg(sfx_sched_cfg_default(NUM_WARPS)), .is_ld(w_is_ld)", "configuration port ignored (defaults always used)"),
]


class MutConfig(RtlConfig):
    def __init__(self, name, rtl_dir, **kw):
        super().__init__(name, **kw)
        self.rtl_dir = rtl_dir

    def build(self, force=False):
        env = dict(os.environ, SFX_RTL_DIR=self.rtl_dir)
        subprocess.run([os.path.join(ROOT, "build", "build_sim.sh"), self.name] + self.gflags(), check=True, env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        return self.binary()


def make_copy(mid, fname, old, new):
    d = os.path.join(ROOT, "build", f"mut_{mid}", "rtl")
    if os.path.exists(d):
        shutil.rmtree(d)
    shutil.copytree(os.path.join(ROOT, "rtl"), d)
    p = os.path.join(d, fname)
    s = open(p).read()
    if s.count(old) != 1:
        raise SystemExit(f"mutant {mid}: pattern occurs {s.count(old)} times in {fname} (must be exactly 1) - mutation table is stale")
    open(p, "w").write(s.replace(old, new))
    return d


def kill_unit(mid, d):
    out = os.path.join(ROOT, "build", f"mut_{mid}", "unit")
    os.makedirs(out, exist_ok=True)
    flags = ["--binary", "--timing", "--assert", "-O2", "-Wno-fatal", "-Wno-TIMESCALEMOD", "-Wno-WIDTH", "-Wno-STMTDLY",
             "-Wno-INITIALDLY", "-Wno-DECLFILENAME", "-Wno-UNUSEDSIGNAL", "-Wno-UNUSEDPARAM", "-Wno-BLKSEQ", "-Wno-CASEINCOMPLETE",
             "-Wno-VARHIDDEN", "-Wno-PINCONNECTEMPTY", "-Wno-SYMRSVDWORD"]
    cmd = ["verilator"] + flags + ["--top-module", "tb_unit_aware", "-Mdir", out, "-o", "unit_tb", "-I" + d, "-GN=8", "-GCYCLES=120000",
                                  os.path.join(d, "sfx_simt_pkg.sv"), os.path.join(d, ARB), os.path.join(ROOT, "tb", "tb_unit_aware.sv")]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode != 0:
        return "BUILD-ERROR", p.stdout[-300:]
    r = subprocess.run([os.path.join(out, "unit_tb")], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=600)
    if r.returncode != 0:
        first = next((l for l in r.stdout.splitlines() if "FAIL" in l or "Assertion" in l), r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "")
        return "KILLED", first[:160]
    return "SURVIVED", ""


def kill_system(mid, d):
    cfg = MutConfig(f"mut_{mid}", d, sched_policy=2)
    try:
        cfg.build()
    except subprocess.CalledProcessError as e:
        return "BUILD-ERROR", e.stdout.decode()[-300:] if e.stdout else ""
    mem = make_init_mem(1234)
    for t in directed.all_tests():
        if not ({"age32", "rr32"} & set(t.cfgs)):
            continue
        lanes = cfg.warp_size
        prog = assemble(directed._asm(t, lanes)).words
        nth = directed._nth(t, lanes, cfg.num_warps)
        for prof in t.profiles:
            errs, rtl, ref = run_case(cfg, prog, mem, nth, t.nwgs, prof, 11 + prof, t.launch_gap, t.reps,
                                      fault_exact_warp=t.fault_exact_warp, check_counters=t.check_counters,
                                      extra_args=t.extra_args, allow_proto=t.allow_proto)
            if errs:
                return "KILLED", f"{t.name} profile {prof}: {errs[0][:140]}"
    errs = directed.cfg_effect_test(cfg)
    if errs:
        return "KILLED", errs[0][:160]
    return "SURVIVED", ""


def run_mutant(m):
    mid, fname, old, new, desc = m
    d = make_copy(mid, fname, old, new)
    kind = "unit" if mid.startswith("U") else "system"
    t0 = time.time()
    res, why = (kill_unit if kind == "unit" else kill_system)(mid, d)
    return mid, kind, desc, res, why, time.time() - t0


def validate():
    """every mutation pattern must occur exactly once in its file (otherwise the table is stale)"""
    bad = []
    for mid, fname, old, new, desc in M:
        n = open(os.path.join(ROOT, "rtl", fname)).read().count(old)
        if n != 1:
            bad.append(f"{mid} ({fname}): pattern occurs {n} times")
    return bad


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--check", action="store_true", help="only validate the mutation table against the RTL")
    ap.add_argument("--only", default="")
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "mutation_policy2.log"))
    a = ap.parse_args()
    bad = validate()
    if bad:
        raise SystemExit("mutation table is stale:\n  " + "\n  ".join(bad))
    if a.check:
        print(f"mutation table OK: {len(M)} mutants, every pattern matches exactly once")
        return
    sel = [m for m in M if not a.only or m[0] in a.only.split(",")]
    lines = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for mid, kind, desc, res, why, dt in ex.map(run_mutant, sel):
            line = f"{mid:4s} [{kind:6s}] {res:9s} {desc}" + (f"\n         by: {why}" if why else "")
            print(line + f"   ({dt:.0f}s)")
            lines.append(line)
    killed = sum(1 for l in lines if " KILLED " in l)
    surv = [l.split()[0] for l in lines if " SURVIVED " in l]
    err = [l.split()[0] for l in lines if "BUILD-ERROR" in l]
    summary = f"mutants: {len(lines)}  killed: {killed}  survived: {len(surv)} {surv}  build-errors: {len(err)} {err}"
    print(summary)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    open(a.out, "w").write("\n".join(lines) + "\n" + summary + "\n")


if __name__ == "__main__":
    main()
