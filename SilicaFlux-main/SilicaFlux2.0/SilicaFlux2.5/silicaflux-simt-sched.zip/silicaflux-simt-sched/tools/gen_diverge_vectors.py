#!/usr/bin/env python3
"""Generate test vectors for tb/tb_unit_diverge.sv from the Python reference
`resolve_branch` (the architectural definition of branch resolution).

usage: gen_diverge_vectors.py OUT.txt [--lanes 32] [--depth 8] [--pcw 16] [--n 30000] [--seed 1]
"""
import argparse
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sfx_ref import resolve_branch
from sfx_isa import FAULT_PC_RANGE, FAULT_STACK_OVF


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--lanes", type=int, default=32)
    ap.add_argument("--depth", type=int, default=8)
    ap.add_argument("--pcw", type=int, default=16)
    ap.add_argument("--n", type=int, default=30000)
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    rng = random.Random(a.seed)
    full = (1 << a.lanes) - 1
    lim = 1 << a.pcw

    def rmask():
        k = rng.random()
        if k < 0.15:
            return full
        if k < 0.30:
            return 1 << rng.randrange(a.lanes)
        if k < 0.40:
            return rng.getrandbits(a.lanes) & rng.getrandbits(a.lanes) & rng.getrandbits(a.lanes)
        return rng.getrandbits(a.lanes)

    lines = 0
    with open(a.out, "w") as f:
        for _ in range(a.n):
            # pc: mostly small, sometimes at the range limits
            k = rng.random()
            if k < 0.7:
                pc = rng.randrange(0, 200)
            elif k < 0.85:
                pc = rng.randrange(lim - 1100, lim)
            else:
                pc = rng.randrange(0, lim)
            tgt_off = rng.choice([rng.randrange(-1024, 1024), rng.randrange(-8, 8), -1024, 1023, 0, -1])
            rpc_off = rng.choice([rng.randrange(0, 1024), rng.randrange(0, 12), 0, 1023])
            amask = rmask()
            if amask == 0:
                amask = 1
            # taken: sometimes uniform, sometimes subset
            k = rng.random()
            if k < 0.15:
                taken = amask
            elif k < 0.30:
                taken = 0
            elif k < 0.40:
                taken = rng.getrandbits(a.lanes) & ~amask       # taken lanes outside the active mask
            else:
                taken = rng.getrandbits(a.lanes)
            sp = rng.randrange(0, a.depth + 1)
            # make interesting equalities likely: T == R, F == R, cur_rpc == R, npc == cur_rpc
            F = pc + 1
            R = F + rpc_off
            T = F + tgt_off
            r = rng.random()
            if r < 0.25:
                tgt_off = rpc_off                       # taken path empty
            elif r < 0.40:
                rpc_off = 0                             # not-taken path empty
            r = rng.random()
            R = pc + 1 + rpc_off
            T = pc + 1 + tgt_off
            if r < 0.35:
                cur_rpc = R & (lim - 1)                 # merge optimisation
            elif r < 0.45:
                cur_rpc = (T & (lim - 1))               # uniform-taken pop
            elif r < 0.55:
                cur_rpc = ((pc + 1) & (lim - 1))        # uniform-not-taken pop
            else:
                cur_rpc = rng.randrange(0, lim)
            o = resolve_branch(pc, tgt_off, rpc_off, amask, taken, sp, cur_rpc, a.depth, a.pcw)
            ok = lambda v: 0 if v is None else v
            p0 = o["push0"] or (0, 0, 0)
            p1 = o["push1"] or (0, 0, 0)
            f.write(f"{pc:x} {tgt_off & 0x7ff:x} {rpc_off:x} {amask:x} {taken:x} {sp:x} {cur_rpc:x} | "
                    f"{int(o['fault'] == FAULT_PC_RANGE)} {int(o['fault'] == FAULT_STACK_OVF)} {int(o['pop'])} "
                    f"{int(o['kind'] == 'diverge')} {ok(o['pc']):x} {ok(o['mask']):x} {o['rpc']:x} {o['sp']:x} "
                    f"{int(o['push0'] is not None)} {p0[0]:x} {p0[1]:x} {p0[2]:x} "
                    f"{int(o['push1'] is not None)} {p1[0]:x} {p1[1]:x} {p1[2]:x}\n")
            lines += 1
    print(f"wrote {lines} vectors to {a.out}")


if __name__ == "__main__":
    main()
