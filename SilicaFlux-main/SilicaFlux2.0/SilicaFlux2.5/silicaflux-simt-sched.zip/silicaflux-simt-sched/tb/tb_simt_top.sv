// ============================================================================
// System testbench: SIMT control unit + imem model + backend model + host.
//
// Plusargs
//   +prog=<hex> +proglen=<n>   program image (32-bit words, one per line)
//   +mem=<hex>                 initial global memory image ($readmemh format)
//   +nthreads=<n> +nwgs=<m>    workgroup size / number of workgroups
//   +entry=<pc>                kernel entry pc (default 0)
//   +profile=<0..5> +seed=<s>  downstream timing profile / seed (random, schedule dependent)
//   +trace=<hex> +tr_k=<K> +tr_wpg=<W> +tr_wgs=<G> +tr_mshr=<M> +tr_imem=<L>
//                              deterministic workload-trace mode (tools/wl_gen.py): latencies come
//                              from the table, identical for every scheduling policy
//   +sc_<field>=<n>            policy-2 weights / limits (see sfx_sched_cfg_t), e.g. +sc_w_cls_mem=3
//   +launch_gap=<n>            max random idle cycles between workgroup launches
//   +reps=<n>                  run the kernel n times (kernel_clear in between)
//   +out=<prefix>              write <prefix>.log (trace / regs / mem / counters)
//   +maxcyc=<n>                timeout
// ============================================================================
`timescale 1ns/1ps
module tb_simt_top;
  import sfx_simt_pkg::*;
  parameter int NUM_WARPS    = 8;
  parameter int NUM_WGS      = 4;
  parameter int WARP_SIZE    = 32;
  parameter int PC_W         = 16;
  parameter int STACK_DEPTH  = 8;
  parameter int MAX_INFLIGHT = 15;
  parameter int SCHED_POLICY = 0;
  parameter int STARVE_LIMIT = 16;
  parameter bit STRICT_BAR_PC= 1'b0;
  parameter int WG_ID_W      = 8;
  parameter int CNT_W        = 32;
  parameter int GMEM_WORDS   = 16384;
  parameter int SMEM_WORDS   = 256;

  localparam int WID_W = $clog2(NUM_WARPS);
  localparam int SP_W  = $clog2(STACK_DEPTH + 1);
  localparam int NT_W  = $clog2(NUM_WARPS * WARP_SIZE + 1);

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---- DUT interface ----
  logic                  launch_valid, launch_ready, launch_last, kernel_clear, kernel_busy, kernel_done;
  logic [WG_ID_W-1:0]    launch_wg_id;
  logic [NT_W-1:0]       launch_nthreads;
  logic [PC_W-1:0]       launch_pc;
  logic                  fault_valid;
  logic [3:0]            fault_code;
  logic [WG_ID_W-1:0]    fault_wg_id;
  logic [WID_W-1:0]      fault_widx;
  logic [PC_W-1:0]       fault_pc;
  logic [8:0]            fault_mask;
  logic                  imem_req_valid, imem_req_ready, imem_rsp_valid, imem_rsp_err;
  logic [PC_W-1:0]       imem_req_pc;
  logic [WID_W-1:0]      imem_req_tag, imem_rsp_tag;
  logic [31:0]           imem_rsp_data;
  logic                  be_valid;
  logic [1:0]            be_cls;
  logic [WID_W-1:0]      be_warp, be_widx;
  logic [WG_ID_W-1:0]    be_wg_id;
  logic [PC_W-1:0]       be_pc;
  logic [31:0]           be_instr;
  logic [WARP_SIZE-1:0]  be_mask;
  logic [2:0]            be_rdy;
  logic [2:0][CAP_W-1:0] be_cap;
  sfx_sched_cfg_t        sched_cfg;
  logic                  cmp_valid, cmp_wr, cmp_mem, cmp_br;
  logic [WID_W-1:0]      cmp_warp;
  logic [4:0]            cmp_rd;
  logic [WARP_SIZE-1:0]  cmp_taken;
  logic                  iss_valid, exit_valid;
  logic [WID_W-1:0]      iss_warp, iss_widx, exit_warp, exit_widx;
  logic [WG_ID_W-1:0]    iss_wg_id, exit_wg_id;
  logic [PC_W-1:0]       iss_pc;
  logic [WARP_SIZE-1:0]  iss_mask;
  logic [31:0]           iss_instr;
  logic [NUM_WARPS-1:0][2:0] dbg_wstate;

  logic [CNT_W-1:0] cnt_cycles, cnt_issued, cnt_retired, cnt_idle, cnt_idle_nowarp, cnt_idle_be,
                    cnt_idle_mem, cnt_idle_dep, cnt_idle_br, cnt_idle_fetch, cnt_idle_bar,
                    cnt_idle_other, cnt_wc_resident, cnt_wc_issue, cnt_wc_notsel, cnt_wc_dep,
                    cnt_wc_mem, cnt_wc_bar, cnt_wc_br, cnt_wc_fetch, cnt_wc_be, cnt_wc_drain,
                    cnt_div_branches, cnt_bar_episodes, cnt_faults, cnt_proto_err;
  logic [SP_W-1:0]  cnt_stack_hwm;
  logic [NUM_WARPS-1:0][CNT_W-1:0] cnt_warp_issued;

  sfx_simt_ctrl #(
    .NUM_WARPS(NUM_WARPS), .NUM_WGS(NUM_WGS), .WARP_SIZE(WARP_SIZE), .PC_W(PC_W),
    .STACK_DEPTH(STACK_DEPTH), .MAX_INFLIGHT(MAX_INFLIGHT), .SCHED_POLICY(SCHED_POLICY),
    .STARVE_LIMIT(STARVE_LIMIT), .STRICT_BAR_PC(STRICT_BAR_PC), .WG_ID_W(WG_ID_W), .CNT_W(CNT_W)
  ) dut (.*);   // .* connects be_cap and sched_cfg by name

  sfx_imem_model #(.NUM_WARPS(NUM_WARPS), .PC_W(PC_W)) u_imem (
    .clk(clk), .rst_n(rst_n), .req_valid(imem_req_valid), .req_pc(imem_req_pc),
    .req_tag(imem_req_tag), .req_ready(imem_req_ready), .rsp_valid(imem_rsp_valid),
    .rsp_tag(imem_rsp_tag), .rsp_data(imem_rsp_data), .rsp_err(imem_rsp_err));

  sfx_be_model #(.NUM_WARPS(NUM_WARPS), .WARP_SIZE(WARP_SIZE), .PC_W(PC_W), .WG_ID_W(WG_ID_W),
                 .GMEM_WORDS(GMEM_WORDS), .SMEM_WORDS(SMEM_WORDS)) u_be (
    .clk(clk), .rst_n(rst_n), .be_valid(be_valid), .be_cls(be_cls), .be_warp(be_warp),
    .be_wg_id(be_wg_id), .be_widx(be_widx), .be_pc(be_pc), .be_instr(be_instr), .be_mask(be_mask),
    .be_rdy(be_rdy), .be_cap(be_cap), .cmp_valid(cmp_valid), .cmp_warp(cmp_warp), .cmp_wr(cmp_wr), .cmp_rd(cmp_rd),
    .cmp_mem(cmp_mem), .cmp_br(cmp_br), .cmp_taken(cmp_taken), .dbg_wstate(dbg_wstate));

  // independent checker + scheduler statistics (observes ports; scheduler view via hierarchy)
  logic [NUM_WARPS-1:0]                mon_alive, mon_ready;
  logic [NUM_WARPS-1:0][31:0]          mon_ib;
  logic [NUM_WARPS-1:0][WG_ID_W-1:0]   mon_slot_wg;
  logic [NUM_WARPS-1:0][WID_W-1:0]     mon_slot_widx;
  always_comb begin
    for (int w = 0; w < NUM_WARPS; w++) begin
      mon_alive[w]     = (dut.wstate[w] != 3'd0);
      mon_ready[w]     = (dut.wstate[w] == 3'd3) && !dut.gabort[dut.wwg[w]];
      mon_ib[w]        = dut.wib[w];
      mon_slot_wg[w]   = dut.gid[dut.wwg[w]];
      mon_slot_widx[w] = dut.widx_q[w];
    end
  end
  sfx_sched_monitor #(.NUM_WARPS(NUM_WARPS), .WARP_SIZE(WARP_SIZE), .WG_ID_W(WG_ID_W), .NT_W(NT_W)) u_sm (
    .clk(clk), .rst_n(rst_n), .launch_valid(launch_valid), .launch_ready(launch_ready),
    .launch_wg_id(launch_wg_id), .launch_nthreads(launch_nthreads),
    .iss_valid(iss_valid), .iss_warp(iss_warp), .iss_wg_id(iss_wg_id), .iss_widx(iss_widx),
    .iss_instr(iss_instr), .iss_mask(iss_mask),
    .exit_valid(exit_valid), .exit_wg_id(exit_wg_id), .exit_widx(exit_widx),
    .be_valid(be_valid), .be_cls(be_cls), .be_rdy(be_rdy),
    .cmp_valid(cmp_valid), .cmp_warp(cmp_warp), .cmp_wr(cmp_wr), .cmp_rd(cmp_rd), .cmp_mem(cmp_mem),
    .cand(dut.w_cand), .grant(dut.grant), .stall_mem(dut.w_stall_mem), .cls(dut.w_cls),
    .alive(mon_alive), .slot_wg(mon_slot_wg), .slot_widx(mon_slot_widx),
    .ft_ready(mon_ready), .ft_ib(mon_ib), .ft_press(dut.w_bar_press), .ft_rel(dut.w_bar_rel),
    .ft_stall_mem(dut.w_stall_mem), .ft_stall_dep(dut.w_stall_dep),
    .ft_is_ld(dut.w_is_ld), .ft_cls(dut.w_cls), .ft_cap(dut.cls_cap), .be_cap(be_cap));

  // ---- policy-2 configuration: defaults, overridden by +sc_<field>=<n> ----
  task automatic parse_sched_cfg();
    int v;
    sched_cfg = sfx_sched_cfg_default(NUM_WARPS);
    if ($value$plusargs("sc_w_cls_alu=%d",  v)) sched_cfg.w_cls_alu  = 3'(v);
    if ($value$plusargs("sc_w_cls_mem=%d",  v)) sched_cfg.w_cls_mem  = 3'(v);
    if ($value$plusargs("sc_w_cls_br=%d",   v)) sched_cfg.w_cls_br   = 3'(v);
    if ($value$plusargs("sc_w_cls_ctrl=%d", v)) sched_cfg.w_cls_ctrl = 3'(v);
    if ($value$plusargs("sc_w_ld=%d",       v)) sched_cfg.w_ld       = 3'(v);
    if ($value$plusargs("sc_w_memdep=%d",   v)) sched_cfg.w_memdep   = 3'(v);
    if ($value$plusargs("sc_w_dep=%d",      v)) sched_cfg.w_dep      = 3'(v);
    if ($value$plusargs("sc_w_bar=%d",      v)) sched_cfg.w_bar      = 3'(v);
    if ($value$plusargs("sc_w_rel=%d",      v)) sched_cfg.w_rel      = 3'(v);
    if ($value$plusargs("sc_w_cap=%d",      v)) sched_cfg.w_cap      = 3'(v);
    if ($value$plusargs("sc_w_age=%d",      v)) sched_cfg.w_age      = 3'(v);
    if ($value$plusargs("sc_fair_limit=%d", v)) sched_cfg.fair_limit = 6'(v);
    if ($value$plusargs("sc_cls_limit=%d",  v)) sched_cfg.cls_limit  = 4'(v);
    // legal range for the stated fairness bounds (docs/SCHEDULER_POLICIES.md): guard off, or >= N+3
    if (SCHED_POLICY == 2 && !$test$plusargs("sc_illegal_ok")) begin
      if (sched_cfg.fair_limit != 0 && int'(sched_cfg.fair_limit) < NUM_WARPS + 3)
        $fatal(1, "[TB] illegal policy-2 config: fair_limit=%0d must be 0 or >= NUM_WARPS+3=%0d (pass +sc_illegal_ok to override)",
               sched_cfg.fair_limit, NUM_WARPS + 3);
    end
  endtask
  initial parse_sched_cfg();

  sfx_assume_monitor #(.NUM_WARPS(NUM_WARPS)) u_mon (
    .clk(clk), .rst_n(rst_n), .imem_req_valid(imem_req_valid), .imem_req_tag(imem_req_tag),
    .imem_req_ready(imem_req_ready), .imem_rsp_valid(imem_rsp_valid), .imem_rsp_tag(imem_rsp_tag),
    .be_valid(be_valid), .be_cls(be_cls), .be_warp(be_warp), .be_rdy(be_rdy),
    .cmp_valid(cmp_valid), .cmp_warp(cmp_warp));

  // ---- run configuration ----
  int nthreads, nwgs, entry, reps, launch_gap, maxcyc;
  string out_prefix, mem_file;
  int fd = 0;
  bit dump_en;
  bit verbose;
  longint cycle;
  int unsigned hrng;

  function automatic int unsigned hrnd();
    hrng ^= hrng << 13; hrng ^= hrng >> 17; hrng ^= hrng << 5;
    return hrng;
  endfunction

  always @(posedge clk) cycle <= cycle + 1;
  initial cycle = 0;

  // ---- trace / register dump ----
  always @(posedge clk) begin
    if (rst_n && dump_en && fd != 0) begin
      if (iss_valid)
        $fwrite(fd, "I %0d %0d %0d %h\n", iss_wg_id, iss_widx, iss_pc, iss_mask);
      if (exit_valid) begin
        automatic int nthr = nthreads - int'(exit_widx) * WARP_SIZE;
        if (nthr > WARP_SIZE) nthr = WARP_SIZE;
        for (int l = 0; l < nthr; l++) begin
          $fwrite(fd, "R %0d %0d", exit_wg_id, int'(exit_widx) * WARP_SIZE + l);
          for (int r = 0; r < 32; r++)
            $fwrite(fd, " %h", (r == 0) ? 32'h0 : u_be.rf[exit_warp][l][r]);
          $fwrite(fd, "\n");
        end
      end
    end
  end

  // ---- invariants on the counters (checked at kernel completion) ----
  task automatic check_counter_invariants();
    longint idle_sum, wc_sum;
    idle_sum = longint'(cnt_idle_nowarp) + cnt_idle_be + cnt_idle_mem + cnt_idle_dep + cnt_idle_br
             + cnt_idle_fetch + cnt_idle_bar + cnt_idle_other;
    wc_sum = longint'(cnt_wc_issue) + cnt_wc_notsel + cnt_wc_dep + cnt_wc_mem + cnt_wc_bar + cnt_wc_br
           + cnt_wc_fetch + cnt_wc_be + cnt_wc_drain;
    if (cnt_cycles != cnt_issued + cnt_idle)
      $fatal(1, "[TB] counter invariant: cycles(%0d) != issued(%0d)+idle(%0d)", cnt_cycles, cnt_issued, cnt_idle);
    if (idle_sum != longint'(cnt_idle))
      $fatal(1, "[TB] counter invariant: idle causes sum %0d != idle %0d", idle_sum, cnt_idle);
    if (wc_sum != longint'(cnt_wc_resident))
      $fatal(1, "[TB] counter invariant: warp-cycle buckets sum %0d != resident %0d", wc_sum, cnt_wc_resident);
    if (cnt_issued != cnt_retired)
      $fatal(1, "[TB] counter invariant: issued(%0d) != retired(%0d) at kernel completion", cnt_issued, cnt_retired);
    if ($test$plusargs("spurious")) begin
      if (cnt_proto_err == 0) $fatal(1, "[TB] hostile downstream injected spurious traffic but proto_err == 0");
    end else if (cnt_proto_err != 0)
      $fatal(1, "[TB] protocol errors reported by the control unit: %0d", cnt_proto_err);
  endtask

  task automatic dump_final();
    if (fd != 0) begin
      $fwrite(fd, "C cycles %0d\nC issued %0d\nC retired %0d\nC idle %0d\n", cnt_cycles, cnt_issued, cnt_retired, cnt_idle);
      $fwrite(fd, "C idle_nowarp %0d\nC idle_be %0d\nC idle_mem %0d\nC idle_dep %0d\nC idle_br %0d\nC idle_fetch %0d\nC idle_bar %0d\nC idle_other %0d\n",
              cnt_idle_nowarp, cnt_idle_be, cnt_idle_mem, cnt_idle_dep, cnt_idle_br, cnt_idle_fetch, cnt_idle_bar, cnt_idle_other);
      $fwrite(fd, "C wc_resident %0d\nC wc_issue %0d\nC wc_notsel %0d\nC wc_dep %0d\nC wc_mem %0d\nC wc_bar %0d\nC wc_br %0d\nC wc_fetch %0d\nC wc_be %0d\nC wc_drain %0d\n",
              cnt_wc_resident, cnt_wc_issue, cnt_wc_notsel, cnt_wc_dep, cnt_wc_mem, cnt_wc_bar, cnt_wc_br, cnt_wc_fetch, cnt_wc_be, cnt_wc_drain);
      $fwrite(fd, "C div_branches %0d\nC bar_episodes %0d\nC faults %0d\nC proto_err %0d\nC stack_hwm %0d\n",
              cnt_div_branches, cnt_bar_episodes, cnt_faults, cnt_proto_err, cnt_stack_hwm);
      for (int w = 0; w < NUM_WARPS; w++) $fwrite(fd, "C warp_issued_%0d %0d\n", w, cnt_warp_issued[w]);
      $fwrite(fd, "F %0d %0d %0d %0d %0d %0d\n", fault_valid, fault_code, fault_wg_id, fault_widx, fault_pc, fault_mask);
      $fwrite(fd, "D %0d\n", cycle);
      u_sm.dump(fd);
      $fwrite(fd, "X max_imem_lat %0d\nX max_cmp_gap %0d\n", u_mon.get_max_imem_lat(), u_mon.get_max_cmp_gap());
      $fwrite(fd, "X tr_n %0d\nX tr_lat %0d\nX tr_gap %0d\n", u_be.tr_n, u_be.tr_lat_sum, u_be.tr_gap_sum);
      for (int i = 0; i < GMEM_WORDS; i++)
        if (u_be.gmem[i] != 32'h0) $fwrite(fd, "M %0d %h\n", i, u_be.gmem[i]);
      $fclose(fd);
    end
  endtask

  task automatic load_mem();
    for (int i = 0; i < GMEM_WORDS; i++) u_be.gmem[i] = 32'h0;
    for (int wg = 0; wg < 64; wg++) for (int i = 0; i < SMEM_WORDS; i++) u_be.smem[wg][i] = 32'h0;
    if (mem_file != "") $readmemh(mem_file, u_be.gmem);
  endtask

  // Launch handshake driven from a regular clocked block (same sampling discipline as the
  // models: it sees pre-edge values of launch_ready).  The initial block only posts requests.
  bit  l_req;            // set by the main thread, cleared by the driver when the launch is accepted
  int  l_wg;
  bit  l_last;
  always @(posedge clk) begin
    if (!rst_n) begin
      launch_valid <= 1'b0; launch_wg_id <= '0; launch_nthreads <= '0; launch_pc <= '0; launch_last <= 1'b0;
    end else if (launch_valid && launch_ready) begin
      launch_valid <= 1'b0;
      launch_last  <= 1'b0;
      l_req = 1'b0;
    end else if (l_req && !launch_valid) begin
      launch_valid    <= 1'b1;
      launch_wg_id    <= WG_ID_W'(l_wg);
      launch_nthreads <= NT_W'(nthreads);
      launch_pc       <= PC_W'(entry);
      launch_last     <= l_last;
    end
  end

  task automatic launch_wg(input int wg, input bit last);
    int gap;
    gap = (launch_gap > 0) ? int'(hrnd() % unsigned'(launch_gap + 1)) : 0;
    repeat (gap) @(posedge clk);
    l_wg = wg; l_last = last;
    l_req = 1'b1;
    while (l_req) @(posedge clk);
  endtask

  initial begin
    int seed;
    if (!$value$plusargs("nthreads=%d", nthreads)) nthreads = 32;
    if (!$value$plusargs("nwgs=%d", nwgs)) nwgs = 1;
    if (!$value$plusargs("entry=%d", entry)) entry = 0;
    if (!$value$plusargs("reps=%d", reps)) reps = 1;
    if (!$value$plusargs("launch_gap=%d", launch_gap)) launch_gap = 0;
    if (!$value$plusargs("maxcyc=%d", maxcyc)) maxcyc = 3000000;
    if (!$value$plusargs("mem=%s", mem_file)) mem_file = "";
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    verbose = $test$plusargs("verbose");
    hrng = 32'h2545F491 ^ unsigned'(seed * 31337 + 1);
    if (hrng == 0) hrng = 1;
    l_req = 1'b0;
    kernel_clear = 1'b0;
    dump_en = 1'b0;
    if ($value$plusargs("out=%s", out_prefix)) fd = $fopen({out_prefix, ".log"}, "w");

    repeat (4) @(posedge clk);
    rst_n <= 1'b1;
    repeat (2) @(posedge clk);

    for (int rep = 0; rep < reps; rep++) begin
      load_mem();
      dump_en = (rep == reps - 1);
      for (int wg = 0; wg < nwgs; wg++) begin
        launch_wg(wg, wg == nwgs - 1);
        if (verbose) $display("[TB] t=%0d launched wg %0d", cycle, wg);
      end
      while (!kernel_done) @(posedge clk);
      if (verbose) $display("[TB] t=%0d kernel_done", cycle);
      repeat (3) @(posedge clk);
      check_counter_invariants();
      if (verbose) $display("[TB] t=%0d invariants ok", cycle);
      if (rep != reps - 1) begin
        kernel_clear <= 1'b1;
        @(posedge clk);
        kernel_clear <= 1'b0;
        repeat (2) @(posedge clk);
        if (kernel_done || kernel_busy) $fatal(1, "[TB] kernel_done/busy still set after kernel_clear");
        if (cnt_cycles != 0 || cnt_issued != 0 || cnt_retired != 0)
          $fatal(1, "[TB] counters not cleared by kernel_clear");
      end
    end
    dump_final();
    $display("[TB] PASS-RUN done: cycles=%0d issued=%0d idle=%0d fault=%0d/%0d",
             cnt_cycles, cnt_issued, cnt_idle, fault_valid, fault_code);
    $finish;
  end

  // timeout watchdog
  initial begin
    forever begin
      @(posedge clk);
      if (cycle > maxcyc) begin
        $display("[TB] TIMEOUT after %0d cycles (kernel_done=%0d busy=%0d)", cycle, kernel_done, kernel_busy);
        $fatal(1, "TIMEOUT");
      end
    end
  end
endmodule
