// ============================================================================
// Independent scheduler monitor (testbench).
//
// It observes only the external interfaces of sfx_simt_ctrl (issue trace,
// backend issue / completion, host launch) and re-implements the ISA register
// decode on its own, so it does not trust the RTL decoder, the RTL scoreboard or
// the RTL barrier unit.  Fatal checks:
//
//   M1  operands available     : an instruction never issues while a source register or the
//                                destination is pending (RAW / WAW), shadow scoreboard
//   M2  resource available     : be_valid only while be_rdy[class] was high
//   M3  memory ordering        : BAR issues only with no outstanding memory operation of the warp
//                                (data visible before the barrier); EXIT only with nothing in flight
//   M4  barrier semantics      : once a warp has passed its k-th BAR, every warp of the workgroup
//                                has either issued its k-th BAR or exited (no early release, no
//                                warp slips into the next episode)
//   M5  execution mask         : never issue with an empty mask
//   M6  scheduler features     : the barrier features the controller feeds to policy 2
//                                (parked warps of the own workgroup, "this issue releases the
//                                barrier") equal the values derived here from the issue trace alone
//   M7  stall classification   : "blocked on a memory result" / "blocked on a register result" as used
//                                by the policy's wake-up bonus equal the values derived from the shadow
//                                scoreboard (load-tagged pending registers, outstanding memory operations)
//   M8  instruction features   : class code and load flag fed to the arbiter equal the monitor's own decode
//   M9  capacity hint          : the per-class headroom fed to the arbiter equals the backend's be_cap
//                                (CTRL class: never limited)
//   M7  stall classification   : "blocked on a memory result" / "blocked on a register result" as used
//                                by the policy's wake-up bonus equal the values derived from the shadow
//                                scoreboard (load-tagged pending registers, outstanding memory operations)
//
// Statistics (dumped as log lines for tools/compare_policies.py):
//   per warp (wg,widx): launch / exit cycle, issued instructions, cycles as a candidate, cycles
//   as a candidate that were not granted (== grants lost, the scheduler is work conserving)
//   per class        : grants, candidate-to-grant wait (sum / max / count)
//   memory-dependent : candidate-to-grant wait of warps that had been blocked on a memory result
//                      since their previous issue, vs all other issues
// ============================================================================
module sfx_sched_monitor #(
  parameter int NUM_WARPS  = 8,
  parameter int WARP_SIZE  = 32,
  parameter int WG_ID_W    = 8,
  parameter int NT_W       = 9,
  parameter int MAXWG      = 64
) (
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic                              launch_valid,
  input  logic                              launch_ready,
  input  logic [WG_ID_W-1:0]                launch_wg_id,
  input  logic [NT_W-1:0]                   launch_nthreads,
  input  logic                              iss_valid,
  input  logic [$clog2(NUM_WARPS)-1:0]      iss_warp,
  input  logic [WG_ID_W-1:0]                iss_wg_id,
  input  logic [$clog2(NUM_WARPS)-1:0]      iss_widx,
  input  logic [31:0]                       iss_instr,
  input  logic [WARP_SIZE-1:0]              iss_mask,
  input  logic                              exit_valid,
  input  logic [WG_ID_W-1:0]                exit_wg_id,
  input  logic [$clog2(NUM_WARPS)-1:0]      exit_widx,
  input  logic                              be_valid,
  input  logic [1:0]                        be_cls,
  input  logic [2:0]                        be_rdy,
  input  logic                              cmp_valid,
  input  logic [$clog2(NUM_WARPS)-1:0]      cmp_warp,
  input  logic                              cmp_wr,
  input  logic [4:0]                        cmp_rd,
  input  logic                              cmp_mem,
  // scheduler view (hierarchical connections made by the testbench top)
  input  logic [NUM_WARPS-1:0]              cand,
  input  logic [NUM_WARPS-1:0]              grant,
  input  logic [NUM_WARPS-1:0]              stall_mem,
  input  logic [NUM_WARPS-1:0][1:0]         cls,
  input  logic [NUM_WARPS-1:0]              alive,
  input  logic [NUM_WARPS-1:0][WG_ID_W-1:0] slot_wg,
  input  logic [NUM_WARPS-1:0][$clog2(NUM_WARPS)-1:0] slot_widx,
  // controller-internal feature values and the state needed to judge them (hierarchical connections)
  input  logic [NUM_WARPS-1:0]              ft_ready,       // slot holds a buffered instruction (READY) and is not aborting
  input  logic [NUM_WARPS-1:0][31:0]        ft_ib,          // buffered instruction word
  input  logic [NUM_WARPS-1:0][1:0]         ft_press,       // w_bar_press
  input  logic [NUM_WARPS-1:0]              ft_rel,         // w_bar_rel
  input  logic [NUM_WARPS-1:0]              ft_stall_mem,   // w_stall_mem
  input  logic [NUM_WARPS-1:0]              ft_stall_dep,   // w_stall_dep
  input  logic [NUM_WARPS-1:0]              ft_is_ld,       // w_is_ld
  input  logic [NUM_WARPS-1:0][1:0]         ft_cls,         // w_cls
  input  logic [3:0][1:0]                   ft_cap,         // cls_cap (per class, incl. CTRL)
  input  logic [2:0][1:0]                   be_cap          // backend headroom hint
);
  localparam int WID_W = $clog2(NUM_WARPS);

  longint cycle;
  bit     hostile;                 // +spurious: completions for idle warps are expected, skip shadow checks
  initial begin hostile = $test$plusargs("spurious"); cycle = 0; end

  // ---------------- independent decode ----------------
  typedef struct {
    bit u1, u2, wr, is_mem;
    int rs1, rs2, rd;
    int op;
  } mdec_t;

  function automatic mdec_t mdecode(input logic [31:0] i);
    mdec_t d;
    int op, a, b, c;
    op = int'(i[31:26]); a = int'(i[25:21]); b = int'(i[20:16]); c = int'(i[15:11]);
    d.u1 = 0; d.u2 = 0; d.wr = 0; d.is_mem = 0; d.rs1 = 0; d.rs2 = 0; d.rd = 0; d.op = op;
    if (op >= 1 && op <= 9)       begin d.u1 = 1; d.u2 = 1; d.wr = 1; d.rd = a; d.rs1 = b; d.rs2 = c; end   // add .. mul
    else if (op == 10 || op == 11) begin d.u1 = 1; d.wr = 1; d.rd = a; d.rs1 = b; end                       // addi andi
    else if (op >= 12 && op <= 14) begin d.wr = 1; d.rd = a; end                                            // movi tid wgid
    else if (op == 16 || op == 18) begin d.u1 = 1; d.wr = 1; d.rd = a; d.rs1 = b; d.is_mem = 1; end        // ld lds
    else if (op == 17 || op == 19) begin d.u1 = 1; d.u2 = 1; d.rs1 = b; d.rs2 = c; d.is_mem = 1; end       // st sts
    else if (op == 32 || op == 33) begin d.u1 = 1; d.rs1 = a; end                                           // bra brz
    return d;
  endfunction

  // ---------------- shadow state ----------------
  logic [31:0] pend [NUM_WARPS];
  logic [31:0] pmem [NUM_WARPS];          // pending registers whose producer is a load
  int          ft7_checks, ft7_mem, ft7_dep;
  int          ninf [NUM_WARPS];
  int          nmem [NUM_WARPS];
  logic        alive_q [NUM_WARPS];

  int  barcnt  [MAXWG][NUM_WARPS];
  bit  exited  [MAXWG][NUM_WARPS];
  int  nwarps  [MAXWG];
  // independent barrier tracking: bit k = warp k of the workgroup
  logic [NUM_WARPS-1:0] arr_mask  [MAXWG];     // parked at the barrier
  logic [NUM_WARPS-1:0] live_mask [MAXWG];     // neither exited nor faulted
  int   ft_checks, ft_rel_seen;

  // ---------------- statistics ----------------
  longint launch_cyc [MAXWG];
  longint first_launch;
  longint exit_cyc   [MAXWG][NUM_WARPS];
  bit     has_exit   [MAXWG][NUM_WARPS];
  longint st_issued  [MAXWG][NUM_WARPS];
  longint st_cand    [MAXWG][NUM_WARPS];
  longint st_notsel  [MAXWG][NUM_WARPS];
  int     st_maxwait [MAXWG][NUM_WARPS];
  int     cur_wait   [NUM_WARPS];
  bit     ms         [NUM_WARPS];
  longint cl_grants  [4];
  longint cl_wsum    [4];
  longint cl_wcnt    [4];
  int     cl_wmax    [4];
  longint md_cnt, md_sum, ot_cnt, ot_sum;
  int     md_max, ot_max;
  int     max_wait_all;

  initial begin
    ft_checks = 0; ft_rel_seen = 0;
    for (int g = 0; g < MAXWG; g++) begin arr_mask[g] = '0; live_mask[g] = '0; end
    first_launch = -1; md_cnt = 0; md_sum = 0; ot_cnt = 0; ot_sum = 0; md_max = 0; ot_max = 0; max_wait_all = 0;
    for (int c = 0; c < 4; c++) begin cl_grants[c] = 0; cl_wsum[c] = 0; cl_wcnt[c] = 0; cl_wmax[c] = 0; end
    for (int g = 0; g < MAXWG; g++) begin
      launch_cyc[g] = -1; nwarps[g] = 0;
      for (int w = 0; w < NUM_WARPS; w++) begin
        barcnt[g][w] = 0; exited[g][w] = 0; exit_cyc[g][w] = 0; has_exit[g][w] = 0;
        st_issued[g][w] = 0; st_cand[g][w] = 0; st_notsel[g][w] = 0; st_maxwait[g][w] = 0;
      end
    end
    ft7_checks = 0; ft7_mem = 0; ft7_dep = 0;
    for (int w = 0; w < NUM_WARPS; w++) begin pend[w] = '0; pmem[w] = '0; ninf[w] = 0; nmem[w] = 0; alive_q[w] = 0; cur_wait[w] = 0; ms[w] = 0; end
  end

  always @(posedge clk) begin
    cycle <= cycle + 1;
    if (rst_n) begin
      // ------------------------------------------------ host launch
      if (launch_valid && launch_ready && int'(launch_nthreads) != 0
          && int'(launch_nthreads) <= NUM_WARPS * WARP_SIZE && int'(launch_wg_id) < MAXWG) begin
        automatic int g = int'(launch_wg_id);
        nwarps[g] = (int'(launch_nthreads) + WARP_SIZE - 1) / WARP_SIZE;
        launch_cyc[g] = cycle;
        if (first_launch < 0) first_launch = cycle;
        for (int w = 0; w < NUM_WARPS; w++) begin barcnt[g][w] = 0; exited[g][w] = 0; has_exit[g][w] = 0; end
        arr_mask[g] = '0;
        live_mask[g] = (NUM_WARPS'(1) << nwarps[g]) - NUM_WARPS'(1);
      end

      // ------------------------------------------------ M6: scheduler barrier features (pre-edge view)
      for (int w = 0; w < NUM_WARPS; w++) begin
        if (ft_ready[w] && int'(slot_wg[w]) < MAXWG && nwarps[slot_wg[w]] != 0 && !hostile) begin
          automatic int g  = int'(slot_wg[w]);
          automatic int k  = int'(slot_widx[w]);
          automatic int np = $countones(arr_mask[g]);
          automatic int exp_press = (np > 3) ? 3 : np;
          automatic logic [NUM_WARPS-1:0] me = NUM_WARPS'(1) << k;
          automatic int op = int'(ft_ib[w][31:26]);
          automatic bit exp_rel = ((op == 35) && ((arr_mask[g] | me) == live_mask[g]))
                               || ((op == 36) && (arr_mask[g] != '0) && (arr_mask[g] == (live_mask[g] & ~me)));
          ft_checks++;
          if (exp_rel) ft_rel_seen++;
          if (int'(ft_press[w]) != exp_press)
            $fatal(1, "[MON] M6: bar_press of wg %0d warp %0d is %0d, independent tracking says %0d", g, k, ft_press[w], exp_press);
          if (ft_rel[w] !== exp_rel)
            $fatal(1, "[MON] M6: bar_rel of wg %0d warp %0d is %0d, independent tracking says %0d (instr %h)", g, k, ft_rel[w], exp_rel, ft_ib[w]);
          // ---- M8: class and load flag ----
          begin
            automatic mdec_t d8 = mdecode(ft_ib[w]);
            automatic int e_cls = (d8.op >= 1 && d8.op <= 14) ? 0 : (d8.op >= 16 && d8.op <= 19) ? 1 : (d8.op == 32 || d8.op == 33) ? 2 : 3;
            automatic bit e_ld  = (d8.op == 16 || d8.op == 18);
            if (int'(ft_cls[w]) != e_cls)
              $fatal(1, "[MON] M8: class of wg %0d warp %0d is %0d, own decode says %0d (instr %h)", g, k, ft_cls[w], e_cls, ft_ib[w]);
            if (ft_is_ld[w] !== e_ld)
              $fatal(1, "[MON] M8: load flag of wg %0d warp %0d is %0d, own decode says %0d (instr %h)", g, k, ft_is_ld[w], e_ld, ft_ib[w]);
          end
          // ---- M7: stall classification from the shadow scoreboard ----
          begin
            automatic mdec_t d7 = mdecode(ft_ib[w]);
            automatic bit h1 = d7.u1 && pend[w][d7.rs1];
            automatic bit h2 = d7.u2 && pend[w][d7.rs2];
            automatic bit h3 = d7.wr && d7.rd != 0 && pend[w][d7.rd];
            automatic bit hz = h1 || h2 || h3;
            automatic bit hm = (d7.u1 && pmem[w][d7.rs1]) || (d7.u2 && pmem[w][d7.rs2]) || (d7.wr && d7.rd != 0 && pmem[w][d7.rd]);
            automatic bit blk = (d7.op == 35 && nmem[w] != 0) || (d7.op == 36 && ninf[w] != 0);
            automatic bit e_mem = hz ? hm : (blk && nmem[w] != 0);
            automatic bit e_dep = hz ? !hm : (blk && nmem[w] == 0);
            ft7_checks++;
            if (e_mem) ft7_mem++;
            if (e_dep) ft7_dep++;
            if (ft_stall_mem[w] !== e_mem)
              $fatal(1, "[MON] M7: stall_mem of wg %0d warp %0d is %0d, shadow scoreboard says %0d (instr %h)", g, k, ft_stall_mem[w], e_mem, ft_ib[w]);
            if (ft_stall_dep[w] !== e_dep)
              $fatal(1, "[MON] M7: stall_dep of wg %0d warp %0d is %0d, shadow scoreboard says %0d (instr %h)", g, k, ft_stall_dep[w], e_dep, ft_ib[w]);
          end
        end
      end

      // ------------------------------------------------ slot allocation (reset per-slot shadows)
      for (int w = 0; w < NUM_WARPS; w++) begin
        if (alive[w] && !alive_q[w]) begin
          pend[w] = '0; pmem[w] = '0; ninf[w] = 0; nmem[w] = 0; cur_wait[w] = 0; ms[w] = 0;
        end
        alive_q[w] = alive[w];
      end

      // ------------------------------------------------ scheduler statistics (pre-edge view)
      for (int w = 0; w < NUM_WARPS; w++) begin
        if (alive[w] && int'(slot_wg[w]) < MAXWG) begin
          automatic int g = int'(slot_wg[w]);
          automatic int k = int'(slot_widx[w]);
          if (stall_mem[w]) ms[w] = 1'b1;
          if (cand[w]) begin
            st_cand[g][k]++;
            if (grant[w]) begin
              automatic int c = int'(cls[w]);
              cl_grants[c]++; cl_wsum[c] += cur_wait[w]; cl_wcnt[c]++;
              if (cur_wait[w] > cl_wmax[c]) cl_wmax[c] = cur_wait[w];
              if (ms[w]) begin md_cnt++; md_sum += cur_wait[w]; if (cur_wait[w] > md_max) md_max = cur_wait[w]; end
              else       begin ot_cnt++; ot_sum += cur_wait[w]; if (cur_wait[w] > ot_max) ot_max = cur_wait[w]; end
              if (cur_wait[w] > st_maxwait[g][k]) st_maxwait[g][k] = cur_wait[w];
              if (cur_wait[w] > max_wait_all) max_wait_all = cur_wait[w];
              cur_wait[w] = 0; ms[w] = 1'b0;
            end else begin
              st_notsel[g][k]++;
              cur_wait[w]++;
            end
          end
        end
      end

      // ------------------------------------------------ M9: headroom hint mapping
      if (ft_cap[0] !== be_cap[0] || ft_cap[1] !== be_cap[1] || ft_cap[2] !== be_cap[2] || ft_cap[3] !== 2'd3)
        $fatal(1, "[MON] M9: class headroom fed to the arbiter %h differs from the backend hint %h", ft_cap, be_cap);

      // ------------------------------------------------ issue checks (pre-edge shadow state)
      if (iss_valid) begin
        automatic mdec_t d = mdecode(iss_instr);
        automatic int s = int'(iss_warp);
        automatic int g = int'(iss_wg_id);
        automatic int k = int'(iss_widx);
        if (g < MAXWG) st_issued[g][k]++;
        if (iss_mask == '0) $fatal(1, "[MON] M5: issue with an empty execution mask (wg %0d warp %0d)", g, k);
        if (!hostile) begin
          if (d.u1 && pend[s][d.rs1] && d.rs1 != 0) $fatal(1, "[MON] M1: RAW hazard on r%0d at issue (wg %0d warp %0d instr %h)", d.rs1, g, k, iss_instr);
          if (d.u2 && pend[s][d.rs2] && d.rs2 != 0) $fatal(1, "[MON] M1: RAW hazard on r%0d at issue (wg %0d warp %0d instr %h)", d.rs2, g, k, iss_instr);
          if (d.wr && d.rd != 0 && pend[s][d.rd])   $fatal(1, "[MON] M1: WAW hazard on r%0d at issue (wg %0d warp %0d instr %h)", d.rd, g, k, iss_instr);
          if (d.op == 35 && nmem[s] != 0) $fatal(1, "[MON] M3: BAR issued with %0d outstanding memory operations (wg %0d warp %0d)", nmem[s], g, k);
          if (d.op == 36 && ninf[s] != 0) $fatal(1, "[MON] M3: EXIT issued with %0d instructions in flight (wg %0d warp %0d)", ninf[s], g, k);
        end
        if (be_valid && !be_rdy[be_cls]) $fatal(1, "[MON] M2: issued to backend class %0d while it was not ready", be_cls);
        // M4 barrier episodes
        if (g < MAXWG && nwarps[g] != 0) begin
          for (int j = 0; j < nwarps[g]; j++)
            if (j != k && !exited[g][j] && barcnt[g][j] < barcnt[g][k])
              $fatal(1, "[MON] M4: wg %0d warp %0d passed barrier #%0d but warp %0d has only arrived at %0d and has not exited",
                     g, k, barcnt[g][k], j, barcnt[g][j]);
          if (d.op == 35) begin
            barcnt[g][k]++;
            arr_mask[g][k] = 1'b1;
          end
        end
        // shadow scoreboard update for backend instructions
        if (be_valid) begin
          ninf[s]++;
          if (d.is_mem) nmem[s]++;
          if (d.wr && d.rd != 0) begin
            pend[s][d.rd] = 1'b1;
            pmem[s][d.rd] = (d.op == 16 || d.op == 18);     // LD / LDS results are 'memory' registers
          end
        end
      end
      if (exit_valid && int'(exit_wg_id) < MAXWG) begin
        exited[exit_wg_id][exit_widx] = 1'b1;
        live_mask[exit_wg_id][exit_widx] = 1'b0;
        has_exit[exit_wg_id][exit_widx] = 1'b1;
        exit_cyc[exit_wg_id][exit_widx] = cycle;
      end

      // barrier release (same cycle as the last arrival / exit): every live warp has arrived
      for (int g = 0; g < MAXWG; g++)
        if (nwarps[g] != 0 && arr_mask[g] != '0 && arr_mask[g] == live_mask[g]) arr_mask[g] = '0;

      // ------------------------------------------------ completions
      if (cmp_valid && !hostile) begin
        automatic int s = int'(cmp_warp);
        if (ninf[s] <= 0) $fatal(1, "[MON] completion for warp slot %0d with nothing in flight", s);
        ninf[s]--;
        if (cmp_mem) begin
          if (nmem[s] <= 0) $fatal(1, "[MON] memory completion for warp slot %0d with no memory op outstanding", s);
          nmem[s]--;
        end
        if (cmp_wr) begin pend[s][cmp_rd] = 1'b0; pmem[s][cmp_rd] = 1'b0; end
      end
    end
  end

  // ---------------- dump ----------------
  task automatic dump(input int fd);
    for (int g = 0; g < MAXWG; g++) begin
      if (launch_cyc[g] >= 0) begin
        $fwrite(fd, "L %0d %0d %0d\n", g, launch_cyc[g] - first_launch, nwarps[g]);
        for (int k = 0; k < nwarps[g]; k++)
          $fwrite(fd, "W %0d %0d %0d %0d %0d %0d %0d\n", g, k, st_issued[g][k], st_cand[g][k], st_notsel[g][k],
                  st_maxwait[g][k], has_exit[g][k] ? (exit_cyc[g][k] - first_launch) : -1);
      end
    end
    for (int c = 0; c < 4; c++)
      $fwrite(fd, "G %0d %0d %0d %0d %0d\n", c, cl_grants[c], cl_wcnt[c], cl_wsum[c], cl_wmax[c]);
    $fwrite(fd, "X mon_ft_checks %0d\nX mon_ft_rel %0d\nX mon_ft7_mem %0d\nX mon_ft7_dep %0d\n", ft_checks, ft_rel_seen, ft7_mem, ft7_dep);
    $fwrite(fd, "H md %0d %0d %0d\nH ot %0d %0d %0d\nH maxwait %0d\n", md_cnt, md_sum, md_max, ot_cnt, ot_sum, ot_max, max_wait_all);
  endtask
endmodule
