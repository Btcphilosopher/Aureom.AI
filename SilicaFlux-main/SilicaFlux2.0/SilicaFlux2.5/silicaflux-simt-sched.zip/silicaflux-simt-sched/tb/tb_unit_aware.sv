// ============================================================================
// Unit test of sfx_aware_arb (scheduling policy 2) against an independent
// behavioural model, the stated fairness bounds, and an ablation.
//
// The environment reproduces what the control unit does to the arbiter:
//   * every slot buffers an instruction of an execution class; a slot REQUESTS only if its
//     hazard has cleared AND its class is ready; a class goes busy for a random window right
//     after one of its instructions is granted (non-retracting ready, assumption D1);
//   * hazards come in two kinds (memory result / register result) and raise stall_mem / stall_dep
//     while the slot waits;  barrier pressure, barrier release, load flag, class headroom vary;
//   * the configuration changes every few thousand cycles (random weights, adversarial weights,
//     guards on/off) - only STATIC phases are checked against the bounds.
//
// Checks per cycle
//   exact grant vs model | one-hot | grant subset of req | work conserving
//   urgent override: a warp-urgent candidate is always served before any non-urgent one
//   lag[i]  <= fair_limit + N         (grants lost while a candidate; guard on, fair_limit >= N+3)
//   clsbyp[c] <= cls_limit + N + 2    (consecutive bypasses of a class that has a candidate)
// ABLATION phase (guards OFF, compute-first weights): memory-class slots MUST starve past the
// bound - this proves the bound checks above are not vacuous and the guard is what provides them.
// ============================================================================
`timescale 1ns/1ps
module tb_unit_aware;
  import sfx_simt_pkg::*;
  parameter int N      = 8;
  parameter int CYCLES = 200000;
  localparam int NMEM  = (N / 4 > 1) ? N / 4 : 1;   // memory-class slots in the ablation / compute-first scenarios

  logic clk = 0;
  logic rst_n = 0;
  always #5 clk = ~clk;

  sfx_sched_cfg_t           cfg;
  logic [N-1:0]             req, wait_en, alloc, is_ld, stall_mem, stall_dep, bar_rel;
  logic [N-1:0][1:0]        cls, bar_press;
  logic [3:0][CAP_W-1:0]    cap;
  logic [N-1:0]             grant, dbg_urgent;
  logic [3:0]               dbg_cls_urgent;

  sfx_aware_arb #(.N(N)) u_dut (
    .clk(clk), .rst_n(rst_n), .cfg(cfg), .req(req), .wait_en(wait_en), .alloc(alloc), .cls(cls),
    .is_ld(is_ld), .stall_mem(stall_mem), .stall_dep(stall_dep), .bar_press(bar_press), .bar_rel(bar_rel),
    .cap(cap), .grant(grant), .dbg_urgent(dbg_urgent), .dbg_cls_urgent(dbg_cls_urgent));

  // ---------------- model state ----------------
  int          m_ptr;
  int          m_wcnt [N];
  int          m_cb   [4];
  bit          m_md   [N];
  bit          m_dd   [N];
  // ---------------- environment ----------------
  int          busy   [4];
  int          hz     [N];
  bit          hzmem  [N];
  int          cur_cls [N];
  bit          resident [N];
  bit          ready_i  [N];
  int          lag    [N];
  int          clsbyp [4];
  longint      grants_per_slot [N];
  longint      grants_per_cls  [4];
  int unsigned rng;
  int          errors, max_lag, max_clsbyp, total_grants;
  int          checked_lag_cycles;
  int          max_over;               // max (lost grants - fair_limit) in guarded phases; derived bound: N-1
  bit          check_bounds;           // static legal phase: bound assertions active
  bit          ablation;               // guards off: expect starvation
  int          abl_max_lag;
  int          urgent_override_checks, cls_urgent_grants;
  bit          chk_fixed;
  logic [N-1:0] fixed_exp;

  function automatic int unsigned rnd();
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng;
  endfunction

  // ---------------- behavioural model ----------------
  function automatic int w_of_cls(input int c);
    case (c)
      0: return int'(cfg.w_cls_alu);
      1: return int'(cfg.w_cls_mem);
      2: return int'(cfg.w_cls_br);
      default: return int'(cfg.w_cls_ctrl);
    endcase
  endfunction

  function automatic int m_score(input int i);
    int s;
    s = w_of_cls(int'(cls[i]));
    if (is_ld[i])     s += int'(cfg.w_ld);
    if (m_md[i])      s += int'(cfg.w_memdep);
    if (m_dd[i])      s += int'(cfg.w_dep);
    if (bar_rel[i])   s += int'(cfg.w_rel);
    s += int'(bar_press[i]) * int'(cfg.w_bar);
    s += int'(cap[cls[i]]) * int'(cfg.w_cap);
    s += ((m_wcnt[i] > 3) ? 3 : m_wcnt[i]) * int'(cfg.w_age);
    return s;
  endfunction

  function automatic bit m_urg(input int i);
    return req[i] && cfg.fair_limit != 0 && m_wcnt[i] >= int'(cfg.fair_limit);
  endfunction
  function automatic bit m_curg(input int i);
    return req[i] && cfg.cls_limit != 0 && m_cb[cls[i]] >= int'(cfg.cls_limit);
  endfunction

  function automatic int m_key(input int i);
    int tier, prim;
    if (m_urg(i))       begin tier = 3; prim = m_wcnt[i]; end
    else if (m_curg(i)) begin tier = 2; prim = m_cb[cls[i]]; end
    else                begin tier = 1; prim = 0; end
    return (tier << 14) | (prim << 7) | m_score(i);
  endfunction

  function automatic logic [N-1:0] model_grant();
    logic [N-1:0] g = '0;
    int best = -1, bi = -1;
    for (int p = 0; p < N; p++) begin
      int idx = (m_ptr + p) % N;
      if (req[idx]) begin
        int k = m_key(idx);
        if (k > best) begin best = k; bi = idx; end
      end
    end
    if (bi >= 0) g[bi] = 1'b1;
    return g;
  endfunction

  // one clock: compare, check theorems, advance model + environment
  task automatic step(input string phase);
    logic [N-1:0] e;
    logic [3:0]   has_c, gr_c;
    logic [N-1:0] req_urg_model;
    bit fire;
    #4;
    e = model_grant();
    if (grant !== e) begin $display("[AWARE-UNIT] FAIL %s grant %b expected %b (req %b)", phase, grant, e, req); errors++; end
    if (chk_fixed && grant !== fixed_exp) begin $display("[AWARE-UNIT] FAIL directed %s grant %b expected %b", phase, grant, fixed_exp); errors++; end
    if (!$onehot0(grant)) begin $display("[AWARE-UNIT] FAIL grant not one-hot"); errors++; end
    if ((grant & ~req) != 0) begin $display("[AWARE-UNIT] FAIL grant outside request"); errors++; end
    if ((grant != 0) != (req != 0)) begin $display("[AWARE-UNIT] FAIL not work-conserving"); errors++; end
    // dbg flags vs model
    for (int i = 0; i < N; i++) if (dbg_urgent[i] !== m_urg(i)) begin $display("[AWARE-UNIT] FAIL dbg_urgent[%0d]", i); errors++; end
    // urgent override: if any warp-urgent candidate exists the grant is warp-urgent
    req_urg_model = '0;
    for (int i = 0; i < N; i++) req_urg_model[i] = m_urg(i);
    if (req_urg_model != 0) begin
      urgent_override_checks++;
      if ((grant & req_urg_model) == 0) begin $display("[AWARE-UNIT] FAIL %s warp-urgent candidate bypassed", phase); errors++; end
    end
    fire = (grant != 0);
    has_c = '0; gr_c = '0;
    for (int i = 0; i < N; i++) begin
      if (req[i])   has_c[cls[i]] = 1'b1;
      if (grant[i]) gr_c[cls[i]]  = 1'b1;
    end
    if (fire && (grant & req_urg_model) == 0) for (int c = 0; c < 4; c++) if (gr_c[c] && m_cb[c] >= int'(cfg.cls_limit) && cfg.cls_limit != 0) cls_urgent_grants++;

    // ---- bounded wait / class bypass (environment view: reset on own-state change) ----
    for (int i = 0; i < N; i++) begin
      if (!resident[i] || !ready_i[i] || hz[i] > 0 || grant[i]) lag[i] = 0;
      else if (req[i] && fire) begin
        lag[i]++;
        if (check_bounds && lag[i] > max_lag) max_lag = lag[i];
        if (check_bounds && cfg.fair_limit != 0 && lag[i] - int'(cfg.fair_limit) > max_over) max_over = lag[i] - int'(cfg.fair_limit);
        if (ablation && lag[i] > abl_max_lag) abl_max_lag = lag[i];
        if (check_bounds && cfg.fair_limit != 0 && lag[i] > int'(cfg.fair_limit) + N) begin
          $display("[AWARE-UNIT] FAIL %s starvation: slot %0d lag %0d > %0d", phase, i, lag[i], int'(cfg.fair_limit) + N); errors++;
        end
        checked_lag_cycles++;
      end
    end
    for (int c = 0; c < 4; c++) begin
      bit any_requester = 0;
      for (int i = 0; i < N; i++) if (resident[i] && ready_i[i] && hz[i] == 0 && cur_cls[i] == c) any_requester = 1;
      if (gr_c[c] || !any_requester) clsbyp[c] = 0;
      else if (has_c[c] && fire) begin
        clsbyp[c]++;
        if (check_bounds && clsbyp[c] > max_clsbyp) max_clsbyp = clsbyp[c];
        if (check_bounds && cfg.fair_limit != 0 && cfg.cls_limit != 0 && clsbyp[c] > int'(cfg.cls_limit) + N + 2) begin
          $display("[AWARE-UNIT] FAIL %s class %0d bypassed %0d > %0d", phase, c, clsbyp[c], int'(cfg.cls_limit) + N + 2); errors++;
        end
      end
    end
    if (fire) begin total_grants++; for (int c = 0; c < 4; c++) if (gr_c[c]) grants_per_cls[c]++; end
    for (int i = 0; i < N; i++) if (grant[i]) grants_per_slot[i]++;

    // ---- advance the model exactly as the RTL registers will ----
    for (int i = 0; i < N; i++) begin
      if (!wait_en[i] || grant[i] || alloc[i]) m_wcnt[i] = 0;
      else if (fire && req[i] && m_wcnt[i] < 127) m_wcnt[i]++;
      if (alloc[i] || grant[i]) begin m_md[i] = 0; m_dd[i] = 0; end
      else begin
        if (stall_mem[i]) m_md[i] = 1;
        if (stall_dep[i]) m_dd[i] = 1;
      end
    end
    for (int c = 0; c < 4; c++) begin
      if (gr_c[c]) m_cb[c] = 0;
      else if (fire && has_c[c] && m_cb[c] < 15) m_cb[c]++;
    end
    if (fire) for (int i = 0; i < N; i++) if (grant[i]) m_ptr = (i + 1) % N;

    // ---- environment reacts ----
    for (int c = 0; c < 4; c++) if (busy[c] > 0) busy[c]--;
    for (int i = 0; i < N; i++) if (hz[i] > 0) hz[i]--;
    for (int i = 0; i < N; i++) if (grant[i]) begin
      int pick = int'(rnd() % 8);
      if (cur_cls[i] != 3)
        busy[cur_cls[i]] = (pick < 3) ? 0 : (pick < 5) ? 3 : (pick < 7) ? 6 : (rnd() % 2 ? 20 : 40);
      cur_cls[i] = int'(rnd() % 4);
      if (rnd() % 100 < 25) begin hz[i] = 1 + int'(rnd() % 8); hzmem[i] = (rnd() % 2 == 0); end
      ready_i[i] = (rnd() % 100 < 92);
    end
    @(negedge clk);
  endtask

  task automatic drive_env(input logic [N-1:0] a, input int pr);
    for (int i = 0; i < N; i++) begin
      req[i]       = resident[i] && ready_i[i] && hz[i] == 0 && (cur_cls[i] == 3 || busy[cur_cls[i]] == 0) && (rnd() % 100 < pr);
      wait_en[i]   = resident[i] && ready_i[i];
      cls[i]       = 2'(cur_cls[i]);
      is_ld[i]     = (cur_cls[i] == 1) && (rnd() % 100 < 60);
      stall_mem[i] = resident[i] && ready_i[i] && hz[i] > 0 && hzmem[i];
      stall_dep[i] = resident[i] && ready_i[i] && hz[i] > 0 && !hzmem[i];
      if (rnd() % 100 < 4) bar_press[i] = 2'(rnd() % 4);
      bar_rel[i]   = (rnd() % 100 < 3);
    end
    for (int c = 0; c < 4; c++)
      cap[c] = (c == 3) ? 2'd3 : (busy[c] > 0) ? 2'd0 : 2'(1 + rnd() % 3);
    alloc = a;
  endtask

  function automatic sfx_sched_cfg_t rand_cfg(input int style);
    sfx_sched_cfg_t c;
    int f2 = (2 * N > N + 3) ? 2 * N : N + 3;
    int fls [3] = '{N + 3, (f2 > 63) ? 63 : f2, 63};
    int cls_ [5] = '{0, 1, 2, 6, 15};
    c = sfx_sched_cfg_default(N);
    case (style)
      0: ;                                              // defaults
      1: begin                                          // random weights, guards on
           c.w_cls_alu = 3'(rnd()); c.w_cls_mem = 3'(rnd()); c.w_cls_br = 3'(rnd()); c.w_cls_ctrl = 3'(rnd());
           c.w_ld = 3'(rnd()); c.w_memdep = 3'(rnd()); c.w_dep = 3'(rnd()); c.w_bar = 3'(rnd());
           c.w_rel = 3'(rnd()); c.w_cap = 3'(rnd()); c.w_age = 3'(rnd());
           c.fair_limit = 6'(fls[rnd() % 3]); c.cls_limit = 4'(cls_[rnd() % 5]);
         end
      2: begin                                          // adversarial: compute first, memory last, guards on
           c.w_cls_alu = 3'd7; c.w_cls_mem = 3'd0; c.w_cls_br = 3'd0; c.w_cls_ctrl = 3'd0;
           c.w_ld = 3'd0; c.w_memdep = 3'd0; c.w_dep = 3'd0; c.w_bar = 3'd0; c.w_rel = 3'd0; c.w_cap = 3'd0; c.w_age = 3'd0;
         end
      3: begin                                          // all weights zero: degenerates to rotating priority + guards
           c.w_cls_alu = 0; c.w_cls_mem = 0; c.w_cls_br = 0; c.w_cls_ctrl = 0; c.w_ld = 0; c.w_memdep = 0;
           c.w_dep = 0; c.w_bar = 0; c.w_rel = 0; c.w_cap = 0; c.w_age = 0;
         end
      default: begin                                    // everything maximal
           c.w_cls_alu = 7; c.w_cls_mem = 7; c.w_cls_br = 7; c.w_cls_ctrl = 7; c.w_ld = 7; c.w_memdep = 7;
           c.w_dep = 7; c.w_bar = 7; c.w_rel = 7; c.w_cap = 7; c.w_age = 7;
         end
    endcase
    return c;
  endfunction

  task automatic fresh_state_checks();
    for (int i = 0; i < N; i++) lag[i] = 0;
    for (int c = 0; c < 4; c++) clsbyp[c] = 0;
  endtask

  initial begin
    rng = 32'hA11CE5ED + N; errors = 0; max_lag = 0; max_over = -1000; max_clsbyp = 0; total_grants = 0; checked_lag_cycles = 0;
    check_bounds = 0; ablation = 0; abl_max_lag = 0; chk_fixed = 0; fixed_exp = '0; urgent_override_checks = 0; cls_urgent_grants = 0;
    m_ptr = 0;
    for (int c = 0; c < 4; c++) begin m_cb[c] = 0; busy[c] = 0; clsbyp[c] = 0; grants_per_cls[c] = 0; end
    for (int i = 0; i < N; i++) begin
      m_wcnt[i] = 0; m_md[i] = 0; m_dd[i] = 0; lag[i] = 0; hz[i] = 0; hzmem[i] = 0; cur_cls[i] = 0;
      resident[i] = 0; ready_i[i] = 0; grants_per_slot[i] = 0; bar_press[i] = 0;
    end
    cfg = rand_cfg(0);
    req = '0; wait_en = '0; alloc = '0; cls = '0; is_ld = '0; stall_mem = '0; stall_dep = '0; bar_rel = '0; cap = '0;
    repeat (3) @(posedge clk);
    rst_n = 1;
    @(negedge clk);

    // ---------- directed 1: allocate every slot in one cycle ----------
    for (int i = 0; i < N; i++) begin resident[i] = 1; ready_i[i] = 1; end
    drive_env('1, 100); req = '0; wait_en = '0; alloc = '1; step("alloc-all");

    // ---------- directed 2: all weights zero, everything requests, one class -> plain rotation ----------
    cfg = rand_cfg(3);
    for (int k = 0; k < 3 * N; k++) begin
      req = '1; wait_en = '1; alloc = '0;
      for (int i = 0; i < N; i++) begin cls[i] = 2'(0); is_ld[i] = 0; stall_mem[i] = 0; stall_dep[i] = 0; bar_rel[i] = 0; bar_press[i] = 0; end
      for (int c = 0; c < 4; c++) cap[c] = 2'd3;
      chk_fixed = 1; fixed_exp = N'(1) << (k % N);              // 0,1,2,..,N-1,0,...
      step("rotation");
      chk_fixed = 0;
    end

    // ---------- directed 3: a single feature decides (the load wins every cycle) ----------
    cfg = rand_cfg(3); cfg.w_ld = 3'd5; cfg.fair_limit = 6'd0; cfg.cls_limit = 4'd0;
    for (int k = 0; k < 6; k++) begin
      req = '1; wait_en = '1; alloc = '0;
      for (int i = 0; i < N; i++) begin cls[i] = 2'd1; is_ld[i] = (i == N/2); stall_mem[i] = 0; stall_dep[i] = 0; bar_rel[i] = 0; bar_press[i] = 0; end
      for (int c = 0; c < 4; c++) cap[c] = 2'd3;
      chk_fixed = 1; fixed_exp = N'(1) << (N/2);
      step("load-first");
      chk_fixed = 0;
    end

    // ---------- directed 4: barrier-release bonus and straggler boost beat class preference ----------
    cfg = rand_cfg(3); cfg.w_rel = 3'd7; cfg.w_cls_alu = 3'd3; cfg.fair_limit = 6'd0; cfg.cls_limit = 4'd0;
    for (int k = 0; k < 4; k++) begin
      req = '1; wait_en = '1; alloc = '0;
      for (int i = 0; i < N; i++) begin cls[i] = 2'd0; is_ld[i] = 0; stall_mem[i] = 0; stall_dep[i] = 0; bar_rel[i] = (i == 1); bar_press[i] = 0; end
      for (int c = 0; c < 4; c++) cap[c] = 2'd3;
      chk_fixed = 1; fixed_exp = N'(1) << 1;
      step("barrier-release-first");
      chk_fixed = 0;
    end
    cfg = rand_cfg(3); cfg.w_bar = 3'd2; cfg.fair_limit = 6'd0; cfg.cls_limit = 4'd0;
    for (int k = 0; k < 4; k++) begin
      req = '1; wait_en = '1; alloc = '0;
      for (int i = 0; i < N; i++) begin cls[i] = 2'd0; is_ld[i] = 0; stall_mem[i] = 0; stall_dep[i] = 0; bar_rel[i] = 0; bar_press[i] = (i == N-1) ? 2'd2 : 2'd0; end
      for (int c = 0; c < 4; c++) cap[c] = 2'd3;
      chk_fixed = 1; fixed_exp = N'(1) << (N-1);
      step("straggler-first");
      chk_fixed = 0;
    end

    // ---------- directed 5: urgent warps are served longest-waiting first ----------
    // Phase 1 (guards off): slot i joins at cycle i; the high-score slots keep winning, the others starve and
    // accumulate DIFFERENT lost-grant counts (earlier joiners have more).  Phase 2: fair_limit is lowered to N+3,
    // so several starved slots are urgent at the same moment; the one with the largest count must be served first
    // although a later joiner may have the higher score.  Checked cycle by cycle by the exact model (this is the
    // ordering the bounded-wait argument relies on; a mutant that drops it must be caught).
    cfg = rand_cfg(3); cfg.w_bar = 3'd1; cfg.fair_limit = 6'd0; cfg.cls_limit = 4'd0;
    begin
      int multi_urgent = 0;
      for (int k = -1; k < 9 * N + 40; k++) begin
        if (k == 5 * N) cfg.fair_limit = 6'(N + 3);                 // phase 2
        for (int i = 0; i < N; i++) begin
          bit joined = (k >= 0) && (k >= i);                        // k = -1: everyone idle, clears all counters
          req[i] = joined; wait_en[i] = joined; cls[i] = 2'd0; is_ld[i] = 0; stall_mem[i] = 0; stall_dep[i] = 0; bar_rel[i] = 0;
          bar_press[i] = 2'((i * 3) % 4);
        end
        for (int c = 0; c < 4; c++) cap[c] = 2'd3;
        alloc = '0;
        step("urgent-order");
        if ($countones(dbg_urgent) > 1) multi_urgent++;
      end
      if (N >= 4 && multi_urgent == 0) begin $display("[AWARE-UNIT] FAIL urgent-order scenario never had two urgent warps at once"); errors++; end
    end

    // ---------- randomised phases ----------
    for (int ph = 0; ph < CYCLES / 4000; ph++) begin
      int style = (ph % 7 == 0) ? 0 : (ph % 7 == 1) ? 2 : (ph % 7 == 2) ? 4 : 1;
      cfg = rand_cfg(style);
      check_bounds = 1;
      fresh_state_checks();
      for (int cyc = 0; cyc < 4000; cyc++) begin
        logic [N-1:0] n_alloc;
        int pr = ((cyc / 700) % 3 == 0) ? 100 : ((cyc / 700) % 3 == 1) ? 85 : 55;
        n_alloc = '0;
        for (int i = 0; i < N; i++) begin
          if (!resident[i] && rnd() % 100 < 4) begin
            n_alloc[i] = 1'b1; resident[i] = 1'b1; ready_i[i] = 0; hz[i] = 0; cur_cls[i] = int'(rnd() % 4);
          end else if (resident[i] && rnd() % 100 < 1) begin
            resident[i] = 1'b0; ready_i[i] = 0;
          end else if (resident[i] && !ready_i[i] && rnd() % 100 < 15) ready_i[i] = 1'b1;
        end
        drive_env(n_alloc, pr);
        for (int i = 0; i < N; i++) if (n_alloc[i]) begin req[i] = 1'b0; wait_en[i] = 1'b0; end
        step("random");
      end
    end

    // ---------- ablation: guards OFF + compute-first weights: memory slots must starve ----------
    check_bounds = 0; ablation = 1;
    cfg = rand_cfg(2); cfg.fair_limit = 6'd0; cfg.cls_limit = 4'd0;
    fresh_state_checks();
    for (int i = 0; i < N; i++) begin resident[i] = 1; ready_i[i] = 1; hz[i] = 0; cur_cls[i] = (i < NMEM) ? 1 : 0; end
    for (int c = 0; c < 4; c++) busy[c] = 0;
    begin
      longint mem_before = grants_per_cls[1];
      for (int k = 0; k < 3000; k++) begin
        for (int i = 0; i < N; i++) begin
          req[i] = resident[i] && (cur_cls[i] != 1 || busy[1] == 0);
          wait_en[i] = 1'b1; cls[i] = 2'(cur_cls[i]); is_ld[i] = (cur_cls[i] == 1); stall_mem[i] = 0; stall_dep[i] = 0; bar_rel[i] = 0;
          bar_press[i] = 0; hz[i] = 0; ready_i[i] = 1;
        end
        for (int c = 0; c < 4; c++) cap[c] = 2'd3;
        alloc = '0;
        step("ablation");
        for (int i = 0; i < N; i++) cur_cls[i] = (i < NMEM) ? 1 : 0;
      end
      $display("[AWARE-UNIT] ablation (guards off, compute-first): memory-class grants %0d in 3000 cycles, max lost grants %0d (guarded bound would be %0d)",
               grants_per_cls[1] - mem_before, abl_max_lag, int'(sfx_sched_cfg_default(N).fair_limit) + N);
      if (abl_max_lag <= int'(sfx_sched_cfg_default(N).fair_limit) + N) begin
        $display("[AWARE-UNIT] FAIL ablation did not starve: the bound checks would be vacuous"); errors++;
      end
    end
    // ---------- same scenario with the guards ON: bounded, memory work is served ----------
    check_bounds = 1; ablation = 0;
    cfg = rand_cfg(2);
    fresh_state_checks();
    for (int c = 0; c < 4; c++) busy[c] = 0;
    begin
      longint mem_before = grants_per_cls[1];
      for (int k = 0; k < 3000; k++) begin
        for (int i = 0; i < N; i++) begin
          req[i] = resident[i] && (cur_cls[i] != 1 || busy[1] == 0);
          wait_en[i] = 1'b1; cls[i] = 2'(cur_cls[i]); is_ld[i] = (cur_cls[i] == 1); stall_mem[i] = 0; stall_dep[i] = 0; bar_rel[i] = 0;
          bar_press[i] = 0; hz[i] = 0; ready_i[i] = 1;
        end
        for (int c = 0; c < 4; c++) cap[c] = 2'd3;
        alloc = '0;
        step("guarded-compute-first");
        for (int i = 0; i < N; i++) cur_cls[i] = (i < NMEM) ? 1 : 0;
      end
      $display("[AWARE-UNIT] same scenario, guards on (fair_limit %0d): memory-class grants %0d in 3000 cycles",
               cfg.fair_limit, grants_per_cls[1] - mem_before);
      if (grants_per_cls[1] - mem_before == 0) begin $display("[AWARE-UNIT] FAIL memory class never served with guards on"); errors++; end
    end

    $display("[AWARE-UNIT] N=%0d: %0d grants; guarded phases: max lost grants beyond fair_limit = %0d (derived bound N-1 = %0d, asserted N = %0d); max class bypass %0d; %0d urgent-override checks, %0d class-urgent grants",
             N, total_grants, max_over, N - 1, N, max_clsbyp, urgent_override_checks, cls_urgent_grants);
    if (max_over > N - 1) begin $display("[AWARE-UNIT] FAIL lost grants beyond fair_limit exceed the derived bound N-1"); errors++; end
    if (urgent_override_checks == 0) begin $display("[AWARE-UNIT] FAIL warp guard never exercised"); errors++; end
    if (cls_urgent_grants == 0)      begin $display("[AWARE-UNIT] FAIL class guard never exercised"); errors++; end
    if (errors == 0) $display("[AWARE-UNIT] PASS N=%0d", N);
    else             $display("[AWARE-UNIT] FAILED with %0d errors", errors);
    if (errors != 0) $fatal(1, "aware arbiter unit test failed");
    $finish;
  end
endmodule
