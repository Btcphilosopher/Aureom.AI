// ============================================================================
// SilicaFlux warp scheduler and SIMT control unit
//
// See docs/architecture.md (micro-architecture + interfaces),
//     docs/divergence_model.md (reconvergence model),
//     docs/isa.md (instruction set).
//
// One instruction is fetched and one instruction issued per cycle.  The unit
// keeps NUM_WARPS resident warp contexts grouped into at most NUM_WGS
// workgroups, and handles: program counters, ready/blocked states, register
// dependency tracking (scoreboard), execution masks, branch divergence and
// reconvergence (per-warp stack), workgroup barriers, faults and kernel
// completion.  Operand fetch, ALUs, load/store and the register file live in
// the downstream backend (see be_* / cmp_* ports and docs/architecture.md for
// the contract).
// ============================================================================
`include "sfx_defs.svh"
module sfx_simt_ctrl
  import sfx_simt_pkg::*;
#(
  parameter int NUM_WARPS      = 8,      // resident warp slots (power of two, >= 2)
  parameter int NUM_WGS        = 4,      // resident workgroup slots (<= NUM_WARPS)
  parameter int WARP_SIZE      = 32,     // lanes per warp (power of two)
  parameter int PC_W           = 16,     // program counter width (instruction words)
  parameter int STACK_DEPTH    = 8,      // reconvergence stack entries per warp
  parameter int MAX_INFLIGHT   = 15,     // issued-not-completed instructions per warp
  parameter int SCHED_POLICY   = 0,      // 0 round-robin, 1 age-based (oldest first)
  parameter int STARVE_LIMIT   = 16,     // age policy starvation guard (>= NUM_WARPS, 0 = off)
  parameter bit STRICT_BAR_PC  = 1'b0,   // barrier episode must use a single BAR pc
  parameter int WG_ID_W        = 8,
  parameter int CNT_W          = 32,
  parameter int LIVENESS_LIMIT = 8192    // simulation-only progress watchdog (cycles)
) (
  input  logic                  clk,
  input  logic                  rst_n,

  // ---------------- host / dispatcher: workgroup launch ----------------
  input  logic                  launch_valid,
  output logic                  launch_ready,
  input  logic [WG_ID_W-1:0]    launch_wg_id,
  input  logic [$clog2(NUM_WARPS*WARP_SIZE+1)-1:0] launch_nthreads,
  input  logic [PC_W-1:0]       launch_pc,
  input  logic                  launch_last,     // last workgroup of the kernel
  input  logic                  kernel_clear,    // host: acknowledge done, clear status+counters
  output logic                  kernel_busy,
  output logic                  kernel_done,

  // ---------------- fault record (first fault, sticky) ----------------
  output logic                  fault_valid,
  output logic [3:0]            fault_code,
  output logic [WG_ID_W-1:0]    fault_wg_id,
  output logic [$clog2(NUM_WARPS)-1:0] fault_widx,
  output logic [PC_W-1:0]       fault_pc,
  output logic [8:0]            fault_mask,      // bit per fault code seen

  // ---------------- instruction memory ----------------
  output logic                  imem_req_valid,
  output logic [PC_W-1:0]       imem_req_pc,
  output logic [$clog2(NUM_WARPS)-1:0] imem_req_tag,
  input  logic                  imem_req_ready,
  input  logic                  imem_rsp_valid,
  input  logic [$clog2(NUM_WARPS)-1:0] imem_rsp_tag,
  input  logic [31:0]           imem_rsp_data,
  input  logic                  imem_rsp_err,

  // ---------------- backend issue ----------------
  output logic                  be_valid,        // instruction accepted by backend this cycle
  output logic [1:0]            be_cls,          // CLS_ALU / CLS_MEM / CLS_BR
  output logic [$clog2(NUM_WARPS)-1:0] be_warp,
  output logic [WG_ID_W-1:0]    be_wg_id,
  output logic [$clog2(NUM_WARPS)-1:0] be_widx,  // warp index inside the workgroup
  output logic [PC_W-1:0]       be_pc,
  output logic [31:0]           be_instr,
  output logic [WARP_SIZE-1:0]  be_mask,
  input  logic [2:0]            be_rdy,          // per-class credit [ALU, MEM, BR]

  // ---------------- backend completion (one per cycle) ----------------
  input  logic                  cmp_valid,
  input  logic [$clog2(NUM_WARPS)-1:0] cmp_warp,
  input  logic                  cmp_wr,          // clears scoreboard bit cmp_rd
  input  logic [4:0]            cmp_rd,
  input  logic                  cmp_mem,         // memory op completed
  input  logic                  cmp_br,          // branch outcome
  input  logic [WARP_SIZE-1:0]  cmp_taken,

  // ---------------- architectural event trace ----------------
  output logic                  iss_valid,       // an instruction issued (all classes)
  output logic [$clog2(NUM_WARPS)-1:0] iss_warp,
  output logic [WG_ID_W-1:0]    iss_wg_id,
  output logic [$clog2(NUM_WARPS)-1:0] iss_widx,
  output logic [PC_W-1:0]       iss_pc,
  output logic [WARP_SIZE-1:0]  iss_mask,
  output logic [31:0]           iss_instr,
  output logic                  exit_valid,      // a warp retired (EXIT)
  output logic [$clog2(NUM_WARPS)-1:0] exit_warp,
  output logic [WG_ID_W-1:0]    exit_wg_id,
  output logic [$clog2(NUM_WARPS)-1:0] exit_widx,

  // ---------------- observability ----------------
  output logic [NUM_WARPS-1:0][2:0] dbg_wstate,

  // ---------------- performance counters ----------------
  output logic [CNT_W-1:0] cnt_cycles,
  output logic [CNT_W-1:0] cnt_issued,
  output logic [CNT_W-1:0] cnt_retired,
  output logic [CNT_W-1:0] cnt_idle,
  output logic [CNT_W-1:0] cnt_idle_nowarp,
  output logic [CNT_W-1:0] cnt_idle_be,
  output logic [CNT_W-1:0] cnt_idle_mem,
  output logic [CNT_W-1:0] cnt_idle_dep,
  output logic [CNT_W-1:0] cnt_idle_br,
  output logic [CNT_W-1:0] cnt_idle_fetch,
  output logic [CNT_W-1:0] cnt_idle_bar,
  output logic [CNT_W-1:0] cnt_idle_other,
  output logic [CNT_W-1:0] cnt_wc_resident,
  output logic [CNT_W-1:0] cnt_wc_issue,
  output logic [CNT_W-1:0] cnt_wc_notsel,
  output logic [CNT_W-1:0] cnt_wc_dep,
  output logic [CNT_W-1:0] cnt_wc_mem,
  output logic [CNT_W-1:0] cnt_wc_bar,
  output logic [CNT_W-1:0] cnt_wc_br,
  output logic [CNT_W-1:0] cnt_wc_fetch,
  output logic [CNT_W-1:0] cnt_wc_be,
  output logic [CNT_W-1:0] cnt_wc_drain,
  output logic [CNT_W-1:0] cnt_div_branches,
  output logic [CNT_W-1:0] cnt_bar_episodes,
  output logic [CNT_W-1:0] cnt_faults,
  output logic [CNT_W-1:0] cnt_proto_err,
  output logic [$clog2(STACK_DEPTH+1)-1:0] cnt_stack_hwm,
  output logic [NUM_WARPS-1:0][CNT_W-1:0] cnt_warp_issued
);

  // ==========================================================================
  // Elaboration-time sanity
  // ==========================================================================
  localparam int WID_W = $clog2(NUM_WARPS);
  localparam int GID_W = (NUM_WGS > 1) ? $clog2(NUM_WGS) : 1;
  localparam int SP_W  = $clog2(STACK_DEPTH + 1);
  localparam int SIW  = $clog2(STACK_DEPTH);          // stack array index width
  localparam int INF_W = $clog2(MAX_INFLIGHT + 1);
  localparam int NT_W  = $clog2(NUM_WARPS * WARP_SIZE + 1);

  initial begin
    if (NUM_WARPS < 2 || (NUM_WARPS & (NUM_WARPS - 1)) != 0)
      $fatal(1, "sfx_simt_ctrl: NUM_WARPS must be a power of two >= 2");
    if (WARP_SIZE < 2 || (WARP_SIZE & (WARP_SIZE - 1)) != 0)
      $fatal(1, "sfx_simt_ctrl: WARP_SIZE must be a power of two >= 2");
    if (NUM_WGS < 1 || NUM_WGS > NUM_WARPS)
      $fatal(1, "sfx_simt_ctrl: 1 <= NUM_WGS <= NUM_WARPS required");
    if (SCHED_POLICY == 1 && STARVE_LIMIT != 0 && STARVE_LIMIT < NUM_WARPS)
      $fatal(1, "sfx_simt_ctrl: STARVE_LIMIT must be 0 or >= NUM_WARPS");
    if (STACK_DEPTH < 2) $fatal(1, "sfx_simt_ctrl: STACK_DEPTH must be >= 2");
  end

  // ==========================================================================
  // State
  // ==========================================================================
  // ---- warp contexts ----
  logic [2:0]            wstate [NUM_WARPS];
  logic [PC_W-1:0]       wpc    [NUM_WARPS];   // pc of the next instruction
  logic [WARP_SIZE-1:0]  wmask  [NUM_WARPS];   // current active mask
  logic [WARP_SIZE-1:0]  wlmask [NUM_WARPS];   // launch mask (lanes that exist)
  logic [PC_W-1:0]       wrpc   [NUM_WARPS];   // reconvergence pc of the current context (valid iff wsp != 0)
  logic [SP_W-1:0]       wsp    [NUM_WARPS];   // stack depth
  logic [31:0]           wib    [NUM_WARPS];   // instruction buffer
  logic [GID_W-1:0]      wwg    [NUM_WARPS];   // workgroup slot
  logic [WID_W-1:0]      widx_q [NUM_WARPS];   // warp index inside workgroup
  logic [INF_W-1:0]      winf   [NUM_WARPS];   // issued-not-completed backend instructions
  logic [INF_W-1:0]      wmem   [NUM_WARPS];   // ... of which memory operations
  logic [NUM_WARPS-1:0]  fetch_pend;

  // ---- reconvergence stacks (suspended contexts) ----
  logic [PC_W-1:0]       stk_pc   [NUM_WARPS][STACK_DEPTH];
  logic [WARP_SIZE-1:0]  stk_mask [NUM_WARPS][STACK_DEPTH];
  logic [PC_W-1:0]       stk_rpc  [NUM_WARPS][STACK_DEPTH];

  // ---- workgroup slots ----
  logic [NUM_WGS-1:0]    gvalid;
  logic [NUM_WGS-1:0]    gabort;
  logic [WG_ID_W-1:0]    gid      [NUM_WGS];
  logic [NUM_WARPS-1:0]  gmembers [NUM_WGS];

  // ---- kernel ----
  logic k_active, k_last, k_done_q;

  // ---- fault record ----
  logic                  f_valid;
  logic [3:0]            f_code;
  logic [WG_ID_W-1:0]    f_wg;
  logic [WID_W-1:0]      f_widx;
  logic [PC_W-1:0]       f_pc;
  logic [8:0]            f_mask;

  // ==========================================================================
  // Launch / allocation
  // ==========================================================================
  logic [NUM_WARPS-1:0]  free_vec;
  int                    nfree;
  logic                  have_g;
  logic [GID_W-1:0]      free_g;
  logic                  size_ok;
  int                    need;
  logic                  launch_fire, alloc_ok, launch_fault_ev;
  logic [NUM_WARPS-1:0]  alloc_sel;
  logic [WARP_SIZE-1:0]  lmask_w [NUM_WARPS];
  int                    rank_w  [NUM_WARPS];
  logic [WARP_SIZE-1:0]  mask_last;
  int                    tl;
  logic                  clear_ok;

  always_comb begin
    nfree = 0;
    for (int w = 0; w < NUM_WARPS; w++) begin
      free_vec[w] = (wstate[w] == WS_FREE);
      nfree += int'(free_vec[w]);
    end
    have_g = 1'b0;
    free_g = '0;
    for (int g = NUM_WGS - 1; g >= 0; g--)
      if (!gvalid[g]) begin have_g = 1'b1; free_g = GID_W'(g); end

    size_ok = (launch_nthreads != '0) && (int'(launch_nthreads) <= NUM_WARPS * WARP_SIZE);
    need    = (int'(launch_nthreads) + WARP_SIZE - 1) / WARP_SIZE;
    tl      = int'(launch_nthreads) - (need - 1) * WARP_SIZE;
    mask_last = {WARP_SIZE{1'b1}};
    if (tl >= 1 && tl <= WARP_SIZE) mask_last = {WARP_SIZE{1'b1}} >> (WARP_SIZE - tl);

    clear_ok = kernel_clear && (gvalid == '0);
    launch_ready = !k_done_q && !k_last && !clear_ok &&
                   (!size_ok || (have_g && nfree >= need));
    launch_fire     = launch_valid && launch_ready;
    alloc_ok        = launch_fire && size_ok;
    launch_fault_ev = launch_fire && !size_ok;

    begin
      automatic int r = 0;
      for (int w = 0; w < NUM_WARPS; w++) begin
        rank_w[w]    = r;
        alloc_sel[w] = alloc_ok && free_vec[w] && (r < need);
        lmask_w[w]   = (r == need - 1) ? mask_last : {WARP_SIZE{1'b1}};
        if (free_vec[w]) r++;
      end
    end
  end

  // ==========================================================================
  // Per-warp decode, hazards, candidates
  // ==========================================================================
  dec_t                      dec [NUM_WARPS];
  logic [NUM_WARPS-1:0][4:0] q_rs1, q_rs2, q_rd;
  logic [NUM_WARPS-1:0]      q_use1, q_use2, q_wr;
  logic [NUM_WARPS-1:0]      hazard, hazard_mem;
  logic [NUM_WARPS-1:0][31:0] sb_pend;
  logic [NUM_WARPS-1:0]      w_ready, w_cand, w_be_blk, w_drain_blk, w_requester;
  logic [NUM_WARPS-1:0][1:0] w_cls;
  logic [NUM_WARPS-1:0]      grant;

  always_comb begin
    for (int w = 0; w < NUM_WARPS; w++) begin
      dec[w]    = sfx_decode(wib[w]);
      q_rs1[w]  = dec[w].rs1;
      q_rs2[w]  = dec[w].rs2;
      q_rd[w]   = dec[w].rd;
      q_use1[w] = dec[w].use1;
      q_use2[w] = dec[w].use2;
      q_wr[w]   = dec[w].wr && (dec[w].rd != 5'd0);
    end
  end

  always_comb begin
    for (int w = 0; w < NUM_WARPS; w++) begin
      automatic logic be_ok, inf_ok, drain_ok;
      w_ready[w] = (wstate[w] == WS_READY) && !gabort[wwg[w]];
      be_ok    = (dec[w].cls == CLS_CTRL) ? 1'b1 : be_rdy[dec[w].cls[1:0]];
      inf_ok   = (dec[w].cls == CLS_CTRL) ? 1'b1 : (winf[w] != INF_W'(MAX_INFLIGHT));
      drain_ok = (dec[w].op == OP_BAR)  ? (wmem[w] == '0) :
                 (dec[w].op == OP_EXIT) ? (winf[w] == '0) : 1'b1;
      w_cls[w]       = dec[w].cls;
      w_be_blk[w]    = !(be_ok && inf_ok);
      w_drain_blk[w] = !drain_ok;
      w_cand[w] = w_ready[w] && !hazard[w] && be_ok && inf_ok && drain_ok;
      // would be a candidate if its backend class were ready (used by the fairness checks)
      w_requester[w] = w_ready[w] && !hazard[w] && inf_ok && drain_ok;
    end
  end

  // set/clear events for the scoreboard
  logic                 sb_set_valid, sb_set_mem, sb_clr_valid;
  logic [WID_W-1:0]     sb_set_warp;
  logic [4:0]           sb_set_rd;

  sfx_scoreboard #(.NUM_WARPS(NUM_WARPS)) u_sb (
    .clk(clk), .rst_n(rst_n),
    .set_valid(sb_set_valid), .set_warp(sb_set_warp), .set_rd(sb_set_rd), .set_mem(sb_set_mem),
    .clr_valid(sb_clr_valid), .clr_warp(cmp_warp), .clr_rd(cmp_rd),
    .q_rs1(q_rs1), .q_rs2(q_rs2), .q_rd(q_rd), .q_use1(q_use1), .q_use2(q_use2), .q_wr(q_wr),
    .hazard(hazard), .hazard_mem(hazard_mem), .pend_o(sb_pend));

  // ==========================================================================
  // Warp scheduler
  // ==========================================================================
  sfx_warp_sched #(.N(NUM_WARPS), .POLICY(SCHED_POLICY), .STARVE_LIMIT(STARVE_LIMIT)) u_sched (
    .clk(clk), .rst_n(rst_n), .req(w_cand), .wait_en(w_ready), .alloc(alloc_sel), .cls(w_cls), .grant(grant));

  logic             gany;
  logic [WID_W-1:0] gw;
  always_comb begin
    gany = |grant;
    gw   = '0;
    for (int w = 0; w < NUM_WARPS; w++) if (grant[w]) gw = WID_W'(w);
  end

  // ==========================================================================
  // Issue stage: decode of the granted instruction
  // ==========================================================================
  dec_t                 s_dec;
  logic [31:0]          s_ib;
  logic [PC_W-1:0]      s_pc, s_rpc;
  logic [WARP_SIZE-1:0] s_mask;
  logic [SP_W-1:0]      s_sp;
  logic [GID_W-1:0]     s_g;
  logic signed [PC_W+1:0] s_f, s_t, s_npc_x;
  logic                 s_range_bad, s_needs_npc;
  logic [PC_W-1:0]      s_npc;
  logic [3:0]           iss_flt;
  logic                 iss_exec, iss_fault_ev;
  logic                 ev_be, ev_br, ev_bar, ev_exit, ev_ctrl_ret;
  logic                 fin_pop;
  logic [SP_W-1:0]      s_sp_m1;
  logic                 bar_mismatch;

  always_comb begin
    s_dec = dec[gw];
    s_ib  = wib[gw];
    s_pc  = wpc[gw];
    s_rpc = wrpc[gw];
    s_mask= wmask[gw];
    s_sp  = wsp[gw];
    s_g   = wwg[gw];
    s_f   = $signed({2'b00, s_pc}) + 1;
    s_t   = s_f + (PC_W+2)'($signed(s_ib[10:0]));
    s_npc_x = (s_dec.op == OP_JMP) ? s_t : s_f;
    s_range_bad = (s_npc_x[PC_W+1:PC_W] != '0);
    s_npc = s_npc_x[PC_W-1:0];
    // instructions whose next pc is computed here (everything but BRA/BRZ/EXIT)
    s_needs_npc = (s_dec.cls != CLS_BR) && (s_dec.op != OP_EXIT);
    s_sp_m1 = (s_sp == '0) ? '0 : s_sp - 1'b1;
    fin_pop = (s_sp != '0) && (s_npc == s_rpc);
  end

  always_comb begin
    iss_flt = FLT_NONE;
    if (gany) begin
      if      (s_dec.op == OP_BAR  && s_sp != '0)               iss_flt = FLT_DIV_BARRIER;
      else if (s_dec.op == OP_EXIT && s_sp != '0)               iss_flt = FLT_DIV_EXIT;
      else if (s_needs_npc && s_range_bad)                      iss_flt = FLT_PC_RANGE;
      else if (s_dec.op == OP_BAR && bar_mismatch)              iss_flt = FLT_BAR_PC;
    end
    iss_fault_ev = gany && (iss_flt != FLT_NONE);
    iss_exec     = gany && (iss_flt == FLT_NONE);

    ev_be   = iss_exec && (s_dec.cls != CLS_CTRL);
    ev_br   = iss_exec && (s_dec.cls == CLS_BR);
    ev_bar  = iss_exec && (s_dec.op == OP_BAR);
    ev_exit = iss_exec && (s_dec.op == OP_EXIT);
    ev_ctrl_ret = iss_exec && (s_dec.cls == CLS_CTRL);
  end

  // backend + trace outputs
  assign be_valid  = ev_be;
  assign be_cls    = s_dec.cls;
  assign be_warp   = gw;
  assign be_wg_id  = gid[s_g];
  assign be_widx   = widx_q[gw];
  assign be_pc     = s_pc;
  assign be_instr  = s_ib;
  assign be_mask   = s_mask;

  assign iss_valid = iss_exec;
  assign iss_warp  = gw;
  assign iss_wg_id = gid[s_g];
  assign iss_widx  = widx_q[gw];
  assign iss_pc    = s_pc;
  assign iss_mask  = s_mask;
  assign iss_instr = s_ib;

  assign exit_valid  = ev_exit;
  assign exit_warp   = gw;
  assign exit_wg_id  = gid[s_g];
  assign exit_widx   = widx_q[gw];

  // scoreboard set (ALU/MEM instructions with a destination)
  assign sb_set_valid = ev_be && (s_dec.cls != CLS_BR) && s_dec.wr && (s_dec.rd != 5'd0);
  assign sb_set_warp  = gw;
  assign sb_set_rd    = s_dec.rd;
  assign sb_set_mem   = s_dec.is_ld;

  // ==========================================================================
  // Fetch
  // ==========================================================================
  logic [NUM_WARPS-1:0] fetch_cand, fetch_grant;
  logic [WID_W-1:0]     fw;
  logic                 fetch_fire;

  always_comb begin
    for (int w = 0; w < NUM_WARPS; w++)
      fetch_cand[w] = (wstate[w] == WS_FETCH) && !gabort[wwg[w]];
  end
  sfx_rr_arb #(.N(NUM_WARPS)) u_fetch_arb (
    .clk(clk), .rst_n(rst_n), .req(fetch_cand), .adv(imem_req_ready), .grant(fetch_grant));
  always_comb begin
    fw = '0;
    for (int w = 0; w < NUM_WARPS; w++) if (fetch_grant[w]) fw = WID_W'(w);
  end
  assign imem_req_valid = |fetch_cand;
  assign imem_req_pc    = wpc[fw];
  assign imem_req_tag   = fw;
  assign fetch_fire     = imem_req_valid && imem_req_ready;

  // fetch response
  logic             rsp_ok, rsp_live, rsp_fault_ev;
  dec_t             rsp_dec;
  logic [3:0]       rsp_flt;
  logic [NUM_WARPS-1:0] rsp_hit;
  always_comb begin
    rsp_ok   = imem_rsp_valid && fetch_pend[imem_rsp_tag];
    rsp_live = rsp_ok && (wstate[imem_rsp_tag] == WS_FETCHING) && !gabort[wwg[imem_rsp_tag]];
    rsp_dec  = sfx_decode(imem_rsp_data);
    rsp_flt  = imem_rsp_err ? FLT_FETCH : (rsp_dec.illegal ? FLT_ILLEGAL : FLT_NONE);
    rsp_fault_ev = rsp_live && (rsp_flt != FLT_NONE);
    for (int w = 0; w < NUM_WARPS; w++)
      rsp_hit[w] = rsp_live && (int'(imem_rsp_tag) == w) && (rsp_flt == FLT_NONE);
  end

  // ==========================================================================
  // Completion port
  // ==========================================================================
  logic             cmp_ok, br_ev;
  logic [WID_W-1:0] bw;
  always_comb begin
    bw = cmp_warp;
    cmp_ok = cmp_valid
           && (wstate[cmp_warp] != WS_FREE)
           && (winf[cmp_warp] != '0)
           && !(cmp_br && (cmp_wr || cmp_mem))
           && (!cmp_wr  || (cmp_rd != 5'd0 && sb_pend[cmp_warp][cmp_rd]))
           && (!cmp_mem || (wmem[cmp_warp] != '0))
           && (!cmp_br  || (wstate[cmp_warp] == WS_WAIT_BR) || (wstate[cmp_warp] == WS_DRAIN));
    br_ev = cmp_ok && cmp_br && (wstate[cmp_warp] == WS_WAIT_BR) && !gabort[wwg[cmp_warp]];
  end
  assign sb_clr_valid = cmp_ok && cmp_wr;

  // ==========================================================================
  // Branch resolution (divergence unit)
  // ==========================================================================
  logic                 d_fault_range, d_fault_ovf, d_pop, d_diverge;
  logic [PC_W-1:0]      d_n_pc, d_n_rpc;
  logic [WARP_SIZE-1:0] d_n_mask;
  logic [SP_W-1:0]      d_n_sp;
  logic                 d_p0_en, d_p1_en;
  logic [PC_W-1:0]      d_p0_pc, d_p1_pc, d_p0_rpc, d_p1_rpc;
  logic [WARP_SIZE-1:0] d_p0_mask, d_p1_mask;
  logic                 br_fault_ev;
  logic [3:0]           br_flt;

  sfx_diverge_unit #(.PC_W(PC_W), .LANES(WARP_SIZE), .STACK_DEPTH(STACK_DEPTH)) u_div (
    .pc(wpc[bw]), .tgt_off(wib[bw][10:0]), .rpc_off(wib[bw][20:11]),
    .amask(wmask[bw]), .taken_raw(cmp_taken), .sp(wsp[bw]), .cur_rpc(wrpc[bw]),
    .fault_range(d_fault_range), .fault_ovf(d_fault_ovf), .pop(d_pop), .diverge(d_diverge),
    .n_pc(d_n_pc), .n_mask(d_n_mask), .n_rpc(d_n_rpc), .n_sp(d_n_sp),
    .p0_en(d_p0_en), .p0_pc(d_p0_pc), .p0_mask(d_p0_mask), .p0_rpc(d_p0_rpc),
    .p1_en(d_p1_en), .p1_pc(d_p1_pc), .p1_mask(d_p1_mask), .p1_rpc(d_p1_rpc));

  always_comb begin
    br_flt      = d_fault_range ? FLT_PC_RANGE : (d_fault_ovf ? FLT_STACK_OVF : FLT_NONE);
    br_fault_ev = br_ev && (br_flt != FLT_NONE);
  end

  // ==========================================================================
  // Barrier unit
  // ==========================================================================
  logic [NUM_WARPS-1:0]             rel_warps;
  logic [NUM_WGS-1:0]               rel_g;
  logic [NUM_WGS-1:0][NUM_WARPS-1:0] bar_arrived, bar_live;

  sfx_barrier_unit #(.NUM_WARPS(NUM_WARPS), .NUM_WGS(NUM_WGS), .PC_W(PC_W), .STRICT_PC(STRICT_BAR_PC)) u_bar (
    .clk(clk), .rst_n(rst_n),
    .alloc_valid(alloc_ok), .alloc_g(free_g), .alloc_members(alloc_sel),
    .arr_req(gany && (s_dec.op == OP_BAR)), .arr_valid(ev_bar), .arr_g(s_g), .arr_w(gw), .arr_pc(s_pc),
    .exit_valid(ev_exit), .exit_g(s_g), .exit_w(gw),
    .abort(gabort), .arr_mismatch(bar_mismatch),
    .rel_warps(rel_warps), .rel_g(rel_g), .arrived_o(bar_arrived), .live_o(bar_live));

  // ==========================================================================
  // Fault aggregation / abort
  // ==========================================================================
  logic [NUM_WGS-1:0] abort_set;
  logic [NUM_WARPS-1:0] freed_vec, drained;
  always_comb begin
    abort_set = '0;
    if (iss_fault_ev) abort_set[s_g]                = 1'b1;
    if (rsp_fault_ev) abort_set[wwg[imem_rsp_tag]]  = 1'b1;
    if (br_fault_ev)  abort_set[wwg[bw]]            = 1'b1;
    for (int w = 0; w < NUM_WARPS; w++) begin
      drained[w]   = (wstate[w] == WS_DRAIN) && (winf[w] == '0) && !fetch_pend[w];
      freed_vec[w] = drained[w] || (ev_exit && int'(gw) == w);
    end
  end

  // ==========================================================================
  // Sequential: warp contexts
  // ==========================================================================
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      for (int w = 0; w < NUM_WARPS; w++) begin
        wstate[w] <= WS_FREE;  wpc[w] <= '0;   wmask[w] <= '0; wlmask[w] <= '0;
        wrpc[w]   <= '0;       wsp[w] <= '0;   wib[w]   <= '0; wwg[w]    <= '0;
        widx_q[w] <= '0;       winf[w] <= '0;  wmem[w]  <= '0;
      end
      fetch_pend <= '0;
    end else begin
      // ---------------- stack pushes (branch resolution only) ----------------
      if (br_ev && (br_flt == FLT_NONE)) begin
        if (d_p0_en) begin
          stk_pc  [bw][SIW'(wsp[bw])] <= d_p0_pc;
          stk_mask[bw][SIW'(wsp[bw])] <= d_p0_mask;
          stk_rpc [bw][SIW'(wsp[bw])] <= d_p0_rpc;
        end
        if (d_p1_en) begin
          stk_pc  [bw][SIW'(int'(wsp[bw]) + 1)] <= d_p1_pc;
          stk_mask[bw][SIW'(int'(wsp[bw]) + 1)] <= d_p1_mask;
          stk_rpc [bw][SIW'(int'(wsp[bw]) + 1)] <= d_p1_rpc;
        end
      end

      for (int w = 0; w < NUM_WARPS; w++) begin
        automatic logic inc_inf = ev_be && (int'(gw) == w);
        automatic logic dec_inf = cmp_ok && (int'(cmp_warp) == w);
        automatic logic inc_mem = ev_be && s_dec.is_mem && (int'(gw) == w);
        automatic logic dec_mem = cmp_ok && cmp_mem && (int'(cmp_warp) == w);
        automatic logic [SP_W-1:0] spm1_b = (wsp[w] == '0) ? '0 : wsp[w] - 1'b1;

        // ---- in-flight / memory counters ----
        if (alloc_sel[w]) begin
          winf[w] <= '0; wmem[w] <= '0;
        end else begin
          if      (inc_inf && !dec_inf) winf[w] <= winf[w] + 1'b1;
          else if (!inc_inf && dec_inf) winf[w] <= winf[w] - 1'b1;
          if      (inc_mem && !dec_mem) wmem[w] <= wmem[w] + 1'b1;
          else if (!inc_mem && dec_mem) wmem[w] <= wmem[w] - 1'b1;
        end

        // ---- fetch-pending flag ----
        if (fetch_fire && fw == WID_W'(w))               fetch_pend[w] <= 1'b1;
        else if (rsp_ok && imem_rsp_tag == WID_W'(w))    fetch_pend[w] <= 1'b0;

        // ---- context / state machine ----
        if (alloc_sel[w]) begin
          wstate[w] <= WS_FETCH;
          wpc[w]    <= launch_pc;
          wmask[w]  <= lmask_w[w];
          wlmask[w] <= lmask_w[w];
          wrpc[w]   <= '0;
          wsp[w]    <= '0;
          wwg[w]    <= free_g;
          widx_q[w] <= WID_W'(rank_w[w]);
        end else if (wstate[w] != WS_FREE && wstate[w] != WS_DRAIN && gabort[wwg[w]]) begin
          wstate[w] <= WS_DRAIN;                       // workgroup abort wins
        end else begin
          case (wstate[w])
            WS_FETCH: begin
              if (fetch_fire && fw == WID_W'(w)) wstate[w] <= WS_FETCHING;
            end
            WS_FETCHING: begin
              if (rsp_hit[w]) begin
                wib[w]    <= imem_rsp_data;
                wstate[w] <= WS_READY;
              end else if (rsp_fault_ev && imem_rsp_tag == WID_W'(w)) begin
                wstate[w] <= WS_DRAIN;
              end
            end
            WS_READY: begin
              if (gany && gw == WID_W'(w)) begin
                if (iss_flt != FLT_NONE) begin
                  wstate[w] <= WS_DRAIN;
                end else if (ev_br) begin
                  wstate[w] <= WS_WAIT_BR;
                end else if (ev_bar) begin
                  wpc[w]    <= s_f[PC_W-1:0];
                  wstate[w] <= rel_warps[w] ? WS_FETCH : WS_BARRIER;
                end else if (ev_exit) begin
                  wstate[w] <= WS_FREE;
                end else begin                          // ALU / MEM / NOP / JMP
                  wstate[w] <= WS_FETCH;
                  if (fin_pop) begin
                    wpc[w]   <= stk_pc  [w][SIW'(s_sp_m1)];
                    wmask[w] <= stk_mask[w][SIW'(s_sp_m1)];
                    wrpc[w]  <= stk_rpc [w][SIW'(s_sp_m1)];
                    wsp[w]   <= s_sp_m1;
                  end else begin
                    wpc[w]   <= s_npc;
                  end
                end
              end
            end
            WS_WAIT_BR: begin
              if (br_ev && bw == WID_W'(w)) begin
                if (br_flt != FLT_NONE) begin
                  wstate[w] <= WS_DRAIN;
                end else begin
                  wstate[w] <= WS_FETCH;
                  if (d_pop) begin
                    wpc[w]   <= stk_pc  [w][SIW'(spm1_b)];
                    wmask[w] <= stk_mask[w][SIW'(spm1_b)];
                    wrpc[w]  <= stk_rpc [w][SIW'(spm1_b)];
                    wsp[w]   <= d_n_sp;
                  end else begin
                    wpc[w]   <= d_n_pc;
                    wmask[w] <= d_n_mask;
                    wrpc[w]  <= d_n_rpc;
                    wsp[w]   <= d_n_sp;
                  end
                end
              end
            end
            WS_BARRIER: begin
              if (rel_warps[w]) wstate[w] <= WS_FETCH;
            end
            WS_DRAIN: begin
              if (drained[w]) wstate[w] <= WS_FREE;
            end
            default: ;
          endcase
        end
      end
    end
  end

  // ==========================================================================
  // Sequential: workgroups, kernel status, fault record
  // ==========================================================================
  logic any_fault_ev;
  logic [8:0] fault_bits;
  always_comb begin
    any_fault_ev = iss_fault_ev || rsp_fault_ev || br_fault_ev || launch_fault_ev;
    fault_bits = '0;
    if (iss_fault_ev)    fault_bits[iss_flt]  = 1'b1;
    if (rsp_fault_ev)    fault_bits[rsp_flt]  = 1'b1;
    if (br_fault_ev)     fault_bits[br_flt]   = 1'b1;
    if (launch_fault_ev) fault_bits[FLT_LAUNCH] = 1'b1;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      gvalid   <= '0;
      gabort   <= '0;
      k_active <= 1'b0;
      k_last   <= 1'b0;
      k_done_q <= 1'b0;
      f_valid  <= 1'b0; f_code <= '0; f_wg <= '0; f_widx <= '0; f_pc <= '0; f_mask <= '0;
      for (int g = 0; g < NUM_WGS; g++) begin gid[g] <= '0; gmembers[g] <= '0; end
    end else begin
      // ---- workgroup table ----
      for (int g = 0; g < NUM_WGS; g++) begin
        if (alloc_ok && int'(free_g) == g) begin
          gvalid[g]    <= 1'b1;
          gid[g]       <= launch_wg_id;
          gmembers[g]  <= alloc_sel;
          gabort[g]    <= 1'b0;
        end else begin
          automatic logic [NUM_WARPS-1:0] mem_n = gmembers[g] & ~freed_vec;
          gmembers[g] <= mem_n;
          if (gvalid[g] && mem_n == '0) begin
            gvalid[g] <= 1'b0;
            gabort[g] <= 1'b0;
          end else if (abort_set[g]) begin
            gabort[g] <= 1'b1;
          end
        end
      end

      // ---- kernel status ----
      if (clear_ok) begin
        k_active <= 1'b0; k_last <= 1'b0; k_done_q <= 1'b0;
      end else begin
        if (launch_fire) begin
          k_active <= 1'b1;
          if (launch_last) k_last <= 1'b1;
        end
        if (k_last && !k_done_q && (gvalid == '0)) k_done_q <= 1'b1;
      end

      // ---- fault record ----
      if (clear_ok) begin
        f_valid <= 1'b0; f_mask <= '0;
      end else if (any_fault_ev) begin
        f_mask <= f_mask | fault_bits;
        if (!f_valid) begin
          f_valid <= 1'b1;
          if (iss_fault_ev) begin
            f_code <= iss_flt; f_wg <= gid[s_g]; f_widx <= widx_q[gw]; f_pc <= s_pc;
          end else if (rsp_fault_ev) begin
            f_code <= rsp_flt; f_wg <= gid[wwg[imem_rsp_tag]]; f_widx <= widx_q[imem_rsp_tag];
            f_pc <= wpc[imem_rsp_tag];
          end else if (br_fault_ev) begin
            f_code <= br_flt; f_wg <= gid[wwg[bw]]; f_widx <= widx_q[bw]; f_pc <= wpc[bw];
          end else begin
            f_code <= FLT_LAUNCH; f_wg <= launch_wg_id; f_widx <= '0; f_pc <= launch_pc;
          end
        end
      end
    end
  end

  assign kernel_busy = k_active && !k_done_q;
  assign kernel_done = k_done_q;
  assign fault_valid = f_valid;
  assign fault_code  = f_code;
  assign fault_wg_id = f_wg;
  assign fault_widx  = f_widx;
  assign fault_pc    = f_pc;
  assign fault_mask  = f_mask;

  always_comb begin
    for (int w = 0; w < NUM_WARPS; w++) dbg_wstate[w] = wstate[w];
  end

  // ==========================================================================
  // Performance counter plumbing
  // ==========================================================================
  logic [NUM_WARPS-1:0] m_resident, m_notsel, m_dep, m_mem, m_bar, m_br, m_fetch, m_be, m_drain;
  logic [SP_W-1:0]      sp_max_now;
  logic [2:0]           proto_inc, fault_inc;
  logic [1:0]           retire_inc;

  always_comb begin
    m_resident = '0; m_notsel = '0; m_dep = '0; m_mem = '0; m_bar = '0;
    m_br = '0; m_fetch = '0; m_be = '0; m_drain = '0;
    sp_max_now = '0;
    for (int w = 0; w < NUM_WARPS; w++) begin
      if (wsp[w] > sp_max_now) sp_max_now = wsp[w];
      m_resident[w] = (wstate[w] != WS_FREE);
      case (wstate[w])
        WS_FETCH, WS_FETCHING: m_fetch[w] = 1'b1;
        WS_WAIT_BR:            m_br[w]    = 1'b1;
        WS_BARRIER:            m_bar[w]   = 1'b1;
        WS_DRAIN:              m_drain[w] = 1'b1;
        WS_READY: begin
          if (grant[w]) begin
            if (iss_flt != FLT_NONE) m_drain[w] = 1'b1;     // fault replaces the issue
          end else if (w_cand[w])        m_notsel[w] = 1'b1;
          else if (!w_ready[w])          m_drain[w]  = 1'b1;  // aborting this cycle
          else if (hazard[w]) begin
            if (hazard_mem[w]) m_mem[w] = 1'b1; else m_dep[w] = 1'b1;
          end else if (w_drain_blk[w]) begin
            if (wmem[w] != '0) m_mem[w] = 1'b1; else m_dep[w] = 1'b1;
          end else                       m_be[w] = 1'b1;
        end
        default: ;
      endcase
    end
    fault_inc = 3'(int'(iss_fault_ev) + int'(rsp_fault_ev) + int'(br_fault_ev) + int'(launch_fault_ev));
    proto_inc = 3'(int'(cmp_valid && !cmp_ok)
                 + int'(imem_rsp_valid && !rsp_ok)
                 + int'(kernel_clear && !clear_ok));
    retire_inc = 2'(int'(ev_ctrl_ret) + int'(cmp_ok));
  end

  sfx_perf_counters #(.NUM_WARPS(NUM_WARPS), .CNT_W(CNT_W), .SP_W(SP_W)) u_perf (
    .clk(clk), .rst_n(rst_n), .clear(clear_ok), .active(kernel_busy),
    .issue(iss_exec), .issue_warp(grant & {NUM_WARPS{iss_exec}}),
    .m_resident(m_resident), .m_notsel(m_notsel), .m_dep(m_dep), .m_mem(m_mem), .m_bar(m_bar),
    .m_br(m_br), .m_fetch(m_fetch), .m_be(m_be), .m_drain(m_drain),
    .retire_inc(retire_inc),
    .div_branch_ev(br_ev && (br_flt == FLT_NONE) && d_diverge),
    .bar_episode_ev(|rel_g),
    .fault_inc(fault_inc), .proto_inc(proto_inc), .sp_max_now(sp_max_now),
    .cnt_cycles(cnt_cycles), .cnt_issued(cnt_issued), .cnt_retired(cnt_retired),
    .cnt_idle(cnt_idle), .cnt_idle_nowarp(cnt_idle_nowarp), .cnt_idle_be(cnt_idle_be),
    .cnt_idle_mem(cnt_idle_mem), .cnt_idle_dep(cnt_idle_dep), .cnt_idle_br(cnt_idle_br),
    .cnt_idle_fetch(cnt_idle_fetch), .cnt_idle_bar(cnt_idle_bar), .cnt_idle_other(cnt_idle_other),
    .cnt_wc_resident(cnt_wc_resident), .cnt_wc_issue(cnt_wc_issue), .cnt_wc_notsel(cnt_wc_notsel),
    .cnt_wc_dep(cnt_wc_dep), .cnt_wc_mem(cnt_wc_mem), .cnt_wc_bar(cnt_wc_bar),
    .cnt_wc_br(cnt_wc_br), .cnt_wc_fetch(cnt_wc_fetch), .cnt_wc_be(cnt_wc_be),
    .cnt_wc_drain(cnt_wc_drain), .cnt_div_branches(cnt_div_branches),
    .cnt_bar_episodes(cnt_bar_episodes), .cnt_faults(cnt_faults), .cnt_proto_err(cnt_proto_err),
    .cnt_stack_hwm(cnt_stack_hwm), .cnt_warp_issued(cnt_warp_issued));

  // ==========================================================================
  // Simulation-only assertions / monitors (compile with -DSFX_CHECKS)
  // ==========================================================================
`ifdef SFX_CHECKS
  `include "sfx_simt_checks.svh"
`endif

endmodule
