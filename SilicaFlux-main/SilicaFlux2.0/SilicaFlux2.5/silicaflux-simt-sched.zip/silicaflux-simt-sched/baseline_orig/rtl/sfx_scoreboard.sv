// ============================================================================
// Per-warp register scoreboard.
//
//   pend[w][r] : an issued, not yet completed instruction writes register r
//   pmem[w][r] : ... and that instruction is a load (stall attribution only)
//
// Hazard rules for the instruction buffered in warp w (in-order issue,
// operands read at issue):
//   RAW : a source register is pending
//   WAW : the destination register is pending
//   WAR : impossible (operands are read at issue, writes land later)
// r0 is hard-wired to zero and is never set pending by the control unit.
//
// Set and clear in the same cycle are applied as  next = (cur & ~clr) | set.
// (They can never target the same bit: WAW blocks re-issue while pending.)
// ============================================================================
module sfx_scoreboard #(
  parameter int NUM_WARPS = 8
) (
  input  logic clk,
  input  logic rst_n,
  // set on issue
  input  logic                         set_valid,
  input  logic [$clog2(NUM_WARPS)-1:0] set_warp,
  input  logic [4:0]                   set_rd,
  input  logic                         set_mem,
  // clear on completion
  input  logic                         clr_valid,
  input  logic [$clog2(NUM_WARPS)-1:0] clr_warp,
  input  logic [4:0]                   clr_rd,
  // hazard query for the buffered instruction of every warp
  input  logic [NUM_WARPS-1:0][4:0]    q_rs1,
  input  logic [NUM_WARPS-1:0][4:0]    q_rs2,
  input  logic [NUM_WARPS-1:0][4:0]    q_rd,
  input  logic [NUM_WARPS-1:0]         q_use1,
  input  logic [NUM_WARPS-1:0]         q_use2,
  input  logic [NUM_WARPS-1:0]         q_wr,
  output logic [NUM_WARPS-1:0]         hazard,
  output logic [NUM_WARPS-1:0]         hazard_mem,
  // observability (assertions / debug)
  output logic [NUM_WARPS-1:0][31:0]   pend_o
);
  logic [31:0] pend [NUM_WARPS];
  logic [31:0] pmem [NUM_WARPS];

  always_comb begin
    for (int w = 0; w < NUM_WARPS; w++) begin
      automatic logic h1 = q_use1[w] && pend[w][q_rs1[w]];
      automatic logic h2 = q_use2[w] && pend[w][q_rs2[w]];
      automatic logic h3 = q_wr[w]   && pend[w][q_rd[w]];
      automatic logic m1 = q_use1[w] && pmem[w][q_rs1[w]];
      automatic logic m2 = q_use2[w] && pmem[w][q_rs2[w]];
      automatic logic m3 = q_wr[w]   && pmem[w][q_rd[w]];
      hazard[w]     = h1 | h2 | h3;
      hazard_mem[w] = m1 | m2 | m3;
      pend_o[w]     = pend[w];
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      for (int w = 0; w < NUM_WARPS; w++) begin
        pend[w] <= '0;
        pmem[w] <= '0;
      end
    end else begin
      for (int w = 0; w < NUM_WARPS; w++) begin
        automatic logic [31:0] clr = (clr_valid && int'(clr_warp) == w) ? (32'd1 << clr_rd) : 32'd0;
        automatic logic [31:0] set = (set_valid && int'(set_warp) == w) ? (32'd1 << set_rd) : 32'd0;
        pend[w] <= (pend[w] & ~clr) | set;
        pmem[w] <= (pmem[w] & ~clr) | (set_mem ? set : 32'd0);
      end
    end
  end
endmodule
