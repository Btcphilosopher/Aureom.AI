// ============================================================================
// Branch-resolution / reconvergence-stack update function (combinational).
//
// Exact RTL image of `resolve_branch()` in tools/sfx_ref.py; see
// docs/divergence_model.md for the architectural definition.
//
// Inputs : the branch (pc, raw tgt/rpc offset fields), the warp's current
//          context (active mask, stack depth sp, current reconvergence PC
//          cur_rpc - valid iff sp != 0) and the lane predicate (taken_raw).
// Outputs: fault flags, `pop` (context reached its reconvergence point: the
//          new context comes from the stack top), otherwise the new current
//          context and up to two stack pushes (p0 at index sp, p1 at sp+1).
//
// Fault precedence: PC range first, then stack overflow.  On any fault the
// stack and context are left untouched by the caller.
// ============================================================================
module sfx_diverge_unit #(
  parameter int PC_W        = 16,
  parameter int LANES       = 32,
  parameter int STACK_DEPTH = 8
) (
  input  logic [PC_W-1:0]              pc,
  input  logic [10:0]                  tgt_off,    // signed
  input  logic [9:0]                   rpc_off,    // unsigned
  input  logic [LANES-1:0]             amask,
  input  logic [LANES-1:0]             taken_raw,
  input  logic [$clog2(STACK_DEPTH+1)-1:0] sp,
  input  logic [PC_W-1:0]              cur_rpc,
  output logic                         fault_range,
  output logic                         fault_ovf,
  output logic                         pop,
  output logic                         diverge,    // a real split happened (counter)
  output logic [PC_W-1:0]              n_pc,
  output logic [LANES-1:0]             n_mask,
  output logic [PC_W-1:0]              n_rpc,
  output logic [$clog2(STACK_DEPTH+1)-1:0] n_sp,
  output logic                         p0_en,
  output logic [PC_W-1:0]              p0_pc,
  output logic [LANES-1:0]             p0_mask,
  output logic [PC_W-1:0]              p0_rpc,
  output logic                         p1_en,
  output logic [PC_W-1:0]              p1_pc,
  output logic [LANES-1:0]             p1_mask,
  output logic [PC_W-1:0]              p1_rpc
);
  localparam int SPW = $clog2(STACK_DEPTH + 1);
  localparam int AW  = PC_W + 2;                 // signed range-check arithmetic

  logic signed [AW-1:0] f, t, r;
  logic [LANES-1:0] mt, mn;
  logic t_empty, f_empty, join_needed, both;
  int   npush;

  function automatic logic out_of_range(input logic signed [AW-1:0] v);
    return (v[AW-1:PC_W] != '0);                 // negative or >= 2^PC_W
  endfunction

  always_comb begin
    f = $signed({2'b00, pc}) + 1;
    t = f + AW'($signed(tgt_off));
    r = f + $signed({{(AW-10){1'b0}}, rpc_off});
    fault_range = out_of_range(f) | out_of_range(t) | out_of_range(r);
    fault_ovf   = 1'b0;
    pop         = 1'b0;
    diverge     = 1'b0;
    n_pc        = pc;
    n_mask      = amask;
    n_rpc       = cur_rpc;
    n_sp        = sp;
    p0_en = 1'b0; p0_pc = '0; p0_mask = '0; p0_rpc = '0;
    p1_en = 1'b0; p1_pc = '0; p1_mask = '0; p1_rpc = '0;

    mt = taken_raw & amask;
    mn = amask & ~mt;
    t_empty = (t[PC_W-1:0] == r[PC_W-1:0]);
    f_empty = (f[PC_W-1:0] == r[PC_W-1:0]);
    join_needed = !((sp != '0) && (r[PC_W-1:0] == cur_rpc));   // merge optimisation
    both  = !t_empty && !f_empty;
    npush = (join_needed ? 1 : 0) + (both ? 1 : 0);

    if (fault_range) begin
      // no state change
    end else if (mn == '0) begin                                // uniform taken
      if (sp != '0 && t[PC_W-1:0] == cur_rpc) begin pop = 1'b1; n_sp = sp - 1'b1; end
      else n_pc = t[PC_W-1:0];
    end else if (mt == '0) begin                                // uniform not taken
      if (sp != '0 && f[PC_W-1:0] == cur_rpc) begin pop = 1'b1; n_sp = sp - 1'b1; end
      else n_pc = f[PC_W-1:0];
    end else if (t_empty && f_empty) begin                      // both paths empty
      if (sp != '0 && r[PC_W-1:0] == cur_rpc) begin pop = 1'b1; n_sp = sp - 1'b1; end
      else n_pc = r[PC_W-1:0];
    end else begin                                              // real divergence
      diverge = 1'b1;
      if (int'(sp) + npush > STACK_DEPTH) begin
        fault_ovf = 1'b1;
      end else begin
        if (join_needed) begin
          p0_en = 1'b1; p0_pc = r[PC_W-1:0]; p0_mask = amask; p0_rpc = cur_rpc;
          if (both) begin
            p1_en = 1'b1; p1_pc = f[PC_W-1:0]; p1_mask = mn; p1_rpc = r[PC_W-1:0];
          end
        end else if (both) begin
          p0_en = 1'b1; p0_pc = f[PC_W-1:0]; p0_mask = mn; p0_rpc = r[PC_W-1:0];
        end
        n_sp = SPW'(int'(sp) + npush);
        n_rpc = r[PC_W-1:0];
        if (!t_empty) begin n_pc = t[PC_W-1:0]; n_mask = mt; end
        else          begin n_pc = f[PC_W-1:0]; n_mask = mn; end
      end
    end
  end
endmodule
