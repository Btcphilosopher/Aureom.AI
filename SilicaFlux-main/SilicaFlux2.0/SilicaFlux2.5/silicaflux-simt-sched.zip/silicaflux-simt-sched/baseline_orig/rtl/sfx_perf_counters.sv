// ============================================================================
// Performance counters.
//
// All counters are CNT_W bits, saturating, cleared by `clear` (kernel_clear).
// They count only while `active` (first accepted launch .. kernel_done).
//
// (1) Slot-level (exclusive; one event per active cycle):
//       cycles == issued + idle
//       idle   == idle_nowarp + idle_be + idle_mem + idle_dep + idle_br
//                 + idle_fetch + idle_bar + idle_other
//     An idle cycle is attributed to the FIRST matching cause in the order
//       NOWARP  no resident warp at all
//       BE      >=1 warp was issuable but the backend class / per-warp credit
//               refused it (structural stall)
//       MEM     >=1 warp waits on a load result or on outstanding stores
//               (BAR / EXIT drain)
//       DEP     >=1 warp waits on a non-memory register dependency
//       BR      >=1 warp waits for a branch outcome
//       FETCH   >=1 warp waits for an instruction fetch
//       BAR     every resident warp is parked at a barrier
//       OTHER   only draining (aborted) warps
//
// (2) Warp-cycle level (sum over resident warps; every resident warp falls in
//     exactly one bucket per cycle):
//       wc_resident == wc_issue + wc_notsel + wc_dep + wc_mem + wc_bar
//                      + wc_br + wc_fetch + wc_be + wc_drain
//     wc_notsel = warp was issuable but lost arbitration to another warp.
// ============================================================================
module sfx_perf_counters #(
  parameter int NUM_WARPS = 8,
  parameter int CNT_W     = 32,
  parameter int SP_W      = 4
) (
  input  logic clk,
  input  logic rst_n,
  input  logic clear,
  input  logic active,
  input  logic issue,                       // an instruction issued this cycle
  input  logic [NUM_WARPS-1:0] issue_warp,  // one-hot (valid with issue)
  input  logic [NUM_WARPS-1:0] m_resident,
  input  logic [NUM_WARPS-1:0] m_notsel,
  input  logic [NUM_WARPS-1:0] m_dep,
  input  logic [NUM_WARPS-1:0] m_mem,
  input  logic [NUM_WARPS-1:0] m_bar,
  input  logic [NUM_WARPS-1:0] m_br,
  input  logic [NUM_WARPS-1:0] m_fetch,
  input  logic [NUM_WARPS-1:0] m_be,
  input  logic [NUM_WARPS-1:0] m_drain,
  input  logic [1:0]           retire_inc,
  input  logic                 div_branch_ev,
  input  logic                 bar_episode_ev,
  input  logic [2:0]           fault_inc,
  input  logic [2:0]           proto_inc,
  input  logic [SP_W-1:0]      sp_max_now,

  output logic [CNT_W-1:0] cnt_cycles,
  output logic [CNT_W-1:0] cnt_issued,
  output logic [CNT_W-1:0] cnt_retired,
  output logic [CNT_W-1:0] cnt_idle,
  output logic [CNT_W-1:0] cnt_idle_nowarp,
  output logic [CNT_W-1:0] cnt_idle_be,
  output logic [CNT_W-1:0] cnt_idle_mem,
  output logic [CNT_W-1:0] cnt_idle_dep,
  output logic [CNT_W-1:0] cnt_idle_br,
  output logic [CNT_W-1:0] cnt_idle_fetch,
  output logic [CNT_W-1:0] cnt_idle_bar,
  output logic [CNT_W-1:0] cnt_idle_other,
  output logic [CNT_W-1:0] cnt_wc_resident,
  output logic [CNT_W-1:0] cnt_wc_issue,
  output logic [CNT_W-1:0] cnt_wc_notsel,
  output logic [CNT_W-1:0] cnt_wc_dep,
  output logic [CNT_W-1:0] cnt_wc_mem,
  output logic [CNT_W-1:0] cnt_wc_bar,
  output logic [CNT_W-1:0] cnt_wc_br,
  output logic [CNT_W-1:0] cnt_wc_fetch,
  output logic [CNT_W-1:0] cnt_wc_be,
  output logic [CNT_W-1:0] cnt_wc_drain,
  output logic [CNT_W-1:0] cnt_div_branches,
  output logic [CNT_W-1:0] cnt_bar_episodes,
  output logic [CNT_W-1:0] cnt_faults,
  output logic [CNT_W-1:0] cnt_proto_err,
  output logic [SP_W-1:0]  cnt_stack_hwm,
  output logic [NUM_WARPS-1:0][CNT_W-1:0] cnt_warp_issued
);
  localparam logic [CNT_W-1:0] MAXV = '1;

  function automatic logic [CNT_W-1:0] sat_add(input logic [CNT_W-1:0] a, input int unsigned b);
    logic [CNT_W:0] s;
    s = {1'b0, a} + (CNT_W+1)'(b);
    return s[CNT_W] ? MAXV : s[CNT_W-1:0];
  endfunction

  function automatic int unsigned popc(input logic [NUM_WARPS-1:0] v);
    int unsigned n = 0;
    for (int i = 0; i < NUM_WARPS; i++) n += int'(v[i]);
    return n;
  endfunction

  logic no_resident;
  assign no_resident = (m_resident == '0);

  always_ff @(posedge clk) begin
    if (!rst_n || clear) begin
      cnt_cycles <= '0; cnt_issued <= '0; cnt_retired <= '0; cnt_idle <= '0;
      cnt_idle_nowarp <= '0; cnt_idle_be <= '0; cnt_idle_mem <= '0; cnt_idle_dep <= '0;
      cnt_idle_br <= '0; cnt_idle_fetch <= '0; cnt_idle_bar <= '0; cnt_idle_other <= '0;
      cnt_wc_resident <= '0; cnt_wc_issue <= '0; cnt_wc_notsel <= '0; cnt_wc_dep <= '0;
      cnt_wc_mem <= '0; cnt_wc_bar <= '0; cnt_wc_br <= '0; cnt_wc_fetch <= '0;
      cnt_wc_be <= '0; cnt_wc_drain <= '0;
      cnt_div_branches <= '0; cnt_bar_episodes <= '0; cnt_faults <= '0; cnt_proto_err <= '0;
      cnt_stack_hwm <= '0;
      for (int w = 0; w < NUM_WARPS; w++) cnt_warp_issued[w] <= '0;
    end else begin
      // events that are meaningful even outside the active window
      cnt_retired      <= sat_add(cnt_retired, int'(retire_inc));
      cnt_faults       <= sat_add(cnt_faults, int'(fault_inc));
      cnt_proto_err    <= sat_add(cnt_proto_err, int'(proto_inc));
      if (div_branch_ev)  cnt_div_branches <= sat_add(cnt_div_branches, 1);
      if (bar_episode_ev) cnt_bar_episodes <= sat_add(cnt_bar_episodes, 1);
      if (sp_max_now > cnt_stack_hwm) cnt_stack_hwm <= sp_max_now;
      if (issue) begin
        cnt_issued <= sat_add(cnt_issued, 1);
        for (int w = 0; w < NUM_WARPS; w++)
          if (issue_warp[w]) cnt_warp_issued[w] <= sat_add(cnt_warp_issued[w], 1);
      end
      if (active) begin
        cnt_cycles      <= sat_add(cnt_cycles, 1);
        cnt_wc_resident <= sat_add(cnt_wc_resident, popc(m_resident));
        cnt_wc_issue    <= sat_add(cnt_wc_issue, issue ? 1 : 0);
        cnt_wc_notsel   <= sat_add(cnt_wc_notsel, popc(m_notsel));
        cnt_wc_dep      <= sat_add(cnt_wc_dep,    popc(m_dep));
        cnt_wc_mem      <= sat_add(cnt_wc_mem,    popc(m_mem));
        cnt_wc_bar      <= sat_add(cnt_wc_bar,    popc(m_bar));
        cnt_wc_br       <= sat_add(cnt_wc_br,     popc(m_br));
        cnt_wc_fetch    <= sat_add(cnt_wc_fetch,  popc(m_fetch));
        cnt_wc_be       <= sat_add(cnt_wc_be,     popc(m_be));
        cnt_wc_drain    <= sat_add(cnt_wc_drain,  popc(m_drain));
        if (!issue) begin
          cnt_idle <= sat_add(cnt_idle, 1);
          if      (no_resident)   cnt_idle_nowarp <= sat_add(cnt_idle_nowarp, 1);
          else if (|m_be)         cnt_idle_be     <= sat_add(cnt_idle_be, 1);
          else if (|m_mem)        cnt_idle_mem    <= sat_add(cnt_idle_mem, 1);
          else if (|m_dep)        cnt_idle_dep    <= sat_add(cnt_idle_dep, 1);
          else if (|m_br)         cnt_idle_br     <= sat_add(cnt_idle_br, 1);
          else if (|m_fetch)      cnt_idle_fetch  <= sat_add(cnt_idle_fetch, 1);
          else if (|m_bar)        cnt_idle_bar    <= sat_add(cnt_idle_bar, 1);
          else                    cnt_idle_other  <= sat_add(cnt_idle_other, 1);
        end
      end
    end
  end
endmodule
