// ============================================================================
// SilicaFlux SIMT control unit - shared definitions (ISA decode, state codes)
// ============================================================================
`ifndef SFX_SIMT_PKG_SV
`define SFX_SIMT_PKG_SV

package sfx_simt_pkg;

  // ---- opcodes (6 bit) ----------------------------------------------------
  localparam logic [5:0] OP_NOP  = 6'h00;
  localparam logic [5:0] OP_ADD  = 6'h01;
  localparam logic [5:0] OP_SUB  = 6'h02;
  localparam logic [5:0] OP_AND  = 6'h03;
  localparam logic [5:0] OP_OR   = 6'h04;
  localparam logic [5:0] OP_XOR  = 6'h05;
  localparam logic [5:0] OP_SHL  = 6'h06;
  localparam logic [5:0] OP_SHR  = 6'h07;
  localparam logic [5:0] OP_SLT  = 6'h08;
  localparam logic [5:0] OP_MUL  = 6'h09;
  localparam logic [5:0] OP_ADDI = 6'h0A;
  localparam logic [5:0] OP_ANDI = 6'h0B;
  localparam logic [5:0] OP_MOVI = 6'h0C;
  localparam logic [5:0] OP_TID  = 6'h0D;
  localparam logic [5:0] OP_WGID = 6'h0E;
  localparam logic [5:0] OP_LD   = 6'h10;
  localparam logic [5:0] OP_ST   = 6'h11;
  localparam logic [5:0] OP_LDS  = 6'h12;
  localparam logic [5:0] OP_STS  = 6'h13;
  localparam logic [5:0] OP_BRA  = 6'h20;
  localparam logic [5:0] OP_BRZ  = 6'h21;
  localparam logic [5:0] OP_JMP  = 6'h22;
  localparam logic [5:0] OP_BAR  = 6'h23;
  localparam logic [5:0] OP_EXIT = 6'h24;

  // ---- execution classes (index into be_rdy[]) ----------------------------
  localparam logic [1:0] CLS_ALU  = 2'd0;
  localparam logic [1:0] CLS_MEM  = 2'd1;
  localparam logic [1:0] CLS_BR   = 2'd2;
  localparam logic [1:0] CLS_CTRL = 2'd3;   // handled inside the control unit

  // ---- warp slot states ---------------------------------------------------
  localparam logic [2:0] WS_FREE    = 3'd0;  // slot unallocated
  localparam logic [2:0] WS_FETCH   = 3'd1;  // PC valid, wants an instruction
  localparam logic [2:0] WS_FETCHING= 3'd2;  // fetch request outstanding
  localparam logic [2:0] WS_READY   = 3'd3;  // instruction buffered, may issue
  localparam logic [2:0] WS_WAIT_BR = 3'd4;  // branch issued, awaiting taken mask
  localparam logic [2:0] WS_BARRIER = 3'd5;  // arrived at workgroup barrier
  localparam logic [2:0] WS_DRAIN   = 3'd6;  // faulted/aborted, draining in-flight work

  // ---- fault codes (kernel status) ----------------------------------------
  localparam logic [3:0] FLT_NONE        = 4'd0;
  localparam logic [3:0] FLT_DIV_BARRIER = 4'd1;  // BAR executed while warp diverged
  localparam logic [3:0] FLT_DIV_EXIT    = 4'd2;  // EXIT executed while warp diverged
  localparam logic [3:0] FLT_STACK_OVF   = 4'd3;  // reconvergence stack overflow
  localparam logic [3:0] FLT_ILLEGAL     = 4'd4;  // undefined opcode
  localparam logic [3:0] FLT_FETCH       = 4'd5;  // instruction fetch error
  localparam logic [3:0] FLT_PC_RANGE    = 4'd6;  // branch/jump/sequential PC outside [0,2^PC_W)
  localparam logic [3:0] FLT_BAR_PC      = 4'd7;  // strict mode: barrier PC mismatch in one episode
  localparam logic [3:0] FLT_LAUNCH      = 4'd8;  // invalid launch size

  // ---- decoded instruction ------------------------------------------------
  typedef struct packed {
    logic        illegal;
    logic [5:0]  op;
    logic [1:0]  cls;
    logic        use1;      // reads rs1
    logic        use2;      // reads rs2
    logic        wr;        // writes rd (rd != 0 checked by consumer)
    logic        is_ld;     // result comes from memory (scoreboard 'mem' tag)
    logic        is_mem;
    logic [4:0]  rs1;
    logic [4:0]  rs2;
    logic [4:0]  rd;
  } dec_t;

  function automatic dec_t sfx_decode(input logic [31:0] i);
    dec_t d;
    d = '0;
    d.op  = i[31:26];
    d.rd  = i[25:21];
    d.rs1 = i[20:16];
    d.rs2 = i[15:11];
    d.cls = CLS_CTRL;
    case (i[31:26])
      OP_NOP, OP_JMP, OP_BAR, OP_EXIT: d.cls = CLS_CTRL;
      OP_ADD, OP_SUB, OP_AND, OP_OR, OP_XOR, OP_SHL, OP_SHR, OP_SLT, OP_MUL: begin
        d.cls = CLS_ALU; d.use1 = 1'b1; d.use2 = 1'b1; d.wr = 1'b1;
      end
      OP_ADDI, OP_ANDI: begin d.cls = CLS_ALU; d.use1 = 1'b1; d.wr = 1'b1; end
      OP_MOVI, OP_TID, OP_WGID: begin d.cls = CLS_ALU; d.wr = 1'b1; end
      OP_LD, OP_LDS: begin
        d.cls = CLS_MEM; d.use1 = 1'b1; d.wr = 1'b1; d.is_ld = 1'b1; d.is_mem = 1'b1;
      end
      OP_ST, OP_STS: begin
        d.cls = CLS_MEM; d.use1 = 1'b1; d.use2 = 1'b1; d.is_mem = 1'b1;
      end
      OP_BRA, OP_BRZ: begin
        d.cls = CLS_BR; d.use1 = 1'b1; d.rs1 = i[25:21];   // predicate register is field A
      end
      default: d.illegal = 1'b1;
    endcase
    return d;
  endfunction

endpackage

`endif
