// ============================================================================
// Warp scheduler: selects at most one issuable warp per cycle.
//   POLICY 0 : deterministic round-robin (default): round-robin inside every execution
//              class and across classes (sfx_class_rr_arb)
//   POLICY 1 : age-based (oldest-first) with starvation guard (sfx_age_arb)
// `req`  : warps that can issue THIS cycle (all hazards / credits resolved)
// `wait_en` : warps holding a buffered instruction (for age-policy accounting)
// `alloc`: slots allocated this cycle (age bookkeeping)
// ============================================================================
module sfx_warp_sched #(
  parameter int N            = 8,
  parameter int POLICY       = 0,
  parameter int STARVE_LIMIT = 16
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] req,
  input  logic [N-1:0] wait_en,
  input  logic [N-1:0] alloc,
  input  logic [N-1:0][1:0] cls,       // execution class of each warp's buffered instruction
  output logic [N-1:0] grant
);
  generate
    if (POLICY == 0) begin : g_rr
      sfx_class_rr_arb #(.N(N)) u_arb (
        .clk(clk), .rst_n(rst_n), .req(req), .cls(cls), .grant(grant));
      // unused in RR mode
      logic unused_ok;
      assign unused_ok = &{1'b0, wait_en, alloc};
    end else begin : g_age
      sfx_age_arb #(.N(N), .STARVE_LIMIT(STARVE_LIMIT)) u_arb (
        .clk(clk), .rst_n(rst_n), .req(req), .wait_en(wait_en), .alloc(alloc),
        .adv(1'b1), .grant(grant));
      logic unused_cls;
      assign unused_cls = &{1'b0, cls};
    end
  endgenerate
endmodule
