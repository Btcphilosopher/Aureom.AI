// ============================================================================
// Age-based (oldest-first) arbiter with a starvation guard.
//
// Age is tracked exactly with an N x N age matrix: older[i][j] == 1 means slot
// i was allocated before slot j.  Newly allocated slots are younger than every
// existing slot; slots allocated in the same cycle are ordered by index.
//
// Policy
//   1. A requester whose wait counter reached STARVE_LIMIT is "urgent".
//   2. If any urgent requester exists, the grant goes to the OLDEST urgent one,
//      otherwise to the OLDEST requester.
//   wait[i] counts the grants to OTHER slots made in cycles in which i was a candidate
//   (req[i]); it is cleared when i is granted or stops waiting (wait_en[i] = 0).
//   Cycles in which i cannot issue only because its backend class is busy do not count,
//   and do not reset the counter either: otherwise a long busy window lets an older
//   sibling become urgent again between two grant opportunities and win every time.
//
// Starvation bound (STARVE_LIMIT >= N): a candidate that stays requesting is
// granted after at most STARVE_LIMIT + N grants of other slots made while it was
// a candidate.  STARVE_LIMIT
// = 0 disables the guard (pure oldest-first; only as live as the older warps).
// ============================================================================
module sfx_age_arb #(
  parameter int N            = 8,
  parameter int STARVE_LIMIT = 16
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] req,        // candidates
  input  logic [N-1:0] wait_en,    // slot is waiting for an issue slot (superset of req)
  input  logic [N-1:0] alloc,      // slots (re)allocated this cycle
  input  logic         adv,        // grant is consumed this cycle
  output logic [N-1:0] grant
);
  localparam int CW = $clog2(STARVE_LIMIT + 2);

  logic [N-1:0]  older [N];        // older[i][j]: i is older than j
  logic [CW-1:0] wcnt  [N];
  logic [N-1:0]  urgent, urg_req, sel;
  logic          fire;

  assign fire = adv && (|grant);

  always_comb begin
    for (int i = 0; i < N; i++)
      urgent[i] = (STARVE_LIMIT != 0) && (wcnt[i] >= CW'(STARVE_LIMIT));
    urg_req = req & urgent;
    sel     = (|urg_req) ? urg_req : req;
    for (int j = 0; j < N; j++) begin
      automatic logic blocked = 1'b0;
      for (int i = 0; i < N; i++)
        if (i != j && sel[i] && older[i][j]) blocked = 1'b1;
      grant[j] = sel[j] && !blocked;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      for (int i = 0; i < N; i++) begin
        older[i] <= '0;
        wcnt[i]  <= '0;
      end
    end else begin
      // age matrix
      for (int i = 0; i < N; i++) begin
        for (int j = 0; j < N; j++) begin
          if (i != j) begin
            if (alloc[j] && !alloc[i])      older[i][j] <= 1'b1;
            else if (alloc[i] && !alloc[j]) older[i][j] <= 1'b0;
            else if (alloc[i] && alloc[j])  older[i][j] <= (i < j);
          end
        end
      end
      // starvation counters
      for (int i = 0; i < N; i++) begin
        if (!wait_en[i] || (fire && grant[i]) || alloc[i]) wcnt[i] <= '0;
        else if (fire && req[i] && (wcnt[i] < CW'(STARVE_LIMIT + 1))) wcnt[i] <= wcnt[i] + 1'b1;
      end
    end
  end
endmodule
