// ============================================================================
// Workgroup barrier unit.
//
// Per workgroup slot g:
//   live[g]    : warps of the workgroup that have neither exited nor faulted.
//                Initialised to the full member set at launch (atomic
//                allocation => the participant set is complete from cycle 0).
//   arrived[g] : live warps currently waiting at the barrier.
//
// Participant rule: the barrier releases when  arrived == live  and
// arrived != 0, evaluated on the NEXT-state masks, i.e. an arrival and an
// exit are both taken into account in the same cycle.  Exited warps stop
// participating (a warp that EXITs while others wait can complete the
// episode).  Release clears `arrived` atomically and wakes every arrived warp
// in the same cycle, so no warp can re-enter the next episode early.
//
// Optional strict mode (STRICT_PC): all arrivals of one episode must come from
// the same BAR instruction; a mismatching arrival is refused (arr_mismatch)
// and the control unit turns it into a fault.
// ============================================================================
module sfx_barrier_unit #(
  parameter int NUM_WARPS = 8,
  parameter int NUM_WGS   = 4,
  parameter int PC_W      = 16,
  parameter bit STRICT_PC = 1'b0
) (
  input  logic clk,
  input  logic rst_n,
  // workgroup allocation
  input  logic                         alloc_valid,
  input  logic [$clog2(NUM_WGS)-1:0]   alloc_g,
  input  logic [NUM_WARPS-1:0]         alloc_members,
  // warp arrival (BAR of warp arr_w of workgroup arr_g).
  //   arr_req   : the BAR is being considered for issue (used only for the strict-PC check,
  //               must not depend on arr_mismatch)
  //   arr_valid : the BAR actually issued (arrival committed)
  input  logic                         arr_req,
  input  logic                         arr_valid,
  input  logic [$clog2(NUM_WGS)-1:0]   arr_g,
  input  logic [$clog2(NUM_WARPS)-1:0] arr_w,
  input  logic [PC_W-1:0]              arr_pc,
  // warp exit (EXIT issued)
  input  logic                         exit_valid,
  input  logic [$clog2(NUM_WGS)-1:0]   exit_g,
  input  logic [$clog2(NUM_WARPS)-1:0] exit_w,
  // workgroups being aborted: no release
  input  logic [NUM_WGS-1:0]           abort,
  output logic                         arr_mismatch,
  output logic [NUM_WARPS-1:0]         rel_warps,   // warps woken this cycle (incl. the arriving warp)
  output logic [NUM_WGS-1:0]           rel_g,       // workgroups released this cycle
  output logic [NUM_WGS-1:0][NUM_WARPS-1:0] arrived_o,
  output logic [NUM_WGS-1:0][NUM_WARPS-1:0] live_o
);
  logic [NUM_WARPS-1:0] arrived [NUM_WGS];
  logic [NUM_WARPS-1:0] live    [NUM_WGS];
  logic [PC_W-1:0]      bpc     [NUM_WGS];
  logic [NUM_WARPS-1:0] arr_n   [NUM_WGS];
  logic [NUM_WARPS-1:0] live_n  [NUM_WGS];

  always_comb begin
    arr_mismatch = 1'b0;
    if (STRICT_PC && arr_req && (arrived[arr_g] != '0) && (bpc[arr_g] != arr_pc))
      arr_mismatch = 1'b1;
    rel_warps = '0;
    for (int g = 0; g < NUM_WGS; g++) begin
      arr_n[g]  = arrived[g];
      live_n[g] = live[g];
      if (arr_valid && int'(arr_g) == g)
        arr_n[g][arr_w] = 1'b1;
      if (exit_valid && int'(exit_g) == g)
        live_n[g][exit_w] = 1'b0;
      rel_g[g] = !abort[g] && (arr_n[g] != '0) && (arr_n[g] == live_n[g]);
      if (rel_g[g]) rel_warps |= arr_n[g];
      arrived_o[g] = arrived[g];
      live_o[g]    = live[g];
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      for (int g = 0; g < NUM_WGS; g++) begin
        arrived[g] <= '0;
        live[g]    <= '0;
        bpc[g]     <= '0;
      end
    end else begin
      for (int g = 0; g < NUM_WGS; g++) begin
        if (alloc_valid && int'(alloc_g) == g) begin
          arrived[g] <= '0;
          live[g]    <= alloc_members;
        end else begin
          arrived[g] <= rel_g[g] ? '0 : arr_n[g];
          live[g]    <= live_n[g];
          if (arr_valid && int'(arr_g) == g && arrived[g] == '0) bpc[g] <= arr_pc;
        end
      end
    end
  end
endmodule
