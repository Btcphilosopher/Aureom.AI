// Common macros for SilicaFlux SIMT RTL / testbenches.
`ifndef SFX_DEFS_SVH
`define SFX_DEFS_SVH

// Simulation assertion: always fatal, prints module-scope message with time.
`define SFX_ASSERT(cond, msg) \
  if (!(cond)) begin \
    $display("[SFX-ASSERT] t=%0t %m : %s", $time, msg); \
    $fatal(1, "SFX assertion failed: %s", msg); \
  end

`endif
