// ============================================================================
// Simulation-only assertions and monitors for sfx_simt_ctrl (included inside
// the module body when SFX_CHECKS is defined).  Every check is evaluated each
// clock on the pre-edge state; a violation is fatal.
//
//   Group A  warp-state consistency
//   Group B  bounded-resource ownership
//   Group C  eventual progress (bounded-wait / bounded-latency proofs),
//            valid under the downstream fairness assumptions documented in
//            docs/architecture.md and enforced by tb/sfx_assume_monitor.sv
// ============================================================================
  bit chk_allow_proto;
  initial chk_allow_proto = $test$plusargs("sfx_allow_proto_err");

  // ---------------------------------------------------------------- helpers
  logic [NUM_WARPS-1:0] chk_prev_issued;      // warp issued in the previous cycle
  int                   chk_wait   [NUM_WARPS];
  int                   chk_done_wait;
  int                   chk_idle_cnt;
  int unsigned          chk_max_wait;         // observed maximum (reported by TB)
  // RR  : N-1 same-class grants, <= 3 other-class grants before each class grant  -> 4N-1
  // AGE : STARVE_LIMIT + N
  localparam int CHK_WAIT_BOUND = (SCHED_POLICY == 0) ? (4 * NUM_WARPS - 1)
                                 : ((STARVE_LIMIT == 0) ? 1000000 : (STARVE_LIMIT + NUM_WARPS));

  initial begin chk_max_wait = 0; chk_done_wait = 0; chk_idle_cnt = 0; end

  logic chk_progress;
  always_comb begin
    chk_progress = iss_exec || cmp_ok || rsp_ok || fetch_fire || (|rel_g) || launch_fire
                 || (|drained) || kernel_clear;
  end

  always @(posedge clk) begin
    if (!rst_n) begin
      chk_prev_issued <= '0;
      for (int w = 0; w < NUM_WARPS; w++) chk_wait[w] = 0;
      chk_done_wait = 0;
      chk_idle_cnt  = 0;
    end else begin
      // ======================= Group A: warp-state consistency ==============
      for (int w = 0; w < NUM_WARPS; w++) begin
        automatic int g = int'(wwg[w]);
        // A1 a resident warp belongs to exactly one valid workgroup that lists it as a member
        if (wstate[w] != WS_FREE) begin
          `SFX_ASSERT(gvalid[g] && gmembers[g][w], "A1: resident warp not owned by a valid workgroup")
        end else begin
          // A1b a free slot carries no live work
          `SFX_ASSERT(winf[w] == '0 && wmem[w] == '0 && !fetch_pend[w] && sb_pend[w] == '0,
                      "A1b: FREE slot has in-flight work / pending registers")
        end
        // A2 fetch bookkeeping
        if (wstate[w] == WS_FETCHING) `SFX_ASSERT(fetch_pend[w], "A2: FETCHING without fetch_pend")
        if (fetch_pend[w]) `SFX_ASSERT(wstate[w] == WS_FETCHING || wstate[w] == WS_DRAIN,
                                       "A2: fetch_pend outside FETCHING/DRAIN")
        // A3 barrier state <-> arrived mask
        if (wstate[w] == WS_BARRIER) `SFX_ASSERT(bar_arrived[g][w], "A3: BARRIER state but not in arrived mask")
        if (wstate[w] != WS_FREE && bar_arrived[g][w] && gvalid[g] && !gabort[g])
          `SFX_ASSERT(wstate[w] == WS_BARRIER, "A3: in arrived mask but not in BARRIER state")
        // A5 branch wait implies an in-flight branch
        if (wstate[w] == WS_WAIT_BR) `SFX_ASSERT(winf[w] != '0, "A5: WAIT_BR without in-flight branch")
        // A6 execution-mask / stack consistency (non-draining live contexts)
        if (wstate[w] != WS_FREE && wstate[w] != WS_DRAIN) begin
          `SFX_ASSERT(wmask[w] != '0, "A6: empty active mask")
          `SFX_ASSERT((wmask[w] & ~wlmask[w]) == '0, "A6: active mask outside launch mask")
          `SFX_ASSERT(int'(wsp[w]) <= STACK_DEPTH, "A6: stack depth exceeds STACK_DEPTH")
          `SFX_ASSERT((wsp[w] == '0) == (wmask[w] == wlmask[w]),
                      "A6: converged (sp==0) must coincide with full launch mask")
          if (wsp[w] != '0 && (wstate[w] == WS_FETCH || wstate[w] == WS_FETCHING || wstate[w] == WS_READY))
            `SFX_ASSERT(wpc[w] != wrpc[w], "A6: context pc equals its own reconvergence pc")
          for (int d = 0; d < STACK_DEPTH; d++) begin
            if (d < int'(wsp[w])) begin
              `SFX_ASSERT(stk_mask[w][d] != '0 && (stk_mask[w][d] & ~wlmask[w]) == '0,
                          "A6: stack entry mask empty / outside launch mask")
              if (d >= 1) `SFX_ASSERT(stk_pc[w][d] != stk_rpc[w][d],
                                      "A6: stack entry pc equals its reconvergence pc")
            end
          end
        end
        // A8 no duplicate issue: after an issue the warp is never READY on the next cycle
        if (chk_prev_issued[w]) `SFX_ASSERT(wstate[w] != WS_READY, "A8: warp still READY after issuing (duplicate issue)")
      end
      chk_prev_issued <= grant & {NUM_WARPS{iss_exec}};

      // A7 issue legality
      `SFX_ASSERT($onehot0(grant), "A7: more than one warp granted")
      `SFX_ASSERT($onehot0(fetch_grant), "A7: more than one fetch grant")
      if (iss_exec) begin
        `SFX_ASSERT(wstate[gw] == WS_READY, "A7: issue from a non-READY warp")
        `SFX_ASSERT(!gabort[wwg[gw]], "A7: issue from an aborting workgroup")
        `SFX_ASSERT(!hazard[gw], "A7: issue with an unresolved register hazard")
        `SFX_ASSERT(s_mask != '0 && (s_mask & ~wlmask[gw]) == '0, "A7: bad execution mask at issue")
        if (s_dec.cls != CLS_CTRL) begin
          `SFX_ASSERT(be_rdy[s_dec.cls[1:0]], "A7: issue to a backend class that is not ready")
          `SFX_ASSERT(winf[gw] != INF_W'(MAX_INFLIGHT), "A7: in-flight credit exceeded")
        end
        if (s_dec.op == OP_BAR)  `SFX_ASSERT(wmem[gw] == '0 && s_sp == '0, "A7: BAR with outstanding memory ops or while diverged")
        if (s_dec.op == OP_EXIT) `SFX_ASSERT(winf[gw] == '0 && wmem[gw] == '0 && s_sp == '0 && s_mask == wlmask[gw],
                                             "A7: EXIT with in-flight work or while diverged")
      end
      // A9 no retirement from inactive contexts
      if (cmp_valid && !chk_allow_proto) begin
        `SFX_ASSERT(cmp_ok, "A9: completion for an inactive/non-matching context (retirement refused)")
      end
      if (cmp_ok) `SFX_ASSERT(wstate[cmp_warp] != WS_FREE && winf[cmp_warp] != '0,
                              "A9: retirement accepted for an inactive context")
      // A10 allocation only onto clean slots
      for (int w = 0; w < NUM_WARPS; w++)
        if (alloc_sel[w])
          `SFX_ASSERT(wstate[w] == WS_FREE && winf[w] == '0 && wmem[w] == '0 && !fetch_pend[w] && sb_pend[w] == '0,
                      "A10: allocation onto a slot that is not clean")
      // A11 per-warp bucket partition of the stall accounting
      for (int w = 0; w < NUM_WARPS; w++) begin
        automatic int n = int'(m_notsel[w]) + int'(m_dep[w]) + int'(m_mem[w]) + int'(m_bar[w]) + int'(m_br[w])
                        + int'(m_fetch[w]) + int'(m_be[w]) + int'(m_drain[w])
                        + int'(grant[w] && iss_exec);
        `SFX_ASSERT(n == int'(m_resident[w]), "A11: stall buckets do not partition resident warps")
      end

      // ======================= Group B: bounded-resource ownership ==========
      begin
        automatic int resident = 0, owned = 0;
        for (int w = 0; w < NUM_WARPS; w++) begin
          automatic int owners = 0;
          resident += int'(wstate[w] != WS_FREE);
          for (int g = 0; g < NUM_WGS; g++) owners += int'(gvalid[g] && gmembers[g][w]);
          owned += owners;
          `SFX_ASSERT(owners <= 1, "B1: warp slot owned by more than one workgroup")
          if (wstate[w] != WS_FREE) `SFX_ASSERT(owners == 1, "B1: resident warp slot without an owner")
          `SFX_ASSERT(int'(winf[w]) <= MAX_INFLIGHT, "B3: in-flight counter exceeds MAX_INFLIGHT")
          `SFX_ASSERT(wmem[w] <= winf[w], "B3: outstanding memory ops exceed in-flight ops")
        end
        `SFX_ASSERT(resident == owned, "B2: resident warp count != sum of workgroup memberships")
        for (int g = 0; g < NUM_WGS; g++) begin
          if (gvalid[g]) begin
            `SFX_ASSERT(gmembers[g] != '0, "B4: valid workgroup without members")
            `SFX_ASSERT((bar_arrived[g] & ~bar_live[g]) == '0, "A4: arrived warps not a subset of live warps")
            if (!gabort[g]) `SFX_ASSERT((bar_live[g] & ~gmembers[g]) == '0, "A4: live warps not a subset of members")
          end
        end
      end
      // B5 one outstanding fetch per warp
      if (imem_req_valid) `SFX_ASSERT(!fetch_pend[fw], "B5: second outstanding fetch for one warp")
      // B6 stack never written beyond its depth
      if (br_ev && br_flt == FLT_NONE && (d_p0_en || d_p1_en))
        `SFX_ASSERT(int'(wsp[bw]) + int'(d_p0_en) + int'(d_p1_en) <= STACK_DEPTH, "B6: stack push beyond STACK_DEPTH")
      // B7 workgroup slots: allocation needs a free workgroup slot and enough free warp slots
      if (alloc_ok) begin
        `SFX_ASSERT(!gvalid[free_g], "B7: workgroup slot allocated while valid")
        `SFX_ASSERT($countones(alloc_sel) == need, "B7: allocated warp count != required warps")
      end

      // ======================= Group C: eventual progress ===================
      // C1 bounded wait.  lag[w] = grants to OTHER warps made in cycles in which w was a candidate.
      //    It is reset only when w is granted or stops being a requester (its OWN state changed:
      //    hazard / drain / credit / not READY).  Cycles in which w cannot issue only because its
      //    backend class is busy neither count nor reset - that is exactly the case in which a
      //    single-pointer arbiter lets a sibling win every time (found by directed test
      //    fairness_class_gating_no_starvation, see docs/verification.md).
      for (int w = 0; w < NUM_WARPS; w++) begin
        if (!w_requester[w] || grant[w]) chk_wait[w] = 0;
        else if (w_cand[w] && (|grant)) begin
          chk_wait[w] = chk_wait[w] + 1;
          if (unsigned'(chk_wait[w]) > chk_max_wait) chk_max_wait = unsigned'(chk_wait[w]);
          `SFX_ASSERT(chk_wait[w] <= CHK_WAIT_BOUND, "C1: candidate warp starved beyond the policy bound")
        end
      end
      // C2 a complete barrier never persists; release only when every live warp is parked
      for (int g = 0; g < NUM_WGS; g++) begin
        if (gvalid[g] && !gabort[g])
          `SFX_ASSERT(!(bar_arrived[g] != '0 && bar_arrived[g] == bar_live[g]),
                      "C2: barrier complete but not released")
        if (rel_g[g]) begin
          for (int w = 0; w < NUM_WARPS; w++) begin
            if (bar_live[g][w] && !(ev_exit && int'(gw) == w))
              `SFX_ASSERT(wstate[w] == WS_BARRIER || (ev_bar && int'(gw) == w),
                          "C2: PREMATURE barrier release - a live warp has not arrived")
          end
          `SFX_ASSERT(!gabort[g], "C2: release of an aborting workgroup")
        end
      end
      // C3 kernel completion: done iff last launched and everything drained, within 2 cycles
      if (k_done_q) begin
        `SFX_ASSERT(k_last && gvalid == '0, "C3: kernel_done while work remains")
        for (int w = 0; w < NUM_WARPS; w++)
          `SFX_ASSERT(wstate[w] == WS_FREE && winf[w] == '0, "C3: kernel_done with a resident warp")
      end
      if (k_last && gvalid == '0 && !k_done_q) begin
        chk_done_wait = chk_done_wait + 1;
        `SFX_ASSERT(chk_done_wait <= 2, "C3: kernel completion not signalled within 2 cycles")
      end else chk_done_wait = 0;
      // C4 global bounded progress (under downstream fairness assumptions)
      if (m_resident != '0 && !chk_progress) chk_idle_cnt = chk_idle_cnt + 1; else chk_idle_cnt = 0;
      `SFX_ASSERT(chk_idle_cnt <= LIVENESS_LIMIT, "C4: no progress event for LIVENESS_LIMIT cycles with resident warps")
    end
  end

  final begin
    $display("[SFX-CHK] max_wait=%0d bound=%0d", chk_max_wait, CHK_WAIT_BOUND);
  end
