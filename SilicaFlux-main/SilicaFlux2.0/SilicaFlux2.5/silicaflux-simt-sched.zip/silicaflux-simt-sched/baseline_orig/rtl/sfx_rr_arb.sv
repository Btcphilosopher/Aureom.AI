// ============================================================================
// Deterministic rotating-priority (round-robin) arbiter.
//
//   grant   : one-hot, the first requester at or after `ptr` (cyclically)
//   on adv  : if any grant, ptr <= grant_index + 1 (mod N)
//
// Fairness: a requester that stays asserted is granted within N-1 *advances*
// (every advance moves ptr strictly closer to it in rotation order).
// ============================================================================
module sfx_rr_arb #(
  parameter int N = 8
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] req,
  input  logic         adv,        // grant is consumed this cycle
  output logic [N-1:0] grant
);
  localparam int PW = (N > 1) ? $clog2(N) : 1;
  logic [PW-1:0] ptr;

  always_comb begin
    grant = '0;
    for (int i = 0; i < N; i++) begin
      automatic int k = (int'(ptr) + i) % N;
      if (req[k] && (grant == '0)) grant[k] = 1'b1;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      ptr <= '0;
    end else if (adv) begin
      for (int k = 0; k < N; k++) begin
        if (grant[k]) ptr <= PW'((k + 1) % N);
      end
    end
  end
endmodule
