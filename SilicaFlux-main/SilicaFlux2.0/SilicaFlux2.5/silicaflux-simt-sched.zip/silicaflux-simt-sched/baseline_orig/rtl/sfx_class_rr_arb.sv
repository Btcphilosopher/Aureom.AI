// ============================================================================
// Two-level deterministic round-robin arbiter (the default scheduling policy).
//
//   level 1 : one round-robin arbiter per execution class (ALU, MEM, BR, CTRL);
//             the pointer of class c advances ONLY when a class-c warp is granted
//   level 2 : a round-robin arbiter over the classes that have a candidate
//
// Why two levels: a candidate set that is gated by backend readiness changes
// shape whenever a class is busy.  With ONE pointer, grants to warps of other
// classes keep moving the pointer while a ready warp is out of the candidate
// set, and the same sibling can win every time its class becomes ready again
// (the pointer is parked in front of the sibling): starvation.  With a pointer
// per class, only class-c grants move class-c's pointer, so a class-c
// candidate that stays requesting is granted after at most N-1 class-c grants.
//
// Bounded wait (counting grants made in cycles in which the warp is a
// candidate; candidacy persists until it is granted because be_rdy is
// non-retracting):
//     within the class :  <= N-1 grants of same-class warps
//     across classes   :  <= 3 grants of other classes before each class-c grant
//     total            :  <= 4N-1 grants          (all warps one class: N-1)
// ============================================================================
module sfx_class_rr_arb #(
  parameter int N = 8
) (
  input  logic                clk,
  input  logic                rst_n,
  input  logic [N-1:0]        req,
  input  logic [N-1:0][1:0]   cls,       // execution class of each requester
  output logic [N-1:0]        grant
);
  logic [3:0][N-1:0] req_c, g_c;
  logic [3:0]        cls_req, cls_grant;

  always_comb begin
    for (int c = 0; c < 4; c++) begin
      for (int i = 0; i < N; i++) req_c[c][i] = req[i] && (cls[i] == 2'(c));
      cls_req[c] = |req_c[c];
    end
    grant = '0;
    for (int c = 0; c < 4; c++) if (cls_grant[c]) grant |= g_c[c];
  end

  sfx_rr_arb #(.N(4)) u_cls (.clk(clk), .rst_n(rst_n), .req(cls_req), .adv(1'b1), .grant(cls_grant));

  generate
    for (genvar c = 0; c < 4; c++) begin : g_cls
      sfx_rr_arb #(.N(N)) u_c (.clk(clk), .rst_n(rst_n), .req(req_c[c]), .adv(cls_grant[c]), .grant(g_c[c]));
    end
  endgenerate
endmodule
