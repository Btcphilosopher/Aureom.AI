// ============================================================================
// Unit test of sfx_diverge_unit against vectors produced by the Python
// reference (tools/gen_diverge_vectors.py -> resolve_branch()).
//
// Vector line (all hex):
//   pc tgt_off11 rpc_off10 amask taken sp cur_rpc |
//   f_range f_ovf pop diverge n_pc n_mask n_rpc n_sp p0_en p0_pc p0_mask p0_rpc p1_en p1_pc p1_mask p1_rpc
// Fields that are architecturally "don't care" on a fault / pop are not compared.
// ============================================================================
`timescale 1ns/1ps
module tb_unit_diverge;
  parameter int PC_W        = 16;
  parameter int LANES       = 32;
  parameter int STACK_DEPTH = 8;
  localparam int SPW = $clog2(STACK_DEPTH + 1);

  logic [PC_W-1:0]  pc;
  logic [10:0]      tgt_off;
  logic [9:0]       rpc_off;
  logic [LANES-1:0] amask, taken;
  logic [SPW-1:0]   sp;
  logic [PC_W-1:0]  cur_rpc;
  logic f_range, f_ovf, pop, diverge, p0_en, p1_en;
  logic [PC_W-1:0]  n_pc, n_rpc, p0_pc, p0_rpc, p1_pc, p1_rpc;
  logic [LANES-1:0] n_mask, p0_mask, p1_mask;
  logic [SPW-1:0]   n_sp;

  sfx_diverge_unit #(.PC_W(PC_W), .LANES(LANES), .STACK_DEPTH(STACK_DEPTH)) dut (
    .pc(pc), .tgt_off(tgt_off), .rpc_off(rpc_off), .amask(amask), .taken_raw(taken), .sp(sp),
    .cur_rpc(cur_rpc), .fault_range(f_range), .fault_ovf(f_ovf), .pop(pop), .diverge(diverge),
    .n_pc(n_pc), .n_mask(n_mask), .n_rpc(n_rpc), .n_sp(n_sp),
    .p0_en(p0_en), .p0_pc(p0_pc), .p0_mask(p0_mask), .p0_rpc(p0_rpc),
    .p1_en(p1_en), .p1_pc(p1_pc), .p1_mask(p1_mask), .p1_rpc(p1_rpc));

  int fd, n, errors, nvec;
  // $fscanf targets: scanned into temporaries, then copied with ordinary assignments
  // (Verilator does not re-evaluate combinational logic for variables written by $fscanf)
  logic [PC_W-1:0]  t_pc, t_cur_rpc;
  logic [10:0]      t_tgt;
  logic [9:0]       t_rpc;
  logic [LANES-1:0] t_amask, t_taken;
  logic [SPW-1:0]   t_sp;
  string vf;
  // expected
  logic [PC_W-1:0]  e_pc, e_rpc, e_p0pc, e_p0rpc, e_p1pc, e_p1rpc;
  logic [LANES-1:0] e_mask, e_p0m, e_p1m;
  logic [SPW-1:0]   e_sp;
  logic e_range, e_ovf, e_pop, e_div, e_p0en, e_p1en;
  int cnt_fault, cnt_pop, cnt_div, cnt_merge;

  initial begin
    errors = 0; nvec = 0; cnt_fault = 0; cnt_pop = 0; cnt_div = 0; cnt_merge = 0;
    if (!$value$plusargs("vec=%s", vf)) $fatal(1, "+vec=<file> required");
    fd = $fopen(vf, "r");
    if (fd == 0) $fatal(1, "cannot open %s", vf);
    while (!$feof(fd)) begin
      n = $fscanf(fd, "%h %h %h %h %h %h %h | %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h\n",
                  t_pc, t_tgt, t_rpc, t_amask, t_taken, t_sp, t_cur_rpc,
                  e_range, e_ovf, e_pop, e_div, e_pc, e_mask, e_rpc, e_sp,
                  e_p0en, e_p0pc, e_p0m, e_p0rpc, e_p1en, e_p1pc, e_p1m, e_p1rpc);
      if (n == 23) begin
        pc = t_pc; tgt_off = t_tgt; rpc_off = t_rpc; amask = t_amask; taken = t_taken; sp = t_sp; cur_rpc = t_cur_rpc;
        #1;
        nvec++;
        if ($test$plusargs("dbg") && nvec < 14)
          $display("[DIV-UNIT-DBG] #%0d in: pc=%h tgt=%h rpc=%h am=%h tk=%h sp=%0d crpc=%h | out: range=%b ovf=%b pop=%b div=%b n_pc=%h n_sp=%0d p0=%b p1=%b | exp range=%b ovf=%b pop=%b", nvec, pc, tgt_off, rpc_off, amask, taken, sp, cur_rpc, f_range, f_ovf, pop, diverge, n_pc, n_sp, p0_en, p1_en, e_range, e_ovf, e_pop);
        if (f_range !== e_range || f_ovf !== e_ovf) begin
          $display("[DIV-UNIT] FAIL #%0d fault flags rtl=%b%b exp=%b%b  (pc=%h tgt=%h rpc=%h am=%h tk=%h sp=%0d crpc=%h)",
                   nvec, f_range, f_ovf, e_range, e_ovf, pc, tgt_off, rpc_off, amask, taken, sp, cur_rpc);
          errors++;
        end else if (e_range) begin
          cnt_fault++;
        end else begin
          if (diverge !== e_div) begin $display("[DIV-UNIT] FAIL #%0d diverge rtl=%b exp=%b", nvec, diverge, e_div); errors++; end
          if (e_ovf) cnt_fault++;
          else begin
            if (pop !== e_pop) begin $display("[DIV-UNIT] FAIL #%0d pop rtl=%b exp=%b", nvec, pop, e_pop); errors++; end
            if (n_sp !== e_sp) begin $display("[DIV-UNIT] FAIL #%0d n_sp rtl=%0d exp=%0d", nvec, n_sp, e_sp); errors++; end
            if (e_pop) cnt_pop++;
            else begin
              if (n_pc !== e_pc || n_mask !== e_mask || n_rpc !== e_rpc) begin
                $display("[DIV-UNIT] FAIL #%0d ctx rtl=(%h,%h,%h) exp=(%h,%h,%h)", nvec, n_pc, n_mask, n_rpc, e_pc, e_mask, e_rpc);
                errors++;
              end
            end
            if (p0_en !== e_p0en || p1_en !== e_p1en) begin
              $display("[DIV-UNIT] FAIL #%0d push enables rtl=%b%b exp=%b%b", nvec, p0_en, p1_en, e_p0en, e_p1en); errors++;
            end else begin
              if (e_p0en && (p0_pc !== e_p0pc || p0_mask !== e_p0m || p0_rpc !== e_p0rpc)) begin
                $display("[DIV-UNIT] FAIL #%0d push0 rtl=(%h,%h,%h) exp=(%h,%h,%h)", nvec, p0_pc, p0_mask, p0_rpc, e_p0pc, e_p0m, e_p0rpc); errors++;
              end
              if (e_p1en && (p1_pc !== e_p1pc || p1_mask !== e_p1m || p1_rpc !== e_p1rpc)) begin
                $display("[DIV-UNIT] FAIL #%0d push1 rtl=(%h,%h,%h) exp=(%h,%h,%h)", nvec, p1_pc, p1_mask, p1_rpc, e_p1pc, e_p1m, e_p1rpc); errors++;
              end
            end
            if (e_div) begin cnt_div++; if (!e_p0en) cnt_merge++; end
          end
        end
        if (errors > 20) $fatal(1, "too many errors");
      end
    end
    $fclose(fd);
    $display("[DIV-UNIT] %0d vectors (%0d faults, %0d pops, %0d divergences, %0d merged/elided), %0d errors",
             nvec, cnt_fault, cnt_pop, cnt_div, cnt_merge, errors);
    if (errors != 0 || nvec == 0) $fatal(1, "diverge unit test failed");
    $display("[DIV-UNIT] PASS LANES=%0d STACK_DEPTH=%0d", LANES, STACK_DEPTH);
    $finish;
  end
endmodule
