// ============================================================================
// Instruction-memory model (testbench).
//   * one request accepted per cycle at most, latency LAT_MIN..LAT_MAX cycles,
//     responses may be reordered between warps (tags), one response per cycle;
//   * req_ready obeys the NON-RETRACTING rule of the downstream fairness
//     assumption: once high it stays high until a request is accepted;
//   * PCs >= PROG_LEN answer with rsp_err (fetch fault).
// ============================================================================
module sfx_imem_model #(
  parameter int NUM_WARPS = 8,
  parameter int PC_W      = 16,
  parameter int PROG_WORDS = 4096
) (
  input  logic                         clk,
  input  logic                         rst_n,
  input  logic                         req_valid,
  input  logic [PC_W-1:0]              req_pc,
  input  logic [$clog2(NUM_WARPS)-1:0] req_tag,
  output logic                         req_ready,
  output logic                         rsp_valid,
  output logic [$clog2(NUM_WARPS)-1:0] rsp_tag,
  output logic [31:0]                  rsp_data,
  output logic                         rsp_err
);
  localparam int WID_W = $clog2(NUM_WARPS);

  logic [31:0] prog [PROG_WORDS];
  int          prog_len;
  int          lat_min, lat_max, busy_max;
  int unsigned rng;

  bit          p_v   [NUM_WARPS];
  int          p_pc  [NUM_WARPS];
  longint      p_rdy [NUM_WARPS];
  longint      cyc;
  int          busy;
  int          fetches;
  int          spurious_pct;

  function automatic int unsigned rnd();
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    return rng;
  endfunction
  function automatic int rnd_range(input int lo, input int hi);
    if (hi <= lo) return lo;
    return lo + int'(rnd() % (hi - lo + 1));
  endfunction

  initial begin
    string pf;
    int    prof, seed;
    for (int i = 0; i < PROG_WORDS; i++) prog[i] = 32'h0;
    prog_len = 0;
    if ($value$plusargs("prog=%s", pf)) $readmemh(pf, prog);
    if (!$value$plusargs("proglen=%d", prog_len)) prog_len = 0;
    if (!$value$plusargs("profile=%d", prof)) prof = 0;
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("spurious=%d", spurious_pct)) spurious_pct = 0;
    rng = 32'h9E3779B9 ^ unsigned'(seed * 7919 + 13);
    if (rng == 0) rng = 1;
    case (prof)
      0, 4, 5: begin lat_min = 1; lat_max = 1;  busy_max = 0; end
      1:       begin lat_min = 1; lat_max = 4;  busy_max = 1; end
      2:       begin lat_min = 1; lat_max = 12; busy_max = 3; end
      default: begin lat_min = 2; lat_max = 6;  busy_max = 2; end
    endcase
  end

  // request ready: non-retracting (drops only after an accepted request)
  assign req_ready = (busy == 0);

  logic [WID_W-1:0] pick;
  logic             have;
  int               ncand;

  always @(posedge clk) begin
    if (!rst_n) begin
      cyc <= 0; busy <= 0; fetches <= 0;
      for (int i = 0; i < NUM_WARPS; i++) p_v[i] = 1'b0;
      rsp_valid <= 1'b0; rsp_tag <= '0; rsp_data <= '0; rsp_err <= 1'b0;
    end else begin
      cyc <= cyc + 1;
      // ---- accept request ----
      if (req_valid && req_ready) begin
        if (p_v[req_tag]) $fatal(1, "imem model: second outstanding fetch for tag %0d", req_tag);
        p_v[req_tag]   = 1'b1;
        p_pc[req_tag]  = int'(req_pc);
        p_rdy[req_tag] = cyc + rnd_range(lat_min, lat_max);
        busy <= rnd_range(0, busy_max);
        fetches <= fetches + 1;
      end else if (busy > 0) begin
        busy <= busy - 1;
      end
      // ---- present one response next cycle (pick any entry that is due) ----
      rsp_valid <= 1'b0;
      // hostile downstream: response for a tag that has no outstanding request
      if (spurious_pct > 0 && int'(rnd() % 100) < spurious_pct) begin
        automatic int t2 = int'(rnd() % unsigned'(NUM_WARPS));
        if (!p_v[t2] && !(req_valid && req_ready && int'(req_tag) == t2)) begin
          rsp_valid <= 1'b1; rsp_tag <= WID_W'(t2); rsp_data <= rnd(); rsp_err <= 1'b0;
        end
      end
      ncand = 0;
      for (int i = 0; i < NUM_WARPS; i++)
        if (p_v[i] && p_rdy[i] <= cyc + 1) ncand++;
      if (ncand > 0) begin
        automatic int sel = int'(rnd() % unsigned'(ncand));
        for (int i = 0; i < NUM_WARPS; i++) begin
          if (p_v[i] && p_rdy[i] <= cyc + 1) begin
            if (sel == 0) begin
              rsp_valid <= 1'b1;
              rsp_tag   <= WID_W'(i);
              rsp_err   <= (p_pc[i] >= prog_len);
              rsp_data  <= (p_pc[i] < prog_len) ? prog[p_pc[i]] : 32'h0;
              p_v[i] = 1'b0;
              sel = -1;
            end else if (sel > 0) sel--;
          end
        end
      end
    end
  end

  logic unused;
  assign unused = &{1'b0, pick, have};
endmodule
