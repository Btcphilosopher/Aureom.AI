// ============================================================================
// Downstream-assumption monitor (testbench).
//
// The liveness guarantee of the control unit is conditional on these
// assumptions about everything it talks to (docs/architecture.md, "Fairness
// assumptions").  This monitor CHECKS them on the live interfaces so that a
// violating downstream is blamed explicitly ("ASSUMPTION VIOLATION") instead
// of being reported as a control-unit bug.
//
//   D1  imem_req_ready / be_rdy[c] are non-retracting: once high they stay
//       high until a request / instruction of that class is accepted.
//   D2  every fetch request receives exactly one response within
//       IMEM_MAX_LAT cycles.
//   D3  every issued backend instruction receives exactly one completion;
//       a warp with instructions in flight sees a completion at least every
//       CMP_MAX_LAT cycles.
//   D4  completions are only presented for in-flight instructions.
// Observed maxima are reported at the end of the run.
// ============================================================================
module sfx_assume_monitor #(
  parameter int NUM_WARPS    = 8,
  parameter int IMEM_MAX_LAT = 256,
  parameter int CMP_MAX_LAT  = 4000
) (
  input logic                         clk,
  input logic                         rst_n,
  input logic                         imem_req_valid,
  input logic [$clog2(NUM_WARPS)-1:0] imem_req_tag,
  input logic                         imem_req_ready,
  input logic                         imem_rsp_valid,
  input logic [$clog2(NUM_WARPS)-1:0] imem_rsp_tag,
  input logic                         be_valid,
  input logic [1:0]                   be_cls,
  input logic [$clog2(NUM_WARPS)-1:0] be_warp,
  input logic [2:0]                   be_rdy,
  input logic                         cmp_valid,
  input logic [$clog2(NUM_WARPS)-1:0] cmp_warp
);
  logic       prev_ireq_rdy, prev_ireq_fire;
  logic [2:0] prev_be_rdy, prev_be_fire;
  int         fpend  [NUM_WARPS];       // age of outstanding fetch (-1 none)
  int         inf    [NUM_WARPS];       // in-flight backend instructions
  int         since  [NUM_WARPS];       // cycles since last completion / first in-flight
  int         max_imem_lat, max_cmp_gap;

  bit hostile;
  initial begin max_imem_lat = 0; max_cmp_gap = 0; hostile = $test$plusargs("spurious"); end

  always @(posedge clk) begin
    if (!rst_n) begin
      prev_ireq_rdy <= 1'b0; prev_ireq_fire <= 1'b0; prev_be_rdy <= '0; prev_be_fire <= '0;
      for (int w = 0; w < NUM_WARPS; w++) begin fpend[w] = -1; inf[w] = 0; since[w] = 0; end
    end else begin
      // ---- D1 non-retracting readies ----
      if (prev_ireq_rdy && !prev_ireq_fire && !imem_req_ready)
        $fatal(1, "ASSUMPTION VIOLATION (D1): imem_req_ready retracted without an accepted request");
      for (int c = 0; c < 3; c++)
        if (prev_be_rdy[c] && !prev_be_fire[c] && !be_rdy[c])
          $fatal(1, "ASSUMPTION VIOLATION (D1): be_rdy[%0d] retracted without an accepted instruction", c);
      prev_ireq_rdy  <= imem_req_ready;
      prev_ireq_fire <= imem_req_valid && imem_req_ready;
      prev_be_rdy    <= be_rdy;
      for (int c = 0; c < 3; c++) prev_be_fire[c] <= be_valid && (int'(be_cls) == c);

      // ---- D2 fetch response ----
      for (int w = 0; w < NUM_WARPS; w++) if (fpend[w] >= 0) fpend[w] = fpend[w] + 1;
      if (imem_req_valid && imem_req_ready) fpend[imem_req_tag] = 0;
      if (imem_rsp_valid) begin
        if (fpend[imem_rsp_tag] < 0 && !hostile)
          $fatal(1, "ASSUMPTION VIOLATION (D2): fetch response without an outstanding request (tag %0d)", imem_rsp_tag);
        if (fpend[imem_rsp_tag] > max_imem_lat) max_imem_lat = fpend[imem_rsp_tag];
        if (fpend[imem_rsp_tag] >= 0) fpend[imem_rsp_tag] = -1;
      end
      for (int w = 0; w < NUM_WARPS; w++)
        if (fpend[w] > IMEM_MAX_LAT)
          $fatal(1, "ASSUMPTION VIOLATION (D2): fetch for tag %0d unanswered for %0d cycles", w, fpend[w]);

      // ---- D3/D4 completions ----
      for (int w = 0; w < NUM_WARPS; w++) if (inf[w] > 0) since[w] = since[w] + 1;
      if (be_valid) begin
        if (inf[be_warp] == 0) since[be_warp] = 0;
        inf[be_warp] = inf[be_warp] + 1;
      end
      if (cmp_valid) begin
        if (inf[cmp_warp] <= 0 && !hostile)
          $fatal(1, "ASSUMPTION VIOLATION (D4): completion for warp %0d with nothing in flight", cmp_warp);
        if (inf[cmp_warp] > 0) begin
          inf[cmp_warp] = inf[cmp_warp] - 1;
          if (since[cmp_warp] > max_cmp_gap) max_cmp_gap = since[cmp_warp];
          since[cmp_warp] = 0;
        end
      end
      for (int w = 0; w < NUM_WARPS; w++)
        if (inf[w] > 0 && since[w] > CMP_MAX_LAT)
          $fatal(1, "ASSUMPTION VIOLATION (D3): warp %0d has had instructions in flight for %0d cycles without a completion", w, since[w]);
    end
  end

  function automatic int get_max_imem_lat(); return max_imem_lat; endfunction
  function automatic int get_max_cmp_gap();  return max_cmp_gap;  endfunction
endmodule
