// ============================================================================
// Unit test of the scheduling arbiters against independent behavioural models
// and against the bounded-wait theorems.
//
//   KIND = 0 : sfx_class_rr_arb (default round-robin policy)
//   KIND = 1 : sfx_age_arb      (age-based policy with starvation guard)
//
// The stimulus models what the control unit does to the arbiter:
//   * every slot has a buffered instruction of an execution class (ALU/MEM/BR/CTRL);
//   * a slot REQUESTS only if its instruction has no hazard AND its class is ready;
//   * after a grant of class c the class is BUSY for a random window (0..40 cycles),
//     i.e. the candidate set changes shape as a function of the arbiter's own
//     grants (non-retracting ready: it only drops after a grant);
// This feedback is what exposed the single-pointer starvation hole.
//
// Checks per cycle: exact grant vs model, one-hot, work-conserving, and
//   lag[i] = grants to OTHER slots in cycles where i was a candidate
//   (reset when i is granted or stops being a requester)
//   lag <= 4N-1 (class RR) or STARVE_LIMIT + N (age).
//
// Timing discipline: inputs change at the falling edge, outputs are sampled
// 4 ns later (before the rising edge), models advance as the RTL registers will.
// ============================================================================
`timescale 1ns/1ps
module tb_unit_arb;
  parameter int KIND         = 0;
  parameter int N            = 8;
  parameter int STARVE_LIMIT = 16;
  parameter int CYCLES       = 300000;

  logic clk = 0;
  logic rst_n = 0;
  always #5 clk = ~clk;

  logic [N-1:0]      req, wait_en, alloc;
  logic [N-1:0][1:0] cls;
  logic [N-1:0]      grant;

  generate
    if (KIND == 0) begin : g_rr
      sfx_class_rr_arb #(.N(N)) u_dut (.clk(clk), .rst_n(rst_n), .req(req), .cls(cls), .grant(grant));
    end else begin : g_age
      sfx_age_arb #(.N(N), .STARVE_LIMIT(STARVE_LIMIT)) u_dut (
        .clk(clk), .rst_n(rst_n), .req(req), .wait_en(wait_en), .alloc(alloc), .adv(1'b1), .grant(grant));
    end
  endgenerate

  // ---------------- model state ----------------
  int          ptr_cls, ptr_c [4];
  longint      seqno [N];
  longint      next_seq;
  int          wcnt  [N];
  int          lag   [N];
  int          busy  [4];
  int          hz    [N];                 // remaining hazard cycles
  int          cur_cls [N];
  bit          resident [N];
  bit          ready_i  [N];              // wait_en
  longint      grants_per_slot [N];
  int unsigned rng;
  int          errors, max_lag, urgent_grants, total_grants, bound;
  bit          used_urgent;
  bit          chk_fixed;                 // directed check of an exact expected grant
  logic [N-1:0] fixed_exp;

  function automatic int unsigned rnd();
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng;
  endfunction

  // ---- model of the class round-robin ----
  function automatic logic [N-1:0] model_rr();
    logic [N-1:0] g = '0;
    int gc = -1;
    for (int i = 0; i < 4 && gc < 0; i++) begin
      int c = (ptr_cls + i) % 4;
      for (int k = 0; k < N; k++) if (req[k] && int'(cls[k]) == c) gc = c;
    end
    if (gc >= 0) begin
      bit found = 0;
      for (int i = 0; i < N && !found; i++) begin
        int k = (ptr_c[gc] + i) % N;
        if (req[k] && int'(cls[k]) == gc) begin g[k] = 1'b1; found = 1; end
      end
    end
    return g;
  endfunction

  // ---- model of the age policy (allocation sequence numbers, not a matrix) ----
  function automatic logic [N-1:0] model_age();
    logic [N-1:0] sel, urg, g;
    longint best = -1;
    urg = '0; g = '0;
    for (int i = 0; i < N; i++) if (req[i] && STARVE_LIMIT != 0 && wcnt[i] >= STARVE_LIMIT) urg[i] = 1'b1;
    used_urgent = (urg != '0);
    sel = (urg != '0) ? urg : req;
    for (int i = 0; i < N; i++)
      if (sel[i] && (best < 0 || seqno[i] < best)) begin best = seqno[i]; g = '0; g[i] = 1'b1; end
    return g;
  endfunction

  // one clock: compare, check theorems, advance models
  task automatic step(input string phase);
    logic [N-1:0] e;
    int nalloc;
    #4;
    e = (KIND == 0) ? model_rr() : model_age();
    if (grant !== e) begin $display("[ARB-UNIT] FAIL %s grant %b expected %b (req %b)", phase, grant, e, req); errors++; end
    if (chk_fixed && grant !== fixed_exp) begin $display("[ARB-UNIT] FAIL directed %s grant %b expected %b", phase, grant, fixed_exp); errors++; end
    if (!$onehot0(grant)) begin $display("[ARB-UNIT] FAIL grant not one-hot"); errors++; end
    if ((grant & ~req) != 0) begin $display("[ARB-UNIT] FAIL grant outside request"); errors++; end
    if ((grant != 0) != (req != 0)) begin $display("[ARB-UNIT] FAIL not work-conserving"); errors++; end
    // ---- bounded wait theorem ----
    for (int i = 0; i < N; i++) begin
      if (!ready_i[i] || hz[i] > 0 || grant[i]) lag[i] = 0;
      else if (req[i] && grant != 0) begin
        lag[i]++;
        if (lag[i] > max_lag) max_lag = lag[i];
        if (lag[i] > bound) begin $display("[ARB-UNIT] FAIL %s starvation: slot %0d lag %0d > %0d", phase, i, lag[i], bound); errors++; end
      end
    end
    if (grant != 0) begin total_grants++; if (KIND == 1 && used_urgent) urgent_grants++; end
    for (int i = 0; i < N; i++) if (grant[i]) grants_per_slot[i]++;
    // ---- advance models ----
    if (KIND == 0) begin
      for (int i = 0; i < N; i++) if (grant[i]) begin
        ptr_cls = (cur_cls[i] + 1) % 4;
        ptr_c[cur_cls[i]] = (i + 1) % N;
      end
    end else begin
      nalloc = 0;
      for (int i = 0; i < N; i++) if (alloc[i]) begin seqno[i] = next_seq + nalloc; nalloc++; end
      next_seq += nalloc;
      for (int i = 0; i < N; i++) begin
        if (!wait_en[i] || grant[i] || alloc[i]) wcnt[i] = 0;
        else if (grant != 0 && req[i] && wcnt[i] < STARVE_LIMIT + 1) wcnt[i]++;
      end
    end
    // ---- environment reacts to the grant (class busy window, hazards) ----
    for (int c = 0; c < 4; c++) if (busy[c] > 0) busy[c]--;
    for (int i = 0; i < N; i++) if (hz[i] > 0) hz[i]--;
    for (int i = 0; i < N; i++) if (grant[i]) begin
      int pick = int'(rnd() % 8);
      if (cur_cls[i] != 3)
        busy[cur_cls[i]] = (pick < 3) ? 0 : (pick < 5) ? 3 : (pick < 7) ? 6 : (rnd() % 2 ? 20 : 40);
      // next instruction of the slot
      cur_cls[i] = int'(rnd() % 4);
      hz[i] = (rnd() % 100 < 20) ? int'(rnd() % 6) : 0;
      ready_i[i] = (rnd() % 100 < 90);                       // sometimes the slot leaves READY for a while
    end
    @(negedge clk);
  endtask

  // build the inputs of the next cycle from the environment state
  task automatic drive_env(input logic [N-1:0] a, input int pr);
    for (int i = 0; i < N; i++) begin
      req[i]     = resident[i] && ready_i[i] && hz[i] == 0 && (cur_cls[i] == 3 || busy[cur_cls[i]] == 0)
                   && (rnd() % 100 < pr);
      wait_en[i] = resident[i] && ready_i[i];
      cls[i]     = 2'(cur_cls[i]);
    end
    alloc = a;
  endtask

  initial begin
    rng = 32'hDEADBEEF + KIND; errors = 0; max_lag = 0; urgent_grants = 0; total_grants = 0;
    bound = (KIND == 0) ? (4 * N - 1) : (STARVE_LIMIT + N);
    ptr_cls = 0; next_seq = 0; chk_fixed = 0;
    for (int c = 0; c < 4; c++) begin ptr_c[c] = 0; busy[c] = 0; end
    for (int i = 0; i < N; i++) begin
      seqno[i] = 0; wcnt[i] = 0; lag[i] = 0; hz[i] = 0; cur_cls[i] = 0; resident[i] = 0; ready_i[i] = 0;
      grants_per_slot[i] = 0;
    end
    req = '0; wait_en = '0; alloc = '0; cls = '0;
    repeat (3) @(posedge clk);
    rst_n = 1;
    @(negedge clk);

    // ---------- directed 1: allocate all slots in one cycle ----------
    for (int i = 0; i < N; i++) begin resident[i] = 1; ready_i[i] = 1; end
    drive_env('1, 100); req = '0; wait_en = '0; alloc = '1; step("alloc-all");

    // ---------- directed 2: every slot always requests, one class -> plain round robin ----------
    for (int i = 0; i < N; i++) cur_cls[i] = 0;
    for (int k = 0; k < 3 * N; k++) begin
      req = '1; wait_en = '1; alloc = '0; for (int i = 0; i < N; i++) cls[i] = 2'(0);
      chk_fixed = (KIND == 0); fixed_exp = N'(1) << (k % N);     // 0,1,2,..,N-1,0,...
      step("all-requesting");
      chk_fixed = 0;
      for (int i = 0; i < N; i++) begin cur_cls[i] = 0; hz[i] = 0; ready_i[i] = 1; end
      for (int c = 0; c < 4; c++) busy[c] = 0;
    end

    // ---------- directed 3: the class-gating scenario (two MEM slots + always-ready ALU slots) ----------
    for (int i = 0; i < N; i++) begin cur_cls[i] = (i < 2) ? 1 : 0; hz[i] = 0; ready_i[i] = 1; end
    for (int c = 0; c < 4; c++) busy[c] = 0;
    for (int k = 0; k < 2000; k++) begin
      for (int i = 0; i < N; i++) begin
        req[i] = resident[i] && (cur_cls[i] != 1 || busy[1] == 0);
        wait_en[i] = 1'b1; cls[i] = 2'(cur_cls[i]);
      end
      alloc = '0;
      step("class-gating");
      // keep the roles fixed; MEM class busy window is 6 after each MEM grant (done in step via random) -> force it
      for (int i = 0; i < N; i++) if (i < 2) cur_cls[i] = 1; else cur_cls[i] = 0;
      for (int i = 0; i < N; i++) if (i >= 2) cur_cls[i] = 0;
    end
    for (int i = 0; i < N; i++) if (i < 2 && grants_per_slot[i] == 0) begin
      $display("[ARB-UNIT] FAIL slot %0d never granted in the class-gating scenario", i); errors++;
    end

    // ---------- randomised comparison ----------
    for (int cyc = 0; cyc < CYCLES; cyc++) begin
      logic [N-1:0] n_alloc;
      int pr = ((cyc / 900) % 3 == 0) ? 100 : ((cyc / 900) % 3 == 1) ? 85 : 55;
      n_alloc = '0;
      for (int i = 0; i < N; i++) begin
        if (!resident[i] && rnd() % 100 < 4) begin
          n_alloc[i] = 1'b1; resident[i] = 1'b1; ready_i[i] = 0; hz[i] = 0; cur_cls[i] = int'(rnd() % 4);
        end else if (resident[i] && rnd() % 100 < 1) begin
          resident[i] = 1'b0; ready_i[i] = 0;
        end else if (resident[i] && !ready_i[i] && rnd() % 100 < 15) ready_i[i] = 1'b1;
      end
      drive_env(n_alloc, pr);
      for (int i = 0; i < N; i++) if (n_alloc[i]) begin req[i] = 1'b0; wait_en[i] = 1'b0; end
      step("random");
    end

    $display("[ARB-UNIT] KIND=%0d N=%0d: %0d grants, max lag %0d (bound %0d)%s", KIND, N, total_grants, max_lag, bound,
             KIND == 1 ? $sformatf(", %0d urgent-promoted", urgent_grants) : "");
    if (KIND == 1 && urgent_grants == 0) begin $display("[ARB-UNIT] FAIL starvation guard was never exercised"); errors++; end
    if (errors == 0) $display("[ARB-UNIT] PASS KIND=%0d N=%0d STARVE_LIMIT=%0d", KIND, N, STARVE_LIMIT);
    else             $display("[ARB-UNIT] FAILED with %0d errors", errors);
    if (errors != 0) $fatal(1, "arbiter unit test failed");
    $finish;
  end
endmodule
