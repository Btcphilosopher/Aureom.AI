// ============================================================================
// Behavioural backend model (testbench): lane register files, ALUs, global and
// shared memory, with randomised latency / back-pressure.
//
// It implements the DOWNSTREAM CONTRACT that the control unit relies on
// (docs/architecture.md section "Backend contract"):
//   BC1 operands are read at the issue edge (so the scoreboard alone must
//       prevent RAW/WAW hazards - results are committed at completion time);
//   BC2 every accepted instruction yields exactly one completion;
//   BC3 memory operations of ONE warp are performed in program order;
//   BC4 one completion per cycle;
//   BC5 be_rdy[c] is NON-RETRACTING: once high it stays high until an
//       instruction of class c is accepted;
//   BC6 registers of a newly allocated warp slot read as zero;
//   BC7 a branch outcome (cmp_taken) names only lanes of the issued mask - the control unit does
//       NOT rely on it (it intersects with the active mask); +spurious violates BC7 on purpose.
// ISA semantics are re-implemented here independently of the RTL decoder.
// ============================================================================
module sfx_be_model #(
  parameter int NUM_WARPS  = 8,
  parameter int WARP_SIZE  = 32,
  parameter int PC_W       = 16,
  parameter int WG_ID_W    = 8,
  parameter int GMEM_WORDS = 16384,
  parameter int SMEM_WORDS = 256,
  parameter int SMEM_WGS   = 64,
  parameter int NINF       = 256
) (
  input  logic                         clk,
  input  logic                         rst_n,
  input  logic                         be_valid,
  input  logic [1:0]                   be_cls,
  input  logic [$clog2(NUM_WARPS)-1:0] be_warp,
  input  logic [WG_ID_W-1:0]           be_wg_id,
  input  logic [$clog2(NUM_WARPS)-1:0] be_widx,
  input  logic [PC_W-1:0]              be_pc,
  input  logic [31:0]                  be_instr,
  input  logic [WARP_SIZE-1:0]         be_mask,
  output logic [2:0]                   be_rdy,
  output logic                         cmp_valid,
  output logic [$clog2(NUM_WARPS)-1:0] cmp_warp,
  output logic                         cmp_wr,
  output logic [4:0]                   cmp_rd,
  output logic                         cmp_mem,
  output logic                         cmp_br,
  output logic [WARP_SIZE-1:0]         cmp_taken,
  input  logic [NUM_WARPS-1:0][2:0]    dbg_wstate
);
  localparam int WID_W = $clog2(NUM_WARPS);

  // ---- architectural state ----
  logic [31:0] rf   [NUM_WARPS][WARP_SIZE][32];
  logic [31:0] gmem [GMEM_WORDS];
  logic [31:0] smem [SMEM_WGS][SMEM_WORDS];

  // ---- in-flight table ----
  bit          inf_v    [NINF];
  int          inf_warp [NINF];
  int          inf_kind [NINF];        // 0 alu, 1 ld, 2 st, 3 lds, 4 sts, 5 br
  int          inf_rd   [NINF];
  bit          inf_wr   [NINF];
  int          inf_wg   [NINF];
  longint      inf_rdy  [NINF];
  longint      inf_seq  [NINF];
  logic [WARP_SIZE-1:0] inf_mask  [NINF];
  logic [WARP_SIZE-1:0] inf_taken [NINF];
  logic [31:0] inf_val  [NINF][WARP_SIZE];   // ALU result / store data
  logic [31:0] inf_addr [NINF][WARP_SIZE];
  longint      last_mem_rdy [NUM_WARPS];

  // ---- profile ----
  int alu_lo, alu_hi, mul_lo, mul_hi, ld_lo, ld_hi, st_lo, st_hi, lds_lo, lds_hi, br_lo, br_hi;
  int busy_max, cstall_pct, mem_cap, spurious_pct, mem_busy_fixed;
  int mi [NUM_WARPS];            // model's own in-flight count per warp
  int unsigned rng;
  longint cyc, seq;
  int cons_stall;
  int busy [3];
  int mem_outstanding;
  logic [2:0] prev_busy_free;
  logic [2:0] st_prev [NUM_WARPS];
  logic [2:0] ws_prev [NUM_WARPS];

  function automatic int unsigned rnd();
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    return rng;
  endfunction
  function automatic int rnd_range(input int lo, input int hi);
    if (hi <= lo) return lo;
    return lo + int'(rnd() % unsigned'(hi - lo + 1));
  endfunction

  initial begin
    int prof, seed;
    if (!$value$plusargs("profile=%d", prof)) prof = 0;
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("spurious=%d", spurious_pct)) spurious_pct = 0;
    rng = 32'hC0FFEE11 ^ unsigned'(seed * 104729 + 7);
    if (rng == 0) rng = 1;
    mem_cap = 1000; mem_busy_fixed = 0;
    case (prof)
      0: begin alu_lo=1; alu_hi=1; mul_lo=1; mul_hi=1; ld_lo=2; ld_hi=2; st_lo=2; st_hi=2;
               lds_lo=2; lds_hi=2; br_lo=1; br_hi=1; busy_max=0; cstall_pct=0; end
      1: begin alu_lo=1; alu_hi=3; mul_lo=3; mul_hi=6; ld_lo=4; ld_hi=14; st_lo=3; st_hi=9;
               lds_lo=2; lds_hi=5; br_lo=1; br_hi=4; busy_max=2; cstall_pct=10; end
      2: begin alu_lo=1; alu_hi=8; mul_lo=4; mul_hi=14; ld_lo=10; ld_hi=70; st_lo=5; st_hi=40;
               lds_lo=3; lds_hi=12; br_lo=2; br_hi=10; busy_max=6; cstall_pct=30; end
      4, 5: begin alu_lo=1; alu_hi=1; mul_lo=1; mul_hi=1; ld_lo=2; ld_hi=2; st_lo=2; st_hi=2;
               lds_lo=2; lds_hi=2; br_lo=1; br_hi=1; busy_max=0; cstall_pct=0; mem_busy_fixed = (prof == 5) ? 40 : 6; end
      default: begin alu_lo=1; alu_hi=2; mul_lo=2; mul_hi=4; ld_lo=30; ld_hi=120; st_lo=20; st_hi=80;
               lds_lo=10; lds_hi=30; br_lo=1; br_hi=3; busy_max=1; cstall_pct=5; mem_cap=2; end
    endcase
  end

  // ------------------------------------------------------------------------
  function automatic logic [31:0] rreg(input int w, input int l, input int r);
    return (r == 0) ? 32'h0 : rf[w][l][r];
  endfunction

  function automatic logic [31:0] sext_n(input logic [31:0] v, input int bits);
    logic [31:0] m;
    m = 32'hFFFFFFFF << bits;
    return v[bits-1] ? (v | m) : (v & ~m);
  endfunction

  // ---- contract BC5: ready never retracts without an accept (registered, set at the end of the edge) ----

  int          pres_idx;       // entry presented this cycle (-1 none)

  always @(posedge clk) begin
    if (!rst_n) begin
      cyc = 0; seq = 0; cons_stall = 0; mem_outstanding = 0; pres_idx = -1;
      for (int i = 0; i < NINF; i++) inf_v[i] = 1'b0;
      for (int w = 0; w < NUM_WARPS; w++) begin last_mem_rdy[w] = 0; ws_prev[w] = 3'd0; mi[w] = 0; end
      for (int c = 0; c < 3; c++) busy[c] = 0;
      cmp_valid <= 1'b0; cmp_warp <= '0; cmp_wr <= 1'b0; cmp_rd <= '0;
      cmp_mem <= 1'b0; cmp_br <= 1'b0; cmp_taken <= '0;
      be_rdy <= 3'b111;
    end else begin
      cyc = cyc + 1;

      // ---- B6: new warp slot -> registers read as zero ----
      for (int w = 0; w < NUM_WARPS; w++) begin
        if (ws_prev[w] == 3'd0 && dbg_wstate[w] != 3'd0) begin
          for (int l = 0; l < WARP_SIZE; l++)
            for (int r = 0; r < 32; r++) rf[w][l][r] = 32'h0;
        end
        ws_prev[w] = dbg_wstate[w];
      end

      // ---- (2) accept an issued instruction: BC1 operands read NOW ----
      if (be_valid) begin
        automatic int e = -1;
        automatic int op = int'(be_instr[31:26]);
        automatic int ra = int'(be_instr[25:21]);
        automatic int rb = int'(be_instr[20:16]);
        automatic int rc = int'(be_instr[15:11]);
        automatic int w  = int'(be_warp);
        if (!be_rdy[be_cls]) $fatal(1, "[BE] DUT issued class %0d while backend not ready", be_cls);
        if (be_mask == '0)   $fatal(1, "[BE] DUT issued with empty mask pc=%0d", be_pc);
        for (int i = 0; i < NINF; i++) if (e < 0 && !inf_v[i]) e = i;
        if (e < 0) $fatal(1, "[BE] in-flight table full");
        inf_v[e] = 1'b1; inf_warp[e] = w; inf_mask[e] = be_mask; inf_wg[e] = int'(be_wg_id);
        mi[w] = mi[w] + 1;
        inf_seq[e] = seq; seq = seq + 1;
        inf_wr[e] = 1'b0; inf_rd[e] = 0; inf_taken[e] = '0;
        case (op)
          6'h10, 6'h12: begin   // LD / LDS
            inf_kind[e] = (op == 6'h10) ? 1 : 3; inf_rd[e] = ra; inf_wr[e] = (ra != 0);
            inf_rdy[e] = cyc + ((op == 6'h10) ? rnd_range(ld_lo, ld_hi) : rnd_range(lds_lo, lds_hi));
            for (int l = 0; l < WARP_SIZE; l++)
              inf_addr[e][l] = rreg(w, l, rb) + sext_n({21'b0, be_instr[10:0]}, 11);
            mem_outstanding = mem_outstanding + 1;
          end
          6'h11, 6'h13: begin   // ST / STS
            inf_kind[e] = (op == 6'h11) ? 2 : 4;
            inf_rdy[e] = cyc + ((op == 6'h11) ? rnd_range(st_lo, st_hi) : rnd_range(lds_lo, lds_hi));
            for (int l = 0; l < WARP_SIZE; l++) begin
              inf_addr[e][l] = rreg(w, l, rb) + sext_n({21'b0, be_instr[10:0]}, 11);
              inf_val[e][l]  = rreg(w, l, rc);
            end
            mem_outstanding = mem_outstanding + 1;
          end
          6'h20, 6'h21: begin   // BRA / BRZ  (predicate register = field A)
            inf_kind[e] = 5;
            inf_rdy[e] = cyc + rnd_range(br_lo, br_hi);
            for (int l = 0; l < WARP_SIZE; l++) begin
              automatic logic [31:0] p = rreg(w, l, ra);
              if (be_mask[l] && ((op == 6'h20) ? (p != 0) : (p == 0))) inf_taken[e][l] = 1'b1;
            end
          end
          default: begin        // ALU
            inf_kind[e] = 0; inf_rd[e] = ra; inf_wr[e] = (ra != 0);
            inf_rdy[e] = cyc + ((op == 6'h09) ? rnd_range(mul_lo, mul_hi) : rnd_range(alu_lo, alu_hi));
            for (int l = 0; l < WARP_SIZE; l++) begin
              automatic logic [31:0] a = rreg(w, l, rb);
              automatic logic [31:0] b = rreg(w, l, rc);
              automatic logic [31:0] imm = sext_n({21'b0, be_instr[10:0]}, 11);
              automatic logic [31:0] res = 32'h0;
              case (op)
                6'h01: res = a + b;
                6'h02: res = a - b;
                6'h03: res = a & b;
                6'h04: res = a | b;
                6'h05: res = a ^ b;
                6'h06: res = a << b[4:0];
                6'h07: res = a >> b[4:0];
                6'h08: res = ($signed(a) < $signed(b)) ? 32'd1 : 32'd0;
                6'h09: res = a * b;
                6'h0A: res = a + imm;
                6'h0B: res = a & {21'b0, be_instr[10:0]};
                6'h0C: res = sext_n({16'b0, be_instr[15:0]}, 16);
                6'h0D: res = 32'(int'(be_widx) * WARP_SIZE + l);
                6'h0E: res = 32'(int'(be_wg_id));
                default: $fatal(1, "[BE] unexpected opcode %h at pc=%0d", op, be_pc);
              endcase
              inf_val[e][l] = res;
            end
          end
        endcase
        // BC3: in-order memory per warp
        if (inf_kind[e] >= 1 && inf_kind[e] <= 4) begin
          if (inf_rdy[e] <= last_mem_rdy[w]) inf_rdy[e] = last_mem_rdy[w] + 1;
          last_mem_rdy[w] = inf_rdy[e];
        end
        // BC5: busy gap after an accept (class level)
        busy[int'(be_cls)] = (int'(be_cls) == 1 && mem_busy_fixed > 0) ? mem_busy_fixed : rnd_range(0, busy_max);
      end else begin
        for (int c = 0; c < 3; c++) if (busy[c] > 0) busy[c] = busy[c] - 1;
      end
      if (be_valid) begin
        // other classes still count down
        for (int c = 0; c < 3; c++) if (c != int'(be_cls) && busy[c] > 0) busy[c] = busy[c] - 1;
      end

      // ---- (1) the completion presented this cycle is consumed now ----
      if (cmp_valid && pres_idx >= 0) begin
        automatic int e = pres_idx;
        automatic int w = inf_warp[e];
        case (inf_kind[e])
          0: begin
            if (inf_wr[e])
              for (int l = 0; l < WARP_SIZE; l++)
                if (inf_mask[e][l]) rf[w][l][inf_rd[e]] = inf_val[e][l];
          end
          1: begin
            for (int l = 0; l < WARP_SIZE; l++)
              if (inf_mask[e][l] && inf_wr[e])
                rf[w][l][inf_rd[e]] = gmem[int'(inf_addr[e][l]) & (GMEM_WORDS - 1)];
            mem_outstanding = mem_outstanding - 1;
          end
          2: begin
            for (int l = 0; l < WARP_SIZE; l++)
              if (inf_mask[e][l]) gmem[int'(inf_addr[e][l]) & (GMEM_WORDS - 1)] = inf_val[e][l];
            mem_outstanding = mem_outstanding - 1;
          end
          3: begin
            for (int l = 0; l < WARP_SIZE; l++)
              if (inf_mask[e][l] && inf_wr[e])
                rf[w][l][inf_rd[e]] = smem[inf_wg[e] % SMEM_WGS][int'(inf_addr[e][l]) & (SMEM_WORDS - 1)];
            mem_outstanding = mem_outstanding - 1;
          end
          4: begin
            for (int l = 0; l < WARP_SIZE; l++)
              if (inf_mask[e][l]) smem[inf_wg[e] % SMEM_WGS][int'(inf_addr[e][l]) & (SMEM_WORDS - 1)] = inf_val[e][l];
            mem_outstanding = mem_outstanding - 1;
          end
          default: ;
        endcase
        inf_v[e] = 1'b0;
        mi[w] = mi[w] - 1;
      end

      // ---- (3) choose the completion to present next cycle ----
      cmp_valid <= 1'b0; cmp_wr <= 1'b0; cmp_mem <= 1'b0; cmp_br <= 1'b0; cmp_taken <= '0;
      pres_idx = -1;
      if (!(cstall_pct > 0 && cons_stall < 5 && int'(rnd() % 100) < cstall_pct)) begin
        automatic int n = 0;
        automatic int pick = -1;
        for (int e = 0; e < NINF; e++) begin
          if (inf_v[e] && inf_rdy[e] <= cyc + 1) begin
            automatic bit ok = 1'b1;
            if (inf_kind[e] >= 1 && inf_kind[e] <= 4) begin
              for (int f = 0; f < NINF; f++)
                if (inf_v[f] && f != e && inf_warp[f] == inf_warp[e] &&
                    inf_kind[f] >= 1 && inf_kind[f] <= 4 && inf_seq[f] < inf_seq[e]) ok = 1'b0;
            end
            if (ok) n++;
          end
        end
        if (n > 0) begin
          automatic int sel = int'(rnd() % unsigned'(n));
          for (int e = 0; e < NINF; e++) begin
            if (inf_v[e] && inf_rdy[e] <= cyc + 1 && pick < 0) begin
              automatic bit ok = 1'b1;
              if (inf_kind[e] >= 1 && inf_kind[e] <= 4) begin
                for (int f = 0; f < NINF; f++)
                  if (inf_v[f] && f != e && inf_warp[f] == inf_warp[e] &&
                      inf_kind[f] >= 1 && inf_kind[f] <= 4 && inf_seq[f] < inf_seq[e]) ok = 1'b0;
              end
              if (ok) begin
                if (sel == 0) pick = e; else sel--;
              end
            end
          end
        end
        if (pick >= 0) begin
          pres_idx = pick;
          cmp_valid <= 1'b1;
          cmp_warp  <= WID_W'(inf_warp[pick]);
          cmp_wr    <= inf_wr[pick];
          cmp_rd    <= 5'(inf_rd[pick]);
          cmp_mem   <= (inf_kind[pick] >= 1 && inf_kind[pick] <= 4);
          cmp_br    <= (inf_kind[pick] == 5);
          // hostile downstream: a branch outcome may name lanes outside the issued mask (BC7 violation)
          cmp_taken <= (spurious_pct > 0 && inf_kind[pick] == 5 && (rnd() % 2 == 0))
                         ? (inf_taken[pick] | (WARP_SIZE'(rnd()) & ~inf_mask[pick])) : inf_taken[pick];
          cons_stall = 0;
        end else cons_stall = 0;
      end else begin
        cons_stall = cons_stall + 1;
      end
      // ---- hostile downstream: spurious completion for a warp with NOTHING in flight ----
      if (spurious_pct > 0 && pres_idx < 0 && int'(rnd() % 100) < spurious_pct) begin
        automatic int w2 = int'(rnd() % unsigned'(NUM_WARPS));
        if (mi[w2] == 0) begin
          cmp_valid <= 1'b1; cmp_warp <= WID_W'(w2);
          cmp_wr    <= (rnd() % 2 == 0); cmp_rd <= 5'(1 + rnd() % 31);
          cmp_mem   <= (rnd() % 2 == 0); cmp_br <= (rnd() % 4 == 0); cmp_taken <= WARP_SIZE'(rnd());
        end
      end

      // ---- (4) ready for the next cycle ----
      be_rdy <= {(busy[2] == 0),
                 (busy[1] == 0) && (mem_outstanding < mem_cap),
                 (busy[0] == 0)};
    end
  end

  // pres_idx must keep the entry alive until consumed (it is freed in step (1))
  logic unused;
  assign unused = &{1'b0, st_prev[0], prev_busy_free};
endmodule
