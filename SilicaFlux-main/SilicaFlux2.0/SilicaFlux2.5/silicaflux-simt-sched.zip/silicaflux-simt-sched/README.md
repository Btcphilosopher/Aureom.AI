# SilicaFlux SIMT warp scheduler: round-robin vs age-aware vs readiness / capacity-aware

Synthesisable SystemVerilog, a self-checking testbench, assertions, and a reproducible comparison flow for the warp scheduler of the SilicaFlux SIMT
control unit (`silicaflux-simt`, from `SilicaFlux2.0/SilicaFlux2.5/silicaflux-simt.zip` of the repository). Three policies, selected by `SCHED_POLICY`:

| `SCHED_POLICY` | policy | status |
|---|---|---|
| 0 | round-robin (two-level, per execution class) - **the baseline** | existing, **proved unchanged** (569 runs cycle-exact vs the pristine original) |
| 1 | age-aware (oldest first + starvation guard) | existing, **proved unchanged** |
| 2 | **readiness / downstream-capacity aware** with bounded-fairness guards | **new** (`rtl/sfx_aware_arb.sv`) |

## The result, stated plainly

Measured on 256 held-out workload instances (8 families x 16 unseen seeds x 2 geometries), all five scheduler variants running **identical** workloads
(same program, memory, launch and schedule-independent latency trace; every run bit-exact against the reference model). Ratios are policy / round-robin, 95 %
cluster-bootstrap CI; lower is better. The claim rule was fixed before measuring: "better"/"worse" only if the CI excludes 1 **and** the mean differs by > 0.5 %.

| | age (existing) | **policy 2, default weights** | policy 2, weights tuned on dev seeds |
|---|---|---|---|
| kernel cycles | 1.051 [1.045, 1.058] **worse** | 1.000 [0.999, 1.001] no difference | 0.996 [0.995, 0.997] below the 0.5 % threshold |
| p95 workgroup latency | 1.070 **worse** | 1.002 no difference | 1.000 no difference |
| Jain fairness of service when ready (RR 0.975) | 0.838 | 0.978 | 0.977 |
| longest wait as a candidate (RR 15.1 cycles) | 25.7 | 19.3 | 19.4 |
| wake-to-issue wait of memory-dependent warps, mean / max (RR 1.02 / 4.9 cycles) | 2.36 / 12.4 | **0.55 / 1.8** | 1.29 / 7.1 |

* **I do not claim a throughput improvement for policy 2.** With the default weights it is indistinguishable from round-robin on cycles; the measurable gains are
  confined to barrier-heavy kernels (-0.7 % default, **-1.5 %** tuned) and, with tuned weights only, dependent-ALU kernels (-1.1 %).
* What policy 2 does deliver: **memory-dependent warps are woken about twice as fast** (default weights) at equal throughput and equal-or-better fairness, with
  **bounded waiting** (per-warp and per-class guards, asserted in every simulation) and an explicit compute-vs-memory guard.
* **The tuned weights trade that wake-up benefit away** (max wake wait 7.1 vs 4.9 for round-robin) for their small cycle gain; no configuration wins on every metric.
* **Round-robin wins** the worst-case wait metric, and on **kernel cycles** no variant beats it on six of eight families (`compute`, `diverge`, `ldchain`, `memstream`,
  `mixed`, `skew`): they are either issue-slot-bound or bound by 100-300-cycle memory chains, where arbitration order has about one cycle per instruction to save.
* **The existing age policy is worse than round-robin by about 5 %** here (up to 10 % on mixed / skewed kernels): it leaves the long chains of young warps for the tail.

Full tables, per-family results, idle-cause breakdown, ablation, hardware accounting: `results/REPORT.md` (generated). Interpretation and threats to validity:
`docs/RESULTS_INTERPRETATION.md`. **Read the limits below before using any number.**

## Where each requirement is met

| requirement | where / evidence |
|---|---|
| round-robin, age-aware, and a configurable readiness / downstream-capacity policy | `SCHED_POLICY` 0 / 1 / 2; policy 2 = `rtl/sfx_aware_arb.sv`, weights in `sfx_sched_cfg_t` (`docs/SCHEDULER_POLICIES.md`) |
| respect instruction semantics, execution masks, barriers, memory ordering | arbiters only rank warps the existing legality gate allows; all results bit-exact vs the reference model in every run; masks: assertion A7 + `diverge` family; barriers: C2 + monitor M4 + `barrier` family; memory ordering: BAR drain (A7/M3) + backend contract BC3 |
| explicit warp states and a scoreboard | `WS_*` state machine and `sfx_scoreboard` (existing, reused); scheduler-visible stall classes added; independently re-derived by the monitor (M1, M7) |
| no issue when operands are unavailable or a resource cannot accept work | candidate gate `w_cand` (hazard, `be_rdy`, in-flight credit, BAR/EXIT drain); assertions A7, D1; monitor M1, M2, M3 |
| bounded fairness under stated assumptions | assumptions D1-D5, P1-P2 and bounds in `docs/SCHEDULER_POLICIES.md` 3; assertions C1, D2, D3; exact-model unit test N = 2-32; **argument has a documented gap, not a formal proof** |
| do not let compute-heavy warps starve memory-dependent work | per-class bypass guard (D3), memory-dependent wake bonus, `skew` family, wake-wait metrics; unit-test ablation (guards off: 0 memory grants, on: 216-299) |
| Python-generated identical traces: long-latency loads, dependent arithmetic, mixed kernels, barrier-heavy workgroups | `tools/wl_gen.py` families `ldchain depalu mixed skew barrier` (+ `compute memstream diverge`); trace mode in `tb/sfx_be_model.sv`; identity enforced per run (`tools/compare_policies.py`) |
| report throughput, tail completion, fairness, idle cycles, scheduling overhead | `results/REPORT.md` sections 2-5 and 9 (overhead: cycles measured = 0 bubbles; hardware state/operators **analytical, not synthesised**) |
| explain where the baseline wins | `results/REPORT.md` section 6 (auto-extracted) and `docs/RESULTS_INTERPRETATION.md` 2 |
| complete RTL, self-checking testbench, assertions, reproducible scripts | `rtl/`, `tb/`, `rtl/sfx_simt_checks.svh`, `tools/`, `Makefile`; clean-room reproduction was run from the unzipped archive |
| no improvement claimed without equivalent-workload measurement | claim rule in `docs/COMPARISON_METHOD.md` 6, applied by `tools/make_report.py` to held-out seeds only |

## Layout

```
rtl/    sfx_simt_ctrl.sv        control unit (modified: be_cap + sched_cfg ports, policy-2 features, policy select)
        sfx_aware_arb.sv        NEW  policy 2 arbiter (priority key, tiers, guards)
        sfx_warp_sched.sv       policy select (0 class-RR | 1 age | 2 aware)         sfx_simt_pkg.sv  + sfx_sched_cfg_t, defaults
        sfx_class_rr_arb.sv sfx_rr_arb.sv sfx_age_arb.sv sfx_scoreboard.sv sfx_barrier_unit.sv sfx_diverge_unit.sv sfx_perf_counters.sv   (unchanged)
        sfx_simt_checks.svh     assertions A-D (policy-aware C1, new group D)
tb/     tb_simt_top.sv          system testbench (+ cfg / trace plusargs)            sfx_be_model.sv  backend: random mode (original) + deterministic TRACE mode
        sfx_imem_model.sv       instruction memory (+ deterministic mode)            sfx_assume_monitor.sv  downstream-assumption checker (original)
        sfx_sched_monitor.sv    NEW  independent monitor M1-M9 + scheduler statistics
        tb_unit_aware.sv        NEW  policy-2 arbiter: exact model, bounds, ablation  tb_unit_arb.sv tb_unit_diverge.sv (original)
tools/  wl_gen.py               NEW  workload generator: programs + latency traces      compare_policies.py  NEW  run all variants, hard equivalence checks
        sweep_cfg.py            NEW  weight search (dev seeds only)                     make_report.py       NEW  report with bootstrap CIs and claim rule
        check_baseline_equiv.py NEW  policies 0/1 cycle-exact vs pristine original      mutate_sched.py      NEW  24 mutants of the policy-2 path
        hw_cost.py              NEW  analytical state/operator accounting               package.sh           NEW
        run_tests.py run_unit.py sfx_run.py final_regression.sh (extended)   sfx_isa.py sfx_asm.py sfx_ref.py sfx_gen.py sfx_cfg.py mutate.py ... (original)
tests/  directed.py             45 directed tests (run on every policy, incl. policy 2)
baseline_orig/                  the pristine original rtl/ and tb/ (reference for `make equiv`)
docs/   SCHEDULER_POLICIES.md   design, legality gate, policy 2, fairness bounds + their limits
        COMPARISON_METHOD.md    trace mode, workload families, metrics, claim rule, limits of the model
        RESULTS_INTERPRETATION.md   hand-written reading of the archived run
        architecture.md divergence_model.md isa.md verification.md   (original; architecture.md and verification.md extended)
results/ REPORT.md (generated)  raw_test.json raw_dev.json raw_ablation.json sweep_dev.json tuned_cfg.json hw_cost.md  + logs of the final regression
```

## Quick start

Needs `verilator >= 5.020`, `python3 >= 3.9`, `g++`, `make`. (Yosys and Icarus are not used; see limits.)

```bash
make lint unit directed random equiv     # functional regression, incl. policy 2 and the baseline-unchanged proof   (~8 min)
make workloads                           # 8 families x seeds 1-6 (dev) and 101-116 (test)                            (~10 s)
make compare                             # held-out seeds, all variants, both geometries -> results/raw_test.json    (~1 min)
make report                              # -> results/REPORT.md
make sweep                               # re-run the weight search on the dev seeds (~10 min)
make mutants-p2                          # mutation tests of the policy-2 path (~10 min)
```

Run one program under a policy and compare it with the reference: `python3 tools/sfx_run.py prog.s --nthreads 96 --nwgs 2 --policy 2`.
Policy-2 weights are plusargs of the testbench (`+sc_w_cls_mem=7 +sc_fair_limit=24 ...`, see `tb/tb_simt_top.sv`) or the `sched_cfg` input of the unit.

## What is verified

Details and counts in `docs/verification.md` (addendum). In short: lint clean; policy 0/1 cycle-exact unchanged; policy-2 arbiter against an exact model for N = 2-32
with bounds and an ablation that must fail; the whole directed suite and 1,800 random legal programs against the reference; an **independent monitor** that re-derives operand
availability (RAW/WAW), backend readiness, BAR/EXIT drain, barrier-episode ordering and every controller-to-arbiter feature; 4,040 archived policy-2 simulations with
all assertions on and none fired; mutation tests showing the checks can fail (24/24 policy-2 mutants killed, `results/mutation_policy2.log`; the original 32/32 re-run on the modified RTL, `results/mutation_original_rerun.log`). The package was also reproduced from the unzipped archive: regenerated metrics and `REPORT.md` are identical to the archived ones.
Instruction semantics, execution masks, barriers and memory ordering are untouched: a scheduler only ranks warps that the existing legality gate already allows.

## Limits (stated plainly)

* **Simulation only.** No synthesis, timing or power result exists for any arbiter: the only synthesis tool available (Yosys 0.33) cannot parse the original
  arbiters. `results/hw_cost.md` is an *analytical* state/operator count. Policy 2's grant path is the deepest of the three and drives the backend issue interface in
  the same cycle; its timing closure is unmeasured.
* **The performance model has no locality.** No cache, bank, row-buffer or coalescing behaviour; one issue slot, one fetch port, single-entry instruction buffer. Any gain
  that depends on those cannot appear, and the conclusions should not be extrapolated to real memory systems without re-measuring.
* **Small synthetic kernels** (3k-20k warp instructions, at most 16 resident warps); the tuned weights were searched on the same eight families (held-out *seeds*, not held-out
  *kernel types*).
* **Fairness bounds are asserted and unit-tested, not formally proved**; the argument has a documented gap for cross-class interleavings (`docs/SCHEDULER_POLICIES.md` 3.3).
* The backend is a behavioural model; the unit uses its own small ISA and is not connected to the SilicaFlux dataflow core. `NUM_WGS >= 2` is required (an existing limitation of the
  barrier unit's port widths).

## Provenance

Base: `silicaflux-simt` (SIMT control unit with round-robin and age policies, scoreboard, barrier unit, divergence stack, counters, assertions, reference models), unchanged except
where listed above. New work: policy 2, the trace-driven comparison flow, the independent monitor and the verification of all of it.
