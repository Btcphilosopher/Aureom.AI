// ============================================================================
// SilicaFlux SIMT control unit - shared definitions (ISA decode, state codes)
// ============================================================================
`ifndef SFX_SIMT_PKG_SV
`define SFX_SIMT_PKG_SV

package sfx_simt_pkg;

  // ---- opcodes (6 bit) ----------------------------------------------------
  localparam logic [5:0] OP_NOP  = 6'h00;
  localparam logic [5:0] OP_ADD  = 6'h01;
  localparam logic [5:0] OP_SUB  = 6'h02;
  localparam logic [5:0] OP_AND  = 6'h03;
  localparam logic [5:0] OP_OR   = 6'h04;
  localparam logic [5:0] OP_XOR  = 6'h05;
  localparam logic [5:0] OP_SHL  = 6'h06;
  localparam logic [5:0] OP_SHR  = 6'h07;
  localparam logic [5:0] OP_SLT  = 6'h08;
  localparam logic [5:0] OP_MUL  = 6'h09;
  localparam logic [5:0] OP_ADDI = 6'h0A;
  localparam logic [5:0] OP_ANDI = 6'h0B;
  localparam logic [5:0] OP_MOVI = 6'h0C;
  localparam logic [5:0] OP_TID  = 6'h0D;
  localparam logic [5:0] OP_WGID = 6'h0E;
  localparam logic [5:0] OP_LD   = 6'h10;
  localparam logic [5:0] OP_ST   = 6'h11;
  localparam logic [5:0] OP_LDS  = 6'h12;
  localparam logic [5:0] OP_STS  = 6'h13;
  localparam logic [5:0] OP_BRA  = 6'h20;
  localparam logic [5:0] OP_BRZ  = 6'h21;
  localparam logic [5:0] OP_JMP  = 6'h22;
  localparam logic [5:0] OP_BAR  = 6'h23;
  localparam logic [5:0] OP_EXIT = 6'h24;

  // ---- execution classes (index into be_rdy[]) ----------------------------
  localparam logic [1:0] CLS_ALU  = 2'd0;
  localparam logic [1:0] CLS_MEM  = 2'd1;
  localparam logic [1:0] CLS_BR   = 2'd2;
  localparam logic [1:0] CLS_CTRL = 2'd3;   // handled inside the control unit

  // ---- warp slot states ---------------------------------------------------
  localparam logic [2:0] WS_FREE    = 3'd0;  // slot unallocated
  localparam logic [2:0] WS_FETCH   = 3'd1;  // PC valid, wants an instruction
  localparam logic [2:0] WS_FETCHING= 3'd2;  // fetch request outstanding
  localparam logic [2:0] WS_READY   = 3'd3;  // instruction buffered, may issue
  localparam logic [2:0] WS_WAIT_BR = 3'd4;  // branch issued, awaiting taken mask
  localparam logic [2:0] WS_BARRIER = 3'd5;  // arrived at workgroup barrier
  localparam logic [2:0] WS_DRAIN   = 3'd6;  // faulted/aborted, draining in-flight work

  // ---- fault codes (kernel status) ----------------------------------------
  localparam logic [3:0] FLT_NONE        = 4'd0;
  localparam logic [3:0] FLT_DIV_BARRIER = 4'd1;  // BAR executed while warp diverged
  localparam logic [3:0] FLT_DIV_EXIT    = 4'd2;  // EXIT executed while warp diverged
  localparam logic [3:0] FLT_STACK_OVF   = 4'd3;  // reconvergence stack overflow
  localparam logic [3:0] FLT_ILLEGAL     = 4'd4;  // undefined opcode
  localparam logic [3:0] FLT_FETCH       = 4'd5;  // instruction fetch error
  localparam logic [3:0] FLT_PC_RANGE    = 4'd6;  // branch/jump/sequential PC outside [0,2^PC_W)
  localparam logic [3:0] FLT_BAR_PC      = 4'd7;  // strict mode: barrier PC mismatch in one episode
  localparam logic [3:0] FLT_LAUNCH      = 4'd8;  // invalid launch size

  // ---- scheduler policy 2 (readiness / capacity aware) configuration ------
  // Static while a kernel runs (a CSR in a real SoC; the testbench drives it).
  // All weights are unsigned 3-bit integers; the per-warp score is the sum of
  // weight x feature terms and is at most 91 (fits 7 bits, no saturation).
  localparam int CAP_W = 2;     // downstream headroom hint per class (0..3 free entries)

  typedef struct packed {
    logic [2:0] w_cls_alu;     // static bonus: ALU class
    logic [2:0] w_cls_mem;     //               MEM class
    logic [2:0] w_cls_br;      //               BR class (the warp cannot proceed until the outcome returns)
    logic [2:0] w_cls_ctrl;    //               CTRL class (NOP/JMP/BAR/EXIT)
    logic [2:0] w_ld;          // extra bonus for loads (they start a result latency; stores do not)
    logic [2:0] w_memdep;      // warp was blocked on a memory result and its operand is now ready
    logic [2:0] w_dep;         // warp was blocked on a non-memory register dependency, now ready
    logic [2:0] w_bar;         // per warp (0..3) of the own workgroup already parked at the barrier
    logic [2:0] w_rel;         // this issue completes a barrier episode (releases the parked warps)
    logic [2:0] w_cap;         // per unit (0..3) of downstream headroom of the instruction's class
    logic [2:0] w_age;         // per unit (0..3) of waiting (grants lost while a candidate)
    logic [5:0] fair_limit;    // per-warp guard: urgent after this many lost grants (0 = guard off)
    logic [3:0] cls_limit;     // per-class guard: class urgent after this many bypasses (0 = guard off)
  } sfx_sched_cfg_t;

  // Default weights.  Chosen from first principles BEFORE any measurement (see
  // docs/SCHEDULER_POLICIES.md); the comparison report states whether they were later tuned.
  // fair_limit scales with the warp count n: the stated bound needs fair_limit >= n+3 (or 0 = off);
  // 2n gives margin, capped at the 6-bit field maximum.
  function automatic sfx_sched_cfg_t sfx_sched_cfg_default(input int n);
    sfx_sched_cfg_t c;
    int fl;
    c.w_cls_alu  = 3'd0;
    c.w_cls_mem  = 3'd1;
    c.w_cls_br   = 3'd2;
    c.w_cls_ctrl = 3'd1;
    c.w_ld       = 3'd2;
    c.w_memdep   = 3'd2;
    c.w_dep      = 3'd0;
    c.w_bar      = 3'd1;
    c.w_rel      = 3'd7;
    c.w_cap      = 3'd1;
    c.w_age      = 3'd1;
    fl = (2 * n > n + 3) ? 2 * n : n + 3;
    c.fair_limit = (fl > 63) ? 6'd63 : 6'(fl);
    c.cls_limit  = 4'd6;
    return c;
  endfunction

  // ---- decoded instruction ------------------------------------------------
  typedef struct packed {
    logic        illegal;
    logic [5:0]  op;
    logic [1:0]  cls;
    logic        use1;      // reads rs1
    logic        use2;      // reads rs2
    logic        wr;        // writes rd (rd != 0 checked by consumer)
    logic        is_ld;     // result comes from memory (scoreboard 'mem' tag)
    logic        is_mem;
    logic [4:0]  rs1;
    logic [4:0]  rs2;
    logic [4:0]  rd;
  } dec_t;

  function automatic dec_t sfx_decode(input logic [31:0] i);
    dec_t d;
    d = '0;
    d.op  = i[31:26];
    d.rd  = i[25:21];
    d.rs1 = i[20:16];
    d.rs2 = i[15:11];
    d.cls = CLS_CTRL;
    case (i[31:26])
      OP_NOP, OP_JMP, OP_BAR, OP_EXIT: d.cls = CLS_CTRL;
      OP_ADD, OP_SUB, OP_AND, OP_OR, OP_XOR, OP_SHL, OP_SHR, OP_SLT, OP_MUL: begin
        d.cls = CLS_ALU; d.use1 = 1'b1; d.use2 = 1'b1; d.wr = 1'b1;
      end
      OP_ADDI, OP_ANDI: begin d.cls = CLS_ALU; d.use1 = 1'b1; d.wr = 1'b1; end
      OP_MOVI, OP_TID, OP_WGID: begin d.cls = CLS_ALU; d.wr = 1'b1; end
      OP_LD, OP_LDS: begin
        d.cls = CLS_MEM; d.use1 = 1'b1; d.wr = 1'b1; d.is_ld = 1'b1; d.is_mem = 1'b1;
      end
      OP_ST, OP_STS: begin
        d.cls = CLS_MEM; d.use1 = 1'b1; d.use2 = 1'b1; d.is_mem = 1'b1;
      end
      OP_BRA, OP_BRZ: begin
        d.cls = CLS_BR; d.use1 = 1'b1; d.rs1 = i[25:21];   // predicate register is field A
      end
      default: d.illegal = 1'b1;
    endcase
    return d;
  endfunction

endpackage

`endif
