// ============================================================================
// Warp scheduler: selects at most one issuable warp per cycle.
//   POLICY 0 : deterministic round-robin (default): round-robin inside every execution
//              class and across classes (sfx_class_rr_arb)
//   POLICY 1 : age-based (oldest-first) with starvation guard (sfx_age_arb)
//   POLICY 2 : readiness / downstream-capacity aware priority with bounded-wait
//              guards (sfx_aware_arb)
// `req`  : warps that can issue THIS cycle (all hazards / credits resolved)
// `wait_en` : warps holding a buffered instruction (for age-policy accounting)
// `alloc`: slots allocated this cycle (age bookkeeping)
// The remaining inputs (is_ld ... cap, cfg) are used by POLICY 2 only; policies 0 and 1
// are bit-for-bit what they were before policy 2 existed (tools/check_baseline_equiv.py).
// ============================================================================
module sfx_warp_sched
  import sfx_simt_pkg::*;
#(
  parameter int N            = 8,
  parameter int POLICY       = 0,
  parameter int STARVE_LIMIT = 16
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] req,
  input  logic [N-1:0] wait_en,
  input  logic [N-1:0] alloc,
  input  logic [N-1:0][1:0] cls,       // execution class of each warp's buffered instruction
  // ---- policy 2 inputs ----
  input  sfx_sched_cfg_t        cfg,
  input  logic [N-1:0]          is_ld,
  input  logic [N-1:0]          stall_mem,
  input  logic [N-1:0]          stall_dep,
  input  logic [N-1:0][1:0]     bar_press,
  input  logic [N-1:0]          bar_rel,
  input  logic [3:0][CAP_W-1:0] cap,
  output logic [N-1:0]          grant,
  output logic [N-1:0]          dbg_urgent,
  output logic [3:0]            dbg_cls_urgent
);
  generate
    if (POLICY == 0) begin : g_rr
      sfx_class_rr_arb #(.N(N)) u_arb (
        .clk(clk), .rst_n(rst_n), .req(req), .cls(cls), .grant(grant));
      // unused in RR mode
      logic unused_ok;
      assign unused_ok = &{1'b0, wait_en, alloc, cfg, is_ld, stall_mem, stall_dep, bar_press, bar_rel, cap};
      assign dbg_urgent = '0;
      assign dbg_cls_urgent = '0;
    end else if (POLICY == 1) begin : g_age
      sfx_age_arb #(.N(N), .STARVE_LIMIT(STARVE_LIMIT)) u_arb (
        .clk(clk), .rst_n(rst_n), .req(req), .wait_en(wait_en), .alloc(alloc),
        .adv(1'b1), .grant(grant));
      logic unused_cls;
      assign unused_cls = &{1'b0, cls, cfg, is_ld, stall_mem, stall_dep, bar_press, bar_rel, cap};
      assign dbg_urgent = '0;
      assign dbg_cls_urgent = '0;
    end else begin : g_aware
      sfx_aware_arb #(.N(N)) u_arb (
        .clk(clk), .rst_n(rst_n), .cfg(cfg), .req(req), .wait_en(wait_en), .alloc(alloc),
        .cls(cls), .is_ld(is_ld), .stall_mem(stall_mem), .stall_dep(stall_dep),
        .bar_press(bar_press), .bar_rel(bar_rel), .cap(cap), .grant(grant),
        .dbg_urgent(dbg_urgent), .dbg_cls_urgent(dbg_cls_urgent));
    end
  endgenerate
endmodule
