// ============================================================================
// Readiness / capacity aware warp arbiter (scheduling policy 2).
//
// WHAT IT DECIDES.  Legality is NOT decided here.  `req` already contains only
// warps that may issue THIS cycle (state READY, scoreboard hazard-free, backend
// class ready, in-flight credit available, BAR/EXIT drain conditions met, see
// sfx_simt_ctrl).  This module only chooses WHICH legal candidate issues, so no
// weight setting can make an illegal issue: grant is always a subset of req and
// the arbiter is work conserving (any candidate => a grant).
//
// PRIORITY KEY (compared as one 16-bit unsigned number, highest wins)
//
//     key = { tier[1:0] , prim[6:0] , score[6:0] }
//
//   tier 3  warp-urgent : the candidate has lost >= fair_limit grants since it
//                         last issued (counted only in cycles in which it was a
//                         candidate).  prim = lost-grant count: the longest
//                         waiting urgent candidate wins.
//   tier 2  class-urgent: the candidate's execution class has been bypassed by
//                         >= cls_limit consecutive grants to other classes while
//                         it had a candidate.  prim = bypass count of the class.
//   tier 1  normal      : prim = 0.
//   score  = sum of weight x feature terms (all weights 3 bit, see sfx_sched_cfg_t):
//              class bonus (ALU/MEM/BR/CTRL)         static preference
//              load bonus                            loads start a result latency
//              memdep / dep bonus                    the warp was blocked on a memory /
//                                                    register result that is now ready
//              bar x parked-warps-of-own-workgroup   straggler boost (0..3)
//              rel                                   this issue completes a barrier
//              cap x headroom of the class (0..3)    downstream capacity hint
//              age x min(lost grants, 3)             soft aging below the hard guard
//   ties  : rotating priority; the pointer moves to (granted + 1) on every grant.
//
// FAIRNESS (stated assumptions in docs/SCHEDULER_POLICIES.md, checked by assertion
// C1 and by tb/tb_unit_aware.sv):
//   * guard enabled (fair_limit >= N), backend ready bits non-retracting (D1),
//     completions eventually delivered (D3).
//   * a candidate loses at most  fair_limit + N  grants made in cycles in which it is
//     a candidate before it issues;
//   * a class with a candidate is bypassed by at most  cls_limit + 3  consecutive grants
//     unless warp-urgent candidates intervene (each warp-urgent grant resets that warp).
//   fair_limit = 0 / cls_limit = 0 switch a guard OFF (ablation only: then a score
//   that always prefers other warps can starve this one; the unit test demonstrates it).
//
// Per-warp state: lost-grant counter (7 bit), two sticky "was blocked" flags.
// Global state:   4 class bypass counters (4 bit), one rotating pointer.
// ============================================================================
module sfx_aware_arb
  import sfx_simt_pkg::*;
#(
  parameter int N = 8
) (
  input  logic                   clk,
  input  logic                   rst_n,
  input  sfx_sched_cfg_t         cfg,
  input  logic [N-1:0]           req,        // legal candidates this cycle
  input  logic [N-1:0]           wait_en,    // warp holds a buffered instruction (READY)
  input  logic [N-1:0]           alloc,      // slot (re)allocated this cycle
  input  logic [N-1:0][1:0]      cls,        // execution class of the buffered instruction
  input  logic [N-1:0]           is_ld,      // buffered instruction is a load
  input  logic [N-1:0]           stall_mem,  // READY but blocked on an outstanding memory result
  input  logic [N-1:0]           stall_dep,  // READY but blocked on a non-memory register result
  input  logic [N-1:0][1:0]      bar_press,  // parked warps in own workgroup (saturated at 3)
  input  logic [N-1:0]           bar_rel,    // issuing this instruction releases a barrier episode
  input  logic [3:0][CAP_W-1:0]  cap,        // free entries of each class (advisory only)
  output logic [N-1:0]           grant,
  output logic [N-1:0]           dbg_urgent,      // warp-urgent candidates (assertions)
  output logic [3:0]             dbg_cls_urgent   // class-urgent classes   (assertions)
);
  localparam int PW  = (N > 1) ? $clog2(N) : 1;
  localparam int WCW = 7;                 // lost-grant counter width
  localparam int SW  = 7;                 // score width (max score 91)
  localparam int KW  = 2 + WCW + SW;      // key width

  // ---------------- state ----------------
  logic [N-1:0][WCW-1:0] wcnt;            // grants lost while a candidate (held while not a candidate)
  logic [3:0][3:0]       cb;              // class bypass counters
  logic [N-1:0]          md, dd;          // sticky: was blocked on memory / on a register result
  logic [PW-1:0]         ptr;

  // ---------------- combinational ----------------
  logic [N-1:0][SW-1:0]  score;
  logic [N-1:0][KW-1:0]  key;
  logic [N-1:0]          urg, curg;
  logic [3:0]            cls_has;
  logic [3:0]            cls_gr;          // class of the granted warp, one-hot
  logic [9:0]            s_tmp;
  logic [1:0]            aged;
  logic [1:0]            tier;
  logic [WCW-1:0]        prim;
  logic [PW-1:0]         widx;            // granted warp index
  logic                  wvalid;
  logic                  fire;
  logic [N-1:0][KW-1:0]  tk;
  logic [N-1:0]          tv;
  logic [N-1:0][PW-1:0]  ti;
  logic [PW-1:0]         ridx;

  always_comb begin
    cls_has = '0;
    for (int i = 0; i < N; i++)
      if (req[i]) cls_has[cls[i]] = 1'b1;

    for (int i = 0; i < N; i++) begin
      // ---- score ----
      case (cls[i])
        CLS_ALU: s_tmp = {7'd0, cfg.w_cls_alu};
        CLS_MEM: s_tmp = {7'd0, cfg.w_cls_mem};
        CLS_BR:  s_tmp = {7'd0, cfg.w_cls_br};
        default: s_tmp = {7'd0, cfg.w_cls_ctrl};
      endcase
      if (is_ld[i]) s_tmp = s_tmp + {7'd0, cfg.w_ld};
      if (md[i])    s_tmp = s_tmp + {7'd0, cfg.w_memdep};
      if (dd[i])    s_tmp = s_tmp + {7'd0, cfg.w_dep};
      if (bar_rel[i]) s_tmp = s_tmp + {7'd0, cfg.w_rel};
      s_tmp = s_tmp + 10'(bar_press[i]) * 10'(cfg.w_bar);
      s_tmp = s_tmp + 10'(cap[cls[i]]) * 10'(cfg.w_cap);
      aged  = (wcnt[i] > WCW'(3)) ? 2'd3 : wcnt[i][1:0];
      s_tmp = s_tmp + 10'(aged) * 10'(cfg.w_age);
      score[i] = s_tmp[SW-1:0];

      // ---- guards ----
      urg[i]  = req[i] && (cfg.fair_limit != 6'd0) && (wcnt[i] >= WCW'(cfg.fair_limit));
      curg[i] = req[i] && (cfg.cls_limit  != 4'd0) && (cb[cls[i]] >= cfg.cls_limit);
      if (urg[i])       begin tier = 2'd3; prim = wcnt[i]; end
      else if (curg[i]) begin tier = 2'd2; prim = {3'd0, cb[cls[i]]}; end
      else              begin tier = 2'd1; prim = '0; end
      key[i] = {tier, prim, score[i]};
    end

    // ---- tournament tree over the rotated candidate list (left child wins ties) ----
    for (int p = 0; p < N; p++) begin
      ridx  = PW'(int'(ptr) + p);               // wraps modulo N (N is a power of two)
      tk[p] = key[ridx];
      tv[p] = req[ridx];
      ti[p] = ridx;
    end
    for (int span = 1; span < N; span = span * 2) begin
      for (int p = 0; p < N; p = p + 2 * span) begin
        if (tv[p + span] && (!tv[p] || tk[p + span] > tk[p])) begin
          tk[p] = tk[p + span];
          tv[p] = 1'b1;
          ti[p] = ti[p + span];
        end
      end
    end
    wvalid = tv[0];
    widx   = ti[0];

    grant = '0;
    if (wvalid) grant[widx] = 1'b1;

    cls_gr = '0;
    for (int i = 0; i < N; i++)
      if (grant[i]) cls_gr[cls[i]] = 1'b1;

    fire = wvalid;
    dbg_urgent = urg;
    for (int c = 0; c < 4; c++)
      dbg_cls_urgent[c] = cls_has[c] && (cfg.cls_limit != 4'd0) && (cb[c] >= cfg.cls_limit);
  end

  // ---------------- state update ----------------
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      wcnt <= '0;
      cb   <= '0;
      md   <= '0;
      dd   <= '0;
      ptr  <= '0;
    end else begin
      if (fire) ptr <= PW'(int'(widx) + 1);
      for (int i = 0; i < N; i++) begin
        // lost-grant counter: same rule as the age policy (held while not a candidate)
        if (!wait_en[i] || grant[i] || alloc[i])       wcnt[i] <= '0;
        else if (fire && req[i] && wcnt[i] != {WCW{1'b1}}) wcnt[i] <= wcnt[i] + 1'b1;
        // sticky "was blocked" flags, cleared when the warp issues
        if (alloc[i] || grant[i]) begin
          md[i] <= 1'b0;
          dd[i] <= 1'b0;
        end else begin
          if (stall_mem[i]) md[i] <= 1'b1;
          if (stall_dep[i]) dd[i] <= 1'b1;
        end
      end
      // class bypass counters
      for (int c = 0; c < 4; c++) begin
        if (cls_gr[c])                              cb[c] <= '0;
        else if (fire && cls_has[c] && cb[c] != 4'hF) cb[c] <= cb[c] + 4'd1;
      end
    end
  end
endmodule
