#!/usr/bin/env python3
"""Directed tests for the SilicaFlux SIMT control unit.

Every test is executed on the RTL (with all selected downstream timing
profiles) AND on the SimtSim reference, and the architectural state is
compared (sfx_run.compare).  On top of that each test states explicit
expectations about the micro-architectural behaviour it was written to hit
(`check`): stack high-water marks, barrier episodes, stall counters, faults.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Union

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
from sfx_isa import (FAULT_DIV_BARRIER, FAULT_DIV_EXIT, FAULT_STACK_OVF, FAULT_ILLEGAL, FAULT_FETCH,
                     FAULT_PC_RANGE, FAULT_BAR_PC, FAULT_LAUNCH)

Spec = Union[int, Callable[[int, int], int]]     # int or f(lanes, num_warps)
Asm = Union[str, Callable[[int], str]]            # text or f(lanes)


@dataclass
class T:
    name: str
    asm: Asm
    nthreads: Spec = 64
    nwgs: int = 1
    cfgs: tuple = ("rr32", "age32")
    profiles: tuple = (0, 1, 2, 3)
    check: Optional[Callable] = None              # f(c: dict, rtl, ref, lanes) -> [errors]
    fault_exact_warp: bool = True
    launch_gap: int = 0
    reps: int = 1
    check_counters: bool = True
    extra_args: tuple = ()
    allow_proto: bool = False
    doc: str = ""


def _nth(t: T, lanes: int, nwarps: int) -> int:
    return t.nthreads(lanes, nwarps) if callable(t.nthreads) else t.nthreads


def _asm(t: T, lanes: int) -> str:
    return t.asm(lanes) if callable(t.asm) else t.asm


# ---------------------------------------------------------------- program builders
def nested(k: int, tail: bool = False) -> str:
    """k nested divergent regions; the deeper region is on the TAKEN path so every
    level keeps its (join + not-taken) pair on the stack: peak depth 2*k."""
    out = ["tid r1"]

    def level(i: int):
        if i == k:
            if tail:                                  # one more divergent region needing a single stack entry
                out.append(f"andi r2, r1, {1 << k}")
                out.append("brz r2, Ltail")           # taken target == reconvergence PC: join entry only
                out.append("addi r3, r3, 1")
                out.append("Ltail:")
                out.append("addi r7, r7, 1")          # distinct reconvergence PC (else the merge needs no entry)
            else:
                out.append("addi r3, r3, 1")
            return
        out.append(f"andi r2, r1, {1 << i}")
        out.append(f"bra r2, Lt{i}")
        out.append(f"addi r4, r4, {i + 1}")
        out.append(f"jmp Lj{i}")
        out.append(f"Lt{i}:")
        level(i + 1)
        out.append(f"Lj{i}:")
        out.append("addi r6, r6, 1")          # distinct reconvergence PC per level
    level(0)
    out += ["add r5, r3, r4", "add r5, r5, r6", "st r5, [r1+300]", "exit"]
    return "\n".join(out) + "\n"


# ---------------------------------------------------------------- expectation helpers
def expect(cond, msg):
    return [] if cond else [msg]


def c_hwm(n):
    return lambda c, rtl, ref, lanes: expect(c["stack_hwm"] == n, f"stack_hwm {c['stack_hwm']} != {n}")


def c_all(*fs):
    def f(c, rtl, ref, lanes):
        e = []
        for g in fs:
            e += g(c, rtl, ref, lanes)
        return e
    return f


def c_ge(key, n):
    return lambda c, rtl, ref, lanes: expect(c[key] >= n, f"{key}={c[key]} expected >= {n}")


def c_eq(key, n):
    return lambda c, rtl, ref, lanes: expect(c[key] == n, f"{key}={c[key]} expected == {n}")


def c_eq_fn(key, fn):
    return lambda c, rtl, ref, lanes: expect(c[key] == fn(lanes), f"{key}={c[key]} expected == {fn(lanes)}")


TESTS: List[T] = []


def add(*a, **k):
    TESTS.append(T(*a, **k))


# ===================================================================== basic issue / hazards
add("nop_exit", "nop\nexit\n", nthreads=1,
    check=c_all(c_eq("issued", 2), c_eq("div_branches", 0)),
    doc="smallest legal kernel")

add("alu_dependency_chain", """
    movi r1, 5
    add  r2, r1, r1
    add  r3, r2, r1
    mul  r4, r3, r3
    sub  r5, r4, r1
    xor  r6, r5, r4
    shl  r7, r6, r1
    st   r7, [r0+10]
    exit
""", nthreads=1, check=c_ge("wc_dep", 1), profiles=(1, 2),
    doc="RAW chain on a single warp shows dependency stalls (visible once ALU latency exceeds fetch latency)")

add("waw_ordering", """
    movi r1, 1
    movi r1, 2
    mul  r1, r1, r1
    movi r1, 7
    add  r2, r1, r1
    st   r2, [r0+20]
    exit
""", nthreads=1, doc="back-to-back writes of one register: out-of-order completion must not reorder them")

add("memory_raw_in_order", """
    tid  r1
    movi r2, 77
    st   r2, [r1+300]
    ld   r3, [r1+300]
    addi r4, r3, 1
    st   r4, [r1+400]
    ld   r5, [r1+400]
    add  r6, r5, r3
    exit
""", nthreads=lambda l, w: 2 * l, check=c_ge("wc_mem", 1), profiles=(1, 2, 3),
    doc="store->load to one address must be ordered; load use stalls on memory")

add("inflight_credit_cap", lambda lanes: "tid r1\nmovi r2, 1\n" + "".join(
    f"    st r2, [r1+{100 + k}]\n" for k in range(24)) + "exit\n", nthreads=lambda l, w: l,
    profiles=(1, 2, 3), doc="24 back-to-back stores exceed MAX_INFLIGHT=15: credit stalls, no loss")

# ===================================================================== divergence / reconvergence
IFELSE = """
    tid  r1
    andi r2, r1, 1
    brz  r2, Lelse
    addi r3, r3, 1
    jmp  Lend
Lelse:
    addi r3, r3, 2
Lend:
    movi r5, 3
    mul  r4, r3, r5
    st   r4, [r1+100]
    exit
"""
add("diverge_if_else", IFELSE, nthreads=lambda l, w: 2 * l,
    check=c_all(c_hwm(2), c_eq("div_branches", 2)),
    doc="one divergent branch per warp: join + not-taken entry, reconverges at the join")

add("diverge_if_only", """
    tid  r1
    andi r2, r1, 1
    brz  r2, Lend
    addi r3, r3, 5
Lend:
    st   r3, [r1+500]
    exit
""", nthreads=lambda l, w: 2 * l, check=c_all(c_hwm(1), c_eq("div_branches", 2)),
    doc="taken target == reconvergence PC: empty-path elision, a single join entry")

add("uniform_branch_no_push", """
    wgid r2
    andi r2, r2, 1
    brz  r2, Lskip
    addi r3, r3, 9
Lskip:
    tid  r1
    wgid r7
    movi r8, 128
    mul  r7, r7, r8
    add  r7, r7, r1
    st   r3, [r7+800]
    exit
""", nthreads=lambda l, w: 2 * l, nwgs=2, check=c_all(c_hwm(0), c_eq("div_branches", 0)),
    doc="branch outcome uniform across the warp: no stack traffic")

add("nested_4_levels_at_limit", nested(4), nthreads=lambda l, w: l, cfgs=("rr32", "age32"),
    check=c_all(c_hwm(8), c_eq("faults", 0)),
    doc="4 nested divergent levels use exactly 8 = STACK_DEPTH entries")

add("nested_5_levels_overflow", nested(5), nthreads=lambda l, w: l, cfgs=("rr32", "age32"),
    check=lambda c, rtl, ref, lanes: expect(rtl.fault[0] == 1 and rtl.fault[1] == FAULT_STACK_OVF,
                                              f"expected STACK_OVF fault, got {rtl.fault}"),
    doc="the 5th nested level needs 10 entries: precise overflow fault, workgroup aborted, kernel completes")

add("nested_4_plus_single_entry_overflow", nested(4, tail=True), nthreads=lambda l, w: l, cfgs=("rr32", "age32"),
    check=lambda c, rtl, ref, lanes: expect(rtl.fault[0] == 1 and rtl.fault[1] == FAULT_STACK_OVF,
                                              f"expected STACK_OVF, got {rtl.fault}"),
    doc="full stack (8) + a region that needs exactly ONE more entry: boundary at STACK_DEPTH+1 must fault")
add("nested_depth4_config", nested(2), nthreads=lambda l, w: l, cfgs=("d4",), check=c_hwm(4),
    doc="STACK_DEPTH=4 build: 2 levels fit")
add("nested_depth4_overflow", nested(3), nthreads=lambda l, w: l, cfgs=("d4",),
    check=lambda c, rtl, ref, lanes: expect(rtl.fault[1] == FAULT_STACK_OVF, f"expected STACK_OVF, got {rtl.fault}"),
    doc="STACK_DEPTH=4 build: the 3rd level overflows")

add("loop_divergent_exit_constant_stack", """
    tid  r1
    andi r2, r1, 15
Lh: brz  r2, Lx
    addi r3, r3, 3
    addi r2, r2, -1
    jmp  Lh
Lx: st   r3, [r1+600]
    exit
""", nthreads=lambda l, w: l, check=c_all(c_hwm(1), c_ge("div_branches", 8)),
    doc="lanes leave a loop at different iterations: stack depth stays 1 however many iterations run")

add("do_while_divergent_latch", """
    tid  r1
    andi r2, r1, 7
    addi r2, r2, 1
Lh: addi r3, r3, 2
    addi r2, r2, -1
    bra  r2, Lh
    st   r3, [r1+610]
    exit
""", nthreads=lambda l, w: l, check=c_hwm(1),
    doc="backward conditional branch whose fall-through is the reconvergence point")

add("early_exit_merge", """
    tid  r1
    andi r2, r1, 1
    bra  r2, Lexit
    andi r2, r1, 2
    bra  r2, Lexit
    andi r2, r1, 4
    bra  r2, Lexit
    andi r2, r1, 8
    bra  r2, Lexit
    addi r3, r3, 1
Lexit:
    st   r3, [r1+700]
    exit
""", nthreads=lambda l, w: l, check=c_hwm(1),
    doc="4 early-exit branches to the single exit block share one reconvergence PC: merge keeps depth 1")

add("loop_break_nested_if", """
    tid  r1
    andi r2, r1, 7
    addi r2, r2, 2
Lh: brz  r2, Lx
    andi r4, r2, 1
    brz  r4, Lskip
    addi r3, r3, 5
Lskip:
    andi r5, r1, 4
    bra  r5, Lx
    addi r2, r2, -1
    jmp  Lh
Lx: st   r3, [r1+620]
    exit
""", nthreads=lambda l, w: 2 * l, doc="if inside loop with a break: nested reconvergence points inside one loop region")

add("partial_warp_diverge", IFELSE, nthreads=lambda l, w: l + l // 2 + 1,
    doc="partial last warp: lanes beyond the launch size never become active")

# ===================================================================== barriers
BAR_BASIC = """
    tid  r1
    addi r2, r1, 1000
    sts  r2, [r1+0]
    bar
    addi r3, r1, 1
    andi r3, r3, 127
    lds  r4, [r3+0]
    st   r4, [r1+900]
    exit
"""
add("barrier_basic", BAR_BASIC, nthreads=lambda l, w: min(4 * l, w * l), check=c_eq_fn("bar_episodes", lambda l: 1),
    doc="all warps of a workgroup meet at one barrier; neighbour data visible after it")
add("barrier_partial_warp", BAR_BASIC, nthreads=lambda l, w: l + l // 4, check=c_eq("bar_episodes", 1),
    doc="a partial warp (fewer lanes than WARP_SIZE) counts as one participant")
add("barrier_back_to_back", "tid r1\nbar\nbar\nbar\nst r1, [r1+950]\nexit\n", nthreads=lambda l, w: 2 * l,
    check=c_eq("bar_episodes", 3), doc="consecutive barriers: no warp may slip into the next episode early")
add("barrier_repeated_loop", """
    tid  r1
    movi r5, 5
Lloop:
    sts  r5, [r1+0]
    bar
    addi r3, r1, 1
    andi r3, r3, 63
    lds  r4, [r3+0]
    add  r6, r6, r4
    bar
    addi r5, r5, -1
    bra  r5, Lloop
    st   r6, [r1+1000]
    exit
""", nthreads=lambda l, w: min(3 * l, w * l), check=c_eq("bar_episodes", 10),
    doc="barriers inside a uniform loop: 2 episodes x 5 iterations")
add("barrier_many_workgroups_recycle", BAR_BASIC, nthreads=lambda l, w: 3 * l if w * l >= 6 * l else 2 * l,
    nwgs=6, launch_gap=3, cfgs=("rr32", "age32", "rr8"), check=c_eq("bar_episodes", 6),
    doc="more workgroups than slots: warp slots recycled; barriers of different workgroups stay isolated")


def exit_rule(lanes):
    return f"""
    tid  r1
    movi r2, {2 * lanes}
    slt  r2, r1, r2
    brz  r2, Lexit
    sts  r1, [r1+0]
    bar
    addi r3, r1, 1
    andi r3, r3, {2 * lanes - 1}
    lds  r4, [r3+0]
    bar
    st   r4, [r1+300]
Lexit:
    exit
"""


add("barrier_exited_warps_do_not_participate", exit_rule, nthreads=lambda l, w: min(4 * l, w * l),
    cfgs=("rr32", "age32", "rr8", "age8"), check=c_eq("bar_episodes", 2),
    doc="warps that EXIT before any barrier are not counted as participants")


def late_exit(lanes):
    return f"""
    tid  r1
    movi r2, {2 * lanes}
    slt  r2, r1, r2
    bra  r2, Lbar
    movi r5, 60
Ld: addi r5, r5, -1
    bra  r5, Ld
    jmp  Lexit
Lbar:
    sts  r1, [r1+0]
    bar
    lds  r4, [r1+0]
    st   r4, [r1+400]
Lexit:
    exit
"""


add("barrier_released_by_late_exit", late_exit, nthreads=lambda l, w: min(4 * l, w * l),
    profiles=(0, 1, 2), cfgs=("rr32", "age32", "rr8"), check=c_eq("bar_episodes", 1),
    doc="warps 0/1 wait at the barrier while warps 2/3 are still busy; their EXIT completes the episode")

add("barrier_after_divergence_reconverges", """
    tid  r1
    andi r2, r1, 7
Lh: brz  r2, Lx
    addi r2, r2, -1
    jmp  Lh
Lx: bar
    addi r3, r1, 1
    st   r3, [r1+700]
    exit
""", nthreads=lambda l, w: 2 * l, check=c_all(c_eq_fn("bar_episodes", lambda l: 1)),
    doc="a barrier AFTER the divergent region has reconverged is legal")

add("barrier_in_workgroup_uniform_if", """
    wgid r2
    andi r2, r2, 1
    brz  r2, Lskip
    tid  r1
    sts  r1, [r1+0]
    bar
    lds  r4, [r1+0]
    st   r4, [r1+800]
Lskip:
    exit
""", nthreads=lambda l, w: 2 * l, nwgs=3, check=c_eq("bar_episodes", 1),
    doc="a barrier under a workgroup-uniform branch: only workgroup 1 arrives")

# ===================================================================== invalid barrier / exit / faults
DIV_BAR = """
    wgid r2
    andi r2, r2, 1
    bra  r2, Lsafe
    tid  r1
    andi r3, r1, 1
    brz  r3, Lend0
    bar
Lend0:
    jmp  Lexit
Lsafe:
    tid  r1
    addi r4, r1, 5
    st   r4, [r1+500]
Lexit:
    exit
"""


def _fault_check(code, wg=0):
    return lambda c, rtl, ref, lanes: expect(rtl.fault[0] == 1 and rtl.fault[1] == code and rtl.fault[2] == wg,
                                              f"fault record {rtl.fault}, expected code {code} wg {wg}")


add("divergent_barrier_fault", DIV_BAR, nthreads=lambda l, w: l, nwgs=2, check=_fault_check(FAULT_DIV_BARRIER),
    doc="BAR executed while the warp is diverged: FLT_DIV_BARRIER, workgroup 0 aborted, workgroup 1 unaffected")
add("divergent_barrier_fault_multiwarp", DIV_BAR, nthreads=lambda l, w: 3 * l, nwgs=2, fault_exact_warp=False,
    check=_fault_check(FAULT_DIV_BARRIER), doc="same, several warps fault; the whole workgroup is aborted without deadlock")

add("divergent_exit_fault", """
    tid  r1
    andi r2, r1, 1
    brz  r2, Lcont, Lcont
    exit
Lcont:
    st   r1, [r1+600]
    exit
""", nthreads=lambda l, w: l, check=_fault_check(FAULT_DIV_EXIT),
    doc="EXIT while diverged (program violates the single-exit contract): FLT_DIV_EXIT")

add("illegal_instruction_fault", "nop\n.word 0xFC000000\nexit\n", nthreads=1, check=_fault_check(FAULT_ILLEGAL),
    doc="undefined opcode")
add("fetch_fault_fall_off_end", "nop\nnop\n", nthreads=1, check=_fault_check(FAULT_FETCH),
    doc="no EXIT: the fetch past the program end errors")
add("jump_out_of_range_fault", "jmp @-5\nexit\n", nthreads=1, check=_fault_check(FAULT_PC_RANGE),
    doc="jump target below 0")
add("launch_zero_threads", "exit\n", nthreads=0, check=_fault_check(FAULT_LAUNCH), check_counters=False,
    doc="invalid launch (0 threads) is consumed, faulted, and does not hang kernel completion")
add("launch_too_many_threads", "exit\n", nthreads=lambda l, w: l * w + 1, check=_fault_check(FAULT_LAUNCH), check_counters=False,
    doc="invalid launch (more threads than warp slots)")

STRICT = lambda lanes: f"""
    tid  r1
    movi r2, {lanes}
    slt  r2, r1, r2
    bra  r2, Lw0
    bar
    jmp  Lend
Lw0:
    bar
Lend:
    exit
"""
add("strict_barrier_pc_mismatch_fault", STRICT, nthreads=lambda l, w: 2 * l, cfgs=("strict32",), fault_exact_warp=False,
    check=_fault_check(FAULT_BAR_PC), doc="STRICT_BAR_PC=1: two different BAR instructions in one episode -> FLT_BAR_PC")
add("lenient_barrier_pc_pairing", STRICT, nthreads=lambda l, w: 2 * l, cfgs=("rr32", "age32"), check=c_eq("bar_episodes", 1),
    doc="default mode: arrivals at different BAR instructions are one episode (counted by warps, not by pc)")

# ===================================================================== resources / kernel completion / scheduling
add("resource_recycle_12_workgroups", """
    tid  r1
    wgid r2
    movi r3, 64
    mul  r4, r2, r3
    add  r4, r4, r1
    addi r5, r4, 7
    movi r6, 2000
    add  r4, r4, r6
    st   r5, [r4+0]
    exit
""", nthreads=lambda l, w: l + l // 2, nwgs=12, launch_gap=2, cfgs=("rr32", "age32", "rr8", "age8"),
    doc="12 workgroups through 4 workgroup slots: allocation is all-or-nothing, slots are reused, kernel_done after the last")

add("kernel_done_waits_for_stores", """
    tid  r1
    movi r2, 5
""" + "".join(f"    st r2, [r1+{200 + k}]\n" for k in range(12)) + "    exit\n",
    nthreads=lambda l, w: l, profiles=(2, 3), doc="kernel_done only after every store has committed")

add("two_kernels_back_to_back", IFELSE, nthreads=lambda l, w: l, reps=2, cfgs=("rr32", "age32"),
    doc="kernel_clear returns the unit to idle with cleared status/counters; a second kernel runs identically")

add("fairness_identical_warps", """
    tid  r1
    movi r2, 3
    movi r5, 40
Lh: add  r2, r2, r1
    xor  r3, r2, r5
    addi r5, r5, -1
    bra  r5, Lh
    st   r3, [r1+900]
    exit
""", nthreads=lambda l, w: l * w, cfgs=("rr32", "age32"), profiles=(0, 1),
    check=lambda c, rtl, ref, lanes: expect(len({c[f"warp_issued_{w}"] for w in range(8)}) == 1,
                                             f"per-warp issue counts differ: {[c[f'warp_issued_{w}'] for w in range(8)]}"),
    doc="eight identical warps: each issues exactly the same number of instructions")


add("hostile_downstream_spurious_completions_and_fetches", IFELSE, nthreads=lambda l, w: 2 * l, nwgs=2,
    cfgs=("rr32", "age32"), profiles=(0, 1, 2), extra_args=("+spurious=25", "+sfx_allow_proto_err"), allow_proto=True,
    doc="backend/imem inject completions and fetch responses for contexts with nothing outstanding: "
        "they are refused (proto_err counted) and architectural state is unaffected")
add("hostile_downstream_barriers_loops", """
    tid  r1
    movi r5, 3
Lloop:
    sts  r5, [r1+0]
    bar
    addi r3, r1, 1
    andi r3, r3, 63
    lds  r4, [r3+0]
    add  r6, r6, r4
    ld   r7, [r1+0]
    bar
    addi r5, r5, -1
    bra  r5, Lloop
    st   r6, [r1+1000]
    exit
""", nthreads=lambda l, w: min(3 * l, w * l), nwgs=2, cfgs=("rr32", "age32"), profiles=(1, 2),
    extra_args=("+spurious=30", "+sfx_allow_proto_err"), allow_proto=True,
    doc="same hostile downstream with barrier episodes and memory traffic in flight")


def class_gating_program(lanes):
    """warps 0,1 stream MEM instructions, warps 2..7 stream independent ALU instructions."""
    out = ["tid r1", "movi r2, 5", "shr r3, r1, r2", "movi r4, 2", "slt r5, r3, r4",
           "movi r7, 64", "mul r6, r1, r7", "bra r5, Lmem"]      # r6 = private 64-word slice per thread
    for k in range(120):
        out.append(f"add r{10 + k % 20}, r1, r1")
    out.append("jmp Lexit")
    out.append("Lmem:")
    for k in range(60):
        out.append(f"st r1, [r6+{k}]")
    out += ["Lexit:", "exit"]
    return "\n".join(out) + "\n"


def check_memory_warps_interleave(c, rtl, ref, lanes):
    """The two MEM-streaming warps compete for the MEM class, which is busy for a fixed window after
    every accept while ALU warps keep the issue slot busy.  Bounded wait: between two consecutive MEM
    issues of one warp, the OTHER MEM warp may issue at most `bound` MEM instructions
    (RR: N-1 same-class grants; AGE: STARVE_LIMIT + N).  With a single-pointer arbiter the pointer is
    parked in front of one warp and the other never issues (gap = 60)."""
    cfg = rtl.cfg
    bound = (cfg.num_warps - 1) if cfg.sched_policy == 0 else (cfg.starve_limit + cfg.num_warps)
    idx = {0: [], 1: []}
    for i, (wg, w, pc) in enumerate(rtl.order):
        if w in (0, 1) and pc >= 8 + 120 + 1:              # inside the Lmem block (after prologue + ALU block + jmp)
            idx[w].append(i)
    if len(idx[0]) < 60 or len(idx[1]) < 60:
        return [f"unexpected MEM-block issue counts {len(idx[0])}/{len(idx[1])}"]
    errs = []
    for me, other in ((0, 1), (1, 0)):
        stamps = [-1] + idx[me]
        worst = 0
        for a, b in zip(stamps, stamps[1:]):
            n_other = sum(1 for j in idx[other] if a < j < b)
            worst = max(worst, n_other)
        # the very first wait starts when the warp first requests (its first MEM issue is the end of the gap)
        if worst > bound:
            errs.append(f"MEM warp {me} waited while warp {other} issued {worst} MEM instructions in a row "
                        f"(bound {bound}) - starvation")
    return errs


add("fairness_class_gating_no_starvation", class_gating_program, nthreads=lambda l, w: l * w, cfgs=("rr32", "age32"),
    profiles=(4, 5), check=check_memory_warps_interleave,
    doc="MEM class busy for a fixed window after every accept while ALU warps keep the issue slot busy: "
        "two MEM warps must share the MEM slots (class-gated candidacy must not let the pointer skip a ready warp)")


add("hostile_downstream_out_of_mask_branch_outcomes", nested(3), nthreads=lambda l, w: l + l // 2,
    cfgs=("rr32", "age32"), profiles=(0, 1, 2), extra_args=("+spurious=30", "+sfx_allow_proto_err"), allow_proto=True,
    doc="branches issued with a PARTIAL mask (nested divergence + partial warp) get outcomes that also name lanes "
        "outside the issued mask: the control unit must intersect with the active mask (BC7 is not trusted)")


def all_tests() -> List[T]:
    return TESTS


# ===================================================================== configuration reaches the arbiter (policy 2)
def cfg_effect_test(cfg):
    """The policy-2 weights are a RUNTIME input (sched_cfg).  Run one mixed kernel on `cfg` (a policy-2 build) twice,
    with the default weights and with an adversarial compute-first set.  Both runs must be architecturally identical to the
    reference (a policy never changes results) AND must issue in a DIFFERENT global order - otherwise the configuration
    never reached the arbiter (found by mutation testing: a build that ignores `sched_cfg` passed every other test).
    Returns a list of error strings."""
    import os, sys
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tools"))
    from sfx_isa import assemble
    from sfx_gen import make_init_mem
    from sfx_ref import SimtSim
    from sfx_run import run_rtl, compare
    import wl_gen
    wl = wl_gen.FAMILIES["mixed"](101)
    prog = assemble(wl.asm).words
    mem = make_init_mem(101)
    nth = wl.nwarps * 32
    ref = SimtSim(prog, cfg.ref_cfg(), mem).run(nth, wl.nwgs)
    adversarial = ["+sc_w_cls_alu=7", "+sc_w_cls_mem=0", "+sc_w_cls_br=0", "+sc_w_cls_ctrl=0", "+sc_w_ld=0", "+sc_w_memdep=0",
                   "+sc_w_dep=0", "+sc_w_bar=0", "+sc_w_rel=0", "+sc_w_cap=0", "+sc_w_age=0"]
    runs = {}
    for name, args in (("default", []), ("compute-first", adversarial)):
        r = run_rtl(cfg, prog, mem, nth, wl.nwgs, 1, 5, 0, 1, extra_args=args)
        if not r.ok:
            return [f"cfg-effect: {name} run failed: {r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ''}"]
        errs = compare(r, ref, cfg, mem)
        if errs:
            return [f"cfg-effect: {name} run differs from the reference: {errs[0]}"]
        runs[name] = r
    if runs["default"].order == runs["compute-first"].order:
        return ["cfg-effect: default and compute-first weights produced an IDENTICAL issue order - sched_cfg does not reach the arbiter"]
    return []
