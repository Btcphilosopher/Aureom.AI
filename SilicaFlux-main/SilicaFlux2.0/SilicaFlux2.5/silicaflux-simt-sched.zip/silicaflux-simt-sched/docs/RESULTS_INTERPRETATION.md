# What the measurements say

This page interprets the run archived in `results/` (held-out seeds 101-116, 8 families, geometries g8 and g16, 256 workload instances, 5 scheduler variants,
1,280 simulations, all bit-exact against the reference model). **`results/REPORT.md` is generated and authoritative for every number; this page is
hand-written** and describes that archived run only. If you re-run with other seeds, regenerate the report and re-read this page critically.

## 1. The honest summary

1. **The existing age-aware policy is measurably worse than round-robin** on this model: +5.1 % cycles [4.5, 5.8], +7.0 % p95 workgroup latency,
   +8.7 % slowest workgroup, in every family except pure compute (a tie). Its Jain fairness is 0.84 vs 0.975.
2. **Policy 2 with the default weights does not improve throughput.** Kernel cycles ratio 1.000 [0.999, 1.001]: no measurable difference to round-robin overall.
   Measured, statistically clear but small effects: *better* on `barrier` (-0.7 % cycles, -9.7 % idle); *worse* idle on `depalu` (+6.3 %) and slightly
   worse p95 workgroup latency on `barrier` and `depalu` (+0.6 % to +0.9 %).
3. **What policy 2 does achieve is the thing it was designed for at the micro level**: the wake-to-issue wait of memory-dependent warps falls from
   1.02 to 0.55 cycles on average and from 4.9 to 1.8 cycles at the worst case, with Jain fairness 0.978 (round-robin 0.975) and bounded waiting. It cannot
   turn that into makespan, because under round-robin that wait was already about one cycle per instruction while the memory latencies in the model are
   100-300 cycles.
4. **A configuration found by search on development seeds buys a little more cycle time and gives up the wake-up benefit.** Held-out result: cycles
   0.996 [0.995, 0.997] overall (statistically detectable, but below the 0.5 % materiality threshold fixed beforehand, so the claim rule reports it as *n.s.*),
   `barrier` 0.985, `depalu` 0.989 (*better*), idle cycles -3.9 %. The same configuration has a worse worst-case memory-dependent wake wait (7.1 cycles
   vs 4.9 for round-robin) and worse longest wait (19.4 vs 15.1). There is no configuration in this evaluation that is best on all of these at once.

So: **no throughput improvement is claimed for policy 2.** What is claimed, and measured, is bounded fairness with an explicit compute-vs-memory guard, much
faster wake-up of memory-dependent warps at equal throughput (default weights), a small gain on barrier-heavy and dependent-ALU workloads with the tuned
configuration at the price of that wake-up benefit, and a clear negative result for the age policy.

## 2. Where the baseline wins, and why

| observation (test seeds) | evidence | explanation |
|---|---|---|
| round-robin has the shortest worst-case wait: 15.1 cycles vs 19.3 (aware), 25.7 (age) | REPORT section 4 | its class-level rotation gives a bound of 4N-1 grants with no priorities to override; policy 2's guard only intervenes after `fair_limit` lost grants, so a low-score warp legitimately waits longer before it is promoted |
| `depalu`: policy 2 default has +6.3 % idle cycles [5.2, 8.2] and +0.9 % p95 workgroup latency | REPORT 3.2, 3.4 | in this family 80 % of RR's idle cycles are "backend class busy" (consistent with the multiplier occupying the ALU port for one extra cycle after each accept, about one multiply per nine ALU instructions): in those cycles no ALU instruction can issue whoever is chosen, so arbitration order changes only *when* the gaps fall. The default weights are not helpful here; the idle increase is measured, the exact mechanism was not isolated |
| `barrier`: policy 2 default improves cycles by 0.7 % but p95 workgroup latency is 0.6 % *worse* | REPORT 3.1, 3.4 | the straggler boost shortens the whole kernel but delays the completion of some other workgroups; the cycles/latency trade-off is real, not noise (CIs exclude 1) |
| `compute`, `diverge`, `ldchain`, `memstream`, `mixed`, `skew`: **no variant beats round-robin on cycles** | REPORT section 6 | two different reasons. *Throughput-bound* (`compute` IPC 0.978, `skew` 0.987): the issue slot is almost always used, so any work-conserving order issues the same number of instructions in the same number of cycles. *Latency-bound* (`ldchain` IPC 0.16, `memstream` 0.058): the critical path is a chain of 100-300 cycle memory latencies; the mean candidate-to-issue wait of an ordinary instruction is only 0.01-4.7 cycles under round-robin (REPORT 4, candidate-to-issue wait table), so a better choice of warp has that little to save |
| policy 2 with all weights 0 is +0.4 % cycles vs round-robin | REPORT 2 | a single rotating pointer plus guards is a slightly weaker arbiter than the existing two-level class round-robin; the default weights recover parity, they do not exceed it |
| age loses everywhere | REPORT 2, 3, 5 | oldest-first concentrates issue slots on older warps and leaves the long chains of younger warps for the end. On `skew` the idle-cycle breakdown shows it: fetch-latency idle 1028 cycles vs 5, branch 317 vs 5, dependency 134 vs 27 - at the tail only one or two warps remain and nothing hides their own latencies, so idle cycles are 9.6x round-robin's and the kernel is 9.4 % longer |

## 3. What drives the small gains (post-hoc ablation, REPORT 7b)

* The `barrier` gain is **caused by the barrier features**: with `w_bar = w_rel = 0` it disappears (1.0025 vs 0.9845). That is the straggler boost and the
  "this issue releases the barrier" bonus working, and they are fed by values the monitor re-derives independently (M6).
* The fairness guards are cheap and necessary: with both off the mean per-run longest wait grows from 19 to 86 cycles for 0.25 % of cycles, and the `depalu`
  gain turns into a 0.5 % loss.
* The `depalu` gain comes mostly from the static class bonuses and the dependency terms; I can state which switches matter but not a physical story.
* Removing aging (`w_age = 0`) makes `diverge` and `memstream` slower than round-robin (ratios 1.007 and 1.005; with aging they are 0.999 and 0.998).

## 4. Threats to validity

* **One model.** No cache, bank or row-buffer behaviour, one issue slot, a single-entry instruction buffer per warp (see `COMPARISON_METHOD.md` 7). Gains that
  come from locality or bandwidth shaping cannot show up, and costs of ignoring them cannot either.
* **Tuning scope.** The weight search used development seeds of the *same eight families*; held-out seeds test generalisation to new instances, not to new kinds
  of kernel. No out-of-family validation was done.
* **Small, synthetic kernels** (3k-20k warp instructions). Tie bands and CIs describe sampling over instances, not over real applications.
* **No timing or area measurement.** The grant path of policy 2 is the deepest of the three and also drives the backend issue interface in the same cycle;
  whether that closes timing is unknown. The state / operator counts in REPORT section 9 are analytical.
* **Fairness bound is not formally proved** (`SCHEDULER_POLICIES.md` 3.3).
* The monitor and assertions check the properties named in `SCHEDULER_POLICIES.md`; passing them does not prove the absence of other defects.

## 5. Practical reading

* If worst-case waiting and simplicity matter most: keep round-robin (policy 0).
* If the workload is barrier-heavy or latency-sensitive memory-dependent warps must be woken quickly, policy 2 is a reasonable, bounded-fairness option; choose
  the default weights for wake-up latency and fairness, the tuned weights for barrier-heavy kernels, and measure on your own kernels first.
* Do not use the age policy for these workloads.
