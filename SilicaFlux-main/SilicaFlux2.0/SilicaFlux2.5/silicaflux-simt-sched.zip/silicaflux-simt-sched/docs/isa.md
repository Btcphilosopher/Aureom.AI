# SFX-SIMT instruction set (v1)

A small 32-bit RISC-style ISA that is just large enough to exercise every
mechanism of the control unit (dependencies, memory, divergence, barriers).  It
is defined independently in four places that are cross-checked:
`tools/sfx_isa.py` (assembler / disassembler), `tools/sfx_ref.py` (semantics),
`rtl/sfx_simt_pkg.sv` (decode used by the control unit) and
`tb/sfx_be_model.sv` (backend semantics, written separately from the RTL decoder).

All threads have 32 general registers `r0..r31` of 32 bits.  **`r0` reads as zero
and writes to it are discarded** (the scoreboard never tracks it).  A new warp
starts with all registers zero.

## Encoding

```
 31      26 25   21 20   16 15   11 10            0
+----------+-------+-------+-------+---------------+
|  opcode  |   A   |   B   |   C   |     imm11     |
+----------+-------+-------+-------+---------------+
```

| format | fields |
|---|---|
| R   | `rd=A rs1=B rs2=C` |
| I   | `rd=A rs1=B imm11` (`ADDI`,`LD`,`LDS` sign-extended; `ANDI` zero-extended) |
| S   | `rs1=B` (base) `rs2=C` (data) `imm11` sign-extended |
| MOVI | `rd=A`, `imm16 = instr[15:0]` sign-extended (bits `[20:16]` = 0) |
| BR  | `rs1=A` (predicate), `rpc_off = instr[20:11]` (10 bit, unsigned), `tgt_off = instr[10:0]` (11 bit, signed) |
| JMP | `tgt_off = instr[10:0]` |

Branch addresses are instruction-word indices.  For a branch at `b`:
`F = b+1`, `T = b+1+tgt_off`, `R = b+1+rpc_off` (the reconvergence PC, see
`divergence_model.md`).

## Instructions

| op | mnemonic | class | semantics |
|---|---|---|---|
| 00 | `nop`                    | CTRL | |
| 01..09 | `add sub and or xor shl shr slt mul` `rd,rs1,rs2` | ALU | 32-bit; `shl/shr` use `rs2[4:0]`, `shr` is logical, `slt` signed -> 0/1, `mul` low 32 bit |
| 0A | `addi rd,rs1,imm` | ALU | `rs1 + sext(imm11)` |
| 0B | `andi rd,rs1,imm` | ALU | `rs1 & zext(imm11)` |
| 0C | `movi rd,imm16`   | ALU | `sext(imm16)` |
| 0D | `tid rd`          | ALU | thread index inside the workgroup = `warp_idx*WARP_SIZE + lane` |
| 0E | `wgid rd`         | ALU | workgroup id given at launch |
| 10 | `ld  rd,[rs1+imm]` | MEM | global memory word `(rs1+sext(imm)) mod GMEM_WORDS` |
| 11 | `st  rs2,[rs1+imm]`| MEM | store; if several lanes hit one address the highest lane wins |
| 12 | `lds rd,[rs1+imm]` | MEM | shared memory of the workgroup (word address `mod SMEM_WORDS`) |
| 13 | `sts rs2,[rs1+imm]`| MEM | shared store |
| 20 | `bra rs1,T[,R]`   | BR   | lanes with `rs1 != 0` take the branch |
| 21 | `brz rs1,T[,R]`   | BR   | lanes with `rs1 == 0` take the branch |
| 22 | `jmp T`           | CTRL | uniform jump (all active lanes) |
| 23 | `bar`             | CTRL | workgroup barrier (convergent only) |
| 24 | `exit`            | CTRL | retire the warp (convergent only) |

* **Class** decides where an instruction executes: `ALU`, `MEM` and `BR` go to
  the backend (`be_*` interface, one completion each); `CTRL` instructions are
  executed inside the control unit and retire at issue.
* A branch with the reconvergence field omitted or `auto` is completed by the
  tool chain (`tools/sfx_cfg.py`) with the immediate post-dominator.
* Memory consistency: operations of one warp take effect in program order;
  threads of different warps are ordered only by `bar` (data written before a
  barrier by any thread of the workgroup is visible to every thread after it).
  Programs that race on a word are outside the model.

## Assembly syntax (`tools/sfx_asm.py`)

```
        tid  r1
        andi r2, r1, 1
        brz  r2, Lelse          ; reconvergence PC computed by the CFG pass (immediate post-dominator)
        addi r3, r3, 1
        jmp  Lend
Lelse:  addi r3, r3, 2
Lend:   st   r3, [r1+100]
        exit
        .word 0xFC000000         ; raw word (used to build an illegal-opcode test)
```
`bra rP, target, Lrpc` gives an explicit reconvergence label; `@N` is an
absolute address.
