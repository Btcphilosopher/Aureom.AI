# SFX-SIMT divergence and reconvergence model

This document is the architectural definition of branch divergence,
reconvergence, convergent barriers and kernel exit for the SilicaFlux SIMT
control unit.  It is implemented three times and the three are compared
against each other by the test-bench:

| implementation                                  | role                                                         |
|-------------------------------------------------|--------------------------------------------------------------|
| `tools/sfx_ref.py: resolve_branch(), SimtSim`   | executable specification (bit-exact, no timing)              |
| `rtl/sfx_diverge_unit.sv` + `rtl/sfx_simt_ctrl.sv` | the hardware                                              |
| `tools/sfx_ref.py: OracleSim`                   | independent per-thread semantics (ground truth for legal programs) |

## 1. Terms

* **Warp** – `WARP_SIZE` lanes executing in lock-step; lane `l` of warp `k`
  of a workgroup is thread `k*WARP_SIZE + l`.
* **Launch mask `L`** – the lanes that exist (all ones except possibly in the
  last warp of a workgroup whose thread count is not a multiple of `WARP_SIZE`).
* **Context `C = (pc, mask, rpc)`** – the path the warp is executing now.
  `mask` is the *execution mask*; only lanes in `mask` read/write registers,
  access memory, or contribute to branch outcomes.  `rpc` is the PC at which
  this context ends (its *reconvergence PC*); it is meaningful only when the
  stack is non-empty.
* **Stack `S[0 .. sp-1]`** – suspended contexts, `S[sp-1]` is the top.
  `sp` is the *stack depth*; `sp = 0` means the warp is **converged**.

All PCs are instruction-word indices of `PC_W` bits.

## 2. Stack entries

```
entry = { pc   : PC_W bits   -- where the suspended lanes resume
          mask : WARP_SIZE bits -- which lanes
          rpc  : PC_W bits   -- the reconvergence PC of the context they resume as }
```

| default parameters | value |
|---|---|
| entry width | 16 + 32 + 16 = 64 bit |
| `STACK_DEPTH` | 8 entries per warp (parameter, >= 2) |
| storage | 8 x 64 = 512 flip-flops per warp slot, 4096 for 8 warps |

The *current* context lives in the warp's `pc/mask/rpc` registers, **not** in
the stack memory, so the stack holds only suspended contexts.  Because the
two entries of a divergent branch are written in one cycle, and a pop can come
from either the issue path or the branch-resolution path, the stack is a flop
array with two write ports and two read ports (not an SRAM).

Entry 0 (the bottom) always belongs to the converged base context; its `rpc`
field is never read.

### Invariants (all checked by assertions in `rtl/sfx_simt_checks.svh`, group A6)

| # | invariant |
|---|-----------|
| I1 | `sp = 0`  <=>  `C.mask = L`  (a warp is converged exactly when all existing lanes are active) |
| I2 | `C.rpc` is valid iff `sp != 0` (there is no `rpc` valid-bit; `sp != 0` is the valid bit) |
| I3 | `C.mask != 0`, `C.mask ⊆ L`; every stack entry mask is non-empty and `⊆ L` |
| I4 | `C.pc != C.rpc` while the context is waiting to issue (a context that reaches its RPC is popped at once) |
| I5 | every entry with index >= 1 has `pc != rpc` |
| I6 | `sp <= STACK_DEPTH` |

I1 holds because every push is the result of splitting a mask into two
non-empty parts, so every context above the base is a strict subset of its
parent.

## 3. Operations

Let `advance(npc)` be the **only** place where the stack is popped:

```
advance(npc):                       # called after every issued instruction that has a next PC
    if sp != 0 and npc == C.rpc:    # the context has reached its reconvergence point
        (C.pc, C.mask, C.rpc) = S[sp-1];  sp -= 1          # resume the suspended lanes
    else:
        C.pc = npc
```

By I4/I5 a pop is never followed by another pop, so `advance` is single-cycle.

| instruction class | effect |
|---|---|
| ALU / memory / `NOP` | executes for lanes in `C.mask`; `advance(pc+1)` |
| `JMP t`              | `advance(t)`  (uniform, resolved in the control unit, no backend round trip) |
| `BRA p,t,R` / `BRZ p,t,R` | issued to the backend with `C.mask`; the warp waits (`WAIT_BR`) for the per-lane outcome; then `resolve` (below) |
| `BAR`                | requires `sp = 0` (section 6); `pc += 1`; warp parks at the workgroup barrier |
| `EXIT`               | requires `sp = 0` (section 6); the warp retires |

### 3.1 Branch resolution (`resolve`)

For a branch at `b` with target `T = b+1+tgt_off`, fall-through `F = b+1`,
reconvergence PC `R = b+1+rpc_off`, active mask `A = C.mask` and taken lanes
`Mt = outcome & A` (lanes whose predicate is non-zero for `BRA`, zero for
`BRZ`), `Mn = A & ~Mt`:

```
if F, T or R is outside [0, 2^PC_W):          FAULT_PC_RANGE
elif Mn == 0:                                  advance(T)           # uniform taken
elif Mt == 0:                                  advance(F)           # uniform not taken
elif T == R and F == R:                        advance(R)           # both paths empty
else:                                          # real divergence
    join = not (sp != 0 and R == C.rpc)        # merge optimisation   (section 4.2)
    both = (T != R) and (F != R)               # empty-path elision   (section 4.1)
    n    = join + both                         # entries to push
    if sp + n > STACK_DEPTH:                   FAULT_STACK_OVF        # nothing has been modified
    if join: push (R, A,  C.rpc)               # the lanes that wait for everybody
    if both: push (F, Mn, R)                   # the not-taken path, runs after the taken path
    if T != R:  C = (T, Mt, R)                 # taken path first
    else:       C = (F, Mn, R)                 # taken path is empty: continue with not-taken
```

The taken path always runs first.  The two push orders (`join` below, `not-taken`
above) put the not-taken path on top of the join.  Pushes happen only on a real
divergence, never on a uniform branch.

`resolve` is a pure function of its arguments; the RTL unit and the Python
function share one test-vector set (`tools/gen_diverge_vectors.py`, 160 000
vectors over four configurations) in `tb/tb_unit_diverge.sv`.

### 3.2 Worked example

`if (tid & 1) A else B` on a 4-lane warp (`BRZ` is taken by the even lanes, so
the *else* arm runs first).  Generated by `SimtSim`, not written by hand
(`results/worked_example.txt`):

```
pc  instruction          active  ctx.rpc  sp  stack (bottom first, entries are (pc,mask,rpc))
0   tid r1               1111    -        0
1   andi r2, r1, 1       1111    -        0
2   brz r2, @5, @6       1111    -        0                 <- divergent: T=5, F=3, R=6
5   addi r3, r3, 2       0101    6        2   (6,1111,0) (3,1010,6)     else arm (even lanes)
3   addi r3, r3, 1       1010    6        1   (6,1111,0)               popped: then arm resumes
4   jmp @6               1010    6        1   (6,1111,0)
6   st r3, [r1+100]      1111    -        0                 <- JMP target == rpc: pop, lanes reconverged
7   exit                 1111    -        0
```

## 4. The two stack optimisations (and why they are not optional)

### 4.1 Empty-path elision
If `T == R` (an `if` without `else`) or `F == R` (a loop back-edge, whose
fall-through *is* the loop exit) one of the two paths is empty.  Pushing it would
create an entry whose `pc == rpc`, which could only be popped by a second pop
cycle.  Instead the empty side simply waits in the `join` entry.

### 4.2 Merge
If the new region reconverges where the *enclosing* context already
reconverges (`R == C.rpc`), the enclosing context's own pending entries already
bring those lanes back, so no `join` entry is needed.

**Without the merge, a loop with data-dependent exits would push one `join`
entry per iteration** and overflow any finite stack.  With it, the stack depth
is a property of the *static nesting* of the code, not of the number of
dynamic iterations (directed tests `loop_divergent_exit_constant_stack`,
`early_exit_merge`, `do_while_divergent_latch`; mutants `div_no_merge`,
`div_no_empty_elision`).

## 5. Overflow handling and nesting limits

* **Detection** – before any state is modified: `sp + n > STACK_DEPTH`.  The
  branch has already been issued and retired (it is in the issue trace), the
  stack and context are untouched.
* **Reaction** – `FLT_STACK_OVF` is recorded in the kernel fault record
  (`fault_code/fault_wg_id/fault_widx/fault_pc`, `fault_mask` bit 3) and the
  **whole workgroup is aborted** (section 7).  There is no spill to memory and
  no silent corruption.  `kernel_done` still asserts.
* **Nesting limit** – a divergent region costs `n <= 2` entries, so
  `STACK_DEPTH = 8` supports **4 levels of fully divergent nesting in the worst
  case** (both paths non-empty and distinct reconvergence PCs): exactly
  8 entries.  A 5th level faults (`nested_5_levels_overflow`).  A region whose
  `rpc` equals its parent's and/or that has an empty path costs 0 or 1
  entries, so real programs nest deeper; the boundary at `STACK_DEPTH + 1`
  for a *single* extra entry is tested separately
  (`nested_4_plus_single_entry_overflow`, mutant `div_overflow_off_by_one`).
* **Static bound for a compiler** – let the open divergent regions at a
  program point be `r_1 ⊃ r_2 ⊃ …`.  The stack demand is
  `Σ cost(r_i)` with `cost = [R_i != R_{i-1}] + [both paths non-empty]`
  (`R_0` = "no enclosing region").  `2 × nesting depth` is a safe upper bound.
* Stack occupancy is exported as `cnt_stack_hwm` (high-water mark over all
  warps).

## 6. Convergent barriers and exit

`BAR` and `EXIT` are **convergent instructions**: they may only execute when
`sp = 0` (equivalently, by I1, when the execution mask equals the launch mask).

| usage | defined behaviour |
|---|---|
| `BAR` with `sp != 0` (some lanes of the warp are suspended) | `FLT_DIV_BARRIER` at the BAR's pc; the instruction does not execute and is not traced; the workgroup is aborted (no hang: the other warps are killed, not left waiting) |
| `EXIT` with `sp != 0` | `FLT_DIV_EXIT`, same handling |
| `BAR` where only *some warps* of the workgroup arrive (e.g. under a warp-uniform branch) | **not** an error: the barrier is complete when every *live* warp has arrived; warps that have exited (or been killed) do not participate (see `architecture.md`, section 7) |
| two *different* `BAR` instructions arrived in one episode | allowed in the default build (episodes are counted by warps, not by pc); `STRICT_BAR_PC=1` turns it into `FLT_BAR_PC` |

A barrier after a divergent region *has reconverged* is legal and is tested
(`barrier_after_divergence_reconverges`).  A thread that left the warp's
context early (e.g. `if (c) return;` compiled as a branch to the exit block)
remains in a `join` entry until the exit block, so the warp is **not**
converged between the early exit and the exit block; a `BAR` placed there is
a divergent barrier (the generator therefore never emits a barrier after a
data-dependent early exit).

There is deliberately **no lane-granular `EXIT`**: a single exit block that
every path reaches (see section 8, C1) makes `EXIT` convergent by
construction, and removes the need to mask exited lanes out of every stack
entry.

## 7. Faults and workgroup abort

| code | name | raised when |
|---|---|---|
| 1 | `DIV_BARRIER` | `BAR` with `sp != 0` |
| 2 | `DIV_EXIT` | `EXIT` with `sp != 0` |
| 3 | `STACK_OVF` | `sp + n > STACK_DEPTH` at a divergent branch |
| 4 | `ILLEGAL` | undefined opcode fetched |
| 5 | `FETCH` | instruction memory reported an error (e.g. pc past the program) |
| 6 | `PC_RANGE` | a computed PC (`F`, `T`, `R`, next sequential PC, `JMP` target) is outside `[0, 2^PC_W)` |
| 7 | `BAR_PC` | strict mode: BAR pc differs from the episode's first BAR |
| 8 | `LAUNCH` | launch of 0 threads or more threads than `NUM_WARPS*WARP_SIZE` (consumed, not allocated) |

The faulting warp enters `DRAIN`; its workgroup is flagged `abort`; every
other warp of the workgroup moves to `DRAIN` on the next cycle, no new
instruction issues and no barrier releases for that workgroup; a slot is freed
only after its in-flight instructions have completed and its outstanding fetch
has been answered.  Other workgroups are unaffected.  Memory written by an
aborted workgroup is indeterminate.  The first fault is latched in the fault
record; `fault_mask` accumulates every code seen.

## 8. Relationship to compiler-generated control flow

The hardware does **not** discover reconvergence points.  The compiler encodes
one in every `BRA/BRZ`.  The contract:

| # | rule |
|---|------|
| C1 | The kernel has **one** `EXIT`, which every path reaches (early `return` = branch to the exit block). |
| C2 | For every `BRA/BRZ` at `b`, `R` is a **post-dominator** of `b` (every path from `b` reaches `R`), and `R >= b+1` (the field is an unsigned forward offset).  The **immediate** post-dominator is the best choice (earliest reconvergence); any later post-dominator is also correct, just less efficient. |
| C3 | A loop back-edge `BRA`'s fall-through is the loop exit: `R = b+1`.  A `while` loop is `head: BRZ c, exit` + body + `JMP head`, with `R(head) = exit`. |
| C4 | A reconvergence label must be a distinct instruction address from an enclosing region's label if the compiler wants the two regions to cost separate entries – coincident labels merge (this is an optimisation, not a rule). |
| C5 | `BAR` only where the warp is converged (`sp = 0`): top-level code, uniform loops, workgroup-uniform `if`s, or after a divergent region has reconverged. |
| C6 | Static stack demand (section 5) `<= STACK_DEPTH`. |
| C7 | Branch targets and `R` within +-1023 / +1023 instructions (11/10-bit fields); longer distances need trampolines. |

Why a post-dominator is sufficient: lanes that leave the branch must meet again
at a node that all of them are guaranteed to reach, and for nested divergent
branches inside the region, any post-dominator of the outer branch that the
inner branch can reach before leaving the region also post-dominates the inner
branch, so inner `R` values are always reached first and the stack discipline
(last pushed, first popped) holds.  An `R` that is **not** a post-dominator
(e.g. an early-exit path skips it) breaks the discipline: lanes run past `R`
without popping.  The hardware has no way to know; such programs end in
`FLT_FETCH` / `FLT_PC_RANGE` or run until the host's watchdog.  That is why the
tool chain checks the contract:

* `tools/sfx_cfg.py: patch_auto_rpc()` – the "compiler back-end" pass: builds the
  instruction-level CFG, computes post-dominator sets with a virtual exit, and fills
  every `auto` branch with `ipdom(b)`; it rejects branches whose ipdom is the
  virtual exit (two EXITs) or lies before the branch.
* `tools/sfx_cfg.py: lint_program()` – verifies explicit RPCs against C1/C2.
* The random-program generator emits only `auto` branches, so every generated
  program obeys the contract *including early exits and loop breaks*, for which
  the ipdom is the exit block (this is why `early_exit_merge` has depth 1).

## 9. Correctness argument and how it is verified

*Claim.*  For a legal (contract-obeying, race-free, terminating) program the
final registers and memory produced by the stack machine equal those of
running every thread independently (`OracleSim`), and the issue trace of each
warp is the sequence of `(pc, mask)` pairs the stack machine defines.

*Sketch.*  By induction on stack depth: a context `(pc, mask, rpc)` executes
the lanes of `mask` through the region `[pc, rpc)`; every lane in `mask`
reaches `rpc` (post-dominance) and the contexts suspended above/below it hold
disjoint lane sets whose union is the parent's mask; popping at `rpc`
restores exactly the suspended lanes.  Lane execution inside a context is
independent of other lanes (no cross-lane data flow except through memory,
which race-free programs order with barriers).

*Evidence* (all executed, see `docs/verification.md` for numbers):
`OracleSim == SimtSim` on 3000 random programs (with the three mutated-model
sanity checks proving the fuzzer detects wrong stack models);
`SimtSim == RTL` on directed tests and 2000 random programs under four timing
profiles; `resolve_branch == RTL unit` on 160 000 vectors.  This is
simulation evidence, not a formal proof.
