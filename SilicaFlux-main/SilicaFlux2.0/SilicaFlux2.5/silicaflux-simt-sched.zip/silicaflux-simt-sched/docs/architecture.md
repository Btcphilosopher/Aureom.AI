# SilicaFlux warp scheduler and SIMT control unit - architecture

`rtl/sfx_simt_ctrl.sv` keeps `NUM_WARPS` resident warp contexts, grouped into
at most `NUM_WGS` workgroups, fetches and issues **one instruction per cycle**,
tracks register dependencies, divergence/reconvergence, workgroup barriers and
kernel completion, and hands ALU / memory / branch instructions to a downstream
backend.  Operand fetch, the lane ALUs, load/store and the register file are
*not* part of this unit; `tb/sfx_be_model.sv` is a behavioural implementation of
the backend contract used for verification.

```
                    host launch / kernel status / fault record / counters
                                      |
   +----------------------------------v-----------------------------------+
   | sfx_simt_ctrl                                                         |
   |  launch & allocation --> warp table (state, pc, mask, rpc, sp, ibuf)  |
   |                              |        |          |                    |
   |  fetch arbiter (RR) <--------+        |          +--> sfx_diverge_unit|
   |     |        ^                        |               (stack push/pop) |
   |  imem req   imem rsp                  v                                |
   |                       per-warp decode + sfx_scoreboard (hazards)       |
   |                              |                                          |
   |                       candidates (class ready, credits, BAR/EXIT gates)|
   |                              v                                          |
   |                       sfx_warp_sched (class-RR | age)                   |
   |                              |                                          |
   |      sfx_barrier_unit <------+------> be_* issue / cmp_* completion     |
   |      sfx_perf_counters       |                                          |
   +------------------------------+----------------------------------------+
                                  v
                    backend: operand read, lane ALUs, LSU, register file
```

## 1. Parameters

| parameter | default | meaning |
|---|---|---|
| `NUM_WARPS` | 8 | resident warp slots (power of two, >= 2) |
| `NUM_WGS` | 4 | resident workgroup slots (<= `NUM_WARPS`) |
| `WARP_SIZE` | 32 | lanes per warp (power of two) |
| `PC_W` | 16 | PC width in instruction words |
| `STACK_DEPTH` | 8 | reconvergence stack entries per warp (`divergence_model.md`) |
| `MAX_INFLIGHT` | 15 | issued-not-completed backend instructions per warp |
| `SCHED_POLICY` | 0 | 0 = round-robin, 1 = age-based, 2 = readiness / downstream-capacity aware (`SCHEDULER_POLICIES.md`) |
| `STARVE_LIMIT` | 16 | age policy guard, `0` or `>= NUM_WARPS` |
| `STRICT_BAR_PC` | 0 | one BAR instruction per barrier episode |
| `WG_ID_W` | 8 | width of the logical workgroup id |
| `CNT_W` | 32 | performance counter width (saturating) |
| `LIVENESS_LIMIT` | 8192 | simulation-only progress watchdog (cycles) |

Per-warp state: `state(3) pc(PC_W) mask(WARP_SIZE) launch_mask(WARP_SIZE)
rpc(PC_W) sp(log2(D+1)) ibuf(32) wg(log2 G) warp_idx(log2 W) inflight mem_outstanding`
+ the stack `STACK_DEPTH x (2*PC_W + WARP_SIZE)` + 32-bit scoreboard pair.
Per workgroup: `valid abort id members[W] live[W] arrived[W]`.

## 2. Warp slot state machine

```
          alloc            fetch grant           response ok
  FREE ----------> FETCH ---------------> FETCHING ------------> READY
   ^                 ^  ^                    |   response error/illegal    |  issue
   |  slot freed     |  | resolved / barrier |        -> DRAIN             +--> (ALU,MEM,NOP,JMP)  -> FETCH
   |  (in-flight==0  |  | released           |                             +--> BRA/BRZ            -> WAIT_BR
   |   && no fetch)  |  +--------------------+-- WAIT_BR <- resolved ------+--> BAR                -> BARRIER / FETCH
  DRAIN <------------+----- BARRIER ---------------------- release -------+--> EXIT               -> FREE
   ^                                                                       +--> issue-time fault  -> DRAIN
   +---- any non-FREE state when its workgroup aborts (one cycle later)
```

| state | meaning | leaves when |
|---|---|---|
| `FREE`     | slot unallocated; no in-flight work, no pending registers (assertion A1b) | workgroup launch |
| `FETCH`    | pc valid, ibuf empty | fetch arbiter grants it and `imem_req_ready` |
| `FETCHING` | one fetch outstanding (`fetch_pend`) | response (tag = slot) |
| `READY`    | instruction buffered; **may issue** subject to the conditions in section 3 | issue |
| `WAIT_BR`  | branch issued, waiting for the per-lane outcome | `cmp_br` completion |
| `BARRIER`  | arrived at the workgroup barrier | barrier release |
| `DRAIN`    | faulted or aborted; draining | no in-flight instruction and no outstanding fetch |

`READY` is further qualified *combinationally* by the reason it cannot issue
(dependency / memory drain / backend not ready / lost arbitration); these
reasons feed the stall counters (section 9).

## 3. Fetch and issue

**Fetch.** Warps in `FETCH` request round-robin (`sfx_rr_arb`, pointer moves on
an accepted request); the request carries the warp slot as a tag; at most one
fetch per warp is outstanding, so a warp's pc is stable while it waits and no
flush is ever needed.  The response is decoded for faults (`imem_rsp_err` ->
`FLT_FETCH`, undefined opcode -> `FLT_ILLEGAL`) and stored raw in the warp's
instruction buffer.  A response for a tag with no outstanding fetch is ignored
and counted as a protocol error (`cnt_proto_err`).

**Issue condition** (a warp is a *candidate* in a cycle iff all hold):

1. state `READY` and its workgroup is not aborting;
2. no scoreboard hazard: RAW on `rs1`/`rs2` or WAW on `rd` (`r0` ignored);
3. for ALU / MEM / BR: `be_rdy[class]` and `inflight < MAX_INFLIGHT`;
4. `BAR`: no outstanding memory operations of the warp (data visible before the
   barrier); `EXIT`: no in-flight instruction at all (the slot can be freed
   with nothing left to retire).

The scheduler grants at most one candidate per cycle.  The grant *is* the issue;
`be_valid` is asserted in the same cycle for backend-bound instructions (the
backend has promised, through `be_rdy`, to accept it).  On issue: scoreboard
bit set (load results are tagged "memory"), in-flight counters incremented, ibuf
emptied, and the next pc is computed (`advance`, `divergence_model.md`).  A warp
is therefore never `READY` in the cycle after it issued (assertion A8).

Instruction classes: **ALU** and **MEM** go to the backend and complete once
(`cmp_*`); **BR** goes to the backend, the warp waits in `WAIT_BR` for the taken
mask; **CTRL** (`NOP`, `JMP`, `BAR`, `EXIT`) execute inside the unit and retire
at issue.

Measured throughput (`profile 0`, 1-cycle instruction memory, independent
instructions): one warp issues every 3 cycles (`FETCH -> FETCHING -> READY ->
issue`); 3 or more resident warps reach 0.98-0.99 issue/cycle.

## 4. Register dependency tracking

`sfx_scoreboard`: per warp a 32-bit `pending` vector and a 32-bit `from-load`
vector.  Set at issue for the destination, cleared by the matching completion
(`cmp_wr`, `cmp_rd`).  Operands are read by the backend **at issue**, so WAR
hazards cannot exist; RAW and WAW are covered by the issue condition.
Same-cycle set and clear are applied as `(cur & ~clr) | set` and cannot target
one bit.  A completion that clears a bit that is not pending is *refused*
(section 8).

## 5. Scheduling policies

Candidates are the warps of section 3.

* **`SCHED_POLICY=0` - deterministic round-robin** (`sfx_class_rr_arb`).
  Round-robin *inside* each execution class (the pointer of class `c` moves only
  when a class-`c` warp is granted) and round-robin *across* the classes that
  have a candidate.  Fully deterministic: no randomness, no history other than
  the five pointers; with all warps in one class it is plain round-robin.
* **`SCHED_POLICY=1` - age-based** (`sfx_age_arb`, optional).  Oldest-first
  using an exact age matrix (allocation order; a newly allocated warp is
  younger than every resident warp; warps allocated together are ordered by
  slot), plus a starvation guard: a warp that has lost `STARVE_LIMIT` grants
  while it was a candidate becomes *urgent*; the oldest urgent candidate wins,
  otherwise the oldest candidate.

* **`SCHED_POLICY=2` - readiness / capacity aware** (`sfx_aware_arb`).  Ranks the *legal* candidates by a weighted score (class, load, memory-
  dependence, barrier pressure, barrier release, downstream headroom, aging) with two hard guards (a per-warp lost-grant limit and a per-class bypass
  limit) that make the wait bounded.  It never changes which warps are legal.  Full description, configuration and fairness argument:
  `SCHEDULER_POLICIES.md`; measured comparison: `../results/REPORT.md`, `RESULTS_INTERPRETATION.md`.

**Why two levels / candidate-cycle counting.**  Candidacy is gated by backend
readiness, which lapses for a few cycles after every accept.  With a single
round-robin pointer, grants to warps of *other* classes keep moving the pointer
while a ready warp is out of the candidate set, and a sibling of the same class
can win every time the class becomes ready again.  This was found (not
anticipated) while verifying this design: the directed test
`fairness_class_gating_no_starvation` made the earlier single-pointer RR issue
60/60 stores from one warp before the other issued any, and showed the same
effect in the age guard for busy windows longer than `STARVE_LIMIT`.  The fix
is the per-class pointers above, and counting the age guard only in cycles in
which the warp was a candidate.

**Bounded wait** (`lag` = grants to *other* warps made in cycles in which the
warp is a candidate; reset only when the warp is granted or stops being a
requester for reasons of its own - hazard, drain, credit, not `READY`):

| policy | bound | observed max (random + directed runs) |
|---|---|---|
| RR  | `4*NUM_WARPS - 1` (all warps one class: `NUM_WARPS-1`) | 14 of 31 (8 warps), 6 of 15 (4 warps) |
| age | `STARVE_LIMIT + NUM_WARPS` | 20 of 24 (8 warps), 37 of 40 (16 warps, `STARVE_LIMIT=24`) |

Both are asserted every cycle (C1) and proved on the arbiters in isolation
against independent models with feedback-driven candidate sets
(`tb/tb_unit_arb.sv`).  The fetch arbiter is plain round-robin; its requesters
(`FETCH`-state warps) never leave the set until granted.

## 6. Branches, divergence and reconvergence

See `divergence_model.md`.  Summary: a conditional branch issues to the backend
with the warp's execution mask; the backend returns the per-lane outcome in the
completion; `sfx_diverge_unit` (combinational) computes the new context and the
stack pushes in one cycle; the warp then refetches.  There is no branch
prediction and no speculation.

## 7. Workgroups, barriers and kernel completion

**Launch** (`launch_*`): one workgroup per handshake, `launch_nthreads` threads
(1..`NUM_WARPS*WARP_SIZE`).  Warps = `ceil(n / WARP_SIZE)`; the last warp's launch
mask covers the remaining lanes.  A workgroup is accepted **all-or-nothing**:
it needs a free workgroup slot *and* enough free warp slots in the same cycle,
so no workgroup is ever partially resident and the barrier participant set is
complete from cycle 0.  Warp slots are taken lowest-first; warp *k* of the
workgroup gets index *k* (`tid` base).  An invalid size (0 or too large) is
consumed, reported as `FLT_LAUNCH`, and does not allocate anything (so it can
never block `kernel_done`).  `launch_ready` may depend on the payload; the host
holds the payload stable until the handshake.

**Barrier unit** (`sfx_barrier_unit`).  Per workgroup: `live` (warps that have
neither exited nor faulted; initialised to all members at launch) and `arrived`.

* A `BAR` issues only from a converged warp with no outstanding memory
  operations, advances the warp's pc, and sets its `arrived` bit.
* The barrier is **released when `arrived == live` and `arrived != 0`**,
  evaluated on the *next-state* masks, so an arrival and an `EXIT` in the same
  cycle are both counted.  Release clears `arrived` and wakes every arrived warp
  **in the same cycle** (the last arriver never even parks), so a fast warp
  cannot enter the next episode before the others have left this one.
* **Participating warps** are exactly the live warps: a warp that `EXIT`s (or is
  killed) stops participating; this is what completes a barrier when some warps
  leave while others wait (`barrier_released_by_late_exit`).  Partial warps
  count as one participant.  Exited warps are *not* an error.
* Invalid usage - `BAR` while the warp is diverged - is a fault
  (`FLT_DIV_BARRIER`, `divergence_model.md` section 6), so it cannot cause a
  hang.  Because participants are live warps only, the barrier model is
  deadlock-free: every live warp either arrives or leaves.
* `STRICT_BAR_PC=1` additionally refuses an arrival from a different `BAR`
  instruction than the first of the episode (`FLT_BAR_PC`).

**Kernel completion.**  The host marks the last workgroup with `launch_last`.
`kernel_done` asserts (and stays asserted) when the last workgroup has been
launched **and** every workgroup slot is free (all warp slots `FREE`, which
requires in-flight == 0 and no outstanding fetch); at most 2 cycles after the
last slot frees (assertion C3).  While `kernel_done`, further launches are
refused; `kernel_clear` (only honoured when idle) clears done/fault/counters.

## 8. Faults, abort, and protection of inactive contexts

Fault codes and the abort sequence are in `divergence_model.md` section 7.
Protections implemented in the unit:

* **Duplicate issue**: after an issue the warp leaves `READY`; one grant per
  cycle (assertions A7/A8).
* **Retirement from inactive contexts**: a completion is accepted only if its
  warp slot is allocated, has an instruction in flight, and its flags are
  consistent (`cmp_wr` -> that scoreboard bit is pending, `cmp_mem` -> a memory
  operation is outstanding, `cmp_br` -> the warp awaits a branch).  Otherwise
  it is **dropped without touching any state** and counted
  (`cnt_proto_err`).  A slot is freed only when its in-flight count is zero and
  no fetch is outstanding, so a stale completion can never alias into a new
  warp incarnation.  Spurious fetch responses are refused the same way.
  The hostile-downstream directed tests inject both.
* **Bounded resources**: warp slots (each owned by exactly one workgroup),
  workgroup slots, per-warp in-flight credits, stack entries (checked before
  any push), one outstanding fetch per warp - all checked by group B assertions.

## 9. Interfaces

All signals are synchronous to `clk`; reset is `rst_n`, active low.

**Host**

| signal | dir | meaning |
|---|---|---|
| `launch_valid/ready`, `launch_wg_id`, `launch_nthreads`, `launch_pc`, `launch_last` | in/out | workgroup launch |
| `kernel_clear` | in | acknowledge: clear done, fault record, counters (honoured only when idle) |
| `kernel_busy`, `kernel_done` | out | first launch .. completion |
| `fault_valid`, `fault_code`, `fault_wg_id`, `fault_widx`, `fault_pc`, `fault_mask` | out | first fault (sticky) + bit per code seen |

**Instruction memory**: `imem_req_valid/ready/pc/tag` (valid never depends on
ready), `imem_rsp_valid/tag/data/err` (responses may return in any order across
tags; no back-pressure on responses).

**Backend issue**: `be_valid`, `be_cls`, `be_warp`, `be_wg_id`, `be_widx` (warp
index in the workgroup, for `tid`), `be_pc`, `be_instr`, `be_mask`, and
`be_rdy[2:0]` (per-class credit: ALU, MEM, BR).  `be_valid` already contains
`be_rdy[cls]`; the backend must accept in the same cycle.  **New (policy 2 only, advisory):** `be_cap[2:0][1:0]` = free entries of each class saturated at
3, used only to rank legal candidates (legality is `be_rdy` alone; tie to a constant if the backend has no such information), and `sched_cfg`
(`sfx_sched_cfg_t`: 11 three-bit weights + two limits, static while `kernel_busy`).

**Backend completion** (one per cycle, always accepted): `cmp_valid`, `cmp_warp`,
`cmp_wr` + `cmp_rd` (clears scoreboard bit), `cmp_mem`, `cmp_br` + `cmp_taken`.

**Trace**: `iss_valid/warp/wg_id/widx/pc/mask/instr` (every instruction that
executes, in issue order, including those handled inside the unit),
`exit_valid/warp/wg_id/widx` (a warp retired - its registers are final).
`dbg_wstate[w]` exposes the warp states.

**Counters** (all `CNT_W` bits, saturating, cleared by `kernel_clear`, counted
while `kernel_busy`):

| counter | meaning |
|---|---|
| `cnt_cycles` | active cycles |
| `cnt_issued` | issued instructions (a faulting issue does not count) |
| `cnt_retired` | completions accepted + instructions retired at issue (`== issued` at kernel completion) |
| `cnt_idle` | cycles with no issue (`cycles == issued + idle`) |
| `cnt_idle_{nowarp,be,mem,dep,br,fetch,bar,other}` | the idle cycles, each attributed to the **first** matching cause in that order; they sum to `idle`. `nowarp`: nothing resident; `be`: a warp was issuable but its backend class / credit refused it; `mem`: some warp waits on a load result or outstanding stores (BAR/EXIT drain); `dep`: some warp waits on a non-memory register; `br`: waits for a branch outcome; `fetch`: waits for an instruction; `bar`: all resident warps are parked at barriers; `other`: only draining warps |
| `cnt_wc_{issue,notsel,dep,mem,bar,br,fetch,be,drain}` | **warp-cycles**: every resident warp is in exactly one of these buckets every cycle (they sum to `cnt_wc_resident`); `notsel` = issuable but lost arbitration |
| `cnt_div_branches` | branches that really split the warp |
| `cnt_bar_episodes` | barrier releases |
| `cnt_stack_hwm` | stack high-water mark over all warps |
| `cnt_faults`, `cnt_proto_err` | fault events / refused downstream transactions |
| `cnt_warp_issued[w]` | issues per warp slot |

The requested counters map as: issued instructions = `cnt_issued`; idle cycles =
`cnt_idle`; dependency stalls = `cnt_idle_dep` / `cnt_wc_dep`; memory stalls =
`cnt_idle_mem` / `cnt_wc_mem`; barrier waits = `cnt_idle_bar` / `cnt_wc_bar`.

## 10. Backend contract and downstream fairness assumptions

**Backend contract** (BC1-BC7, implemented by `tb/sfx_be_model.sv`, checked by it and by
`tb/sfx_assume_monitor.sv`):

| id | requirement |
|---|---|
| BC1 | source operands are read at the issue edge; results are committed at completion time |
| BC2 | every accepted instruction yields exactly one completion (`cmp_wr` iff a scoreboard bit was set) |
| BC3 | memory operations of one warp are performed in program order |
| BC4 | at most one completion per cycle |
| BC5 | `be_rdy[c]` never drops without an accepted class-`c` instruction in between |
| BC6 | the registers of a newly allocated warp slot read as zero |
| BC7 | a branch outcome (`cmp_taken`) names only lanes of the issued mask; the control unit does **not** rely on this (it intersects the outcome with the active mask) and the hostile test mode violates it on purpose |

**Downstream fairness assumptions** (D1-D5) under which the liveness claim holds
(`sfx_assume_monitor` fails the run, blaming the downstream, if one is violated):

| id | assumption |
|---|---|
| D1 | `imem_req_ready` and `be_rdy[c]` are *non-retracting* (they fall only after an accept) **and** rise again within `T_rdy` cycles after an accept |
| D2 | every accepted fetch request is answered exactly once within `T_imem` cycles |
| D3 | every accepted backend instruction completes exactly once within `T_cmp` cycles; completions are always accepted by the control unit |
| D4 | the host keeps the launch payload stable until accepted and eventually acknowledges a finished kernel |
| D5 | the program is legal (`divergence_model.md` section 8) and every thread terminates |

**Eventual progress** (argument, not a formal proof; each step is also a
run-time assertion or a unit-tested bound):

1. *Fetch.* A warp in `FETCH` stays a requester until granted, the fetch pointer
   moves only on accepted requests, so it is granted within `NUM_WARPS-1`
   accepted requests; D1 supplies the acceptances; D2 the response.
2. *Hazards clear.* Scoreboard bits, outstanding-memory counts and in-flight
   counts only fall through completions (D3).
3. *Backend credit.* By D1 a class that is ready stays ready until some warp of
   that class is accepted; between two accepts of its class a lapse lasts at most
   `T_rdy`.
4. *Arbitration.* Once a warp is a requester it is granted after at most
   `4N-1` (RR) / `STARVE_LIMIT+N` (age) grants made while it is a candidate
   (C1); lapses are bounded by 3 and so are finite.
5. *Per instruction* a warp therefore advances in bounded time; with D5 each warp
   reaches `EXIT`.
6. *Barrier.* The only inter-warp dependency.  Participants are the live warps; a
   live warp either arrives (step 5) or exits, so `arrived == live` is reached;
   release takes one cycle (C2: a full barrier never persists across a clock).
7. *Completion.* After the last slot frees, `kernel_done` rises within 2
   cycles (C3); an aborted workgroup drains because its in-flight work completes
   (D3) and its fetch is answered (D2).

Run-time check of the conclusion: C4 fails if a resident warp exists and no
progress event (issue, completion, fetch response, release, launch, drain) happens
for `LIVENESS_LIMIT` cycles.

## 11. Assertions (`rtl/sfx_simt_checks.svh`, compile with `-DSFX_CHECKS`)

| id | property |
|---|---|
| A1 | resident warp owned by exactly one valid workgroup that lists it |
| A1b | `FREE` slot has no in-flight work, no pending registers, no outstanding fetch |
| A2 | `FETCHING <-> fetch_pend` (or draining) |
| A3 | `BARRIER <-> in the arrived mask` |
| A4 | `arrived ⊆ live ⊆ members` |
| A5 | `WAIT_BR` implies an in-flight branch |
| A6 | mask / stack invariants I1..I6 of the divergence model |
| A7 | issue legality: READY, not aborting, hazard-free, class ready, credit, BAR/EXIT gates, mask within launch mask, one grant |
| A8 | no duplicate issue |
| A9 | no retirement from an inactive context (a refused completion is a failure unless `+sfx_allow_proto_err`) |
| A10 | allocation only onto clean slots |
| A11 | every resident warp is in exactly one stall bucket |
| B1-B7 | single ownership, slot/membership counts, counter ranges, one fetch per warp, stack never written past its depth, all-or-nothing launch |
| C1 | bounded wait (section 5) |
| C2 | barrier never complete-but-unreleased; release only when every live warp is parked or arriving; never for an aborting workgroup |
| C3 | `kernel_done` iff last launched and idle; within 2 cycles |
| C4 | global progress watchdog |
| C1 (policy 2) | the bound becomes `fair_limit + NUM_WARPS` (from `sched_cfg`; `fair_limit = 0` disables the guard and the check) |
| D1 | the grant is a subset of the legal candidates and a candidate implies a grant (all policies) |
| D2 | policy 2: if a warp-urgent candidate exists the grant goes to a warp-urgent candidate |
| D3 | policy 2: a class with a candidate is bypassed by at most `cls_limit + NUM_WARPS + 2` consecutive grants |

Independent testbench monitor (`tb/sfx_sched_monitor.sv`, not part of the RTL): M1 operand availability (shadow scoreboard), M2 backend readiness,
M3 BAR/EXIT memory drain, M4 barrier-episode ordering, M5 non-empty mask, M6 barrier features, M7 memory/register stall classification, M8 class and load
flag, M9 headroom mapping.

## 12. Design decisions and limits

* One instruction issued, one fetched, one completion accepted per cycle; no
  dual issue, no instruction prefetch beyond the single buffered instruction.
* No lane-granular `EXIT`; no spill of the reconvergence stack; `STACK_DEPTH`
  entries are flip-flops (4096 for the default configuration).
* A divergent `BAR` / `EXIT` is a fault by definition rather than undefined
  behaviour.
* The backend, instruction cache and the dispatcher are out of scope; their
  contracts are stated above and enforced by models in the testbench.
* Not synthesised through a physical flow; a Yosys elaboration/synthesis
  smoke check is reported in `docs/verification.md`.
