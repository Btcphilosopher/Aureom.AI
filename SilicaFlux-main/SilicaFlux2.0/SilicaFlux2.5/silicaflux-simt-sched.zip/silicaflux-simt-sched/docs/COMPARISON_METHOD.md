# How the policies are compared

The aim is a comparison in which **the only thing that differs between runs is the scheduling policy**, and in which a claim of improvement can be
refuted by the numbers. Results: `results/REPORT.md` (generated). Reproduce: `make compare` (see section 8).

## 1. The problem with the stock backend model

`tb/sfx_be_model.sv` and `tb/sfx_imem_model.sv` draw every latency and pick every completion with one global xorshift generator. The k-th latency drawn is
whatever the generator state is at that moment, i.e. it depends on how many random numbers the *schedule* consumed before. Two policies would therefore
see different "same" workloads and any difference in cycles would mix policy effect with latency luck. That mode is kept (it is what the original regression
uses) but **is not used for the comparison**.

## 2. Trace mode (`+trace=<file>`)

`tools/wl_gen.py` writes, per workload instance, a table `trace.hex`. Word index `(wg*16 + widx)*K + k`:

```
[31:26] opcode      [23:16] busy gap of the instruction's class after the accept      [15:0] latency (cycles from accept to completion)
```

* `k` = number of backend instructions the warp `(wg, widx)` has issued so far. The instruction stream of a warp is a function of the program and the data
  (programs are race free, the reference model fixes the stream), **not of the schedule**, so `k` names the same dynamic instruction under every policy.
* Latency of an entry is a stateless hash `f(seed, wg, widx, k)` (splitmix64), never a sequential random number.
* The backend checks that the table opcode equals the opcode issued (`$fatal` otherwise) and counts the entries, latency sum and gap sum it consumed; the
  comparison script requires these three totals to be **identical across policies** for every (workload, geometry).
* Completions are presented oldest-ready-first (ties: issue order); no random completion stalls. Instruction fetch: fixed latency 2, no busy gaps.
* **Capacity model**: `be_rdy[ALU/MEM/BR]` is low for `gap` cycles after an accept of that class (the multiplier occupies the ALU port for one extra
  cycle); `be_rdy[MEM]` is also low while `tr_mshr` global loads/stores are outstanding (shared-memory operations do not use MSHRs). `be_cap[MEM]` reports
  the free MSHRs (0..3). Ready bits obey the non-retracting rule D1 (checked by `sfx_assume_monitor`).
* Per-warp memory operations complete in program order (BC3) in both modes.

Latency profiles (cycles):

| profile | load hit prob. | hit | miss | store | shared | ALU | MUL (+gap) | branch | MSHRs | used by |
|---|---|---|---|---|---|---|---|---|---|---|
| `default` | 0.60 | 20-28 | 150-300 | 30-50 | 8-10 | 4 | 8 (+1) | 6 | 4 | depalu, compute, mixed, barrier, diverge |
| `dram`    | 0.15 | 20-28 | 180-320 | 30-50 | 8-10 | 4 | 8 (+1) | 6 | 4 | ldchain, skew |
| `stream`  | 0.30 | 20-28 | 120-200 | 60-120 | 8-10 | 4 | 8 (+1) | 6 | 2 | memstream |

## 3. Workload families (`tools/wl_gen.py`)

All programs are legal and race free (per-thread private output slots, read-only inputs, shared memory in write / barrier / read / barrier phases).
Control flow is warp-uniform except in `diverge`. Each instance is fixed by `(family, seed)`; loop counts, role assignment and barrier imbalance are drawn
from the seed.

| family | warps x workgroups | what it stresses |
|---|---|---|
| `ldchain` | 4 x 4 | pointer chasing: every load address depends on the previous load; long-latency loads feeding dependent arithmetic |
| `depalu` | 4 x 4 | ALU-only fully dependent chains incl. multiplies (operand readiness) |
| `compute` | 8 x 2 | compute-heavy, 4 independent chains, no memory |
| `mixed` | 4 x 4 | per workgroup: 2 compute warps + 1 pointer-chasing memory warp + 1 balanced warp; roles shuffled by seed |
| `skew` | 8 x 2 | 6-7 compute-heavy warps + 1-2 memory-dependent warps in the *youngest* slots (the starvation probe for compute-first policies) |
| `memstream` | 4 x 4 | independent loads + stores, 2 outstanding global operations (downstream capacity bound) |
| `barrier` | 4 x 6 | 6-9 phases x 2 barriers; per-warp work differs by up to 7 x 3 loop iterations and changes every phase; shared-memory exchange between warp pairs |
| `diverge` | 4 x 4 | lane-parity divergence around loads, reconverging every iteration (execution masks, reconvergence stack) |

Seeds 1-6 are **development** seeds (the weight search uses them), seeds 101-116 are **held-out test** seeds (the report uses them). Geometries: `g8` = 8 warp
slots / 4 workgroup slots, `g16` = 16 / 8; 32 lanes; instruction fetch is single-ported in both. `STARVE_LIMIT` (age) and `fair_limit` (policy 2) are
2 x NUM_WARPS in both.

## 4. What is checked on every single run

* bit-exact match with the reference model `SimtSim`: per-warp `(pc, active mask)` stream, all registers, global memory, barrier episodes, divergent branches,
  stack high-water mark; **any mismatch aborts the whole comparison** (a policy is never scored on a workload it executed wrongly);
* identical input fingerprint and identical consumed service demand across policies;
* all in-RTL assertions (groups A-D) and the independent monitor checks M1-M9.

## 5. Metrics

| metric | definition |
|---|---|
| kernel cycles / throughput | `cnt_cycles` (cycles while the kernel is active). Every policy issues the same number of warp instructions, so throughput = issued / cycles moves exactly inversely to cycles |
| idle cycles | cycles with no issue; `idle = cycles - issued`; split into causes by the existing counters (resource busy, memory, dependency, branch, fetch, barrier, none resident) |
| tail completion | p95 over warps of the exit cycle; p95 and max over workgroups of (last-warp exit - launch) |
| fairness | **Jain index** over warps of `issued / cycles-as-candidate` (service share when ready; 1 = identical service); **longest wait** = most consecutive cycles a legal candidate was not selected |
| memory-dependent wake-up | cycles from "legal candidate" to issue, for warps that had been blocked on a load result since their previous issue (mean / max), against all other issues |
| scheduling overhead | issue bubbles caused by the scheduler: 0 for every policy (assertion D1); state and datapath: analytical count, **not synthesised** (`results/hw_cost.md`, `tools/hw_cost.py`) |

## 6. Statistics and the claim rule

Ratios are variant / round-robin. For each metric the report gives the geometric mean over instances with a 95 % **cluster bootstrap** CI (2000
resamples; clusters = seeds, so the two geometries of one seed do not count as independent), and paired wins / ties / losses with a 0.5 % tie band.

* **better**: CI entirely below 1 and mean below 0.995.  **worse**: CI entirely above 1 and mean above 1.005.  **n.s.**: otherwise.
* The default weights were fixed before simulation. A weight search (`tools/sweep_cfg.py`) used development seeds only; its result is evaluated on the
  held-out seeds as a separate variant. No claim in the report uses development seeds.

## 7. Limits of the model (read before drawing conclusions)

* Latencies are independent of the access pattern. There is **no cache, bank, row-buffer or coalescing model**, so locality-aware or bandwidth-aware
  scheduling gains cannot appear here, and policies that harm locality are not penalised.
* One issue slot, one fetch port, one completion port per cycle, a single-entry instruction buffer per warp: after an issue a warp needs about four cycles
  to be ready again. This caps how much any scheduler can matter when warps are plentiful.
* The workloads are synthetic and small (3k-20k warp instructions, at most 16 warps resident); they cover latency-bound, throughput-bound,
  barrier-bound and divergent behaviour but are not a benchmark suite.
* The backend is a behavioural model, not the SilicaFlux datapath; the SIMT unit defines its own small ISA (`isa.md`).
* Hardware cost is an analytical state/operator count, not a synthesis result (section 5); timing closure of the policy-2 grant path is **unmeasured**.
* Fairness bounds are checked by assertions and exact-model unit tests, not formally proved (`SCHEDULER_POLICIES.md` section 3.3).

## 8. Reproduce

```bash
make lint unit directed random      # functional regression incl. policy 2   (about 5 min)
make equiv                          # policies 0/1 cycle-exact vs the pristine original
make workloads                      # tools/wl_gen.py  seeds 1-6,101-116 (about 10 s)
make sweep                          # dev-seed weight search (about 10 min)  -> results/tuned_cfg.json
make compare                        # test seeds, all variants, both geometries -> results/raw_test.json
make report                         # results/REPORT.md
make mutants                        # mutation tests of policy 2 (about 10 min)
```
