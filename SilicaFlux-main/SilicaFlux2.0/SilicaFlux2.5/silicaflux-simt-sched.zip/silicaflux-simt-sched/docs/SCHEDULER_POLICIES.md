# Warp scheduling policies of the SilicaFlux SIMT control unit

Three policies are selectable with the parameter `SCHED_POLICY` of `sfx_simt_ctrl`:

| `SCHED_POLICY` | name | module | what it is |
|---|---|---|---|
| 0 | round-robin (**baseline**) | `sfx_class_rr_arb` | existing default: rotating priority inside every execution class and across classes |
| 1 | age-aware | `sfx_age_arb` | existing: oldest warp first (exact N x N age matrix) with a starvation guard |
| 2 | readiness / capacity aware | `sfx_aware_arb` | **new**: weighted priority from operand-readiness, memory-dependence, barrier and downstream-capacity features, with two hard fairness guards |

Policies 0 and 1 are **unchanged**: `tools/check_baseline_equiv.py` builds the pristine original RTL and testbench (`baseline_orig/`) next to
the modified ones and compares 569 runs cycle-exactly (global issue order, cycle count, every counter, all registers, memory); the checker is itself
checked by a negative control (original RR vs modified age differ in 12/12 cases).

## 1. Legality is separate from priority (so no policy can break the semantics)

A scheduler never decides *whether* a warp may issue. `sfx_simt_ctrl` computes the set of **legal candidates** `w_cand` first, and only then asks the
arbiter *which one*:

```
w_cand[w] = READY state                       (explicit warp state machine, architecture.md section 2)
          & workgroup not aborting
          & no scoreboard hazard              (sfx_scoreboard: RAW on rs1/rs2, WAW on rd; r0 ignored)
          & backend class ready               (be_rdy[class]  - the downstream resource can accept the work)
          & in-flight credit left             (MAX_INFLIGHT per warp)
          & BAR: no outstanding memory op     (data visible before the barrier)   EXIT: nothing in flight
```

* **Explicit warp states** (`WS_FREE, FETCH, FETCHING, READY, WAIT_BR, BARRIER, DRAIN`) and the **scoreboard** (`pend` / `pmem` bit per register per
  warp, set at issue, cleared by the matching completion) are the existing SilicaFlux structures; they were reused, not rebuilt.
  What this work adds on top is the *scheduler-visible classification* of a blocked warp (`w_stall_mem`: waiting for a load result or for outstanding
  memory operations before a BAR/EXIT; `w_stall_dep`: waiting for a register result), derived from the same hazard signals as the stall counters.
* **Execution masks** are untouched: the arbiter only picks a warp; the issued mask is the warp's own active mask (assertion A7: non-empty, inside the
  launch mask). Divergence / reconvergence is `sfx_diverge_unit`, unchanged.
* **Barriers** are untouched (`sfx_barrier_unit`). Policy 2 only *reads* its `arrived` / `live` masks to rank warps.
* **Memory ordering** is untouched: loads/stores of one warp still execute in program order in the backend (contract BC3), BAR waits for the warp's
  outstanding memory operations.
* Assertions `grant subset of w_cand` and `w_cand != 0 implies grant != 0` (group D1) run in every simulation of every policy. The independent monitor
  `tb/sfx_sched_monitor.sv` re-derives RAW/WAW availability, backend readiness, BAR/EXIT drain and barrier-episode ordering from the external ports alone
  (checks M1-M5), so a bug in the RTL scoreboard would not be masked by the RTL.

## 2. Policy 2 in detail

### 2.1 Priority key

Compared as one unsigned 16-bit number, highest wins:

```
key = { tier[1:0] , prim[6:0] , score[6:0] }
tier 3  warp-urgent   lost >= fair_limit grants since it last issued (counted only in cycles in which it was a candidate)   prim = lost count
tier 2  class-urgent  its class was bypassed by >= cls_limit consecutive grants while it had a candidate                    prim = bypass count
tier 1  normal
score = w_cls[class] + w_ld*[load] + w_memdep*[was blocked on memory] + w_dep*[was blocked on a register]
      + w_bar*parked_warps_in_own_workgroup(0..3) + w_rel*[this issue completes a barrier episode]
      + w_cap*headroom(class)(0..3) + w_age*min(lost,3)                        (max 91, 7 bits, no saturation)
ties -> rotating priority (pointer moves to granted+1 on every grant)
```

| field (3-bit weights, `sfx_sched_cfg_t`) | meaning | why |
|---|---|---|
| `w_cls_alu/mem/br/ctrl` | static class preference | start long-latency work early; a warp waiting for a branch outcome cannot proceed |
| `w_ld` | load bonus (on top of the class) | a load starts a result latency, a store does not |
| `w_memdep` | the warp was blocked on a memory result since its last issue and its operand is now ready | **memory-dependent work is woken promptly** instead of queueing behind compute warps |
| `w_dep` | same for register results | |
| `w_bar` | per warp of the own workgroup already parked at the barrier | straggler boost |
| `w_rel` | issuing this BAR / EXIT completes the episode | releases all parked warps in the same cycle |
| `w_cap` | free entries of the instruction's class (`be_cap`, 0..3) | prefer the class whose downstream queue has the most room |
| `w_age` | soft aging below the hard guard | |
| `fair_limit` (6 bit) | warp guard threshold; `0` = off | see section 3 |
| `cls_limit` (4 bit) | class guard threshold; `0` = off | see section 3 |

`sfx_sched_cfg_default(N)` holds the default weights, **chosen from first principles before any simulation**:
`w_cls_alu 0, w_cls_mem 1, w_cls_br 2, w_cls_ctrl 1, w_ld 2, w_memdep 2, w_dep 0, w_bar 1, w_rel 7, w_cap 1, w_age 1, fair_limit max(2N, N+3), cls_limit 6`.
The configuration is a static input (`sched_cfg`, a CSR in a real SoC) so weights can be changed without re-synthesis. `be_cap` is an optional advisory
hint from the backend; legality uses only `be_rdy`. A backend with no headroom information ties `be_cap` to a constant and the capacity term degenerates
to a constant.

### 2.2 Features and who checks them

Every controller-to-arbiter feature is verified against independent code in the testbench, because a wiring error would degrade the policy silently
rather than break functionality:

| feature | independent check |
|---|---|
| legal candidates, `grant` subset of candidates, work conservation | D1 (RTL assertion), M1-M3 (monitor) |
| `bar_press`, `bar_rel` | **M6**: monitor tracks arrivals / exits itself |
| `stall_mem`, `stall_dep` | **M7**: monitor keeps a shadow scoreboard with load-tagged registers |
| class code, load flag | **M8**: monitor's own opcode decode |
| class headroom mapping | **M9**: equals the backend's `be_cap`, CTRL class never limited |
| arbiter selection, guards, counters | `tb/tb_unit_aware.sv`: exact grant model compared every cycle |

`tools/mutate_sched.py` injects 24 single-fault mutants into these paths to show the checks can fail (`results/mutation_policy2.log`: 24/24 killed; the first run killed
22 and exposed two gaps in the tests, which were then closed - see `verification.md`).

## 3. Bounded fairness

### 3.1 Stated assumptions (the original D1-D5 plus two)

| id | assumption |
|---|---|
| D1 | `be_rdy[c]` and `imem_req_ready` are **non-retracting**: they fall only after an accepted request and rise again after a bounded time (checked by `sfx_assume_monitor`) |
| D2 | every fetch is answered exactly once within a bounded time |
| D3 | every accepted backend instruction completes exactly once within a bounded time |
| D4 | the host keeps the launch payload stable and acknowledges a finished kernel |
| D5 | the program is legal (`divergence_model.md` section 8) and terminates |
| P1 | policy 2 configuration is static while a kernel runs |
| P2 | `fair_limit` is `0` (guard off, no guarantee) or `>= NUM_WARPS + 3`; the testbench refuses other values unless `+sc_illegal_ok` |

### 3.2 Bounds

* **Warp guard.** A warp that is a legal candidate loses at most `fair_limit + NUM_WARPS` grants made in cycles in which it is a candidate before it
  issues (assertion **C1**, every simulation; the counter is reset only when the warp issues or stops being a requester for reasons of its own, exactly
  as for the other policies). The derived bound is `fair_limit + NUM_WARPS - 1`.
* **Class guard.** A class that has a candidate is bypassed by at most `cls_limit + NUM_WARPS + 2` consecutive grants to other classes (assertion **D3**).
  This is what prevents *compute-heavy warps from repeatedly winning while memory-dependent work waits*: even with the adversarial weights
  `w_cls_alu = 7`, everything else 0, memory-class warps are still served (unit test: 0 memory grants in 3000 cycles with both guards off, 216-299 with
  them on, for N = 2, 4, 8, 16, 32).
* **Override.** If any warp-urgent candidate exists, the grant goes to a warp-urgent candidate (assertion **D2**, also compared by the exact model).

### 3.3 Why it holds, and where the argument is incomplete

*Argument.* A warp that has lost `fair_limit` grants is urgent and outranks every non-urgent candidate. Among urgent candidates the longest-waiting wins, and
a warp that wins is reset, so with `fair_limit >= N + 3` it cannot become urgent again before the warp it overtook has issued. A warp is therefore overtaken
by at most the other `N - 1` warps once each while urgent.

*Gap.* The argument is clean when the competitors share the waiting warp's class, because backend readiness is non-retracting (D1): a class can only become
unready after one of its own instructions was accepted, so windows in which a warp is a candidate are closed by same-class grants. For competitors of a
*different* class the lost-grant counters of the two warps advance in different sets of cycles; I could not close the argument for every interleaving.
What backs the bound instead of a proof:

* the exact-model unit test runs 5 sizes (N = 2, 4, 8, 16, 32) with randomised hazards, class busy windows of up to 40 cycles, random and adversarial weights, and
  checks every cycle. Worst observed excess of lost grants over `fair_limit`: **0-2**, against the derived bound `N - 1` (7 at N = 8);
* the ablation shows the checks are not vacuous: with the guards off the same scenario starves memory-class warps for the whole 3000 cycles;
* assertions C1/D2/D3 are active in every system simulation of policy 2 - 4,040 archived runs (176 directed, 600 random programs, 3,264 workload runs) plus the
  138 x 96 evaluations of the weight search, which would have aborted - and never fired.

**This is simulation evidence, not a formal proof.** A formal proof (e.g. bounded model checking of the arbiter with a non-retracting-ready environment)
is not part of this deliverable.

## 4. What this scheduler can and cannot do

The arbiter removes *arbitration delay*. In the evaluated model that delay is already about one cycle per instruction under round-robin, while
memory latencies are 100-300 cycles, so there is little makespan to recover; the comparison in `results/REPORT.md` quantifies this and should be read
before any performance expectation is formed. Effects that real GPU schedulers exploit and that this model does **not** contain are listed in
`docs/COMPARISON_METHOD.md` section 7.
