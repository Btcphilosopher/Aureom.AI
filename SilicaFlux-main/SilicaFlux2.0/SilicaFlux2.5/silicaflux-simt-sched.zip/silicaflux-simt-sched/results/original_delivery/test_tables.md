| directed test | configs | timing profiles | what it checks |
|---|---|---|---|
| `nop_exit` | rr32, age32 | 0,1,2,3 | smallest legal kernel |
| `alu_dependency_chain` | rr32, age32 | 1,2 | RAW chain on a single warp shows dependency stalls (visible once ALU latency exceeds fetch latency) |
| `waw_ordering` | rr32, age32 | 0,1,2,3 | back-to-back writes of one register: out-of-order completion must not reorder them |
| `memory_raw_in_order` | rr32, age32 | 1,2,3 | store->load to one address must be ordered; load use stalls on memory |
| `inflight_credit_cap` | rr32, age32 | 1,2,3 | 24 back-to-back stores exceed MAX_INFLIGHT=15: credit stalls, no loss |
| `diverge_if_else` | rr32, age32 | 0,1,2,3 | one divergent branch per warp: join + not-taken entry, reconverges at the join |
| `diverge_if_only` | rr32, age32 | 0,1,2,3 | taken target == reconvergence PC: empty-path elision, a single join entry |
| `uniform_branch_no_push` | rr32, age32 | 0,1,2,3 | branch outcome uniform across the warp: no stack traffic |
| `nested_4_levels_at_limit` | rr32, age32 | 0,1,2,3 | 4 nested divergent levels use exactly 8 = STACK_DEPTH entries |
| `nested_5_levels_overflow` | rr32, age32 | 0,1,2,3 | the 5th nested level needs 10 entries: precise overflow fault, workgroup aborted, kernel completes |
| `nested_4_plus_single_entry_overflow` | rr32, age32 | 0,1,2,3 | full stack (8) + a region that needs exactly ONE more entry: boundary at STACK_DEPTH+1 must fault |
| `nested_depth4_config` | d4 | 0,1,2,3 | STACK_DEPTH=4 build: 2 levels fit |
| `nested_depth4_overflow` | d4 | 0,1,2,3 | STACK_DEPTH=4 build: the 3rd level overflows |
| `loop_divergent_exit_constant_stack` | rr32, age32 | 0,1,2,3 | lanes leave a loop at different iterations: stack depth stays 1 however many iterations run |
| `do_while_divergent_latch` | rr32, age32 | 0,1,2,3 | backward conditional branch whose fall-through is the reconvergence point |
| `early_exit_merge` | rr32, age32 | 0,1,2,3 | 4 early-exit branches to the single exit block share one reconvergence PC: merge keeps depth 1 |
| `loop_break_nested_if` | rr32, age32 | 0,1,2,3 | if inside loop with a break: nested reconvergence points inside one loop region |
| `partial_warp_diverge` | rr32, age32 | 0,1,2,3 | partial last warp: lanes beyond the launch size never become active |
| `barrier_basic` | rr32, age32 | 0,1,2,3 | all warps of a workgroup meet at one barrier; neighbour data visible after it |
| `barrier_partial_warp` | rr32, age32 | 0,1,2,3 | a partial warp (fewer lanes than WARP_SIZE) counts as one participant |
| `barrier_back_to_back` | rr32, age32 | 0,1,2,3 | consecutive barriers: no warp may slip into the next episode early |
| `barrier_repeated_loop` | rr32, age32 | 0,1,2,3 | barriers inside a uniform loop: 2 episodes x 5 iterations |
| `barrier_many_workgroups_recycle` | rr32, age32, rr8 | 0,1,2,3 | more workgroups than slots: warp slots recycled; barriers of different workgroups stay isolated |
| `barrier_exited_warps_do_not_participate` | rr32, age32, rr8, age8 | 0,1,2,3 | warps that EXIT before any barrier are not counted as participants |
| `barrier_released_by_late_exit` | rr32, age32, rr8 | 0,1,2 | warps 0/1 wait at the barrier while warps 2/3 are still busy; their EXIT completes the episode |
| `barrier_after_divergence_reconverges` | rr32, age32 | 0,1,2,3 | a barrier AFTER the divergent region has reconverged is legal |
| `barrier_in_workgroup_uniform_if` | rr32, age32 | 0,1,2,3 | a barrier under a workgroup-uniform branch: only workgroup 1 arrives |
| `divergent_barrier_fault` | rr32, age32 | 0,1,2,3 | BAR executed while the warp is diverged: FLT_DIV_BARRIER, workgroup 0 aborted, workgroup 1 unaffected |
| `divergent_barrier_fault_multiwarp` | rr32, age32 | 0,1,2,3 | same, several warps fault; the whole workgroup is aborted without deadlock |
| `divergent_exit_fault` | rr32, age32 | 0,1,2,3 | EXIT while diverged (program violates the single-exit contract): FLT_DIV_EXIT |
| `illegal_instruction_fault` | rr32, age32 | 0,1,2,3 | undefined opcode |
| `fetch_fault_fall_off_end` | rr32, age32 | 0,1,2,3 | no EXIT: the fetch past the program end errors |
| `jump_out_of_range_fault` | rr32, age32 | 0,1,2,3 | jump target below 0 |
| `launch_zero_threads` | rr32, age32 | 0,1,2,3 | invalid launch (0 threads) is consumed, faulted, and does not hang kernel completion |
| `launch_too_many_threads` | rr32, age32 | 0,1,2,3 | invalid launch (more threads than warp slots) |
| `strict_barrier_pc_mismatch_fault` | strict32 | 0,1,2,3 | STRICT_BAR_PC=1: two different BAR instructions in one episode -> FLT_BAR_PC |
| `lenient_barrier_pc_pairing` | rr32, age32 | 0,1,2,3 | default mode: arrivals at different BAR instructions are one episode (counted by warps, not by pc) |
| `resource_recycle_12_workgroups` | rr32, age32, rr8, age8 | 0,1,2,3 | 12 workgroups through 4 workgroup slots: allocation is all-or-nothing, slots are reused, kernel_done after the last |
| `kernel_done_waits_for_stores` | rr32, age32 | 2,3 | kernel_done only after every store has committed |
| `two_kernels_back_to_back` | rr32, age32 | 0,1,2,3 | kernel_clear returns the unit to idle with cleared status/counters; a second kernel runs identically |
| `fairness_identical_warps` | rr32, age32 | 0,1 | eight identical warps: each issues exactly the same number of instructions |
| `hostile_downstream_spurious_completions_and_fetches` | rr32, age32 | 0,1,2 | backend/imem inject completions and fetch responses for contexts with nothing outstanding: they are refused (proto_err counted) and architectural state is unaffected |
| `hostile_downstream_barriers_loops` | rr32, age32 | 1,2 | same hostile downstream with barrier episodes and memory traffic in flight |
| `fairness_class_gating_no_starvation` | rr32, age32 | 4,5 | MEM class busy for a fixed window after every accept while ALU warps keep the issue slot busy: two MEM warps must share the MEM slots (class-gated candidacy must not let the pointer skip a ready warp) |
| `hostile_downstream_out_of_mask_branch_outcomes` | rr32, age32 | 0,1,2 | branches issued with a PARTIAL mask (nested divergence + partial warp) get outcomes that also name lanes outside the issued mask: the control unit must intersect with the active mask (BC7 is not trusted) |

| mutant | config | injected bug |
|---|---|---|
| `sb_ignore_waw` | rr32 | WAW hazard not detected: two writes of one register may complete out of order |
| `sb_ignore_rs2` | rr32 | RAW hazard on the second source operand not detected |
| `sb_clear_wrong_bit` | rr32 | completion clears the wrong scoreboard bit |
| `branch_predicate_hazard_ignored` | rr32 | a branch issues before its predicate register is written |
| `stall_attr_swap_mem_dep` | rr32 | memory and dependency stalls attributed to each other |
| `div_no_merge` | rr32 | merge optimisation removed: loops with divergent exits grow the stack |
| `div_no_empty_elision` | rr32 | empty-path elision removed: entries with pc == rpc are pushed |
| `div_taken_not_masked` | rr32 | taken mask not intersected with the active mask: inactive lanes wake up |
| `div_nt_mask_wrong` | rr32 | not-taken stack entry stores the taken lanes |
| `div_no_pop_on_uniform_nt` | rr32 | uniform not-taken branch landing on the reconvergence PC does not pop |
| `div_overflow_off_by_one` | rr32 | overflow detected one entry too late (writes beyond the stack) |
| `ctrl_no_pop_after_seq` | rr32 | sequential/JMP flow reaching the reconvergence PC does not pop the stack |
| `bar_premature_release` | rr32 | barrier releases when ONE live warp is still missing |
| `bar_exit_not_removed` | rr32 | exited warps keep counting as participants (barrier never completes) |
| `bar_arrived_not_cleared` | rr32 | arrival mask survives the release: the next episode releases immediately |
| `bar_no_memory_drain` | rr32 | BAR does not wait for outstanding stores: data not visible after the barrier |
| `bar_divergent_not_detected` | rr32 | a divergent BAR is accepted instead of faulting |
| `bar_strict_pc_inverted` | strict32 | strict-PC check inverted |
| `bar_live_mask_partial_warp_lost` | rr32 | the lowest member warp is not a participant (premature release / lost warp) |
| `exit_no_drain` | rr32 | EXIT retires a warp that still has instructions in flight |
| `duplicate_issue` | rr32 | warp stays READY after issuing: the same instruction issues again |
| `retire_inactive_context` | rr32 | completions for a context with nothing in flight are accepted |
| `inflight_never_decrements` | rr32 | in-flight counter leaks: EXIT can never issue |
| `partial_warp_mask_ignored` | rr32 | launch mask of a partial warp is all ones: phantom threads execute |
| `abort_does_not_kill_siblings` | rr32 | a fault does not abort the other warps of the workgroup |
| `drain_ignores_inflight` | rr32 | an aborted slot is freed while completions are still in flight |
| `kernel_done_early` | rr32 | kernel_done asserts as soon as the last workgroup is launched |
| `rr_pointer_sticks` | rr32 | round-robin pointer does not advance past the granted slot (greedy, starves others) |
| `rr_class_pointers_advance_on_any_grant` | rr32 | per-class pointers move on every grant (single-pointer behaviour): a ready warp is skipped while its class is busy |
| `age_counts_class_busy_cycles` | age32 | starvation counter also counts cycles in which the warp's class is busy: an older sibling re-becomes urgent between grants |
| `age_guard_disabled` | age32 | starvation guard disabled: pure oldest-first |
| `age_matrix_inverted` | age32 | a newly allocated slot is recorded as older than existing slots |
