These logs are from the ORIGINAL silicaflux-simt delivery (round-robin and age policies only, before policy 2 existed).
They are kept for reference and are NOT evidence about the modified RTL. The current logs are in the parent directory
(lint.log, unit.log, models.log, directed.log, random.log, equiv.log, mutation_policy2.log, ...), produced by tools/final_regression.sh.
