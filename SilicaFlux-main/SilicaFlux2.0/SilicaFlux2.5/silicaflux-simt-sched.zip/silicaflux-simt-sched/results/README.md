# results/

| file | content | produced by |
|---|---|---|
| `REPORT.md`, `REPORT_tables.csv` | the comparison report (generated; authoritative for all numbers) | `make report` |
| `raw_test.json` | every run on the held-out seeds (5 variants x 256 instances): metrics + fingerprints + consumed demand | `make compare` |
| `raw_dev.json` | development-seed runs (used as the baseline of the weight search) | `make dev` |
| `sweep_dev.json`, `tuned_cfg.json` | weight search trajectory (dev seeds only) and the configuration it found | `make sweep` |
| `raw_ablation.json`, `ablation_variants.json` | post-hoc ablation of the tuned configuration (analysis only) | `tools/compare_policies.py --variants-file results/ablation_variants.json` |
| `hw_cost.md` | analytical state / operator accounting (not synthesis) | `make hw` |
| `lint.log unit.log models.log directed.log random.log equiv.log` | final regression of the modified RTL | `tools/final_regression.sh` (+ `make unit directed` refresh) |
| `mutation_policy2.log` | 24 mutants of the policy-2 path: 24/24 killed | `make mutants-p2` |
| `mutation_original_rerun.log` | the ORIGINAL 32-mutant harness re-run on the modified RTL | `make mutants` |
| `original_delivery/` | logs of the original delivery, before policy 2 - **not** evidence about the modified RTL | - |
