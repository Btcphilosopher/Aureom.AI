## 9. Scheduling overhead

### 9.1 Cycle overhead (measured)

All three arbiters are purely combinational in the issue cycle: the grant is the issue (`be_valid` is asserted in the same cycle). Policy 2 therefore adds **no pipeline stage and no issue bubble**. Assertion D1 (`grant` subset of legal candidates, and a candidate implies a grant) is active in every simulation of every policy, so the scheduler never causes an idle issue slot. Any throughput difference between policies is a consequence of *which* warp is chosen, not of decision latency.

### 9.2 State and datapath (analytical count read from the RTL; **not synthesised, no area/delay/power claimed**)

Why not synthesised: Yosys 0.33, the only synthesis tool that could be installed in this environment, cannot parse the original round-robin and age arbiters (package functions using `return`, `automatic` locals in loops, `int'()` casts, multi-dimensional packed ports), so a like-for-like gate count of the three RTL files could not be obtained. Re-running with a modern SystemVerilog front end (e.g. a yosys-slang flow) is the recommended next step before any area or timing statement is made.

**NUM_WARPS = 8** (STARVE_LIMIT / fair_limit = 16)

| | class round-robin (baseline) | age (oldest-first + guard) | aware (policy 2) |
|---|---|---|---|
| flip-flops | **14** (4 class pointers x 3 + 1 class-level pointer x 2) | **96** (8x7 age matrix (diagonal is constant) + 8 lost-grant counters x 5) | **91** (8 lost-grant counters x 7 + 16 sticky flags + 4 class-bypass counters x 4 + pointer 3) |
| adders / multipliers | 5 pointer increments (<= 3 bit) | 8 counter increments (5 bit) | 8 x (7 score adders + 3 small multipliers 2b x 3b) + 8 lost-grant increments + 8 index adders (3 bit) |
| comparators | none (rotating-priority masks) | 8 x (5-bit >= STARVE_LIMIT) | 8 x 7-bit urgency + 8 x 4-bit class urgency + 7 x 16-bit key compares in the tournament tree |
| selection / muxing | 4 per-class + 1 class-level priority selection over 8 / 4 requesters | 56 AND terms + 8 OR-reductions of 7 inputs (oldest-first), 1 urgent-mask mux | rotation of 8 keys: 8 x 3 levels x (16+1+3) bits = 480 mux2 bits; tournament selects: 7 x (17+3) bits |
| grant-path depth (qualitative) | 2 priority-select levels (class, then warp) + OR of 4 class grants | urgent compare -> mask -> one AND/OR matrix level (about log2(N)+3 gate levels) | score (4-5 chained small adds) -> key -> 3 rotation levels -> 3 compare/select levels |

**NUM_WARPS = 16** (STARVE_LIMIT / fair_limit = 32)

| | class round-robin (baseline) | age (oldest-first + guard) | aware (policy 2) |
|---|---|---|---|
| flip-flops | **18** (4 class pointers x 4 + 1 class-level pointer x 2) | **336** (16x15 age matrix (diagonal is constant) + 16 lost-grant counters x 6) | **164** (16 lost-grant counters x 7 + 32 sticky flags + 4 class-bypass counters x 4 + pointer 4) |
| adders / multipliers | 5 pointer increments (<= 4 bit) | 16 counter increments (6 bit) | 16 x (7 score adders + 3 small multipliers 2b x 3b) + 16 lost-grant increments + 16 index adders (4 bit) |
| comparators | none (rotating-priority masks) | 16 x (6-bit >= STARVE_LIMIT) | 16 x 7-bit urgency + 16 x 4-bit class urgency + 15 x 16-bit key compares in the tournament tree |
| selection / muxing | 4 per-class + 1 class-level priority selection over 16 / 4 requesters | 240 AND terms + 16 OR-reductions of 15 inputs (oldest-first), 1 urgent-mask mux | rotation of 16 keys: 16 x 4 levels x (16+1+4) bits = 1344 mux2 bits; tournament selects: 15 x (17+4) bits |
| grant-path depth (qualitative) | 2 priority-select levels (class, then warp) + OR of 4 class grants | urgent compare -> mask -> one AND/OR matrix level (about log2(N)+3 gate levels) | score (4-5 chained small adds) -> key -> 4 rotation levels -> 4 compare/select levels |

Additional policy-2 cost outside the arbiter: a 43-bit static configuration register (weights and limits), per-warp feature extraction in `sfx_simt_ctrl` (a popcount of the workgroup's parked-warp mask and two mask-equality compares per warp for the barrier features, a 2-bit headroom hint per backend class, and the load flag from the decoder), and an `be_cap` input from the backend (advisory; tie it to a constant to disable the capacity term).

**Reading of the table.** Policy 2 needs more state than round-robin (about 6.5x at 8 warps) but less than the age policy, whose N x N age matrix grows quadratically; its arithmetic is the dominant new cost and it has the deepest combinational grant path of the three. Because the grant also drives the backend issue interface in the same cycle, that depth is a **timing-closure risk that this work has not measured**; the mitigation (computing the score a cycle early from registered features) is not implemented.

