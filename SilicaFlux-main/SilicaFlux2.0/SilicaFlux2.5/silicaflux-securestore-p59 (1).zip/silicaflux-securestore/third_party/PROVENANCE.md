# Third-party sources (vendored UNMODIFIED)

Nothing cryptographic was invented for this project: the only block primitive is the vetted AES core below; all modes
(XTS, CMAC, SP 800-108 KDF) are written in this project's own RTL and validated against independent vectors (docs/07).

| Component | Upstream | Pin | Licence | Used for |
|---|---|---|---|---|
| **secworks/aes** — `aes_core.v`, `aes_encipher_block.v`, `aes_decipher_block.v`, `aes_key_mem.v`, `aes_sbox.v`, `aes_inv_sbox.v`, `aes.v` (wrapper, not instantiated) | https://github.com/secworks/aes (Joachim Strömbergson) | `master` @ `80dc4718e1dcbbdb4b0dd1bdb393d8f7b98981dc` (resolved with `git ls-remote` on 2026-11-12; files fetched from the same branch immediately afterwards; hashes in `secworks-aes/SHA256SUMS`) | BSD-2-Clause (`secworks-aes/LICENSE`) | FIPS 197 AES-128/256 block cipher: 2 instances in the XTS engine (data key, tweak key), 1 in the CMAC engine |
| **SilicaFlux ECCCore (Project 54)** — `rtl/*.sv`, `rtl/*.svh`, `rtl/generated/*.svh`, `ref/{sfecc_bch,sfecc_gf,sfecc_page,sfecc_configs}.py` | this repository, `SilicaFlux-main/silicaflux-ecccore-p54.zip` (sha256 `474d8b40b18fe4bff8ea1512ada0d7d52c7ae998e2e7828f25a7eebc4f4feab6`) | byte-identical to the archive (21 files compared, `SHA256SUMS`) | project-internal | NAND BCH page codec (RTL) and its reference page format / config generator (`scripts/gen_ecc_cfg.py` derives config `SF59` with P54's own code) |

Why secworks/aes: same upstream author and licence family as the `secworks/sha256` core already vendored by SecureSilicon (P28); iterative
4-S-box datapath; encipher / decipher paths separate; 128- and 256-bit keys; "used in several FPGA and ASIC designs" per its README.
**This is not a certification**: the core is reputed, not validated by a CMVP / CAVP laboratory as far as this project could establish, and its
test vectors were *re-run here* only through the XTS / CMAC / KDF vectors listed in docs/07.

Standard vectors (`vectors/src/`, from the PyPI wheel `cryptography_vectors` 50.0.1, themselves NIST CAVP / SP 800-38B files):
`XTSGenAES{128,256}` (tweak as 128-bit string and as data-unit sequence number), `nist-800-38b-aes{128,256}`, `nist-800-108-KBKDF-CTR`.
Independent oracle: OpenSSL via the Python `cryptography` package (50.0.1).  IEEE 1619-2007 Annex B vector 1 and RFC 3720 CRC-32C vectors are asserted in `model/sfsec_ref.py`.

Tool used for simulation: Verilator 5.49 (`pip install verilator`, the wheel's makefile needs `-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include` and `-CFLAGS -fcoroutines`; see `scripts/vl_common.sh`).
