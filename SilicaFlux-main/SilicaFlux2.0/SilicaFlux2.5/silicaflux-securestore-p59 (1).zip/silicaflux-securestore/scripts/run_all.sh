#!/bin/bash
# Build and run every self-checking testbench; usage: scripts/run_all.sh [RTLDIR]  (run from the project root)
# RTLDIR (default rtl) lets the mutation script point at a mutated copy of the RTL.
set -u
. scripts/vl_common.sh
R=${1:-rtl}
OUT=${2:-build}
UNIT_FILES="$R/sfsec_pkg.sv $R/sfsec_crc.sv $AES_FILES $R/sfsec_xts_engine.sv $R/sfsec_cmac.sv $R/sfsec_kdf.sv"
mkdir -p $OUT
fail=0
run() {   # name top files...
  local name=$1 top=$2; shift 2
  rm -rf $OUT/$name
  if ! $VL $VLFLAGS -O1 --top-module $top -Mdir $OUT/$name "$@" > $OUT/$name.build.log 2>&1; then echo "BUILD FAIL $name"; grep -E '%Error' $OUT/$name.build.log | head -5; fail=1; return; fi
  ./$OUT/$name/V$top +VECDIR=vectors > $OUT/$name.run.log 2>&1
  local res; res=$(grep -E 'TB_RESULT' $OUT/$name.run.log | tail -1)
  echo "$name: ${res:-NO RESULT}"
  echo "$res" | grep -q 'PASS' || fail=1
  if [ "${STOP_ON_FAIL:-0}" = 1 ] && [ $fail = 1 ]; then exit 1; fi
}
# the core file list uses rtl/ paths: rewrite for the mutated tree
sed -E "s#^rtl/#$R/#; s#^\+incdir\+rtl/#+incdir+$R/#" scripts/files_core.f > $OUT/files_core.f
run unit tb_crypto_units $UNIT_FILES tb/tb_crypto_units.sv
run e2e  tb_core_e2e -f $OUT/files_core.f tb/sfsec_nand_model.sv tb/tb_core_e2e.sv
run top  tb_top_regs -f $OUT/files_core.f tb/sfsec_nand_model.sv tb/tb_top_regs.sv
exit $fail
