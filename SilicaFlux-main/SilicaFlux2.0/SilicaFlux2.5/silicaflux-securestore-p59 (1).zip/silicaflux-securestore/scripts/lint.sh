#!/bin/bash
# Verilator -Wall over the SecureStore RTL (third-party and generated register constants reported separately).
. scripts/vl_common.sh
mkdir -p reports build
$VL --lint-only -Wall -Wno-TIMESCALEMOD -Wno-fatal --top-module silicaflux_storage_security -f scripts/files_core.f > build/lint_all.txt 2>&1
{
echo "# Lint (Verilator -Wall)"; echo
echo "Command: \`verilator --lint-only -Wall --top-module silicaflux_storage_security -f scripts/files_core.f\`"; echo
echo "| Category | Count (new RTL: rtl/sfsec_*, rtl/silicaflux_*) | Disposition |"; echo "|---|---|---|"
for c in UNUSEDPARAM UNUSEDSIGNAL WIDTHEXPAND WIDTHTRUNC SYNCASYNCNET PINCONNECTEMPTY BLKSEQ LATCH MULTIDRIVEN; do
  n=$(grep -E "^%Warning-$c" build/lint_all.txt | grep -E ' (rtl/(sfsec_|silicaflux_|generated))' | wc -l)
  case $c in UNUSEDPARAM) d="generated register-offset constants (waived)";; UNUSEDSIGNAL) d="unused P54 outputs / reserved fields (reviewed)";; WIDTH*) d="width style, covered by tests (see list)";; SYNCASYNCNET) d="intentional: rst_n observed for reset counting";; PINCONNECTEMPTY) d="unused status output";; *) d="";; esac
  echo "| $c | $n | $d |"
done
echo; echo "Errors: $(grep -c '^%Error' build/lint_all.txt)"
echo; echo "Third-party (secworks AES, P54) warnings are not counted here."
} > reports/lint.md
cat reports/lint.md
