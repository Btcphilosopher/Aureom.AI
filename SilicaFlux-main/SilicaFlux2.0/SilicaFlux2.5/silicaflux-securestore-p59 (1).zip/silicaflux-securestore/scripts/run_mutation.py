#!/usr/bin/env python3
"""
run_mutation.py -- mutation check of the self-checking testbenches.  Each mutant is ONE planted fault in the
RTL (security-relevant: wrong polynomial, bypassed check, wrong order, skipped zeroisation, relaxed lifecycle ...).
A mutant is KILLED when at least one testbench (unit, e2e, top) reports a failure.  Survivors are listed in
reports/mutation.md and discussed in docs/07.   Usage: python3 scripts/run_mutation.py [-j N]
"""
import os, shutil, subprocess, sys, json
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

M = [
 # (id, file, old, new, what)
 ("M01", "rtl/sfsec_pipeline.sv", ".mode_i(2'd0), .en(c_en)", ".mode_i(2'd1), .en(c_en)", "data guard uses CRC-32 (IEEE) instead of CRC-32C"),
 ("M02", "rtl/sfsec_pkg.sv", "(le[127] ? 128'h87 : 128'h0)", "(le[127] ? 128'h86 : 128'h0)", "XTS alpha-multiplication reduction polynomial wrong"),
 ("M03", "rtl/sfsec_pipeline.sv", "assign x_tweak = {bswap64(lba_q), 64'h0};", "assign x_tweak = {lba_q, 64'h0};", "XTS tweak byte order (LBA not little-endian)"),
 ("M04", "rtl/sfsec_pipeline.sv", "if (g_err || !g_crc_ok) begin err_q <= E_PMD_CRC;", "if (g_err) begin err_q <= E_PMD_CRC;", "PMD CRC verdict ignored"),
 ("M05", "rtl/sfsec_pipeline.sv", "else if (!g_tag_ok) begin err_q <= E_PMD_AUTH;", "else if (1'b0) begin err_q <= E_PMD_AUTH;", "PMD authentication tag verdict ignored"),
 ("M06", "rtl/sfsec_pipeline.sv", "if (rx_lba != lba_q) begin", "if (1'b0) begin", "LBA binding of the physical metadata not checked"),
 ("M07", "rtl/sfsec_pipeline.sv", "|| rx_gen != ks_gen_i)", "|| 1'b0)", "key generation binding not checked"),
 ("M08", "rtl/sfsec_pipeline.sv", "if (c_crc != dim_guard) begin", "if (1'b0) begin", "DIM guard CRC verdict ignored"),
 ("M09", "rtl/sfsec_pipeline.sv", "else if (dim_ref != lba_q) begin", "else if (1'b0) begin", "DIM reference tag not checked"),
 ("M10", "rtl/sfsec_keymgr.sv", "for (int s = 0; s < NS; s++) begin wipe_slot(s); gen_q[s] <= gen_q[s] + 8'd1; end", "for (int s = 0; s < NS; s++) begin gen_q[s] <= gen_q[s] + 8'd1; end", "secure reset does not wipe the key slots"),
 ("M11", "rtl/silicaflux_storage_security.sv", "assign allow_import     = !locked && (sb_lc_i == LC_DEV || sb_lc_i == LC_PROV);", "assign allow_import     = !locked;", "clear-key import allowed in PROD / RECOVERY"),
 ("M12", "rtl/silicaflux_storage_security.sv", "(sb_exec_open_i || (sb_lc_i == LC_DEV && sb_debug_en_i))", "1'b1", "privileged access without authenticated firmware"),
 ("M13", "rtl/sfsec_xts_engine.sv", "if (eq_now) begin                 // policy: refuse, and leave no usable key behind", "if (1'b0) begin", "equal XTS key halves accepted"),
 ("M14", "rtl/sfsec_pipeline.sv", "assign col_r = (32'(rd_cnt_q) < PAGE_SPARE) ? 16'(PAGE_DATA + 32'(rd_cnt_q)) : 16'(32'(rd_cnt_q) - PAGE_SPARE);", "assign col_r = 16'(rd_cnt_q);", "randomiser column mapping wrong on the spare-first read stream"),
 ("M15", "rtl/sfsec_pipeline.sv", "assign hw_bad     = hw_beat && (hw_err_i || hw_poison_i);", "assign hw_bad     = hw_beat && hw_err_i;", "poisoned host data accepted"),
 ("M16", "rtl/sfsec_cmac.sv", "cur_blk = pad_blk ^ x_q ^ (is_last ? (lastfull_q ? sk1_q : sk2_q) : 128'h0);", "cur_blk = pad_blk ^ x_q ^ (is_last ? (lastfull_q ? sk2_q : sk1_q) : 128'h0);", "CMAC final-block subkeys swapped"),
 ("M17", "rtl/sfsec_pkg.sv", "localparam logic [31:0] POLY_CRC32C = 32'h82F63B78;", "localparam logic [31:0] POLY_CRC32C = 32'h82F63B79;", "CRC-32C polynomial off by one bit"),
 ("M18", "rtl/silicaflux_storage_security.sv", "E_PMD_AUTH:                           ev[EV_AUTH_FAIL] = 1'b1;", "E_PMD_AUTH:                           ;", "authentication failures not counted (no security alarm)"),
 ("M19", "rtl/sfsec_pipeline.sv", "else if (sst_code_q == SS_UNCORR) begin err_q <= E_ECC_UNCORR; st <= S_ERR; end", "else if (1'b0) begin err_q <= E_ECC_UNCORR; st <= S_ERR; end", "ECC uncorrectable verdict ignored"),
 ("M20", "rtl/sfsec_pipeline.sv", "          for (int i = 0; i < NBLK; i++) rbuf[i] <= '0;\n          acc_q <= '0;", "          acc_q <= '0;", "plaintext buffer not cleared on the error path"),
 ("M21", "rtl/sfsec_keymgr.sv", "if (stg_gen_i < gen_q[cmd_slot_i]) begin err_q <= E_RANGE; st <= M_DONE; end   // never roll a slot back", "if (1'b0) begin err_q <= E_RANGE; st <= M_DONE; end", "key generation rollback permitted on IMPORT"),
 ("M22", "rtl/sfsec_pipeline.sv", "else if (pst_erased_q) begin err_q <= E_ERASED; st <= S_ERR; end", "else if (1'b0) begin err_q <= E_ERASED; st <= S_ERR; end", "erased page not recognised"),
 ("M23", "rtl/sfsec_rec_guard.sv", "cm_msg_o[511 -: 8]  = cls_q;", "cm_msg_o[511 -: 8]  = 8'h00;", "record class not bound into the CMAC input"),
 ("M24", "rtl/sfsec_health.sv", "if (c_crc == base_img_i[32*31 +: 32]) begin", "if (1'b1) begin", "health snapshot restore without CRC check"),
 ("M25", "rtl/sfsec_core.sv", "assign dp_zero = zeroize_i | km_kill_o | km_done_o;", "assign dp_zero = zeroize_i;", "INVALIDATE / key commands do not wipe the datapath key copies"),
 ("M26", "rtl/sfsec_cmac.sv", "zc_q <= 2'd3; key_q <= '0; msg_q <= '0; sk1_q <= '0; sk2_q <= '0;\n                   end", "end", "CMAC key / schedule not wiped after an operation"),
 ("M27", "rtl/sfsec_pipeline.sv", "else if (hw_beat) begin\n            acc_q  <= put_word(acc_q, word_q, hw_data_i);", "else if (hw_beat) begin\n            acc_q  <= put_word(acc_q, word_q, hw_data_i ^ 32'h1);", "host word corrupted on the way into the XTS engine (after the guard CRC)"),
 ("M28", "rtl/sfsec_pipeline.sv", "assign nand_wd_data_o     = ecc_wr_raw_data_i ^ ks_w;", "assign nand_wd_data_o     = ecc_wr_raw_data_i;", "randomiser not applied on the write stream"),
]

def run(m):
    mid, f, old, new, what = m
    d = f"build/mut/{mid}"
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    shutil.copytree("rtl", f"{d}/rtl")
    p = f"{d}/{f}"
    s = open(p).read()
    if s.count(old) != 1:
        return (mid, what, "ERROR", f"pattern occurs {s.count(old)}x")
    open(p, "w").write(s.replace(old, new))
    env = dict(os.environ, STOP_ON_FAIL="1")
    r = subprocess.run(["bash", "scripts/run_all.sh", f"{d}/rtl", f"{d}/out"], env=env, capture_output=True, text=True)
    out = r.stdout
    if "BUILD FAIL" in out:
        return (mid, what, "BUILD-ERROR", out.strip().splitlines()[-1][:80])      # never counted as a kill
    killed_by = [l.split(":")[0] for l in out.splitlines() if "FAIL" in l]
    return (mid, what, "KILLED" if r.returncode != 0 else "SURVIVED", ",".join(killed_by) if killed_by else "")

if __name__ == "__main__":
    jobs = 3
    if "-j" in sys.argv: jobs = int(sys.argv[sys.argv.index("-j") + 1])
    todo = M
    if "--only" in sys.argv:
        ids = sys.argv[sys.argv.index("--only") + 1].split(",")
        todo = [m for m in M if m[0] in ids]
    with ThreadPoolExecutor(jobs) as ex:
        res = list(ex.map(run, todo))
    if "--append" in sys.argv and os.path.exists("reports/mutation.json"):
        old = {r[0]: r for r in json.load(open("reports/mutation.json"))}
        for r in res: old[r[0]] = tuple(r)
        res = [old[k] for k in sorted(old)]
    os.makedirs("reports", exist_ok=True)
    k = sum(1 for r in res if r[2] == "KILLED")
    with open("reports/mutation.md", "w") as f:
        f.write("# Mutation check\n\nOne planted RTL fault per mutant; KILLED = at least one self-checking testbench failed.\n\n")
        f.write(f"**{k} / {len(res)} mutants killed.**\n\n| id | planted fault | result | caught by |\n|---|---|---|---|\n")
        for mid, what, status, by in res:
            f.write(f"| {mid} | {what} | {status} | {by} |\n")
    json.dump(res, open("reports/mutation.json", "w"), indent=1)
    for r in res: print(r)
    print(f"{k}/{len(res)} killed")
