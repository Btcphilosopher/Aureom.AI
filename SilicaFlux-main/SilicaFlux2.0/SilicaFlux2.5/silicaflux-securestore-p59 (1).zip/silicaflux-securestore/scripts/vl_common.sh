# shared Verilator environment (pip "verilator" wheel provides verilator-cli; see README "Tools")
export VERILATOR_ROOT=${VERILATOR_ROOT:-$(python3 -c "import verilator,os;print(os.path.dirname(verilator.__file__))" 2>/dev/null)}
VL=${VL:-verilator-cli}
VLFLAGS="-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include -CFLAGS -fcoroutines -CFLAGS -O1 --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-UNOPTFLAT -Wno-CASEINCOMPLETE -Wno-IMPLICIT -Wno-PINMISSING -Wno-TIMESCALEMOD -Wno-INITIALDLY -Wno-MULTIDRIVEN -Wno-SELRANGE -j 0"
AES_FILES="third_party/secworks-aes/aes_sbox.v third_party/secworks-aes/aes_inv_sbox.v third_party/secworks-aes/aes_key_mem.v third_party/secworks-aes/aes_encipher_block.v third_party/secworks-aes/aes_decipher_block.v third_party/secworks-aes/aes_core.v"
