#!/usr/bin/env python3
"""
gen_regmap.py -- single source of truth for the SecureStore firmware-visible register map (Project 59).
Writes  rtl/generated/sfsec_regs_pkg.sv   (offsets for the RTL)
        sw/sfsec_regs.h                   (C header for firmware / host drivers)
        docs/REGISTER_MAP.md              (documentation)
Access:  RO read-only | RW read/write | WO write-only (reads 0) | W1C write-1-to-clear
Privilege: P = secure-control register: writes (and reads of key-related windows) need an authenticated-firmware
           privileged master (see docs/05); T = telemetry: readable by any master that can reach the page.
Byte-string registers (keys, salts, record bodies, tags) use big-endian word packing: byte 0 in bits [31:24] of
word 0 -- the natural hex-string order of the vectors in vectors/.
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
NEV = 24
EVENTS = ["ECC_CORR", "ECC_UNCORR", "ECC_INTEG", "ECC_SCRUB", "DI_FAIL", "PMD_FAIL", "AUTH_FAIL", "KEY_FAIL",
          "LBA_FAIL", "DMA_ERR", "POISON", "NAND_PROG", "LIFECYCLE", "THERM_WARN", "RESET", "RECOVERY", "BAD_BLOCK",
          "ERASE", "KEY_ERASE", "SEC_RESET", "PROTOCOL", "ERASED_READ", "ENT_FAIL", "REC_FAIL"]
assert len(EVENTS) == NEV

# (name, offset, access, priv, reset, description)
R = []
def r(name, off, acc, priv, rst, desc): R.append((name, off, acc, priv, rst, desc))

r("ID",            0x000, "RO", "T", "0x53465353", '"SFSS"')
r("VERSION",       0x004, "RO", "T", "0x00010000", "RTL version 1.0")
r("CFG",           0x008, "RO", "T", "",  "[7:0] N_SLOTS [15:8] DU_BLOCKS (16-byte blocks of payload) [16] CMAC auth [17] NAND randomiser [18] KDF hierarchy [19] XTS-AES-256 [20] ECC engine (P54) [31:24] N_EVENTS")
r("CAPS",          0x00C, "RO", "T", "",  "[0] XTS-AES-128 [1] XTS-AES-256 [2] CRC-32C data guard [3] CMAC-64 metadata authentication [4] SP 800-108 KDF [5] ECC (P54 BCH) [8] PRK key store: 0 = port only (not implemented here) [9] entropy: 0 = port only (not implemented here) [10] eFuse/OTP: 0 = not provided [11] tamper-resistant key storage: 0 = NOT provided")
r("CTRL",          0x010, "RW", "P", "0x00000023", "[0] DATA_EN [1] AUTH_EN (seal PMD with CMAC) [2] AUTH_REQ (require valid tag on read) [3] SCR_EN (NAND randomiser) [4] IRQ_EN [5] HOST_TELEMETRY (non-privileged masters may read telemetry)")
r("STATUS",        0x014, "RO", "T", "",  "[0] PIPE_BUSY [1] KEY_BUSY [2] DATA_ALLOWED [3] LOCKDOWN [7:4] LC [8] FW_AUTH (authenticated firmware running) [9] PRK_VALID [10] RG_BUSY [11] SEC_ALARM [12] PRIV_ACCESS (this access is privileged)")
r("WD_HOST",       0x018, "RW", "P", "0x00100000", "host data watchdog in cycles (0 = off)")
r("ERR_LAST",      0x01C, "RO", "T", "0", "last data-command response: [7:0] error code [15:8] tag [16] op (1 = read) [31:24] data commands since reset (saturating)")
r("KEY_CMD",       0x020, "WO", "P", "",  "[31:16] magic 0x5EC0 [12] K256 [9:8] SLOT [2:0] OP: 1 IMPORT 2 GENERATE 3 DERIVE 4 INVALIDATE")
r("KEY_STATUS",    0x024, "RO", "P", "0", "[0] BUSY [1] DONE (sticky until next KEY_CMD) [2] ERR [15:8] ERR_CODE")
r("KEY_SEL",       0x028, "RW", "P", "0", "[1:0] slot shown by KEY_INFO / SALT")
r("KEY_INFO",      0x02C, "RO", "P", "",  "selected slot: [0] VALID [1] K256 [2] DERIVED from PRK (else imported) [15:8] GENERATION [31:16] KEY EPOCH")
for i in range(4):
    r(f"SALT{i}",  0x030 + 4*i, "RO", "P", "", f"selected slot: key-derivation salt word {i} (big-endian; persist with GENERATION to DERIVE after a power cycle; NOT secret on its own without the PRK)")
for i in range(8):
    r(f"STG_K1_{i}", 0x040 + 4*i, "WO", "P", "", f"staging: XTS data key K1 word {i} (AES-128: words 0-3, left aligned)")
for i in range(8):
    r(f"STG_K2_{i}", 0x060 + 4*i, "WO", "P", "", f"staging: XTS tweak key K2 word {i}")
for i in range(4):
    r(f"STG_MAC{i}", 0x080 + 4*i, "WO", "P", "", f"staging: CMAC key word {i}")
for i in range(4):
    r(f"STG_SALT{i}", 0x090 + 4*i, "WO", "P", "", f"staging: derivation salt word {i} (DERIVE)")
r("STG_GEN",       0x0A0, "WO", "P", "",  "staging: key generation for IMPORT / DERIVE (must be >= the slot's current generation)")
r("LC_STATUS",     0x0B0, "RO", "T", "",  "[3:0] LC (SecureSilicon CC_SB_LC_*) [4] LOCKDOWN [5] EXEC_OPEN [6] DEBUG_EN [8] ALLOW_IMPORT [9] ALLOW_GENERATE [10] ALLOW_DERIVE [11] ALLOW_INVALIDATE [12] ALLOW_DATA [13] ALLOW_RG")
r("SEC_CMD",       0x0B4, "WO", "P", "",  "write 0x5EC05EED: SECURE RESET (zeroise every key slot, staging, CMAC / XTS key schedules and buffers; abort the data command)")
r("SAN_STATUS",    0x0B8, "RO", "T", "",  "[0] PLAINTEXT_PATH (always 0: no plaintext bypass exists) [1] SCOPE_UNVALIDATED (always 1: crypto-erase scope NOT validated against any sanitisation standard) [15:8] KEY ERASURES [23:16] VALID SLOTS [24] SECURE_RESETS>0")
r("RG_CTRL",       0x0C0, "WO", "P", "",  "[0] START [1] VERIFY [2] AUTH [15:8] CLASS (1 PMD 2 MAP 3 JRN 4 HLT) [21:16] LEN (<=32) [25:24] KEY SLOT (K_mac)")
r("RG_STATUS",     0x0C4, "RO", "P", "0", "[0] BUSY [1] DONE [2] CRC_OK [3] TAG_OK [4] ERR (bad class / length) [5] KEY_INVALID")
r("RG_CTX_HI",     0x0C8, "RW", "P", "0", "record context (binding) bits [63:32]")
r("RG_CTX_LO",     0x0CC, "RW", "P", "0", "record context (binding) bits [31:0]")
r("RG_CRC",        0x0D0, "RW", "P", "0", "CRC-32C: input for VERIFY, output of SEAL")
r("RG_TAG_HI",     0x0D4, "RW", "P", "0", "CMAC-64 tag bytes 0-3: input for VERIFY, output of SEAL")
r("RG_TAG_LO",     0x0D8, "RW", "P", "0", "CMAC-64 tag bytes 4-7")
for i in range(8):
    r(f"RG_BODY{i}", 0x0E0 + 4*i, "RW", "P", "0", f"record body word {i} (bytes 4i..4i+3, big-endian)")
r("TEL_CTRL",      0x100, "WO", "P", "",  "[0] CLEAR session counters [1] CLEAR fault history [2] CLEAR event log [3] ACK sticky alarms")
r("SEC_ALARM_LIMIT", 0x104, "RW", "P", "0x00000004", "authentication failures (EV_AUTH_FAIL) that latch SEC_ALARM (0 = off)")
for i, e in enumerate(EVENTS):
    r(f"EV_CNT_{e}", 0x110 + 4*i, "RO", "T", "0", f"event counter {i}: {e}")
r("ECC_CORR_BITS", 0x170, "RO", "T", "0", "total corrected raw bit errors (sum over decoded pages)")
r("ECC_PAGES_DEC", 0x174, "RO", "T", "0", "pages passed through the ECC decoder (ECC decoder activity)")
r("WR_OK",         0x178, "RO", "T", "0", "data-unit writes completed")
r("RD_OK",         0x17C, "RO", "T", "0", "data-unit reads completed")
r("ECC_MAX_FLIPS", 0x180, "RO", "T", "0", "maximum bit flips seen in one codeword (session)")
r("WR_ERR",        0x184, "RO", "T", "0", "writes ended with an error")
r("RD_ERR",        0x188, "RO", "T", "0", "reads ended with an error")
r("RESET_COUNT",   0x18C, "RO", "T", "0", "controller resets since power-on (POR domain)")
r("FAULT_CUR",     0x190, "RO", "T", "",  "CURRENT fault conditions: [0] thermal warning asserted [1] key slot(s) invalid while data enabled [2] SEC_ALARM [3] LOCKDOWN [4] ECC scrub pending (last page above the flip threshold) [5] persistence snapshot stale")
r("FAULT_HIST",    0x194, "W1C", "P", "0", "HISTORICAL faults since power-on (sticky): bit i = event class i has occurred")
r("FAULT_LIFE",    0x198, "RO", "T", "0", "lifetime fault classes = restored snapshot | this power-on's history")
r("TEMP_CUR",      0x1A0, "RO", "T", "0", "last temperature code from the sensor input (platform-defined units; no conversion is applied)")
r("TEMP_MAX",      0x1A4, "RO", "T", "0", "maximum temperature code this power-on")
r("TEMP_MIN",      0x1A8, "RO", "T", "0xFFFF", "minimum temperature code this power-on")
r("TEMP_STATUS",   0x1AC, "RO", "T", "0", "[0] VALID (a reading has been received) [1] WARN asserted now")
r("WEAR_ERASE_MAX", 0x1B0, "RW", "P", "0", "firmware-published (FTL): highest block erase count")
r("WEAR_ERASE_MIN", 0x1B4, "RW", "P", "0", "firmware-published: lowest block erase count")
r("WEAR_ERASE_TOTAL", 0x1B8, "RW", "P", "0", "firmware-published: total block erases")
r("WEAR_BLOCKS",   0x1BC, "RW", "P", "0", "firmware-published: blocks in the wear population")
r("BAD_BLOCKS_FACTORY", 0x1C0, "RW", "P", "0", "firmware-published: factory-marked bad blocks")
r("BAD_BLOCKS_RUNTIME", 0x1C4, "RW", "P", "0", "firmware-published: blocks retired in service")
r("RESERVED_TOTAL", 0x1C8, "RW", "P", "0", "firmware-published: reserved / spare capacity, blocks")
r("RESERVED_REMAIN", 0x1CC, "RW", "P", "0", "firmware-published: reserved capacity still available, blocks")
r("WEAR_VALID",    0x1D0, "RW", "P", "0", "[0] erase statistics valid [1] bad-block statistics valid [2] reserved-capacity valid (set by firmware). NO remaining-life percentage exists: none is derivable from these counters without a validated NAND wear model")
r("HL_CTRL",       0x1E0, "WO", "P", "",  "[0] CAPTURE lifetime snapshot (counters = restored base + this power-on) [1] RESTORE base from HL_BASE (CRC-32C verified) [2] CLEAR lifetime base (needs [31:16] = 0xC1EA)")
r("HL_STATUS",     0x1E4, "RO", "T", "0", "[0] SNAP_VALID [1] RESTORED [2] RESTORE_REFUSED (CRC mismatch) [15:8] snapshots captured [31:16] snapshot age in captures-since-restore")
for i in range(32):
    r(f"HL_SNAP{i}", 0x200 + 4*i, "RO", "T", "0", ("lifetime counter %d (EV_CNT_%s)" % (i, EVENTS[i]) if i < 24 else
        {24: "lifetime ECC corrected bits", 25: "lifetime ECC pages decoded", 26: "lifetime writes ok", 27: "lifetime reads ok",
         28: "max codeword flips ever", 29: "max temperature code ever", 30: "lifetime fault classes", 31: "CRC-32C of words 0-30 (little-endian bytes)"}[i]))
for i in range(32):
    r(f"HL_BASE{i}", 0x280 + 4*i, "WO", "P", "", f"restore image word {i} (same layout as HL_SNAP; word 31 = CRC-32C)")
r("LOG_STAT",      0x300, "RO", "T", "0", "[7:0] entries [15:8] lost (overflow, saturating)")
r("LOG_POP",       0x304, "WO", "P", "",  "pop the oldest entry")
r("LOG_W0",        0x308, "RO", "T", "0", "head entry: [4:0] event [7:5] severity [15:8] tag [23:16] error code")
r("LOG_W1",        0x30C, "RO", "T", "0", "head entry: timestamp (cycles since power-on, low 32 bits)")
r("LOG_W2",        0x310, "RO", "T", "0", "head entry: info word (ECC flips for reads, otherwise 0)")
r("IRQ_STATUS",    0x314, "W1C", "P", "0", "sticky: [0] INFO [1] WARN [2] ERROR [3] FATAL/SECURITY")
r("IRQ_ENABLE",    0x318, "RW", "P", "0x0000000E", "interrupt enable per severity (INFO off by default)")
r("ECC_WINDOW",    0x800, "RW", "T", "",  "0x800-0x8FF: P54 ECCCore register window (docs of P54: statistics, scrub threshold); writes need privilege")

OFF = {n: o for (n, o, *_x) in R}

def write_sv():
    p = os.path.join(ROOT, "rtl", "generated", "sfsec_regs_pkg.sv")
    with open(p, "w") as f:
        f.write("// GENERATED by scripts/gen_regmap.py -- do not edit.\n`default_nettype none\npackage sfsec_regs_pkg;\n")
        f.write(f"  localparam int NEV_REG = {NEV};\n")
        for n, o, a, pr, rst, d in R:
            f.write(f"  localparam logic [11:0] R_{n} = 12'h{o:03x};   // {a} {pr}\n")
        f.write("endpackage\n`default_nettype wire\n")

def write_h():
    p = os.path.join(ROOT, "sw", "sfsec_regs.h")
    with open(p, "w") as f:
        f.write("/* GENERATED by scripts/gen_regmap.py -- do not edit.  SilicaFlux SecureStore (P59) register offsets. */\n")
        f.write("#ifndef SFSEC_REGS_H\n#define SFSEC_REGS_H\n")
        f.write("#define SFSEC_ID_VALUE 0x53465353u\n#define SFSEC_KEY_MAGIC 0x5EC00000u\n#define SFSEC_SEC_RESET_KEY 0x5EC05EEDu\n")
        f.write("#define SFSEC_HL_CLEAR_KEY 0xC1EA0000u\n")
        f.write("#define SFSEC_OP_IMPORT 1u\n#define SFSEC_OP_GENERATE 2u\n#define SFSEC_OP_DERIVE 3u\n#define SFSEC_OP_INVALIDATE 4u\n")
        for n, o, a, pr, rst, d in R:
            f.write(f"#define SFSEC_{n} 0x{o:03X}u  /* {a} {pr} */\n")
        f.write("#endif\n")

def write_md():
    p = os.path.join(ROOT, "docs", "REGISTER_MAP.md")
    with open(p, "w") as f:
        f.write("# SecureStore register map (generated)\n\n> GENERATED by `scripts/gen_regmap.py` -- edit the script, not this file.\n\n")
        f.write("32-bit registers, word accesses, byte offsets inside the SecureStore register page. Access: RO / RW / WO / W1C.\n")
        f.write("`P` = secure-control register (privileged master + authenticated firmware running + not in lockdown; otherwise the access is\nrefused with a bus error and counted as EV_LIFECYCLE). `T` = telemetry (any master the fabric lets reach the page; privileged\nclears). Byte strings use big-endian word packing (byte 0 in bits [31:24]).\n\n")
        f.write("| Offset | Name | Acc | Priv | Reset | Description |\n|---|---|---|---|---|---|\n")
        for n, o, a, pr, rst, d in R:
            f.write(f"| `0x{o:03X}` | {n} | {a} | {pr} | {rst or '-'} | {d} |\n")
        f.write("\n## Event classes (EV_CNT_*, LOG, FAULT_HIST, HL_SNAP0..23)\n\n| # | Event | Severity | Meaning |\n|---|---|---|---|\n")
        sev = {"ECC_CORR": "INFO", "ECC_UNCORR": "ERROR", "ECC_INTEG": "ERROR", "ECC_SCRUB": "WARN", "DI_FAIL": "ERROR", "PMD_FAIL": "ERROR",
               "AUTH_FAIL": "ERROR (+SEC_ALARM at the limit)", "KEY_FAIL": "ERROR", "LBA_FAIL": "ERROR", "DMA_ERR": "WARN", "POISON": "WARN",
               "NAND_PROG": "ERROR", "LIFECYCLE": "WARN", "THERM_WARN": "WARN", "RESET": "INFO", "RECOVERY": "WARN", "BAD_BLOCK": "WARN",
               "ERASE": "INFO", "KEY_ERASE": "INFO", "SEC_RESET": "WARN", "PROTOCOL": "ERROR", "ERASED_READ": "INFO", "ENT_FAIL": "ERROR", "REC_FAIL": "ERROR"}
        mean = {"ECC_CORR": "codeword corrected by the ECC engine", "ECC_UNCORR": "ECC uncorrectable", "ECC_INTEG": "ECC miscorrection caught by the codeword CRC-16",
                "ECC_SCRUB": "page reached the flip threshold (refresh hint)", "DI_FAIL": "data guard / reference tag / format failure after decryption",
                "PMD_FAIL": "physical metadata CRC / format failure", "AUTH_FAIL": "metadata authentication failure (forgery or wrong key)",
                "KEY_FAIL": "key invalid / mismatch / equal halves", "LBA_FAIL": "misdirected read (PMD LBA differs)", "DMA_ERR": "host DMA fault",
                "POISON": "poisoned write data rejected", "NAND_PROG": "NAND program failure", "LIFECYCLE": "refused privileged or lifecycle-restricted operation",
                "THERM_WARN": "thermal warning asserted (rising edge)", "RESET": "controller reset observed", "RECOVERY": "power-loss recovery performed (PowerSafe)",
                "BAD_BLOCK": "bad block reported by the NAND controller", "ERASE": "block erase reported", "KEY_ERASE": "key slot invalidated / zeroised",
                "SEC_RESET": "secure reset executed", "PROTOCOL": "pipeline protocol violation", "ERASED_READ": "read of a never-written page",
                "ENT_FAIL": "entropy source unavailable", "REC_FAIL": "firmware record-guard verification failure (MAP / JRN / HLT)"}
        for i, e in enumerate(EVENTS):
            f.write(f"| {i} | {e} | {sev[e]} | {mean[e]} |\n")

if __name__ == "__main__":
    write_sv(); write_h(); write_md()
    print("registers:", len(R))
