#!/bin/bash
# usage: scripts/run_unit.sh <tb_top> <rtl files...>   (run from the project root)
set -e
. scripts/vl_common.sh
TOP=$1; shift
mkdir -p build/$TOP
$VL $VLFLAGS -O1 --top-module $TOP -Mdir build/$TOP "$@" 2>&1 | grep -v -E '^(make|c\+\+|ar |rm |ccache|python|g\+\+)' | grep -E '%Error|%Warning-(?!WIDTH)' | head -40 || true
./build/$TOP/V$TOP "${RUN_ARGS[@]}" +VECDIR=vectors
