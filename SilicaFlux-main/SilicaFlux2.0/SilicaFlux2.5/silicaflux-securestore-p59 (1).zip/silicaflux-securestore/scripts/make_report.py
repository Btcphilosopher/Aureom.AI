#!/usr/bin/env python3
"""make_report.py -- assemble reports/regression.md from the logs of the last `make regress` and the mutation report."""
import os, re, json
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
def last(path, pat):
    if not os.path.exists(path): return None
    m = [l for l in open(path).read().splitlines() if re.search(pat, l)]
    return m[-1] if m else None
rows = []
for name, title in (("unit", "tb_crypto_units: XTS (NIST CAVP + OpenSSL), CRC, CMAC (SP 800-38B), KDF (SP 800-108 CAVP)"),
                    ("e2e", "tb_core_e2e: protected data path with the real P54 BCH codec and a NAND model"),
                    ("top", "tb_top_regs: register interface, lifecycle, RAS, health, sanitise, record guard")):
    r = last(f"build/{name}.run.log", "TB_RESULT")
    rows.append((title, r or "not run"))
with open("reports/regression.md", "w") as f:
    f.write("# Regression summary\n\nProduced by `make regress` + `make report`.  Simulator: Verilator 5.49.\n\n| Testbench | Result |\n|---|---|\n")
    for t, r in rows: f.write(f"| {t} | `{r}` |\n")
    f.write("\n## Detail lines from the logs\n\n```\n")
    for name in ("unit", "e2e", "top"):
        p = f"build/{name}.run.log"
        if os.path.exists(p):
            for l in open(p).read().splitlines():
                if l.startswith(("[", "  ")) or "latency" in l: f.write(l + "\n")
    f.write("```\n")
    if os.path.exists("reports/mutation.json"):
        res = json.load(open("reports/mutation.json"))
        k = sum(1 for r in res if r[2] == "KILLED")
        f.write(f"\n## Mutation check\n\n{k} / {len(res)} planted faults killed (details: `reports/mutation.md`).\n")
print(open("reports/regression.md").read())
