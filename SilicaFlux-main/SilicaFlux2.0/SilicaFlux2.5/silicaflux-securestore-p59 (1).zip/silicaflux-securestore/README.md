# SilicaFlux-STORE · Project 59 — SecureStore: cryptography, data integrity and storage RAS

**Primary RTL:** [`rtl/silicaflux_storage_security.sv`](rtl/silicaflux_storage_security.sv) · Aureom.AI | SilicaFlux-STORE

A secure data-processing subsystem for SilicaFlux storage chips: **AES-XTS** encryption (vetted AES core + XTS mode validated against NIST CAVP vectors and
OpenSSL) in front of the **real P54 BCH page codec**, end-to-end **data-integrity metadata**, separately defined **record integrity / authentication**
(CRC-32C + AES-CMAC-64) for physical metadata and FTL mapping / journal records, a **key hierarchy** (SP 800-108 KDF) with explicit lifecycle gating
tied to the existing **SecureSilicon** boot architecture, a controlled **key-erasure** capability, **RAS aggregation** and **health telemetry** behind a
documented firmware-visible register map.

```
 write:  host ─► DIM(CRC-32C guard + LBA tag) ─► AES-XTS ─► ECC (P54 BCH) ─► [NAND randomiser] ─► NAND
 read :  NAND ─► [de-randomiser] ─► ECC decode ─► checks (ECC, PMD CRC/CMAC, LBA, key slot+generation) ─► AES-XTS decrypt ─► DIM checks ─► host
                                                      (plaintext leaves only if EVERY check passed; every failure = one explicit error code)
```

> **Status — read this first.**  Everything here is RTL **simulation** (Verilator 5.49), an independent Python / OpenSSL reference model and a mutation check.
> No FPGA, no silicon, no synthesis numbers, no formal proofs.  **Not a certification and not a validated cryptographic module** (docs/09).
> **AES-XTS gives confidentiality only — no authentication or tamper detection.**  **A CRC is not authentication**; the design says so and tests it.
> **No eFuse / OTP / secure NVM / tamper-resistant key storage exists or is claimed** (keys are flip-flops; PRK and entropy are platform *ports*).
> **No sanitisation-standard compliance is claimed** (metadata, spare / remapped blocks, firmware areas and protocol rules are not validated — docs/08).
> Delivered as a zip; **nothing was committed to GitHub.**

## Definition of done — met in simulation

*The storage pipeline can encrypt, store, retrieve, decrypt and verify test data correctly, and corruption or supported security failures produce explicit errors.*

| Evidence | Result |
|---|---|
| Stored NAND page vs the independent model (XTS + DIM + PMD + P54 BCH, AES-128 and -256), then read back | **24 / 24 vectors bit-exact and round-tripped** |
| AES-XTS: NIST CAVP (AES-128/256, both tweak formats, enc + dec) + OpenSSL randomised | **2,400 + 201 records bit-exact** |
| CMAC (SP 800-38B + OpenSSL), SP 800-108 KDF (NIST CAVP KBKDF), CRC-32C / CRC-32 / CRC-16 | **308 / 140 (80 CAVP) / 768** |
| ECC recovery: 1…8 injected raw flips corrected with the exact count; > 8 flips ⇒ explicit error, **no payload released** | **pass** (24 + 20 trials) |
| 14 crafted pages (valid ECC codeword, one wrong layer each) ⇒ exact error codes | **14 / 14** |
| Wrong key / wrong generation / wrong salt / wrong data-unit number / invalidated key | explicit, distinct codes |
| Reset, flush, DMA faults (error beat, poison, async, watchdog), NAND failures, erased page | explicit codes; faulted writes program nothing |
| Lifecycle / privilege matrix (DEV, PROV, PROD, RECOVERY, lockdown, invalid) | refused + counted outside the allowed set |
| Record guard vs model (48 seals / verifies); forged records pass CRC and fail the tag | **48 / 48; 11 forgeries detected** |
| Total self-checks | unit **29,940** · end-to-end **10,233** · register-level **490** · 0 failures |
| Mutation check (28 planted faults) | **28 / 28 killed** (two initially survived and exposed test gaps that were then closed — docs/07 §5) |

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit | [docs/00_AUDIT.md](docs/00_AUDIT.md) |
| 2 | AES-XTS integration interface, key sizes, DUN, enc/dec, flow control, errors, standard vectors; XTS ≠ authentication | `rtl/sfsec_xts_engine.sv`, [docs/02 §3](docs/02_PIPELINE_AND_FORMATS.md), [docs/07](docs/07_VERIFICATION.md) |
| 3 | Integrity for data units, physical metadata, FTL mapping records, journal records; CRC ≠ authentication; authenticated metadata | `rtl/sfsec_crc.sv`, `sfsec_rec_guard.sv`, `sfsec_cmac.sv`, [docs/03](docs/03_INTEGRITY_AND_AUTHENTICATION.md) |
| 4 | Pipeline ordering, scrambler position, metadata association | `rtl/sfsec_pipeline.sv`, [docs/02](docs/02_PIPELINE_AND_FORMATS.md), [docs/04](docs/04_NAND_RANDOMISER.md) |
| 5 | Provisioning, key selection, hierarchy, invalidation, secure reset, lifecycle; no false storage claims | `rtl/sfsec_keymgr.sv`, `sfsec_kdf.sv`, [docs/05](docs/05_KEY_MANAGEMENT_AND_LIFECYCLE.md) |
| 6 | Secure boot integration; no invented signature logic | `sb_*` inputs, [docs/05 §6](docs/05_KEY_MANAGEMENT_AND_LIFECYCLE.md) |
| 7 | Controlled key erasure; no compliance claim | [docs/08](docs/08_SANITISATION.md) |
| 8 | Reliability telemetry + register map | `rtl/sfsec_ras.sv`, [docs/06](docs/06_RAS_AND_HEALTH.md), [docs/REGISTER_MAP.md](docs/REGISTER_MAP.md), `sw/sfsec_regs.h` |
| 9 | Health service; no invented life %; persistent counters; temperature; wear; reserved capacity | `rtl/sfsec_health.sv`, [docs/06 §3](docs/06_RAS_AND_HEALTH.md) |
| 10 | Verification list | [docs/07](docs/07_VERIFICATION.md), `tb/` |
| 11 | Deliverables | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_storage_security.sv` (primary: lifecycle policy, register file, interlocks, event assembly) | `rtl/silicaflux_storage_security.sv` |
| Verified cryptographic integration | `rtl/sfsec_xts_engine.sv`, `sfsec_cmac.sv`, `sfsec_kdf.sv` around `third_party/secworks-aes` (unmodified); vectors in `vectors/` |
| Integrity metadata logic | `rtl/sfsec_crc.sv`, `rtl/sfsec_rec_guard.sv`, DIM / PMD in `rtl/sfsec_pipeline.sv` |
| Secure-control registers | `rtl/silicaflux_storage_security.sv`, `docs/REGISTER_MAP.md`, `sw/sfsec_regs.h` |
| RAS aggregation / health telemetry | `rtl/sfsec_ras.sv`, `rtl/sfsec_health.sv` |
| Self-checking tests | `tb/tb_crypto_units.sv`, `tb/tb_core_e2e.sv`, `tb/tb_top_regs.sv`, `tb/sfsec_nand_model.sv`, `scripts/run_mutation.py` |
| Reference model / vectors | `model/sfsec_ref.py`, `scripts/gen_vectors.py`, `vectors/` |
| Threat model | [docs/01_THREAT_MODEL.md](docs/01_THREAT_MODEL.md) |
| Known limitations | [docs/09_LIMITATIONS.md](docs/09_LIMITATIONS.md) |

## Quick start

Tools: Verilator ≥ 5.040 (`pip install verilator` works; the wheel needs two flags that `scripts/vl_common.sh` already sets), GCC 13 (coroutines), Python 3.10+ with
`cryptography` (and `cryptography_vectors` only to regenerate `vectors/src`, which is shipped).

```bash
make regress      # builds + runs the three self-checking testbenches (~45 s); exits non-zero on any failure
```
```bash
make mutation     # 28 planted faults, each must be killed (~20 min on 3 cores) -> reports/mutation.md
```
```bash
make gen          # regenerate register map (SV / C / Markdown), ECC page config, vectors (deterministic seed)
```

## Layout

```
rtl/            silicaflux_storage_security.sv (PRIMARY) · sfsec_pipeline · sfsec_xts_engine · sfsec_cmac · sfsec_kdf · sfsec_keymgr
                sfsec_rec_guard · sfsec_crc · sfsec_ras · sfsec_health · sfsec_core · sfsec_pkg · generated/ (register pkg, ECC page config)
third_party/    secworks-aes (unmodified, pinned) · silicaflux-ecccore (P54 RTL + reference, byte-identical to the repository archive) · PROVENANCE.md
tb/             tb_crypto_units · tb_core_e2e · tb_top_regs · sfsec_nand_model
model/          sfsec_ref.py (independent reference: OpenSSL + pure-Python XTS, CRCs, CMAC, KDF, formats, P54 page format)
vectors/        *.memh (generated) + src/ (NIST CAVP files)         scripts/  generators, runners, lint, mutation
docs/           00 audit … 09 limitations, REGISTER_MAP (generated)  reports/  regression, lint, mutation
sw/             sfsec_regs.h (generated C header)
```

## Integration summary (specified, not wired — docs/00, docs/09)

PERIPH page on the ControlCore bus (`rb_priv_i` from the CPU-data-master qualifier), `sb_lc_i` / `sb_exec_open_i` / `sb_lockdown_i` / `sb_debug_en_i` from `silicaflux_secure_boot`,
`ras_warn_o` / `ras_fatal_o` into `cc_ras`, the NAND channel into the P51 / P53 controller (spare-first reads, abort-before-confirm programs), P58's recovery pulse and the FTL's erase /
bad-block pulses and wear statistics into the telemetry inputs, a platform key store and a vetted entropy source behind `prk_*` / `ent_*`.
