// =============================================================================
// SilicaFlux SecureStore :: sfsec_ras -- RAS aggregation: event counters, fault history, event log, severity, IRQ
//
// All state is in the POWER-ON domain (por_rst_n): counters and history keep counting across CONTROLLER resets
// (rst_n) and are lost only at power-off -- durable storage across power cycles is the firmware's job through
// the lifetime snapshot service (sfsec_health), which this block feeds.
//   * one saturating 32-bit counter per event class (sfsec_pkg::EV_*), plus ECC decoder activity statistics
//   * historical fault status (sticky bit per event class) -- the CURRENT status is assembled by the register layer
//   * 16-entry event log (timestamp, event, severity, tag, error code, info); one entry per cycle (simultaneous
//     further events are counted as lost log entries, never as lost counts)
//   * severity -> interrupt status; authentication-failure alarm (SEC_ALARM) at a programmable limit
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfsec_ras
  import sfsec_pkg::*;
(
  input  wire logic              clk,
  input  wire logic              por_rst_n,
  input  wire logic [NEV-1:0]    ev_i,            // one-cycle pulses
  input  wire logic [7:0]        ev_tag_i,
  input  wire logic [7:0]        ev_err_i,
  input  wire logic [31:0]       ev_info_i,
  // ECC decoder activity / data-command statistics (pulses)
  input  wire logic              pst_i,
  input  wire logic [15:0]       pst_flips_i,
  input  wire logic [7:0]        pst_max_i,
  input  wire logic              wr_ok_i,
  input  wire logic              rd_ok_i,
  input  wire logic              wr_err_i,
  input  wire logic              rd_err_i,
  // maintenance
  input  wire logic              clr_session_i,
  input  wire logic              clr_hist_i,
  input  wire logic              clr_log_i,
  input  wire logic              ack_i,
  input  wire logic              log_pop_i,
  input  wire logic [31:0]       auth_limit_i,
  input  wire logic [3:0]        irq_clr_i,
  input  wire logic [3:0]        irq_en_i,
  input  wire logic              irq_global_en_i,
  // outputs
  output logic [32*NEV-1:0]      cnt_o,
  output logic [31:0]            corr_bits_o,
  output logic [31:0]            pages_dec_o,
  output logic [31:0]            wr_ok_o,
  output logic [31:0]            rd_ok_o,
  output logic [31:0]            wr_err_o,
  output logic [31:0]            rd_err_o,
  output logic [7:0]             max_flips_o,
  output logic [NEV-1:0]         hist_o,
  output logic [7:0]             log_count_o,
  output logic [7:0]             log_lost_o,
  output logic [31:0]            log_w0_o,
  output logic [31:0]            log_w1_o,
  output logic [31:0]            log_w2_o,
  output logic [3:0]             irq_status_o,
  output logic                   sec_alarm_o,
  output logic                   irq_o,
  output logic                   ras_warn_o,
  output logic                   ras_err_o,
  output logic                   ras_fatal_o
);
  // severity: 0 INFO 1 WARN 2 ERROR
  function automatic logic [1:0] sev_of(input int i);
    case (i)
      EV_ECC_CORR, EV_RESET, EV_ERASE, EV_KEY_ERASE, EV_ERASED_READ: return 2'd0;
      EV_ECC_SCRUB, EV_DMA_ERR, EV_POISON, EV_LIFECYCLE, EV_THERM_WARN, EV_RECOVERY, EV_BAD_BLOCK, EV_SEC_RESET: return 2'd1;
      default: return 2'd2;
    endcase
  endfunction

  function automatic logic [31:0] sat_add(input logic [31:0] a, input logic [31:0] b);
    logic [32:0] s;
    s = {1'b0, a} + {1'b0, b};
    return s[32] ? 32'hFFFF_FFFF : s[31:0];
  endfunction

  logic [31:0] cnt_q [NEV];
  logic [31:0] ts_q;
  logic [31:0] corr_q, pages_q, wrok_q, rdok_q, wrerr_q, rderr_q;
  logic [7:0]  maxf_q;
  logic [NEV-1:0] hist_q;
  logic [3:0]  irq_q;
  logic        alarm_q;
  logic [31:0] auth_base_q;

  // event log (circular FIFO, depth 16): entry = {info[31:0], timestamp[31:0], w0[31:0]}
  logic [95:0] log_q [16];
  logic [4:0]  log_wr_q, log_rd_q;
  logic [7:0]  lost_q;

  logic        any_ev;
  logic [4:0]  first_ev;
  logic [4:0]  nev_now;
  logic [3:0]  irq_set;
  always_comb begin
    any_ev = |ev_i; first_ev = '0; nev_now = '0; irq_set = '0;
    for (int i = NEV - 1; i >= 0; i--) if (ev_i[i]) first_ev = 5'(i);
    for (int i = 0; i < NEV; i++) begin
      nev_now = nev_now + 5'(ev_i[i]);
      if (ev_i[i]) irq_set[sev_of(i)] = 1'b1;
    end
  end

  logic [4:0] log_level;
  assign log_level = log_wr_q - log_rd_q;
  logic [1:0] first_sev;
  assign first_sev = sev_of(int'(first_ev));
  logic [8:0] lost_sum;
  always_comb begin
    lost_sum = {1'b0, lost_q};
    if (any_ev) begin
      if (log_level < 5'd16) begin
        if (nev_now > 5'd1) lost_sum = lost_sum + 9'(nev_now - 5'd1);
      end else lost_sum = lost_sum + 9'(nev_now);
    end
  end

  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin
      for (int i = 0; i < NEV; i++) cnt_q[i] <= '0;
      ts_q <= '0; corr_q <= '0; pages_q <= '0; wrok_q <= '0; rdok_q <= '0; wrerr_q <= '0; rderr_q <= '0; maxf_q <= '0;
      hist_q <= '0; irq_q <= '0; alarm_q <= 1'b0; log_wr_q <= '0; log_rd_q <= '0; lost_q <= '0; auth_base_q <= '0;
      for (int i = 0; i < 16; i++) log_q[i] <= '0;
    end else begin
      ts_q <= ts_q + 32'd1;
      // ---- counters (a clear in the same cycle wins)
      for (int i = 0; i < NEV; i++) cnt_q[i] <= clr_session_i ? 32'd0 : (ev_i[i] ? sat_add(cnt_q[i], 32'd1) : cnt_q[i]);
      if (clr_session_i) begin
        corr_q <= '0; pages_q <= '0; wrok_q <= '0; rdok_q <= '0; wrerr_q <= '0; rderr_q <= '0; maxf_q <= '0;
        auth_base_q <= '0;
      end else begin
        if (pst_i) begin
          pages_q <= sat_add(pages_q, 32'd1);
          corr_q  <= sat_add(corr_q, {16'h0, pst_flips_i});
          if (pst_max_i > maxf_q) maxf_q <= pst_max_i;
        end
        if (wr_ok_i)  wrok_q  <= sat_add(wrok_q, 32'd1);
        if (rd_ok_i)  rdok_q  <= sat_add(rdok_q, 32'd1);
        if (wr_err_i) wrerr_q <= sat_add(wrerr_q, 32'd1);
        if (rd_err_i) rderr_q <= sat_add(rderr_q, 32'd1);
      end
      // ---- history, interrupt status, security alarm
      hist_q <= (clr_hist_i ? '0 : hist_q) | ev_i;
      irq_q  <= (irq_q & ~irq_clr_i) | irq_set;
      if (auth_limit_i != 32'd0 && (cnt_q[EV_AUTH_FAIL] - auth_base_q) >= auth_limit_i) begin
        alarm_q <= 1'b1; irq_q[3] <= 1'b1;
      end
      if (ack_i) begin alarm_q <= 1'b0; auth_base_q <= cnt_q[EV_AUTH_FAIL]; end
      // ---- log
      if (any_ev && log_level < 5'd16) begin
        log_q[log_wr_q[3:0]] <= {ev_info_i, ts_q, 8'h00, ev_err_i, ev_tag_i, 1'b0, first_sev, first_ev};
        log_wr_q <= log_wr_q + 5'd1;
      end
      lost_q <= (lost_sum > 9'd255) ? 8'hFF : lost_sum[7:0];
      if (clr_log_i)  begin log_wr_q <= '0; log_rd_q <= '0; lost_q <= '0; end
      else if (log_pop_i && log_level != 5'd0) log_rd_q <= log_rd_q + 5'd1;
    end
  end

  always_comb begin
    for (int i = 0; i < NEV; i++) cnt_o[32*i +: 32] = cnt_q[i];
  end
  assign corr_bits_o = corr_q;
  assign pages_dec_o = pages_q;
  assign wr_ok_o = wrok_q; assign rd_ok_o = rdok_q; assign wr_err_o = wrerr_q; assign rd_err_o = rderr_q;
  assign max_flips_o = maxf_q;
  assign hist_o = hist_q;
  assign log_count_o = {3'b0, log_level};
  assign log_lost_o  = lost_q;
  logic [95:0] head;
  assign head = log_q[log_rd_q[3:0]];
  assign log_w0_o = (log_level == 5'd0) ? 32'h0 : head[31:0];
  assign log_w1_o = (log_level == 5'd0) ? 32'h0 : head[63:32];
  assign log_w2_o = (log_level == 5'd0) ? 32'h0 : head[95:64];
  assign irq_status_o = irq_q;
  assign sec_alarm_o  = alarm_q;
  assign irq_o        = irq_global_en_i && |(irq_q & irq_en_i);
  assign ras_warn_o   = irq_q[1];
  assign ras_err_o    = irq_q[2];
  assign ras_fatal_o  = irq_q[3] | alarm_q;
endmodule

`default_nettype wire
