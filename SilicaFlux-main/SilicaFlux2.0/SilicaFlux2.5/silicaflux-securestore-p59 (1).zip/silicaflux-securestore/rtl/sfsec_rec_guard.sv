// =============================================================================
// SilicaFlux SecureStore :: sfsec_rec_guard -- integrity / authentication of metadata records
//
// Separate protections for four record classes (docs/03):
//   CLS_PMD 0x01 physical storage metadata (rides in the ECC user-metadata field of every page)
//   CLS_MAP 0x02 FTL mapping records      CLS_JRN 0x03 persistent journal records      CLS_HLT 0x04 health snapshot
// Every record is  body(<=32 B) | CRC-32C | CMAC-64  with
//   CRC  = CRC-32C( class || len || body )                       -- ACCIDENTAL corruption only (not authentication)
//   TAG  = AES-CMAC(K_mac, class || len || body || ctx[8, LE])[0:8]   -- authenticity, NIST SP 800-38B, Tlen = 64
// `ctx` binds the record to where it lives (e.g. physical page address); `class` and `len` give domain
// separation, so a record of one class can never validate as another.  A CRC mismatch is reported as
// corruption; a valid CRC with an invalid tag is reported as an authentication failure (forgery / wrong key).
// Verify compares the full tag at once (no early exit).
// The CMAC engine is shared (client port); `auth_i = 0` skips the tag (CRC-only mode).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfsec_rec_guard
  import sfsec_pkg::*;
(
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         zeroize_i,
  // request (one at a time)
  input  wire logic         req_valid_i,
  output logic              req_ready_o,
  output logic              busy_o,
  input  wire logic         req_verify_i,   // 0: seal (compute), 1: verify
  input  wire logic [7:0]   req_cls_i,
  input  wire logic [5:0]   req_len_i,      // 0..32
  input  wire logic [255:0] req_body_i,     // byte 0 in [255:248]
  input  wire logic [63:0]  req_ctx_i,
  input  wire logic [31:0]  req_crc_i,      // verify: stored CRC
  input  wire logic [63:0]  req_tag_i,      // verify: stored tag
  input  wire logic         req_auth_i,
  input  wire logic [127:0] req_kmac_i,
  // response
  output logic              rsp_valid_o,    // one-cycle pulse
  output logic [31:0]       rsp_crc_o,
  output logic [63:0]       rsp_tag_o,
  output logic              rsp_crc_ok_o,
  output logic              rsp_tag_ok_o,
  output logic              rsp_err_o,      // illegal class / length
  // CMAC client
  output logic              cm_start_o,
  output logic [255:0]      cm_key_o,
  output logic              cm_key256_o,
  output logic [6:0]        cm_len_o,
  output logic [511:0]      cm_msg_o,
  input  wire logic         cm_busy_i,
  input  wire logic         cm_done_i,
  input  wire logic [127:0] cm_tag_i
);
  typedef enum logic [2:0] { G_IDLE, G_CRC, G_CRCW, G_CM, G_CMW, G_RSP } gstate_t;
  gstate_t st;

  logic         ver_q, auth_q;
  logic [7:0]   cls_q;
  logic [5:0]   len_q;
  logic [255:0] body_q;
  logic [63:0]  ctx_q;
  logic [31:0]  icrc_q;
  logic [63:0]  itag_q;
  logic [127:0] kmac_q;
  logic [5:0]   idx_q;        // CRC byte index (0 .. len+1)
  logic         bad_q;
  logic [1:0]   zc_q;

  // CRC engine, byte-serial
  logic        c_clr, c_en;
  logic [7:0]  c_byte;
  logic [31:0] c_crc;
  sfsec_crc u_crc (.clk(clk), .rst_n(rst_n), .clr(c_clr), .mode_i(2'd0), .en(c_en), .data_i({24'b0, c_byte}),
                   .nbytes_i(3'd1), .crc_o(c_crc));

  always_comb begin
    if (idx_q == 6'd0)      c_byte = cls_q;
    else if (idx_q == 6'd1) c_byte = {2'b0, len_q};
    else                    c_byte = body_q[255 - 8*int'(idx_q - 6'd2) -: 8];
  end
  assign c_clr = (st == G_IDLE) && req_valid_i && req_ready_o;
  assign c_en  = (st == G_CRC);

  // CMAC message: class || len || body[len] || ctx (little endian)
  always_comb begin
    cm_msg_o = '0;
    cm_msg_o[511 -: 8]  = cls_q;
    cm_msg_o[503 -: 8]  = {2'b0, len_q};
    for (int b = 0; b < 32; b++) if (b < len_q) cm_msg_o[495 - 8*b -: 8] = body_q[255 - 8*b -: 8];
    for (int k = 0; k < 8; k++) cm_msg_o[495 - 8*(len_q + k) -: 8] = ctx_q[8*k +: 8];
  end
  assign cm_key_o    = {kmac_q, 128'b0};
  assign cm_key256_o = 1'b0;
  assign cm_len_o    = 7'(len_q) + 7'd10;
  assign cm_start_o  = (st == G_CM) && !cm_busy_i;

  assign req_ready_o = (st == G_IDLE) && (zc_q == 2'd0);
  assign busy_o      = (st != G_IDLE);

  logic [31:0] crc_q;
  logic [63:0] tag_q;
  logic        crc_ok_c, tag_ok_c;
  assign crc_ok_c = (crc_q == icrc_q);
  assign tag_ok_c = (tag_q == itag_q);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= G_IDLE; ver_q <= 1'b0; auth_q <= 1'b0; cls_q <= '0; len_q <= '0; body_q <= '0; ctx_q <= '0;
      icrc_q <= '0; itag_q <= '0; kmac_q <= '0; idx_q <= '0; bad_q <= 1'b0; crc_q <= '0; tag_q <= '0; zc_q <= 2'd0;
      rsp_valid_o <= 1'b0; rsp_crc_o <= '0; rsp_tag_o <= '0; rsp_crc_ok_o <= 1'b0; rsp_tag_ok_o <= 1'b0;
      rsp_err_o <= 1'b0;
    end else begin
      rsp_valid_o <= 1'b0;
      if (zc_q != 2'd0) zc_q <= zc_q - 2'd1;
      if (zeroize_i) begin
        st <= G_IDLE; body_q <= '0; kmac_q <= '0; ctx_q <= '0; crc_q <= '0; tag_q <= '0; zc_q <= 2'd2;
        rsp_crc_o <= '0; rsp_tag_o <= '0;
      end else begin
        case (st)
          G_IDLE: if (req_valid_i && req_ready_o) begin
            ver_q <= req_verify_i; auth_q <= req_auth_i; cls_q <= req_cls_i; len_q <= req_len_i;
            body_q <= req_body_i; ctx_q <= req_ctx_i; icrc_q <= req_crc_i; itag_q <= req_tag_i; kmac_q <= req_kmac_i;
            idx_q <= '0;
            bad_q <= (req_cls_i == 8'h00) || (req_cls_i > CLS_HLT) || (req_len_i > 6'd32);
            st <= G_CRC;
          end
          G_CRC: begin
            if (idx_q == len_q + 6'd1) st <= G_CRCW;
            idx_q <= idx_q + 6'd1;
          end
          G_CRCW: begin crc_q <= c_crc; st <= (auth_q && !bad_q) ? G_CM : G_RSP; end
          G_CM:  if (!cm_busy_i) st <= G_CMW;
          G_CMW: if (cm_done_i) begin tag_q <= cm_tag_i[127:64]; st <= G_RSP; end
          G_RSP: begin
            rsp_valid_o   <= 1'b1;
            rsp_err_o     <= bad_q;
            rsp_crc_o     <= bad_q ? '0 : crc_q;
            rsp_tag_o     <= (bad_q || !auth_q) ? '0 : tag_q;
            rsp_crc_ok_o  <= !bad_q && (!ver_q || crc_ok_c);
            rsp_tag_ok_o  <= !bad_q && (!auth_q || !ver_q || tag_ok_c);
            st <= G_IDLE;
            body_q <= '0; kmac_q <= '0;       // hygiene: no K_mac copy outlives the request
          end
          default: st <= G_IDLE;
        endcase
      end
    end
  end
endmodule

`default_nettype wire
