// =============================================================================
// SilicaFlux SecureStore :: sfsec_health -- health telemetry: temperature, wear / capacity, lifetime snapshot
//
//   * temperature: last / maximum / minimum sensor code and the thermal-warning level (platform sensor; units are
//     whatever the sensor code means -- no conversion is applied)
//   * wear / capacity statistics are PUBLISHED BY FIRMWARE (the FTL owns erase counts, bad blocks and spare
//     capacity); this block stores them and flags which ones were published.  There is deliberately NO
//     "remaining life %" -- no validated NAND wear model exists to derive one (docs/06).
//   * lifetime snapshot service ("persistent counters"): this block cannot write NAND.  Firmware CAPTUREs a
//     32-word snapshot = {restored base + this power-on's counters, maxima, fault classes, CRC-32C}, stores it
//     in its metadata, and after the next power-up RESTOREs it (CRC-32C verified; refused otherwise).
//     CRC-32C detects accidental corruption only: a stale or forged-but-consistent snapshot is accepted
//     (authenticated, rollback-protected telemetry needs firmware to wrap the image with a MAC and a monotonic
//     counter that this design does not have -- docs/09).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfsec_health
  import sfsec_pkg::*;
(
  input  wire logic          clk,
  input  wire logic          por_rst_n,
  // sensors
  input  wire logic          temp_valid_i,
  input  wire logic [15:0]   temp_code_i,
  input  wire logic          therm_warn_i,
  output logic               therm_ev_o,       // rising edge of the warning
  output logic [15:0]        temp_cur_o,
  output logic [15:0]        temp_max_o,
  output logic [15:0]        temp_min_o,
  output logic               temp_seen_o,
  output logic               therm_warn_o,
  // session statistics from the RAS block
  input  wire logic [28*32-1:0] cnt28_i,    // 28 counters: events 0..23, corrected bits, pages decoded, wr ok, rd ok
  input  wire logic [7:0]    maxflips_i,
  input  wire logic [NEV-1:0] hist_i,
  // snapshot service
  input  wire logic          cap_i,
  input  wire logic          rst_i,            // RESTORE from the staging image
  input  wire logic          clr_life_i,
  input  wire logic [32*32-1:0] base_img_i,    // staging image (HL_BASE0..31)
  output logic [32*32-1:0]   snap_o,
  output logic               snap_valid_o,
  output logic               restored_o,
  output logic               refused_o,
  output logic [7:0]         ncap_o,
  output logic [15:0]        age_o,
  output logic [NEV-1:0]     fault_life_o,
  output logic               busy_o
);
  // ---------------------------------------------------------------- temperature
  logic [15:0] cur_q, max_q, min_q;
  logic        seen_q, warn_q;
  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin
      cur_q <= '0; max_q <= '0; min_q <= 16'hFFFF; seen_q <= 1'b0; warn_q <= 1'b0; therm_ev_o <= 1'b0;
    end else begin
      therm_ev_o <= therm_warn_i && !warn_q;
      warn_q <= therm_warn_i;
      if (temp_valid_i) begin
        cur_q <= temp_code_i; seen_q <= 1'b1;
        if (!seen_q || temp_code_i > max_q) max_q <= temp_code_i;
        if (!seen_q || temp_code_i < min_q) min_q <= temp_code_i;
      end
    end
  end
  assign temp_cur_o = cur_q; assign temp_max_o = max_q; assign temp_min_o = min_q;
  assign temp_seen_o = seen_q; assign therm_warn_o = warn_q;

  // ---------------------------------------------------------------- lifetime snapshot
  logic [31:0] base_q [32];
  logic [31:0] snap_q [32];
  logic        sv_q, rs_q, rf_q;
  logic [7:0]  ncap_q;
  logic [15:0] age_q;
  typedef enum logic [2:0] { H_IDLE, H_CAPCRC, H_CAPFIN, H_RSTCRC, H_RSTFIN } hstate_t;
  hstate_t st;
  logic [4:0]  idx_q;
  logic        c_clr, c_en;
  logic [31:0] c_data, c_crc;
  sfsec_crc u_crc (.clk(clk), .rst_n(por_rst_n), .clr(c_clr), .mode_i(2'd0), .en(c_en), .data_i(c_data), .nbytes_i(3'd4),
                   .crc_o(c_crc));
  assign c_clr  = (st == H_IDLE) && (cap_i || rst_i);
  assign c_en   = (st == H_CAPCRC) || (st == H_RSTCRC);
  assign c_data = (st == H_CAPCRC) ? snap_q[idx_q] : base_img_i[32*int'(idx_q) +: 32];
  // little-endian bytes of each word are fed LSB first: byte 0 = bits [7:0]

  function automatic logic [31:0] sat_add(input logic [31:0] a, input logic [31:0] b);
    logic [32:0] s;
    s = {1'b0, a} + {1'b0, b};
    return s[32] ? 32'hFFFF_FFFF : s[31:0];
  endfunction

  assign busy_o = (st != H_IDLE);
  logic [31:0] hist32;
  assign hist32 = {{(32-NEV){1'b0}}, hist_i};

  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin
      for (int i = 0; i < 32; i++) begin base_q[i] <= '0; snap_q[i] <= '0; end
      sv_q <= 1'b0; rs_q <= 1'b0; rf_q <= 1'b0; ncap_q <= '0; age_q <= '0; st <= H_IDLE; idx_q <= '0;
    end else begin
      case (st)
        H_IDLE: begin
          if (cap_i) begin
            for (int i = 0; i < 28; i++) snap_q[i] <= sat_add(base_q[i], cnt28_i[32*i +: 32]);
            snap_q[28] <= (base_q[28][7:0] > maxflips_i) ? base_q[28] : {24'h0, maxflips_i};
            snap_q[29] <= (base_q[29][15:0] > max_q) ? base_q[29] : {16'h0, max_q};
            snap_q[30] <= base_q[30] | hist32;
            idx_q <= '0; st <= H_CAPCRC;
          end else if (rst_i) begin idx_q <= '0; st <= H_RSTCRC; end
          if (clr_life_i) begin for (int i = 0; i < 32; i++) base_q[i] <= '0; rs_q <= 1'b0; age_q <= '0; end
        end
        H_CAPCRC: begin
          if (idx_q == 5'd30) st <= H_CAPFIN; else idx_q <= idx_q + 5'd1;
        end
        H_CAPFIN: begin
          snap_q[31] <= c_crc; sv_q <= 1'b1; ncap_q <= ncap_q + 8'd1; age_q <= age_q + 16'd1; st <= H_IDLE;
        end
        H_RSTCRC: begin
          if (idx_q == 5'd30) st <= H_RSTFIN; else idx_q <= idx_q + 5'd1;
        end
        H_RSTFIN: begin
          if (c_crc == base_img_i[32*31 +: 32]) begin
            for (int i = 0; i < 32; i++) base_q[i] <= base_img_i[32*i +: 32];
            rs_q <= 1'b1; rf_q <= 1'b0; age_q <= '0;
          end else rf_q <= 1'b1;
          st <= H_IDLE;
        end
        default: st <= H_IDLE;
      endcase
    end
  end

  always_comb begin
    for (int i = 0; i < 32; i++) snap_o[32*i +: 32] = snap_q[i];
  end
  assign snap_valid_o = sv_q; assign restored_o = rs_q; assign refused_o = rf_q;
  assign ncap_o = ncap_q; assign age_o = age_q;
  assign fault_life_o = base_q[30][NEV-1:0] | hist_i;
endmodule

`default_nettype wire
