// =============================================================================
// SilicaFlux SecureStore :: sfsec_kdf -- NIST SP 800-108 key derivation, counter mode, PRF = AES-CMAC
//
//   K(i) = CMAC(KI, [i]_32 (big endian) || FixedInput),  i = 1 .. ceil(L/128),  output = K(1)||K(2)||...
//
// "Counter before fixed input", r = 32 bits (CAVP KBKDF CTR configuration).  The CMAC engine is shared and
// owned by the caller; this block only sequences the calls.  FixedInput <= 60 bytes (byte 0 in fixed_i[479:472]).
// Output ko_o[511:0]: byte 0 in [511:504]; only the first ceil(L/8) bytes are meaningful (rest zero).
// Validated against NIST CAVP KBKDF CTR AES-CMAC vectors (tb_crypto_units).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfsec_kdf (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         start_i,
  input  wire logic [255:0] ki_i,        // key-derivation key, left aligned
  input  wire logic         ki256_i,
  input  wire logic [479:0] fixed_i,
  input  wire logic [5:0]   fixed_len_i, // 0..60 bytes
  input  wire logic [9:0]   l_bits_i,    // output length in bits, multiple of 8, 8..512
  output logic              busy_o,
  output logic              done_o,
  output logic [511:0]      ko_o,
  // CMAC client port
  output logic              cm_start_o,
  output logic [255:0]      cm_key_o,
  output logic              cm_key256_o,
  output logic [6:0]        cm_len_o,
  output logic [511:0]      cm_msg_o,
  input  wire logic         cm_busy_i,
  input  wire logic         cm_done_i,
  input  wire logic [127:0] cm_tag_i
);
  typedef enum logic [2:0] { K_IDLE, K_CALL, K_WAIT, K_DONE } kstate_t;
  kstate_t st;
  logic [255:0] ki_q;
  logic         k256_q;
  logic [479:0] fixed_q;
  logic [5:0]   flen_q;
  logic [9:0]   l_q;
  logic [2:0]   i_q, n_q;       // 0-based block index / number of blocks
  logic [511:0] ko_q;

  assign busy_o = (st != K_IDLE);
  assign ko_o   = ko_q;

  // message = counter(4 B) || fixed (flen B), byte 0 in the MSB
  always_comb begin
    cm_msg_o = '0;
    cm_msg_o[511 -: 32] = {29'b0, i_q} + 32'd1;
    cm_msg_o[479:0]     = fixed_q;
  end
  assign cm_key_o    = ki_q;
  assign cm_key256_o = k256_q;
  assign cm_len_o    = {1'b0, flen_q} + 7'd4;
  assign cm_start_o  = (st == K_CALL) && !cm_busy_i;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= K_IDLE; ki_q <= '0; k256_q <= 1'b0; fixed_q <= '0; flen_q <= '0; l_q <= '0; i_q <= '0; n_q <= '0;
      ko_q <= '0; done_o <= 1'b0;
    end else begin
      done_o <= 1'b0;
      case (st)
        K_IDLE: if (done_o) begin
          ki_q <= '0; fixed_q <= '0; ko_q <= '0;           // hygiene: derived keys and the PRK copy do not outlive the call
        end else if (start_i) begin
          ki_q <= ki_i; k256_q <= ki256_i; fixed_q <= fixed_i; flen_q <= fixed_len_i; l_q <= l_bits_i;
          n_q <= 3'((l_bits_i + 10'd127) >> 7); i_q <= 3'd0; ko_q <= '0;
          st <= K_CALL;
        end
        K_CALL: if (!cm_busy_i) st <= K_WAIT;       // cm_start_o asserted this cycle
        K_WAIT: if (cm_done_i) begin
          ko_q[511 - 128*i_q -: 128] <= cm_tag_i;
          if (i_q + 3'd1 == n_q) st <= K_DONE;
          else begin i_q <= i_q + 3'd1; st <= K_CALL; end
        end
        K_DONE: begin
          // truncate to L bits (zero the unused tail)
          for (int b = 0; b < 64; b++) if (b >= (l_q >> 3)) ko_q[511 - 8*b -: 8] <= 8'h00;
          done_o <= 1'b1; st <= K_IDLE;
        end
        default: st <= K_IDLE;
      endcase
    end
  end
endmodule

`default_nettype wire
