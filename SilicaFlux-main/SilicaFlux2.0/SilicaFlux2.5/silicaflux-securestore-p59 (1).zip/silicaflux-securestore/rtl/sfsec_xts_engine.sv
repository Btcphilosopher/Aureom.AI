// =============================================================================
// SilicaFlux SecureStore :: sfsec_xts_engine -- XTS-AES mode engine around a VETTED AES block core
//
// Integration contract for an AES-XTS engine (docs/02 section 3): this module is the *reference realisation*
// of that contract; a licensed / validated XTS IP can replace it behind the same ports.
//
//   * Block primitive: secworks/aes `aes_core` (FIPS 197, 128/256-bit keys), vendored UNMODIFIED
//     (third_party/secworks-aes).  Two instances: data key (K1, encrypt or decrypt) and tweak key (K2, encrypt).
//   * Mode: XTS-AES per IEEE 1619-2007 / NIST SP 800-38E.  The only logic written here is the mode itself:
//       T_0 = AES_K2(tweak) ; C_j = AES_K1(P_j ^ T_j) ^ T_j ; T_{j+1} = T_j * alpha in GF(2^128)
//     validated against NIST CAVP XTS vectors, IEEE 1619 Annex B and OpenSSL (tb_crypto_units, model/).
//   * Key sizes: XTS-AES-128 (2 x 128-bit keys, 256-bit XTS key) and XTS-AES-256 (2 x 256-bit, 512-bit XTS key).
//     Equal key halves are refused (SP 800-38E / FIPS 140 IG A.9) -> key_eq_o.
//   * Data unit: 1 .. 2^20 whole 16-byte blocks (SP 800-38E limit).  Ciphertext stealing (partial final block)
//     is NOT implemented: a data unit is always a multiple of 16 bytes (sector sizes are).
//   * Provides CONFIDENTIALITY only.  XTS gives no authentication or tamper detection (docs/09).
//
// Port conventions: all 128-bit values are AES blocks, byte 0 in bits [127:120].  Keys are left-aligned in the
// 256-bit key ports (AES-128: key in [255:128]).  `du_tweak_i` carries the 16 tweak bytes (the data-unit number
// as a little-endian integer, byte 0 first).
// Flow control: s_* accepts one plaintext/ciphertext block when s_ready_o; m_* delivers one block with m_last_o on
// the final block of the data unit.  One data unit in flight.
// Zeroisation: zeroize_i resets both AES cores (their round-key memories are cleared by the cores' reset) and
// clears the key / tweak registers.
// Classification: SYNTHESIZABLE (AES core: third-party, see PROVENANCE.md)
// =============================================================================
`default_nettype none

module sfsec_xts_engine
  import sfsec_pkg::*;
(
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         zeroize_i,
  // ---- key interface
  input  wire logic         key_load_i,     // pulse; ignored unless key_idle_o
  input  wire logic [255:0] key1_i,         // data key (K1)
  input  wire logic [255:0] key2_i,         // tweak key (K2)
  input  wire logic         key256_i,       // 0: AES-128 halves, 1: AES-256 halves
  output logic              key_idle_o,
  output logic              key_ok_o,       // keys loaded and expanded
  output logic              key_eq_o,       // last load refused: K1 == K2
  // ---- data-unit command
  input  wire logic         du_start_i,     // pulse; requires du_ready_o
  input  wire logic         du_dec_i,       // 1: decrypt
  input  wire logic [127:0] du_tweak_i,
  input  wire logic [20:0]  du_nblk_i,      // 1 .. 2^20
  output logic              du_ready_o,
  output logic              du_len_err_o,   // pulse: du_nblk_i out of range at start (command refused)
  input  wire logic         abort_i,        // pulse: drop the data unit in flight (tweak state is wiped)
  // ---- block streams
  input  wire logic         s_valid_i,
  output logic              s_ready_o,
  input  wire logic [127:0] s_data_i,
  output logic              m_valid_o,
  input  wire logic         m_ready_i,
  output logic [127:0]      m_data_o,
  output logic              m_last_o,
  output logic              busy_o
);
  localparam int MAX_BLK = 1 << 20;

  typedef enum logic [3:0] {
    X_IDLE, X_KINIT, X_KWAIT, X_TW, X_TWWAIT, X_BLK, X_AES, X_AESWAIT, X_OUT, X_DRAIN
  } xstate_t;
  xstate_t st;

  logic [255:0] k1_q, k2_q;
  logic         k256_q;
  logic         key_ok_q, key_eq_q;
  logic         dec_q;
  logic [127:0] tw_q;      // current tweak T_j (AES block byte order)
  logic [127:0] in_q;      // P ^ T
  logic [127:0] out_q;
  logic [20:0]  cnt_q, nblk_q;
  logic [1:0]   zc_q;      // zeroize hold counter
  logic         abort_q;   // abort request latched until the engine reaches X_DRAIN
  logic         ab;
  assign ab = abort_i | abort_q;

  // ---- AES cores (reset low = zeroised round keys)
  logic aes_rst_n;
  assign aes_rst_n = rst_n & (zc_q == 2'd0);

  logic         d_init, d_next, d_ready, d_rv;
  logic [127:0] d_res;
  logic         t_init, t_next, t_ready, t_rv;
  logic [127:0] t_res;
  logic [127:0] t_block;

  aes_core u_aes_data (.clk(clk), .reset_n(aes_rst_n), .encdec(~dec_q), .init(d_init), .next(d_next),
                       .ready(d_ready), .key(k1_q), .keylen(k256_q), .block(in_q), .result(d_res),
                       .result_valid(d_rv));
  aes_core u_aes_twk  (.clk(clk), .reset_n(aes_rst_n), .encdec(1'b1), .init(t_init), .next(t_next),
                       .ready(t_ready), .key(k2_q), .keylen(k256_q), .block(t_block), .result(t_res),
                       .result_valid(t_rv));
  assign t_block = tw_q;   // tweak core input: the 16 tweak bytes

  logic eq_now;
  assign eq_now = key256_i ? (key1_i == key2_i) : (key1_i[255:128] == key2_i[255:128]);

  assign key_idle_o   = (st == X_IDLE) && (zc_q == 2'd0);
  assign key_ok_o     = key_ok_q;
  assign key_eq_o     = key_eq_q;
  assign du_ready_o   = (st == X_IDLE) && key_ok_q && (zc_q == 2'd0);
  assign busy_o       = (st != X_IDLE);
  assign s_ready_o    = (st == X_BLK);
  assign m_valid_o    = (st == X_OUT);
  assign m_data_o     = out_q;
  assign m_last_o     = (st == X_OUT) && (cnt_q + 21'd1 == nblk_q);

  assign d_init = (st == X_KINIT);
  assign t_init = (st == X_KINIT);
  assign t_next = (st == X_TW);
  assign d_next = (st == X_AES);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= X_IDLE; k1_q <= '0; k2_q <= '0; k256_q <= 1'b0; key_ok_q <= 1'b0; key_eq_q <= 1'b0;
      dec_q <= 1'b0; tw_q <= '0; in_q <= '0; out_q <= '0; cnt_q <= '0; nblk_q <= '0; zc_q <= 2'd0;
      du_len_err_o <= 1'b0; abort_q <= 1'b0;
    end else begin
      du_len_err_o <= 1'b0;
      if (zc_q != 2'd0) zc_q <= zc_q - 2'd1;
      if (abort_i && st != X_IDLE) abort_q <= 1'b1;

      if (zeroize_i) begin
        zc_q <= 2'd3;                       // hold the AES cores in reset for 3 cycles
        k1_q <= '0; k2_q <= '0; k256_q <= 1'b0; key_ok_q <= 1'b0; key_eq_q <= 1'b0;
        tw_q <= '0; in_q <= '0; out_q <= '0; cnt_q <= '0; nblk_q <= '0; dec_q <= 1'b0; abort_q <= 1'b0;
        st <= X_IDLE;
      end else begin
        case (st)
          X_IDLE: begin
            if (key_load_i && zc_q == 2'd0) begin
              k1_q <= key1_i; k2_q <= key2_i; k256_q <= key256_i; key_eq_q <= eq_now;
              if (eq_now) begin                 // policy: refuse, and leave no usable key behind
                key_ok_q <= 1'b0;
                k1_q <= '0; k2_q <= '0;
                zc_q <= 2'd3;
              end else begin
                key_ok_q <= 1'b0;
                st <= X_KINIT;
              end
            end else if (du_start_i && du_ready_o) begin
              if (du_nblk_i == 21'd0 || du_nblk_i > MAX_BLK[20:0]) begin
                du_len_err_o <= 1'b1;
              end else begin
                dec_q <= du_dec_i; tw_q <= du_tweak_i; nblk_q <= du_nblk_i; cnt_q <= '0;
                st <= X_TW;
              end
            end
          end
          X_KINIT: st <= X_KWAIT;                 // init pulse issued this cycle
          X_KWAIT: if (d_ready && t_ready) begin key_ok_q <= 1'b1; st <= X_IDLE; end
          X_TW:    st <= ab ? X_DRAIN : X_TWWAIT;  // tweak encryption started
          X_TWWAIT: if (ab) st <= X_DRAIN;
                    else if (t_ready && t_rv) begin tw_q <= t_res; st <= X_BLK; end
          X_BLK: begin
            if (ab) st <= X_DRAIN;
            else if (s_valid_i) begin in_q <= s_data_i ^ tw_q; st <= X_AES; end
          end
          X_AES:   st <= X_AESWAIT;               // next pulse issued this cycle
          X_AESWAIT: if (d_ready && d_rv) begin out_q <= d_res ^ tw_q; st <= ab ? X_DRAIN : X_OUT; end
          X_OUT: begin
            if (ab) st <= X_DRAIN;
            else if (m_ready_i) begin
              tw_q  <= xts_mul_alpha(tw_q);
              cnt_q <= cnt_q + 21'd1;
              st    <= (cnt_q + 21'd1 == nblk_q) ? X_IDLE : X_BLK;
            end
          end
          X_DRAIN: begin
            tw_q <= '0; in_q <= '0; out_q <= '0;
            if (d_ready && t_ready) begin st <= X_IDLE; abort_q <= 1'b0; end
          end
          default: st <= X_IDLE;
        endcase
      end
    end
  end
endmodule

`default_nettype wire
