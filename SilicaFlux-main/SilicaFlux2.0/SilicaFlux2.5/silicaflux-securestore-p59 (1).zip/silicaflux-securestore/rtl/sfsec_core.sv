// =============================================================================
// SilicaFlux SecureStore :: sfsec_core -- key manager + CMAC + record guard service + protected data path + ECCCore
//
// Structural integration of the cryptographic / integrity blocks with the P54 ECC engine (vendored unmodified).
// The shared AES-CMAC engine is used by exactly one client at a time (key derivation, the pipeline's PMD guard,
// or the firmware record-guard service); an interlock in the register layer guarantees mutual exclusion.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfecc_defs.svh"
`include "sfsec_ecc_cfg.svh"
`default_nettype none

module sfsec_core
  import sfsec_pkg::*;
#(
  parameter int DU_BYTES = 512,
  parameter int NS = 4,
  parameter int WD_RD = 200000          // read watchdog (cycles waiting for NAND / ECC)
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         flush_i,
  input  wire logic         zeroize_i,
  // ---- data command / host data / response (see sfsec_pipeline)
  input  wire logic         cmd_valid_i,
  output logic              cmd_ready_o,
  input  wire logic         cmd_op_i,
  input  wire logic [7:0]   cmd_tag_i,
  input  wire logic [63:0]  cmd_lba_i,
  input  wire logic [31:0]  cmd_ppa_i,
  input  wire logic [47:0]  cmd_seq_i,
  input  wire logic [1:0]   cmd_slot_i,
  input  wire logic         pol_data_en_i,
  input  wire logic         pol_auth_en_i,
  input  wire logic         pol_auth_req_i,
  input  wire logic         pol_scr_en_i,
  input  wire logic [31:0]  pol_wd_host_i,
  input  wire logic         hw_valid_i,
  output logic              hw_ready_o,
  input  wire logic [31:0]  hw_data_i,
  input  wire logic         hw_err_i,
  input  wire logic         hw_poison_i,
  input  wire logic         dma_err_i,
  output logic              hr_valid_o,
  input  wire logic         hr_ready_i,
  output logic [31:0]       hr_data_o,
  output logic              hr_last_o,
  output logic              rsp_valid_o,
  input  wire logic         rsp_ready_i,
  output logic              rsp_op_o,
  output logic [7:0]        rsp_tag_o,
  output logic [7:0]        rsp_err_o,
  output logic [31:0]       rsp_info_o,
  output logic              pipe_busy_o,
  // ---- key manager command
  input  wire logic         km_valid_i,
  input  wire logic [2:0]   km_op_i,
  input  wire logic [1:0]   km_slot_i,
  input  wire logic         km_k256_i,
  input  wire logic [255:0] km_k1_i,
  input  wire logic [255:0] km_k2_i,
  input  wire logic [127:0] km_kmac_i,
  input  wire logic [127:0] km_salt_i,
  input  wire logic [7:0]   km_gen_i,
  input  wire logic         prk_valid_i,
  input  wire logic [255:0] prk_i,
  output logic              ent_req_o,
  input  wire logic         ent_valid_i,
  input  wire logic [127:0] ent_data_i,
  output logic              km_busy_o,
  output logic              km_done_o,
  output logic [7:0]        km_err_o,
  output logic              km_kill_o,
  output logic [NS-1:0]     slot_valid_o,
  output logic [NS-1:0]     slot_k256_o,
  output logic [NS-1:0]     slot_origin_o,
  output logic [8*NS-1:0]   slot_gen_o,
  output logic [128*NS-1:0] slot_salt_o,
  output logic [15:0]       epoch_o,
  // ---- firmware record-guard service
  input  wire logic         rg_valid_i,
  output logic              rg_ready_o,
  output logic              rg_busy_o,
  input  wire logic         rg_verify_i,
  input  wire logic [7:0]   rg_cls_i,
  input  wire logic [5:0]   rg_len_i,
  input  wire logic [255:0] rg_body_i,
  input  wire logic [63:0]  rg_ctx_i,
  input  wire logic [31:0]  rg_crc_i,
  input  wire logic [63:0]  rg_tag_i,
  input  wire logic         rg_auth_i,
  input  wire logic [1:0]   rg_slot_i,
  output logic              rg_rsp_valid_o,
  output logic [31:0]       rg_crc_o,
  output logic [63:0]       rg_tag_o,
  output logic              rg_crc_ok_o,
  output logic              rg_tag_ok_o,
  output logic              rg_err_o,
  output logic              rg_key_valid_o,
  // ---- ECC engine register window (P54)
  input  wire logic         ecc_rb_sel_i,
  input  wire logic         ecc_rb_we_i,
  input  wire logic [7:0]   ecc_rb_addr_i,
  input  wire logic [31:0]  ecc_rb_wdata_i,
  output logic [31:0]       ecc_rb_rdata_o,
  output logic              ecc_ev_corrected_o,
  output logic              ecc_ev_uncorr_o,
  output logic              ecc_ev_integrity_o,
  output logic              ecc_ev_scrub_o,
  // ---- NAND raw-page channel
  output logic              nand_cmd_valid_o,
  input  wire logic         nand_cmd_ready_i,
  output logic              nand_cmd_read_o,
  output logic [31:0]       nand_cmd_ppa_o,
  output logic              nand_wd_valid_o,
  input  wire logic         nand_wd_ready_i,
  output logic [7:0]        nand_wd_data_o,
  output logic              nand_wd_last_o,
  input  wire logic         nand_rd_valid_i,
  output logic              nand_rd_ready_o,
  input  wire logic [7:0]   nand_rd_data_i,
  input  wire logic         nand_rd_last_i,
  output logic              nand_abort_o,
  input  wire logic         nand_done_valid_i,
  input  wire logic         nand_done_fail_i,
  // ---- telemetry pulses
  output logic              tel_pst_o,
  output logic [15:0]       tel_flips_o,
  output logic [7:0]        tel_maxflips_o,
  output logic [7:0]        tel_ncorr_o,
  output logic              tel_scrub_o,
  output logic              tel_dma_o
);
  localparam int PAGE_DATA  = `SFSEC_PAGE_DATA;
  localparam int PAGE_SPARE = `SFSEC_PAGE_SPARE;

  // ---------------------------------------------------------------- datapath key hygiene
  // Every key command (install, derive, generate, invalidate) and every secure reset wipes the key copies held by the
  // XTS engine, the CMAC engine and the record guards; the next data command reloads from the key slots.
  logic dp_zero;
  assign dp_zero = zeroize_i | km_kill_o | km_done_o;

  // ---------------------------------------------------------------- key manager
  logic [1:0]   ks_slot;
  logic         ks_valid, ks_k256;
  logic [7:0]   ks_gen;
  logic [255:0] ks_k1, ks_k2;
  logic [127:0] ks_kmac;
  logic         km_cm_start, km_cm_k256;
  logic [255:0] km_cm_key;
  logic [6:0]   km_cm_len;
  logic [511:0] km_cm_msg;
  logic [127:0] cm_tag;

  // pipeline / guard CMAC client signals
  logic         pl_cm_start, pl_cm_k256; logic [255:0] pl_cm_key; logic [6:0] pl_cm_len; logic [511:0] pl_cm_msg;
  logic         fg_cm_start, fg_cm_k256; logic [255:0] fg_cm_key; logic [6:0] fg_cm_len; logic [511:0] fg_cm_msg;
  logic         cm_busy, cm_done;

  sfsec_keymgr #(.NS(NS)) u_km (.clk, .rst_n, .zeroize_i, .cmd_valid_i(km_valid_i), .cmd_op_i(km_op_i),
    .cmd_slot_i(km_slot_i), .cmd_k256_i(km_k256_i), .stg_k1_i(km_k1_i), .stg_k2_i(km_k2_i), .stg_kmac_i(km_kmac_i),
    .stg_salt_i(km_salt_i), .stg_gen_i(km_gen_i), .prk_valid_i, .prk_i, .ent_req_o, .ent_valid_i, .ent_data_i,
    .busy_o(km_busy_o), .done_o(km_done_o), .err_o(km_err_o), .kill_o(km_kill_o), .slot_valid_o, .slot_k256_o,
    .slot_origin_o, .slot_gen_o, .slot_salt_o, .epoch_o, .sel_slot_i(ks_slot), .sel_valid_o(ks_valid),
    .sel_gen_o(ks_gen), .sel_k256_o(ks_k256), .sel_k1_o(ks_k1), .sel_k2_o(ks_k2), .sel_kmac_o(ks_kmac), .sel2_slot_i(rg_slot_i), .sel2_valid_o(fg_kvalid), .sel2_kmac_o(fg_kmac),
    .cm_start_o(km_cm_start), .cm_key_o(km_cm_key), .cm_key256_o(km_cm_k256), .cm_len_o(km_cm_len),
    .cm_msg_o(km_cm_msg), .cm_busy_i(cm_busy), .cm_done_i(cm_done), .cm_tag_i(cm_tag));

  // ---------------------------------------------------------------- firmware record guard (selects its own K_mac slot)
  logic [127:0] fg_kmac;
  logic         fg_kvalid;

  // ---------------------------------------------------------------- shared CMAC engine (single owner at a time)
  logic        cm_start, cm_k256;
  logic [255:0] cm_key;
  logic [6:0]  cm_len;
  logic [511:0] cm_msg;
  logic        fg_busy_w;
  always_comb begin
    if (km_busy_o) begin
      cm_start = km_cm_start; cm_key = km_cm_key; cm_k256 = km_cm_k256; cm_len = km_cm_len; cm_msg = km_cm_msg;
    end else if (fg_busy_w) begin
      cm_start = fg_cm_start; cm_key = fg_cm_key; cm_k256 = fg_cm_k256; cm_len = fg_cm_len; cm_msg = fg_cm_msg;
    end else begin
      cm_start = pl_cm_start; cm_key = pl_cm_key; cm_k256 = pl_cm_k256; cm_len = pl_cm_len; cm_msg = pl_cm_msg;
    end
  end
  sfsec_cmac u_cmac (.clk, .rst_n, .zeroize_i(dp_zero), .start_i(cm_start), .key_i(cm_key), .key256_i(cm_k256),
                     .len_i(cm_len), .msg_i(cm_msg), .busy_o(cm_busy), .done_o(cm_done), .tag_o(cm_tag));

  // ---------------------------------------------------------------- ECC engine (P54) wires
  logic        e_wr_pay_v, e_wr_pay_r, e_wr_pay_l, e_wr_um_v, e_wr_um_r, e_wr_raw_v, e_wr_raw_r, e_wr_raw_l;
  logic [7:0]  e_wr_pay_d, e_wr_um_d, e_wr_raw_d;
  logic        e_rd_raw_v, e_rd_raw_r, e_rd_raw_l, e_rd_pay_v, e_rd_pay_r, e_rd_pay_l, e_rd_um_v, e_rd_um_r;
  logic [7:0]  e_rd_raw_d, e_rd_pay_d, e_rd_um_d;
  logic        e_sst_v, e_sst_r, e_pst_v, e_pst_r, e_pst_alle, e_pst_ok, e_pst_scrub, e_pst_ferr, e_crc_ok;
  logic [2:0]  e_sst_code;
  logic [7:0]  e_sst_nerr, e_sst_aux, e_sst_sec, e_pn_corr, e_pn_unc, e_pn_int, e_pn_era, e_pmax, e_pbbm;
  logic [15:0] e_ptot;
  logic        e_flush, e_irq, e_ebusy, e_dbusy;
  logic        ecc_rst_n;
  assign ecc_rst_n = rst_n & ~e_flush;

  silicaflux_storage_ecc #(`SFSEC_PAGE_SF59) u_ecc (
    .clk, .rst_n(ecc_rst_n), .rb_sel(ecc_rb_sel_i), .rb_we(ecc_rb_we_i), .rb_addr(ecc_rb_addr_i),
    .rb_wdata(ecc_rb_wdata_i), .rb_rdata(ecc_rb_rdata_o),
    .wr_pay_valid(e_wr_pay_v), .wr_pay_ready(e_wr_pay_r), .wr_pay_data(e_wr_pay_d), .wr_pay_last(e_wr_pay_l),
    .wr_um_valid(e_wr_um_v), .wr_um_ready(e_wr_um_r), .wr_um_data(e_wr_um_d),
    .wr_raw_valid(e_wr_raw_v), .wr_raw_ready(e_wr_raw_r), .wr_raw_data(e_wr_raw_d), .wr_raw_last(e_wr_raw_l),
    .rd_raw_valid(e_rd_raw_v), .rd_raw_ready(e_rd_raw_r), .rd_raw_data(e_rd_raw_d), .rd_raw_last(e_rd_raw_l),
    .rd_pay_valid(e_rd_pay_v), .rd_pay_ready(e_rd_pay_r), .rd_pay_data(e_rd_pay_d), .rd_pay_last(e_rd_pay_l),
    .rd_um_valid(e_rd_um_v), .rd_um_ready(e_rd_um_r), .rd_um_data(e_rd_um_d),
    .rd_sst_valid(e_sst_v), .rd_sst_ready(e_sst_r), .rd_sst_code(e_sst_code), .rd_sst_nerr(e_sst_nerr),
    .rd_sst_aux(e_sst_aux), .rd_sst_sector(e_sst_sec), .rd_sst_crc_ok(e_crc_ok),
    .rd_pst_valid(e_pst_v), .rd_pst_ready(e_pst_r), .rd_pst_n_corr(e_pn_corr), .rd_pst_n_uncorr(e_pn_unc),
    .rd_pst_n_integ(e_pn_int), .rd_pst_n_erased(e_pn_era), .rd_pst_max_flips(e_pmax), .rd_pst_tot_flips(e_ptot),
    .rd_pst_all_erased(e_pst_alle), .rd_pst_bbm(e_pbbm), .rd_pst_ok(e_pst_ok), .rd_pst_scrub(e_pst_scrub),
    .rd_pst_frame_err(e_pst_ferr),
    .ev_corrected(ecc_ev_corrected_o), .ev_uncorr(ecc_ev_uncorr_o), .ev_integrity(ecc_ev_integrity_o),
    .ev_scrub(ecc_ev_scrub_o), .irq(e_irq), .enc_busy(e_ebusy), .dec_busy(e_dbusy));

  // ---------------------------------------------------------------- protected data path
  sfsec_pipeline #(.DU_BYTES(DU_BYTES), .PAGE_DATA(PAGE_DATA), .PAGE_SPARE(PAGE_SPARE), .WD_RD(WD_RD)) u_pipe (
    .clk, .rst_n, .flush_i, .zeroize_i(dp_zero), .cmd_valid_i, .cmd_ready_o, .cmd_op_i, .cmd_tag_i, .cmd_lba_i, .cmd_ppa_i,
    .cmd_seq_i, .cmd_slot_i, .pol_data_en_i, .pol_auth_en_i, .pol_auth_req_i, .pol_scr_en_i, .pol_wd_host_i,
    .ks_slot_o(ks_slot), .ks_valid_i(ks_valid), .ks_gen_i(ks_gen), .ks_k256_i(ks_k256), .ks_k1_i(ks_k1),
    .ks_k2_i(ks_k2), .ks_kmac_i(ks_kmac), .ks_epoch_i(epoch_o),
    .hw_valid_i, .hw_ready_o, .hw_data_i, .hw_err_i, .hw_poison_i, .dma_err_i,
    .hr_valid_o, .hr_ready_i, .hr_data_o, .hr_last_o,
    .rsp_valid_o, .rsp_ready_i, .rsp_op_o, .rsp_tag_o, .rsp_err_o, .rsp_info_o, .busy_o(pipe_busy_o),
    .ecc_wr_pay_valid_o(e_wr_pay_v), .ecc_wr_pay_ready_i(e_wr_pay_r), .ecc_wr_pay_data_o(e_wr_pay_d),
    .ecc_wr_pay_last_o(e_wr_pay_l), .ecc_wr_um_valid_o(e_wr_um_v), .ecc_wr_um_ready_i(e_wr_um_r),
    .ecc_wr_um_data_o(e_wr_um_d), .ecc_wr_raw_valid_i(e_wr_raw_v), .ecc_wr_raw_ready_o(e_wr_raw_r),
    .ecc_wr_raw_data_i(e_wr_raw_d), .ecc_wr_raw_last_i(e_wr_raw_l),
    .ecc_rd_raw_valid_o(e_rd_raw_v), .ecc_rd_raw_ready_i(e_rd_raw_r), .ecc_rd_raw_data_o(e_rd_raw_d),
    .ecc_rd_raw_last_o(e_rd_raw_l), .ecc_rd_pay_valid_i(e_rd_pay_v), .ecc_rd_pay_ready_o(e_rd_pay_r),
    .ecc_rd_pay_data_i(e_rd_pay_d), .ecc_rd_pay_last_i(e_rd_pay_l), .ecc_rd_um_valid_i(e_rd_um_v),
    .ecc_rd_um_ready_o(e_rd_um_r), .ecc_rd_um_data_i(e_rd_um_d),
    .ecc_rd_sst_valid_i(e_sst_v), .ecc_rd_sst_ready_o(e_sst_r), .ecc_rd_sst_code_i(e_sst_code),
    .ecc_rd_sst_nerr_i(e_sst_nerr), .ecc_rd_pst_valid_i(e_pst_v), .ecc_rd_pst_ready_o(e_pst_r),
    .ecc_rd_pst_n_corr_i(e_pn_corr), .ecc_rd_pst_n_uncorr_i(e_pn_unc), .ecc_rd_pst_n_integ_i(e_pn_int),
    .ecc_rd_pst_max_flips_i(e_pmax), .ecc_rd_pst_tot_flips_i(e_ptot), .ecc_rd_pst_all_erased_i(e_pst_alle),
    .ecc_rd_pst_ok_i(e_pst_ok), .ecc_rd_pst_scrub_i(e_pst_scrub), .ecc_rd_pst_frame_err_i(e_pst_ferr),
    .ecc_flush_o(e_flush),
    .nand_cmd_valid_o, .nand_cmd_ready_i, .nand_cmd_read_o, .nand_cmd_ppa_o, .nand_wd_valid_o, .nand_wd_ready_i,
    .nand_wd_data_o, .nand_wd_last_o, .nand_rd_valid_i, .nand_rd_ready_o, .nand_rd_data_i, .nand_rd_last_i,
    .nand_abort_o, .nand_done_valid_i, .nand_done_fail_i,
    .cm_start_o(pl_cm_start), .cm_key_o(pl_cm_key), .cm_key256_o(pl_cm_k256), .cm_len_o(pl_cm_len),
    .cm_msg_o(pl_cm_msg), .cm_busy_i(cm_busy), .cm_done_i(cm_done), .cm_tag_i(cm_tag),
    .tel_pst_o, .tel_flips_o, .tel_maxflips_o, .tel_ncorr_o, .tel_scrub_o, .tel_dma_o);

  // ---------------------------------------------------------------- firmware record-guard service
  assign rg_busy_o = fg_busy_w;
  assign rg_key_valid_o = fg_kvalid;
  sfsec_rec_guard u_fguard (.clk, .rst_n, .zeroize_i(dp_zero), .req_valid_i(rg_valid_i), .req_ready_o(rg_ready_o),
    .busy_o(fg_busy_w), .req_verify_i(rg_verify_i), .req_cls_i(rg_cls_i), .req_len_i(rg_len_i),
    .req_body_i(rg_body_i), .req_ctx_i(rg_ctx_i), .req_crc_i(rg_crc_i), .req_tag_i(rg_tag_i),
    .req_auth_i(rg_auth_i), .req_kmac_i(fg_kmac), .rsp_valid_o(rg_rsp_valid_o), .rsp_crc_o(rg_crc_o),
    .rsp_tag_o(rg_tag_o), .rsp_crc_ok_o(rg_crc_ok_o), .rsp_tag_ok_o(rg_tag_ok_o), .rsp_err_o(rg_err_o),
    .cm_start_o(fg_cm_start), .cm_key_o(fg_cm_key), .cm_key256_o(fg_cm_k256), .cm_len_o(fg_cm_len),
    .cm_msg_o(fg_cm_msg), .cm_busy_i(cm_busy), .cm_done_i(cm_done), .cm_tag_i(cm_tag));
endmodule

`default_nettype wire
