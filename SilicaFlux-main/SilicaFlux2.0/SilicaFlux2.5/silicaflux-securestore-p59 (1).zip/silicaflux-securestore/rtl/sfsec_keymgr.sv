// =============================================================================
// SilicaFlux SecureStore :: sfsec_keymgr -- key slots, key hierarchy, invalidation
//
// Key hierarchy (docs/05):
//   PLATFORM ROOT KEY (PRK, 256 bit, provided by the platform key store through `prk_i` -- NOT stored here)
//        |  NIST SP 800-108 counter-mode KDF, PRF = AES-CMAC, context = slot || generation || salt
//        v
//   per-slot keys:  K_xts = K1 || K2 (XTS-AES-128: 2x128 bit, XTS-AES-256: 2x256 bit)   and   K_mac (128 bit)
//   `salt` (128 bit) comes from the platform entropy source (`ent_*`, a vetted DRBG/TRNG is required: none is
//   provided here) at GENERATE time, or is supplied by firmware at DERIVE time (restore after a power cycle).
// Operations (all refused with an explicit error code, never silently):
//   IMPORT      clear key injection with an explicit generation >= the slot's current one (lifecycle-gated by
//               the caller; lets standard vectors be loaded)
//   GENERATE    fresh salt from the entropy port -> derive keys           (crypto-erase = INVALIDATE + GENERATE)
//   DERIVE      salt + generation supplied by firmware -> same keys again (restore)
//   INVALIDATE  zeroise the slot's keys and salt, bump the generation, mark the slot invalid
// A key set is installed only if K1 != K2 (SP 800-38E).  The slot generation increments on every install /
// invalidate and is recorded in every page's physical metadata (explicit stale-key detection).
// *** The key registers are ordinary flip-flops.  This block is NOT tamper-resistant key storage and makes no
// *** eFuse / OTP / secure-NVM claim (docs/09).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfsec_keymgr
  import sfsec_pkg::*;
#(
  parameter int NS = 4,
  parameter int ENT_TIMEOUT = 4096
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  zeroize_i,        // secure reset: wipe every slot
  // command
  input  wire logic                  cmd_valid_i,
  input  wire logic [2:0]            cmd_op_i,         // 1 IMPORT 2 GENERATE 3 DERIVE 4 INVALIDATE
  input  wire logic [1:0]            cmd_slot_i,
  input  wire logic                  cmd_k256_i,
  input  wire logic [255:0]          stg_k1_i,
  input  wire logic [255:0]          stg_k2_i,
  input  wire logic [127:0]          stg_kmac_i,
  input  wire logic [127:0]          stg_salt_i,
  input  wire logic [7:0]            stg_gen_i,
  // platform
  input  wire logic                  prk_valid_i,
  input  wire logic [255:0]          prk_i,
  output logic                       ent_req_o,
  input  wire logic                  ent_valid_i,
  input  wire logic [127:0]          ent_data_i,
  // result
  output logic                       busy_o,
  output logic                       done_o,           // pulse
  output logic [7:0]                 err_o,            // valid with done_o (E_NONE = success)
  output logic                       kill_o,           // pulse: key material destroyed (zeroise datapath copies)
  // per-slot state
  output logic [NS-1:0]              slot_valid_o,
  output logic [NS-1:0]              slot_k256_o,
  output logic [NS-1:0]              slot_origin_o,    // 1: derived from PRK, 0: imported
  output logic [8*NS-1:0]            slot_gen_o,
  output logic [128*NS-1:0]          slot_salt_o,
  output logic [15:0]                epoch_o,
  // key selection for the data path
  input  wire logic [1:0]            sel_slot_i,
  output logic                       sel_valid_o,
  output logic [7:0]                 sel_gen_o,
  output logic                       sel_k256_o,
  output logic [255:0]               sel_k1_o,
  output logic [255:0]               sel_k2_o,
  output logic [127:0]               sel_kmac_o,
  // second read port: K_mac of any slot (firmware record-guard service)
  input  wire logic [1:0]            sel2_slot_i,
  output logic                       sel2_valid_o,
  output logic [127:0]               sel2_kmac_o,
  // CMAC client (KDF)
  output logic                       cm_start_o,
  output logic [255:0]               cm_key_o,
  output logic                       cm_key256_o,
  output logic [6:0]                 cm_len_o,
  output logic [511:0]               cm_msg_o,
  input  wire logic                  cm_busy_i,
  input  wire logic                  cm_done_i,
  input  wire logic [127:0]          cm_tag_i
);
  localparam logic [2:0] OP_IMPORT = 3'd1, OP_GENERATE = 3'd2, OP_DERIVE = 3'd3, OP_INVAL = 3'd4;
  localparam logic [71:0] LBL_XTS = {8'h53, 8'h46, 8'h53, 8'h45, 8'h43, 8'h2d, 8'h58, 8'h54, 8'h53};  // "SFSEC-XTS"
  localparam logic [71:0] LBL_MAC = {8'h53, 8'h46, 8'h53, 8'h45, 8'h43, 8'h2d, 8'h4d, 8'h41, 8'h43};  // "SFSEC-MAC"

  // ---------------------------------------------------------------- slot storage
  logic [255:0] k1_q   [NS];
  logic [255:0] k2_q   [NS];
  logic [127:0] km_q   [NS];
  logic [127:0] salt_q [NS];
  logic [7:0]   gen_q  [NS];
  logic         val_q  [NS];
  logic         k256_q [NS];
  logic         org_q  [NS];
  logic [15:0]  epoch_q;

  always_comb begin
    for (int s = 0; s < NS; s++) begin
      slot_valid_o[s]  = val_q[s];
      slot_k256_o[s]   = k256_q[s];
      slot_origin_o[s] = org_q[s];
      slot_gen_o[8*s +: 8]     = gen_q[s];
      slot_salt_o[128*s +: 128] = salt_q[s];
    end
  end
  assign epoch_o     = epoch_q;
  assign sel_valid_o = val_q[sel_slot_i];
  assign sel_gen_o   = gen_q[sel_slot_i];
  assign sel_k256_o  = k256_q[sel_slot_i];
  assign sel_k1_o    = k1_q[sel_slot_i];
  assign sel_k2_o    = k2_q[sel_slot_i];
  assign sel_kmac_o  = km_q[sel_slot_i];
  assign sel2_valid_o = val_q[sel2_slot_i];
  assign sel2_kmac_o  = km_q[sel2_slot_i];

  // ---------------------------------------------------------------- KDF
  logic         kd_start, kd_busy, kd_done;
  logic [479:0] kd_fixed;
  logic [9:0]   kd_l;
  logic [511:0] kd_ko;
  logic [255:0] prk_q;
  sfsec_kdf u_kdf (.clk(clk), .rst_n(rst_n), .start_i(kd_start), .ki_i(prk_q), .ki256_i(1'b1), .fixed_i(kd_fixed),
    .fixed_len_i(6'd32), .l_bits_i(kd_l), .busy_o(kd_busy), .done_o(kd_done), .ko_o(kd_ko),
    .cm_start_o(cm_start_o), .cm_key_o(cm_key_o), .cm_key256_o(cm_key256_o), .cm_len_o(cm_len_o),
    .cm_msg_o(cm_msg_o), .cm_busy_i(cm_busy_i), .cm_done_i(cm_done_i), .cm_tag_i(cm_tag_i));

  // ---------------------------------------------------------------- FSM
  typedef enum logic [3:0] { M_IDLE, M_ENT, M_KX, M_KXW, M_KM, M_KMW, M_INST, M_DONE } mstate_t;
  mstate_t st;
  logic [2:0]   op_q;
  logic [1:0]   slot_q;
  logic         k256c_q;
  logic [127:0] salt_c_q;
  logic [7:0]   gen_c_q;
  logic [511:0] kx_q;
  logic [127:0] kmc_q;
  logic [255:0] k1c_q, k2c_q;
  logic [7:0]   err_q;
  logic [15:0]  tmo_q;

  function automatic logic [479:0] fixed_of(input logic [71:0] lbl, input logic [1:0] slot,
                                            input logic [7:0] gen, input logic [127:0] salt, input logic [9:0] l);
    logic [479:0] f;
    f = '0;
    f[479 -: 72] = lbl;
    f[407 -: 8]  = 8'h00;
    f[399 -: 8]  = {6'b0, slot};
    f[391 -: 8]  = gen;
    f[383 -: 128] = salt;
    f[255 -: 32] = {22'b0, l};
    return f;
  endfunction

  logic [9:0] lx;
  assign lx = k256c_q ? 10'd512 : 10'd256;
  assign kd_fixed = (st == M_KX || st == M_KXW) ? fixed_of(LBL_XTS, slot_q, gen_c_q, salt_c_q, lx)
                                                 : fixed_of(LBL_MAC, slot_q, gen_c_q, salt_c_q, 10'd128);
  assign kd_l     = (st == M_KX || st == M_KXW) ? lx : 10'd128;
  assign kd_start = ((st == M_KX) || (st == M_KM)) && !kd_busy;
  assign ent_req_o = (st == M_ENT);

  logic eq_c;
  assign eq_c = k256c_q ? (k1c_q == k2c_q) : (k1c_q[255:128] == k2c_q[255:128]);

  task automatic wipe_slot(input int s);
    k1_q[s] <= '0; k2_q[s] <= '0; km_q[s] <= '0; salt_q[s] <= '0; val_q[s] <= 1'b0; org_q[s] <= 1'b0;
  endtask

  assign busy_o = (st != M_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int s = 0; s < NS; s++) begin
        k1_q[s] <= '0; k2_q[s] <= '0; km_q[s] <= '0; salt_q[s] <= '0; gen_q[s] <= '0; val_q[s] <= 1'b0;
        k256_q[s] <= 1'b0; org_q[s] <= 1'b0;
      end
      epoch_q <= '0; st <= M_IDLE; op_q <= '0; slot_q <= '0; k256c_q <= 1'b0; salt_c_q <= '0; gen_c_q <= '0;
      kx_q <= '0; kmc_q <= '0; k1c_q <= '0; k2c_q <= '0; err_q <= '0; tmo_q <= '0; prk_q <= '0;
      done_o <= 1'b0; err_o <= E_NONE; kill_o <= 1'b0;
    end else begin
      done_o <= 1'b0; kill_o <= 1'b0;
      if (zeroize_i) begin
        for (int s = 0; s < NS; s++) begin wipe_slot(s); gen_q[s] <= gen_q[s] + 8'd1; end
        epoch_q <= epoch_q + 16'd1; st <= M_IDLE; prk_q <= '0; kx_q <= '0; kmc_q <= '0; k1c_q <= '0; k2c_q <= '0;
        salt_c_q <= '0; kill_o <= 1'b1;
      end else begin
        case (st)
          M_IDLE: if (cmd_valid_i) begin
            op_q <= cmd_op_i; slot_q <= cmd_slot_i; k256c_q <= cmd_k256_i; err_q <= E_NONE;
            case (cmd_op_i)
              OP_IMPORT: begin
                k1c_q <= stg_k1_i; k2c_q <= stg_k2_i; kmc_q <= stg_kmac_i; salt_c_q <= '0;
                gen_c_q <= stg_gen_i;
                if (stg_gen_i < gen_q[cmd_slot_i]) begin err_q <= E_RANGE; st <= M_DONE; end   // never roll a slot back
                else st <= M_INST;
              end
              OP_GENERATE, OP_DERIVE: begin
                if (!prk_valid_i) begin err_q <= E_PRK; st <= M_DONE; end
                else begin
                  prk_q <= prk_i;
                  if (cmd_op_i == OP_GENERATE) begin
                    gen_c_q <= gen_q[cmd_slot_i] + 8'd1; tmo_q <= '0; st <= M_ENT;
                  end else begin
                    gen_c_q <= stg_gen_i; salt_c_q <= stg_salt_i;
                    if (stg_gen_i < gen_q[cmd_slot_i]) begin err_q <= E_RANGE; st <= M_DONE; end
                    else st <= M_KX;
                  end
                end
              end
              OP_INVAL: begin
                wipe_slot(int'(cmd_slot_i));
                gen_q[cmd_slot_i] <= gen_q[cmd_slot_i] + 8'd1;
                epoch_q <= epoch_q + 16'd1; kill_o <= 1'b1;
                st <= M_DONE;
              end
              default: begin err_q <= E_RANGE; st <= M_DONE; end
            endcase
          end
          M_ENT: begin
            tmo_q <= tmo_q + 16'd1;
            if (ent_valid_i) begin salt_c_q <= ent_data_i; st <= M_KX; end
            else if (tmo_q >= ENT_TIMEOUT[15:0]) begin err_q <= E_ENT; st <= M_DONE; end
          end
          M_KX:  if (!kd_busy) st <= M_KXW;                 // kd_start asserted this cycle
          M_KXW: if (kd_done) begin kx_q <= kd_ko; st <= M_KM; end
          M_KM:  if (!kd_busy) st <= M_KMW;                 // kd_start asserted this cycle
          M_KMW: if (kd_done) begin
                   kmc_q <= kd_ko[511 -: 128];
                   if (k256c_q) begin k1c_q <= kx_q[511 -: 256]; k2c_q <= kx_q[255:0]; end
                   else begin k1c_q <= {kx_q[511 -: 128], 128'b0}; k2c_q <= {kx_q[383 -: 128], 128'b0}; end
                   st <= M_INST;
                 end
          M_INST: begin
            if (eq_c) begin err_q <= E_KEY_EQ; st <= M_DONE; end
            else begin
              k1_q[slot_q] <= k1c_q; k2_q[slot_q] <= k2c_q; km_q[slot_q] <= kmc_q; salt_q[slot_q] <= salt_c_q;
              gen_q[slot_q] <= gen_c_q; val_q[slot_q] <= 1'b1; k256_q[slot_q] <= k256c_q;
              org_q[slot_q] <= (op_q != OP_IMPORT);
              epoch_q <= epoch_q + 16'd1;
              prk_q <= '0; kx_q <= '0; k1c_q <= '0; k2c_q <= '0; kmc_q <= '0;
              st <= M_DONE;
            end
          end
          M_DONE: begin done_o <= 1'b1; err_o <= err_q; prk_q <= '0; st <= M_IDLE; end
          default: st <= M_IDLE;
        endcase
      end
    end
  end
endmodule

`default_nettype wire
