// =============================================================================
// SilicaFlux SecureStore :: sfsec_pipeline -- the protected data path (write and read), one data unit in flight
//
//  WRITE   host words (32 b) -> [DIM: CRC-32C guard + LBA ref tag, appended as the 33rd block] -> AES-XTS encrypt
//          (tweak = LBA) -> ECC encode (P54 BCH page codec; PMD record rides in the ECC user-metadata field)
//          -> [optional NAND randomiser] -> NAND program stream
//  READ    NAND raw page (spare first) -> [de-randomiser] -> ECC decode/correct (P54) -> ciphertext buffer
//          -> pre-checks (ECC verdict, PMD format / CRC-32C / CMAC, LBA + key binding) -> AES-XTS decrypt (in place)
//          -> DIM checks (guard CRC-32C, reference tag, format) -> host.   The plaintext is released to the host
//          ONLY if every check passed; on any error no payload leaves the block (the buffer is cleared).
//
//  Metadata association (docs/02): every stage is keyed by the same command record {tag, lba, ppa, seq, slot};
//  the PMD (slot, key generation, LBA, seq, class-separated CRC-32C [+ CMAC-64 bound to ppa]) travels with the
//  page; the DIM (guard, LBA) travels INSIDE the XTS data unit (encrypted, so a plaintext CRC is never stored).
//  CRC = accidental corruption only.  XTS = confidentiality only.  Authenticity of metadata = CMAC (when enabled).
//
//  Error model: every failure ends in the single error path S_ERR (abort XTS, reset ECC, cancel NAND, clear
//  buffers) and produces exactly one response with an explicit error code (sfsec_pkg::E_*).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfsec_pipeline
  import sfsec_pkg::*;
#(
  parameter int DU_BYTES   = 512,
  parameter int PAGE_DATA  = 528,
  parameter int PAGE_SPARE = 48,
  parameter int WD_RD      = 200000      // read watchdog (cycles waiting for NAND / ECC)
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         flush_i,        // controller / secure reset request: abort the command (E_RESET)
  input  wire logic         zeroize_i,      // wipe datapath key material
  // ---- command
  input  wire logic         cmd_valid_i,
  output logic              cmd_ready_o,
  input  wire logic         cmd_op_i,       // 0 write, 1 read
  input  wire logic [7:0]   cmd_tag_i,
  input  wire logic [63:0]  cmd_lba_i,
  input  wire logic [31:0]  cmd_ppa_i,
  input  wire logic [47:0]  cmd_seq_i,
  input  wire logic [1:0]   cmd_slot_i,
  // ---- policy (from the lifecycle / control registers)
  input  wire logic         pol_data_en_i,
  input  wire logic         pol_auth_en_i,   // write: seal PMD with CMAC-64
  input  wire logic         pol_auth_req_i,  // read: PMD tag mandatory (downgrade protection)
  input  wire logic         pol_scr_en_i,    // NAND randomiser
  input  wire logic [31:0]  pol_wd_host_i,   // host data watchdog (cycles, 0 = off)
  // ---- key selection
  output logic [1:0]        ks_slot_o,
  input  wire logic         ks_valid_i,
  input  wire logic [7:0]   ks_gen_i,
  input  wire logic         ks_k256_i,
  input  wire logic [255:0] ks_k1_i,
  input  wire logic [255:0] ks_k2_i,
  input  wire logic [127:0] ks_kmac_i,
  input  wire logic [15:0]  ks_epoch_i,
  // ---- host write data
  input  wire logic         hw_valid_i,
  output logic              hw_ready_o,
  input  wire logic [31:0]  hw_data_i,
  input  wire logic         hw_err_i,        // DMA / bus fault flagged on this beat
  input  wire logic         hw_poison_i,     // known-corrupt data flagged on this beat
  input  wire logic         dma_err_i,       // asynchronous DMA fault pulse
  // ---- host read data
  output logic              hr_valid_o,
  input  wire logic         hr_ready_i,
  output logic [31:0]       hr_data_o,
  output logic              hr_last_o,
  // ---- response
  output logic              rsp_valid_o,
  input  wire logic         rsp_ready_i,
  output logic              rsp_op_o,
  output logic [7:0]        rsp_tag_o,
  output logic [7:0]        rsp_err_o,
  output logic [31:0]       rsp_info_o,
  output logic              busy_o,
  // ---- ECC engine (P54) program path
  output logic              ecc_wr_pay_valid_o,
  input  wire logic         ecc_wr_pay_ready_i,
  output logic [7:0]        ecc_wr_pay_data_o,
  output logic              ecc_wr_pay_last_o,
  output logic              ecc_wr_um_valid_o,
  input  wire logic         ecc_wr_um_ready_i,
  output logic [7:0]        ecc_wr_um_data_o,
  input  wire logic         ecc_wr_raw_valid_i,
  output logic              ecc_wr_raw_ready_o,
  input  wire logic [7:0]   ecc_wr_raw_data_i,
  input  wire logic         ecc_wr_raw_last_i,
  // ---- ECC engine read path
  output logic              ecc_rd_raw_valid_o,
  input  wire logic         ecc_rd_raw_ready_i,
  output logic [7:0]        ecc_rd_raw_data_o,
  output logic              ecc_rd_raw_last_o,
  input  wire logic         ecc_rd_pay_valid_i,
  output logic              ecc_rd_pay_ready_o,
  input  wire logic [7:0]   ecc_rd_pay_data_i,
  input  wire logic         ecc_rd_pay_last_i,
  input  wire logic         ecc_rd_um_valid_i,
  output logic              ecc_rd_um_ready_o,
  input  wire logic [7:0]   ecc_rd_um_data_i,
  input  wire logic         ecc_rd_sst_valid_i,
  output logic              ecc_rd_sst_ready_o,
  input  wire logic [2:0]   ecc_rd_sst_code_i,
  input  wire logic [7:0]   ecc_rd_sst_nerr_i,
  input  wire logic         ecc_rd_pst_valid_i,
  output logic              ecc_rd_pst_ready_o,
  input  wire logic [7:0]   ecc_rd_pst_n_corr_i,
  input  wire logic [7:0]   ecc_rd_pst_n_uncorr_i,
  input  wire logic [7:0]   ecc_rd_pst_n_integ_i,
  input  wire logic [7:0]   ecc_rd_pst_max_flips_i,
  input  wire logic [15:0]  ecc_rd_pst_tot_flips_i,
  input  wire logic         ecc_rd_pst_all_erased_i,
  input  wire logic         ecc_rd_pst_ok_i,
  input  wire logic         ecc_rd_pst_scrub_i,
  input  wire logic         ecc_rd_pst_frame_err_i,
  output logic              ecc_flush_o,     // reset the ECC engine (abort / recovery)
  // ---- NAND raw-page channel
  output logic              nand_cmd_valid_o,
  input  wire logic         nand_cmd_ready_i,
  output logic              nand_cmd_read_o,
  output logic [31:0]       nand_cmd_ppa_o,
  output logic              nand_wd_valid_o,
  input  wire logic         nand_wd_ready_i,
  output logic [7:0]        nand_wd_data_o,
  output logic              nand_wd_last_o,
  input  wire logic         nand_rd_valid_i,
  output logic              nand_rd_ready_o,
  input  wire logic [7:0]   nand_rd_data_i,
  input  wire logic         nand_rd_last_i,
  output logic              nand_abort_o,
  input  wire logic         nand_done_valid_i,
  input  wire logic         nand_done_fail_i,
  // ---- CMAC client (record guard)
  output logic              cm_start_o,
  output logic [255:0]      cm_key_o,
  output logic              cm_key256_o,
  output logic [6:0]        cm_len_o,
  output logic [511:0]      cm_msg_o,
  input  wire logic         cm_busy_i,
  input  wire logic         cm_done_i,
  input  wire logic [127:0] cm_tag_i,
  // ---- telemetry pulses
  output logic              tel_pst_o,       // an ECC page status was received
  output logic [15:0]       tel_flips_o,
  output logic [7:0]        tel_maxflips_o,
  output logic [7:0]        tel_ncorr_o,
  output logic              tel_scrub_o,
  output logic              tel_dma_o        // DMA fault observed by the pipeline
);
  localparam int NBLK_PAY = DU_BYTES / 16;          // payload blocks
  localparam int NBLK     = NBLK_PAY + 1;           // + DIM block
  localparam int NWORD    = DU_BYTES / 4;
  localparam int RAW      = PAGE_DATA + PAGE_SPARE;
  localparam logic [2:0] SS_UNCORR = 3'd3, SS_INTEG = 3'd4;

  // ---------------------------------------------------------------- state
  typedef enum logic [5:0] {
    S_IDLE, S_VAL, S_KLOAD, S_KLOADW,
    S_W_PMD, S_W_PMDW, S_W_START, S_W_IN, S_W_DIM, S_W_XIN, S_W_XOUT, S_W_DRAIN,
    S_R_CMD, S_R_RX, S_R_PRE, S_R_PMD, S_R_PMDW, S_R_BIND, S_R_DSTART, S_R_DXIN, S_R_DXOUT, S_R_CRC, S_R_VER,
    S_R_OUT,
    S_ERR, S_ERRW, S_RSP
  } state_t;
  state_t st;

  logic         op_q;
  logic [7:0]   tag_q;
  logic [63:0]  lba_q;
  logic [31:0]  ppa_q;
  logic [47:0]  seq_q;
  logic [1:0]   slot_q;
  logic [7:0]   err_q;
  logic [31:0]  info_q;
  logic [6:0]   blk_q;
  logic [1:0]   word_q;
  logic [127:0] acc_q;
  logic [127:0] ct_q;
  logic [255:0] pmd_q;
  logic [5:0]   um_idx_q;
  logic [9:0]   raw_cnt_q;
  logic         xs_done_q, nc_done_q;
  logic         nand_active_q, nand_done_q, nand_fail_q, raw_done_q;
  logic [3:0]   fl_q;                 // flush hold counter
  logic [31:0]  wd_q;
  logic         xts_loaded_q;
  logic [1:0]   slot_loaded_q;
  logic [15:0]  epoch_loaded_q;

  assign busy_o      = (st != S_IDLE);
  assign cmd_ready_o = (st == S_IDLE) && (fl_q == 4'd0);
  assign ks_slot_o   = (st == S_IDLE) ? cmd_slot_i : slot_q;

  // ---------------------------------------------------------------- XTS engine
  logic         x_kload, x_kidle, x_kok, x_keq, x_start, x_dec, x_ready, x_lenerr, x_abort;
  logic [127:0] x_tweak;
  logic [20:0]  x_nblk;
  logic         xs_valid, xs_ready, xm_valid, xm_ready, xm_last, x_busy;
  logic [127:0] xs_data, xm_data;
  logic         x_zero;

  sfsec_xts_engine u_xts (.clk, .rst_n, .zeroize_i(x_zero), .key_load_i(x_kload), .key1_i(ks_k1_i),
    .key2_i(ks_k2_i), .key256_i(ks_k256_i), .key_idle_o(x_kidle), .key_ok_o(x_kok), .key_eq_o(x_keq),
    .du_start_i(x_start), .du_dec_i(x_dec), .du_tweak_i(x_tweak), .du_nblk_i(x_nblk), .du_ready_o(x_ready),
    .du_len_err_o(x_lenerr), .abort_i(x_abort), .s_valid_i(xs_valid), .s_ready_o(xs_ready), .s_data_i(xs_data),
    .m_valid_o(xm_valid), .m_ready_i(xm_ready), .m_data_o(xm_data), .m_last_o(xm_last), .busy_o(x_busy));
  assign x_zero  = zeroize_i;
  assign x_tweak = {bswap64(lba_q), 64'h0};      // 16 tweak bytes: the LBA as a little-endian 128-bit integer

  // ---------------------------------------------------------------- record guard (PMD)
  logic         g_req, g_ready, g_verify, g_auth, g_rsp, g_crc_ok, g_tag_ok, g_err;
  logic [255:0] g_body;
  logic [31:0]  g_crc_in, g_crc_out;
  logic [63:0]  g_tag_in, g_tag_out;
  sfsec_rec_guard u_guard (.clk, .rst_n, .zeroize_i, .req_valid_i(g_req), .req_ready_o(g_ready), .busy_o(),
    .req_verify_i(g_verify), .req_cls_i(CLS_PMD), .req_len_i(6'd20), .req_body_i(g_body), .req_ctx_i({32'h0, ppa_q}),
    .req_crc_i(g_crc_in), .req_tag_i(g_tag_in), .req_auth_i(g_auth), .req_kmac_i(ks_kmac_i),
    .rsp_valid_o(g_rsp), .rsp_crc_o(g_crc_out), .rsp_tag_o(g_tag_out), .rsp_crc_ok_o(g_crc_ok),
    .rsp_tag_ok_o(g_tag_ok), .rsp_err_o(g_err),
    .cm_start_o, .cm_key_o, .cm_key256_o, .cm_len_o, .cm_msg_o, .cm_busy_i, .cm_done_i, .cm_tag_i);

  // PMD body (20 bytes) for the write path
  logic [7:0]   pmd_flags_w;
  logic [159:0] pmd_body_w;
  assign pmd_flags_w = FL_ENC | (pol_auth_en_i ? FL_AUTH : 8'h00);
  assign pmd_body_w  = {PMD_MAGIC, pmd_flags_w, {6'b0, slot_q}, ks_gen_i, bswap64(lba_q), bswap48(seq_q), 16'h0000};

  // PMD parsed from the read path (byte i of the record at [255-8i -: 8])
  logic [7:0]   rx_magic, rx_flags, rx_slot, rx_gen;
  logic [63:0]  rx_lba;
  logic [15:0]  rx_rsvd;
  logic [31:0]  rx_crc;
  logic [63:0]  rx_tag;
  logic [255:0] pmdrx_q;
  assign rx_magic = pmdrx_q[255 -: 8];
  assign rx_flags = pmdrx_q[247 -: 8];
  assign rx_slot  = pmdrx_q[239 -: 8];
  assign rx_gen   = pmdrx_q[231 -: 8];
  assign rx_lba   = bswap64(pmdrx_q[223 -: 64]);
  assign rx_rsvd  = pmdrx_q[255-18*8 -: 16];
  assign rx_crc   = {pmdrx_q[255-23*8 -: 8], pmdrx_q[255-22*8 -: 8], pmdrx_q[255-21*8 -: 8], pmdrx_q[255-20*8 -: 8]};
  assign rx_tag   = pmdrx_q[63:0];

  // ---------------------------------------------------------------- DIM guard CRC (data path)
  logic        c_clr, c_en;
  logic [31:0] c_data, c_crc;
  sfsec_crc u_dcrc (.clk, .rst_n, .clr(c_clr), .mode_i(2'd0), .en(c_en), .data_i(c_data), .nbytes_i(3'd4),
                    .crc_o(c_crc));

  // ---------------------------------------------------------------- read buffer (ciphertext in, plaintext out)
  logic [127:0] rbuf [NBLK];
  logic [9:0]   rx_pay_cnt_q;
  logic [5:0]   rx_um_cnt_q;
  logic         pay_done_q, um_done_q, sst_seen_q, pst_seen_q;
  logic [2:0]   sst_code_q;
  logic [7:0]   sst_nerr_q;
  logic [15:0]  pst_flips_q;
  logic [7:0]   pst_max_q, pst_ncorr_q;
  logic         pst_erased_q, pst_scrub_q, pst_ferr_q, pst_ok_q;
  logic [9:0]   rd_cnt_q;             // raw bytes received from NAND (stream index)
  logic [6:0]   wordidx_q;            // read-side word index

  // ---------------------------------------------------------------- write-side serializer to the ECC encoder
  logic [4:0]   ser_cnt_q;
  logic [3:0]   ser_idx_q;
  logic         ser_last_q;
  logic         ser_idle;
  assign ser_idle = (ser_cnt_q == 5'd0);

  logic wr_phase, rd_phase;
  assign wr_phase = (st >= S_W_START) && (st <= S_W_DRAIN);
  assign rd_phase = (st >= S_R_CMD) && (st <= S_R_RX);

  assign ecc_wr_pay_valid_o = wr_phase && !ser_idle;
  assign ecc_wr_pay_data_o  = ct_q[127 - 8*ser_idx_q -: 8];
  assign ecc_wr_pay_last_o  = ser_last_q && (ser_cnt_q == 5'd1);
  assign ecc_wr_um_valid_o  = wr_phase && (um_idx_q < 6'd32);
  assign ecc_wr_um_data_o   = pmd_q[255 - 8*um_idx_q -: 8];

  // ECC raw -> randomiser -> NAND (write); NAND -> de-randomiser -> ECC (read)
  logic [15:0] col_w, col_r;
  logic [7:0]  ks_w, ks_r;
  assign col_w = {6'b0, raw_cnt_q};
  assign col_r = (32'(rd_cnt_q) < PAGE_SPARE) ? 16'(PAGE_DATA + 32'(rd_cnt_q)) : 16'(32'(rd_cnt_q) - PAGE_SPARE);
  assign ks_w  = pol_scr_en_i ? scr_ks(ppa_q, col_w) : 8'h00;
  assign ks_r  = pol_scr_en_i ? scr_ks(ppa_q, col_r) : 8'h00;

  assign nand_wd_valid_o    = wr_phase && nand_active_q && ecc_wr_raw_valid_i;
  assign nand_wd_data_o     = ecc_wr_raw_data_i ^ ks_w;
  assign nand_wd_last_o     = ecc_wr_raw_last_i;
  assign ecc_wr_raw_ready_o = wr_phase && nand_active_q && nand_wd_ready_i;

  assign ecc_rd_raw_valid_o = rd_phase && nand_active_q && nand_rd_valid_i;
  assign ecc_rd_raw_data_o  = nand_rd_data_i ^ ks_r;
  assign ecc_rd_raw_last_o  = nand_rd_last_i;
  assign nand_rd_ready_o    = rd_phase && nand_active_q && ecc_rd_raw_ready_i;

  assign ecc_rd_pay_ready_o = rd_phase;
  assign ecc_rd_um_ready_o  = rd_phase;
  assign ecc_rd_sst_ready_o = rd_phase;
  assign ecc_rd_pst_ready_o = rd_phase;

  assign nand_cmd_valid_o = ((st == S_W_START) && !nc_done_q) || ((st == S_R_CMD) && !nc_done_q);
  assign nand_cmd_read_o  = (st == S_R_CMD);
  assign nand_cmd_ppa_o   = ppa_q;

  // ---------------------------------------------------------------- DIM block helpers
  logic [127:0] dim_blk;
  assign dim_blk = {bswap32(c_crc), bswap64(lba_q), 16'h0000, DIM_VERSION, 8'h00};

  // host word -> block position
  function automatic logic [127:0] put_word(input logic [127:0] blk, input logic [1:0] k, input logic [31:0] w);
    logic [127:0] r;
    r = blk;
    for (int b = 0; b < 4; b++) r[127 - 8*(4*int'(k) + b) -: 8] = w[8*b +: 8];
    return r;
  endfunction
  function automatic logic [31:0] get_word(input logic [127:0] blk, input logic [1:0] k);
    logic [31:0] w;
    for (int b = 0; b < 4; b++) w[8*b +: 8] = blk[127 - 8*(4*int'(k) + b) -: 8];
    return w;
  endfunction

  // read-side DIM fields (block NBLK-1 after decrypt)
  logic [127:0] dim_rx;
  logic [31:0]  dim_guard;
  logic [63:0]  dim_ref;
  assign dim_rx    = rbuf[NBLK-1];
  assign dim_guard = bswap32(dim_rx[127:96]);
  assign dim_ref   = bswap64(dim_rx[95:32]);

  // ---------------------------------------------------------------- combinational control
  logic       need_load;
  assign need_load = !xts_loaded_q || (slot_loaded_q != slot_q) || (epoch_loaded_q != ks_epoch_i);

  logic hw_beat, hw_bad;
  assign hw_ready_o = (st == S_W_IN) && (blk_q < NBLK_PAY[6:0]);
  assign hw_beat    = hw_valid_i && hw_ready_o;
  assign hw_bad     = hw_beat && (hw_err_i || hw_poison_i);

  assign xs_valid = (st == S_W_XIN) || (st == S_R_DXIN);
  assign xs_data  = (st == S_W_XIN) ? acc_q : rbuf[blk_q[5:0]];
  assign xm_ready = (st == S_W_XOUT) ? ser_idle : (st == S_R_DXOUT);
  assign x_kload  = (st == S_KLOAD) && x_kidle;
  assign x_dec    = (st == S_R_DSTART);
  assign x_nblk   = 21'(NBLK);
  assign x_start  = ((st == S_W_START) && !xs_done_q && x_ready) || ((st == S_R_DSTART) && x_ready);
  assign x_abort  = (st == S_ERR);

  assign hr_valid_o = (st == S_R_OUT);
  assign hr_data_o  = get_word(rbuf[6'(wordidx_q[6:2])], wordidx_q[1:0]);
  assign hr_last_o  = (st == S_R_OUT) && (wordidx_q == NWORD[6:0] - 7'd1);

  assign c_clr  = ((st == S_W_START) && !xs_done_q) || (st == S_R_DSTART);
  assign c_en   = hw_beat && !hw_bad || (st == S_R_CRC);
  assign c_data = (st == S_R_CRC) ? get_word(rbuf[6'(wordidx_q[6:2])], wordidx_q[1:0]) : hw_data_i;

  assign g_req    = (st == S_W_PMD && g_ready) || (st == S_R_PMD && g_ready);
  assign g_verify = (st == S_R_PMD);
  assign g_auth   = (st == S_R_PMD) ? (rx_flags[1] | pol_auth_req_i) : pol_auth_en_i;
  assign g_body   = (st == S_R_PMD) ? {pmdrx_q[255 -: 160], 96'b0} : {pmd_body_w, 96'b0};
  assign g_crc_in = rx_crc;
  assign g_tag_in = rx_tag;

  assign ecc_flush_o = (fl_q != 4'd0);
  assign nand_abort_o = (st == S_ERR) && nand_active_q;

  // watchdog on the host side of a write
  logic host_wd_hit;
  assign host_wd_hit = (pol_wd_host_i != 32'd0) && (wd_q >= pol_wd_host_i) && (st == S_W_IN || st == S_R_OUT);

  // ---------------------------------------------------------------- sequential
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; op_q <= 1'b0; tag_q <= '0; lba_q <= '0; ppa_q <= '0; seq_q <= '0; slot_q <= '0;
      err_q <= E_NONE; info_q <= '0; blk_q <= '0; word_q <= '0; acc_q <= '0; ct_q <= '0; pmd_q <= '0;
      um_idx_q <= '0; raw_cnt_q <= '0; xs_done_q <= 1'b0; nc_done_q <= 1'b0; nand_active_q <= 1'b0;
      nand_done_q <= 1'b0; nand_fail_q <= 1'b0; raw_done_q <= 1'b0; fl_q <= 4'd0; wd_q <= '0;
      xts_loaded_q <= 1'b0; slot_loaded_q <= '0; epoch_loaded_q <= '0; pmdrx_q <= '0;
      rx_pay_cnt_q <= '0; rx_um_cnt_q <= '0; pay_done_q <= 1'b0; um_done_q <= 1'b0; sst_seen_q <= 1'b0;
      pst_seen_q <= 1'b0; sst_code_q <= '0; sst_nerr_q <= '0; pst_flips_q <= '0; pst_max_q <= '0; pst_ncorr_q <= '0;
      pst_erased_q <= 1'b0; pst_scrub_q <= 1'b0; pst_ferr_q <= 1'b0; pst_ok_q <= 1'b0; rd_cnt_q <= '0;
      wordidx_q <= '0; ser_cnt_q <= '0; ser_idx_q <= '0; ser_last_q <= 1'b0;
      rsp_valid_o <= 1'b0; rsp_op_o <= 1'b0; rsp_tag_o <= '0; rsp_err_o <= '0; rsp_info_o <= '0;
      tel_pst_o <= 1'b0; tel_flips_o <= '0; tel_maxflips_o <= '0; tel_ncorr_o <= '0; tel_scrub_o <= 1'b0;
      tel_dma_o <= 1'b0;
      for (int i = 0; i < NBLK; i++) rbuf[i] <= '0;
    end else begin
      tel_pst_o <= 1'b0; tel_dma_o <= 1'b0;
      if (fl_q != 4'd0) fl_q <= fl_q - 4'd1;
      if (zeroize_i) xts_loaded_q <= 1'b0;

      // ---------------- write-side serializer (runs concurrently with the main FSM)
      if (ecc_wr_pay_valid_o && ecc_wr_pay_ready_i) begin
        ser_idx_q <= ser_idx_q + 4'd1;
        ser_cnt_q <= ser_cnt_q - 5'd1;
      end
      if (ecc_wr_um_valid_o && ecc_wr_um_ready_i) um_idx_q <= um_idx_q + 6'd1;
      if (nand_wd_valid_o && nand_wd_ready_i) begin
        raw_cnt_q <= raw_cnt_q + 10'd1;
        if (nand_wd_last_o) raw_done_q <= 1'b1;
      end

      // ---------------- read-side collectors
      if (rd_phase) begin
        if (nand_rd_valid_i && nand_rd_ready_o) rd_cnt_q <= rd_cnt_q + 10'd1;
        if (ecc_rd_pay_valid_i && ecc_rd_pay_ready_o) begin
          rbuf[rx_pay_cnt_q[9:4]][127 - 8*int'(rx_pay_cnt_q[3:0]) -: 8] <= ecc_rd_pay_data_i;
          rx_pay_cnt_q <= rx_pay_cnt_q + 10'd1;
          if (ecc_rd_pay_last_i) pay_done_q <= 1'b1;
        end
        if (ecc_rd_um_valid_i && ecc_rd_um_ready_o) begin
          pmdrx_q[255 - 8*int'(rx_um_cnt_q) -: 8] <= ecc_rd_um_data_i;
          rx_um_cnt_q <= rx_um_cnt_q + 6'd1;
          if (rx_um_cnt_q == 6'd31) um_done_q <= 1'b1;
        end
        if (ecc_rd_sst_valid_i && ecc_rd_sst_ready_o) begin
          sst_seen_q <= 1'b1; sst_code_q <= ecc_rd_sst_code_i; sst_nerr_q <= ecc_rd_sst_nerr_i;
        end
        if (ecc_rd_pst_valid_i && ecc_rd_pst_ready_o) begin
          pst_seen_q <= 1'b1; pst_flips_q <= ecc_rd_pst_tot_flips_i; pst_max_q <= ecc_rd_pst_max_flips_i;
          pst_ncorr_q <= ecc_rd_pst_n_corr_i; pst_erased_q <= ecc_rd_pst_all_erased_i;
          pst_scrub_q <= ecc_rd_pst_scrub_i; pst_ferr_q <= ecc_rd_pst_frame_err_i; pst_ok_q <= ecc_rd_pst_ok_i;
          tel_pst_o <= 1'b1; tel_flips_o <= ecc_rd_pst_tot_flips_i; tel_maxflips_o <= ecc_rd_pst_max_flips_i;
          tel_ncorr_o <= ecc_rd_pst_n_corr_i; tel_scrub_o <= ecc_rd_pst_scrub_i;
        end
      end
      if (nand_done_valid_i && nand_active_q) begin nand_done_q <= 1'b1; nand_fail_q <= nand_done_fail_i; end

      // ---------------- watchdogs
      if (st == S_W_IN || st == S_R_OUT) wd_q <= (hw_beat || (hr_valid_o && hr_ready_i)) ? 32'd0 : wd_q + 32'd1;
      else if (st == S_R_RX) wd_q <= wd_q + 32'd1;
      else wd_q <= 32'd0;

      // ---------------- main FSM
      case (st)
        S_IDLE: if (cmd_valid_i && cmd_ready_o) begin
          op_q <= cmd_op_i; tag_q <= cmd_tag_i; lba_q <= cmd_lba_i; ppa_q <= cmd_ppa_i; seq_q <= cmd_seq_i;
          slot_q <= cmd_slot_i; err_q <= E_NONE; info_q <= '0;
          blk_q <= '0; word_q <= '0; um_idx_q <= '0; raw_cnt_q <= '0; xs_done_q <= 1'b0; nc_done_q <= 1'b0;
          nand_active_q <= 1'b0; nand_done_q <= 1'b0; nand_fail_q <= 1'b0; raw_done_q <= 1'b0;
          rx_pay_cnt_q <= '0; rx_um_cnt_q <= '0; pay_done_q <= 1'b0; um_done_q <= 1'b0; sst_seen_q <= 1'b0;
          pst_seen_q <= 1'b0; rd_cnt_q <= '0; wordidx_q <= '0; ser_cnt_q <= '0; ser_idx_q <= '0;
          st <= S_VAL;
        end
        S_VAL: begin
          if (!pol_data_en_i) begin err_q <= E_LIFECYCLE; st <= S_ERR; end
          else if (!ks_valid_i) begin err_q <= E_KEY_INVALID; st <= S_ERR; end
          else if (need_load) st <= S_KLOAD;
          else st <= op_q ? S_R_CMD : S_W_PMD;
        end
        S_KLOAD: if (x_kidle) st <= S_KLOADW;                 // x_kload pulses this cycle
        S_KLOADW: if (x_kidle) begin
          if (x_keq) begin err_q <= E_KEY_EQ; st <= S_ERR; end
          else if (!x_kok) begin err_q <= E_KEY_INVALID; st <= S_ERR; end
          else begin
            xts_loaded_q <= 1'b1; slot_loaded_q <= slot_q; epoch_loaded_q <= ks_epoch_i;
            st <= op_q ? S_R_CMD : S_W_PMD;
          end
        end

        // ======================================== WRITE
        S_W_PMD:  if (g_ready) st <= S_W_PMDW;
        S_W_PMDW: if (g_rsp) begin
          pmd_q <= {pmd_body_w, {g_crc_out[7:0], g_crc_out[15:8], g_crc_out[23:16], g_crc_out[31:24]}, g_tag_out};
          st <= S_W_START;
        end
        S_W_START: begin
          if (x_start) xs_done_q <= 1'b1;
          if (nand_cmd_valid_o && nand_cmd_ready_i) begin nc_done_q <= 1'b1; nand_active_q <= 1'b1; end
          if ((xs_done_q || x_start) && (nc_done_q || (nand_cmd_valid_o && nand_cmd_ready_i))) begin
            blk_q <= '0; word_q <= '0; st <= S_W_IN;
          end
        end
        S_W_IN: begin
          if (dma_err_i || hw_bad || host_wd_hit) begin
            err_q <= (hw_poison_i && hw_beat && !hw_err_i && !dma_err_i) ? E_POISON : E_DMA;
            tel_dma_o <= !(hw_poison_i && hw_beat && !hw_err_i && !dma_err_i);
            st <= S_ERR;
          end else if (blk_q == NBLK_PAY[6:0]) st <= S_W_DIM;
          else if (hw_beat) begin
            acc_q  <= put_word(acc_q, word_q, hw_data_i);
            word_q <= word_q + 2'd1;
            if (word_q == 2'd3) st <= S_W_XIN;
          end
        end
        S_W_DIM:  begin acc_q <= dim_blk; st <= S_W_XIN; end
        S_W_XIN:  begin
          if (dma_err_i) begin err_q <= E_DMA; tel_dma_o <= 1'b1; st <= S_ERR; end
          else if (xs_valid && xs_ready) st <= S_W_XOUT;
        end
        S_W_XOUT: if (xm_valid && xm_ready) begin
          ct_q <= xm_data; ser_cnt_q <= 5'd16; ser_idx_q <= 4'd0; ser_last_q <= (blk_q == NBLK[6:0] - 7'd1);
          blk_q <= blk_q + 7'd1;
          st <= (blk_q == NBLK[6:0] - 7'd1) ? S_W_DRAIN : S_W_IN;
        end
        S_W_DRAIN: begin
          if (nand_done_q && nand_fail_q) begin err_q <= E_NAND_PROG; st <= S_ERR; end
          else if (nand_done_q && raw_done_q && ser_idle && (um_idx_q == 6'd32)) begin
            nand_active_q <= 1'b0; st <= S_RSP;
          end
        end

        // ======================================== READ
        S_R_CMD: begin
          if (nand_cmd_valid_o && nand_cmd_ready_i) begin nc_done_q <= 1'b1; nand_active_q <= 1'b1; st <= S_R_RX; wd_q <= '0; end
        end
        S_R_RX: begin
          if (nand_done_q && nand_fail_q) begin err_q <= E_NAND_READ; st <= S_ERR; end
          else if (wd_q >= WD_RD[31:0]) begin err_q <= E_NAND_READ; st <= S_ERR; end
          else if (nand_done_q && pst_seen_q && sst_seen_q && pay_done_q && um_done_q) begin
            nand_active_q <= 1'b0; st <= S_R_PRE;
            info_q <= {8'h00, pst_max_q, pst_flips_q};
          end
        end
        S_R_PRE: begin
          if (pst_ferr_q) begin err_q <= E_NAND_READ; st <= S_ERR; end
          else if (pst_erased_q) begin err_q <= E_ERASED; st <= S_ERR; end
          else if (sst_code_q == SS_UNCORR) begin err_q <= E_ECC_UNCORR; st <= S_ERR; end
          else if (sst_code_q == SS_INTEG) begin err_q <= E_ECC_INTEG; st <= S_ERR; end
          else st <= S_R_PMD;
        end
        S_R_PMD:  if (g_ready) st <= S_R_PMDW;
        S_R_PMDW: if (g_rsp) begin
          if (g_err || !g_crc_ok) begin err_q <= E_PMD_CRC; st <= S_ERR; end
          else if (!g_tag_ok) begin err_q <= E_PMD_AUTH; st <= S_ERR; end
          else if (rx_magic != PMD_MAGIC || rx_rsvd != 16'h0000 || (rx_flags & ~(FL_ENC | FL_AUTH)) != 8'h00 ||
                   !rx_flags[0]) begin err_q <= E_PMD_FORMAT; st <= S_ERR; end
          else st <= S_R_BIND;
        end
        S_R_BIND: begin
          if (rx_lba != lba_q) begin err_q <= E_LBA_MISMATCH; st <= S_ERR; end
          else if (rx_slot != {6'b0, slot_q} || rx_gen != ks_gen_i) begin err_q <= E_KEY_MISMATCH; st <= S_ERR; end
          else begin blk_q <= '0; st <= S_R_DSTART; end
        end
        S_R_DSTART: if (x_ready) st <= S_R_DXIN;               // x_start pulses this cycle
        S_R_DXIN:  if (xs_valid && xs_ready) st <= S_R_DXOUT;
        S_R_DXOUT: if (xm_valid && xm_ready) begin
          rbuf[blk_q[5:0]] <= xm_data;
          blk_q <= blk_q + 7'd1;
          if (blk_q == NBLK[6:0] - 7'd1) begin wordidx_q <= '0; st <= S_R_CRC; end
          else st <= S_R_DXIN;
        end
        S_R_CRC: begin
          // feed the plaintext words of the payload blocks through CRC-32C
          if (wordidx_q == NWORD[6:0] - 7'd1) begin wordidx_q <= '0; st <= S_R_VER; end
          else wordidx_q <= wordidx_q + 7'd1;
        end
        S_R_VER: begin
          if (c_crc != dim_guard) begin err_q <= E_DI_GUARD; st <= S_ERR; end
          else if (dim_ref != lba_q) begin err_q <= E_DI_REFTAG; st <= S_ERR; end
          else if (dim_rx[15:8] != DIM_VERSION || dim_rx[7:0] != 8'h00 || dim_rx[31:16] != 16'h0000) begin
            err_q <= E_DI_FORMAT; st <= S_ERR;
          end else st <= S_R_OUT;
        end
        S_R_OUT: begin
          if (dma_err_i || host_wd_hit) begin err_q <= E_DMA; tel_dma_o <= 1'b1; st <= S_ERR; end
          else if (hr_valid_o && hr_ready_i) begin
            if (wordidx_q == NWORD[6:0] - 7'd1) begin wordidx_q <= '0; st <= S_RSP; end
            else wordidx_q <= wordidx_q + 7'd1;
          end
        end

        // ======================================== error exit / response
        S_ERR: begin
          fl_q <= 4'd8;                          // hold the ECC engine in reset, XTS abort pulses (x_abort)
          for (int i = 0; i < NBLK; i++) rbuf[i] <= '0;
          acc_q <= '0; ct_q <= '0; pmd_q <= '0; pmdrx_q <= '0; ser_cnt_q <= '0; um_idx_q <= 6'd32;
          st <= S_ERRW;
        end
        S_ERRW: if (fl_q == 4'd0 && !x_busy) begin nand_active_q <= 1'b0; st <= S_RSP; end
        S_RSP: begin
          if (!rsp_valid_o) begin
            rsp_valid_o <= 1'b1; rsp_op_o <= op_q; rsp_tag_o <= tag_q; rsp_err_o <= err_q;
            rsp_info_o <= (err_q == E_NONE || err_q == E_ECC_UNCORR || err_q == E_ECC_INTEG) ? info_q : 32'h0;
            if (err_q == E_NONE) for (int i = 0; i < NBLK; i++) rbuf[i] <= '0;   // no residual plaintext
          end else if (rsp_ready_i) begin rsp_valid_o <= 1'b0; st <= S_IDLE; end
        end
        default: st <= S_IDLE;
      endcase

      // controller / secure reset request: abort whatever is in flight (response E_RESET)
      if (flush_i && st != S_IDLE && st != S_ERR && st != S_ERRW && st != S_RSP) begin
        err_q <= E_RESET; st <= S_ERR;
      end
    end
  end
endmodule

`default_nettype wire
