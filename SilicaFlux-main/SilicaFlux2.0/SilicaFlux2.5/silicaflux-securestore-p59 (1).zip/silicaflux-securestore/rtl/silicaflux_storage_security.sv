// =============================================================================
// SilicaFlux-STORE :: Project 59 -- SecureStore :: silicaflux_storage_security   (PRIMARY RTL)
// Cryptography, data integrity and storage RAS for SilicaFlux storage chips.   Aureom.AI | SilicaFlux-STORE
//
//   host/DMA  --32b-->  [ DIM guard CRC-32C | AES-XTS (vetted AES core) | P54 BCH ECC | NAND randomiser ]  --> NAND
//   host/DMA  <--32b--  [ DIM verify        | AES-XTS decrypt          | P54 ECC decode| de-randomiser   ]  <-- NAND
//   firmware  <-regs->  secure control (key slots / key hierarchy / lifecycle gating / secure reset / sanitise),
//                       record guard service (CRC-32C + CMAC-64 for MAP / JRN / HLT records),
//                       RAS aggregation (events, history, log, IRQ) and health telemetry (temperature, wear,
//                       lifetime snapshot).   Register map: docs/REGISTER_MAP.md (generated).
//
// Security integration with the existing SecureSilicon (P28) boot architecture:
//   * lifecycle   sb_lc_i        = SecureSilicon effective lifecycle (CC_SB_LC_*): DEV 0 / PROV 1 / PROD 2 / RECOVERY 3
//   * privilege   sb_exec_open_i = authenticated-firmware execution window is open (HAND-OFF passed: manifest signature
//                                  verified by the ROM, image measured, hardware hand-off checks passed).  Every
//                                  secure-control register write needs rb_priv_i (CPU data master) AND this signal.
//   * lockdown    sb_lockdown_i  = SecureSilicon LOCKDOWN (invalid lifecycle / illegal state): everything refused.
//   * No signature-verification logic is implemented here; the Ed25519 / SHA-256 verification is SecureSilicon's.
//
// Trust boundaries and what is NOT claimed: docs/01_THREAT_MODEL.md, docs/09_LIMITATIONS.md.  In particular key
// registers are ordinary flip-flops (no eFuse / OTP / tamper-resistant key storage), the platform root key and the
// entropy source are PORTS that the platform must supply, and nothing here is a certified sanitisation or a
// FIPS-validated module.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfecc_defs.svh"
`default_nettype none

module silicaflux_storage_security
  import sfsec_pkg::*;
  import sfsec_regs_pkg::*;
#(
  parameter int DU_BYTES = 512,
  parameter int NS       = 4,
  parameter int WD_RD    = 200000       // read watchdog (cycles)
) (
  input  wire logic         clk,
  input  wire logic         rst_n,            // controller / system reset (volatile keys and data path)
  input  wire logic         por_rst_n,        // power-on reset (telemetry counters, history, health)
  // ---- register page (ControlCore PERIPH bus)
  input  wire logic         rb_sel,
  input  wire logic         rb_we,
  input  wire logic [11:0]  rb_addr,
  input  wire logic [31:0]  rb_wdata,
  output logic [31:0]       rb_rdata,
  output logic              rb_err,
  input  wire logic         rb_priv_i,        // transaction comes from the privileged CPU data master
  // ---- SecureSilicon boot architecture
  input  wire logic [3:0]   sb_lc_i,
  input  wire logic         sb_exec_open_i,
  input  wire logic         sb_lockdown_i,
  input  wire logic         sb_debug_en_i,
  // ---- platform: root key, entropy, tamper
  input  wire logic         prk_valid_i,
  input  wire logic [255:0] prk_i,
  output logic              ent_req_o,
  input  wire logic         ent_valid_i,
  input  wire logic [127:0] ent_data_i,
  input  wire logic         ext_zeroize_i,    // e.g. tamper detector / reset controller: secure reset
  // ---- protected data path: command, host write data, host read data, response
  input  wire logic         cmd_valid_i,
  output logic              cmd_ready_o,
  input  wire logic         cmd_op_i,         // 0 write, 1 read
  input  wire logic [7:0]   cmd_tag_i,
  input  wire logic [63:0]  cmd_lba_i,
  input  wire logic [31:0]  cmd_ppa_i,
  input  wire logic [47:0]  cmd_seq_i,
  input  wire logic [1:0]   cmd_slot_i,
  input  wire logic         hw_valid_i,
  output logic              hw_ready_o,
  input  wire logic [31:0]  hw_data_i,
  input  wire logic         hw_err_i,
  input  wire logic         hw_poison_i,
  input  wire logic         dma_err_i,
  output logic              hr_valid_o,
  input  wire logic         hr_ready_i,
  output logic [31:0]       hr_data_o,
  output logic              hr_last_o,
  output logic              rsp_valid_o,
  input  wire logic         rsp_ready_i,
  output logic              rsp_op_o,
  output logic [7:0]        rsp_tag_o,
  output logic [7:0]        rsp_err_o,
  output logic [31:0]       rsp_info_o,
  // ---- NAND raw-page channel (to the channel controller, P51 / P53 class)
  output logic              nand_cmd_valid_o,
  input  wire logic         nand_cmd_ready_i,
  output logic              nand_cmd_read_o,
  output logic [31:0]       nand_cmd_ppa_o,
  output logic              nand_wd_valid_o,
  input  wire logic         nand_wd_ready_i,
  output logic [7:0]        nand_wd_data_o,
  output logic              nand_wd_last_o,
  input  wire logic         nand_rd_valid_i,
  output logic              nand_rd_ready_o,
  input  wire logic [7:0]   nand_rd_data_i,
  input  wire logic         nand_rd_last_i,
  output logic              nand_abort_o,
  input  wire logic         nand_done_valid_i,
  input  wire logic         nand_done_fail_i,
  // ---- platform health inputs
  input  wire logic         therm_warn_i,
  input  wire logic         temp_valid_i,
  input  wire logic [15:0]  temp_code_i,
  input  wire logic         recovery_evt_i,   // PowerSafe (P58): power-loss recovery performed
  input  wire logic         bad_block_evt_i,
  input  wire logic         erase_evt_i,
  // ---- RAS outputs
  output logic              irq_o,
  output logic              ras_warn_o,
  output logic              ras_err_o,
  output logic              ras_fatal_o
);
  // ======================================================================== lifecycle policy
  logic lc_valid, locked, priv_ok;
  logic allow_data, allow_import, allow_generate, allow_invalidate, allow_rg;
  logic [5:0] ctrl_q;                    // CTRL register
  logic [31:0] wd_host_q;
  assign lc_valid = (sb_lc_i == LC_DEV) || (sb_lc_i == LC_PROV) || (sb_lc_i == LC_PROD) || (sb_lc_i == LC_RECOVERY);
  assign locked   = sb_lockdown_i || !lc_valid;
  assign priv_ok  = rb_priv_i && !locked && (sb_exec_open_i || (sb_lc_i == LC_DEV && sb_debug_en_i));
  assign allow_data       = !locked && (sb_lc_i != LC_RECOVERY) && ctrl_q[0];
  assign allow_import     = !locked && (sb_lc_i == LC_DEV || sb_lc_i == LC_PROV);
  assign allow_generate   = !locked && (sb_lc_i != LC_RECOVERY);
  assign allow_invalidate = !locked;
  assign allow_rg         = !locked;

  // ======================================================================== core
  logic         zeroize;
  logic         pipe_busy, km_busy, km_done, km_kill, rg_busy;
  logic [7:0]   km_err;
  logic [NS-1:0] slot_valid, slot_k256, slot_origin;
  logic [8*NS-1:0] slot_gen;
  logic [128*NS-1:0] slot_salt;
  logic [15:0]  epoch;
  logic         km_valid;
  logic [2:0]   km_op;
  logic [1:0]   km_slot;
  logic         km_k256;
  logic [31:0]  stg_k1 [8];
  logic [31:0]  stg_k2 [8];
  logic [31:0]  stg_mac [4];
  logic [31:0]  stg_salt [4];
  logic [7:0]   stg_gen_q;
  logic         core_cmd_ready, cmd_gate, core_cmd_valid;
  logic         rg_valid, rg_verify, rg_auth, rg_ready, rg_rsp_valid, rg_crc_ok, rg_tag_ok, rg_err, rg_key_valid;
  logic [7:0]   rg_cls;
  logic [5:0]   rg_len;
  logic [1:0]   rg_slot;
  logic [255:0] rg_body;
  logic [63:0]  rg_ctx, rg_tag_o, rg_tag_in;
  logic [31:0]  rg_crc_o, rg_crc_in;
  logic [31:0]  ecc_rdata;
  logic         ecc_sel, ecc_we;
  logic         ev_ecc_c, ev_ecc_u, ev_ecc_i, ev_ecc_s;
  logic         tel_pst, tel_scrub, tel_dma;
  logic [15:0]  tel_flips;
  logic [7:0]   tel_max, tel_ncorr;

  logic [255:0] km_k1, km_k2;
  logic [127:0] km_mac, km_salt;
  always_comb begin
    for (int i = 0; i < 8; i++) begin km_k1[255 - 32*i -: 32] = stg_k1[i]; km_k2[255 - 32*i -: 32] = stg_k2[i]; end
    for (int i = 0; i < 4; i++) begin km_mac[127 - 32*i -: 32] = stg_mac[i]; km_salt[127 - 32*i -: 32] = stg_salt[i]; end
  end

  assign core_cmd_valid = cmd_valid_i && cmd_gate;
  assign cmd_ready_o    = core_cmd_ready && cmd_gate;

  sfsec_core #(.DU_BYTES(DU_BYTES), .NS(NS), .WD_RD(WD_RD)) u_core (
    .clk, .rst_n, .flush_i(zeroize), .zeroize_i(zeroize),
    .cmd_valid_i(core_cmd_valid), .cmd_ready_o(core_cmd_ready), .cmd_op_i, .cmd_tag_i, .cmd_lba_i, .cmd_ppa_i,
    .cmd_seq_i, .cmd_slot_i,
    .pol_data_en_i(allow_data), .pol_auth_en_i(ctrl_q[1]), .pol_auth_req_i(ctrl_q[2]), .pol_scr_en_i(ctrl_q[3]),
    .pol_wd_host_i(wd_host_q),
    .hw_valid_i, .hw_ready_o, .hw_data_i, .hw_err_i, .hw_poison_i, .dma_err_i,
    .hr_valid_o, .hr_ready_i, .hr_data_o, .hr_last_o,
    .rsp_valid_o, .rsp_ready_i, .rsp_op_o, .rsp_tag_o, .rsp_err_o, .rsp_info_o, .pipe_busy_o(pipe_busy),
    .km_valid_i(km_valid), .km_op_i(km_op), .km_slot_i(km_slot), .km_k256_i(km_k256), .km_k1_i(km_k1),
    .km_k2_i(km_k2), .km_kmac_i(km_mac), .km_salt_i(km_salt), .km_gen_i(stg_gen_q),
    .prk_valid_i, .prk_i, .ent_req_o, .ent_valid_i, .ent_data_i, .km_busy_o(km_busy), .km_done_o(km_done),
    .km_err_o(km_err), .km_kill_o(km_kill), .slot_valid_o(slot_valid), .slot_k256_o(slot_k256),
    .slot_origin_o(slot_origin), .slot_gen_o(slot_gen), .slot_salt_o(slot_salt), .epoch_o(epoch),
    .rg_valid_i(rg_valid), .rg_ready_o(rg_ready), .rg_busy_o(rg_busy), .rg_verify_i(rg_verify), .rg_cls_i(rg_cls),
    .rg_len_i(rg_len), .rg_body_i(rg_body), .rg_ctx_i(rg_ctx), .rg_crc_i(rg_crc_in), .rg_tag_i(rg_tag_in),
    .rg_auth_i(rg_auth), .rg_slot_i(rg_slot), .rg_rsp_valid_o(rg_rsp_valid), .rg_crc_o(rg_crc_o), .rg_tag_o(rg_tag_o),
    .rg_crc_ok_o(rg_crc_ok), .rg_tag_ok_o(rg_tag_ok), .rg_err_o(rg_err), .rg_key_valid_o(rg_key_valid),
    .ecc_rb_sel_i(ecc_sel), .ecc_rb_we_i(ecc_we), .ecc_rb_addr_i(rb_addr[7:0]), .ecc_rb_wdata_i(rb_wdata),
    .ecc_rb_rdata_o(ecc_rdata), .ecc_ev_corrected_o(ev_ecc_c), .ecc_ev_uncorr_o(ev_ecc_u),
    .ecc_ev_integrity_o(ev_ecc_i), .ecc_ev_scrub_o(ev_ecc_s),
    .nand_cmd_valid_o, .nand_cmd_ready_i, .nand_cmd_read_o, .nand_cmd_ppa_o, .nand_wd_valid_o, .nand_wd_ready_i,
    .nand_wd_data_o, .nand_wd_last_o, .nand_rd_valid_i, .nand_rd_ready_o, .nand_rd_data_i, .nand_rd_last_i,
    .nand_abort_o, .nand_done_valid_i, .nand_done_fail_i,
    .tel_pst_o(tel_pst), .tel_flips_o(tel_flips), .tel_maxflips_o(tel_max), .tel_ncorr_o(tel_ncorr),
    .tel_scrub_o(tel_scrub), .tel_dma_o(tel_dma));

  // ======================================================================== register access decode
  logic wr, rd, a_aligned;
  assign wr = rb_sel && rb_we;
  assign rd = rb_sel && !rb_we;
  assign a_aligned = (rb_addr[1:0] == 2'b00);

  function automatic logic in_rng(input logic [11:0] a, input logic [11:0] lo, input int n);
    return (a >= lo) && (a < lo + 12'(4*n));
  endfunction

  logic wr_p, rd_p, rd_tel;
  always_comb begin
    // privileged-write registers
    wr_p = 1'b0;
    if (rb_addr == R_CTRL || rb_addr == R_WD_HOST || rb_addr == R_KEY_CMD || rb_addr == R_KEY_SEL ||
        rb_addr == R_STG_GEN || rb_addr == R_SEC_CMD || rb_addr == R_RG_CTRL || rb_addr == R_RG_CTX_HI ||
        rb_addr == R_RG_CTX_LO || rb_addr == R_RG_CRC || rb_addr == R_RG_TAG_HI || rb_addr == R_RG_TAG_LO ||
        rb_addr == R_TEL_CTRL || rb_addr == R_SEC_ALARM_LIMIT || rb_addr == R_FAULT_HIST || rb_addr == R_HL_CTRL ||
        rb_addr == R_LOG_POP || rb_addr == R_IRQ_STATUS || rb_addr == R_IRQ_ENABLE || rb_addr == R_WEAR_VALID ||
        in_rng(rb_addr, R_STG_K1_0, 8) || in_rng(rb_addr, R_STG_K2_0, 8) || in_rng(rb_addr, R_STG_MAC0, 4) ||
        in_rng(rb_addr, R_STG_SALT0, 4) || in_rng(rb_addr, R_RG_BODY0, 8) || in_rng(rb_addr, R_HL_BASE0, 32) ||
        in_rng(rb_addr, R_WEAR_ERASE_MAX, 8) || (rb_addr[11:8] == 4'h8))
      wr_p = 1'b1;
    // read-protected registers (key-related / record service)
    rd_p = (rb_addr == R_KEY_STATUS) || (rb_addr == R_KEY_SEL) || (rb_addr == R_KEY_INFO) || in_rng(rb_addr, R_SALT0, 4) ||
           (rb_addr == R_RG_STATUS) || (rb_addr == R_RG_CTX_HI) || (rb_addr == R_RG_CTX_LO) || (rb_addr == R_RG_CRC) ||
           (rb_addr == R_RG_TAG_HI) || (rb_addr == R_RG_TAG_LO) || in_rng(rb_addr, R_RG_BODY0, 8);
    rd_tel = !(rb_addr == R_ID || rb_addr == R_VERSION || rb_addr == R_CFG || rb_addr == R_CAPS) && !rd_p;
  end
  logic wr_denied, rd_denied;
  assign wr_denied = wr && a_aligned && wr_p && !priv_ok;
  assign rd_denied = rd && a_aligned && ((rd_p && !priv_ok) || (rd_tel && !priv_ok && !ctrl_q[5]));

  // ======================================================================== key command / secure reset / record guard
  logic [1:0]  key_sel_q;
  logic        key_done_q, key_err_f_q;
  logic [7:0]  key_err_q;
  logic        km_try, km_ok, sec_try, sec_ok;
  logic        rg_try, rg_ok;
  logic [7:0]  km_deny_code;
  logic [2:0]  kc_op;
  assign kc_op = rb_wdata[2:0];
  assign km_try  = wr && a_aligned && (rb_addr == R_KEY_CMD) && priv_ok;
  assign sec_try = wr && a_aligned && (rb_addr == R_SEC_CMD) && priv_ok && (rb_wdata == 32'h5EC0_5EED);
  assign rg_try  = wr && a_aligned && (rb_addr == R_RG_CTRL) && priv_ok && rb_wdata[0];

  logic cmd_fire_pre;
  assign cmd_gate = !km_try && !rg_try && !km_busy && !rg_busy && !sec_try && !zeroize;
  assign cmd_fire_pre = cmd_valid_i && core_cmd_ready && cmd_gate;

  always_comb begin
    km_deny_code = E_NONE;
    if (rb_wdata[31:16] != 16'h5EC0) km_deny_code = E_RANGE;
    else if (pipe_busy || cmd_fire_pre || km_busy || rg_busy) km_deny_code = E_BUSY;
    else case (kc_op)
      3'd1: if (!allow_import) km_deny_code = E_LIFECYCLE;
      3'd2, 3'd3: if (!allow_generate) km_deny_code = E_LIFECYCLE;
      3'd4: if (!allow_invalidate) km_deny_code = E_LIFECYCLE;
      default: km_deny_code = E_RANGE;
    endcase
  end
  assign km_ok = km_try && (km_deny_code == E_NONE);
  assign sec_ok = sec_try;
  assign km_valid = km_ok;
  assign km_op    = kc_op;
  assign km_slot  = rb_wdata[9:8];
  assign km_k256  = rb_wdata[12];

  // zeroize: secure-reset command or external pin; one registered pulse
  logic zero_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) zero_q <= 1'b0; else zero_q <= sec_ok | ext_zeroize_i;
  end
  assign zeroize = zero_q;

  // record-guard request
  logic [25:0] rgc_q;
  logic        rg_done_q, rg_ok_q, rg_tok_q, rg_err_q, rg_kinv_q;
  logic [31:0] rg_ctx_hi_q, rg_ctx_lo_q, rg_crc_q, rg_th_q, rg_tl_q;
  logic [31:0] rg_body_q [8];
  logic        rg_pending_q;
  assign rg_verify = rgc_q[1];
  assign rg_auth   = rgc_q[2];
  assign rg_cls    = rgc_q[15:8];
  assign rg_len    = rgc_q[21:16];
  assign rg_slot   = rgc_q[25:24];
  always_comb begin
    for (int i = 0; i < 8; i++) rg_body[255 - 32*i -: 32] = rg_body_q[i];
  end
  assign rg_ctx    = {rg_ctx_hi_q, rg_ctx_lo_q};
  assign rg_crc_in = rg_crc_q;
  assign rg_tag_in = {rg_th_q, rg_tl_q};
  assign rg_valid  = rg_pending_q && rg_ready;
  assign rg_ok = rg_try && allow_rg && !pipe_busy && !cmd_fire_pre && !km_busy && !rg_busy && !rg_pending_q &&
                 (!rb_wdata[2] || slot_valid[rb_wdata[25:24]]);

  // ======================================================================== telemetry / RAS
  logic [NEV-1:0] ev;
  logic [7:0]     ev_tag, ev_err;
  logic [31:0]    ev_info;
  logic           rsp_fire;
  logic           rst_q1;
  logic           reset_ev;
  logic           lifecycle_ev;
  assign rsp_fire = rsp_valid_o && rsp_ready_i;
  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin rst_q1 <= 1'b0; reset_ev <= 1'b0; end
    else begin rst_q1 <= rst_n; reset_ev <= !rst_q1 && rst_n; end    // controller reset released
  end

  logic therm_ev;
  logic denied_key;
  assign denied_key = wr && a_aligned && (rb_addr == R_KEY_CMD) && priv_ok && !km_ok;
  assign lifecycle_ev = wr_denied || rd_denied || (denied_key && (km_deny_code == E_LIFECYCLE));

  always_comb begin
    ev = '0; ev_tag = '0; ev_err = '0; ev_info = '0;
    ev[EV_ECC_CORR]   = ev_ecc_c;
    ev[EV_ECC_UNCORR] = ev_ecc_u;
    ev[EV_ECC_INTEG]  = ev_ecc_i;
    ev[EV_ECC_SCRUB]  = ev_ecc_s;
    if (rsp_fire) begin
      ev_tag = rsp_tag_o; ev_err = rsp_err_o; ev_info = rsp_info_o;
      case (rsp_err_o)
        E_DI_GUARD, E_DI_REFTAG, E_DI_FORMAT: ev[EV_DI_FAIL] = 1'b1;
        E_PMD_CRC, E_PMD_FORMAT:              ev[EV_PMD_FAIL] = 1'b1;
        E_PMD_AUTH:                           ev[EV_AUTH_FAIL] = 1'b1;
        E_KEY_INVALID, E_KEY_MISMATCH, E_KEY_EQ: ev[EV_KEY_FAIL] = 1'b1;
        E_LBA_MISMATCH:                       ev[EV_LBA_FAIL] = 1'b1;
        E_POISON:                             ev[EV_POISON] = 1'b1;
        E_NAND_PROG:                          ev[EV_NAND_PROG] = 1'b1;
        E_LIFECYCLE:                          ev[EV_LIFECYCLE] = 1'b1;
        E_ERASED:                             ev[EV_ERASED_READ] = 1'b1;
        E_NAND_READ, E_BUSY:                  ev[EV_PROTOCOL] = 1'b1;
        default: ;
      endcase
    end
    ev[EV_DMA_ERR]    = tel_dma || (dma_err_i && !pipe_busy);
    ev[EV_THERM_WARN] = therm_ev;
    ev[EV_RESET]      = reset_ev;
    ev[EV_RECOVERY]   = recovery_evt_i;
    ev[EV_BAD_BLOCK]  = bad_block_evt_i;
    ev[EV_ERASE]      = erase_evt_i;
    ev[EV_KEY_ERASE]  = km_kill;
    ev[EV_SEC_RESET]  = zeroize;
    ev[EV_LIFECYCLE]  = ev[EV_LIFECYCLE] | lifecycle_ev;
    if (km_done) begin
      if (km_err == E_ENT) ev[EV_ENT_FAIL] = 1'b1;
      if (km_err == E_PRK || km_err == E_KEY_EQ) ev[EV_KEY_FAIL] = 1'b1;
    end
    ev[EV_REC_FAIL]   = rg_rsp_valid && rgc_q[1] && (!rg_crc_ok || !rg_tag_ok);
  end

  logic [32*NEV-1:0] cnt_flat;
  logic [31:0] corr_bits, pages_dec, wr_ok_c, rd_ok_c, wr_err_c, rd_err_c;
  logic [7:0]  max_flips;
  logic [NEV-1:0] hist;
  logic [7:0]  log_count, log_lost;
  logic [31:0] log_w0, log_w1, log_w2;
  logic [3:0]  irq_status;
  logic        sec_alarm;
  logic        clr_session, clr_hist, clr_log, ack_alarm, log_pop;
  logic [31:0] auth_limit_q;
  logic [3:0]  irq_clr, irq_en_q;

  sfsec_ras u_ras (.clk, .por_rst_n, .ev_i(ev), .ev_tag_i(ev_tag), .ev_err_i(ev_err), .ev_info_i(ev_info),
    .pst_i(tel_pst), .pst_flips_i(tel_flips), .pst_max_i(tel_max),
    .wr_ok_i(rsp_fire && !rsp_op_o && rsp_err_o == E_NONE), .rd_ok_i(rsp_fire && rsp_op_o && rsp_err_o == E_NONE),
    .wr_err_i(rsp_fire && !rsp_op_o && rsp_err_o != E_NONE), .rd_err_i(rsp_fire && rsp_op_o && rsp_err_o != E_NONE),
    .clr_session_i(clr_session), .clr_hist_i(clr_hist), .clr_log_i(clr_log), .ack_i(ack_alarm), .log_pop_i(log_pop),
    .auth_limit_i(auth_limit_q), .irq_clr_i(irq_clr), .irq_en_i(irq_en_q), .irq_global_en_i(ctrl_q[4]),
    .cnt_o(cnt_flat), .corr_bits_o(corr_bits), .pages_dec_o(pages_dec), .wr_ok_o(wr_ok_c), .rd_ok_o(rd_ok_c),
    .wr_err_o(wr_err_c), .rd_err_o(rd_err_c), .max_flips_o(max_flips), .hist_o(hist), .log_count_o(log_count),
    .log_lost_o(log_lost), .log_w0_o(log_w0), .log_w1_o(log_w1), .log_w2_o(log_w2), .irq_status_o(irq_status),
    .sec_alarm_o(sec_alarm), .irq_o, .ras_warn_o, .ras_err_o, .ras_fatal_o);

  logic [15:0] temp_cur, temp_max, temp_min;
  logic        temp_seen, therm_now;
  logic        hl_cap, hl_rst, hl_clr;
  logic [32*32-1:0] hl_snap, hl_base_img;
  logic        hl_sv, hl_rs, hl_rf, hl_busy;
  logic [7:0]  hl_ncap;
  logic [15:0] hl_age;
  logic [NEV-1:0] fault_life;
  logic [28*32-1:0] cnt28;
  always_comb begin
    cnt28 = '0;
    for (int i = 0; i < NEV; i++) cnt28[32*i +: 32] = cnt_flat[32*i +: 32];
    cnt28[32*24 +: 32] = corr_bits; cnt28[32*25 +: 32] = pages_dec; cnt28[32*26 +: 32] = wr_ok_c; cnt28[32*27 +: 32] = rd_ok_c;
  end
  logic [31:0] hlb_q [32];
  always_comb begin
    for (int i = 0; i < 32; i++) hl_base_img[32*i +: 32] = hlb_q[i];
  end
  sfsec_health u_health (.clk, .por_rst_n, .temp_valid_i, .temp_code_i, .therm_warn_i, .therm_ev_o(therm_ev),
    .temp_cur_o(temp_cur), .temp_max_o(temp_max), .temp_min_o(temp_min), .temp_seen_o(temp_seen), .therm_warn_o(therm_now),
    .cnt28_i(cnt28), .maxflips_i(max_flips), .hist_i(hist), .cap_i(hl_cap), .rst_i(hl_rst), .clr_life_i(hl_clr),
    .base_img_i(hl_base_img), .snap_o(hl_snap), .snap_valid_o(hl_sv), .restored_o(hl_rs), .refused_o(hl_rf),
    .ncap_o(hl_ncap), .age_o(hl_age), .fault_life_o(fault_life), .busy_o(hl_busy));

  // ======================================================================== register file
  logic [31:0] wear_q [8];
  logic [2:0]  wear_valid_q;
  logic [7:0]  cmds_q;
  logic [7:0]  lasterr_q, lasttag_q;
  logic        lastop_q;
  logic [7:0]  san_erasures_q, san_resets_q;
  assign ecc_sel = rb_sel && (rb_addr[11:8] == 4'h8) && (!rb_we || priv_ok) && a_aligned;
  assign ecc_we  = rb_we;

  // volatile / control registers (controller-reset domain)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ctrl_q <= 6'h23; wd_host_q <= 32'h0010_0000; key_sel_q <= '0; key_done_q <= 1'b0; key_err_f_q <= 1'b0;
      key_err_q <= '0; stg_gen_q <= '0;
      for (int i = 0; i < 8; i++) begin stg_k1[i] <= '0; stg_k2[i] <= '0; end
      for (int i = 0; i < 4; i++) begin stg_mac[i] <= '0; stg_salt[i] <= '0; end
      rgc_q <= '0; rg_done_q <= 1'b0; rg_ok_q <= 1'b0; rg_tok_q <= 1'b0; rg_err_q <= 1'b0; rg_kinv_q <= 1'b0;
      rg_ctx_hi_q <= '0; rg_ctx_lo_q <= '0; rg_crc_q <= '0; rg_th_q <= '0; rg_tl_q <= '0; rg_pending_q <= 1'b0;
      for (int i = 0; i < 8; i++) rg_body_q[i] <= '0;
      cmds_q <= '0; lasterr_q <= '0; lasttag_q <= '0; lastop_q <= 1'b0; san_erasures_q <= '0; san_resets_q <= '0;
      for (int i = 0; i < 8; i++) wear_q[i] <= '0;
      wear_valid_q <= '0;
      for (int i = 0; i < 32; i++) hlb_q[i] <= '0;
    end else begin
      // ---- staging-key hygiene: wiped when a command completes and by secure reset
      if (km_done || zeroize) begin
        for (int i = 0; i < 8; i++) begin stg_k1[i] <= '0; stg_k2[i] <= '0; end
        for (int i = 0; i < 4; i++) begin stg_mac[i] <= '0; stg_salt[i] <= '0; end
      end
      if (zeroize) begin
        for (int i = 0; i < 8; i++) rg_body_q[i] <= '0;
        rg_pending_q <= 1'b0;
      end
      if (km_done) begin key_done_q <= 1'b1; key_err_q <= km_err; key_err_f_q <= (km_err != E_NONE); end
      if (km_kill && !zeroize && san_erasures_q != 8'hFF) san_erasures_q <= san_erasures_q + 8'd1;
      if (zeroize && san_resets_q != 8'hFF) san_resets_q <= san_resets_q + 8'd1;
      if (rg_valid) rg_pending_q <= 1'b0;
      if (rg_rsp_valid) begin
        rg_done_q <= 1'b1; rg_ok_q <= rg_crc_ok; rg_tok_q <= rg_tag_ok; rg_err_q <= rg_err;
        if (!rgc_q[1]) begin rg_crc_q <= rg_crc_o; {rg_th_q, rg_tl_q} <= rg_tag_o; end
      end
      if (rsp_fire) begin
        lasterr_q <= rsp_err_o; lasttag_q <= rsp_tag_o; lastop_q <= rsp_op_o;
        if (cmds_q != 8'hFF) cmds_q <= cmds_q + 8'd1;
      end
      // ---- key command bookkeeping
      if (km_try) begin
        key_done_q <= !km_ok; key_err_f_q <= !km_ok; key_err_q <= km_ok ? E_NONE : km_deny_code;
      end
      // ---- register writes
      if (wr && a_aligned && priv_ok) begin
        case (rb_addr)
          R_CTRL:      ctrl_q <= rb_wdata[5:0];
          R_WD_HOST:   wd_host_q <= rb_wdata;
          R_KEY_SEL:   key_sel_q <= rb_wdata[1:0];
          R_STG_GEN:   stg_gen_q <= rb_wdata[7:0];
          R_RG_CTX_HI: rg_ctx_hi_q <= rb_wdata;
          R_RG_CTX_LO: rg_ctx_lo_q <= rb_wdata;
          R_RG_CRC:    rg_crc_q <= rb_wdata;
          R_RG_TAG_HI: rg_th_q <= rb_wdata;
          R_RG_TAG_LO: rg_tl_q <= rb_wdata;
          R_WEAR_VALID: wear_valid_q <= rb_wdata[2:0];
          R_RG_CTRL: if (rb_wdata[0]) begin
            rg_done_q <= 1'b0; rg_kinv_q <= rb_wdata[2] && !slot_valid[rb_wdata[25:24]];
            if (rg_ok) begin rgc_q <= rb_wdata[25:0]; rg_pending_q <= 1'b1; end
            else begin rg_err_q <= 1'b1; rg_done_q <= 1'b1; end
          end
          default: begin
            for (int i = 0; i < 8; i++) begin
              if (rb_addr == R_STG_K1_0 + 12'(4*i)) stg_k1[i] <= rb_wdata;
              if (rb_addr == R_STG_K2_0 + 12'(4*i)) stg_k2[i] <= rb_wdata;
              if (rb_addr == R_RG_BODY0 + 12'(4*i)) rg_body_q[i] <= rb_wdata;
              if (rb_addr == R_WEAR_ERASE_MAX + 12'(4*i)) wear_q[i] <= rb_wdata;
            end
            for (int i = 0; i < 4; i++) begin
              if (rb_addr == R_STG_MAC0 + 12'(4*i)) stg_mac[i] <= rb_wdata;
              if (rb_addr == R_STG_SALT0 + 12'(4*i)) stg_salt[i] <= rb_wdata;
            end
            for (int i = 0; i < 32; i++) if (rb_addr == R_HL_BASE0 + 12'(4*i)) hlb_q[i] <= rb_wdata;
          end
        endcase
      end
    end
  end

  // pulses decoded from writes (combinational, one cycle)
  always_comb begin
    clr_session = 1'b0; clr_hist = 1'b0; clr_log = 1'b0; ack_alarm = 1'b0; log_pop = 1'b0; irq_clr = '0;
    hl_cap = 1'b0; hl_rst = 1'b0; hl_clr = 1'b0;
    if (wr && a_aligned && priv_ok) begin
      if (rb_addr == R_TEL_CTRL) begin clr_session = rb_wdata[0]; clr_hist = rb_wdata[1]; clr_log = rb_wdata[2]; ack_alarm = rb_wdata[3]; end
      if (rb_addr == R_FAULT_HIST && |rb_wdata) clr_hist = 1'b1;
      if (rb_addr == R_LOG_POP) log_pop = 1'b1;
      if (rb_addr == R_IRQ_STATUS) irq_clr = rb_wdata[3:0];
      if (rb_addr == R_HL_CTRL) begin
        hl_cap = rb_wdata[0] && !hl_busy; hl_rst = rb_wdata[1] && !hl_busy;
        hl_clr = rb_wdata[2] && (rb_wdata[31:16] == 16'hC1EA);
      end
    end
  end
  // power-on-domain control registers (alarm limit, interrupt enables)
  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin
      auth_limit_q <= 32'd4; irq_en_q <= 4'hE;
    end else if (wr && a_aligned && priv_ok) begin
      if (rb_addr == R_SEC_ALARM_LIMIT) auth_limit_q <= rb_wdata;
      if (rb_addr == R_IRQ_ENABLE) irq_en_q <= rb_wdata[3:0];
    end
  end

  // ---- read mux
  logic [31:0] rdata_c;
  logic        rd_hit;
  logic [31:0] cfg_w, caps_w, status_w, lc_w;
  assign cfg_w   = {8'(NEV), 3'b000, 1'b1, 1'b1, 1'b1, 1'b1, 1'b1, 8'(DU_BYTES / 16), 8'(NS)};
  assign caps_w  = 32'h0000_003F;
  assign status_w = {19'h0, rb_priv_i && priv_ok, sec_alarm, rg_busy, prk_valid_i, sb_exec_open_i, sb_lc_i, locked, allow_data,
                     km_busy, pipe_busy};
  assign lc_w = {18'h0, allow_rg, allow_data, allow_invalidate, allow_generate, allow_generate, allow_import, 1'b0,
                 sb_debug_en_i, sb_exec_open_i, locked, sb_lc_i};
  logic [127:0] sel_salt;
  assign sel_salt = slot_salt[128*key_sel_q +: 128];
  logic tel_scrub_q;
  logic [31:0] fault_cur_w;
  assign fault_cur_w = {26'h0, !hl_sv, tel_scrub_q, locked, sec_alarm, (slot_valid == '0) && allow_data, therm_now};
  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) tel_scrub_q <= 1'b0; else if (tel_pst) tel_scrub_q <= tel_scrub;
  end

  always_comb begin
    rdata_c = 32'h0; rd_hit = 1'b1;
    case (rb_addr)
      R_ID:          rdata_c = 32'h5346_5353;
      R_VERSION:     rdata_c = 32'h0001_0000;
      R_CFG:         rdata_c = cfg_w;
      R_CAPS:        rdata_c = caps_w;
      R_CTRL:        rdata_c = {26'h0, ctrl_q};
      R_STATUS:      rdata_c = status_w;
      R_WD_HOST:     rdata_c = wd_host_q;
      R_ERR_LAST:    rdata_c = {cmds_q, 7'h0, lastop_q, lasttag_q, lasterr_q};
      R_KEY_STATUS:  rdata_c = {16'h0, key_err_q, 5'h0, key_err_f_q, key_done_q, km_busy};
      R_KEY_SEL:     rdata_c = {30'h0, key_sel_q};
      R_KEY_INFO:    rdata_c = {epoch, slot_gen[8*key_sel_q +: 8], 5'h0, slot_origin[key_sel_q], slot_k256[key_sel_q], slot_valid[key_sel_q]};
      R_LC_STATUS:   rdata_c = lc_w;
      R_SAN_STATUS:  rdata_c = {7'h0, (san_resets_q != 0), 8'($countones(slot_valid)), san_erasures_q, 6'h0, 1'b1, 1'b0};
      R_RG_STATUS:   rdata_c = {26'h0, rg_kinv_q, rg_err_q, rg_tok_q, rg_ok_q, rg_done_q, rg_busy || rg_pending_q};
      R_RG_CTX_HI:   rdata_c = rg_ctx_hi_q;
      R_RG_CTX_LO:   rdata_c = rg_ctx_lo_q;
      R_RG_CRC:      rdata_c = rg_crc_q;
      R_RG_TAG_HI:   rdata_c = rg_th_q;
      R_RG_TAG_LO:   rdata_c = rg_tl_q;
      R_SEC_ALARM_LIMIT: rdata_c = auth_limit_q;
      R_ECC_CORR_BITS: rdata_c = corr_bits;
      R_ECC_PAGES_DEC: rdata_c = pages_dec;
      R_WR_OK:       rdata_c = wr_ok_c;
      R_RD_OK:       rdata_c = rd_ok_c;
      R_ECC_MAX_FLIPS: rdata_c = {24'h0, max_flips};
      R_WR_ERR:      rdata_c = wr_err_c;
      R_RD_ERR:      rdata_c = rd_err_c;
      R_RESET_COUNT: rdata_c = cnt_flat[32*EV_RESET +: 32];
      R_FAULT_CUR:   rdata_c = fault_cur_w;
      R_FAULT_HIST:  rdata_c = {{(32-NEV){1'b0}}, hist};
      R_FAULT_LIFE:  rdata_c = {{(32-NEV){1'b0}}, fault_life};
      R_TEMP_CUR:    rdata_c = {16'h0, temp_cur};
      R_TEMP_MAX:    rdata_c = {16'h0, temp_max};
      R_TEMP_MIN:    rdata_c = {16'h0, temp_seen ? temp_min : 16'hFFFF};
      R_TEMP_STATUS: rdata_c = {30'h0, therm_now, temp_seen};
      R_WEAR_VALID:  rdata_c = {29'h0, wear_valid_q};
      R_HL_STATUS:   rdata_c = {hl_age, hl_ncap, 5'h0, hl_rf, hl_rs, hl_sv};
      R_LOG_STAT:    rdata_c = {16'h0, log_lost, log_count};
      R_LOG_W0:      rdata_c = log_w0;
      R_LOG_W1:      rdata_c = log_w1;
      R_LOG_W2:      rdata_c = log_w2;
      R_IRQ_STATUS:  rdata_c = {28'h0, irq_status};
      R_IRQ_ENABLE:  rdata_c = {28'h0, irq_en_q};
      default: begin
        rd_hit = 1'b0;
        if (in_rng(rb_addr, R_SALT0, 4))               begin rdata_c = sel_salt[127 - 32*int'((rb_addr - R_SALT0) >> 2) -: 32]; rd_hit = 1'b1; end
        else if (in_rng(rb_addr, R_RG_BODY0, 8))       begin rdata_c = rg_body_q[(rb_addr - R_RG_BODY0) >> 2]; rd_hit = 1'b1; end
        else if (in_rng(rb_addr, R_EV_CNT_ECC_CORR, NEV)) begin rdata_c = cnt_flat[32*int'((rb_addr - R_EV_CNT_ECC_CORR) >> 2) +: 32]; rd_hit = 1'b1; end
        else if (in_rng(rb_addr, R_WEAR_ERASE_MAX, 8)) begin rdata_c = wear_q[(rb_addr - R_WEAR_ERASE_MAX) >> 2]; rd_hit = 1'b1; end
        else if (in_rng(rb_addr, R_HL_SNAP0, 32))      begin rdata_c = hl_snap[32*int'((rb_addr - R_HL_SNAP0) >> 2) +: 32]; rd_hit = 1'b1; end
        else if (rb_addr[11:8] == 4'h8)                begin rdata_c = ecc_rdata; rd_hit = 1'b1; end
        else if (in_rng(rb_addr, R_STG_K1_0, 8) || in_rng(rb_addr, R_STG_K2_0, 8) || in_rng(rb_addr, R_STG_MAC0, 4) ||
                 in_rng(rb_addr, R_STG_SALT0, 4) || in_rng(rb_addr, R_HL_BASE0, 32) || rb_addr == R_STG_GEN ||
                 rb_addr == R_KEY_CMD || rb_addr == R_SEC_CMD || rb_addr == R_RG_CTRL || rb_addr == R_TEL_CTRL ||
                 rb_addr == R_HL_CTRL || rb_addr == R_LOG_POP)
          rd_hit = 1'b1;   // write-only registers read as zero
      end
    endcase
  end

  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b0;
    if (rb_sel) begin
      if (!a_aligned) rb_err = 1'b1;
      else if (rb_we) begin
        if (wr_denied) rb_err = 1'b1;
        else if (!wr_p) rb_err = 1'b1;             // read-only or unmapped register
      end else begin
        if (rd_denied) rb_err = 1'b1;
        else if (!rd_hit) rb_err = 1'b1;
        else rb_rdata = rdata_c;
      end
    end
  end
endmodule

`default_nettype wire
