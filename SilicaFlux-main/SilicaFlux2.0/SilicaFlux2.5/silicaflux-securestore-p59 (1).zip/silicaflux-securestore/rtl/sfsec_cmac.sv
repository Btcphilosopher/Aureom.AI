// =============================================================================
// SilicaFlux SecureStore :: sfsec_cmac -- AES-CMAC (NIST SP 800-38B) around the VETTED secworks AES core
//
// The AES block primitive is third_party/secworks-aes (unmodified).  This module is only the CMAC mode
// (subkey derivation, last-block handling, chaining), validated against the NIST SP 800-38B examples and
// randomised OpenSSL vectors (tb_crypto_units).  Used for (a) the SP 800-108 key-derivation function and
// (b) message authentication of metadata records (sfsec_rec_guard).
//
// Message: up to 64 bytes, byte 0 in msg_i[511:504].  Key: AES-128 (left-aligned in key_i[255:128]) or AES-256.
// start_i (pulse, when !busy_o) latches key / length / message; done_o pulses when tag_o (128 bit) is valid;
// tag_o stays valid until the next start.  After EVERY operation the key copies and the AES key schedule are wiped
// (busy_o stays high for the 3-cycle wipe); zeroize_i does the same on demand and also clears the tag.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfsec_cmac (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         zeroize_i,
  input  wire logic         start_i,
  input  wire logic [255:0] key_i,
  input  wire logic         key256_i,
  input  wire logic [6:0]   len_i,       // 0..64 bytes
  input  wire logic [511:0] msg_i,
  output logic              busy_o,
  output logic              done_o,
  output logic [127:0]      tag_o
);
  typedef enum logic [3:0] { C_IDLE, C_INIT, C_INITW, C_SK, C_SKW, C_BLK, C_BLKW, C_FIN } cstate_t;
  cstate_t st;

  logic [255:0] key_q;
  logic         k256_q;
  logic [511:0] msg_q;
  logic [6:0]   len_q;
  logic [2:0]   nblk_q, idx_q;
  logic         lastfull_q;
  logic [127:0] x_q, sk1_q, sk2_q;
  logic [1:0]   zc_q;

  logic aes_rst_n;
  assign aes_rst_n = rst_n & (zc_q == 2'd0);

  logic         a_init, a_next, a_ready, a_rv;
  logic [127:0] a_res, a_blk;

  aes_core u_aes (.clk(clk), .reset_n(aes_rst_n), .encdec(1'b1), .init(a_init), .next(a_next), .ready(a_ready),
                  .key(key_q), .keylen(k256_q), .block(a_blk), .result(a_res), .result_valid(a_rv));

  function automatic logic [127:0] dbl(input logic [127:0] v);
    return {v[126:0], 1'b0} ^ (v[127] ? 128'h87 : 128'h0);
  endfunction

  // block `idx` of the message with CMAC padding / subkey applied (SP 800-38B algorithm 5)
  logic [127:0] raw_blk, pad_blk, cur_blk;
  logic         is_last;
  always_comb begin
    raw_blk = msg_q[511 - 128*idx_q -: 128];
    is_last = (idx_q + 3'd1 == nblk_q);
    pad_blk = raw_blk;
    if (is_last && !lastfull_q) begin
      // keep the (len mod 16) message bytes, then 0x80, then zeros
      pad_blk = '0;
      for (int b = 0; b < 16; b++) begin
        if (b < int'(len_q[3:0]))       pad_blk[127 - 8*b -: 8] = raw_blk[127 - 8*b -: 8];
        else if (b == int'(len_q[3:0])) pad_blk[127 - 8*b -: 8] = 8'h80;
      end
    end
    cur_blk = pad_blk ^ x_q ^ (is_last ? (lastfull_q ? sk1_q : sk2_q) : 128'h0);
  end

  assign a_init = (st == C_INIT);
  assign a_next = (st == C_SK) || (st == C_BLK);
  assign a_blk  = (st == C_SK || st == C_SKW) ? 128'h0 : cur_blk;   // sampled by the core on the `next` pulse
  assign busy_o = (st != C_IDLE) || (zc_q != 2'd0);     // includes the key-schedule wipe that follows every operation
  assign tag_o  = x_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= C_IDLE; key_q <= '0; k256_q <= 1'b0; msg_q <= '0; len_q <= '0; nblk_q <= '0; idx_q <= '0;
      lastfull_q <= 1'b0; x_q <= '0; sk1_q <= '0; sk2_q <= '0; zc_q <= 2'd0; done_o <= 1'b0;
    end else begin
      done_o <= 1'b0;
      if (zc_q != 2'd0) zc_q <= zc_q - 2'd1;
      if (zeroize_i) begin
        zc_q <= 2'd3; st <= C_IDLE; key_q <= '0; msg_q <= '0; x_q <= '0; sk1_q <= '0; sk2_q <= '0;
      end else begin
        case (st)
          C_IDLE: if (start_i && zc_q == 2'd0) begin
            key_q <= key_i; k256_q <= key256_i; msg_q <= msg_i; len_q <= len_i;
            nblk_q <= (len_i == 7'd0) ? 3'd1 : 3'((len_i + 7'd15) >> 4);
            lastfull_q <= (len_i != 7'd0) && (len_i[3:0] == 4'd0);
            idx_q <= 3'd0; x_q <= '0;
            st <= C_INIT;
          end
          C_INIT:  st <= C_INITW;
          C_INITW: if (a_ready) st <= C_SK;
          C_SK:    st <= C_SKW;
          C_SKW:   if (a_ready && a_rv) begin
                     sk1_q <= dbl(a_res);
                     sk2_q <= dbl(dbl(a_res));
                     st <= C_BLK;
                   end
          C_BLK:   st <= C_BLKW;
          C_BLKW:  if (a_ready && a_rv) begin
                     x_q <= a_res;
                     if (is_last) begin st <= C_FIN; end
                     else begin idx_q <= idx_q + 3'd1; st <= C_BLK; end
                   end
          C_FIN:   begin
                     done_o <= 1'b1; st <= C_IDLE;
                     // hygiene: no key (K_mac / PRK) outlives its operation -- clear the copies and reset the AES core,
                     // whose reset clears the round-key memory; the tag (x_q) stays readable until the next start
                     zc_q <= 2'd3; key_q <= '0; msg_q <= '0; sk1_q <= '0; sk2_q <= '0;
                   end
          default: st <= C_IDLE;
        endcase
      end
    end
  end

endmodule

`default_nettype wire
