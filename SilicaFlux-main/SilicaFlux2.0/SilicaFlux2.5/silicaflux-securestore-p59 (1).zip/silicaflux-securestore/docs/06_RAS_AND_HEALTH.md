# 06 — RAS aggregation and reliability / health telemetry

Register map: `docs/REGISTER_MAP.md` (generated from `scripts/gen_regmap.py`, also emitted as `sw/sfsec_regs.h` and the RTL package).
Telemetry registers are readable by any master that can reach the page while `CTRL.HOST_TELEMETRY = 1` (default) and by privileged masters always;
clears and configuration are privileged.

## 1. What is collected (brief §8) and where it is visible

| Quantity | Source | Register(s) |
|---|---|---|
| NAND corrected-error counts | P54 page status (`tot_flips`) + codeword event | `ECC_CORR_BITS` (bits), `EV_CNT_ECC_CORR` (codewords), `ECC_MAX_FLIPS`; per-read count in the response (`rsp_info[15:0]`) |
| Uncorrectable errors | P54 events | `EV_CNT_ECC_UNCORR`, `EV_CNT_ECC_INTEG` (miscorrection caught) |
| ECC decoder activity | P54 page status | `ECC_PAGES_DEC`, P54 statistics window at `0x800` |
| Bad-block counts | NAND controller pulse + FTL | `EV_CNT_BAD_BLOCK` (events), `BAD_BLOCKS_FACTORY/RUNTIME` (firmware-published) |
| Erase counts | NAND controller pulse + FTL | `EV_CNT_ERASE`, `WEAR_ERASE_MAX/MIN/TOTAL`, `WEAR_BLOCKS` |
| Thermal warnings | `therm_warn_i` | `EV_CNT_THERM_WARN` (rising edges), `TEMP_STATUS.WARN` (live), `FAULT_CUR[0]` |
| Controller resets | reset release (POR domain) | `RESET_COUNT` = `EV_CNT_RESET` |
| DMA errors | pipeline + `dma_err_i` | `EV_CNT_DMA_ERR`, `EV_CNT_POISON` |
| Recovery events | PowerSafe (P58) pulse | `EV_CNT_RECOVERY` |
| Data-integrity failures | pipeline responses | `EV_CNT_DI_FAIL`, `PMD_FAIL`, `AUTH_FAIL`, `KEY_FAIL`, `LBA_FAIL`, `REC_FAIL`, `ERASED_READ` |
| Security events | lifecycle / privilege / key | `EV_CNT_LIFECYCLE`, `KEY_ERASE`, `SEC_RESET`, `ENT_FAIL`; `SEC_ALARM` |
| Data commands | responses | `WR_OK`, `RD_OK`, `WR_ERR`, `RD_ERR`, `ERR_LAST` |

All counters are 32-bit, saturating, in the **power-on domain** (they keep counting across controller resets, which the reset counter itself requires;
a power cycle clears them — persistence across power loss is the snapshot service, §3).

## 2. Aggregation

* 24 event classes (`sfsec_pkg::EV_*`, listed with severity in the register map) → counter, sticky history bit (`FAULT_HIST`, W1C), 16-entry log (timestamp, event, severity, tag, error code, info; overflow counted in `LOG_STAT.lost`), severity → `IRQ_STATUS` (INFO / WARN / ERROR / FATAL-SECURITY).
* Outputs: `irq_o` (enabled severities), `ras_warn_o`, `ras_err_o`, `ras_fatal_o` — intended for the `cc_ras` `EXT_WARN` / `EXT_FATAL` inputs (P26 style).
* **Security alarm:** `EV_AUTH_FAIL` ≥ `SEC_ALARM_LIMIT` (default 4) since the last acknowledge latches `SEC_ALARM` → `ras_fatal_o`; acknowledged by a privileged `TEL_CTRL[3]`.  The policy action (e.g. lock the device) belongs to firmware.
* **Current vs historical status:** `FAULT_CUR` is live (thermal warning now, no valid key slot while data is enabled, security alarm, lockdown, scrub pending on the last page, "no snapshot this power-on"); `FAULT_HIST` is sticky since power-on; `FAULT_LIFE` = restored snapshot | history.

## 3. Health service

* **Temperature:** last / max / min sensor code and a `VALID` flag.  *Units are whatever the platform sensor delivers; no conversion is applied.*  ("where available": until a reading arrives `TEMP_STATUS.VALID = 0`.)
* **Wear and capacity are published by firmware** (the FTL owns erase counts, bad blocks and spare capacity): `WEAR_*`, `BAD_BLOCKS_*`, `RESERVED_TOTAL/REMAIN`, with `WEAR_VALID` flags so a reader can tell "0" from "not published".
* **No remaining-life percentage.**  Deriving one needs a validated NAND endurance model (P52's is explicitly uncalibrated; P56 limitations: "no TBW / DWPD derived"); no register pretends to.
* **Persistent counters = lifetime snapshot service.**  The block cannot write NAND.  `HL_CTRL.CAPTURE` produces 32 words in `HL_SNAP0..31` = (restored base + this power-on) for 28 counters, max flips ever, max temperature ever, fault classes, and a CRC-32C of words 0–30; firmware stores them; after the next power-up firmware writes the image to `HL_BASE0..31` and `HL_CTRL.RESTORE`s it (**refused** — `HL_STATUS.RESTORE_REFUSED` — unless the CRC-32C matches; verified with an image whose CRC comes from the independent model).  Lifetime = base + session.  *CRC-32C detects accidental corruption only: a stale or deliberately consistent image is accepted* (no monotonic counter exists to give freshness; wrap the image with the record guard / a MAC for authenticity — future work).

## 4. Observability caveats

Events are generated from the verified pipeline responses and the P54 pulses; `EV_DMA_ERR` counts faults seen by the pipeline plus `dma_err_i` pulses while idle.  P54's own statistics window restarts whenever the pipeline resets the codec on an error path; SecureStore's counters are authoritative.
