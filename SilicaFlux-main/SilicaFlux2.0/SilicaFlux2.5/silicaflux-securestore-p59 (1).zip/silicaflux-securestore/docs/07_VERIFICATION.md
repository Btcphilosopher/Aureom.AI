# 07 — Verification

Everything below is **RTL simulation** (Verilator 5.49).  Three self-checking testbenches print `TB_RESULT: PASS|FAIL` and exit with a log;
`make regress` runs all three (≈ 45 s), `make mutation` plants 28 faults (≈ 20 min on 3 cores).

## 1. Independent references (nothing in the model is shared with the RTL)

| Item | Reference |
|---|---|
| AES block, XTS mode | OpenSSL (Python `cryptography` 50.0.1) **and** a pure-Python XTS built on AES-ECB blocks; both agree on every vector before it is written to a `.memh` (`scripts/gen_vectors.py` asserts it) |
| XTS standard vectors | NIST CAVP XTSGenAES128 / 256, `tweak-128hexstr` (tweak bytes) and `tweak-dataunitseqno` (little-endian sequence number — confirmed against every vector), encrypt **and** decrypt; IEEE 1619-2007 Annex B vector 1 asserted in the model |
| CMAC | NIST SP 800-38B examples (AES-128/256) + 300 randomised OpenSSL CMACs (0…64 bytes, all padding cases) |
| KDF | NIST CAVP KBKDF counter mode AES-CMAC (80 vectors: AES-128/256, 32-bit counter, 60-byte fixed input, L = 128/160/256/320) + 60 vectors in the SecureStore label format |
| CRC | RFC 3720 CRC-32C vectors, `"123456789"` check values for CRC-32C / CRC-32 / CRC-16, zlib for CRC-32 |
| Page format / ECC | P54's own reference (`PageFormat.encode_page` / `decode_page`) — the raw page the RTL writes to NAND is compared **byte for byte** |
| Record guard | model CRC-32C + CMAC-64 (48 vectors, 4 classes) |
| Health image | CRC-32C computed by the model over a 31-word image the RTL has never seen |

## 2. Results (last run; logs in `reports/`)

| Testbench | Checks | Highlights |
|---|---|---|
| `tb_crypto_units` | 29,940 | XTS engine: **2,400 NIST CAVP records** (AES-128/256 × 2 tweak formats × enc/dec) + **201 OpenSSL records** (1…257 blocks, edge tweaks, 4 KiB+ unit with maximal tweak carry) all bit-exact; policy: equal halves refused (128 / 256), length 0 and 2²⁰+1 refused, abort mid-unit, **zeroise clears the AES round-key memories**; CRC engine 768 messages (3 CRCs); CMAC 308; KDF 140 |
| `tb_core_e2e` | 10,233 | see §3 — real P54 BCH codec + NAND model; functional latency (command → response) ≈ 2.7 k cycles write, ≈ 4.0 k cycles read |
| `tb_top_regs` | 490 | register-level: privilege / lifecycle gating, key management, RAS, health, sanitise, record guard |

## 3. Test plan against the brief (§10)

| Required test | Where | What is checked |
|---|---|---|
| AES-XTS vectors | unit §1 | NIST CAVP + OpenSSL, both key sizes, both directions |
| Encryption/decryption round trips | e2e **E1** | 24 vectors (AES-128 and -256, auth on): stored page **bit-exact** with the independent model, read back equals the payload, zero corrections reported; `T4`, `T6`, `T8` repeat it through the register interface |
| Wrong keys | e2e **E4**, **E8** | wrong XTS key with matching metadata ⇒ `E_DI_GUARD`; wrong K_mac ⇒ `E_PMD_AUTH`; newer generation ⇒ `E_KEY_MISMATCH`; PRK-derived wrong salt ⇒ `E_PMD_AUTH`; rollback refused; invalidated key ⇒ `E_KEY_INVALID`; right keys restored ⇒ page readable again |
| Incorrect data-unit numbers | e2e **E4(a)**, **E3** | read of the page with another LBA ⇒ `E_LBA_MISMATCH`; data encrypted for another tweak under valid metadata ⇒ `E_DI_GUARD`; DIM reference tag naming another LBA ⇒ `E_DI_REFTAG` |
| CRC mismatch | e2e **E3**, unit, top **T7** | PMD CRC-32C (`E_PMD_CRC`), DIM guard (`E_DI_GUARD`), format fields; record-guard CRC; **forged records with recomputed CRC pass the CRC and fail the tag** (11 forgeries, class separation, context binding) |
| ECC recovery | e2e **E2**, **E5**; top **T4** | 1…8 random raw bit flips (data and spare) × 3 repetitions: payload recovered, corrected-bit count reported exactly, counters (`ECC_CORR_BITS`, `EV_CNT_ECC_CORR`, `ECC_MAX_FLIPS`) match; 9…20 flips (20 trials): explicit error, **no data released**, classified as ECC / integrity error; correction unaffected by the randomiser |
| Metadata corruption | e2e **E3** (14 crafted pages with a *valid* ECC codeword and one wrong layer), top **T5** | PMD crc / format / forged tag / forged fields / AUTH-flag downgrade / misdirected LBA / wrong slot / wrong generation / ciphertext rot / wrong tweak / DIM reference / DIM version ⇒ **the exact expected code each time**; health snapshot with a flipped bit refused |
| Reset | e2e **E6**, top **T8** | `rst_n` in the middle of a write: nothing programmed, pipeline idle, volatile keys gone, next write needs the key; `flush` mid-read ⇒ `E_RESET`, **no data leaked**; secure reset: key slots / AES key schedules (XTS data + tweak, CMAC) / plaintext buffer all zero (probed); INVALIDATE wipes the datapath key copies (`E4`), a KDF call leaves no PRK copy (`E8`); controller reset keeps telemetry and counts itself, power cycle clears it |
| DMA faults | e2e **E7** | error beat, poisoned beat, async DMA error during write, host watchdog, async error while draining read data: each gives the right code, a faulted write **programs nothing**, and the next command works |
| Error propagation | e2e **E7**, top **T4** | NAND hang ⇒ read watchdog ⇒ `E_NAND_READ`, ECC engine reset, next read fine (watchdog set to 3,000 cycles in the testbench, 200,000 by default); NAND program failure ⇒ `E_NAND_PROG`; NAND read failure ⇒ `E_NAND_READ`; never-written page ⇒ `E_ERASED`; response → event → counter → history → log → IRQ → `SEC_ALARM` / `ras_fatal_o` chain checked on the 14 crafted failures (class counters equal the expected totals) |
| Security lifecycle restrictions | top **T2**, **T3**, **T6** | unprivileged master, unauthenticated firmware, PROD without exec, debug outside DEV, lockdown, invalid lifecycle code ⇒ refused + counted; DEV / PROV import ok, **PROD import refused**, PROD generate ok, **RECOVERY: data path closed, generate refused, invalidate allowed**; wrong magic, busy interlock, staging hygiene, read-protected key registers; secure reset needs authenticated firmware |
| Honest reporting | top **T1**, **T6** | `CAPS` shows no PRK store / entropy / eFuse / tamper-resistant storage; `SAN_STATUS` shows `SCOPE_UNVALIDATED = 1` and no plaintext path |

## 4. Testbench conventions (why the TBs drive on the falling edge)

Verilator's `--timing` scheduler applies non-blocking assignments made by timed testbench processes before the DUT's clocked logic samples them, which
mis-orders a handshake sampled "at the clock edge".  All testbenches therefore drive with blocking assignments on the **falling** edge and sample
there; ready signals in the DUT depend on registered state only, so a transfer is exactly "valid ∧ ready at the falling edge before the rising edge".  This is a
testbench technique, not a DUT dependence.  The NAND model and entropy source are behavioural / software test devices.

## 5. Mutation check (`reports/mutation.md`)

28 single faults planted in the RTL (wrong CRC polynomial / mode, XTS reduction polynomial and tweak byte order, CMAC subkeys swapped,
PMD CRC / tag / LBA / generation checks removed, DIM guard / reference checks removed, ECC verdict ignored, erased-page detection removed, plaintext buffer not
cleared on errors, secure reset not wiping keys, PROD import allowed, privilege without authenticated firmware, poison accepted, equal key halves accepted,
randomiser column mapping, record class not in the MAC input, auth failures not counted, generation rollback allowed, health restore without CRC).
A mutant counts as killed only if a testbench *runs and reports a failure*; a mutant that fails to build is reported separately and never counted.

**Result: 28 / 28 planted faults killed** (full table: `reports/mutation.md`).  The campaign found two weaknesses in the tests, which were then fixed and re-run:
mutant **M20** (read buffer not cleared on the error path) and **M26** (CMAC key / key schedule not wiped after an operation) both **survived** the first run, because no test looked
at those internal states after a command; checks were added (`E1`, `E2`, `E3`: buffer and key copies zero after every command) and both are now killed.  The 26 other mutants were killed
by earlier, smaller versions of the testbenches, so the final testbenches kill them too (the final versions are supersets); only M20, M25 … M28 were (re-)run against the final testbench.
Mutation testing shows the tests *notice* these 28 specific faults; it does not show the absence of other faults.

## 6. Not verified (see docs/09)

Concurrent traffic, multiple data-unit sizes, more than 4 slots, formal interlock proofs, coverage closure, gate-level / power-aware runs, hardware.
