# 09 — Known limitations (read before relying on anything here)

## Evidence level

* **RTL simulation only** (Verilator 5.49 from the `verilator` PyPI wheel).  No FPGA, no silicon, no gate-level simulation, no formal proof, no Icarus run, **no synthesis / area / timing numbers** (Yosys is not available in this environment; AES core figures quoted by its authors are for *their* tool flows).
* Not FIPS 140-3 / CAVP-validated.  The AES block core is third-party and widely used, but **this integration (XTS / CMAC / KDF mode logic, key management, pipeline) has not been independently reviewed or validated**; it passes NIST CAVP *test vectors* and OpenSSL cross-checks, which is evidence of conformance on those vectors, not a validation certificate.
* No code coverage measurement, no randomised long-run soak, no power-loss campaign.  The pipeline was tested with one data unit in flight, 512-byte data units, `NS = 4` slots.

## Cryptography

* **XTS provides confidentiality only** — no authentication, no tamper detection (docs/01 T5).  Replay / swap of ciphertext and metadata pairs is possible without a freshness source; detection of modified ciphertext is by CRC-32C, i.e. probabilistic against *random* damage only.
* XTS is deterministic per (key, LBA); equality of repeated writes to one location leaks; 16-byte granularity.  No ciphertext stealing: data units must be a multiple of 16 bytes; the CAVP 130- and 200-bit units are not supported.  Data unit ≤ 2²⁰ blocks (enforced), 512 B in this configuration.
* CMAC tag truncated to 64 bits (SP 800-38B allows Tlen ≥ 64; 2⁻⁶⁴ forgery probability per try, bounded by the alarm policy).
* The AES core is an iterative table-S-box design: **no side-channel (timing, power, EM, fault) countermeasures** were designed or evaluated.
* KDF / MAC keys use AES-CMAC from a *platform-provided* PRK; **no PRK storage, no TRNG / DRBG, no health tests on entropy** — ports only.  The testbench entropy is `$urandom`.
* `IMPORT` is a clear-key path (DEV / PROV only).  No wrapped import (AES-KW), no certificate / attestation, no key escrow.
* Keys live in flip-flops: **no eFuse, OTP, secure-NVM or tamper-resistant key storage**; readable by physical probing and by simulation probes.  The generation counter is 8-bit and resets at power-up (cross-power-cycle anti-rollback of keys is not enforced).
* Signature verification is **not** part of this project (SecureSilicon owns it); SecureStore trusts `sb_exec_open_i` / `sb_lc_i` / `sb_lockdown_i` and `rb_priv_i`.  The wiring into the ControlCore crossbar and the P28 system testbench was **not done**.

## Data path / architecture

* **One data unit in flight**, ≈ 2.7 k cycles per 512-byte write and ≈ 4.0 k per read in simulation (AES at ≈ 53 cycles / block; no frequency / MB/s figure is claimed); a production controller needs several engines per channel or a faster AES pipeline behind the same contract.  Memory: 33 × 128-bit read buffer (flip-flop array; a RAM macro needs a clear sequencer).
* **ECC strength:** BCH t = 8 per 528 B sector is the P54 baseline for **SLC-class** NAND; nothing here is claimed sufficient for MLC / TLC / QLC (needs LDPC with soft information) or any UBER / endurance figure.  The P54 codec is reused unmodified but remains un-integrated into the P51 controller; its ECC reset-on-error clears its own statistics.
* **OOB budget** 48 B per 512 B sector (PMD 32 B + CRC-16 + parity + marker): check against the target part.
* The NAND model in the testbench is behavioural (no timing, no wear, no retention physics); NANDLab was not co-simulated.  ONFI sequencing / timing is not implemented (channel controller's job).
* **NAND randomiser** is a placeholder function with a verified *position*; it is off by default and not any vendor's polynomial.
* Host interface: no NVMe / PCIe semantics, no authentication of host commands (P51's `AUTH_IMPL = 0` stays true), no per-namespace keys beyond the 4 slots, no T10-PI / NVMe-PI format compatibility (the DIM is a private format).
* **FTL records:** the record guard is a service; the P56 firmware was **not** modified to call it and the P56 spare-record format is unchanged.
* **Health:** wear statistics are firmware-published (hardware cannot see the FTL); temperature units are sensor-defined; lifetime snapshot is CRC-only and has no freshness; no remaining-life estimate exists on purpose.
* **Sanitisation:** crypto-erase mechanism only; **no standard compliance** and scope (metadata, spare / remapped blocks, firmware areas, persisted salts) not validated — docs/08.
* Lifecycle DEV intentionally relaxes privilege (debug); P28 itself states DEV is not secure.
* Register file: single-cycle combinational read; no byte enables; 32-bit aligned accesses only; no CDC (single clock; POR-domain flops are reset by `por_rst_n` but clocked by `clk`).
* Reset: `rst_n` is used as an asynchronous reset and, for reset counting, as data (lint `SYNCASYNCNET`, intentional); the AES-core zeroisation drives the cores' asynchronous reset from a registered pulse — an ASIC flow needs a glitch-free reset structure and reset-domain-crossing review.

## Verification gaps

Directed + randomised tests against standard vectors and an independent model, and a 28-mutant campaign (docs/07).  Not done: UVM-style
constrained-random system test with concurrent traffic, formal checks of the interlocks, fuzzing of the register interface, gate-level / power-aware
simulation, X-propagation analysis, coverage closure.
