# 05 — Key management, hierarchy, lifecycle and the secure boot / privilege model

> **No eFuse, OTP, secure NVM or tamper-resistant key storage is provided or claimed.**  Key slots are flip-flops that lose their
> contents at reset and are readable by RTL probes.  The platform root key and the entropy source are *ports*; the hardware says so in
> `CAPS[11:8] = 0`.

## 1. Hierarchy

```
PRK  (256-bit, platform key store — port prk_i, not stored here)
 └─ NIST SP 800-108 counter-mode KDF, PRF = AES-CMAC (AES-256 keyed with PRK)
     K(i) = CMAC_PRK( [i]32 ‖ label ‖ 0x00 ‖ slot ‖ generation ‖ salt ‖ [L]32 )
     ├─ label "SFSEC-XTS": L = 256 / 512 bits → K1 ‖ K2   (XTS-AES-128 / -256)
     └─ label "SFSEC-MAC": L = 128 bits       → K_mac     (metadata CMAC key)
salt: 128 bit from the platform entropy port (GENERATE) or supplied by firmware (DERIVE)
```
The KDF is validated against the NIST CAVP KBKDF counter-mode AES-CMAC vectors (80 vectors, AES-128/256 PRFs, 32-bit counter, counter
before fixed data) plus 60 vectors of the SecureStore label format whose expected values come from an independent implementation.

## 2. Operations (`KEY_CMD`, privileged, magic `0x5EC0` in bits [31:16])

| Op | Effect | Allowed in |
|---|---|---|
| 1 IMPORT | install clear XTS K1/K2 + K_mac from the write-only staging registers with an explicit generation ≥ the slot's | DEV, PROV |
| 2 GENERATE | entropy → salt → KDF; generation = old + 1; needs `prk_valid_i` (`E_PRK`) and entropy (`E_ENT`, timeout 4096 cycles) | DEV, PROV, PROD |
| 3 DERIVE | KDF with firmware-supplied salt + generation (restore after power-up); refuses a generation below the slot's (`E_RANGE`) | DEV, PROV, PROD |
| 4 INVALIDATE | zeroise the slot's keys and salt, advance the generation, mark invalid | every non-locked state incl. RECOVERY |
| `SEC_CMD = 0x5EC05EED` | secure reset: every slot, staging registers, record-guard body, CMAC and XTS key schedules, plaintext buffer; aborts the in-flight command (`E_RESET`) | privileged, non-locked |
| `ext_zeroize_i` pin | same as the secure reset (tamper detector / reset-controller hook) | always |

All refusals return an explicit code in `KEY_STATUS` (`E_LIFECYCLE`, `E_RANGE` for a bad magic / generation, `E_BUSY` while the data path, a
record-guard job or another key command is active, `E_PRK`, `E_ENT`, `E_KEY_EQ`) and are counted (`EV_LIFECYCLE`, `EV_KEY_FAIL`, `EV_ENT_FAIL`).
A key set is installed only if K1 ≠ K2.  Staging registers are wiped when a command completes.

**Key-copy hygiene (verified by probes in simulation).**  Keys exist in the slot registers and, transiently, in the XTS engine (K1/K2 registers + two AES key schedules), the CMAC engine (key + schedule), the record guards (K_mac copy) and the KDF (PRK copy, derived output).  Every key command and every secure reset wipes the XTS / CMAC / guard copies (the AES cores' reset clears their round-key memories); the CMAC engine additionally wipes its key and schedule after **every** operation (3-cycle hold, `busy` stays high), the KDF zeroes its PRK copy and output one cycle after each call, the record guard clears its body and K_mac copy once the response is formed.  The XTS engine keeps the *active* slot's key between data units (performance) and reloads from the slot after any key command.

## 3. Key selection and binding

`cmd_slot` (0…3) selects the slot for a data command.  The XTS engine is (re)loaded when the slot, or the *key epoch* (any install /
invalidate), changed since the last load.  Every page records `{slot, generation}` in its PMD; a read under a different slot or generation
fails with `E_KEY_MISMATCH` **before** decryption — a stale key is a named error, not garbage data.

## 4. Provisioning and persistence

* **Test/bring-up (DEV, PROV):** `IMPORT` clear keys (this is how the standard vectors are loaded; the reference model's keys are test keys derived from public labels).
* **Product (PROD):** only `GENERATE` / `DERIVE`; clear import is refused (test `T3`).
* **Across power cycles:** hardware keys are volatile.  Firmware persists `{slot, generation, salt}` (readable by privileged code from `SALT0..3` / `KEY_INFO`) in its own metadata and `DERIVE`s after boot; the PRK must again be supplied by the platform.  `{salt, generation}` without the PRK reveal nothing; the PRK without the salt cannot reproduce the slot's keys — which is what makes erasing the salt a crypto-erase (docs/08).
* **Generation counter:** 8-bit, advanced on every install / invalidate, restarts at 0 on a power cycle; a wrap after 255 installs on one slot in one power-on is possible and is a documented limitation.

## 5. Lifecycle matrix (SecureSilicon `CC_SB_LC_*`; verified in `tb_top_regs T2/T3`)

| | DEV | PROV | PROD | RECOVERY | LOCKDOWN / invalid |
|---|---|---|---|---|---|
| Data path (read/write) | ✓ | ✓ | ✓ | ✗ `E_LIFECYCLE` | ✗ |
| Clear-key IMPORT | ✓ | ✓ | ✗ | ✗ | ✗ |
| GENERATE / DERIVE | ✓ | ✓ | ✓ | ✗ | ✗ |
| INVALIDATE / secure reset | ✓ | ✓ | ✓ | ✓ | ✗ |
| Record-guard service | ✓ | ✓ | ✓ | ✓ | ✗ |
| Privileged register access | authenticated firmware, **or** debug-enabled DEV | authenticated firmware | authenticated firmware | authenticated firmware | ✗ |

## 6. Integration with SecureSilicon (P28) — "verify firmware before privileged execution"

SecureStore implements **no** signature verification.  It consumes the hardware state of the existing boot architecture:
`sb_exec_open_i` is the "authenticated firmware window is open" signal that exists only after the ROM verified the Ed25519 manifest,
the hardware measured the image (SHA-256) and the hand-off checks passed.  Every secure-control register write requires
`rb_priv_i ∧ sb_exec_open_i ∧ ¬sb_lockdown_i` (plus the DEV-debug exception).  A write from an unprivileged master or from
unauthenticated code is refused with a bus error and counted (`EV_LIFECYCLE`); reads of key-related registers are refused the same way.
The privileged-master qualifier `rb_priv_i` must be produced by the bus fabric (CPU data master only).
Not integrated here (specified in docs/00): wiring into the ControlCore crossbar and the P28 system testbench.

## 7. What is not provided

Authenticated key wrap / unwrap (AES-KW, SP 800-38F) for importing keys over an untrusted link; key escrow; key rotation of an
*in-use* slot with background re-encryption (a new generation makes old data unreadable until firmware rewrites it); per-namespace key
policy beyond the 4 slots; a secure debug unlock / RMA state (P28 has none either).
