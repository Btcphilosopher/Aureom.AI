# 04 — NAND data randomiser (scrambler): position and status

**Selected device:** the NANDLab (P52) SLC twin used by P51 / P54 / P56 — it models **no** scrambler and no vendor randomiser
requirement, so the randomiser is **off by default** (`CTRL.SCR_EN = 0`).  The brief asks that, *if* scrambling is required, its position
be defined and verified; that is done for the case where a part needs one.

| Item | Definition |
|---|---|
| Position | **after ECC encode and before the NAND on write; after the NAND and before ECC decode on read.** The transform covers the *entire raw page* (data area, bad-block-marker byte, PMD, CRC-16, parity), so stored bit patterns — including parity and the cleartext PMD, which AES-XTS does not whiten — are decorrelated. |
| Function | `byte' = byte ⊕ scr_ks(ppa, column)` — a stateless 32-bit integer mixing function of the physical page address and the byte column (`rtl/sfsec_pkg.sv`).  Column = position in column order (data 0…527, spare 528…575); on the spare-first read stream the column is remapped so write and read agree. |
| Why this position | XOR commutes with bit errors, so ECC still sees the same error count (test `E5`: 6 injected flips are corrected and counted with the randomiser on). Placing it *before* ECC encode would leave parity un-randomised; placing it between XTS and ECC would not cover PMD. |
| What it is not | **Not cryptographic and not a substitute for encryption**; the keystream is public (function of the page address).  It is a placeholder for the *interface and position*; a part that mandates a specific vendor polynomial / seeding needs that function substituted (single function `scr_ks`). |
| Verification | keystream bytes match the independent Python function (`E5`); stored page = model page ⊕ keystream, bit-exact; round trip; correction unaffected; a page written plain and read with the randomiser on is rejected with an explicit ECC/integrity error (never returned as data). |
