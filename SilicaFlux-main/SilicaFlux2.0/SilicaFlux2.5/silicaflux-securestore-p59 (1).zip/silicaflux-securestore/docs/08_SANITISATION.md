# 08 — Controlled key erasure (crypto-erase): what is designed, what is verified, what is NOT claimed

> **No standards-compliant sanitisation is claimed** (NIST SP 800-88 *Cryptographic Erase*, NVMe *Sanitize*, ATA / TCG Opal *Crypto
> Erase*, IEEE 2883).  The hardware reports this: `SAN_STATUS[1] SCOPE_UNVALIDATED = 1` is constant.

## Design

1. All host data that goes through the pipeline is encrypted under a slot key; **no plaintext bypass exists** (`SAN_STATUS[0] PLAINTEXT_PATH = 0`; the data path has no mode that skips XTS, unlike many SSD controllers' debug modes).
2. `INVALIDATE(slot)` zeroises K1, K2, K_mac and the salt of the slot (flip-flops), then wipes every datapath copy — the XTS engine's key registers and both AES key schedules, the CMAC engine, the record guards (the AES cores' round-key memories are cleared by resetting the cores) — advances the generation and marks the slot invalid; `KEY_ERASE` is counted and logged.  Staging registers are wiped when any key command completes.
3. A derived (PRK-based) slot is erasable by destroying the **salt**: the key is a function of PRK, generation and salt only; with the salt gone the key cannot be recomputed even though the PRK persists.  The generation counter then forbids `DERIVE` of the old generation within the power-on.
4. `crypto-erase = INVALIDATE` (+ firmware destroys its persisted `{salt, generation}`), optionally followed by `GENERATE` to get a fresh key for new data.

## Verified (tb_top_regs T6, tb_core_e2e E4/E6)

* read / write with an invalidated key → `E_KEY_INVALID` (never garbage data); generation advanced; salt registers read zero; the slot registers, the XTS engine's key registers and both AES round-key memories, the CMAC engine's key / schedule and the record-guard K_mac copies are zero (probed in simulation, `E4`); after a KDF call the PRK copy, derived output and CMAC schedule are zero (`E8`);
* old ciphertext read back under a *replacement* key of the same generation → `E_PMD_AUTH` (MAC key differs) or, with the same K_mac, `E_DI_GUARD`; under a newer generation → `E_KEY_MISMATCH`;
* secure reset via register and via pin; refused without authenticated firmware; no residual plaintext in the buffer (probed).

## Not considered / not validated — each of these must be resolved before any sanitisation claim

| Item | Status |
|---|---|
| **Metadata** (PMD, FTL mapping / journal / checkpoint pages): PMD fields (LBA, seq) and FTL metadata are **cleartext** and survive key erasure | not erased; LBA/sequence history remains |
| **Spare blocks, over-provisioned / reserved capacity, remapped (retired) blocks**, blocks awaiting erase | may hold old ciphertext under the retired key: erased *logically* by key destruction only if every byte there was written through this pipeline — **not tracked** by hardware |
| **Pages written before encryption was enabled / by firmware bypassing the pipeline** | cannot be excluded by this block (the platform must guarantee all media writes go through it) |
| **Firmware areas**, boot images, journals written by firmware directly | not covered |
| **Persisted copies of `{salt, generation}`** and any other key-derivation inputs in NAND metadata | firmware must destroy them; not verifiable by the hardware |
| **Key copies outside the block** (host KMS, DRAM, logs, debug captures) | out of scope |
| Protocol requirements: command semantics, completion rules, power-loss during erase, verification / logging requirements of the cited standards | **not validated** |
| Physical remanence of flip-flops / NAND charge | out of scope |
| Multiple generations: data written under an earlier generation of the same slot remain decryptable only if the old keys exist; the hardware keeps none | by design, but not independently verified on a device |
