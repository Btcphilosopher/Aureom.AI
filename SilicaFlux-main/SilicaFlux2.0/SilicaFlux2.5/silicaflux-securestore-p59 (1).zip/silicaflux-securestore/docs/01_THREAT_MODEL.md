# 01 — Threat model

Everything here is a **design-level threat model for a simulated RTL block**, not a security evaluation.  No
penetration test, side-channel analysis, fault-injection campaign or third-party review was performed.

## 1. Assets

| Asset | Protected property | Where it lives |
|---|---|---|
| Host data (payload) | confidentiality at rest; integrity against accidental corruption | NAND (ciphertext) |
| Data-unit location binding | detect misdirected / mis-mapped reads | DIM (encrypted) + PMD (cleartext, CRC / CMAC) |
| Media keys (XTS K1/K2, K_mac) | confidentiality, availability, erasability | key-slot flip-flops (volatile) |
| Derivation inputs (platform root key PRK, per-slot salt + generation) | PRK: confidentiality; salt: erasability | PRK: **platform** (port); salt: slot register + firmware's persisted copy |
| Physical metadata (PMD), FTL mapping / journal / health records | integrity (accidental), authenticity (malicious, optional) | NAND spare area / firmware metadata |
| Telemetry / health counters | availability of truthful reporting | POR-domain flops; firmware snapshot |
| Lifecycle / privilege state | only authenticated firmware may drive secure control | SecureSilicon (P28) |

## 2. Adversaries and capabilities

| # | Adversary | Capability assumed | In scope? |
|---|---|---|---|
| A1 | **Physical media thief** | reads the raw NAND content (data + spare) offline, powered off | **Yes** — confidentiality only (XTS) |
| A2 | **Media corruption** (retention, disturb, program noise, firmware bug, DMA bit-flip) | random / burst errors anywhere in the pipeline | **Yes** — detection + correction (ECC) + explicit errors (CRC-32C, PMD CRC) |
| A3 | **Active flash tamperer** | can rewrite NAND pages / spare bytes of a powered-off or hot-plugged device | **Partly** — metadata forgery detected when AUTH is enabled (CMAC-64); **data replay and ciphertext malleability are NOT prevented** (§4) |
| A4 | Untrusted host / DMA master | can send commands, wrong LBAs / slots, faulty or poisoned data; cannot reach the secure-control page | **Yes** — privilege gate, explicit errors, no payload release on failure |
| A5 | Unauthenticated / unprivileged code on the ControlCore bus or a debug port | register accesses without authenticated-firmware status | **Yes** — secure-control registers refuse (bus error + `EV_LIFECYCLE`) unless `rb_priv_i` ∧ `sb_exec_open_i` ∧ ¬lockdown (DEV + debug exception documented) |
| A6 | Software that tries to **recover erased data** (crypto-erase bypass) | reads ciphertext after key erasure | **Yes** — keys and salts zeroised, generation advanced, no plaintext bypass path exists |
| A7 | Cold-boot / bus-probe / glitching / EM / power analysis / invasive attacker | physical access to the chip | **No** — keys are in ordinary flip-flops; no side-channel or fault countermeasures were designed or evaluated |
| A8 | Compromised platform root key store or entropy source | controls PRK / salts | **No** — they are *trusted ports* (§3) |
| A9 | Authenticated-but-malicious firmware | holds privilege | **No** — firmware is inside the trust boundary |

## 3. Trust assumptions the platform must satisfy (otherwise the claims below are void)

1. `prk_i` carries a 256-bit root key that is secret, random, device-unique, and stored by a **platform key store** (OTP/eFuse macro, secure NVM, HSM-injected) — **none is provided here** (`CAPS[8:11] = 0` says so in hardware).
2. `ent_*` is a **vetted DRBG/TRNG** (e.g. SP 800-90B/C class).  The testbench uses a software PRNG; that is a test device only.
3. `sb_exec_open_i` really means "signature-verified, measured, hand-off-checked firmware is executing" (SecureSilicon P28) and `rb_priv_i` is derived by the fabric from the CPU-data-master identity (HOST, DMA and DBG masters must present `0` outside DEV).
4. Firmware destroys its persisted copy of a slot's `{salt, generation}` when it invalidates the slot (crypto-erase effectiveness depends on it, docs/08).
5. The NAND channel controller honours `nand_abort_o` (no program-confirm after abort) and reports `done_fail`.

## 4. Threats, mitigations, residual risk

| Threat | Mitigation | Residual risk / not covered |
|---|---|---|
| T1 Offline reading of NAND (A1) | AES-XTS (IEEE 1619 / SP 800-38E), per-slot keys, LBA tweak; the DIM guard CRC is **inside** the encrypted unit so no plaintext fingerprint is stored | XTS is deterministic per (key, LBA): rewriting the same plaintext to the same LBA yields the same ciphertext (equality leak across *versions* of one location); 16-byte-block granularity; **no authentication** |
| T2 Accidental corruption (A2) | P54 BCH (t = 8 / 528 B) → CRC-16 inside the codeword → PMD CRC-32C → DIM guard CRC-32C → explicit error codes, counters, log | CRC-32C residual 2⁻³² per random corruption; BCH miscorrection beyond t is caught by CRC-16 / CRC-32C with the probabilities in P54 docs/04; **not** a UBER / endurance claim |
| T3 Misdirected read / FTL map corruption | PMD LBA binding (`E_LBA_MISMATCH`), DIM reference tag, key-slot + generation binding (`E_KEY_MISMATCH`) | an attacker who can rewrite page *and* spare consistently can still present another valid page of the same LBA (replay) |
| T4 Metadata forgery (A3) | CMAC-64 over `class‖len‖body‖ctx(ppa)` with K_mac; CRC-valid-but-tag-invalid ⇒ `E_PMD_AUTH` (a *security* event, counts toward `SEC_ALARM`); `AUTH_REQ` blocks the "strip the flag, recompute the CRC" downgrade | 64-bit tag; **no freshness**: replay of an old valid {page, PMD} pair is undetected (needs a monotonic counter in a root of trust — none exists; P28 docs/07) |
| T5 Ciphertext malleability / chosen modification (A3) | a modified ciphertext block decrypts to garbage, the DIM guard then fails (probability 1−2⁻³²) | **XTS is not authenticated encryption**: an adversary can *swap or replay* whole ciphertext blocks/units; detection is probabilistic and by CRC, not cryptographic. For authenticated data a tag over the ciphertext (e.g. AES-GCM / XTS+MAC) would be required — not implemented |
| T6 Unprivileged key access (A4, A5) | write-only key staging, privileged-only read of key state, `exec_open` gate, lockdown, wrong-magic rejection, busy interlock | DEV lifecycle intentionally allows debug-privileged access |
| T7 Key remanence after erase (A6) | `INVALIDATE` / `SEC_CMD` / `ext_zeroize_i` zero slot keys, salts, XTS and CMAC key schedules (AES-core reset clears round-key memory), staging registers and the plaintext buffer; generation advance forbids restoring an old generation | flip-flop remanence at the physical level is outside RTL scope; scope of *data* covered by the erased keys is not validated (docs/08) |
| T8 Brute-forcing the tag via repeated forgeries | `SEC_ALARM` after N authentication failures (default 4) → `ras_fatal_o` | policy action (lock the device) is firmware's |
| T9 Faulty / poisoned host data (A4) | `hw_err` / `hw_poison` / async DMA error / watchdog ⇒ abort, nothing programmed, explicit code | — |
| T10 Reset / power loss mid-operation | pipeline state is volatile; NAND program is only confirmed after the last byte; abort path; ECC reset | torn pages after real power loss are the FTL/PowerSafe domain (P56/P58) |

## 5. Not in the threat model

Side channels (timing: the AES core's S-box is a table lookup, not constant-time hardened; the tag
comparison is a full-width parallel compare); fault injection / glitching; hardware Trojans; supply-chain compromise
of the vendored cores beyond pinning and hashing (`third_party/PROVENANCE.md`); denial of service by an authorised host;
compliance (FIPS 140-3, Common Criteria, TCG Opal / OPAL SSC, NVMe sanitize) — **none is claimed**.
