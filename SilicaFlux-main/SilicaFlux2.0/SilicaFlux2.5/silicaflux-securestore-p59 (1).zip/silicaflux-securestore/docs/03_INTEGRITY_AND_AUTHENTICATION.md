# 03 — Data integrity (CRC) versus authentication (CMAC): what each layer is and is not

> **A CRC is not authentication.**  Anyone — including an attacker — can compute a CRC over forged data.  CRCs here detect
> *accidental* corruption only.  Authenticity is provided separately, by AES-CMAC, and only where it is enabled and a key is available.
> Test `T7`/`E3` demonstrate the difference: a forged record with a *recomputed, valid CRC* passes the CRC check and fails the tag.

## 1. Layers

| Layer | Covers | Code | Detects | Does **not** protect against |
|---|---|---|---|---|
| NAND ECC (P54) | each 528 B sector + PMD | BCH t = 8, GF(2^13) | ≤ 8 raw bit errors corrected; more usually detected | not an integrity primitive; BCH can miscorrect beyond t |
| ECC codeword CRC-16 (P54) | sector ‖ PMD inside the codeword | CRC-16/CCITT-FALSE | BCH miscorrection (residual 2⁻¹⁶) | forgery |
| **Data guard (DIM)** | the 512 B payload, inside the encrypted unit | CRC-32C | corruption anywhere between host and host (wrong key / tweak / bit rot after ECC) with probability 1 − 2⁻³² | forgery, replay of an old valid unit |
| **Physical metadata (PMD)** | slot, generation, LBA, seq | CRC-32C, class-separated | accidental metadata corruption (`E_PMD_CRC`) | forgery (CRC is public) |
| **PMD authentication** | same fields + physical page address | AES-CMAC-64 (SP 800-38B, Tlen 64) with the slot's K_mac | forged / edited / relocated metadata (`E_PMD_AUTH`); wrong K_mac | replay of an old *valid* page+PMD pair (no freshness source) |
| **FTL mapping records** (class `MAP`) | firmware-defined ≤ 32 B body + context | CRC-32C + optional CMAC-64 via the **record-guard service** | as PMD | as PMD |
| **Persistent journal records** (class `JRN`) | likewise | likewise | likewise | likewise |
| Health snapshot (class `HLT` available; the on-chip snapshot itself uses CRC-32C only) | counters | CRC-32C | accidental corruption | forgery, stale-but-valid restore |

The existing FTL (P56) keeps its own CRC-32 (IEEE) spare record; the record guard is an **additional, separately defined**
protection that firmware applies to its metadata records, not a change of the FTL format.

## 2. Definitions

```
CRC-32C(m)  : reflected poly 0x82F63B78, init = xorout = 0xFFFFFFFF            check("123456789") = 0xE3069283
record CRC  : CRC-32C( class(1) ‖ len(1) ‖ body(len) )
record tag  : AES-CMAC_Kmac( class(1) ‖ len(1) ‖ body(len) ‖ ctx(8, LE) )[0:8]
classes     : 0x01 PMD   0x02 MAP   0x03 JRN   0x04 HLT      ctx: e.g. physical page address (binds the record to its place)
```
* **Domain separation.** The class byte and the length are inside both the CRC and the MAC input, so a record of one class can never
  validate as another and a body cannot be extended (test `T7`: "class separation").  The *data guard* is deliberately a plain
  CRC-32C of the payload so it can be checked against any independent CRC-32C implementation.
* **Binding.** `ctx` (the physical page for the PMD) is in the MAC input only: a valid record moved to another location fails
  authentication but still passes its CRC (test `T7`: "context binding").
* **Tag handling.** The full tag is compared in one parallel comparison (no early exit).  A CRC mismatch is reported as corruption
  (`E_PMD_CRC`); a *valid CRC with an invalid tag* is reported as `E_PMD_AUTH` — only an adversary (or a wrong key) produces that
  combination, so it counts toward `SEC_ALARM`.
* **Downgrade protection.** With `CTRL.AUTH_REQ = 1` a PMD whose AUTH flag is absent is rejected as `E_PMD_AUTH` (an attacker cannot strip
  the flag and recompute the CRC).  Test `E3 pmd_downgrade`.

## 3. Why the data guard is encrypted

A CRC stored in the clear next to ciphertext is a fingerprint of the plaintext: a guess ("all zeros", a known header) can be confirmed
offline.  The guard is therefore part of the XTS data unit.  The side effect — the guard cannot be read without the key — is acceptable
because the PMD (cleartext, CRC/CMAC protected) is what firmware needs for mount-time scans.

## 4. Quantified residuals (random corruption; not adversarial)

| Event | Probability |
|---|---|
| DIM guard misses a random corruption of the decrypted unit | 2⁻³² |
| PMD CRC-32C misses a random corruption | 2⁻³² |
| ECC miscorrection (> t errors) accepted by CRC-16 | ≈ P(miscorrect) × 2⁻¹⁶ (P54 docs/04) |
| Forging a PMD tag without the key | 2⁻⁶⁴ per attempt (SP 800-38B, Tlen 64); the alarm limit bounds the number of attempts the firmware tolerates |

## 5. Record-guard service (firmware-visible)

`RG_CTRL` (class, length ≤ 32, key slot, AUTH, VERIFY, START) with `RG_BODY0..7`, `RG_CTX_HI/LO`, `RG_CRC`, `RG_TAG_HI/LO`, `RG_STATUS`
(`DONE`, `CRC_OK`, `TAG_OK`, `ERR`, `KEY_INVALID`).  SEAL fills `RG_CRC` / `RG_TAG`; VERIFY compares.  Failed verifications count as
`EV_REC_FAIL`.  The service shares the CMAC engine with key derivation and the pipeline under a hardware interlock (`E_BUSY` / "refused").
