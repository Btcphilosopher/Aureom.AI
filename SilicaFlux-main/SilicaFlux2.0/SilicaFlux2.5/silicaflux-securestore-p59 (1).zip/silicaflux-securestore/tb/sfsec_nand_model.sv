// =============================================================================
// SecureStore testbench :: sfsec_nand_model -- behavioural NAND raw-page store with fault injection
//   * pages of PAGE_BYTES (data area then spare); an erased page reads as all 0xFF
//   * program: accepts the byte stream in column order; commits at the last byte unless aborted / failed
//   * read: streams the page SPARE FIRST (as the P54 decoder requires: 00h/30h, spare, 05h/E0h, data)
//   * injection: flip bits of a stored page (tb access to `mem`), fail the next program, fail the next read
// Behavioural model for verification only; it is not NANDLab and models no timing.
// =============================================================================
`default_nettype none

module sfsec_nand_model #(
  parameter int NPAGES = 64,
  parameter int PAGE_DATA = 528,
  parameter int PAGE_SPARE = 48
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        cmd_valid,
  output logic             cmd_ready,
  input  wire logic        cmd_read,
  input  wire logic [31:0] cmd_ppa,
  input  wire logic        wd_valid,
  output logic             wd_ready,
  input  wire logic [7:0]  wd_data,
  input  wire logic        wd_last,
  output logic             rd_valid,
  input  wire logic        rd_ready,
  output logic [7:0]       rd_data,
  output logic             rd_last,
  input  wire logic        abort,
  output logic             done_valid,
  output logic             done_fail
);
  localparam int PB = PAGE_DATA + PAGE_SPARE;
  logic [7:0] mem [NPAGES][PB];
  logic       programmed [NPAGES];
  // fault injection controls (driven by the testbench)
  logic       fail_next_program = 1'b0;
  logic       fail_next_read    = 1'b0;
  logic       hang_next_read    = 1'b0;   // accept the command, then never answer (tests the read watchdog)
  int         stall_pct         = 0;      // random back-pressure percentage
  int         n_programs = 0, n_reads = 0, n_aborts = 0;

  typedef enum logic [2:0] { N_IDLE, N_WR, N_RD, N_DONE } nstate_t;
  nstate_t st;
  logic [31:0] page_q;
  int          idx_q;
  logic [7:0]  buf_q [PB];
  logic        failw_q, failr_q, hang_q;

  assign cmd_ready = (st == N_IDLE);
  assign wd_ready  = (st == N_WR) && (($urandom % 100) >= stall_pct);
  assign rd_valid  = (st == N_RD) && !failr_q && !hang_q;
  assign rd_last   = (st == N_RD) && (idx_q == PB - 1);
  logic [31:0] pidx;
  assign pidx = page_q % NPAGES;
  always_comb begin
    int j;
    j = idx_q;
    rd_data = 8'hFF;
    if (st == N_RD) begin
      // spare first
      if (j < PAGE_SPARE) rd_data = programmed[pidx] ? mem[pidx][PAGE_DATA + j] : 8'hFF;
      else                rd_data = programmed[pidx] ? mem[pidx][j - PAGE_SPARE] : 8'hFF;
    end
  end

  initial begin
    for (int p = 0; p < NPAGES; p++) begin programmed[p] = 1'b0; for (int b = 0; b < PB; b++) mem[p][b] = 8'hFF; end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= N_IDLE; idx_q <= 0; page_q <= '0; done_valid <= 1'b0; done_fail <= 1'b0; failw_q <= 1'b0; failr_q <= 1'b0;
    end else begin
      done_valid <= 1'b0;
      if (abort && st != N_IDLE) begin st <= N_IDLE; n_aborts <= n_aborts + 1; end
      else case (st)
        N_IDLE: if (cmd_valid) begin
          page_q <= cmd_ppa; idx_q <= 0;
          failw_q <= fail_next_program; failr_q <= fail_next_read; hang_q <= hang_next_read; hang_next_read <= 1'b0;
          if (cmd_read) begin st <= N_RD; fail_next_read <= 1'b0; n_reads <= n_reads + 1; end
          else begin st <= N_WR; fail_next_program <= 1'b0; end
        end
        N_WR: if (wd_valid && wd_ready) begin
          buf_q[idx_q] <= wd_data;
          idx_q <= idx_q + 1;
          if (wd_last) st <= N_DONE;
        end
        N_RD: begin
          if (failr_q) begin done_valid <= 1'b1; done_fail <= 1'b1; st <= N_IDLE; end
          else if (hang_q) begin end
          else if (rd_valid && rd_ready) begin
            idx_q <= idx_q + 1;
            if (rd_last) begin done_valid <= 1'b1; done_fail <= 1'b0; st <= N_IDLE; end
          end
        end
        N_DONE: begin
          if (!failw_q) begin
            for (int b = 0; b < PB; b++) mem[pidx][b] <= buf_q[b];
            programmed[pidx] <= 1'b1; n_programs <= n_programs + 1;
          end
          done_valid <= 1'b1; done_fail <= failw_q; st <= N_IDLE;
        end
        default: st <= N_IDLE;
      endcase
    end
  end
endmodule

`default_nettype wire
