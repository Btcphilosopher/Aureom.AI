// =============================================================================
// SecureStore :: tb_top_regs -- tests of the primary RTL silicaflux_storage_security through its REGISTER interface
//
//  T1  identification, configuration, honest capability flags (no eFuse / OTP / tamper-resistant storage)
//  T2  privilege: unprivileged master / unauthenticated firmware / lockdown / invalid lifecycle are refused
//  T3  key management through KEY_CMD: IMPORT / GENERATE / DERIVE / INVALIDATE and the lifecycle matrix
//      (DEV, PROV, PROD, RECOVERY), magic, busy interlock, generation rollback, staging-register hygiene
//  T4  telemetry + RAS: corrected-bit counts, decoder activity, failure classes, history, event log, IRQ, SEC_ALARM
//  T5  health: temperature, thermal warning, wear statistics, lifetime snapshot capture / restore (independent CRC)
//  T6  sanitise / secure reset: key erasure, SAN_STATUS honesty, SEC_CMD, external pin, data inaccessible afterwards
//  T7  record-guard service (PMD / MAP / JRN / HLT): CRC-32C + CMAC-64 vs the model; CRC is not authentication
//  T8  controller reset: telemetry (power-on domain) survives, volatile keys do not
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_top_regs;
  import sfsec_pkg::*;
  import sfsec_regs_pkg::*;
  localparam int NPAGES = 64;
  localparam int PB = 576;

  logic clk = 1'b0, rst_n = 1'b0, por_rst_n = 1'b0;
  always #5 clk = ~clk;
  int errors = 0, checks = 0;
  string vecdir;
  task automatic chk(input bit cond, input string what);
    begin checks++; if (!cond) begin errors++; if (errors <= 40) $display("FAIL: %s (t=%0t)", what, $time); end end
  endtask

  // ---------------- DUT ports
  logic rb_sel = 1'b0, rb_we = 1'b0, rb_priv = 1'b0, rb_err;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic [3:0]  sb_lc = LC_DEV;
  logic        sb_exec = 1'b1, sb_lock = 1'b0, sb_dbg = 1'b0;
  logic        prk_valid = 1'b0, ent_req, ent_valid = 1'b0, ext_zero = 1'b0;
  logic [255:0] prk = '0;
  logic [127:0] ent_data = '0;
  logic cmd_valid = 1'b0, cmd_ready, cmd_op = 1'b0;
  logic [7:0] cmd_tag = '0; logic [63:0] cmd_lba = '0; logic [31:0] cmd_ppa = '0; logic [47:0] cmd_seq = '0; logic [1:0] cmd_slot = '0;
  logic hw_valid = 1'b0, hw_ready, hw_err = 1'b0, hw_poison = 1'b0, dma_err = 1'b0;
  logic [31:0] hw_data = '0;
  logic hr_valid, hr_ready = 1'b0, hr_last;
  logic [31:0] hr_data;
  logic rsp_valid, rsp_ready = 1'b0, rsp_op;
  logic [7:0] rsp_tag, rsp_err; logic [31:0] rsp_info;
  logic n_cmd_valid, n_cmd_ready, n_cmd_read, n_wd_valid, n_wd_ready, n_wd_last, n_rd_valid, n_rd_ready, n_rd_last, n_abort, n_done_valid, n_done_fail;
  logic [31:0] n_cmd_ppa; logic [7:0] n_wd_data, n_rd_data;
  logic therm_warn = 1'b0, temp_valid = 1'b0, recov = 1'b0, badblk = 1'b0, erase = 1'b0;
  logic [15:0] temp_code = '0;
  logic irq, ras_warn, ras_err, ras_fatal;

  silicaflux_storage_security #(.DU_BYTES(512), .NS(4)) dut (
    .clk, .rst_n, .por_rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .rb_priv_i(rb_priv),
    .sb_lc_i(sb_lc), .sb_exec_open_i(sb_exec), .sb_lockdown_i(sb_lock), .sb_debug_en_i(sb_dbg),
    .prk_valid_i(prk_valid), .prk_i(prk), .ent_req_o(ent_req), .ent_valid_i(ent_valid), .ent_data_i(ent_data),
    .ext_zeroize_i(ext_zero),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_op_i(cmd_op), .cmd_tag_i(cmd_tag), .cmd_lba_i(cmd_lba),
    .cmd_ppa_i(cmd_ppa), .cmd_seq_i(cmd_seq), .cmd_slot_i(cmd_slot),
    .hw_valid_i(hw_valid), .hw_ready_o(hw_ready), .hw_data_i(hw_data), .hw_err_i(hw_err), .hw_poison_i(hw_poison),
    .dma_err_i(dma_err), .hr_valid_o(hr_valid), .hr_ready_i(hr_ready), .hr_data_o(hr_data), .hr_last_o(hr_last),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_op_o(rsp_op), .rsp_tag_o(rsp_tag), .rsp_err_o(rsp_err),
    .rsp_info_o(rsp_info),
    .nand_cmd_valid_o(n_cmd_valid), .nand_cmd_ready_i(n_cmd_ready), .nand_cmd_read_o(n_cmd_read), .nand_cmd_ppa_o(n_cmd_ppa),
    .nand_wd_valid_o(n_wd_valid), .nand_wd_ready_i(n_wd_ready), .nand_wd_data_o(n_wd_data), .nand_wd_last_o(n_wd_last),
    .nand_rd_valid_i(n_rd_valid), .nand_rd_ready_o(n_rd_ready), .nand_rd_data_i(n_rd_data), .nand_rd_last_i(n_rd_last),
    .nand_abort_o(n_abort), .nand_done_valid_i(n_done_valid), .nand_done_fail_i(n_done_fail),
    .therm_warn_i(therm_warn), .temp_valid_i(temp_valid), .temp_code_i(temp_code), .recovery_evt_i(recov),
    .bad_block_evt_i(badblk), .erase_evt_i(erase), .irq_o(irq), .ras_warn_o(ras_warn), .ras_err_o(ras_err), .ras_fatal_o(ras_fatal));

  sfsec_nand_model #(.NPAGES(NPAGES)) nd (.clk, .rst_n, .cmd_valid(n_cmd_valid), .cmd_ready(n_cmd_ready), .cmd_read(n_cmd_read),
    .cmd_ppa(n_cmd_ppa), .wd_valid(n_wd_valid), .wd_ready(n_wd_ready), .wd_data(n_wd_data), .wd_last(n_wd_last),
    .rd_valid(n_rd_valid), .rd_ready(n_rd_ready), .rd_data(n_rd_data), .rd_last(n_rd_last), .abort(n_abort),
    .done_valid(n_done_valid), .done_fail(n_done_fail));

  always @(negedge clk) begin
    ent_valid <= ent_req;
    if (ent_req) ent_data <= {$urandom, $urandom, $urandom, $urandom};
  end

  // ---------------- register driver (negedge drive, settle, sample)
  logic        last_err;
  logic [31:0] last_rd;
  task automatic wreg(input [11:0] a, input [31:0] d, input bit priv = 1'b1);
    begin
      @(negedge clk); rb_sel = 1'b1; rb_we = 1'b1; rb_addr = a; rb_wdata = d; rb_priv = priv;
      #1 last_err = rb_err;
      @(negedge clk); rb_sel = 1'b0; rb_we = 1'b0; rb_priv = 1'b0;
    end
  endtask
  task automatic rreg(input [11:0] a, input bit priv = 1'b1);
    begin
      @(negedge clk); rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a; rb_priv = priv;
      #1 last_rd = rb_rdata; last_err = rb_err;
      @(negedge clk); rb_sel = 1'b0; rb_priv = 1'b0;
    end
  endtask

  // ---------------- vectors
  localparam int PIPE_W = 76, NEG_W = 78;
  logic [127:0] vp [0:PIPE_W*24-1];
  logic [127:0] vn [0:NEG_W*14-1];
  logic [127:0] vr [0:6*48-1];
  logic [31:0]  hl [0:31];
  logic [31:0]  payw [0:127];
  logic [31:0]  rdw  [0:127];
  int           rd_n;

  function automatic logic [31:0] bsw32(input logic [31:0] x); return {x[7:0], x[15:8], x[23:16], x[31:24]}; endfunction

  task automatic key_load_stage(input logic [255:0] k1, input logic [255:0] k2, input logic [127:0] mac, input logic [127:0] salt, input [7:0] gen);
    begin
      for (int i = 0; i < 8; i++) begin wreg(R_STG_K1_0 + 12'(4*i), k1[255 - 32*i -: 32]); wreg(R_STG_K2_0 + 12'(4*i), k2[255 - 32*i -: 32]); end
      for (int i = 0; i < 4; i++) begin wreg(R_STG_MAC0 + 12'(4*i), mac[127 - 32*i -: 32]); wreg(R_STG_SALT0 + 12'(4*i), salt[127 - 32*i -: 32]); end
      wreg(R_STG_GEN, {24'h0, gen});
    end
  endtask

  logic [7:0] kerr;
  // run a key command through KEY_CMD, wait for completion, return the error code seen in KEY_STATUS
  task automatic key_cmd(input [2:0] op, input [1:0] slot, input bit k256, output [7:0] err);
    int n;
    begin
      wreg(R_KEY_CMD, {16'h5EC0, 3'b0, k256, 2'b0, slot, 5'b0, op});
      n = 0;
      do begin rreg(R_KEY_STATUS); n++; end while (!last_rd[1] && n < 4000);
      err = last_rd[15:8];
      chk(n < 4000, "KEY_STATUS DONE reached");
    end
  endtask

  task automatic import_vec(input int base, output [7:0] err);
    logic [127:0] h;
    begin
      h = vp[base];
      key_load_stage({vp[base+3], vp[base+4]}, {vp[base+5], vp[base+6]}, vp[base+7], '0, h[7:0]);
      key_cmd(3'd1, h[33:32], h[64], err);
    end
  endtask

  // data path helpers
  task automatic issue(input bit op, input [7:0] tag, input [63:0] lba, input [31:0] ppa, input [47:0] seq, input [1:0] slot);
    begin
      @(negedge clk); while (!cmd_ready) @(negedge clk);
      cmd_op = op; cmd_tag = tag; cmd_lba = lba; cmd_ppa = ppa; cmd_seq = seq; cmd_slot = slot; cmd_valid = 1'b1;
      @(negedge clk); cmd_valid = 1'b0;
    end
  endtask
  task automatic run_write(output [7:0] err, output [31:0] info);
    int w; bit pend;
    begin
      w = 0; pend = 1'b0; hw_valid = 1'b0;
      forever begin
        @(negedge clk);
        if (rsp_valid) begin err = rsp_err; info = rsp_info; rsp_ready = 1'b1; @(negedge clk); rsp_ready = 1'b0; hw_valid = 1'b0; break; end
        if (pend) begin pend = 1'b0; w++; hw_valid = 1'b0; end
        if (!hw_valid && w < 128) begin hw_valid = 1'b1; hw_data = payw[w]; end
        if (hw_valid && hw_ready) pend = 1'b1;
      end
    end
  endtask
  task automatic run_read(output [7:0] err, output [31:0] info);
    int cnt;
    begin
      rd_n = 0; cnt = 0; hr_ready = 1'b0;
      forever begin
        @(negedge clk);
        hr_ready = (($urandom % 4) != 0);
        if (hr_valid && hr_ready) begin rdw[rd_n] = hr_data; rd_n++; end
        if (rsp_valid) begin err = rsp_err; info = rsp_info; rsp_ready = 1'b1; @(negedge clk); rsp_ready = 1'b0; hr_ready = 1'b0; break; end
        cnt++; if (cnt > 300000) begin chk(1'b0, "read timeout"); err = 8'hFF; info = 0; break; end
      end
    end
  endtask
  task automatic load_pay(input int base);
    begin
      for (int b = 0; b < 32; b++) for (int k = 0; k < 4; k++) payw[4*b + k] = bsw32(vp[base + 8 + b][127 - 32*k -: 32]);
    end
  endtask
  function automatic bit pay_ok(input int base);
    bit ok; begin
      ok = (rd_n == 128);
      for (int b = 0; b < 32; b++) for (int k = 0; k < 4; k++) if (rdw[4*b + k] !== bsw32(vp[base + 8 + b][127 - 32*k -: 32])) ok = 1'b0;
      return ok; end
  endfunction
  task automatic wr_vec(input int base, output [7:0] err, output [31:0] info);
    logic [127:0] h;
    begin h = vp[base]; load_pay(base); issue(1'b0, 8'(base), vp[base+1][127:64], vp[base+1][63:32], {vp[base+2][15:0], vp[base+1][31:0]}, h[33:32]); run_write(err, info); end
  endtask
  task automatic rd_vec(input int base, output [7:0] err, output [31:0] info);
    logic [127:0] h;
    begin h = vp[base]; issue(1'b1, 8'(base), vp[base+1][127:64], vp[base+1][63:32], {vp[base+2][15:0], vp[base+1][31:0]}, h[33:32]); run_read(err, info); end
  endtask
  task automatic flip(input int ppa, input int n);
    int pos, cnt; logic [1023:0] seen;
    begin
      cnt = 0; seen = '0;
      while (cnt < n) begin
        pos = $urandom % (PB * 8);
        if ((pos / 8) == 528 || seen[pos % 1024] === 1'b1) continue;
        seen[pos % 1024] = 1'b1; nd.mem[ppa % NPAGES][pos / 8] = nd.mem[ppa % NPAGES][pos / 8] ^ (8'h01 << (pos % 8)); cnt++;
      end
    end
  endtask
  task automatic do_reset(input bit por);
    begin
      @(negedge clk); rst_n = 1'b0; if (por) por_rst_n = 1'b0; repeat (4) @(negedge clk); rst_n = 1'b1; por_rst_n = 1'b1; repeat (4) @(negedge clk);
    end
  endtask
  function automatic logic [31:0] evaddr(input int e); return R_EV_CNT_ECC_CORR + 12'(4*e); endfunction
  task automatic evcnt(input int e, output logic [31:0] v); begin rreg(evaddr(e)); v = last_rd; end endtask

  task automatic rg_wait(output [31:0] st);
    int n;
    begin
      n = 0;
      do begin rreg(R_RG_STATUS); n++; end while (!last_rd[1] && n < 3000);
      st = last_rd;
      chk(n < 3000, "RG_STATUS DONE reached");
    end
  endtask
  function automatic logic [31:0] rgctrl(input [1:0] slot, input [5:0] len, input [7:0] cls, input bit auth, input bit ver, input bit start);
    return {6'b0, slot, 2'b0, len, cls, 5'b0, auth, ver, start};
  endfunction

  logic [7:0]  e8, er;
  logic [31:0] i32, v1, v2;
  int base;

  initial begin
    logic [127:0] h;
    if (!$value$plusargs("VECDIR=%s", vecdir)) vecdir = "vectors";
    $readmemh({vecdir, "/pipe.memh"}, vp);
    $readmemh({vecdir, "/neg.memh"}, vn);
    $readmemh({vecdir, "/rec.memh"}, vr);
    $readmemh({vecdir, "/hl_image.memh"}, hl);
    repeat (4) @(negedge clk);
    rst_n = 1'b1; por_rst_n = 1'b1;
    repeat (4) @(negedge clk);

    // ============================================================ T1
    $display("[T1] identification / configuration / honest capability flags");
    rreg(R_ID, 1'b0);       chk(last_rd == 32'h5346_5353 && !last_err, "ID readable by any master");
    rreg(R_VERSION, 1'b0);  chk(last_rd == 32'h0001_0000, "VERSION");
    rreg(R_CFG, 1'b0);      chk(last_rd[7:0] == 8'd4 && last_rd[15:8] == 8'd32 && last_rd[31:24] == 8'd24 && last_rd[20:16] == 5'h1F, "CFG");
    rreg(R_CAPS, 1'b0);
    chk(last_rd[5:0] == 6'h3F, "CAPS: XTS128/256, CRC32C, CMAC, KDF, ECC");
    chk(last_rd[11:8] == 4'h0, "CAPS: no PRK store, no entropy source, no eFuse/OTP, no tamper-resistant key storage implemented");
    rreg(R_FAULT_LIFE, 1'b0); chk(!last_err, "telemetry readable (HOST_TELEMETRY default on)");

    // ============================================================ T2
    $display("[T2] privilege / lifecycle gating of secure-control registers");
    evcnt(EV_LIFECYCLE, v1);
    wreg(R_CTRL, 32'h0000_0023, 1'b0);               chk(last_err, "T2 unprivileged master write refused (bus error)");
    sb_exec = 1'b0;
    wreg(R_CTRL, 32'h0000_0023, 1'b1);               chk(last_err, "T2 privileged master but firmware not authenticated -> refused");
    sb_dbg = 1'b1; sb_lc = LC_DEV;
    wreg(R_CTRL, 32'h0000_0023, 1'b1);               chk(!last_err, "T2 DEV lifecycle + debug: privileged access allowed (documented DEV exception)");
    sb_dbg = 1'b0; sb_lc = LC_PROD;
    wreg(R_CTRL, 32'h0000_0023, 1'b1);               chk(last_err, "T2 PROD without authenticated firmware refused even with debug off");
    sb_dbg = 1'b1;
    wreg(R_CTRL, 32'h0000_0023, 1'b1);               chk(last_err, "T2 debug gives nothing outside DEV");
    sb_exec = 1'b1; sb_dbg = 1'b0; sb_lc = LC_PROD;
    wreg(R_CTRL, 32'h0000_0023, 1'b1);               chk(!last_err, "T2 PROD + authenticated firmware: allowed");
    sb_lock = 1'b1;
    wreg(R_CTRL, 32'h0000_0023, 1'b1);               chk(last_err, "T2 SecureSilicon LOCKDOWN refuses everything");
    rreg(R_LC_STATUS, 1'b1);                         chk(last_rd[4] && !last_rd[12], "T2 lockdown: data path not allowed");
    sb_lock = 1'b0; sb_lc = 4'd7;
    rreg(R_LC_STATUS, 1'b0);                         chk(last_rd[4] && !last_rd[12], "T2 invalid lifecycle treated as lockdown");
    sb_lc = LC_PROD;
    rreg(R_KEY_INFO, 1'b0);                          chk(last_err && last_rd == 0, "T2 key-related register unreadable by an unprivileged master");
    rreg(R_SALT0, 1'b0);                             chk(last_err, "T2 salt unreadable by an unprivileged master");
    wreg(R_ID, 32'h1, 1'b1);                         chk(last_err, "T2 write to a read-only register refused");
    rreg(12'h7F0, 1'b1);                             chk(last_err, "T2 unmapped address -> bus error");
    rreg(R_CTRL + 12'd2, 1'b1);                      chk(last_err, "T2 unaligned access -> bus error");
    evcnt(EV_LIFECYCLE, v2);
    chk(v2 - v1 >= 7, $sformatf("T2 refused accesses counted as EV_LIFECYCLE (+%0d)", v2 - v1));
    sb_lc = LC_DEV; wreg(R_CTRL, 32'h0000_0023); do_reset(1'b0); sb_lc = LC_DEV;

    // ============================================================ T3
    $display("[T3] key management: lifecycle matrix, magic, interlock, generation, hygiene");
    base = 0;
    sb_lc = LC_DEV;  import_vec(base, e8);                     chk(e8 == E_NONE, "T3 DEV: IMPORT allowed");
    rreg(R_KEY_SEL); wreg(R_KEY_SEL, 32'(vp[base][33:32])); rreg(R_KEY_INFO);
    chk(last_rd[0] && last_rd[2] === 1'b0 && last_rd[15:8] == vp[base][7:0], "T3 KEY_INFO: valid, imported, generation");
    rreg(R_STG_K1_0); chk(last_rd == 0, "T3 staging registers are write-only (read as zero)");
    chk(dut.stg_k1[0] === 32'h0 && dut.stg_k2[3] === 32'h0 && dut.stg_mac[1] === 32'h0, "T3 staging registers wiped after the command");
    sb_lc = LC_PROV; base = PIPE_W; import_vec(base, e8);      chk(e8 == E_NONE, "T3 PROV: IMPORT allowed");
    sb_lc = LC_PROD; base = 2 * PIPE_W; import_vec(base, e8);  chk(e8 == E_LIFECYCLE, "T3 PROD: clear-key IMPORT refused");
    rreg(R_KEY_INFO); wreg(R_KEY_SEL, 32'(vp[base][33:32]));
    wreg(R_KEY_CMD, 32'h0000_0001);                            // wrong magic
    rreg(R_KEY_STATUS); chk(last_rd[2] && last_rd[15:8] == E_RANGE, "T3 missing magic -> E_RANGE");
    // PROD: GENERATE allowed (platform provides PRK + entropy)
    prk = 256'hD00D_0000_1111_2222_3333_4444_5555_6666_7777_8888_9999_AAAA_BBBB_CCCC_DDDD_EEEE; prk_valid = 1'b1;
    key_cmd(3'd2, 2'd3, 1'b1, e8);                             chk(e8 == E_NONE, "T3 PROD: GENERATE allowed");
    rreg(R_KEY_SEL); wreg(R_KEY_SEL, 32'd3); rreg(R_KEY_INFO); chk(last_rd[0] && last_rd[1] && last_rd[2], "T3 generated slot: valid, K256, DERIVED");
    rreg(R_SALT0); v1 = last_rd; rreg(R_SALT1); v2 = last_rd; chk(v1 != 0 || v2 != 0, "T3 salt exported to privileged reader");
    prk_valid = 1'b0; key_cmd(3'd2, 2'd2, 1'b0, e8);           chk(e8 == E_PRK, "T3 GENERATE without PRK -> E_PRK");
    prk_valid = 1'b1;
    // stale / rollback: IMPORT with a generation below the slot's
    sb_lc = LC_DEV; h = vp[0];
    key_load_stage(256'h1111 << 100, 256'h2222 << 100, 128'h3, '0, 8'd0);
    key_cmd(3'd1, h[33:32], 1'b0, e8); chk(e8 == E_RANGE, "T3 generation rollback refused");
    // RECOVERY: data path closed, GENERATE refused, INVALIDATE allowed
    sb_lc = LC_RECOVERY;
    key_cmd(3'd2, 2'd2, 1'b0, e8);                             chk(e8 == E_LIFECYCLE, "T3 RECOVERY: GENERATE refused");
    base = 0; wr_vec(base, e8, i32);                           chk(e8 == E_LIFECYCLE, $sformatf("T3 RECOVERY: data path closed (got %0d)", e8));
    key_cmd(3'd4, 2'd3, 1'b0, e8);                             chk(e8 == E_NONE, "T3 RECOVERY: INVALIDATE allowed (crypto-erase stays possible)");
    sb_lc = LC_DEV;
    // busy interlock: key command while a data command is in flight
    base = 0; load_pay(base);
    h = vp[base];
    issue(1'b0, 8'd1, vp[base+1][127:64], vp[base+1][63:32], 48'd1, h[33:32]);
    wreg(R_KEY_CMD, {16'h5EC0, 3'b0, 1'b0, 2'b0, 2'd2, 5'b0, 3'd4});
    rreg(R_KEY_STATUS); chk(last_rd[2] && last_rd[15:8] == E_BUSY, "T3 key command refused while the data path is busy (E_BUSY)");
    run_write(e8, i32); chk(e8 == E_NONE, "T3 the in-flight write still completes");

    // ============================================================ T4
    $display("[T4] telemetry / RAS: counters, history, log, IRQ, security alarm");
    do_reset(1'b1);
    sb_lc = LC_DEV; wreg(R_TEL_CTRL, 32'h7);
    base = 4 * PIPE_W; import_vec(base, e8);
    wr_vec(base, e8, i32); chk(e8 == E_NONE, "T4 write");
    rd_vec(base, e8, i32); chk(e8 == E_NONE && pay_ok(base), "T4 read");
    rreg(R_WR_OK); chk(last_rd == 1, "T4 WR_OK");  rreg(R_RD_OK); chk(last_rd == 1, "T4 RD_OK");
    rreg(R_ECC_PAGES_DEC); chk(last_rd == 1, "T4 ECC decoder activity: pages decoded");
    h = vp[base]; v1 = 0;
    for (int n = 1; n <= 6; n++) begin
      wr_vec(base, e8, i32); flip(int'(vp[base+1][63:32]), n); v1 += n;
      rd_vec(base, e8, i32); chk(e8 == E_NONE && pay_ok(base) && i32[15:0] == 16'(n), "T4 correction");
    end
    rreg(R_ECC_CORR_BITS); chk(last_rd == v1, $sformatf("T4 ECC_CORR_BITS = %0d (got %0d)", v1, last_rd));
    evcnt(EV_ECC_CORR, v2); chk(v2 == 6, "T4 EV_CNT_ECC_CORR = 6 codewords");
    rreg(R_ECC_MAX_FLIPS); chk(last_rd == 6, "T4 ECC_MAX_FLIPS");
    // uncorrectable
    wr_vec(base, e8, i32); flip(int'(vp[base+1][63:32]), 15); rd_vec(base, e8, i32);
    chk(e8 != E_NONE && rd_n == 0, "T4 uncorrectable page: explicit error");
    rreg(R_FAULT_HIST); chk(last_rd[EV_ECC_UNCORR] || last_rd[EV_ECC_INTEG] || last_rd[EV_DI_FAIL], "T4 history records the failure class");
    // crafted pages: every failure class lands in its own counter, history bit and log entry
    do_reset(1'b0);
    wreg(R_TEL_CTRL, 32'h7);                      // clear session counters / history / log
    wreg(R_SEC_ALARM_LIMIT, 32'd3); wreg(R_IRQ_ENABLE, 32'hF); wreg(R_IRQ_STATUS, 32'hF);
    begin : neg_suite
      int exp_di, exp_pmd, exp_auth, exp_key, exp_lba, nb;
      logic [127:0] hn;
      exp_di = 0; exp_pmd = 0; exp_auth = 0; exp_key = 0; exp_lba = 0;
      for (int r = 0; r < 14; r++) begin
        nb = r * NEG_W; hn = vn[nb];
        do_reset(1'b0);                           // volatile keys / generations restart; telemetry persists
        key_load_stage({vn[nb+3], vn[nb+4]}, {vn[nb+5], vn[nb+6]}, vn[nb+7], '0, hn[7:0]);
        key_cmd(3'd1, hn[33:32], hn[64], e8); chk(e8 == E_NONE, "T4 neg import");
        for (int j = 0; j < PB; j++) begin
          logic [127:0] w; w = vn[nb + 40 + j/16];
          nd.mem[vn[nb+1][63:32] % NPAGES][j] = w[127 - 8*(j%16) -: 8];
        end
        nd.programmed[vn[nb+1][63:32] % NPAGES] = 1'b1;
        wreg(R_CTRL, 32'h33 | (hn[67] ? 32'h4 : 32'h0));      // IRQ_EN on
        h = vn[nb + 76];
        issue(1'b1, 8'(200 + r), h[127:64], vn[nb+1][63:32], 48'd0, hn[33:32]); run_read(e8, i32);
        chk(e8 == h[63:56], $sformatf("T4 neg case %0d expected %0d got %0d", r, h[63:56], e8));
        case (e8)
          E_DI_GUARD, E_DI_REFTAG, E_DI_FORMAT: exp_di++;
          E_PMD_CRC, E_PMD_FORMAT: exp_pmd++;
          E_PMD_AUTH: exp_auth++;
          E_KEY_MISMATCH, E_KEY_INVALID: exp_key++;
          E_LBA_MISMATCH: exp_lba++;
          default: ;
        endcase
      end
      evcnt(EV_DI_FAIL, v1);   chk(v1 == exp_di,   $sformatf("T4 EV_CNT_DI_FAIL %0d == %0d", v1, exp_di));
      evcnt(EV_PMD_FAIL, v1);  chk(v1 == exp_pmd,  $sformatf("T4 EV_CNT_PMD_FAIL %0d == %0d", v1, exp_pmd));
      evcnt(EV_AUTH_FAIL, v1); chk(v1 == exp_auth && exp_auth == 3, $sformatf("T4 EV_CNT_AUTH_FAIL %0d == %0d", v1, exp_auth));
      evcnt(EV_KEY_FAIL, v1);  chk(v1 == exp_key,  $sformatf("T4 EV_CNT_KEY_FAIL %0d == %0d", v1, exp_key));
      evcnt(EV_LBA_FAIL, v1);  chk(v1 == exp_lba,  $sformatf("T4 EV_CNT_LBA_FAIL %0d == %0d", v1, exp_lba));
      rreg(R_FAULT_HIST);
      chk(last_rd[EV_DI_FAIL] && last_rd[EV_PMD_FAIL] && last_rd[EV_AUTH_FAIL] && last_rd[EV_KEY_FAIL] && last_rd[EV_LBA_FAIL],
          "T4 FAULT_HIST has every failure class");
    end
    rreg(R_STATUS); chk(last_rd[11] === 1'b1, "T4 SEC_ALARM latched after 3 authentication failures");
    chk(ras_fatal === 1'b1 && irq === 1'b1, "T4 ras_fatal + irq asserted by the security alarm");
    rreg(R_LOG_STAT); v1 = last_rd[7:0]; chk(v1 >= 5, $sformatf("T4 event log filled (%0d entries)", v1));
    begin : logscan
      bit found; int guard;
      found = 1'b0;
      for (guard = 0; guard < 64; guard++) begin
        rreg(R_LOG_STAT); if (last_rd[7:0] == 0) break;
        rreg(R_LOG_W0);
        if (last_rd[15:8] >= 8'd200 && last_rd[23:16] != 8'd0) begin
          found = 1'b1;
          chk(last_rd[4:0] < 5'(NEV), "T4 log entry: event index valid");
        end
        wreg(R_LOG_POP, 32'd1);
      end
      chk(found, "T4 event log carries entries with command tag and error code");
      rreg(R_LOG_STAT); chk(last_rd[7:0] == 0, "T4 log drained by pops");
    end
    wreg(R_TEL_CTRL, 32'h8);                       // acknowledge the alarm
    wreg(R_IRQ_STATUS, 32'hF);
    rreg(R_STATUS); chk(last_rd[11] === 1'b0, "T4 alarm acknowledged");
    chk(irq === 1'b0 && ras_fatal === 1'b0, "T4 irq / fatal deasserted after acknowledge");
    wreg(R_TEL_CTRL, 32'h2); rreg(R_FAULT_HIST); chk(last_rd == 0, "T4 history cleared on request");
    wreg(R_CTRL, 32'h23);

    // ============================================================ T5
    $display("[T5] health telemetry: temperature, thermal warnings, wear, lifetime snapshot");
    do_reset(1'b1);
    rreg(R_TEMP_STATUS); chk(last_rd[0] == 1'b0, "T5 no temperature reading yet");
    @(negedge clk); temp_valid = 1'b1; temp_code = 16'h0A00; @(negedge clk); temp_code = 16'h0B10; @(negedge clk); temp_code = 16'h0900; @(negedge clk); temp_valid = 1'b0;
    rreg(R_TEMP_CUR);  chk(last_rd == 32'h0900, "T5 TEMP_CUR");
    rreg(R_TEMP_MAX);  chk(last_rd == 32'h0B10, "T5 TEMP_MAX");
    rreg(R_TEMP_MIN);  chk(last_rd == 32'h0900, "T5 TEMP_MIN");
    @(negedge clk); therm_warn = 1'b1; repeat (4) @(negedge clk);
    rreg(R_FAULT_CUR); chk(last_rd[0] === 1'b1, "T5 CURRENT fault: thermal warning asserted");
    therm_warn = 1'b0; repeat (3) @(negedge clk);
    rreg(R_FAULT_CUR); chk(last_rd[0] === 1'b0, "T5 CURRENT fault clears with the condition");
    evcnt(EV_THERM_WARN, v1); chk(v1 == 1, "T5 thermal warning counted once (rising edge)");
    rreg(R_FAULT_HIST); chk(last_rd[EV_THERM_WARN], "T5 HISTORICAL fault status remembers it");
    @(negedge clk); recov = 1'b1; badblk = 1'b1; erase = 1'b1; @(negedge clk); recov = 1'b0; badblk = 1'b0; erase = 1'b0; @(negedge clk);
    evcnt(EV_RECOVERY, v1); chk(v1 == 1, "T5 recovery event counted");
    evcnt(EV_BAD_BLOCK, v1); chk(v1 == 1, "T5 bad block counted");
    evcnt(EV_ERASE, v1); chk(v1 == 1, "T5 erase counted");
    // wear statistics are firmware-published
    wreg(R_WEAR_ERASE_MAX, 32'd912); wreg(R_WEAR_ERASE_MIN, 32'd4); wreg(R_WEAR_ERASE_TOTAL, 32'd123456); wreg(R_WEAR_BLOCKS, 32'd2048);
    wreg(R_BAD_BLOCKS_FACTORY, 32'd9); wreg(R_BAD_BLOCKS_RUNTIME, 32'd2); wreg(R_RESERVED_TOTAL, 32'd64); wreg(R_RESERVED_REMAIN, 32'd62);
    wreg(R_WEAR_VALID, 32'h7);
    rreg(R_WEAR_ERASE_MAX); chk(last_rd == 912, "T5 wear: max erase count"); rreg(R_RESERVED_REMAIN); chk(last_rd == 62, "T5 reserved capacity remaining");
    rreg(R_WEAR_VALID, 1'b0); chk(last_rd == 7, "T5 wear valid flags");
    wreg(R_WEAR_ERASE_MAX, 32'd1, 1'b0); chk(last_err, "T5 wear registers are write-protected from unprivileged masters");
    // lifetime snapshot: independent CRC-32C image restore, corrupted image refused
    for (int i = 0; i < 32; i++) wreg(R_HL_BASE0 + 12'(4*i), hl[i]);
    wreg(R_HL_CTRL, 32'h2); repeat (60) @(negedge clk);
    rreg(R_HL_STATUS); chk(last_rd[1] && !last_rd[2], "T5 restore of an externally generated image accepted (independent CRC-32C)");
    wreg(R_HL_BASE0 + 12'd8, hl[2] ^ 32'h1); wreg(R_HL_CTRL, 32'h2); repeat (60) @(negedge clk);
    rreg(R_HL_STATUS); chk(last_rd[2], "T5 corrupted image refused");
    wreg(R_HL_BASE0 + 12'd8, hl[2]); wreg(R_HL_CTRL, 32'h2); repeat (60) @(negedge clk);
    wreg(R_HL_CTRL, 32'h1); repeat (80) @(negedge clk);
    rreg(R_HL_STATUS); chk(last_rd[0], "T5 snapshot captured");
    rreg(R_HL_SNAP0 + 12'd4 * 28); chk(last_rd == 37, "T5 lifetime max flips carried from the restored base");
    rreg(R_HL_SNAP0 + 12'd4 * 29); chk(last_rd == 32'h0B10 || last_rd == 32'h0A21, "T5 lifetime max temperature code");
    rreg(R_HL_SNAP0 + 12'd4 * EV_RECOVERY);
    chk(last_rd == hl[EV_RECOVERY] + 1, "T5 lifetime counter = restored base + this power-on");
    rreg(R_HL_SNAP0 + 12'd4 * 31); v1 = last_rd;
    chk(v1 != 0, "T5 snapshot carries a CRC");
    chk(dut.u_health.snap_q[31] === v1, "T5 CRC register consistent");
    rreg(R_FAULT_LIFE); chk(last_rd[EV_RECOVERY] && last_rd[EV_THERM_WARN], "T5 lifetime fault classes");
    chk(1'b1, "T5 no remaining-life register exists (by design)");

    // ============================================================ T6
    $display("[T6] sanitise / secure reset");
    do_reset(1'b1);
    base = 7 * PIPE_W; h = vp[base];
    import_vec(base, e8); wr_vec(base, e8, i32); chk(e8 == E_NONE, "T6 write before erasure");
    rd_vec(base, e8, i32); chk(e8 == E_NONE && pay_ok(base), "T6 read before erasure");
    rreg(R_SAN_STATUS);
    chk(last_rd[0] == 1'b0 && last_rd[1] == 1'b1, "T6 SAN_STATUS: no plaintext path; scope NOT validated (honest flag)");
    chk(last_rd[23:16] == 8'd1, "T6 one valid slot");
    key_cmd(3'd4, h[33:32], 1'b0, e8); chk(e8 == E_NONE, "T6 INVALIDATE (crypto-erase of the slot's key)");
    rreg(R_SAN_STATUS); chk(last_rd[15:8] == 8'd1 && last_rd[23:16] == 8'd0, "T6 SAN_STATUS counts the erasure");
    wreg(R_KEY_SEL, 32'(h[33:32])); rreg(R_KEY_INFO); chk(!last_rd[0] && last_rd[15:8] != vp[base][7:0], "T6 slot invalid, generation advanced");
    rd_vec(base, e8, i32); chk(e8 == E_KEY_INVALID && rd_n == 0, "T6 data inaccessible after key erasure");
    for (int i = 0; i < 4; i++) begin rreg(R_SALT0 + 12'(4*i)); chk(last_rd == 0, "T6 salt zeroised"); end
    // secure reset via register
    import_vec(base + PIPE_W, e8);
    wreg(R_SEC_CMD, 32'hDEAD_BEEF);
    rreg(R_SAN_STATUS); chk(last_rd[24] == 1'b0, "T6 wrong value: no secure reset");
    wreg(R_SEC_CMD, 32'h5EC0_5EED); repeat (10) @(negedge clk);
    rreg(R_SAN_STATUS); chk(last_rd[24] == 1'b1 && last_rd[23:16] == 8'd0, "T6 secure reset executed, no valid slots");
    chk(dut.u_core.u_km.k1_q[1] === '0 && dut.u_core.u_km.km_q[1] === '0 && dut.u_core.u_pipe.u_xts.k2_q === '0, "T6 key material zero after secure reset");
    // external zeroise pin (tamper / reset-controller hook)
    import_vec(base + PIPE_W, e8);
    @(negedge clk); ext_zero = 1'b1; @(negedge clk); ext_zero = 1'b0; repeat (8) @(negedge clk);
    rreg(R_SAN_STATUS); chk(last_rd[23:16] == 8'd0, "T6 external zeroise pin wipes the keys");
    sb_lc = LC_PROD; sb_exec = 1'b0;
    wreg(R_SEC_CMD, 32'h5EC0_5EED, 1'b1); chk(last_err, "T6 secure reset refused without authenticated firmware");
    sb_exec = 1'b1; sb_lc = LC_DEV;

    // ============================================================ T7
    $display("[T7] record-guard service (PMD / MAP / JRN / HLT): CRC-32C + CMAC-64");
    do_reset(1'b0);
    begin : rg
      int ok_seal, ok_ver, ok_forge, bs;
      logic [127:0] hr_, b0, b1, cx, km, ex;
      logic [7:0] cls8; logic [5:0] len6;
      logic [31:0] stv, c0, th, tl;
      ok_seal = 0; ok_ver = 0; ok_forge = 0;
      for (int r = 0; r < 48; r++) begin
        bs = r * 6;
        hr_ = vr[bs]; b0 = vr[bs+1]; b1 = vr[bs+2]; cx = vr[bs+3]; km = vr[bs+4]; ex = vr[bs+5];
        cls8 = hr_[103:96]; len6 = hr_[69:64];
        key_load_stage(256'h1 << 200, 256'h2 << 200, km, '0, 8'(r + 1)); key_cmd(3'd1, 2'd0, 1'b0, e8);
        for (int i = 0; i < 4; i++) begin wreg(R_RG_BODY0 + 12'(4*i), b0[127 - 32*i -: 32]); wreg(R_RG_BODY0 + 12'(16 + 4*i), b1[127 - 32*i -: 32]); end
        wreg(R_RG_CTX_HI, cx[127:96]); wreg(R_RG_CTX_LO, cx[95:64]);
        rreg(R_RG_BODY0 + 12'd20); chk(last_rd === b1[95:64], "T7 RG_BODY readback (privileged)");
        rreg(R_RG_BODY0, 1'b0); chk(last_err, "T7 RG_BODY unreadable by an unprivileged master");
        wreg(R_RG_CTRL, rgctrl(2'd0, len6, cls8, 1'b1, 1'b0, 1'b1));       // SEAL with CMAC
        rg_wait(stv);
        rreg(R_RG_CRC); c0 = last_rd; rreg(R_RG_TAG_HI); th = last_rd; rreg(R_RG_TAG_LO); tl = last_rd;
        if (c0 === ex[127:96] && th === ex[95:64] && tl === ex[63:32]) ok_seal++;
        else chk(1'b0, $sformatf("T7 seal vector %0d: crc %08h/%08h tag %08h%08h/%08h%08h", r, c0, ex[127:96], th, tl, ex[95:64], ex[63:32]));
        wreg(R_RG_CTRL, rgctrl(2'd0, len6, cls8, 1'b1, 1'b1, 1'b1));       // VERIFY the sealed record
        rg_wait(stv);
        if (stv[2] && stv[3]) ok_ver++; else chk(1'b0, $sformatf("T7 verify vector %0d", r));
        if (r < 16 && len6 > 0) begin
          // forgery: change the body, recompute the PUBLIC CRC, keep / invent a tag
          wreg(R_RG_BODY0, b0[127:96] ^ 32'h0100_0000);
          wreg(R_RG_CTRL, rgctrl(2'd0, len6, cls8, 1'b0, 1'b0, 1'b1));     // CRC-only seal of the altered record
          rg_wait(stv);
          wreg(R_RG_TAG_HI, th); wreg(R_RG_TAG_LO, tl);                    // the old tag
          wreg(R_RG_CTRL, rgctrl(2'd0, len6, cls8, 1'b1, 1'b1, 1'b1));
          rg_wait(stv);
          if (stv[2] === 1'b1 && stv[3] === 1'b0) ok_forge++;
          else chk(1'b0, $sformatf("T7 forged record %0d: CRC_OK=%b TAG_OK=%b", r, stv[2], stv[3]));
          // class confusion: the same bytes under another class never validate
          wreg(R_RG_BODY0, b0[127:96]); wreg(R_RG_TAG_HI, th); wreg(R_RG_TAG_LO, tl); wreg(R_RG_CRC, c0);
          wreg(R_RG_CTRL, rgctrl(2'd0, len6, (cls8 == 8'd4) ? 8'd1 : cls8 + 8'd1, 1'b1, 1'b1, 1'b1));
          rg_wait(stv);
          chk(stv[2] === 1'b0 && stv[3] === 1'b0, "T7 class separation: CRC and tag both fail under another class");
          // context binding: a record moved to another location (ctx) fails authentication
          wreg(R_RG_CTX_LO, cx[95:64] ^ 32'h1);
          wreg(R_RG_CTRL, rgctrl(2'd0, len6, cls8, 1'b1, 1'b1, 1'b1));
          rg_wait(stv);
          chk(stv[2] === 1'b1 && stv[3] === 1'b0, "T7 context binding: moved record fails authentication, CRC still passes");
        end
      end
      $display("  %0d / 48 seals, %0d / 48 verifies, %0d forgeries detected (CRC passed, tag failed)", ok_seal, ok_ver, ok_forge);
      wreg(R_RG_CTRL, rgctrl(2'd0, 6'd8, 8'd9, 1'b0, 1'b0, 1'b1)); rg_wait(stv); chk(stv[4], "T7 illegal class refused");
      wreg(R_RG_CTRL, rgctrl(2'd0, 6'd40, 8'd1, 1'b0, 1'b0, 1'b1)); rg_wait(stv); chk(stv[4], "T7 length > 32 refused");
      wreg(R_RG_CTRL, rgctrl(2'd3, 6'd8, 8'd1, 1'b1, 1'b1, 1'b1)); rreg(R_RG_STATUS); chk(last_rd[5] && last_rd[4], "T7 authenticated request with an invalid key slot refused");
      evcnt(EV_REC_FAIL, v1); chk(v1 >= 20, $sformatf("T7 verification failures counted (EV_REC_FAIL=%0d)", v1));
    end

    // ============================================================ T8
    $display("[T8] controller reset: telemetry persists across it, volatile keys do not");
    base = 9 * PIPE_W; import_vec(base, e8); wr_vec(base, e8, i32);
    rreg(R_WR_OK); v1 = last_rd; evcnt(EV_RESET, v2);
    do_reset(1'b0);
    rreg(R_WR_OK); chk(last_rd == v1, "T8 counters survive a controller reset (power-on domain)");
    rreg(R_RESET_COUNT); chk(last_rd == v2 + 1, $sformatf("T8 RESET_COUNT incremented (%0d -> %0d)", v2, last_rd));
    rd_vec(base, e8, i32); chk(e8 == E_KEY_INVALID, "T8 keys are gone after a controller reset");
    do_reset(1'b1);
    rreg(R_WR_OK); chk(last_rd == 0, "T8 a power cycle clears the volatile telemetry (persistence = snapshot service)");

    $display("TB_RESULT: %s  checks=%0d errors=%0d", (errors == 0) ? "PASS" : "FAIL", checks, errors);
    $finish;
  end
  initial begin #6000000000; $display("TB_RESULT: FAIL timeout"); $finish; end
endmodule

`default_nettype wire
