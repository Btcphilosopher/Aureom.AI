// =============================================================================
// SecureStore :: tb_core_e2e -- end-to-end tests of the protected data path (sfsec_core + P54 ECC + NAND model)
//
//  E1  write -> stored raw page is bit-exact with the independent Python/OpenSSL/P54-reference model; read back
//  E2  ECC recovery: 1..8 injected raw bit flips corrected (count reported); >8 flips -> explicit error, no data
//  E3  crafted pages (valid ECC codeword, one wrong layer): PMD CRC / format / forged tag / forged fields /
//      downgrade / misdirected LBA / wrong key slot / wrong generation / ciphertext rot / wrong tweak /
//      DIM reference tag / DIM format -> exact error codes; CRC is NOT authentication (forged-CRC pages pass CRC)
//  E4  wrong key (same generation, different salt), incorrect data-unit number, stale generation after INVALIDATE
//  E5  NAND randomiser (position: after ECC encode / before ECC decode) round trip + bit-exact keystream
//  E6  controller reset mid-write / mid-read, flush request, secure-reset zeroisation
//  E7  DMA faults: error beat, poisoned beat, async DMA error, host watchdog; NAND program / read failure; erased page
//  E8  key hierarchy: KDF-derived keys (PRK + salt) bit-exact with the model, GENERATE + restore after power cycle
// Inputs are driven and outputs sampled on the falling edge (docs/07).  Prints TB_RESULT: PASS/FAIL.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_core_e2e;
  import sfsec_pkg::*;
  localparam int NPAGES = 64;
  localparam int PB = 576;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int errors = 0, checks = 0;
  string vecdir;
  time   t_cmd;
  bit    measure = 1'b0;
  longint lat_w_sum = 0, lat_r_sum = 0;
  int     lat_w_n = 0, lat_r_n = 0;

  task automatic chk(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; if (errors <= 40) $display("FAIL: %s (t=%0t)", what, $time); end
    end
  endtask

  // ------------------------------------------------------------------ DUT
  logic         flush = 1'b0, zeroize = 1'b0;
  logic         cmd_valid = 1'b0, cmd_ready, cmd_op = 1'b0;
  logic [7:0]   cmd_tag = '0;
  logic [63:0]  cmd_lba = '0;
  logic [31:0]  cmd_ppa = '0;
  logic [47:0]  cmd_seq = '0;
  logic [1:0]   cmd_slot = '0;
  logic         pol_data_en = 1'b1, pol_auth_en = 1'b0, pol_auth_req = 1'b0, pol_scr_en = 1'b0;
  logic [31:0]  pol_wd = 32'd0;
  logic         hw_valid = 1'b0, hw_ready, hw_err = 1'b0, hw_poison = 1'b0, dma_err = 1'b0;
  logic [31:0]  hw_data = '0;
  logic         hr_valid, hr_ready = 1'b0, hr_last;
  logic [31:0]  hr_data;
  logic         rsp_valid, rsp_ready = 1'b0, rsp_op, pipe_busy;
  logic [7:0]   rsp_tag, rsp_err;
  logic [31:0]  rsp_info;
  logic         km_valid = 1'b0, km_k256 = 1'b0, prk_valid = 1'b0, ent_req, ent_valid = 1'b0, km_busy, km_done, km_kill;
  logic [2:0]   km_op = '0;
  logic [1:0]   km_slot = '0;
  logic [255:0] km_k1 = '0, km_k2 = '0, prk = '0;
  logic [127:0] km_kmac = '0, km_salt = '0, ent_data = '0;
  logic [7:0]   km_gen = '0, km_err;
  logic [3:0]   slot_valid, slot_k256, slot_origin;
  logic [31:0]  slot_gen;
  logic [511:0] slot_salt;
  logic [15:0]  epoch;
  logic         rg_ready, rg_busy, rg_rsp_valid, rg_crc_ok, rg_tag_ok, rg_err, rg_key_valid;
  logic [31:0]  rg_crc;
  logic [63:0]  rg_tag;
  logic [31:0]  ecc_rdata;
  logic         ev_c, ev_u, ev_i, ev_s;
  logic         n_cmd_valid, n_cmd_ready, n_cmd_read, n_wd_valid, n_wd_ready, n_wd_last, n_rd_valid, n_rd_ready, n_rd_last;
  logic         n_abort, n_done_valid, n_done_fail;
  logic [31:0]  n_cmd_ppa;
  logic [7:0]   n_wd_data, n_rd_data;
  logic         tel_pst, tel_scrub, tel_dma;
  logic [15:0]  tel_flips;
  logic [7:0]   tel_max, tel_ncorr;

  sfsec_core #(.DU_BYTES(512), .NS(4), .WD_RD(3000)) dut (
    .clk, .rst_n, .flush_i(flush), .zeroize_i(zeroize),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_op_i(cmd_op), .cmd_tag_i(cmd_tag), .cmd_lba_i(cmd_lba),
    .cmd_ppa_i(cmd_ppa), .cmd_seq_i(cmd_seq), .cmd_slot_i(cmd_slot),
    .pol_data_en_i(pol_data_en), .pol_auth_en_i(pol_auth_en), .pol_auth_req_i(pol_auth_req), .pol_scr_en_i(pol_scr_en),
    .pol_wd_host_i(pol_wd),
    .hw_valid_i(hw_valid), .hw_ready_o(hw_ready), .hw_data_i(hw_data), .hw_err_i(hw_err), .hw_poison_i(hw_poison),
    .dma_err_i(dma_err), .hr_valid_o(hr_valid), .hr_ready_i(hr_ready), .hr_data_o(hr_data), .hr_last_o(hr_last),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_op_o(rsp_op), .rsp_tag_o(rsp_tag), .rsp_err_o(rsp_err),
    .rsp_info_o(rsp_info), .pipe_busy_o(pipe_busy),
    .km_valid_i(km_valid), .km_op_i(km_op), .km_slot_i(km_slot), .km_k256_i(km_k256), .km_k1_i(km_k1), .km_k2_i(km_k2),
    .km_kmac_i(km_kmac), .km_salt_i(km_salt), .km_gen_i(km_gen), .prk_valid_i(prk_valid), .prk_i(prk),
    .ent_req_o(ent_req), .ent_valid_i(ent_valid), .ent_data_i(ent_data), .km_busy_o(km_busy), .km_done_o(km_done),
    .km_err_o(km_err), .km_kill_o(km_kill), .slot_valid_o(slot_valid), .slot_k256_o(slot_k256),
    .slot_origin_o(slot_origin), .slot_gen_o(slot_gen), .slot_salt_o(slot_salt), .epoch_o(epoch),
    .rg_valid_i(1'b0), .rg_ready_o(rg_ready), .rg_busy_o(rg_busy), .rg_verify_i(1'b0), .rg_cls_i(8'h01), .rg_len_i(6'd0),
    .rg_body_i('0), .rg_ctx_i('0), .rg_crc_i('0), .rg_tag_i('0), .rg_auth_i(1'b0), .rg_slot_i(2'd0),
    .rg_rsp_valid_o(rg_rsp_valid), .rg_crc_o(rg_crc), .rg_tag_o(rg_tag), .rg_crc_ok_o(rg_crc_ok),
    .rg_tag_ok_o(rg_tag_ok), .rg_err_o(rg_err), .rg_key_valid_o(rg_key_valid),
    .ecc_rb_sel_i(1'b0), .ecc_rb_we_i(1'b0), .ecc_rb_addr_i(8'h00), .ecc_rb_wdata_i(32'h0), .ecc_rb_rdata_o(ecc_rdata),
    .ecc_ev_corrected_o(ev_c), .ecc_ev_uncorr_o(ev_u), .ecc_ev_integrity_o(ev_i), .ecc_ev_scrub_o(ev_s),
    .nand_cmd_valid_o(n_cmd_valid), .nand_cmd_ready_i(n_cmd_ready), .nand_cmd_read_o(n_cmd_read),
    .nand_cmd_ppa_o(n_cmd_ppa), .nand_wd_valid_o(n_wd_valid), .nand_wd_ready_i(n_wd_ready), .nand_wd_data_o(n_wd_data),
    .nand_wd_last_o(n_wd_last), .nand_rd_valid_i(n_rd_valid), .nand_rd_ready_o(n_rd_ready), .nand_rd_data_i(n_rd_data),
    .nand_rd_last_i(n_rd_last), .nand_abort_o(n_abort), .nand_done_valid_i(n_done_valid), .nand_done_fail_i(n_done_fail),
    .tel_pst_o(tel_pst), .tel_flips_o(tel_flips), .tel_maxflips_o(tel_max), .tel_ncorr_o(tel_ncorr),
    .tel_scrub_o(tel_scrub), .tel_dma_o(tel_dma));

  sfsec_nand_model #(.NPAGES(NPAGES)) nd (.clk, .rst_n, .cmd_valid(n_cmd_valid), .cmd_ready(n_cmd_ready),
    .cmd_read(n_cmd_read), .cmd_ppa(n_cmd_ppa), .wd_valid(n_wd_valid), .wd_ready(n_wd_ready), .wd_data(n_wd_data),
    .wd_last(n_wd_last), .rd_valid(n_rd_valid), .rd_ready(n_rd_ready), .rd_data(n_rd_data), .rd_last(n_rd_last),
    .abort(n_abort), .done_valid(n_done_valid), .done_fail(n_done_fail));

  // test-only entropy source (a software PRNG: NOT a TRNG / DRBG)
  always @(negedge clk) begin
    ent_valid <= ent_req;
    if (ent_req) ent_data <= {$urandom, $urandom, $urandom, $urandom};
  end

  // ------------------------------------------------------------------ vectors
  localparam int PIPE_W = 76, NEG_W = 78;
  logic [127:0] vp [0:PIPE_W*24-1];
  logic [127:0] vk [0:PIPE_W*8-1];
  logic [127:0] vn [0:NEG_W*14-1];
  logic [31:0]  payw [0:127];       // payload as host words (little-endian byte order)
  logic [31:0]  rdw  [0:127];       // words read back
  int           rd_n;

  function automatic logic [31:0] bsw32(input logic [31:0] x);
    return {x[7:0], x[15:8], x[23:16], x[31:24]};
  endfunction

  task automatic load_payload(input logic [127:0] v [], input int base);
    begin end
  endtask

  // ------------------------------------------------------------------ drivers
  task automatic tick(input int n = 1); repeat (n) @(negedge clk); endtask

  task automatic issue(input bit op, input [7:0] tag, input [63:0] lba, input [31:0] ppa, input [47:0] seq, input [1:0] slot);
    begin
      @(negedge clk);
      while (!cmd_ready) @(negedge clk);
      cmd_op = op; cmd_tag = tag; cmd_lba = lba; cmd_ppa = ppa; cmd_seq = seq; cmd_slot = slot; cmd_valid = 1'b1;
      t_cmd = $time;
      @(negedge clk);
      cmd_valid = 1'b0;
    end
  endtask

  // inj_kind: 0 none, 1 err beat, 2 poison beat, 3 async dma_err pulse at word, 4 stall forever (host watchdog)
  task automatic run_write(input int inj_word, input int inj_kind, output [7:0] err, output [31:0] info);
    int  w;
    bit  pend;
    begin
      w = 0; pend = 1'b0; hw_valid = 1'b0; hw_err = 1'b0; hw_poison = 1'b0;
      forever begin
        @(negedge clk);
        if (rsp_valid) begin
          err = rsp_err; info = rsp_info; rsp_ready = 1'b1; @(negedge clk); rsp_ready = 1'b0;
          if (measure && rsp_err == E_NONE) begin lat_w_sum += longint'(($time - t_cmd) / 10); lat_w_n++; end
          hw_valid = 1'b0; hw_err = 1'b0; hw_poison = 1'b0; dma_err = 1'b0;
          break;
        end
        if (pend) begin pend = 1'b0; w++; hw_valid = 1'b0; hw_err = 1'b0; hw_poison = 1'b0; end
        if (!hw_valid && w < 128 && !(inj_kind == 4 && w == inj_word)) begin
          hw_valid = 1'b1; hw_data = payw[w];
          if (w == inj_word && inj_kind == 1) hw_err = 1'b1;
          if (w == inj_word && inj_kind == 2) hw_poison = 1'b1;
        end
        dma_err = (w == inj_word && inj_kind == 3 && hw_valid && hw_ready);
        if (hw_valid && hw_ready) pend = 1'b1;
      end
    end
  endtask

  // inj: 0 none, 1 async dma_err pulse while the host drains the data, 2 host never takes the data (watchdog)
  task automatic run_read(input int inj, output [7:0] err, output [31:0] info);
    int cnt;
    begin
      rd_n = 0; cnt = 0; hr_ready = 1'b0;
      forever begin
        @(negedge clk);
        hr_ready = (inj == 2) ? 1'b0 : (($urandom % 4) != 0);
        if (hr_valid && hr_ready) begin
          rdw[rd_n] = hr_data; chk(hr_last === (rd_n == 127), "hr_last position"); rd_n++;
          if (inj == 1 && rd_n == 40) dma_err = 1'b1;
        end else dma_err = 1'b0;
        if (rsp_valid) begin
          err = rsp_err; info = rsp_info; rsp_ready = 1'b1; @(negedge clk); rsp_ready = 1'b0; hr_ready = 1'b0; dma_err = 1'b0;
          if (measure && rsp_err == E_NONE) begin lat_r_sum += longint'(($time - t_cmd) / 10); lat_r_n++; end
          break;
        end
        cnt++;
        if (cnt > 400000) begin chk(1'b0, "read timeout"); err = 8'hFF; info = 0; break; end
      end
    end
  endtask

  task automatic km_do(input [2:0] op, input [1:0] slot, input bit k256, input [255:0] k1, input [255:0] k2,
                       input [127:0] kmac, input [127:0] salt, input [7:0] gen, output [7:0] err);
    begin
      @(negedge clk); while (km_busy) @(negedge clk);
      km_op = op; km_slot = slot; km_k256 = k256; km_k1 = k1; km_k2 = k2; km_kmac = kmac; km_salt = salt; km_gen = gen;
      km_valid = 1'b1;
      @(negedge clk); km_valid = 1'b0;
      while (!km_done) @(negedge clk);
      err = km_err;
      @(negedge clk);
    end
  endtask

  // vector -> payload words
  task automatic payload_from(input logic [127:0] blk [32]);
    begin
      for (int b = 0; b < 32; b++) for (int k = 0; k < 4; k++) payw[4*b + k] = bsw32(blk[b][127 - 32*k -: 32]);
    end
  endtask

  logic [127:0] tmpblk [32];
  task automatic payload_rec(input int which, input int base);   // which 0: pipe 1: kdf 2: neg
    begin
      for (int b = 0; b < 32; b++) tmpblk[b] = (which == 0) ? vp[base + 8 + b] : (which == 1) ? vk[base + 8 + b] : vn[base + 8 + b];
      payload_from(tmpblk);
    end
  endtask

  function automatic logic [7:0] raw_byte(input int which, input int base, input int j);
    logic [127:0] w;
    begin
      w = (which == 0) ? vp[base + 40 + j/16] : (which == 1) ? vk[base + 40 + j/16] : vn[base + 40 + j/16];
      return w[127 - 8*(j%16) -: 8];
    end
  endfunction

  function automatic bit page_equals_golden(input int which, input int base, input int ppa, input bit scr);
    bit ok;
    begin
      ok = 1'b1;
      for (int j = 0; j < PB; j++)
        if (nd.mem[ppa % NPAGES][j] !== (raw_byte(which, base, j) ^ (scr ? scr_ks(ppa, 16'(j)) : 8'h00))) ok = 1'b0;
      return ok;
    end
  endfunction

  function automatic bit payload_matches(input int which, input int base);
    bit ok;
    begin
      ok = 1'b1;
      for (int b = 0; b < 32; b++) for (int k = 0; k < 4; k++) begin
        logic [127:0] w;
        w = (which == 0) ? vp[base + 8 + b] : (which == 1) ? vk[base + 8 + b] : vn[base + 8 + b];
        if (rdw[4*b + k] !== bsw32(w[127 - 32*k -: 32])) ok = 1'b0;
      end
      return ok;
    end
  endfunction

  // rec fields
  function automatic logic [63:0] rec_lba(input int which, input int base);
    logic [127:0] w; begin w = (which == 0) ? vp[base+1] : (which == 1) ? vk[base+1] : vn[base+1]; return w[127:64]; end
  endfunction
  function automatic logic [31:0] rec_ppa(input int which, input int base);
    logic [127:0] w; begin w = (which == 0) ? vp[base+1] : (which == 1) ? vk[base+1] : vn[base+1]; return w[63:32]; end
  endfunction
  function automatic logic [47:0] rec_seq(input int which, input int base);
    logic [127:0] a, b; begin
      a = (which == 0) ? vp[base+1] : (which == 1) ? vk[base+1] : vn[base+1];
      b = (which == 0) ? vp[base+2] : (which == 1) ? vk[base+2] : vn[base+2];
      return {b[15:0], a[31:0]}; end
  endfunction
  function automatic logic [127:0] rec_hdr(input int which, input int base);
    return (which == 0) ? vp[base] : (which == 1) ? vk[base] : vn[base];
  endfunction
  function automatic logic [255:0] rec_key(input int which, input int base, input int idx);   // idx 0: key1 1: key2
    begin
      return (which == 0) ? {vp[base + 3 + 2*idx], vp[base + 4 + 2*idx]} :
             (which == 1) ? {vk[base + 3 + 2*idx], vk[base + 4 + 2*idx]} : {vn[base + 3 + 2*idx], vn[base + 4 + 2*idx]};
    end
  endfunction
  function automatic logic [127:0] rec_w7(input int which, input int base);
    return (which == 0) ? vp[base + 7] : (which == 1) ? vk[base + 7] : vn[base + 7];
  endfunction

  // install the keys of a vector record into its slot (IMPORT with the record's generation)
  task automatic import_rec(input int which, input int base, output [7:0] err);
    logic [127:0] h;
    begin
      h = rec_hdr(which, base);
      km_do(3'd1, h[33:32], h[64], rec_key(which, base, 0), rec_key(which, base, 1), rec_w7(which, base), '0, h[7:0], err);
    end
  endtask

  task automatic wr_rec(input int which, input int base, input bit auth, output [7:0] err, output [31:0] info);
    logic [127:0] h;
    begin
      h = rec_hdr(which, base);
      payload_rec(which, base);
      pol_auth_en = auth;
      issue(1'b0, 8'(base), rec_lba(which, base), rec_ppa(which, base), rec_seq(which, base), h[33:32]);
      run_write(-1, 0, err, info);
    end
  endtask

  task automatic rd_rec(input int which, input int base, input bit auth_req, output [7:0] err, output [31:0] info);
    logic [127:0] h;
    begin
      h = rec_hdr(which, base);
      pol_auth_req = auth_req;
      issue(1'b1, 8'(base), rec_lba(which, base), rec_ppa(which, base), rec_seq(which, base), h[33:32]);
      run_read(0, err, info);
    end
  endtask

  task automatic do_reset(input int n);
    begin
      @(negedge clk); rst_n = 1'b0; repeat (n) @(negedge clk); rst_n = 1'b1; repeat (3) @(negedge clk);
    end
  endtask

  // no plaintext (or ciphertext) may remain in the read buffer after a command has ended
  function automatic bit rbuf_clean();
    bit ok;
    begin ok = 1'b1; for (int b = 0; b < 33; b++) if (dut.u_pipe.rbuf[b] !== 128'h0) ok = 1'b0; return ok; end
  endfunction

  // ------------------------------------------------------------------ tests
  logic [7:0]  e8;
  logic [31:0] i32;
  int          nflip;

  task automatic flip_random(input int ppa, input int n);
    int pos, cnt;
    logic [1023:0] seen;
    begin
      cnt = 0; seen = '0;
      while (cnt < n) begin
        pos = $urandom % (PB * 8);
        // skip the bad-block-marker byte (first spare byte, column PAGE_DATA): outside every codeword
        if ((pos / 8) == 528 || seen[pos % 1024] === 1'b1) continue;
        seen[pos % 1024] = 1'b1;
        nd.mem[ppa % NPAGES][pos / 8] = nd.mem[ppa % NPAGES][pos / 8] ^ (8'h01 << (pos % 8));
        cnt++;
      end
    end
  endtask

  initial begin
    int base, nok;
    logic [127:0] h;
    if (!$value$plusargs("VECDIR=%s", vecdir)) vecdir = "vectors";
    $readmemh({vecdir, "/pipe.memh"}, vp);
    $readmemh({vecdir, "/pipe_kdf.memh"}, vk);
    $readmemh({vecdir, "/neg.memh"}, vn);
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (4) @(negedge clk);

    // ============================================================ E1 bit-exact write + read back
    $display("[E1] write -> bit-exact page vs independent model -> read back (24 vectors, AES-128/256, auth on)");
    nok = 0; measure = 1'b1;
    for (int r = 0; r < 24; r++) begin
      base = r * PIPE_W;
      import_rec(0, base, e8); chk(e8 == E_NONE, "E1 key import");
      wr_rec(0, base, 1'b1, e8, i32);
      chk(e8 == E_NONE, $sformatf("E1 write %0d status %0d", r, e8));
      chk(page_equals_golden(0, base, int'(rec_ppa(0, base)), 1'b0), $sformatf("E1 stored page %0d == model", r));
      rd_rec(0, base, 1'b1, e8, i32);
      chk(e8 == E_NONE, $sformatf("E1 read %0d status %0d", r, e8));
      chk(rd_n == 128 && payload_matches(0, base), $sformatf("E1 read data %0d", r));
      chk(i32[15:0] == 16'd0, "E1 clean read reports no corrections");
      repeat (4) @(negedge clk);
      chk(dut.u_cmac.key_q === '0 && dut.u_cmac.u_aes.keymem.key_mem[2] === '0 && dut.u_pipe.u_guard.kmac_q === '0 && dut.u_pipe.u_guard.body_q === '0,
          "E1 no K_mac copy outlives a PMD seal / verify (CMAC key + schedule and record guard wiped)");
      if (e8 == E_NONE) nok++;
    end
    measure = 1'b0;
    $display("  %0d / 24 vectors round-tripped", nok);
    $display("  functional latency (command accept -> response, includes key load): write %0d cycles, read %0d cycles (512 B, AES-128/256 mix)", lat_w_sum / lat_w_n, lat_r_sum / lat_r_n);

    // ============================================================ E2 ECC recovery
    $display("[E2] ECC recovery: injected raw bit flips");
    base = 5 * PIPE_W;
    import_rec(0, base, e8);
    wr_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE, "E2 write");
    for (int n = 1; n <= 8; n++) begin
      for (int rep = 0; rep < 3; rep++) begin
        wr_rec(0, base, 1'b1, e8, i32);
        flip_random(int'(rec_ppa(0, base)), n);
        rd_rec(0, base, 1'b1, e8, i32);
        chk(e8 == E_NONE && rd_n == 128 && payload_matches(0, base), $sformatf("E2 %0d flips corrected", n));
        chk(i32[15:0] == 16'(n), $sformatf("E2 corrected-bit count %0d (got %0d)", n, i32[15:0]));
      end
    end
    nok = 0;
    for (int rep = 0; rep < 20; rep++) begin
      wr_rec(0, base, 1'b1, e8, i32);
      flip_random(int'(rec_ppa(0, base)), 9 + (rep % 12));
      rd_rec(0, base, 1'b1, e8, i32);
      chk(e8 != E_NONE && rd_n == 0, $sformatf("E2 >t flips: explicit error, no data (err %0d, %0d words)", e8, rd_n));
      chk(rbuf_clean(), "E2 read buffer cleared after the failed read");
      if (e8 == E_ECC_UNCORR || e8 == E_ECC_INTEG || e8 == E_DI_GUARD || e8 == E_PMD_CRC) nok++;
    end
    chk(nok == 20, "E2 >t flips classified as ECC / integrity errors");

    // ============================================================ E3 crafted pages
    do_reset(3);   // power cycle: volatile keys / generations restart, the NAND content persists
    $display("[E3] crafted pages: one wrong layer each (valid ECC codeword)");
    for (int r = 0; r < 14; r++) begin
      base = r * NEG_W;
      h = vn[base + 76];
      import_rec(2, base, e8); chk(e8 == E_NONE, "E3 import");
      // program the crafted raw page straight into the NAND model
      for (int j = 0; j < PB; j++) nd.mem[rec_ppa(2, base) % NPAGES][j] = raw_byte(2, base, j);
      nd.programmed[rec_ppa(2, base) % NPAGES] = 1'b1;
      pol_auth_req = rec_hdr(2, base) >> 67 & 1;
      pol_auth_en = 1'b0;
      issue(1'b1, 8'(100 + r), h[127:64], rec_ppa(2, base), rec_seq(2, base), rec_hdr(2, base) >> 32 & 2'b11);
      run_read(0, e8, i32);
      chk(e8 == h[63:56], $sformatf("E3 case %0d expected error %0d got %0d", r, h[63:56], e8));
      chk((e8 == E_NONE) ? (rd_n == 128 && payload_matches(2, base)) : (rd_n == 0), $sformatf("E3 case %0d data release policy", r));
      repeat (3) @(negedge clk);
      chk(rbuf_clean(), $sformatf("E3 case %0d: no plaintext / ciphertext left in the buffer after the response", r));
      pol_auth_req = 1'b0;
    end

    // ============================================================ E4 wrong key / wrong DUN / stale key
    do_reset(3);   // power cycle: volatile keys / generations restart, the NAND content persists
    $display("[E4] wrong key, incorrect data-unit number, invalidated key");
    base = 3 * PIPE_W;
    import_rec(0, base, e8);
    wr_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE, "E4 write");
    h = rec_hdr(0, base);
    // (a) incorrect data-unit number: read the same physical page asking for a different LBA
    issue(1'b1, 8'd1, rec_lba(0, base) + 64'd1, rec_ppa(0, base), rec_seq(0, base), h[33:32]);
    run_read(0, e8, i32);
    chk(e8 == E_LBA_MISMATCH && rd_n == 0, $sformatf("E4 wrong DUN -> LBA mismatch (got %0d)", e8));
    // (b1) wrong XTS key, same generation, correct K_mac: metadata checks pass, decryption is garbage -> DIM guard
    km_do(3'd1, h[33:32], h[64], 256'h1 << 200, 256'h2 << 200, rec_w7(0, base), '0, h[7:0], e8);
    chk(e8 == E_NONE, "E4 XTS key replaced (same generation, same K_mac)");
    rd_rec(0, base, 1'b1, e8, i32);
    chk(e8 == E_DI_GUARD && rd_n == 0, $sformatf("E4 wrong XTS key, matching metadata -> DIM guard failure (got %0d)", e8));
    // (b2) wrong K_mac: the authentication tag of the physical metadata fails before any decryption
    km_do(3'd1, h[33:32], h[64], rec_key(0, base, 0), rec_key(0, base, 1), 128'h77, '0, h[7:0], e8);
    rd_rec(0, base, 1'b1, e8, i32);
    chk(e8 == E_PMD_AUTH && rd_n == 0, $sformatf("E4 wrong MAC key -> PMD authentication failure (got %0d)", e8));
    // (b3) the right keys again: the page is readable (nothing was damaged by the failed reads)
    km_do(3'd1, h[33:32], h[64], rec_key(0, base, 0), rec_key(0, base, 1), rec_w7(0, base), '0, h[7:0], e8);
    rd_rec(0, base, 1'b1, e8, i32);
    chk(e8 == E_NONE && rd_n == 128 && payload_matches(0, base), "E4 right keys restored -> page readable");
    // (c) newer generation
    km_do(3'd1, h[33:32], h[64], rec_key(0, base, 0), rec_key(0, base, 1), rec_w7(0, base), '0, h[7:0] + 8'd1, e8);
    rd_rec(0, base, 1'b1, e8, i32);
    chk(e8 == E_KEY_MISMATCH && rd_n == 0, $sformatf("E4 right key, newer generation -> key mismatch (got %0d)", e8));
    // (d) rollback of the generation refused
    km_do(3'd1, h[33:32], h[64], rec_key(0, base, 0), rec_key(0, base, 1), rec_w7(0, base), '0, h[7:0], e8);
    chk(e8 == E_RANGE, "E4 generation rollback refused");
    // (e) INVALIDATE -> explicit error; crypto-erase: old ciphertext not decryptable with a fresh key
    km_do(3'd4, h[33:32], 1'b0, '0, '0, '0, '0, 8'h00, e8);
    chk(e8 == E_NONE && slot_valid[h[33:32]] === 1'b0, "E4 slot invalidated");
    repeat (6) @(negedge clk);
    chk(dut.u_pipe.u_xts.k1_q === '0 && dut.u_pipe.u_xts.k2_q === '0 && dut.u_pipe.u_xts.u_aes_data.keymem.key_mem[1] === '0 &&
        dut.u_pipe.u_xts.u_aes_twk.keymem.key_mem[1] === '0, "E4 INVALIDATE wipes the XTS engine's copy of the key and its key schedules");
    chk(dut.u_cmac.key_q === '0 && dut.u_cmac.u_aes.keymem.key_mem[1] === '0 && dut.u_pipe.u_guard.kmac_q === '0 && dut.u_fguard.kmac_q === '0,
        "E4 INVALIDATE leaves no K_mac copy in the CMAC engine / record guards");
    rd_rec(0, base, 1'b1, e8, i32);
    chk(e8 == E_KEY_INVALID && rd_n == 0, $sformatf("E4 read with invalidated key -> E_KEY_INVALID (got %0d)", e8));
    wr_rec(0, base, 1'b1, e8, i32);
    chk(e8 == E_KEY_INVALID, "E4 write with invalidated key refused");
    chk(km_kill === 1'b0, "kill pulse is a pulse");

    // ============================================================ E5 NAND randomiser
    do_reset(3);   // power cycle: volatile keys / generations restart, the NAND content persists
    $display("[E5] NAND randomiser (after ECC encode / before ECC decode)");
    chk(scr_ks(32'h1234, 16'd0) == 8'h32 && scr_ks(32'h1234, 16'd1) == 8'h8b && scr_ks(32'h1234, 16'd2) == 8'hd0 &&
        scr_ks(32'h1234, 16'd3) == 8'hde, "E5 keystream matches the Python model");
    pol_scr_en = 1'b1;
    for (int r = 0; r < 4; r++) begin
      base = (6 + r) * PIPE_W;
      import_rec(0, base, e8);
      wr_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE, "E5 write");
      chk(page_equals_golden(0, base, int'(rec_ppa(0, base)), 1'b1), $sformatf("E5 stored page %0d == model ^ keystream", r));
      chk(!page_equals_golden(0, base, int'(rec_ppa(0, base)), 1'b0), "E5 randomised page differs from the plain page");
      rd_rec(0, base, 1'b1, e8, i32);
      chk(e8 == E_NONE && payload_matches(0, base), "E5 read through the de-randomiser");
      flip_random(int'(rec_ppa(0, base)), 6);
      rd_rec(0, base, 1'b1, e8, i32);
      chk(e8 == E_NONE && payload_matches(0, base) && i32[15:0] == 16'd6, "E5 correction unaffected by the randomiser (flips commute)");
    end
    pol_scr_en = 1'b0;
    // page written plain, read with randomiser on -> garbage into the ECC -> explicit error
    base = 6 * PIPE_W; import_rec(0, base, e8);
    wr_rec(0, base, 1'b1, e8, i32);
    pol_scr_en = 1'b1; rd_rec(0, base, 1'b1, e8, i32); pol_scr_en = 1'b0;
    chk(e8 != E_NONE && rd_n == 0, "E5 mismatched randomiser setting is detected");

    // ============================================================ E6 resets
    do_reset(3);
    $display("[E6] controller reset / flush / secure-reset zeroisation");
    base = 7 * PIPE_W;
    import_rec(0, base, e8);
    h = rec_hdr(0, base);
    // reset in the middle of a write: nothing programmed
    nd.programmed[rec_ppa(0, base) % NPAGES] = 1'b0;
    for (int j = 0; j < PB; j++) nd.mem[rec_ppa(0, base) % NPAGES][j] = 8'hFF;
    payload_rec(0, base);
    pol_auth_en = 1'b1;
    issue(1'b0, 8'd9, rec_lba(0, base), rec_ppa(0, base), rec_seq(0, base), h[33:32]);
    fork
      begin : wr_thread
        run_write(-1, 0, e8, i32);
      end
      begin : rst_thread
        repeat (400) @(negedge clk);
        rst_n = 1'b0; repeat (3) @(negedge clk); rst_n = 1'b1;
      end
    join_any
    disable wr_thread; disable rst_thread;
    hw_valid = 1'b0; rst_n = 1'b1; repeat (10) @(negedge clk);
    chk(nd.programmed[rec_ppa(0, base) % NPAGES] === 1'b0, "E6 reset mid-write leaves no programmed page");
    chk(cmd_ready === 1'b1 && !pipe_busy, "E6 pipeline idle after reset");
    chk(slot_valid == 4'b0000, "E6 volatile keys cleared by reset");
    wr_rec(0, base, 1'b1, e8, i32);
    chk(e8 == E_KEY_INVALID, "E6 write after reset needs the key again");
    import_rec(0, base, e8);
    wr_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE, "E6 write after re-provisioning");
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE && payload_matches(0, base), "E6 read after reset");
    // flush request in the middle of a read
    issue(1'b1, 8'd10, rec_lba(0, base), rec_ppa(0, base), rec_seq(0, base), h[33:32]);
    repeat (300) @(negedge clk);
    flush = 1'b1; @(negedge clk); flush = 1'b0;
    run_read(0, e8, i32);
    chk(e8 == E_RESET, $sformatf("E6 flush -> E_RESET (got %0d)", e8));
    chk(rd_n == 0, "E6 no data leaked by an aborted read");
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE && payload_matches(0, base), "E6 read works after flush");
    // secure-reset zeroisation
    zeroize = 1'b1; @(negedge clk); zeroize = 1'b0; repeat (8) @(negedge clk);
    chk(slot_valid == 4'b0000, "E6 secure reset invalidates every slot");
    chk(dut.u_km.k1_q[0] === '0 && dut.u_km.k2_q[0] === '0 && dut.u_km.km_q[0] === '0, "E6 key registers zero");
    chk(dut.u_pipe.u_xts.k1_q === '0 && dut.u_pipe.u_xts.u_aes_data.keymem.key_mem[1] === '0, "E6 XTS engine key schedule zero");
    chk(dut.u_pipe.u_xts.u_aes_twk.keymem.key_mem[3] === '0 && dut.u_cmac.key_q === '0 && dut.u_cmac.u_aes.keymem.key_mem[2] === '0, "E6 tweak-AES and CMAC key schedules zero");
    for (int b = 0; b < 33; b++) chk(dut.u_pipe.rbuf[b] === '0, "E6 no residual plaintext in the buffer");
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_KEY_INVALID && rd_n == 0, "E6 data inaccessible after secure reset");

    // ============================================================ E7 DMA / NAND faults
    do_reset(3);   // power cycle: volatile keys / generations restart, the NAND content persists
    $display("[E7] DMA faults, NAND failures, erased page");
    base = 8 * PIPE_W;
    import_rec(0, base, e8);
    h = rec_hdr(0, base);
    for (int p = 0; p < NPAGES; p++) nd.programmed[p] = 1'b0;
    for (int kind = 1; kind <= 3; kind++) begin
      payload_rec(0, base);
      pol_auth_en = 1'b1;
      issue(1'b0, 8'(20 + kind), rec_lba(0, base), rec_ppa(0, base), rec_seq(0, base), h[33:32]);
      run_write(37, kind, e8, i32);
      chk(e8 == ((kind == 2) ? E_POISON : E_DMA), $sformatf("E7 write fault kind %0d -> err %0d", kind, e8));
      chk(nd.programmed[rec_ppa(0, base) % NPAGES] === 1'b0, "E7 faulted write programs nothing");
    end
    pol_wd = 32'd500;
    payload_rec(0, base);
    issue(1'b0, 8'd30, rec_lba(0, base), rec_ppa(0, base), rec_seq(0, base), h[33:32]);
    run_write(20, 4, e8, i32);
    chk(e8 == E_DMA, $sformatf("E7 host watchdog -> E_DMA (got %0d)", e8));
    pol_wd = 32'd0;
    wr_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE, "E7 write succeeds after the faults");
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE && payload_matches(0, base), "E7 read after faults");
    // DMA error on the read output
    issue(1'b1, 8'd31, rec_lba(0, base), rec_ppa(0, base), rec_seq(0, base), h[33:32]);
    run_read(1, e8, i32);
    chk(e8 == E_DMA, $sformatf("E7 async DMA error while draining read data -> E_DMA (got %0d)", e8));
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE && payload_matches(0, base), "E7 read after DMA error");
    // NAND failures
    nd.fail_next_program = 1'b1;
    wr_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NAND_PROG, $sformatf("E7 NAND program failure -> E_NAND_PROG (got %0d)", e8));
    nd.fail_next_read = 1'b1;
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NAND_READ && rd_n == 0, $sformatf("E7 NAND read failure -> E_NAND_READ (got %0d)", e8));
    // NAND hang: the read watchdog ends the command, resets the ECC engine, and the pipeline recovers
    nd.hang_next_read = 1'b1;
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NAND_READ && rd_n == 0, $sformatf("E7 NAND never answers -> read watchdog -> E_NAND_READ (got %0d)", e8));
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE && payload_matches(0, base), "E7 read works after the watchdog (ECC engine reset)");
    // erased page
    nd.programmed[rec_ppa(0, base) % NPAGES] = 1'b0;
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_ERASED && rd_n == 0, $sformatf("E7 never-written page -> E_ERASED (got %0d)", e8));
    // data path disabled by policy (lifecycle)
    pol_data_en = 1'b0;
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_LIFECYCLE, "E7 data path disabled -> E_LIFECYCLE");
    pol_data_en = 1'b1;
    // slow NAND (back-pressure on the program stream)
    nd.stall_pct = 60;
    wr_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE, "E7 write with NAND back-pressure");
    rd_rec(0, base, 1'b1, e8, i32); chk(e8 == E_NONE && payload_matches(0, base), "E7 read after back-pressure");
    nd.stall_pct = 0;

    // ============================================================ E8 key hierarchy
    do_reset(3);   // power cycle: volatile keys / generations restart, the NAND content persists
    $display("[E8] key hierarchy: PRK + salt -> KDF -> keys (bit-exact), GENERATE, restore after power cycle");
    for (int r = 0; r < 8; r++) begin
      base = r * PIPE_W;
      h = vk[base];
      prk = rec_key(1, base, 0); prk_valid = 1'b1;
      km_do(3'd3, h[33:32], h[64], '0, '0, '0, rec_w7(1, base), h[7:0], e8);
      chk(e8 == E_NONE, "E8 derive");
      repeat (6) @(negedge clk);
      chk(dut.u_km.u_kdf.ki_q === '0 && dut.u_km.u_kdf.ko_q === '0 && dut.u_km.prk_q === '0 && dut.u_cmac.key_q === '0 &&
          dut.u_cmac.u_aes.keymem.key_mem[1] === '0, "E8 no PRK / derived-key copy outlives the KDF (KDF, key manager, CMAC schedule wiped)");
      wr_rec(1, base, 1'b1, e8, i32); chk(e8 == E_NONE, "E8 write");
      chk(page_equals_golden(1, base, int'(rec_ppa(1, base)), 1'b0), $sformatf("E8 KDF-derived keys give the model's page (%0d)", r));
      rd_rec(1, base, 1'b1, e8, i32); chk(e8 == E_NONE && payload_matches(1, base), "E8 read");
    end
    // GENERATE with the (test-only) entropy port; remember {salt, generation}; power-cycle; DERIVE; read old page
    begin : gen_restore
      logic [127:0] salt_saved;
      logic [7:0]   gen_saved;
      base = 2 * PIPE_W;
      prk = 256'hA5A5_0000_1111_2222_3333_4444_5555_6666_7777_8888_9999_AAAA_BBBB_CCCC_DDDD_EEEE;
      prk_valid = 1'b1;
      km_do(3'd2, 2'd1, 1'b1, '0, '0, '0, '0, 8'h00, e8);
      chk(e8 == E_NONE && slot_valid[1] && slot_origin[1], "E8 GENERATE");
      salt_saved = slot_salt[128 +: 128]; gen_saved = slot_gen[8 +: 8];
      chk(salt_saved != '0 && gen_saved != 8'd0, "E8 salt exported, generation advanced");
      payload_rec(0, base);
      for (int w = 0; w < 128; w++) payw[w] = payw[w] ^ 32'hC0DE0000;
      pol_auth_en = 1'b1;
      issue(1'b0, 8'd77, 64'h1234_5678_9ABC, 32'd12, 48'd99, 2'd1);
      run_write(-1, 0, e8, i32); chk(e8 == E_NONE, "E8 write with generated key");
      issue(1'b1, 8'd78, 64'h1234_5678_9ABC, 32'd12, 48'd99, 2'd1);
      run_read(0, e8, i32); chk(e8 == E_NONE && rd_n == 128, "E8 read with generated key");
      do_reset(3);                                           // power cycle: volatile keys gone, NAND persists
      prk_valid = 1'b1;
      issue(1'b1, 8'd79, 64'h1234_5678_9ABC, 32'd12, 48'd99, 2'd1);
      run_read(0, e8, i32); chk(e8 == E_KEY_INVALID, "E8 after power cycle the key is gone");
      km_do(3'd3, 2'd1, 1'b1, '0, '0, '0, salt_saved, gen_saved, e8); chk(e8 == E_NONE, "E8 DERIVE (restore)");
      issue(1'b1, 8'd80, 64'h1234_5678_9ABC, 32'd12, 48'd99, 2'd1);
      run_read(0, e8, i32); chk(e8 == E_NONE && rd_n == 128, "E8 old page readable after restore");
      for (int w = 0; w < 128; w++) chk(rdw[w] === payw[w], "E8 restored data correct");
      // without the salt the key cannot be recovered: derive with a different salt -> wrong key, same gen
      km_do(3'd3, 2'd1, 1'b1, '0, '0, '0, salt_saved ^ 128'h1, gen_saved, e8);
      issue(1'b1, 8'd81, 64'h1234_5678_9ABC, 32'd12, 48'd99, 2'd1);
      run_read(0, e8, i32); chk(e8 == E_PMD_AUTH && rd_n == 0, $sformatf("E8 wrong salt -> wrong derived keys -> PMD authentication failure (got %0d)", e8));
      // PRK missing
      prk_valid = 1'b0;
      km_do(3'd2, 2'd2, 1'b0, '0, '0, '0, '0, 8'h00, e8); chk(e8 == E_PRK, "E8 GENERATE without platform root key refused");
    end

    $display("TB_RESULT: %s  checks=%0d errors=%0d", (errors == 0) ? "PASS" : "FAIL", checks, errors);
    $finish;
  end
  initial begin #3000000000; $display("TB_RESULT: FAIL timeout"); $finish; end
endmodule

`default_nettype wire
