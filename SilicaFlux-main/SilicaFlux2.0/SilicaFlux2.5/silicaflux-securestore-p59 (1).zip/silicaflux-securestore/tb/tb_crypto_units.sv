// =============================================================================
// SecureStore :: tb_crypto_units -- unit tests of the cryptographic building blocks against standard vectors
//   [1] XTS engine vs NIST CAVP XTS-AES (tweak as 128-bit string and as sequence number) and randomised
//       OpenSSL vectors (key sizes 128/256, 1..257 blocks, both directions, K1/K2 policy, length limits, abort,
//       zeroisation)
//   [2] CRC engine vs CRC-32C (incl. RFC 3720), CRC-32 (IEEE), CRC-16/CCITT-FALSE vectors
// Self-checking: prints "TB_RESULT: PASS" or "TB_RESULT: FAIL" and a count of failed checks.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_crypto_units;
  import sfsec_pkg::*;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int errors = 0, checks = 0;
  string vecdir;

  task automatic chk(input bit cond, input string what);
    begin
      checks++;
      if (!cond) begin errors++; if (errors <= 25) $display("FAIL: %s (t=%0t)", what, $time); end
    end
  endtask

  // ------------------------------------------------------------------ XTS DUT
  logic         x_zero = 1'b0, x_kload = 1'b0, x_k256 = 1'b0, x_kidle, x_kok, x_keq;
  logic [255:0] x_k1 = '0, x_k2 = '0;
  logic         x_start = 1'b0, x_dec = 1'b0, x_ready, x_lenerr, x_abort = 1'b0;
  logic [127:0] x_tw = '0;
  logic [20:0]  x_nblk = '0;
  logic         s_valid = 1'b0, s_ready, m_valid, m_ready = 1'b0, m_last, x_busy;
  logic [127:0] s_data = '0, m_data;

  sfsec_xts_engine u_xts (.clk, .rst_n, .zeroize_i(x_zero), .key_load_i(x_kload), .key1_i(x_k1), .key2_i(x_k2),
    .key256_i(x_k256), .key_idle_o(x_kidle), .key_ok_o(x_kok), .key_eq_o(x_keq), .du_start_i(x_start),
    .du_dec_i(x_dec), .du_tweak_i(x_tw), .du_nblk_i(x_nblk), .du_ready_o(x_ready), .du_len_err_o(x_lenerr),
    .abort_i(x_abort), .s_valid_i(s_valid), .s_ready_o(s_ready), .s_data_i(s_data), .m_valid_o(m_valid),
    .m_ready_i(m_ready), .m_data_o(m_data), .m_last_o(m_last), .busy_o(x_busy));

  // ------------------------------------------------------------------ CRC DUT
  logic        c_clr = 1'b0, c_en = 1'b0;
  logic [1:0]  c_mode = '0;
  logic [31:0] c_data = '0, c_crc;
  logic [2:0]  c_nb = '0;
  sfsec_crc u_crc (.clk, .rst_n, .clr(c_clr), .mode_i(c_mode), .en(c_en), .data_i(c_data), .nbytes_i(c_nb),
                   .crc_o(c_crc));

  // ------------------------------------------------------------------ CMAC DUT (direct) and KDF + its own CMAC
  logic         m_start = 1'b0, m_k256 = 1'b0, m_busy, m_done, m_zero = 1'b0;
  logic [255:0] m_key = '0;
  logic [6:0]   m_len = '0;
  logic [511:0] m_msg = '0;
  logic [127:0] m_tag;
  sfsec_cmac u_cmac (.clk, .rst_n, .zeroize_i(m_zero), .start_i(m_start), .key_i(m_key), .key256_i(m_k256),
                     .len_i(m_len), .msg_i(m_msg), .busy_o(m_busy), .done_o(m_done), .tag_o(m_tag));

  logic         kd_start = 1'b0, kd_k256 = 1'b0, kd_busy, kd_done;
  logic [255:0] kd_ki = '0;
  logic [479:0] kd_fixed = '0;
  logic [5:0]   kd_flen = '0;
  logic [9:0]   kd_l = '0;
  logic [511:0] kd_ko;
  logic         kc_start, kc_k256, kc_busy, kc_done;
  logic [255:0] kc_key;
  logic [6:0]   kc_len;
  logic [511:0] kc_msg;
  logic [127:0] kc_tag;
  sfsec_kdf u_kdf (.clk, .rst_n, .start_i(kd_start), .ki_i(kd_ki), .ki256_i(kd_k256), .fixed_i(kd_fixed),
    .fixed_len_i(kd_flen), .l_bits_i(kd_l), .busy_o(kd_busy), .done_o(kd_done), .ko_o(kd_ko),
    .cm_start_o(kc_start), .cm_key_o(kc_key), .cm_key256_o(kc_k256), .cm_len_o(kc_len), .cm_msg_o(kc_msg),
    .cm_busy_i(kc_busy), .cm_done_i(kc_done), .cm_tag_i(kc_tag));
  sfsec_cmac u_cmac_kdf (.clk, .rst_n, .zeroize_i(1'b0), .start_i(kc_start), .key_i(kc_key), .key256_i(kc_k256),
                         .len_i(kc_len), .msg_i(kc_msg), .busy_o(kc_busy), .done_o(kc_done), .tag_o(kc_tag));

  logic [127:0] vm [0:25999];
  logic [127:0] exp_blk;

  // Testbench convention (docs/07): inputs are driven with blocking assignments on the FALLING clock edge and
  // outputs are sampled there too; the DUT samples everything on the rising edge (race-free under Verilator).
  task automatic tick(input int n = 1); repeat (n) @(negedge clk); endtask

  task automatic xts_load_key(input logic [255:0] k1, input logic [255:0] k2, input bit k256, output bit eq);
    begin
      @(negedge clk); while (!x_kidle) @(negedge clk);
      x_k1 = k1; x_k2 = k2; x_k256 = k256; x_kload = 1'b1;
      @(negedge clk); x_kload = 1'b0;
      @(negedge clk); while (!x_kidle) @(negedge clk);
      eq = x_keq;
    end
  endtask

  // run one data unit; compare against expected words in vm[eoff ..]
  task automatic xts_unit(input logic [127:0] tw, input bit dec, input int nblk, input int ioff, input int eoff,
                          input string tag);
    int i, o;
    begin
      @(negedge clk); while (!x_ready) @(negedge clk);
      x_tw = tw; x_dec = dec; x_nblk = nblk; x_start = 1'b1;
      @(negedge clk); x_start = 1'b0;
      i = 0; o = 0;
      fork
        begin : feeder
          while (i < nblk) begin
            s_valid = 1'b1; s_data = vm[ioff + i];
            while (!s_ready) @(negedge clk);   // s_ready depends on state only: stable across the rising edge
            @(negedge clk);                    // the rising edge in between transferred the block
            s_valid = 1'b0;
            i++;
            if (($urandom & 3) == 0) tick(($urandom % 5) + 1);
          end
        end
        begin : collector
          while (o < nblk) begin
            m_ready = (($urandom & 3) != 0);
            if (m_valid && m_ready) begin      // transfer happens at the coming rising edge
              chk(m_data === vm[eoff + o], {tag, " block"});
              chk(m_last === (o == nblk - 1), {tag, " last"});
              o++;
            end
            @(negedge clk);
          end
          m_ready = 1'b0;
        end
      join
      @(negedge clk);
    end
  endtask

  task automatic xts_file(input string fname, input int nrec_max);
    int p, n, nb;
    bit eq;
    logic [127:0] h;
    begin
      for (int i = 0; i < 26000; i++) vm[i] = '0;
      $readmemh({vecdir, "/", fname}, vm);
      p = 0; n = 0;
      while (n < nrec_max && !(vm[p] == '0 && vm[p+1] == '0)) begin
        h = vm[p];
        nb = h[127:96];
        if (nb == 0) break;
        xts_load_key({vm[p+1], vm[p+2]}, {vm[p+3], vm[p+4]}, h[64], eq);
        chk(!eq, {fname, " key halves distinct"});
        chk(x_kok, {fname, " key_ok"});
        xts_unit(vm[p+5], h[65], nb, p + 6, p + 6 + nb, fname);
        p += 6 + 2 * nb;
        n++;
      end
      $display("  %-18s %0d records checked", fname, n);
    end
  endtask

  // ------------------------------------------------------------------ CRC test
  task automatic crc_file(input string fname, input int nrec);
    int p, n, len, base;
    logic [127:0] h;
    logic [127:0] w;
    begin
      for (int i = 0; i < 26000; i++) vm[i] = '0;
      $readmemh({vecdir, "/", fname}, vm);
      p = 0; n = 0;
      while (n < nrec) begin
        h = vm[p]; len = h[127:96];
        @(negedge clk);
        c_clr = 1'b1; c_mode = h[95:64];
        @(negedge clk); c_clr = 1'b0;
        for (int b = 0; b < len; b += 4) begin
          w = vm[p + 1 + b/16];
          base = b % 16;
          c_data = {w[127 - 8*(base+3) -: 8], w[127 - 8*(base+2) -: 8], w[127 - 8*(base+1) -: 8], w[127 - 8*base -: 8]};
          c_nb   = (len - b >= 4) ? 3'd4 : 3'(len - b);
          c_en   = 1'b1;
          @(negedge clk);
        end
        c_en = 1'b0;
        @(negedge clk);
        chk(c_crc === h[63:32], $sformatf("crc mode %0d len %0d got %08h exp %08h", h[95:64], len, c_crc, h[63:32]));
        p += 5; n++;
      end
      $display("  %-18s %0d messages checked", fname, n);
    end
  endtask

  task automatic cmac_file(input string fname, input int nrec);
    int p, n;
    logic [127:0] h;
    begin
      for (int i = 0; i < 26000; i++) vm[i] = '0;
      $readmemh({vecdir, "/", fname}, vm);
      p = 0;
      for (n = 0; n < nrec; n++) begin
        h = vm[p];
        @(negedge clk); while (m_busy) @(negedge clk);
        m_key = {vm[p+1], vm[p+2]}; m_k256 = h[64]; m_len = h[102:96]; m_msg = {vm[p+3], vm[p+4], vm[p+5], vm[p+6]};
        m_start = 1'b1;
        @(negedge clk); m_start = 1'b0;
        while (!m_done) @(negedge clk);
        chk(m_tag === vm[p+7], $sformatf("cmac len %0d got %h exp %h", h[127:96], m_tag, vm[p+7]));
        p += 8;
      end
      $display("  %-18s %0d messages checked", fname, n);
    end
  endtask

  task automatic kdf_file(input string fname, input int nrec);
    int p, n, nbytes;
    logic [127:0] h;
    logic [511:0] expv, mask;
    begin
      for (int i = 0; i < 26000; i++) vm[i] = '0;
      $readmemh({vecdir, "/", fname}, vm);
      p = 0;
      for (n = 0; n < nrec; n++) begin
        h = vm[p];
        @(negedge clk); while (kd_busy) @(negedge clk);
        kd_ki = {vm[p+1], vm[p+2]}; kd_k256 = h[64]; kd_l = h[127:96]; kd_flen = h[63:32];
        begin : fx logic [511:0] cat; cat = {vm[p+3], vm[p+4], vm[p+5], vm[p+6]}; kd_fixed = cat[511:32]; end
        kd_start = 1'b1;
        @(negedge clk); kd_start = 1'b0;
        while (!kd_done) @(negedge clk);
        expv = {vm[p+7], vm[p+8], vm[p+9], vm[p+10]};
        nbytes = h[127:96] / 8;
        mask = '1; mask = mask << (512 - 8 * nbytes);
        chk(((kd_ko ^ expv) & mask) === '0, $sformatf("kdf L=%0d fixedlen=%0d", h[127:96], h[63:32]));
        p += 11;
      end
      $display("  %-18s %0d derivations checked", fname, n);
    end
  endtask

  initial begin
    bit eq;
    if (!$value$plusargs("VECDIR=%s", vecdir)) vecdir = "vectors";
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (3) @(negedge clk);
    $display("[1] AES-XTS engine (secworks AES core + XTS mode)");
    xts_file("xts_cavp.memh", 100000);
    xts_file("xts_rand.memh", 100000);
    // ---- policy / robustness
    begin : policy
      logic [255:0] kk;
      kk = {128'h000102030405060708090a0b0c0d0e0f, 128'h0};
      xts_load_key(kk, kk, 1'b0, eq);
      chk(eq, "equal key halves refused (128)");
      chk(!x_kok, "no key after refused load");
      chk(!x_ready, "du_ready low without key");
      kk = {128'h1, 128'h2};
      xts_load_key(kk, kk, 1'b1, eq);
      chk(eq, "equal key halves refused (256)");
      xts_load_key({128'h11, 128'h22}, {128'h33, 128'h44}, 1'b1, eq);
      chk(!eq && x_kok, "distinct 256-bit halves accepted");
      // length limits: refused at start, no state change
      @(negedge clk); x_nblk = 21'd0; x_start = 1'b1; @(negedge clk); x_start = 1'b0;
      chk(x_lenerr === 1'b1, "0 blocks refused (len error pulse)");
      @(negedge clk);
      x_nblk = 21'h100001; x_start = 1'b1; @(negedge clk); x_start = 1'b0;
      chk(x_lenerr === 1'b1, "2^20+1 blocks refused");
      @(negedge clk);
      chk(!x_busy, "engine idle after refused commands");
      // abort in the middle of a unit, then the engine is idle again and the key retained
      x_dec = 1'b0; x_tw = 128'h5; x_nblk = 21'd4; x_start = 1'b1; @(negedge clk); x_start = 1'b0;
      repeat (80) @(negedge clk);                 // tweak done, waiting for data
      s_valid = 1'b1; s_data = 128'h1234; @(negedge clk); @(negedge clk); s_valid = 1'b0;
      repeat (3) @(negedge clk);
      x_abort = 1'b1; @(negedge clk); x_abort = 1'b0;
      repeat (6) @(negedge clk);
      while (x_busy) @(negedge clk);
      chk(!x_busy && x_kok, "abort returns to idle, key retained");
      // zeroisation: key gone, refuses data units, round keys wiped inside the AES cores
      x_zero = 1'b1; @(negedge clk); x_zero = 1'b0; repeat (6) @(negedge clk);
      chk(!x_kok && !x_ready, "zeroize drops the key");
      chk(u_xts.u_aes_data.keymem.key_mem[0] === 128'h0 && u_xts.u_aes_data.keymem.key_mem[10] === 128'h0 &&
          u_xts.u_aes_twk.keymem.key_mem[14] === 128'h0, "AES round-key memories cleared by zeroize");
      chk(u_xts.k1_q === '0 && u_xts.k2_q === '0 && u_xts.tw_q === '0, "key / tweak registers cleared");
    end
    $display("[2] CRC engine (CRC-32C, CRC-32 IEEE, CRC-16/CCITT-FALSE)");
    crc_file("crc.memh", 768);
    $display("[3] AES-CMAC (SP 800-38B) engine");
    cmac_file("cmac.memh", 308);
    $display("[4] SP 800-108 counter-mode KDF with AES-CMAC PRF (NIST CAVP KBKDF + SecureStore label formats)");
    kdf_file("kdf.memh", 140);
    $display("TB_RESULT: %s  checks=%0d errors=%0d", (errors == 0) ? "PASS" : "FAIL", checks, errors);
    $finish;
  end
  initial begin #400000000; $display("TB_RESULT: FAIL timeout"); $finish; end
endmodule

`default_nettype wire
