# Regression summary

Produced by `make regress` + `make report`.  Simulator: Verilator 5.49.

| Testbench | Result |
|---|---|
| tb_crypto_units: XTS (NIST CAVP + OpenSSL), CRC, CMAC (SP 800-38B), KDF (SP 800-108 CAVP) | `TB_RESULT: PASS  checks=29940 errors=0` |
| tb_core_e2e: protected data path with the real P54 BCH codec and a NAND model | `TB_RESULT: PASS  checks=10233 errors=0` |
| tb_top_regs: register interface, lifecycle, RAS, health, sanitise, record guard | `TB_RESULT: PASS  checks=490 errors=0` |

## Detail lines from the logs

```
[1] AES-XTS engine (secworks AES core + XTS mode)
  xts_cavp.memh      2400 records checked
  xts_rand.memh      201 records checked
[2] CRC engine (CRC-32C, CRC-32 IEEE, CRC-16/CCITT-FALSE)
  crc.memh           768 messages checked
[3] AES-CMAC (SP 800-38B) engine
  cmac.memh          308 messages checked
[4] SP 800-108 counter-mode KDF with AES-CMAC PRF (NIST CAVP KBKDF + SecureStore label formats)
  kdf.memh           140 derivations checked
[E1] write -> bit-exact page vs independent model -> read back (24 vectors, AES-128/256, auth on)
  24 / 24 vectors round-tripped
  functional latency (command accept -> response, includes key load): write 2717 cycles, read 3981 cycles (512 B, AES-128/256 mix)
[E2] ECC recovery: injected raw bit flips
[E3] crafted pages: one wrong layer each (valid ECC codeword)
[E4] wrong key, incorrect data-unit number, invalidated key
[E5] NAND randomiser (after ECC encode / before ECC decode)
[E6] controller reset / flush / secure-reset zeroisation
[E7] DMA faults, NAND failures, erased page
[E8] key hierarchy: PRK + salt -> KDF -> keys (bit-exact), GENERATE, restore after power cycle
[T1] identification / configuration / honest capability flags
[T2] privilege / lifecycle gating of secure-control registers
[T3] key management: lifecycle matrix, magic, interlock, generation, hygiene
[T4] telemetry / RAS: counters, history, log, IRQ, security alarm
[T5] health telemetry: temperature, thermal warnings, wear, lifetime snapshot
[T6] sanitise / secure reset
[T7] record-guard service (PMD / MAP / JRN / HLT): CRC-32C + CMAC-64
  48 / 48 seals, 48 / 48 verifies, 11 forgeries detected (CRC passed, tag failed)
[T8] controller reset: telemetry persists across it, volatile keys do not
```

## Mutation check

28 / 28 planted faults killed (details: `reports/mutation.md`).
