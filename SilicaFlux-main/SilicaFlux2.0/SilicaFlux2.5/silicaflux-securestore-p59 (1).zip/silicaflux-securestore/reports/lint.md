# Lint (Verilator -Wall)

Command: `verilator --lint-only -Wall --top-module silicaflux_storage_security -f scripts/files_core.f`

| Category | Count (new RTL: rtl/sfsec_*, rtl/silicaflux_*) | Disposition |
|---|---|---|
| UNUSEDPARAM | 133 | generated register-offset constants (waived) |
| UNUSEDSIGNAL | 22 | unused P54 outputs / reserved fields (reviewed) |
| WIDTHEXPAND | 10 | width style, covered by tests (see list) |
| WIDTHTRUNC | 2 | width style, covered by tests (see list) |
| SYNCASYNCNET | 1 | intentional: rst_n observed for reset counting |
| PINCONNECTEMPTY | 1 | unused status output |
| BLKSEQ | 0 |  |
| LATCH | 0 |  |
| MULTIDRIVEN | 0 |  |

Errors: 0

Third-party (secworks AES, P54) warnings are not counted here.
