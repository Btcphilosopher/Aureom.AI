# Mutation check

One planted RTL fault per mutant; KILLED = at least one self-checking testbench failed.

**28 / 28 mutants killed.**

| id | planted fault | result | caught by |
|---|---|---|---|
| M01 | data guard uses CRC-32 (IEEE) instead of CRC-32C | KILLED | e2e |
| M02 | XTS alpha-multiplication reduction polynomial wrong | KILLED | unit |
| M03 | XTS tweak byte order (LBA not little-endian) | KILLED | e2e |
| M04 | PMD CRC verdict ignored | KILLED | e2e |
| M05 | PMD authentication tag verdict ignored | KILLED | e2e |
| M06 | LBA binding of the physical metadata not checked | KILLED | e2e |
| M07 | key generation binding not checked | KILLED | e2e |
| M08 | DIM guard CRC verdict ignored | KILLED | e2e |
| M09 | DIM reference tag not checked | KILLED | e2e |
| M10 | secure reset does not wipe the key slots | KILLED | e2e |
| M11 | clear-key import allowed in PROD / RECOVERY | KILLED | top |
| M12 | privileged access without authenticated firmware | KILLED | top |
| M13 | equal XTS key halves accepted | KILLED | unit |
| M14 | randomiser column mapping wrong on the spare-first read stream | KILLED | e2e |
| M15 | poisoned host data accepted | KILLED | e2e |
| M16 | CMAC final-block subkeys swapped | KILLED | unit |
| M17 | CRC-32C polynomial off by one bit | KILLED | unit |
| M18 | authentication failures not counted (no security alarm) | KILLED | top |
| M19 | ECC uncorrectable verdict ignored | KILLED | e2e |
| M20 | plaintext buffer not cleared on the error path | KILLED | e2e |
| M21 | key generation rollback permitted on IMPORT | KILLED | e2e |
| M22 | erased page not recognised | KILLED | e2e |
| M23 | record class not bound into the CMAC input | KILLED | e2e |
| M24 | health snapshot restore without CRC check | KILLED | top |
| M25 | INVALIDATE / key commands do not wipe the datapath key copies | KILLED | e2e |
| M26 | CMAC key / schedule not wiped after an operation | KILLED | e2e |
| M27 | host word corrupted on the way into the XTS engine (after the guard CRC) | KILLED | e2e |
| M28 | randomiser not applied on the write stream | KILLED | e2e |
