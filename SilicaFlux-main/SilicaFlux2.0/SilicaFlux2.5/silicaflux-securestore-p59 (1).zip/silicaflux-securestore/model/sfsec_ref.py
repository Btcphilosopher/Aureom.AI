"""
sfsec_ref.py -- independent reference model of SilicaFlux SecureStore (Project 59).

Nothing here is shared with the RTL.  Cryptographic primitives come from OpenSSL (via the `cryptography`
package); the XTS *mode* is additionally written out in pure Python (built on the AES block primitive only) and
cross-checked against OpenSSL's XTS, the NIST CAVP XTS vectors and the IEEE 1619 vectors, so that a disagreement
between the RTL and the model can be attributed.  Page framing uses the unmodified Project 54 reference
(`third_party/silicaflux-ecccore/ref`).

Formats (normative text: docs/02_PIPELINE_AND_FORMATS.md)
  DIM  16 B  guard CRC-32C(payload) | ref_tag LBA | app_tag | version | flags     (encrypted with the payload)
  PMD  32 B  magic | flags | slot | gen | lba | seq | rsvd | CRC-32C | CMAC-64    (cleartext, rides in ECC UMETA)
  REC  class | len | body | CRC-32C | CMAC-64                                   (PMD / MAP / JRN / HLT records)
"""
import os
import sys
import zlib

from cryptography.hazmat.primitives import cmac as _cmac
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "third_party", "silicaflux-ecccore", "ref"))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

# ---------------------------------------------------------------------------------------------- constants
DU_BYTES = 512
DIM_BYTES = 16
PMD_BYTES = 32
PMD_MAGIC = 0x5C
DIM_VERSION = 0x01
CLS_PMD, CLS_MAP, CLS_JRN, CLS_HLT = 0x01, 0x02, 0x03, 0x04
FL_ENC, FL_AUTH = 0x01, 0x02

# error codes (must match rtl/sfsec_pkg.sv)
E = dict(NONE=0, LIFECYCLE=1, KEY_INVALID=2, KEY_MISMATCH=3, LEN=4, DMA=5, POISON=6, ECC_UNCORR=7, ECC_INTEG=8,
         PMD_CRC=9, PMD_AUTH=10, LBA_MISMATCH=11, DI_GUARD=12, DI_REFTAG=13, DI_FORMAT=14, NAND_PROG=15,
         NAND_READ=16, ERASED=17, RESET=18, BUSY=19, KEY_EQ=20, PMD_FORMAT=21, ENT=22, PRK=23)


# ---------------------------------------------------------------------------------------------- bytes helpers
def le(n, size):
    return int(n).to_bytes(size, "little")


def from_le(b):
    return int.from_bytes(b, "little")


# ---------------------------------------------------------------------------------------------- CRCs
def _crc32_bitwise(data, poly_ref, init=0xFFFFFFFF, xorout=0xFFFFFFFF):
    crc = init
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = (crc >> 1) ^ poly_ref if crc & 1 else crc >> 1
    return crc ^ xorout


def crc32c(data, init=0xFFFFFFFF):
    """CRC-32C (Castagnoli), reflected, init/xorout 0xFFFFFFFF: check("123456789") = 0xE3069283."""
    return _crc32_bitwise(data, 0x82F63B78, init)


def crc32_ieee(data):
    """CRC-32 (IEEE 802.3), as the FTL (sfftl_crc32) and zlib: check("123456789") = 0xCBF43926."""
    return _crc32_bitwise(data, 0xEDB88320)


def crc16_ccitt_false(data, crc=0xFFFF):
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc


def _selfcheck_crc():
    assert crc32c(b"123456789") == 0xE3069283
    assert crc32_ieee(b"123456789") == 0xCBF43926 == zlib.crc32(b"123456789")
    assert crc16_ccitt_false(b"123456789") == 0x29B1
    # RFC 3720 (iSCSI) appendix B.4 CRC-32C test vectors
    assert crc32c(bytes(32)) == 0x8A9136AA
    assert crc32c(b"\xff" * 32) == 0x62A8AB43
    assert crc32c(bytes(range(32))) == 0x46DD794E
    assert crc32c(bytes(range(31, -1, -1))) == 0x113FDB5C


_selfcheck_crc()


# ---------------------------------------------------------------------------------------------- AES / XTS
def aes_ecb(key, block, enc=True):
    c = Cipher(algorithms.AES(key), modes.ECB())
    x = c.encryptor() if enc else c.decryptor()
    return x.update(block) + x.finalize()


def gf_mul_alpha(t16):
    """Multiply a tweak (16 bytes, little-endian field element, IEEE 1619) by alpha in GF(2^128)."""
    v = from_le(t16)
    carry = v >> 127
    v = (v << 1) & ((1 << 128) - 1)
    if carry:
        v ^= 0x87
    return le(v, 16)


def xts_pure(key1, key2, tweak16, data, decrypt=False):
    """XTS-AES (IEEE 1619-2007 / NIST SP 800-38E) for data units that are a multiple of 16 bytes
    (no ciphertext stealing).  Pure Python on top of AES-ECB blocks."""
    assert len(data) % 16 == 0 and len(data) >= 16
    t = aes_ecb(key2, tweak16, True)
    out = bytearray()
    for i in range(0, len(data), 16):
        x = bytes(a ^ b for a, b in zip(data[i:i + 16], t))
        y = aes_ecb(key1, x, not decrypt)
        out += bytes(a ^ b for a, b in zip(y, t))
        t = gf_mul_alpha(t)
    return bytes(out)


def xts_openssl(key1, key2, tweak16, data, decrypt=False):
    c = Cipher(algorithms.AES(key1 + key2), modes.XTS(tweak16))
    x = c.decryptor() if decrypt else c.encryptor()
    return x.update(data) + x.finalize()


def xts(key1, key2, tweak16, data, decrypt=False):
    a = xts_pure(key1, key2, tweak16, data, decrypt)
    if key1 != key2:  # OpenSSL refuses identical halves
        assert a == xts_openssl(key1, key2, tweak16, data, decrypt), "pure XTS != OpenSSL XTS"
    return a


def dun_tweak(lba):
    """Data-unit number -> 16 tweak bytes (IEEE 1619: little-endian integer, zero-extended)."""
    return le(lba, 16)


def _selfcheck_xts():
    # IEEE 1619-2007 Annex B vector 1 (all-zero keys, tweak 0, 32 zero bytes) -- cross-checked with OpenSSL above
    k = bytes(16)
    # (identical halves are rejected by OpenSSL, so compare the pure model with the published ciphertext)
    ct = xts_pure(k, k, bytes(16), bytes(32))
    assert ct.hex() == "917cf69ebd68b2ec9b9fe9a3eadda692cd43d2f59598ed858c02c2652fbf922e"
    assert xts_pure(k, k, bytes(16), ct, True) == bytes(32)


_selfcheck_xts()


# ---------------------------------------------------------------------------------------------- CMAC / KDF
def cmac_aes(key, msg):
    c = _cmac.CMAC(algorithms.AES(key))
    c.update(msg)
    return c.finalize()


def kdf_ctr_cmac(kin, fixed, nbytes, rlen=4):
    """NIST SP 800-108 counter mode, PRF = AES-CMAC, counter before fixed input, r = 32 bits:
       K(i) = CMAC(KI, [i]_32be || fixed), output truncated to nbytes."""
    out = b""
    i = 1
    while len(out) < nbytes:
        out += cmac_aes(kin, i.to_bytes(rlen, "big") + fixed)
        i += 1
    return out[:nbytes]


LABEL_XTS = b"SFSEC-XTS"
LABEL_MAC = b"SFSEC-MAC"


def kdf_fixed(label, slot, gen, salt, nbits):
    """Fixed input data of the SecureStore key hierarchy: label || 0x00 || context || [L]_32be,
       context = slot(1) || gen(1) || salt(16)."""
    assert len(label) == 9 and len(salt) == 16
    return label + b"\x00" + bytes([slot, gen]) + salt + nbits.to_bytes(4, "big")


def derive_slot_keys(prk, slot, gen, salt, xts256):
    """Key hierarchy: PRK (platform root key) --KDF--> {K1||K2 (XTS), K_mac (CMAC)} per (slot, generation, salt)."""
    nx = 64 if xts256 else 32
    kx = kdf_ctr_cmac(prk, kdf_fixed(LABEL_XTS, slot, gen, salt, nx * 8), nx)
    km = kdf_ctr_cmac(prk, kdf_fixed(LABEL_MAC, slot, gen, salt, 128), 16)
    return kx[:nx // 2], kx[nx // 2:], km


# ---------------------------------------------------------------------------------------------- record guard
def rec_crc(cls, body):
    return crc32c(bytes([cls, len(body)]) + body)


def rec_tag(kmac, cls, body, ctx):
    """CMAC-64 over class || len || body || ctx(8 B little-endian), truncated to the leftmost 8 bytes
       (NIST SP 800-38B, Tlen = 64)."""
    return cmac_aes(kmac, bytes([cls, len(body)]) + body + le(ctx, 8))[:8]


# ---------------------------------------------------------------------------------------------- DIM / PMD
def make_dim(payload, lba):
    return le(crc32c(payload), 4) + le(lba, 8) + le(0, 2) + bytes([DIM_VERSION, 0])


def parse_dim(dim):
    return dict(guard=from_le(dim[0:4]), ref_tag=from_le(dim[4:12]), app_tag=from_le(dim[12:14]),
                version=dim[14], flags=dim[15])


def pmd_body(slot, gen, lba, seq, flags):
    return bytes([PMD_MAGIC, flags, slot, gen]) + le(lba, 8) + le(seq, 6) + le(0, 2)


def make_pmd(slot, gen, lba, seq, ppa, kmac=None):
    flags = FL_ENC | (FL_AUTH if kmac is not None else 0)
    body = pmd_body(slot, gen, lba, seq, flags)
    assert len(body) == 20
    crc = le(rec_crc(CLS_PMD, body), 4)
    tag = rec_tag(kmac, CLS_PMD, body, ppa) if kmac is not None else bytes(8)
    return body + crc + tag


def parse_pmd(pmd):
    return dict(magic=pmd[0], flags=pmd[1], slot=pmd[2], gen=pmd[3], lba=from_le(pmd[4:12]),
                seq=from_le(pmd[12:18]), rsvd=from_le(pmd[18:20]), crc=from_le(pmd[20:24]), tag=pmd[24:32])


# ---------------------------------------------------------------------------------------------- page / pipeline
_fmt_cache = {}


def page_format(du=DU_BYTES):
    if du not in _fmt_cache:
        import gen_ecc_cfg
        _fmt_cache[du] = gen_ecc_cfg.fmt(du)
    return _fmt_cache[du]


def seal_data_unit(k1, k2, kmac, slot, gen, lba, ppa, seq, payload, auth=True, du=DU_BYTES):
    """Write path golden: returns dict(ct=XTS data unit, pmd=UMETA, raw=raw page in column order)."""
    assert len(payload) == du
    dim = make_dim(payload, lba)
    ct = xts(k1, k2, dun_tweak(lba), payload + dim)
    pmd = make_pmd(slot, gen, lba, seq, ppa, kmac if auth else None)
    raw = page_format(du).encode_page(ct, [pmd])
    return dict(ct=ct, pmd=pmd, dim=dim, raw=raw)


def flip_bits(raw, positions):
    b = bytearray(raw)
    for p in positions:
        b[p // 8] ^= 1 << (p % 8)
    return bytes(b)


def spare_first(raw, du=DU_BYTES):
    return page_format(du).spare_first(raw)




# ---------------------------------------------------------------------------------------------- NAND randomiser
def scr_ks(ppa, col):
    """Decorrelation keystream (rtl/sfsec_pkg.sv scr_ks).  NOT cryptographic."""
    m = 0xFFFFFFFF
    h = ((ppa ^ 0xA5C35E17) + (col * 0x9E3779B1)) & m
    h ^= h >> 15
    h = (h * 0x85EBCA6B) & m
    h ^= h >> 13
    h = (h * 0xC2B2AE35) & m
    h ^= h >> 16
    return h & 0xFF


def scramble(raw, ppa):
    """Applied to the raw page in COLUMN order (data area, then spare); XOR is its own inverse."""
    return bytes(b ^ scr_ks(ppa, c) for c, b in enumerate(raw))
