// Minimal bring-up test for the Verilated core: raw register programming, no driver library.
// Exercises: identity, ABI negotiation, window + queue setup, NOP, COPY_H2D, COPY_D2H, doorbell,
// completion phase/fields, interrupt. Used to debug the RTL and harness independent of the
// shared test-suite.  Exit code 0 = pass.
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include "rtl_target.hpp"
#include "sfx_abi.h"

using namespace sfx;

#define CHECK(c)                                                                           \
    do {                                                                                   \
        if (!(c)) { std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #c); std::exit(1); } \
    } while (0)
#define CHECK_EQ(a, b)                                                                     \
    do {                                                                                   \
        unsigned long long _a = (a), _b = (b);                                             \
        if (_a != _b) { std::printf("FAIL %s:%d: %s == %s (0x%llx vs 0x%llx)\n", __FILE__, __LINE__, #a, #b, _a, _b); std::exit(1); } \
    } while (0)

static void wr64(Target& t, uint32_t lo, uint64_t v) { t.wr32(lo, (uint32_t)v); t.wr32(lo + 4, (uint32_t)(v >> 32)); }

int main() {
    Geometry g;
    auto t = make_rtl_target(g);
    const uint64_t H = t->host.base();

    CHECK_EQ(t->rd32(SFX_R_ID), SFX_ID_VALUE);
    CHECK_EQ(t->rd32(SFX_R_VERSION), 0x01000000u);
    std::printf("geometry reg=0x%08x limits=0x%08x caps=0x%08x\n", t->rd32(SFX_R_GEOMETRY),
                t->rd32(SFX_R_LIMITS), t->rd32(SFX_R_CAPS));

    t->wr32(SFX_R_ABI_REQ, (1u << 16) | 0);
    CHECK(t->rd32(SFX_R_STATUS) & SFX_STATUS_ABI_OK);

    // host window [H, H+1MiB) RW domain 1; device window [0, 1MiB) RW domain 1
    auto win = [&](unsigned w, bool dev, uint64_t base, uint64_t size) {
        wr64(*t, SFX_WIN_REG(w, SFX_R_W_BASE_LO), base);
        wr64(*t, SFX_WIN_REG(w, SFX_R_W_SIZE_LO), size);
        t->wr32(SFX_WIN_REG(w, SFX_R_W_CTRL), SFX_WIN_VALID | (dev ? SFX_WIN_SPACE : 0) | SFX_WIN_R | SFX_WIN_W | (1u << 8));
        CHECK(t->rd32(SFX_WIN_REG(w, SFX_R_W_CTRL)) & SFX_WIN_VALID);
    };
    win(0, false, H, 1u << 20);
    win(1, true, 0, 1u << 20);

    // queue 0: rings at H+0 (SQ, 8 entries) and H+0x1000 (CQ, 8 entries)
    const uint64_t SQ = H + 0x0, CQ = H + 0x1000, BUF = H + 0x10000;
    wr64(*t, SFX_Q_REG(0, SFX_R_Q_SQ_BASE_LO), SQ);
    wr64(*t, SFX_Q_REG(0, SFX_R_Q_CQ_BASE_LO), CQ);
    t->wr32(SFX_Q_REG(0, SFX_R_Q_SIZE), 3 | (3u << 8));
    t->wr32(SFX_Q_REG(0, SFX_R_Q_CTRL), SFX_QCTL_ENABLE | (1u << 8));
    CHECK_EQ(t->rd32(SFX_Q_REG(0, SFX_R_Q_STATUS)) & 3, SFX_QS_ENABLED);
    t->wr32(SFX_R_CTRL, SFX_CTRL_ENABLE);
    t->wr32(SFX_R_IRQ_ENABLE, 1);

    unsigned irq_edges = 0;
    t->on_irq_rise = [&](unsigned) { ++irq_edges; };

    auto submit = [&](unsigned idx, const sfx_desc_t& d) {
        t->host.poke(SQ + (idx % 8) * 64, &d, sizeof d);
    };
    sfx_desc_t d{};
    d.opcode = SFX_OP_NOP; d.seq = 0; d.cmd_id = 0x11; d.desc_ver = 1; d.flags = SFX_F_IRQ;
    submit(0, d);
    // H2D copy of 256 bytes
    for (int i = 0; i < 256; ++i) t->host.poke_as<uint8_t>(BUF + i, uint8_t(i * 7 + 1));
    d = sfx_desc_t{};
    d.opcode = SFX_OP_COPY_H2D; d.seq = 1; d.cmd_id = 0x22; d.desc_ver = 1;
    d.addr0 = BUF; d.addr1 = 0x4000; d.length = 256;
    submit(1, d);
    // D2H copy back to a different host area
    d = sfx_desc_t{};
    d.opcode = SFX_OP_COPY_D2H; d.seq = 2; d.cmd_id = 0x33; d.desc_ver = 1; d.flags = SFX_F_FENCE_BEFORE | SFX_F_IRQ;
    d.addr0 = 0x4000; d.addr1 = BUF + 0x1000; d.length = 256;
    submit(2, d);
    t->wr32(SFX_DB_REG(0, SFX_R_DB_SQ_TAIL), 3);

    auto cqe_at = [&](unsigned n) { sfx_cqe_t c; t->host.peek(CQ + (n % 8) * 32, &c, sizeof c); return c; };
    for (int i = 0; i < 20000 && !(cqe_at(2).phase_word & 1); ++i) t->run(1);
    for (unsigned n = 0; n < 3; ++n) {
        sfx_cqe_t c = cqe_at(n);
        std::printf("cqe[%u]: id=0x%x seq=%u status=%s opcode=0x%x sq_head=%u result=%llu cq_seq=%u phase=%u\n", n,
                    c.cmd_id, c.sq_seq, sfx_status_str(c.status), c.opcode, c.sq_head,
                    (unsigned long long)c.result, c.cq_seq, c.phase_word & 1);
        CHECK_EQ(c.status, SFX_ST_OK);
        CHECK_EQ(c.sq_seq, n);
        CHECK_EQ(c.cq_seq, n);
        CHECK_EQ(c.phase_word & 1, 1u);
        CHECK_EQ(c.sq_head, n + 1);
    }
    CHECK_EQ(cqe_at(0).cmd_id, 0x11u);
    CHECK_EQ(cqe_at(1).result, 256u);
    CHECK_EQ(cqe_at(2).cmd_id, 0x33u);
    for (int i = 0; i < 256; ++i) {
        CHECK_EQ(t->dev.peek_as<uint8_t>(0x4000 + i), uint8_t(i * 7 + 1));
        CHECK_EQ(t->host.peek_as<uint8_t>(BUF + 0x1000 + i), uint8_t(i * 7 + 1));
    }
    CHECK(irq_edges >= 1);
    // The CQE is visible in host memory a few cycles before the Q_CQ_TAIL register counts it
    // (the counter advances after the phase-word write response), so wait for the register.
    for (int i = 0; i < 100 && t->rd32(SFX_Q_REG(0, SFX_R_Q_CQ_TAIL)) != 3u; ++i) t->run(1);
    CHECK_EQ(t->rd32(SFX_Q_REG(0, SFX_R_Q_CQ_TAIL)), 3u);
    CHECK_EQ(t->rd32(SFX_R_CMDS_OK), 3u);
    std::string pe = t->protocol_errors();
    if (!pe.empty()) { std::printf("PROTOCOL ERRORS:\n%s", pe.c_str()); return 1; }
    std::printf("rtl_smoke: PASS (irq edges=%u, t=%llu cycles)\n", irq_edges, (unsigned long long)t->now());
    return 0;
}
