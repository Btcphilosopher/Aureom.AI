// RtlTarget: the Verilated SFX-CP core behind the sfx::Target interface.
#pragma once
#include <memory>
#include <string>

#include "sfx_target.hpp"

namespace sfx {

// Factory used by the shared test runner. The RTL geometry is fixed when the design is
// Verilated (see Makefile variables SFX_NQ, SFX_NW, SFX_DATA_W, ...); the argument is ignored
// except for dev_mem_size, which must match the DEV_MEM_SIZE parameter used at build time.
std::unique_ptr<Target> make_rtl_target(const Geometry& g);

// RTL-only extras, reachable by dynamic_cast from a Target*.
class RtlOnly {
public:
    virtual ~RtlOnly() = default;
    // AXI4-Lite write with explicit byte strobes (to test partial-write rejection).
    virtual void wr32_strb(uint32_t off, uint32_t v, uint8_t strb) = 0;
    // Raw checker state, for diagnostics.
    virtual uint32_t checker_error_count() const = 0;
};

}  // namespace sfx
