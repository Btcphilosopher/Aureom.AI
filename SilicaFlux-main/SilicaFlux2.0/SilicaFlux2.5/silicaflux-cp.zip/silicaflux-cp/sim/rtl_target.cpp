// Verilator harness: cycle-accurate bus-functional models around the Verilated sfx_transport_sim.
//   * AXI4-Lite master            -> MMIO (rd32/wr32)
//   * two AXI4 slave memories     -> host (IOVA) and device memory, backed by SimMemory
//     with random ready/valid stalls, latency, per-transaction fault injection and "hung" mode
//   * compute-fabric BFM          -> KernelHook, abort, heartbeat
//   * interrupt level sampling    -> on_irq_rise
// Protocol rules on the core's master ports are checked inside the RTL (sfx_axi_checker.sv).
#include "rtl_target.hpp"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <vector>

#include "Vsfx_transport_sim.h"
#include "verilated.h"

#ifndef SFX_DATA_W
#define SFX_DATA_W 64
#endif
#ifndef SFX_NQ
#define SFX_NQ 2
#endif
#ifndef SFX_NW
#define SFX_NW 8
#endif
#ifndef SFX_MAXB
#define SFX_MAXB 16
#endif
#ifndef SFX_INFL
#define SFX_INFL 4
#endif

#if SFX_DATA_W == 64
using BusData = QData;
using BusStrb = CData;
#elif SFX_DATA_W == 128
using BusData = VlWide<4>;
using BusStrb = SData;
#elif SFX_DATA_W == 256
using BusData = VlWide<8>;
using BusStrb = IData;
#else
#error "SFX_DATA_W must be 64, 128 or 256"
#endif


#ifdef SFX_COVERAGE
// Optional: dump Verilator line coverage when each model is destroyed (the points are unregistered
// with the model, and the suite creates one model per test). One file per model under ./covdata;
// tools/cov_report.py merges them. See `make coverage-rtl`.
#include <sys/stat.h>
#include "verilated_cov.h"
static void sfx_dump_coverage() {
    static int n = 0;
    char name[64];
    ::mkdir("covdata", 0755);
    std::snprintf(name, sizeof name, "covdata/cov_%d.dat", n++);
    Verilated::threadContextp()->coveragep()->write(name);
}
#endif

namespace sfx {
namespace {

constexpr unsigned kBeat = SFX_DATA_W / 8;

inline void data_get(const QData& s, uint8_t* out) { std::memcpy(out, &s, 8); }
template <std::size_t N> inline void data_get(const VlWide<N>& s, uint8_t* out) {
    std::memcpy(out, s.data(), N * 4);
}
inline void data_set(QData& d, const uint8_t* in) { std::memcpy(&d, in, 8); }
template <std::size_t N> inline void data_set(VlWide<N>& d, const uint8_t* in) {
    std::memcpy(d.data(), in, N * 4);
}

struct Rng {
    uint64_t s = 1;
    uint32_t next() {
        s ^= s << 13; s ^= s >> 7; s ^= s << 17;
        return static_cast<uint32_t>(s >> 11);
    }
    bool pct(unsigned p) { return p >= 100 || (next() % 100) < p; }
    unsigned range(unsigned lo, unsigned hi) { return hi <= lo ? lo : lo + next() % (hi - lo + 1); }
};

// ---- one AXI4 slave memory port ---------------------------------------------------------
struct SlavePorts {
    // AR/R
    QData* araddr; CData* arlen; CData* arvalid; CData* arready;
    BusData* rdata; CData* rresp; CData* rlast; CData* rvalid; CData* rready;
    // AW/W/B
    QData* awaddr; CData* awlen; CData* awvalid; CData* awready;
    BusData* wdata; BusStrb* wstrb; CData* wlast; CData* wvalid; CData* wready;
    CData* bresp; CData* bvalid; CData* bready;
};

class SlaveBfm {
public:
    SlaveBfm(SimMemory& m, SlavePorts p, Rng& r, const BusProfile& prof, const uint64_t& clk,
             std::string& errs, const char* nm)
        : mem_(m), p_(p), rng_(r), prof_(prof), now_(clk), errs_(errs), name_(nm) {}

    void reset() {
        rq_.clear(); wq_.clear(); bq_.clear();
        r_pres_ = false; b_pres_ = false; w_open_ = false;
    }

    // Phase 1: decide this cycle's slave-driven inputs.
    void drive() {
        const bool hung = mem_.hung();
        *p_.arready = (!hung && rng_.pct(prof_.ready_pct)) ? 1 : 0;
        *p_.awready = (!hung && rng_.pct(prof_.ready_pct)) ? 1 : 0;
        // accept W only after its AW was accepted (the core is AW-first)
        *p_.wready  = (!hung && w_open_ && rng_.pct(prof_.ready_pct)) ? 1 : 0;

        // read data
        if (!r_pres_ && !hung && !rq_.empty() && now_ >= rq_.front().due && rng_.pct(prof_.valid_pct))
            r_pres_ = true;
        if (r_pres_ && !hung) {
            const auto& t = rq_.front();
            uint8_t buf[kBeat];
            if (t.resp == Resp::OKAY) std::memcpy(buf, mem_.ptr(t.addr + t.beat * kBeat, kBeat), kBeat);
            else std::memset(buf, 0xDD, kBeat);
            data_set(*p_.rdata, buf);
            *p_.rresp  = static_cast<uint8_t>(t.resp);
            *p_.rlast  = (t.beat + 1 == t.beats);
            *p_.rvalid = 1;
        } else {
            *p_.rvalid = 0; *p_.rlast = 0; *p_.rresp = 0;
        }
        // write response
        if (!b_pres_ && !hung && !bq_.empty() && now_ >= bq_.front().due && rng_.pct(prof_.valid_pct))
            b_pres_ = true;
        if (b_pres_ && !hung) { *p_.bvalid = 1; *p_.bresp = static_cast<uint8_t>(bq_.front().resp); }
        else                  { *p_.bvalid = 0; *p_.bresp = 0; }
    }

    // Phase 2: with settled signals, apply the handshakes that will occur at this clock edge.
    void sample() {
        if (mem_.hung()) return;
        // AR
        if (*p_.arvalid && *p_.arready) {
            Rd t;
            t.addr = *p_.araddr; t.beats = *p_.arlen + 1u; t.beat = 0;
            t.resp = mem_.txn(false, t.addr, uint64_t(t.beats) * kBeat);
            t.due = now_ + rng_.range(prof_.latency_min, prof_.latency_max);
            rq_.push_back(t);
        }
        // R beat accepted
        if (r_pres_ && *p_.rvalid && *p_.rready) {
            auto& t = rq_.front();
            if (++t.beat == t.beats) { rq_.pop_front(); }
            r_pres_ = false;
        }
        // AW
        if (*p_.awvalid && *p_.awready) {
            Wr t;
            t.addr = *p_.awaddr; t.beats = *p_.awlen + 1u; t.beat = 0;
            t.resp = mem_.txn(true, t.addr, uint64_t(t.beats) * kBeat);
            wq_.push_back(t);
            w_open_ = true;
        }
        // W beat
        if (*p_.wvalid && *p_.wready) {
            if (wq_.empty()) { note("W beat without AW"); }
            else {
                auto& t = wq_.front();
                uint8_t buf[kBeat], en[kBeat];
                data_get(*p_.wdata, buf);
                const uint64_t st = static_cast<uint64_t>(*p_.wstrb);
                for (unsigned i = 0; i < kBeat; ++i) en[i] = (st >> i) & 1;
                if (t.resp == Resp::OKAY) mem_.apply_write(t.addr + t.beat * kBeat, buf, kBeat, en);
                const bool last = (t.beat + 1 == t.beats);
                if (bool(*p_.wlast) != last) note("WLAST mismatch");
                ++t.beat;
                if (last) {
                    if (t.resp == Resp::OKAY) mem_.notify_write_done(t.addr, uint64_t(t.beats) * kBeat);
                    bq_.push_back({t.resp, now_ + rng_.range(prof_.latency_min, prof_.latency_max)});
                    wq_.pop_front();
                    w_open_ = !wq_.empty();
                }
            }
        }
        // B accepted
        if (b_pres_ && *p_.bvalid && *p_.bready) { bq_.pop_front(); b_pres_ = false; }
    }

private:
    struct Rd { uint64_t addr; unsigned beats, beat; Resp resp; uint64_t due; };
    struct Wr { uint64_t addr; unsigned beats, beat; Resp resp; };
    struct Br { Resp resp; uint64_t due; };
    void note(const char* what) { errs_ += name_ + ": " + what + "\n"; }

    SimMemory& mem_;
    SlavePorts p_;
    Rng& rng_;
    const BusProfile& prof_;
    const uint64_t& now_;
    std::string& errs_;
    std::string name_;
    std::deque<Rd> rq_;
    std::deque<Wr> wq_;
    std::deque<Br> bq_;
    bool r_pres_ = false, b_pres_ = false, w_open_ = false;
};

// ---- the Target ----------------------------------------------------------------------------
class RtlTargetImpl : public Target, public RtlOnly {
public:
    explicit RtlTargetImpl(const Geometry& g)
        : Target(0x0000400000000000ull, 8u << 20, g.dev_mem_size), top_(new Vsfx_transport_sim) {
        geo_ = g;
        geo_.num_queues = SFX_NQ;
        geo_.num_windows = SFX_NW;
        geo_.num_vectors = SFX_NQ + 1;
        geo_.inflight_depth = SFX_INFL;
        geo_.beat_bytes = kBeat;
        geo_.dma_align = kBeat;
        geo_.max_burst_beats = SFX_MAXB;

        SlavePorts h{&top_->m_host_araddr, &top_->m_host_arlen, &top_->m_host_arvalid, &top_->m_host_arready,
                     &top_->m_host_rdata, &top_->m_host_rresp, &top_->m_host_rlast, &top_->m_host_rvalid,
                     &top_->m_host_rready,
                     &top_->m_host_awaddr, &top_->m_host_awlen, &top_->m_host_awvalid, &top_->m_host_awready,
                     &top_->m_host_wdata, &top_->m_host_wstrb, &top_->m_host_wlast, &top_->m_host_wvalid,
                     &top_->m_host_wready, &top_->m_host_bresp, &top_->m_host_bvalid, &top_->m_host_bready};
        SlavePorts d{&top_->m_dev_araddr, &top_->m_dev_arlen, &top_->m_dev_arvalid, &top_->m_dev_arready,
                     &top_->m_dev_rdata, &top_->m_dev_rresp, &top_->m_dev_rlast, &top_->m_dev_rvalid,
                     &top_->m_dev_rready,
                     &top_->m_dev_awaddr, &top_->m_dev_awlen, &top_->m_dev_awvalid, &top_->m_dev_awready,
                     &top_->m_dev_wdata, &top_->m_dev_wstrb, &top_->m_dev_wlast, &top_->m_dev_wvalid,
                     &top_->m_dev_wready, &top_->m_dev_bresp, &top_->m_dev_bvalid, &top_->m_dev_bready};
        host_bfm_.reset(new SlaveBfm(host, h, rng_, prof_, time_, bfm_errs_, "host-bus"));
        dev_bfm_.reset(new SlaveBfm(dev, d, rng_, prof_, time_, bfm_errs_, "dev-bus"));
        rng_.s = prof_.seed;
        power_on_reset();
    }
    ~RtlTargetImpl() override {
        top_->final();
#ifdef SFX_COVERAGE
        sfx_dump_coverage();
#endif
    }

    const char* name() const override { return "rtl"; }
    bool is_rtl() const override { return true; }
    const Geometry& geometry() const override { return geo_; }

    void set_bus_profile(const BusProfile& p) override {
        prof_ = p;
        rng_.s = p.seed ? p.seed : 1;
    }

    void run(uint64_t n) override { for (uint64_t i = 0; i < n; ++i) cycle(); }

    void hard_reset() override { power_on_reset(); }

    bool irq_level(unsigned vec) const override { return (top_->irq_level >> vec) & 1; }

    std::string protocol_errors() const override {
        std::string s = bfm_errs_;
        if (top_->chk_err_count) {
            char b[160];
            std::snprintf(b, sizeof b, "RTL checker: %u violations (host flags 0x%x, dev flags 0x%x, lite flags 0x%x)\n",
                          unsigned(top_->chk_err_count), unsigned(top_->chk_host_flags),
                          unsigned(top_->chk_dev_flags), unsigned(top_->chk_axil_flags));
            s += b;
        }
        return s;
    }
    uint32_t checker_error_count() const override { return top_->chk_err_count; }

    // ---- MMIO -----------------------------------------------------------------------------
    uint32_t rd32(uint32_t off) override {
        idle_gap();
        lite_ = Lite{};
        lite_.is_read = true; lite_.addr = off; lite_.ar_pend = true; lite_.active = true;
        while (lite_.active) cycle();
        return lite_.rdata;
    }
    void wr32(uint32_t off, uint32_t v) override { wr32_strb(off, v, 0xF); }
    void wr32_strb(uint32_t off, uint32_t v, uint8_t strb) override {
        idle_gap();
        lite_ = Lite{};
        lite_.addr = off; lite_.wdata = v; lite_.wstrb = strb;
        lite_.aw_pend = lite_.w_pend = lite_.b_wait = true; lite_.active = true;
        while (lite_.active) cycle();
    }

private:
    struct Lite {
        bool active = false, is_read = false;
        bool aw_pend = false, w_pend = false, b_wait = false, ar_pend = false, r_wait = false;
        uint32_t addr = 0, wdata = 0, rdata = 0;
        uint8_t wstrb = 0xF;
    };
    struct Kern {
        uint32_t tag; uint64_t finish; bool hang; uint8_t status; uint64_t info; uint32_t hb;
    };

    void idle_gap() { for (unsigned i = 0; i < prof_.lite_gap; ++i) cycle(); }

    void power_on_reset() {
        host_bfm_->reset(); dev_bfm_->reset();
        host.set_hang(false); dev.set_hang(false);
        kerns_.clear(); kdone_q_.clear();
        lite_ = Lite{};
        top_->rst_n = 0;
        top_->s_axil_awvalid = top_->s_axil_wvalid = top_->s_axil_arvalid = 0;
        top_->s_axil_bready = top_->s_axil_rready = 0;
        top_->kd_ready = 0; top_->kd_done_valid = 0; top_->kd_heartbeat = 0;
        top_->kd_done_tag = 0; top_->kd_done_status = 0; top_->kd_done_info = 0;
        top_->m_host_arready = top_->m_host_awready = top_->m_host_wready = 0;
        top_->m_dev_arready = top_->m_dev_awready = top_->m_dev_wready = 0;
        top_->m_host_rvalid = top_->m_host_bvalid = top_->m_dev_rvalid = top_->m_dev_bvalid = 0;
        top_->m_host_bid = top_->m_host_rid = top_->m_dev_bid = top_->m_dev_rid = 0;
        for (int i = 0; i < 6; ++i) { top_->clk = 0; top_->eval(); top_->clk = 1; top_->eval(); ++time_; }
        top_->rst_n = 1;
        prev_irq_ = top_->irq_level;
    }

    void kd_drive() {
        const bool abort = top_->kd_abort;
        top_->kd_ready = (kerns_.size() < 4 && rng_.pct(prof_.ready_pct)) ? 1 : 0;
        top_->kd_done_valid = 0;
        top_->kd_heartbeat = 0;
        // heartbeats
        for (const auto& k : kerns_)
            if (k.hb && (time_ % k.hb) == 0) top_->kd_heartbeat = 1;
        // completions: one pulse per cycle
        int pick = -1;
        for (size_t i = 0; i < kerns_.size(); ++i) {
            const auto& k = kerns_[i];
            if (abort || (!k.hang && time_ >= k.finish)) { pick = int(i); break; }
        }
        if (pick >= 0) {
            const Kern k = kerns_[pick];
            top_->kd_done_valid = 1;
            top_->kd_done_tag = k.tag;
            top_->kd_done_status = abort ? 2 : k.status;
            top_->kd_done_info = abort ? 0 : k.info;
            kerns_.erase(kerns_.begin() + pick);
        }
    }

    void lite_drive() {
        top_->s_axil_awvalid = lite_.aw_pend;
        top_->s_axil_awaddr = lite_.addr;
        top_->s_axil_wvalid = lite_.w_pend;
        top_->s_axil_wdata = lite_.wdata;
        top_->s_axil_wstrb = lite_.wstrb;
        top_->s_axil_bready = lite_.b_wait;
        top_->s_axil_arvalid = lite_.ar_pend;
        top_->s_axil_araddr = lite_.addr;
        top_->s_axil_rready = lite_.r_wait || lite_.ar_pend;
    }
    void lite_sample() {
        if (!lite_.active) return;
        if (lite_.aw_pend && top_->s_axil_awready) lite_.aw_pend = false;
        if (lite_.w_pend && top_->s_axil_wready) lite_.w_pend = false;
        if (lite_.b_wait && !lite_.aw_pend && !lite_.w_pend && top_->s_axil_bvalid) {
            lite_.b_wait = false; lite_.active = false;
        }
        if (lite_.ar_pend && top_->s_axil_arready) { lite_.ar_pend = false; lite_.r_wait = true; }
        else if (lite_.r_wait && top_->s_axil_rvalid) {
            lite_.rdata = top_->s_axil_rdata; lite_.r_wait = false; lite_.active = false;
        }
    }

    void kd_sample() {
        if (top_->kd_valid && top_->kd_ready) {
            KernelReq r;
            r.tag = top_->kd_tag; r.cmd_id = top_->kd_cmd_id;
            r.kernel_addr = top_->kd_kernel_addr; r.args_addr = top_->kd_args_addr;
            r.args_size = top_->kd_args_size;
            r.grid[0] = top_->kd_grid_x; r.grid[1] = top_->kd_grid_y; r.grid[2] = top_->kd_grid_z;
            r.domain = top_->kd_domain;
            kernels_launched.push_back(r);
            KernelResult res;
            if (kernel_hook) res = kernel_hook(r);
            kerns_.push_back({r.tag, time_ + std::max<uint32_t>(res.latency, 1), res.hang,
                              res.status, res.info, res.heartbeat_period});
        }
    }

    void cycle() {
        // 1. slave-side / master-side inputs for this cycle
        host_bfm_->drive();
        dev_bfm_->drive();
        kd_drive();
        lite_drive();
        top_->clk = 0;
        top_->eval();
        // 2. handshakes that complete at the coming edge (settled values)
        host_bfm_->sample();
        dev_bfm_->sample();
        kd_sample();
        lite_sample();
        // trace pulses: sampled here, in the settled pre-edge state, because dbg_issue is combinational
        // on kd_ready and dbg_pub is the phase-word W handshake (the instant the entry becomes visible).
        if (top_->dbg_issue_valid)    events.push_back({EvKind::Issue, time_, top_->dbg_issue_cmd_id, 0});
        if (top_->dbg_dma_done_valid) events.push_back({EvKind::DmaDone, time_, top_->dbg_dma_done_cmd_id, 0});
        if (top_->dbg_pub_valid && top_->m_host_wvalid && top_->m_host_wready)
            events.push_back({EvKind::Publish, time_, top_->dbg_pub_cmd_id, 0});
        // 3. clock edge
        top_->clk = 1;
        top_->eval();
        ++time_;
        // 4. observations
        const uint32_t irq = top_->irq_level;
        const uint32_t rise = irq & ~prev_irq_;
        prev_irq_ = irq;
        if (rise && on_irq_rise)
            for (unsigned v = 0; v < 32; ++v)
                if ((rise >> v) & 1) on_irq_rise(v);
    }

    Geometry geo_;
    BusProfile prof_;
    Rng rng_;
    std::unique_ptr<Vsfx_transport_sim> top_;
    std::unique_ptr<SlaveBfm> host_bfm_, dev_bfm_;
    std::string bfm_errs_;
    Lite lite_;
    std::vector<Kern> kerns_;
    std::deque<Kern> kdone_q_;
    uint32_t prev_irq_ = 0;
};

}  // namespace

std::unique_ptr<Target> make_rtl_target(const Geometry& g) {
    return std::unique_ptr<Target>(new RtlTargetImpl(g));
}

}  // namespace sfx
