#!/usr/bin/env python3
"""Mutation sanity check: does the shared test-suite notice realistic RTL bugs?

For each mutation this script copies the project to a scratch directory, injects one small bug into
the RTL (an exact, asserted-unique text substitution), builds the Verilated test binary and runs the
suite. A mutation is KILLED if at least one test fails, SURVIVED if every test still passes (which
means the suite has a hole, or the mutation is equivalent).

It never touches the working tree. Usage:
    python3 tools/mutation_check.py [--only NAME ...] [--profile all|ideal|stall|latency] [--keep] [--out FILE]
Needs Verilator and a C++ toolchain, like `make test-rtl`.
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# name, file, old text (must occur exactly once), new text, what real bug it stands for
MUTATIONS = [
    ("dma_burst_crosses_4k", "rtl/sfx_dma.sv",
     "b4k  = (32'd4096 - {20'b0, addr[11:0]}) >> BLOG2;", "b4k  = (32'd8192 - {20'b0, addr[11:0]}) >> BLOG2;",
     "bursts cross a 4 KiB boundary (AXI protocol violation)"),
    ("dma_burst_exceeds_max", "rtl/sfx_dma.sv",
     "m    = (m < 32'(MAXB)) ? m : 32'(MAXB);", "m    = (m < 32'(MAXB) + 32'd1) ? m : 32'(MAXB) + 32'd1;",
     "bursts longer than the advertised maximum"),
    ("irq_before_visibility", "rtl/sfx_retire.sv",
     ["RT_C2_REQ: if (rw_req_ack) st <= RT_C2_W;",
      "            pub_valid          <= 1'b1;\n            pub_q              <= eq;\n            pub_irq            <= ((e.flags & SFX_F_IRQ) != 16'd0);\n"],
     ["RT_C2_REQ: if (rw_req_ack) begin st <= RT_C2_W; pub_valid <= 1'b1; pub_q <= eq; pub_irq <= ((e.flags & SFX_F_IRQ) != 16'd0); end",
      ""],
     "interrupt raised before the completion is visible to the host (violates D4)"),
    ("reset_key_unchecked", "rtl/sfx_regs.sv",
     "if (wr_data[31:16] == 16'(SFX_RESET_KEY) && wr_data[0]) begin", "if (wr_data[0]) begin",
     "any write with bit 0 set resets the device"),
    ("reset_no_kernel_abort", "rtl/sfx_cp_core.sv",
     "assign kd_abort = quiesce | fault;", "assign kd_abort = fault;",
     "controlled reset does not stop running kernels"),
    ("cq_credit_removed", "rtl/sfx_frontend.sv",
     "q_work[q] = q_enabled[q] && q_credit[q] && (q_sq_tail[q] != q_sq_head[q]);",
     "q_work[q] = q_enabled[q] && (q_sq_tail[q] != q_sq_head[q]);",
     "one tenant's unreleased CQ stalls every queue's completions (head-of-line blocking)"),
    ("irq_stale_coalescing_state", "rtl/sfx_irq.sv",
     "      for (int q = 0; q < NQ; q++)\n        if (!q_enabled[q]) begin cnt[q] <= '0; tmr[q] <= '0; tmr_on[q] <= 1'b0; end\n",
     "",
     "a stale coalescing timer fires on a re-enabled queue"),
    ("doorbell_error_raises_dev_err", "rtl/sfx_regs.sv",
     "if ((err_ev & ~err_status) != 32'd0 && w_page == 4'd0) irq_set[8] = 1'b1;",
     "if ((err_ev & ~err_status) != 32'd0) irq_set[8] = 1'b1;",
     "an untrusted doorbell writer can raise kernel-visible DEV_ERR interrupts"),
    ("authz_ignores_domain", "rtl/sfx_authz.sv",
     "&& (win_dom[i]   == q_dom)", "&& 1'b1",
     "a queue can use another domain's windows"),
    ("authz_ignores_write_perm", "rtl/sfx_authz.sv",
     "&& (q_wr ? win_w[i] : win_r[i])", "&& (win_r[i] | win_w[i])",
     "a read-only window accepts device writes"),
    ("authz_exact_fit_rejected", "rtl/sfx_authz.sv",
     "&& (q_end <= w_end);", "&& (q_end < w_end);",
     "off-by-one at the end of a window"),
    ("authz_overrun_allowed", "rtl/sfx_authz.sv",
     "&& (q_end <= w_end);", "&& (q_end <= w_end + 65'd4096);",
     "access may run past the end of a window"),
    ("dma_no_per_burst_recheck_read", "rtl/sfx_dma.sv",
     ["            if (r_authz_ok) begin\n              rd_use <= r_hit;",
      "end else if (!r_halt && r_space_ok && !r_authz_ok) begin"],
     ["            if (1'b1) begin\n              rd_use <= r_hit;",
      "end else if (1'b0) begin"],
     "a revoked source window is still read mid-transfer"),
    ("dma_no_per_burst_recheck_write", "rtl/sfx_dma.sv",
     ["            if (w_authz_ok) begin\n              wr_use <= w_hit;",
      "end else if ((w_can_go || (rd_fin && avail != '0)) && !w_authz_ok) begin"],
     ["            if (1'b1) begin\n              wr_use <= w_hit;",
      "end else if ((w_can_go || (rd_fin && avail != '0)) && 1'b0) begin"],
     "a revoked destination window is still written mid-transfer"),
    ("cqe_not_two_phase", "rtl/sfx_retire.sv",
     "body_strb[b] = ((int'(cnt) * BEAT + b) < 28);", "body_strb[b] = ((int'(cnt) * BEAT + b) < 32);",
     "phase word is published together with the body"),
    ("doorbell_duplicate_is_error", "rtl/sfx_regs.sv",
     "if (wr_data == sqt[dbq])                        dup_cnt <= dup_cnt + 32'd1;",
     "if (wr_data == sqt[dbq])                        err_ev |= SFX_ERR_BAD_DOORBELL;",
     "re-ringing the same doorbell is treated as an error"),
    ("doorbell_overrun_allowed", "rtl/sfx_regs.sv",
     "dnew <= (32'd1 << sql[dbq])", "dnew <= (32'd2 << sql[dbq])",
     "tail may run more than one ring ahead of the head"),
    ("doorbell_cqhead_beyond_tail", "rtl/sfx_regs.sv",
     "else if (dnew <= dmax)                          cqh[dbq] <= wr_data;",
     "else if (1'b1)                                  cqh[dbq] <= wr_data;",
     "host may release CQ entries that were never published"),
    ("seq_check_disabled", "rtl/sfx_decode.sv",
     "assign seq_ok = (desc[63:32] == exp_seq);", "assign seq_ok = 1'b1;",
     "stale/torn descriptors are executed"),
    ("decode_length_vs_align_swapped", "rtl/sfx_decode.sv",
     "      if (copy_len_bad)                                       status = SFX_ST_BAD_LENGTH;\n      else if (copy_align_bad)                                status = SFX_ST_BAD_ALIGN;",
     "      if (copy_align_bad)                                     status = SFX_ST_BAD_ALIGN;\n      else if (copy_len_bad)                                  status = SFX_ST_BAD_LENGTH;",
     "validation precedence differs from the spec"),
    ("decode_range_check_dropped", "rtl/sfx_decode.sv",
     "else if (a_range_bad || b_range_bad)                    status = SFX_ST_BAD_RANGE;\n      else if (auth_bad)                                      status = SFX_ST_UNAUTHORIZED;\n    end else if (is_kernel)",
     "else if (auth_bad)                                      status = SFX_ST_UNAUTHORIZED;\n    end else if (is_kernel)",
     "out-of-range addresses are reported as unauthorised (or worse)"),
    ("fence_barrier_not_enforced", "rtl/sfx_frontend.sv",
     "&& (d_fence || !fence_present)", "&& 1'b1",
     "commands behind a FENCE start before it retires"),
    ("fence_before_ignored", "rtl/sfx_frontend.sv",
     "|| inf_empty);", "|| 1'b1);",
     "F_FENCE_BEFORE does not wait for earlier commands"),
    ("cq_full_overwrites", ["rtl/sfx_retire.sv", "rtl/sfx_cp_core.sv"],
     ["else if (!cq_full) st <= RT_CQ_AUTH;",
      "q_credit[q] = ((q_sq_head[q] - q_cq_head[q]) < (32'd1 << q_cq_log2[q]));"],
     ["else st <= RT_CQ_AUTH;",
      "q_credit[q] = ((q_sq_head[q] - q_cq_head[q]) <= (32'd1 << q_cq_log2[q]));"],
     "device overwrites completions the host has not consumed (credit off by one AND no CQ-space check; "
     "removing only the now-unreachable check is an equivalent mutant)"),
    ("phase_never_toggles", "rtl/sfx_retire.sv",
     "assign phase     = ~lap[0];", "assign phase     = 1'b1;",
     "phase bit never toggles on ring wrap"),
    ("irq_without_blank", "rtl/sfx_irq.sv",
     "    if (blank) irq_level = '0;", "    // (re-arm blanking removed)",
     "pending causes are lost after a partial W1C acknowledge"),
    ("reset_keeps_windows", "rtl/sfx_regs.sv",
     "        w_valid_r <= '0; w_err_r <= '0; w_space_r <= '0; w_r_r <= '0; w_w_r <= '0;\n        w_dom_r <= '0; w_base_r <= '0; w_size_r <= '0;\n        qstate <= '0;",
     "        w_err_r <= '0;\n        qstate <= '0;",
     "controlled reset leaves old DMA authorisations alive"),
    ("reset_skips_drain", "rtl/sfx_reset_ctl.sv",
     "if (all_idle && stable >= 3'd4) begin", "if (1'b1) begin",
     "controlled reset does not wait for outstanding bus transactions"),
    ("watchdog_never_fires", "rtl/sfx_wdt.sv",
     "end else if (count + 32'd1 >= timeout) begin", "end else if (1'b0) begin",
     "a hung kernel is never detected"),
]


def sh(cmd, cwd, env, log):
    with open(log, "ab") as f:
        f.write(("\n$ " + " ".join(cmd) + "\n").encode())
        return subprocess.run(cmd, cwd=cwd, env=env, stdout=f, stderr=subprocess.STDOUT).returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*", default=[])
    ap.add_argument("--profile", default="all")
    ap.add_argument("--keep", action="store_true")
    ap.add_argument("--out", default=None)
    ap.add_argument("--jobs", type=int, default=2, help="parallel mutations")
    a = ap.parse_args()

    muts = [m for m in MUTATIONS if not a.only or m[0] in a.only]
    work_root = tempfile.mkdtemp(prefix="sfx_mut_")
    env = dict(os.environ)
    results = []

    # Validate every mutation applies exactly once before spending build time.
    for name, f, old, new, why in muts:
        olds = old if isinstance(old, list) else [old]
        files = f if isinstance(f, list) else [f] * len(olds)
        for fn, o in zip(files, olds):
            txt = open(os.path.join(ROOT, fn)).read()
            if txt.count(o) != 1:
                print("MUTATION DOES NOT APPLY EXACTLY ONCE: %s (%d matches in %s)" % (name, txt.count(o), fn))
                return 2

    def run_one(m):
        name, f, old, new, why = m
        wd = os.path.join(work_root, name)
        shutil.copytree(ROOT, wd, ignore=shutil.ignore_patterns("build", "*.zip", "__pycache__"))
        olds = old if isinstance(old, list) else [old]
        news = new if isinstance(new, list) else [new]
        files = f if isinstance(f, list) else [f] * len(olds)
        for fn, o, n in zip(files, olds, news):
            p = os.path.join(wd, fn)
            txt = open(p).read()
            open(p, "w").write(txt.replace(o, n))
        log = os.path.join(work_root, name + ".log")
        rc = sh(["make", "-f", "Makefile.rtl", "build-rtl-tests"], wd, env, log)
        if rc != 0:
            return (name, why, "BUILD-FAIL", [])
        exe = None
        for d in os.listdir(os.path.join(wd, "build")):
            c = os.path.join(wd, "build", d, "sfx_tests_rtl")
            if os.path.exists(c):
                exe = c
        out = subprocess.run([exe, "--target=rtl", "--profile=" + a.profile], cwd=wd, env=env,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=1800).stdout.decode()
        failed = re.findall(r"^FAIL\s+(\S+?)\[", out, re.M)
        return (name, why, "KILLED" if failed else "SURVIVED", failed)

    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(run_one, muts):
            results.append(r)
            print("%-34s %-9s %s" % (r[0], r[2], (", ".join(sorted(set(r[3])))[:90] if r[3] else "")))
            sys.stdout.flush()

    killed = sum(1 for r in results if r[2] == "KILLED")
    print("\n%d/%d mutations killed" % (killed, len(results)))
    if a.out:
        with open(a.out, "w") as fh:
            fh.write("# Mutation sanity results\n\n")
            fh.write("Generated by `tools/mutation_check.py` (profile `%s`). Each row injects one bug into the RTL; "
                     "KILLED means at least one test in the shared suite failed.\n\n" % a.profile)
            fh.write("| Mutation | Models the bug | Result | Tests that caught it |\n|---|---|---|---|\n")
            for n, why, res, failed in results:
                fh.write("| `%s` | %s | **%s** | %s |\n" % (n, why, res, ", ".join("`%s`" % x for x in sorted(set(failed))) or "-"))
            fh.write("\n%d of %d mutations killed.\n" % (killed, len(results)))
    if not a.keep:
        shutil.rmtree(work_root, ignore_errors=True)
    else:
        print("work dir kept:", work_root)
    return 0 if killed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
