#!/usr/bin/env python3
"""Summarise a Verilator `coverage.dat` (line coverage) per RTL source file.

Verilator's coverage points are per instance; this merges them by (file, line, column) so a line counts
as covered if *any* instance executed it. Usage:
    python3 tools/cov_report.py coverage.dat [--md OUT.md] [--list-uncovered]
`make coverage-rtl` builds the suite with --coverage-line, runs it on all bus profiles and calls this.
Line coverage only says a line ran; it does not say the behaviour was checked.
"""
import argparse
import collections
import os
import re
import sys


def parse_many(paths):
    pts = collections.defaultdict(int)
    for p in paths:
        parse(p, pts)
    return pts


def parse(path, pts=None):
    if pts is None:
        pts = collections.defaultdict(int)  # (file, line, col, kind) -> count
    with open(path, encoding="latin-1") as fh:
        for raw in fh:
            if not raw.startswith("C '"):
                continue
            body, _, cnt = raw.rstrip("\n").rpartition("' ")
            key = body[3:]
            fields = {}
            for part in key.split("\x01"):
                if "\x02" in part:
                    k, v = part.split("\x02", 1)
                    fields[k] = v
            if fields.get("page", "").split("/")[0] != "v_line":
                continue
            f = fields.get("f", "?")
            pts[(f, int(fields.get("l", "0")), fields.get("n", "0"), fields.get("o", ""))] += int(cnt)
    return pts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dat", nargs="+", help="coverage.dat file(s) or a directory of them")
    ap.add_argument("--md")
    ap.add_argument("--list-uncovered", action="store_true")
    ap.add_argument("--only", default="rtl/", help="only report files whose path contains this")
    a = ap.parse_args()

    paths = []
    for d in a.dat:
        if os.path.isdir(d):
            paths += [os.path.join(d, f) for f in sorted(os.listdir(d)) if f.endswith(".dat")]
        else:
            paths.append(d)
    pts = parse_many(paths)
    per = collections.defaultdict(lambda: [0, 0, set()])  # file -> [total, hit, uncovered lines]
    for (f, line, col, kind), c in pts.items():
        if a.only not in f:
            continue
        per[f][0] += 1
        if c > 0:
            per[f][1] += 1
        else:
            per[f][2].add(line)

    tot = sum(v[0] for v in per.values())
    hit = sum(v[1] for v in per.values())
    rows = []
    for f in sorted(per):
        t, h, unc = per[f]
        rows.append((os.path.basename(f), t, h, 100.0 * h / t if t else 100.0, sorted(unc)))
    out = ["| File | Line points | Executed | % |", "|---|---:|---:|---:|"]
    for n, t, h, pct, unc in rows:
        out.append("| `%s` | %d | %d | %.1f |" % (n, t, h, pct))
    out.append("| **total** | **%d** | **%d** | **%.1f** |" % (tot, hit, 100.0 * hit / tot if tot else 100.0))
    text = "\n".join(out)
    print(text)
    if a.list_uncovered:
        print()
        for n, t, h, pct, unc in rows:
            if unc:
                print("%s: %s" % (n, ", ".join(str(x) for x in unc)))
    if a.md:
        with open(a.md, "w") as fh:
            fh.write("# RTL line coverage (Verilator, shared suite, all bus profiles)\n\n" + text + "\n\n")
            fh.write("Uncovered lines (no instance executed them):\n\n")
            for n, t, h, pct, unc in rows:
                if unc:
                    fh.write("* `%s`: %s\n" % (n, ", ".join(str(x) for x in unc)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
