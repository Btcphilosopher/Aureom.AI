// Simulation-only AXI protocol checkers. These assert the *rules the core promises to obey*
// (SPEC 14.1). They are a testbench aid, not a claim of AXI conformance certification.
//
// sfx_axi_master_checker : watches an AXI4 master port of the core.
//   flag bit  rule
//   0  AW payload/valid not stable while stalled     5  W: WLAST not on the final beat / missing
//   1  AR payload/valid not stable while stalled     6  W beat with no AW outstanding (AW-first rule)
//   2  W  payload/valid not stable while stalled     7  WSTRB == 0
//   3  AW illegal (len, size, burst, align, 4 KiB)   8  second write burst started before B (1 outstanding)
//   4  AR illegal (len, size, burst, align, 4 KiB)   9  second read burst started before RLAST (1 outstanding)
module sfx_axi_master_checker #(
  parameter int DATA_W = 64,
  parameter int MAXB   = 16,
  parameter string NAME = "axi"
) (
  input  logic                clk,
  input  logic                rst_n,
  input  logic [63:0]         awaddr,
  input  logic [7:0]          awlen,
  input  logic [2:0]          awsize,
  input  logic [1:0]          awburst,
  input  logic                awvalid,
  input  logic                awready,
  input  logic [DATA_W-1:0]   wdata,
  input  logic [DATA_W/8-1:0] wstrb,
  input  logic                wlast,
  input  logic                wvalid,
  input  logic                wready,
  input  logic                bvalid,
  input  logic                bready,
  input  logic [63:0]         araddr,
  input  logic [7:0]          arlen,
  input  logic [2:0]          arsize,
  input  logic [1:0]          arburst,
  input  logic                arvalid,
  input  logic                arready,
  input  logic                rvalid,
  input  logic                rready,
  input  logic                rlast,
  output logic [15:0]         flags,
  output logic [31:0]         err_count
);
  localparam int BYTES = DATA_W / 8;

  logic                p_awvalid, p_awready, p_arvalid, p_arready, p_wvalid, p_wready;
  logic [63:0]             p_awaddr, p_araddr;
  logic [7:0]              p_awlen, p_arlen;
  logic [2:0]              p_awsize, p_arsize;
  logic [1:0]              p_awburst, p_arburst;
  logic [DATA_W-1:0]       p_wdata;
  logic [DATA_W/8-1:0]     p_wstrb;
  logic                    p_wlast;

  logic        wr_open, rd_open;       // burst accepted, response not yet complete
  logic [8:0]  w_cnt;
  logic [7:0]  w_len;

  function automatic logic burst_ok(input logic [63:0] a, input logic [7:0] len,
                                    input logic [2:0] size, input logic [1:0] burst);
    logic [31:0] span;
    span = ({24'b0, len} + 32'd1) * BYTES;
    burst_ok = ((int'(len) + 1) <= MAXB) && (size == 3'($clog2(BYTES))) && (burst == 2'b01)
            && ((a & 64'(BYTES - 1)) == 0) && ((32'(a[11:0]) + span) <= 32'd4096);
  endfunction

  task automatic flag(input int bit_idx);
    if (!flags[bit_idx]) $display("[%s] AXI CHECK FAIL: rule %0d at t=%0t", NAME, bit_idx, $time);
    flags[bit_idx] <= 1'b1;
    err_count <= err_count + 32'd1;
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      flags <= '0; err_count <= '0;
      p_awvalid <= 1'b0; p_awready <= 1'b0; p_arvalid <= 1'b0; p_arready <= 1'b0;
      p_wvalid <= 1'b0; p_wready <= 1'b0;
      wr_open <= 1'b0; rd_open <= 1'b0; w_cnt <= '0; w_len <= '0;
      p_awaddr <= '0; p_araddr <= '0; p_awlen <= '0; p_arlen <= '0; p_awsize <= '0; p_arsize <= '0;
      p_awburst <= '0; p_arburst <= '0; p_wdata <= '0; p_wstrb <= '0; p_wlast <= 1'b0;
    end else begin
      // ---- stability while stalled
      if (p_awvalid && !p_awready &&
          !(awvalid && awaddr == p_awaddr && awlen == p_awlen && awsize == p_awsize && awburst == p_awburst))
        flag(0);
      if (p_arvalid && !p_arready &&
          !(arvalid && araddr == p_araddr && arlen == p_arlen && arsize == p_arsize && arburst == p_arburst))
        flag(1);
      if (p_wvalid && !p_wready &&
          !(wvalid && wdata == p_wdata && wstrb == p_wstrb && wlast == p_wlast))
        flag(2);

      // ---- AW handshake
      if (awvalid && awready) begin
        if (!burst_ok(awaddr, awlen, awsize, awburst)) flag(3);
        if (wr_open) flag(8);
        wr_open <= 1'b1; w_cnt <= '0; w_len <= awlen;
      end
      // ---- W handshake
      if (wvalid && wready) begin
        if (!(wr_open || (awvalid && awready))) flag(6);
        if (wstrb == '0) flag(7);
        if (wlast != (w_cnt[7:0] == ((awvalid && awready && !wr_open) ? awlen : w_len))) flag(5);
        w_cnt <= w_cnt + 9'd1;
      end
      // ---- B
      if (bvalid && bready) wr_open <= 1'b0;

      // ---- AR / R
      if (arvalid && arready) begin
        if (!burst_ok(araddr, arlen, arsize, arburst)) flag(4);
        if (rd_open) flag(9);
        rd_open <= 1'b1;
      end
      if (rvalid && rready && rlast) rd_open <= 1'b0;

      p_awvalid <= awvalid; p_awready <= awready; p_awaddr <= awaddr; p_awlen <= awlen;
      p_awsize <= awsize; p_awburst <= awburst;
      p_arvalid <= arvalid; p_arready <= arready; p_araddr <= araddr; p_arlen <= arlen;
      p_arsize <= arsize; p_arburst <= arburst;
      p_wvalid <= wvalid; p_wready <= wready; p_wdata <= wdata; p_wstrb <= wstrb; p_wlast <= wlast;
    end
  end

endmodule

// AXI4-Lite slave-side response checker: B and R must hold stable until accepted.
module sfx_axil_checker (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        bvalid,
  input  logic        bready,
  input  logic [1:0]  bresp,
  input  logic        rvalid,
  input  logic        rready,
  input  logic [31:0] rdata,
  input  logic [1:0]  rresp,
  output logic [3:0]  flags,
  output logic [31:0] err_count
);
  logic p_bvalid, p_bready, p_rvalid, p_rready;
  logic [1:0] p_bresp, p_rresp;
  logic [31:0] p_rdata;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      flags <= '0; err_count <= '0;
      p_bvalid <= 1'b0; p_bready <= 1'b0; p_rvalid <= 1'b0; p_rready <= 1'b0;
      p_bresp <= '0; p_rresp <= '0; p_rdata <= '0;
    end else begin
      if (p_bvalid && !p_bready && !(bvalid && bresp == p_bresp)) begin flags[0] <= 1'b1; err_count <= err_count + 1; end
      if (p_rvalid && !p_rready && !(rvalid && rresp == p_rresp && rdata == p_rdata)) begin flags[1] <= 1'b1; err_count <= err_count + 1; end
      if ((bvalid && bresp != 2'b00) || (rvalid && rresp != 2'b00)) begin flags[2] <= 1'b1; err_count <= err_count + 1; end
      p_bvalid <= bvalid; p_bready <= bready; p_bresp <= bresp;
      p_rvalid <= rvalid; p_rready <= rready; p_rresp <= rresp; p_rdata <= rdata;
    end
  end
endmodule
