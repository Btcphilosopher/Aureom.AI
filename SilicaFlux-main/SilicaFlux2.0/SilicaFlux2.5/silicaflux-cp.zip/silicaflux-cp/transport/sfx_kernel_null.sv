// Null compute fabric: accepts a kernel dispatch and completes it after `grid_x*grid_y*grid_z`
// cycles (clamped to MAX_CYCLES) with KD_OK. Honours kd_abort. For FPGA bring-up and for the
// transport-wrapper testbench only; real fabrics implement the contract in SPEC 14.2.
module sfx_kernel_null #(
  parameter int TAGW       = 2,
  parameter int MAX_CYCLES = 1024
) (
  input  logic                clk,
  input  logic                rst_n,
  input  logic                kd_valid,
  output logic                kd_ready,
  input  logic [TAGW-1:0]     kd_tag,
  input  logic [31:0]         kd_grid_x,
  input  logic [31:0]         kd_grid_y,
  input  logic [31:0]         kd_grid_z,
  input  logic                kd_abort,
  output logic                kd_done_valid,
  output logic [TAGW-1:0]     kd_done_tag,
  output logic [1:0]          kd_done_status,
  output logic [63:0]         kd_done_info,
  output logic                kd_heartbeat
);
  logic          busy;
  logic [TAGW-1:0] tag_q;
  logic [31:0]   left;
  logic [63:0]   work;

  assign kd_ready     = !busy;
  assign kd_heartbeat = busy;                 // proves liveness every cycle while running
  assign kd_done_info = work;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= 1'b0; tag_q <= '0; left <= '0; work <= '0;
      kd_done_valid <= 1'b0; kd_done_tag <= '0; kd_done_status <= '0;
    end else begin
      kd_done_valid <= 1'b0;
      if (!busy) begin
        if (kd_valid) begin
          logic [63:0] total;
          total = 64'(kd_grid_x) * 64'(kd_grid_y) * 64'(kd_grid_z);
          busy <= 1'b1; tag_q <= kd_tag;
          left <= (total > 64'(MAX_CYCLES)) ? 32'(MAX_CYCLES) : total[31:0];
          work <= total;
        end
      end else if (kd_abort) begin
        busy <= 1'b0; kd_done_valid <= 1'b1; kd_done_tag <= tag_q; kd_done_status <= 2'd2;
      end else if (left <= 32'd1) begin
        busy <= 1'b0; kd_done_valid <= 1'b1; kd_done_tag <= tag_q; kd_done_status <= 2'd0;
      end else begin
        left <= left - 32'd1;
      end
    end
  end
endmodule
