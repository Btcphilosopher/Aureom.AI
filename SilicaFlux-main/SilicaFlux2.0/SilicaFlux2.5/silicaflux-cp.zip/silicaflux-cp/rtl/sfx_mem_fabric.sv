// Memory fabric: the two AXI4 masters of the core and the clients that share them.
//   host bus : reads  <- {fetch, dma}      writes <- {dma, retire}
//   dev  bus : reads  <- {dma}             writes <- {dma}
// Each bus carries at most one read burst and one write burst at a time (SPEC 14.1).
module sfx_mem_fabric #(
  parameter int DATA_W = 64
) (
  input  logic                    clk,
  input  logic                    rst_n,
  output logic                    idle,

  // ---- client F: descriptor fetch (host read)
  input  logic                    f_req_valid,
  input  logic [63:0]             f_req_addr,
  input  logic [7:0]              f_req_beats,
  output logic                    f_req_ack,
  output logic                    f_rsp_valid,
  output logic [DATA_W-1:0]       f_rsp_data,
  output logic                    f_rsp_last,
  output logic                    f_rsp_err,

  // ---- client D read: dma (host or dev)
  input  logic                    dr_req_valid,
  input  logic                    dr_req_dev,
  input  logic [63:0]             dr_req_addr,
  input  logic [7:0]              dr_req_beats,
  output logic                    dr_req_ack,
  output logic                    dr_rsp_valid,
  output logic [DATA_W-1:0]       dr_rsp_data,
  output logic                    dr_rsp_last,
  output logic                    dr_rsp_err,

  // ---- client D write: dma (host or dev)
  input  logic                    dw_req_valid,
  input  logic                    dw_req_dev,      // must be stable from request to b_valid
  input  logic [63:0]             dw_req_addr,
  input  logic [7:0]              dw_req_beats,
  output logic                    dw_req_ack,
  input  logic                    dw_w_valid,
  input  logic [DATA_W-1:0]       dw_w_data,
  input  logic [DATA_W/8-1:0]     dw_w_strb,
  output logic                    dw_w_ready,
  output logic                    dw_b_valid,
  output logic                    dw_b_err,

  // ---- client R write: retire (host write)
  input  logic                    rw_req_valid,
  input  logic [63:0]             rw_req_addr,
  input  logic [7:0]              rw_req_beats,
  output logic                    rw_req_ack,
  input  logic                    rw_w_valid,
  input  logic [DATA_W-1:0]       rw_w_data,
  input  logic [DATA_W/8-1:0]     rw_w_strb,
  output logic                    rw_w_ready,
  output logic                    rw_b_valid,
  output logic                    rw_b_err,

  // ---- AXI4 host master
  output logic [63:0]             h_araddr,
  output logic [7:0]              h_arlen,
  output logic [2:0]              h_arsize,
  output logic [1:0]              h_arburst,
  output logic                    h_arvalid,
  input  logic                    h_arready,
  input  logic [DATA_W-1:0]       h_rdata,
  input  logic [1:0]              h_rresp,
  input  logic                    h_rlast,
  input  logic                    h_rvalid,
  output logic                    h_rready,
  output logic [63:0]             h_awaddr,
  output logic [7:0]              h_awlen,
  output logic [2:0]              h_awsize,
  output logic [1:0]              h_awburst,
  output logic                    h_awvalid,
  input  logic                    h_awready,
  output logic [DATA_W-1:0]       h_wdata,
  output logic [DATA_W/8-1:0]     h_wstrb,
  output logic                    h_wlast,
  output logic                    h_wvalid,
  input  logic                    h_wready,
  input  logic [1:0]              h_bresp,
  input  logic                    h_bvalid,
  output logic                    h_bready,

  // ---- AXI4 device-memory master
  output logic [63:0]             d_araddr,
  output logic [7:0]              d_arlen,
  output logic [2:0]              d_arsize,
  output logic [1:0]              d_arburst,
  output logic                    d_arvalid,
  input  logic                    d_arready,
  input  logic [DATA_W-1:0]       d_rdata,
  input  logic [1:0]              d_rresp,
  input  logic                    d_rlast,
  input  logic                    d_rvalid,
  output logic                    d_rready,
  output logic [63:0]             d_awaddr,
  output logic [7:0]              d_awlen,
  output logic [2:0]              d_awsize,
  output logic [1:0]              d_awburst,
  output logic                    d_awvalid,
  input  logic                    d_awready,
  output logic [DATA_W-1:0]       d_wdata,
  output logic [DATA_W/8-1:0]     d_wstrb,
  output logic                    d_wlast,
  output logic                    d_wvalid,
  input  logic                    d_wready,
  input  logic [1:0]              d_bresp,
  input  logic                    d_bvalid,
  output logic                    d_bready
);
  // ---------------- host read port: req[0]=fetch, req[1]=dma
  logic [1:0]            hr_ack, hr_rsp_valid;
  logic [DATA_W-1:0]     hr_rsp_data;
  logic                  hr_rsp_last, hr_rsp_err, hr_idle;

  sfx_axi_rport #(.NREQ(2), .DATA_W(DATA_W)) u_host_rd (
    .clk, .rst_n,
    .req_valid ({dr_req_valid & ~dr_req_dev, f_req_valid}),
    .req_addr  ({dr_req_addr, f_req_addr}),
    .req_beats ({dr_req_beats, f_req_beats}),
    .req_ack   (hr_ack),
    .rsp_valid (hr_rsp_valid), .rsp_data(hr_rsp_data), .rsp_last(hr_rsp_last), .rsp_err(hr_rsp_err),
    .idle      (hr_idle),
    .araddr(h_araddr), .arlen(h_arlen), .arsize(h_arsize), .arburst(h_arburst),
    .arvalid(h_arvalid), .arready(h_arready),
    .rdata(h_rdata), .rresp(h_rresp), .rlast(h_rlast), .rvalid(h_rvalid), .rready(h_rready)
  );

  // ---------------- dev read port: req[0]=dma
  logic [0:0]            dvr_ack, dvr_rsp_valid;
  logic [DATA_W-1:0]     dvr_rsp_data;
  logic                  dvr_rsp_last, dvr_rsp_err, dvr_idle;

  sfx_axi_rport #(.NREQ(1), .DATA_W(DATA_W)) u_dev_rd (
    .clk, .rst_n,
    .req_valid (dr_req_valid & dr_req_dev),
    .req_addr  (dr_req_addr),
    .req_beats (dr_req_beats),
    .req_ack   (dvr_ack),
    .rsp_valid (dvr_rsp_valid), .rsp_data(dvr_rsp_data), .rsp_last(dvr_rsp_last), .rsp_err(dvr_rsp_err),
    .idle      (dvr_idle),
    .araddr(d_araddr), .arlen(d_arlen), .arsize(d_arsize), .arburst(d_arburst),
    .arvalid(d_arvalid), .arready(d_arready),
    .rdata(d_rdata), .rresp(d_rresp), .rlast(d_rlast), .rvalid(d_rvalid), .rready(d_rready)
  );

  assign f_req_ack    = hr_ack[0];
  assign f_rsp_valid  = hr_rsp_valid[0];
  assign f_rsp_data   = hr_rsp_data;
  assign f_rsp_last   = hr_rsp_last;
  assign f_rsp_err    = hr_rsp_err;

  assign dr_req_ack   = dr_req_dev ? dvr_ack[0] : hr_ack[1];
  assign dr_rsp_valid = hr_rsp_valid[1] | dvr_rsp_valid[0];
  assign dr_rsp_data  = hr_rsp_valid[1] ? hr_rsp_data : dvr_rsp_data;
  assign dr_rsp_last  = hr_rsp_valid[1] ? hr_rsp_last : dvr_rsp_last;
  assign dr_rsp_err   = hr_rsp_valid[1] ? hr_rsp_err  : dvr_rsp_err;

  // ---------------- host write port: req[0]=dma, req[1]=retire
  logic [1:0]            hw_ack, hw_w_ready, hw_b_valid;
  logic                  hw_b_err, hw_idle;

  sfx_axi_wport #(.NREQ(2), .DATA_W(DATA_W)) u_host_wr (
    .clk, .rst_n,
    .req_valid ({rw_req_valid, dw_req_valid & ~dw_req_dev}),
    .req_addr  ({rw_req_addr, dw_req_addr}),
    .req_beats ({rw_req_beats, dw_req_beats}),
    .req_ack   (hw_ack),
    .w_valid   ({rw_w_valid, dw_w_valid & ~dw_req_dev}),
    .w_data    ({rw_w_data, dw_w_data}),
    .w_strb    ({rw_w_strb, dw_w_strb}),
    .w_ready   (hw_w_ready),
    .b_valid   (hw_b_valid), .b_err(hw_b_err),
    .idle      (hw_idle),
    .awaddr(h_awaddr), .awlen(h_awlen), .awsize(h_awsize), .awburst(h_awburst),
    .awvalid(h_awvalid), .awready(h_awready),
    .wdata(h_wdata), .wstrb(h_wstrb), .wlast(h_wlast), .wvalid(h_wvalid), .wready(h_wready),
    .bresp(h_bresp), .bvalid(h_bvalid), .bready(h_bready)
  );

  // ---------------- dev write port: req[0]=dma
  logic [0:0]            dvw_ack, dvw_w_ready, dvw_b_valid;
  logic                  dvw_b_err, dvw_idle;

  sfx_axi_wport #(.NREQ(1), .DATA_W(DATA_W)) u_dev_wr (
    .clk, .rst_n,
    .req_valid (dw_req_valid & dw_req_dev),
    .req_addr  (dw_req_addr),
    .req_beats (dw_req_beats),
    .req_ack   (dvw_ack),
    .w_valid   (dw_w_valid & dw_req_dev),
    .w_data    (dw_w_data),
    .w_strb    (dw_w_strb),
    .w_ready   (dvw_w_ready),
    .b_valid   (dvw_b_valid), .b_err(dvw_b_err),
    .idle      (dvw_idle),
    .awaddr(d_awaddr), .awlen(d_awlen), .awsize(d_awsize), .awburst(d_awburst),
    .awvalid(d_awvalid), .awready(d_awready),
    .wdata(d_wdata), .wstrb(d_wstrb), .wlast(d_wlast), .wvalid(d_wvalid), .wready(d_wready),
    .bresp(d_bresp), .bvalid(d_bvalid), .bready(d_bready)
  );

  assign dw_req_ack = dw_req_dev ? dvw_ack[0] : hw_ack[0];
  assign dw_w_ready = dw_req_dev ? dvw_w_ready[0] : hw_w_ready[0];
  assign dw_b_valid = hw_b_valid[0] | dvw_b_valid[0];
  assign dw_b_err   = hw_b_valid[0] ? hw_b_err : dvw_b_err;

  assign rw_req_ack = hw_ack[1];
  assign rw_w_ready = hw_w_ready[1];
  assign rw_b_valid = hw_b_valid[1];
  assign rw_b_err   = hw_b_err;

  assign idle = hr_idle & dvr_idle & hw_idle & dvw_idle;
endmodule
