// GENERATED FILE -- do not edit.  Source: spec/sfx_spec.py  (run `make gen`)
package sfx_pkg;

  // ---- identity
  localparam logic [31:0] SFX_ID_VALUE = 32'h53465843;  // 'SFXC' read from ID register
  localparam logic [31:0] SFX_ABI_MAJOR = 32'h1;  // register-map ABI major (incompatible changes)
  localparam logic [31:0] SFX_ABI_MINOR = 32'h0;  // register-map ABI minor (backward-compatible additions)
  localparam logic [31:0] SFX_ABI_PATCH = 32'h0;  // errata level, no ABI effect
  localparam logic [31:0] SFX_DESC_VERSION = 32'h1;  // descriptor/CQE layout version
  localparam logic [31:0] SFX_RESET_KEY = 32'h5AFE;  // must be written in RESET_CTRL[31:16]

  // ---- limits
  localparam logic [31:0] SFX_DESC_BYTES = 32'h40;  // submission queue entry size
  localparam logic [31:0] SFX_DESC_LOG2 = 32'h6;
  localparam logic [31:0] SFX_CQE_BYTES = 32'h20;  // completion queue entry size
  localparam logic [31:0] SFX_CQE_LOG2 = 32'h5;
  localparam logic [31:0] SFX_MAX_RING_LOG2 = 32'hC;  // largest supported ring: 4096 entries
  localparam logic [31:0] SFX_MIN_RING_LOG2 = 32'h1;  // smallest supported ring: 2 entries
  localparam logic [31:0] SFX_MAX_COPY_BYTES = 32'h40000000;  // largest single COPY length (1 GiB)
  localparam logic [31:0] SFX_MAX_ARGS_BYTES = 32'h1000;  // largest kernel argument block
  localparam logic [31:0] SFX_MAX_GRID_DIM = 32'hFFFF;  // largest value of any grid dimension
  localparam logic [31:0] SFX_MAX_QUEUES = 32'h4;  // architectural maximum; instance reports actual
  localparam logic [31:0] SFX_MAX_WINDOWS = 32'h10;  // architectural maximum; instance reports actual
  localparam logic [31:0] SFX_MAX_DOMAINS = 32'h10;  // domain id is 4 bits
  localparam logic [31:0] SFX_TIMER_UNIT = 32'h40;  // Q_IRQ_COAL timer unit, in core clocks (model: ticks)

  // ---- opcode
  localparam logic [15:0] SFX_OP_NOP = 16'h0;  // no operation; completes in order
  localparam logic [15:0] SFX_OP_COPY_H2D = 16'h1;  // host IOVA -> device memory
  localparam logic [15:0] SFX_OP_COPY_D2H = 16'h2;  // device memory -> host IOVA
  localparam logic [15:0] SFX_OP_COPY_D2D = 16'h3;  // device memory -> device memory
  localparam logic [15:0] SFX_OP_KERNEL = 16'h10;  // kernel dispatch
  localparam logic [15:0] SFX_OP_FENCE = 16'h20;  // execution barrier, optional host signal write

  // ---- flag
  localparam logic [15:0] SFX_F_FENCE_BEFORE = 16'h1;  // all opcodes: do not issue until every earlier command has retired
  localparam logic [15:0] SFX_F_IRQ = 16'h2;  // all opcodes: raise queue completion interrupt when CQE is visible
  localparam logic [15:0] SFX_F_FENCE_SCOPE_ALL = 16'h4;  // FENCE only: advisory in ABI 1.0 (scope is always all queues)
  localparam logic [15:0] SFX_F_FENCE_SIGNAL = 16'h8;  // FENCE only: write 64-bit value to host address after prior work
  localparam logic [15:0] SFX_F_VALID_MASK = 16'hF;  // all defined flag bits

  // ---- status
  localparam logic [15:0] SFX_ST_OK = 16'h0;  // completion point reached
  localparam logic [15:0] SFX_ST_BAD_VERSION = 16'h1;  // desc_ver not supported
  localparam logic [15:0] SFX_ST_BAD_OPCODE = 16'h2;  // unknown opcode
  localparam logic [15:0] SFX_ST_BAD_FLAGS = 16'h3;  // undefined flag bit, or flag not valid for opcode
  localparam logic [15:0] SFX_ST_BAD_DESC = 16'h4;  // must-be-zero field set, or invalid field value (grid)
  localparam logic [15:0] SFX_ST_BAD_LENGTH = 16'h5;  // zero / too large / not a multiple of DMA_ALIGN
  localparam logic [15:0] SFX_ST_BAD_ALIGN = 16'h6;  // address not a multiple of DMA_ALIGN
  localparam logic [15:0] SFX_ST_BAD_RANGE = 16'h7;  // outside supported address space or wraps
  localparam logic [15:0] SFX_ST_UNAUTHORIZED = 16'h8;  // not inside one driver-authorised window (space/domain/permission)
  localparam logic [15:0] SFX_ST_DMA_READ_ERR = 16'h9;  // bus error response on a read
  localparam logic [15:0] SFX_ST_DMA_WRITE_ERR = 16'hA;  // bus error response on a write
  localparam logic [15:0] SFX_ST_KERNEL_FAULT = 16'hB;  // compute fabric reported a fault; result = fabric info
  localparam logic [15:0] SFX_ST_ABORTED = 16'hC;  // aborted by controlled reset before its completion point
  localparam logic [15:0] SFX_ST_TIMEOUT = 16'hD;  // aborted by watchdog fault before its completion point

  // ---- qerr
  localparam logic [7:0] SFX_QERR_NONE = 8'h0;
  localparam logic [7:0] SFX_QERR_BAD_SEQ = 8'h1;  // descriptor seq field != expected sequence number
  localparam logic [7:0] SFX_QERR_SQ_FETCH = 8'h2;  // bus error fetching a descriptor
  localparam logic [7:0] SFX_QERR_RING_UNAUTH = 8'h3;  // SQ or CQ ring access not inside an authorised window
  localparam logic [7:0] SFX_QERR_CQ_WRITE = 8'h4;  // bus error publishing a completion
  localparam logic [7:0] SFX_QERR_BAD_CONFIG = 8'h5;  // enable-time validation failed

  // ---- qstate
  localparam logic [1:0] SFX_QS_DISABLED = 2'h0;
  localparam logic [1:0] SFX_QS_ENABLED = 2'h1;
  localparam logic [1:0] SFX_QS_DRAINING = 2'h2;
  localparam logic [1:0] SFX_QS_ERROR = 2'h3;

  // ---- kdstatus
  localparam logic [1:0] SFX_KD_OK = 2'h0;  // kernel finished; its writes are performed
  localparam logic [1:0] SFX_KD_FAULT = 2'h1;  // kernel faulted; info is fabric specific
  localparam logic [1:0] SFX_KD_ABORTED = 2'h2;  // kernel stopped by kd_abort

  // ---- space
  localparam logic SFX_SPACE_HOST = 1'b0;  // host DMA (IOVA) address space
  localparam logic SFX_SPACE_DEV = 1'b1;  // device-local memory address space

  // ---- layout
  localparam logic [31:0] SFX_D_OPCODE = 32'h0;  // u16
  localparam logic [31:0] SFX_D_FLAGS = 32'h2;  // u16
  localparam logic [31:0] SFX_D_SEQ = 32'h4;  // u32 == absolute SQ index of this slot
  localparam logic [31:0] SFX_D_CMD_ID = 32'h8;  // u32 opaque host tag, echoed in CQE
  localparam logic [31:0] SFX_D_DESC_VER = 32'hC;  // u16 must equal DESC_VERSION
  localparam logic [31:0] SFX_D_RSVD0 = 32'hE;  // u16 must be zero
  localparam logic [31:0] SFX_D_ADDR0 = 32'h10;  // u64 COPY src | KERNEL entry | FENCE signal addr
  localparam logic [31:0] SFX_D_ADDR1 = 32'h18;  // u64 COPY dst | KERNEL args addr
  localparam logic [31:0] SFX_D_LENGTH = 32'h20;  // u32 COPY bytes | KERNEL args bytes
  localparam logic [31:0] SFX_D_AUX0 = 32'h24;  // u32 KERNEL grid_x
  localparam logic [31:0] SFX_D_AUX1 = 32'h28;  // u32 KERNEL grid_y
  localparam logic [31:0] SFX_D_AUX2 = 32'h2C;  // u32 KERNEL grid_z
  localparam logic [31:0] SFX_D_VALUE = 32'h30;  // u64 FENCE signal value
  localparam logic [31:0] SFX_D_RSVD1 = 32'h38;  // u64 must be zero
  localparam logic [31:0] SFX_C_CMD_ID = 32'h0;  // u32
  localparam logic [31:0] SFX_C_SQ_SEQ = 32'h4;  // u32 absolute SQ index of the command
  localparam logic [31:0] SFX_C_STATUS = 32'h8;  // u16
  localparam logic [31:0] SFX_C_OPCODE = 32'hA;  // u16 echo of descriptor opcode
  localparam logic [31:0] SFX_C_SQ_HEAD = 32'hC;  // u32 SQ slots with absolute index < sq_head are reusable
  localparam logic [31:0] SFX_C_RESULT = 32'h10;  // u64
  localparam logic [31:0] SFX_C_CQ_SEQ = 32'h18;  // u32 absolute CQ index of this entry
  localparam logic [31:0] SFX_C_PHASE = 32'h1C;  // u32, bit0 = phase; written LAST, as its own write

  // ---- winctl
  localparam logic [31:0] SFX_WIN_VALID = 32'h1;  // write 1: commit window; write 0: invalidate
  localparam logic [31:0] SFX_WIN_SPACE = 32'h2;  // 0 host IOVA, 1 device
  localparam logic [31:0] SFX_WIN_R = 32'h4;  // device may read
  localparam logic [31:0] SFX_WIN_W = 32'h8;  // device may write
  localparam logic [31:0] SFX_WIN_DOM_LSB = 32'h8;  // domain id [11:8]
  localparam logic [31:0] SFX_WIN_DOM_MASK = 32'hF00;
  localparam logic [31:0] SFX_WIN_BUSY = 32'h10000;  // read: window referenced by an in-flight device access
  localparam logic [31:0] SFX_WIN_ERR = 32'h20000;  // read: last commit rejected; cleared by an invalidate write or a successful commit

  // ---- qctl
  localparam logic [31:0] SFX_QCTL_ENABLE = 32'h1;
  localparam logic [31:0] SFX_QCTL_DOM_LSB = 32'h8;  // domain id [11:8]
  localparam logic [31:0] SFX_QCTL_DOM_MASK = 32'hF00;
  localparam logic [31:0] SFX_QSTAT_STATE_MASK = 32'h3;  // Q_STATUS[1:0]
  localparam logic [31:0] SFX_QSTAT_ERR_LSB = 32'h8;  // Q_STATUS[15:8] = QERR_*
  localparam logic [31:0] SFX_QSIZE_SQ_MASK = 32'h1F;  // Q_SIZE[4:0]
  localparam logic [31:0] SFX_QSIZE_CQ_LSB = 32'h8;  // Q_SIZE[12:8]
  localparam logic [31:0] SFX_QSIZE_CQ_MASK = 32'h1F00;

  // ---- ctrl
  localparam logic [31:0] SFX_CTRL_ENABLE = 32'h1;  // global run enable
  localparam logic [31:0] SFX_STATUS_READY = 32'h1;  // out of reset and not RESETTING: registers usable
  localparam logic [31:0] SFX_STATUS_RUNNING = 32'h2;  // CTRL.ENABLE && !FAULT && !RESETTING
  localparam logic [31:0] SFX_STATUS_FAULT = 32'h4;  // watchdog fault; cleared only by controlled reset
  localparam logic [31:0] SFX_STATUS_RESETTING = 32'h8;
  localparam logic [31:0] SFX_STATUS_IDLE = 32'h10;  // no pending, fetched, in-flight or publishing work
  localparam logic [31:0] SFX_STATUS_ABI_OK = 32'h20;  // ABI_REQ accepted
  localparam logic [31:0] SFX_FAULT_WDT = 32'h1;  // FAULT_CAUSE bit

  // ---- errbits
  localparam logic [31:0] SFX_ERR_BAD_DOORBELL = 32'h1;  // invalid doorbell value, or queue not ENABLED
  localparam logic [31:0] SFX_ERR_BAD_REG_ACCESS = 32'h2;  // partial/unaligned write, write to RO/unmapped, bad key
  localparam logic [31:0] SFX_ERR_BAD_WINDOW = 32'h4;  // window commit rejected
  localparam logic [31:0] SFX_ERR_BAD_QCONFIG = 32'h8;  // queue enable rejected
  localparam logic [31:0] SFX_ERR_BAD_IRQ_CONFIG = 32'h10;  // vector out of range
  localparam logic [31:0] SFX_ERR_CFG_LOCKED = 32'h20;  // config write to a locked (enabled/valid) object

  // ---- irqbits
  localparam logic [31:0] SFX_IRQ_QCPL_LSB = 32'h0;  // bit q: queue q completion
  localparam logic [31:0] SFX_IRQ_QERR_LSB = 32'h4;  // bit 4+q: queue q entered ERROR
  localparam logic [31:0] SFX_IRQ_DEV_ERR = 32'h100;  // a new ERR_STATUS bit was set
  localparam logic [31:0] SFX_IRQ_WDT = 32'h200;  // watchdog expired
  localparam logic [31:0] SFX_IRQ_RESET_DONE = 32'h400;  // controlled reset finished
  localparam logic [31:0] SFX_IRQ_VALID_MASK = 32'h7FF;

  // ---- wdtbits
  localparam logic [31:0] SFX_WDT_CTRL_ENABLE = 32'h1;
  localparam logic [31:0] SFX_WDT_ST_ENABLED = 32'h1;
  localparam logic [31:0] SFX_WDT_ST_ARMED = 32'h2;  // work outstanding and counting
  localparam logic [31:0] SFX_WDT_ST_EXPIRED = 32'h4;  // W1C
  localparam logic [31:0] SFX_WDT_STUCK_LSB = 32'h8;  // [11:8] unit mask at expiry
  localparam logic [31:0] SFX_WDT_STUCK_FRONTEND = 32'h100;
  localparam logic [31:0] SFX_WDT_STUCK_DMA = 32'h200;
  localparam logic [31:0] SFX_WDT_STUCK_KERNEL = 32'h400;
  localparam logic [31:0] SFX_WDT_STUCK_RETIRE = 32'h800;
  localparam logic [31:0] SFX_WDT_COUNT_LSB = 32'h10;  // [31:16] expiry count

  // ---- rstbits
  localparam logic [31:0] SFX_RST_REQ = 32'h1;  // RESET_CTRL[0]
  localparam logic [31:0] SFX_RST_KEY_LSB = 32'h10;  // RESET_CTRL[31:16]
  localparam logic [31:0] SFX_RST_ST_BUSY = 32'h1;
  localparam logic [31:0] SFX_RST_ST_DONE = 32'h2;  // cleared when next reset is requested
  localparam logic [31:0] SFX_RST_ST_DRAIN_TIMEOUT = 32'h4;  // outstanding bus transactions never drained
  localparam logic [31:0] SFX_RST_COUNT_LSB = 32'h10;  // [31:16] controlled resets since hard reset

  // ---- caps
  localparam logic [31:0] SFX_CAP_KERNEL = 32'h1;
  localparam logic [31:0] SFX_CAP_COPY_H2D = 32'h2;
  localparam logic [31:0] SFX_CAP_COPY_D2H = 32'h4;
  localparam logic [31:0] SFX_CAP_COPY_D2D = 32'h8;
  localparam logic [31:0] SFX_CAP_FENCE = 32'h10;
  localparam logic [31:0] SFX_CAP_FENCE_SIGNAL = 32'h20;
  localparam logic [31:0] SFX_CAP_IRQ_COALESCE = 32'h40;
  localparam logic [31:0] SFX_CAP_WATCHDOG = 32'h80;
  localparam logic [31:0] SFX_CAP_SOFT_RESET = 32'h100;
  localparam logic [31:0] SFX_CAP_WINDOW_AUTHZ = 32'h200;  // device enforces driver-programmed windows
  localparam logic [31:0] SFX_CAP_SEQ_START = 32'h400;  // Q_SEQ_START supported

  // ---- register offsets (control page, byte offsets)
  localparam logic [15:0] SFX_R_ID = 16'h0000;
  localparam logic [15:0] SFX_R_VERSION = 16'h0004;
  localparam logic [15:0] SFX_R_CAPS = 16'h0008;
  localparam logic [15:0] SFX_R_GEOMETRY = 16'h000C;
  localparam logic [15:0] SFX_R_LIMITS = 16'h0010;
  localparam logic [15:0] SFX_R_MAX_COPY = 16'h0014;
  localparam logic [15:0] SFX_R_DEVMEM_LO = 16'h0018;
  localparam logic [15:0] SFX_R_DEVMEM_HI = 16'h001C;
  localparam logic [15:0] SFX_R_HOST_ADDR_BITS = 16'h0020;
  localparam logic [15:0] SFX_R_DESC_VERSIONS = 16'h0024;
  localparam logic [15:0] SFX_R_LIMITS2 = 16'h0028;
  localparam logic [15:0] SFX_R_ABI_REQ = 16'h0030;
  localparam logic [15:0] SFX_R_SCRATCH = 16'h0034;
  localparam logic [15:0] SFX_R_CTRL = 16'h0040;
  localparam logic [15:0] SFX_R_STATUS = 16'h0044;
  localparam logic [15:0] SFX_R_FAULT_CAUSE = 16'h0048;
  localparam logic [15:0] SFX_R_ERR_STATUS = 16'h004C;
  localparam logic [15:0] SFX_R_ERR_COUNT = 16'h0050;
  localparam logic [15:0] SFX_R_DUP_DB_COUNT = 16'h0054;
  localparam logic [15:0] SFX_R_FAULT_ADDR_LO = 16'h0058;
  localparam logic [15:0] SFX_R_FAULT_ADDR_HI = 16'h005C;
  localparam logic [15:0] SFX_R_FAULT_INFO = 16'h0060;
  localparam logic [15:0] SFX_R_CMDS_OK = 16'h0064;
  localparam logic [15:0] SFX_R_CMDS_ERR = 16'h0068;
  localparam logic [15:0] SFX_R_IRQ_STATUS = 16'h0070;
  localparam logic [15:0] SFX_R_IRQ_ENABLE = 16'h0074;
  localparam logic [15:0] SFX_R_IRQ_MISC_VECTOR = 16'h0078;
  localparam logic [15:0] SFX_R_IRQ_FORCE = 16'h007C;
  localparam logic [15:0] SFX_R_WDT_CTRL = 16'h0080;
  localparam logic [15:0] SFX_R_WDT_TIMEOUT = 16'h0084;
  localparam logic [15:0] SFX_R_WDT_STATUS = 16'h0088;
  localparam logic [15:0] SFX_R_WDT_COUNT = 16'h008C;
  localparam logic [15:0] SFX_R_RESET_CTRL = 16'h0090;
  localparam logic [15:0] SFX_R_RESET_STATUS = 16'h0094;
  localparam logic [15:0] SFX_R_RESET_TIMEOUT = 16'h0098;
  localparam logic [15:0] SFX_WIN_BASE   = 16'h0100;
  localparam logic [15:0] SFX_WIN_STRIDE = 16'h0020;
  localparam logic [15:0] SFX_R_W_BASE_LO = 16'h0000;
  localparam logic [15:0] SFX_R_W_BASE_HI = 16'h0004;
  localparam logic [15:0] SFX_R_W_SIZE_LO = 16'h0008;
  localparam logic [15:0] SFX_R_W_SIZE_HI = 16'h000C;
  localparam logic [15:0] SFX_R_W_CTRL = 16'h0010;
  localparam logic [15:0] SFX_Q_BASE     = 16'h0400;
  localparam logic [15:0] SFX_Q_STRIDE   = 16'h0080;
  localparam logic [15:0] SFX_R_Q_CTRL = 16'h0000;
  localparam logic [15:0] SFX_R_Q_STATUS = 16'h0004;
  localparam logic [15:0] SFX_R_Q_SQ_BASE_LO = 16'h0008;
  localparam logic [15:0] SFX_R_Q_SQ_BASE_HI = 16'h000C;
  localparam logic [15:0] SFX_R_Q_CQ_BASE_LO = 16'h0010;
  localparam logic [15:0] SFX_R_Q_CQ_BASE_HI = 16'h0014;
  localparam logic [15:0] SFX_R_Q_SIZE = 16'h0018;
  localparam logic [15:0] SFX_R_Q_VECTOR = 16'h001C;
  localparam logic [15:0] SFX_R_Q_SEQ_START = 16'h0020;
  localparam logic [15:0] SFX_R_Q_IRQ_COAL = 16'h0024;
  localparam logic [15:0] SFX_R_Q_SQ_HEAD = 16'h0028;
  localparam logic [15:0] SFX_R_Q_SQ_TAIL = 16'h002C;
  localparam logic [15:0] SFX_R_Q_CQ_HEAD = 16'h0030;
  localparam logic [15:0] SFX_R_Q_CQ_TAIL = 16'h0034;
  localparam logic [15:0] SFX_R_Q_CMDS_OK = 16'h0038;
  localparam logic [15:0] SFX_R_Q_CMDS_ERR = 16'h003C;
  localparam logic [15:0] SFX_R_Q_RST_SQ_TAIL = 16'h0040;
  localparam logic [15:0] SFX_R_Q_RST_SQ_HEAD = 16'h0044;
  localparam logic [15:0] SFX_R_Q_RST_CQ_TAIL = 16'h0048;
  localparam logic [15:0] SFX_DB_BASE    = 16'h1000;
  localparam logic [15:0] SFX_DB_STRIDE  = 16'h1000;
  localparam logic [15:0] SFX_R_DB_SQ_TAIL = 16'h0000;
  localparam logic [15:0] SFX_R_DB_CQ_HEAD = 16'h0004;


  // ---- shared types ------------------------------------------------------
  // In-flight command table entry (sfx_inflight / sfx_frontend / sfx_retire)
  typedef struct packed {
    logic [1:0]  q;          // queue index
    logic [31:0] seq;        // absolute SQ index
    logic [31:0] cmd_id;
    logic [15:0] opcode;
    logic [15:0] flags;
    logic [15:0] status;
    logic [63:0] result;
    logic        sig_en;     // FENCE with SIGNAL and valid descriptor
    logic [63:0] sig_addr;
    logic [63:0] sig_val;
    logic [3:0]  domain;
    logic        is_kernel;  // issued to compute fabric
  } inf_t;

  // 256-bit completion queue entry, little-endian byte order (byte 0 = bits [7:0])
  function automatic logic [255:0] cqe_pack(
      input logic [31:0] cmd_id, input logic [31:0] sq_seq, input logic [15:0] status,
      input logic [15:0] opcode, input logic [31:0] sq_head, input logic [63:0] result,
      input logic [31:0] cq_seq, input logic phase);
    cqe_pack = {{31'b0, phase}, cq_seq, result, sq_head, opcode, status, sq_seq, cmd_id};
  endfunction

endpackage
