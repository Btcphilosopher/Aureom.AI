// DMA copy engine (SPEC 8.2). One COPY at a time.
//
//  read side  --(authz per burst)--> bus read burst --> FIFO (speculative -> committed on burst OK)
//  write side <-(store-and-forward)-- FIFO --(authz per burst)--> bus write burst --> B response
//
//  * Bursts never cross 4 KiB and are at most MAXB beats; source and destination partition
//    independently (both are DATA_W/8-aligned by validation, so no lane realignment is needed).
//  * A read burst is atomic: any error beat discards the whole burst (FIFO rollback).
//  * Read-side failure: the write side still drains everything committed before the failing burst.
//  * Write-side failure or halt_req: both sides stop at the next burst boundary.
//  * Completion = all write responses received.  done_bytes = bytes whose write response was OKAY.
module sfx_dma #(
  parameter int DATA_W = 64,
  parameter int MAXB   = 16,      // power of two, <= 128
  parameter int NW     = 8
) (
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    halt_req,           // level: stop at next burst boundary

  // command
  input  logic                    cmd_valid,
  output logic                    cmd_ready,
  input  logic                    cmd_src_dev,
  input  logic                    cmd_dst_dev,
  input  logic [63:0]             cmd_src,
  input  logic [63:0]             cmd_dst,
  input  logic [31:0]             cmd_len,
  input  logic [3:0]              cmd_dom,

  // completion (single-cycle pulse)
  output logic                    done_valid,
  output logic [15:0]             done_status,
  output logic [31:0]             done_bytes,
  output logic [63:0]             done_fault_addr,
  output logic                    done_fault_valid,
  output logic                    busy,
  output logic [NW-1:0]           win_use,
  output logic                    progress,

  // authorisation windows
  input  logic [NW-1:0]           win_valid,
  input  logic [NW-1:0][63:0]     win_base,
  input  logic [NW-1:0][63:0]     win_size,
  input  logic [NW-1:0]           win_space,
  input  logic [NW-1:0]           win_r,
  input  logic [NW-1:0]           win_w,
  input  logic [NW-1:0][3:0]      win_dom,

  // fabric: read
  output logic                    dr_req_valid,
  output logic                    dr_req_dev,
  output logic [63:0]             dr_req_addr,
  output logic [7:0]              dr_req_beats,
  input  logic                    dr_req_ack,
  input  logic                    dr_rsp_valid,
  input  logic [DATA_W-1:0]       dr_rsp_data,
  input  logic                    dr_rsp_last,
  input  logic                    dr_rsp_err,
  // fabric: write
  output logic                    dw_req_valid,
  output logic                    dw_req_dev,
  output logic [63:0]             dw_req_addr,
  output logic [7:0]              dw_req_beats,
  input  logic                    dw_req_ack,
  output logic                    dw_w_valid,
  output logic [DATA_W-1:0]       dw_w_data,
  output logic [DATA_W/8-1:0]     dw_w_strb,
  input  logic                    dw_w_ready,
  input  logic                    dw_b_valid,
  input  logic                    dw_b_err
);
  import sfx_pkg::*;

  localparam int BEAT  = DATA_W / 8;
  localparam int BLOG2 = $clog2(BEAT);
  localparam int FD    = 2 * MAXB;
  localparam int PW    = $clog2(FD) + 1;     // pointer width (one extra wrap bit)
  localparam int IW    = $clog2(FD);

  // ---------------- command state
  logic        active;
  logic [63:0] src_addr, dst_addr;
  logic [31:0] rd_rem, wr_rem, written;
  logic [3:0]  dom;
  logic        src_dev, dst_dev;

  // first-error record
  logic        err_set, w_kill;
  logic [15:0] err_status;
  logic [63:0] err_addr;

  // ---------------- FIFO
  logic [DATA_W-1:0] mem [FD];
  logic [PW-1:0]     rp, tp_spec, tp_com;
  logic [PW-1:0]     avail, used_spec;
  assign avail     = tp_com - rp;
  assign used_spec = tp_spec - rp;

  // ---------------- read side
  typedef enum logic [2:0] {R_IDLE, R_PLAN, R_REQ, R_DATA, R_DONE} rst_t;
  rst_t        rstate;
  logic [7:0]  rd_beats;
  logic        rd_err_acc;
  logic [NW-1:0] rd_use;
  logic        rd_use_v;

  // ---------------- write side
  typedef enum logic [2:0] {W_IDLE, W_PLAN, W_REQ, W_DATA, W_RESP, W_DONE} wst_t;
  wst_t        wstate;
  logic [7:0]  wr_beats, wcnt;
  logic [NW-1:0] wr_use;
  logic        wr_use_v;

  function automatic logic [8:0] plan_beats(input logic [63:0] addr, input logic [31:0] rem);
    logic [31:0] b4k, brem, m;
    b4k  = (32'd4096 - {20'b0, addr[11:0]}) >> BLOG2;
    brem = rem >> BLOG2;
    m    = (b4k < brem) ? b4k : brem;
    m    = (m < 32'(MAXB)) ? m : 32'(MAXB);
    return m[8:0];
  endfunction

  // ---------------- read planning + authorisation (combinational)
  logic [8:0]  rb_plan;
  logic [31:0] rb_bytes;
  logic        r_space_ok, r_authz_ok;
  logic [NW-1:0] r_hit;
  assign rb_plan    = plan_beats(src_addr, rd_rem);
  assign rb_bytes   = {23'b0, rb_plan} << BLOG2;
  assign r_space_ok = (32'(FD) - 32'(used_spec)) >= {23'b0, rb_plan};

  sfx_authz #(.NW(NW)) u_authz_r (
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom,
    .q_space(src_dev), .q_dom(dom), .q_addr(src_addr), .q_len(rb_bytes), .q_wr(1'b0),
    .ok(r_authz_ok), .hit(r_hit)
  );

  // ---------------- write planning + authorisation (combinational)
  logic [8:0]  wb_want, wb_sel;
  logic [31:0] wb_bytes;
  logic        w_can_go, w_partial_end, w_authz_ok, rd_fin;
  logic [NW-1:0] w_hit;
  assign rd_fin    = (rstate == R_DONE);
  assign wb_want   = plan_beats(dst_addr, wr_rem);
  assign w_can_go  = (32'(avail) >= {23'b0, wb_want});
  assign wb_sel    = w_can_go ? wb_want : 9'(avail);
  assign wb_bytes  = {23'b0, wb_sel} << BLOG2;
  assign w_partial_end = !w_can_go && rd_fin && (avail == '0);   // nothing more will ever arrive

  sfx_authz #(.NW(NW)) u_authz_w (
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom,
    .q_space(dst_dev), .q_dom(dom), .q_addr(dst_addr), .q_len(wb_bytes), .q_wr(1'b1),
    .ok(w_authz_ok), .hit(w_hit)
  );

  // ---------------- error events (combinational, merged below)
  logic        ev_r_valid, ev_w_valid;
  logic [15:0] ev_r_status, ev_w_status;
  logic [63:0] ev_r_addr, ev_w_addr;
  logic        r_halt;
  assign r_halt = err_set | halt_req;

  always_comb begin
    ev_r_valid = 1'b0; ev_r_status = '0; ev_r_addr = '0;
    if (rstate == R_PLAN) begin
      if (halt_req && !err_set) begin
        ev_r_valid = 1'b1; ev_r_status = SFX_ST_ABORTED; ev_r_addr = src_addr;
      end else if (!r_halt && r_space_ok && !r_authz_ok) begin
        ev_r_valid = 1'b1; ev_r_status = SFX_ST_UNAUTHORIZED; ev_r_addr = src_addr;
      end
    end else if (rstate == R_DATA && dr_rsp_valid && dr_rsp_last && (rd_err_acc | dr_rsp_err)) begin
      ev_r_valid = 1'b1; ev_r_status = SFX_ST_DMA_READ_ERR; ev_r_addr = src_addr;
    end
    ev_w_valid = 1'b0; ev_w_status = '0; ev_w_addr = '0;
    if (wstate == W_PLAN) begin
      if (halt_req || w_kill) begin
        // halt_req with write work still outstanding: the command did not reach its completion point
        if (halt_req && !err_set) begin
          ev_w_valid = 1'b1; ev_w_status = SFX_ST_ABORTED; ev_w_addr = dst_addr;
        end
      end else if ((w_can_go || (rd_fin && avail != '0)) && !w_authz_ok) begin
        ev_w_valid = 1'b1; ev_w_status = SFX_ST_UNAUTHORIZED; ev_w_addr = dst_addr;
      end
    end else if (wstate == W_RESP && dw_b_valid && dw_b_err) begin
      ev_w_valid = 1'b1; ev_w_status = SFX_ST_DMA_WRITE_ERR; ev_w_addr = dst_addr;
    end
  end

  // ---------------- outputs
  assign cmd_ready    = !active && !halt_req;
  assign busy         = active;
  assign win_use      = (rd_use_v ? rd_use : '0) | (wr_use_v ? wr_use : '0);

  assign dr_req_valid = (rstate == R_REQ);
  assign dr_req_dev   = src_dev;
  assign dr_req_addr  = src_addr;
  assign dr_req_beats = rd_beats;

  assign dw_req_valid = (wstate == W_REQ);
  assign dw_req_dev   = dst_dev;
  assign dw_req_addr  = dst_addr;
  assign dw_req_beats = wr_beats;
  assign dw_w_valid   = (wstate == W_DATA);
  assign dw_w_data    = mem[rp[IW-1:0]];
  assign dw_w_strb    = '1;

  // bytes of the burst currently in flight (derived from the latched beat counts)
  logic [31:0] rb_bytes_q, wr_bytes_q;
  assign rb_bytes_q = {24'b0, rd_beats} << BLOG2;
  assign wr_bytes_q = {24'b0, wr_beats} << BLOG2;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      active <= 1'b0; src_addr <= '0; dst_addr <= '0; rd_rem <= '0; wr_rem <= '0; written <= '0;
      dom <= '0; src_dev <= 1'b0; dst_dev <= 1'b0;
      err_set <= 1'b0; w_kill <= 1'b0; err_status <= '0; err_addr <= '0;
      rp <= '0; tp_spec <= '0; tp_com <= '0;
      rstate <= R_IDLE; rd_beats <= '0; rd_err_acc <= 1'b0; rd_use <= '0; rd_use_v <= 1'b0;
      wstate <= W_IDLE; wr_beats <= '0; wcnt <= '0; wr_use <= '0; wr_use_v <= 1'b0;
      done_valid <= 1'b0; done_status <= '0; done_bytes <= '0; done_fault_addr <= '0;
      done_fault_valid <= 1'b0; progress <= 1'b0;
    end else begin
      done_valid <= 1'b0;
      progress   <= 1'b0;

      // ---- first-error merge (read event wins a same-cycle tie)
      if (!err_set) begin
        if (ev_r_valid) begin
          err_set <= 1'b1; err_status <= ev_r_status; err_addr <= ev_r_addr;
        end else if (ev_w_valid) begin
          err_set <= 1'b1; err_status <= ev_w_status; err_addr <= ev_w_addr;
        end
      end
      if (ev_w_valid) w_kill <= 1'b1;

      // ---- command accept
      if (cmd_valid && cmd_ready) begin
        active   <= 1'b1;
        src_addr <= cmd_src;  dst_addr <= cmd_dst;
        rd_rem   <= cmd_len;  wr_rem   <= cmd_len;  written <= '0;
        dom      <= cmd_dom;  src_dev  <= cmd_src_dev; dst_dev <= cmd_dst_dev;
        err_set  <= 1'b0;  w_kill <= 1'b0;  err_status <= '0;  err_addr <= '0;
        rp <= '0; tp_spec <= '0; tp_com <= '0;
        rstate <= R_PLAN;  wstate <= W_PLAN;
        rd_err_acc <= 1'b0;
      end

      // ---- read side
      unique case (rstate)
        R_PLAN: begin
          if (halt_req || err_set) begin
            rstate <= R_DONE;
          end else if (r_space_ok) begin
            if (r_authz_ok) begin
              rd_use <= r_hit; rd_use_v <= 1'b1;
              rd_beats <= rb_plan[7:0];
              rd_err_acc <= 1'b0;
              rstate <= R_REQ;
            end else begin
              rstate <= R_DONE;      // ev_r_* recorded UNAUTHORIZED
            end
          end
        end
        R_REQ: if (dr_req_ack) rstate <= R_DATA;
        R_DATA: if (dr_rsp_valid) begin
          mem[tp_spec[IW-1:0]] <= dr_rsp_data;
          tp_spec    <= tp_spec + 1'b1;
          rd_err_acc <= rd_err_acc | dr_rsp_err;
          if (dr_rsp_last) begin
            rd_use_v <= 1'b0;
            progress <= 1'b1;
            if (rd_err_acc | dr_rsp_err) begin
              tp_spec <= tp_com;                 // roll back the whole burst
              rstate  <= R_DONE;
            end else begin
              tp_com   <= tp_spec + 1'b1;
              src_addr <= src_addr + 64'(rb_bytes_q);
              rd_rem   <= rd_rem - rb_bytes_q;
              rstate   <= (rd_rem == rb_bytes_q) ? R_DONE : R_PLAN;
            end
          end
        end
        default: ;
      endcase

      // ---- write side
      unique case (wstate)
        W_PLAN: begin
          if (halt_req || w_kill) begin
            wstate <= W_DONE;
          end else if (w_can_go || (rd_fin && avail != '0)) begin
            if (w_authz_ok) begin
              wr_use <= w_hit; wr_use_v <= 1'b1;
              wr_beats <= wb_sel[7:0];
              wcnt <= '0;
              wstate <= W_REQ;
            end else begin
              wstate <= W_DONE;     // ev_w_* recorded UNAUTHORIZED
            end
          end else if (w_partial_end) begin
            wstate <= W_DONE;
          end
        end
        W_REQ: if (dw_req_ack) wstate <= W_DATA;
        W_DATA: if (dw_w_ready) begin
          rp   <= rp + 1'b1;
          wcnt <= wcnt + 8'd1;
          if (wcnt == wr_beats - 8'd1) wstate <= W_RESP;
        end
        W_RESP: if (dw_b_valid) begin
          wr_use_v <= 1'b0;
          progress <= 1'b1;
          if (dw_b_err) begin
            wstate <= W_DONE;
          end else begin
            dst_addr <= dst_addr + 64'(wr_bytes_q);
            wr_rem   <= wr_rem - wr_bytes_q;
            written  <= written + wr_bytes_q;
            wstate   <= (wr_rem == wr_bytes_q) ? W_DONE : W_PLAN;
          end
        end
        default: ;
      endcase

      // ---- completion
      if (active && rstate == R_DONE && wstate == W_DONE && !(cmd_valid && cmd_ready)) begin
        active           <= 1'b0;
        rstate           <= R_IDLE;
        wstate           <= W_IDLE;
        done_valid       <= 1'b1;
        done_status      <= err_set ? err_status : SFX_ST_OK;
        done_bytes       <= written;
        done_fault_addr  <= err_addr;
        done_fault_valid <= err_set && (err_status != SFX_ST_ABORTED);
        progress         <= 1'b1;
      end
    end
  end

endmodule
