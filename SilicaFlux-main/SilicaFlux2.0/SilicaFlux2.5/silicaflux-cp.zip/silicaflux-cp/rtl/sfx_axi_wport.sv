// AXI4 write-burst master port shared by NREQ requesters. One burst outstanding at a time.
//
// Requester protocol: hold req_valid/req_addr/req_beats until req_ack (1-cycle pulse). Then
// present w_valid/w_data/w_strb for each beat; a beat is consumed when w_valid && w_ready.
// Data and strobes must stay stable while w_valid && !w_ready. When the last beat has been
// written and the B response arrives, b_valid[i] pulses for one cycle with b_err.
// Address phase is always issued BEFORE data (AW then W).
module sfx_axi_wport #(
  parameter int NREQ   = 2,
  parameter int DATA_W = 64
) (
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic [NREQ-1:0]                   req_valid,
  input  logic [NREQ-1:0][63:0]             req_addr,
  input  logic [NREQ-1:0][7:0]              req_beats,
  output logic [NREQ-1:0]                   req_ack,
  input  logic [NREQ-1:0]                   w_valid,
  input  logic [NREQ-1:0][DATA_W-1:0]       w_data,
  input  logic [NREQ-1:0][DATA_W/8-1:0]     w_strb,
  output logic [NREQ-1:0]                   w_ready,
  output logic [NREQ-1:0]                   b_valid,
  output logic                              b_err,
  output logic                              idle,
  // AXI4 AW / W / B
  output logic [63:0]                       awaddr,
  output logic [7:0]                        awlen,
  output logic [2:0]                        awsize,
  output logic [1:0]                        awburst,
  output logic                              awvalid,
  input  logic                              awready,
  output logic [DATA_W-1:0]                 wdata,
  output logic [DATA_W/8-1:0]               wstrb,
  output logic                              wlast,
  output logic                              wvalid,
  input  logic                              wready,
  input  logic [1:0]                        bresp,
  input  logic                              bvalid,
  output logic                              bready
);
  localparam int OW = (NREQ > 1) ? $clog2(NREQ) : 1;
  typedef enum logic [1:0] {S_IDLE, S_AW, S_W, S_B} st_t;
  st_t st;
  logic [OW-1:0] owner, rr;
  logic [7:0]    cnt;       // beats accepted so far

  assign awsize  = 3'($clog2(DATA_W / 8));
  assign awburst = 2'b01;

  logic [OW-1:0] gsel;
  logic          gany;
  always_comb begin
    gany = 1'b0;
    gsel = '0;
    for (int k = 0; k < NREQ; k++) begin
      int idx;
      idx = (int'(rr) + k) % NREQ;
      if (!gany && req_valid[idx]) begin
        gany = 1'b1;
        gsel = OW'(idx);
      end
    end
  end

  always_comb begin
    req_ack = '0;
    if (st == S_IDLE && gany) req_ack[gsel] = 1'b1;
  end

  assign wvalid = (st == S_W) && w_valid[owner];
  assign wdata  = w_data[owner];
  assign wstrb  = w_strb[owner];
  assign wlast  = (cnt == awlen);
  always_comb begin
    w_ready = '0;
    if (st == S_W) w_ready[owner] = wready;
  end
  assign bready = (st == S_B);
  always_comb begin
    b_valid = '0;
    if (st == S_B && bvalid) b_valid[owner] = 1'b1;
  end
  assign b_err = (bresp != 2'b00);
  assign idle  = (st == S_IDLE) && !(|req_valid);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; owner <= '0; rr <= '0; cnt <= '0;
      awaddr <= '0; awlen <= '0; awvalid <= 1'b0;
    end else begin
      unique case (st)
        S_IDLE: if (gany) begin
          owner   <= gsel;
          awaddr  <= req_addr[gsel];
          awlen   <= req_beats[gsel] - 8'd1;
          awvalid <= 1'b1;
          cnt     <= '0;
          rr      <= OW'((int'(gsel) + 1) % NREQ);
          st      <= S_AW;
        end
        S_AW: if (awready) begin
          awvalid <= 1'b0;
          st      <= S_W;
        end
        S_W: if (wvalid && wready) begin
          cnt <= cnt + 8'd1;
          if (wlast) st <= S_B;
        end
        S_B: if (bvalid) st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
