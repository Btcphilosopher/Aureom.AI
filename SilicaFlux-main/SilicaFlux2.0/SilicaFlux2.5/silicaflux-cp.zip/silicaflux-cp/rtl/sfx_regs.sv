// Register file (SPEC 3, 4, 6, 11-13): every programmer-visible register and the state
// machines that belong to it -- authorisation windows, queue enable/drain/error states,
// doorbell validation, IRQ status, watchdog and reset status.
//
// Reset domains:  rst_n      -> everything (power-on)
//                 soft_rst   -> everything except the "persistent" set (SPEC 3, item 7):
//                               SCRATCH, IRQ_ENABLE, IRQ_MISC_VECTOR, RESET_TIMEOUT,
//                               RESET_STATUS and the Q_RST_* snapshot registers.
module sfx_regs #(
  parameter int                 NQ             = 2,
  parameter int                 NW             = 8,
  parameter int                 NV             = 3,
  parameter int                 INFL           = 4,
  parameter int                 DATA_W         = 64,
  parameter logic [63:0]        DEV_MEM_SIZE   = 64'h0100_0000,
  parameter int                 HOST_ADDR_BITS = 48
) (
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    soft_rst,

  // register bus (from sfx_axil_slave)
  input  logic                    wr_en,
  input  logic [15:0]             wr_addr,
  input  logic [31:0]             wr_data,
  input  logic [3:0]              wr_strb,
  input  logic [15:0]             rd_addr,
  output logic [31:0]             rd_data,

  // global
  output logic                    ctrl_enable,
  output logic                    fault,           // watchdog fault latched
  input  logic                    core_idle,

  // windows
  output logic [NW-1:0]           win_valid,
  output logic [NW-1:0][63:0]     win_base,
  output logic [NW-1:0][63:0]     win_size,
  output logic [NW-1:0]           win_space,
  output logic [NW-1:0]           win_r,
  output logic [NW-1:0]           win_w,
  output logic [NW-1:0][3:0]      win_dom,
  input  logic [NW-1:0]           win_use,

  // queues -> core
  output logic [NQ-1:0]           q_enabled,
  output logic [NQ-1:0]           q_pub_ok,
  output logic [NQ-1:0][63:0]     q_sq_base,
  output logic [NQ-1:0][63:0]     q_cq_base,
  output logic [NQ-1:0][4:0]      q_sq_log2,
  output logic [NQ-1:0][4:0]      q_cq_log2,
  output logic [NQ-1:0][3:0]      q_dom,
  output logic [NQ-1:0][31:0]     q_sq_head,
  output logic [NQ-1:0][31:0]     q_sq_tail,
  output logic [NQ-1:0][31:0]     q_cq_head,
  output logic [NQ-1:0][31:0]     q_cq_tail,
  output logic [NQ-1:0][31:0]     q_seq_start,
  output logic [NQ-1:0][15:0]     q_coal_cnt,
  output logic [NQ-1:0][15:0]     q_coal_tmr,
  output logic [NQ-1:0][2:0]      q_vector,

  // events from the core
  input  logic [NQ-1:0]           sq_consume,
  input  logic [NQ-1:0]           cq_publish,
  input  logic [NQ-1:0]           cq_pub_inflight,
  input  logic [NQ-1:0]           cmd_ok_pulse,
  input  logic [NQ-1:0]           cmd_err_pulse,
  input  logic [NQ-1:0]           q_busy,
  input  logic                    qfatal_valid,
  input  logic [$clog2(NQ > 1 ? NQ : 2)-1:0] qfatal_q,
  input  logic [7:0]              qfatal_code,
  input  logic [63:0]             qfatal_addr,
  input  logic                    frec_valid,
  input  logic [63:0]             frec_addr,
  input  logic [15:0]             frec_status,
  input  logic [$clog2(NQ > 1 ? NQ : 2)-1:0] frec_q,

  // interrupts
  input  logic [NQ-1:0]           qcpl_set,
  output logic [10:0]             irq_status_o,
  output logic [10:0]             irq_enable_o,
  output logic [2:0]              irq_misc_vector_o,
  output logic                    irq_blank,

  // watchdog
  output logic                    wdt_enable,
  output logic [31:0]             wdt_timeout,
  input  logic                    wdt_expired,
  input  logic [31:0]             wdt_count,
  input  logic                    wdt_armed,
  input  logic [3:0]              wdt_stuck,

  // reset
  output logic                    rst_req,
  output logic [31:0]             rst_timeout,
  input  logic                    rst_busy,
  input  logic                    rst_done,
  input  logic                    rst_drain_timeout,
  input  logic                    snap
);
  import sfx_pkg::*;
  localparam int QW    = $clog2(NQ > 1 ? NQ : 2);
  localparam int BLOG2 = $clog2(DATA_W / 8);

  // =============================================================== state
  // global
  logic [31:0] abi_req, scratch, err_status, err_count, dup_cnt, fault_cause, fault_info;
  logic [31:0] cmds_ok, cmds_err;
  logic [63:0] fault_addr;
  logic        ctrl_en_r;
  // irq
  logic [10:0] irq_st, irq_en;
  logic [2:0]  irq_misc;
  logic [1:0]  blank_cnt;
  // watchdog
  logic        wdt_en_r, wdt_exp_r;
  logic [31:0] wdt_to;
  logic [3:0]  wdt_stuck_r;
  logic [15:0] wdt_expcnt;
  // reset
  logic [31:0] rst_to;
  logic        rst_done_r, rst_dto_r;
  logic [15:0] rst_count;
  // windows
  logic [NW-1:0]          w_valid_r, w_err_r, w_space_r, w_r_r, w_w_r;
  logic [NW-1:0][3:0]     w_dom_r;
  logic [NW-1:0][63:0]    w_base_r, w_size_r;
  // queues
  logic [NQ-1:0][1:0]     qstate;
  logic [NQ-1:0][7:0]     qerr;
  logic [NQ-1:0]          qdrop;
  logic [NQ-1:0][3:0]     qdom_r;
  logic [NQ-1:0][63:0]    sqb, cqb;
  logic [NQ-1:0][4:0]     sql, cql;
  logic [NQ-1:0][2:0]     qvec;
  logic [NQ-1:0][31:0]    seqs, sqh, sqt, cqh, cqt, qok, qer;
  logic [NQ-1:0][15:0]    coal_c, coal_t;
  logic [NQ-1:0][31:0]    snap_sqt, snap_sqh, snap_cqt;

  // =============================================================== outputs
  assign ctrl_enable      = ctrl_en_r;
  assign fault            = (fault_cause != 32'd0);
  assign win_valid        = w_valid_r;
  assign win_base         = w_base_r;
  assign win_size         = w_size_r;
  assign win_space        = w_space_r;
  assign win_r            = w_r_r;
  assign win_w            = w_w_r;
  assign win_dom          = w_dom_r;
  assign q_sq_base        = sqb;
  assign q_cq_base        = cqb;
  assign q_sq_log2        = sql;
  assign q_cq_log2        = cql;
  assign q_dom            = qdom_r;
  assign q_sq_head        = sqh;
  assign q_sq_tail        = sqt;
  assign q_cq_head        = cqh;
  assign q_cq_tail        = cqt;
  assign q_seq_start      = seqs;
  assign q_coal_cnt       = coal_c;
  assign q_coal_tmr       = coal_t;
  assign q_vector         = qvec;
  assign irq_status_o     = irq_st;
  assign irq_enable_o     = irq_en;
  assign irq_misc_vector_o = irq_misc;
  assign irq_blank        = (blank_cnt != 2'd0);
  assign wdt_enable       = wdt_en_r;
  assign wdt_timeout      = wdt_to;
  assign rst_timeout      = rst_to;
  always_comb begin
    for (int q = 0; q < NQ; q++) begin
      q_enabled[q] = (qstate[q] == SFX_QS_ENABLED);
      q_pub_ok[q]  = ((qstate[q] == SFX_QS_ENABLED) || (qstate[q] == SFX_QS_DRAINING)) && !qdrop[q];
    end
  end

  logic abi_ok;
  assign abi_ok = (abi_req[31:16] == 16'(SFX_ABI_MAJOR)) && (abi_req[15:0] <= 16'(SFX_ABI_MINOR));

  // =============================================================== write decode
  logic        acc_ok, is_ctl, is_db, is_win, is_qr, do_wr;
  logic [11:0] w_off;
  logic [3:0]  w_page;
  logic [11:0] win_rel, q_rel;
  logic [$clog2(NW > 1 ? NW : 2)-1:0] wsel;
  logic [QW-1:0]                      qsel;
  logic [QW-1:0]                      dbq;
  assign w_page  = wr_addr[15:12];
  assign w_off   = wr_addr[11:0];
  assign acc_ok  = (wr_strb == 4'hF) && (wr_addr[1:0] == 2'b00);
  assign is_ctl  = (w_page == 4'd0);
  assign do_wr   = wr_en && !rst_busy;
  assign win_rel = w_off - 12'(SFX_WIN_BASE);
  assign q_rel   = w_off - 12'(SFX_Q_BASE);
  assign is_win  = is_ctl && (w_off >= 12'(SFX_WIN_BASE)) && (win_rel < 12'(NW * 32));
  assign is_qr   = is_ctl && (w_off >= 12'(SFX_Q_BASE))   && (q_rel   < 12'(NQ * 128));
  assign is_db   = (w_page != 4'd0) && ((w_page - 4'd1) < 4'(NQ)) && (wr_addr[11:3] == 9'd0);
  assign wsel    = win_rel[$clog2(NW > 1 ? NW : 2) + 4 : 5];
  assign qsel    = q_rel[QW + 6 : 7];
  assign dbq     = QW'(w_page - 4'd1);

  // ---------------------------------------------------------------- window commit validation
  logic [64:0] wv_end, wv_lim;
  logic        wv_ok;
  always_comb begin
    wv_end = {1'b0, w_base_r[wsel]} + {1'b0, w_size_r[wsel]};
    wv_lim = wr_data[1] ? {1'b0, DEV_MEM_SIZE} : (65'd1 << HOST_ADDR_BITS);
    wv_ok  = (w_size_r[wsel] != 64'd0)
          && (w_base_r[wsel][BLOG2-1:0] == '0) && (w_size_r[wsel][BLOG2-1:0] == '0)
          && (wv_end <= wv_lim)
          && (wr_data[2] || wr_data[3]);
  end

  // ---------------------------------------------------------------- queue enable validation
  logic [31:0] en_sq_bytes, en_cq_bytes, en_mask;
  logic [64:0] en_sq_end, en_cq_end, host_lim;
  logic        en_sq_ok, en_cq_ok, en_cfg_ok, en_ok;
  logic [NW-1:0] unused_hit_a, unused_hit_b;
  logic [4:0]  en_maxlog;
  always_comb begin
    en_sq_bytes = 32'd64 << sql[qsel];
    en_cq_bytes = 32'd32 << cql[qsel];
    host_lim    = 65'd1 << HOST_ADDR_BITS;
    en_sq_end   = {1'b0, sqb[qsel]} + {33'b0, en_sq_bytes};
    en_cq_end   = {1'b0, cqb[qsel]} + {33'b0, en_cq_bytes};
    en_maxlog   = (sql[qsel] > cql[qsel]) ? sql[qsel] : cql[qsel];
    en_mask     = (32'd1 << en_maxlog) - 32'd1;
    en_cfg_ok   = abi_ok
               && (sql[qsel] >= 5'(SFX_MIN_RING_LOG2)) && (sql[qsel] <= 5'(SFX_MAX_RING_LOG2))
               && (cql[qsel] >= 5'(SFX_MIN_RING_LOG2)) && (cql[qsel] <= 5'(SFX_MAX_RING_LOG2))
               && (sqb[qsel][5:0] == 6'd0) && (cqb[qsel][5:0] == 6'd0)
               && (en_sq_end <= host_lim) && (en_cq_end <= host_lim)
               && ((seqs[qsel] & en_mask) == 32'd0);
  end
  sfx_authz #(.NW(NW)) u_az_sq (
    .win_valid(w_valid_r), .win_base(w_base_r), .win_size(w_size_r), .win_space(w_space_r),
    .win_r(w_r_r), .win_w(w_w_r), .win_dom(w_dom_r),
    .q_space(1'b0), .q_dom(wr_data[11:8]), .q_addr(sqb[qsel]), .q_len(en_sq_bytes), .q_wr(1'b0),
    .ok(en_sq_ok), .hit(unused_hit_a));
  sfx_authz #(.NW(NW)) u_az_cq (
    .win_valid(w_valid_r), .win_base(w_base_r), .win_size(w_size_r), .win_space(w_space_r),
    .win_r(w_r_r), .win_w(w_w_r), .win_dom(w_dom_r),
    .q_space(1'b0), .q_dom(wr_data[11:8]), .q_addr(cqb[qsel]), .q_len(en_cq_bytes), .q_wr(1'b1),
    .ok(en_cq_ok), .hit(unused_hit_b));
  assign en_ok = en_cfg_ok && en_sq_ok && en_cq_ok;

  // =============================================================== sequential logic
  logic [31:0] err_ev;          // blocking temporaries: events raised by this cycle's actions
  logic [10:0] irq_set, irq_clr;
  logic [31:0] err_clr;
  logic        wdt_clr;
  logic [31:0] dnew, dold, dmax;

  /* verilator lint_off BLKSEQ */
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      abi_req <= '0; scratch <= '0; err_status <= '0; err_count <= '0; dup_cnt <= '0;
      fault_cause <= '0; fault_info <= '0; fault_addr <= '0; cmds_ok <= '0; cmds_err <= '0;
      ctrl_en_r <= 1'b0;
      irq_st <= '0; irq_en <= '0; irq_misc <= 3'(NQ); blank_cnt <= '0;
      wdt_en_r <= 1'b0; wdt_exp_r <= 1'b0; wdt_to <= '0; wdt_stuck_r <= '0; wdt_expcnt <= '0;
      rst_to <= 32'd100000; rst_done_r <= 1'b0; rst_dto_r <= 1'b0; rst_count <= '0; rst_req <= 1'b0;
      w_valid_r <= '0; w_err_r <= '0; w_space_r <= '0; w_r_r <= '0; w_w_r <= '0;
      w_dom_r <= '0; w_base_r <= '0; w_size_r <= '0;
      qstate <= '0; qerr <= '0; qdrop <= '0; qdom_r <= '0; sqb <= '0; cqb <= '0; sql <= '0; cql <= '0;
      seqs <= '0; sqh <= '0; sqt <= '0; cqh <= '0; cqt <= '0; qok <= '0; qer <= '0;
      coal_c <= '0; coal_t <= '0; snap_sqt <= '0; snap_sqh <= '0; snap_cqt <= '0;
      for (int q = 0; q < NQ; q++) qvec[q] <= 3'(q);
    end else begin
      err_ev = '0; err_clr = '0; irq_set = '0; irq_clr = '0; wdt_clr = 1'b0;
      rst_req <= 1'b0;
      if (blank_cnt != 2'd0) blank_cnt <= blank_cnt - 2'd1;

      // ------------------------------------------------ persistent: snapshot + reset status
      if (snap) begin
        snap_sqt <= sqt; snap_sqh <= sqh; snap_cqt <= cqt;
      end
      if (rst_done) begin rst_done_r <= 1'b1; rst_count <= rst_count + 16'd1; irq_set[10] = 1'b1; end
      if (rst_drain_timeout) rst_dto_r <= 1'b1;

      if (soft_rst) begin
        // ---------------------------------------------- controlled reset: non-persistent state
        abi_req <= '0; err_status <= '0; err_count <= '0; dup_cnt <= '0;
        fault_cause <= '0; fault_info <= '0; fault_addr <= '0; cmds_ok <= '0; cmds_err <= '0;
        ctrl_en_r <= 1'b0; irq_st <= '0; blank_cnt <= '0;
        wdt_en_r <= 1'b0; wdt_exp_r <= 1'b0; wdt_to <= '0; wdt_stuck_r <= '0; wdt_expcnt <= '0;
        w_valid_r <= '0; w_err_r <= '0; w_space_r <= '0; w_r_r <= '0; w_w_r <= '0;
        w_dom_r <= '0; w_base_r <= '0; w_size_r <= '0;
        qstate <= '0; qerr <= '0; qdrop <= '0; qdom_r <= '0; sqb <= '0; cqb <= '0; sql <= '0; cql <= '0;
        seqs <= '0; sqh <= '0; sqt <= '0; cqh <= '0; cqt <= '0; qok <= '0; qer <= '0;
        coal_c <= '0; coal_t <= '0;
        for (int q = 0; q < NQ; q++) qvec[q] <= 3'(q);
      end else begin
        // ---------------------------------------------- events from the core
        for (int q = 0; q < NQ; q++) begin
          if (sq_consume[q])    sqh[q] <= sqh[q] + 32'd1;
          if (cq_publish[q])    cqt[q] <= cqt[q] + 32'd1;
          if (cmd_ok_pulse[q])  qok[q] <= qok[q] + 32'd1;
          if (cmd_err_pulse[q]) qer[q] <= qer[q] + 32'd1;
          if (qstate[q] == SFX_QS_DRAINING && !q_busy[q]) begin
            qstate[q] <= SFX_QS_DISABLED;
            qdrop[q]  <= 1'b0;
          end
        end
        if (|cmd_ok_pulse)  cmds_ok  <= cmds_ok  + 32'd1;
        if (|cmd_err_pulse) cmds_err <= cmds_err + 32'd1;
        irq_set[NQ-1:0] = irq_set[NQ-1:0] | qcpl_set;

        if (frec_valid) begin
          fault_addr <= frec_addr;
          fault_info <= {12'b0, 4'(frec_q), frec_status};
        end
        if (qfatal_valid) begin
          fault_addr <= qfatal_addr;
          fault_info <= {12'b0, 4'(qfatal_q), 8'h80, qfatal_code};
          if (qstate[qfatal_q] == SFX_QS_ENABLED) begin
            qstate[qfatal_q] <= SFX_QS_ERROR;
            qerr[qfatal_q]   <= qfatal_code;
            qdrop[qfatal_q]  <= 1'b1;
            irq_set[4 + int'(qfatal_q)] = 1'b1;
          end else if (qstate[qfatal_q] == SFX_QS_DRAINING) begin
            qerr[qfatal_q]   <= qfatal_code;
            qdrop[qfatal_q]  <= 1'b1;
          end
        end

        if (wdt_expired) begin
          wdt_exp_r <= 1'b1; wdt_stuck_r <= wdt_stuck; wdt_expcnt <= wdt_expcnt + 16'd1;
          fault_cause <= fault_cause | SFX_FAULT_WDT;
          irq_set[9] = 1'b1;
        end

        // ---------------------------------------------- bus writes
        if (do_wr) begin
          if (!acc_ok) begin
            err_ev |= SFX_ERR_BAD_REG_ACCESS;
          end else if (is_ctl && w_off < 12'h100) begin
            // ------------------------------------------ global registers
            unique case ({4'b0, w_off[7:0]})
              12'(SFX_R_ABI_REQ):        abi_req <= wr_data;
              12'(SFX_R_SCRATCH):        scratch <= wr_data;
              12'(SFX_R_CTRL):           ctrl_en_r <= wr_data[0];
              12'(SFX_R_ERR_STATUS):     err_clr = wr_data;
              12'(SFX_R_IRQ_STATUS):     begin irq_clr = wr_data[10:0] & 11'(SFX_IRQ_VALID_MASK); blank_cnt <= 2'd2; end
              12'(SFX_R_IRQ_ENABLE):     irq_en <= wr_data[10:0] & 11'(SFX_IRQ_VALID_MASK);
              12'(SFX_R_IRQ_MISC_VECTOR): begin
                if (wr_data < 32'(NV)) irq_misc <= wr_data[2:0];
                else err_ev |= SFX_ERR_BAD_IRQ_CONFIG;
              end
              12'(SFX_R_IRQ_FORCE):      irq_set = irq_set | (wr_data[10:0] & 11'(SFX_IRQ_VALID_MASK));
              12'(SFX_R_WDT_CTRL): begin
                if (wr_data[0] && wdt_to == 32'd0) err_ev |= SFX_ERR_BAD_REG_ACCESS;
                else wdt_en_r <= wr_data[0];
              end
              12'(SFX_R_WDT_TIMEOUT):    wdt_to <= wr_data;
              12'(SFX_R_WDT_STATUS):     wdt_clr = wr_data[2];
              12'(SFX_R_RESET_CTRL): begin
                if (wr_data[31:16] == 16'(SFX_RESET_KEY) && wr_data[0]) begin
                  rst_req <= 1'b1; rst_done_r <= 1'b0; rst_dto_r <= 1'b0;
                end else begin
                  err_ev |= SFX_ERR_BAD_REG_ACCESS;
                end
              end
              12'(SFX_R_RESET_TIMEOUT):  rst_to <= wr_data;
              default:                   err_ev |= SFX_ERR_BAD_REG_ACCESS;   // RO or reserved
            endcase
          end else if (is_win) begin
            // ------------------------------------------ authorisation windows
            unique case (win_rel[4:2])
              3'd0, 3'd1, 3'd2, 3'd3: begin
                if (w_valid_r[wsel]) err_ev |= SFX_ERR_CFG_LOCKED;
                else begin
                  unique case (win_rel[4:2])
                    3'd0: w_base_r[wsel][31:0]  <= wr_data;
                    3'd1: w_base_r[wsel][63:32] <= wr_data;
                    3'd2: w_size_r[wsel][31:0]  <= wr_data;
                    default: w_size_r[wsel][63:32] <= wr_data;
                  endcase
                end
              end
              3'd4: begin
                if (!wr_data[0]) begin
                  w_valid_r[wsel] <= 1'b0;                  // invalidate: immediate for new decisions
                  w_err_r[wsel]   <= 1'b0;
                  w_space_r[wsel] <= wr_data[1]; w_r_r[wsel] <= wr_data[2];
                  w_w_r[wsel] <= wr_data[3];     w_dom_r[wsel] <= wr_data[11:8];
                end else if (w_valid_r[wsel]) begin
                  w_err_r[wsel] <= 1'b1;
                  err_ev |= SFX_ERR_CFG_LOCKED;
                end else begin
                  w_space_r[wsel] <= wr_data[1]; w_r_r[wsel] <= wr_data[2];
                  w_w_r[wsel] <= wr_data[3];     w_dom_r[wsel] <= wr_data[11:8];
                  if (wv_ok) begin
                    w_valid_r[wsel] <= 1'b1; w_err_r[wsel] <= 1'b0;
                  end else begin
                    w_err_r[wsel] <= 1'b1;
                    err_ev |= SFX_ERR_BAD_WINDOW;
                  end
                end
              end
              default: err_ev |= SFX_ERR_BAD_REG_ACCESS;
            endcase
          end else if (is_qr) begin
            // ------------------------------------------ queue registers
            unique case (q_rel[6:2])
              5'(SFX_R_Q_CTRL >> 2): begin
                if (qstate[qsel] == SFX_QS_DISABLED) begin
                  qdom_r[qsel] <= wr_data[11:8];
                  if (wr_data[0]) begin
                    if (en_ok) begin
                      qstate[qsel] <= SFX_QS_ENABLED; qerr[qsel] <= '0; qdrop[qsel] <= 1'b0;
                      sqh[qsel] <= seqs[qsel]; sqt[qsel] <= seqs[qsel];
                      cqh[qsel] <= seqs[qsel]; cqt[qsel] <= seqs[qsel];
                      qok[qsel] <= '0; qer[qsel] <= '0;
                    end else begin
                      qstate[qsel] <= SFX_QS_ERROR; qerr[qsel] <= SFX_QERR_BAD_CONFIG;
                      qdrop[qsel] <= 1'b1;
                      irq_set[4 + int'(qsel)] = 1'b1;
                      err_ev |= SFX_ERR_BAD_QCONFIG;
                    end
                  end
                end else begin
                  if (wr_data[11:8] != qdom_r[qsel]) err_ev |= SFX_ERR_CFG_LOCKED;
                  if (!wr_data[0]) begin
                    if (qstate[qsel] == SFX_QS_ENABLED || qstate[qsel] == SFX_QS_ERROR)
                      qstate[qsel] <= SFX_QS_DRAINING;
                  end else begin
                    err_ev |= SFX_ERR_CFG_LOCKED;      // ENABLE=1 in any state but DISABLED is ignored
                  end
                end
              end
              5'(SFX_R_Q_IRQ_COAL >> 2): begin
                coal_c[qsel] <= wr_data[15:0]; coal_t[qsel] <= wr_data[31:16];
              end
              5'(SFX_R_Q_SQ_BASE_LO >> 2), 5'(SFX_R_Q_SQ_BASE_HI >> 2),
              5'(SFX_R_Q_CQ_BASE_LO >> 2), 5'(SFX_R_Q_CQ_BASE_HI >> 2),
              5'(SFX_R_Q_SIZE >> 2), 5'(SFX_R_Q_VECTOR >> 2), 5'(SFX_R_Q_SEQ_START >> 2): begin
                if (qstate[qsel] != SFX_QS_DISABLED) err_ev |= SFX_ERR_CFG_LOCKED;
                else begin
                  unique case (q_rel[6:2])
                    5'(SFX_R_Q_SQ_BASE_LO >> 2): sqb[qsel][31:0]  <= wr_data;
                    5'(SFX_R_Q_SQ_BASE_HI >> 2): sqb[qsel][63:32] <= wr_data;
                    5'(SFX_R_Q_CQ_BASE_LO >> 2): cqb[qsel][31:0]  <= wr_data;
                    5'(SFX_R_Q_CQ_BASE_HI >> 2): cqb[qsel][63:32] <= wr_data;
                    5'(SFX_R_Q_SIZE >> 2):       begin sql[qsel] <= wr_data[4:0]; cql[qsel] <= wr_data[12:8]; end
                    5'(SFX_R_Q_VECTOR >> 2): begin
                      if (wr_data < 32'(NV)) qvec[qsel] <= wr_data[2:0];
                      else err_ev |= SFX_ERR_BAD_IRQ_CONFIG;
                    end
                    default:                     seqs[qsel] <= wr_data;
                  endcase
                end
              end
              default: err_ev |= SFX_ERR_BAD_REG_ACCESS;       // RO / reserved
            endcase
          end else if (is_db) begin
            // ------------------------------------------ doorbells (SPEC 6.4)
            if (qstate[dbq] != SFX_QS_ENABLED) begin
              err_ev |= SFX_ERR_BAD_DOORBELL;
            end else if (!wr_addr[2]) begin                          // DB_SQ_TAIL
              dnew = wr_data - sqh[dbq];
              dold = sqt[dbq] - sqh[dbq];
              if (wr_data == sqt[dbq])                        dup_cnt <= dup_cnt + 32'd1;
              else if (dnew > dold && dnew <= (32'd1 << sql[dbq])) sqt[dbq] <= wr_data;
              else                                            err_ev |= SFX_ERR_BAD_DOORBELL;
            end else begin                                           // DB_CQ_HEAD
              dnew = wr_data - cqh[dbq];
              // bound = published + the one being published (its phase word may already be visible)
              dmax = cqt[dbq] - cqh[dbq] + 32'((cq_pub_inflight[dbq] || cq_publish[dbq]) ? 1 : 0);
              if (wr_data == cqh[dbq])                        dup_cnt <= dup_cnt + 32'd1;
              else if (dnew <= dmax)                          cqh[dbq] <= wr_data;
              else                                            err_ev |= SFX_ERR_BAD_DOORBELL;
            end
          end else begin
            err_ev |= SFX_ERR_BAD_REG_ACCESS;                        // unmapped
          end
        end

        // ---------------------------------------------- sticky status updates
        if (err_ev != 32'd0) begin
          err_count <= err_count + 32'd1;
          // Writes to the user-mappable doorbell pages are recorded but never raise DEV_ERR: an untrusted
          // queue owner must not be able to generate kernel-visible interrupts at will.
          if ((err_ev & ~err_status) != 32'd0 && w_page == 4'd0) irq_set[8] = 1'b1;
        end
        err_status <= (err_status & ~err_clr) | err_ev;
        irq_st     <= (irq_st & ~irq_clr) | irq_set;
        if (wdt_clr && !wdt_expired) wdt_exp_r <= 1'b0;
      end
    end
  end
  /* verilator lint_on BLKSEQ */

  // =============================================================== read mux
  logic [11:0] r_off;
  logic [3:0]  r_page;
  logic [11:0] r_win_rel, r_q_rel;
  logic [$clog2(NW > 1 ? NW : 2)-1:0] rwsel;
  logic [QW-1:0]                      rqsel, rdbq;
  assign r_off     = rd_addr[11:0];
  assign r_page    = rd_addr[15:12];
  assign r_win_rel = r_off - 12'(SFX_WIN_BASE);
  assign r_q_rel   = r_off - 12'(SFX_Q_BASE);
  assign rwsel     = r_win_rel[$clog2(NW > 1 ? NW : 2) + 4 : 5];
  assign rqsel     = r_q_rel[QW + 6 : 7];
  assign rdbq      = QW'(r_page - 4'd1);

  logic any_pending;
  always_comb begin
    any_pending = 1'b0;
    for (int q = 0; q < NQ; q++)
      if (qstate[q] == SFX_QS_ENABLED && sqt[q] != sqh[q]) any_pending = 1'b1;
  end

  logic [31:0] status_v, caps_v;
  assign status_v = {26'b0, abi_ok, (core_idle && !any_pending), rst_busy, fault,
                     (ctrl_en_r && !fault && !rst_busy), !rst_busy};
  assign caps_v   = SFX_CAP_KERNEL | SFX_CAP_COPY_H2D | SFX_CAP_COPY_D2H | SFX_CAP_COPY_D2D |
                    SFX_CAP_FENCE | SFX_CAP_FENCE_SIGNAL | SFX_CAP_IRQ_COALESCE | SFX_CAP_WATCHDOG |
                    SFX_CAP_SOFT_RESET | SFX_CAP_WINDOW_AUTHZ | SFX_CAP_SEQ_START;

  always_comb begin
    rd_data = '0;
    if (r_page == 4'd0) begin
      if (r_off < 12'h100) begin
        unique case (r_off)
          12'(SFX_R_ID):           rd_data = SFX_ID_VALUE;
          12'(SFX_R_VERSION):      rd_data = {8'(SFX_ABI_MAJOR), 8'(SFX_ABI_MINOR), 16'(SFX_ABI_PATCH)};
          12'(SFX_R_CAPS):         rd_data = caps_v;
          12'(SFX_R_GEOMETRY):     rd_data = {4'b0, 4'(INFL), 4'b0, 4'(NV), 8'(NW), 4'b0, 4'(NQ)};
          12'(SFX_R_LIMITS):       rd_data = {8'(SFX_CQE_LOG2), 8'(SFX_DESC_LOG2), 8'(BLOG2), 8'(SFX_MAX_RING_LOG2)};
          12'(SFX_R_MAX_COPY):     rd_data = SFX_MAX_COPY_BYTES;
          12'(SFX_R_DEVMEM_LO):    rd_data = DEV_MEM_SIZE[31:0];
          12'(SFX_R_DEVMEM_HI):    rd_data = DEV_MEM_SIZE[63:32];
          12'(SFX_R_HOST_ADDR_BITS): rd_data = 32'(HOST_ADDR_BITS);
          12'(SFX_R_DESC_VERSIONS): rd_data = 32'd1 << SFX_DESC_VERSION;
          12'(SFX_R_LIMITS2):      rd_data = {16'(SFX_MAX_GRID_DIM), 16'(SFX_MAX_ARGS_BYTES)};
          12'(SFX_R_ABI_REQ):      rd_data = abi_req;
          12'(SFX_R_SCRATCH):      rd_data = scratch;
          12'(SFX_R_CTRL):         rd_data = {31'b0, ctrl_en_r};
          12'(SFX_R_STATUS):       rd_data = status_v;
          12'(SFX_R_FAULT_CAUSE):  rd_data = fault_cause;
          12'(SFX_R_ERR_STATUS):   rd_data = err_status;
          12'(SFX_R_ERR_COUNT):    rd_data = err_count;
          12'(SFX_R_DUP_DB_COUNT): rd_data = dup_cnt;
          12'(SFX_R_FAULT_ADDR_LO): rd_data = fault_addr[31:0];
          12'(SFX_R_FAULT_ADDR_HI): rd_data = fault_addr[63:32];
          12'(SFX_R_FAULT_INFO):   rd_data = fault_info;
          12'(SFX_R_CMDS_OK):      rd_data = cmds_ok;
          12'(SFX_R_CMDS_ERR):     rd_data = cmds_err;
          12'(SFX_R_IRQ_STATUS):   rd_data = {21'b0, irq_st};
          12'(SFX_R_IRQ_ENABLE):   rd_data = {21'b0, irq_en};
          12'(SFX_R_IRQ_MISC_VECTOR): rd_data = {29'b0, irq_misc};
          12'(SFX_R_WDT_CTRL):     rd_data = {31'b0, wdt_en_r};
          12'(SFX_R_WDT_TIMEOUT):  rd_data = wdt_to;
          12'(SFX_R_WDT_STATUS):   rd_data = {wdt_expcnt, 4'b0, wdt_stuck_r, 5'b0, wdt_exp_r, wdt_armed, wdt_en_r};
          12'(SFX_R_WDT_COUNT):    rd_data = wdt_count;
          12'(SFX_R_RESET_STATUS): rd_data = {rst_count, 13'b0, rst_dto_r, rst_done_r, rst_busy};
          12'(SFX_R_RESET_TIMEOUT): rd_data = rst_to;
          default:                 rd_data = '0;
        endcase
      end else if (r_off >= 12'(SFX_WIN_BASE) && r_win_rel < 12'(NW * 32)) begin
        unique case (r_win_rel[4:2])
          3'd0: rd_data = w_base_r[rwsel][31:0];
          3'd1: rd_data = w_base_r[rwsel][63:32];
          3'd2: rd_data = w_size_r[rwsel][31:0];
          3'd3: rd_data = w_size_r[rwsel][63:32];
          3'd4: rd_data = {14'b0, w_err_r[rwsel], win_use[rwsel], 4'b0, w_dom_r[rwsel], 4'b0,
                           w_w_r[rwsel], w_r_r[rwsel], w_space_r[rwsel], w_valid_r[rwsel]};
          default: rd_data = '0;
        endcase
      end else if (r_off >= 12'(SFX_Q_BASE) && r_q_rel < 12'(NQ * 128)) begin
        unique case (r_q_rel[6:2])
          5'(SFX_R_Q_CTRL >> 2):      rd_data = {20'b0, qdom_r[rqsel], 7'b0, (qstate[rqsel] == SFX_QS_ENABLED)};
          5'(SFX_R_Q_STATUS >> 2):    rd_data = {16'b0, qerr[rqsel], 6'b0, qstate[rqsel]};
          5'(SFX_R_Q_SQ_BASE_LO >> 2): rd_data = sqb[rqsel][31:0];
          5'(SFX_R_Q_SQ_BASE_HI >> 2): rd_data = sqb[rqsel][63:32];
          5'(SFX_R_Q_CQ_BASE_LO >> 2): rd_data = cqb[rqsel][31:0];
          5'(SFX_R_Q_CQ_BASE_HI >> 2): rd_data = cqb[rqsel][63:32];
          5'(SFX_R_Q_SIZE >> 2):      rd_data = {19'b0, cql[rqsel], 3'b0, sql[rqsel]};
          5'(SFX_R_Q_VECTOR >> 2):    rd_data = {29'b0, qvec[rqsel]};
          5'(SFX_R_Q_SEQ_START >> 2): rd_data = seqs[rqsel];
          5'(SFX_R_Q_IRQ_COAL >> 2):  rd_data = {coal_t[rqsel], coal_c[rqsel]};
          5'(SFX_R_Q_SQ_HEAD >> 2):   rd_data = sqh[rqsel];
          5'(SFX_R_Q_SQ_TAIL >> 2):   rd_data = sqt[rqsel];
          5'(SFX_R_Q_CQ_HEAD >> 2):   rd_data = cqh[rqsel];
          5'(SFX_R_Q_CQ_TAIL >> 2):   rd_data = cqt[rqsel];
          5'(SFX_R_Q_CMDS_OK >> 2):   rd_data = qok[rqsel];
          5'(SFX_R_Q_CMDS_ERR >> 2):  rd_data = qer[rqsel];
          5'(SFX_R_Q_RST_SQ_TAIL >> 2): rd_data = snap_sqt[rqsel];
          5'(SFX_R_Q_RST_SQ_HEAD >> 2): rd_data = snap_sqh[rqsel];
          5'(SFX_R_Q_RST_CQ_TAIL >> 2): rd_data = snap_cqt[rqsel];
          default:                    rd_data = '0;
        endcase
      end
    end else if (((r_page - 4'd1) < 4'(NQ)) && (rd_addr[11:3] == 9'd0)) begin
      rd_data = rd_addr[2] ? cqh[rdbq] : sqt[rdbq];     // doorbells read back the accepted value
    end
  end
endmodule
