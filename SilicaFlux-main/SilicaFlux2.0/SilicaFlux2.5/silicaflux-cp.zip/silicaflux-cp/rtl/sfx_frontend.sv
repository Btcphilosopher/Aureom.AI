// Frontend: round-robin queue selection, descriptor fetch, validation, issue (SPEC 5-7).
//
//   IDLE -> AUTH -> REQ -> DATA -> ISSUE -> IDLE
//
// Rules implemented here: fetch only when `run`; one descriptor at a time; issue stalls on a full
// table, a FENCE in flight, F_FENCE_BEFORE with a non-empty table, a busy DMA, or an unready
// kernel fabric.  Invalid commands are issued as already-complete entries carrying their status.
module sfx_frontend #(
  parameter int                 NQ             = 2,
  parameter int                 NW             = 8,
  parameter int                 DATA_W         = 64,
  parameter int                 DEPTH          = 4,
  parameter logic [63:0]        DEV_MEM_SIZE   = 64'h0100_0000,
  parameter int                 HOST_ADDR_BITS = 48
) (
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    run,            // CTRL.ENABLE & !FAULT & !RESETTING
  input  logic                    quiesce,

  // per-queue state from the register file
  input  logic [NQ-1:0]           q_enabled,
  input  logic [NQ-1:0]           q_credit,       // a CQ slot is guaranteed for one more command
  input  logic [NQ-1:0][63:0]     q_sq_base,
  input  logic [NQ-1:0][4:0]      q_sq_log2,
  input  logic [NQ-1:0][3:0]      q_dom,
  input  logic [NQ-1:0][31:0]     q_sq_head,
  input  logic [NQ-1:0][31:0]     q_sq_tail,
  output logic [NQ-1:0]           sq_consume,
  output logic                    qfatal_valid,
  output logic [$clog2(NQ > 1 ? NQ : 2)-1:0] qfatal_q,
  output logic [7:0]              qfatal_code,
  output logic [63:0]             qfatal_addr,

  // fault record for decode-time authorisation failures
  output logic                    frec_valid,
  output logic [63:0]             frec_addr,
  output logic [$clog2(NQ > 1 ? NQ : 2)-1:0] frec_q,

  // authorisation windows
  input  logic [NW-1:0]           win_valid,
  input  logic [NW-1:0][63:0]     win_base,
  input  logic [NW-1:0][63:0]     win_size,
  input  logic [NW-1:0]           win_space,
  input  logic [NW-1:0]           win_r,
  input  logic [NW-1:0]           win_w,
  input  logic [NW-1:0][3:0]      win_dom,
  output logic [NW-1:0]           win_use,

  // fabric client F (host read)
  output logic                    f_req_valid,
  output logic [63:0]             f_req_addr,
  output logic [7:0]              f_req_beats,
  input  logic                    f_req_ack,
  input  logic                    f_rsp_valid,
  input  logic [DATA_W-1:0]       f_rsp_data,
  input  logic                    f_rsp_last,
  input  logic                    f_rsp_err,

  // in-flight table
  output logic                    alloc_valid,
  output sfx_pkg::inf_t           alloc_data,
  output logic                    alloc_done,
  input  logic [$clog2(DEPTH)-1:0] alloc_idx,
  input  logic                    inf_full,
  input  logic                    inf_empty,
  input  logic                    fence_present,

  // DMA
  output logic                    dma_cmd_valid,
  input  logic                    dma_cmd_ready,
  output logic                    dma_cmd_src_dev,
  output logic                    dma_cmd_dst_dev,
  output logic [63:0]             dma_cmd_src,
  output logic [63:0]             dma_cmd_dst,
  output logic [31:0]             dma_cmd_len,
  output logic [3:0]              dma_cmd_dom,
  output logic [$clog2(DEPTH)-1:0] dma_tag,
  output logic [$clog2(NQ > 1 ? NQ : 2)-1:0] dma_q,

  // kernel fabric
  output logic                    kd_valid,
  input  logic                    kd_ready,
  output logic [$clog2(DEPTH)-1:0] kd_tag,
  output logic [31:0]             kd_cmd_id,
  output logic [63:0]             kd_kernel_addr,
  output logic [63:0]             kd_args_addr,
  output logic [31:0]             kd_args_size,
  output logic [31:0]             kd_grid_x, kd_grid_y, kd_grid_z,
  output logic [3:0]              kd_domain,
  input  logic                    kd_abort,

  // status
  output logic                    busy,
  output logic [NQ-1:0]           q_fetching,
  output logic                    progress,
  output logic                    dbg_issue_valid,
  output logic [31:0]             dbg_issue_cmd_id
);
  import sfx_pkg::*;
  localparam int QW    = $clog2(NQ > 1 ? NQ : 2);
  localparam int DBEATS = 512 / DATA_W;

  typedef enum logic [2:0] {FE_IDLE, FE_AUTH, FE_REQ, FE_DATA, FE_ISSUE} fe_t;
  fe_t           st;
  logic [QW-1:0] cur_q, rr;
  logic [31:0]   cur_seq;
  logic [63:0]   cur_addr;
  logic [3:0]    cur_dom;
  logic [511:0]  desc;
  logic [7:0]    beat;
  logic          err_acc;
  logic [NW-1:0] f_use;
  logic          f_use_v;

  // ---------------- queue pick
  logic [NQ-1:0] q_work;
  // A queue is only served while a completion slot is guaranteed for the command (q_credit): retire can then
  // never block on a full CQ, so one tenant's unreleased CQ cannot stall other queues' completions.
  always_comb for (int q = 0; q < NQ; q++) q_work[q] = q_enabled[q] && q_credit[q] && (q_sq_tail[q] != q_sq_head[q]);

  logic          pick_any;
  logic [QW-1:0] pick_q;
  always_comb begin
    pick_any = 1'b0;
    pick_q   = '0;
    for (int k = 0; k < NQ; k++) begin
      int idx;
      idx = (int'(rr) + k) % NQ;
      if (!pick_any && q_work[idx]) begin
        pick_any = 1'b1;
        pick_q   = QW'(idx);
      end
    end
  end

  // address of the descriptor slot for the picked queue: base + (head mod size) * 64
  logic [63:0] pick_idx, pick_addr;
  assign pick_idx  = {32'b0, q_sq_head[pick_q]} & ((64'd1 << q_sq_log2[pick_q]) - 64'd1);
  assign pick_addr = q_sq_base[pick_q] + (pick_idx << SFX_DESC_LOG2);

  // ---------------- descriptor-slot authorisation (fetch)
  logic          f_ok;
  logic [NW-1:0] f_hit;
  sfx_authz #(.NW(NW)) u_az_f (
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom,
    .q_space(1'b0), .q_dom(cur_dom), .q_addr(cur_addr), .q_len(32'd64), .q_wr(1'b0),
    .ok(f_ok), .hit(f_hit));

  // ---------------- decode
  logic [15:0] d_opcode, d_flags, d_status;
  logic [31:0] d_cmd_id, d_length, d_gx, d_gy, d_gz;
  logic [63:0] d_addr0, d_addr1, d_value, d_unauth_addr;
  logic        d_seq_ok, d_nop, d_copy, d_kernel, d_fence, d_src_dev, d_dst_dev, d_sig_en;

  sfx_decode #(.DATA_W(DATA_W), .NW(NW), .DEV_MEM_SIZE(DEV_MEM_SIZE), .HOST_ADDR_BITS(HOST_ADDR_BITS)) u_dec (
    .desc, .exp_seq(cur_seq), .dom(cur_dom),
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom,
    .opcode(d_opcode), .flags(d_flags), .cmd_id(d_cmd_id), .addr0(d_addr0), .addr1(d_addr1),
    .length(d_length), .grid_x(d_gx), .grid_y(d_gy), .grid_z(d_gz), .value(d_value),
    .seq_ok(d_seq_ok), .status(d_status),
    .is_nop(d_nop), .is_copy(d_copy), .is_kernel(d_kernel), .is_fence(d_fence),
    .src_dev(d_src_dev), .dst_dev(d_dst_dev), .sig_en(d_sig_en), .unauth_addr(d_unauth_addr));

  // ---------------- issue conditions
  logic d_ok, exec_dma, exec_kd, can_alloc, unit_ready, issue_fire, still_valid;
  assign d_ok       = (d_status == SFX_ST_OK);
  assign exec_dma   = d_copy   && d_ok;
  assign exec_kd    = d_kernel && d_ok;
  assign still_valid = run && !quiesce && q_enabled[cur_q];
  assign can_alloc  = !inf_full
                   && (d_fence || !fence_present)
                   && (((d_flags & SFX_F_FENCE_BEFORE) == 16'd0) || inf_empty);
  assign unit_ready = exec_dma ? dma_cmd_ready : (exec_kd ? kd_ready : 1'b1);
  assign issue_fire = (st == FE_ISSUE) && still_valid && d_seq_ok && can_alloc && unit_ready;

  // valid must hold until ready (or kd_abort / drop)
  assign dma_cmd_valid   = (st == FE_ISSUE) && still_valid && d_seq_ok && can_alloc && exec_dma;
  assign dma_cmd_src_dev = d_src_dev;
  assign dma_cmd_dst_dev = d_dst_dev;
  assign dma_cmd_src     = d_addr0;
  assign dma_cmd_dst     = d_addr1;
  assign dma_cmd_len     = d_length;
  assign dma_cmd_dom     = cur_dom;

  assign kd_valid        = (st == FE_ISSUE) && still_valid && d_seq_ok && can_alloc && exec_kd;
  assign kd_tag          = alloc_idx;
  assign kd_cmd_id       = d_cmd_id;
  assign kd_kernel_addr  = d_addr0;
  assign kd_args_addr    = d_addr1;
  assign kd_args_size    = d_length;
  assign kd_grid_x       = d_gx;
  assign kd_grid_y       = d_gy;
  assign kd_grid_z       = d_gz;
  assign kd_domain       = cur_dom;

  always_comb begin
    alloc_valid      = issue_fire;
    alloc_done       = d_nop || d_fence || !d_ok;
    alloc_data       = '0;
    alloc_data.q      = 2'(cur_q);
    alloc_data.seq    = cur_seq;
    alloc_data.cmd_id = d_cmd_id;
    alloc_data.opcode = d_opcode;
    alloc_data.flags  = d_flags;
    alloc_data.status = d_status;
    alloc_data.result = '0;
    alloc_data.sig_en = d_sig_en;
    alloc_data.sig_addr = d_addr0;
    alloc_data.sig_val  = d_value;
    alloc_data.domain = cur_dom;
    alloc_data.is_kernel = exec_kd;
  end


  assign sq_consume = issue_fire ? (NQ'(1) << cur_q) : '0;

  // ---------------- outputs
  assign f_req_valid = (st == FE_REQ);
  assign f_req_addr  = cur_addr;
  assign f_req_beats = 8'(DBEATS);
  assign busy        = (st != FE_IDLE);
  always_comb begin
    q_fetching = '0;
    if (st != FE_IDLE) q_fetching[cur_q] = 1'b1;
  end
  assign win_use = f_use_v ? f_use : '0;

  assign dbg_issue_valid  = issue_fire;
  assign dbg_issue_cmd_id = d_cmd_id;

  // ---------------- state machine
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= FE_IDLE; cur_q <= '0; rr <= '0; cur_seq <= '0; cur_addr <= '0; cur_dom <= '0;
      desc <= '0; beat <= '0; err_acc <= 1'b0; f_use <= '0; f_use_v <= 1'b0;
      qfatal_valid <= 1'b0; qfatal_q <= '0; qfatal_code <= '0; qfatal_addr <= '0;
      frec_valid <= 1'b0; frec_addr <= '0; frec_q <= '0; progress <= 1'b0;
      dma_tag <= '0; dma_q <= '0;
    end else begin
      qfatal_valid <= 1'b0;
      frec_valid   <= 1'b0;
      progress     <= 1'b0;

      unique case (st)
        FE_IDLE: if (run && !quiesce && pick_any) begin
          cur_q    <= pick_q;
          cur_seq  <= q_sq_head[pick_q];
          cur_dom  <= q_dom[pick_q];
          cur_addr <= pick_addr;
          rr       <= QW'((int'(pick_q) + 1) % NQ);
          st       <= FE_AUTH;
        end

        FE_AUTH: begin
          if (!run || quiesce || !q_enabled[cur_q]) begin
            st <= FE_IDLE;
          end else if (f_ok) begin
            f_use <= f_hit; f_use_v <= 1'b1;
            err_acc <= 1'b0; beat <= '0;
            st <= FE_REQ;
          end else begin
            qfatal_valid <= 1'b1; qfatal_q <= cur_q; qfatal_code <= SFX_QERR_RING_UNAUTH;
            qfatal_addr  <= cur_addr;
            st <= FE_IDLE;
          end
        end

        FE_REQ: if (f_req_ack) st <= FE_DATA;

        FE_DATA: if (f_rsp_valid) begin
          desc[int'(beat) * DATA_W +: DATA_W] <= f_rsp_data;
          beat    <= beat + 8'd1;
          err_acc <= err_acc | f_rsp_err;
          if (f_rsp_last) begin
            f_use_v  <= 1'b0;
            progress <= 1'b1;
            if (err_acc | f_rsp_err) begin
              qfatal_valid <= 1'b1; qfatal_q <= cur_q; qfatal_code <= SFX_QERR_SQ_FETCH;
              qfatal_addr  <= cur_addr;
              st <= FE_IDLE;
            end else begin
              st <= FE_ISSUE;
            end
          end
        end

        FE_ISSUE: begin
          if (!still_valid) begin
            st <= FE_IDLE;                       // paused / queue left ENABLED / quiesce: re-fetch later
          end else if (!d_seq_ok) begin
            qfatal_valid <= 1'b1; qfatal_q <= cur_q; qfatal_code <= SFX_QERR_BAD_SEQ;
            qfatal_addr  <= cur_addr;
            st <= FE_IDLE;
          end else if (issue_fire) begin
            progress <= 1'b1;
            if (exec_dma) begin dma_tag <= alloc_idx; dma_q <= cur_q; end
            if (d_status == SFX_ST_UNAUTHORIZED) begin
              frec_valid <= 1'b1; frec_addr <= d_unauth_addr; frec_q <= cur_q;
            end
            st <= FE_IDLE;
          end else if (kd_abort && exec_kd) begin
            st <= FE_IDLE;                       // fabric is aborting: withdraw
          end
        end

        default: st <= FE_IDLE;
      endcase
    end
  end
endmodule
