// Retire stage: publishes completions strictly in issue order (SPEC 7.4, 10.1).
//
//   head done?  [FENCE signal write -> response]  wait CQ space  authorise CQ slot
//     -> write #1: CQE bytes 0x00-0x1B   -> response
//     -> write #2: phase_word (bytes 0x1C-0x1F) alone  -> response
//     -> counters / interrupt event / pop
//
// The phase word is written last and only after the body's write response, so a host that sees
// the new phase sees a whole entry; interrupt events fire only after write #2's response.
module sfx_retire #(
  parameter int NQ     = 2,
  parameter int NW     = 8,
  parameter int DATA_W = 64                    // <= 256
) (
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    quiesce,

  // oldest in-flight entry
  input  logic                    head_valid,
  input  logic                    head_done,
  input  sfx_pkg::inf_t           head,
  output logic                    pop,

  // per-queue state
  input  logic [NQ-1:0]           q_pub_ok,        // ENABLED or DRAINING, and not dropping
  input  logic [NQ-1:0][63:0]     q_cq_base,
  input  logic [NQ-1:0][4:0]      q_cq_log2,
  input  logic [NQ-1:0][31:0]     q_cq_head,
  input  logic [NQ-1:0][31:0]     q_cq_tail,
  input  logic [NQ-1:0][31:0]     q_seq_start,
  output logic [NQ-1:0]           cq_publish,      // pulse: CQE visible
  output logic [NQ-1:0]           cq_pub_inflight, // phase word may already be host-visible (C2 phase)
  output logic [NQ-1:0]           cmd_ok_pulse,
  output logic [NQ-1:0]           cmd_err_pulse,
  output logic                    qfatal_valid,
  output logic [$clog2(NQ > 1 ? NQ : 2)-1:0] qfatal_q,
  output logic [7:0]              qfatal_code,
  output logic [63:0]             qfatal_addr,
  output logic                    frec_valid,
  output logic [63:0]             frec_addr,
  output logic [15:0]             frec_status,
  output logic [$clog2(NQ > 1 ? NQ : 2)-1:0] frec_q,

  // interrupt event
  output logic                    pub_valid,
  output logic [$clog2(NQ > 1 ? NQ : 2)-1:0] pub_q,
  output logic                    pub_irq,

  // authorisation windows (domain comes from the entry)
  input  logic [NW-1:0]           win_valid,
  input  logic [NW-1:0][63:0]     win_base,
  input  logic [NW-1:0][63:0]     win_size,
  input  logic [NW-1:0]           win_space,
  input  logic [NW-1:0]           win_r,
  input  logic [NW-1:0]           win_w,
  input  logic [NW-1:0][3:0]      win_dom,
  output logic [NW-1:0]           win_use,

  // fabric client R (host write)
  output logic                    rw_req_valid,
  output logic [63:0]             rw_req_addr,
  output logic [7:0]              rw_req_beats,
  input  logic                    rw_req_ack,
  output logic                    rw_w_valid,
  output logic [DATA_W-1:0]       rw_w_data,
  output logic [DATA_W/8-1:0]     rw_w_strb,
  input  logic                    rw_w_ready,
  input  logic                    rw_b_valid,
  input  logic                    rw_b_err,

  // status
  output logic                    busy,            // not IDLE
  output logic                    bus_active,      // a bus transaction is requested/in flight
  output logic                    blocked_cqfull,  // waiting on the host to release CQ slots
  output logic                    progress,
  output logic                    dbg_pub_valid,   // comb: phase word accepted on the bus (host-visible now)
  output logic [31:0]             dbg_pub_cmd_id
);
  import sfx_pkg::*;
  localparam int QW     = $clog2(NQ > 1 ? NQ : 2);
  localparam int BEAT   = DATA_W / 8;
  localparam int BLOG2  = $clog2(BEAT);
  localparam int CBEATS = 256 / DATA_W;
  localparam int PH_OFF  = (28 / BEAT) * BEAT;      // beat-aligned byte offset holding the phase word
  localparam int PH_LANE = 28 % BEAT;

  typedef enum logic [3:0] {
    RT_IDLE, RT_SIG_AUTH, RT_SIG_REQ, RT_SIG_W, RT_SIG_B,
    RT_CQ_WAIT, RT_CQ_AUTH,
    RT_C1_REQ, RT_C1_W, RT_C1_B, RT_C2_REQ, RT_C2_W, RT_C2_B
  } rt_t;
  rt_t           st;
  inf_t          e;
  logic [QW-1:0] eq;
  logic [7:0]    cnt;
  logic [NW-1:0] use_m;
  logic          use_v;

  assign eq = e.q[QW-1:0];

  // ---------------- per-entry ring arithmetic
  logic [31:0] tail, chead, occ, size32, slot_idx;
  logic [63:0] slot_addr;
  logic        cq_full, phase;
  logic [255:0] cqe;
  logic [31:0] lap;
  assign tail      = q_cq_tail[eq];
  assign chead     = q_cq_head[eq];
  assign occ       = tail - chead;
  assign size32    = 32'd1 << q_cq_log2[eq];
  assign cq_full   = (occ >= size32);
  assign slot_idx  = tail & (size32 - 32'd1);
  assign slot_addr = q_cq_base[eq] + ({32'b0, slot_idx} << SFX_CQE_LOG2);
  assign lap       = (tail - q_seq_start[eq]) >> q_cq_log2[eq];
  assign phase     = ~lap[0];             // lap 0 (first pass) -> phase 1
  assign cqe       = cqe_pack(e.cmd_id, e.seq, e.status, e.opcode, e.seq + 32'd1, e.result, tail, phase);

  // ---------------- authorisation (sequentially shared: signal write, then CQ slot)
  logic          az_wr_sig, az_ok;
  logic [NW-1:0] az_hit;
  logic [63:0]   az_addr;
  logic [31:0]   az_len;
  always_comb begin
    az_wr_sig = (st == RT_SIG_AUTH);
    az_addr   = az_wr_sig ? e.sig_addr : slot_addr;
    az_len    = az_wr_sig ? 32'd8 : 32'(SFX_CQE_BYTES);
  end
  sfx_authz #(.NW(NW)) u_az (
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom,
    .q_space(1'b0), .q_dom(e.domain), .q_addr(az_addr), .q_len(az_len), .q_wr(1'b1),
    .ok(az_ok), .hit(az_hit));

  // ---------------- write data generation
  logic [DATA_W-1:0]   sig_data, body_data, ph_data;
  logic [BEAT-1:0]     sig_strb, body_strb, ph_strb;
  logic [BLOG2-1:0]    sig_lane;
  assign sig_lane = e.sig_addr[BLOG2-1:0];
  assign sig_data = DATA_W'(e.sig_val) << ({sig_lane, 3'b000});
  assign sig_strb = BEAT'(8'hFF) << sig_lane;
  assign body_data = cqe[int'(cnt) * DATA_W +: DATA_W];
  always_comb begin
    for (int b = 0; b < BEAT; b++)
      body_strb[b] = ((int'(cnt) * BEAT + b) < 28);
  end
  assign ph_data = DATA_W'(cqe[255:224]) << (PH_LANE * 8);
  assign ph_strb = BEAT'(4'hF) << PH_LANE;

  // ---------------- outputs
  assign rw_req_valid = (st == RT_SIG_REQ) || (st == RT_C1_REQ) || (st == RT_C2_REQ);
  always_comb begin
    rw_req_addr  = slot_addr;
    rw_req_beats = 8'd1;
    unique case (st)
      RT_SIG_REQ: rw_req_addr = {e.sig_addr[63:BLOG2], {BLOG2{1'b0}}};
      RT_C1_REQ:  begin rw_req_addr = slot_addr; rw_req_beats = 8'(CBEATS); end
      RT_C2_REQ:  rw_req_addr = slot_addr + 64'(PH_OFF);
      default: ;
    endcase
    rw_w_valid = (st == RT_SIG_W) || (st == RT_C1_W) || (st == RT_C2_W);
    rw_w_data  = sig_data;
    rw_w_strb  = sig_strb;
    if (st == RT_C1_W) begin rw_w_data = body_data; rw_w_strb = body_strb; end
    if (st == RT_C2_W) begin rw_w_data = ph_data;   rw_w_strb = ph_strb;   end
  end

  assign dbg_pub_valid  = (st == RT_C2_W) && rw_w_ready;
  assign dbg_pub_cmd_id = e.cmd_id;
  assign win_use        = use_v ? use_m : '0;
  assign busy           = (st != RT_IDLE);
  assign bus_active     = (st == RT_SIG_REQ) || (st == RT_SIG_W) || (st == RT_SIG_B) ||
                          (st == RT_C1_REQ)  || (st == RT_C1_W)  || (st == RT_C1_B)  ||
                          (st == RT_C2_REQ)  || (st == RT_C2_W)  || (st == RT_C2_B);
  assign blocked_cqfull = (st == RT_CQ_WAIT) && cq_full;
  // From the moment the phase-word write is requested until the cq_publish pulse has been applied to
  // the counter, the host may legitimately have seen the entry: the CQ-head doorbell bound must count it.
  always_comb begin
    cq_pub_inflight = '0;
    if (st == RT_C2_REQ || st == RT_C2_W || st == RT_C2_B) cq_pub_inflight[eq] = 1'b1;
  end

  // ---------------- state machine
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= RT_IDLE; e <= '0; cnt <= '0; use_m <= '0; use_v <= 1'b0;
      pop <= 1'b0; cq_publish <= '0; cmd_ok_pulse <= '0; cmd_err_pulse <= '0;
      qfatal_valid <= 1'b0; qfatal_q <= '0; qfatal_code <= '0; qfatal_addr <= '0;
      frec_valid <= 1'b0; frec_addr <= '0; frec_status <= '0; frec_q <= '0;
      pub_valid <= 1'b0; pub_q <= '0; pub_irq <= 1'b0;
      progress <= 1'b0;
    end else begin
      pop <= 1'b0; cq_publish <= '0; cmd_ok_pulse <= '0; cmd_err_pulse <= '0;
      qfatal_valid <= 1'b0; frec_valid <= 1'b0; pub_valid <= 1'b0;
      progress <= 1'b0;

      unique case (st)
        RT_IDLE: if (head_valid && head_done && !quiesce && !pop) begin   // !pop: head not yet advanced
          e <= head;
          if (!q_pub_ok[head.q[QW-1:0]]) begin
            pop <= 1'b1;                       // queue is in ERROR / dropping: complete silently
            progress <= 1'b1;
          end else begin
            st <= head.sig_en ? RT_SIG_AUTH : RT_CQ_WAIT;
          end
        end

        RT_SIG_AUTH: begin
          if (quiesce) st <= RT_IDLE;
          else if (az_ok) begin
            use_m <= az_hit; use_v <= 1'b1;
            st <= RT_SIG_REQ;
          end else begin
            e.status <= SFX_ST_UNAUTHORIZED;
            frec_valid <= 1'b1; frec_addr <= e.sig_addr; frec_status <= SFX_ST_UNAUTHORIZED; frec_q <= eq;
            st <= RT_CQ_WAIT;
          end
        end
        RT_SIG_REQ: if (rw_req_ack) st <= RT_SIG_W;
        RT_SIG_W:   if (rw_w_ready) st <= RT_SIG_B;
        RT_SIG_B:   if (rw_b_valid) begin
          use_v <= 1'b0; progress <= 1'b1;
          if (rw_b_err) begin
            e.status <= SFX_ST_DMA_WRITE_ERR;
            frec_valid <= 1'b1; frec_addr <= e.sig_addr; frec_status <= SFX_ST_DMA_WRITE_ERR; frec_q <= eq;
          end
          st <= RT_CQ_WAIT;
        end

        RT_CQ_WAIT: begin
          if (quiesce) st <= RT_IDLE;
          else if (!q_pub_ok[eq]) begin pop <= 1'b1; st <= RT_IDLE; end
          else if (!cq_full) st <= RT_CQ_AUTH;
        end

        RT_CQ_AUTH: begin
          if (quiesce) st <= RT_IDLE;
          else if (az_ok) begin
            use_m <= az_hit; use_v <= 1'b1; cnt <= '0;
            st <= RT_C1_REQ;
          end else begin
            qfatal_valid <= 1'b1; qfatal_q <= eq; qfatal_code <= SFX_QERR_RING_UNAUTH;
            qfatal_addr <= slot_addr;
            pop <= 1'b1; st <= RT_IDLE;
          end
        end

        RT_C1_REQ: if (rw_req_ack) st <= RT_C1_W;
        RT_C1_W: if (rw_w_ready) begin
          cnt <= cnt + 8'd1;
          if (cnt == 8'(CBEATS - 1)) st <= RT_C1_B;
        end
        RT_C1_B: if (rw_b_valid) begin
          progress <= 1'b1;
          if (rw_b_err) begin
            use_v <= 1'b0;
            qfatal_valid <= 1'b1; qfatal_q <= eq; qfatal_code <= SFX_QERR_CQ_WRITE; qfatal_addr <= slot_addr;
            pop <= 1'b1; st <= RT_IDLE;
          end else begin
            st <= RT_C2_REQ;
          end
        end

        RT_C2_REQ: if (rw_req_ack) st <= RT_C2_W;
        RT_C2_W:   if (rw_w_ready) st <= RT_C2_B;
        RT_C2_B:   if (rw_b_valid) begin
          use_v <= 1'b0; progress <= 1'b1;
          if (rw_b_err) begin
            qfatal_valid <= 1'b1; qfatal_q <= eq; qfatal_code <= SFX_QERR_CQ_WRITE; qfatal_addr <= slot_addr;
          end else begin
            cq_publish[eq]     <= 1'b1;
            cmd_ok_pulse[eq]   <= (e.status == SFX_ST_OK);
            cmd_err_pulse[eq]  <= (e.status != SFX_ST_OK);
            pub_valid          <= 1'b1;
            pub_q              <= eq;
            pub_irq            <= ((e.flags & SFX_F_IRQ) != 16'd0);
          end
          pop <= 1'b1; st <= RT_IDLE;
        end

        default: st <= RT_IDLE;
      endcase
    end
  end
endmodule
