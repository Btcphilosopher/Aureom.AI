// In-flight command table (SPEC 7): allocation order == issue order == retire order.
module sfx_inflight #(
  parameter int DEPTH = 4,           // power of two
  parameter int NQ    = 2
) (
  input  logic                   clk,
  input  logic                   rst_n,

  // allocate at the tail
  input  logic                   alloc_valid,
  input  sfx_pkg::inf_t          alloc_data,
  input  logic                   alloc_done,
  output logic [$clog2(DEPTH)-1:0] alloc_idx,
  output logic                   full,
  output logic                   empty,

  // out-of-order completion from execution units
  input  logic                   cmp0_valid,       // DMA
  input  logic [$clog2(DEPTH)-1:0] cmp0_idx,
  input  logic [15:0]            cmp0_status,
  input  logic [63:0]            cmp0_result,
  input  logic                   cmp1_valid,       // kernel fabric
  input  logic [$clog2(DEPTH)-1:0] cmp1_idx,
  input  logic [15:0]            cmp1_status,
  input  logic [63:0]            cmp1_result,

  // oldest entry
  output logic                   head_valid,
  output logic                   head_done,
  output sfx_pkg::inf_t          head,
  input  logic                   pop,

  // summaries
  output logic                   fence_present,
  output logic [NQ-1:0]          q_busy,
  output logic [$clog2(DEPTH):0] kernel_pending
);
  import sfx_pkg::*;
  localparam int IW = $clog2(DEPTH);

  inf_t            ent   [DEPTH];
  logic [DEPTH-1:0] valid, done;
  logic [IW:0]     wr_ptr, rd_ptr;

  assign alloc_idx  = wr_ptr[IW-1:0];
  assign empty      = (wr_ptr == rd_ptr);
  assign full       = (wr_ptr - rd_ptr) == (IW+1)'(DEPTH);
  assign head_valid = !empty;
  assign head       = ent[rd_ptr[IW-1:0]];
  assign head_done  = done[rd_ptr[IW-1:0]];

  always_comb begin
    fence_present  = 1'b0;
    q_busy         = '0;
    kernel_pending = '0;
    for (int i = 0; i < DEPTH; i++) begin
      if (valid[i]) begin
        if (ent[i].opcode == SFX_OP_FENCE) fence_present = 1'b1;
        q_busy[ent[i].q[$clog2(NQ > 1 ? NQ : 2)-1:0]] = 1'b1;
        if (ent[i].is_kernel && !done[i]) kernel_pending = kernel_pending + 1'b1;
      end
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wr_ptr <= '0; rd_ptr <= '0; valid <= '0; done <= '0;
    end else begin
      if (alloc_valid && !full) begin
        ent[wr_ptr[IW-1:0]]   <= alloc_data;
        valid[wr_ptr[IW-1:0]] <= 1'b1;
        done[wr_ptr[IW-1:0]]  <= alloc_done;
        wr_ptr <= wr_ptr + 1'b1;
      end
      // a completion may only finish an entry of the matching kind (a faulty fabric tag cannot complete a COPY)
      if (cmp0_valid && valid[cmp0_idx] && !done[cmp0_idx] && !ent[cmp0_idx].is_kernel) begin
        ent[cmp0_idx].status <= cmp0_status;
        ent[cmp0_idx].result <= cmp0_result;
        done[cmp0_idx]       <= 1'b1;
      end
      if (cmp1_valid && valid[cmp1_idx] && !done[cmp1_idx] && ent[cmp1_idx].is_kernel) begin
        ent[cmp1_idx].status <= cmp1_status;
        ent[cmp1_idx].result <= cmp1_result;
        done[cmp1_idx]       <= 1'b1;
      end
      if (pop && !empty) begin
        valid[rd_ptr[IW-1:0]] <= 1'b0;
        done[rd_ptr[IW-1:0]]  <= 1'b0;
        rd_ptr <= rd_ptr + 1'b1;
      end
    end
  end
endmodule
