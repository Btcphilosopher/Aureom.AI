// AXI4 read-burst master port shared by NREQ requesters. One burst outstanding at a time.
//
// Requester protocol: hold req_valid/req_addr/req_beats until req_ack (1-cycle pulse, request
// consumed). Then beats arrive on rsp_valid[i] (no backpressure: RREADY is held high, so the
// requester MUST have reserved space for all beats before requesting).
// req_beats is 1..256. IDs are fixed at 0, INCR bursts, full-width beats.
module sfx_axi_rport #(
  parameter int NREQ   = 2,
  parameter int DATA_W = 64
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic [NREQ-1:0]           req_valid,
  input  logic [NREQ-1:0][63:0]     req_addr,
  input  logic [NREQ-1:0][7:0]      req_beats,
  output logic [NREQ-1:0]           req_ack,
  output logic [NREQ-1:0]           rsp_valid,
  output logic [DATA_W-1:0]         rsp_data,
  output logic                      rsp_last,
  output logic                      rsp_err,
  output logic                      idle,
  // AXI4 AR / R
  output logic [63:0]               araddr,
  output logic [7:0]                arlen,
  output logic [2:0]                arsize,
  output logic [1:0]                arburst,
  output logic                      arvalid,
  input  logic                      arready,
  input  logic [DATA_W-1:0]         rdata,
  input  logic [1:0]                rresp,
  input  logic                      rlast,
  input  logic                      rvalid,
  output logic                      rready
);
  localparam int OW = (NREQ > 1) ? $clog2(NREQ) : 1;
  typedef enum logic [1:0] {S_IDLE, S_AR, S_R} st_t;
  st_t st;
  logic [OW-1:0] owner, rr;

  assign arsize  = 3'($clog2(DATA_W / 8));
  assign arburst = 2'b01;

  // round-robin grant
  logic [OW-1:0] gsel;
  logic          gany;
  always_comb begin
    gany = 1'b0;
    gsel = '0;
    for (int k = 0; k < NREQ; k++) begin
      int idx;
      idx = (int'(rr) + k) % NREQ;
      if (!gany && req_valid[idx]) begin
        gany = 1'b1;
        gsel = OW'(idx);
      end
    end
  end

  always_comb begin
    req_ack = '0;
    if (st == S_IDLE && gany) req_ack[gsel] = 1'b1;
  end

  assign rready    = (st == S_R);
  assign rsp_data  = rdata;
  assign rsp_last  = rlast;
  assign rsp_err   = (rresp != 2'b00);
  always_comb begin
    rsp_valid = '0;
    if (st == S_R && rvalid) rsp_valid[owner] = 1'b1;
  end
  assign idle = (st == S_IDLE) && !(|req_valid);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; owner <= '0; rr <= '0;
      araddr <= '0; arlen <= '0; arvalid <= 1'b0;
    end else begin
      unique case (st)
        S_IDLE: if (gany) begin
          owner   <= gsel;
          araddr  <= req_addr[gsel];
          arlen   <= req_beats[gsel] - 8'd1;
          arvalid <= 1'b1;
          rr      <= OW'((int'(gsel) + 1) % NREQ);
          st      <= S_AR;
        end
        S_AR: if (arready) begin
          arvalid <= 1'b0;
          st      <= S_R;
        end
        S_R: if (rvalid && rlast) st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
