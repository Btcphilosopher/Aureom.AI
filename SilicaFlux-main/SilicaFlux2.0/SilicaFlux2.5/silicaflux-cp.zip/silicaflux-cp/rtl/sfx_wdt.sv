// Progress watchdog (SPEC 12). Counts clocks while armed with no progress.
module sfx_wdt (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        enable,            // WDT_CTRL.ENABLE
  input  logic [31:0] timeout,           // WDT_TIMEOUT (clocks)
  input  logic        armed_in,          // work outstanding and device RUNNING
  input  logic        progress,          // any forward progress this cycle
  output logic        armed,             // WDT_STATUS.ARMED
  output logic [31:0] count,
  output logic        expired            // single-cycle pulse
);
  assign armed = enable && (timeout != 32'd0) && armed_in;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      count   <= '0;
      expired <= 1'b0;
    end else begin
      expired <= 1'b0;
      if (!armed || progress) begin
        count <= '0;
      end else if (count + 32'd1 >= timeout) begin
        count   <= '0;
        expired <= 1'b1;
      end else begin
        count <= count + 32'd1;
      end
    end
  end
endmodule
