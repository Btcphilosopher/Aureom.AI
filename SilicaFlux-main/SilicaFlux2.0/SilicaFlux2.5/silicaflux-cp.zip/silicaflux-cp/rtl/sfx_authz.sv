// Combinational DMA authorisation lookup (SPEC 4).
// An access (space, domain, addr, len, perm) is authorised iff ONE valid window matches
// space and domain, grants the permission, and fully contains [addr, addr+len).
module sfx_authz #(
  parameter int NW = 8
) (
  input  logic [NW-1:0]        win_valid,
  input  logic [NW-1:0][63:0]  win_base,
  input  logic [NW-1:0][63:0]  win_size,
  input  logic [NW-1:0]        win_space,   // 0 host, 1 device
  input  logic [NW-1:0]        win_r,
  input  logic [NW-1:0]        win_w,
  input  logic [NW-1:0][3:0]   win_dom,
  // query
  input  logic                 q_space,
  input  logic [3:0]           q_dom,
  input  logic [63:0]          q_addr,
  input  logic [31:0]          q_len,       // > 0
  input  logic                 q_wr,        // 1 = needs W, 0 = needs R
  output logic                 ok,
  output logic [NW-1:0]        hit          // one-hot-ish: windows that authorise (use mask)
);
  logic [64:0] q_end;
  assign q_end = {1'b0, q_addr} + {33'b0, q_len};

  always_comb begin
    hit = '0;
    for (int i = 0; i < NW; i++) begin
      logic [64:0] w_end;
      w_end = {1'b0, win_base[i]} + {1'b0, win_size[i]};
      hit[i] = win_valid[i]
             && (win_space[i] == q_space)
             && (win_dom[i]   == q_dom)
             && (q_wr ? win_w[i] : win_r[i])
             && ({1'b0, q_addr} >= {1'b0, win_base[i]})
             && (q_end <= w_end);
    end
    ok = |hit;
  end
endmodule
