// SFX-CP core: command processor + DMA subsystem. The ports of this module ARE the transport
// contract (SPEC 14.1): AXI4-Lite slave, two AXI4 masters, interrupt levels, kernel dispatch.
// Everything that depends on how the host is actually connected lives in a transport wrapper.
module sfx_cp_core #(
  parameter int          NUM_QUEUES      = 2,                   // 1..4
  parameter int          NUM_WINDOWS     = 8,                   // 1..16
  parameter int          DATA_W          = 64,                  // 64 | 128 | 256
  parameter int          MAX_BURST_BEATS = 16,                  // power of two, <= 128
  parameter int          INFLIGHT_DEPTH  = 4,                   // 2, 4 or 8
  parameter logic [63:0] DEV_MEM_SIZE    = 64'h0100_0000,
  parameter int          HOST_ADDR_BITS  = 48,
  parameter int          NUM_VECTORS     = NUM_QUEUES + 1
) (
  input  logic                        clk,
  input  logic                        rst_n,

  // ---- AXI4-Lite slave: registers + doorbells
  input  logic [15:0]                 s_axil_awaddr,
  input  logic                        s_axil_awvalid,
  output logic                        s_axil_awready,
  input  logic [31:0]                 s_axil_wdata,
  input  logic [3:0]                  s_axil_wstrb,
  input  logic                        s_axil_wvalid,
  output logic                        s_axil_wready,
  output logic [1:0]                  s_axil_bresp,
  output logic                        s_axil_bvalid,
  input  logic                        s_axil_bready,
  input  logic [15:0]                 s_axil_araddr,
  input  logic                        s_axil_arvalid,
  output logic                        s_axil_arready,
  output logic [31:0]                 s_axil_rdata,
  output logic [1:0]                  s_axil_rresp,
  output logic                        s_axil_rvalid,
  input  logic                        s_axil_rready,

  // ---- AXI4 master: host IOVA space
  output logic [3:0]                  m_host_awid,
  output logic [63:0]                 m_host_awaddr,
  output logic [7:0]                  m_host_awlen,
  output logic [2:0]                  m_host_awsize,
  output logic [1:0]                  m_host_awburst,
  output logic                        m_host_awvalid,
  input  logic                        m_host_awready,
  output logic [DATA_W-1:0]           m_host_wdata,
  output logic [DATA_W/8-1:0]         m_host_wstrb,
  output logic                        m_host_wlast,
  output logic                        m_host_wvalid,
  input  logic                        m_host_wready,
  input  logic [3:0]                  m_host_bid,
  input  logic [1:0]                  m_host_bresp,
  input  logic                        m_host_bvalid,
  output logic                        m_host_bready,
  output logic [3:0]                  m_host_arid,
  output logic [63:0]                 m_host_araddr,
  output logic [7:0]                  m_host_arlen,
  output logic [2:0]                  m_host_arsize,
  output logic [1:0]                  m_host_arburst,
  output logic                        m_host_arvalid,
  input  logic                        m_host_arready,
  input  logic [3:0]                  m_host_rid,
  input  logic [DATA_W-1:0]           m_host_rdata,
  input  logic [1:0]                  m_host_rresp,
  input  logic                        m_host_rlast,
  input  logic                        m_host_rvalid,
  output logic                        m_host_rready,

  // ---- AXI4 master: device-local memory
  output logic [3:0]                  m_dev_awid,
  output logic [63:0]                 m_dev_awaddr,
  output logic [7:0]                  m_dev_awlen,
  output logic [2:0]                  m_dev_awsize,
  output logic [1:0]                  m_dev_awburst,
  output logic                        m_dev_awvalid,
  input  logic                        m_dev_awready,
  output logic [DATA_W-1:0]           m_dev_wdata,
  output logic [DATA_W/8-1:0]         m_dev_wstrb,
  output logic                        m_dev_wlast,
  output logic                        m_dev_wvalid,
  input  logic                        m_dev_wready,
  input  logic [3:0]                  m_dev_bid,
  input  logic [1:0]                  m_dev_bresp,
  input  logic                        m_dev_bvalid,
  output logic                        m_dev_bready,
  output logic [3:0]                  m_dev_arid,
  output logic [63:0]                 m_dev_araddr,
  output logic [7:0]                  m_dev_arlen,
  output logic [2:0]                  m_dev_arsize,
  output logic [1:0]                  m_dev_arburst,
  output logic                        m_dev_arvalid,
  input  logic                        m_dev_arready,
  input  logic [3:0]                  m_dev_rid,
  input  logic [DATA_W-1:0]           m_dev_rdata,
  input  logic [1:0]                  m_dev_rresp,
  input  logic                        m_dev_rlast,
  input  logic                        m_dev_rvalid,
  output logic                        m_dev_rready,

  // ---- interrupts (levels; transport converts edges to MSI-X / INTx)
  output logic [NUM_VECTORS-1:0]      irq_level,

  // ---- compute-fabric dispatch (SPEC 14.2)
  output logic                        kd_valid,
  input  logic                        kd_ready,
  output logic [$clog2(INFLIGHT_DEPTH)-1:0] kd_tag,
  output logic [31:0]                 kd_cmd_id,
  output logic [63:0]                 kd_kernel_addr,
  output logic [63:0]                 kd_args_addr,
  output logic [31:0]                 kd_args_size,
  output logic [31:0]                 kd_grid_x,
  output logic [31:0]                 kd_grid_y,
  output logic [31:0]                 kd_grid_z,
  output logic [3:0]                  kd_domain,
  input  logic                        kd_done_valid,
  input  logic [$clog2(INFLIGHT_DEPTH)-1:0] kd_done_tag,
  input  logic [1:0]                  kd_done_status,
  input  logic [63:0]                 kd_done_info,
  output logic                        kd_abort,
  input  logic                        kd_heartbeat,

  // ---- non-functional trace pulses (may be left unconnected)
  output logic                        dbg_issue_valid,
  output logic [31:0]                 dbg_issue_cmd_id,
  output logic                        dbg_dma_done_valid,
  output logic [31:0]                 dbg_dma_done_cmd_id,
  output logic                        dbg_pub_valid,
  output logic [31:0]                 dbg_pub_cmd_id,
  output logic                        dbg_fault,
  output logic                        dbg_resetting
);
  import sfx_pkg::*;

  localparam int NQ  = NUM_QUEUES;
  localparam int NW  = NUM_WINDOWS;
  localparam int NV  = NUM_VECTORS;
  localparam int QW  = $clog2(NQ > 1 ? NQ : 2);
  localparam int IW  = $clog2(INFLIGHT_DEPTH);

  // elaboration-time sanity (also caught by Verilator lint)
  if (DATA_W != 64 && DATA_W != 128 && DATA_W != 256) begin : g_chk_dw
    $error("DATA_W must be 64, 128 or 256");
  end
  if (NQ < 1 || NQ > 4) begin : g_chk_nq
    $error("NUM_QUEUES must be 1..4");
  end
  if (NW < 1 || NW > 16) begin : g_chk_nw
    $error("NUM_WINDOWS must be 1..16");
  end
  if (MAX_BURST_BEATS < 1 || MAX_BURST_BEATS > 128 || ((MAX_BURST_BEATS & (MAX_BURST_BEATS - 1)) != 0)) begin : g_chk_mb
    $error("MAX_BURST_BEATS must be a power of two <= 128");
  end
  if (INFLIGHT_DEPTH < 2 || INFLIGHT_DEPTH > 8 || ((INFLIGHT_DEPTH & (INFLIGHT_DEPTH - 1)) != 0)) begin : g_chk_id
    $error("INFLIGHT_DEPTH must be 2, 4 or 8 (GEOMETRY reports it in 4 bits)");
  end

  // =============================================================== resets
  logic soft_rst, quiesce, rst_busy, rst_snap, rst_done, rst_dto, rst_req;
  logic core_rst_n;
  assign core_rst_n = rst_n & ~soft_rst;

  // =============================================================== register bus
  logic        wr_en;
  logic [15:0] wr_addr, rd_addr;
  logic [31:0] wr_data, rd_data;
  logic [3:0]  wr_strb;

  sfx_axil_slave #(.AW(16)) u_axil (
    .clk, .rst_n,
    .awaddr(s_axil_awaddr), .awvalid(s_axil_awvalid), .awready(s_axil_awready),
    .wdata(s_axil_wdata), .wstrb(s_axil_wstrb), .wvalid(s_axil_wvalid), .wready(s_axil_wready),
    .bresp(s_axil_bresp), .bvalid(s_axil_bvalid), .bready(s_axil_bready),
    .araddr(s_axil_araddr), .arvalid(s_axil_arvalid), .arready(s_axil_arready),
    .rdata(s_axil_rdata), .rresp(s_axil_rresp), .rvalid(s_axil_rvalid), .rready(s_axil_rready),
    .wr_en, .wr_addr, .wr_data, .wr_strb, .rd_addr, .rd_data);

  // =============================================================== register file
  logic                     ctrl_enable, fault, core_idle;
  logic [NW-1:0]            win_valid, win_space, win_r, win_w, win_use;
  logic [NW-1:0][63:0]      win_base, win_size;
  logic [NW-1:0][3:0]       win_dom;
  logic [NQ-1:0]            q_enabled, q_pub_ok, sq_consume, cq_publish, cmd_ok_pulse, cmd_err_pulse;
  logic [NQ-1:0]            q_busy_all, qcpl_set, cq_pub_inflight;
  logic [NQ-1:0][63:0]      q_sq_base, q_cq_base;
  logic [NQ-1:0][4:0]       q_sq_log2, q_cq_log2;
  logic [NQ-1:0][3:0]       q_dom;
  logic [NQ-1:0][31:0]      q_sq_head, q_sq_tail, q_cq_head, q_cq_tail, q_seq_start;
  logic [NQ-1:0][15:0]      q_coal_cnt, q_coal_tmr;
  logic [NQ-1:0][2:0]       q_vector;
  logic                     qf_valid;
  logic [QW-1:0]            qf_q;
  logic [7:0]               qf_code;
  logic [63:0]              qf_addr;
  logic                     fr_valid;
  logic [63:0]              fr_addr;
  logic [15:0]              fr_status;
  logic [QW-1:0]            fr_q;
  logic [10:0]              irq_status, irq_enable;
  logic [2:0]               irq_misc;
  logic                     irq_blank;
  logic                     wdt_enable, wdt_expired, wdt_armed;
  logic [31:0]              wdt_timeout, wdt_count;
  logic [3:0]               wdt_stuck;
  logic [31:0]              rst_timeout;

  sfx_regs #(.NQ(NQ), .NW(NW), .NV(NV), .INFL(INFLIGHT_DEPTH), .DATA_W(DATA_W),
             .DEV_MEM_SIZE(DEV_MEM_SIZE), .HOST_ADDR_BITS(HOST_ADDR_BITS)) u_regs (
    .clk, .rst_n, .soft_rst,
    .wr_en, .wr_addr, .wr_data, .wr_strb, .rd_addr, .rd_data,
    .ctrl_enable, .fault, .core_idle,
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom, .win_use,
    .q_enabled, .q_pub_ok, .q_sq_base, .q_cq_base, .q_sq_log2, .q_cq_log2, .q_dom,
    .q_sq_head, .q_sq_tail, .q_cq_head, .q_cq_tail, .q_seq_start, .q_coal_cnt, .q_coal_tmr, .q_vector,
    .sq_consume, .cq_publish, .cq_pub_inflight, .cmd_ok_pulse, .cmd_err_pulse, .q_busy(q_busy_all),
    .qfatal_valid(qf_valid), .qfatal_q(qf_q), .qfatal_code(qf_code), .qfatal_addr(qf_addr),
    .frec_valid(fr_valid), .frec_addr(fr_addr), .frec_status(fr_status), .frec_q(fr_q),
    .qcpl_set, .irq_status_o(irq_status), .irq_enable_o(irq_enable),
    .irq_misc_vector_o(irq_misc), .irq_blank,
    .wdt_enable, .wdt_timeout, .wdt_expired, .wdt_count, .wdt_armed, .wdt_stuck,
    .rst_req, .rst_timeout, .rst_busy, .rst_done, .rst_drain_timeout(rst_dto), .snap(rst_snap));

  // =============================================================== frontend
  logic                       fe_qf_valid;
  logic [QW-1:0]              fe_qf_q;
  logic [7:0]                 fe_qf_code;
  logic [63:0]                fe_qf_addr;
  logic                       fe_fr_valid;
  logic [63:0]                fe_fr_addr;
  logic [QW-1:0]              fe_fr_q;
  logic [NW-1:0]              fe_win_use, dma_win_use, rt_win_use;
  logic                       f_req_valid, f_req_ack, f_rsp_valid, f_rsp_last, f_rsp_err;
  logic [63:0]                f_req_addr;
  logic [7:0]                 f_req_beats;
  logic [DATA_W-1:0]          f_rsp_data;
  logic                       alloc_valid, alloc_done, inf_full, inf_empty, fence_present;
  inf_t                       alloc_data;
  logic [IW-1:0]              alloc_idx;
  logic                       dma_cmd_valid, dma_cmd_ready, dma_cmd_src_dev, dma_cmd_dst_dev;
  logic [63:0]                dma_cmd_src, dma_cmd_dst;
  logic [31:0]                dma_cmd_len;
  logic [3:0]                 dma_cmd_dom;
  logic [IW-1:0]              dma_tag;
  logic [QW-1:0]              dma_q;
  logic                       fe_busy, fe_progress;
  logic [NQ-1:0]              fe_q_fetching;

  // CQ credit: commands consumed but whose completion the host has not released must fit in the CQ.
  // sq_head - cq_head counts them, so (sq_head - cq_head) < cq_size guarantees a slot for one more.
  logic [NQ-1:0] q_credit;
  always_comb
    for (int q = 0; q < NQ; q++)
      q_credit[q] = ((q_sq_head[q] - q_cq_head[q]) < (32'd1 << q_cq_log2[q]));

  logic run;
  assign run = ctrl_enable && !fault && !rst_busy;
  assign kd_abort = quiesce | fault;

  sfx_frontend #(.NQ(NQ), .NW(NW), .DATA_W(DATA_W), .DEPTH(INFLIGHT_DEPTH),
                 .DEV_MEM_SIZE(DEV_MEM_SIZE), .HOST_ADDR_BITS(HOST_ADDR_BITS)) u_fe (
    .clk, .rst_n(core_rst_n), .run, .quiesce,
    .q_enabled, .q_credit, .q_sq_base, .q_sq_log2, .q_dom, .q_sq_head, .q_sq_tail,
    .sq_consume,
    .qfatal_valid(fe_qf_valid), .qfatal_q(fe_qf_q), .qfatal_code(fe_qf_code), .qfatal_addr(fe_qf_addr),
    .frec_valid(fe_fr_valid), .frec_addr(fe_fr_addr), .frec_q(fe_fr_q),
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom, .win_use(fe_win_use),
    .f_req_valid, .f_req_addr, .f_req_beats, .f_req_ack,
    .f_rsp_valid, .f_rsp_data, .f_rsp_last, .f_rsp_err,
    .alloc_valid, .alloc_data, .alloc_done, .alloc_idx, .inf_full, .inf_empty, .fence_present,
    .dma_cmd_valid, .dma_cmd_ready, .dma_cmd_src_dev, .dma_cmd_dst_dev, .dma_cmd_src, .dma_cmd_dst,
    .dma_cmd_len, .dma_cmd_dom, .dma_tag, .dma_q,
    .kd_valid, .kd_ready, .kd_tag, .kd_cmd_id, .kd_kernel_addr, .kd_args_addr, .kd_args_size,
    .kd_grid_x, .kd_grid_y, .kd_grid_z, .kd_domain, .kd_abort,
    .busy(fe_busy), .q_fetching(fe_q_fetching), .progress(fe_progress),
    .dbg_issue_valid, .dbg_issue_cmd_id);

  // =============================================================== in-flight table
  logic                 dma_done_valid, dma_done_fault_valid, dma_busy, dma_progress;
  logic [15:0]          dma_done_status;
  logic [31:0]          dma_done_bytes;
  logic [63:0]          dma_done_fault_addr;
  logic [15:0]          cmp0_status, cmp1_status;
  logic                 head_valid, head_done, pop;
  inf_t                 head;
  logic [NQ-1:0]        inf_q_busy;
  logic [IW:0]          kernel_pending;

  // status mapping when an abort was caused by a watchdog fault rather than a reset
  assign cmp0_status = (dma_done_status == SFX_ST_ABORTED && fault) ? SFX_ST_TIMEOUT : dma_done_status;
  always_comb begin
    unique case (kd_done_status)
      SFX_KD_OK:      cmp1_status = SFX_ST_OK;
      SFX_KD_ABORTED: cmp1_status = fault ? SFX_ST_TIMEOUT : SFX_ST_ABORTED;
      default:        cmp1_status = SFX_ST_KERNEL_FAULT;
    endcase
  end

  sfx_inflight #(.DEPTH(INFLIGHT_DEPTH), .NQ(NQ)) u_inf (
    .clk, .rst_n(core_rst_n),
    .alloc_valid, .alloc_data, .alloc_done, .alloc_idx, .full(inf_full), .empty(inf_empty),
    .cmp0_valid(dma_done_valid), .cmp0_idx(dma_tag), .cmp0_status, .cmp0_result({32'b0, dma_done_bytes}),
    .cmp1_valid(kd_done_valid), .cmp1_idx(kd_done_tag), .cmp1_status, .cmp1_result(kd_done_info),
    .head_valid, .head_done, .head, .pop,
    .fence_present, .q_busy(inf_q_busy), .kernel_pending);

  assign q_busy_all = inf_q_busy | fe_q_fetching;

  // =============================================================== memory fabric + DMA
  logic                dr_req_valid, dr_req_dev, dr_req_ack, dr_rsp_valid, dr_rsp_last, dr_rsp_err;
  logic [63:0]         dr_req_addr;
  logic [7:0]          dr_req_beats;
  logic [DATA_W-1:0]   dr_rsp_data;
  logic                dw_req_valid, dw_req_dev, dw_req_ack, dw_w_valid, dw_w_ready, dw_b_valid, dw_b_err;
  logic [63:0]         dw_req_addr;
  logic [7:0]          dw_req_beats;
  logic [DATA_W-1:0]   dw_w_data;
  logic [DATA_W/8-1:0] dw_w_strb;
  logic                rw_req_valid, rw_req_ack, rw_w_valid, rw_w_ready, rw_b_valid, rw_b_err;
  logic [63:0]         rw_req_addr;
  logic [7:0]          rw_req_beats;
  logic [DATA_W-1:0]   rw_w_data;
  logic [DATA_W/8-1:0] rw_w_strb;
  logic                fabric_idle;

  sfx_mem_fabric #(.DATA_W(DATA_W)) u_fabric (
    .clk, .rst_n(core_rst_n), .idle(fabric_idle),
    .f_req_valid, .f_req_addr, .f_req_beats, .f_req_ack,
    .f_rsp_valid, .f_rsp_data, .f_rsp_last, .f_rsp_err,
    .dr_req_valid, .dr_req_dev, .dr_req_addr, .dr_req_beats, .dr_req_ack,
    .dr_rsp_valid, .dr_rsp_data, .dr_rsp_last, .dr_rsp_err,
    .dw_req_valid, .dw_req_dev, .dw_req_addr, .dw_req_beats, .dw_req_ack,
    .dw_w_valid, .dw_w_data, .dw_w_strb, .dw_w_ready, .dw_b_valid, .dw_b_err,
    .rw_req_valid, .rw_req_addr, .rw_req_beats, .rw_req_ack,
    .rw_w_valid, .rw_w_data, .rw_w_strb, .rw_w_ready, .rw_b_valid, .rw_b_err,
    .h_araddr(m_host_araddr), .h_arlen(m_host_arlen), .h_arsize(m_host_arsize), .h_arburst(m_host_arburst),
    .h_arvalid(m_host_arvalid), .h_arready(m_host_arready),
    .h_rdata(m_host_rdata), .h_rresp(m_host_rresp), .h_rlast(m_host_rlast), .h_rvalid(m_host_rvalid),
    .h_rready(m_host_rready),
    .h_awaddr(m_host_awaddr), .h_awlen(m_host_awlen), .h_awsize(m_host_awsize), .h_awburst(m_host_awburst),
    .h_awvalid(m_host_awvalid), .h_awready(m_host_awready),
    .h_wdata(m_host_wdata), .h_wstrb(m_host_wstrb), .h_wlast(m_host_wlast), .h_wvalid(m_host_wvalid),
    .h_wready(m_host_wready),
    .h_bresp(m_host_bresp), .h_bvalid(m_host_bvalid), .h_bready(m_host_bready),
    .d_araddr(m_dev_araddr), .d_arlen(m_dev_arlen), .d_arsize(m_dev_arsize), .d_arburst(m_dev_arburst),
    .d_arvalid(m_dev_arvalid), .d_arready(m_dev_arready),
    .d_rdata(m_dev_rdata), .d_rresp(m_dev_rresp), .d_rlast(m_dev_rlast), .d_rvalid(m_dev_rvalid),
    .d_rready(m_dev_rready),
    .d_awaddr(m_dev_awaddr), .d_awlen(m_dev_awlen), .d_awsize(m_dev_awsize), .d_awburst(m_dev_awburst),
    .d_awvalid(m_dev_awvalid), .d_awready(m_dev_awready),
    .d_wdata(m_dev_wdata), .d_wstrb(m_dev_wstrb), .d_wlast(m_dev_wlast), .d_wvalid(m_dev_wvalid),
    .d_wready(m_dev_wready),
    .d_bresp(m_dev_bresp), .d_bvalid(m_dev_bvalid), .d_bready(m_dev_bready));

  assign m_host_awid = '0;  assign m_host_arid = '0;
  assign m_dev_awid  = '0;  assign m_dev_arid  = '0;

  sfx_dma #(.DATA_W(DATA_W), .MAXB(MAX_BURST_BEATS), .NW(NW)) u_dma (
    .clk, .rst_n(core_rst_n), .halt_req(kd_abort),
    .cmd_valid(dma_cmd_valid), .cmd_ready(dma_cmd_ready),
    .cmd_src_dev(dma_cmd_src_dev), .cmd_dst_dev(dma_cmd_dst_dev),
    .cmd_src(dma_cmd_src), .cmd_dst(dma_cmd_dst), .cmd_len(dma_cmd_len), .cmd_dom(dma_cmd_dom),
    .done_valid(dma_done_valid), .done_status(dma_done_status), .done_bytes(dma_done_bytes),
    .done_fault_addr(dma_done_fault_addr), .done_fault_valid(dma_done_fault_valid),
    .busy(dma_busy), .win_use(dma_win_use), .progress(dma_progress),
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom,
    .dr_req_valid, .dr_req_dev, .dr_req_addr, .dr_req_beats, .dr_req_ack,
    .dr_rsp_valid, .dr_rsp_data, .dr_rsp_last, .dr_rsp_err,
    .dw_req_valid, .dw_req_dev, .dw_req_addr, .dw_req_beats, .dw_req_ack,
    .dw_w_valid, .dw_w_data, .dw_w_strb, .dw_w_ready, .dw_b_valid, .dw_b_err);

  // =============================================================== retire
  logic             rt_qf_valid, rt_fr_valid, rt_busy, rt_bus_active, rt_blocked, rt_progress;
  logic [QW-1:0]    rt_qf_q, rt_fr_q, pub_q;
  logic [7:0]       rt_qf_code;
  logic [63:0]      rt_qf_addr, rt_fr_addr;
  logic [15:0]      rt_fr_status;
  logic             pub_valid, pub_irq;

  sfx_retire #(.NQ(NQ), .NW(NW), .DATA_W(DATA_W)) u_rt (
    .clk, .rst_n(core_rst_n), .quiesce,
    .head_valid, .head_done, .head, .pop,
    .q_pub_ok, .q_cq_base, .q_cq_log2, .q_cq_head, .q_cq_tail, .q_seq_start,
    .cq_publish, .cq_pub_inflight, .cmd_ok_pulse, .cmd_err_pulse,
    .qfatal_valid(rt_qf_valid), .qfatal_q(rt_qf_q), .qfatal_code(rt_qf_code), .qfatal_addr(rt_qf_addr),
    .frec_valid(rt_fr_valid), .frec_addr(rt_fr_addr), .frec_status(rt_fr_status), .frec_q(rt_fr_q),
    .pub_valid, .pub_q, .pub_irq,
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom, .win_use(rt_win_use),
    .rw_req_valid, .rw_req_addr, .rw_req_beats, .rw_req_ack,
    .rw_w_valid, .rw_w_data, .rw_w_strb, .rw_w_ready, .rw_b_valid, .rw_b_err,
    .busy(rt_busy), .bus_active(rt_bus_active), .blocked_cqfull(rt_blocked), .progress(rt_progress),
    .dbg_pub_valid, .dbg_pub_cmd_id);

  assign win_use = fe_win_use | dma_win_use | rt_win_use;

  // =============================================================== fatal / fault-record arbitration
  // Two sources can report a queue-fatal error in the same cycle; neither may be lost, so each
  // is latched until delivered (one per cycle, retire first).
  logic          fe_pend, rt_pend;
  logic [QW-1:0] fe_pq, rt_pq;
  logic [7:0]    fe_pc, rt_pc;
  logic [63:0]   fe_pa, rt_pa;
  always_ff @(posedge clk or negedge core_rst_n) begin
    if (!core_rst_n) begin
      fe_pend <= 1'b0; rt_pend <= 1'b0;
      fe_pq <= '0; rt_pq <= '0; fe_pc <= '0; rt_pc <= '0; fe_pa <= '0; rt_pa <= '0;
    end else begin
      // retire's event is delivered the cycle after it is latched; the frontend's waits one more
      // cycle if retire's is being delivered at the same time.
      rt_pend <= rt_qf_valid;
      fe_pend <= fe_qf_valid | (fe_pend & rt_pend);
      if (fe_qf_valid) begin fe_pq <= fe_qf_q; fe_pc <= fe_qf_code; fe_pa <= fe_qf_addr; end
      if (rt_qf_valid) begin rt_pq <= rt_qf_q; rt_pc <= rt_qf_code; rt_pa <= rt_qf_addr; end
    end
  end
  always_comb begin
    qf_valid = 1'b0; qf_q = '0; qf_code = '0; qf_addr = '0;
    if (rt_pend)      begin qf_valid = 1'b1; qf_q = rt_pq; qf_code = rt_pc; qf_addr = rt_pa; end
    else if (fe_pend) begin qf_valid = 1'b1; qf_q = fe_pq; qf_code = fe_pc; qf_addr = fe_pa; end
  end

  // fault records are diagnostic only: fixed priority, collisions drop the lower-priority record
  always_comb begin
    fr_valid = 1'b0; fr_addr = '0; fr_status = '0; fr_q = '0;
    if (dma_done_valid && dma_done_fault_valid) begin
      fr_valid = 1'b1; fr_addr = dma_done_fault_addr; fr_status = dma_done_status; fr_q = dma_q;
    end else if (rt_fr_valid) begin
      fr_valid = 1'b1; fr_addr = rt_fr_addr; fr_status = rt_fr_status; fr_q = rt_fr_q;
    end else if (fe_fr_valid) begin
      fr_valid = 1'b1; fr_addr = fe_fr_addr; fr_status = SFX_ST_UNAUTHORIZED; fr_q = fe_fr_q;
    end
  end

  // =============================================================== interrupts
  sfx_irq #(.NQ(NQ), .NV(NV)) u_irq (
    .clk, .rst_n(core_rst_n),
    .pub_valid, .pub_q, .pub_irq,
    .q_enabled, .q_coal_cnt, .q_coal_tmr, .qcpl_set,
    .status(irq_status), .enable(irq_enable), .q_vector, .misc_vector(irq_misc),
    .blank(irq_blank), .irq_level);

  // =============================================================== watchdog
  logic queue_pending, wdt_progress, wdt_armed_in;
  always_comb begin
    queue_pending = 1'b0;
    for (int q = 0; q < NQ; q++)
      if (q_enabled[q] && q_credit[q] && (q_sq_tail[q] != q_sq_head[q])) queue_pending = 1'b1;
  end
  assign wdt_progress = fe_progress | dma_progress | rt_progress | kd_done_valid | kd_heartbeat | dma_done_valid;
  assign wdt_armed_in = !fault && !rst_busy &&
                        ((ctrl_enable && queue_pending) || fe_busy || !inf_empty || rt_busy) &&
                        !rt_blocked;
  assign wdt_stuck    = {rt_busy, (kernel_pending != '0), dma_busy, fe_busy};

  sfx_wdt u_wdt (
    .clk, .rst_n(core_rst_n),
    .enable(wdt_enable), .timeout(wdt_timeout), .armed_in(wdt_armed_in), .progress(wdt_progress),
    .armed(wdt_armed), .count(wdt_count), .expired(wdt_expired));

  // =============================================================== controlled reset
  logic all_idle;
  assign all_idle = fabric_idle && !dma_busy && (kernel_pending == '0) && !rt_bus_active;
  assign core_idle = !fe_busy && inf_empty && !rt_busy;

  sfx_reset_ctl u_rst (
    .clk, .rst_n, .req(rst_req), .timeout(rst_timeout), .all_idle,
    .quiesce, .soft_rst, .busy(rst_busy), .snap(rst_snap), .done(rst_done), .drain_timeout(rst_dto));

  // =============================================================== trace pulses
  logic [31:0] dma_cid;
  always_ff @(posedge clk or negedge core_rst_n) begin
    if (!core_rst_n) dma_cid <= '0;
    else if (dma_cmd_valid && dma_cmd_ready) dma_cid <= dbg_issue_cmd_id;
  end
  assign dbg_dma_done_valid  = dma_done_valid;
  assign dbg_dma_done_cmd_id = dma_cid;
  assign dbg_fault           = fault;
  assign dbg_resetting       = rst_busy;

  // unused-by-design inputs
  logic unused_ok;
  assign unused_ok = &{1'b0, m_host_bid, m_host_rid, m_dev_bid, m_dev_rid, dma_done_fault_addr[0]};
endmodule
