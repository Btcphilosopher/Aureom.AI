// Interrupt block (SPEC 11): per-queue completion coalescing and cause->vector level mapping.
// The status/enable registers themselves live in sfx_regs; this block turns published
// completions into QCPL cause pulses and turns (status & enable) into one level per vector.
module sfx_irq #(
  parameter int NQ = 2,
  parameter int NV = 3                       // NQ + 1
) (
  input  logic                    clk,
  input  logic                    rst_n,

  // completion events (after the phase word's write response -- SPEC D4)
  input  logic                    pub_valid,
  input  logic [$clog2(NQ > 1 ? NQ : 2)-1:0] pub_q,
  input  logic                    pub_irq,

  // per-queue coalescing config
  input  logic [NQ-1:0]           q_enabled,         // coalescing state is held clear while not ENABLED
  input  logic [NQ-1:0][15:0]     q_coal_cnt,
  input  logic [NQ-1:0][15:0]     q_coal_tmr,
  output logic [NQ-1:0]           qcpl_set,

  // level generation
  input  logic [10:0]             status,
  input  logic [10:0]             enable,
  input  logic [NQ-1:0][2:0]      q_vector,
  input  logic [2:0]              misc_vector,
  input  logic                    blank,
  output logic [NV-1:0]           irq_level
);
  import sfx_pkg::*;
  localparam int TU = SFX_TIMER_UNIT;

  // ---------------- coalescing
  logic [15:0] cnt    [NQ];
  logic [15:0] tmr    [NQ];
  logic        tmr_on [NQ];
  logic [$clog2(TU)-1:0] pre;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pre <= '0; qcpl_set <= '0;
      for (int q = 0; q < NQ; q++) begin cnt[q] <= '0; tmr[q] <= '0; tmr_on[q] <= 1'b0; end
    end else begin
      qcpl_set <= '0;
      pre <= pre + 1'b1;
      // timers advance once per TIMER_UNIT clocks
      for (int q = 0; q < NQ; q++) begin
        // The prescaler free-runs, so the first tick after the timer starts arrives within one unit; firing
        // on the (T+1)th tick guarantees at least T*TIMER_UNIT clocks (and fewer than (T+1)*TIMER_UNIT).
        if (tmr_on[q] && (pre == '1)) begin
          if (tmr[q] >= q_coal_tmr[q]) begin
            qcpl_set[q] <= 1'b1; tmr_on[q] <= 1'b0; cnt[q] <= '0; tmr[q] <= '0;
          end else begin
            tmr[q] <= tmr[q] + 16'd1;
          end
        end
      end
      if (pub_valid) begin
        if (pub_irq) begin
          qcpl_set[pub_q] <= 1'b1; tmr_on[pub_q] <= 1'b0; cnt[pub_q] <= '0; tmr[pub_q] <= '0;
        end else begin
          if (q_coal_cnt[pub_q] != 16'd0 && (cnt[pub_q] + 16'd1) >= q_coal_cnt[pub_q]) begin
            qcpl_set[pub_q] <= 1'b1; tmr_on[pub_q] <= 1'b0; cnt[pub_q] <= '0; tmr[pub_q] <= '0;
          end else begin
            cnt[pub_q] <= cnt[pub_q] + 16'd1;
            if (q_coal_tmr[pub_q] != 16'd0 && !tmr_on[pub_q]) begin
              tmr_on[pub_q] <= 1'b1; tmr[pub_q] <= '0;
            end
          end
        end
      end
      // no stale count/timer may survive a queue being disabled, so a re-enabled queue starts clean
      for (int q = 0; q < NQ; q++)
        if (!q_enabled[q]) begin cnt[q] <= '0; tmr[q] <= '0; tmr_on[q] <= 1'b0; end
    end
  end

  // ---------------- cause -> vector levels
  logic [10:0] act;
  assign act = status & enable;
  always_comb begin
    irq_level = '0;
    for (int v = 0; v < NV; v++) begin
      for (int q = 0; q < NQ; q++)
        if (act[SFX_IRQ_QCPL_LSB + q] && int'(q_vector[q]) == v) irq_level[v] = 1'b1;
      // every non-completion cause uses the misc vector
      if ((act & ~11'((1 << NQ) - 1)) != 11'd0 && int'(misc_vector) == v) irq_level[v] = 1'b1;
    end
    if (blank) irq_level = '0;
  end
endmodule
