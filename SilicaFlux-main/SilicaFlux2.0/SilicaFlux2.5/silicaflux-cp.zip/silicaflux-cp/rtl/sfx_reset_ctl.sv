// Controlled-reset sequencer (SPEC 13).
//   IDLE --req--> DRAIN (quiesce, wait all_idle for >=4 stable cycles, or time out)
//        DRAIN --idle--> SNAP (1 cycle) --> RST (soft_rst for 6 cycles) --> DONE (pulse) --> IDLE
//        DRAIN --timeout--> STUCK  (stays quiesced until hard reset; drain_timeout latched)
// timeout == 0 disables the timeout (wait forever).
// Only the hard reset (rst_n) resets this block, so it survives the soft reset it produces.
module sfx_reset_ctl (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        req,               // single-cycle pulse (already key-checked)
  input  logic [31:0] timeout,
  input  logic        all_idle,
  output logic        quiesce,           // level
  output logic        soft_rst,          // level
  output logic        busy,              // RESETTING
  output logic        snap,              // pulse: capture queue counters now
  output logic        done,              // pulse
  output logic        drain_timeout      // latched until next request
);
  typedef enum logic [2:0] {S_IDLE, S_DRAIN, S_SNAP, S_RST, S_DONE, S_STUCK} st_t;
  st_t         st;
  logic [31:0] wait_cnt;
  logic [2:0]  stable;
  logic [2:0]  rst_cnt;

  assign quiesce  = (st == S_DRAIN) || (st == S_SNAP) || (st == S_STUCK);
  assign soft_rst = (st == S_RST);
  assign busy     = (st != S_IDLE);
  assign snap     = (st == S_SNAP);
  assign done     = (st == S_DONE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; wait_cnt <= '0; stable <= '0; rst_cnt <= '0; drain_timeout <= 1'b0;
    end else begin
      unique case (st)
        S_IDLE: if (req) begin
          st <= S_DRAIN; wait_cnt <= '0; stable <= '0; drain_timeout <= 1'b0;
        end
        S_DRAIN: begin
          wait_cnt <= wait_cnt + 32'd1;
          stable   <= all_idle ? ((stable == 3'd7) ? stable : stable + 3'd1) : 3'd0;
          if (all_idle && stable >= 3'd4) begin
            st <= S_SNAP;
          end else if (timeout != 32'd0 && wait_cnt >= timeout) begin
            drain_timeout <= 1'b1;
            st <= S_STUCK;
          end
        end
        S_SNAP: begin st <= S_RST; rst_cnt <= '0; end
        S_RST: begin
          rst_cnt <= rst_cnt + 3'd1;
          if (rst_cnt == 3'd5) st <= S_DONE;
        end
        S_DONE: st <= S_IDLE;
        S_STUCK: ;                       // only a hard reset leaves this state
        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
