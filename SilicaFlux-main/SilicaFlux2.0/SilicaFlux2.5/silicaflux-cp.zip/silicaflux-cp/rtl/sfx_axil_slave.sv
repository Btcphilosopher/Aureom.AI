// AXI4-Lite slave -> simple register bus.
// AW and W may arrive in either order. One write or read is processed at a time.
// Always responds OKAY (see SPEC 3: an AXI error response can become a fatal host fault).
module sfx_axil_slave #(
  parameter int AW = 16
) (
  input  logic          clk,
  input  logic          rst_n,
  // AXI4-Lite
  input  logic [AW-1:0] awaddr,
  input  logic          awvalid,
  output logic          awready,
  input  logic [31:0]   wdata,
  input  logic [3:0]    wstrb,
  input  logic          wvalid,
  output logic          wready,
  output logic [1:0]    bresp,
  output logic          bvalid,
  input  logic          bready,
  input  logic [AW-1:0] araddr,
  input  logic          arvalid,
  output logic          arready,
  output logic [31:0]   rdata,
  output logic [1:0]    rresp,
  output logic          rvalid,
  input  logic          rready,
  // register bus (single-cycle strobes)
  output logic          wr_en,
  output logic [AW-1:0] wr_addr,
  output logic [31:0]   wr_data,
  output logic [3:0]    wr_strb,
  output logic [AW-1:0] rd_addr,
  input  logic [31:0]   rd_data      // combinational function of rd_addr
);
  logic          aw_got, w_got, ar_got;
  logic [AW-1:0] aw_q, ar_q;
  logic [31:0]   w_q;
  logic [3:0]    ws_q;

  assign bresp   = 2'b00;
  assign rresp   = 2'b00;
  assign awready = ~aw_got & ~bvalid;
  assign wready  = ~w_got  & ~bvalid;
  assign arready = ~ar_got & ~rvalid;

  assign wr_en   = aw_got & w_got & ~bvalid;
  assign wr_addr = aw_q;
  assign wr_data = w_q;
  assign wr_strb = ws_q;
  assign rd_addr = ar_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      aw_got <= 1'b0; w_got <= 1'b0; ar_got <= 1'b0;
      bvalid <= 1'b0; rvalid <= 1'b0;
      aw_q <= '0; ar_q <= '0; w_q <= '0; ws_q <= '0; rdata <= '0;
    end else begin
      // write channel
      if (awvalid && awready) begin aw_got <= 1'b1; aw_q <= awaddr; end
      if (wvalid  && wready)  begin w_got  <= 1'b1; w_q  <= wdata; ws_q <= wstrb; end
      if (wr_en) begin
        aw_got <= 1'b0; w_got <= 1'b0; bvalid <= 1'b1;
      end
      if (bvalid && bready) bvalid <= 1'b0;
      // read channel
      if (arvalid && arready) begin ar_got <= 1'b1; ar_q <= araddr; end
      if (ar_got && !rvalid) begin
        ar_got <= 1'b0; rvalid <= 1'b1; rdata <= rd_data;
      end
      if (rvalid && rready) rvalid <= 1'b0;
    end
  end
endmodule
