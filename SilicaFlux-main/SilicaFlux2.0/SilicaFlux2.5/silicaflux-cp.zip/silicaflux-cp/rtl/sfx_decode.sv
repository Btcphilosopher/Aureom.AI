// Descriptor decode + validation (SPEC 5.1, 5.5). Purely combinational.
// Status precedence is normative: version > opcode > flags > must-be-zero > op-specific
// (length > alignment > range > authorisation).  Sequence mismatch is reported separately
// (it is queue-fatal, not a per-command status).
module sfx_decode #(
  parameter int                 DATA_W         = 64,
  parameter int                 NW             = 8,
  parameter logic [63:0]        DEV_MEM_SIZE   = 64'h0100_0000,
  parameter int                 HOST_ADDR_BITS = 48
) (
  input  logic [511:0]          desc,
  input  logic [31:0]           exp_seq,
  input  logic [3:0]            dom,

  // authorisation windows
  input  logic [NW-1:0]         win_valid,
  input  logic [NW-1:0][63:0]   win_base,
  input  logic [NW-1:0][63:0]   win_size,
  input  logic [NW-1:0]         win_space,
  input  logic [NW-1:0]         win_r,
  input  logic [NW-1:0]         win_w,
  input  logic [NW-1:0][3:0]    win_dom,

  // decoded fields
  output logic [15:0]           opcode,
  output logic [15:0]           flags,
  output logic [31:0]           cmd_id,
  output logic [63:0]           addr0,
  output logic [63:0]           addr1,
  output logic [31:0]           length,
  output logic [31:0]           grid_x, grid_y, grid_z,
  output logic [63:0]           value,
  // results
  output logic                  seq_ok,
  output logic [15:0]           status,
  output logic                  is_nop, is_copy, is_kernel, is_fence,
  output logic                  src_dev, dst_dev,        // COPY address spaces
  output logic                  sig_en,                  // FENCE with signal (valid)
  output logic [63:0]           unauth_addr              // first unauthorised operand (for fault record)
);
  import sfx_pkg::*;
  localparam int BLOG2 = $clog2(DATA_W / 8);

  logic [15:0] ver, rsvd0;
  logic [63:0] rsvd1;
  assign opcode = desc[15:0];
  assign flags  = desc[31:16];
  assign cmd_id = desc[95:64];
  assign ver    = desc[111:96];
  assign rsvd0  = desc[127:112];
  assign addr0  = desc[191:128];
  assign addr1  = desc[255:192];
  assign length = desc[287:256];
  assign grid_x = desc[319:288];
  assign grid_y = desc[351:320];
  assign grid_z = desc[383:352];
  assign value  = desc[447:384];
  assign rsvd1  = desc[511:448];
  assign seq_ok = (desc[63:32] == exp_seq);

  logic is_h2d, is_d2h, is_d2d, known, f_sig;
  assign is_nop    = (opcode == SFX_OP_NOP);
  assign is_h2d    = (opcode == SFX_OP_COPY_H2D);
  assign is_d2h    = (opcode == SFX_OP_COPY_D2H);
  assign is_d2d    = (opcode == SFX_OP_COPY_D2D);
  assign is_copy   = is_h2d | is_d2h | is_d2d;
  assign is_kernel = (opcode == SFX_OP_KERNEL);
  assign is_fence  = (opcode == SFX_OP_FENCE);
  assign known     = is_nop | is_copy | is_kernel | is_fence;
  assign f_sig     = (flags & SFX_F_FENCE_SIGNAL) != 16'd0;
  assign src_dev   = is_d2h | is_d2d;
  assign dst_dev   = is_h2d | is_d2d;

  // ---------------- must-be-zero checks
  logic aux_nz, mbz_bad;
  assign aux_nz = (grid_x != 0) || (grid_y != 0) || (grid_z != 0);
  always_comb begin
    mbz_bad = (rsvd0 != 0) || (rsvd1 != 0);
    if (is_nop)    mbz_bad |= (addr0 != 0) || (addr1 != 0) || (length != 0) || aux_nz || (value != 0);
    if (is_copy)   mbz_bad |= aux_nz || (value != 0);
    if (is_kernel) mbz_bad |= (value != 0);
    if (is_fence)  mbz_bad |= (addr1 != 0) || (length != 0) || aux_nz ||
                              (!f_sig && ((addr0 != 0) || (value != 0)));
  end

  // ---------------- operand queries (two shared authorisation lookups)
  //   A: COPY source (R)        | KERNEL entry point (8 B, R, dev) | FENCE signal (8 B, W, host)
  //   B: COPY destination (W)   | KERNEL argument block (R, dev)
  logic        qa_space, qb_space, qa_wr, qb_wr;
  logic [31:0] qa_len, qb_len;
  logic        a_active, b_active;
  always_comb begin
    qa_space = src_dev; qb_space = dst_dev;
    qa_wr = 1'b0;       qb_wr = 1'b1;
    qa_len = length;    qb_len = length;
    a_active = 1'b1;    b_active = 1'b1;
    if (is_kernel) begin
      qa_space = 1'b1; qb_space = 1'b1; qa_wr = 1'b0; qb_wr = 1'b0;
      qa_len = 32'd8;  qb_len = length;
      b_active = (length != 0);
    end else if (is_fence) begin
      qa_space = 1'b0; qa_wr = 1'b1; qa_len = 32'd8;
      b_active = 1'b0;
    end
  end

  logic a_ok, b_ok;
  logic [NW-1:0] a_hit, b_hit;
  sfx_authz #(.NW(NW)) u_az_a (
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom,
    .q_space(qa_space), .q_dom(dom), .q_addr(addr0), .q_len((qa_len == 0) ? 32'd1 : qa_len),
    .q_wr(qa_wr), .ok(a_ok), .hit(a_hit));
  sfx_authz #(.NW(NW)) u_az_b (
    .win_valid, .win_base, .win_size, .win_space, .win_r, .win_w, .win_dom,
    .q_space(qb_space), .q_dom(dom), .q_addr(addr1), .q_len((qb_len == 0) ? 32'd1 : qb_len),
    .q_wr(qb_wr), .ok(b_ok), .hit(b_hit));

  // ---------------- range checks (supported address spaces, no wrap)
  logic [64:0] host_lim, dev_lim, a_end, b_end;
  logic        a_range_bad, b_range_bad;
  assign host_lim = 65'd1 << HOST_ADDR_BITS;
  assign dev_lim  = {1'b0, DEV_MEM_SIZE};
  assign a_end    = {1'b0, addr0} + {33'b0, qa_len};
  assign b_end    = {1'b0, addr1} + {33'b0, qb_len};
  assign a_range_bad = a_active && (a_end > (qa_space ? dev_lim : host_lim));
  assign b_range_bad = b_active && (b_end > (qb_space ? dev_lim : host_lim));

  // ---------------- alignment
  logic copy_align_bad, k_align_bad, f_align_bad;
  assign copy_align_bad = (addr0[BLOG2-1:0] != '0) || (addr1[BLOG2-1:0] != '0);
  assign k_align_bad    = (addr0[2:0] != 3'd0) || (addr1[2:0] != 3'd0);
  assign f_align_bad    = (addr0[2:0] != 3'd0);

  // ---------------- precedence chain
  logic copy_len_bad, k_grid_bad, k_argsdesc_bad, k_len_bad, auth_bad;
  assign copy_len_bad   = (length == 0) || (length > SFX_MAX_COPY_BYTES) || (length[BLOG2-1:0] != '0);
  assign k_grid_bad     = (grid_x == 0) || (grid_x > SFX_MAX_GRID_DIM) ||
                          (grid_y == 0) || (grid_y > SFX_MAX_GRID_DIM) ||
                          (grid_z == 0) || (grid_z > SFX_MAX_GRID_DIM);
  assign k_argsdesc_bad = (length == 0) && (addr1 != 0);
  assign k_len_bad      = (length > SFX_MAX_ARGS_BYTES) || (length[2:0] != 3'd0);
  assign auth_bad       = (a_active && !a_ok) || (b_active && !b_ok);
  assign unauth_addr    = (a_active && !a_ok) ? addr0 : addr1;

  assign sig_en = is_fence && f_sig && (status == SFX_ST_OK);

  always_comb begin
    status = SFX_ST_OK;
    if (ver != 16'(SFX_DESC_VERSION))                         status = SFX_ST_BAD_VERSION;
    else if (!known)                                          status = SFX_ST_BAD_OPCODE;
    else if (((flags & ~SFX_F_VALID_MASK) != 16'd0) ||
             (!is_fence && ((flags & (SFX_F_FENCE_SCOPE_ALL | SFX_F_FENCE_SIGNAL)) != 16'd0)))
                                                              status = SFX_ST_BAD_FLAGS;
    else if (mbz_bad)                                         status = SFX_ST_BAD_DESC;
    else if (is_copy) begin
      if (copy_len_bad)                                       status = SFX_ST_BAD_LENGTH;
      else if (copy_align_bad)                                status = SFX_ST_BAD_ALIGN;
      else if (a_range_bad || b_range_bad)                    status = SFX_ST_BAD_RANGE;
      else if (auth_bad)                                      status = SFX_ST_UNAUTHORIZED;
    end else if (is_kernel) begin
      if (k_grid_bad || k_argsdesc_bad)                       status = SFX_ST_BAD_DESC;
      else if (k_len_bad)                                     status = SFX_ST_BAD_LENGTH;
      else if (k_align_bad)                                   status = SFX_ST_BAD_ALIGN;
      else if (a_range_bad || b_range_bad)                    status = SFX_ST_BAD_RANGE;
      else if (auth_bad)                                      status = SFX_ST_UNAUTHORIZED;
    end else if (is_fence && f_sig) begin
      if (f_align_bad)                                        status = SFX_ST_BAD_ALIGN;
      else if (a_range_bad)                                   status = SFX_ST_BAD_RANGE;
      else if (auth_bad)                                      status = SFX_ST_UNAUTHORIZED;
    end
  end
endmodule
