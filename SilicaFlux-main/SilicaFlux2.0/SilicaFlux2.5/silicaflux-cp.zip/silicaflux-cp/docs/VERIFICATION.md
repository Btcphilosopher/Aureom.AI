# Verification report

Everything here is **simulation evidence from Verilator (two-state) and a C++ model**. There is no formal proof, no hardware, no vendor
endpoint IP, and no PCIe. Read §5 before relying on any of it.

## 1. What is run, and the results of the final run

| Check | Command | Result |
|---|---|---|
| Generated files up to date | `make check-gen` | pass |
| Lint, 3 parameter sets + sim wrapper | `make lint` | clean apart from waived cosmetic classes (`DESIGN_NOTES.md` §5) |
| Software model + shared suite | `make test-model` | 71 tests pass (also clean under ASan/UBSan, `make test-model-asan`) |
| RTL, default geometry (64-bit, 2 queues, 8 windows, burst 16, depth 4) | `make test-rtl` | 74 tests × 3 bus profiles = **222 runs pass** |
| RTL, 256-bit / 4 queues / 16 windows / burst 32 / depth 8 | `make test-rtl-matrix` | 222 runs pass |
| RTL, 128-bit / 1 queue / 4 windows / burst 8 / depth 2 | `make test-rtl-matrix` | 198 pass, 24 skipped (tests that need ≥ 2 queues, or more windows than the geometry has, skip by design) |
| Model ≡ RTL | `make test-diff` | six seeded random programs × three bus profiles: statuses and final memory digests identical |
| Seed soak | loop over `--seed` for `stall` and `latency` (command in §7) | 4440 test runs over 60 (seed, profile) combinations, 0 failures |
| Endpoint wrapper | `make test-ep` | pass |
| RTL line-block coverage | `make coverage-rtl` | 277 / 277 blocks executed (`COVERAGE.md`) |
| Mutation sanity | `make mutation` | **29 of 29** injected RTL bugs caught (§4, `MUTATION_RESULTS.md`) |

"74 tests" = the 71 shared tests plus 3 RTL-only tests (`tests/t_rtl_only.cpp`: partial-strobe/unaligned AXI-Lite writes, unmapped
space, partial-strobe doorbells).

## 2. How the tests work

* **One suite, two targets.** `tests/` is written against the abstract `sfx::Target` (MMIO, time, interrupt level, host/device memory,
  fault injection, a kernel-fabric hook, an event log). `sfx::ModelTarget` implements it in software; `sfx::RtlTarget` (`sim/`) implements it
  on the Verilated core with cycle-accurate AXI bus-functional models.
* **Timing-independent assertions.** Tests wait on conditions and assert *partial orders* between events (e.g. "the kernel was issued
  before the copy's completion became visible"), never absolute times, so they hold on a tick-based model and on cycle-accurate RTL
  alike.
* **Three bus profiles** for the RTL: `ideal` (no stalls), `stall` (random ready/valid back-pressure), `latency` (multi-cycle response
  latency). Several real bugs only appeared under `stall`/`latency`.
* **The device is a black box to the tests**: they use the reference driver (`sfx_driver.hpp`) and registers, not RTL internals.
* **Fault injection** is per bus transaction (`FaultRule`: SLVERR/DECERR for a byte range, reads/writes, skip/count), plus a
  *hung* mode where a bus stops responding entirely.
* **Protocol checkers in the RTL** (`transport/sfx_axi_checker.sv`) watch the core's AXI masters every cycle: stability of
  payload while stalled, burst length, size, INCR, alignment, no 4 KiB crossing, WLAST position, no W without AW, nonzero strobes, one
  outstanding burst per direction. Any violation fails the running test.
* **Device-never-touches-unauthorised-memory** is checked by logging every device-initiated transaction and asserting that guarded
  regions were never read or written, not just that a status was returned.

## 3. Test inventory (71 shared tests)

| Area | Tests |
|---|---|
| Identity, versioning, access rules | `identity_regs`, `reg_access_rules`, `abi_negotiation`, `window_commit_validation` |
| Basic data movement & completion fields | `nop_basic`, `copy_integrity`, `copy_roundtrip_chain`, `completion_fields_and_order`, `completion_point_copies`, `cqe_two_phase_publish` |
| Queue wraparound & counters | `queue_wraparound_tiny_rings`, `queue_counters_wrap_at_2_32`, `queue_cq_full_backpressure`, `queue_lifecycle_disable_reenable`, `queue_config_lock_rules`, `queue_enable_config_validation` |
| Doorbells | `doorbell_duplicates`, `doorbell_invalid_values`, `doorbell_retraction_rejected`, `doorbell_to_non_enabled_queue`, `doorbell_storm_exactly_once` |
| Interrupts | `irq_only_after_cqe_visible`, `irq_no_cause_no_edge`, `irq_masking_and_w1c`, `irq_rearm_after_partial_ack`, `irq_vector_mapping`, `irq_vector_per_queue`, `irq_vector_range_rejected`, `irq_coalesce_count`, `irq_coalesce_timer`, `irq_error_and_force_causes` |
| Malformed descriptors | `malformed_copy_matrix`, `malformed_kernel_nop_fence_matrix`, `malformed_user_virtual_address` |
| Queue-fatal errors | `queue_error_bad_seq`, `queue_error_sq_fetch_bus_error`, `queue_error_ring_unauthorised`, `queue_error_cq_write_bus_error`, `queue_error_drops_inflight_completions` |
| DMA failures | `dma_bus_errors_mid_transfer`, `dma_fault_direction_attribution` |
| Authorised windows | `window_revoke_midcopy_h2d_source`, `window_revoke_midcopy_d2h_destination`, `window_unmap_during_copy_driver_flow`, `window_domain_isolation`, `window_permissions_spaces_and_spans` |
| Ordering, fences, kernels | `ordering_overlap_vs_fence`, `ordering_barrier_blocks_later_commands`, `ordering_inorder_retire_despite_reordering`, `ordering_inflight_depth_respected`, `fence_signal_semantics`, `fence_signal_bus_error`, `fence_signal_revoked_before_write`, `fence_cross_queue`, `kernel_dispatch_plumbing`, `kernel_domain_and_two_queues` |
| Watchdog | `wdt_enable_rules_and_idle`, `wdt_expiry_hung_kernel_and_recovery`, `wdt_no_false_expiry_progressing_copy`, `wdt_heartbeat_keeps_long_kernel_alive`, `wdt_disarmed_while_cq_full` |
| Controlled reset | `reset_with_outstanding_work`, `reset_wrong_key_and_variants`, `reset_drain_timeout_then_hard_reset`, `reset_at_random_moments` |
| Tenant isolation & abuse | `isolation_unreleased_cq_does_not_stall_other_queues`, `disable_with_full_cq_completes_and_never_deadlocks`, `doorbell_page_errors_do_not_raise_dev_err`, `irq_coalescing_state_cleared_when_queue_disabled` |
| Randomised | `stress_random_single_queue`, `stress_random_two_queues` (also the model ≡ RTL digest) |

Highlights of what the named tests check:

* **Queue wraparound** — 2- and 4-entry rings (SQ and CQ different sizes) with hundreds of commands; phase flips on every lap; free-slot
  accounting from `cqe.sq_head`; counters started near 2³² so the 32-bit wrap is exercised; full CQ back-pressures without overwriting.
* **Duplicate doorbells** — the same value rung many times and after consumption: every command runs exactly once, `DUP_DB_COUNT` rises, no
  error; backwards, over-capacity, and to-a-disabled-queue doorbells are rejected without disturbing the queue.
* **Interrupt handling** — raised only after the CQE is visible (checked *at the edge*); masking; W1C; re-arm after a partial acknowledge; vector
  mapping; exact count coalescing; timer coalescing; no spurious edge.
* **Malformed descriptors** — one case per rule in SPEC §5.5 including precedence pairs, a real process pointer used as an address,
  addresses beyond the supported ranges, wrong domain / permission; each time the device must not have touched guarded memory and the
  queue must keep working. A wrong `seq` kills the queue.
* **DMA failures** — SLVERR and DECERR on host/device reads and writes mid-transfer; correct status, valid-prefix guarantee for `result`, no bytes
  outside the destination touched, fault registers updated, next command still runs; windows revoked mid-copy.
* **Reset with outstanding work** — copy in flight + kernel running + pending SQ entries + CQE publication; reset at random moments;
  registers at reset values per the persistence list; snapshots consistent; no completion ever appears for abandoned work; device usable after
  re-init; wrong key ignored; drain timeout on a hung bus leaves the device quiesced until a hard reset.

## 4. Mutation sanity

Passing tests prove little if they would also pass against a broken design. `tools/mutation_check.py` injects one realistic bug at a time
into a **copy** of the RTL (29 mutations: authorisation holes, a revoked window still honoured mid-burst, completion/phase ordering, doorbell
validation, descriptor validation precedence, sequence check, fence/barrier rules, CQ overwrite, interrupt ordering and re-arm, reset,
watchdog, AXI protocol violations), rebuilds, and runs the suite. See `MUTATION_RESULTS.md` for the table. The suite was run
once *before* the table was final and **found real holes in itself**:

* `cqe_two_phase_publish` did not detect a phase word published together with the body (SPEC D3) — fixed (it now checks memory content at
  every device write to the CQ ring).
* Two of the first mutants were *invalid* (they disabled a state-machine branch but left the error-event path alive, so the outward
  behaviour was unchanged); they were redefined to truly disable the check and are then caught.
* One mutant (`cq_full_overwrites`) became *equivalent* when a later design change (CQ credit) made the code it removed unreachable; it was
  redefined to break the credit bound as well, and is noted in `MUTATION_RESULTS.md`.
* A mutation pass run on the *software model* separately found a missing "doorbell may not retract published entries" test
  (`doorbell_retraction_rejected` added).

### 4.1 Independent review

After the suite was green, a fresh reviewer (a separate AI agent given only `SPEC.md` and the RTL, no conclusions from the author) was asked to find
spec/RTL contradictions, spec ambiguities, safety-property violations and abuse paths. It found real problems that the tests had not:
see rows 9–13 in §6. Each confirmed finding was then reproduced or traced by the author before being fixed; the fixes got tests and
mutants of their own (`isolation_*`, `cq_credit_removed`, …). This was an automated review, **not a human one**; a human review of `SPEC.md` is still
recommended.

## 5. Not verified / limits — read before relying on this

* **No formal verification.** No equivalence checking, no property proofs, no deadlock/liveness proof. Coverage is simulation only.
* **Block coverage only.** "277/277" is Verilator *line-block* coverage: every block ran at least once. It says nothing about branch/condition
  combinations, toggle, or functional coverage, and it does not say the behaviour was checked (that is what §4 is for).
* **Two-state simulation.** Verilator has no X/Z; uninitialised-state and X-propagation bugs cannot appear. Reset values are checked only for
  the registers the tests read.
* **Model and RTL share an author-side reading of the spec.** The model was written from `SPEC.md` independently of the RTL and they agree on
  everything tested, which catches implementation slips; it cannot catch a *common misreading* of the spec. (Resolving the spec ambiguities that the
  two implementations surfaced is listed in §6.) A human review of `SPEC.md` is still the main safeguard.
* **Completion point for device-memory destinations is structural.** The RTL waits for each write's B response before reporting a copy done
  and the host-bus port is single-outstanding, so for host destinations the harness's protocol checker would flag overlap. For *device*
  destinations no test can observe "B before done" independently: the bus-functional model applies a beat when it is accepted, before B.
  This property is enforced by construction (`sfx_dma` W_RESP) and by review, not by an observable test.
* **Bus models are mine.** The AXI slave BFMs (random stalls, latency, error injection) and the protocol checkers were written alongside the
  RTL. They are not a vendor VIP and do not certify AXI compliance.
* **Single clock domain**; no CDC, no multiple-clock or asynchronous-reset-release verification. The endpoint wrapper's 2-flop reset synchronizer
  is not analysed.
* **No real endpoint, no PCIe, no FPGA tools, no hardware.** See `INTEGRATION_FPGA.md`.
* **Performance is unmeasured**, and the design is deliberately single-outstanding (`DESIGN_NOTES.md` §4).
* **Randomised testing is bounded.** The stress tests use a few seeds in the default run (more via `--seed`); the soak above is
  60 (seed, profile) pairs.

## 6. Bugs and spec issues the verification found

Listed because they show what the process catches — and where it caught things late.

| # | Found by | Issue | Fix |
|---|---|---|---|
| 1 | shared suite (`identity_regs`) | `GEOMETRY.NUM_VECTORS` placed at bits 23:20 instead of 19:16 | RTL fixed |
| 2 | shared suite (wraparound, doorbell storm) | **CQ-head doorbell race:** the host can see a completion before `Q_CQ_TAIL` counts it, so a valid release doorbell was rejected → deadlock on tiny rings | doorbell bound now counts the completion mid-publication; spec §6.4 updated |
| 3 | shared suite under `stall`/`latency` | event definition mismatch: `Publish` fired after the phase-word *response* (after host-visible), `Issue` was sampled post-edge against stale inputs | events now defined at the phase-word accept and sampled pre-edge |
| 4 | code review (before any sim) | DMA abort while only the write side was active would complete with `ST_OK` after a partial copy | RTL fixed |
| 5 | code review | retire could double-pop the in-flight head the cycle after a registered pop; simultaneous queue-fatal events could be lost | RTL fixed (`!pop` guard; latched fatal arbitration) |
| 6 | mutation run | test hole: phase word published with body (D3) not detected | test strengthened |
| 7 | model/RTL comparison | three spec ambiguities resolved the same way in both: repeated `ENABLE=1` on an ENABLED queue is `CFG_LOCKED`; `W_CTRL` write with `VALID=0` clears `W_CTRL.ERR`; `STATUS.READY` is 0 while `RESETTING` | spec, RTL and model aligned |
| 8 | review | in-flight completions are now accepted only for entries of the matching kind (a faulty fabric tag cannot complete a COPY) | RTL hardened |
| 9 | independent review | **head-of-line blocking across tenants:** a queue owner who never released its CQ stalled every queue's completions (global in-order retire + CQ-full stall), and the watchdog ignored it | **CQ credit** (SPEC §7.7): a queue is served only while a CQ slot is guaranteed; RTL, model, spec, tests (`isolation_unreleased_cq_…`) |
| 10 | independent review | **deadlock:** disabling a queue while its CQ was full left it in DRAINING forever (retire waits for CQ space, the CQ-head doorbell is rejected once the queue is not ENABLED) | removed structurally by CQ credit; test `disable_with_full_cq_completes_…` (reverting the credit reproduces the hang) |
| 11 | independent review | a coalescing timer/count survived a queue disable and could raise `QCPL` on the re-enabled queue; timer could fire up to one unit early | state cleared while not ENABLED; timer fires after ≥ T units; test `irq_coalescing_state_cleared_…` |
| 12 | independent review | an untrusted doorbell-page writer could raise `DEV_ERR` interrupts at will; "doorbells are safe by construction" overclaimed | doorbell-page errors are recorded but never raise `DEV_ERR`; SPEC §3 reworded; test `doorbell_page_errors_do_not_raise_dev_err` |
| 13 | independent review | spec gaps, now stated explicitly: `BUSY` does not cover kernels; rings are ordinary windowed memory so D6 needs correctly programmed windows (§4.1); fabric memory access is not mediated; FENCE signals are skipped on an ERROR queue; `kd_valid` can be withdrawn when a window is invalidated; `kd_done` not in the dispatch cycle; `kd_abort` must complete in bounded time; `QERR_BAD_CONFIG` does not record `FAULT_INFO`; `INFLIGHT_DEPTH` limited to 2/4/8; no performance isolation between tenants | spec / design notes / driver guide updated; elaboration check |

## 7. Reproduce

```bash
make test               # everything except coverage / mutation
make coverage-rtl       # writes docs/COVERAGE.md
make mutation           # slow; writes docs/MUTATION_RESULTS.md
build/rtl_dw64_q2_w8_b16_i4/sfx_tests_rtl --target=rtl --profile=stall --seed=123   # one seed, one profile
```
