# Driver guide

How to talk to an SFX-CP device correctly. The normative rules are in `SPEC.md`; the executable reference is
`sw/include/sfx_driver.hpp` (header-only C++17, works over an abstract `sfx::MmioIf`, so the same code drives the
software model, the Verilated RTL, or — with a thin MMIO shim — real hardware). The Linux names below are the *typical*
mapping; check your architecture's memory-ordering documentation before relying on any of them.

## 1. Two roles, two pages

| Role | Touches | Notes |
|---|---|---|
| **Kernel driver** (privileged) | control page `0x0000–0x0FFF`: windows, queue config, IRQ, WDT, reset | Never map this page to user space. |
| **Queue owner** (may be a user process) | its own 4 KiB doorbell page, plus its SQ/CQ ring memory | `sfx::Queue` is this role. |

The hardware cannot tell the roles apart; the *page boundary* is what lets the OS enforce it. Doorbells are safe by construction (§SPEC 6.4: bad
values are rejected; descriptors are re-validated; DMA is window-checked), so a misbehaving queue owner can hurt only its own queue.

## 2. Three kinds of address

| Type in the library | Meaning | Who creates it |
|---|---|---|
| raw pointer (`void*`) | user/kernel virtual address — **never given to the device** | the CPU |
| `sfx::Iova` | device-visible DMA address from `dma_map_*` / the IOMMU | kernel driver, via the DMA API |
| `sfx::DevAddr` | offset in device-local memory | the kernel driver's device-memory allocator |

`Iova` and `DevAddr` are distinct structs with explicit constructors: passing a pointer or one kind where the other is expected does not compile. The
descriptor builders (`sfx::cmd::copy_h2d(cmd_id, Iova src, DevAddr dst, len, flags)` …) take the strong types. The raw-descriptor path exists only
for tests that deliberately craft bad descriptors.

## 3. Bring-up (kernel driver)

```
dev.init()                       // ID, VERSION major, geometry/limits, ABI_REQ negotiation  → STATUS.ABI_OK
// per buffer the device may touch:
iova = dma_map(...)              // OS DMA API; keep the mapping alive while the window is valid
w    = dev.map_host(iova, len, PermR|PermW, domain)      // writes W_BASE/W_SIZE then W_CTRL(VALID)
// per queue:
dev.create_queue(q, cfg, &h)     // allocates coherent SQ/CQ rings, maps them (SQ: R, CQ: W), programs Q_*, enables
queue = dev.make_queue(doorbell_mmio, h)
dev.irq_enable(mask); dev.wdt_enable(timeout); dev.enable(true)
```

Rules the library implements and a native driver must too:

* **Check geometry, don't assume it.** Read `NUM_QUEUES`, `NUM_WINDOWS`, `DMA_ALIGN`, `MAX_COPY`, `HOST_ADDR_BITS`, `DEVMEM_*`.
* **Rings** are 64-byte-aligned, DMA-coherent, power-of-two sized (2…4096 entries). **Zero the CQ ring before every enable**
  (zero = "not yet valid"; the first lap carries phase 1).
* **A window must be programmed before any descriptor uses it**, and a command must lie in **one** window.
* **Unmapping.** `W_CTRL.VALID=0` → poll `BUSY==0` → `dma_unmap` → free (`Device::unmap_window`). Skipping the poll can let an in-flight
  burst touch freed memory. `BUSY` covers only what the *core* does (fetch, DMA, completion/signal writes): **wait for any kernel that may touch the
  memory to complete (or reset the device) before unmapping it.**
* **Map rings in dedicated windows:** SQ ring **R only**, CQ ring **W only**, and never put ring memory inside a window usable as a COPY/signal
  target (SPEC §4.1). Queues that must not interfere with each other's rings belong in different domains.
* **Untrusted queue owners.** Doorbell-page errors never raise `DEV_ERR`, but they do set `ERR_STATUS`/`ERR_COUNT`, and a rejected command can overwrite
  `FAULT_ADDR/FAULT_INFO`: treat those as hints. `F_IRQ` bypasses coalescing; to rate-limit an owner, mask its queue's `QCPL` bit in `IRQ_ENABLE`.
  Queues are not performance-isolated (shared DMA engine/fabric, global fence and retire order, device-wide fault/reset).

## 4. Submitting work (queue owner)

```
fill descriptor (seq = absolute SQ index, desc_ver = 1, reserved = 0, address fields = Iova / DevAddr only)
SFX_WMB()            // store→store: descriptor visible before the doorbell (Linux: writel() orders it; with
                     //   writel_relaxed() use wmb())
write DB_SQ_TAIL = new_tail            // may be repeated: duplicates are harmless
```

* The **sequence number** is the free-running 32-bit SQ index; the library's `Queue::submit` assigns it. A wrong `seq` kills the queue
  (`QERR_BAD_SEQ`, no completion) — it exists to catch stale or torn slots.
* **Free slots** come from completions: slots below `cqe.sq_head` are reusable (`Queue::sq_free`).
* Never ring a tail further than the ring size ahead of the oldest unreclaimed slot, and never move it backwards: the device rejects it
  (`ERR_BAD_DOORBELL`) and **ignores** the write.
* **Dependencies.** Commands may overlap. Use `FENCE` / `F_FENCE_BEFORE` between dependent commands. A failed command does not stop
  later ones; if a chain must stop on error, fence and inspect completions.

## 5. Completions

```
loop:
  w = READ_ONCE(cqe[head].phase_word)           // single read of the phase word
  if phase(w) != expected_phase(head): break
  SFX_RMB()                                      // load→load (Linux: dma_rmb()) — only now read the other fields
  consume(cqe[head]); head++
SFX_MB()                                         // full barrier (Linux: mb()) — loads done before releasing slots
write DB_CQ_HEAD = head                          // device may overwrite released slots immediately
```

* `expected_phase(n) = ((n − seq_start) >> cq_log2 & 1) ^ 1` (`sfx_cq_phase()`).
* `status == ST_OK` means **the documented completion point was reached** (SPEC §8). A `COPY` completing OK means every byte was written and the
  bus acknowledged the writes; on error `result` is a *guaranteed-valid prefix*, nothing more.
* **Do not poll `Q_CQ_TAIL` to discover completions.** It lags the ring by a few cycles by design; the phase word is authoritative.
* If a `FENCE` with signal is used, the signalled value implies all earlier commands reached their completion points; the FENCE's own completion
  implies all earlier completions are visible.

## 6. Interrupts

```
isr:  s = IRQ_STATUS                     // which causes?
      write IRQ_STATUS = s               // W1C exactly the bits you handled (never a blanket 0xFFFFFFFF)
      for each QCPL[q] in s: drain CQ q
      repeat while IRQ_STATUS != 0       // the device re-pulses the vector if causes remain after your W1C
```

`F_IRQ` forces a completion interrupt for that command; `Q_IRQ_COAL` (count, timer) batches the rest. A QCPL interrupt is raised only after the
completion is visible. `QERR[q]`, `DEV_ERR`, `WDT`, `RESET_DONE` share `IRQ_MISC_VECTOR`.

## 7. Errors and recovery

| Symptom | Meaning | Action |
|---|---|---|
| completion `ST_BAD_*`, `ST_UNAUTHORIZED` | descriptor rejected before touching memory | fix the submitter; the queue is unaffected |
| completion `ST_DMA_READ_ERR` / `_WRITE_ERR` | bus error; `result` = valid prefix; `FAULT_ADDR/INFO` set | handle in software; queue continues |
| `Q_STATUS.STATE == ERROR` | `QERR_*` code explains (bad seq, ring unauthorised, fetch/CQ bus error, bad config) | `disable_queue`, fix, re-create; or controlled reset |
| `STATUS.FAULT` / `WDT_STATUS.EXPIRED` | watchdog tripped; kernels aborted, completions `ST_TIMEOUT` | read `WDT_STATUS.STUCK`, then **controlled reset** |
| reset `DRAIN_TIMEOUT` | bus is wedged; the device parks quiesced | function-level / hard reset only |

**Controlled reset** (`Device::controlled_reset`): write `RESET_CTRL = {RESET_KEY, REQ}`, poll `RESET_STATUS` for `DONE`. Afterwards: everything is cleared
except the persistent registers; every command without a visible completion is **abandoned**. Use `Q_RST_SQ_TAIL`, `Q_RST_SQ_HEAD`, `Q_RST_CQ_TAIL` to
work out what completed, then zero the CQ rings, reprogram windows and queues, and resubmit. No completion will ever appear for an abandoned command.

## 8. Checklist for a Linux kernel driver

* `dma_alloc_coherent()` for rings; `dma_map_single/sg()` (or `dma_map_resource`) for payloads; keep the returned `dma_addr_t` as the `Iova`.
* Program windows from the mapping, with the domain you assigned to the owning process/queue.
* Map only the owner's doorbell page into user space (`remap_pfn_range` / `vm_iomap_memory` on the BAR page), never the control page.
* MSI-X: vector *v* ↔ the wrapper's `irq_req[v]`; request one vector per queue plus the misc vector.
* On process exit: disable the queue (it cannot deadlock on a full CQ: the device never has more outstanding than the CQ holds), wait for the queue's
  kernels to complete, invalidate its windows, wait for `BUSY==0`, then unmap and free.
* On `STATUS.FAULT` or a reset request: controlled reset, then rebuild state; on drain timeout use FLR.
