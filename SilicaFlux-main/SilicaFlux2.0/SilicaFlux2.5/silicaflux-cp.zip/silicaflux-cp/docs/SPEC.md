# SilicaFlux Command Processor (SFX-CP) — Device Specification

**Register ABI 1.0 · descriptor layout v1 · status: reference design, simulation-verified only**

This document is normative for the RTL (`rtl/`), the software device model (`sw/model/`) and the
reference driver library (`sw/include/sfx_driver.hpp`). Numeric constants are generated from
`spec/sfx_spec.py`; the generated tables are in `REGMAP.md`. Where this text and the generated
tables disagree, fix `spec/sfx_spec.py`.

Keywords **MUST**, **MUST NOT**, **SHOULD**, **MAY** are used in the RFC 2119 sense.

---

## 0. Scope and honest limits

SFX-CP is the command-handling and DMA block of a SilicaFlux accelerator card: a host driver
submits commands through ring buffers in host memory; the device fetches, validates and executes
them (memory copies, kernel dispatch, fences), and reports completions through a second ring plus
interrupts.

What this package **is**:

* synthesizable-style SystemVerilog for the command processor, DMA engine, interrupt block,
  watchdog and controlled-reset sequencer (`rtl/`);
* a *transport boundary* made of plain AXI4-Lite + AXI4 + interrupt-level ports, with two
  replaceable wrappers (`transport/`): a simulation wrapper and an AXI-endpoint wrapper intended
  to sit between the core and a vendor PCIe endpoint IP;
* a C++ software device model and reference driver library that implement the same protocol;
* a test suite that runs unchanged against the model and the Verilated RTL.

What it is **not**, and what is **not claimed**:

* It contains **no PCIe PHY, link, TLP, or configuration-space logic**. Nothing here implements or
  claims compliance with the PCI Express Base Specification. The simulation wrapper is an AXI
  test harness, not a PCIe model.
* The AXI-endpoint wrapper has **not** been built against any vendor endpoint IP and **not** run on
  hardware. Its pin mapping is an integration task described in `INTEGRATION_FPGA.md`.
* No timing closure, area, power, or throughput numbers are claimed. v1 is correctness-first: one
  outstanding burst per bus direction.
* The compute fabric is out of scope; only its dispatch interface (§14.2) is defined.
* **Isolation limits (v1).** Queues in different *domains* are isolated in *which memory the core will touch on their
  behalf*. They are **not** isolated in performance or availability: execution units are shared (one COPY at a time, one
  compute fabric), retire and FENCE ordering are global across queues, a watchdog fault or a controlled reset affects every
  queue, and `F_IRQ` is a per-command interrupt request that bypasses coalescing. Memory that the *compute fabric* itself
  accesses while a kernel runs is **not** mediated by this block (§14.2). A deployment serving mutually distrusting tenants must
  add policy around these points.

---

## 1. Architecture

```
 host CPU / driver                                              (PCIe link, vendor IP: NOT in this package)
      │  MMIO (BAR)                      DMA (device-initiated)         MSI-X
      ▼                                         ▲                          ▲
┌──────────────────────────  transport wrapper  (replaceable)  ───────────────────────────┐
│  sim:  AXI protocol checkers + testbench pins     ep:  AXI-Lite/AXI4/irq req-ack shim   │
└───────┬───────────────────────────────┬──────────────────────────────────┬─────────────┘
 AXI4-Lite slave                 AXI4 master "host"                  irq_level[NV]
        │                                │ (IOVA space)                     ▲
┌───────▼────────┐  config/pointers ┌────┴─────────────────────────────────┴───────────────┐
│ sfx_axil_slave │◄────────────────►│                        sfx_cp_core                    │
│ sfx_regs       │                  │  frontend ─► inflight table ─► retire (CQE writer)    │
│  windows       │  window arrays   │     │  fetch      │ issue          ▲ in-order           │
│  queues        ├─────────────────►│     ▼             ▼                │                    │
│  irq/wdt/reset │                  │  mem_fabric ◄── sfx_dma ──► kernel dispatch (kd_*)    │
└────────────────┘                  └────┬──────────────────────────────────────────────────┘
                                   AXI4 master "dev"  (device-local memory, e.g. DDR/HBM controller)
```

* **Control plane**: AXI4-Lite slave → `sfx_regs`. 
* **Data plane**: two AXI4 masters. `host` carries IOVA-addressed traffic (descriptor fetch,
  host↔device copies, completion writes, fence signals); `dev` carries device-local memory traffic.
* **Every device-initiated access passes the authorisation windows** (§4), including ring accesses.

### 1.1 Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `NUM_QUEUES` | 2 | 1..4 SQ/CQ pairs |
| `NUM_WINDOWS` | 8 | 1..16 authorisation windows |
| `DATA_W` | 64 | AXI data width: 64, 128 or 256. `DMA_ALIGN = DATA_W/8` bytes |
| `MAX_BURST_BEATS` | 16 | beats per burst (never crosses 4 KiB) |
| `INFLIGHT_DEPTH` | 4 | issued-but-unretired commands: 2, 4 or 8 |
| `DEV_MEM_SIZE` | 16 MiB (sim) | device address space size |
| `HOST_ADDR_BITS` | 48 | supported host DMA address bits |

`NUM_VECTORS = NUM_QUEUES + 1`. All are reported in `GEOMETRY`, `LIMITS`, `DEVMEM_*`, `HOST_ADDR_BITS`.

---

## 2. Conventions

* Little-endian everywhere (registers, descriptors, completions).
* **Three kinds of address, never interchangeable:**
  * **User VA** — a pointer in a process. *Never* seen by the device. Descriptors MUST NOT contain one.
  * **IOVA / DMA address** — device-visible host address (`dma_addr_t`): what the kernel driver
    obtained from the DMA-mapping API (or the IOMMU) for pinned memory, and what the device puts on its
    `host` bus. Only the kernel driver creates mappings.
  * **Device address** — offset in device-local memory.
  The reference driver models these as distinct C++ types (`sfx::Iova`, `sfx::DevAddr`; raw pointers are
  a third type) so mixing them is a compile error. At the hardware level a VA that is not also an
  authorised IOVA is rejected by window checks (`ST_UNAUTHORIZED`), or `ST_BAD_RANGE` if it is outside
  the supported address space.
* **Domain**: a 4-bit protection-domain id. A queue belongs to one domain (set by the kernel driver in
  `Q_CTRL`); a window belongs to one domain. A queue can use only windows of its own domain.
* **Free-running counters** are 32-bit and wrap modulo 2³²; all comparisons use modular differences.
* "Retire" = the point where a command's completion entry becomes visible to the host.

---

## 3. Register interface and versioning

Full map: `REGMAP.md`. Summary of rules:

1. **Identity.** `ID` reads `0x53465843`. `VERSION` = `[31:24]` ABI major, `[23:16]` minor, `[15:0]` patch.
2. **Versioning rules.** A *major* bump is an incompatible change (register meaning, descriptor layout).
   A *minor* bump only adds registers/bits/opcodes/flags; software written for minor *m* works on any
   minor ≥ *m* of the same major. Software MUST ignore unknown `CAPS` bits and MUST NOT write
   reserved bits. The patch field has no ABI effect.
3. **ABI negotiation.** Before enabling any queue the driver MUST write `ABI_REQ = {major, minor}`.
   The device accepts it iff `major == ABI_MAJOR` and `minor ≤ ABI_MINOR`; `STATUS.ABI_OK` reflects
   acceptance. `Q_CTRL.ENABLE` with no accepted ABI fails with `QERR_BAD_CONFIG`.
4. **Descriptor version.** Every descriptor carries `desc_ver`; `DESC_VERSIONS` is a bitmap of
   supported layouts (bit *n* = version *n*).
5. **Access rules.** 32-bit aligned accesses with all strobes. Reads of reserved/unmapped offsets
   return 0 and have no side effect. A *write* that is partial, unaligned, to a read-only register,
   or to unmapped space is ignored and sets `ERR_STATUS.BAD_REG_ACCESS`. (The bus response is always
   OKAY: an AXI error response can be escalated to a fatal host fault by some PCIe root complexes.)
6. **Pages.** Control page `0x0000–0x0FFF` is for the kernel driver only. Each queue has its own
   4 KiB **doorbell page** at `0x1000 + q·0x1000`. A driver MAY map one doorbell page into the process
   that owns the queue; the hardware cannot enforce this — the page boundary is what lets the OS do so.
   Doorbells cannot corrupt device or memory state: an invalid value is rejected (§6.4), and descriptors are
   independently validated and window-checked. A doorbell-page writer *can* make the device record diagnostics: errors
   from doorbell-page writes set `ERR_STATUS` bits, `ERR_COUNT` and `DUP_DB_COUNT`, but they **never raise
   `IRQ_STATUS.DEV_ERR`**. When queues belong to untrusted processes, treat those registers — and `FAULT_ADDR/FAULT_INFO`, which a
   queue owner can influence by submitting a rejected command — as untrusted hints.
7. **Persistence across controlled reset (§13):** `IRQ_ENABLE`, `IRQ_MISC_VECTOR`, `RESET_TIMEOUT`,
   `SCRATCH`, `RESET_STATUS`, and `Q_RST_*` persist; everything else returns to its reset value.
   A hard reset (`rst_n`) resets everything.

### 3.1 Global control / status

* `CTRL.ENABLE` allows command *fetch and issue*. Doorbells are accepted regardless.
* `STATUS`: `READY` (0 while `RESETTING`, otherwise 1), `RUNNING` = `ENABLE ∧ ¬FAULT ∧ ¬RESETTING`, `FAULT`
  (watchdog, §12), `RESETTING`, `IDLE` (no unfetched work on an ENABLED queue, no frontend activity,
  no in-flight entry, no completion being published), `ABI_OK`.
* `ERR_STATUS` bits are sticky until written 1; each *event* also increments `ERR_COUNT`. Setting a
  bit that was previously clear raises `IRQ_STATUS.DEV_ERR`.
* `FAULT_ADDR`/`FAULT_INFO` record the **most recent** of: (a) a COPY that completed with `ST_DMA_READ_ERR`,
  `ST_DMA_WRITE_ERR` or `ST_UNAUTHORIZED` (address = start of the failing burst); (b) a decode-time
  `ST_UNAUTHORIZED` (address = start of the first unauthorised operand: source/entry, then destination/args);
  (c) a FENCE signal-write fault (address = signal address); (d) a queue-fatal error (status field =
  `0x8000 | QERR_*`, address = the ring slot that failed, or the descriptor slot for `QERR_BAD_SEQ`).
  `FAULT_INFO = {12'b0, queue[3:0], status[15:0]}`. `ST_ABORTED` is not recorded. If two records arrive in the same
  cycle the higher-priority one (queue-fatal, then DMA, then fence-signal, then decode) wins.
* `CMDS_OK`/`CMDS_ERR` (and the per-queue `Q_CMDS_*`, `Q_CQ_TAIL`) count published completions (not commands that were
  dropped). **They advance a few cycles after the phase word becomes visible in host memory** (they count after the
  phase-word write response). A driver should rely on the CQ ring, not on these registers, to find new completions;
  software that polls registers must tolerate this lag.

---

## 4. DMA authorisation (driver-authorised mappings)

The device never trusts an address from a descriptor or a ring configuration register. It holds a
table of **windows**, programmed only through the control page by the kernel driver:

`window = { valid, space (host IOVA | device), R, W, domain, base, size }`

An access *(space, domain, addr, len, perm)* is **authorised** iff some valid window *w* has
`w.space == space ∧ w.domain == domain ∧ w.perm ∋ perm ∧ w.base ≤ addr ∧ addr+len ≤ w.base+w.size`
(computed without overflow). A single access must fit in **one** window.

### 4.1 Where it is enforced

| Access | Checked |
|---|---|
| Queue enable | SQ ring `[sq_base, +64·size)` host/R and CQ ring `[cq_base, +32·size)` host/W authorised in the queue's domain (early failure) |
| Descriptor fetch | each fetch, host/R |
| Completion write(s) | each publish, host/W |
| Fence signal write | decode time **and** at write time, host/W |
| COPY / kernel operands | whole range at decode time (single window), **and again before every DMA burst** |

The per-burst re-check means a window invalidated mid-transfer stops the transfer at the next burst
boundary with `ST_UNAUTHORIZED` (§8.4).

**Rings are ordinary windowed memory.** Windows authorise by space, domain and permission, not by purpose, so the device cannot tell a
ring from a data buffer. D6 (§10.1) therefore holds *given correctly programmed windows*: the kernel driver MUST map each SQ ring in a
window with **R only** and each CQ ring in a window with **W only**, dedicated to that ring, and MUST NOT include ring memory in any window
usable as a COPY or signal target. Queues that must not be able to touch each other's rings must be in different domains.

### 4.2 Programming and revocation

* Window registers are written while `VALID=0`; writing `W_CTRL` with `VALID=1` **commits**. Commit
  is rejected (`W_CTRL.ERR`, `ERR_BAD_WINDOW`, window stays invalid) if: size is 0, base or size is not
  a multiple of `DMA_ALIGN`, `base+size` wraps or exceeds the space limit (`2^HOST_ADDR_BITS` for host,
  `DEVMEM_SIZE` for device), or neither R nor W is set.
* While valid, writes to `W_BASE/SIZE` are ignored (`ERR_CFG_LOCKED`); a commit write to a valid
  window is rejected the same way. To change a window: invalidate (`W_CTRL` write with `VALID=0`),
  wait for `BUSY=0`, reprogram, commit.
* A `W_CTRL` write with `VALID=0` also clears `W_CTRL.ERR` and stores the attribute bits.
* **Invalidate** takes effect for *new* authorisation decisions immediately. `W_CTRL.BUSY` reads 1
  while any already-authorised access that used the window is still outstanding on a bus. The driver
  MUST NOT unmap/free the underlying memory until `BUSY=0`.
  *(Linux-style sequence: write VALID=0 → poll BUSY → `dma_unmap_*` → free.)*
* `BUSY` covers only accesses **the core itself performs** (descriptor fetch, DMA bursts, completion and fence-signal writes). It does **not**
  cover memory a dispatched kernel is using: the driver MUST wait for the kernel's completion (or a reset) before unmapping memory the
  kernel may touch.

---

## 5. Descriptors and completions

### 5.1 Submission queue entry (64 bytes)

| Off | Size | Field | Meaning |
|---|---|---|---|
| 0x00 | u16 | `opcode` | §5.3 |
| 0x02 | u16 | `flags` | §5.4 |
| 0x04 | u32 | `seq` | **MUST equal the absolute SQ index of this slot** (§6.3) |
| 0x08 | u32 | `cmd_id` | opaque host tag, echoed in the completion |
| 0x0C | u16 | `desc_ver` | MUST be 1 |
| 0x0E | u16 | `rsvd0` | MUST be 0 |
| 0x10 | u64 | `addr0` | COPY: source · KERNEL: kernel entry (device addr) · FENCE: signal address (host IOVA) |
| 0x18 | u64 | `addr1` | COPY: destination · KERNEL: argument block (device addr) |
| 0x20 | u32 | `length` | COPY: bytes · KERNEL: argument-block bytes |
| 0x24 | u32 | `aux0` | KERNEL: grid_x |
| 0x28 | u32 | `aux1` | KERNEL: grid_y |
| 0x2C | u32 | `aux2` | KERNEL: grid_z |
| 0x30 | u64 | `value` | FENCE: signal value |
| 0x38 | u64 | `rsvd1` | MUST be 0 |

Fields unused by an opcode MUST be zero (checked: `ST_BAD_DESC`) — this keeps them available for
future minor versions.

### 5.2 Completion queue entry (32 bytes)

| Off | Size | Field | Meaning |
|---|---|---|---|
| 0x00 | u32 | `cmd_id` | echo |
| 0x04 | u32 | `sq_seq` | absolute SQ index of the command |
| 0x08 | u16 | `status` | `ST_*` |
| 0x0A | u16 | `opcode` | echo of the raw descriptor opcode |
| 0x0C | u32 | `sq_head` | `sq_seq + 1`: SQ slots with absolute index `< sq_head` may be reused |
| 0x10 | u64 | `result` | see §8 |
| 0x18 | u32 | `cq_seq` | absolute CQ index of this entry (lost/duplicate detection) |
| 0x1C | u32 | `phase_word` | bit 0 = **phase**; **written last, as a separate bus write** (§10) |

**Phase.** `phase(n) = ((n − seq_start) >> cq_log2 & 1) ^ 1`: the first lap after enable carries
phase 1, so zero-initialised memory never looks valid. The driver tracks the same function.

### 5.3 Opcodes

| Opcode | Value | Meaning |
|---|---|---|
| `NOP` | 0x0000 | completes in order; no memory access |
| `COPY_H2D` | 0x0001 | host IOVA `addr0` → device `addr1`, `length` bytes |
| `COPY_D2H` | 0x0002 | device `addr0` → host IOVA `addr1` |
| `COPY_D2D` | 0x0003 | device `addr0` → device `addr1` |
| `KERNEL` | 0x0010 | dispatch `addr0` with args `addr1/length`, grid `aux0×aux1×aux2` |
| `FENCE` | 0x0020 | execution barrier; with `F_FENCE_SIGNAL`: then write `value` (u64) to host `addr0` |

### 5.4 Flags

| Flag | Bit | Applies to | Meaning |
|---|---|---|---|
| `F_FENCE_BEFORE` | 0 | all | do not **issue** until every earlier command (all queues) has retired |
| `F_IRQ` | 1 | all | raise this queue's completion interrupt once the completion is visible |
| `F_FENCE_SCOPE_ALL` | 2 | FENCE | advisory in ABI 1.0: scope is always *all queues* |
| `F_FENCE_SIGNAL` | 3 | FENCE | perform the signal write |

### 5.5 Validation — normative order

The first failing rule determines the status. A failing command is **still completed** (it occupies
its place in order and gets a completion with that status); it does not touch memory.

0. **`seq != expected`** → queue-fatal `QERR_BAD_SEQ` (§6.5); *no completion*.
1. `desc_ver != 1` → `ST_BAD_VERSION`.
2. unknown opcode → `ST_BAD_OPCODE`.
3. flag bit outside `F_VALID_MASK`, or `F_FENCE_SCOPE_ALL`/`F_FENCE_SIGNAL` on a non-FENCE → `ST_BAD_FLAGS`.
4. `rsvd0 ≠ 0`, `rsvd1 ≠ 0`, or any field unused by the opcode ≠ 0 → `ST_BAD_DESC`.
   (NOP: all of addr0/addr1/length/aux/value; COPY: aux0-2, value; KERNEL: value;
   FENCE: addr1/length/aux0-2, and addr0/value unless `F_FENCE_SIGNAL`.)
5. Opcode-specific, in this order:
   * **COPY**: `length == 0 ∨ length > MAX_COPY ∨ length % DMA_ALIGN ≠ 0` → `ST_BAD_LENGTH`;
     `addr0 % DMA_ALIGN ≠ 0 ∨ addr1 % DMA_ALIGN ≠ 0` → `ST_BAD_ALIGN`;
     either range outside its space's supported limit or wrapping → `ST_BAD_RANGE`;
     source not authorised for **R**, or destination not authorised for **W** → `ST_UNAUTHORIZED`.
   * **KERNEL**: any grid dim `== 0` or `> MAX_GRID_DIM` → `ST_BAD_DESC`;
     `length == 0 ∧ addr1 ≠ 0` → `ST_BAD_DESC`; `length > MAX_ARGS ∨ length % 8 ≠ 0` → `ST_BAD_LENGTH`;
     `addr0 % 8 ≠ 0 ∨ addr1 % 8 ≠ 0` → `ST_BAD_ALIGN`;
     kernel entry (8 bytes) or args range outside device limit → `ST_BAD_RANGE`;
     kernel entry or args not authorised for **R** (device space) → `ST_UNAUTHORIZED`.
   * **FENCE with signal**: `addr0 % 8 ≠ 0` → `ST_BAD_ALIGN`; 8 bytes outside host limit → `ST_BAD_RANGE`;
     not authorised for host **W** → `ST_UNAUTHORIZED`.
   * **NOP / FENCE without signal**: nothing further.

(`DMA_ALIGN` applies to COPY addresses and length; kernel and signal addresses use 8.)

---

## 6. Queues

### 6.1 Ring ownership

Each queue has an SQ ring (64-byte entries) and a CQ ring (32-byte entries) in **driver-allocated,
DMA-coherent host memory**, sizes `2^k` entries, `1 ≤ k ≤ 12`, bases 64-byte aligned.

| Object | Producer (writes) | Consumer (reads) | Handoff signal |
|---|---|---|---|
| SQ slot *i* | host driver | device | doorbell `DB_SQ_TAIL` (publishes *all* slots below the new tail) |
| CQ slot *i* | device | host driver | phase bit in `phase_word` (§10) |
| SQ slot reuse | — | — | host may reuse slot `< cqe.sq_head` |
| CQ slot reuse | — | — | host releases via `DB_CQ_HEAD`; device never overwrites an unreleased slot |

The device **never writes** the SQ ring and **never reads** the CQ ring. A slot is owned by exactly
one side at a time; the table above is the whole protocol.

### 6.2 State per queue

Four free-running 32-bit counters, all initialised to `Q_SEQ_START` at enable:
`sq_tail` (host-published), `sq_head` (device-consumed), `cq_tail` (device-published), `cq_head`
(host-released). Pending = `sq_tail − sq_head`; CQ occupancy = `cq_tail − cq_head`.

### 6.3 Sequence numbers

* **Command sequence number** = absolute SQ index (`sq_head` when the descriptor is consumed). The
  descriptor's `seq` MUST equal it. This detects torn, stale or mis-ordered slots and is echoed as
  `cqe.sq_seq`.
* **Completion sequence number** = absolute CQ index, echoed as `cqe.cq_seq`.
* `cmd_id` is the host's own tag; the device does not interpret it.
* `Q_SEQ_START` lets software (and tests) start counters near 2³² to exercise wrap. It MUST be a
  multiple of `max(SQ size, CQ size)`.

### 6.4 Doorbells

Writing `DB_SQ_TAIL = v` on an ENABLED queue (let `d = v − sq_head`, `o = sq_tail − sq_head`, `S` = SQ size):

* `v == sq_tail` → **duplicate**: no effect, `DUP_DB_COUNT++`, **not** an error. (The same doorbell
  may be rung any number of times; each command executes exactly once.)
* `o < d ≤ S` → accept; `sq_tail = v`.
* otherwise (backwards, or more than the ring capacity ahead) → **rejected**: ignored,
  `ERR_BAD_DOORBELL`.

Writing `DB_CQ_HEAD = v` (let `d = v − cq_head`, and `p = cq_tail − cq_head`, **plus one if a completion for this queue is mid-publication** — its phase word may already be visible to the host before `cq_tail` counts it, §10):
`v == cq_head` → duplicate; `0 < d ≤ p` → accept; otherwise rejected as above.

A doorbell to a queue that is not ENABLED, or any doorbell while RESETTING, is ignored
(`ERR_BAD_DOORBELL` only for the not-ENABLED case, not during reset).

### 6.5 Queue states

`DISABLED → ENABLED → (DRAINING →) DISABLED`, and `ENABLED → ERROR → DRAINING → DISABLED`.

* **Enable** (`Q_CTRL.ENABLE=1` while DISABLED): validate ABI accepted; sizes in `[1,12]`; bases 64-byte
  aligned and rings within the host address limit without wrap; `Q_SEQ_START` aligned; vector valid;
  rings authorised (§4.1). Pass → counters = `Q_SEQ_START`, state ENABLED. Fail → state ERROR with
  `QERR_BAD_CONFIG`, `ERR_BAD_QCONFIG`. `ENABLE=1` in any other state — including a repeated enable of an ENABLED queue — is ignored and sets `ERR_CFG_LOCKED`.
* **Config registers** (`Q_SQ/CQ_BASE`, `Q_SIZE`, `Q_VECTOR`, `Q_SEQ_START`, domain bits of `Q_CTRL`) are
  writable only while DISABLED; otherwise ignored with `ERR_CFG_LOCKED`. `Q_IRQ_COAL` is writable any time.
* **Disable** (`ENABLE=0` while ENABLED or ERROR) → DRAINING: no further descriptors are fetched or
  issued for the queue; unfetched SQ entries are abandoned; commands already fetched/in flight run to
  completion and are published (unless the queue was in ERROR: then dropped). When none remain
  → DISABLED. Re-enabling restarts counters at `Q_SEQ_START`; the driver MUST zero the CQ ring first.
* **Fatal queue errors → ERROR** (and `IRQ_STATUS.QERR[q]`, `Q_STATUS.ERR_CODE`; run-time errors also record `FAULT_INFO`, `QERR_BAD_CONFIG` does not):
  `QERR_BAD_SEQ`, `QERR_SQ_FETCH` (bus error on descriptor read), `QERR_RING_UNAUTH` (SQ/CQ access
  not authorised), `QERR_CQ_WRITE` (bus error publishing), `QERR_BAD_CONFIG`.
  In ERROR the queue fetches nothing and publishes nothing; commands already in flight finish but their
  completions are dropped — including the signal write of an in-flight FENCE, which is **not** performed on an ERROR queue. `Q_SQ_HEAD`/`Q_CQ_TAIL` tell the driver what happened. Recovery: disable,
  reconfigure, enable (or controlled reset).

---

## 7. Execution and ordering model

Each in-flight command occupies one slot of the **in-flight table** (`INFLIGHT_DEPTH` entries,
allocation order = issue order, shared by all queues).

1. **Fetch/issue order.** One descriptor at a time, round-robin among queues that are ENABLED and have
   pending work. Within a queue, commands are issued in SQ order.
2. **Issue** = allocate an in-flight slot and hand the command to its unit. NOP, FENCE and commands
   that failed validation complete immediately at issue. Issue stalls while:
   (a) the table is full; (b) a FENCE entry is in flight (barrier); (c) the command has
   `F_FENCE_BEFORE` and the table is not empty; (d) its unit is busy — **one COPY at a time** (the DMA
   engine); a KERNEL waits for the fabric to accept it (`kd_ready`).
3. **Overlap.** Independent commands MAY overlap: a COPY and one or more KERNELs execute concurrently.
   Software that needs ordering between dependent commands MUST use `FENCE` / `F_FENCE_BEFORE`.
4. **Retire in order.** Completions are published strictly in issue order, a completion only after the
   command's *completion point* (§8) is reached **and** every earlier-issued command has been published.
   Hence a CQE becoming visible implies all earlier-issued commands' CQEs are visible.
5. **FENCE.** A FENCE entry reaches the retire head only when every earlier-issued command (any queue)
   has retired. Then, if `F_FENCE_SIGNAL`: the 8-byte value is written to host `addr0` and the write
   response (OKAY) awaited; then its own completion is published. No command issued after the FENCE
   starts before the FENCE retires. Consequences a driver may rely on: *signal observed ⇒ all prior
   commands reached their completion points and their CQEs were published first*; *FENCE CQE visible ⇒
   all prior CQEs visible*. (In ABI 1.0 the scope bit is advisory: this implementation always provides the
   strongest, all-queue scope; a stronger ordering than requested is always conforming.)
   A signal write failing authorisation or with a bus error does not fail the queue: the FENCE's
   completion carries `ST_UNAUTHORIZED` / `ST_DMA_WRITE_ERR`.
6. **Errors do not cancel later commands.** A failed command does not poison its successors; use
   `F_FENCE_BEFORE` + checking completions if a chain must stop on error (a driver-level policy).
7. **Completion-queue credit.** A queue is served (descriptors fetched and issued) only while a completion slot is guaranteed for one more
   command: `(sq_head − cq_head) < CQ size`, i.e. commands consumed but not yet released by the host always fit in the CQ. Consequently retire
   never waits for CQ space, the device never overwrites an unreleased slot, and **a tenant that stops releasing its CQ stalls only its own
   queue**: its unfetched entries stay pending, `STATUS.IDLE` stays 0, and the watchdog does not count the wait. Software that submits more
   commands than the CQ holds simply sees them start as it releases slots.

---

## 8. Commands and completion points

A completion with `status == ST_OK` means the command **reached its documented completion point**:

| Command | Completion point (all of) |
|---|---|
| NOP | all earlier commands retired (in-order retire) |
| COPY_* | every source byte read with OKAY response **and** every destination byte written and its AXI write response (OKAY) received from the destination bus. `result` = `length` |
| KERNEL | the compute fabric reported `KD_OK` for the dispatch; the fabric contract (§14.2) says this is after the kernel's memory writes are performed. `result` = fabric `info` |
| FENCE | §7.5 incl. signal write response (OKAY) when requested. `result` = 0 |

For a host destination, "write response received" is what the **bus** guarantees — for a PCIe bridge
this is acceptance by the bridge; host visibility then relies on PCIe posted-write ordering (the
completion write is issued only after this response and travels behind the data). See §10.

### 8.1 Errors and `result`

On a non-OK status `result` is the number of leading bytes of the destination guaranteed to hold the
correct data (COPY; always a multiple of `DMA_ALIGN`, never more than the true failing offset) — the
reference RTL reports the start of the failing burst. Bytes of the destination at or beyond
`result` are **undefined** (they may or may not have been written); bytes outside
`[dst, dst+length)` are never touched. For KERNEL faults `result` is the fabric's `info`.

### 8.2 DMA engine behaviour (informative detail the tests rely on)

* Reads and writes are split into bursts of at most `MAX_BURST_BEATS` beats that never cross a 4 KiB
  boundary. Source and destination are partitioned independently. A read burst is *atomic*: if any beat
  returns a bus error the whole burst is discarded, never written onward.
* On a read-side fault the engine still writes out everything read before the failing burst, then
  completes with `ST_DMA_READ_ERR` (or `ST_UNAUTHORIZED` if the failure was a per-burst re-check).
  On a write-side fault it stops reading and completes with `ST_DMA_WRITE_ERR` / `ST_UNAUTHORIZED`.
* Source and destination fault at once → whichever the engine records first (unspecified).

### 8.3 Aborts

* Controlled reset (§13): the DMA stops at the next burst boundary, kernels receive `kd_abort`;
  the affected commands are **not** published (state is discarded).
* Watchdog fault (§12): in-flight kernels are aborted and the DMA stopped likewise; their completions
  carry `ST_TIMEOUT` and are published normally.

---

## 9. Life of a command (end-to-end summary)

Each step names the rule that governs it. *Host* = driver/queue owner, *Dev* = the device.

| # | Who | Step | Rule |
|---|---|---|---|
| 1 | Host (kernel) | maps the buffers, programs windows, enables the queue | §4, §6.5 |
| 2 | Host | writes **all** 64 descriptor bytes into SQ slot *n* (`seq = n`) — slot is host-owned until step 4 | §5.1, §6.1 |
| 3 | Host | **store barrier (H1)** | §10.2 |
| 4 | Host | writes `DB_SQ_TAIL = n+1` — slot ownership passes to the device. Repeating the write is harmless | §6.4 |
| 5 | Dev | accepts the doorbell (validates it); `sq_tail` advances | §6.4 |
| 6 | Dev | authorises the slot (host, R), reads the descriptor (**D1**: only after the doorbell) | §4.1, §10.1 |
| 7 | Dev | checks `seq`; decodes and validates in the normative order (bad `seq` = queue-fatal, no completion) | §5.5 |
| 8 | Dev | **issues**: allocates an in-flight slot; COPY → DMA engine, KERNEL → fabric, FENCE/NOP/invalid → already complete. Issue stalls on barrier / `F_FENCE_BEFORE` / busy unit | §7 |
| 9 | Dev | executes; every DMA burst is re-authorised; reaches the **completion point** or fails with a status | §4.1, §8 |
| 10 | Dev | **retires in order**: [FENCE signal write → response] → waits for CQ space → writes CQE body → response (**D2, D3**) | §7.4, §10.1 |
| 11 | Dev | writes the **phase word** as its own write (entry becomes visible) → response; then counters advance and the interrupt cause is raised (**D4**) | §10.1, §11 |
| 12 | Host | observes the phase, **load barrier (H2)**, reads the entry; slots below `cqe.sq_head` are reusable | §5.2, §10.2 |
| 13 | Host | **full barrier (H3)**, writes `DB_CQ_HEAD` — CQ slots return to the device | §6.4, §10.2 |

Failure edges: a descriptor that fails validation still completes (step 10–11 with an error status) without touching memory; a ring or
sequence fault stops the queue (§6.5); a hung unit trips the watchdog (§12); a controlled reset abandons everything whose completion was not yet
visible (§13).

---

## 10. Memory ordering contract

### 10.1 What the device guarantees (D1–D6)

* **D1 — no early fetch.** The device reads SQ slot *n* only after a doorbell making `sq_tail > n` has been
  accepted. (A doorbell is a posted MMIO write; it is processed in order after earlier MMIO writes.)
* **D2 — data before completion.** A command's completion write(s) are issued only after its completion
  point (§8); in particular after the **write response** of every data write.
* **D3 — body before phase.** The completion is published in **two bus writes**: first bytes `0x00–0x1B`
  (everything except `phase_word`), then — only after the first write's response — the 4-byte
  `phase_word`. A host that observes the new phase therefore observes a complete entry (given D5/§10.2).
* **D4 — interrupt after visibility.** An interrupt cause for a completion is raised only after the
  `phase_word` write's response is received. (Fence signal writes complete before the FENCE's completion
  is published.)
* **D5 — in-order visibility.** Completions are published in issue order, each fully (both writes) before
  the next begins.
* **D6 — ownership.** Given windows programmed as §4.1 requires, the device never writes the SQ ring and never reads the CQ ring; it
  never accesses host memory outside an authorised window.

### 10.2 What the driver must do (H1–H5)

Mapping to Linux primitives is given as a *typical* choice; verify against your architecture's ordering
rules. Rings MUST be DMA-coherent memory (e.g. `dma_alloc_coherent`); streaming/non-coherent mappings
additionally need cache maintenance.

* **H1 — publish.** Fill **all** descriptor bytes (including `seq`), then a store→store barrier, then the doorbell
  write. (Linux: `writel()` orders prior stores to coherent memory before the MMIO write; with
  `writel_relaxed()` use `wmb()` first.)
* **H2 — consume.** Read `phase_word` once; if its phase is not the expected one, stop. Otherwise a load→load barrier
  (Linux: `dma_rmb()`), then read the remaining fields.
* **H3 — release.** After finishing with CQ entries, issue a full barrier (Linux: `mb()`; a store-release is not
  enough toward an MMIO register), then write `DB_CQ_HEAD`. The device may overwrite the released slots
  immediately.
* **H4 — window lifetime.** Program a window before any command uses it; before unmapping memory, invalidate and
  wait for `BUSY=0`.
* **H5 — interrupts.** In the ISR read `IRQ_STATUS`, write back **exactly the bits handled** (W1C), then drain the CQ;
  repeat while `IRQ_STATUS` has bits. (The device re-pulses the vector after any W1C if causes remain,
  so no wake-up is lost.)

---

## 11. Interrupts

`IRQ_STATUS` (W1C) cause bits: `QCPL[q]` (bits 0..3), `QERR[q]` (bits 4..7), `DEV_ERR` (8), `WDT` (9),
`RESET_DONE` (10). `IRQ_ENABLE` masks causes. `IRQ_FORCE` sets cause bits (bring-up/test).

* `QCPL[q]` maps to vector `Q_VECTOR[q]`; all other causes map to `IRQ_MISC_VECTOR`.
  Vector numbers `≥ NUM_VECTORS` are rejected at write (`ERR_BAD_IRQ_CONFIG`).
* Output: one **level** per vector: `level[v] = OR(status & enable & causes mapped to v)`.
  The transport turns rising edges into MSI-X messages (or drives INTx).
* **Re-arm.** Any W1C write to `IRQ_STATUS` forces all levels low for ≥1 cycle, so causes still pending
  produce a new rising edge (H5).
* **When `QCPL[q]` is set.** For each published completion on queue *q*, **after D4**:
  * `F_IRQ` set → set at once and reset the coalescing state;
  * else, if `Q_IRQ_COAL.count = N > 0` → count completions; set when the count reaches *N*;
  * and, if `Q_IRQ_COAL.timer = T > 0` → a timer starts at the first completion after the last announcement and expires after at least
    `T × TIMER_UNIT` and fewer than `(T+1) × TIMER_UNIT` clocks (the prescaler free-runs); set when it expires with ≥1 completion unannounced.
  * Both zero: only `F_IRQ` completions raise the cause.
  * Coalescing counters and timers are held clear while the queue is not ENABLED, so nothing stale survives a disable/re-enable.
  * `F_IRQ` bypasses coalescing: it is a per-command request from the queue owner. A kernel driver that must rate-limit an untrusted owner
    masks that queue's `QCPL` bit in `IRQ_ENABLE`.
* `QERR[q]` is set when the queue enters ERROR; `DEV_ERR` per §3.1; `WDT` at watchdog expiry;
  `RESET_DONE` when a controlled reset finishes.

---

## 12. Watchdog

* `WDT_CTRL.ENABLE` with `WDT_TIMEOUT > 0` (clocks). Enabling with timeout 0 is ignored (`ERR_BAD_REG_ACCESS`).
* **Armed** (`WDT_STATUS.ARMED`) iff the watchdog is enabled, the device is neither in `FAULT` nor `RESETTING`, **and** at least
  one of: (`CTRL.ENABLE` ∧ some ENABLED queue has unfetched entries *and CQ credit*, §7.7); the frontend is busy; the in-flight table is not
  empty; a completion is being published. An ENABLED queue whose pending entries wait only for CQ credit does not arm the watchdog — that
  wait is on the host, not on the device.
* `WDT_COUNT` counts clocks while armed with **no progress**; any progress (descriptor fetched, command issued, a bus
  burst finished, DMA/kernel completion, completion published, or the fabric's optional `kd_heartbeat`) clears
  it; disarming clears it.
* **Expiry** (`WDT_COUNT == WDT_TIMEOUT`): `WDT_STATUS.EXPIRED` (W1C) sets, `STUCK` records which units were busy
  (frontend / DMA / kernel / retire), `EXPIRY_COUNT++`, `IRQ_STATUS.WDT`, `FAULT_CAUSE.WDT`, `STATUS.FAULT`.
* **FAULT**: no further fetch or issue. In-flight kernels get `kd_abort`; the DMA stops at the next burst
  boundary; they complete with `ST_TIMEOUT` and are published. A stuck bus transaction cannot be aborted
  (AXI has no cancel): recovery from FAULT is **controlled reset only**, and if the bus itself is dead, a
  hard (link/function-level) reset.
* A kernel running legitimately longer than `WDT_TIMEOUT` must emit `kd_heartbeat` pulses or the timeout must be
  sized above the worst case.

---

## 13. Controlled reset

`RESET_CTRL = {RESET_KEY, …, REQ=1}`. A wrong key is ignored (`ERR_BAD_REG_ACCESS`). Sequence:

1. **Quiesce.** `RESETTING=1`; the frontend stops fetching/issuing (an AXI fetch already on the bus completes);
   the DMA is aborted at its next burst boundary; kernels receive `kd_abort`; retire starts no new completion
   (a completion already being written completes — it will be visible to the host); the doorbell and
   register-write paths ignore writes (reads work).
2. **Drain.** Wait until every bus transaction has received its response and every dispatched kernel has
   reported done. If this does not happen within `RESET_TIMEOUT` clocks (`0` = no timeout, wait forever; the idle condition must hold for 4 consecutive clocks): `RESET_STATUS.DRAIN_TIMEOUT` is
   set, the device **stays quiesced in RESETTING** (the bus is wedged; only a hard reset recovers).
3. **Snapshot.** `Q_RST_SQ_TAIL/SQ_HEAD/CQ_TAIL` capture the final counters of each queue.
4. **Reset.** Non-persistent state returns to reset values (all queues DISABLED, all windows invalid,
   `CTRL.ENABLE=0`, FAULT cleared, in-flight table empty, IRQ status and coalescing cleared, WDT disabled).
5. **Done.** `RESET_STATUS.DONE=1`, `count++`, `RESETTING=0`, `IRQ_STATUS.RESET_DONE` (if enabled).

**Semantics for outstanding work.** Every command that had not published its completion before step 4 is
**abandoned**: no completion will ever be written for it. The driver computes what to retry from the snapshot:
published = `Q_RST_CQ_TAIL − seq_start`, submitted = `Q_RST_SQ_TAIL − seq_start`, consumed = `Q_RST_SQ_HEAD − seq_start`.
Destination memory of an abandoned COPY is undefined within the destination range only. The driver MUST zero
the CQ rings, reprogram windows/queues, and resubmit.

---

## 14. Device-side interfaces

### 14.1 Transport boundary (the replaceable part)

The core's ports are the contract; a transport wrapper only adapts them to a concrete host connection.

| Port group | Direction | Notes |
|---|---|---|
| `s_axil_*` (16-bit address, 32-bit data) | in | register + doorbell access. Always OKAY responses |
| `m_host_*` AXI4 master (64-bit address, `DATA_W`) | out | host IOVA space; INCR bursts, 4 KiB-safe, AW before W, ≤1 outstanding read burst and ≤1 outstanding write burst, fixed ID 0 |
| `m_dev_*` AXI4 master | out | device-local memory; same rules |
| `irq_level[NUM_VECTORS]` | out | levels, §11 |
| `kd_*` | out/in | compute-fabric dispatch, §14.2 |
| `clk`, `rst_n` | in | one clock domain; `rst_n` = hard reset, asynchronous assert, synchronous release done outside |
| `dbg_*` | out | non-functional trace pulses (issue/publish/dma-done) for testbenches; may be left open |

Any clock-domain crossing (e.g. PCIe user clock to core clock) belongs in the wrapper.

### 14.2 Kernel dispatch interface (to the compute fabric)

`kd_valid/kd_ready` (core→fabric): `{tag, cmd_id, kernel_addr, args_addr, args_size, grid_x/y/z, domain}`. A dispatch happens
exactly on a cycle with `kd_valid && kd_ready`. `kd_valid` and its payload hold until ready, **except** that the core withdraws a
dispatch that was never accepted if the command is dropped: its queue left ENABLED, `CTRL.ENABLE` was cleared, a window it depends on
was invalidated (the command then completes `ST_UNAUTHORIZED`), or `kd_abort`/FAULT/reset began. A fabric must therefore act only on `valid && ready`, never on `valid` alone. `kd_done_valid` (fabric→core, single-cycle pulse, no backpressure): `{tag, status[1:0], info[63:0]}` with
`KD_OK / KD_FAULT / KD_ABORTED`; it MUST NOT be asserted in the same cycle as the dispatch handshake (earliest: the next cycle).
`kd_abort` (core→fabric, level): the fabric MUST complete every outstanding dispatch with `KD_ABORTED` within bounded time; if it does
not, a controlled reset ends in `RESET_STATUS.DRAIN_TIMEOUT` (§13) and only a hard reset recovers.
`kd_heartbeat` (fabric→core, optional pulse): proves liveness to the watchdog.

**Fabric contract:** `KD_OK` MUST NOT be reported before the kernel's memory writes have been performed and are
visible to subsequent device-memory accesses. The fabric is responsible for any addressing of device memory it
does with `kernel_addr`/`args_addr` (already authorised by the core in the queue's domain).

**The fabric's own memory accesses are not mediated by SFX-CP.** The core authorises only the kernel entry and argument ranges. A
fabric that serves more than one domain must itself confine what a kernel can reach to that domain's windows; v1 does not export the
window table to the fabric. A kernel's footprint is also not covered by `W_CTRL.BUSY` (§4.2).

---

## 15. Conformance summary

A conforming implementation passes `tests/` against its model (`make test-model`) and, for RTL, against the
Verilated design (`make test-rtl`). `VERIFICATION.md` lists what each test checks and, importantly, what is
**not** covered (formal proof, multi-clock operation, real PCIe/vendor IP, FPGA timing).
