<!-- GENERATED FILE -- do not edit.  Source: spec/sfx_spec.py  (run `make gen`) -->
# SFX-CP register map (ABI 1.0)

All registers are 32 bits wide and must be accessed with aligned 32-bit accesses with all byte strobes set. Reserved space reads as zero and ignores writes (reads of reserved registers never fault; *writes* set `ERR_BAD_REG_ACCESS`). 64-bit quantities are lo/hi register pairs; they are sampled only at a commit action (`W_CTRL` write, `Q_CTRL.ENABLE` write), so torn updates are harmless.

Access: RO read-only, RW read/write, W1C write-1-to-clear, WO write-only (reads 0), WO* write-only doorbell whose read returns the accepted value.

## Page map

| Range | Page | Who may map it |
|---|---|---|
| `0x0000-0x0FFF` | control page (identity, windows, queue config, IRQ, WDT, reset) | **kernel driver only** |
| `0x1000 + q*0x1000` | doorbell page of queue *q* (`DB_SQ_TAIL`, `DB_CQ_HEAD`) | may be mapped into the process that owns queue *q* |

## Global registers (control page)

| Offset | Name | Acc | Reset | Description |
|---|---|---|---|---|
| `0x000` | `ID` | RO | 0x53465843 | Device identity 'SFXC' |
| `0x004` | `VERSION` | RO | 0x01000000 | [31:24] ABI major, [23:16] minor, [15:0] patch |
| `0x008` | `CAPS` | RO | impl | Capability bits CAP_*; unknown bits must be ignored |
| `0x00C` | `GEOMETRY` | RO | impl | [3:0] NUM_QUEUES [15:8] NUM_WINDOWS [19:16] NUM_VECTORS [27:24] INFLIGHT_DEPTH |
| `0x010` | `LIMITS` | RO | impl | [7:0] MAX_RING_LOG2 [15:8] DMA_ALIGN_LOG2 [23:16] DESC_LOG2 [31:24] CQE_LOG2 |
| `0x014` | `MAX_COPY` | RO | 0x40000000 | Largest COPY length in bytes |
| `0x018` | `DEVMEM_LO` | RO | impl | Device address space size (bytes), low |
| `0x01C` | `DEVMEM_HI` | RO | impl | Device address space size (bytes), high |
| `0x020` | `HOST_ADDR_BITS` | RO | impl | Supported host DMA address width in bits |
| `0x024` | `DESC_VERSIONS` | RO | 0x00000002 | Bitmap: bit n set => descriptor layout version n supported |
| `0x028` | `LIMITS2` | RO | 0xFFFF1000 | [15:0] max kernel args bytes, [31:16] max grid dimension |
| `0x030` | `ABI_REQ` | RW | 0 | Driver-requested ABI: [31:16] major [15:0] minor. Required before any queue enable |
| `0x034` | `SCRATCH` | RW | 0 | Software scratch |
| `0x040` | `CTRL` | RW | 0 | [0] ENABLE: allow command fetch/issue |
| `0x044` | `STATUS` | RO | 0x1 | STATUS_* bits |
| `0x048` | `FAULT_CAUSE` | RO | 0 | FAULT_* bits; sticky until controlled reset |
| `0x04C` | `ERR_STATUS` | W1C | 0 | ERR_* sticky bits |
| `0x050` | `ERR_COUNT` | RO | 0 | Number of ERR_* events |
| `0x054` | `DUP_DB_COUNT` | RO | 0 | Doorbells rewriting the current value (benign no-ops) |
| `0x058` | `FAULT_ADDR_LO` | RO | 0 | Address of last DMA/authorisation fault |
| `0x05C` | `FAULT_ADDR_HI` | RO | 0 |  |
| `0x060` | `FAULT_INFO` | RO | 0 | [15:0] ST_* status of the last fault (0x8000 + QERR_* code for a queue-fatal error), [19:16] queue |
| `0x064` | `CMDS_OK` | RO | 0 | Commands published with ST_OK |
| `0x068` | `CMDS_ERR` | RO | 0 | Commands published with status != ST_OK |
| `0x070` | `IRQ_STATUS` | W1C | 0 | IRQ_* cause bits |
| `0x074` | `IRQ_ENABLE` | RW | 0 | Cause mask. Persists across controlled reset |
| `0x078` | `IRQ_MISC_VECTOR` | RW | NUM_QUEUES | Vector for non-completion causes. Persists across controlled reset |
| `0x07C` | `IRQ_FORCE` | WO | - | Write 1s to set IRQ_STATUS bits (driver bring-up) |
| `0x080` | `WDT_CTRL` | RW | 0 | [0] ENABLE (ignored if WDT_TIMEOUT==0) |
| `0x084` | `WDT_TIMEOUT` | RW | 0 | Cycles without progress while work is outstanding |
| `0x088` | `WDT_STATUS` | RW | 0 | WDT_ST_* ; EXPIRED is W1C |
| `0x08C` | `WDT_COUNT` | RO | 0 | Current no-progress count |
| `0x090` | `RESET_CTRL` | WO | - | [31:16] must be RESET_KEY, [0] REQ |
| `0x094` | `RESET_STATUS` | RO | 0 | RST_ST_* ; [31:16] count |
| `0x098` | `RESET_TIMEOUT` | RW | 100000 | Cycles to wait for bus drain; 0 = wait forever. Persists across controlled reset |

## DMA authorisation windows

Window *w* registers live at `0x100 + w*0x20 + offset`.

| Offset | Name | Acc | Description |
|---|---|---|---|
| `+0x00` | `W_BASE_LO` | RW | Window base IOVA / device address, low |
| `+0x04` | `W_BASE_HI` | RW |  |
| `+0x08` | `W_SIZE_LO` | RW | Window size in bytes, low |
| `+0x0C` | `W_SIZE_HI` | RW |  |
| `+0x10` | `W_CTRL` | RW | WIN_* bits. Write last; commits when VALID=1 |

`W_CTRL` bits: `[0]` VALID, `[1]` SPACE (0 host IOVA, 1 device), `[2]` R, `[3]` W, `[11:8]` DOMAIN, read-only `[16]` BUSY, `[17]` ERR.

## Queue registers

Queue *q* registers live at `0x400 + q*0x80 + offset`.

| Offset | Name | Acc | Description |
|---|---|---|---|
| `+0x00` | `Q_CTRL` | RW | [0] ENABLE [11:8] DOMAIN (domain writable only while DISABLED) |
| `+0x04` | `Q_STATUS` | RO | [1:0] STATE [15:8] QERR_* code |
| `+0x08` | `Q_SQ_BASE_LO` | RW | SQ ring base IOVA (64-byte aligned) |
| `+0x0C` | `Q_SQ_BASE_HI` | RW |  |
| `+0x10` | `Q_CQ_BASE_LO` | RW | CQ ring base IOVA (64-byte aligned) |
| `+0x14` | `Q_CQ_BASE_HI` | RW |  |
| `+0x18` | `Q_SIZE` | RW | [4:0] log2 SQ entries, [12:8] log2 CQ entries |
| `+0x1C` | `Q_VECTOR` | RW | Interrupt vector for this queue's completion cause |
| `+0x20` | `Q_SEQ_START` | RW | Initial value of all four ring counters at enable. Multiple of max(SQ,CQ) size |
| `+0x24` | `Q_IRQ_COAL` | RW | [15:0] count threshold, [31:16] timer (TIMER_UNIT clocks); 0 = off |
| `+0x28` | `Q_SQ_HEAD` | RO | Device SQ head: descriptors consumed (free-running) |
| `+0x2C` | `Q_SQ_TAIL` | RO | Accepted SQ tail |
| `+0x30` | `Q_CQ_HEAD` | RO | Accepted CQ head |
| `+0x34` | `Q_CQ_TAIL` | RO | Device CQ tail: completions published |
| `+0x38` | `Q_CMDS_OK` | RO | Completions published OK on this queue |
| `+0x3C` | `Q_CMDS_ERR` | RO | Completions published with error on this queue |
| `+0x40` | `Q_RST_SQ_TAIL` | RO | Snapshot taken when last controlled reset drained |
| `+0x44` | `Q_RST_SQ_HEAD` | RO |  |
| `+0x48` | `Q_RST_CQ_TAIL` | RO |  |

## Doorbell page registers

Doorbell page of queue *q* lives at `0x1000 + q*0x1000`.

| Offset | Name | Acc | Description |
|---|---|---|---|
| `+0x00` | `DB_SQ_TAIL` | WO* | Publish new SQ tail (free-running). Read returns accepted tail |
| `+0x04` | `DB_CQ_HEAD` | WO* | Release CQ entries up to new head. Read returns accepted head |

## Constants: identity

| Name | Value | Meaning |
|---|---|---|
| `SFX_ID_VALUE` | `0x53465843` | 'SFXC' read from ID register |
| `SFX_ABI_MAJOR` | `0x1` | register-map ABI major (incompatible changes) |
| `SFX_ABI_MINOR` | `0x0` | register-map ABI minor (backward-compatible additions) |
| `SFX_ABI_PATCH` | `0x0` | errata level, no ABI effect |
| `SFX_DESC_VERSION` | `0x1` | descriptor/CQE layout version |
| `SFX_RESET_KEY` | `0x5AFE` | must be written in RESET_CTRL[31:16] |

## Constants: limits

| Name | Value | Meaning |
|---|---|---|
| `SFX_DESC_BYTES` | `0x40` | submission queue entry size |
| `SFX_DESC_LOG2` | `0x6` |  |
| `SFX_CQE_BYTES` | `0x20` | completion queue entry size |
| `SFX_CQE_LOG2` | `0x5` |  |
| `SFX_MAX_RING_LOG2` | `0xC` | largest supported ring: 4096 entries |
| `SFX_MIN_RING_LOG2` | `0x1` | smallest supported ring: 2 entries |
| `SFX_MAX_COPY_BYTES` | `0x40000000` | largest single COPY length (1 GiB) |
| `SFX_MAX_ARGS_BYTES` | `0x1000` | largest kernel argument block |
| `SFX_MAX_GRID_DIM` | `0xFFFF` | largest value of any grid dimension |
| `SFX_MAX_QUEUES` | `0x4` | architectural maximum; instance reports actual |
| `SFX_MAX_WINDOWS` | `0x10` | architectural maximum; instance reports actual |
| `SFX_MAX_DOMAINS` | `0x10` | domain id is 4 bits |
| `SFX_TIMER_UNIT` | `0x40` | Q_IRQ_COAL timer unit, in core clocks (model: ticks) |

## Constants: opcode

| Name | Value | Meaning |
|---|---|---|
| `SFX_OP_NOP` | `0x0` | no operation; completes in order |
| `SFX_OP_COPY_H2D` | `0x1` | host IOVA -> device memory |
| `SFX_OP_COPY_D2H` | `0x2` | device memory -> host IOVA |
| `SFX_OP_COPY_D2D` | `0x3` | device memory -> device memory |
| `SFX_OP_KERNEL` | `0x10` | kernel dispatch |
| `SFX_OP_FENCE` | `0x20` | execution barrier, optional host signal write |

## Constants: flag

| Name | Value | Meaning |
|---|---|---|
| `SFX_F_FENCE_BEFORE` | `0x1` | all opcodes: do not issue until every earlier command has retired |
| `SFX_F_IRQ` | `0x2` | all opcodes: raise queue completion interrupt when CQE is visible |
| `SFX_F_FENCE_SCOPE_ALL` | `0x4` | FENCE only: advisory in ABI 1.0 (scope is always all queues) |
| `SFX_F_FENCE_SIGNAL` | `0x8` | FENCE only: write 64-bit value to host address after prior work |
| `SFX_F_VALID_MASK` | `0xF` | all defined flag bits |

## Constants: status

| Name | Value | Meaning |
|---|---|---|
| `SFX_ST_OK` | `0x0` | completion point reached |
| `SFX_ST_BAD_VERSION` | `0x1` | desc_ver not supported |
| `SFX_ST_BAD_OPCODE` | `0x2` | unknown opcode |
| `SFX_ST_BAD_FLAGS` | `0x3` | undefined flag bit, or flag not valid for opcode |
| `SFX_ST_BAD_DESC` | `0x4` | must-be-zero field set, or invalid field value (grid) |
| `SFX_ST_BAD_LENGTH` | `0x5` | zero / too large / not a multiple of DMA_ALIGN |
| `SFX_ST_BAD_ALIGN` | `0x6` | address not a multiple of DMA_ALIGN |
| `SFX_ST_BAD_RANGE` | `0x7` | outside supported address space or wraps |
| `SFX_ST_UNAUTHORIZED` | `0x8` | not inside one driver-authorised window (space/domain/permission) |
| `SFX_ST_DMA_READ_ERR` | `0x9` | bus error response on a read |
| `SFX_ST_DMA_WRITE_ERR` | `0xA` | bus error response on a write |
| `SFX_ST_KERNEL_FAULT` | `0xB` | compute fabric reported a fault; result = fabric info |
| `SFX_ST_ABORTED` | `0xC` | aborted by controlled reset before its completion point |
| `SFX_ST_TIMEOUT` | `0xD` | aborted by watchdog fault before its completion point |

## Constants: qerr

| Name | Value | Meaning |
|---|---|---|
| `SFX_QERR_NONE` | `0x0` |  |
| `SFX_QERR_BAD_SEQ` | `0x1` | descriptor seq field != expected sequence number |
| `SFX_QERR_SQ_FETCH` | `0x2` | bus error fetching a descriptor |
| `SFX_QERR_RING_UNAUTH` | `0x3` | SQ or CQ ring access not inside an authorised window |
| `SFX_QERR_CQ_WRITE` | `0x4` | bus error publishing a completion |
| `SFX_QERR_BAD_CONFIG` | `0x5` | enable-time validation failed |

## Constants: qstate

| Name | Value | Meaning |
|---|---|---|
| `SFX_QS_DISABLED` | `0x0` |  |
| `SFX_QS_ENABLED` | `0x1` |  |
| `SFX_QS_DRAINING` | `0x2` |  |
| `SFX_QS_ERROR` | `0x3` |  |

## Constants: kdstatus

| Name | Value | Meaning |
|---|---|---|
| `SFX_KD_OK` | `0x0` | kernel finished; its writes are performed |
| `SFX_KD_FAULT` | `0x1` | kernel faulted; info is fabric specific |
| `SFX_KD_ABORTED` | `0x2` | kernel stopped by kd_abort |

## Constants: ctrl

| Name | Value | Meaning |
|---|---|---|
| `SFX_CTRL_ENABLE` | `0x1` | global run enable |
| `SFX_STATUS_READY` | `0x1` | out of reset and not RESETTING: registers usable |
| `SFX_STATUS_RUNNING` | `0x2` | CTRL.ENABLE && !FAULT && !RESETTING |
| `SFX_STATUS_FAULT` | `0x4` | watchdog fault; cleared only by controlled reset |
| `SFX_STATUS_RESETTING` | `0x8` |  |
| `SFX_STATUS_IDLE` | `0x10` | no pending, fetched, in-flight or publishing work |
| `SFX_STATUS_ABI_OK` | `0x20` | ABI_REQ accepted |
| `SFX_FAULT_WDT` | `0x1` | FAULT_CAUSE bit |

## Constants: errbits

| Name | Value | Meaning |
|---|---|---|
| `SFX_ERR_BAD_DOORBELL` | `0x1` | invalid doorbell value, or queue not ENABLED |
| `SFX_ERR_BAD_REG_ACCESS` | `0x2` | partial/unaligned write, write to RO/unmapped, bad key |
| `SFX_ERR_BAD_WINDOW` | `0x4` | window commit rejected |
| `SFX_ERR_BAD_QCONFIG` | `0x8` | queue enable rejected |
| `SFX_ERR_BAD_IRQ_CONFIG` | `0x10` | vector out of range |
| `SFX_ERR_CFG_LOCKED` | `0x20` | config write to a locked (enabled/valid) object |

## Constants: irqbits

| Name | Value | Meaning |
|---|---|---|
| `SFX_IRQ_QCPL_LSB` | `0x0` | bit q: queue q completion |
| `SFX_IRQ_QERR_LSB` | `0x4` | bit 4+q: queue q entered ERROR |
| `SFX_IRQ_DEV_ERR` | `0x100` | a new ERR_STATUS bit was set |
| `SFX_IRQ_WDT` | `0x200` | watchdog expired |
| `SFX_IRQ_RESET_DONE` | `0x400` | controlled reset finished |
| `SFX_IRQ_VALID_MASK` | `0x7FF` |  |

## Constants: wdtbits

| Name | Value | Meaning |
|---|---|---|
| `SFX_WDT_CTRL_ENABLE` | `0x1` |  |
| `SFX_WDT_ST_ENABLED` | `0x1` |  |
| `SFX_WDT_ST_ARMED` | `0x2` | work outstanding and counting |
| `SFX_WDT_ST_EXPIRED` | `0x4` | W1C |
| `SFX_WDT_STUCK_LSB` | `0x8` | [11:8] unit mask at expiry |
| `SFX_WDT_STUCK_FRONTEND` | `0x100` |  |
| `SFX_WDT_STUCK_DMA` | `0x200` |  |
| `SFX_WDT_STUCK_KERNEL` | `0x400` |  |
| `SFX_WDT_STUCK_RETIRE` | `0x800` |  |
| `SFX_WDT_COUNT_LSB` | `0x10` | [31:16] expiry count |

## Constants: rstbits

| Name | Value | Meaning |
|---|---|---|
| `SFX_RST_REQ` | `0x1` | RESET_CTRL[0] |
| `SFX_RST_KEY_LSB` | `0x10` | RESET_CTRL[31:16] |
| `SFX_RST_ST_BUSY` | `0x1` |  |
| `SFX_RST_ST_DONE` | `0x2` | cleared when next reset is requested |
| `SFX_RST_ST_DRAIN_TIMEOUT` | `0x4` | outstanding bus transactions never drained |
| `SFX_RST_COUNT_LSB` | `0x10` | [31:16] controlled resets since hard reset |

## Constants: caps

| Name | Value | Meaning |
|---|---|---|
| `SFX_CAP_KERNEL` | `0x1` |  |
| `SFX_CAP_COPY_H2D` | `0x2` |  |
| `SFX_CAP_COPY_D2H` | `0x4` |  |
| `SFX_CAP_COPY_D2D` | `0x8` |  |
| `SFX_CAP_FENCE` | `0x10` |  |
| `SFX_CAP_FENCE_SIGNAL` | `0x20` |  |
| `SFX_CAP_IRQ_COALESCE` | `0x40` |  |
| `SFX_CAP_WATCHDOG` | `0x80` |  |
| `SFX_CAP_SOFT_RESET` | `0x100` |  |
| `SFX_CAP_WINDOW_AUTHZ` | `0x200` | device enforces driver-programmed windows |
| `SFX_CAP_SEQ_START` | `0x400` | Q_SEQ_START supported |

## Descriptor (64 bytes) and completion entry (32 bytes) layout

| Struct | Offset | Field | Notes |
|---|---|---|---|
| SQE | `0x00` | `opcode` | u16 |
| SQE | `0x02` | `flags` | u16 |
| SQE | `0x04` | `seq` | u32 == absolute SQ index of this slot |
| SQE | `0x08` | `cmd_id` | u32 opaque host tag, echoed in CQE |
| SQE | `0x0C` | `desc_ver` | u16 must equal DESC_VERSION |
| SQE | `0x0E` | `rsvd0` | u16 must be zero |
| SQE | `0x10` | `addr0` | u64 COPY src | KERNEL entry | FENCE signal addr |
| SQE | `0x18` | `addr1` | u64 COPY dst | KERNEL args addr |
| SQE | `0x20` | `length` | u32 COPY bytes | KERNEL args bytes |
| SQE | `0x24` | `aux0` | u32 KERNEL grid_x |
| SQE | `0x28` | `aux1` | u32 KERNEL grid_y |
| SQE | `0x2C` | `aux2` | u32 KERNEL grid_z |
| SQE | `0x30` | `value` | u64 FENCE signal value |
| SQE | `0x38` | `rsvd1` | u64 must be zero |
| CQE | `0x00` | `cmd_id` | u32 |
| CQE | `0x04` | `sq_seq` | u32 absolute SQ index of the command |
| CQE | `0x08` | `status` | u16 |
| CQE | `0x0A` | `opcode` | u16 echo of descriptor opcode |
| CQE | `0x0C` | `sq_head` | u32 SQ slots with absolute index < sq_head are reusable |
| CQE | `0x10` | `result` | u64 |
| CQE | `0x18` | `cq_seq` | u32 absolute CQ index of this entry |
| CQE | `0x1C` | `phase` | u32, bit0 = phase; written LAST, as its own write |

