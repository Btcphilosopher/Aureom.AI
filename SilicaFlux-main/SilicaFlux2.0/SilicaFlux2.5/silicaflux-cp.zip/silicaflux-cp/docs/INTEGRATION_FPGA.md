# FPGA / PCIe integration guide

> **Read this first.** This package contains **no PCIe PHY, link layer, transaction layer, TLP
> handling or configuration space**, and it makes **no claim of PCI Express compliance**. The simulation
> wrapper is an AXI test harness, not a PCIe model. The AXI-endpoint wrapper
> (`transport/sfx_transport_axi_ep.sv`) has been exercised **only in simulation against behavioural AXI
> memories** (`tests/tb/tb_transport_axi_ep.sv`); it has **not** been built against any vendor endpoint IP, run
> through any FPGA tool flow, or tried on hardware. Treat everything below as an integration plan, and verify
> each item against your endpoint IP's product guide.

## 1. How the pieces connect

```
 host
  │  PCIe link ── vendor endpoint IP (PHY, link, TLPs, config space, BARs, MSI-X)   ◄── NOT in this package
  │
  │ ┌─ BAR window ─────────  AXI4-Lite master ──► s_axil_*     registers + doorbells
  │ ├─ host-DMA bridge ◄───  AXI4 slave         ◄── m_host_*   device-initiated reads/writes of host memory
  │ ├─ interrupts ◄────────  request / ack       ◄── irq_req/irq_ack  (MSI-X)
  │ └─ reset ──────────────  aresetn, link_up, flr_active
  │
 sfx_transport_axi_ep   (wrapper: reset conditioning, address offset, irq level → request/ack)
 sfx_cp_core            (command processor + DMA)
  │   m_dev_*  AXI4 master ──► on-card memory controller (DDR / HBM / BRAM)
  │   kd_*     dispatch    ◄──► compute fabric (sfx_kernel_null is only a placeholder)
```

`fpga/sfx_fpga_top_example.sv` (generated) instantiates the wrapper and the null fabric with all endpoint-side
signals brought out as plain ports; connect those to your endpoint IP in a block design or your own wrapper.

The **transport boundary is the core's own port list** (SPEC §14.1). Anything specific to *how the host is
connected* belongs in a wrapper that adapts these ports; the core never changes. To target a different bus or
endpoint, write another wrapper (or edit this one) — do not edit the core.

## 2. Requirements the endpoint must meet

| Area | Requirement |
|---|---|
| Register path | AXI4-Lite master, 32-bit data, ≥ 16-bit address, all byte strobes set on writes. The core always answers OKAY. |
| BAR sizing | Control page `0x0000–0x0FFF` + one 4 KiB doorbell page per queue: `0x1000 × (1 + NUM_QUEUES)` bytes, rounded up to a power of two (NUM_QUEUES = 2 → 16 KiB; 4 → 32 KiB). Keep each doorbell page 4 KiB aligned so the OS can map it into one process. |
| Host-DMA path | AXI4 **slave** accepting 64-bit addresses, `DATA_W`-wide data (64/128/256), INCR bursts of ≤ `MAX_BURST_BEATS` beats that never cross 4 KiB, fixed ID 0, **AW issued before W**, at most one outstanding read burst and one outstanding write burst. |
| Byte order | Little-endian. AXI write strobes must map to PCIe byte enables 1:1 (the completion's phase word is written with a 4-byte strobe). |
| Address mapping | The core drives **IOVA** = the PCIe bus address from the OS DMA-mapping API. Configure the endpoint's AXI-to-PCIe translation to pass the address through unchanged, or set `HOST_AXI_OFFSET` (module parameter) so that `AXI address = IOVA + offset`. |
| Ordering | The completion protocol relies on **posted-write ordering**: data writes, then the completion body, then the phase word must not be reordered on the link. Do **not** enable relaxed ordering or ID-based reordering for these writes. |
| Write response | The core waits for each write's **B response** before issuing the next dependent write (data → CQE body → phase word) and before raising an interrupt. For a PCIe bridge, B usually means *accepted by the bridge*, not *visible at the host*; correctness then depends on PCIe ordering (previous row), not on B. Check what your bridge's B means. |
| Reads | Read responses may be split/reordered by the bridge internally but must reach the core as one in-order burst (single outstanding, ID 0). |
| Error responses | Map completion-abort / unsupported-request / poisoned data to SLVERR/DECERR on the AXI read or write response; the core turns them into `ST_DMA_*_ERR` or, for ring accesses, a queue error. |
| Interrupts | One request/acknowledge pair per vector, `NUM_VECTORS = NUM_QUEUES + 1`. The wrapper raises `irq_req[v]` on each rising edge of the core's level and holds it until `irq_ack[v]` pulses. Map vector *v* to MSI-X table entry *v*. If your IP uses fire-and-forget pulses, replace the small handshake block at the end of the wrapper. |
| Reset | `aresetn & link_up & ~flr_active` is synchronised (async assert, 2-flop sync release) and drives the core's hard reset. A function-level reset resets *everything* in the core. |
| Clocking | One clock for the core, register slave and both masters. Put any clock-domain crossing (e.g. PCIe user clock ↔ core clock, memory-controller clock) **outside** the core, in AXI CDC blocks, in the wrapper. |
| Device memory | `m_dev_*` follows the same AXI rules; addresses are device offsets `[0, DEV_MEM_SIZE)`. |

## 3. Things that are the integrator's job

These are open items, not features of this package:

1. **Pin mapping** of the vendor IP's AXI/IRQ/reset ports to the wrapper (names differ per product).
2. **Verifying** the endpoint's AXI-to-PCIe address translation, maximum payload / read-request splitting, the
   meaning of B, relaxed-ordering settings, and outstanding-transaction limits against §2.
3. **MSI-X**: table programming happens in the OS; the core only requests vector numbers.
4. **IOMMU / ATS / PASID**: not used. The device-side *domain* is an internal isolation mechanism between queues;
   it is not a PASID. DMA addresses must be valid bus addresses already produced by the OS.
5. **Timing closure, resource use, clocking constraints, and floorplanning** — none have been measured.
6. **Function-level reset sequencing** and hot-reset behaviour of the endpoint.
7. **Device-memory controller and compute fabric.** Only their interfaces are defined (SPEC §14). `sfx_kernel_null`
   completes after `grid_x·grid_y·grid_z` cycles and is for bring-up only.
8. **Throughput.** v1 issues one burst at a time per bus direction and is correctness-first (§ "Performance" in
   `DESIGN_NOTES.md`). Raise `MAX_BURST_BEATS` / `DATA_W` first; deeper pipelining is future work.

## 4. Bring-up checklist

1. **Link and BAR.** With the endpoint alone, confirm BAR reads/writes reach AXI4-Lite.
2. **Identity.** Read `ID` (`0x53465843`) and `VERSION`; read `GEOMETRY`, `LIMITS`, `CAPS`.
3. **Scratch.** Write/read `SCRATCH`; try a partial write and check `ERR_STATUS.BAD_REG_ACCESS`.
4. **ABI.** Write `ABI_REQ = 1.0`; check `STATUS.ABI_OK`.
5. **Host-DMA loopback.** Allocate coherent memory for rings, program one host window, one device window,
   queue 0; submit `NOP` with `F_IRQ`; poll the CQ phase; verify the MSI-X arrives *after* the CQE is readable.
6. **Copies.** `COPY_H2D` then `COPY_D2H` of increasing sizes crossing 4 KiB; compare. Then a size that is not a multiple of
   `DMA_ALIGN` and confirm `ST_BAD_LENGTH`.
7. **Failure paths.** Unmap a buffer without invalidating the window and confirm the device is the one that stops
   it; try a descriptor pointing at a user virtual address and confirm `ST_UNAUTHORIZED`.
8. **Ordering on a trace.** On a PCIe analyser (or ILA on the AXI port) confirm the sequence *data → CQE body →
   phase word* and that the MSI-X follows the phase word.
9. **Reset.** Exercise controlled reset with outstanding work, then function-level reset.

## 5. What was actually tested here

* `make test-ep` builds `tests/tb/tb_transport_axi_ep.sv` with Verilator (`--binary --timing`): the wrapper passes register
  access and DMA through to the core, the host AXI address equals IOVA + `HOST_AXI_OFFSET` (a behavioural memory
  flags any other address), `irq_req` stays asserted until `irq_ack` and a second request follows a W1C plus a new
  completion, and holding `flr_active` resets the core.
* Nothing above says anything about a real endpoint. See `VERIFICATION.md` for the full list of what is and
  is not covered.
