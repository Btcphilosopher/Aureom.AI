# Design notes (microarchitecture)

SPEC.md says *what* the device does; this file says *how the reference RTL does it* and why, so reviewers can map
each normative rule to the block that enforces it.

## 1. Module map

| Module | Role | Enforces (SPEC §) |
|---|---|---|
| `sfx_axil_slave` | AXI4-Lite slave → single-cycle register bus. AW/W in either order. Always OKAY | 3.5 |
| `sfx_regs` | All programmer-visible state: windows, queue state machines, doorbell validation, IRQ/WDT/reset registers, persistence across soft reset | 3, 4.2, 6, 11–13 |
| `sfx_authz` | Combinational window lookup (space, domain, permission, containment without overflow). Instantiated wherever the device touches memory | 4 |
| `sfx_decode` | Descriptor field extraction and validation in the normative order; operand authorisation | 5.5 |
| `sfx_frontend` | Round-robin queue pick, descriptor fetch, sequence check, issue rules (barrier, `F_FENCE_BEFORE`, unit availability) | 6.3, 7 |
| `sfx_inflight` | Circular table: allocation order = issue order = retire order; completions arrive out of order | 7.4 |
| `sfx_dma` | COPY engine: independent read/write FSMs, speculative/committed FIFO, per-burst authorisation, 4 KiB splitting | 4.1, 8.1–8.3 |
| `sfx_axi_rport`, `sfx_axi_wport` | Burst-level AXI masters with round-robin sharing; AW before W; one burst outstanding | 14.1 |
| `sfx_mem_fabric` | Wires host bus {fetch, DMA, retire} and device bus {DMA} onto the ports | 14.1 |
| `sfx_retire` | In-order completion publisher: fence signal write, two-phase CQE write (CQ-space wait kept as a defensive check; unreachable with CQ credit) | 7.4–7.5, 10.1 |
| `sfx_irq` | Per-queue coalescing (count + timer), cause → vector level mapping, re-arm blanking | 11 |
| `sfx_wdt` | Progress watchdog | 12 |
| `sfx_reset_ctl` | Quiesce → drain → snapshot → soft reset → done, with drain timeout | 13 |
| `sfx_cp_core` | Glue; the port list is the transport contract | 14 |

## 2. Invariants and how they hold

**One window check per memory access.** Descriptor fetch, completion writes, fence signal writes and every DMA
burst are authorised at the moment they are issued; `sfx_dma` re-checks before *each* burst. The authorising windows
are recorded in a *use mask* that the register file reports as `W_CTRL.BUSY`. The mask bit is set on the same clock edge as
the authorisation decision, so an invalidate that races with a decision is linearised: either the decision saw the
window valid and `BUSY` is already visible, or it saw it invalid and the access never starts.

**Read bursts are atomic.** The DMA FIFO has a speculative tail and a committed tail. Beats are written at the
speculative tail; only a burst that finished with all-OKAY responses advances the committed tail. An error rolls the tail
back, so garbage never reaches the write side. The write side sees only the committed count and uses store-and-forward
(a write burst's AW is issued only once all its beats are committed), which also avoids holding the destination bus
while waiting for data. After a *read-side* failure the write side still drains what was committed (shorter final
burst), which is what makes `result` a guaranteed-valid prefix.

**Completion order and visibility.** `sfx_inflight` has no completion-order logic: units mark entries done in any order, and
`sfx_retire` only ever looks at the head. That makes SPEC 7.4 true by construction. `sfx_retire` issues write #2 (phase
word) only after write #1's B response, and the *interrupt event* only after write #2's B response. Because both
writes go through the same single-outstanding write port as DMA data, a completion can never be issued while a data
write to the host bus is still awaiting its response.

**Doorbell race.** A host may legitimately see a completion the instant the phase-word *write* is accepted by the bus — a few
cycles before `Q_CQ_TAIL` counts it. The CQ-head doorbell bound therefore includes one extra entry while a completion is
mid-publication (`cq_pub_inflight`). (An early version compared against the register only and rejected valid doorbells;
the shared test-suite caught it as a deadlock on tiny rings.)

**CQ credit.** The frontend only picks a queue while `(sq_head − cq_head) < CQ size`. Every consumed command publishes at most one completion
and `cq_tail ≤ sq_head`, so a completion slot always exists when retire needs one: retire never waits on the host, the device cannot overwrite an
unreleased slot, and a tenant that stops releasing completions stalls only its own queue (its entries stay unfetched; the watchdog ignores that wait).
This also removes a deadlock an independent review found in the first design — a queue disabled while its CQ was full could not drain, because the
CQ-head doorbell is rejected once the queue leaves ENABLED. `sfx_retire` keeps its CQ-full wait as a defensive check that should be unreachable.

**Fence.** A FENCE is an in-flight entry that is already "done" at issue; its work happens at the retire head, which
by construction is reached only when every earlier command has retired. Commands issued after it are held by the
frontend (`fence_present`) until it leaves the table. `F_FENCE_BEFORE` is the same wait expressed as a flag
(`inflight empty`). Scope is therefore always "all queues" — stronger than requested, hence conforming.

**Queue-fatal errors are never lost.** Frontend and retire can both report one in the same cycle; `sfx_cp_core` latches each
until it is delivered (retire first).

**Soft reset.** `sfx_reset_ctl` asserts `quiesce`, waits for the bus ports, DMA, kernels and retire to be quiet for four
consecutive cycles, pulses `snap` (the register file copies the counters), then holds `soft_rst` for six cycles. All
datapath modules take `rst_n & ~soft_rst`; the register file takes both and keeps a documented persistent subset; the
reset controller and AXI-Lite slave see only the hard reset so the sequence survives itself and the host can poll.
On drain timeout the controller parks in `STUCK`: with a wedged bus, only a hard reset is safe.

## 3. Parameters and elaboration checks

`DATA_W` ∈ {64,128,256}; `NUM_QUEUES` 1–4; `NUM_WINDOWS` 1–16; `MAX_BURST_BEATS` a power of two ≤ 128;
`INFLIGHT_DEPTH` ∈ {2,4,8} (`GEOMETRY` reports it in 4 bits). Violations are `$error`s at elaboration. `DATA_W` = 512 is not supported
because a 32-byte completion would then need lane placement inside the beat.
The suite has been run on (64-bit, 2 queues, 8 windows, burst 16, depth 4) and (256-bit, 4 queues, 16 windows, burst 32,
depth 8); `make lint` also elaborates 128-bit/1-queue/4-window. See `VERIFICATION.md`.

## 4. Deliberate limitations (v1)

* **Throughput.** One outstanding read burst and one outstanding write burst per bus, one COPY at a time, bursts
  ≤ `MAX_BURST_BEATS` beats. This is a correctness-first reference: it is simple enough to reason about every
  ordering claim in SPEC §10. No throughput number has been measured and none is claimed. The scaling path is
  larger bursts / wider data first, then AXI IDs with a small reorder buffer, then multiple DMA channels.
* **Fence scope** is always all-queues; **retire** is global in-order, so a slow command on one queue delays
  completions on another (head-of-line blocking across queues). *Mitigated for one case:* a queue is served only while a CQ slot is
  guaranteed for it (**CQ credit**, SPEC §7.7), so a tenant that never releases its CQ stalls only itself. Slow kernels, a long COPY
  (one DMA engine), `FENCE`/`F_FENCE_BEFORE`, a watchdog fault, and a controlled reset still affect every queue: **no performance or availability
  isolation between tenants in v1.**
* **Kernel memory is not mediated.** The core authorises a kernel's entry and argument ranges only; the fabric's own accesses are the
  fabric's responsibility, and `W_CTRL.BUSY` does not cover them.
* **Alignment.** COPY addresses and lengths must be multiples of `DATA_W/8`; there is no byte-lane realignment.
* **One contiguous IOVA range per command.** Drivers without an IOMMU must split scatter/gather lists into several commands.
* **Windows are not an IOMMU.** They cap what the *device* will touch based on driver-programmed ranges; they do not translate
  addresses and cannot stop a mis-programmed window from authorising memory the driver should not have mapped.
* **No error recovery from a dead bus** other than function-level reset (AXI has no cancel).
* **Single clock domain**; CDC is the wrapper's job.
* **Kernel dispatch** is a handshake interface only; the compute fabric and device memory controller are out of scope.

## 5. Lint and style

`make lint` runs Verilator `-Wall` on the core in three parameter sets plus the simulation wrapper. The remaining waived
classes are cosmetic (`UNUSEDSIGNAL`, `UNUSEDPARAM`, `DECLFILENAME`, `GENUNNAMED`). Sequential logic in `sfx_regs` uses blocking
temporaries (`err_ev`, `irq_set`) for per-cycle event accumulation, with a local `BLKSEQ` waiver.
