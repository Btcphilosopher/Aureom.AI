# RTL line coverage (Verilator, shared suite, all bus profiles)

| File | Line points | Executed | % |
|---|---:|---:|---:|
| `sfx_authz.sv` | 2 | 2 | 100.0 |
| `sfx_axi_rport.sv` | 9 | 9 | 100.0 |
| `sfx_axi_wport.sv` | 11 | 11 | 100.0 |
| `sfx_axil_slave.sv` | 1 | 1 | 100.0 |
| `sfx_cp_core.sv` | 16 | 16 | 100.0 |
| `sfx_decode.sv` | 19 | 19 | 100.0 |
| `sfx_dma.sv` | 20 | 20 | 100.0 |
| `sfx_frontend.sv` | 19 | 19 | 100.0 |
| `sfx_inflight.sv` | 3 | 3 | 100.0 |
| `sfx_irq.sv` | 7 | 7 | 100.0 |
| `sfx_regs.sv` | 125 | 125 | 100.0 |
| `sfx_reset_ctl.sv` | 9 | 9 | 100.0 |
| `sfx_retire.sv` | 32 | 32 | 100.0 |
| `sfx_wdt.sv` | 4 | 4 | 100.0 |
| **total** | **277** | **277** | **100.0** |

Uncovered lines (no instance executed them):

