#!/usr/bin/env python3
"""SilicaFlux Command Processor (SFX-CP) -- machine-readable interface spec.

This file is the single source of truth for every numeric constant shared by
the RTL (rtl/sfx_pkg.sv), the C/C++ software (sw/include/sfx_abi.h) and the
register map document (docs/REGMAP.md).  Do not edit the generated files; edit
this file and run `make gen`.  `make check-gen` fails if they are stale.

Normative prose lives in docs/SPEC.md; where the two disagree, SPEC.md is the
intent and this file is the bug.
"""

# ----------------------------------------------------------------------------
# Constant groups: (group_name, sv_width, [(NAME, value, comment), ...])
# Names are emitted with the SFX_ prefix.
# ----------------------------------------------------------------------------
VERSION_MAJOR = 1
VERSION_MINOR = 0
VERSION_PATCH = 0
DESC_VERSION = 1

GROUPS = []


def group(name, width, items):
    GROUPS.append((name, width, items))


group("identity", 32, [
    ("ID_VALUE",        0x53465843, "'SFXC' read from ID register"),
    ("ABI_MAJOR",       VERSION_MAJOR, "register-map ABI major (incompatible changes)"),
    ("ABI_MINOR",       VERSION_MINOR, "register-map ABI minor (backward-compatible additions)"),
    ("ABI_PATCH",       VERSION_PATCH, "errata level, no ABI effect"),
    ("DESC_VERSION",    DESC_VERSION, "descriptor/CQE layout version"),
    ("RESET_KEY",       0x5AFE, "must be written in RESET_CTRL[31:16]"),
])

group("limits", 32, [
    ("DESC_BYTES",      64, "submission queue entry size"),
    ("DESC_LOG2",       6, ""),
    ("CQE_BYTES",       32, "completion queue entry size"),
    ("CQE_LOG2",        5, ""),
    ("MAX_RING_LOG2",   12, "largest supported ring: 4096 entries"),
    ("MIN_RING_LOG2",   1, "smallest supported ring: 2 entries"),
    ("MAX_COPY_BYTES",  0x40000000, "largest single COPY length (1 GiB)"),
    ("MAX_ARGS_BYTES",  4096, "largest kernel argument block"),
    ("MAX_GRID_DIM",    65535, "largest value of any grid dimension"),
    ("MAX_QUEUES",      4, "architectural maximum; instance reports actual"),
    ("MAX_WINDOWS",     16, "architectural maximum; instance reports actual"),
    ("MAX_DOMAINS",     16, "domain id is 4 bits"),
    ("TIMER_UNIT",      64, "Q_IRQ_COAL timer unit, in core clocks (model: ticks)"),
])

group("opcode", 16, [
    ("OP_NOP",          0x0000, "no operation; completes in order"),
    ("OP_COPY_H2D",     0x0001, "host IOVA -> device memory"),
    ("OP_COPY_D2H",     0x0002, "device memory -> host IOVA"),
    ("OP_COPY_D2D",     0x0003, "device memory -> device memory"),
    ("OP_KERNEL",       0x0010, "kernel dispatch"),
    ("OP_FENCE",        0x0020, "execution barrier, optional host signal write"),
])

group("flag", 16, [
    ("F_FENCE_BEFORE",  0x0001, "all opcodes: do not issue until every earlier command has retired"),
    ("F_IRQ",           0x0002, "all opcodes: raise queue completion interrupt when CQE is visible"),
    ("F_FENCE_SCOPE_ALL", 0x0004, "FENCE only: advisory in ABI 1.0 (scope is always all queues)"),
    ("F_FENCE_SIGNAL",  0x0008, "FENCE only: write 64-bit value to host address after prior work"),
    ("F_VALID_MASK",    0x000F, "all defined flag bits"),
])

group("status", 16, [
    ("ST_OK",           0x0000, "completion point reached"),
    ("ST_BAD_VERSION",  0x0001, "desc_ver not supported"),
    ("ST_BAD_OPCODE",   0x0002, "unknown opcode"),
    ("ST_BAD_FLAGS",    0x0003, "undefined flag bit, or flag not valid for opcode"),
    ("ST_BAD_DESC",     0x0004, "must-be-zero field set, or invalid field value (grid)"),
    ("ST_BAD_LENGTH",   0x0005, "zero / too large / not a multiple of DMA_ALIGN"),
    ("ST_BAD_ALIGN",    0x0006, "address not a multiple of DMA_ALIGN"),
    ("ST_BAD_RANGE",    0x0007, "outside supported address space or wraps"),
    ("ST_UNAUTHORIZED", 0x0008, "not inside one driver-authorised window (space/domain/permission)"),
    ("ST_DMA_READ_ERR", 0x0009, "bus error response on a read"),
    ("ST_DMA_WRITE_ERR", 0x000A, "bus error response on a write"),
    ("ST_KERNEL_FAULT", 0x000B, "compute fabric reported a fault; result = fabric info"),
    ("ST_ABORTED",      0x000C, "aborted by controlled reset before its completion point"),
    ("ST_TIMEOUT",      0x000D, "aborted by watchdog fault before its completion point"),
])

group("qerr", 8, [
    ("QERR_NONE",         0, ""),
    ("QERR_BAD_SEQ",      1, "descriptor seq field != expected sequence number"),
    ("QERR_SQ_FETCH",     2, "bus error fetching a descriptor"),
    ("QERR_RING_UNAUTH",  3, "SQ or CQ ring access not inside an authorised window"),
    ("QERR_CQ_WRITE",     4, "bus error publishing a completion"),
    ("QERR_BAD_CONFIG",   5, "enable-time validation failed"),
])

group("qstate", 2, [
    ("QS_DISABLED",     0, ""),
    ("QS_ENABLED",      1, ""),
    ("QS_DRAINING",     2, ""),
    ("QS_ERROR",        3, ""),
])

group("kdstatus", 2, [
    ("KD_OK",           0, "kernel finished; its writes are performed"),
    ("KD_FAULT",        1, "kernel faulted; info is fabric specific"),
    ("KD_ABORTED",      2, "kernel stopped by kd_abort"),
])

group("space", 1, [
    ("SPACE_HOST",      0, "host DMA (IOVA) address space"),
    ("SPACE_DEV",       1, "device-local memory address space"),
])

group("layout", 32, [
    # descriptor byte offsets
    ("D_OPCODE",    0x00, "u16"),
    ("D_FLAGS",     0x02, "u16"),
    ("D_SEQ",       0x04, "u32 == absolute SQ index of this slot"),
    ("D_CMD_ID",    0x08, "u32 opaque host tag, echoed in CQE"),
    ("D_DESC_VER",  0x0C, "u16 must equal DESC_VERSION"),
    ("D_RSVD0",     0x0E, "u16 must be zero"),
    ("D_ADDR0",     0x10, "u64 COPY src | KERNEL entry | FENCE signal addr"),
    ("D_ADDR1",     0x18, "u64 COPY dst | KERNEL args addr"),
    ("D_LENGTH",    0x20, "u32 COPY bytes | KERNEL args bytes"),
    ("D_AUX0",      0x24, "u32 KERNEL grid_x"),
    ("D_AUX1",      0x28, "u32 KERNEL grid_y"),
    ("D_AUX2",      0x2C, "u32 KERNEL grid_z"),
    ("D_VALUE",     0x30, "u64 FENCE signal value"),
    ("D_RSVD1",     0x38, "u64 must be zero"),
    # completion entry byte offsets
    ("C_CMD_ID",    0x00, "u32"),
    ("C_SQ_SEQ",    0x04, "u32 absolute SQ index of the command"),
    ("C_STATUS",    0x08, "u16"),
    ("C_OPCODE",    0x0A, "u16 echo of descriptor opcode"),
    ("C_SQ_HEAD",   0x0C, "u32 SQ slots with absolute index < sq_head are reusable"),
    ("C_RESULT",    0x10, "u64"),
    ("C_CQ_SEQ",    0x18, "u32 absolute CQ index of this entry"),
    ("C_PHASE",     0x1C, "u32, bit0 = phase; written LAST, as its own write"),
])

# Window control register bits
group("winctl", 32, [
    ("WIN_VALID",   1 << 0, "write 1: commit window; write 0: invalidate"),
    ("WIN_SPACE",   1 << 1, "0 host IOVA, 1 device"),
    ("WIN_R",       1 << 2, "device may read"),
    ("WIN_W",       1 << 3, "device may write"),
    ("WIN_DOM_LSB", 8, "domain id [11:8]"),
    ("WIN_DOM_MASK", 0xF << 8, ""),
    ("WIN_BUSY",    1 << 16, "read: window referenced by an in-flight device access"),
    ("WIN_ERR",     1 << 17, "read: last commit rejected; cleared by an invalidate write or a successful commit"),
])

group("qctl", 32, [
    ("QCTL_ENABLE",   1 << 0, ""),
    ("QCTL_DOM_LSB",  8, "domain id [11:8]"),
    ("QCTL_DOM_MASK", 0xF << 8, ""),
    ("QSTAT_STATE_MASK", 0x3, "Q_STATUS[1:0]"),
    ("QSTAT_ERR_LSB", 8, "Q_STATUS[15:8] = QERR_*"),
    ("QSIZE_SQ_MASK", 0x1F, "Q_SIZE[4:0]"),
    ("QSIZE_CQ_LSB",  8, "Q_SIZE[12:8]"),
    ("QSIZE_CQ_MASK", 0x1F << 8, ""),
])

group("ctrl", 32, [
    ("CTRL_ENABLE",  1 << 0, "global run enable"),
    ("STATUS_READY", 1 << 0, "out of reset and not RESETTING: registers usable"),
    ("STATUS_RUNNING", 1 << 1, "CTRL.ENABLE && !FAULT && !RESETTING"),
    ("STATUS_FAULT", 1 << 2, "watchdog fault; cleared only by controlled reset"),
    ("STATUS_RESETTING", 1 << 3, ""),
    ("STATUS_IDLE",  1 << 4, "no pending, fetched, in-flight or publishing work"),
    ("STATUS_ABI_OK", 1 << 5, "ABI_REQ accepted"),
    ("FAULT_WDT",    1 << 0, "FAULT_CAUSE bit"),
])

group("errbits", 32, [
    ("ERR_BAD_DOORBELL",   1 << 0, "invalid doorbell value, or queue not ENABLED"),
    ("ERR_BAD_REG_ACCESS", 1 << 1, "partial/unaligned write, write to RO/unmapped, bad key"),
    ("ERR_BAD_WINDOW",     1 << 2, "window commit rejected"),
    ("ERR_BAD_QCONFIG",    1 << 3, "queue enable rejected"),
    ("ERR_BAD_IRQ_CONFIG", 1 << 4, "vector out of range"),
    ("ERR_CFG_LOCKED",     1 << 5, "config write to a locked (enabled/valid) object"),
])

group("irqbits", 32, [
    ("IRQ_QCPL_LSB",  0, "bit q: queue q completion"),
    ("IRQ_QERR_LSB",  4, "bit 4+q: queue q entered ERROR"),
    ("IRQ_DEV_ERR",   1 << 8, "a new ERR_STATUS bit was set"),
    ("IRQ_WDT",       1 << 9, "watchdog expired"),
    ("IRQ_RESET_DONE", 1 << 10, "controlled reset finished"),
    ("IRQ_VALID_MASK", (0xF << 0) | (0xF << 4) | (1 << 8) | (1 << 9) | (1 << 10), ""),
])

group("wdtbits", 32, [
    ("WDT_CTRL_ENABLE", 1 << 0, ""),
    ("WDT_ST_ENABLED",  1 << 0, ""),
    ("WDT_ST_ARMED",    1 << 1, "work outstanding and counting"),
    ("WDT_ST_EXPIRED",  1 << 2, "W1C"),
    ("WDT_STUCK_LSB",   8, "[11:8] unit mask at expiry"),
    ("WDT_STUCK_FRONTEND", 1 << 8, ""),
    ("WDT_STUCK_DMA",   1 << 9, ""),
    ("WDT_STUCK_KERNEL", 1 << 10, ""),
    ("WDT_STUCK_RETIRE", 1 << 11, ""),
    ("WDT_COUNT_LSB",   16, "[31:16] expiry count"),
])

group("rstbits", 32, [
    ("RST_REQ",         1 << 0, "RESET_CTRL[0]"),
    ("RST_KEY_LSB",     16, "RESET_CTRL[31:16]"),
    ("RST_ST_BUSY",     1 << 0, ""),
    ("RST_ST_DONE",     1 << 1, "cleared when next reset is requested"),
    ("RST_ST_DRAIN_TIMEOUT", 1 << 2, "outstanding bus transactions never drained"),
    ("RST_COUNT_LSB",   16, "[31:16] controlled resets since hard reset"),
])

group("caps", 32, [
    ("CAP_KERNEL",      1 << 0, ""),
    ("CAP_COPY_H2D",    1 << 1, ""),
    ("CAP_COPY_D2H",    1 << 2, ""),
    ("CAP_COPY_D2D",    1 << 3, ""),
    ("CAP_FENCE",       1 << 4, ""),
    ("CAP_FENCE_SIGNAL", 1 << 5, ""),
    ("CAP_IRQ_COALESCE", 1 << 6, ""),
    ("CAP_WATCHDOG",    1 << 7, ""),
    ("CAP_SOFT_RESET",  1 << 8, ""),
    ("CAP_WINDOW_AUTHZ", 1 << 9, "device enforces driver-programmed windows"),
    ("CAP_SEQ_START",   1 << 10, "Q_SEQ_START supported"),
])

# ----------------------------------------------------------------------------
# Register map.  (offset, NAME, access, reset, description)
# access: RO RW W1C WO ;   reset is documentation only (RTL/model are normative)
# ----------------------------------------------------------------------------
GLOBAL_REGS = [
    (0x000, "ID",           "RO",  "0x53465843", "Device identity 'SFXC'"),
    (0x004, "VERSION",      "RO",  "0x01000000", "[31:24] ABI major, [23:16] minor, [15:0] patch"),
    (0x008, "CAPS",         "RO",  "impl",       "Capability bits CAP_*; unknown bits must be ignored"),
    (0x00C, "GEOMETRY",     "RO",  "impl",       "[3:0] NUM_QUEUES [15:8] NUM_WINDOWS [19:16] NUM_VECTORS [27:24] INFLIGHT_DEPTH"),
    (0x010, "LIMITS",       "RO",  "impl",       "[7:0] MAX_RING_LOG2 [15:8] DMA_ALIGN_LOG2 [23:16] DESC_LOG2 [31:24] CQE_LOG2"),
    (0x014, "MAX_COPY",     "RO",  "0x40000000", "Largest COPY length in bytes"),
    (0x018, "DEVMEM_LO",    "RO",  "impl",       "Device address space size (bytes), low"),
    (0x01C, "DEVMEM_HI",    "RO",  "impl",       "Device address space size (bytes), high"),
    (0x020, "HOST_ADDR_BITS", "RO", "impl",      "Supported host DMA address width in bits"),
    (0x024, "DESC_VERSIONS", "RO", "0x00000002", "Bitmap: bit n set => descriptor layout version n supported"),
    (0x028, "LIMITS2",      "RO",  "0xFFFF1000", "[15:0] max kernel args bytes, [31:16] max grid dimension"),
    (0x030, "ABI_REQ",      "RW",  "0",          "Driver-requested ABI: [31:16] major [15:0] minor. Required before any queue enable"),
    (0x034, "SCRATCH",      "RW",  "0",          "Software scratch"),
    (0x040, "CTRL",         "RW",  "0",          "[0] ENABLE: allow command fetch/issue"),
    (0x044, "STATUS",       "RO",  "0x1",        "STATUS_* bits"),
    (0x048, "FAULT_CAUSE",  "RO",  "0",          "FAULT_* bits; sticky until controlled reset"),
    (0x04C, "ERR_STATUS",   "W1C", "0",          "ERR_* sticky bits"),
    (0x050, "ERR_COUNT",    "RO",  "0",          "Number of ERR_* events"),
    (0x054, "DUP_DB_COUNT", "RO",  "0",          "Doorbells rewriting the current value (benign no-ops)"),
    (0x058, "FAULT_ADDR_LO", "RO", "0",          "Address of last DMA/authorisation fault"),
    (0x05C, "FAULT_ADDR_HI", "RO", "0",          ""),
    (0x060, "FAULT_INFO",   "RO",  "0",          "[15:0] ST_* status of the last fault (0x8000 + QERR_* code for a queue-fatal error), [19:16] queue"),
    (0x064, "CMDS_OK",      "RO",  "0",          "Commands published with ST_OK"),
    (0x068, "CMDS_ERR",     "RO",  "0",          "Commands published with status != ST_OK"),
    (0x070, "IRQ_STATUS",   "W1C", "0",          "IRQ_* cause bits"),
    (0x074, "IRQ_ENABLE",   "RW",  "0",          "Cause mask. Persists across controlled reset"),
    (0x078, "IRQ_MISC_VECTOR", "RW", "NUM_QUEUES", "Vector for non-completion causes. Persists across controlled reset"),
    (0x07C, "IRQ_FORCE",    "WO",  "-",          "Write 1s to set IRQ_STATUS bits (driver bring-up)"),
    (0x080, "WDT_CTRL",     "RW",  "0",          "[0] ENABLE (ignored if WDT_TIMEOUT==0)"),
    (0x084, "WDT_TIMEOUT",  "RW",  "0",          "Cycles without progress while work is outstanding"),
    (0x088, "WDT_STATUS",   "RW",  "0",          "WDT_ST_* ; EXPIRED is W1C"),
    (0x08C, "WDT_COUNT",    "RO",  "0",          "Current no-progress count"),
    (0x090, "RESET_CTRL",   "WO",  "-",          "[31:16] must be RESET_KEY, [0] REQ"),
    (0x094, "RESET_STATUS", "RO",  "0",          "RST_ST_* ; [31:16] count"),
    (0x098, "RESET_TIMEOUT", "RW", "100000",     "Cycles to wait for bus drain; 0 = wait forever. Persists across controlled reset"),
]

# window w registers at WIN_BASE + w*WIN_STRIDE
WIN_BASE = 0x100
WIN_STRIDE = 0x20
WIN_REGS = [
    (0x00, "W_BASE_LO", "RW", "Window base IOVA / device address, low"),
    (0x04, "W_BASE_HI", "RW", ""),
    (0x08, "W_SIZE_LO", "RW", "Window size in bytes, low"),
    (0x0C, "W_SIZE_HI", "RW", ""),
    (0x10, "W_CTRL",    "RW", "WIN_* bits. Write last; commits when VALID=1"),
]

# queue q registers at Q_BASE + q*Q_STRIDE
Q_BASE = 0x400
Q_STRIDE = 0x80
Q_REGS = [
    (0x00, "Q_CTRL",      "RW", "[0] ENABLE [11:8] DOMAIN (domain writable only while DISABLED)"),
    (0x04, "Q_STATUS",    "RO", "[1:0] STATE [15:8] QERR_* code"),
    (0x08, "Q_SQ_BASE_LO", "RW", "SQ ring base IOVA (64-byte aligned)"),
    (0x0C, "Q_SQ_BASE_HI", "RW", ""),
    (0x10, "Q_CQ_BASE_LO", "RW", "CQ ring base IOVA (64-byte aligned)"),
    (0x14, "Q_CQ_BASE_HI", "RW", ""),
    (0x18, "Q_SIZE",      "RW", "[4:0] log2 SQ entries, [12:8] log2 CQ entries"),
    (0x1C, "Q_VECTOR",    "RW", "Interrupt vector for this queue's completion cause"),
    (0x20, "Q_SEQ_START", "RW", "Initial value of all four ring counters at enable. Multiple of max(SQ,CQ) size"),
    (0x24, "Q_IRQ_COAL",  "RW", "[15:0] count threshold, [31:16] timer (TIMER_UNIT clocks); 0 = off"),
    (0x28, "Q_SQ_HEAD",   "RO", "Device SQ head: descriptors consumed (free-running)"),
    (0x2C, "Q_SQ_TAIL",   "RO", "Accepted SQ tail"),
    (0x30, "Q_CQ_HEAD",   "RO", "Accepted CQ head"),
    (0x34, "Q_CQ_TAIL",   "RO", "Device CQ tail: completions published"),
    (0x38, "Q_CMDS_OK",   "RO", "Completions published OK on this queue"),
    (0x3C, "Q_CMDS_ERR",  "RO", "Completions published with error on this queue"),
    (0x40, "Q_RST_SQ_TAIL", "RO", "Snapshot taken when last controlled reset drained"),
    (0x44, "Q_RST_SQ_HEAD", "RO", ""),
    (0x48, "Q_RST_CQ_TAIL", "RO", ""),
]

# doorbell page for queue q at DB_BASE + q*DB_STRIDE
DB_BASE = 0x1000
DB_STRIDE = 0x1000
DB_REGS = [
    (0x00, "DB_SQ_TAIL", "WO*", "Publish new SQ tail (free-running). Read returns accepted tail"),
    (0x04, "DB_CQ_HEAD", "WO*", "Release CQ entries up to new head. Read returns accepted head"),
]


# ----------------------------------------------------------------------------
# Generators
# ----------------------------------------------------------------------------
def _sv_lit(width, v):
    if width == 1:
        return "1'b%d" % v
    return "%d'h%X" % (width, v)


def emit_sv():
    o = []
    o.append("// GENERATED FILE -- do not edit.  Source: spec/sfx_spec.py  (run `make gen`)")
    o.append("package sfx_pkg;")
    o.append("")
    for name, width, items in GROUPS:
        o.append("  // ---- %s" % name)
        for n, v, c in items:
            lit = _sv_lit(width, v) if width <= 32 else "%d'h%X" % (width, v)
            if width == 1:
                o.append("  localparam logic SFX_%s = %s;%s" % (n, lit, ("  // " + c) if c else ""))
            else:
                o.append("  localparam logic [%d:0] SFX_%s = %s;%s" %
                         (width - 1, n, lit, ("  // " + c) if c else ""))
        o.append("")
    # register offsets
    o.append("  // ---- register offsets (control page, byte offsets)")
    for off, n, a, r, d in GLOBAL_REGS:
        o.append("  localparam logic [15:0] SFX_R_%s = 16'h%04X;" % (n, off))
    o.append("  localparam logic [15:0] SFX_WIN_BASE   = 16'h%04X;" % WIN_BASE)
    o.append("  localparam logic [15:0] SFX_WIN_STRIDE = 16'h%04X;" % WIN_STRIDE)
    for off, n, a, d in WIN_REGS:
        o.append("  localparam logic [15:0] SFX_R_%s = 16'h%04X;" % (n, off))
    o.append("  localparam logic [15:0] SFX_Q_BASE     = 16'h%04X;" % Q_BASE)
    o.append("  localparam logic [15:0] SFX_Q_STRIDE   = 16'h%04X;" % Q_STRIDE)
    for off, n, a, d in Q_REGS:
        o.append("  localparam logic [15:0] SFX_R_%s = 16'h%04X;" % (n, off))
    o.append("  localparam logic [15:0] SFX_DB_BASE    = 16'h%04X;" % DB_BASE)
    o.append("  localparam logic [15:0] SFX_DB_STRIDE  = 16'h%04X;" % DB_STRIDE)
    for off, n, a, d in DB_REGS:
        o.append("  localparam logic [15:0] SFX_R_%s = 16'h%04X;" % (n, off))
    o.append("")
    o.append(SV_TAIL)
    o.append("endpackage")
    return "\n".join(o) + "\n"


SV_TAIL = r"""
  // ---- shared types ------------------------------------------------------
  // In-flight command table entry (sfx_inflight / sfx_frontend / sfx_retire)
  typedef struct packed {
    logic [1:0]  q;          // queue index
    logic [31:0] seq;        // absolute SQ index
    logic [31:0] cmd_id;
    logic [15:0] opcode;
    logic [15:0] flags;
    logic [15:0] status;
    logic [63:0] result;
    logic        sig_en;     // FENCE with SIGNAL and valid descriptor
    logic [63:0] sig_addr;
    logic [63:0] sig_val;
    logic [3:0]  domain;
    logic        is_kernel;  // issued to compute fabric
  } inf_t;

  // 256-bit completion queue entry, little-endian byte order (byte 0 = bits [7:0])
  function automatic logic [255:0] cqe_pack(
      input logic [31:0] cmd_id, input logic [31:0] sq_seq, input logic [15:0] status,
      input logic [15:0] opcode, input logic [31:0] sq_head, input logic [63:0] result,
      input logic [31:0] cq_seq, input logic phase);
    cqe_pack = {{31'b0, phase}, cq_seq, result, sq_head, opcode, status, sq_seq, cmd_id};
  endfunction
"""


def emit_c():
    o = []
    o.append("/* GENERATED FILE -- do not edit.  Source: spec/sfx_spec.py  (run `make gen`) */")
    o.append("#ifndef SFX_ABI_H")
    o.append("#define SFX_ABI_H")
    o.append("#include <stdint.h>")
    o.append("#ifdef __cplusplus")
    o.append("extern \"C\" {")
    o.append("#endif")
    o.append("")
    for name, width, items in GROUPS:
        o.append("/* ---- %s */" % name)
        for n, v, c in items:
            suffix = "u"
            if v > 0x7FFFFFFF:
                suffix = "u"
            o.append("#define SFX_%-22s 0x%Xu%s" % (n, v, ("  /* " + c + " */") if c else ""))
        o.append("")
    o.append("/* ---- register offsets */")
    for off, n, a, r, d in GLOBAL_REGS:
        o.append("#define SFX_R_%-20s 0x%04Xu" % (n, off))
    o.append("#define SFX_WIN_BASE   0x%04Xu" % WIN_BASE)
    o.append("#define SFX_WIN_STRIDE 0x%04Xu" % WIN_STRIDE)
    for off, n, a, d in WIN_REGS:
        o.append("#define SFX_R_%-20s 0x%04Xu" % (n, off))
    o.append("#define SFX_Q_BASE     0x%04Xu" % Q_BASE)
    o.append("#define SFX_Q_STRIDE   0x%04Xu" % Q_STRIDE)
    for off, n, a, d in Q_REGS:
        o.append("#define SFX_R_%-20s 0x%04Xu" % (n, off))
    o.append("#define SFX_DB_BASE    0x%04Xu" % DB_BASE)
    o.append("#define SFX_DB_STRIDE  0x%04Xu" % DB_STRIDE)
    for off, n, a, d in DB_REGS:
        o.append("#define SFX_R_%-20s 0x%04Xu" % (n, off))
    o.append("")
    o.append("#define SFX_WIN_REG(w, reg) (SFX_WIN_BASE + (w) * SFX_WIN_STRIDE + (reg))")
    o.append("#define SFX_Q_REG(q, reg)   (SFX_Q_BASE + (q) * SFX_Q_STRIDE + (reg))")
    o.append("#define SFX_DB_REG(q, reg)  (SFX_DB_BASE + (q) * SFX_DB_STRIDE + (reg))")
    o.append("")
    o.append(C_TAIL)
    o.append("#ifdef __cplusplus")
    o.append("}")
    o.append("#endif")
    o.append("#endif /* SFX_ABI_H */")
    return "\n".join(o) + "\n"


C_TAIL = r"""
/* ---- wire structures (little-endian; all fields naturally aligned) ---- */
#pragma pack(push, 1)
typedef struct sfx_desc {
    uint16_t opcode;      /* 0x00 */
    uint16_t flags;       /* 0x02 */
    uint32_t seq;         /* 0x04 */
    uint32_t cmd_id;      /* 0x08 */
    uint16_t desc_ver;    /* 0x0C */
    uint16_t rsvd0;       /* 0x0E */
    uint64_t addr0;       /* 0x10 */
    uint64_t addr1;       /* 0x18 */
    uint32_t length;      /* 0x20 */
    uint32_t aux0;        /* 0x24 */
    uint32_t aux1;        /* 0x28 */
    uint32_t aux2;        /* 0x2C */
    uint64_t value;       /* 0x30 */
    uint64_t rsvd1;       /* 0x38 */
} sfx_desc_t;

typedef struct sfx_cqe {
    uint32_t cmd_id;      /* 0x00 */
    uint32_t sq_seq;      /* 0x04 */
    uint16_t status;      /* 0x08 */
    uint16_t opcode;      /* 0x0A */
    uint32_t sq_head;     /* 0x0C */
    uint64_t result;      /* 0x10 */
    uint32_t cq_seq;      /* 0x18 */
    uint32_t phase_word;  /* 0x1C  bit0 = phase */
} sfx_cqe_t;
#pragma pack(pop)

#ifdef __cplusplus
static_assert(sizeof(sfx_desc_t) == SFX_DESC_BYTES, "descriptor size");
static_assert(sizeof(sfx_cqe_t) == SFX_CQE_BYTES, "cqe size");
#define SFX_STATIC_INLINE static inline
#else
_Static_assert(sizeof(sfx_desc_t) == SFX_DESC_BYTES, "descriptor size");
_Static_assert(sizeof(sfx_cqe_t) == SFX_CQE_BYTES, "cqe size");
#define SFX_STATIC_INLINE static inline
#endif

/* Phase the device writes into the CQE with absolute index n.
 * Lap 0 (the first pass after enable) is phase 1, so zero-initialised memory
 * never looks valid.  seq_start must be a multiple of the CQ size. */
SFX_STATIC_INLINE uint32_t sfx_cq_phase(uint32_t n, uint32_t seq_start, uint32_t cq_log2)
{
    return (((n - seq_start) >> cq_log2) & 1u) ^ 1u;
}

SFX_STATIC_INLINE const char *sfx_status_str(uint16_t st)
{
    switch (st) {
    case SFX_ST_OK: return "OK";
    case SFX_ST_BAD_VERSION: return "BAD_VERSION";
    case SFX_ST_BAD_OPCODE: return "BAD_OPCODE";
    case SFX_ST_BAD_FLAGS: return "BAD_FLAGS";
    case SFX_ST_BAD_DESC: return "BAD_DESC";
    case SFX_ST_BAD_LENGTH: return "BAD_LENGTH";
    case SFX_ST_BAD_ALIGN: return "BAD_ALIGN";
    case SFX_ST_BAD_RANGE: return "BAD_RANGE";
    case SFX_ST_UNAUTHORIZED: return "UNAUTHORIZED";
    case SFX_ST_DMA_READ_ERR: return "DMA_READ_ERR";
    case SFX_ST_DMA_WRITE_ERR: return "DMA_WRITE_ERR";
    case SFX_ST_KERNEL_FAULT: return "KERNEL_FAULT";
    case SFX_ST_ABORTED: return "ABORTED";
    case SFX_ST_TIMEOUT: return "TIMEOUT";
    default: return "?";
    }
}

SFX_STATIC_INLINE const char *sfx_qerr_str(uint8_t e)
{
    switch (e) {
    case SFX_QERR_NONE: return "NONE";
    case SFX_QERR_BAD_SEQ: return "BAD_SEQ";
    case SFX_QERR_SQ_FETCH: return "SQ_FETCH";
    case SFX_QERR_RING_UNAUTH: return "RING_UNAUTH";
    case SFX_QERR_CQ_WRITE: return "CQ_WRITE";
    case SFX_QERR_BAD_CONFIG: return "BAD_CONFIG";
    default: return "?";
    }
}
"""


def emit_regmap_md():
    o = []
    o.append("<!-- GENERATED FILE -- do not edit.  Source: spec/sfx_spec.py  (run `make gen`) -->")
    o.append("# SFX-CP register map (ABI %d.%d)" % (VERSION_MAJOR, VERSION_MINOR))
    o.append("")
    o.append("All registers are 32 bits wide and must be accessed with aligned 32-bit "
             "accesses with all byte strobes set. Reserved space reads as zero and ignores writes "
             "(reads of reserved registers never fault; *writes* set `ERR_BAD_REG_ACCESS`). "
             "64-bit quantities are lo/hi register pairs; they are sampled only at a commit "
             "action (`W_CTRL` write, `Q_CTRL.ENABLE` write), so torn updates are harmless.")
    o.append("")
    o.append("Access: RO read-only, RW read/write, W1C write-1-to-clear, WO write-only (reads 0), "
             "WO* write-only doorbell whose read returns the accepted value.")
    o.append("")
    o.append("## Page map")
    o.append("")
    o.append("| Range | Page | Who may map it |")
    o.append("|---|---|---|")
    o.append("| `0x0000-0x0FFF` | control page (identity, windows, queue config, IRQ, WDT, reset) | **kernel driver only** |")
    o.append("| `0x1000 + q*0x1000` | doorbell page of queue *q* (`DB_SQ_TAIL`, `DB_CQ_HEAD`) | may be mapped into the process that owns queue *q* |")
    o.append("")
    o.append("## Global registers (control page)")
    o.append("")
    o.append("| Offset | Name | Acc | Reset | Description |")
    o.append("|---|---|---|---|---|")
    for off, n, a, r, d in GLOBAL_REGS:
        o.append("| `0x%03X` | `%s` | %s | %s | %s |" % (off, n, a, r, d))
    o.append("")
    o.append("## DMA authorisation windows")
    o.append("")
    o.append("Window *w* registers live at `0x%03X + w*0x%02X + offset`." % (WIN_BASE, WIN_STRIDE))
    o.append("")
    o.append("| Offset | Name | Acc | Description |")
    o.append("|---|---|---|---|")
    for off, n, a, d in WIN_REGS:
        o.append("| `+0x%02X` | `%s` | %s | %s |" % (off, n, a, d))
    o.append("")
    o.append("`W_CTRL` bits: `[0]` VALID, `[1]` SPACE (0 host IOVA, 1 device), `[2]` R, `[3]` W, "
             "`[11:8]` DOMAIN, read-only `[16]` BUSY, `[17]` ERR.")
    o.append("")
    o.append("## Queue registers")
    o.append("")
    o.append("Queue *q* registers live at `0x%03X + q*0x%02X + offset`." % (Q_BASE, Q_STRIDE))
    o.append("")
    o.append("| Offset | Name | Acc | Description |")
    o.append("|---|---|---|---|")
    for off, n, a, d in Q_REGS:
        o.append("| `+0x%02X` | `%s` | %s | %s |" % (off, n, a, d))
    o.append("")
    o.append("## Doorbell page registers")
    o.append("")
    o.append("Doorbell page of queue *q* lives at `0x%04X + q*0x%04X`." % (DB_BASE, DB_STRIDE))
    o.append("")
    o.append("| Offset | Name | Acc | Description |")
    o.append("|---|---|---|---|")
    for off, n, a, d in DB_REGS:
        o.append("| `+0x%02X` | `%s` | %s | %s |" % (off, n, a, d))
    o.append("")
    for name, width, items in GROUPS:
        if name in ("opcode", "flag", "status", "qerr", "qstate", "kdstatus", "errbits",
                    "irqbits", "wdtbits", "rstbits", "caps", "ctrl", "limits", "identity"):
            o.append("## Constants: %s" % name)
            o.append("")
            o.append("| Name | Value | Meaning |")
            o.append("|---|---|---|")
            for n, v, c in items:
                o.append("| `SFX_%s` | `0x%X` | %s |" % (n, v, c))
            o.append("")
    o.append("## Descriptor (64 bytes) and completion entry (32 bytes) layout")
    o.append("")
    o.append("| Struct | Offset | Field | Notes |")
    o.append("|---|---|---|---|")
    for n, v, c in dict((g[0], g[2]) for g in GROUPS)["layout"]:
        kind = "SQE" if n.startswith("D_") else "CQE"
        o.append("| %s | `0x%02X` | `%s` | %s |" % (kind, v, n[2:].lower(), c))
    o.append("")
    return "\n".join(o) + "\n"


if __name__ == "__main__":
    import os, sys
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    outs = {
        os.path.join(root, "rtl", "sfx_pkg.sv"): emit_sv(),
        os.path.join(root, "sw", "include", "sfx_abi.h"): emit_c(),
        os.path.join(root, "docs", "REGMAP.md"): emit_regmap_md(),
    }
    check = "--check" in sys.argv
    bad = 0
    for path, text in outs.items():
        if check:
            cur = open(path).read() if os.path.exists(path) else None
            if cur != text:
                print("STALE:", path)
                bad += 1
        else:
            with open(path, "w") as f:
                f.write(text)
            print("wrote", os.path.relpath(path, root))
    sys.exit(1 if bad else 0)
