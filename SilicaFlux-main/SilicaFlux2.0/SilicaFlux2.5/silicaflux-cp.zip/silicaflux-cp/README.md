# SilicaFlux Command Processor & DMA subsystem (SFX-CP)

Device-side command handling for a SilicaFlux accelerator card, written in SystemVerilog, with a replaceable host
transport, a software device model, a reference driver library, and a test-suite that runs unchanged against both the model
and the Verilated RTL.

* **Register ABI 1.0, descriptor layout v1** — see [`docs/SPEC.md`](docs/SPEC.md) (normative) and
  [`docs/REGMAP.md`](docs/REGMAP.md) (generated register map).
* Submission/completion queues with defined slot ownership, 32-bit free-running sequence numbers, phase-tagged completions, and a
  documented memory-ordering contract (barriers on both sides).
* Commands: `NOP`, `COPY_H2D`, `COPY_D2H`, `COPY_D2D`, `KERNEL` dispatch, `FENCE` (barrier, optional host signal write).
* **Driver-authorised DMA.** The device never trusts an address in a descriptor: every device-initiated access (descriptor fetch,
  completion write, fence signal, every DMA burst) must fall inside a window the kernel driver programmed. Descriptors carry device-visible
  IOVAs; user virtual addresses are rejected, and the reference driver makes `Iova`, `DevAddr` and pointers distinct types.
* Validation of opcode, flags, reserved fields, lengths, alignment, address range and authorisation, in a fixed precedence order.
* A completion with `ST_OK` means the command reached its documented **completion point** (e.g. a copy's last write was acknowledged by the bus).
* Interrupts with per-queue coalescing and re-arm; progress watchdog with status registers; controlled reset that quiesces, drains
  the buses, snapshots queue counters and reports what was abandoned.

## What this is not

* **No PCIe.** There is no PHY, link, TLP or config-space logic, and **no claim of PCI Express compliance.** The host connection is a plain
  AXI4-Lite + AXI4 + interrupt interface (the *transport boundary*). `transport/sfx_transport_sim.sv` is an AXI test harness;
  `transport/sfx_transport_axi_ep.sv` is an **untested-on-hardware** adapter intended to sit between the core and a vendor PCIe endpoint IP that
  exposes AXI. See [`docs/INTEGRATION_FPGA.md`](docs/INTEGRATION_FPGA.md) for what the integrator must verify.
* **No hardware results.** Everything here is simulation (Verilator). No timing, area, power or throughput figures are claimed; v1 is correctness-first
  (one outstanding burst per bus direction).
* No compute fabric and no device-memory controller; only their interfaces.

## Layout

```
spec/sfx_spec.py            single source of truth for constants → generates rtl/sfx_pkg.sv, sw/include/sfx_abi.h, docs/REGMAP.md
rtl/                        the core (SystemVerilog)
transport/                  replaceable host-connection wrappers, AXI protocol checkers, null compute fabric
fpga/                       example top level (generated) showing where a vendor endpoint IP connects
sw/include/                 sfx_abi.h (generated), sfx_driver.hpp (reference driver), sim_memory.hpp, sfx_target.hpp
sw/model/                   C++ software device model (no hardware or simulator needed)
sim/                        Verilator C++ harness: AXI bus-functional models, fault injection, RtlTarget
tests/                      shared test-suite (runs on the model and on the RTL) + SV testbench for the endpoint wrapper
tools/                      generators, mutation checker, helper scripts
docs/                       SPEC, REGMAP, DRIVER_GUIDE, INTEGRATION_FPGA, DESIGN_NOTES, VERIFICATION
```

## Quick start

Requirements: Python 3, a C++17 compiler (g++ ≥ 9 or clang), `make`. The RTL flow also needs **Verilator ≥ 5.0**
(`pip install verilator` provides one; Linux/macOS). The software model needs no simulator.

```bash
make help            # list targets
make test-model      # software model + shared test-suite (fast, no Verilator)
make test-rtl        # Verilated RTL + the same suite under three bus-timing profiles
make test-ep         # SystemVerilog testbench for the AXI-endpoint wrapper
make test-diff       # same randomized program on model and RTL: results must be identical
make lint            # Verilator -Wall over three parameter sets
make test            # everything above plus generated-file freshness checks
make coverage-rtl    # RTL line-block coverage of the suite  -> docs/COVERAGE.md
make mutation        # inject bugs into a copy of the RTL; the suite must catch them (slow) -> docs/MUTATION_RESULTS.md
```

If your Verilator is not on `PATH`, set `VERILATOR=/path/to/verilator` (and `VERILATOR_ROOT` if needed).

## Where to read next

| If you are… | Read |
|---|---|
| writing a driver | [`docs/DRIVER_GUIDE.md`](docs/DRIVER_GUIDE.md), then `sw/include/sfx_driver.hpp` |
| reviewing the protocol | [`docs/SPEC.md`](docs/SPEC.md) |
| reviewing the RTL | [`docs/DESIGN_NOTES.md`](docs/DESIGN_NOTES.md) |
| integrating on an FPGA | [`docs/INTEGRATION_FPGA.md`](docs/INTEGRATION_FPGA.md) |
| judging how much to trust it | [`docs/VERIFICATION.md`](docs/VERIFICATION.md) |
