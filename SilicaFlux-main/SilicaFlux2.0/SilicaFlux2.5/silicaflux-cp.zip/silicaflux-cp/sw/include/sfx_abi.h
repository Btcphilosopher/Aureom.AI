/* GENERATED FILE -- do not edit.  Source: spec/sfx_spec.py  (run `make gen`) */
#ifndef SFX_ABI_H
#define SFX_ABI_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

/* ---- identity */
#define SFX_ID_VALUE               0x53465843u  /* 'SFXC' read from ID register */
#define SFX_ABI_MAJOR              0x1u  /* register-map ABI major (incompatible changes) */
#define SFX_ABI_MINOR              0x0u  /* register-map ABI minor (backward-compatible additions) */
#define SFX_ABI_PATCH              0x0u  /* errata level, no ABI effect */
#define SFX_DESC_VERSION           0x1u  /* descriptor/CQE layout version */
#define SFX_RESET_KEY              0x5AFEu  /* must be written in RESET_CTRL[31:16] */

/* ---- limits */
#define SFX_DESC_BYTES             0x40u  /* submission queue entry size */
#define SFX_DESC_LOG2              0x6u
#define SFX_CQE_BYTES              0x20u  /* completion queue entry size */
#define SFX_CQE_LOG2               0x5u
#define SFX_MAX_RING_LOG2          0xCu  /* largest supported ring: 4096 entries */
#define SFX_MIN_RING_LOG2          0x1u  /* smallest supported ring: 2 entries */
#define SFX_MAX_COPY_BYTES         0x40000000u  /* largest single COPY length (1 GiB) */
#define SFX_MAX_ARGS_BYTES         0x1000u  /* largest kernel argument block */
#define SFX_MAX_GRID_DIM           0xFFFFu  /* largest value of any grid dimension */
#define SFX_MAX_QUEUES             0x4u  /* architectural maximum; instance reports actual */
#define SFX_MAX_WINDOWS            0x10u  /* architectural maximum; instance reports actual */
#define SFX_MAX_DOMAINS            0x10u  /* domain id is 4 bits */
#define SFX_TIMER_UNIT             0x40u  /* Q_IRQ_COAL timer unit, in core clocks (model: ticks) */

/* ---- opcode */
#define SFX_OP_NOP                 0x0u  /* no operation; completes in order */
#define SFX_OP_COPY_H2D            0x1u  /* host IOVA -> device memory */
#define SFX_OP_COPY_D2H            0x2u  /* device memory -> host IOVA */
#define SFX_OP_COPY_D2D            0x3u  /* device memory -> device memory */
#define SFX_OP_KERNEL              0x10u  /* kernel dispatch */
#define SFX_OP_FENCE               0x20u  /* execution barrier, optional host signal write */

/* ---- flag */
#define SFX_F_FENCE_BEFORE         0x1u  /* all opcodes: do not issue until every earlier command has retired */
#define SFX_F_IRQ                  0x2u  /* all opcodes: raise queue completion interrupt when CQE is visible */
#define SFX_F_FENCE_SCOPE_ALL      0x4u  /* FENCE only: advisory in ABI 1.0 (scope is always all queues) */
#define SFX_F_FENCE_SIGNAL         0x8u  /* FENCE only: write 64-bit value to host address after prior work */
#define SFX_F_VALID_MASK           0xFu  /* all defined flag bits */

/* ---- status */
#define SFX_ST_OK                  0x0u  /* completion point reached */
#define SFX_ST_BAD_VERSION         0x1u  /* desc_ver not supported */
#define SFX_ST_BAD_OPCODE          0x2u  /* unknown opcode */
#define SFX_ST_BAD_FLAGS           0x3u  /* undefined flag bit, or flag not valid for opcode */
#define SFX_ST_BAD_DESC            0x4u  /* must-be-zero field set, or invalid field value (grid) */
#define SFX_ST_BAD_LENGTH          0x5u  /* zero / too large / not a multiple of DMA_ALIGN */
#define SFX_ST_BAD_ALIGN           0x6u  /* address not a multiple of DMA_ALIGN */
#define SFX_ST_BAD_RANGE           0x7u  /* outside supported address space or wraps */
#define SFX_ST_UNAUTHORIZED        0x8u  /* not inside one driver-authorised window (space/domain/permission) */
#define SFX_ST_DMA_READ_ERR        0x9u  /* bus error response on a read */
#define SFX_ST_DMA_WRITE_ERR       0xAu  /* bus error response on a write */
#define SFX_ST_KERNEL_FAULT        0xBu  /* compute fabric reported a fault; result = fabric info */
#define SFX_ST_ABORTED             0xCu  /* aborted by controlled reset before its completion point */
#define SFX_ST_TIMEOUT             0xDu  /* aborted by watchdog fault before its completion point */

/* ---- qerr */
#define SFX_QERR_NONE              0x0u
#define SFX_QERR_BAD_SEQ           0x1u  /* descriptor seq field != expected sequence number */
#define SFX_QERR_SQ_FETCH          0x2u  /* bus error fetching a descriptor */
#define SFX_QERR_RING_UNAUTH       0x3u  /* SQ or CQ ring access not inside an authorised window */
#define SFX_QERR_CQ_WRITE          0x4u  /* bus error publishing a completion */
#define SFX_QERR_BAD_CONFIG        0x5u  /* enable-time validation failed */

/* ---- qstate */
#define SFX_QS_DISABLED            0x0u
#define SFX_QS_ENABLED             0x1u
#define SFX_QS_DRAINING            0x2u
#define SFX_QS_ERROR               0x3u

/* ---- kdstatus */
#define SFX_KD_OK                  0x0u  /* kernel finished; its writes are performed */
#define SFX_KD_FAULT               0x1u  /* kernel faulted; info is fabric specific */
#define SFX_KD_ABORTED             0x2u  /* kernel stopped by kd_abort */

/* ---- space */
#define SFX_SPACE_HOST             0x0u  /* host DMA (IOVA) address space */
#define SFX_SPACE_DEV              0x1u  /* device-local memory address space */

/* ---- layout */
#define SFX_D_OPCODE               0x0u  /* u16 */
#define SFX_D_FLAGS                0x2u  /* u16 */
#define SFX_D_SEQ                  0x4u  /* u32 == absolute SQ index of this slot */
#define SFX_D_CMD_ID               0x8u  /* u32 opaque host tag, echoed in CQE */
#define SFX_D_DESC_VER             0xCu  /* u16 must equal DESC_VERSION */
#define SFX_D_RSVD0                0xEu  /* u16 must be zero */
#define SFX_D_ADDR0                0x10u  /* u64 COPY src | KERNEL entry | FENCE signal addr */
#define SFX_D_ADDR1                0x18u  /* u64 COPY dst | KERNEL args addr */
#define SFX_D_LENGTH               0x20u  /* u32 COPY bytes | KERNEL args bytes */
#define SFX_D_AUX0                 0x24u  /* u32 KERNEL grid_x */
#define SFX_D_AUX1                 0x28u  /* u32 KERNEL grid_y */
#define SFX_D_AUX2                 0x2Cu  /* u32 KERNEL grid_z */
#define SFX_D_VALUE                0x30u  /* u64 FENCE signal value */
#define SFX_D_RSVD1                0x38u  /* u64 must be zero */
#define SFX_C_CMD_ID               0x0u  /* u32 */
#define SFX_C_SQ_SEQ               0x4u  /* u32 absolute SQ index of the command */
#define SFX_C_STATUS               0x8u  /* u16 */
#define SFX_C_OPCODE               0xAu  /* u16 echo of descriptor opcode */
#define SFX_C_SQ_HEAD              0xCu  /* u32 SQ slots with absolute index < sq_head are reusable */
#define SFX_C_RESULT               0x10u  /* u64 */
#define SFX_C_CQ_SEQ               0x18u  /* u32 absolute CQ index of this entry */
#define SFX_C_PHASE                0x1Cu  /* u32, bit0 = phase; written LAST, as its own write */

/* ---- winctl */
#define SFX_WIN_VALID              0x1u  /* write 1: commit window; write 0: invalidate */
#define SFX_WIN_SPACE              0x2u  /* 0 host IOVA, 1 device */
#define SFX_WIN_R                  0x4u  /* device may read */
#define SFX_WIN_W                  0x8u  /* device may write */
#define SFX_WIN_DOM_LSB            0x8u  /* domain id [11:8] */
#define SFX_WIN_DOM_MASK           0xF00u
#define SFX_WIN_BUSY               0x10000u  /* read: window referenced by an in-flight device access */
#define SFX_WIN_ERR                0x20000u  /* read: last commit rejected; cleared by an invalidate write or a successful commit */

/* ---- qctl */
#define SFX_QCTL_ENABLE            0x1u
#define SFX_QCTL_DOM_LSB           0x8u  /* domain id [11:8] */
#define SFX_QCTL_DOM_MASK          0xF00u
#define SFX_QSTAT_STATE_MASK       0x3u  /* Q_STATUS[1:0] */
#define SFX_QSTAT_ERR_LSB          0x8u  /* Q_STATUS[15:8] = QERR_* */
#define SFX_QSIZE_SQ_MASK          0x1Fu  /* Q_SIZE[4:0] */
#define SFX_QSIZE_CQ_LSB           0x8u  /* Q_SIZE[12:8] */
#define SFX_QSIZE_CQ_MASK          0x1F00u

/* ---- ctrl */
#define SFX_CTRL_ENABLE            0x1u  /* global run enable */
#define SFX_STATUS_READY           0x1u  /* out of reset and not RESETTING: registers usable */
#define SFX_STATUS_RUNNING         0x2u  /* CTRL.ENABLE && !FAULT && !RESETTING */
#define SFX_STATUS_FAULT           0x4u  /* watchdog fault; cleared only by controlled reset */
#define SFX_STATUS_RESETTING       0x8u
#define SFX_STATUS_IDLE            0x10u  /* no pending, fetched, in-flight or publishing work */
#define SFX_STATUS_ABI_OK          0x20u  /* ABI_REQ accepted */
#define SFX_FAULT_WDT              0x1u  /* FAULT_CAUSE bit */

/* ---- errbits */
#define SFX_ERR_BAD_DOORBELL       0x1u  /* invalid doorbell value, or queue not ENABLED */
#define SFX_ERR_BAD_REG_ACCESS     0x2u  /* partial/unaligned write, write to RO/unmapped, bad key */
#define SFX_ERR_BAD_WINDOW         0x4u  /* window commit rejected */
#define SFX_ERR_BAD_QCONFIG        0x8u  /* queue enable rejected */
#define SFX_ERR_BAD_IRQ_CONFIG     0x10u  /* vector out of range */
#define SFX_ERR_CFG_LOCKED         0x20u  /* config write to a locked (enabled/valid) object */

/* ---- irqbits */
#define SFX_IRQ_QCPL_LSB           0x0u  /* bit q: queue q completion */
#define SFX_IRQ_QERR_LSB           0x4u  /* bit 4+q: queue q entered ERROR */
#define SFX_IRQ_DEV_ERR            0x100u  /* a new ERR_STATUS bit was set */
#define SFX_IRQ_WDT                0x200u  /* watchdog expired */
#define SFX_IRQ_RESET_DONE         0x400u  /* controlled reset finished */
#define SFX_IRQ_VALID_MASK         0x7FFu

/* ---- wdtbits */
#define SFX_WDT_CTRL_ENABLE        0x1u
#define SFX_WDT_ST_ENABLED         0x1u
#define SFX_WDT_ST_ARMED           0x2u  /* work outstanding and counting */
#define SFX_WDT_ST_EXPIRED         0x4u  /* W1C */
#define SFX_WDT_STUCK_LSB          0x8u  /* [11:8] unit mask at expiry */
#define SFX_WDT_STUCK_FRONTEND     0x100u
#define SFX_WDT_STUCK_DMA          0x200u
#define SFX_WDT_STUCK_KERNEL       0x400u
#define SFX_WDT_STUCK_RETIRE       0x800u
#define SFX_WDT_COUNT_LSB          0x10u  /* [31:16] expiry count */

/* ---- rstbits */
#define SFX_RST_REQ                0x1u  /* RESET_CTRL[0] */
#define SFX_RST_KEY_LSB            0x10u  /* RESET_CTRL[31:16] */
#define SFX_RST_ST_BUSY            0x1u
#define SFX_RST_ST_DONE            0x2u  /* cleared when next reset is requested */
#define SFX_RST_ST_DRAIN_TIMEOUT   0x4u  /* outstanding bus transactions never drained */
#define SFX_RST_COUNT_LSB          0x10u  /* [31:16] controlled resets since hard reset */

/* ---- caps */
#define SFX_CAP_KERNEL             0x1u
#define SFX_CAP_COPY_H2D           0x2u
#define SFX_CAP_COPY_D2H           0x4u
#define SFX_CAP_COPY_D2D           0x8u
#define SFX_CAP_FENCE              0x10u
#define SFX_CAP_FENCE_SIGNAL       0x20u
#define SFX_CAP_IRQ_COALESCE       0x40u
#define SFX_CAP_WATCHDOG           0x80u
#define SFX_CAP_SOFT_RESET         0x100u
#define SFX_CAP_WINDOW_AUTHZ       0x200u  /* device enforces driver-programmed windows */
#define SFX_CAP_SEQ_START          0x400u  /* Q_SEQ_START supported */

/* ---- register offsets */
#define SFX_R_ID                   0x0000u
#define SFX_R_VERSION              0x0004u
#define SFX_R_CAPS                 0x0008u
#define SFX_R_GEOMETRY             0x000Cu
#define SFX_R_LIMITS               0x0010u
#define SFX_R_MAX_COPY             0x0014u
#define SFX_R_DEVMEM_LO            0x0018u
#define SFX_R_DEVMEM_HI            0x001Cu
#define SFX_R_HOST_ADDR_BITS       0x0020u
#define SFX_R_DESC_VERSIONS        0x0024u
#define SFX_R_LIMITS2              0x0028u
#define SFX_R_ABI_REQ              0x0030u
#define SFX_R_SCRATCH              0x0034u
#define SFX_R_CTRL                 0x0040u
#define SFX_R_STATUS               0x0044u
#define SFX_R_FAULT_CAUSE          0x0048u
#define SFX_R_ERR_STATUS           0x004Cu
#define SFX_R_ERR_COUNT            0x0050u
#define SFX_R_DUP_DB_COUNT         0x0054u
#define SFX_R_FAULT_ADDR_LO        0x0058u
#define SFX_R_FAULT_ADDR_HI        0x005Cu
#define SFX_R_FAULT_INFO           0x0060u
#define SFX_R_CMDS_OK              0x0064u
#define SFX_R_CMDS_ERR             0x0068u
#define SFX_R_IRQ_STATUS           0x0070u
#define SFX_R_IRQ_ENABLE           0x0074u
#define SFX_R_IRQ_MISC_VECTOR      0x0078u
#define SFX_R_IRQ_FORCE            0x007Cu
#define SFX_R_WDT_CTRL             0x0080u
#define SFX_R_WDT_TIMEOUT          0x0084u
#define SFX_R_WDT_STATUS           0x0088u
#define SFX_R_WDT_COUNT            0x008Cu
#define SFX_R_RESET_CTRL           0x0090u
#define SFX_R_RESET_STATUS         0x0094u
#define SFX_R_RESET_TIMEOUT        0x0098u
#define SFX_WIN_BASE   0x0100u
#define SFX_WIN_STRIDE 0x0020u
#define SFX_R_W_BASE_LO            0x0000u
#define SFX_R_W_BASE_HI            0x0004u
#define SFX_R_W_SIZE_LO            0x0008u
#define SFX_R_W_SIZE_HI            0x000Cu
#define SFX_R_W_CTRL               0x0010u
#define SFX_Q_BASE     0x0400u
#define SFX_Q_STRIDE   0x0080u
#define SFX_R_Q_CTRL               0x0000u
#define SFX_R_Q_STATUS             0x0004u
#define SFX_R_Q_SQ_BASE_LO         0x0008u
#define SFX_R_Q_SQ_BASE_HI         0x000Cu
#define SFX_R_Q_CQ_BASE_LO         0x0010u
#define SFX_R_Q_CQ_BASE_HI         0x0014u
#define SFX_R_Q_SIZE               0x0018u
#define SFX_R_Q_VECTOR             0x001Cu
#define SFX_R_Q_SEQ_START          0x0020u
#define SFX_R_Q_IRQ_COAL           0x0024u
#define SFX_R_Q_SQ_HEAD            0x0028u
#define SFX_R_Q_SQ_TAIL            0x002Cu
#define SFX_R_Q_CQ_HEAD            0x0030u
#define SFX_R_Q_CQ_TAIL            0x0034u
#define SFX_R_Q_CMDS_OK            0x0038u
#define SFX_R_Q_CMDS_ERR           0x003Cu
#define SFX_R_Q_RST_SQ_TAIL        0x0040u
#define SFX_R_Q_RST_SQ_HEAD        0x0044u
#define SFX_R_Q_RST_CQ_TAIL        0x0048u
#define SFX_DB_BASE    0x1000u
#define SFX_DB_STRIDE  0x1000u
#define SFX_R_DB_SQ_TAIL           0x0000u
#define SFX_R_DB_CQ_HEAD           0x0004u

#define SFX_WIN_REG(w, reg) (SFX_WIN_BASE + (w) * SFX_WIN_STRIDE + (reg))
#define SFX_Q_REG(q, reg)   (SFX_Q_BASE + (q) * SFX_Q_STRIDE + (reg))
#define SFX_DB_REG(q, reg)  (SFX_DB_BASE + (q) * SFX_DB_STRIDE + (reg))


/* ---- wire structures (little-endian; all fields naturally aligned) ---- */
#pragma pack(push, 1)
typedef struct sfx_desc {
    uint16_t opcode;      /* 0x00 */
    uint16_t flags;       /* 0x02 */
    uint32_t seq;         /* 0x04 */
    uint32_t cmd_id;      /* 0x08 */
    uint16_t desc_ver;    /* 0x0C */
    uint16_t rsvd0;       /* 0x0E */
    uint64_t addr0;       /* 0x10 */
    uint64_t addr1;       /* 0x18 */
    uint32_t length;      /* 0x20 */
    uint32_t aux0;        /* 0x24 */
    uint32_t aux1;        /* 0x28 */
    uint32_t aux2;        /* 0x2C */
    uint64_t value;       /* 0x30 */
    uint64_t rsvd1;       /* 0x38 */
} sfx_desc_t;

typedef struct sfx_cqe {
    uint32_t cmd_id;      /* 0x00 */
    uint32_t sq_seq;      /* 0x04 */
    uint16_t status;      /* 0x08 */
    uint16_t opcode;      /* 0x0A */
    uint32_t sq_head;     /* 0x0C */
    uint64_t result;      /* 0x10 */
    uint32_t cq_seq;      /* 0x18 */
    uint32_t phase_word;  /* 0x1C  bit0 = phase */
} sfx_cqe_t;
#pragma pack(pop)

#ifdef __cplusplus
static_assert(sizeof(sfx_desc_t) == SFX_DESC_BYTES, "descriptor size");
static_assert(sizeof(sfx_cqe_t) == SFX_CQE_BYTES, "cqe size");
#define SFX_STATIC_INLINE static inline
#else
_Static_assert(sizeof(sfx_desc_t) == SFX_DESC_BYTES, "descriptor size");
_Static_assert(sizeof(sfx_cqe_t) == SFX_CQE_BYTES, "cqe size");
#define SFX_STATIC_INLINE static inline
#endif

/* Phase the device writes into the CQE with absolute index n.
 * Lap 0 (the first pass after enable) is phase 1, so zero-initialised memory
 * never looks valid.  seq_start must be a multiple of the CQ size. */
SFX_STATIC_INLINE uint32_t sfx_cq_phase(uint32_t n, uint32_t seq_start, uint32_t cq_log2)
{
    return (((n - seq_start) >> cq_log2) & 1u) ^ 1u;
}

SFX_STATIC_INLINE const char *sfx_status_str(uint16_t st)
{
    switch (st) {
    case SFX_ST_OK: return "OK";
    case SFX_ST_BAD_VERSION: return "BAD_VERSION";
    case SFX_ST_BAD_OPCODE: return "BAD_OPCODE";
    case SFX_ST_BAD_FLAGS: return "BAD_FLAGS";
    case SFX_ST_BAD_DESC: return "BAD_DESC";
    case SFX_ST_BAD_LENGTH: return "BAD_LENGTH";
    case SFX_ST_BAD_ALIGN: return "BAD_ALIGN";
    case SFX_ST_BAD_RANGE: return "BAD_RANGE";
    case SFX_ST_UNAUTHORIZED: return "UNAUTHORIZED";
    case SFX_ST_DMA_READ_ERR: return "DMA_READ_ERR";
    case SFX_ST_DMA_WRITE_ERR: return "DMA_WRITE_ERR";
    case SFX_ST_KERNEL_FAULT: return "KERNEL_FAULT";
    case SFX_ST_ABORTED: return "ABORTED";
    case SFX_ST_TIMEOUT: return "TIMEOUT";
    default: return "?";
    }
}

SFX_STATIC_INLINE const char *sfx_qerr_str(uint8_t e)
{
    switch (e) {
    case SFX_QERR_NONE: return "NONE";
    case SFX_QERR_BAD_SEQ: return "BAD_SEQ";
    case SFX_QERR_SQ_FETCH: return "SQ_FETCH";
    case SFX_QERR_RING_UNAUTH: return "RING_UNAUTH";
    case SFX_QERR_CQ_WRITE: return "CQ_WRITE";
    case SFX_QERR_BAD_CONFIG: return "BAD_CONFIG";
    default: return "?";
    }
}

#ifdef __cplusplus
}
#endif
#endif /* SFX_ABI_H */
