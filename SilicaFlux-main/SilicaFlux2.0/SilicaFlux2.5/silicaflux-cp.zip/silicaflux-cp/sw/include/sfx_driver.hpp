// SFX-CP reference driver (header-only, C++17).
//
// This is the host-side half of docs/SPEC.md written as readable code: how to bring the device
// up, how to authorise DMA memory, how to build and publish commands, and how to consume
// completions with the right memory barriers.  It depends only on an MMIO window (sfx::MmioIf)
// and a DMA-coherent memory allocator (sfx::DmaAllocator), so the same code runs against the
// software model, the Verilated RTL (tests) and - with a real MmioIf over an ioremap()ed BAR
// and dma_alloc_coherent() - hardware.
//
// ROLES (see SPEC 3 and 4)
//   Device     PRIVILEGED / kernel role.  Owns the control page (identity, ABI negotiation, DMA
//              windows, queue configuration, interrupts, watchdog, controlled reset).  Never hand
//              the control page to user space.
//   Queue      USER role.  Needs only the queue's own doorbell page and the two rings.  Cannot
//              create mappings, cannot name an address the kernel did not authorise.
//
// ADDRESS TYPES (SPEC 2): three kinds of "address", three C++ types that do not convert:
//   sfx::Iova     device-visible host DMA address (what dma_map_*/dma_alloc_coherent return)
//   sfx::DevAddr  offset in device-local memory
//   void*/uintptr_t  a CPU/user virtual address - never placed in a descriptor
// A descriptor can only be built from Iova/DevAddr; getting a raw pointer into one takes an
// explicit, greppable cast (the malformed-descriptor tests do exactly that on purpose).
#pragma once

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <functional>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

#include "sfx_abi.h"
#include "sfx_target.hpp"  // only for sfx::MmioIf

namespace sfx {

// ---------------------------------------------------------------------------------------------
// Memory barriers (SPEC 10.2).  Replace with the platform's primitives in a kernel build:
//   SFX_WMB  store->store before the doorbell      Linux: wmb(), or writel() ordering
//   SFX_RMB  load->load after seeing the phase     Linux: dma_rmb()
//   SFX_MB   full barrier before CQ-head doorbell  Linux: mb()
// ---------------------------------------------------------------------------------------------
#ifndef SFX_WMB
#define SFX_WMB() std::atomic_thread_fence(std::memory_order_release)
#endif
#ifndef SFX_RMB
#define SFX_RMB() std::atomic_thread_fence(std::memory_order_acquire)
#endif
#ifndef SFX_MB
#define SFX_MB() std::atomic_thread_fence(std::memory_order_seq_cst)
#endif

// ---------------------------------------------------------------------------------------------
// Strong address types
// ---------------------------------------------------------------------------------------------
struct Iova {
    uint64_t v = 0;
    constexpr Iova() = default;
    constexpr explicit Iova(uint64_t x) : v(x) {}
    constexpr Iova operator+(uint64_t n) const { return Iova(v + n); }
    constexpr bool operator==(const Iova& o) const { return v == o.v; }
    constexpr bool operator!=(const Iova& o) const { return v != o.v; }
};
struct DevAddr {
    uint64_t v = 0;
    constexpr DevAddr() = default;
    constexpr explicit DevAddr(uint64_t x) : v(x) {}
    constexpr DevAddr operator+(uint64_t n) const { return DevAddr(v + n); }
    constexpr bool operator==(const DevAddr& o) const { return v == o.v; }
    constexpr bool operator!=(const DevAddr& o) const { return v != o.v; }
};
static_assert(!std::is_convertible<Iova, DevAddr>::value, "Iova must not convert to DevAddr");
static_assert(!std::is_convertible<DevAddr, Iova>::value, "DevAddr must not convert to Iova");
static_assert(!std::is_convertible<uint64_t, Iova>::value, "raw integers must not become Iova implicitly");
static_assert(!std::is_convertible<void*, Iova>::value, "user pointers must not become Iova");
static_assert(!std::is_convertible<Iova, uint64_t>::value, "Iova must not decay to an integer");

enum class Space : unsigned { Host = SFX_SPACE_HOST, Dev = SFX_SPACE_DEV };
enum Perm : unsigned { PermR = 1, PermW = 2, PermRW = 3 };

// ---------------------------------------------------------------------------------------------
// DMA-coherent memory provider (stands in for dma_alloc_coherent / dma_free_coherent).
// Memory MUST be zeroed.  `cpu` is the CPU-visible pointer, `iova` what the device must use.
// ---------------------------------------------------------------------------------------------
struct DmaBuffer {
    void* cpu = nullptr;
    Iova iova;
    size_t size = 0;
};
class DmaAllocator {
public:
    virtual ~DmaAllocator() = default;
    virtual DmaBuffer alloc_coherent(size_t bytes, size_t align) = 0;
    virtual void free_coherent(const DmaBuffer& b) = 0;
};

// ---------------------------------------------------------------------------------------------
// Command builders (descriptor layout: SPEC 5.1).  They take strong types only.
// ---------------------------------------------------------------------------------------------
namespace cmd {
inline sfx_desc_t make(uint16_t opcode, uint32_t cmd_id, uint16_t flags) {
    sfx_desc_t d;
    std::memset(&d, 0, sizeof d);
    d.opcode = opcode;
    d.flags = flags;
    d.cmd_id = cmd_id;
    d.desc_ver = SFX_DESC_VERSION;
    return d;  // seq is assigned by Queue::submit()
}
inline sfx_desc_t nop(uint32_t id, uint16_t flags = 0) { return make(SFX_OP_NOP, id, flags); }
inline sfx_desc_t copy_h2d(uint32_t id, Iova src, DevAddr dst, uint32_t len, uint16_t flags = 0) {
    sfx_desc_t d = make(SFX_OP_COPY_H2D, id, flags);
    d.addr0 = src.v; d.addr1 = dst.v; d.length = len;
    return d;
}
inline sfx_desc_t copy_d2h(uint32_t id, DevAddr src, Iova dst, uint32_t len, uint16_t flags = 0) {
    sfx_desc_t d = make(SFX_OP_COPY_D2H, id, flags);
    d.addr0 = src.v; d.addr1 = dst.v; d.length = len;
    return d;
}
inline sfx_desc_t copy_d2d(uint32_t id, DevAddr src, DevAddr dst, uint32_t len, uint16_t flags = 0) {
    sfx_desc_t d = make(SFX_OP_COPY_D2D, id, flags);
    d.addr0 = src.v; d.addr1 = dst.v; d.length = len;
    return d;
}
inline sfx_desc_t kernel(uint32_t id, DevAddr entry, DevAddr args, uint32_t args_size, uint32_t gx = 1,
                         uint32_t gy = 1, uint32_t gz = 1, uint16_t flags = 0) {
    sfx_desc_t d = make(SFX_OP_KERNEL, id, flags);
    d.addr0 = entry.v; d.addr1 = args.v; d.length = args_size;
    d.aux0 = gx; d.aux1 = gy; d.aux2 = gz;
    return d;
}
inline sfx_desc_t fence(uint32_t id, uint16_t flags = 0) { return make(SFX_OP_FENCE, id, flags); }
// FENCE that, after all earlier work has retired, writes `value` (8 bytes) to host `addr`.
inline sfx_desc_t fence_signal(uint32_t id, Iova addr, uint64_t value, uint16_t flags = 0) {
    sfx_desc_t d = make(SFX_OP_FENCE, id, flags | SFX_F_FENCE_SIGNAL);
    d.addr0 = addr.v; d.value = value;
    return d;
}
}  // namespace cmd

// ---------------------------------------------------------------------------------------------
// Queue : USER role.  One SQ/CQ pair.  Not thread-safe (one producer, one consumer thread).
// ---------------------------------------------------------------------------------------------
class Queue {
public:
    // `db` must reach this queue's doorbell page only (in a real system: the mmap()ed page).
    Queue(MmioIf& db, unsigned qid, void* sq_cpu, void* cq_cpu, unsigned sq_log2, unsigned cq_log2,
          uint32_t seq_start)
        : db_(&db), qid_(qid), sq_(static_cast<uint8_t*>(sq_cpu)), cq_(static_cast<uint8_t*>(cq_cpu)),
          sq_log2_(sq_log2), cq_log2_(cq_log2), seq_start_(seq_start), sq_tail_(seq_start),
          sq_reclaimed_(seq_start), cq_head_(seq_start), cq_released_(seq_start) {}

    unsigned id() const { return qid_; }
    uint32_t sq_size() const { return 1u << sq_log2_; }
    uint32_t cq_size() const { return 1u << cq_log2_; }
    uint32_t sq_tail() const { return sq_tail_; }
    uint32_t cq_head() const { return cq_head_; }
    uint32_t seq_start() const { return seq_start_; }
    // Slots we may still fill: capacity minus slots not yet reclaimed through cqe.sq_head.
    uint32_t sq_free() const { return sq_size() - (sq_tail_ - sq_reclaimed_); }
    // Commands submitted whose completion has not been polled yet.
    uint32_t outstanding() const { return sq_tail_ - cq_head_; }

    // ---- producer ------------------------------------------------------------------------
    // Fill the next SQ slot (H1, step 1).  Assigns d.seq = absolute SQ index.  Does NOT ring.
    bool submit(sfx_desc_t d) {
        if (sq_free() == 0) return false;
        d.seq = sq_tail_;
        put(d);
        return true;
    }
    // Same, but publishes the descriptor exactly as given (arbitrary seq/reserved/raw addresses).
    // For negative tests only.
    bool submit_raw(const sfx_desc_t& d) {
        if (sq_free() == 0) return false;
        put(d);
        return true;
    }
    // Publish everything submitted so far: store barrier, then the doorbell write (H1).
    // Ringing again with nothing new is harmless (duplicate doorbell, SPEC 6.4).
    void ring() { ring_value(sq_tail_); }
    // Raw doorbell (negative tests).
    void ring_value(uint32_t tail) {
        SFX_WMB();
        db_->wr32(SFX_DB_REG(qid_, SFX_R_DB_SQ_TAIL), tail);
    }

    // ---- consumer ------------------------------------------------------------------------
    // Fetch the next completion if one is visible (H2).  Returns false if none.
    bool poll(sfx_cqe_t* out) {
        const uint8_t* slot = cq_slot(cq_head_);
        uint32_t phase_word = load32(slot + SFX_C_PHASE);        // 1. observe the phase ...
        if ((phase_word & 1u) != sfx_cq_phase(cq_head_, seq_start_, cq_log2_)) return false;
        SFX_RMB();                                                 // 2. ... then order the rest after it
        std::memcpy(out, slot, sizeof *out);
        out->phase_word = phase_word;
        ++cq_head_;
        if (static_cast<int32_t>(out->sq_head - sq_reclaimed_) > 0) sq_reclaimed_ = out->sq_head;
        return true;
    }
    // Hand the polled CQ slots back to the device (H3): full barrier, then the doorbell.
    void release() { release_value(cq_head_); }
    void release_value(uint32_t head) {
        SFX_MB();
        db_->wr32(SFX_DB_REG(qid_, SFX_R_DB_CQ_HEAD), head);
        if (head == cq_head_) cq_released_ = head;
    }
    uint32_t cq_released() const { return cq_released_; }

    // Accepted pointers as the device sees them (doorbell page reads, SPEC 3 / REGMAP).
    uint32_t device_sq_tail() { return db_->rd32(SFX_DB_REG(qid_, SFX_R_DB_SQ_TAIL)); }
    uint32_t device_cq_head() { return db_->rd32(SFX_DB_REG(qid_, SFX_R_DB_CQ_HEAD)); }

private:
    void put(const sfx_desc_t& d) {
        uint8_t* slot = sq_ + static_cast<size_t>(sq_tail_ & (sq_size() - 1)) * SFX_DESC_BYTES;
        std::memcpy(slot, &d, sizeof d);
        ++sq_tail_;
    }
    const uint8_t* cq_slot(uint32_t n) const {
        return cq_ + static_cast<size_t>(n & (cq_size() - 1)) * SFX_CQE_BYTES;
    }
    static uint32_t load32(const uint8_t* p) { return *reinterpret_cast<const volatile uint32_t*>(p); }

    MmioIf* db_;
    unsigned qid_;
    uint8_t *sq_, *cq_;
    unsigned sq_log2_, cq_log2_;
    uint32_t seq_start_;
    uint32_t sq_tail_, sq_reclaimed_, cq_head_, cq_released_;
};

// ---------------------------------------------------------------------------------------------
// Device : PRIVILEGED / kernel role.
// ---------------------------------------------------------------------------------------------
struct DeviceInfo {
    uint32_t id = 0, version = 0, caps = 0;
    unsigned abi_major = 0, abi_minor = 0;
    unsigned num_queues = 0, num_windows = 0, num_vectors = 0, inflight_depth = 0;
    unsigned max_ring_log2 = 0, dma_align_log2 = 0;
    uint32_t max_copy = 0, desc_versions = 0, max_args = 0, max_grid = 0;
    uint64_t dev_mem_size = 0;
    unsigned host_addr_bits = 0;
    uint32_t dma_align() const { return 1u << dma_align_log2; }
};

struct QueueConfig {
    uint8_t domain = 0;
    unsigned sq_log2 = 6, cq_log2 = 6;
    int vector = -1;          // -1: leave the reset default
    uint32_t seq_start = 0;   // multiple of max(SQ,CQ) size
    uint32_t irq_coal = 0;
};

// Everything the kernel keeps per queue; hand the rings to Queue (or to the owning process).
struct QueueHandle {
    unsigned id = 0;
    QueueConfig cfg;
    DmaBuffer sq, cq;
    int sq_win = -1, cq_win = -1;
    uint32_t state = SFX_QS_DISABLED;
    uint32_t err = SFX_QERR_NONE;
    bool ok() const { return state == SFX_QS_ENABLED; }
};

class Device {
public:
    Device(MmioIf& mmio, DmaAllocator& dma, std::function<void()> relax = {})
        : m_(&mmio), dma_(&dma), relax_(std::move(relax)) {}

    // ---- bring-up ------------------------------------------------------------------------
    // Check identity, read geometry, negotiate the register ABI (SPEC 3, rule 3).
    bool init(std::string* why = nullptr, unsigned want_major = SFX_ABI_MAJOR, unsigned want_minor = SFX_ABI_MINOR) {
        info_.id = rd(SFX_R_ID);
        if (info_.id != SFX_ID_VALUE) return fail(why, "bad ID register");
        info_.version = rd(SFX_R_VERSION);
        info_.abi_major = info_.version >> 24;
        info_.abi_minor = (info_.version >> 16) & 0xFF;
        if (info_.abi_major != want_major) return fail(why, "ABI major mismatch");
        if (info_.abi_minor < want_minor) return fail(why, "device ABI minor too old");
        info_.caps = rd(SFX_R_CAPS);                       // unknown bits are ignored
        uint32_t geo = rd(SFX_R_GEOMETRY), lim = rd(SFX_R_LIMITS), lim2 = rd(SFX_R_LIMITS2);
        info_.num_queues = geo & 0xF;
        info_.num_windows = (geo >> 8) & 0xFF;
        info_.num_vectors = (geo >> 16) & 0xF;
        info_.inflight_depth = (geo >> 24) & 0xF;
        info_.max_ring_log2 = lim & 0xFF;
        info_.dma_align_log2 = (lim >> 8) & 0xFF;
        info_.max_copy = rd(SFX_R_MAX_COPY);
        info_.dev_mem_size = rd(SFX_R_DEVMEM_LO) | (static_cast<uint64_t>(rd(SFX_R_DEVMEM_HI)) << 32);
        info_.host_addr_bits = rd(SFX_R_HOST_ADDR_BITS);
        info_.desc_versions = rd(SFX_R_DESC_VERSIONS);
        if (!(info_.desc_versions & (1u << SFX_DESC_VERSION))) return fail(why, "descriptor layout v1 unsupported");
        info_.max_args = lim2 & 0xFFFF;
        info_.max_grid = lim2 >> 16;
        // negotiate: ask for the version we were written against
        m_->wr32(SFX_R_ABI_REQ, (want_major << 16) | want_minor);
        if (!(rd(SFX_R_STATUS) & SFX_STATUS_ABI_OK)) return fail(why, "device rejected ABI_REQ");
        win_used_.assign(info_.num_windows, false);
        return true;
    }
    const DeviceInfo& info() const { return info_; }

    uint32_t rd(uint32_t off) { return m_->rd32(off); }
    void wr(uint32_t off, uint32_t v) { m_->wr32(off, v); }

    void enable(bool on) { wr(SFX_R_CTRL, on ? SFX_CTRL_ENABLE : 0); }
    uint32_t status() { return rd(SFX_R_STATUS); }

    // ---- DMA windows (SPEC 4): the only way memory becomes reachable ----------------------
    // Returns the window index, or -1 if the device rejected it or none is free.
    int map_host(Iova base, uint64_t size, unsigned perm, unsigned domain) {
        return map_window(Space::Host, base.v, size, perm, domain);
    }
    int map_dev(DevAddr base, uint64_t size, unsigned perm, unsigned domain) {
        return map_window(Space::Dev, base.v, size, perm, domain);
    }
    // Invalidate, then wait for BUSY=0 (SPEC 4.2).  Only after this may the memory be unmapped/freed.
    bool unmap_window(int w, unsigned spin_limit = 1000000) {
        if (w < 0 || static_cast<unsigned>(w) >= win_used_.size()) return false;
        wr(win_reg(w, SFX_R_W_CTRL), 0);
        bool idle = wait_clear(win_reg(w, SFX_R_W_CTRL), SFX_WIN_BUSY, spin_limit);
        if (idle) win_used_[w] = false;
        return idle;
    }
    bool window_busy(int w) { return rd(win_reg(w, SFX_R_W_CTRL)) & SFX_WIN_BUSY; }
    uint32_t window_ctrl(int w) { return rd(win_reg(w, SFX_R_W_CTRL)); }
    void forget_windows() { std::fill(win_used_.begin(), win_used_.end(), false); }  // after controlled reset

    // ---- queues ---------------------------------------------------------------------------
    // Allocate + map rings, program registers, enable.  On failure `out->state/err` say why and
    // the rings stay allocated for inspection (call destroy_queue()).
    bool create_queue(unsigned q, const QueueConfig& cfg, QueueHandle* out) {
        QueueHandle h;
        h.id = q;
        h.cfg = cfg;
        h.sq = dma_->alloc_coherent(static_cast<size_t>(SFX_DESC_BYTES) << cfg.sq_log2, 64);
        h.cq = dma_->alloc_coherent(static_cast<size_t>(SFX_CQE_BYTES) << cfg.cq_log2, 64);
        std::memset(h.sq.cpu, 0, h.sq.size);
        std::memset(h.cq.cpu, 0, h.cq.size);  // zeroed CQ: phase 0 never looks valid (SPEC 5.2)
        h.sq_win = map_host(h.sq.iova, h.sq.size, PermR, cfg.domain);  // device only READS the SQ
        h.cq_win = map_host(h.cq.iova, h.cq.size, PermW, cfg.domain);  // device only WRITES the CQ
        program_queue(q, h);
        set_queue_enable(q, cfg.domain, true);
        uint32_t qs = rd(SFX_Q_REG(q, SFX_R_Q_STATUS));
        h.state = qs & SFX_QSTAT_STATE_MASK;
        h.err = qs >> SFX_QSTAT_ERR_LSB;
        *out = h;
        return h.ok();
    }
    // Register programming only (queue must be DISABLED).
    void program_queue(unsigned q, const QueueHandle& h) {
        wr(SFX_Q_REG(q, SFX_R_Q_SQ_BASE_LO), static_cast<uint32_t>(h.sq.iova.v));
        wr(SFX_Q_REG(q, SFX_R_Q_SQ_BASE_HI), static_cast<uint32_t>(h.sq.iova.v >> 32));
        wr(SFX_Q_REG(q, SFX_R_Q_CQ_BASE_LO), static_cast<uint32_t>(h.cq.iova.v));
        wr(SFX_Q_REG(q, SFX_R_Q_CQ_BASE_HI), static_cast<uint32_t>(h.cq.iova.v >> 32));
        wr(SFX_Q_REG(q, SFX_R_Q_SIZE), h.cfg.sq_log2 | (h.cfg.cq_log2 << SFX_QSIZE_CQ_LSB));
        if (h.cfg.vector >= 0) wr(SFX_Q_REG(q, SFX_R_Q_VECTOR), static_cast<uint32_t>(h.cfg.vector));
        wr(SFX_Q_REG(q, SFX_R_Q_SEQ_START), h.cfg.seq_start);
        wr(SFX_Q_REG(q, SFX_R_Q_IRQ_COAL), h.cfg.irq_coal);
    }
    void set_queue_enable(unsigned q, unsigned domain, bool on) {
        wr(SFX_Q_REG(q, SFX_R_Q_CTRL), (on ? SFX_QCTL_ENABLE : 0) | (domain << SFX_QCTL_DOM_LSB));
    }
    uint32_t queue_state(unsigned q) { return rd(SFX_Q_REG(q, SFX_R_Q_STATUS)) & SFX_QSTAT_STATE_MASK; }
    uint32_t queue_err(unsigned q) { return rd(SFX_Q_REG(q, SFX_R_Q_STATUS)) >> SFX_QSTAT_ERR_LSB; }
    // Graceful disable: wait for DISABLED (fetched commands complete first).
    bool disable_queue(unsigned q, unsigned spin_limit = 1000000) {
        wr(SFX_Q_REG(q, SFX_R_Q_CTRL), 0);
        for (unsigned i = 0; i < spin_limit; ++i) {
            if (queue_state(q) == SFX_QS_DISABLED) return true;
            relax();
        }
        return false;
    }
    // Disable, drop the ring mappings, free the rings.  The caller must have stopped using the Queue.
    void destroy_queue(QueueHandle& h) {
        disable_queue(h.id);
        if (h.sq_win >= 0) unmap_window(h.sq_win);
        if (h.cq_win >= 0) unmap_window(h.cq_win);
        if (h.sq.cpu) dma_->free_coherent(h.sq);
        if (h.cq.cpu) dma_->free_coherent(h.cq);
        h = QueueHandle{};
    }
    // The user-role object.  `db` is what the owning process can reach: the doorbell page.
    Queue make_queue(MmioIf& db, const QueueHandle& h) const {
        return Queue(db, h.id, h.sq.cpu, h.cq.cpu, h.cfg.sq_log2, h.cfg.cq_log2, h.cfg.seq_start);
    }

    // ---- interrupts (SPEC 11, H5) ----------------------------------------------------------
    void irq_enable(uint32_t mask) { wr(SFX_R_IRQ_ENABLE, mask); }
    uint32_t irq_status() { return rd(SFX_R_IRQ_STATUS); }
    // Acknowledge exactly the bits that were handled.
    void irq_ack(uint32_t handled) { wr(SFX_R_IRQ_STATUS, handled); }

    // ---- watchdog / reset (SPEC 12, 13) ----------------------------------------------------
    void wdt_enable(uint32_t timeout_clocks) {
        wr(SFX_R_WDT_TIMEOUT, timeout_clocks);
        wr(SFX_R_WDT_CTRL, SFX_WDT_CTRL_ENABLE);
    }
    // Request a controlled reset and wait.  Returns RESET_STATUS; the caller checks DONE vs
    // DRAIN_TIMEOUT.  After DONE the driver MUST re-initialise everything (init(), windows,
    // queues) and zero the CQ rings.
    uint32_t controlled_reset(unsigned spin_limit = 1000000) {
        wr(SFX_R_RESET_CTRL, (SFX_RESET_KEY << SFX_RST_KEY_LSB) | SFX_RST_REQ);
        uint32_t st = 0;
        for (unsigned i = 0; i < spin_limit; ++i) {
            st = rd(SFX_R_RESET_STATUS);
            if ((st & SFX_RST_ST_DONE) || (st & SFX_RST_ST_DRAIN_TIMEOUT)) break;
            relax();
        }
        forget_windows();
        return st;
    }

private:
    static uint32_t win_reg(int w, uint32_t reg) { return SFX_WIN_REG(w, reg); }
    void relax() { if (relax_) relax_(); }
    bool fail(std::string* why, const char* m) { if (why) *why = m; return false; }
    bool wait_clear(uint32_t off, uint32_t mask, unsigned spin_limit) {
        for (unsigned i = 0; i < spin_limit; ++i) {
            if (!(rd(off) & mask)) return true;
            relax();
        }
        return false;
    }
    int map_window(Space sp, uint64_t base, uint64_t size, unsigned perm, unsigned domain) {
        int w = -1;
        for (unsigned i = 0; i < win_used_.size(); ++i)
            if (!win_used_[i]) { w = static_cast<int>(i); break; }
        if (w < 0) return -1;
        wr(win_reg(w, SFX_R_W_BASE_LO), static_cast<uint32_t>(base));
        wr(win_reg(w, SFX_R_W_BASE_HI), static_cast<uint32_t>(base >> 32));
        wr(win_reg(w, SFX_R_W_SIZE_LO), static_cast<uint32_t>(size));
        wr(win_reg(w, SFX_R_W_SIZE_HI), static_cast<uint32_t>(size >> 32));
        uint32_t ctrl = SFX_WIN_VALID | (sp == Space::Dev ? SFX_WIN_SPACE : 0) | ((perm & PermR) ? SFX_WIN_R : 0) |
                        ((perm & PermW) ? SFX_WIN_W : 0) | (domain << SFX_WIN_DOM_LSB);
        wr(win_reg(w, SFX_R_W_CTRL), ctrl);  // commit last (SPEC 4.2)
        if (!(rd(win_reg(w, SFX_R_W_CTRL)) & SFX_WIN_VALID)) return -1;  // rejected (W_CTRL.ERR set)
        win_used_[w] = true;
        return w;
    }

    MmioIf* m_;
    DmaAllocator* dma_;
    std::function<void()> relax_;
    DeviceInfo info_;
    std::vector<bool> win_used_;
};

}  // namespace sfx
