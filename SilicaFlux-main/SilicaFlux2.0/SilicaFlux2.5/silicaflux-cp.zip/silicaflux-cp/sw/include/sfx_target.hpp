// Target: the thing a driver/test talks to.  Two implementations exist:
//   * sfx::ModelTarget  (sw/model)   - software device model, no hardware or simulator needed
//   * sfx::RtlTarget    (sim/)       - the Verilated RTL driven through AXI bus-functional models
// The shared test-suite (tests/) and the reference driver (sfx_driver.hpp) are written against
// this interface only.
#pragma once
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

#include "sim_memory.hpp"

namespace sfx {

// Abstract MMIO window onto the device BAR (control page + doorbell pages).  A real driver would
// implement this over an ioremap()ed BAR; tests use Target.
class MmioIf {
public:
    virtual ~MmioIf() = default;
    virtual uint32_t rd32(uint32_t off) = 0;
    virtual void wr32(uint32_t off, uint32_t v) = 0;
};

struct KernelReq {
    uint32_t tag = 0;
    uint32_t cmd_id = 0;
    uint64_t kernel_addr = 0, args_addr = 0;
    uint32_t args_size = 0;
    uint32_t grid[3] = {1, 1, 1};
    uint8_t domain = 0;
};
struct KernelResult {
    uint32_t latency = 1;  // time units (RTL cycles / model ticks) from launch to completion
    uint8_t status = 0;    // KD_OK(0) / KD_FAULT(1)
    uint64_t info = 0;     // copied to the CQE `result`
    bool hang = false;     // never complete on its own; only kd_abort ends it
    uint32_t heartbeat_period = 0;  // if non-zero, emit kd_heartbeat this often while running
};
using KernelHook = std::function<KernelResult(const KernelReq&)>;

enum class EvKind { Issue, DmaDone, Publish };
struct Event {
    EvKind kind;
    uint64_t time;
    uint32_t cmd_id;
    uint8_t queue;
};

// Bus perturbation knobs.  Honoured by the RTL harness; the software model ignores them.
struct BusProfile {
    unsigned ready_pct = 100;  // % of cycles a slave-side ready is asserted
    unsigned valid_pct = 100;  // % of cycles a slave presents rvalid/bvalid when it has data
    unsigned latency_min = 1;  // cycles from request accept to first response
    unsigned latency_max = 1;
    unsigned lite_gap = 0;     // idle cycles inserted between MMIO operations
    uint64_t seed = 1;
};

// Implementation geometry (also readable from registers; the extra fields are not architectural).
struct Geometry {
    unsigned num_queues = 2;
    unsigned num_windows = 8;
    unsigned num_vectors = 3;
    unsigned inflight_depth = 4;
    unsigned dma_align = 8;
    unsigned max_burst_beats = 16;
    unsigned beat_bytes = 8;
    uint64_t dev_mem_size = 16u << 20;
    unsigned host_addr_bits = 48;
};

class Target : public MmioIf {
public:
    Target(uint64_t host_base, uint64_t host_size, uint64_t dev_size)
        : host("host", host_base, host_size), dev("dev", 0, dev_size) {
        host.clock = &time_;
        dev.clock = &time_;
    }
    ~Target() override = default;

    virtual const char* name() const = 0;
    virtual bool is_rtl() const { return false; }
    virtual const Geometry& geometry() const = 0;

    // Advance simulated time by n units.  Interrupt edges, kernel hooks, memory hooks and events
    // fire synchronously from inside run().
    virtual void run(uint64_t n) = 0;
    uint64_t now() const { return time_; }

    // Whole-device power-on reset (like asserting rst_n).  Memories keep their contents.
    virtual void hard_reset() = 0;

    virtual bool irq_level(unsigned vec) const = 0;

    // RTL-only perturbations; the model ignores them.
    virtual void set_bus_profile(const BusProfile&) {}
    // Non-empty if a protocol checker saw a violation (AXI rules, one-outstanding rule, ...).
    virtual std::string protocol_errors() const { return ""; }

    SimMemory host;  // system memory the device reaches by DMA (address space = IOVA)
    SimMemory dev;   // device-local memory (address space = device address)

    KernelHook kernel_hook;                      // default: latency 1, KD_OK
    std::vector<KernelReq> kernels_launched;     // every kernel handed to the fabric
    std::function<void(unsigned vec)> on_irq_rise;
    std::vector<Event> events;

protected:
    uint64_t time_ = 0;
};

}  // namespace sfx
