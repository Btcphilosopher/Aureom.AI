// SimMemory: byte-addressable memory used as "host memory" and "device memory" by both
// the software device model and the Verilator RTL harness.  It models the *far end of a bus*:
// device-initiated transactions go through txn()/read()/write(), which apply range checks, fault
// injection and logging; tests use the backdoor (ptr/poke/peek) which does none of those.
#pragma once
#include <cstdint>
#include <cstring>
#include <functional>
#include <string>
#include <vector>

namespace sfx {

enum class Resp : uint8_t { OKAY = 0, SLVERR = 2, DECERR = 3 };

// A bus-error rule, matched once per *transaction* (burst), never per beat.  A transaction matches
// if its byte range intersects [lo, hi).  The model and the RTL harness both call txn() once per
// burst, so rules behave identically in both.
struct FaultRule {
    uint64_t lo = 0, hi = 0;
    bool on_read = true, on_write = true;
    Resp resp = Resp::SLVERR;
    int skip = 0;    // matching transactions that pass before injection starts
    int count = -1;  // injections to perform; -1 = forever
};

struct Access {
    bool write;
    uint64_t addr;
    uint64_t len;
    uint64_t time;
    Resp resp;
};

class SimMemory {
public:
    SimMemory(std::string name, uint64_t base, uint64_t size)
        : name_(std::move(name)), base_(base), data_(size, 0) {}

    const std::string& name() const { return name_; }
    uint64_t base() const { return base_; }
    uint64_t size() const { return data_.size(); }
    bool contains(uint64_t addr, uint64_t len) const {
        return len <= size() && addr >= base_ && addr - base_ <= size() - len;
    }

    // ---- backdoor (no logging, no faults) -------------------------------------------------
    uint8_t* ptr(uint64_t addr, uint64_t len) {
        return contains(addr, len) ? &data_[addr - base_] : nullptr;
    }
    const uint8_t* ptr(uint64_t addr, uint64_t len) const {
        return contains(addr, len) ? &data_[addr - base_] : nullptr;
    }
    void poke(uint64_t addr, const void* src, uint64_t n) {
        uint8_t* p = ptr(addr, n);
        if (p) std::memcpy(p, src, n);
    }
    void peek(uint64_t addr, void* dst, uint64_t n) const {
        const uint8_t* p = ptr(addr, n);
        if (p) std::memcpy(dst, p, n);
        else std::memset(dst, 0xEE, n);
    }
    void fill(uint64_t addr, uint8_t v, uint64_t n) {
        uint8_t* p = ptr(addr, n);
        if (p) std::memset(p, v, n);
    }
    template <typename T> T peek_as(uint64_t addr) const {
        T v{};
        peek(addr, &v, sizeof v);
        return v;
    }
    template <typename T> void poke_as(uint64_t addr, T v) { poke(addr, &v, sizeof v); }

    // ---- device-initiated transactions ----------------------------------------------------
    // Decide the response for a whole transaction; logs it; consumes fault-rule counters.
    // Does not move data.  Out-of-range => DECERR.
    Resp txn(bool write, uint64_t addr, uint64_t len) {
        Resp r = Resp::OKAY;
        if (!contains(addr, len)) {
            r = Resp::DECERR;
        } else {
            for (auto& f : faults_) {
                if (write ? !f.on_write : !f.on_read) continue;
                if (addr >= f.hi || addr + len <= f.lo) continue;
                if (f.skip > 0) { --f.skip; continue; }
                if (f.count == 0) continue;
                if (f.count > 0) --f.count;
                r = f.resp;
                break;
            }
        }
        log.push_back({write, addr, len, clock ? *clock : 0, r});
        return r;
    }
    // Convenience for the software model: whole-transaction read/write with data movement.
    Resp read(uint64_t addr, void* dst, uint64_t len) {
        Resp r = txn(false, addr, len);
        if (r == Resp::OKAY) std::memcpy(dst, &data_[addr - base_], len);
        return r;
    }
    Resp write(uint64_t addr, const void* src, uint64_t len, const uint8_t* byte_en = nullptr) {
        Resp r = txn(true, addr, len);
        if (r == Resp::OKAY) {
            apply_write(addr, src, len, byte_en);
            notify_write_done(addr, len);
        }
        return r;
    }
    // Used by the RTL harness per beat (after txn() said OKAY).
    void apply_write(uint64_t addr, const void* src, uint64_t len, const uint8_t* byte_en = nullptr) {
        uint8_t* p = ptr(addr, len);
        if (!p) return;
        const uint8_t* s = static_cast<const uint8_t*>(src);
        for (uint64_t i = 0; i < len; ++i)
            if (!byte_en || byte_en[i]) p[i] = s[i];
    }
    void notify_write_done(uint64_t addr, uint64_t len) {
        if (write_hook) write_hook(addr, len);
    }

    // ---- fault injection / observation ----------------------------------------------------
    void add_fault(const FaultRule& f) { faults_.push_back(f); }
    void clear_faults() { faults_.clear(); }
    // A hung memory never responds: the model stalls the access, the RTL harness deasserts all
    // ready/valid on this bus.  Used for watchdog and reset-drain-timeout tests.
    void set_hang(bool h) { hung_ = h; }
    bool hung() const { return hung_; }

    std::vector<Access> log;  // every device-initiated transaction, in order
    void clear_log() { log.clear(); }
    // Did the device touch [lo,hi) with a read/write/either (0 any, 1 read, 2 write)?
    bool touched(uint64_t lo, uint64_t hi, int kind = 0) const {
        for (const auto& a : log) {
            if (a.addr >= hi || a.addr + a.len <= lo) continue;
            if (kind == 1 && a.write) continue;
            if (kind == 2 && !a.write) continue;
            return true;
        }
        return false;
    }
    // Called after a device write has been applied (after its last beat).
    std::function<void(uint64_t addr, uint64_t len)> write_hook;
    const uint64_t* clock = nullptr;  // set by the Target; used to timestamp the log

private:
    std::string name_;
    uint64_t base_;
    std::vector<uint8_t> data_;
    std::vector<FaultRule> faults_;
    bool hung_ = false;
};

}  // namespace sfx
