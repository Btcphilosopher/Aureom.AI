// SFX-CP software device model.
//
// A tick-based functional model of the whole device in docs/SPEC.md: register file, DMA
// authorisation windows, queues and doorbells, descriptor validation, in-flight table with
// in-order retire, DMA engine, two-phase completion publish, interrupts, watchdog and controlled
// reset.  It is NOT cycle accurate: one run(1) is one "tick", a DMA burst takes a few ticks, a
// register access takes one tick.  It exists so driver and test development does not need
// hardware or an HDL simulator, and as the golden functional reference for the RTL.
#pragma once
#include <memory>

#include "sfx_target.hpp"

namespace sfx {

class ModelTarget final : public Target {
public:
    explicit ModelTarget(const Geometry& g = Geometry{});
    ~ModelTarget() override;

    const char* name() const override { return "model"; }
    const Geometry& geometry() const override { return geom_; }

    uint32_t rd32(uint32_t off) override;
    void wr32(uint32_t off, uint32_t v) override;
    void run(uint64_t n) override;
    void hard_reset() override;
    bool irq_level(unsigned vec) const override;

    // Host-memory placement used by the model (deliberately not like any process VA).
    static constexpr uint64_t kHostBase = 0x0000400000000000ull;
    static constexpr uint64_t kHostSize = 8u << 20;

private:
    Geometry geom_;
    struct Impl;
    std::unique_ptr<Impl> p_;
};

std::unique_ptr<Target> make_model_target(const Geometry& g = Geometry{});

}  // namespace sfx
