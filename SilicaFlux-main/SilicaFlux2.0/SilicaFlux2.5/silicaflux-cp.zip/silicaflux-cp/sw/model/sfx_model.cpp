#include "sfx_model.hpp"

#include <algorithm>
#include <cstring>
#include <deque>

#include "sfx_abi.h"

namespace sfx {

namespace {
constexpr unsigned kTicksPerTxn = 2;  // ticks a bus transaction is "outstanding" (window in use)
constexpr uint32_t kDefaultResetTimeout = 100000;

uint32_t lo32(uint64_t v) { return static_cast<uint32_t>(v); }
uint32_t hi32(uint64_t v) { return static_cast<uint32_t>(v >> 32); }
}  // namespace

struct ModelTarget::Impl {
    ModelTarget& T;
    Geometry g;
    unsigned nq, nw, nv, depth;
    uint32_t burst_bytes;

    // ---------------------------------------------------------------- state ----------------
    struct Window {
        bool valid = false, err = false, space_dev = false, r = false, w = false;
        uint8_t dom = 0;
        uint64_t base = 0, size = 0;
        int use = 0;  // in-flight bus transactions that were authorised through this window
    };
    struct Queue {
        uint8_t state = SFX_QS_DISABLED, err_code = 0;
        bool dropping = false;
        uint8_t dom = 0;
        uint64_t sq_base = 0, cq_base = 0;
        uint32_t size_reg = 0, vector = 0, seq_start = 0, coal = 0;
        uint32_t sq_head = 0, sq_tail = 0, cq_head = 0, cq_tail = 0;
        uint32_t cmds_ok = 0, cmds_err = 0;
        uint32_t rst_sq_tail = 0, rst_sq_head = 0, rst_cq_tail = 0;  // persistent
        uint32_t coal_cnt = 0;
        uint64_t coal_timer = 0;
        uint32_t sq_log2() const { return size_reg & 0x1F; }
        uint32_t cq_log2() const { return (size_reg >> 8) & 0x1F; }
    };
    struct Inf {
        bool valid = false, done = false, is_kernel = false, sig_en = false;
        unsigned q = 0;
        uint32_t seq = 0, cmd_id = 0;
        uint16_t opcode = 0, flags = 0, status = 0;
        uint64_t result = 0, sig_addr = 0, sig_val = 0;
        uint8_t dom = 0;
        // kernel execution
        int k_left = 0;
        bool k_hang = false;
        uint8_t k_status = 0;
        uint64_t k_info = 0;
        uint32_t k_hb_period = 0, k_hb_cnt = 0;
    };
    struct Dma {
        bool busy = false;
        unsigned tag = 0, q = 0;
        bool src_dev = false, dst_dev = false;
        uint64_t src = 0, dst = 0;
        uint32_t len = 0;
        uint8_t dom = 0;
        uint64_t rd_off = 0, wr_off = 0;
        std::deque<uint8_t> fifo;
        bool r_act = false, w_act = false;
        int r_left = 0, w_left = 0, r_win = -1, w_win = -1;
        uint64_t r_addr = 0, r_n = 0, w_addr = 0;
        std::vector<uint8_t> w_buf;
        bool rd_stop = false, wr_stop = false, aborted = false;
        uint16_t status = SFX_ST_OK;
        uint64_t fault_addr = 0;
    };

    // global registers
    bool ctrl_enable = false;
    uint32_t abi_req = 0, scratch = 0;
    uint32_t err_status = 0, err_count = 0, dup_db = 0;
    uint32_t fault_cause = 0;
    uint64_t fault_addr = 0;
    uint32_t fault_info = 0;
    uint32_t cmds_ok = 0, cmds_err = 0;
    uint32_t irq_status = 0, irq_enable = 0, irq_misc_vec = 0;
    bool wdt_en = false;
    uint32_t wdt_timeout = 0, wdt_count = 0, wdt_expired = 0, wdt_stuck = 0, wdt_expiries = 0;
    bool wdt_armed = false;
    uint32_t rst_timeout = kDefaultResetTimeout;
    bool rst_done = false, rst_drain_to = false;
    uint32_t rst_count = 0;
    bool resetting = false;
    uint32_t rst_wait = 0;
    bool fault = false;

    std::vector<Window> win;
    std::vector<Queue> qs;

    // in-flight table (ring)
    std::vector<Inf> tab;
    unsigned tab_head = 0, tab_cnt = 0;

    // front end
    enum Fe { FE_IDLE, FE_FETCH, FE_ISSUE } fe = FE_IDLE;
    unsigned fe_q = 0, rr = 0;
    uint32_t fe_seq = 0;
    int fe_left = 0, fe_win = -1;
    uint64_t fe_addr = 0;
    sfx_desc_t desc{};
    struct Dec {
        uint16_t status = SFX_ST_OK;
        bool copy = false, kernel = false, fence_sig = false;
        bool src_dev = false, dst_dev = false;
        uint64_t fault_addr = 0;
        bool fault_dev = false;
    } dec;

    Dma dma;

    // retire
    enum Rt { RT_IDLE, RT_SIG, RT_BODY, RT_PHASE } rt = RT_IDLE;
    int rt_left = 0, rt_win = -1;
    uint64_t rt_addr = 0;
    sfx_cqe_t cqe{};
    bool retire_blocked = false;

    // misc
    bool progress = false;
    bool in_tick = false;
    int blank = 0;
    std::vector<bool> level, level_prev;

    explicit Impl(ModelTarget& t, const Geometry& geo) : T(t), g(geo) {
        nq = g.num_queues;
        nw = g.num_windows;
        nv = nq + 1;
        depth = g.inflight_depth;
        burst_bytes = g.max_burst_beats * g.beat_bytes;
        g.num_vectors = nv;
        level.assign(nv, false);
        level_prev.assign(nv, false);
        reset_state(true);
    }

    // ---------------------------------------------------------------- helpers --------------
    bool quiesce() const { return resetting; }
    bool kd_abort() const { return resetting || fault; }
    bool abi_ok() const {
        return (abi_req >> 16) == SFX_ABI_MAJOR && (abi_req & 0xFFFF) <= SFX_ABI_MINOR;
    }
    bool mem_hung(bool dev) const { return dev ? T.dev.hung() : T.host.hung(); }
    SimMemory& mem(bool dev) { return dev ? T.dev : T.host; }
    void ev(EvKind k, uint32_t cmd_id, unsigned q) {
        T.events.push_back({k, T.time_, cmd_id, static_cast<uint8_t>(q)});
    }

    void reset_state(bool hard) {
        ctrl_enable = false;
        abi_req = 0;
        err_status = err_count = dup_db = 0;
        fault_cause = 0;
        fault_addr = 0;
        fault_info = 0;
        cmds_ok = cmds_err = 0;
        irq_status = 0;
        wdt_en = false;
        wdt_timeout = wdt_count = wdt_expired = wdt_stuck = wdt_expiries = 0;
        wdt_armed = false;
        fault = false;
        win.assign(nw, Window{});
        for (unsigned q = 0; q < nq; ++q) {
            Queue old = qs.size() > q ? qs[q] : Queue{};
            Queue n;
            n.vector = q;
            if (!hard) {
                n.rst_sq_tail = old.rst_sq_tail;
                n.rst_sq_head = old.rst_sq_head;
                n.rst_cq_tail = old.rst_cq_tail;
            }
            if (qs.size() <= q) qs.push_back(n);
            else qs[q] = n;
        }
        tab.assign(depth, Inf{});
        tab_head = tab_cnt = 0;
        fe = FE_IDLE;
        fe_win = -1;
        dma = Dma{};
        rt = RT_IDLE;
        rt_win = -1;
        retire_blocked = false;
        progress = false;
        blank = 0;
        if (hard) {
            scratch = 0;
            irq_enable = 0;
            irq_misc_vec = nq;
            rst_timeout = kDefaultResetTimeout;
            rst_done = rst_drain_to = false;
            rst_count = 0;
            resetting = false;
            rst_wait = 0;
            for (unsigned q = 0; q < nq; ++q) qs[q].rst_sq_tail = qs[q].rst_sq_head = qs[q].rst_cq_tail = 0;
        }
    }

    // Errors raised by writes to the user-mappable doorbell pages are recorded but never raise DEV_ERR.
    bool quiet_err = false;
    void set_err(uint32_t bit) {
        ++err_count;
        if (!(err_status & bit) && !quiet_err) irq_status |= SFX_IRQ_DEV_ERR;
        err_status |= bit;
    }
    // FAULT_INFO = {12'b0, queue[3:0], status[15:0]}; last fault wins; ST_ABORTED is never recorded.
    void record_fault(uint64_t addr, uint32_t code, unsigned q) {
        fault_addr = addr;
        fault_info = (code & 0xFFFF) | ((q & 0xF) << 16);
    }

    // ---------------------------------------------------------------- authorisation --------
    int authz(bool dev, uint8_t dom, uint64_t addr, uint64_t len, bool wr) const {
        for (unsigned i = 0; i < nw; ++i) {
            const Window& w = win[i];
            if (!w.valid || w.space_dev != dev || w.dom != dom) continue;
            if (!(wr ? w.w : w.r)) continue;
            if (len <= w.size && addr >= w.base && addr - w.base <= w.size - len) return static_cast<int>(i);
        }
        return -1;
    }
    bool range_ok(bool dev, uint64_t addr, uint64_t len) const {
        uint64_t lim = dev ? g.dev_mem_size : (1ull << g.host_addr_bits);
        return len <= lim && addr <= lim - len;
    }
    void use(int w) { if (w >= 0) ++win[w].use; }
    void unuse(int w) { if (w >= 0 && win[w].use > 0) --win[w].use; }

    // ---------------------------------------------------------------- queue helpers --------
    uint32_t sq_size(const Queue& Q) const { return 1u << Q.sq_log2(); }
    uint32_t cq_size(const Queue& Q) const { return 1u << Q.cq_log2(); }
    // CQ credit (SPEC 7.7): commands consumed but not yet released by the host must fit in the CQ, so a
    // completion slot is guaranteed for one more command. A queue without credit is not served.
    bool cq_credit(const Queue& Q) const { return (Q.sq_head - Q.cq_head) < cq_size(Q); }

    void qfatal(unsigned q, uint8_t code, uint64_t addr) {
        Queue& Q = qs[q];
        Q.err_code = code;
        Q.dropping = true;
        if (Q.state == SFX_QS_ENABLED) Q.state = SFX_QS_ERROR;
        irq_status |= 1u << (SFX_IRQ_QERR_LSB + q);
        record_fault(addr, 0x8000u | code, q);  // queue-fatal: 0x8000 | QERR, addr = failing ring slot
    }
    bool qbusy(unsigned q) const {
        if (fe != FE_IDLE && fe_q == q) return true;
        for (unsigned i = 0; i < depth; ++i)
            if (tab[i].valid && tab[i].q == q) return true;
        return false;
    }
    bool publish_ok(unsigned q) const {
        const Queue& Q = qs[q];
        return (Q.state == SFX_QS_ENABLED || Q.state == SFX_QS_DRAINING) && !Q.dropping;
    }

    // ---------------------------------------------------------------- decode ---------------
    Dec decode(const sfx_desc_t& d, uint8_t dom) const {
        Dec x;
        const uint16_t op = d.opcode;
        if (d.desc_ver != SFX_DESC_VERSION) { x.status = SFX_ST_BAD_VERSION; return x; }
        if (!(op == SFX_OP_NOP || op == SFX_OP_COPY_H2D || op == SFX_OP_COPY_D2H || op == SFX_OP_COPY_D2D ||
              op == SFX_OP_KERNEL || op == SFX_OP_FENCE)) { x.status = SFX_ST_BAD_OPCODE; return x; }
        const bool is_fence = op == SFX_OP_FENCE;
        if ((d.flags & ~SFX_F_VALID_MASK) || (!is_fence && (d.flags & (SFX_F_FENCE_SCOPE_ALL | SFX_F_FENCE_SIGNAL)))) {
            x.status = SFX_ST_BAD_FLAGS; return x;
        }
        const bool sig = is_fence && (d.flags & SFX_F_FENCE_SIGNAL);
        bool mbz = d.rsvd0 || d.rsvd1;
        switch (op) {
        case SFX_OP_NOP:
            mbz |= d.addr0 || d.addr1 || d.length || d.aux0 || d.aux1 || d.aux2 || d.value; break;
        case SFX_OP_COPY_H2D: case SFX_OP_COPY_D2H: case SFX_OP_COPY_D2D:
            mbz |= d.aux0 || d.aux1 || d.aux2 || d.value; break;
        case SFX_OP_KERNEL:
            mbz |= d.value != 0; break;
        case SFX_OP_FENCE:
            mbz |= d.addr1 || d.length || d.aux0 || d.aux1 || d.aux2;
            if (!sig) mbz |= d.addr0 || d.value;
            break;
        }
        if (mbz) { x.status = SFX_ST_BAD_DESC; return x; }

        if (op == SFX_OP_COPY_H2D || op == SFX_OP_COPY_D2H || op == SFX_OP_COPY_D2D) {
            x.copy = true;
            x.src_dev = op != SFX_OP_COPY_H2D;
            x.dst_dev = op != SFX_OP_COPY_D2H;
            if (d.length == 0 || d.length > SFX_MAX_COPY_BYTES || d.length % g.dma_align) { x.status = SFX_ST_BAD_LENGTH; return x; }
            if (d.addr0 % g.dma_align || d.addr1 % g.dma_align) { x.status = SFX_ST_BAD_ALIGN; return x; }
            if (!range_ok(x.src_dev, d.addr0, d.length) || !range_ok(x.dst_dev, d.addr1, d.length)) { x.status = SFX_ST_BAD_RANGE; return x; }
            if (authz(x.src_dev, dom, d.addr0, d.length, false) < 0) {
                x.status = SFX_ST_UNAUTHORIZED; x.fault_addr = d.addr0; x.fault_dev = x.src_dev; return x;
            }
            if (authz(x.dst_dev, dom, d.addr1, d.length, true) < 0) {
                x.status = SFX_ST_UNAUTHORIZED; x.fault_addr = d.addr1; x.fault_dev = x.dst_dev; return x;
            }
        } else if (op == SFX_OP_KERNEL) {
            x.kernel = true;
            for (uint32_t gd : {d.aux0, d.aux1, d.aux2})
                if (gd == 0 || gd > SFX_MAX_GRID_DIM) { x.status = SFX_ST_BAD_DESC; return x; }
            if (d.length == 0 && d.addr1 != 0) { x.status = SFX_ST_BAD_DESC; return x; }
            if (d.length > SFX_MAX_ARGS_BYTES || d.length % 8) { x.status = SFX_ST_BAD_LENGTH; return x; }
            if (d.addr0 % 8 || d.addr1 % 8) { x.status = SFX_ST_BAD_ALIGN; return x; }
            if (!range_ok(true, d.addr0, 8) || (d.length && !range_ok(true, d.addr1, d.length))) { x.status = SFX_ST_BAD_RANGE; return x; }
            if (authz(true, dom, d.addr0, 8, false) < 0) {
                x.status = SFX_ST_UNAUTHORIZED; x.fault_addr = d.addr0; x.fault_dev = true; return x;
            }
            if (d.length && authz(true, dom, d.addr1, d.length, false) < 0) {
                x.status = SFX_ST_UNAUTHORIZED; x.fault_addr = d.addr1; x.fault_dev = true; return x;
            }
        } else if (sig) {
            x.fence_sig = true;
            if (d.addr0 % 8) { x.status = SFX_ST_BAD_ALIGN; return x; }
            if (!range_ok(false, d.addr0, 8)) { x.status = SFX_ST_BAD_RANGE; return x; }
            if (authz(false, dom, d.addr0, 8, true) < 0) {
                x.status = SFX_ST_UNAUTHORIZED; x.fault_addr = d.addr0; x.fault_dev = false; return x;
            }
        }
        return x;
    }

    // ---------------------------------------------------------------- in-flight table ------
    Inf& head() { return tab[tab_head]; }
    bool fence_in_flight() const {
        for (unsigned i = 0; i < depth; ++i)
            if (tab[i].valid && tab[i].opcode == SFX_OP_FENCE) return true;
        return false;
    }
    void pop() {
        tab[tab_head] = Inf{};
        tab_head = (tab_head + 1) % depth;
        --tab_cnt;
    }
    bool any_kernel_running() const {
        for (unsigned i = 0; i < depth; ++i)
            if (tab[i].valid && tab[i].is_kernel && !tab[i].done) return true;
        return false;
    }
    bool unfetched_work() const {
        for (unsigned q = 0; q < nq; ++q)
            if (qs[q].state == SFX_QS_ENABLED && qs[q].sq_tail != qs[q].sq_head) return true;
        return false;
    }
    // Work the device could start now (the watchdog does not count waiting for the host to release CQ slots).
    bool startable_work() const {
        for (unsigned q = 0; q < nq; ++q)
            if (qs[q].state == SFX_QS_ENABLED && qs[q].sq_tail != qs[q].sq_head && cq_credit(qs[q])) return true;
        return false;
    }

    // ---------------------------------------------------------------- tick -----------------
    void tick() {
        in_tick = true;
        ++T.time_;
        if (blank > 0) --blank;
        tick_reset();
        tick_kernels();
        tick_dma();
        tick_frontend();
        tick_retire();
        tick_queues();
        tick_wdt();
        update_irq();
        in_tick = false;
    }

    // -- kernels
    void tick_kernels() {
        for (unsigned i = 0; i < depth; ++i) {
            Inf& e = tab[i];
            if (!e.valid || !e.is_kernel || e.done) continue;
            uint8_t st;
            uint64_t info = 0;
            bool fin = false;
            if (kd_abort()) {
                st = SFX_KD_ABORTED; fin = true;
            } else if (!e.k_hang) {
                if (e.k_hb_period && ++e.k_hb_cnt >= e.k_hb_period) { e.k_hb_cnt = 0; progress = true; }
                if (--e.k_left <= 0) { st = e.k_status; info = e.k_info; fin = true; }
            }
            if (!fin) continue;
            e.done = true;
            progress = true;
            if (st == SFX_KD_OK) { e.status = SFX_ST_OK; e.result = info; }
            else if (st == SFX_KD_FAULT) { e.status = SFX_ST_KERNEL_FAULT; e.result = info; }
            else { e.status = fault ? SFX_ST_TIMEOUT : SFX_ST_ABORTED; e.result = 0; }
        }
    }

    // -- DMA
    uint32_t burst_len(uint64_t addr, uint64_t remaining) const {
        uint64_t to4k = 4096 - (addr & 4095);
        return static_cast<uint32_t>(std::min<uint64_t>({remaining, burst_bytes, to4k}));
    }
    void dma_err(uint16_t st, uint64_t addr, bool dev) {
        (void)dev;
        if (dma.status != SFX_ST_OK) return;
        dma.status = st;
        dma.fault_addr = addr;  // start address of the failing burst; recorded at command completion
    }
    void tick_dma() {
        Dma& d = dma;
        if (!d.busy) return;
        if ((quiesce() || fault) && !d.aborted) {
            d.aborted = true;
            d.rd_stop = d.wr_stop = true;
        }
        const uint64_t cap = 2ull * burst_bytes;
        // read side
        if (d.r_act) {
            if (!mem_hung(d.src_dev) && --d.r_left <= 0) {
                std::vector<uint8_t> buf(d.r_n);
                Resp r = mem(d.src_dev).read(d.r_addr, buf.data(), d.r_n);
                unuse(d.r_win);
                d.r_act = false;
                progress = true;
                if (r != Resp::OKAY) {
                    dma_err(SFX_ST_DMA_READ_ERR, d.r_addr, d.src_dev);
                    d.rd_stop = true;
                } else {
                    d.fifo.insert(d.fifo.end(), buf.begin(), buf.end());
                    d.rd_off += d.r_n;
                }
            }
        } else if (!d.rd_stop && d.rd_off < d.len) {
            uint64_t a = d.src + d.rd_off;
            uint32_t n = burst_len(a, d.len - d.rd_off);
            if (cap - d.fifo.size() >= n) {
                int w = authz(d.src_dev, d.dom, a, n, false);
                if (w < 0) {
                    dma_err(SFX_ST_UNAUTHORIZED, a, d.src_dev);
                    d.rd_stop = true;
                } else {
                    use(w);
                    d.r_win = w; d.r_act = true; d.r_left = kTicksPerTxn; d.r_addr = a; d.r_n = n;
                }
            }
        }
        // write side
        if (d.w_act) {
            if (!mem_hung(d.dst_dev) && --d.w_left <= 0) {
                Resp r = mem(d.dst_dev).write(d.w_addr, d.w_buf.data(), d.w_buf.size());
                unuse(d.w_win);
                d.w_act = false;
                progress = true;
                if (r != Resp::OKAY) {
                    dma_err(SFX_ST_DMA_WRITE_ERR, d.w_addr, d.dst_dev);
                    d.wr_stop = d.rd_stop = true;
                } else {
                    d.wr_off += d.w_buf.size();
                }
            }
        } else if (!d.wr_stop && d.wr_off < d.len) {
            uint64_t a = d.dst + d.wr_off;
            uint32_t planned = burst_len(a, d.len - d.wr_off);
            uint64_t avail = d.fifo.size();
            bool rd_fin = !d.r_act && (d.rd_off == d.len || d.rd_stop);
            if (avail >= planned || (rd_fin && avail > 0)) {
                uint32_t n = static_cast<uint32_t>(std::min<uint64_t>(planned, avail));
                int w = authz(d.dst_dev, d.dom, a, n, true);
                if (w < 0) {
                    dma_err(SFX_ST_UNAUTHORIZED, a, d.dst_dev);
                    d.wr_stop = d.rd_stop = true;
                } else {
                    use(w);
                    d.w_win = w; d.w_act = true; d.w_left = kTicksPerTxn; d.w_addr = a;
                    d.w_buf.assign(d.fifo.begin(), d.fifo.begin() + n);
                    d.fifo.erase(d.fifo.begin(), d.fifo.begin() + n);
                }
            }
        }
        // completion
        bool rd_fin = !d.r_act && (d.rd_off == d.len || d.rd_stop);
        bool wr_fin = !d.w_act && (d.wr_off == d.len || d.wr_stop || (rd_fin && d.fifo.empty()));
        if (rd_fin && wr_fin) {
            uint16_t st = d.status;
            if (st == SFX_ST_OK && d.wr_off < d.len) st = fault ? SFX_ST_TIMEOUT : SFX_ST_ABORTED;
            if (st == SFX_ST_DMA_READ_ERR || st == SFX_ST_DMA_WRITE_ERR || st == SFX_ST_UNAUTHORIZED)
                record_fault(d.fault_addr, st, d.q);
            Inf& e = tab[d.tag];
            e.done = true;
            e.status = st;
            e.result = d.wr_off;
            ev(EvKind::DmaDone, e.cmd_id, e.q);
            progress = true;
            d = Dma{};
        }
    }

    // -- front end
    bool fe_running() const { return ctrl_enable && !fault && !resetting; }

    void tick_frontend() {
        switch (fe) {
        case FE_IDLE: {
            if (!fe_running()) return;
            for (unsigned i = 0; i < nq; ++i) {
                unsigned q = (rr + 1 + i) % nq;
                Queue& Q = qs[q];
                if (Q.state != SFX_QS_ENABLED || Q.sq_tail == Q.sq_head || !cq_credit(Q)) continue;
                rr = q;
                fe_q = q;
                fe_seq = Q.sq_head;
                fe_addr = Q.sq_base + static_cast<uint64_t>(fe_seq & (sq_size(Q) - 1)) * SFX_DESC_BYTES;
                int w = authz(false, Q.dom, fe_addr, SFX_DESC_BYTES, false);
                if (w < 0) { qfatal(q, SFX_QERR_RING_UNAUTH, fe_addr); return; }
                use(w);
                fe_win = w;
                fe_left = kTicksPerTxn;
                fe = FE_FETCH;
                return;
            }
            return;
        }
        case FE_FETCH: {
            if (T.host.hung()) return;
            if (--fe_left > 0) return;
            Resp r = T.host.read(fe_addr, &desc, SFX_DESC_BYTES);
            unuse(fe_win);
            fe_win = -1;
            progress = true;
            Queue& Q = qs[fe_q];
            if (r != Resp::OKAY) {
                qfatal(fe_q, SFX_QERR_SQ_FETCH, fe_addr);
                fe = FE_IDLE;
                return;
            }
            if (!fe_running() || Q.state != SFX_QS_ENABLED) { fe = FE_IDLE; return; }  // dropped
            if (desc.seq != fe_seq) {
                qfatal(fe_q, SFX_QERR_BAD_SEQ, fe_addr);
                fe = FE_IDLE;
                return;
            }
            dec = decode(desc, Q.dom);
            fe = FE_ISSUE;
            return;
        }
        case FE_ISSUE: {
            Queue& Q = qs[fe_q];
            if (!fe_running() || Q.state != SFX_QS_ENABLED) { fe = FE_IDLE; return; }
            const bool is_fence = desc.opcode == SFX_OP_FENCE;
            if (tab_cnt >= depth) return;
            if (!is_fence && fence_in_flight()) return;
            if ((desc.flags & SFX_F_FENCE_BEFORE) && tab_cnt != 0) return;
            const bool ok = dec.status == SFX_ST_OK;
            if (ok && dec.copy && dma.busy) return;

            unsigned idx = (tab_head + tab_cnt) % depth;
            Inf& e = tab[idx];
            e = Inf{};
            e.valid = true;
            e.q = fe_q;
            e.seq = fe_seq;
            e.cmd_id = desc.cmd_id;
            e.opcode = desc.opcode;
            e.flags = desc.flags;
            e.status = dec.status;
            e.dom = Q.dom;
            ++tab_cnt;
            if (!ok) {
                e.done = true;
                if (dec.status == SFX_ST_UNAUTHORIZED) record_fault(dec.fault_addr, dec.status, fe_q);
            } else if (dec.copy) {
                dma = Dma{};
                dma.busy = true; dma.tag = idx; dma.q = fe_q;
                dma.src_dev = dec.src_dev; dma.dst_dev = dec.dst_dev;
                dma.src = desc.addr0; dma.dst = desc.addr1; dma.len = desc.length; dma.dom = Q.dom;
            } else if (dec.kernel) {
                e.is_kernel = true;
                KernelReq kr;
                kr.tag = idx; kr.cmd_id = desc.cmd_id;
                kr.kernel_addr = desc.addr0; kr.args_addr = desc.addr1; kr.args_size = desc.length;
                kr.grid[0] = desc.aux0; kr.grid[1] = desc.aux1; kr.grid[2] = desc.aux2;
                kr.domain = Q.dom;
                KernelResult res;
                if (T.kernel_hook) res = T.kernel_hook(kr);
                T.kernels_launched.push_back(kr);
                e.k_left = static_cast<int>(std::max<uint32_t>(res.latency, 1));
                e.k_hang = res.hang;
                e.k_status = res.status;
                e.k_info = res.info;
                e.k_hb_period = res.heartbeat_period;
            } else {
                e.done = true;  // NOP and FENCE complete at issue; FENCE acts at retire
                e.sig_en = dec.fence_sig;
                e.sig_addr = desc.addr0;
                e.sig_val = desc.value;
            }
            ++Q.sq_head;
            ev(EvKind::Issue, desc.cmd_id, fe_q);
            progress = true;
            fe = FE_IDLE;
            return;
        }
        }
    }

    // -- retire
    uint64_t cq_slot_addr(const Queue& Q, uint32_t n) const {
        return Q.cq_base + static_cast<uint64_t>(n & (cq_size(Q) - 1)) * SFX_CQE_BYTES;
    }
    // Start the next bus write of the retire sequence: authorise, mark window in use.
    bool rt_start(unsigned q, uint64_t addr, uint64_t len, Rt next, bool ring) {
        int w = authz(false, qs[q].dom, addr, len, true);
        if (w < 0) {
            if (ring) {
                qfatal(q, SFX_QERR_RING_UNAUTH, cq_slot_addr(qs[q], qs[q].cq_tail));
                pop(); rt = RT_IDLE; return false;
            }
            return false;
        }
        use(w);
        rt_win = w;
        rt_addr = addr;
        rt_left = kTicksPerTxn;
        rt = next;
        return true;
    }
    void start_cqe(unsigned q) {
        Inf& e = head();
        Queue& Q = qs[q];
        cqe = sfx_cqe_t{};
        cqe.cmd_id = e.cmd_id;
        cqe.sq_seq = e.seq;
        cqe.status = e.status;
        cqe.opcode = e.opcode;
        cqe.sq_head = e.seq + 1;
        cqe.result = e.result;
        cqe.cq_seq = Q.cq_tail;
        cqe.phase_word = sfx_cq_phase(Q.cq_tail, Q.seq_start, Q.cq_log2());
        rt_start(q, cq_slot_addr(Q, Q.cq_tail), SFX_CQE_BYTES, RT_BODY, true);
    }
    void tick_retire() {
        switch (rt) {
        case RT_IDLE: {
            retire_blocked = false;
            if (quiesce() || tab_cnt == 0) return;
            Inf& e = head();
            if (!e.done) return;
            unsigned q = e.q;
            if (!publish_ok(q)) { pop(); progress = true; return; }
            Queue& Q = qs[q];
            if (Q.cq_tail - Q.cq_head >= cq_size(Q)) { retire_blocked = true; return; }
            if (e.sig_en) {
                if (!rt_start(q, e.sig_addr, 8, RT_SIG, false)) {
                    e.status = SFX_ST_UNAUTHORIZED;
                    record_fault(e.sig_addr, SFX_ST_UNAUTHORIZED, q);
                    start_cqe(q);
                }
                return;
            }
            start_cqe(q);
            return;
        }
        case RT_SIG: {
            if (T.host.hung()) return;
            if (--rt_left > 0) return;
            Inf& e = head();
            Resp r = T.host.write(rt_addr, &e.sig_val, 8);
            unuse(rt_win);
            rt_win = -1;
            progress = true;
            if (r != Resp::OKAY) {
                e.status = SFX_ST_DMA_WRITE_ERR;
                record_fault(rt_addr, SFX_ST_DMA_WRITE_ERR, e.q);
            }
            start_cqe(e.q);
            return;
        }
        case RT_BODY: {
            if (T.host.hung()) return;
            if (--rt_left > 0) return;
            Inf& e = head();
            Queue& Q = qs[e.q];
            Resp r = T.host.write(rt_addr, &cqe, SFX_C_PHASE);  // bytes 0x00-0x1B
            unuse(rt_win);
            rt_win = -1;
            progress = true;
            if (r != Resp::OKAY) {
                qfatal(e.q, SFX_QERR_CQ_WRITE, cq_slot_addr(Q, Q.cq_tail));
                pop();
                rt = RT_IDLE;
                return;
            }
            rt_start(e.q, rt_addr + SFX_C_PHASE, 4, RT_PHASE, true);
            (void)Q;
            return;
        }
        case RT_PHASE: {
            if (T.host.hung()) return;
            if (--rt_left > 0) return;
            Inf& e = head();
            Queue& Q = qs[e.q];
            Resp r = T.host.write(rt_addr, &cqe.phase_word, 4);
            unuse(rt_win);
            rt_win = -1;
            progress = true;
            if (r != Resp::OKAY) {
                qfatal(e.q, SFX_QERR_CQ_WRITE, cq_slot_addr(Q, Q.cq_tail));
                pop();
                rt = RT_IDLE;
                return;
            }
            // published
            ++Q.cq_tail;
            if (e.status == SFX_ST_OK) { ++Q.cmds_ok; ++cmds_ok; } else { ++Q.cmds_err; ++cmds_err; }
            ev(EvKind::Publish, e.cmd_id, e.q);
            on_publish(e.q, e.flags);
            pop();
            rt = RT_IDLE;
            return;
        }
        }
    }

    void announce(unsigned q) {
        irq_status |= 1u << (SFX_IRQ_QCPL_LSB + q);
        qs[q].coal_cnt = 0;
        qs[q].coal_timer = 0;
    }
    void on_publish(unsigned q, uint16_t flags) {
        Queue& Q = qs[q];
        uint32_t thr = Q.coal & 0xFFFF, tmr = Q.coal >> 16;
        if (flags & SFX_F_IRQ) { announce(q); return; }
        if (!thr && !tmr) return;
        ++Q.coal_cnt;
        if (thr && Q.coal_cnt >= thr) { announce(q); return; }
        if (tmr && Q.coal_timer == 0) Q.coal_timer = static_cast<uint64_t>(tmr) * SFX_TIMER_UNIT;
    }

    // -- queue state / timers
    void tick_queues() {
        for (unsigned q = 0; q < nq; ++q) {
            Queue& Q = qs[q];
            if (Q.state == SFX_QS_DRAINING && !qbusy(q)) {
                Q.state = SFX_QS_DISABLED;
                Q.dropping = false;
            }
            if (Q.coal_timer > 0 && --Q.coal_timer == 0 && Q.coal_cnt > 0) announce(q);
        }
    }

    // -- watchdog
    void tick_wdt() {
        bool rt_busy = rt != RT_IDLE;
        bool armed = wdt_en && wdt_timeout > 0 && !fault && !resetting &&
                     ((ctrl_enable && startable_work()) || fe != FE_IDLE || tab_cnt > 0 || rt_busy) &&
                     !retire_blocked;
        wdt_armed = armed;
        if (!armed || progress) {
            wdt_count = 0;
        } else if (++wdt_count >= wdt_timeout) {
            uint32_t stuck = 0;
            if (fe != FE_IDLE) stuck |= SFX_WDT_STUCK_FRONTEND;
            if (dma.busy) stuck |= SFX_WDT_STUCK_DMA;
            if (any_kernel_running()) stuck |= SFX_WDT_STUCK_KERNEL;
            if (rt_busy || tab_cnt > 0) stuck |= SFX_WDT_STUCK_RETIRE;
            wdt_stuck = stuck;
            wdt_expired = 1;
            ++wdt_expiries;
            irq_status |= SFX_IRQ_WDT;
            fault_cause |= SFX_FAULT_WDT;
            fault = true;
            wdt_count = 0;
            wdt_armed = false;
        }
        progress = false;
    }

    // -- controlled reset
    bool drained() const {
        if (dma.busy) return false;
        if (fe == FE_FETCH) return false;
        if (rt != RT_IDLE) return false;
        if (any_kernel_running()) return false;
        return true;
    }
    void tick_reset() {
        if (!resetting) return;
        if (drained()) {
            // snapshot
            for (unsigned q = 0; q < nq; ++q) {
                qs[q].rst_sq_tail = qs[q].sq_tail;
                qs[q].rst_sq_head = qs[q].sq_head;
                qs[q].rst_cq_tail = qs[q].cq_tail;
            }
            uint32_t cnt = rst_count + 1;
            bool keep_ie = true;
            (void)keep_ie;
            reset_state(false);
            rst_count = cnt;
            rst_done = true;
            rst_drain_to = false;
            resetting = false;
            irq_status |= SFX_IRQ_RESET_DONE;
            return;
        }
        if (rst_timeout != 0 && ++rst_wait >= rst_timeout) rst_drain_to = true;  // stays quiesced in RESETTING
    }

    // ---------------------------------------------------------------- interrupts -----------
    void update_irq() {
        std::fill(level.begin(), level.end(), false);
        if (blank == 0) {
            uint32_t en = irq_status & irq_enable;
            for (unsigned q = 0; q < nq; ++q)
                if (en & (1u << (SFX_IRQ_QCPL_LSB + q))) level[qs[q].vector] = true;
            uint32_t qm = (1u << nq) - 1;
            if (en & ~qm) level[irq_misc_vec] = true;
        }
        for (unsigned v = 0; v < nv; ++v) {
            if (level[v] && !level_prev[v] && T.on_irq_rise) T.on_irq_rise(v);
            level_prev[v] = level[v];
        }
    }

    // ---------------------------------------------------------------- registers ------------
    uint32_t status_reg() const {
        uint32_t s = 0;
        if (!resetting) s |= SFX_STATUS_READY;
        if (ctrl_enable && !fault && !resetting) s |= SFX_STATUS_RUNNING;
        if (fault) s |= SFX_STATUS_FAULT;
        if (resetting) s |= SFX_STATUS_RESETTING;
        if (!unfetched_work() && fe == FE_IDLE && tab_cnt == 0 && rt == RT_IDLE) s |= SFX_STATUS_IDLE;
        if (abi_ok()) s |= SFX_STATUS_ABI_OK;
        return s;
    }
    static uint32_t log2u(uint32_t v) { uint32_t r = 0; while ((1u << r) < v) ++r; return r; }

    uint32_t reg_read(uint32_t off) {
        if (off >= SFX_DB_BASE) {
            unsigned q = (off - SFX_DB_BASE) / SFX_DB_STRIDE;
            uint32_t o = (off - SFX_DB_BASE) % SFX_DB_STRIDE;
            if (q < nq) {
                if (o == SFX_R_DB_SQ_TAIL) return qs[q].sq_tail;
                if (o == SFX_R_DB_CQ_HEAD) return qs[q].cq_head;
            }
            return 0;
        }
        if (off < SFX_WIN_BASE) return global_read(off);
        if (off < SFX_WIN_BASE + SFX_MAX_WINDOWS * SFX_WIN_STRIDE) {
            unsigned w = (off - SFX_WIN_BASE) / SFX_WIN_STRIDE;
            uint32_t o = (off - SFX_WIN_BASE) % SFX_WIN_STRIDE;
            if (w >= nw) return 0;
            const Window& W = win[w];
            switch (o) {
            case SFX_R_W_BASE_LO: return lo32(W.base);
            case SFX_R_W_BASE_HI: return hi32(W.base);
            case SFX_R_W_SIZE_LO: return lo32(W.size);
            case SFX_R_W_SIZE_HI: return hi32(W.size);
            case SFX_R_W_CTRL:
                return (W.valid ? SFX_WIN_VALID : 0) | (W.space_dev ? SFX_WIN_SPACE : 0) | (W.r ? SFX_WIN_R : 0) |
                       (W.w ? SFX_WIN_W : 0) | (static_cast<uint32_t>(W.dom) << SFX_WIN_DOM_LSB) |
                       (W.use > 0 ? SFX_WIN_BUSY : 0) | (W.err ? SFX_WIN_ERR : 0);
            default: return 0;
            }
        }
        if (off >= SFX_Q_BASE && off < SFX_Q_BASE + SFX_MAX_QUEUES * SFX_Q_STRIDE) {
            unsigned q = (off - SFX_Q_BASE) / SFX_Q_STRIDE;
            uint32_t o = (off - SFX_Q_BASE) % SFX_Q_STRIDE;
            if (q >= nq) return 0;
            const Queue& Q = qs[q];
            switch (o) {
            case SFX_R_Q_CTRL: return (Q.state == SFX_QS_ENABLED ? SFX_QCTL_ENABLE : 0) | (static_cast<uint32_t>(Q.dom) << SFX_QCTL_DOM_LSB);
            case SFX_R_Q_STATUS: return Q.state | (static_cast<uint32_t>(Q.err_code) << SFX_QSTAT_ERR_LSB);
            case SFX_R_Q_SQ_BASE_LO: return lo32(Q.sq_base);
            case SFX_R_Q_SQ_BASE_HI: return hi32(Q.sq_base);
            case SFX_R_Q_CQ_BASE_LO: return lo32(Q.cq_base);
            case SFX_R_Q_CQ_BASE_HI: return hi32(Q.cq_base);
            case SFX_R_Q_SIZE: return Q.size_reg;
            case SFX_R_Q_VECTOR: return Q.vector;
            case SFX_R_Q_SEQ_START: return Q.seq_start;
            case SFX_R_Q_IRQ_COAL: return Q.coal;
            case SFX_R_Q_SQ_HEAD: return Q.sq_head;
            case SFX_R_Q_SQ_TAIL: return Q.sq_tail;
            case SFX_R_Q_CQ_HEAD: return Q.cq_head;
            case SFX_R_Q_CQ_TAIL: return Q.cq_tail;
            case SFX_R_Q_CMDS_OK: return Q.cmds_ok;
            case SFX_R_Q_CMDS_ERR: return Q.cmds_err;
            case SFX_R_Q_RST_SQ_TAIL: return Q.rst_sq_tail;
            case SFX_R_Q_RST_SQ_HEAD: return Q.rst_sq_head;
            case SFX_R_Q_RST_CQ_TAIL: return Q.rst_cq_tail;
            default: return 0;
            }
        }
        return 0;
    }

    uint32_t global_read(uint32_t off) {
        switch (off) {
        case SFX_R_ID: return SFX_ID_VALUE;
        case SFX_R_VERSION: return (SFX_ABI_MAJOR << 24) | (SFX_ABI_MINOR << 16) | SFX_ABI_PATCH;
        case SFX_R_CAPS: return 0x7FF;
        case SFX_R_GEOMETRY: return nq | (nw << 8) | (nv << 16) | (depth << 24);
        case SFX_R_LIMITS:
            return SFX_MAX_RING_LOG2 | (log2u(g.dma_align) << 8) | (SFX_DESC_LOG2 << 16) | (SFX_CQE_LOG2 << 24);
        case SFX_R_MAX_COPY: return SFX_MAX_COPY_BYTES;
        case SFX_R_DEVMEM_LO: return lo32(g.dev_mem_size);
        case SFX_R_DEVMEM_HI: return hi32(g.dev_mem_size);
        case SFX_R_HOST_ADDR_BITS: return g.host_addr_bits;
        case SFX_R_DESC_VERSIONS: return 1u << SFX_DESC_VERSION;
        case SFX_R_LIMITS2: return SFX_MAX_ARGS_BYTES | (SFX_MAX_GRID_DIM << 16);
        case SFX_R_ABI_REQ: return abi_req;
        case SFX_R_SCRATCH: return scratch;
        case SFX_R_CTRL: return ctrl_enable ? SFX_CTRL_ENABLE : 0;
        case SFX_R_STATUS: return status_reg();
        case SFX_R_FAULT_CAUSE: return fault_cause;
        case SFX_R_ERR_STATUS: return err_status;
        case SFX_R_ERR_COUNT: return err_count;
        case SFX_R_DUP_DB_COUNT: return dup_db;
        case SFX_R_FAULT_ADDR_LO: return lo32(fault_addr);
        case SFX_R_FAULT_ADDR_HI: return hi32(fault_addr);
        case SFX_R_FAULT_INFO: return fault_info;
        case SFX_R_CMDS_OK: return cmds_ok;
        case SFX_R_CMDS_ERR: return cmds_err;
        case SFX_R_IRQ_STATUS: return irq_status;
        case SFX_R_IRQ_ENABLE: return irq_enable;
        case SFX_R_IRQ_MISC_VECTOR: return irq_misc_vec;
        case SFX_R_WDT_CTRL: return wdt_en ? SFX_WDT_CTRL_ENABLE : 0;
        case SFX_R_WDT_TIMEOUT: return wdt_timeout;
        case SFX_R_WDT_STATUS:
            return (wdt_en ? SFX_WDT_ST_ENABLED : 0) | (wdt_armed ? SFX_WDT_ST_ARMED : 0) |
                   (wdt_expired ? SFX_WDT_ST_EXPIRED : 0) | wdt_stuck | (wdt_expiries << SFX_WDT_COUNT_LSB);
        case SFX_R_WDT_COUNT: return wdt_count;
        case SFX_R_RESET_STATUS:
            return (resetting ? SFX_RST_ST_BUSY : 0) | (rst_done ? SFX_RST_ST_DONE : 0) |
                   (rst_drain_to ? SFX_RST_ST_DRAIN_TIMEOUT : 0) | (rst_count << SFX_RST_COUNT_LSB);
        case SFX_R_RESET_TIMEOUT: return rst_timeout;
        default: return 0;
        }
    }

    void bad_access() { set_err(SFX_ERR_BAD_REG_ACCESS); }

    void reg_write(uint32_t off, uint32_t v) {
        if (resetting) return;  // register and doorbell write paths are closed during reset
        if (off >= SFX_DB_BASE) { quiet_err = true; doorbell_write(off, v); quiet_err = false; return; }
        if (off < SFX_WIN_BASE) { global_write(off, v); return; }
        if (off < SFX_WIN_BASE + SFX_MAX_WINDOWS * SFX_WIN_STRIDE) {
            unsigned w = (off - SFX_WIN_BASE) / SFX_WIN_STRIDE;
            if (w >= nw) { bad_access(); return; }
            window_write(w, (off - SFX_WIN_BASE) % SFX_WIN_STRIDE, v);
            return;
        }
        if (off >= SFX_Q_BASE && off < SFX_Q_BASE + SFX_MAX_QUEUES * SFX_Q_STRIDE) {
            unsigned q = (off - SFX_Q_BASE) / SFX_Q_STRIDE;
            if (q >= nq) { bad_access(); return; }
            queue_write(q, (off - SFX_Q_BASE) % SFX_Q_STRIDE, v);
            return;
        }
        bad_access();
    }

    void global_write(uint32_t off, uint32_t v) {
        switch (off) {
        case SFX_R_ABI_REQ: abi_req = v; break;
        case SFX_R_SCRATCH: scratch = v; break;
        case SFX_R_CTRL: ctrl_enable = v & SFX_CTRL_ENABLE; break;
        case SFX_R_ERR_STATUS: err_status &= ~v; break;
        case SFX_R_IRQ_STATUS:
            irq_status &= ~v;
            blank = 2;
            break;
        case SFX_R_IRQ_ENABLE: irq_enable = v & SFX_IRQ_VALID_MASK; break;
        case SFX_R_IRQ_MISC_VECTOR:
            if (v >= nv) set_err(SFX_ERR_BAD_IRQ_CONFIG);
            else irq_misc_vec = v;
            break;
        case SFX_R_IRQ_FORCE: irq_status |= v & SFX_IRQ_VALID_MASK; break;
        case SFX_R_WDT_CTRL:
            if ((v & SFX_WDT_CTRL_ENABLE) && wdt_timeout == 0) bad_access();
            else wdt_en = v & SFX_WDT_CTRL_ENABLE;
            break;
        case SFX_R_WDT_TIMEOUT: wdt_timeout = v; break;
        case SFX_R_WDT_STATUS: if (v & SFX_WDT_ST_EXPIRED) wdt_expired = 0; break;
        case SFX_R_RESET_CTRL:
            if ((v >> SFX_RST_KEY_LSB) != SFX_RESET_KEY) { bad_access(); break; }
            if (v & SFX_RST_REQ) {
                resetting = true;
                rst_wait = 0;
                rst_done = false;
                rst_drain_to = false;
            }
            break;
        case SFX_R_RESET_TIMEOUT: rst_timeout = v; break;
        default: bad_access(); break;  // read-only or unmapped
        }
    }

    void window_write(unsigned w, uint32_t o, uint32_t v) {
        Window& W = win[w];
        switch (o) {
        case SFX_R_W_BASE_LO: case SFX_R_W_BASE_HI: case SFX_R_W_SIZE_LO: case SFX_R_W_SIZE_HI: {
            if (W.valid) { set_err(SFX_ERR_CFG_LOCKED); return; }
            uint64_t& f = (o == SFX_R_W_BASE_LO || o == SFX_R_W_BASE_HI) ? W.base : W.size;
            if (o == SFX_R_W_BASE_LO || o == SFX_R_W_SIZE_LO) f = (f & ~0xFFFFFFFFull) | v;
            else f = (f & 0xFFFFFFFFull) | (static_cast<uint64_t>(v) << 32);
            return;
        }
        case SFX_R_W_CTRL: {
            bool want_valid = v & SFX_WIN_VALID;
            if (!want_valid) {
                W.err = false;
                W.valid = false;  // immediate for new authorisations; BUSY tracks in-flight use
                W.space_dev = v & SFX_WIN_SPACE; W.r = v & SFX_WIN_R; W.w = v & SFX_WIN_W;
                W.dom = (v & SFX_WIN_DOM_MASK) >> SFX_WIN_DOM_LSB;
                return;
            }
            if (W.valid) { W.err = true; set_err(SFX_ERR_CFG_LOCKED); return; }
            bool sp = v & SFX_WIN_SPACE, r = v & SFX_WIN_R, wr = v & SFX_WIN_W;
            uint64_t lim = sp ? g.dev_mem_size : (1ull << g.host_addr_bits);
            bool ok = W.size != 0 && W.base % g.dma_align == 0 && W.size % g.dma_align == 0 &&
                      W.size <= lim && W.base <= lim - W.size && (r || wr);
            W.space_dev = sp; W.r = r; W.w = wr;
            W.dom = (v & SFX_WIN_DOM_MASK) >> SFX_WIN_DOM_LSB;
            if (!ok) { W.err = true; set_err(SFX_ERR_BAD_WINDOW); return; }
            W.err = false;
            W.valid = true;
            return;
        }
        default: bad_access(); return;
        }
    }

    bool q_locked(unsigned q) { if (qs[q].state != SFX_QS_DISABLED) { set_err(SFX_ERR_CFG_LOCKED); return true; } return false; }

    void queue_write(unsigned q, uint32_t o, uint32_t v) {
        Queue& Q = qs[q];
        switch (o) {
        case SFX_R_Q_CTRL: {
            uint8_t dom = (v & SFX_QCTL_DOM_MASK) >> SFX_QCTL_DOM_LSB;
            if (Q.state == SFX_QS_DISABLED) Q.dom = dom;
            else if (dom != Q.dom) set_err(SFX_ERR_CFG_LOCKED);
            if (v & SFX_QCTL_ENABLE) {
                if (Q.state != SFX_QS_DISABLED) { set_err(SFX_ERR_CFG_LOCKED); return; }
                enable_queue(q);
            } else if (Q.state == SFX_QS_ENABLED || Q.state == SFX_QS_ERROR) {
                Q.state = SFX_QS_DRAINING;
            }
            return;
        }
        case SFX_R_Q_SQ_BASE_LO: if (!q_locked(q)) Q.sq_base = (Q.sq_base & ~0xFFFFFFFFull) | v; return;
        case SFX_R_Q_SQ_BASE_HI: if (!q_locked(q)) Q.sq_base = (Q.sq_base & 0xFFFFFFFFull) | (static_cast<uint64_t>(v) << 32); return;
        case SFX_R_Q_CQ_BASE_LO: if (!q_locked(q)) Q.cq_base = (Q.cq_base & ~0xFFFFFFFFull) | v; return;
        case SFX_R_Q_CQ_BASE_HI: if (!q_locked(q)) Q.cq_base = (Q.cq_base & 0xFFFFFFFFull) | (static_cast<uint64_t>(v) << 32); return;
        case SFX_R_Q_SIZE: if (!q_locked(q)) Q.size_reg = v & (SFX_QSIZE_SQ_MASK | SFX_QSIZE_CQ_MASK); return;
        case SFX_R_Q_VECTOR:
            if (q_locked(q)) return;
            if (v >= nv) set_err(SFX_ERR_BAD_IRQ_CONFIG);
            else Q.vector = v;
            return;
        case SFX_R_Q_SEQ_START: if (!q_locked(q)) Q.seq_start = v; return;
        case SFX_R_Q_IRQ_COAL: Q.coal = v; Q.coal_cnt = 0; Q.coal_timer = 0; return;
        default: bad_access(); return;
        }
    }

    void enable_queue(unsigned q) {
        Queue& Q = qs[q];
        Q.err_code = 0;
        Q.dropping = false;
        const uint32_t sl = Q.sq_log2(), cl = Q.cq_log2();
        bool ok = abi_ok() && sl >= SFX_MIN_RING_LOG2 && sl <= SFX_MAX_RING_LOG2 && cl >= SFX_MIN_RING_LOG2 &&
                  cl <= SFX_MAX_RING_LOG2 && Q.sq_base % 64 == 0 && Q.cq_base % 64 == 0;
        if (ok) {
            uint64_t sq_bytes = 64ull << sl, cq_bytes = 32ull << cl;
            ok = range_ok(false, Q.sq_base, sq_bytes) && range_ok(false, Q.cq_base, cq_bytes);
            uint32_t big = std::max(1u << sl, 1u << cl);
            ok = ok && Q.seq_start % big == 0;
            ok = ok && authz(false, Q.dom, Q.sq_base, sq_bytes, false) >= 0 &&
                 authz(false, Q.dom, Q.cq_base, cq_bytes, true) >= 0;
        }
        if (!ok) {
            Q.state = SFX_QS_ERROR;
            Q.err_code = SFX_QERR_BAD_CONFIG;
            Q.dropping = true;
            set_err(SFX_ERR_BAD_QCONFIG);
            irq_status |= 1u << (SFX_IRQ_QERR_LSB + q);
            return;
        }
        Q.sq_head = Q.sq_tail = Q.cq_head = Q.cq_tail = Q.seq_start;
        Q.cmds_ok = Q.cmds_err = 0;
        Q.coal_cnt = 0;
        Q.coal_timer = 0;
        Q.state = SFX_QS_ENABLED;
    }

    void doorbell_write(uint32_t off, uint32_t v) {
        unsigned q = (off - SFX_DB_BASE) / SFX_DB_STRIDE;
        uint32_t o = (off - SFX_DB_BASE) % SFX_DB_STRIDE;
        if (q >= nq || (o != SFX_R_DB_SQ_TAIL && o != SFX_R_DB_CQ_HEAD)) { bad_access(); return; }
        Queue& Q = qs[q];
        if (Q.state != SFX_QS_ENABLED) { set_err(SFX_ERR_BAD_DOORBELL); return; }
        if (o == SFX_R_DB_SQ_TAIL) {
            if (v == Q.sq_tail) { ++dup_db; return; }
            uint32_t d = v - Q.sq_head, old = Q.sq_tail - Q.sq_head;
            if (d > old && d <= sq_size(Q)) Q.sq_tail = v;
            else set_err(SFX_ERR_BAD_DOORBELL);
        } else {
            if (v == Q.cq_head) { ++dup_db; return; }
            uint32_t d = v - Q.cq_head, p = Q.cq_tail - Q.cq_head;
            if (d > 0 && d <= p) Q.cq_head = v;
            else set_err(SFX_ERR_BAD_DOORBELL);
        }
    }
};

// ---------------------------------------------------------------------------------------------
ModelTarget::ModelTarget(const Geometry& g)
    : Target(kHostBase, kHostSize, g.dev_mem_size), geom_(g), p_(new Impl(*this, g)) {
    geom_ = p_->g;
}
ModelTarget::~ModelTarget() = default;

uint32_t ModelTarget::rd32(uint32_t off) {
    uint32_t v = p_->reg_read(off);
    if (!p_->in_tick) p_->tick();
    return v;
}
void ModelTarget::wr32(uint32_t off, uint32_t v) {
    p_->reg_write(off, v);
    p_->update_irq();
    if (!p_->in_tick) p_->tick();
}
void ModelTarget::run(uint64_t n) {
    for (uint64_t i = 0; i < n; ++i) p_->tick();
}
void ModelTarget::hard_reset() {
    host.set_hang(false);  // models a link/function-level reset: wedged buses are released
    dev.set_hang(false);
    p_->reset_state(true);
    std::fill(p_->level_prev.begin(), p_->level_prev.end(), false);
    p_->update_irq();
}
bool ModelTarget::irq_level(unsigned vec) const { return vec < p_->level.size() && p_->level[vec]; }

std::unique_ptr<Target> make_model_target(const Geometry& g) { return std::make_unique<ModelTarget>(g); }

}  // namespace sfx
