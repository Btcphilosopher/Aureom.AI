// Execution ordering: overlap, fences, barriers, in-order retire, in-flight depth, kernel dispatch.
// Only PARTIAL ORDERS between events are asserted, never times.
#include <map>

#include "test_util.hpp"

using namespace sfxt;

namespace {
int ev(const Target& t, EvKind k, uint32_t id) { return find_event(t, k, id); }
}  // namespace

// Independent commands may overlap; FENCE and F_FENCE_BEFORE order them (SPEC 7.3, 7.5).
TEST(ordering_overlap_vs_fence) {
    for (int mode = 0; mode < 3; ++mode) {
        auto tp = c.fresh();
        Target& t = *tp;
        Env e(t);
        const uint32_t A = e.align();
        const uint32_t len = 65536 / A * A;
        HBuf h = e.host_buf(len);
        DBuf d = e.dev_buf(len), k = e.dev_buf(64);
        fill_pattern(h.p, len, 3);
        std::vector<sfx_desc_t> cmds{cmd::copy_h2d(1, h.iova, d.addr, len)};
        if (mode == 1) cmds.push_back(cmd::fence(2));
        cmds.push_back(cmd::kernel(3, k.addr, DevAddr(0), 0, 1, 1, 1, mode == 2 ? SFX_F_FENCE_BEFORE : 0));
        auto r = e.exec(0, cmds);
        for (auto& q : r) CHECK_ST(q, SFX_ST_OK);
        int i_kernel = ev(t, EvKind::Issue, 3), p_copy = ev(t, EvKind::Publish, 1);
        CHECK(i_kernel >= 0 && p_copy >= 0);
        if (mode == 0) {
            // overlap needs a second in-flight slot; with INFLIGHT_DEPTH=1 commands are serial
            if (t.geometry().inflight_depth >= 2)
                CHECK_MSG(i_kernel < p_copy, "without a fence the kernel is issued while the copy is still running");
        } else {
            CHECK_MSG(p_copy < i_kernel, "fence / FENCE_BEFORE: kernel issues only after the copy retired");
            if (mode == 1) CHECK(p_copy < ev(t, EvKind::Publish, 2));
        }
        CHECK(std::memcmp(h.p, d.p, len) == 0);
    }
}

TEST(ordering_barrier_blocks_later_commands) {
    Target& t = c.t;
    Env e(t);
    DBuf k = e.dev_buf(64);
    t.kernel_hook = [](const KernelReq& r) { KernelResult x; x.latency = r.cmd_id == 1 ? 3000 : 1; return x; };
    auto r = e.exec(0, {cmd::kernel(1, k.addr, DevAddr(0), 0), cmd::fence(2), cmd::nop(3), cmd::nop(4)});
    for (auto& q : r) CHECK_ST(q, SFX_ST_OK);
    const int p1 = ev(t, EvKind::Publish, 1), p2 = ev(t, EvKind::Publish, 2);
    CHECK(p1 < p2);
    if (t.geometry().inflight_depth >= 2)
        CHECK_MSG(ev(t, EvKind::Issue, 2) < p1, "the fence itself issues immediately and waits at retire");
    CHECK_MSG(ev(t, EvKind::Issue, 3) > p2, "commands behind a fence start only after it retired");
    CHECK_MSG(ev(t, EvKind::Issue, 4) > p2, "commands behind a fence start only after it retired");
}

TEST(ordering_inorder_retire_despite_reordering) {
    Target& t = c.t;
    Env e(t);
    const uint32_t A = e.align();
    const uint32_t len = 32768 / A * A;
    HBuf h = e.host_buf(len);
    DBuf d = e.dev_buf(len), k = e.dev_buf(64);
    fill_pattern(h.p, len, 6);
    // slow kernel first, fast things behind it; then a slow copy with a fast kernel behind it
    t.kernel_hook = [](const KernelReq& r) { KernelResult x; x.latency = r.cmd_id == 1 ? 2500 : 1; return x; };
    auto r = e.exec(0, {cmd::kernel(1, k.addr, DevAddr(0), 0), cmd::nop(2), cmd::nop(3),
                        cmd::copy_h2d(4, h.iova, d.addr, len), cmd::kernel(5, k.addr, DevAddr(0), 0)});
    CHECK_EQ(r.size(), 5u);
    for (uint32_t i = 0; i < 5; ++i) { CHECK_EQ(r[i].cmd_id, i + 1); CHECK_ST(r[i], SFX_ST_OK); }
    // publication order on the bus equals issue order
    std::vector<uint32_t> pubs;
    for (const Event& x : t.events) if (x.kind == EvKind::Publish) pubs.push_back(x.cmd_id);
    CHECK_EQ(pubs.size(), 5u);
    for (uint32_t i = 0; i < 5; ++i) CHECK_EQ(pubs[i], i + 1);
    // the later, faster commands really did overlap the slow kernel
    if (t.geometry().inflight_depth >= 3) {
        CHECK(ev(t, EvKind::Issue, 2) < ev(t, EvKind::Publish, 1));
        CHECK(ev(t, EvKind::Issue, 3) < ev(t, EvKind::Publish, 1));
    }
    // copy slower than the kernel behind it: still published first
    CHECK(ev(t, EvKind::Publish, 4) < ev(t, EvKind::Publish, 5));
    if (t.geometry().inflight_depth >= 2) CHECK(ev(t, EvKind::Issue, 5) < ev(t, EvKind::Publish, 4));
}

TEST(ordering_inflight_depth_respected) {
    Target& t = c.t;
    Env e(t);
    DBuf k = e.dev_buf(64);
    t.kernel_hook = [](const KernelReq&) { KernelResult x; x.latency = 400; return x; };
    std::vector<sfx_desc_t> cmds;
    for (uint32_t i = 0; i < 14; ++i) cmds.push_back(cmd::kernel(10 + i, k.addr, DevAddr(0), 0));
    auto r = e.exec(0, cmds);
    CHECK_EQ(r.size(), 14u);
    int cur = 0, peak = 0;
    for (const Event& x : t.events) {
        if (x.kind == EvKind::Issue) ++cur;
        if (x.kind == EvKind::Publish) --cur;
        peak = std::max(peak, cur);
        CHECK_LE(cur, int(t.geometry().inflight_depth));
    }
    if (t.geometry().inflight_depth > 1) CHECK_GE(peak, 2);  // and they do overlap
    CHECK_EQ(cur, 0);
}

// FENCE with signal: the value appears only after every earlier command completed and its
// completion was published; its own completion follows the signal.
TEST(fence_signal_semantics) {
    Target& t = c.t;
    Env e(t);
    const uint32_t A = e.align();
    const uint32_t len = 8192 / A * A;
    HBuf h = e.host_buf(len), sig = e.host_buf(256);
    DBuf d = e.dev_buf(len), k = e.dev_buf(64);
    fill_pattern(h.p, len, 8);
    std::memset(sig.p, 0xA5, 256);
    std::memset(sig.p + 64, 0, 8);   // the signal slot (8 bytes at +64)
    const Iova slot(sig.iova.v + 64);
    t.kernel_hook = [](const KernelReq&) { KernelResult x; x.latency = 300; return x; };
    struct Snap { bool seen = false; uint32_t visible = 0; bool data_done = false; uint64_t value = 0; };
    std::vector<Snap> snaps;
    CqeWatch w(e, 0, nullptr);
    w.extra = [&](uint64_t a, uint64_t l) {
        if (!(a <= slot.v && slot.v < a + l)) return;
        Snap s;
        s.seen = true;
        s.visible = w.seen();
        s.data_done = std::memcmp(h.p, d.p, len) == 0;
        std::memcpy(&s.value, sig.p + 64, 8);
        snaps.push_back(s);
    };
    auto r = e.exec(0, {cmd::copy_h2d(1, h.iova, d.addr, len), cmd::kernel(2, k.addr, DevAddr(0), 0),
                        cmd::fence_signal(3, slot, 0x1111111111111111ull), cmd::nop(4),
                        cmd::fence_signal(5, slot, 0x2222222222222222ull, SFX_F_IRQ)});
    CHECK_EQ(r.size(), 5u);
    for (auto& q : r) CHECK_ST(q, SFX_ST_OK);
    CHECK_EQ(snaps.size(), 2u);
    // first signal: copy and kernel both completed AND published before it
    CHECK_GE(snaps[0].visible, 2u);
    CHECK(snaps[0].data_done);
    CHECK_EQ(snaps[0].value, 0x1111111111111111ull);
    // second signal: everything up to and including the first FENCE and the NOP is visible
    CHECK_GE(snaps[1].visible, 4u);
    CHECK_EQ(snaps[1].value, 0x2222222222222222ull);
    // and the FENCE completion itself comes after its signal (it was not visible yet at signal time)
    CHECK_LE(snaps[0].visible, 3u);
    CHECK_LE(snaps[1].visible, 4u);
    for (int i = 0; i < 64; ++i) CHECK_EQ(sig.p[i], 0xA5);          // only the 8-byte slot was written
    for (int i = 72; i < 256; ++i) CHECK_EQ(sig.p[i], 0xA5);
}

TEST(fence_signal_bus_error) {
    {   // bus error on the signal write: the FENCE completes with ST_DMA_WRITE_ERR, the queue lives
        auto tp = c.fresh();
        Target& t = *tp;
        Env e(t);
        HBuf sig = e.host_buf(64);
        FaultRule f; f.lo = sig.iova.v; f.hi = sig.iova.v + 8; f.on_read = false; f.on_write = true;
        t.host.add_fault(f);
        auto q = e.exec1(0, cmd::fence_signal(1, sig.iova, 0x77));
        CHECK_ST(q, SFX_ST_DMA_WRITE_ERR);
        uint64_t v; std::memcpy(&v, sig.p, 8);
        CHECK_EQ(v, 0u);
        CHECK_EQ(e.rd(SFX_R_FAULT_INFO) & 0xFFFF, uint32_t(SFX_ST_DMA_WRITE_ERR));
        uint64_t fa = e.rd(SFX_R_FAULT_ADDR_LO) | (uint64_t(e.rd(SFX_R_FAULT_ADDR_HI)) << 32);
        CHECK(fa >= sig.iova.v && fa < sig.iova.v + 8);
        CHECK_EQ(e.dev.queue_state(0), uint32_t(SFX_QS_ENABLED));
        t.host.clear_faults();
        CHECK_ST(e.exec1(0, cmd::fence_signal(2, sig.iova, 0x88)), SFX_ST_OK);
        std::memcpy(&v, sig.p, 8);
        CHECK_EQ(v, 0x88u);
    }
}

// Signal window revoked after the FENCE was decoded: re-checked at write time.
TEST(fence_signal_revoked_before_write) {
    if (c.t.geometry().inflight_depth < 2) SKIP("needs the FENCE issued while the kernel still runs (depth >= 2)");
    if (c.t.geometry().num_windows < 5) SKIP("needs 5 windows: rings (2) + data arena (2) + the signal window");
    {
        auto tp = c.fresh();
        Target& t = *tp;
        Env e(t);
        DmaBuffer sb = e.alloc.alloc_coherent(4096, 4096);
        int sw = e.dev.map_host(sb.iova, 4096, PermW, 1);
        CHECK(sw >= 0);
        DBuf k = e.dev_buf(64);
        t.kernel_hook = [](const KernelReq&) { KernelResult x; x.latency = 3000; return x; };
        e.q().submit(cmd::kernel(1, k.addr, DevAddr(0), 0));
        e.q().submit(cmd::fence_signal(2, sb.iova, 0x99));
        e.q().submit(cmd::nop(3));
        e.q().ring();
        WAIT(t, ev(t, EvKind::Issue, 2) >= 0);             // fence decoded and waiting behind the kernel
        t.wr32(SFX_WIN_REG(sw, SFX_R_W_CTRL), 0);          // revoke
        auto r = e.collect(0, 3);
        CHECK_ST(r[0], SFX_ST_OK);
        CHECK_ST(r[1], SFX_ST_UNAUTHORIZED);
        CHECK_ST(r[2], SFX_ST_OK);
        uint64_t v; std::memcpy(&v, sb.cpu, 8);
        CHECK_EQ(v, 0u);                                   // the write never happened
        CHECK_EQ(e.rd(SFX_R_FAULT_INFO) & 0xFFFF, uint32_t(SFX_ST_UNAUTHORIZED));
        CHECK_EQ(e.dev.queue_state(0), uint32_t(SFX_QS_ENABLED));
    }
}

TEST(kernel_dispatch_plumbing) {
    Target& t = c.t;
    Env e(t);
    DBuf entry = e.dev_buf(4096), args = e.dev_buf(4096);
    t.kernel_hook = [](const KernelReq& r) {
        KernelResult x;
        x.latency = 1 + (r.cmd_id % 5) * 30;
        if (r.cmd_id == 3) { x.status = SFX_KD_FAULT; x.info = 0xBEEF; }
        else x.info = 0x1000 + r.cmd_id;
        return x;
    };
    auto r = e.exec(0, {cmd::kernel(1, entry.addr, args.addr, 64, 3, 4, 5),
                        cmd::kernel(2, DevAddr(entry.addr.v + 64), DevAddr(0), 0, 65535, 1, 7, SFX_F_IRQ),
                        cmd::kernel(3, entry.addr, DevAddr(args.addr.v + 8), 4096 - 8),
                        cmd::kernel(4, entry.addr, args.addr, 8)});
    CHECK_EQ(r.size(), 4u);
    CHECK_ST(r[0], SFX_ST_OK);      CHECK_EQ(r[0].result, 0x1001u);
    CHECK_ST(r[1], SFX_ST_OK);      CHECK_EQ(r[1].result, 0x1002u);
    CHECK_ST(r[2], SFX_ST_KERNEL_FAULT); CHECK_EQ(r[2].result, 0xBEEFu);
    CHECK_ST(r[3], SFX_ST_OK);      CHECK_EQ(r[3].result, 0x1004u);
    for (int i = 0; i < 4; ++i) CHECK_EQ(r[i].opcode, uint16_t(SFX_OP_KERNEL));
    CHECK_EQ(t.kernels_launched.size(), 4u);
    const KernelReq& k0 = t.kernels_launched[0];
    CHECK_EQ(k0.cmd_id, 1u);
    CHECK_EQ(k0.kernel_addr, entry.addr.v); CHECK_EQ(k0.args_addr, args.addr.v); CHECK_EQ(k0.args_size, 64u);
    CHECK_EQ(k0.grid[0], 3u); CHECK_EQ(k0.grid[1], 4u); CHECK_EQ(k0.grid[2], 5u);
    CHECK_EQ(k0.domain, 1u);
    const KernelReq& k1 = t.kernels_launched[1];
    CHECK_EQ(k1.kernel_addr, entry.addr.v + 64); CHECK_EQ(k1.args_size, 0u); CHECK_EQ(k1.args_addr, 0u);
    CHECK_EQ(k1.grid[0], 65535u); CHECK_EQ(k1.grid[2], 7u);
    CHECK_EQ(t.kernels_launched[2].args_size, 4096u - 8);
    WAIT_REG(t, SFX_R_CMDS_ERR, 1u);
    WAIT_REG(t, SFX_R_CMDS_OK, 3u);
    // a kernel fault is a command failure, not a device or queue failure
    CHECK_EQ(e.err_status(), 0u);
    CHECK_EQ(e.dev.queue_state(0), uint32_t(SFX_QS_ENABLED));
}

TEST(kernel_domain_and_two_queues) {
    Target& t = c.t;
    if (t.geometry().num_queues < 2) SKIP("needs 2 queues");
    if (t.geometry().num_windows < 8) SKIP("needs 8 windows");
    EnvOpts o; o.queues = 2; o.domains = {1, 2};
    Env e(t, o);
    DBuf k1 = e.dev_buf(64, 1), k2 = e.dev_buf(64, 2);
    // interleave submissions on both queues
    for (uint32_t i = 0; i < 6; ++i) {
        e.q(0).submit(cmd::kernel(100 + i, k1.addr, DevAddr(0), 0));
        e.q(1).submit(cmd::kernel(200 + i, k2.addr, DevAddr(0), 0));
    }
    e.q(0).ring(); e.q(1).ring();
    auto r0 = e.collect(0, 6), r1 = e.collect(1, 6);
    for (uint32_t i = 0; i < 6; ++i) {
        CHECK_EQ(r0[i].cmd_id, 100 + i); CHECK_ST(r0[i], SFX_ST_OK);
        CHECK_EQ(r1[i].cmd_id, 200 + i); CHECK_ST(r1[i], SFX_ST_OK);
    }
    CHECK_EQ(t.kernels_launched.size(), 12u);
    for (const KernelReq& k : t.kernels_launched) CHECK_EQ(k.domain, k.cmd_id < 200 ? 1u : 2u);
    // a queue cannot dispatch a kernel from the other domain's device memory
    CHECK_ST(e.exec1(0, cmd::kernel(1, k2.addr, DevAddr(0), 0)), SFX_ST_UNAUTHORIZED);
    CHECK_ST(e.exec1(1, cmd::kernel(2, k1.addr, DevAddr(0), 0)), SFX_ST_UNAUTHORIZED);
}

// A FENCE is global: it waits for earlier commands of *other* queues, and later commands of
// other queues wait for it.
TEST(fence_cross_queue) {
    Target& t = c.t;
    if (t.geometry().num_queues < 2) SKIP("needs 2 queues");
    if (t.geometry().num_windows < 8) SKIP("needs 8 windows");
    EnvOpts o; o.queues = 2; o.domains = {1, 2};
    Env e(t, o);
    DBuf k = e.dev_buf(64, 1);
    t.kernel_hook = [](const KernelReq& r) { KernelResult x; x.latency = r.cmd_id == 1 ? 3000 : 1; return x; };
    e.q(0).submit(cmd::kernel(1, k.addr, DevAddr(0), 0));
    e.q(0).ring();
    WAIT(t, ev(t, EvKind::Issue, 1) >= 0);
    e.q(1).submit(cmd::fence(2));
    e.q(1).ring();
    WAIT(t, ev(t, EvKind::Issue, 2) >= 0);
    e.q(0).submit(cmd::nop(3));
    e.q(0).ring();
    auto r1 = e.collect(1, 1);
    auto r0 = e.collect(0, 2);
    CHECK_ST(r1[0], SFX_ST_OK);
    CHECK_EQ(r0[0].cmd_id, 1u); CHECK_EQ(r0[1].cmd_id, 3u);
    CHECK_MSG(ev(t, EvKind::Publish, 1) < ev(t, EvKind::Publish, 2), "fence on queue 1 waited for queue 0's kernel");
    CHECK_MSG(ev(t, EvKind::Issue, 3) > ev(t, EvKind::Publish, 2), "queue 0's later command waited for the fence");
}
