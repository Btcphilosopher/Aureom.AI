// Self-checking SystemVerilog testbench for the AXI-endpoint transport wrapper.
// Run with Verilator --binary --timing (see Makefile target `test-ep`).
//
// Checks: (1) wrapper passes register access and DMA through to the core; (2) the host AXI address is
// IOVA + HOST_AXI_OFFSET (the behavioural memory only responds there and flags any other address);
// (3) an F_IRQ completion produces irq_req that stays asserted until irq_ack, and a W1C of the cause
// followed by a new completion produces a second request; (4) nothing is raised without a cause;
// (5) holding flr_active resets the core (registers return to power-on values).
// This exercises AXI-level adaptation only. It is not a PCIe test.
`timescale 1ns/1ps

module tb_axi_mem #(
  parameter int          DATA_W = 64,
  parameter int          SIZE   = 65536,
  parameter logic [63:0] BASE   = 64'h0
) (
  input  logic                clk,
  input  logic                rst_n,
  input  logic [63:0]         awaddr,
  input  logic [7:0]          awlen,
  input  logic                awvalid,
  output logic                awready,
  input  logic [DATA_W-1:0]   wdata,
  input  logic [DATA_W/8-1:0] wstrb,
  input  logic                wlast,
  input  logic                wvalid,
  output logic                wready,
  output logic [1:0]          bresp,
  output logic                bvalid,
  input  logic                bready,
  input  logic [63:0]         araddr,
  input  logic [7:0]          arlen,
  input  logic                arvalid,
  output logic                arready,
  output logic [DATA_W-1:0]   rdata,
  output logic [1:0]          rresp,
  output logic                rlast,
  output logic                rvalid,
  input  logic                rready,
  output logic                oob          // sticky: an access fell outside [BASE, BASE+SIZE)
);
  localparam int BYTES = DATA_W / 8;
  logic [7:0] mem [SIZE];
  typedef enum logic [1:0] {IDLE, DATA, RESP} st_t;
  st_t   ws, rs;
  logic [63:0] wa, ra;
  logic [7:0]  rcnt, rlen;

  assign awready = (ws == IDLE);
  assign wready  = (ws == DATA);
  assign bvalid  = (ws == RESP);
  assign bresp   = 2'b00;
  assign arready = (rs == IDLE);
  assign rvalid  = (rs == DATA);
  assign rresp   = 2'b00;
  assign rlast   = (rs == DATA) && (rcnt == rlen);

  always_comb begin
    rdata = '0;
    for (int i = 0; i < BYTES; i++)
      if ((ra - BASE + 64'(i)) < 64'(SIZE)) rdata[i*8 +: 8] = mem[int'(ra - BASE) + i];
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ws <= IDLE; rs <= IDLE; wa <= '0; ra <= '0; rcnt <= '0; rlen <= '0; oob <= 1'b0;
    end else begin
      unique case (ws)
        IDLE: if (awvalid) begin
          wa <= awaddr; ws <= DATA;
          if ((awaddr - BASE) >= 64'(SIZE)) oob <= 1'b1;
        end
        DATA: if (wvalid) begin
          for (int i = 0; i < BYTES; i++)
            if (wstrb[i] && (wa - BASE + 64'(i)) < 64'(SIZE)) mem[int'(wa - BASE) + i] <= wdata[i*8 +: 8];
          wa <= wa + 64'(BYTES);
          if (wlast) ws <= RESP;
        end
        RESP: if (bready) ws <= IDLE;
        default: ws <= IDLE;
      endcase
      unique case (rs)
        IDLE: if (arvalid) begin
          ra <= araddr; rlen <= arlen; rcnt <= '0; rs <= DATA;
          if ((araddr - BASE) >= 64'(SIZE)) oob <= 1'b1;
        end
        DATA: if (rready) begin
          ra <= ra + 64'(BYTES); rcnt <= rcnt + 8'd1;
          if (rcnt == rlen) rs <= IDLE;
        end
        default: rs <= IDLE;
      endcase
    end
  end
endmodule

module tb_transport_axi_ep;
  localparam logic [63:0] HOFF = 64'h0000_0010_0000_0000;
  initial clk = 1'b0;
  always #5 clk = ~clk;

  logic aresetn = 1'b0, link_up = 1'b0, flr_active = 1'b0;
  logic [1:0] irq_req, irq_ack;
  logic                clk;
  logic [15:0]         s_axil_awaddr;
  logic                s_axil_awvalid;
  logic                s_axil_awready;
  logic [31:0]         s_axil_wdata;
  logic [3:0]          s_axil_wstrb;
  logic                s_axil_wvalid;
  logic                s_axil_wready;
  logic [1:0]          s_axil_bresp;
  logic                s_axil_bvalid;
  logic                s_axil_bready;
  logic [15:0]         s_axil_araddr;
  logic                s_axil_arvalid;
  logic                s_axil_arready;
  logic [31:0]         s_axil_rdata;
  logic [1:0]          s_axil_rresp;
  logic                s_axil_rvalid;
  logic                s_axil_rready;
  logic [3:0]          m_host_awid;
  logic [63:0]         m_host_awaddr;
  logic [7:0]          m_host_awlen;
  logic [2:0]          m_host_awsize;
  logic [1:0]          m_host_awburst;
  logic                m_host_awvalid;
  logic                m_host_awready;
  logic [64-1:0]       m_host_wdata;
  logic [64/8-1:0]     m_host_wstrb;
  logic                m_host_wlast;
  logic                m_host_wvalid;
  logic                m_host_wready;
  logic [3:0]          m_host_bid;
  logic [1:0]          m_host_bresp;
  logic                m_host_bvalid;
  logic                m_host_bready;
  logic [3:0]          m_host_arid;
  logic [63:0]         m_host_araddr;
  logic [7:0]          m_host_arlen;
  logic [2:0]          m_host_arsize;
  logic [1:0]          m_host_arburst;
  logic                m_host_arvalid;
  logic                m_host_arready;
  logic [3:0]          m_host_rid;
  logic [64-1:0]       m_host_rdata;
  logic [1:0]          m_host_rresp;
  logic                m_host_rlast;
  logic                m_host_rvalid;
  logic                m_host_rready;
  logic [3:0]          m_dev_awid;
  logic [63:0]         m_dev_awaddr;
  logic [7:0]          m_dev_awlen;
  logic [2:0]          m_dev_awsize;
  logic [1:0]          m_dev_awburst;
  logic                m_dev_awvalid;
  logic                m_dev_awready;
  logic [64-1:0]       m_dev_wdata;
  logic [64/8-1:0]     m_dev_wstrb;
  logic                m_dev_wlast;
  logic                m_dev_wvalid;
  logic                m_dev_wready;
  logic [3:0]          m_dev_bid;
  logic [1:0]          m_dev_bresp;
  logic                m_dev_bvalid;
  logic                m_dev_bready;
  logic [3:0]          m_dev_arid;
  logic [63:0]         m_dev_araddr;
  logic [7:0]          m_dev_arlen;
  logic [2:0]          m_dev_arsize;
  logic [1:0]          m_dev_arburst;
  logic                m_dev_arvalid;
  logic                m_dev_arready;
  logic [3:0]          m_dev_rid;
  logic [64-1:0]       m_dev_rdata;
  logic [1:0]          m_dev_rresp;
  logic                m_dev_rlast;
  logic                m_dev_rvalid;
  logic                m_dev_rready;
  logic                kd_valid;
  logic                kd_ready;
  logic [2-1:0]        kd_tag;
  logic [31:0]         kd_cmd_id;
  logic [63:0]         kd_kernel_addr;
  logic [63:0]         kd_args_addr;
  logic [31:0]         kd_args_size;
  logic [31:0]         kd_grid_x;
  logic [31:0]         kd_grid_y;
  logic [31:0]         kd_grid_z;
  logic [3:0]          kd_domain;
  logic                kd_done_valid;
  logic [2-1:0]        kd_done_tag;
  logic [1:0]          kd_done_status;
  logic [63:0]         kd_done_info;
  logic                kd_abort;
  logic                kd_heartbeat;
  logic                dbg_issue_valid;
  logic [31:0]         dbg_issue_cmd_id;
  logic                dbg_dma_done_valid;
  logic [31:0]         dbg_dma_done_cmd_id;
  logic                dbg_pub_valid;
  logic [31:0]         dbg_pub_cmd_id;
  logic                dbg_fault;
  logic                dbg_resetting;
  logic h_oob, d_oob;

  sfx_transport_axi_ep #(.NUM_QUEUES(1), .NUM_WINDOWS(4), .HOST_AXI_OFFSET(HOFF)) dut (.*);

  sfx_kernel_null #(.TAGW(2)) u_k (
    .clk, .rst_n(aresetn),
    .kd_valid, .kd_ready, .kd_tag, .kd_grid_x, .kd_grid_y, .kd_grid_z, .kd_abort,
    .kd_done_valid, .kd_done_tag, .kd_done_status, .kd_done_info, .kd_heartbeat);

  tb_axi_mem #(.BASE(HOFF)) u_host (
    .clk, .rst_n(aresetn),
    .awaddr(m_host_awaddr), .awlen(m_host_awlen), .awvalid(m_host_awvalid), .awready(m_host_awready),
    .wdata(m_host_wdata), .wstrb(m_host_wstrb), .wlast(m_host_wlast), .wvalid(m_host_wvalid),
    .wready(m_host_wready), .bresp(m_host_bresp), .bvalid(m_host_bvalid), .bready(m_host_bready),
    .araddr(m_host_araddr), .arlen(m_host_arlen), .arvalid(m_host_arvalid), .arready(m_host_arready),
    .rdata(m_host_rdata), .rresp(m_host_rresp), .rlast(m_host_rlast), .rvalid(m_host_rvalid),
    .rready(m_host_rready), .oob(h_oob));
  tb_axi_mem #(.BASE(64'h0)) u_dev (
    .clk, .rst_n(aresetn),
    .awaddr(m_dev_awaddr), .awlen(m_dev_awlen), .awvalid(m_dev_awvalid), .awready(m_dev_awready),
    .wdata(m_dev_wdata), .wstrb(m_dev_wstrb), .wlast(m_dev_wlast), .wvalid(m_dev_wvalid),
    .wready(m_dev_wready), .bresp(m_dev_bresp), .bvalid(m_dev_bvalid), .bready(m_dev_bready),
    .araddr(m_dev_araddr), .arlen(m_dev_arlen), .arvalid(m_dev_arvalid), .arready(m_dev_arready),
    .rdata(m_dev_rdata), .rresp(m_dev_rresp), .rlast(m_dev_rlast), .rvalid(m_dev_rvalid),
    .rready(m_dev_rready), .oob(d_oob));

  int errors = 0;
  task automatic check(input bit cond, input string what);
    if (!cond) begin
      errors++;
      $display("TB FAIL: %s (t=%0t)", what, $time);
    end
  endtask

  // ---- AXI4-Lite master. Drive and sample at the falling edge: every DUT output is stable there, so
  // "valid && ready at the falling edge" means the handshake completes at the next rising edge.
  task automatic axil_wr(input logic [15:0] a, input logic [31:0] d);
    bit aw_ok = 0, w_ok = 0, aw_hs, w_hs;
    @(negedge clk);
    s_axil_awaddr = a; s_axil_wdata = d; s_axil_wstrb = 4'hF;
    s_axil_awvalid = 1'b1; s_axil_wvalid = 1'b1; s_axil_bready = 1'b1;
    while (!(aw_ok && w_ok)) begin
      aw_hs = !aw_ok && s_axil_awvalid && s_axil_awready;
      w_hs  = !w_ok  && s_axil_wvalid  && s_axil_wready;
      @(negedge clk);
      if (aw_hs) begin aw_ok = 1; s_axil_awvalid = 1'b0; end
      if (w_hs)  begin w_ok  = 1; s_axil_wvalid  = 1'b0; end
    end
    while (!s_axil_bvalid) @(negedge clk);
    @(negedge clk);                      // the rising edge with bvalid && bready has passed
    s_axil_bready = 1'b0;
  endtask
  task automatic axil_rd(input logic [15:0] a, output logic [31:0] d);
    bit hs;
    @(negedge clk);
    s_axil_araddr = a; s_axil_arvalid = 1'b1; s_axil_rready = 1'b1;
    forever begin
      hs = s_axil_arvalid && s_axil_arready;
      @(negedge clk);
      if (hs) begin s_axil_arvalid = 1'b0; break; end
    end
    while (!s_axil_rvalid) @(negedge clk);
    d = s_axil_rdata;
    @(negedge clk);
    s_axil_rready = 1'b0;
  endtask

  task automatic wr64(input logic [15:0] lo, input logic [63:0] v);
    axil_wr(lo, v[31:0]);
    axil_wr(lo + 16'd4, v[63:32]);
  endtask

  // descriptor / completion helpers (host memory is u_host.mem, offset by HOFF)
  task automatic put_desc(input int slot, input logic [15:0] op, input logic [15:0] fl, input logic [31:0] seq,
                          input logic [31:0] id, input logic [63:0] a0, input logic [63:0] a1, input logic [31:0] len);
    logic [511:0] d;
    d = '0;
    d[15:0] = op; d[31:16] = fl; d[63:32] = seq; d[95:64] = id; d[111:96] = 16'd1;
    d[191:128] = a0; d[255:192] = a1; d[287:256] = len;
    for (int i = 0; i < 64; i++) u_host.mem[16'(slot * 64 + i)] = d[i*8 +: 8];
  endtask
  function automatic logic [31:0] cqe_w(input int slot, input int dw);
    cqe_w = {u_host.mem[16'(4096 + slot*32 + dw*4 + 3)], u_host.mem[16'(4096 + slot*32 + dw*4 + 2)],
             u_host.mem[16'(4096 + slot*32 + dw*4 + 1)], u_host.mem[16'(4096 + slot*32 + dw*4)]};
  endfunction

  task automatic wait_cq(input int slot);
    int n = 0;
    while (!cqe_w(slot, 7)[0] && n < 5000) begin @(negedge clk); n++; end
    check(n < 5000, "timeout waiting for CQE");
  endtask

  logic [31:0] rv;
  initial begin
    s_axil_awvalid = 0; s_axil_wvalid = 0; s_axil_arvalid = 0; s_axil_bready = 0; s_axil_rready = 0;
    s_axil_awaddr = 0; s_axil_araddr = 0; s_axil_wdata = 0; s_axil_wstrb = 0;
    kd_done_valid = 0; irq_ack = '0;
    m_host_bid = 0; m_host_rid = 0; m_dev_bid = 0; m_dev_rid = 0;
    for (int i = 0; i < 65536; i++) begin u_host.mem[i] = 8'h00; u_dev.mem[i] = 8'h00; end
    repeat (4) @(negedge clk);
    aresetn = 1'b1; link_up = 1'b1;
    repeat (8) @(negedge clk);

    axil_rd(16'h0000, rv);  check(rv == 32'h53465843, "ID readable through wrapper");
    axil_wr(16'h0030, 32'h0001_0000);                       // ABI_REQ 1.0
    // window 0: host IOVA [0, 64K) R/W domain 0 ; window 1: device [0, 64K) R/W
    wr64(16'h0100, 64'h0);  wr64(16'h0108, 64'h1_0000);  axil_wr(16'h0110, 32'h0000_000D);
    wr64(16'h0120, 64'h0);  wr64(16'h0128, 64'h1_0000);  axil_wr(16'h0130, 32'h0000_000F);
    // queue 0: SQ @0 (4 entries), CQ @0x1000 (4 entries)
    wr64(16'h0408, 64'h0);  wr64(16'h0410, 64'h1000);
    axil_wr(16'h0418, 32'h0000_0202);                       // sq_log2=2, cq_log2=2
    axil_wr(16'h0400, 32'h1);                               // enable
    axil_rd(16'h0404, rv);  check(rv[1:0] == 2'd1, "queue enabled");
    axil_wr(16'h0040, 32'h1);                               // CTRL.ENABLE
    axil_wr(16'h0074, 32'h1);                               // IRQ_ENABLE: QCPL[0]

    // cmd0: H2D 64 bytes from host 0x2000 to dev 0x100.  cmd1: D2H back to host 0x3000 (+F_IRQ)
    for (int i = 0; i < 64; i++) u_host.mem[16'(16'h2000 + i)] = 8'(i * 3 + 5);
    put_desc(0, 16'h0001, 16'h0000, 0, 32'hA0, 64'h2000, 64'h0100, 64);
    put_desc(1, 16'h0002, 16'h0003, 1, 32'hA1, 64'h0100, 64'h3000, 64);   // FENCE_BEFORE | IRQ
    check(irq_req == 2'b00, "no irq request before any cause");
    axil_wr(16'h1000, 32'd2);                               // doorbell: sq tail = 2
    wait_cq(1);
    check(cqe_w(0, 0) == 32'hA0 && cqe_w(0, 2)[15:0] == 16'h0000, "cqe0 id/status");
    check(cqe_w(1, 0) == 32'hA1 && cqe_w(1, 2)[15:0] == 16'h0000, "cqe1 id/status");
    for (int i = 0; i < 64; i++) check(u_host.mem[16'(16'h3000 + i)] == 8'(i * 3 + 5), "D2H data");
    // interrupt: request must be pending and stay asserted until acknowledged
    repeat (6) @(negedge clk);
    check(irq_req[0] === 1'b1, "irq_req[0] asserted after IRQ completion");
    repeat (4) @(negedge clk);
    check(irq_req[0] === 1'b1, "irq_req[0] held until ack");
    irq_ack = 2'b01; @(negedge clk); irq_ack = 2'b00; repeat (2) @(negedge clk);
    check(irq_req[0] === 1'b0, "irq_req[0] dropped after ack");
    // W1C the cause; a new IRQ completion must raise a second request
    axil_wr(16'h0070, 32'h1);
    put_desc(2, 16'h0000, 16'h0002, 2, 32'hA2, 0, 0, 0);                    // NOP + IRQ
    axil_wr(16'h1000, 32'd3);
    wait_cq(2);
    repeat (8) @(negedge clk);
    check(irq_req[0] === 1'b1, "second irq request after new completion");
    irq_ack = 2'b01; @(negedge clk); irq_ack = 2'b00; repeat (3) @(negedge clk);
    check(irq_req[0] === 1'b0, "second request acknowledged");

    check(!h_oob, "host bus only ever addressed IOVA + HOST_AXI_OFFSET");
    check(!d_oob, "device bus in range");

    // FLR resets the core
    flr_active = 1'b1; repeat (4) @(negedge clk); flr_active = 1'b0; repeat (8) @(negedge clk);
    axil_rd(16'h0404, rv);  check(rv[1:0] == 2'd0, "queue disabled after function-level reset");
    axil_rd(16'h0000, rv);  check(rv == 32'h53465843, "ID readable after FLR");

    if (errors == 0) $display("tb_transport_axi_ep: PASS");
    else             $display("tb_transport_axi_ep: FAIL (%0d errors)", errors);
    $finish;
  end

  initial begin
    #5_000_000;
    $display("tb_transport_axi_ep: TIMEOUT");
    $finish;
  end
endmodule
