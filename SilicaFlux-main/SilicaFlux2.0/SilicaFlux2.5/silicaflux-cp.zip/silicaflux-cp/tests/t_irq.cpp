// Interrupt generation: causes, masking, vectors, W1C, re-arm, coalescing (SPEC 11).
#include "test_util.hpp"

using namespace sfxt;

namespace {
const uint32_t QCPL0 = 1u << SFX_IRQ_QCPL_LSB;

struct Rises {
    std::vector<unsigned> vec;
    size_t n() const { return vec.size(); }
};
}  // namespace

// The interrupt edge must not precede visibility of the completion that caused it (D4).
TEST(irq_only_after_cqe_visible) {
    Target& t = c.t;
    EnvOpts o; o.vector = 0;
    Env e(t, o);
    e.dev.irq_enable(QCPL0);
    CqeWatch w(e, 0, nullptr);
    struct Rec { unsigned vec; uint32_t visible; };
    std::vector<Rec> rises;
    t.on_irq_rise = [&](unsigned v) { w.check(); rises.push_back({v, w.seen()}); };
    CHECK_EQ(t.irq_level(0), false);
    const uint32_t N = 10;
    for (uint32_t i = 0; i < N; ++i) {
        e.q().submit(cmd::nop(i, SFX_F_IRQ));
        e.q().ring();
        WAIT(t, rises.size() == i + 1);
        CHECK_EQ(rises[i].vec, 0u);
        CHECK_GE(rises[i].visible, i + 1);          // the completion is already visible at the edge
        CHECK(t.irq_level(0));                        // level stays asserted until acknowledged
        sfx_cqe_t q;
        WAIT(t, e.q().poll(&q));
        CHECK_EQ(q.cmd_id, i);
        e.q().release();
        e.dev.irq_ack(QCPL0);
        WAIT(t, !t.irq_level(0));
        CHECK_EQ(e.dev.irq_status() & QCPL0, 0u);
    }
    settle(t);
    CHECK_EQ(rises.size(), size_t(N));              // exactly one edge per interrupting completion
    t.on_irq_rise = nullptr;
}

TEST(irq_no_cause_no_edge) {
    Target& t = c.t;
    EnvOpts o; o.vector = 0;
    Env e(t, o);
    e.dev.irq_enable(SFX_IRQ_VALID_MASK);
    Rises r;
    t.on_irq_rise = [&](unsigned v) { r.vec.push_back(v); };
    // completions without F_IRQ and with coalescing off never raise the cause
    std::vector<sfx_desc_t> cmds;
    for (uint32_t i = 0; i < 6; ++i) cmds.push_back(cmd::nop(i));
    e.exec(0, cmds);
    settle(t, 20000);
    CHECK_EQ(e.dev.irq_status() & QCPL0, 0u);
    // acknowledging bits that are not set, and clearing error bits, are not events either
    e.dev.irq_ack(SFX_IRQ_VALID_MASK);
    e.clear_err();
    settle(t, 5000);
    CHECK_EQ(r.n(), 0u);
    CHECK(!t.irq_level(0));
    CHECK(!t.irq_level(1));
    t.on_irq_rise = nullptr;
}

TEST(irq_masking_and_w1c) {
    Target& t = c.t;
    EnvOpts o; o.vector = 0;
    Env e(t, o);
    Rises r;
    t.on_irq_rise = [&](unsigned v) { r.vec.push_back(v); };
    CHECK_EQ(e.rd(SFX_R_IRQ_ENABLE), 0u);
    CHECK_ST(e.exec1(0, cmd::nop(1, SFX_F_IRQ)), SFX_ST_OK);
    WAIT(t, e.dev.irq_status() & QCPL0);            // the cause is recorded even though it is masked
    settle(t);
    CHECK(!t.irq_level(0));
    CHECK_EQ(r.n(), 0u);
    e.dev.irq_enable(QCPL0);                         // unmasking a pending cause raises the vector
    WAIT(t, r.n() == 1);
    CHECK(t.irq_level(0));
    // masking again drops the level without clearing the cause
    e.dev.irq_enable(0);
    WAIT(t, !t.irq_level(0));
    CHECK(e.dev.irq_status() & QCPL0);
    e.dev.irq_enable(QCPL0);
    WAIT(t, t.irq_level(0));
    // W1C clears only what is written
    e.dev.irq_ack(SFX_IRQ_DEV_ERR);
    CHECK(e.dev.irq_status() & QCPL0);
    e.dev.irq_ack(QCPL0);
    CHECK_EQ(e.dev.irq_status() & QCPL0, 0u);
    WAIT(t, !t.irq_level(0));
    // register masks: only the 11 architectural bits stick
    t.wr32(SFX_R_IRQ_ENABLE, 0xFFFFFFFFu);
    CHECK_EQ(e.rd(SFX_R_IRQ_ENABLE) & ~uint32_t(SFX_IRQ_VALID_MASK), 0u);
    CHECK_EQ(e.rd(SFX_R_IRQ_ENABLE) & (SFX_IRQ_DEV_ERR | SFX_IRQ_WDT | SFX_IRQ_RESET_DONE | QCPL0),
             uint32_t(SFX_IRQ_DEV_ERR | SFX_IRQ_WDT | SFX_IRQ_RESET_DONE | QCPL0));
    t.on_irq_rise = nullptr;
}

// After a W1C, causes that are still pending must produce a NEW rising edge (SPEC 11, H5).
TEST(irq_rearm_after_partial_ack) {
    Target& t = c.t;
    EnvOpts o; o.vector = 0;
    Env e(t, o);
    t.wr32(SFX_R_IRQ_MISC_VECTOR, 0);                // both causes on vector 0
    e.dev.irq_enable(QCPL0 | SFX_IRQ_RESET_DONE);
    Rises r;
    t.on_irq_rise = [&](unsigned v) { r.vec.push_back(v); };
    t.wr32(SFX_R_IRQ_FORCE, QCPL0 | SFX_IRQ_RESET_DONE);
    WAIT(t, r.n() == 1);
    CHECK_EQ(r.vec[0], 0u);
    settle(t, 2000);
    CHECK_EQ(r.n(), 1u);                              // one edge for two causes
    e.dev.irq_ack(QCPL0);                             // handle one of them
    WAIT(t, r.n() == 2);                              // the other re-pulses the vector
    CHECK(t.irq_level(0));
    settle(t, 2000);
    CHECK_EQ(r.n(), 2u);
    e.dev.irq_ack(SFX_IRQ_RESET_DONE);
    WAIT(t, !t.irq_level(0));
    settle(t, 2000);
    CHECK_EQ(r.n(), 2u);                              // nothing pending: no further edge
    t.on_irq_rise = nullptr;
}

TEST(irq_vector_mapping) {
    Target& t = c.t;
    const unsigned nv = t.geometry().num_queues + 1;
    {   // route the queue to the highest vector, misc causes to vector 0
        EnvOpts o; o.vector = int(nv - 1);
        Env e(t, o);
        t.wr32(SFX_R_IRQ_MISC_VECTOR, 0);
        CHECK_EQ(e.rd(SFX_R_IRQ_MISC_VECTOR), 0u);
        e.dev.irq_enable(QCPL0 | SFX_IRQ_DEV_ERR);
        Rises r;
        t.on_irq_rise = [&](unsigned v) { r.vec.push_back(v); };
        CHECK_ST(e.exec1(0, cmd::nop(1, SFX_F_IRQ)), SFX_ST_OK);
        WAIT(t, r.n() == 1);
        CHECK_EQ(r.vec[0], nv - 1);
        CHECK(t.irq_level(nv - 1));
        CHECK(!t.irq_level(0));
        e.dev.irq_ack(QCPL0);
        WAIT(t, !t.irq_level(nv - 1));
        t.wr32(SFX_R_IRQ_FORCE, SFX_IRQ_DEV_ERR);     // a misc cause goes to the misc vector
        WAIT(t, r.n() == 2);
        CHECK_EQ(r.vec[1], 0u);
        e.dev.irq_ack(SFX_IRQ_DEV_ERR);
        t.on_irq_rise = nullptr;
    }
}

TEST(irq_vector_per_queue) {
    Target& t = c.t;
    if (t.geometry().num_queues < 2) SKIP("needs 2 queues");
    if (t.geometry().num_windows < 8) SKIP("needs 8 windows");
    EnvOpts o; o.queues = 2; o.domains = {1, 2}; o.vectors = {0, 1};
    Env e(t, o);
    t.wr32(SFX_R_IRQ_MISC_VECTOR, 2);
    CHECK_EQ(e.qreg(0, SFX_R_Q_VECTOR), 0u);
    CHECK_EQ(e.qreg(1, SFX_R_Q_VECTOR), 1u);
    e.dev.irq_enable(QCPL0 | (QCPL0 << 1));
    Rises r;
    t.on_irq_rise = [&](unsigned v) { r.vec.push_back(v); };
    CHECK_ST(e.exec1(1, cmd::nop(1, SFX_F_IRQ)), SFX_ST_OK);
    WAIT(t, r.n() == 1);
    CHECK_EQ(r.vec[0], 1u);
    CHECK(!t.irq_level(0));
    CHECK_ST(e.exec1(0, cmd::nop(2, SFX_F_IRQ)), SFX_ST_OK);
    WAIT(t, r.n() == 2);
    CHECK_EQ(r.vec[1], 0u);
    CHECK(t.irq_level(0)); CHECK(t.irq_level(1));
    e.dev.irq_ack(QCPL0 | (QCPL0 << 1));
    t.on_irq_rise = nullptr;
}

TEST(irq_vector_range_rejected) {
    Target& t = c.t;
    EnvOpts o; o.create_queues = false;
    Env e(t, o);
    const unsigned nv = t.geometry().num_queues + 1;
    e.clear_err();
    t.wr32(SFX_Q_REG(0, SFX_R_Q_VECTOR), nv);        // queue is DISABLED: only the range is wrong
    CHECK(e.err_status() & SFX_ERR_BAD_IRQ_CONFIG);
    CHECK_NE(e.qreg(0, SFX_R_Q_VECTOR), nv);
    e.clear_err();
    uint32_t before = e.rd(SFX_R_IRQ_MISC_VECTOR);
    t.wr32(SFX_R_IRQ_MISC_VECTOR, nv);
    CHECK(e.err_status() & SFX_ERR_BAD_IRQ_CONFIG);
    CHECK_EQ(e.rd(SFX_R_IRQ_MISC_VECTOR), before);
    e.clear_err();
    t.wr32(SFX_R_IRQ_MISC_VECTOR, nv - 1);           // the largest legal vector is accepted
    CHECK_EQ(e.err_status(), 0u);
    CHECK_EQ(e.rd(SFX_R_IRQ_MISC_VECTOR), nv - 1);
}

TEST(irq_coalesce_count) {
    Target& t = c.t;
    EnvOpts o; o.vector = 0; o.irq_coal = 4;         // every 4th completion
    Env e(t, o);
    e.dev.irq_enable(QCPL0);
    Rises r;
    t.on_irq_rise = [&](unsigned v) { r.vec.push_back(v); };
    uint32_t id = 0;
    auto nops = [&](int n, uint16_t flags_last = 0) {
        std::vector<sfx_desc_t> v;
        for (int i = 0; i < n; ++i) v.push_back(cmd::nop(id++, i == n - 1 ? flags_last : 0));
        e.exec(0, v);
    };
    nops(3);
    settle(t, 5000);
    CHECK_EQ(e.dev.irq_status() & QCPL0, 0u);         // 3 < threshold
    CHECK_EQ(r.n(), 0u);
    nops(1);                                          // the 4th
    WAIT(t, r.n() == 1);
    e.dev.irq_ack(QCPL0);
    WAIT(t, !t.irq_level(0));
    nops(4);                                          // exactly one more announcement per 4
    WAIT(t, r.n() == 2);
    e.dev.irq_ack(QCPL0);
    WAIT(t, !t.irq_level(0));
    nops(8);
    WAIT(t, e.dev.irq_status() & QCPL0);
    settle(t, 3000);
    e.dev.irq_ack(QCPL0);
    // F_IRQ announces at once and restarts the count
    WAIT(t, !t.irq_level(0));
    size_t base = r.n();
    nops(2);
    nops(1, SFX_F_IRQ);                               // immediate
    WAIT(t, r.n() == base + 1);
    e.dev.irq_ack(QCPL0);
    WAIT(t, !t.irq_level(0));
    nops(3);
    settle(t, 5000);
    CHECK_EQ(r.n(), base + 1);                        // count restarted: 3 < 4
    nops(1);
    WAIT(t, r.n() == base + 2);
    t.on_irq_rise = nullptr;
}

TEST(irq_coalesce_timer) {
    Target& t = c.t;
    EnvOpts o; o.vector = 0;
    o.irq_coal = (64u << 16) | 1000u;                 // 64 timer units, count threshold out of reach
    Env e(t, o);
    e.dev.irq_enable(QCPL0);
    Rises r;
    t.on_irq_rise = [&](unsigned v) { r.vec.push_back(v); };
    e.exec(0, {cmd::nop(1), cmd::nop(2), cmd::nop(3)});
    CHECK_EQ(e.dev.irq_status() & QCPL0, 0u);         // not on the first completions
    CHECK_EQ(r.n(), 0u);
    WAIT(t, r.n() == 1);                              // eventually the timer announces them
    CHECK(e.dev.irq_status() & QCPL0);
    e.dev.irq_ack(QCPL0);
    settle(t, 20000);
    CHECK_EQ(r.n(), 1u);                              // nothing left to announce
    t.on_irq_rise = nullptr;
}

TEST(irq_error_and_force_causes) {
    Target& t = c.t;
    EnvOpts o; o.vector = 0;
    Env e(t, o);
    t.wr32(SFX_R_IRQ_MISC_VECTOR, 0);
    Rises r;
    t.on_irq_rise = [&](unsigned v) { r.vec.push_back(v); };
    e.dev.irq_enable(SFX_IRQ_DEV_ERR | (1u << SFX_IRQ_QERR_LSB));
    // DEV_ERR: raised the first time an ERR_STATUS bit is set
    t.wr32(SFX_R_ID, 0);
    WAIT(t, r.n() == 1);
    CHECK(e.dev.irq_status() & SFX_IRQ_DEV_ERR);
    e.dev.irq_ack(SFX_IRQ_DEV_ERR);
    t.wr32(SFX_R_ID, 0);                              // bit already set: not a *new* error bit
    settle(t, 2000);
    CHECK_EQ(e.dev.irq_status() & SFX_IRQ_DEV_ERR, 0u);
    e.clear_err();
    t.wr32(SFX_R_ID, 0);                              // after W1C it is new again
    WAIT(t, e.dev.irq_status() & SFX_IRQ_DEV_ERR);
    e.dev.irq_ack(SFX_IRQ_DEV_ERR);
    WAIT(t, !t.irq_level(0));
    size_t base = r.n();
    // QERR[0]: the queue dies
    sfx_desc_t bad = cmd::nop(1);
    bad.seq = 12345;
    e.q().submit_raw(bad);
    e.q().ring();
    WAIT(t, e.dev.queue_state(0) == SFX_QS_ERROR);
    WAIT(t, r.n() > base);
    CHECK(e.dev.irq_status() & (1u << SFX_IRQ_QERR_LSB));
    e.dev.irq_ack(1u << SFX_IRQ_QERR_LSB);
    // IRQ_FORCE sets any architectural cause bit and nothing else
    t.wr32(SFX_R_IRQ_FORCE, 0xFFFFFFFFu);
    uint32_t st = e.dev.irq_status();
    CHECK_EQ(st & ~uint32_t(SFX_IRQ_VALID_MASK), 0u);
    CHECK_EQ(st & (SFX_IRQ_DEV_ERR | SFX_IRQ_WDT | SFX_IRQ_RESET_DONE | QCPL0 | (1u << SFX_IRQ_QERR_LSB)),
             uint32_t(SFX_IRQ_DEV_ERR | SFX_IRQ_WDT | SFX_IRQ_RESET_DONE | QCPL0 | (1u << SFX_IRQ_QERR_LSB)));
    e.dev.irq_ack(0xFFFFFFFFu);
    CHECK_EQ(e.dev.irq_status(), 0u);
    t.on_irq_rise = nullptr;
}
