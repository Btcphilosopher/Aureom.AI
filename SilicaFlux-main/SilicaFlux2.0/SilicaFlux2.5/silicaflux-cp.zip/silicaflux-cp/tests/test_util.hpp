// Test utilities shared by every test file.  Tests are written against sfx::Target only, so the
// same code runs on the software model and on the Verilated RTL.  Tests MUST be timing
// independent: wait for conditions, assert partial orders (events), never absolute times.
#pragma once

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <functional>
#include <memory>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

#include "sfx_abi.h"
#include "sfx_driver.hpp"
#include "sfx_target.hpp"

namespace sfxt {
using namespace sfx;

struct TestFailure : std::runtime_error { using std::runtime_error::runtime_error; };
struct TestSkip : std::runtime_error { using std::runtime_error::runtime_error; };
#define SKIP(msg) throw sfxt::TestSkip(msg)

// ------------------------------------------------------------------ assertions ------------
template <class T> std::string show(const T& v) {
    std::ostringstream o;
    if constexpr (std::is_same_v<T, bool>) o << (v ? "true" : "false");
    else if constexpr (std::is_enum_v<T>) o << static_cast<long long>(v);
    else if constexpr (std::is_integral_v<T>) {
        if constexpr (std::is_signed_v<T>) o << static_cast<long long>(v);
        else o << static_cast<unsigned long long>(v) << " (0x" << std::hex << static_cast<unsigned long long>(v) << ")";
    } else o << v;
    return o.str();
}
template <class A, class B> int cmp3(const A& a, const B& b) {
    if constexpr (std::is_integral_v<A> && std::is_integral_v<B>) {
        if constexpr (std::is_signed_v<A> == std::is_signed_v<B>) return a < b ? -1 : (a > b ? 1 : 0);
        else if constexpr (std::is_signed_v<A>) {
            if (a < 0) return -1;
            auto ua = static_cast<std::make_unsigned_t<A>>(a);
            return ua < b ? -1 : (ua > b ? 1 : 0);
        } else {
            if (b < 0) return 1;
            auto ub = static_cast<std::make_unsigned_t<B>>(b);
            return a < ub ? -1 : (a > ub ? 1 : 0);
        }
    } else {
        return a == b ? 0 : (a < b ? -1 : 1);
    }
}
[[noreturn]] inline void fail(const char* file, int line, const std::string& msg) {
    std::ostringstream o;
    o << file << ":" << line << ": " << msg;
    throw TestFailure(o.str());
}
#define CHECK(c) do { if (!(c)) sfxt::fail(__FILE__, __LINE__, "CHECK failed: " #c); } while (0)
#define REQUIRE(c) CHECK(c)
#define CHECK_MSG(c, m) do { if (!(c)) sfxt::fail(__FILE__, __LINE__, std::string("CHECK failed: " #c " -- ") + (m)); } while (0)
#define SFXT_CMP(a, b, op, opstr) do { const auto _a = (a); const auto _b = (b); \
    if (!(sfxt::cmp3(_a, _b) op 0)) sfxt::fail(__FILE__, __LINE__, std::string("CHECK failed: " #a " " opstr " " #b "  [") + sfxt::show(_a) + " vs " + sfxt::show(_b) + "]"); } while (0)
#define CHECK_EQ(a, b) SFXT_CMP(a, b, ==, "==")
#define CHECK_NE(a, b) SFXT_CMP(a, b, !=, "!=")
#define CHECK_LT(a, b) SFXT_CMP(a, b, <, "<")
#define CHECK_LE(a, b) SFXT_CMP(a, b, <=, "<=")
#define CHECK_GT(a, b) SFXT_CMP(a, b, >, ">")
#define CHECK_GE(a, b) SFXT_CMP(a, b, >=, ">=")
// Compare two completion statuses with names in the message.
#define CHECK_ST(cqe, st) do { uint16_t _s = (cqe).status; if (_s != (st)) sfxt::fail(__FILE__, __LINE__, \
    std::string("status: got ") + sfx_status_str(_s) + " expected " + sfx_status_str(st)); } while (0)

// ------------------------------------------------------------------ registry --------------
struct Ctx {
    Target& t;
    uint64_t seed = 1;
    uint64_t digest = 0;
    bool has_digest = false;
    // A brand-new Target of the same kind/geometry/bus profile, for tests that need several
    // independent devices (one Env per Target: never build two Envs on the same Target).
    std::function<std::unique_ptr<Target>()> fresh;
    void set_digest(uint64_t d) { digest = d; has_digest = true; }
};
struct TestReg { const char* name; void (*fn)(Ctx&); };
inline std::vector<TestReg>& registry() { static std::vector<TestReg> r; return r; }
struct Registrar { Registrar(const char* n, void (*f)(Ctx&)) { registry().push_back({n, f}); } };
#define TEST(name) static void test_##name(sfxt::Ctx& c); \
    static sfxt::Registrar reg_##name(#name, test_##name); \
    static void test_##name(sfxt::Ctx& c)

// ------------------------------------------------------------------ waiting --------------
template <class F> bool wait_for(Target& t, F cond, uint64_t max_units = 6000000, uint64_t step = 8) {
    uint64_t spent = 0;
    while (!cond()) {
        if (spent >= max_units) return false;
        t.run(step);
        spent += step;
    }
    return true;
}
#define WAIT(t, cond) do { if (!sfxt::wait_for((t), [&]() -> bool { return (cond); })) \
    sfxt::fail(__FILE__, __LINE__, "timed out waiting for: " #cond); } while (0)
// Counter registers (Q_CQ_TAIL, *CMDS_*) may advance a few cycles AFTER the completion becomes
// visible in host memory (RTL counts after the phase-word write response).  Never read them at the
// instant a completion is seen: wait for the value instead.
#define WAIT_REG(t, off, val) WAIT((t), (t).rd32(off) == uint32_t(val))
// Let the device run "long enough that nothing else should happen" (bounded, not timing-asserting).
inline void settle(Target& t, uint64_t units = 4000) { t.run(units); }

inline uint64_t fnv(uint64_t h, const void* p, size_t n) {
    const uint8_t* b = static_cast<const uint8_t*>(p);
    for (size_t i = 0; i < n; ++i) { h ^= b[i]; h *= 0x100000001b3ull; }
    return h;
}
constexpr uint64_t kFnvInit = 0xcbf29ce484222325ull;

inline void fill_pattern(uint8_t* p, size_t n, uint64_t seed) {
    std::mt19937_64 r(seed);
    for (size_t i = 0; i < n; ++i) p[i] = static_cast<uint8_t>(r());
}

// ------------------------------------------------------------------ allocator ------------
// Hands out zeroed "coherent" host memory from Target.host.  cpu = backdoor pointer.
class HostArena : public DmaAllocator {
public:
    explicit HostArena(Target& t, uint64_t skip = 4096) : t_(t), next_(t.host.base() + skip) {}
    DmaBuffer alloc_coherent(size_t bytes, size_t align) override {
        uint64_t a = (next_ + align - 1) & ~(uint64_t(align) - 1);
        DmaBuffer b;
        b.cpu = t_.host.ptr(a, bytes);
        if (!b.cpu) throw TestFailure("host arena exhausted");
        std::memset(b.cpu, 0, bytes);
        b.iova = Iova(a);
        b.size = bytes;
        next_ = a + bytes;
        return b;
    }
    void free_coherent(const DmaBuffer&) override {}
    uint64_t next() const { return next_; }
private:
    Target& t_;
    uint64_t next_;
};

// ------------------------------------------------------------------ environment ----------
struct HBuf {
    uint8_t* p = nullptr;
    Iova iova;
    size_t size = 0;
};
struct DBuf {
    DevAddr addr;
    uint8_t* p = nullptr;  // backdoor pointer into Target.dev
    size_t size = 0;
};

struct EnvOpts {
    unsigned queues = 1;                // queues to create (<= geometry)
    unsigned sq_log2 = 5, cq_log2 = 5;
    uint32_t seq_start = 0;
    bool enable_device = true;          // CTRL.ENABLE
    bool create_queues = true;
    bool arenas = true;                 // one host + one dev R/W data window per domain
    std::vector<unsigned> domains;      // per queue; default: all domain 1
    size_t host_arena = 1u << 20, dev_arena = 1u << 20;
    int vector = -1;                    // interrupt vector for every queue (-1: reset default)
    std::vector<int> vectors;           // per-queue override
    uint32_t irq_coal = 0;
};

// A bring-up'd device: Device (kernel role) + Queue objects (user role) + data arenas.
class Env {
public:
    Target& t;
    HostArena alloc;
    Device dev;
    EnvOpts o;
    std::vector<QueueHandle> qh;
    std::vector<std::unique_ptr<Queue>> qu;
    std::vector<unsigned> dom;

    explicit Env(Target& tt, EnvOpts opts = EnvOpts{})
        : t(tt), alloc(tt), dev(tt, alloc, [&tt] { tt.run(1); }), o(std::move(opts)) {
        bring_up();
    }
    // Repeat the whole bring-up (ABI, windows, queues).  Use after a controlled or hard reset: all
    // device state is gone, the old rings and data windows are abandoned, new ones are allocated.
    void reinit() {
        arenas_.clear(); qh.clear(); qu.clear(); dom.clear();
        bring_up();
    }

    Queue& q(unsigned i = 0) { return *qu.at(i); }
    unsigned align() const { return t.geometry().dma_align; }

    // ---- data arenas (one pair of windows per domain) ------------------------------------
    struct Arena {
        unsigned domain;
        int hwin, dwin;
        Iova hbase; uint64_t hsize, hnext;
        DevAddr dbase; uint64_t dsize, dnext;
    };
    std::vector<Arena> arenas_;
    Arena& arena(unsigned d) {
        for (auto& a : arenas_) if (a.domain == d) return a;
        Arena a{};
        a.domain = d;
        DmaBuffer hb = alloc.alloc_coherent(o.host_arena, 4096);
        a.hbase = hb.iova; a.hsize = o.host_arena; a.hnext = hb.iova.v;
        a.dbase = DevAddr(next_dev_); a.dsize = o.dev_arena; a.dnext = next_dev_;
        next_dev_ += o.dev_arena;
        a.hwin = dev.map_host(a.hbase, a.hsize, PermRW, d);
        a.dwin = dev.map_dev(a.dbase, a.dsize, PermRW, d);
        if (a.hwin < 0 || a.dwin < 0) throw TestFailure("arena window mapping rejected");
        arenas_.push_back(a);
        return arenas_.back();
    }
    HBuf host_buf(size_t n, unsigned domain = 0, size_t align_to = 64) {
        Arena& a = arena(domain ? domain : dom.at(0));
        uint64_t p = (a.hnext + align_to - 1) & ~(uint64_t(align_to) - 1);
        if (p + n > a.hbase.v + a.hsize) throw TestFailure("host data arena exhausted");
        a.hnext = p + n;
        HBuf b;
        b.iova = Iova(p); b.size = n; b.p = t.host.ptr(p, n);
        return b;
    }
    DBuf dev_buf(size_t n, unsigned domain = 0, size_t align_to = 64) {
        Arena& a = arena(domain ? domain : dom.at(0));
        uint64_t p = (a.dnext + align_to - 1) & ~(uint64_t(align_to) - 1);
        if (p + n > a.dbase.v + a.dsize) throw TestFailure("dev data arena exhausted");
        a.dnext = p + n;
        DBuf b;
        b.addr = DevAddr(p); b.size = n; b.p = t.dev.ptr(p, n);
        return b;
    }

    // ---- command execution helpers -------------------------------------------------------
    // Submit all `cmds` on queue qi (respecting free slots), ring, collect every completion in
    // order, release CQ slots.  Fails the test on timeout.
    std::vector<sfx_cqe_t> exec(unsigned qi, const std::vector<sfx_desc_t>& cmds, uint64_t max_units = 12000000) {
        Queue& Q = q(qi);
        std::vector<sfx_cqe_t> out;
        size_t next = 0;
        uint64_t spent = 0;
        while (out.size() < cmds.size()) {
            bool moved = false;
            bool subbed = false;
            while (next < cmds.size() && Q.sq_free() > 0 && Q.outstanding() < Q.cq_size()) {
                Q.submit(cmds[next++]);
                subbed = moved = true;
            }
            if (subbed) Q.ring();
            sfx_cqe_t c;
            bool got = false;
            while (Q.poll(&c)) { out.push_back(c); got = moved = true; }
            if (got) Q.release();
            if (!moved) {
                t.run(8);
                spent += 8;
                if (spent > max_units) throw TestFailure("exec(): timed out; completions " + std::to_string(out.size()) +
                                                         "/" + std::to_string(cmds.size()));
            }
        }
        return out;
    }
    sfx_cqe_t exec1(unsigned qi, const sfx_desc_t& d) { return exec(qi, {d}).at(0); }

    // Wait until `n` more completions are visible on queue qi without releasing them.
    std::vector<sfx_cqe_t> collect(unsigned qi, size_t n) {
        Queue& Q = q(qi);
        std::vector<sfx_cqe_t> out;
        WAIT(t, [&] { sfx_cqe_t c; while (Q.poll(&c)) out.push_back(c); return out.size() >= n; }());
        Q.release();
        return out;
    }
    // Ring queue qi and wait for exactly n completions.
    std::vector<sfx_cqe_t> ring_collect(unsigned qi, size_t n) { q(qi).ring(); return collect(qi, n); }

    uint32_t status() { return dev.status(); }
    uint32_t rd(uint32_t off) { return t.rd32(off); }
    void wr(uint32_t off, uint32_t v) { t.wr32(off, v); }
    uint32_t qreg(unsigned qi, uint32_t reg) { return t.rd32(SFX_Q_REG(qi, reg)); }
    uint32_t err_status() { return t.rd32(SFX_R_ERR_STATUS); }
    void clear_err() { t.wr32(SFX_R_ERR_STATUS, 0xFFFFFFFFu); }

    // Wait until the device reports IDLE.
    void wait_idle() { WAIT(t, (status() & SFX_STATUS_IDLE) != 0); }

    void bring_up() {
        std::string why;
        if (!dev.init(&why)) throw TestFailure("device init failed: " + why);
        if (o.queues > t.geometry().num_queues) SKIP("needs more queues than the geometry has");
        if (o.enable_device) dev.enable(true);
        for (unsigned q = 0; q < o.queues; ++q) dom.push_back(q < o.domains.size() ? o.domains[q] : 1);
        if (o.arenas) for (unsigned d : dom) arena(d);
        if (o.create_queues) {
            qh.resize(o.queues);
            for (unsigned q = 0; q < o.queues; ++q) {
                QueueConfig c;
                c.domain = static_cast<uint8_t>(dom[q]);
                c.sq_log2 = o.sq_log2; c.cq_log2 = o.cq_log2;
                c.seq_start = o.seq_start;
                c.vector = q < o.vectors.size() ? o.vectors[q] : o.vector;
                c.irq_coal = o.irq_coal;
                if (!dev.create_queue(q, c, &qh[q])) throw TestFailure("queue create failed");
                qu.push_back(std::make_unique<Queue>(dev.make_queue(t, qh[q])));
            }
        }
    }

private:
    uint64_t next_dev_ = 0x1000;
};

// ------------------------------------------------------------------ CQE watcher ----------
// Installs a host-memory write hook and calls `cb` at the exact moment each completion of queue
// `qi` first becomes visible (its phase_word matches the expected phase).  This is how tests
// assert what must already be true "when the host could see the completion".
class CqeWatch {
public:
    using Cb = std::function<void(uint32_t n, const sfx_cqe_t&)>;
    CqeWatch(Env& e, unsigned qi, Cb cb) : e_(e), qi_(qi), cb_(std::move(cb)) {
        next_ = e.qh.at(qi).cfg.seq_start;
        e_.t.host.write_hook = [this](uint64_t a, uint64_t l) {
            if (extra) extra(a, l);  // e.g. "a signal write just landed: what is visible right now?"
            check();
        };
    }
    std::function<void(uint64_t addr, uint64_t len)> extra;
    ~CqeWatch() { e_.t.host.write_hook = nullptr; }
    uint32_t seen() const { return next_ - e_.qh.at(qi_).cfg.seq_start; }
    void check() {
        const QueueHandle& h = e_.qh[qi_];
        const uint32_t mask = (1u << h.cfg.cq_log2) - 1;
        for (;;) {
            const uint8_t* slot = static_cast<const uint8_t*>(h.cq.cpu) + size_t(next_ & mask) * SFX_CQE_BYTES;
            uint32_t pw;
            std::memcpy(&pw, slot + SFX_C_PHASE, 4);
            if ((pw & 1u) != sfx_cq_phase(next_, h.cfg.seq_start, h.cfg.cq_log2)) return;
            sfx_cqe_t c;
            std::memcpy(&c, slot, sizeof c);
            uint32_t n = next_++;
            if (cb_) cb_(n, c);
        }
    }
private:
    Env& e_;
    unsigned qi_;
    Cb cb_;
    uint32_t next_;
};

// ------------------------------------------------------------------ event helpers ----------
inline int find_event(const Target& t, EvKind k, uint32_t cmd_id) {
    for (size_t i = 0; i < t.events.size(); ++i)
        if (t.events[i].kind == k && t.events[i].cmd_id == cmd_id) return static_cast<int>(i);
    return -1;
}

// ------------------------------------------------------------------ misc -------------------
inline sfx_desc_t desc_copy_raw(uint16_t op, uint32_t id, uint64_t a0, uint64_t a1, uint32_t len, uint16_t flags = 0) {
    sfx_desc_t d = cmd::make(op, id, flags);
    d.addr0 = a0; d.addr1 = a1; d.length = len;
    return d;
}
inline uint64_t round_up(uint64_t v, uint64_t a) { return (v + a - 1) / a * a; }

}  // namespace sfxt
