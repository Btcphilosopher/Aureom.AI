// DMA bus failures: SLVERR / DECERR on every combination of space and direction.
#include "test_util.hpp"

using namespace sfxt;

namespace {
enum class Kind { H2D, D2H, D2D };
const char* kname(Kind k) { return k == Kind::H2D ? "h2d" : k == Kind::D2H ? "d2h" : "d2d"; }
}  // namespace

// A copy whose source (read) or destination (write) transaction returns a bus error part-way
// through.  The completion must say so, report a correct prefix, leave everything outside the
// destination range alone, and the queue must carry on.
TEST(dma_bus_errors_mid_transfer) {
    for (Kind kind : {Kind::H2D, Kind::D2H, Kind::D2D}) {
        for (bool fault_on_src : {true, false}) {
            for (Resp rsp : {Resp::SLVERR, Resp::DECERR}) {
                for (int where = 0; where < 3; ++where) {  // first unit, middle, last unit
                    auto tp = c.fresh();
                    Target& t = *tp;
                    Env e(t);
                    const uint32_t A = e.align();
                    const uint32_t len = 16384 / A * A;
                    const uint32_t pad = 512;
                    const uint32_t fault_off = where == 0 ? 0 : where == 1 ? (len / 2 / A) * A + A : len - A;
                    const std::string label = std::string(kname(kind)) + (fault_on_src ? " src " : " dst ") +
                                              (rsp == Resp::SLVERR ? "SLVERR" : "DECERR") + " @" + std::to_string(fault_off);

                    HBuf hs = e.host_buf(len), hd = e.host_buf(len + 2 * pad);
                    DBuf ds = e.dev_buf(len), dd = e.dev_buf(len + 2 * pad);
                    DBuf g_a = e.dev_buf(len), g_b = e.dev_buf(len), g_c = e.dev_buf(len);  // healthy neighbours
                    fill_pattern(hs.p, len, 1); fill_pattern(ds.p, len, 2);
                    fill_pattern(g_a.p, len, 3);
                    std::memset(hd.p, 0xC5, len + 2 * pad);
                    std::memset(dd.p, 0xC5, len + 2 * pad);

                    sfx_desc_t d;
                    SimMemory *src_mem, *dst_mem;
                    uint64_t src_base, dst_base;
                    const uint8_t* src_ptr;
                    uint8_t* dst_buf;  // start of the canary-guarded destination buffer
                    if (kind == Kind::H2D) {
                        d = cmd::copy_h2d(2, hs.iova, DevAddr(dd.addr.v + pad), len);
                        src_mem = &t.host; dst_mem = &t.dev; src_base = hs.iova.v; dst_base = dd.addr.v + pad;
                        src_ptr = hs.p; dst_buf = dd.p;
                    } else if (kind == Kind::D2H) {
                        d = cmd::copy_d2h(2, ds.addr, Iova(hd.iova.v + pad), len);
                        src_mem = &t.dev; dst_mem = &t.host; src_base = ds.addr.v; dst_base = hd.iova.v + pad;
                        src_ptr = ds.p; dst_buf = hd.p;
                    } else {
                        d = cmd::copy_d2d(2, ds.addr, DevAddr(dd.addr.v + pad), len);
                        src_mem = &t.dev; dst_mem = &t.dev; src_base = ds.addr.v; dst_base = dd.addr.v + pad;
                        src_ptr = ds.p; dst_buf = dd.p;
                    }
                    FaultRule f;
                    f.resp = rsp;
                    f.lo = (fault_on_src ? src_base : dst_base) + fault_off;
                    f.hi = f.lo + A;
                    f.on_read = fault_on_src;
                    f.on_write = !fault_on_src;
                    (fault_on_src ? src_mem : dst_mem)->add_fault(f);

                    auto r = e.exec(0, {cmd::copy_d2d(1, g_a.addr, g_b.addr, len), d, cmd::copy_d2d(3, g_a.addr, g_c.addr, len)});
                    CHECK_EQ(r.size(), 3u);
                    CHECK_MSG(r[0].status == SFX_ST_OK, label);
                    CHECK_MSG(r[2].status == SFX_ST_OK, label);
                    CHECK_MSG(r[1].cmd_id == 2, label);
                    const uint16_t want = fault_on_src ? SFX_ST_DMA_READ_ERR : SFX_ST_DMA_WRITE_ERR;
                    if (r[1].status != want) fail(__FILE__, __LINE__, label + ": status " + sfx_status_str(r[1].status));
                    // prefix guarantee (SPEC 8.1)
                    const uint64_t res = r[1].result;
                    CHECK_MSG(res <= fault_off, label);
                    CHECK_MSG(res % A == 0, label);
                    CHECK_MSG(std::memcmp(dst_buf + pad, src_ptr, res) == 0, label);
                    // nothing outside the destination range was touched
                    for (uint32_t i = 0; i < pad; ++i) CHECK_MSG(dst_buf[i] == 0xC5, label);
                    for (uint32_t i = pad + len; i < len + 2 * pad; ++i) CHECK_MSG(dst_buf[i] == 0xC5, label);
                    // neighbours unaffected
                    CHECK(std::memcmp(g_b.p, g_a.p, len) == 0);
                    CHECK(std::memcmp(g_c.p, g_a.p, len) == 0);
                    // fault record: status, queue, and an address inside the failing operand
                    uint32_t info = e.rd(SFX_R_FAULT_INFO);
                    CHECK_MSG((info & 0xFFFF) == want, label);
                    CHECK_MSG(((info >> 16) & 0xF) == 0, label);
                    uint64_t fa = e.rd(SFX_R_FAULT_ADDR_LO) | (uint64_t(e.rd(SFX_R_FAULT_ADDR_HI)) << 32);
                    uint64_t op = fault_on_src ? src_base : dst_base;
                    CHECK_MSG(fa >= op && fa < op + len, label);
                    WAIT_REG(t, SFX_R_CMDS_ERR, 1u);
                    WAIT_REG(t, SFX_R_CMDS_OK, 2u);
                    // a bus error is not a device error, and the queue keeps working
                    CHECK_EQ(e.err_status(), 0u);
                    CHECK_EQ(e.dev.queue_state(0), uint32_t(SFX_QS_ENABLED));
                    // after the fault is gone the same command succeeds
                    src_mem->clear_faults(); dst_mem->clear_faults();
                    sfx_desc_t retry = d; retry.cmd_id = 4;
                    sfx_cqe_t q = e.exec1(0, retry);
                    CHECK_MSG(q.status == SFX_ST_OK, label);
                    CHECK_MSG(std::memcmp(dst_buf + pad, src_ptr, len) == 0, label);
                }
            }
        }
    }
}

// Faults on the *other* side must not matter: a read-fault rule on the destination range does not
// disturb a write there (and vice versa) - a guard against mixing up read and write attribution.
TEST(dma_fault_direction_attribution) {
    Env e(c.t);
    const uint32_t A = e.align();
    const uint32_t len = 4096 / A * A;
    HBuf hs = e.host_buf(len); DBuf dd = e.dev_buf(len);
    fill_pattern(hs.p, len, 4);
    FaultRule f;
    f.lo = dd.addr.v; f.hi = dd.addr.v + len; f.on_read = true; f.on_write = false;  // reads of dst fail; writes fine
    c.t.dev.add_fault(f);
    CHECK_ST(e.exec1(0, cmd::copy_h2d(1, hs.iova, dd.addr, len)), SFX_ST_OK);
    CHECK(std::memcmp(hs.p, dd.p, len) == 0);
    c.t.dev.clear_faults();
    f.lo = hs.iova.v; f.hi = hs.iova.v + len; f.on_read = false; f.on_write = true;  // writes to src fail; reads fine
    c.t.host.add_fault(f);
    CHECK_ST(e.exec1(0, cmd::copy_h2d(2, hs.iova, dd.addr, len)), SFX_ST_OK);
}
