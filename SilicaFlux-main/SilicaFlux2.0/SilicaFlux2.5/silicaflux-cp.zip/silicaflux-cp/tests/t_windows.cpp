// DMA authorisation windows in action: revocation, BUSY, domains, permissions, spaces.
#include "test_util.hpp"

using namespace sfxt;

namespace {
bool win_busy(Target& t, int w) { return t.rd32(SFX_WIN_REG(w, SFX_R_W_CTRL)) & SFX_WIN_BUSY; }
}  // namespace

// Hang the bus mid-copy so the window is *provably* in use: BUSY must read 1, invalidate must take
// effect for new authorisations at once, and the transfer must stop at the next burst boundary.
TEST(window_revoke_midcopy_h2d_source) {
    Target& t = c.t;
    Env e(t);
    const uint32_t A = e.align();
    const uint32_t len = 65536 / A * A;
    HBuf h = e.host_buf(len);
    DBuf d = e.dev_buf(len);
    fill_pattern(h.p, len, 9);
    std::memset(d.p, 0xEE, len);
    const int hw = e.arena(1).hwin;
    CHECK(e.q().submit(cmd::copy_h2d(1, h.iova, d.addr, len)));
    e.q().ring();
    WAIT(t, t.host.touched(h.iova.v, h.iova.v + len, 1));  // the copy is reading its source
    t.host.set_hang(true);
    settle(t, 3000);
    CHECK(win_busy(t, hw));                                 // an authorised burst is outstanding
    t.wr32(SFX_WIN_REG(hw, SFX_R_W_CTRL), 0);               // revoke
    uint32_t ctrl = t.rd32(SFX_WIN_REG(hw, SFX_R_W_CTRL));
    CHECK(!(ctrl & SFX_WIN_VALID));
    CHECK(ctrl & SFX_WIN_BUSY);                             // still in use until the burst drains
    t.host.set_hang(false);
    auto r = e.collect(0, 1);
    CHECK_ST(r[0], SFX_ST_UNAUTHORIZED);
    CHECK_LT(r[0].result, len);
    CHECK_EQ(r[0].result % A, 0u);
    CHECK(std::memcmp(d.p, h.p, r[0].result) == 0);         // prefix guarantee (SPEC 8.1)
    WAIT(t, !win_busy(t, hw));
    // no further access to the revoked window once BUSY has cleared
    size_t n = t.host.log.size();
    settle(t, 2000);
    for (size_t i = n; i < t.host.log.size(); ++i)
        CHECK(!(t.host.log[i].addr < h.iova.v + len && t.host.log[i].addr + t.host.log[i].len > h.iova.v));
    CHECK(e.err_status() == 0u || e.err_status() == SFX_ERR_BAD_DOORBELL);
    CHECK_EQ(e.rd(SFX_R_FAULT_INFO) & 0xFFFF, uint32_t(SFX_ST_UNAUTHORIZED));
}

TEST(window_revoke_midcopy_d2h_destination) {
    Target& t = c.t;
    Env e(t);
    const uint32_t A = e.align();
    const uint32_t len = 65536 / A * A;
    HBuf h = e.host_buf(len);
    DBuf d = e.dev_buf(len);
    fill_pattern(d.p, len, 10);
    std::memset(h.p, 0xEE, len);
    const int hw = e.arena(1).hwin;
    CHECK(e.q().submit(cmd::copy_d2h(1, d.addr, h.iova, len)));
    e.q().ring();
    WAIT(t, t.host.touched(h.iova.v, h.iova.v + len, 2));
    t.host.set_hang(true);
    settle(t, 3000);
    CHECK(win_busy(t, hw));
    t.wr32(SFX_WIN_REG(hw, SFX_R_W_CTRL), 0);
    t.host.set_hang(false);
    auto r = e.collect(0, 1);
    CHECK_ST(r[0], SFX_ST_UNAUTHORIZED);
    CHECK_LT(r[0].result, len);
    CHECK_EQ(r[0].result % A, 0u);
    CHECK(std::memcmp(h.p, d.p, r[0].result) == 0);
    WAIT(t, !win_busy(t, hw));
}

// Free-running revocation through the driver's unmap path (invalidate, poll BUSY): whatever the
// interleaving, the copy ends OK (finished first) or UNAUTHORIZED with a valid prefix, and after
// unmap() returns the device never touches the region again.
TEST(window_unmap_during_copy_driver_flow) {
    Target& t = c.t;
    Env e(t);
    const uint32_t A = e.align();
    const uint32_t len = 65536 / A * A;
    HBuf h = e.host_buf(len);
    DBuf d = e.dev_buf(len);
    fill_pattern(h.p, len, 12);
    const int hw = e.arena(1).hwin;
    e.q().submit(cmd::copy_h2d(1, h.iova, d.addr, len));
    e.q().ring();
    WAIT(t, t.host.touched(h.iova.v, h.iova.v + len, 1));
    CHECK(e.dev.unmap_window(hw));
    size_t n = t.host.log.size();   // unmap returned: BUSY=0, so the memory could now be freed
    auto r = e.collect(0, 1);
    CHECK(r[0].status == SFX_ST_OK || r[0].status == SFX_ST_UNAUTHORIZED);
    if (r[0].status == SFX_ST_UNAUTHORIZED) CHECK(std::memcmp(d.p, h.p, r[0].result) == 0);
    for (size_t i = n; i < t.host.log.size(); ++i)
        CHECK(!(t.host.log[i].addr < h.iova.v + len && t.host.log[i].addr + t.host.log[i].len > h.iova.v &&
                t.host.log[i].addr >= h.iova.v));
}

TEST(window_domain_isolation) {
    Target& t = c.t;
    if (t.geometry().num_queues < 2) SKIP("needs 2 queues");
    if (t.geometry().num_windows < 8) SKIP("needs 8 windows");
    EnvOpts o; o.queues = 2; o.domains = {1, 2};
    Env e(t, o);
    const uint32_t A = e.align();
    const uint32_t len = 512 / A * A + A;
    HBuf h1 = e.host_buf(len, 1), h2 = e.host_buf(len, 2);
    DBuf d1 = e.dev_buf(len, 1), d2 = e.dev_buf(len, 2);
    fill_pattern(h1.p, len, 1); fill_pattern(h2.p, len, 2);
    std::memset(d1.p, 0xAA, len); std::memset(d2.p, 0xBB, len);
    // own domain: fine
    CHECK_ST(e.exec1(0, cmd::copy_h2d(1, h1.iova, d1.addr, len)), SFX_ST_OK);
    CHECK_ST(e.exec1(1, cmd::copy_h2d(2, h2.iova, d2.addr, len)), SFX_ST_OK);
    CHECK(std::memcmp(d1.p, h1.p, len) == 0);
    CHECK(std::memcmp(d2.p, h2.p, len) == 0);
    t.host.clear_log(); t.dev.clear_log();
    // queue 0 (domain 1) naming domain-2 memory, source or destination, host or device
    std::vector<uint8_t> d2_before(d2.p, d2.p + len), d1_before(d1.p, d1.p + len);
    CHECK_ST(e.exec1(0, cmd::copy_h2d(3, h2.iova, d1.addr, len)), SFX_ST_UNAUTHORIZED);
    CHECK_ST(e.exec1(0, cmd::copy_h2d(4, h1.iova, d2.addr, len)), SFX_ST_UNAUTHORIZED);
    CHECK_ST(e.exec1(0, cmd::copy_d2d(5, d2.addr, d1.addr, len)), SFX_ST_UNAUTHORIZED);
    CHECK_ST(e.exec1(0, cmd::copy_d2h(6, d1.addr, h2.iova, len)), SFX_ST_UNAUTHORIZED);
    // and the other way round
    CHECK_ST(e.exec1(1, cmd::copy_h2d(7, h1.iova, d2.addr, len)), SFX_ST_UNAUTHORIZED);
    CHECK_ST(e.exec1(1, cmd::copy_d2d(8, d1.addr, d2.addr, len)), SFX_ST_UNAUTHORIZED);
    CHECK(std::memcmp(d2.p, d2_before.data(), len) == 0);
    CHECK(std::memcmp(d1.p, d1_before.data(), len) == 0);
    // the refused commands moved no data: nothing touched the foreign buffers
    CHECK(!t.host.touched(h2.iova.v, h2.iova.v + len, 1));
    CHECK(!t.dev.touched(d2.addr.v, d2.addr.v + len));
    CHECK(!t.dev.touched(d1.addr.v, d1.addr.v + len));
}

TEST(window_permissions_spaces_and_spans) {
    Target& t = c.t;
    if (t.geometry().num_windows < 8) SKIP("needs 8 windows");
    EnvOpts o; o.arenas = false;
    Env e(t, o);
    const uint32_t A = e.align();
    const uint32_t len = 256 / A * A + A;
    auto hbuf = [&](unsigned perm, bool map = true) {
        HBuf b; DmaBuffer db = e.alloc.alloc_coherent(8192, 4096);
        b.p = static_cast<uint8_t*>(db.cpu); b.iova = db.iova; b.size = 8192;
        if (map) CHECK(e.dev.map_host(b.iova, 8192, perm, 1) >= 0);
        return b;
    };
    uint64_t dnext = 0x10000;
    auto dbuf = [&](unsigned perm, bool map = true) {
        DBuf b; b.addr = DevAddr(dnext); b.size = 8192; b.p = t.dev.ptr(dnext, 8192); dnext += 8192;
        if (map) CHECK(e.dev.map_dev(b.addr, 8192, perm, 1) >= 0);
        return b;
    };
    HBuf h_r = hbuf(PermR), h_w = hbuf(PermW);
    DBuf d_r = dbuf(PermR), d_w = dbuf(PermW), d_rw = dbuf(PermRW), d_rw2 = dbuf(PermRW);  // d_rw|d_rw2 adjacent
    fill_pattern(h_r.p, len, 1); fill_pattern(d_r.p, len, 2); fill_pattern(d_rw.p, len, 3);
    std::memset(h_w.p, 0x77, 8192);
    // allowed combinations
    CHECK_ST(e.exec1(0, cmd::copy_h2d(1, h_r.iova, d_w.addr, len)), SFX_ST_OK);     // R src, W dst
    CHECK_ST(e.exec1(0, cmd::copy_d2h(2, d_r.addr, h_w.iova, len)), SFX_ST_OK);     // R src, W dst
    CHECK_ST(e.exec1(0, cmd::copy_d2d(3, d_r.addr, d_w.addr, len)), SFX_ST_OK);
    // wrong permission: read-only destination, write-only source
    CHECK_ST(e.exec1(0, cmd::copy_d2h(4, d_r.addr, h_r.iova, len)), SFX_ST_UNAUTHORIZED);
    CHECK_ST(e.exec1(0, cmd::copy_h2d(5, h_w.iova, d_w.addr, len)), SFX_ST_UNAUTHORIZED);
    CHECK_ST(e.exec1(0, cmd::copy_d2d(6, d_r.addr, d_r.addr, len)), SFX_ST_UNAUTHORIZED);   // dst not writable
    CHECK_ST(e.exec1(0, cmd::copy_d2d(7, d_w.addr, d_rw.addr, len)), SFX_ST_UNAUTHORIZED);  // src not readable
    // kernel entry/args need READ permission on device memory
    CHECK_ST(e.exec1(0, cmd::kernel(8, d_r.addr, DevAddr(0), 0)), SFX_ST_OK);
    CHECK_ST(e.exec1(0, cmd::kernel(9, d_w.addr, DevAddr(0), 0)), SFX_ST_UNAUTHORIZED);
    CHECK_ST(e.exec1(0, cmd::kernel(10, d_r.addr, d_w.addr, 64)), SFX_ST_UNAUTHORIZED);     // args not readable
    CHECK_ST(e.exec1(0, cmd::kernel(11, d_r.addr, d_rw.addr, 64)), SFX_ST_OK);
    // host and device are different spaces: a host window does not authorise the same number as a device address
    DBuf alias; alias.addr = DevAddr(h_r.iova.v & 0xFFFFFF); alias.size = 8192;  // inside dev memory
    CHECK_ST(e.exec1(0, cmd::copy_d2d(12, alias.addr, d_w.addr, len)), SFX_ST_UNAUTHORIZED);
    // a range must lie inside ONE window: two adjacent windows do not combine
    CHECK_EQ(d_rw.addr.v + 8192, d_rw2.addr.v);
    CHECK_ST(e.exec1(0, cmd::copy_d2d(13, DevAddr(d_rw.addr.v + 8192 - 2 * A), d_w.addr, 4 * A)), SFX_ST_UNAUTHORIZED);
    CHECK_ST(e.exec1(0, cmd::copy_d2d(14, DevAddr(d_rw.addr.v + 8192 - 4 * A), d_w.addr, 4 * A)), SFX_ST_OK);
    // exact window edges are inside, one unit past is outside
    CHECK_ST(e.exec1(0, cmd::copy_d2d(15, DevAddr(d_r.addr.v + 8192 - 4 * A), d_w.addr, 4 * A)), SFX_ST_OK);
    CHECK_ST(e.exec1(0, cmd::copy_d2d(16, DevAddr(d_r.addr.v + 8192 - 3 * A), d_w.addr, 4 * A)), SFX_ST_UNAUTHORIZED);
}
