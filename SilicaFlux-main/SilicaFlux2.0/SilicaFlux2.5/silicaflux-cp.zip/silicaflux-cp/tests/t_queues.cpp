// Queue mechanics: wraparound, counters at 2^32, CQ-full backpressure, doorbells, lifecycle.
#include "test_util.hpp"

using namespace sfxt;

namespace {
void wrap_run(Ctx& c, unsigned sl, unsigned cl, uint32_t start, uint32_t N) {
    auto tp = c.fresh();
    Target& t = *tp;
    EnvOpts o;
    o.sq_log2 = sl; o.cq_log2 = cl; o.seq_start = start;
    Env e(t, o);
    Queue& Q = e.q();
    const uint32_t A = e.align();
    HBuf h = e.host_buf(4 * A);
    DBuf d = e.dev_buf(4 * A);
    std::vector<sfx_desc_t> cmds;
    for (uint32_t i = 0; i < N; ++i) {
        if (i % 7 == 3) cmds.push_back(cmd::copy_h2d(1000 + i, h.iova, d.addr, 2 * A));  // real traffic too
        else cmds.push_back(cmd::nop(1000 + i));
    }
    auto r = e.exec(0, cmds);
    CHECK_EQ(r.size(), size_t(N));
    for (uint32_t i = 0; i < N; ++i) {
        const sfx_cqe_t& q = r[i];
        CHECK_EQ(q.cmd_id, 1000 + i);
        CHECK_EQ(q.sq_seq, uint32_t(start + i));
        CHECK_EQ(q.cq_seq, uint32_t(start + i));
        CHECK_EQ(q.sq_head, uint32_t(start + i + 1));
        CHECK_EQ(q.phase_word & 1u, sfx_cq_phase(start + i, start, cl));
        CHECK_ST(q, SFX_ST_OK);
    }
    const uint32_t end = start + N;
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_HEAD), end);
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_TAIL), end);
    WAIT_REG(t, SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), end);
    WAIT_REG(t, SFX_Q_REG(0, SFX_R_Q_CQ_HEAD), end);
    CHECK_EQ(Q.sq_free(), 1u << sl);  // everything reclaimed through cqe.sq_head
    CHECK_EQ(e.err_status(), 0u);
}
}  // namespace

TEST(queue_wraparound_tiny_rings) {
    struct Cfg { unsigned sl, cl; };
    for (Cfg g : {Cfg{1, 1}, Cfg{2, 2}, Cfg{2, 3}, Cfg{3, 2}, Cfg{1, 3}}) wrap_run(c, g.sl, g.cl, 0, 300);
}

TEST(queue_counters_wrap_at_2_32) {
    // 16 commands before the 32-bit counters wrap, then 100 more across and past the wrap
    for (unsigned lg : {1u, 2u, 3u}) wrap_run(c, lg, lg, 0xFFFFFFF0u, 116);
    wrap_run(c, 3, 2, 0xFFFFFFF8u, 80);
}

TEST(queue_cq_full_backpressure) {
    EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 2;
    Env e(c.t, o);
    Queue& Q = e.q();
    const QueueHandle& h = e.qh[0];
    for (uint32_t i = 0; i < 8; ++i) CHECK(Q.submit(cmd::nop(i)));
    Q.ring();
    // the CQ has 4 slots and we do not release any: exactly 4 completions may ever appear
    WAIT(c.t, e.qreg(0, SFX_R_Q_CQ_TAIL) == 4u);
    std::vector<uint8_t> snap(h.cq.size);
    std::memcpy(snap.data(), h.cq.cpu, h.cq.size);
    settle(c.t, 20000);
    CHECK_EQ(e.qreg(0, SFX_R_Q_CQ_TAIL), 4u);
    CHECK(std::memcmp(snap.data(), h.cq.cpu, h.cq.size) == 0);  // never overwritten
    CHECK(!(e.status() & SFX_STATUS_IDLE));                      // work is still queued behind the stall
    std::vector<sfx_cqe_t> got;
    sfx_cqe_t q;
    while (Q.poll(&q)) got.push_back(q);
    CHECK_EQ(got.size(), 4u);
    for (uint32_t i = 0; i < 4; ++i) { CHECK_EQ(got[i].cmd_id, i); CHECK_EQ(got[i].cq_seq, i); }
    // releasing lets the rest through
    Q.release();
    WAIT(c.t, e.qreg(0, SFX_R_Q_CQ_TAIL) == 8u);
    while (Q.poll(&q)) got.push_back(q);
    CHECK_EQ(got.size(), 8u);
    for (uint32_t i = 4; i < 8; ++i) { CHECK_EQ(got[i].cmd_id, i); CHECK_EQ(got[i].cq_seq, i); CHECK_ST(got[i], SFX_ST_OK); }
    Q.release();
    e.wait_idle();
    CHECK_EQ(e.err_status(), 0u);
}

TEST(doorbell_duplicates) {
    Env e(c.t);
    Queue& Q = e.q();
    const uint32_t A = e.align();
    DBuf d = e.dev_buf(64); HBuf h = e.host_buf(64);
    // kernels are not idempotent: a double execution would be visible in kernels_launched
    for (uint32_t i = 0; i < 3; ++i) CHECK(Q.submit(cmd::kernel(50 + i, d.addr, DevAddr(0), 0)));
    uint32_t dup0 = e.rd(SFX_R_DUP_DB_COUNT);
    for (int i = 0; i < 5; ++i) Q.ring();  // one accepted, four duplicates
    auto r = e.collect(0, 3);
    CHECK_EQ(r.size(), 3u);
    for (uint32_t i = 0; i < 3; ++i) { CHECK_EQ(r[i].cmd_id, 50 + i); CHECK_ST(r[i], SFX_ST_OK); }
    CHECK_EQ(e.rd(SFX_R_DUP_DB_COUNT), dup0 + 4);
    // duplicates after consumption are still harmless
    for (int i = 0; i < 4; ++i) Q.ring();
    settle(c.t);
    CHECK_EQ(e.rd(SFX_R_DUP_DB_COUNT), dup0 + 8);
    CHECK_EQ(c.t.kernels_launched.size(), 3u);
    WAIT_REG(c.t, SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), 3u);
    CHECK_EQ(e.err_status(), 0u);  // duplicates are not errors
    // CQ-head duplicates too
    uint32_t dup1 = e.rd(SFX_R_DUP_DB_COUNT);
    Q.release(); Q.release();
    CHECK_EQ(e.rd(SFX_R_DUP_DB_COUNT), dup1 + 2);  // head already released by collect()
    CHECK_EQ(e.err_status(), 0u);
    (void)A; (void)h;
    // then the queue keeps working
    CHECK_ST(e.exec1(0, cmd::nop(99)), SFX_ST_OK);
}

TEST(doorbell_invalid_values) {
    EnvOpts o; o.sq_log2 = 3; o.cq_log2 = 3;
    Env e(c.t, o);
    Queue& Q = e.q();
    auto r = e.exec(0, {cmd::nop(1), cmd::nop(2), cmd::nop(3)});
    CHECK_EQ(r.size(), 3u);
    const uint32_t T = Q.sq_tail();  // == 3 == consumed head
    const uint32_t S = Q.sq_size();
    struct Bad { const char* what; uint32_t v; };
    for (Bad b : {Bad{"backwards", T - 1}, Bad{"far backwards", T - 100}, Bad{"beyond capacity", T + S + 1},
                  Bad{"far beyond capacity", T + 1000}}) {
        e.clear_err();
        Q.ring_value(b.v);
        CHECK_MSG(e.err_status() & SFX_ERR_BAD_DOORBELL, b.what);
        CHECK_MSG(e.qreg(0, SFX_R_Q_SQ_TAIL) == T, b.what);   // accepted tail unchanged
        CHECK_MSG(Q.device_sq_tail() == T, b.what);            // doorbell page reads accepted tail
    }
    // CQ head: beyond the device tail, and backwards
    WAIT_REG(c.t, SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), 3u);
    uint32_t cq_tail = e.qreg(0, SFX_R_Q_CQ_TAIL);
    CHECK_EQ(cq_tail, 3u);
    for (Bad b : {Bad{"cq head beyond tail", cq_tail + 1}, Bad{"cq head backwards", cq_tail - 1},
                  Bad{"cq head far beyond", cq_tail + 100}}) {
        e.clear_err();
        Q.release_value(b.v);
        CHECK_MSG(e.err_status() & SFX_ERR_BAD_DOORBELL, b.what);
        CHECK_MSG(e.qreg(0, SFX_R_Q_CQ_HEAD) == 3u, b.what);
    }
    // the queue is unaffected
    e.clear_err();
    auto r2 = e.exec(0, {cmd::nop(10), cmd::nop(11)});
    CHECK_EQ(r2.size(), 2u);
    CHECK_EQ(r2[0].sq_seq, 3u);
    CHECK_EQ(e.err_status(), 0u);
    // exactly-at-capacity forward move is legal for the doorbell value itself, but only if the
    // slots hold valid descriptors; verify the boundary by filling the ring completely
    for (uint32_t i = 0; i < S; ++i) CHECK(Q.submit(cmd::nop(200 + i)));
    CHECK_EQ(Q.sq_free(), 0u);
    Q.ring();
    CHECK_EQ(e.collect(0, S).size(), size_t(S));
    CHECK_EQ(e.err_status(), 0u);
}

// A tail may never move backwards over entries that were already published (the device may be
// fetching them).  The device is paused (CTRL.ENABLE=0) so published entries stay unconsumed:
// this is the case where "new tail still within capacity" is NOT sufficient to accept.
TEST(doorbell_retraction_rejected) {
    EnvOpts o; o.sq_log2 = 3; o.cq_log2 = 3; o.enable_device = false;
    Env e(c.t, o);
    Queue& Q = e.q();
    for (uint32_t i = 1; i <= 4; ++i) CHECK(Q.submit(cmd::nop(i)));
    Q.ring();
    CHECK_EQ(Q.device_sq_tail(), 4u);
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_HEAD), 0u);   // paused: nothing consumed yet
    for (uint32_t back : {2u, 0u, 3u, 1u}) {
        e.clear_err();
        Q.ring_value(back);                      // retracts published entries
        CHECK_MSG(e.err_status() & SFX_ERR_BAD_DOORBELL, "retracting doorbell must be rejected");
        CHECK_EQ(Q.device_sq_tail(), 4u);
    }
    e.clear_err();
    Q.ring_value(4);                             // same value: duplicate, not an error
    CHECK_EQ(e.err_status(), 0u);
    CHECK(Q.submit(cmd::nop(5)));
    CHECK(Q.submit(cmd::nop(6)));
    Q.ring();
    CHECK_EQ(Q.device_sq_tail(), 6u);
    e.dev.enable(true);                          // now let them run: exactly the six, in order
    auto r = e.collect(0, 6);
    for (uint32_t i = 0; i < 6; ++i) { CHECK_EQ(r[i].cmd_id, i + 1); CHECK_ST(r[i], SFX_ST_OK); }
    settle(c.t);
    CHECK_EQ(e.qreg(0, SFX_R_Q_CQ_TAIL), 6u);
}

TEST(doorbell_to_non_enabled_queue) {
    EnvOpts o; o.create_queues = false;
    Env e(c.t, o);
    // never-enabled queue
    e.clear_err();
    c.t.wr32(SFX_DB_REG(0, SFX_R_DB_SQ_TAIL), 1);
    CHECK(e.err_status() & SFX_ERR_BAD_DOORBELL);
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_TAIL), 0u);
    e.clear_err();
    c.t.wr32(SFX_DB_REG(0, SFX_R_DB_CQ_HEAD), 1);
    CHECK(e.err_status() & SFX_ERR_BAD_DOORBELL);
}

TEST(doorbell_storm_exactly_once) {
    EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 4;
    Env e(c.t, o);
    Queue& Q = e.q();
    DBuf k = e.dev_buf(64);
    std::mt19937_64 rng(c.seed);
    const uint32_t N = 60;
    std::vector<sfx_cqe_t> done;
    uint32_t next = 0;
    uint64_t guard = 0;
    while (done.size() < N) {
        bool any = false;
        while (next < N && Q.sq_free() > 0 && Q.outstanding() < Q.cq_size() && rng() % 3) {
            Q.submit(cmd::kernel(300 + next, k.addr, DevAddr(0), 0));
            ++next; any = true;
        }
        int rings = 1 + int(rng() % 4);  // redundant doorbells, interleaved with execution
        for (int i = 0; i < rings; ++i) { Q.ring(); c.t.run(1 + rng() % 3); }
        sfx_cqe_t q;
        bool got = false;
        while (Q.poll(&q)) { done.push_back(q); got = true; }
        if (got) { Q.release(); if (rng() & 1) Q.release(); }
        if (!any && !got) c.t.run(4);
        if (++guard > 200000) throw TestFailure("storm test did not finish");
    }
    settle(c.t);
    CHECK_EQ(c.t.kernels_launched.size(), size_t(N));
    for (uint32_t i = 0; i < N; ++i) {
        CHECK_EQ(c.t.kernels_launched[i].cmd_id, 300 + i);
        CHECK_EQ(done[i].cmd_id, 300 + i);
        CHECK_ST(done[i], SFX_ST_OK);
    }
    CHECK_EQ(e.qreg(0, SFX_R_Q_CQ_TAIL), N);
    CHECK_GT(e.rd(SFX_R_DUP_DB_COUNT), 0u);
    CHECK_EQ(e.err_status() & SFX_ERR_BAD_DOORBELL, 0u);
}

TEST(queue_lifecycle_disable_reenable) {
    EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 4;
    Env e(c.t, o);
    Queue& Q = e.q();
    const uint32_t A = e.align();
    const uint32_t len = 16384 / A * A;
    HBuf h = e.host_buf(len); DBuf d = e.dev_buf(len);
    fill_pattern(h.p, len, 5);
    // queue a slow copy followed by NOPs, then disable immediately
    Q.submit(cmd::copy_h2d(1, h.iova, d.addr, len));
    for (uint32_t i = 2; i <= 6; ++i) Q.submit(cmd::nop(i));
    Q.ring();
    CHECK(e.dev.disable_queue(0));
    CHECK_EQ(e.qreg(0, SFX_R_Q_STATUS) & SFX_QSTAT_STATE_MASK, uint32_t(SFX_QS_DISABLED));
    e.wait_idle();
    // whatever was fetched before the disable completed and was published, in order, starting at 0
    sfx_cqe_t q;
    uint32_t seen = 0;
    while (Q.poll(&q)) { CHECK_EQ(q.cmd_id, seen + 1); CHECK_ST(q, SFX_ST_OK); ++seen; }
    CHECK_LE(seen, 6u);
    const uint32_t pub = seen;
    WAIT_REG(c.t, SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), pub);  // the register agrees with what the host can see
    if (pub >= 1) CHECK(std::memcmp(h.p, d.p, len) == 0);  // a published copy is complete
    // doorbells to a disabled queue are rejected
    e.clear_err();
    Q.ring_value(Q.sq_tail() + 1);
    CHECK(e.err_status() & SFX_ERR_BAD_DOORBELL);
    // config is writable again; reconfigure with different geometry and re-enable
    e.dev.destroy_queue(e.qh[0]);
    QueueConfig cfg;
    cfg.domain = 1; cfg.sq_log2 = 3; cfg.cq_log2 = 5; cfg.seq_start = 32;
    QueueHandle nh;
    CHECK(e.dev.create_queue(0, cfg, &nh));
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_HEAD), 32u);  // counters restart at SEQ_START
    CHECK_EQ(e.qreg(0, SFX_R_Q_CQ_TAIL), 32u);
    e.qh[0] = nh;
    e.qu[0] = std::make_unique<Queue>(e.dev.make_queue(c.t, nh));
    auto r = e.exec(0, {cmd::nop(70), cmd::nop(71)});
    CHECK_EQ(r[0].sq_seq, 32u);
    CHECK_EQ(r[1].cq_seq, 33u);
}

TEST(queue_config_lock_rules) {
    Env e(c.t);
    const Geometry& g = c.t.geometry();
    // while ENABLED, configuration is locked
    struct Reg { const char* n; uint32_t off; uint32_t v; };
    for (Reg r : {Reg{"SQ_BASE_LO", SFX_R_Q_SQ_BASE_LO, 0x1000}, Reg{"CQ_BASE_HI", SFX_R_Q_CQ_BASE_HI, 7},
                  Reg{"SIZE", SFX_R_Q_SIZE, 0x0303}, Reg{"VECTOR", SFX_R_Q_VECTOR, 0}, Reg{"SEQ_START", SFX_R_Q_SEQ_START, 64}}) {
        uint32_t before = e.qreg(0, r.off);
        e.clear_err();
        c.t.wr32(SFX_Q_REG(0, r.off), r.v);
        CHECK_MSG(e.err_status() & SFX_ERR_CFG_LOCKED, r.n);
        CHECK_MSG(e.qreg(0, r.off) == before, r.n);
    }
    // domain change and a second ENABLE are refused too
    e.clear_err();
    c.t.wr32(SFX_Q_REG(0, SFX_R_Q_CTRL), SFX_QCTL_ENABLE | (7u << SFX_QCTL_DOM_LSB));
    CHECK(e.err_status() & SFX_ERR_CFG_LOCKED);
    CHECK_EQ((e.qreg(0, SFX_R_Q_CTRL) & SFX_QCTL_DOM_MASK) >> SFX_QCTL_DOM_LSB, 1u);
    CHECK_EQ(e.qreg(0, SFX_R_Q_STATUS) & SFX_QSTAT_STATE_MASK, uint32_t(SFX_QS_ENABLED));
    // IRQ_COAL is not structural: writable any time
    e.clear_err();
    c.t.wr32(SFX_Q_REG(0, SFX_R_Q_IRQ_COAL), 0x00020003);
    CHECK_EQ(e.qreg(0, SFX_R_Q_IRQ_COAL), 0x00020003u);
    CHECK_EQ(e.err_status(), 0u);
    // read-only queue registers refuse writes
    e.clear_err();
    c.t.wr32(SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), 9);
    CHECK(e.err_status() & SFX_ERR_BAD_REG_ACCESS);
    CHECK_NE(e.qreg(0, SFX_R_Q_CQ_TAIL), 9u);
    // vector range is enforced when writing
    CHECK(e.dev.disable_queue(0));
    e.clear_err();
    c.t.wr32(SFX_Q_REG(0, SFX_R_Q_VECTOR), g.num_queues + 1);
    CHECK(e.err_status() & SFX_ERR_BAD_IRQ_CONFIG);
    CHECK_NE(e.qreg(0, SFX_R_Q_VECTOR), g.num_queues + 1);
}

TEST(queue_enable_config_validation) {
    EnvOpts o; o.create_queues = false;
    Env e(c.t, o);
    // each case breaks exactly one rule of SPEC 6.5 "Enable"
    struct Case { const char* what; std::function<void(QueueConfig&, QueueHandle&)> mut; };
    auto attempt = [&](const Case& k) {
        QueueConfig cfg; cfg.domain = 1; cfg.sq_log2 = 3; cfg.cq_log2 = 3;
        QueueHandle h;
        h.id = 0; h.cfg = cfg;
        h.sq = e.alloc.alloc_coherent(64u << 3, 64);
        h.cq = e.alloc.alloc_coherent(32u << 3, 64);
        int w1 = e.dev.map_host(h.sq.iova, h.sq.size, PermR, 1);
        int w2 = e.dev.map_host(h.cq.iova, h.cq.size, PermW, 1);
        k.mut(h.cfg, h);
        e.clear_err();
        e.dev.program_queue(0, h);
        e.dev.set_queue_enable(0, 1, true);
        CHECK_MSG(e.dev.queue_state(0) == SFX_QS_ERROR, k.what);
        CHECK_MSG(e.dev.queue_err(0) == SFX_QERR_BAD_CONFIG, k.what);
        CHECK_MSG(e.err_status() & SFX_ERR_BAD_QCONFIG, k.what);
        CHECK(e.dev.disable_queue(0));
        e.dev.unmap_window(w1); e.dev.unmap_window(w2);
    };
    const Case cases[] = {
        {"sq_log2 = 0", [](QueueConfig& c2, QueueHandle&) { c2.sq_log2 = 0; }},
        {"sq_log2 too big", [](QueueConfig& c2, QueueHandle&) { c2.sq_log2 = SFX_MAX_RING_LOG2 + 1; }},
        {"cq_log2 = 0", [](QueueConfig& c2, QueueHandle&) { c2.cq_log2 = 0; }},
        {"cq_log2 too big", [](QueueConfig& c2, QueueHandle&) { c2.cq_log2 = 13; }},
        {"sq base unaligned", [](QueueConfig&, QueueHandle& h) { h.sq.iova = Iova(h.sq.iova.v + 8); }},
        {"cq base unaligned", [](QueueConfig&, QueueHandle& h) { h.cq.iova = Iova(h.cq.iova.v + 32); }},
        {"seq_start not ring-aligned", [](QueueConfig& c2, QueueHandle&) { c2.seq_start = 4; }},
        {"sq ring outside any window", [](QueueConfig&, QueueHandle& h) { h.sq.iova = Iova(h.sq.iova.v + 1 * 1024 * 1024); }},
        {"cq ring outside any window", [](QueueConfig&, QueueHandle& h) { h.cq.iova = Iova(h.cq.iova.v + 1 * 1024 * 1024); }},
        {"ring larger than its window", [](QueueConfig& c2, QueueHandle&) { c2.sq_log2 = 6; }},
        {"ring beyond host address bits", [](QueueConfig&, QueueHandle& h) { h.sq.iova = Iova((1ull << 48) - 64); }},
    };
    for (const Case& k : cases) attempt(k);
    // ring windows of the wrong domain or permission are rejected as well
    {
        QueueConfig cfg; cfg.domain = 1; cfg.sq_log2 = 3; cfg.cq_log2 = 3;
        QueueHandle h; h.id = 0; h.cfg = cfg;
        h.sq = e.alloc.alloc_coherent(64u << 3, 64);
        h.cq = e.alloc.alloc_coherent(32u << 3, 64);
        int w1 = e.dev.map_host(h.sq.iova, h.sq.size, PermR, 1);
        int w2 = e.dev.map_host(h.cq.iova, h.cq.size, PermR, 1);  // CQ must be writable
        e.dev.program_queue(0, h);
        e.dev.set_queue_enable(0, 1, true);
        CHECK_EQ(e.dev.queue_state(0), uint32_t(SFX_QS_ERROR));
        CHECK(e.dev.disable_queue(0));
        e.dev.unmap_window(w2);
        w2 = e.dev.map_host(h.cq.iova, h.cq.size, PermW, 2);  // wrong domain
        e.dev.set_queue_enable(0, 1, true);
        CHECK_EQ(e.dev.queue_state(0), uint32_t(SFX_QS_ERROR));
        CHECK(e.dev.disable_queue(0));
        e.dev.unmap_window(w2);
        w2 = e.dev.map_host(h.cq.iova, h.cq.size, PermW, 1);  // finally right
        e.dev.set_queue_enable(0, 1, true);
        CHECK_EQ(e.dev.queue_state(0), uint32_t(SFX_QS_ENABLED));
        (void)w1;
    }
}
