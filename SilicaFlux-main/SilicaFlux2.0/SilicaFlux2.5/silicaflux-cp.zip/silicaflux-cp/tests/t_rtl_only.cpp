// RTL-only tests: behaviour the abstract MmioIf cannot express (AXI4-Lite byte strobes and unaligned
// writes). The software model is tested against the same rules through its register decode, but only
// the RTL harness can put a malformed bus access on the wire. Compiled only into the RTL test binary.
#ifdef SFX_WITH_RTL
#include "rtl_target.hpp"
#include "test_util.hpp"

using namespace sfxt;

namespace {
sfx::RtlOnly& rtl(Target& t) {
    auto* r = dynamic_cast<sfx::RtlOnly*>(&t);
    if (!r) SKIP("RTL-only test");
    return *r;
}
}  // namespace

// SPEC 3.5: a write that is partial, unaligned, or to a read-only/unmapped register is ignored and
// sets ERR_BAD_REG_ACCESS; the bus response is always OKAY (an AXI error could become a host fault).
TEST(rtl_axilite_partial_and_unaligned_writes) {
    Target& t = c.t;
    sfx::RtlOnly& r = rtl(t);
    t.wr32(SFX_R_ERR_STATUS, 0xFFFFFFFFu);
    t.wr32(SFX_R_SCRATCH, 0x12345678u);
    CHECK_EQ(t.rd32(SFX_R_ERR_STATUS) & SFX_ERR_BAD_REG_ACCESS, 0u);

    for (uint8_t strb : {uint8_t(0x0), uint8_t(0x1), uint8_t(0x3), uint8_t(0x7), uint8_t(0xE)}) {
        t.wr32(SFX_R_ERR_STATUS, 0xFFFFFFFFu);
        r.wr32_strb(SFX_R_SCRATCH, 0xFFFFFFFFu, strb);
        CHECK_EQ(t.rd32(SFX_R_SCRATCH), 0x12345678u);                   // not applied, not even partially
        CHECK(t.rd32(SFX_R_ERR_STATUS) & SFX_ERR_BAD_REG_ACCESS);
    }
    // unaligned address
    t.wr32(SFX_R_ERR_STATUS, 0xFFFFFFFFu);
    r.wr32_strb(SFX_R_SCRATCH + 2, 0xDEADBEEFu, 0xF);
    CHECK_EQ(t.rd32(SFX_R_SCRATCH), 0x12345678u);
    CHECK(t.rd32(SFX_R_ERR_STATUS) & SFX_ERR_BAD_REG_ACCESS);
    // a full-strobe aligned write still works afterwards
    t.wr32(SFX_R_ERR_STATUS, 0xFFFFFFFFu);
    r.wr32_strb(SFX_R_SCRATCH, 0xCAFEF00Du, 0xF);
    CHECK_EQ(t.rd32(SFX_R_SCRATCH), 0xCAFEF00Du);
    CHECK_EQ(t.rd32(SFX_R_ERR_STATUS) & SFX_ERR_BAD_REG_ACCESS, 0u);
}

// Reserved/unmapped space reads as zero without side effects (SPEC 3.5); unmapped writes are flagged.
TEST(rtl_unmapped_space_raz_wi) {
    Target& t = c.t;
    sfx::RtlOnly& r = rtl(t);
    t.wr32(SFX_R_ERR_STATUS, 0xFFFFFFFFu);
    for (uint32_t off : {0x02Cu, 0x0A0u, 0x0F00u, 0x0FFCu, 0x2F00u, 0x7000u, 0xFFFCu})
        CHECK_EQ(t.rd32(off), 0u);
    CHECK_EQ(t.rd32(SFX_R_ERR_STATUS), 0u);
    for (uint32_t off : {0x02Cu, 0x0A0u, 0x0F00u, 0x7000u}) {
        t.wr32(SFX_R_ERR_STATUS, 0xFFFFFFFFu);
        r.wr32_strb(off, 0x1u, 0xF);
        CHECK(t.rd32(SFX_R_ERR_STATUS) & SFX_ERR_BAD_REG_ACCESS);
        CHECK_EQ(t.rd32(off), 0u);
    }
}

// Partial-strobe or unaligned doorbell writes must not move the tail.
TEST(rtl_doorbell_partial_strobe_ignored) {
    Target& t = c.t;
    sfx::RtlOnly& r = rtl(t);
    Env e(t);
    e.clear_err();
    const uint32_t before = e.qreg(0, SFX_R_Q_SQ_TAIL);
    r.wr32_strb(SFX_DB_REG(0, SFX_R_DB_SQ_TAIL), 1, 0x3);
    r.wr32_strb(SFX_DB_REG(0, SFX_R_DB_SQ_TAIL) + 2, 1, 0xF);
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_TAIL), before);
    CHECK(e.err_status() & SFX_ERR_BAD_REG_ACCESS);
    // and the queue still works
    CHECK_ST(e.exec1(0, cmd::nop(1)), SFX_ST_OK);
}
#endif  // SFX_WITH_RTL
