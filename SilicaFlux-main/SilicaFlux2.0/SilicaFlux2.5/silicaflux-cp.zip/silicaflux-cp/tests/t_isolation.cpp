// Tenant-isolation and resource-abuse properties (found by independent review of SPEC vs RTL):
//  * a queue whose owner never releases its CQ must not stall other queues' completions (SPEC 7.7),
//  * disabling a queue whose CQ is full must not deadlock (SPEC 6.5),
//  * errors caused by user-mappable doorbell pages must not raise kernel-visible interrupts (SPEC 3),
//  * no coalescing state may survive a queue being disabled (SPEC 11).
#include "test_util.hpp"

using namespace sfxt;

TEST(isolation_unreleased_cq_does_not_stall_other_queues) {
    EnvOpts o;
    o.queues = 2; o.sq_log2 = 4; o.cq_log2 = 1;       // two queues, 2-entry CQs
    Env e(c.t, o);
    Queue& A = e.q(0);
    e.dev.wdt_enable(3000);                            // waiting on the host must never look like a hang

    // Tenant A submits far more commands than its CQ can hold and never releases a slot.
    for (uint32_t i = 0; i < 6; ++i) CHECK(A.submit(cmd::nop(100 + i)));
    A.ring();
    WAIT_REG(c.t, SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), 2u);

    // Tenant B must keep completing, promptly and in order, behind A's stalled queue.
    for (uint32_t round = 0; round < 6; ++round) {
        auto r = e.exec(1, {cmd::nop(200 + 2 * round), cmd::nop(201 + 2 * round)});
        CHECK_EQ(r.size(), 2u);
        CHECK_EQ(r[0].cmd_id, 200 + 2 * round);
        CHECK_ST(r[1], SFX_ST_OK);
    }
    // A is exactly where credit stops it: two completions published, two descriptors consumed
    settle(c.t, 12000);                                // longer than the watchdog timeout
    CHECK_EQ(e.qreg(0, SFX_R_Q_CQ_TAIL), 2u);
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_HEAD), 2u);
    CHECK(!(e.status() & SFX_STATUS_IDLE));            // A still has unfetched work
    CHECK(!(e.status() & SFX_STATUS_FAULT));
    CHECK_EQ(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_EXPIRED, 0u);

    // Once A releases, its remaining commands complete (in order, nothing lost or repeated).
    std::vector<sfx_cqe_t> got;
    sfx_cqe_t q;
    for (int guard = 0; got.size() < 6 && guard < 200000; ++guard) {
        bool any = false;
        while (A.poll(&q)) { got.push_back(q); any = true; }
        if (any) A.release();
        c.t.run(2);
    }
    CHECK_EQ(got.size(), 6u);
    for (uint32_t i = 0; i < got.size(); ++i) { CHECK_EQ(got[i].cmd_id, 100 + i); CHECK_ST(got[i], SFX_ST_OK); }
    CHECK_EQ(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_EXPIRED, 0u);
}

TEST(disable_with_full_cq_completes_and_never_deadlocks) {
    EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 1;
    Env e(c.t, o);
    Queue& Q = e.q();
    for (uint32_t i = 0; i < 5; ++i) CHECK(Q.submit(cmd::nop(i)));
    Q.ring();
    WAIT_REG(c.t, SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), 2u);  // CQ full, three commands still unfetched
    CHECK(e.dev.disable_queue(0));
    CHECK_EQ(e.qreg(0, SFX_R_Q_STATUS) & SFX_QSTAT_STATE_MASK, uint32_t(SFX_QS_DISABLED));
    // the two published completions are still readable and intact
    sfx_cqe_t q;
    CHECK(Q.poll(&q)); CHECK_EQ(q.cmd_id, 0u);
    CHECK(Q.poll(&q)); CHECK_EQ(q.cmd_id, 1u);
    CHECK(!Q.poll(&q));
    e.wait_idle();

    // slow kernels in flight when the queue is disabled: it must still drain and reach DISABLED
    auto tp = c.fresh();
    Target& t2 = *tp;
    Env e2(t2, o);
    DBuf k = e2.dev_buf(64);
    t2.kernel_hook = [](const KernelReq&) { KernelResult x; x.latency = 3000; return x; };
    e2.q().submit(cmd::kernel(1, k.addr, DevAddr(0), 0));
    e2.q().submit(cmd::kernel(2, k.addr, DevAddr(0), 0));
    e2.q().ring();
    CHECK(e2.dev.disable_queue(0));
    CHECK_EQ(e2.qreg(0, SFX_R_Q_STATUS) & SFX_QSTAT_STATE_MASK, uint32_t(SFX_QS_DISABLED));
    e2.wait_idle();
}

TEST(doorbell_page_errors_do_not_raise_dev_err) {
    Env e(c.t);
    Target& t = c.t;
    Queue& Q = e.q();
    e.dev.irq_enable(SFX_IRQ_DEV_ERR);
    const unsigned misc_vec = e.rd(SFX_R_IRQ_MISC_VECTOR);
    e.clear_err();
    t.wr32(SFX_R_IRQ_STATUS, 0xFFFFFFFFu);

    // an untrusted queue owner writes garbage doorbells and pokes the rest of its doorbell page
    Q.ring_value(Q.sq_tail() + 1000);                          // over capacity
    Q.ring_value(Q.sq_tail() + 0x80000000u);                   // "backwards"
    t.wr32(SFX_DB_REG(0, SFX_R_DB_SQ_TAIL) + 8, 1);            // reserved offset inside its page
    t.wr32(SFX_DB_REG(0, SFX_R_DB_CQ_HEAD), 5);                // beyond the CQ tail
    settle(t, 200);
    CHECK(e.err_status() & SFX_ERR_BAD_DOORBELL);              // recorded ...
    CHECK(e.err_status() & SFX_ERR_BAD_REG_ACCESS);
    CHECK_EQ(e.rd(SFX_R_IRQ_STATUS) & SFX_IRQ_DEV_ERR, 0u);    // ... but no kernel-visible interrupt
    CHECK(!t.irq_level(misc_vec));
    CHECK_GT(e.rd(SFX_R_ERR_COUNT), 0u);

    // the same bits set through the (privileged) control page still raise DEV_ERR
    e.clear_err();
    t.wr32(SFX_R_ID, 0);                                       // write to a read-only register
    settle(t, 50);
    CHECK(e.rd(SFX_R_IRQ_STATUS) & SFX_IRQ_DEV_ERR);
    CHECK(t.irq_level(misc_vec));
    t.wr32(SFX_R_IRQ_STATUS, SFX_IRQ_DEV_ERR);
}

TEST(irq_coalescing_state_cleared_when_queue_disabled) {
    EnvOpts o; o.irq_coal = (100u << 16);                      // timer only: 100 units, far longer than the test's setup
    Env e(c.t, o);
    Queue& Q = e.q();
    const uint32_t qcpl0 = 1u << SFX_IRQ_QCPL_LSB;
    e.dev.irq_enable(qcpl0);
    CHECK(Q.submit(cmd::nop(1)));
    Q.ring();
    WAIT_REG(c.t, SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), 1u);          // a completion is announced-later: the timer is running
    CHECK_EQ(e.rd(SFX_R_IRQ_STATUS) & qcpl0, 0u);

    // disable and recreate the queue before the timer could expire
    CHECK(e.dev.disable_queue(0));
    e.dev.destroy_queue(e.qh[0]);
    QueueConfig cfg;
    cfg.domain = 1; cfg.sq_log2 = 4; cfg.cq_log2 = 4;
    QueueHandle nh;
    CHECK(e.dev.create_queue(0, cfg, &nh));
    c.t.wr32(SFX_Q_REG(0, SFX_R_Q_IRQ_COAL), 100u << 16);
    e.qh[0] = nh;
    e.qu[0] = std::make_unique<Queue>(e.dev.make_queue(c.t, nh));
    c.t.wr32(SFX_R_IRQ_STATUS, 0xFFFFFFFFu);

    // no completion has happened on the new queue: nothing may ever be announced, however long we wait
    settle(c.t, 60000);                                        // > 2x the original timer
    CHECK_EQ(e.rd(SFX_R_IRQ_STATUS) & qcpl0, 0u);
    CHECK(!c.t.irq_level(0));
    // and the queue works normally afterwards
    auto r = e.exec(0, {cmd::nop(9, SFX_F_IRQ)});
    CHECK_ST(r[0], SFX_ST_OK);
    WAIT(c.t, (e.rd(SFX_R_IRQ_STATUS) & qcpl0) != 0);
}
