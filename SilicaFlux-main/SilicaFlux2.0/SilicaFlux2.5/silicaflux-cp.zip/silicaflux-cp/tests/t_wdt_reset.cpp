// Watchdog (SPEC 12) and controlled reset (SPEC 13).
#include "test_util.hpp"

using namespace sfxt;

namespace {
uint32_t count_visible(Queue& q) {
    uint32_t n = 0;
    sfx_cqe_t c;
    while (q.poll(&c)) ++n;
    return n;
}
const uint32_t RST_KEY_REQ = (SFX_RESET_KEY << SFX_RST_KEY_LSB) | SFX_RST_REQ;
}  // namespace

// ------------------------------------------------------------------------------ watchdog ----
TEST(wdt_enable_rules_and_idle) {
    Target& t = c.t;
    Env e(t);
    e.clear_err();
    t.wr32(SFX_R_WDT_CTRL, SFX_WDT_CTRL_ENABLE);       // timeout still 0: refused
    CHECK(e.err_status() & SFX_ERR_BAD_REG_ACCESS);
    CHECK_EQ(e.rd(SFX_R_WDT_CTRL) & SFX_WDT_CTRL_ENABLE, 0u);
    CHECK_EQ(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_ENABLED, 0u);
    e.clear_err();
    e.dev.wdt_enable(5000);
    CHECK_EQ(e.err_status(), 0u);
    CHECK_EQ(e.rd(SFX_R_WDT_TIMEOUT), 5000u);
    CHECK(e.rd(SFX_R_WDT_CTRL) & SFX_WDT_CTRL_ENABLE);
    CHECK(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_ENABLED);
    // an idle device is never armed and never expires, however long it sits there
    e.wait_idle();
    settle(t, 30000);
    uint32_t st = e.rd(SFX_R_WDT_STATUS);
    CHECK_EQ(st & SFX_WDT_ST_ARMED, 0u);
    CHECK_EQ(st & SFX_WDT_ST_EXPIRED, 0u);
    CHECK_EQ(e.rd(SFX_R_WDT_COUNT), 0u);
    CHECK_EQ(e.status() & SFX_STATUS_FAULT, 0u);
}

TEST(wdt_expiry_hung_kernel_and_recovery) {
    Target& t = c.t;
    Env e(t);
    DBuf k = e.dev_buf(64);
    t.kernel_hook = [](const KernelReq& r) { KernelResult x; x.hang = r.cmd_id == 1; return x; };
    t.wr32(SFX_R_IRQ_MISC_VECTOR, 0);
    e.dev.irq_enable(SFX_IRQ_WDT);
    unsigned rises = 0;
    t.on_irq_rise = [&](unsigned) { ++rises; };
    e.dev.wdt_enable(4000);
    e.q().submit(cmd::kernel(1, k.addr, DevAddr(0), 0));   // never finishes by itself
    e.q().submit(cmd::nop(2));                              // issued behind it
    e.q().ring();
    WAIT(t, e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_ARMED);    // outstanding work: the timer runs
    WAIT(t, e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_EXPIRED);
    uint32_t ws = e.rd(SFX_R_WDT_STATUS);
    CHECK(ws & SFX_WDT_STUCK_KERNEL);
    CHECK_EQ(ws >> SFX_WDT_COUNT_LSB, 1u);
    uint32_t st = e.status();
    CHECK(st & SFX_STATUS_FAULT);
    CHECK_EQ(st & SFX_STATUS_RUNNING, 0u);
    CHECK(e.rd(SFX_R_FAULT_CAUSE) & SFX_FAULT_WDT);
    WAIT(t, e.dev.irq_status() & SFX_IRQ_WDT);
    WAIT(t, rises >= 1);
    // the kernel was aborted and completes as TIMEOUT; completions are still published (in order).
    // The NOP behind it was issued before the fault only if a second in-flight slot existed.
    const bool nop_issued = t.geometry().inflight_depth >= 2;
    auto r = e.collect(0, nop_issued ? 2 : 1);
    CHECK_EQ(r[0].cmd_id, 1u); CHECK_ST(r[0], SFX_ST_TIMEOUT);
    if (nop_issued) { CHECK_EQ(r[1].cmd_id, 2u); CHECK_ST(r[1], SFX_ST_OK); }
    // while FAULT nothing new is fetched or issued
    uint32_t head = e.qreg(0, SFX_R_Q_SQ_HEAD);
    e.q().submit(cmd::nop(3));
    e.q().ring();
    settle(t, 20000);
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_HEAD), head);
    sfx_cqe_t q;
    CHECK(!e.q().poll(&q));
    // EXPIRED is W1C; the FAULT state is not
    t.wr32(SFX_R_WDT_STATUS, SFX_WDT_ST_EXPIRED);
    CHECK_EQ(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_EXPIRED, 0u);
    CHECK(e.status() & SFX_STATUS_FAULT);
    // only a controlled reset leaves FAULT
    uint32_t rs = e.dev.controlled_reset();
    CHECK(rs & SFX_RST_ST_DONE);
    CHECK_EQ(rs & SFX_RST_ST_DRAIN_TIMEOUT, 0u);
    CHECK_EQ(e.status() & SFX_STATUS_FAULT, 0u);
    CHECK_EQ(e.rd(SFX_R_FAULT_CAUSE), 0u);
    CHECK_EQ(e.rd(SFX_R_WDT_CTRL), 0u);
    CHECK_EQ(e.rd(SFX_R_WDT_STATUS), 0u);
    t.kernel_hook = nullptr;
    e.reinit();
    CHECK_ST(e.exec1(0, cmd::nop(10)), SFX_ST_OK);
    CHECK_ST(e.exec1(0, cmd::kernel(11, e.dev_buf(64).addr, DevAddr(0), 0)), SFX_ST_OK);
    t.on_irq_rise = nullptr;
}

TEST(wdt_no_false_expiry_progressing_copy) {
    Target& t = c.t;
    Env e(t);
    const uint32_t A = e.align();
    const uint32_t len = 524288 / A * A;
    HBuf h = e.host_buf(len);
    DBuf d = e.dev_buf(len);
    fill_pattern(h.p, len, 21);
    e.dev.wdt_enable(3000);
    // long but steadily progressing: many bursts, each far apart from the timeout
    CHECK_ST(e.exec1(0, cmd::copy_h2d(1, h.iova, d.addr, len)), SFX_ST_OK);
    CHECK(std::memcmp(h.p, d.p, len) == 0);
    CHECK_EQ(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_EXPIRED, 0u);
    CHECK_EQ(e.status() & SFX_STATUS_FAULT, 0u);
}

TEST(wdt_heartbeat_keeps_long_kernel_alive) {
    for (bool beat : {true, false}) {
        auto tp = c.fresh();
        Target& t = *tp;
        Env e(t);
        DBuf k = e.dev_buf(64);
        t.kernel_hook = [beat](const KernelReq&) {
            KernelResult x;
            x.latency = 20000;
            x.heartbeat_period = beat ? 500 : 0;
            return x;
        };
        e.dev.wdt_enable(3000);
        e.q().submit(cmd::kernel(1, k.addr, DevAddr(0), 0));
        e.q().ring();
        if (beat) {
            auto r = e.collect(0, 1);
            CHECK_ST(r[0], SFX_ST_OK);
            CHECK_EQ(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_EXPIRED, 0u);
            CHECK_EQ(e.status() & SFX_STATUS_FAULT, 0u);
        } else {
            WAIT(t, e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_EXPIRED);  // silent long kernel: indistinguishable from hung
            auto r = e.collect(0, 1);
            CHECK_ST(r[0], SFX_ST_TIMEOUT);
        }
    }
}

// Waiting for the HOST to drain a full CQ is not a device hang.
TEST(wdt_disarmed_while_cq_full) {
    Target& t = c.t;
    EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 1;
    Env e(t, o);
    e.dev.wdt_enable(3000);
    for (uint32_t i = 0; i < 6; ++i) CHECK(e.q().submit(cmd::nop(i)));
    e.q().ring();
    WAIT_REG(t, SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), 2u);    // CQ (2 entries) full, no release
    settle(t, 40000);                                   // >> the timeout
    CHECK_EQ(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_EXPIRED, 0u);
    CHECK_EQ(e.status() & SFX_STATUS_FAULT, 0u);
    CHECK_EQ(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_ARMED, 0u);
    std::vector<sfx_cqe_t> all;
    sfx_cqe_t q;
    while (e.q().poll(&q)) all.push_back(q);
    e.q().release();
    WAIT(t, [&] { while (e.q().poll(&q)) { all.push_back(q); e.q().release(); } return all.size() == 6; }());
    for (uint32_t i = 0; i < 6; ++i) { CHECK_EQ(all[i].cmd_id, i); CHECK_ST(all[i], SFX_ST_OK); }
    CHECK_EQ(e.rd(SFX_R_WDT_STATUS) & SFX_WDT_ST_EXPIRED, 0u);
}

// ------------------------------------------------------------------------------ reset -------
TEST(reset_with_outstanding_work) {
    Target& t = c.t;
    const Geometry& g = t.geometry();
    EnvOpts o; o.sq_log2 = 5; o.cq_log2 = 5;
    Env e(t, o);
    const uint32_t A = e.align();
    const uint32_t len = 65536 / A * A, pad = 256;
    HBuf h = e.host_buf(len);
    DBuf d = e.dev_buf(len + 2 * pad), k = e.dev_buf(64);
    fill_pattern(h.p, len, 31);
    std::memset(d.p, 0xC5, len + 2 * pad);
    t.kernel_hook = [](const KernelReq&) { KernelResult x; x.latency = 100000000; return x; };  // only abort ends them
    // state that must persist / must be cleared
    t.wr32(SFX_R_SCRATCH, 0xC0FFEE);
    t.wr32(SFX_R_IRQ_MISC_VECTOR, 0);
    e.dev.irq_enable(SFX_IRQ_RESET_DONE);
    t.wr32(SFX_R_RESET_TIMEOUT, 400000);
    unsigned rises = 0;
    t.on_irq_rise = [&](unsigned) { ++rises; };
    t.wr32(SFX_R_ID, 1);                                // leaves ERR_STATUS / ERR_COUNT non-zero
    // a copy in flight, two kernels running, and NOPs queued up behind them
    const uint32_t N = 12;
    e.q().submit(cmd::copy_h2d(1, h.iova, DevAddr(d.addr.v + pad), len));
    e.q().submit(cmd::kernel(2, k.addr, DevAddr(0), 0));
    e.q().submit(cmd::kernel(3, k.addr, DevAddr(0), 0));
    for (uint32_t i = 4; i <= N; ++i) e.q().submit(cmd::nop(i));
    e.q().ring();
    WAIT(t, t.host.touched(h.iova.v, h.iova.v + len, 1));
    const unsigned depth = g.inflight_depth;
    const size_t want_kernels = depth >= 3 ? 2 : (depth == 2 ? 1 : 0);   // what fits behind the copy
    WAIT(t, t.kernels_launched.size() >= want_kernels);
    const size_t launched = t.kernels_launched.size();

    uint32_t rs = e.dev.controlled_reset(4000000);
    CHECK(rs & SFX_RST_ST_DONE);
    CHECK_EQ(rs & SFX_RST_ST_DRAIN_TIMEOUT, 0u);
    CHECK_EQ(rs & SFX_RST_ST_BUSY, 0u);
    CHECK_EQ(rs >> SFX_RST_COUNT_LSB, 1u);

    // device state
    uint32_t st = e.status();
    CHECK(st & SFX_STATUS_READY);
    CHECK(st & SFX_STATUS_IDLE);
    CHECK_EQ(st & (SFX_STATUS_FAULT | SFX_STATUS_RESETTING | SFX_STATUS_RUNNING | SFX_STATUS_ABI_OK), 0u);
    CHECK_EQ(e.rd(SFX_R_CTRL), 0u);
    for (unsigned w = 0; w < g.num_windows; ++w) CHECK_EQ(e.rd(SFX_WIN_REG(w, SFX_R_W_CTRL)) & SFX_WIN_VALID, 0u);
    for (unsigned q = 0; q < g.num_queues; ++q) {
        CHECK_EQ(e.qreg(q, SFX_R_Q_STATUS) & SFX_QSTAT_STATE_MASK, uint32_t(SFX_QS_DISABLED));
        for (uint32_t reg : {SFX_R_Q_SQ_BASE_LO, SFX_R_Q_CQ_BASE_LO, SFX_R_Q_SIZE, SFX_R_Q_SEQ_START, SFX_R_Q_SQ_HEAD,
                             SFX_R_Q_SQ_TAIL, SFX_R_Q_CQ_HEAD, SFX_R_Q_CQ_TAIL, SFX_R_Q_CMDS_OK, SFX_R_Q_CMDS_ERR, SFX_R_Q_IRQ_COAL})
            CHECK_EQ(e.qreg(q, reg), 0u);
    }
    // persistent registers survive, everything else is back to reset values
    CHECK_EQ(e.rd(SFX_R_SCRATCH), 0xC0FFEEu);
    CHECK_EQ(e.rd(SFX_R_IRQ_ENABLE), uint32_t(SFX_IRQ_RESET_DONE));
    CHECK_EQ(e.rd(SFX_R_IRQ_MISC_VECTOR), 0u);
    CHECK_EQ(e.rd(SFX_R_RESET_TIMEOUT), 400000u);
    CHECK_EQ(e.rd(SFX_R_ABI_REQ), 0u);
    CHECK_EQ(e.err_status(), 0u);
    for (uint32_t reg : {SFX_R_ERR_COUNT, SFX_R_DUP_DB_COUNT, SFX_R_CMDS_OK, SFX_R_CMDS_ERR, SFX_R_FAULT_ADDR_LO,
                         SFX_R_FAULT_ADDR_HI, SFX_R_FAULT_INFO, SFX_R_FAULT_CAUSE, SFX_R_WDT_CTRL, SFX_R_WDT_TIMEOUT})
        CHECK_EQ(e.rd(reg), 0u);
    CHECK_EQ(e.rd(SFX_R_IRQ_STATUS), uint32_t(SFX_IRQ_RESET_DONE));   // only the reset-done cause
    WAIT(t, rises >= 1);                                               // ... which interrupts

    // snapshot: published <= consumed <= submitted, and it matches what the host can see
    CHECK_EQ(e.qreg(0, SFX_R_Q_RST_SQ_TAIL), N);
    uint32_t sq_head = e.qreg(0, SFX_R_Q_RST_SQ_HEAD), cq_tail = e.qreg(0, SFX_R_Q_RST_CQ_TAIL);
    CHECK_LE(cq_tail, sq_head);
    CHECK_LE(sq_head, N);
    CHECK_GE(sq_head, std::min(depth, 3u));                            // copy (and kernels) were consumed
    const QueueHandle& h0 = e.qh[0];
    std::vector<uint8_t> ring_snap(h0.cq.size);
    std::memcpy(ring_snap.data(), h0.cq.cpu, h0.cq.size);
    uint32_t visible = count_visible(e.q());
    CHECK_EQ(visible, cq_tail);
    // abandoned work never completes: run a long time and the CQ ring does not change
    settle(t, 50000);
    CHECK(std::memcmp(ring_snap.data(), h0.cq.cpu, h0.cq.size) == 0);
    CHECK_EQ(t.kernels_launched.size(), launched);                     // nothing new was issued
    // the destination was never touched outside [dst, dst+len)
    for (uint32_t i = 0; i < pad; ++i) CHECK_EQ(d.p[i], 0xC5);
    for (uint32_t i = pad + len; i < len + 2 * pad; ++i) CHECK_EQ(d.p[i], 0xC5);

    // the device is fully usable again after re-initialisation
    t.kernel_hook = nullptr;
    e.reinit();
    HBuf h2 = e.host_buf(4096), h3 = e.host_buf(4096);
    DBuf d2 = e.dev_buf(4096), k2 = e.dev_buf(64);   // new buffers: the old arena's windows are gone
    fill_pattern(h2.p, 4096, 77);
    auto r = e.exec(0, {cmd::copy_h2d(21, h2.iova, d2.addr, 4096, 0), cmd::copy_d2h(22, d2.addr, h3.iova, 4096, SFX_F_FENCE_BEFORE),
                        cmd::kernel(23, k2.addr, DevAddr(0), 0)});
    CHECK_EQ(r.size(), 3u);
    CHECK_EQ(r[0].cq_seq, 0u);                       // counters restarted from the new SEQ_START
    CHECK_EQ(r[0].sq_seq, 0u);
    for (auto& q : r) CHECK_ST(q, SFX_ST_OK);
    CHECK(std::memcmp(h2.p, h3.p, 4096) == 0);
    // a second reset (now with the device idle) counts again
    rs = e.dev.controlled_reset();
    CHECK(rs & SFX_RST_ST_DONE);
    CHECK_EQ(rs >> SFX_RST_COUNT_LSB, 2u);
    t.on_irq_rise = nullptr;
}

TEST(reset_wrong_key_and_variants) {
    Target& t = c.t;
    Env e(t);
    e.clear_err();
    t.wr32(SFX_R_RESET_CTRL, (0xBEEFu << SFX_RST_KEY_LSB) | SFX_RST_REQ);   // wrong key: ignored
    CHECK(e.err_status() & SFX_ERR_BAD_REG_ACCESS);
    settle(t, 3000);
    CHECK_EQ(e.rd(SFX_R_RESET_STATUS), 0u);
    CHECK_EQ(e.status() & SFX_STATUS_RESETTING, 0u);
    CHECK(e.status() & SFX_STATUS_ABI_OK);                                   // nothing was reset
    t.wr32(SFX_R_RESET_CTRL, SFX_RST_REQ);                                    // no key at all
    settle(t, 3000);
    CHECK_EQ(e.rd(SFX_R_RESET_STATUS), 0u);
    t.wr32(SFX_R_RESET_CTRL, SFX_RESET_KEY << SFX_RST_KEY_LSB);              // right key, REQ clear: no reset
    settle(t, 3000);
    CHECK_EQ(e.rd(SFX_R_RESET_STATUS) >> SFX_RST_COUNT_LSB, 0u);
    CHECK(e.status() & SFX_STATUS_ABI_OK);
    // resetting an idle device works and is repeatable
    for (uint32_t n = 1; n <= 3; ++n) {
        uint32_t rs = e.dev.controlled_reset();
        CHECK(rs & SFX_RST_ST_DONE);
        CHECK_EQ(rs >> SFX_RST_COUNT_LSB, n);
        CHECK_EQ(e.rd(SFX_R_STATUS) & SFX_STATUS_ABI_OK, 0u);
    }
}

// If the bus is wedged the drain never completes: the device must stay quiesced in RESETTING,
// ignore writes, and only a hard reset recovers (SPEC 13 step 2).
TEST(reset_drain_timeout_then_hard_reset) {
    Target& t = c.t;
    Env e(t);
    const uint32_t A = e.align();
    const uint32_t len = 65536 / A * A;
    HBuf h = e.host_buf(len);
    DBuf d = e.dev_buf(len);
    fill_pattern(h.p, len, 41);
    t.wr32(SFX_R_RESET_TIMEOUT, 3000);
    t.wr32(SFX_R_SCRATCH, 0xAAAA5555);
    e.q().submit(cmd::copy_h2d(1, h.iova, d.addr, len));
    e.q().ring();
    WAIT(t, t.host.touched(h.iova.v, h.iova.v + len, 1));
    t.host.set_hang(true);                                    // the host bus stops answering mid-copy
    settle(t, 2000);
    t.wr32(SFX_R_RESET_CTRL, RST_KEY_REQ);
    WAIT(t, e.rd(SFX_R_RESET_STATUS) & SFX_RST_ST_DRAIN_TIMEOUT);
    uint32_t rs = e.rd(SFX_R_RESET_STATUS);
    CHECK(rs & SFX_RST_ST_BUSY);
    CHECK_EQ(rs & SFX_RST_ST_DONE, 0u);
    CHECK(e.status() & SFX_STATUS_RESETTING);
    // quiesced: register and doorbell writes are ignored, reads still work
    t.wr32(SFX_R_SCRATCH, 0x12345678);
    CHECK_EQ(e.rd(SFX_R_SCRATCH), 0xAAAA5555u);
    t.wr32(SFX_R_CTRL, 0);
    CHECK_EQ(e.rd(SFX_R_CTRL), uint32_t(SFX_CTRL_ENABLE));
    e.clear_err();
    uint32_t before = e.qreg(0, SFX_R_Q_SQ_TAIL);
    e.q().submit(cmd::nop(2));
    e.q().ring();
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_TAIL), before);             // doorbell ignored
    CHECK_EQ(e.err_status() & SFX_ERR_BAD_DOORBELL, 0u);       // ... silently (SPEC 6.4)
    CHECK_EQ(e.rd(SFX_R_ID), SFX_ID_VALUE);
    settle(t, 20000);
    CHECK(e.status() & SFX_STATUS_RESETTING);                  // still stuck: not a silent give-up
    // a hard (link/function-level) reset recovers: power-on state, wedged bus released
    t.hard_reset();
    CHECK_EQ(e.rd(SFX_R_RESET_STATUS), 0u);
    CHECK_EQ(e.rd(SFX_R_SCRATCH), 0u);
    CHECK_EQ(e.rd(SFX_R_IRQ_ENABLE), 0u);
    CHECK_EQ(e.rd(SFX_R_RESET_TIMEOUT), 100000u);
    CHECK_EQ(e.rd(SFX_R_CTRL), 0u);
    uint32_t st = e.status();
    CHECK(st & SFX_STATUS_READY);
    CHECK_EQ(st & (SFX_STATUS_RESETTING | SFX_STATUS_FAULT | SFX_STATUS_ABI_OK), 0u);
    CHECK_EQ(e.qreg(0, SFX_R_Q_STATUS) & SFX_QSTAT_STATE_MASK, uint32_t(SFX_QS_DISABLED));
    for (unsigned w = 0; w < t.geometry().num_windows; ++w) CHECK_EQ(e.rd(SFX_WIN_REG(w, SFX_R_W_CTRL)) & SFX_WIN_VALID, 0u);
    e.reinit();
    CHECK_ST(e.exec1(0, cmd::nop(9)), SFX_ST_OK);
    HBuf h2 = e.host_buf(4096); DBuf d2 = e.dev_buf(4096);
    fill_pattern(h2.p, 4096, 1);
    CHECK_ST(e.exec1(0, cmd::copy_h2d(10, h2.iova, d2.addr, 4096)), SFX_ST_OK);
    CHECK(std::memcmp(h2.p, d2.p, 4096) == 0);
}

// Reset at arbitrary moments - including in the middle of publishing a completion - must always
// leave a consistent picture: whatever completions the host can see are exactly the ones counted
// in the snapshot, in order and OK; nothing appears afterwards.
TEST(reset_at_random_moments) {
    std::mt19937_64 rng(c.seed * 7919 + 1);
    for (int iter = 0; iter < 24; ++iter) {
        auto tp = c.fresh();
        Target& t = *tp;
        EnvOpts o; o.sq_log2 = 5; o.cq_log2 = 5;
        Env e(t, o);
        const uint32_t A = e.align();
        HBuf h = e.host_buf(4096); DBuf d = e.dev_buf(4096), k = e.dev_buf(64);
        fill_pattern(h.p, 4096, iter);
        t.kernel_hook = [](const KernelReq& r) { KernelResult x; x.latency = 5 + (r.cmd_id % 4) * 40; return x; };
        const uint32_t N = 24;
        for (uint32_t i = 0; i < N; ++i) {
            switch (i % 4) {
            case 0: e.q().submit(cmd::copy_h2d(i, h.iova, d.addr, 1024 / A * A)); break;
            case 1: e.q().submit(cmd::kernel(i, k.addr, DevAddr(0), 0)); break;
            case 2: e.q().submit(cmd::nop(i, SFX_F_IRQ)); break;
            default: e.q().submit(cmd::copy_d2h(i, d.addr, Iova(h.iova.v + 2048), 512 / A * A)); break;
            }
        }
        e.q().ring();
        t.run(rng() % 700);
        uint32_t rs = e.dev.controlled_reset(4000000);
        std::string label = "iter " + std::to_string(iter);
        CHECK_MSG(rs & SFX_RST_ST_DONE, label);
        CHECK_MSG(!(rs & SFX_RST_ST_DRAIN_TIMEOUT), label);
        uint32_t sq_tail = e.qreg(0, SFX_R_Q_RST_SQ_TAIL), sq_head = e.qreg(0, SFX_R_Q_RST_SQ_HEAD),
                 cq_tail = e.qreg(0, SFX_R_Q_RST_CQ_TAIL);
        CHECK_MSG(sq_tail == N, label);
        CHECK_MSG(cq_tail <= sq_head && sq_head <= sq_tail, label);
        std::vector<sfx_cqe_t> seen;
        sfx_cqe_t q;
        while (e.q().poll(&q)) seen.push_back(q);
        CHECK_MSG(seen.size() == cq_tail, label);
        for (uint32_t i = 0; i < seen.size(); ++i) {
            CHECK_MSG(seen[i].cmd_id == i && seen[i].cq_seq == i, label);
            CHECK_MSG(seen[i].status == SFX_ST_OK, label);    // aborted work is never reported as completed
        }
        std::vector<uint8_t> snap(e.qh[0].cq.size);
        std::memcpy(snap.data(), e.qh[0].cq.cpu, snap.size());
        settle(t, 3000);
        CHECK_MSG(std::memcmp(snap.data(), e.qh[0].cq.cpu, snap.size()) == 0, label);
        CHECK_MSG(e.status() & SFX_STATUS_IDLE, label);
    }
}
