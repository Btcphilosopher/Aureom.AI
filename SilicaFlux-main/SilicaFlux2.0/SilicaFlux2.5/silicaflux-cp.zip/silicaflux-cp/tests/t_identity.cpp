// Identity, versioning, register access rules, ABI negotiation, DMA window programming.
#include "test_util.hpp"

using namespace sfxt;

TEST(identity_regs) {
    Target& t = c.t;
    const Geometry& g = t.geometry();
    CHECK_EQ(t.rd32(SFX_R_ID), SFX_ID_VALUE);
    uint32_t ver = t.rd32(SFX_R_VERSION);
    CHECK_EQ(ver >> 24, SFX_ABI_MAJOR);
    CHECK_EQ((ver >> 16) & 0xFF, SFX_ABI_MINOR);
    uint32_t caps = t.rd32(SFX_R_CAPS);
    uint32_t need = SFX_CAP_KERNEL | SFX_CAP_COPY_H2D | SFX_CAP_COPY_D2H | SFX_CAP_COPY_D2D | SFX_CAP_FENCE |
                    SFX_CAP_FENCE_SIGNAL | SFX_CAP_IRQ_COALESCE | SFX_CAP_WATCHDOG | SFX_CAP_SOFT_RESET |
                    SFX_CAP_WINDOW_AUTHZ | SFX_CAP_SEQ_START;
    CHECK_EQ(caps & need, need);
    uint32_t geo = t.rd32(SFX_R_GEOMETRY);
    CHECK_EQ(geo & 0xF, g.num_queues);
    CHECK_EQ((geo >> 8) & 0xFF, g.num_windows);
    CHECK_EQ((geo >> 16) & 0xF, g.num_queues + 1);  // NUM_VECTORS = NUM_QUEUES + 1
    CHECK_EQ((geo >> 24) & 0xF, g.inflight_depth);
    uint32_t lim = t.rd32(SFX_R_LIMITS);
    CHECK_EQ(lim & 0xFF, SFX_MAX_RING_LOG2);
    CHECK_EQ(1u << ((lim >> 8) & 0xFF), g.dma_align);
    CHECK_EQ((lim >> 16) & 0xFF, SFX_DESC_LOG2);
    CHECK_EQ((lim >> 24) & 0xFF, SFX_CQE_LOG2);
    CHECK_EQ(t.rd32(SFX_R_MAX_COPY), SFX_MAX_COPY_BYTES);
    uint64_t dm = t.rd32(SFX_R_DEVMEM_LO) | (uint64_t(t.rd32(SFX_R_DEVMEM_HI)) << 32);
    CHECK_EQ(dm, t.dev.size());
    CHECK_EQ(t.rd32(SFX_R_HOST_ADDR_BITS), g.host_addr_bits);
    CHECK((t.rd32(SFX_R_DESC_VERSIONS) >> SFX_DESC_VERSION) & 1);
    uint32_t l2 = t.rd32(SFX_R_LIMITS2);
    CHECK_EQ(l2 & 0xFFFF, SFX_MAX_ARGS_BYTES);
    CHECK_EQ(l2 >> 16, SFX_MAX_GRID_DIM);
    // power-on state
    uint32_t st = t.rd32(SFX_R_STATUS);
    CHECK(st & SFX_STATUS_READY);
    CHECK(!(st & SFX_STATUS_RUNNING));
    CHECK(!(st & SFX_STATUS_FAULT));
    CHECK(!(st & SFX_STATUS_RESETTING));
    CHECK(st & SFX_STATUS_IDLE);
    CHECK(!(st & SFX_STATUS_ABI_OK));
    CHECK_EQ(t.rd32(SFX_R_ERR_STATUS), 0u);
    CHECK_EQ(t.rd32(SFX_R_IRQ_STATUS), 0u);
    CHECK_EQ(t.rd32(SFX_R_IRQ_MISC_VECTOR), g.num_queues);
    for (unsigned q = 0; q < g.num_queues; ++q) {
        CHECK_EQ(t.rd32(SFX_Q_REG(q, SFX_R_Q_STATUS)), uint32_t(SFX_QS_DISABLED));
        CHECK_LT(t.rd32(SFX_Q_REG(q, SFX_R_Q_VECTOR)), g.num_queues + 1);  // some valid vector
    }
    for (unsigned w = 0; w < g.num_windows; ++w)
        CHECK_EQ(t.rd32(SFX_WIN_REG(w, SFX_R_W_CTRL)) & SFX_WIN_VALID, 0u);
}

TEST(reg_access_rules) {
    Target& t = c.t;
    const Geometry& g = t.geometry();
    // reserved / unmapped reads return 0 with no side effect
    for (uint32_t off : {0x0A0u, 0x0F0u, 0x300u, 0x3FCu, 0x7F0u, 0xFFCu, 0x2FF0u}) {
        CHECK_EQ(t.rd32(off), 0u);
    }
    CHECK_EQ(t.rd32(SFX_R_ERR_STATUS), 0u);

    // SCRATCH is plain RW
    t.wr32(SFX_R_SCRATCH, 0xDEADBEEF);
    CHECK_EQ(t.rd32(SFX_R_SCRATCH), 0xDEADBEEFu);
    CHECK_EQ(t.rd32(SFX_R_ERR_STATUS), 0u);

    // write to a read-only register: ignored + ERR_BAD_REG_ACCESS + count + DEV_ERR cause
    uint32_t cnt0 = t.rd32(SFX_R_ERR_COUNT);
    t.wr32(SFX_R_ID, 0x12345678);
    CHECK_EQ(t.rd32(SFX_R_ID), SFX_ID_VALUE);
    CHECK(t.rd32(SFX_R_ERR_STATUS) & SFX_ERR_BAD_REG_ACCESS);
    CHECK_EQ(t.rd32(SFX_R_ERR_COUNT), cnt0 + 1);
    CHECK(t.rd32(SFX_R_IRQ_STATUS) & SFX_IRQ_DEV_ERR);
    // every further bad write counts, even though the sticky bit is already set
    t.wr32(SFX_R_VERSION, 0);
    t.wr32(SFX_R_CAPS, 0);
    CHECK_EQ(t.rd32(SFX_R_ERR_COUNT), cnt0 + 3);

    // write to unmapped space
    t.wr32(0x0A0, 1);
    t.wr32(0x7F0, 1);
    t.wr32(0x1008, 1);  // reserved offset inside a doorbell page
    CHECK_EQ(t.rd32(0x1008), 0u);
    CHECK_EQ(t.rd32(SFX_R_ERR_COUNT), cnt0 + 6);

    // write to a window / queue slot beyond the implemented ones
    t.wr32(SFX_WIN_REG(g.num_windows, SFX_R_W_BASE_LO), 0x1000);
    CHECK_EQ(t.rd32(SFX_WIN_REG(g.num_windows, SFX_R_W_BASE_LO)), 0u);
    CHECK_EQ(t.rd32(SFX_R_ERR_COUNT), cnt0 + 7);
    if (g.num_queues < SFX_MAX_QUEUES) {
        t.wr32(SFX_Q_REG(g.num_queues, SFX_R_Q_CTRL), 1);
        CHECK_EQ(t.rd32(SFX_Q_REG(g.num_queues, SFX_R_Q_STATUS)), 0u);
        t.wr32(SFX_DB_REG(g.num_queues, SFX_R_DB_SQ_TAIL), 1);
        CHECK_EQ(t.rd32(SFX_R_ERR_COUNT), cnt0 + 9);
    }

    // W1C of the sticky bits
    t.wr32(SFX_R_ERR_STATUS, SFX_ERR_BAD_REG_ACCESS);
    CHECK_EQ(t.rd32(SFX_R_ERR_STATUS) & SFX_ERR_BAD_REG_ACCESS, 0u);
    // write-only registers read as zero
    t.wr32(SFX_R_IRQ_FORCE, 0);
    CHECK_EQ(t.rd32(SFX_R_IRQ_FORCE), 0u);
    CHECK_EQ(t.rd32(SFX_R_RESET_CTRL), 0u);
}

TEST(abi_negotiation) {
    Target& t = c.t;
    EnvOpts o;
    o.create_queues = false;
    Env e(t, o);
    CHECK(t.rd32(SFX_R_STATUS) & SFX_STATUS_ABI_OK);  // Env negotiated 1.0

    QueueConfig cfg;
    cfg.domain = 1; cfg.sq_log2 = 3; cfg.cq_log2 = 3;
    struct Case { uint32_t req; bool ok; const char* what; };
    const Case cases[] = {
        {0x00000000u, false, "no ABI requested"},
        {(SFX_ABI_MAJOR + 1) << 16, false, "wrong major"},
        {((SFX_ABI_MAJOR - 1) << 16) | 0, false, "older major"},
        {(SFX_ABI_MAJOR << 16) | (SFX_ABI_MINOR + 1), false, "minor newer than the device"},
        {(SFX_ABI_MAJOR << 16) | SFX_ABI_MINOR, true, "exact version"},
    };
    for (const Case& k : cases) {
        t.wr32(SFX_R_ABI_REQ, k.req);
        CHECK_EQ(t.rd32(SFX_R_ABI_REQ), k.req);
        CHECK_EQ(bool(t.rd32(SFX_R_STATUS) & SFX_STATUS_ABI_OK), k.ok);
        e.clear_err();
        QueueHandle h;
        bool ok = e.dev.create_queue(0, cfg, &h);
        CHECK_MSG(ok == k.ok, k.what);
        if (!k.ok) {
            CHECK_EQ(h.state, uint32_t(SFX_QS_ERROR));
            CHECK_EQ(h.err, uint32_t(SFX_QERR_BAD_CONFIG));
            CHECK(e.err_status() & SFX_ERR_BAD_QCONFIG);
            CHECK(t.rd32(SFX_R_IRQ_STATUS) & (1u << (SFX_IRQ_QERR_LSB + 0)));
        }
        // back to DISABLED for the next round
        CHECK(e.dev.disable_queue(0));
        e.dev.destroy_queue(h);
    }
}

TEST(window_commit_validation) {
    Target& t = c.t;
    EnvOpts o;
    o.create_queues = false;
    o.arenas = false;
    Env e(t, o);
    const Geometry& g = t.geometry();
    const uint32_t A = g.dma_align;
    const uint64_t host_lim = 1ull << g.host_addr_bits;
    const uint64_t dev_lim = t.dev.size();

    auto program = [&](unsigned w, uint64_t base, uint64_t size, uint32_t ctrl) {
        t.wr32(SFX_WIN_REG(w, SFX_R_W_BASE_LO), uint32_t(base));
        t.wr32(SFX_WIN_REG(w, SFX_R_W_BASE_HI), uint32_t(base >> 32));
        t.wr32(SFX_WIN_REG(w, SFX_R_W_SIZE_LO), uint32_t(size));
        t.wr32(SFX_WIN_REG(w, SFX_R_W_SIZE_HI), uint32_t(size >> 32));
        t.wr32(SFX_WIN_REG(w, SFX_R_W_CTRL), ctrl);
        return t.rd32(SFX_WIN_REG(w, SFX_R_W_CTRL));
    };
    const uint32_t HRW = SFX_WIN_VALID | SFX_WIN_R | SFX_WIN_W | (1u << SFX_WIN_DOM_LSB);
    const uint32_t DRW = HRW | SFX_WIN_SPACE;
    struct Bad { const char* what; uint64_t base, size; uint32_t ctrl; };
    const Bad bad[] = {
        {"size zero", 0x10000, 0, HRW},
        {"base unaligned", 0x10000 + 1, 4096, HRW},
        {"size unaligned", 0x10000, 4096 + 1, HRW},
        {"base+size wraps 2^64", 0xFFFFFFFFFFFFF000ull, 0x2000, HRW},
        {"host beyond address bits", host_lim - 0x1000, 0x2000, HRW},
        {"host base beyond address bits", host_lim, 0x1000, HRW},
        {"dev beyond device memory", dev_lim - 0x1000, 0x2000, DRW},
        {"neither R nor W", 0x10000, 4096, SFX_WIN_VALID | (1u << SFX_WIN_DOM_LSB)},
    };
    for (const Bad& b : bad) {
        e.clear_err();
        uint32_t ctrl = program(0, b.base, b.size, b.ctrl);
        CHECK_MSG(!(ctrl & SFX_WIN_VALID), b.what);
        CHECK_MSG(ctrl & SFX_WIN_ERR, b.what);
        CHECK_MSG(e.err_status() & SFX_ERR_BAD_WINDOW, b.what);
    }
    // a good commit clears ERR and reads back its attributes
    e.clear_err();
    uint32_t ctrl = program(0, 0x10000, 8192, HRW);
    CHECK(ctrl & SFX_WIN_VALID);
    CHECK(!(ctrl & SFX_WIN_ERR));
    CHECK(ctrl & SFX_WIN_R);
    CHECK(ctrl & SFX_WIN_W);
    CHECK(!(ctrl & SFX_WIN_SPACE));
    CHECK_EQ((ctrl & SFX_WIN_DOM_MASK) >> SFX_WIN_DOM_LSB, 1u);
    CHECK(!(ctrl & SFX_WIN_BUSY));
    CHECK_EQ(e.err_status(), 0u);
    CHECK_EQ(t.rd32(SFX_WIN_REG(0, SFX_R_W_BASE_LO)), 0x10000u);
    CHECK_EQ(t.rd32(SFX_WIN_REG(0, SFX_R_W_SIZE_LO)), 8192u);
    // boundary-exact windows are fine (end == limit)
    ctrl = program(1, dev_lim - 4096, 4096, DRW);
    CHECK(ctrl & SFX_WIN_VALID);
    ctrl = program(2, host_lim - 4096, 4096, HRW);
    CHECK(ctrl & SFX_WIN_VALID);
    // minimum granularity
    ctrl = program(3, 0x20000, A, SFX_WIN_VALID | SFX_WIN_R);
    CHECK(ctrl & SFX_WIN_VALID);
    CHECK(!(ctrl & SFX_WIN_W));

    // lock rules: a valid window refuses reprogramming and a second commit
    e.clear_err();
    t.wr32(SFX_WIN_REG(0, SFX_R_W_BASE_LO), 0x40000);
    CHECK_EQ(t.rd32(SFX_WIN_REG(0, SFX_R_W_BASE_LO)), 0x10000u);
    CHECK(e.err_status() & SFX_ERR_CFG_LOCKED);
    e.clear_err();
    t.wr32(SFX_WIN_REG(0, SFX_R_W_SIZE_LO), 4096);
    CHECK_EQ(t.rd32(SFX_WIN_REG(0, SFX_R_W_SIZE_LO)), 8192u);
    CHECK(e.err_status() & SFX_ERR_CFG_LOCKED);
    e.clear_err();
    t.wr32(SFX_WIN_REG(0, SFX_R_W_CTRL), HRW);
    CHECK(e.err_status() & SFX_ERR_CFG_LOCKED);
    CHECK(t.rd32(SFX_WIN_REG(0, SFX_R_W_CTRL)) & SFX_WIN_VALID);  // still valid, unchanged
    CHECK_EQ(t.rd32(SFX_WIN_REG(0, SFX_R_W_BASE_LO)), 0x10000u);

    // invalidate (idle window: BUSY is clear immediately), then reprogram
    t.wr32(SFX_WIN_REG(0, SFX_R_W_CTRL), 0);
    ctrl = t.rd32(SFX_WIN_REG(0, SFX_R_W_CTRL));
    CHECK(!(ctrl & SFX_WIN_VALID));
    CHECK(!(ctrl & SFX_WIN_BUSY));
    ctrl = program(0, 0x40000, 4096, HRW);
    CHECK(ctrl & SFX_WIN_VALID);
    CHECK_EQ(t.rd32(SFX_WIN_REG(0, SFX_R_W_BASE_LO)), 0x40000u);
}
