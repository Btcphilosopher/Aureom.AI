// Test runner.  One binary, two targets:
//   --target=model   software device model (default)
//   --target=rtl     Verilated RTL (only when built with -DSFX_WITH_RTL and linked with sim/)
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "sfx_model.hpp"
#include "test_util.hpp"

#ifdef SFX_WITH_RTL
#include "rtl_target.hpp"
#endif

using namespace sfxt;

namespace {
struct Profile { const char* name; BusProfile p; };

std::vector<Profile> profiles_for(const std::string& sel) {
    BusProfile ideal;
    BusProfile stall;
    stall.ready_pct = 60; stall.valid_pct = 60; stall.latency_min = 1; stall.latency_max = 4; stall.lite_gap = 1;
    BusProfile lat;
    lat.latency_min = 8; lat.latency_max = 40; lat.lite_gap = 3;
    std::vector<Profile> v;
    if (sel == "ideal" || sel == "all") v.push_back({"ideal", ideal});
    if (sel == "stall" || sel == "all") v.push_back({"stall", stall});
    if (sel == "latency" || sel == "all") v.push_back({"latency", lat});
    return v;
}

bool starts(const char* a, const char* pre, const char** val) {
    size_t n = std::strlen(pre);
    if (std::strncmp(a, pre, n) != 0) return false;
    *val = a + n;
    return true;
}
}  // namespace

int main(int argc, char** argv) {
    std::string target = "model", filter, profile = "ideal";
    uint64_t seed = 1;
    bool list = false, digest = false, verbose = false;
    Geometry geom;
    for (int i = 1; i < argc; ++i) {
        const char* v;
        if (starts(argv[i], "--target=", &v)) target = v;
        else if (starts(argv[i], "--filter=", &v)) filter = v;
        else if (starts(argv[i], "--profile=", &v)) profile = v;
        else if (starts(argv[i], "--seed=", &v)) seed = std::strtoull(v, nullptr, 0);
        else if (starts(argv[i], "--queues=", &v)) geom.num_queues = std::atoi(v);
        else if (starts(argv[i], "--windows=", &v)) geom.num_windows = std::atoi(v);
        else if (starts(argv[i], "--depth=", &v)) geom.inflight_depth = std::atoi(v);
        else if (starts(argv[i], "--beat-bytes=", &v)) { geom.beat_bytes = std::atoi(v); geom.dma_align = geom.beat_bytes; }
        else if (!std::strcmp(argv[i], "--list")) list = true;
        else if (!std::strcmp(argv[i], "--digest")) digest = true;
        else if (!std::strcmp(argv[i], "-v")) verbose = true;
        else { std::fprintf(stderr, "unknown option %s\n", argv[i]); return 2; }
    }
    if (list) {
        for (auto& t : registry()) std::printf("%s\n", t.name);
        return 0;
    }
    bool rtl = target == "rtl";
#ifndef SFX_WITH_RTL
    if (rtl) { std::fprintf(stderr, "this binary was built without RTL support\n"); return 2; }
#endif
    if (!rtl && target != "model") { std::fprintf(stderr, "unknown target\n"); return 2; }

    std::vector<Profile> profs = rtl ? profiles_for(profile) : std::vector<Profile>{{"-", BusProfile{}}};
    if (profs.empty()) { std::fprintf(stderr, "unknown profile\n"); return 2; }

    int pass = 0, failed = 0, skipped = 0;
    for (auto& tr : registry()) {
        if (!filter.empty() && std::string(tr.name).find(filter) == std::string::npos) continue;
        for (auto& pr : profs) {
            std::unique_ptr<Target> t;
            if (rtl) {
#ifdef SFX_WITH_RTL
                t = make_rtl_target(geom);
#endif
            } else {
                t = make_model_target(geom);
            }
            BusProfile bp = pr.p;
            bp.seed = seed;
            t->set_bus_profile(bp);
            Ctx ctx{*t, seed, 0, false, nullptr};
            ctx.fresh = [&]() -> std::unique_ptr<Target> {
                std::unique_ptr<Target> n;
                if (rtl) {
#ifdef SFX_WITH_RTL
                    n = make_rtl_target(geom);
#endif
                } else {
                    n = make_model_target(geom);
                }
                BusProfile b2 = pr.p;
                b2.seed = seed;
                n->set_bus_profile(b2);
                return n;
            };
            std::string label = std::string(tr.name) + (rtl ? std::string("[") + pr.name + "]" : "");
            try {
                tr.fn(ctx);
                std::string perr = t->protocol_errors();
                if (!perr.empty()) throw TestFailure("protocol checker: " + perr);
                std::printf("PASS  %s\n", label.c_str());
                ++pass;
                if (digest && ctx.has_digest) std::printf("DIGEST %s %016llx\n", tr.name, static_cast<unsigned long long>(ctx.digest));
            } catch (const TestSkip& s) {
                std::printf("SKIP  %s  (%s)\n", label.c_str(), s.what());
                ++skipped;
            } catch (const std::exception& e) {
                std::printf("FAIL  %s\n      %s\n", label.c_str(), e.what());
                ++failed;
            }
            (void)verbose;
            std::fflush(stdout);
        }
    }
    std::printf("\n%s: %d passed, %d failed, %d skipped\n", rtl ? "rtl" : "model", pass, failed, skipped);
    return failed ? 1 : 0;
}
