// Basic command execution: NOP, copies, completion fields, completion point, two-phase CQE.
#include <array>

#include "test_util.hpp"

using namespace sfxt;

TEST(nop_basic) {
    Env e(c.t);
    sfx_cqe_t q = e.exec1(0, cmd::nop(0x1234));
    CHECK_EQ(q.cmd_id, 0x1234u);
    CHECK_ST(q, SFX_ST_OK);
    CHECK_EQ(q.opcode, uint16_t(SFX_OP_NOP));
    CHECK_EQ(q.sq_seq, 0u);
    CHECK_EQ(q.sq_head, 1u);
    CHECK_EQ(q.cq_seq, 0u);
    CHECK_EQ(q.phase_word & 1u, 1u);  // first lap => phase 1
    CHECK_EQ(q.result, 0u);
    // counters
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_HEAD), 1u);
    CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_TAIL), 1u);
    WAIT_REG(c.t, SFX_Q_REG(0, SFX_R_Q_CQ_TAIL), 1u);   // counters trail the visible completion
    WAIT_REG(c.t, SFX_Q_REG(0, SFX_R_Q_CQ_HEAD), 1u);
    WAIT_REG(c.t, SFX_Q_REG(0, SFX_R_Q_CMDS_OK), 1u);
    WAIT_REG(c.t, SFX_R_CMDS_OK, 1u);
    CHECK_EQ(e.rd(SFX_R_CMDS_ERR), 0u);
    CHECK_EQ(e.err_status(), 0u);
    e.wait_idle();
}

// Run one copy of `len` bytes from a patterned source to a canary-guarded destination.
namespace {
struct CopyCase { const char* kind; uint32_t len; uint32_t src_off, dst_off; };

struct CopyBufs {
    HBuf hsrc, hdst;
    DBuf dsrc, ddst;
    size_t cap;
    explicit CopyBufs(Env& e, size_t max_len) : cap(max_len + 8192 + 512) {
        hsrc = e.host_buf(cap, 0, 4096); hdst = e.host_buf(cap, 0, 4096);
        dsrc = e.dev_buf(cap, 0, 4096); ddst = e.dev_buf(cap, 0, 4096);
    }
};

void run_copy(Env& e, CopyBufs& b, uint64_t seed, const CopyCase& k) {
    const uint32_t pad = 256;
    const size_t span = k.len + 8192 + 2 * pad;
    if (span > b.cap) throw TestFailure("copy case larger than buffers");
    uint64_t kind = !std::strcmp(k.kind, "h2d") ? 0 : !std::strcmp(k.kind, "d2h") ? 1 : 2;
    HBuf &hsrc = b.hsrc, &hdst = b.hdst;
    DBuf &dsrc = b.dsrc, &ddst = b.ddst;
    std::vector<uint8_t> ref(k.len);
    fill_pattern(ref.data(), k.len, seed);
    // canary everywhere in the destination zone
    sfx_desc_t d;
    uint8_t* dst_base;
    uint64_t dst_addr;
    if (kind == 0) {  // host -> dev
        std::memcpy(hsrc.p + pad + k.src_off, ref.data(), k.len);
        std::memset(ddst.p, 0xC5, span);
        dst_base = ddst.p; dst_addr = ddst.addr.v;
        d = cmd::copy_h2d(7, Iova(hsrc.iova.v + pad + k.src_off), DevAddr(ddst.addr.v + pad + k.dst_off), k.len);
    } else if (kind == 1) {  // dev -> host
        std::memcpy(dsrc.p + pad + k.src_off, ref.data(), k.len);
        std::memset(hdst.p, 0xC5, span);
        dst_base = hdst.p; dst_addr = hdst.iova.v;
        d = cmd::copy_d2h(7, DevAddr(dsrc.addr.v + pad + k.src_off), Iova(hdst.iova.v + pad + k.dst_off), k.len);
    } else {  // dev -> dev
        std::memcpy(dsrc.p + pad + k.src_off, ref.data(), k.len);
        std::memset(ddst.p, 0xC5, span);
        dst_base = ddst.p; dst_addr = ddst.addr.v;
        d = cmd::copy_d2d(7, DevAddr(dsrc.addr.v + pad + k.src_off), DevAddr(ddst.addr.v + pad + k.dst_off), k.len);
    }
    (void)dst_addr;
    sfx_cqe_t q = e.exec1(0, d);
    CHECK_ST(q, SFX_ST_OK);
    CHECK_EQ(q.result, k.len);
    // data
    CHECK(std::memcmp(dst_base + pad + k.dst_off, ref.data(), k.len) == 0);
    // canaries untouched: everything outside [pad+dst_off, pad+dst_off+len)
    for (size_t i = 0; i < span; ++i) {
        if (i >= size_t(pad + k.dst_off) && i < size_t(pad + k.dst_off + k.len)) continue;
        if (dst_base[i] != 0xC5) fail(__FILE__, __LINE__, std::string(k.kind) + " len=" + std::to_string(k.len) +
                                      ": canary overwritten at +" + std::to_string(i));
    }
}
}  // namespace

TEST(copy_integrity) {
    Env e(c.t);
    const uint32_t A = e.align();
    const Geometry& g = c.t.geometry();
    const uint32_t burst = g.max_burst_beats * g.beat_bytes;
    std::vector<uint32_t> sizes = {A, 2 * A, 3 * A, 5 * A, burst - A, burst, burst + A, 2 * burst + 3 * A,
                                   4096 - A, 4096, 4096 + A, 7 * 4096 / A * A + A, 9000 / A * A, 65536};
    const char* kinds[] = {"h2d", "d2h", "d2d"};
    std::mt19937_64 rng(c.seed);
    CopyBufs b(e, 65536);
    for (const char* kind : kinds) {
        for (uint32_t len : sizes) {
            if (len == 0 || len % A) continue;
            // offsets chosen to make bursts start misaligned and cross 4 KiB boundaries
            uint32_t so = uint32_t(rng() % 128) * A, dof = uint32_t(rng() % 128) * A;
            run_copy(e, b, rng(), {kind, len, so, dof});
        }
    }
    // explicit 4 KiB straddlers on both sides (buffer base is 4 KiB aligned, pad is 256)
    for (const char* kind : kinds)
        run_copy(e, b, 11, {kind, 4 * A, 4096 - 256 - A, 4096 - 256 - 2 * A});
}

TEST(copy_roundtrip_chain) {
    Env e(c.t);
    const uint32_t A = e.align();
    const uint32_t len = 12288 / A * A;
    HBuf h0 = e.host_buf(len), h1 = e.host_buf(len);
    DBuf d0 = e.dev_buf(len), d1 = e.dev_buf(len);
    fill_pattern(h0.p, len, c.seed);
    // dependent chain: needs F_FENCE_BEFORE because commands may overlap (SPEC 7.3)
    auto r = e.exec(0, {cmd::copy_h2d(1, h0.iova, d0.addr, len),
                        cmd::copy_d2d(2, d0.addr, d1.addr, len, SFX_F_FENCE_BEFORE),
                        cmd::copy_d2h(3, d1.addr, h1.iova, len, SFX_F_FENCE_BEFORE)});
    CHECK_EQ(r.size(), 3u);
    for (auto& q : r) { CHECK_ST(q, SFX_ST_OK); CHECK_EQ(q.result, len); }
    CHECK_EQ(r[0].cmd_id, 1u); CHECK_EQ(r[1].cmd_id, 2u); CHECK_EQ(r[2].cmd_id, 3u);
    CHECK(std::memcmp(h0.p, h1.p, len) == 0);
}

TEST(completion_fields_and_order) {
    EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 4;
    Env e(c.t, o);
    std::vector<sfx_desc_t> cmds;
    for (uint32_t i = 0; i < 12; ++i) cmds.push_back(cmd::nop(0x100 + i, (i % 3 == 0) ? SFX_F_IRQ : 0));
    auto r = e.exec(0, cmds);
    CHECK_EQ(r.size(), cmds.size());
    for (uint32_t i = 0; i < r.size(); ++i) {
        CHECK_EQ(r[i].cmd_id, 0x100 + i);
        CHECK_EQ(r[i].sq_seq, i);
        CHECK_EQ(r[i].cq_seq, i);
        CHECK_EQ(r[i].sq_head, i + 1);
        CHECK_EQ(r[i].opcode, uint16_t(SFX_OP_NOP));
        CHECK_EQ(r[i].phase_word & 1u, sfx_cq_phase(i, 0, 4));
        CHECK_ST(r[i], SFX_ST_OK);
    }
}

// A completion must mean "documented completion point reached": at the instant the host could
// first see the completion, the destination bytes must already be complete (SPEC 8, D2/D4).
TEST(completion_point_copies) {
    Env e(c.t);
    const uint32_t A = e.align();
    const uint32_t len = 6144 / A * A;
    HBuf h_src = e.host_buf(len), h_dst = e.host_buf(len);
    DBuf d_a = e.dev_buf(len), d_b = e.dev_buf(len), d_c = e.dev_buf(len);
    fill_pattern(h_src.p, len, 1);
    fill_pattern(d_b.p, len, 2);   // source of the D2D copy
    fill_pattern(d_c.p, len, 3);   // source of the D2H copy
    std::memset(d_a.p, 0, len);
    std::memset(h_dst.p, 0, len);
    std::vector<uint8_t> src_h(h_src.p, h_src.p + len), src_b(d_b.p, d_b.p + len), src_c(d_c.p, d_c.p + len);
    DBuf d_dd = e.dev_buf(len);
    std::memset(d_dd.p, 0, len);
    unsigned checked = 0;
    CqeWatch w(e, 0, [&](uint32_t n, const sfx_cqe_t& q) {
        CHECK_ST(q, SFX_ST_OK);
        if (n == 0) { CHECK(std::memcmp(d_a.p, src_h.data(), len) == 0); ++checked; }       // H2D
        if (n == 1) { CHECK(std::memcmp(d_dd.p, src_b.data(), len) == 0); ++checked; }      // D2D
        if (n == 2) { CHECK(std::memcmp(h_dst.p, src_c.data(), len) == 0); ++checked; }     // D2H
    });
    auto r = e.exec(0, {cmd::copy_h2d(1, h_src.iova, d_a.addr, len), cmd::copy_d2d(2, d_b.addr, d_dd.addr, len),
                        cmd::copy_d2h(3, d_c.addr, h_dst.iova, len)});
    CHECK_EQ(r.size(), 3u);
    CHECK_EQ(checked, 3u);
}

// Completion publication is two bus writes: body first, phase_word last (SPEC 10.1 D3).
//
// Asserted on memory CONTENT at the moment of each device write to the CQ ring, not on write
// lengths, so it holds for any bus granularity: for every publish the slot must go through
//   (a) body final, phase word still at its PRE-publish value      (possibly after partial states)
//   (b) body final, phase word new
// and the new phase must never be visible before a snapshot of (a) has been seen.
TEST(cqe_two_phase_publish) {
    EnvOpts o; o.sq_log2 = 3; o.cq_log2 = 3;
    Env e(c.t, o);
    const QueueHandle& h = e.qh[0];
    const uint32_t RING = 8;
    struct Slot {
        std::array<uint8_t, SFX_CQE_BYTES> prev{};  // zero-initialised ring
        uint32_t next_n = 0;
        bool body_seen = false;
        uint32_t published = 0;
    };
    std::vector<Slot> slots(RING);
    for (uint32_t s = 0; s < RING; ++s) slots[s].next_n = s;
    unsigned visible = 0;
    CqeWatch w(e, 0, [&](uint32_t n, const sfx_cqe_t& q) {
        CHECK_EQ(q.cq_seq, n);
        CHECK_EQ(q.sq_seq, n);
        CHECK_EQ(q.cmd_id, 500 + n);
        CHECK_EQ(q.sq_head, n + 1);
        CHECK_EQ(q.opcode, uint16_t(SFX_OP_NOP));
        CHECK_ST(q, SFX_ST_OK);
        ++visible;
    });
    const uint64_t cq_lo = h.cq.iova.v, cq_hi = cq_lo + h.cq.size, sq_lo = h.sq.iova.v, sq_hi = sq_lo + h.sq.size;
    w.extra = [&](uint64_t a, uint64_t l) {
        for (uint32_t s = 0; s < RING; ++s) {
            const uint64_t slot = cq_lo + uint64_t(s) * SFX_CQE_BYTES;
            if (!(a < slot + SFX_CQE_BYTES && a + l > slot)) continue;       // this write did not touch slot s
            std::array<uint8_t, SFX_CQE_BYTES> cur;
            std::memcpy(cur.data(), static_cast<const uint8_t*>(h.cq.cpu) + size_t(s) * SFX_CQE_BYTES, SFX_CQE_BYTES);
            Slot& st = slots[s];
            if (cur == st.prev) continue;                                    // no visible change
            sfx_cqe_t q;
            std::memcpy(&q, cur.data(), sizeof q);
            uint32_t pw_prev;
            std::memcpy(&pw_prev, st.prev.data() + SFX_C_PHASE, 4);
            const uint32_t n = st.next_n;
            const bool phase_new = (q.phase_word & 1u) == sfx_cq_phase(n, 0, 3);
            const bool body_ok = q.cmd_id == 500 + n && q.cq_seq == n && q.sq_seq == n && q.status == SFX_ST_OK &&
                                 q.sq_head == n + 1 && q.opcode == SFX_OP_NOP && q.result == 0;
            if (phase_new) {
                CHECK_MSG(body_ok, "the new phase became visible before the entry body was complete");
                CHECK_MSG(st.body_seen, "the new phase became visible in the same write as the body (no body-only state)");
                st.body_seen = false;
                st.next_n += RING;
                ++st.published;
            } else {
                // until publication, bytes 0x1C-0x1F must still hold their pre-publish value
                CHECK_MSG(q.phase_word == pw_prev, "phase word changed before the body was complete");
                if (body_ok) st.body_seen = true;
            }
            st.prev = cur;
        }
    };
    c.t.host.clear_log();
    std::vector<sfx_desc_t> cmds;
    const uint32_t N = 20;  // several laps of the 8-entry ring
    for (uint32_t i = 0; i < N; ++i) cmds.push_back(cmd::nop(500 + i));
    e.exec(0, cmds);
    CHECK_EQ(visible, N);
    uint32_t pubs = 0;
    for (const Slot& s : slots) pubs += s.published;
    CHECK_EQ(pubs, N);                                  // every publish went through both states

    // bus view: every completion was written by exactly two transactions, the last covering +0x1C
    std::vector<Access> ring_writes;
    for (const Access& a : c.t.host.log)
        if (a.write && a.addr < cq_hi && a.addr + a.len > cq_lo) ring_writes.push_back(a);
    CHECK_EQ(ring_writes.size(), size_t(2 * N));
    for (uint32_t n = 0; n < N; ++n) {
        uint64_t slot = cq_lo + uint64_t(n & 7) * SFX_CQE_BYTES;
        const Access& body = ring_writes[2 * n];
        const Access& ph = ring_writes[2 * n + 1];
        CHECK_EQ(body.addr, slot);
        CHECK(ph.addr + ph.len > slot + SFX_C_PHASE);
        CHECK(ph.addr <= slot + SFX_C_PHASE);
        CHECK(ph.addr >= slot);
        CHECK(ph.addr + ph.len <= slot + SFX_CQE_BYTES);
    }
    // ownership: the device never writes the SQ ring and never reads the CQ ring
    CHECK(!c.t.host.touched(sq_lo, sq_hi, 2));
    CHECK(!c.t.host.touched(cq_lo, cq_hi, 1));
    CHECK(c.t.host.touched(sq_lo, sq_hi, 1));
}
