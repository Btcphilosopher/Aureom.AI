// Constrained-random differential stress.
//
// A seeded program of valid and deliberately malformed commands is run on several queues with
// random doorbell batching, duplicate doorbells and delayed CQ release.  The test carries its own
// reference: expected status/result per command (SPEC 5.5 precedence, written independently of the
// model) and a shadow of every buffer.  Data hazards inside a queue are resolved by the program
// itself (F_FENCE_BEFORE), so the final state is timing independent; the DIGEST printed at the end
// can therefore be compared between the model and the RTL.
#include <deque>

#include "test_util.hpp"

using namespace sfxt;

namespace {

constexpr unsigned kBufs = 3;
constexpr uint32_t kBufSz = 4096;

struct Foot { int space; unsigned buf; uint32_t lo, hi; bool wr; };  // space 0 host, 1 dev
struct Cmd { sfx_desc_t d; uint16_t st; uint64_t result; };

struct QS {
    unsigned qi = 0, dom = 1;
    HBuf hb[kBufs];
    DBuf db[kBufs];
    std::vector<uint8_t> sh[kBufs], sd[kBufs];  // shadows
    DBuf kent;
    HBuf sigb;
    uint64_t sig = 0;
    std::deque<Cmd> pending, expect;
    std::vector<Foot> hist;
    uint32_t idx = 0, unreleased = 0, done = 0;
    uint64_t digest = kFnvInit;
};

struct Mut {
    int rank;
    uint16_t status;
    // applicable to: bit0 copy, bit1 kernel, bit2 nop, bit3 fence(plain), bit4 fence+signal
    unsigned ops;
    std::function<void(sfx_desc_t&, uint16_t op, Target&, uint64_t hguard, uint64_t dguard)> apply;
};

std::vector<Mut> mutations() {
    std::vector<Mut> m;
    const unsigned ALL = 0x1F;
    m.push_back({10, SFX_ST_BAD_VERSION, ALL, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.desc_ver = 2; }});
    m.push_back({20, SFX_ST_BAD_OPCODE, ALL, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.opcode = 0x55; }});
    m.push_back({30, SFX_ST_BAD_FLAGS, ALL, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.flags |= 0x40; }});
    m.push_back({40, SFX_ST_BAD_DESC, ALL, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.rsvd1 = 1; }});
    m.push_back({45, SFX_ST_BAD_DESC, 0x02, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.aux1 = 0; }});
    m.push_back({50, SFX_ST_BAD_LENGTH, 0x01, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.length = 0; }});
    m.push_back({50, SFX_ST_BAD_LENGTH, 0x02, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.length = 12; }});
    m.push_back({60, SFX_ST_BAD_ALIGN, 0x01, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.addr0 += 1; }});
    m.push_back({60, SFX_ST_BAD_ALIGN, 0x12, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.addr0 += 4; }});
    m.push_back({70, SFX_ST_BAD_RANGE, 0x01, [](sfx_desc_t& d, uint16_t op, Target& t, uint64_t, uint64_t) {
        d.addr1 = op == SFX_OP_COPY_D2H ? (1ull << 48) : t.dev.size();  // destination beyond its space
    }});
    m.push_back({70, SFX_ST_BAD_RANGE, 0x02, [](sfx_desc_t& d, uint16_t, Target& t, uint64_t, uint64_t) { d.addr0 = t.dev.size(); }});
    m.push_back({70, SFX_ST_BAD_RANGE, 0x10, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t) { d.addr0 = 1ull << 48; }});
    m.push_back({80, SFX_ST_UNAUTHORIZED, 0x01, [](sfx_desc_t& d, uint16_t op, Target&, uint64_t hg, uint64_t dg) {
        d.addr0 = op == SFX_OP_COPY_H2D ? hg : dg;  // source in unmapped memory
    }});
    m.push_back({80, SFX_ST_UNAUTHORIZED, 0x02, [](sfx_desc_t& d, uint16_t, Target&, uint64_t, uint64_t dg) { d.addr0 = dg; }});
    m.push_back({80, SFX_ST_UNAUTHORIZED, 0x10, [](sfx_desc_t& d, uint16_t, Target&, uint64_t hg, uint64_t) { d.addr0 = hg; }});
    return m;
}

bool overlaps(const Foot& a, const Foot& b) {
    return a.space == b.space && a.buf == b.buf && a.lo < b.hi && b.lo < a.hi;
}

struct Run {
    Ctx& c;
    Target& t;
    Env e;
    std::mt19937_64 rng;
    std::vector<QS> qs;
    uint32_t A;
    uint64_t hguard = 0, dguard = 0x800000;
    std::vector<Mut> muts = mutations();

    Run(Ctx& cc, Target& tt, uint64_t seed, const EnvOpts& o) : c(cc), t(tt), e(tt, o), rng(seed), A(e.align()) {
        DmaBuffer g = e.alloc.alloc_coherent(4096, 4096);  // unmapped
        hguard = g.iova.v;
        qs.resize(o.queues);
        for (unsigned q = 0; q < o.queues; ++q) {
            QS& s = qs[q];
            s.qi = q;
            s.dom = e.dom[q];
            for (unsigned b = 0; b < kBufs; ++b) {
                s.hb[b] = e.host_buf(kBufSz, s.dom, 4096);
                s.db[b] = e.dev_buf(kBufSz, s.dom, 4096);
                fill_pattern(s.hb[b].p, kBufSz, rng());
                fill_pattern(s.db[b].p, kBufSz, rng());
                s.sh[b].assign(s.hb[b].p, s.hb[b].p + kBufSz);
                s.sd[b].assign(s.db[b].p, s.db[b].p + kBufSz);
            }
            s.kent = e.dev_buf(64, s.dom);
            s.sigb = e.host_buf(64, s.dom);
            std::memset(s.sigb.p, 0, 64);
        }
    }

    // ---- reference model of one command ---------------------------------------------------
    bool conflicts(QS& s, const std::vector<Foot>& f) {
        for (const Foot& n : f)
            for (const Foot& h : s.hist)
                if (overlaps(n, h) && (n.wr || h.wr)) return true;
        return false;
    }
    void note(QS& s, sfx_desc_t& d, const std::vector<Foot>& f, bool barrier) {
        if (barrier || conflicts(s, f)) {
            d.flags |= SFX_F_FENCE_BEFORE;
            s.hist.clear();
        }
        for (const Foot& n : f) s.hist.push_back(n);
    }

    Cmd gen_valid(QS& s, unsigned kind, uint32_t id) {
        Cmd cm{};
        uint16_t flags = (rng() % 4 == 0) ? SFX_F_IRQ : 0;
        bool want_barrier = rng() % 14 == 0;
        auto pick = [&](uint32_t& len, uint32_t& so, uint32_t& dof) {
            len = A * (1 + rng() % (2048 / A));
            so = A * (rng() % ((kBufSz - len) / A + 1));
            dof = A * (rng() % ((kBufSz - len) / A + 1));
        };
        uint32_t len, so, dof;
        unsigned i = rng() % kBufs, j = rng() % kBufs;
        switch (kind) {
        case 0: {  // H2D
            pick(len, so, dof);
            cm.d = cmd::copy_h2d(id, Iova(s.hb[i].iova.v + so), DevAddr(s.db[j].addr.v + dof), len, flags);
            note(s, cm.d, {{0, i, so, so + len, false}, {1, j, dof, dof + len, true}}, want_barrier);
            std::memcpy(&s.sd[j][dof], &s.sh[i][so], len);
            cm.result = len;
            break;
        }
        case 1: {  // D2H
            pick(len, so, dof);
            cm.d = cmd::copy_d2h(id, DevAddr(s.db[i].addr.v + so), Iova(s.hb[j].iova.v + dof), len, flags);
            note(s, cm.d, {{1, i, so, so + len, false}, {0, j, dof, dof + len, true}}, want_barrier);
            std::memcpy(&s.sh[j][dof], &s.sd[i][so], len);
            cm.result = len;
            break;
        }
        case 2: {  // D2D, distinct buffers (no intra-command overlap)
            pick(len, so, dof);
            if (j == i) j = (i + 1) % kBufs;
            cm.d = cmd::copy_d2d(id, DevAddr(s.db[i].addr.v + so), DevAddr(s.db[j].addr.v + dof), len, flags);
            note(s, cm.d, {{1, i, so, so + len, false}, {1, j, dof, dof + len, true}}, want_barrier);
            std::memcpy(&s.sd[j][dof], &s.sd[i][so], len);
            cm.result = len;
            break;
        }
        case 3: {  // KERNEL
            uint32_t asz = 0, aoff = 0;
            unsigned k = rng() % kBufs;
            DevAddr args(0);
            std::vector<Foot> f;
            if (rng() % 2) {
                asz = 8 * (1 + rng() % 16);
                aoff = 8 * (rng() % 16);
                args = DevAddr(s.db[k].addr.v + aoff);
                f.push_back({1, k, aoff, aoff + asz, false});
            }
            cm.d = cmd::kernel(id, s.kent.addr, args, asz, 1 + rng() % 9, 1 + rng() % 9, 1 + rng() % 9, flags);
            note(s, cm.d, f, want_barrier);
            if (id % 13 == 5) { cm.st = SFX_ST_KERNEL_FAULT; cm.result = uint64_t(id) * 5; }
            else cm.result = uint64_t(id) * 3;
            break;
        }
        case 4:
            cm.d = cmd::nop(id, flags);
            note(s, cm.d, {}, want_barrier);
            break;
        default: {  // FENCE (always a barrier for everything that follows)
            bool sig = rng() % 2;
            if (sig) {
                uint64_t v = rng();
                cm.d = cmd::fence_signal(id, s.sigb.iova, v, flags);
                s.sig = v;
            } else {
                cm.d = cmd::fence(id, flags | (rng() % 2 ? SFX_F_FENCE_SCOPE_ALL : 0));
            }
            s.hist.clear();
            break;
        }
        }
        return cm;
    }

    Cmd gen_bad(QS& s, uint32_t id) {
        // a valid base of a random shape, then 1-2 mutations; expected status = earliest-rule mutation
        unsigned shape = rng() % 5;  // 0 h2d 1 d2h 2 d2d 3 kernel 4 fence+signal
        unsigned ops, op_kind;
        sfx_desc_t d;
        const uint32_t len = A * 2;
        if (shape == 0) { d = cmd::copy_h2d(id, s.hb[0].iova, s.db[1].addr, len); ops = 1; op_kind = 0; }
        else if (shape == 1) { d = cmd::copy_d2h(id, s.db[0].addr, s.hb[1].iova, len); ops = 1; op_kind = 0; }
        else if (shape == 2) { d = cmd::copy_d2d(id, s.db[0].addr, s.db[1].addr, len); ops = 1; op_kind = 0; }
        else if (shape == 3) { d = cmd::kernel(id, s.kent.addr, DevAddr(0), 0); ops = 2; op_kind = 1; }
        else { d = cmd::fence_signal(id, s.sigb.iova, 0x1234); ops = 0x10; op_kind = 4; }
        (void)op_kind;
        std::vector<const Mut*> app;
        for (const Mut& m : muts) if (m.ops & ops) app.push_back(&m);
        unsigned n = 1 + rng() % 2;
        std::vector<const Mut*> chosen;
        for (unsigned k = 0; k < n; ++k) {
            const Mut* m = app[rng() % app.size()];
            bool dup = false;
            for (auto* x : chosen) if (x == m) dup = true;
            if (!dup) chosen.push_back(m);
        }
        std::sort(chosen.begin(), chosen.end(), [](const Mut* a, const Mut* b) { return a->rank > b->rank; });  // high rank first
        const uint16_t op0 = d.opcode;
        for (const Mut* m : chosen) m->apply(d, op0, t, hguard, dguard);
        const Mut* first = chosen.front();
        for (const Mut* m : chosen) if (m->rank < first->rank) first = m;
        Cmd cm{};
        cm.d = d;
        cm.st = first->status;
        cm.result = 0;
        // a rejected command moves no data; a FENCE_BEFORE flag it carries is harmless
        return cm;
    }

    Cmd next_cmd(QS& s) {
        uint32_t id = ((s.qi + 1) << 16) | s.idx++;
        unsigned r = rng() % 100;
        if (r < 14) return gen_bad(s, id);
        if (r < 40) return gen_valid(s, 0, id);
        if (r < 54) return gen_valid(s, 1, id);
        if (r < 66) return gen_valid(s, 2, id);
        if (r < 80) return gen_valid(s, 3, id);
        if (r < 90) return gen_valid(s, 4, id);
        return gen_valid(s, 5, id);
    }

    void check_completion(QS& s, const sfx_cqe_t& q) {
        if (s.expect.empty()) fail(__FILE__, __LINE__, "completion with nothing outstanding");
        Cmd ex = s.expect.front();
        s.expect.pop_front();
        std::string at = "queue " + std::to_string(s.qi) + " cmd " + std::to_string(ex.d.cmd_id & 0xFFFF);
        if (q.cmd_id != ex.d.cmd_id) fail(__FILE__, __LINE__, at + ": out of order completion");
        if (q.status != ex.st) fail(__FILE__, __LINE__, at + ": status " + sfx_status_str(q.status) + " expected " + sfx_status_str(ex.st));
        if (q.result != ex.result) fail(__FILE__, __LINE__, at + ": result mismatch");
        if (q.opcode != ex.d.opcode) fail(__FILE__, __LINE__, at + ": opcode echo");
        s.digest = fnv(s.digest, &q.cmd_id, 4);
        s.digest = fnv(s.digest, &q.status, 2);
        s.digest = fnv(s.digest, &q.result, 8);
        ++s.done;
    }

    void go(uint32_t per_queue) {
        for (QS& s : qs) for (uint32_t i = 0; i < per_queue; ++i) s.pending.push_back(next_cmd(s));
        // kernel behaviour keyed by cmd_id only, so it is identical on every target and every run
        t.kernel_hook = [](const KernelReq& r) {
            KernelResult x;
            x.latency = 1 + (r.cmd_id * 37u) % 150u;
            if (r.cmd_id % 13 == 5) { x.status = SFX_KD_FAULT; x.info = uint64_t(r.cmd_id) * 5; }
            else x.info = uint64_t(r.cmd_id) * 3;
            return x;
        };
        uint64_t guard = 0;
        for (;;) {
            bool all = true;
            for (QS& s : qs) if (!s.pending.empty() || !s.expect.empty()) all = false;
            if (all) break;
            std::vector<unsigned> order;
            for (unsigned q = 0; q < qs.size(); ++q) order.push_back(q);
            std::shuffle(order.begin(), order.end(), rng);
            for (unsigned qi : order) {
                QS& s = qs[qi];
                Queue& Q = e.q(qi);
                unsigned k = 1 + rng() % 6, sub = 0;
                while (k-- && !s.pending.empty() && Q.sq_free() > 0 && Q.outstanding() < Q.cq_size()) {
                    Q.submit(s.pending.front().d);
                    s.expect.push_back(s.pending.front());
                    s.pending.pop_front();
                    ++sub;
                }
                if (sub) {
                    Q.ring();
                    if (rng() % 3 == 0) Q.ring();                      // duplicate doorbell
                    if (rng() % 7 == 0) Q.ring_value(Q.sq_tail());     // and a raw duplicate
                }
                sfx_cqe_t q;
                while (Q.poll(&q)) { check_completion(s, q); ++s.unreleased; }
                if (s.unreleased && (rng() & 1)) { Q.release(); s.unreleased = 0; }
                if (rng() % 11 == 0 && s.unreleased == 0) Q.release();  // duplicate CQ-head doorbell
            }
            t.run(1 + rng() % 8);
            if (++guard > 3000000) throw TestFailure("stress: no forward progress");
        }
        for (unsigned qi = 0; qi < qs.size(); ++qi) { e.q(qi).release(); qs[qi].unreleased = 0; }
        e.wait_idle();
        settle(t, 2000);
    }

    void verify_and_digest(uint64_t& dig) {
        for (QS& s : qs) {
            for (unsigned b = 0; b < kBufs; ++b) {
                if (std::memcmp(s.hb[b].p, s.sh[b].data(), kBufSz) != 0)
                    fail(__FILE__, __LINE__, "queue " + std::to_string(s.qi) + " host buffer " + std::to_string(b) + " differs from reference");
                if (std::memcmp(s.db[b].p, s.sd[b].data(), kBufSz) != 0)
                    fail(__FILE__, __LINE__, "queue " + std::to_string(s.qi) + " device buffer " + std::to_string(b) + " differs from reference");
                dig = fnv(dig, s.hb[b].p, kBufSz);
                dig = fnv(dig, s.db[b].p, kBufSz);
            }
            uint64_t sig;
            std::memcpy(&sig, s.sigb.p, 8);
            CHECK_EQ(sig, s.sig);
            dig = fnv(dig, &s.digest, 8);
            WAIT_REG(t, SFX_Q_REG(s.qi, SFX_R_Q_CQ_TAIL), e.qh[s.qi].cfg.seq_start + s.done);
        }
        // guard memory never touched
        std::vector<uint8_t> z(4096, 0);
        CHECK(!t.host.touched(hguard, hguard + 4096));
        CHECK(!t.dev.touched(dguard, dguard + 4096));
    }
};

uint64_t run_stress(Ctx& c, uint64_t seed, unsigned queues, unsigned sq_log2, unsigned cq_log2, uint32_t seq_start, uint32_t cmds) {
    auto tp = c.fresh();
    EnvOpts o;
    o.queues = queues;
    o.sq_log2 = sq_log2; o.cq_log2 = cq_log2; o.seq_start = seq_start;
    if (queues > 1 && tp->geometry().num_windows >= 8) o.domains = {1, 2, 3, 4};
    Run r(c, *tp, seed, o);
    r.go(cmds);
    uint64_t dig = kFnvInit;
    r.verify_and_digest(dig);
    CHECK_EQ(r.e.err_status() & ~uint32_t(SFX_ERR_BAD_DOORBELL), 0u);  // only (benign) rejected doorbells may be flagged
    return dig;
}
}  // namespace

TEST(stress_random_single_queue) {
    uint64_t dig = kFnvInit;
    struct Cfg { unsigned sl, cl; uint32_t start; };
    uint32_t n = 0;
    for (Cfg g : {Cfg{3, 3, 0}, Cfg{2, 3, 0xFFFFFFC0u}, Cfg{4, 2, 16}}) {
        uint64_t d = run_stress(c, c.seed * 1000 + n++, 1, g.sl, g.cl, g.start, 220);
        dig = fnv(dig, &d, 8);
    }
    c.set_digest(dig);
}

TEST(stress_random_two_queues) {
    if (c.t.geometry().num_queues < 2) SKIP("needs 2 queues");
    if (c.t.geometry().num_windows < 8) SKIP("needs 8 windows");
    uint64_t dig = kFnvInit;
    for (uint32_t n = 0; n < 2; ++n) {
        uint64_t d = run_stress(c, c.seed * 77 + n, 2, 3, 3, n ? 0xFFFFFFF8u : 0u, 200);
        dig = fnv(dig, &d, 8);
    }
    c.set_digest(dig);
}
