// Malformed descriptors and queue-fatal errors (SPEC 5.5, 6.5).
#include "test_util.hpp"

using namespace sfxt;

namespace {

// One queue, valid data windows, plus "guard" host and device memory that NO window covers.
// Every rejected command must complete with the expected status, move no data, and never even
// touch the guard memory on the bus.
struct Rig {
    Env e;
    Target& t;
    uint32_t A;
    uint64_t dev_size;
    HBuf hgood, hguard;
    DBuf dgood, dguard;
    uint64_t arena_h_end = 0, arena_d_end = 0;
    uint32_t next_id = 1;
    uint32_t seq = 0;
    unsigned ok_kernels = 0;
    std::vector<uint8_t> dgood_before;

    explicit Rig(Target& tt) : e(tt), t(tt), A(tt.geometry().dma_align), dev_size(tt.dev.size()) {
        hgood = e.host_buf(16384);
        dgood = e.dev_buf(16384);
        Env::Arena& a = e.arena(1);
        arena_h_end = a.hbase.v + a.hsize;
        arena_d_end = a.dbase.v + a.dsize;
        DmaBuffer g = e.alloc.alloc_coherent(4096, 4096);  // allocated after the arena: outside every window
        hguard.p = static_cast<uint8_t*>(g.cpu); hguard.iova = g.iova; hguard.size = 4096;
        dguard.addr = DevAddr(0x800000); dguard.size = 4096; dguard.p = tt.dev.ptr(0x800000, 4096);
        fill_pattern(hgood.p, 16384, 77);
        std::memset(dgood.p, 0xC5, 16384);
    }

    void arm_guards() {
        std::memset(hguard.p, 0x5A, hguard.size);
        std::memset(dguard.p, 0x5A, dguard.size);
        t.host.clear_log(); t.dev.clear_log();
        dgood_before.assign(dgood.p, dgood.p + 16384);
    }
    void check_guards(const char* what) {
        for (size_t i = 0; i < hguard.size; ++i) CHECK_MSG(hguard.p[i] == 0x5A, what);
        for (size_t i = 0; i < dguard.size; ++i) CHECK_MSG(dguard.p[i] == 0x5A, what);
        CHECK_MSG(!t.host.touched(hguard.iova.v, hguard.iova.v + hguard.size), what);
        CHECK_MSG(!t.dev.touched(dguard.addr.v, dguard.addr.v + dguard.size), what);
    }

    // Submit one descriptor, expect `st`.  Returns the completion.
    sfx_cqe_t run(const char* what, sfx_desc_t d, uint16_t st) {
        arm_guards();
        d.cmd_id = next_id++;
        sfx_cqe_t q = e.exec1(0, d);
        std::string msg = what;
        if (q.status != st)
            fail(__FILE__, __LINE__, msg + ": status got " + sfx_status_str(q.status) + " expected " + sfx_status_str(st));
        CHECK_MSG(q.cmd_id == d.cmd_id, what);
        CHECK_MSG(q.opcode == d.opcode, what);          // raw opcode echoed even when unknown
        CHECK_MSG(q.sq_seq == seq, what);               // the failed command still occupied its slot
        CHECK_MSG(q.cq_seq == seq, what);
        ++seq;
        if (st != SFX_ST_OK) {
            CHECK_MSG(q.result == 0, what);
            CHECK_MSG(std::memcmp(dgood.p, dgood_before.data(), 16384) == 0, what);  // moved no data
        }
        check_guards(what);
        CHECK_MSG((e.qreg(0, SFX_R_Q_STATUS) & SFX_QSTAT_STATE_MASK) == SFX_QS_ENABLED, what);  // queue survives
        return q;
    }

    sfx_desc_t base_h2d() const { return cmd::copy_h2d(0, hgood.iova, dgood.addr, 4 * A); }
    sfx_desc_t base_d2h() const { return cmd::copy_d2h(0, dgood.addr, Iova(hgood.iova.v + 8192), 4 * A); }
    sfx_desc_t base_d2d() const { return cmd::copy_d2d(0, dgood.addr, DevAddr(dgood.addr.v + 8192), 4 * A); }
    sfx_desc_t base_kernel() const { return cmd::kernel(0, dgood.addr, DevAddr(dgood.addr.v + 64), 64); }
    sfx_desc_t base_fence_sig() const { return cmd::fence_signal(0, Iova(hgood.iova.v + 12288), 0x1122334455667788ull); }
};

template <class F> sfx_desc_t mut(sfx_desc_t d, F f) { f(d); return d; }

}  // namespace

TEST(malformed_copy_matrix) {
    Rig r(c.t);
    const uint32_t A = r.A;
    const uint64_t HL = 1ull << c.t.geometry().host_addr_bits, DS = r.dev_size;
    const uint16_t OK = SFX_ST_OK;
    auto H = [&](auto f) { return mut(r.base_h2d(), f); };

    r.run("baseline h2d", r.base_h2d(), OK);
    CHECK(std::memcmp(r.dgood.p, r.hgood.p, 4 * A) == 0);
    r.run("flags IRQ|FENCE_BEFORE", H([](sfx_desc_t& d) { d.flags = SFX_F_IRQ | SFX_F_FENCE_BEFORE; }), OK);

    // 1. version
    for (uint16_t v : {0, 2, 0x100}) r.run("bad desc_ver", H([&](sfx_desc_t& d) { d.desc_ver = v; }), SFX_ST_BAD_VERSION);
    // 2. opcode
    for (uint16_t op : {0x0004, 0x0011, 0x0021, 0x0100, 0xFFFF})
        r.run("bad opcode", H([&](sfx_desc_t& d) { d.opcode = op; }), SFX_ST_BAD_OPCODE);
    // 3. flags
    for (uint16_t f : {0x0010, 0x0100, 0x8000, 0xFFF0, 0x0011})
        r.run("undefined flag bit", H([&](sfx_desc_t& d) { d.flags = f; }), SFX_ST_BAD_FLAGS);
    r.run("SIGNAL flag on COPY", H([](sfx_desc_t& d) { d.flags = SFX_F_FENCE_SIGNAL; }), SFX_ST_BAD_FLAGS);
    r.run("SCOPE_ALL flag on COPY", H([](sfx_desc_t& d) { d.flags = SFX_F_FENCE_SCOPE_ALL; }), SFX_ST_BAD_FLAGS);
    // 4. must-be-zero fields
    r.run("rsvd0", H([](sfx_desc_t& d) { d.rsvd0 = 1; }), SFX_ST_BAD_DESC);
    r.run("rsvd0 high", H([](sfx_desc_t& d) { d.rsvd0 = 0x8000; }), SFX_ST_BAD_DESC);
    r.run("rsvd1", H([](sfx_desc_t& d) { d.rsvd1 = 1; }), SFX_ST_BAD_DESC);
    r.run("rsvd1 high", H([](sfx_desc_t& d) { d.rsvd1 = 1ull << 63; }), SFX_ST_BAD_DESC);
    r.run("aux0 on COPY", H([](sfx_desc_t& d) { d.aux0 = 1; }), SFX_ST_BAD_DESC);
    r.run("aux1 on COPY", H([](sfx_desc_t& d) { d.aux1 = 1; }), SFX_ST_BAD_DESC);
    r.run("aux2 on COPY", H([](sfx_desc_t& d) { d.aux2 = 1; }), SFX_ST_BAD_DESC);
    r.run("value on COPY", H([](sfx_desc_t& d) { d.value = 1; }), SFX_ST_BAD_DESC);
    // 5. COPY length
    r.run("len 0", H([](sfx_desc_t& d) { d.length = 0; }), SFX_ST_BAD_LENGTH);
    r.run("len A-1", H([&](sfx_desc_t& d) { d.length = A - 1; }), SFX_ST_BAD_LENGTH);
    r.run("len 4A+1", H([&](sfx_desc_t& d) { d.length = 4 * A + 1; }), SFX_ST_BAD_LENGTH);
    r.run("len 4A+A/2", H([&](sfx_desc_t& d) { d.length = 4 * A + A / 2; }), SFX_ST_BAD_LENGTH);
    r.run("len MAX+A", H([&](sfx_desc_t& d) { d.length = SFX_MAX_COPY_BYTES + A; }), SFX_ST_BAD_LENGTH);
    r.run("len 0xFFFFFFF8", H([](sfx_desc_t& d) { d.length = 0xFFFFFFF8u; }), SFX_ST_BAD_LENGTH);
    // exactly MAX_COPY passes the length rule and then fails on the device address range
    r.run("len == MAX_COPY (range)", H([](sfx_desc_t& d) { d.length = SFX_MAX_COPY_BYTES; }), SFX_ST_BAD_RANGE);
    // 5. alignment
    r.run("src +1", H([](sfx_desc_t& d) { d.addr0 += 1; }), SFX_ST_BAD_ALIGN);
    r.run("src +A/2", H([&](sfx_desc_t& d) { d.addr0 += A / 2; }), SFX_ST_BAD_ALIGN);
    r.run("dst +1", H([](sfx_desc_t& d) { d.addr1 += 1; }), SFX_ST_BAD_ALIGN);
    r.run("dst +A/2", H([&](sfx_desc_t& d) { d.addr1 += A / 2; }), SFX_ST_BAD_ALIGN);
    // 5. range (supported address space), distinct from "not authorised"
    r.run("src at 2^48", H([&](sfx_desc_t& d) { d.addr0 = HL; }), SFX_ST_BAD_RANGE);
    r.run("src crosses 2^48", H([&](sfx_desc_t& d) { d.addr0 = HL - 2 * A; }), SFX_ST_BAD_RANGE);
    r.run("src wraps 2^64", H([&](sfx_desc_t& d) { d.addr0 = ~uint64_t(0) & ~uint64_t(A - 1); }), SFX_ST_BAD_RANGE);
    r.run("dst at DEVMEM end", H([&](sfx_desc_t& d) { d.addr1 = DS; }), SFX_ST_BAD_RANGE);
    r.run("dst crosses DEVMEM end", H([&](sfx_desc_t& d) { d.addr1 = DS - 2 * A; }), SFX_ST_BAD_RANGE);
    r.run("dst wraps 2^64", H([&](sfx_desc_t& d) { d.addr1 = ~uint64_t(0) & ~uint64_t(A - 1); }), SFX_ST_BAD_RANGE);
    // 5. authorisation: in range, but no window
    r.run("src in guard", H([&](sfx_desc_t& d) { d.addr0 = r.hguard.iova.v; }), SFX_ST_UNAUTHORIZED);
    r.run("src one past the guard page", H([&](sfx_desc_t& d) { d.addr0 = r.hguard.iova.v + r.hguard.size; }), SFX_ST_UNAUTHORIZED);
    r.run("src straddles arena end", H([&](sfx_desc_t& d) { d.addr0 = r.arena_h_end - 2 * A; }), SFX_ST_UNAUTHORIZED);
    r.run("src ends exactly at 2^48", H([&](sfx_desc_t& d) { d.addr0 = HL - 4 * A; }), SFX_ST_UNAUTHORIZED);
    r.run("dst in guard", H([&](sfx_desc_t& d) { d.addr1 = r.dguard.addr.v; }), SFX_ST_UNAUTHORIZED);
    r.run("dst straddles arena end", H([&](sfx_desc_t& d) { d.addr1 = r.arena_d_end - 2 * A; }), SFX_ST_UNAUTHORIZED);
    r.run("dst addr 0", H([](sfx_desc_t& d) { d.addr1 = 0; }), SFX_ST_UNAUTHORIZED);
    r.run("src addr 0", H([](sfx_desc_t& d) { d.addr0 = 0; }), SFX_ST_UNAUTHORIZED);

    // precedence between adjacent rules: the earlier rule must win
    r.run("version beats opcode", H([](sfx_desc_t& d) { d.desc_ver = 2; d.opcode = 0x77; }), SFX_ST_BAD_VERSION);
    r.run("opcode beats flags", H([](sfx_desc_t& d) { d.opcode = 0x77; d.flags = 0x10; }), SFX_ST_BAD_OPCODE);
    r.run("flags beat MBZ", H([](sfx_desc_t& d) { d.flags = 0x10; d.rsvd0 = 1; }), SFX_ST_BAD_FLAGS);
    r.run("MBZ beats length", H([](sfx_desc_t& d) { d.rsvd1 = 1; d.length = 0; }), SFX_ST_BAD_DESC);
    r.run("length beats align", H([](sfx_desc_t& d) { d.length = 0; d.addr0 += 1; }), SFX_ST_BAD_LENGTH);
    r.run("align beats range", H([&](sfx_desc_t& d) { d.addr0 += 1; d.addr1 = DS; }), SFX_ST_BAD_ALIGN);
    r.run("range beats auth", H([&](sfx_desc_t& d) { d.addr0 = r.hguard.iova.v; d.addr1 = DS; }), SFX_ST_BAD_RANGE);
    r.run("auth src+dst", H([&](sfx_desc_t& d) { d.addr0 = r.hguard.iova.v; d.addr1 = r.dguard.addr.v; }), SFX_ST_UNAUTHORIZED);

    // the same rules through the other copy directions
    auto D2H = [&](auto f) { return mut(r.base_d2h(), f); };
    auto D2D = [&](auto f) { return mut(r.base_d2d(), f); };
    r.run("baseline d2h", r.base_d2h(), OK);
    r.run("baseline d2d", r.base_d2d(), OK);
    r.run("d2h dst in guard", D2H([&](sfx_desc_t& d) { d.addr1 = r.hguard.iova.v; }), SFX_ST_UNAUTHORIZED);
    r.run("d2h src in guard", D2H([&](sfx_desc_t& d) { d.addr0 = r.dguard.addr.v; }), SFX_ST_UNAUTHORIZED);
    r.run("d2h dst at 2^48", D2H([&](sfx_desc_t& d) { d.addr1 = HL; }), SFX_ST_BAD_RANGE);
    r.run("d2h src beyond DEVMEM", D2H([&](sfx_desc_t& d) { d.addr0 = DS; }), SFX_ST_BAD_RANGE);
    r.run("d2h dst misaligned", D2H([](sfx_desc_t& d) { d.addr1 += 1; }), SFX_ST_BAD_ALIGN);
    r.run("d2d src beyond DEVMEM", D2D([&](sfx_desc_t& d) { d.addr0 = DS; }), SFX_ST_BAD_RANGE);
    r.run("d2d dst beyond DEVMEM", D2D([&](sfx_desc_t& d) { d.addr1 = DS - A; d.length = 2 * A; }), SFX_ST_BAD_RANGE);
    r.run("d2d src in guard", D2D([&](sfx_desc_t& d) { d.addr0 = r.dguard.addr.v; }), SFX_ST_UNAUTHORIZED);
    r.run("d2d dst in guard", D2D([&](sfx_desc_t& d) { d.addr1 = r.dguard.addr.v; }), SFX_ST_UNAUTHORIZED);
    // a host-space address given where a device address is expected is just another bad address
    r.run("d2d src = host iova", D2D([&](sfx_desc_t& d) { d.addr0 = r.hgood.iova.v; }), SFX_ST_BAD_RANGE);

    CHECK_EQ(r.e.err_status(), 0u);  // rejecting commands is not a device error
}

TEST(malformed_kernel_nop_fence_matrix) {
    Rig r(c.t);
    const uint32_t A = r.A;
    const uint64_t HL = 1ull << c.t.geometry().host_addr_bits, DS = r.dev_size;
    const uint16_t OK = SFX_ST_OK;
    auto K = [&](auto f) { return mut(r.base_kernel(), f); };
    auto F = [&](auto f) { return mut(r.base_fence_sig(), f); };
    auto N = [&](auto f) { return mut(cmd::nop(0), f); };

    // ---- NOP
    r.run("nop", cmd::nop(0), OK);
    r.run("nop + IRQ", cmd::nop(0, SFX_F_IRQ), OK);
    r.run("nop + FENCE_BEFORE", cmd::nop(0, SFX_F_FENCE_BEFORE), OK);
    r.run("nop addr0", N([](sfx_desc_t& d) { d.addr0 = 8; }), SFX_ST_BAD_DESC);
    r.run("nop addr1", N([](sfx_desc_t& d) { d.addr1 = 8; }), SFX_ST_BAD_DESC);
    r.run("nop length", N([](sfx_desc_t& d) { d.length = 8; }), SFX_ST_BAD_DESC);
    r.run("nop aux0", N([](sfx_desc_t& d) { d.aux0 = 1; }), SFX_ST_BAD_DESC);
    r.run("nop value", N([](sfx_desc_t& d) { d.value = 1; }), SFX_ST_BAD_DESC);
    r.run("nop undefined flag", N([](sfx_desc_t& d) { d.flags = 0x20; }), SFX_ST_BAD_FLAGS);
    r.run("nop SIGNAL flag", N([](sfx_desc_t& d) { d.flags = SFX_F_FENCE_SIGNAL; }), SFX_ST_BAD_FLAGS);
    r.run("nop SCOPE_ALL flag", N([](sfx_desc_t& d) { d.flags = SFX_F_FENCE_SCOPE_ALL; }), SFX_ST_BAD_FLAGS);

    // ---- KERNEL
    r.run("kernel baseline", r.base_kernel(), OK);
    r.run("kernel no args", K([](sfx_desc_t& d) { d.addr1 = 0; d.length = 0; }), OK);
    r.run("kernel max grid", K([](sfx_desc_t& d) { d.aux0 = d.aux1 = d.aux2 = SFX_MAX_GRID_DIM; }), OK);
    r.run("kernel max args", K([](sfx_desc_t& d) { d.length = SFX_MAX_ARGS_BYTES; }), OK);
    r.run("kernel IRQ flag", K([](sfx_desc_t& d) { d.flags = SFX_F_IRQ; }), OK);
    r.run("kernel grid_x 0", K([](sfx_desc_t& d) { d.aux0 = 0; }), SFX_ST_BAD_DESC);
    r.run("kernel grid_y 0", K([](sfx_desc_t& d) { d.aux1 = 0; }), SFX_ST_BAD_DESC);
    r.run("kernel grid_z 0", K([](sfx_desc_t& d) { d.aux2 = 0; }), SFX_ST_BAD_DESC);
    r.run("kernel grid_x 65536", K([](sfx_desc_t& d) { d.aux0 = 65536; }), SFX_ST_BAD_DESC);
    r.run("kernel grid_z huge", K([](sfx_desc_t& d) { d.aux2 = 0xFFFFFFFFu; }), SFX_ST_BAD_DESC);
    r.run("kernel value", K([](sfx_desc_t& d) { d.value = 1; }), SFX_ST_BAD_DESC);
    r.run("kernel args addr without size", K([](sfx_desc_t& d) { d.length = 0; }), SFX_ST_BAD_DESC);
    r.run("kernel args > max", K([](sfx_desc_t& d) { d.length = SFX_MAX_ARGS_BYTES + 8; }), SFX_ST_BAD_LENGTH);
    r.run("kernel args size 12", K([](sfx_desc_t& d) { d.length = 12; }), SFX_ST_BAD_LENGTH);
    r.run("kernel args size 4", K([](sfx_desc_t& d) { d.length = 4; }), SFX_ST_BAD_LENGTH);
    r.run("kernel entry +4", K([](sfx_desc_t& d) { d.addr0 += 4; }), SFX_ST_BAD_ALIGN);
    r.run("kernel args +4", K([](sfx_desc_t& d) { d.addr1 += 4; }), SFX_ST_BAD_ALIGN);
    r.run("kernel entry at DEVMEM end", K([&](sfx_desc_t& d) { d.addr0 = DS; }), SFX_ST_BAD_RANGE);
    r.run("kernel args cross DEVMEM end", K([&](sfx_desc_t& d) { d.addr1 = DS - 8; }), SFX_ST_BAD_RANGE);
    r.run("kernel entry last 8 bytes (unauthorised)", K([&](sfx_desc_t& d) { d.addr0 = DS - 8; }), SFX_ST_UNAUTHORIZED);
    r.run("kernel entry in guard", K([&](sfx_desc_t& d) { d.addr0 = r.dguard.addr.v; }), SFX_ST_UNAUTHORIZED);
    r.run("kernel args in guard", K([&](sfx_desc_t& d) { d.addr1 = r.dguard.addr.v; }), SFX_ST_UNAUTHORIZED);
    r.run("kernel entry is a host iova", K([&](sfx_desc_t& d) { d.addr0 = r.hgood.iova.v; }), SFX_ST_BAD_RANGE);
    r.run("kernel flags SIGNAL", K([](sfx_desc_t& d) { d.flags = SFX_F_FENCE_SIGNAL; }), SFX_ST_BAD_FLAGS);
    r.run("kernel grid beats args", K([](sfx_desc_t& d) { d.aux0 = 0; d.length = 4; }), SFX_ST_BAD_DESC);
    r.run("kernel args-size beats align", K([](sfx_desc_t& d) { d.length = 12; d.addr0 += 4; }), SFX_ST_BAD_LENGTH);
    r.run("kernel align beats range", K([&](sfx_desc_t& d) { d.addr0 += 4; d.addr1 = DS; }), SFX_ST_BAD_ALIGN);
    r.run("kernel range beats auth", K([&](sfx_desc_t& d) { d.addr0 = r.dguard.addr.v; d.addr1 = DS; }), SFX_ST_BAD_RANGE);
    // only the accepted kernels reached the compute fabric
    CHECK_EQ(c.t.kernels_launched.size(), size_t(5));

    // ---- FENCE
    r.arm_guards();
    r.run("fence plain", cmd::fence(0), OK);
    r.run("fence SCOPE_ALL (advisory)", cmd::fence(0, SFX_F_FENCE_SCOPE_ALL), OK);
    r.run("fence FENCE_BEFORE", cmd::fence(0, SFX_F_FENCE_BEFORE | SFX_F_IRQ), OK);
    std::memset(r.hgood.p + 12288, 0, 8);
    r.run("fence signal", r.base_fence_sig(), OK);
    uint64_t sig;
    std::memcpy(&sig, r.hgood.p + 12288, 8);
    CHECK_EQ(sig, 0x1122334455667788ull);
    r.run("fence plain with addr0", mut(cmd::fence(0), [](sfx_desc_t& d) { d.addr0 = 8; }), SFX_ST_BAD_DESC);
    r.run("fence plain with value", mut(cmd::fence(0), [](sfx_desc_t& d) { d.value = 1; }), SFX_ST_BAD_DESC);
    r.run("fence addr1", F([](sfx_desc_t& d) { d.addr1 = 8; }), SFX_ST_BAD_DESC);
    r.run("fence length", F([](sfx_desc_t& d) { d.length = 8; }), SFX_ST_BAD_DESC);
    r.run("fence aux2", F([](sfx_desc_t& d) { d.aux2 = 1; }), SFX_ST_BAD_DESC);
    r.run("fence signal addr +4", F([](sfx_desc_t& d) { d.addr0 += 4; }), SFX_ST_BAD_ALIGN);
    r.run("fence signal addr +1", F([](sfx_desc_t& d) { d.addr0 += 1; }), SFX_ST_BAD_ALIGN);
    r.run("fence signal at 2^48", F([&](sfx_desc_t& d) { d.addr0 = HL; }), SFX_ST_BAD_RANGE);
    r.run("fence signal ends at 2^48 (unauthorised)", F([&](sfx_desc_t& d) { d.addr0 = HL - 8; }), SFX_ST_UNAUTHORIZED);
    r.run("fence signal in guard", F([&](sfx_desc_t& d) { d.addr0 = r.hguard.iova.v; }), SFX_ST_UNAUTHORIZED);
    r.run("fence undefined flag", F([](sfx_desc_t& d) { d.flags |= 0x40; }), SFX_ST_BAD_FLAGS);
    (void)A;
    CHECK_EQ(r.e.err_status(), 0u);
}

TEST(malformed_user_virtual_address) {
    Target& t = c.t;
    Env e(t);
    const uint32_t A = e.align();
    HBuf h = e.host_buf(4096);
    DBuf d = e.dev_buf(4096);
    fill_pattern(h.p, 4096, 5);
    std::memset(d.p, 0xC5, 4096);
    // The three address kinds must not convert (compile-time guarantee of the driver API).
    static_assert(!std::is_convertible<uint8_t*, Iova>::value, "user pointers must not become Iova");
    static_assert(!std::is_convertible<Iova, DevAddr>::value, "Iova must not become DevAddr");
    // Our IOVAs are deliberately nothing like process virtual addresses.
    uint64_t va = reinterpret_cast<uint64_t>(h.p);
    CHECK_NE(h.iova.v, va);
    int local = 0;
    uint64_t stack_va = reinterpret_cast<uint64_t>(&local);
    const uint64_t HL = 1ull << t.geometry().host_addr_bits;
    const std::vector<uint64_t> vas = {va, stack_va, reinterpret_cast<uint64_t>(&t), va & ~uint64_t(A - 1),
                                       (va & ~uint64_t(A - 1)) | 0x7000000000000000ull};
    for (uint64_t v : vas) {
        uint64_t aligned = v & ~uint64_t(A - 1);
        t.host.clear_log();
        // a raw VA smuggled in with an explicit cast (the only way to get it into a descriptor)
        sfx_cqe_t q = e.exec1(0, cmd::copy_h2d(1, Iova(aligned), d.addr, A));
        uint16_t want = aligned + A <= HL ? SFX_ST_UNAUTHORIZED : SFX_ST_BAD_RANGE;
        if (q.status != want) fail(__FILE__, __LINE__, std::string("VA as source: got ") + sfx_status_str(q.status));
        q = e.exec1(0, cmd::copy_d2h(2, d.addr, Iova(aligned), A));
        if (q.status != want) fail(__FILE__, __LINE__, std::string("VA as destination: got ") + sfx_status_str(q.status));
        // no bus access ever used a raw VA
        for (const Access& a : t.host.log) CHECK(!(a.addr <= aligned && aligned < a.addr + a.len));
    }
    for (int i = 0; i < 4096; ++i) CHECK_EQ(d.p[i], 0xC5);
    // control: the genuine IOVA of the same buffer works
    CHECK_ST(e.exec1(0, cmd::copy_h2d(3, h.iova, d.addr, A)), SFX_ST_OK);
}

// ---------------------------------------------------------------------------------------------
// Queue-fatal errors
// ---------------------------------------------------------------------------------------------
namespace {
void recover_queue(Env& e, uint32_t seq_start = 0) {
    CHECK(e.dev.disable_queue(0));
    CHECK_EQ(e.dev.queue_state(0), uint32_t(SFX_QS_DISABLED));
    e.dev.destroy_queue(e.qh[0]);
    QueueConfig cfg;
    cfg.domain = 1; cfg.sq_log2 = 4; cfg.cq_log2 = 4; cfg.seq_start = seq_start;
    QueueHandle nh;
    CHECK(e.dev.create_queue(0, cfg, &nh));
    e.qh[0] = nh;
    e.qu[0] = std::make_unique<Queue>(e.dev.make_queue(e.t, nh));
    CHECK_ST(e.exec1(0, cmd::nop(0xAAAA)), SFX_ST_OK);  // alive again
}
void expect_qerr(Env& e, uint32_t code) {
    CHECK_EQ(e.dev.queue_state(0), uint32_t(SFX_QS_ERROR));
    CHECK_EQ(e.dev.queue_err(0), code);
    CHECK(e.rd(SFX_R_IRQ_STATUS) & (1u << (SFX_IRQ_QERR_LSB + 0)));
    CHECK_EQ((e.rd(SFX_R_FAULT_INFO) >> 16) & 0xF, 0u);  // names queue 0
}
}  // namespace

TEST(queue_error_bad_seq) {
    // `pre`: submit a good NOP first, so the bad slot has a non-zero expected sequence number
    struct Case { const char* what; bool pre; uint32_t seq; };
    for (Case k : {Case{"seq ahead", false, 1}, Case{"seq behind (stale slot)", true, 0},
                   Case{"far ahead", false, 1000}, Case{"all ones", false, 0xFFFFFFFFu}}) {
        EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 4;
        auto tp = c.fresh();
        Env e(*tp, o);
        DBuf d = e.dev_buf(64);
        Queue& Q = e.q();
        if (k.pre) CHECK(Q.submit(cmd::nop(900)));
        sfx_desc_t bad = cmd::kernel(1, d.addr, DevAddr(0), 0);
        bad.seq = k.seq;
        CHECK(Q.submit_raw(bad));
        CHECK(Q.submit(cmd::kernel(2, d.addr, DevAddr(0), 0)));  // must NOT run
        CHECK(Q.submit(cmd::kernel(3, d.addr, DevAddr(0), 0)));
        Q.ring();
        WAIT(*tp, e.dev.queue_state(0) == SFX_QS_ERROR);
        settle(*tp);
        expect_qerr(e, SFX_QERR_BAD_SEQ);
        CHECK_MSG(tp->kernels_launched.empty(), k.what);                 // nothing at/after the bad slot ran
        CHECK_MSG(e.qreg(0, SFX_R_Q_SQ_HEAD) == (k.pre ? 1u : 0u), k.what);  // bad slot never consumed
        CHECK_LE(e.qreg(0, SFX_R_Q_CQ_TAIL), k.pre ? 1u : 0u);
        sfx_cqe_t q;
        while (Q.poll(&q)) CHECK_NE(q.cmd_id, 1u);                       // no completion for the bad command
        // an ERROR queue ignores doorbells
        e.clear_err();
        Q.ring_value(Q.sq_tail());
        CHECK(e.err_status() & SFX_ERR_BAD_DOORBELL);
        CHECK(!(e.status() & SFX_STATUS_FAULT));                         // queue-local failure, device fine
        recover_queue(e);
    }
}

TEST(queue_error_sq_fetch_bus_error) {
    for (Resp rsp : {Resp::SLVERR, Resp::DECERR}) {
        auto tp = c.fresh();
        EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 4;
        Env e(*tp, o);
        const QueueHandle& h = e.qh[0];
        FaultRule f; f.lo = h.sq.iova.v; f.hi = h.sq.iova.v + h.sq.size; f.on_read = true; f.on_write = false; f.resp = rsp;
        tp->host.add_fault(f);
        e.q().submit(cmd::nop(1));
        e.q().ring();
        WAIT(*tp, e.dev.queue_state(0) == SFX_QS_ERROR);
        expect_qerr(e, SFX_QERR_SQ_FETCH);
        CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_HEAD), 0u);
        CHECK_EQ(e.qreg(0, SFX_R_Q_CQ_TAIL), 0u);
        tp->host.clear_faults();
        recover_queue(e);
    }
}

TEST(queue_error_ring_unauthorised) {
    {   // SQ window revoked before the doorbell: fetch is refused
        auto tp = c.fresh();
        EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 4;
        Env e(*tp, o);
        tp->wr32(SFX_WIN_REG(e.qh[0].sq_win, SFX_R_W_CTRL), 0);
        e.q().submit(cmd::nop(1));
        e.q().ring();
        WAIT(*tp, e.dev.queue_state(0) == SFX_QS_ERROR);
        expect_qerr(e, SFX_QERR_RING_UNAUTH);
        CHECK(!tp->host.touched(e.qh[0].sq.iova.v, e.qh[0].sq.iova.v + e.qh[0].sq.size));  // never even read
        CHECK_EQ(e.qreg(0, SFX_R_Q_SQ_HEAD), 0u);
    }
    {   // CQ window revoked: the command runs but its completion cannot be written
        auto tp = c.fresh();
        EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 4;
        Env e(*tp, o);
        tp->wr32(SFX_WIN_REG(e.qh[0].cq_win, SFX_R_W_CTRL), 0);
        e.q().submit(cmd::nop(1));
        e.q().ring();
        WAIT(*tp, e.dev.queue_state(0) == SFX_QS_ERROR);
        expect_qerr(e, SFX_QERR_RING_UNAUTH);
        CHECK_EQ(e.qreg(0, SFX_R_Q_CQ_TAIL), 0u);
        CHECK(!tp->host.touched(e.qh[0].cq.iova.v, e.qh[0].cq.iova.v + e.qh[0].cq.size));
        sfx_cqe_t q;
        CHECK(!e.q().poll(&q));
    }
}

TEST(queue_error_cq_write_bus_error) {
    struct Case { const char* what; uint64_t lo_off, hi_off; };
    // whole entry, or just the phase word: either way the completion must stay invisible
    for (Case k : {Case{"whole entry", 0, SFX_CQE_BYTES}, Case{"phase word only", SFX_C_PHASE, SFX_CQE_BYTES}}) {
        for (Resp rsp : {Resp::SLVERR, Resp::DECERR}) {
            auto tp = c.fresh();
            EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 4;
            Env e(*tp, o);
            const QueueHandle& h = e.qh[0];
            FaultRule f; f.lo = h.cq.iova.v + k.lo_off; f.hi = h.cq.iova.v + k.hi_off;
            f.on_read = false; f.on_write = true; f.resp = rsp;
            tp->host.add_fault(f);
            e.q().submit(cmd::nop(1));
            e.q().ring();
            WAIT(*tp, e.dev.queue_state(0) == SFX_QS_ERROR);
            expect_qerr(e, SFX_QERR_CQ_WRITE);
            CHECK_EQ(e.qreg(0, SFX_R_Q_CQ_TAIL), 0u);
            sfx_cqe_t q;
            CHECK_MSG(!e.q().poll(&q), k.what);  // the faulted completion never became visible
            tp->host.clear_faults();
            recover_queue(e);
        }
    }
}

// Commands in flight when the queue dies finish, but nothing more is published for that queue.
TEST(queue_error_drops_inflight_completions) {
    EnvOpts o; o.sq_log2 = 4; o.cq_log2 = 4;
    Env e(c.t, o);
    DBuf d = e.dev_buf(64);
    // a slow kernel, then a bad-seq descriptor
    c.t.kernel_hook = [](const KernelReq&) { KernelResult r; r.latency = 2000; return r; };
    Queue& Q = e.q();
    Q.submit(cmd::kernel(1, d.addr, DevAddr(0), 0));
    sfx_desc_t bad = cmd::nop(2);
    bad.seq = 777;
    Q.submit_raw(bad);
    Q.ring();
    WAIT(c.t, e.dev.queue_state(0) == SFX_QS_ERROR);
    WAIT(c.t, e.status() & SFX_STATUS_IDLE);  // the kernel ran to completion ...
    CHECK_EQ(c.t.kernels_launched.size(), 1u);
    CHECK_EQ(e.qreg(0, SFX_R_Q_CQ_TAIL), 0u);  // ... but its completion was dropped
    sfx_cqe_t q;
    CHECK(!Q.poll(&q));
}
