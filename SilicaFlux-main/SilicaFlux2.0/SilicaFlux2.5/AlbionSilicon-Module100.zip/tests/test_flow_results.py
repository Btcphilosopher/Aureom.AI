"""Properties of the COMPLETED runs (reports/<run>/summary.json).  Skipped until the flow has produced them."""
import pytest

from conftest import summary

pytestmark = pytest.mark.flow
RUNS = ["albion_pe_mesh__base", "albion_spm__base"]


@pytest.mark.parametrize("run_id", RUNS)
def test_every_physical_stage_executed_and_passed(run_id):
    s = summary(run_id)
    for st in ("techcheck", "lint", "verify_rtl", "synth", "gls", "sdc", "sta_pre", "plan", "floorplan", "place", "cts", "groute", "droute",
               "signoff_sta", "irdrop", "antenna", "drc", "lvs"):
        assert s["stages"][st] == "passed", (run_id, st, s["stages"])


@pytest.mark.parametrize("run_id", RUNS)
def test_no_latches_and_ports_preserved(run_id):
    s = summary(run_id)
    assert s["synthesis"]["latches_rtl"] == 0 and s["synthesis"]["latches_mapped"] == 0


@pytest.mark.parametrize("run_id", RUNS)
def test_default_corner_timing_closed_and_routing_clean(run_id):
    s = summary(run_id)
    tt = s["timing_by_corner"]["tt"]
    assert tt["setup_violating_endpoints"] == 0 and tt["setup_worst_slack_ns"] >= 0
    assert tt["hold_violating_endpoints"] == 0 and tt["hold_worst_slack_ns"] >= 0
    assert s["routing"]["global"]["total_overflow"] == 0 and s["routing"]["detailed"]["final_violations"] == 0
    assert (s["unconstrained_endpoints"] or {}).get("other", 0) == 0


@pytest.mark.parametrize("run_id", RUNS)
def test_result_is_labelled_experimental_and_never_tapeout_ready(run_id):
    s = summary(run_id)
    assert s["pdk"]["class"] == "open_public_experimental" and s["pdk"]["signoff_eligible"] is False
    assert s["readiness"]["tapeout_ready"] is False
    assert s["physical_verification"]["electromigration"]["status"] == "not_run"


def test_spm_uses_one_real_macro_and_vendor_model_was_exercised():
    s = summary("albion_spm__base")
    assert s["synthesis"]["n_macros"] == 1 and len(s["floorplan"]["macros"]) == 1
    rtl = s["source_verification"]["rtl"]["detail"]
    assert rtl["n_runs"] == rtl["n_pass"] == 26 and rtl["vendor_macro_model_log_events"] > 1000 and rtl["backdoor_checker_live"]


def test_drc_split_shows_zero_violations_outside_macro_in_magic():
    d = summary("albion_spm__base")["physical_verification"]["drc"]["engine"]["magic_drc"]
    assert d["ran"] and d["outside_macros"] == 0


@pytest.mark.parametrize("a,b", [("albion_pe_mesh__s_base", "albion_pe_mesh__base"), ("albion_spm__s_base", "albion_spm__base")])
def test_independent_rerun_reproduces_the_baseline_exactly(a, b):
    sa, sb = summary(a), summary(b)
    for k in ("setup_worst_slack_ns", "hold_worst_slack_ns", "setup_tns_ns"):
        assert sa["timing_by_corner"]["tt"][k] == sb["timing_by_corner"]["tt"][k], k
    assert sa["synthesis"]["std_cell_area_um2"] == sb["synthesis"]["std_cell_area_um2"]
    assert sa["routing"]["detailed"]["wirelength_um"] == sb["routing"]["detailed"]["wirelength_um"]
    assert sa["routing"]["global"]["wirelength_um"] == sb["routing"]["global"]["wirelength_um"]
