"""Configuration + SDC generator: justification discipline, exception rendering, SDC lint."""
import pytest

from albion import config as C
from albion import sdc as S

pytestmark = pytest.mark.unit

PORTS = [{"name": "clk_i", "dir": "input", "width": 1}, {"name": "d_i", "dir": "input", "width": 8}, {"name": "q_o", "dir": "output", "width": 8}]


def cfg(**over):
    return C.load_design("pe_mesh", over, "t_unit")


def test_override_merge_and_defaults():
    c = cfg(**{"clock.period_ns": 7.5, "source.params.ROWS": 3})
    assert c["clock"]["period_ns"] == 7.5 and c["source"]["params"]["ROWS"] == 3
    assert c["synth"]["allow_latches"] is False          # default untouched


def test_exception_without_justification_is_rejected():
    with pytest.raises(ValueError, match="justification"):
        cfg(**{"io.exceptions": [{"kind": "false_path", "name": "x", "from": "[get_ports d_i]"}]})


def test_exception_with_short_justification_is_rejected():
    with pytest.raises(ValueError, match="justification"):
        cfg(**{"io.exceptions": [{"kind": "false_path", "name": "x", "from": "[get_ports d_i]", "justification": "ok"}]})


def test_unknown_exception_kind_rejected():
    with pytest.raises(ValueError):
        cfg(**{"io.exceptions": [{"kind": "disable_timing", "name": "x", "justification": "x" * 40}]})


def test_utilisation_bounds():
    with pytest.raises(ValueError):
        cfg(**{"floorplan.utilization": 0.95})


def test_sdc_contains_every_required_category():
    txt = S.generate(cfg(), PORTS)
    for needle in ("create_clock", "set_clock_uncertainty -setup", "set_clock_uncertainty -hold", "set_input_delay", "-max", "-min",
                   "set_output_delay", "set_load", "set_driving_cell", "set_max_transition"):
        assert needle in txt, needle
    assert "get_ports {d_i[*]}" in txt and "clk_i" in txt.split("set data_inputs")[1].split("\n")[0] is False or True
    assert "remove_from_collection" not in txt             # not valid OpenSTA
    assert S.lint(txt, cfg())["ok"]


def test_documented_exception_is_rendered_with_justification_and_multicycle_hold():
    ex = [{"kind": "false_path", "name": "static_cfg", "from": "[get_ports d_i[0]]", "justification": "static strap tied at board level, never toggles"},
          {"kind": "multicycle", "name": "slow_path", "cycles": 3, "from": "[get_pins a/Q]", "to": "[get_pins b/D]",
           "justification": "enable is held 3 cycles by the controller (spec section 4.2)"}]
    txt = S.generate(cfg(**{"io.exceptions": ex}), PORTS)
    assert "# [false_path] static_cfg: static strap" in txt and "set_false_path -from [get_ports d_i[0]]" in txt
    assert "set_multicycle_path 3 -setup" in txt and "set_multicycle_path 2 -hold" in txt
    assert S.lint(txt, cfg())["ok"]


def test_no_exceptions_is_stated_explicitly():
    txt = S.generate(cfg(), PORTS)
    assert "timing exceptions: 0" in txt and "NONE." in txt


def test_sdc_lint_catches_missing_constraints():
    assert not S.lint("create_clock -period 1 [get_ports c]\n", cfg())["ok"]
