"""The tapeout gate must be unpassable here, and no report may ever claim tapeout readiness."""
import json

import pytest

from albion import config as C
from albion import gates as G
from albion import report as R
from albion.pdk import load_profile

pytestmark = pytest.mark.unit


def test_readiness_never_true_for_open_pdk():
    r = R.readiness(None, load_profile("sky130hd"), {})
    assert r["tapeout_ready"] is False and "EXPERIMENTAL" in r["label"] and len(r["blockers"]) >= 6


def test_tapeout_tier_fails_with_explicit_blockers():
    cfg = C.load_design("pe_mesh", {}, "t_unit")
    summ = {"readiness": R.readiness(None, load_profile("sky130hd"), {}), "pdk": {"class": "open_public_experimental"}}
    res = G.tapeout(cfg, summ, "open_public_experimental")
    assert not any(g["ok"] for g in res) and any("pdk_class_commercial" in g["gate"] for g in res)


def test_experimental_gate_can_fail():
    cfg = C.load_design("pe_mesh", {}, "t_unit")
    stages = {k: "passed" for k in ("techcheck", "lint", "verify_rtl", "synth", "gls", "sdc", "sta_pre", "plan", "floorplan", "place",
                                    "cts", "groute", "droute")}
    s = {"stages": dict(stages, synth="failed"), "synthesis": {"latches_rtl": 2, "latches_mapped": 0},
         "floorplan": {"legality": True}, "routing": {"global": {"total_overflow": 5}, "detailed": {"final_violations": 3}},
         "timing_by_corner": {"tt": {"setup_violating_endpoints": 4, "setup_worst_slack_ns": -0.2, "hold_violating_endpoints": 0,
                                     "hold_worst_slack_ns": 0.1, "unconstrained_endpoints": 2}},
         "unconstrained_endpoints": {"total": 2, "const": 0, "other": 2},
         "physical_verification": {"antenna": {"net_violations": 1}}}
    res = G.experimental(cfg, s)
    failed = {g["gate"] for g in res if not g["ok"]}
    assert {"synthesis", "no_latches", "route_overflow", "router_drc", "setup_tt", "constrained_tt", "antenna"} <= failed


def test_non_default_corner_is_warning_not_failure_in_experimental_tier():
    cfg = C.load_design("pe_mesh", {}, "t_unit")
    st = {k: "passed" for k in ("techcheck", "lint", "verify_rtl", "synth", "gls", "sdc", "sta_pre", "plan", "floorplan", "place", "cts", "groute", "droute")}
    ok = {"setup_violating_endpoints": 0, "setup_worst_slack_ns": 1.0, "hold_violating_endpoints": 0, "hold_worst_slack_ns": 0.1, "unconstrained_endpoints": 0}
    ss = dict(ok, setup_violating_endpoints=9, setup_worst_slack_ns=-5.0)
    s = {"stages": st, "synthesis": {"latches_rtl": 0, "latches_mapped": 0}, "floorplan": {"legality": True},
         "routing": {"global": {"total_overflow": 0}, "detailed": {"final_violations": 0}}, "timing_by_corner": {"tt": ok, "ss": ss},
         "unconstrained_endpoints": {"total": 0, "const": 0, "other": 0}, "physical_verification": {"antenna": {"net_violations": 0}}}
    res = G.experimental(cfg, s)
    bad = [g for g in res if not g["ok"]]
    assert [g["gate"] for g in bad] == ["setup_ss"] and bad[0]["severity"] == "warn"
