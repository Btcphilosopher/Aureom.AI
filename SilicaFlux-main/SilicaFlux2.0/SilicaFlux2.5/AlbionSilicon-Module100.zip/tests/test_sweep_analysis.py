"""Sweep ranking logic: gate failures dominate, incomplete points are never ranked, SVG output is well-formed."""
import xml.dom.minidom

import pytest

from albion import sweep as SW

pytestmark = pytest.mark.unit


def row(name, area, period, power, usage, status="complete", fail=False, pnr=100.0):
    return {"point": name, "status": status, "die_area_um2": area, "min_period_tt_ns": period, "power_tt_mw": power, "grt_usage_pct": usage,
            "pnr_seconds": pnr, "setup_viol_tt": 3 if fail else 0, "hold_viol_tt": 0, "grt_overflow": 0, "drt_violations": 0, "corners": {},
            "dimension": "x", "clock_target_ns": 10, "std_cell_area_um2": 1, "macro_area_um2": 0, "setup_ws_tt_ns": 1, "hold_ws_tt_ns": 1,
            "drt_wl_um": 1, "hold_buffers": 0}


def analyse_rows(rows, monkeypatch, tmp_path):
    monkeypatch.setattr(SW, "ROOT", tmp_path)
    sw = {"name": "t", "design": "d", "points": [{"name": r["point"]} for r in rows]}
    monkeypatch.setattr(SW, "_metric_row", lambda s, p, r: next(x for x in rows if x["point"] == p["name"]))
    res = [{"name": r["point"], "status": "ok", "run_id": r["point"], "seconds": 1} for r in rows]
    return SW.analyse(sw, res)


def test_best_on_every_axis_ranks_first_and_failure_is_last(monkeypatch, tmp_path):
    rows = [row("best", 100, 8, 5, 10), row("mid", 150, 9, 6, 15), row("worst_but_clean", 200, 10, 8, 20), row("fast_but_fails", 90, 6, 4, 5, fail=True)]
    out = analyse_rows(rows, monkeypatch, tmp_path)
    ranked = sorted([p for p in out["points"] if p.get("rank")], key=lambda p: p["rank"])
    assert ranked[0]["point"] == "best" and ranked[-1]["point"] == "fast_but_fails"      # +10 penalty beats any metric advantage
    assert ranked[-1]["tt_gate_failure"] is True


def test_incomplete_points_are_listed_but_unranked(monkeypatch, tmp_path):
    out = analyse_rows([row("ok", 100, 8, 5, 10), row("broken", None, None, None, None, status="incomplete")], monkeypatch, tmp_path)
    broken = next(p for p in out["points"] if p["point"] == "broken")
    assert "rank" not in broken and out["n_complete"] == 1


def test_svg_is_well_formed_and_contains_every_point(monkeypatch, tmp_path):
    out = analyse_rows([row("a", 100, 8, 5, 10), row("b", 150, 9, 6, 15)], monkeypatch, tmp_path)
    svg = tmp_path / "reports" / "sweeps" / "t.svg"
    xml.dom.minidom.parse(str(svg))
    txt = svg.read_text()
    assert ">a<" in txt and ">b<" in txt


def test_markdown_table_marks_incomplete(monkeypatch, tmp_path):
    out = analyse_rows([row("a", 100, 8, 5, 10), row("x", None, None, None, None, status="incomplete")], monkeypatch, tmp_path)
    md = (tmp_path / "reports" / "sweeps" / "t.md").read_text()
    assert "**incomplete**" in md and "`a`" in md
