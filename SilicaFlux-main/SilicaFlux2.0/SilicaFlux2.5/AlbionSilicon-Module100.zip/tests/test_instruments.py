"""Every checking tool must be shown to FAIL on a known-bad input; otherwise its 'clean' result means nothing."""
import re
import subprocess
from pathlib import Path

import pytest

from albion import pdk as P
from albion import verify as V
from albion.util import ROOT, run, tool

pytestmark = pytest.mark.eda


def test_drc_engines_detect_planted_violation_and_unconfigured_klayout_does_not():
    r = V.drc_selftest(P.load_profile("sky130hd"))
    assert r["magic_detects"], "Magic DRC could not detect a planted met1 spacing violation"
    assert r["klayout_detects"], "KLayout deck (feol/beol enabled) could not detect it"
    assert r["klayout_unconfigured_detects"] is False, "documents the trap: the unconfigured deck runs zero rules"


def test_sta_reports_unconstrained_endpoints_when_constraints_are_missing(tmp_path):
    prof = P.load_profile("sky130hd")
    lib = prof["corners"]["tt"]["lib"]
    (tmp_path / "t.v").write_text("module t(input clk, input a, output y); reg q; always @(posedge clk) q <= a; assign y = q; endmodule\n")
    (tmp_path / "s.ys").write_text(f"read_liberty -lib {lib}\nread_verilog t.v\nsynth -top t -flatten\ndfflibmap -liberty {lib}\nabc -liberty {lib}\n"
                                   "opt_clean -purge\nwrite_verilog -noattr n.v\n")
    assert subprocess.run(["yosys", "-q", "s.ys"], cwd=tmp_path, capture_output=True).returncode == 0

    def sta(sdc):
        (tmp_path / "c.sdc").write_text(sdc)
        (tmp_path / "x.tcl").write_text(f"read_lef {prof['files']['tech_lef']}\nread_lef {prof['files']['stdcell_lef']}\nread_liberty {lib}\nread_verilog n.v\nlink_design t\nread_sdc c.sdc\n"
                                        "check_setup -verbose -unconstrained_endpoints -no_clock -no_input_delay -no_output_delay\nexit\n")
        r = run([tool("openroad"), "-no_splash", "-exit", "x.tcl"], tmp_path / "o.log", cwd=tmp_path, fatal=[])
        return (tmp_path / "o.log").read_text()
    full = sta("create_clock -name c -period 10 [get_ports clk]\nset_input_delay 1 -clock c [get_ports a]\nset_output_delay 1 -clock c [get_ports y]\n")
    bare = sta("create_clock -name c -period 10 [get_ports clk]\nset_input_delay 1 -clock c [get_ports a]\n")
    assert "unconstrained endpoint" not in full
    assert re.search(r"There (is|are) \d+ unconstrained endpoint", bare), bare[-400:]


@pytest.mark.flow
def test_gls_testbench_detects_a_stuck_at_fault_in_the_macro_netlist():
    d = ROOT / "build" / "albion_spm__base" / "gls"
    if not (d / "netlist_gl.v").exists():
        pytest.skip("run the spm flow first")
    t = (d / "netlist_gl.v").read_text()
    old = ".din0({ \\g_core.g_bank[0].u_bank.a_sw[31] ,"
    assert old in t
    (d / "netlist_mut_test.v").write_text(t.replace(old, ".din0({ 1'b0 ,", 1))
    macro = Path(P.load_profile("sky130hd")["macros"]["sky130_sram_1kbyte_1rw1r_32x256_8"]["dir"]) / "sky130_sram_1kbyte_1rw1r_32x256_8.v"
    cmd = ["iverilog", "-g2012", "-DFUNCTIONAL", "-DUNIT_DELAY=#0", "-s", "tb_spm_gls", "-o", "mut_test.vvp", "tb_spm_gls.sv", "netlist_mut_test.v", "cell_models.v", str(macro)]
    assert subprocess.run(cmd, cwd=d, capture_output=True).returncode == 0
    out = subprocess.run(["vvp", "-n", "mut_test.vvp"], cwd=d, capture_output=True, text=True).stdout
    assert re.search(r"SPM_GLS_RESULT: FAIL .*errors=[1-9]", out), out[-300:]


@pytest.mark.flow
def test_lvs_detects_a_missing_instance():
    d = ROOT / "build" / "albion_pe_mesh__base" / "verify"
    if not (d / "final_lvs.v").exists():
        pytest.skip("run the pe_mesh LVS stage first")
    t = (d / "final_lvs.v").read_text()
    m = re.search(r"^\s*sky130_fd_sc_hd__buf_\d+\s+\S+\s*\([^;]*?\);\s*\n", t, flags=re.M | re.S)
    assert m
    (d / "final_lvs_mut.v").write_text(t.replace(m.group(0), "", 1))
    prof = P.load_profile("sky130hd")
    (d / "lvs_mut.tcl").write_text(f"lvs {{tensor_pe_mesh_layout_lvs.spice tensor_pe_mesh}} {{final_lvs_mut.v tensor_pe_mesh}} {prof['files']['netgen_setup']} lvs_mut.out -json\n")
    subprocess.run([tool("netgen"), "-batch", "source", "lvs_mut.tcl"], cwd=d, capture_output=True)
    assert "Circuits match uniquely" not in (d / "lvs_mut.out").read_text()
