import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))


def summary(run_id):
    p = ROOT / "reports" / run_id / "summary.json"
    if not p.exists():
        pytest.skip(f"{p} missing: run the flow first")
    return json.loads(p.read_text())


@pytest.fixture(scope="session")
def root():
    return ROOT
