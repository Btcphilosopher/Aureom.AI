"""Floorplan planner + the independent legality checker must be able to REJECT illegal plans."""
import copy

import pytest

from albion import config as C
from albion import plan as PL

pytestmark = pytest.mark.unit


def good_plan():
    return {"site": [0.46, 2.72], "die": [0, 0, 700.0, 700.0], "core": [20.24, 21.76, 680.34, 677.28], "halo": [20.0, 20.0],
            "macros": [{"name": "m0", "cell": "X", "x": 100.28, "y": 103.36, "w": 100.0, "h": 100.0, "orient": "R0"},
                       {"name": "m1", "cell": "X", "x": 400.2, "y": 103.36, "w": 100.0, "h": 100.0, "orient": "R0"}],
            "blockages": [], "placeable_core_area_um2": 1e5,
            "pin_groups": {"edges": {"west": ["a"], "east": [], "north": [], "south": []}, "unassigned": [], "n_pins": 1}}


def chk(p):
    return PL.check_plan(p, C.load_design("pe_mesh", {}, "t_unit"))


def test_legal_plan_passes():
    assert chk(good_plan())["ok"], chk(good_plan())


def test_macro_outside_core_halo_is_rejected():
    p = good_plan()
    p["macros"][0]["x"] = 25.76                      # inside core but violates the 20 um halo clearance
    assert not chk(p)["ok"]


def test_overlapping_halos_are_rejected():
    p = good_plan()
    p["macros"][1]["x"] = p["macros"][0]["x"] + 110.4   # macros 10 um apart: halos (20 um) overlap
    r = chk(p)
    assert not r["ok"] and any("halos overlap" in v for v in r["violations"])


def test_off_grid_origin_is_rejected():
    p = good_plan()
    p["macros"][0]["x"] = 100.31
    assert any("off the placement grid" in v for v in chk(p)["violations"])


def test_unassigned_pin_is_rejected():
    p = copy.deepcopy(good_plan())
    p["pin_groups"]["unassigned"] = ["rogue"]
    assert not chk(p)["ok"]


def test_io_limited_die_is_rejected():
    p = good_plan()
    p["pin_groups"]["edges"]["west"] = [f"p{i}" for i in range(1000)]
    assert any("I/O-limited" in v for v in chk(p)["violations"])


def test_anchor_positions_respect_halo():
    core = (20.24, 21.76, 680.34, 677.28)
    for a in ("west", "east", "north", "south", "sw", "ne", "center"):
        x, y = PL.anchor_xy(a, core, 100, 100, 20, 20)
        assert core[0] + 20 - 1e-6 <= x <= core[2] - 20 - 100 + 1e-6, a
        assert core[1] + 20 - 1e-6 <= y <= core[3] - 20 - 100 + 1e-6, a
    with pytest.raises(ValueError):
        PL.anchor_xy("sideways", core, 100, 100, 20, 20)


@pytest.mark.pdk
@pytest.mark.parametrize("anchor", ["center", "west", "east", "north", "south", "sw", "se", "nw", "ne"])
@pytest.mark.parametrize("layout", ["row", "column"])
def test_planner_output_is_always_accepted_by_the_independent_checker(anchor, layout):
    """Regression: the `east`/`north` anchors once produced a macro one site past the halo limit (clamp-then-snap-up)."""
    cfg = C.load_design("spm", {"floorplan.macro_layout.anchor": anchor, "floorplan.macro_layout.arrangement": layout}, "t_unit")
    synth = {"std_cell_area_um2": 15313.4, "macro_instances": [{"name": "m0", "cell": "sky130_sram_1kbyte_1rw1r_32x256_8"},
                                                              {"name": "m1", "cell": "sky130_sram_1kbyte_1rw1r_32x256_8"}],
             "ports": [{"name": "clk", "dir": "input", "width": 1}]}
    cfg["floorplan"]["io"]["groups"] = [{"pins": ".*", "edge": ["west"]}]
    from albion import pdk as P
    prof = P.load_profile("sky130hd")
    import os as _os
    if not _os.path.exists(prof["files"]["tech_lef"]):
        pytest.skip("PDK not installed")
    metas = [{"name": "sky130_sram_1kbyte_1rw1r_32x256_8", "lef_path": "/opt/eda/cache/sky130_sram_macros/sky130_sram_1kbyte_1rw1r_32x256_8/sky130_sram_1kbyte_1rw1r_32x256_8.lef"}]
    import os
    if not os.path.exists(metas[0]["lef_path"]):
        pytest.skip("macro LEF not fetched")
    p = PL.plan(cfg, prof, synth, metas)
    chk = PL.check_plan(p, cfg)
    assert chk["ok"], (anchor, layout, chk["violations"])
