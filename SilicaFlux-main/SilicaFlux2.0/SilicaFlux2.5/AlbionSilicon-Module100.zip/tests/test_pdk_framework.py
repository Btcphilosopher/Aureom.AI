"""PDK framework: commercial template must fail, hash pinning, liberty filtering, macro interface cross-check."""
import json
import re
import subprocess
import tempfile
from pathlib import Path

import pytest

from albion import lef as L
from albion import pdk as P

MAC = "sky130_sram_1kbyte_1rw1r_32x256_8"


@pytest.mark.unit
def test_commercial_template_fails_and_names_what_is_missing():
    r = P.techcheck("commercial_template")
    assert not r["ok"] and len(r["missing"]) > 20
    assert any("signoff" in m for m in r["missing"]) and any("ip." in m for m in r["missing"])
    assert r["signoff_eligible"] is False


@pytest.mark.unit
def test_open_profile_is_never_signoff_eligible(monkeypatch):
    prof = P.load_profile("sky130hd")
    assert prof["pdk_class"] == "open_public_experimental" and prof["signoff_eligible"] is False


@pytest.mark.unit
def test_liberty_filter_removes_only_dont_use_cells(tmp_path):
    lib = tmp_path / "a.lib"
    lib.write_text('library (x) {\n  cell ("sky130_fd_sc_hd__lpflow_isobufsrc_1") {\n    area : 1;\n    pin (A) { direction : input; }\n  }\n'
                   '  cell ("sky130_fd_sc_hd__nand2_1") {\n    area : 3;\n    pin (Y) { function : "!(A&B)"; }\n  }\n}\n')
    out = tmp_path / "b.lib"
    info = P.filter_liberty(str(lib), str(out), ["sky130_fd_sc_hd__lpflow_.*"])
    txt = out.read_text()
    assert info["removed"] == 1 and "nand2_1" in txt and "lpflow" not in txt and txt.count("{") == txt.count("}")


@pytest.mark.pdk
def test_sky130_profile_passes_techcheck():
    r = P.techcheck("sky130hd")
    assert r["ok"], r["missing"] + r["hash_mismatch"]


@pytest.mark.pdk
def test_macro_hashes_match_the_ones_recorded_by_silicaflux_sramlib():
    prof = P.load_profile("sky130hd")
    ra = prof["remote_assets"]["sky130_sram_macros"]
    for rel, exp in ra["expected_sha256"].items():
        assert P.sha256(Path(ra["dest"]) / rel) == exp, rel


@pytest.mark.pdk
def test_tampered_macro_is_detected(monkeypatch):
    orig = P.load_profile

    def fake(name):
        p = orig(name)
        k = next(iter(p["remote_assets"]["sky130_sram_macros"]["expected_sha256"]))
        p["remote_assets"]["sky130_sram_macros"]["expected_sha256"][k] = "0" * 64
        return p
    monkeypatch.setattr(P, "load_profile", fake)
    r = P.techcheck("sky130hd")
    assert not r["ok"] and r["hash_mismatch"]


@pytest.mark.pdk
@pytest.mark.eda
def test_macro_lef_verilog_liberty_agree_and_perturbation_is_caught():
    prof = P.load_profile("sky130hd")
    m = prof["macros"][MAC]
    d = Path(m["dir"])
    tmp = Path(tempfile.mkdtemp())
    (tmp / "a.ys").write_text(f"read_verilog -lib -sv {d / m['verilog']}\nhierarchy -top {MAC}\nwrite_json {tmp}/m.json\n")
    subprocess.run(["yosys", "-q", str(tmp / "a.ys")], check=True)
    mod = json.load(open(tmp / "m.json"))["modules"][MAC]
    vp = {n: (p["direction"], len(p["bits"])) for n, p in mod["ports"].items() if n not in ("vccd1", "vssd1")}
    lib = d / m["lib"]["tt"]
    assert L.check_macro_interface(str(d / m["lef"]), vp, str(lib))["ok"]
    bad = dict(vp, din0=("input", 31))
    assert not L.check_macro_interface(str(d / m["lef"]), bad, str(lib))["ok"]
