# albion_pe_mesh__util_055

*generated 2026-11-18T15:02:23Z · config `4ff2c917ed06` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 23939.2096 µm², 3263 cells, 276 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 63067.99 µm², core 43739.45 µm², std-logic core utilisation 65.18 %
* breakdown µm²: buf_io=1043.5, diode=17.52, decap=0.0, tap=740.71, tie=0.0, clk=1051.01, macro=0.0, hold=10.01, fill=15229.61, std=25647.1

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 4.9268 | 0.1656 | 0 | 0 | 5.0732 | 197.11 | 0 |
| ss | -6.9851 | -0.0916 | 138 | 16 | 16.9851 | 58.88 | 0 |
| tt | 1.5565 | 0.0865 | 0 | 0 | 8.4435 | 118.43 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0127 W (internal 0.00611, switching 0.00664, leakage 2.7e-08)
* ss: total 0.00909 W (internal 0.00435, switching 0.00472, leakage 1.63e-05)
* tt: total 0.0112 W (internal 0.00542, switching 0.00583, leakage 1.18e-08)

## Routing

* global route: {'resource': 46666, 'demand': 11253, 'usage_pct': 24.11, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 132562, 'routed_nets': 3556, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 31.3, 'overflow': 0}, 'met2': {'usage_pct': 35.47, 'overflow': 0}, 'met3': {'usage_pct': 5.02, 'overflow': 0}, 'met4': {'usage_pct': 10.99, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 85788, 'vias': 24947, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 33508, 'met2': 38211, 'met3': 10292, 'met4': 3775, 'met5': 0}, 'router_elapsed': '00:13:12'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 0, 'pin_violations': 0, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 138
* hold violations at ss: 16
* max slew/cap/fanout violations at ss: 57 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
