# albion_pe_mesh__lanes_4x4

*generated 2026-11-18T15:02:25Z · config `1990ed47466e` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 96926.7104 µm², 12945 cells, 1096 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 285677.74 µm², core 242546.37 µm², std-logic core utilisation 48.77 %
* breakdown µm²: buf_io=3560.92, diode=132.63, decap=0.0, tap=4006.34, tie=0.0, clk=3478.34, macro=0.0, hold=680.65, fill=124256.67, std=106430.83

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 4.7687 | 0.1745 | 0 | 0 | 5.2313 | 191.16 | 0 |
| ss | -8.5793 | -0.1065 | 539 | 52 | 18.5793 | 53.82 | 0 |
| tt | 1.0535 | 0.0752 | 0 | 0 | 8.9465 | 111.78 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0531 W (internal 0.0248, switching 0.0283, leakage 1.16e-07)
* ss: total 0.0381 W (internal 0.0177, switching 0.0203, leakage 6.58e-05)
* tt: total 0.0469 W (internal 0.022, switching 0.0249, leakage 4.79e-08)

## Routing

* global route: {'resource': 211832, 'demand': 53841, 'usage_pct': 25.42, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 584264, 'routed_nets': 13928, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 34.85, 'overflow': 0}, 'met2': {'usage_pct': 36.71, 'overflow': 0}, 'met3': {'usage_pct': 4.66, 'overflow': 0}, 'met4': {'usage_pct': 9.43, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 402141, 'vias': 97475, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 164223, 'met2': 181890, 'met3': 40964, 'met4': 15063, 'met5': 0}, 'router_elapsed': '00:55:13'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 15, 'pin_violations': 15, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 539
* hold violations at ss: 52

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
