# albion_pe_mesh__base

*generated 2026-11-18T15:06:35Z · config `4835794d0370` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | passed |
| lvs | passed |
| report | (this stage writes the table) |

## Synthesis

* standard-cell area 23939.2096 µm², 3263 cells, 276 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 82228.86 µm², core 59907.46 µm², std-logic core utilisation 48.29 %
* breakdown µm²: buf_io=1107.31, diode=10.01, decap=0.0, tap=978.44, tie=0.0, clk=1025.98, macro=0.0, hold=10.01, fill=30977.21, std=25798.49

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 4.9365 | 0.1697 | 0 | 0 | 5.0635 | 197.49 | 0 |
| ss | -6.9038 | -0.0551 | 136 | 10 | 16.9038 | 59.16 | 0 |
| tt | 1.5737 | 0.1042 | 0 | 0 | 8.4263 | 118.68 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0127 W (internal 0.00612, switching 0.00659, leakage 2.73e-08)
* ss: total 0.00904 W (internal 0.00437, switching 0.00466, leakage 1.64e-05)
* tt: total 0.0112 W (internal 0.00543, switching 0.00577, leakage 1.19e-08)

## Routing

* global route: {'resource': 61050, 'demand': 11548, 'usage_pct': 18.92, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 131265, 'routed_nets': 3555, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 26.54, 'overflow': 0}, 'met2': {'usage_pct': 27.14, 'overflow': 0}, 'met3': {'usage_pct': 3.82, 'overflow': 0}, 'met4': {'usage_pct': 4.68, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 87288, 'vias': 23571, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 38452, 'met2': 39131, 'met3': 7892, 'met4': 1813, 'met5': 0}, 'router_elapsed': '00:19:14'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 0, 'pin_violations': 0, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: {'engine': {'klayout_drc': {'inside_macro_bboxes': 0, 'log': '/home/user/Aureom.AI/physical/albion/build/albion_pe_mesh__base/verify/klayout_drc.log', 'outside_macros': 27, 'ran': True, 'rc': 0, 'rule_groups_enabled': 'feol,beol,offgrid', 'rules_violated': 3, 'top_rules': [['npc.2', 15], ['psd.2', 8], ['nsd.2', 4]], 'total': 27}, 'magic_drc': {'inside_macro_bboxes': None, 'log': '/home/user/Aureom.AI/physical/albion/build/albion_pe_mesh__base/verify/magic_drc.log', 'outside_macros': None, 'ran': True, 'rules_violated': 0, 'top_rules': [], 'total': 0, 'um_scale': 200.0}}, 'gds': {'bytes': 10089176, 'ok': True, 'problems': []}, 'instrument_selftest': {'klayout_detects': True, 'klayout_unconfigured_detects': False, 'magic_detects': True}, 'note': 'community open decks (Magic sky130A tech, KLayout sky130A_mr); NOT the foundry signoff deck', 'ok': True, 'signoff_accepted': False, 'stage': 'drc'}
* LVS: {'devices_layout_vs_netlist': [3520, 3520], 'engine': 'Magic extraction + Netgen (community sky130A setup)', 'equivalent': True, 'excluded_from_netlist_no_devices': {'sky130_fd_sc_hd__fill_1': 1312, 'sky130_fd_sc_hd__fill_2': 1257, 'sky130_fd_sc_hd__fill_4': 831, 'sky130_fd_sc_hd__fill_8': 2201, 'sky130_fd_sc_hd__tapvpwrvgnd_1': 782}, 'gds': {'bytes': 10089176, 'ok': True}, 'macros_blackboxed': [], 'nets_layout_vs_netlist': [3557, 3557], 'ok': True, 'pin_lists_equivalent': True, 'report_tail': ['---------------------------------------------------------------------------------------', 'Cell pin lists are equivalent.', 'Device classes tensor_pe_mesh and tensor_pe_mesh are equivalent.', '', 'Final result: Circuits match uniquely.', '.'], 'scope_note': 'full design LVS', 'signoff_accepted': False, 'stage': 'lvs'}

## Violations

* setup violations at ss: 136
* hold violations at ss: 10
* max slew/cap/fanout violations at ss: 20 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
