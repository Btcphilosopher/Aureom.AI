# albion_pe_mesh__noadder_map

*generated 2026-11-18T15:02:13Z · config `eaa8309d652f` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 24312.0672 µm², 3129 cells, 276 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 83540.12 µm², core 61028.53 µm², std-logic core utilisation 48.76 %
* breakdown µm²: buf_io=1122.33, diode=10.01, decap=0.0, tap=988.45, tie=0.0, clk=1000.96, macro=0.0, hold=10.01, fill=31273.74, std=26623.03

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 5.0207 | 0.1744 | 0 | 0 | 4.9793 | 200.83 | 0 |
| ss | -7.0706 | -0.0813 | 141 | 5 | 17.0706 | 58.58 | 0 |
| tt | 1.6324 | 0.0902 | 0 | 0 | 8.3676 | 119.51 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0132 W (internal 0.00638, switching 0.00679, leakage 2.82e-08)
* ss: total 0.00936 W (internal 0.00455, switching 0.00479, leakage 1.71e-05)
* tt: total 0.0116 W (internal 0.00566, switching 0.00594, leakage 1.23e-08)

## Routing

* global route: {'resource': 61988, 'demand': 11276, 'usage_pct': 18.19, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 129181, 'routed_nets': 3420, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 25.75, 'overflow': 0}, 'met2': {'usage_pct': 26.67, 'overflow': 0}, 'met3': {'usage_pct': 2.59, 'overflow': 0}, 'met4': {'usage_pct': 3.91, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 84989, 'vias': 22796, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 37702, 'met2': 39170, 'met3': 6449, 'met4': 1666, 'met5': 0}, 'router_elapsed': '00:06:49'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 4, 'pin_violations': 4, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 141
* hold violations at ss: 5
* max slew/cap/fanout violations at ss: 118 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
