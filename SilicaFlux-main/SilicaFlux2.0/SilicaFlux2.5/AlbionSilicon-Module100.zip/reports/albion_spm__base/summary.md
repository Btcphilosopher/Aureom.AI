# albion_spm__base

*generated 2026-11-18T15:06:36Z · config `d03733451d87` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | passed |
| lvs | passed |
| report | (this stage writes the table) |

## Synthesis

* standard-cell area 15313.4368 µm², 1677 cells, 322 flops, 1 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 357753.11 µm², core 309046.4 µm², std-logic core utilisation 19.02 %
* breakdown µm²: buf_io=1709.14, diode=85.08, decap=0.0, tap=1978.15, tie=7.51, clk=775.74, macro=190712.55, hold=0.0, fill=91545.3, std=17953.47

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| tt | 1.7424 | 0.2018 | 0 | 0 | 18.2576 | 54.77 | 83 |

Unconstrained endpoints: 83 total = 83 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* tt: total 0.00383 W (internal 0.00301, switching 0.000805, leakage 1.9e-05)

## Routing

* global route: {'resource': 123428, 'demand': 14306, 'usage_pct': 11.59, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 141850, 'routed_nets': 2164, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 14.75, 'overflow': 0}, 'met2': {'usage_pct': 12.66, 'overflow': 0}, 'met3': {'usage_pct': 7.08, 'overflow': 0}, 'met4': {'usage_pct': 9.8, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 109990, 'vias': 14911, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 43635, 'met2': 35402, 'met3': 21706, 'met4': 9245, 'met5': 0}, 'router_elapsed': '00:09:30'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 9, 'pin_violations': 9, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: {'engine': {'klayout_drc': {'inside_macro_bboxes': 0, 'log': '/home/user/Aureom.AI/physical/albion/build/albion_spm__base/verify/klayout_drc.log', 'outside_macros': 31, 'ran': True, 'rc': 0, 'rule_groups_enabled': 'feol,beol,offgrid', 'rules_violated': 4, 'top_rules': [['psd.2', 14], ['nsd.2', 12], ['licon.13', 3], ['npc.2', 2]], 'total': 31}, 'magic_drc': {'inside_macro_bboxes': 2832369, 'log': '/home/user/Aureom.AI/physical/albion/build/albion_spm__base/verify/magic_drc.log', 'outside_macros': 0, 'ran': True, 'rules_violated': 32, 'top_rules': [['N-Diffusion spacing to N-well < 0.34um (diff/tap.9)', 308037], ['Local interconnect width < 0.17um (li.1)', 232703], ['poly overlap of poly contact < 0.05um (licon.8)', 189088], ['poly overhang of SRAM core transistor < 0.11um (poly.8)', 187200], ['Diffusion width < 0.15um (diff/tap.1)', 186032], ['N-diffusion overlap of N-diffusion contact < 0.04um (licon.5a)', 180183], ['poly contact spacing to diffusion < 0.19um (licon.14)', 173454], ['Via1 width < 0.26um (via.1a + 2 * via.4a)', 163020]], 'total': 2832369, 'um_scale': 200.0}}, 'gds': {'bytes': 18175430, 'ok': True, 'problems': []}, 'instrument_selftest': {'klayout_detects': True, 'klayout_unconfigured_detects': False, 'magic_detects': True}, 'note': 'community open decks (Magic sky130A tech, KLayout sky130A_mr); NOT the foundry signoff deck', 'ok': True, 'signoff_accepted': False, 'stage': 'drc'}
* LVS: {'devices_layout_vs_netlist': [2088, 2088], 'engine': 'Magic extraction + Netgen (community sky130A setup)', 'equivalent': True, 'excluded_from_netlist_no_devices': {'sky130_fd_sc_hd__fill_1': 1736, 'sky130_fd_sc_hd__fill_2': 1641, 'sky130_fd_sc_hd__fill_4': 811, 'sky130_fd_sc_hd__fill_8': 8113, 'sky130_fd_sc_hd__tapvpwrvgnd_1': 1581}, 'gds': {'bytes': 18175430, 'ok': True}, 'macros_blackboxed': ['sky130_sram_1kbyte_1rw1r_32x256_8'], 'nets_layout_vs_netlist': [2200, 2200], 'ok': True, 'pin_lists_equivalent': True, 'report_tail': ['---------------------------------------------------------------------------------------', 'Cell pin lists are equivalent.', 'Device classes hpc_scratchpad and hpc_scratchpad are equivalent.', '', 'Final result: Circuits match uniquely.', '.'], 'scope_note': 'top-level LVS; SRAM macro internals treated as black boxes on both sides (macro-internal LVS belongs to the macro vendor and was not run)', 'signoff_accepted': False, 'stage': 'lvs'}

## Violations

* max slew/cap/fanout violations at tt: 12 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
