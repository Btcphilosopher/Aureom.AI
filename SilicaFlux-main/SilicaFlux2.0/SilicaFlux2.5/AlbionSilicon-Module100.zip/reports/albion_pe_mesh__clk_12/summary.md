# albion_pe_mesh__clk_12

*generated 2026-11-18T15:01:43Z · config `d586909267c1` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 23939.2096 µm², 3263 cells, 276 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 82228.86 µm², core 59907.46 µm², std-logic core utilisation 48.39 %
* breakdown µm²: buf_io=1107.31, diode=15.01, decap=0.0, tap=978.44, tie=0.0, clk=1025.98, macro=0.0, hold=0.0, fill=30918.4, std=25862.3

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 6.9578 | 0.1865 | 0 | 0 | 5.0422 | 198.33 | 0 |
| ss | -4.8266 | -0.5346 | 132 | 148 | 16.8266 | 59.43 | 0 |
| tt | 3.6107 | 0.0212 | 0 | 0 | 8.3893 | 119.2 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0106 W (internal 0.0051, switching 0.00549, leakage 2.74e-08)
* ss: total 0.00755 W (internal 0.00364, switching 0.00389, leakage 1.64e-05)
* tt: total 0.00934 W (internal 0.00453, switching 0.00481, leakage 1.2e-08)

## Routing

* global route: {'resource': 61054, 'demand': 11486, 'usage_pct': 18.81, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 130444, 'routed_nets': 3554, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 26.89, 'overflow': 0}, 'met2': {'usage_pct': 27.14, 'overflow': 0}, 'met3': {'usage_pct': 2.91, 'overflow': 0}, 'met4': {'usage_pct': 4.38, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 86801, 'vias': 23674, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 38664, 'met2': 39102, 'met3': 7316, 'met4': 1718, 'met5': 0}, 'router_elapsed': '00:10:20'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 0, 'pin_violations': 0, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 132
* hold violations at ss: 148
* max slew/cap/fanout violations at ss: 48 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
