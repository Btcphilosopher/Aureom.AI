# albion_spm__cap_2k_2bank

*generated 2026-11-18T15:02:36Z · config `10b85b9c9f46` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 18081.0912 µm², 1910 cells, 387 flops, 2 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 962438.05 µm², core 878017.09 µm², std-logic core utilisation 6.95 %
* breakdown µm²: buf_io=2909.04, diode=507.99, decap=0.0, tap=8217.88, tie=7.51, clk=875.84, macro=381425.1, hold=10.01, fill=453529.97, std=21974.83

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| tt | 1.0662 | 0.3436 | 0 | 0 | 18.9338 | 52.82 | 62 |

Unconstrained endpoints: 62 total = 62 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* tt: total 0.00606 W (internal 0.00512, switching 0.000903, leakage 3.81e-05)

## Routing

* global route: {'resource': 430868, 'demand': 25484, 'usage_pct': 5.91, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 236193, 'routed_nets': 2603, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 8.95, 'overflow': 0}, 'met2': {'usage_pct': 4.81, 'overflow': 0}, 'met3': {'usage_pct': 5.02, 'overflow': 0}, 'met4': {'usage_pct': 2.3, 'overflow': 0}, 'met5': {'usage_pct': 1.92, 'overflow': 0}}}
* detailed route: {'wirelength_um': 188479, 'vias': 19843, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 88657, 'met2': 46964, 'met3': 44118, 'met4': 7989, 'met5': 750}, 'router_elapsed': '00:06:47'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 9, 'pin_violations': 11, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* max slew/cap/fanout violations at tt: 24 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
