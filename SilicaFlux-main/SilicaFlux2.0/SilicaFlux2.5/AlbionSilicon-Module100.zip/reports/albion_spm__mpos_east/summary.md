# albion_spm__mpos_east

*generated 2026-11-18T15:02:38Z · config `6a38ace63b6f` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 15313.4368 µm², 1677 cells, 322 flops, 1 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 357753.11 µm², core 309046.4 µm², std-logic core utilisation 20.46 %
* breakdown µm²: buf_io=1834.26, diode=295.28, decap=0.0, tap=1885.56, tie=7.51, clk=1000.96, macro=190712.55, hold=0.0, fill=89843.67, std=19187.15

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| tt | 0.7106 | 0.1279 | 0 | 0 | 19.2894 | 51.84 | 83 |

Unconstrained endpoints: 83 total = 83 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* tt: total 0.00432 W (internal 0.00313, switching 0.00117, leakage 1.9e-05)

## Routing

* global route: {'resource': 125331, 'demand': 33251, 'usage_pct': 26.53, 'max_h_overflow': 6, 'max_v_overflow': 10, 'total_overflow': 3121, 'wirelength_um': 295402, 'routed_nets': 2147, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 987}, 'met1': {'usage_pct': 36.78, 'overflow': 1248}, 'met2': {'usage_pct': 27.72, 'overflow': 831}, 'met3': {'usage_pct': 15.3, 'overflow': 30}, 'met4': {'usage_pct': 9.19, 'overflow': 25}, 'met5': {'usage_pct': 1.39, 'overflow': 0}}}
* detailed route: {'wirelength_um': 236497, 'vias': 19934, 'final_violations': 4871, 'wirelength_by_layer_um': {'li1': 0, 'met1': 95609, 'met2': 78153, 'met3': 38056, 'met4': 10968, 'met5': 13709}, 'router_elapsed': '00:46:07'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 27, 'pin_violations': 30, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* max slew/cap/fanout violations at tt: 54 (see drv report)
* global-route overflow 3121
* detail-route DRC violations 4871

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
