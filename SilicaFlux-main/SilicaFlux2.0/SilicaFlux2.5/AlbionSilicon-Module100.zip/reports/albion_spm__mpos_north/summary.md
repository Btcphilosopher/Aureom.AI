# albion_spm__mpos_north

*generated 2026-11-18T15:02:41Z · config `3ee527470b33` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 15313.4368 µm², 1677 cells, 322 flops, 1 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 357753.11 µm², core 309046.4 µm², std-logic core utilisation 18.93 %
* breakdown µm²: buf_io=1724.15, diode=45.04, decap=0.0, tap=1978.15, tie=7.51, clk=950.91, macro=190712.55, hold=0.0, fill=91651.65, std=17696.97

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| tt | 1.8566 | 0.1744 | 0 | 0 | 18.1434 | 55.12 | 83 |

Unconstrained endpoints: 83 total = 83 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* tt: total 0.00382 W (internal 0.00306, switching 0.000743, leakage 1.9e-05)

## Routing

* global route: {'resource': 124372, 'demand': 14431, 'usage_pct': 11.6, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 142940, 'routed_nets': 2143, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 15.43, 'overflow': 0}, 'met2': {'usage_pct': 12.17, 'overflow': 0}, 'met3': {'usage_pct': 7.17, 'overflow': 0}, 'met4': {'usage_pct': 9.05, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 110791, 'vias': 14947, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 44698, 'met2': 34791, 'met3': 22273, 'met4': 9026, 'met5': 0}, 'router_elapsed': '00:07:58'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 18, 'pin_violations': 18, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* max slew/cap/fanout violations at tt: 13 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
