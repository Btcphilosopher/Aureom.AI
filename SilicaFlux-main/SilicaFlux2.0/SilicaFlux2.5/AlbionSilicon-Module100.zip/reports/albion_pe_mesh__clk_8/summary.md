# albion_pe_mesh__clk_8

*generated 2026-11-18T15:01:52Z · config `54b0b92b979b` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 23939.2096 µm², 3263 cells, 276 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 82228.86 µm², core 59907.46 µm², std-logic core utilisation 48.6 %
* breakdown µm²: buf_io=1107.31, diode=27.53, decap=0.0, tap=978.44, tie=0.0, clk=1000.96, macro=0.0, hold=120.12, fill=30792.03, std=25881.07

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 3.0959 | 0.1109 | 0 | 0 | 4.9041 | 203.91 | 0 |
| ss | -8.2852 | -0.0626 | 155 | 9 | 16.2852 | 61.41 | 0 |
| tt | -0.0445 | 0.054 | 18 | 0 | 8.0445 | 124.31 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0159 W (internal 0.00764, switching 0.00823, leakage 2.77e-08)
* ss: total 0.0113 W (internal 0.00545, switching 0.00582, leakage 1.65e-05)
* tt: total 0.014 W (internal 0.00678, switching 0.00721, leakage 1.21e-08)

## Routing

* global route: {'resource': 61041, 'demand': 11558, 'usage_pct': 18.93, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 131458, 'routed_nets': 3570, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 26.41, 'overflow': 0}, 'met2': {'usage_pct': 27.22, 'overflow': 0}, 'met3': {'usage_pct': 3.84, 'overflow': 0}, 'met4': {'usage_pct': 4.96, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 87178, 'vias': 23661, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 38017, 'met2': 38974, 'met3': 8278, 'met4': 1908, 'met5': 0}, 'router_elapsed': '00:29:16'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 2, 'pin_violations': 2, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 155
* hold violations at ss: 9
* max slew/cap/fanout violations at ss: 91 (see drv report)
* setup violations at tt: 18

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
