# albion_spm__util_055

*generated 2026-11-18T15:02:46Z · config `52ccd1a4193e` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 15313.4368 µm², 1677 cells, 322 flops, 1 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 350806.45 µm², core 302540.16 µm², std-logic core utilisation 19.81 %
* breakdown µm²: buf_io=1704.13, diode=72.57, decap=0.0, tap=1870.54, tie=7.51, clk=775.74, macro=190712.55, hold=0.0, fill=85400.66, std=17716.99

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| tt | 1.7207 | 0.2127 | 0 | 0 | 18.2793 | 54.71 | 83 |

Unconstrained endpoints: 83 total = 83 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* tt: total 0.00382 W (internal 0.00301, switching 0.000789, leakage 1.9e-05)

## Routing

* global route: {'resource': 118709, 'demand': 14297, 'usage_pct': 12.04, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 141042, 'routed_nets': 2141, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 14.61, 'overflow': 0}, 'met2': {'usage_pct': 13.21, 'overflow': 0}, 'met3': {'usage_pct': 8.56, 'overflow': 0}, 'met4': {'usage_pct': 9.69, 'overflow': 0}, 'met5': {'usage_pct': 1.12, 'overflow': 0}}}
* detailed route: {'wirelength_um': 110035, 'vias': 14849, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 41201, 'met2': 35846, 'met3': 23749, 'met4': 8990, 'met5': 248}, 'router_elapsed': '00:10:15'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 10, 'pin_violations': 10, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* max slew/cap/fanout violations at tt: 19 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
