# albion_spm__flopmem_1k

*generated 2026-11-18T15:02:32Z · config `b0550cedc6da` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **LABEL:** FLOP-BASED MEMORY EXPERIMENT: storage is synthesized into flip-flops. Area and power are NOT representative of an SRAM macro and must not be quoted as SRAM figures.
>
> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | not_run |
| signoff_sta | failed |
| irdrop | failed |
| antenna | failed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 316293.3504 µm², 38111 cells, 8546 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die None µm², core None µm², std-logic core utilisation None %
* breakdown µm²: 

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| tt | None | None | 0 | 0 | None | None | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* tt: total None W (internal None, switching None, leakage None)

## Routing

* global route: {'resource': 643881, 'demand': 309286, 'usage_pct': 48.03, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 2910495, 'routed_nets': 39198, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 49.03, 'overflow': 0}, 'met2': {'usage_pct': 54.2, 'overflow': 0}, 'met3': {'usage_pct': 40.46, 'overflow': 0}, 'met4': {'usage_pct': 45.21, 'overflow': 0}, 'met5': {'usage_pct': 32.53, 'overflow': 0}}}
* detailed route: {'status': 'NOT COMPLETED', 'last_logged_violations': 119387, 'note': 'detailed routing did not finish; no final wirelength/via/DRC figures exist'}

## Physical verification (experimental decks)

* antenna: {'net_violations': None, 'pin_violations': None, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': False}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* detailed routing NOT COMPLETED (last logged router violations: 119387)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
