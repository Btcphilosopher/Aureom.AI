# albion_pe_mesh__util_030

*generated 2026-11-18T15:02:24Z · config `65b65c2be706` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 23939.2096 µm², 3263 cells, 276 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 105551.23 µm², core 80026.75 µm², std-logic core utilisation 36.65 %
* breakdown µm²: buf_io=1104.81, diode=10.01, decap=0.0, tap=1326.27, tie=0.0, clk=950.91, macro=0.0, hold=10.01, fill=50697.37, std=25927.37

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 4.9553 | 0.1573 | 0 | 0 | 5.0447 | 198.23 | 0 |
| ss | -6.8855 | -0.0448 | 136 | 2 | 16.8855 | 59.22 | 0 |
| tt | 1.5905 | 0.1105 | 0 | 0 | 8.4095 | 118.91 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0127 W (internal 0.00607, switching 0.00659, leakage 2.75e-08)
* ss: total 0.00902 W (internal 0.00433, switching 0.00467, leakage 1.64e-05)
* tt: total 0.0112 W (internal 0.00539, switching 0.00577, leakage 1.2e-08)

## Routing

* global route: {'resource': 78388, 'demand': 11594, 'usage_pct': 14.79, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 132466, 'routed_nets': 3552, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 21.29, 'overflow': 0}, 'met2': {'usage_pct': 21.84, 'overflow': 0}, 'met3': {'usage_pct': 1.99, 'overflow': 0}, 'met4': {'usage_pct': 2.01, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 87572, 'vias': 23658, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 38527, 'met2': 40699, 'met3': 7314, 'met4': 1029, 'met5': 0}, 'router_elapsed': '00:08:43'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 4, 'pin_violations': 4, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 136
* hold violations at ss: 2
* max slew/cap/fanout violations at ss: 144 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
