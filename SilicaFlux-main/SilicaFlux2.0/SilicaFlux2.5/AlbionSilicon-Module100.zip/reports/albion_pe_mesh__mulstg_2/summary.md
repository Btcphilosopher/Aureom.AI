# albion_pe_mesh__mulstg_2

*generated 2026-11-18T15:02:03Z · config `a25a12bc105d` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 26151.3312 µm², 3317 cells, 344 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 89440.78 µm², core 66088.38 µm², std-logic core utilisation 47.69 %
* breakdown µm²: buf_io=1131.08, diode=25.02, decap=0.0, tap=1092.3, tie=0.0, clk=1051.01, macro=0.0, hold=10.01, fill=34570.66, std=28208.3

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 4.7924 | 0.1711 | 0 | 0 | 5.2076 | 192.03 | 0 |
| ss | -8.2186 | -0.0958 | 135 | 6 | 18.2186 | 54.89 | 0 |
| tt | 1.1424 | 0.0837 | 0 | 0 | 8.8576 | 112.9 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0134 W (internal 0.00672, switching 0.00666, leakage 2.97e-08)
* ss: total 0.0095 W (internal 0.00478, switching 0.0047, leakage 1.82e-05)
* tt: total 0.0118 W (internal 0.00595, switching 0.00582, leakage 1.32e-08)

## Routing

* global route: {'resource': 65734, 'demand': 11729, 'usage_pct': 17.84, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 134163, 'routed_nets': 3611, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 25.15, 'overflow': 0}, 'met2': {'usage_pct': 26.0, 'overflow': 0}, 'met3': {'usage_pct': 2.98, 'overflow': 0}, 'met4': {'usage_pct': 4.34, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 88086, 'vias': 23990, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 39048, 'met2': 40178, 'met3': 7113, 'met4': 1745, 'met5': 0}, 'router_elapsed': '00:25:16'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 3, 'pin_violations': 3, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 135
* hold violations at ss: 6
* max slew/cap/fanout violations at ss: 146 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
