# albion_spm__cap_2k_1mac

*generated 2026-11-18T15:02:30Z · config `936d66561e11` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 15352.224 µm², 1694 cells, 322 flops, 1 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 569346.05 µm², core 506725.99 µm², std-logic core utilisation 10.92 %
* breakdown µm²: buf_io=1848.02, diode=87.58, decap=0.0, tap=3711.06, tie=7.51, clk=800.77, macro=284538.47, hold=0.0, fill=192534.66, std=17802.07

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| tt | 1.5379 | 0.2423 | 0 | 0 | 18.4621 | 54.17 | 84 |

Unconstrained endpoints: 84 total = 84 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* tt: total 0.00462 W (internal 0.00385, switching 0.000727, leakage 3.55e-05)

## Routing

* global route: {'resource': 212555, 'demand': 15299, 'usage_pct': 7.2, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 151855, 'routed_nets': 2194, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 10.57, 'overflow': 0}, 'met2': {'usage_pct': 7.33, 'overflow': 0}, 'met3': {'usage_pct': 4.01, 'overflow': 0}, 'met4': {'usage_pct': 3.82, 'overflow': 0}, 'met5': {'usage_pct': 0.34, 'overflow': 0}}}
* detailed route: {'wirelength_um': 116593, 'vias': 15426, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 52383, 'met2': 35179, 'met3': 22390, 'met4': 6500, 'met5': 139}, 'router_elapsed': '00:04:52'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 10, 'pin_violations': 11, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* max slew/cap/fanout violations at tt: 15 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
