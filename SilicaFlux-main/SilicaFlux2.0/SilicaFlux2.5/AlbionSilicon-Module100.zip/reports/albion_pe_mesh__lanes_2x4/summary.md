# albion_pe_mesh__lanes_2x4

*generated 2026-11-18T15:02:02Z · config `0e0edfee612b` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 48407.6768 µm², 6444 cells, 548 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 152246.02 µm², core 121236.28 µm², std-logic core utilisation 48.86 %
* breakdown µm²: buf_io=1980.65, diode=57.56, decap=0.0, tap=2033.2, tie=0.0, clk=2026.94, macro=0.0, hold=200.19, fill=62005.72, std=52932.02

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 4.7065 | 0.1358 | 0 | 0 | 5.2935 | 188.91 | 0 |
| ss | -8.5572 | -0.1893 | 273 | 30 | 18.5572 | 53.89 | 0 |
| tt | 0.9782 | 0.0291 | 0 | 0 | 9.0218 | 110.84 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0269 W (internal 0.0128, switching 0.0141, leakage 5.73e-08)
* ss: total 0.0192 W (internal 0.0091, switching 0.0101, leakage 3.33e-05)
* tt: total 0.0237 W (internal 0.0113, switching 0.0124, leakage 2.41e-08)

## Routing

* global route: {'resource': 113055, 'demand': 24625, 'usage_pct': 21.78, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 274889, 'routed_nets': 6984, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 29.12, 'overflow': 0}, 'met2': {'usage_pct': 32.4, 'overflow': 0}, 'met3': {'usage_pct': 4.35, 'overflow': 0}, 'met4': {'usage_pct': 6.86, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 185241, 'vias': 47955, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 76119, 'met2': 85828, 'met3': 17738, 'met4': 5555, 'met5': 0}, 'router_elapsed': '00:19:20'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 2, 'pin_violations': 2, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 273
* hold violations at ss: 30

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
