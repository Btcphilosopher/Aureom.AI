# albion_spm__clk_16

*generated 2026-11-18T15:02:31Z · config `a0ee39fb5730` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 15313.4368 µm², 1677 cells, 322 flops, 1 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 357753.11 µm², core 309046.4 µm², std-logic core utilisation 18.96 %
* breakdown µm²: buf_io=1709.14, diode=22.52, decap=0.0, tap=1978.15, tie=7.51, clk=775.74, macro=190712.55, hold=10.01, fill=91614.12, std=17937.2

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| tt | 0.9606 | 0.3405 | 0 | 0 | 15.0394 | 66.49 | 83 |

Unconstrained endpoints: 83 total = 83 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* tt: total 0.00478 W (internal 0.00377, switching 0.000997, leakage 1.9e-05)

## Routing

* global route: {'resource': 123436, 'demand': 14225, 'usage_pct': 11.52, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 140773, 'routed_nets': 2165, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 14.9, 'overflow': 0}, 'met2': {'usage_pct': 12.14, 'overflow': 0}, 'met3': {'usage_pct': 6.94, 'overflow': 0}, 'met4': {'usage_pct': 10.59, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 108992, 'vias': 14794, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 43641, 'met2': 34424, 'met3': 21305, 'met4': 9620, 'met5': 0}, 'router_elapsed': '00:04:19'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 12, 'pin_violations': 14, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* max slew/cap/fanout violations at tt: 12 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
