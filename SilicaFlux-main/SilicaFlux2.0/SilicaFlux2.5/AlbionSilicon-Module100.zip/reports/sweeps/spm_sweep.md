# Sweep `spm_sweep` (spm)

*generated 2026-11-18T15:03:54Z; 10/11 points complete. All numbers are tool output from the runs in `reports/<run>/summary.json`. Open sky130 PDK; EXPERIMENTAL.*

Score weights (policy, lower is better): {"area": 0.3, "period_tt": 0.25, "power": 0.2, "grt_usage": 0.15, "complexity": 0.1, "gate_failure_penalty": 10}

| rank | point | dimension | die µm² | std µm² | macro µm² | target ns | min period tt ns | setup WS tt | hold WS tt | ss setup WS | power tt mW | GRT use % | GRT ovf | DRT viol | wire µm | hold bufs | P&R s | score |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | `clk_16` | clock target | 357753.11 | 15313.4368 | 190712.55 | 16.0 | 15.0394 | 0.9606 | 0.3405 | n/a | 4.78 | 11.52 | 0 | 0 | 108992 | 1 | 296.3 | 0.1583 |
| 2 | `mpos_west` | macro position | 357753.11 | 15313.4368 | 190712.55 | 20.0 | 18.2879 | 1.7121 | 0.3129 | n/a | 3.63 | 10.79 | 0 | 0 | 102306 | 0 | 381.2 | 0.1915 |
| 3 | `util_030` | utilisation | 366436.44 | 15313.4368 | 190712.55 | 20.0 | 18.1983 | 1.8017 | 0.1782 | n/a | 3.79 | 10.81 | 0 | 0 | 107750 | 0 | 323.9 | 0.2013 |
| 4 | `s_base` | baseline | 357753.11 | 15313.4368 | 190712.55 | 20.0 | 18.2576 | 1.7424 | 0.2018 | n/a | 3.83 | 11.59 | 0 | 0 | 109990 | 0 | 369.6 | 0.2093 |
| 5 | `mpos_north` | macro position | 357753.11 | 15313.4368 | 190712.55 | 20.0 | 18.1434 | 1.8566 | 0.1744 | n/a | 3.82 | 11.6 | 0 | 0 | 110791 | 0 | 534.5 | 0.2113 |
| 6 | `util_055` | utilisation | 350806.45 | 15313.4368 | 190712.55 | 20.0 | 18.2793 | 1.7207 | 0.2127 | n/a | 3.82 | 12.04 | 0 | 0 | 110035 | 0 | 668.1 | 0.2211 |
| 7 | `clk_25` | clock target | 357753.11 | 15313.4368 | 190712.55 | 25.0 | 22.2672 | 2.7328 | 0.2447 | n/a | 3.08 | 11.57 | 0 | 0 | 109731 | 0 | 371.8 | 0.2976 |
| 8 | `cap_2k_1mac` | SRAM capacity | 569346.05 | 15352.224 | 284538.47 | 20.0 | 18.4621 | 1.5379 | 0.2423 | n/a | 4.62 | 7.2 | 0 | 0 | 116593 | 0 | 339.3 | 0.34 |
| 9 | `cap_2k_2bank` | SRAM banks/width | 962438.05 | 18081.0912 | 381425.1 | 20.0 | 18.9338 | 1.0662 | 0.3436 | n/a | 6.06 | 5.91 | 0 | 0 | 188479 | 1 | 470.7 | 0.6416 |
| 10 | `mpos_east` | macro position | 357753.11 | 15313.4368 | 190712.55 | 20.0 | 19.2894 | 0.7106 | 0.1279 | n/a | 4.32 | 26.53 | 3121 | 4871 | 236497 | 0 | 2818.1 | 10.4836 |
| – | `flopmem_1k` | FLOP-BASED memory (labelled experiment) | **incomplete** | failed stages: ['antenna', 'irdrop', 'signoff_sta'] | | | | | | | | | | | | | | |
