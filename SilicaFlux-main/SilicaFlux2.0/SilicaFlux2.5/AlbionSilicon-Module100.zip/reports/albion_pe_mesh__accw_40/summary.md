# albion_pe_mesh__accw_40

*generated 2026-11-18T15:01:43Z · config `b9a608911332` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 26450.368 µm², 3389 cells, 308 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 89996.31 µm², core 66563.84 µm², std-logic core utilisation 48.45 %
* breakdown µm²: buf_io=1246.2, diode=15.01, decap=0.0, tap=1092.3, tie=0.0, clk=1000.96, macro=0.0, hold=10.01, fill=34314.16, std=28885.2

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 4.1278 | 0.1618 | 0 | 0 | 5.8722 | 170.29 | 0 |
| ss | -10.3358 | -0.1219 | 171 | 10 | 20.3358 | 49.17 | 0 |
| tt | 0.0706 | 0.068 | 0 | 0 | 9.9294 | 100.71 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0144 W (internal 0.00688, switching 0.00753, leakage 3.07e-08)
* ss: total 0.0103 W (internal 0.00491, switching 0.00533, leakage 1.85e-05)
* tt: total 0.0127 W (internal 0.0061, switching 0.0066, leakage 1.31e-08)

## Routing

* global route: {'resource': 66835, 'demand': 12483, 'usage_pct': 18.68, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 142250, 'routed_nets': 3713, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 26.44, 'overflow': 0}, 'met2': {'usage_pct': 27.25, 'overflow': 0}, 'met3': {'usage_pct': 3.02, 'overflow': 0}, 'met4': {'usage_pct': 3.9, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 94597, 'vias': 24792, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 41718, 'met2': 43256, 'met3': 8049, 'met4': 1573, 'met5': 0}, 'router_elapsed': '00:32:36'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 2, 'pin_violations': 2, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 171
* hold violations at ss: 10
* max slew/cap/fanout violations at ss: 177 (see drv report)
* max slew/cap/fanout violations at tt: 130 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
