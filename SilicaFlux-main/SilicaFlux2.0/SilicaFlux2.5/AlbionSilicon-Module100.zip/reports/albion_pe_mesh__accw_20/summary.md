# albion_pe_mesh__accw_20

*generated 2026-11-18T15:01:42Z · config `04765eba192c` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 20901.296 µm², 2573 cells, 228 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 73927.15 µm², core 52856.94 µm², std-logic core utilisation 47.05 %
* breakdown µm²: buf_io=838.3, diode=10.01, decap=0.0, tap=870.84, tie=0.0, clk=875.84, macro=0.0, hold=10.01, fill=27988.09, std=22263.85

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 5.7563 | 0.1804 | 0 | 0 | 4.2437 | 235.64 | 0 |
| ss | -5.3335 | -0.0563 | 88 | 7 | 15.3335 | 65.22 | 0 |
| tt | 2.6481 | 0.1026 | 0 | 0 | 7.3519 | 136.02 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.0111 W (internal 0.00555, switching 0.00554, leakage 2.32e-08)
* ss: total 0.00791 W (internal 0.00397, switching 0.00392, leakage 1.46e-05)
* tt: total 0.00979 W (internal 0.00493, switching 0.00485, leakage 1.05e-08)

## Routing

* global route: {'resource': 55002, 'demand': 9309, 'usage_pct': 16.92, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 106598, 'routed_nets': 2811, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 23.22, 'overflow': 0}, 'met2': {'usage_pct': 24.67, 'overflow': 0}, 'met3': {'usage_pct': 3.66, 'overflow': 0}, 'met4': {'usage_pct': 4.07, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 69875, 'vias': 19012, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 30613, 'met2': 31531, 'met3': 6328, 'met4': 1401, 'met5': 0}, 'router_elapsed': '00:09:13'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 2, 'pin_violations': 2, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 88
* hold violations at ss: 7

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
