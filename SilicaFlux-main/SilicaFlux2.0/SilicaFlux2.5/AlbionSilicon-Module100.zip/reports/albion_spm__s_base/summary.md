# albion_spm__s_base

*generated 2026-11-18T15:02:43Z · config `a269a8ae51c6` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 15313.4368 µm², 1677 cells, 322 flops, 1 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 357753.11 µm², core 309046.4 µm², std-logic core utilisation 19.02 %
* breakdown µm²: buf_io=1709.14, diode=85.08, decap=0.0, tap=1978.15, tie=7.51, clk=775.74, macro=190712.55, hold=0.0, fill=91545.3, std=17953.47

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| tt | 1.7424 | 0.2018 | 0 | 0 | 18.2576 | 54.77 | 83 |

Unconstrained endpoints: 83 total = 83 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* tt: total 0.00383 W (internal 0.00301, switching 0.000805, leakage 1.9e-05)

## Routing

* global route: {'resource': 123428, 'demand': 14306, 'usage_pct': 11.59, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 141850, 'routed_nets': 2164, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 14.75, 'overflow': 0}, 'met2': {'usage_pct': 12.66, 'overflow': 0}, 'met3': {'usage_pct': 7.08, 'overflow': 0}, 'met4': {'usage_pct': 9.8, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 109990, 'vias': 14911, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 43635, 'met2': 35402, 'met3': 21706, 'met4': 9245, 'met5': 0}, 'router_elapsed': '00:05:00'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 9, 'pin_violations': 9, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* max slew/cap/fanout violations at tt: 12 (see drv report)

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
