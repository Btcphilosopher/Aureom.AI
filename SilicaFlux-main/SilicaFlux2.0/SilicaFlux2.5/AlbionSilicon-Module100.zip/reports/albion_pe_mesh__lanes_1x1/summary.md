# albion_pe_mesh__lanes_1x1

*generated 2026-11-18T15:01:48Z · config `4f31cf93ba11` · PDK `sky130hd` (**open_public_experimental**, signoff_eligible=False)*

> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; `null` / `not_run` means the measurement does not exist.

## Stages

| stage | status |
|---|---|
| techcheck | passed |
| lint | passed |
| verify_rtl | passed |
| synth | passed |
| gls | passed |
| sdc | passed |
| sta_pre | passed |
| plan | passed |
| floorplan | passed |
| place | passed |
| cts | passed |
| groute | passed |
| droute | passed |
| signoff_sta | passed |
| irdrop | passed |
| antenna | passed |
| drc | not_run |
| lvs | not_run |
| report | passed |

## Synthesis

* standard-cell area 6238.4832 µm², 782 cells, 70 flops, 0 macros, latches (RTL/mapped) 0/0

## Area / utilisation (final database)

* die 27926.78 µm², core 15655.01 µm², std-logic core utilisation 48.14 %
* breakdown µm²: buf_io=352.84, diode=2.5, decap=0.0, tap=270.26, tie=0.0, clk=225.22, macro=0.0, hold=10.01, fill=8119.04, std=6675.15

## Timing (post-route, OpenRCX + OpenSTA)

| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |
|---|---|---|---|---|---|---|---|
| ff | 5.2205 | 0.1755 | 0 | 0 | 4.7795 | 209.23 | 0 |
| ss | -6.4166 | 0.2494 | 33 | 0 | 16.4166 | 60.91 | 0 |
| tt | 1.9902 | 0.2809 | 0 | 0 | 8.0098 | 124.85 | 0 |

Unconstrained endpoints: 0 total = 0 constant-driven (no launching path exists: tie-cell outputs / unused macro port) + 0 other (genuine constraint gaps).

## Power (vectorless; activity assumed, NOT measured)

* ff: total 0.00267 W (internal 0.00139, switching 0.00128, leakage 6.97e-09)
* ss: total 0.00188 W (internal 0.000982, switching 0.000894, leakage 4.24e-06)
* tt: total 0.00234 W (internal 0.00123, switching 0.00111, leakage 3.01e-09)

## Routing

* global route: {'resource': 20839, 'demand': 2401, 'usage_pct': 11.52, 'max_h_overflow': 0, 'max_v_overflow': 0, 'total_overflow': 0, 'wirelength_um': 29325, 'routed_nets': 885, 'per_layer': {'li1': {'usage_pct': 0.0, 'overflow': 0}, 'met1': {'usage_pct': 15.34, 'overflow': 0}, 'met2': {'usage_pct': 18.07, 'overflow': 0}, 'met3': {'usage_pct': 1.64, 'overflow': 0}, 'met4': {'usage_pct': 1.37, 'overflow': 0}, 'met5': {'usage_pct': 0.0, 'overflow': 0}}}
* detailed route: {'wirelength_um': 18329, 'vias': 5472, 'final_violations': 0, 'wirelength_by_layer_um': {'li1': 0, 'met1': 8357, 'met2': 8524, 'met3': 1283, 'met4': 164, 'met5': 0}, 'router_elapsed': '00:05:19'}

## Physical verification (experimental decks)

* antenna: {'net_violations': 0, 'pin_violations': 0, 'engine': 'openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck'}
* IR-drop screen: {'log': None, 'ok': True}
* EM: {'status': 'not_run', 'reason': 'no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)'}
* DRC: None
* LVS: None

## Violations

* setup violations at ss: 33

## Readiness

**EXPERIMENTAL (open PDK)** — tapeout_ready = False

* technology is an open public PDK (experimental); no production-qualified kit
* no foundry signoff DRC/LVS/antenna/density decks run
* no signoff-grade parasitic extraction or multi-corner/OCV STA
* no DFT insertion, ATPG or MBIST
* no I/O pad ring / ESD / package model
* no PLL / clock IP
* no vector-based power or EM/IR signoff
* no foundry-qualified SRAM compiler output (OpenRAM macros used as published)
