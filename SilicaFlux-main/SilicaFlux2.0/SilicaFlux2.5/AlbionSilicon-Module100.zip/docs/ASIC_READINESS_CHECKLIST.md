# ASIC-readiness checklist

Legend: ✅ done and evidenced in this archive · 🟡 done in a limited/experimental form (see note) · ❌ not done · ⛔ cannot be done with open tools / this PDK.
"Evidence" points at the report or log that backs the tick. **No row below may be ticked ✅ for a production-signoff item.**

## A. Source and verification
| item | status | evidence / note |
|---|---|---|
| Subsystem selected by audit, not by README | ✅ | `reports/audit/`, doc 01 |
| Upstream self-checking regression re-run on this toolchain | ✅ | `reports/audit/logs/`, `build/*/verify_rtl/` |
| Real macro model exercised in simulation (not just blackbox) | ✅ | 26/26 + >10,000 macro-model events (KI-002) |
| Netlist gate-level simulation with foundry cell models | 🟡 | zero-delay functional only (KI-005) |
| RTL↔netlist equivalence checking | ❌ | not run |
| Formal proofs for the integration | ❌ | upstream proofs exist for sub-blocks; none re-run |
| Coverage closure | ❌ | not measured |

## B. Technology
| item | status | note |
|---|---|---|
| Public PDK configured with hash-pinned data | ✅ | `techcheck`, manifest |
| Macro views (LEF/Liberty/GDS/Verilog) + interface cross-check | ✅ | 11 buses / 121 pins agree |
| Production PDK / libraries / compiled memories | ⛔ | doc 11 #1–3 |
| Multi-corner libraries for the macro | ⛔ | OpenRAM TT only |

## C. Implementation
| item | status | note |
|---|---|---|
| Synthesis, latch-free, area report | ✅ | both baselines |
| SDC with clock/uncertainty/IO/loads; exceptions only with justification | ✅ | none applied, with reasons (doc 04) |
| Unconstrained paths reported and classified | ✅ | B: 83 constant-driven, 0 gaps |
| Floorplan, macro placement, halos, blockages, I/O plan, PDN | ✅ | legality-checked and re-verified in the DB |
| Global/detailed placement, CTS, global/detailed route | ✅ | 0 router violations, both baselines |
| Extraction + STA at tt | ✅ | OpenRCX with PDK rules |
| ss/ff screening | 🟡 | Design A only; A fails ss at 10 ns (KI-017) |
| Timing closure at all signoff corners | ❌ | |
| Hold/setup ECO after routing | ❌ | |

## D. Physical verification
| item | status | note |
|---|---|---|
| DRC (Magic + KLayout open decks) | 🟡 | engines disagree (KI-010/011) |
| LVS (logic, macro black-boxed) | 🟡 | A and B baselines; macro internals not checked |
| Antenna | 🟡 | B has residual violations (KI-016) |
| IR drop | 🟡 | vectorless, assumption-dependent (KI-014) |
| Electromigration | 🟡 | PDN peak-current screen only (KI-013) |
| Foundry DRC/LVS/antenna/density/ERC decks | ⛔ | |
| Metal fill, seal ring, GDS stream-out to foundry spec | ❌ | |

## E. Products needed to ship silicon
| item | status |
|---|---|
| DFT: scan, JTAG, MBIST, ATPG | ❌ |
| I/O pad ring, ESD, bump/RDL | ❌ |
| PLL / clock IP / clock gating / reset+CDC | ❌ |
| Package + board co-design, SSN, thermal | ❌ |
| Test program, bring-up plan, yield/binning | ❌ |
| Foundry signoff sign-off sheet | ❌ |

## Gate summary

* `albion gates --tier experimental` — enforced on every run. **Design A passes** (24 gates; 3 warnings: the ss-corner setup/hold/DRV screening results). **Design B FAILS** one gate: `antenna` (9 net violations remaining after detailed routing, KI-016); 17 gates pass, 1 warning (tt max-slew at macro input pins, KI-012). The gate is left red on purpose.
* `albion gates --tier tapeout` — **fails by construction** here; CI requires that it stays failed.
