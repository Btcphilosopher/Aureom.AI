# 06 · Floorplanning (brief §6)

Two layers, deliberately independent: **`plan.py` computes numbers**, **`checker` approves them**, **OpenROAD executes and re-verifies**.

| brief item | how |
|---|---|
| Die / core dimensions | from synthesised standard-cell area ÷ target utilisation (+ macro footprint with halos for macro designs), aspect ratio, snapped to the 0.46 × 2.72 µm `unithd` site read from the tech LEF; `floorplan.core_margin_um` die-to-core gap. |
| Placement utilisation | `floorplan.utilization` = std-cell area / placeable core area (core − macro − halo). Reported pre-place target, final value (with taps, buffers, CTS cells, diodes) and the area breakdown. |
| Macro placement | `floorplan.macro_layout`: `anchor` (west/east/north/south/sw/…/center), `arrangement` (row/column), `gap_um`, optional explicit coordinates. FIRM placement, orientation R0, grid-snapped. |
| Placement blockages / halos | each macro gets a halo (`macro_halo_um`, default 20 µm) enforced as a hard **placement blockage** (`dbBlockage`) and as the clearance the legality checker demands; macro PDN halo 2 µm. |
| I/O planning | `floorplan.io.groups`: regex → edge(s). Pins are assigned per bit, split across multi-edge groups, **placed after a first global placement** (`place_pins`, met2 vertical / met3 horizontal) so pin order follows real cell positions. The checker rejects an edge that needs > 50 % of its raw track slots (I/O-limited die). |
| Power-grid planning | tap cells every 14 µm; `met1` follow-pins (0.48 µm), `met4` (1.6 µm, 27.14 µm pitch), `met5` (1.6 µm, 27.2 µm pitch); a **macro grid** with met4–met5 connections. Connectivity is machine-checked (`check_power_grid` VDD and VSS). |

## Independent legality checker (`plan.check_plan`) – can it fail? yes, and a test proves it

Rejects: core outside die; coordinates off the site/row grid; macro closer to the core edge than its halo; overlapping macro halos;
unassigned pins; I/O-limited edges; no placeable area. `tests/test_planner.py` constructs each illegal case and requires rejection
(this even caught my own sloppy test fixture, which was off-grid).

After OpenROAD executes the plan, the floorplan stage **re-reads the database** and compares every macro's bounding box, status (FIRM), core clearance
and the blockage count against the plan; any mismatch fails the stage.

## Defects found and fixed here (so they are not silently re-introduced)

* **Tap cells had unconnected power pins** (`PDN-0189`) because `global_connect` ran before `tapcell`; fixed (re-run after every instance-adding stage:
  taps, buffers, CTS, diodes, fillers). Design A's first route predated the fix and was redone.
* **Signal-pin count vs port count:** PDN generation adds VDD/VSS terminals; the pin count is now taken over `SIGNAL` terminals only and must equal the
  synthesised port-bit count.

* **Placement density vs utilisation (KI-032):** a 55 % utilisation floorplan aborted global placement (`GPL-0302`) because the default target density (0.55) was
  below what utilisation + tap cells need. The effective density is now `max(configured, utilisation + 0.10)` and is recorded per run.
* **Planner clamp bug (KI-026):** `east`/`north` macro anchors could land one site past the halo limit; the independent checker caught it.

## Limits

No pad ring / bump map (pins are plain metal at the die edge); no seal ring; no region/fence constraints (logic placement is not partitioned);
macro placement is rule-based (anchors), not optimised; the PDN recipe is the community sky130 recipe, not a package-co-designed grid.
