# 07 · Physical implementation (brief §7)

All stages run in OpenROAD 2.0-12381 (conda, Feb 2024 build) through `scripts/tcl/*.tcl`; the Tcl contains **no design knowledge** (everything
arrives through `build/<run>/env.tcl` and `plan.tcl`). A stage refuses to run unless its prerequisite is recorded OK in `build/<run>/state.json`.

| stage | script | what runs | executed for both designs |
|---|---|---|---|
| floorplan | `floorplan.tcl` | `initialize_floorplan`, `make_tracks`, macro placement + blockages, global connect, `tapcell`, PDN (`pdngen`), DB re-check | yes |
| global placement | `place.tcl` | `global_placement -skip_io` → `place_pins` → `global_placement -routability_driven -timing_driven` | yes |
| detailed placement | `place.tcl` | `buffer_ports`, `repair_design`, `detailed_placement`, `check_placement` | yes |
| clock-tree synthesis | `cts.tcl` | TritonCTS (clkbuf_4/8/16, sink clustering 20 / 50 µm), `repair_clock_nets`, post-CTS `repair_timing -setup -hold` with **propagated clocks** | yes |
| global routing | `groute.tcl` | `global_route` (adjustment 0.2, congestion report), **antenna repair** (`repair_antennas`, diode insertion) + incremental re-route | yes |
| detailed routing | `droute.tcl` | TritonRoute met1–met5 until 0 violations; std-cell fillers; `write_db/def/verilog/sdc` | yes (0 router violations on both baselines) |
| parasitic extraction | `signoff_sta.tcl` | **OpenRCX with the rule files shipped with the PDK** (`rules.openrcx.sky130A.{min,nom,max}.calibre`), `write_spef` | yes |
| static timing analysis | `signoff_sta.tcl` | per corner: setup/hold WNS/TNS, violating endpoints, worst paths, DRV, skew, `check_setup`, power | tt (+ ss, ff for Design A) |

Stage timings are in `state.json`; TritonRoute dominates (single-threaded: ~5–9 min per baseline on one core), which is why sweeps run in parallel.

## Timing at every stage is recorded, not just at the end

`RESULTS.md` shows tt setup/hold at post-place (estimated parasitics), post-CTS before and after repair, post-global-route, and post-route (extracted).
Design A shows the textbook CTS effect: hold violations appear only after the clock tree exists and are then repaired.

## Conventions that matter when reading the numbers

* "Utilisation" = std-logic area ÷ (core − macros). Fillers/decaps are excluded; taps, I/O buffers, clock cells, hold cells, diodes are included.
* "min period / Fmax (derived)" = `P − worst_setup_slack` at the stated corner; the slack already includes the clock-uncertainty budget. It is derived
  from one run at one target, not a separate closure search.
* Wirelength: global-route estimate vs TritonRoute's own total; per-layer split is reported.
* Power: OpenSTA `report_power` with **vectorless activity 0.2 at all inputs** (assumption, labelled) + the macro's published Liberty internal power.

## Limits

Single-threaded; no useful-skew or multi-corner-aware CTS; `repair_timing` runs at tt only; no routing-layer or NDR tuning; no timing ECO after
routing (post-route STA is analysis only); no metal density fill; no antenna repair after detail route (KI-016).
