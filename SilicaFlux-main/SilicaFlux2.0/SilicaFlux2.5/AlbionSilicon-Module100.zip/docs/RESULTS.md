# RESULTS (generated)

*Generated 2026-11-18T15:06:36Z by `albion docgen` from `reports/`. Do not edit by hand. EXPERIMENTAL open-PDK results; nothing here is tapeout evidence.*

## Tool versions

```
{
 "yosys": "Yosys 0.33 (git sha1 2584903a060)",
 "verilator": "Verilator 5.020 2024-01-01 rev (Debian 5.020-1)",
 "iverilog": "Icarus Verilog version 12.0 (stable) ()",
 "openroad": "2.0-12381-g01bba3695",
 "klayout": "KLayout 0.28.16",
 "magic": "8.3.465",
 "netgen": "installed",
 "python": "3.13.18"
}
```

## Design A - albion_pe_mesh (TensorCore-01 INT8 MAC mesh)

run `albion_pe_mesh__base` · config `4835794d0370` · 2026-11-18T15:06:35Z

| stage | status |
|---|---|
| antenna | passed |
| cts | passed |
| drc | passed |
| droute | passed |
| floorplan | passed |
| gls | passed |
| groute | passed |
| irdrop | passed |
| lint | passed |
| lvs | passed |
| place | passed |
| plan | passed |
| report | (this stage writes the table) |
| sdc | passed |
| signoff_sta | passed |
| sta_pre | passed |
| synth | passed |
| techcheck | passed |
| verify_rtl | passed |

### Source and netlist verification

* RTL (upstream self-checking testbench, re-run here): ok=True · detail `{"backdoor_checker_live": null, "n_pass": null, "n_runs": null, "note": null, "scenarios": [{"alignment_failures": [], "cycles": 934, "msgs": [], "ok": true, "scenario": "base", "tiles": 24, "token_errors": 0, "tokens_checked": 1564}, {"alignment_failures": [], "cycles": 1508, "msgs": [], "ok": true, "scenario": "overflow", "tiles": 24, "token_errors": 0, "tokens_checked": 2328}], "vendor_macro_mo`
* gate-level netlist simulation (foundry cell models): ok=True · checks=None

### Synthesis (Yosys 0.33, abc, sky130_fd_sc_hd tt)

* standard-cell area **23939.2 µm²** · 3263 cells · 276 flops · 0 macro(s) · latches (RTL/mapped) 0/0 · 213 port bits

### Floorplan

* die [0.0, 0.0, 285.2, 288.32] µm, core [20.24, 21.76, 264.96, 266.56] µm, target std-logic utilisation 0.4 (upper bound; achieved before placement 0.3996), halo [20.0, 20.0] µm, legality check: True
* macros: []
* I/O pins per edge: {'east': 88, 'north': 16, 'south': 87, 'west': 22}

### Area (final database)

| class | µm² |
|---|---|
| buf_io | 1107.31 |
| clk | 1025.98 |
| core | 59907.46 |
| decap | 0.0 |
| die | 82228.86 |
| diode | 10.01 |
| fill | 30977.21 |
| hold | 10.01 |
| macro | 0.0 |
| std | 25798.49 |
| std_logic_core_utilization_pct | 48.29 |
| tap | 978.44 |
| tie | 0.0 |

### Timing (post-route, OpenRCX with PDK rules + OpenSTA)

| corner | setup WS ns | hold WS ns | setup viol | hold viol | min period ns (derived) | Fmax MHz (derived) | power mW (vectorless) |
|---|---|---|---|---|---|---|---|
| ff | 4.936 | 0.170 | 0 | 0 | 5.064 | 197.5 | 12.700 |
| ss | -6.904 | -0.055 | 136 | 10 | 16.904 | 59.2 | 9.040 |
| tt | 1.574 | 0.104 | 0 | 0 | 8.426 | 118.7 | 11.200 |

Unconstrained endpoints: 0 total = 0 constant-driven + 0 other. Timing exceptions applied: 0.

### Timing at each stage (tt)

| stage | setup WS ns | hold WS ns | hold violations |
|---|---|---|---|
| pre_layout_ideal_clock | 1.785 | 0.299 | None |
| post_place_est | 1.576 | 0.398 | 0 |
| post_cts_before_repair | 1.575 | -0.039 | 96 |
| post_cts_after_repair | 1.575 | 0.106 | 0 |
| post_groute_est | 1.106 | 0.139 | 0 |

### Clock tree

```
[INFO CTS-0010]  Clock net "clk_i" has 276 sinks.
[INFO CTS-0018]     Created 41 clock buffers.
[INFO CTS-0012]     Minimum number of buffers in the clock path: 3.
[INFO CTS-0017]     Max level of the clock tree: 2.
[INFO CTS-0098] Clock net "clk_i"
[INFO CTS-0099]  Sinks 276
```

### Routing

* global: usage 18.92 %, overflow 0, wirelength 131265 µm, 3555 nets; per layer {"li1": {"overflow": 0, "usage_pct": 0.0}, "met1": {"overflow": 0, "usage_pct": 26.54}, "met2": {"overflow": 0, "usage_pct": 27.14}, "met3": {"overflow": 0, "usage_pct": 3.82}, "met4": {"overflow": 0, "usage_pct": 4.68}, "met5": {"overflow": 0, "usage_pct": 0.0}}
* detailed: violations 0, wirelength 87288 µm, vias 23571, by layer {'li1': 0, 'met1': 38452, 'met2': 39131, 'met3': 7892, 'met4': 1813, 'met5': 0}, router wall time 00:19:14

### Physical verification (EXPERIMENTAL open decks; none is a foundry signoff run)

* antenna (OpenROAD, tech-LEF rules): 0 net / 0 pin violations
* IR drop (ideal, 135 supply sources): worst VDD 0.000502 V + VSS 0.000301 V = 0.0446 % of supply
* IR drop (corners, 4 supply sources): worst VDD 0.0021 V + VSS 0.00133 V = 0.1906 % of supply
* EM screen: {"avg_segment_current_a": 4.82e-05, "engine": "OpenROAD PSM -enable_em (PDN only)", "interpretation": "FLAG, not a verdict: peak element is not identified by this PSM version. If it is a single via the via reference applies; if it is a strap segment the strap reference applies. Needs a signoff EM tool.", "not_covered": "signal/clock-net EM, AC/RMS limits, via arrays, thermal derating, vector-based currents", "peak_over_limit": 4.9722, "peak_over_strap_limit": 0.3996, "peak_segment_current_a": 0.00179, "reference_limit_a": 0.00036, "reference_limit_basis": "techLEF DCCURRENTDENSITY AVERAGE 0.36 mA per via (Iavg_max @ 90C); most restrictive entry", "screen_pass": false, "strap_reference_limit_a": 0.00448}
* DRC instrument self-test: {'klayout_detects': True, 'klayout_unconfigured_detects': False, 'magic_detects': True}
* DRC klayout_drc: total 27, outside macros 27, inside macro bboxes 0, rules 3, top rules [['npc.2', 15], ['psd.2', 8], ['nsd.2', 4]]
* DRC magic_drc: total 0, outside macros None, inside macro bboxes None, rules 0, top rules []
* LVS: equivalent=True, devices [3520, 3520], nets [3557, 3557], pin lists equivalent True; excluded device-less cells {'sky130_fd_sc_hd__fill_1': 1312, 'sky130_fd_sc_hd__fill_2': 1257, 'sky130_fd_sc_hd__fill_4': 831, 'sky130_fd_sc_hd__fill_8': 2201, 'sky130_fd_sc_hd__tapvpwrvgnd_1': 782}; scope: full design LVS

### Violations / readiness

* setup violations at ss: 136
* hold violations at ss: 10
* max slew/cap/fanout violations at ss: 20 (see drv report)

**EXPERIMENTAL (open PDK)** - tapeout_ready = False

## Design B - albion_spm (M04 scratchpad on a real OpenRAM sky130 macro)

run `albion_spm__base` · config `d03733451d87` · 2026-11-18T15:06:36Z

| stage | status |
|---|---|
| antenna | passed |
| cts | passed |
| drc | passed |
| droute | passed |
| floorplan | passed |
| gls | passed |
| groute | passed |
| irdrop | passed |
| lint | passed |
| lvs | passed |
| place | passed |
| plan | passed |
| report | (this stage writes the table) |
| sdc | passed |
| signoff_sta | passed |
| sta_pre | passed |
| synth | passed |
| techcheck | passed |
| verify_rtl | passed |

### Source and netlist verification

* RTL (upstream self-checking testbench, re-run here): ok=True · detail `{"backdoor_checker_live": true, "n_pass": 26, "n_runs": 26, "note": "upstream TB patched at run time: MACRO param forwarded + ASIC backdoor path to vendor model mem; upstream never ran BACKEND=ASIC", "scenarios": null, "vendor_macro_model_log_events": 10282}`
* gate-level netlist simulation (foundry cell models): ok=True · checks=1284

### Synthesis (Yosys 0.33, abc, sky130_fd_sc_hd tt)

* standard-cell area **15313.4 µm²** · 1677 cells · 322 flops · 1 macro(s) · latches (RTL/mapped) 0/0 · 407 port bits

### Floorplan

* die [0.0, 0.0, 638.48, 560.32] µm, core [20.24, 21.76, 618.24, 538.56] µm, target std-logic utilisation 0.4 (upper bound; achieved before placement 0.1876), halo [20.0, 20.0] µm, legality check: True
* macros: [{"cell": "sky130_sram_1kbyte_1rw1r_32x256_8", "h": 397.5, "name": "g_core.g_bank[0].u_bank.genblk3.g_ram.u_ram.genblk6.genblk1.g_asic.u_mem.g_r[0].g_c[0].g_sky130.u_leaf.g_1.u_macro", "w": 479.78, "x": 79.58, "y": 81.6}]
* I/O pins per edge: {'east': 344, 'north': 0, 'south': 0, 'west': 63}

### Area (final database)

| class | µm² |
|---|---|
| buf_io | 1709.14 |
| clk | 775.74 |
| core | 309046.4 |
| decap | 0.0 |
| die | 357753.11 |
| diode | 85.08 |
| fill | 91545.3 |
| hold | 0.0 |
| macro | 190712.55 |
| std | 17953.47 |
| std_logic_core_utilization_pct | 19.02 |
| tap | 1978.15 |
| tie | 7.51 |

### Timing (post-route, OpenRCX with PDK rules + OpenSTA)

| corner | setup WS ns | hold WS ns | setup viol | hold viol | min period ns (derived) | Fmax MHz (derived) | power mW (vectorless) |
|---|---|---|---|---|---|---|---|
| tt | 1.742 | 0.202 | 0 | 0 | 18.258 | 54.8 | 3.830 |

Unconstrained endpoints: 83 total = 83 constant-driven + 0 other. Timing exceptions applied: 0.

### Timing at each stage (tt)

| stage | setup WS ns | hold WS ns | hold violations |
|---|---|---|---|
| pre_layout_ideal_clock | 3.040 | 0.358 | None |
| post_place_est | 2.251 | 0.377 | 0 |
| post_cts_before_repair | 1.821 | 0.215 | 0 |
| post_cts_after_repair | 1.821 | 0.215 | 0 |
| post_groute_est | 1.752 | 0.202 | 0 |

### Clock tree

```
[INFO CTS-0010]  Clock net "clk" has 324 sinks.
[INFO CTS-0018]     Created 31 clock buffers.
[INFO CTS-0012]     Minimum number of buffers in the clock path: 2.
[INFO CTS-0017]     Max level of the clock tree: 2.
[INFO CTS-0098] Clock net "clk"
[INFO CTS-0099]  Sinks 324
[INFO RSZ-0033] No hold violations found.
```

### Routing

* global: usage 11.59 %, overflow 0, wirelength 141850 µm, 2164 nets; per layer {"li1": {"overflow": 0, "usage_pct": 0.0}, "met1": {"overflow": 0, "usage_pct": 14.75}, "met2": {"overflow": 0, "usage_pct": 12.66}, "met3": {"overflow": 0, "usage_pct": 7.08}, "met4": {"overflow": 0, "usage_pct": 9.8}, "met5": {"overflow": 0, "usage_pct": 0.0}}
* detailed: violations 0, wirelength 109990 µm, vias 14911, by layer {'li1': 0, 'met1': 43635, 'met2': 35402, 'met3': 21706, 'met4': 9245, 'met5': 0}, router wall time 00:09:30

### Physical verification (EXPERIMENTAL open decks; none is a foundry signoff run)

* antenna (OpenROAD, tech-LEF rules): 9 net / 9 pin violations
* IR drop (ideal, 703 supply sources): worst VDD 0.00014 V + VSS 0.000248 V = 0.0216 % of supply
* IR drop (corners, 4 supply sources): worst VDD 0.00133 V + VSS 0.0016 V = 0.1628 % of supply
* EM screen: {"avg_segment_current_a": 1.31e-05, "engine": "OpenROAD PSM -enable_em (PDN only)", "interpretation": "FLAG, not a verdict: peak element is not identified by this PSM version. If it is a single via the via reference applies; if it is a strap segment the strap reference applies. Needs a signoff EM tool.", "not_covered": "signal/clock-net EM, AC/RMS limits, via arrays, thermal derating, vector-based currents", "peak_over_limit": 1.9361, "peak_over_strap_limit": 0.1556, "peak_segment_current_a": 0.000697, "reference_limit_a": 0.00036, "reference_limit_basis": "techLEF DCCURRENTDENSITY AVERAGE 0.36 mA per via (Iavg_max @ 90C); most restrictive entry", "screen_pass": false, "strap_reference_limit_a": 0.00448}
* DRC instrument self-test: {'klayout_detects': True, 'klayout_unconfigured_detects': False, 'magic_detects': True}
* DRC klayout_drc: total 31, outside macros 31, inside macro bboxes 0, rules 4, top rules [['psd.2', 14], ['nsd.2', 12], ['licon.13', 3], ['npc.2', 2]]
* DRC magic_drc: total 2832369, outside macros 0, inside macro bboxes 2832369, rules 32, top rules [['N-Diffusion spacing to N-well < 0.34um (diff/tap.9)', 308037], ['Local interconnect width < 0.17um (li.1)', 232703], ['poly overlap of poly contact < 0.05um (licon.8)', 189088], ['poly overhang of SRAM core transistor < 0.11um (poly.8)', 187200], ['Diffusion width < 0.15um (diff/tap.1)', 186032], ['N-diffusion overlap of N-diffusion contact < 0.04um (licon.5a)', 180183], ['poly contact spacing to diffusion < 0.19um (licon.14)', 173454], ['Via1 width < 0.26um (via.1a + 2 * via.4a)', 163020]]
* LVS: equivalent=True, devices [2088, 2088], nets [2200, 2200], pin lists equivalent True; excluded device-less cells {'sky130_fd_sc_hd__fill_1': 1736, 'sky130_fd_sc_hd__fill_2': 1641, 'sky130_fd_sc_hd__fill_4': 811, 'sky130_fd_sc_hd__fill_8': 8113, 'sky130_fd_sc_hd__tapvpwrvgnd_1': 1581}; scope: top-level LVS; SRAM macro internals treated as black boxes on both sides (macro-internal LVS belongs to the macro vendor and was not run)

### Violations / readiness

* max slew/cap/fanout violations at tt: 12 (see drv report)

**EXPERIMENTAL (open PDK)** - tapeout_ready = False

# Parameter sweeps

# Sweep `pe_mesh_sweep` (pe_mesh)

*generated 2026-11-18T15:03:54Z; 12/12 points complete. All numbers are tool output from the runs in `reports/<run>/summary.json`. Open sky130 PDK; EXPERIMENTAL.*

Score weights (policy, lower is better): {"area": 0.3, "period_tt": 0.25, "power": 0.2, "grt_usage": 0.15, "complexity": 0.1, "gate_failure_penalty": 10}

| rank | point | dimension | die µm² | std µm² | macro µm² | target ns | min period tt ns | setup WS tt | hold WS tt | ss setup WS | power tt mW | GRT use % | GRT ovf | DRT viol | wire µm | hold bufs | P&R s | score |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | `lanes_1x1` | compute lanes | 27926.78 | 6238.4832 | 0.0 | 10.0 | 8.0098 | 1.9902 | 0.2809 | -6.4166 | 2.34 | 11.52 | 0 | 0 | 18329 | 1 | 392.5 | 0.0638 |
| 2 | `accw_20` | bus/acc width | 73927.15 | 20901.296 | 0.0 | 10.0 | 7.3519 | 2.6481 | 0.1026 | -5.3335 | 9.79 | 16.92 | 0 | 0 | 69875 | 1 | 620.0 | 0.1526 |
| 3 | `util_030` | utilisation | 105551.23 | 23939.2096 | 0.0 | 10.0 | 8.4095 | 1.5905 | 0.1105 | -6.8855 | 11.2 | 14.79 | 0 | 0 | 87572 | 1 | 709.5 | 0.2782 |
| 4 | `noadder_map` | synthesis recipe | 83540.12 | 24312.0672 | 0.0 | 10.0 | 8.3676 | 1.6324 | 0.0902 | -7.0706 | 11.6 | 18.19 | 0 | 0 | 84989 | 1 | 549.8 | 0.2818 |
| 5 | `clk_12` | clock target | 82228.86 | 23939.2096 | 0.0 | 12.0 | 8.3893 | 3.6107 | 0.0212 | -4.8266 | 9.34 | 18.81 | 0 | 0 | 86801 | 0 | 994.9 | 0.2932 |
| 6 | `s_base` | baseline | 82228.86 | 23939.2096 | 0.0 | 10.0 | 8.4263 | 1.5737 | 0.1042 | -6.9038 | 11.2 | 18.92 | 0 | 0 | 87288 | 1 | 652.2 | 0.2954 |
| 7 | `util_055` | utilisation | 63067.99 | 23939.2096 | 0.0 | 10.0 | 8.4435 | 1.5565 | 0.0865 | -6.9851 | 11.2 | 24.11 | 0 | 0 | 85788 | 1 | 934.4 | 0.3398 |
| 8 | `mulstg_2` | pipeline depth | 89440.78 | 26151.3312 | 0.0 | 10.0 | 8.8576 | 1.1424 | 0.0837 | -8.2186 | 11.8 | 17.84 | 0 | 0 | 88086 | 1 | 1894.3 | 0.3765 |
| 9 | `accw_40` | bus/acc width | 89996.31 | 26450.368 | 0.0 | 10.0 | 9.9294 | 0.0706 | 0.068 | -10.3358 | 12.7 | 18.68 | 0 | 0 | 94597 | 1 | 2320.6 | 0.5079 |
| 10 | `lanes_2x4` | compute lanes | 152246.02 | 48407.6768 | 0.0 | 10.0 | 9.0218 | 0.9782 | 0.0291 | -8.5572 | 23.7 | 21.78 | 0 | 0 | 185241 | 20 | 1344.6 | 0.5438 |
| 11 | `lanes_4x4` | compute lanes | 285677.74 | 96926.7104 | 0.0 | 10.0 | 8.9465 | 1.0535 | 0.0752 | -8.5793 | 46.9 | 25.42 | 0 | 0 | 402141 | 68 | 3507.5 | 0.9047 |
| 12 | `clk_8` | clock target | 82228.86 | 23939.2096 | 0.0 | 8.0 | 8.0445 | -0.0445 | 0.054 | -8.2852 | 14.0 | 18.93 | 0 | 0 | 87178 | 12 | 2143.7 | 10.3189 |


![pe_mesh_sweep](../reports/sweeps/pe_mesh_sweep.svg)

# Sweep `spm_sweep` (spm)

*generated 2026-11-18T15:03:54Z; 10/11 points complete. All numbers are tool output from the runs in `reports/<run>/summary.json`. Open sky130 PDK; EXPERIMENTAL.*

Score weights (policy, lower is better): {"area": 0.3, "period_tt": 0.25, "power": 0.2, "grt_usage": 0.15, "complexity": 0.1, "gate_failure_penalty": 10}

| rank | point | dimension | die µm² | std µm² | macro µm² | target ns | min period tt ns | setup WS tt | hold WS tt | ss setup WS | power tt mW | GRT use % | GRT ovf | DRT viol | wire µm | hold bufs | P&R s | score |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | `clk_16` | clock target | 357753.11 | 15313.4368 | 190712.55 | 16.0 | 15.0394 | 0.9606 | 0.3405 | n/a | 4.78 | 11.52 | 0 | 0 | 108992 | 1 | 296.3 | 0.1583 |
| 2 | `mpos_west` | macro position | 357753.11 | 15313.4368 | 190712.55 | 20.0 | 18.2879 | 1.7121 | 0.3129 | n/a | 3.63 | 10.79 | 0 | 0 | 102306 | 0 | 381.2 | 0.1915 |
| 3 | `util_030` | utilisation | 366436.44 | 15313.4368 | 190712.55 | 20.0 | 18.1983 | 1.8017 | 0.1782 | n/a | 3.79 | 10.81 | 0 | 0 | 107750 | 0 | 323.9 | 0.2013 |
| 4 | `s_base` | baseline | 357753.11 | 15313.4368 | 190712.55 | 20.0 | 18.2576 | 1.7424 | 0.2018 | n/a | 3.83 | 11.59 | 0 | 0 | 109990 | 0 | 369.6 | 0.2093 |
| 5 | `mpos_north` | macro position | 357753.11 | 15313.4368 | 190712.55 | 20.0 | 18.1434 | 1.8566 | 0.1744 | n/a | 3.82 | 11.6 | 0 | 0 | 110791 | 0 | 534.5 | 0.2113 |
| 6 | `util_055` | utilisation | 350806.45 | 15313.4368 | 190712.55 | 20.0 | 18.2793 | 1.7207 | 0.2127 | n/a | 3.82 | 12.04 | 0 | 0 | 110035 | 0 | 668.1 | 0.2211 |
| 7 | `clk_25` | clock target | 357753.11 | 15313.4368 | 190712.55 | 25.0 | 22.2672 | 2.7328 | 0.2447 | n/a | 3.08 | 11.57 | 0 | 0 | 109731 | 0 | 371.8 | 0.2976 |
| 8 | `cap_2k_1mac` | SRAM capacity | 569346.05 | 15352.224 | 284538.47 | 20.0 | 18.4621 | 1.5379 | 0.2423 | n/a | 4.62 | 7.2 | 0 | 0 | 116593 | 0 | 339.3 | 0.34 |
| 9 | `cap_2k_2bank` | SRAM banks/width | 962438.05 | 18081.0912 | 381425.1 | 20.0 | 18.9338 | 1.0662 | 0.3436 | n/a | 6.06 | 5.91 | 0 | 0 | 188479 | 1 | 470.7 | 0.6416 |
| 10 | `mpos_east` | macro position | 357753.11 | 15313.4368 | 190712.55 | 20.0 | 19.2894 | 0.7106 | 0.1279 | n/a | 4.32 | 26.53 | 3121 | 4871 | 236497 | 0 | 2818.1 | 10.4836 |
| – | `flopmem_1k` | FLOP-BASED memory (labelled experiment) | **incomplete** | failed stages: ['antenna', 'irdrop', 'signoff_sta'] | | | | | | | | | | | | | | |


![spm_sweep](../reports/sweeps/spm_sweep.svg)

