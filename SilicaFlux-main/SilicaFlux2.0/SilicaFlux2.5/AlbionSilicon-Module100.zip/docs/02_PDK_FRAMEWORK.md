# 02 · Technology configuration / PDK framework (brief §2)

## Principle

A **profile** (`config/pdk/<name>.yaml`) is the only place technology facts live. The flow never carries a technology number of its own: every
path, corner, cell name, layer, and macro view comes from the active profile, and `albion pdk-check` (stage `techcheck`) fails if any referenced
file is missing, null, or has the wrong hash. *No generic physical assumptions are substituted for foundry data.*

| | `sky130hd` (used) | `commercial_template` (not usable) |
|---|---|---|
| `pdk_class` | `open_public_experimental` | `commercial_production` |
| `signoff_eligible` | hard-wired **false** | false until a signed evidence bundle exists |
| data | SkyWater SKY130 + `sky130_fd_sc_hd` + OpenRAM macros, all public (Apache-2.0) | **every field null**; `pdk-check` FAILS with 34 named gaps |

Experimental open-PDK results and any future commercial-node signoff are separated *structurally*: `pdk_class` is stamped into every report, the
`tapeout` gate requires `commercial_production`, and the report's readiness block always lists the open-PDK blockers.

## What the `sky130hd` profile pins

* **From the installed PDK package** (conda `litex-hub::open_pdks.sky130a 1.0.471`): tech LEF (nominal), std-cell LEF/GDS/Verilog/CDL,
  Liberty at **tt_025C_1v80, ss_100C_1v60, ff_n40C_1v95**, the **OpenRCX rule files shipped with the PDK (min/nom/max)**, the Magic tech + rc, the
  Netgen LVS setup, the KLayout DRC deck.
* **From OpenROAD-flow-scripts `sky130hd`** (BSD-3, copied verbatim, SHA-256 recorded in `config/pdk/sky130hd.manifest.json`): per-layer RC
  estimate script (`setRC.tcl`, used only for pre-route estimates), PDN/tap recipes, filler list. *Unpinned `master`* – the GitHub API needed to
  resolve a commit was unavailable (KI-019); the recorded hashes are the reproducibility anchor.
* **SRAM macros** – *the PDK package contains none.* They are fetched from `efabless/sky130_sram_macros` at the **exact commit recorded in the
  SilicaFlux sramlib manifests** (`ebfbf5775c8c…`). `albion fetch-pdk` re-downloads them and **verifies the SHA-256 of the Verilog model, LEF and
  LICENSE against the values the SilicaFlux manifest recorded** (all match – an independent provenance check, and covered by a test that tampers
  with a hash and expects failure).
* **Macro interface cross-check** (`techcheck`): LEF pins ⇔ vendor Verilog ports ⇔ Liberty pins must agree on name, direction and width
  (11 buses / 121 signal pins for the 1 KiB macro). A negative control perturbs one width and must be caught.
* **Liberty `dont_use` filtering:** Yosys 0.33's `abc` has no `-dont_use`, so a filtered Liberty copy is generated (probe and `lpflow_*` cells
  removed, brace-matched, cached in `build/_shared/`).

## Corners and what they mean here

Only the **default corner (tt)** is optimised (placement, CTS, repair). ss and ff are *off-nominal screening* corners run at the end with the
matching OpenRCX rule set (`max` for ss, `min` for ff). A design that closes at tt and fails ss is a **reported result** (non-default corners are
warnings in the `experimental` gate tier and blockers in the `tapeout` tier). **OpenRAM published only a TT Liberty**, so macro designs are
analysed at tt only; the flow skips ss/ff for them and says so (`skipped_corners`).

## Adding a real technology

Copy `commercial_template.yaml`, fill every field with licensed deliverables (commit only their hashes), bind the signoff engines under
`signoff:`, set `pdk_class: commercial_production`. Until each entry exists the profile cannot pass `pdk-check`.
