# 01 · Repository audit and source selection (brief §1)

**Rule applied:** start from the *smallest genuinely synthesizable and functionally verified* subsystem; never from an unverified full processor.
"Verified" was not taken from a README: every claim that mattered was **re-run with this programme's toolchain**
(Verilator 5.020, Icarus 12.0, Yosys 0.33) and the logs are kept in `reports/audit/logs/`.

## Method

1. **Inventory** (`python3 -m albion audit`, output `reports/audit/repo_inventory.json`): every SilicaFlux archive, including nested archives
   (depth ≤ 3), scanned for HDL and physical-design assets. Result: **155 archives** carrying 7,390 HDL file entries (nested duplicates counted)
   but only 55 SDC, 15 LEF, 15 Liberty, 21 DEF files. There is very little physical-design collateral relative to RTL.
2. **Shortlist** by function: compute lanes, memory with a real-macro path, and small enough to run the full flow in minutes.
3. **Re-verify** each shortlisted block: lint, upstream regression target, and a generic Yosys synthesis to *measure* size (`reports/audit/candidates.json`).
4. **Probe gaps** the READMEs do not mention (found two; see "Findings").

## Candidates (all numbers measured here unless marked upstream-reported)

| candidate | generic cells / flops | re-run evidence | decision |
|---|---|---|---|
| **TensorCore-01 `tensor_pe_mesh`** (INT8 MAC mesh) | 3,262 / 276 (2×2); 817 / 140 (one PE) | `make lint` clean; `make quick` **PASS in 103.4 s** (reference model, lint, PE sim Verilator + Icarus, mesh, config checks) | **SELECTED – Design A (compute)** |
| **M04 `hpc_scratchpad`** + sramlib ASIC backend | 1,677 / 322 + 1 macro (as configured) | `make spm-quick`: lint 11/11, invalid-parameter rejection 27/27, stage-1 **133/133**, PASSED in 254.7 s | **SELECTED – Design B (memory + real macro)** |
| SRAMCore P71 `sf_sram_core` | behavioural array | `make sram-quick`: lint 64/64, sim 11/11 | not selected: no real-macro path (M04 + sramlib carries it) |
| M01 FP32 FMA | 8,663 / 418 | upstream: TestFloat/SoftFloat bit-exact (not re-run) | not selected: 2.6× the mesh for one unit, no lane knob |
| M02 FP32 vector lane | 22,475 / 2,354 | upstream-reported only | not selected: 6.9× the mesh |
| M03 vector array / M08 tile | N × M02 + scratchpad + DMA + scheduler | upstream: 145/145 integration (simulation) | not selected: the "first big design" the brief forbids |
| ALBION_MIN (`sf_albion_cloud_top`) | *upstream-reported* 53,304 sky130 cells, 8,494 flops, 472,011 µm² | upstream: 33 sim tests, 6 formal checks; physical flow "configured, not executed" | not selected: RV32 core + DMA + fabric + 4 × (4096×39) macros that do not exist as open macros |
| P40 FLOORPLANBUILD | – | – | **not usable as evidence** (see KI-001) |

## Why A and B (and not one design)

The brief asks to sweep SRAM capacity, bus width, compute-lane count, clock, utilisation and macro position. No existing small *verified* block has
both a lane array and a macro, and writing an unverified integration wrapper would break the selection rule. So the programme runs **two** small
verified subsystems through the *same* gated flow:

* **A `albion_pe_mesh`** – lane count = ROWS×COLS (a parameter), no memory: isolates logic, clock tree, congestion, multi-corner timing.
* **B `albion_spm`** – capacity / banks are parameters, **real OpenRAM sky130 macro** (LEF + Liberty + GDS + vendor Verilog): isolates macro
  integration, PDN to a macro, macro-dominated timing, macro placement.

## Findings from the audit (all recorded in `KNOWN_ISSUES.md`)

* **KI-001** The P40 archive README cites `physical/silicaflux/{scripts,tech,results}`; **none of those files are in the archive**. Its numbers
  cannot be reproduced from this repository and are not used. (Its RTL is also a stand-in DieTop, not real RTL.)
* **KI-002** M04's ASIC backend was **never simulated upstream**: its testbench hard-codes `.MACRO(0)` and reaches into the *GENERIC* array by
  hierarchical path for its whole-array backdoor check. This programme closes that gap with a documented runtime patch (two edits + an ASIC
  branch pointing at the vendor model's `mem`), keeping the vendored file untouched (`build/<run>/verify_rtl/tb_patch.diff`), and runs the
  upstream testbench against the real OpenRAM model: **26/26 runs pass** (13 tests × 2 seeds), the macro model emits >10,000 log events
  (proof it was exercised), and the backdoor checker self-test is live.
* **KI-003** The same testbench **fails 13/13 tests with `PERF_EN=0`** (it checks the performance counters in every test). The implemented
  configuration is therefore `PERF_EN=1`, the verified one, even though it costs area (≈ the 32-bit counters). A smaller variant would have
  been *unverified*.

## What "verified" means in this programme

For each design the flow **cannot proceed past `verify_rtl`** unless the upstream self-checking testbench passes on the configured parameters,
and cannot proceed past `gls` unless the *synthesized* netlist, simulated with the foundry's own cell models, reproduces the same results
(Design A: same stimulus and the same independent Python GEMM reference, 3,892 result tokens; Design B: an AlbionSilicon-authored front-door
testbench, because the upstream one uses RTL hierarchical paths that do not exist in a flat netlist – validated on the RTL first, and shown to
detect an injected stuck-at fault). This is a functional smoke gate, **not** a coverage or equivalence-checking claim.
