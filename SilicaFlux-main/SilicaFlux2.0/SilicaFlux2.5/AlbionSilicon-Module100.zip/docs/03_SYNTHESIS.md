# 03 · Synthesis (brief §3)

Stage `synth` (`scripts/albion/synth.py`, Yosys 0.33). Everything below is *executed*, not planned.

| brief item | implementation |
|---|---|
| RTL elaboration | `read_verilog -defer -sv` + `hierarchy -check -top T -chparam K V …` (parameters applied *during* elaboration; `-defer` is required because the sramlib leaf modules `FATAL` at parse time with default parameters). Preceded by `lint`: Verilator `-Wall` (simulation view, like upstream) and Yosys `hierarchy -check; proc; check -assert` (synthesis view). Un-waived warnings fail; every waiver needs a ≥ 20-character justification and is listed in the report. |
| Logic optimisation | `synth -run :fine`, `opt`, `extract_fa` + ORFS `cells_adders_hd.v` (full/half-adder cells), `techmap`, `opt`. |
| Sequential-cell mapping | `dfflibmap -liberty` (sky130 `dfrtp`/`dfxtp` family). |
| Technology mapping | `abc -liberty <filtered tt lib> -constr -D <period_ps>` (speed mode, clock target passed to ABC). |
| Tie cells / buffers | `hilomap` (`conb_1`), `insbuf` (`buf_4`) so no constants or bare assigns reach the netlist. |
| **Latch detection** | (1) after `proc`: `select -count t:$dlatch t:$adlatch t:$dlatchsr`; (2) after mapping: cell-name scan against `dlx*/dlr*/dlclk*/sdl*`. **Any latch fails the stage** unless `synth.allow_latches` is set. |
| Netlist generation | `write_verilog -noattr` + `write_json` (the JSON supplies ports, widths and macro instances to the SDC generator and planner). |
| Area reporting | `stat -liberty` → `std_cell_area_um2` (standard cells only; macro area comes from the LEF in the planner). |
| Macros | read as blackboxes from the vendor Verilog (`read_verilog -lib`); the exact count must survive synthesis (the flow checks it). |

## Gates around synthesis

* **before:** `verify_rtl` – the upstream testbench must pass on the *configured* parameters.
* **after:** `gls` – the netlist is simulated with the foundry cell models and must reproduce the same results. The packaged sky130 Verilog models
  are timing-aware (`specify` blocks, `$setuphold`, `D_delayed` nets) and Icarus does not implement the delayed nets, so every flop output stays X.
  `functionalize()` strips the `specify` block and ties each `<pin>_delayed` to `<pin>`; logic, UDP tables and reset behaviour are the foundry's
  own (KI-005). GLS is therefore **zero-delay functional**; it does not exercise timing checks.
* Negative controls (in `tests/`): a stuck-at-0 on one macro data pin must make the GLS testbench fail (it does: 98 errors); the same testbench
  passes on the clean netlist.

## Honest limits

No equivalence checking (RTL vs netlist), no formal proof on the new flow, no scan/DFT mapping, no retiming, single synthesis recipe (the
`synth.abc_effort`/`extra_yosys` knobs exist but were not swept).
