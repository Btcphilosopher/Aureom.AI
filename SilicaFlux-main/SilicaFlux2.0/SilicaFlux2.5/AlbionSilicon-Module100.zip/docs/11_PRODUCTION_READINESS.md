# 11 · Production readiness (brief §11)

> **Neither design is tapeout ready, and this programme does not describe either as such.** "Tapeout ready" requires production-qualified
> libraries, physical verification with foundry decks, test infrastructure and foundry signoff. **None of these exist here.** The machine-readable
> form is `albion gates --tier tapeout`, which is *designed to fail* on an open PDK and prints the blocker list; CI inverts its exit code to prove it
> stays red.

## What this programme did demonstrate

* A **reproducible, gated RTL → GDS flow** exists in this repository, runs on a real (open) PDK, and was executed through **every** physical-design
  stage for two *verified* SilicaFlux subsystems (one with a real SRAM macro), with all reports traceable to tool output.
* The flow's checks **can fail** (instrument self-tests) and several real defects were found and fixed *by* those checks (KI-008, 009, 022, 025–027).
* The two designs go **RTL → verified netlist → placed → clocked → routed with 0 router violations → extracted → STA** at the default corner, with
  LVS equivalence of the logic (macro black-boxed) on the baselines.

That is a statement about the **flow and the blocks on an educational-class technology**, not about a SilicaFlux chip.

## Missing prerequisites for tapeout

| # | prerequisite | state here | consequence |
|---|---|---|---|
| 1 | **Production PDK** (foundry-qualified, NDA, signoff corner matrix, versioned) | sky130 open PDK, `pdk_class: open_public_experimental`; 3 corners, community RC | no number here predicts a commercial node; `commercial_template.yaml` fails `pdk-check` by design |
| 2 | **Production standard-cell libraries** (multi-Vt, ECO/spare/decap/fill sets, characterised across the full PVT/RC matrix) | `sky130_fd_sc_hd` single flavour; only tt optimised | no multi-Vt power/timing trade-off; ss fails at 10 ns for Design A |
| 3 | **SRAM macros** from the foundry/vendor compiler for the target node, with all-corner Liberty, BIST/redundancy | OpenRAM published macros: **TT Liberty only**, 2 sizes, `max_transition 0.04 ns` on inputs, no redundancy/BIST | macro designs have no ss/ff timing; macro interior not signoff-checked (KI-011/012) |
| 4 | **I/O libraries** (pads, ESD, level shifters, bump/RDL) | none: pins are bare metal at the die edge | no pad ring, no ESD, no I/O timing model beyond an assumed 30 % budget |
| 5 | **Clock and PLL IP**, clock gating, reset/CDC infrastructure | none; ideal clock port, TritonCTS tree, no PLL, no gating | no on-die clock source, jitter model or CDC verification |
| 6 | **DFT insertion** (scan, JTAG, MBIST, ATPG) | **none**; flops are non-scan, no MBIST for the macro | zero test coverage; unmanufacturable at volume (KI-018) |
| 7 | **Foundry signoff** (DRC/LVS/antenna/density/ERC decks; SI-aware STA with OCV/AOCV/POCV; signoff RC; dynamic IR/EM; formal equivalence RTL↔netlist) | community decks, OpenRCX/OpenSTA/PSM; **no** OCV/SI, no signoff EM, no equivalence check, no density fill, no seal ring | all checks are advisory (`signoff_accepted: false`) |
| 8 | **Package integration** (bump map, RDL, power/ground planning with package parasitics, thermal) | none; IR uses assumed supply points (KI-014) | no real IR/thermal/SSN picture |
| 9 | **Test development** (production test program, bring-up, characterisation, yield/binning) | none | – |
| 10 | **Power signoff** (vector/emulation-based activity, power-grid + decap closure) | vectorless 0.2 activity | power numbers are estimates |
| 11 | **Verification closure** (coverage, formal, gate-level with SDF, power-aware sim) | upstream self-checking regressions re-run; zero-delay GLS | no coverage closure claim, no timing GLS |
| 12 | **Release process** (DRC-clean GDS from the foundry stream-out, MPW/shuttle submission, legal) | Magic-written GDS only (KI-024) | no submission artefact |

## Suggested order of work (no schedule claimed)

1. Re-run on the **same designs** with a real (even if shuttle-class) PDK profile: this is the cheapest way to learn how much of the flow ports.
2. Bind a signoff-grade extraction + STA and re-measure corners (the open ss result for Design A shows how far a single-corner flow can mislead).
3. Add scan/MBIST to the verified blocks **before** scaling up (`tensor_pe` is a natural DFT-friendly unit).
4. Replace the OpenRAM macros with compiler output for the target node; carry all-corner Liberty/LEF/GDS through `config/pdk/`.
5. Only then move up to M03/M08-class blocks and ALBION_MIN.

See `ASIC_READINESS_CHECKLIST.md` for the item-level checklist with current status.
