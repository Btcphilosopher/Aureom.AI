# 10 · Design experiments (brief §10)

## Method

* One-factor-at-a-time sweeps around each baseline (`config/sweeps/*.yaml`), run in parallel by `albion sweep`.
* **Every point runs the same gated flow**: lint → source verification → synthesis → gate-level simulation → SDC → floorplan → placement → CTS →
  global + detailed route → OpenRCX/STA → IR/antenna → report. A variant that fails a gate is listed as *incomplete* with the failing stage; it is never
  silently dropped or patched into passing. (Points that initially stopped, and what each exposed, are listed under "Defects found by the sweeps".)
* DRC/LVS are **skipped for sweep points** (macro DRC ≈ 12 min; KI-023); they are run on the baselines.
* `s_base` is an **independent re-run of the baseline** in the sweep: it must reproduce the baseline exactly (it does – `tests/test_flow_results.py`).
* One run per point. OpenROAD is deterministic on one machine, so there is **no confidence interval**; differences between points are real for *that
  configuration on that machine*, and say nothing about run-to-run noise on other platforms.

## Axes

| brief axis | Design A (`pe_mesh`) | Design B (`spm`) |
|---|---|---|
| SRAM capacity | – | 1 KiB macro (baseline) vs **2 KiB as one 32×512 macro** vs **2 KiB as two 1 KiB macros (2 banks)** |
| bus width | accumulator width ACC_W 20 / **32** / 40 (datapath width). *Operand width and the scratchpad's DATA_WIDTH were not swept (see below).* | DATA_WIDTH fixed at 32: the macro catalogue and the verified TB path support 32-bit words only |
| compute-lane count | 1×1, **2×2**, 2×4, 4×4 PEs (1, 4, 8, 16) | – |
| pipeline depth (extra) | MUL_STAGES 1 / 2 | – |
| clock target | 8 / **10** / 12 ns | 16 / **20** / 25 ns |
| floorplan utilisation | 0.30 / **0.40** / 0.55 | 0.30 / **0.40** / 0.55 |
| macro positioning | – | **centre**, west, east, north |
| labelled flop-array comparison | – | `flopmem_1k`: same 1 KiB as flip-flops (**not an SRAM figure**) |

## Ranking (a stated policy, not a physical law)

`score = 10·[tt setup/hold/overflow/DRC failure] + 0.30·norm(die area) + 0.25·norm(min period at tt) + 0.20·norm(power) + 0.15·norm(GRT usage) + 0.10·norm(P&R wall time)`,
`norm` = min–max over completed points of the same sweep (lower is better). The **per-metric table is the result**; the score only orders it.
Trade-off axes: **P**ower = vectorless tt power; **P**erformance = derived min period at tt; **A**rea = die area; **R**outability = global-route usage /
overflow / detailed-route violations; **I**mplementation complexity = P&R wall-clock + repair cells inserted (a *proxy*; there is no agreed unit).

## Reading the numbers safely

* min period / Fmax are derived from one run at one target (not a closure search), tt only; ss is reported separately for Design A.
* Power is vectorless (activity 0.2 on all inputs): it ranks *structure*, it does not predict real workloads.
* Die area is set by the planner from utilisation and (for B) macro footprint; for macro designs the macro dominates, so die-area differences mostly
  reflect macro choice, not logic.
* Wall-clock is affected by how many flows share the machine.

## Findings

All values below are copied from `reports/sweeps/*_sweep.{md,json}` (generated from `reports/<run>/summary.json`). One run per point, open sky130,
tt unless stated, vectorless power. **None of these is a prediction for another node, tool version or workload.** Baselines: A = 2×2 mesh at 10 ns,
B = 1 KiB OpenRAM macro at 20 ns.

### Design A — `albion_pe_mesh` (12/12 points complete, 0 detailed-route violations everywhere)

| axis | points | what was measured |
|---|---|---|
| compute lanes | 1, 4, 8, 16 PEs | std-cell area 6,238 / 23,939 / 48,408 / 96,927 µm² (≈ linear: 6.2k µm² per lane at 1 lane, 6.1k at 16); power 2.34 / 11.2 / 23.7 / 46.9 mW; detailed wirelength 18.3k / 87.3k / 185k / 402k µm (wire per lane grows 18.3k → 25.1k µm, +37 %); GRT usage 11.5 / 18.9 / 21.8 / 25.4 %; hold-repair buffers 1 / 1 / 20 / 68 |
| lane count vs speed | same | derived min period 8.01 / 8.43 / 9.02 / 8.95 ns. **Non-monotonic** (4×4 is 0.07 ns *faster* than 2×4); with one run per point and no noise estimate this is read as "roughly flat to +1 ns", not as a trend. ss setup at 10 ns is negative at every size (−6.4 … −8.6 ns) |
| accumulator width | ACC_W 20 / 32 / 40 | min period 7.35 / 8.43 / 9.93 ns; std area 20.9k / 23.9k / 26.5k µm²; the **40-bit point closes tt by only +0.07 ns**. The critical path is a ripple (`maj3`) carry chain in the accumulator, so period grows ≈ linearly with width |
| pipeline depth | MUL_STAGES 1 → 2 | min period **8.86 ns vs 8.43 (worse by 0.43)**, area +9.2 %, power +5 %. Hypothesis "pipelining the multiplier helps" is **not supported**: the multiplier is not the critical path, the extra stage adds flops and clock load |
| synthesis recipe | ORFS adder map off (`noadder_map`) | min period 8.37 vs 8.43 ns (−0.06), area +1.6 %. Hypothesis "the ORFS adder map shortens the carry path" is **not supported** by this data (difference is below what one run can resolve) |
| clock target | 8 / 10 / 12 ns | **8 ns fails tt by 0.045 ns** (12 hold buffers, power 14.0 mW, +25 %); 10 ns closes (+1.57); 12 ns closes (+3.61, power 9.34 mW, −17 %). Derived min period barely moves between 10 and 12 ns (8.43 / 8.39): the design is logic-limited near 8.0–8.4 ns at tt. Power tracks clock at fixed vectorless activity |
| utilisation | 0.30 / 0.40 / 0.55 | die 105.6k / 82.2k / 63.1k µm² (+28 % / −23 %); GRT usage 14.8 / 18.9 / 24.1 %; wirelength 87.6k / 87.3k / 85.8k µm (±2 %); min period 8.41 / 8.43 / 8.44. At this size, 0.55 routes clean with no measurable timing penalty. Larger lane counts at 0.55 were **not** run, so congestion at scale is untested |

Cross-corner note: every Design A point fails the ss screening corner (the flow optimises at tt only, KI-017); ss numbers were therefore not used to rank.

### Design B — `albion_spm` (10/11 complete; 1 labelled experiment not routed)

Baseline: macro 190,713 µm² + std logic 15,313 µm², die 357,753 µm². The macro is 12.5× the logic.

| axis | points | what was measured |
|---|---|---|
| SRAM capacity (one macro) | 1 KiB → 2 KiB (32×512 macro) | macro area ×1.49 for ×2 capacity; die **+59 %** (569.3k µm²); power +21 % (4.62 mW); wirelength +6 %; min period 18.46 vs 18.26 ns |
| SRAM capacity (two banks) | 2 × 1 KiB macros | die **+169 %** (962.4k µm²); std logic +18 %; power +58 % (6.06 mW); wirelength +71 %. For the same 2 KiB, one 32×512 macro takes **41 % less die** than two 1 KiB banks in this planner. The two are *not functionally equivalent* (banking allows concurrent access), so this is a cost of banking in this flow, not a recommendation |
| clock target | 16 / 20 / 25 ns | 16 ns closes tt (+0.96 ns, power +25 %); 25 ns closes (+2.73, power −20 %). The derived min period (15.04 / 18.26 / 22.27 ns) **tracks the target**, so it is *not* an Fmax: repair stops at zero slack and the macro-limited floor was not found. Only "16 ns closes at tt" is a conclusion; anything below 16 ns is untested. Macro Liberty is TT only, so there is no ss/ff result |
| utilisation | 0.30 / 0.40 / 0.55 | die 366.4k / 357.8k / 350.8k µm² (+2.4 % / −1.9 %). The planner sizes the core from macro + halo footprint, so this knob is nearly inert for macro designs; wirelength 107.8k / 110.0k / 110.0k µm |
| macro position | centre / west / north / **east** | west: wirelength **−7 %** (102.3k vs 110.0k µm), power −5 %, 0 violations. north: +0.7 % wirelength, 0 violations, 0 hold buffers. **east: did not converge, see below** |

**`mpos_east` (macro at the east edge): routing did not converge within its budget.** This point was run with `drc_iterations = 8` (default flow: 64) to bound
wall time. After 8 iterations TritonRoute reported **4,871 violations** (baseline: 0); global routing overflow 3,121; GRT usage 26.5 % (baseline 11.6 %);
detailed wirelength 236.5k µm (+115 %); 27 net antenna violations; router time 46 min (baseline: minutes). tt setup +0.71 ns. By the sweep's own policy it is a
**failure** (score 10.48) and must not be read as a usable layout. **Not established:** whether 64 iterations would converge (not run: ≈ 6 h by naive extrapolation of 46 min per 8 iterations),
and *why* east fails while west, with a symmetric 98 µm logic channel, routes clean. Facts that bear on it but were **not** tested as causes: input pins are on the
west edge and outputs on the east edge; the macro's pins are mostly on its south face (74 of 121 signal pins by LEF centre). The only general lesson supported
here is that *macro position is a first-order routability variable and has to be checked, not assumed symmetric.* (KI-033.)

**`flopmem_1k` — FLOP-BASED MEMORY EXPERIMENT. Not an SRAM figure, never to be quoted as one.** The same 1 KiB held in flip-flops instead of the macro:

| | macro version (`s_base`) | flop array (`flopmem_1k`) |
|---|---|---|
| flops / std cells | 322 / 1,677 (+1 macro) | **8,546 / 38,111** |
| std-cell area | 15,313 µm² (+ macro 190,713) | **316,293 µm²** (1.54× macro + logic of the macro version) |
| die | 357,753 µm² | 867,764 µm² (2.43×) |
| global-route wirelength | 141,850 µm | 2,910,495 µm (20.5×); usage 48 %, 0 overflow |
| tt setup / hold after global route (estimate) | +1.74 / +0.20 ns (post-detail) | +3.83 / +0.07 ns (estimate only) |
| detailed routing | complete, 0 violations | **NOT COMPLETED** — stopped by this programme for time at 119,387 router violations (an intermediate count, not a result); no DRC, LVS, IR, antenna or signoff STA exist for this point |

What this says: at 1 KiB a synthesized flop array costs about 1.5× the silicon of the OpenRAM macro plus its logic and is unroutable on a reasonable budget here; what it does
**not** say is anything about SRAM power or area in a production memory compiler (the macro here is itself an open OpenRAM design). The flop array is useful only as a
functional stand-in and as a sanity bound.

### Trade-off summary (P, P, A, R, I)

| | Power | Performance | Area | Routability | Implementation complexity |
|---|---|---|---|---|---|
| more lanes (A) | linear | roughly flat (≤ 1 ns) | linear | wire/lane +37 % at 16 lanes, 0 violations | P&R time ×9 for ×16 lanes (shared machine, indicative) + hold buffers 1 → 68 |
| wider accumulator (A) | +30 % (20→40 bit) | period +35 % (7.35→9.93 ns) | +27 % std | clean | small |
| extra mult stage (A) | +5 % | worse | +9 % | clean | none gained |
| higher utilisation (A) | flat | flat | die −23 % | usage +5 pts, clean | longer P&R |
| bigger/banked SRAM (B) | +21 % / +58 % | flat | die +59 % / +169 % | clean | banked: 2 macros, wirelength +71 % |
| macro position (B) | −5 % west | flat | flat | **east fails (4,871 violations at cap)** | a bad position costs hours |

### Defects found by the sweeps (all in `KNOWN_ISSUES.md`)

| point | what stopped it | resolution |
|---|---|---|
| `lanes_1x1` | lint gate: `v_clear` unused (KI-007) | justified waiver, config-recorded |
| `util_055` (A) | `GPL-0302` placer abort (KI-032) | effective density = max(configured, util + 0.10) |
| `mpos_east`, `mpos_north` | planner placed the macro one site past the halo limit (KI-026) | fixed; found by the independent legality checker; regression-tested |
| `clk_16`, `cap_2k_2bank` | OpenROAD segfault in `irdrop.tcl` (KI-030) | `-placement` parasitics; **all sweep runs re-run through signoff STA / IR / antenna / report with the final scripts** |
| `mpos_east` | detailed routing not converged at 8 iterations (KI-033) | reported as a failed point; **not** patched |
| `flopmem_1k` | detailed routing not completed (KI-033) | reported as incomplete, labelled experiment |

