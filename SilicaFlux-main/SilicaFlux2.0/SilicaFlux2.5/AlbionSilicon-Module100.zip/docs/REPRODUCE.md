# Reproducing the results

Environment actually used: Ubuntu 24.04.5 x86-64, 4 cores, 15 GB RAM, ~12 GB tools + ~5 GB build. Versions are stamped in every `reports/*/summary.json`.

| tool | version | source |
|---|---|---|
| Yosys | 0.33 (git 2584903a060) | apt |
| Verilator | 5.020 | apt |
| Icarus Verilog | 12.0 | apt |
| OpenROAD | 2.0-12381-g01bba3695 | conda `litex-hub` |
| open_pdks sky130A | 1.0.471_0_g97d0844 | conda `litex-hub` |
| Magic | 8.3.465 | conda `litex-hub` (apt's 8.3.105 is too old for the PDK tech file) |
| Netgen | 1.5.272 | conda `litex-hub` |
| KLayout | 0.28.16 | apt |
| Python | 3.13 (PyYAML, matplotlib, pytest from apt) | |

```bash
cd physical/albion
make albion-install-tools        # exactly the commands used (apt + micromamba); needs network, ~12 GB
make albion-fetch-pdk            # downloads OpenRAM macros + ORFS support files; verifies SHA-256 pins
make albion-pdk-check            # must pass; `--pdk commercial_template` must FAIL
make albion-test-unit            # no tools needed
make albion-all                  # both designs through every stage, then docs/RESULTS.md   (~35 min on 4 cores)
make albion-sweeps               # sweeps in parallel (several hours on 4 cores: single points take 6–60 min, the east-macro router alone 46 min; TritonRoute is single-threaded)
make albion-test                 # all tests, incl. determinism (s_base == base) and instrument self-tests
make albion-gates DESIGN=pe_mesh # experimental tier: passes on the shipped baseline
make albion-gates DESIGN=spm     # experimental tier: currently FAILS the antenna gate (9 net violations, KI-016) - expected until post-detail-route antenna repair exists
make albion-tapeout-gate         # must FAIL (inverted exit code)
make albion-zip
```

One design, one stage:

```bash
cd scripts
python3 -m albion flow  --design spm --to droute
python3 -m albion drc   --design spm              # Magic + KLayout (≈ 12 min for the macro design)
python3 -m albion flow  --design pe_mesh --variant try --set clock.period_ns=8 --set floorplan.utilization=0.5
```

## Determinism

The flow is single-threaded with default seeds. The sweep's `s_base` point is an *independent* re-run of the baseline; `tests/test_flow_results.py`
requires identical tt slack, TNS, synthesis area and global/detailed wirelength. (Run on one machine; cross-machine determinism of OpenROAD was
not tested.)

## What a fresh checkout will differ in

* the ORFS support files are fetched from unpinned `master` (KI-019); the recorded hashes will flag a change;
* the OpenRAM macro views are fetched from a **pinned commit** and verified against hashes recorded by the SilicaFlux sramlib manifest;
* wall-clock numbers (router time, stage seconds) depend on the machine and on how many flows run concurrently.
