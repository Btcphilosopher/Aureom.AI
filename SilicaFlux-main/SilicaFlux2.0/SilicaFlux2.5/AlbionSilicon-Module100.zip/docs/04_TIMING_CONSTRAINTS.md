# 04 · Timing constraints (brief §4)

`scripts/albion/sdc.py` generates `build/<run>/constraints.sdc` from the resolved configuration (never hand-edited) in **OpenSTA dialect**
(KI-020: the explicit port list is used instead of Synopsys `remove_from_collection`, which OpenSTA lacks; the portability fix was found because
the stage failed).

| brief item | generated as |
|---|---|
| Primary clock | `create_clock -name core_clk -period P -waveform {0 P/2} [get_ports clk]` |
| Clock uncertainty | `set_clock_uncertainty -setup 0.25` / `-hold 0.10` (ns; pre-CTS jitter+skew budget – post-CTS skew is *measured*) |
| Ideal-clock attributes | `set_clock_latency`, `set_clock_transition` – applied only before CTS |
| Input delays | `set_input_delay -max 30% P` and `-min 5% P` on **every input except the clock** (explicit list) |
| Output delays | `set_output_delay -max 30% P`, `-min 0` on all outputs |
| Drive / load | `set_driving_cell -lib_cell sky130_fd_sc_hd__buf_4 -pin X`; `set_load 0.02 pF` on outputs; `set_max_transition 1.5` |
| False / multicycle paths | **none were identified as legitimate.** See below. |

The 30 %/30 % budgets, 0.02 pF load and the drive cell are **stated assumptions** about the environment (no package, board or neighbouring-block
model exists); they are config values, visible in every report.

## Why no false paths and no multicycle paths

Both designs use **asynchronous-assert / synchronous-release** reset (`always_ff @(posedge clk or negedge rst)`), and both designs' contracts
require release from a synchroniser. A blanket `set_false_path -from rst` would *delete the recovery/removal checks* that this reset style needs.
Measured instead: the reset input is timed as a synchronous input and the recovery checks to every `RESET_B` pin are met (visible in
`build/<run>/sta_pre/unconstrained_paths.rpt`, group `asynchronous`). No static strap, test-only path or multi-cycle enable exists in either
design. The generator supports both exception kinds, **refuses any exception without a justification**, echoes each into the SDC and the report,
and the unit tests exercise exception rendering (including the multicycle `-hold N-1` companion) — but the design SDCs carry
`# timing exceptions: 0`. Inventing one to tick a box would hide real paths.

## Unconstrained timing paths (reported, classified)

`check_setup -verbose -unconstrained_endpoints -multiple_clock -no_clock -no_input_delay -no_output_delay -loops -generated_clocks` runs
pre-layout and at every post-route corner. Unconstrained endpoints are then **classified in the routed database** (`classify_unconstrained.tcl`):
an endpoint whose driver chain (through buffers/inverters) ends at a tie cell is *constant-driven* – it has no launching startpoint, so no real
timing path exists. Anything else is a genuine constraint gap and fails the gate.

* Design A: 0 unconstrained endpoints.
* Design B: 83 unconstrained endpoints, **all 83 constant-driven** (perf-counter/event outputs that are structurally zero in this 1-port,
  no-ECC configuration, plus the macro's unused read port `addr1`/`csb1`), **0 genuine gaps** (KI-021). A first version of the classifier
  reported 9 "other" because it looked up hierarchical instance names without OpenDB's bracket escaping – a lookup bug, fixed, not a design fact.

## Verified-instrument note

The `check_setup` detector is itself tested: the same tiny design with and without an output-delay constraint must show 0 vs ≥ 1 unconstrained
endpoint (`tests/test_instruments.py`).
