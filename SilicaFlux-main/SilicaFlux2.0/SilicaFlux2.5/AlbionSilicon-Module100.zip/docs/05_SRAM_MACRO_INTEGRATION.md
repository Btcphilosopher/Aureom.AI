# 05 · SRAM macro integration (brief §5)

## Real macro views (used by Design B)

| view | file (from `efabless/sky130_sram_macros@ebfbf5775c8c…`, OpenRAM-generated, Apache-2.0) | used for |
|---|---|---|
| Liberty | `*_TT_1p8V_25C.lib` (**only the TT corner exists**) | STA / power; interface cross-check |
| LEF | `*.lef` (479.78 × 397.5 µm for the 1 KiB 32×256 macro; 25 KB) | floorplan, blockage, PDN macro grid, routing obstructions |
| GDS | `*.gds` (9.5 MB) | physical verification (Magic/KLayout) |
| behavioural model | vendor Verilog `*.v` (SHA-256 identical to the one the SilicaFlux sramlib manifest recorded) | RTL simulation (`verify_rtl`) and GLS |

Integration chain: `hpc_scratchpad` (M04) → `sram_backend_1rw` → `sram_asic_array` → `sram_leaf_sky130` → `sky130_sram_1kbyte_1rw1r_32x256_8`.
The SilicaFlux sramlib is used **unmodified**; the macro is a blackbox in synthesis and the physical flow binds LEF/Liberty/GDS by cell name.

* **Interface check** (`techcheck`): LEF ⇔ vendor Verilog ⇔ Liberty agree on every bus (name, direction, width): 11 buses / 121 signal pins.
* **Power pins** `vccd1`/`vssd1` (LEF: met3+met4) are bound by `add_global_connection`; a **macro PDN grid** with met4–met5 connections is generated and
  VDD/VSS connectivity is checked after PDN (`check_power_grid`: "All PDN stripes … connected", 703 voltage sources in the ideal case).
* **Unused read port:** the macro's second port is not used by the 1RW scratchpad; `addr1`/`csb1` end up tied to a constant-0 *port net*
  (`ev_bank_conflict`) by synthesis. Functionally harmless; recorded under KI-021.

## What was verified against the real model (this closes KI-002)

Upstream never ran `BACKEND=ASIC`. Here the **unmodified-semantics upstream testbench** runs against the vendor macro model through a run-time patch
(`tb_patch.diff`: forward a `MACRO` parameter; add an ASIC branch to the backdoor checker pointing at `…u_leaf.g_1.u_macro.mem`):
13 tests × 2 seeds = **26/26 pass**, the whole-array backdoor comparison is live (its injected-corruption self-test fires), and the macro model's own
log appears 10,282 times (proof it executed). Timing caveat found while writing the gate-level testbench: the OpenRAM model's `dout` is valid
only ~3 ns after the **falling** edge and goes X 1 ns after the next rising edge, so outputs must be sampled just before the rising edge.

## Fallback: labelled flop-based memory experiment (also run)

Real macros exist, so the flop model is not a substitute; it is run **as a labelled experiment** (`flopmem_1k` in the sweep) to show what the
same 1 KiB costs when synthesized into flip-flops. **The flop model does not represent the area or power of a real SRAM macro.**
Every report from such a run carries the label *"FLOP-BASED MEMORY EXPERIMENT … must not be quoted as SRAM figures"*, and the comparison table
in `RESULTS.md` is the only place the two are shown together.

## Limits

* Only **1 KiB (32×256)** and **2 KiB (32×512)** 1RW1R OpenRAM macros are wired in; no commercial compiler output, no multi-port macros, no ECC/BIST wrapper.
* The Liberty is **TT only** → no ss/ff analysis of macro designs; the macro's published `max_transition 0.04 ns` on input pins is far tighter than the
  library default (0.5 ns) and produces post-route slew violations that cannot be removed by this flow (KI-012).
* Macro-internal DRC/LVS is not signoff-checked (two open DRC decks disagree wildly about the SRAM interior – see doc 08).
