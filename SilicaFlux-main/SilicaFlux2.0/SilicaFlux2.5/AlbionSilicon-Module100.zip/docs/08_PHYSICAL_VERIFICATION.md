# 08 · Physical verification (brief §8)

**Everything here is EXPERIMENTAL.** The decks are community/open decks and the extraction/STA/IR engines are open-source; none is a foundry signoff
tool, and the reports say `signoff_accepted: false`. Experimental checks are separated from production signoff in three ways: a `pdk_class`
stamp, the `signoff_accepted: false` field on every verification result, and a `tapeout` gate tier that can never pass on an open PDK.

| check | engine / deck | status here | what is *not* covered |
|---|---|---|---|
| DRC | **Magic** (sky130A tech, `drc(full)`) **and KLayout** (`sky130A_mr.drc`, `feol/beol/offgrid` enabled) on a Magic-written GDS | run on both baselines | foundry runset, density/dummy fill, seal ring, latch-up rules, SRAM-aware macro rules |
| LVS | Magic extraction → **Netgen** (PDK setup) vs OpenROAD `write_verilog -include_pwr_gnd` | run on both baselines | macro internals (black-boxed on both sides), parasitic-aware LVS |
| Antenna | OpenROAD `check_antennas` with the tech-LEF `ANTENNA*` rules | run on both baselines | foundry antenna deck; no repair after detail route |
| IR drop | OpenROAD PSM, **vectorless** power, two supply assumptions (ideal: a source at every top-strap crossing; 4 corner sources) | run | package/bump model, dynamic IR, vector-based power |
| Electromigration | PSM `-enable_em`: peak/average PDN segment current vs tech-LEF DC limits | **screen only** (hook) | signal/clock-net EM, AC/RMS limits, via arrays, thermal derating; no signoff EM engine is bound |
| Setup / hold | OpenRCX (PDK rules) + OpenSTA, tt/ss/ff for macro-free designs | run | OCV/AOCV/POCV, SI/crosstalk delay, multi-mode |
| Congestion | global-route per-layer usage and overflow | run | – |

## Instrument self-tests (because a clean result from a tool that cannot fail is worthless)

* **DRC:** a layout with two met1 rectangles 0.05 µm apart (rule 0.14 µm) must be flagged by **both** engines. Result: Magic detects (`met1.2`),
  configured KLayout detects (`m1.2`), and the **unconfigured KLayout deck does *not* detect it**: the deck runs *zero* rule groups unless
  `feol/beol/offgrid` are set (KI-009). A first KLayout run in this programme reported "0 violations" for that reason; it was discarded.
* **LVS:** the first run *failed* (5 device mismatches) and that failure was explained (device-less tap/fill cells appear only on the schematic
  side); after excluding exactly those cells, "Circuits match uniquely". A test deletes one buffer from the schematic and requires a mismatch.
* **GDS export:** the first export silently wrote a **126-byte** GDS (Magic read `-labels` as a filename). The stage now requires a plausible size,
  no Magic "couldn't be read"/"Cannot open" text, and a `DONE` marker, and Magic's exit code is never trusted (it exited 0 after a Tcl error; a segfault returned −11): the success markers
  are required. Magic's DEF reader also **segfaults on a PLACEMENT blockage** (the
  macro halo): the Magic-specific DEF copy omits that section (KI-008).
* **STA:** the same small design with and without an output delay must show 0 vs ≥ 1 unconstrained endpoint.

## How the GDS is produced (KI-024)

Magic reads the tech LEF, the macro GDS, then the routed DEF; standard cells are resolved from the PDK's `.mag` layouts on Magic's search path
(reading the abstract LEFs first makes Magic keep empty abstract views). Both DRC engines and LVS run on **this Magic-written GDS**, not on a
merge of the foundry GDS stream with OpenROAD's DEF.

## Reading the DRC numbers

* The two open decks **disagree**, in opposite directions, and neither disagreement is resolved here (KI-010/011): see `RESULTS.md` for the live
  counts and the by-rule / inside-vs-outside-macro split. In short: Magic reports **0 outside the macro** on both designs and, for Design B,
  millions of violations **inside** the OpenRAM macro whose top rules name SRAM-cell geometry; KLayout reports a few dozen FEOL implant-rule hits
  (`npc.2`, `psd.2`, `nsd.2`, `licon.13`) in **library cells and cell boundaries**, none in routing, and none inside the macro. TritonRoute reports 0.
* Violations are located by bounding box and attributed to the placed cell containing them (analysis recorded in the build logs and KNOWN_ISSUES).
