#!/usr/bin/env bash
# Build the delivery archive.  The 1 GB build/ tree (ODB/GDS/SPEF/DEF databases, 200 MB DRC dump) is NEVER archived: `make albion-all`
# regenerates it, and scripts/collect_results.py has already curated the deliverable subset into results/ (netlists, SDC, plans, stage
# results, logs, reports).  Nothing is committed or pushed by this script.
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/collect_results.py
OUT=${OUT:-../AlbionSilicon-Module100.zip}
rm -f "$OUT"
zip -qr "$OUT" . -x 'build/*' '*/__pycache__/*' '*.pyc' '.pytest_cache/*' 'tests/__pycache__/*'
echo "wrote $OUT ($(du -h "$OUT" | cut -f1)); $(unzip -l "$OUT" | tail -1)"
