"""PDK profile framework: load, validate (techcheck), fetch hash-pinned assets, filter Liberty.

A profile is a YAML file under config/pdk/.  `techcheck` is the gate that separates real
technology data from placeholders: any null / missing / hash-mismatching entry fails.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

import yaml

from .util import ROOT, EDA, read_json, run, sha256, write_json

DEFAULT_PDK_ROOT = "/opt/eda/env/share/pdk/sky130A"
DEFAULT_CACHE = "/opt/eda/cache"


def _subst(v, ctx):
    if isinstance(v, str):
        for k, val in ctx.items():
            v = v.replace("${" + k + "}", val)
        return v
    if isinstance(v, dict):
        return {k: _subst(x, ctx) for k, x in v.items()}
    if isinstance(v, list):
        return [_subst(x, ctx) for x in v]
    return v


def load_profile(name: str) -> dict:
    p = ROOT / "config" / "pdk" / f"{name}.yaml"
    if not p.exists():
        raise FileNotFoundError(f"PDK profile not found: {p}")
    with open(p) as f:
        raw = yaml.safe_load(f)
    ctx = {
        "PDK": os.environ.get("ALBION_PDK_ROOT", DEFAULT_PDK_ROOT),
        "CACHE": os.environ.get("ALBION_PDK_CACHE", DEFAULT_CACHE),
        "TOOLS": os.environ.get("ALBION_TOOLS_ROOT", str(EDA)),
    }
    prof = _subst(raw, ctx)
    prof["_ctx"] = ctx
    prof["_path"] = str(p)
    # hard rule: an open public profile can never be signoff eligible
    if prof.get("pdk_class") != "commercial_production":
        prof["signoff_eligible"] = False
    return prof


def _walk_paths(prof: dict):
    """Yield (label, value) for every path-like entry the flow consumes."""
    for k, v in prof.get("files", {}).items():
        yield f"files.{k}", v
    for c, d in prof.get("corners", {}).items():
        yield f"corners.{c}.lib", d.get("lib")
    rc = prof.get("rc", {})
    yield "rc.estimate_script", rc.get("estimate_script")
    for k, v in (rc.get("rcx_rules") or {}).items():
        yield f"rc.rcx_rules.{k}", v
    for m, d in prof.get("macros", {}).items():
        base = d.get("dir")
        for key in ("lef", "gds", "verilog"):
            yield f"macros.{m}.{key}", (os.path.join(base, d[key]) if base and d.get(key) else None)
        for c, f in (d.get("lib") or {}).items():
            yield f"macros.{m}.lib.{c}", (os.path.join(base, f) if base and f else None)


def techcheck(name: str) -> dict:
    """Validate a profile. Returns {ok, missing, mismatched, notes, class}."""
    prof = load_profile(name)
    missing, notes, mismatched = [], [], []
    for label, val in _walk_paths(prof):
        if val is None:
            missing.append(f"{label}: null (no data supplied)")
        elif not Path(val).exists():
            missing.append(f"{label}: file not found: {val}")
    # null scalar fundamentals
    for key in ("stdcell_library", "site", "default_corner"):
        if prof.get(key) is None:
            missing.append(f"{key}: null")
    # signoff bindings required for a production class
    if prof.get("pdk_class") == "commercial_production":
        for k, v in (prof.get("signoff") or {}).items():
            if k != "licensed_file_hashes" and v is None:
                missing.append(f"signoff.{k}: null (no signoff engine bound)")
        for k, v in (prof.get("ip") or {}).items():
            if v is None:
                missing.append(f"ip.{k}: null")
    # hash pinning for fetched macro assets
    ra = (prof.get("remote_assets") or {}).get("sky130_sram_macros") or {}
    for rel, exp in (ra.get("expected_sha256") or {}).items():
        f = Path(ra["dest"]) / rel
        if f.exists():
            got = sha256(f)
            if got != exp:
                mismatched.append(f"{rel}: expected {exp[:12]} got {got[:12]}")
    if prof.get("pdk_class") != "commercial_production":
        notes.append("EXPERIMENTAL: open public PDK; results cannot satisfy a production tapeout gate")
    ok = not missing and not mismatched
    res = {"profile": name, "pdk_class": prof.get("pdk_class"), "signoff_eligible": prof.get("signoff_eligible", False),
           "ok": ok, "missing": missing, "hash_mismatch": mismatched, "notes": notes,
           "n_checked": sum(1 for _ in _walk_paths(prof))}
    return res


def fetch(name: str) -> dict:
    """Download remote_assets with curl (inherits the sandbox proxy), record sha256 and verify pins."""
    prof = load_profile(name)
    results = {}
    for aname, a in (prof.get("remote_assets") or {}).items():
        dest = Path(a["dest"])
        entries = {}
        for rel in a["files"]:
            out = dest / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            if not out.exists() or out.stat().st_size == 0:
                r = run(["curl", "-fsSL", "-m", "300", "-o", str(out), f"{a['base_url']}/{rel}"],
                        ROOT / "build" / "logs" / f"fetch_{aname}_{Path(rel).name}.log", fatal=[])
                if r["rc"] != 0:
                    entries[rel] = {"status": "FETCH_FAILED", "rc": r["rc"]}
                    continue
            h = sha256(out)
            st = "ok"
            exp = (a.get("expected_sha256") or {}).get(rel)
            if exp and exp != h:
                st = f"HASH_MISMATCH expected {exp}"
            elif exp:
                st = "ok (matches upstream-recorded sha256)"
            entries[rel] = {"sha256": h, "bytes": out.stat().st_size, "status": st}
        results[aname] = {"pin": a.get("pin"), "base_url": a["base_url"], "files": entries}
    write_json(Path(prof["_ctx"]["CACHE"]) / "pdk_manifest.json", results)
    # keep a copy of the manifest in the repo so provenance travels with the archive
    write_json(ROOT / "config" / "pdk" / f"{name}.manifest.json", results)
    bad = [f"{a}:{r}" for a, d in results.items() for r, e in d["files"].items() if not str(e["status"]).startswith("ok")]
    return {"ok": not bad, "problems": bad, "assets": results}


def filter_liberty(src: str, dst: str, dont_use_patterns: list[str]) -> dict:
    """Write a copy of `src` with every cell matching a dont_use regex removed.

    Needed because Yosys 0.33's `abc` has no -dont_use option.  Brace-matching is done on the raw
    text so the result remains a valid Liberty file for Yosys/ABC and OpenSTA.
    """
    pats = [re.compile(p) for p in dont_use_patterns]
    text = Path(src).read_text()
    cell_re = re.compile(r'^[ \t]*cell[ \t]*\([ \t]*"?([^")\s]+)"?[ \t]*\)[ \t]*\{', re.M)
    out, pos, removed, kept = [], 0, [], 0
    for m in cell_re.finditer(text):
        if m.start() < pos:
            continue
        name = m.group(1)
        if not any(p.fullmatch(name) or p.match(name) for p in pats):
            kept += 1
            continue
        depth, i = 0, m.end() - 1
        in_str = False
        while i < len(text):
            c = text[i]
            if c == '"':
                in_str = not in_str
            elif not in_str:
                if c == "{":
                    depth += 1
                elif c == "}":
                    depth -= 1
                    if depth == 0:
                        break
            i += 1
        out.append(text[pos:m.start()])
        pos = i + 1
        removed.append(name)
    out.append(text[pos:])
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    Path(dst).write_text("".join(out))
    return {"src": src, "dst": dst, "removed": len(removed), "kept": kept, "removed_cells": removed[:10]}
