"""Stage implementations (thin wrappers: tool invocation + result parsing)."""
from __future__ import annotations

import re
from pathlib import Path

from . import pdk as pdkmod
from . import plan as planmod
from . import sdc as sdcmod
from . import simgate, synth
from .config import run_dir
from .flow import run_openroad
from .parse import _grep, _timing  # noqa: F401
from .util import ROOT, read_json, run, write_json


def stage_techcheck(cfg, prof) -> dict:
    r = pdkmod.techcheck(cfg["pdk"])
    # macro interface cross-check (LEF vs vendor Verilog vs Liberty)
    from . import lef as lefmod
    problems = []
    checks = []
    import json
    import subprocess
    import tempfile
    for m in synth.macro_cells(cfg, prof):
        d = Path(tempfile.mkdtemp())
        (d / "a.ys").write_text(f"read_verilog -lib -sv {m['verilog_path']}\nhierarchy -top {m['name']}\nwrite_json {d}/m.json\n")
        rr = subprocess.run(["yosys", "-q", str(d / "a.ys")], capture_output=True, text=True)
        if rr.returncode != 0:
            problems.append(f"{m['name']}: yosys could not read vendor model: {rr.stderr[:150]}")
            continue
        mod = json.load(open(d / "m.json"))["modules"][m["name"]]
        vp = {n: (p["direction"], len(p["bits"])) for n, p in mod["ports"].items() if n not in ("vccd1", "vssd1")}
        c = lefmod.check_macro_interface(m["lef_path"], vp, m["lib_paths"].get("tt"))
        checks.append(c)
        problems += [f"{m['name']}: {p}" for p in c["problems"]]
    r["macro_interface_checks"] = checks
    r["ok"] = r["ok"] and not problems
    r["macro_problems"] = problems
    return r


def stage_lint(cfg, prof):
    return synth.stage_lint(cfg)


def stage_verify_rtl(cfg, prof):
    return simgate.verify_rtl(cfg, prof)


def stage_synth(cfg, prof):
    return synth.stage_synth(cfg)


def stage_gls(cfg, prof):
    return simgate.gls(cfg, prof)


def stage_sdc(cfg, prof):
    sj = read_json(run_dir(cfg, "synth") / "synth.json")
    res = sdcmod.write(cfg, sj["ports"], run_dir(cfg) / "constraints.sdc")
    res["ok"] = res["ok"]
    return res


def stage_sta_pre(cfg, prof):
    r = run_openroad(cfg, prof, "sta_pre.tcl", "sta_pre")
    d = run_dir(cfg, "sta_pre")
    ct = (d / "check_setup.rpt").read_text() if (d / "check_setup.rpt").exists() else ""
    unc = (d / "unconstrained_paths.rpt").read_text() if (d / "unconstrained_paths.rpt").exists() else ""
    n_unc = len([ln for ln in unc.splitlines() if re.match(r"^\S+\s+\S+\s*$", ln) or "unconstrained" in ln.lower()])
    r["timing"] = _timing(d, "pre")
    r["check_timing_lines"] = [ln for ln in ct.splitlines() if ln.strip()][:40]
    r["setup_wns_ns"] = r["timing"]["ws_setup"]       # worst setup slack, ideal clock, zero wire load
    r["hold_ws_ns"] = r["timing"]["ws_hold"]
    return r


def stage_plan(cfg, prof):
    return planmod.stage_plan(cfg, prof)


def stage_floorplan(cfg, prof):
    r = run_openroad(cfg, prof, "floorplan.tcl", "floorplan")
    d = run_dir(cfg, "floorplan")
    fc = (d / "floorplan_check.rpt").read_text() if (d / "floorplan_check.rpt").exists() else ""
    r["macro_lines"] = [ln for ln in fc.splitlines() if ln.startswith("macro ")]
    m = r.get("metrics", {})
    r["ok"] = r["ok"] and m.get("floorplan_macro_violations", 1) == 0 and (d / "floorplan.odb").exists()
    return r




def stage_place(cfg, prof):
    r = run_openroad(cfg, prof, "place.tcl", "place")
    d = run_dir(cfg, "place")
    cp = (d / "check_placement.rpt").read_text() if (d / "check_placement.rpt").exists() else "MISSING"
    r["timing"] = _timing(d, "place")
    m = r.get("metrics", {})
    r["check_placement_clean"] = not re.search(r"(?i)\b(error|overlap|violat|not on|fail)", cp.replace("Placement check", ""))
    sj = read_json(run_dir(cfg, "synth") / "synth.json", {})
    r["ports_match_synthesis"] = m.get("io_pins_total") == sj.get("n_port_bits")
    r["ok"] = (r["ok"] and m.get("unplaced_instances", 1) == 0 and m.get("io_pins_placed") == m.get("io_pins_total")
               and r["ports_match_synthesis"])
    return r




def stage_cts(cfg, prof):
    r = run_openroad(cfg, prof, "cts.tcl", "cts")
    d = run_dir(cfg, "cts")
    log = (d / "cts.log").read_text(errors="replace")
    r["timing"] = _timing(d, "cts")
    r["timing_pre_repair"] = _timing(d, "cts_pre_repair")
    r["timing_pre_cts"] = _timing(d, "pre_cts")
    r["cts_log"] = _grep(log, r"CTS-00(10|12|18|98|99)|CTS-0124|CTS-0125|CTS-0017|RSZ-00(33|34|51|52|59)")[:30]
    r["ok"] = r["ok"] and (d / "cts.odb").exists()
    return r


def stage_groute(cfg, prof):
    r = run_openroad(cfg, prof, "groute.tcl", "groute")
    d = run_dir(cfg, "groute")
    log = (d / "groute.log").read_text(errors="replace")
    r["timing"] = _timing(d, "groute")
    r["timing_pre_antenna"] = _timing(d, "groute_pre_antenna")
    ov = re.findall(r"Total overflow:?\s*(\d+)|overflow[^\d]*(\d+)", log, flags=re.I)
    r["grt_log"] = _grep(log, r"GRT-00(03|12|13|14|15|16|17|18|19|43|44|45|46|47|48|49)|ANT-00|Total (wire|overflow)|overflow|congestion")[:40]
    r["ok"] = r["ok"] and (d / "groute.odb").exists()
    return r


def stage_droute(cfg, prof):
    r = run_openroad(cfg, prof, "droute.tcl", "droute", timeout=14400)
    d = run_dir(cfg, "droute")
    log = (d / "droute.log").read_text(errors="replace")
    r["drt_log"] = _grep(log, r"DRT-00(18|19|98|99|43|44|45|46|47)|Number of violations|Total wire length|Total number of vias|violation")[-25:]
    drc_rpt = d / "detailed_route_drc.rpt"
    n_viol = len(re.findall(r"^violation type", drc_rpt.read_text(), flags=re.M)) if drc_rpt.exists() else None
    r["router_drc_violations"] = n_viol
    r["ok"] = r["ok"] and (d / "droute.odb").exists()
    return r


# post-route analysis + physical verification live in verify.py (imported last: it uses helpers defined above)
from .verify import stage_antenna, stage_drc, stage_irdrop, stage_lvs, stage_signoff_sta  # noqa: E402,F401


def stage_report(cfg, prof):
    from .report import stage_report as _r
    return _r(cfg, prof)
