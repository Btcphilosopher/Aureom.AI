"""Shared helpers: subprocess discipline, hashing, JSON, tool discovery.

Design rule: a stage is only PASS if the tool exited 0 AND its log contains none of the
fatal patterns.  Tools are never run with quiet flags that could hide an error (the
mistake that hid a Yosys import failure during development).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[2]          # physical/albion
EDA = Path(os.environ.get("ALBION_TOOLS_ROOT", "/opt/eda/env"))
EDA_MN = Path(os.environ.get("ALBION_TOOLS_MN_ROOT", "/opt/eda/env_mn"))

FATAL_PATTERNS = [r"^ERROR", r"\[ERROR", r"Segmentation fault", r"Traceback \(most recent", r"^Error:", r"terminate called"]


def tool(name: str) -> str | None:
    """Locate a tool. Order: explicit env override, conda env, matched-version env (magic/netgen), PATH."""
    ov = os.environ.get(f"ALBION_{name.upper()}")
    if ov and Path(ov).exists():
        return ov
    for base in (EDA / "bin", EDA_MN / "bin"):
        p = base / name
        if p.exists():
            return str(p)
    return shutil.which(name)


def sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(p: str | Path, default=None):
    try:
        with open(p) as f:
            return json.load(f)
    except FileNotFoundError:
        return default


def write_json(p: str | Path, obj) -> None:
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write("\n")


def run(cmd: list[str] | str, log: str | Path, cwd: str | Path | None = None, env: dict | None = None,
        timeout: int = 3600, shell: bool = False, fatal: Iterable[str] = FATAL_PATTERNS) -> dict:
    """Run a command, tee everything to `log`, return {rc, seconds, fatal_hits}.

    ok == (rc == 0 and no fatal pattern in log).  Never raises on tool failure.
    """
    Path(log).parent.mkdir(parents=True, exist_ok=True)
    e = os.environ.copy()
    e["PATH"] = f"{EDA}/bin:{EDA_MN}/bin:" + e.get("PATH", "")
    if env:
        e.update({k: str(v) for k, v in env.items()})
    t0 = time.time()
    with open(log, "w") as lf:
        lf.write(f"# cmd: {cmd}\n# cwd: {cwd}\n")
        lf.flush()
        try:
            p = subprocess.run(cmd, cwd=cwd, env=e, stdout=lf, stderr=subprocess.STDOUT, timeout=timeout, shell=shell)
            rc = p.returncode
        except subprocess.TimeoutExpired:
            rc = 124
            lf.write(f"\n# TIMEOUT after {timeout}s\n")
        except FileNotFoundError as ex:
            rc = 127
            lf.write(f"\n# NOT FOUND: {ex}\n")
    secs = time.time() - t0
    hits = []
    pats = [re.compile(p) for p in fatal]
    with open(log, errors="replace") as lf:
        for line in lf:
            if line.startswith("# cmd:"):
                continue
            if any(p.search(line) for p in pats):
                hits.append(line.rstrip()[:200])
                if len(hits) >= 5:
                    break
    return {"rc": rc, "seconds": round(secs, 2), "fatal_hits": hits, "ok": rc == 0 and not hits, "log": str(log)}


def versions() -> dict:
    """Capture tool versions for provenance (reports embed this)."""
    out = {}

    def grab(cmd, key, n=1):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=30,
                               env={**os.environ, "PATH": f"{EDA}/bin:{EDA_MN}/bin:" + os.environ.get("PATH", "")})
            txt = (r.stdout + r.stderr).strip().splitlines()
            out[key] = txt[0].strip() if txt else "unknown"
        except Exception as ex:  # noqa: BLE001
            out[key] = f"unavailable ({ex.__class__.__name__})"

    grab(["yosys", "-V"], "yosys")
    grab(["verilator", "--version"], "verilator")
    grab(["iverilog", "-V"], "iverilog")
    grab([tool("openroad") or "openroad", "-version"], "openroad")
    grab(["klayout", "-v"], "klayout")
    mg = tool("magic")
    out["magic"] = "unavailable"
    if mg:
        try:
            r = subprocess.run([mg, "--version"], capture_output=True, text=True, timeout=30)
            out["magic"] = (r.stdout + r.stderr).strip().splitlines()[0]
        except Exception:  # noqa: BLE001
            pass
    ng = tool("netgen")
    out["netgen"] = "installed" if ng else "unavailable"
    import sys
    out["python"] = sys.version.split()[0]
    return out


def human_um2(x: float) -> str:
    return f"{x:,.1f} um^2"
