"""CI implementation gates.

tier `experimental` : what this programme enforces on every run (a gate that cannot fail is not a gate).
tier `tapeout`      : by design CANNOT pass in this repository; it prints the exact blocker list.  It exists so CI
                      has a single red/green answer to "is this tapeout-ready?" that is honest.
Exit code 0 = all gates passed, 1 = at least one gate failed, 2 = required evidence missing.
"""
from __future__ import annotations

import json
import sys

from .util import ROOT, read_json


def _g(name, ok, detail, severity="fail"):
    return {"gate": name, "ok": bool(ok) if ok is not None else None, "detail": detail, "severity": severity}


def experimental(cfg, s) -> list[dict]:
    g = cfg["gates"]
    st = s["stages"]
    need = lambda *names: all(st.get(n) == "passed" for n in names)  # noqa: E731
    out = []
    out.append(_g("pdk_techcheck", st["techcheck"] == "passed", "PDK files + macro views exist, hashes match, LEF/Verilog/Liberty interfaces agree"))
    out.append(_g("rtl_lint", st["lint"] == "passed", "Verilator -Wall + Yosys elaboration (un-waived warnings = fail)"))
    out.append(_g("source_rtl_verification", st["verify_rtl"] == "passed", "upstream self-checking TB re-run on this toolchain"))
    out.append(_g("synthesis", st["synth"] == "passed", "Yosys + abc technology mapping, no unmapped cells"))
    sy = s["synthesis"]
    lat = (sy.get("latches_rtl") or 0) + (sy.get("latches_mapped") or 0)
    out.append(_g("no_latches", lat <= g["max_latches"], f"{lat} latches (limit {g['max_latches']})"))
    out.append(_g("gate_level_sim", st["gls"] == "passed", "synthesized netlist re-checked with foundry cell models"))
    out.append(_g("sdc_loads", st["sdc"] == "passed" and st["sta_pre"] == "passed", "SDC generated, linted and accepted by OpenSTA"))
    out.append(_g("floorplan_legal", st["plan"] == "passed" and st["floorplan"] == "passed" and s["floorplan"]["legality"], "independent legality check + database re-check"))
    out.append(_g("placement", st["place"] == "passed", "legal detailed placement, all pins placed, port count == synthesis"))
    out.append(_g("cts", st["cts"] == "passed", "TritonCTS + propagated-clock repair"))
    out.append(_g("global_route", st["groute"] == "passed", "global routing completed"))
    ov = (s["routing"]["global"] or {}).get("total_overflow")
    out.append(_g("route_overflow", ov is not None and ov <= g["max_route_overflow"], f"global-route overflow {ov} (limit {g['max_route_overflow']})"))
    out.append(_g("detail_route", st["droute"] == "passed", "TritonRoute completed"))
    dv = (s["routing"]["detailed"] or {}).get("final_violations")
    out.append(_g("router_drc", dv is not None and dv <= g["max_drc_violations"], f"router-reported violations {dv} (limit {g['max_drc_violations']})"))
    default = (read_json(ROOT / "build" / cfg["run_id"] / "resolved.json", {}) or {}).get("pdk_default_corner", "tt")
    for c, d in s["timing_by_corner"].items():
        # The flow optimises at the default corner only; other corners are an off-nominal SCREENING whose failure is a reported
        # result (warn), not a flow defect.  In the tapeout tier every corner is a blocker.
        sev = "fail" if c == default else "warn"
        out.append(_g(f"setup_{c}", d["setup_violating_endpoints"] == 0 and (d["setup_worst_slack_ns"] or -1) >= 0, f"WS {d['setup_worst_slack_ns']} ns, {d['setup_violating_endpoints']} violating endpoints", sev))
        out.append(_g(f"hold_{c}", d["hold_violating_endpoints"] == 0 and (d["hold_worst_slack_ns"] or -1) >= 0, f"WS {d['hold_worst_slack_ns']} ns, {d['hold_violating_endpoints']} violating endpoints", sev))
        out.append(_g(f"drv_{c}", (d.get("drv_violations") or 0) == 0, f"{d.get('drv_violations')} max-slew/cap/fanout violations after routing "
                      "(reported by OpenSTA with the Liberty limits; see KNOWN_ISSUES KI-012 for macro-pin limits)", "warn"))
        u = s.get("unconstrained_endpoints") or {}
        other = (u.get("other") or 0) + max(0, (d["unconstrained_endpoints"] or 0) - (u.get("total") or 0))
        out.append(_g(f"constrained_{c}", d["unconstrained_endpoints"] is not None and other <= g["max_unconstrained_endpoints"],
                      f"{d['unconstrained_endpoints']} unconstrained, of which {other} not constant-driven (limit {g['max_unconstrained_endpoints']}; "
                      f"{u.get('const')} constant-driven endpoints are explained: no launching path exists)"))
    if not s["timing_by_corner"]:
        out.append(_g("post_route_sta", False, "no post-route STA result"))
    ant = s["physical_verification"]["antenna"]
    out.append(_g("antenna", ant is not None and ant.get("net_violations") == 0, f"{ant}"))
    return out


def tapeout(cfg, s, prof_class) -> list[dict]:
    r = s["readiness"]
    out = [_g("pdk_class_commercial_production", prof_class == "commercial_production", f"pdk_class={prof_class}")]
    for b in r["blockers"]:
        out.append(_g("blocker", False, b))
    return out


def evaluate(cfg, tier="experimental") -> tuple[list[dict], dict]:
    s = read_json(ROOT / "reports" / cfg["run_id"] / "summary.json")
    if not s:
        return [_g("summary_exists", False, f"reports/{cfg['run_id']}/summary.json missing: run `albion report`")], {}
    if tier == "tapeout":
        return tapeout(cfg, s, s["pdk"]["class"]), s
    return experimental(cfg, s), s


def cli(cfg, tier="experimental") -> int:
    res, s = evaluate(cfg, tier)
    bad = [r for r in res if not r["ok"] and r["severity"] == "fail"]
    warn = [r for r in res if not r["ok"] and r["severity"] == "warn"]
    print(json.dumps({"run": cfg["run_id"], "tier": tier, "n_gates": len(res), "n_failed": len(bad), "n_warnings": len(warn),
                      "failed": bad, "warnings": warn, "passed": [r["gate"] for r in res if r["ok"]]}, indent=2))
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(0)
