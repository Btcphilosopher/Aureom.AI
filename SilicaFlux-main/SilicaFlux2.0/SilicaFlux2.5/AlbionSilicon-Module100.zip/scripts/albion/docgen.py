"""Generate docs/RESULTS.md and reports/INDEX.md from reports/*/summary.json and reports/sweeps/*.json.

Nothing in the generated file is typed by hand: every number is read from a report produced by a tool run.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from .util import ROOT, read_json, versions

BASES = [("albion_pe_mesh__base", "Design A - albion_pe_mesh (TensorCore-01 INT8 MAC mesh)"),
         ("albion_spm__base", "Design B - albion_spm (M04 scratchpad on a real OpenRAM sky130 macro)")]


def _f(x, nd=3):
    return "n/a" if x is None else (f"{x:.{nd}f}" if isinstance(x, float) else str(x))


def design_section(run_id: str, title: str) -> list[str]:
    s = read_json(ROOT / "reports" / run_id / "summary.json")
    if not s:
        return [f"## {title}", "", f"*no summary for `{run_id}` (flow not run)*", ""]
    sy, a, fp, rt = s["synthesis"], s["area_um2"], s["floorplan"], s["routing"]
    pv = s["physical_verification"]
    L = [f"## {title}", "", f"run `{run_id}` · config `{s['config_sha256'][:12]}` · {s['generated_utc']}", ""]
    L += ["| stage | status |", "|---|---|"] + [f"| {k} | {'(this stage writes the table)' if k == 'report' else v} |" for k, v in s["stages"].items()] + [""]
    sv = s["source_verification"]
    L += ["### Source and netlist verification", "",
          f"* RTL (upstream self-checking testbench, re-run here): ok={sv['rtl']['ok']} · detail `{json.dumps(sv['rtl']['detail'], default=str)[:400]}`",
          f"* gate-level netlist simulation (foundry cell models): ok={sv['gate_level']['ok']} · checks={sv['gate_level']['checks']}", ""]
    L += ["### Synthesis (Yosys 0.33, abc, sky130_fd_sc_hd tt)", "",
          f"* standard-cell area **{_f(sy['std_cell_area_um2'], 1)} µm²** · {sy['n_std_cells']} cells · {sy['n_flops']} flops · {sy['n_macros']} macro(s) · "
          f"latches (RTL/mapped) {sy['latches_rtl']}/{sy['latches_mapped']} · {sy['n_port_bits']} port bits", ""]
    L += ["### Floorplan", "", f"* die {fp['die_um']} µm, core {fp['core_um']} µm, target std-logic utilisation {fp['target_utilization']} (upper bound; achieved before placement {fp.get('achieved_pre_place_utilization')}), halo {fp['halo_um']} µm, legality check: {fp['legality']}",
          f"* macros: {json.dumps(fp['macros'])}", f"* I/O pins per edge: {fp['io_pins_by_edge']}", ""]
    L += ["### Area (final database)", "", "| class | µm² |", "|---|---|"] + [f"| {k} | {v} |" for k, v in sorted(a.items())] + [""]
    L += ["### Timing (post-route, OpenRCX with PDK rules + OpenSTA)", "", "| corner | setup WS ns | hold WS ns | setup viol | hold viol | min period ns (derived) | Fmax MHz (derived) | power mW (vectorless) |", "|---|---|---|---|---|---|---|---|"]
    for c, d in s["timing_by_corner"].items():
        pw = (d.get("power_w") or {}).get("total_w")
        L.append(f"| {c} | {_f(d['setup_worst_slack_ns'])} | {_f(d['hold_worst_slack_ns'])} | {d['setup_violating_endpoints']} | {d['hold_violating_endpoints']} | "
                 f"{_f(d['min_period_ns_derived'])} | {_f(d['fmax_mhz_derived'], 1)} | {_f(pw * 1e3 if pw is not None else None, 3)} |")
    u = s.get("unconstrained_endpoints") or {}
    L += ["", f"Unconstrained endpoints: {u.get('total')} total = {u.get('const')} constant-driven + {u.get('other')} other. "
          f"Timing exceptions applied: {s['constraints']['n_exceptions']}.", ""]
    stg = s["timing_stages_tt"]
    L += ["### Timing at each stage (tt)", "", "| stage | setup WS ns | hold WS ns | hold violations |", "|---|---|---|---|"]
    for k in ("pre_layout_ideal_clock", "post_place_est", "post_cts_before_repair", "post_cts_after_repair", "post_groute_est"):
        v = stg.get(k) or {}
        L.append(f"| {k} | {_f(v.get('ws_setup'))} | {_f(v.get('ws_hold'))} | {v.get('viol_hold')} |")
    L += ["", "### Clock tree", "", "```", *(s["clock_tree"].get("log") or []), "```", ""]
    g, d = rt["global"], rt["detailed"]
    L += ["### Routing", "", f"* global: usage {g.get('usage_pct')} %, overflow {g.get('total_overflow')}, wirelength {g.get('wirelength_um')} µm, {g.get('routed_nets')} nets; per layer {json.dumps(g.get('per_layer'))}",
          f"* detailed: violations {d.get('final_violations')}, wirelength {d.get('wirelength_um')} µm, vias {d.get('vias')}, by layer {d.get('wirelength_by_layer_um')}, router wall time {d.get('router_elapsed')}", ""]
    ant = pv.get("antenna") or {}
    L += ["### Physical verification (EXPERIMENTAL open decks; none is a foundry signoff run)", "",
          f"* antenna (OpenROAD, tech-LEF rules): {ant.get('net_violations')} net / {ant.get('pin_violations')} pin violations"]
    ir = read_json(ROOT / "build" / run_id / "irdrop" / "result.json")
    if ir and ir.get("ir_cases"):
        for cs in ("ideal", "corners"):
            c = ir["ir_cases"][cs]
            L.append(f"* IR drop ({cs}, {c['vdd']['sources']} supply sources): worst VDD {c['vdd']['worst_ir_drop_v']} V + VSS {c['vss']['worst_ir_drop_v']} V = {c['worst_total_drop_pct_of_supply']} % of supply")
        L.append(f"* EM screen: {json.dumps(ir.get('em_screen'))}")
    drc = pv.get("drc") or {}
    if drc:
        L.append(f"* DRC instrument self-test: {drc.get('instrument_selftest')}")
        for k, e in (drc.get("engine") or {}).items():
            L.append(f"* DRC {k}: total {e.get('total')}, outside macros {e.get('outside_macros')}, inside macro bboxes {e.get('inside_macro_bboxes')}, rules {e.get('rules_violated')}, top rules {e.get('top_rules')}")
    lvs = pv.get("lvs") or {}
    if lvs:
        L.append(f"* LVS: equivalent={lvs.get('equivalent')}, devices {lvs.get('devices_layout_vs_netlist')}, nets {lvs.get('nets_layout_vs_netlist')}, pin lists equivalent {lvs.get('pin_lists_equivalent')}; "
                 f"excluded device-less cells {lvs.get('excluded_from_netlist_no_devices')}; scope: {lvs.get('scope_note')}")
    L += ["", "### Violations / readiness", ""] + ([f"* {v}" for v in s["violations"]] or ["* none recorded"])
    L += ["", f"**{s['readiness']['label']}** - tapeout_ready = {s['readiness']['tapeout_ready']}", ""]
    return L


def sweep_sections() -> list[str]:
    L = []
    d = ROOT / "reports" / "sweeps"
    for f in sorted(d.glob("*.md")) if d.exists() else []:
        L += [f.read_text(), ""]
        png = f.with_suffix(".svg")
        if png.exists():
            L += [f"![{f.stem}](../reports/sweeps/{png.name})", ""]
    return L


def headline() -> str:
    cols = []
    for rid, title in BASES:
        s = read_json(ROOT / "reports" / rid / "summary.json")
        cols.append((title.split(" - ")[0], s))
    def row(label, fn):
        cells = []
        for _t, s in cols:
            try:
                cells.append("n/a" if s is None else str(fn(s)))
            except Exception:  # noqa: BLE001
                cells.append("n/a")
        return f"| {label} | " + " | ".join(cells) + " |"
    L = ["| | " + " | ".join(t for t, _ in cols) + " |", "|---|" + "---|" * len(cols)]
    # the summary is written BY the report stage, so that stage is still "not_run" inside its own summary: it is excluded from the count
    L.append(row("stages passed (excl. the report stage that writes this table)", lambda s: f"{sum(1 for k, v in s['stages'].items() if k != 'report' and v == 'passed')}/{sum(1 for k in s['stages'] if k != 'report')}"))
    L.append(row("source verification (RTL / gate-level)", lambda s: f"{s['source_verification']['rtl']['ok']} / {s['source_verification']['gate_level']['ok']}"))
    L.append(row("std-cell area (µm²) / cells / flops", lambda s: f"{s['synthesis']['std_cell_area_um2']:.0f} / {s['synthesis']['n_std_cells']} / {s['synthesis']['n_flops']}"))
    L.append(row("SRAM macros", lambda s: s['synthesis']['n_macros']))
    L.append(row("die (µm)", lambda s: f"{s['floorplan']['die_um'][2]:.1f} × {s['floorplan']['die_um'][3]:.1f}"))
    L.append(row("clock target (ns)", lambda s: s['constraints']['clock_period_ns']))
    L.append(row("tt setup / hold worst slack (ns)", lambda s: f"{s['timing_by_corner']['tt']['setup_worst_slack_ns']} / {s['timing_by_corner']['tt']['hold_worst_slack_ns']}"))
    L.append(row("tt min period, derived (ns)", lambda s: s['timing_by_corner']['tt']['min_period_ns_derived']))
    L.append(row("ss setup worst slack (ns)", lambda s: s['timing_by_corner']['ss']['setup_worst_slack_ns'] if 'ss' in s['timing_by_corner'] else 'not run (no macro Liberty)'))
    L.append(row("power at tt, vectorless (mW)", lambda s: f"{s['timing_by_corner']['tt']['power_w']['total_w'] * 1e3:.2f}"))
    L.append(row("global-route usage % / overflow", lambda s: f"{s['routing']['global']['usage_pct']} / {s['routing']['global']['total_overflow']}"))
    L.append(row("detailed-route violations", lambda s: s['routing']['detailed']['final_violations']))
    L.append(row("DRC Magic: outside / inside macro", lambda s: f"{s['physical_verification']['drc']['engine']['magic_drc']['outside_macros'] if s['physical_verification']['drc']['engine']['magic_drc']['outside_macros'] is not None else 0} / {s['physical_verification']['drc']['engine']['magic_drc']['inside_macro_bboxes'] or 0}"))
    L.append(row("DRC KLayout (FEOL implant rules in library cells)", lambda s: s['physical_verification']['drc']['engine']['klayout_drc']['total']))
    L.append(row("LVS (open deck)", lambda s: 'match' if s['physical_verification']['lvs']['equivalent'] else 'MISMATCH'))
    L.append(row("antenna net violations", lambda s: s['physical_verification']['antenna']['net_violations']))
    L.append(row("tapeout ready", lambda s: s['readiness']['tapeout_ready']))
    return "\n".join(L)


def update_readme() -> None:
    p = ROOT / "README.md"
    if not p.exists():
        return
    t = p.read_text()
    b, e = "<!-- HEADLINE:BEGIN -->", "<!-- HEADLINE:END -->"
    if b in t and e in t:
        pre, rest = t.split(b, 1)
        _old, post = rest.split(e, 1)
        p.write_text(pre + b + "\n" + headline() + "\n" + e + post)


def main() -> int:
    L = ["# RESULTS (generated)", "", f"*Generated {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} by `albion docgen` from `reports/`. "
         "Do not edit by hand. EXPERIMENTAL open-PDK results; nothing here is tapeout evidence.*", "",
         "## Tool versions", "", "```", json.dumps(versions(), indent=1), "```", ""]
    for rid, title in BASES:
        L += design_section(rid, title)
    L += ["# Parameter sweeps", ""] + sweep_sections()
    out = ROOT / "docs" / "RESULTS.md"
    out.write_text("\n".join(L) + "\n")
    update_readme()
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
