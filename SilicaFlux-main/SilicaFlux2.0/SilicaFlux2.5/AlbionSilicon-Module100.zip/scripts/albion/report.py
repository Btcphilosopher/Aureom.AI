"""Report builder: reports/<run>/summary.json + summary.md.

Rules enforced here:
  * every number is read from a stage result produced by an executed tool; absent => null + status not_run
  * vectorless power is labelled as an assumption-based estimate
  * a run is NEVER labelled tapeout ready (see `readiness`)
"""
from __future__ import annotations

import re
import time
from pathlib import Path

from . import synth
from .config import run_dir
from .flow import STAGES, load_state, run_openroad
from .util import ROOT, read_json, versions, write_json


def _res(cfg, stage):
    return read_json(run_dir(cfg, stage) / "result.json", None)


def _grt(cfg) -> dict:
    p = run_dir(cfg, "groute") / "groute.log"
    if not p.exists():
        return {}
    text = p.read_text(errors="replace")
    tables = re.findall(r"^Total\s+(\d+)\s+(\d+)\s+([\d.]+)%\s+(\d+)\s*/\s*(\d+)\s*/\s*(\d+)", text, flags=re.M)
    wl = re.findall(r"Total wirelength:\s*(\d+) um", text)
    nets = re.findall(r"Routed nets:\s*(\d+)", text)
    out = {}
    if tables:
        r, dmd, use, h, v, tot = tables[-1]
        out.update({"resource": int(r), "demand": int(dmd), "usage_pct": float(use), "max_h_overflow": int(h),
                    "max_v_overflow": int(v), "total_overflow": int(tot)})
    if wl:
        out["wirelength_um"] = int(wl[-1])
    if nets:
        out["routed_nets"] = int(nets[-1])
    layers = {}
    if tables:
        for ln in text.splitlines():
            m = re.match(r"^(li1|met\d)\s+(\d+)\s+(\d+)\s+([\d.]+)%\s+(\d+)\s*/\s*(\d+)\s*/\s*(\d+)", ln)
            if m:
                layers[m.group(1)] = {"usage_pct": float(m.group(4)), "overflow": int(m.group(7))}
    out["per_layer"] = layers
    return out


def _drt(cfg) -> dict:
    p = run_dir(cfg, "droute") / "droute.log"
    if not p.exists():
        return {}
    text = p.read_text(errors="replace")
    out = {}
    m = re.findall(r"Total wire length = (\d+) um", text)
    if m:
        out["wirelength_um"] = int(m[-1])
    m = re.findall(r"Total number of vias = (\d+)", text)
    if m:
        out["vias"] = int(m[-1])
    m = re.findall(r"Number of violations = (\d+)", text)
    if m:
        out["final_violations"] = int(m[-1])
    layers = {}
    for ly, v in re.findall(r"Total wire length on LAYER (\w+) = (\d+) um", text)[-6:]:
        layers[ly] = int(v)
    out["wirelength_by_layer_um"] = layers
    cpu = re.findall(r"cpu time = ([\d:]+), elapsed time = ([\d:]+)", text)
    if cpu:
        out["router_elapsed"] = cpu[-1][1]
    return out


def stage_report(cfg, prof) -> dict:
    run = run_dir(cfg)
    st = load_state(cfg)
    # database metrics (fast OpenROAD pass)
    mres = {}
    if (run / "droute" / "droute.odb").exists():
        r = run_openroad(cfg, prof, "metrics.tcl", "metrics", timeout=1800)
        mres = r.get("metrics", {})
    synth_r = _res(cfg, "synth") or {}
    sta = _res(cfg, "signoff_sta") or {}
    plan = read_json(run / "plan" / "plan.json", {})
    cts = _res(cfg, "cts") or {}
    ir = _res(cfg, "irdrop")
    ant = _res(cfg, "antenna")
    drc = _res(cfg, "drc")
    lvs = _res(cfg, "lvs")
    gls = _res(cfg, "gls")
    rtl = _res(cfg, "verify_rtl")
    P = float(cfg["clock"]["period_ns"])
    corners = {}
    for c, d in (sta.get("corners") or {}).items():
        t = d["timing"]
        ws = t.get("ws_setup")
        corners[c] = {
            "setup_worst_slack_ns": ws, "hold_worst_slack_ns": t.get("ws_hold"), "setup_tns_ns": t.get("tns_setup"),
            "setup_violating_endpoints": t.get("viol_setup"), "hold_violating_endpoints": t.get("viol_hold"),
            "min_period_ns_derived": round(P - ws, 4) if ws is not None else None,
            "fmax_mhz_derived": round(1000.0 / (P - ws), 2) if ws is not None and P - ws > 0 else None,
            "unconstrained_endpoints": d.get("unconstrained_endpoints"),
            "power_w": d.get("power"), "clock_skew": d.get("skew"),
            "drv_lines": d.get("drv_report_lines"), "drv_violations": d.get("drv_violations"),
            "extraction": d.get("rcx_rules"),
        }
    stages = {}
    for s in STAGES:
        e = st.get(s)
        stages[s] = ("passed" if e and e["ok"] else "failed" if e else "not_run")
    area = {k.replace("area_", ""): v for k, v in mres.items() if k.startswith("area_")}
    count = {k.replace("count_", ""): v for k, v in mres.items() if k.startswith("count_")}
    placeable = (mres.get("core_area") or 0) - (area.get("macro") or 0)
    util = None
    if placeable > 0:
        util = round(100.0 * ((area.get("std") or 0) + (area.get("tap") or 0) + (area.get("clk") or 0) + (area.get("buf_io") or 0)
                              + (area.get("hold") or 0) + (area.get("diode") or 0) + (area.get("tie") or 0)) / placeable, 2)
    violations = []
    for c, d in corners.items():
        if d["setup_violating_endpoints"]:
            violations.append(f"setup violations at {c}: {d['setup_violating_endpoints']}")
        if d["hold_violating_endpoints"]:
            violations.append(f"hold violations at {c}: {d['hold_violating_endpoints']}")
        if d.get("drv_violations"):
            violations.append(f"max slew/cap/fanout violations at {c}: {d['drv_violations']} (see drv report)")
        unc = sta.get("unconstrained") or {}
        if (unc.get("other") or 0) > 0 or (d["unconstrained_endpoints"] or 0) > (unc.get("total") or 0):
            violations.append(f"unconstrained endpoints at {c} that are NOT constant-driven: {unc.get('other')} (corner total {d['unconstrained_endpoints']})")
    grt = _grt(cfg)
    drt = _drt(cfg)
    if not (st.get("droute") or {}).get("ok"):
        # an unfinished/killed route must not publish intermediate router-log numbers as results
        drt = {"status": "NOT COMPLETED", "last_logged_violations": drt.get("final_violations"),
               "note": "detailed routing did not finish; no final wirelength/via/DRC figures exist"}
    if grt.get("total_overflow"):
        violations.append(f"global-route overflow {grt['total_overflow']}")
    if drt.get("status") == "NOT COMPLETED":
        violations.append(f"detailed routing NOT COMPLETED (last logged router violations: {drt.get('last_logged_violations')})")
    elif drt.get("final_violations"):
        violations.append(f"detail-route DRC violations {drt['final_violations']}")
    summary = {
        "run_id": cfg["run_id"], "design": cfg["design"], "variant": cfg["variant"], "overrides": cfg.get("overrides", {}),
        "config_sha256": cfg["config_sha256"], "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "pdk": {"profile": prof["profile"], "class": prof["pdk_class"], "signoff_eligible": prof["signoff_eligible"],
                "provenance": prof.get("provenance")},
        "tools": versions(),
        "stages": stages,
        "source_verification": {
            "rtl": {"ok": rtl.get("ok") if rtl else None, "detail": {k: rtl.get(k) for k in ("n_runs", "n_pass", "scenarios", "vendor_macro_model_log_events", "backdoor_checker_live", "note")} if rtl else None},
            "gate_level": {"ok": gls.get("ok") if gls else None, "checks": gls.get("checks") if gls else None, "scenarios": gls.get("scenarios") if gls else None},
        },
        "synthesis": {k: synth_r.get(k) for k in ("std_cell_area_um2", "n_std_cells", "n_flops", "n_macros", "latches_rtl", "latches_mapped",
                                                   "n_port_bits", "abc_period_ps", "cell_histogram")},
        "constraints": {"clock_period_ns": P, "n_exceptions": len(cfg["io"].get("exceptions", [])), "exceptions": cfg["io"].get("exceptions", []),
                        "io_budget": {k: cfg["io"][k] for k in ("input_delay_frac", "output_delay_frac")},
                        "clock_uncertainty_ns": {"setup": cfg["clock"]["uncertainty_setup_ns"], "hold": cfg["clock"]["uncertainty_hold_ns"]}},
        "floorplan": {"die_um": plan.get("die"), "core_um": plan.get("core"), "macros": [
            {"name": m["name"], "cell": m["cell"], "x": m["x"], "y": m["y"], "w": m["w"], "h": m["h"]} for m in plan.get("macros", [])],
            "halo_um": plan.get("halo"), "target_utilization": plan.get("target_utilization"),
            "achieved_pre_place_utilization": plan.get("achieved_pre_place_utilization"),
            "utilization_note": "target is an UPPER bound: for macro designs the core is sized by the macro footprint + halos, so achieved utilization is lower",
            "legality": (plan.get("legality") or {}).get("ok"), "io_pins_by_edge": {e: len(v) for e, v in (plan.get("pin_groups", {}).get("edges") or {}).items()}},
        "area_um2": {**area, "core": mres.get("core_area"), "die": mres.get("die_area"), "std_logic_core_utilization_pct": util},
        "instance_counts": count,
        "unconstrained_endpoints": sta.get("unconstrained"),
        "timing_by_corner": corners,
        "timing_stages_tt": {
            "pre_layout_ideal_clock": {"ws_setup": (_res(cfg, "sta_pre") or {}).get("setup_wns_ns"), "ws_hold": (_res(cfg, "sta_pre") or {}).get("hold_ws_ns"), "viol_hold": None},
            "post_place_est": (_res(cfg, "place") or {}).get("timing"),
            "post_cts_before_repair": cts.get("timing_pre_repair"),
            "post_cts_after_repair": cts.get("timing"),
            "post_groute_est": (_res(cfg, "groute") or {}).get("timing"),
        },
        "clock_tree": {"log": cts.get("cts_log"), "clock_tree_instances": (cts.get("metrics") or {}).get("clock_tree_instances")},
        "routing": {"global": grt, "detailed": drt, "db_wire_length_um": None, "db_vias": None,
                    "signal_nets": mres.get("nets_signal")},
        "physical_verification": {
            "antenna": ({k: ant.get(k) for k in ("net_violations", "pin_violations", "engine")} if ant else None),
            "ir_drop_screen": ({"log": ir.get("irdrop_log"), "ok": ir.get("ok")} if ir else None),
            "electromigration": {"status": "not_run", "reason": "no open-source EM engine is bound; hook only (docs/06_PHYSICAL_VERIFICATION.md)"},
            "drc": drc, "lvs": lvs,
        },
        "violations": violations,
        "readiness": readiness(cfg, prof, stages),
        "labels": labels(cfg),
    }
    out = ROOT / "reports" / cfg["run_id"]
    write_json(out / "summary.json", summary)
    (out / "summary.md").write_text(to_markdown(summary))
    return {"ok": True, "summary": str(out / "summary.json"), "violations": violations}


def labels(cfg) -> list[str]:
    """Labels that MUST accompany this run's numbers wherever they are quoted."""
    out = ["EXPERIMENTAL: open public PDK, community decks, vectorless power"]
    p = cfg["source"]["params"]
    if cfg["source"]["verification"]["kind"] == "m04_scratchpad" and p.get("BACKEND") == 0:
        out.append("FLOP-BASED MEMORY EXPERIMENT: storage is synthesized into flip-flops. Area and power are NOT representative of an SRAM macro "
                   "and must not be quoted as SRAM figures.")
    return out


def readiness(cfg, prof, stages) -> dict:
    reasons = []
    if prof["pdk_class"] != "commercial_production":
        reasons.append("technology is an open public PDK (experimental); no production-qualified kit")
    reasons += ["no foundry signoff DRC/LVS/antenna/density decks run", "no signoff-grade parasitic extraction or multi-corner/OCV STA",
                "no DFT insertion, ATPG or MBIST", "no I/O pad ring / ESD / package model", "no PLL / clock IP", "no vector-based power or EM/IR signoff",
                "no foundry-qualified SRAM compiler output (OpenRAM macros used as published)"]
    return {"tapeout_ready": False, "label": "EXPERIMENTAL (open PDK)", "blockers": reasons}


def to_markdown(s: dict) -> str:
    L = [f"# {s['run_id']}", "", f"*generated {s['generated_utc']} · config `{s['config_sha256'][:12]}` · PDK `{s['pdk']['profile']}` "
         f"(**{s['pdk']['class']}**, signoff_eligible={s['pdk']['signoff_eligible']})*", ""]
    for lab in s.get("labels", [])[1:]:          # run-specific labels (e.g. flop-memory experiment) come first and must travel with the numbers
        L += [f"> **LABEL:** {lab}", ">"]
    L += ["> **Experimental result on an open public PDK. NOT tapeout ready.** Every number below was produced by a tool run recorded in this archive; "
          "`null` / `not_run` means the measurement does not exist.", ""]
    L += ["## Stages", "", "| stage | status |", "|---|---|"] + [f"| {k} | {'(this stage writes the table)' if k == 'report' else v} |" for k, v in s["stages"].items()] + [""]
    sy = s["synthesis"]
    L += ["## Synthesis", "", f"* standard-cell area {sy.get('std_cell_area_um2')} µm², {sy.get('n_std_cells')} cells, {sy.get('n_flops')} flops, "
          f"{sy.get('n_macros')} macros, latches (RTL/mapped) {sy.get('latches_rtl')}/{sy.get('latches_mapped')}"]
    a = s["area_um2"]
    L += ["", "## Area / utilisation (final database)", "", f"* die {a.get('die')} µm², core {a.get('core')} µm², std-logic core utilisation {a.get('std_logic_core_utilization_pct')} %",
          f"* breakdown µm²: " + ", ".join(f"{k}={v}" for k, v in a.items() if k not in ("core", "die", "std_logic_core_utilization_pct"))]
    L += ["", "## Timing (post-route, OpenRCX + OpenSTA)", "", "| corner | setup WS (ns) | hold WS (ns) | setup viol | hold viol | min period (derived) | Fmax MHz (derived) | unconstrained (total) |", "|---|---|---|---|---|---|---|---|"]
    for c, d in s["timing_by_corner"].items():
        L.append(f"| {c} | {d['setup_worst_slack_ns']} | {d['hold_worst_slack_ns']} | {d['setup_violating_endpoints']} | {d['hold_violating_endpoints']} | "
                 f"{d['min_period_ns_derived']} | {d['fmax_mhz_derived']} | {d['unconstrained_endpoints']} |")
    u = s.get("unconstrained_endpoints") or {}
    L += ["", f"Unconstrained endpoints: {u.get('total')} total = {u.get('const')} constant-driven (no launching path exists: tie-cell outputs / unused macro port) + {u.get('other')} other (genuine constraint gaps)."]
    L += ["", "## Power (vectorless; activity assumed, NOT measured)", ""]
    for c, d in s["timing_by_corner"].items():
        pw = d.get("power_w") or {}
        L.append(f"* {c}: total {pw.get('total_w')} W (internal {pw.get('internal_w')}, switching {pw.get('switching_w')}, leakage {pw.get('leakage_w')})")
    r = s["routing"]
    L += ["", "## Routing", "", f"* global route: {r['global']}", f"* detailed route: {r['detailed']}"]
    pv = s["physical_verification"]
    L += ["", "## Physical verification (experimental decks)", "", f"* antenna: {pv['antenna']}", f"* IR-drop screen: {pv['ir_drop_screen']}",
          f"* EM: {pv['electromigration']}", f"* DRC: {pv['drc']}", f"* LVS: {pv['lvs']}"]
    L += ["", "## Violations", ""] + ([f"* {v}" for v in s["violations"]] or ["* none recorded by the stages that ran"])
    L += ["", "## Readiness", "", f"**{s['readiness']['label']}** — tapeout_ready = {s['readiness']['tapeout_ready']}", ""] + [f"* {b}" for b in s["readiness"]["blockers"]]
    return "\n".join(L) + "\n"
