"""Shared log/report parsers (kept separate so stages.py and verify.py do not import each other)."""
from __future__ import annotations

import re


def _timing(d, label):
    """Parse report_worst_slack/tns output written by common.tcl::timing_summary."""
    f = d / f"timing_{label}.rpt"
    out = {"wns_setup": None, "ws_setup": None, "ws_hold": None, "tns_setup": None}
    if f.exists():
        nums = re.findall(r"(?:worst slack|tns|wns)\s+(-?[\d.]+(?:e[-+]?\d+)?)", f.read_text())
        if len(nums) >= 4:
            out["ws_setup"], out["ws_hold"], out["tns_setup"], out["wns_setup"] = (float(x) for x in nums[:4])
    for kind, fn in (("setup", f"endpoints_setup_{label}.rpt"), ("hold", f"endpoints_hold_{label}.rpt")):
        ff = d / fn
        n = 0
        if ff.exists():
            n = len([ln for ln in ff.read_text().splitlines() if re.search(r"\(VIOLATED\)", ln)])
        out[f"viol_{kind}"] = n
    return out


def _grep(text: str, pat: str) -> list[str]:
    return [ln.strip() for ln in text.splitlines() if re.search(pat, ln)]
