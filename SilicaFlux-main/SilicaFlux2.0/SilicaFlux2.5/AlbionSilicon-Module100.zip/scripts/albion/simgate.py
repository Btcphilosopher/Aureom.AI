"""Functional gates: verify_rtl (source RTL) and gls (synthesized gate-level netlist).

verify_rtl re-runs the UPSTREAM self-checking testbench of the selected subsystem with this programme's tools.
gls reruns the same checker against the synthesized netlist with the real sky130 cell models.
Nothing here is a coverage or sign-off claim; it is a functional smoke gate that can fail.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

from .config import run_dir, source_files
from .util import ROOT, run, write_json

M04_TESTS = ["smoke", "all_banks", "boundaries", "unaligned", "byte_mask", "conflict", "parallel", "backpressure",
             "reset", "rdw", "oor", "stall_preserve", "random"]


def _import_mesh_modules(cfg):
    sys.dont_write_bytecode = True        # keep vendor/ byte-identical to the upstream archive (no __pycache__ written into it)
    v = cfg["source"]["verification"]
    sys.path.insert(0, str(ROOT / v["scenario_dir"]))
    sys.path.insert(0, str(ROOT / v["model_dir"]))
    import importlib
    ref = importlib.import_module("tensor_pe_ref")
    ms = importlib.import_module("mesh_scenarios")
    return ref, ms


def _mesh_scenarios(cfg):
    p = cfg["source"]["params"]
    v = cfg["source"]["verification"]
    ref, ms = _import_mesh_modules(cfg)
    pe = ref.PeConfig(a_w=p["A_W"], b_w=p["B_W"], acc_w=p["ACC_W"], mul_stages=p["MUL_STAGES"], policy=p["OVF_POLICY"],
                      operand_gating=bool(p["OPERAND_GATING"]))
    out = []
    for tag, seed, ovf in (("base", v["seed"], False), ("overflow", v["seed"] + 1, True)):
        lines, expected, tl, stream = ms.build(pe, p["ROWS"], p["COLS"], v["tiles"], seed=seed, overflow_tiles=ovf)
        out.append((tag, lines, expected, tl, stream))
    return ms, out


def _tb_params(cfg):
    p = cfg["source"]["params"]
    return {k: p[k] for k in ("ROWS", "COLS", "A_W", "B_W", "ACC_W", "MUL_STAGES", "OVF_POLICY", "OPERAND_GATING")}


def verify_rtl(cfg, prof) -> dict:
    kind = cfg["source"]["verification"]["kind"]
    d = run_dir(cfg, "verify_rtl")
    if kind == "tensorcore_mesh":
        return _verify_mesh(cfg, d, netlist=None)
    if kind == "m04_scratchpad":
        return _verify_m04(cfg, prof, d)
    return {"ok": False, "error": f"unknown verification kind {kind}"}


def _verify_mesh(cfg, d: Path, netlist: str | None, label="rtl") -> dict:
    v = cfg["source"]["verification"]
    ms, scen = _mesh_scenarios(cfg)
    params = _tb_params(cfg)
    tb = str(ROOT / v["tb"])
    files = source_files(cfg)
    sims = []
    if netlist is None:
        cmd = ["iverilog", "-g2012", "-s", "tb_tensor_pe_mesh", "-o", str(d / "tb.vvp")] + \
              [f"-Ptb_tensor_pe_mesh.{k}={val}" for k, val in params.items()] + files + [tb]
    else:
        cmd = netlist  # list prepared by gls()
    r = run(cmd, d / "build.log", fatal=[r"error:"])
    if r["rc"] != 0:
        return {"ok": False, "stage": label, "error": "simulator build failed", "build_log": str(d / "build.log"), "fatal": r["fatal_hits"]}
    allok = True
    for tag, lines, expected, tl, stream in scen:
        stim = d / f"stim_{tag}.txt"
        ms.write_stim(lines, str(stim))
        toks = d / f"tokens_{tag}.txt"
        rr = run(["vvp", "-n", str(d / "tb.vvp"), f"+STIM={stim}", f"+TOKENS={toks}"], d / f"sim_{tag}.log", cwd=d, fatal=[])
        log = (d / f"sim_{tag}.log").read_text(errors="replace")
        errs, msgs, st = ms.compare(str(toks), expected, params["ROWS"], params["COLS"])
        align = [ln for ln in log.splitlines() if "violated" in ln][:5]
        xerr = [ln for ln in log.splitlines() if "X" in ln and "acc_valid" in ln][:3]
        ok = rr["rc"] == 0 and errs == 0 and not align and "MESH_RESULT: DONE" in log
        n_tok = sum(1 for _ in open(toks)) if toks.exists() else 0
        sims.append({"scenario": tag, "ok": ok, "token_errors": errs, "tokens_checked": n_tok, "cycles": len(lines),
                     "tiles": len(tl), "alignment_failures": align, "msgs": list(msgs)[:3]})
        allok &= ok
    res = {"ok": allok, "stage": label, "simulator": "iverilog", "scenarios": sims, "params": params}
    write_json(d / f"{label}.json", res)
    return res


def _m04_files(cfg, prof):
    from .synth import macro_cells
    return source_files(cfg), [m["verilog_path"] for m in macro_cells(cfg, prof)]


def m04_patched_tb(cfg, d: Path) -> tuple[Path, str]:
    """Runtime patch of the vendored upstream TB (vendored file stays untouched):
       (1) forward a MACRO parameter to the DUT (upstream hard-codes .MACRO(0));
       (2) add an ASIC branch to the backdoor array checker that points at the vendor macro model's `mem`.
    Returns (patched path, unified diff)."""
    import difflib
    src = ROOT / cfg["source"]["verification"]["tb"]
    t = src.read_text()
    new = t.replace("parameter int          BACKEND = 0;", "parameter int          BACKEND = 0;\n  parameter int          MACRO   = 0;")
    new = new.replace(".MACRO(0)", ".MACRO(MACRO)")
    leaf_blk = {1: "g_1", 2: "g_2", 3: "g_3"}[int(cfg["source"]["params"]["MACRO"])]
    new = new.replace("    end else begin : g_gen\n",
                      "    end else if (BACKEND == 2) begin : g_asic\n"
                      f"      `TB_BACKDOOR_BODY(dut.g_core.g_bank[b].u_bank.g_ram.u_ram.g_asic.u_mem.g_r[0].g_c[0].g_sky130.u_leaf.{leaf_blk}.u_macro.mem)\n"
                      "    end else begin : g_gen\n")
    out = d / "tb_hpc_scratchpad_asic.sv"
    out.write_text(new)
    diff = "".join(difflib.unified_diff(t.splitlines(True), new.splitlines(True), "tb_hpc_scratchpad.sv (upstream)",
                                        "tb_hpc_scratchpad_asic.sv (patched at run time)"))
    (d / "tb_patch.diff").write_text(diff)
    return out, diff


def _verify_m04(cfg, prof, d: Path) -> dict:
    files, macro_v = _m04_files(cfg, prof)
    p = cfg["source"]["params"]
    if p["BACKEND"] == 0:
        return _verify_m04_generic(cfg, files, d)
    if p["BACKEND"] != 2:
        return {"ok": False, "error": "this gate supports BACKEND=2 (ASIC macro) and BACKEND=0 (GENERIC flop array, labelled experiment)"}
    macro_words = {1: 256, 2: 512, 3: 1024}.get(int(p["MACRO"]))
    words_per_bank = p["CAPACITY_BYTES"] // p["NUM_BANKS"] // (p["DATA_WIDTH"] // 8)
    if p["DATA_WIDTH"] != 32 or macro_words is None or words_per_bank != macro_words:
        return {"ok": False, "error": "backdoor path supports configurations where every bank is exactly ONE 32-bit macro "
                f"(DATA_WIDTH=32, words/bank {words_per_bank} must equal macro words {macro_words})"}
    tb, diff = m04_patched_tb(cfg, d)
    incs = [f"-I{ROOT / x}" for x in cfg["source"]["incdirs"]]
    tbp = {"NP": p["NUM_PORTS"], "CAP": p["CAPACITY_BYTES"], "NB": p["NUM_BANKS"], "DW": p["DATA_WIDTH"],
           "AW": p["ADDR_WIDTH"], "TAGW": p["TAG_W"], "RL": p["READ_LATENCY"], "BACKEND": p["BACKEND"], "MACRO": p["MACRO"]}
    cmd = ["iverilog", "-g2012", "-DHPC_SPM_ASSERT", "-DSRAMLIB_ASSERT", "-DSRAMLIB_POISON", "-DSRAMLIB_VENDOR_MODELS"] + incs + \
          ["-s", "tb_hpc_scratchpad", "-o", str(d / "tb.vvp")] + [f"-Ptb_hpc_scratchpad.{k}={v}" for k, v in tbp.items()] + \
          [str(tb)] + files + macro_v
    r = run(cmd, d / "build.log", fatal=[r"error:"])
    if r["rc"] != 0:
        return {"ok": False, "error": "simulator build failed", "fatal": r["fatal_hits"], "build_log": str(d / "build.log")}
    results = []
    macro_events = 0
    for t in M04_TESTS:
        for seed in (1, 2):
            lg = d / f"sim_{t}_{seed}.log"
            rr = run(["vvp", "-n", str(d / "tb.vvp"), f"+test={t}", f"+seed={seed}"], lg, cwd=d, fatal=[])
            txt = lg.read_text(errors="replace")
            passed = f"TEST {t} PASSED" in txt and rr["rc"] == 0
            macro_events += len(re.findall(r"u_macro", txt))
            results.append({"test": t, "seed": seed, "ok": passed, "seconds": rr["seconds"]})
    ok = all(x["ok"] for x in results)
    bd = "backdoor self-test: injected corruption detected" in (d / "sim_smoke_1.log").read_text(errors="replace")
    res = {"ok": ok and macro_events > 0 and bd, "stage": "rtl", "simulator": "iverilog",
           "n_runs": len(results), "n_pass": sum(1 for x in results if x["ok"]), "tests": results,
           "vendor_macro_model_log_events": macro_events, "backdoor_checker_live": bd,
           "tb_patch": "tb_patch.diff", "params": tbp,
           "note": "upstream TB patched at run time: MACRO param forwarded + ASIC backdoor path to vendor model mem; upstream never ran BACKEND=ASIC"}
    write_json(d / "rtl.json", res)
    return res


def _verify_m04_generic(cfg, files, d: Path) -> dict:
    """GENERIC backend = behavioural array that synthesis turns into FLIP-FLOPS.  Upstream verified this backend heavily, so the
    UNPATCHED upstream testbench runs here.  This configuration is a labelled flop-memory experiment, NOT an SRAM macro."""
    p = cfg["source"]["params"]
    tb = ROOT / cfg["source"]["verification"]["tb"]
    incs = [f"-I{ROOT / x}" for x in cfg["source"]["incdirs"]]
    tbp = {"NP": p["NUM_PORTS"], "CAP": p["CAPACITY_BYTES"], "NB": p["NUM_BANKS"], "DW": p["DATA_WIDTH"], "AW": p["ADDR_WIDTH"],
           "TAGW": p["TAG_W"], "RL": p["READ_LATENCY"], "BACKEND": 0}
    cmd = ["iverilog", "-g2012", "-DHPC_SPM_ASSERT", "-DSRAMLIB_ASSERT", "-DSRAMLIB_POISON"] + incs + ["-s", "tb_hpc_scratchpad", "-o", str(d / "tb.vvp")] + \
          [f"-Ptb_hpc_scratchpad.{k}={v}" for k, v in tbp.items()] + [str(tb)] + files
    r = run(cmd, d / "build.log", fatal=[r"error:"])
    if r["rc"] != 0:
        return {"ok": False, "error": "simulator build failed", "fatal": r["fatal_hits"], "build_log": str(d / "build.log")}
    results = []
    for t in M04_TESTS:
        for seed in (1, 2):
            lg = d / f"sim_{t}_{seed}.log"
            rr = run(["vvp", "-n", str(d / "tb.vvp"), f"+test={t}", f"+seed={seed}"], lg, cwd=d, fatal=[])
            results.append({"test": t, "seed": seed, "ok": f"TEST {t} PASSED" in lg.read_text(errors="replace") and rr["rc"] == 0, "seconds": rr["seconds"]})
    res = {"ok": all(x["ok"] for x in results), "stage": "rtl", "simulator": "iverilog", "n_runs": len(results), "n_pass": sum(1 for x in results if x["ok"]),
           "tests": results, "params": tbp, "memory_model": "flop_array",
           "note": "GENERIC backend, unpatched upstream testbench. LABELLED EXPERIMENT: storage is synthesized into flip-flops; area/power are NOT representative of an SRAM macro."}
    write_json(d / "rtl.json", res)
    return res


# ------------------------------------------------------------------ gate-level simulation
def functionalize(mod: str) -> str:
    """Make a foundry cell model simulatable in Icarus at zero delay.

    The packaged sky130 models are timing-aware: sequential cells use `D_delayed`, `CLK_delayed`, ... nets that are
    driven only by `$setuphold/$recrem` timing checks, which Icarus does not implement (the nets stay X).  We drop
    the `specify` block and tie every `<pin>_delayed` net to `<pin>`.  Logic, UDP tables and reset behaviour are the
    foundry's own; only the timing checks are removed (functional gate-level simulation, no timing).
    """
    mod = re.sub(r"\bspecify\b.*?\bendspecify\b", "", mod, flags=re.S)
    ties = "".join(f"    assign {n}_delayed = {n};\n" for n in sorted(set(re.findall(r"wire\s+(\w+)_delayed\s*;", mod))))
    return mod.replace("endmodule", ties + "endmodule", 1)


def reduced_cell_models(prof, netlist: Path, out: Path) -> dict:
    """Extract only the cells (and UDP primitives) used by `netlist` from the PDK Verilog."""
    used = set(re.findall(r"^\s*(sky130_fd_sc_hd__\w+)\s+\S+\s*\(", netlist.read_text(), flags=re.M))
    src = Path(prof["files"]["stdcell_verilog"]).read_text()
    prim = Path(prof["files"]["stdcell_primitives"]).read_text()
    mods = {}
    for m in re.finditer(r"(?:^|\n)\s*(?:`celldefine\s*)?module\s+(\w+)\b.*?endmodule", src, flags=re.S):
        mods[m.group(1)] = m.group(0)
    prims = {}
    for m in re.finditer(r"(?:^|\n)\s*primitive\s+([\w$]+).*?endprimitive", prim, flags=re.S):
        prims[m.group(1)] = m.group(0)
    keep, udps = [], set()
    for u in sorted(used):
        if u not in mods:
            continue
        keep.append(functionalize(mods[u]))
        for pn in prims:
            if pn in mods[u]:
                udps.add(pn)
    out.write_text("`timescale 1ns/1ps\n`default_nettype none\n" + "\n".join(prims[p] for p in sorted(udps)) + "\n" + "\n".join(keep) + "\n")
    return {"cells_used": len(used), "cells_found": len(keep), "udps": sorted(udps), "missing": sorted(used - set(mods))}


MESH_SHIM = """`timescale 1ns/1ps
module tensor_pe_mesh #(
  parameter int unsigned ROWS=4, COLS=4, A_W=8, B_W=8, ACC_W=32, MUL_STAGES=1, OVF_POLICY=0,
  parameter bit OPERAND_GATING=1'b1, parameter int unsigned K_LIMIT_SEVERITY=1
) (
  input  wire clk_i, input wire rst_ni, input wire enable_i,
  input  wire [ROWS*A_W-1:0] west_a_i, input wire [ROWS-1:0] west_valid_i, input wire [ROWS-1:0] west_clear_i,
  input  wire [COLS*B_W-1:0] north_b_i,
  output wire [ROWS*COLS*ACC_W-1:0] acc_result_o, output wire [ROWS*COLS-1:0] acc_valid_o, output wire [ROWS*COLS-1:0] overflow_o,
  output wire [ROWS*A_W-1:0] east_a_o, output wire [ROWS-1:0] east_valid_o, output wire [ROWS-1:0] east_clear_o,
  output wire [COLS*B_W-1:0] south_b_o, output wire [COLS-1:0] south_valid_o
);
  tensor_pe_mesh_gl u_gl (.*);
endmodule
"""


def gls(cfg, prof) -> dict:
    d = run_dir(cfg, "gls")
    netlist = run_dir(cfg, "synth") / "netlist.v"
    if not netlist.exists():
        return {"ok": False, "error": "no synthesized netlist"}
    kind = cfg["source"]["verification"]["kind"]
    models = d / "cell_models.v"
    mi = reduced_cell_models(prof, netlist, models)
    if mi["missing"]:
        return {"ok": False, "error": f"cells without simulation models: {mi['missing'][:5]}"}
    if kind == "tensorcore_mesh":
        gl = d / "netlist_gl.v"
        top = cfg["source"]["top"]
        gl.write_text(re.sub(rf"\bmodule\s+{top}\b", f"module {top}_gl", netlist.read_text(), count=1))
        shim = d / "mesh_shim.v"
        shim.write_text(MESH_SHIM)
        v = cfg["source"]["verification"]
        params = _tb_params(cfg)
        cmd = ["iverilog", "-g2012", "-DFUNCTIONAL", "-DUNIT_DELAY=#0", "-s", "tb_tensor_pe_mesh", "-o", str(d / "tb.vvp")] + \
              [f"-Ptb_tensor_pe_mesh.{k}={val}" for k, val in params.items()] + [str(ROOT / v["tb"]), str(shim), str(gl), str(models)]
        res = _verify_mesh(cfg, d, netlist=cmd, label="gls")
        res["cell_models"] = mi
        return res
    if kind == "m04_scratchpad":
        return _gls_m04(cfg, prof, d, netlist, models, mi)
    return {"ok": False, "error": f"no GLS for kind {kind}"}


def _gls_m04(cfg, prof, d, netlist, models, mi) -> dict:
    from .synth import macro_cells
    from .gls_tb import write_spm_gls_tb
    macs = macro_cells(cfg, prof)
    gl = d / "netlist_gl.v"
    top = cfg["source"]["top"]
    gl.write_text(netlist.read_text())
    tb = d / "tb_spm_gls.sv"
    write_spm_gls_tb(cfg, tb)
    cmd = ["iverilog", "-g2012", "-DFUNCTIONAL", "-DUNIT_DELAY=#0", "-s", "tb_spm_gls", "-o", str(d / "tb.vvp"), str(tb), str(gl),
           str(models)] + [m["verilog_path"] for m in macs]
    r = run(cmd, d / "build.log", fatal=[r"error:"])
    if r["rc"] != 0:
        return {"ok": False, "error": "gate-level build failed", "build_log": str(d / "build.log"), "fatal": r["fatal_hits"]}
    rr = run(["vvp", "-n", str(d / "tb.vvp")], d / "sim.log", cwd=d, fatal=[])
    txt = (d / "sim.log").read_text(errors="replace")
    m = re.search(r"SPM_GLS_RESULT: (PASS|FAIL).*?checks=(\d+).*?errors=(\d+)", txt)
    ok = bool(m) and m.group(1) == "PASS" and int(m.group(3)) == 0 and rr["rc"] == 0
    res = {"ok": ok, "stage": "gls", "simulator": "iverilog", "checks": int(m.group(2)) if m else 0,
           "errors": int(m.group(3)) if m else None, "cell_models": mi,
           "note": "TB authored in this programme (not upstream): front-door write/read/byte-mask/oor checks vs a simple model"}
    write_json(d / "gls.json", res)
    return res
