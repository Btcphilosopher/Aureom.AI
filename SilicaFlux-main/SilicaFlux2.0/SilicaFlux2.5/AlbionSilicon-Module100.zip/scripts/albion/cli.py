"""AlbionSilicon command line.  Run from physical/albion/scripts:  python3 -m albion <command> ...

Standalone:   pdk-check [--pdk P] | fetch-pdk [--pdk P] | versions
Per-design:   <stage> --design pe_mesh|spm [--variant NAME] [--set key=value ...]
              flow --design D [--to STAGE]      run every stage up to STAGE
              sweep --sweep config/sweeps/X.yaml [--jobs N]
              gates --design D [--variant V] [--tier experimental|tapeout]
"""
from __future__ import annotations

import argparse
import json
import sys

from . import config as cfgmod
from . import pdk as pdkmod
from .flow import STAGES
from .util import versions


def _load(args):
    ov = dict(cfgmod.parse_override(s) for s in (args.set or []))
    cfg = cfgmod.load_design(args.design, ov, args.variant)
    cfgmod.save_resolved(cfg)
    return cfg


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="albion")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def per_design(name, help_):
        p = sub.add_parser(name, help=help_)
        p.add_argument("--design", required=True)
        p.add_argument("--variant", default="base")
        p.add_argument("--set", action="append", help="override, e.g. clock.period_ns=8")
        return p

    p = sub.add_parser("pdk-check"); p.add_argument("--pdk", default="sky130hd")
    p = sub.add_parser("fetch-pdk"); p.add_argument("--pdk", default="sky130hd")
    sub.add_parser("versions")
    sub.add_parser("docgen")
    p = sub.add_parser("rereport", help="re-run the report stage of a finished run from its saved resolved.json")
    p.add_argument("--run-id", required=True)
    p.add_argument("--stages", default="report", help="comma separated stages to re-run in order (default: report)")
    sub.add_parser("audit")
    for s in STAGES:
        p = per_design(s, f"run stage {s}")
        p.add_argument("--force", action="store_true", help="ignore prerequisite state")
    p = per_design("flow", "run all stages up to --to")
    p.add_argument("--to", default="report")
    p.add_argument("--skip", default="", help="comma separated stages to skip (e.g. drc,lvs)")
    p = sub.add_parser("sweep"); p.add_argument("--sweep", required=True); p.add_argument("--jobs", type=int, default=2)
    p.add_argument("--only", help="comma separated point names"); p.add_argument("--to", default="report"); p.add_argument("--force", action="store_true")
    p.add_argument("--analyse-only", action="store_true", help="do not run flows; rebuild the sweep tables from existing reports")
    p = per_design("gates", "evaluate CI gates for an already-built run")
    p.add_argument("--tier", default="experimental")
    p = sub.add_parser("clean"); p.add_argument("--design"); p.add_argument("--variant", default="base")
    args = ap.parse_args(argv)

    if args.cmd == "pdk-check":
        r = pdkmod.techcheck(args.pdk)
        print(json.dumps(r, indent=2))
        return 0 if r["ok"] else 2
    if args.cmd == "fetch-pdk":
        r = pdkmod.fetch(args.pdk)
        print(json.dumps({k: r[k] for k in ("ok", "problems")}, indent=2))
        return 0 if r["ok"] else 2
    if args.cmd == "versions":
        print(json.dumps(versions(), indent=2))
        return 0
    if args.cmd == "rereport":
        import json as _json
        from . import flow as _flow
        from .util import ROOT as _ROOT
        saved = _json.load(open(_ROOT / "build" / args.run_id / "resolved.json"))
        cfg = cfgmod.load_design(saved["design"].replace("albion_", "") if saved["design"].startswith("albion_") else saved["design"],
                                 saved.get("overrides", {}), saved["variant"])
        ok = True
        r = {}
        for stg in [s for s in args.stages.split(",") if s]:
            r = _flow.run_stage(cfg, stg, force=True)
            ok &= bool(r.get("ok"))
        print(_json.dumps({"run": args.run_id, "ok": ok, "last_stage": args.stages.split(",")[-1], "violations": r.get("violations")}))
        return 0 if ok else 1
    if args.cmd == "docgen":
        from . import docgen
        return docgen.main()
    if args.cmd == "audit":
        from . import audit
        return audit.main()
    if args.cmd == "sweep":
        from . import sweep
        return sweep.main(args.sweep, args.jobs, args.only, args.to, args.force, args.analyse_only)
    if args.cmd == "clean":
        import shutil
        from .util import ROOT
        t = ROOT / "build" / (f"{cfgmod.DESIGNS.get(args.design, args.design)}__{args.variant}" if args.design else "")
        if args.design:
            cfg = cfgmod.load_design(args.design, {}, args.variant)
            shutil.rmtree(cfg["paths"]["build"], ignore_errors=True)
        return 0
    from . import flow
    cfg = _load(args)
    if args.cmd == "flow":
        return flow.run_flow(cfg, args.to, skip=tuple(s for s in args.skip.split(",") if s))
    if args.cmd == "gates":
        from . import gates
        return gates.cli(cfg, args.tier)
    r = flow.run_stage(cfg, args.cmd, force=getattr(args, "force", False))
    print(json.dumps(r, indent=2, default=str)[:6000])
    return 0 if r.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main())
