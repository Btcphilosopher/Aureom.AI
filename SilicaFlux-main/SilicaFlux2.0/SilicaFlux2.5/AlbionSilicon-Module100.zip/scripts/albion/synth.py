"""Stages: lint, synth.

synth = RTL elaboration -> coarse/fine synthesis -> (optional) adder-cell extraction -> sequential mapping
        (dfflibmap) -> technology mapping (abc) -> tie cells -> netlist, with:
  * latch detection after `proc` (RTL level) and by cell-name scan of the mapped netlist,
  * area from `stat -liberty` (standard cells only; macro area is added from the LEF by the planner),
  * port list extraction (write_json) used by SDC generation and I/O planning.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from . import lef as lefmod
from . import pdk as pdkmod
from .config import run_dir, source_files
from .util import ROOT, read_json, run, write_json

MACRO_VERILOG_CACHE = "sky130_sram_macros"


def _pdk(cfg):
    return pdkmod.load_profile(cfg["pdk"])


def macro_cells(cfg, prof) -> list[dict]:
    """Macro catalogue entries named in source.macro_models (each must exist in the PDK profile)."""
    out = []
    for name in cfg["source"].get("macro_models", []):
        m = prof["macros"].get(name)
        if not m:
            raise KeyError(f"macro {name} not in PDK profile {prof['profile']}")
        d = dict(m)
        d["name"] = name
        d["lef_path"] = str(Path(m["dir"]) / m["lef"])
        d["gds_path"] = str(Path(m["dir"]) / m["gds"])
        d["verilog_path"] = str(Path(m["dir"]) / m["verilog"])
        d["lib_paths"] = {c: str(Path(m["dir"]) / f) for c, f in m["lib"].items()}
        out.append(d)
    return out


def filtered_lib(cfg, prof, corner="tt") -> str:
    """Corner Liberty with dont_use cells removed (cached under build/_shared)."""
    src = prof["corners"][corner]["lib"]
    dst = ROOT / "build" / "_shared" / f"{prof['profile']}_{corner}_dontuse.lib"
    stamp = dst.with_suffix(".json")
    pats = prof["cells"]["dont_use_patterns"]
    meta = read_json(stamp)
    if not dst.exists() or not meta or meta.get("src") != src or meta.get("patterns") != pats:
        info = pdkmod.filter_liberty(src, str(dst), pats)
        write_json(stamp, {"src": src, "patterns": pats, **{k: info[k] for k in ("removed", "kept")}})
    return str(dst)


def yosys_params(cfg) -> str:
    return " ".join(f"-chparam {k} {v}" for k, v in cfg["source"]["params"].items())


def stage_lint(cfg) -> dict:
    d = run_dir(cfg, "lint")
    files = source_files(cfg)
    top = cfg["source"]["top"]
    incs = [f"-I{ROOT / p}" for p in cfg["source"].get("incdirs", [])]
    bitp = set(cfg["source"].get("bit_params", []))
    gp = [f"-G{k}={'1' + chr(39) + 'b' + str(int(v)) if k in bitp else v}" for k, v in cfg["source"]["params"].items()]
    defines = [f"-D{x}" for x in cfg["source"].get("defines", [])]
    prof = _pdk(cfg)
    # --- verilator -Wall.  Warnings are only counted for files under vendor/<id>/rtl (the upstream's own policy
    #     for third-party library code), never silently dropped: third-party counts are reported.
    # Verilator lints the SIMULATION view (no -DSYNTHESIS), like the upstream lint: assertion/checker blocks stay in so
    # signals they use are not reported unused.  The SYNTHESIS view is elaborated and checked by Yosys below.
    cmd = ["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "--top-module", top] + incs + gp + files
    # the macro vendor model is not lint-clean Verilog (delays etc.): lint with a pin-only blackbox instead
    stubs = []
    lint_stubs = [str(ROOT / s) for s in cfg["source"].get("lint_stubs", [])]
    for m in ([] if lint_stubs else macro_cells(cfg, prof)):
        stub = d / f"{m['name']}_bb.v"
        stub.write_text(lefmod.blackbox_from_lef(lefmod.parse_lef_macro(m["lef_path"])))
        stubs.append(str(stub))
    r1 = run(cmd + stubs + lint_stubs, d / "verilator.log", fatal=[])
    own, third, waived = [], 0, []
    waivers = cfg["source"].get("verilator_waivers", [])
    for w in waivers:
        if not w.get("justification") or len(str(w["justification"]).strip()) < 20:
            raise ValueError(f"verilator waiver {w.get('match')} lacks a justification")
    for ln in Path(d / "verilator.log").read_text().splitlines():
        if ln.startswith("%Warning") or ln.startswith("%Error"):
            if "/third_party/" in ln or "_bb.v" in ln or "sram_macro_blackboxes" in ln:
                third += 1
            elif ln.startswith("%Error: Exiting due to") and waivers:
                continue          # summary line; real errors are reported individually
            else:
                hit = next((w for w in waivers if re.search(w["match"], ln)), None)
                if hit:
                    waived.append({"warning": ln[:220], "justification": hit["justification"]})
                else:
                    own.append(ln)
    # --- yosys elaboration check (hierarchy -check) with proc + check -assert
    ys = d / "lint.ys"
    lines = []
    for m in macro_cells(cfg, prof):
        lines.append(f"read_verilog -lib -sv {m['verilog_path']}")
    lines.append("read_verilog -defer -sv " + " ".join(defines) + " " + " ".join(incs) + " " + " ".join(files))
    lines.append(f"hierarchy -check -top {top} {yosys_params(cfg)}")
    lines += ["proc", "check -assert"]
    ys.write_text("\n".join(lines) + "\n")
    r2 = run(["yosys", "-l", str(d / "yosys_elab.log"), str(ys)], d / "yosys_elab.out", fatal=[r"^ERROR"])
    # with waivers, Verilator still exits non-zero for the waived warnings: success = no un-waived warning or error
    ok = (r1["rc"] == 0 or (waived and not own)) and not own and r2["ok"]
    res = {"stage": "lint", "ok": ok, "verilator_rc": r1["rc"], "own_warnings": own[:20], "n_own_warnings": len(own), "waived_warnings": waived,
           "third_party_warnings": third, "yosys_elab_ok": r2["ok"], "yosys_fatal": r2["fatal_hits"]}
    write_json(d / "lint.json", res)
    return res


def stage_synth(cfg) -> dict:
    prof = _pdk(cfg)
    d = run_dir(cfg, "synth")
    top = cfg["source"]["top"]
    files = source_files(cfg)
    incs = [f"-I{ROOT / p}" for p in cfg["source"].get("incdirs", [])]
    defines = [f"-D{x}" for x in cfg["source"].get("defines", [])]
    lib = filtered_lib(cfg, prof, cfg.get("synth_corner", "tt"))
    period_ps = int(round(cfg["clock"]["period_ns"] * 1000))
    cells = prof["cells"]
    hi, lo, mb = cells["tie_hi"], cells["tie_lo"], cells["min_buf"]
    macs = macro_cells(cfg, prof)
    orfs = Path(prof["_ctx"]["CACHE"]) / "orfs_sky130hd"

    constr = d / "abc.constr"
    constr.write_text(f"set_driving_cell {cells['abc_driver']}\nset_load {cells['abc_load_ff'] / 1000.0}\n")

    L = []
    L.append(f"read_liberty -overwrite -setattr liberty_cell -lib {lib}")
    for m in macs:
        L.append(f"read_verilog -lib -sv {m['verilog_path']}")
    L.append("read_verilog -defer -sv " + " ".join(defines) + " " + " ".join(incs) + " " + " ".join(files))
    L.append(f"hierarchy -check -top {top} {yosys_params(cfg)}")
    L.append("proc")
    L.append(f"tee -o {d}/latch_rtl.txt select -count t:$dlatch t:$adlatch t:$dlatchsr")
    if cfg["synth"]["flatten"]:
        L.append(f"synth -top {top} -flatten -run :fine")
    else:
        L.append(f"synth -top {top} -run :fine")
    L.append("opt -purge")
    if cfg["synth"].get("use_adder_cells", True) and (orfs / "cells_adders_hd.v").exists():
        L.append("extract_fa -fa")
        L.append(f"techmap -map {orfs / 'cells_adders_hd.v'}")
        L.append("techmap")
        L.append("opt -fast -purge")
    L.append(f"synth -top {top} -run fine:")
    L += cfg["synth"].get("extra_yosys", [])
    L.append("opt -purge")
    L.append("techmap")
    L.append("opt -fast")
    L.append(f"dfflibmap -liberty {lib}")
    L.append("opt")
    if cfg["synth"]["abc_effort"] == "speed":
        L.append(f"abc -liberty {lib} -constr {constr} -D {period_ps}")
    else:
        L.append(f"abc -liberty {lib} -constr {constr}")
    L.append("opt_clean -purge")
    L.append(f"hilomap -singleton -hicell {hi['cell']} {hi['port']} -locell {lo['cell']} {lo['port']}")
    L.append("opt_clean -purge")
    L.append("splitnets")
    L.append("opt_clean -purge")
    L.append(f"insbuf -buf {mb['cell']} {mb['in']} {mb['out']}")
    L.append("check")
    L.append(f"tee -o {d}/stat.txt stat -liberty {lib}")
    L.append(f"tee -o {d}/stat.json stat -json -liberty {lib}")
    L.append(f"write_verilog -noattr -noexpr -nohex -nodec {d}/netlist.v")
    L.append(f"write_json {d}/netlist.json")
    ys = d / "synth.ys"
    ys.write_text("\n".join(L) + "\n")
    r = run(["yosys", "-l", str(d / "synth.log"), str(ys)], d / "synth.out", fatal=[r"^ERROR"])
    res = {"stage": "synth", "ok": r["ok"], "seconds": r["seconds"], "fatal": r["fatal_hits"]}
    if not r["ok"]:
        write_json(d / "synth.json", res)
        return res

    # ---------------- parse results
    text = (d / "stat.txt").read_text() if (d / "stat.txt").exists() else ""
    area = None
    m = re.search(r"Chip area for (?:top )?module '.*?':\s*([\d.]+)", text)
    if m:
        area = float(m.group(1))
    ncell = re.search(r"Number of cells:\s+(\d+)", text)
    cellcount: dict[str, int] = {}
    for mm in re.finditer(r"^\s+(sky130_\w+|\$_\w+)\s+(\d+)", text, flags=re.M):
        cellcount[mm.group(1)] = cellcount.get(mm.group(1), 0) + int(mm.group(2))
    macro_names = {m_["name"] for m_ in macs}
    n_macro = sum(v for k, v in cellcount.items() if k in macro_names)
    std = {k: v for k, v in cellcount.items() if k not in macro_names}
    seq_re = re.compile(cells["dff_cells_regex"])
    flops = sum(v for k, v in std.items() if seq_re.fullmatch(k) or seq_re.match(k))
    latch_res = [re.compile(p) for p in cells["latch_cells"]]
    latches_mapped = sum(v for k, v in std.items() if any(p.fullmatch(k) for p in latch_res))
    latch_rtl = 0
    lt = d / "latch_rtl.txt"
    if lt.exists():
        mm = re.search(r"(\d+)\s+objects", lt.read_text())
        latch_rtl = int(mm.group(1)) if mm else 0
    unmapped = {k: v for k, v in cellcount.items() if k.startswith("$")}
    # macro instance names (flattened) for the planner
    nj = read_json(d / "netlist.json", {})
    top_mod = nj.get("modules", {}).get(top, {})
    macro_insts = [{"name": n, "cell": c["type"]} for n, c in top_mod.get("cells", {}).items() if c["type"] in macro_names]
    if macro_insts:
        # order = order of appearance in netlist.v, which is the order OpenROAD's database will hold them
        nl_text = (d / "netlist.v").read_text()
        pos = {}
        for mm in re.finditer(r"^\s*(%s)\s+(\S+)\s*\(" % "|".join(re.escape(x) for x in macro_names), nl_text, flags=re.M):
            pos[mm.group(2).lstrip("\\")] = mm.start()
        macro_insts.sort(key=lambda i: pos.get(i["name"], 1 << 60))
    ports = []
    for pn, p in top_mod.get("ports", {}).items():
        ports.append({"name": pn, "dir": p["direction"], "width": len(p["bits"])})
    synth_ok = (area is not None and not unmapped and
                (cfg["synth"]["allow_latches"] or (latch_rtl == 0 and latches_mapped == 0)))
    res.update({
        "ok": synth_ok,
        "std_cell_area_um2": area, "n_cells_total": int(ncell.group(1)) if ncell else None,
        "n_std_cells": sum(std.values()), "n_flops": flops, "n_macros": n_macro,
        "cell_histogram": dict(sorted(std.items(), key=lambda kv: -kv[1])[:25]),
        "latches_rtl": latch_rtl, "latches_mapped": latches_mapped, "unmapped_internal_cells": unmapped,
        "macro_instances": macro_insts, "ports": ports,
        "n_port_bits": sum(p["width"] for p in ports),
        "lib": lib, "abc_effort": cfg["synth"]["abc_effort"], "abc_period_ps": period_ps,
    })
    if latch_rtl or latches_mapped:
        res["latch_note"] = "latches detected: gate fails unless synth.allow_latches=true"
    write_json(d / "synth.json", res)
    return res
