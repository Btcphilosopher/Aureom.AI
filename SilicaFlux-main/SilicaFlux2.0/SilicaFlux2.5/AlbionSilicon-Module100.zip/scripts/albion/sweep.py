"""Controlled parameter sweeps.

A sweep file defines a baseline (the design YAML) and named points, each a set of dotted-key overrides.  Every point runs
the SAME gated flow (lint, source verification, synthesis, gate-level simulation, floorplan ... detailed route, post-route STA,
IR/antenna, report) - a variant can never bypass a verification gate.  Physical-verification decks (DRC/LVS) are skipped for
sweep points by default because the macro-design DRC takes ~10 min per point; they are run on the baselines (see docs).

Ranking (documented, lower is better; infeasible/failed points are listed but unranked):
  score = 10*[any gate failure at tt] + 0.30*norm(area) + 0.25*norm(period_at_tt) + 0.20*norm(power) + 0.15*norm(GRT usage)
          + 0.10*norm(flow complexity)      with norm() = min-max over completed points
The weights are a stated policy for this programme, not a physical law: the per-metric table is the primary result.
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import subprocess
import sys
import time
from pathlib import Path

import yaml

from . import config as cfgmod
from .util import ROOT, read_json, write_json


def _run_point(design: str, name: str, sets: dict, to: str, skip: str, force: bool, log_dir: Path) -> dict:
    t0 = time.time()
    variant = name
    cfg = cfgmod.load_design(design, sets, variant)
    summ = ROOT / "reports" / cfg["run_id"] / "summary.json"
    if summ.exists() and not force:
        return {"name": name, "status": "cached", "run_id": cfg["run_id"], "seconds": 0}
    args = [sys.executable, "-m", "albion", "flow", "--design", design, "--variant", variant, "--to", to, "--skip", skip]
    for k, v in sets.items():
        args += ["--set", f"{k}={json.dumps(v) if isinstance(v, (list, dict)) else v}"]
    log = log_dir / f"{cfg['run_id']}.log"
    with open(log, "w") as lf:
        p = subprocess.run(args, cwd=ROOT / "scripts", stdout=lf, stderr=subprocess.STDOUT)
    return {"name": name, "status": "ok" if p.returncode == 0 else "flow_failed", "rc": p.returncode, "run_id": cfg["run_id"],
            "seconds": round(time.time() - t0, 1), "log": str(log)}


def main(sweep_file: str, jobs: int = 2, only: str | None = None, to: str = "report", force: bool = False, analyse_only: bool = False) -> int:
    sw = yaml.safe_load(open(ROOT / sweep_file if not Path(sweep_file).is_absolute() else sweep_file))
    design = sw["design"]
    points = sw["points"]
    if only:
        keep = set(only.split(","))
        points = [p for p in points if p["name"] in keep]
    log_dir = ROOT / "build" / "sweeps" / sw["name"]
    log_dir.mkdir(parents=True, exist_ok=True)
    skip = sw.get("skip", "drc,lvs")
    results = []
    if analyse_only:
        for p in points:
            cfg = cfgmod.load_design(design, p.get("set", {}), p["name"])
            ok = (ROOT / "reports" / cfg["run_id"] / "summary.json").exists()
            results.append({"name": p["name"], "status": "cached" if ok else "missing", "run_id": cfg["run_id"], "seconds": 0})
        analyse(sw, results)
        return 0
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = {ex.submit(_run_point, design, p["name"], p.get("set", {}), to, skip, force, log_dir): p for p in points}
        for f in cf.as_completed(futs):
            r = f.result()
            results.append(r)
            print(f"[sweep {sw['name']}] {r['name']:24s} {r['status']:12s} {r['seconds']}s", flush=True)
    analyse(sw, results)
    return 0 if all(r["status"] in ("ok", "cached") for r in results) else 1


def _metric_row(sw: dict, point: dict, r: dict) -> dict:
    run_id = r["run_id"]
    s = read_json(ROOT / "reports" / run_id / "summary.json")
    row = {"point": point["name"], "dimension": point.get("dimension"), "run_id": run_id, "flow_status": r["status"],
           "overrides": point.get("set", {})}
    if not s:
        row["status"] = "no_summary"
        return row
    tt = s["timing_by_corner"].get("tt", {})
    pw = (tt.get("power_w") or {})
    area = s["area_um2"]
    g = s["routing"]["global"] or {}
    d = s["routing"]["detailed"] or {}
    st = s["stages"]
    ran_all = all(st.get(k) == "passed" for k in ("verify_rtl", "synth", "gls", "floorplan", "place", "cts", "groute", "droute", "signoff_sta"))
    row.update({
        "status": "complete" if ran_all else "incomplete",
        "stages_failed": [k for k, v in st.items() if v == "failed"],
        "std_cell_area_um2": s["synthesis"].get("std_cell_area_um2"), "n_std_cells": s["synthesis"].get("n_std_cells"), "n_flops": s["synthesis"].get("n_flops"),
        "die_area_um2": area.get("die"), "core_area_um2": area.get("core"), "macro_area_um2": area.get("macro"),
        "std_logic_core_util_pct": area.get("std_logic_core_utilization_pct"),
        "clock_target_ns": s["constraints"]["clock_period_ns"],
        "setup_ws_tt_ns": tt.get("setup_worst_slack_ns"), "hold_ws_tt_ns": tt.get("hold_worst_slack_ns"),
        "min_period_tt_ns": tt.get("min_period_ns_derived"), "fmax_tt_mhz": tt.get("fmax_mhz_derived"),
        "setup_viol_tt": tt.get("setup_violating_endpoints"), "hold_viol_tt": tt.get("hold_violating_endpoints"),
        "corners": {c: {"setup_ws": v["setup_worst_slack_ns"], "hold_ws": v["hold_worst_slack_ns"],
                        "setup_viol": v["setup_violating_endpoints"], "hold_viol": v["hold_violating_endpoints"]} for c, v in s["timing_by_corner"].items()},
        "power_tt_mw": round(pw["total_w"] * 1e3, 4) if pw.get("total_w") is not None else None,
        "grt_usage_pct": g.get("usage_pct"), "grt_overflow": g.get("total_overflow"), "grt_wl_um": g.get("wirelength_um"),
        "drt_wl_um": d.get("wirelength_um"), "drt_vias": d.get("vias"), "drt_violations": d.get("final_violations"),
        "drt_status": d.get("status"),
        "drt_elapsed": d.get("router_elapsed"),
        "hold_buffers": (s["instance_counts"] or {}).get("hold"), "clock_cells": (s["instance_counts"] or {}).get("clk"),
        "io_buffers": (s["instance_counts"] or {}).get("buf_io"), "tap_cells": (s["instance_counts"] or {}).get("tap"),
        "diodes": (s["instance_counts"] or {}).get("diode"),
        "n_io_pins": s["synthesis"].get("n_port_bits"),
        "antenna_viol": ((s["physical_verification"].get("antenna") or {}).get("net_violations")),
        "ir_drop_pct_corners": None,
        "flow_seconds": r.get("seconds"),
    })
    ir = read_json(ROOT / "build" / run_id / "irdrop" / "result.json")
    if ir and ir.get("ir_cases"):
        row["ir_drop_pct_ideal"] = ir["ir_cases"]["ideal"]["worst_total_drop_pct_of_supply"]
        row["ir_drop_pct_4src"] = ir["ir_cases"]["corners"]["worst_total_drop_pct_of_supply"]
        em = ir.get("em_screen") or {}
        row["em_peak_over_via_ref"] = em.get("peak_over_limit")
        row["em_peak_over_strap_ref"] = em.get("peak_over_strap_limit")
    # complexity proxy: flow wall-clock of the P&R stages (seconds) + number of repair cells inserted
    st_times = read_json(ROOT / "build" / run_id / "state.json", {})
    pnr = sum(st_times.get(k, {}).get("seconds", 0) for k in ("floorplan", "place", "cts", "groute", "droute"))
    row["pnr_seconds"] = round(pnr, 1)
    row["repair_cells"] = (row["hold_buffers"] or 0) + (row["diodes"] or 0)
    return row


def _norm(vals):
    v = [x for x in vals if x is not None]
    lo, hi = (min(v), max(v)) if v else (0, 0)
    return lambda x: 0.0 if x is None or hi == lo else (x - lo) / (hi - lo)


def analyse(sw: dict, results: list[dict]) -> dict:
    by_name = {r["name"]: r for r in results}
    rows = [_metric_row(sw, p, by_name[p["name"]]) for p in sw["points"] if p["name"] in by_name]
    done = [r for r in rows if r.get("status") == "complete"]
    nA, nP, nW, nR, nC = (_norm([r["die_area_um2"] for r in done]), _norm([r["min_period_tt_ns"] for r in done]),
                          _norm([r["power_tt_mw"] for r in done]), _norm([r["grt_usage_pct"] for r in done]), _norm([r["pnr_seconds"] for r in done]))
    for r in done:
        gate_fail = (r["setup_viol_tt"] or 0) > 0 or (r["hold_viol_tt"] or 0) > 0 or (r["grt_overflow"] or 0) > 0 or (r["drt_violations"] or 0) > 0
        r["tt_gate_failure"] = bool(gate_fail)
        r["score"] = round(10 * gate_fail + 0.30 * nA(r["die_area_um2"]) + 0.25 * nP(r["min_period_tt_ns"]) + 0.20 * nW(r["power_tt_mw"])
                           + 0.15 * nR(r["grt_usage_pct"]) + 0.10 * nC(r["pnr_seconds"]), 4)
    ranked = sorted(done, key=lambda r: r["score"])
    for i, r in enumerate(ranked, 1):
        r["rank"] = i
    out = {"sweep": sw["name"], "design": sw["design"], "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "weights": {"area": 0.30, "period_tt": 0.25, "power": 0.20, "grt_usage": 0.15, "complexity": 0.10, "gate_failure_penalty": 10},
           "n_points": len(rows), "n_complete": len(done), "points": rows}
    d = ROOT / "reports" / "sweeps"
    write_json(d / f"{sw['name']}.json", out)
    (d / f"{sw['name']}.md").write_text(to_markdown(out))
    try:
        plot(out, d / f"{sw['name']}.svg")
    except Exception as ex:  # noqa: BLE001
        print("plot skipped:", ex)
    return out


def to_markdown(o: dict) -> str:
    L = [f"# Sweep `{o['sweep']}` ({o['design']})", "", f"*generated {o['generated_utc']}; {o['n_complete']}/{o['n_points']} points complete. "
         "All numbers are tool output from the runs in `reports/<run>/summary.json`. Open sky130 PDK; EXPERIMENTAL.*", "",
         "Score weights (policy, lower is better): " + json.dumps(o["weights"]), "",
         "| rank | point | dimension | die µm² | std µm² | macro µm² | target ns | min period tt ns | setup WS tt | hold WS tt | ss setup WS | power tt mW | GRT use % | GRT ovf | DRT viol | wire µm | hold bufs | P&R s | score |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    rows = sorted(o["points"], key=lambda r: (r.get("rank") or 999, r["point"]))
    for r in rows:
        if r.get("status") != "complete":
            L.append(f"| – | `{r['point']}` | {r.get('dimension')} | **{r.get('status')}** | failed stages: {r.get('stages_failed')} | | | | | | | | | | | | | | |")
            continue
        ss = (r["corners"].get("ss") or {}).get("setup_ws", "n/a")
        L.append(f"| {r['rank']} | `{r['point']}` | {r['dimension']} | {r['die_area_um2']} | {r['std_cell_area_um2']} | {r['macro_area_um2']} | {r['clock_target_ns']} | "
                 f"{r['min_period_tt_ns']} | {r['setup_ws_tt_ns']} | {r['hold_ws_tt_ns']} | {ss} | {r['power_tt_mw']} | {r['grt_usage_pct']} | {r['grt_overflow']} | "
                 f"{r['drt_violations']} | {r['drt_wl_um']} | {r['hold_buffers']} | {r['pnr_seconds']} | {r['score']} |")
    return "\n".join(L) + "\n"


def _scatter_svg(points, x0, y0, w, h, xlabel, ylabel, title) -> list[str]:
    """One scatter panel as SVG fragments. points: [(x, y, label, radius)]."""
    xs, ys = [p[0] for p in points], [p[1] for p in points]
    lo_x, hi_x, lo_y, hi_y = min(xs), max(xs), min(ys), max(ys)
    px = (hi_x - lo_x) * 0.12 or 1.0
    py = (hi_y - lo_y) * 0.12 or 1.0
    lo_x, hi_x, lo_y, hi_y = lo_x - px, hi_x + px, lo_y - py, hi_y + py
    sx = lambda v: x0 + 50 + (v - lo_x) / (hi_x - lo_x) * (w - 70)  # noqa: E731
    sy = lambda v: y0 + h - 40 - (v - lo_y) / (hi_y - lo_y) * (h - 70)  # noqa: E731
    out = [f'<rect x="{x0}" y="{y0}" width="{w}" height="{h}" fill="none" stroke="#999"/>',
           f'<text x="{x0 + w / 2}" y="{y0 + 16}" text-anchor="middle" font-size="12" font-weight="bold">{title}</text>',
           f'<text x="{x0 + w / 2}" y="{y0 + h - 8}" text-anchor="middle" font-size="11">{xlabel}</text>',
           f'<text x="{x0 + 12}" y="{y0 + h / 2}" font-size="11" transform="rotate(-90 {x0 + 12} {y0 + h / 2})" text-anchor="middle">{ylabel}</text>']
    for i in range(5):
        vx, vy = lo_x + (hi_x - lo_x) * i / 4, lo_y + (hi_y - lo_y) * i / 4
        out.append(f'<line x1="{sx(vx)}" y1="{y0 + h - 40}" x2="{sx(vx)}" y2="{y0 + h - 36}" stroke="#555"/>'
                   f'<text x="{sx(vx)}" y="{y0 + h - 26}" text-anchor="middle" font-size="9">{vx:.4g}</text>')
        out.append(f'<line x1="{x0 + 46}" y1="{sy(vy)}" x2="{x0 + 50}" y2="{sy(vy)}" stroke="#555"/>'
                   f'<text x="{x0 + 44}" y="{sy(vy) + 3}" text-anchor="end" font-size="9">{vy:.4g}</text>')
    for x, y, lab, r in points:
        out.append(f'<circle cx="{sx(x):.1f}" cy="{sy(y):.1f}" r="{r:.1f}" fill="#2a6fb0" fill-opacity="0.65" stroke="#123"/>')
        out.append(f'<text x="{sx(x) + r + 2:.1f}" y="{sy(y) - 2:.1f}" font-size="9">{lab}</text>')
    return out


def plot(o: dict, path: Path) -> None:
    """Dependency-free SVG (no matplotlib): area vs performance (marker size ~ power) and routability vs power."""
    pts = [r for r in o["points"] if r.get("status") == "complete"]
    if not pts:
        return
    pw = [r["power_tt_mw"] or 0 for r in pts]
    pmax = max(pw) or 1.0
    a = [(r["die_area_um2"], r["min_period_tt_ns"], r["point"], 3 + 8 * (r["power_tt_mw"] or 0) / pmax) for r in pts]
    b = [(r["grt_usage_pct"], r["power_tt_mw"], r["point"], 5) for r in pts]
    W, H = 1100, 440
    body = _scatter_svg(a, 10, 30, 530, 390, "die area (um^2)", "min period at tt, derived (ns)", "area vs performance (marker size ~ power)")
    body += _scatter_svg(b, 560, 30, 530, 390, "global-route usage (%)", "vectorless power at tt (mW)", "routability vs power")
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="sans-serif">'
           f'<rect width="{W}" height="{H}" fill="white"/><text x="{W / 2}" y="18" text-anchor="middle" font-size="12">'
           f'{o["sweep"]} (open sky130, EXPERIMENTAL; all values tool-measured)</text>' + "".join(body) + "</svg>")
    Path(path).write_text(svg)
