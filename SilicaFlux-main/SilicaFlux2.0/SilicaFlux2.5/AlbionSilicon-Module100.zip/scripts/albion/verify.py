"""Post-route analysis and physical-verification stages.

Everything in this module is EXPERIMENTAL (open-source engines, community decks).  Each stage records which engine ran,
the deck/rule file used, its version and whether the engine is an accepted signoff tool (never, for this PDK class).
"""
from __future__ import annotations

import re
import shutil
from pathlib import Path

from . import synth
from .config import run_dir
from .flow import run_openroad
from .parse import _grep, _timing
from .util import ROOT, read_json, run, tool, write_json

MAGIC_RC = None


def _corner_list(cfg, prof) -> list[str]:
    want = cfg["extract"]["corners"]
    macs = synth.macro_cells(cfg, prof)
    out = []
    for c in want:
        if all(c in m["lib_paths"] for m in macs):
            out.append(c)
    return out


def _power(text: str) -> dict:
    m = re.search(r"^Total\s+([-\d.e+]+)\s+([-\d.e+]+)\s+([-\d.e+]+)\s+([-\d.e+]+)", text, flags=re.M)
    if not m:
        return {}
    i, s, l, t = (float(x) for x in m.groups())
    grp = {}
    for g in ("Sequential", "Combinational", "Clock", "Macro", "Pad"):
        mm = re.search(rf"^{g}\s+([-\d.e+]+)\s+([-\d.e+]+)\s+([-\d.e+]+)\s+([-\d.e+]+)", text, flags=re.M)
        if mm:
            grp[g.lower() + "_w"] = float(mm.group(4))
    return {"internal_w": i, "switching_w": s, "leakage_w": l, "total_w": t, **grp}


def _skew(text: str) -> dict:
    m = re.search(r"(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s*$", text.strip().splitlines()[-1]) if text.strip() else None
    lat = re.findall(r"^\s+(-?\d+\.\d+)\s*$", text, flags=re.M)
    out = {}
    if lat:
        out["min_latency_ns"], out["max_latency_ns"] = min(float(x) for x in lat), max(float(x) for x in lat)
    if m:
        out["skew_ns"] = float(m.group(3))
    return out


def stage_signoff_sta(cfg, prof):
    corners = _corner_list(cfg, prof)
    if not corners:
        return {"ok": False, "error": "no corner has liberty views for every macro"}
    res = {"ok": True, "corners": {}, "skipped_corners": [c for c in cfg["extract"]["corners"] if c not in corners],
           "engine": "OpenRCX (PDK rules) + OpenSTA (inside OpenROAD)", "signoff_accepted": False}
    for c in corners:
        r = run_openroad(cfg, prof, "signoff_sta.tcl", f"signoff_sta_{c}", extra_env={"ALBION_CORNER": c})
        d = run_dir(cfg, f"signoff_sta_{c}")
        rd = lambda n: (d / f"{n}.rpt").read_text() if (d / f"{n}.rpt").exists() else ""  # noqa: E731
        t = _timing(d, c)
        cs = rd(f"check_setup_{c}")
        n_unc = sum(int(x) for x in re.findall(r"There (?:are|is) (\d+) unconstrained endpoint", cs))
        res["corners"][c] = {
            "ok": r["ok"], "seconds": r["seconds"], "timing": t,
            "unconstrained_endpoints": n_unc, "check_setup_warnings": [ln for ln in cs.splitlines() if ln.strip()][:10],
            "power": _power(rd(f"power_{c}")), "skew": _skew(rd(f"skew_{c}")),
            "drv_report_lines": [ln for ln in rd(f"drv_{c}").splitlines() if ln.strip()][:12],
            "drv_violations": rd(f"drv_{c}").count("(VIOLATED)"),
            "rcx_rules": r["metrics"].get("rcx_rules"), "spef": str(d / f"signoff_{c}.spef"),
        }
        res["ok"] = res["ok"] and r["ok"]
    # classify unconstrained endpoints (constant-driven vs genuine gap) once, on the default corner's list
    c0 = prof["default_corner"] if prof["default_corner"] in res["corners"] else next(iter(res["corners"]))
    d0 = run_dir(cfg, f"signoff_sta_{c0}")
    cs = (d0 / f"check_setup_{c0}.rpt").read_text() if (d0 / f"check_setup_{c0}.rpt").exists() else ""
    names = []
    grab = False
    for ln in cs.splitlines():
        if re.search(r"unconstrained endpoints", ln):
            grab = True
            continue
        if grab and ln.startswith("  "):
            names.append(ln.strip())
        elif grab and not ln.startswith("  "):
            grab = False
    unc = {"total": len(names), "const": 0, "other": 0, "other_names": [], "names_file": None}
    if names:
        dc = run_dir(cfg, "classify")
        (dc / "unconstrained.txt").write_text("\n".join(names) + "\n")
        rc = run_openroad(cfg, prof, "classify_unconstrained.tcl", "classify", extra_env={"ALB_UNC_FILE": str(dc / "unconstrained.txt")})
        unc["const"] = int(rc["metrics"].get("unconstrained_const", 0))
        unc["other"] = int(rc["metrics"].get("unconstrained_other", 0))
        txt = (dc / "classify.log").read_text(errors="replace")
        unc["other_names"] = [ln[6:] for ln in txt.splitlines() if ln.startswith("other ")][:20]
        unc["classifier_ok"] = rc["ok"]
        res["ok"] = res["ok"] and rc["ok"] and unc["const"] + unc["other"] == unc["total"]
    res["unconstrained"] = unc
    return res


def _ir_case(d: Path, net: str, case: str) -> dict:
    f = d / f"irdrop_{net}_{case}.rpt"
    txt = f.read_text(errors="replace") if f.exists() else ""
    g = lambda pat: (float(re.search(pat, txt).group(1)) if re.search(pat, txt) else None)  # noqa: E731
    return {"sources": int(re.search(r"Number of voltage sources = (\d+)", txt).group(1)) if re.search(r"Number of voltage sources = (\d+)", txt) else None,
            "worst_ir_drop_v": g(r"Worstcase IR drop:\s*([-\d.e+]+)"), "avg_ir_drop_v": g(r"Average IR drop\s*:\s*([-\d.e+]+)")}


def stage_irdrop(cfg, prof):
    r = run_openroad(cfg, prof, "irdrop.tcl", "irdrop")
    d = run_dir(cfg, "irdrop")
    V = float(prof["supply"]["voltage"])
    cases = {}
    for case in ("ideal", "corners"):
        vdd, vss = _ir_case(d, "vdd", case), _ir_case(d, "vss", case)
        tot = (vdd["worst_ir_drop_v"] or 0) + (vss["worst_ir_drop_v"] or 0)
        cases[case] = {"vdd": vdd, "vss": vss, "worst_total_drop_v": round(tot, 6), "worst_total_drop_pct_of_supply": round(100 * tot / V, 4)}
    # the two cases must actually differ in supply assumption; identical source counts mean the option did nothing
    cases["cases_distinct"] = cases["ideal"]["vdd"]["sources"] != cases["corners"]["vdd"]["sources"]
    em = {}
    f = d / "em_vdd_corners.rpt"
    if f.exists():
        txt = f.read_text(errors="replace")
        m = re.search(r"Maximum current:\s*([-\d.e+]+) A", txt)
        a = re.search(r"Average current:\s*([-\d.e+]+) A", txt)
        if m:
            peak = float(m.group(1))
            # most restrictive DC limit in the tech LEF: 0.36 mA per via (Iavg_max @ 90C); conservative because the layer/element of
            # the peak current is not reported by this PSM version
            em = {"engine": "OpenROAD PSM -enable_em (PDN only)", "peak_segment_current_a": peak,
                  "avg_segment_current_a": float(a.group(1)) if a else None,
                  "reference_limit_a": 0.36e-3, "reference_limit_basis": "techLEF DCCURRENTDENSITY AVERAGE 0.36 mA per via (Iavg_max @ 90C); most restrictive entry",
                  "peak_over_limit": round(peak / 0.36e-3, 4), "screen_pass": peak < 0.36e-3,
                  # second, less conservative reference: the widest PDN strap (techLEF DCCURRENTDENSITY AVERAGE 2.8 mA/um)
                  "strap_reference_limit_a": round(float(cfg["floorplan"]["pdn"]["m4_width"]) * 2.8e-3, 6),
                  "peak_over_strap_limit": round(peak / (float(cfg["floorplan"]["pdn"]["m4_width"]) * 2.8e-3), 4),
                  "interpretation": "FLAG, not a verdict: peak element is not identified by this PSM version. If it is a single via the "
                                    "via reference applies; if it is a strap segment the strap reference applies. Needs a signoff EM tool.",
                  "not_covered": "signal/clock-net EM, AC/RMS limits, via arrays, thermal derating, vector-based currents"}
    r["ir_cases"] = cases
    r["em_screen"] = em
    r["limit_pct"] = cfg["power"]["ir_drop_limit_pct"]
    r["ok"] = r["ok"] and cases["ideal"]["vdd"]["worst_ir_drop_v"] is not None and cases["corners"]["vdd"]["worst_ir_drop_v"] is not None
    return r


def stage_antenna(cfg, prof):
    r = run_openroad(cfg, prof, "antenna.tcl", "antenna")
    d = run_dir(cfg, "antenna")
    log = (d / "antenna.log").read_text(errors="replace")
    nets = re.search(r"ANT-0002\] Found (\d+) net violations", log)
    pins = re.search(r"ANT-0001\] Found (\d+) pin violations", log)
    r["net_violations"] = int(nets.group(1)) if nets else None
    r["pin_violations"] = int(pins.group(1)) if pins else None
    r["engine"] = "openroad check_antennas (rules from tech LEF ANTENNA* props); not a foundry antenna deck"
    r["ok"] = r["ok"] and r["net_violations"] is not None
    return r


# ----------------------------------------------------------------------------- Magic / KLayout / Netgen
def _magic_env(cfg, prof, d: Path) -> dict:
    macs = synth.macro_cells(cfg, prof)
    return {
        "PDK_ROOT": str(Path(prof["_ctx"]["PDK"]).parent), "PDK": "sky130A",
        "ALB_TOP": cfg["source"]["top"], "ALB_OUT": str(d),
        "ALB_DEF": str(d / "final_magic.def"),
        "ALB_TECH_LEF": prof["files"]["tech_lef"], "ALB_STD_LEF": prof["files"]["stdcell_lef"],
        "ALB_STD_GDS": prof["files"]["stdcell_gds"],
        "ALB_MACRO_LEFS": "{" + "} {".join(m["lef_path"] for m in macs) + "}" if macs else "",
        "ALB_MACRO_GDS": "{" + "} {".join(m["gds_path"] for m in macs) + "}" if macs else "",
    }


def _run_magic(cfg, prof, script: str, d: Path, log: str, timeout=7200) -> dict:
    mg = tool("magic")
    if not mg:
        return {"ok": False, "rc": 127, "error": "magic not installed"}
    env = _magic_env(cfg, prof, d)
    rc = prof["files"]["magic_rc"]
    # Tcl list parsing of the env vars happens inside the script via `foreach` over a string list
    return run([mg, "-dnull", "-noconsole", "-rcfile", rc, str(ROOT / "scripts" / "magic" / script)], d / log, cwd=d, env=env,
               timeout=timeout, fatal=[r"Segmentation fault", r"ALBION_MAGIC_ERROR", r"Error parsing"])


def ensure_gds(cfg, prof) -> dict:
    d = run_dir(cfg, "verify")
    gds = d / f"{cfg['source']['top']}.gds"
    if gds.exists() and gds.stat().st_size > 1000 and gds.stat().st_mtime > (run_dir(cfg, "droute") / "final.def").stat().st_mtime:
        return {"ok": True, "gds": str(gds), "cached": True, "bytes": gds.stat().st_size}
    gds.unlink(missing_ok=True)
    # Magic's DEF reader segfaults on a PLACEMENT BLOCKAGES section (our macro halo keep-out).  Placement blockages carry
    # no layout geometry, so the Magic-specific DEF copy simply omits them (the original final.def is untouched).
    src = (run_dir(cfg, "droute") / "final.def").read_text()
    (d / "final_magic.def").write_text(re.sub(r"^BLOCKAGES\s+\d+\s*;.*?^END BLOCKAGES\s*\n", "", src, flags=re.S | re.M))
    r = _run_magic(cfg, prof, "magic_gds.tcl", d, "magic_gds.log")
    log = (d / "magic_gds.log").read_text(errors="replace")
    size = gds.stat().st_size if gds.exists() else 0
    macs = synth.macro_cells(cfg, prof)
    # sanity: a real layout is MBs (std-cell polygons + routing); 126 bytes = empty top cell (a bug we hit once)
    min_bytes = 200_000 + sum(Path(m["gds_path"]).stat().st_size for m in macs) // 2
    bad = [w for w in ("couldn't be read", "Cannot open input file", "No such file or directory", "Creating new cell") if w in log]
    ok = r.get("rc") == 0 and size >= min_bytes and not bad and "ALBION_DONE magic_gds" in log
    return {"ok": ok, "gds": str(gds), "bytes": size, "min_bytes_required": min_bytes, "problems": bad, "seconds": r.get("seconds"),
            "engine": "Magic 8.3.x (open_pdks)", "log": str(d / "magic_gds.log")}


def _macro_boxes(cfg) -> list[tuple[float, float, float, float]]:
    p = read_json(run_dir(cfg, "plan") / "plan.json", {})
    return [(m["x"], m["y"], m["x"] + m["w"], m["y"] + m["h"]) for m in p.get("macros", [])]


KLAYOUT_FLAGS = ["-rd", "feol=true", "-rd", "beol=true", "-rd", "offgrid=true", "-rd", "seal=false", "-rd", "floating_met=false"]


def drc_selftest(prof) -> dict:
    """Prove each DRC engine can FAIL: plant a metal1 spacing violation (0.05 um gap; rule minimum 0.14 um) and require detection.

    Learned the hard way: the KLayout deck runs ZERO rule groups unless feol/beol/offgrid are enabled, so an unconfigured
    run reports a clean result for any layout.  A DRC number without this self-test is not evidence.
    """
    d = ROOT / "build" / "_shared" / "drc_selftest"
    d.mkdir(parents=True, exist_ok=True)
    cache = d / "result.json"
    key = (prof["files"]["klayout_drc"], prof["files"]["magic_tech"])
    old = read_json(cache)
    if old and old.get("key") == list(key):
        return old
    (d / "mk.py").write_text(
        "import pya\nly=pya.Layout(); ly.dbu=0.001\ntop=ly.create_cell('viol_top')\nl=ly.layer(68,20)\n"
        "top.shapes(l).insert(pya.Box(0,0,1000,1000))\ntop.shapes(l).insert(pya.Box(1050,0,2050,1000))\nly.write('viol.gds')\n")
    res = {"key": list(key), "magic_detects": False, "klayout_detects": False}
    r = run([tool("klayout"), "-b", "-r", str(d / "mk.py")], d / "mk.log", cwd=d, fatal=[])
    if (d / "viol.gds").exists():
        (d / "m.tcl").write_text("drc off\ncrashbackups stop\ngds readonly true\ngds read viol.gds\nload viol_top\nselect top cell\n"
                                 "drc style drc(full)\ndrc on\ndrc check\ndrc catchup\nset n 0\nforeach {r b} [drc listall why] {foreach x $b {incr n}}\n"
                                 "puts \"SELFTEST_TOTAL $n\"\nquit -noprompt\n")
        rm = run([tool("magic"), "-dnull", "-noconsole", "-rcfile", prof["files"]["magic_rc"], str(d / "m.tcl")], d / "magic.log", cwd=d,
                 env={"PDK_ROOT": str(Path(prof["_ctx"]["PDK"]).parent), "PDK": "sky130A"}, fatal=[])
        m = re.search(r"SELFTEST_TOTAL (\d+)", (d / "magic.log").read_text(errors="replace"))
        res["magic_detects"] = bool(m and int(m.group(1)) > 0)
        rk = run([tool("klayout"), "-b", "-r", prof["files"]["klayout_drc"], "-rd", "input=viol.gds", "-rd", "top_cell=viol_top",
                  "-rd", "report=k.txt", "-rd", "thr=1"] + KLAYOUT_FLAGS, d / "klayout.log", cwd=d, fatal=[])
        kt = (d / "k.txt").read_text(errors="replace") if (d / "k.txt").exists() else ""
        res["klayout_detects"] = len(re.findall(r"<item>", kt)) > 0
        # and the UNCONFIGURED deck must NOT detect it: documents the trap
        rk0 = run([tool("klayout"), "-b", "-r", prof["files"]["klayout_drc"], "-rd", "input=viol.gds", "-rd", "top_cell=viol_top",
                   "-rd", "report=k0.txt", "-rd", "thr=1"], d / "klayout0.log", cwd=d, fatal=[])
        k0 = (d / "k0.txt").read_text(errors="replace") if (d / "k0.txt").exists() else ""
        res["klayout_unconfigured_detects"] = len(re.findall(r"<item>", k0)) > 0
    res["ok"] = res["magic_detects"] and res["klayout_detects"]
    write_json(cache, res)
    return res


def _um_scale(top_box_line: str, die_w_um: float) -> float | None:
    nums = [float(x) for x in re.findall(r"-?\d+(?:\.\d+)?", top_box_line)]
    if len(nums) >= 4 and die_w_um > 0:
        return (nums[2] - nums[0]) / die_w_um
    return None


def stage_drc(cfg, prof):
    d = run_dir(cfg, "verify")
    st = drc_selftest(prof)
    g = ensure_gds(cfg, prof)
    res = {"ok": False, "gds": {k: g.get(k) for k in ("ok", "bytes", "problems")}, "engine": {}, "signoff_accepted": False,
           "instrument_selftest": {k: st.get(k) for k in ("magic_detects", "klayout_detects", "klayout_unconfigured_detects")},
           "note": "community open decks (Magic sky130A tech, KLayout sky130A_mr); NOT the foundry signoff deck"}
    if not g["ok"]:
        res["error"] = "GDS generation failed"
        return res
    if not st.get("ok"):
        res["error"] = "DRC engine self-test failed: an engine could not detect a planted violation; results would be meaningless"
        return res
    plan = read_json(run_dir(cfg, "plan") / "plan.json", {})
    die = plan.get("die") or [0, 0, 0, 0]
    macros = _macro_boxes(cfg)

    def where(x0, y0, x1, y1):
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        return "macro" if any(a <= cx <= c and b <= cy <= e for a, b, c, e in macros) else "top"

    # ---- Magic DRC
    if cfg["verify"]["drc_magic"]:
        lg = d / "magic_drc.log"
        gds_p = Path(g["gds"])
        # reuse a finished Magic DRC of THIS GDS (the macro design takes ~12 min); re-run if the GDS is newer
        fresh = (lg.exists() and (d / "magic_drc.rpt").exists() and lg.stat().st_mtime > gds_p.stat().st_mtime
                 and "ALBION_MAGIC drc_total" in lg.read_text(errors="replace"))
        if fresh:
            r = {"rc": 0, "cached": True}
        else:
            (d / "magic_drc.rpt").unlink(missing_ok=True)
            r = _run_magic(cfg, prof, "magic_drc.tcl", d, "magic_drc.log")
        txt = (d / "magic_drc.log").read_text(errors="replace")
        m = re.search(r"ALBION_MAGIC drc_total (\d+)", txt)
        tb = re.search(r"ALBION_MAGIC top_box (.*)", txt)
        scale = _um_scale(tb.group(1), die[2] - die[0]) if tb else None
        total = int(m.group(1)) if m and "ALBION_MAGIC_ERROR" not in txt else None
        by_rule: dict[str, int] = {}
        split = {"top": 0, "macro": 0}
        rpt = d / "magic_drc.rpt"
        if rpt.exists():
            for ln in rpt.read_text().splitlines():
                rule, _, box = ln.partition(" | ")
                by_rule[rule.strip()] = by_rule.get(rule.strip(), 0) + 1
                n = [float(x) for x in re.findall(r"-?\d+(?:\.\d+)?", box)]
                if scale and len(n) >= 4:
                    split[where(*(v_ / scale for v_ in n[:4]))] += 1
        res["engine"]["magic_drc"] = {"ran": r.get("rc") == 0 and total is not None, "total": total, "outside_macros": split["top"] if total else None,
                                      "inside_macro_bboxes": split["macro"] if total else None, "rules_violated": len(by_rule),
                                      "top_rules": sorted(by_rule.items(), key=lambda kv: -kv[1])[:8], "um_scale": scale, "log": str(d / "magic_drc.log")}
    # ---- KLayout DRC (rule groups explicitly enabled)
    if cfg["verify"]["drc_klayout"] and tool("klayout"):
        deck = prof["files"]["klayout_drc"]
        rpt = d / "klayout_drc.txt"
        rpt.unlink(missing_ok=True)
        r = run([tool("klayout"), "-b", "-r", deck, "-rd", f"input={g['gds']}", "-rd", f"top_cell={cfg['source']['top']}",
                 "-rd", f"report={rpt}", "-rd", "thr=2"] + KLAYOUT_FLAGS, d / "klayout_drc.log", cwd=d, timeout=7200, fatal=[])
        txt = rpt.read_text(errors="replace") if rpt.exists() else ""
        items = re.findall(r"<item>.*?</item>", txt, flags=re.S)
        cats: dict[str, int] = {}
        split = {"top": 0, "macro": 0}
        for it in items:
            cm = re.search(r"<category>\s*'?([^<'\s]+)'?\s*</category>", it)
            cats[cm.group(1) if cm else "?"] = cats.get(cm.group(1) if cm else "?", 0) + 1
            n = [float(x) for x in re.findall(r"-?\d+\.?\d*", re.sub(r"<[^>]+>", " ", it.split("<values>")[-1]))]
            if len(n) >= 2:
                xs, ys = n[0::2], n[1::2]
                split[where(min(xs), min(ys), max(xs), max(ys))] += 1
        res["engine"]["klayout_drc"] = {"ran": r["rc"] == 0 and rpt.exists(), "rc": r["rc"], "total": len(items), "outside_macros": split["top"],
                                        "inside_macro_bboxes": split["macro"], "rules_violated": len(cats),
                                        "top_rules": sorted(cats.items(), key=lambda kv: -kv[1])[:8], "rule_groups_enabled": "feol,beol,offgrid",
                                        "log": str(d / "klayout_drc.log")}
    res["ok"] = bool(res["engine"]) and all(e.get("ran") for e in res["engine"].values())
    return res


_NODEVICE = r"sky130_fd_sc_hd__(?:fill_\d+|tapvpwrvgnd_\d+|decap_\d+|diode_\d+)"


def _strip_nodevice_cells(src: str) -> tuple[str, dict]:
    """Remove instances of cells that contain no devices (fill/tap/decap) from a Verilog netlist for LVS.

    They have nothing for the extractor to find, so they appear only on the schematic side (5 'devices' of exactly these
    classes in the first LVS attempt).  Antenna diodes DO have a device and are kept.
    """
    removed: dict[str, int] = {}

    def repl(m):
        removed[m.group(1)] = removed.get(m.group(1), 0) + 1
        return ""
    out = re.sub(rf"^\s*({_NODEVICE.replace('|diode_\\d+', '')})\s+\S+\s*\((?:[^;]*?)\);\s*\n", repl, src, flags=re.M | re.S)
    return out, removed


def _blackbox_macro_subckts(spice: str, macro_names: list[str]) -> tuple[str, list[str]]:
    """Empty the body of macro sub-circuits (keep header ports): macro-internal LVS is not run (see docs)."""
    done = []
    for n in macro_names:
        m = re.search(rf"^\.subckt {re.escape(n)}\b[^\n]*\n(?:\+[^\n]*\n)*", spice, flags=re.M)
        if not m:
            continue
        e = re.search(r"^\.ends[^\n]*\n", spice[m.end():], flags=re.M)
        if not e:
            continue
        spice = spice[:m.end()] + spice[m.end() + e.start():]
        done.append(n)
    return spice, done


def _macro_blackbox_verilog(macs) -> str:
    """Schematic-side blackbox: LEF signal buses PLUS the LEF power/ground pins.  Omitting the power pins left the instance's
    .vccd1/.vssd1 connections dangling on the schematic side (2 extra nets in the first Design-B LVS attempt)."""
    from . import lef as lefmod
    out = []
    for m in macs:
        lef = lefmod.parse_lef_macro(m["lef_path"])
        bb = lefmod.blackbox_from_lef(lef).replace("(* blackbox *)\n", "")
        pg = lefmod.power_pins(lef)
        extra = ",\n".join(f"  inout wire {n}" for n, _ in pg["power"] + pg["ground"])
        if extra:
            bb = bb.replace("\n);\nendmodule", ",\n" + extra + "\n);\nendmodule")
        out.append(bb)
    return "\n".join(out)


def stage_lvs(cfg, prof):
    d = run_dir(cfg, "verify")
    g = ensure_gds(cfg, prof)
    res = {"ok": False, "gds": {k: g.get(k) for k in ("ok", "bytes")}, "engine": "Magic extraction + Netgen (community sky130A setup)",
           "signoff_accepted": False}
    if not g["ok"]:
        res["error"] = "GDS generation failed"
        return res
    top = cfg["source"]["top"]
    macs = synth.macro_cells(cfg, prof)
    spice = d / f"{top}_layout.spice"
    spice.unlink(missing_ok=True)
    r = _run_magic(cfg, prof, "magic_extract.tcl", d, "magic_extract.log")
    if not spice.exists():
        res["error"] = "extraction produced no SPICE"
        res["log"] = str(d / "magic_extract.log")
        return res
    sp = spice.read_text()
    sp, bb = _blackbox_macro_subckts(sp, [m["name"] for m in macs])
    lay = d / f"{top}_layout_lvs.spice"
    lay.write_text(sp)
    nl, removed = _strip_nodevice_cells((run_dir(cfg, "droute") / "final_pg.v").read_text())
    if macs:
        nl = _macro_blackbox_verilog(macs) + "\n" + nl
    net = d / "final_lvs.v"
    net.write_text(nl)
    (d / "lvs.tcl").write_text(f"lvs {{{lay} {top}}} {{{net} {top}}} {prof['files']['netgen_setup']} {d}/lvs.out -json\n")
    out = d / "lvs.out"
    out.unlink(missing_ok=True)
    rr = run([tool("netgen"), "-batch", "source", str(d / "lvs.tcl")], d / "netgen.log", cwd=d, timeout=3600, fatal=[])
    txt = out.read_text(errors="replace") if out.exists() else ""
    dev = re.search(r"Number of devices:\s*(\d+)[^|]*\|Number of devices:\s*(\d+)", txt)
    nets = re.search(r"Number of nets:\s*(\d+)[^|]*\|Number of nets:\s*(\d+)", txt)
    res.update({
        "equivalent": bool(re.search(r"Circuits match uniquely", txt)) or bool(re.search(r"Final result:\s*\n?\s*Circuits match", txt)),
        "devices_layout_vs_netlist": [int(dev.group(1)), int(dev.group(2))] if dev else None,
        "nets_layout_vs_netlist": [int(nets.group(1)), int(nets.group(2))] if nets else None,
        "pin_lists_equivalent": "Cell pin lists are equivalent" in txt,
        "excluded_from_netlist_no_devices": removed,
        "macros_blackboxed": bb,
        "scope_note": ("top-level LVS; SRAM macro internals treated as black boxes on both sides (macro-internal LVS belongs to the macro "
                       "vendor and was not run)" if macs else "full design LVS"),
        "report_tail": txt.strip().splitlines()[-6:],
    })
    res["ok"] = rr["rc"] == 0 and out.exists() and bool(res["equivalent"])
    return res
