"""Floorplan planner + independent legality checker.

The planner turns (synthesis area, macro LEF sizes, config) into explicit numbers (die, core, macro origins,
halos, blockages, pin regions) written to plan.json and plan.tcl.  OpenROAD then *executes* the plan; the
legality checker (`check_plan`) is deliberately independent of the planner code so that a planner bug cannot
approve its own output, and `verify_odb` (Tcl, see floorplan.tcl) re-checks the result inside OpenROAD.

All geometry is in micrometres.  Grid: site 0.46 x 2.72 (read from the tech LEF, not assumed).
"""
from __future__ import annotations

import math
import re
from pathlib import Path

from . import lef as lefmod
from .config import run_dir
from .util import read_json, write_json

SITE_W_DEFAULT, SITE_H_DEFAULT = 0.46, 2.72


def site_dims(tech_lef: str, site: str) -> tuple[float, float]:
    txt = Path(tech_lef).read_text()
    m = re.search(rf"^SITE\s+{re.escape(site)}\b.*?SIZE\s+([\d.]+)\s+BY\s+([\d.]+)", txt, flags=re.M | re.S)
    if not m:
        return SITE_W_DEFAULT, SITE_H_DEFAULT
    return float(m.group(1)), float(m.group(2))


def snap_up(v: float, g: float) -> float:
    return math.ceil(v / g - 1e-9) * g


def snap_down(v: float, g: float) -> float:
    return math.floor(v / g + 1e-9) * g


def snap_nearest(v: float, g: float) -> float:
    return round(v / g) * g


def anchor_xy(anchor: str, core: tuple, w: float, h: float, hx: float, hy: float) -> tuple[float, float]:
    """Lower-left origin of a w x h macro placed at `anchor` inside `core` (x0,y0,x1,y1) honouring its halo."""
    x0, y0, x1, y1 = core
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    xs = {"w": x0 + hx, "e": x1 - hx - w, "c": cx - w / 2}
    ys = {"s": y0 + hy, "n": y1 - hy - h, "c": cy - h / 2}
    a = anchor.lower()
    table = {
        "center": ("c", "c"), "west": ("w", "c"), "east": ("e", "c"), "north": ("c", "n"), "south": ("c", "s"),
        "sw": ("w", "s"), "se": ("e", "s"), "nw": ("w", "n"), "ne": ("e", "n"),
    }
    if a not in table:
        raise ValueError(f"unknown macro anchor {anchor!r}; valid: {sorted(table)}")
    xk, yk = table[a]
    return xs[xk], ys[yk]


def plan(cfg: dict, prof: dict, synth: dict, macros_meta: list[dict]) -> dict:
    fp = cfg["floorplan"]
    sw, sh = site_dims(prof["files"]["tech_lef"], prof["site"])
    A_std = float(synth["std_cell_area_um2"])
    util = float(fp["utilization"])
    AR = float(fp["aspect_ratio"])
    margin = float(fp["core_margin_um"])
    hx, hy = fp["macro_halo_um"]
    insts = synth.get("macro_instances", [])
    by_cell = {m["name"]: m for m in macros_meta}
    mac = []
    for i in insts:
        lm = lefmod.parse_lef_macro(by_cell[i["cell"]]["lef_path"])
        mac.append({"name": i["name"], "cell": i["cell"], "w": lm["w"], "h": lm["h"], "halo": [hx, hy]})

    foot_area = sum((m["w"] + 2 * hx) * (m["h"] + 2 * hy) for m in mac)
    logic_core = A_std / util
    need = logic_core + foot_area
    # core sizing: aspect ratio target, but never smaller than the macros (with halos) require
    w = math.sqrt(need / AR)
    h = AR * w
    if mac:
        layout = fp.get("macro_layout", {})
        arr = layout.get("arrangement", "row")
        gap = float(layout.get("gap_um", 40.0))
        if arr == "row":
            mw = sum(m["w"] + 2 * hx for m in mac) + gap * (len(mac) - 1)
            mh = max(m["h"] + 2 * hy for m in mac)
        else:   # column
            mw = max(m["w"] + 2 * hx for m in mac)
            mh = sum(m["h"] + 2 * hy for m in mac) + gap * (len(mac) - 1)
        # leave at least ~25% extra on the long dimension for logic channels
        w = max(w, mw * 1.15)
        h = max(h, mh * 1.15)
        # keep the requested std-cell utilisation: grow whichever dimension keeps AR closest
        while (w * h - foot_area) * util < A_std:
            if w / h < 1 / AR:
                w *= 1.03
            else:
                h *= 1.03
    cw, ch = snap_up(w, sw), snap_up(h, sh)
    # grid-aligned core origin
    cx0, cy0 = snap_up(margin, sw), snap_up(margin, sh)
    core = (cx0, cy0, cx0 + cw, cy0 + ch)
    die = (0.0, 0.0, snap_up(core[2] + margin, sw), snap_up(core[3] + margin, sh))

    # macro placement
    blockages = []
    placed = []
    if mac:
        layout = fp.get("macro_layout", {})
        anchor = layout.get("anchor", "center")
        arr = layout.get("arrangement", "row")
        gap = float(layout.get("gap_um", 40.0))
        explicit = {int(e["index"]): e for e in layout.get("explicit", [])}
        # first, place a group box with the requested anchor, then lay macros out inside it
        if arr == "row":
            gw = sum(m["w"] + 2 * hx for m in mac) + gap * (len(mac) - 1)
            gh = max(m["h"] + 2 * hy for m in mac)
        else:
            gw = max(m["w"] + 2 * hx for m in mac)
            gh = sum(m["h"] + 2 * hy for m in mac) + gap * (len(mac) - 1)
        gx, gy = anchor_xy(anchor, core, gw, gh, 0.0, 0.0)
        cursor_x, cursor_y = gx, gy
        for k, m in enumerate(mac):
            if k in explicit:
                ox, oy = float(explicit[k]["x_um"]), float(explicit[k]["y_um"])
            elif arr == "row":
                ox, oy = cursor_x + hx, gy + (gh - (m["h"] + 2 * hy)) / 2 + hy
                cursor_x += m["w"] + 2 * hx + gap
            else:
                ox, oy = gx + (gw - (m["w"] + 2 * hx)) / 2 + hx, cursor_y + hy
                cursor_y += m["h"] + 2 * hy + gap
            # clamp INTO the legal window using grid-snapped bounds (lower bound rounded up, upper bound rounded DOWN): clamping first and
            # snapping up afterwards could push a macro past the core+halo limit by one site (bug found by the independent checker)
            lo_x, hi_x = snap_up(core[0] + hx, sw), snap_down(core[2] - hx - m["w"], sw)
            lo_y, hi_y = snap_up(core[1] + hy, sh), snap_down(core[3] - hy - m["h"], sh)
            ox = min(max(snap_nearest(ox, sw), lo_x), hi_x)
            oy = min(max(snap_nearest(oy, sh), lo_y), hi_y)
            placed.append({**m, "x": round(ox, 3), "y": round(oy, 3), "orient": "R0"})
            bx = float(fp.get("macro_blockage_um", 2.0))
            # hard placement keep-out = macro halo ring (the halo itself) -> one blockage rect per macro
            blockages.append([round(ox - hx, 3), round(oy - hy, 3), round(ox + m["w"] + hx, 3), round(oy + m["h"] + hy, 3)])
    p = {
        "site": [sw, sh], "die": [round(v, 3) for v in die], "core": [round(v, 3) for v in core],
        "macros": placed, "blockages": blockages, "halo": [hx, hy],
        "std_cell_area_um2": A_std, "target_utilization": util, "macro_area_um2": round(sum(m["w"] * m["h"] for m in mac), 1),
        "placeable_core_area_um2": round((core[2] - core[0]) * (core[3] - core[1]) - sum(
            (b[2] - b[0]) * (b[3] - b[1]) for b in blockages), 1),
        "aspect_ratio_target": AR,
        "pin_groups": assign_pins(cfg, synth),
    }
    p["achieved_pre_place_utilization"] = round(A_std / p["placeable_core_area_um2"], 4) if p["placeable_core_area_um2"] > 0 else None
    return p


def expand_bits(ports: list[dict]) -> list[tuple[str, str]]:
    """[(bit_name, direction)] using OpenROAD-style names: bus[3] -> 'bus[3]'."""
    out = []
    for p in ports:
        if p["width"] == 1:
            out.append((p["name"], p["dir"]))
        else:
            for i in range(p["width"]):
                out.append((f"{p['name']}[{i}]", p["dir"]))
    return out


def assign_pins(cfg: dict, synth: dict) -> dict:
    """Assign every port bit to an edge by the first matching group; split multi-edge groups evenly."""
    bits = expand_bits(synth["ports"])
    groups = cfg["floorplan"]["io"]["groups"]
    assigned: dict[str, str] = {}
    per_group: list[list[str]] = [[] for _ in groups]
    for bit, _d in bits:
        base = bit.split("[")[0]
        for gi, g in enumerate(groups):
            if re.match(g["pins"], base) or re.match(g["pins"], bit):
                per_group[gi].append(bit)
                break
    edges: dict[str, list[str]] = {"west": [], "east": [], "north": [], "south": []}
    for gi, g in enumerate(groups):
        es = g["edge"] if isinstance(g["edge"], list) else [g["edge"]]
        pins = per_group[gi]
        n = len(pins)
        for k, pn in enumerate(pins):
            e = es[min(k * len(es) // max(n, 1), len(es) - 1)]
            edges[e].append(pn)
            assigned[pn] = e
    unassigned = [b for b, _ in bits if b not in assigned]
    return {"edges": edges, "unassigned": unassigned, "n_pins": len(bits)}


def check_plan(plan_: dict, cfg: dict) -> dict:
    """Independent legality checks.  Returns {ok, violations[]}."""
    v = []
    sw, sh = plan_["site"]
    d, c = plan_["die"], plan_["core"]
    if not (d[0] <= c[0] and d[1] <= c[1] and c[2] <= d[2] and c[3] <= d[3]):
        v.append("core not inside die")
    for nm, val, g in (("core x0", c[0], sw), ("core y0", c[1], sh), ("core x1", c[2], sw), ("core y1", c[3], sh)):
        if abs(val / g - round(val / g)) > 1e-3:
            v.append(f"{nm}={val} not on {g} grid")
    hx, hy = plan_["halo"]
    boxes = []
    for m in plan_["macros"]:
        x0, y0, x1, y1 = m["x"], m["y"], m["x"] + m["w"], m["y"] + m["h"]
        if x0 < c[0] + hx - 1e-6 or y0 < c[1] + hy - 1e-6 or x1 > c[2] - hx + 1e-6 or y1 > c[3] - hy + 1e-6:
            v.append(f"macro {m['name']} violates core+halo clearance")
        if abs(x0 / sw - round(x0 / sw)) > 1e-3 or abs(y0 / sh - round(y0 / sh)) > 1e-3:
            v.append(f"macro {m['name']} origin ({x0},{y0}) off the placement grid")
        boxes.append((m["name"], x0 - hx, y0 - hy, x1 + hx, y1 + hy))
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i], boxes[j]
            if a[1] < b[3] and b[1] < a[3] and a[2] < b[4] and b[2] < a[4]:
                v.append(f"macro halos overlap: {a[0]} / {b[0]}")
    if plan_["pin_groups"]["unassigned"]:
        v.append(f"{len(plan_['pin_groups']['unassigned'])} port bits not assigned to an edge (first: {plan_['pin_groups']['unassigned'][:3]})")
    # pin capacity: bits per edge vs usable track slots on that edge (met2 vertical pins on N/S, met3 horizontal on E/W)
    ucap = {"north": (d[2] - d[0]) / 0.46, "south": (d[2] - d[0]) / 0.46, "west": (d[3] - d[1]) / 0.68, "east": (d[3] - d[1]) / 0.68}
    for e, pins in plan_["pin_groups"]["edges"].items():
        if len(pins) > ucap[e] * 0.5:    # allow at most half of the raw track slots (min-distance + keep-out)
            v.append(f"edge {e}: {len(pins)} pins exceed 50% of {ucap[e]:.0f} track slots (I/O-limited die)")
    if plan_["placeable_core_area_um2"] <= 0:
        v.append("no placeable area left after blockages")
    return {"ok": not v, "violations": v}


def emit_tcl(plan_: dict, path: str | Path, cfg: dict) -> None:
    """Numbers-only Tcl consumed by floorplan.tcl (no logic here)."""
    L = []
    L.append("# generated by albion.plan; numbers only")
    L.append("set PLAN(die)  {" + " ".join(str(x) for x in plan_["die"]) + "}")
    L.append("set PLAN(core) {" + " ".join(str(x) for x in plan_["core"]) + "}")
    L.append("set PLAN(halo) {" + " ".join(str(x) for x in plan_["halo"]) + "}")
    L.append("set PLAN(macros) {}")
    for m in plan_["macros"]:
        L.append("lappend PLAN(macros) [list {%s} %s %s %s %s]" % (m["name"], m["cell"], m["x"], m["y"], m["orient"]))
    L.append("set PLAN(blockages) {}")
    for b in plan_["blockages"]:
        L.append("lappend PLAN(blockages) {" + " ".join(str(x) for x in b) + "}")
    for e, pins in plan_["pin_groups"]["edges"].items():
        L.append("set PLAN(pins_%s) {%s}" % (e, " ".join("{%s}" % p for p in pins)))
    Path(path).write_text("\n".join(L) + "\n")


def stage_plan(cfg: dict, prof: dict) -> dict:
    from .synth import macro_cells  # local import to avoid cycle
    d = run_dir(cfg, "plan")
    synth = read_json(run_dir(cfg, "synth") / "synth.json")
    if not synth or not synth.get("ok"):
        return {"stage": "plan", "ok": False, "reason": "synthesis result missing or failed"}
    macros_meta = macro_cells(cfg, prof)
    p = plan(cfg, prof, synth, macros_meta)
    chk = check_plan(p, cfg)
    p["legality"] = chk
    write_json(d / "plan.json", p)
    emit_tcl(p, d / "plan.tcl", cfg)
    return {"stage": "plan", "ok": chk["ok"], "violations": chk["violations"], "die": p["die"], "core": p["core"],
            "macros": len(p["macros"]), "utilization_target": p["target_utilization"],
            "achieved_pre_place_utilization": p["achieved_pre_place_utilization"]}
