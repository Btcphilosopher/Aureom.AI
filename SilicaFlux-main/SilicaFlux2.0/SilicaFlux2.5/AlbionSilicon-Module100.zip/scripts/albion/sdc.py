"""SDC generation from the resolved configuration.

Covers: primary clock, clock uncertainty (setup/hold), clock transition/latency (ideal, pre-CTS only), input delays
(max+min), output delays (max+min), driving cells, output loads, max transition, and justified exceptions
(false paths / multicycle).  An exception without a justification is a hard error (config.validate) and every
accepted exception is echoed into the SDC as a comment block AND into reports/<run>/constraints.json so that a
reviewer can see what was excluded from timing and why.

`unconstrained` reports are produced by STA (`check_timing`, `report_checks -unconstrained`), not here.
"""
from __future__ import annotations

from pathlib import Path


def generate(cfg: dict, ports: list[dict]) -> str:
    c, io = cfg["clock"], cfg["io"]
    P = float(c["period_ns"])
    clk = c["port"]
    name = c["name"]
    in_max = io["input_delay_frac"] * P
    in_min = io["input_min_delay_frac"] * P
    out_max = io["output_delay_frac"] * P
    out_min = io["output_min_delay_frac"] * P
    L = []
    L.append("# =============================================================================")
    L.append(f"# AlbionSilicon generated SDC   design={cfg['design']} variant={cfg['variant']} config_sha256={cfg['config_sha256'][:12]}")
    L.append("# DO NOT EDIT: regenerate with `albion sdc`.  Units: ns, pF.")
    L.append("# =============================================================================")
    L.append(f"set clk_period {P:.4f}")
    L.append(f"create_clock -name {name} -period $clk_period -waveform {{0.0 {P * c['duty']:.4f}}} [get_ports {clk}]")
    L.append(f"set_clock_uncertainty -setup {c['uncertainty_setup_ns']:.4f} [get_clocks {name}]")
    L.append(f"set_clock_uncertainty -hold  {c['uncertainty_hold_ns']:.4f} [get_clocks {name}]")
    L.append("# ideal-clock attributes: applied only before CTS (post-CTS the clock is propagated and these are ignored)")
    L.append(f"set_clock_latency {c['latency_ns']:.4f} [get_clocks {name}]")
    L.append(f"set_clock_transition {c['transition_ns']:.4f} [get_clocks {name}]")
    L.append("")
    L.append("# ---- external timing budget (fractions of the clock period)")
    L.append(f"set in_max  {in_max:.4f}   ;# input_delay_frac={io['input_delay_frac']}")
    L.append(f"set in_min  {in_min:.4f}   ;# input_min_delay_frac={io['input_min_delay_frac']}")
    L.append(f"set out_max {out_max:.4f}   ;# output_delay_frac={io['output_delay_frac']}")
    L.append(f"set out_min {out_min:.4f}   ;# output_min_delay_frac={io['output_min_delay_frac']}")
    ins = [q for q in ports if q["dir"] == "input" and q["name"] != clk]
    names = " ".join((f"{q['name']}[*]" if q["width"] > 1 else q["name"]) for q in ins)
    L.append(f"set data_inputs [get_ports {{{names}}}]   ;# every input except the clock (explicit list: portable across STA tools)")
    L.append(f"set_input_delay  -clock {name} -max $in_max  $data_inputs")
    L.append(f"set_input_delay  -clock {name} -min $in_min  $data_inputs")
    L.append(f"set_output_delay -clock {name} -max $out_max [all_outputs]")
    L.append(f"set_output_delay -clock {name} -min $out_min [all_outputs]")
    L.append(f"set_driving_cell -lib_cell {io['drive_cell']} -pin {io['drive_pin']} $data_inputs")
    L.append(f"set_load {io['load_pf']:.4f} [all_outputs]")
    L.append(f"set_max_transition {io['max_transition_ns']:.4f} [current_design]")
    L.append("")
    exc = io.get("exceptions", [])
    L.append(f"# ---- timing exceptions: {len(exc)}")
    if not exc:
        L.append("# NONE.  No false path or multicycle path was identified that can be justified for this design.")
        L.append("# (Reset is asynchronous-assert / synchronous-release by contract, so recovery/removal stay checked.)")
    for e in exc:
        L.append(f"# [{e['kind']}] {e.get('name', '')}: {str(e['justification']).strip()}")
        if e.get("evidence"):
            L.append(f"#   evidence: {e['evidence']}")
        if e["kind"] == "false_path":
            args = []
            for k, flag in (("from", "-from"), ("through", "-through"), ("to", "-to")):
                if e.get(k):
                    args.append(f"{flag} {e[k]}")
            L.append("set_false_path " + " ".join(args))
        elif e["kind"] == "multicycle":
            n = int(e["cycles"])
            args = []
            for k, flag in (("from", "-from"), ("through", "-through"), ("to", "-to")):
                if e.get(k):
                    args.append(f"{flag} {e[k]}")
            L.append(f"set_multicycle_path {n} -setup " + " ".join(args))
            L.append(f"set_multicycle_path {n - 1} -hold " + " ".join(args))
    L.append("")
    return "\n".join(L)


def lint(sdc_text: str, cfg: dict) -> dict:
    """Static checks on the generated SDC text."""
    problems = []
    if "create_clock" not in sdc_text:
        problems.append("no create_clock")
    for must in ("set_input_delay", "set_output_delay", "set_load", "set_clock_uncertainty"):
        if must not in sdc_text:
            problems.append(f"missing {must}")
    n_fp = sdc_text.count("set_false_path")
    n_mc = sdc_text.count("set_multicycle_path") // 2
    just = sum(1 for ln in sdc_text.splitlines() if ln.startswith("# [false_path]") or ln.startswith("# [multicycle]"))
    if n_fp + n_mc != just:
        problems.append("exception count does not match justification count")
    return {"ok": not problems, "problems": problems, "n_false_paths": n_fp, "n_multicycle": n_mc}


def write(cfg: dict, ports: list[dict], out: str | Path) -> dict:
    txt = generate(cfg, ports)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(txt)
    res = lint(txt, cfg)
    res["path"] = str(out)
    return res
