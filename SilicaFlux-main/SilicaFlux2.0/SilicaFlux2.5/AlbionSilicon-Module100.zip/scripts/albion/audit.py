"""Repository audit (brief section 1): inventory every archive for HDL / physical-design assets, and record the candidate table.

`python3 -m albion.audit [REPO_ROOT]` writes reports/audit/repo_inventory.json (reproducible scan) and
reports/audit/candidates.json (candidate evidence: numbers re-measured in this programme, with the log they came from).
"""
from __future__ import annotations

import io
import json
import os
import re
import sys
import time
import zipfile
from pathlib import Path

from .util import ROOT, write_json

PATTERNS = {
    "hdl": re.compile(r"\.(sv|v|vhd|svh|vh)$", re.I), "sdc": re.compile(r"\.sdc$", re.I), "lef": re.compile(r"\.(lef|tlef)$", re.I),
    "liberty": re.compile(r"\.lib$", re.I), "gds": re.compile(r"\.gds2?$", re.I), "def": re.compile(r"\.def$", re.I),
    "tcl": re.compile(r"\.tcl$", re.I), "upf": re.compile(r"\.upf$", re.I),
}


def _scan(zf: zipfile.ZipFile, depth: int, counts: dict, found: dict, prefix: str) -> None:
    for n in zf.namelist():
        for k, p in PATTERNS.items():
            if p.search(n):
                counts[k] = counts.get(k, 0) + 1
        if re.search(r"(nangate|sky130|gf180|ihp-?sg13|asap7|freepdk|fakeram)", n, re.I):
            found.setdefault("pdk_references", []).append(n)
        if depth < 3 and n.lower().endswith(".zip"):
            try:
                _scan(zipfile.ZipFile(io.BytesIO(zf.read(n))), depth + 1, counts, found, prefix + "!" + n)
            except Exception:  # noqa: BLE001
                pass


def inventory(repo: Path) -> dict:
    out = {"generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "repo": str(repo), "archives": []}
    for root, _dirs, files in os.walk(repo):
        if ".git" in root.split(os.sep) or "physical/albion" in root:
            continue
        for fn in files:
            if fn.lower().endswith(".zip") and re.search(r"silica|albion|neurax|fabtwin", os.path.join(root, fn), re.I):
                p = os.path.join(root, fn)
                counts: dict = {}
                found: dict = {}
                try:
                    _scan(zipfile.ZipFile(p), 0, counts, found, p)
                except Exception as ex:  # noqa: BLE001
                    counts["error"] = str(ex)
                out["archives"].append({"path": os.path.relpath(p, repo), "counts": counts, "n_pdk_references": len(found.get("pdk_references", []))})
    tot: dict = {}
    for a in out["archives"]:
        for k, v in a["counts"].items():
            if isinstance(v, int):
                tot[k] = tot.get(k, 0) + v
    out["n_archives"] = len(out["archives"])
    out["totals_including_nested_duplicates"] = tot
    out["archives_with_sdc_or_lef_or_liberty"] = [a["path"] for a in out["archives"] if any(a["counts"].get(k) for k in ("sdc", "lef", "liberty"))]
    return out


# Candidate table.  Every number below was measured in THIS programme (tools: Yosys 0.33 generic `synth -flatten; stat`, upstream
# regression targets re-run with Verilator 5.020 / Icarus 12 / Yosys 0.33) unless marked "upstream-reported".
CANDIDATES = [
    {"id": "tensorcore01.tensor_pe_mesh", "role": "SELECTED (Design A: compute)", "source": "silicaflux-tensorcore01",
     "generic_cells_2x2": 3262, "flops_2x2": 276, "single_pe_cells": 817, "single_pe_flops": 140,
     "evidence_rerun": "make lint: clean; `make quick` OVERALL PASS in 103.4 s (reference model, lint, PE sim in Verilator+Icarus, mesh, config checks, K-limit)",
     "evidence_log": "tpe_regress.log", "why": "smallest verified compute subsystem; lane count is an RTL parameter; pure synthesizable RTL; async-reset flops only; no latches"},
    {"id": "hpc_m04_scratchpad", "role": "SELECTED (Design B: memory + real macro)", "source": "silicaflux-hpc-m04-scratchpad",
     "generic_cells_as_configured": 1677, "flops_as_configured": 322, "evidence_rerun": "make spm-quick: lint 11/11, invalid-parameter rejection 27/27, stage-1 133/133, regression PASSED in 254.7 s",
     "evidence_log": "m04_quick.log",
     "gap_found": "upstream never simulated BACKEND=ASIC (TB hard-codes MACRO=0 and backdoors the GENERIC array); closed here: 26/26 runs against the real OpenRAM vendor model (see docs/05)",
     "why": "smallest verified memory subsystem with a real-macro backend (sramlib, unmodified); capacity/banks are parameters"},
    {"id": "sramcore_p71.sf_sram_core", "role": "not selected", "source": "silicaflux-sramcore-p71", "evidence_rerun": "make sram-quick: lint 64/64, sim 11/11",
     "evidence_log": "p71_quick.log", "why": "behavioural array only; real-macro path is carried by the M04 + sramlib stack instead"},
    {"id": "hpc_fp32_fma (M01)", "role": "not selected", "generic_cells": 8663, "flops": 418, "why": "2.6x the cells of the 2x2 mesh for one arithmetic unit; no lane-count knob; adds no new physical-design capability"},
    {"id": "hpc_vector_lane (M02)", "role": "not selected", "generic_cells": 22475, "flops": 2354, "why": "6.9x the cells of the 2x2 mesh; FP32 datapaths; defer until the flow is proven on smaller verified blocks"},
    {"id": "hpc_m03_vector_array / hpc_m08_tile", "role": "not selected", "why": "N copies of the M02 lane plus scratchpad/DMA/scheduler: would be the 'first big design' the brief warns against",
     "upstream_reported": "M08 integration regression 145/145 (simulation only); no physical flow"},
    {"id": "albion_p90 ALBION_MIN (sf_albion_cloud_top)", "role": "not selected", "why": "contains an RV32 ControlCore + DMA + fabric + 4 SRAM macros of 4096x39 (no such open macro exists)",
     "upstream_reported": "53,304 sky130 cells, 8,494 flops, 472,011 um^2 (reports/synth/summary.json); physical flow 'configured, not executed'"},
    {"id": "silicaflux-p40-floorplanbuild", "role": "not selected / not usable as evidence", "why": "uses a STAND-IN DieTop (not real RTL); its README cites physical/silicaflux/{scripts,tech,results} which are NOT in the archive, so its published numbers cannot be reproduced from the repository"},
]


def main(repo: str | None = None) -> int:
    repo_p = Path(repo or ROOT.parents[1])
    d = ROOT / "reports" / "audit"
    inv = inventory(repo_p)
    write_json(d / "repo_inventory.json", inv)
    write_json(d / "candidates.json", {"generated_utc": inv["generated_utc"], "method": "see docs/01_SOURCE_SELECTION.md", "candidates": CANDIDATES})
    print(f"archives scanned: {inv['n_archives']}; totals: {inv['totals_including_nested_duplicates']}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else None))
