"""Minimal LEF macro reader (size, pins, directions, layers) + macro interface consistency checks."""
from __future__ import annotations

import re
from pathlib import Path


def parse_lef_macro(path: str, macro: str | None = None) -> dict:
    """Return {name, w, h, pins:{pin: {dir, use, layers}}, obs_layers}."""
    txt = Path(path).read_text()
    m = re.search(r"^MACRO\s+(\S+)", txt, flags=re.M) if macro is None else re.search(rf"^MACRO\s+({re.escape(macro)})\b", txt, flags=re.M)
    if not m:
        raise ValueError(f"MACRO {macro or ''} not found in {path}")
    name = m.group(1)
    end = re.search(rf"^END\s+{re.escape(name)}\b", txt[m.end():], flags=re.M)
    body = txt[m.end(): m.end() + end.start()] if end else txt[m.end():]
    sz = re.search(r"SIZE\s+([\d.]+)\s+BY\s+([\d.]+)", body)
    pins: dict[str, dict] = {}
    # line-based scan: `\b` does not work after ']' in bus pin names such as din0[3]
    lines = body.splitlines()
    i = 0
    while i < len(lines):
        pm = re.match(r"^\s*PIN\s+(\S+)\s*$", lines[i])
        if not pm:
            i += 1
            continue
        pname = pm.group(1)
        j = i + 1
        while j < len(lines) and not re.match(rf"^\s*END\s+{re.escape(pname)}\s*$", lines[j]):
            j += 1
        pbody = "\n".join(lines[i + 1: j])
        d = re.search(r"DIRECTION\s+(\w+)", pbody)
        u = re.search(r"USE\s+(\w+)", pbody)
        layers = sorted(set(re.findall(r"^\s*LAYER\s+(\w+)", pbody, flags=re.M)))
        pins[pname] = {"dir": d.group(1) if d else None, "use": u.group(1) if u else None, "layers": layers}
        i = j + 1
    obs = re.search(r"^\s*OBS(.*?)^\s*END\b", body, flags=re.M | re.S)
    obs_layers = sorted(set(re.findall(r"^\s*LAYER\s+(\w+)", obs.group(1), flags=re.M))) if obs else []
    return {"name": name, "w": float(sz.group(1)), "h": float(sz.group(2)), "pins": pins, "obs_layers": obs_layers}


def signal_buses(lef: dict) -> list[tuple[str, str, int]]:
    """[(direction, base, width)] for signal pins (power/ground excluded), buses merged."""
    buses: dict[str, list] = {}
    for p, v in lef["pins"].items():
        if v["use"] in ("POWER", "GROUND"):
            continue
        m = re.fullmatch(r"(.+)\[(\d+)\]", p)
        base, idx = (m.group(1), int(m.group(2))) if m else (p, None)
        d = {"INPUT": "input", "OUTPUT": "output", "INOUT": "inout"}.get(v["dir"] or "", "inout")
        b = buses.setdefault(base, [d, -1])
        if idx is not None:
            b[1] = max(b[1], idx)
    out = []
    for base, (d, mx) in buses.items():
        out.append((d, base, mx + 1 if mx >= 0 else 1))
    return out


def blackbox_from_lef(lef: dict) -> str:
    ps = []
    for d, base, w in signal_buses(lef):
        rng = f"[{w - 1}:0] " if w > 1 else ""
        ps.append(f"  {d} wire {rng}{base}")
    return f"(* blackbox *)\nmodule {lef['name']} (\n" + ",\n".join(ps) + "\n);\nendmodule\n"


def power_pins(lef: dict) -> dict:
    out = {"power": [], "ground": []}
    for p, v in lef["pins"].items():
        if v["use"] == "POWER":
            out["power"].append((p, v["layers"]))
        elif v["use"] == "GROUND":
            out["ground"].append((p, v["layers"]))
    return out


def liberty_pins(lib_path: str) -> dict[str, int]:
    """Signal pin/bus base names -> width from an OpenRAM-style Liberty (pin(x) and bus(x) groups)."""
    txt = Path(lib_path).read_text()
    widths: dict[str, int] = {}
    for m in re.finditer(r'\bbus\s*\(\s*"?([\w]+)"?\s*\)\s*\{(.*?)bus_type\s*:\s*"?(\w+)"?', txt, flags=re.S):
        name, _, bt = m.group(1), m.group(2), m.group(3)
        tm = re.search(rf'type\s*\(\s*"?{re.escape(bt)}"?\s*\)\s*\{{(.*?)\}}', txt, flags=re.S)
        w = 1
        if tm:
            bw = re.search(r"bit_width\s*:\s*(\d+)", tm.group(1))
            if bw:
                w = int(bw.group(1))
        widths[name] = w
    for m in re.finditer(r'\bpin\s*\(\s*"?([\w]+)"?\s*\)\s*\{', txt):
        widths.setdefault(m.group(1), 1)
    return widths


def check_macro_interface(lef_path: str, verilog_ports: dict[str, tuple[str, int]], lib_path: str | None) -> dict:
    """Cross-check LEF signal buses against (a) the vendor Verilog port list and (b) the Liberty pins."""
    lef = parse_lef_macro(lef_path)
    lef_b = {base: (d, w) for d, base, w in signal_buses(lef)}
    problems = []
    for n, (d, w) in lef_b.items():
        if n not in verilog_ports:
            problems.append(f"LEF pin {n} missing in vendor Verilog model")
        else:
            vd, vw = verilog_ports[n]
            if vw != w:
                problems.append(f"{n}: LEF width {w} != Verilog width {vw}")
            if vd != d:
                problems.append(f"{n}: LEF dir {d} != Verilog dir {vd}")
    for n in verilog_ports:
        if n not in lef_b:
            problems.append(f"Verilog port {n} missing in LEF")
    if lib_path:
        lp = liberty_pins(lib_path)
        for n, (d, w) in lef_b.items():
            if n not in lp:
                problems.append(f"LEF pin {n} missing in Liberty")
            elif lp[n] != w:
                problems.append(f"{n}: LEF width {w} != Liberty width {lp[n]}")
    return {"macro": lef["name"], "ok": not problems, "problems": problems, "n_signal_buses": len(lef_b),
            "n_signal_pins": sum(w for _, w in lef_b.values()), "size_um": [lef["w"], lef["h"]],
            "power_pins": power_pins(lef)}
