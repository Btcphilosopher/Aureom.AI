"""Stage registry, state tracking and prerequisite enforcement.

A stage runs only if its prerequisites are recorded OK in build/<run>/state.json (the same discipline a CI gate
uses).  A stage that is not run is never reported as passed: reports state exactly which stages executed.
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path

from . import pdk as pdkmod
from .config import run_dir, save_resolved
from .util import ROOT, read_json, run, tool, write_json

# order matters; value = prerequisite stage
STAGES: dict[str, str | None] = {
    "techcheck": None,
    "lint": "techcheck",
    "verify_rtl": "lint",
    "synth": "verify_rtl",
    "gls": "synth",
    "sdc": "synth",
    "sta_pre": "sdc",
    "plan": "sta_pre",
    "floorplan": "plan",
    "place": "floorplan",
    "cts": "place",
    "groute": "cts",
    "droute": "groute",
    "signoff_sta": "droute",
    "irdrop": "droute",
    "antenna": "droute",
    "drc": "droute",
    "lvs": "droute",
    "report": "signoff_sta",
}


def state_path(cfg) -> Path:
    return Path(cfg["paths"]["build"]) / "state.json"


def load_state(cfg) -> dict:
    return read_json(state_path(cfg), {})


def record(cfg, stage: str, res: dict, seconds: float) -> None:
    st = load_state(cfg)
    st[stage] = {"ok": bool(res.get("ok")), "seconds": round(seconds, 2), "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                 "config_sha256": cfg["config_sha256"]}
    write_json(state_path(cfg), st)


def sections(text: str) -> dict[str, str]:
    out = {}
    for m in re.finditer(r"ALBION_BEGIN (\S+)\n(.*?)ALBION_END \1\n", text, flags=re.S):
        out[m.group(1)] = m.group(2)
    return out


def metrics(text: str) -> dict:
    out = {}
    for m in re.finditer(r"^ALBION_METRIC (\S+) (.*)$", text, flags=re.M):
        k, v = m.group(1), m.group(2).strip()
        try:
            out[k] = float(v) if re.fullmatch(r"-?\d+\.\d*([eE][-+]?\d+)?|-?\d+[eE][-+]?\d+", v) else (int(v) if re.fullmatch(r"-?\d+", v) else v)
        except ValueError:
            out[k] = v
    return out


def run_openroad(cfg, prof, script: str, stage: str, extra_env: dict | None = None, extra_cfg: dict | None = None,
                 timeout: int = 7200) -> dict:
    """Run an OpenROAD Tcl stage script.  Writes build/<run>/<stage>/<stage>.log and per-section report files."""
    from .tclenv import emit_env
    d = run_dir(cfg, stage)
    envf = emit_env(cfg, prof, extra_cfg)
    env = {"ALBION_ENV": str(envf), "ALBION_TCL_DIR": str(ROOT / "scripts" / "tcl"), "ALBION_STAGE_DIR": str(d)}
    env.update(extra_env or {})
    exe = tool("openroad")
    r = run([exe, "-exit", "-no_splash", str(ROOT / "scripts" / "tcl" / script)], d / f"{stage}.log", cwd=d, env=env,
            timeout=timeout, fatal=[r"^ERROR", r"^Error:", r"\[ERROR", r"Segmentation fault", r"Traceback"])
    text = Path(d / f"{stage}.log").read_text(errors="replace")
    for name, body in sections(text).items():
        (d / f"{name}.rpt").write_text(body)
    r["metrics"] = metrics(text)
    r["done"] = f"ALBION_DONE {stage}" in text
    r["ok"] = r["ok"] and r["done"]
    return r


def run_stage(cfg: dict, stage: str, force: bool = False) -> dict:
    from . import stages
    if stage not in STAGES and stage not in ("sdc",):
        return {"ok": False, "error": f"unknown stage {stage}"}
    prof = pdkmod.load_profile(cfg["pdk"])
    st = load_state(cfg)
    pre = STAGES.get(stage)
    if pre and not force and not st.get(pre, {}).get("ok"):
        return {"ok": False, "stage": stage, "error": f"prerequisite stage '{pre}' has not passed (state: {st.get(pre)})"}
    fn = getattr(stages, f"stage_{stage}", None)
    if fn is None:
        return {"ok": False, "error": f"stage {stage} not implemented"}
    t0 = time.time()
    try:
        res = fn(cfg, prof)
    except Exception as ex:  # noqa: BLE001
        import traceback
        res = {"ok": False, "stage": stage, "exception": f"{ex.__class__.__name__}: {ex}", "trace": traceback.format_exc()[-1500:]}
    secs = time.time() - t0
    res.setdefault("stage", stage)
    record(cfg, stage, res, secs)
    write_json(run_dir(cfg, stage) / "result.json", res)
    return res


def run_flow(cfg: dict, to: str = "report", advisory: tuple = ("irdrop", "antenna", "drc", "lvs"), skip: tuple = ()) -> int:
    order = list(STAGES)
    if to not in order:
        print(f"unknown stage {to}")
        return 2
    last = order.index(to)
    rc = 0
    for s in order[: last + 1]:
        if s in skip:
            print(f"[{cfg['run_id']}] {s:12s} SKIPPED (requested)")
            continue
        r = run_stage(cfg, s)
        mark = "PASS" if r.get("ok") else "FAIL"
        print(f"[{cfg['run_id']}] {s:12s} {mark}" + ("" if r.get("ok") else f"  -> {str(r.get('error') or r.get('exception') or r.get('fatal') or r.get('reason') or r.get('violations') or '')[:300]}"))
        if not r.get("ok"):
            rc = 1
            if s not in advisory:
                break
    return rc
