"""Configuration resolver: defaults.yaml <- designs/<name>.yaml <- variant overrides.

Everything the flow needs is resolved into ONE dict that is written verbatim to
build/<run>/resolved.json, so a run is reproducible from that file alone.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
from pathlib import Path

import yaml

from .util import ROOT, write_json

DESIGNS = {  # short name -> yaml stem
    "pe_mesh": "pe_mesh",
    "spm": "spm",
}


def deep_merge(a: dict, b: dict) -> dict:
    out = copy.deepcopy(a)
    for k, v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def set_dotted(d: dict, key: str, value) -> None:
    cur = d
    parts = key.split(".")
    for p in parts[:-1]:
        if p.isdigit() and isinstance(cur, list):
            cur = cur[int(p)]
        else:
            cur = cur.setdefault(p, {})
    last = parts[-1]
    if last.isdigit() and isinstance(cur, list):
        cur[int(last)] = value
    else:
        cur[last] = value


def get_dotted(d: dict, key: str, default=None):
    cur = d
    for p in key.split("."):
        if isinstance(cur, list) and p.isdigit():
            cur = cur[int(p)]
        elif isinstance(cur, dict) and p in cur:
            cur = cur[p]
        else:
            return default
    return cur


def load_design(name: str, overrides: dict | None = None, variant: str = "base") -> dict:
    stem = DESIGNS.get(name, name)
    p = ROOT / "config" / "designs" / f"{stem}.yaml"
    if not p.exists():
        raise FileNotFoundError(f"design config not found: {p}")
    with open(ROOT / "config" / "defaults.yaml") as f:
        cfg = yaml.safe_load(f)
    with open(p) as f:
        cfg = deep_merge(cfg, yaml.safe_load(f))
    for k, v in (overrides or {}).items():
        set_dotted(cfg, k, v)
    cfg["variant"] = variant
    try:
        from . import pdk as _pdk
        cfg["pdk_default_corner"] = _pdk.load_profile(cfg["pdk"]).get("default_corner", "tt")
    except Exception:  # noqa: BLE001
        cfg["pdk_default_corner"] = "tt"
    cfg["overrides"] = dict(overrides or {})
    cfg["run_id"] = f"{cfg['design']}__{variant}"
    cfg["paths"] = {
        "root": str(ROOT),
        "build": str(ROOT / "build" / cfg["run_id"]),
        "results": str(ROOT / "results" / cfg["run_id"]),
    }
    cfg["config_sha256"] = hashlib.sha256(json.dumps({k: v for k, v in cfg.items() if k != "paths"},
                                                     sort_keys=True, default=str).encode()).hexdigest()
    validate(cfg)
    return cfg


def validate(cfg: dict) -> None:
    errs = []
    c = cfg["clock"]
    if not c["period_ns"] > 0:
        errs.append("clock.period_ns must be > 0")
    f = cfg["floorplan"]
    if not 0.05 <= f["utilization"] <= 0.9:
        errs.append("floorplan.utilization must be in [0.05, 0.90]")
    if f["aspect_ratio"] <= 0:
        errs.append("floorplan.aspect_ratio must be > 0")
    for e in cfg["io"].get("exceptions", []):
        if not e.get("justification") or len(str(e["justification"]).strip()) < 20:
            errs.append(f"io.exceptions entry {e.get('kind')}/{e.get('name')} lacks a real justification")
        if e.get("kind") not in ("false_path", "multicycle"):
            errs.append(f"io.exceptions: unknown kind {e.get('kind')!r}")
    for g in f["io"]["groups"]:
        try:
            re.compile(g["pins"])
        except re.error as ex:
            errs.append(f"floorplan.io.groups regex invalid: {g['pins']!r}: {ex}")
    if errs:
        raise ValueError("invalid configuration:\n  " + "\n  ".join(errs))


def source_files(cfg: dict) -> list[str]:
    return [str(ROOT / s) for s in cfg["source"]["files"]]


def run_dir(cfg: dict, *sub: str) -> Path:
    p = Path(cfg["paths"]["build"]).joinpath(*sub)
    p.mkdir(parents=True, exist_ok=True)
    return p


def save_resolved(cfg: dict) -> Path:
    p = Path(cfg["paths"]["build"]) / "resolved.json"
    write_json(p, cfg)
    return p


def parse_override(s: str):
    """'a.b=3' / 'a.b=0.4' / 'a.b=[1,2]' / 'a.b=text' -> (key, python value)."""
    k, v = s.split("=", 1)
    try:
        val = yaml.safe_load(v)
    except Exception:  # noqa: BLE001
        val = v
    return k.strip(), val
