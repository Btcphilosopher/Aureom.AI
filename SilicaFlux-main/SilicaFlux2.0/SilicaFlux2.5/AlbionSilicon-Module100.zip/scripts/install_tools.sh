#!/usr/bin/env bash
# AlbionSilicon tool installation: the EXACT steps used to produce the reported results (Ubuntu 24.04, x86-64).
# Every command below was executed in the original run; versions are recorded in reports/*/summary.json.
#   apt:        Yosys 0.33, Verilator 5.020, Icarus 12.0, KLayout 0.28.16, Python deps
#   conda-hub:  OpenROAD 2.0-12381-g01bba3695 + open_pdks.sky130a 1.0.471 (litex-hub / anaconda / conda-forge)
#               Magic 8.3.465 + Netgen 1.5.272 (matched to the PDK tech file; apt Magic 8.3.105 is too old)
# Needs outbound HTTPS to archive.ubuntu.com and conda.anaconda.org.  ~12 GB disk (the PDK package alone is 1.3 GB download).
set -euo pipefail
EDA=${EDA:-/opt/eda}
sudo mkdir -p "$EDA" && sudo chown "$USER" "$EDA"

sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
  yosys verilator iverilog klayout python3-pip python3-yaml python3-pytest build-essential curl unzip zip

# micromamba from conda-forge (micro.mamba.pm may be unreachable behind proxies)
mkdir -p "$EDA/dl" && cd "$EDA/dl"
curl -fsSL -o micromamba.tar.bz2 https://conda.anaconda.org/conda-forge/linux-64/micromamba-2.10.0-0.tar.bz2
mkdir -p mm && tar -xjf micromamba.tar.bz2 -C mm
export MAMBA_ROOT_PREFIX="$EDA/mamba"
MM="$EDA/dl/mm/bin/micromamba"

$MM create -y -p "$EDA/env"    -c litex-hub -c anaconda -c conda-forge --override-channels openroad=2.0_12381_g01bba3695 open_pdks.sky130a
$MM create -y -p "$EDA/env_mn" -c litex-hub -c anaconda -c conda-forge --override-channels magic netgen

echo "now run:  make albion-fetch-pdk albion-pdk-check"
