# Magic DRC (sky130A tech, drc(full) style) on the exported GDS.  Violations are written with rule text and box (Magic
# internal units) so the python side can split macro-internal vs top-level (routing / std-cell) violations.
# Tcl errors in result handling are caught and reported (Magic exits 0 even if a script dies: never trust the exit code).
set top   $::env(ALB_TOP)
set out   $::env(ALB_OUT)
drc off
crashbackups stop
gds readonly true
gds rescale false
gds read $out/$top.gds
load $top
select top cell
# top-cell bounding box in internal units: python derives the um scale from the known die size
puts "ALBION_MAGIC top_box [box values]"
drc style drc(full)
drc on
drc check
drc catchup
set total 0
if {[catch {
  set whys [drc listall why]
  set fh [open $out/magic_drc.rpt w]
  foreach {rule boxes} $whys {
    foreach b $boxes {
      incr total
      puts $fh "$rule | $b"
    }
  }
  close $fh
  puts "ALBION_MAGIC drc_rules [expr {[llength $whys] / 2}]"
} err]} { puts "ALBION_MAGIC_ERROR $err" }
puts "ALBION_MAGIC drc_total $total"
puts "ALBION_DONE magic_drc"
quit -noprompt
