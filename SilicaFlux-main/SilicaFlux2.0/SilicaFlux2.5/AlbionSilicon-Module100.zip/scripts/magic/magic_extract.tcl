# Magic: layout -> SPICE (hierarchical, std cells as sub-circuits) for LVS against the routed netlist.
set top   $::env(ALB_TOP)
set out   $::env(ALB_OUT)
drc off
crashbackups stop
gds readonly true
gds rescale false
gds read $out/$top.gds
load $top
select top cell
cd $out
extract do local
extract no capacitance
extract no coupling
extract no resistance
extract no adjust
extract unique
extract warn all
extract
ext2spice lvs
ext2spice hierarchy on
ext2spice subcircuit top on
ext2spice -o $out/${top}_layout.spice
puts "ALBION_DONE magic_extract"
quit -noprompt
