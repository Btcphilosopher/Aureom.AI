# Magic: routed DEF + LEF + cell GDS  ->  full-layout GDS (std cells + macros + routing).
#   magic -dnull -noconsole -rcfile <sky130A.magicrc> magic_gds.tcl      (environment variables ALB_* set by albion)
# EXPERIMENTAL flow (open_pdks/Magic): this GDS is the object that open-source DRC/LVS decks are run on; it is NOT a
# foundry-qualified tapeout database (no seal ring, no density/dummy fill, no foundry-approved GDS stream-out).
set top   $::env(ALB_TOP)
set out   $::env(ALB_OUT)
drc off
crashbackups stop
gds readonly true
gds rescale false
gds noduplicates true

# Order matters (learned the hard way: the first version silently produced an empty 126-byte GDS):
#   * tech LEF only: layer/via definitions for the DEF reader.  Do NOT read std-cell or macro LEFs: an abstract view
#     that already exists makes `gds read` keep the empty abstract ("Using pre-existing cell definition").
#   * macro GDS before the DEF so macro instances bind to the real layout.
#   * std cells are resolved from the PDK .mag layouts on Magic's search path (set by sky130A.magicrc).
lef read $::env(ALB_TECH_LEF)
foreach g $::env(ALB_MACRO_GDS) { gds read $g }
def read $::env(ALB_DEF) -labels

load $top
select top cell
puts "ALBION_MAGIC cells_in_hierarchy [llength [cellname list allcells]]"
gds write $out/$top.gds
puts "ALBION_DONE magic_gds"
quit -noprompt
