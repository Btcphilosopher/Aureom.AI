# Floorplan: die/core, tracks, macro placement + halos + blockages, tap cells, power grid.
# Executes plan.tcl (numbers computed and independently legality-checked in Python) and re-verifies it in the database.
source $::env(ALBION_TCL_DIR)/common.tcl
source [cfg build.plan_tcl]

load_lefs
load_libs [cfg pdk.default_corner tt]
load_netlist
read_sdc [cfg build.sdc]
source_rc
apply_dont_use

set block [ord::get_db_block]
set dbu [$block getDbUnitsPerMicron]

# ---------------------------------------------------------------- die / core / tracks
initialize_floorplan -die_area $PLAN(die) -core_area $PLAN(core) -site [cfg pdk.site]
make_tracks

# ---------------------------------------------------------------- macros: placement, halo, blockage
set macs [macro_instances]
if {[llength $macs] != [llength $PLAN(macros)]} {
  fatal "macro count mismatch: database [llength $macs] vs plan [llength $PLAN(macros)]"
}
lassign $PLAN(halo) hx hy
set i 0
foreach inst $macs {
  lassign [lindex $PLAN(macros) $i] pname pcell px py porient
  set master [[$inst getMaster] getName]
  if {$master ne $pcell} { fatal "macro $i master $master != planned $pcell" }
  $inst setOrient $porient
  $inst setLocation [dbu $px] [dbu $py]
  $inst setPlacementStatus FIRM
  incr i
}
# placement blockage = halo ring around each macro (hard keep-out for standard cells)
foreach b $PLAN(blockages) {
  lassign $b bx0 by0 bx1 by1
  odb::dbBlockage_create $block [dbu $bx0] [dbu $by0] [dbu $bx1] [dbu $by1]
}

# ---------------------------------------------------------------- power connections
add_global_connection -net [cfg pdk.vdd_net] -inst_pattern {.*} -pin_pattern {^VPWR$} -power
add_global_connection -net [cfg pdk.vdd_net] -inst_pattern {.*} -pin_pattern {^VPB$} -power
add_global_connection -net [cfg pdk.vss_net] -inst_pattern {.*} -pin_pattern {^VGND$} -ground
add_global_connection -net [cfg pdk.vss_net] -inst_pattern {.*} -pin_pattern {^VNB$} -ground
foreach p [lsort -unique [cfg macro.power_vdd]] {
  add_global_connection -net [cfg pdk.vdd_net] -inst_pattern {.*} -pin_pattern "^${p}\$" -power
}
foreach p [lsort -unique [cfg macro.power_vss]] {
  add_global_connection -net [cfg pdk.vss_net] -inst_pattern {.*} -pin_pattern "^${p}\$" -ground
}
global_connect

# ---------------------------------------------------------------- tap cells
if {[cfg floorplan.tapcell 1]} {
  tapcell -distance [cfg cells.tap_distance_um 14] -tapcell_master [cfg cells.tap]
  # tap cells were created after the first global_connect: connect their VPWR/VGND pins now
  global_connect
}

# ---------------------------------------------------------------- power grid
set_voltage_domain -name CORE -power [cfg pdk.vdd_net] -ground [cfg pdk.vss_net]
define_pdn_grid -name grid -voltage_domains CORE -pins [cfg layers.pdn_horizontal]
add_pdn_stripe -grid grid -layer [cfg layers.pdn_followpin] -width [cfg floorplan.pdn.m1_followpin_width] -pitch 5.44 -offset 0 -followpins
add_pdn_stripe -grid grid -layer [cfg layers.pdn_vertical] -width [cfg floorplan.pdn.m4_width] -pitch [cfg floorplan.pdn.m4_pitch] -offset [cfg floorplan.pdn.m4_offset]
add_pdn_stripe -grid grid -layer [cfg layers.pdn_horizontal] -width [cfg floorplan.pdn.m5_width] -pitch [cfg floorplan.pdn.m5_pitch] -offset [cfg floorplan.pdn.m5_offset]
add_pdn_connect -grid grid -layers [list [cfg layers.pdn_followpin] [cfg layers.pdn_vertical]]
add_pdn_connect -grid grid -layers [list [cfg layers.pdn_vertical] [cfg layers.pdn_horizontal]]
if {[llength $macs] > 0} {
  set mh [cfg floorplan.pdn.macro_halo_um 2.0]
  define_pdn_grid -name macro_grid -voltage_domains CORE -macro -orient {R0 R180 MX MY} -halo [list $mh $mh $mh $mh] -default -grid_over_boundary
  add_pdn_connect -grid macro_grid -layers [list [cfg layers.pdn_vertical] [cfg layers.pdn_horizontal]]
}
pdngen

# ---------------------------------------------------------------- re-verification in the database
section floorplan_check {
  set die [$block getDieArea]
  set core [$block getCoreArea]
  puts "die   [um [$die xMin]] [um [$die yMin]] [um [$die xMax]] [um [$die yMax]]"
  puts "core  [um [$core xMin]] [um [$core yMin]] [um [$core xMax]] [um [$core yMax]]"
  puts "rows  [llength [$block getRows]]"
  set bad 0
  set i 0
  foreach inst $macs {
    set bb [$inst getBBox]
    set x0 [um [$bb xMin]]; set y0 [um [$bb yMin]]; set x1 [um [$bb xMax]]; set y1 [um [$bb yMax]]
    lassign [lindex $PLAN(macros) $i] pname pcell px py porient
    set ok 1
    if {abs($x0 - $px) > 0.01 || abs($y0 - $py) > 0.01} { set ok 0 }
    if {$x0 < [um [$core xMin]] + $hx - 0.01 || $y0 < [um [$core yMin]] + $hy - 0.01 || $x1 > [um [$core xMax]] - $hx + 0.01 || $y1 > [um [$core yMax]] - $hy + 0.01} { set ok 0 }
    if {![string equal [$inst getPlacementStatus] FIRM]} { set ok 0 }
    puts "macro [$inst getName] master=[[$inst getMaster] getName] bbox=$x0,$y0,$x1,$y1 halo=${hx},${hy} legal=$ok"
    if {!$ok} { incr bad }
    incr i
  }
  puts "blockages [llength [$block getBlockages]]"
  metric floorplan_macro_violations $bad
  metric floorplan_blockages [llength [$block getBlockages]]
  metric floorplan_rows [llength [$block getRows]]
}
section pdn_check {
  foreach net [list [cfg pdk.vdd_net] [cfg pdk.vss_net]] {
    puts "check_power_grid -net $net"
    catch {check_power_grid -net $net} err
    puts "result: $err"
  }
}
set taps 0
foreach inst [$block getInsts] { if {[string match "*tapvpwrvgnd*" [[$inst getMaster] getName]]} { incr taps } }
metric tapcells $taps
design_area_summary floorplan

write_db floorplan.odb
write_def floorplan.def
puts "ALBION_DONE floorplan"
exit
