# Antenna rule check on the detail-routed database (OpenROAD).  Rule parameters come from the technology LEF
# (ANTENNA* properties); this is an open-source implementation, not a foundry antenna signoff deck.
source $::env(ALBION_TCL_DIR)/common.tcl
load_lefs
load_libs [cfg pdk.default_corner tt]
read_db $::env(ALBION_STAGE_DIR)/../droute/droute.odb
section antenna_final { check_antennas -verbose }
puts "ALBION_DONE antenna"
exit
