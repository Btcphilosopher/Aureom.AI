# Classify STA "unconstrained endpoints" from the routed database: an endpoint whose driver chain (through buffers /
# inverters only) ends at a tie cell (conb) is CONSTANT-DRIVEN: it has no launching startpoint, so STA cannot constrain it
# and no real timing path exists.  Anything else is "other" and is a genuine constraint gap.
source $::env(ALBION_TCL_DIR)/common.tcl
load_lefs
read_db $::env(ALBION_STAGE_DIR)/../droute/droute.odb
set block [ord::get_db_block]

proc is_passthru {master} {
  return [expr {[string match "*__buf_*" $master] || [string match "*__clkbuf_*" $master] || [string match "*__inv_*" $master] || [string match "*__clkinv_*" $master] || [string match "*__dlygate*" $master] || [string match "*__dlymetal*" $master]}]
}
# returns "const" | "other" for the net feeding an endpoint
proc net_class {net depth} {
  if {$depth > 8} { return other }
  set drivers {}
  foreach it [$net getITerms] { if {[$it isOutputSignal]} { lappend drivers $it } }
  foreach bt [$net getBTerms] { if {[$bt getIoType] eq "INPUT"} { return other } }
  if {[llength $drivers] == 0} { return other }
  foreach it $drivers {
    set inst [$it getInst]
    set m [[$inst getMaster] getName]
    if {[string match "*__conb_*" $m]} { continue }
    if {[is_passthru $m]} {
      set ok 1
      foreach in [$inst getITerms] {
        if {[$in isInputSignal]} {
          set n2 [$in getNet]
          if {$n2 eq "NULL" || [net_class $n2 [expr {$depth+1}]] ne "const"} { set ok 0 }
        }
      }
      if {$ok} { continue }
    }
    return other
  }
  return const
}

set fh [open $::env(ALB_UNC_FILE) r]
set names [split [string trim [read $fh]] "\n"]
close $fh
set nconst 0; set nother 0
puts "ALBION_BEGIN unconstrained_classes"
foreach name $names {
  set name [string trim $name]
  if {$name eq ""} { continue }
  set net NULL
  if {[string first "/" $name] >= 0} {
    set idx [string last "/" $name]
    set iname [string range $name 0 [expr {$idx-1}]]
    set pname [string range $name [expr {$idx+1}] end]
    set inst [$block findInst $iname]
    # OpenDB stores hierarchical instance names with escaped brackets (g_bank\[0\]); STA prints them plain
    if {$inst eq "NULL"} { set inst [$block findInst [string map {"[" "\\[" "]" "\\]"} $iname]] }
    if {$inst ne "NULL"} {
      set it [$inst findITerm $pname]
      if {$it ne "NULL"} { set net [$it getNet] }
    }
  } else {
    set bt [$block findBTerm $name]
    if {$bt ne "NULL"} {
      # an output port is constrained by the cell that drives it; its net is what we classify
      set net [$bt getNet]
    }
  }
  if {$net eq "NULL"} { puts "other $name (not found in database)"; incr nother; continue }
  set c [net_class $net 0]
  puts "$c $name"
  if {$c eq "const"} { incr nconst } else { incr nother }
}
puts "ALBION_END unconstrained_classes"
metric unconstrained_const $nconst
metric unconstrained_other $nother
puts "ALBION_DONE classify"
exit
