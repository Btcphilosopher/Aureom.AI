# AlbionSilicon common Tcl helpers (OpenROAD / OpenSTA).  No design knowledge here: everything comes from env.tcl.
source $::env(ALBION_ENV)

proc cfg {k {d ""}} {
  global CFG
  if {[info exists CFG($k)]} { return $CFG($k) }
  return $d
}
proc metric {k v} { puts "ALBION_METRIC $k $v" }
proc section {name body} {
  puts "ALBION_BEGIN $name"
  uplevel 1 $body
  puts "ALBION_END $name"
}
proc fatal {msg} { puts "ERROR: ALBION $msg"; exit 1 }

proc load_lefs {} {
  read_lef [cfg pdk.tech_lef]
  read_lef [cfg pdk.std_lef]
  foreach l [cfg macro.lefs] { read_lef $l }
}
proc load_libs {corner} {
  read_liberty [cfg corner.$corner.lib]
  foreach l [cfg macro.libs.$corner] { read_liberty $l }
}
proc apply_dont_use {} {
  foreach pat [cfg dont_use_patterns] {
    set g [string map {.* *} $pat]
    set cells [get_lib_cells -quiet $g]
    if {[llength $cells] > 0} { set_dont_use $cells }
  }
}
proc source_rc {} { source [cfg pdk.setrc] }

# read_verilog + link
proc load_netlist {} {
  read_verilog [cfg build.synth_netlist]
  link_design [cfg top]
}

# timing summary: machine-readable lines for the Python metric parser
proc timing_summary {label} {
  puts "ALBION_BEGIN timing_$label"
  report_worst_slack -max -digits 4
  report_worst_slack -min -digits 4
  report_tns -digits 4
  report_wns -digits 4
  puts "ALBION_END timing_$label"
  puts "ALBION_BEGIN endpoints_setup_$label"
  report_checks -path_delay max -slack_max 0.0 -group_count 100000 -format end -digits 4
  puts "ALBION_END endpoints_setup_$label"
  puts "ALBION_BEGIN endpoints_hold_$label"
  report_checks -path_delay min -slack_max 0.0 -group_count 100000 -format end -digits 4
  puts "ALBION_END endpoints_hold_$label"
}

proc design_area_summary {label} {
  puts "ALBION_BEGIN area_$label"
  report_design_area
  puts "ALBION_END area_$label"
}

proc um {v} { return [expr {double($v) / [[ord::get_db_block] getDbUnitsPerMicron]}] }
proc dbu {v} { return [expr {int(round($v * [[ord::get_db_block] getDbUnitsPerMicron]))}] }

# macro instances in database (= netlist) order
proc macro_instances {} {
  set out {}
  foreach inst [[ord::get_db_block] getInsts] {
    if {[[$inst getMaster] isBlock]} { lappend out $inst }
  }
  return $out
}
