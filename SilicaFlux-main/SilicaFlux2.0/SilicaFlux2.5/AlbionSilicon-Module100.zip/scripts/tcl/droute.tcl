# Detailed routing (TritonRoute), filler insertion, final database + netlist + DEF outputs.
source $::env(ALBION_TCL_DIR)/common.tcl

load_lefs
load_libs [cfg pdk.default_corner tt]
read_db $::env(ALBION_STAGE_DIR)/../groute/groute.odb
read_sdc [cfg build.sdc]
source_rc
apply_dont_use
set_propagated_clock [all_clocks]

set lo [cfg layers.min_route]
set hi [cfg layers.max_route]
set_routing_layers -signal ${lo}-${hi} -clock [cfg layers.min_clk_route]-${hi}

if {![cfg route.detailed.enabled 1]} { fatal "route.detailed.enabled=0: this stage is the routing milestone" }

detailed_route -output_drc detailed_route_drc.rpt -output_maze maze.log \
  -bottom_routing_layer [cfg route.detailed.bottom_layer met1] -top_routing_layer [cfg route.detailed.top_layer met5] \
  -droute_end_iter [cfg route.detailed.drc_iterations 64] -verbose 1

# metal-layer geometry stays untouched below; fillers only add std-cell filler (NOT foundry metal density fill)
if {[cfg route.fill 1]} {
  filler_placement [cfg cells.fill]
}
section check_placement_final { check_placement -verbose }

# connectivity: every net must be fully connected by the router
section drt_connectivity { catch {check_drc -verbose} }

set block [ord::get_db_block]
set nets 0
set sig_wire 0.0
foreach n [$block getNets] {
  if {[$n getSigType] ne "SIGNAL" && [$n getSigType] ne "CLOCK"} { continue }
  incr nets
}
metric signal_nets $nets

global_connect
write_db droute.odb
write_def final.def
write_verilog -include_pwr_gnd final_pg.v
write_verilog final.v
write_sdc final.sdc
puts "ALBION_DONE droute"
exit
