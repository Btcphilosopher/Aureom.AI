# Clock tree synthesis (TritonCTS) + post-CTS timing repair with PROPAGATED clocks.
source $::env(ALBION_TCL_DIR)/common.tcl

load_lefs
load_libs [cfg pdk.default_corner tt]
read_db $::env(ALBION_STAGE_DIR)/../place/place.odb
read_sdc [cfg build.sdc]
source_rc
apply_dont_use
set_wire_rc -signal -layer [cfg layers.min_route]
set_wire_rc -clock -layer [cfg layers.min_clk_route]
estimate_parasitics -placement

timing_summary pre_cts

set cts_args [list -root_buf [cfg cells.clk_root_buf] -buf_list [cfg cells.clk_bufs]]
if {[cfg cts.sink_clustering 1]} {
  lappend cts_args -sink_clustering_enable -sink_clustering_size [cfg cts.cluster_size 20] -sink_clustering_max_diameter [cfg cts.cluster_diameter_um 50]
}
clock_tree_synthesis {*}$cts_args
set_propagated_clock [all_clocks]
estimate_parasitics -placement
repair_clock_nets
detailed_placement
estimate_parasitics -placement

timing_summary cts_pre_repair
section clock_skew_pre_repair { report_clock_skew }

if {[cfg cts.repair_timing 1]} {
  repair_timing -setup -hold -setup_margin [cfg cts.setup_margin_ns 0.0] -hold_margin [cfg cts.hold_margin_ns 0.05] -repair_tns 100
  detailed_placement
  estimate_parasitics -placement
}
section check_placement { check_placement -verbose }
timing_summary cts
section clock_skew { report_clock_skew }
section drv_cts { report_check_types -max_slew -max_capacitance -max_fanout -violators }
design_area_summary cts

# clock tree structure straight from the database: clock buffers and sinks
set nbuf 0
foreach inst [[ord::get_db_block] getInsts] {
  set n [$inst getName]
  if {[string match "clkbuf_*" $n] || [string match "clkload*" $n]} { incr nbuf }
}
metric clock_tree_instances $nbuf

global_connect
write_db cts.odb
puts "ALBION_DONE cts"
exit
