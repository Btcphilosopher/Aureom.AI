# Pre-layout STA on the synthesized netlist: ideal clock, zero wire load.  Purpose:
#   * prove the SDC loads, every endpoint is constrained or explicitly reported unconstrained
#   * give the pre-layout timing baseline (NOT a performance claim: no wires, no clock tree)
source $::env(ALBION_TCL_DIR)/common.tcl
load_lefs
load_libs [cfg pdk.default_corner tt]
load_netlist
read_sdc [cfg build.sdc]

section check_setup { check_setup -verbose -unconstrained_endpoints -multiple_clock -no_clock -no_input_delay -no_output_delay -loops -generated_clocks }
section unconstrained_paths { report_checks -unconstrained -path_delay max -group_count 1000 -format end }
timing_summary pre
section clock_properties { report_clock_properties }
design_area_summary pre
puts "ALBION_DONE sta_pre"
exit
