# Global routing, congestion report, antenna repair (diode insertion) + incremental re-route, parasitic estimate.
source $::env(ALBION_TCL_DIR)/common.tcl

load_lefs
load_libs [cfg pdk.default_corner tt]
read_db $::env(ALBION_STAGE_DIR)/../cts/cts.odb
read_sdc [cfg build.sdc]
source_rc
apply_dont_use
set_wire_rc -signal -layer [cfg layers.min_route]
set_wire_rc -clock -layer [cfg layers.min_clk_route]
set_propagated_clock [all_clocks]

set lo [cfg layers.min_route]
set hi [cfg layers.max_route]
set_global_routing_layer_adjustment ${lo}-${hi} [cfg route.global.layer_adjustment 0.2]
set_routing_layers -signal ${lo}-${hi} -clock [cfg layers.min_clk_route]-${hi}

# -allow_congestion: a routing failure is MEASURED (overflow is reported and gated), not a crash that hides the data
global_route -guide_file route.guide -congestion_iterations [cfg route.global.congestion_iterations 50] \
  -congestion_report_file congestion.rpt -allow_congestion -verbose

estimate_parasitics -global_routing
timing_summary groute_pre_antenna

if {[cfg route.antenna.repair 1]} {
  # insert diodes where the antenna ratio is exceeded, then re-route only what changed
  repair_antennas [cfg cells.antenna_diode] -iterations 3 -ratio_margin [cfg route.antenna.ratio_margin 10]
  detailed_placement
  global_route -start_incremental -congestion_report_file congestion_incr.rpt -allow_congestion
  global_route -end_incremental -congestion_report_file congestion_final.rpt -allow_congestion -verbose
  estimate_parasitics -global_routing
}
section antenna_groute { check_antennas -verbose }

timing_summary groute
section drv_groute { report_check_types -max_slew -max_capacitance -max_fanout -violators }
design_area_summary groute

global_connect
write_db groute.odb
puts "ALBION_DONE groute"
exit
