# Database-only metrics of the final detail-routed design (no timing engine needed).
#   area breakdown by instance class, instance counts, resizer/CTS inserted cells, net counts, die/core geometry.
source $::env(ALBION_TCL_DIR)/common.tcl
load_lefs
read_db $::env(ALBION_STAGE_DIR)/../droute/droute.odb
set block [ord::get_db_block]
set dbu [$block getDbUnitsPerMicron]
proc cell_area {inst} {
  set m [$inst getMaster]
  set dbu [[ord::get_db_block] getDbUnitsPerMicron]
  return [expr {double([$m getWidth]) * [$m getHeight] / ($dbu * $dbu)}]
}
array set A {std 0.0 tap 0.0 fill 0.0 decap 0.0 macro 0.0 clk 0.0 diode 0.0 buf_io 0.0 hold 0.0 tie 0.0}
array set N {std 0 tap 0 fill 0 decap 0 macro 0 clk 0 diode 0 buf_io 0 hold 0 tie 0 flop 0}
foreach inst [$block getInsts] {
  set name [$inst getName]
  set mname [[$inst getMaster] getName]
  set a [cell_area $inst]
  if {[[$inst getMaster] isBlock]} { set k macro } \
  elseif {[string match "*tapvpwrvgnd*" $mname]} { set k tap } \
  elseif {[string match "*__fill_*" $mname]} { set k fill } \
  elseif {[string match "*__decap_*" $mname]} { set k decap } \
  elseif {[string match "*__diode_*" $mname]} { set k diode } \
  elseif {[string match "*__conb_*" $mname]} { set k tie } \
  elseif {[string match "clkbuf_*" $name] || [string match "clkload*" $name]} { set k clk } \
  elseif {[string match "input*" $name] || [string match "output*" $name]} { set k buf_io } \
  elseif {[string match "hold*" $name]} { set k hold } \
  else { set k std }
  set A($k) [expr {$A($k) + $a}]
  incr N($k)
  if {[string match "*__df*" $mname] || [string match "*__edf*" $mname] || [string match "*__sdf*" $mname]} { incr N(flop) }
}
set core [$block getCoreArea]
set die [$block getDieArea]
set core_um2 [expr {double([$core dx]) * [$core dy] / ($dbu * $dbu)}]
set die_um2 [expr {double([$die dx]) * [$die dy] / ($dbu * $dbu)}]
foreach k [array names A] { metric area_$k [format %.2f $A($k)]; metric count_$k $N($k) }
metric count_flop $N(flop)
metric core_area [format %.2f $core_um2]
metric die_area [format %.2f $die_um2]
metric die_w [format %.3f [expr {double([$die dx]) / $dbu}]]
metric die_h [format %.3f [expr {double([$die dy]) / $dbu}]]
metric core_w [format %.3f [expr {double([$core dx]) / $dbu}]]
metric core_h [format %.3f [expr {double([$core dy]) / $dbu}]]
set nets 0; set clk_nets 0
foreach n [$block getNets] {
  set t [$n getSigType]
  if {$t eq "SIGNAL"} { incr nets } elseif {$t eq "CLOCK"} { incr clk_nets }
}
metric nets_signal $nets
metric nets_clock $clk_nets
metric insts_total [llength [$block getInsts]]
# (wire length / via counts come from TritonRoute's own log: decoding wires in Tcl was too slow and added nothing)
puts "ALBION_DONE metrics"
exit
