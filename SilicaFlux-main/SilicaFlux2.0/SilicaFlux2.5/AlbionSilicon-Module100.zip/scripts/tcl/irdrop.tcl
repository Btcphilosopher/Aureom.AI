# Static IR-drop + EM screen of the power grid (OpenROAD PSM) using VECTORLESS power.
# SCREENING ONLY: not foundry IR/EM signoff (no vector-based power, no package model, no dynamic analysis,
# signal-net EM not analysed).
#
# Two supply assumptions are run and BOTH are reported (the source count PSM prints is recorded as evidence):
#   ideal   : PSM default - an ideal voltage source at every top-metal strap crossing (optimistic bound)
#   corners : four supply points, one near each core corner (ASSUMED pad/bump positions; conservative stand-in)
source $::env(ALBION_TCL_DIR)/common.tcl

load_lefs
load_libs [cfg pdk.default_corner tt]
read_db $::env(ALBION_STAGE_DIR)/../droute/droute.odb
read_sdc [cfg build.sdc]
source_rc
set_propagated_clock [all_clocks]
estimate_parasitics -placement   ;# NOT -global_routing: on a detail-routed DB it has no GRT data, warns "Missing route to pin" and can SEGFAULT (KI-030)
set_power_activity -input -activity [cfg power.activity_default 0.2] -duty 0.5

set vdd [cfg pdk.vdd_net]
set vss [cfg pdk.vss_net]
set volt [cfg pdk.voltage]
foreach {net v} [list $vdd $volt $vss 0.0] { set_pdnsim_net_voltage -net $net -voltage $v }

# explicit supply points: x,y,size_um,voltage  (PSM source-file format; the 4th field is the net voltage)
set block [ord::get_db_block]
set core [$block getCoreArea]
set inset [cfg power.supply_inset_um 30]
set x0 [expr {[um [$core xMin]] + $inset}]; set x1 [expr {[um [$core xMax]] - $inset}]
set y0 [expr {[um [$core yMin]] + $inset}]; set y1 [expr {[um [$core yMax]] - $inset}]
foreach {name v} [list vdd $volt vss 0.0] {
  set fh [open vsrc_$name.csv w]
  foreach {x y} [list $x0 $y0 $x1 $y0 $x0 $y1 $x1 $y1] { puts $fh [format "%.3f,%.3f,10,%s" $x $y $v] }
  close $fh
}

section irdrop_vdd_ideal   { analyze_power_grid -net $vdd -outfile ir_vdd_ideal.rpt   -error_file ir_vdd_ideal_err.rpt }
section irdrop_vss_ideal   { analyze_power_grid -net $vss -outfile ir_vss_ideal.rpt   -error_file ir_vss_ideal_err.rpt }
section irdrop_vdd_corners { analyze_power_grid -net $vdd -vsrc vsrc_vdd.csv -outfile ir_vdd_corners.rpt -error_file ir_vdd_corners_err.rpt }
section irdrop_vss_corners { analyze_power_grid -net $vss -vsrc vsrc_vss.csv -outfile ir_vss_corners.rpt -error_file ir_vss_corners_err.rpt }
# EM screen: peak/average current per PDN segment under the conservative (corner-supplied) case
section em_vdd_corners {
  if {[catch {analyze_power_grid -net $vdd -vsrc vsrc_vdd.csv -enable_em -em_outfile em_vdd.rpt} err]} { puts "EM_UNAVAILABLE: $err" }
}
section pdn_connectivity {
  catch {check_power_grid -net $vdd} a
  puts "VDD connectivity: $a"
  catch {check_power_grid -net $vss} b
  puts "VSS connectivity: $b"
}
puts "ALBION_DONE irdrop"
exit
