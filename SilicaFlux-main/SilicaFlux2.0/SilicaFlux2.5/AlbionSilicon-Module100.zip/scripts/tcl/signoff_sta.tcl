# Post-route parasitic extraction (OpenRCX with the rule files SHIPPED WITH THE PDK) + STA for ONE corner.
# EXPERIMENTAL: open-source extraction + open-source STA; not a foundry signoff flow.
source $::env(ALBION_TCL_DIR)/common.tcl
set corner $::env(ALBION_CORNER)

load_lefs
load_libs $corner
read_db $::env(ALBION_STAGE_DIR)/../droute/droute.odb
read_sdc [cfg build.sdc]
source_rc
set_propagated_clock [all_clocks]

# ---------------------------------------------------------------- parasitic extraction
set rcx_file [cfg rcx.[cfg corner.$corner.rc]]
define_process_corner -ext_model_index 0 X
extract_parasitics -ext_model_file $rcx_file
write_spef signoff_${corner}.spef
read_spef signoff_${corner}.spef
metric rcx_rules [file tail $rcx_file]

# ---------------------------------------------------------------- timing
timing_summary $corner
section check_setup_$corner { check_setup -verbose -unconstrained_endpoints -multiple_clock -no_clock -no_input_delay -no_output_delay -loops -generated_clocks }
section unconstrained_$corner { report_checks -unconstrained -path_delay max -group_count 1000 -format end }
section worst_setup_paths_$corner { report_checks -path_delay max -format full_clock_expanded -group_count 3 -digits 3 -fields {slew cap input_pins fanout} }
section worst_hold_paths_$corner { report_checks -path_delay min -format full_clock_expanded -group_count 3 -digits 3 }
section drv_$corner { report_check_types -max_slew -max_capacitance -max_fanout -violators }
section skew_$corner { report_clock_skew }
section area_$corner { report_design_area }

# ---------------------------------------------------------------- power (VECTORLESS: assumed activity, NOT measured)
set_power_activity -input -activity [cfg power.activity_default 0.2] -duty 0.5
section power_$corner { report_power }

puts "ALBION_DONE signoff_sta_$corner"
exit
