# Placement: global placement (pins skipped) -> I/O pin placement -> global placement (routability + timing driven)
#            -> port buffering + design repair -> detailed placement -> legality check.
source $::env(ALBION_TCL_DIR)/common.tcl
source [cfg build.plan_tcl]

load_lefs
load_libs [cfg pdk.default_corner tt]
read_db $::env(ALBION_STAGE_DIR)/../floorplan/floorplan.odb
read_sdc [cfg build.sdc]
source_rc
apply_dont_use
set_wire_rc -signal -layer [cfg layers.min_route]
set_wire_rc -clock -layer [cfg layers.min_clk_route]

set dens [cfg place.density 0.55]
# Global placement aborts (GPL-0302) if the target density is below what the floorplan needs (utilisation + tap cells).  Keep the
# configured density unless utilisation demands more: effective = max(configured, utilisation + 0.10), capped at 0.95.
set min_dens [expr {min(0.95, [cfg floorplan.utilization 0.4] + 0.10)}]
if {$dens < $min_dens} { puts "ALBION_NOTE place density raised from $dens to $min_dens (utilisation [cfg floorplan.utilization])"; set dens $min_dens }
metric place_density_effective $dens
set gpl_flags {}
if {[cfg place.routability_driven 1]} { lappend gpl_flags -routability_driven }
if {[cfg place.timing_driven 1]} { lappend gpl_flags -timing_driven }

# ---- 1. global placement without I/O, so pins can be placed against real cell positions
global_placement -skip_io -density $dens

# ---- 2. I/O pin placement from the planned edge assignment
set edge_region [dict create west left east right north top south bottom]
foreach edge {west east north south} {
  set pins $PLAN(pins_$edge)
  if {[llength $pins] > 0} {
    set_io_pin_constraint -pin_names $pins -region "[dict get $edge_region $edge]:*"
  }
}
set pin_args [list -hor_layers [cfg layers.io_hor] -ver_layers [cfg layers.io_ver]]
if {[cfg floorplan.io.min_distance_um] ne ""} { lappend pin_args -min_distance [cfg floorplan.io.min_distance_um] -min_distance_in_tracks 0 }
place_pins {*}$pin_args

# ---- 3. final global placement
global_placement {*}$gpl_flags -density $dens

# ---- 4. port buffering, repair (slew / cap / fanout), detailed placement
estimate_parasitics -placement
buffer_ports
if {[cfg place.repair_design 1]} { repair_design }
detailed_placement
estimate_parasitics -placement

section check_placement { check_placement -verbose }
timing_summary place
section drv_place { report_check_types -max_slew -max_capacitance -max_fanout -violators }
design_area_summary place
section floating_nets { report_floating_nets }
set pins_placed 0
set pins_total 0
foreach bt [[ord::get_db_block] getBTerms] {
  # power/ground terminals are added by the PDN generator; only SIGNAL terminals are design I/O
  if {[$bt getSigType] ne "SIGNAL"} { continue }
  incr pins_total
  set st [$bt getFirstPinPlacementStatus]
  if {$st eq "PLACED" || $st eq "FIRM"} { incr pins_placed }
}
metric io_pins_total $pins_total
metric io_pins_placed $pins_placed
set n 0
foreach inst [[ord::get_db_block] getInsts] { if {[$inst getPlacementStatus] eq "UNPLACED"} { incr n } }
metric unplaced_instances $n

global_connect
write_db place.odb
puts "ALBION_DONE place"
exit
