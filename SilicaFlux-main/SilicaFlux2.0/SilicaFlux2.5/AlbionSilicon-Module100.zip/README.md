# AlbionSilicon — SilicaFlux Module 100: ASIC physical-implementation pipeline

**A reproducible, gated RTL-to-GDSII experiment on a real (open) PDK for two *verified* SilicaFlux subsystems, with every number traceable to a tool run and every gap written down.**

> ### Status in one paragraph
> Two small, verified SilicaFlux subsystems were taken **through every physical-design stage** with real SkyWater sky130 technology data:
> synthesis → gate-level check → SDC → floorplan → placement → CTS → global & detailed routing (0 router violations) → OpenRCX extraction → STA →
> antenna / IR-drop / EM-screen → DRC (two engines) → LVS. One of them uses a **real OpenRAM SRAM macro** (LEF + Liberty + GDS + vendor model).
> Design A passes the repository's *experimental* gate tier; **Design B fails it** (9 antenna violations remain after detailed routing, KI-016), and two sweep
> points (macro on the east edge; a flop-array memory experiment) did not finish detailed routing (KI-033). Results that are not clean are listed, not hidden.
> **Neither is tapeout ready**: the PDK is an open educational-class kit, the DRC/LVS/EM/IR tools are community/open (not foundry signoff), and
> there is no DFT, I/O ring, clock/PLL IP, package, or foundry signoff. See [`docs/11_PRODUCTION_READINESS.md`](docs/11_PRODUCTION_READINESS.md).

## Headline results (generated from `reports/`; do not edit by hand)

<!-- HEADLINE:BEGIN -->
| | Design A | Design B |
|---|---|---|
| stages passed (excl. the report stage that writes this table) | 18/18 | 18/18 |
| source verification (RTL / gate-level) | True / True | True / True |
| std-cell area (µm²) / cells / flops | 23939 / 3263 / 276 | 15313 / 1677 / 322 |
| SRAM macros | 0 | 1 |
| die (µm) | 285.2 × 288.3 | 638.5 × 560.3 |
| clock target (ns) | 10.0 | 20.0 |
| tt setup / hold worst slack (ns) | 1.5737 / 0.1042 | 1.7424 / 0.2018 |
| tt min period, derived (ns) | 8.4263 | 18.2576 |
| ss setup worst slack (ns) | -6.9038 | not run (no macro Liberty) |
| power at tt, vectorless (mW) | 11.20 | 3.83 |
| global-route usage % / overflow | 18.92 / 0 | 11.59 / 0 |
| detailed-route violations | 0 | 0 |
| DRC Magic: outside / inside macro | 0 / 0 | 0 / 2832369 |
| DRC KLayout (FEOL implant rules in library cells) | 27 | 31 |
| LVS (open deck) | match | match |
| antenna net violations | 0 | 9 |
| tapeout ready | False | False |
<!-- HEADLINE:END -->

Full tables, per-stage timing, per-layer routing, DRC attribution and all sweeps: [`docs/RESULTS.md`](docs/RESULTS.md). Things that **did not** come out clean are in
[`docs/KNOWN_ISSUES.md`](docs/KNOWN_ISSUES.md) — read it before quoting any number.

## What was selected and why

| | source | role |
|---|---|---|
| **Design A** `albion_pe_mesh` | SilicaFlux TensorCore-01 `tensor_pe_mesh` (INT8 MAC mesh) | smallest verified compute subsystem; lane count = ROWS×COLS |
| **Design B** `albion_spm` | SilicaFlux-HPC M04 `hpc_scratchpad` + sramlib → **real OpenRAM sky130 macro** | smallest verified memory subsystem with a real-macro path |

Not chosen: a processor, the FP32 lanes/tile, ALBION_MIN, the P40 "floorplan build" (whose scripts/results are absent from its archive). Measured sizes and
the re-run verification of every candidate: [`docs/01_SOURCE_SELECTION.md`](docs/01_SOURCE_SELECTION.md).

## Quick start

```bash
cd physical/albion
make albion-install-tools albion-fetch-pdk albion-pdk-check   # tools + hash-verified technology data
make albion-test-unit                                          # no tools needed
make albion-all                                                # both designs, every stage (~35 min, 4 cores) → docs/RESULTS.md
make albion-sweeps                                             # controlled parameter sweeps (several hours on 4 cores; 4×4 lanes ~1 h, east-macro router 46 min)
make albion-test                                               # unit + instrument + result-property tests
make albion-gates DESIGN=pe_mesh                               # experimental gates: passes (3 ss-corner warnings)
make albion-gates DESIGN=spm                                   # experimental gates: FAILS on antenna (9 nets, KI-016) - by design, see KNOWN_ISSUES
make albion-tapeout-gate                                       # MUST fail on an open PDK (exit code is inverted)
```

## Layout

```
config/pdk/        sky130hd.yaml (real, open, hash-pinned) · commercial_template.yaml (all null: pdk-check FAILS by design)
config/designs/    pe_mesh.yaml · spm.yaml          config/sweeps/   pe_mesh_sweep.yaml · spm_sweep.yaml     config/defaults.yaml
vendor/            the verified SilicaFlux sources actually used (unmodified, upstream hashes kept)
scripts/albion/    pipeline: pdk · config · synth · sdc · plan · simgate · verify · report · gates · sweep · audit · docgen
scripts/tcl|magic  OpenROAD / Magic stage scripts (no design knowledge: all numbers come from env.tcl / plan.tcl)
constraints/ floorplan/   generated SDC and floorplan plans of the baselines        results/  curated per-run artefacts
reports/           summary.{json,md} per run · sweeps/ · audit/                      docs/     the numbered documents below
tests/             unit · pdk · instrument self-tests · result-property tests       .github/  CI workflow (file only; not pushed)
```

## Brief → where it is met

| brief § | deliverable |
|---|---|
| 1 source selection | [`01_SOURCE_SELECTION`](docs/01_SOURCE_SELECTION.md), `reports/audit/` |
| 2 technology configuration | [`02_PDK_FRAMEWORK`](docs/02_PDK_FRAMEWORK.md), `config/pdk/` |
| 3 synthesis | [`03_SYNTHESIS`](docs/03_SYNTHESIS.md) |
| 4 timing constraints | [`04_TIMING_CONSTRAINTS`](docs/04_TIMING_CONSTRAINTS.md), `constraints/` |
| 5 SRAM macro integration | [`05_SRAM_MACRO_INTEGRATION`](docs/05_SRAM_MACRO_INTEGRATION.md) |
| 6 floorplanning | [`06_FLOORPLAN`](docs/06_FLOORPLAN.md), `floorplan/` |
| 7 physical implementation | [`07_PHYSICAL_IMPLEMENTATION`](docs/07_PHYSICAL_IMPLEMENTATION.md) |
| 8 physical verification | [`08_PHYSICAL_VERIFICATION`](docs/08_PHYSICAL_VERIFICATION.md) |
| 9 reports | [`09_REPORTS`](docs/09_REPORTS.md), [`RESULTS`](docs/RESULTS.md) |
| 10 design experiments | [`10_DESIGN_EXPERIMENTS`](docs/10_DESIGN_EXPERIMENTS.md), `reports/sweeps/` |
| 11 production readiness | [`11_PRODUCTION_READINESS`](docs/11_PRODUCTION_READINESS.md), [`ASIC_READINESS_CHECKLIST`](docs/ASIC_READINESS_CHECKLIST.md) |
| 12 deliverables | scripts · PDK framework · SDC · floorplan config · CI gates (`.github/`, `make albion-gates`) · reports · [`KNOWN_ISSUES`](docs/KNOWN_ISSUES.md) · checklist |

## How claims are kept honest

* **Every stage can refuse to run** (prerequisite state) and **every checker can fail**: DRC engines are shown to flag a planted violation, the GLS
  testbench a stuck-at fault, LVS a deleted cell, the STA a missing constraint, the legality checker an illegal plan — each is a test.
* **False passes found and fixed by that discipline:** an empty 126-byte GDS reported OK; a KLayout deck that silently ran no rules; a planner that
  placed a macro one site past its halo; tap cells with unconnected power; a fake "bump" IR case identical to the default. See `KNOWN_ISSUES.md`.
* **Labels travel with numbers:** open-PDK / vectorless / flop-memory-experiment labels are stamped into the report JSON and Markdown.
* **Nothing is described as tapeout ready**; `albion gates --tier tapeout` fails by construction and prints why.
