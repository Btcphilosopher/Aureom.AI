# =============================================================================
# AlbionSilicon generated SDC   design=albion_pe_mesh variant=lanes_1x1 config_sha256=4f31cf93ba11
# DO NOT EDIT: regenerate with `albion sdc`.  Units: ns, pF.
# =============================================================================
set clk_period 10.0000
create_clock -name core_clk -period $clk_period -waveform {0.0 5.0000} [get_ports clk_i]
set_clock_uncertainty -setup 0.2500 [get_clocks core_clk]
set_clock_uncertainty -hold  0.1000 [get_clocks core_clk]
# ideal-clock attributes: applied only before CTS (post-CTS the clock is propagated and these are ignored)
set_clock_latency 0.0000 [get_clocks core_clk]
set_clock_transition 0.1500 [get_clocks core_clk]

# ---- external timing budget (fractions of the clock period)
set in_max  3.0000   ;# input_delay_frac=0.3
set in_min  0.5000   ;# input_min_delay_frac=0.05
set out_max 3.0000   ;# output_delay_frac=0.3
set out_min 0.0000   ;# output_min_delay_frac=0.0
set data_inputs [get_ports {rst_ni enable_i west_a_i[*] west_valid_i west_clear_i north_b_i[*]}]   ;# every input except the clock (explicit list: portable across STA tools)
set_input_delay  -clock core_clk -max $in_max  $data_inputs
set_input_delay  -clock core_clk -min $in_min  $data_inputs
set_output_delay -clock core_clk -max $out_max [all_outputs]
set_output_delay -clock core_clk -min $out_min [all_outputs]
set_driving_cell -lib_cell sky130_fd_sc_hd__buf_4 -pin X $data_inputs
set_load 0.0200 [all_outputs]
set_max_transition 1.5000 [current_design]

# ---- timing exceptions: 0
# NONE.  No false path or multicycle path was identified that can be justified for this design.
# (Reset is asynchronous-assert / synchronous-release by contract, so recovery/removal stay checked.)
