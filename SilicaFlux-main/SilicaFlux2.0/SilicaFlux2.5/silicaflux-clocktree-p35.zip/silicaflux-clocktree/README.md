# SilicaFlux CLOCKTREE — Project 35: chip-wide clock and reset architecture

**Primary RTL: [`rtl/silicaflux_clock_reset_tree.sv`](rtl/silicaflux_clock_reset_tree.sv)** · Aureom.AI | SilicaFlux-HPC

The SystemVerilog here implements clock / reset **control**: reset synchronisation and sequencing,
clock-domain-ready monitoring, safe clock enables, watchdog and software resets, and CDC adapters. The
**physical** clock distribution (buffers, skew, routing) is produced by clock-tree synthesis. For that,
this project delivers the constraints (SDC) and an OpenROAD CTS configuration for the real IHP SG13G2
and SKY130HD libraries. **No clock-tree closure is claimed.**

## Status

| Deliverable | Status | Evidence |
|---|---|---|
| Audit of clocks, PLL, resets, enables, CDC, TimingFlow, FloorplanLab, gating, power management | done, 9 findings | [docs/00_AUDIT.md](docs/00_AUDIT.md) |
| Clock-domain table (baseline + research) | done | [docs/01_CLOCK_DOMAINS.md](docs/01_CLOCK_DOMAINS.md) |
| `silicaflux_clock_reset_tree.sv` + sequencer, monitors, watchdog, cause log, registers | done; lint-clean (Verilator `-Wall`, 15 targets) | [reports/lint.md](reports/lint.md) |
| Reset synchronisers, reset-domain isolation, reset-combine / DFT cells | done | [docs/02_RESET_DOMAINS.md](docs/02_RESET_DOMAINS.md) |
| Clock-gating wrappers: ASIC ICG (IHP / SKY130), Xilinx BUFGCE, ECP5 DCCA, enable-only | done; mapped by Yosys for all 4 targets | [docs/03_CLOCK_GATING.md](docs/03_CLOCK_GATING.md), [reports/synth/SYNTHESIS.md](reports/synth/SYNTHESIS.md) |
| CDC adapters (status, Gray, commands, wide data, DMA FIFO, reset, interrupts) + crossing inventory | done; structural check 0 FAIL, all waivers evidenced, checker proven by 8 negative tests | [docs/04_CDC.md](docs/04_CDC.md), [reports/cdc/](reports/cdc/) |
| SDC (functional pre / post-CTS, test, die template) | done; generated from one YAML; Tcl dry-run clean | [docs/05_SDC.md](docs/05_SDC.md), [constraints/sdc/](constraints/sdc/) |
| OpenROAD CTS configuration and flow (IHP SG13G2, SKY130HD) | prepared and pre-checked against LEF / Liberty / netlist; **not run** (OpenROAD unavailable here) | [docs/06_CTS.md](docs/06_CTS.md), [reports/cts/CTS_PRECHECK.md](reports/cts/CTS_PRECHECK.md) |
| Verification (12 system tests + CDC library tests, 2 simulators, 6 builds, 3 seeds) | **492 / 492 runs pass** (116 815 self-checks); 16 / 16 mutants killed | [docs/07_VERIFICATION.md](docs/07_VERIFICATION.md) |
| Timing / CDC / RDC analysis report | done with the tools available: in-house NLDM checker (indicative), **OpenSTA not run** | [docs/08_TIMING_ANALYSIS.md](docs/08_TIMING_ANALYSIS.md) |
| Limitations and blocked items | — | [docs/09_LIMITATIONS.md](docs/09_LIMITATIONS.md) |

## Architecture in one paragraph

The baseline has **one functional clock** (`clk_core`, the PLL output) plus the **reference clock**
(`clk_ref`, the crystal that also feeds the PLL). `clk_ref` is required because it is the only clock that
exists before lock and the only one that can see `clk_core` stop. A sequencer on `clk_ref` waits for PLL
lock **and** a frequency-qualified core clock. It then opens a glitch-free root ICG and releases the
fabric → ControlCore → accelerator branches (each branch's gated clock is forced on for its release),
every step acknowledged from the target domain. Every reset asserts asynchronously from a single flop and
releases synchronously in its own clock. In RUN it handles clock / PLL loss (asynchronous assertion with
the clock stopped, automatic recovery), a two-stage system watchdog on `clk_ref`, block-watchdog requests,
and keyed software resets with four scopes and an optional graceful drain. Causes are logged in a POR-only
domain. The research configuration adds the memory-controller clock `clk_mc` (DieTop `EXTMEM_ASYNC = 1`).
No PCIe clock is created: there is no endpoint IP or PHY.

## Results at a glance

* **Synthesis** (Yosys 0.33, IHP SG13G2 typ): baseline 2 457 cells / 781 flip-flops / 2 ICG / 0 latches;
  research 3 118 cells / 982 flip-flops / 3 ICG. Xilinx: 2 × BUFGCE; ECP5: 2 × DCCA; enable-only: 0 ICG.
  A build without a clock-gating target is **refused**.
* **Timing check** (`sf_sta`, indicative): 0 violations and 0 unconstrained endpoints at typ / slow / fast
  in functional and test modes. Critical path is the combinational register-bus read, +1.88 ns at slow;
  −0.06 ns with a pessimistic wire-load sensitivity (sizing issue, see the limitations).
* **CDC / RDC**: 0 FAIL in both configurations; 31 / 34 reset-domain crossings, all isolated.
* **Verification**: 492 / 492 runs pass on Icarus 12 and Verilator 5.020 (core/reference ratios 0.32×–7.7×,
  random metastability model). The regression found and fixed **3 real RTL bugs** (MC release ordering, partial-window
  clock qualification, saturating-counter wrap). Mutation analysis: 16 / 16 injected clock / reset defects
  detected.

## Quick start

```
make lint                  # Verilator -Wall, every configuration
make sim TEST=clk_loss     # one system test (Icarus)
make regress               # full regression: Icarus + Verilator, 6 builds, 3 seeds
make synth cdc sta         # Yosys mapping, structural CDC/RDC, timing check (all corners)
make cts-precheck tcl-dryrun
make mutate                # mutation analysis
make cts                   # OpenROAD block flow with CTS   (needs openroad)
make sta-opensta           # OpenSTA multi-corner run       (needs sta)
```
Requires Icarus Verilog 12, Verilator 5.x, Yosys 0.33, Python 3.12+ with PyYAML, and tclsh. The IHP SG13G2
collateral is vendored in `third_party/ihp-sg13g2` (Apache-2.0, provenance and SHA-256 included). SKY130HD:
`scripts/fetch_pdk.sh`.

## Layout

| Path | Contents |
|---|---|
| `rtl/` | `silicaflux_clock_reset_tree.sv` (top), `sf_crt_seq` (sequencer), `sf_crt_clk_mon`, `sf_crt_wdog`, `sf_crt_cause_log`, `sf_crt_branch_gate`, `sf_crt_regs`, `sf_crt_pkg`; `cdc/` CDC + reset library; `clk/` clock-gate wrapper; `tech/{sim,ihp_sg13g2,sky130hd,fpga}` cell mappings; `files.f` |
| `tb/` | `tb_crt_top.sv` (12 system tests + continuous checkers), `tb_models.sv` (DMA, compute branch, glitch / release checkers), `tb_cdc_lib.sv` |
| `config/` | `clock_spec.yaml` (single source for SDC / STA / CTS), `cdc_waivers.yaml` |
| `constraints/` | `gen_sdc.py`, `sdc/*.sdc`, `json/*.json` |
| `cts/` | `gen_cts_config.py`, `cts_config_<tech>.tcl`, `run_block_cts.tcl`, `report_cts_groups.tcl`, `pdn_block_*.tcl`, `sta_signoff.tcl` |
| `scripts/` | `regress.py`, `synth.py`, `cdc_check.py`, `cdc_negative.py`, `sf_sta.py`, `run_sta.py`, `cts_precheck.py`, `tcl_dryrun.tcl`, `mutate.py`, `lint.sh`, `fetch_pdk.sh`, `sfa/` (Liberty + netlist library) |
| `tests/cdc_negative/` | checker negative tests |
| `integration/` | DieTop P31 integration guide |
| `reports/` | regression, lint, synthesis, CDC, timing, CTS pre-check, Tcl dry run, mutation |
| `docs/` | 00 audit … 09 limitations, register map |

## Read before integrating

* **OpenSTA and OpenROAD were not run.** The environment refused both a prebuilt package and a source
  build. All timing figures come from the in-house checker and are indicative. Run `make sta-opensta`
  and `make cts` before relying on them.
* **Periods are requirements, not frequency claims.** IO budgets are 30 % block budgets.
* A new die pin, `clk_ref_i`, is needed (`integration/P31_INTEGRATION.md`).
