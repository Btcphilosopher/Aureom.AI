// =============================================================================
// SilicaFlux CLOCKTREE :: clock-domain-ready monitor
//
//   sf_crt_clk_mon_src  (in the MONITORED clock, reset by its own synchroniser
//                        of the reference POR): an 8-bit Gray counter that
//                        advances once per monitored edge (one bit changes per
//                        edge; registered output, glitch-free).
//   sf_crt_clk_mon      (in clk_ref): synchronises the Gray code (bus-coherent
//                        synchroniser, skew bounded by set_max_delay), converts
//                        to binary, accumulates the edge count over WINDOW ref
//                        cycles and flags the clock OK when the count lies in
//                        [CNT_MIN, CNT_MAX].
//
// A stopped clock gives count 0 (< CNT_MIN = 1 by default); a clock running at
// the wrong frequency (e.g. a PLL locked to a wrong multiplier, a VCO running
// away before lock) falls outside the window when the integrator programs
// realistic bounds.  OK requires OK_WINDOWS consecutive in-range windows: the
// first window after a clock starts is only partially counted and can land
// inside the range by accident (found by the clk_start regression, Verilator
// seed 3); a single out-of-range window clears OK immediately.  Limits: f_mon / f_ref must stay below 127 (8-bit Gray
// delta per ref cycle) -- e.g. f_ref = 25 MHz covers f_mon < 3.1 GHz.
// Detection latency of a stop: <= 2 windows + 3 ref cycles.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_clk_mon_src (
  input  wire logic       clk_i,
  input  wire logic       rst_ni,
  output logic [7:0]      gray_o
);
  logic [7:0] bin_q, gray_q;
  wire  [7:0] bin_n = bin_q + 8'd1;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      bin_q  <= '0;
      gray_q <= '0;
    end else begin
      bin_q  <= bin_n;
      gray_q <= bin_n ^ (bin_n >> 1);
    end
  end
  assign gray_o = gray_q;
endmodule

module sf_crt_clk_mon #(
  parameter int          WINDOW  = 16,          // ref cycles per measurement window
  parameter int          STAGES  = 2,
  parameter logic [15:0] CNT_MIN = 16'd1,
  parameter logic [15:0] CNT_MAX = 16'hFFFF,
  parameter int          OK_WINDOWS = 2             // consecutive in-range windows before OK
) (
  input  wire logic        clk_ref_i,
  input  wire logic        rst_ni,
  input  wire logic [7:0]  gray_i,        // from sf_crt_clk_mon_src (asynchronous)
  output logic             ok_o,
  output logic [15:0]      meas_o
);
  localparam int            WW    = $clog2(WINDOW + 1);
  localparam logic [WW-1:0] WLAST = WW'(WINDOW - 1);

  logic [7:0] gray_s;
  sf_crt_sync #(.WIDTH(8), .STAGES(STAGES), .GRAY(1'b1)) u_gsync (
    .clk_i(clk_ref_i), .rst_ni, .d_i(gray_i), .q_o(gray_s));

  logic [7:0] bin_s;
  always_comb begin
    for (int i = 0; i < 8; i++) bin_s[i] = ^(gray_s >> i);   // Gray -> binary
  end

  logic [7:0]    prev_q;
  logic [15:0]   acc_q;
  logic [WW-1:0] win_q;
  logic [3:0]    good_q;                  // consecutive in-range windows (saturating)
  localparam logic [3:0] GOOD_N = 4'(OK_WINDOWS);
  wire           in_range;
  wire  [7:0]    delta = bin_s - prev_q;
  wire  [15:0]   acc_n = acc_q + {8'd0, delta};
  /* verilator lint_off CMPCONST */
  assign in_range = (acc_n >= CNT_MIN) && (acc_n <= CNT_MAX);
  /* verilator lint_on CMPCONST */

  always_ff @(posedge clk_ref_i or negedge rst_ni) begin
    if (!rst_ni) begin
      prev_q <= '0;
      acc_q  <= '0;
      win_q  <= '0;
      ok_o   <= 1'b0;
      meas_o <= '0;
      good_q <= '0;
    end else begin
      prev_q <= bin_s;
      if (win_q == WLAST) begin
        win_q  <= '0;
        acc_q  <= '0;
        meas_o <= acc_n;
        if (in_range) begin
          if (good_q != 4'hF) good_q <= good_q + 4'd1;
          // compare before incrementing: no 4-bit wrap once good_q saturates
          // (regression finding: ok dropped after 15 windows with `good_q + 1`)
          ok_o <= (good_q >= GOOD_N - 4'd1);
        end else begin
          good_q <= '0;
          ok_o   <= 1'b0;
        end
      end else begin
        win_q  <= win_q + 1'b1;
        acc_q  <= (acc_n < acc_q) ? 16'hFFFF : acc_n;   // saturate
      end
    end
  end
endmodule

`default_nettype wire
