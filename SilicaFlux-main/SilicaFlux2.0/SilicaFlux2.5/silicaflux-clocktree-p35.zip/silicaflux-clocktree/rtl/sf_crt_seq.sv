// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_seq -- chip reset / clock-start sequencer
// (clk_ref domain, reset by the POR+EXT reference reset)
//
// Every output is a FLOP: the reset requests drive the asynchronous inputs of
// the per-domain reset synchronisers (glitch-free by construction) and every
// other output crosses into another clock domain.  All inputs are already
// synchronised into clk_ref.  Acknowledges make the sequence independent of
// the core / reference frequency ratio: no step assumes a cycle count in a
// foreign clock.
//
//  OFF -> WAIT_CLK : PLL lock AND core clock OK for STABLE_CYC consecutive ref
//                    cycles  -> open the root clock gate
//  ROOT_ON         : wait for the gate-enable acknowledge, then PRE_REL_CYC
//                    cycles of running clock with every domain still in reset
//  REL_FAB         : release fabric (NoC, SRAM, DMA, die registers, this
//                    block's register file); ack + FAB_DELAY
//  REL_CC          : release the ControlCore; ack + CC_DELAY
//  REL_ACC         : for every accelerator branch still in reset: force its
//                    gated clock on, wait for the force ack, release, wait for
//                    the release ack, drop the force
//  RUN             : monitors clock / PLL loss, watchdog, block watchdogs and
//                    software reset commands
//  QUIESCE         : graceful software reset: ask the affected domains to
//                    drain (quiesce_req); continue on all idle-acks or after
//                    QTIMEOUT cycles (sticky qtimeout flag)
//  ASSERT          : assert the affected domain resets (asynchronously in the
//                    target domain), hold >= HOLD_CYC and until every affected
//                    domain acknowledges "in reset", then re-enter the release
//                    chain at the first affected stage
//  CLK_LOST        : core clock or PLL lock lost: every core-side reset is
//                    asserted asynchronously (no core clock needed), the root
//                    gate is closed; wait until every acknowledge has cleared,
//                    then back to WAIT_CLK (automatic recovery)
//
// Memory-controller domain (MC_EN = 1): an independent 3-state FSM.  It is
// held off while the fabric is in reset, released once the fabric domain has
// acknowledged its release and clk_mc has been OK for STABLE_CYC cycles, and taken back to OFF on mc clock
// loss (cause MC_CLK_LOSS) or a software MEMCTL reset.  An absent mc clock
// never blocks the core sequence.
//
// Priority when several requests coincide (all of them are logged in evt_o):
//   PLL/clock loss > system watchdog > block watchdog > software command.
// Software commands are accepted only in RUN; otherwise they are dropped and
// cmd_drop_o (sticky) is set.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_seq #(
  parameter int NB          = 1,
  parameter bit MC_EN       = 1'b0,
  parameter int STABLE_CYC  = 8,
  parameter int PRE_REL_CYC = 4,
  parameter int FAB_DELAY   = 4,
  parameter int CC_DELAY    = 4,
  parameter int HOLD_CYC    = 4,
  parameter int QTIMEOUT    = 1024
) (
  input  wire logic          clk_i,
  input  wire logic          rst_ni,
  // synchronised status
  input  wire logic          pll_locked_i,
  input  wire logic          core_ok_i,
  input  wire logic          mc_ok_i,
  // synchronised acknowledges (1 = released / enabled)
  input  wire logic          root_ack_i,
  input  wire logic          fab_ack_i,
  input  wire logic          cc_ack_i,
  input  wire logic [NB-1:0] br_ack_i,
  input  wire logic [NB-1:0] force_ack_i,
  input  wire logic          mc_ack_i,
  input  wire logic          fab_qack_i,
  input  wire logic [NB-1:0] br_qack_i,
  // reset requests (already in this reset domain via sf_crt_rdc_sync)
  input  wire logic          wdog_expire_i,
  input  wire logic          ext_wdog_i,
  input  wire logic          cmd_valid_i,
  input  wire logic [1:0]    cmd_scope_i,
  input  wire logic [NB-1:0] cmd_mask_i,
  input  wire logic          cmd_force_i,
  // controls (all registered)
  output logic               root_en_o,
  output logic               fab_rst_no,
  output logic               cc_rst_no,
  output logic [NB-1:0]      br_rst_no,
  output logic [NB-1:0]      br_force_o,
  output logic               mc_rst_no,
  output logic               fab_qreq_o,
  output logic [NB-1:0]      br_qreq_o,
  // status
  output logic [3:0]         state_o,
  output logic [1:0]         mc_state_o,
  output logic               run_o,
  output logic               mc_run_o,
  output logic [15:0]        evt_o,
  output logic               boot_o,
  output logic               qtimeout_o,
  output logic               cmd_drop_o
);
  localparam logic [15:0] M_CLK  = 16'd1 << sf_crt_pkg::CAUSE_CLK_LOSS;
  localparam logic [15:0] M_PLL  = 16'd1 << sf_crt_pkg::CAUSE_PLL_LOSS;
  localparam logic [15:0] M_WDG  = 16'd1 << sf_crt_pkg::CAUSE_WDOG;
  localparam logic [15:0] M_XWDG = 16'd1 << sf_crt_pkg::CAUSE_EXT_WDOG;
  localparam logic [15:0] M_SSYS = 16'd1 << sf_crt_pkg::CAUSE_SW_SYS;
  localparam logic [15:0] M_SCC  = 16'd1 << sf_crt_pkg::CAUSE_SW_CC;
  localparam logic [15:0] M_SACC = 16'd1 << sf_crt_pkg::CAUSE_SW_ACC;
  localparam logic [15:0] M_SMC  = 16'd1 << sf_crt_pkg::CAUSE_SW_MC;
  localparam logic [15:0] M_MCLK = 16'd1 << sf_crt_pkg::CAUSE_MC_CLK_LOSS;

  localparam logic [15:0] C_STABLE = 16'(STABLE_CYC);
  localparam logic [15:0] C_PRE    = 16'(PRE_REL_CYC);
  localparam logic [15:0] C_FAB    = 16'(FAB_DELAY);
  localparam logic [15:0] C_CC     = 16'(CC_DELAY);
  localparam logic [15:0] C_HOLD   = 16'(HOLD_CYC);
  localparam logic [15:0] C_QTO    = 16'(QTIMEOUT);

  logic [3:0]    st_q;
  logic [15:0]   cnt_q;
  logic          ph_q;                 // REL_ACC phase: 0 force, 1 release
  logic          sc_fab_q, sc_cc_q;    // domains affected by the current reset
  logic [NB-1:0] sc_br_q;
  logic          mc_sw_q;              // one-cycle request to the MC FSM
  logic [15:0]   evt_main, evt_mc;

  // ------------------------------------------------------------ main FSM
  wire           lost      = !pll_locked_i || !core_ok_i;
  wire  [15:0]   lost_m    = (!pll_locked_i ? M_PLL : 16'd0) | (!core_ok_i ? M_CLK : 16'd0);
  wire  [NB-1:0] cmd_br    = (cmd_mask_i == '0) ? {NB{1'b1}} : cmd_mask_i;
  wire           acks_clear = !root_ack_i && !fab_ack_i && !cc_ack_i && (br_ack_i == '0) && (force_ack_i == '0);
  wire           cnt_sat   = (cnt_q == 16'hFFFF);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q       <= sf_crt_pkg::ST_OFF;
      cnt_q      <= '0;
      ph_q       <= 1'b0;
      sc_fab_q   <= 1'b0;
      sc_cc_q    <= 1'b0;
      sc_br_q    <= '0;
      root_en_o  <= 1'b0;
      fab_rst_no <= 1'b0;
      cc_rst_no  <= 1'b0;
      br_rst_no  <= '0;
      br_force_o <= '0;
      fab_qreq_o <= 1'b0;
      br_qreq_o  <= '0;
      run_o      <= 1'b0;
      boot_o     <= 1'b0;
      evt_main   <= '0;
      qtimeout_o <= 1'b0;
      cmd_drop_o <= 1'b0;
      mc_sw_q    <= 1'b0;
    end else begin
      boot_o   <= 1'b0;
      evt_main <= '0;
      mc_sw_q  <= 1'b0;
      if (!cnt_sat) cnt_q <= cnt_q + 16'd1;

      // commands outside RUN are refused (counted as dropped)
      if (cmd_valid_i && st_q != sf_crt_pkg::ST_RUN) cmd_drop_o <= 1'b1;

      // clock / PLL loss once the root gate has been opened: highest priority
      if (lost && st_q != sf_crt_pkg::ST_OFF && st_q != sf_crt_pkg::ST_WAIT_CLK && st_q != sf_crt_pkg::ST_CLK_LOST) begin
        evt_main   <= lost_m | (wdog_expire_i ? M_WDG : 16'd0) | (ext_wdog_i ? M_XWDG : 16'd0);
        st_q       <= sf_crt_pkg::ST_CLK_LOST;
        root_en_o  <= 1'b0;
        fab_rst_no <= 1'b0;
        cc_rst_no  <= 1'b0;
        br_rst_no  <= '0;
        br_force_o <= '0;
        fab_qreq_o <= 1'b0;
        br_qreq_o  <= '0;
        run_o      <= 1'b0;
        cnt_q      <= '0;
      end else begin
        unique case (st_q)
          sf_crt_pkg::ST_OFF: begin
            boot_o <= 1'b1;
            st_q   <= sf_crt_pkg::ST_WAIT_CLK;
            cnt_q  <= '0;
          end

          sf_crt_pkg::ST_WAIT_CLK: begin
            if (lost) cnt_q <= '0;
            else if (cnt_q >= C_STABLE) begin
              root_en_o <= 1'b1;
              st_q      <= sf_crt_pkg::ST_ROOT_ON;
              cnt_q     <= '0;
            end
          end

          sf_crt_pkg::ST_ROOT_ON: begin
            if (!root_ack_i) cnt_q <= '0;
            else if (cnt_q >= C_PRE) begin
              fab_rst_no <= 1'b1;
              st_q       <= sf_crt_pkg::ST_REL_FAB;
              cnt_q      <= '0;
            end
          end

          sf_crt_pkg::ST_REL_FAB: begin
            if (!fab_ack_i) cnt_q <= '0;
            else if (cnt_q >= C_FAB) begin
              cc_rst_no <= 1'b1;
              st_q      <= sf_crt_pkg::ST_REL_CC;
              cnt_q     <= '0;
            end
          end

          sf_crt_pkg::ST_REL_CC: begin
            if (!cc_ack_i) cnt_q <= '0;
            else if (cnt_q >= C_CC) begin
              sc_br_q <= ~br_rst_no;
              if (br_rst_no == {NB{1'b1}}) begin
                st_q  <= sf_crt_pkg::ST_RUN;
                run_o <= 1'b1;
              end else begin
                br_force_o <= br_force_o | ~br_rst_no;
                ph_q       <= 1'b0;
                st_q       <= sf_crt_pkg::ST_REL_ACC;
              end
              cnt_q <= '0;
            end
          end

          sf_crt_pkg::ST_REL_ACC: begin
            if (!ph_q) begin
              if ((force_ack_i & sc_br_q) == sc_br_q) begin
                br_rst_no <= br_rst_no | sc_br_q;
                ph_q      <= 1'b1;
              end
            end else if ((br_ack_i & sc_br_q) == sc_br_q) begin
              br_force_o <= br_force_o & ~sc_br_q;
              st_q       <= sf_crt_pkg::ST_RUN;
              run_o      <= 1'b1;
            end
          end

          sf_crt_pkg::ST_RUN: begin
            if (wdog_expire_i || ext_wdog_i) begin
              evt_main <= (wdog_expire_i ? M_WDG : 16'd0) | (ext_wdog_i ? M_XWDG : 16'd0);
              if (cmd_valid_i) cmd_drop_o <= 1'b1;
              sc_fab_q   <= 1'b1;
              sc_cc_q    <= 1'b1;
              sc_br_q    <= {NB{1'b1}};
              fab_rst_no <= 1'b0;
              cc_rst_no  <= 1'b0;
              br_rst_no  <= '0;
              run_o      <= 1'b0;
              st_q       <= sf_crt_pkg::ST_ASSERT;
              cnt_q      <= '0;
            end else if (cmd_valid_i) begin
              unique case (cmd_scope_i)
                sf_crt_pkg::SCOPE_SYS: begin
                  evt_main <= M_SSYS;
                  sc_fab_q <= 1'b1; sc_cc_q <= 1'b1; sc_br_q <= {NB{1'b1}};
                end
                sf_crt_pkg::SCOPE_CC: begin
                  evt_main <= M_SCC;
                  sc_fab_q <= 1'b0; sc_cc_q <= 1'b1; sc_br_q <= {NB{1'b1}};
                end
                sf_crt_pkg::SCOPE_ACC: begin
                  evt_main <= M_SACC;
                  sc_fab_q <= 1'b0; sc_cc_q <= 1'b0; sc_br_q <= cmd_br;
                end
                default: begin                   // sf_crt_pkg::SCOPE_MC: handled by the MC FSM
                  evt_main <= M_SMC;
                  mc_sw_q  <= 1'b1;
                end
              endcase
              if (cmd_scope_i != sf_crt_pkg::SCOPE_MC) begin
                run_o <= 1'b0;
                cnt_q <= '0;
                if (cmd_force_i) begin
                  // immediate assertion (no drain)
                  if (cmd_scope_i == sf_crt_pkg::SCOPE_SYS) fab_rst_no <= 1'b0;
                  if (cmd_scope_i != sf_crt_pkg::SCOPE_ACC) cc_rst_no  <= 1'b0;
                  br_rst_no <= br_rst_no & ~((cmd_scope_i == sf_crt_pkg::SCOPE_ACC) ? cmd_br : {NB{1'b1}});
                  st_q      <= sf_crt_pkg::ST_ASSERT;
                end else begin
                  fab_qreq_o <= (cmd_scope_i == sf_crt_pkg::SCOPE_SYS);
                  br_qreq_o  <= (cmd_scope_i == sf_crt_pkg::SCOPE_ACC) ? cmd_br : {NB{1'b1}};
                  st_q       <= sf_crt_pkg::ST_QUIESCE;
                end
              end
            end
          end

          sf_crt_pkg::ST_QUIESCE: begin
            if (wdog_expire_i || ext_wdog_i) begin
              // a fault during the drain escalates to an immediate system reset
              evt_main   <= (wdog_expire_i ? M_WDG : 16'd0) | (ext_wdog_i ? M_XWDG : 16'd0);
              sc_fab_q   <= 1'b1;
              sc_cc_q    <= 1'b1;
              sc_br_q    <= {NB{1'b1}};
              fab_rst_no <= 1'b0;
              cc_rst_no  <= 1'b0;
              br_rst_no  <= '0;
              fab_qreq_o <= 1'b0;
              br_qreq_o  <= '0;
              st_q       <= sf_crt_pkg::ST_ASSERT;
              cnt_q      <= '0;
            end else if (((!sc_fab_q || fab_qack_i) && ((br_qack_i & sc_br_q) == sc_br_q))
                         || (cnt_q >= C_QTO)) begin
              if (cnt_q >= C_QTO) qtimeout_o <= 1'b1;
              if (sc_fab_q) fab_rst_no <= 1'b0;
              if (sc_cc_q)  cc_rst_no  <= 1'b0;
              br_rst_no  <= br_rst_no & ~sc_br_q;
              fab_qreq_o <= 1'b0;
              br_qreq_o  <= '0;
              st_q       <= sf_crt_pkg::ST_ASSERT;
              cnt_q      <= '0;
            end
          end

          sf_crt_pkg::ST_ASSERT: begin
            if (cnt_q >= C_HOLD && (!sc_fab_q || !fab_ack_i) && (!sc_cc_q || !cc_ack_i)
                && ((br_ack_i & sc_br_q) == '0)) begin
              cnt_q <= '0;
              if (sc_fab_q) begin
                fab_rst_no <= 1'b1;
                st_q       <= sf_crt_pkg::ST_REL_FAB;
              end else if (sc_cc_q) begin
                cc_rst_no  <= 1'b1;
                st_q       <= sf_crt_pkg::ST_REL_CC;
              end else begin
                br_force_o <= br_force_o | sc_br_q;
                ph_q       <= 1'b0;
                st_q       <= sf_crt_pkg::ST_REL_ACC;
              end
            end
          end

          sf_crt_pkg::ST_CLK_LOST: begin
            if (acks_clear) begin
              st_q  <= sf_crt_pkg::ST_WAIT_CLK;
              cnt_q <= '0;
            end
          end

          default: st_q <= sf_crt_pkg::ST_OFF;
        endcase
      end
    end
  end

  assign state_o = st_q;

  // ------------------------------------------------------------ memory-controller FSM
  if (MC_EN) begin : g_mc
    logic [1:0]  mst_q;
    logic [15:0] mstab_q, mhold_q;
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        mst_q     <= sf_crt_pkg::MC_OFF;
        mstab_q   <= '0;
        mhold_q   <= '0;
        mc_rst_no <= 1'b0;
        mc_run_o  <= 1'b0;
        evt_mc    <= '0;
      end else begin
        evt_mc <= '0;
        if (!mc_ok_i)                  mstab_q <= '0;
        else if (mstab_q != 16'hFFFF)  mstab_q <= mstab_q + 16'd1;
        if (mhold_q != 16'hFFFF)       mhold_q <= mhold_q + 16'd1;

        if (!fab_rst_no) begin
          // fabric (and so the memory bridge) in reset: memory controller too
          mst_q     <= sf_crt_pkg::MC_OFF;
          mc_rst_no <= 1'b0;
          mc_run_o  <= 1'b0;
        end else begin
          unique case (mst_q)
            sf_crt_pkg::MC_OFF: begin
              // release only once the fabric domain itself is out of reset (its
              // acknowledge), never on the request alone: with a slow core clock
              // the fabric release lags its request by SYNC_STAGES core cycles
              if (fab_ack_i && mstab_q >= C_STABLE && mhold_q >= C_HOLD && !mc_ack_i) begin
                mc_rst_no <= 1'b1;
                mst_q     <= sf_crt_pkg::MC_REL;
              end
            end
            sf_crt_pkg::MC_REL, sf_crt_pkg::MC_RUN: begin
              if (!mc_ok_i || mc_sw_q) begin
                evt_mc    <= mc_ok_i ? 16'd0 : M_MCLK;
                mc_rst_no <= 1'b0;
                mc_run_o  <= 1'b0;
                mhold_q   <= '0;
                mst_q     <= sf_crt_pkg::MC_OFF;
              end else if (mst_q == sf_crt_pkg::MC_REL && mc_ack_i) begin
                mc_run_o <= 1'b1;
                mst_q    <= sf_crt_pkg::MC_RUN;
              end
            end
            default: mst_q <= sf_crt_pkg::MC_OFF;
          endcase
          // a software MEMCTL reset while the domain is already off restarts its hold
          if (mc_sw_q && mst_q == sf_crt_pkg::MC_OFF) mhold_q <= '0;
        end
      end
    end
    assign mc_state_o = mst_q;
  end else begin : g_no_mc
    assign mc_rst_no  = 1'b0;
    assign mc_run_o   = 1'b0;
    assign mc_state_o = sf_crt_pkg::MC_OFF;
    assign evt_mc     = '0;
    wire unused_mc = &{1'b0, mc_ok_i, mc_ack_i, mc_sw_q};
  end

  assign evt_o = evt_main | evt_mc;
endmodule

`default_nettype wire
