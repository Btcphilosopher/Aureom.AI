// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_branch_gate -- safe control of one gated
// branch of the core clock (e.g. the accelerator / compute domain)
//
// Runs on the root-gated core clock (the ICG's own source clock), reset by the
// fabric reset.  The gate enable is a REGISTER of that clock, so the ICG sees
// a full-cycle setup path (clock-gating check in STA) and the latch-based ICG
// makes the output glitch-free.
//
//   en = sw_en      software clock enable (R_CLK_EN)
//      | clk_req    the branch's own request ("I have work / I am busy"),
//                   registered in the branch domain (ComputeCluster P32
//                   clk_req, ControlCore PMU acc_clk_en)
//      | wake       events from the always-clocked side that need the branch
//                   (command valid, CSR select, NoC request into the branch)
//      | force      the sequencer forces the clock on while it releases the
//                   branch reset (a gated branch can never miss its release)
// Hardware interlock: software can only stop a branch that is idle and not
// being addressed -- en is an OR, so no software value can cut a busy branch.
// Reset value 1: clocks run during and right after reset.
// test_en forces the clock on (scan) through the ICG's SE pin.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_branch_gate #(
  parameter int STAGES = 2
) (
  input  wire logic clk_i,
  input  wire logic rst_ni,
  input  wire logic sw_en_i,
  input  wire logic clk_req_i,
  input  wire logic wake_i,
  input  wire logic force_i,        // asynchronous (clk_ref flop)
  input  wire logic test_en_i,
  output logic      clk_o,
  output logic      ce_o,
  output logic      en_o,
  output logic      force_ack_o
);
  logic force_s, en_q;
  sf_crt_sync #(.WIDTH(1), .STAGES(STAGES)) u_force_sync (
    .clk_i, .rst_ni, .d_i(force_i), .q_o(force_s));

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      en_q        <= 1'b1;
      force_ack_o <= 1'b0;
    end else begin
      en_q        <= sw_en_i | clk_req_i | wake_i | force_s;
      force_ack_o <= force_s & en_q;
    end
  end
  assign en_o = en_q;

  sf_crt_clk_gate u_cg (.clk_i, .en_i(en_q), .test_en_i, .clk_o, .ce_o);
endmodule

`default_nettype wire
