// =============================================================================
// SilicaFlux CLOCKTREE (Project 35) :: sf_crt_pkg
// Encodings shared by the chip-wide clock / reset controller, its testbenches
// and the register-map documentation (docs/REGISTER_MAP.md).
// Classification: SYNTHESIZABLE (package)
// =============================================================================
`default_nettype none

package sf_crt_pkg;

  // ------------------------------------------------------------ identity
  localparam logic [31:0] CRT_ID      = 32'h5346_4354;   // "SFCT"
  localparam logic [7:0]  CRT_VERSION = 8'h01;

  // ------------------------------------------------------------ sequencer states (clk_ref domain)
  localparam logic [3:0] ST_OFF      = 4'd0;   // ref system reset active / first cycle after it
  localparam logic [3:0] ST_WAIT_CLK = 4'd1;   // waiting for PLL lock + core clock present & in range
  localparam logic [3:0] ST_ROOT_ON  = 4'd2;   // root clock gate opened, waiting for its acknowledge
  localparam logic [3:0] ST_REL_FAB  = 4'd3;   // fabric reset released, waiting ack + FAB_DELAY
  localparam logic [3:0] ST_REL_CC   = 4'd4;   // ControlCore reset released, waiting ack + CC_DELAY
  localparam logic [3:0] ST_REL_ACC  = 4'd5;   // accelerator branches: clock forced on, reset released
  localparam logic [3:0] ST_RUN      = 4'd6;   // sequence complete
  localparam logic [3:0] ST_QUIESCE  = 4'd7;   // graceful software reset: waiting for idle (or timeout)
  localparam logic [3:0] ST_ASSERT   = 4'd8;   // reset asserted in the affected domains, hold + ack
  localparam logic [3:0] ST_CLK_LOST = 4'd9;   // core clock / PLL lock lost: everything held in reset

  // memory-controller domain FSM (clk_ref domain, only with MC_EN = 1)
  localparam logic [1:0] MC_OFF = 2'd0;        // mc_rst asserted
  localparam logic [1:0] MC_REL = 2'd1;        // released, waiting for the mc-domain acknowledge
  localparam logic [1:0] MC_RUN = 2'd2;        // memory-controller domain out of reset

  // ------------------------------------------------------------ reset causes (sticky, POR domain)
  localparam int CAUSE_POR         = 0;   // power-on reset (por_ni)
  localparam int CAUSE_EXT         = 1;   // external reset pin (ext_rst_ni)
  localparam int CAUSE_CLK_LOSS    = 2;   // core clock absent / out of range (clock monitor)
  localparam int CAUSE_PLL_LOSS    = 3;   // PLL lock lost
  localparam int CAUSE_WDOG        = 4;   // system watchdog (this block) second-stage expiry
  localparam int CAUSE_EXT_WDOG    = 5;   // block watchdog reset request input (wdog_req_i)
  localparam int CAUSE_SW_SYS      = 6;   // software reset, scope SYSTEM
  localparam int CAUSE_SW_CC       = 7;   // software reset, scope CONTROL
  localparam int CAUSE_SW_ACC      = 8;   // software reset, scope COMPUTE
  localparam int CAUSE_SW_MC       = 9;   // software reset, scope MEMCTL
  localparam int CAUSE_MC_CLK_LOSS = 10;  // memory-controller clock absent / out of range

  // ------------------------------------------------------------ software reset command
  // SW_RST register: [31:16] KEY, [12] FORCE (skip quiesce), [9:8] SCOPE, [7:0] ACC branch mask (0 = all)
  localparam logic [15:0] SWRST_KEY   = 16'h5AFE;
  localparam logic [1:0]  SCOPE_SYS   = 2'd0;  // fabric + ControlCore + accelerators + memory controller
  localparam logic [1:0]  SCOPE_CC    = 2'd1;  // ControlCore + accelerators
  localparam logic [1:0]  SCOPE_ACC   = 2'd2;  // selected accelerator branches
  localparam logic [1:0]  SCOPE_MC    = 2'd3;  // memory-controller domain

  // ------------------------------------------------------------ watchdog
  localparam logic [31:0] WDOG_KICK_KEY = 32'h57D0_6EED;

  // ------------------------------------------------------------ register offsets (byte, 8-bit window)
  localparam logic [7:0] R_ID        = 8'h00;  // RO  identity
  localparam logic [7:0] R_CONFIG    = 8'h04;  // RO  build configuration
  localparam logic [7:0] R_STATUS    = 8'h08;  // RO  sequencer / clock status (snapshot)
  localparam logic [7:0] R_CAUSE     = 8'h0C;  // RO/W1C sticky reset causes
  localparam logic [7:0] R_RST_INFO  = 8'h10;  // RO  reset count, last cause, states
  localparam logic [7:0] R_SW_RST    = 8'h14;  // WO  keyed software reset command
  localparam logic [7:0] R_CLK_EN    = 8'h18;  // RW  software clock enables of the gated branches
  localparam logic [7:0] R_CLK_STAT  = 8'h1C;  // RO  branch gate state / clock requests
  localparam logic [7:0] R_WDOG_CTRL = 8'h20;  // RW  watchdog control (write launches the config)
  localparam logic [7:0] R_WDOG_LOAD = 8'h24;  // RW  watchdog reload value (clk_ref cycles)
  localparam logic [7:0] R_WDOG_KICK = 8'h28;  // WO  keyed watchdog service
  localparam logic [7:0] R_WDOG_CNT  = 8'h2C;  // RO  watchdog counter (snapshot)
  localparam logic [7:0] R_CLK_MEAS  = 8'h30;  // RO  clock-monitor counts per window (snapshot)
  localparam logic [7:0] R_IRQ       = 8'h34;  // RO/W1C interrupt status

  // ------------------------------------------------------------ helpers
  // Highest-priority cause of an event mask (lowest index wins); 4'hF = none.
  // (Function-name assignment style: Yosys 0.33 mis-parses some `return`
  //  expressions -- TimingFlow docs/TOOLS.md.)
  function automatic logic [3:0] first_cause(input logic [15:0] m);
    logic [3:0] r;
    r = 4'hF;
    for (int i = 15; i >= 0; i--) begin
      if (m[i]) r = i[3:0];
    end
    first_cause = r;
  endfunction

endpackage

`default_nettype wire
