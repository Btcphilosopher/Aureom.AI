// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_rst_sync -- reset synchroniser
//   asynchronous assertion, synchronous de-assertion to clk_i.
//
// arst_ni must be glitch-free: a primary reset pin, a sf_crt_rst_comb output,
// or a single flop output (never decoded / combinational logic -- this is the
// rule the ControlCore's sys_reset_req path breaks, docs/00_AUDIT.md F-04).
// Assertion needs no clock edge, so it works with clk_i stopped; release takes
// STAGES rising edges of clk_i, so the clock must be running (the sequencer
// opens the clock before it releases any reset).
//
// DFT: with test_mode_i = 1 both the chain's own asynchronous input and the
// output are taken from test_rst_ni through sf_crt_dft_mux cells, so every
// flop downstream (and the chain itself) is controllable from the scan reset
// pin.  test_mode_i is a static test signal (set_case_analysis in the SDC).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_rst_sync #(
  parameter int STAGES = 2
) (
  input  wire logic clk_i,
  input  wire logic arst_ni,
  input  wire logic test_mode_i,
  input  wire logic test_rst_ni,
  output logic      rst_no
);
  logic arst_eff_n;
  sf_crt_dft_mux u_dft_in (.a_i(arst_ni), .b_i(test_rst_ni), .s_i(test_mode_i), .y_o(arst_eff_n));

  (* async_reg = "true" *) logic [STAGES-1:0] rsync_q;
  always_ff @(posedge clk_i or negedge arst_eff_n) begin
    if (!arst_eff_n) rsync_q <= '0;
    else             rsync_q <= {rsync_q[STAGES-2:0], 1'b1};
  end

  sf_crt_dft_mux u_dft_out (.a_i(rsync_q[STAGES-1]), .b_i(test_rst_ni), .s_i(test_mode_i), .y_o(rst_no));

  // synopsys translate_off
  initial begin
    if (STAGES < 2) $fatal(1, "sf_crt_rst_sync: STAGES must be >= 2");
  end
  // synopsys translate_on
endmodule

`default_nettype wire
