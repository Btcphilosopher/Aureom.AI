// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_sync -- multi-flop LEVEL synchroniser
//
// Legal uses (enforced by review + scripts/cdc_check.py):
//   * WIDTH = 1 : any single-bit level (status, request, acknowledge, enable);
//   * WIDTH > 1 with GRAY = 0 : ONLY a bundle of independent single-bit levels
//     (no logic may rely on two bits arriving in the same cycle);
//   * WIDTH > 1 with GRAY = 1 : a Gray-coded value in which at most one bit
//     changes per source clock, with the source->stage-0 skew bounded to one
//     source period by set_max_delay (constraints/sdc).
// An arbitrary multi-bit bus must NOT use this cell: use sf_crt_handshake or
// sf_crt_async_fifo.
//
// Simulation metastability model (+define+SF_CRT_CDC_RANDOM): when stage 0
// would change, it randomly keeps its old value for one cycle -- the one-cycle
// latency uncertainty of a real synchroniser.  GRAY = 0: each bit decides
// independently (exposes logic that assumes bit coherence).  GRAY = 1: the
// whole word is held (physically only one bit is in transition, so the
// resolved word is either the old or the new code).
// Classification: SYNTHESIZABLE (stage flops: replace by the library's
// characterised synchroniser cell where one exists; IHP SG13G2 and SKY130HD
// have none, so plain DFFs with dont_touch are used -- docs/04_CDC.md)
// =============================================================================
`default_nettype none

module sf_crt_sync #(
  parameter int               WIDTH     = 1,
  parameter int               STAGES    = 2,
  parameter logic [WIDTH-1:0] RESET_VAL = '0,
  /* verilator lint_off UNUSEDPARAM */
  parameter bit               GRAY      = 1'b0     // used only by the simulation metastability model
  /* verilator lint_on UNUSEDPARAM */
) (
  input  wire logic             clk_i,
  input  wire logic             rst_ni,
  input  wire logic [WIDTH-1:0] d_i,
  output logic      [WIDTH-1:0] q_o
);
  // stage s occupies bits [s*WIDTH +: WIDTH]; stage 0 is the metastable stage
  (* async_reg = "true" *) logic [STAGES*WIDTH-1:0] sync_q;

`ifdef SF_CRT_CDC_RANDOM
  logic [WIDTH-1:0] held_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sync_q <= {STAGES{RESET_VAL}};
      held_q <= '0;
    end else begin
      for (int st = 1; st < STAGES; st++) sync_q[st*WIDTH +: WIDTH] <= sync_q[(st-1)*WIDTH +: WIDTH];
      if (GRAY) begin
        if (d_i != sync_q[WIDTH-1:0] && held_q == '0 && ($urandom_range(0, 1) == 1)) begin
          held_q <= '1;
        end else begin
          sync_q[WIDTH-1:0] <= d_i;
          held_q            <= '0;
        end
      end else begin
        for (int b = 0; b < WIDTH; b++) begin
          if (d_i[b] != sync_q[b] && !held_q[b] && ($urandom_range(0, 1) == 1)) begin
            held_q[b] <= 1'b1;
          end else begin
            sync_q[b] <= d_i[b];
            held_q[b] <= 1'b0;
          end
        end
      end
    end
  end
`else
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) sync_q <= {STAGES{RESET_VAL}};
    else         sync_q <= {sync_q[(STAGES-1)*WIDTH-1:0], d_i};
  end
`endif

  assign q_o = sync_q[(STAGES-1)*WIDTH +: WIDTH];

  // synopsys translate_off
  initial begin
    if (STAGES < 2) $fatal(1, "sf_crt_sync: STAGES must be >= 2");
  end
  // synopsys translate_on
endmodule

`default_nettype wire
