// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_pulse_sync -- loss-free COMMAND pulse crossing
//
// A one-cycle src pulse becomes a one-cycle dst pulse.  Implementation: a
// source toggle (2-phase request) synchronised into dst, an acknowledge
// toggle synchronised back.  A pulse that arrives while the previous one is
// still in flight is remembered (pending) and sent as soon as the channel is
// free, so pulses are never lost; back-to-back pulses inside one round trip
// are COALESCED into one (the users -- watchdog service, event notifications
// -- are idempotent).  src_busy_o reports an in-flight / pending pulse.
//
// Reset-domain rule: both ends must be reset together (they may release
// independently); a one-sided reset desynchronises the toggles.  In this
// design both ends are cleared by the same sequencer flop (docs/04_CDC.md).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_pulse_sync #(
  parameter int STAGES = 2
) (
  input  wire logic src_clk_i,
  input  wire logic src_rst_ni,
  input  wire logic src_pulse_i,
  output logic      src_busy_o,
  input  wire logic dst_clk_i,
  input  wire logic dst_rst_ni,
  output logic      dst_pulse_o
);
  // ---------------- source
  logic src_tgl_q, src_pend_q, src_ack_s, dst_tgl_q;
  sf_crt_sync #(.WIDTH(1), .STAGES(STAGES)) u_ack_sync (
    .clk_i(src_clk_i), .rst_ni(src_rst_ni), .d_i(dst_tgl_q), .q_o(src_ack_s));
  wire src_idle = (src_tgl_q == src_ack_s);

  always_ff @(posedge src_clk_i or negedge src_rst_ni) begin
    if (!src_rst_ni) begin
      src_tgl_q  <= 1'b0;
      src_pend_q <= 1'b0;
    end else begin
      if (src_idle && (src_pulse_i || src_pend_q)) begin
        src_tgl_q  <= ~src_tgl_q;
        src_pend_q <= 1'b0;
      end else if (src_pulse_i) begin
        src_pend_q <= 1'b1;
      end
    end
  end
  assign src_busy_o = !src_idle || src_pend_q;

  // ---------------- destination
  logic dst_req_s;
  sf_crt_sync #(.WIDTH(1), .STAGES(STAGES)) u_req_sync (
    .clk_i(dst_clk_i), .rst_ni(dst_rst_ni), .d_i(src_tgl_q), .q_o(dst_req_s));

  always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
    if (!dst_rst_ni) begin
      dst_tgl_q   <= 1'b0;
      dst_pulse_o <= 1'b0;
    end else begin
      dst_pulse_o <= (dst_req_s != dst_tgl_q);
      dst_tgl_q   <= dst_req_s;
    end
  end
endmodule

`default_nettype wire
