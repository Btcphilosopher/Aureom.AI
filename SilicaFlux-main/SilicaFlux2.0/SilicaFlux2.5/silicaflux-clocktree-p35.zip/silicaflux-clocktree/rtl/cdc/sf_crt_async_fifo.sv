// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_async_fifo -- dual-clock FIFO for STREAMS
// (DMA requests / responses, wide data at rate)
//
// Gray-coded pointers (one bit changes per increment, so each pointer may be
// carried by an sf_crt_sync #(.GRAY(1))), flop storage written in the write
// domain, read data REGISTERED in the read domain.  A slot is read only after
// its write-pointer update has crossed (>= STAGES read edges after the
// write), so the storage -> r_data_q path is quasi-static; it is bounded by
// set_max_delay in the SDC.  Full/empty are conservative (pessimistic by the
// synchroniser latency), never optimistic.
//
// Interface: valid/ready on both sides; r_valid_o/r_data_o form a one-entry
// output register (first-word fall-through after one read-clock cycle).
// Reset: wrst_ni and rrst_ni MUST be asserted together (both halves empty when
// the link restarts); they may release independently.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_async_fifo #(
  parameter int  WIDTH  = 32,
  parameter int  DEPTH  = 8,          // power of two, >= 4
  parameter int  STAGES = 2,
  localparam int AW     = $clog2(DEPTH)
) (
  input  wire logic             wclk_i,
  input  wire logic             wrst_ni,
  input  wire logic             w_valid_i,
  output logic                  w_ready_o,
  input  wire logic [WIDTH-1:0] w_data_i,
  input  wire logic             rclk_i,
  input  wire logic             rrst_ni,
  output logic                  r_valid_o,
  input  wire logic             r_ready_i,
  output logic      [WIDTH-1:0] r_data_o
);
  logic [WIDTH-1:0] mem_q [DEPTH];
  logic [AW:0] wbin_q, wgray_q, rbin_q, rgray_q, rgray_w, wgray_r;

  function automatic logic [AW:0] b2g(input logic [AW:0] b);
    b2g = b ^ (b >> 1);
  endfunction
  function automatic logic [AW:0] g2b(input logic [AW:0] g);
    logic [AW:0] b;
    b[AW] = g[AW];
    for (int i = AW - 1; i >= 0; i--) b[i] = b[i+1] ^ g[i];
    g2b = b;
  endfunction

  // ------------------------------------------------------------ write domain
  sf_crt_sync #(.WIDTH(AW + 1), .STAGES(STAGES), .GRAY(1'b1)) u_r2w (
    .clk_i(wclk_i), .rst_ni(wrst_ni), .d_i(rgray_q), .q_o(rgray_w));
  wire [AW:0] rbin_w = g2b(rgray_w);
  wire        full_w = (wbin_q[AW] != rbin_w[AW]) && (wbin_q[AW-1:0] == rbin_w[AW-1:0]);
  assign w_ready_o = !full_w;
  wire        push   = w_valid_i && !full_w;

  always_ff @(posedge wclk_i or negedge wrst_ni) begin
    if (!wrst_ni) begin
      wbin_q  <= '0;
      wgray_q <= '0;
    end else if (push) begin
      wbin_q  <= wbin_q + 1'b1;
      wgray_q <= b2g(wbin_q + 1'b1);
    end
  end
  // storage: datapath flops, not reset (written before they are ever read)
  always_ff @(posedge wclk_i) begin
    if (push) mem_q[wbin_q[AW-1:0]] <= w_data_i;
  end

  // ------------------------------------------------------------ read domain
  sf_crt_sync #(.WIDTH(AW + 1), .STAGES(STAGES), .GRAY(1'b1)) u_w2r (
    .clk_i(rclk_i), .rst_ni(rrst_ni), .d_i(wgray_q), .q_o(wgray_r));
  wire [AW:0] wbin_r  = g2b(wgray_r);
  wire        empty_r = (wbin_r == rbin_q);
  // output register: load when it is empty or being consumed
  wire        load    = !empty_r && (!r_valid_o || r_ready_i);

  logic [WIDTH-1:0] r_data_q;
  always_ff @(posedge rclk_i or negedge rrst_ni) begin
    if (!rrst_ni) begin
      rbin_q    <= '0;
      rgray_q   <= '0;
      r_valid_o <= 1'b0;
      r_data_q  <= '0;
    end else begin
      if (load) begin
        r_data_q  <= mem_q[rbin_q[AW-1:0]];   // quasi-static slot (written >= STAGES rclk ago)
        rbin_q    <= rbin_q + 1'b1;
        rgray_q   <= b2g(rbin_q + 1'b1);
        r_valid_o <= 1'b1;
      end else if (r_ready_i) begin
        r_valid_o <= 1'b0;
      end
    end
  end
  assign r_data_o = r_data_q;

  // synopsys translate_off
`ifndef SYNTHESIS
  // Simulation-only QUASI-STATIC CHECK: a slot is read only if it was written
  // before the previous read-clock edge (its pointer update has crossed).
  realtime t_wr [DEPTH];
  realtime t_r_prev = -1.0, t_r_cur = -1.0;
  initial for (int i = 0; i < DEPTH; i++) t_wr[i] = -1.0;
  // (in reset the pointers are equal: no load, so no reset term is needed)
  /* verilator lint_off BLKSEQ */
  always @(posedge wclk_i) if (push) t_wr[wbin_q[AW-1:0]] = $realtime;
  always @(posedge rclk_i) begin
    t_r_prev = t_r_cur;
    t_r_cur  = $realtime;
    if (load && t_r_prev >= 0.0 && t_wr[rbin_q[AW-1:0]] >= t_r_prev)
      $fatal(1, "sf_crt_async_fifo %m: QUASI-STATIC VIOLATION -- slot %0d written %0.3f ns before it is read",
             rbin_q[AW-1:0], $realtime - t_wr[rbin_q[AW-1:0]]);
  end
  /* verilator lint_on BLKSEQ */
`endif
  // synopsys translate_on

  // synopsys translate_off
  initial begin
    if (DEPTH < 4 || (1 << AW) != DEPTH) $fatal(1, "sf_crt_async_fifo: DEPTH must be a power of two >= 4");
  end
  // synopsys translate_on
endmodule

`default_nettype wire
