// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_irq_sync -- INTERRUPT crossing
//
//   EDGE_MODE = 0 (level): the source holds the interrupt line (a registered,
//     sticky level cleared by its own software) -> plain synchroniser.  The
//     destination sees the level >= STAGES cycles late and the de-assertion
//     equally late; software must clear at the source.
//   EDGE_MODE = 1 (event): each one-cycle source event pulse crosses through a
//     loss-free sf_crt_pulse_sync and SETS a sticky destination status bit,
//     cleared by dst_clr_i (W1C in the destination register file).  Events
//     closer than one round trip coalesce into one interrupt (status, not a
//     counter).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_irq_sync #(
  parameter bit EDGE_MODE = 1'b0,
  parameter int STAGES    = 2
) (
  input  wire logic src_clk_i,
  input  wire logic src_rst_ni,
  input  wire logic src_irq_i,     // level (EDGE_MODE=0) or one-cycle event (EDGE_MODE=1)
  input  wire logic dst_clk_i,
  input  wire logic dst_rst_ni,
  input  wire logic dst_clr_i,     // EDGE_MODE=1 only
  output logic      dst_irq_o
);
  if (EDGE_MODE == 1'b0) begin : g_level
    sf_crt_sync #(.WIDTH(1), .STAGES(STAGES)) u_sync (
      .clk_i(dst_clk_i), .rst_ni(dst_rst_ni), .d_i(src_irq_i), .q_o(dst_irq_o));
    wire unused_ok = &{1'b0, src_clk_i, src_rst_ni, dst_clr_i};
  end else begin : g_edge
    logic ev, busy, sticky_q;
    sf_crt_pulse_sync #(.STAGES(STAGES)) u_ps (
      .src_clk_i, .src_rst_ni, .src_pulse_i(src_irq_i), .src_busy_o(busy),
      .dst_clk_i, .dst_rst_ni, .dst_pulse_o(ev));
    always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
      if (!dst_rst_ni)    sticky_q <= 1'b0;
      else if (ev)        sticky_q <= 1'b1;      // a new event wins over a same-cycle clear
      else if (dst_clr_i) sticky_q <= 1'b0;
    end
    assign dst_irq_o = sticky_q;
    wire unused_ok = busy;
  end
endmodule

`default_nettype wire
