// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_rdc_sync -- RESET-domain crossing isolation
//
// Same clock on both sides, different reset domains.  When the SOURCE domain
// is reset asynchronously while the destination keeps running, a source flop
// can change at an arbitrary time relative to the destination clock edge and
// make a destination flop metastable.  This two-flop pipeline (reset by the
// DESTINATION reset) absorbs that metastability before any destination state
// machine uses the value.  It adds two cycles of latency and needs no random
// CDC model (there is no frequency difference).
// Use it only when the source reset can assert while the destination is not
// in reset; when the destination is always reset together with (or before)
// the source, no isolation is required (docs/02_RESET_DOMAINS.md, RDC table).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_rdc_sync #(
  parameter int WIDTH = 1
) (
  input  wire logic             clk_i,
  input  wire logic             rst_ni,     // destination-domain reset
  input  wire logic [WIDTH-1:0] d_i,
  output logic      [WIDTH-1:0] q_o
);
  (* async_reg = "true" *) logic [WIDTH-1:0] rdc_q0, rdc_q1;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rdc_q0 <= '0;
      rdc_q1 <= '0;
    end else begin
      rdc_q0 <= d_i;
      rdc_q1 <= rdc_q0;
    end
  end
  assign q_o = rdc_q1;
endmodule

`default_nettype wire
