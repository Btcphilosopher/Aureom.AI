// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_handshake -- multi-bit WIDE-DATA / COMMAND
// crossing (2-phase toggle request / acknowledge, held payload)
//
// Only the single-bit request and acknowledge toggles are synchronised.  The
// payload register src_hold_q is loaded when the request is launched and is
// not touched again until the acknowledge returns, so when the destination
// sees the request toggle (>= STAGES dst edges after launch) the payload has
// been stable for at least that long and is captured coherently.
//
// Timing constraint (constraints/sdc): src_hold_q -> dst_data_q is a
// quasi-static path; it is bounded with set_max_delay -ignore_clock_latency
// (<= one destination period), never false-pathed.
// Reset-domain rule: both ends reset together (see sf_crt_pulse_sync).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_handshake #(
  parameter int WIDTH  = 32,
  parameter int STAGES = 2
) (
  input  wire logic             src_clk_i,
  input  wire logic             src_rst_ni,
  input  wire logic             src_valid_i,
  output logic                  src_ready_o,
  input  wire logic [WIDTH-1:0] src_data_i,
  input  wire logic             dst_clk_i,
  input  wire logic             dst_rst_ni,
  output logic                  dst_valid_o,
  output logic      [WIDTH-1:0] dst_data_o
);
  // ---------------- source
  logic             src_req_q, src_ack_s, dst_ack_q;
  logic [WIDTH-1:0] src_hold_q;

  sf_crt_sync #(.WIDTH(1), .STAGES(STAGES)) u_ack_sync (
    .clk_i(src_clk_i), .rst_ni(src_rst_ni), .d_i(dst_ack_q), .q_o(src_ack_s));
  assign src_ready_o = (src_req_q == src_ack_s);

  always_ff @(posedge src_clk_i or negedge src_rst_ni) begin
    if (!src_rst_ni) begin
      src_req_q  <= 1'b0;
      src_hold_q <= '0;
    end else if (src_valid_i && src_ready_o) begin
      src_hold_q <= src_data_i;
      src_req_q  <= ~src_req_q;
    end
  end

  // ---------------- destination
  logic             dst_req_s;
  logic [WIDTH-1:0] dst_data_q;
  sf_crt_sync #(.WIDTH(1), .STAGES(STAGES)) u_req_sync (
    .clk_i(dst_clk_i), .rst_ni(dst_rst_ni), .d_i(src_req_q), .q_o(dst_req_s));

  always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
    if (!dst_rst_ni) begin
      dst_ack_q   <= 1'b0;
      dst_valid_o <= 1'b0;
      dst_data_q  <= '0;
    end else begin
      dst_valid_o <= 1'b0;
      if (dst_req_s != dst_ack_q) begin
        dst_ack_q   <= dst_req_s;
        dst_data_q  <= src_hold_q;     // quasi-static: stable >= STAGES dst edges
        dst_valid_o <= 1'b1;
      end
    end
  end
  assign dst_data_o = dst_data_q;

  // synopsys translate_off
`ifndef SYNTHESIS
  // Simulation-only QUASI-STATIC CHECK: the payload sampled by the destination
  // must not have changed after the previous destination edge (with real
  // per-bit skew it could be captured incoherently).  Zero-delay RTL
  // simulation cannot show that corruption, so it is asserted here.
  // (in reset dst_req_s == dst_ack_q, so no reset term is needed)
  realtime t_hold_chg = -1.0, t_dst_prev = -1.0, t_dst_cur = -1.0;
  always @(src_hold_q) t_hold_chg = $realtime;
  /* verilator lint_off BLKSEQ */
  always @(posedge dst_clk_i) begin
    t_dst_prev = t_dst_cur;
    t_dst_cur  = $realtime;
    if ((dst_req_s != dst_ack_q) && t_dst_prev >= 0.0 && t_hold_chg >= t_dst_prev)
      $fatal(1, "sf_crt_handshake %m: QUASI-STATIC VIOLATION -- payload changed %0.3f ns before capture",
             $realtime - t_hold_chg);
  end
  /* verilator lint_on BLKSEQ */
`endif
  // synopsys translate_on
endmodule

`default_nettype wire
