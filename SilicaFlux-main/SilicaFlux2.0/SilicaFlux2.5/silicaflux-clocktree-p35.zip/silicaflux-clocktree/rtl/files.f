// SilicaFlux CLOCKTREE RTL file list (technology cells chosen separately:
// rtl/tech/<tech>/sf_crt_tech_cells.sv)
rtl/sf_crt_pkg.sv
rtl/cdc/sf_crt_sync.sv
rtl/cdc/sf_crt_rst_sync.sv
rtl/cdc/sf_crt_rdc_sync.sv
rtl/cdc/sf_crt_pulse_sync.sv
rtl/cdc/sf_crt_handshake.sv
rtl/cdc/sf_crt_async_fifo.sv
rtl/cdc/sf_crt_irq_sync.sv
rtl/clk/sf_crt_clk_gate.sv
rtl/sf_crt_clk_mon.sv
rtl/sf_crt_wdog.sv
rtl/sf_crt_cause_log.sv
rtl/sf_crt_seq.sv
rtl/sf_crt_branch_gate.sv
rtl/sf_crt_regs.sv
rtl/silicaflux_clock_reset_tree.sv
