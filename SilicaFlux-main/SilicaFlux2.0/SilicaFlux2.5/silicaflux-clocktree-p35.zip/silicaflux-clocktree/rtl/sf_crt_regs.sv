// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_regs -- software interface (core domain)
//
// SilicaFlux-V register-bus slave, the same contract as the die registers
// (one-cycle rb_sel strobe, rb_rdata / rb_err combinational in the strobe
// cycle, side effects at the end of that cycle, rb_err = refused with no
// effect).  Clocked by the root-gated core clock, reset by the fabric reset.
// Map: docs/REGISTER_MAP.md (offsets in sf_crt_pkg).
//
// Everything owned by the reference domain is read from the latest status
// SNAPSHOT (a coherent multi-bit word delivered by sf_crt_handshake, refreshed
// continuously); every command to the reference domain leaves through its own
// CDC channel, and a write that finds its channel busy is refused (rb_err) so
// software can retry -- nothing is silently lost.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_regs #(
  parameter int NB     = 1,
  parameter int NW     = 1,
  parameter bit MC_EN  = 1'b0,
  parameter int SNAP_W = 128
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  // register bus
  input  wire logic              rb_sel_i,
  input  wire logic              rb_we_i,
  input  wire logic [7:0]        rb_addr_i,
  input  wire logic [31:0]       rb_wdata_i,
  output logic [31:0]            rb_rdata_o,
  output logic                   rb_err_o,
  // status snapshot from clk_ref
  input  wire logic              snap_valid_i,
  input  wire logic [SNAP_W-1:0] snap_i,
  // local status
  input  wire logic [NB-1:0]     br_en_i,
  input  wire logic [NB-1:0]     br_clk_req_i,
  input  wire logic              wdog_irq_i,
  // software reset command channel
  output logic                   cmd_valid_o,
  input  wire logic              cmd_ready_i,
  output logic [3+NB-1:0]        cmd_data_o,      // {force, scope[1:0], mask[NB-1:0]}
  // watchdog configuration channel
  output logic                   cfg_valid_o,
  input  wire logic              cfg_ready_i,
  output logic [34:0]            cfg_data_o,
  // watchdog service
  output logic                   kick_o,
  input  wire logic              kick_busy_i,
  // cause clear channel
  output logic                   clr_valid_o,
  input  wire logic              clr_ready_i,
  output logic [15:0]            clr_data_o,
  // clock enables
  output logic [NB-1:0]          sw_clk_en_o
);
  logic [31:0] wdog_load_q;
  logic        snap_seen_q;

  wire wr = rb_sel_i && rb_we_i;
  wire rd = rb_sel_i && !rb_we_i;

  // snapshot fields (layout: docs/REGISTER_MAP.md, "snapshot")
  wire [3:0]  s_state    = snap_i[3:0];
  wire [1:0]  s_mcstate  = snap_i[5:4];
  wire [10:0] s_flags    = snap_i[16:6];
  wire [7:0]  s_br_ack   = snap_i[24:17];
  wire [2:0]  s_dom_ack  = snap_i[27:25];    // {mc, cc, fab}
  wire [3:0]  s_last     = snap_i[31:28];
  wire [15:0] s_cause    = snap_i[47:32];
  wire [15:0] s_count    = snap_i[63:48];
  wire [31:0] s_wcount   = snap_i[95:64];
  wire [15:0] s_core_cnt = snap_i[111:96];
  wire [15:0] s_mc_cnt   = snap_i[127:112];

  // ------------------------------------------------------------ write decode
  wire [15:0] key       = rb_wdata_i[31:16];
  wire        w_swrst   = wr && rb_addr_i == sf_crt_pkg::R_SW_RST;
  wire        w_cause   = wr && rb_addr_i == sf_crt_pkg::R_CAUSE;
  wire        w_wctrl   = wr && rb_addr_i == sf_crt_pkg::R_WDOG_CTRL;
  wire        w_wload   = wr && rb_addr_i == sf_crt_pkg::R_WDOG_LOAD;
  wire        w_kick    = wr && rb_addr_i == sf_crt_pkg::R_WDOG_KICK;
  wire        w_clken   = wr && rb_addr_i == sf_crt_pkg::R_CLK_EN;
  // a MEMCTL-scope reset is refused when the build has no memory-controller domain
  wire        scope_ok  = MC_EN || (rb_wdata_i[9:8] != sf_crt_pkg::SCOPE_MC);
  wire        swrst_ok  = (key == sf_crt_pkg::SWRST_KEY) && cmd_ready_i && scope_ok;
  wire        kick_ok   = (rb_wdata_i == sf_crt_pkg::WDOG_KICK_KEY);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cmd_valid_o <= 1'b0;
      cmd_data_o  <= '0;
      cfg_valid_o <= 1'b0;
      cfg_data_o  <= '0;
      kick_o      <= 1'b0;
      clr_valid_o <= 1'b0;
      clr_data_o  <= '0;
      sw_clk_en_o <= {NB{1'b1}};
      wdog_load_q <= 32'hFFFF_FFFF;
      snap_seen_q <= 1'b0;
    end else begin
      kick_o <= 1'b0;
      if (snap_valid_i) snap_seen_q <= 1'b1;
      // each channel request is held until its handshake accepts it
      if (cmd_valid_o && cmd_ready_i) cmd_valid_o <= 1'b0;
      if (cfg_valid_o && cfg_ready_i) cfg_valid_o <= 1'b0;
      if (clr_valid_o && clr_ready_i) clr_valid_o <= 1'b0;

      if (w_swrst && swrst_ok && !cmd_valid_o) begin
        cmd_valid_o <= 1'b1;
        cmd_data_o  <= {rb_wdata_i[12], rb_wdata_i[9:8], rb_wdata_i[NB-1:0]};
      end
      if (w_cause && clr_ready_i && !clr_valid_o) begin
        clr_valid_o <= 1'b1;
        clr_data_o  <= rb_wdata_i[15:0];
      end
      if (w_wload) wdog_load_q <= rb_wdata_i;
      if (w_wctrl && cfg_ready_i && !cfg_valid_o) begin
        cfg_valid_o <= 1'b1;
        cfg_data_o  <= {rb_wdata_i[2], rb_wdata_i[1], rb_wdata_i[0], wdog_load_q};
      end
      if (w_kick && kick_ok) kick_o <= 1'b1;
      if (w_clken) sw_clk_en_o <= rb_wdata_i[NB-1:0];
    end
  end

  // ------------------------------------------------------------ read mux / errors
  localparam logic [7:0] NB8 = 8'(NB);
  localparam logic [7:0] NW8 = 8'(NW);
  logic [31:0] cfg_word;
  logic [7:0]  br_req8, br_en8;
  logic [31:0] clk_en32;
  assign cfg_word = {sf_crt_pkg::CRT_VERSION, NB8, NW8, 7'd0, MC_EN};
  always_comb begin
    br_req8  = '0;
    br_en8   = '0;
    clk_en32 = '0;
    br_req8[NB-1:0]  = br_clk_req_i;
    br_en8[NB-1:0]   = br_en_i;
    clk_en32[NB-1:0] = sw_clk_en_o;
  end

  always_comb begin
    rb_rdata_o = '0;
    rb_err_o   = 1'b0;
    unique case (rb_addr_i)
      sf_crt_pkg::R_ID:        begin rb_rdata_o = sf_crt_pkg::CRT_ID;   rb_err_o = wr; end
      sf_crt_pkg::R_CONFIG:    begin rb_rdata_o = cfg_word; rb_err_o = wr; end
      sf_crt_pkg::R_STATUS:    begin
                     rb_rdata_o = {snap_seen_q, 11'd0, s_dom_ack, s_flags, s_mcstate, s_state};
                     rb_err_o   = wr;
                   end
      sf_crt_pkg::R_CAUSE:     begin rb_rdata_o = {16'd0, s_cause}; rb_err_o = wr && (!clr_ready_i || clr_valid_o); end
      sf_crt_pkg::R_RST_INFO:  begin rb_rdata_o = {s_br_ack, 4'd0, s_last, s_count}; rb_err_o = wr; end
      sf_crt_pkg::R_SW_RST:    begin rb_err_o = rd ? 1'b0 : !(swrst_ok && !cmd_valid_o); end
      sf_crt_pkg::R_CLK_EN:    begin rb_rdata_o = clk_en32; end
      sf_crt_pkg::R_CLK_STAT:  begin rb_rdata_o = {16'd0, br_req8, br_en8}; rb_err_o = wr; end
      sf_crt_pkg::R_WDOG_CTRL: begin
                     rb_rdata_o = {29'd0, s_flags[7], s_flags[6], s_flags[5]};   // {rst_en, lock, en} effective
                     rb_err_o   = wr && (!cfg_ready_i || cfg_valid_o);
                   end
      sf_crt_pkg::R_WDOG_LOAD: begin rb_rdata_o = wdog_load_q; end
      sf_crt_pkg::R_WDOG_KICK: begin rb_err_o = rd ? 1'b0 : !kick_ok; end
      sf_crt_pkg::R_WDOG_CNT:  begin rb_rdata_o = s_wcount; rb_err_o = wr; end
      sf_crt_pkg::R_CLK_MEAS:  begin rb_rdata_o = {s_mc_cnt, s_core_cnt}; rb_err_o = wr; end
      sf_crt_pkg::R_IRQ:       begin rb_rdata_o = {31'd0, wdog_irq_i}; rb_err_o = wr; end
      default:     begin rb_err_o = rb_sel_i; end
    endcase
    if (!rb_sel_i) rb_err_o = 1'b0;
  end

  wire unused_ok = &{1'b0, kick_busy_i};
endmodule

`default_nettype wire
