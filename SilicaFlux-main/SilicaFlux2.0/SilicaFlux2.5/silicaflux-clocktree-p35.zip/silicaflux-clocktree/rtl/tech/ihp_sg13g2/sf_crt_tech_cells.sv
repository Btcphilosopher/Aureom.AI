// =============================================================================
// SilicaFlux CLOCKTREE :: technology cells -- IHP SG13G2 (130 nm, open PDK)
// Cells and pins checked against ORFS flow/platforms/ihp-sg13g2/lib/
// sg13g2_stdcell_{typ,slow,fast}*.lib (scripts/check_tech_cells.py):
//   sg13g2_slgcp_1 : clock_gating_integrated_cell "latch_posedge_precontrol"
//                    pins CLK GATE SCE -> GCLK.  ORFS lists it as DONT_USE (the
//                    synthesiser must not infer it); explicit instantiation is
//                    legal and the Liberty marks it dont_touch.
//   sg13g2_mux2_1  : A0 A1 S -> X        (DFT reset mux, dont_touch in the flow)
//   sg13g2_and2_1  : A B -> X            (reset-combine cell, dont_touch)
// Classification: SYNTHESIZABLE (technology mapping)
// =============================================================================
`default_nettype none

module sf_crt_icg_cell (
  input  wire logic clk_i,
  input  wire logic en_i,
  input  wire logic se_i,
  output logic      gclk_o
);
  (* keep, dont_touch = "true" *)
  sg13g2_slgcp_1 u_cell (.CLK(clk_i), .GATE(en_i), .SCE(se_i), .GCLK(gclk_o));
endmodule

module sf_crt_dft_mux (
  input  wire logic a_i,
  input  wire logic b_i,
  input  wire logic s_i,
  output logic      y_o
);
  (* keep, dont_touch = "true" *)
  sg13g2_mux2_1 u_cell (.A0(a_i), .A1(b_i), .S(s_i), .X(y_o));
endmodule

module sf_crt_rst_comb (
  input  wire logic a_ni,
  input  wire logic b_ni,
  output logic      y_no
);
  (* keep, dont_touch = "true" *)
  sg13g2_and2_1 u_cell (.A(a_ni), .B(b_ni), .X(y_no));
endmodule

`default_nettype wire
