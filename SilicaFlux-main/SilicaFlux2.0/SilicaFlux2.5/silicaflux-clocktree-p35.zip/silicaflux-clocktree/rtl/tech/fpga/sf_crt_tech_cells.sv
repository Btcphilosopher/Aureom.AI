// =============================================================================
// SilicaFlux CLOCKTREE :: technology cells -- FPGA (Xilinx 7-series /
// UltraScale and Lattice ECP5)
//
// Build with +define+SF_CRT_CG_XILINX_BUFGCE (or SF_CRT_CG_ECP5_DCCA): clock
// gating then uses the vendor global-buffer primitive in sf_crt_clk_gate and
// no sf_crt_icg_cell exists in this library -- a build that forgets the define
// fails to elaborate instead of building LUT-gated clocks.
// FPGA builds have no scan: test_mode_i / test_en_i are tied 0 at the top, so
// the DFT mux reduces to a wire after constant propagation.  The reset-combine
// cell is one LUT whose inputs are both glitch-free (pins / flops).
// Classification: SYNTHESIZABLE (FPGA mapping)
// =============================================================================
`default_nettype none

module sf_crt_dft_mux (
  input  wire logic a_i,
  input  wire logic b_i,
  input  wire logic s_i,
  output logic      y_o
);
  assign y_o = s_i ? b_i : a_i;
endmodule

module sf_crt_rst_comb (
  input  wire logic a_ni,
  input  wire logic b_ni,
  output logic      y_no
);
  assign y_no = a_ni & b_ni;
endmodule

`default_nettype wire
