// =============================================================================
// SilicaFlux CLOCKTREE :: technology cells -- SIMULATION / generic model
//
// sf_crt_icg_cell  : positive-edge latch-based ICG (latch transparent while
//                    CK is low, GCLK = CK & latched enable) -- glitch-free by
//                    construction, behaviourally identical to sg13g2_slgcp_1 /
//                    sky130_fd_sc_hd__sdlclkp_1.  Under SYNTHESIS it refuses
//                    to elaborate unless SF_CRT_GENERIC_SYNTH is defined (a
//                    generic, technology-free structural check), so a real
//                    flow can never silently infer a latch + AND clock gate.
// sf_crt_dft_mux   : static DFT multiplexer for reset / test-control paths.
// sf_crt_rst_comb  : reset-combine cell (active-low AND of two glitch-free
//                    reset sources).  The only combinational gate allowed on a
//                    reset path (scripts/cdc_check.py rule RDC-COMB).
// Classification: SIMULATION MODEL (+ generic synthesis stand-in)
// =============================================================================
`default_nettype none

module sf_crt_icg_cell (
  input  wire logic clk_i,
  input  wire logic en_i,
  input  wire logic se_i,
  output logic      gclk_o
);
`ifdef SYNTHESIS
`ifndef SF_CRT_GENERIC_SYNTH
  sf_crt_icg_target_not_selected u_select_a_technology_icg ();
`endif
`endif
  logic en_l;
  /* verilator lint_off LATCH */
  always_latch begin
    if (!clk_i) en_l = en_i | se_i;
  end
  /* verilator lint_on LATCH */
  assign gclk_o = clk_i & en_l;
endmodule

module sf_crt_dft_mux (
  input  wire logic a_i,    // functional
  input  wire logic b_i,    // test
  input  wire logic s_i,    // test_mode (static)
  output logic      y_o
);
  assign y_o = s_i ? b_i : a_i;
endmodule

module sf_crt_rst_comb (
  input  wire logic a_ni,
  input  wire logic b_ni,
  output logic      y_no
);
  assign y_no = a_ni & b_ni;
endmodule

`default_nettype wire
