// =============================================================================
// SilicaFlux CLOCKTREE :: technology cells -- SkyWater SKY130 (sky130_fd_sc_hd)
// Cells and pins checked against ORFS flow/platforms/sky130hd/lib/
// sky130_fd_sc_hd__tt_025C_1v80.lib (scripts/check_tech_cells.py):
//   sky130_fd_sc_hd__sdlclkp_1 : ICG with scan enable, CLK GATE SCE -> GCLK
//   sky130_fd_sc_hd__mux2_1    : A0 A1 S -> X
//   sky130_fd_sc_hd__and2_1    : A B -> X
// Classification: SYNTHESIZABLE (technology mapping)
// =============================================================================
`default_nettype none

module sf_crt_icg_cell (
  input  wire logic clk_i,
  input  wire logic en_i,
  input  wire logic se_i,
  output logic      gclk_o
);
  (* keep, dont_touch = "true" *)
  sky130_fd_sc_hd__sdlclkp_1 u_cell (.CLK(clk_i), .GATE(en_i), .SCE(se_i), .GCLK(gclk_o));
endmodule

module sf_crt_dft_mux (
  input  wire logic a_i,
  input  wire logic b_i,
  input  wire logic s_i,
  output logic      y_o
);
  (* keep, dont_touch = "true" *)
  sky130_fd_sc_hd__mux2_1 u_cell (.A0(a_i), .A1(b_i), .S(s_i), .X(y_o));
endmodule

module sf_crt_rst_comb (
  input  wire logic a_ni,
  input  wire logic b_ni,
  output logic      y_no
);
  (* keep, dont_touch = "true" *)
  sky130_fd_sc_hd__and2_1 u_cell (.A(a_ni), .B(b_ni), .X(y_no));
endmodule

`default_nettype wire
