// =============================================================================
// SilicaFlux CLOCKTREE (Project 35) :: silicaflux_clock_reset_tree
// Chip-wide clock and reset CONTROL architecture   Aureom.AI | SilicaFlux-HPC
//
// This block implements clock/reset CONTROL logic only.  Physical clock
// distribution (buffers, skew balancing, routing) is produced by clock-tree
// synthesis from cts/ and constraints/ -- nothing here builds a tree.
//
//                    ┌──────────────── silicaflux_clock_reset_tree ─────────────────────┐
//  por_ni ─────────► │ POR sync ─► cause log (POR domain, sticky)                       │
//  ext_rst_ni ──┐    │                                                                  │
//  (rst_comb) ──┴──► │ SYS sync ─► sf_crt_seq (clk_ref) ──flops──┬─► root_en ─► ICG ─────┼─► clk_core_o
//  pll_lock_i ─────► │ 2FF  ┐        ▲     ▲      ▲              ├─► fab/cc rst req ─────┼─► rst sync ─► fab_rst_no, cc_rst_no
//  clk_ref_i ──────► │      │   clock mon  wdog   cmd/cfg/kick   ├─► br force/rst req ──┼─► branch ICG + rst sync ─► clk_br_o, br_rst_no
//  clk_core_i ─────► │ Gray counter ─┘     (clk_ref) ▲ CDC       └─► mc rst req ────────┼─► rst sync (clk_mc) ─► mc_rst_no
//  clk_mc_i  ──────► │ Gray counter (MC_EN)          │                                  │
//  rb_* (core) ────► │ sf_crt_regs (clk_core_o) ─────┘ handshakes / pulse syncs ◄── snapshot
//                    └──────────────────────────────────────────────────────────────────┘
//
// Clock domains (docs/01_CLOCK_DOMAINS.md):
//   clk_ref   reference / management clock (crystal; the PLL's reference).
//             Required: it is the only clock that exists before PLL lock and
//             the only one that can observe the core clock stopping.
//   clk_core  the ONE functional clock (PLL output).  clk_core_o and every
//             clk_br_o[b] are ICG-gated copies: same clock, not crossings.
//   clk_mc    memory-controller interface clock -- research configuration
//             only (MC_EN = 1, matching DieTop EXTMEM_ASYNC = 1).
//   No PCIe application clock: no PCIe endpoint IP / PHY exists (HostLink P25
//   is BLOCKED on that), so none is created.
//
// Reset domains (docs/02_RESET_DOMAINS.md): ref POR, ref SYS (POR | EXT),
// fabric, ControlCore, accelerator branch b, memory controller.  All assert
// asynchronously and release synchronously to the clock of the domain.
//
// Parameters are in reference-clock cycles unless stated.
// Classification: SYNTHESIZABLE (new, Project 35)
// =============================================================================
`default_nettype none

module silicaflux_clock_reset_tree #(
  parameter int          NB           = 1,        // gated core-clock branches (1..8)
  parameter int          NW           = 2,        // block-watchdog reset-request inputs (>= 1)
  parameter bit          MC_EN        = 1'b0,     // memory-controller clock domain present
  parameter int          SYNC_STAGES  = 2,
  parameter int          MON_WINDOW   = 16,       // clock-monitor window (ref cycles)
  parameter int          MON_OK_WIN   = 2,        // consecutive in-range windows before a clock is OK
  parameter logic [15:0] CORE_CNT_MIN = 16'd1,    // core edges per window: OK range
  parameter logic [15:0] CORE_CNT_MAX = 16'hFFFF,
  parameter logic [15:0] MC_CNT_MIN   = 16'd1,
  parameter logic [15:0] MC_CNT_MAX   = 16'hFFFF,
  parameter int          STABLE_CYC   = 8,        // clock OK this long before use
  parameter int          PRE_REL_CYC  = 4,        // running clock before the first release
  parameter int          FAB_DELAY    = 4,        // fabric -> ControlCore release spacing
  parameter int          CC_DELAY     = 4,        // ControlCore -> accelerator spacing
  parameter int          HOLD_CYC     = 4,        // minimum warm-reset assertion
  parameter int          QTIMEOUT     = 1024,     // graceful-reset drain timeout
  localparam int         SNAP_W       = 128
) (
  // ------------------------------------------------------------ clocks
  input  wire logic           clk_ref_i,
  input  wire logic           clk_core_i,
  input  wire logic           clk_mc_i,
  // ------------------------------------------------------------ asynchronous inputs
  input  wire logic           por_ni,
  input  wire logic           ext_rst_ni,
  input  wire logic           pll_lock_i,
  // ------------------------------------------------------------ DFT (static)
  input  wire logic           test_mode_i,
  input  wire logic           test_rst_ni,
  input  wire logic           test_en_i,
  // ------------------------------------------------------------ clocks out
  output logic                clk_core_o,          // root-gated core clock
  output logic [NB-1:0]       clk_br_o,            // gated branches of clk_core_o
  output logic [NB-1:0]       clk_br_ce_o,         // 1, or the enable in ENABLE_ONLY builds
  // ------------------------------------------------------------ domain resets (active low)
  output logic                fab_rst_no,          // clk_core_o domain
  output logic                cc_rst_no,           // clk_core_o domain
  output logic [NB-1:0]       br_rst_no,           // clk_br_o[b] domain
  output logic                mc_rst_no,           // clk_mc_i domain
  // ------------------------------------------------------------ graceful reset (clk_core_o)
  output logic                fab_quiesce_o,
  input  wire logic           fab_idle_i,
  output logic [NB-1:0]       br_quiesce_o,
  input  wire logic [NB-1:0]  br_idle_i,
  // ------------------------------------------------------------ branch clock requests (clk_core_o)
  input  wire logic [NB-1:0]  br_clk_req_i,
  input  wire logic [NB-1:0]  br_wake_i,
  // ------------------------------------------------------------ watchdogs
  input  wire logic [NW-1:0]  wdog_req_i,          // block watchdog reset requests (registered levels)
  output logic                wdog_irq_o,          // clk_core_o: system watchdog stage-1 warning
  // ------------------------------------------------------------ readiness (clk_core_o)
  output logic                sys_ready_o,
  output logic                mc_ready_o,
  // ------------------------------------------------------------ register bus (clk_core_o, fabric reset)
  input  wire logic           rb_sel_i,
  input  wire logic           rb_we_i,
  input  wire logic [7:0]     rb_addr_i,
  input  wire logic [31:0]    rb_wdata_i,
  output logic [31:0]         rb_rdata_o,
  output logic                rb_err_o,
  // ------------------------------------------------------------ debug (clk_ref)
  output logic [3:0]          seq_state_o
);

  // ================================================================ reference-domain resets
  logic ref_por_rst_n, por_ext_n, ref_sys_rst_n, ref_fab_rst_n;
  logic seq_root_en, seq_fab_rst_n, seq_cc_rst_n, seq_mc_rst_n;
  logic [NB-1:0] seq_br_rst_n, seq_br_force, seq_br_qreq;
  logic seq_fab_qreq;

  sf_crt_rst_sync #(.STAGES(SYNC_STAGES)) u_rs_ref_por (
    .clk_i(clk_ref_i), .arst_ni(por_ni), .test_mode_i, .test_rst_ni, .rst_no(ref_por_rst_n));
  sf_crt_rst_comb u_rc_por_ext (.a_ni(por_ni), .b_ni(ext_rst_ni), .y_no(por_ext_n));
  sf_crt_rst_sync #(.STAGES(SYNC_STAGES)) u_rs_ref_sys (
    .clk_i(clk_ref_i), .arst_ni(por_ext_n), .test_mode_i, .test_rst_ni, .rst_no(ref_sys_rst_n));
  // reference-side partners of the fabric-domain CDC endpoints: asserted by the
  // same flop that asserts the fabric reset, so both ends reset together
  sf_crt_rst_sync #(.STAGES(SYNC_STAGES)) u_rs_ref_fab (
    .clk_i(clk_ref_i), .arst_ni(seq_fab_rst_n), .test_mode_i, .test_rst_ni, .rst_no(ref_fab_rst_n));

  // ================================================================ core root: gate + monitor
  logic root_arst_n, root_en_c, core_ce_unused;
  sf_crt_dft_mux u_dft_root (.a_i(seq_root_en), .b_i(test_rst_ni), .s_i(test_mode_i), .y_o(root_arst_n));
  // async-off / sync-on enable (reset-synchroniser structure clocked by the raw core clock)
  sf_crt_sync #(.WIDTH(1), .STAGES(SYNC_STAGES)) u_root_en (
    .clk_i(clk_core_i), .rst_ni(root_arst_n), .d_i(1'b1), .q_o(root_en_c));
  sf_crt_clk_gate u_cg_root (.clk_i(clk_core_i), .en_i(root_en_c), .test_en_i, .clk_o(clk_core_o), .ce_o(core_ce_unused));

  logic       mon_core_rst_n, core_ok;
  logic [7:0] gray_core;
  logic [15:0] core_meas;
  sf_crt_rst_sync #(.STAGES(SYNC_STAGES)) u_rs_mon_core (
    .clk_i(clk_core_i), .arst_ni(ref_por_rst_n), .test_mode_i, .test_rst_ni, .rst_no(mon_core_rst_n));
  sf_crt_clk_mon_src u_mon_src_core (.clk_i(clk_core_i), .rst_ni(mon_core_rst_n), .gray_o(gray_core));
  sf_crt_clk_mon #(.WINDOW(MON_WINDOW), .STAGES(SYNC_STAGES), .CNT_MIN(CORE_CNT_MIN), .CNT_MAX(CORE_CNT_MAX),
                   .OK_WINDOWS(MON_OK_WIN)) u_mon_core (
    .clk_ref_i, .rst_ni(ref_sys_rst_n), .gray_i(gray_core), .ok_o(core_ok), .meas_o(core_meas));

  // ================================================================ core-domain resets
  logic fab_rst_n;
  sf_crt_rst_sync #(.STAGES(SYNC_STAGES)) u_rs_fab (
    .clk_i(clk_core_o), .arst_ni(seq_fab_rst_n), .test_mode_i, .test_rst_ni, .rst_no(fab_rst_n));
  sf_crt_rst_sync #(.STAGES(SYNC_STAGES)) u_rs_cc (
    .clk_i(clk_core_o), .arst_ni(seq_cc_rst_n), .test_mode_i, .test_rst_ni, .rst_no(cc_rst_no));
  assign fab_rst_no = fab_rst_n;

  // ================================================================ gated branches
  logic [NB-1:0] sw_clk_en, br_en, br_force_ack_c;
  for (genvar b = 0; b < NB; b++) begin : g_br
    sf_crt_branch_gate #(.STAGES(SYNC_STAGES)) u_bg (
      .clk_i(clk_core_o), .rst_ni(fab_rst_n), .sw_en_i(sw_clk_en[b]), .clk_req_i(br_clk_req_i[b]),
      .wake_i(br_wake_i[b]), .force_i(seq_br_force[b]), .test_en_i,
      .clk_o(clk_br_o[b]), .ce_o(clk_br_ce_o[b]), .en_o(br_en[b]), .force_ack_o(br_force_ack_c[b]));
    sf_crt_rst_sync #(.STAGES(SYNC_STAGES)) u_rs_br (
      .clk_i(clk_br_o[b]), .arst_ni(seq_br_rst_n[b]), .test_mode_i, .test_rst_ni, .rst_no(br_rst_no[b]));
  end

  // ================================================================ memory-controller domain
  logic        mc_ok;
  logic [15:0] mc_meas;
  logic        mc_rst_n_c;
  if (MC_EN) begin : g_mc
    logic       mon_mc_rst_n;
    logic [7:0] gray_mc;
    sf_crt_rst_sync #(.STAGES(SYNC_STAGES)) u_rs_mc (
      .clk_i(clk_mc_i), .arst_ni(seq_mc_rst_n), .test_mode_i, .test_rst_ni, .rst_no(mc_rst_n_c));
    sf_crt_rst_sync #(.STAGES(SYNC_STAGES)) u_rs_mon_mc (
      .clk_i(clk_mc_i), .arst_ni(ref_por_rst_n), .test_mode_i, .test_rst_ni, .rst_no(mon_mc_rst_n));
    sf_crt_clk_mon_src u_mon_src_mc (.clk_i(clk_mc_i), .rst_ni(mon_mc_rst_n), .gray_o(gray_mc));
    sf_crt_clk_mon #(.WINDOW(MON_WINDOW), .STAGES(SYNC_STAGES), .CNT_MIN(MC_CNT_MIN), .CNT_MAX(MC_CNT_MAX),
                     .OK_WINDOWS(MON_OK_WIN)) u_mon_mc (
      .clk_ref_i, .rst_ni(ref_sys_rst_n), .gray_i(gray_mc), .ok_o(mc_ok), .meas_o(mc_meas));
  end else begin : g_no_mc
    assign mc_rst_n_c = 1'b0;
    assign mc_ok      = 1'b0;
    assign mc_meas    = '0;
    wire unused_mc = &{1'b0, clk_mc_i, seq_mc_rst_n};
  end
  assign mc_rst_no = mc_rst_n_c;

  // ================================================================ quiesce (core side)
  logic          fab_q_s, fab_qack_q;
  logic [NB-1:0] br_q_s, br_qack_q;
  sf_crt_sync #(.WIDTH(NB + 1), .STAGES(SYNC_STAGES)) u_q_sync (
    .clk_i(clk_core_o), .rst_ni(fab_rst_n), .d_i({seq_br_qreq, seq_fab_qreq}), .q_o({br_q_s, fab_q_s}));
  always_ff @(posedge clk_core_o or negedge fab_rst_n) begin
    if (!fab_rst_n) begin
      fab_qack_q <= 1'b0;
      br_qack_q  <= '0;
    end else begin
      fab_qack_q <= fab_q_s & fab_idle_i;          // acknowledge = request seen AND idle
      br_qack_q  <= br_q_s & br_idle_i;
    end
  end
  assign fab_quiesce_o = fab_q_s;
  assign br_quiesce_o  = br_q_s;

  // ================================================================ acknowledges -> clk_ref
  // independent single-bit levels (each one is waited for on its own)
  localparam int AW = 1 + 1 + 1 + NB + NB + 1 + 1 + NB;
  logic [AW-1:0] ack_c, ack_s;
  assign ack_c = {br_qack_q, fab_qack_q, mc_rst_n_c, br_force_ack_c, br_rst_no, cc_rst_no, fab_rst_n, root_en_c};
  sf_crt_sync #(.WIDTH(AW), .STAGES(SYNC_STAGES)) u_ack_sync (
    .clk_i(clk_ref_i), .rst_ni(ref_sys_rst_n), .d_i(ack_c), .q_o(ack_s));
  wire          a_root    = ack_s[0];
  wire          a_fab     = ack_s[1];
  wire          a_cc      = ack_s[2];
  wire [NB-1:0] a_br      = ack_s[3 +: NB];
  wire [NB-1:0] a_force   = ack_s[3 + NB +: NB];
  wire          a_mc      = ack_s[3 + 2*NB];
  wire          a_fab_q   = ack_s[4 + 2*NB];
  wire [NB-1:0] a_br_q    = ack_s[5 + 2*NB +: NB];

  // ================================================================ asynchronous / block status -> clk_ref
  logic          pll_s;
  logic [NW-1:0] wdog_req_s;
  sf_crt_sync #(.WIDTH(1), .STAGES(SYNC_STAGES)) u_pll_sync (
    .clk_i(clk_ref_i), .rst_ni(ref_sys_rst_n), .d_i(pll_lock_i), .q_o(pll_s));
  sf_crt_sync #(.WIDTH(NW), .STAGES(SYNC_STAGES)) u_wreq_sync (
    .clk_i(clk_ref_i), .rst_ni(ref_sys_rst_n), .d_i(wdog_req_i), .q_o(wdog_req_s));

  // ================================================================ core <-> ref command / data channels
  localparam int CMDW = 3 + NB;
  logic            cmd_v_c, cmd_rdy_c, cmd_v_r;
  logic [CMDW-1:0] cmd_d_c, cmd_d_r;
  logic            cfg_v_c, cfg_rdy_c, cfg_v_r;
  logic [34:0]     cfg_d_c, cfg_d_r;
  logic            kick_c, kick_busy_c, kick_r;
  logic            clr_v_c, clr_rdy_c, clr_v_r;
  logic [15:0]     clr_d_c, clr_d_r;
  logic            snap_rdy_r, snap_v_c;
  logic [SNAP_W-1:0] snap_r, snap_c;

  sf_crt_handshake #(.WIDTH(CMDW), .STAGES(SYNC_STAGES)) u_hs_cmd (
    .src_clk_i(clk_core_o), .src_rst_ni(fab_rst_n), .src_valid_i(cmd_v_c), .src_ready_o(cmd_rdy_c), .src_data_i(cmd_d_c),
    .dst_clk_i(clk_ref_i), .dst_rst_ni(ref_fab_rst_n), .dst_valid_o(cmd_v_r), .dst_data_o(cmd_d_r));
  sf_crt_handshake #(.WIDTH(35), .STAGES(SYNC_STAGES)) u_hs_cfg (
    .src_clk_i(clk_core_o), .src_rst_ni(fab_rst_n), .src_valid_i(cfg_v_c), .src_ready_o(cfg_rdy_c), .src_data_i(cfg_d_c),
    .dst_clk_i(clk_ref_i), .dst_rst_ni(ref_fab_rst_n), .dst_valid_o(cfg_v_r), .dst_data_o(cfg_d_r));
  sf_crt_pulse_sync #(.STAGES(SYNC_STAGES)) u_ps_kick (
    .src_clk_i(clk_core_o), .src_rst_ni(fab_rst_n), .src_pulse_i(kick_c), .src_busy_o(kick_busy_c),
    .dst_clk_i(clk_ref_i), .dst_rst_ni(ref_fab_rst_n), .dst_pulse_o(kick_r));
  sf_crt_handshake #(.WIDTH(16), .STAGES(SYNC_STAGES)) u_hs_clr (
    .src_clk_i(clk_core_o), .src_rst_ni(fab_rst_n), .src_valid_i(clr_v_c), .src_ready_o(clr_rdy_c), .src_data_i(clr_d_c),
    .dst_clk_i(clk_ref_i), .dst_rst_ni(ref_fab_rst_n), .dst_valid_o(clr_v_r), .dst_data_o(clr_d_r));
  sf_crt_handshake #(.WIDTH(SNAP_W), .STAGES(SYNC_STAGES)) u_hs_snap (
    .src_clk_i(clk_ref_i), .src_rst_ni(ref_fab_rst_n), .src_valid_i(1'b1), .src_ready_o(snap_rdy_r), .src_data_i(snap_r),
    .dst_clk_i(clk_core_o), .dst_rst_ni(fab_rst_n), .dst_valid_o(snap_v_c), .dst_data_o(snap_c));

  // ================================================================ watchdog (clk_ref, fabric-paired reset)
  logic [31:0] wd_count;
  logic        wd_en, wd_lock, wd_rsten, wd_irq, wd_expire, wd_rej;
  sf_crt_wdog u_wdog (
    .clk_i(clk_ref_i), .rst_ni(ref_fab_rst_n), .cfg_valid_i(cfg_v_r), .cfg_i(cfg_d_r), .kick_i(kick_r),
    .count_o(wd_count), .en_o(wd_en), .lock_o(wd_lock), .rst_en_o(wd_rsten), .irq_o(wd_irq),
    .expire_o(wd_expire), .cfg_rej_o(wd_rej));
  sf_crt_irq_sync #(.EDGE_MODE(1'b0), .STAGES(SYNC_STAGES)) u_irq_wdog (
    .src_clk_i(clk_ref_i), .src_rst_ni(ref_fab_rst_n), .src_irq_i(wd_irq),
    .dst_clk_i(clk_core_o), .dst_rst_ni(fab_rst_n), .dst_clr_i(1'b0), .dst_irq_o(wdog_irq_o));

  // ================================================================ fabric-paired ref domain -> sequencer (RDC isolation)
  logic            wd_expire_s, cmd_v_s;
  logic [CMDW-1:0] cmd_d_s;
  sf_crt_rdc_sync #(.WIDTH(1 + 1 + CMDW)) u_rdc_seq (
    .clk_i(clk_ref_i), .rst_ni(ref_sys_rst_n), .d_i({wd_expire, cmd_v_r, cmd_d_r}), .q_o({wd_expire_s, cmd_v_s, cmd_d_s}));

  // ================================================================ sequencer
  logic [3:0]  seq_state;
  logic [1:0]  mc_state;
  logic        seq_run, seq_mc_run, seq_boot, seq_qto, seq_drop;
  logic [15:0] seq_evt;
  sf_crt_seq #(
    .NB(NB), .MC_EN(MC_EN), .STABLE_CYC(STABLE_CYC), .PRE_REL_CYC(PRE_REL_CYC), .FAB_DELAY(FAB_DELAY),
    .CC_DELAY(CC_DELAY), .HOLD_CYC(HOLD_CYC), .QTIMEOUT(QTIMEOUT)
  ) u_seq (
    .clk_i(clk_ref_i), .rst_ni(ref_sys_rst_n),
    .pll_locked_i(pll_s), .core_ok_i(core_ok), .mc_ok_i(mc_ok),
    .root_ack_i(a_root), .fab_ack_i(a_fab), .cc_ack_i(a_cc), .br_ack_i(a_br), .force_ack_i(a_force), .mc_ack_i(a_mc),
    .fab_qack_i(a_fab_q), .br_qack_i(a_br_q),
    .wdog_expire_i(wd_expire_s), .ext_wdog_i(|wdog_req_s),
    .cmd_valid_i(cmd_v_s), .cmd_scope_i(cmd_d_s[NB +: 2]), .cmd_mask_i(cmd_d_s[NB-1:0]), .cmd_force_i(cmd_d_s[NB + 2]),
    .root_en_o(seq_root_en), .fab_rst_no(seq_fab_rst_n), .cc_rst_no(seq_cc_rst_n), .br_rst_no(seq_br_rst_n),
    .br_force_o(seq_br_force), .mc_rst_no(seq_mc_rst_n), .fab_qreq_o(seq_fab_qreq), .br_qreq_o(seq_br_qreq),
    .state_o(seq_state), .mc_state_o(mc_state), .run_o(seq_run), .mc_run_o(seq_mc_run),
    .evt_o(seq_evt), .boot_o(seq_boot), .qtimeout_o(seq_qto), .cmd_drop_o(seq_drop));
  assign seq_state_o = seq_state;

  // ================================================================ cause log (POR domain)
  logic [15:0] evt_p, clr_p, cause;
  logic        boot_p, clr_v_p;
  logic [3:0]  last_cause;
  logic [15:0] rst_count;
  sf_crt_rdc_sync #(.WIDTH(1 + 16 + 1 + 16)) u_rdc_log (
    .clk_i(clk_ref_i), .rst_ni(ref_por_rst_n), .d_i({seq_boot, seq_evt, clr_v_r, clr_d_r}),
    .q_o({boot_p, evt_p, clr_v_p, clr_p}));
  sf_crt_cause_log u_log (
    .clk_i(clk_ref_i), .rst_ni(ref_por_rst_n), .boot_i(boot_p), .evt_i(evt_p), .clr_i(clr_v_p), .clr_mask_i(clr_p),
    .cause_o(cause), .last_o(last_cause), .count_o(rst_count));

  // ================================================================ status snapshot (clk_ref -> core)
  logic [7:0] br_ack8;
  always_comb begin
    br_ack8         = '0;
    br_ack8[NB-1:0] = a_br;
  end
  assign snap_r = {mc_meas, core_meas, wd_count, rst_count, cause, last_cause,
                   a_mc, a_cc, a_fab, br_ack8,
                   wd_rej, seq_drop, seq_qto, wd_rsten, wd_lock, wd_en, wd_irq, mc_ok, core_ok, pll_s, seq_run,
                   mc_state, seq_state};

  // ================================================================ readiness -> core
  logic run_c, mc_run_c;
  sf_crt_sync #(.WIDTH(2), .STAGES(SYNC_STAGES)) u_rdy_sync (
    .clk_i(clk_core_o), .rst_ni(fab_rst_n), .d_i({seq_mc_run, seq_run}), .q_o({mc_run_c, run_c}));
  assign sys_ready_o = run_c;
  assign mc_ready_o  = mc_run_c;

  // ================================================================ software interface
  sf_crt_regs #(.NB(NB), .NW(NW), .MC_EN(MC_EN), .SNAP_W(SNAP_W)) u_regs (
    .clk_i(clk_core_o), .rst_ni(fab_rst_n),
    .rb_sel_i, .rb_we_i, .rb_addr_i, .rb_wdata_i, .rb_rdata_o, .rb_err_o,
    .snap_valid_i(snap_v_c), .snap_i(snap_c), .br_en_i(br_en), .br_clk_req_i, .wdog_irq_i(wdog_irq_o),
    .cmd_valid_o(cmd_v_c), .cmd_ready_i(cmd_rdy_c), .cmd_data_o(cmd_d_c),
    .cfg_valid_o(cfg_v_c), .cfg_ready_i(cfg_rdy_c), .cfg_data_o(cfg_d_c),
    .kick_o(kick_c), .kick_busy_i(kick_busy_c),
    .clr_valid_o(clr_v_c), .clr_ready_i(clr_rdy_c), .clr_data_o(clr_d_c),
    .sw_clk_en_o(sw_clk_en));

  wire unused_ok = &{1'b0, core_ce_unused, snap_rdy_r};

  // synopsys translate_off
  initial begin
    if (NB < 1 || NB > 8)   $fatal(1, "silicaflux_clock_reset_tree: NB must be 1..8");
    if (NW < 1)             $fatal(1, "silicaflux_clock_reset_tree: NW must be >= 1");
    if (STABLE_CYC < 4)     $fatal(1, "silicaflux_clock_reset_tree: STABLE_CYC must be >= 4 (stale acknowledges)");
    if (MON_WINDOW < 4)     $fatal(1, "silicaflux_clock_reset_tree: MON_WINDOW must be >= 4");
    if (MON_OK_WIN < 2 || MON_OK_WIN > 15)
                            $fatal(1, "silicaflux_clock_reset_tree: MON_OK_WIN must be 2..15 (a partial first window must never qualify a clock)");
  end
  // synopsys translate_on
endmodule

`default_nettype wire
