// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_cause_log -- sticky reset-cause record
// (clk_ref, POR reset domain: survives every reset except power-on)
//
//   * POR: cause = {POR}, last = POR, count = 0.
//   * boot_i (the sequencer left its own reset): if this is the first boot
//     after POR nothing more is logged; otherwise the sequencer was reset by
//     the external reset pin -- the only other source of its reset -- and EXT
//     is logged.  This catches external pulses of any width, including ones
//     too short to be sampled as data.
//   * evt_i (one-cycle event mask from the sequencer): OR-ed into the sticky
//     causes; last = highest-priority cause of the event; count saturates.
//   * clr_i / clr_mask_i: W1C from software (a same-cycle new cause wins).
// Every input comes from another reset domain through sf_crt_rdc_sync.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_cause_log (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,       // POR-only reference reset
  input  wire logic        boot_i,
  input  wire logic [15:0] evt_i,
  input  wire logic        clr_i,
  input  wire logic [15:0] clr_mask_i,
  output logic [15:0]      cause_o,
  output logic [3:0]       last_o,
  output logic [15:0]      count_o
);
  localparam logic [15:0] POR_M = 16'd1 << sf_crt_pkg::CAUSE_POR;
  localparam logic [15:0] EXT_M = 16'd1 << sf_crt_pkg::CAUSE_EXT;
  localparam logic [3:0]  POR_I = 4'(sf_crt_pkg::CAUSE_POR);
  logic        por_fresh_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cause_o     <= POR_M;
      last_o      <= POR_I;
      count_o     <= '0;
      por_fresh_q <= 1'b1;
    end else begin : b_upd
      logic [15:0] c;
      logic [15:0] e;
      e = evt_i;
      if (boot_i) begin
        if (por_fresh_q) por_fresh_q <= 1'b0;
        else             e = e | EXT_M;
      end
      c = cause_o;
      if (clr_i) c = c & ~clr_mask_i;
      c = c | e;
      cause_o <= c;
      if (e != 16'd0) begin
        last_o  <= sf_crt_pkg::first_cause(e);
        if (count_o != 16'hFFFF) count_o <= count_o + 16'd1;
      end
    end
  end
endmodule

`default_nettype wire
