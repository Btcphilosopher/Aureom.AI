// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_clk_gate -- the ONLY place a clock is gated
//
// A clock is never gated with RTL AND/OR logic.  One implementation is chosen
// at build time (exactly one define, or none for the default ICG path):
//
//   (default)                 ICG: instantiates sf_crt_icg_cell, provided by
//                             the selected technology file:
//                               rtl/tech/ihp_sg13g2  -> sg13g2_slgcp_1
//                               rtl/tech/sky130hd    -> sky130_fd_sc_hd__sdlclkp_1
//                               rtl/tech/sim         -> behavioural latch ICG
//                                 (simulation only: fails synthesis on purpose)
//   SF_CRT_CG_XILINX_BUFGCE   Xilinx 7-series / UltraScale BUFGCE (global buffer
//                             with synchronous, glitch-free clock enable)
//   SF_CRT_CG_ECP5_DCCA       Lattice ECP5 DCCA (dynamic clock control element)
//   SF_CRT_CG_ENABLE_ONLY     clock-ENABLE methodology baseline: the clock is
//                             NOT gated (clk_o = clk_i) and ce_o carries the
//                             enable; every flop of the domain must be written
//                             as `if (ce) q <= d;` (no power saving, no clock
//                             tree change, identical cycle behaviour).
//
// en_i must be synchronous to clk_i (launched by a clk_i flop, setup to the
// next rising edge).  test_en_i forces the clock on (scan shift / capture);
// it is a static/scan signal.  ce_o is 1 in every gating implementation.
// Equivalence: an ICG passes edge n when en was 1 during the low phase before
// edge n; a flop with enable ce samples ce at edge n -- the same cycle.
// Classification: SYNTHESIZABLE (technology wrapper)
// =============================================================================
`default_nettype none

module sf_crt_clk_gate (
  input  wire logic clk_i,
  input  wire logic en_i,
  input  wire logic test_en_i,
  output logic      clk_o,
  output logic      ce_o
);
`ifdef SF_CRT_CG_ENABLE_ONLY
  assign clk_o = clk_i;
  assign ce_o  = en_i | test_en_i;
`elsif SF_CRT_CG_XILINX_BUFGCE
  BUFGCE u_bufgce (.I(clk_i), .CE(en_i | test_en_i), .O(clk_o));
  assign ce_o = 1'b1;
`elsif SF_CRT_CG_ECP5_DCCA
  DCCA u_dcca (.CLKI(clk_i), .CE(en_i | test_en_i), .CLKO(clk_o));
  assign ce_o = 1'b1;
`else
  sf_crt_icg_cell u_icg (.clk_i(clk_i), .en_i(en_i), .se_i(test_en_i), .gclk_o(clk_o));
  assign ce_o = 1'b1;
`endif
endmodule

`default_nettype wire
