// =============================================================================
// SilicaFlux CLOCKTREE :: sf_crt_wdog -- chip-level system watchdog (clk_ref)
//
// Runs on the reference clock, so its timeout is independent of the core
// clock frequency (PowerClock operating points) and it still expires if the
// core clock is gated or stuck.  Two stages, as the RAS watchdog (P26):
//   count reaches 0 the first time  -> stage 1: warning (irq_o, a registered
//                                       level), counter reloaded;
//   reaches 0 again without service -> stage 2: expire_o (held until this
//                                       block is reset) if RST_EN, otherwise
//                                       it stays in stage 1 and reloads.
// Service (kick_i pulse) reloads the counter and clears stage 1.
// Configuration {RST_EN, LOCK, EN, LOAD} arrives through a handshake from the
// core domain; once LOCK is set further configuration is rejected (cfg_rej_o)
// until the next system reset (it cannot be disabled by runaway firmware).
// Reset: the fabric-paired reference reset (cleared with every SYSTEM reset),
// so the watchdog restarts disabled after the reset it caused.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_crt_wdog (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  input  wire logic        cfg_valid_i,
  input  wire logic [34:0] cfg_i,          // {rst_en, lock, en, load[31:0]}
  input  wire logic        kick_i,
  output logic [31:0]      count_o,
  output logic             en_o,
  output logic             lock_o,
  output logic             rst_en_o,
  output logic             irq_o,          // stage-1 warning (level)
  output logic             expire_o,       // stage-2 reset request (level, held)
  output logic             cfg_rej_o       // sticky: configuration refused while locked
);
  logic [31:0] load_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      load_q    <= 32'hFFFF_FFFF;
      count_o   <= 32'hFFFF_FFFF;
      en_o      <= 1'b0;
      lock_o    <= 1'b0;
      rst_en_o  <= 1'b0;
      irq_o     <= 1'b0;
      expire_o  <= 1'b0;
      cfg_rej_o <= 1'b0;
    end else begin
      if (cfg_valid_i) begin
        if (lock_o) begin
          cfg_rej_o <= 1'b1;
        end else begin
          {rst_en_o, lock_o, en_o, load_q} <= cfg_i;
          count_o <= cfg_i[31:0];
          irq_o   <= 1'b0;
        end
      end else if (!en_o) begin
        count_o <= load_q;
        irq_o   <= 1'b0;
      end else if (expire_o) begin
        count_o <= 32'd0;                       // hold until reset
      end else if (kick_i) begin
        count_o <= load_q;
        irq_o   <= 1'b0;
      end else if (count_o == 32'd0) begin
        count_o <= load_q;
        if (!irq_o)        irq_o    <= 1'b1;    // stage 1
        else if (rst_en_o) expire_o <= 1'b1;    // stage 2
      end else begin
        count_o <= count_o - 32'd1;
      end
    end
  end
endmodule

`default_nettype wire
