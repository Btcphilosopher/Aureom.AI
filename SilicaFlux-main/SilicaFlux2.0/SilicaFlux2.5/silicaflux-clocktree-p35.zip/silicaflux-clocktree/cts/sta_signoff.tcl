# =============================================================================
# SilicaFlux CLOCKTREE -- OpenSTA signoff-style timing run (multi-corner)
#
#   sta -exit cts/sta_signoff.tcl
#   env: CRT_CONFIG  = baseline | research          (default baseline)
#        CRT_MODE    = func_prects | func_postcts | test   (default func_prects)
#        CRT_NETLIST = netlist (default build/synth/ihp_sg13g2_<cfg>/netlist.v; after CTS use the
#                      OpenROAD write_verilog output)
#        CRT_SPEF    = optional extracted parasitics (post-route)
# Reports: reports/sta_opensta/<cfg>_<mode>.rpt
#
# STATUS: NOT EXECUTED here (OpenSTA could not be installed).  The same
# constraints were exercised with scripts/sf_sta.py (indicative).
# =============================================================================
set root [file normalize [file join [file dirname [info script]] ..]]
set cfg  [expr {[info exists ::env(CRT_CONFIG)] ? $::env(CRT_CONFIG) : "baseline"}]
set mode [expr {[info exists ::env(CRT_MODE)]   ? $::env(CRT_MODE)   : "func_prects"}]
set nl   [expr {[info exists ::env(CRT_NETLIST)] ? $::env(CRT_NETLIST) : "$root/build/synth/ihp_sg13g2_${cfg}/netlist.v"}]
set lib  "$root/third_party/ihp-sg13g2/lib"
set corners [dict create typ  "$lib/sg13g2_stdcell_typ_1p20V_25C.lib" \
                         slow "$lib/sg13g2_stdcell_slow_1p08V_125C.lib" \
                         fast "$lib/sg13g2_stdcell_fast_1p32V_m40C.lib"]
set rdir [expr {[info exists ::env(CRT_OUT)] ? $::env(CRT_OUT) : "$root/reports/sta_opensta"}]
file mkdir $rdir
set rpt "$rdir/${cfg}_${mode}.rpt"

# OpenSTA 3.1 replaced corners by scenes; keep both paths (TimingFlow finding)
if {[llength [info commands define_scene]]} {
  dict for {c f} $corners { read_liberty $f }
  read_verilog $nl
  link_design silicaflux_clock_reset_tree
  read_sdc "$root/constraints/sdc/silicaflux_crt_${cfg}_${mode}.sdc"
  dict for {c f} $corners { define_scene $c -mode default -liberty [file rootname [file tail $f]] }
} else {
  define_corners {*}[dict keys $corners]
  dict for {c f} $corners { read_liberty -corner $c $f }
  read_verilog $nl
  link_design silicaflux_clock_reset_tree
  read_sdc "$root/constraints/sdc/silicaflux_crt_${cfg}_${mode}.sdc"
}
if {[info exists ::env(CRT_SPEF)]} { read_spef $::env(CRT_SPEF) }

report_clock_properties                                                     > $rpt
check_setup -verbose -unconstrained_endpoints -multiple_clock -no_clock -loops >> $rpt
foreach c [dict keys $corners] {
  report_checks -corner $c -path_delay max -group_path_count 10 -digits 4 -fields {slew cap fanout} >> $rpt
  report_checks -corner $c -path_delay min -group_path_count 10 -digits 4 -fields {slew cap fanout} >> $rpt
  report_tns -digits 4                                                      >> $rpt
  report_wns -digits 4                                                      >> $rpt
}
report_checks -path_delay min_max -to [all_registers -async_pins] -group_path_count 5 -digits 4 >> $rpt
report_check_types -max_slew -max_capacitance -max_fanout -violators      >> $rpt
report_check_types -min_pulse_width -violators                            >> $rpt
puts "CRT OpenSTA report -> $rpt"
