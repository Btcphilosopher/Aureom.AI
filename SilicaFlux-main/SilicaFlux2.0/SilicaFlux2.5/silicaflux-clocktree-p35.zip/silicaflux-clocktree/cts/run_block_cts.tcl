# =============================================================================
# SilicaFlux CLOCKTREE -- OpenROAD block flow up to and including CTS
#
#   openroad -exit cts/run_block_cts.tcl
#   env: CRT_TECH   = ihp_sg13g2 (default) | sky130hd
#        CRT_CONFIG = baseline (default) | research
#        CRT_PLATFORM_DIR = technology collateral (default third_party/ihp-sg13g2)
#
# Stages: read -> floorplan -> tracks / pins / PDN -> global + detailed
# placement -> pre-CTS STA -> CTS (TritonCTS) -> clock-net repair -> legalise
# -> post-CTS STA with propagated clocks -> global route -> post-GRT STA ->
# reports.  Every report lands in reports/cts/<tech>_<config>/.
#
# STATUS: NOT EXECUTED.  OpenROAD could not be installed in the environment
# that produced this project (docs/06_CTS.md).  The script was syntax- and
# flow-checked with tclsh against command stubs (scripts/tcl_dryrun.tcl); the
# command options follow the OpenROAD documentation and the IHP SG13G2 ORFS
# platform scripts.  No clock-tree closure is claimed until it has run on a
# placed and routed database.
# =============================================================================
set root [file normalize [file join [file dirname [info script]] ..]]
set tech     [expr {[info exists ::env(CRT_TECH)]   ? $::env(CRT_TECH)   : "ihp_sg13g2"}]
set cfg      [expr {[info exists ::env(CRT_CONFIG)] ? $::env(CRT_CONFIG) : "baseline"}]
set platform [expr {[info exists ::env(CRT_PLATFORM_DIR)] ? $::env(CRT_PLATFORM_DIR) : "$root/third_party/ihp-sg13g2"}]
set out [expr {[info exists ::env(CRT_OUT)] ? $::env(CRT_OUT) : "$root/reports/cts/${tech}_${cfg}"}]
file mkdir $out
source "$root/cts/cts_config_${tech}.tcl"
source "$root/cts/report_cts_groups.tcl"
# the platform fastroute.tcl reads these (ORFS conventions)
set ::env(MIN_CLK_ROUTING_LAYER) [lindex [split $::crt(clock_layers) -] 0]

if {$tech eq "ihp_sg13g2"} {
  set tech_lef  "$platform/lef/sg13g2_tech.lef"
  set sc_lef    "$platform/lef/sg13g2_stdcell.lef"
  set libs [dict create typ  "$platform/lib/sg13g2_stdcell_typ_1p20V_25C.lib" \
                        slow "$platform/lib/sg13g2_stdcell_slow_1p08V_125C.lib" \
                        fast "$platform/lib/sg13g2_stdcell_fast_1p32V_m40C.lib"]
  set site CoreSite
  set ::env(MIN_ROUTING_LAYER) Metal2
  set ::env(MAX_ROUTING_LAYER) Metal5
  set pin_h Metal3 ; set pin_v Metal2
  set tie_hi {sg13g2_tiehi L_HI} ; set tie_lo {sg13g2_tielo L_LO}
  set fill  {sg13g2_fill_1 sg13g2_fill_2 sg13g2_decap_4 sg13g2_decap_8}
} else {
  set tech_lef  "$platform/lef/sky130_fd_sc_hd.tlef"
  set sc_lef    "$platform/lef/sky130_fd_sc_hd_merged.lef"
  set libs [dict create typ "$platform/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"]
  set site unithd
  set ::env(MIN_ROUTING_LAYER) met1
  set ::env(MAX_ROUTING_LAYER) met5
  set pin_h met3 ; set pin_v met2
  set tie_hi {sky130_fd_sc_hd__conb_1 HI} ; set tie_lo {sky130_fd_sc_hd__conb_1 LO}
  set fill  {sky130_fd_sc_hd__fill_1 sky130_fd_sc_hd__fill_2 sky130_fd_sc_hd__fill_4 sky130_fd_sc_hd__fill_8}
}

# ----------------------------------------------------------------------------- read
read_lef $tech_lef
read_lef $sc_lef
# multi-corner: OpenSTA 3.x scenes when available, define_corners otherwise (TimingFlow tcl/load_corners.tcl)
if {[llength [info commands define_corners]] && [dict size $libs] > 1} {
  define_corners {*}[dict keys $libs]
  dict for {c f} $libs { read_liberty -corner $c $f }
} else {
  dict for {c f} $libs { read_liberty $f }
}
read_verilog "$root/build/synth/${tech}_${cfg}/netlist.v"
link_design silicaflux_clock_reset_tree
read_sdc "$root/constraints/sdc/silicaflux_crt_${cfg}_func_prects.sdc"
source "$platform/$::crt(wire_rc_script)"
set_routing_layers -signal $::crt(signal_layers) -clock $::crt(clock_layers)
# the explicit technology cells (ICG, DFT reset mux, reset-combine) must survive every repair step
set_dont_touch [get_cells -hierarchical *u_cell]

# ----------------------------------------------------------------------------- floorplan
initialize_floorplan -utilization 45 -aspect_ratio 1.0 -core_space 10 -site $site
source "$platform/make_tracks.tcl"
place_pins -hor_layers $pin_h -ver_layers $pin_v
if {$tech eq "ihp_sg13g2"} {
  source "$platform/global_connect.tcl"
  source "$root/cts/pdn_block_ihp_sg13g2.tcl"
} else {
  add_global_connection -net VDD -pin_pattern {^VPWR$} -power
  add_global_connection -net VDD -pin_pattern {^VPB$}
  add_global_connection -net VSS -pin_pattern {^VGND$} -ground
  add_global_connection -net VSS -pin_pattern {^VNB$}
  source "$root/cts/pdn_block_sky130hd.tcl"
  tapcell -distance 14 -tapcell_master sky130_fd_sc_hd__tapvpwrvgnd_1
}
pdngen

# ----------------------------------------------------------------------------- placement
global_placement -density 0.60
repair_tie_fanout -separation 5 [lindex $tie_hi 0]/[lindex $tie_hi 1]
repair_tie_fanout -separation 5 [lindex $tie_lo 0]/[lindex $tie_lo 1]
estimate_parasitics -placement
repair_design
detailed_placement
check_placement -verbose
estimate_parasitics -placement
crt_report_timing $out pre_cts

# ----------------------------------------------------------------------------- clock-tree synthesis
# Gated sub-trees: TritonCTS builds a tree on every clock net, the ICG outputs
# (clk_core_o, clk_br_o[*]) included; -balance_levels balances the ICG levels
# against the ungated root sinks (sink groups in cts_config_<tech>.tcl).
clock_tree_synthesis \
  -root_buf $::crt(root_buffer) \
  -buf_list $::crt(clock_buffers) \
  -sink_clustering_enable \
  -sink_clustering_size $::crt(sink_cluster_size) \
  -sink_clustering_max_diameter $::crt(sink_cluster_diameter) \
  -balance_levels
set_propagated_clock [all_clocks]
repair_clock_nets
detailed_placement
estimate_parasitics -placement
report_cts -out_file "$out/cts_summary.rpt"
crt_report_clock_tree $out post_cts
crt_report_timing $out post_cts
# hold fixing after CTS (synchroniser chains have no logic between stages)
repair_timing -hold -hold_margin 0.05
detailed_placement
estimate_parasitics -placement
crt_report_timing $out post_cts_hold_repaired

# ----------------------------------------------------------------------------- global route
source "$platform/fastroute.tcl"
# fastroute.tcl re-sets the layer ranges: restore the project's clock layers
set_routing_layers -signal $::crt(signal_layers) -clock $::crt(clock_layers)
global_route -congestion_iterations 50 -verbose
estimate_parasitics -global_routing
crt_report_clock_tree $out post_grt
crt_report_timing $out post_grt
write_def "$out/silicaflux_crt.def"
write_db  "$out/silicaflux_crt.odb"
puts "CRT CTS FLOW DONE -> $out  (detailed routing, extraction and signoff STA not included)"
