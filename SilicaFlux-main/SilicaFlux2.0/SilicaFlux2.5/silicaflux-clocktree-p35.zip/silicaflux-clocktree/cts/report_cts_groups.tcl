# =============================================================================
# SilicaFlux CLOCKTREE -- clock-tree and timing report procs (OpenROAD / OpenSTA)
# Sourced by cts/run_block_cts.tcl.  NOT EXECUTED in the producing environment.
# Probing with [info commands] keeps the procs usable across OpenSTA revisions
# (TimingFlow docs/TOOLS.md: report_clock_latency / report_check_types differ).
# =============================================================================

proc crt_has {cmd} { return [expr {[llength [info commands $cmd]] > 0}] }

# Timing reports for one stage: clocks, unconstrained endpoints, setup / hold,
# DRV, and path groups (register, recovery / removal, clock gating, CDC max delay).
proc crt_report_timing {out stage} {
  set f "$out/${stage}_timing.rpt"
  report_clock_properties                              > $f
  if {[crt_has check_setup]} {
    check_setup -verbose -unconstrained_endpoints -multiple_clock -no_clock -loops -generated_clocks >> $f
  }
  report_checks -path_delay max -group_path_count 5 -fields {slew cap input_pins fanout} -digits 4 >> $f
  report_checks -path_delay min -group_path_count 5 -fields {slew cap input_pins fanout} -digits 4 >> $f
  # asynchronous reset release (recovery / removal) and clock-gating checks
  report_checks -path_delay max -to [all_registers -async_pins] -group_path_count 3 -digits 4 >> $f
  report_checks -path_delay min -to [all_registers -async_pins] -group_path_count 3 -digits 4 >> $f
  # bounded clock-domain crossings (set_max_delay -ignore_clock_latency)
  foreach a [get_clocks *] {
    foreach b [get_clocks *] {
      if {[get_name $a] ne [get_name $b]} {
        report_checks -from $a -to $b -path_delay max -group_path_count 2 -digits 4 >> $f
      }
    }
  }
  report_tns                                           >> $f
  report_wns                                           >> $f
  report_worst_slack -max                              >> $f
  report_worst_slack -min                              >> $f
  report_check_types -max_slew -max_capacitance -max_fanout -violators >> $f
  puts "CRT: $stage timing -> $f"
}

# Clock-tree reports after CTS: skew / latency per clock, then insertion delay
# per sink group (ungated root sinks, behind the root ICG, behind a branch ICG)
# compared against the budgets in config/clock_spec.yaml.
proc crt_report_clock_tree {out stage} {
  set f "$out/${stage}_clock_tree.rpt"
  report_clock_skew -setup -digits 4                   > $f
  report_clock_skew -hold  -digits 4                   >> $f
  if {[crt_has report_clock_latency]} { report_clock_latency -digits 4 >> $f }
  report_clock_min_period                              >> $f
  set ch [open $f a]
  puts $ch "\n# insertion delay per sink group (clock-pin arrival, propagated clocks)"
  puts $ch [format "%-14s %-9s %6s %10s %10s %10s  %s" group clock pins min_ns max_ns spread_ns budget]
  foreach g $::crt(sink_groups) {
    lassign $g gname clk through
    set lat {}
    foreach pin [all_registers -clock $clk -clock_pins] {
      # classify by the gating cells on the clock path: none / root ICG / root + branch ICG
      set path_icgs [crt_icgs_on_clock_path $pin]
      if {[llength $path_icgs] != [llength $through]} { continue }
      set a [crt_pin_arrival $pin]
      if {$a ne ""} { lappend lat $a }
    }
    if {![llength $lat]} { continue }
    set mn [tcl::mathfunc::min {*}$lat] ; set mx [tcl::mathfunc::max {*}$lat]
    set bud [expr {[info exists ::crt(budget,$clk)] ? $::crt(budget,$clk) : "-"}]
    puts $ch [format "%-14s %-9s %6d %10.4f %10.4f %10.4f  %s" $gname $clk [llength $lat] $mn $mx [expr {$mx - $mn}] $bud]
  }
  close $ch
  puts "CRT: $stage clock tree -> $f"
}

# ICG cells between a register clock pin and its clock root (walk the fan-in
# through buffers / inverters / ICGs).
proc crt_icgs_on_clock_path {pin} {
  set icgs {}
  set cur $pin
  for {set i 0} {$i < 64} {incr i} {
    set net [get_nets -of_objects $cur]
    set drv [get_pins -of_objects $net -filter "direction==output"]
    if {![llength $drv]} { break }
    set inst [get_cells -of_objects $drv]
    set ref [get_property $inst ref_name]
    if {[string match *lgcp* $ref] || [string match *dlclkp* $ref]} { lappend icgs [get_name $inst] ; set in CLK } else { set in A }
    set nxt [get_pins -quiet [get_name $inst]/$in]
    if {![llength $nxt]} { break }
    set cur $nxt
  }
  return $icgs
}

proc crt_pin_arrival {pin} {
  if {[catch {set v [get_property $pin arrival_max_rise]}]} { return "" }
  return $v
}
