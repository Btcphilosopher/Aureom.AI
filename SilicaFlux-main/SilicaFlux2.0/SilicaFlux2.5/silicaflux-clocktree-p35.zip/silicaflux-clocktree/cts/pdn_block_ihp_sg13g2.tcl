# SilicaFlux CLOCKTREE -- block-level PDN for IHP SG13G2 (no pad ring).
# Derived from ORFS ihp-sg13g2/pdn.tcl: same layers, widths and pitches, the
# ring is a core ring (no -connect_to_pads) so the block can be analysed alone.
# Metal5 carries no PDN: it stays free for the clock tree (clock layers Metal3-Metal5).
set_voltage_domain -name {CORE} -power {VDD} -ground {VSS}
define_pdn_grid -name {grid} -voltage_domains {CORE}
add_pdn_ring -grid {grid} -layers {TopMetal1 TopMetal2} -widths {5.0} -spacings {2.0} -core_offsets {4.5}
add_pdn_stripe -grid {grid} -layer {Metal1} -width {0.44} -pitch {7.56} -offset {0} -followpins -extend_to_core_ring
add_pdn_stripe -grid {grid} -layer {TopMetal1} -width {2.200} -pitch {75.6} -offset {13.600} -extend_to_core_ring
add_pdn_stripe -grid {grid} -layer {TopMetal2} -width {2.200} -pitch {75.6} -offset {13.600} -extend_to_core_ring
add_pdn_connect -grid {grid} -layers {Metal1 TopMetal1}
add_pdn_connect -grid {grid} -layers {TopMetal1 TopMetal2}
