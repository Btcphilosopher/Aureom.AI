// NEGATIVE: binary multi-bit counter through per-bit 2-flop synchronisers (CDC-MULTIBIT_SYNC, unwaived)
module neg_multibit_bus (input logic clka, clkb, rst_ni, d_i, en_i, output logic [3:0] q_o);
  logic [3:0] cnt_q, s0, s1;
  always_ff @(posedge clka or negedge rst_ni) if (!rst_ni) cnt_q <= 0; else if (en_i) cnt_q <= cnt_q + 1'b1;
  always_ff @(posedge clkb or negedge rst_ni) if (!rst_ni) {s1, s0} <= 0; else {s1, s0} <= {s0, cnt_q};
  assign q_o = s1;
endmodule
