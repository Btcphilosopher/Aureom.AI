// NEGATIVE: same clock, the source can be reset by a functional request while
// the destination keeps running, no isolation stage (RDC-DATA, unwaived)
module neg_rdc_data (input logic clka, clkb, rst_ni, d_i, en_i, output logic [1:0] q_o);
  logic req_n, r0, r1, a_q;
  always_ff @(posedge clka or negedge rst_ni) if (!rst_ni) req_n <= 0; else req_n <= en_i;
  always_ff @(posedge clka or negedge req_n) if (!req_n) {r1, r0} <= 0; else {r1, r0} <= {r0, 1'b1};
  always_ff @(posedge clka or negedge r1) if (!r1) a_q <= 0; else a_q <= d_i;
  always_ff @(posedge clka or negedge rst_ni) if (!rst_ni) q_o <= 0; else q_o <= {q_o[0] ^ a_q, a_q ^ d_i};
endmodule
