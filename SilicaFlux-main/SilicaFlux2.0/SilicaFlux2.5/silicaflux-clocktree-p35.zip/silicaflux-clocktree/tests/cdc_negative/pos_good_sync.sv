// POSITIVE control: reset synchroniser per clock, clean 2-flop synchroniser (must PASS)
module pos_good_sync (input logic clka, clkb, rst_ni, d_i, en_i, output logic q_o);
  logic a_q, s0, s1;
  logic [1:0] rsa, rsb;
  always_ff @(posedge clka or negedge rst_ni) if (!rst_ni) rsa <= 0; else rsa <= {rsa[0], 1'b1};
  always_ff @(posedge clkb or negedge rst_ni) if (!rst_ni) rsb <= 0; else rsb <= {rsb[0], 1'b1};
  always_ff @(posedge clka or negedge rsa[1]) if (!rsa[1]) a_q <= 0; else a_q <= d_i;
  always_ff @(posedge clkb or negedge rsb[1]) if (!rsb[1]) {s1, s0} <= 0; else {s1, s0} <= {s0, a_q};
  always_ff @(posedge clkb or negedge rsb[1]) if (!rsb[1]) q_o <= 0; else q_o <= s1;
endmodule
