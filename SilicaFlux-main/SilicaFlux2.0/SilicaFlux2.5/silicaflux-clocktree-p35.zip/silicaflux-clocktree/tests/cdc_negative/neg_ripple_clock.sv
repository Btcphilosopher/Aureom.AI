// NEGATIVE: a flop clocked by another flop's output (ripple clock, not a
// declared clock and not an ICG) -- CLK-UNCLOCKED
module neg_ripple_clock (input logic clka, clkb, rst_ni, d_i, en_i, output logic q_o);
  logic div_q;
  always_ff @(posedge clka or negedge rst_ni) if (!rst_ni) div_q <= 0; else div_q <= ~div_q;
  always_ff @(posedge div_q or negedge rst_ni) if (!rst_ni) q_o <= 0; else q_o <= d_i;
endmodule
