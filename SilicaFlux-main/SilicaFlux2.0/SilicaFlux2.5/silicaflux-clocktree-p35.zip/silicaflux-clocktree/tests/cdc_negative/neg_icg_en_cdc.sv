// NEGATIVE: ICG enable launched from the other clock domain (CLK-ICG-EN-CDC)
module neg_icg_en_cdc (input logic clka, clkb, rst_ni, d_i, en_i, output logic q_o);
  logic en_q, gclk;
  always_ff @(posedge clkb or negedge rst_ni) if (!rst_ni) en_q <= 0; else en_q <= en_i;
  sg13g2_slgcp_1 u_icg (.CLK(clka), .GATE(en_q), .SCE(1'b0), .GCLK(gclk));
  always_ff @(posedge gclk or negedge rst_ni) if (!rst_ni) q_o <= 0; else q_o <= d_i;
endmodule
