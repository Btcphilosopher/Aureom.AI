// NEGATIVE: clock gated with an AND gate (must fire CLK-COMB-GATING)
module neg_comb_clkgate (input logic clka, clkb, rst_ni, d_i, en_i, output logic q_o);
  logic en_q;
  always_ff @(posedge clka or negedge rst_ni) if (!rst_ni) en_q <= 0; else en_q <= en_i;
  wire gclk = clka & en_q;                       // unsafe combinational gating
  always_ff @(posedge gclk or negedge rst_ni) if (!rst_ni) q_o <= 0; else q_o <= d_i;
endmodule
