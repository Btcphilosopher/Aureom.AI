// NEGATIVE: a clka request flop resets clkb logic directly, no reset synchroniser (RDC-ASYNC-RELEASE)
module neg_async_release (input logic clka, clkb, rst_ni, d_i, en_i, output logic q_o);
  logic req_n;
  always_ff @(posedge clka or negedge rst_ni) if (!rst_ni) req_n <= 0; else req_n <= en_i;
  always_ff @(posedge clkb or negedge req_n) if (!req_n) q_o <= 0; else q_o <= ~q_o;
endmodule
