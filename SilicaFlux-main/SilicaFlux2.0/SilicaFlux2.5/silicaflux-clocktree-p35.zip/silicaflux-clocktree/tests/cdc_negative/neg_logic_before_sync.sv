// NEGATIVE: combinational logic between the source domain and a synchroniser (CDC-LOGIC_BEFORE_SYNC)
module neg_logic_before_sync (input logic clka, clkb, rst_ni, d_i, en_i, output logic q_o);
  logic a_q, b_q, s0, s1;
  always_ff @(posedge clka or negedge rst_ni) if (!rst_ni) {a_q, b_q} <= 0; else {a_q, b_q} <= {d_i, en_i};
  always_ff @(posedge clkb or negedge rst_ni) if (!rst_ni) {s1, s0} <= 0; else {s1, s0} <= {s0, a_q & b_q};
  assign q_o = s1;
endmodule
