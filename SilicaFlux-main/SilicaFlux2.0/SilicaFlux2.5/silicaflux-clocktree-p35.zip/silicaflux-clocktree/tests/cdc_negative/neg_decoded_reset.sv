// NEGATIVE: ControlCore F-04 pattern -- a decoded down-counter (str != 0) AND-ed
// with the POR drives the asynchronous input of a reset synchroniser (RDC-COMB)
module neg_decoded_reset (input logic clka, clkb, rst_ni, d_i, en_i, output logic q_o);
  logic [5:0] str_q;
  logic [1:0] rs;
  always_ff @(posedge clka or negedge rst_ni)
    if (!rst_ni) str_q <= 0; else if (str_q != 0) str_q <= str_q - 1'b1; else if (en_i) str_q <= 6'd16;
  wire sys_rst_n = rst_ni && !(str_q != 6'd0);
  always_ff @(posedge clka or negedge sys_rst_n) if (!sys_rst_n) rs <= 0; else rs <= {rs[0], 1'b1};
  always_ff @(posedge clka or negedge rs[1]) if (!rs[1]) q_o <= 0; else q_o <= d_i;
endmodule
