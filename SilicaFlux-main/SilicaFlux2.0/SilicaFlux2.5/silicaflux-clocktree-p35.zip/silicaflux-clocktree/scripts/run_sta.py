#!/usr/bin/env python3
"""Run sf_sta over configurations x modes x corners and write reports/sta/STA_SUMMARY.md.
Indicative only (see scripts/sf_sta.py); the OpenSTA signoff script is cts/sta_signoff.tcl."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LIB = ROOT / "third_party/ihp-sg13g2/lib"
CORNERS = {"typ": "sg13g2_stdcell_typ_1p20V_25C.lib", "slow": "sg13g2_stdcell_slow_1p08V_125C.lib",
           "fast": "sg13g2_stdcell_fast_1p32V_m40C.lib"}
RUNS = []
for cfg in ("baseline", "research"):
    for mode in ("func_prects", "test"):
        for corner in CORNERS:
            RUNS.append((cfg, mode, corner, "ideal", 0.0))
    RUNS.append((cfg, "func_prects", "slow", "ideal", 20.0))          # wire-load sensitivity
    RUNS.append((cfg, "func_postcts", "typ", "propagated", 0.0))      # ICG insertion (unbuffered tree)


def main():
    rows = []
    ok = True
    for cfg, mode, corner, cm, wire in RUNS:
        tag = f"{cfg}_{mode}_{corner}" + (f"_wire{int(wire)}" if wire else "") + ("_prop" if cm == "propagated" else "")
        out = ROOT / "reports/sta" / f"{tag}.json"
        cmd = [sys.executable, str(ROOT / "scripts/sf_sta.py"), "--netlist",
               str(ROOT / f"build/synth/ihp_sg13g2_{cfg}/netlist.json"), "--lib", str(LIB / CORNERS[corner]),
               "--corner", corner, "--cons", str(ROOT / f"constraints/json/silicaflux_crt_{cfg}_{mode}.json"),
               "--clock-mode", cm, "--wire-um", str(wire), "--out", str(out)]
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        print(p.stdout.strip())
        if p.returncode:
            ok = False
            continue
        r = json.loads(out.read_text())
        rows.append((tag, cfg, mode, corner, cm, wire, r))
        if cm == "ideal" and not wire:          # gating runs; sensitivity / propagated runs are informational
            ok &= r["verdict"]["violations"] == 0 and r["verdict"]["unconstrained_endpoints"] == 0
    L = ["# Timing check summary (sf_sta -- indicative, NOT signoff)", "",
         "OpenSTA / OpenROAD could not be installed in this environment; these numbers come from the in-house",
         "NLDM checker (scripts/sf_sta.py) on the Yosys netlist mapped to the IHP SG13G2 Liberty, pin-capacitance",
         "loads, an estimated buffer tree on nets with > 16 sinks, ideal clocks unless marked `propagated`.",
         "Run cts/sta_signoff.tcl with OpenSTA for signoff.", "",
         "| run | kind | violations | unconstrained | false-path-only | worst setup group (slack ns) | worst hold (ns) | Fmax* reg2reg (MHz) |",
         "|---|---|---|---|---|---|---|---|"]
    for tag, cfg, mode, corner, cm, wire, r in rows:
        gs = r["groups"]
        ws = min(((k, g["setup_wns"]) for k, g in gs.items() if g["setup_wns"] is not None), key=lambda x: x[1])
        wh = min((g["hold_wns"] for g in gs.values() if g["hold_wns"] is not None), default=None)
        kind = "gating" if cm == "ideal" and not wire else ("sensitivity: +%d um wire / fanout" % wire if wire
                                                             else "informational: UNBUFFERED propagated clocks (no CTS)")
        L.append(f"| {tag} | {kind} | {r['verdict']['violations']} | {r['verdict']['unconstrained_endpoints']} | "
                 f"{r['verdict']['false_path_only_endpoints']} | {ws[0]}: {ws[1]:.3f} | {wh:.3f} | "
                 f"{', '.join(f'{k} {v}' for k, v in r['derived_fmax_mhz'].items())} |")
    L += ["", "Fmax* = 1 / (T - worst reg2reg setup slack): DERIVED from ideal-clock, pin-capacitance analysis of",
          "this block only; not a measured or achievable die frequency.", ""]
    base = next((r for t, c, m, co, cm, w, r in rows if t == "baseline_func_prects_slow"), None)
    if base:
        L += ["## Path groups -- baseline, functional, pre-CTS, slow corner (1.08 V, 125 C)", "",
              "| group | endpoints | setup WNS (ns) | hold WNS (ns) | raw WNS without estimated buffer trees (ns) |",
              "|---|---|---|---|---|"]
        for k, g in base["groups"].items():
            raw = base["groups_raw_no_repair"].get(k, {}).get("setup_wns")
            L.append(f"| {k} | {g['endpoints']} | {g['setup_wns']} | {g['hold_wns']} | {raw} |")
        L += ["", "### Endpoints constrained only by justified false paths (asynchronous ports)", ""]
        for u in base["unconstrained"]:
            L.append(f"* `{u['endpoint']}` ({u['kind']}): {u['reason']}")
        L += ["", "### Worst setup paths (slow)", ""]
        for w in base["worst_setup"][:4]:
            L.append(f"* **{w['group']}** `{w['endpoint']}` slack {w['slack']:.3f} ns: " + " -> ".join(w["path"][:10]))
    prop = next((r for t, c, m, co, cm, w, r in rows if t == "research_func_postcts_typ_prop"), None)
    if prop:
        L += ["", "## Clock insertion through the ICGs (research, typ, unbuffered, indicative)", "",
              "| clock sinks | pins | latency min (ns) | latency max (ns) |", "|---|---|---|---|"]
        for k, v in prop["clock_latency_by_icg_level"].items():
            L.append(f"| {k} | {v['pins']} | {v['min_ns']} | {v['max_ns']} |")
        L += ["", "Pre-CTS, a gated branch sits one or two ICG delays behind the ungated root sinks: CTS must",
              "balance these sink groups (cts/ configuration, skew budget in config/clock_spec.yaml)."]
    (ROOT / "reports/sta/STA_SUMMARY.md").write_text("\n".join(L) + "\n")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
