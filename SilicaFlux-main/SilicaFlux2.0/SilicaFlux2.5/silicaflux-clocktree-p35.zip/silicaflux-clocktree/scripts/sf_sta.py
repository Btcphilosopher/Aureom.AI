#!/usr/bin/env python3
"""sf_sta -- SilicaFlux CLOCKTREE in-house static timing CHECK (not signoff).

WHY THIS EXISTS: OpenSTA / OpenROAD could not be installed in this
environment (a prebuilt package and a source build were both refused), so
the constraints are exercised by this NLDM graph analysis instead.  The same
constraints are emitted as SDC for OpenSTA (cts/sta_signoff.tcl, ready to
run).  Treat every number here as INDICATIVE.

Model
  * netlist: flattened Yosys netlist mapped to the IHP SG13G2 Liberty
  * delays: Liberty NLDM tables (cell_rise/fall, transitions), rise / fall and
    unateness tracked separately; corner = the Liberty file given
  * loads: pin capacitance (+ optional wire estimate per fanout, --wire-um)
  * high-fanout nets (> --max-fanout sinks): an ESTIMATED balanced tree of
    --tree-buf buffers (what repair_design would build); raw numbers are kept
  * clocks: ideal (pre-CTS: zero latency, set_clock_transition) or
    'propagated' through the ICGs with pin-cap loads (unbuffered, indicative)
  * constraints: constraints/json/<sdc>.json, generated with the SDC
  * no SI, no OCV / derates, no CRPR, no wire parasitics from extraction
Checks: reg->reg / in->reg / reg->out setup & hold per clock, recovery /
removal on asynchronous pins, clock-gating setup / hold on ICG enables,
set_max_delay on every asynchronous-clock crossing, unconstrained endpoints,
max-transition.
"""
import argparse
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sfa.liberty import Library          # noqa: E402
from sfa.netlist import Netlist          # noqa: E402

INF = float("inf")
R, F = 0, 1


class STA:
    def __init__(self, lib, net, cons, wire_um=0.0, max_fanout=16, tree_buf="sg13g2_buf_8",
                 clock_mode="ideal", c_per_um=1.73072e-4):
        self.L, self.N, self.C = lib, net, cons
        self.wire_um, self.max_fanout, self.c_per_um = wire_um, max_fanout, c_per_um
        self.tree = lib.cells.get(tree_buf)
        self.tree_name = tree_buf
        self.clock_mode = clock_mode
        net.case_analysis(cons["case"])
        self.clock_ports = {c: v["port"] for c, v in cons["clocks"].items()}
        self.clk_of, self.csinks = net.propagate_clocks(self.clock_ports)
        self.ck = {inst: (c, inv, path) for inst, pin, c, inv, path in self.csinks}
        self.clock_bits = set(self.clk_of)
        self.load_cache = {}
        self.port_load = cons["load_pf"]
        self.drv_cell = lib.cells.get(cons["driving_cell"]["ihp_sg13g2"][0])
        self.drv_pin = cons["driving_cell"]["ihp_sg13g2"][1]
        self.trees = {}

    # ------------------------------------------------------------------ loads
    def sinks_caps(self, b):
        caps = []
        for kind, inst, pin in self.N.sinks.get(b, []):
            if kind == "cell":
                caps.append(self.N.cells[inst]["lc"].pins[pin].cap)
            else:
                caps.append(self.port_load)
        return caps

    def load(self, b):
        if b in self.load_cache:
            return self.load_cache[b]
        caps = self.sinks_caps(b)
        w = self.wire_um * len(caps) * self.c_per_um
        if len(caps) > self.max_fanout and self.tree is not None and b not in self.clock_bits:
            nbuf = math.ceil(len(caps) / 8)
            levels = []
            cnt = nbuf
            while cnt > 8:
                levels.append(cnt)
                cnt = math.ceil(cnt / 8)
            levels.append(cnt)
            self.trees[b] = {"sinks": len(caps), "leaf_buffers": nbuf, "levels": len(levels)}
            ld = cnt * self.tree.pins["A"].cap + w / max(1, len(levels))
        else:
            ld = sum(caps) + w
        self.load_cache[b] = ld
        return ld

    def tree_delay(self, b, slew_in):
        """Extra delay / slew of the estimated buffer tree on high-fanout net b."""
        if b not in self.trees:
            return 0.0, slew_in
        t = self.trees[b]
        caps = self.sinks_caps(b)
        avg = sum(caps) / len(caps)
        arc = self.tree.pins["X"].arcs[0]
        levels = t["levels"]
        d, s = 0.0, slew_in
        # upper levels drive 8 buffers, the leaf level drives 8 sinks
        for lvl in range(levels):
            ld = 8 * (avg if lvl == levels - 1 else self.tree.pins["A"].cap)
            d += max(arc.tables["cell_rise"].at(slew=s, load=ld), arc.tables["cell_fall"].at(slew=s, load=ld))
            s = max(arc.tables["rise_transition"].at(slew=s, load=ld), arc.tables["fall_transition"].at(slew=s, load=ld))
        return d, s

    # ------------------------------------------------------------------ clocks
    def clock_arrival(self, inst):
        """(latency, slew) of the clock at a sequential / ICG clock pin."""
        cname, inv, path = self.ck[inst]
        tr = self.C["clocks"][cname]["transition"] or 0.15
        if self.clock_mode == "ideal":
            return 0.0, tr
        lat, s = 0.0, tr
        for pi, ptype in path:
            c = self.N.cells[pi]
            lc = c["lc"]
            op = lc.outputs()[0]
            ob = c["conn"][op]
            arc = next(a for a in lc.pins[op].arcs if a.type == "combinational")
            ld = sum(self.sinks_caps(ob))
            lat += arc.tables["cell_rise"].at(slew=s, load=ld)
            s = arc.tables["rise_transition"].at(slew=s, load=ld)
        return lat, s

    # ------------------------------------------------------------------ propagation
    def run(self):
        N, L = self.N, self.L
        arr = defaultdict(dict)          # bit -> clock -> [maxR, maxF, minR, minF, sR, sF, sminR, sminF]
        pred = {}                        # (bit, clock, edge) -> (prev_bit, prev_edge, inst, delay)
        false_ports = set(self.C["false_from_ports"])
        in_delay = {}
        for g in self.C["inputs"]:
            for b in N.port_bits(g["ports"]):
                in_delay.setdefault(b, []).append((g["clock"], g["max"], g["min"]))
        self.false_only = set()

        def upd(b, clk, vals, pr=None):
            cur = arr[b].get(clk)
            if cur is None:
                arr[b][clk] = list(vals)
                for e in (R, F):
                    pred[(b, clk, e)] = pr[e] if pr else None
                return
            for e in (R, F):
                if vals[e] > cur[e]:
                    cur[e] = vals[e]
                    cur[4 + e] = vals[4 + e]
                    pred[(b, clk, e)] = pr[e] if pr else None
                if vals[2 + e] < cur[2 + e]:
                    cur[2 + e] = vals[2 + e]
                    cur[6 + e] = vals[6 + e]

        # start points: input ports
        for pname, (d, bits) in N.ports.items():
            if d != "input":
                continue
            for b in bits:
                if b in self.clock_bits or N.value(b) is not None:
                    continue
                if pname in false_ports:
                    continue
                for clk, mx, mn in in_delay.get(b, []):
                    if clk not in self.C["clocks"]:
                        continue
                    arc = self.drv_cell.pins[self.drv_pin].arcs[0]
                    ld = self.load(b)
                    s_in = 0.15
                    dr = arc.tables["cell_rise"].at(slew=s_in, load=ld)
                    df = arc.tables["cell_fall"].at(slew=s_in, load=ld)
                    sr = arc.tables["rise_transition"].at(slew=s_in, load=ld)
                    sf = arc.tables["fall_transition"].at(slew=s_in, load=ld)
                    td, ts = self.tree_delay(b, max(sr, sf))
                    upd(b, clk + "@in", [mx + dr + td, mx + df + td, mn + dr + td, mn + df + td,
                                 ts if td else sr, ts if td else sf, sr, sf],
                        ({"start": f"port {pname}"}, {"start": f"port {pname}"}))
        # start points: flop outputs (clock -> Q)
        for inst, c in N.cells.items():
            lc = c["lc"]
            if not lc.is_seq() or inst not in self.ck:
                continue
            clk = self.ck[inst][0]
            lat, cs = self.clock_arrival(inst)
            for op in lc.outputs():
                b = c["conn"].get(op)
                if not isinstance(b, int) or N.value(b) is not None:
                    continue
                arcs = [a for a in lc.pins[op].arcs if a.type == "rising_edge"]
                if not arcs:
                    continue
                ld = self.load(b)
                dr = max(a.tables["cell_rise"].at(slew=cs, load=ld) for a in arcs if "cell_rise" in a.tables)
                df = max(a.tables["cell_fall"].at(slew=cs, load=ld) for a in arcs if "cell_fall" in a.tables)
                sr = max(a.tables["rise_transition"].at(slew=cs, load=ld) for a in arcs if "rise_transition" in a.tables)
                sf = max(a.tables["fall_transition"].at(slew=cs, load=ld) for a in arcs if "fall_transition" in a.tables)
                td, ts = self.tree_delay(b, max(sr, sf))
                st = {"start": f"{N.bit_name(b)} ({clk} {c['type']})", "clk_q": max(dr, df), "lat": lat}
                upd(b, clk, [lat + dr + td, lat + df + td, lat + dr + td, lat + df + td,
                             ts if td else sr, ts if td else sf, sr, sf], (st, st))
        # combinational levelisation (Kahn on cells)
        comb = {}
        for inst, c in N.cells.items():
            lc = c["lc"]
            if lc.is_seq() or lc.icg or not lc.inputs():
                continue
            outs = [p for p in lc.outputs() if isinstance(c["conn"].get(p), int)]
            if not outs:
                continue
            comb[inst] = outs
        driven_by = {}
        for inst, outs in comb.items():
            for p in outs:
                driven_by[self.N.cells[inst]["conn"][p]] = inst
        indeg = {}
        users = defaultdict(list)
        for inst in comb:
            c = N.cells[inst]
            deps = set()
            for ip in c["lc"].inputs():
                b = c["conn"].get(ip)
                if isinstance(b, int) and b in driven_by:
                    deps.add(driven_by[b])
            indeg[inst] = len(deps)
            for d in deps:
                users[d].append(inst)
        ready = [i for i, d in indeg.items() if d == 0]
        order = []
        while ready:
            i = ready.pop()
            order.append(i)
            for u in users[i]:
                indeg[u] -= 1
                if indeg[u] == 0:
                    ready.append(u)
        self.loops = len(comb) - len(order)
        for inst in order:
            c = N.cells[inst]
            lc = c["lc"]
            for op in comb[inst]:
                ob = c["conn"][op]
                if ob in self.clock_bits or N.value(ob) is not None:
                    continue
                ld = self.load(ob)
                for arc in lc.pins[op].arcs:
                    if arc.type not in ("combinational", "combinational_rise", "combinational_fall"):
                        continue
                    for ip in arc.related:
                        ib = c["conn"].get(ip)
                        if not isinstance(ib, int) or ib not in arr or not N.arc_live(inst, ip, op):
                            continue
                        for clk, v in list(arr[ib].items()):
                            out = [-INF, -INF, INF, INF, 0.0, 0.0, 0.0, 0.0]
                            prr = [None, None]
                            for oe in (R, F):
                                tname = "cell_rise" if oe == R else "cell_fall"
                                sname = "rise_transition" if oe == R else "fall_transition"
                                if tname not in arc.tables:
                                    continue
                                ies = {"positive_unate": [oe], "negative_unate": [1 - oe]}.get(arc.sense, [R, F])
                                for ie in ies:
                                    if v[ie] == -INF:
                                        continue
                                    dmax = arc.tables[tname].at(slew=v[4 + ie], load=ld)
                                    smax = arc.tables[sname].at(slew=v[4 + ie], load=ld)
                                    dmin = arc.tables[tname].at(slew=v[6 + ie], load=ld)
                                    smin = arc.tables[sname].at(slew=v[6 + ie], load=ld)
                                    td, ts = self.tree_delay(ob, smax)
                                    if v[ie] + dmax + td > out[oe]:
                                        out[oe] = v[ie] + dmax + td
                                        out[4 + oe] = ts if td else smax
                                        prr[oe] = {"prev": ib, "prev_edge": ie, "inst": inst, "type": c["type"],
                                                   "delay": dmax + td}
                                    if v[2 + ie] + dmin + td < out[2 + oe]:
                                        out[2 + oe] = v[2 + ie] + dmin + td
                                        out[6 + oe] = smin
                            if out[R] > -INF or out[F] > -INF:
                                upd(ob, clk, out, (prr[R], prr[F]))
        self.arr, self.pred = arr, pred
        return self

    # ------------------------------------------------------------------ checks
    def path(self, b, clk, e, limit=60):
        steps = []
        cur = (b, clk, e)
        while limit:
            limit -= 1
            p = self.pred.get(cur)
            if p is None:
                break
            if "start" in p:
                steps.append(p["start"])
                break
            steps.append(f"{p['type']} -> {self.N.bit_name(cur[0])} (+{p['delay']:.3f})")
            cur = (p["prev"], clk, p["prev_edge"])
        return list(reversed(steps))

    def checks(self):
        N, C = self.N, self.C
        res = []
        unconstrained = []
        maxd = {(m["from"], m["to"]): m["value"] for m in C["max_delay"]}
        hold_false = {tuple(x) for x in C["hold_false"]}
        false_ports = set(C["false_from_ports"])

        def evaluate(kind, endpoint, cap_clk, data_bit, setup_tab, hold_tab, cap_lat, cap_slew, edges=(R, F)):
            if data_bit is None or not isinstance(data_bit, int) or N.value(data_bit) is not None:
                return
            a = self.arr.get(data_bit, {})
            if not a:
                srcs, _ = N.fanin_sources(data_bit)
                why = "false-path ports only" if srcs and all(s[0] == "const" or (s[0] == "port" and s[1] in false_ports)
                                                              for s in srcs) else "no clocked startpoint"
                unconstrained.append({"endpoint": endpoint, "kind": kind, "reason": why})
                return
            cdef = C["clocks"][cap_clk]
            for lkey, v in a.items():
                lclk, frm = (lkey[:-3], "in") if lkey.endswith("@in") else (lkey, "reg")
                for e in edges:
                    if v[e] == -INF:
                        continue
                    st = setup_tab.get("rise_constraint" if e == R else "fall_constraint") if setup_tab else None
                    su = st.at(rel_slew=cap_slew, con_slew=v[4 + e]) if st else 0.0
                    if lclk == cap_clk:
                        req = cdef["period"] + cap_lat - su - cdef["unc_setup"]
                        grp = f"{'in2reg' if frm == 'in' and kind == 'reg' else kind} {lclk}"
                    elif (lclk, cap_clk) in maxd:
                        req = maxd[(lclk, cap_clk)] - su
                        grp = f"cdc_max_delay {lclk}->{cap_clk}"
                    else:
                        res.append({"check": "setup", "group": f"UNRELATED {lclk}->{cap_clk}", "endpoint": endpoint,
                                    "slack": -INF, "arrival": v[e], "required": None})
                        continue
                    res.append({"check": "setup", "group": grp, "endpoint": endpoint, "edge": "rise" if e == R else "fall",
                                "arrival": v[e], "required": req, "slack": req - v[e], "launch": lclk, "capture": cap_clk,
                                "lib_setup": su, "path": (data_bit, lkey, e)})
                    if lclk == cap_clk and (lclk, cap_clk) not in hold_false:
                        ht = hold_tab.get("rise_constraint" if e == R else "fall_constraint") if hold_tab else None
                        ho = ht.at(rel_slew=cap_slew, con_slew=v[6 + e]) if ht else 0.0
                        reqh = cap_lat + ho + cdef["unc_hold"]
                        res.append({"check": "hold", "group": f"{'in2reg' if frm == 'in' and kind == 'reg' else kind} {lclk}", "endpoint": endpoint,
                                    "edge": "rise" if e == R else "fall", "arrival": v[2 + e], "required": reqh,
                                    "slack": v[2 + e] - reqh, "launch": lclk, "capture": cap_clk, "lib_hold": ho})

        for inst, c in N.cells.items():
            lc = c["lc"]
            if not (lc.is_seq() or lc.icg):
                continue
            if inst not in self.ck:
                if lc.is_seq():
                    unconstrained.append({"endpoint": inst, "kind": "flop", "reason": "no clock reaches the clock pin"})
                continue
            clk = self.ck[inst][0]
            lat, cs = self.clock_arrival(inst)
            for pin, lp in lc.pins.items():
                if lp.dir != "input":
                    continue
                types = {a.type: a for a in lp.arcs}
                b = c["conn"].get(pin)
                ename = f"{self._ename(inst)}/{pin}"
                if "setup_rising" in types:
                    kind = "clock_gating" if lc.icg else "reg"
                    if lc.icg and pin != "GATE":
                        continue
                    evaluate(kind, ename, clk, b, types["setup_rising"].tables, types.get("hold_rising").tables
                             if "hold_rising" in types else {}, lat, cs)
                if "recovery_rising" in types:
                    evaluate("recovery", ename, clk, b, types["recovery_rising"].tables,
                             types["removal_rising"].tables if "removal_rising" in types else {}, lat, cs, edges=(R,))
        for g in C["outputs"]:
            cdef = C["clocks"][g["clock"]]
            for b in N.port_bits(g["ports"]):
                if N.value(b) is not None or b in self.clock_bits:
                    continue
                pn = N.port_of_bit.get(b, ("?", 0))
                ename = f"port {pn[0]}[{pn[1]}]"
                a = self.arr.get(b, {})
                if not a:
                    unconstrained.append({"endpoint": ename, "kind": "output", "reason": "no clocked startpoint"})
                    continue
                for lkey, v in a.items():
                    lclk, frm = (lkey[:-3], "in") if lkey.endswith("@in") else (lkey, "reg")
                    for e in (R, F):
                        if v[e] == -INF:
                            continue
                        if lclk == g["clock"]:
                            req = cdef["period"] - g["max"] - cdef["unc_setup"]
                            grp = f"{'in2out' if frm == 'in' else 'reg2out'} {lclk}"
                            res.append({"check": "hold", "group": grp, "endpoint": ename, "arrival": v[2 + e],
                                        "required": -g["min"] + cdef["unc_hold"], "slack": v[2 + e] + g["min"] - cdef["unc_hold"],
                                        "launch": lclk, "capture": g["clock"]})
                        elif (lclk, g["clock"]) in maxd:
                            req = maxd[(lclk, g["clock"])] - g["max"]
                            grp = f"cdc_max_delay {lclk}->{g['clock']} (port)"
                        else:
                            continue
                        res.append({"check": "setup", "group": grp, "endpoint": ename, "edge": "rise" if e == R else "fall",
                                    "arrival": v[e], "required": req, "slack": req - v[e], "launch": lclk,
                                    "capture": g["clock"], "path": (b, lkey, e)})
        self.results, self.unconstrained = res, unconstrained
        return res

    def _ename(self, inst):
        c = self.N.cells[inst]
        for p in c["lc"].outputs():
            b = c["conn"].get(p)
            if isinstance(b, int):
                return self.N.bit_name(b)
        return inst

    def max_transition(self):
        viol = []
        lim = self.L.default_max_tran
        for b, cl in self.arr.items():
            if b in self.clock_bits:
                continue
            for v in cl.values():
                s = max(v[4], v[5])
                if s > lim:
                    viol.append((self.N.bit_name(b), s))
                    break
        return sorted(viol, key=lambda x: -x[1])


def summarize(sta, label):
    res = sta.results
    groups = defaultdict(lambda: {"setup_wns": INF, "setup_tns": 0.0, "setup_viol": 0, "hold_wns": INF,
                                  "hold_tns": 0.0, "hold_viol": 0, "endpoints": set()})
    for r in res:
        g = groups[r["group"]]
        g["endpoints"].add(r["endpoint"])
        k = r["check"]
        if r["slack"] < g[f"{k}_wns"]:
            g[f"{k}_wns"] = r["slack"]
        if r["slack"] < 0:
            g[f"{k}_tns"] += r["slack"]
            g[f"{k}_viol"] += 1
    return groups


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--netlist", required=True)
    ap.add_argument("--lib", required=True)
    ap.add_argument("--corner", required=True)
    ap.add_argument("--cons", required=True)
    ap.add_argument("--top", default="silicaflux_clock_reset_tree")
    ap.add_argument("--wire-um", type=float, default=0.0)
    ap.add_argument("--max-fanout", type=int, default=16)
    ap.add_argument("--clock-mode", default="ideal", choices=["ideal", "propagated"])
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    lib = Library(a.lib)
    net = Netlist(a.netlist, lib, a.top)
    cons = json.loads(Path(a.cons).read_text())
    sta = STA(lib, net, cons, wire_um=a.wire_um, max_fanout=a.max_fanout, clock_mode=a.clock_mode).run()
    sta.checks()
    groups = summarize(sta, a.corner)
    # raw view (no estimated buffer trees) for the record
    raw = STA(lib, Netlist(a.netlist, lib, a.top), cons, wire_um=a.wire_um, max_fanout=10**9,
              clock_mode=a.clock_mode).run()
    raw.checks()
    graw = summarize(raw, a.corner)

    worst = sorted([r for r in sta.results if r["check"] == "setup"], key=lambda r: r["slack"])[:8]
    worst_h = sorted([r for r in sta.results if r["check"] == "hold"], key=lambda r: r["slack"])[:5]
    fmax = {}
    for r in sta.results:
        if r["check"] == "setup" and r["group"].startswith("reg ") and r["launch"] == r["capture"]:
            # derived from register-to-register paths only
            cdef = cons["clocks"][r["capture"]]
            need = cdef["period"] - r["slack"]
            fmax[r["capture"]] = max(fmax.get(r["capture"], 0.0), need)
    ep_per_clock = defaultdict(int)
    lat_by_level = defaultdict(list)
    for inst, (c, inv, path) in sta.ck.items():
        ep_per_clock[c] += 1
        nicg = sum(1 for pi, _ in path if net.cells[pi]["lc"].icg)
        lat_by_level[f"{c} behind {nicg} ICG"].append(sta.clock_arrival(inst)[0])
    out = {
        "corner": a.corner, "liberty": a.lib, "constraints": a.cons, "clock_mode": a.clock_mode,
        "model": {"loads": "pin capacitance" + (f" + {a.wire_um} um/fanout wire" if a.wire_um else ""),
                  "high_fanout": f"> {a.max_fanout} sinks: estimated sg13g2_buf_8 tree", "comb_loops": sta.loops},
        "clocks": {k: {"period_ns": v["period"], "clock_pins": ep_per_clock.get(k, 0)} for k, v in cons["clocks"].items()},
        "clock_latency_by_icg_level": {k: {"pins": len(v), "min_ns": round(min(v), 4), "max_ns": round(max(v), 4)}
                                       for k, v in sorted(lat_by_level.items())},
        "groups": {k: {**{kk: (None if vv in (INF, -INF) else round(vv, 4)) for kk, vv in g.items() if kk != "endpoints"},
                       "endpoints": len(g["endpoints"])} for k, g in sorted(groups.items())},
        "groups_raw_no_repair": {k: {"setup_wns": None if g["setup_wns"] == INF else round(g["setup_wns"], 4),
                                     "hold_wns": None if g["hold_wns"] == INF else round(g["hold_wns"], 4)}
                                 for k, g in sorted(graw.items())},
        "estimated_trees": {net.bit_name(b): t for b, t in sta.trees.items()},
        "unconstrained": sta.unconstrained,
        "max_transition_violations": sta.max_transition()[:20],
        "derived_fmax_mhz": {k: round(1000.0 / v, 1) for k, v in fmax.items() if v > 0},
        "worst_setup": [{k: v for k, v in w.items() if k != "path"} | {"path": sta.path(*w["path"]) if "path" in w else []}
                        for w in worst],
        "worst_hold": [{k: v for k, v in w.items() if k != "path"} for w in worst_h],
    }
    nv = sum(g["setup_viol"] + g["hold_viol"] for g in groups.values())
    uc = [u for u in sta.unconstrained if u["reason"] != "false-path ports only"]
    out["verdict"] = {"violations": nv, "unconstrained_endpoints": len(uc),
                      "false_path_only_endpoints": len(sta.unconstrained) - len(uc)}
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text(json.dumps(out, indent=1, default=str))
    print(f"[{a.corner}] {Path(a.cons).stem}: violations {nv}, unconstrained {len(uc)}, "
          f"false-path-only {len(sta.unconstrained) - len(uc)}, fmax* {out['derived_fmax_mhz']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
