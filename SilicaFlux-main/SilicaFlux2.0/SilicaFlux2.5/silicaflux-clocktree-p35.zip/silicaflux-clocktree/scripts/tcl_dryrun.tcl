# =============================================================================
# SilicaFlux CLOCKTREE -- Tcl dry run of the SDC / CTS / STA scripts.
#   tclsh scripts/tcl_dryrun.tcl <script> [<script> ...]
# Every OpenROAD / OpenSTA command is a logging stub; a command that is not in
# the whitelist below (OpenROAD + OpenSTA documented commands used by this
# project) fails the run.  This checks Tcl syntax, control flow, variable /
# file references and command spelling -- NOT the tools' semantics.
# =============================================================================
set ::whitelist {
  read_lef read_liberty read_verilog link_design read_sdc read_spef read_db write_db write_def
  define_corners define_scene set_routing_layers set_layer_rc set_wire_rc set_dont_touch
  initialize_floorplan make_tracks place_pins add_global_connection set_voltage_domain define_pdn_grid
  add_pdn_ring add_pdn_stripe add_pdn_connect pdngen tapcell cut_rows global_placement detailed_placement
  check_placement repair_tie_fanout estimate_parasitics repair_design repair_timing clock_tree_synthesis
  set_propagated_clock repair_clock_nets report_cts set_global_routing_layer_adjustment global_route
  report_clock_properties check_setup report_checks report_tns report_wns report_worst_slack
  report_check_types report_clock_skew report_clock_latency report_clock_min_period
  get_cells get_pins get_nets get_ports get_clocks all_clocks all_registers all_inputs all_outputs get_name get_property
  create_clock set_clock_uncertainty set_clock_transition set_case_analysis set_max_delay set_min_delay
  set_false_path set_driving_cell set_load set_input_delay set_output_delay current_design
}
set ::calls {}
proc unknown {cmd args} {
  if {[lsearch -exact $::whitelist $cmd] < 0} { error "DRYRUN: command '$cmd' is not a known OpenROAD/OpenSTA command" }
  lappend ::calls $cmd
  switch -- $cmd {
    get_clocks - all_clocks { return {clk_ref clk_core} }
    all_registers { return {r1/CLK r2/CLK} }
    get_name      { return [lindex $args end] }
    get_property  { return 0.0 }
    default       { return "" }
  }
}
set sdc_version 0
namespace eval ::dry { variable n 0 }
foreach ::dry::f $argv {
  # each script sees a fresh set of whitelisted globals it may have changed
  set ::dry::cur $::dry::f
  if {[catch {uplevel #0 [list source $::dry::cur]} ::dry::err]} { puts "DRYRUN FAIL $::dry::cur: $::dry::err" ; exit 1 }
  incr ::dry::n
  puts "DRYRUN OK   $::dry::cur"
}
set ::dry::u [lsort -unique $::calls]
puts "DRYRUN: $::dry::n scripts, [llength $::calls] stubbed calls, [llength $::dry::u] distinct commands: $::dry::u"
