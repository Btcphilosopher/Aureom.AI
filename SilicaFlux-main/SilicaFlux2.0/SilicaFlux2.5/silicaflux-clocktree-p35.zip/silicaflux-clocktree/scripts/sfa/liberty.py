"""Minimal Liberty reader for SilicaFlux CLOCKTREE analysis.

Parses the group / attribute structure of a Liberty file and extracts, per
cell: pins (direction, capacitance, function, clock flags), sequential
groups (ff / latch / statetable), the clock-gating attributes and every
timing arc with its NLDM tables.  Enough for structural CDC/RDC checks and a
pin-capacitance NLDM timing check; NOT a full Liberty implementation (no
CCS, no power, no OCV tables).
"""
import bisect
import re

_TOK = re.compile(r'"(?:\\.|[^"\\])*"|\\\n|[{}();:,]|[^\s{}();:,"]+', re.S)


def _tokens(text):
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)
    text = re.sub(r"//[^\n]*", " ", text)
    for m in _TOK.finditer(text):
        t = m.group(0)
        if t == "\\\n":
            continue
        yield t


class Group:
    __slots__ = ("kind", "args", "attrs", "groups")

    def __init__(self, kind, args):
        self.kind, self.args, self.attrs, self.groups = kind, args, {}, []

    def sub(self, kind):
        return [g for g in self.groups if g.kind == kind]

    def name(self):
        return self.args[0] if self.args else ""


def _strip(v):
    return v[1:-1] if len(v) >= 2 and v[0] == '"' and v[-1] == '"' else v


def parse(text):
    toks = list(_tokens(text))
    pos = 0
    root = Group("root", [])
    stack = [root]
    n = len(toks)
    while pos < n:
        t = toks[pos]
        if t == "}":
            stack.pop()
            pos += 1
            continue
        if t == ";":
            pos += 1
            continue
        name = t
        nxt = toks[pos + 1] if pos + 1 < n else ""
        if nxt == ":":
            # simple attribute  name : value ;
            j = pos + 2
            vals = []
            while j < n and toks[j] not in (";", "}") and not (toks[j + 1:j + 2] == [":"] and vals):
                vals.append(toks[j])
                j += 1
            stack[-1].attrs[name] = _strip(" ".join(vals))
            pos = j + 1 if j < n and toks[j] == ";" else j
        elif nxt == "(":
            j = pos + 2
            args = []
            while toks[j] != ")":
                if toks[j] != ",":
                    args.append(_strip(toks[j]))
                j += 1
            j += 1
            if j < n and toks[j] == "{":
                g = Group(name, args)
                stack[-1].groups.append(g)
                stack.append(g)
                pos = j + 1
            else:
                stack[-1].attrs.setdefault(name, args)       # complex attribute
                pos = j + 1 if j < n and toks[j] == ";" else j
        else:
            pos += 1
    return root


def _floats(s):
    if isinstance(s, list):
        s = ",".join(s)
    return [float(x) for x in re.split(r"[,\s]+", s.replace('"', "").strip()) if x]


class Table:
    """NLDM lookup table, bilinear inter/extrapolation."""
    __slots__ = ("var1", "var2", "i1", "i2", "v")

    def __init__(self, g, templates):
        tpl = templates.get(g.name(), {})
        self.var1 = tpl.get("variable_1", "")
        self.var2 = tpl.get("variable_2", "")
        i1 = g.attrs.get("index_1", tpl.get("index_1"))
        i2 = g.attrs.get("index_2", tpl.get("index_2"))
        self.i1 = _floats(i1) if i1 else [0.0]
        self.i2 = _floats(i2) if i2 else [0.0]
        vals = g.attrs.get("values", [])
        rows = vals if isinstance(vals, list) else [vals]
        self.v = [_floats(r) for r in rows]
        if len(self.v) == 1 and len(self.i1) > 1 and len(self.v[0]) == len(self.i1) and len(self.i2) == 1:
            self.v = [[x] for x in self.v[0]]          # 1-D table given as one row

    @staticmethod
    def _seg(idx, x):
        if len(idx) == 1:
            return 0, 0, 0.0
        k = bisect.bisect_left(idx, x)
        k = min(max(k, 1), len(idx) - 1)
        lo, hi = k - 1, k
        f = (x - idx[lo]) / (idx[hi] - idx[lo]) if idx[hi] != idx[lo] else 0.0
        return lo, hi, f

    def lookup(self, x1, x2=0.0):
        """x1, x2 in the table's own variable order (callers map by name)."""
        a0, a1, fa = self._seg(self.i1, x1)
        b0, b1, fb = self._seg(self.i2, x2)
        v = self.v
        try:
            q00, q01 = v[a0][b0], v[a0][b1]
            q10, q11 = v[a1][b0], v[a1][b1]
        except IndexError:
            return v[0][0]
        return (q00 * (1 - fa) * (1 - fb) + q10 * fa * (1 - fb) + q01 * (1 - fa) * fb + q11 * fa * fb)

    def at(self, slew=0.0, load=0.0, rel_slew=0.0, con_slew=0.0):
        m = {"input_net_transition": slew, "total_output_net_capacitance": load,
             "related_pin_transition": rel_slew, "constrained_pin_transition": con_slew}
        return self.lookup(m.get(self.var1, slew), m.get(self.var2, load))


class Arc:
    __slots__ = ("related", "type", "sense", "tables", "when")

    def __init__(self, g, templates):
        a = g.attrs
        rp = a.get("related_pin", "")
        self.related = rp.split()
        self.type = a.get("timing_type", "combinational")
        self.sense = a.get("timing_sense", "non_unate")
        self.when = a.get("when", "")
        self.tables = {}
        for t in g.groups:
            if t.kind in ("cell_rise", "cell_fall", "rise_transition", "fall_transition",
                          "rise_constraint", "fall_constraint"):
                self.tables[t.kind] = Table(t, templates)


class Pin:
    __slots__ = ("name", "dir", "cap", "function", "clock", "arcs", "cg_clock", "cg_enable", "cg_out",
                 "state_function", "max_tran")

    def __init__(self, g, templates):
        a = g.attrs
        self.name = g.name()
        self.dir = a.get("direction", "")
        caps = [float(a[k]) for k in ("capacitance", "rise_capacitance", "fall_capacitance") if k in a]
        self.cap = max(caps) if caps else 0.0
        self.function = a.get("function", "")
        self.state_function = a.get("state_function", "")
        self.clock = a.get("clock", "false") == "true"
        self.cg_clock = a.get("clock_gate_clock_pin", "false") == "true"
        self.cg_enable = a.get("clock_gate_enable_pin", "false") == "true"
        self.cg_out = a.get("clock_gate_out_pin", "false") == "true"
        self.max_tran = float(a["max_transition"]) if "max_transition" in a else None
        self.arcs = [Arc(t, templates) for t in g.sub("timing")]


class Cell:
    def __init__(self, g, templates):
        a = g.attrs
        self.name = g.name()
        self.area = float(a.get("area", 0.0))
        self.dont_use = a.get("dont_use", "false") == "true"
        self.icg = a.get("clock_gating_integrated_cell", "")
        self.pins = {}
        for p in g.sub("pin"):
            pin = Pin(p, templates)
            self.pins[pin.name] = pin
        for b in g.sub("bus") + g.sub("bundle"):
            for p in b.sub("pin"):
                pin = Pin(p, templates)
                self.pins[pin.name] = pin
        self.ff = None
        self.latch = None
        ffs = g.sub("ff")
        if ffs:
            f = ffs[0].attrs
            self.ff = {"clocked_on": f.get("clocked_on", ""), "next_state": f.get("next_state", ""),
                       "clear": f.get("clear", ""), "preset": f.get("preset", "")}
        lat = g.sub("latch")
        if lat:
            f = lat[0].attrs
            self.latch = {"enable": f.get("enable", ""), "data_in": f.get("data_in", "")}

    # ---------------------------------------------------------------- roles
    def is_seq(self):
        return self.ff is not None

    def clock_pin(self):
        if self.ff:
            return _ids(self.ff["clocked_on"])[0]
        if self.icg:
            return next((p for p, x in self.pins.items() if x.cg_clock), None)
        return None

    def data_pins(self):
        return _ids(self.ff["next_state"]) if self.ff else []

    def async_pins(self):
        if not self.ff:
            return []
        return _ids(self.ff["clear"]) + _ids(self.ff["preset"])

    def outputs(self):
        return [p for p, x in self.pins.items() if x.dir == "output"]

    def inputs(self):
        return [p for p, x in self.pins.items() if x.dir == "input"]


def _ids(expr):
    out = []
    for t in re.findall(r"[A-Za-z_][A-Za-z0-9_\[\]]*", expr or ""):
        if t not in out and t not in ("IQ", "IQN"):
            out.append(t)
    return out


class Library:
    def __init__(self, path):
        text = open(path).read()
        root = parse(text)
        lib = root.groups[0]
        self.name = lib.name()
        self.attrs = lib.attrs
        self.time_unit = lib.attrs.get("time_unit", "1ns")
        self.cap_unit = lib.attrs.get("capacitive_load_unit", ["1", "pf"])
        self.templates = {}
        for kind in ("lu_table_template", "power_lut_template"):
            for t in lib.sub(kind):
                self.templates[t.name()] = {k: t.attrs.get(k) for k in ("variable_1", "variable_2", "index_1", "index_2")}
        self.default_max_tran = float(lib.attrs.get("default_max_transition", 0) or 0)
        self.nom_voltage = lib.attrs.get("nom_voltage")
        self.nom_temperature = lib.attrs.get("nom_temperature")
        self.cells = {}
        for c in lib.sub("cell"):
            cell = Cell(c, self.templates)
            self.cells[cell.name] = cell


# ------------------------------------------------------------------ boolean functions
class Func:
    """Liberty boolean function: ! ' * & space + | ^ ( ) 0 1."""

    def __init__(self, s):
        self.s = s
        self.toks = re.findall(r"[A-Za-z_][A-Za-z0-9_\[\]]*|[!'*&+|^()01]", s)
        self.vars = []
        for t in self.toks:
            if re.match(r"[A-Za-z_]", t) and t not in self.vars:
                self.vars.append(t)

    def eval(self, env):
        self.p = 0
        v = self._or(env)
        return v

    def _peek(self):
        return self.toks[self.p] if self.p < len(self.toks) else None

    def _or(self, env):
        v = self._xor(env)
        while self._peek() in ("+", "|"):
            self.p += 1
            r = self._xor(env)
            v = _or3(v, r)
        return v

    def _xor(self, env):
        v = self._and(env)
        while self._peek() == "^":
            self.p += 1
            r = self._and(env)
            v = None if v is None or r is None else v ^ r
        return v

    def _and(self, env):
        v = self._un(env)
        while True:
            t = self._peek()
            if t in ("*", "&"):
                self.p += 1
                v = _and3(v, self._un(env))
            elif t is not None and (t in ("!", "(", "0", "1") or re.match(r"[A-Za-z_]", t)):
                v = _and3(v, self._un(env))                # implicit AND (space)
            else:
                return v

    def _un(self, env):
        t = self._peek()
        if t == "!":
            self.p += 1
            v = self._un(env)
            v = None if v is None else 1 - v
        elif t == "(":
            self.p += 1
            v = self._or(env)
            self.p += 1                                   # ')'
        elif t in ("0", "1"):
            self.p += 1
            v = int(t)
        else:
            self.p += 1
            v = env.get(t)
        while self._peek() == "'":
            self.p += 1
            v = None if v is None else 1 - v
        return v


def _and3(a, b):
    if a == 0 or b == 0:
        return 0
    if a is None or b is None:
        return None
    return 1


def _or3(a, b):
    if a == 1 or b == 1:
        return 1
    if a is None or b is None:
        return None
    return 0
