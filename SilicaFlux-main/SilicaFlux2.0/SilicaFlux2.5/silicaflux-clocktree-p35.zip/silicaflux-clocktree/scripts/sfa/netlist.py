"""Gate-level netlist graph over a flattened, Liberty-mapped Yosys JSON netlist.

Provides: net connectivity (driver / sinks per bit), case analysis (constant
propagation through Liberty functions, used for test_mode_i = 0 etc.),
sensitised arcs, clock propagation from clock ports through buffers,
inverters and integrated clock-gating cells, and per-instance roles
(flop clock / data / asynchronous pins, ICG enable).
"""
import json
from itertools import product

from .liberty import Func


class Netlist:
    def __init__(self, json_path, lib, top):
        nl = json.load(open(json_path))
        mod = nl["modules"][top]
        self.lib = lib
        self.top = top
        self.ports = {}          # name -> (direction, [bits])
        self.port_of_bit = {}    # bit -> (port, index)
        self.drv = {}            # bit -> ("cell", inst, pin) | ("port", name, idx) | ("const", v)
        self.sinks = {}          # bit -> [("cell", inst, pin) | ("port", name, idx)]
        self.cells = {}          # inst -> {"type", "conn": {pin: bit}}
        self.netname = {}        # bit -> preferred name
        for pname, p in mod["ports"].items():
            bits = p["bits"]
            self.ports[pname] = (p["direction"], bits)
            for i, b in enumerate(bits):
                self.port_of_bit[b] = (pname, i)
                if p["direction"] == "input":
                    self.drv[b] = ("port", pname, i)
                else:
                    self.sinks.setdefault(b, []).append(("port", pname, i))
        for inst, c in mod["cells"].items():
            lc = lib.cells.get(c["type"])
            if lc is None:
                raise SystemExit(f"cell type {c['type']} ({inst}) not in Liberty {lib.name}")
            conn = {}
            for pin, bits in c["connections"].items():
                b = bits[0]
                conn[pin] = b
                if isinstance(b, str):        # constant bit "0"/"1"
                    continue
                d = lc.pins[pin].dir
                if d == "output":
                    self.drv[b] = ("cell", inst, pin)
                else:
                    self.sinks.setdefault(b, []).append(("cell", inst, pin))
            self.cells[inst] = {"type": c["type"], "conn": conn, "lc": lc}
        cand = {}
        for nname, n in mod["netnames"].items():
            if n.get("hide_name", 0):
                continue
            for i, b in enumerate(n["bits"]):
                if isinstance(b, int):
                    cand.setdefault(b, []).append(nname if len(n["bits"]) == 1 else f"{nname}[{i}]")

        def _rank(nm):
            leaf = nm.split(".")[-1].split("[")[0]
            reg = leaf.endswith("_q")
            port_like = leaf.endswith(("_i", "_ni", "_o", "_no")) or leaf in ("a_i", "b_i", "y_o", "d_i", "q_o")
            return (0 if reg else 1, 1 if port_like else 0, nm.count("."), len(nm))
        self.aliases = {}
        for b, names in cand.items():
            names = sorted(names, key=_rank)
            self.netname[b] = names[0]
            self.aliases[b] = names
        self.const = {}
        self.funcs = {}

    # ------------------------------------------------------------ helpers
    def bit_name(self, b):
        if isinstance(b, str):
            return f"1'b{b}"
        return self.netname.get(b, f"n{b}")

    def port_bits(self, pattern_names):
        out = []
        for n in pattern_names:
            base = n.split("[")[0]
            if base not in self.ports:
                continue
            bits = self.ports[base][1]
            if n.endswith("[*]") or "[" not in n:
                out += bits
            else:
                idx = int(n[n.index("[") + 1:-1])
                out.append(bits[idx])
        return out

    def func(self, inst, pin):
        key = (self.cells[inst]["type"], pin)
        if key not in self.funcs:
            lp = self.cells[inst]["lc"].pins[pin]
            f = lp.function or ""
            self.funcs[key] = Func(f) if f else None
        return self.funcs[key]

    # ------------------------------------------------------------ case analysis
    def case_analysis(self, port_values):
        """Propagate constants: tie cells, constant bits, and port_values
        ({port_name: 0/1}).  Iterates to a fixed point."""
        const = {}
        for p, v in port_values.items():
            if p in self.ports:
                for b in self.ports[p][1]:
                    const[b] = v
        changed = True
        while changed:
            changed = False
            for inst, c in self.cells.items():
                lc = c["lc"]
                if lc.is_seq() or lc.icg:
                    continue
                for op in lc.outputs():
                    ob = c["conn"].get(op)
                    if ob is None or isinstance(ob, str) or ob in const:
                        continue
                    f = self.func(inst, op)
                    if f is None:
                        continue
                    env = {}
                    for v in f.vars:
                        b = c["conn"].get(v)
                        env[v] = int(b) if isinstance(b, str) else const.get(b)
                    r = f.eval(env)
                    if r is not None:
                        const[ob] = r
                        changed = True
        self.const = const
        return const

    def value(self, b):
        if isinstance(b, str):
            return int(b)
        return self.const.get(b)

    def arc_live(self, inst, in_pin, out_pin):
        """An input->output arc is sensitisable under the current constants."""
        c = self.cells[inst]
        ob = c["conn"].get(out_pin)
        if ob is not None and self.value(ob) is not None:
            return False
        if self.value(c["conn"].get(in_pin)) is not None:
            return False                                  # a constant input never transitions
        lc = c["lc"]
        if lc.icg:
            return in_pin == lc.clock_pin()
        f = self.func(inst, out_pin)
        if f is None:
            return True
        if in_pin not in f.vars:
            return False
        free = [v for v in f.vars if v != in_pin and self.value(c["conn"].get(v)) is None]
        fixed = {v: self.value(c["conn"].get(v)) for v in f.vars if v != in_pin and v not in free}
        for combo in product((0, 1), repeat=len(free)):
            env = dict(fixed)
            env.update(dict(zip(free, combo)))
            env[in_pin] = 0
            a = f.eval(env)
            env[in_pin] = 1
            if a != f.eval(env):
                return True
        return False

    # ------------------------------------------------------------ clocks
    def propagate_clocks(self, clock_ports):
        """clock_ports: {clock_name: port}.  Returns (clk_of_bit, sinks) where
        clk_of_bit maps every clock-network bit to (clock, inverted, path),
        path = list of (inst, cell_type) from the port; sinks = list of
        (inst, pin, clock, inverted, path) for every sequential / ICG clock pin."""
        clk_of = {}
        sinks = []
        work = []
        for cname, port in clock_ports.items():
            if port in self.ports:
                b = self.ports[port][1][0]
                clk_of[b] = (cname, False, [])
                work.append(b)
        while work:
            b = work.pop()
            cname, inv, path = clk_of[b]
            for kind, inst, pin in self.sinks.get(b, []):
                if kind != "cell":
                    continue
                c = self.cells[inst]
                lc = c["lc"]
                if lc.is_seq() or lc.icg:
                    if pin == lc.clock_pin():
                        sinks.append((inst, pin, cname, inv, path))
                        if lc.icg:
                            for op in lc.outputs():
                                ob = c["conn"].get(op)
                                if isinstance(ob, int) and ob not in clk_of:
                                    clk_of[ob] = (cname, inv, path + [(inst, c["type"])])
                                    work.append(ob)
                    continue
                for op in lc.outputs():
                    ob = c["conn"].get(op)
                    if not isinstance(ob, int) or ob in clk_of or not self.arc_live(inst, pin, op):
                        continue
                    arc = next((a for a in lc.pins[op].arcs if pin in a.related), None)
                    neg = arc is not None and arc.sense == "negative_unate"
                    clk_of[ob] = (cname, inv ^ neg, path + [(inst, c["type"])])
                    work.append(ob)
        return clk_of, sinks

    # ------------------------------------------------------------ cones
    def fanin_sources(self, b, stop=None, through_ok=None):
        """Backward cone of bit b through combinational cells (live arcs).
        Returns (sources, comb_cells) where sources = set of ('cell', inst, pin)
        sequential / ICG outputs, ('port', name, idx) or ('const', v)."""
        sources, comb, seen = set(), [], set()
        stack = [b]
        while stack:
            x = stack.pop()
            if isinstance(x, str):
                sources.add(("const", x))
                continue
            if x in seen:
                continue
            seen.add(x)
            if self.value(x) is not None:
                sources.add(("const", str(self.value(x))))
                continue
            d = self.drv.get(x)
            if d is None:
                sources.add(("undriven", x))
                continue
            if d[0] == "port":
                sources.add(d)
                continue
            _, inst, pin = d
            lc = self.cells[inst]["lc"]
            if lc.is_seq() or lc.icg or not lc.inputs():
                sources.add(d)
                continue
            comb.append(inst)
            for ip in lc.inputs():
                if self.arc_live(inst, ip, pin):
                    stack.append(self.cells[inst]["conn"].get(ip))
        return sources, comb
