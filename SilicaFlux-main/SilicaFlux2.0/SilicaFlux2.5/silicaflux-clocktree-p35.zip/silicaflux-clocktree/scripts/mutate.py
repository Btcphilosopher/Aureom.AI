#!/usr/bin/env python3
"""Mutation analysis: does the verification catch real clock / reset bugs?

Each mutant is one deliberate RTL defect (a plausible design error).  The RTL
is copied, the edit applied, the system testbench rebuilt with Icarus and the
listed tests run.  A mutant is KILLED when at least one test fails.
"""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
B = ROOT / "build" / "mutants"

MUTANTS = [
    ("M01", "sequencer releases the ControlCore together with the fabric (ordering)",
     "rtl/sf_crt_seq.sv", "              fab_rst_no <= 1'b1;\n              st_q       <= sf_crt_pkg::ST_REL_FAB;\n              cnt_q      <= '0;",
     "              fab_rst_no <= 1'b1;\n              cc_rst_no  <= 1'b1;\n              st_q       <= sf_crt_pkg::ST_REL_FAB;\n              cnt_q      <= '0;", ["por"]),
    ("M02", "gated branch released without forcing its clock on",
     "rtl/sf_crt_seq.sv", "                br_force_o <= br_force_o | sc_br_q;\n                ph_q       <= 1'b0;\n                st_q       <= sf_crt_pkg::ST_REL_ACC;",
     "                ph_q       <= 1'b0;\n                st_q       <= sf_crt_pkg::ST_REL_ACC;", ["clk_en"]),
    ("M03", "clock monitor accepts any count (no frequency window)",
     "rtl/sf_crt_clk_mon.sv", "assign in_range = (acc_n >= CNT_MIN) && (acc_n <= CNT_MAX);", "assign in_range = 1'b1;", ["clk_start", "clk_loss"]),
    ("M04", "reset synchroniser removed (asynchronous release)",
     "rtl/cdc/sf_crt_rst_sync.sv", ".a_i(rsync_q[STAGES-1])", ".a_i(arst_eff_n)", ["por"]),
    ("M05", "clock gated with a plain AND (no latch)",
     "rtl/tech/sim/sf_crt_tech_cells.sv", "  assign gclk_o = clk_i & en_l;", "  assign gclk_o = clk_i & (en_i | se_i);", ["clk_en"]),
    ("M06", "watchdog ignores service",
     "rtl/sf_crt_wdog.sv", "      end else if (kick_i) begin", "      end else if (1'b0) begin", ["wdog"]),
    ("M07", "external reset not recorded in the cause log",
     "rtl/sf_crt_cause_log.sv", "        else             e = e | EXT_M;", "        else             e = e;", ["ext_rst"]),
    ("M08", "software reset key not checked",
     "rtl/sf_crt_regs.sv", "  wire        swrst_ok  = (key == sf_crt_pkg::SWRST_KEY) && cmd_ready_i && scope_ok;",
     "  wire        swrst_ok  = cmd_ready_i && scope_ok;", ["sw_reset"]),
    ("M09", "branch gate ignores the busy request (no interlock)",
     "rtl/sf_crt_branch_gate.sv", "      en_q        <= sw_en_i | clk_req_i | wake_i | force_s;", "      en_q        <= sw_en_i | wake_i | force_s;", ["clk_en"]),
    ("M10", "graceful reset does not wait for the drain",
     "rtl/sf_crt_seq.sv", "            end else if (((!sc_fab_q || fab_qack_i) && ((br_qack_i & sc_br_q) == sc_br_q))",
     "            end else if (1'b1", ["sw_reset"]),
    ("M11", "clock / PLL loss not acted upon",
     "rtl/sf_crt_seq.sv", "  wire           lost      = !pll_locked_i || !core_ok_i;", "  wire           lost      = 1'b0;", ["clk_loss"]),
    ("M12", "handshake payload not held (source re-samples every cycle)",
     "rtl/cdc/sf_crt_handshake.sv", "    end else if (src_valid_i && src_ready_o) begin\n      src_hold_q <= src_data_i;",
     "    end else begin\n      src_hold_q <= src_data_i;\n    end\n    if (src_rst_ni && src_valid_i && src_ready_o) begin", ["cdc", "wdog"]),
    ("M13", "clock-monitor saturating counter wraps (the bug found by regression)",
     "rtl/sf_crt_clk_mon.sv", "          ok_o <= (good_q >= GOOD_N - 4'd1);", "          ok_o <= (good_q + 4'd1 >= GOOD_N);", ["wdog", "cdc"]),
    ("M14", "root clock gate opened before the PLL is locked",
     "rtl/sf_crt_seq.sv", "            if (lost) cnt_q <= '0;\n            else if (cnt_q >= C_STABLE) begin",
     "            if (!core_ok_i) cnt_q <= '0;\n            else if (cnt_q >= C_STABLE) begin", ["clk_start", "por"]),
    ("M15", "watchdog request input ignored",
     "rtl/silicaflux_clock_reset_tree.sv", ".ext_wdog_i(|wdog_req_s)", ".ext_wdog_i(1'b0)", ["ext_wdog"]),
    ("M16", "test mode does not bypass the reset synchroniser output",
     "rtl/cdc/sf_crt_rst_sync.sv", "  sf_crt_dft_mux u_dft_out (.a_i(rsync_q[STAGES-1]), .b_i(test_rst_ni), .s_i(test_mode_i), .y_o(rst_no));",
     "  assign rst_no = rsync_q[STAGES-1];", ["test_mode"]),
]


def main():
    files = [l.strip() for l in (ROOT / "rtl/files.f").read_text().splitlines() if l.strip() and not l.startswith("//")]
    rows, killed = [], 0
    for mid, desc, path, old, new, tests in MUTANTS:
        d = B / mid
        if d.exists():
            shutil.rmtree(d)
        shutil.copytree(ROOT / "rtl", d / "rtl")
        shutil.copytree(ROOT / "tb", d / "tb")
        src = (d / path).read_text()
        if old not in src:
            rows.append((mid, desc, "NOT APPLIED (pattern missing)", tests, ""))
            print(f"[{mid}] pattern missing")
            continue
        (d / path).write_text(src.replace(old, new, 1))
        exe = d / "sim.vvp"
        p = subprocess.run(["iverilog", "-g2012", "-o", str(exe), "-s", "tb_crt_top", "rtl/tech/sim/sf_crt_tech_cells.sv"]
                           + files + ["tb/tb_models.sv", "tb/tb_crt_top.sv"], cwd=d, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, text=True)
        if p.returncode:
            rows.append((mid, desc, "KILLED (does not compile)", tests, p.stdout[-120:]))
            killed += 1
            continue
        verdict, evidence = "SURVIVED", ""
        for t in tests:
            q = subprocess.run(["vvp", "-n", str(exe), f"+TEST={t}", "+SEED=1"], cwd=d, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, timeout=1800)
            m = re.search(r"RESULT (PASS|FAIL)", q.stdout)
            if not m or m.group(1) == "FAIL":
                verdict = "KILLED"
                lines = q.stdout.splitlines()
                err = next((l for l in lines if "VIOLATION" in l or l.startswith("ERROR")), None)
                if err is None:
                    err = "test did not complete (sequencer hang -> global timeout)" if m is None else "FAIL"
                evidence = f"{t}: {err[:140]}"
                break
        killed += verdict == "KILLED"
        rows.append((mid, desc, verdict, tests, evidence))
        print(f"[{mid}] {verdict}: {desc} -- {evidence}", flush=True)
    L = ["# Mutation analysis", "", f"**{killed} / {len(MUTANTS)} mutants killed** by the system testbench (Icarus, seed 1).", "",
         "| id | injected defect | tests run | result | first evidence |", "|---|---|---|---|---|"]
    for mid, desc, v, tests, ev in rows:
        L.append(f"| {mid} | {desc} | {', '.join(tests)} | {v} | {ev.replace('|', '/')} |")
    (ROOT / "reports/mutation.md").write_text("\n".join(L) + "\n")
    (ROOT / "reports/mutation.json").write_text(json.dumps([dict(zip(("id", "defect", "result", "tests", "evidence"), r))
                                                            for r in rows], indent=1))
    return 0 if killed == len(MUTANTS) else 1


if __name__ == "__main__":
    sys.exit(main())
