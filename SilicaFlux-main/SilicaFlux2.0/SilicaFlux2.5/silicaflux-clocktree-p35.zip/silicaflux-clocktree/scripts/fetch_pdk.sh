#!/usr/bin/env bash
# Fetch the SKY130HD platform collateral (portability target) at the ORFS revision used here.
# IHP SG13G2 (primary) is vendored in third_party/ihp-sg13g2 and needs no fetch.
#   scripts/fetch_pdk.sh [dest]   -> then: export SKY130_LIB=<dest>/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
#                                          export SKY130_PLATFORM_DIR=<dest>/flow/platforms/sky130hd
set -euo pipefail
ORFS_REV=bfcc1895a7a1d9ff6e677066825812e549b72421     # OpenROAD-flow-scripts, 2026-11-11
DEST=${1:-build/orfs}
if [ ! -d "$DEST/.git" ]; then
  git clone -q --filter=blob:none --sparse https://github.com/The-OpenROAD-Project/OpenROAD-flow-scripts.git "$DEST"
fi
cd "$DEST"
git sparse-checkout set flow/platforms/sky130hd flow/platforms/ihp-sg13g2
git checkout -q "$ORFS_REV" 2>/dev/null || echo "note: revision $ORFS_REV not reachable with a shallow clone; using $(git rev-parse --short HEAD)"
echo "SKY130_LIB=$PWD/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"
echo "SKY130_PLATFORM_DIR=$PWD/flow/platforms/sky130hd"
