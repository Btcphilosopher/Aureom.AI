#!/usr/bin/env python3
"""CTS preparation check: the generated OpenROAD CTS configuration against the
ACTUAL technology files and the synthesised netlist.

Per technology: clock / root buffers exist in the Liberty and the LEF, are not
dont_use and are buffers (one input, function = that input); the ICG exists
with clock_gating_integrated_cell; clock / signal routing layers exist as
ROUTING layers in the tech LEF and are ordered; the placement site exists; the
wire-RC script sets a clock wire RC.
Per configuration (IHP netlists): clock roots exist as ports; sink groups and
pre-CTS clock-net fanout from structural clock propagation; leaf-cluster
estimate for the configured sink-cluster size.
"""
import json
import math
import os
import re
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sfa.liberty import Library, Func   # noqa: E402
from sfa.netlist import Netlist         # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
SKY = os.environ.get("SKY130_PLATFORM_DIR")
TECH = {
    "ihp_sg13g2": {"lib": ROOT / "third_party/ihp-sg13g2/lib/sg13g2_stdcell_typ_1p20V_25C.lib",
                   "tlef": ROOT / "third_party/ihp-sg13g2/lef/sg13g2_tech.lef",
                   "lef": ROOT / "third_party/ihp-sg13g2/lef/sg13g2_stdcell.lef",
                   "rc": ROOT / "third_party/ihp-sg13g2/setRC.tcl", "icg": "sg13g2_slgcp_1", "site": "CoreSite"},
    "sky130hd": {"lib": Path(SKY or "/nonexistent") / "lib/sky130_fd_sc_hd__tt_025C_1v80.lib",
                 "tlef": Path(SKY or "/nonexistent") / "lef/sky130_fd_sc_hd.tlef",
                 "lef": Path(SKY or "/nonexistent") / "lef/sky130_fd_sc_hd_merged.lef",
                 "rc": Path(SKY or "/nonexistent") / "setRC.tcl", "icg": "sky130_fd_sc_hd__sdlclkp_1", "site": "unithd"},
}


def lef_layers(tlef):
    t = tlef.read_text()
    out = []
    for m in re.finditer(r"^LAYER\s+(\S+)(.*?)^END\s+\1", t, re.S | re.M):
        if re.search(r"TYPE\s+ROUTING", m.group(2)):
            out.append(m.group(1))
    return out


def main():
    spec = yaml.safe_load((ROOT / "config/clock_spec.yaml").read_text())
    cts = spec["cts"]
    checks, ok_all = [], True

    def chk(scope, item, ok, detail):
        nonlocal ok_all
        if ok is False:
            ok_all = False
        checks.append({"scope": scope, "item": item, "result": {True: "PASS", False: "FAIL", None: "NOT RUN"}[ok],
                       "detail": detail})

    for tech, t in cts["technologies"].items():
        f = TECH[tech]
        if not f["lib"].exists():
            chk(tech, "collateral", None, "technology files not present (set SKY130_PLATFORM_DIR; scripts/fetch_pdk.sh)")
            continue
        lib = Library(f["lib"])
        lef = f["lef"].read_text()
        tl = f["tlef"].read_text()
        for b in t["clock_buffers"] + [t["root_buffer"]]:
            c = lib.cells.get(b)
            ok = c is not None and re.search(rf"^MACRO\s+{re.escape(b)}\s*$", lef, re.M) is not None
            isbuf = False
            if c:
                outs, ins = c.outputs(), c.inputs()
                if len(outs) == 1 and len(ins) == 1:
                    fn = c.pins[outs[0]].function.strip()
                    isbuf = fn.strip("() ") == ins[0]
            chk(tech, f"clock buffer {b}", ok and isbuf and not c.dont_use,
                f"Liberty {'yes' if c else 'NO'}, LEF {'yes' if ok else 'NO'}, buffer {isbuf}, dont_use {c.dont_use if c else '-'}"
                + (f", area {c.area}" if c else ""))
        icg = lib.cells.get(f["icg"])
        chk(tech, f"ICG {f['icg']}", icg is not None and bool(icg.icg) and re.search(rf"^MACRO\s+{f['icg']}\s*$", lef, re.M) is not None,
            f"clock_gating_integrated_cell = {icg.icg if icg else 'missing'} (explicit instantiation; dont_use for inference = {icg.dont_use if icg else '-'})")
        layers = lef_layers(f["tlef"])
        for kind in ("clock_layers", "signal_layers"):
            lo, hi = t[kind]
            ok = lo in layers and hi in layers and layers.index(lo) <= layers.index(hi)
            chk(tech, f"{kind} {lo}-{hi}", ok, f"routing layers in tech LEF: {layers}")
        site_ok = re.search(rf"^SITE\s+{f['site']}\s*$", tl + lef, re.M) is not None
        chk(tech, f"site {f['site']}", site_ok, "SITE found" if site_ok else "SITE missing")
        rc = f["rc"].read_text() if f["rc"].exists() else ""
        chk(tech, "clock wire RC", "set_wire_rc -clock" in rc, f"{f['rc'].name}: " + (
            [l for l in rc.splitlines() if "-clock" in l] or ["no clock RC"])[0])

    # ------------------------------------------------------------ sink groups from the netlists
    groups = {}
    lib = Library(TECH["ihp_sg13g2"]["lib"])
    for cfg, c in spec["configurations"].items():
        nlp = ROOT / f"build/synth/ihp_sg13g2_{cfg}/netlist.json"
        if not nlp.exists():
            chk(cfg, "netlist", None, "run scripts/synth.py first")
            continue
        N = Netlist(nlp, lib, spec["design"])
        N.case_analysis(spec["ports"]["static_test"])
        roots = {k: spec["clocks"][k]["port"] for k in c["clocks"]}
        for k, p in roots.items():
            chk(cfg, f"root {k} = port {p}", p in N.ports, "port present" if p in N.ports else "port MISSING")
        clk_of, sinks = N.propagate_clocks(roots)
        g = {}
        for inst, pin, cname, inv, path in sinks:
            icgs = [N.cells[pi]["type"] for pi, _ in path if N.cells[pi]["lc"].icg]
            key = (cname, len(icgs))
            g[key] = g.get(key, 0) + 1
        fan = {}
        for b, (cname, inv, path) in clk_of.items():
            n = len(N.sinks.get(b, []))
            if n:
                fan[N.bit_name(b)] = (cname, n)
        groups[cfg] = {"sinks": {f"{k[0]} behind {k[1]} ICG": v for k, v in sorted(g.items())},
                       "clock_nets": dict(sorted(fan.items(), key=lambda x: -x[1][1]))}
        for (cname, lv), n in g.items():
            clusters = math.ceil(n / 20)
            groups[cfg]["sinks"][f"{cname} behind {lv} ICG"] = {"sinks": n, "leaf_clusters_est": clusters}

    out = {"checks": checks, "groups": groups, "pass": ok_all}
    (ROOT / "reports/cts").mkdir(parents=True, exist_ok=True)
    (ROOT / "reports/cts/cts_precheck.json").write_text(json.dumps(out, indent=1))
    L = ["# CTS preparation check", "",
         "The generated OpenROAD CTS configuration (cts/cts_config_<tech>.tcl, from config/clock_spec.yaml)",
         "checked against the actual technology files and the synthesised netlists.  **This is not a CTS run**:",
         "OpenROAD could not be installed here, so no clock tree has been built and no closure is claimed.", "",
         f"**Verdict: {'PASS' if ok_all else 'FAIL'}**", "", "| scope | item | result | detail |", "|---|---|---|---|"]
    for c in checks:
        L.append(f"| {c['scope']} | {c['item']} | {c['result']} | {c['detail']} |")
    for cfg, g in groups.items():
        L += ["", f"## Sink groups -- {cfg} (structural clock propagation on the IHP netlist)", "",
              "| clock / gating level | sinks | leaf clusters (20 sinks) |", "|---|---|---|"]
        for k, v in g["sinks"].items():
            L.append(f"| {k} | {v['sinks']} | {v['leaf_clusters_est']} |")
        L += ["", "| pre-CTS clock net | clock | fanout |", "|---|---|---|"]
        for n, (cname, f_) in g["clock_nets"].items():
            L.append(f"| `{n}` | {cname} | {f_} |")
    (ROOT / "reports/cts/CTS_PRECHECK.md").write_text("\n".join(L) + "\n")
    print(f"CTS precheck: {'PASS' if ok_all else 'FAIL'} ({sum(c['result'] == 'PASS' for c in checks)} pass, "
          f"{sum(c['result'] == 'FAIL' for c in checks)} fail, {sum(c['result'] == 'NOT RUN' for c in checks)} not run)")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
