#!/usr/bin/env python3
"""Negative (and one positive) tests of scripts/cdc_check.py.

Each design in tests/cdc_negative contains exactly one known-bad structure.
It is synthesised to IHP SG13G2 exactly like the real block, then checked;
the expected rule MUST fire.  pos_good_sync must pass cleanly.
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
T = ROOT / "tests" / "cdc_negative"
B = ROOT / "build" / "cdc_negative"
LIB = ROOT / "build" / "synth" / "sg13g2_stdcell_typ_1p20V_25C.synth.lib"
CASES = {
    "neg_comb_clkgate": "CLK-COMB-GATING",
    "neg_logic_before_sync": "CDC-LOGIC_BEFORE_SYNC",
    "neg_multibit_bus": "CDC-MULTIBIT_SYNC",
    "neg_decoded_reset": "RDC-COMB",
    "neg_async_release": "RDC-ASYNC-RELEASE",
    "neg_rdc_data": "RDC-DATA",
    "neg_icg_en_cdc": "CLK-ICG-EN-CDC",
    "neg_ripple_clock": "CLK-UNCLOCKED",
    "pos_good_sync": None,
}


def main():
    if not LIB.exists():
        sys.exit("run scripts/synth.py first (synthesis Liberty)")
    B.mkdir(parents=True, exist_ok=True)
    rows, ok_all = [], True
    for name, rule in CASES.items():
        out = B / name
        out.mkdir(exist_ok=True)
        ys = out / "synth.ys"
        ys.write_text(f"""read_liberty -lib {LIB}
read_verilog -sv {T / (name + '.sv')}
synth -top {name} -flatten
dfflibmap -liberty {LIB}
abc -liberty {LIB}
opt_clean -purge
hilomap -singleton -hicell sg13g2_tiehi L_HI -locell sg13g2_tielo L_LO
write_json {out / 'netlist.json'}
""")
        p = subprocess.run(["yosys", "-q", "-s", str(ys)], cwd=ROOT, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, text=True)
        if p.returncode != 0:
            rows.append((name, rule, "SYNTH FAILED", p.stdout[-200:]))
            ok_all = False
            continue
        cmd = [sys.executable, str(ROOT / "scripts/cdc_check.py"), "--netlist", str(out / "netlist.json"),
               "--spec", str(T / "spec.yaml"), "--config", "neg", "--waivers", "", "--top", name,
               "--out", str(ROOT / "reports/cdc/negative" / name)]
        if rule:
            cmd += ["--expect-fail", rule]
        q = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        ok = q.returncode == 0
        ok_all &= ok
        rows.append((name, rule or "(none: must pass)", "PASS" if ok else "FAIL", q.stdout.strip().splitlines()[-1]))
        print(f"[{'PASS' if ok else 'FAIL'}] {name}: {q.stdout.strip().splitlines()[-1]}")
    L = ["# CDC / RDC checker negative tests", "",
         "Each design is synthesised to IHP SG13G2 like the real block and checked by scripts/cdc_check.py.", "",
         "| design | rule that must fire | result | checker output |", "|---|---|---|---|"]
    for r in rows:
        L.append(f"| `{r[0]}` | {r[1]} | {r[2]} | {r[3]} |")
    (ROOT / "reports/cdc/NEGATIVE_TESTS.md").write_text("\n".join(L) + "\n")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
