#!/usr/bin/env python3
"""SilicaFlux CLOCKTREE structural clock / CDC / RDC checker.

Runs on the flattened, Liberty-mapped Yosys netlist with case analysis
(functional mode: test_mode_i = test_en_i = 0).  Every rule is structural
(cell functions from the Liberty, connectivity from the netlist); names are
used only for reporting, for recognising the explicitly instantiated DFT-mux
/ reset-combine cells (wrapper instance paths *.u_dft*.u_cell / *u_rc_*.u_cell)
and for waivers.

Clock structure
  CLK-UNCLOCKED     sequential cell whose clock pin no clock reaches       FAIL
  CLK-COMB-GATING   clock passes through logic other than buf/inv/ICG     FAIL
  CLK-ICG-EN-CDC    ICG enable launched from another clock domain         FAIL
CDC (every flop / ICG-enable endpoint fed from another clock or an async port)
  SYNC_2FF          single source, buffers only, first stage drives exactly
                    one flop of its own clock (the second stage)            PASS
  LOGIC_BEFORE_SYNC logic or several sources feed a synchroniser stage    FAIL
  QUASI_STATIC_DATA cross-domain value captured directly (handshake
                    payload, FIFO read data)                             REVIEW -> waiver with evidence
  MULTIBIT_SYNC     several SYNC_2FF bits in one synchroniser bank       REVIEW -> waiver (Gray / independent bits)
Reset structure / RDC
  RDC-COMB          reset path through logic other than buf/inv, the DFT
                    mux (case-analysed) or the reset-combine cell          FAIL
  RDC-SOURCE        reset driven by a port that is not a declared
                    asynchronous reset port                               FAIL
  RDC-ASYNC-RELEASE reset released by a source not synchronous to the
                    flop's clock and the flop is not a reset-synchroniser
                    stage                                                 FAIL
  RDC-DATA          same-clock data path from a flop that can be reset
                    while the destination is not, without an isolation
                    stage                                               REVIEW -> waiver
Ports
  PORT-ASYNC        a declared asynchronous port reaching anything other
                    than reset pins / synchroniser first stages           FAIL
  PORT-UNCOVERED    an input port with no declared domain                 WARN
"""
import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from sfa.liberty import Library          # noqa: E402
from sfa.netlist import Netlist          # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


def is_bufinv(N, inst):
    """Buffer / inverter, or any cell that is one under case analysis: exactly
    one non-constant input with a sensitisable arc (e.g. the DFT reset mux with
    test_mode_i = 0).  Such a cell cannot create a glitch: its other inputs are
    static."""
    lc = N.cells[inst]["lc"]
    if lc.is_seq() or lc.icg or len(lc.outputs()) != 1:
        return False
    op = lc.outputs()[0]
    f = N.func(inst, op)
    if f is None:
        return False
    if len(lc.inputs()) == 1:
        return len(f.vars) == 1
    c = N.cells[inst]["conn"]
    live = [ip for ip in lc.inputs() if N.value(c.get(ip)) is None and N.arc_live(inst, ip, op)]
    return len(live) == 1


def is_dft_mux(inst):
    return re.search(r"(^|\.)u_dft\w*\.u_cell$", inst) is not None


def is_rst_comb(inst):
    return re.search(r"(^|\.)u_rc_\w*\.u_cell$", inst) is not None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--netlist", required=True)
    ap.add_argument("--lib", default=str(ROOT / "third_party/ihp-sg13g2/lib/sg13g2_stdcell_typ_1p20V_25C.lib"))
    ap.add_argument("--spec", default=str(ROOT / "config/clock_spec.yaml"))
    ap.add_argument("--config", default="baseline")
    ap.add_argument("--waivers", default=str(ROOT / "config/cdc_waivers.yaml"))
    ap.add_argument("--top", default="silicaflux_clock_reset_tree")
    ap.add_argument("--out", required=True)
    ap.add_argument("--expect-fail", default="", help="comma list of rules that MUST fire (negative tests)")
    a = ap.parse_args()

    spec = yaml.safe_load(open(a.spec))
    waivers = yaml.safe_load(open(a.waivers)) if a.waivers and Path(a.waivers).exists() else {"waivers": []}
    lib = Library(a.lib)
    N = Netlist(a.netlist, lib, a.top)
    N.case_analysis(spec["ports"]["static_test"])

    clocks_cfg = spec["configurations"].get(a.config, {}).get("clocks", list(spec["clocks"]))
    clock_ports = {c: spec["clocks"][c]["port"] for c in clocks_cfg if spec["clocks"][c]["port"] in N.ports}
    clk_of, csinks = N.propagate_clocks(clock_ports)

    findings = []

    def add(rule, sev, obj, msg, **kw):
        findings.append({"rule": rule, "severity": sev, "object": obj, "message": msg, **kw})

    # ---------------------------------------------------------------- sequential map
    seq = {}
    for inst, c in N.cells.items():
        lc = c["lc"]
        if lc.is_seq() or lc.icg:
            seq[inst] = c
    ck_of = {}
    for inst, pin, cname, inv, path in csinks:
        ck_of[inst] = (cname, inv, path)
        for (pi, ptype) in path:
            if not (N.cells[pi]["lc"].icg or is_bufinv(N, pi)):
                add("CLK-COMB-GATING", "FAIL", inst, f"clock {cname} reaches {inst} through {ptype} {pi}")

    def qname(inst):
        c = N.cells[inst]
        lc = c["lc"]
        outs = [p for p in lc.outputs() if p in c["conn"] and isinstance(c["conn"][p], int)]
        return N.bit_name(c["conn"][outs[0]]) if outs else inst

    def qaliases(inst):
        c = N.cells[inst]
        lc = c["lc"]
        outs = [p for p in lc.outputs() if p in c["conn"] and isinstance(c["conn"][p], int)]
        return N.aliases.get(c["conn"][outs[0]], [qname(inst)]) if outs else [inst]

    for inst, c in seq.items():
        if inst not in ck_of:
            cp = c["lc"].clock_pin()
            if N.value(c["conn"].get(cp)) is None:
                add("CLK-UNCLOCKED", "FAIL", qname(inst), f"no clock reaches {inst} ({c['type']})")

    # ---------------------------------------------------------------- port domains
    port_dom = {}
    for clk, plist in spec["ports"]["inputs"].items():
        for p in plist:
            for b in N.port_bits([p]):
                port_dom[b] = clk
    async_ports = set(spec["ports"]["asynchronous"])
    for p in async_ports:
        for b in N.port_bits([p]):
            port_dom[b] = "async"
    for b in N.port_bits([spec["ports"]["test_reset"]]):
        port_dom[b] = "test"
    for p in spec["ports"]["static_test"]:
        for b in N.port_bits([p]):
            port_dom[b] = "static"
    for c, port in clock_ports.items():
        for b in N.port_bits([port]):
            port_dom[b] = "clock"
    for pname, (d, bits) in N.ports.items():
        if d != "input":
            continue
        for b in bits:
            if b not in port_dom and pname not in [spec["clocks"][c]["port"] for c in spec["clocks"]]:
                add("PORT-UNCOVERED", "WARN", pname, f"input port {pname} has no declared domain")

    def dom(src):
        if src[0] == "cell":
            ck = ck_of.get(src[1])
            return ck[0] if ck else None
        if src[0] == "port":
            return port_dom.get(N.ports[src[1]][1][src[2]], None)
        return "const"

    def fanout_terms(b):
        """Sinks of bit b through buffers / inverters."""
        out, stack, seen = [], [b], set()
        while stack:
            x = stack.pop()
            if x in seen:
                continue
            seen.add(x)
            for kind, inst, pin in N.sinks.get(x, []):
                if kind == "cell" and is_bufinv(N, inst):
                    ob = N.cells[inst]["conn"][N.cells[inst]["lc"].outputs()[0]]
                    stack.append(ob)
                else:
                    out.append((kind, inst, pin))
        return out

    def q_bit(inst):
        c = N.cells[inst]
        for p in c["lc"].outputs():
            b = c["conn"].get(p)
            if isinstance(b, int):
                return b
        return None

    def drives_one_stage(inst):
        """Q of inst drives exactly one sequential D pin of the same clock."""
        qb = q_bit(inst)
        if qb is None:
            return False
        t = fanout_terms(qb)
        if len(t) != 1 or t[0][0] != "cell":
            return False
        k, si, sp = t[0]
        lc = N.cells[si]["lc"]
        return lc.is_seq() and sp in lc.data_pins() and ck_of.get(si, (None,))[0] == ck_of.get(inst, (None,))[0]

    # ---------------------------------------------------------------- CDC
    crossings = []
    sync_first = {}
    for inst, c in seq.items():
        lc = c["lc"]
        ck = ck_of.get(inst)
        if ck is None:
            continue
        pins = lc.data_pins() if lc.is_seq() else [p for p, x in lc.pins.items() if x.cg_enable]
        for pin in pins:
            b = c["conn"].get(pin)
            if b is None:
                continue
            sources, comb = N.fanin_sources(b)
            real = [s for s in sources if s[0] in ("cell", "port")]
            foreign = [s for s in real if dom(s) not in (ck[0], "const", "static", None)]
            if lc.icg and foreign:
                add("CLK-ICG-EN-CDC", "FAIL", inst, f"ICG enable of {inst} launched from {[dom(s) for s in foreign]}")
                continue
            if not foreign:
                continue
            bufonly = all(is_bufinv(N, x) for x in comb)
            single = len(real) == 1
            one_stage = drives_one_stage(inst)
            name = qname(inst)
            if single and bufonly and one_stage:
                cls = "SYNC_2FF"
            elif one_stage:
                cls = "LOGIC_BEFORE_SYNC"
            else:
                cls = "QUASI_STATIC_DATA"
            src_desc = []
            for s in foreign:
                if s[0] == "cell":
                    src_desc.append({"name": qname(s[1]), "clock": dom(s)})
                else:
                    src_desc.append({"name": f"{s[1]}[{s[2]}]", "clock": dom(s)})
            crossings.append({"endpoint": name, "clock": ck[0], "class": cls, "sources": src_desc,
                              "logic_cells": len(comb), "aliases": qaliases(inst)})
            if cls == "SYNC_2FF":
                bank = re.sub(r"\[\d+\]$", "", name)
                sync_first.setdefault(bank, []).append(name)
            elif cls == "LOGIC_BEFORE_SYNC":
                add("CDC-LOGIC_BEFORE_SYNC", "FAIL", name,
                    f"{len(comb)} logic cells / {len(real)} sources feed synchroniser stage {name}")

    # multi-bit synchroniser banks
    for bank, bits in sync_first.items():
        if len(bits) > 1:
            crossings.append({"endpoint": bank, "clock": None, "class": "MULTIBIT_SYNC", "bits": len(bits),
                              "sources": []})

    # ---------------------------------------------------------------- reset structure / RDC
    allowed_ports = async_ports | {spec["ports"]["test_reset"]}
    reset_nets = defaultdict(lambda: {"flops": 0, "clocks": set(), "source": None, "kind": None})
    rsrc = {}

    def reset_sources(inst):
        if inst in rsrc:
            return rsrc[inst]
        c = N.cells[inst]
        out = []
        for ap_ in c["lc"].async_pins():
            b = c["conn"].get(ap_)
            if b is None:
                continue
            sources, comb = N.fanin_sources(b)
            bad = [x for x in comb if not (is_bufinv(N, x) or is_dft_mux(x) or is_rst_comb(x))]
            out.append((ap_, b, sources, comb, bad))
        rsrc[inst] = out
        return out

    rs_memo = {}

    def is_rsync_stage(inst):
        """Reset-synchroniser stage: D is constant 1 (first stage) or, through
        buffers only, the Q of a previous stage with the same clock and the
        same asynchronous sources (no inversion: a toggle flop is not a stage)."""
        if inst in rs_memo:
            return rs_memo[inst]
        rs_memo[inst] = False                          # cycle guard
        c = N.cells[inst]
        lc = c["lc"]
        res = False
        if lc.is_seq():
            d = c["conn"].get(lc.data_pins()[0])
            srcs, comb = N.fanin_sources(d)
            if srcs == {("const", "1")}:
                res = True
            else:
                real = [s for s in srcs if s[0] == "cell"]
                if (len(real) == 1 and real[0][1] != inst and all(is_bufinv(N, x) for x in comb)
                        and sum(1 for x in comb if N.cells[x]["lc"].pins[N.cells[x]["lc"].outputs()[0]].function.startswith("!")) % 2 == 0):
                    g = real[0][1]
                    if ck_of.get(g, (None,))[0] == ck_of.get(inst, (None,))[0]:
                        ga = {s for r in reset_sources(g) for s in r[2]}
                        fa = {s for r in reset_sources(inst) for s in r[2]}
                        res = ga == fa and is_rsync_stage(g)
        rs_memo[inst] = res
        return res

    rdc_rows = []
    for inst, c in seq.items():
        if not c["lc"].is_seq():
            continue
        ck = ck_of.get(inst, (None,))[0]
        for ap_, b, sources, comb, bad in reset_sources(inst):
            if N.value(b) is not None:
                continue                                   # reset pin tied inactive
            name = qname(inst)
            if bad:
                add("RDC-COMB", "FAIL", name, f"reset of {name} passes through logic: "
                    + ", ".join(sorted({N.cells[x]['type'] for x in bad})))
            for s in sources:
                if s[0] == "const":
                    continue
                if s[0] == "port":
                    if s[1] not in allowed_ports:
                        add("RDC-SOURCE", "FAIL", name, f"reset driven by non-reset port {s[1]}")
                    elif not is_rsync_stage(inst):
                        add("RDC-ASYNC-RELEASE", "FAIL", name, f"port {s[1]} releases {name} asynchronously")
                    key = f"port:{s[1]}"
                    rel = "RESET_SYNC_STAGE"
                elif s[0] == "cell":
                    sck = ck_of.get(s[1], (None,))[0]
                    key = qname(s[1])
                    if sck == ck:
                        rel = "SYNC_RELEASE"
                    elif is_rsync_stage(inst):
                        rel = "RESET_SYNC_STAGE"
                    else:
                        rel = "ASYNC_RELEASE"
                        add("RDC-ASYNC-RELEASE", "FAIL", name,
                            f"{name} ({ck}) released by {key} ({sck}) without a reset synchroniser")
                else:
                    add("RDC-SOURCE", "FAIL", name, f"reset source {s}")
                    continue
                rn = reset_nets[(key, rel)]
                rn["flops"] += 1
                rn["clocks"].add(ck)
                rn["source"] = key
                rn["kind"] = rel

    # assertion causes (reset-synchroniser stages are transparent)
    causes_memo = {}

    def causes(inst, depth=0):
        if inst in causes_memo:
            return causes_memo[inst]
        causes_memo[inst] = set()
        out = set()
        for ap_, b, sources, comb, bad in reset_sources(inst):
            for s in sources:
                if s[0] == "port":
                    out.add("port:" + s[1])
                elif s[0] == "cell" and N.cells[s[1]]["lc"].is_seq():
                    if is_rsync_stage(s[1]):
                        out |= causes(s[1], depth + 1)
                    else:
                        out.add(qname(s[1]))
                        out |= causes(s[1], depth + 1)
        causes_memo[inst] = out
        return out

    for inst, c in seq.items():
        lc = c["lc"]
        if not lc.is_seq() or inst not in ck_of:
            continue
        ck = ck_of[inst][0]
        if is_rsync_stage(inst):
            continue
        d = c["conn"].get(lc.data_pins()[0])
        sources, comb = N.fanin_sources(d)
        fc = causes(inst)
        for s in sources:
            if s[0] != "cell" or not N.cells[s[1]]["lc"].is_seq() or ck_of.get(s[1], (None,))[0] != ck:
                continue
            extra = causes(s[1]) - fc
            if not extra:
                continue
            real = [x for x in sources if x[0] == "cell"]
            isolated = len(real) == 1 and all(is_bufinv(N, x) for x in comb) and drives_one_stage(inst)
            rdc_rows.append({"endpoint": qname(inst), "source": qname(s[1]), "clock": ck, "aliases": qaliases(inst),
                             "source_only_causes": sorted(extra)[:6],
                             "class": "RDC_ISOLATED" if isolated else "RDC_DATA"})

    # ---------------------------------------------------------------- async ports reach only reset pins / sync stages
    for p in sorted(async_ports):
        for b in N.port_bits([p]):
            stack, seen = [b], set()
            while stack:
                x = stack.pop()
                if x in seen:
                    continue
                seen.add(x)
                for kind, inst, pin in N.sinks.get(x, []):
                    if kind != "cell":
                        add("PORT-ASYNC", "FAIL", p, f"{p} reaches output port {inst}")
                        continue
                    lc = N.cells[inst]["lc"]
                    if lc.is_seq():
                        if pin in lc.async_pins():
                            continue
                        if pin in lc.data_pins() and any(cr["endpoint"] == qname(inst) and cr["class"] == "SYNC_2FF"
                                                         for cr in crossings):
                            continue
                        add("PORT-ASYNC", "FAIL", p, f"{p} reaches {pin} of {qname(inst)} (not a synchroniser stage)")
                    elif is_bufinv(N, inst) or is_dft_mux(inst) or is_rst_comb(inst):
                        ob = N.cells[inst]["conn"][lc.outputs()[0]]
                        if N.value(ob) is None:
                            stack.append(ob)
                    else:
                        add("PORT-ASYNC", "FAIL", p, f"{p} enters logic {N.cells[inst]['type']} {inst}")

    # ---------------------------------------------------------------- waivers
    wl = waivers.get("waivers", []) or []
    review = []
    for cr in crossings:
        if cr["class"] in ("QUASI_STATIC_DATA", "MULTIBIT_SYNC"):
            review.append(("CDC-" + cr["class"], cr["endpoint"], cr))
    for r in rdc_rows:
        if r["class"] == "RDC_DATA":
            review.append(("RDC-DATA", r["endpoint"], r))
    used = set()
    for rule, obj, row in review:
        names = row.get("aliases", [obj]) + [obj]
        w = next((w for w in wl if w["rule"] == rule and any(re.search(w["match"], n) for n in names)), None)
        if w:
            row["waiver"] = w["id"]
            used.add(w["id"])
        else:
            add(rule, "REVIEW", obj, f"{rule} without a waiver")
    for w in wl:
        if w["id"] not in used and a.config in w.get("configs", [a.config]):
            add("WAIVER-UNUSED", "WARN", w["id"], f"waiver {w['id']} matches nothing in configuration {a.config}")

    # ---------------------------------------------------------------- results
    counts = defaultdict(int)
    for cr in crossings:
        counts[cr["class"]] += 1
    sev = defaultdict(int)
    for f in findings:
        sev[f["severity"]] += 1
    exp = [x for x in a.expect_fail.split(",") if x]
    fired = {f["rule"] for f in findings if f["severity"] in ("FAIL", "REVIEW")}
    ok = (sev["FAIL"] == 0 and sev["REVIEW"] == 0) if not exp else all(e in fired for e in exp)

    clocks_summary = defaultdict(lambda: {"sinks": 0, "gated_sinks": 0, "icg_levels": set()})
    for inst, pin, cname, inv, path in csinks:
        cs = clocks_summary[cname]
        cs["sinks"] += 1
        nicg = sum(1 for pi, _ in path if N.cells[pi]["lc"].icg)
        if nicg:
            cs["gated_sinks"] += 1
        cs["icg_levels"].add(nicg)

    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    res = {
        "netlist": a.netlist, "config": a.config, "case_analysis": spec["ports"]["static_test"],
        "clocks": {k: {"sinks": v["sinks"], "gated_sinks": v["gated_sinks"], "icg_levels": sorted(v["icg_levels"])}
                   for k, v in clocks_summary.items()},
        "crossing_counts": dict(counts), "findings_by_severity": dict(sev),
        "crossings": crossings, "rdc": rdc_rows,
        "reset_nets": [{"source": v["source"], "release": v["kind"], "flops": v["flops"],
                        "clocks": sorted(v["clocks"], key=str)}
                       for v in reset_nets.values()],
        "findings": findings, "expect_fail": exp, "pass": ok,
    }
    Path(str(out) + ".json").write_text(json.dumps(res, indent=1, default=list))
    write_md(Path(str(out) + ".md"), res)
    verdict = "PASS" if ok else "FAIL"
    if exp:
        print(f"[{verdict}] negative test {a.netlist}: expected {exp}, fired {sorted(fired)}")
    else:
        print(f"[{verdict}] {a.config}: crossings {dict(counts)}; FAIL {sev['FAIL']} REVIEW {sev['REVIEW']} "
              f"WARN {sev['WARN']}")
    return 0 if ok else 1


def write_md(path, r):
    L = [f"# Structural CDC / RDC report -- `{r['config']}`", "",
         f"Netlist: `{r['netlist']}` (flattened, Liberty-mapped).  Case analysis: `{r['case_analysis']}`.", "",
         f"**Verdict: {'PASS' if r['pass'] else 'FAIL'}** -- findings by severity: {r['findings_by_severity'] or 'none'}", "",
         "## Clocks reached (structural)", "", "| clock | sequential / ICG sinks | behind an ICG | ICG levels |", "|---|---|---|---|"]
    for k, v in sorted(r["clocks"].items()):
        L.append(f"| {k} | {v['sinks']} | {v['gated_sinks']} | {v['icg_levels']} |")
    L += ["", "## Crossings", "", "| class | count |", "|---|---|"]
    for k, v in sorted(r["crossing_counts"].items()):
        L.append(f"| {k} | {v} |")
    L += ["", "| endpoint | clock | class | source(s) | waiver |", "|---|---|---|---|---|"]
    for c in sorted(r["crossings"], key=lambda c: (c["class"], c["endpoint"])):
        src = ", ".join(f"{s['name']} ({s['clock']})" for s in c["sources"][:3]) + (" ..." if len(c["sources"]) > 3 else "")
        if c["class"] == "MULTIBIT_SYNC":
            src = f"{c['bits']} bits"
        L.append(f"| `{c['endpoint']}` | {c['clock'] or ''} | {c['class']} | {src} | {c.get('waiver', '')} |")
    L += ["", "## Reset distribution", "", "| reset source | release | flops | clocks |", "|---|---|---|---|"]
    for n in sorted(r["reset_nets"], key=lambda n: (n["release"], n["source"])):
        L.append(f"| `{n['source']}` | {n['release']} | {n['flops']} | {', '.join(c or '-' for c in n['clocks'])} |")
    L += ["", "## Reset-domain crossings (same clock, different assertion causes)", ""]
    if not r["rdc"]:
        L.append("None.")
    else:
        L += ["| endpoint | source | clock | class | waiver |", "|---|---|---|---|---|"]
        for x in r["rdc"]:
            L.append(f"| `{x['endpoint']}` | `{x['source']}` | {x['clock']} | {x['class']} | {x.get('waiver', '')} |")
    L += ["", "## Findings", ""]
    if not r["findings"]:
        L.append("None.")
    for f in r["findings"]:
        L.append(f"* **{f['severity']}** {f['rule']} `{f['object']}`: {f['message']}")
    path.write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
