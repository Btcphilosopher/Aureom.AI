#!/usr/bin/env bash
# SilicaFlux CLOCKTREE lint: Verilator -Wall on every configuration of the top
# and on every CDC / clock primitive standalone; Icarus elaboration.  Writes reports/lint.md.
set -u
cd "$(dirname "$0")/.."
RTL=$(grep -v '^//' rtl/files.f)
TECH=rtl/tech/sim/sf_crt_tech_cells.sv
out=reports/lint.md
fail=0
{
echo "# Lint"
echo
echo "Verilator \`$(verilator --version)\` with \`-Wall\` (only DECLFILENAME disabled: several technology cells share one file)."
echo
echo "| target | configuration | warnings / errors |"
echo "|---|---|---|"
} > $out
run() {   # $1 label  $2 config  rest: verilator args
  local label=$1 cfg=$2; shift 2
  local log; log=$(verilator --lint-only -Wall -Wno-DECLFILENAME "$@" 2>&1 | grep -E '^%(Warning|Error)' | grep -v 'Exiting due to')
  local n; n=$(printf '%s' "$log" | grep -c . || true)
  echo "| $label | $cfg | $([ "$n" = 0 ] && echo clean || echo "**$n**: $(echo "$log" | head -3 | tr '\n' ' ')") |" >> $out
  [ "$n" = 0 ] || fail=1
}
for mc in 0 1; do for nb in 1 2 8; do
  run silicaflux_clock_reset_tree "MC_EN=$mc NB=$nb" --top-module silicaflux_clock_reset_tree "-GMC_EN=1'b$mc" -GNB=$nb $TECH $RTL
done; done
run silicaflux_clock_reset_tree "+SF_CRT_CDC_RANDOM (sim model)" -DSF_CRT_CDC_RANDOM --top-module silicaflux_clock_reset_tree $TECH $RTL
run silicaflux_clock_reset_tree "+SF_CRT_CG_ENABLE_ONLY" -DSF_CRT_CG_ENABLE_ONLY --top-module silicaflux_clock_reset_tree $TECH $RTL
run sf_crt_async_fifo  "standalone" --top-module sf_crt_async_fifo  rtl/cdc/sf_crt_sync.sv rtl/cdc/sf_crt_async_fifo.sv
run sf_crt_handshake   "standalone" --top-module sf_crt_handshake   rtl/cdc/sf_crt_sync.sv rtl/cdc/sf_crt_handshake.sv
run sf_crt_pulse_sync  "standalone" --top-module sf_crt_pulse_sync  rtl/cdc/sf_crt_sync.sv rtl/cdc/sf_crt_pulse_sync.sv
run sf_crt_irq_sync    "EDGE_MODE=1" --top-module sf_crt_irq_sync -GEDGE_MODE=1\'b1 rtl/cdc/sf_crt_sync.sv rtl/cdc/sf_crt_pulse_sync.sv rtl/cdc/sf_crt_irq_sync.sv
run sf_crt_rst_sync    "standalone" --top-module sf_crt_rst_sync $TECH rtl/cdc/sf_crt_rst_sync.sv
run sf_crt_clk_gate    "ICG (sim cell)" --top-module sf_crt_clk_gate $TECH rtl/clk/sf_crt_clk_gate.sv
if iverilog -g2012 -o /dev/null -s silicaflux_clock_reset_tree $TECH $RTL 2>&1 | grep -v 'constant selects\|unique/unique0' | grep -q .; then
  echo "| Icarus 12 elaboration | default | **messages** |" >> $out; fail=1
else
  echo "| Icarus 12 elaboration | default | clean (only Icarus 'sorry' notes on unique-case / constant selects, no effect) |" >> $out
fi
echo "lint: $([ $fail = 0 ] && echo CLEAN || echo FINDINGS) -> $out"
exit $fail
