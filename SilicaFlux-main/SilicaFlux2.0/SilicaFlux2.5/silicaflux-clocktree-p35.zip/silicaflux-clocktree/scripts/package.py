#!/usr/bin/env python3
"""Package SilicaFlux CLOCKTREE as a zip: sources, configuration, constraints, CTS, tests, docs,
reports and the vendored IHP SG13G2 collateral.  build/ (regenerable) is excluded.  Writes
MANIFEST.sha256 inside the archive."""
import hashlib
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXCLUDE_DIRS = {"build", "__pycache__", ".pytest_cache"}


def main():
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / "silicaflux-clocktree-p35.zip"
    files = sorted(p for p in ROOT.rglob("*")
                   if p.is_file() and not (set(p.relative_to(ROOT).parts) & EXCLUDE_DIRS)
                   and p.name != "MANIFEST.sha256")
    manifest = []
    for p in files:
        manifest.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT)}")
    (ROOT / "MANIFEST.sha256").write_text("\n".join(manifest) + "\n")
    files.append(ROOT / "MANIFEST.sha256")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files:
            z.write(p, Path("silicaflux-clocktree") / p.relative_to(ROOT))
    print(f"{out}: {len(files)} files, {out.stat().st_size / 1e6:.2f} MB")
    return 0


if __name__ == "__main__":
    sys.exit(main())
