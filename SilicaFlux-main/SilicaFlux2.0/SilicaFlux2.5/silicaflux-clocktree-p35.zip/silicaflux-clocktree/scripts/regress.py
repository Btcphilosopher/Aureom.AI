#!/usr/bin/env python3
"""SilicaFlux CLOCKTREE regression runner.

Builds the system testbench (tb/tb_crt_top.sv) and the CDC-library testbench
(tb/tb_cdc_lib.sv) with Icarus Verilog and Verilator for a matrix of builds
(memory-controller domain on/off, clock ratios, random CDC metastability
model), runs every test with several seeds, and writes
reports/regression.{json,md}.

usage: scripts/regress.py [--sims iverilog,verilator] [--seeds N] [--quick] [-j N]
"""
import argparse
import concurrent.futures as cf
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build" / "regress"
RTL = [l.strip() for l in (ROOT / "rtl/files.f").read_text().splitlines()
       if l.strip() and not l.startswith("//")]
TECH = "rtl/tech/sim/sf_crt_tech_cells.sv"

TESTS = ["por", "clk_start", "ext_rst", "wdog", "ext_wdog", "sw_reset", "simul",
         "clk_en", "clk_loss", "dma_reset", "cdc", "test_mode"]

# name: (defines)  -- half periods in ns
BUILDS = {
    "B0_base":        {"TB_MC_EN": "0", "REF_HALF": "10.0", "CORE_HALF": "3.5",  "MC_HALF": "4.5"},
    "B1_mc":          {"TB_MC_EN": "1", "REF_HALF": "10.0", "CORE_HALF": "3.5",  "MC_HALF": "4.5"},
    "B2_mc_rand":     {"TB_MC_EN": "1", "REF_HALF": "10.0", "CORE_HALF": "3.5",  "MC_HALF": "4.5",  "SF_CRT_CDC_RANDOM": ""},
    "B3_slowcore":    {"TB_MC_EN": "1", "REF_HALF": "10.0", "CORE_HALF": "31.0", "MC_HALF": "13.0", "SF_CRT_CDC_RANDOM": ""},
    "B4_fastcore":    {"TB_MC_EN": "0", "REF_HALF": "10.0", "CORE_HALF": "1.3",  "MC_HALF": "4.5",  "SF_CRT_CDC_RANDOM": ""},
    "B5_noncommens":  {"TB_MC_EN": "1", "REF_HALF": "10.0", "CORE_HALF": "4.37", "MC_HALF": "6.91", "SF_CRT_CDC_RANDOM": ""},
}
# CDC library: (src_half, dst_half)
CDC_RATIOS = [("3.5", "10.0"), ("10.0", "3.5"), ("5.0", "7.3"), ("31.0", "10.0"), ("1.3", "10.0")]


def run(cmd, cwd=ROOT, timeout=3600):
    t0 = time.time()
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    return p.returncode, p.stdout, time.time() - t0


def defs(d, sim):
    out = []
    for k, v in d.items():
        if sim == "iverilog":
            out.append(f"-D{k}={v}" if v != "" else f"-D{k}")
        else:
            out.append(f"+define+{k}={v}" if v != "" else f"+define+{k}")
    return out


def build(sim, name, top, tb_files, d):
    out = BUILD / sim / name
    out.mkdir(parents=True, exist_ok=True)
    srcs = [TECH] + RTL + tb_files
    if sim == "iverilog":
        exe = out / "sim.vvp"
        cmd = ["iverilog", "-g2012", "-o", str(exe), "-s", top] + defs(d, sim) + srcs
        rc, log, dt = run(cmd)
        log = "\n".join(l for l in log.splitlines()
                        if "constant selects in always_*" not in l and "unique/unique0" not in l)
        return (["vvp", "-n", str(exe)] if rc == 0 else None), log, dt
    exe = out / "obj" / "sim"
    cmd = ["verilator", "--binary", "--timing", "-j", "4", "--timescale", "1ns/1ps",
           "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-WIDTH", "-Wno-MULTIDRIVEN", "-Wno-INITIALDLY",
           "--top-module", top, "-Mdir", str(out / "obj"), "-o", "sim"] + defs(d, sim) + srcs
    rc, log, dt = run(cmd, timeout=3600)
    return ([str(exe)] if rc == 0 and exe.exists() else None), log, dt


RES = re.compile(r"TEST (\S+) RESULT (PASS|FAIL)(?:.*?checks=(\d+) errors=(\d+))?")


def run_test(exe, test, seed, logpath):
    rc, log, dt = run(exe + [f"+TEST={test}", f"+SEED={seed}"], timeout=1800)
    logpath.write_text(log)
    m = RES.search(log)
    sim_ns = re.search(r"sim_ns=(\d+)", log)
    return {
        "result": (m.group(2) if m else "FAIL"),
        "checks": int(m.group(3)) if m and m.group(3) else None,
        "errors": int(m.group(4)) if m and m.group(4) else None,
        "first_error": next((l for l in log.splitlines() if l.startswith("ERROR")), ""),
        "wall_s": round(dt, 2),
        "sim_ns": int(sim_ns.group(1)) / 1000.0 if sim_ns else None,
        "log": str(logpath.relative_to(ROOT)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sims", default="iverilog,verilator")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--quick", action="store_true", help="B0 and B2 only, one seed")
    ap.add_argument("-j", type=int, default=os.cpu_count() or 2)
    a = ap.parse_args()
    sims = a.sims.split(",")
    builds = {k: v for k, v in BUILDS.items() if not a.quick or k in ("B0_base", "B2_mc_rand")}
    seeds = [1] if a.quick else list(range(1, a.seeds + 1))
    results, build_log = [], []

    jobs = []
    for sim in sims:
        for bname, d in builds.items():
            jobs.append((sim, bname, "tb_crt_top", ["tb/tb_models.sv", "tb/tb_crt_top.sv"], d))
        for rnd in (False, True):
            for s, dd in CDC_RATIOS:
                d = {"SRC_HALF": s, "DST_HALF": dd}
                if rnd:
                    d["SF_CRT_CDC_RANDOM"] = ""
                jobs.append((sim, f"CDC_{s}_{dd}{'_rand' if rnd else ''}", "tb_cdc_lib", ["tb/tb_cdc_lib.sv"], d))

    # builds (Verilator compiles are memory hungry: 2 at a time)
    exes = {}
    with cf.ThreadPoolExecutor(max_workers=2) as ex:
        futs = {ex.submit(build, *j): j for j in jobs}
        for f in cf.as_completed(futs):
            sim, bname, top, _, d = futs[f]
            exe, log, dt = f.result()
            build_log.append({"sim": sim, "build": bname, "top": top, "ok": exe is not None,
                              "seconds": round(dt, 1), "defines": d})
            (BUILD / sim / bname / "build.log").write_text(log)
            exes[(sim, bname)] = (exe, top)
            print(f"[build] {sim:9s} {bname:22s} {'OK' if exe else 'FAILED'} {dt:6.1f}s", flush=True)

    runs = []
    for (sim, bname), (exe, top) in exes.items():
        if exe is None:
            results.append({"sim": sim, "build": bname, "test": "(build)", "seed": 0, "result": "FAIL",
                            "first_error": "build failed"})
            continue
        tests = TESTS if top == "tb_crt_top" else ["cdc_lib"]
        for t in tests:
            for s in seeds:
                runs.append((sim, bname, exe, t, s))

    with cf.ThreadPoolExecutor(max_workers=a.j) as ex:
        futs = {}
        for sim, bname, exe, t, s in runs:
            lp = BUILD / sim / bname / f"{t}_s{s}.log"
            futs[ex.submit(run_test, exe, t, s, lp)] = (sim, bname, t, s)
        for f in cf.as_completed(futs):
            sim, bname, t, s = futs[f]
            r = f.result()
            r.update({"sim": sim, "build": bname, "test": t, "seed": s})
            results.append(r)
            if r["result"] != "PASS":
                print(f"[FAIL] {sim} {bname} {t} seed={s}: {r['first_error']}", flush=True)

    results.sort(key=lambda r: (r["sim"], r["build"], r["test"], r["seed"]))
    npass = sum(r["result"] == "PASS" for r in results)
    summary = {"runs": len(results), "pass": npass, "fail": len(results) - npass,
               "sims": sims, "builds": {k: v for k, v in builds.items()}, "cdc_ratios": CDC_RATIOS,
               "seeds": seeds, "tool_versions": tool_versions()}
    out = ROOT / "reports"
    out.mkdir(exist_ok=True)
    (out / "regression.json").write_text(json.dumps({"summary": summary, "builds": build_log, "results": results},
                                                    indent=1))
    write_md(out / "regression.md", summary, build_log, results)
    print(f"\nREGRESSION: {npass}/{len(results)} passed")
    return 0 if npass == len(results) else 1


def tool_versions():
    v = {}
    for name, cmd in (("iverilog", ["iverilog", "-V"]), ("verilator", ["verilator", "--version"])):
        try:
            o = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True).stdout
            v[name] = o.splitlines()[0].strip()
        except Exception as e:  # pragma: no cover
            v[name] = f"unavailable ({e})"
    return v


def write_md(path, summary, build_log, results):
    L = ["# Regression results", "",
         f"**{summary['pass']} / {summary['runs']} runs passed** "
         f"({', '.join(summary['sims'])}; seeds {summary['seeds']}).", "",
         "Tools: " + "; ".join(f"{k}: `{v}`" for k, v in summary["tool_versions"].items()), "",
         "## Builds", "", "| simulator | build | top | defines | compiled | s |", "|---|---|---|---|---|---|"]
    for b in sorted(build_log, key=lambda b: (b["sim"], b["build"])):
        dd = " ".join(f"{k}={v}" if v else k for k, v in b["defines"].items())
        L.append(f"| {b['sim']} | {b['build']} | {b['top']} | `{dd}` | {'yes' if b['ok'] else '**NO**'} | {b['seconds']} |")
    L += ["", "## Pass matrix (passed / runs per test)", ""]
    tests = sorted({r["test"] for r in results})
    cols = sorted({(r["sim"], r["build"]) for r in results})
    L.append("| test | " + " | ".join(f"{s[:4]} {b}" for s, b in cols) + " |")
    L.append("|---|" + "---|" * len(cols))
    for t in tests:
        row = []
        for c in cols:
            rs = [r for r in results if r["test"] == t and (r["sim"], r["build"]) == c]
            row.append("" if not rs else f"{sum(r['result'] == 'PASS' for r in rs)}/{len(rs)}")
        L.append(f"| {t} | " + " | ".join(row) + " |")
    fails = [r for r in results if r["result"] != "PASS"]
    L += ["", "## Failures", ""]
    if not fails:
        L.append("None.")
    for r in fails:
        L.append(f"* {r['sim']} {r['build']} {r['test']} seed {r['seed']}: `{r.get('first_error', '')}` ({r.get('log', '')})")
    tot_checks = sum(r.get("checks") or 0 for r in results)
    L += ["", f"Total self-checks executed: {tot_checks}."]
    path.write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
