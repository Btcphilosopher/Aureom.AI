# IHP SG13G2 technology collateral (vendored, unmodified)

| item | value |
|---|---|
| source | The-OpenROAD-Project/OpenROAD-flow-scripts, `flow/platforms/ihp-sg13g2` |
| ORFS commit | `bfcc1895a7a1d9ff6e677066825812e549b72421` (2026-11-11) |
| licence | IHP-Open-PDK: Apache-2.0 (see Readme.md); ORFS scripts BSD-3-Clause |
| files | standard-cell Liberty typ/slow/fast, tech LEF, standard-cell LEF, platform Tcl (setRC, make_tracks, pdn, tapcell, global_connect, fastroute), config.mk (reference) |
| integrity | SHA256SUMS (this directory) |

Nothing here was edited.  The synthesis-only Liberty copy with ORFS DONT_USE
cells marked `dont_use : true` is generated under build/ by scripts/synth.py.
