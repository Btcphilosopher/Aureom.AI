# Regression results

**492 / 492 runs passed** (iverilog, verilator; seeds [1, 2, 3]).

Tools: iverilog: `Icarus Verilog version 12.0 (stable) ()`; verilator: `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)`

## Builds

| simulator | build | top | defines | compiled | s |
|---|---|---|---|---|---|
| iverilog | B0_base | tb_crt_top | `TB_MC_EN=0 REF_HALF=10.0 CORE_HALF=3.5 MC_HALF=4.5` | yes | 0.0 |
| iverilog | B1_mc | tb_crt_top | `TB_MC_EN=1 REF_HALF=10.0 CORE_HALF=3.5 MC_HALF=4.5` | yes | 0.0 |
| iverilog | B2_mc_rand | tb_crt_top | `TB_MC_EN=1 REF_HALF=10.0 CORE_HALF=3.5 MC_HALF=4.5 SF_CRT_CDC_RANDOM` | yes | 0.0 |
| iverilog | B3_slowcore | tb_crt_top | `TB_MC_EN=1 REF_HALF=10.0 CORE_HALF=31.0 MC_HALF=13.0 SF_CRT_CDC_RANDOM` | yes | 0.0 |
| iverilog | B4_fastcore | tb_crt_top | `TB_MC_EN=0 REF_HALF=10.0 CORE_HALF=1.3 MC_HALF=4.5 SF_CRT_CDC_RANDOM` | yes | 0.0 |
| iverilog | B5_noncommens | tb_crt_top | `TB_MC_EN=1 REF_HALF=10.0 CORE_HALF=4.37 MC_HALF=6.91 SF_CRT_CDC_RANDOM` | yes | 0.0 |
| iverilog | CDC_1.3_10.0 | tb_cdc_lib | `SRC_HALF=1.3 DST_HALF=10.0` | yes | 0.0 |
| iverilog | CDC_1.3_10.0_rand | tb_cdc_lib | `SRC_HALF=1.3 DST_HALF=10.0 SF_CRT_CDC_RANDOM` | yes | 0.0 |
| iverilog | CDC_10.0_3.5 | tb_cdc_lib | `SRC_HALF=10.0 DST_HALF=3.5` | yes | 0.0 |
| iverilog | CDC_10.0_3.5_rand | tb_cdc_lib | `SRC_HALF=10.0 DST_HALF=3.5 SF_CRT_CDC_RANDOM` | yes | 0.0 |
| iverilog | CDC_3.5_10.0 | tb_cdc_lib | `SRC_HALF=3.5 DST_HALF=10.0` | yes | 0.0 |
| iverilog | CDC_3.5_10.0_rand | tb_cdc_lib | `SRC_HALF=3.5 DST_HALF=10.0 SF_CRT_CDC_RANDOM` | yes | 0.0 |
| iverilog | CDC_31.0_10.0 | tb_cdc_lib | `SRC_HALF=31.0 DST_HALF=10.0` | yes | 0.0 |
| iverilog | CDC_31.0_10.0_rand | tb_cdc_lib | `SRC_HALF=31.0 DST_HALF=10.0 SF_CRT_CDC_RANDOM` | yes | 0.0 |
| iverilog | CDC_5.0_7.3 | tb_cdc_lib | `SRC_HALF=5.0 DST_HALF=7.3` | yes | 0.0 |
| iverilog | CDC_5.0_7.3_rand | tb_cdc_lib | `SRC_HALF=5.0 DST_HALF=7.3 SF_CRT_CDC_RANDOM` | yes | 0.0 |
| verilator | B0_base | tb_crt_top | `TB_MC_EN=0 REF_HALF=10.0 CORE_HALF=3.5 MC_HALF=4.5` | yes | 126.0 |
| verilator | B1_mc | tb_crt_top | `TB_MC_EN=1 REF_HALF=10.0 CORE_HALF=3.5 MC_HALF=4.5` | yes | 136.2 |
| verilator | B2_mc_rand | tb_crt_top | `TB_MC_EN=1 REF_HALF=10.0 CORE_HALF=3.5 MC_HALF=4.5 SF_CRT_CDC_RANDOM` | yes | 138.1 |
| verilator | B3_slowcore | tb_crt_top | `TB_MC_EN=1 REF_HALF=10.0 CORE_HALF=31.0 MC_HALF=13.0 SF_CRT_CDC_RANDOM` | yes | 137.8 |
| verilator | B4_fastcore | tb_crt_top | `TB_MC_EN=0 REF_HALF=10.0 CORE_HALF=1.3 MC_HALF=4.5 SF_CRT_CDC_RANDOM` | yes | 130.8 |
| verilator | B5_noncommens | tb_crt_top | `TB_MC_EN=1 REF_HALF=10.0 CORE_HALF=4.37 MC_HALF=6.91 SF_CRT_CDC_RANDOM` | yes | 135.9 |
| verilator | CDC_1.3_10.0 | tb_cdc_lib | `SRC_HALF=1.3 DST_HALF=10.0` | yes | 18.8 |
| verilator | CDC_1.3_10.0_rand | tb_cdc_lib | `SRC_HALF=1.3 DST_HALF=10.0 SF_CRT_CDC_RANDOM` | yes | 17.4 |
| verilator | CDC_10.0_3.5 | tb_cdc_lib | `SRC_HALF=10.0 DST_HALF=3.5` | yes | 19.1 |
| verilator | CDC_10.0_3.5_rand | tb_cdc_lib | `SRC_HALF=10.0 DST_HALF=3.5 SF_CRT_CDC_RANDOM` | yes | 23.1 |
| verilator | CDC_3.5_10.0 | tb_cdc_lib | `SRC_HALF=3.5 DST_HALF=10.0` | yes | 17.0 |
| verilator | CDC_3.5_10.0_rand | tb_cdc_lib | `SRC_HALF=3.5 DST_HALF=10.0 SF_CRT_CDC_RANDOM` | yes | 23.0 |
| verilator | CDC_31.0_10.0 | tb_cdc_lib | `SRC_HALF=31.0 DST_HALF=10.0` | yes | 18.9 |
| verilator | CDC_31.0_10.0_rand | tb_cdc_lib | `SRC_HALF=31.0 DST_HALF=10.0 SF_CRT_CDC_RANDOM` | yes | 21.6 |
| verilator | CDC_5.0_7.3 | tb_cdc_lib | `SRC_HALF=5.0 DST_HALF=7.3` | yes | 18.9 |
| verilator | CDC_5.0_7.3_rand | tb_cdc_lib | `SRC_HALF=5.0 DST_HALF=7.3 SF_CRT_CDC_RANDOM` | yes | 22.6 |

## Pass matrix (passed / runs per test)

| test | iver B0_base | iver B1_mc | iver B2_mc_rand | iver B3_slowcore | iver B4_fastcore | iver B5_noncommens | iver CDC_1.3_10.0 | iver CDC_1.3_10.0_rand | iver CDC_10.0_3.5 | iver CDC_10.0_3.5_rand | iver CDC_3.5_10.0 | iver CDC_3.5_10.0_rand | iver CDC_31.0_10.0 | iver CDC_31.0_10.0_rand | iver CDC_5.0_7.3 | iver CDC_5.0_7.3_rand | veri B0_base | veri B1_mc | veri B2_mc_rand | veri B3_slowcore | veri B4_fastcore | veri B5_noncommens | veri CDC_1.3_10.0 | veri CDC_1.3_10.0_rand | veri CDC_10.0_3.5 | veri CDC_10.0_3.5_rand | veri CDC_3.5_10.0 | veri CDC_3.5_10.0_rand | veri CDC_31.0_10.0 | veri CDC_31.0_10.0_rand | veri CDC_5.0_7.3 | veri CDC_5.0_7.3_rand |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cdc | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| cdc_lib |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |
| clk_en | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| clk_loss | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| clk_start | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| dma_reset | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| ext_rst | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| ext_wdog | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| por | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| simul | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| sw_reset | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| test_mode | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |
| wdog | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 |  |  |  |  |  |  |  |  |  |  |

## Failures

None.

Total self-checks executed: 116815.
