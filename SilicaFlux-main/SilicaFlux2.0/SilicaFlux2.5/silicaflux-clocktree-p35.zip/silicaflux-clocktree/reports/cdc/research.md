# Structural CDC / RDC report -- `research`

Netlist: `build/synth/ihp_sg13g2_research/netlist.json` (flattened, Liberty-mapped).  Case analysis: `{'test_mode_i': 0, 'test_en_i': 0}`.

**Verdict: PASS** -- findings by severity: {'FAIL': 0, 'REVIEW': 0}

## Clocks reached (structural)

| clock | sequential / ICG sinks | behind an ICG | ICG levels |
|---|---|---|---|
| clk_core | 343 | 323 | [0, 1, 2] |
| clk_mc | 19 | 0 | [0] |
| clk_ref | 623 | 0 | [0] |

## Crossings

| class | count |
|---|---|
| MULTIBIT_SYNC | 6 |
| QUASI_STATIC_DATA | 178 |
| SYNC_2FF | 48 |

| endpoint | clock | class | source(s) | waiver |
|---|---|---|---|---|
| `g_mc.u_mon_mc.u_gsync.sync_q` |  | MULTIBIT_SYNC | 8 bits | CDC-W03 |
| `u_ack_sync.sync_q` |  | MULTIBIT_SYNC | 11 bits | CDC-W02 |
| `u_mon_core.u_gsync.sync_q` |  | MULTIBIT_SYNC | 8 bits | CDC-W03 |
| `u_q_sync.sync_q` |  | MULTIBIT_SYNC | 3 bits | CDC-W05 |
| `u_rdy_sync.sync_q` |  | MULTIBIT_SYNC | 2 bits | CDC-W06 |
| `u_wreq_sync.sync_q` |  | MULTIBIT_SYNC | 2 bits | CDC-W04 |
| `u_hs_cfg.dst_data_o[0]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[0] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[10]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[10] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[11]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[11] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[12]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[12] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[13]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[13] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[14]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[14] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[15]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[15] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[16]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[16] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[17]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[17] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[18]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[18] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[19]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[19] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[1]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[1] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[20]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[20] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[21]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[21] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[22]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[22] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[23]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[23] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[24]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[24] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[25]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[25] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[26]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[26] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[27]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[27] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[28]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[28] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[29]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[29] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[2]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[2] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[30]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[30] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[31]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[31] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[32]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[32] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[33]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[33] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[34]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[34] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[3]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[3] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[4]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[4] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[5]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[5] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[6]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[6] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[7]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[7] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[8]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[8] (clk_core) | CDC-W01 |
| `u_hs_cfg.dst_data_o[9]` | clk_ref | QUASI_STATIC_DATA | u_hs_cfg.src_hold_q[9] (clk_core) | CDC-W01 |
| `u_hs_cmd.dst_data_o[0]` | clk_ref | QUASI_STATIC_DATA | u_hs_cmd.src_hold_q[0] (clk_core) | CDC-W01 |
| `u_hs_cmd.dst_data_o[1]` | clk_ref | QUASI_STATIC_DATA | u_hs_cmd.src_hold_q[1] (clk_core) | CDC-W01 |
| `u_hs_cmd.dst_data_o[2]` | clk_ref | QUASI_STATIC_DATA | u_hs_cmd.src_hold_q[2] (clk_core) | CDC-W01 |
| `u_hs_cmd.dst_data_o[3]` | clk_ref | QUASI_STATIC_DATA | u_hs_cmd.src_hold_q[3] (clk_core) | CDC-W01 |
| `u_hs_cmd.dst_data_o[4]` | clk_ref | QUASI_STATIC_DATA | u_hs_cmd.src_hold_q[4] (clk_core) | CDC-W01 |
| `u_hs_snap.dst_data_o[0]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[0] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[100]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[100] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[101]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[101] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[102]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[102] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[103]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[103] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[104]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[104] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[105]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[105] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[106]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[106] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[107]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[107] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[108]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[108] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[109]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[109] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[10]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[10] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[110]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[110] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[111]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[111] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[112]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[112] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[113]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[113] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[114]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[114] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[115]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[115] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[116]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[116] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[117]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[117] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[118]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[118] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[119]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[119] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[11]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[11] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[120]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[120] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[121]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[121] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[122]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[122] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[123]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[123] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[124]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[124] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[125]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[125] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[126]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[126] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[127]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[127] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[12]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[12] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[13]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[13] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[14]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[14] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[15]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[15] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[16]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[16] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[17]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[17] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[18]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[18] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[1]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[1] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[25]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[25] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[26]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[26] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[27]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[27] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[28]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[28] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[29]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[29] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[2]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[2] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[30]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[30] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[31]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[31] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[32]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[32] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[33]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[33] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[34]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[34] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[35]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[35] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[36]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[36] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[37]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[37] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[38]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[38] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[39]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[39] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[3]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[3] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[40]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[40] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[41]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[41] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[42]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[42] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[43]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[43] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[44]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[44] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[45]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[45] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[46]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[46] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[47]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[47] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[48]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[48] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[49]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[49] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[4]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[4] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[50]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[50] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[51]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[51] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[52]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[52] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[53]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[53] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[54]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[54] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[55]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[55] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[56]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[56] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[57]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[57] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[58]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[58] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[59]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[59] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[5]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[5] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[60]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[60] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[61]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[61] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[62]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[62] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[63]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[63] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[64]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[64] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[65]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[65] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[66]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[66] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[67]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[67] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[68]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[68] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[69]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[69] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[6]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[6] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[70]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[70] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[71]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[71] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[72]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[72] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[73]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[73] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[74]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[74] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[75]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[75] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[76]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[76] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[77]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[77] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[78]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[78] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[79]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[79] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[7]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[7] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[80]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[80] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[81]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[81] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[82]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[82] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[83]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[83] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[84]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[84] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[85]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[85] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[86]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[86] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[87]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[87] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[88]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[88] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[89]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[89] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[8]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[8] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[90]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[90] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[91]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[91] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[92]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[92] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[93]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[93] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[94]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[94] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[95]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[95] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[96]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[96] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[97]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[97] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[98]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[98] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[99]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[99] (clk_ref) | CDC-W01 |
| `u_hs_snap.dst_data_o[9]` | clk_core | QUASI_STATIC_DATA | u_hs_snap.src_hold_q[9] (clk_ref) | CDC-W01 |
| `u_rdc_log.d_i[0]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[0] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[10]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[10] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[11]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[11] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[12]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[12] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[13]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[13] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[14]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[14] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[15]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[15] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[1]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[1] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[2]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[2] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[3]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[3] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[4]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[4] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[5]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[5] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[6]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[6] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[7]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[7] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[8]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[8] (clk_core) | CDC-W01 |
| `u_rdc_log.d_i[9]` | clk_ref | QUASI_STATIC_DATA | u_hs_clr.src_hold_q[9] (clk_core) | CDC-W01 |
| `g_br[0].u_bg.u_force_sync.sync_q[0]` | clk_core | SYNC_2FF | g_br[0].u_bg.force_i (clk_ref) |  |
| `g_br[1].u_bg.u_force_sync.sync_q[0]` | clk_core | SYNC_2FF | g_br[1].u_bg.force_i (clk_ref) |  |
| `g_mc.u_mon_mc.u_gsync.sync_q[0]` | clk_ref | SYNC_2FF | g_mc.u_mon_mc.gray_i[0] (clk_mc) |  |
| `g_mc.u_mon_mc.u_gsync.sync_q[1]` | clk_ref | SYNC_2FF | g_mc.u_mon_mc.gray_i[1] (clk_mc) |  |
| `g_mc.u_mon_mc.u_gsync.sync_q[2]` | clk_ref | SYNC_2FF | g_mc.u_mon_mc.gray_i[2] (clk_mc) |  |
| `g_mc.u_mon_mc.u_gsync.sync_q[3]` | clk_ref | SYNC_2FF | g_mc.u_mon_mc.gray_i[3] (clk_mc) |  |
| `g_mc.u_mon_mc.u_gsync.sync_q[4]` | clk_ref | SYNC_2FF | g_mc.u_mon_mc.gray_i[4] (clk_mc) |  |
| `g_mc.u_mon_mc.u_gsync.sync_q[5]` | clk_ref | SYNC_2FF | g_mc.u_mon_mc.gray_i[5] (clk_mc) |  |
| `g_mc.u_mon_mc.u_gsync.sync_q[6]` | clk_ref | SYNC_2FF | g_mc.u_mon_mc.gray_i[6] (clk_mc) |  |
| `g_mc.u_mon_mc.u_gsync.sync_q[7]` | clk_ref | SYNC_2FF | g_mc.u_mon_src_mc.bin_q[7] (clk_mc) |  |
| `u_ack_sync.sync_q[0]` | clk_ref | SYNC_2FF | u_root_en.sync_q[1] (clk_core) |  |
| `u_ack_sync.sync_q[10]` | clk_ref | SYNC_2FF | u_ack_sync.d_i[10] (clk_core) |  |
| `u_ack_sync.sync_q[1]` | clk_ref | SYNC_2FF | u_rs_fab.rsync_q[1] (clk_core) |  |
| `u_ack_sync.sync_q[2]` | clk_ref | SYNC_2FF | u_rs_cc.rsync_q[1] (clk_core) |  |
| `u_ack_sync.sync_q[3]` | clk_ref | SYNC_2FF | g_br[0].u_rs_br.rsync_q[1] (clk_core) |  |
| `u_ack_sync.sync_q[4]` | clk_ref | SYNC_2FF | g_br[1].u_rs_br.rsync_q[1] (clk_core) |  |
| `u_ack_sync.sync_q[5]` | clk_ref | SYNC_2FF | u_ack_sync.d_i[5] (clk_core) |  |
| `u_ack_sync.sync_q[6]` | clk_ref | SYNC_2FF | u_ack_sync.d_i[6] (clk_core) |  |
| `u_ack_sync.sync_q[7]` | clk_ref | SYNC_2FF | g_mc.u_rs_mc.rsync_q[1] (clk_mc) |  |
| `u_ack_sync.sync_q[8]` | clk_ref | SYNC_2FF | fab_qack_q (clk_core) |  |
| `u_ack_sync.sync_q[9]` | clk_ref | SYNC_2FF | u_ack_sync.d_i[9] (clk_core) |  |
| `u_hs_cfg.u_ack_sync.sync_q[0]` | clk_core | SYNC_2FF | u_hs_cfg.dst_ack_q (clk_ref) |  |
| `u_hs_cfg.u_req_sync.sync_q[0]` | clk_ref | SYNC_2FF | u_hs_cfg.src_req_q (clk_core) |  |
| `u_hs_clr.u_ack_sync.sync_q[0]` | clk_core | SYNC_2FF | u_hs_clr.dst_ack_q (clk_ref) |  |
| `u_hs_clr.u_req_sync.sync_q[0]` | clk_ref | SYNC_2FF | u_hs_clr.src_req_q (clk_core) |  |
| `u_hs_cmd.u_ack_sync.sync_q[0]` | clk_core | SYNC_2FF | u_hs_cmd.dst_ack_q (clk_ref) |  |
| `u_hs_cmd.u_req_sync.sync_q[0]` | clk_ref | SYNC_2FF | u_hs_cmd.src_req_q (clk_core) |  |
| `u_hs_snap.u_ack_sync.sync_q[0]` | clk_ref | SYNC_2FF | u_hs_snap.dst_ack_q (clk_core) |  |
| `u_hs_snap.u_req_sync.sync_q[0]` | clk_core | SYNC_2FF | u_hs_snap.src_req_q (clk_ref) |  |
| `u_irq_wdog.g_level.u_sync.sync_q[0]` | clk_core | SYNC_2FF | u_hs_snap.src_data_i[10] (clk_ref) |  |
| `u_mon_core.u_gsync.sync_q[0]` | clk_ref | SYNC_2FF | u_mon_core.gray_i[0] (clk_core) |  |
| `u_mon_core.u_gsync.sync_q[1]` | clk_ref | SYNC_2FF | u_mon_core.gray_i[1] (clk_core) |  |
| `u_mon_core.u_gsync.sync_q[2]` | clk_ref | SYNC_2FF | u_mon_core.gray_i[2] (clk_core) |  |
| `u_mon_core.u_gsync.sync_q[3]` | clk_ref | SYNC_2FF | u_mon_core.gray_i[3] (clk_core) |  |
| `u_mon_core.u_gsync.sync_q[4]` | clk_ref | SYNC_2FF | u_mon_core.gray_i[4] (clk_core) |  |
| `u_mon_core.u_gsync.sync_q[5]` | clk_ref | SYNC_2FF | u_mon_core.gray_i[5] (clk_core) |  |
| `u_mon_core.u_gsync.sync_q[6]` | clk_ref | SYNC_2FF | u_mon_core.gray_i[6] (clk_core) |  |
| `u_mon_core.u_gsync.sync_q[7]` | clk_ref | SYNC_2FF | u_mon_src_core.bin_q[7] (clk_core) |  |
| `u_pll_sync.sync_q[0]` | clk_ref | SYNC_2FF | pll_lock_i[0] (async) |  |
| `u_ps_kick.u_ack_sync.sync_q[0]` | clk_core | SYNC_2FF | u_ps_kick.dst_tgl_q (clk_ref) |  |
| `u_ps_kick.u_req_sync.sync_q[0]` | clk_ref | SYNC_2FF | u_ps_kick.src_tgl_q (clk_core) |  |
| `u_q_sync.sync_q[0]` | clk_core | SYNC_2FF | u_q_sync.d_i[0] (clk_ref) |  |
| `u_q_sync.sync_q[1]` | clk_core | SYNC_2FF | u_q_sync.d_i[1] (clk_ref) |  |
| `u_q_sync.sync_q[2]` | clk_core | SYNC_2FF | u_q_sync.d_i[2] (clk_ref) |  |
| `u_rdy_sync.sync_q[0]` | clk_core | SYNC_2FF | u_seq.run_o (clk_ref) |  |
| `u_rdy_sync.sync_q[1]` | clk_core | SYNC_2FF | u_seq.mc_run_o (clk_ref) |  |
| `u_wreq_sync.sync_q[0]` | clk_ref | SYNC_2FF | wdog_req_i[0] (clk_core) |  |
| `u_wreq_sync.sync_q[1]` | clk_ref | SYNC_2FF | wdog_req_i[1] (clk_core) |  |

## Reset distribution

| reset source | release | flops | clocks |
|---|---|---|---|
| `g_br[0].u_rs_br.arst_ni` | RESET_SYNC_STAGE | 2 | clk_core |
| `g_br[1].u_rs_br.arst_ni` | RESET_SYNC_STAGE | 2 | clk_core |
| `g_mc.u_rs_mc.arst_ni` | RESET_SYNC_STAGE | 2 | clk_mc |
| `port:ext_rst_ni` | RESET_SYNC_STAGE | 2 | clk_ref |
| `port:por_ni` | RESET_SYNC_STAGE | 4 | clk_ref |
| `u_dft_root.a_i` | RESET_SYNC_STAGE | 2 | clk_core |
| `u_rs_cc.arst_ni` | RESET_SYNC_STAGE | 2 | clk_core |
| `u_rs_fab.arst_ni` | RESET_SYNC_STAGE | 2 | clk_core |
| `u_rs_ref_por.rsync_q[1]` | RESET_SYNC_STAGE | 4 | clk_core, clk_mc |
| `g_mc.u_rs_mon_mc.rsync_q[1]` | SYNC_RELEASE | 15 | clk_mc |
| `u_rs_fab.arst_ni` | SYNC_RELEASE | 2 | clk_ref |
| `u_rs_fab.rsync_q[1]` | SYNC_RELEASE | 313 | clk_core |
| `u_rs_mon_core.rsync_q[1]` | SYNC_RELEASE | 15 | clk_core |
| `u_rs_ref_fab.rsync_q[1]` | SYNC_RELEASE | 267 | clk_ref |
| `u_rs_ref_por.rsync_q[1]` | SYNC_RELEASE | 91 | clk_ref |
| `u_rs_ref_sys.rsync_q[1]` | SYNC_RELEASE | 259 | clk_ref |

## Reset-domain crossings (same clock, different assertion causes)

| endpoint | source | clock | class | waiver |
|---|---|---|---|---|
| `u_rdc_seq.rdc_q0[0]` | `u_hs_cmd.dst_data_o[0]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_seq.rdc_q0[1]` | `u_hs_cmd.dst_data_o[1]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_seq.rdc_q0[2]` | `u_hs_cmd.dst_data_o[2]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_seq.rdc_q0[3]` | `u_hs_cmd.dst_data_o[3]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_seq.rdc_q0[4]` | `u_hs_cmd.dst_data_o[4]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_seq.rdc_q0[5]` | `u_hs_cmd.dst_valid_o` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_seq.rdc_q0[6]` | `u_wdog.expire_o` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[0]` | `u_rdc_log.d_i[0]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[1]` | `u_rdc_log.d_i[1]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[2]` | `u_rdc_log.d_i[2]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[3]` | `u_rdc_log.d_i[3]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[4]` | `u_rdc_log.d_i[4]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[5]` | `u_rdc_log.d_i[5]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[6]` | `u_rdc_log.d_i[6]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[7]` | `u_rdc_log.d_i[7]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[8]` | `u_rdc_log.d_i[8]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[9]` | `u_rdc_log.d_i[9]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[10]` | `u_rdc_log.d_i[10]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[11]` | `u_rdc_log.d_i[11]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[12]` | `u_rdc_log.d_i[12]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[13]` | `u_rdc_log.d_i[13]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[14]` | `u_rdc_log.d_i[14]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[15]` | `u_rdc_log.d_i[15]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[16]` | `u_rdc_log.d_i[16]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[19]` | `u_rdc_log.d_i[19]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[20]` | `u_rdc_log.d_i[20]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[21]` | `u_rdc_log.d_i[21]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[22]` | `u_rdc_log.d_i[22]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[23]` | `u_rdc_log.d_i[23]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[24]` | `u_rdc_log.d_i[24]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[25]` | `u_rdc_log.d_i[25]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[26]` | `u_rdc_log.d_i[26]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[27]` | `u_rdc_log.d_i[27]` | clk_ref | RDC_ISOLATED |  |
| `u_rdc_log.rdc_q0[33]` | `u_seq.boot_o` | clk_ref | RDC_ISOLATED |  |

## Findings

None.
