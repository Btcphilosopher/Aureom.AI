# Structural CDC / RDC report -- `neg`

Netlist: `/tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_async_release/netlist.json` (flattened, Liberty-mapped).  Case analysis: `{}`.

**Verdict: PASS** -- findings by severity: {'FAIL': 2}

## Clocks reached (structural)

| clock | sequential / ICG sinks | behind an ICG | ICG levels |
|---|---|---|---|
| clka | 1 | 0 | [0] |
| clkb | 1 | 0 | [0] |

## Crossings

| class | count |
|---|---|

| endpoint | clock | class | source(s) | waiver |
|---|---|---|---|---|

## Reset distribution

| reset source | release | flops | clocks |
|---|---|---|---|
| `req_n` | ASYNC_RELEASE | 1 | clkb |
| `port:rst_ni` | RESET_SYNC_STAGE | 1 | clka |

## Reset-domain crossings (same clock, different assertion causes)

None.

## Findings

* **FAIL** RDC-ASYNC-RELEASE `q_o`: q_o (clkb) released by req_n (clka) without a reset synchroniser
* **FAIL** RDC-ASYNC-RELEASE `req_n`: port rst_ni releases req_n asynchronously
