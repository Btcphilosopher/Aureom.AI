# Structural CDC / RDC report -- `neg`

Netlist: `/tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_multibit_bus/netlist.json` (flattened, Liberty-mapped).  Case analysis: `{}`.

**Verdict: PASS** -- findings by severity: {'FAIL': 12, 'REVIEW': 1}

## Clocks reached (structural)

| clock | sequential / ICG sinks | behind an ICG | ICG levels |
|---|---|---|---|
| clka | 4 | 0 | [0] |
| clkb | 8 | 0 | [0] |

## Crossings

| class | count |
|---|---|
| MULTIBIT_SYNC | 1 |
| SYNC_2FF | 4 |

| endpoint | clock | class | source(s) | waiver |
|---|---|---|---|---|
| `s0` |  | MULTIBIT_SYNC | 4 bits |  |
| `s0[0]` | clkb | SYNC_2FF | cnt_q[0] (clka) |  |
| `s0[1]` | clkb | SYNC_2FF | cnt_q[1] (clka) |  |
| `s0[2]` | clkb | SYNC_2FF | cnt_q[2] (clka) |  |
| `s0[3]` | clkb | SYNC_2FF | cnt_q[3] (clka) |  |

## Reset distribution

| reset source | release | flops | clocks |
|---|---|---|---|
| `port:rst_ni` | RESET_SYNC_STAGE | 12 | clka, clkb |

## Reset-domain crossings (same clock, different assertion causes)

None.

## Findings

* **FAIL** RDC-ASYNC-RELEASE `cnt_q[3]`: port rst_ni releases cnt_q[3] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `s0[0]`: port rst_ni releases s0[0] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `s0[1]`: port rst_ni releases s0[1] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `s0[2]`: port rst_ni releases s0[2] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `s0[3]`: port rst_ni releases s0[3] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `q_o[0]`: port rst_ni releases q_o[0] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `q_o[1]`: port rst_ni releases q_o[1] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `q_o[2]`: port rst_ni releases q_o[2] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `q_o[3]`: port rst_ni releases q_o[3] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `cnt_q[0]`: port rst_ni releases cnt_q[0] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `cnt_q[1]`: port rst_ni releases cnt_q[1] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `cnt_q[2]`: port rst_ni releases cnt_q[2] asynchronously
* **REVIEW** CDC-MULTIBIT_SYNC `s0`: CDC-MULTIBIT_SYNC without a waiver
