# Structural CDC / RDC report -- `neg`

Netlist: `/tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_decoded_reset/netlist.json` (flattened, Liberty-mapped).  Case analysis: `{}`.

**Verdict: PASS** -- findings by severity: {'FAIL': 9}

## Clocks reached (structural)

| clock | sequential / ICG sinks | behind an ICG | ICG levels |
|---|---|---|---|
| clka | 9 | 0 | [0] |

## Crossings

| class | count |
|---|---|

| endpoint | clock | class | source(s) | waiver |
|---|---|---|---|---|

## Reset distribution

| reset source | release | flops | clocks |
|---|---|---|---|
| `port:rst_ni` | RESET_SYNC_STAGE | 8 | clka |
| `rs[1]` | SYNC_RELEASE | 1 | clka |
| `str_q[0]` | SYNC_RELEASE | 2 | clka |
| `str_q[1]` | SYNC_RELEASE | 2 | clka |
| `str_q[2]` | SYNC_RELEASE | 2 | clka |
| `str_q[3]` | SYNC_RELEASE | 2 | clka |
| `str_q[4]` | SYNC_RELEASE | 2 | clka |
| `str_q[5]` | SYNC_RELEASE | 2 | clka |

## Reset-domain crossings (same clock, different assertion causes)

None.

## Findings

* **FAIL** RDC-ASYNC-RELEASE `str_q[0]`: port rst_ni releases str_q[0] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `str_q[1]`: port rst_ni releases str_q[1] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `str_q[2]`: port rst_ni releases str_q[2] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `str_q[3]`: port rst_ni releases str_q[3] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `str_q[4]`: port rst_ni releases str_q[4] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `str_q[5]`: port rst_ni releases str_q[5] asynchronously
* **FAIL** RDC-COMB `rs[0]`: reset of rs[0] passes through logic: sg13g2_and2_1, sg13g2_nor3_1, sg13g2_or4_1
* **FAIL** RDC-COMB `rs[1]`: reset of rs[1] passes through logic: sg13g2_and2_1, sg13g2_nor3_1, sg13g2_or4_1
* **FAIL** PORT-ASYNC `rst_ni`: rst_ni enters logic sg13g2_and2_1 $abc$257$auto$blifparse.cc:386:parse_blif$263
