# Structural CDC / RDC report -- `neg`

Netlist: `/tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_comb_clkgate/netlist.json` (flattened, Liberty-mapped).  Case analysis: `{}`.

**Verdict: PASS** -- findings by severity: {'FAIL': 3}

## Clocks reached (structural)

| clock | sequential / ICG sinks | behind an ICG | ICG levels |
|---|---|---|---|
| clka | 2 | 0 | [0] |

## Crossings

| class | count |
|---|---|

| endpoint | clock | class | source(s) | waiver |
|---|---|---|---|---|

## Reset distribution

| reset source | release | flops | clocks |
|---|---|---|---|
| `port:rst_ni` | RESET_SYNC_STAGE | 2 | clka |

## Reset-domain crossings (same clock, different assertion causes)

None.

## Findings

* **FAIL** CLK-COMB-GATING `$auto$ff.cc:266:slice$86`: clock clka reaches $auto$ff.cc:266:slice$86 through sg13g2_and2_1 $abc$90$auto$blifparse.cc:386:parse_blif$91
* **FAIL** RDC-ASYNC-RELEASE `q_o`: port rst_ni releases q_o asynchronously
* **FAIL** RDC-ASYNC-RELEASE `en_q`: port rst_ni releases en_q asynchronously
