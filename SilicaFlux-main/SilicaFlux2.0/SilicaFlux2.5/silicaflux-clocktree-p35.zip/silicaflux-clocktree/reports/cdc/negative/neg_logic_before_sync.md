# Structural CDC / RDC report -- `neg`

Netlist: `/tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_logic_before_sync/netlist.json` (flattened, Liberty-mapped).  Case analysis: `{}`.

**Verdict: PASS** -- findings by severity: {'FAIL': 5}

## Clocks reached (structural)

| clock | sequential / ICG sinks | behind an ICG | ICG levels |
|---|---|---|---|
| clka | 2 | 0 | [0] |
| clkb | 2 | 0 | [0] |

## Crossings

| class | count |
|---|---|
| LOGIC_BEFORE_SYNC | 1 |

| endpoint | clock | class | source(s) | waiver |
|---|---|---|---|---|
| `s0` | clkb | LOGIC_BEFORE_SYNC | b_q (clka), a_q (clka) |  |

## Reset distribution

| reset source | release | flops | clocks |
|---|---|---|---|
| `port:rst_ni` | RESET_SYNC_STAGE | 4 | clka, clkb |

## Reset-domain crossings (same clock, different assertion causes)

None.

## Findings

* **FAIL** CDC-LOGIC_BEFORE_SYNC `s0`: 1 logic cells / 2 sources feed synchroniser stage s0
* **FAIL** RDC-ASYNC-RELEASE `s0`: port rst_ni releases s0 asynchronously
* **FAIL** RDC-ASYNC-RELEASE `q_o`: port rst_ni releases q_o asynchronously
* **FAIL** RDC-ASYNC-RELEASE `a_q`: port rst_ni releases a_q asynchronously
* **FAIL** RDC-ASYNC-RELEASE `b_q`: port rst_ni releases b_q asynchronously
