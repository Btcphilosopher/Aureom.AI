# Structural CDC / RDC report -- `neg`

Netlist: `/tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_icg_en_cdc/netlist.json` (flattened, Liberty-mapped).  Case analysis: `{}`.

**Verdict: PASS** -- findings by severity: {'FAIL': 3, 'REVIEW': 1}

## Clocks reached (structural)

| clock | sequential / ICG sinks | behind an ICG | ICG levels |
|---|---|---|---|
| clka | 2 | 1 | [0, 1] |
| clkb | 1 | 0 | [0] |

## Crossings

| class | count |
|---|---|
| QUASI_STATIC_DATA | 1 |

| endpoint | clock | class | source(s) | waiver |
|---|---|---|---|---|
| `en_q` | clkb | QUASI_STATIC_DATA | en_i[0] (clka) |  |

## Reset distribution

| reset source | release | flops | clocks |
|---|---|---|---|
| `port:rst_ni` | RESET_SYNC_STAGE | 2 | clka, clkb |

## Reset-domain crossings (same clock, different assertion causes)

None.

## Findings

* **FAIL** CLK-ICG-EN-CDC `u_icg`: ICG enable of u_icg launched from ['clkb']
* **FAIL** RDC-ASYNC-RELEASE `q_o`: port rst_ni releases q_o asynchronously
* **FAIL** RDC-ASYNC-RELEASE `en_q`: port rst_ni releases en_q asynchronously
* **REVIEW** CDC-QUASI_STATIC_DATA `en_q`: CDC-QUASI_STATIC_DATA without a waiver
