# Structural CDC / RDC report -- `neg`

Netlist: `/tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/pos_good_sync/netlist.json` (flattened, Liberty-mapped).  Case analysis: `{}`.

**Verdict: PASS** -- findings by severity: {'FAIL': 0, 'REVIEW': 0}

## Clocks reached (structural)

| clock | sequential / ICG sinks | behind an ICG | ICG levels |
|---|---|---|---|
| clka | 3 | 0 | [0] |
| clkb | 5 | 0 | [0] |

## Crossings

| class | count |
|---|---|
| SYNC_2FF | 1 |

| endpoint | clock | class | source(s) | waiver |
|---|---|---|---|---|
| `s0` | clkb | SYNC_2FF | a_q (clka) |  |

## Reset distribution

| reset source | release | flops | clocks |
|---|---|---|---|
| `port:rst_ni` | RESET_SYNC_STAGE | 4 | clka, clkb |
| `rsa[1]` | SYNC_RELEASE | 1 | clka |
| `rsb[1]` | SYNC_RELEASE | 3 | clkb |

## Reset-domain crossings (same clock, different assertion causes)

None.

## Findings

None.
