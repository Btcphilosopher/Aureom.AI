# Structural CDC / RDC report -- `neg`

Netlist: `/tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_rdc_data/netlist.json` (flattened, Liberty-mapped).  Case analysis: `{}`.

**Verdict: PASS** -- findings by severity: {'FAIL': 3, 'REVIEW': 2}

## Clocks reached (structural)

| clock | sequential / ICG sinks | behind an ICG | ICG levels |
|---|---|---|---|
| clka | 6 | 0 | [0] |

## Crossings

| class | count |
|---|---|

| endpoint | clock | class | source(s) | waiver |
|---|---|---|---|---|

## Reset distribution

| reset source | release | flops | clocks |
|---|---|---|---|
| `port:rst_ni` | RESET_SYNC_STAGE | 3 | clka |
| `r1` | SYNC_RELEASE | 1 | clka |
| `req_n` | SYNC_RELEASE | 2 | clka |

## Reset-domain crossings (same clock, different assertion causes)

| endpoint | source | clock | class | waiver |
|---|---|---|---|---|
| `q_o[0]` | `a_q` | clka | RDC_DATA |  |
| `q_o[1]` | `a_q` | clka | RDC_DATA |  |

## Findings

* **FAIL** RDC-ASYNC-RELEASE `req_n`: port rst_ni releases req_n asynchronously
* **FAIL** RDC-ASYNC-RELEASE `q_o[0]`: port rst_ni releases q_o[0] asynchronously
* **FAIL** RDC-ASYNC-RELEASE `q_o[1]`: port rst_ni releases q_o[1] asynchronously
* **REVIEW** RDC-DATA `q_o[0]`: RDC-DATA without a waiver
* **REVIEW** RDC-DATA `q_o[1]`: RDC-DATA without a waiver
