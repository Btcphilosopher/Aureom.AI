# CDC / RDC checker negative tests

Each design is synthesised to IHP SG13G2 like the real block and checked by scripts/cdc_check.py.

| design | rule that must fire | result | checker output |
|---|---|---|---|
| `neg_comb_clkgate` | CLK-COMB-GATING | PASS | [PASS] negative test /tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_comb_clkgate/netlist.json: expected ['CLK-COMB-GATING'], fired ['CLK-COMB-GATING', 'RDC-ASYNC-RELEASE'] |
| `neg_logic_before_sync` | CDC-LOGIC_BEFORE_SYNC | PASS | [PASS] negative test /tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_logic_before_sync/netlist.json: expected ['CDC-LOGIC_BEFORE_SYNC'], fired ['CDC-LOGIC_BEFORE_SYNC', 'RDC-ASYNC-RELEASE'] |
| `neg_multibit_bus` | CDC-MULTIBIT_SYNC | PASS | [PASS] negative test /tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_multibit_bus/netlist.json: expected ['CDC-MULTIBIT_SYNC'], fired ['CDC-MULTIBIT_SYNC', 'RDC-ASYNC-RELEASE'] |
| `neg_decoded_reset` | RDC-COMB | PASS | [PASS] negative test /tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_decoded_reset/netlist.json: expected ['RDC-COMB'], fired ['PORT-ASYNC', 'RDC-ASYNC-RELEASE', 'RDC-COMB'] |
| `neg_async_release` | RDC-ASYNC-RELEASE | PASS | [PASS] negative test /tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_async_release/netlist.json: expected ['RDC-ASYNC-RELEASE'], fired ['RDC-ASYNC-RELEASE'] |
| `neg_rdc_data` | RDC-DATA | PASS | [PASS] negative test /tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_rdc_data/netlist.json: expected ['RDC-DATA'], fired ['RDC-ASYNC-RELEASE', 'RDC-DATA'] |
| `neg_icg_en_cdc` | CLK-ICG-EN-CDC | PASS | [PASS] negative test /tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_icg_en_cdc/netlist.json: expected ['CLK-ICG-EN-CDC'], fired ['CDC-QUASI_STATIC_DATA', 'CLK-ICG-EN-CDC', 'RDC-ASYNC-RELEASE'] |
| `neg_ripple_clock` | CLK-UNCLOCKED | PASS | [PASS] negative test /tmp/claude-0/-home-user-Aureom-AI/c64271db-133d-5676-8915-4a6eb2493d5f/scratchpad/silicaflux-clocktree/build/cdc_negative/neg_ripple_clock/netlist.json: expected ['CLK-UNCLOCKED'], fired ['CLK-UNCLOCKED', 'RDC-ASYNC-RELEASE'] |
| `pos_good_sync` | (none: must pass) | PASS | [PASS] neg: crossings {'SYNC_2FF': 1}; FAIL 0 REVIEW 0 WARN 0 |
