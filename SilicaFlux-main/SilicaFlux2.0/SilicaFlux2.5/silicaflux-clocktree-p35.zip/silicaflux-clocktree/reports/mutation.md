# Mutation analysis

**16 / 16 mutants killed** by the system testbench (Icarus, seed 1).

| id | injected defect | tests run | result | first evidence |
|---|---|---|---|---|
| M01 | sequencer releases the ControlCore together with the fabric (ordering) | por | KILLED | por: ERROR 1039500 [por] ControlCore released 0.0 ns after the fabric (< FAB_DELAY reference cycles) |
| M02 | gated branch released without forcing its clock on | clk_en | KILLED | clk_en: ERROR 404570000 [clk_en] sequence did not reach RUN ACC reset of gated branches |
| M03 | clock monitor accepts any count (no frequency window) | clk_start, clk_loss | KILLED | clk_start: ERROR 9030000 [clk_start] out-of-range clock must not be accepted |
| M04 | reset synchroniser removed (asynchronous release) | por | KILLED | por: ERROR 990000 fab_rst_no: reset released 6.500 ns after the last clock edge (not synchronous) |
| M05 | clock gated with a plain AND (no latch) | clk_en | KILLED | clk_en: ERROR 1991500 clk_br_o[0]: falling edge without a source falling edge (truncated pulse) |
| M06 | watchdog ignores service | wdog | KILLED | wdog: ERROR 41678000 [wdog] a serviced watchdog must not warn or reset |
| M07 | external reset not recorded in the cause log | ext_rst | KILLED | ext_rst: ERROR 4445000 [ext_rst] CAUSE = 0x0001, expected bits 0x0003 (POR/EXT) |
| M08 | software reset key not checked | sw_reset | KILLED | sw_reset: ERROR 1645000 [sw_reset] write 0x14 <= 0xdead0003: rb_err=0, expected 1 |
| M09 | branch gate ignores the busy request (no interlock) | clk_en | KILLED | clk_en: ERROR 2481500 [clk_en] branch 0 gated while it requests its clock |
| M10 | graceful reset does not wait for the drain | sw_reset | KILLED | sw_reset: FAIL |
| M11 | clock / PLL loss not acted upon | clk_loss | KILLED | clk_loss: ERROR 2170000 [clk_loss] resets asserted with the core clock stopped (asynchronous assertion) |
| M12 | handshake payload not held (source re-samples every cycle) | cdc, wdog | KILLED | cdc: FATAL: rtl/cdc/sf_crt_handshake.sv:89: sf_crt_handshake tb_crt_top.u_dut.u_hs_snap: QUASI-STATIC VIOLATION -- payload changed 0.000 ns befor |
| M13 | clock-monitor saturating counter wraps (the bug found by regression) | wdog, cdc | KILLED | wdog: FAIL |
| M14 | root clock gate opened before the PLL is locked | clk_start, por | KILLED | clk_start: ERROR 11670000 [clk_start] a chattering lock must not open the root gate |
| M15 | watchdog request input ignored | ext_wdog | KILLED | ext_wdog: FAIL |
| M16 | test mode does not bypass the reset synchroniser output | test_mode | KILLED | test_mode: ERROR 1633000 [test_mode] test mode: resets follow test_rst_ni (1) |
