# Lint

Verilator `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)` with `-Wall` (only DECLFILENAME disabled: several technology cells share one file).

| target | configuration | warnings / errors |
|---|---|---|
| silicaflux_clock_reset_tree | MC_EN=0 NB=1 | clean |
| silicaflux_clock_reset_tree | MC_EN=0 NB=2 | clean |
| silicaflux_clock_reset_tree | MC_EN=0 NB=8 | clean |
| silicaflux_clock_reset_tree | MC_EN=1 NB=1 | clean |
| silicaflux_clock_reset_tree | MC_EN=1 NB=2 | clean |
| silicaflux_clock_reset_tree | MC_EN=1 NB=8 | clean |
| silicaflux_clock_reset_tree | +SF_CRT_CDC_RANDOM (sim model) | clean |
| silicaflux_clock_reset_tree | +SF_CRT_CG_ENABLE_ONLY | clean |
| sf_crt_async_fifo | standalone | clean |
| sf_crt_handshake | standalone | clean |
| sf_crt_pulse_sync | standalone | clean |
| sf_crt_irq_sync | EDGE_MODE=1 | clean |
| sf_crt_rst_sync | standalone | clean |
| sf_crt_clk_gate | ICG (sim cell) | clean |
| Icarus 12 elaboration | default | clean (only Icarus 'sorry' notes on unique-case / constant selects, no effect) |
