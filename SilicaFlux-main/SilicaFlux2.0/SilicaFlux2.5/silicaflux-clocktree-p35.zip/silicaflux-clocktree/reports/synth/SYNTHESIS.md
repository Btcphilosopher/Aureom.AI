# Synthesis summary (Yosys)

Tool: `Yosys 0.33 (git sha1 2584903a060)`

| run | result | detail |
|---|---|---|
| ihp_sg13g2_baseline | PASS | 2457 cells, 781 flops, 2 ICG, 0 latches |
| ihp_sg13g2_research | PASS | 3118 cells, 982 flops, 3 ICG, 0 latches |
| ihp_sg13g2_enable_only | PASS | 2445 cells, 0 ICG (expected 0: clock-enable methodology) |
| sky130hd_baseline | PASS | 2198 cells, 2 sdlclkp ICG |
| fpga_ecp5_baseline | PASS | 2 x DCCA, 0 latches |
| fpga_xilinx_baseline | PASS | 2 x BUFGCE, 0 latches |
| negative_no_target | PASS | synthesis refused (sf_crt_icg_target_not_selected) -- as required |

`ihp_sg13g2_baseline`: 2457 cells, 781 flip-flops, area 56636.6 um^2 (standard cells, typ Liberty; not a placed area), 15 DFT mux, 1 reset-combine AND2, 2 ICG.

`ihp_sg13g2_research`: 3118 cells, 982 flip-flops, area 71399.5 um^2 (standard cells, typ Liberty; not a placed area), 21 DFT mux, 1 reset-combine AND2, 3 ICG.
