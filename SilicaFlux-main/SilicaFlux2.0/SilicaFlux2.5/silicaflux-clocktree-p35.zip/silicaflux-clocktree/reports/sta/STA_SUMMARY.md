# Timing check summary (sf_sta -- indicative, NOT signoff)

OpenSTA / OpenROAD could not be installed in this environment; these numbers come from the in-house
NLDM checker (scripts/sf_sta.py) on the Yosys netlist mapped to the IHP SG13G2 Liberty, pin-capacitance
loads, an estimated buffer tree on nets with > 16 sinks, ideal clocks unless marked `propagated`.
Run cts/sta_signoff.tcl with OpenSTA for signoff.

| run | kind | violations | unconstrained | false-path-only | worst setup group (slack ns) | worst hold (ns) | Fmax* reg2reg (MHz) |
|---|---|---|---|---|---|---|---|
| baseline_func_prects_typ | gating | 0 | 0 | 5 | in2out clk_core: 2.542 | 0.048 | clk_core 721.0, clk_ref 252.8 |
| baseline_func_prects_slow | gating | 0 | 0 | 5 | in2out clk_core: 1.880 | 0.114 | clk_core 493.7, clk_ref 166.1 |
| baseline_func_prects_fast | gating | 0 | 0 | 5 | in2out clk_core: 2.935 | 0.004 | clk_core 1001.5, clk_ref 369.1 |
| baseline_test_typ | gating | 0 | 0 | 1 | in2out clk_core: 18.542 | 0.048 | clk_core 721.0, clk_ref 252.8 |
| baseline_test_slow | gating | 0 | 0 | 1 | in2out clk_core: 17.880 | 0.114 | clk_core 493.7, clk_ref 166.1 |
| baseline_test_fast | gating | 0 | 0 | 1 | in2out clk_core: 18.935 | 0.004 | clk_core 1001.5, clk_ref 369.1 |
| baseline_func_prects_slow_wire20 | sensitivity: +20 um wire / fanout | 1 | 0 | 5 | in2out clk_core: -0.062 | 0.148 | clk_core 206.5, clk_ref 105.8 |
| baseline_func_postcts_typ_prop | informational: UNBUFFERED propagated clocks (no CTS) | 188 | 0 | 5 | in2out clk_core: 2.692 | -2.650 | clk_core 725.2, clk_ref 262.8 |
| research_func_prects_typ | gating | 0 | 0 | 5 | in2out clk_core: 2.542 | 0.048 | clk_core 651.7, clk_ref 233.4, clk_mc 765.5 |
| research_func_prects_slow | gating | 0 | 0 | 5 | in2out clk_core: 1.885 | 0.114 | clk_core 444.8, clk_ref 153.8, clk_mc 523.6 |
| research_func_prects_fast | gating | 0 | 0 | 5 | in2out clk_core: 2.940 | 0.004 | clk_core 912.3, clk_ref 342.0, clk_mc 1041.9 |
| research_test_typ | gating | 0 | 0 | 1 | in2out clk_core: 18.543 | 0.048 | clk_core 651.7, clk_ref 233.4, clk_mc 765.5 |
| research_test_slow | gating | 0 | 0 | 1 | in2out clk_core: 17.885 | 0.114 | clk_core 444.8, clk_ref 153.8, clk_mc 523.6 |
| research_test_fast | gating | 0 | 0 | 1 | in2out clk_core: 18.940 | 0.004 | clk_core 912.3, clk_ref 342.0, clk_mc 1041.9 |
| research_func_prects_slow_wire20 | sensitivity: +20 um wire / fanout | 1 | 0 | 5 | in2out clk_core: -0.018 | 0.148 | clk_core 208.1, clk_ref 95.9, clk_mc 373.1 |
| research_func_postcts_typ_prop | informational: UNBUFFERED propagated clocks (no CTS) | 198 | 0 | 5 | in2out clk_core: 2.692 | -2.979 | clk_core 652.6, clk_ref 241.9, clk_mc 864.9 |

Fmax* = 1 / (T - worst reg2reg setup slack): DERIVED from ideal-clock, pin-capacitance analysis of
this block only; not a measured or achievable die frequency.

## Path groups -- baseline, functional, pre-CTS, slow corner (1.08 V, 125 C)

| group | endpoints | setup WNS (ns) | hold WNS (ns) | raw WNS without estimated buffer trees (ns) |
|---|---|---|---|---|
| cdc_max_delay clk_core->clk_ref | 76 | 6.6791 | None | 2.1133 |
| cdc_max_delay clk_ref->clk_core | 121 | 8.771 | None | 6.8584 |
| clock_gating clk_core | 2 | 9.2042 | 0.2793 | 9.2042 |
| in2out clk_core | 33 | 1.8799 | 0.1768 | 1.4169 |
| in2reg clk_core | 94 | 4.2453 | 0.1139 | 1.0165 |
| recovery clk_core | 293 | 8.5416 | 0.9824 | 1.6931 |
| recovery clk_ref | 474 | 38.5959 | 0.597 | 32.6114 |
| reg clk_core | 287 | 7.9744 | 0.2234 | 3.709 |
| reg clk_ref | 452 | 33.9783 | 0.2234 | 33.1646 |
| reg2out clk_core | 40 | 5.4175 | 0.2244 | 0.4774 |
| reg2out clk_ref | 4 | 27.3126 | 0.2948 | 27.3126 |

### Endpoints constrained only by justified false paths (asynchronous ports)

* `u_pll_sync.sync_q[0]/D` (reg): false-path ports only
* `u_rs_ref_sys.rsync_q[0]/RESET_B` (recovery): false-path ports only
* `u_rs_ref_sys.rsync_q[1]/RESET_B` (recovery): false-path ports only
* `u_rs_ref_por.rsync_q[0]/RESET_B` (recovery): false-path ports only
* `u_rs_ref_por.rsync_q[1]/RESET_B` (recovery): false-path ports only

### Worst setup paths (slow)

* **in2out clk_core** `port rb_err_o[0]` slack 1.880 ns: port rb_addr_i -> sg13g2_nor2_1 -> n240 (+0.114) -> sg13g2_nand3b_1 -> n241 (+0.304) -> sg13g2_nor2_1 -> n567 (+0.828) -> sg13g2_nor4_1 -> n799 (+0.063) -> sg13g2_nand3_1 -> n800 (+0.076) -> sg13g2_a221oi_1 -> n824 (+0.065) -> sg13g2_o21ai_1 -> n825 (+0.059) -> sg13g2_a21oi_1 -> n828 (+0.091) -> sg13g2_nor2b_1 -> rb_err_o (+0.106)
* **in2out clk_core** `port rb_err_o[0]` slack 1.963 ns: port rb_addr_i -> sg13g2_nor2_1 -> n240 (+0.114) -> sg13g2_nand3b_1 -> n241 (+0.304) -> sg13g2_nor2_1 -> n567 (+0.828) -> sg13g2_nor4_1 -> n799 (+0.063) -> sg13g2_nand3_1 -> n800 (+0.076) -> sg13g2_nor4_1 -> n827 (+0.073) -> sg13g2_a21oi_1 -> n828 (+0.094) -> sg13g2_nor2b_1 -> rb_err_o (+0.071)
* **in2out clk_core** `port rb_rdata_o[0]` slack 2.119 ns: port rb_addr_i -> sg13g2_nor2_1 -> n240 (+0.114) -> sg13g2_nand3b_1 -> n241 (+0.304) -> sg13g2_nor2_1 -> n567 (+0.828) -> sg13g2_a221oi_1 -> n582 (+0.122) -> sg13g2_nand3_1 -> rb_rdata_o[0] (+0.098)
* **in2out clk_core** `port rb_rdata_o[1]` slack 2.133 ns: port rb_addr_i -> sg13g2_nor2_1 -> n240 (+0.114) -> sg13g2_nand3b_1 -> n241 (+0.304) -> sg13g2_nor2_1 -> n567 (+0.828) -> sg13g2_a221oi_1 -> n587 (+0.121) -> sg13g2_nand3_1 -> rb_rdata_o[1] (+0.085)

## Clock insertion through the ICGs (research, typ, unbuffered, indicative)

| clock sinks | pins | latency min (ns) | latency max (ns) |
|---|---|---|---|
| clk_core behind 0 ICG | 20 | 0.0 | 0.0 |
| clk_core behind 1 ICG | 319 | 2.775 | 2.775 |
| clk_core behind 2 ICG | 4 | 3.2346 | 3.2346 |
| clk_mc behind 0 ICG | 19 | 0.0 | 0.0 |
| clk_ref behind 0 ICG | 623 | 0.0 | 0.0 |

Pre-CTS, a gated branch sits one or two ICG delays behind the ungated root sinks: CTS must
balance these sink groups (cts/ configuration, skew budget in config/clock_spec.yaml).
