# CTS preparation check

The generated OpenROAD CTS configuration (cts/cts_config_<tech>.tcl, from config/clock_spec.yaml)
checked against the actual technology files and the synthesised netlists.  **This is not a CTS run**:
OpenROAD could not be installed here, so no clock tree has been built and no closure is claimed.

**Verdict: PASS**

| scope | item | result | detail |
|---|---|---|---|
| ihp_sg13g2 | clock buffer sg13g2_buf_16 | PASS | Liberty yes, LEF yes, buffer True, dont_use False, area 45.36 |
| ihp_sg13g2 | clock buffer sg13g2_buf_8 | PASS | Liberty yes, LEF yes, buffer True, dont_use False, area 23.5872 |
| ihp_sg13g2 | clock buffer sg13g2_buf_4 | PASS | Liberty yes, LEF yes, buffer True, dont_use False, area 14.5152 |
| ihp_sg13g2 | clock buffer sg13g2_buf_16 | PASS | Liberty yes, LEF yes, buffer True, dont_use False, area 45.36 |
| ihp_sg13g2 | ICG sg13g2_slgcp_1 | PASS | clock_gating_integrated_cell = latch_posedge_precontrol (explicit instantiation; dont_use for inference = True) |
| ihp_sg13g2 | clock_layers Metal3-Metal5 | PASS | routing layers in tech LEF: ['Metal1', 'Metal2', 'Metal3', 'Metal4', 'Metal5', 'TopMetal1', 'TopMetal2'] |
| ihp_sg13g2 | signal_layers Metal2-Metal5 | PASS | routing layers in tech LEF: ['Metal1', 'Metal2', 'Metal3', 'Metal4', 'Metal5', 'TopMetal1', 'TopMetal2'] |
| ihp_sg13g2 | site CoreSite | PASS | SITE found |
| ihp_sg13g2 | clock wire RC | PASS | setRC.tcl: set_wire_rc -clock -resistance 2.48603E-03 -capacitance 1.44812E-04 |
| sky130hd | clock buffer sky130_fd_sc_hd__clkbuf_16 | PASS | Liberty yes, LEF yes, buffer True, dont_use False, area 25.024 |
| sky130hd | clock buffer sky130_fd_sc_hd__clkbuf_8 | PASS | Liberty yes, LEF yes, buffer True, dont_use False, area 13.7632 |
| sky130hd | clock buffer sky130_fd_sc_hd__clkbuf_4 | PASS | Liberty yes, LEF yes, buffer True, dont_use False, area 7.5072 |
| sky130hd | clock buffer sky130_fd_sc_hd__clkbuf_16 | PASS | Liberty yes, LEF yes, buffer True, dont_use False, area 25.024 |
| sky130hd | ICG sky130_fd_sc_hd__sdlclkp_1 | PASS | clock_gating_integrated_cell = latch_posedge_precontrol (explicit instantiation; dont_use for inference = False) |
| sky130hd | clock_layers met3-met5 | PASS | routing layers in tech LEF: ['li1', 'met1', 'met2', 'met3', 'met4', 'met5'] |
| sky130hd | signal_layers met1-met5 | PASS | routing layers in tech LEF: ['li1', 'met1', 'met2', 'met3', 'met4', 'met5'] |
| sky130hd | site unithd | PASS | SITE found |
| sky130hd | clock wire RC | PASS | setRC.tcl: set_wire_rc -clock -layer met3 |
| baseline | root clk_ref = port clk_ref_i | PASS | port present |
| baseline | root clk_core = port clk_core_i | PASS | port present |
| research | root clk_ref = port clk_ref_i | PASS | port present |
| research | root clk_core = port clk_core_i | PASS | port present |
| research | root clk_mc = port clk_mc_i | PASS | port present |

## Sink groups -- baseline (structural clock propagation on the IHP netlist)

| clock / gating level | sinks | leaf clusters (20 sinks) |
|---|---|---|
| clk_core behind 0 ICG | 20 | 1 |
| clk_core behind 1 ICG | 283 | 15 |
| clk_core behind 2 ICG | 2 | 1 |
| clk_ref behind 0 ICG | 478 | 24 |

| pre-CTS clock net | clock | fanout |
|---|---|---|
| `clk_ref_i` | clk_ref | 478 |
| `clk_core_o` | clk_core | 284 |
| `clk_core_i` | clk_core | 20 |
| `clk_br_o` | clk_core | 3 |

## Sink groups -- research (structural clock propagation on the IHP netlist)

| clock / gating level | sinks | leaf clusters (20 sinks) |
|---|---|---|
| clk_core behind 0 ICG | 20 | 1 |
| clk_core behind 1 ICG | 319 | 16 |
| clk_core behind 2 ICG | 4 | 1 |
| clk_mc behind 0 ICG | 19 | 1 |
| clk_ref behind 0 ICG | 623 | 32 |

| pre-CTS clock net | clock | fanout |
|---|---|---|
| `clk_ref_i` | clk_ref | 623 |
| `clk_core_o` | clk_core | 320 |
| `clk_core_i` | clk_core | 20 |
| `clk_mc_i` | clk_mc | 19 |
| `clk_br_o[0]` | clk_core | 3 |
| `clk_br_o[1]` | clk_core | 3 |
