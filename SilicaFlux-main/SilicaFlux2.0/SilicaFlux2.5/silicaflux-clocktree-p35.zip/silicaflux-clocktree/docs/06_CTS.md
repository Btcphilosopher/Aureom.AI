# 06 — Clock-tree synthesis preparation (OpenROAD / TritonCTS)

> **No clock tree has been built and no clock-tree closure is claimed.** OpenROAD could not be installed
> in the environment that produced this project: a prebuilt package and a source build were both refused
> by the environment's permission policy. Everything below is configuration plus static checks. The flow
> is ready to run (`make cts`). The first run on a placed database is the real test.

## 1. Inputs (all generated from `config/clock_spec.yaml`)

| Item | IHP SG13G2 (primary) | SKY130HD (portability) |
|---|---|---|
| Clock buffers | `sg13g2_buf_16`, `sg13g2_buf_8`, `sg13g2_buf_4`. SG13G2 has no dedicated clock buffers; this is the drive-strength set ORFS / TimingFlow use | `sky130_fd_sc_hd__clkbuf_16/8/4` |
| Root buffer | `sg13g2_buf_16` | `sky130_fd_sc_hd__clkbuf_16` |
| ICG | `sg13g2_slgcp_1` (explicitly instantiated, `dont_touch`) | `sky130_fd_sc_hd__sdlclkp_1` |
| Clock routing layers | Metal3–Metal5 (the block PDN keeps Metal5 free) | met3–met5 |
| Signal routing layers | Metal2–Metal5 | met1–met5 |
| Wire RC | platform `setRC.tcl` (`set_wire_rc -clock`) | platform `setRC.tcl` |
| Sink clustering | 20 sinks, 50 µm diameter, `-balance_levels` | same |

Clock roots: `clk_core_i`, `clk_ref_i` and `clk_mc_i` (research).

## 2. Sink groups (from the synthesised netlists, structural clock propagation)

| Group | Baseline sinks | Research sinks | Path |
|---|---|---|---|
| `core_ungated` | 20 | 20 | `clk_core_i` → root-enable synchroniser, core monitor, root ICG CLK |
| `core_root` | 283 | 319 | → `u_cg_root` → fabric / ControlCore-side registers, register file, handshakes, branch ICG CLK |
| `core_branch` | 2 | 4 | → `u_cg_root` → `g_br[b].u_bg.u_cg` → branch reset synchronisers (on the die: the compute cluster) |
| `ref` | 478 | 623 | `clk_ref_i` → sequencer, monitors, watchdog, cause log, snapshot source |
| `mc` | — | 19 | `clk_mc_i` → memory-controller reset synchroniser and monitor source |

Pre-CTS (unbuffered) the gated groups sit 2.8 ns (root group) and 3.2 ns (branch group) behind the
ungated sinks at typ (`reports/sta/research_func_postcts_typ_prop.json`). That is the imbalance CTS must
remove. TritonCTS builds a tree on every clock net, ICG outputs included, and `-balance_levels` balances
the gated levels.

## 3. Insertion-delay and skew budgets (checked after CTS, not CTS inputs)

| Clock | Max insertion | Max skew |
|---|---|---|
| clk_core | 1.0 ns | 0.15 ns (= the pre-CTS skew allowance in the SDC) |
| clk_ref | 1.5 ns | 0.30 ns |
| clk_mc | 1.0 ns | 0.15 ns |

## 4. Flow (`cts/run_block_cts.tcl`)

read LEF / Liberty (multi-corner), netlist, SDC → `set_dont_touch` on the explicit ICG / DFT / reset cells
→ floorplan (45 % utilisation) → tracks, pins, block PDN (`cts/pdn_block_*.tcl`) → global placement →
tie-cell fan-out repair → `repair_design` → detailed placement → **pre-CTS timing** →
`clock_tree_synthesis -root_buf … -buf_list … -sink_clustering_enable … -balance_levels` →
`set_propagated_clock` → `repair_clock_nets` → detailed placement → **`report_cts`, clock skew / latency,
per-sink-group insertion vs budget** (`cts/report_cts_groups.tcl`) → post-CTS timing → `repair_timing
-hold` → global route → post-GRT clock tree + timing → DEF / ODB. Detailed routing, extraction and signoff
STA (`cts/sta_signoff.tcl` with SPEF) follow.

## 5. What was verified here

| Check | Result | Evidence |
|---|---|---|
| Buffer / root / ICG cells exist in Liberty **and** LEF, are buffers, are not dont_use | PASS (both technologies) | `reports/cts/CTS_PRECHECK.md` |
| Clock / signal layer ranges exist and are ordered in the tech LEF; site exists; clock wire RC defined | PASS | same |
| Clock roots exist as ports in both netlists | PASS | same |
| Every flow / CTS / STA / SDC script parses and runs end to end against command stubs; every command is an OpenROAD / OpenSTA command; both technologies × both configurations | PASS | `reports/TCL_DRYRUN.log` |
| Dry run found and fixed: SKY130 `fastroute.tcl` needs `MIN_CLK_ROUTING_LAYER`; `fastroute.tcl` re-sets layer ranges, so the clock layers are re-applied after it | fixed | `cts/run_block_cts.tcl` |
| Real CTS / skew / insertion delay | **NOT RUN** | — |

The die-level tree depends on the FloorplanLab floorplan. FloorplanLab reported it "not ready for CTS"
because of routing overflow around the SRAM macros.
