# Register map — `silicaflux_clock_reset_tree` (`sf_crt_regs`)

SilicaFlux-V register-bus slave: a one-cycle `rb_sel_i` strobe, with `rb_rdata_o` / `rb_err_o`
combinational in the strobe cycle. Side effects happen at the end of that cycle. `rb_err` means refused,
no effect. Clocked by `clk_core_o`, reset by the fabric reset. 8-bit byte offsets.
Everything owned by the reference domain is read from the **status snapshot**, a coherent 128-bit word
delivered by a handshake about every 3 reference + 3 core cycles. A register that launches a CDC channel
answers `rb_err` while that channel is busy; software retries.

| Off | Name | Access | Fields |
|---|---|---|---|
| 0x00 | ID | RO | `0x5346_4354` ("SFCT") |
| 0x04 | CONFIG | RO | [31:24] version (1), [23:16] NB, [15:8] NW, [0] MC_EN |
| 0x08 | STATUS | RO (snapshot) | [3:0] sequencer state, [5:4] MC state, [6] RUN, [7] PLL_LOCKED, [8] CORE_CLK_OK, [9] MC_CLK_OK, [10] WDOG_WARN, [11] WDOG_EN, [12] WDOG_LOCK, [13] WDOG_RST_EN, [14] QTIMEOUT (sticky), [15] CMD_DROP (sticky), [16] WDOG_CFG_REJECTED (sticky), [19:17] domain released {MC, CC, FAB}, [31] snapshot received since fabric reset |
| 0x0C | CAUSE | RO / W1C | [10:0] sticky reset causes (table below); a write clears the written bits (refused while the clear channel is busy) |
| 0x10 | RST_INFO | RO | [15:0] reset count since POR (saturating), [19:16] last cause (highest priority of the last event), [31:24] branch released mask |
| 0x14 | SW_RST | WO | [31:16] key **0x5AFE**, [12] FORCE (skip drain), [9:8] scope 0 SYSTEM / 1 CONTROL / 2 COMPUTE / 3 MEMCTL, [7:0] branch mask for COMPUTE (0 = all). Wrong key, MEMCTL without an MC domain, or busy channel → `rb_err` |
| 0x18 | CLK_EN | RW | [NB-1:0] software clock enable per branch (reset: all 1). The hardware interlock overrides a 0 while the branch is busy, woken or being reset |
| 0x1C | CLK_STAT | RO | [7:0] gate enable per branch (actual), [15:8] branch clock requests |
| 0x20 | WDOG_CTRL | RW | [0] EN, [1] LOCK, [2] RST_EN (stage 2 resets the chip). A write sends {RST_EN, LOCK, EN, WDOG_LOAD}. A read returns the **effective** values. Refused by the watchdog while locked (STATUS[16]) |
| 0x24 | WDOG_LOAD | RW | reload value in `clk_ref` cycles (local shadow, sent with WDOG_CTRL) |
| 0x28 | WDOG_KICK | WO | write **0x57D0_6EED** to service; another value → `rb_err` |
| 0x2C | WDOG_CNT | RO (snapshot) | current watchdog count |
| 0x30 | CLK_MEAS | RO (snapshot) | [15:0] core edges per monitor window, [31:16] mc edges per window |
| 0x34 | IRQ | RO | [0] watchdog warning (level; cleared by service) |

## Reset-cause bits

| Bit | Cause | Bit | Cause |
|---|---|---|---|
| 0 | POR | 6 | software SYSTEM |
| 1 | external reset pin | 7 | software CONTROL |
| 2 | core clock absent / out of range | 8 | software COMPUTE |
| 3 | PLL lock lost | 9 | software MEMCTL |
| 4 | system watchdog | 10 | memory-controller clock absent / out of range |
| 5 | block watchdog request | | |

## Sequencer states (STATUS[3:0])

0 OFF · 1 WAIT_CLK · 2 ROOT_ON · 3 REL_FAB · 4 REL_CC · 5 REL_ACC · 6 RUN · 7 QUIESCE · 8 ASSERT · 9 CLK_LOST
MC states (STATUS[5:4]): 0 OFF · 1 REL · 2 RUN

## Snapshot layout (128 bits, `u_hs_snap`)

`{mc_meas[15:0], core_meas[15:0], wdog_count[31:0], rst_count[15:0], cause[15:0], last[3:0], ack_mc, ack_cc,
ack_fab, br_ack[7:0], wdog_cfg_rej, cmd_drop, qtimeout, wdog_rst_en, wdog_lock, wdog_en, wdog_warn, mc_ok,
core_ok, pll_locked, run, mc_state[1:0], seq_state[3:0]}` (LSB last).
