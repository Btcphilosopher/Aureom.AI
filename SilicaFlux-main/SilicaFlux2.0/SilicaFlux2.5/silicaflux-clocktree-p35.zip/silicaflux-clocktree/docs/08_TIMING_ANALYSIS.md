# 08 — Timing, CDC and reset-domain analysis report

**Tools actually run:** Yosys 0.33 (mapping to the IHP SG13G2 Liberty, typ / slow / fast), `scripts/sf_sta.py`
(in-house NLDM timing check, indicative), `scripts/cdc_check.py` (structural CDC / RDC), Verilator 5.020 lint.
**Not run:** OpenSTA / OpenROAD (could not be installed: `09_LIMITATIONS.md`). The OpenSTA script with the
same SDC is `cts/sta_signoff.tcl`.

## 1. Defined clocks

| Clock | Port | Period | Clock pins reached (baseline / research) | Gated pins |
|---|---|---|---|---|
| clk_core | `clk_core_i` | 10 ns | 305 / 343 | 285 / 323 (1 or 2 ICG levels) |
| clk_ref | `clk_ref_i` | 40 ns | 478 / 623 | 0 |
| clk_mc (research) | `clk_mc_i` | 7 ns | — / 19 | 0 |

No generated clocks: nothing generates one (`05_SDC.md`). Structurally, every sequential and ICG clock pin
is reached by a declared clock (rule CLK-UNCLOCKED: 0). No clock passes through logic other than buffers,
inverters and ICGs (CLK-COMB-GATING: 0).

## 2. Clocked endpoints and unconstrained endpoints

| Run | Endpoint checks | Unconstrained | Constrained only by justified false paths |
|---|---|---|---|
| baseline func pre-CTS (typ / slow / fast) | 1876 | **0** | 5 |
| research func pre-CTS (slow) | 2308 | **0** | 5 |
| research test (slow) | 4296 | **0** | 1 |

The 5 functional false-path-only endpoints are exactly the asynchronous inputs' first destinations:
`u_pll_sync.sync_q[0]/D` and the four `RESET_B` pins of the reference POR / SYS reset synchronisers
(driven only by `por_ni` / `ext_rst_ni`). In test mode only `u_pll_sync` remains, because the resets then
come from the timed `test_rst_ni`.

## 3. Setup / hold (ideal clocks, pin-capacitance loads, estimated buffer trees on nets > 16 sinks)

| Run | Violations | Worst setup (group) | Worst hold (group) | Fmax* reg2reg clk_core |
|---|---|---|---|---|
| baseline func, typ 1.20 V 25 °C | 0 | +2.542 ns (in2out) | +0.048 ns (in2reg) | 721 MHz |
| baseline func, slow 1.08 V 125 °C | 0 | +1.880 ns (in2out) | +0.114 ns (in2reg) | 494 MHz |
| baseline func, fast 1.32 V −40 °C | 0 | +2.935 ns (in2out) | +0.004 ns (in2reg) | 1002 MHz |
| research func, typ / slow / fast | 0 / 0 / 0 | +1.885 ns at slow (in2out) | +0.004 ns at fast | 652 / 445 / 912 MHz |
| test mode, all corners, both configurations | 0 | — | — | — |
| *sensitivity*: slow + 20 µm/fanout wire | **1** (baseline), 1 (research) | −0.062 ns in2out `rb_addr_i → rb_err_o` | +0.148 ns | 207 MHz |
| *informational*: typ, propagated clocks **without** a clock tree | 188 / 198 hold | — | −2.98 ns | — |

*Hold slacks already include the 0.10 ns hold uncertainty.*

Path groups at the slow corner (baseline): reg2reg clk_core +7.97 ns, in2reg +4.25, reg2out +5.42,
in2out +1.88, recovery clk_core +8.54 / removal +0.98, recovery clk_ref +38.6, clock gating +9.20 / hold
+0.28, CDC max_delay ref→core +8.77 and core→ref +6.68. All groups:
`reports/sta/STA_SUMMARY.md`.

Interpretation:

* The block meets its 10 ns / 40 ns / 7 ns requirements at all three corners with margin, **within the
  model's limits** (no extraction, no SI / OCV, no real repair).
* The critical path is the combinational register-bus read (an in→out feed-through). With pessimistic
  wire load it misses its 4 ns budget by 62 ps because of an under-sized `nor2_1` driving a wide decode
  net. That is a sizing job for `repair_design`. Alternatively, register the read data.
* "Fmax*" = 1 / (T − worst reg2reg setup slack) at that corner. It is **derived, not measured**, and is
  not a die frequency.
* The propagated run is not a verdict. With no clock tree, one ICG drives 283–319 sinks, and the root and
  branch groups lag the ungated sinks by 2.8 / 3.2 ns. It quantifies what CTS must balance.

## 4. CDC violations

**0 FAIL, 0 unwaived REVIEW** in both configurations. 33 / 48 SYNC_2FF crossings, 155 / 178 handshake
payload captures (waiver CDC-W01), 4 / 6 multi-bit banks (CDC-W02..W06: independent bits or Gray). Every
asynchronous crossing has a `set_max_delay` bound. Details: `reports/cdc/{baseline,research}.md`; negative
tests: `reports/cdc/NEGATIVE_TESTS.md` (9 / 9).

## 5. Reset-domain issues

* Reset structure: every asynchronous reset pin is driven through buffers, case-analysed DFT muxes or the
  single reset-combine cell, from a flop or a declared reset port (RDC-COMB 0, RDC-SOURCE 0). Every
  release is either synchronous to the flop's own clock (`SYNC_RELEASE`, e.g. 278 fabric flops from
  `u_rs_fab`) or happens in a reset-synchroniser stage (RDC-ASYNC-RELEASE 0).
* Reset-domain crossings: 31 / 34, all `RDC_ISOLATED` (2-flop isolation `u_rdc_log`, `u_rdc_seq`). No
  unisolated crossing.
* Recovery / removal timed on 293 core and 474 reference asynchronous pins (no violations).
* Outside this block (audit): ControlCore F-04, the decoded counter in its reset path (rule violation,
  low impact, not modified here).
