# 02 — Reset architecture and reset domains

## 1. Reset domains

| Domain | Output / net | Clock | Asserted by | Released by | Content (die) |
|---|---|---|---|---|---|
| REF-POR | `ref_por_rst_n` (internal) | `clk_ref` | `por_ni` only | `u_rs_ref_por` | reset-cause log, clock-monitor sources |
| REF-SYS | `ref_sys_rst_n` | `clk_ref` | `por_ni` **or** `ext_rst_ni` (reset-combine cell) | `u_rs_ref_sys` | sequencer, monitors, status synchronisers |
| REF-FAB | `ref_fab_rst_n` | `clk_ref` | the sequencer's fabric request flop | `u_rs_ref_fab` | watchdog, reference ends of every core↔ref channel (reset together with their fabric ends) |
| **Fabric** | `fab_rst_no` | `clk_core_o` | sequencer (system scope, clock / PLL loss, POR / EXT) | `u_rs_fab` | NoC, shared SRAM, DMA, die registers, this block's register file |
| **ControlCore** | `cc_rst_no` | `clk_core_o` | sequencer (system or CONTROL scope) | `u_rs_cc` | ControlCore (whose own generator keeps soft / CC-watchdog / host resets inside the ControlCore) |
| **Accelerator branch b** | `br_rst_no[b]` | `clk_br_o[b]` | sequencer (system, CONTROL or COMPUTE scope with mask) | `g_br[b].u_rs_br` | compute cluster b (ComputeCluster P32 interface) |
| **Memory controller** | `mc_rst_no` | `clk_mc` | MC FSM (fabric in reset, mc clock loss, MEMCTL scope) | `g_mc.u_rs_mc` | controller IP side of ExtMem P24 |

Every domain reset **asserts asynchronously** (no clock needed) and **releases synchronously** to the
clock of the domain, through a 2-flop reset synchroniser whose asynchronous input is driven by a
**single flop** of the sequencer. A reset path never contains decoded logic (contrast audit F-04).

## 2. Sources, scopes and priority

| Source | Kind | Scope | Quiesce first? | Cause bit |
|---|---|---|---|---|
| `por_ni` | asynchronous pin | everything, including the cause log | no | POR (0) |
| `ext_rst_ni` | asynchronous pin | everything except REF-POR | no | EXT (1) |
| core clock absent / out of range | monitor | all core domains + MC, root gate closed | no | CLK_LOSS (2) |
| PLL lock lost | `pll_lock_i` (synchronised) | as clock loss | no | PLL_LOSS (3) |
| system watchdog stage 2 | `sf_crt_wdog` (`clk_ref`) | SYSTEM | no (a fault) | WDOG (4) |
| block watchdog request | `wdog_req_i[NW]` | SYSTEM | no | EXT_WDOG (5) |
| software, SYSTEM | `R_SW_RST` (key `0x5AFE`) | fabric + ControlCore + branches + MC | yes, unless FORCE | SW_SYS (6) |
| software, CONTROL | `R_SW_RST` | ControlCore + branches | yes, unless FORCE | SW_CC (7) |
| software, COMPUTE | `R_SW_RST` + branch mask | selected branches | yes, unless FORCE | SW_ACC (8) |
| software, MEMCTL | `R_SW_RST` (MC builds; refused otherwise) | memory controller | no | SW_MC (9) |
| mc clock absent / out of range | monitor | memory controller only | no | MC_CLK_LOSS (10) |

**Priority** when requests coincide: clock / PLL loss > system watchdog > block watchdog > software.
**Every** cause present in the same sequencer cycle is logged. `last cause` = the highest priority among
them. A software command that arrives outside RUN, or loses to a watchdog, is dropped and
`STATUS.CMD_DROP` is set. A watchdog that fires during a graceful drain escalates immediately to a
SYSTEM assertion.

## 3. Behaviour in each situation

| Situation | Behaviour |
|---|---|
| **Power-up** | Everything held. The sequencer waits (WAIT_CLK) for PLL lock **and** the core clock qualified for `STABLE_CYC` cycles, opens the root gate (glitch-free ICG; `clk_core_o` is silent before), waits `PRE_REL_CYC` running cycles, then releases fabric → ControlCore → branches (clock forced on) → RUN. The MC domain is released independently once the fabric has acknowledged and `clk_mc` is qualified. |
| **External reset** | `ext_rst_ni` resets the reference system domain asynchronously. Every domain asserts in the same delta (flop → reset-synchroniser chain), and the root gate closes, so `clk_core_o` stops while the pin is held. Any pulse width works: the reset synchroniser stretches it to at least 2 reference cycles, so nothing is partially reset. A 1 ns glitch is tested. The cause log records EXT on the next boot even if the pulse was too short to sample. |
| **Watchdog** | Stage 1 sets `wdog_irq_o`. Stage 2 (no service) triggers a SYSTEM reset when `RST_EN = 1`. LOCK makes it impossible to disable until the next system reset. The watchdog restarts disabled after the reset it caused. |
| **Clock unavailable** | The core clock stops, or leaves its window, or the PLL unlocks. All core-side resets assert **asynchronously while the clock is stopped** (tested), the root gate closes, and the sequencer waits for every acknowledge to clear, then re-enters WAIT_CLK. Recovery is automatic when the clock returns. `clk_mc` loss affects only the MC domain; the core keeps running (tested). |
| **Software reset** | Keyed write. The graceful form asks the affected domains to drain (`fab_quiesce_o`, `br_quiesce_o`; acknowledge = request seen **and** idle), asserts after all acks or after `QTIMEOUT` (sticky `STATUS.QTIMEOUT`), holds `HOLD_CYC`, waits for the "in reset" acks, then re-enters the release chain at the first affected stage. FORCE skips the drain. |
| **Reset during DMA / compute** | A fabric reset aborts the DMA (no stale completion afterwards). A CONTROL or COMPUTE reset leaves the fabric DMA running to completion. A COMPUTE reset of branch 1 leaves branch 0's job intact. 18 randomised injections are covered by `dma_reset`. |
| **Test mode** | `test_mode_i = 1`: every reset synchroniser's input **and** output switch to `test_rst_ni` through DFT mux cells (scan-controllable). `test_en_i` forces every ICG open through its SE pin. |

## 4. Reset-domain crossings (same clock, different reset)

Detected structurally (`scripts/cdc_check.py`, assertion-cause analysis; reset-synchroniser stages are
transparent):

| From | To | Hazard | Mechanism |
|---|---|---|---|
| sequencer (REF-SYS) | cause log (REF-POR) | an external reset changes sequencer flops asynchronously while the log keeps running | `u_rdc_log`, 2-flop isolation |
| watchdog / command channel (REF-FAB) | sequencer (REF-SYS) | a fabric reset changes them while the sequencer runs | `u_rdc_seq`, 2-flop isolation |
| cause-clear channel (REF-FAB) | cause log (REF-POR) | as above | `u_rdc_log` |
| sequencer / monitors (REF-SYS) | snapshot source (REF-FAB) | none: every REF-SYS assertion also asserts REF-FAB | — |
| cause log (REF-POR) | snapshot source (REF-FAB) | none: POR resets both | — |

Result: 31 (baseline) / 34 (research) reset-domain crossings, **all isolated** (`reports/cdc/*.md`). The
negative test `neg_rdc_data` shows the checker flags an unisolated one.

## 5. Reset-cause record

`R_CAUSE` holds the sticky cause bits (W1C), and `R_RST_INFO` the reset count since POR plus the last
cause. They live in the POR domain and so survive every other reset. The record is coherent because it is
read through the status snapshot.

## 6. Release timing in STA

* Releases from a reset synchroniser output into its own domain are timed as **recovery / removal**
  (293 core and 474 reference endpoints). They are **not** false-pathed.
* Request flop (`clk_ref`) → reset-synchroniser asynchronous pin (another clock) is an asynchronous
  crossing. It is bounded by the CDC `set_max_delay`; the synchroniser takes care of metastability.
* `por_ni` / `ext_rst_ni` are false-pathed. Structurally they reach only reset-synchroniser asynchronous
  pins (rule PORT-ASYNC).
