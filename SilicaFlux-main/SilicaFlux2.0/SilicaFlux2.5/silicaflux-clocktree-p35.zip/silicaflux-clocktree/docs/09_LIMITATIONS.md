# 09 — Limitations, blocked items and what remains for signoff

## Blocked in this environment

| Item | Status | Why | What is provided instead |
|---|---|---|---|
| OpenSTA timing | **NOT RUN** | the environment's permission policy refused both a prebuilt OpenROAD package (conda) and an OpenSTA / CUDD source build | `cts/sta_signoff.tcl`, ready to run, multi-corner with a scenes / corners fallback. The same constraints were exercised by `scripts/sf_sta.py`, an in-house NLDM checker (indicative, pin-capacitance loads, estimated buffer trees, no SI / OCV / CRPR) |
| OpenROAD placement / CTS / routing | **NOT RUN** | same | `cts/run_block_cts.tcl` + generated `cts_config_<tech>.tcl`, CTS pre-check against LEF / Liberty / netlist, end-to-end Tcl dry run against command stubs |
| Clock-tree closure | **not claimed** | needs a placed and routed implementation | budgets defined (`06_CTS.md`); the unbuffered ICG imbalance is quantified |
| Structural CDC signoff with a commercial tool | not available | — | `scripts/cdc_check.py` (TimingFlow rule set) proven by 8 negative tests + 1 positive control |

## Not implemented / out of scope

* **PLL.** No PLL macro exists in the repository. `pll_lock_i` and the clock pins are integration
  boundaries. The clock monitor checks the PLL output frequency independently of the lock flag.
* **PCIe application clock.** HostLink physical PCIe is blocked (no endpoint IP or PHY), so no clock was
  invented.
* **Die integration.** This project delivers the controller and an integration guide
  (`integration/P31_INTEGRATION.md`). DieTop P31 was not modified or re-verified with it. The die SDC is a
  template.
* **Synchroniser MTBF.** Not computed: neither open PDK ships a characterised synchroniser cell (τ, T0).
  Use 2 stages at ≤ 100 MHz in 130 nm only after an MTBF calculation with foundry data; `SYNC_STAGES`
  is a parameter.
* **FPGA primitives** (BUFGCE, DCCA) are mapped by Yosys, not built with vendor tools or run on hardware.
* **Gate-level simulation** was not run (no SDF from a signoff STA).
* **Frequencies.** Every period is a requirement. "Fmax*" figures are derived from ideal-clock,
  pin-capacitance analysis of this block only and are **not** die frequencies.
* **IO budgets** are 30 % block budgets, not datasheet values.
* **Power.** No power analysis. Gating is functional; there is no retention and no power domain.

## Known findings for the integrator

1. **Combinational register-bus read path** (`rb_addr_i` → `rb_rdata_o` / `rb_err_o`, combinational by
   the SilicaFlux-V bus contract). It is the block's critical path: 1.88 ns slack at slow without wire
   load, and −0.06 ns in the pessimistic +20 µm/fanout sensitivity run, because ABC leaves a `nor2_1`
   driving a wide decode net. `repair_design` gate sizing is expected to fix it. Otherwise register the
   read data (a contract change) or relax the 30 %/30 % IO budget.
2. **Fast-corner hold margin on block inputs** (in2reg, register-bus inputs): +0.004 ns beyond the
   0.10 ns hold uncertainty, with the 0 ns minimum input delay of the block budget (ideal clocks). Real
   minimum input delays from the driving block, and post-CTS `repair_timing -hold` (in the flow), set the
   final margin.
3. **Two root gates must not coexist.** If PowerClock P27 is integrated, its global core gate must be
   removed or tied open, because this block's root gate is the reset / PLL authority. PowerClock's branch
   gates and policies remain valid behind it.
4. **ControlCore reset decode** (audit F-04): recommend registering `sys_reset_req` in a future ControlCore
   revision. It is not modified here.
5. **PowerClock SDC precedence** (audit F-05): verify in the target STA that `set_clock_groups` does not
   cancel its `set_max_delay` bounds.

## Bugs found by this project's own verification (fixed)

| Found by | Bug | Fix |
|---|---|---|
| iverilog regression, slow-core build | the MC domain was released when the fabric reset *request* dropped, before the fabric domain itself had left reset | wait for the fabric acknowledge (`sf_crt_seq` MC_OFF) |
| Verilator regression, `clk_start` seed 3 | a clock starting mid-window gave a partial, in-range first count; with a false lock the root gate opened on a runaway clock | OK requires `MON_OK_WIN` ≥ 2 consecutive in-range windows |
| iverilog regression, long tests | the saturating window counter wrapped (`good_q + 1` in 4 bits), so OK dropped after 15 windows and the chip reset itself forever | compare before incrementing; long-run unit check added; kept as mutant M13 |
