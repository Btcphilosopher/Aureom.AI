# 05 — Timing constraints (SDC)

Source of truth: `config/clock_spec.yaml`. Generator: `constraints/gen_sdc.py`. It is deterministic, and the
header carries the YAML's SHA-256. The generator also writes `constraints/json/*.json`, so the in-house
checker reads exactly the same constraints.

## 1. Files

| File | Mode / stage | Analysed here |
|---|---|---|
| `silicaflux_crt_{baseline,research}_func_prects.sdc` | functional, ideal clocks, jitter + skew allowance | yes (`sf_sta`, typ / slow / fast) |
| `silicaflux_crt_{baseline,research}_func_postcts.sdc` | functional, `set_propagated_clock [all_clocks]`, jitter only | only as an *unbuffered, informational* run (no CTS tree exists) |
| `silicaflux_crt_{baseline,research}_test.sdc` | scan: `test_mode_i = test_en_i = 1`, 50 ns tester clocks, `test_rst_ni` timed | yes (typ / slow / fast) |
| `silicaflux_die_func_template.sdc` | die level (P31 port names + new `clk_ref_i`) | **no**: no integrated die netlist exists |

All seven are Tcl-syntax-checked and dry-run (`reports/TCL_DRYRUN.log`).

## 2. What each constraint is and why

| Constraint | Value | Justification |
|---|---|---|
| `create_clock clk_core` | 10 ns | requirement (P31 simulation clock); **not a frequency claim** |
| `create_clock clk_ref` | 40 ns | 25 MHz crystal assumption (no oscillator is selected in the repository) |
| `create_clock clk_mc` (research) | 7 ns | P31 V3 regression controller clock |
| generated clocks | **none** | nothing divides, multiplies or muxes a clock. ICG outputs are gated copies: the clock propagates through the library clock-gating cells, and the GATE setup / hold checks come from the Liberty. Real clock-generating hardware (PLL) is outside the block. |
| clock uncertainty | pre-CTS setup 0.25 / hold 0.10; post-CTS 0.10 / 0.05 | TimingFlow convention: 0.10 ns jitter budget + 0.15 ns skew allowance pre-CTS; jitter only post-CTS. Budget values, not foundry margins. |
| clock transition (pre-CTS) | 0.15 ns | ideal clock slew (TimingFlow) |
| `set_case_analysis 0 test_mode_i / test_en_i` (functional) | — | DFT muxes select the functional reset; ICG scan enable off |
| **CDC**: `set_max_delay -ignore_clock_latency` between every asynchronous pair | min(T_src, T_dst) | bounds the skew of Gray words and handshake payloads, and keeps synchroniser latency deterministic. **Deliberately not** `set_clock_groups` / `set_false_path`, which would remove the bound (audit F-05). |
| `set_false_path -hold` between asynchronous pairs | — | hold has no meaning without a phase relationship. Metastability is handled by the synchronisers. |
| `set_false_path -from {por_ni ext_rst_ni pll_lock_i}` | — | **justified**: asynchronous pins whose only fan-out is reset-synchroniser asynchronous pins, the reset-combine cell, or a synchroniser first stage. Checked structurally (rule PORT-ASYNC). STA shows exactly 5 endpoints constrained only by these exceptions, all of that kind. |
| input / output delays | 30 % of the period on each side | block budget (TimingFlow `block_budget`): the register bus, idle / clock-request / wake / watchdog inputs, reset / quiesce / ready outputs. Replace with the integrating block's real budgets. |
| reset synchroniser → domain flops | timed | recovery / removal checks stay **on**. Only the asynchronous assertion pins are excepted. |
| driving cell / load | `sg13g2_buf_2` / 5 fF | block-internal boundary assumption |

There is no blanket false path anywhere. `report_checks` / `check_setup -unconstrained_endpoints`
(OpenSTA), or `sf_sta` here, show 0 unconstrained endpoints.

## 3. Modes

| Mode | Status |
|---|---|
| func | DEFINED (pre- and post-CTS) |
| test (scan) | DEFINED: resets from `test_rst_ni`, timed as a synchronous tester input to every clock; ICGs open |
| low-power | NOT APPLICABLE: no power domains or retention exist. Gating is functional behaviour. |
| debug (JTAG) | NOT APPLICABLE in this block (TestCore not instantiated) |
