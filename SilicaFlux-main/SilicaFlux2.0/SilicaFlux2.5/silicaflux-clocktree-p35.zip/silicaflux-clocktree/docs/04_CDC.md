# 04 — Clock-domain crossings

## 1. CDC requirements by signal class (what the library provides)

| Class | Requirement | Adapter | Never |
|---|---|---|---|
| **Status** (single-bit levels) | each bit meaningful on its own | `sf_crt_sync` (2+ flops) | combine two synchronised bits as if coherent |
| **Status word** (counter / pointer) | Gray-coded, one bit per source edge, skew ≤ 1 source period | `sf_crt_sync #(.GRAY(1))` + `set_max_delay` | binary bus through per-bit flops (`neg_multibit_bus` is flagged) |
| **Commands** (events) | loss-free; bursts may coalesce | `sf_crt_pulse_sync` (toggle + acknowledge + pending) | a plain pulse through 2 flops |
| **Commands with payload / wide data** | coherent multi-bit transfer | `sf_crt_handshake` (2-phase toggle, payload held until acknowledged) | sample a changing bus |
| **Streams / DMA requests** | ordered, back-pressured, at rate | `sf_crt_async_fifo` (Gray pointers, registered read, conservative full / empty) | — |
| **Reset** | async assert, sync release in the destination | `sf_crt_rst_sync` (+ DFT bypass) | release a domain from a foreign-clock flop (`neg_async_release` is flagged) |
| **Reset-domain crossing** (same clock) | absorb metastability when the source resets alone | `sf_crt_rdc_sync` | sample a flop that can reset asynchronously under a running destination (`neg_rdc_data` is flagged) |
| **Interrupts** | level: hold at source; event: sticky at destination | `sf_crt_irq_sync` (EDGE_MODE 0 / 1) | — |

Both ends of every handshake, pulse or FIFO channel reset **together** and may release independently.
Here both are cleared by the same sequencer flop (`seq_fab_rst_n` → fabric end and REF-FAB end).

## 2. Every crossing in `silicaflux_clock_reset_tree`

| # | Signal | From → To | Width | Class | Mechanism (instance) | SDC | Test |
|---|---|---|---|---|---|---|---|
| 1 | `pll_lock_i` | async pin → ref | 1 | status | `u_pll_sync` | false path from port | clk_start, clk_loss |
| 2 | core Gray count | core raw → ref | 8 | status word | `u_mon_core.u_gsync` (GRAY) | max_delay 10 ns | cdc_lib monitor accuracy, clk_start |
| 3 | mc Gray count | mc → ref | 8 | status word | `g_mc.u_mon_mc.u_gsync` | max_delay 7 ns | clk_loss (MC) |
| 4 | root enable | ref → core raw | 1 | reset-style (async off / sync on) | `u_root_en` | max_delay | clk_start, clk_loss |
| 5 | domain reset requests | ref → core / branch / mc | 1 each | reset | `u_rs_fab`, `u_rs_cc`, `g_br[b].u_rs_br`, `g_mc.u_rs_mc` | max_delay (recovery bounded) | all |
| 6 | acknowledges (root, fab, cc, br[b], force[b], mc, quiesce) | core / branch / mc → ref | 3+3·NB+2 | independent levels | `u_ack_sync` | max_delay | all (each waited on individually) |
| 7 | branch force | ref → core | 1 / branch | level | `g_br[b].u_bg.u_force_sync` | max_delay | clk_en (gated-branch reset) |
| 8 | quiesce requests | ref → core | 1+NB | independent levels | `u_q_sync` (ack = request seen ∧ idle) | max_delay | sw_reset |
| 9 | block-watchdog requests | core → ref | NW | independent levels (OR-ed) | `u_wreq_sync` | input delay + max_delay | ext_wdog, simul |
| 10 | software reset command | core → ref | 3+NB | command + payload | `u_hs_cmd` | max_delay | sw_reset, simul, dma_reset |
| 11 | watchdog configuration | core → ref | 35 | wide data | `u_hs_cfg` | max_delay | wdog |
| 12 | watchdog service | core → ref | 1 | command | `u_ps_kick` (coalescing) | max_delay | wdog, cdc |
| 13 | cause clear (W1C) | core → ref | 16 | command + payload | `u_hs_clr` | max_delay | ext_rst, cdc |
| 14 | status snapshot | ref → core | 128 | wide data (continuous) | `u_hs_snap` | max_delay | every register read; cdc (WDOG_CNT coherence) |
| 15 | watchdog warning | ref → core | 1 | interrupt (level) | `u_irq_wdog` | max_delay | wdog |
| 16 | readiness (run, mc_run) | ref → core | 2 | independent levels | `u_rdy_sync` | max_delay | por, clk_loss |
| 17 | reset events / clear → cause log | REF-SYS / REF-FAB → REF-POR | 34 | reset-domain crossing | `u_rdc_log` | same clock | ext_rst, simul |
| 18 | watchdog expiry, command → sequencer | REF-FAB → REF-SYS | 2+CMDW | reset-domain crossing | `u_rdc_seq` | same clock | wdog, sw_reset |
| — | memory-controller **data** | core ↔ mc | — | streams | ExtMem P24 `extmem_mc_cdc` (async FIFOs), outside this block | P24 template (F-06) | P24 regression |

## 3. Structural check (`scripts/cdc_check.py`, IHP netlists, `test_mode_i = 0`)

| | baseline | research |
|---|---|---|
| SYNC_2FF crossings (PASS) | 33 | 48 |
| QUASI_STATIC_DATA (handshake payload capture), waiver CDC-W01 | 155 | 178 |
| MULTIBIT_SYNC banks: acknowledges, Gray monitors, watchdog requests, quiesce, readiness; waivers CDC-W02..W06 | 4 | 6 |
| LOGIC_BEFORE_SYNC / clock-gating / ICG-enable / reset-structure FAIL | **0** | **0** |
| Reset-domain crossings (all isolated) | 31 | 34 |
| Unwaived REVIEW items | **0** | **0** |

The waivers (`config/cdc_waivers.yaml`) cover only REVIEW classes. Each states why the structure is safe
and where that is proven. FAIL classes cannot be waived.

**The checker is itself tested** (`scripts/cdc_negative.py`). 8 negative designs, each with one known
defect, are synthesised exactly like the block and must fire their rule: combinational clock gating,
logic before a synchroniser, a binary bus through per-bit synchronisers, the ControlCore decoded-reset
pattern (audit F-04), asynchronous release, an unisolated RDC, an ICG enable from another domain, and a
ripple clock. A clean positive control must pass. **9 / 9 pass**
(`reports/cdc/NEGATIVE_TESTS.md`).

## 4. CDC in simulation

* **Metastability model** (`+define+SF_CRT_CDC_RANDOM`). Stage 0 of every synchroniser randomly resolves
  one cycle late: per bit for independent bundles, for the whole word for Gray buses (physically only one
  bit is in transition). Builds B2–B5 run every system test with it, at core/reference ratios 0.32×, 2.9×,
  2.3× (non-commensurate) and 7.7×.
* **Quasi-static checkers** (simulation only, inside `sf_crt_handshake` and `sf_crt_async_fifo`). They
  `$fatal` if the captured payload or FIFO slot changed after the previous destination edge. This is the
  corruption zero-delay RTL simulation cannot show. It is proven by mutant M12 (payload not held), which
  is otherwise invisible to simulation.
* **CDC library unit tests** (`tb/tb_cdc_lib.sv`) at 5 clock ratios × metastability model on/off:
  64-bit handshake scoreboard, async FIFO scoreboard (random valid / ready), loss-free pulses (no pulse
  is ever lost; bursts coalesce), interrupt event → sticky → W1C, Gray monitor accuracy and long-run
  stability, reset synchroniser (assert with the clock stopped, release after exactly 2 edges), and a
  paired reset in the middle of traffic (nothing stale delivered).

## 5. Not done

Synchroniser MTBF is not computed. Neither IHP SG13G2 nor SKY130HD ships a characterised synchroniser
cell, so there is no τ / T0 data. No commercial structural CDC tool (Questa CDC, SpyGlass, Meridian) was
available. The in-house checker implements the TimingFlow rule set, and its coverage is shown by the
negative tests, not by tool qualification.
