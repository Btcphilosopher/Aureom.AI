# 07 — Verification

## 1. Environment

Two simulators (Icarus Verilog 12.0, Verilator 5.020 with `--timing`), the same testbench, self-checking.
Every test ends with `TEST <name> RESULT PASS|FAIL checks=… errors=…`. Regression: `scripts/regress.py` →
`reports/regression.{md,json}`.

### Builds (system testbench)

| Build | `clk_ref` / `clk_core` / `clk_mc` half-periods (ns) | Core / ref ratio | MC domain | Metastability model |
|---|---|---|---|---|
| B0_base | 10 / 3.5 / 4.5 | 2.9× | no | no |
| B1_mc | 10 / 3.5 / 4.5 | 2.9× | yes | no |
| B2_mc_rand | 10 / 3.5 / 4.5 | 2.9× | yes | **yes** |
| B3_slowcore | 10 / 31 / 13 | **0.32×** (core slower than reference) | yes | yes |
| B4_fastcore | 10 / 1.3 / 4.5 | **7.7×** | no | yes |
| B5_noncommens | 10 / 4.37 / 6.91 | 2.3× (non-commensurate) | yes | yes |

The CDC library testbench runs at 5 source/destination ratios (0.35×, 2.9×, 1.46×, 0.32×, 7.7×), with
the metastability model off and on.

## 2. Requirement → test

| Brief item | Test(s) | What is checked |
|---|---|---|
| **Power-on reset** | `por` | sequence order and spacing; no release before lock + qualified clock; `CAUSE` = POR exactly, count 0; CONFIG; core / mc clock measurements in range; watchdog disabled; each domain released exactly once; recovery check |
| **Clock-start sequencing** | `clk_start` | no core clock: WAIT_CLK, all domains held, **0** edges on `clk_core_o`; 25 glitches on `clk_core_i` don't pass the root gate; a runaway 3× clock with a **false lock** is refused by the frequency monitor; lock chatter faster than `STABLE_CYC` never opens the gate; a normal start releases each domain once |
| **Watchdog** | `wdog`, `ext_wdog` | wrong service key refused; a serviced watchdog never warns; stage 1 = interrupt, stage 2 = system reset, cause WDOG, disabled afterwards; interrupt-only mode; LOCK rejects reconfiguration (`STATUS.CFG_REJ`) and still fires; each block-watchdog input resets the chip (cause EXT_WDOG) |
| **Software reset** | `sw_reset` | wrong key refused; COMPUTE scope with mask (branch 1 reset, branch 0 keeps computing to the correct result, fabric and ControlCore untouched); CONTROL scope; SYSTEM graceful (the DMA transfer completes **before** the reset asserts); SYSTEM forced (transfer aborted); drain timeout (`STATUS.QTIMEOUT`); MEMCTL scope (MC builds) or refused (`rb_err`, non-MC); command outside RUN dropped (`STATUS.CMD_DROP`) |
| **Simultaneous reset causes** | `simul` | system watchdog vs block watchdog swept over 32 launch offsets (exactly one reset per point; at least one point logs both causes in one event when the core is faster than the reference); command + watchdog (watchdog wins, command dropped); watchdog during a graceful drain escalates (no drain timeout reported); clock loss + watchdog; external reset during clock loss (still waits for the clock; CLK_LOSS + EXT logged); POR inside an external reset (one boot, cause POR only, count reset) |
| **Clock-enable changes** | `clk_en` | gating an idle branch stops its edges; a job wakes it; it gates again after the job; software cannot stop a busy branch (interlock); ACC reset of gated-off branches completes (forced clock) and the gate closes again; 120 random enable / job operations with the glitch checkers on; `test_en` forces the clocks; simulator gated-clock sampling sanity chain |
| **CDC under asynchronous clocks** | `cdc` in every build; `tb_cdc_lib` | 400 random register operations through all CDC channels with snapshot coherence (WDOG_CNT never above load, never increases without service), CLK_MEAS in range, STATUS RUN; builds B2–B5 with random metastability at 4 ratios; library scoreboards (handshake 64-bit, async FIFO, pulses, interrupts, Gray monitor, reset synchroniser, paired reset mid-traffic) |
| **Reset during DMA / compute** | `dma_reset`, `ext_rst`, `sw_reset`, `clk_loss` | 18 injections of 6 kinds (1–30 ns external pulse, forced SYSTEM / CONTROL / COMPUTE, block watchdog, clock stop) at random points during a DMA transfer and two compute jobs: no DMA survives a fabric reset; the DMA completes correctly through CONTROL / COMPUTE resets; then a fresh DMA and jobs are verified |
| **Recovery** | every test | `check_functional` after every reset: ID, STATUS RUN / locked / clock OK / domains released, a seeded DMA transfer verified word by word, compute jobs on both branches with the exact sum |
| Clock unavailable | `clk_loss` | core clock stopped: all domains asserted **while the clock is stopped**, automatic recovery; PLL unlock: `clk_core_o` silent while unlocked; frequency excursion with lock held; mc clock loss resets only the MC domain |
| External reset | `ext_rst` | a 1 ns pulse asserts every domain asynchronously and closes the root gate; long hold stops `clk_core_o`; cause EXT, count; W1C clear |
| DFT | `test_mode` | resets follow `test_rst_ni` combinationally in test mode; `test_en` drives the clock; POR restores functional control |

## 3. Continuous checkers (every test, every build)

| Checker | Rule |
|---|---|
| `tb_clk_check` × 3 (`clk_core_o`, `clk_br_o[0..1]`) | every gated edge coincides with a source edge of the same polarity (no runt, no truncated pulse) |
| `tb_rel_check` × 5 (fab, cc, br0, br1, mc) | every reset **release** is on an edge of the domain's own clock |
| ordering + spacing | fabric before ControlCore (≥ `FAB_DELAY` reference cycles), ControlCore before branches (≥ `CC_DELAY`), fabric only with PLL lock, MC only with the fabric out of reset |
| X check | no X on resets, state, ready, interrupt after POR; none on the register bus while the fabric runs |
| interlock | a branch that requests its clock for 2 cycles has its gate open |
| quasi-static (in the RTL, simulation only) | handshake payload / FIFO slot unchanged since before the previous destination edge (`$fatal`) |

## 4. Results

**492 / 492 runs pass, 0 failures, 116 815 self-checks** (`reports/regression.md`): Icarus + Verilator
× 6 system builds × 12 tests × 3 seeds (432 runs), plus 2 simulators × 10 CDC-library builds × 3 seeds (60 runs).
Every glitch checker, release checker, ordering / spacing checker, X check, interlock and quasi-static
checker stayed silent in every run.

### Bugs found by this verification (all fixed in the RTL)

1. **MC released before the fabric was out of reset** (slow-core build). Fix: wait for the fabric acknowledge.
2. **Partial first monitor window accepted a runaway clock** (Verilator, `clk_start` seed 3). Fix: 2
   consecutive in-range windows.
3. **Saturating counter wrap** made the monitor drop OK after 15 windows, so the chip reset itself forever
   (long tests). Fix: compare before incrementing, plus a long-run unit check.

### Mutation analysis (`reports/mutation.md`)

16 plausible clock / reset defects were injected one at a time. **16 / 16 are killed.** Three were
initially missed, and the verification was strengthened in response: release-spacing checks (M01), the
true no-force defect (M02), and the quasi-static checkers (M12, invisible to zero-delay simulation
otherwise).

| Mutant | Killed by |
|---|---|
| M01 ControlCore released with the fabric | release-spacing checker (`por`) |
| M02 gated branch released without forcing its clock | `clk_en` (sequence never reaches RUN) |
| M03 monitor accepts any frequency | `clk_start` |
| M04 reset synchroniser removed | synchronous-release checker (`por`) |
| M05 AND-gate clock gating | glitch checker (`clk_en`) |
| M06 watchdog ignores service | `wdog` |
| M07 EXT not logged | `ext_rst` |
| M08 reset key not checked | `sw_reset` |
| M09 no busy interlock | interlock checker (`clk_en`) |
| M10 no drain wait | `sw_reset` |
| M11 clock loss ignored | `clk_loss` |
| M12 handshake payload not held | quasi-static checker (`cdc`) |
| M13 saturating counter wraps | `wdog` (hang) |
| M14 root gate opens without lock | `clk_start` |
| M15 block-watchdog input ignored | `ext_wdog` |
| M16 no DFT bypass on the reset output | `test_mode` |

## 5. Not verified

Gate-level simulation; formal proof (no formal tool was used for the new RTL); FPGA hardware; the
integrated die (P31 not re-simulated with this controller).
