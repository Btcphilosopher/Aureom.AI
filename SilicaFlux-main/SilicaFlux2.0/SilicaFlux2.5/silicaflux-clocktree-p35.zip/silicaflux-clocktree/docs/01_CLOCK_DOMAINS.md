# 01 — Clock-domain architecture

## 1. Baseline: one functional clock plus a reference

| Domain | Port | Period (requirement) | Source | Role | Sinks (IHP netlist) |
|---|---|---|---|---|---|
| `clk_core` | `clk_core_i` | 10 ns | PLL output (integration boundary) | **The one functional clock.** Fabric, ControlCore, accelerators | 305 clock pins: 20 ungated, 283 behind the root ICG, 2 behind a branch ICG |
| `clk_ref` | `clk_ref_i` | 40 ns (25 MHz assumed) | Board crystal / oscillator, which is also the PLL's reference | Management: reset sequencer, clock monitors, system watchdog, reset-cause log | 478 |

**Why the reference clock is required, not optional** (the brief allows one "if required"):

1. It is the only clock that exists before the PLL locks. Reset sequencing must start with the core clock
   absent or unstable.
2. Only a clock that does not depend on `clk_core` can see `clk_core` stop or run at the wrong frequency.
   P31 cannot detect either (audit F-01).
3. The watchdog timeout must not depend on the core frequency (PowerClock operating points) and must still
   expire if `clk_core` is gated or stuck.
4. The board already provides it: it is the PLL reference.

It clocks only the small controller (478 flops, of which 256 are the 128-bit status snapshot
handshake). No functional datapath runs on it.

## 2. Research configuration (`MC_EN = 1`, DieTop `EXTMEM_ASYNC = 1`)

| Domain | Port | Period | Status | Crossing to `clk_core` |
|---|---|---|---|---|
| Core compute | `clk_core_i` | 10 ns | **implemented** | — |
| Management / reference | `clk_ref_i` | 40 ns | **implemented** | handshakes, pulse / level synchronisers (inside this block) |
| Memory-controller interface | `clk_mc_i` | 7 ns (P31 V3 regression) | **implemented** (reset, monitor, readiness) | data: ExtMem P24 async FIFOs (`extmem_mc_cdc`) |
| PCIe application interface | — | — | **not created**: no endpoint IP / PHY (HostLink P25 BLOCKED) | when it exists: `sf_crt_async_fifo` channels, or run HostLink on `clk_core` |
| JTAG `tck` | `tck_i` (die) | — | **not created**: TestCore not instantiated | TestCore's own synchronisers / handshake bridge |

## 3. Gated clocks: copies, not new domains

| Gated clock | Cell | Source | Enable | Relationship |
|---|---|---|---|---|
| `clk_core_o` | `u_cg_root` (ICG) | `clk_core_i` | `root_en`: off asynchronously (reset / clock loss), on synchronously (2 flops in `clk_core_i`) | same clock, delayed by the ICG |
| `clk_br_o[b]` | `g_br[b].u_bg.u_cg` (ICG) | `clk_core_o` | `en_q = sw_en \| clk_req \| wake \| force` (registered in `clk_core_o`) | same clock, two ICG levels |

Crossings between `clk_core_i`, `clk_core_o` and `clk_br_o[b]` are **not** CDC: the edges are the same,
and STA times them as one clock propagated through clock-gating cells. That is why the SDC has no
`create_generated_clock`. CTS must balance the three sink groups (`06_CTS.md`).

## 4. Relationships

All functional clocks are **mutually asynchronous**. Even the PLL output and its own reference have no
guaranteed phase relationship after lock. Every crossing therefore ends in a synchroniser, a handshake or
a reset synchroniser (`04_CDC.md`). In the SDC every such pair is bounded with
`set_max_delay = min(T_src, T_dst)`, and hold is false-pathed (`05_SDC.md`).

## 5. Clock-domain-ready monitoring

`sf_crt_clk_mon_src` (in the monitored clock) drives a registered 8-bit Gray counter. `sf_crt_clk_mon`
(in `clk_ref`) synchronises it with a bus-coherent synchroniser, accumulates edges over `MON_WINDOW`
reference cycles and declares the clock OK after **`MON_OK_WIN` (default 2) consecutive in-range
windows**. A single out-of-range window clears OK.

* Range `[CNT_MIN, CNT_MAX]` per clock. A stopped clock (count 0) is always detected. A wrong-frequency
  clock is detected once the integrator programs real bounds. The testbench uses ±40 % around nominal.
* Accuracy: ±1 reference cycle of edges at each window boundary (±2 with the metastability model).
* Limit: f_mon / f_ref < 127 (8-bit Gray delta per reference cycle). At 25 MHz that covers < 3.1 GHz.
* Two windows are needed because a clock that starts mid-window produces a partial, possibly in-range,
  first count. That hole was found by the regression (Verilator `clk_start`, seed 3) and closed in the RTL.
* Readiness of each domain = its clock OK **and** its reset released (acknowledged). It is published in
  `R_STATUS` (`core_clk_ok`, `mc_clk_ok`, `dom_ack`) and on `sys_ready_o` / `mc_ready_o`.

## 6. Measured power-up timeline (simulation, `clk_ref` 50 MHz, `clk_core` 143 MHz, research build)

| t (ns after POR release) | event |
|---|---|
| 0 | POR released; sequencer leaves reset (WAIT_CLK at 53 ns) |
| 600 | PLL lock asserted |
| 673 | core clock qualified by the monitor (2 in-range windows) |
| 853 / 862 | `STABLE_CYC` met: root gate requested / `clk_core_o` starts |
| 1002 | fabric reset released (after `PRE_REL_CYC` + acknowledge) |
| 1121 | memory-controller domain ready (released only after the fabric acknowledge) |
| 1142 | ControlCore reset released (`FAB_DELAY` later) |
| 1345 | accelerator branch reset released (clock forced on, `CC_DELAY` later) |
| 1401 | `sys_ready_o` |

All delays are parameters, in reference cycles. Every step waits for an acknowledge from the target
domain, so the sequence is correct for any core / reference frequency ratio. It was tested from 0.3× to
7.7× (`07_VERIFICATION.md`).
