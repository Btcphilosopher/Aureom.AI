# 03 — Clock gating and clock-enable control

## 1. One wrapper, four implementations

`rtl/clk/sf_crt_clk_gate.sv` is the only place a clock is gated. Clocks are never AND-ed in RTL.

| Build | Implementation | Glitch-free because | Evidence |
|---|---|---|---|
| ASIC (default) | `sf_crt_icg_cell` → **`sg13g2_slgcp_1`** (IHP SG13G2) / **`sky130_fd_sc_hd__sdlclkp_1`** (SKY130): library latch-based ICG, `clock_gating_integrated_cell : latch_posedge_precontrol`, scan enable on SCE | the enable latch is transparent only while CLK is low; the tool times GATE setup / hold against the rising edge (clock-gating check) | Yosys mapping: 2 ICG (baseline), 3 (research), pins checked against the Liberty |
| Xilinx 7-series / UltraScale (`SF_CRT_CG_XILINX_BUFGCE`) | `BUFGCE` global buffer | vendor primitive with synchronous CE | Yosys `synth_xilinx`: 2 × BUFGCE, 0 latches |
| Lattice ECP5 (`SF_CRT_CG_ECP5_DCCA`) | `DCCA` dynamic clock control | vendor primitive (ULX3S is the repository's ECP5 board) | Yosys `synth_ecp5`: 2 × DCCA, 0 latches |
| Clock-enable baseline (`SF_CRT_CG_ENABLE_ONLY`) | no gating: `clk_o = clk_i`, `ce_o = en \| test_en` | nothing is gated | Yosys: 0 ICG; domain flops must use `if (ce) q <= d;` |
| Simulation | behavioural latch + AND, identical to the library cell | — | **Refuses to synthesise** (`sf_crt_icg_target_not_selected`), checked by `negative_no_target` |

FPGA primitives are mapped, not validated: no FPGA hardware or vendor tool was available. The FPGA
technology file deliberately has no `sf_crt_icg_cell`, so an FPGA build without one of the two defines
fails to elaborate instead of building LUT-gated clocks.

## 2. Gates in this block

| Gate | Enable logic | Off | On |
|---|---|---|---|
| Root `u_cg_root` | `root_en`: sequencer flop → 2-flop *reset-synchroniser structure* clocked by `clk_core_i` (async clear, D = 1) | asynchronously: POR, external reset, clock / PLL loss. The flops behind it are reset at the same moment. | synchronously, 2 `clk_core_i` edges after the sequencer's request |
| Branch `g_br[b].u_bg.u_cg` | `en_q <= sw_en \| clk_req \| wake \| force` (register of `clk_core_o`, reset value 1) | when software clears `CLK_EN[b]`, the branch does not request its clock, nothing wakes it, and no release is in progress | any of the four |

**Hardware interlock.** The enable is an OR. Software can never stop a branch that requests its clock
(`clk_req` = busy, registered in the branch), that is being addressed (`wake` = command / CSR / NoC
request on the always-clocked side, the ComputeCluster P32 contract), or whose reset the sequencer is
releasing (`force`). The interlock is checked continuously by the testbench and killed by mutant M09.

**Safe release of a gated branch.** Its reset synchroniser is clocked by the gated clock. The sequencer
first raises `force`, waits for the acknowledge that the gate enable is set, releases the reset, waits for
the release acknowledge, then drops `force`. Without the force, a gated-off branch would never leave reset
(mutant M02).

## 3. Verification of glitch-freedom

* `tb_clk_check` on `clk_core_o`, `clk_br_o[0]` and `clk_br_o[1]` in every test. Every gated edge must
  coincide with a source edge of the same polarity, which catches runts and truncated pulses at any
  frequency. 0 errors over every regression run. Mutant M05 (AND gate without latch) is killed:
  "truncated pulse".
* Glitch injection on `clk_core_i` before lock (`clk_start`): `clk_core_o` has 0 edges.
* Random enable / job storm: 120 operations per run, plus `test_en` override (`clk_en`).
* Structural: `scripts/cdc_check.py` rule CLK-COMB-GATING (no logic other than buffers, inverters and ICGs
  in any clock path) passes on both netlists. Negative test `neg_comb_clkgate` is flagged.
* Clock-gating timing: the ICG GATE setup / hold checks are in group `clock_gating clk_core`, with slack
  9.2 ns at the slow corner (`08_TIMING_ANALYSIS.md`).

## 4. Interaction with existing gating

* ControlCore PMU ICG (`u_cg_acc`) and PowerClock gates stay where they are. When the die uses this
  block's root gate, the accelerator clock has two ICG levels (root + PMU) and CTS balances them like the
  branch group here.
* Only **one** root gate may exist. If PowerClock is integrated, its global core gate (`u_cg_core`) must
  be removed or left permanently enabled, because this block's root gate is the reset / PLL authority
  (`integration/P31_INTEGRATION.md`).
