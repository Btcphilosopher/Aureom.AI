// =============================================================================
// SilicaFlux CLOCKTREE :: tb_crt_top -- system testbench (SIMULATION ONLY)
//
// One test per run (+TEST=<name>, +SEED=<n>); scripts/regress.py runs every
// test in every build (MC on/off, clock ratios, random CDC metastability).
// Tests: por clk_start ext_rst wdog ext_wdog sw_reset simul clk_en clk_loss
//        dma_reset cdc test_mode
// Continuous checkers (whole run): reset release ordering, synchronous release
// of every reset output, glitch-free gated clocks, no X after POR, branch
// clock interlock, the clock-semantics sanity chain.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

`ifndef TB_MC_EN
`define TB_MC_EN 0
`endif
`ifndef REF_HALF
`define REF_HALF 10.0
`endif
`ifndef CORE_HALF
`define CORE_HALF 3.5
`endif
`ifndef MC_HALF
`define MC_HALF 4.5
`endif

module tb_crt_top;
  import sf_crt_pkg::*;

  localparam bit  MC_EN    = `TB_MC_EN;
  localparam int  NB       = 2;
  localparam int  NW       = 2;
  localparam int  WIN      = 16;
  localparam real REF_H    = `REF_HALF;
  localparam real CORE_H   = `CORE_HALF;
  localparam real MC_H     = `MC_HALF;
  localparam real CORE_EXP = WIN * REF_H / CORE_H;      // core edges per monitor window
  localparam real MC_EXP   = WIN * REF_H / MC_H;
  localparam int  CORE_MIN = (CORE_EXP * 0.6 < 1.0) ? 1 : $rtoi(CORE_EXP * 0.6);
  localparam int  CORE_MAX = $rtoi(CORE_EXP * 1.4) + 2;
  localparam int  MC_MIN   = (MC_EXP * 0.6 < 1.0) ? 1 : $rtoi(MC_EXP * 0.6);
  localparam int  MC_MAX   = $rtoi(MC_EXP * 1.4) + 2;
  // drain timeout: long enough for the longest test transfer (~300 core cycles)
  localparam int  QTO      = 400 + $rtoi(900.0 * CORE_H / REF_H);
  localparam int  WD_CDC   = 5000 + $rtoi(20000.0 * CORE_H / REF_H);

  // ------------------------------------------------------------------ clocks
  logic clk_ref = 1'b0, clk_core_g = 1'b0, clk_mc_g = 1'b0, glitch = 1'b0;
  real  ref_half = REF_H, core_half = CORE_H, mc_half = MC_H;
  bit   core_run = 1'b0, mc_run = 1'b0;
  wire  clk_core = clk_core_g | glitch;
  wire  clk_mc   = clk_mc_g;

  always #(ref_half) clk_ref = ~clk_ref;
  // a stopping clock completes its high phase and stays low
  always begin
    #(core_half);
    if (core_run || clk_core_g) clk_core_g = ~clk_core_g;
  end
  always begin
    #(mc_half);
    if (mc_run || clk_mc_g) clk_mc_g = ~clk_mc_g;
  end

  // ------------------------------------------------------------------ DUT
  logic          por_n, ext_rst_n, pll_lock, test_mode, test_rst_n, test_en;
  logic          clk_core_o, fab_rst_no, cc_rst_no, mc_rst_no;
  logic [NB-1:0] clk_br_o, clk_br_ce, br_rst_no, br_quiesce, br_idle, br_clk_req, br_wake;
  logic          fab_quiesce, fab_idle, wdog_irq, sys_ready, mc_ready;
  logic [NW-1:0] wdog_req;
  logic          rb_sel, rb_we, rb_err;
  logic [7:0]    rb_addr;
  logic [31:0]   rb_wdata, rb_rdata;
  logic [3:0]    seq_state;

  silicaflux_clock_reset_tree #(
    .NB(NB), .NW(NW), .MC_EN(MC_EN), .MON_WINDOW(WIN),
    .CORE_CNT_MIN(16'(CORE_MIN)), .CORE_CNT_MAX(16'(CORE_MAX)),
    .MC_CNT_MIN(16'(MC_MIN)), .MC_CNT_MAX(16'(MC_MAX)),
    .STABLE_CYC(8), .PRE_REL_CYC(4), .FAB_DELAY(4), .CC_DELAY(4), .HOLD_CYC(4), .QTIMEOUT(QTO)
  ) u_dut (
    .clk_ref_i(clk_ref), .clk_core_i(clk_core), .clk_mc_i(clk_mc),
    .por_ni(por_n), .ext_rst_ni(ext_rst_n), .pll_lock_i(pll_lock),
    .test_mode_i(test_mode), .test_rst_ni(test_rst_n), .test_en_i(test_en),
    .clk_core_o, .clk_br_o, .clk_br_ce_o(clk_br_ce),
    .fab_rst_no, .cc_rst_no, .br_rst_no, .mc_rst_no,
    .fab_quiesce_o(fab_quiesce), .fab_idle_i(fab_idle), .br_quiesce_o(br_quiesce), .br_idle_i(br_idle),
    .br_clk_req_i(br_clk_req), .br_wake_i(br_wake),
    .wdog_req_i(wdog_req), .wdog_irq_o(wdog_irq), .sys_ready_o(sys_ready), .mc_ready_o(mc_ready),
    .rb_sel_i(rb_sel), .rb_we_i(rb_we), .rb_addr_i(rb_addr), .rb_wdata_i(rb_wdata),
    .rb_rdata_o(rb_rdata), .rb_err_o(rb_err), .seq_state_o(seq_state));

  // ------------------------------------------------------------------ models
  logic       dma_start, dma_hang, dma_busy, dma_done, dma_err, dma_acc;
  logic [7:0] dma_len, dma_seed, dma_done_seed;
  tb_dma_model u_dma (
    .clk(clk_core_o), .rst_n(fab_rst_no), .start(dma_start), .len(dma_len), .seed(dma_seed),
    .quiesce(fab_quiesce), .hang(dma_hang), .busy(dma_busy), .done(dma_done), .done_seed(dma_done_seed),
    .err(dma_err), .accepted(dma_acc));
  assign fab_idle = !dma_busy;

  logic [NB-1:0] cm_start, cm_done;
  logic [7:0]    cm_n      [NB];
  logic [15:0]   cm_result [NB];
  logic [31:0]   cm_edges  [NB];
  for (genvar b = 0; b < NB; b++) begin : g_cm
    tb_compute_model u_cm (
      .clk(clk_br_o[b]), .rst_n(br_rst_no[b]), .start(cm_start[b]), .n(cm_n[b]), .quiesce(br_quiesce[b]),
      .clk_req(br_clk_req[b]), .idle(br_idle[b]), .done(cm_done[b]), .result(cm_result[b]), .edges(cm_edges[b]));
  end
  assign br_wake = cm_start;     // a pending command wakes its branch

  // completed-job counters (a done pulse is never missed by a waiting task)
  int cm_done_cnt [NB];
  int cm_mark     [NB];
  initial for (int b = 0; b < NB; b++) cm_done_cnt[b] = 0;
  always @(posedge clk_core_o) for (int b = 0; b < NB; b++) if (cm_done[b] === 1'b1) cm_done_cnt[b] = cm_done_cnt[b] + 1;

  // block-watchdog requests: registered levels in the fabric domain, cleared by its reset
  logic [NW-1:0] wdog_req_set;
  always_ff @(posedge clk_core_o or negedge fab_rst_no) begin
    if (!fab_rst_no) wdog_req <= '0;
    else             wdog_req <= wdog_req | wdog_req_set;
  end

  // ------------------------------------------------------------------ checkers
  int  errors = 0, checks = 0;
  bit  chk_en = 1'b0;
  string test_name;

  task automatic fail(input string msg);
    errors++;
    $display("ERROR %0t [%s] %s", $realtime, test_name, msg);
  endtask
  task automatic check(input bit cond, input string msg);
    checks++;
    if (!cond) fail(msg);
  endtask

  tb_clk_check #(.NAME("clk_core_o")) u_cc_root (.src(clk_core), .gclk(clk_core_o), .en(chk_en && !glitch));
  tb_clk_check #(.NAME("clk_br_o[0]")) u_cc_b0 (.src(clk_core_o), .gclk(clk_br_o[0]), .en(chk_en));
  tb_clk_check #(.NAME("clk_br_o[1]")) u_cc_b1 (.src(clk_core_o), .gclk(clk_br_o[1]), .en(chk_en));
  tb_rel_check #(.NAME("fab_rst_no"))  u_rc_fab (.clk(clk_core_o), .rst_n(fab_rst_no), .en(!test_mode));
  tb_rel_check #(.NAME("cc_rst_no"))   u_rc_cc  (.clk(clk_core_o), .rst_n(cc_rst_no),  .en(!test_mode));
  tb_rel_check #(.NAME("br_rst_no[0]")) u_rc_b0 (.clk(clk_br_o[0]), .rst_n(br_rst_no[0]), .en(!test_mode));
  tb_rel_check #(.NAME("br_rst_no[1]")) u_rc_b1 (.clk(clk_br_o[1]), .rst_n(br_rst_no[1]), .en(!test_mode));
  tb_rel_check #(.NAME("mc_rst_no"))   u_rc_mc  (.clk(clk_mc), .rst_n(mc_rst_no), .en(!test_mode));

  // release ordering and minimum spacing (FAB_DELAY / CC_DELAY reference cycles)
  realtime t_fab_rel = -1.0e9, t_cc_rel = -1.0e9;
  always @(posedge fab_rst_no) t_fab_rel = $realtime;
  always @(posedge cc_rst_no) begin
    if (!test_mode && chk_en && $realtime - t_fab_rel < 4 * 2.0 * ref_half)
      fail($sformatf("ControlCore released %0.1f ns after the fabric (< FAB_DELAY reference cycles)", $realtime - t_fab_rel));
    t_cc_rel = $realtime;
  end
  always @(posedge br_rst_no[0])
    if (!test_mode && chk_en && $realtime - t_cc_rel < 4 * 2.0 * ref_half)
      fail($sformatf("branch 0 released %0.1f ns after the ControlCore (< CC_DELAY reference cycles)", $realtime - t_cc_rel));
  always @(posedge cc_rst_no)    if (!test_mode && !fab_rst_no) fail("ControlCore released before the fabric");
  always @(posedge br_rst_no[0]) if (!test_mode && !cc_rst_no)  fail("branch 0 released before the ControlCore");
  always @(posedge br_rst_no[1]) if (!test_mode && !cc_rst_no)  fail("branch 1 released before the ControlCore");
  always @(posedge fab_rst_no)   if (!test_mode && !pll_lock)   fail("fabric released without PLL lock");
  always @(posedge mc_rst_no)    if (!test_mode && !fab_rst_no) fail("memory controller released while the fabric is in reset");

  // no X once the POR has been released
  always @(posedge clk_ref) begin
    if (chk_en && por_n && !test_mode) begin
      if ((^{fab_rst_no, cc_rst_no, br_rst_no, mc_rst_no, seq_state, sys_ready, wdog_irq}) === 1'bx)
        fail($sformatf("X on a reset / status output %b %b %b %b %b %b %b", fab_rst_no, cc_rst_no, br_rst_no, mc_rst_no, seq_state, sys_ready, wdog_irq));
      if (fab_rst_no && (^{rb_rdata, rb_err, clk_core_o}) === 1'bx)
        fail($sformatf("X on the register bus while the fabric is out of reset %h %b %b", rb_rdata, rb_err, clk_core_o));
    end
  end

  // interlock: a branch that has requested its clock for two cycles must have its gate open
  logic [NB-1:0] req_d1;
  always @(posedge clk_core_o) begin
    if (chk_en && fab_rst_no && !test_mode) begin
      for (int b = 0; b < NB; b++)
        if (req_d1[b] && br_clk_req[b] && !u_dut.br_en[b]) fail($sformatf("branch %0d gated while it requests its clock", b));
    end
    req_d1 <= br_clk_req;
  end

  // simulation-semantics sanity: counter in clk_core_o, copied in clk_br_o[0],
  // copied back in clk_core_o; while the branch is ungated the copy lags by 2
  logic [7:0] sem_a = 0, sem_b = 0, sem_c = 0;
  always @(posedge clk_core_o) begin sem_a <= sem_a + 8'd1; sem_c <= sem_b; end
  always @(posedge clk_br_o[0]) sem_b <= sem_a;
  // (the sanity chain is evaluated in t_clk_en while branch 0 is ungated)

  // ------------------------------------------------------------------ register bus
  task automatic rb_access(input bit we, input logic [7:0] a, input logic [31:0] d,
                           output logic [31:0] q, output bit e);
    @(negedge clk_core_o);
    rb_sel = 1'b1; rb_we = we; rb_addr = a; rb_wdata = d;
    #0.4;
    q = rb_rdata; e = rb_err;
    @(negedge clk_core_o);
    rb_sel = 1'b0; rb_we = 1'b0;
  endtask
  task automatic rb_wr(input logic [7:0] a, input logic [31:0] d, input bit exp_err = 1'b0);
    logic [31:0] q; bit e;
    rb_access(1'b1, a, d, q, e);
    check(e == exp_err, $sformatf("write 0x%02h <= 0x%08h: rb_err=%0d, expected %0d", a, d, e, exp_err));
  endtask
  // registers backed by a CDC channel answer rb_err while the channel is busy:
  // software retries, as the driver would
  task automatic rb_wr_retry(input logic [7:0] a, input logic [31:0] d);
    logic [31:0] q; bit e; int n;
    n = 0;
    e = 1'b1;
    while (e && n < 200) begin
      rb_access(1'b1, a, d, q, e);
      n++;
    end
    check(!e, $sformatf("write 0x%02h <= 0x%08h refused %0d times", a, d, n));
  endtask
  task automatic rb_rd(input logic [7:0] a, output logic [31:0] q);
    bit e;
    rb_access(1'b0, a, 32'd0, q, e);
    check(!e, $sformatf("read 0x%02h refused", a));
  endtask

  // ------------------------------------------------------------------ helpers
  task automatic ref_cycles(input int n);
    repeat (n) @(posedge clk_ref);
  endtask
  task automatic wait_snap(input int n = 3);
    repeat (n) @(posedge u_dut.snap_v_c);
    @(negedge clk_core_o);
  endtask
  task automatic wait_run(input int max_ref = 20000, input string why = "");
    int i; bit hit;
    i = 0; hit = 1'b0;
    while (i < max_ref && !hit) begin
      @(posedge clk_ref);
      if (seq_state == ST_RUN && sys_ready && fab_rst_no && cc_rst_no && br_rst_no == '1) hit = 1'b1;
      else i++;
    end
    check(hit, $sformatf("sequence did not reach RUN %s", why));
    if (fab_rst_no) wait_snap(3);
  endtask
  task automatic wait_state(input logic [3:0] s, input int max_ref, input string why);
    int i; bit hit;
    i = 0; hit = 1'b0;
    while (i < max_ref && !hit) begin
      @(posedge clk_ref);
      if (seq_state == s) hit = 1'b1;
      else i++;
    end
    check(hit, $sformatf("state %0d not reached: %s", s, why));
  endtask

  task automatic power_on(input real lock_delay, input bit start_core = 1'b1);
    por_n = 1'b0; ext_rst_n = 1'b1; pll_lock = 1'b0; core_run = 1'b0; mc_run = 1'b0;
    test_mode = 1'b0; test_rst_n = 1'b0; test_en = 1'b0;
    rb_sel = 1'b0; rb_we = 1'b0; rb_addr = '0; rb_wdata = '0;
    dma_start = 1'b0; dma_hang = 1'b0; dma_len = 8'd8; dma_seed = 8'd1;
    cm_start = '0; for (int b = 0; b < NB; b++) cm_n[b] = 8'd1;
    wdog_req_set = '0;
    #(37.3);
    por_n = 1'b1;
    chk_en = 1'b1;
    if (start_core) begin
      #($urandom_range(0, 7) * 0.71);
      core_run = 1'b1;
      mc_run   = MC_EN;
      #(lock_delay);
      pll_lock = 1'b1;
    end
  endtask

  task automatic expect_cause(input logic [15:0] mask, input string why, input bit exact = 1'b0);
    logic [31:0] q;
    wait_snap(4);
    rb_rd(R_CAUSE, q);
    if (exact) check(q[15:0] == mask, $sformatf("CAUSE = 0x%04h, expected exactly 0x%04h (%s)", q[15:0], mask, why));
    else       check((q[15:0] & mask) == mask, $sformatf("CAUSE = 0x%04h, expected bits 0x%04h (%s)", q[15:0], mask, why));
  endtask

  // DMA: start one transfer; optionally wait for its verified completion
  task automatic dma_run(input logic [7:0] seed, input logic [7:0] len, input bit wait_done = 1'b1);
    int i;
    @(negedge clk_core_o);
    dma_seed = seed; dma_len = len; dma_start = 1'b1;
    for (i = 0; i < 2000 && !dma_acc; i++) @(negedge clk_core_o);
    dma_start = 1'b0;
    check(i < 2000, "DMA start not accepted");
    if (wait_done) begin
      i = 0;
      while (i < 4000 && !dma_done) begin
        @(posedge clk_core_o);
        if (!dma_done) i++;
      end
      check(i < 4000 && dma_done_seed == seed, $sformatf("DMA seed %0d did not complete", seed));
      check(!dma_err, "DMA copied a wrong word");
    end
  endtask

  // compute job on branch b: n + (n-1) + ... + 1
  task automatic cm_launch(input int b, input logic [7:0] n);
    int i;
    @(negedge clk_core_o);
    cm_mark[b] = cm_done_cnt[b];
    cm_n[b] = n; cm_start[b] = 1'b1;
    for (i = 0; i < 2000 && !br_clk_req[b]; i++) @(negedge clk_core_o);
    cm_start[b] = 1'b0;
    check(i < 2000, $sformatf("branch %0d did not accept its job", b));
  endtask
  task automatic cm_wait(input int b, input logic [7:0] n);
    int i;
    i = 0;
    while (i < 20000 && cm_done_cnt[b] <= cm_mark[b]) begin
      @(posedge clk_core_o);
      #0.05;
      if (cm_done_cnt[b] <= cm_mark[b]) i++;
    end
    #0.1;
    check(i < 20000, $sformatf("branch %0d job did not finish", b));
    check(cm_result[b] == (n * (n + 1)) / 2, $sformatf("branch %0d result %0d, expected %0d", b, cm_result[b], (n * (n + 1)) / 2));
  endtask
  task automatic cm_run(input int b, input logic [7:0] n);
    cm_launch(b, n);
    cm_wait(b, n);
  endtask

  task automatic check_functional(input string tag);
    logic [31:0] q;
    logic [7:0]  n0, n1;
    rb_rd(R_ID, q);
    check(q == CRT_ID, $sformatf("ID mismatch after %s", tag));
    wait_snap(2);
    rb_rd(R_STATUS, q);
    check(q[3:0] == ST_RUN && q[6] && q[7] && q[8], $sformatf("STATUS 0x%08h not RUN/locked/clock OK after %s", q, tag));
    check(q[19:17] == {MC_EN && mc_ready, 1'b1, 1'b1}, $sformatf("STATUS domain acks 0x%0h after %s", q[19:17], tag));
    dma_run(8'($urandom_range(1, 250)), 8'($urandom_range(8, 40)));
    n0 = 8'($urandom_range(3, 40));
    n1 = 8'($urandom_range(3, 40));
    cm_launch(0, n0);
    cm_launch(1, n1);
    cm_wait(0, n0);
    cm_wait(1, n1);
  endtask

  task automatic swrst(input logic [1:0] scope, input logic [7:0] mask, input bit force_, input bit exp_err = 1'b0);
    if (exp_err) rb_wr(R_SW_RST, {SWRST_KEY, 3'd0, force_, 2'd0, scope, mask}, 1'b1);
    else         rb_wr_retry(R_SW_RST, {SWRST_KEY, 3'd0, force_, 2'd0, scope, mask});
  endtask

  task automatic wdog_cfg(input logic [31:0] load, input bit en, input bit lock, input bit rst_en);
    rb_wr(R_WDOG_LOAD, load);
    rb_wr_retry(R_WDOG_CTRL, {29'd0, rst_en, lock, en});
  endtask

  // counts assertions of the fabric reset
  int fab_asserts = 0;
  always @(negedge fab_rst_no) if (chk_en) fab_asserts++;
  int root_rises_gate = 0;

  // ================================================================== TESTS
  task automatic t_por();
    logic [31:0] q;
    realtime t_lock;
    power_on(600.0);
    t_lock = $realtime;
    check(seq_state == ST_WAIT_CLK || seq_state == ST_ROOT_ON, "state after lock");
    wait_run(20000, "after POR");
    rb_rd(R_CONFIG, q);
    check(q[31:24] == CRT_VERSION && q[23:16] == NB && q[15:8] == NW && q[0] == MC_EN, $sformatf("CONFIG 0x%08h", q));
    expect_cause(16'h0001, "POR", 1'b1);
    rb_rd(R_RST_INFO, q);
    check(q[15:0] == 16'd0 && q[19:16] == CAUSE_POR, $sformatf("RST_INFO 0x%08h after POR", q));
    rb_rd(R_CLK_MEAS, q);
    check(q[15:0] >= CORE_MIN && q[15:0] <= CORE_MAX, $sformatf("core clock count %0d outside [%0d,%0d]", q[15:0], CORE_MIN, CORE_MAX));
    if (MC_EN) begin
      check(q[31:16] >= MC_MIN && q[31:16] <= MC_MAX, $sformatf("mc clock count %0d outside [%0d,%0d]", q[31:16], MC_MIN, MC_MAX));
      wait (mc_ready);
    end
    rb_rd(R_WDOG_CTRL, q);
    check(q[2:0] == 3'b000, "watchdog must be disabled after POR");
    check(u_rc_fab.releases == 1 && u_rc_cc.releases == 1 && u_rc_b0.releases == 1 && u_rc_b1.releases == 1,
          "each domain released exactly once at power-up");
    check_functional("POR");
  endtask

  task automatic t_clk_start();
    logic [31:0] q;
    int r0;
    power_on(0.0, 1'b0);          // POR released, NO core clock
    ref_cycles(200);
    check(seq_state == ST_WAIT_CLK, "no core clock: must wait");
    check(u_cc_root.rises == 0, "no clk_core_o edge without a core clock");
    check(!fab_rst_no && !cc_rst_no && br_rst_no == '0 && !mc_rst_no, "all domains held in reset without a clock");
    // glitchy, unlocked clock: root gate stays closed
    repeat (25) begin
      #($urandom_range(5, 60) * 1.0);
      glitch = 1'b1; #0.3; glitch = 1'b0;
    end
    ref_cycles(20);
    check(u_cc_root.rises == 0, "a glitch on clk_core_i reached clk_core_o");
    check(seq_state == ST_WAIT_CLK, "glitches must not start the sequence");
    // a runaway (3x) clock with a false lock: frequency monitor refuses it
    core_half = CORE_H / 3.0;
    core_run  = 1'b1;
    pll_lock  = 1'b1;
    ref_cycles(WIN * 12);
    check(seq_state == ST_WAIT_CLK, "out-of-range clock must not be accepted");
    check(u_dut.core_meas > CORE_MAX, $sformatf("monitor count %0d not above max %0d", u_dut.core_meas, CORE_MAX));
    check(u_cc_root.rises == 0, "root gate opened on an out-of-range clock");
    // lock chatter at the right frequency: needs STABLE consecutive OK cycles
    pll_lock  = 1'b0;                                 // PLL relocking at the right frequency
    core_half = CORE_H;
    ref_cycles(WIN * 3);
    repeat (12) begin
      pll_lock = 1'b0; ref_cycles(2); pll_lock = 1'b1;
      ref_cycles(5);                                  // < STABLE_CYC: never stable
    end
    r0 = u_cc_root.rises;
    check(r0 == 0, "a chattering lock must not open the root gate");
    wait_run(20000, "after clock start");
    check(u_dut.u_seq.cnt_q < 16'hFFFF, "counter sanity");
    rb_rd(R_CLK_MEAS, q);
    check(q[15:0] >= CORE_MIN && q[15:0] <= CORE_MAX, "core clock in range once running");
    check(u_rc_fab.releases == 1, "fabric released exactly once");
    check_functional("clock start");
  endtask

  task automatic t_ext_rst();
    logic [31:0] q;
    int n_before;
    power_on(300.0);
    wait_run(20000, "after POR");
    check_functional("POR");
    // short (1 ns) external reset glitch during DMA and compute activity
    dma_run(8'd77, 8'd200, 1'b0);
    cm_launch(0, 8'd200);
    #($urandom_range(0, 40) * 1.3);
    ext_rst_n = 1'b0; #1.0; ext_rst_n = 1'b1;
    #0.5;
    check(!fab_rst_no && !cc_rst_no && br_rst_no == '0, "a 1 ns external reset must assert every domain asynchronously");
    check(!u_dut.seq_root_en, "external reset closes the root clock gate");
    wait_run(20000, "after 1 ns external reset");
    check(!dma_busy, "DMA state cleared by the reset");
    expect_cause(16'h0003, "POR|EXT");
    rb_rd(R_RST_INFO, q);
    check(q[15:0] == 16'd1 && q[19:16] == CAUSE_EXT, $sformatf("RST_INFO 0x%08h after EXT", q));
    check_functional("1 ns external reset");
    // long external reset: root gate closed, no core-domain clock while held
    n_before = u_cc_root.rises;
    ext_rst_n = 1'b0;
    ref_cycles(100);
    check(u_cc_root.rises - n_before <= 1, "clk_core_o must stop while the external reset is held");
    check(seq_state == ST_OFF, "sequencer held in reset by ext_rst_ni");
    ext_rst_n = 1'b1;
    wait_run(20000, "after long external reset");
    rb_rd(R_RST_INFO, q);
    check(q[15:0] == 16'd2, "two external resets counted");
    // W1C of the cause register
    rb_wr_retry(R_CAUSE, 32'h0000_0003);
    expect_cause(16'h0000, "cleared", 1'b1);
    check_functional("long external reset");
  endtask

  task automatic t_wdog();
    logic [31:0] q;
    int a0;
    power_on(300.0);
    wait_run(20000, "after POR");
    rb_wr(R_WDOG_KICK, 32'h1234_5678, 1'b1);             // wrong key refused
    // serviced watchdog: no reset
    wdog_cfg(32'd200, 1'b1, 1'b0, 1'b1);
    a0 = fab_asserts;
    repeat (20) begin
      ref_cycles(100);
      rb_wr(R_WDOG_KICK, WDOG_KICK_KEY);
    end
    check(fab_asserts == a0 && !wdog_irq, "a serviced watchdog must not warn or reset");
    wait_snap(2);
    rb_rd(R_WDOG_CTRL, q);
    check(q[2:0] == 3'b101, $sformatf("WDOG_CTRL effective 0x%0h", q[2:0]));
    rb_rd(R_WDOG_CNT, q);
    check(q <= 32'd200, $sformatf("WDOG_CNT %0d above load", q));
    // stop servicing: warning then system reset
    wait (wdog_irq);
    rb_rd(R_IRQ, q);
    check(q[0], "IRQ register shows the watchdog warning");
    check(fab_asserts == a0, "stage 1 only warns");
    wait (!fab_rst_no);
    wait_run(20000, "after watchdog reset");
    expect_cause(16'd1 << CAUSE_WDOG, "WDOG");
    rb_rd(R_RST_INFO, q);
    check(q[19:16] == CAUSE_WDOG, "last cause WDOG");
    rb_rd(R_WDOG_CTRL, q);
    check(q[2:0] == 3'b000, "watchdog disabled after the reset it caused");
    check_functional("watchdog reset");
    // interrupt-only mode
    a0 = fab_asserts;
    wdog_cfg(32'd150, 1'b1, 1'b0, 1'b0);
    wait (wdog_irq);
    ref_cycles(700);
    check(fab_asserts == a0, "interrupt-only watchdog must not reset");
    rb_wr(R_WDOG_KICK, WDOG_KICK_KEY);
    // kick -> clk_ref (pulse sync) -> warning cleared -> clk_core (level sync)
    for (int i = 0; i < 60 && wdog_irq; i++) @(posedge clk_ref);
    check(!wdog_irq, "service clears the warning");
    rb_wr_retry(R_WDOG_CTRL, 32'd0);                      // disable
    // locked watchdog cannot be disabled
    wdog_cfg(32'd300, 1'b1, 1'b1, 1'b1);
    ref_cycles(20);
    rb_wr_retry(R_WDOG_CTRL, 32'd0);                      // attempt to disable
    wait_snap(3);
    rb_rd(R_STATUS, q);
    check(q[16], "configuration of a locked watchdog must be rejected (cfg_rej)");
    rb_rd(R_WDOG_CTRL, q);
    check(q[2:0] == 3'b111, "locked watchdog stays enabled");
    wait (!fab_rst_no);
    wait_run(20000, "after locked watchdog reset");
    rb_rd(R_RST_INFO, q);
    check(q[19:16] == CAUSE_WDOG, "locked watchdog expired");
    rb_rd(R_WDOG_CTRL, q);
    check(q[2:0] == 3'b000, "lock cleared by the system reset");
    check_functional("locked watchdog reset");
  endtask

  task automatic t_ext_wdog();
    logic [31:0] q;
    power_on(300.0);
    wait_run(20000, "after POR");
    for (int w = 0; w < NW; w++) begin
      @(negedge clk_core_o); wdog_req_set[w] = 1'b1; @(negedge clk_core_o); wdog_req_set[w] = 1'b0;
      wait (!fab_rst_no);
      wait_run(20000, "after block watchdog request");
      expect_cause(16'd1 << CAUSE_EXT_WDOG, "EXT_WDOG");
      rb_rd(R_RST_INFO, q);
      check(q[19:16] == CAUSE_EXT_WDOG && q[15:0] == 16'(w + 1), $sformatf("RST_INFO 0x%08h", q));
      check_functional("block watchdog reset");
    end
  endtask

  task automatic t_sw_reset();
    logic [31:0] q;
    int a_fab, a_cc, a_b0, a_b1, r_b0;
    realtime t_done, t_rst;
    power_on(300.0);
    wait_run(20000, "after POR");
    if (MC_EN) wait (mc_ready);
    // wrong key: refused, no effect
    a_fab = u_rc_fab.asserts;
    rb_wr(R_SW_RST, {16'hDEAD, 8'h00, 8'h03}, 1'b1);
    ref_cycles(50);
    check(seq_state == ST_RUN && u_rc_fab.asserts == a_fab, "wrong key must not reset");
    // ACC scope, branch 1 only, while branch 0 computes
    a_fab = u_rc_fab.asserts; a_cc = u_rc_cc.asserts; a_b0 = u_rc_b0.asserts; a_b1 = u_rc_b1.asserts;
    cm_launch(0, 8'd250);
    swrst(SCOPE_ACC, 8'b10, 1'b0);
    wait (!br_rst_no[1]);
    wait_run(20000, "after ACC reset");
    cm_wait(0, 8'd250);
    check(u_rc_b1.asserts == a_b1 + 1, "branch 1 reset");
    check(u_rc_b0.asserts == a_b0 && u_rc_cc.asserts == a_cc && u_rc_fab.asserts == a_fab,
          "ACC-scope reset must not touch branch 0, ControlCore or fabric");
    expect_cause(16'd1 << CAUSE_SW_ACC, "SW_ACC");
    // CC scope
    a_fab = u_rc_fab.asserts; a_b0 = u_rc_b0.asserts;
    swrst(SCOPE_CC, 8'h00, 1'b0);
    wait (!cc_rst_no);
    wait_run(20000, "after CC reset");
    check(u_rc_fab.asserts == a_fab, "CC-scope reset must not reset the fabric");
    check(u_rc_b0.asserts == a_b0 + 1, "CC-scope reset includes the accelerators");
    expect_cause(16'd1 << CAUSE_SW_CC, "SW_CC");
    // SYS scope, graceful: the running DMA transfer completes first
    dma_run(8'd91, 8'd220, 1'b0);
    swrst(SCOPE_SYS, 8'h00, 1'b0);
    t_done = 0.0;
    fork
      begin wait (dma_done && dma_done_seed == 8'd91); t_done = $realtime; end
      begin wait (!fab_rst_no); t_rst = $realtime; end
    join
    check(t_done > 0.0 && t_done < t_rst, "graceful SYS reset must wait for the DMA transfer");
    check(!dma_err, "drained transfer correct");
    wait_run(20000, "after graceful SYS reset");
    expect_cause(16'd1 << CAUSE_SW_SYS, "SW_SYS");
    check_functional("graceful SYS reset");
    // SYS scope, FORCE: aborts the transfer
    dma_run(8'd92, 8'd220, 1'b0);
    ref_cycles(2);
    swrst(SCOPE_SYS, 8'h00, 1'b1);
    wait (!fab_rst_no);
    check(!(dma_done && dma_done_seed == 8'd92), "forced reset aborts");
    wait_run(20000, "after forced SYS reset");
    check_functional("forced SYS reset");
    // quiesce timeout: a hung DMA engine never drains
    dma_hang = 1'b1;
    dma_run(8'd93, 8'd50, 1'b0);
    swrst(SCOPE_SYS, 8'h00, 1'b0);
    wait_state(ST_QUIESCE, 40, "drain of the hung engine");
    ref_cycles(QTO / 2);
    check(fab_rst_no && seq_state == ST_QUIESCE, "waiting for the hung engine");
    wait (!fab_rst_no);
    dma_hang = 1'b0;
    wait_run(20000, "after quiesce timeout");
    rb_rd(R_STATUS, q);
    check(q[14], "STATUS.QTIMEOUT set after a drain timeout");
    check_functional("quiesce timeout");
    // MEMCTL scope
    if (MC_EN) begin
      a_fab = u_rc_fab.asserts;
      swrst(SCOPE_MC, 8'h00, 1'b1);
      wait (!mc_rst_no);
      ref_cycles(4);
      wait (mc_rst_no);
      wait (mc_ready);
      check(u_rc_fab.asserts == a_fab, "MEMCTL reset must not reset the fabric");
      expect_cause(16'd1 << CAUSE_SW_MC, "SW_MC");
    end else begin
      swrst(SCOPE_MC, 8'h00, 1'b1, 1'b1);                  // refused: no MC domain in this build
    end
    // command while a reset is in progress: dropped
    cm_launch(1, 8'd200);
    swrst(SCOPE_ACC, 8'b10, 1'b0);                         // drains branch 1 (busy ~200 cycles)
    wait_state(ST_QUIESCE, 40, "draining branch 1");
    swrst(SCOPE_ACC, 8'b01, 1'b0);                         // arrives outside RUN
    wait_run(20000, "after ACC reset with a dropped command");
    wait_snap(3);
    rb_rd(R_STATUS, q);
    check(q[15], "STATUS.CMD_DROP set for a command outside RUN");
    check_functional("dropped command");
  endtask

  // all the reset causes that coincided in one sequencer cycle
  logic [15:0] evt_seen_or = '0;
  int          evt_multi   = 0;
  always @(posedge clk_ref) begin
    if (u_dut.seq_evt != 16'd0) begin
      evt_seen_or <= evt_seen_or | u_dut.seq_evt;
      if ((u_dut.seq_evt & (u_dut.seq_evt - 16'd1)) != 16'd0) evt_multi <= evt_multi + 1;
    end
  end

  task automatic t_simul();
    logic [31:0] q;
    int a0, k;
    power_on(300.0);
    wait_run(20000, "after POR");
    // (a) system watchdog expiry vs block watchdog request, swept around the expiry
    for (k = 0; k < 32; k++) begin
      a0 = fab_asserts;
      wdog_cfg(32'd40, 1'b1, 1'b0, 1'b1);
      // stage 2 expires 41 ref cycles after stage 1; the block request needs
      // ~1 core + 2 ref cycles, the expiry 2 ref cycles (RDC stage): sweep the
      // request launch across the coincidence point in core-cycle steps
      @(posedge u_dut.u_wdog.irq_o);
      ref_cycles(36);
      #(k * REF_H / 2.0);                             // quarter-reference-cycle steps
      @(negedge clk_core_o);
      if (fab_rst_no) begin wdog_req_set[0] = 1'b1; @(negedge clk_core_o); wdog_req_set[0] = 1'b0; end
      wait (!fab_rst_no);
      wait_run(20000, "after coincident watchdogs");
      ref_cycles(30);
      check(fab_asserts == a0 + 1, $sformatf("iteration %0d: exactly one reset expected, got %0d", k, fab_asserts - a0));
    end
    // the launch of the block request is quantised to core cycles: a same-cycle
    // coincidence is guaranteed to be hit only when the core is faster than clk_ref
    if (CORE_H < REF_H)
      check(evt_multi > 0 && evt_seen_or[CAUSE_WDOG] && evt_seen_or[CAUSE_EXT_WDOG],
            "at least one sweep point must log WDOG and EXT_WDOG in the same event");
    $display("simul: %0d multi-cause events, causes seen 0x%04h", evt_multi, evt_seen_or);
    rb_rd(R_RST_INFO, q);
    check(q[19:16] == CAUSE_WDOG || q[19:16] == CAUSE_EXT_WDOG, "last cause is a watchdog");
    // (b) software command coinciding with a block watchdog: watchdog wins, command dropped
    @(negedge clk_core_o);
    wdog_req_set[1] = 1'b1;
    rb_wr(R_SW_RST, {SWRST_KEY, 6'd0, SCOPE_CC, 8'h00});
    wdog_req_set[1] = 1'b0;
    wait (!fab_rst_no);
    wait_run(20000, "after watchdog + command");
    expect_cause(16'd1 << CAUSE_EXT_WDOG, "EXT_WDOG wins");
    // (c) watchdog during a graceful drain escalates immediately
    dma_hang = 1'b1;
    dma_run(8'd55, 8'd30, 1'b0);
    swrst(SCOPE_SYS, 8'h00, 1'b0);
    wait_state(ST_QUIESCE, 40, "draining");
    ref_cycles(20);
    check(seq_state == ST_QUIESCE, "draining");
    @(negedge clk_core_o); wdog_req_set[0] = 1'b1; @(negedge clk_core_o); wdog_req_set[0] = 1'b0;
    wait (!fab_rst_no);
    dma_hang = 1'b0;
    wait_run(20000, "after escalation");
    rb_rd(R_STATUS, q);
    check(!q[14], "escalated reset must not be reported as a drain timeout");
    expect_cause((16'd1 << CAUSE_SW_SYS) | (16'd1 << CAUSE_EXT_WDOG), "SW_SYS then EXT_WDOG");
    // (d) clock loss and watchdog expiry together
    wdog_cfg(32'd30, 1'b1, 1'b0, 1'b1);
    ref_cycles(58);
    core_run = 1'b0;
    ref_cycles(WIN * 4);
    check(!fab_rst_no, "clock loss asserts the resets");
    core_run = 1'b1;
    wait_run(20000, "after clock loss + watchdog");
    expect_cause(16'd1 << CAUSE_CLK_LOSS, "CLK_LOSS");
    // (e) external reset while the core clock is lost
    core_run = 1'b0;
    wait_state(ST_WAIT_CLK, WIN * 10, "clock lost");
    ext_rst_n = 1'b0; ref_cycles(3); ext_rst_n = 1'b1;
    ref_cycles(50);
    check(seq_state == ST_WAIT_CLK, "still waiting for the clock after the external reset");
    core_run = 1'b1;
    wait_run(20000, "after ext reset during clock loss");
    expect_cause((16'd1 << CAUSE_CLK_LOSS) | (16'd1 << CAUSE_EXT), "CLK_LOSS|EXT");
    // (f) POR while the external reset is held: one boot, cause POR only
    ext_rst_n = 1'b0;
    ref_cycles(5);
    por_n = 1'b0; ref_cycles(3); por_n = 1'b1;
    ref_cycles(5);
    ext_rst_n = 1'b1;
    wait_run(20000, "after POR inside external reset");
    expect_cause(16'h0001, "POR only", 1'b1);
    rb_rd(R_RST_INFO, q);
    check(q[15:0] == 16'd0, "reset count restarts at POR");
    check_functional("simultaneous causes");
  endtask

  task automatic t_clk_en();
    logic [31:0] q;
    int e0, e1, sem_err;
    power_on(300.0);
    wait_run(20000, "after POR");
    // simulation-semantics chain (branch 0 ungated)
    sem_err = 0;
    repeat (50) begin
      @(posedge clk_core_o); #0.1;
      if (sem_c != sem_a - 8'd2) sem_err++;
    end
    check(sem_err == 0, $sformatf("gated-clock sampling semantics broken (%0d mismatches)", sem_err));
    // gate branch 0 while idle
    rb_wr(R_CLK_EN, 32'b10);
    repeat (5) @(posedge clk_core_o);
    e0 = cm_edges[0]; e1 = cm_edges[1];
    repeat (60) @(posedge clk_core_o);
    check(cm_edges[0] == e0, "gated idle branch 0 must not receive edges");
    check(cm_edges[1] > e1 + 50, "branch 1 keeps running");
    rb_rd(R_CLK_STAT, q);
    check(q[1:0] == 2'b10, $sformatf("CLK_STAT en 0x%0h", q[1:0]));
    // a job wakes the gated branch and keeps it running until done
    cm_run(0, 8'd60);
    repeat (6) @(posedge clk_core_o);
    e0 = cm_edges[0];
    repeat (40) @(posedge clk_core_o);
    check(cm_edges[0] == e0, "branch 0 gated again after its job");
    // software cannot stop a busy branch (interlock)
    cm_launch(1, 8'd120);
    rb_wr(R_CLK_EN, 32'b00);
    cm_wait(1, 8'd120);
    repeat (6) @(posedge clk_core_o);
    e1 = cm_edges[1];
    repeat (40) @(posedge clk_core_o);
    check(cm_edges[1] == e1, "branch 1 gated after its job");
    // reset of gated-off branches: the sequencer forces their clocks on
    swrst(SCOPE_ACC, 8'b11, 1'b0);
    wait (br_rst_no == '0);
    wait_run(20000, "ACC reset of gated branches");
    repeat (8) @(posedge clk_core_o);
    e0 = cm_edges[0];
    repeat (40) @(posedge clk_core_o);
    check(cm_edges[0] == e0, "force released: branch 0 gated again");
    // random enable / job storm: glitch checkers watch every edge
    for (int i = 0; i < 120; i++) begin
      int b;
      b = $urandom_range(0, NB - 1);
      case ($urandom_range(0, 3))
        0, 1: rb_wr(R_CLK_EN, 32'($urandom_range(0, 3)));
        2:    cm_run(b, 8'($urandom_range(1, 20)));
        3:    repeat ($urandom_range(1, 9)) @(posedge clk_core_o);
      endcase
    end
    // scan clock enable forces the gates on
    rb_wr(R_CLK_EN, 32'b00);
    repeat (10) @(posedge clk_core_o);
    e0 = cm_edges[0];
    test_en = 1'b1;
    repeat (20) @(posedge clk_core_o);
    check(cm_edges[0] > e0 + 15, "test_en forces the gated clock on");
    test_en = 1'b0;
    rb_wr(R_CLK_EN, 32'b11);
    check_functional("clock-enable storm");
  endtask

  task automatic t_clk_loss();
    logic [31:0] q;
    int n0, a0;
    power_on(300.0);
    wait_run(20000, "after POR");
    if (MC_EN) wait (mc_ready);
    // core clock stops in RUN with work in flight
    dma_run(8'd33, 8'd200, 1'b0);
    cm_launch(0, 8'd200);
    core_run = 1'b0;
    ref_cycles(WIN * 3 + 10);
    check(!fab_rst_no && !cc_rst_no && br_rst_no == '0, "resets asserted with the core clock stopped (asynchronous assertion)");
    check(!clk_core_g, "clock is stopped");
    check(seq_state == ST_WAIT_CLK || seq_state == ST_CLK_LOST, "waiting for the clock to return");
    if (MC_EN) check(!mc_rst_no, "memory controller reset with the fabric");
    ref_cycles(200);
    core_run = 1'b1;
    wait_run(20000, "after core clock returns");
    expect_cause(16'd1 << CAUSE_CLK_LOSS, "CLK_LOSS");
    check_functional("core clock loss");
    // PLL lock lost while the clock keeps running: root gate closes
    pll_lock = 1'b0;
    wait (!fab_rst_no);
    ref_cycles(6);
    n0 = u_cc_root.rises;
    ref_cycles(80);
    check(u_cc_root.rises == n0, "clk_core_o must stay off while the PLL is unlocked");
    pll_lock = 1'b1;
    wait_run(20000, "after relock");
    expect_cause(16'd1 << CAUSE_PLL_LOSS, "PLL_LOSS");
    check_functional("PLL lock loss");
    // frequency excursion while locked
    core_half = CORE_H * 3.0;
    wait (!fab_rst_no);
    core_half = CORE_H;
    wait_run(20000, "after frequency excursion");
    check_functional("frequency excursion");
    // memory-controller clock loss: only that domain
    if (MC_EN) begin
      wait (mc_ready);
      a0 = u_rc_fab.asserts;
      mc_run = 1'b0;
      wait (!mc_rst_no);
      ref_cycles(WIN * 2);
      check(fab_rst_no && cc_rst_no && sys_ready, "core domains unaffected by mc clock loss");
      wait (!mc_ready);
      mc_run = 1'b1;
      wait (mc_ready);
      check(u_rc_fab.asserts == a0, "fabric not reset by mc clock loss");
      expect_cause(16'd1 << CAUSE_MC_CLK_LOSS, "MC_CLK_LOSS");
      check_functional("mc clock loss");
    end
  endtask

  task automatic t_dma_reset();
    logic [31:0] q;
    int kind;
    power_on(300.0);
    wait_run(20000, "after POR");
    for (int it = 0; it < 18; it++) begin
      logic [7:0] s;
      s = 8'(100 + it);
      dma_run(s, 8'($urandom_range(60, 200)), 1'b0);
      cm_launch(0, 8'($urandom_range(60, 200)));
      cm_launch(1, 8'($urandom_range(60, 200)));
      repeat ($urandom_range(1, 50)) @(posedge clk_core_o);
      kind = it % 6;
      case (kind)
        0: begin ext_rst_n = 1'b0; #($urandom_range(1, 30) * 1.0); ext_rst_n = 1'b1; end
        1: begin swrst(SCOPE_SYS, 8'h00, 1'b1); wait (!fab_rst_no); end
        2: begin swrst(SCOPE_CC, 8'h00, 1'b1);  wait (!cc_rst_no); end
        3: begin swrst(SCOPE_ACC, 8'h00, 1'b1); wait (br_rst_no != '1); end
        4: begin @(negedge clk_core_o); wdog_req_set[1] = 1'b1; @(negedge clk_core_o); wdog_req_set[1] = 1'b0;
                 wait (!fab_rst_no); end
        5: begin core_run = 1'b0; ref_cycles(WIN * 3 + 5); core_run = 1'b1; end
      endcase
      check(br_rst_no != '1 || !cc_rst_no || !fab_rst_no || kind == 0, "the injected reset took effect");
      wait_run(30000, $sformatf("after reset kind %0d", kind));
      if (kind == 2 || kind == 3) begin
        // fabric untouched: the transfer must still complete correctly
        if (dma_busy) begin wait (dma_done); check(dma_done_seed == s && !dma_err, "DMA survives a CC/ACC reset"); end
      end else begin
        check(!dma_busy, "no DMA transfer survives a reset of the fabric");
      end
      check_functional($sformatf("reset kind %0d during DMA/compute", kind));
    end
  endtask

  task automatic t_cdc();
    logic [31:0] q, prev_cnt;
    int a0;
    power_on(300.0);
    wait_run(20000, "after POR");
    wdog_cfg(WD_CDC, 1'b1, 1'b0, 1'b1);
    wait_snap(3);
    prev_cnt = 32'hFFFF_FFFF;
    a0 = fab_asserts;
    for (int i = 0; i < 400; i++) begin
      case ($urandom_range(0, 7))
        0: begin
             rb_rd(R_WDOG_CNT, q);
             check(q <= WD_CDC, $sformatf("WDOG_CNT %0d above load (incoherent snapshot)", q));
             check(q <= prev_cnt, $sformatf("WDOG_CNT went up without service: %0d -> %0d", prev_cnt, q));
             prev_cnt = q;
           end
        1: begin
             rb_wr(R_WDOG_KICK, WDOG_KICK_KEY);
             prev_cnt = 32'hFFFF_FFFF;
             wait_snap(3);
           end
        2: begin
             rb_rd(R_CLK_MEAS, q);
             check(q[15:0] >= CORE_MIN && q[15:0] <= CORE_MAX, $sformatf("CLK_MEAS core %0d", q[15:0]));
           end
        3: begin
             rb_rd(R_STATUS, q);
             check(q[3:0] == ST_RUN && q[8] && q[7], $sformatf("STATUS 0x%08h", q));
           end
        4: rb_wr(R_CLK_EN, 32'($urandom_range(0, 3)));
        5: rb_wr_retry(R_CAUSE, 32'h0);
        6: cm_run($urandom_range(0, 1), 8'($urandom_range(1, 12)));
        7: begin
             swrst(SCOPE_ACC, 8'($urandom_range(1, 3)), $urandom_range(0, 1));
             wait (br_rst_no != '1);
             wait_run(20000, "ACC reset in CDC stress");
             prev_cnt = 32'hFFFF_FFFF;
           end
      endcase
    end
    check(fab_asserts == a0, "no unexpected system reset during the CDC stress");
    rb_wr(R_CLK_EN, 32'b11);
    check_functional("CDC stress");
  endtask

  task automatic t_test_mode();
    power_on(300.0);
    wait_run(20000, "after POR");
    test_mode = 1'b1; test_rst_n = 1'b0;
    #1;
    check(!fab_rst_no && !cc_rst_no && br_rst_no == '0, "test mode: resets follow test_rst_ni (0)");
    test_rst_n = 1'b1;
    #1;
    check(fab_rst_no && cc_rst_no && br_rst_no == '1, "test mode: resets follow test_rst_ni (1)");
    if (MC_EN) check(mc_rst_no, "test mode: mc reset follows test_rst_ni");
    test_en = 1'b1;
    repeat (20) @(posedge clk_core);
    check(u_cc_root.rises > 0, "test_en drives the root clock");
    test_mode = 1'b0; test_en = 1'b0;
    // leaving test mode: a POR restores functional control
    por_n = 1'b0; #50; por_n = 1'b1;
    wait_run(20000, "after leaving test mode");
    check_functional("test mode exit");
  endtask

  // ================================================================== main
  initial begin
    int seed;
    if (!$value$plusargs("TEST=%s", test_name)) test_name = "por";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    $display("TB start: test=%s seed=%0d MC_EN=%0d ref_half=%0.2f core_half=%0.2f mc_half=%0.2f window=[%0d,%0d]",
             test_name, seed, MC_EN, REF_H, CORE_H, MC_H, CORE_MIN, CORE_MAX);
    void'($urandom(seed));
    // (if-chain: Icarus 12 cannot `case` on a string)
    if      (test_name == "por")       t_por();
    else if (test_name == "clk_start") t_clk_start();
    else if (test_name == "ext_rst")   t_ext_rst();
    else if (test_name == "wdog")      t_wdog();
    else if (test_name == "ext_wdog")  t_ext_wdog();
    else if (test_name == "sw_reset")  t_sw_reset();
    else if (test_name == "simul")     t_simul();
    else if (test_name == "clk_en")    t_clk_en();
    else if (test_name == "clk_loss")  t_clk_loss();
    else if (test_name == "dma_reset") t_dma_reset();
    else if (test_name == "cdc")       t_cdc();
    else if (test_name == "test_mode") t_test_mode();
    else                               fail($sformatf("unknown test %s", test_name));
    ref_cycles(20);
    errors += u_cc_root.errors + u_cc_b0.errors + u_cc_b1.errors;
    errors += u_rc_fab.errors + u_rc_cc.errors + u_rc_b0.errors + u_rc_b1.errors + u_rc_mc.errors;
    $display("TEST %s RESULT %s checks=%0d errors=%0d glitch_checked_edges=%0d/%0d/%0d releases fab=%0d cc=%0d b0=%0d b1=%0d mc=%0d sim_ns=%0t",
             test_name, (errors == 0) ? "PASS" : "FAIL", checks, errors,
             u_cc_root.rises, u_cc_b0.rises, u_cc_b1.rises,
             u_rc_fab.releases, u_rc_cc.releases, u_rc_b0.releases, u_rc_b1.releases, u_rc_mc.releases, $realtime);
    $finish;
  end

  initial begin
    #(20_000_000);
    $display("TEST %s RESULT FAIL (global timeout)", test_name);
    $finish;
  end
endmodule

`default_nettype wire
