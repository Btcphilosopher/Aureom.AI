// =============================================================================
// SilicaFlux CLOCKTREE :: testbench models and checkers (SIMULATION ONLY)
//   tb_dma_model      fabric-domain DMA engine (clk_core_o, fab_rst_no):
//                     copies a seeded pattern, checks it, honours quiesce
//   tb_compute_model  accelerator branch (clk_br_o[b], br_rst_no[b]): sums
//                     n..1, raises clk_req while busy, counts its own edges
//   tb_clk_check      glitch checker: every high / low phase of a gated
//                     clock is at least the source clock's phase
//   tb_rel_check      a reset output may only RELEASE on its clock's edge
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_dma_model (
  input  wire logic       clk,
  input  wire logic       rst_n,
  input  wire logic       start,
  input  wire logic [7:0] len,
  input  wire logic [7:0] seed,
  input  wire logic       quiesce,
  input  wire logic       hang,
  output logic            busy,
  output logic            done,          // one-cycle pulse
  output logic [7:0]      done_seed,
  output logic            err,           // sticky: a copied word was wrong
  output logic            accepted       // one-cycle pulse: start taken
);
  logic [7:0] dst [256];
  logic [7:0] idx, cur_len, cur_seed;
  logic       chk;

  function automatic logic [7:0] pat(input logic [7:0] s, input logic [7:0] i);
    pat = s * 8'd7 + i * 8'd13 + 8'h5A;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy      <= 1'b0;
      done      <= 1'b0;
      done_seed <= '0;
      err       <= 1'b0;
      idx       <= '0;
      cur_len   <= '0;
      cur_seed  <= '0;
      chk       <= 1'b0;
      accepted  <= 1'b0;
    end else begin
      done     <= 1'b0;
      accepted <= 1'b0;
      if (chk) begin
        chk  <= 1'b0;
        busy <= 1'b0;
        for (int i = 0; i < 256; i++)
          if (i < cur_len && dst[i] !== pat(cur_seed, i[7:0])) err <= 1'b1;
        done      <= 1'b1;
        done_seed <= cur_seed;
      end else if (!busy) begin
        if (start && !quiesce) begin
          busy     <= 1'b1;
          idx      <= '0;
          cur_len  <= len;
          cur_seed <= seed;
          accepted <= 1'b1;
        end
      end else if (!hang && !chk) begin
        dst[idx] <= pat(cur_seed, idx);
        if (idx == cur_len - 8'd1) chk <= 1'b1;   // busy stays 1 through the check cycle
        idx <= idx + 8'd1;
      end
    end
  end
endmodule

module tb_compute_model (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        start,
  input  wire logic [7:0]  n,
  input  wire logic        quiesce,
  output logic             clk_req,       // registered "busy" request
  output logic             idle,
  output logic             done,
  output logic [15:0]      result,
  output logic [31:0]      edges          // edges of this branch clock since reset
);
  logic [7:0]  k;
  logic [15:0] acc;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      clk_req <= 1'b0;
      done    <= 1'b0;
      result  <= '0;
      k       <= '0;
      acc     <= '0;
      edges   <= '0;
    end else begin
      edges <= edges + 32'd1;
      done  <= 1'b0;
      if (!clk_req) begin
        if (start && !quiesce && n != 0) begin
          clk_req <= 1'b1;
          k       <= n;
          acc     <= '0;
        end
      end else begin
        acc <= acc + {8'd0, k};
        k   <= k - 8'd1;
        if (k == 8'd1) begin
          clk_req <= 1'b0;
          result  <= acc + {8'd0, k};
          done    <= 1'b1;
        end
      end
    end
  end
  assign idle = !clk_req;
endmodule

// A gated clock is glitch-free iff every one of its edges coincides with a
// source edge of the same polarity (zero-delay simulation): a truncated high
// phase would fall while the source is still high, a runt would rise without
// a source rising edge.  Frequency-independent.
module tb_clk_check #(
  parameter string NAME = "clk"
) (
  input wire logic src,
  input wire logic gclk,
  input wire logic en
);
  realtime t_src_rise, t_src_fall;
  int      errors, rises;
  initial begin
    errors     = 0;
    rises      = 0;
    t_src_rise = -1.0;
    t_src_fall = -1.0;
  end
  always @(posedge src) t_src_rise = $realtime;
  always @(negedge src) t_src_fall = $realtime;
  // compare 1 ps after the edge, when every same-timestep event has executed
  // (independent of the simulator's ordering of derived-clock processes)
  always @(posedge gclk) begin
    realtime t;
    rises++;
    t = $realtime;
    #0.001;
    if (en && t != t_src_rise) begin
      errors++;
      $display("ERROR %0t %s: rising edge without a source rising edge (runt)", t, NAME);
    end
  end
  always @(negedge gclk) begin
    realtime t;
    t = $realtime;
    #0.001;
    if (en && t != t_src_fall) begin
      errors++;
      $display("ERROR %0t %s: falling edge without a source falling edge (truncated pulse)", t, NAME);
    end
  end
endmodule

module tb_rel_check #(
  parameter string NAME = "rst"
) (
  input wire logic clk,
  input wire logic rst_n,
  input wire logic en
);
  realtime t_edge;
  int      errors, releases, asserts;
  initial begin
    errors   = 0;
    releases = 0;
    asserts  = 0;
    t_edge   = -1.0;
  end
  always @(posedge clk) t_edge = $realtime;
  always @(posedge rst_n) begin
    if (en) begin
      releases++;
      if ($realtime != t_edge) begin
        errors++;
        $display("ERROR %0t %s: reset released %0.3f ns after the last clock edge (not synchronous)",
                 $realtime, NAME, $realtime - t_edge);
      end
    end
  end
  always @(negedge rst_n) if (en) asserts++;
endmodule

`default_nettype wire
