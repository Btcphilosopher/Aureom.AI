// =============================================================================
// SilicaFlux CLOCKTREE :: tb_cdc_lib -- CDC adapter unit tests (SIMULATION ONLY)
//
// Two free-running asynchronous clocks (periods from SRC_HALF / DST_HALF, with
// a random phase), every CDC adapter in both directions where meaningful:
//   status    sf_crt_sync (independent bits) and the Gray clock monitor
//   commands  sf_crt_pulse_sync (loss-free, coalescing) / sf_crt_handshake
//   wide data sf_crt_handshake (64-bit payloads, scoreboard)
//   DMA reqs  sf_crt_async_fifo (random valid/ready, scoreboard, full/empty)
//   reset     sf_crt_rst_sync (async assert with the clock stopped, release
//             after exactly STAGES edges); paired-reset of every channel in
//             the middle of traffic (no stale item may be delivered)
//   interrupt sf_crt_irq_sync EDGE_MODE=1 (event -> sticky, W1C)
// Build with +define+SF_CRT_CDC_RANDOM for the metastability-delay model.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

`ifndef SRC_HALF
`define SRC_HALF 3.5
`endif
`ifndef DST_HALF
`define DST_HALF 10.0
`endif

module tb_cdc_lib;
  localparam real SH = `SRC_HALF;
  localparam real DH = `DST_HALF;

  logic sclk = 1'b0, dclk = 1'b0;
  bit   sclk_run = 1'b1;
  initial begin
    #($urandom_range(0, 100) * 0.037);
    forever #(SH) if (sclk_run || sclk) sclk = ~sclk;
  end
  always #(DH) dclk = ~dclk;

  int errors = 0, checks = 0;
  task automatic check(input bit c, input string m);
    checks++;
    if (!c) begin errors++; $display("ERROR %0t %s", $realtime, m); end
  endtask

  // paired channel reset (asserted together, released independently)
  logic arst_n = 1'b0, srst_n, drst_n;
  sf_crt_rst_sync u_rs_s (.clk_i(sclk), .arst_ni(arst_n), .test_mode_i(1'b0), .test_rst_ni(1'b0), .rst_no(srst_n));
  sf_crt_rst_sync u_rs_d (.clk_i(dclk), .arst_ni(arst_n), .test_mode_i(1'b0), .test_rst_ni(1'b0), .rst_no(drst_n));

  // ------------------------------------------------------------ handshake (wide data)
  logic        hs_v, hs_rdy, hs_dv;
  logic [63:0] hs_d, hs_dd;
  sf_crt_handshake #(.WIDTH(64)) u_hs (
    .src_clk_i(sclk), .src_rst_ni(srst_n), .src_valid_i(hs_v), .src_ready_o(hs_rdy), .src_data_i(hs_d),
    .dst_clk_i(dclk), .dst_rst_ni(drst_n), .dst_valid_o(hs_dv), .dst_data_o(hs_dd));
  logic [63:0] hs_q [$];
  int          hs_sent = 0, hs_got = 0;
  always @(posedge sclk) if (srst_n && hs_v && hs_rdy) begin hs_q.push_back(hs_d); hs_sent++; end
  always @(posedge dclk) begin
    if (drst_n && hs_dv) begin
      hs_got++;
      if (hs_q.size() == 0) check(1'b0, "handshake delivered an item that was never sent");
      else begin
        logic [63:0] e;
        e = hs_q.pop_front();
        check(hs_dd == e, $sformatf("handshake data %h, expected %h", hs_dd, e));
      end
    end
  end

  // ------------------------------------------------------------ pulse sync (commands)
  logic ps_p, ps_busy, ps_dp;
  sf_crt_pulse_sync u_ps (
    .src_clk_i(sclk), .src_rst_ni(srst_n), .src_pulse_i(ps_p), .src_busy_o(ps_busy),
    .dst_clk_i(dclk), .dst_rst_ni(drst_n), .dst_pulse_o(ps_dp));
  int ps_sent = 0, ps_got = 0;
  realtime t_ps_src = 0.0, t_ps_dst = 0.0;
  always @(posedge sclk) if (srst_n && ps_p) begin ps_sent++; t_ps_src = $realtime; end
  always @(posedge dclk) if (drst_n && ps_dp) begin ps_got++; t_ps_dst = $realtime; end

  // ------------------------------------------------------------ async FIFO (DMA requests)
  logic        f_wv, f_wr, f_rv, f_rr;
  logic [39:0] f_wd, f_rd;
  sf_crt_async_fifo #(.WIDTH(40), .DEPTH(8)) u_fifo (
    .wclk_i(sclk), .wrst_ni(srst_n), .w_valid_i(f_wv), .w_ready_o(f_wr), .w_data_i(f_wd),
    .rclk_i(dclk), .rrst_ni(drst_n), .r_valid_o(f_rv), .r_ready_i(f_rr), .r_data_o(f_rd));
  logic [39:0] f_q [$];
  int          f_in = 0, f_out = 0;
  always @(posedge sclk) if (srst_n && f_wv && f_wr) begin f_q.push_back(f_wd); f_in++; end
  always @(posedge dclk) begin
    if (drst_n && f_rv && f_rr) begin
      f_out++;
      if (f_q.size() == 0) check(1'b0, "FIFO delivered a word that was never written");
      else begin
        logic [39:0] e;
        e = f_q.pop_front();
        check(f_rd == e, $sformatf("FIFO data %h, expected %h", f_rd, e));
      end
    end
  end

  // ------------------------------------------------------------ interrupt (event -> sticky)
  logic irq_ev, irq_clr, irq_s;
  sf_crt_irq_sync #(.EDGE_MODE(1'b1)) u_irq (
    .src_clk_i(sclk), .src_rst_ni(srst_n), .src_irq_i(irq_ev),
    .dst_clk_i(dclk), .dst_rst_ni(drst_n), .dst_clr_i(irq_clr), .dst_irq_o(irq_s));

  // ------------------------------------------------------------ status bits + Gray monitor
  logic [3:0] st_src, st_dst;
  sf_crt_sync #(.WIDTH(4)) u_st (.clk_i(dclk), .rst_ni(drst_n), .d_i(st_src), .q_o(st_dst));
  logic [7:0]  gray;
  logic        mon_ok;
  logic [15:0] mon_meas;
  sf_crt_clk_mon_src u_msrc (.clk_i(sclk), .rst_ni(srst_n), .gray_o(gray));
  sf_crt_clk_mon #(.WINDOW(16)) u_mon (.clk_ref_i(dclk), .rst_ni(drst_n), .gray_i(gray), .ok_o(mon_ok), .meas_o(mon_meas));

  // ------------------------------------------------------------ stimulus tasks
  task automatic traffic(input int n_items);
    fork
      begin : hs_src
        for (int i = 0; i < n_items; i++) begin
          @(negedge sclk);
          hs_d = {$urandom, $urandom}; hs_v = 1'b1;
          @(posedge sclk); while (!hs_rdy) @(posedge sclk);
          #0.01; @(negedge sclk); hs_v = 1'b0;
          repeat ($urandom_range(0, 3)) @(negedge sclk);
        end
      end
      begin : fifo_src
        for (int i = 0; i < 4 * n_items; i++) begin
          @(negedge sclk);
          f_wd = {$urandom, 8'(i)}; f_wv = ($urandom_range(0, 3) != 0);
          if (f_wv) begin @(posedge sclk); while (!f_wr) @(posedge sclk); #0.01; end
        end
        @(negedge sclk); f_wv = 1'b0;
      end
      begin : fifo_dst
        repeat (40 * n_items) begin @(negedge dclk); f_rr = ($urandom_range(0, 2) != 0); end
        f_rr = 1'b1;
      end
      begin : st_src_p
        repeat (20 * n_items) begin @(negedge sclk); if ($urandom_range(0, 15) == 0) st_src = 4'($urandom); end
      end
    join
  endtask

  initial begin
    int seed;
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    void'($urandom(seed));
    hs_v = 0; hs_d = 0; ps_p = 0; f_wv = 0; f_wd = 0; f_rr = 1; irq_ev = 0; irq_clr = 0; st_src = 0;
    $display("tb_cdc_lib: src_half=%0.3f dst_half=%0.3f", SH, DH);
    #(53.0); arst_n = 1'b1;
    repeat (5) @(posedge dclk);

    // ---------------- wide data / DMA FIFO / status traffic
    traffic(150);
    repeat (40) @(posedge dclk);
    check(hs_got == hs_sent && hs_q.size() == 0, $sformatf("handshake: sent %0d delivered %0d", hs_sent, hs_got));
    check(f_out == f_in && f_q.size() == 0, $sformatf("FIFO: written %0d read %0d", f_in, f_out));
    check(st_dst == st_src, "status bits settle to the source value");

    // ---------------- command pulses: spaced (loss-free) then bursts (coalesced, never lost)
    for (int i = 0; i < 60; i++) begin
      @(negedge sclk); ps_p = 1'b1; @(negedge sclk); ps_p = 1'b0;
      while (ps_busy) @(negedge sclk);
    end
    repeat (10) @(posedge dclk);
    check(ps_got == ps_sent, $sformatf("spaced pulses: sent %0d delivered %0d", ps_sent, ps_got));
    begin
      int g0, s0, coalesced;
      coalesced = 0;
      for (int burst = 0; burst < 20; burst++) begin
        g0 = ps_got; s0 = ps_sent;
        repeat ($urandom_range(2, 6)) begin @(negedge sclk); ps_p = 1'b1; @(negedge sclk); ps_p = 1'b0; end
        while (ps_busy) @(negedge sclk);
        repeat (6) @(posedge dclk);
        check(ps_got > g0, "a burst of pulses must deliver at least one pulse");
        check(ps_got - g0 <= ps_sent - s0, "never more deliveries than pulses");
        check(t_ps_dst > t_ps_src, "the last pulse of a burst is always delivered (never lost)");
        if (ps_got - g0 < ps_sent - s0) coalesced++;
      end
      $display("pulse bursts: %0d of 20 coalesced", coalesced);
    end

    // ---------------- interrupts: event -> sticky, W1C, no event lost after a clear
    for (int i = 0; i < 30; i++) begin
      @(negedge sclk); irq_ev = 1'b1; @(negedge sclk); irq_ev = 1'b0;
      repeat (12) @(posedge dclk);
      check(irq_s, "interrupt event reached the destination");
      @(negedge dclk); irq_clr = 1'b1; @(negedge dclk); irq_clr = 1'b0;
      repeat (2) @(posedge dclk);
      check(!irq_s, "W1C clears the sticky interrupt");
    end

    // ---------------- clock monitor accuracy (16-window, expected count = 16*DH/SH)
    repeat (16 * 4) @(posedge dclk);
    begin
      real exp_cnt;
      int  tol;
      int  drops;
      exp_cnt = 16.0 * DH / SH;
      check(mon_ok, "monitor sees the running clock");
      // OK must persist indefinitely on a good clock (saturating-counter regression)
      drops = 0;
      repeat (16 * 24) begin
        @(posedge dclk);
        if (!mon_ok) drops++;
      end
      check(drops == 0, $sformatf("monitor OK dropped for %0d cycles on a running clock (24 windows)", drops));
      // each window boundary is uncertain by one reference cycle (two with the
      // metastability model): +-2*(f_src/f_dst) edges, +2 for rounding
      tol = 2 + $rtoi(2.0 * DH / SH);
      check(mon_meas >= $rtoi(exp_cnt) - tol && mon_meas <= $rtoi(exp_cnt) + tol,
            $sformatf("monitor count %0d, expected %0.1f +- %0d", mon_meas, exp_cnt, tol));
      // stop the monitored clock: count falls to 0 within two windows
      sclk_run = 1'b0;
      repeat (16 * 2 + 4) @(posedge dclk);
      check(!mon_ok && mon_meas == 0, $sformatf("stopped clock: ok=%0d count=%0d", mon_ok, mon_meas));
    end

    // ---------------- reset synchroniser: async assertion with the clock stopped,
    //                  release after STAGES edges once it runs again
    arst_n = 1'b0;
    #0.01;
    check(!srst_n, "reset asserted asynchronously while the source clock is stopped");
    #(20.0);
    arst_n = 1'b1;
    #(20.0);
    check(!srst_n, "no release without clock edges");
    sclk_run = 1'b1;
    @(posedge sclk); #0.01; check(!srst_n, "not released after one edge");
    @(posedge sclk); #0.01; check(srst_n, "released after exactly two edges");

    // ---------------- paired reset in the middle of traffic: nothing stale survives
    fork
      traffic(40);
      begin
        repeat ($urandom_range(50, 200)) @(posedge sclk);
        arst_n = 1'b0;
        #0.001;                               // after every same-timestep push / pop
        hs_q.delete(); f_q.delete();          // everything in flight is dropped by design
        #(30.0);
        arst_n = 1'b1;
      end
    join
    repeat (60) @(posedge dclk);
    check(hs_q.size() == 0 && f_q.size() == 0, "after the paired reset every new item was delivered");

    $display("TEST cdc_lib RESULT %s checks=%0d errors=%0d hs=%0d fifo=%0d pulses=%0d",
             (errors == 0) ? "PASS" : "FAIL", checks, errors, hs_got, f_out, ps_got);
    $finish;
  end

  initial begin
    #(5_000_000);
    $display("TEST cdc_lib RESULT FAIL (timeout)");
    $finish;
  end
endmodule

`default_nettype wire
