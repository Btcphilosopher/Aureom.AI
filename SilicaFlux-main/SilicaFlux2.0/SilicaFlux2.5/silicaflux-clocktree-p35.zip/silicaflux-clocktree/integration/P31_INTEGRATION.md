# Integrating `silicaflux_clock_reset_tree` into DieTop (P31)

The controller replaces `rtl/subsys/clock_reset_subsystem.sv` and becomes the die's clock root. This
guide maps the ports. **Not done in this project**: P31 is unmodified and the integrated die has not
been simulated.

## 1. New die pins

| Pin | Why |
|---|---|
| `clk_ref_i` | Reference clock: the crystal that also feeds the PLL. **Required** (`docs/01_CLOCK_DOMAINS.md`) |
| `ext_rst_ni` | Board reset distinct from POR (or tie to `por_ni` if the board has only one) |
| `test_rst_ni`, `test_en_i` | Scan reset / scan clock enable. With no scan yet: `test_rst_ni = por_ni`, `test_en_i = test_mode_i`, which reproduces P31's `test_mode_i ? por_ni : …` bypass |

## 2. Port mapping

| `silicaflux_clock_reset_tree` | P31 net / block | Note |
|---|---|---|
| `clk_core_i` | `clk_i` (PLL output) | — |
| `clk_core_o` | **the die's `clk`** (every subsystem) | replaces `wire clk = clk_i` |
| `pll_lock_i`, `por_ni`, `test_mode_i` | same pins | — |
| `fab_rst_no` | `fab_rst_n` | NoC, SRAM, ExtMem bridge, DMA, DIE_REGS, gates, fences |
| `cc_rst_no` | `cc_rst_n` → ControlCore `rst_ni` | the ControlCore keeps its soft / watchdog / host resets and its PMU (accelerator gate + reset) |
| `sys_ready_o` | `reset_done` / `DIE_SYS.STATUS.RESET_DONE` | — |
| `rb_*` | a free DIE_REGS page | 14 registers, 0x00–0x34 |
| `wdog_req_i[0]` | RAS P26 `sfras_watchdog.reset_req` (registered sticky level, as required) | escalates a RAS stage-2 watchdog to a chip reset |
| `wdog_req_i[1]` | spare (tie 0), or the ControlCore watchdog request if policy says it must reset the whole chip | — |
| `wdog_irq_o` | `die_sysctrl` interrupt input | — |
| `fab_quiesce_o` / `fab_idle_i` | DMA + host-bridge "stop accepting" / idle (`dma_busy`, `host_busy`, NoC idle) | without it, graceful SYSTEM resets wait `QTIMEOUT` and then force |
| **branch b** (`clk_br_o[b]`, `br_rst_no[b]`, `br_clk_req_i[b]`, `br_wake_i[b]`, `br_idle_i[b]`, `br_quiesce_o[b]`) | **ComputeCluster P32**: `clk_req` → `br_clk_req_i`, `!busy` → `br_idle_i`, `cmd_valid \| csr_sel \| spm_req_valid \| rst_req` → `br_wake_i` (P32 docs/02 §6 contract) | P32 has no clock gate and expects an external one, which this is |
| `clk_mc_i`, `mc_rst_no`, `mc_ready_o` (MC_EN = 1) | `mc_clk_i`; controller reset = `mc_rst_no` **combined by an `sf_crt_rst_comb` cell** with the bridge's own `mc_rst_no` (both synchronous to `clk_mc`); `mc_ready_o` → `EXTMEM_READY` qualification | the data CDC stays P24's `extmem_mc_cdc` |

## 3. Accelerator clock with the existing ControlCore PMU

Option A, no third-party edit and recommended first: the vector / tensor clusters keep the ControlCore
PMU's ICG and `acc_rst_no`. The accelerator clock then has two ICG levels (root + PMU), which CTS balances
like the branch group (`docs/06_CTS.md`). The `die_sfb_dom_gate` clock-request protocol is unchanged.

Option B: build the ControlCore with `SFV_NO_CLOCK_GATE` and drive the clusters from `clk_br_o[0]`, with
`br_clk_req_i[0]` = PMU `acc_clk_en` (registered `clk_on_q`) and `br_wake_i[0]` = `die_sfb_dom_gate`
`dom_busy`. This requires re-verifying P31's `t_*` gating tests.

## 4. Re-verification required after integration

P31 regression (MIN / HPC / V2 / V3); a new `clk_ref`-based POR timing (`PLATFORM_CYC` moves by the
sequencer latency, about 1.4 µs at 50 MHz / 143 MHz); die SDC from `constraints/sdc/silicaflux_die_func_template.sdc`;
CDC check on the die netlist with `scripts/cdc_check.py` (P24 FIFOs: add waivers CDC-W01-style with
P24's evidence).
