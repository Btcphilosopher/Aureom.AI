// =============================================================================
// SilicaFlux TensorScratch :: ts_tc_system        REFERENCE INTEGRATION (synthesizable)
//
//   sf_tensor_scratchpad  --k-slices-->  TENSORCORE 02 tensor_systolic_array  --readout-->  TENSORCORE 04 tensor_accumulator
//          ^                                                                                         |
//          +----------- accumulator storage interface (st_*) <---------------------------------------+
//                       accumulator cmt_done / cmt_slot  -->  scratchpad slot ownership (complete)
//
//   Both tensor cores are the UNMODIFIED third_party copies.  What this wrapper adds is only the wiring the brief asks for:
//     * s_* (array operands) come from the scratchpad, tile_rsp_{m,n,k} are what the sequencer feeds to the array's cfg_{m,n,k}
//     * array readout m_* -> accumulator ps_*  (the sequencer supplies the {slot, tag, chunk, chunk_k} sideband for the launch)
//     * accumulator st_* <-> scratchpad accumulator buffer;  accumulator cmt_done/cmt_slot -> scratchpad acc_complete
//   The tile sequencer (what TENSORCORE 06 does) stays OUTSIDE: it drives the descriptor / cfg / sideband ports below.
//   readout_gate_i is a test hook that back-pressures the readout handshake (tie to 1 in a real system).
// Classification: SYNTHESIZABLE (instantiates the two third_party cores)
// =============================================================================
`timescale 1ns/1ps
`include "sf_ts_defs.svh"
`default_nettype none

module ts_tc_system #(
  parameter int          ARRAY_ROWS              = 4,
  parameter int          ARRAY_COLS              = 4,
  parameter int          TILE_K                  = 32,
  parameter int          OPERAND_WIDTH           = 8,
  parameter int          ACC_WIDTH               = 32,     // persistent accumulator lane width (32 / 40 / 48)
  parameter int          PSUM_WIDTH              = 32,     // array partial-sum width (>= 2*OPERAND_WIDTH)
  parameter int          A_BUFFER_BYTES          = 8192,
  parameter int          B_BUFFER_BYTES          = 8192,
  parameter int          ACC_BUFFER_BYTES        = 1024,
  parameter int          NUM_A_BANKS             = 4,
  parameter int          NUM_B_BANKS             = 2,
  parameter int          ENABLE_DOUBLE_BUFFERING = 1,
  parameter int          WORD_BYTES              = 4,
  parameter int          NUM_ACC_BANKS           = 4,
  parameter int          SET_MAP                 = 1,
  parameter int          READ_LATENCY            = 1,
  parameter int          A_STAGE                 = 4,
  parameter int          B_STAGE                 = 8,
  parameter int          WR_STARVE_LIMIT         = 8,
  parameter int          STREAM_CHAIN            = 1,
  parameter int          ACC_RD_LAT              = 1,
  parameter int          ACC_WQ_DEPTH            = 4,
  parameter int          ACC_EXT_STARVE_LIMIT    = 8,
  parameter int          ACC_AUTO_RELEASE        = 0,
  parameter int          CTXQ_DEPTH              = 2,
  parameter int          MUL_PIPE                = 0,
  parameter int          ADDR_W                  = 32,
  parameter logic [63:0] DMA_BASE                = 64'h0,
  parameter int          IDX_W                   = 16,
  parameter int          K_W                     = 17,
  parameter int          TAG_W                   = 8,
  parameter int          TT_W                    = 16,     // accumulator tile tag
  parameter int          CHUNK_W                 = 16,
  parameter int          KTOT_W                  = 40,
  // ---- derived (never set)
  parameter int          R         = ARRAY_ROWS,
  parameter int          C         = ARRAY_COLS,
  parameter int          OW        = OPERAND_WIDTH,
  parameter int          DW        = 8 * WORD_BYTES,
  parameter int          NSETS     = (ENABLE_DOUBLE_BUFFERING != 0) ? 2 : 1,
  parameter int          SETW      = (NSETS > 1) ? $clog2(NSETS) : 1,
  parameter int          RMW       = $clog2(ARRAY_ROWS + 1),
  parameter int          CNW       = $clog2(ARRAY_COLS + 1),
  parameter int          RIDW      = (ARRAY_ROWS > 1) ? $clog2(ARRAY_ROWS) : 1,
  parameter int          ACC_EW    = ARRAY_COLS * (ACC_WIDTH + 1),
  parameter int          NSLOT     = (ACC_BUFFER_BYTES / (ARRAY_ROWS * ((ACC_EW + 7) / 8)) < 1) ? 1 : ACC_BUFFER_BYTES / (ARRAY_ROWS * ((ACC_EW + 7) / 8)),
  parameter int          SLOT_W    = (NSLOT > 1) ? $clog2(NSLOT) : 1
) (
  input  wire logic                           clk,
  input  wire logic                           rst_n,
  // ---------------------------------------------------------- scratchpad: DMA fill, ownership, tile descriptors
  input  wire logic                           dma_req_valid,
  output logic                                dma_req_ready,
  input  wire logic                           dma_req_we,
  input  wire logic [ADDR_W-1:0]              dma_req_addr,
  input  wire logic [DW-1:0]                  dma_req_wdata,
  input  wire logic [WORD_BYTES-1:0]          dma_req_wstrb,
  input  wire logic [TAG_W-1:0]               dma_req_tag,
  output logic                                dma_rsp_valid,
  input  wire logic                           dma_rsp_ready,
  output logic      [DW-1:0]                  dma_rsp_rdata,
  output logic                                dma_rsp_err,
  output logic      [2:0]                     dma_rsp_err_code,
  output logic                                dma_rsp_we,
  output logic      [TAG_W-1:0]               dma_rsp_tag,
  input  wire logic                           fill_begin_valid,
  output logic                                fill_begin_ready,
  input  wire logic                           fill_end_valid,
  output logic                                fill_end_ready,
  input  wire logic                           cmp_begin_valid,
  output logic                                cmp_begin_ready,
  input  wire logic                           cmp_end_valid,
  output logic                                cmp_end_ready,
  output logic      [SETW-1:0]                fill_set,
  output logic      [SETW-1:0]                cmp_set,
  output logic      [NSETS*2-1:0]             set_state,
  input  wire logic                           tile_valid,
  output logic                                tile_ready,
  input  wire logic [ADDR_W-1:0]              tile_a_addr,
  input  wire logic [ADDR_W-1:0]              tile_lda,
  input  wire logic [ADDR_W-1:0]              tile_b_addr,
  input  wire logic [ADDR_W-1:0]              tile_ldb,
  input  wire logic [IDX_W-1:0]               tile_m0,
  input  wire logic [IDX_W-1:0]               tile_n0,
  input  wire logic [K_W-1:0]                 tile_k0,
  input  wire logic [IDX_W-1:0]               tile_mat_m,
  input  wire logic [IDX_W-1:0]               tile_mat_n,
  input  wire logic [K_W-1:0]                 tile_mat_k,
  input  wire logic [K_W-1:0]                 tile_k,
  input  wire logic [TAG_W-1:0]               tile_tag,
  output logic                                tile_rsp_valid,
  input  wire logic                           tile_rsp_ready,
  output logic      [TAG_W-1:0]               tile_rsp_tag,
  output logic                                tile_rsp_err,
  output logic      [3:0]                     tile_rsp_code,
  output logic      [RMW-1:0]                 tile_rsp_m,
  output logic      [CNW-1:0]                 tile_rsp_n,
  output logic      [K_W-1:0]                 tile_rsp_k,
  // ---------------------------------------------------------- observation taps of the operand stream (the array consumes it internally)
  output logic                                s_valid,
  output logic                                s_ready,
  output logic      [R*OW-1:0]                s_a,
  output logic      [C*OW-1:0]                s_b,
  output logic      [K_W-1:0]                 s_k,
  output logic      [K_W-1:0]                 s_kg,
  output logic      [IDX_W-1:0]               s_m0,
  output logic      [IDX_W-1:0]               s_n0,
  output logic      [R-1:0]                   s_row_mask,
  output logic      [C-1:0]                   s_col_mask,
  output logic                                s_first,
  output logic                                s_last,
  output logic      [TAG_W-1:0]               s_tag,
  output logic      [SETW-1:0]                s_set,
  // ---------------------------------------------------------- TENSORCORE 02 array control (driven by the tile sequencer)
  input  wire logic                           ar_cfg_valid,
  output logic                                ar_cfg_ready,
  input  wire logic [RMW-1:0]                 ar_cfg_m,
  input  wire logic [CNW-1:0]                 ar_cfg_n,
  input  wire logic [K_W-1:0]                 ar_cfg_k,
  output logic                                ar_cfg_reject,
  input  wire logic                           ar_stall,
  input  wire logic                           readout_gate_i,
  output logic                                ar_m_valid,
  output logic                                ar_m_ready,
  output logic                                ar_m_last,
  output logic                                ar_align_err,
  output logic      [K_W-1:0]                 ar_s_k,
  // ---------------------------------------------------------- TENSORCORE 04 accumulator control + outputs
  input  wire logic                           ac_cfg_valid,
  output logic                                ac_cfg_ready,
  input  wire logic [SLOT_W-1:0]              ac_cfg_slot,
  input  wire logic [TT_W-1:0]                ac_cfg_tag,
  input  wire logic [RMW-1:0]                 ac_cfg_m,
  input  wire logic [CNW-1:0]                 ac_cfg_n,
  input  wire logic [KTOT_W-1:0]              ac_cfg_ktot,
  input  wire logic [CHUNK_W-1:0]             ac_cfg_nch,
  output logic                                ac_cfg_reject,
  input  wire logic [SLOT_W-1:0]              ps_slot,
  input  wire logic [TT_W-1:0]                ps_tag,
  input  wire logic [CHUNK_W-1:0]             ps_chunk,
  input  wire logic [K_W-1:0]                 ps_chunk_k,
  output logic                                ac_o_valid,
  input  wire logic                           ac_o_ready,
  output logic      [TT_W-1:0]                ac_o_tag,
  output logic      [RIDW-1:0]                ac_o_row,
  output logic                                ac_o_last,
  output logic      [C-1:0]                   ac_o_col_mask,
  output logic      [C*ACC_WIDTH-1:0]         ac_o_wide,
  output logic      [C-1:0]                   ac_o_ovf,
  output logic                                cmt_done,
  output logic      [SLOT_W-1:0]              cmt_slot,
  output logic      [TT_W-1:0]                cmt_tag,
  output logic                                ac_idle,
  output logic      [7:0]                     ac_err_sticky,
  // ---------------------------------------------------------- scratchpad accumulator buffer: slot ownership + external port
  input  wire logic                           acc_claim_valid,
  output logic                                acc_claim_ready,
  input  wire logic [SLOT_W-1:0]              acc_claim_slot,
  input  wire logic                           acc_release_valid,
  input  wire logic [SLOT_W-1:0]              acc_release_slot,
  output logic      [NSLOT*2-1:0]             acc_slot_state,
  input  wire logic                           ext_req_valid,
  output logic                                ext_req_ready,
  input  wire logic                           ext_req_we,
  input  wire logic [SLOT_W-1:0]              ext_req_slot,
  input  wire logic [RIDW-1:0]                ext_req_row,
  input  wire logic [ACC_EW-1:0]              ext_req_wdata,
  output logic                                ext_rsp_valid,
  input  wire logic                           ext_rsp_ready,
  output logic      [ACC_EW-1:0]              ext_rsp_rdata,
  output logic                                ext_rsp_we,
  output logic                                ext_rsp_err,
  output logic      [2:0]                     ext_rsp_code,
  output logic      [3:0]                     acc_viol_sticky,
  // ---------------------------------------------------------- status / performance
  output logic                                busy,
  output logic                                engine_idle,
  output logic      [`TS_NUM_EV*8-1:0]        ev_inc,
  input  wire logic                           perf_clear,
  output logic      [`TS_NUM_EV*32-1:0]       perf_cnt
);
  // ------------------------------------------------------------ the scratchpad
  logic                 st_en, st_rd_req, st_wr_req, st_rd_ready, st_wr_ready;
  logic [$clog2(NSLOT * ARRAY_ROWS) + (NSLOT * ARRAY_ROWS == 1 ? 1 : 0) - 1:0] st_rd_addr, st_wr_addr;
  logic [ACC_EW-1:0]    st_rd_data, st_wr_data;
  logic                 s_ready_i;

  sf_tensor_scratchpad #(.ARRAY_ROWS(R), .ARRAY_COLS(C), .TILE_K(TILE_K), .OPERAND_WIDTH(OW), .ACC_WIDTH(ACC_WIDTH), .A_BUFFER_BYTES(A_BUFFER_BYTES),
      .B_BUFFER_BYTES(B_BUFFER_BYTES), .ACC_BUFFER_BYTES(ACC_BUFFER_BYTES), .NUM_A_BANKS(NUM_A_BANKS), .NUM_B_BANKS(NUM_B_BANKS),
      .ENABLE_DOUBLE_BUFFERING(ENABLE_DOUBLE_BUFFERING), .WORD_BYTES(WORD_BYTES), .NUM_ACC_BANKS(NUM_ACC_BANKS), .SET_MAP(SET_MAP),
      .READ_LATENCY(READ_LATENCY), .A_STAGE(A_STAGE), .B_STAGE(B_STAGE), .WR_STARVE_LIMIT(WR_STARVE_LIMIT), .STREAM_CHAIN(STREAM_CHAIN),
      .ACC_RD_LAT(ACC_RD_LAT), .ACC_WQ_DEPTH(ACC_WQ_DEPTH), .ACC_EXT_STARVE_LIMIT(ACC_EXT_STARVE_LIMIT), .ACC_AUTO_RELEASE(ACC_AUTO_RELEASE),
      .CTXQ_DEPTH(CTXQ_DEPTH), .ADDR_W(ADDR_W), .DMA_BASE(DMA_BASE), .IDX_W(IDX_W), .K_W(K_W), .TAG_W(TAG_W)) u_sp (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(dma_req_we), .dma_req_addr(dma_req_addr), .dma_req_wdata(dma_req_wdata),
    .dma_req_wstrb(dma_req_wstrb), .dma_req_tag(dma_req_tag), .dma_rsp_valid(dma_rsp_valid), .dma_rsp_ready(dma_rsp_ready), .dma_rsp_rdata(dma_rsp_rdata),
    .dma_rsp_err(dma_rsp_err), .dma_rsp_err_code(dma_rsp_err_code), .dma_rsp_we(dma_rsp_we), .dma_rsp_tag(dma_rsp_tag),
    .fill_begin_valid(fill_begin_valid), .fill_begin_ready(fill_begin_ready), .fill_end_valid(fill_end_valid), .fill_end_ready(fill_end_ready),
    .cmp_begin_valid(cmp_begin_valid), .cmp_begin_ready(cmp_begin_ready), .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cmp_end_ready),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(set_state),
    .tile_valid(tile_valid), .tile_ready(tile_ready), .tile_a_addr(tile_a_addr), .tile_lda(tile_lda), .tile_b_addr(tile_b_addr), .tile_ldb(tile_ldb),
    .tile_m0(tile_m0), .tile_n0(tile_n0), .tile_k0(tile_k0), .tile_mat_m(tile_mat_m), .tile_mat_n(tile_mat_n), .tile_mat_k(tile_mat_k), .tile_k(tile_k),
    .tile_tag(tile_tag), .tile_rsp_valid(tile_rsp_valid), .tile_rsp_ready(tile_rsp_ready), .tile_rsp_tag(tile_rsp_tag), .tile_rsp_err(tile_rsp_err),
    .tile_rsp_code(tile_rsp_code), .tile_rsp_m(tile_rsp_m), .tile_rsp_n(tile_rsp_n), .tile_rsp_k(tile_rsp_k),
    .s_valid(s_valid), .s_ready(s_ready_i), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0), .s_row_mask(s_row_mask),
    .s_col_mask(s_col_mask), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .acc_st_en(st_en), .acc_st_rd_req(st_rd_req), .acc_st_rd_addr(st_rd_addr), .acc_st_rd_ready(st_rd_ready), .acc_st_rd_data(st_rd_data),
    .acc_st_wr_req(st_wr_req), .acc_st_wr_addr(st_wr_addr), .acc_st_wr_data(st_wr_data), .acc_st_wr_ready(st_wr_ready),
    .acc_claim_valid(acc_claim_valid), .acc_claim_ready(acc_claim_ready), .acc_claim_slot(acc_claim_slot),
    .acc_complete_valid(cmt_done), .acc_complete_slot(cmt_slot), .acc_release_valid(acc_release_valid), .acc_release_slot(acc_release_slot),
    .acc_slot_state(acc_slot_state),
    .ext_req_valid(ext_req_valid), .ext_req_ready(ext_req_ready), .ext_req_we(ext_req_we), .ext_req_slot(ext_req_slot), .ext_req_row(ext_req_row),
    .ext_req_wdata(ext_req_wdata), .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(ext_rsp_ready), .ext_rsp_rdata(ext_rsp_rdata), .ext_rsp_we(ext_rsp_we),
    .ext_rsp_err(ext_rsp_err), .ext_rsp_code(ext_rsp_code), .acc_viol_sticky(acc_viol_sticky), .busy(busy), .engine_idle(engine_idle),
    .ev_inc(ev_inc), .perf_clear(perf_clear), .perf_cnt(perf_cnt));
  assign s_ready = s_ready_i;

  // ------------------------------------------------------------ TENSORCORE 02 systolic array
  logic [C*PSUM_WIDTH-1:0] ar_m_data;
  logic [RIDW-1:0]         ar_m_row;
  logic [C-1:0]            ar_m_col_mask;
  logic                    ar_busy_u, ar_tile_done_u, ps_ready;
  logic [39:0]             pf0, pf1, pf2, pf3, pf4, pf5;
  tensor_systolic_array #(.ARRAY_ROWS(R), .ARRAY_COLS(C), .DATA_WIDTH(OW), .ACC_WIDTH(PSUM_WIDTH), .K_WIDTH(K_W), .MUL_PIPE(MUL_PIPE), .CHECK_ALIGN(1), .PERF_EN(1)) u_arr (
    .clk(clk), .rst_n(rst_n), .cfg_valid(ar_cfg_valid), .cfg_ready(ar_cfg_ready), .cfg_m(ar_cfg_m), .cfg_n(ar_cfg_n), .cfg_k(ar_cfg_k), .cfg_reject(ar_cfg_reject),
    .s_valid(s_valid), .s_ready(s_ready_i), .s_a(s_a), .s_b(s_b), .s_k(ar_s_k), .stall_i(ar_stall),
    .m_valid(ar_m_valid), .m_ready(ar_m_ready), .m_row(ar_m_row), .m_data(ar_m_data), .m_col_mask(ar_m_col_mask), .m_last(ar_m_last),
    .busy(ar_busy_u), .tile_done(ar_tile_done_u), .align_err(ar_align_err), .perf_busy(pf0), .perf_issue(pf1), .perf_stall_up(pf2), .perf_stall_ext(pf3),
    .perf_mac(pf4), .perf_pad(pf5));

  // ------------------------------------------------------------ TENSORCORE 04 accumulator (its storage is the scratchpad's accumulator buffer)
  logic [2:0]               cfg_rej_code_u, ac_o_dest_u, ac_err_code_u;
  logic [SLOT_W-1:0]        ac_o_slot_u;
  logic [C*32-1:0]          ac_o_data_u;
  logic [C-1:0]             ac_o_clip_u;
  logic                     ac_o_err_u, cmt_ovf_u, cmt_clip_u, cmt_err_u, err_pulse_u, hc_ready_u, hr_valid_u, hr_vld_u;
  logic [NSLOT*2-1:0]       ac_slot_state_u;
  logic [2:0]               hr_status_u;
  logic [C*ACC_WIDTH-1:0]   hr_data_u;
  logic [C-1:0]             hr_ovf_u;
  logic [CHUNK_W-1:0]       hr_nchunk_u;
  logic [KTOT_W-1:0]        hr_kacc_u;
  assign ar_m_ready = ps_ready & readout_gate_i;
  tensor_accumulator #(.ROWS(R), .COLS(C), .DATA_W(OW), .PSUM_W(PSUM_WIDTH), .ACC_W(ACC_WIDTH), .OUT_W(32), .BIAS_W(32), .NUM_TILES(NSLOT), .TAG_W(TT_W),
      .CHUNK_W(CHUNK_W), .KC_W(K_W), .KTOT_W(KTOT_W), .RD_LAT(ACC_RD_LAT), .OVF_POLICY(0), .STRICT_RANGE(1), .PSUM_GUARD(1), .OFIFO_DEPTH(4), .HFIFO_DEPTH(4),
      .PERF_EN(1), .PERF_W(40)) u_acc (
    .clk(clk), .rst_n(rst_n),
    .cfg_valid(ac_cfg_valid), .cfg_ready(ac_cfg_ready), .cfg_slot(ac_cfg_slot), .cfg_tag(ac_cfg_tag), .cfg_m(ac_cfg_m), .cfg_n(ac_cfg_n), .cfg_k_total(ac_cfg_ktot),
    .cfg_n_chunks(ac_cfg_nch), .cfg_bias_en(1'b0), .cfg_bias('0), .cfg_dest(3'b001), .cfg_reject(ac_cfg_reject), .cfg_reject_code(cfg_rej_code_u),
    .ps_valid(ar_m_valid & readout_gate_i), .ps_ready(ps_ready), .ps_slot(ps_slot), .ps_tag(ps_tag), .ps_chunk(ps_chunk), .ps_chunk_k(ps_chunk_k), .ps_row(ar_m_row),
    .ps_data(ar_m_data), .ps_col_mask(ar_m_col_mask), .ps_last(ar_m_last),
    .hc_valid(1'b0), .hc_ready(hc_ready_u), .hc_op(2'd0), .hc_slot('0), .hc_row('0), .hc_wdata('0), .hr_valid(hr_valid_u), .hr_ready(1'b1), .hr_status(hr_status_u),
    .hr_data(hr_data_u), .hr_ovf(hr_ovf_u), .hr_vld(hr_vld_u), .hr_nchunk(hr_nchunk_u), .hr_kacc(hr_kacc_u),
    .st_en(st_en), .st_rd_req(st_rd_req), .st_rd_addr(st_rd_addr), .st_rd_ready(st_rd_ready), .st_rd_data(st_rd_data),
    .st_wr_req(st_wr_req), .st_wr_addr(st_wr_addr), .st_wr_data(st_wr_data), .st_wr_ready(st_wr_ready),
    .o_valid(ac_o_valid), .o_ready(ac_o_ready), .o_dest(ac_o_dest_u), .o_tag(ac_o_tag), .o_slot(ac_o_slot_u), .o_row(ac_o_row), .o_last(ac_o_last),
    .o_col_mask(ac_o_col_mask), .o_wide(ac_o_wide), .o_data(ac_o_data_u), .o_ovf(ac_o_ovf), .o_clip(ac_o_clip_u), .o_err(ac_o_err_u),
    .cmt_done(cmt_done), .cmt_slot(cmt_slot), .cmt_tag(cmt_tag), .cmt_ovf(cmt_ovf_u), .cmt_clip(cmt_clip_u), .cmt_err(cmt_err_u), .slot_state(ac_slot_state_u),
    .idle(ac_idle), .err_pulse(err_pulse_u), .err_code(ac_err_code_u), .err_sticky(ac_err_sticky), .perf_clr(1'b0), .ev_inc(), .perf_o());      // the accumulator's own counters are left unconnected here (package-sized buses; Yosys 0.33 cannot size them)

  wire unused_ok = &{1'b0, ar_busy_u, ar_tile_done_u, pf0, pf1, pf2, pf3, pf4, pf5, cfg_rej_code_u, ac_o_dest_u, ac_err_code_u, ac_o_slot_u, ac_o_data_u,
                     ac_o_clip_u, ac_o_err_u, cmt_ovf_u, cmt_clip_u, cmt_err_u, err_pulse_u, hc_ready_u, hr_valid_u, hr_vld_u, ac_slot_state_u, hr_status_u,
                     hr_data_u, hr_ovf_u, hr_nchunk_u, hr_kacc_u};
endmodule

`default_nettype wire
