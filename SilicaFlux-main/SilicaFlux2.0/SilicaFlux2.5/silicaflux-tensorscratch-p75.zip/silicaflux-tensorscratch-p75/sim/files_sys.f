-f sim/files_rtl.f
-f sim/files_tc.f
integration/ts_tc_system.sv
