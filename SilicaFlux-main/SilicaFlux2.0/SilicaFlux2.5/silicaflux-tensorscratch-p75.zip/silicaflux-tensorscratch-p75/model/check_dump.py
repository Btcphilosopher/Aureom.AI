#!/usr/bin/env python3
"""Independent software GEMM check of a testbench dump.

The testbench (tb/tb_ts_system.sv) writes, per problem, the matrices it generated (A, B) and the C it OBSERVED from the
TENSORCORE 04 commit stream (after the DMA -> scratchpad -> TENSORCORE 02 array -> TENSORCORE 04 path).  This script recomputes
C = A x B with numpy int64 matmul (no code shared with the RTL or the testbench) and compares element by element.

    python3 model/check_dump.py build/d1.txt [more dumps...]      exit status 0 only if every element of every problem matches
"""
import sys
import numpy as np

def parse(path):
    probs, cur = [], None
    for line in open(path):
        t = line.split()
        if not t:
            continue
        if t[0] == "PROBLEM":
            cur = {"id": int(t[1]), "M": int(t[2]), "N": int(t[3]), "K": int(t[4])}
            probs.append(cur)
        elif t[0] in ("A", "B", "C"):
            cur[t[0]] = np.array([int(x) for x in t[1:]], dtype=np.int64)
    return probs

def main(paths):
    bad = total = elems = 0
    for p in paths:
        for pr in parse(p):
            M, N, K = pr["M"], pr["N"], pr["K"]
            A = pr["A"].reshape(M, K); B = pr["B"].reshape(K, N); C = pr["C"].reshape(M, N)
            ref = A @ B                      # numpy int64 matmul: the independent GEMM
            total += 1; elems += M * N
            if not np.array_equal(ref, C):
                bad += 1
                idx = np.argwhere(ref != C)
                print(f"{p}: problem {pr['id']} (M={M} N={N} K={K}) MISMATCH at {len(idx)} elements, first {idx[0].tolist()} got {C[tuple(idx[0])]} expected {ref[tuple(idx[0])]}")
    print(f"check_dump: {total - bad}/{total} problems match numpy ({elems} C elements)")
    return 1 if bad or total == 0 else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
