#!/usr/bin/env python3
"""Analytical UPPER BOUND on the sustained slice rate of sf_tensor_scratchpad (no simulation, no RTL knowledge beyond the address map).

A bound, not a prediction: it only counts bank-port capacity.  It ignores staging depth, DMA writes, tile boundaries and the sink, all of which can only
LOWER the rate, so   measured rate <= bound   must hold for every benchmark run (checked by scripts/run_bench.py), and a bound of 1.0 is a necessary - not
sufficient - condition for full rate.

Per tile the scratchpad must read a known multiset of bank words (address map: word w of an operand set lives in bank  w mod NB):
  A: lane i reads the N = ceil((off + eff_k)/EPW) consecutive words  wA0 + i*SA + j , j = 0..N-1   (EPW = WORD_BYTES/ELEM_BYTES elements per word)
  B: slice k reads the NW consecutive words  wB0 + k*SB + j , j = 0..NW-1  (NW = 1 aligned, 2 when the row segment straddles a word boundary)
A single-port bank serves one read per cycle and a tile needs at least eff_k cycles (one slice per cycle), therefore
        rate <= eff_k / max over banks of (reads of that bank per tile)         for A and for B, and  rate <= 1.
Why "per tile" and not "per word step": the lanes request in lockstep only at the very first word; arbitration staggers them (lane 1 is granted first, lane 2 next,
...) and each lane then sweeps consecutive words, i.e. consecutive banks, so what limits the rate is the total number of reads per bank over the tile.  (A first,
instantaneous model - "lanes that share a bank at one word step" - was falsified by the benchmark: it predicted 0.5 for an 8 x 8 array whose lanes all map to one
bank at word 0, and the RTL sustains 0.94.)
"""
import math
from collections import Counter


def a_reads(R, EPW, NAB, SA, w0, off, eff_k, rows=None):
    rows = R if rows is None else rows
    n = (off + eff_k + EPW - 1) // EPW
    c = Counter()
    for i in range(rows):
        for j in range(n):
            c[(w0 + i * SA + j) % NAB] += 1
    return c, n


def b_reads(NBB, wB0, SB, NW, eff_k):
    c = Counter()
    for k in range(eff_k):
        for j in range(NW):
            c[(wB0 + k * SB + j) % NBB] += 1
    return c


def rate_bound(R=4, C=4, WB=4, EB=1, NAB=4, NBB=2, LDA_W=17, LDB_W=1, M0=0, N0=0, K0=0, TK=32):
    EPW = WB // EB
    A0 = M0 * LDA_W * WB + K0 * EB                      # byte address of lane 0's first element (a_addr = 0)
    wA0, offA = A0 // WB, (A0 % WB) // EB
    B0 = K0 * LDB_W * WB + N0 * EB                      # byte address of B row 0 segment (b_addr = 0)
    wB0, offB = B0 // WB, B0 % WB
    NW = (offB + C * EB + WB - 1) // WB
    ca, nwa = a_reads(R, EPW, NAB, LDA_W, wA0, offA, TK)
    cb = b_reads(NBB, wB0, LDB_W, NW, TK)
    ba = min(1.0, TK / max(ca.values()))
    bb = min(1.0, TK / max(cb.values()))
    return min(ba, bb), dict(a_bound=round(ba, 4), b_bound=round(bb, 4), a_max_reads_per_bank=max(ca.values()), b_max_reads_per_bank=max(cb.values()), b_words=NW, a_words_per_lane=nwa)


if __name__ == "__main__":
    print("4x4 NAB=4 TK=32, pitch 8 / 17:", rate_bound(LDA_W=8)[0], rate_bound(LDA_W=17)[0])
    print("8x8 NAB=8 pitch 32:", rate_bound(R=8, C=8, NAB=8, NBB=4, LDA_W=32, LDB_W=2)[0])
    print("4x4 NAB=1 TK=32:", rate_bound(NAB=1)[0], "  8x8 NAB=1:", rate_bound(R=8, C=8, NAB=1, NBB=4, LDA_W=33, LDB_W=2)[0])
    print("NBB=1 straddle n0=1:", rate_bound(NBB=1, N0=1, LDB_W=2))
