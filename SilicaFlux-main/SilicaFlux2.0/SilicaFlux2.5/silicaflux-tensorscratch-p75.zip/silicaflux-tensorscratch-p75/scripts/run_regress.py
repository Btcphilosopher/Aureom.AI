#!/usr/bin/env python3
"""Regression driver for the SilicaFlux TensorScratch (sf_tensor_scratchpad).

    python3 scripts/run_regress.py [--jobs 4] [--quick] [--only base,single,...] [--seeds 3]

Stages (each stage must pass before the report says PASS):
  lint      Verilator -Wall over the RTL for several parameter sets, Icarus elaboration, and the ILLEGAL-parameter rejections
  unit      tb_ts_smoke (Verilator + Icarus), tb_ts_errors (Verilator + Icarus, check counts must agree), tb_ts_acc (accumulator buffer vs the
            TENSORCORE 04 reference storage, 12 configurations; one short run on Icarus)
  system    tb_ts_system (DMA -> scratchpad -> TENSORCORE 02 array -> TENSORCORE 04 accumulator) for every configuration x profile x seed;
            every dump is re-verified with numpy int64 matmul (model/check_dump.py), independent of the RTL and of the testbench
  reset     abort a problem at several points with a reset, then run a clean problem
Results: reports/regression.json and reports/regression.md.  Nothing here touches git.
"""
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "model"))
import check_dump  # noqa: E402

VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD"]
RTL = ["-f", "sim/files_rtl.f"]
TC = ["-f", "sim/files_tc.f"]
BUILD = os.path.join(ROOT, "build", "regress")

# configuration name -> TB parameter overrides (names are the tb_ts_system parameters)
CONFIGS = {
    "base":    {},
    "single":  {"ND": 0},
    "shared":  {"SET_MAP": 0},
    "shared_s0": {"SET_MAP": 0, "STARVE": 0},
    "nab1":    {"NAB": 1, "NBB": 1},
    "nab2":    {"NAB": 2},
    "nab8":    {"NAB": 8},
    "nbb1":    {"NBB": 1},
    "nbb4":    {"NBB": 4},
    "rlat2":   {"RLAT": 2, "ASTAGE": 6, "BSTAGE": 8},
    "rlat3":   {"RLAT": 3, "ASTAGE": 8, "BSTAGE": 10},
    "stage2":  {"ASTAGE": 2, "BSTAGE": 2, "MUL_PIPE": 1},
    "r2c2":    {"R": 2, "C": 2, "NAB": 2},
    "r3c5":    {"R": 3, "C": 5, "NAB": 4},
    "r8c8":    {"R": 8, "C": 8, "NAB": 8, "NBB": 4, "ACC_BYTES": 2048},
    "wb8":     {"WB": 8},
    "wb16":    {"WB": 16, "NAB": 2},
    "ow16":    {"OW": 16, "PSUM": 48, "ACC_W": 48},
    "acc48":   {"ACC_W": 48},
    "acc40wq2": {"ACC_W": 40, "WQ": 2},
    "rdlat2":  {"RD_LAT": 2},
    "rdlat3":  {"RD_LAT": 3, "NACCB": 8},
    "nacc1":   {"NACCB": 1},
    "autorel": {"AUTO_REL": 1},
    "ctxq3":   {"CTXQ": 3},
    "tilek8":  {"TILE_K": 8},
    # the RTL's embedded checkers (SF_ASSERT) compiled in and enabled (--assert); any "Assertion failed" line fails the run
    "assert_base":   {"__vflags": ["--assert", "-DSF_ASSERT"]},
    "assert_shared": {"SET_MAP": 0, "NBB": 1, "NAB": 2, "__vflags": ["--assert", "-DSF_ASSERT"]},
}
QUICK = ["base", "single", "shared", "nab1", "nbb1", "r8c8", "ow16", "rdlat3", "autorel", "stage2"]

PROFILES = {
    "clean":  ["+NPROB=12"],
    "stalls": ["+NPROB=10", "+ASTALL=30", "+MRDY=30", "+ORDY=40", "+DGAP=40", "+DRSP=40", "+TRSP=40", "+DDUP=25", "+SPLITW=35"],
}
# directed shapes (no randomness in the geometry): minimum sizes, K far above TILE_K, partial tiles in every direction, no padding / heavy padding
DIRECTED = [
    ("1x1x1",        ["+M=1", "+N=1", "+K=1", "+BM=1", "+BN=1", "+BK=1", "+TK=1", "+MPAD=0", "+KPAD=0", "+NPAD=0"]),
    ("tileK1",       ["+M=9", "+N=9", "+K=9", "+BM=8", "+BN=8", "+BK=9", "+TK=1"]),
    ("kchunks",      ["+M=8", "+N=8", "+K=100", "+BM=8", "+BN=8", "+BK=25", "+TK=8", "+KPAD=0", "+NPAD=0", "+MPAD=0"]),
    ("deepK_stalls", ["+M=4", "+N=4", "+K=200", "+BM=4", "+BN=4", "+BK=50", "+TK=17", "+ASTALL=30", "+MRDY=30"]),
    ("straddle",     ["+M=8", "+N=8", "+K=16", "+BM=8", "+BN=8", "+BK=16", "+TK=16", "+NPAD=1", "+KPAD=3", "+MPAD=1"]),
    ("dense_nopad",  ["+M=12", "+N=12", "+K=32", "+BM=12", "+BN=12", "+BK=32", "+TK=32", "+PADA=0", "+PADB=0", "+OFFA=0", "+OFFB=0", "+MPAD=0", "+KPAD=0", "+NPAD=0"]),
    ("conflict_lda", ["+M=8", "+N=8", "+K=32", "+BM=8", "+BN=8", "+BK=32", "+TK=32", "+PADA=0", "+PADB=0", "+KPAD=0", "+NPAD=0", "+MPAD=0"]),
]
RESET_POINTS = [40, 120, 260, 500, 900]


def sh(cmd, cwd=ROOT, timeout=1800):
    t0 = time.time()
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout + p.stderr, time.time() - t0


def vbuild(name, top, files, extra=(), mdir=None):
    mdir = mdir or os.path.join(BUILD, name)
    os.makedirs(mdir, exist_ok=True)
    rc, out, dt = sh(["verilator"] + VFLAGS + files + ["--top-module", top] + list(extra) + ["-Mdir", mdir, "-o", "V" + top])
    errs = [l for l in out.splitlines() if l.startswith("%Error")]
    return os.path.join(mdir, "V" + top), errs, dt


# ---------------------------------------------------------------------------------------------------------- lint
LINT_SETS = {
    "base": {}, "single": {"ENABLE_DOUBLE_BUFFERING": 0}, "shared": {"SET_MAP": 0}, "r8c8": {"ARRAY_ROWS": 8, "ARRAY_COLS": 8, "NUM_A_BANKS": 8, "NUM_B_BANKS": 4},
    "r3c5": {"ARRAY_ROWS": 3, "ARRAY_COLS": 5}, "wb8": {"WORD_BYTES": 8}, "wb16": {"WORD_BYTES": 16}, "ow16": {"OPERAND_WIDTH": 16, "ACC_WIDTH": 48},
    "acc40": {"ACC_WIDTH": 40}, "rdlat3": {"ACC_RD_LAT": 3, "NUM_ACC_BANKS": 8}, "nab1": {"NUM_A_BANKS": 1, "NUM_B_BANKS": 1}, "lat3": {"READ_LATENCY": 3},
}
ILLEGAL = {   # each must be REJECTED at elaboration
    "NUM_A_BANKS=3": {"NUM_A_BANKS": 3}, "NUM_B_BANKS=3": {"NUM_B_BANKS": 3}, "OPERAND_WIDTH=12": {"OPERAND_WIDTH": 12}, "OPERAND_WIDTH=32": {"OPERAND_WIDTH": 32},
    "A_BUFFER_BYTES=3000": {"A_BUFFER_BYTES": 3000}, "B_BUFFER_BYTES=0": {"B_BUFFER_BYTES": 0}, "ACC_WIDTH=8": {"ACC_WIDTH": 8}, "WORD_BYTES=3": {"WORD_BYTES": 3},
    "WORD_BYTES=1": {"WORD_BYTES": 1}, "ARRAY_ROWS=0": {"ARRAY_ROWS": 0}, "TILE_K=0": {"TILE_K": 0}, "CTXQ_DEPTH=1": {"CTXQ_DEPTH": 1}, "A_STAGE=1": {"A_STAGE": 1},
    "ACC_RD_LAT=4": {"ACC_RD_LAT": 4}, "A_BUFFER too small for the banks": {"A_BUFFER_BYTES": 32, "NUM_A_BANKS": 8}, "ACC_BUFFER_BYTES too small": {"ACC_BUFFER_BYTES": 16},
    "NUM_ACC_BANKS=3": {"NUM_ACC_BANKS": 3}, "ACC_WQ_DEPTH=1": {"ACC_WQ_DEPTH": 1},
}


def stage_lint():
    res = []
    for name, ov in LINT_SETS.items():
        g = [f"-G{k}={v}" for k, v in ov.items()]
        rc, out, _ = sh(["verilator", "--lint-only", "-Wall", "-Wno-fatal"] + RTL + ["--top-module", "sf_tensor_scratchpad"] + g)
        mine = [l for l in out.splitlines() if re.match(r"%(Warning|Error)", l) and "third_party" not in l]
        res.append(dict(name=f"verilator -Wall [{name}]", ok=(rc == 0 and not mine), detail="; ".join(mine[:3])))
    rc, out, _ = sh(["iverilog", "-g2012", "-o", os.path.join(BUILD, "elab.vvp"), "-s", "sf_tensor_scratchpad"] + ["-f", "sim/files_rtl.f"])
    bad = [l for l in out.splitlines() if "error" in l.lower()]
    res.append(dict(name="icarus elaboration [base]", ok=(rc == 0 and not bad), detail="; ".join(bad[:3])))
    for name, ov in ILLEGAL.items():
        g = [f"-G{k}={v}" for k, v in ov.items()]
        # no -Wno-fatal here: $fatal in a generate block is reported as USERFATAL and must stop elaboration
        rc, out, _ = sh(["verilator", "--lint-only"] + RTL + ["--top-module", "sf_tensor_scratchpad"] + g)
        friendly = (rc != 0) and bool(re.search(r"\$fatal\(1, \"sf_(tensor_scratchpad|ts_\w+):", out))
        other = (rc != 0) and not friendly and ("%Error" in out)          # still rejected (elaboration errors), but without the named message
        res.append(dict(name=f"illegal parameter rejected [{name}]", ok=friendly or other,
                        detail="named $fatal message" if friendly else ("rejected by elaboration errors (no named message)" if other else out[-200:])))
    return res


# ---------------------------------------------------------------------------------------------------------- unit
ACC_CFGS = [
    {}, {"NBA": 1}, {"NBA": 2, "WQ": 2}, {"RD_LAT": 2}, {"RD_LAT": 3, "NBA": 8}, {"ACC_W": 48, "WQ": 3}, {"ACC_W": 40, "EXTLIM": 2}, {"AUTO_REL": 1},
    {"NUM_SLOTS": 4, "ROWS": 3, "COLS": 5}, {"NUM_SLOTS": 2, "NBA": 2}, {"RD_LAT": 2, "NBA": 4, "WQ": 2}, {"RD_LAT": 3, "NBA": 4},
]


def run_unit(jobs):
    res = []
    # smoke + errors on Verilator and Icarus
    exe, errs, _ = vbuild("smoke", "tb_ts_smoke", RTL + ["tb/tb_ts_smoke.sv"])
    rc, out, _ = sh([exe])
    res.append(dict(name="tb_ts_smoke [verilator]", ok="SMOKE PASS" in out, detail=""))
    rc, out, _ = sh(["iverilog", "-g2012", "-o", os.path.join(BUILD, "smoke.vvp"), "-s", "tb_ts_smoke"] + ["-f", "sim/files_rtl.f", "tb/tb_ts_smoke.sv"])
    rc, out, _ = sh(["vvp", os.path.join(BUILD, "smoke.vvp")])
    res.append(dict(name="tb_ts_smoke [icarus]", ok="SMOKE PASS" in out, detail=""))
    exe, errs, _ = vbuild("errors", "tb_ts_errors", RTL + ["tb/tb_ts_errors.sv"])
    rc, outv, _ = sh([exe])
    mv = re.search(r"tb_ts_errors: (\d+) checks, (\d+) errors", outv)
    res.append(dict(name="tb_ts_errors [verilator]", ok=bool(mv) and mv.group(2) == "0" and "TB_RESULT PASS" in outv, detail=mv.group(0) if mv else outv[-200:], checks=int(mv.group(1)) if mv else 0))
    rc, _, _ = sh(["iverilog", "-g2012", "-o", os.path.join(BUILD, "errors.vvp"), "-s", "tb_ts_errors", "-f", "sim/files_rtl.f", "tb/tb_ts_errors.sv"])
    rc, outi, _ = sh(["vvp", os.path.join(BUILD, "errors.vvp")], timeout=3000)
    mi = re.search(r"tb_ts_errors: (\d+) checks, (\d+) errors", outi)
    res.append(dict(name="tb_ts_errors [icarus]", ok=bool(mi) and mi.group(2) == "0" and "TB_RESULT PASS" in outi, detail=mi.group(0) if mi else outi[-200:], checks=int(mi.group(1)) if mi else 0))
    res.append(dict(name="tb_ts_errors check counts agree (verilator vs icarus)", ok=bool(mv and mi) and mv.group(1) == mi.group(1), detail=f"{mv.group(1) if mv else '?'} vs {mi.group(1) if mi else '?'}"))

    def one_acc(i_cfg):
        i, cfg = i_cfg
        g = [f"-G{k}={v}" for k, v in cfg.items()]
        exe, errs, _ = vbuild(f"acc{i}", "tb_ts_acc", ["-f", "sim/files_acc.f", "tb/tb_ts_acc.sv"], extra=g)
        rc, out, _ = sh([exe], timeout=1800)
        m = re.search(r"tb_ts_acc: (\d+) checks, (\d+) errors", out)
        ok = bool(m) and m.group(2) == "0" and "TB_RESULT PASS" in out
        w = re.search(r"worst external read latency[^:]*: (\d+) cycles", out)
        t = re.search(r"(\d+) cycles, (\d+) reads \((\d+) forwarded from the write buffer\), (\d+) writes, (\d+) completions, read denials (\d+), write freezes (\d+), max ext latency (\d+)", out)
        stats = dict(zip(["cycles", "reads", "forwarded", "writes", "completions", "read_denials", "write_freezes", "max_ext_latency"], map(int, t.groups()))) if t else None
        return dict(name=f"tb_ts_acc vs TENSORCORE 04 reference storage {cfg or 'default'}", ok=ok, detail=(m.group(0) if m else out[-200:]),
                    checks=int(m.group(1)) if m else 0, ext_worst=int(w.group(1)) if w else None, stats=stats, cfg=cfg)
    with ThreadPoolExecutor(jobs) as ex:
        res += list(ex.map(one_acc, list(enumerate(ACC_CFGS))))
    rc, _, _ = sh(["iverilog", "-g2012", "-o", os.path.join(BUILD, "acc.vvp"), "-s", "tb_ts_acc", "-P", "tb_ts_acc.CYCLES=6000", "-f", "sim/files_acc.f", "tb/tb_ts_acc.sv"])
    rc, out, _ = sh(["vvp", os.path.join(BUILD, "acc.vvp")], timeout=3000)
    m = re.search(r"tb_ts_acc: (\d+) checks, (\d+) errors", out)
    res.append(dict(name="tb_ts_acc [icarus, 6000 cycles]", ok=bool(m) and m.group(2) == "0" and "TB_RESULT PASS" in out, detail=m.group(0) if m else out[-200:]))
    return res


# ---------------------------------------------------------------------------------------------------------- system
def run_case(exe, name, args, dump):
    t0 = time.time()
    rc, out, _ = sh([exe] + args + [f"+dump={dump}", "+TIMEOUT=400000"], timeout=3000)
    ok = "TB_RESULT PASS" in out and rc == 0 and "Assertion failed" not in out
    probs = re.findall(r"PROBLEM \d+ done in (\d+) cycles: slices=(\d+)", out)
    return dict(ok=ok, cycles=sum(int(c) for c, _ in probs), slices=sum(int(s) for _, s in probs), problems=len(probs),
                tail="" if ok else "\n".join(out.splitlines()[-6:]), secs=round(time.time() - t0, 1))


def system_job(cfg_name, seeds, quick):
    ov = {k: v for k, v in CONFIGS[cfg_name].items() if not k.startswith("__")}
    vfl = CONFIGS[cfg_name].get("__vflags", [])
    g = [f"-G{k}={v}" for k, v in ov.items()] + vfl
    exe, errs, bt = vbuild(f"sys_{cfg_name}", "tb_ts_system", ["-f", "sim/files_sys.f", "tb/tb_ts_system.sv"], extra=g)
    if errs or not os.path.exists(exe):
        return [dict(config=cfg_name, case="build", ok=False, detail="; ".join(errs[:2]))]
    ddir = os.path.join(BUILD, "dumps"); os.makedirs(ddir, exist_ok=True)
    rows = []
    cases = []
    for sd in range(1, seeds + 1):
        for pn, pa in PROFILES.items():
            cases.append((f"{pn}/seed{sd}", [f"+seed={sd * 101 + len(cfg_name)}"] + pa))
    if not quick:
        for dn, da in DIRECTED:
            if cfg_name in ("r8c8",) and dn in ("deepK_stalls",):
                continue
            cases.append((f"directed/{dn}", ["+seed=7"] + da))
        for at in RESET_POINTS:
            cases.append((f"reset@{at}", ["+seed=5", "+NPROB=2", "+M=12", "+N=12", "+K=40", "+BM=8", "+BN=8", "+BK=16", f"+RESET_AT={at}", "+ASTALL=10", "+DGAP=10"]))
    for cname, args in cases:
        dump = os.path.join(ddir, f"{cfg_name}_{cname.replace('/', '_').replace('@', '_')}.txt")
        if os.path.exists(dump): os.remove(dump)
        r = run_case(exe, cname, args, dump)
        npy = None
        if r["ok"] and os.path.exists(dump):
            probs = check_dump.parse(dump)
            bad = 0; elems = 0
            import numpy as np
            for pr in probs:
                M, N, K = pr["M"], pr["N"], pr["K"]
                A = pr["A"].reshape(M, K); B = pr["B"].reshape(K, N); Cc = pr["C"].reshape(M, N)
                elems += M * N
                if not np.array_equal(A @ B, Cc): bad += 1
            npy = dict(problems=len(probs), elements=elems, bad=bad)
            if bad: r["ok"] = False; r["tail"] = f"numpy mismatch in {bad} problems"
        rows.append(dict(config=cfg_name, case=cname, args=" ".join(args), numpy=npy, **r))
    return rows


def a_partial(stages):
    return set(stages) != {"lint", "unit", "system"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--only", default="")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--stages", default="lint,unit,system")
    a = ap.parse_args()
    os.makedirs(BUILD, exist_ok=True); os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    stages = a.stages.split(",")
    rep = dict(tool=dict(verilator=sh(["verilator", "--version"])[1].strip(), icarus=sh(["iverilog", "-V"])[1].splitlines()[0], python=sys.version.split()[0]), stages={})
    t0 = time.time()
    if "lint" in stages:
        rep["stages"]["lint"] = stage_lint()
        print("lint:", sum(r["ok"] for r in rep["stages"]["lint"]), "/", len(rep["stages"]["lint"]), flush=True)
    if "unit" in stages:
        rep["stages"]["unit"] = run_unit(a.jobs)
        print("unit:", sum(r["ok"] for r in rep["stages"]["unit"]), "/", len(rep["stages"]["unit"]), flush=True)
    if "system" in stages:
        names = a.only.split(",") if a.only else (QUICK if a.quick else list(CONFIGS))
        with ThreadPoolExecutor(a.jobs) as ex:
            futs = {n: ex.submit(system_job, n, a.seeds, a.quick) for n in names}
            rows = []
            for n, f in futs.items():
                r = f.result(); rows += r
                print(f"system[{n}]: {sum(x['ok'] for x in r)}/{len(r)}", flush=True)
        rep["stages"]["system"] = rows
    rep["seconds"] = round(time.time() - t0)
    old = os.path.join(ROOT, "reports", "regression.json")
    if os.path.exists(old) and a_partial(stages):
        prev = json.load(open(old))
        merged = dict(prev.get("stages", {})); merged.update(rep["stages"]); rep["stages"] = merged
        rep["seconds"] += prev.get("seconds", 0)
    ok = all(all(x["ok"] for x in v) for v in rep["stages"].values())
    rep["overall"] = "PASS" if ok else "FAIL"
    json.dump(rep, open(os.path.join(ROOT, "reports", "regression.json"), "w"), indent=1)
    write_md(rep)
    print("OVERALL", rep["overall"], f"({rep['seconds']} s)")
    return 0 if ok else 1


def write_md(rep):
    L = ["# Regression results (generated by scripts/run_regress.py)", "",
         f"Tools: {rep['tool']['verilator']} | {rep['tool']['icarus']} | Python {rep['tool']['python']}.  Overall: **{rep['overall']}** ({rep['seconds']} s).",
         "All numbers are RTL-simulation results; nothing here is silicon, FPGA or timing data.", ""]
    for st, rows in rep["stages"].items():
        L += [f"## {st}: {sum(r['ok'] for r in rows)} / {len(rows)} pass", ""]
        if st == "system":
            by = {}
            for r in rows: by.setdefault(r["config"], []).append(r)
            L += ["| config | runs | pass | GEMM problems | C elements (numpy-verified) | array slices | cycles |", "|---|---:|---:|---:|---:|---:|---:|"]
            for c, rs in by.items():
                pr = sum((r.get("numpy") or {}).get("problems", 0) for r in rs); el = sum((r.get("numpy") or {}).get("elements", 0) for r in rs)
                L.append(f"| {c} | {len(rs)} | {sum(r['ok'] for r in rs)} | {pr} | {el} | {sum(r.get('slices', 0) for r in rs)} | {sum(r.get('cycles', 0) for r in rs)} |")
            bad = [r for r in rows if not r["ok"]]
            if bad:
                L += ["", "### failures", ""] + [f"* {r['config']} / {r['case']}: {r.get('tail') or r.get('detail')}" for r in bad]
        else:
            L += ["| test | result | detail |", "|---|---|---|"]
            for r in rows: L.append(f"| {r['name']} | {'PASS' if r['ok'] else 'FAIL'} | {str(r.get('detail', ''))[:90]} |")
        L.append("")
    open(os.path.join(ROOT, "reports", "regression.md"), "w").write("\n".join(L))


if __name__ == "__main__":
    sys.exit(main())
