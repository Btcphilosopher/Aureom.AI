#!/usr/bin/env bash
# Re-check that every reused third_party file still matches its recorded SHA-256.
cd "$(dirname "$0")/.." && sha256sum -c third_party/SHA256SUMS --quiet && echo "third_party: all files match SHA256SUMS"
