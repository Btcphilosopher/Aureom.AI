#!/usr/bin/env bash
# Build the deliverable ZIP (no git involved).  Usage: scripts/make_zip.sh [output-dir]
# Includes sources, docs, reports and scripts; excludes build products (build/), caches and the templates' intermediate files.
set -euo pipefail
cd "$(dirname "$0")/.."
NAME=silicaflux-tensorscratch-p75
OUT="${1:-..}"
python3 scripts/fill_docs.py
./scripts/check_third_party.sh
rm -f MANIFEST.sha256
find . -type f -not -path './build/*' -not -path '*/__pycache__/*' -not -name '*.pyc' -not -name MANIFEST.sha256 | sort | xargs sha256sum > MANIFEST.sha256
STAGE=$(mktemp -d)
mkdir -p "$STAGE/$NAME"
tar --exclude='./build' --exclude='__pycache__' --exclude='*.pyc' -cf - . | tar -xf - -C "$STAGE/$NAME"
rm -f "$OUT/$NAME.zip"
( cd "$STAGE" && zip -qr -X "$OLDPWD/$OUT/$NAME.zip" "$NAME" ) 2>/dev/null || ( cd "$STAGE" && zip -qr -X "$(realpath "$OLDPWD/$OUT")/$NAME.zip" "$NAME" )
rm -rf "$STAGE"
echo "wrote $(realpath "$OUT")/$NAME.zip"; unzip -l "$OUT/$NAME.zip" | tail -1
