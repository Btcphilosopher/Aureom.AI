#!/usr/bin/env python3
"""Render the generated documents from the report files, so no number in the docs can differ from what was measured.

    python3 scripts/fill_docs.py          reads  reports/{regression,bandwidth,synthesis}.json  and  docs/src/*.tpl
                                          writes README.md, docs/VERIFICATION.md, docs/BANDWIDTH.md, docs/SYNTHESIS.md
"""
import json, os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rd = lambda p: json.load(open(os.path.join(ROOT, p)))
reg, bw, syn = rd("reports/regression.json"), rd("reports/bandwidth.json"), rd("reports/synthesis.json")
T = {}

# ------------------------------------------------------------------ regression
lint, unit, system = reg["stages"]["lint"], reg["stages"]["unit"], reg["stages"]["system"]
T["REGRESS_SECS"] = f"{reg.get('seconds', 0) // 60} min {reg.get('seconds', 0) % 60} s"
T["LINT_PASS"], T["LINT_TOTAL"] = sum(r["ok"] for r in lint), len(lint)
T["UNIT_PASS"], T["UNIT_TOTAL"] = sum(r["ok"] for r in unit), len(unit)
T["SYS_RUNS"], T["SYS_PASS"] = len(system), sum(r["ok"] for r in system)
cfgs = []
for r in system:
    if r["config"] not in cfgs: cfgs.append(r["config"])
T["SYS_CONFIGS"] = len(cfgs)
T["SYS_PROBLEMS"] = sum((r.get("numpy") or {}).get("problems", 0) for r in system)
T["SYS_ELEMS"] = sum((r.get("numpy") or {}).get("elements", 0) for r in system)
T["SYS_SLICES"] = f"{sum(r.get('slices', 0) for r in system):,}"
T["SYS_ELEMS"] = f"{T['SYS_ELEMS']:,}"
errs = [r for r in unit if r["name"].startswith("tb_ts_errors [verilator]")]
T["ERR_CHECKS"] = errs[0].get("checks", 0) if errs else 0
acc = [r for r in unit if r["name"].startswith("tb_ts_acc vs")]
T["ACC_CHECKS"] = f"{sum(r.get('checks', 0) for r in acc):,}"
T["ACC_CFGS"] = len(acc)
rows = ["| configuration | reads | forwarded from the write buffer | writes | completions | read denials | write freezes | max ext latency in mix | worst ext latency, saturated |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
for r in acc:
    s = r.get("stats") or {}
    rows.append(f"| {r.get('cfg') or 'default'} | {s.get('reads', '')} | {s.get('forwarded', '')} | {s.get('writes', '')} | {s.get('completions', '')} | {s.get('read_denials', '')} | {s.get('write_freezes', '')} | {s.get('max_ext_latency', '')} | {r.get('ext_worst', '')} |")
T["ACC_TABLE"] = "\n".join(rows)
by = {}
for r in system: by.setdefault(r["config"], []).append(r)
rows = ["| config | runs | pass | GEMM problems | C elements | array slices | cycles |", "|---|---:|---:|---:|---:|---:|---:|"]
for c, rs in by.items():
    rows.append(f"| {c} | {len(rs)} | {sum(r['ok'] for r in rs)} | {sum((r.get('numpy') or {}).get('problems', 0) for r in rs)} | {sum((r.get('numpy') or {}).get('elements', 0) for r in rs):,} | {sum(r.get('slices', 0) for r in rs):,} | {sum(r.get('cycles', 0) for r in rs):,} |")
T["SYS_TABLE"] = "\n".join(rows)

# ------------------------------------------------------------------ bandwidth
brs = bw["rows"]
T["BENCH_RUNS"], T["BENCH_ERR"], T["BENCH_VIOL"] = len(brs), bw["errors"], bw["bound_violations"]
def find(group, config, layout):
    for r in brs:
        if r["group"] == group and r["config"] == config and r["layout"] == layout: return r
best = find("A layout x NUM_A_BANKS", "NAB=4", "conflict-free pitch 17 words")
worst = find("A layout x NUM_A_BANKS", "NAB=4", "all A lanes in one bank (pitch 8)")
T["BEST_RATE"] = f"{best['rate']:.4f}" if best else "?"
T["BEST_OPC"] = f"{best['operands_per_cycle']:.3f}" if best else "?"
T["WORST_RATE"] = f"{worst['rate']:.4f}" if worst else "?"
T["DOD_RATE"] = (f"{T['BEST_OPC']} operands/cycle (rate {T['BEST_RATE']} slice/cycle) sustained over 32 back-to-back tiles for a conflict-free layout; "
                 f"{T['WORST_RATE']} slice/cycle even when all four A lanes share one bank (`B_STAGE` = 8)")

# ------------------------------------------------------------------ synthesis
sres = syn["results"]
T["SYN_TOTAL"] = len(sres); T["SYN_OK"] = sum(r["status"] == "OK" for r in sres)
T["SYN_LATCH"] = sum(r["latches"] for r in sres); T["SYN_LOOPS"] = sum(r["comb_loops"] for r in sres)
def srow(prefix):
    for r in sres:
        if r["name"].startswith(prefix): return r
base = srow("sf_tensor_scratchpad baseline")
sysr = srow("ts_tc_system")
T["BASE_FF"] = f"{base['flip_flops']:,}" if base else "?"
T["BASE_LOGIC"] = f"{base['logic_cells']:,}" if base else "?"
T["BASE_SRAM"] = f"{base['sram_bank_bits']:,}" if base else "?"
T["SYS_FF"] = f"{sysr['flip_flops']:,}" if sysr else "?"
T["SYS_LOGIC"] = f"{sysr['logic_cells']:,}" if sysr else "?"
T["SYN_TABLE"] = "\n".join(["| module / configuration | status | flip-flops | logic cells | SRAM bank bits | FIFO bits | latches | comb. loops |", "|---|---|---:|---:|---:|---:|---:|---:|"] +
    [f"| {r['name']} | {r['status']} | {r['flip_flops']:,} | {r['logic_cells']:,} | {r['sram_bank_bits']:,} | {r['fifo_bits']:,} | {r['latches']} | {r['comb_loops']} |" for r in sres])

def sv(prefix, key):
    r = srow(prefix); return r[key] if r else None
T["AGU_LOGIC"], T["AGU20_LOGIC"] = f"{sv('sf_ts_agu (ADDR_W=32)', 'logic_cells'):,}", f"{sv('sf_ts_agu (ADDR_W=20)', 'logic_cells'):,}"
T["ACCBUF_LOGIC"] = f"{sv('sf_ts_accbuf', 'logic_cells'):,}"
T["SINGLE_LOGIC"], T["SHARED_LOGIC"] = f"{sv('  ... single buffer', 'logic_cells'):,}", f"{sv('  ... ping-pong shared banks', 'logic_cells'):,}"
T["SPLIT_VS_SINGLE"] = f"{sv('sf_tensor_scratchpad baseline', 'logic_cells') - sv('  ... single buffer', 'logic_cells'):,}"
T["WB8_LOGIC"], T["WB8_FIFO"], T["BASE_FIFO"] = f"{sv('  ... WORD_BYTES=8', 'logic_cells'):,}", f"{sv('  ... WORD_BYTES=8', 'fifo_bits'):,}", f"{sv('sf_tensor_scratchpad baseline', 'fifo_bits'):,}"
T["ACC48_ADD_FF"] = f"{sv('  ... ACC_WIDTH=48', 'flip_flops') - sv('sf_tensor_scratchpad baseline', 'flip_flops'):,}"
T["X8_RATIO"] = f"{sv('  ... 8x8 array', 'logic_cells') / sv('sf_tensor_scratchpad baseline', 'logic_cells'):.1f}"
# ------------------------------------------------------------------ headline table for the README
T["HEADLINE_TABLE"] = "\n".join([
    "| item | result |", "|---|---|",
    f"| sustained operand rate, 4 x 4 INT8, conflict-free layout | **{T['BEST_OPC']} operands/cycle** ({T['BEST_RATE']} slice/cycle, 32 back-to-back tiles, data-checked) |",
    f"| same, pitch that makes all four A lanes request the same bank at their first word | {T['WORST_RATE']} slice/cycle with `B_STAGE` = 8 (lower with shallower staging, `docs/BANDWIDTH.md`) |",
    f"| system runs through the real TENSORCORE 02 + 04, {T['SYS_CONFIGS']} configurations | **{T['SYS_PASS']} / {T['SYS_RUNS']}** pass; {T['SYS_PROBLEMS']} GEMM problems, {T['SYS_ELEMS']} C elements equal to `numpy` int64 matmul |",
    f"| lint / unit / directed | {T['LINT_PASS']} / {T['LINT_TOTAL']} lint checks; {T['UNIT_PASS']} / {T['UNIT_TOTAL']} unit tests; {T['ERR_CHECKS']} directed error / boundary / ownership checks |",
    f"| accumulator buffer vs TENSORCORE 04 reference storage | bit-exact lock-step, {T['ACC_CFGS']} configurations, {T['ACC_CHECKS']} checks |",
    f"| bandwidth benchmark | {T['BENCH_RUNS']} rows, {T['BENCH_ERR']} data errors, {T['BENCH_VIOL']} analytical-bound violations |",
    f"| synthesis (Yosys generic gates, no PDK / timing) | baseline 4 x 4: {T['BASE_FF']} flip-flops, {T['BASE_LOGIC']} logic cells, {T['BASE_SRAM']} SRAM-bank bits; integrated with TC02 + TC04: {T['SYS_FF']} flip-flops, {T['SYS_LOGIC']} logic cells; `check -assert` clean ({T['SYN_OK']} / {T['SYN_TOTAL']}), {T['SYN_LATCH']} latches |",
])


# ------------------------------------------------------------------ bandwidth tables for docs/BANDWIDTH.md
def R_(group, config, layout):
    r = find(group, config, layout); return r
L0, L1 = "conflict-free pitch 17 words", "all A lanes in one bank (pitch 8)"
rows_ = ["| `A_STAGE` | `B_STAGE` | conflict-free layout | all four A lanes request the same bank at the first word (pitch 8) | array starvation cycles (worst layout) |", "|---:|---:|---:|---:|---:|"]
for a_ in (2, 4, 8):
    for b_ in (4, 8):
        x, y = R_("staging depth", f"ASTAGE={a_} BSTAGE={b_}", L0), R_("staging depth", f"ASTAGE={a_} BSTAGE={b_}", L1)
        if x and y: rows_.append(f"| {a_} | {b_} | {x['rate']:.4f} | {y['rate']:.4f} | {y['starve']} |")
T["STAGE_TABLE"] = "\n".join(rows_)
rows_ = ["| `READ_LATENCY` | `A_STAGE` / `B_STAGE` | conflict-free | pitch 8 | first slice after the descriptor (cycles) |", "|---:|---|---:|---:|---:|"]
for l_ in (1, 2, 3):
    for ab in ("4/4", "4/8", "8/12"):
        x, y = R_("read latency", f"RLAT={l_} A/B stage={ab}", L0), R_("read latency", f"RLAT={l_} A/B stage={ab}", L1)
        if x and y: rows_.append(f"| {l_} | {ab} | {x['rate']:.4f} | {y['rate']:.4f} | {x['first_latency']} |")
T["RLAT_TABLE"] = "\n".join(rows_)
rows_ = ["| tile length `TK` (slices) | without chaining | with stream chaining (default) | bound |", "|---:|---:|---:|---:|"]
for tk in (4, 8, 16, 32, 64):
    x, y = R_("tile length / stream chaining", "CHAIN=0", f"TK={tk}"), R_("tile length / stream chaining", "CHAIN=1", f"TK={tk}")
    if x and y: rows_.append(f"| {tk} | {x['rate']:.4f} | {y['rate']:.4f} | {y['bound']:.2f} |")
T["CHAIN_TABLE"] = "\n".join(rows_)
rows_ = ["| tile length `TK` (slices) | `CTXQ_DEPTH` = 2 (default) | `CTXQ_DEPTH` = 4 | `CTXQ_DEPTH` = 8 |", "|---:|---:|---:|---:|"]
for tk in (4, 8, 12, 16):
    cells = []
    for q in (2, 4, 8):
        x = R_("context queue depth / short tiles", f"CTXQ={q}", f"TK={tk}")
        cells.append(f"{x['rate']:.4f}" if x else "?")
    rows_.append(f"| {tk} | " + " | ".join(cells) + " |")
T["CTXQ_TABLE"] = "\n".join(rows_)
nb1 = R_("B straddle x NUM_B_BANKS", "NBB=1", "n0=1"); nb2 = R_("B straddle x NUM_B_BANKS", "NBB=2", "n0=1")
T["NBB1_RATE"] = f"{nb1['rate']:.4f}" if nb1 else "?"; T["NBB2_RATE"] = f"{nb2['rate']:.4f}" if nb2 else "?"
a8 = R_("array size", "8x8 NAB=1", "conflict-free pitch 33")
T["A8_RATE"] = f"{a8['rate']:.4f}" if a8 else "?"; T["A8_BOUND"] = f"{a8['bound']:.3f}" if a8 else "?"
n1 = R_("A layout x NUM_A_BANKS", "NAB=1", L1)
T["NAB1_RATE"] = f"{n1['rate']:.4f}" if n1 else "?"; T["NAB1_ASTALL"] = n1["a_rd_stall"] if n1 else "?"; T["NAB1_STARVE"] = n1["starve"] if n1 else "?"
lat = sorted({r["first_latency"] for r in brs if r["group"] in ("A layout x NUM_A_BANKS", "B straddle x NUM_B_BANKS", "tile offsets")})
T["LAT_MIN"], T["LAT_MAX"] = lat[0], lat[-1]
T["LAT_ALL_MAX"] = max(r["first_latency"] for r in brs)
ov = bw.get("overlap", [])
rows_ = ["| buffering | DMA request gaps | cycles | speed-up vs single buffer | DMA words written while a slice was delivered | result |", "|---|---:|---:|---:|---:|---|"]
base_ = {r["dma_gap_pct"]: r["cycles"] for r in ov if r["config"].startswith("single")}
for r in ov:
    sp = f"{base_[r['dma_gap_pct']] / r['cycles']:.2f}x" if r["cycles"] and base_.get(r["dma_gap_pct"]) else "-"
    rows_.append(f"| {r['config']} | {r['dma_gap_pct']} % | {r['cycles']:,} | {sp} | {r['overlap_cycles']} | {'PASS' if r['ok'] else 'FAIL'} |")
T["OVL_TABLE"] = "\n".join(rows_)
def ovl(cfg, gap):
    for r in ov:
        if r["config"].startswith(cfg) and r["dma_gap_pct"] == gap: return r["cycles"]
T["OVL_SINGLE0"], T["OVL_SPLIT0"] = f"{ovl('single', 0):,}", f"{ovl('ping-pong, split', 0):,}"
T["OVL_SP0"] = f"{ovl('single', 0) / ovl('ping-pong, split', 0):.2f}"
T["OVL_SP50"] = f"{ovl('single', 50) / ovl('ping-pong, split', 50):.2f}"; T["OVL_SP80"] = f"{ovl('single', 80) / ovl('ping-pong, split', 80):.2f}"
sh0, sh100 = R_("DMA overlap, split vs shared sets", "SHARED STARVE=8", "DMAW=100%"), R_("DMA overlap, split vs shared sets", "SHARED STARVE=0", "DMAW=100%")
sp100 = R_("DMA overlap, split vs shared sets", "SPLIT", "DMAW=100%")
T["SPLIT100_RATE"], T["SPLIT100_DMA"] = f"{sp100['rate']:.4f}", sp100["dma_words"]
T["SH8_100_RATE"], T["SH8_100_DMA"] = f"{sh0['rate']:.4f}", sh0["dma_words"]
T["SH0_100_RATE"] = f"{sh100['rate']:.4f}"
tk8, tk4 = R_("tile length / stream chaining", "CHAIN=1", "TK=8"), R_("tile length / stream chaining", "CHAIN=1", "TK=4")
T["TK8_RATE"], T["TK4_RATE"] = f"{tk8['rate']:.3f}", f"{tk4['rate']:.3f}"
body = open(os.path.join(ROOT, "reports", "bandwidth.md")).read().split("\n", 1)[1]
T["BW_BODY"] = body

# review summary (written by hand after the independent review)
rv = os.path.join(ROOT, "docs", "src", "review_summary.txt")
T["REVIEW_SUMMARY"] = open(rv).read().strip() if os.path.exists(rv) else "not recorded"

# ------------------------------------------------------------------ render
for tpl, out in (("README.tpl", "README.md"), ("VERIFICATION.tpl", "docs/VERIFICATION.md"), ("BANDWIDTH.tpl", "docs/BANDWIDTH.md"), ("SYNTHESIS.tpl", "docs/SYNTHESIS.md")):
    p = os.path.join(ROOT, "docs", "src", tpl)
    if not os.path.exists(p): print("skip", tpl); continue
    s = open(p).read()
    s = re.sub(r"\{\{(\w+)\}\}", lambda m: str(T.get(m.group(1), f"<<{m.group(1)}?>>")), s)
    open(os.path.join(ROOT, out), "w").write(s)
    left = re.findall(r"<<(\w+)\?>>", s)
    print("wrote", out, ("UNRESOLVED: " + ",".join(left)) if left else "")
