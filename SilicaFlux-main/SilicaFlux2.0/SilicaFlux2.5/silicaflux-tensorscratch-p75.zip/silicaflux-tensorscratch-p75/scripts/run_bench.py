#!/usr/bin/env python3
"""Operand-bandwidth benchmark sweep for sf_tensor_scratchpad.

    python3 scripts/run_bench.py [--jobs 4]          ->  reports/bandwidth.json, reports/bandwidth.csv, reports/bandwidth.md

Every row is a Verilator RTL-simulation run of tb/tb_ts_bench.sv (self-checking: every slice is compared with the deterministic operand function,
errors must be 0).  Measured: sustained slices/cycle from the first to the last delivered slice, tile boundaries included, and the event counters.
Each row is compared with the analytical UPPER BOUND of model/bw_model.py (measured <= bound must hold).  Nothing here is silicon, FPGA or timing data.
"""
import argparse, csv, hashlib, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "model"))
import bw_model  # noqa: E402

VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD"]
BUILD = os.path.join(ROOT, "build", "bench")


def sh(cmd, timeout=1800):
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout + p.stderr


def build(name, params):
    mdir = os.path.join(BUILD, name); os.makedirs(mdir, exist_ok=True)
    g = [f"-G{k}={v}" for k, v in params.items()]
    rc, out = sh(["verilator"] + VFLAGS + ["-f", "sim/files_rtl.f", "tb/tb_ts_bench.sv", "--top-module", "tb_ts_bench"] + g + ["-Mdir", mdir, "-o", "Vbench"])
    exe = os.path.join(mdir, "Vbench")
    if not os.path.exists(exe):
        raise RuntimeError(f"build {name} failed: " + "\n".join(l for l in out.splitlines() if "%Error" in l)[:400])
    return exe


def parse(line):
    d = {}
    for k, v in re.findall(r"(\w+)=([-\d.]+)", line):
        d[k] = float(v) if "." in v else int(v)
    return d


def run(exe, args):
    rc, out = sh([exe] + args)
    lines = [l for l in out.splitlines() if l.startswith("BENCH ")]
    if not lines:
        raise RuntimeError("no BENCH line: " + out[-300:])
    return parse(lines[0])


# ---------------------------------------------------------------------------------------------------- experiment definition
BASE = dict(R=4, C=4, WB=4, ND=1, SET_MAP=1, NAB=4, NBB=2, RLAT=1, ASTAGE=4, BSTAGE=8, STARVE=8, TILE_K=64, CTXQ=2, CHAIN=1)

def cfg(**kw):
    c = dict(BASE); c.update(kw); return c

EXPS = []   # (group, config params, runtime args list of (label, args))
LAYOUTS = [("conflict-free pitch 17 words", ["+LDA_W=17"]), ("all A lanes in one bank (pitch 8)", ["+LDA_W=8"]), ("pitch 18 (lane pairs share a bank)", ["+LDA_W=18"]),
           ("pitch 19", ["+LDA_W=19"])]
EXPS.append(("A layout x NUM_A_BANKS", [(f"NAB={n}", cfg(NAB=n)) for n in (1, 2, 4, 8)], LAYOUTS))
EXPS.append(("B straddle x NUM_B_BANKS", [(f"NBB={n}", cfg(NBB=n)) for n in (1, 2, 4)], [(f"n0={n}", ["+LDA_W=17", f"+N0={n}"]) for n in range(4)]))
EXPS.append(("staging depth", [(f"ASTAGE={a} BSTAGE={b}", cfg(ASTAGE=a, BSTAGE=b)) for a in (2, 4, 8) for b in (4, 8)], LAYOUTS[:2]))
EXPS.append(("read latency", [(f"RLAT={l} A/B stage={a}/{b}", cfg(RLAT=l, ASTAGE=a, BSTAGE=b)) for l in (1, 2, 3) for a, b in ((4, 4), (4, 8), (8, 12))], LAYOUTS[:2]))
EXPS.append(("tile length / stream chaining", [(f"CHAIN={c}", cfg(CHAIN=c)) for c in (0, 1)], [(f"TK={t}", ["+LDA_W=17", f"+TK={t}", f"+NT={max(8, 512 // t)}"]) for t in (4, 8, 16, 32, 64)]))
EXPS.append(("context queue depth / short tiles", [(f"CTXQ={q}", cfg(CTXQ=q)) for q in (2, 4, 8)], [(f"TK={t}", ["+LDA_W=17", f"+TK={t}", f"+NT={max(8, 512 // t)}"]) for t in (4, 8, 12, 16)]))
EXPS.append(("DMA overlap, split vs shared sets", [("SPLIT", cfg(SET_MAP=1)), ("SHARED STARVE=8", cfg(SET_MAP=0, STARVE=8)), ("SHARED STARVE=2", cfg(SET_MAP=0, STARVE=2)), ("SHARED STARVE=0", cfg(SET_MAP=0, STARVE=0))],
            [(f"DMAW={d}%", ["+LDA_W=17", f"+DMAW={d}"]) for d in (0, 25, 50, 100)] + [("DMAW=100% all-one-bank A", ["+LDA_W=8", "+DMAW=100"])]))
EXPS.append(("array size", [("2x2", cfg(R=2, C=2, NAB=2, NBB=2)), ("4x4", cfg()), ("8x8", cfg(R=8, C=8, NAB=8, NBB=4)), ("8x8 NAB=4", cfg(R=8, C=8, NAB=4, NBB=4)), ("8x8 NAB=1", cfg(R=8, C=8, NAB=1, NBB=4))],
            [("conflict-free pitch 33", ["+LDA_W=33"]), ("pitch 32", ["+LDA_W=32"])]))
EXPS.append(("word size", [("WB=4", cfg()), ("WB=8", cfg(WB=8)), ("WB=16", cfg(WB=16, NAB=2))], [("conflict-free", ["+LDA_W=17"]), ("pitch 16", ["+LDA_W=16"])]))
EXPS.append(("sink back-pressure", [("default", cfg())], [(f"SRDY={s}%", ["+LDA_W=17", f"+SRDY={s}"]) for s in (100, 90, 70, 50)]))
EXPS.append(("tile offsets", [("default", cfg())], [("k0=0", ["+LDA_W=17"]), ("k0=1", ["+LDA_W=17", "+K0=1"]), ("k0=2", ["+LDA_W=17", "+K0=2"]), ("k0=3 n0=3", ["+LDA_W=17", "+K0=3", "+N0=3"]), ("m0=2", ["+LDA_W=17", "+M0=2"])]))


# ---------------------------------------------------------------------------------------------------- workload-level DMA / compute overlap
OVL_CFGS = [("single buffer (no overlap possible)", {"ND": 0}), ("ping-pong, split banks", {"ND": 1, "SET_MAP": 1}), ("ping-pong, shared banks (WR_STARVE_LIMIT 8)", {"ND": 1, "SET_MAP": 0})]
OVL_PROBLEM = ["+NPROB=1", "+M=16", "+N=12", "+K=96", "+BM=16", "+BN=12", "+BK=32", "+TK=32", "+PADA=0", "+PADB=0", "+OFFA=0", "+OFFB=0", "+MPAD=0", "+KPAD=0", "+NPAD=0", "+seed=3"]
OVL_GAPS = [0, 50, 80]


def overlap_experiment(jobs):
    """A fixed GEMM (16 x 12 x 96: 3 operand blocks, 12 output tiles) through the REAL TENSORCORE 02 array and TENSORCORE 04 accumulator.  The only things that change are the buffering
    and the DMA request-gap probability.  Cycles are from the first fill to the last committed row."""
    out = []
    def one(item):
        cname, ov, gap = item
        g = [f"-G{k}={v}" for k, v in ov.items()]
        mdir = os.path.join(BUILD, "ovl_" + hashlib.sha1((cname).encode()).hexdigest()[:8]); os.makedirs(mdir, exist_ok=True)
        exe = os.path.join(mdir, "Vtb_ts_system")
        if not os.path.exists(exe):
            rc, o = sh(["verilator"] + VFLAGS + ["-f", "sim/files_sys.f", "tb/tb_ts_system.sv", "--top-module", "tb_ts_system"] + g + ["-Mdir", mdir, "-o", "Vtb_ts_system"])
        rc, o = sh([exe] + OVL_PROBLEM + [f"+DGAP={gap}"])
        m = re.search(r"PROBLEM 0 done in (\d+) cycles: slices=(\d+)", o)
        ev = {k: int(v) for k, v in re.findall(r"^PERF (\w+) (\d+)$", o, re.M)}
        return dict(config=cname, dma_gap_pct=gap, ok="TB_RESULT PASS" in o, cycles=int(m.group(1)) if m else None, slices=int(m.group(2)) if m else None,
                    overlap_cycles=ev.get("overlap"), dma_words=ev.get("dma_wr_words"), dma_wr_stall=ev.get("dma_wr_stall"), rd_wr_block=ev.get("rd_wr_block"), starve=ev.get("starve"))
    items = [(c, ov, g) for c, ov in OVL_CFGS for g in OVL_GAPS]
    # build each configuration once before the parallel runs
    for c, ov in OVL_CFGS: one((c, ov, 0))
    with ThreadPoolExecutor(jobs) as ex:
        out = list(ex.map(one, items))
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--jobs", type=int, default=4); a = ap.parse_args()
    os.makedirs(BUILD, exist_ok=True); os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    # build each distinct configuration once
    items = []
    for group, configs, layouts in EXPS:
        for cname, params in configs:
            for label, args in layouts:
                items.append((group, cname, params, label, args))
    exes = {}
    uniq = {json.dumps(p, sort_keys=True): p for _, _, p, _, _ in items}
    t0 = time.time()
    def b(k):
        name = "c" + hashlib.sha1(k.encode()).hexdigest()[:10]
        return k, build(name, uniq[k])
    with ThreadPoolExecutor(a.jobs) as ex:
        for k, e in ex.map(b, list(uniq)): exes[k] = e
    print(f"built {len(exes)} configurations in {time.time() - t0:.0f} s", flush=True)

    def runone(item):
        group, cname, params, label, args = item
        full = list(args)
        if not any(x.startswith("+NT=") for x in full): full.append("+NT=32")
        r = run(exes[json.dumps(params, sort_keys=True)], full)
        # analytical bound (per-tile bank load, model/bw_model.py)
        bound, info = bw_model.rate_bound(R=params["R"], C=params["C"], WB=params["WB"], EB=1, NAB=params["NAB"], NBB=params["NBB"], LDA_W=r["LDA_W"], LDB_W=r["LDB_W"],
                                          M0=r["M0"], N0=r["N0"], K0=r["K0"], TK=r["TK"])
        return dict(group=group, config=cname, layout=label, bound=round(bound, 4), **info, **r)
    with ThreadPoolExecutor(a.jobs) as ex:
        rows = list(ex.map(runone, items))
    bad = [r for r in rows if r["errors"] != 0]
    viol = [r for r in rows if r["rate"] > r["bound"] + 0.002]
    ovl = overlap_experiment(a.jobs)
    print("overlap experiment:", len(ovl), "runs,", sum(not r["ok"] for r in ovl), "failures", flush=True)
    json.dump(dict(rows=rows, errors=len(bad), bound_violations=len(viol), overlap=ovl), open(os.path.join(ROOT, "reports", "bandwidth.json"), "w"), indent=1)
    keys = ["group", "config", "layout", "R", "C", "WB", "ND", "SET_MAP", "NAB", "NBB", "RLAT", "ASTAGE", "BSTAGE", "STARVE", "LDA_W", "N0", "K0", "TK", "NT", "DMAW", "SRDY", "slices", "span", "rate", "bound", "operands_per_cycle",
            "first_latency", "starve", "starve_a", "starve_b", "a_rd_stall", "b_rd_stall", "a_conf", "b_conf", "rd_wr_block", "dma_wr_stall", "dma_forced", "overlap", "bp", "dma_words", "errors"]
    with open(os.path.join(ROOT, "reports", "bandwidth.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(keys)
        for r in rows: w.writerow([r.get(k, "") for k in keys])
    write_md(rows, bad, viol, ovl)
    print(f"{len(rows)} runs, {len(bad)} data errors, {len(viol)} bound violations")
    return 1 if bad or viol else 0


def write_md(rows, bad, viol, ovl):
    L = ["# Operand bandwidth (generated by scripts/run_bench.py)", "",
         f"{len(rows)} RTL-simulation runs of `tb/tb_ts_bench.sv` (Verilator).  Every slice of every run was checked against the operand function: **{len(bad)} data errors**.",
         f"Every measured rate was compared with the analytical upper bound of `model/bw_model.py`: **{len(viol)} violations** (a violation would mean the model or the RTL is wrong).",
         "`rate` = sustained slices per cycle from the first to the last delivered slice (tile boundaries included); `operands/cycle` = rate x (ARRAY_ROWS + ARRAY_COLS).",
         "These are RTL cycle counts, not time: no clock frequency is implied.  Bound = bank-port demand only (no staging, DMA, boundaries).", ""]
    groups = []
    for r in rows:
        if r["group"] not in groups: groups.append(r["group"])
    for g in groups:
        rs = [r for r in rows if r["group"] == g]
        L += [f"## {g}", "", "| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |", "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for r in rs:
            L.append(f"| {r['config']} | {r['layout']} | {r['rate']:.4f} | {r['operands_per_cycle']:.3f} | {r['bound']:.3f} | {r['first_latency']} | {r['starve']} | {r['a_rd_stall']} | {r['b_rd_stall']} | {r['a_conf']} | {r['b_conf']} | {r['rd_wr_block']} | {r['dma_wr_stall']} | {r['dma_words']} | {r['overlap']} |")
        L.append("")
    L += ["## Workload-level DMA / compute overlap (real TENSORCORE 02 array + TENSORCORE 04 accumulator)", "",
          "Fixed GEMM 16 x 12 x 96 (3 operand blocks of K = 32, 12 output tiles); only the buffering and the DMA request-gap probability change.  Cycles = first fill to last committed row.", "",
          "| buffering | DMA gap % | result | cycles | cycles vs single buffer at the same gap | DMA words written while a slice was delivered (`overlap`) | array starvation cycles |", "|---|---:|---|---:|---:|---:|---:|"]
    base = {r["dma_gap_pct"]: r["cycles"] for r in ovl if r["config"].startswith("single")}
    for r in ovl:
        sp = f"{base[r['dma_gap_pct']] / r['cycles']:.3f}x" if r["cycles"] and base.get(r["dma_gap_pct"]) else "-"
        L.append(f"| {r['config']} | {r['dma_gap_pct']} | {'PASS' if r['ok'] else 'FAIL'} | {r['cycles']} | {sp} | {r['overlap_cycles']} | {r['starve']} |")
    L.append("")
    open(os.path.join(ROOT, "reports", "bandwidth.md"), "w").write("\n".join(L))


if __name__ == "__main__":
    sys.exit(main())
