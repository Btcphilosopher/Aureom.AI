#!/usr/bin/env python3
"""Technology-independent logic synthesis report (Yosys 0.33 generic gates; NO standard-cell library, NO timing, NO PDK, NO place and route).

    python3 scripts/run_synth.py [--jobs 4]      ->  reports/synthesis.json, reports/synthesis.md

Per module / configuration:  hierarchy -check;  synth -flatten -run :fine;  opt;  [memory bits read from the $mem_v2 cells];  techmap;  abc -fast;
`check -assert` (fails on a combinational loop, a multiply-driven net or an undriven used net);  stat.  SRAM ARRAYS STAY $mem CELLS (macro mapping is a physical
design step): the report gives LOGIC cells and FLIP-FLOPS only, and the memory bits split into SRAM bank arrays and small FIFO storages.  Cell counts are
generic-gate counts, not area: no frequency, area in um2 or power is claimed anywhere from these numbers.
"""
import argparse, json, os, re, subprocess, sys, tempfile, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
READ = open(os.path.join(ROOT, "syn", "files_syn.ys")).read().strip()
SYS_FILES = ["integration/ts_tc_system.sv", "third_party/tensorcore02/rtl/tensor_pe.sv", "third_party/tensorcore02/rtl/tensor_skew.sv", "third_party/tensorcore02/rtl/tensor_output_collect.sv",
             "third_party/tensorcore02/rtl/tensor_systolic_array.sv", "third_party/tensorcore04/rtl/tensor_acc_pkg.sv", "third_party/tensorcore04/rtl/tensor_acc_fifo.sv",
             "third_party/tensorcore04/rtl/tensor_accumulator.sv"]

# (label, top, parameter overrides, extra files)
ITEMS = [
    ("sf_ts_agu (ADDR_W=32)",                        "sf_ts_agu", {}, []),
    ("sf_ts_agu (ADDR_W=20)",                        "sf_ts_agu", {"ADDR_W": 20}, []),
    ("sf_ts_stream (4 words x 32 b)",                "sf_ts_stream", {"AWW": 10, "CW": 6, "DW": 32, "DEPTH": 4}, []),
    ("sf_ts_bankgrp A (4 streams, 2x4 banks)",       "sf_ts_bankgrp", {"NS": 4, "NB": 4, "NSETS": 2, "SPLIT": 1, "SET_WORDS": 1024, "DW": 32}, []),
    ("sf_ts_bankgrp B (2 streams, 2x2 banks)",       "sf_ts_bankgrp", {"NS": 2, "NB": 2, "NSETS": 2, "SPLIT": 1, "SET_WORDS": 1024, "DW": 32}, []),
    ("sf_ts_slice (4x4 INT8)",                       "sf_ts_slice", {}, []),
    ("sf_ts_dbuf_ctrl (2 sets)",                     "sf_ts_dbuf_ctrl", {"NSETS": 2}, []),
    ("sf_ts_dma_port (2 sets)",                      "sf_ts_dma_port", {}, []),
    ("sf_ts_accbuf (4x4, 15 slots, 4 banks, WQ 4)",  "sf_ts_accbuf", {"ROWS": 4, "COLS": 4, "ACC_W": 32, "NUM_SLOTS": 15, "NBA": 4, "WQ_DEPTH": 4}, []),
    ("sf_ts_abuf_ctrl (4 lanes)",                    "sf_ts_abuf_ctrl", {"R": 4, "NB": 4, "NSETS": 2, "SPLIT": 1, "SET_WORDS": 1024}, []),
    ("sf_ts_bbuf_ctrl (2 word columns)",             "sf_ts_bbuf_ctrl", {"NWB": 2, "NB": 2, "NSETS": 2, "SPLIT": 1, "SET_WORDS": 1024}, []),
    ("sf_tensor_scratchpad baseline 4x4 INT8/INT32, ping-pong split", "sf_tensor_scratchpad", {}, []),
    ("  ... single buffer",                          "sf_tensor_scratchpad", {"ENABLE_DOUBLE_BUFFERING": 0}, []),
    ("  ... ping-pong shared banks",                 "sf_tensor_scratchpad", {"SET_MAP": 0}, []),
    ("  ... ADDR_W=20",                              "sf_tensor_scratchpad", {"ADDR_W": 20}, []),
    ("  ... ACC_WIDTH=48 (wider format)",            "sf_tensor_scratchpad", {"ACC_WIDTH": 48}, []),
    ("  ... WORD_BYTES=8",                           "sf_tensor_scratchpad", {"WORD_BYTES": 8}, []),
    ("  ... 8x8 array (8 A banks, 4 B banks)",       "sf_tensor_scratchpad", {"ARRAY_ROWS": 8, "ARRAY_COLS": 8, "NUM_A_BANKS": 8, "NUM_B_BANKS": 4, "ACC_BUFFER_BYTES": 2048}, []),
    ("  ... INT16 operands",                         "sf_tensor_scratchpad", {"OPERAND_WIDTH": 16, "ACC_WIDTH": 48}, []),
    ("ts_tc_system: scratchpad + TENSORCORE 02 + TENSORCORE 04 (4x4)", "ts_tc_system", {}, SYS_FILES),
]


def run(item):
    label, top, ov, extra = item
    read = READ + ("\nread_verilog -sv -Irtl " + " ".join(extra) if extra else "")
    ch = "".join(f"chparam -set {k} {v} {top}; " for k, v in ov.items())
    js = tempfile.mktemp(suffix=".json")
    t0 = time.time()
    script = (f"{read}\n{ch}hierarchy -check -top {top}; synth -flatten -run :fine; opt -fast -full; write_json {js}; techmap; opt -fast; abc -fast; opt_clean; "
              f"tee -o /dev/stdout stat; check -assert")
    ys = tempfile.mktemp(suffix=".ys"); open(ys, "w").write(script)
    r = subprocess.run(["yosys", "-q", "-s", ys], cwd=ROOT, capture_output=True, text=True, timeout=3000)
    out = r.stdout + r.stderr
    check_ok = (r.returncode == 0)
    cells = re.search(r"Number of cells:\s+(\d+)", out)
    types = {m.group(1): int(m.group(2)) for m in re.finditer(r"^\s+(\$\S+)\s+(\d+)$", out, re.M)}
    ffs = sum(v for k, v in types.items() if "DFF" in k.upper())
    mem_cells = types.get("$mem_v2", 0)
    logic = sum(v for k, v in types.items() if "DFF" not in k.upper() and not k.startswith("$mem"))
    latches = sum(v for k, v in types.items() if "LATCH" in k.upper()) + len(re.findall(r"Warning: .*latch", out, re.I))
    sram_bits = fifo_bits = 0
    try:
        j = json.load(open(js))
        for mod in j["modules"].values():
            for cn, c in mod["cells"].items():
                if c["type"] == "$mem_v2":
                    bits = int(str(c["parameters"]["WIDTH"]), 2) * int(str(c["parameters"]["SIZE"]), 2)
                    if "u_core" in cn or "u_mem" in cn: sram_bits += bits
                    else: fifo_bits += bits
    except Exception as e:  # noqa
        pass
    for f in (js, ys):
        try: os.remove(f)
        except OSError: pass
    loops = len(re.findall(r"found logic loop|logic loop", out))
    return dict(name=label, top=top, params=ov, status="OK" if (check_ok and cells) else "FAIL", total_cells=int(cells.group(1)) if cells else None, flip_flops=ffs, logic_cells=logic,
                mem_cells=mem_cells, sram_bank_bits=sram_bits, fifo_bits=fifo_bits, latches=latches, comb_loops=loops, secs=round(time.time() - t0, 1),
                detail="" if check_ok else out[-500:])


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--jobs", type=int, default=4); a = ap.parse_args()
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with ThreadPoolExecutor(a.jobs) as ex:
        rs = list(ex.map(run, ITEMS))
    tool = subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip()
    json.dump(dict(tool=tool, results=rs), open(os.path.join(ROOT, "reports", "synthesis.json"), "w"), indent=1)
    md = ["# Logic synthesis report (generated by scripts/run_synth.py)", "",
          f"Tool: {tool}.  **Technology-independent generic-gate synthesis only**: no PDK / standard-cell library, no timing, no place and route, no clock frequency, no area in um2, no power.",
          "Yosys `synth -flatten` + `techmap` + `abc -fast`; SRAM arrays remain `$mem` cells (a physical flow maps them to macros), so `logic cells` and `flip-flops` exclude the arrays.",
          "`check -assert` must pass (no combinational loop, no multiply-driven net).  Cell counts are generic-gate counts, NOT area, and are not comparable across tools.", "",
          "| module / configuration | status | flip-flops | logic cells | SRAM bank bits | FIFO bits | latches | comb. loops | s |", "|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in rs:
        md.append(f"| {r['name']} | {r['status']} | {r['flip_flops']} | {r['logic_cells']} | {r['sram_bank_bits']} | {r['fifo_bits']} | {r['latches']} | {r['comb_loops']} | {r['secs']} |")
    open(os.path.join(ROOT, "reports", "synthesis.md"), "w").write("\n".join(md) + "\n")
    for r in rs: print(r["name"], r["status"], r["flip_flops"], r["logic_cells"], r["sram_bank_bits"], r["fifo_bits"], r["latches"], r["comb_loops"], r["detail"][:100])
    return 0 if all(r["status"] == "OK" and r["latches"] == 0 and r["comb_loops"] == 0 for r in rs) else 1


if __name__ == "__main__":
    sys.exit(main())
