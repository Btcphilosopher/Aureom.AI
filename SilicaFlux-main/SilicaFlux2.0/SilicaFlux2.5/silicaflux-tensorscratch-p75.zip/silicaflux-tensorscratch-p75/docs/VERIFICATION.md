# Verification

All results are RTL simulation (Verilator 5.020, Icarus 12) or Yosys 0.33 generic-gate synthesis.  The tables below are **generated from `reports/*.json`** by `scripts/fill_docs.py`; regenerate with
`make regress bench synth`.  Nothing is silicon, FPGA, gate-level or formal data.  Read `docs/KNOWN_LIMITATIONS.md` L4 (the testbenches and the RTL share an author) before weighing the numbers.

## 1. Headline results (final run on the frozen sources)

| check | result |
|---|---|
| Lint, Verilator `-Wall` over 12 parameter sets + Icarus elaboration + 18 illegal-parameter rejections | **31 / 31** |
| Unit / directed: smoke (2 simulators), error + boundary + ownership testbench (2 simulators), accumulator buffer vs TENSORCORE 04 reference storage (12 configurations + 1 on Icarus) | **18 / 18** |
| System runs (DMA -> scratchpad -> real TENSORCORE 02 array -> real TENSORCORE 04 accumulator), 28 configurations x clean / stalled / directed / reset cases | **503 / 503 runs** |
| GEMM problems executed and checked against `numpy` int64 matmul (independent of RTL and testbench) | **2183 problems, 144,348 C elements, 0 mismatches** |
| k-slices delivered and compared with the testbench's own model (every field, every slice) | **288,885** |
| `tb_ts_errors` checks (Verilator, identical count on Icarus) | **463** |
| `tb_ts_acc` checks, accumulator buffer (sum over configurations, Verilator) | **1,622,652** |
| Bandwidth benchmark rows, every slice checked, every rate <= the analytical bound | **125 rows, 0 data errors, 0 bound violations** |
| Synthesis: Yosys `check -assert` (no combinational loop, no multiply-driven net), latches | **20 / 20 items, 0 latches, 0 loops** |

## 2. Brief section 10 -> where each item is tested

| brief item | tested by |
|---|---|
| 4x4 GEMM data delivery | `tb_ts_smoke` (first tile, hand model); every system run (every slice compared with a model computed from the matrices, plus the array's own `s_k` / `align_err` checker); `tb_ts_bench` (data checked in every throughput run) |
| Multiple K chunks | system runs: K split into chunks of `TK` inside a block **and** across operand blocks (the accumulator keeps the partial sums in the buffer between launches); directed `kchunks`, `deepK_stalls` (K = 200), `tileK1` |
| Partial tiles | random M / N / K in every system run (boundary masks in M, N and K); directed `1x1x1`, `tileK1`; `tb_ts_errors` E2 (3 x 2 x 5 tile with offsets) |
| Matrix stride, tile offsets | random pitch padding `padA/padB`, base offsets `offA/offB`, leading rows / columns / K padding `mpad/kpad/npad` (tile origins at arbitrary byte offsets, unwritten poison in the padding); bench `LDA_W`, `N0`, `K0`, `M0` |
| Double buffering | default for all system runs (fill of the next block overlapping compute); `tb_ts_errors` E5 / E6 (ring order, gates, two **different** matrices in the two sets, writes to the active set refused while slices stream); `single` / `shared` / `shared_s0` configurations |
| Bank collisions | `nab1`, `nab2`, `nbb1`, `nab8`, `nbb4` configurations; pitches that put all A lanes in one bank occur naturally in the random layouts; benchmark `A layout x NUM_A_BANKS`, `B straddle x NUM_B_BANKS`; events `A_BANK_CONF`, `B_BANK_CONF` |
| Reset | 5 abort points x 28 configurations: a problem is abandoned mid-flight, everything is reset, the next problem must run clean (`reset@N` cases); every testbench also starts from reset.  Reset is not covered by any property or formal check |
| DMA / compute overlap | `OVERLAP` event > 0 in the double-buffered runs; `tb_ts_bench` with a background DMA master (`DMAW`), split vs shared banks, `WR_STARVE_LIMIT`; DMA write forced against reads in `shared*` |
| Accumulator correctness | (a) **bit-exact lock-step** with TENSORCORE 04's own `tensor_acc_storage` under random read / write / freeze traffic, RD_LAT 1..3, 12 configurations; (b) every committed C row compared with the testbench GEMM; (c) the final tile **read back through the external port** and compared; (d) hazards H1..H6, range and starvation-bound checks (`tb_ts_acc`) |
| Random stalls | profile `stalls`: random `stall_i` on the array, back-pressure on the readout and the commit stream, DMA request gaps and response back-pressure, tile-response back-pressure, duplicate / split DMA writes |
| Out-of-range accesses | `tb_ts_errors` E1 / E2 / E3 (every DMA and tile error code, all priority pairs, exact last-byte boundary accepted / one byte more rejected, ADDR_W overflow); `tb_ts_acc` (slot / row range, accumulator address beyond the buffer) |
| Final matrix vs an independent software GEMM | `model/check_dump.py`: numpy int64 `A @ B` against the C that came out of TENSORCORE 04 for every problem of every system run |

## 3. What was done to make the testbenches able to fail

* **Mutation spot checks** (hand-made, not systematic): swapping the byte selection of the A word in `sf_ts_slice` was caught by the first slice (system testbench); a deliberately false embedded assertion in `sf_ts_bankgrp` fired at the first DMA write (this is what showed that
  Verilator needs `--assert`: an earlier "no assertion fired" run was meaningless).  Both mutants were removed.
* **A real defect found by integration, not by a unit test**: the first accumulator buffer made `st_rd_ready` depend on a bank conflict; integrating the unmodified TENSORCORE 04 produced a Verilator `UNOPTFLAT` on `u_acc.issue_ok`, absent with the reference storage.
  The buffer was redesigned (write buffer + forwarding, ready from registered state only) and `yosys check -assert` on the integrated system is now part of the synthesis report.
* **A performance defect found by the benchmark**: one idle cycle per tile at stream boundaries (1055 cycles for 1024 slices); fixed by stream chaining (1024); `STREAM_CHAIN = 0` keeps the old behaviour for the ablation row.
* **Testbench bugs found while building them** (all fixed, none hid an RTL defect): a driver race with the slot `complete` pulse, a wrong B-set size constant, a Verilator dead-code elimination that removed a side-effecting `pop_front()`, unplannable random shapes counted as failures.
  The regression report lists only the final run; earlier failing runs are not shown.
* **Independent review**: a fresh-context review agent that had not written any of the RTL read all `sf_ts_*` files and the integration wrapper, and tried to break them with its **own** testbenches (a scratchpad-only testbench with an independent byte-level model, random tiles / pitches / origins, an adversarial DMA master, random `s_ready` / response back-pressure; and a variant of `tb_ts_acc` with random `st_en` drops and external writes racing claims): about 70 configurations (R 1..8, C 1..9, 8 / 16-bit operands, `WORD_BYTES` 2..16, 1..8 banks, both set mappings, `READ_LATENCY` 1..3, `TILE_K` 1..33, chaining on / off), about 700 seeded runs plus 90 soak runs, the embedded `SF_ASSERT` checks enabled throughout, and `yosys check -assert` on odd parameter sets.  **It found no data-path defect** (no wrong-k association, lost or duplicated word, FIFO overflow, ownership race or accumulator hazard).  It did find, and these were **fixed and re-verified**:
  (1) a **liveness hazard** - `fill_end` was held off by any request on the DMA port, including requests that decode to an error and are refused without side effect, so a master that kept presenting refused requests blocked the end of the fill forever (all 8 seeds timed out in the reviewer's testbench).  `quiet_o` now ignores requests that do not decode as a legal write; a new test (E5b in `tb_ts_errors`, 463 checks) fails on the old behaviour and passes on the fix;
  (2) **Verilator 5.020 rejected `sf_ts_accbuf` for more than 64 accumulator slots** (a loop reset of a per-slot array; default 4 x 4 INT32 with `ACC_BUFFER_BYTES` = 8192 gives 120 slots).  The slot states are now one packed vector; `tb_ts_acc` with 100 slots builds and passes (138,888 checks);
  (3) the **A bank arbiter's priority mask was 32 bits wide**, wrong for more than 32 array rows (found by lint only; a 40-row run now delivers with 0 errors).
  Left open and documented: with `ARRAY_COLS` >= 16 (INT32) the unmodified third-party `sf_sram_core` needs `--unroll-count 256` (L19); a `release` issued while the host's own external read is still in flight can read the next tile's value (L12, a protocol hole the contract already forbids); `fill_end_ready` / `acc_claim_ready` depend combinationally on the request inputs (`INTERFACES.md`).  The review's own testbenches are not part of this package; its results are reported here as a review outcome, not as package evidence.  One correction to the review: the regression does enable `SF_ASSERT` (the `assert_base` / `assert_shared` configurations), but the other configurations do not.

## 4. Accumulator buffer traffic statistics (`tb_ts_acc`, 60 000 cycles each, Verilator)

| configuration | reads | forwarded from the write buffer | writes | completions | read denials | write freezes | max ext latency in mix | worst ext latency, saturated |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| default | 39936 | 10470 | 45186 | 1433 | 2 | 1376 | 12 | 9 |
| {'NBA': 1} | 31194 | 11718 | 36248 | 885 | 3318 | 11343 | 12 | 12 |
| {'NBA': 2, 'WQ': 2} | 35592 | 5088 | 40114 | 1272 | 284 | 6853 | 12 | 12 |
| {'RD_LAT': 2} | 39936 | 10470 | 45186 | 1433 | 2 | 1376 | 12 | 9 |
| {'RD_LAT': 3, 'NBA': 8} | 41001 | 10367 | 46193 | 1483 | 0 | 429 | 9 | 8 |
| {'ACC_W': 48, 'WQ': 3} | 39891 | 8145 | 45066 | 1432 | 3 | 1590 | 12 | 7 |
| {'ACC_W': 40, 'EXTLIM': 2} | 39527 | 10246 | 45150 | 1448 | 630 | 1445 | 6 | 6 |
| {'AUTO_REL': 1} | 39198 | 8542 | 44848 | 2246 | 0 | 1927 | 0 | None |
| {'NUM_SLOTS': 4, 'ROWS': 3, 'COLS': 5} | 39995 | 9424 | 44943 | 1658 | 2 | 1776 | 12 | 8 |
| {'NUM_SLOTS': 2, 'NBA': 2} | 37755 | 14429 | 42862 | 1254 | 104 | 2773 | 12 | 12 |
| {'RD_LAT': 2, 'NBA': 4, 'WQ': 2} | 39458 | 5568 | 44602 | 1427 | 4 | 2021 | 12 | 11 |
| {'RD_LAT': 3, 'NBA': 4} | 39936 | 10470 | 45186 | 1433 | 2 | 1376 | 12 | 9 |

`write freezes` = cycles in which the write buffer was full and `st_wr_ready` was low (the accumulator freezes for that cycle); `read denials` = cycles in which a starved external access was forced in;
`forwarded` = reads served from the write buffer.  The traffic is a saturating random mix (up to a read and a write every cycle), harsher than the accumulator's real access pattern.

## 5. Per-configuration system results

| config | runs | pass | GEMM problems | C elements | array slices | cycles |
|---|---:|---:|---:|---:|---:|---:|
| base | 18 | 18 | 78 | 4,825 | 10,826 | 82,445 |
| single | 18 | 18 | 78 | 5,264 | 9,258 | 86,518 |
| shared | 18 | 18 | 78 | 5,140 | 10,114 | 68,737 |
| shared_s0 | 18 | 18 | 78 | 4,498 | 8,446 | 61,018 |
| nab1 | 18 | 18 | 78 | 5,296 | 11,004 | 78,874 |
| nab2 | 18 | 18 | 78 | 5,058 | 10,610 | 88,838 |
| nab8 | 18 | 18 | 78 | 4,892 | 10,271 | 75,887 |
| nbb1 | 18 | 18 | 78 | 4,956 | 10,491 | 73,763 |
| nbb4 | 18 | 18 | 78 | 4,825 | 10,826 | 82,445 |
| rlat2 | 18 | 18 | 78 | 4,957 | 9,936 | 74,622 |
| rlat3 | 18 | 18 | 78 | 4,699 | 9,857 | 75,961 |
| stage2 | 18 | 18 | 78 | 5,463 | 11,012 | 86,829 |
| r2c2 | 18 | 18 | 78 | 2,595 | 20,797 | 76,424 |
| r3c5 | 18 | 18 | 78 | 5,420 | 12,447 | 86,275 |
| r8c8 | 17 | 17 | 77 | 13,054 | 6,743 | 84,144 |
| wb8 | 18 | 18 | 78 | 4,423 | 8,642 | 53,924 |
| wb16 | 18 | 18 | 78 | 5,646 | 10,439 | 54,281 |
| ow16 | 18 | 18 | 78 | 4,855 | 10,083 | 101,761 |
| acc48 | 18 | 18 | 78 | 5,071 | 9,689 | 70,753 |
| acc40wq2 | 18 | 18 | 78 | 4,409 | 8,905 | 60,097 |
| rdlat2 | 18 | 18 | 78 | 5,098 | 10,691 | 77,826 |
| rdlat3 | 18 | 18 | 78 | 5,051 | 9,796 | 66,762 |
| nacc1 | 18 | 18 | 78 | 4,962 | 8,964 | 64,148 |
| autorel | 18 | 18 | 78 | 4,470 | 8,570 | 55,535 |
| ctxq3 | 18 | 18 | 78 | 4,189 | 8,089 | 59,235 |
| tilek8 | 18 | 18 | 78 | 4,432 | 9,104 | 81,654 |
| assert_base | 18 | 18 | 78 | 5,561 | 12,072 | 102,109 |
| assert_shared | 18 | 18 | 78 | 5,239 | 11,203 | 80,427 |

## 6. Not verified (see `KNOWN_LIMITATIONS.md`)

Formal properties; gate-level, FPGA or silicon behaviour; timing; TENSORCORE 06 / 07 / Module 07 in the loop; ECC and non-behavioural SRAM backends; K beyond the hundreds in this package's own runs; unaligned pitches (rejected by design).
