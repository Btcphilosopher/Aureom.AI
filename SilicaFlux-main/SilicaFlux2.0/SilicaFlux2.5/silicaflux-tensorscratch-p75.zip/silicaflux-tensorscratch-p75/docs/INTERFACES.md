# Interface contract of `sf_tensor_scratchpad`

Single clock `clk`, asynchronous-assert active-low `rst_n` (the reused TENSORCORE 02 / 04 cores use a synchronous reset: drive both from the same `rst_n`; deassert it synchronously).
`valid / ready`: a transfer happens when both are high in a cycle; a `valid` that is not accepted must be held with an unchanged payload (no cancellation).

## Parameters

| parameter | default | meaning / legal values |
|---|---|---|
| `ARRAY_ROWS`, `ARRAY_COLS` | 4, 4 | array size = A lanes, B lanes; >= 1, need not be powers of two |
| `TILE_K` | 32 | largest `tile_k` one descriptor may request (K-chunk length); larger -> `K_RANGE` |
| `OPERAND_WIDTH` | 8 | 8 or 16 (signed) |
| `ACC_WIDTH` | 32 | accumulator lane width; >= 2*`OPERAND_WIDTH`; 32 INT32, 40 / 48 wider format |
| `A_BUFFER_BYTES`, `B_BUFFER_BYTES` | 8192, 8192 | TOTAL capacity over all sets, powers of two; per set = total / NSETS |
| `ACC_BUFFER_BYTES` | 1024 | accumulator buffer; slots = `ACC_BUFFER_BYTES / (ARRAY_ROWS * ceil((ARRAY_COLS*(ACC_WIDTH+1))/8))` (15 for the baseline); must equal the accumulator's `NUM_TILES` |
| `NUM_A_BANKS`, `NUM_B_BANKS`, `NUM_ACC_BANKS` | 4, 2, 4 | physical 1RW banks per buffer (per set when `SET_MAP`=1), powers of two |
| `ENABLE_DOUBLE_BUFFERING` | 1 | 1: two operand sets (ping-pong); 0: one set |
| `SET_MAP` | 1 | 1 SPLIT banks per set, 0 SHARED banks |
| `WORD_BYTES` | 4 | bank word = DMA beat; power of two, >= max(2, operand bytes) |
| `READ_LATENCY` | 1 | operand bank read latency (`sf_sram_bank` contract) |
| `A_STAGE`, `B_STAGE` | 4, 8 | staged words per A lane / B stream (>= 2) |
| `WR_STARVE_LIMIT` | 8 | cycles a DMA write yields to reads in a shared bank (0 = writes first) |
| `STREAM_CHAIN` | 1 | stream chaining (0 only for the ablation measurement) |
| `ACC_RD_LAT` | 1 | accumulator storage read latency 1..3; must equal `tensor_accumulator` `RD_LAT` |
| `ACC_WQ_DEPTH` | 4 | accumulator write-buffer entries (>= 2) |
| `ACC_EXT_STARVE_LIMIT`, `ACC_AUTO_RELEASE` | 8, 0 | external-access starvation limit; 1 = a completed slot is freed at once (no external drain) |
| `CTXQ_DEPTH` | 2 | tiles addressed / fetched ahead (>= 2) |
| `ADDR_W`, `DMA_BASE`, `IDX_W`, `K_W`, `TAG_W` | 32, 0, 16, 17, 8 | widths; `K_W` = array `K_WIDTH` |
| `BACKEND`, `SIM_INIT` | behavioural, 2 | pass-through to `sf_sram_bank` (only the behavioural backend is verified here) |

Illegal combinations are rejected at elaboration (18 cases tested, `reports/regression.md`).

## DMA fill port (write only)

`dma_req_{valid,ready,we,addr,wdata,wstrb,tag}`, `dma_rsp_{valid,ready,rdata,err,err_code,we,tag}`.  `addr` = `DMA_BASE` + window offset (`ARCHITECTURE.md` section 2); `wdata` = `WORD_BYTES` bytes with byte strobes,
little endian; `addr` must be word aligned.  One response per request, in order; `err_code` 0 OK, 1 RANGE, 2 ALIGN, 6 OWNER, 7 UNSUP; `rdata` = 0.  `dma_req_ready` never depends on `dma_rsp_ready`.

## Ownership

`fill_begin / fill_end / cmp_begin / cmp_end` (`_valid`, `_ready`); outputs `fill_set`, `cmp_set`, `set_state[2*NSETS]` (0 FREE, 1 FILLING, 2 READY, 3 IN_USE).  A command waits (ready low) until its
precondition holds.  `fill_end` additionally waits for a quiet DMA port (no accepted legal write pending and none being presented; requests that decode to an error do not count), `cmp_end` for `engine_idle`.
Combinational paths from inputs: `dma_req_ready` and `fill_end_ready` depend on the `dma_req_*` inputs of the same cycle, and `acc_claim_ready` on the `ext_req_*` inputs; a master must not derive its `dma_req_valid` / `ext_req_*` from these ready signals
in the same cycle (the design itself is loop-free: `yosys check -assert` on the integrated system).

## Tile descriptor and slice stream (TENSORCORE 03 compatible)

`tile_valid / tile_ready`, fields `tile_a_addr, tile_lda, tile_b_addr, tile_ldb` (bytes, **word aligned**, offsets inside the A / B region of the compute set), `tile_m0, tile_n0, tile_k0, tile_mat_m, tile_mat_n, tile_mat_k, tile_k, tile_tag`.
Response `tile_rsp_{valid,ready,tag,err,code,m,n,k}` in descriptor order; for a good tile `m, n, k` = effective sizes = the array's `cfg_m / cfg_n / cfg_k`.  Codes: 0 OK, 1 EMPTY, 2 LD, 3 A_OVF, 4 A_RANGE, 5 B_OVF, 6 B_RANGE, 7 OWNER, 8 ALIGN, 9 K_RANGE.
A rejected tile produces no slice and touches no memory.

Slice stream (to the array's `s_*`): `s_valid / s_ready`, `s_a` (R operands), `s_b` (C operands), `s_k`, `s_kg`, `s_m0`, `s_n0`, `s_row_mask`, `s_col_mask`, `s_first`, `s_last`, `s_tag`, `s_set`.  Stable while `s_ready` is low.

## Accumulator storage interface (to `tensor_accumulator` `st_*`)

`acc_st_en, acc_st_rd_req, acc_st_rd_addr, acc_st_rd_ready, acc_st_rd_data, acc_st_wr_req, acc_st_wr_addr, acc_st_wr_data, acc_st_wr_ready` - the contract of `tensor_acc_storage.sv` (entry = `slot*ROWS+row`;
read data `RD_LAT` enabled cycles after an accepted read, held while `acc_st_en = 0`; a read in the cycle of a write to the same entry sees the old value; a write is visible from the next cycle).
`acc_st_rd_ready` and `acc_st_wr_ready` depend on registered state only.

## Accumulator slot ownership and external port

`acc_claim_{valid,ready,slot}` (reserve a FREE slot before opening it in the accumulator), `acc_complete_{valid,slot}` (wire `cmt_done / cmt_slot`), `acc_release_{valid,slot}`, `acc_slot_state[2*NUM_SLOTS]`
(0 FREE, 1 ACTIVE, 2 COMPLETE).  External port (one tile row = one entry per access, single outstanding): `ext_req_{valid,ready,we,slot,row,wdata}`, `ext_rsp_{valid,ready,rdata,we,err,code}`; codes 0 OK, 1 RANGE, 2 OWNER.
Read is legal on a COMPLETE slot, write on a FREE slot.  `acc_viol_sticky[3:0]`: H1 write to a non-ACTIVE slot (blocked), H2 read of a non-ACTIVE slot, H6 bad complete / release, address out of range.
Release only **after** the last external read response.

## Status / performance

`busy`, `engine_idle`, `ev_inc[30*8]` (events per cycle, `rtl/sf_ts_defs.svh`), `perf_clear`, `perf_cnt[30*32]` (saturating).
