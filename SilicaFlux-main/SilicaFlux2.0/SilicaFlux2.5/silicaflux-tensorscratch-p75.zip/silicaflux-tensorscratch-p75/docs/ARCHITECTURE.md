# Architecture of `sf_tensor_scratchpad`

Notation: R = `ARRAY_ROWS`, C = `ARRAY_COLS`, EB = operand bytes (1 for INT8), WB = `WORD_BYTES` (bank word, default 4), EPW = WB/EB elements per word, NSETS = 1 or 2 operand sets.

```
 DMA fill port ──► sf_ts_dma_port ──┬─► A bank group  (sf_ts_bankgrp: NUM_A_BANKS x 1RW sf_sram_bank, per set when SPLIT) ─► R lane streams ─┐
 (Module 04 port protocol)          └─► B bank group  (NUM_B_BANKS x 1RW sf_sram_bank)                       ─► NWB word streams ─┤
                                                                                                                                 ▼
 tile descriptor ─► sf_ts_agu ─► context queue ─► fetch sequencer (loads all streams)   sf_ts_slice  ─► s_* k-slices ─► TENSORCORE 02 array
 fill_/cmp_ commands ─► sf_ts_dbuf_ctrl  (FREE / FILLING / READY / IN_USE per set)                                          │ readout m_*
                                                                                                                             ▼
 TENSORCORE 04 st_* storage interface  ◄──►  sf_ts_accbuf  (NUM_ACC_BANKS x 1RW banks + write buffer, slot ownership, external port)  ◄─ tensor_accumulator
```

Files: `sf_ts_bank` (wrapper of the reused `sf_sram_bank`), `sf_ts_stream`, `sf_ts_bankgrp`, `sf_ts_abuf_ctrl` / `sf_ts_bbuf_ctrl` (A / B buffer controllers), `sf_ts_agu`, `sf_ts_slice`,
`sf_ts_dma_port`, `sf_ts_dbuf_ctrl`, `sf_ts_accbuf`, `sf_ts_perf`, top `sf_tensor_scratchpad`; reference integration `integration/ts_tc_system.sv`.

## 1. Bandwidth arithmetic: why this is legal single-port banking (brief section 4)

The array wants one slice per cycle = R A bytes + C B bytes (8 INT8 operands for 4 x 4).  **No bank is ever asked for more than one access per cycle**; the bandwidth comes from
(a) reading *words*, (b) spending each word over several slices, (c) using several banks in the same cycle.

* **A.**  Lane *i* (matrix row *m0+i*) needs element *k* of its row each slice.  One bank read returns a whole word = EPW consecutive elements (4 for INT8), so a lane needs
  **one read per EPW slices**.  R lanes -> R/EPW reads per slice (1.0 for 4 x 4 INT8): an average of one bank read per cycle spread over the banks.  Banks are word-interleaved (`bank = word mod NUM_A_BANKS`); lane *i*'s words are `wA0 + i*SA + j` with `SA = lda/WB`.
  If `SA` is a multiple of `NUM_A_BANKS` the lanes all request the same bank at their first word and arbitration serialises them - but that **staggers** the lanes in time, and each lane
  then sweeps consecutive words, i.e. consecutive banks.  What bounds the rate in steady state is therefore the *total reads per bank over the tile*, not the instantaneous collision;
  the instantaneous collision costs a transient that the lane FIFOs (`A_STAGE`) and the B FIFOs (`B_STAGE`) absorb (measured, `docs/BANDWIDTH.md`).  A first model that bounded the rate by the instantaneous
  collision was falsified by the benchmark (it predicted 0.5 for an 8 x 8 array that sustains 0.94) and was replaced.
* **B.**  Every slice needs the C elements of **one** B row (`n0 .. n0+C-1`, contiguous in row `k0+k`).  That is **one word** when the segment does not cross a word boundary
  (`(n0*EB mod WB) + C*EB <= WB`) and **two consecutive words** when it does (NWB = 2 for 4 x 4 INT8 / 4-byte words).  Consecutive words are in different banks, so two banks are
  read in the same cycle; with `NUM_B_BANKS = 1` the single bank would have to do 2 reads per slice: rate 1/2 (measured).
* The A and B bank groups are **separate physical banks**, so A and B reads never contend with each other; the only other client is the DMA write.
* `model/bw_model.py` turns this into an analytical **upper bound** on the rate: for the exact set of words a tile reads, `rate <= eff_k / (reads of the busiest bank per tile)` for A and for B
  (a single-port bank serves one read per cycle, a tile needs at least `eff_k` cycles); every benchmark row is checked against it.

## 2. Storage layout

A set holds an A region and a B region of `A_BUFFER_BYTES/NSETS` and `B_BUFFER_BYTES/NSETS` bytes (powers of two).  Matrices are stored **row-major in the order the DMA writes them**, with
the leading dimension chosen by the descriptor (`lda`, `ldb` bytes).  Set-relative word `w = byte / WB`; bank = `w mod NB`, row = `w / NB`.

| `SET_MAP` | meaning |
|---|---|
| `1` SPLIT (default, with double buffering) | set *s* has its own physical banks: a DMA fill of one set and compute reads of the other can never touch the same bank (no conflict at all) |
| `0` SHARED | both sets share the banks, the set is the MSB of the physical row: fill and compute contend for the 1RW bank port; the read wins, a waiting DMA write is forced in after `WR_STARVE_LIMIT` cycles (0 = writes first); every case is counted |

DMA window (byte addresses, offset = addr - `DMA_BASE`): A region `[0, NSETS*A_SET)`, B region `[REGION, REGION + NSETS*B_SET)` with `REGION = max(A_TOT, B_TOT)`; anything else is `RANGE`.

## 3. Tile address generation and validation (`sf_ts_agu`, brief section 5)

Descriptor -> `eff_m, eff_n, eff_k` (boundary masks), word-granular stream parameters, or an error.  First match wins:
`OWNER` (no set IN_USE) > `EMPTY` > `LD` (`lda < mat_k*EB` or `ldb < mat_n*EB`) > `ALIGN` > `K_RANGE` (`tile_k > TILE_K`) > `A_OVF` > `A_RANGE` > `B_OVF` > `B_RANGE`.

**No request crosses an allocated buffer boundary.**  The last byte a tile touches is its largest address (`lda, ldb >= 0`):
`Alast = a_addr + (m0+eff_m-1)*lda + (k0+eff_k)*EB - 1`, `Blast = b_addr + (k0+eff_k-1)*ldb + (n0+eff_n)*EB - 1`.  `Alast >= A_SET_BYTES` (or the B equivalent) rejects the descriptor before any access;
a set is a whole number of words, so "last byte inside the set" bounds every word read.  The arithmetic is `ADDR_W + max(IDX_W,K_W) + 4` bits wide (53 by default), so an overflow is detected
(`A_OVF` / `B_OVF`) and cannot wrap.  `tb_ts_errors.sv` checks that a tile ending exactly at `SET_BYTES-1` is accepted and delivered correctly and one byte more is rejected.
Cost: one shared 18 x 32 multiplier, 4 products, 8 cycles per descriptor (hidden by the context queue).

## 4. Streams, credits and chaining (`sf_ts_stream`)

A stream is an arithmetic sequence of words `base, base+stride, ...` (count) with a small FIFO (`A_STAGE` / `B_STAGE` words).  A lane is `base = wA0 + i*SA, stride 1, count NWA`;
a B word column *j* is `base = wB0 + j, stride SB = ldb/WB, count eff_k`.  Credits: *staged + in-flight < depth*, so a response can never find a full FIFO (`sf_sram_bank` has no response
back-pressure).  Responses of one stream come back in request order (all banks have the same fixed read latency).

**Stream chaining.**  A stream is "idle" in the cycle of its *last grant*, and the fetch sequencer loads the next tile's configuration in that same cycle, so the first request of tile *n+1* directly
follows the last request of tile *n*.  Before this (idle one cycle later) the benchmark measured 1055 cycles for 1024 slices (32 tiles of 32), i.e. one bubble per tile; with it 1024.
`STREAM_CHAIN = 0` restores the old behaviour for the ablation measurement.

## 5. Fetch sequencing and the context queue

`AGU -> context queue (CTXQ_DEPTH entries) -> fetch (loads A and B streams when both can take a configuration) -> slice assembler`.  Three pointers (write, fetch, assemble) give
"tile *n+1* is addressed and fetched while tile *n* streams".  A descriptor is accepted only if there is room for its context **and** its response, counting the one still in flight, so the
queues cannot overflow.  Tile responses (including errors) come back in descriptor order.

## 6. k alignment and back-pressure (`sf_ts_slice`, brief section 6)

The A lanes and B streams fetch independently and arrive at different times.  A slice is emitted **only when every live A lane and every live B stream has the word that holds its element
for the same `k`** and the output register is free (`go`); nothing is consumed otherwise.  Lane *i* supplies element `(a_off + kcnt) mod EPW` of its head word; the head is popped after
the word's last element or after the tile's last slice; B streams pop on every slice.  The pop pattern is a pure function of the slice counter `kcnt`, so *which k an operand is taken for* can
never depend on FIFO timing.  Each slice carries `s_k` (= the array's expected `s_k`, checked by the array's own aligner), `s_kg = k0 + k`, `s_m0 / s_n0`, row / column masks (dead lanes forced to 0),
`s_first / s_last` and the tag.  The output register holds everything stable while `s_ready` is low (checked in every system run).  The scratchpad delivers **un-skewed** slices; the array skews (`AUDIT.md` section 2).

## 7. DMA port and ownership (`sf_ts_dma_port`, `sf_ts_dbuf_ctrl`, brief section 7)

* DMA: write-only Module 04 port; checks `RANGE (1) > ALIGN (2) > UNSUP (7, a read) > OWNER (6, set not FILLING)`, none with a side effect; exactly one response per request, in order (errors pass through the
  same hold stage); the response means the write is **committed** in its bank; a write is presented to a bank only when its response can be queued.
* Sets: `FREE -> FILLING -> READY -> IN_USE -> FREE`, ring order, at most one FILLING and one IN_USE.  `fill_end` waits for a quiet DMA port (no accepted legal write pending, and no request on the port that decodes as a legal write; a request that decodes to an error is refused without side effect and does not hold it off) so a write can never be
  accepted against a set that is about to leave FILLING; `cmp_end` waits for the engine (no queued, fetched or in-flight tile of the set, output register empty) so a set is never released while a read of it is
  outstanding.  A DMA write to a READY / IN_USE / FREE set is refused with `OWNER` and changes nothing - checked **while slices stream** (`tb_ts_errors.sv` E4).
* `NSETS = 1` makes the four phases strictly sequential.

## 8. Accumulator buffer (`sf_ts_accbuf`, brief section 8)

See the header of `rtl/sf_ts_accbuf.sv` (kept next to the code because it states the contract).  Summary: backing store of the TENSORCORE 04 `st_*` interface, **no adder** (TC04 adds each K chunk exactly once;
adding here would add a partial sum twice), single-port banks behind the "one read + one write per cycle" contract through a 4-entry write buffer with read forwarding, ready signals from registered state only,
slot ownership FREE -> ACTIVE -> COMPLETE -> FREE with hazards H1..H6 enforced, an external read / write port with a guaranteed completion bound, optional wider lanes (`ACC_WIDTH` 40 / 48).
"K-chunk continuation", "output tile indexing" and "completion tracking" are the TC04 slot / chunk protocol plus the slot states here; "prevent the same partial sum from being added twice" is TC04's chunk sequencing -
this module's contribution is to never corrupt, duplicate or lose a stored entry (lock-step equivalence with TC04's reference storage, `docs/VERIFICATION.md`).

## 9. Events (brief section 9)

30 events, `ev_inc[EV_W=8 per event]` (multi-event increments, Module 07 `inc_i` style) and local saturating counters `perf_cnt`:
compute starvation (`STARVE`, `STARVE_A`, `STARVE_B`), A-buffer / B-buffer stalls (`A_RD_STALL`, `B_RD_STALL`), bank conflicts (`A_BANK_CONF`, `B_BANK_CONF`), DMA conflicts (`RD_WR_BLOCK`, `DMA_WR_STALL`, `DMA_WR_FORCE`),
overlap (`OVERLAP` = a DMA word written in a cycle in which a slice was delivered), accumulator stalls (`ACC_RD_DENY`, `ACC_WR_FRZ`) and accumulator external-port waits / errors / violations.  Definitions: `rtl/sf_ts_defs.svh`.

## 10. Latency

Tile accept -> first slice: 14 cycles (aligned B) .. 17 cycles (measured, 4 x 4, `READ_LATENCY` 1; up to 21 for the other swept configurations): 8 AGU cycles + context / fetch + one bank read + FIFO + output register.  Hidden for tile *n+1* by the context queue.
