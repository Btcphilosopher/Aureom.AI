# Verification

All results are RTL simulation (Verilator 5.020, Icarus 12) or Yosys 0.33 generic-gate synthesis.  The tables below are **generated from `reports/*.json`** by `scripts/fill_docs.py`; regenerate with
`make regress bench synth`.  Nothing is silicon, FPGA, gate-level or formal data.  Read `docs/KNOWN_LIMITATIONS.md` L4 (the testbenches and the RTL share an author) before weighing the numbers.

## 1. Headline results (final run on the frozen sources)

| check | result |
|---|---|
| Lint, Verilator `-Wall` over 12 parameter sets + Icarus elaboration + 18 illegal-parameter rejections | **{{LINT_PASS}} / {{LINT_TOTAL}}** |
| Unit / directed: smoke (2 simulators), error + boundary + ownership testbench (2 simulators), accumulator buffer vs TENSORCORE 04 reference storage ({{ACC_CFGS}} configurations + 1 on Icarus) | **{{UNIT_PASS}} / {{UNIT_TOTAL}}** |
| System runs (DMA -> scratchpad -> real TENSORCORE 02 array -> real TENSORCORE 04 accumulator), {{SYS_CONFIGS}} configurations x clean / stalled / directed / reset cases | **{{SYS_PASS}} / {{SYS_RUNS}} runs** |
| GEMM problems executed and checked against `numpy` int64 matmul (independent of RTL and testbench) | **{{SYS_PROBLEMS}} problems, {{SYS_ELEMS}} C elements, 0 mismatches** |
| k-slices delivered and compared with the testbench's own model (every field, every slice) | **{{SYS_SLICES}}** |
| `tb_ts_errors` checks (Verilator, identical count on Icarus) | **{{ERR_CHECKS}}** |
| `tb_ts_acc` checks, accumulator buffer (sum over configurations, Verilator) | **{{ACC_CHECKS}}** |
| Bandwidth benchmark rows, every slice checked, every rate <= the analytical bound | **{{BENCH_RUNS}} rows, {{BENCH_ERR}} data errors, {{BENCH_VIOL}} bound violations** |
| Synthesis: Yosys `check -assert` (no combinational loop, no multiply-driven net), latches | **{{SYN_OK}} / {{SYN_TOTAL}} items, {{SYN_LATCH}} latches, {{SYN_LOOPS}} loops** |

## 2. Brief section 10 -> where each item is tested

| brief item | tested by |
|---|---|
| 4x4 GEMM data delivery | `tb_ts_smoke` (first tile, hand model); every system run (every slice compared with a model computed from the matrices, plus the array's own `s_k` / `align_err` checker); `tb_ts_bench` (data checked in every throughput run) |
| Multiple K chunks | system runs: K split into chunks of `TK` inside a block **and** across operand blocks (the accumulator keeps the partial sums in the buffer between launches); directed `kchunks`, `deepK_stalls` (K = 200), `tileK1` |
| Partial tiles | random M / N / K in every system run (boundary masks in M, N and K); directed `1x1x1`, `tileK1`; `tb_ts_errors` E2 (3 x 2 x 5 tile with offsets) |
| Matrix stride, tile offsets | random pitch padding `padA/padB`, base offsets `offA/offB`, leading rows / columns / K padding `mpad/kpad/npad` (tile origins at arbitrary byte offsets, unwritten poison in the padding); bench `LDA_W`, `N0`, `K0`, `M0` |
| Double buffering | default for all system runs (fill of the next block overlapping compute); `tb_ts_errors` E5 / E6 (ring order, gates, two **different** matrices in the two sets, writes to the active set refused while slices stream); `single` / `shared` / `shared_s0` configurations |
| Bank collisions | `nab1`, `nab2`, `nbb1`, `nab8`, `nbb4` configurations; pitches that put all A lanes in one bank occur naturally in the random layouts; benchmark `A layout x NUM_A_BANKS`, `B straddle x NUM_B_BANKS`; events `A_BANK_CONF`, `B_BANK_CONF` |
| Reset | 5 abort points x 28 configurations: a problem is abandoned mid-flight, everything is reset, the next problem must run clean (`reset@N` cases); every testbench also starts from reset.  Reset is not covered by any property or formal check |
| DMA / compute overlap | `OVERLAP` event > 0 in the double-buffered runs; `tb_ts_bench` with a background DMA master (`DMAW`), split vs shared banks, `WR_STARVE_LIMIT`; DMA write forced against reads in `shared*` |
| Accumulator correctness | (a) **bit-exact lock-step** with TENSORCORE 04's own `tensor_acc_storage` under random read / write / freeze traffic, RD_LAT 1..3, 12 configurations; (b) every committed C row compared with the testbench GEMM; (c) the final tile **read back through the external port** and compared; (d) hazards H1..H6, range and starvation-bound checks (`tb_ts_acc`) |
| Random stalls | profile `stalls`: random `stall_i` on the array, back-pressure on the readout and the commit stream, DMA request gaps and response back-pressure, tile-response back-pressure, duplicate / split DMA writes |
| Out-of-range accesses | `tb_ts_errors` E1 / E2 / E3 (every DMA and tile error code, all priority pairs, exact last-byte boundary accepted / one byte more rejected, ADDR_W overflow); `tb_ts_acc` (slot / row range, accumulator address beyond the buffer) |
| Final matrix vs an independent software GEMM | `model/check_dump.py`: numpy int64 `A @ B` against the C that came out of TENSORCORE 04 for every problem of every system run |

## 3. What was done to make the testbenches able to fail

* **Mutation spot checks** (hand-made, not systematic): swapping the byte selection of the A word in `sf_ts_slice` was caught by the first slice (system testbench); a deliberately false embedded assertion in `sf_ts_bankgrp` fired at the first DMA write (this is what showed that
  Verilator needs `--assert`: an earlier "no assertion fired" run was meaningless).  Both mutants were removed.
* **A real defect found by integration, not by a unit test**: the first accumulator buffer made `st_rd_ready` depend on a bank conflict; integrating the unmodified TENSORCORE 04 produced a Verilator `UNOPTFLAT` on `u_acc.issue_ok`, absent with the reference storage.
  The buffer was redesigned (write buffer + forwarding, ready from registered state only) and `yosys check -assert` on the integrated system is now part of the synthesis report.
* **A performance defect found by the benchmark**: one idle cycle per tile at stream boundaries (1055 cycles for 1024 slices); fixed by stream chaining (1024); `STREAM_CHAIN = 0` keeps the old behaviour for the ablation row.
* **Testbench bugs found while building them** (all fixed, none hid an RTL defect): a driver race with the slot `complete` pulse, a wrong B-set size constant, a Verilator dead-code elimination that removed a side-effecting `pop_front()`, unplannable random shapes counted as failures.
  The regression report lists only the final run; earlier failing runs are not shown.
* **Independent review**: {{REVIEW_SUMMARY}}

## 4. Accumulator buffer traffic statistics (`tb_ts_acc`, 60 000 cycles each, Verilator)

{{ACC_TABLE}}

`write freezes` = cycles in which the write buffer was full and `st_wr_ready` was low (the accumulator freezes for that cycle); `read denials` = cycles in which a starved external access was forced in;
`forwarded` = reads served from the write buffer.  The traffic is a saturating random mix (up to a read and a write every cycle), harsher than the accumulator's real access pattern.

## 5. Per-configuration system results

{{SYS_TABLE}}

## 6. Not verified (see `KNOWN_LIMITATIONS.md`)

Formal properties; gate-level, FPGA or silicon behaviour; timing; TENSORCORE 06 / 07 / Module 07 in the loop; ECC and non-behavioural SRAM backends; K beyond the hundreds in this package's own runs; unaligned pitches (rejected by design).
