# Operand bandwidth, conflicts and starvation (brief sections 4, 7, 9)

Every number here is an **RTL-simulation cycle count** from `tb/tb_ts_bench.sv` (Verilator), generated into `reports/bandwidth.{md,csv,json}` by `scripts/run_bench.py` and inserted by `scripts/fill_docs.py`.
No clock frequency is implied, nothing is silicon or FPGA data, and the DMA / sink in the testbenches are behavioural models.  The benchmark is self-checking: every slice of every run was compared with the operand function
(**{{BENCH_ERR}} data errors in {{BENCH_RUNS}} rows**), so a throughput figure can never come from wrong data.

## 1. Headline

* **Sustained rate, 4 x 4 INT8, default parameters, conflict-free layout: {{BEST_RATE}} slices/cycle = {{BEST_OPC}} operands/cycle** (4 A + 4 B per cycle), measured over 32 back-to-back tiles of 32 slices, tile boundaries included.
* The same tile whose pitch makes all four A lanes request the same bank at their first word (pitch = a multiple of `NUM_A_BANKS` words) sustains **{{WORST_RATE}}** with the default `B_STAGE` = 8; shallower staging loses rate (section 2(b)).
* **No bank is ever asked for more than one access per cycle**: the operand bandwidth comes from word-wide reads shared over four slices (A), one or two consecutive-word reads per slice from separate bank groups (B), and several banks per cycle
  (`ARCHITECTURE.md` section 1).  The benchmark never relies on eight read ports from one SRAM; with a single A bank the *same* 4 x 4 tile still reaches {{NAB1_RATE}} (its 32 word reads per 32 slices exactly fill that bank).
* Tile accept -> first slice: **{{LAT_MIN}}..{{LAT_MAX}} cycles** for the default 4 x 4 layouts measured (the first tile after an idle gap; hidden for later tiles); up to {{LAT_ALL_MAX}} in the other configurations of the sweep (8 x 8 array, `READ_LATENCY` 3).

## 2. What limits the rate, and how each limit was checked

**(a) Bank port capacity** - a necessary condition, modelled in `model/bw_model.py`: a tile reads a known set of words, a single-port bank serves one read per cycle and a tile needs at least `eff_k` cycles, so
`rate <= eff_k / (reads of the busiest bank per tile)` (A and B).  It is an *upper bound*; staging, DMA and tile boundaries can only lower the rate.  Result over all {{BENCH_RUNS}} rows: **{{BENCH_VIOL}} violations**, and it is tight in the two limiting cases that were built to test it:

| case | bound | measured |
|---|---:|---:|
| `NUM_B_BANKS` = 1, B rows straddle a word (two words per slice from one bank) | 0.500 | {{NBB1_RATE}} |
| same layout with `NUM_B_BANKS` = 2 | 1.000 | {{NBB2_RATE}} |
| 8 x 8 array, one A bank (64 word reads per 32 slices) | {{A8_BOUND}} | {{A8_RATE}} |

An earlier model that bounded the rate by "lanes that share a bank at one word step" was **falsified by this benchmark** (it predicted 0.5 for an 8 x 8 array that sustains 0.94): the lanes start in lockstep, arbitration serialises them, and
that staggers them so each lane then sweeps consecutive banks.  The model and the architecture text were corrected (`ARCHITECTURE.md` section 1).

**(b) Staging depth and read latency** - the bound can be 1.0 while the array still loses rate if the FIFOs cannot ride out a transient (a burst of lane refills in one bank, or the bank latency).  Measured:

{{STAGE_TABLE}}

{{RLAT_TABLE}}

`B_STAGE` = 8 is the default because it is the smallest of the tested depths (4, 8, 12) that sustains 1.0000 on the worst A layout at `READ_LATENCY` 1..3; `A_STAGE` = 2 costs rate on that layout; deeper than 8 gained nothing in these runs.

**(c) Tile boundaries and descriptor rate.**  Before the fix, a stream was "idle" one cycle after its last grant and the next tile was loaded a cycle later: one bubble per tile.  **Stream chaining** loads the next tile in the cycle of the last grant.
`STREAM_CHAIN = 0` is kept for this ablation:

{{CHAIN_TABLE}}

Tiles of 16 or more slices now run at the full rate.  **Short tiles are limited by the descriptor path, not by memory**, in two ways (the second table varies the number of tile contexts in flight):

{{CTXQ_TABLE}}

* with `CTXQ_DEPTH` = 2 the accept-to-context latency of the address generator (about 12 cycles) is only hidden behind tiles of at least ~12 slices (`TK` = 8 sustains {{TK8_RATE}});
* a deeper queue fixes that (`TK` = 8 and 12 reach 1.0000 with 4 or 8 contexts), but **`TK` = 4 stays at {{TK4_RATE}} whatever the depth**: the AGU handles one descriptor at a time and needs 8 cycles for it.
  A tile chunk shorter than 8 slices therefore cannot be fed at full rate by this design (a pipelined AGU would be needed).  The default `TILE_K` = 32 is far from that limit.

**(d) Back-pressure from the array** is passed through: with a sink that is ready 90 / 70 / 50 % of the cycles the rate tracks it (0.883 / 0.695 / 0.492 measured, `Sink back-pressure` table below).

## 3. What the counters mean (read this before using them)

* `STARVE` (and `STARVE_A` / `STARVE_B`) counts cycles in which **a tile is active, the output stage is free and operands are missing**: this is the loss of the array to operand delivery.  It does **not** count time the array
  idles because no tile has been addressed yet or no operand set is READY (e.g. while waiting for the DMA); that shows up in total cycles, as in section 5.
* `A_RD_STALL` / `B_RD_STALL` / `*_BANK_CONF` count arbitration events, **not lost slices**: with one A bank and the same tile they read {{NAB1_ASTALL}} stalls while the rate is still {{NAB1_RATE}} and starvation is {{NAB1_STARVE}} cycles
  (startup only).  Use `STARVE` for loss and the stall / conflict counters to explain it.
* `RD_WR_BLOCK`, `DMA_WR_STALL`, `DMA_WR_FORCE` are the DMA / compute conflict events (shared banks only; zero with split banks).
* `ACC_RD_DENY` counts cycles in which the accumulator read port was unavailable (only when a starved external access is forced in); `ACC_WR_FRZ` counts cycles in which the write buffer was full.  `docs/VERIFICATION.md` section 4 has their statistics.

## 4. DMA writes against compute reads (benchmark `DMA overlap, split vs shared sets`)

With split banks (`SET_MAP` = 1) a DMA fill of one set never touches a bank that compute reads: a saturating DMA master writes {{SPLIT100_DMA}} words during 1024 slices and the compute rate stays {{SPLIT100_RATE}}.
With shared banks the 1RW port is contended: reads win, a waiting write is forced in after `WR_STARVE_LIMIT` cycles.  With the default limit of 8 the compute rate stays {{SH8_100_RATE}} even against a saturating writer ({{SH8_100_DMA}} words
written - the banks have idle cycles), but with `WR_STARVE_LIMIT` = 0 (writes first) it falls to **{{SH0_100_RATE}}**.  The policy is therefore a real trade-off and is a parameter.

## 5. Does overlap help? (measured on a workload, real array + accumulator)

A fixed GEMM (16 x 12 x 96: three operand blocks, 12 output tiles) through the real TENSORCORE 02 / 04; only the buffering and the DMA request-gap probability change.  The DMA model writes one word per cycle when it is not gapped.

{{OVL_TABLE}}

With the DMA filling at one word per cycle, ping-pong finishes in {{OVL_SPLIT0}} cycles against {{OVL_SINGLE0}} for a single buffer ({{OVL_SP0}}x); with 50 % / 80 % request gaps the factor is {{OVL_SP50}}x / {{OVL_SP80}}x (the slower the fill, the more the run is
fill-bound and the less compute there is to hide it behind).  Split and shared banks differ by a few percent.  **These factors belong to this workload and this DMA model**; they say that the overlap mechanism works and is worth having, not what a real
DMA would achieve.

## 6. Not claimed

No time-based bandwidth (no clock); no result for DMA masters other than the testbench's; no comparison with TENSORCORE 03; the accumulator-buffer throughput is in `VERIFICATION.md` section 4, not here.

## Appendix: every benchmark row (generated)

{{BW_BODY}}
