# Known limitations and things that are NOT claimed

Read this before relying on any number in this package.

## What the evidence is (and is not)

* **L0  RTL simulation only.**  Every result is from Verilator 5.020 / Icarus 12 RTL simulation, Yosys 0.33 generic-gate synthesis, or a Python model.  There is **no** silicon, FPGA, gate-level, place-and-route, timing,
  clock-frequency, area (um2) or power result, and **no formal proof**.  "Cycles" are RTL cycles.  The synthesis numbers are generic-gate counts (technology independent) and must not be read as area.
* **L1  Name collision.**  `rtl/sf_tensor_scratchpad.sv` here is a **new** design.  The MemoryCore pack (`silicaflux-memorycore-sram`) already contains a *different* module of the same name (a 128-bit-line ownership shim)
  plus `sf_ts_port.sv`.  Do not compile both into one design; rename one if both are needed.  Reused MemoryCore files are copied unmodified (`third_party/PROVENANCE.md`).
* **L2  Not co-simulated with TENSORCORE 06 / 07 or the Module 07 counter bank.**  Compatibility is by protocol and numbering only (`AUDIT.md` section 5).  TENSORCORE 02 (array) and 04 (accumulator) **are** simulated, unmodified.
* **L3  The system testbench is Verilator-only.**  Icarus 12 lacks `return` in tasks and other constructs the testbench uses.  Icarus runs the smoke, error / boundary (identical check count to Verilator) and a short accumulator-buffer
  test; the Icarus runs of the accumulator test are not stimulus-identical to Verilator (a shared PRNG across concurrent processes), only both passing.
* **L4  The testbench shares a developer.**  The scoreboards were written by the same author as the RTL.  Mitigations (all in `docs/VERIFICATION.md`): the expected C comes from an independent numpy matmul, the array and accumulator
  are the unmodified third-party cores, a lock-step comparison against TENSORCORE 04's own reference storage, an independent fresh-agent code review, and mutation spot checks.  The mutation campaign is small (a handful of hand-made
  mutants), not a systematic coverage-driven one.

## Functional limits

* **L5  Accumulator buffer is storage, not an adder.**  Partial sums continue across array launches only through TENSORCORE 04 (it adds each chunk exactly once).  An external write into the buffer is **not** an accumulator preload:
  the accumulator's valid / chunk metadata is internal to it; use its `hc_write` for preloads.  The external port is for draining COMPLETE tiles and for writing FREE slots (initialisation / test).
* **L6  Alignment.**  `a_addr, lda, b_addr, ldb` must be multiples of `WORD_BYTES` (error `ALIGN`); the DMA writes whole aligned words (byte strobes allowed).  TENSORCORE 03 also accepts unaligned bases and pitches.  Tile origins and
  sizes are arbitrary.
* **L7  Buffer sizes are powers of two**; bank counts are powers of two; `WORD_BYTES` is a power of two >= max(2, operand bytes).
* **L8  Operand types.**  Signed INT8 (default) and signed INT16 (tested with a 48-bit array partial sum).  No unsigned, FP or sub-byte types.  Reductions longer than the arrays' limit (`K_WIDTH`, 131071) are not tested here
  (the testbench goes to K = 200 per problem; TENSORCORE 02 / 04 packages test the extremes).
* **L9  ECC, MBIST, ASIC / FPGA backends are not integrated.**  `sf_ts_bank` hard-wires ECC off; the `BACKEND` parameter is passed through to `sf_sram_bank` but only the behavioural backend was simulated.
* **L10  The DMA port is write-only** (reads answer `UNSUP`); there is no read-back path for the A / B buffers.
* **L11  Slot count must be consistent by the integrator.**  `ACC_BUFFER_BYTES` determines the slot count, which must equal `tensor_accumulator` `NUM_TILES` (and `ACC_RD_LAT` its `RD_LAT`); nothing checks that across modules.  `integration/ts_tc_system.sv` derives both from the same parameters.
* **L12  Release discipline.**  The external reader must `acc_release` only after its last read response; a release before that is the reader's bug and can let the accumulator overwrite a row that is still being read.
  Found by the independent review (not simulated, protocol hole rather than a bug under the contract): `release` issued in the cycle an external read is accepted, with the bank busy, can return the *next* tile's value for that row, because the slot may be re-claimed before the read is served.  The accumulator buffer does not defer `release` while its own external read is in flight; the host must wait for the response.
* **L13  Single clock domain**, no clock-domain crossings, no clock gating, no power management.
* **L14  Reset.**  Asserts asynchronously, deassert synchronously; the reused cores reset synchronously (Verilator `SYNCASYNCNET` note on the integration).  Memory contents are **not** reset (never-written rows read as a poison pattern in simulation).
  Reset in the middle of a problem was tested at 5 points, with a clean problem afterwards.

## Performance limits

* **L15  The bandwidth figures are for the configurations measured** (`reports/bandwidth.md`): a conflict-free layout sustains 1.0000 slice/cycle; a layout whose pitch makes all four A lanes request the same bank at their first word (`SA` a multiple of `NUM_A_BANKS`) sustains 1.0000 only with
  `B_STAGE` = 8 (0.943 with `B_STAGE` 4; with `A_STAGE` 2: 0.866 / 0.890 for `B_STAGE` 4 / 8); one B bank halves the rate of straddling rows.  Nothing here says what a *real* DMA can deliver: the fill side is one `WORD_BYTES` word per cycle at best, and
  the testbenches' DMA is a behavioural model.
* **L16  "Overlap" is only a claim where it is measured.**  The `OVERLAP` event counts cycles with a DMA word written and a slice delivered; whether that shortens a *workload* is a separate measurement (`reports/bandwidth.md`, "DMA overlap"),
  and depends entirely on the DMA model's speed.
* **L17  Accumulator buffer throughput** depends on `NUM_ACC_BANKS` relative to `ACC_RD_LAT` (a bank hit by both the drained write and the read serialises them; the 4-entry write buffer absorbs short bursts).  Numbers in `docs/VERIFICATION.md`.
  `ACC_RD_DENY` counts cycles in which the read port was unavailable, not reads that were actually wanted (the accumulator only asserts a read when ready).
* **L18  Descriptor path.**  The AGU handles one descriptor at a time (8 cycles, one shared 18 x 32 multiplier; ~7k generic gates, the second-largest logic block after the accumulator buffer; timing unknown).  Consequences, measured in `docs/BANDWIDTH.md` section 2(c):
  tile chunks shorter than 8 slices cannot be fed at full rate at all, and with `CTXQ_DEPTH` = 2 chunks shorter than ~12 slices cannot either.  Tile accept -> first slice is 14..17 cycles for the default 4 x 4 configuration (up to 21 in the other configurations swept) on the first tile after an idle gap.
  An iterative multiplier would trade area for descriptor latency.

* **L19  Verilator 5.020 unroll limit with wide accumulator rows.**  With `ARRAY_COLS` >= 16 at `ACC_WIDTH` 32 (>= 11 at 48) one accumulator entry needs more than 64 byte lanes and the *unmodified* third-party `sf_sram_core.sv` (line 132) fails to build with `%Error-BLKLOOPINIT`.  `--unroll-count 256` fixes it: an 8 x 16 array was built with that flag and delivered 1024 slices at 1.0000 with 0 data errors (one run, not part of the regression).  Yosys and Icarus were not tried at these sizes.
* **L20  Sizes beyond the default sweep.**  The regression covers up to 8 x 8 arrays; the review and a spot run covered 1..9 columns, up to 8 rows in the sweep, a 40-row bench run (data errors 0, rate bound by the A banks) and an 8 x 16 run.  The accumulator buffer was run with 100 slots.

## Toolchain notes

* Yosys 0.33 cannot parse the `int'(x)` cast or size a signal from a package constant; the RTL avoids both (`32'(x)`, no package references in parameter lists), which is also why `ts_tc_system` leaves the accumulator's performance buses unconnected.
* Verilator ignores `assert` unless `--assert` is given: the embedded checks (`SF_ASSERT`) were verified to fire with a deliberately broken mutant before the clean run was trusted.
* Illegal parameter combinations are rejected at elaboration; `ARRAY_ROWS = 0` is rejected by elaboration errors from zero-width derived signals rather than by a named message.
