# Operand bandwidth, conflicts and starvation (brief sections 4, 7, 9)

Every number here is an **RTL-simulation cycle count** from `tb/tb_ts_bench.sv` (Verilator), generated into `reports/bandwidth.{md,csv,json}` by `scripts/run_bench.py` and inserted by `scripts/fill_docs.py`.
No clock frequency is implied, nothing is silicon or FPGA data, and the DMA / sink in the testbenches are behavioural models.  The benchmark is self-checking: every slice of every run was compared with the operand function
(**0 data errors in 125 rows**), so a throughput figure can never come from wrong data.

## 1. Headline

* **Sustained rate, 4 x 4 INT8, default parameters, conflict-free layout: 1.0000 slices/cycle = 8.000 operands/cycle** (4 A + 4 B per cycle), measured over 32 back-to-back tiles of 32 slices, tile boundaries included.
* The same tile whose pitch makes all four A lanes request the same bank at their first word (pitch = a multiple of `NUM_A_BANKS` words) sustains **1.0000** with the default `B_STAGE` = 8; shallower staging loses rate (section 2(b)).
* **No bank is ever asked for more than one access per cycle**: the operand bandwidth comes from word-wide reads shared over four slices (A), one or two consecutive-word reads per slice from separate bank groups (B), and several banks per cycle
  (`ARCHITECTURE.md` section 1).  The benchmark never relies on eight read ports from one SRAM; with a single A bank the *same* 4 x 4 tile still reaches 1.0000 (its 32 word reads per 32 slices exactly fill that bank).
* Tile accept -> first slice: **14..17 cycles** for the default 4 x 4 layouts measured (the first tile after an idle gap; hidden for later tiles); up to 21 in the other configurations of the sweep (8 x 8 array, `READ_LATENCY` 3).

## 2. What limits the rate, and how each limit was checked

**(a) Bank port capacity** - a necessary condition, modelled in `model/bw_model.py`: a tile reads a known set of words, a single-port bank serves one read per cycle and a tile needs at least `eff_k` cycles, so
`rate <= eff_k / (reads of the busiest bank per tile)` (A and B).  It is an *upper bound*; staging, DMA and tile boundaries can only lower the rate.  Result over all 125 rows: **0 violations**, and it is tight in the two limiting cases that were built to test it:

| case | bound | measured |
|---|---:|---:|
| `NUM_B_BANKS` = 1, B rows straddle a word (two words per slice from one bank) | 0.500 | 0.5002 |
| same layout with `NUM_B_BANKS` = 2 | 1.000 | 1.0000 |
| 8 x 8 array, one A bank (64 word reads per 32 slices) | 0.500 | 0.5010 |

An earlier model that bounded the rate by "lanes that share a bank at one word step" was **falsified by this benchmark** (it predicted 0.5 for an 8 x 8 array that sustains 0.94): the lanes start in lockstep, arbitration serialises them, and
that staggers them so each lane then sweeps consecutive banks.  The model and the architecture text were corrected (`ARCHITECTURE.md` section 1).

**(b) Staging depth and read latency** - the bound can be 1.0 while the array still loses rate if the FIFOs cannot ride out a transient (a burst of lane refills in one bank, or the bank latency).  Measured:

| `A_STAGE` | `B_STAGE` | conflict-free layout | all four A lanes request the same bank at the first word (pitch 8) | array starvation cycles (worst layout) |
|---:|---:|---:|---:|---:|
| 2 | 4 | 1.0000 | 0.8663 | 164 |
| 2 | 8 | 1.0000 | 0.8897 | 133 |
| 4 | 4 | 1.0000 | 0.9429 | 68 |
| 4 | 8 | 1.0000 | 1.0000 | 6 |
| 8 | 4 | 1.0000 | 0.9429 | 68 |
| 8 | 8 | 1.0000 | 1.0000 | 6 |

| `READ_LATENCY` | `A_STAGE` / `B_STAGE` | conflict-free | pitch 8 | first slice after the descriptor (cycles) |
|---:|---|---:|---:|---:|
| 1 | 4/4 | 1.0000 | 0.9429 | 14 |
| 1 | 4/8 | 1.0000 | 1.0000 | 14 |
| 1 | 8/12 | 1.0000 | 1.0000 | 14 |
| 2 | 4/4 | 1.0000 | 0.9167 | 15 |
| 2 | 4/8 | 1.0000 | 1.0000 | 15 |
| 2 | 8/12 | 1.0000 | 1.0000 | 15 |
| 3 | 4/4 | 0.8006 | 0.7636 | 16 |
| 3 | 4/8 | 1.0000 | 1.0000 | 16 |
| 3 | 8/12 | 1.0000 | 1.0000 | 16 |

`B_STAGE` = 8 is the default because it is the smallest of the tested depths (4, 8, 12) that sustains 1.0000 on the worst A layout at `READ_LATENCY` 1..3; `A_STAGE` = 2 costs rate on that layout; deeper than 8 gained nothing in these runs.

**(c) Tile boundaries and descriptor rate.**  Before the fix, a stream was "idle" one cycle after its last grant and the next tile was loaded a cycle later: one bubble per tile.  **Stream chaining** loads the next tile in the cycle of the last grant.
`STREAM_CHAIN = 0` is kept for this ablation:

| tile length `TK` (slices) | without chaining | with stream chaining (default) | bound |
|---:|---:|---:|---:|
| 4 | 0.5020 | 0.5020 | 1.00 |
| 8 | 0.8038 | 0.8050 | 1.00 |
| 16 | 0.9429 | 1.0000 | 1.00 |
| 32 | 0.9715 | 1.0000 | 1.00 |
| 64 | 0.9865 | 1.0000 | 1.00 |

Tiles of 16 or more slices now run at the full rate.  **Short tiles are limited by the descriptor path, not by memory**, in two ways (the second table varies the number of tile contexts in flight):

| tile length `TK` (slices) | `CTXQ_DEPTH` = 2 (default) | `CTXQ_DEPTH` = 4 | `CTXQ_DEPTH` = 8 |
|---:|---:|---:|---:|
| 4 | 0.5020 | 0.5020 | 0.5020 |
| 8 | 0.8050 | 1.0000 | 1.0000 |
| 12 | 1.0000 | 1.0000 | 1.0000 |
| 16 | 1.0000 | 1.0000 | 1.0000 |

* with `CTXQ_DEPTH` = 2 the accept-to-context latency of the address generator (about 12 cycles) is only hidden behind tiles of at least ~12 slices (`TK` = 8 sustains 0.805);
* a deeper queue fixes that (`TK` = 8 and 12 reach 1.0000 with 4 or 8 contexts), but **`TK` = 4 stays at 0.502 whatever the depth**: the AGU handles one descriptor at a time and needs 8 cycles for it.
  A tile chunk shorter than 8 slices therefore cannot be fed at full rate by this design (a pipelined AGU would be needed).  The default `TILE_K` = 32 is far from that limit.

**(d) Back-pressure from the array** is passed through: with a sink that is ready 90 / 70 / 50 % of the cycles the rate tracks it (0.883 / 0.695 / 0.492 measured, `Sink back-pressure` table below).

## 3. What the counters mean (read this before using them)

* `STARVE` (and `STARVE_A` / `STARVE_B`) counts cycles in which **a tile is active, the output stage is free and operands are missing**: this is the loss of the array to operand delivery.  It does **not** count time the array
  idles because no tile has been addressed yet or no operand set is READY (e.g. while waiting for the DMA); that shows up in total cycles, as in section 5.
* `A_RD_STALL` / `B_RD_STALL` / `*_BANK_CONF` count arbitration events, **not lost slices**: with one A bank and the same tile they read 2880 stalls while the rate is still 1.0000 and starvation is 6 cycles
  (startup only).  Use `STARVE` for loss and the stall / conflict counters to explain it.
* `RD_WR_BLOCK`, `DMA_WR_STALL`, `DMA_WR_FORCE` are the DMA / compute conflict events (shared banks only; zero with split banks).
* `ACC_RD_DENY` counts cycles in which the accumulator read port was unavailable (only when a starved external access is forced in); `ACC_WR_FRZ` counts cycles in which the write buffer was full.  `docs/VERIFICATION.md` section 4 has their statistics.

## 4. DMA writes against compute reads (benchmark `DMA overlap, split vs shared sets`)

With split banks (`SET_MAP` = 1) a DMA fill of one set never touches a bank that compute reads: a saturating DMA master writes 1108 words during 1024 slices and the compute rate stays 1.0000.
With shared banks the 1RW port is contended: reads win, a waiting write is forced in after `WR_STARVE_LIMIT` cycles.  With the default limit of 8 the compute rate stays 1.0000 even against a saturating writer (800 words
written - the banks have idle cycles), but with `WR_STARVE_LIMIT` = 0 (writes first) it falls to **0.7763**.  The policy is therefore a real trade-off and is a parameter.

## 5. Does overlap help? (measured on a workload, real array + accumulator)

A fixed GEMM (16 x 12 x 96: three operand blocks, 12 output tiles) through the real TENSORCORE 02 / 04; only the buffering and the DMA request-gap probability change.  The DMA model writes one word per cycle when it is not gapped.

| buffering | DMA request gaps | cycles | speed-up vs single buffer | DMA words written while a slice was delivered | result |
|---|---:|---:|---:|---:|---|
| single buffer (no overlap possible) | 0 % | 3,121 | 1.00x | 0 | PASS |
| single buffer (no overlap possible) | 50 % | 3,842 | 1.00x | 0 | PASS |
| single buffer (no overlap possible) | 80 % | 5,901 | 1.00x | 0 | PASS |
| ping-pong, split banks | 0 % | 2,217 | 1.41x | 297 | PASS |
| ping-pong, split banks | 50 % | 2,573 | 1.49x | 265 | PASS |
| ping-pong, split banks | 80 % | 4,776 | 1.24x | 134 | PASS |
| ping-pong, shared banks (WR_STARVE_LIMIT 8) | 0 % | 2,217 | 1.41x | 285 | PASS |
| ping-pong, shared banks (WR_STARVE_LIMIT 8) | 50 % | 2,650 | 1.45x | 242 | PASS |
| ping-pong, shared banks (WR_STARVE_LIMIT 8) | 80 % | 4,725 | 1.25x | 123 | PASS |

With the DMA filling at one word per cycle, ping-pong finishes in 2,217 cycles against 3,121 for a single buffer (1.41x); with 50 % / 80 % request gaps the factor is 1.49x / 1.24x (the slower the fill, the more the run is
fill-bound and the less compute there is to hide it behind).  Split and shared banks differ by a few percent.  **These factors belong to this workload and this DMA model**; they say that the overlap mechanism works and is worth having, not what a real
DMA would achieve.

## 6. Not claimed

No time-based bandwidth (no clock); no result for DMA masters other than the testbench's; no comparison with TENSORCORE 03; the accumulator-buffer throughput is in `VERIFICATION.md` section 4, not here.

## Appendix: every benchmark row (generated)


125 RTL-simulation runs of `tb/tb_ts_bench.sv` (Verilator).  Every slice of every run was checked against the operand function: **0 data errors**.
Every measured rate was compared with the analytical upper bound of `model/bw_model.py`: **0 violations** (a violation would mean the model or the RTL is wrong).
`rate` = sustained slices per cycle from the first to the last delivered slice (tile boundaries included); `operands/cycle` = rate x (ARRAY_ROWS + ARRAY_COLS).
These are RTL cycle counts, not time: no clock frequency is implied.  Bound = bank-port demand only (no staging, DMA, boundaries).

## A layout x NUM_A_BANKS

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| NAB=1 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 17 | 6 | 2880 | 0 | 992 | 0 | 0 | 0 | 64 | 0 |
| NAB=1 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 2880 | 0 | 992 | 0 | 0 | 0 | 64 | 0 |
| NAB=1 | pitch 18 (lane pairs share a bank) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 2880 | 0 | 992 | 0 | 0 | 0 | 64 | 0 |
| NAB=1 | pitch 19 | 1.0000 | 8.000 | 1.000 | 17 | 6 | 2880 | 0 | 992 | 0 | 0 | 0 | 64 | 0 |
| NAB=2 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 16 | 5 | 672 | 0 | 672 | 0 | 0 | 0 | 64 | 0 |
| NAB=2 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1216 | 0 | 608 | 0 | 0 | 0 | 64 | 0 |
| NAB=2 | pitch 18 (lane pairs share a bank) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1216 | 0 | 608 | 0 | 0 | 0 | 64 | 0 |
| NAB=2 | pitch 19 | 1.0000 | 8.000 | 1.000 | 16 | 5 | 672 | 0 | 672 | 0 | 0 | 0 | 64 | 0 |
| NAB=4 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| NAB=4 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1115 | 0 | 573 | 0 | 0 | 0 | 64 | 0 |
| NAB=4 | pitch 18 (lane pairs share a bank) | 1.0000 | 8.000 | 1.000 | 15 | 4 | 320 | 0 | 320 | 0 | 0 | 0 | 64 | 0 |
| NAB=4 | pitch 19 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| NAB=8 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| NAB=8 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1115 | 0 | 573 | 0 | 0 | 0 | 64 | 0 |
| NAB=8 | pitch 18 (lane pairs share a bank) | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| NAB=8 | pitch 19 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |

## B straddle x NUM_B_BANKS

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| NBB=1 | n0=0 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| NBB=1 | n0=1 | 0.5002 | 4.002 | 0.500 | 15 | 1027 | 0 | 2016 | 0 | 2016 | 0 | 0 | 96 | 0 |
| NBB=1 | n0=2 | 0.5002 | 4.002 | 0.500 | 15 | 1027 | 0 | 2016 | 0 | 2016 | 0 | 0 | 96 | 0 |
| NBB=1 | n0=3 | 0.5002 | 4.002 | 0.500 | 15 | 1027 | 0 | 2016 | 0 | 2016 | 0 | 0 | 96 | 0 |
| NBB=2 | n0=0 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| NBB=2 | n0=1 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 96 | 0 |
| NBB=2 | n0=2 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 96 | 0 |
| NBB=2 | n0=3 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 96 | 0 |
| NBB=4 | n0=0 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| NBB=4 | n0=1 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 96 | 0 |
| NBB=4 | n0=2 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 96 | 0 |
| NBB=4 | n0=3 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 96 | 0 |

## staging depth

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| ASTAGE=2 BSTAGE=4 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=2 BSTAGE=4 | all A lanes in one bank (pitch 8) | 0.8663 | 6.931 | 1.000 | 17 | 164 | 1499 | 0 | 765 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=2 BSTAGE=8 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=2 BSTAGE=8 | all A lanes in one bank (pitch 8) | 0.8897 | 7.117 | 1.000 | 17 | 133 | 1530 | 0 | 765 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=4 BSTAGE=4 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=4 BSTAGE=4 | all A lanes in one bank (pitch 8) | 0.9429 | 7.543 | 1.000 | 17 | 68 | 960 | 0 | 480 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=4 BSTAGE=8 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=4 BSTAGE=8 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1115 | 0 | 573 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=8 BSTAGE=4 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=8 BSTAGE=4 | all A lanes in one bank (pitch 8) | 0.9429 | 7.543 | 1.000 | 17 | 68 | 192 | 0 | 96 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=8 BSTAGE=8 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| ASTAGE=8 BSTAGE=8 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 192 | 0 | 96 | 0 | 0 | 0 | 64 | 0 |

## read latency

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| RLAT=1 A/B stage=4/4 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| RLAT=1 A/B stage=4/4 | all A lanes in one bank (pitch 8) | 0.9429 | 7.543 | 1.000 | 17 | 68 | 960 | 0 | 480 | 0 | 0 | 0 | 64 | 0 |
| RLAT=1 A/B stage=4/8 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| RLAT=1 A/B stage=4/8 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1115 | 0 | 573 | 0 | 0 | 0 | 64 | 0 |
| RLAT=1 A/B stage=8/12 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| RLAT=1 A/B stage=8/12 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 17 | 6 | 192 | 0 | 96 | 0 | 0 | 0 | 64 | 0 |
| RLAT=2 A/B stage=4/4 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 15 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| RLAT=2 A/B stage=4/4 | all A lanes in one bank (pitch 8) | 0.9167 | 7.334 | 1.000 | 18 | 100 | 960 | 0 | 480 | 0 | 0 | 0 | 64 | 0 |
| RLAT=2 A/B stage=4/8 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 15 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| RLAT=2 A/B stage=4/8 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 18 | 7 | 1146 | 0 | 573 | 0 | 0 | 0 | 64 | 0 |
| RLAT=2 A/B stage=8/12 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 15 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| RLAT=2 A/B stage=8/12 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 18 | 7 | 192 | 0 | 96 | 0 | 0 | 0 | 64 | 0 |
| RLAT=3 A/B stage=4/4 | conflict-free pitch 17 words | 0.8006 | 6.405 | 1.000 | 16 | 260 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| RLAT=3 A/B stage=4/4 | all A lanes in one bank (pitch 8) | 0.7636 | 6.109 | 1.000 | 19 | 325 | 1053 | 0 | 573 | 0 | 0 | 0 | 64 | 0 |
| RLAT=3 A/B stage=4/8 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 16 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| RLAT=3 A/B stage=4/8 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 19 | 8 | 1239 | 0 | 666 | 0 | 0 | 0 | 64 | 0 |
| RLAT=3 A/B stage=8/12 | conflict-free pitch 17 words | 1.0000 | 8.000 | 1.000 | 16 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| RLAT=3 A/B stage=8/12 | all A lanes in one bank (pitch 8) | 1.0000 | 8.000 | 1.000 | 19 | 8 | 192 | 0 | 96 | 0 | 0 | 0 | 64 | 0 |

## tile length / stream chaining

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CHAIN=0 | TK=4 | 0.5020 | 4.016 | 1.000 | 14 | 384 | 0 | 0 | 0 | 0 | 0 | 0 | 8 | 0 |
| CHAIN=0 | TK=8 | 0.8038 | 6.430 | 1.000 | 14 | 128 | 0 | 0 | 0 | 0 | 0 | 0 | 16 | 0 |
| CHAIN=0 | TK=16 | 0.9429 | 7.543 | 1.000 | 14 | 34 | 0 | 0 | 0 | 0 | 0 | 0 | 32 | 0 |
| CHAIN=0 | TK=32 | 0.9715 | 7.772 | 1.000 | 14 | 18 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| CHAIN=0 | TK=64 | 0.9865 | 7.892 | 1.000 | 14 | 10 | 0 | 0 | 0 | 0 | 0 | 0 | 128 | 0 |
| CHAIN=1 | TK=4 | 0.5020 | 4.016 | 1.000 | 14 | 384 | 0 | 0 | 0 | 0 | 0 | 0 | 8 | 0 |
| CHAIN=1 | TK=8 | 0.8050 | 6.440 | 1.000 | 14 | 96 | 0 | 0 | 0 | 0 | 0 | 0 | 16 | 0 |
| CHAIN=1 | TK=16 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 32 | 0 |
| CHAIN=1 | TK=32 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| CHAIN=1 | TK=64 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 128 | 0 |

## context queue depth / short tiles

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| CTXQ=2 | TK=4 | 0.5020 | 4.016 | 1.000 | 14 | 384 | 0 | 0 | 0 | 0 | 0 | 0 | 8 | 0 |
| CTXQ=2 | TK=8 | 0.8050 | 6.440 | 1.000 | 14 | 96 | 0 | 0 | 0 | 0 | 0 | 0 | 16 | 0 |
| CTXQ=2 | TK=12 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 24 | 0 |
| CTXQ=2 | TK=16 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 32 | 0 |
| CTXQ=4 | TK=4 | 0.5020 | 4.016 | 1.000 | 14 | 384 | 0 | 0 | 0 | 0 | 0 | 0 | 8 | 0 |
| CTXQ=4 | TK=8 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 16 | 0 |
| CTXQ=4 | TK=12 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 24 | 0 |
| CTXQ=4 | TK=16 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 32 | 0 |
| CTXQ=8 | TK=4 | 0.5020 | 4.016 | 1.000 | 14 | 384 | 0 | 0 | 0 | 0 | 0 | 0 | 8 | 0 |
| CTXQ=8 | TK=8 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 16 | 0 |
| CTXQ=8 | TK=12 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 24 | 0 |
| CTXQ=8 | TK=16 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 32 | 0 |

## DMA overlap, split vs shared sets

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| SPLIT | DMAW=0% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| SPLIT | DMAW=25% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 309 | 244 |
| SPLIT | DMAW=50% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 616 | 541 |
| SPLIT | DMAW=100% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 1108 | 1024 |
| SPLIT | DMAW=100% all-one-bank A | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1115 | 0 | 573 | 0 | 0 | 0 | 1111 | 1024 |
| SHARED STARVE=8 | DMAW=0% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| SHARED STARVE=8 | DMAW=25% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 88 | 292 | 226 |
| SHARED STARVE=8 | DMAW=50% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 178 | 510 | 437 |
| SHARED STARVE=8 | DMAW=100% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 308 | 800 | 718 |
| SHARED STARVE=8 | DMAW=100% all-one-bank A | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1115 | 0 | 573 | 0 | 0 | 361 | 750 | 667 |
| SHARED STARVE=2 | DMAW=0% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| SHARED STARVE=2 | DMAW=25% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 4 | 0 | 1 | 0 | 3 | 88 | 292 | 226 |
| SHARED STARVE=2 | DMAW=50% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 18 | 0 | 7 | 0 | 11 | 176 | 511 | 438 |
| SHARED STARVE=2 | DMAW=100% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 29 | 0 | 12 | 0 | 17 | 286 | 822 | 740 |
| SHARED STARVE=2 | DMAW=100% all-one-bank A | 0.9990 | 7.992 | 1.000 | 17 | 7 | 1167 | 0 | 591 | 0 | 54 | 321 | 791 | 707 |
| SHARED STARVE=0 | DMAW=0% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| SHARED STARVE=0 | DMAW=25% | 0.9318 | 7.454 | 1.000 | 14 | 78 | 66 | 75 | 24 | 0 | 118 | 0 | 332 | 244 |
| SHARED STARVE=0 | DMAW=50% | 0.8693 | 6.954 | 1.000 | 14 | 157 | 109 | 154 | 37 | 0 | 225 | 0 | 701 | 559 |
| SHARED STARVE=0 | DMAW=100% | 0.7763 | 6.211 | 1.000 | 15 | 299 | 240 | 296 | 87 | 0 | 450 | 0 | 1404 | 1024 |
| SHARED STARVE=0 | DMAW=100% all-one-bank A | 0.7787 | 6.230 | 1.000 | 19 | 299 | 1303 | 296 | 622 | 0 | 634 | 0 | 1404 | 1024 |

## array size

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2x2 | conflict-free pitch 33 | 1.0000 | 4.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 48 | 0 |
| 2x2 | pitch 32 | 1.0000 | 4.000 | 1.000 | 15 | 4 | 160 | 0 | 160 | 0 | 0 | 0 | 48 | 0 |
| 4x4 | conflict-free pitch 33 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| 4x4 | pitch 32 | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1115 | 0 | 573 | 0 | 0 | 0 | 64 | 0 |
| 8x8 | conflict-free pitch 33 | 1.0000 | 16.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 128 | 0 |
| 8x8 | pitch 32 | 0.9429 | 15.087 | 1.000 | 21 | 72 | 4202 | 0 | 1554 | 0 | 0 | 0 | 128 | 0 |
| 8x8 NAB=4 | conflict-free pitch 33 | 1.0000 | 16.000 | 1.000 | 16 | 5 | 1376 | 0 | 1376 | 0 | 0 | 0 | 128 | 0 |
| 8x8 NAB=4 | pitch 32 | 0.9429 | 15.087 | 1.000 | 21 | 72 | 4202 | 0 | 1554 | 0 | 0 | 0 | 128 | 0 |
| 8x8 NAB=1 | conflict-free pitch 33 | 0.5010 | 8.016 | 0.500 | 21 | 1030 | 13440 | 0 | 2016 | 0 | 0 | 0 | 128 | 0 |
| 8x8 NAB=1 | pitch 32 | 0.5010 | 8.016 | 0.500 | 21 | 1030 | 13440 | 0 | 2016 | 0 | 0 | 0 | 128 | 0 |

## word size

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| WB=4 | conflict-free | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| WB=4 | pitch 16 | 1.0000 | 8.000 | 1.000 | 17 | 6 | 1115 | 0 | 573 | 0 | 0 | 0 | 64 | 0 |
| WB=8 | conflict-free | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 48 | 0 |
| WB=8 | pitch 16 | 1.0000 | 8.000 | 1.000 | 17 | 6 | 347 | 0 | 189 | 0 | 0 | 0 | 48 | 0 |
| WB=16 | conflict-free | 1.0000 | 8.000 | 1.000 | 16 | 5 | 160 | 0 | 160 | 0 | 0 | 0 | 40 | 0 |
| WB=16 | pitch 16 | 1.0000 | 8.000 | 1.000 | 17 | 6 | 192 | 0 | 96 | 0 | 0 | 0 | 40 | 0 |

## sink back-pressure

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| default | SRDY=100% | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| default | SRDY=90% | 0.8828 | 7.062 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| default | SRDY=70% | 0.6952 | 5.561 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| default | SRDY=50% | 0.4923 | 3.938 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |

## tile offsets

| config | layout | rate | operands/cycle | bound | first slice (cycles) | starve | A stall | B stall | A conf | B conf | rd blocked by DMA | DMA stall | DMA words | overlap |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| default | k0=0 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 64 | 0 |
| default | k0=1 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 69 | 0 |
| default | k0=2 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 70 | 0 |
| default | k0=3 n0=3 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 106 | 0 |
| default | m0=2 | 1.0000 | 8.000 | 1.000 | 14 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 80 | 0 |

## Workload-level DMA / compute overlap (real TENSORCORE 02 array + TENSORCORE 04 accumulator)

Fixed GEMM 16 x 12 x 96 (3 operand blocks of K = 32, 12 output tiles); only the buffering and the DMA request-gap probability change.  Cycles = first fill to last committed row.

| buffering | DMA gap % | result | cycles | cycles vs single buffer at the same gap | DMA words written while a slice was delivered (`overlap`) | array starvation cycles |
|---|---:|---|---:|---:|---:|---:|
| single buffer (no overlap possible) | 0 | PASS | 3121 | 1.000x | 0 | 18 |
| single buffer (no overlap possible) | 50 | PASS | 3842 | 1.000x | 0 | 18 |
| single buffer (no overlap possible) | 80 | PASS | 5901 | 1.000x | 0 | 18 |
| ping-pong, split banks | 0 | PASS | 2217 | 1.408x | 297 | 18 |
| ping-pong, split banks | 50 | PASS | 2573 | 1.493x | 265 | 18 |
| ping-pong, split banks | 80 | PASS | 4776 | 1.236x | 134 | 18 |
| ping-pong, shared banks (WR_STARVE_LIMIT 8) | 0 | PASS | 2217 | 1.408x | 285 | 18 |
| ping-pong, shared banks (WR_STARVE_LIMIT 8) | 50 | PASS | 2650 | 1.450x | 242 | 18 |
| ping-pong, shared banks (WR_STARVE_LIMIT 8) | 80 | PASS | 4725 | 1.249x | 123 | 18 |

