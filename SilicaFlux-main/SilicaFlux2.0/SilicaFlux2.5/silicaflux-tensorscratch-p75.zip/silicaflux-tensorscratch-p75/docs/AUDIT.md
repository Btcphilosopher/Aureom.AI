# Repository audit (brief section 1) and the decisions it forced

Scope: the archives in `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` of the Aureom.AI repository.  Everything below was read from those archives; nothing was
assumed from the brief's file names.  **Depth of reading is stated per item** - the interface-defining RTL was read, the rest of some packages only at README /
documentation level, and that limits what this package can claim (see "What was not co-simulated").

## 1. What exists, and what it means for this project

| item in the brief | what the repository actually has | read how | consequence |
|---|---|---|---|
| `sf_sram_core.sv` | `silicaflux-memorycore-sram.zip`: behavioural 1RW synchronous SRAM, byte lanes, `SIM_INIT` poison, fixed read latency, no array reset | full RTL + `CONTRACT.md` | reused unmodified (byte-identical copy, SHA-256 in `third_party/PROVENANCE.md`) |
| `sf_sram_bank.sv` | same pack: request/response wrapper around the core, optional SECDED, init / scrub / MBIST ports | full RTL | reused unmodified as the only storage primitive (ECC off, maintenance ports tied off in `sf_ts_bank.sv`) |
| `sf_sram_controller.sv` | same pack: `NM` masters x `NB` banks, 128-bit lines, per-master in-order response slots, ECC, flush | header + ports + `CONTRACT.md` | **not used for the operand path**, see 2 |
| `sf_tensor_scratchpad.sv` (!) | **the same pack already contains a module with this exact name** (`rtl/sf_tensor_scratchpad.sv` + `sf_ts_port.sv`): a 128-bit-line ownership shim (A / B / C regions, ping-pong, four controller master ports) | full RTL | it is a different design (below); the Project 75 file of the same name is **new** and must not be compiled together with it |
| TensorCore | `silicaflux-tensorcore02` (output-stationary systolic array), `03` (operand buffer), `04` (accumulator), `05` (quantiser), `06` (tile controller), `07` (DMA adapter + output buffer) | 02, 03, 04: README, docs, interface RTL; 05: not read; 06, 07: README only | interfaces for 02 / 03 / 04 taken from RTL; 06 / 07 / M07 compatibility is by protocol, not by simulation |
| Tensor tile controller | TC06 `tensor_tile_controller` + `tensor_gemm_engine`: cuts a GEMM into operand blocks, output tiles and K chunks; drives TC03 + TC04 + TC02 | README | the testbench plays this role (`tb/tb_ts_system.sv`) |
| Tensor DMA adapter | TC07 `tensor_dma_adapter`: 2-D strided SFB2 transfers into the TC03 window, FREE / FILLING / READY / IN_USE ownership | README | the DMA port here uses the same port protocol, window map and error numbering; ownership state names adopted |
| Accumulator engine | TC04 `tensor_accumulator`: adds each K chunk **exactly once**, defines the accumulator **storage interface** | README, `ARCHITECTURE.md`, `STORAGE_INTERFACE.md`, ports, `tensor_acc_storage.sv` | decisive for section 3 (the accumulator buffer) |
| Performance counters | Module 07 `hpc_perf_counters`: multi-event increment vector `inc_i`; TC03 exports `ev_inc` in that format | README | `ev_inc` (30 events x 8 bit) exported in the same style + local saturating counters |

## 2. The actual operand and result interfaces

**Operands (TENSORCORE 02 `tensor_systolic_array`).**  One *k-slice* per `s_valid / s_ready` handshake: `s_a = A[:,k]` (lane *i* = row *i*), `s_b = B[k,:]` (lane *j* = column
*j*), `s_k` = the index the array expects next.  The array **skews the lanes itself** (`tensor_skew` delays A lane *i* by 1+*i* and B lane *j* by 1+*j* registers) so
that A[i][k] and B[k][j] meet in PE(i,j) at enabled cycle *k*+1+*i*+*j*.  Consequence: this scratchpad must deliver **un-skewed, k-aligned** slices.  Skewing them again would
pair A[i][k] with B[k+1][j].  "Correct pipeline skew" in the brief is therefore satisfied by guaranteeing that every lane of a slice is the same *k* (section 6 of `ARCHITECTURE.md`)
and that the array's own `s_k` / `align_err` checker agrees (it is part of every system test).  The array has one global enable (`pipe_en`): back-pressure freezes everything, no bubbles are injected.

**Results (TENSORCORE 02 -> 04).**  The PEs clear their accumulators at every launch and the array reads the finished chunk out as rows (`m_data` = `COLS x ACC_WIDTH`, `m_row`,
`m_last`).  The array has **no preload port**.  TENSORCORE 04 takes those rows (`ps_*`, with a `{slot, tag, chunk, chunk_k}` sideband from the sequencer), adds each row of each chunk
to the stored partial sum exactly once (chunk sequence numbers; replays dropped, a skipped chunk rejected), keeps the values in an **external storage** reached through
`st_en, st_rd_req/addr/ready/data, st_wr_req/addr/data/ready` (entry = `slot*ROWS+row`, `COLS x (ACC_W+1)` bits, `RD_LAT` 1..3, read-before-write, held while `st_en = 0`), and commits
finished tiles to an output path.

**Tile descriptors / slices of the existing operand buffer (TENSORCORE 03).**  `tile_{a_addr,lda,b_addr,ldb,m0,n0,k0,mat_m,mat_n,mat_k,k,tag}` and `s_{a,b,k,kg,m0,n0,row_mask,col_mask,first,last,tag,set}`;
tile response `{tag, err, code, m, n, k}` whose `m,n,k` are fed straight to the array's `cfg_{m,n,k}`.  `sf_tensor_scratchpad` uses the **same descriptor, response, slice and DMA-window
conventions** (codes 0..7 keep their numbering, 8 and 9 are new), so a controller written for that interface can drive this one.

## 3. Decisions (each is a consequence of the audit, not a preference)

| # | decision | evidence | cost / risk |
|---|---|---|---|
| D1 | deliver **un-skewed** k-slices; skew nothing | section 2: the array skews | none; an integration with an array that does not skew would need a skew stage added |
| D2 | the accumulator buffer is the **backing store of the TC04 storage interface and contains no adder** | TC04 already guarantees exactly-once accumulation; TC02 PEs restart at zero every launch, so continuation across launches can only be done by TC04; the brief says not to duplicate accumulation inside the TensorCore | "partial-sum load" is TC04's `hc_write` preload, not an external write into storage (limitation L5) |
| D3 | accumulator storage = banked 1RW banks **plus a write buffer with read forwarding** | a first version made `st_rd_ready` depend on a bank conflict; integrating the real accumulator showed `issue_ok = pipe_en & st_rd_ready` with `st_rd_addr` derived from the same stage - a combinational loop (Verilator `UNOPTFLAT` on `u_acc.issue_ok`, absent with TC04's own storage).  Redesigned so both ready signals are registered state only; proven loop-free by `yosys check -assert` on the integrated system | one 4-entry buffer of 132-bit entries; throughput depends on `NUM_ACC_BANKS` vs `RD_LAT` (measured) |
| D4 | `a_addr, lda, b_addr, ldb` must be multiples of `WORD_BYTES` (error `ALIGN`); `k0`, `n0`, `m0`, tile sizes and the matrix extents are arbitrary | with a word-aligned pitch all A lanes share one byte offset and cross word boundaries together; B rows share one offset, so a B row spans 1 or 2 words (the straddle case is generated and measured) | TC03 accepts unaligned bases and pitches; this module does not (the DMA / loader pads) |
| D5 | **word-interleaved** banks (`bank = word mod NB`), no lda-dependent hashing; bank collisions are *measured*, hidden by staging + stream chaining, and reported as events | with word interleaving some pitches always collide at a word step (every pitch that is a multiple of `NUM_A_BANKS` words puts all lanes in one bank at their first word); a bank hash would move which pitches collide, not remove them, and it would also have to be mirrored by the DMA writer.  TC03 handles it by padding the pitch (its doc 03).  Here arbitration staggers the lanes, the cost is a measured transient, and the layout stays the DMA's choice | a pitch with all A lanes in one bank costs rate unless `B_STAGE` is 8 (`docs/BANDWIDTH.md`) |
| D6 | the operand path does **not** go through `sf_sram_controller` | the controller serialises per-master in-order responses through reorder slots over 128-bit lines; the A path needs `ARRAY_ROWS` independent narrow reads per word step with deterministic latency and no reorder logic | reuse is at the verified primitive level (`sf_sram_bank`, `sf_sync_fifo`), not at the controller level |
| D7 | name `sf_tensor_scratchpad`, as the brief asks, although a different module of that name exists in the MemoryCore pack | section 1 | the two must not be compiled together; `docs/KNOWN_LIMITATIONS.md` L1 |

## 4. Relationship to TENSORCORE 03 (stated plainly)

`silicaflux-tensorcore03` (`tensor_operand_buffer`) already implements banked A / B operand delivery, ping-pong, descriptor validation, DMA fill and events for the same array,
verified in its own package (its README reports 38 + 38 + 15 regression runs, mutation testing and ECP5 place and route).  This package is an **independent implementation**
(written without copying it) with a different structure and a different scope:

* storage is the MemoryCore `sf_sram_bank` instead of the SRAM wrapper library (the brief asks for the former);
* the A lanes and B columns are the same word-stream mechanism with **stream chaining** (no per-tile bubble, measured);
* it adds the **accumulator buffer** region (storage contract, slot ownership, external port, hazards) which TC03 does not have;
* it supports one address model only (word-aligned pitches; TC03 also handles unaligned pitches, replicated A banks, 1R1W macros, FPGA / ASIC backends).

No performance claim relative to TC03 is made: it was not run side by side.  Where both would serve, TC03 has the broader verification history.

## 5. What was not co-simulated

TENSORCORE 06 (tile controller), TENSORCORE 07 (DMA adapter) and the Module 07 counter bank were **not** simulated with this module.  The compatibility claims are about
*port protocol and numbering* (descriptor fields, response codes, DMA window, `ev_inc` format), checked by reading, and the testbench contains a behavioural stand-in for the sequencer
and the DMA master.  TENSORCORE 02 and 04 **are** simulated, unmodified, in every system run.
