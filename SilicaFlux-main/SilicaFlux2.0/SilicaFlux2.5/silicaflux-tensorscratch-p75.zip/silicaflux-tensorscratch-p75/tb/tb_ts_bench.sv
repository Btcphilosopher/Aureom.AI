// =============================================================================
// SilicaFlux TensorScratch :: tb_ts_bench.sv        OPERAND-BANDWIDTH BENCHMARK (self-checking; DUT + a k-slice sink, no array)
//
//   One operand pair is resident in set 0 (A: ARRAY_ROWS rows of pitch LDA_W words, B: rows of pitch LDB_W words, deterministic data);
//   NT descriptors of the SAME tile are issued back to back (the AGU / context queue overlap is part of what is measured) and the slice
//   stream is consumed by a sink with a configurable ready probability.  Every delivered slice is checked against the deterministic
//   operand functions, so a throughput number can never come from wrong data.
//
//   MEASURED: slices per cycle from the first to the last delivered slice (sustained, tile boundaries included), operands per cycle =
//   rate x (ARRAY_ROWS + ARRAY_COLS), first-slice latency from the first descriptor handshake, and the event counters of the DUT.
//   +DMAW=<pct>: with double buffering, set 1 is FILLING and a DMA master writes it (random legal words, <pct>% of the cycles) for the whole
//   run - the "DMA / compute overlap" and DMA-conflict measurement.   +SRDY=<pct>: sink ready probability (100 = never back-pressured).
//   One result line:  BENCH key=value ...   (parsed by scripts/run_bench.py)
// =============================================================================
`timescale 1ns/1ps
module tb_ts_bench;
  parameter int R = 4, C = 4, OW = 8, WB = 4, ND = 1, SET_MAP = 1, NAB = 4, NBB = 2, RLAT = 1, ASTAGE = 4, BSTAGE = 8, STARVE = 8, TILE_K = 64, CTXQ = 2, CHAIN = 1;
  localparam int EB = OW / 8, DW = 8 * WB, NSETS = (ND != 0) ? 2 : 1;
  localparam int A_BYTES = 8192, B_BYTES = 8192, ASET = A_BYTES / NSETS, BSET = B_BYTES / NSETS, REGION = 8192;
  localparam int KW = 17, IDX_W = 16, TAG_W = 8, NEV = 30;
  logic clk = 0, rst_n = 0; always #5 clk = ~clk;
  longint cyc = 0; always @(posedge clk) cyc <= cyc + 1;

  logic dma_req_valid = 0; logic [31:0] dma_req_addr = 0; logic [DW-1:0] dma_req_wdata = 0; logic [WB-1:0] dma_req_wstrb = '1; logic [TAG_W-1:0] dma_req_tag = 0;
  wire dma_req_ready, dma_rsp_valid, dma_rsp_err, dma_rsp_we; wire [DW-1:0] dma_rsp_rdata; wire [2:0] dma_rsp_err_code; wire [TAG_W-1:0] dma_rsp_tag;
  logic fill_begin_valid = 0, fill_end_valid = 0, cmp_begin_valid = 0, cmp_end_valid = 0; wire fill_begin_ready, fill_end_ready, cmp_begin_ready, cmp_end_ready; wire [0:0] fill_set, cmp_set; wire [NSETS*2-1:0] set_state;
  logic tile_valid = 0; logic [31:0] tile_a_addr = 0, tile_lda = 0, tile_b_addr = 0, tile_ldb = 0; logic [IDX_W-1:0] tile_m0 = 0, tile_n0 = 0, tile_mat_m = 0, tile_mat_n = 0;
  logic [KW-1:0] tile_k0 = 0, tile_mat_k = 0, tile_k = 0; logic [TAG_W-1:0] tile_tag = 0;
  wire tile_ready, tile_rsp_valid; wire [TAG_W-1:0] tile_rsp_tag; wire tile_rsp_err; wire [3:0] tile_rsp_code; wire [$clog2(R+1)-1:0] tile_rsp_m; wire [$clog2(C+1)-1:0] tile_rsp_n; wire [KW-1:0] tile_rsp_k;
  wire s_valid; logic s_ready = 1; wire [R*OW-1:0] s_a; wire [C*OW-1:0] s_b; wire [KW-1:0] s_k, s_kg; wire [IDX_W-1:0] s_m0, s_n0; wire [R-1:0] s_row_mask; wire [C-1:0] s_col_mask; wire s_first, s_last; wire [TAG_W-1:0] s_tag; wire [0:0] s_set;
  wire busy, engine_idle; wire [NEV*8-1:0] ev_inc; wire [NEV*32-1:0] perf_cnt;
  logic perf_clear = 0;
  localparam int ACC_EW = C * 33; localparam int NSLOT = 1024 / (R * ((ACC_EW + 7) / 8)); localparam int SLOT_W = (NSLOT > 1) ? $clog2(NSLOT) : 1; localparam int ACC_AW = (NSLOT * R > 1) ? $clog2(NSLOT * R) : 1;
  wire acc_st_rd_ready, acc_st_wr_ready, acc_claim_ready, ext_req_ready, ext_rsp_valid, ext_rsp_we, ext_rsp_err; wire [ACC_EW-1:0] acc_st_rd_data, ext_rsp_rdata; wire [2:0] ext_rsp_code; wire [NSLOT*2-1:0] acc_slot_state; wire [3:0] acc_viol;

  sf_tensor_scratchpad #(.ARRAY_ROWS(R), .ARRAY_COLS(C), .TILE_K(TILE_K), .OPERAND_WIDTH(OW), .A_BUFFER_BYTES(A_BYTES), .B_BUFFER_BYTES(B_BYTES), .ENABLE_DOUBLE_BUFFERING(ND),
      .NUM_A_BANKS(NAB), .NUM_B_BANKS(NBB), .WORD_BYTES(WB), .SET_MAP(SET_MAP), .READ_LATENCY(RLAT), .A_STAGE(ASTAGE), .B_STAGE(BSTAGE), .WR_STARVE_LIMIT(STARVE), .CTXQ_DEPTH(CTXQ), .STREAM_CHAIN(CHAIN)) dut (
    .clk(clk), .rst_n(rst_n), .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(1'b1), .dma_req_addr(dma_req_addr), .dma_req_wdata(dma_req_wdata),
    .dma_req_wstrb(dma_req_wstrb), .dma_req_tag(dma_req_tag), .dma_rsp_valid(dma_rsp_valid), .dma_rsp_ready(1'b1), .dma_rsp_rdata(dma_rsp_rdata), .dma_rsp_err(dma_rsp_err),
    .dma_rsp_err_code(dma_rsp_err_code), .dma_rsp_we(dma_rsp_we), .dma_rsp_tag(dma_rsp_tag),
    .fill_begin_valid(fill_begin_valid), .fill_begin_ready(fill_begin_ready), .fill_end_valid(fill_end_valid), .fill_end_ready(fill_end_ready),
    .cmp_begin_valid(cmp_begin_valid), .cmp_begin_ready(cmp_begin_ready), .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cmp_end_ready),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(set_state),
    .tile_valid(tile_valid), .tile_ready(tile_ready), .tile_a_addr(tile_a_addr), .tile_lda(tile_lda), .tile_b_addr(tile_b_addr), .tile_ldb(tile_ldb), .tile_m0(tile_m0), .tile_n0(tile_n0),
    .tile_k0(tile_k0), .tile_mat_m(tile_mat_m), .tile_mat_n(tile_mat_n), .tile_mat_k(tile_mat_k), .tile_k(tile_k), .tile_tag(tile_tag),
    .tile_rsp_valid(tile_rsp_valid), .tile_rsp_ready(1'b1), .tile_rsp_tag(tile_rsp_tag), .tile_rsp_err(tile_rsp_err), .tile_rsp_code(tile_rsp_code), .tile_rsp_m(tile_rsp_m), .tile_rsp_n(tile_rsp_n), .tile_rsp_k(tile_rsp_k),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0), .s_row_mask(s_row_mask), .s_col_mask(s_col_mask), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .acc_st_en(1'b1), .acc_st_rd_req(1'b0), .acc_st_rd_addr('0), .acc_st_rd_ready(acc_st_rd_ready), .acc_st_rd_data(acc_st_rd_data), .acc_st_wr_req(1'b0), .acc_st_wr_addr('0), .acc_st_wr_data('0), .acc_st_wr_ready(acc_st_wr_ready),
    .acc_claim_valid(1'b0), .acc_claim_ready(acc_claim_ready), .acc_claim_slot('0), .acc_complete_valid(1'b0), .acc_complete_slot('0), .acc_release_valid(1'b0), .acc_release_slot('0), .acc_slot_state(acc_slot_state),
    .ext_req_valid(1'b0), .ext_req_ready(ext_req_ready), .ext_req_we(1'b0), .ext_req_slot('0), .ext_req_row('0), .ext_req_wdata('0), .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(1'b1), .ext_rsp_rdata(ext_rsp_rdata),
    .ext_rsp_we(ext_rsp_we), .ext_rsp_err(ext_rsp_err), .ext_rsp_code(ext_rsp_code), .acc_viol_sticky(acc_viol), .busy(busy), .engine_idle(engine_idle), .ev_inc(ev_inc), .perf_clear(perf_clear), .perf_cnt(perf_cnt));

  // ------------------------------------------------------------ knobs
  int p_lda_w = 0, p_ldb_w = 0, p_n0 = 0, p_k0 = 0, p_tk = 32, p_nt = 32, p_dmaw = 0, p_srdy = 100, p_m0 = 0, p_seed = 1;
  logic [63:0] rs = 64'h1234567;
  function automatic int rnd(input int n); rs = rs ^ (rs << 13); rs = rs ^ (rs >> 7); rs = rs ^ (rs << 17); rnd = (n <= 1) ? 0 : int'(rs[40:8] % 64'(n)); endfunction
  // deterministic operand functions (the model: no memory of its own)
  function automatic logic [OW-1:0] fa(input int r, input int c); fa = OW'(r * 37 + c * 11 + 5 + (r * c) * 3); endfunction
  function automatic logic [OW-1:0] fb(input int k, input int n); fb = OW'(k * 29 + n * 13 + 7 + (k * n) * 5); endfunction

  int errors = 0;
  // sink ready
  always @(negedge clk) s_ready <= (p_srdy >= 100) ? 1'b1 : (rnd(100) < p_srdy);

  // slice monitor: expected data for the tile (m0, n0, k0, tk)
  longint first_cyc = -1, last_cyc = 0; int nslice = 0;
  int exp_per_tile;
  always @(posedge clk) if (rst_n && s_valid && s_ready) begin
    int k; k = int'(s_k);
    if (first_cyc < 0) first_cyc = cyc;
    last_cyc = cyc; nslice++;
    for (int i = 0; i < R; i++) if (s_a[i*OW +: OW] !== fa(p_m0 + i, p_k0 + k)) errors++;
    for (int j = 0; j < C; j++) if (s_b[j*OW +: OW] !== fb(p_k0 + k, p_n0 + j)) errors++;
    if (int'(s_kg) !== p_k0 + k) errors++;
  end

  // ------------------------------------------------------------ DMA background writer (into the filling set while computing)
  bit dma_run = 0; int dma_words = 0;
  always @(negedge clk) if (dma_run) begin
    if (dma_req_valid && !dma_req_ready) begin end                                   // hold until accepted
    else begin
      if (rnd(100) < p_dmaw) begin
        int is_b, w; is_b = rnd(2);
        dma_req_valid <= 1; dma_req_wstrb <= '1; dma_req_wdata <= DW'(rnd(1 << 30));
        // set 1 (the FILLING set)
        w = rnd((is_b ? BSET : ASET) / WB) * WB;
        dma_req_addr <= is_b ? (REGION + 1 * BSET + w) : (1 * ASET + w);
      end else dma_req_valid <= 0;
    end
  end
  always @(posedge clk) if (rst_n && dma_req_valid && dma_req_ready) dma_words <= dma_words + 1;

  // ------------------------------------------------------------ main
  int lda, ldb, kdim, tcode_err = 0;
  longint t_first_desc, lat_first;
  initial begin
    void'($value$plusargs("LDA_W=%d", p_lda_w)); void'($value$plusargs("LDB_W=%d", p_ldb_w)); void'($value$plusargs("N0=%d", p_n0)); void'($value$plusargs("K0=%d", p_k0)); void'($value$plusargs("M0=%d", p_m0));
    void'($value$plusargs("TK=%d", p_tk)); void'($value$plusargs("NT=%d", p_nt)); void'($value$plusargs("DMAW=%d", p_dmaw)); void'($value$plusargs("SRDY=%d", p_srdy)); void'($value$plusargs("seed=%d", p_seed));
    rs = rs ^ (64'(p_seed) * 64'h9E3779B97F4A7C15);
    kdim = p_k0 + p_tk;
    lda = (p_lda_w != 0) ? p_lda_w * WB : ((kdim * EB + WB - 1) / WB) * WB;
    ldb = (p_ldb_w != 0) ? p_ldb_w * WB : (((p_n0 + C) * EB + WB - 1) / WB) * WB;
    if (R * lda > ASET || kdim * ldb > BSET) begin $display("BENCH_ERROR layout does not fit the set (A %0d/%0d B %0d/%0d)", (p_m0 + R) * lda, ASET, kdim * ldb, BSET); $finish; end
    rst_n = 0; repeat (5) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);
    // fill set 0 (the whole operand pair), word writes with all strobes where matrix data lives
    @(negedge clk); fill_begin_valid = 1; @(posedge clk); while (!fill_begin_ready) @(posedge clk); @(negedge clk); fill_begin_valid = 0;
    for (int r = 0; r < p_m0 + R; r++) for (int w = 0; w < (kdim * EB + WB - 1) / WB; w++) begin
      logic [DW-1:0] d; logic [WB-1:0] st; d = '0; st = '0;
      for (int b = 0; b < WB; b++) if (w * WB + b < kdim * EB) begin d[b*8 +: 8] = fa(r, (w * WB + b) / EB) >> (((w * WB + b) % EB) * 8); st[b] = 1; end
      @(negedge clk); dma_req_valid = 1; dma_req_addr = r * lda + w * WB; dma_req_wdata = d; dma_req_wstrb = st; @(posedge clk); while (!dma_req_ready) @(posedge clk); @(negedge clk); dma_req_valid = 0;
    end
    for (int k = 0; k < kdim; k++) for (int w = 0; w < ((p_n0 + C) * EB + WB - 1) / WB; w++) begin
      logic [DW-1:0] d; logic [WB-1:0] st; d = '0; st = '0;
      for (int b = 0; b < WB; b++) if (w * WB + b < (p_n0 + C) * EB) begin d[b*8 +: 8] = fb(k, (w * WB + b) / EB) >> (((w * WB + b) % EB) * 8); st[b] = 1; end
      @(negedge clk); dma_req_valid = 1; dma_req_addr = REGION + k * ldb + w * WB; dma_req_wdata = d; dma_req_wstrb = st; @(posedge clk); while (!dma_req_ready) @(posedge clk); @(negedge clk); dma_req_valid = 0;
    end
    repeat (8) @(posedge clk);
    @(negedge clk); fill_end_valid = 1; @(posedge clk); while (!fill_end_ready) @(posedge clk); @(negedge clk); fill_end_valid = 0;
    @(negedge clk); cmp_begin_valid = 1; @(posedge clk); while (!cmp_begin_ready) @(posedge clk); @(negedge clk); cmp_begin_valid = 0;
    // background DMA into the other set
    if (p_dmaw > 0 && ND != 0) begin
      @(negedge clk); fill_begin_valid = 1; @(posedge clk); while (!fill_begin_ready) @(posedge clk); @(negedge clk); fill_begin_valid = 0;
      dma_run = 1;
    end
    perf_clear = 1; @(negedge clk); perf_clear = 0;
    // NT back-to-back descriptors of the same tile
    t_first_desc = cyc;
    for (int t = 0; t < p_nt; t++) begin
      @(negedge clk); tile_valid = 1; tile_a_addr = 0; tile_lda = lda; tile_b_addr = 0; tile_ldb = ldb; tile_m0 = p_m0; tile_n0 = p_n0; tile_k0 = p_k0;
      tile_mat_m = p_m0 + R; tile_mat_n = p_n0 + C; tile_mat_k = p_k0 + p_tk; tile_k = p_tk; tile_tag = t[7:0];
      @(posedge clk); while (!tile_ready) @(posedge clk); @(negedge clk); tile_valid = 0;
    end
    while (nslice < p_nt * p_tk) begin @(posedge clk); if (cyc - t_first_desc > 2000000) begin $display("BENCH_ERROR timeout nslice=%0d", nslice); $finish; end end
    repeat (4) @(posedge clk);
    dma_run = 0; @(negedge clk); dma_req_valid = 0;
    begin
      real rate, opc; longint span;
      span = last_cyc - first_cyc + 1;
      rate = real'(nslice) / real'(span); opc = rate * (R + C);
      lat_first = first_cyc - t_first_desc;
      $display("BENCH R=%0d C=%0d WB=%0d ND=%0d SET_MAP=%0d NAB=%0d NBB=%0d RLAT=%0d ASTAGE=%0d BSTAGE=%0d STARVE=%0d CHAIN=%0d LDA_W=%0d LDB_W=%0d M0=%0d N0=%0d K0=%0d TK=%0d NT=%0d DMAW=%0d SRDY=%0d slices=%0d span=%0d rate=%0.4f operands_per_cycle=%0.3f first_latency=%0d errors=%0d dma_words=%0d starve=%0d starve_a=%0d starve_b=%0d a_rd_stall=%0d b_rd_stall=%0d a_conf=%0d b_conf=%0d rd_wr_block=%0d dma_wr_stall=%0d dma_forced=%0d overlap=%0d bp=%0d",
               R, C, WB, ND, SET_MAP, NAB, NBB, RLAT, ASTAGE, BSTAGE, STARVE, CHAIN, lda / WB, ldb / WB, p_m0, p_n0, p_k0, p_tk, p_nt, p_dmaw, p_srdy, nslice, span, rate, opc, lat_first, errors, dma_words,
               perf_cnt[3*32 +: 32], perf_cnt[4*32 +: 32], perf_cnt[5*32 +: 32], perf_cnt[9*32 +: 32], perf_cnt[10*32 +: 32], perf_cnt[11*32 +: 32], perf_cnt[12*32 +: 32], perf_cnt[13*32 +: 32],
               perf_cnt[14*32 +: 32], perf_cnt[16*32 +: 32], perf_cnt[20*32 +: 32], perf_cnt[6*32 +: 32]);
    end
    $finish;
  end
endmodule
