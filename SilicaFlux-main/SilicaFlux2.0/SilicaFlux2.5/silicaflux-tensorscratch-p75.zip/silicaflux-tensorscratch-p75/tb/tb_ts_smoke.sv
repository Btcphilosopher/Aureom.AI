// Bring-up smoke test: ONE 4x4 tile, single buffer, no array. Operands are written by DMA, one descriptor is issued and every
// delivered k-slice is checked against a hand model.
`timescale 1ns/1ps
module tb_ts_smoke;
  localparam int R=4, C=4, K=8, LDA=8, LDB=4;
  logic clk=0, rst_n=0;
  always #5 clk = ~clk;
  // DUT ports
  logic dma_req_valid=0, dma_req_we=1; logic [31:0] dma_req_addr; logic [31:0] dma_req_wdata; logic [3:0] dma_req_wstrb=4'hF; logic [7:0] dma_req_tag=0;
  wire dma_req_ready, dma_rsp_valid, dma_rsp_err, dma_rsp_we; wire [31:0] dma_rsp_rdata; wire [2:0] dma_rsp_err_code; wire [7:0] dma_rsp_tag;
  logic fill_begin_valid=0, fill_end_valid=0, cmp_begin_valid=0, cmp_end_valid=0;
  wire fill_begin_ready, fill_end_ready, cmp_begin_ready, cmp_end_ready; wire [0:0] fill_set, cmp_set; wire [1:0] set_state;
  logic tile_valid=0; logic [31:0] tile_a_addr=0, tile_lda=LDA, tile_b_addr=0, tile_ldb=LDB; logic [15:0] tile_m0=0, tile_n0=0, tile_mat_m=4, tile_mat_n=4;
  logic [16:0] tile_k0=0, tile_mat_k=K, tile_k=K; logic [7:0] tile_tag=8'h5A;
  wire tile_ready, tile_rsp_valid; wire [7:0] tile_rsp_tag; wire tile_rsp_err; wire [3:0] tile_rsp_code; wire [2:0] tile_rsp_m, tile_rsp_n; wire [16:0] tile_rsp_k;
  wire s_valid; logic s_ready=1; wire [31:0] s_a, s_b; wire [16:0] s_k, s_kg; wire [15:0] s_m0, s_n0; wire [3:0] s_row_mask, s_col_mask; wire s_first, s_last; wire [7:0] s_tag; wire [0:0] s_set;
  wire busy, engine_idle; wire [29*8-1:0] ev_inc; wire [29*32-1:0] perf_cnt;
  localparam int NSLOT = 7;
  wire acc_st_rd_ready, acc_st_wr_ready, acc_claim_ready, ext_req_ready, ext_rsp_valid, ext_rsp_we, ext_rsp_err; wire [131:0] acc_st_rd_data, ext_rsp_rdata; wire [2:0] ext_rsp_code;
  wire [NSLOT*2-1:0] acc_slot_state; wire [3:0] acc_viol_sticky;

  sf_tensor_scratchpad #(.ENABLE_DOUBLE_BUFFERING(0), .A_BUFFER_BYTES(4096), .B_BUFFER_BYTES(4096)) dut (
    .clk(clk), .rst_n(rst_n), .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(dma_req_we), .dma_req_addr(dma_req_addr),
    .dma_req_wdata(dma_req_wdata), .dma_req_wstrb(dma_req_wstrb), .dma_req_tag(dma_req_tag), .dma_rsp_valid(dma_rsp_valid), .dma_rsp_ready(1'b1),
    .dma_rsp_rdata(dma_rsp_rdata), .dma_rsp_err(dma_rsp_err), .dma_rsp_err_code(dma_rsp_err_code), .dma_rsp_we(dma_rsp_we), .dma_rsp_tag(dma_rsp_tag),
    .fill_begin_valid(fill_begin_valid), .fill_begin_ready(fill_begin_ready), .fill_end_valid(fill_end_valid), .fill_end_ready(fill_end_ready),
    .cmp_begin_valid(cmp_begin_valid), .cmp_begin_ready(cmp_begin_ready), .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cmp_end_ready),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(set_state),
    .tile_valid(tile_valid), .tile_ready(tile_ready), .tile_a_addr(tile_a_addr), .tile_lda(tile_lda), .tile_b_addr(tile_b_addr), .tile_ldb(tile_ldb),
    .tile_m0(tile_m0), .tile_n0(tile_n0), .tile_k0(tile_k0), .tile_mat_m(tile_mat_m), .tile_mat_n(tile_mat_n), .tile_mat_k(tile_mat_k), .tile_k(tile_k), .tile_tag(tile_tag),
    .tile_rsp_valid(tile_rsp_valid), .tile_rsp_ready(1'b1), .tile_rsp_tag(tile_rsp_tag), .tile_rsp_err(tile_rsp_err), .tile_rsp_code(tile_rsp_code),
    .tile_rsp_m(tile_rsp_m), .tile_rsp_n(tile_rsp_n), .tile_rsp_k(tile_rsp_k),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0), .s_row_mask(s_row_mask), .s_col_mask(s_col_mask),
    .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .acc_st_en(1'b1), .acc_st_rd_req(1'b0), .acc_st_rd_addr('0), .acc_st_rd_ready(acc_st_rd_ready), .acc_st_rd_data(acc_st_rd_data),
    .acc_st_wr_req(1'b0), .acc_st_wr_addr('0), .acc_st_wr_data('0), .acc_st_wr_ready(acc_st_wr_ready),
    .acc_claim_valid(1'b0), .acc_claim_ready(acc_claim_ready), .acc_claim_slot('0), .acc_complete_valid(1'b0), .acc_complete_slot('0),
    .acc_release_valid(1'b0), .acc_release_slot('0), .acc_slot_state(acc_slot_state),
    .ext_req_valid(1'b0), .ext_req_ready(ext_req_ready), .ext_req_we(1'b0), .ext_req_slot('0), .ext_req_row('0), .ext_req_wdata('0),
    .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(1'b1), .ext_rsp_rdata(ext_rsp_rdata), .ext_rsp_we(ext_rsp_we), .ext_rsp_err(ext_rsp_err), .ext_rsp_code(ext_rsp_code),
    .acc_viol_sticky(acc_viol_sticky), .busy(busy), .engine_idle(engine_idle), .ev_inc(ev_inc), .perf_clear(1'b0), .perf_cnt(perf_cnt));

  // reference operands
  logic signed [7:0] A [4][K];
  logic signed [7:0] B [K][4];
  int errors = 0, nslice = 0;

  task automatic dmaw(input int addr, input logic [31:0] data);
    @(negedge clk); dma_req_valid = 1; dma_req_addr = addr; dma_req_wdata = data;
    @(posedge clk); while (!dma_req_ready) @(posedge clk);
    @(negedge clk); dma_req_valid = 0;
  endtask

  // expected-slice monitor
  always @(posedge clk) if (rst_n && s_valid && s_ready) begin
    for (int i = 0; i < R; i++) if ($signed(s_a[i*8 +: 8]) !== A[i][s_k]) begin errors++; $display("A MISMATCH k=%0d lane %0d got %0d exp %0d", s_k, i, $signed(s_a[i*8+:8]), A[i][s_k]); end
    for (int j = 0; j < C; j++) if ($signed(s_b[j*8 +: 8]) !== B[s_k][j]) begin errors++; $display("B MISMATCH k=%0d col %0d got %0d exp %0d", s_k, j, $signed(s_b[j*8+:8]), B[s_k][j]); end
    if (s_kg !== s_k) begin errors++; $display("kg mismatch"); end
    if (s_first !== (s_k == 0) || s_last !== (s_k == K-1)) begin errors++; $display("first/last mismatch k=%0d", s_k); end
    if (s_row_mask !== 4'hF || s_col_mask !== 4'hF) begin errors++; $display("mask mismatch"); end
    nslice++;
  end

  initial begin
    for (int i = 0; i < 4; i++) for (int k = 0; k < K; k++) A[i][k] = $signed(8'(i*17 + k*5 - 40));
    for (int k = 0; k < K; k++) for (int j = 0; j < 4; j++) B[k][j] = $signed(8'(k*11 - j*23 + 7));
    #1; repeat (4) @(posedge clk); rst_n = 1; repeat (2) @(posedge clk);
    // fill
    @(negedge clk); fill_begin_valid = 1; @(posedge clk); while (!fill_begin_ready) @(posedge clk); @(negedge clk); fill_begin_valid = 0;
    // A region at 0: rows of LDA=8 bytes -> 2 words per row ; B region at REGION=4096: rows of LDB=4 bytes -> 1 word per row
    for (int i = 0; i < 4; i++) for (int w = 0; w < 2; w++)
      dmaw(i*LDA + w*4, {A[i][w*4+3][7:0], A[i][w*4+2][7:0], A[i][w*4+1][7:0], A[i][w*4+0][7:0]});
    for (int k = 0; k < K; k++) dmaw(4096 + k*LDB, {B[k][3][7:0], B[k][2][7:0], B[k][1][7:0], B[k][0][7:0]});
    repeat (6) @(posedge clk);
    @(negedge clk); fill_end_valid = 1; @(posedge clk); while (!fill_end_ready) @(posedge clk); @(negedge clk); fill_end_valid = 0;
    @(negedge clk); cmp_begin_valid = 1; @(posedge clk); while (!cmp_begin_ready) @(posedge clk); @(negedge clk); cmp_begin_valid = 0;
    // descriptor
    @(negedge clk); tile_valid = 1; @(posedge clk); while (!tile_ready) @(posedge clk); @(negedge clk); tile_valid = 0;
    repeat (60) @(posedge clk);
    $display("slices=%0d errors=%0d engine_idle=%0b tile_rsp_code=%0d", nslice, errors, engine_idle, tile_rsp_code);
    if (nslice == K && errors == 0) $display("SMOKE PASS"); else $display("SMOKE FAIL");
    $finish;
  end
  always @(posedge clk) if (tile_rsp_valid) $display("[%0t] tile_rsp tag=%h err=%0b code=%0d m=%0d n=%0d k=%0d", $time, tile_rsp_tag, tile_rsp_err, tile_rsp_code, tile_rsp_m, tile_rsp_n, tile_rsp_k);
  always @(posedge clk) if (dma_rsp_valid && dma_rsp_err) $display("[%0t] DMA ERR code=%0d", $time, dma_rsp_err_code);
endmodule
