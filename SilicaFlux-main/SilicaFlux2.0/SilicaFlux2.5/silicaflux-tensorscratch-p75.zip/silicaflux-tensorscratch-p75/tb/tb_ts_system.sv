// =============================================================================
// SilicaFlux TensorScratch :: tb_ts_system.sv        SYSTEM TESTBENCH (self-checking)
//
//   DMA model --> sf_tensor_scratchpad --k-slices--> TENSORCORE 02 tensor_systolic_array --readout--> TENSORCORE 04 tensor_accumulator
//                         ^                                                                                  |
//                         +------------- accumulator storage interface (st_*) <------------------------------+   (storage = accbuf)
//   Both tensor cores are the UNMODIFIED third_party copies.  The testbench plays the tile sequencer (what TENSORCORE 06 does):
//   it cuts a GEMM  C[M,N] = A[M,K] x B[K,N]  into operand BLOCKS (panels loaded into an operand set by the DMA), output tiles and K chunks.
//
//   independent checks
//     * every delivered k-slice is compared with a slice computed by the TB from the matrices (s_a, s_b, s_k, s_kg, masks, first/last,
//       tag, s_m0/s_n0), and every output stays stable while s_ready is low;
//     * every tile response (effective sizes) is compared with the TB's own computation;
//     * every committed C row from the accumulator is compared with the TB's 64-bit GEMM, and the final tile is READ BACK from the
//       accumulator buffer through the external port and compared again (the buffer preserved the data);
//     * the full matrices and the observed C are dumped (+dump=) so model/check_dump.py can re-verify with numpy (independent GEMM);
//     * the array's align_err, the accumulator's error flags and the scratchpad's violation flags must stay clear.
//   knobs (plusargs): +seed +M +N +K +BM +BN +BK +TK +PADA +PADB +OFFA +OFFB +ASTALL +MRDY +ORDY +DGAP +DRSP +TRSP +DDUP +SPLITW +NPROB
//                     +RESET_AT=<cycle> (abort a problem with a reset, then run the next one)  +NOEXT (skip the external read-back)
// =============================================================================
`timescale 1ns/1ps
module tb_ts_system;
  // ------------------------------------------------------------ configuration (override with -G)
  parameter int R = 4, C = 4, OW = 8, ACC_W = 32, TILE_K = 32;
  parameter int ND = 1, SET_MAP = 1, NAB = 4, NBB = 2, WB = 4, A_BYTES = 8192, B_BYTES = 8192, ACC_BYTES = 1024, NACCB = 4;
  parameter int RD_LAT = 1, RLAT = 1, ASTAGE = 4, BSTAGE = 8, STARVE = 8, MUL_PIPE = 0, AUTO_REL = 0, CTXQ = 2, WQ = 4;
  parameter int PSUM = 32;                // array partial-sum width (48 for INT16 operands)
  parameter int MAXTILE_ELEMS = 4096;

  localparam int EB       = OW / 8;
  localparam int DW       = 8 * WB;
  localparam int NSETS    = (ND != 0) ? 2 : 1;
  localparam int ASET     = A_BYTES / NSETS;
  localparam int BSET     = B_BYTES / NSETS;
  localparam int AREGION  = (A_BYTES > B_BYTES) ? A_BYTES : B_BYTES;
  localparam int ACC_EW   = C * (ACC_W + 1);
  localparam int ENT_B    = (ACC_EW + 7) / 8;
  localparam int NSLOT    = (ACC_BYTES / (R * ENT_B) < 1) ? 1 : ACC_BYTES / (R * ENT_B);
  localparam int SLOT_W   = (NSLOT > 1) ? $clog2(NSLOT) : 1;
  localparam int RIDW     = (R > 1) ? $clog2(R) : 1;
  localparam int ACC_AW   = (NSLOT * R > 1) ? $clog2(NSLOT * R) : 1;
  localparam int KW = 17, IDX_W = 16, TAG_W = 8, TT_W = 16, CHUNK_W = 16, KTOT_W = 40;
  localparam int RMW = $clog2(R + 1), CNW = $clog2(C + 1);
  localparam int NEV = 30;

  // ------------------------------------------------------------ clock / reset
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ------------------------------------------------------------ DUT signals
  logic dma_req_valid = 0, dma_req_we = 1; logic [31:0] dma_req_addr = 0; logic [DW-1:0] dma_req_wdata = 0; logic [WB-1:0] dma_req_wstrb = 0; logic [TAG_W-1:0] dma_req_tag = 0;
  wire dma_req_ready, dma_rsp_valid, dma_rsp_err, dma_rsp_we; wire [DW-1:0] dma_rsp_rdata; wire [2:0] dma_rsp_err_code; wire [TAG_W-1:0] dma_rsp_tag;
  logic dma_rsp_ready = 1;
  logic fill_begin_valid = 0, fill_end_valid = 0, cmp_begin_valid = 0, cmp_end_valid = 0;
  wire fill_begin_ready, fill_end_ready, cmp_begin_ready, cmp_end_ready; wire [0:0] fill_set, cmp_set; wire [NSETS*2-1:0] set_state;
  logic tile_valid = 0; logic [31:0] tile_a_addr = 0, tile_lda = 0, tile_b_addr = 0, tile_ldb = 0; logic [IDX_W-1:0] tile_m0 = 0, tile_n0 = 0, tile_mat_m = 0, tile_mat_n = 0;
  logic [KW-1:0] tile_k0 = 0, tile_mat_k = 0, tile_k = 0; logic [TAG_W-1:0] tile_tag = 0;
  wire tile_ready, tile_rsp_valid; logic tile_rsp_ready = 1; wire [TAG_W-1:0] tile_rsp_tag; wire tile_rsp_err; wire [3:0] tile_rsp_code; wire [RMW-1:0] tile_rsp_m; wire [CNW-1:0] tile_rsp_n; wire [KW-1:0] tile_rsp_k;
  wire s_valid; wire s_ready; wire [R*OW-1:0] s_a; wire [C*OW-1:0] s_b; wire [KW-1:0] s_k, s_kg; wire [IDX_W-1:0] s_m0, s_n0; wire [R-1:0] s_row_mask; wire [C-1:0] s_col_mask; wire s_first, s_last; wire [TAG_W-1:0] s_tag; wire [0:0] s_set;
  wire busy, engine_idle; wire [NEV*8-1:0] ev_inc; wire [NEV*32-1:0] perf_cnt;
  logic perf_clear = 0;
  logic claim_valid = 0; wire claim_ready; logic [SLOT_W-1:0] claim_slot = 0; logic release_valid = 0; logic [SLOT_W-1:0] release_slot = 0;
  wire cmt_done; wire [SLOT_W-1:0] cmt_slot; wire [TT_W-1:0] cmt_tag; wire [NSLOT*2-1:0] acc_slot_state; wire [3:0] acc_viol;
  logic ext_req_valid = 0, ext_req_we = 0; logic [SLOT_W-1:0] ext_req_slot = 0; logic [RIDW-1:0] ext_req_row = 0; logic [ACC_EW-1:0] ext_req_wdata = 0;
  wire ext_req_ready, ext_rsp_valid, ext_rsp_we, ext_rsp_err; wire [ACC_EW-1:0] ext_rsp_rdata; wire [2:0] ext_rsp_code; logic ext_rsp_ready = 1;

  // ------------------------------------------------------------ the system under test: scratchpad + TENSORCORE 02 array + TENSORCORE 04 accumulator
  // (integration/ts_tc_system.sv: both tensor cores are the unmodified third_party copies; the scratchpad's accumulator buffer is the accumulator's storage)
  logic ar_cfg_valid = 0; wire ar_cfg_ready, ar_cfg_reject; logic [RMW-1:0] ar_cfg_m = 0; logic [CNW-1:0] ar_cfg_n = 0; logic [KW-1:0] ar_cfg_k = 0;
  logic ar_stall = 0; logic m_gate = 1; wire ar_m_valid, ar_m_ready, ar_m_last, ar_align_err; wire [KW-1:0] ar_s_k;
  logic ac_cfg_valid = 0; wire ac_cfg_ready, ac_cfg_reject; logic [SLOT_W-1:0] ac_cfg_slot = 0; logic [TT_W-1:0] ac_cfg_tag = 0;
  logic [RMW-1:0] ac_cfg_m = 0; logic [CNW-1:0] ac_cfg_n = 0; logic [KTOT_W-1:0] ac_cfg_ktot = 0; logic [CHUNK_W-1:0] ac_cfg_nch = 0;
  logic [SLOT_W-1:0] ps_slot = 0; logic [TT_W-1:0] ps_tag = 0; logic [CHUNK_W-1:0] ps_chunk = 0; logic [KW-1:0] ps_chunk_k = 0;
  wire ac_o_valid; logic ac_o_ready = 1; wire [TT_W-1:0] ac_o_tag; wire [RIDW-1:0] ac_o_row; wire ac_o_last; wire [C-1:0] ac_o_col_mask; wire [C*ACC_W-1:0] ac_o_wide; wire [C-1:0] ac_o_ovf;
  wire ac_idle; wire [7:0] ac_err_sticky;

  ts_tc_system #(.ARRAY_ROWS(R), .ARRAY_COLS(C), .TILE_K(TILE_K), .OPERAND_WIDTH(OW), .ACC_WIDTH(ACC_W), .PSUM_WIDTH(PSUM), .A_BUFFER_BYTES(A_BYTES), .B_BUFFER_BYTES(B_BYTES),
      .ACC_BUFFER_BYTES(ACC_BYTES), .NUM_A_BANKS(NAB), .NUM_B_BANKS(NBB), .ENABLE_DOUBLE_BUFFERING(ND), .WORD_BYTES(WB), .NUM_ACC_BANKS(NACCB), .SET_MAP(SET_MAP),
      .READ_LATENCY(RLAT), .A_STAGE(ASTAGE), .B_STAGE(BSTAGE), .WR_STARVE_LIMIT(STARVE), .ACC_RD_LAT(RD_LAT), .ACC_WQ_DEPTH(WQ), .ACC_AUTO_RELEASE(AUTO_REL), .CTXQ_DEPTH(CTXQ),
      .MUL_PIPE(MUL_PIPE), .ADDR_W(32), .IDX_W(IDX_W), .K_W(KW), .TAG_W(TAG_W), .TT_W(TT_W), .CHUNK_W(CHUNK_W), .KTOT_W(KTOT_W)) dut (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(dma_req_we), .dma_req_addr(dma_req_addr), .dma_req_wdata(dma_req_wdata),
    .dma_req_wstrb(dma_req_wstrb), .dma_req_tag(dma_req_tag), .dma_rsp_valid(dma_rsp_valid), .dma_rsp_ready(dma_rsp_ready), .dma_rsp_rdata(dma_rsp_rdata),
    .dma_rsp_err(dma_rsp_err), .dma_rsp_err_code(dma_rsp_err_code), .dma_rsp_we(dma_rsp_we), .dma_rsp_tag(dma_rsp_tag),
    .fill_begin_valid(fill_begin_valid), .fill_begin_ready(fill_begin_ready), .fill_end_valid(fill_end_valid), .fill_end_ready(fill_end_ready),
    .cmp_begin_valid(cmp_begin_valid), .cmp_begin_ready(cmp_begin_ready), .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cmp_end_ready),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(set_state),
    .tile_valid(tile_valid), .tile_ready(tile_ready), .tile_a_addr(tile_a_addr), .tile_lda(tile_lda), .tile_b_addr(tile_b_addr), .tile_ldb(tile_ldb),
    .tile_m0(tile_m0), .tile_n0(tile_n0), .tile_k0(tile_k0), .tile_mat_m(tile_mat_m), .tile_mat_n(tile_mat_n), .tile_mat_k(tile_mat_k), .tile_k(tile_k), .tile_tag(tile_tag),
    .tile_rsp_valid(tile_rsp_valid), .tile_rsp_ready(tile_rsp_ready), .tile_rsp_tag(tile_rsp_tag), .tile_rsp_err(tile_rsp_err), .tile_rsp_code(tile_rsp_code),
    .tile_rsp_m(tile_rsp_m), .tile_rsp_n(tile_rsp_n), .tile_rsp_k(tile_rsp_k),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0), .s_row_mask(s_row_mask), .s_col_mask(s_col_mask),
    .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .ar_cfg_valid(ar_cfg_valid), .ar_cfg_ready(ar_cfg_ready), .ar_cfg_m(ar_cfg_m), .ar_cfg_n(ar_cfg_n), .ar_cfg_k(ar_cfg_k), .ar_cfg_reject(ar_cfg_reject), .ar_stall(ar_stall),
    .readout_gate_i(m_gate), .ar_m_valid(ar_m_valid), .ar_m_ready(ar_m_ready), .ar_m_last(ar_m_last), .ar_align_err(ar_align_err), .ar_s_k(ar_s_k),
    .ac_cfg_valid(ac_cfg_valid), .ac_cfg_ready(ac_cfg_ready), .ac_cfg_slot(ac_cfg_slot), .ac_cfg_tag(ac_cfg_tag), .ac_cfg_m(ac_cfg_m), .ac_cfg_n(ac_cfg_n), .ac_cfg_ktot(ac_cfg_ktot),
    .ac_cfg_nch(ac_cfg_nch), .ac_cfg_reject(ac_cfg_reject), .ps_slot(ps_slot), .ps_tag(ps_tag), .ps_chunk(ps_chunk), .ps_chunk_k(ps_chunk_k),
    .ac_o_valid(ac_o_valid), .ac_o_ready(ac_o_ready), .ac_o_tag(ac_o_tag), .ac_o_row(ac_o_row), .ac_o_last(ac_o_last), .ac_o_col_mask(ac_o_col_mask), .ac_o_wide(ac_o_wide), .ac_o_ovf(ac_o_ovf),
    .cmt_done(cmt_done), .cmt_slot(cmt_slot), .cmt_tag(cmt_tag), .ac_idle(ac_idle), .ac_err_sticky(ac_err_sticky),
    .acc_claim_valid(claim_valid), .acc_claim_ready(claim_ready), .acc_claim_slot(claim_slot), .acc_release_valid(release_valid), .acc_release_slot(release_slot), .acc_slot_state(acc_slot_state),
    .ext_req_valid(ext_req_valid), .ext_req_ready(ext_req_ready), .ext_req_we(ext_req_we), .ext_req_slot(ext_req_slot), .ext_req_row(ext_req_row), .ext_req_wdata(ext_req_wdata),
    .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(ext_rsp_ready), .ext_rsp_rdata(ext_rsp_rdata), .ext_rsp_we(ext_rsp_we), .ext_rsp_err(ext_rsp_err), .ext_rsp_code(ext_rsp_code),
    .acc_viol_sticky(acc_viol), .busy(busy), .engine_idle(engine_idle), .ev_inc(ev_inc), .perf_clear(perf_clear), .perf_cnt(perf_cnt));

  // ------------------------------------------------------------ pseudo random numbers (xorshift64, simulator independent)
  logic [63:0] rs = 64'h9E3779B97F4A7C15;
  function automatic int rnd(input int n);               // 0 .. n-1
    rs = rs ^ (rs << 13); rs = rs ^ (rs >> 7); rs = rs ^ (rs << 17);
    rnd = (n <= 1) ? 0 : int'(rs[40:8] % 64'(n));
  endfunction
  function automatic bit chance(input int pct); chance = (rnd(100) < pct); endfunction
  function automatic int rrange(input int lo, input int hi); rrange = lo + rnd(hi - lo + 1); endfunction

  // ------------------------------------------------------------ knobs
  int seed = 1, pM = 0, pN = 0, pK = 0, pBM = 0, pBN = 0, pBK = 0, pTK = 0, pPADA = -1, pPADB = -1, pOFFA = -1, pOFFB = -1;
  int pASTALL = 0, pMRDY = 0, pORDY = 0, pDGAP = 0, pDRSP = 0, pTRSP = 0, pDDUP = 0, pSPLITW = 0, pNPROB = 1, pRESET_AT = -1, pNOEXT = 0, pTIMEOUT = 4000000;
  string dump_file = "";

  // random stall drivers (all interfaces)
  always @(negedge clk) begin
    ar_stall      <= chance(pASTALL);
    m_gate        <= !chance(pMRDY);
    ac_o_ready    <= !chance(pORDY);
    dma_rsp_ready <= !chance(pDRSP);
    tile_rsp_ready <= !chance(pTRSP);
  end

  // ------------------------------------------------------------ problem data
  logic signed [OW-1:0] Ag [];        // M x K  row-major
  logic signed [OW-1:0] Bg [];        // K x N
  longint               Cexp [];      // M x N  (64-bit, TB's own GEMM)
  longint               Cgot [];
  bit                   Cseen [];
  int M, N, K, BM, BN, BK, TK, PADA, PADB, OFFA, OFFB;
  int MPAD, KPAD, NPAD;                    // leading unwritten (poison) rows / columns in the operand panels: tile origins at arbitrary byte offsets
  int pMPAD = -1, pKPAD = -1, pNPAD = -1;

  // plan tables (parallel queues)
  int  j_mb[$], j_nb[$], j_kb[$], j_bm[$], j_bn[$], j_bk[$], j_abase[$], j_lda[$], j_bbase[$], j_ldb[$], j_tfirst[$], j_tcnt[$], j_dfirst[$], j_dcnt[$];
  // descriptors (one per array launch)
  int  d_job[$], d_a[$], d_lda[$], d_b[$], d_ldb[$], d_m0[$], d_n0[$], d_k0[$], d_matm[$], d_matn[$], d_matk[$], d_tk[$], d_em[$], d_en[$], d_ek[$];
  int  d_slot[$], d_tile[$], d_chunk[$], d_nch[$], d_first[$], d_last[$], d_mglob[$], d_nglob[$];
  // output tiles
  int  t_slot[$], t_m[$], t_n[$], t_em[$], t_en[$], t_nch[$], t_open[$];
  // DMA words
  int  w_addr[$], w_set_is_b[$]; logic [127:0] w_data[$]; logic [15:0] w_strb[$]; int w_job[$];

  function automatic int align_up(input int x, input int a); align_up = ((x + a - 1) / a) * a; endfunction
  function automatic int cdiv(input int a, input int b); cdiv = (a + b - 1) / b; endfunction

  task automatic clear_plan();
    j_mb.delete(); j_nb.delete(); j_kb.delete(); j_bm.delete(); j_bn.delete(); j_bk.delete(); j_abase.delete(); j_lda.delete(); j_bbase.delete(); j_ldb.delete();
    j_tfirst.delete(); j_tcnt.delete(); j_dfirst.delete(); j_dcnt.delete();
    d_job.delete(); d_a.delete(); d_lda.delete(); d_b.delete(); d_ldb.delete(); d_m0.delete(); d_n0.delete(); d_k0.delete(); d_matm.delete(); d_matn.delete(); d_matk.delete();
    d_tk.delete(); d_em.delete(); d_en.delete(); d_ek.delete(); d_slot.delete(); d_tile.delete(); d_chunk.delete(); d_nch.delete(); d_first.delete(); d_last.delete();
    d_mglob.delete(); d_nglob.delete(); t_slot.delete(); t_m.delete(); t_n.delete(); t_em.delete(); t_en.delete(); t_nch.delete(); t_open.delete();
    w_addr.delete(); w_set_is_b.delete(); w_data.delete(); w_strb.delete(); w_job.delete();
    exp_a.delete(); exp_b.delete(); exp_k.delete(); exp_kg.delete(); exp_m0.delete(); exp_n0.delete(); exp_rm.delete(); exp_cm.delete(); exp_first.delete(); exp_last.delete(); exp_tag.delete();
  endtask

  // expected slice queues
  logic [R*OW-1:0] exp_a[$]; logic [C*OW-1:0] exp_b[$]; int exp_k[$], exp_kg[$], exp_m0[$], exp_n0[$], exp_rm[$], exp_cm[$], exp_first[$], exp_last[$], exp_tag[$];

  function automatic logic [OW-1:0] elem_a(input int gr, input int gc);
    elem_a = Ag[gr * K + gc];
  endfunction
  function automatic logic [OW-1:0] elem_b(input int gr, input int gc);
    elem_b = Bg[gr * N + gc];
  endfunction

  // build the operand-block jobs, descriptors, DMA words, expected slices and output tiles
  task automatic plan_problem(output bit ok, output int why);          // why: 1 = not enough accumulator slots for a block, 2 = a block does not fit the operand set
    int mb, nb, kb, mi, ni, ci, jb, nm, nn, nk, bm, bn, bk, lda, ldb, abase, bbase, nchtot, tile_in_block, tcount, gc_base;
    int a_ok, b_ok, t, r, c, w, byt, di, em, en, ek, slot, tile_global, chunks_here, chunk_global;
    int tfirst0;
    logic [127:0] wd; logic [15:0] ws;
    ok = 1; why = 0;
    clear_plan();
    nm = cdiv(M, BM); nn = cdiv(N, BN); nk = cdiv(K, BK);
    nchtot = 0; for (int q = 0; q < nk; q++) nchtot += cdiv((q == nk - 1 ? K - q * BK : BK), TK);
    tcount = 0;
    for (mb = 0; mb < nm; mb++) for (nb = 0; nb < nn; nb++) begin
      bm = (mb == nm - 1) ? M - mb * BM : BM;  bn = (nb == nn - 1) ? N - nb * BN : BN;
      if (cdiv(bm, R) * cdiv(bn, C) > NSLOT) begin ok = 0; why = 1; return; end
      gc_base = 0;
      for (kb = 0; kb < nk; kb++) begin
        bk = (kb == nk - 1) ? K - kb * BK : BK;
        lda = align_up((KPAD + bk) * EB, WB) + PADA * WB;  abase = OFFA * WB;
        ldb = align_up((NPAD + bn) * EB, WB) + PADB * WB;  bbase = OFFB * WB;
        if (abase + (MPAD + bm - 1) * lda + (KPAD + bk) * EB > ASET || bbase + (KPAD + bk - 1) * ldb + (NPAD + bn) * EB > BSET) begin
          ok = 0; why = 2; return;
        end
        jb = j_mb.size();
        j_mb.push_back(mb); j_nb.push_back(nb); j_kb.push_back(kb); j_bm.push_back(bm); j_bn.push_back(bn); j_bk.push_back(bk);
        j_abase.push_back(abase); j_lda.push_back(lda); j_bbase.push_back(bbase); j_ldb.push_back(ldb);
        // ---- DMA words of the A block and of the B block (only bytes that hold matrix data are enabled)
        j_dfirst.push_back(w_addr.size());
        for (r = 0; r < bm; r++) for (w = (KPAD * EB) / WB; w <= ((KPAD + bk) * EB - 1) / WB; w++) begin
          wd = '0; ws = '0;
          for (byt = 0; byt < WB; byt++) begin
            int pb; pb = w * WB + byt;                                    // byte position inside the panel row
            if (pb >= KPAD * EB && pb < (KPAD + bk) * EB) begin
              c = (pb - KPAD * EB) / EB;
              wd[byt*8 +: 8] = elem_a(mb * BM + r, kb * BK + c) >> (((pb - KPAD * EB) % EB) * 8);
              ws[byt] = 1'b1;
            end
          end
          w_addr.push_back(abase + (MPAD + r) * lda + w * WB); w_set_is_b.push_back(0); w_data.push_back(wd); w_strb.push_back(ws); w_job.push_back(jb);
        end
        for (r = 0; r < bk; r++) for (w = (NPAD * EB) / WB; w <= ((NPAD + bn) * EB - 1) / WB; w++) begin
          wd = '0; ws = '0;
          for (byt = 0; byt < WB; byt++) begin
            int pb; pb = w * WB + byt;
            if (pb >= NPAD * EB && pb < (NPAD + bn) * EB) begin
              c = (pb - NPAD * EB) / EB;
              wd[byt*8 +: 8] = elem_b(kb * BK + r, nb * BN + c) >> (((pb - NPAD * EB) % EB) * 8);
              ws[byt] = 1'b1;
            end
          end
          w_addr.push_back(bbase + (KPAD + r) * ldb + w * WB); w_set_is_b.push_back(1); w_data.push_back(wd); w_strb.push_back(ws); w_job.push_back(jb);
        end
        j_dcnt.push_back(w_addr.size() - j_dfirst[jb]);
        // ---- descriptors: output tile (mi, ni), chunks ci
        j_tfirst.push_back(d_job.size());
        tile_in_block = 0;
        for (mi = 0; mi < cdiv(bm, R); mi++) for (ni = 0; ni < cdiv(bn, C); ni++) begin
          em = (bm - mi * R > R) ? R : bm - mi * R;  en = (bn - ni * C > C) ? C : bn - ni * C;
          tile_global = tcount + tile_in_block;
          slot = tile_in_block % NSLOT;
          if (kb == 0) begin
            t_slot.push_back(slot); t_m.push_back(mb * BM + mi * R); t_n.push_back(nb * BN + ni * C); t_em.push_back(em); t_en.push_back(en); t_nch.push_back(nchtot); t_open.push_back(0);
          end
          for (ci = 0; ci < cdiv(bk, TK); ci++) begin
            ek = (bk - ci * TK > TK) ? TK : bk - ci * TK;
            d_job.push_back(jb); d_a.push_back(abase); d_lda.push_back(lda); d_b.push_back(bbase); d_ldb.push_back(ldb);
            d_m0.push_back(MPAD + mi * R); d_n0.push_back(NPAD + ni * C); d_k0.push_back(KPAD + ci * TK); d_matm.push_back(MPAD + bm); d_matn.push_back(NPAD + bn); d_matk.push_back(KPAD + bk); d_tk.push_back(TK);
            d_em.push_back(em); d_en.push_back(en); d_ek.push_back(ek);
            d_slot.push_back(slot); d_tile.push_back(tile_global); d_chunk.push_back(gc_base + ci); d_nch.push_back(nchtot);
            d_first.push_back((kb == 0 && ci == 0) ? 1 : 0); d_last.push_back((kb == nk - 1 && ci == cdiv(bk, TK) - 1) ? 1 : 0);
            d_mglob.push_back(mb * BM + mi * R); d_nglob.push_back(nb * BN + ni * C);
            // expected slices of this descriptor
            di = d_job.size() - 1;
            for (int k = 0; k < ek; k++) begin
              logic [R*OW-1:0] ea; logic [C*OW-1:0] eb;
              ea = '0; eb = '0;
              for (int i = 0; i < R; i++) if (i < em) ea[i*OW +: OW] = elem_a(mb * BM + mi * R + i, kb * BK + ci * TK + k);
              for (int j = 0; j < C; j++) if (j < en) eb[j*OW +: OW] = elem_b(kb * BK + ci * TK + k, nb * BN + ni * C + j);
              exp_a.push_back(ea); exp_b.push_back(eb); exp_k.push_back(k); exp_kg.push_back(KPAD + ci * TK + k); exp_m0.push_back(MPAD + mi * R); exp_n0.push_back(NPAD + ni * C);
              exp_rm.push_back((1 << em) - 1); exp_cm.push_back((1 << en) - 1); exp_first.push_back(k == 0); exp_last.push_back(k == ek - 1); exp_tag.push_back(di % 256);
            end
          end
          tile_in_block++;
        end
        j_tcnt.push_back(d_job.size() - j_tfirst[jb]);
        gc_base += cdiv(bk, TK);
      end
      tcount += tile_in_block;
    end
  endtask

  // ------------------------------------------------------------ cycle helpers and abort
  bit abort = 0;
  task automatic tick(); @(posedge clk); endtask

  // ------------------------------------------------------------ process 1: DMA fill (per job: begin, words, wait responses, end)
  int dma_sent = 0, dma_acked = 0, dma_exp_ack = 0;
  int dma_errs = 0;
  always @(posedge clk) if (rst_n && dma_rsp_valid && dma_rsp_ready) begin
    dma_acked <= dma_acked + 1;
    if (dma_rsp_err) begin dma_errs <= dma_errs + 1; $display("[%0t] UNEXPECTED DMA error code %0d tag %0d", $time, dma_rsp_err_code, dma_rsp_tag); end
  end
  int fill_job_done = 0;
  task automatic dma_write(input int addr, input logic [127:0] data, input logic [15:0] strb);
    while (chance(pDGAP) && !abort) begin @(negedge clk); dma_req_valid = 0; end
    @(negedge clk); dma_req_valid = 1; dma_req_we = 1; dma_req_addr = addr; dma_req_wdata = data[DW-1:0]; dma_req_wstrb = strb[WB-1:0]; dma_req_tag = dma_sent[TAG_W-1:0];
    tick(); while (!dma_req_ready && !abort) tick();
    dma_sent++;
    @(negedge clk); dma_req_valid = 0;
  endtask
  task automatic fill_proc();
    for (int j = 0; j < j_mb.size() && !abort; j++) begin
      int set_sel, base_a, base_b, n0;
      @(negedge clk); fill_begin_valid = 1; tick(); while (!fill_begin_ready && !abort) tick(); @(negedge clk); fill_begin_valid = 0;
      if (abort) return;
      set_sel = int'(fill_set);
      n0 = dma_sent;
      for (int q = 0; q < j_dcnt[j] && !abort; q++) begin
        int wi, a;
        wi = j_dfirst[j] + q;
        a = (w_set_is_b[wi] ? AREGION + set_sel * BSET : set_sel * ASET) + w_addr[wi];
        if (chance(pDDUP)) dma_write(a, ~w_data[wi], w_strb[wi]);                 // write garbage first: the real data must win (in-order WAW)
        if (pSPLITW != 0 && chance(pSPLITW) && WB > 1 && w_strb[wi] != 0) begin  // split into two partial-strobe writes
          logic [15:0] lo, hi; lo = w_strb[wi] & 16'((1 << (WB/2)) - 1); hi = w_strb[wi] & ~16'((1 << (WB/2)) - 1);
          dma_write(a, w_data[wi], hi); dma_write(a, w_data[wi], lo);
        end else dma_write(a, w_data[wi], w_strb[wi]);
      end
      while (dma_acked < dma_sent && !abort) tick();                              // every write acknowledged (= committed) before fill_end
      @(negedge clk); fill_end_valid = 1; tick(); while (!fill_end_ready && !abort) tick(); @(negedge clk); fill_end_valid = 0;
      fill_job_done = j + 1;
    end
  endtask

  // ------------------------------------------------------------ process 2: compute ownership + tile descriptors
  int issued = 0;
  task automatic cmp_proc();
    for (int j = 0; j < j_mb.size() && !abort; j++) begin
      @(negedge clk); cmp_begin_valid = 1; tick(); while (!cmp_begin_ready && !abort) tick(); @(negedge clk); cmp_begin_valid = 0;
      if (abort) return;
      for (int q = 0; q < j_tcnt[j] && !abort; q++) begin
        int di; di = j_tfirst[j] + q;
        while (chance(pDGAP) && !abort) begin @(negedge clk); tile_valid = 0; end
        @(negedge clk); tile_valid = 1; tile_a_addr = d_a[di]; tile_lda = d_lda[di]; tile_b_addr = d_b[di]; tile_ldb = d_ldb[di]; tile_m0 = d_m0[di]; tile_n0 = d_n0[di];
        tile_k0 = d_k0[di]; tile_mat_m = d_matm[di]; tile_mat_n = d_matn[di]; tile_mat_k = d_matk[di]; tile_k = d_tk[di]; tile_tag = di[7:0];
        tick(); while (!tile_ready && !abort) tick();
        @(negedge clk); tile_valid = 0; issued++;
      end
      @(negedge clk); cmp_end_valid = 1; tick(); while (!cmp_end_ready && !abort) tick(); @(negedge clk); cmp_end_valid = 0;
    end
  endtask

  // ------------------------------------------------------------ tile response collector (in order, checks effective sizes)
  int rsp_q_tag[$], rsp_q_m[$], rsp_q_n[$], rsp_q_k[$], rsp_q_err[$];
  int rsp_count = 0; int errors = 0;
  always @(posedge clk) if (rst_n && tile_rsp_valid && tile_rsp_ready) begin
    rsp_q_tag.push_back(int'(tile_rsp_tag)); rsp_q_m.push_back(int'(tile_rsp_m)); rsp_q_n.push_back(int'(tile_rsp_n)); rsp_q_k.push_back(int'(tile_rsp_k)); rsp_q_err.push_back(int'(tile_rsp_err));
  end

  // ------------------------------------------------------------ process 3: array / accumulator launches
  int launched = 0;
  task automatic launch_proc();
    for (int di = 0; di < d_job.size() && !abort; di++) begin
      int slot, rm, rn, rk, rerr, rtag;
      slot = d_slot[di];
      while (rsp_q_tag.size() == 0 && !abort) tick();
      if (abort) return;
      rtag = rsp_q_tag.pop_front(); rm = rsp_q_m.pop_front(); rn = rsp_q_n.pop_front(); rk = rsp_q_k.pop_front(); rerr = rsp_q_err.pop_front();
      if (rerr != 0 || rtag != (di % 256) || rm != d_em[di] || rn != d_en[di] || rk != d_ek[di]) begin
        errors++; $display("[%0t] TILE RSP MISMATCH desc %0d: err=%0d tag=%0d(%0d) m=%0d(%0d) n=%0d(%0d) k=%0d(%0d)", $time, di, rerr, rtag, di % 256, rm, d_em[di], rn, d_en[di], rk, d_ek[di]);
      end
      if (d_first[di] != 0) begin
        // reserve the accumulator slot (waits until the previous tile in it has been drained and released), then open it in TENSORCORE 04
        @(negedge clk); claim_valid = 1; claim_slot = SLOT_W'(slot); tick(); while (!claim_ready && !abort) tick(); @(negedge clk); claim_valid = 0;
        @(negedge clk); ac_cfg_valid = 1; ac_cfg_slot = SLOT_W'(slot); ac_cfg_tag = TT_W'(d_tile[di]); ac_cfg_m = RMW'(d_em[di]); ac_cfg_n = CNW'(d_en[di]);
        ac_cfg_ktot = KTOT_W'(K); ac_cfg_nch = CHUNK_W'(d_nch[di]);
        tick(); while (!ac_cfg_ready && !abort) tick(); @(negedge clk); ac_cfg_valid = 0;
      end
      // launch the array for this chunk with the sizes the scratchpad reported
      @(negedge clk); ar_cfg_valid = 1; ar_cfg_m = RMW'(rm); ar_cfg_n = CNW'(rn); ar_cfg_k = KW'(rk);
      ps_slot = SLOT_W'(slot); ps_tag = TT_W'(d_tile[di]); ps_chunk = CHUNK_W'(d_chunk[di]); ps_chunk_k = KW'(rk);
      tick(); while (!ar_cfg_ready && !abort) tick(); @(negedge clk); ar_cfg_valid = 0;
      // wait for the readout of this launch
      tick(); while (!(ar_m_valid && ar_m_ready && ar_m_last) && !abort) tick();
      launched++;
    end
  endtask

  // ------------------------------------------------------------ slice monitor: every delivered slice against the TB's own model
  int slices = 0;
  logic        prev_valid = 0, prev_ready = 0; logic [R*OW-1:0] prev_a; logic [C*OW-1:0] prev_b; logic [KW-1:0] prev_k, prev_kg;
  always @(posedge clk) if (rst_n) begin
    // back-pressure stability: valid stays, payload stays
    if (prev_valid && !prev_ready) begin
      if (!s_valid || s_a !== prev_a || s_b !== prev_b || s_k !== prev_k || s_kg !== prev_kg) begin errors++; $display("[%0t] SLICE NOT STABLE under back-pressure", $time); end
    end
    prev_valid <= s_valid; prev_ready <= s_ready; prev_a <= s_a; prev_b <= s_b; prev_k <= s_k; prev_kg <= s_kg;
    if (s_valid && s_ready) begin
      if (exp_a.size() == 0) begin errors++; $display("[%0t] UNEXPECTED SLICE", $time); end
      else begin
        logic [R*OW-1:0] ea; logic [C*OW-1:0] eb; int ek, ekg, em0, en0, erm, ecm, ef, el, etag;
        ea = exp_a.pop_front(); eb = exp_b.pop_front(); ek = exp_k.pop_front(); ekg = exp_kg.pop_front(); em0 = exp_m0.pop_front(); en0 = exp_n0.pop_front();
        erm = exp_rm.pop_front(); ecm = exp_cm.pop_front(); ef = exp_first.pop_front(); el = exp_last.pop_front(); etag = exp_tag.pop_front();
        if (s_a !== ea || s_b !== eb || int'(s_k) !== ek || int'(s_kg) !== ekg || int'(s_m0) !== em0 || int'(s_n0) !== en0 || int'(s_row_mask) !== erm || int'(s_col_mask) !== ecm ||
            int'(s_first) !== ef || int'(s_last) !== el || int'(s_tag) !== etag) begin
          errors++;
          if (errors < 20) $display("[%0t] SLICE MISMATCH #%0d: a=%h/%h b=%h/%h k=%0d/%0d kg=%0d/%0d m0=%0d/%0d n0=%0d/%0d rm=%0d/%0d cm=%0d/%0d f=%0d/%0d l=%0d/%0d tag=%0d/%0d",
              $time, slices, s_a, ea, s_b, eb, s_k, ek, s_kg, ekg, s_m0, em0, s_n0, en0, s_row_mask, erm, s_col_mask, ecm, s_first, ef, s_last, el, s_tag, etag);
        end
        if (ar_s_k !== s_k) begin errors++; if (errors < 20) $display("[%0t] array s_k %0d != slice s_k %0d", $time, ar_s_k, s_k); end
      end
      slices++;
    end
  end

  // ------------------------------------------------------------ process 4: committed rows + external read-back + release
  int commits = 0, rows_got = 0, ext_checked = 0;
  task automatic store_row(input int tid, input int row, input int lane, input longint v);
    int gr, gcn;
    gr = t_m[tid] + row; gcn = t_n[tid] + lane;
    if (Cseen[gr * N + gcn]) begin errors++; $display("[%0t] C[%0d][%0d] committed twice", $time, gr, gcn); end
    Cseen[gr * N + gcn] = 1; Cgot[gr * N + gcn] = v;
  endtask
  always @(posedge clk) if (rst_n && ac_o_valid && ac_o_ready) begin
    int tid, row;
    tid = int'(ac_o_tag); row = int'(ac_o_row);
    if (tid >= t_slot.size()) begin errors++; $display("[%0t] commit of unknown tile %0d", $time, tid); end
    else begin
      for (int j = 0; j < C; j++) if (ac_o_col_mask[j]) begin
        longint v; v = $signed(ac_o_wide[j*ACC_W +: ACC_W]);
        store_row(tid, row, j, v);
        if (ac_o_ovf[j]) begin errors++; $display("[%0t] unexpected accumulator overflow flag", $time); end
      end
      rows_got++;
    end
  end
  // completion events: external read-back of the final tile, then release
  int cpl_q_slot[$], cpl_q_tid[$];
  always @(posedge clk) if (rst_n && cmt_done) begin cpl_q_slot.push_back(int'(cmt_slot)); cpl_q_tid.push_back(int'(cmt_tag)); end
  task automatic readback_proc();
    forever begin
      int sl, tid;
      while (cpl_q_slot.size() == 0) begin tick(); if (abort) return; end
      sl = cpl_q_slot.pop_front(); tid = cpl_q_tid.pop_front();
      tick(); tick();
      if (AUTO_REL == 0) begin
        if (pNOEXT == 0) begin
          for (int r = 0; r < t_em[tid]; r++) begin
            @(negedge clk); ext_req_valid = 1; ext_req_we = 0; ext_req_slot = SLOT_W'(sl); ext_req_row = RIDW'(r);
            tick(); while (!ext_req_ready && !abort) tick(); @(negedge clk); ext_req_valid = 0;
            tick(); while (!ext_rsp_valid && !abort) tick();
            if (abort) return;
            if (ext_rsp_err) begin errors++; $display("[%0t] ext read slot %0d row %0d rejected code %0d", $time, sl, r, ext_rsp_code); end
            else for (int j = 0; j < t_en[tid]; j++) begin
              longint v, e; v = $signed(ext_rsp_rdata[j*(ACC_W+1) +: ACC_W]); e = Cexp[(t_m[tid] + r) * N + t_n[tid] + j];
              if (v !== e || ext_rsp_rdata[j*(ACC_W+1) + ACC_W]) begin errors++; $display("[%0t] READ-BACK MISMATCH tile %0d row %0d lane %0d: got %0d exp %0d", $time, tid, r, j, v, e); end
            end
            ext_checked++;
          end
        end
        @(negedge clk); release_valid = 1; release_slot = SLOT_W'(sl); tick(); @(negedge clk); release_valid = 0;
      end
      // sl / tid are consumed here on purpose: with AUTO_RELEASE the branch above is constant-false and Verilator would otherwise drop the
      // dead assignments together with the side-effecting pop_front() calls (the queue would never shrink)
      commits += (sl >= 0 && tid >= 0) ? 1 : 0;
    end
  endtask

  // ------------------------------------------------------------ run one problem
  task automatic run_problem(input int pidx);
    bit ok; int t0, why, tries; bit auto_blocks;
    M = pM; N = pN; K = pK; BM = pBM; BN = pBN; BK = pBK; TK = pTK; PADA = pPADA; PADB = pPADB; OFFA = pOFFA; OFFB = pOFFB;
    if (M == 0) M = rrange(1, 3 * R + 2);  if (N == 0) N = rrange(1, 3 * C + 2);  if (K == 0) K = rrange(1, 40);
    if (TK == 0) TK = rrange(1, TILE_K);   if (TK > TILE_K) TK = TILE_K;
    if (BM == 0) BM = R * rrange(1, 3);    if (BN == 0) BN = C * rrange(1, 3);    if (BK == 0) BK = rrange(1, 40);
    if (BM > M) BM = M; if (BN > N) BN = N; if (BK > K) BK = K;
    if (BM % R != 0 && BM < M) BM = align_up(BM, R); if (BN % C != 0 && BN < N) BN = align_up(BN, C);
    if (PADA < 0) PADA = rnd(3);  if (PADB < 0) PADB = rnd(3);  if (OFFA < 0) OFFA = rnd(5);  if (OFFB < 0) OFFB = rnd(5);
    MPAD = pMPAD; KPAD = pKPAD; NPAD = pNPAD;
    if (MPAD < 0) MPAD = rnd(3);  if (KPAD < 0) KPAD = rnd(4);  if (NPAD < 0) NPAD = rnd(WB / EB + 4);
    // data
    Ag = new[M * K]; Bg = new[K * N]; Cexp = new[M * N]; Cgot = new[M * N]; Cseen = new[M * N];
    for (int i = 0; i < M * K; i++) Ag[i] = (rnd(10) == 0) ? ((rnd(2) == 0) ? {1'b1, {(OW-1){1'b0}}} : {1'b0, {(OW-1){1'b1}}}) : OW'(rnd(1 << OW));
    for (int i = 0; i < K * N; i++) Bg[i] = (rnd(10) == 0) ? ((rnd(2) == 0) ? {1'b1, {(OW-1){1'b0}}} : {1'b0, {(OW-1){1'b1}}}) : OW'(rnd(1 << OW));
    for (int m = 0; m < M; m++) for (int n = 0; n < N; n++) begin
      longint acc; acc = 0;
      for (int k = 0; k < K; k++) acc += longint'($signed(Ag[m * K + k])) * longint'($signed(Bg[k * N + n]));
      Cexp[m * N + n] = acc; Cgot[m * N + n] = 0; Cseen[m * N + n] = 0;
    end
    auto_blocks = (pBM == 0 || pBN == 0 || pBK == 0 || pPADA < 0 || pPADB < 0 || pMPAD < 0 || pKPAD < 0 || pNPAD < 0);
    plan_problem(ok, why);
    for (tries = 0; !ok && auto_blocks && tries < 8; tries++) begin       // randomly chosen shapes may be unplannable: shrink and retry (explicit arguments never are)
      if (why == 1) begin if (pBM == 0 && BM > R) BM = ((BM / 2 + R - 1) / R) * R; if (pBN == 0 && BN > C) BN = ((BN / 2 + C - 1) / C) * C; if (BM >= R && BN >= C && BM <= R && BN <= C) begin end end
      else begin if (pBK == 0 && BK > 1) BK = (BK + 1) / 2; if (pMPAD < 0) MPAD = 0; if (pKPAD < 0) KPAD = 0; if (pNPAD < 0) NPAD = NPAD / 2; if (pPADA < 0) PADA = 0; if (pPADB < 0) PADB = 0; if (pOFFA < 0) OFFA = 0; if (pOFFB < 0) OFFB = 0; end
      if (BM > M) BM = M; if (BN > N) BN = N; if (BK > K) BK = K;
      plan_problem(ok, why);
    end
    if (!ok) begin errors++; $display("PLAN FAILED for problem %0d (why=%0d: 1 slots, 2 set fit) M=%0d N=%0d K=%0d BM=%0d BN=%0d BK=%0d TK=%0d", pidx, why, M, N, K, BM, BN, BK, TK); return; end
    $display("PROBLEM %0d: M=%0d N=%0d K=%0d  blocks BM=%0d BN=%0d BK=%0d  TK=%0d  padA=%0d padB=%0d offA=%0d offB=%0d  mpad=%0d kpad=%0d npad=%0d  jobs=%0d launches=%0d slices=%0d dmaWords=%0d",
             pidx, M, N, K, BM, BN, BK, TK, PADA, PADB, OFFA, OFFB, MPAD, KPAD, NPAD, j_mb.size(), d_job.size(), exp_a.size(), w_addr.size());
    t0 = int'(cyc);
    dma_sent = 0; dma_acked = 0; issued = 0; launched = 0; slices = 0; commits = 0; rows_got = 0; ext_checked = 0; fill_job_done = 0;
    rsp_q_tag.delete(); rsp_q_m.delete(); rsp_q_n.delete(); rsp_q_k.delete(); rsp_q_err.delete(); cpl_q_slot.delete(); cpl_q_tid.delete();
    abort = 0;
    fork
      fill_proc(); cmp_proc(); launch_proc(); readback_proc();
    join_none
    begin : watch
        int expect_rows; bit finished;
        expect_rows = 0; finished = 0; for (int t = 0; t < t_slot.size(); t++) expect_rows += t_em[t];
        while (!abort && !finished) begin
          tick();
          if (launched == d_job.size() && rows_got == expect_rows && commits == t_slot.size() && fill_job_done == j_mb.size() && issued == d_job.size() && engine_idle && ac_idle) finished = 1;
          if (int'(cyc) - t0 > pTIMEOUT) begin errors++; $display("TIMEOUT: launched %0d/%0d rows %0d/%0d commits %0d/%0d fill %0d issued %0d", launched, d_job.size(), rows_got, expect_rows, commits, t_slot.size(), fill_job_done, issued); abort = 1; end
          if (pRESET_AT >= 0 && int'(cyc) - t0 == pRESET_AT) abort = 1;
        end
    end
    if (!abort) begin
      // quiesce: let the remaining processes finish (readback_proc loops forever -> end it)
      repeat (4) tick();
      abort = 1; tick(); tick();
      // final checks
      if (exp_a.size() != 0) begin errors++; $display("%0d expected slices were never delivered", exp_a.size()); end
      for (int i = 0; i < M * N; i++) if (!Cseen[i] || Cgot[i] !== Cexp[i]) begin
        errors++; if (errors < 30) $display("C MISMATCH [%0d][%0d]: got %0d exp %0d seen=%0b", i / N, i % N, Cgot[i], Cexp[i], Cseen[i]);
      end
      if (ar_align_err) begin errors++; $display("array align_err set"); end
      if (ac_err_sticky != 0) begin errors++; $display("accumulator err_sticky=%h", ac_err_sticky); end
      if (acc_viol != 0) begin errors++; $display("scratchpad accumulator-buffer violation flags=%b", acc_viol); end
      if (dma_errs != 0) begin errors++; end
      $display("PROBLEM %0d done in %0d cycles: slices=%0d commits=%0d ext_rows_checked=%0d errors=%0d", pidx, int'(cyc) - t0, slices, commits, ext_checked, errors);
      dump_problem(pidx);
    end
  endtask

  task automatic dump_problem(input int pidx);
    if (dump_file != "") begin
      int fd; fd = $fopen(dump_file, (pidx == 0) ? "w" : "a");
      $fwrite(fd, "PROBLEM %0d %0d %0d %0d\n", pidx, M, N, K);
      $fwrite(fd, "A"); for (int i = 0; i < M * K; i++) $fwrite(fd, " %0d", $signed(Ag[i])); $fwrite(fd, "\n");
      $fwrite(fd, "B"); for (int i = 0; i < K * N; i++) $fwrite(fd, " %0d", $signed(Bg[i])); $fwrite(fd, "\n");
      $fwrite(fd, "C"); for (int i = 0; i < M * N; i++) $fwrite(fd, " %0d", Cgot[i]); $fwrite(fd, "\n");
      $fclose(fd);
    end
  endtask

  function automatic string ev_name(input int e);
    case (e)
      0: ev_name = "cycles"; 1: ev_name = "active"; 2: ev_name = "slices"; 3: ev_name = "starve"; 4: ev_name = "starve_a"; 5: ev_name = "starve_b"; 6: ev_name = "array_bp";
      7: ev_name = "a_rd_words"; 8: ev_name = "b_rd_words"; 9: ev_name = "a_rd_stall"; 10: ev_name = "b_rd_stall"; 11: ev_name = "a_bank_conf"; 12: ev_name = "b_bank_conf";
      13: ev_name = "rd_wr_block"; 14: ev_name = "dma_wr_stall"; 15: ev_name = "dma_wr_words"; 16: ev_name = "dma_wr_forced"; 17: ev_name = "dma_err"; 18: ev_name = "tile_ok";
      19: ev_name = "tile_err"; 20: ev_name = "overlap"; 21: ev_name = "acc_rd"; 22: ev_name = "acc_wr"; 23: ev_name = "acc_rd_deny"; 24: ev_name = "acc_wr_freeze";
      25: ev_name = "acc_ext_wait"; 26: ev_name = "acc_ext_ok"; 27: ev_name = "acc_ext_err"; 28: ev_name = "acc_viol"; 29: ev_name = "acc_fwd"; default: ev_name = "?";
    endcase
  endfunction

  // ------------------------------------------------------------ main
  initial begin
    string s;
    if ($value$plusargs("seed=%d", seed)) rs = 64'h9E3779B97F4A7C15 ^ (64'(seed) * 64'h2545F4914F6CDD1D);
    void'($value$plusargs("M=%d", pM)); void'($value$plusargs("N=%d", pN)); void'($value$plusargs("K=%d", pK));
    void'($value$plusargs("BM=%d", pBM)); void'($value$plusargs("BN=%d", pBN)); void'($value$plusargs("BK=%d", pBK)); void'($value$plusargs("TK=%d", pTK));
    void'($value$plusargs("MPAD=%d", pMPAD)); void'($value$plusargs("KPAD=%d", pKPAD)); void'($value$plusargs("NPAD=%d", pNPAD));
    void'($value$plusargs("PADA=%d", pPADA)); void'($value$plusargs("PADB=%d", pPADB)); void'($value$plusargs("OFFA=%d", pOFFA)); void'($value$plusargs("OFFB=%d", pOFFB));
    void'($value$plusargs("ASTALL=%d", pASTALL)); void'($value$plusargs("MRDY=%d", pMRDY)); void'($value$plusargs("ORDY=%d", pORDY)); void'($value$plusargs("DGAP=%d", pDGAP));
    void'($value$plusargs("DRSP=%d", pDRSP)); void'($value$plusargs("TRSP=%d", pTRSP)); void'($value$plusargs("DDUP=%d", pDDUP)); void'($value$plusargs("SPLITW=%d", pSPLITW));
    void'($value$plusargs("NPROB=%d", pNPROB)); void'($value$plusargs("RESET_AT=%d", pRESET_AT)); void'($value$plusargs("NOEXT=%d", pNOEXT)); void'($value$plusargs("TIMEOUT=%d", pTIMEOUT));
    if ($value$plusargs("dump=%s", s)) dump_file = s;
    $display("CONFIG R=%0d C=%0d OW=%0d ACC_W=%0d ND=%0d SET_MAP=%0d NAB=%0d NBB=%0d WB=%0d A=%0d B=%0d NACCB=%0d RD_LAT=%0d RLAT=%0d NSLOT=%0d seed=%0d", R, C, OW, ACC_W, ND, SET_MAP, NAB, NBB, WB, A_BYTES, B_BYTES, NACCB, RD_LAT, RLAT, NSLOT, seed);
    rst_n = 0; repeat (6) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);
    for (int p = 0; p < pNPROB; p++) begin
      run_problem(p);
      if (pRESET_AT >= 0 && p == 0 && abort) begin
        // reset in the middle of a problem: everything is abandoned, the next problem must run clean
        $display("RESET injected at %0d cycles into problem 0", pRESET_AT);
        ar_cfg_valid = 0; ac_cfg_valid = 0; claim_valid = 0; fill_begin_valid = 0; fill_end_valid = 0; cmp_begin_valid = 0; cmp_end_valid = 0; tile_valid = 0; dma_req_valid = 0; ext_req_valid = 0; release_valid = 0;
        rst_n = 0; repeat (5) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);
        if (!engine_idle) begin errors++; $display("engine not idle after reset"); end
        pRESET_AT = -1;
        dma_errs = 0; errors = 0;                         // the abandoned problem is not checked, only the recovery is
      end
    end
    for (int e = 0; e < NEV; e++) $display("PERF %s %0d", ev_name(e), perf_cnt[e*32 +: 32]);
    if (errors == 0) $display("TB_RESULT PASS"); else $display("TB_RESULT FAIL errors=%0d", errors);
    $finish;
  end
endmodule
