// =============================================================================
// SilicaFlux TensorScratch :: tb_ts_errors.sv       DIRECTED ERROR / BOUNDARY / OWNERSHIP TESTS (self-checking, DUT only)
//   E1  DMA error codes and their priority  RANGE > ALIGN > UNSUP > OWNER, in-order responses, tags, byte-strobe no-op
//   E2  every tile-descriptor error code and its priority; nothing is delivered for a rejected tile
//   E3  buffer-boundary exactness: a tile whose last byte is SET_BYTES-1 is accepted and delivered correctly (A and B), one byte more is
//       rejected; the ADDR_W overflow codes
//   E4  no side effects: writes into the set being computed on are refused WHILE slices stream (back-pressured) and the slices stay correct
//   E5  ownership gates: fill_end waits for a quiet DMA port, cmp_end waits for the engine, fill_begin / cmp_begin wait for their state
//   E6  ping-pong: fill of set 1 while computing set 0 (DMA to set 0 refused, to set 1 accepted); the two tiles use DIFFERENT matrices, so
//       any aliasing between the sets would be a data error
// Accumulator-buffer hazards and out-of-range accumulator accesses are covered in tb_ts_acc.sv.
// =============================================================================
`timescale 1ns/1ps
module tb_ts_errors;
  localparam int R = 4, C = 4, A_TOT = 8192, B_TOT = 16384, ASET = A_TOT / 2, BSET = B_TOT / 2, REGION = 16384;   // two sets: A set 4096 B, B set 8192 B
  localparam logic [63:0] BASE = 64'h0001_0000;
  logic clk = 0, rst_n = 0; always #5 clk = ~clk;
  int errors = 0, checks = 0;

  logic dma_req_valid = 0, dma_req_we = 1; logic [31:0] dma_req_addr = 0, dma_req_wdata = 0; logic [3:0] dma_req_wstrb = 4'hF; logic [7:0] dma_req_tag = 0;
  wire dma_req_ready, dma_rsp_valid, dma_rsp_err, dma_rsp_we; wire [31:0] dma_rsp_rdata; wire [2:0] dma_rsp_err_code; wire [7:0] dma_rsp_tag;
  logic fill_begin_valid = 0, fill_end_valid = 0, cmp_begin_valid = 0, cmp_end_valid = 0;
  wire fill_begin_ready, fill_end_ready, cmp_begin_ready, cmp_end_ready; wire [0:0] fill_set, cmp_set; wire [3:0] set_state;
  logic tile_valid = 0; logic [31:0] tile_a_addr = 0, tile_lda = 0, tile_b_addr = 0, tile_ldb = 0; logic [15:0] tile_m0 = 0, tile_n0 = 0, tile_mat_m = 4, tile_mat_n = 4;
  logic [16:0] tile_k0 = 0, tile_mat_k = 8, tile_k = 8; logic [7:0] tile_tag = 0;
  wire tile_ready, tile_rsp_valid; wire [7:0] tile_rsp_tag; wire tile_rsp_err; wire [3:0] tile_rsp_code; wire [2:0] tile_rsp_m, tile_rsp_n; wire [16:0] tile_rsp_k;
  wire s_valid; logic s_ready = 1; wire [31:0] s_a, s_b; wire [16:0] s_k, s_kg; wire [15:0] s_m0, s_n0; wire [3:0] s_row_mask, s_col_mask; wire s_first, s_last; wire [7:0] s_tag; wire [0:0] s_set;
  wire busy, engine_idle; wire [30*8-1:0] ev_inc; wire [30*32-1:0] perf_cnt;
  wire acc_st_rd_ready, acc_st_wr_ready, acc_claim_ready, ext_req_ready, ext_rsp_valid, ext_rsp_we, ext_rsp_err; wire [131:0] acc_st_rd_data, ext_rsp_rdata; wire [2:0] ext_rsp_code;
  wire [29:0] acc_slot_state; wire [3:0] acc_viol_sticky;

  sf_tensor_scratchpad #(.ENABLE_DOUBLE_BUFFERING(1), .A_BUFFER_BYTES(A_TOT), .B_BUFFER_BYTES(B_TOT), .TILE_K(32), .DMA_BASE(BASE), .WR_STARVE_LIMIT(2)) dut (
    .clk(clk), .rst_n(rst_n), .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(dma_req_we), .dma_req_addr(dma_req_addr),
    .dma_req_wdata(dma_req_wdata), .dma_req_wstrb(dma_req_wstrb), .dma_req_tag(dma_req_tag), .dma_rsp_valid(dma_rsp_valid), .dma_rsp_ready(1'b1),
    .dma_rsp_rdata(dma_rsp_rdata), .dma_rsp_err(dma_rsp_err), .dma_rsp_err_code(dma_rsp_err_code), .dma_rsp_we(dma_rsp_we), .dma_rsp_tag(dma_rsp_tag),
    .fill_begin_valid(fill_begin_valid), .fill_begin_ready(fill_begin_ready), .fill_end_valid(fill_end_valid), .fill_end_ready(fill_end_ready),
    .cmp_begin_valid(cmp_begin_valid), .cmp_begin_ready(cmp_begin_ready), .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cmp_end_ready),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(set_state),
    .tile_valid(tile_valid), .tile_ready(tile_ready), .tile_a_addr(tile_a_addr), .tile_lda(tile_lda), .tile_b_addr(tile_b_addr), .tile_ldb(tile_ldb),
    .tile_m0(tile_m0), .tile_n0(tile_n0), .tile_k0(tile_k0), .tile_mat_m(tile_mat_m), .tile_mat_n(tile_mat_n), .tile_mat_k(tile_mat_k), .tile_k(tile_k), .tile_tag(tile_tag),
    .tile_rsp_valid(tile_rsp_valid), .tile_rsp_ready(1'b1), .tile_rsp_tag(tile_rsp_tag), .tile_rsp_err(tile_rsp_err), .tile_rsp_code(tile_rsp_code),
    .tile_rsp_m(tile_rsp_m), .tile_rsp_n(tile_rsp_n), .tile_rsp_k(tile_rsp_k),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0), .s_row_mask(s_row_mask), .s_col_mask(s_col_mask),
    .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .acc_st_en(1'b1), .acc_st_rd_req(1'b0), .acc_st_rd_addr('0), .acc_st_rd_ready(acc_st_rd_ready), .acc_st_rd_data(acc_st_rd_data),
    .acc_st_wr_req(1'b0), .acc_st_wr_addr('0), .acc_st_wr_data('0), .acc_st_wr_ready(acc_st_wr_ready),
    .acc_claim_valid(1'b0), .acc_claim_ready(acc_claim_ready), .acc_claim_slot('0), .acc_complete_valid(1'b0), .acc_complete_slot('0),
    .acc_release_valid(1'b0), .acc_release_slot('0), .acc_slot_state(acc_slot_state),
    .ext_req_valid(1'b0), .ext_req_ready(ext_req_ready), .ext_req_we(1'b0), .ext_req_slot('0), .ext_req_row('0), .ext_req_wdata('0),
    .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(1'b1), .ext_rsp_rdata(ext_rsp_rdata), .ext_rsp_we(ext_rsp_we), .ext_rsp_err(ext_rsp_err), .ext_rsp_code(ext_rsp_code),
    .acc_viol_sticky(acc_viol_sticky), .busy(busy), .engine_idle(engine_idle), .ev_inc(ev_inc), .perf_clear(1'b0), .perf_cnt(perf_cnt));

  task automatic chk(input bit cond, input string msg);
    checks++; if (!cond) begin errors++; $display("[%0t] FAIL: %s", $time, msg); end
  endtask

  // ------------------------------------------------------------ DMA response monitor (in order)
  int rq_tag[$], rq_code[$], rq_we[$];
  always @(posedge clk) if (rst_n && dma_rsp_valid) begin rq_tag.push_back(int'(dma_rsp_tag)); rq_code.push_back(dma_rsp_err ? int'(dma_rsp_err_code) : 0); rq_we.push_back(int'(dma_rsp_we)); end
  int sent = 0;
  task automatic dma(input bit we, input longint unsigned addr, input logic [31:0] data, input logic [3:0] strb, output int code);
    int t0; t0 = rq_tag.size();
    @(negedge clk); dma_req_valid = 1; dma_req_we = we; dma_req_addr = 32'(addr); dma_req_wdata = data; dma_req_wstrb = strb; dma_req_tag = 8'(sent);
    @(posedge clk); while (!dma_req_ready) @(posedge clk);
    @(negedge clk); dma_req_valid = 0; sent++;
    while (rq_tag.size() == t0) @(posedge clk);
    code = rq_code[t0];
    chk(rq_tag[t0] == ((sent - 1) & 255), "DMA response tag");
    chk(rq_we[t0] == int'(we), "DMA response we echo");
  endtask
  // one handshake of a command channel (macro instead of a task with ref ports, which Icarus 12 does not support)
  `define PULSE(sig, rdy) begin @(negedge clk); sig = 1; @(posedge clk); while (!(rdy)) @(posedge clk); @(negedge clk); sig = 0; end
  task automatic idle(input int n); repeat (n) @(posedge clk); endtask

  // ------------------------------------------------------------ two matrix pairs (one per set) and the expected-slice monitor
  logic signed [7:0] mA [2][64][64]; logic signed [7:0] mB [2][64][64];
  task automatic randomize_mats(input int seed);
    int x; x = seed * 7919 + 13;
    for (int s = 0; s < 2; s++) for (int i = 0; i < 64; i++) for (int j = 0; j < 64; j++) begin
      x = x * 1103515245 + 12345; mA[s][i][j] = x[23:16]; x = x * 1103515245 + 12345; mB[s][i][j] = x[23:16];
    end
  endtask
  int e_set, e_m0, e_n0, e_k0, e_em, e_en, e_ek, e_tag;
  int nslice = 0, nbad = 0;
  always @(posedge clk) if (rst_n && s_valid && s_ready) begin
    int k; k = int'(s_k);
    nslice++;
    if (nslice > e_ek || k != nslice - 1) nbad++;
    else begin
      for (int i = 0; i < R; i++) if ($signed(s_a[i*8 +: 8]) !== ((i < e_em) ? mA[e_set][e_m0 + i][e_k0 + k] : 8'sd0)) nbad++;
      for (int j = 0; j < C; j++) if ($signed(s_b[j*8 +: 8]) !== ((j < e_en) ? mB[e_set][e_k0 + k][e_n0 + j] : 8'sd0)) nbad++;
      if (int'(s_tag) !== e_tag || int'(s_set) !== e_set) nbad++;
      if (int'(s_kg) !== e_k0 + k) nbad++;               // global reduction index = tile k0 + k
      if (int'(s_m0) !== e_m0 || int'(s_n0) !== e_n0) nbad++;
      if (int'(s_row_mask) !== ((1 << e_em) - 1) || int'(s_col_mask) !== ((1 << e_en) - 1)) nbad++;
      if (s_first !== (k == 0) || s_last !== (k == e_ek - 1)) nbad++;
    end
  end
  task automatic expect_tile(input int set, input int m0, input int n0, input int k0, input int em, input int en, input int ek, input int tag);
    e_set = set; e_m0 = m0; e_n0 = n0; e_k0 = k0; e_em = em; e_en = en; e_ek = ek; e_tag = tag; nslice = 0; nbad = 0;
  endtask

  // ------------------------------------------------------------ tile descriptors
  int trq_code[$], trq_err[$], trq_tag[$];
  always @(posedge clk) if (rst_n && tile_rsp_valid) begin trq_code.push_back(int'(tile_rsp_code)); trq_err.push_back(int'(tile_rsp_err)); trq_tag.push_back(int'(tile_rsp_tag)); end
  task automatic tile(input int a_addr, input longint unsigned lda, input int b_addr, input longint unsigned ldb, input int m0, input int n0, input int k0,
                      input int mm, input int mn, input int mk, input int tk, input int tag, output int code);
    int t0; t0 = trq_code.size();
    @(negedge clk); tile_valid = 1; tile_a_addr = a_addr; tile_lda = 32'(lda); tile_b_addr = b_addr; tile_ldb = 32'(ldb); tile_m0 = m0; tile_n0 = n0; tile_k0 = k0;
    tile_mat_m = mm; tile_mat_n = mn; tile_mat_k = mk; tile_k = tk; tile_tag = tag;
    @(posedge clk); while (!tile_ready) @(posedge clk); @(negedge clk); tile_valid = 0;
    while (trq_code.size() == t0) @(posedge clk);
    code = trq_code[t0];
    chk(trq_err[t0] == ((code != 0) ? 1 : 0), "tile_rsp_err consistent with code");
    chk(trq_tag[t0] == (tag & 255), "tile_rsp tag");
  endtask

  // word writes of a matrix block into a set
  task automatic fill_A(input int set, input int a_addr, input int lda, input int m, input int k);
    int code;
    for (int r = 0; r < m; r++) for (int w = 0; w < (k + 3) / 4; w++) begin
      logic [31:0] d; logic [3:0] st; d = '0; st = '0;
      for (int b = 0; b < 4; b++) if (w * 4 + b < k) begin d[b*8 +: 8] = mA[set][r][w * 4 + b]; st[b] = 1; end
      dma(1, BASE + set * ASET + a_addr + r * lda + w * 4, d, st, code); chk(code == 0, "fill_A write accepted");
    end
  endtask
  task automatic fill_B(input int set, input int b_addr, input int ldb, input int k, input int n);
    int code;
    for (int r = 0; r < k; r++) for (int w = 0; w < (n + 3) / 4; w++) begin
      logic [31:0] d; logic [3:0] st; d = '0; st = '0;
      for (int b = 0; b < 4; b++) if (w * 4 + b < n) begin d[b*8 +: 8] = mB[set][r][w * 4 + b]; st[b] = 1; end
      dma(1, BASE + REGION + set * BSET + b_addr + r * ldb + w * 4, d, st, code); chk(code == 0, "fill_B write accepted");
    end
  endtask
  task automatic wait_idle(input int maxc);
    int n; n = 0; while (!engine_idle && n < maxc) begin @(posedge clk); n++; end
    chk(engine_idle, "engine becomes idle");
  endtask

  int code;
  initial begin
    randomize_mats(3);
    e_ek = 0; e_set = 0;
    rst_n = 0; repeat (5) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);

    // ===================================================== E1: DMA error codes
    $display("E1: DMA error codes");
    chk(set_state == 4'b0000, "reset: both sets FREE");
    dma(1, BASE + 0, 32'h11223344, 4'hF, code);            chk(code == 6, "write to a FREE set -> OWNER");
    dma(0, BASE + 0, 32'h0, 4'hF, code);                   chk(code == 7, "read to a FREE set -> UNSUP (beats OWNER)");
    `PULSE(fill_begin_valid, fill_begin_ready)
    chk(set_state[1:0] == 2'd1 && fill_set == 0, "fill_begin: set 0 FILLING");
    dma(1, BASE + 0, 32'h11223344, 4'hF, code);            chk(code == 0, "write to the FILLING set accepted");
    dma(1, BASE + ASET, 32'h55667788, 4'hF, code);         chk(code == 6, "write to set 1 (FREE) -> OWNER");
    dma(1, BASE - 4, 32'h0, 4'hF, code);                   chk(code == 1, "below DMA_BASE -> RANGE");
    dma(1, BASE + A_TOT, 32'h0, 4'hF, code);               chk(code == 1, "in the hole between A and B -> RANGE");
    dma(1, BASE + REGION - 4, 32'h0, 4'hF, code);          chk(code == 1, "last hole word -> RANGE");
    dma(1, BASE + REGION + B_TOT, 32'h0, 4'hF, code);      chk(code == 1, "first word beyond B -> RANGE");
    dma(1, BASE + 64'h0FFF_FFF0, 32'h0, 4'hF, code);       chk(code == 1, "far beyond the window -> RANGE");
    dma(1, BASE + 1, 32'h0, 4'hF, code);                   chk(code == 2, "misaligned (+1) -> ALIGN");
    dma(1, BASE + 6, 32'h0, 4'hF, code);                   chk(code == 2, "misaligned (+2) -> ALIGN");
    dma(0, BASE + 2, 32'h0, 4'hF, code);                   chk(code == 2, "misaligned read -> ALIGN (beats UNSUP)");
    dma(1, BASE + A_TOT + 1, 32'h0, 4'hF, code);           chk(code == 1, "hole + misaligned -> RANGE (beats ALIGN)");
    dma(0, BASE + 4, 32'h0, 4'hF, code);                   chk(code == 7, "read to the FILLING set -> UNSUP");
    dma(1, BASE + REGION, 32'hAABBCCDD, 4'hF, code);       chk(code == 0, "first B word accepted");
    dma(1, BASE + REGION + BSET - 4, 32'h01020304, 4'hF, code); chk(code == 0, "last word of B set 0 accepted");
    dma(1, BASE + REGION + BSET, 32'h0, 4'hF, code);       chk(code == 6, "first word of B set 1 (FREE) -> OWNER");
    dma(1, BASE + ASET - 4, 32'h0A0B0C0D, 4'hF, code);     chk(code == 0, "last word of A set 0 accepted");
    dma(1, BASE + 8, 32'h0, 4'h0, code);                   chk(code == 0, "write with no byte enables = acknowledged no-op");
    begin   // a burst of mixed legal / illegal requests, one per cycle: responses must come back in request order
      int t0, exp_code[$], exp_tag[$];
      t0 = rq_tag.size();
      for (int i = 0; i < 12; i++) begin
        longint unsigned a; bit w; int e;
        case (i % 4) 0: begin a = BASE + 16 + i * 4; w = 1; e = 0; end 1: begin a = BASE + 1; w = 1; e = 2; end 2: begin a = BASE - 8; w = 1; e = 1; end default: begin a = BASE + 20; w = 0; e = 7; end endcase
        @(negedge clk); dma_req_valid = 1; dma_req_we = w; dma_req_addr = 32'(a); dma_req_wdata = 32'(i); dma_req_wstrb = 4'hF; dma_req_tag = 8'(200 + i);
        @(posedge clk); while (!dma_req_ready) @(posedge clk);
        exp_code.push_back(e); exp_tag.push_back(200 + i);
      end
      @(negedge clk); dma_req_valid = 0;
      while (rq_tag.size() < t0 + 12) @(posedge clk);
      for (int i = 0; i < 12; i++) begin
        chk(rq_tag[t0 + i] == exp_tag[i], "burst: response order = request order");
        chk(rq_code[t0 + i] == exp_code[i], "burst: response code");
      end
    end
    idle(3);
    `PULSE(fill_end_valid, fill_end_ready) chk(set_state[1:0] == 2'd2, "fill_end: set 0 READY");
    dma(1, BASE + 0, 32'hDEADBEEF, 4'hF, code); chk(code == 6, "write to a READY set -> OWNER");
    `PULSE(cmp_begin_valid, cmp_begin_ready)    chk(set_state[1:0] == 2'd3 && cmp_set == 0, "cmp_begin: set 0 IN_USE");
    dma(1, BASE + 0, 32'hDEADBEEF, 4'hF, code); chk(code == 6, "write to an IN_USE set -> OWNER");
    `PULSE(cmp_end_valid, cmp_end_ready)        chk(set_state[1:0] == 2'd0, "cmp_end: set 0 FREE (scratch data never computed on)");

    // ===================================================== E2: tile errors (clean operands in set 1, which the ring hands out next)
    $display("E2: tile descriptor errors");
    tile(0, 16, 0, 8, 0, 0, 0, 4, 4, 8, 8, 1, code);                chk(code == 7, "descriptor with no IN_USE set -> OWNER");
    `PULSE(fill_begin_valid, fill_begin_ready) chk(fill_set == 1 && set_state[3:2] == 2'd1, "ring order: the next fill goes to set 1");
    fill_A(1, 0, 16, 4, 8);  fill_B(1, 0, 8, 8, 4);
    `PULSE(fill_end_valid, fill_end_ready)
    `PULSE(cmp_begin_valid, cmp_begin_ready)   chk(cmp_set == 1 && set_state[3:2] == 2'd3, "ring order: compute takes set 1");
    tile(0, 16, 0, 8, 0, 0, 0, 4, 4, 8, 0, 2, code);                chk(code == 1, "tile_k = 0 -> EMPTY");
    tile(0, 16, 0, 8, 4, 0, 0, 4, 4, 8, 8, 3, code);                chk(code == 1, "m0 >= mat_m -> EMPTY");
    tile(0, 16, 0, 8, 0, 4, 0, 4, 4, 8, 8, 4, code);                chk(code == 1, "n0 >= mat_n -> EMPTY");
    tile(0, 16, 0, 8, 0, 0, 8, 4, 4, 8, 8, 5, code);                chk(code == 1, "k0 >= mat_k -> EMPTY");
    tile(0, 4, 0, 8, 0, 0, 0, 4, 4, 8, 8, 6, code);                 chk(code == 2, "lda < mat_k -> LD");
    tile(0, 16, 0, 2, 0, 0, 0, 4, 4, 8, 8, 7, code);                chk(code == 2, "ldb < mat_n -> LD");
    tile(2, 16, 0, 8, 0, 0, 0, 4, 4, 8, 8, 8, code);                chk(code == 8, "a_addr not word aligned -> ALIGN");
    tile(0, 18, 0, 8, 0, 0, 0, 4, 4, 8, 8, 9, code);                chk(code == 8, "lda not word aligned -> ALIGN");
    tile(0, 16, 1, 8, 0, 0, 0, 4, 4, 8, 8, 10, code);               chk(code == 8, "b_addr not word aligned -> ALIGN");
    tile(0, 16, 0, 5, 0, 0, 0, 4, 4, 8, 8, 11, code);               chk(code == 8, "ldb not word aligned -> ALIGN");
    tile(0, 64, 0, 8, 0, 0, 0, 4, 4, 64, 33, 12, code);             chk(code == 9, "tile_k > TILE_K -> K_RANGE");
    // priorities: EMPTY > LD > ALIGN > K_RANGE > A_OVF > A_RANGE > B_OVF > B_RANGE
    tile(0, 4, 0, 8, 0, 0, 0, 4, 4, 8, 0, 13, code);                chk(code == 1, "EMPTY beats LD");
    tile(2, 4, 0, 8, 0, 0, 0, 4, 4, 8, 8, 14, code);                chk(code == 2, "LD beats ALIGN");
    tile(2, 64, 0, 8, 0, 0, 0, 4, 4, 64, 33, 15, code);             chk(code == 8, "ALIGN beats K_RANGE");
    tile(1020, 1024, 0, 8, 0, 0, 0, 4, 4, 8, 8, 16, code);         chk(code == 4, "A last byte = SET_BYTES+3 -> A_RANGE");
    tile(1020, 1024, 1024, 1024, 0, 0, 0, 4, 4, 8, 8, 17, code);   chk(code == 4, "A_RANGE beats B_RANGE");
    tile(0, 32'h7FFF_FFFC, 0, 8, 0, 0, 0, 4, 4, 8, 8, 18, code);   chk(code == 3, "3 * lda >= 2^32 -> A_OVF");
    tile(0, 32'h7FFF_FFFC, 0, 32'h7FFF_FFFC, 0, 0, 0, 4, 4, 8, 8, 19, code); chk(code == 3, "A_OVF beats B_OVF");
    tile(0, 16, 0, 32'h7FFF_FFFC, 0, 0, 0, 4, 4, 8, 8, 20, code);  chk(code == 5, "7 * ldb >= 2^32 -> B_OVF");
    tile(0, 16, 1024, 1024, 0, 0, 0, 4, 4, 8, 8, 21, code);        chk(code == 6, "B last byte = SET_BYTES+3 -> B_RANGE");
    tile(0, 16, 0, 8, 0, 0, 0, 0, 4, 8, 8, 22, code);              chk(code == 1, "mat_m = 0 -> EMPTY");
    idle(10);
    chk(nslice == 0 && engine_idle, "rejected tiles deliver no slices and leave the engine idle");

    // a good tile after all those errors (the errors had no side effect): partial tile, 3 x 2 of a 4 x 4, k = 5 of 8, with tile offsets
    // m0 = 1, n0 = 2, k0 = 3 : rows 1..3 (3 live rows), cols 2..3 (2 live cols), k 3..7 (5 slices)
    expect_tile(1, 1, 2, 3, 3, 2, 5, 33);
    tile(0, 16, 0, 8, 1, 2, 3, 4, 4, 8, 8, 33, code);              chk(code == 0, "partial tile with offsets accepted");
    wait_idle(200);
    chk(nslice == 5 && nbad == 0, "partial tile delivered 5 correct slices");
    `PULSE(cmp_end_valid, cmp_end_ready) chk(set_state[3:2] == 2'd0, "cmp_end: set 1 FREE");

    // ===================================================== E3: buffer-boundary exactness (set 0)
    $display("E3: buffer boundary exactness");
    // A: rows of pitch 1024 at a_addr 1016: row 3 / byte 7 is byte 4095 = the last byte of an A set.  B: rows of pitch 1024 at b_addr 1020:
    // row 7 / byte 3 is byte 8191 = the last byte of a B set.
    `PULSE(fill_begin_valid, fill_begin_ready) chk(fill_set == 0, "ring: fill set 0");
    fill_A(0, 1016, 1024, 4, 8);  fill_B(0, 1020, 1024, 8, 4);
    `PULSE(fill_end_valid, fill_end_ready)
    `PULSE(cmp_begin_valid, cmp_begin_ready) chk(cmp_set == 0, "ring: compute set 0");
    tile(1020, 1024, 1020, 1024, 0, 0, 0, 4, 4, 8, 8, 40, code);   chk(code == 4, "A last byte 4099 -> A_RANGE");
    tile(1016, 1024, 1024, 1024, 0, 0, 0, 4, 4, 8, 8, 41, code);   chk(code == 6, "B last byte 8195 -> B_RANGE");
    tile(1016, 1028, 1020, 1024, 0, 0, 0, 4, 4, 8, 8, 42, code);   chk(code == 4, "A last byte 4107 via the pitch -> A_RANGE");
    expect_tile(0, 0, 0, 0, 4, 4, 8, 43);
    tile(1016, 1024, 1020, 1024, 0, 0, 0, 4, 4, 8, 8, 43, code);   chk(code == 0, "A and B last bytes = SET_BYTES - 1 accepted");
    wait_idle(200);
    chk(nslice == 8 && nbad == 0, "boundary tile: 8 slices, all operands correct (top of both sets, across banks)");

    // ===================================================== E4: writes into the computing set are refused while slices stream
    $display("E4: no overwrite of operands in use");
    expect_tile(0, 0, 0, 0, 4, 4, 8, 44);
    s_ready = 0;
    tile(1016, 1024, 1020, 1024, 0, 0, 0, 4, 4, 8, 8, 44, code);   chk(code == 0, "same boundary tile again, output back-pressured");
    idle(12);
    for (int i = 0; i < 6; i++) begin
      dma(1, BASE + 1016 + (i % 4) * 1024, 32'hFFFFFFFF, 4'hF, code);       chk(code == 6, "A write into the IN_USE set refused while computing");
      dma(1, BASE + REGION + 1020 + (i % 8) * 1024, 32'hFFFFFFFF, 4'hF, code); chk(code == 6, "B write into the IN_USE set refused while computing");
    end
    chk(!engine_idle, "the engine is still busy (slices held by the back-pressure)");
    @(negedge clk); cmp_end_valid = 1; idle(8); chk(!cmp_end_ready, "cmp_end waits while a tile is in flight"); @(negedge clk); cmp_end_valid = 0;
    @(negedge clk); s_ready = 1;
    wait_idle(200);
    chk(nslice == 8 && nbad == 0, "slices unaffected by the refused writes");
    `PULSE(cmp_end_valid, cmp_end_ready) chk(set_state[1:0] == 2'd0, "cmp_end after the tile drained");

    // ===================================================== E5: gates
    $display("E5: ownership gates");
    `PULSE(fill_begin_valid, fill_begin_ready) chk(fill_set == 1, "ring: fill set 1");
    chk(!fill_begin_ready, "a second fill_begin waits while a set is FILLING");
    chk(!cmp_begin_ready, "cmp_begin waits while no set is READY");
    @(negedge clk); dma_req_valid = 1; dma_req_we = 1; dma_req_addr = 32'(BASE + ASET); dma_req_wdata = 32'h12345678; dma_req_wstrb = 4'hF; dma_req_tag = 8'(sent);
    fill_end_valid = 1; #1; chk(!fill_end_ready, "fill_end waits while a DMA request is being presented");
    @(posedge clk); while (!dma_req_ready) @(posedge clk);
    @(negedge clk); dma_req_valid = 0; sent++;
    @(posedge clk); while (!fill_end_ready) @(posedge clk);
    @(negedge clk); fill_end_valid = 0;
    idle(3); chk(set_state[3:2] == 2'd2, "set 1 READY after the gated fill_end");
    chk(!fill_begin_ready || set_state[1:0] == 2'd0, "set 0 is FREE again, so the ring can fill it");
    `PULSE(cmp_begin_valid, cmp_begin_ready) chk(cmp_set == 1 && set_state[3:2] == 2'd3, "cmp_begin: set 1 IN_USE");
    chk(!cmp_begin_ready, "a second cmp_begin waits while a set is IN_USE");
    `PULSE(cmp_end_valid, cmp_end_ready)

    // E5b: liveness.  A request that decodes to an error is refused without side effect, so a master that keeps presenting refused
    // requests (here: a write to the set that is not FILLING = OWNER, and a write outside the window = RANGE) must not hold fill_end
    // off.  Two rounds (both sets in turn) leave the ring pointer where E6 expects it.
    for (int rr = 0; rr < 4; rr++) begin : e5b
      int t0, fs, last_n, still;
      `PULSE(fill_begin_valid, fill_begin_ready)
      fs = int'(fill_set); t0 = rq_tag.size();
      @(negedge clk); dma_req_valid = 1; dma_req_we = 1; dma_req_wdata = 32'hdeadbeef; dma_req_wstrb = 4'hF; dma_req_tag = 8'(sent);
      dma_req_addr = (rr < 2) ? 32'(BASE + ((fs == 0) ? ASET : 0)) : 32'hF000_0000;            // OWNER, then RANGE
      fill_end_valid = 1; #1; chk(fill_end_ready, "fill_end is not held off by a presented request that decodes to an error");
      @(posedge clk); @(negedge clk); fill_end_valid = 0;
      repeat (3) @(posedge clk);
      @(negedge clk); dma_req_valid = 0;
      still = 0; last_n = -1;
      while (still < 6) begin @(posedge clk); if (rq_tag.size() == last_n) still++; else begin still = 0; last_n = rq_tag.size(); end end
      chk(set_state[fs*2 +: 2] == 2'd2, "fill_end completed while the refused request stayed on the port");
      chk(rq_tag.size() - t0 >= 3, "the refused requests were each answered");
      begin : e5b_codes
        bit all_ok; all_ok = 1;
        for (int q = t0; q < rq_tag.size(); q++) if (rq_code[q] != ((rr < 2) ? 6 : 1)) all_ok = 0;
        chk(all_ok, (rr < 2) ? "every refused write answered OWNER" : "every out-of-window write answered RANGE");
      end
      sent = sent + (rq_tag.size() - t0);
      `PULSE(cmp_begin_valid, cmp_begin_ready)
      `PULSE(cmp_end_valid, cmp_end_ready)
    end

    // ===================================================== E6: ping-pong with different matrices per set
    $display("E6: ping-pong, two different tiles");
    randomize_mats(9);
    `PULSE(fill_begin_valid, fill_begin_ready) chk(fill_set == 0, "fill set 0");
    fill_A(0, 0, 16, 4, 8);  fill_B(0, 0, 8, 8, 4);
    `PULSE(fill_end_valid, fill_end_ready)
    `PULSE(cmp_begin_valid, cmp_begin_ready) chk(cmp_set == 0, "compute set 0");
    s_ready = 0;
    expect_tile(0, 0, 0, 0, 4, 4, 8, 50);
    tile(0, 16, 0, 8, 0, 0, 0, 4, 4, 8, 8, 50, code);              chk(code == 0, "tile on set 0");
    `PULSE(fill_begin_valid, fill_begin_ready) chk(fill_set == 1, "fill of set 1 while set 0 computes");
    dma(1, BASE + 0, 32'h0BADF00D, 4'hF, code);                    chk(code == 6, "ping-pong: write to the computing set refused");
    // set 1 gets its own (different) matrices: copy-modify so aliasing between the sets would be visible
    for (int i = 0; i < 64; i++) for (int j = 0; j < 64; j++) begin mA[1][i][j] = ~mA[0][i][j]; mB[1][i][j] = mB[0][i][j] + 8'sd37; end
    fill_A(1, 0, 16, 4, 8);  fill_B(1, 0, 8, 8, 4);
    chk(!engine_idle, "set 0 still being computed on while set 1 was filled");
    `PULSE(fill_end_valid, fill_end_ready)
    s_ready = 1; wait_idle(200);
    chk(nslice == 8 && nbad == 0, "tile on set 0 unaffected by the concurrent fill of set 1");
    `PULSE(cmp_end_valid, cmp_end_ready)
    `PULSE(cmp_begin_valid, cmp_begin_ready) chk(cmp_set == 1, "compute set 1");
    expect_tile(1, 0, 0, 0, 4, 4, 8, 51);
    tile(0, 16, 0, 8, 0, 0, 0, 4, 4, 8, 8, 51, code);              chk(code == 0, "tile on set 1");
    wait_idle(200);
    chk(nslice == 8 && nbad == 0, "tile on set 1 correct (distinct data: no aliasing between the sets)");
    `PULSE(cmp_end_valid, cmp_end_ready)
    idle(4);
    chk(set_state == 4'b0000, "all sets FREE at the end");
    chk(acc_viol_sticky == 0, "no accumulator-buffer violation flags");

    $display("tb_ts_errors: %0d checks, %0d errors", checks, errors);
    if (errors == 0) $display("TB_RESULT PASS"); else $display("TB_RESULT FAIL errors=%0d", errors);
    $finish;
  end
  initial begin #50_000_000; $display("TB_RESULT FAIL timeout"); $finish; end
endmodule
