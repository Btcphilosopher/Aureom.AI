// =============================================================================
// SilicaFlux TensorScratch :: tb_ts_acc.sv        ACCUMULATOR-BUFFER TESTS (self-checking, no operand buffers involved)
//
//   Part 1  LOCK-STEP EQUIVALENCE with the TENSORCORE 04 reference storage (tensor_acc_storage).  Both storages receive the same
//           traffic, generated the way the real accumulator generates it: one global enable  st_en = ~(write pending & ~st_wr_ready),
//           reads only when st_rd_ready & st_en, a held write until it is accepted, any mix of back-to-back reads and writes.
//           st_rd_data of the scratchpad buffer must equal the reference's rd_data in EVERY cycle (bit exact, RD_LAT 1..3, st_en freezes
//           included).  Concurrently an external reader drains COMPLETE slots (compared with a shadow memory) and releases them, slots are
//           claimed / completed at random, so the external port contends with full-rate accumulator traffic.
//   Part 2  hazards H1..H6 and range checks, directed (see the header of sf_ts_accbuf.sv)
//   Part 3  external-access starvation bound under saturating accumulator traffic (measured maximum is printed and checked)
//   Part 4  external write then accumulator read-back; wide-format widths come from the ACC_W parameter
// =============================================================================
`timescale 1ns/1ps
module tb_ts_acc;
  parameter int RD_LAT = 1, NBA = 4, WQ = 4, ACC_W = 32, EXTLIM = 8, AUTO_REL = 0, NUM_SLOTS = 3, ROWS = 4, COLS = 4, CYCLES = 60000;
  localparam int EW = COLS * (ACC_W + 1), NENT = NUM_SLOTS * ROWS, AW = $clog2(NENT), SLOT_W = $clog2(NUM_SLOTS), RIDW = $clog2(ROWS);
  logic clk = 0, rst_n = 0; always #5 clk = ~clk;
  int errors = 0, checks = 0;
  task automatic chk(input bit c, input string m); checks++; if (!c) begin errors++; if (errors < 25) $display("[%0t] FAIL: %s", $time, m); end endtask

  // ------------------------------------------------------------ signals
  logic st_en = 1, st_rd_req = 0, st_wr_req = 0; logic [AW-1:0] st_rd_addr = 0, st_wr_addr = 0; logic [EW-1:0] st_wr_data = 0;
  wire st_rd_ready, st_wr_ready; wire [EW-1:0] st_rd_data;
  logic claim_valid = 0, complete_valid = 0, release_valid = 0; logic [SLOT_W-1:0] claim_slot = 0, complete_slot = 0, release_slot = 0; wire claim_ready; wire [NUM_SLOTS*2-1:0] slot_state;
  logic ext_req_valid = 0, ext_req_we = 0; logic [SLOT_W-1:0] ext_req_slot = 0; logic [RIDW-1:0] ext_req_row = 0; logic [EW-1:0] ext_req_wdata = 0; wire ext_req_ready;
  wire ext_rsp_valid; logic ext_rsp_ready = 1; wire [EW-1:0] ext_rsp_rdata; wire ext_rsp_we, ext_rsp_err; wire [2:0] ext_rsp_code;
  wire [3:0] viol; wire ev_rd, ev_wr, ev_rd_deny, ev_wr_freeze, ev_fwd, ev_ext_wait, ev_ext_ok, ev_ext_err, ev_viol;

  sf_ts_accbuf #(.ROWS(ROWS), .COLS(COLS), .ACC_W(ACC_W), .NUM_SLOTS(NUM_SLOTS), .NBA(NBA), .RD_LAT(RD_LAT), .WQ_DEPTH(WQ), .EXT_STARVE_LIMIT(EXTLIM), .AUTO_RELEASE(AUTO_REL)) dut (
    .clk(clk), .rst_n(rst_n), .st_en(st_en), .st_rd_req(st_rd_req), .st_rd_addr(st_rd_addr), .st_rd_ready(st_rd_ready), .st_rd_data(st_rd_data),
    .st_wr_req(st_wr_req), .st_wr_addr(st_wr_addr), .st_wr_data(st_wr_data), .st_wr_ready(st_wr_ready),
    .claim_valid(claim_valid), .claim_ready(claim_ready), .claim_slot(claim_slot), .complete_valid(complete_valid), .complete_slot(complete_slot),
    .release_valid(release_valid), .release_slot(release_slot), .slot_state(slot_state),
    .ext_req_valid(ext_req_valid), .ext_req_ready(ext_req_ready), .ext_req_we(ext_req_we), .ext_req_slot(ext_req_slot), .ext_req_row(ext_req_row), .ext_req_wdata(ext_req_wdata),
    .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(ext_rsp_ready), .ext_rsp_rdata(ext_rsp_rdata), .ext_rsp_we(ext_rsp_we), .ext_rsp_err(ext_rsp_err), .ext_rsp_code(ext_rsp_code),
    .viol_sticky_o(viol), .ev_rd(ev_rd), .ev_wr(ev_wr), .ev_rd_deny(ev_rd_deny), .ev_wr_freeze(ev_wr_freeze), .ev_fwd(ev_fwd), .ev_ext_wait(ev_ext_wait), .ev_ext_ok(ev_ext_ok), .ev_ext_err(ev_ext_err), .ev_viol(ev_viol));

  // TENSORCORE 04 reference storage: always ready (no contention injected), driven with the accepted accesses of the DUT
  logic ref_rd_req = 0, ref_wr_req = 0; logic [AW-1:0] ref_rd_addr = 0, ref_wr_addr = 0; logic [EW-1:0] ref_wr_data = 0; wire [EW-1:0] ref_rd_data; wire ref_rd_ready, ref_wr_ready;
  tensor_acc_storage #(.DEPTH(NENT), .WIDTH(EW), .RD_LAT(RD_LAT)) u_ref (
    .clk(clk), .rst_n(rst_n), .en(st_en), .rd_req(ref_rd_req), .rd_addr(ref_rd_addr), .rd_ready(ref_rd_ready), .rd_data(ref_rd_data),
    .wr_req(ref_wr_req), .wr_addr(ref_wr_addr), .wr_data(ref_wr_data), .wr_ready(ref_wr_ready), .rd_block(1'b0), .wr_block(1'b0));

  // ------------------------------------------------------------ PRNG
  logic [63:0] rs = 64'hC0FFEE1234567;
  function automatic int rnd(input int n); rs = rs ^ (rs << 13); rs = rs ^ (rs >> 7); rs = rs ^ (rs << 17); rnd = (n <= 1) ? 0 : int'(rs[40:8] % 64'(n)); endfunction
  function automatic logic [EW-1:0] rnd_entry();
    logic [EW-1:0] v;
    for (int i = 0; i < EW; i += 32) begin
      rs = rs ^ (rs << 13); rs = rs ^ (rs >> 7); rs = rs ^ (rs << 17);
      v[i +: 32] = rs[47:16];
    end
    rnd_entry = v;
  endfunction

  // ------------------------------------------------------------ shadow memory and slot model
  logic [EW-1:0] shadow [NENT]; bit written [NENT];
  int st_of [NUM_SLOTS];      // 0 FREE 1 ACTIVE 2 COMPLETE (the TB's own model, compared with the DUT's slot_state)
  int slot_writes [NUM_SLOTS];

  // pending write register (the accumulator's W stage)
  logic        w_pend = 0; logic [AW-1:0] w_a = 0; logic [EW-1:0] w_d = 0;
  int          cyc = 0, en_cnt = 0;
  int          phase = 1;                 // 1: random driver on, others: directed (the random driver is off)
  int          lockstep = 1;              // strict comparison with the reference storage (only valid while the reference mirrors every access)
  int          p_rd = 70, p_wr = 70;      // probabilities (%) of presenting a read / a new write per cycle
  int          n_rd = 0, n_wr = 0, n_cmp = 0, n_fwd = 0, n_deny = 0, n_frz = 0;

  function automatic int active_slot_pick();
    int n, pick, idx;
    n = 0; for (int s = 0; s < NUM_SLOTS; s++) if (st_of[s] == 1) n++;
    active_slot_pick = -1;
    if (n != 0) begin
      pick = rnd(n); idx = 0;
      for (int s = 0; s < NUM_SLOTS; s++) if (st_of[s] == 1) begin if (idx == pick) active_slot_pick = s; idx++; end
    end
  endfunction

  // ---- driver: values for the coming edge are computed at the falling edge from registered state only
  always @(negedge clk) if (rst_n && phase == 1) begin
    int s, r;
    // the accumulator's global enable: freeze when its write cannot be accepted
    st_en = !(w_pend && !st_wr_ready);
    // write port: hold a pending write; the next one is generated after the previous was accepted
    st_wr_req = w_pend; st_wr_addr = w_a; st_wr_data = w_d;
    // read port: only when ready and enabled, to an entry that was written since its slot was claimed
    st_rd_req = 0;
    if (st_en && st_rd_ready && rnd(100) < p_rd) begin
      s = active_slot_pick();
      if (s >= 0) begin
        int tries; tries = 0;
        while (tries < 6 && !st_rd_req) begin r = s * ROWS + rnd(ROWS); if (written[r]) begin st_rd_req = 1; st_rd_addr = AW'(r); end tries++; end
      end
    end
    if (!st_rd_req) st_rd_addr = AW'(rnd(NENT));          // the address bus carries garbage when no read is issued
    ref_rd_req = st_rd_req;  ref_rd_addr = st_rd_addr;
    // reference sees the write only when the DUT accepts it (and it is legal: the slot is ACTIVE, which the driver guarantees)
    ref_wr_req = w_pend && st_wr_ready;  ref_wr_addr = w_a;  ref_wr_data = w_d;
  end
  // ---- state update at the rising edge
  always @(posedge clk) if (rst_n && phase == 1) begin
    cyc <= cyc + 1;
    if (st_en) en_cnt <= en_cnt + 1;
    if (st_rd_req) n_rd <= n_rd + 1;
    // accepted write
    if (w_pend && st_wr_ready) begin shadow[w_a] = w_d; written[w_a] = 1; n_wr <= n_wr + 1; slot_writes[w_a / ROWS] = slot_writes[w_a / ROWS] + 1; w_pend <= 0; end
    // new write (also back to back with the acceptance of the previous one)
    if ((!w_pend || st_wr_ready) && rnd(100) < p_wr) begin
      int s; s = active_slot_pick();
      if (s >= 0) begin w_pend <= 1; w_a <= AW'(s * ROWS + rnd(ROWS)); w_d <= rnd_entry(); end
    end
    if (ev_fwd) n_fwd <= n_fwd + 1;
    if (ev_rd_deny) n_deny <= n_deny + 1;
    if (ev_wr_freeze) n_frz <= n_frz + 1;
  end

  // ---- lock-step compare: the scratchpad buffer must be indistinguishable from the reference storage
  always @(posedge clk) if (rst_n && phase == 1 && lockstep != 0) begin
    chk(st_rd_data === ref_rd_data, $sformatf("st_rd_data differs from the TENSORCORE 04 reference storage (dut %h, ref %h, cyc %0d)", st_rd_data, ref_rd_data, cyc));
    chk(!(ev_viol), "unexpected violation event during legal traffic");
  end

  // ---- slot lifecycle and external drain (random, runs next to the accumulator traffic)
  int ext_busy = 0;
  int max_ext_wait = 0;
  task automatic ext_read(input int slot, input int row, output bit err, output logic [EW-1:0] data, output int code, output int wait_cycles);
    int t0; t0 = cyc;
    @(negedge clk); ext_req_valid = 1; ext_req_we = 0; ext_req_slot = SLOT_W'(slot); ext_req_row = RIDW'(row);
    @(posedge clk); while (!ext_req_ready) @(posedge clk);
    @(negedge clk); ext_req_valid = 0;
    @(posedge clk); while (!ext_rsp_valid) @(posedge clk);
    err = ext_rsp_err; data = ext_rsp_rdata; code = int'(ext_rsp_code); wait_cycles = cyc - t0;
    chk(ext_rsp_we === 1'b0, "ext read response we = 0");
    @(negedge clk);
  endtask
  task automatic claim(input int s);
    @(negedge clk); claim_valid = 1; claim_slot = SLOT_W'(s); @(posedge clk); while (!claim_ready) @(posedge clk); @(negedge clk); claim_valid = 0;
  endtask
  task automatic complete_pulse(input int s);
    @(negedge clk); complete_valid = 1; complete_slot = SLOT_W'(s); @(posedge clk); @(negedge clk); complete_valid = 0;
  endtask
  task automatic release_pulse(input int s);
    @(negedge clk); release_valid = 1; release_slot = SLOT_W'(s); @(posedge clk); @(negedge clk); release_valid = 0;
  endtask

  task automatic lifecycle();
    int ncomplete; ncomplete = 0;
    while (cyc < CYCLES) begin
      int s;
      s = rnd(NUM_SLOTS);
      if (st_of[s] == 0) begin
        claim(s); st_of[s] = 1; slot_writes[s] = 0;
        for (int r = 0; r < ROWS; r++) written[s * ROWS + r] = 0;
      end else if (st_of[s] == 1 && slot_writes[s] > 6 + rnd(30)) begin
        // the accumulator has no write of this slot in flight (its last write was accepted): completion
        if (!(w_pend && (w_a / ROWS) == s)) begin
          int ok_all; ok_all = 1;
          for (int r = 0; r < ROWS; r++) if (!written[s * ROWS + r]) ok_all = 0;
          if (ok_all) begin
            st_of[s] = 3;                                 // closing: the driver must not touch the slot while the complete pulse is in flight
            complete_pulse(s); n_cmp++;
            st_of[s] = (AUTO_REL != 0) ? 0 : 2;
            if (AUTO_REL == 0) begin
              // external drain of the final tile, concurrently with the accumulator traffic on the other slots
              for (int r = 0; r < ROWS; r++) begin
                bit e; logic [EW-1:0] d; int c, w;
                ext_read(s, r, e, d, c, w);
                chk(!e, "ext read of a COMPLETE slot succeeded");
                chk(d === shadow[s * ROWS + r], $sformatf("ext read data of slot %0d row %0d differs from the shadow (got %h exp %h)", s, r, d, shadow[s * ROWS + r]));
                if (w > max_ext_wait) max_ext_wait = w;
              end
              release_pulse(s); st_of[s] = 0;
            end
          end
        end
      end
      repeat (1 + rnd(4)) @(posedge clk);
    end
  endtask

  // ------------------------------------------------------------ main
  initial begin
    for (int s = 0; s < NUM_SLOTS; s++) begin st_of[s] = 0; slot_writes[s] = 0; end
    for (int i = 0; i < NENT; i++) written[i] = 0;
    rst_n = 0; repeat (6) @(posedge clk); rst_n = 1; repeat (2) @(posedge clk);

    // ===================================================== Part 1: lock-step, three traffic mixes
    $display("Part 1: lock-step vs the TENSORCORE 04 reference storage  (RD_LAT=%0d NBA=%0d WQ=%0d ACC_W=%0d EXTLIM=%0d slots=%0d)", RD_LAT, NBA, WQ, ACC_W, EXTLIM, NUM_SLOTS);
    fork
      lifecycle();
      begin : mixer
        while (cyc < CYCLES) begin
          case ((cyc / 8000) % 4) 0: begin p_rd = 70; p_wr = 70; end 1: begin p_rd = 100; p_wr = 100; end 2: begin p_rd = 30; p_wr = 100; end default: begin p_rd = 100; p_wr = 30; end endcase
          @(posedge clk);
        end
      end
    join
    $display("  %0d cycles, %0d reads (%0d forwarded from the write buffer), %0d writes, %0d completions, read denials %0d, write freezes %0d, max ext latency %0d cycles",
             cyc, n_rd, n_fwd, n_wr, n_cmp, n_deny, n_frz, max_ext_wait);
    lockstep = 0;                                    // the directed parts below do not mirror their accesses into the reference
    chk(n_rd > 1000 && n_wr > 1000 && n_cmp > 20, "enough traffic was generated");
    chk(viol == 0, "no violation flags after legal traffic");

    // ===================================================== Part 2: hazards (directed)
    phase = 2; st_rd_req = 0; st_wr_req = 0; ref_rd_req = 0; ref_wr_req = 0; w_pend = 0; st_en = 1;
    repeat (20) @(posedge clk);
    // bring all slots to FREE
    for (int s = 0; s < NUM_SLOTS; s++) begin
      if (st_of[s] == 1) begin complete_pulse(s); st_of[s] = (AUTO_REL != 0) ? 0 : 2; end
      if (st_of[s] == 2) begin release_pulse(s); st_of[s] = 0; end
    end
    repeat (4) @(posedge clk);
    chk(slot_state == '0, "all slots FREE");
    $display("Part 2: hazards H1..H6");
    begin
      bit e; logic [EW-1:0] d; int c, w; int base;
      // claim slot 1, write one full tile through the accumulator write port, complete it
      claim(1); base = 1 * ROWS;
      for (int r = 0; r < ROWS; r++) begin
        @(negedge clk); st_wr_req = 1; st_wr_addr = AW'(base + r); st_wr_data = rnd_entry(); shadow[base + r] = st_wr_data;
        @(posedge clk); while (!st_wr_ready) @(posedge clk); @(negedge clk); st_wr_req = 0;
      end
      repeat (2 * WQ + 4) @(posedge clk);
      // H2: accumulator read of a slot that is not ACTIVE (slot 0 is FREE): allowed, flagged
      chk(viol[1] == 0, "H2 flag clear before the access");
      @(negedge clk); st_rd_req = 1; st_rd_addr = AW'(0); @(posedge clk); @(negedge clk); st_rd_req = 0; @(posedge clk);
      chk(viol[1] == 1, "H2: accumulator read of a FREE slot flagged");
      // H3: external read of an ACTIVE slot -> OWNER, no side effect; of an out-of-range slot/row -> RANGE
      ext_read(1, 0, e, d, c, w);  chk(e && c == 2, "H3: external read of an ACTIVE slot -> OWNER");
      ext_read(0, 0, e, d, c, w);  chk(e && c == 2, "H3: external read of a FREE slot -> OWNER");
      if (NUM_SLOTS < (1 << SLOT_W)) begin ext_read(NUM_SLOTS, 0, e, d, c, w); chk(e && c == 1, "external read of a slot beyond the buffer -> RANGE"); end
      // complete slot 1, then H1: an accumulator write to the COMPLETE slot must be blocked and must not change the final tile
      complete_pulse(1); st_of[1] = (AUTO_REL != 0) ? 0 : 2;
      if (AUTO_REL == 0) begin
        chk(viol[0] == 0, "H1 flag clear before the access");
        @(negedge clk); st_wr_req = 1; st_wr_addr = AW'(base + 2); st_wr_data = ~shadow[base + 2]; @(posedge clk); while (!st_wr_ready) @(posedge clk); @(negedge clk); st_wr_req = 0;
        repeat (2 * WQ + 4) @(posedge clk);
        chk(viol[0] == 1, "H1: accumulator write to a COMPLETE slot blocked and flagged");
        for (int r = 0; r < ROWS; r++) begin
          ext_read(1, r, e, d, c, w);
          chk(!e && d === shadow[base + r], $sformatf("COMPLETE tile preserved: slot 1 row %0d (got %h exp %h)", r, d, shadow[base + r]));
        end
        // H4: external write to a COMPLETE slot refused, to a FREE slot accepted
        @(negedge clk); ext_req_valid = 1; ext_req_we = 1; ext_req_slot = SLOT_W'(1); ext_req_row = 0; ext_req_wdata = '1; @(posedge clk); while (!ext_req_ready) @(posedge clk);
        @(negedge clk); ext_req_valid = 0; @(posedge clk); while (!ext_rsp_valid) @(posedge clk); chk(ext_rsp_err && ext_rsp_code == 2, "H4: external write to a COMPLETE slot -> OWNER"); @(negedge clk);
        // H6: complete of a COMPLETE slot, release of a FREE slot: flagged, no state change
        chk(viol[2] == 0, "H6 flag clear before the access");
        complete_pulse(1); release_pulse(0);
        chk(viol[2] == 1, "H6: complete of a non-ACTIVE slot / release of a non-COMPLETE slot flagged");
        chk(slot_state[3:2] == 2'd2 && slot_state[1:0] == 2'd0, "H6: states unchanged");
        // the claim of a COMPLETE (not yet released) slot waits
        @(negedge clk); claim_valid = 1; claim_slot = SLOT_W'(1); repeat (4) @(posedge clk); chk(!claim_ready, "claim waits while the slot holds an undrained tile"); @(negedge clk); claim_valid = 0;
        release_pulse(1); st_of[1] = 0;
      end
      // out-of-range accumulator addresses (non-power-of-two entry count): write blocked + flagged
      if (NENT < (1 << AW)) begin
        chk(viol[3] == 0, "range flag clear");
        @(negedge clk); st_wr_req = 1; st_wr_addr = AW'(NENT); st_wr_data = '1; @(posedge clk); while (!st_wr_ready) @(posedge clk); @(negedge clk); st_wr_req = 0; repeat (4) @(posedge clk);
        chk(viol[3] == 1, "accumulator write beyond the buffer blocked and flagged");
      end
    end

    // ===================================================== Part 4 first (needs idle traffic): external write then accumulator read-back
    $display("Part 4: external write, claim, accumulator read-back");
    begin
      bit e; logic [EW-1:0] d; int c, w; logic [EW-1:0] v [ROWS];
      for (int s = 0; s < NUM_SLOTS; s++) if (slot_state[s*2 +: 2] != 2'd0) begin if (slot_state[s*2 +: 2] == 2'd1) complete_pulse(s); release_pulse(s); end
      repeat (4) @(posedge clk);
      if (AUTO_REL == 0 || 1) begin
        for (int r = 0; r < ROWS; r++) begin
          v[r] = rnd_entry();
          @(negedge clk); ext_req_valid = 1; ext_req_we = 1; ext_req_slot = SLOT_W'(NUM_SLOTS - 1); ext_req_row = RIDW'(r); ext_req_wdata = v[r];
          @(posedge clk); while (!ext_req_ready) @(posedge clk); @(negedge clk); ext_req_valid = 0;
          @(posedge clk); while (!ext_rsp_valid) @(posedge clk); chk(!ext_rsp_err && ext_rsp_we, "ext write to a FREE slot accepted"); @(negedge clk);
        end
        claim(NUM_SLOTS - 1);
        for (int r = 0; r < ROWS; r++) begin
          @(negedge clk); st_rd_req = 1; st_rd_addr = AW'((NUM_SLOTS - 1) * ROWS + r); st_en = 1;
          @(posedge clk); @(negedge clk); st_rd_req = 0;
          repeat (RD_LAT) @(posedge clk);
          #1; chk(st_rd_data === v[r], $sformatf("accumulator read-back of an externally written entry (row %0d)", r));
        end
      end
    end

    // ===================================================== Part 3: external access starvation bound under saturating traffic
    $display("Part 3: external starvation bound");
    if (AUTO_REL != 0) $display("  (skipped: AUTO_RELEASE leaves nothing to drain)");
    else begin
      int worst, n_deny0, forced_seen; bit e; logic [EW-1:0] d; int c, w, hs;
      worst = 0;
      phase = 1; p_rd = 100; p_wr = 100;
      // slot 2 (ACTIVE in the DUT since Part 4) becomes the hammer: the accumulator model reads and writes it every cycle, so every bank is busy
      hs = NUM_SLOTS - 1;
      if (slot_state[hs*2 +: 2] == 2'd0) claim(hs);
      st_of[hs] = 1; for (int r = 0; r < ROWS; r++) written[hs * ROWS + r] = 1;
      n_deny0 = n_deny;
      for (int rep = 0; rep < 60; rep++) begin
        int sl; sl = rep % (NUM_SLOTS - 1);
        if (slot_state[sl*2 +: 2] == 2'd0) begin
          claim(sl); st_of[sl] = 1;
          for (int r = 0; r < ROWS; r++) written[sl * ROWS + r] = 0;
          while (!(written[sl*ROWS] && written[sl*ROWS+1] && written[sl*ROWS+2] && written[sl*ROWS+3])) @(posedge clk);
          st_of[sl] = 3;                                 // closing: let the write in flight drain, then complete
          while (w_pend && (w_a / ROWS) == sl) @(posedge clk);
          complete_pulse(sl); st_of[sl] = 2;
          for (int r = 0; r < ROWS; r++) begin
            ext_read(sl, r, e, d, c, w); if (w > worst) worst = w;
            chk(!e && d === shadow[sl * ROWS + r], "saturated drain data");
          end
          release_pulse(sl); st_of[sl] = 0;
        end
      end
      forced_seen = n_deny - n_deny0;
      $display("  worst external read latency under saturating traffic: %0d cycles (bound %0d); forced-in events (read denials): %0d", worst, EXTLIM + WQ + 8, forced_seen);
      chk(worst <= EXTLIM + WQ + 8, "external access completes within the starvation bound");
      chk(worst > 0, "the starvation measurement ran");
      if (NBA == 1) chk(forced_seen > 0 && worst >= EXTLIM, "single bank: the external access really starved and was forced in");
    end

    $display("tb_ts_acc: %0d checks, %0d errors", checks, errors);
    if (errors == 0) $display("TB_RESULT PASS"); else $display("TB_RESULT FAIL errors=%0d", errors);
    $finish;
  end
  initial begin #200_000_000; $display("TB_RESULT FAIL timeout"); $finish; end
endmodule
