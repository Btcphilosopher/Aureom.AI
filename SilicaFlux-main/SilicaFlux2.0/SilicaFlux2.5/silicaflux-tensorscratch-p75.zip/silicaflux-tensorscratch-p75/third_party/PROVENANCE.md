# Provenance of the reused code (`third_party/`)

Byte-identical copies of files from the SilicaFlux archives in `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`, copied from the extracted archives; the copy was **verified file by file against the original** (SHA-256 equal) when this package was built.  `SHA256SUMS` lists every file; `scripts/check_third_party.sh` re-checks the copies.  Only the files this project compiles are included.

| file | source archive | SHA-256 |
|---|---|---|
| `third_party/memorycore/rtl/sf_ecc_counters.sv` | `silicaflux-memorycore-sram.zip` | `07de0b6c472b9ad1…` |
| `third_party/memorycore/rtl/sf_ecc_dec.sv` | `silicaflux-memorycore-sram.zip` | `50421b82eb5b4ae9…` |
| `third_party/memorycore/rtl/sf_ecc_enc.sv` | `silicaflux-memorycore-sram.zip` | `7cd6a8e3b7c8b180…` |
| `third_party/memorycore/rtl/sf_sram_bank.sv` | `silicaflux-memorycore-sram.zip` | `3c26e2e21ffdaba9…` |
| `third_party/memorycore/rtl/sf_sram_core.sv` | `silicaflux-memorycore-sram.zip` | `69e07e344f8612e3…` |
| `third_party/memorycore/rtl/sf_sram_defs.svh` | `silicaflux-memorycore-sram.zip` | `a89cb8824f394ee5…` |
| `third_party/memorycore/rtl/sf_sram_macro_wrapper.sv` | `silicaflux-memorycore-sram.zip` | `0e76b94249eec647…` |
| `third_party/memorycore/rtl/sf_sync_fifo.sv` | `silicaflux-memorycore-sram.zip` | `c4760dfb1e41811a…` |
| `third_party/memorycore/rtl/backends/sf_sram_asic_sky130.sv` | `silicaflux-memorycore-sram.zip` | `25419e9ad3771358…` |
| `third_party/memorycore/rtl/backends/sf_sram_fpga_bram.sv` | `silicaflux-memorycore-sram.zip` | `ee5d91ed07e9bcae…` |
| `third_party/memorycore/ras_secded/sfras_defs.svh` | `silicaflux-memorycore-sram.zip (third_party/ras_secded)` | `af06beb45166e3f7…` |
| `third_party/memorycore/ras_secded/sfras_ecc_funcs.svh` | `silicaflux-memorycore-sram.zip (third_party/ras_secded)` | `b34b9d923e5f6422…` |
| `third_party/memorycore/ras_secded/sfras_secded_dec.sv` | `silicaflux-memorycore-sram.zip (third_party/ras_secded)` | `571840dcb0f9c494…` |
| `third_party/memorycore/ras_secded/sfras_secded_enc.sv` | `silicaflux-memorycore-sram.zip (third_party/ras_secded)` | `19cae462eb4c9b7f…` |
| `third_party/tensorcore02/rtl/tensor_output_collect.sv` | `silicaflux-tensorcore02.zip` | `ae2bf95f200152b8…` |
| `third_party/tensorcore02/rtl/tensor_pe.sv` | `silicaflux-tensorcore02.zip` | `f931027f5c65b87b…` |
| `third_party/tensorcore02/rtl/tensor_skew.sv` | `silicaflux-tensorcore02.zip` | `a69f279fa282f22e…` |
| `third_party/tensorcore02/rtl/tensor_systolic_array.sv` | `silicaflux-tensorcore02.zip` | `07be2f4be73cb018…` |
| `third_party/tensorcore04/rtl/tensor_acc_fifo.sv` | `silicaflux-tensorcore04.zip` | `063393ee2000a3d5…` |
| `third_party/tensorcore04/rtl/tensor_acc_out_router.sv` | `silicaflux-tensorcore04.zip` | `12c387c028ef6c69…` |
| `third_party/tensorcore04/rtl/tensor_acc_pkg.sv` | `silicaflux-tensorcore04.zip` | `839c395a324a1e04…` |
| `third_party/tensorcore04/rtl/tensor_acc_storage.sv` | `silicaflux-tensorcore04.zip` | `e0927b856835f207…` |
| `third_party/tensorcore04/rtl/tensor_acc_subsystem.sv` | `silicaflux-tensorcore04.zip` | `6dadcd3e2d4bd14b…` |
| `third_party/tensorcore04/rtl/tensor_accumulator.sv` | `silicaflux-tensorcore04.zip` | `bb1cce9bee4eed62…` |

Not copied (not needed): the SFB3 NoC, MBIST controller, vector / sub-word scratchpads, the existing 128-bit-line `sf_tensor_scratchpad.sv` / `sf_ts_port.sv` (see `docs/KNOWN_LIMITATIONS.md` L1), `sf_sram_controller.sv`, TENSORCORE 03 / 06 / 07 and Module 07.
