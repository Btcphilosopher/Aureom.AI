// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_abuf_ctrl     (A-BUFFER CONTROLLER)
// A operand storage + read side.  The array needs ARRAY_ROWS bytes of A per slice: A[m0+i][k0+k], i = 0..R-1, i.e. one
// element from each of R different matrix rows, which sit lda bytes apart in the buffer.
//
//   * One read stream per array row ("lane"): lane i fetches the words that cover its row segment, words
//         base_i + j,   base_i = wA0 + i*SA,   j = 0..NWA-1       (SA = lda / WORD_BYTES words per matrix row)
//     So one 32-bit bank read feeds a lane for WORD_BYTES/ELEM_BYTES consecutive slices (4 for INT8 / 4-byte words): the
//     R lanes together need R reads per 4 slices, i.e. an average of one bank read per cycle for R = 4.  That is how
//     4 A operands per cycle are sustained from single-port banks without any multi-port assumption.
//   * Which banks the R lanes hit depends on SA mod NUM_A_BANKS (word interleaving).  A bad SA (e.g. every lane in one
//     bank) is NOT a functional problem: the per-bank arbiter serialises the lanes, the staging FIFOs absorb it, and the
//     cost shows up as A_RD_STALL / A_BANK_CONF events and, when the FIFOs run dry, as compute starvation.
//   * All lanes share one byte offset (lda is a multiple of WORD_BYTES), so they cross word boundaries together.
//
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_ts_abuf_ctrl #(
  parameter int R            = 4,
  parameter int WB           = 4,
  parameter int NB           = 4,
  parameter int NSETS        = 1,
  parameter int SPLIT        = 0,
  parameter int SET_WORDS    = 1024,
  parameter int READ_LATENCY = 1,
  parameter int STAGE        = 2,
  parameter int CW           = 6,
  parameter int BACKEND      = `SF_BACKEND_BEHAV,
  parameter int SIM_INIT     = 2,
  parameter int STARVE_LIMIT = 8,
  parameter int CHAIN        = 1,
  // ---- derived
  parameter int DW           = 8 * WB,
  parameter int AWW          = $clog2(SET_WORDS),
  parameter int SETW         = (NSETS > 1) ? $clog2(NSETS) : 1,
  parameter int RMW          = $clog2(R + 1),
  parameter int BE_W         = WB
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // tile load (all lanes at once, only when every lane has issued its previous words)
  input  wire logic                ld_valid,
  output logic                     ld_ready,
  input  wire logic [SETW-1:0]     ld_set,
  input  wire logic [AWW-1:0]      ld_base,       // word index of the first word of lane 0
  input  wire logic [AWW-1:0]      ld_sa,         // lane stride in words (matrix row pitch / WORD_BYTES)
  input  wire logic [CW-1:0]       ld_nwords,     // words per live lane
  input  wire logic [RMW-1:0]      ld_eff_m,      // live lanes
  // staged words
  output logic      [R-1:0]        head_valid,
  output logic      [R*DW-1:0]     head_data,
  input  wire logic [R-1:0]        pop,
  // DMA write port (A window of one set)
  input  wire logic                wr_valid,
  input  wire logic [SETW-1:0]     wr_set,
  input  wire logic [AWW-1:0]      wr_addr,
  input  wire logic [DW-1:0]       wr_data,
  input  wire logic [BE_W-1:0]     wr_be,
  output logic                     wr_gnt,
  // events
  output logic [7:0]               ev_rd_words,
  output logic [7:0]               ev_rd_stall,
  output logic [7:0]               ev_conflict,
  output logic [7:0]               ev_rd_wr_block,
  output logic                     ev_wr_stall,
  output logic                     ev_wr_forced
);
  logic [SETW-1:0]   set_q;
  logic [R-1:0]      s_idle, s_req, s_gnt, s_rp_v, s_blocked;
  logic [R*AWW-1:0]  s_addr;
  logic [R*DW-1:0]   s_rp_d;
  assign ld_ready = &s_idle;
  wire   do_ld    = ld_valid & ld_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) set_q <= '0;
    else if (do_ld) set_q <= ld_set;
  end

  for (genvar i = 0; i < R; i++) begin : g_lane
    wire [AWW-1:0] base_i = ld_base + AWW'(i) * ld_sa;
    wire [CW-1:0]  cnt_i  = (i < 32'(ld_eff_m)) ? ld_nwords : '0;
    sf_ts_stream #(.AWW(AWW), .CW(CW), .DW(DW), .DEPTH(STAGE), .CHAIN(CHAIN)) u_s (
      .clk(clk), .rst_n(rst_n), .load_i(do_ld), .load_base_i(base_i), .load_stride_i(AWW'(1)), .load_cnt_i(cnt_i),
      .idle_o(s_idle[i]), .req_valid_o(s_req[i]), .req_addr_o(s_addr[i*AWW +: AWW]), .gnt_i(s_gnt[i]),
      .rsp_valid_i(s_rp_v[i]), .rsp_data_i(s_rp_d[i*DW +: DW]),
      .head_valid_o(head_valid[i]), .head_data_o(head_data[i*DW +: DW]), .pop_i(pop[i]), .req_blocked_o(s_blocked[i]));
  end

  sf_ts_bankgrp #(.NS(R), .NB(NB), .NSETS(NSETS), .SPLIT(SPLIT), .SET_WORDS(SET_WORDS), .DW(DW),
                  .READ_LATENCY(READ_LATENCY), .BACKEND(BACKEND), .SIM_INIT(SIM_INIT), .STARVE_LIMIT(STARVE_LIMIT)) u_grp (
    .clk(clk), .rst_n(rst_n), .rq_valid(s_req), .rq_set(set_q), .rq_addr(s_addr), .rq_gnt(s_gnt), .rp_valid(s_rp_v),
    .rp_data(s_rp_d), .wr_valid(wr_valid), .wr_set(wr_set), .wr_addr(wr_addr), .wr_data(wr_data), .wr_be(wr_be),
    .wr_gnt(wr_gnt), .ev_rd_words(ev_rd_words), .ev_conflict(ev_conflict), .ev_rd_wr_block(ev_rd_wr_block),
    .ev_wr_stall(ev_wr_stall), .ev_wr_forced(ev_wr_forced));

  always_comb begin
    ev_rd_stall = 8'd0;
    for (int i = 0; i < R; i++) ev_rd_stall = ev_rd_stall + 8'(s_blocked[i]);
  end
endmodule

`default_nettype wire
