// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_accbuf     (ACCUMULATOR BUFFER = ACCUMULATOR STORAGE INTERFACE + SLOT OWNERSHIP)
//
// ---------------------------------------------------------------- what it is, and what it deliberately is NOT
//   TENSORCORE 04 (tensor_accumulator) already adds every K chunk to the stored partial sum EXACTLY ONCE (per-row chunk sequence
//   numbers; replays dropped, skipped chunks rejected) and defines the accumulator STORAGE INTERFACE.  The TENSORCORE 02 PEs clear their
//   accumulators on every launch, so a K-chunk partial sum can only be continued from storage by that engine.  This module is the BACKING
//   STORE for that interface - NOT a second adder: adding here as well would duplicate accumulation (or add a partial sum twice).  There is
//   no arithmetic in this file.
//
// ---------------------------------------------------------------- storage (accumulator side, TC04 contract)
//   entry = slot*ROWS + row, width EW = COLS*(ACC_WIDTH+1) (per lane {sticky overflow, value}).  ACC_WIDTH is the lane width of the persistent
//   accumulator: 32 (INT32), or 40 / 48 for the optional wider format - the entry simply grows.
//   The logical "one read + one write per cycle, any addresses" is realised on single-port (1RW) banks by a WRITE BUFFER:
//     * the accumulator's write is accepted into a small FIFO (WQ_DEPTH entries); st_wr_ready = "FIFO not full" (registered state only);
//     * the FIFO head is written to its bank in any cycle in which that bank is not used by a read (reads have priority, drain order is
//       strict FIFO, so writes to one entry commit in order);
//     * a read whose address matches a buffered write is served FROM the buffer (newest match) and does not touch a bank, so "a write accepted in
//       cycle w is visible to every read requested in w+1 or later" holds exactly as in the reference storage; a read in the SAME cycle as the
//       write sees the old value (read-before-write);
//     * st_rd_ready is registered state only too (low for one cycle when a starved external access is forced in).
//   Why not a bank-conflict based ready: tensor_accumulator derives st_rd_addr combinationally from the issue stage that st_rd_ready gates
//   (issue_ok = pipe_en & st_rd_ready); an address-dependent st_rd_ready closes a combinational loop (found with Verilator UNOPTFLAT while
//   integrating with the real accumulator, docs/KNOWN_LIMITATIONS.md).
//   st_rd_data is held while st_en = 0, and for RD_LAT > 1 the extra stages advance only on st_en, like the reference tensor_acc_storage; the
//   data is captured on its response cycle (not left in a bank's output register), so an external access to the same bank cannot disturb it.
//   Throughput: full rate when consecutive pipeline accesses fall in different banks (the write drained in a cycle is RD_LAT+1 entries older than
//   the read, so NUM_ACC_BANKS > RD_LAT+1 is conflict free); otherwise the FIFO fills and st_wr_ready drops (counted as ACC_WR_FRZ).
//
// ---------------------------------------------------------------- ownership of the slots (output tile storage)
//       FREE --claim--> ACTIVE --complete--> COMPLETE --release--> FREE          (complete goes straight to FREE if AUTO_RELEASE)
//   claim    : the sequencer reserves slot s before it opens it in the accumulator (cfg_slot); waits while s is not FREE.
//   complete : wire the accumulator's cmt_done / cmt_slot here.
//   release  : the external reader gives the slot back after draining it.
//   Hazards defined and enforced:
//     H1 accumulator write to a slot that is not ACTIVE         -> BLOCKED (no write), counted, sticky flag   (protects a COMPLETE tile that
//                                                                   has not been drained yet, and a FREE slot nobody claimed)
//     H2 accumulator read of a slot that is not ACTIVE          -> allowed (harmless), counted, sticky flag
//     H3 external read  : legal only on a COMPLETE slot (final tile; stable)       -> else OWNER error, no side effect
//     H4 external write : legal only on a FREE slot (initialisation / test) and only once no buffered write to that entry is pending; the
//        accumulator's own valid tracking never reads a value it has not written for the open tile, so an external write is NOT an
//        accumulator preload (use tensor_accumulator hc_write for that)
//     H5 claim waits while an external write to that slot is pending
//     H6 complete of a non-ACTIVE slot, release of a non-COMPLETE slot -> counted, sticky flag, no state change
//   An external access is single-outstanding and has the lowest priority (accumulator read > buffer drain > external).  It is guaranteed to
//   complete: after EXT_STARVE_LIMIT cycles of waiting it forces itself in (reads are denied for that one cycle, the drain yields the bank).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_ts_defs.svh"
`default_nettype none

module sf_ts_accbuf #(
  parameter int ROWS            = 4,
  parameter int COLS            = 4,
  parameter int ACC_W           = 32,
  parameter int NUM_SLOTS       = 2,
  parameter int NBA             = 4,         // banks (power of two)
  parameter int RD_LAT          = 1,         // accumulator storage read latency, 1..3 (must equal tensor_accumulator RD_LAT)
  parameter int WQ_DEPTH        = 4,         // write buffer entries (>= 2)
  parameter int EXT_STARVE_LIMIT = 8,
  parameter int AUTO_RELEASE    = 0,
  parameter int BACKEND         = `SF_BACKEND_BEHAV,
  parameter int SIM_INIT        = 2,
  // ---- derived
  parameter int EW              = COLS * (ACC_W + 1),
  parameter int DWA             = ((EW + 7) / 8) * 8,
  parameter int NENT            = NUM_SLOTS * ROWS,
  parameter int AW              = (NENT > 1) ? $clog2(NENT) : 1,
  parameter int SLOT_W          = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1,
  parameter int RIDW            = (ROWS > 1) ? $clog2(ROWS) : 1,
  parameter int ROWS_BANK       = (NENT + NBA - 1) / NBA,
  parameter int DEPTH           = (ROWS_BANK < 2) ? 2 : ROWS_BANK,
  parameter int RW              = $clog2(DEPTH),
  parameter int ECW             = $clog2(EXT_STARVE_LIMIT + 2),
  parameter int QW              = $clog2(WQ_DEPTH),
  parameter int QCW             = $clog2(WQ_DEPTH + 1)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // ---------------------------------------------------------- accumulator storage interface (tensor_accumulator st_*)
  input  wire logic                st_en,
  input  wire logic                st_rd_req,
  input  wire logic [AW-1:0]       st_rd_addr,
  output logic                     st_rd_ready,
  output logic      [EW-1:0]       st_rd_data,
  input  wire logic                st_wr_req,
  input  wire logic [AW-1:0]       st_wr_addr,
  input  wire logic [EW-1:0]       st_wr_data,
  output logic                     st_wr_ready,
  // ---------------------------------------------------------- slot ownership
  input  wire logic                claim_valid,
  output logic                     claim_ready,
  input  wire logic [SLOT_W-1:0]   claim_slot,
  input  wire logic                complete_valid,
  input  wire logic [SLOT_W-1:0]   complete_slot,
  input  wire logic                release_valid,
  input  wire logic [SLOT_W-1:0]   release_slot,
  output logic      [NUM_SLOTS*2-1:0] slot_state,
  // ---------------------------------------------------------- external (DMA / host) port, one entry (one tile row) per access
  input  wire logic                ext_req_valid,
  output logic                     ext_req_ready,
  input  wire logic                ext_req_we,
  input  wire logic [SLOT_W-1:0]   ext_req_slot,
  input  wire logic [RIDW-1:0]     ext_req_row,
  input  wire logic [EW-1:0]       ext_req_wdata,
  output logic                     ext_rsp_valid,
  input  wire logic                ext_rsp_ready,
  output logic      [EW-1:0]       ext_rsp_rdata,
  output logic                     ext_rsp_we,
  output logic                     ext_rsp_err,
  output logic      [2:0]          ext_rsp_code,
  // ---------------------------------------------------------- status / events
  output logic      [3:0]          viol_sticky_o,   // [0] H1  [1] H2  [2] H6  [3] address out of range
  output logic                     ev_rd, ev_wr, ev_rd_deny, ev_wr_freeze, ev_fwd, ev_ext_wait, ev_ext_ok, ev_ext_err, ev_viol
);
  if (NBA < 1 || (NBA & (NBA - 1)) != 0) begin : g_err_nba
    `SF_CFG_FATAL("sf_ts_accbuf: NUM_ACC_BANKS must be a power of two")
  end
  if (RD_LAT < 1 || RD_LAT > 3) begin : g_err_lat
    `SF_CFG_FATAL("sf_ts_accbuf: RD_LAT must be 1..3 (tensor_accumulator contract)")
  end
  if (NUM_SLOTS < 1 || ROWS < 1 || COLS < 1 || WQ_DEPTH < 2) begin : g_err_dim
    `SF_CFG_FATAL("sf_ts_accbuf: NUM_SLOTS, ROWS, COLS >= 1 and WQ_DEPTH >= 2 required")
  end

  function automatic int sidx(input logic [SLOT_W-1:0] s);   // clamp: never index ss_q out of range
    sidx = (32'(s) < NUM_SLOTS) ? 32'(s) : 0;
  endfunction

  // ------------------------------------------------------------ slot state
  // slot states as one packed vector: a per-slot array reset in a loop makes Verilator 5.020 reject more than 64 slots (BLKLOOPINIT)
  logic [NUM_SLOTS*2-1:0] ss_q;
  assign slot_state = ss_q;

  // ------------------------------------------------------------ write buffer (registered state)
  logic [AW-1:0]  wq_a [WQ_DEPTH];
  logic [EW-1:0]  wq_d [WQ_DEPTH];
  logic [QW-1:0]  wq_hd;
  logic [QCW-1:0] wq_n;
  wire            wq_full  = (wq_n == QCW'(WQ_DEPTH));
  wire            wq_empty = (wq_n == '0);

  // ------------------------------------------------------------ external port state
  localparam logic [1:0] E_IDLE = 2'd0, E_PEND = 2'd1, E_WAITRD = 2'd2, E_RSP = 2'd3;
  logic [1:0]        e_state;
  logic              e_we;
  logic [AW-1:0]     e_addr;
  logic [SLOT_W-1:0] e_slot;
  logic [DWA-1:0]    e_wdata;
  logic [ECW-1:0]    e_wait;
  wire               e_force = (e_state == E_PEND) && (e_wait >= ECW'(EXT_STARVE_LIMIT));

  // ------------------------------------------------------------ accumulator request decode
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] w_slot, r_slot, r_bank, r_row, d_bank, d_row, e_bank, e_row;     // 32-bit arithmetic temporaries, truncated on use
  /* verilator lint_on UNUSEDSIGNAL */
  logic        w_inrange, r_inrange, w_legal, r_legal;
  always_comb begin
    w_slot = 32'(st_wr_addr) / ROWS;  r_slot = 32'(st_rd_addr) / ROWS;
    r_bank = 32'(st_rd_addr) % NBA;   r_row  = 32'(st_rd_addr) / NBA;
    w_inrange = (32'(st_wr_addr) < NENT);  r_inrange = (32'(st_rd_addr) < NENT);
    w_legal = w_inrange && (ss_q[((w_slot < NUM_SLOTS) ? 32'(w_slot) : 0)*2 +: 2] == `TS_SLOT_ACTIVE);
    r_legal = r_inrange && (ss_q[((r_slot < NUM_SLOTS) ? 32'(r_slot) : 0)*2 +: 2] == `TS_SLOT_ACTIVE);
    d_bank = 32'(wq_a[wq_hd]) % NBA;  d_row = 32'(wq_a[wq_hd]) / NBA;
    e_bank = 32'(e_addr) % NBA;       e_row = 32'(e_addr) / NBA;
  end

  // ready signals: registered state ONLY (no dependence on any address or request of this cycle)
  assign st_wr_ready = ~wq_full;
  assign st_rd_ready = ~e_force;
  wire   wr_acc  = st_wr_req & st_wr_ready;
  wire   wr_push = wr_acc & w_legal;                                 // accepted into the buffer (H1 blocks the rest)
  wire   rd_acc  = st_rd_req & st_rd_ready & st_en;

  // ------------------------------------------------------------ buffer lookup (existing entries only: a same-cycle push is not visible)
  logic            hit_r, hit_e, any_e;
  logic [EW-1:0]   hit_r_d, hit_e_d;
  always_comb begin
    hit_r = 1'b0; hit_r_d = '0; hit_e = 1'b0; hit_e_d = '0; any_e = 1'b0;
    for (int a = 0; a < WQ_DEPTH; a++) begin                         // a = age: 0 oldest ... newest last, so the newest match wins
      if (a < 32'(wq_n)) begin
        if (wq_a[(32'(wq_hd) + a) % WQ_DEPTH] == st_rd_addr) begin hit_r = 1'b1; hit_r_d = wq_d[(32'(wq_hd) + a) % WQ_DEPTH]; end
        if (wq_a[(32'(wq_hd) + a) % WQ_DEPTH] == e_addr)     begin hit_e = 1'b1; hit_e_d = wq_d[(32'(wq_hd) + a) % WQ_DEPTH]; any_e = 1'b1; end
      end
    end
  end

  // ------------------------------------------------------------ bank allocation for this cycle: acc read > drain > external (forced: external > drain)
  wire rd_bank_use = rd_acc & ~hit_r;                                // the read really needs its bank
  wire e_rd_fwd    = (e_state == E_PEND) & ~e_we & hit_e;            // external read served from the buffer: needs no bank
  wire e_needs     = (e_state == E_PEND) & ~e_rd_fwd;
  wire e_can       = e_needs & ~(e_we & any_e);                      // an external write waits for a buffered write to the same entry
  wire dr_v        = ~wq_empty;
  wire drain_go    = dr_v & ~(rd_bank_use & (r_bank == d_bank)) & ~(e_force & e_can & (e_bank == d_bank));
  wire e_issue     = e_can & (e_force | (~(rd_bank_use & (r_bank == e_bank)) & ~(drain_go & (d_bank == e_bank))));

  // ------------------------------------------------------------ banks
  logic [NBA-1:0]  bk_valid, bk_we;
  logic [RW-1:0]   bk_row   [NBA];
  logic [DWA-1:0]  bk_wdata [NBA];
  logic [NBA-1:0]  bk_tag;
  logic [NBA-1:0]  br_valid, br_we, br_tag;
  logic [DWA-1:0]  br_data  [NBA];
  logic [NBA-1:0]  bk_ready;
  always_comb begin
    for (int p = 0; p < NBA; p++) begin
      bk_valid[p] = 1'b0; bk_we[p] = 1'b0; bk_row[p] = '0; bk_wdata[p] = '0; bk_tag[p] = 1'b0;
      if (rd_bank_use && r_bank == 32'(p)) begin
        bk_valid[p] = 1'b1; bk_row[p] = RW'(r_row); bk_tag[p] = 1'b0;
      end else if (drain_go && d_bank == 32'(p)) begin
        bk_valid[p] = 1'b1; bk_we[p] = 1'b1; bk_row[p] = RW'(d_row); bk_wdata[p] = DWA'(wq_d[wq_hd]); bk_tag[p] = 1'b0;
      end else if (e_issue && e_bank == 32'(p)) begin
        bk_valid[p] = 1'b1; bk_we[p] = e_we; bk_row[p] = RW'(e_row); bk_wdata[p] = e_wdata; bk_tag[p] = 1'b1;
      end
    end
  end
  for (genvar p = 0; p < NBA; p++) begin : g_bank
    logic [DWA-1:0] d;
    logic [0:0]     t;
    sf_ts_bank #(.DEPTH(DEPTH), .DW(DWA), .TAG_W(1), .READ_LATENCY(1), .BACKEND(BACKEND), .SIM_INIT(SIM_INIT)) u_bank (
      .clk(clk), .rst_n(rst_n), .req_valid(bk_valid[p]), .req_we(bk_we[p]), .req_row(bk_row[p]), .req_wdata(bk_wdata[p]),
      .req_be({(DWA/8){1'b1}}), .req_tag(bk_tag[p]), .req_ready(bk_ready[p]), .rsp_valid(br_valid[p]), .rsp_rdata(d),
      .rsp_tag(t), .rsp_we(br_we[p]));
    assign br_data[p] = d;
    assign br_tag[p]  = t[0];
  end

  // ------------------------------------------------------------ write buffer update
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wq_hd <= '0; wq_n <= '0;
    end else begin
      if (wr_push) begin
        wq_a[(32'(wq_hd) + 32'(wq_n)) % WQ_DEPTH] <= st_wr_addr;
        wq_d[(32'(wq_hd) + 32'(wq_n)) % WQ_DEPTH] <= st_wr_data;
      end
      if (drain_go) wq_hd <= (wq_hd == QW'(WQ_DEPTH - 1)) ? '0 : wq_hd + 1'b1;
      wq_n <= wq_n + QCW'(wr_push) - QCW'(drain_go);
    end
  end

  // ------------------------------------------------------------ accumulator read path (TC04 contract)
  logic [DWA-1:0] live_acc, live_ext;
  logic           resp_acc, resp_ext;
  always_comb begin
    live_acc = '0; live_ext = '0; resp_acc = 1'b0; resp_ext = 1'b0;
    for (int p = 0; p < NBA; p++) begin
      if (br_valid[p] && !br_we[p] && !br_tag[p]) begin live_acc = live_acc | br_data[p]; resp_acc = 1'b1; end
      if (br_valid[p] && !br_we[p] &&  br_tag[p]) begin live_ext = live_ext | br_data[p]; resp_ext = 1'b1; end
    end
  end
  logic          byp_v_q;                          // the read of the previous cycle was served from the write buffer
  logic [EW-1:0] byp_d_q, held_q;
  wire  [EW-1:0] s0 = byp_v_q ? byp_d_q : (resp_acc ? live_acc[EW-1:0] : held_q);   // stage 0: data of the last accepted read
  logic [EW-1:0] rp [1:2];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin held_q <= '0; rp[1] <= '0; rp[2] <= '0; byp_v_q <= 1'b0; byp_d_q <= '0; end
    else begin
      byp_v_q <= rd_acc & hit_r;
      if (rd_acc & hit_r) byp_d_q <= hit_r_d;
      held_q <= s0;
      if (st_en) begin rp[1] <= s0; rp[2] <= rp[1]; end
    end
  end
  assign st_rd_data = (RD_LAT == 1) ? s0 : (RD_LAT == 2) ? rp[1] : rp[2];

  // ------------------------------------------------------------ slot ownership + violations
  logic [3:0] viol_q;
  logic       v_h1, v_h2, v_h6;
  wire        claim_in_range   = (32'(claim_slot) < NUM_SLOTS);
  // H5: an external write to the slot is pending, or is being accepted in this very cycle
  wire        claim_blocked_by_ext = ((e_state != E_IDLE) && e_we && (e_slot == claim_slot)) ||
                                     (ext_req_valid && (e_state == E_IDLE) && ext_req_we && (ext_req_slot == claim_slot));
  assign claim_ready = claim_in_range && (ss_q[sidx(claim_slot)*2 +: 2] == `TS_SLOT_FREE) && !claim_blocked_by_ext;
  wire do_claim    = claim_valid && claim_ready;
  wire cpl_ok      = complete_valid && (32'(complete_slot) < NUM_SLOTS) && (ss_q[sidx(complete_slot)*2 +: 2] == `TS_SLOT_ACTIVE);
  wire rel_ok      = release_valid  && (32'(release_slot)  < NUM_SLOTS) && (ss_q[sidx(release_slot)*2 +: 2]  == `TS_SLOT_COMPLETE);
  always_comb begin
    v_h1 = wr_acc & ~w_legal;
    v_h2 = rd_acc & ~r_legal;
    v_h6 = (complete_valid & ~cpl_ok) | (release_valid & ~rel_ok);
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ss_q <= '0;                                   // every slot FREE (TS_SLOT_FREE = 2'd0)
      viol_q <= '0;
    end else begin
      if (do_claim) ss_q[sidx(claim_slot)*2 +: 2] <= `TS_SLOT_ACTIVE;
      if (cpl_ok)   ss_q[sidx(complete_slot)*2 +: 2] <= (AUTO_RELEASE != 0) ? `TS_SLOT_FREE : `TS_SLOT_COMPLETE;
      if (rel_ok)   ss_q[sidx(release_slot)*2 +: 2] <= `TS_SLOT_FREE;
      if (v_h1) viol_q[0] <= 1'b1;
      if (v_h2) viol_q[1] <= 1'b1;
      if (v_h6) viol_q[2] <= 1'b1;
      if ((wr_acc & ~w_inrange) | (rd_acc & ~r_inrange)) viol_q[3] <= 1'b1;
    end
  end
  assign viol_sticky_o = viol_q;

  // ------------------------------------------------------------ external port
  logic          x_rsp_we, x_rsp_err;
  logic [2:0]    x_rsp_code;
  logic [EW-1:0] x_rsp_data;
  logic          x_range_ok, x_state_ok;
  always_comb begin
    x_range_ok = (32'(ext_req_slot) < NUM_SLOTS) && (32'(ext_req_row) < ROWS);
    x_state_ok = 1'b0;
    if (x_range_ok) x_state_ok = ext_req_we ? (ss_q[sidx(ext_req_slot)*2 +: 2] == `TS_SLOT_FREE)
                                            : (ss_q[sidx(ext_req_slot)*2 +: 2] == `TS_SLOT_COMPLETE);
  end
  assign ext_req_ready = (e_state == E_IDLE);
  wire   e_acc = ext_req_valid & ext_req_ready;
  wire   e_ok  = x_range_ok & x_state_ok;
  wire   e_rsp_pop = ext_rsp_valid & ext_rsp_ready;
  assign ext_rsp_valid = (e_state == E_RSP);
  assign ext_rsp_rdata = x_rsp_data; assign ext_rsp_we = x_rsp_we; assign ext_rsp_err = x_rsp_err; assign ext_rsp_code = x_rsp_code;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      e_state <= E_IDLE; e_we <= 1'b0; e_addr <= '0; e_slot <= '0; e_wdata <= '0; e_wait <= '0;
      x_rsp_we <= 1'b0; x_rsp_err <= 1'b0; x_rsp_code <= '0; x_rsp_data <= '0;
    end else begin
      case (e_state)
        E_IDLE: if (e_acc) begin
          e_we <= ext_req_we; e_slot <= ext_req_slot; e_wait <= '0;
          e_addr <= AW'(32'(ext_req_slot) * ROWS + 32'(ext_req_row));
          e_wdata <= DWA'(ext_req_wdata);
          x_rsp_we <= ext_req_we; x_rsp_data <= '0;
          if (e_ok) begin e_state <= E_PEND; x_rsp_err <= 1'b0; x_rsp_code <= `TS_XERR_OK; end
          else begin
            e_state <= E_RSP; x_rsp_err <= 1'b1;
            x_rsp_code <= x_range_ok ? `TS_XERR_OWNER : `TS_XERR_RANGE;
          end
        end
        E_PEND: begin
          if (e_rd_fwd) begin x_rsp_data <= hit_e_d; e_state <= E_RSP; end
          else if (e_issue) e_state <= e_we ? E_RSP : E_WAITRD;
          else if (e_wait != ECW'(EXT_STARVE_LIMIT + 1)) e_wait <= e_wait + 1'b1;
        end
        E_WAITRD: if (resp_ext) begin x_rsp_data <= live_ext[EW-1:0]; e_state <= E_RSP; end
        E_RSP: if (e_rsp_pop) e_state <= E_IDLE;
        default: e_state <= E_IDLE;
      endcase
    end
  end

  // ------------------------------------------------------------ events
  assign ev_rd        = rd_acc;
  assign ev_wr        = wr_push;
  assign ev_rd_deny   = ~st_rd_ready;
  assign ev_wr_freeze = st_wr_req & ~st_wr_ready;
  assign ev_fwd       = rd_acc & hit_r;
  assign ev_ext_wait  = (e_state == E_PEND) & ~e_issue & ~e_rd_fwd;
  assign ev_ext_ok    = e_rsp_pop & ~x_rsp_err;
  assign ev_ext_err   = e_rsp_pop &  x_rsp_err;
  assign ev_viol      = v_h1 | v_h2 | v_h6;
  wire unused_ok = &{1'b0, bk_ready, bk_tag[0], (live_acc >> EW), (live_ext >> EW)};      // padding bits above EW (none when EW is a multiple of 8)
endmodule

`default_nettype wire
