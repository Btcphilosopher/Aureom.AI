// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_stream
// One read stream of the operand buffers: an arithmetic sequence of bank words  base, base+stride, ... (count words),
// fetched in order and staged in a small FIFO.  An A lane is the stream  base_i + j  (stride 1, j = 0..NWA-1) over one
// row of the A tile; a B stream is the stream  base + j + k*SB  (stride SB words, k = 0..eff_k-1) over one word column of
// the B tile.  Both are the same mechanism, so the bank arbiter, the credits and the events are common.
//
//   * load_i (only while idle_o): latch base / stride / count.  The FIFO is NOT cleared: words of the previous tile that
//     are still staged stay in order in front of the new tile's words (tile boundaries are tracked by the consumer).
//     idle_o is also high in the cycle of the LAST grant (stream chaining): the next tile's configuration is loaded in that
//     same cycle, so its first request follows the last request of the previous tile with NO idle cycle (measured: removes the
//     one-cycle bubble per tile, docs/BANDWIDTH.md).
//   * request: req_valid_o while words remain and a credit is free;  credits: staged + in-flight < DEPTH, so a response can
//     never find the FIFO full (no response-side back-pressure exists on sf_sram_bank).
//   * the response path pushes rsp_data_i into the FIFO;  responses of one stream come back in request order because every
//     bank has the same fixed READ_LATENCY.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_ts_stream #(
  parameter int AWW   = 12,     // word-address width (within one operand set)
  parameter int CW    = 6,      // count width
  parameter int DW    = 32,
  parameter int DEPTH = 4,      // staged words (>= 2)
  parameter int CHAIN = 1,      // 1: stream chaining (see above); 0: load only after the cycle of the last grant (ablation for the benchmark)
  parameter int ICW   = $clog2(DEPTH + 1)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // configuration
  input  wire logic            load_i,
  input  wire logic [AWW-1:0]  load_base_i,
  input  wire logic [AWW-1:0]  load_stride_i,
  input  wire logic [CW-1:0]   load_cnt_i,
  output logic                 idle_o,            // every word of the loaded stream has been requested
  // bank request / grant
  output logic                 req_valid_o,
  output logic [AWW-1:0]       req_addr_o,
  input  wire logic            gnt_i,
  // bank response
  input  wire logic            rsp_valid_i,
  input  wire logic [DW-1:0]   rsp_data_i,
  // staged words
  output logic                 head_valid_o,
  output logic [DW-1:0]        head_data_o,
  input  wire logic            pop_i,
  output logic                 req_blocked_o      // a request is presented and not granted this cycle
);
  logic [AWW-1:0] addr_q, stride_q;
  logic [CW-1:0]  cnt_q;
  logic [ICW-1:0] infl_q;
  logic           f_empty, f_full;
  logic [ICW-1:0] f_cnt;

  sf_sync_fifo #(.W(DW), .DEPTH(DEPTH)) u_fifo (
    .clk(clk), .rst_n(rst_n), .clr_i(1'b0), .push_i(rsp_valid_i), .din_i(rsp_data_i), .pop_i(pop_i),
    .dout_o(head_data_o), .empty_o(f_empty), .full_o(f_full), .count_o(f_cnt));

  assign head_valid_o = ~f_empty;
  wire   iss;
  assign idle_o       = (cnt_q == '0) | ((CHAIN != 0) & (cnt_q == CW'(1)) & iss);      // idle, or (chained) issuing its last word right now
  wire   credit       = ((ICW+1)'(f_cnt) + (ICW+1)'(infl_q)) < (ICW+1)'(DEPTH);
  assign req_valid_o  = (cnt_q != '0) & credit;
  assign req_addr_o   = addr_q;
  assign req_blocked_o = req_valid_o & ~gnt_i;
  assign iss          = req_valid_o & gnt_i;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      addr_q <= '0; stride_q <= '0; cnt_q <= '0; infl_q <= '0;
    end else begin
      if (load_i) begin
        addr_q <= load_base_i; stride_q <= load_stride_i; cnt_q <= load_cnt_i;
      end else if (iss) begin
        addr_q <= addr_q + stride_q; cnt_q <= cnt_q - 1'b1;
      end
      infl_q <= infl_q + ICW'(iss) - ICW'(rsp_valid_i);
    end
  end

`ifdef SF_ASSERT
  always_ff @(posedge clk) if (rst_n) begin
    `SF_CHK(!(load_i && cnt_q != '0 && !(cnt_q == CW'(1) && iss)), "sf_ts_stream: load while the previous stream is still issuing")
    `SF_CHK(!(rsp_valid_i && f_full), "sf_ts_stream: response found the FIFO full (credit violation)")
  end
`endif
  wire unused_ok = &{1'b0, f_full};
endmodule

`default_nettype wire
