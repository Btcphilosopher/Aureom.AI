// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_dma_port     (DMA FILL PORT: decode, ownership check, in-order responses)
// Write-only fill port in the Module 04 / TensorCore 03 port protocol (so the same DMA master or tdma_loc_port can drive it):
//   dma_req_{valid,ready,we,addr,wdata,wstrb,tag}   dma_rsp_{valid,ready,rdata,err,err_code,we,tag}
//
// ---------------------------------------------------------------- window (byte addresses, offset = addr - DMA_BASE)
//   [0, A_TOT)                 A region:  set = offset / A_SET_BYTES,  in-set byte = offset mod A_SET_BYTES
//   [A_TOT, REGION)            hole (when B_TOT > A_TOT)                                   -> RANGE
//   [REGION, REGION + B_TOT)   B region:  set = (offset-REGION) / B_SET_BYTES
//   otherwise (also below DMA_BASE)                                                        -> RANGE
//   A_TOT = NSETS*A_SET_BYTES, B_TOT = NSETS*B_SET_BYTES, REGION = max(A_TOT, B_TOT)   (all powers of two)
//
// ---------------------------------------------------------------- checks, first match wins, none has a side effect
//   RANGE (1) > ALIGN (2: offset not a multiple of WORD_BYTES) > UNSUP (7: read request, the port is write-only)
//   > OWNER (6: the target set is not FILLING).   rdata is always 0.
//
// ---------------------------------------------------------------- protocol
//   * One request per cycle is accepted into a hold stage; exactly one response per request, in request order (errors pass through
//     the same hold stage, so they cannot overtake an earlier write).  A response is produced the cycle AFTER the write has been
//     committed in its bank (a write is committed at the accepting edge, sf_sram_core contract), i.e. the response means "visible".
//   * dma_req_ready never depends on dma_rsp_ready or dma_req_valid.  A write is only presented to a bank when the response FIFO can
//     take its response, so a granted write can never lose its response.
//   * quiet_o : no legal write is pending and no request that decodes as a legal write is being presented; sf_ts_dbuf_ctrl waits for
//     it before fill_end, so a
//     write can never be accepted against a set that is about to leave FILLING.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_ts_defs.svh"
`default_nettype none

module sf_ts_dma_port #(
  parameter int          ADDR_W      = 32,
  parameter logic [63:0] DMA_BASE    = 64'h0,
  parameter int          WB          = 4,
  parameter int          NSETS       = 2,
  parameter int          A_SET_BYTES = 4096,
  parameter int          B_SET_BYTES = 4096,
  parameter int          TAG_W       = 8,
  parameter int          RSP_DEPTH   = 4,
  // ---- derived
  parameter int          DW          = 8 * WB,
  parameter int          LWB         = $clog2(WB),
  parameter int          SETW        = (NSETS > 1) ? $clog2(NSETS) : 1,
  parameter int          AWWA        = $clog2(A_SET_BYTES / WB),
  parameter int          AWWB        = $clog2(B_SET_BYTES / WB)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                dma_req_valid,
  output logic                     dma_req_ready,
  input  wire logic                dma_req_we,
  input  wire logic [ADDR_W-1:0]   dma_req_addr,
  input  wire logic [DW-1:0]       dma_req_wdata,
  input  wire logic [WB-1:0]       dma_req_wstrb,
  input  wire logic [TAG_W-1:0]    dma_req_tag,
  output logic                     dma_rsp_valid,
  input  wire logic                dma_rsp_ready,
  output logic      [DW-1:0]       dma_rsp_rdata,
  output logic                     dma_rsp_err,
  output logic      [2:0]          dma_rsp_err_code,
  output logic                     dma_rsp_we,
  output logic      [TAG_W-1:0]    dma_rsp_tag,
  // ownership view
  input  wire logic [NSETS*2-1:0]  set_state,
  output logic                     quiet_o,
  // write ports to the A / B bank groups
  output logic                     a_wr_valid,
  output logic      [SETW-1:0]     a_wr_set,
  output logic      [AWWA-1:0]     a_wr_addr,
  output logic      [DW-1:0]       a_wr_data,
  output logic      [WB-1:0]       a_wr_be,
  input  wire logic                a_wr_gnt,
  output logic                     b_wr_valid,
  output logic      [SETW-1:0]     b_wr_set,
  output logic      [AWWB-1:0]     b_wr_addr,
  output logic      [DW-1:0]       b_wr_data,
  output logic      [WB-1:0]       b_wr_be,
  input  wire logic                b_wr_gnt,
  // events
  output logic                     ev_wr_issue,
  output logic                     ev_err
);
  localparam int A_TOT  = NSETS * A_SET_BYTES;
  localparam int B_TOT  = NSETS * B_SET_BYTES;
  localparam int REGION = (A_TOT > B_TOT) ? A_TOT : B_TOT;
  if ((WB & (WB - 1)) != 0) begin : g_err_wb
    `SF_CFG_FATAL("sf_ts_dma_port: WORD_BYTES must be a power of two")
  end

  // ------------------------------------------------------------ decode
  logic [63:0] off;
  logic        in_win, is_a, is_b;
  logic [2:0]  dcode;
  logic [SETW-1:0] dset;
  logic [31:0] inset;
  always_comb begin
    off    = 64'(dma_req_addr) - DMA_BASE;
    /* verilator lint_off UNSIGNED */
    in_win = (64'(dma_req_addr) >= DMA_BASE);       // constant 1 when DMA_BASE = 0
    /* verilator lint_on UNSIGNED */
    is_a   = in_win & (off < 64'(A_TOT));
    is_b   = in_win & (off >= 64'(REGION)) & (off < 64'(REGION) + 64'(B_TOT));
    dset   = '0; inset = '0;
    if (is_a)      begin dset = SETW'(off / 64'(A_SET_BYTES)); inset = 32'(off % 64'(A_SET_BYTES)); end
    else if (is_b) begin dset = SETW'((off - 64'(REGION)) / 64'(B_SET_BYTES)); inset = 32'((off - 64'(REGION)) % 64'(B_SET_BYTES)); end
    dcode = `TS_DERR_OK;
    if (!(is_a | is_b))                                    dcode = `TS_DERR_RANGE;
    else if ((off & (64'(WB) - 64'd1)) != 64'd0)                 dcode = `TS_DERR_ALIGN;
    else if (!dma_req_we)                                  dcode = `TS_DERR_UNSUP;
    else if (set_state[32'(dset)*2 +: 2] != `TS_SET_FILLING) dcode = `TS_DERR_OWNER;
  end

  // ------------------------------------------------------------ hold stage
  logic            h_v, h_err, h_to_a, h_we;
  logic [2:0]      h_code;
  logic [SETW-1:0] h_set;
  logic [31:0]     h_inset;
  logic [DW-1:0]   h_data;
  logic [WB-1:0]   h_be;
  logic [TAG_W-1:0] h_tag;

  logic        rf_full, rf_empty;
  logic [TAG_W+5:0] rf_in, rf_out;
  wire         space = ~rf_full;

  wire h_is_wr  = h_v & ~h_err;
  assign a_wr_valid = h_is_wr & h_to_a  & space;
  assign b_wr_valid = h_is_wr & ~h_to_a & space;
  assign a_wr_set = h_set; assign b_wr_set = h_set;
  assign a_wr_addr = AWWA'(h_inset >> LWB); assign b_wr_addr = AWWB'(h_inset >> LWB);
  assign a_wr_data = h_data; assign b_wr_data = h_data; assign a_wr_be = h_be; assign b_wr_be = h_be;

  wire h_issue = h_v & space & (h_err | (h_to_a ? a_wr_gnt : b_wr_gnt));
  assign dma_req_ready = ~h_v | h_issue;
  wire acc = dma_req_valid & dma_req_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      h_v <= 1'b0; h_err <= 1'b0; h_to_a <= 1'b0; h_we <= 1'b0; h_code <= '0; h_set <= '0; h_inset <= '0;
      h_data <= '0; h_be <= '0; h_tag <= '0;
    end else begin
      if (h_issue) h_v <= 1'b0;
      if (acc) begin
        h_v <= 1'b1; h_err <= (dcode != `TS_DERR_OK); h_code <= dcode; h_to_a <= is_a; h_we <= dma_req_we;
        h_set <= dset; h_inset <= inset; h_data <= dma_req_wdata; h_be <= dma_req_wstrb; h_tag <= dma_req_tag;
      end
    end
  end

  // quiet = no accepted legal write is pending and the request on the port (if any) will not be a legal write.  A request that decodes
  // to an error is refused without side effect, so it must not hold fill_end off (liveness: a master that keeps presenting refused
  // requests would otherwise block the end of the fill forever).
  assign quiet_o = ~h_is_wr & ~(dma_req_valid & (dcode == `TS_DERR_OK));

  // ------------------------------------------------------------ in-order response FIFO
  assign rf_in = {h_tag, h_we, h_err, h_code, 1'b0};
  logic [$clog2(RSP_DEPTH+1)-1:0] rf_cnt_unused;
  sf_sync_fifo #(.W(TAG_W + 6), .DEPTH(RSP_DEPTH)) u_rsp (
    .clk(clk), .rst_n(rst_n), .clr_i(1'b0), .push_i(h_issue), .din_i(rf_in), .pop_i(dma_rsp_valid & dma_rsp_ready),
    .dout_o(rf_out), .empty_o(rf_empty), .full_o(rf_full), .count_o(rf_cnt_unused));
  assign dma_rsp_valid    = ~rf_empty;
  assign dma_rsp_rdata    = '0;
  assign dma_rsp_tag      = rf_out[TAG_W+5:6];
  assign dma_rsp_we       = rf_out[5];
  assign dma_rsp_err      = rf_out[4];
  assign dma_rsp_err_code = rf_out[3:1];

  assign ev_wr_issue = h_issue & ~h_err;
  assign ev_err      = h_issue & h_err;
  wire unused_ok = &{1'b0, rf_out[0], rf_cnt_unused};
endmodule

`default_nettype wire
