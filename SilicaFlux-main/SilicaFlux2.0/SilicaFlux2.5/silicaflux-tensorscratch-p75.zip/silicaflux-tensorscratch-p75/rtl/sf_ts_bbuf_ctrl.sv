// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_bbuf_ctrl     (B-BUFFER CONTROLLER)
// B operand storage + read side.  The array needs ARRAY_COLS bytes of B per slice: B[k0+k][n0 .. n0+C-1], a contiguous
// run of C elements in ONE matrix row k.  Row k+1 lies ldb bytes further on.
//
//   * A B row segment starts at byte offset offB (= n0*ELEM_BYTES mod WORD_BYTES) inside its first word and therefore spans
//     NW = ceil((offB + eff_n*EB)/WB) consecutive words (1 when aligned, 2 when it straddles a word boundary).
//   * One read stream per word column j = 0..NWBMAX-1: stream j fetches word  wB0 + j + k*SB  for k = 0..eff_k-1
//     (SB = ldb / WORD_BYTES).  Consecutive words are in different banks (word interleaving), so a straddling row needs
//     two different banks in the same cycle - NUM_B_BANKS >= 2 sustains 1 slice per cycle even then; NUM_B_BANKS = 1
//     halves the rate (measured, docs/BANDWIDTH.md).
//   * Unlike A, B needs a fresh word on EVERY slice, so the B banks are read every cycle at full rate.  A and B live in
//     separate bank groups, so they never contend with each other - only with the DMA write.
//
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_ts_bbuf_ctrl #(
  parameter int NWB          = 2,       // max words one B row segment spans (NWBMAX)
  parameter int WB           = 4,
  parameter int NB           = 2,
  parameter int NSETS        = 1,
  parameter int SPLIT        = 0,
  parameter int SET_WORDS    = 1024,
  parameter int READ_LATENCY = 1,
  parameter int STAGE        = 4,
  parameter int CW           = 6,
  parameter int BACKEND      = `SF_BACKEND_BEHAV,
  parameter int SIM_INIT     = 2,
  parameter int STARVE_LIMIT = 8,
  parameter int CHAIN        = 1,
  // ---- derived
  parameter int DW           = 8 * WB,
  parameter int AWW          = $clog2(SET_WORDS),
  parameter int SETW         = (NSETS > 1) ? $clog2(NSETS) : 1,
  parameter int NWW          = $clog2(NWB + 1),
  parameter int BE_W         = WB
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                ld_valid,
  output logic                     ld_ready,
  input  wire logic [SETW-1:0]     ld_set,
  input  wire logic [AWW-1:0]      ld_base,       // word index of word 0 of row k = 0
  input  wire logic [AWW-1:0]      ld_sb,         // row stride in words (ldb / WORD_BYTES)
  input  wire logic [CW-1:0]       ld_rows,       // eff_k: rows to deliver
  input  wire logic [NWW-1:0]      ld_nw,         // live word columns (1..NWB)
  output logic      [NWB-1:0]      head_valid,
  output logic      [NWB*DW-1:0]   head_data,
  input  wire logic [NWB-1:0]      pop,
  input  wire logic                wr_valid,
  input  wire logic [SETW-1:0]     wr_set,
  input  wire logic [AWW-1:0]      wr_addr,
  input  wire logic [DW-1:0]       wr_data,
  input  wire logic [BE_W-1:0]     wr_be,
  output logic                     wr_gnt,
  output logic [7:0]               ev_rd_words,
  output logic [7:0]               ev_rd_stall,
  output logic [7:0]               ev_conflict,
  output logic [7:0]               ev_rd_wr_block,
  output logic                     ev_wr_stall,
  output logic                     ev_wr_forced
);
  logic [SETW-1:0]   set_q;
  logic [NWB-1:0]    s_idle, s_req, s_gnt, s_rp_v, s_blocked;
  logic [NWB*AWW-1:0] s_addr;
  logic [NWB*DW-1:0] s_rp_d;
  assign ld_ready = &s_idle;
  wire   do_ld    = ld_valid & ld_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) set_q <= '0;
    else if (do_ld) set_q <= ld_set;
  end

  for (genvar j = 0; j < NWB; j++) begin : g_col
    wire [AWW-1:0] base_j = ld_base + AWW'(j);
    wire [CW-1:0]  cnt_j  = (j < 32'(ld_nw)) ? ld_rows : '0;
    sf_ts_stream #(.AWW(AWW), .CW(CW), .DW(DW), .DEPTH(STAGE), .CHAIN(CHAIN)) u_s (
      .clk(clk), .rst_n(rst_n), .load_i(do_ld), .load_base_i(base_j), .load_stride_i(ld_sb), .load_cnt_i(cnt_j),
      .idle_o(s_idle[j]), .req_valid_o(s_req[j]), .req_addr_o(s_addr[j*AWW +: AWW]), .gnt_i(s_gnt[j]),
      .rsp_valid_i(s_rp_v[j]), .rsp_data_i(s_rp_d[j*DW +: DW]),
      .head_valid_o(head_valid[j]), .head_data_o(head_data[j*DW +: DW]), .pop_i(pop[j]), .req_blocked_o(s_blocked[j]));
  end

  sf_ts_bankgrp #(.NS(NWB), .NB(NB), .NSETS(NSETS), .SPLIT(SPLIT), .SET_WORDS(SET_WORDS), .DW(DW),
                  .READ_LATENCY(READ_LATENCY), .BACKEND(BACKEND), .SIM_INIT(SIM_INIT), .STARVE_LIMIT(STARVE_LIMIT)) u_grp (
    .clk(clk), .rst_n(rst_n), .rq_valid(s_req), .rq_set(set_q), .rq_addr(s_addr), .rq_gnt(s_gnt), .rp_valid(s_rp_v),
    .rp_data(s_rp_d), .wr_valid(wr_valid), .wr_set(wr_set), .wr_addr(wr_addr), .wr_data(wr_data), .wr_be(wr_be),
    .wr_gnt(wr_gnt), .ev_rd_words(ev_rd_words), .ev_conflict(ev_conflict), .ev_rd_wr_block(ev_rd_wr_block),
    .ev_wr_stall(ev_wr_stall), .ev_wr_forced(ev_wr_forced));

  always_comb begin
    ev_rd_stall = 8'd0;
    for (int j = 0; j < NWB; j++) ev_rd_stall = ev_rd_stall + 8'(s_blocked[j]);
  end
endmodule

`default_nettype wire
