// =============================================================================
// SilicaFlux TensorScratch :: sf_tensor_scratchpad        (PRIMARY SOURCE, SilicaFlux project 75)
// High-bandwidth tensor SRAM subsystem for the SilicaFlux TensorCore: A / B operand buffers, accumulator buffer, DMA fill port,
// double-buffer ownership, tile address generation, k-slice delivery to the TENSORCORE 02 systolic array, performance events.
//
//        DMA (Module 04 port) --> dma_port --> A bank group (NUM_A_BANKS x 1RW sf_sram_bank)  --> R A-lane streams --+
//                                         \--> B bank group (NUM_B_BANKS x 1RW sf_sram_bank)  --> B word streams  ---+--> slice assembler
//        tile descriptor --> AGU --> context queue --> fetch sequencer (loads the streams)                              |  --> s_* to array
//        fill/cmp commands --> dbuf_ctrl (FREE / FILLING / READY / IN_USE per set)                                     v
//        tensor_accumulator st_* <--> accbuf (NUM_ACC_BANKS x 1RW banks, slot ownership, external port)
//
// ---------------------------------------------------------------- what is delivered (the actual TensorCore interfaces)
//   operands : TENSORCORE 02 tensor_systolic_array  s_valid/s_ready, s_a (A[:,k], lane i = row i), s_b (B[k,:], lane j = column j), s_k.
//              Un-skewed k-slices: the array skews internally (tensor_skew), so this module aligns lanes to one k and never skews.
//   results  : TENSORCORE 02 readout -> TENSORCORE 04 tensor_accumulator (adds each K chunk exactly once) -> accumulator storage
//              interface st_*, which this module implements (accbuf).  No second accumulation is performed here.
//
// ---------------------------------------------------------------- bandwidth
//   Steady state: 1 slice per cycle = ARRAY_ROWS + ARRAY_COLS operands (8 for 4x4 INT8) from single-port banks: each bank read
//   returns a WORD_BYTES word; the A lanes spend one word over WORD_BYTES/ELEM_BYTES slices, the B streams read one word (two when
//   the B row straddles a word) per slice from separate bank groups.  Conflict-free layouts reach 1.000 slice/cycle; every loss is
//   an event (A/B read stall, bank conflict, DMA conflict, compute starvation) - docs/BANDWIDTH.md.
//
// ---------------------------------------------------------------- parameters
//   ARRAY_ROWS, ARRAY_COLS        array size (A lanes / B lanes)
//   TILE_K                        largest reduction chunk one tile descriptor may request (K-chunk length)
//   OPERAND_WIDTH                 8 (signed INT8, default) or 16
//   ACC_WIDTH                     lane width of the persistent accumulator storage: 32 (INT32) or 40 / 48 (wider format)
//   A_BUFFER_BYTES, B_BUFFER_BYTES  TOTAL capacity of the A / B regions over all sets (powers of two; per set = total / NSETS)
//   ACC_BUFFER_BYTES              capacity of the accumulator buffer; slots = ACC_BUFFER_BYTES / (ARRAY_ROWS * entry bytes)
//   NUM_A_BANKS, NUM_B_BANKS, NUM_ACC_BANKS   physical single-port banks per buffer (per set when SET_MAP = SPLIT)
//   ACC_WQ_DEPTH                  accumulator write-buffer entries (single-port banks behind the one-read-one-write storage contract)
//   ENABLE_DOUBLE_BUFFERING       1: two operand sets (ping-pong), 0: one set
//   SET_MAP                       0 SHARED: both sets in the same banks (fill and compute contend, counted); 1 SPLIT: own banks per set
//   see the parameter list for the remaining tunables (word size, stages, latencies, widths).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_ts_defs.svh"
`default_nettype none

module sf_tensor_scratchpad #(
  parameter int          ARRAY_ROWS              = 4,
  parameter int          ARRAY_COLS              = 4,
  parameter int          TILE_K                  = 32,
  parameter int          OPERAND_WIDTH           = 8,
  parameter int          ACC_WIDTH               = 32,
  parameter int          A_BUFFER_BYTES          = 8192,
  parameter int          B_BUFFER_BYTES          = 8192,
  parameter int          ACC_BUFFER_BYTES        = 1024,
  parameter int          NUM_A_BANKS             = 4,
  parameter int          NUM_B_BANKS             = 2,
  parameter int          ENABLE_DOUBLE_BUFFERING = 1,
  // ---- further tunables
  parameter int          WORD_BYTES              = 4,
  parameter int          NUM_ACC_BANKS           = 4,
  parameter int          SET_MAP                 = 1,          // 0 SHARED, 1 SPLIT (only meaningful with double buffering)
  parameter int          READ_LATENCY            = 1,          // operand bank read latency (sf_sram_bank contract)
  parameter int          A_STAGE                 = 4,          // staged words per A lane
  parameter int          B_STAGE                 = 8,          // staged words per B stream (8 sustains full rate even for the worst A layout, docs/BANDWIDTH.md)
  parameter int          WR_STARVE_LIMIT         = 8,          // cycles a DMA write yields to reads (0: writes first)
  parameter int          STREAM_CHAIN            = 1,          // 1: load the next tile's stream in the cycle of the last grant (no tile-boundary bubble)
  parameter int          ACC_RD_LAT              = 1,          // must equal tensor_accumulator RD_LAT
  parameter int          ACC_EXT_STARVE_LIMIT    = 8,
  parameter int          ACC_WQ_DEPTH            = 4,          // accumulator write-buffer entries (>= 2)
  parameter int          ACC_AUTO_RELEASE        = 0,
  parameter int          CTXQ_DEPTH              = 2,          // tile contexts in flight (addressed / fetched ahead of the array)
  parameter int          ADDR_W                  = 32,
  parameter logic [63:0] DMA_BASE                = 64'h0,
  parameter int          IDX_W                   = 16,
  parameter int          K_W                     = 17,         // = TENSORCORE 02 K_WIDTH
  parameter int          TAG_W                   = 8,
  parameter int          DMA_RSP_DEPTH           = 4,
  parameter int          TRSP_DEPTH              = 4,
  parameter int          BACKEND                 = `SF_BACKEND_BEHAV,
  parameter int          SIM_INIT                = 2,
  parameter int          PERF_EN                 = 1,
  parameter int          CNT_W                   = 32,
  // ------------------------------------------------------------ derived (never set)
  parameter int          R         = ARRAY_ROWS,
  parameter int          C         = ARRAY_COLS,
  parameter int          OW        = OPERAND_WIDTH,
  parameter int          EB        = OPERAND_WIDTH / 8,
  parameter int          WB        = WORD_BYTES,
  parameter int          DW        = 8 * WORD_BYTES,
  parameter int          EPW       = WORD_BYTES / (OPERAND_WIDTH / 8),
  parameter int          LEPW      = (EPW > 1) ? $clog2(EPW) : 1,
  parameter int          NSETS     = (ENABLE_DOUBLE_BUFFERING != 0) ? 2 : 1,
  parameter int          SETW      = (NSETS > 1) ? $clog2(NSETS) : 1,
  parameter int          A_SET_BYTES = A_BUFFER_BYTES / NSETS,
  parameter int          B_SET_BYTES = B_BUFFER_BYTES / NSETS,
  parameter int          A_SET_WORDS = A_SET_BYTES / WORD_BYTES,
  parameter int          B_SET_WORDS = B_SET_BYTES / WORD_BYTES,
  parameter int          AWWA      = $clog2(A_SET_WORDS),
  parameter int          AWWB      = $clog2(B_SET_WORDS),
  parameter int          NWB       = (WORD_BYTES - EB + ARRAY_COLS * EB + WORD_BYTES - 1) / WORD_BYTES,
  parameter int          NWW       = $clog2(NWB + 1),
  parameter int          CW        = $clog2(TILE_K + 2),
  parameter int          RMW       = $clog2(ARRAY_ROWS + 1),
  parameter int          CNW       = $clog2(ARRAY_COLS + 1),
  parameter int          ACC_EW    = ARRAY_COLS * (ACC_WIDTH + 1),
  parameter int          ACC_ENTRY_BYTES = (ACC_EW + 7) / 8,
  parameter int          NUM_ACC_SLOTS = (ACC_BUFFER_BYTES / (ARRAY_ROWS * ACC_ENTRY_BYTES) < 1) ? 1 : ACC_BUFFER_BYTES / (ARRAY_ROWS * ACC_ENTRY_BYTES),
  parameter int          ACC_AW    = (NUM_ACC_SLOTS * ARRAY_ROWS > 1) ? $clog2(NUM_ACC_SLOTS * ARRAY_ROWS) : 1,
  parameter int          ACC_SLOT_W = (NUM_ACC_SLOTS > 1) ? $clog2(NUM_ACC_SLOTS) : 1,
  parameter int          ACC_RIDW  = (ARRAY_ROWS > 1) ? $clog2(ARRAY_ROWS) : 1,
  parameter int          EV_W      = 8
) (
  input  wire logic                           clk,
  input  wire logic                           rst_n,
  // ---------------------------------------------------------- DMA fill port (Module 04 port protocol, write-only)
  input  wire logic                           dma_req_valid,
  output logic                                dma_req_ready,
  input  wire logic                           dma_req_we,
  input  wire logic [ADDR_W-1:0]              dma_req_addr,
  input  wire logic [DW-1:0]                  dma_req_wdata,
  input  wire logic [WB-1:0]                  dma_req_wstrb,
  input  wire logic [TAG_W-1:0]               dma_req_tag,
  output logic                                dma_rsp_valid,
  input  wire logic                           dma_rsp_ready,
  output logic      [DW-1:0]                  dma_rsp_rdata,
  output logic                                dma_rsp_err,
  output logic      [2:0]                     dma_rsp_err_code,
  output logic                                dma_rsp_we,
  output logic      [TAG_W-1:0]               dma_rsp_tag,
  // ---------------------------------------------------------- operand-set ownership
  input  wire logic                           fill_begin_valid,
  output logic                                fill_begin_ready,
  input  wire logic                           fill_end_valid,
  output logic                                fill_end_ready,
  input  wire logic                           cmp_begin_valid,
  output logic                                cmp_begin_ready,
  input  wire logic                           cmp_end_valid,
  output logic                                cmp_end_ready,
  output logic      [SETW-1:0]                fill_set,
  output logic      [SETW-1:0]                cmp_set,
  output logic      [NSETS*2-1:0]             set_state,
  // ---------------------------------------------------------- tile descriptors (TENSORCORE 03 compatible)
  input  wire logic                           tile_valid,
  output logic                                tile_ready,
  input  wire logic [ADDR_W-1:0]              tile_a_addr,
  input  wire logic [ADDR_W-1:0]              tile_lda,
  input  wire logic [ADDR_W-1:0]              tile_b_addr,
  input  wire logic [ADDR_W-1:0]              tile_ldb,
  input  wire logic [IDX_W-1:0]               tile_m0,
  input  wire logic [IDX_W-1:0]               tile_n0,
  input  wire logic [K_W-1:0]                 tile_k0,
  input  wire logic [IDX_W-1:0]               tile_mat_m,
  input  wire logic [IDX_W-1:0]               tile_mat_n,
  input  wire logic [K_W-1:0]                 tile_mat_k,
  input  wire logic [K_W-1:0]                 tile_k,
  input  wire logic [TAG_W-1:0]               tile_tag,
  output logic                                tile_rsp_valid,
  input  wire logic                           tile_rsp_ready,
  output logic      [TAG_W-1:0]               tile_rsp_tag,
  output logic                                tile_rsp_err,
  output logic      [3:0]                     tile_rsp_code,
  output logic      [RMW-1:0]                 tile_rsp_m,        // = cfg_m of the array
  output logic      [CNW-1:0]                 tile_rsp_n,        // = cfg_n
  output logic      [K_W-1:0]                 tile_rsp_k,        // = cfg_k
  // ---------------------------------------------------------- k-slice stream (to tensor_systolic_array s_*)
  output logic                                s_valid,
  input  wire logic                           s_ready,
  output logic      [R*OW-1:0]                s_a,
  output logic      [C*OW-1:0]                s_b,
  output logic      [K_W-1:0]                 s_k,
  output logic      [K_W-1:0]                 s_kg,
  output logic      [IDX_W-1:0]               s_m0,
  output logic      [IDX_W-1:0]               s_n0,
  output logic      [R-1:0]                   s_row_mask,
  output logic      [C-1:0]                   s_col_mask,
  output logic                                s_first,
  output logic                                s_last,
  output logic      [TAG_W-1:0]               s_tag,
  output logic      [SETW-1:0]                s_set,
  // ---------------------------------------------------------- accumulator storage interface (tensor_accumulator st_*)
  input  wire logic                           acc_st_en,
  input  wire logic                           acc_st_rd_req,
  input  wire logic [ACC_AW-1:0]              acc_st_rd_addr,
  output logic                                acc_st_rd_ready,
  output logic      [ACC_EW-1:0]              acc_st_rd_data,
  input  wire logic                           acc_st_wr_req,
  input  wire logic [ACC_AW-1:0]              acc_st_wr_addr,
  input  wire logic [ACC_EW-1:0]              acc_st_wr_data,
  output logic                                acc_st_wr_ready,
  // ---------------------------------------------------------- accumulator slot ownership + external port
  input  wire logic                           acc_claim_valid,
  output logic                                acc_claim_ready,
  input  wire logic [ACC_SLOT_W-1:0]          acc_claim_slot,
  input  wire logic                           acc_complete_valid,      // wire tensor_accumulator cmt_done / cmt_slot here
  input  wire logic [ACC_SLOT_W-1:0]          acc_complete_slot,
  input  wire logic                           acc_release_valid,
  input  wire logic [ACC_SLOT_W-1:0]          acc_release_slot,
  output logic      [NUM_ACC_SLOTS*2-1:0]     acc_slot_state,
  input  wire logic                           ext_req_valid,
  output logic                                ext_req_ready,
  input  wire logic                           ext_req_we,
  input  wire logic [ACC_SLOT_W-1:0]          ext_req_slot,
  input  wire logic [ACC_RIDW-1:0]            ext_req_row,
  input  wire logic [ACC_EW-1:0]              ext_req_wdata,
  output logic                                ext_rsp_valid,
  input  wire logic                           ext_rsp_ready,
  output logic      [ACC_EW-1:0]              ext_rsp_rdata,
  output logic                                ext_rsp_we,
  output logic                                ext_rsp_err,
  output logic      [2:0]                     ext_rsp_code,
  output logic      [3:0]                     acc_viol_sticky,
  // ---------------------------------------------------------- status / performance
  output logic                                busy,
  output logic                                engine_idle,
  output logic      [`TS_NUM_EV*EV_W-1:0]     ev_inc,
  input  wire logic                           perf_clear,
  output logic      [`TS_NUM_EV*CNT_W-1:0]    perf_cnt
);
  // ------------------------------------------------------------ elaboration checks
  if (ARRAY_ROWS < 1 || ARRAY_COLS < 1) begin : g_err_dim
    `SF_CFG_FATAL("sf_tensor_scratchpad: ARRAY_ROWS and ARRAY_COLS must be >= 1")
  end
  if (OPERAND_WIDTH != 8 && OPERAND_WIDTH != 16) begin : g_err_ow
    `SF_CFG_FATAL("sf_tensor_scratchpad: OPERAND_WIDTH must be 8 or 16 (signed)")
  end
  if (ACC_WIDTH < 2 * OPERAND_WIDTH) begin : g_err_acc
    `SF_CFG_FATAL("sf_tensor_scratchpad: ACC_WIDTH must be >= 2*OPERAND_WIDTH")
  end
  if ((WORD_BYTES & (WORD_BYTES - 1)) != 0 || WORD_BYTES < OPERAND_WIDTH / 8 || WORD_BYTES < 2) begin : g_err_wb
    `SF_CFG_FATAL("sf_tensor_scratchpad: WORD_BYTES must be a power of two, >= 2 and >= the operand size")
  end
  if (A_BUFFER_BYTES < 1 || B_BUFFER_BYTES < 1 || ((A_BUFFER_BYTES & (A_BUFFER_BYTES - 1)) != 0) || ((B_BUFFER_BYTES & (B_BUFFER_BYTES - 1)) != 0)) begin : g_err_buf
    `SF_CFG_FATAL("sf_tensor_scratchpad: A_BUFFER_BYTES and B_BUFFER_BYTES must be powers of two")
  end
  if (A_SET_WORDS < 2 * NUM_A_BANKS || B_SET_WORDS < 2 * NUM_B_BANKS) begin : g_err_cap
    `SF_CFG_FATAL("sf_tensor_scratchpad: a set must hold at least two words per bank (buffer too small for the bank count)")
  end
  if (TILE_K < 1 || CTXQ_DEPTH < 2 || A_STAGE < 2 || B_STAGE < 2) begin : g_err_misc
    `SF_CFG_FATAL("sf_tensor_scratchpad: TILE_K >= 1, CTXQ_DEPTH >= 2, A_STAGE >= 2, B_STAGE >= 2 required")
  end
  if (ACC_BUFFER_BYTES < ARRAY_ROWS * ACC_ENTRY_BYTES) begin : g_err_accb
    `SF_CFG_FATAL("sf_tensor_scratchpad: ACC_BUFFER_BYTES must hold at least one output tile slot")
  end
  if (DMA_BASE[ADDR_W-1:0] != '0 && (64'(1) << ADDR_W) <= DMA_BASE) begin : g_err_base
    `SF_CFG_FATAL("sf_tensor_scratchpad: DMA_BASE does not fit ADDR_W")
  end

  // ------------------------------------------------------------ ownership
  logic fill_active, cmp_active, fill_quiet;
  logic ev_fill_done_u, ev_cmp_begin_u, ev_cmp_done_u;
  sf_ts_dbuf_ctrl #(.NSETS(NSETS)) u_dbuf (
    .clk(clk), .rst_n(rst_n),
    .fill_begin_valid(fill_begin_valid), .fill_begin_ready(fill_begin_ready), .fill_end_valid(fill_end_valid),
    .fill_end_ready(fill_end_ready), .cmp_begin_valid(cmp_begin_valid), .cmp_begin_ready(cmp_begin_ready),
    .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cmp_end_ready), .fill_quiet_i(fill_quiet), .cmp_idle_i(engine_idle),
    .fill_set(fill_set), .cmp_set(cmp_set), .fill_active(fill_active), .cmp_active(cmp_active), .set_state(set_state),
    .ev_fill_done(ev_fill_done_u), .ev_cmp_begin(ev_cmp_begin_u), .ev_cmp_done(ev_cmp_done_u));

  // ------------------------------------------------------------ DMA fill port
  logic                a_wr_valid, b_wr_valid, a_wr_gnt, b_wr_gnt;
  logic [SETW-1:0]     a_wr_set, b_wr_set;
  logic [AWWA-1:0]     a_wr_addr;
  logic [AWWB-1:0]     b_wr_addr;
  logic [DW-1:0]       a_wr_data, b_wr_data;
  logic [WB-1:0]       a_wr_be, b_wr_be;
  logic                ev_dma_issue, ev_dma_err;
  sf_ts_dma_port #(.ADDR_W(ADDR_W), .DMA_BASE(DMA_BASE), .WB(WB), .NSETS(NSETS), .A_SET_BYTES(A_SET_BYTES),
                   .B_SET_BYTES(B_SET_BYTES), .TAG_W(TAG_W), .RSP_DEPTH(DMA_RSP_DEPTH)) u_dma (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(dma_req_we), .dma_req_addr(dma_req_addr),
    .dma_req_wdata(dma_req_wdata), .dma_req_wstrb(dma_req_wstrb), .dma_req_tag(dma_req_tag),
    .dma_rsp_valid(dma_rsp_valid), .dma_rsp_ready(dma_rsp_ready), .dma_rsp_rdata(dma_rsp_rdata), .dma_rsp_err(dma_rsp_err),
    .dma_rsp_err_code(dma_rsp_err_code), .dma_rsp_we(dma_rsp_we), .dma_rsp_tag(dma_rsp_tag),
    .set_state(set_state), .quiet_o(fill_quiet),
    .a_wr_valid(a_wr_valid), .a_wr_set(a_wr_set), .a_wr_addr(a_wr_addr), .a_wr_data(a_wr_data), .a_wr_be(a_wr_be), .a_wr_gnt(a_wr_gnt),
    .b_wr_valid(b_wr_valid), .b_wr_set(b_wr_set), .b_wr_addr(b_wr_addr), .b_wr_data(b_wr_data), .b_wr_be(b_wr_be), .b_wr_gnt(b_wr_gnt),
    .ev_wr_issue(ev_dma_issue), .ev_err(ev_dma_err));

  // ------------------------------------------------------------ tile address generation
  logic                agu_busy, res_valid, res_err;
  logic [3:0]          res_code;
  logic [TAG_W-1:0]    res_tag;
  logic [SETW-1:0]     res_set;
  logic [IDX_W-1:0]    res_m0, res_n0;
  logic [K_W-1:0]      res_k0, res_eff_k;
  logic [RMW-1:0]      res_eff_m;
  logic [CNW-1:0]      res_eff_n;
  logic [AWWA-1:0]     res_a_word, res_a_sa;
  logic [CW-1:0]       res_a_nwords;
  logic [LEPW-1:0]     res_a_off, res_b_off;
  logic [AWWB-1:0]     res_b_word, res_b_sb;
  logic [NWW-1:0]      res_b_nw;
  logic                agu_room;
  sf_ts_agu #(.R(R), .C(C), .EB(EB), .WB(WB), .TILE_K(TILE_K), .A_SET_BYTES(A_SET_BYTES), .B_SET_BYTES(B_SET_BYTES), .NWB(NWB),
              .ADDR_W(ADDR_W), .IDX_W(IDX_W), .K_W(K_W), .TAG_W(TAG_W), .SETW(SETW)) u_agu (
    .clk(clk), .rst_n(rst_n), .tile_valid(tile_valid), .tile_ready(tile_ready), .room_i(agu_room), .own_ok_i(cmp_active),
    .own_set_i(cmp_set), .tile_a_addr(tile_a_addr), .tile_lda(tile_lda), .tile_b_addr(tile_b_addr), .tile_ldb(tile_ldb),
    .tile_m0(tile_m0), .tile_n0(tile_n0), .tile_k0(tile_k0), .tile_mat_m(tile_mat_m), .tile_mat_n(tile_mat_n),
    .tile_mat_k(tile_mat_k), .tile_k(tile_k), .tile_tag(tile_tag),
    .busy_o(agu_busy), .res_valid(res_valid), .res_err(res_err), .res_code(res_code), .res_tag(res_tag), .res_set(res_set),
    .res_m0(res_m0), .res_n0(res_n0), .res_k0(res_k0), .res_eff_m(res_eff_m), .res_eff_n(res_eff_n), .res_eff_k(res_eff_k),
    .res_a_word(res_a_word), .res_a_sa(res_a_sa), .res_a_nwords(res_a_nwords), .res_a_off(res_a_off),
    .res_b_word(res_b_word), .res_b_sb(res_b_sb), .res_b_nw(res_b_nw), .res_b_off(res_b_off));

  // tile response FIFO (every descriptor, in order, including rejected ones)
  localparam int TRW = TAG_W + 1 + 4 + RMW + CNW + K_W;
  logic            tr_full, tr_empty;
  logic [$clog2(TRSP_DEPTH+1)-1:0] tr_cnt;
  logic [TRW-1:0]  tr_out;
  sf_sync_fifo #(.W(TRW), .DEPTH(TRSP_DEPTH)) u_trsp (
    .clk(clk), .rst_n(rst_n), .clr_i(1'b0), .push_i(res_valid), .din_i({res_tag, res_err, res_code, res_eff_m, res_eff_n, res_eff_k}),
    .pop_i(tile_rsp_valid & tile_rsp_ready), .dout_o(tr_out), .empty_o(tr_empty), .full_o(tr_full), .count_o(tr_cnt));
  assign tile_rsp_valid = ~tr_empty;
  assign {tile_rsp_tag, tile_rsp_err, tile_rsp_code, tile_rsp_m, tile_rsp_n, tile_rsp_k} = tr_out;

  // ------------------------------------------------------------ context queue: AGU -> fetch sequencer -> slice assembler
  localparam int QW = (CTXQ_DEPTH > 1) ? $clog2(CTXQ_DEPTH) : 1;
  localparam int QC = $clog2(CTXQ_DEPTH + 1);
  logic [SETW-1:0]  cq_set   [CTXQ_DEPTH];
  logic [TAG_W-1:0] cq_tag   [CTXQ_DEPTH];
  logic [IDX_W-1:0] cq_m0    [CTXQ_DEPTH];
  logic [IDX_W-1:0] cq_n0    [CTXQ_DEPTH];
  logic [K_W-1:0]   cq_k0    [CTXQ_DEPTH];
  logic [RMW-1:0]   cq_em    [CTXQ_DEPTH];
  logic [CNW-1:0]   cq_en    [CTXQ_DEPTH];
  logic [K_W-1:0]   cq_ek    [CTXQ_DEPTH];
  logic [AWWA-1:0]  cq_aw    [CTXQ_DEPTH];
  logic [AWWA-1:0]  cq_asa   [CTXQ_DEPTH];
  logic [CW-1:0]    cq_anw   [CTXQ_DEPTH];
  logic [LEPW-1:0]  cq_aoff  [CTXQ_DEPTH];
  logic [AWWB-1:0]  cq_bw    [CTXQ_DEPTH];
  logic [AWWB-1:0]  cq_bsb   [CTXQ_DEPTH];
  logic [NWW-1:0]   cq_bnw   [CTXQ_DEPTH];
  logic [LEPW-1:0]  cq_boff  [CTXQ_DEPTH];
  logic [QW-1:0]    cq_wr, cq_fetch, cq_asm;
  logic [QC-1:0]    cq_cnt, cq_unf;           // entries not yet completed / not yet fetched
  logic             slice_done, fetch_go, a_ld_ready, b_ld_ready;

  wire push_ctx = res_valid & ~res_err;
  // room for one more descriptor, counting the push that is still in flight this cycle
  assign agu_room = ((QC+1)'(cq_cnt) + (QC+1)'(push_ctx) < (QC+1)'(CTXQ_DEPTH)) &&
                    (($clog2(TRSP_DEPTH+1)+1)'(tr_cnt) + ($clog2(TRSP_DEPTH+1)+1)'(res_valid) < ($clog2(TRSP_DEPTH+1)+1)'(TRSP_DEPTH));
  assign fetch_go = (cq_unf != '0) & a_ld_ready & b_ld_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cq_wr <= '0; cq_fetch <= '0; cq_asm <= '0; cq_cnt <= '0; cq_unf <= '0;
    end else begin
      if (push_ctx) begin
        cq_set[cq_wr] <= res_set; cq_tag[cq_wr] <= res_tag; cq_m0[cq_wr] <= res_m0; cq_n0[cq_wr] <= res_n0;
        cq_k0[cq_wr] <= res_k0; cq_em[cq_wr] <= res_eff_m; cq_en[cq_wr] <= res_eff_n; cq_ek[cq_wr] <= res_eff_k;
        cq_aw[cq_wr] <= res_a_word; cq_asa[cq_wr] <= res_a_sa; cq_anw[cq_wr] <= res_a_nwords; cq_aoff[cq_wr] <= res_a_off;
        cq_bw[cq_wr] <= res_b_word; cq_bsb[cq_wr] <= res_b_sb; cq_bnw[cq_wr] <= res_b_nw; cq_boff[cq_wr] <= res_b_off;
        cq_wr <= (cq_wr == QW'(CTXQ_DEPTH - 1)) ? '0 : cq_wr + 1'b1;
      end
      if (fetch_go) cq_fetch <= (cq_fetch == QW'(CTXQ_DEPTH - 1)) ? '0 : cq_fetch + 1'b1;
      if (slice_done) cq_asm <= (cq_asm == QW'(CTXQ_DEPTH - 1)) ? '0 : cq_asm + 1'b1;
      cq_cnt <= cq_cnt + QC'(push_ctx) - QC'(slice_done);
      cq_unf <= cq_unf + QC'(push_ctx) - QC'(fetch_go);
    end
  end

  // ------------------------------------------------------------ A and B buffers
  logic [R-1:0]       a_head_valid, a_pop;
  logic [R*DW-1:0]    a_head_data;
  logic [NWB-1:0]     b_head_valid, b_pop;
  logic [NWB*DW-1:0]  b_head_data;
  logic [7:0]         a_ev_rd, a_ev_stall, a_ev_conf, a_ev_blk, b_ev_rd, b_ev_stall, b_ev_conf, b_ev_blk;
  logic               a_ev_wst, a_ev_wfo, b_ev_wst, b_ev_wfo;

  sf_ts_abuf_ctrl #(.R(R), .WB(WB), .NB(NUM_A_BANKS), .NSETS(NSETS), .SPLIT(SET_MAP), .SET_WORDS(A_SET_WORDS),
                    .READ_LATENCY(READ_LATENCY), .STAGE(A_STAGE), .CW(CW), .BACKEND(BACKEND), .SIM_INIT(SIM_INIT),
                    .STARVE_LIMIT(WR_STARVE_LIMIT), .CHAIN(STREAM_CHAIN)) u_abuf (
    .clk(clk), .rst_n(rst_n), .ld_valid(fetch_go), .ld_ready(a_ld_ready), .ld_set(cq_set[cq_fetch]), .ld_base(cq_aw[cq_fetch]),
    .ld_sa(cq_asa[cq_fetch]), .ld_nwords(cq_anw[cq_fetch]), .ld_eff_m(cq_em[cq_fetch]),
    .head_valid(a_head_valid), .head_data(a_head_data), .pop(a_pop),
    .wr_valid(a_wr_valid), .wr_set(a_wr_set), .wr_addr(a_wr_addr), .wr_data(a_wr_data), .wr_be(a_wr_be), .wr_gnt(a_wr_gnt),
    .ev_rd_words(a_ev_rd), .ev_rd_stall(a_ev_stall), .ev_conflict(a_ev_conf), .ev_rd_wr_block(a_ev_blk),
    .ev_wr_stall(a_ev_wst), .ev_wr_forced(a_ev_wfo));

  sf_ts_bbuf_ctrl #(.NWB(NWB), .WB(WB), .NB(NUM_B_BANKS), .NSETS(NSETS), .SPLIT(SET_MAP), .SET_WORDS(B_SET_WORDS),
                    .READ_LATENCY(READ_LATENCY), .STAGE(B_STAGE), .CW(CW), .BACKEND(BACKEND), .SIM_INIT(SIM_INIT),
                    .STARVE_LIMIT(WR_STARVE_LIMIT), .CHAIN(STREAM_CHAIN)) u_bbuf (
    .clk(clk), .rst_n(rst_n), .ld_valid(fetch_go), .ld_ready(b_ld_ready), .ld_set(cq_set[cq_fetch]), .ld_base(cq_bw[cq_fetch]),
    .ld_sb(cq_bsb[cq_fetch]), .ld_rows(CW'(cq_ek[cq_fetch])), .ld_nw(cq_bnw[cq_fetch]),
    .head_valid(b_head_valid), .head_data(b_head_data), .pop(b_pop),
    .wr_valid(b_wr_valid), .wr_set(b_wr_set), .wr_addr(b_wr_addr), .wr_data(b_wr_data), .wr_be(b_wr_be), .wr_gnt(b_wr_gnt),
    .ev_rd_words(b_ev_rd), .ev_rd_stall(b_ev_stall), .ev_conflict(b_ev_conf), .ev_rd_wr_block(b_ev_blk),
    .ev_wr_stall(b_ev_wst), .ev_wr_forced(b_ev_wfo));

  // ------------------------------------------------------------ slice assembler
  logic ev_active, ev_slice, ev_starve, ev_starve_a, ev_starve_b, ev_bp;
  wire  ctx_v = (cq_cnt != '0);
  sf_ts_slice #(.R(R), .C(C), .OW(OW), .WB(WB), .NWB(NWB), .K_W(K_W), .IDX_W(IDX_W), .TAG_W(TAG_W), .SETW(SETW)) u_slice (
    .clk(clk), .rst_n(rst_n), .ctx_valid(ctx_v), .ctx_set(cq_set[cq_asm]), .ctx_tag(cq_tag[cq_asm]), .ctx_m0(cq_m0[cq_asm]),
    .ctx_n0(cq_n0[cq_asm]), .ctx_k0(cq_k0[cq_asm]), .ctx_eff_m(cq_em[cq_asm]), .ctx_eff_n(cq_en[cq_asm]), .ctx_eff_k(cq_ek[cq_asm]),
    .ctx_a_off(cq_aoff[cq_asm]), .ctx_b_off(cq_boff[cq_asm]), .ctx_b_nw(cq_bnw[cq_asm]), .ctx_done(slice_done),
    .a_head_valid(a_head_valid), .a_head_data(a_head_data), .a_pop(a_pop), .b_head_valid(b_head_valid), .b_head_data(b_head_data),
    .b_pop(b_pop), .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0),
    .s_row_mask(s_row_mask), .s_col_mask(s_col_mask), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .ev_active(ev_active), .ev_slice(ev_slice), .ev_starve(ev_starve), .ev_starve_a(ev_starve_a), .ev_starve_b(ev_starve_b),
    .ev_bp(ev_bp));

  assign engine_idle = ~agu_busy & ~res_valid & (cq_cnt == '0) & ~s_valid;
  assign busy        = ~engine_idle;

  // ------------------------------------------------------------ accumulator buffer
  logic ac_rd, ac_wr, ac_rd_deny, ac_wr_frz, ac_fwd, ac_ext_wait, ac_ext_ok, ac_ext_err, ac_viol;
  sf_ts_accbuf #(.ROWS(ARRAY_ROWS), .COLS(ARRAY_COLS), .ACC_W(ACC_WIDTH), .NUM_SLOTS(NUM_ACC_SLOTS), .NBA(NUM_ACC_BANKS),
                 .RD_LAT(ACC_RD_LAT), .WQ_DEPTH(ACC_WQ_DEPTH), .EXT_STARVE_LIMIT(ACC_EXT_STARVE_LIMIT), .AUTO_RELEASE(ACC_AUTO_RELEASE),
                 .BACKEND(BACKEND), .SIM_INIT(SIM_INIT)) u_acc (
    .clk(clk), .rst_n(rst_n),
    .st_en(acc_st_en), .st_rd_req(acc_st_rd_req), .st_rd_addr(acc_st_rd_addr), .st_rd_ready(acc_st_rd_ready),
    .st_rd_data(acc_st_rd_data), .st_wr_req(acc_st_wr_req), .st_wr_addr(acc_st_wr_addr), .st_wr_data(acc_st_wr_data),
    .st_wr_ready(acc_st_wr_ready),
    .claim_valid(acc_claim_valid), .claim_ready(acc_claim_ready), .claim_slot(acc_claim_slot),
    .complete_valid(acc_complete_valid), .complete_slot(acc_complete_slot), .release_valid(acc_release_valid),
    .release_slot(acc_release_slot), .slot_state(acc_slot_state),
    .ext_req_valid(ext_req_valid), .ext_req_ready(ext_req_ready), .ext_req_we(ext_req_we), .ext_req_slot(ext_req_slot),
    .ext_req_row(ext_req_row), .ext_req_wdata(ext_req_wdata), .ext_rsp_valid(ext_rsp_valid), .ext_rsp_ready(ext_rsp_ready),
    .ext_rsp_rdata(ext_rsp_rdata), .ext_rsp_we(ext_rsp_we), .ext_rsp_err(ext_rsp_err), .ext_rsp_code(ext_rsp_code),
    .viol_sticky_o(acc_viol_sticky),
    .ev_rd(ac_rd), .ev_wr(ac_wr), .ev_rd_deny(ac_rd_deny), .ev_wr_freeze(ac_wr_frz), .ev_fwd(ac_fwd), .ev_ext_wait(ac_ext_wait),
    .ev_ext_ok(ac_ext_ok), .ev_ext_err(ac_ext_err), .ev_viol(ac_viol));

  // ------------------------------------------------------------ events
  wire ev_wst = a_ev_wst | b_ev_wst;
  wire ev_wfo = a_ev_wfo | b_ev_wfo;
  wire ev_tile_ok = res_valid & ~res_err;
  wire ev_tile_err = res_valid & res_err;
  wire ev_ovl = ev_dma_issue & ev_slice;
  function automatic logic [EV_W-1:0] sat(input int v);
    sat = (v > (1 << EV_W) - 1) ? {EV_W{1'b1}} : EV_W'(v);
  endfunction
  always_comb begin
    ev_inc = '0;
    ev_inc[`TS_EV_CYCLES*EV_W        +: EV_W] = sat(1);
    ev_inc[`TS_EV_ACTIVE*EV_W        +: EV_W] = sat(32'(ev_active));
    ev_inc[`TS_EV_SLICES*EV_W        +: EV_W] = sat(32'(ev_slice));
    ev_inc[`TS_EV_STARVE*EV_W        +: EV_W] = sat(32'(ev_starve));
    ev_inc[`TS_EV_STARVE_A*EV_W      +: EV_W] = sat(32'(ev_starve_a));
    ev_inc[`TS_EV_STARVE_B*EV_W      +: EV_W] = sat(32'(ev_starve_b));
    ev_inc[`TS_EV_ARRAY_BP*EV_W      +: EV_W] = sat(32'(ev_bp));
    ev_inc[`TS_EV_A_RD_WORDS*EV_W    +: EV_W] = sat(32'(a_ev_rd));
    ev_inc[`TS_EV_B_RD_WORDS*EV_W    +: EV_W] = sat(32'(b_ev_rd));
    ev_inc[`TS_EV_A_RD_STALL*EV_W    +: EV_W] = sat(32'(a_ev_stall));
    ev_inc[`TS_EV_B_RD_STALL*EV_W    +: EV_W] = sat(32'(b_ev_stall));
    ev_inc[`TS_EV_A_BANK_CONF*EV_W   +: EV_W] = sat(32'(a_ev_conf));
    ev_inc[`TS_EV_B_BANK_CONF*EV_W   +: EV_W] = sat(32'(b_ev_conf));
    ev_inc[`TS_EV_RD_WR_BLOCK*EV_W   +: EV_W] = sat(32'(a_ev_blk) + 32'(b_ev_blk));
    ev_inc[`TS_EV_DMA_WR_STALL*EV_W  +: EV_W] = sat(32'(ev_wst));
    ev_inc[`TS_EV_DMA_WR_WORDS*EV_W  +: EV_W] = sat(32'(ev_dma_issue));
    ev_inc[`TS_EV_DMA_WR_FORCE*EV_W  +: EV_W] = sat(32'(ev_wfo));
    ev_inc[`TS_EV_DMA_ERR*EV_W       +: EV_W] = sat(32'(ev_dma_err));
    ev_inc[`TS_EV_TILE_OK*EV_W       +: EV_W] = sat(32'(ev_tile_ok));
    ev_inc[`TS_EV_TILE_ERR*EV_W      +: EV_W] = sat(32'(ev_tile_err));
    ev_inc[`TS_EV_OVERLAP*EV_W       +: EV_W] = sat(32'(ev_ovl));
    ev_inc[`TS_EV_ACC_RD*EV_W        +: EV_W] = sat(32'(ac_rd));
    ev_inc[`TS_EV_ACC_WR*EV_W        +: EV_W] = sat(32'(ac_wr));
    ev_inc[`TS_EV_ACC_RD_DENY*EV_W   +: EV_W] = sat(32'(ac_rd_deny));
    ev_inc[`TS_EV_ACC_WR_FRZ*EV_W    +: EV_W] = sat(32'(ac_wr_frz));
    ev_inc[`TS_EV_ACC_FWD*EV_W       +: EV_W] = sat(32'(ac_fwd));
    ev_inc[`TS_EV_ACC_EXT_WAIT*EV_W  +: EV_W] = sat(32'(ac_ext_wait));
    ev_inc[`TS_EV_ACC_EXT_OK*EV_W    +: EV_W] = sat(32'(ac_ext_ok));
    ev_inc[`TS_EV_ACC_EXT_ERR*EV_W   +: EV_W] = sat(32'(ac_ext_err));
    ev_inc[`TS_EV_ACC_VIOL*EV_W      +: EV_W] = sat(32'(ac_viol));
  end

  if (PERF_EN != 0) begin : g_perf
    sf_ts_perf #(.NEV(`TS_NUM_EV), .EV_W(EV_W), .CNT_W(CNT_W)) u_perf (
      .clk(clk), .rst_n(rst_n), .perf_clear(perf_clear), .ev_inc(ev_inc), .perf_cnt(perf_cnt));
  end else begin : g_noperf
    assign perf_cnt = '0;
  end

  // ------------------------------------------------------------ embedded checks (simulation / formal)
`ifdef SF_ASSERT
  always_ff @(posedge clk) if (rst_n) begin
    // a DMA write is never presented to a set that is not FILLING
    `SF_CHK(!((a_wr_valid || b_wr_valid) && (set_state[32'(a_wr_set)*2 +: 2] != `TS_SET_FILLING)),
            "sf_tensor_scratchpad: DMA write presented to a set that is not FILLING")
  end
`endif
  wire unused_ok = &{1'b0, fill_active, ev_fill_done_u, ev_cmp_begin_u, ev_cmp_done_u, tr_full};
endmodule

`default_nettype wire
