// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_perf
// Saturating event counters over the multi-event increment vector ev_inc (EV_W bits per event, TS_NUM_EV events).  The same
// ev_inc vector is exported by sf_tensor_scratchpad so the Module 07 counter bank (inc_i) can count it instead; these local
// counters exist so the benchmarks and testbenches need nothing else.  perf_clear is a synchronous clear.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_ts_perf #(
  parameter int NEV   = 30,
  parameter int EV_W  = 8,
  parameter int CNT_W = 32
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  perf_clear,
  input  wire logic [NEV*EV_W-1:0]   ev_inc,
  output logic      [NEV*CNT_W-1:0]  perf_cnt
);
  for (genvar e = 0; e < NEV; e++) begin : g_cnt
    logic [CNT_W-1:0] c;
    wire  [CNT_W:0]   sum = {1'b0, c} + (CNT_W+1)'(ev_inc[e*EV_W +: EV_W]);
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n)          c <= '0;
      else if (perf_clear) c <= '0;
      else                 c <= sum[CNT_W] ? {CNT_W{1'b1}} : sum[CNT_W-1:0];      // saturate, never wrap
    end
    assign perf_cnt[e*CNT_W +: CNT_W] = c;
  end
endmodule

`default_nettype wire
