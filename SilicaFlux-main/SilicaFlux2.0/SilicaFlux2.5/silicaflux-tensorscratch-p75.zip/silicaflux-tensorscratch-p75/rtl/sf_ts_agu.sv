// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_agu     (TENSOR ADDRESS GENERATOR / DESCRIPTOR VALIDATOR)
// Turns one tile descriptor into the validated parameters of one tile context, or an error code.  One descriptor at a time
// (S_IDLE -> S_CHK -> 4 multiply steps -> S_FIN -> S_OUT, 8 cycles, hidden by the context queue while the previous tile streams).
//
// ---------------------------------------------------------------- matrix contract (row-major, byte addressed)
//   A (mat_m x mat_k):  A[r][c] at  a_addr + r*lda + c*EB        B (mat_k x mat_n):  B[r][c] at  b_addr + r*ldb + c*EB
//   a_addr, b_addr are offsets inside ONE set's A / B region.  lda >= mat_k*EB, ldb >= mat_n*EB.
//   tile origin (m0, n0), reduction start k0, requested chunk tile_k:
//        eff_m = min(R, mat_m-m0)  eff_n = min(C, mat_n-n0)  eff_k = min(tile_k, mat_k-k0)        (boundary masks)
//        slice k (0 <= k < eff_k):  a[i] = A[m0+i][k0+k] (i < eff_m else 0),   b[j] = B[k0+k][n0+j] (j < eff_n else 0)
//
// ---------------------------------------------------------------- buffer-boundary protection
//   The LAST byte the tile touches is the largest address it touches (lda, ldb >= 0):
//        Alast = a_addr + (m0+eff_m-1)*lda + (k0+eff_k)*EB - 1        Blast = b_addr + (k0+eff_k-1)*ldb + (n0+eff_n)*EB - 1
//   Alast >= A_SET_BYTES (or Blast >= B_SET_BYTES) => the descriptor is rejected before any memory access.  Reads fetch whole
//   words, and a set is a whole number of words, so "last byte inside the set" bounds every word read.  All arithmetic is
//   ADDR_W + max(IDX_W,K_W) + 4 bits wide: no input combination can wrap it, so an overflow is detected, never silent.
//
// ---------------------------------------------------------------- result
//   Word-granular stream parameters for the A and B controllers:  first word, row pitch in words, words per lane, and the
//   byte offset of the first element inside its word (elements, i.e. the slice-selection start position).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_ts_defs.svh"
`default_nettype none

module sf_ts_agu #(
  parameter int R           = 4,
  parameter int C           = 4,
  parameter int EB          = 1,          // element bytes
  parameter int WB          = 4,          // word bytes
  parameter int TILE_K      = 32,
  parameter int A_SET_BYTES = 4096,
  parameter int B_SET_BYTES = 4096,
  parameter int NWB         = 2,          // max words per B row segment
  parameter int ADDR_W      = 32,
  parameter int IDX_W       = 16,
  parameter int K_W         = 17,
  parameter int TAG_W       = 8,
  parameter int SETW        = 1,
  // ---- derived
  parameter int LWB         = $clog2(WB),
  parameter int LEB         = (EB > 1) ? $clog2(EB) : 0,
  parameter int MAXW        = (IDX_W > K_W) ? IDX_W : K_W,
  parameter int PW          = ADDR_W + MAXW + 4,
  parameter int AWWA        = $clog2(A_SET_BYTES / WB),
  parameter int AWWB        = $clog2(B_SET_BYTES / WB),
  parameter int RMW         = $clog2(R + 1),
  parameter int CNW         = $clog2(C + 1),
  parameter int CW          = $clog2(TILE_K + 2),
  parameter int NWW         = $clog2(NWB + 1),
  parameter int EPW         = WB / EB,
  parameter int LEPW        = (EPW > 1) ? $clog2(EPW) : 1
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // descriptor
  input  wire logic                tile_valid,
  output logic                     tile_ready,
  input  wire logic                room_i,        // the context queue and the response FIFO can take one more entry
  input  wire logic                own_ok_i,      // some set is IN_USE
  input  wire logic [SETW-1:0]     own_set_i,
  input  wire logic [ADDR_W-1:0]   tile_a_addr,
  input  wire logic [ADDR_W-1:0]   tile_lda,
  input  wire logic [ADDR_W-1:0]   tile_b_addr,
  input  wire logic [ADDR_W-1:0]   tile_ldb,
  input  wire logic [IDX_W-1:0]    tile_m0,
  input  wire logic [IDX_W-1:0]    tile_n0,
  input  wire logic [K_W-1:0]      tile_k0,
  input  wire logic [IDX_W-1:0]    tile_mat_m,
  input  wire logic [IDX_W-1:0]    tile_mat_n,
  input  wire logic [K_W-1:0]      tile_mat_k,
  input  wire logic [K_W-1:0]      tile_k,
  input  wire logic [TAG_W-1:0]    tile_tag,
  // result (res_valid is a one-cycle pulse; the other outputs are valid with it)
  output logic                     busy_o,
  output logic                     res_valid,
  output logic                     res_err,
  output logic [3:0]               res_code,
  output logic [TAG_W-1:0]         res_tag,
  output logic [SETW-1:0]          res_set,
  output logic [IDX_W-1:0]         res_m0,
  output logic [IDX_W-1:0]         res_n0,
  output logic [K_W-1:0]           res_k0,
  output logic [RMW-1:0]           res_eff_m,
  output logic [CNW-1:0]           res_eff_n,
  output logic [K_W-1:0]           res_eff_k,
  output logic [AWWA-1:0]          res_a_word,
  output logic [AWWA-1:0]          res_a_sa,
  output logic [CW-1:0]            res_a_nwords,
  output logic [LEPW-1:0]          res_a_off,
  output logic [AWWB-1:0]          res_b_word,
  output logic [AWWB-1:0]          res_b_sb,
  output logic [NWW-1:0]           res_b_nw,
  output logic [LEPW-1:0]          res_b_off
);
  if ((WB & (WB - 1)) != 0 || WB < EB || EB < 1 || (EB & (EB - 1)) != 0) begin : g_err_w
    `SF_CFG_FATAL("sf_ts_agu: WORD_BYTES and ELEM_BYTES must be powers of two with ELEM_BYTES <= WORD_BYTES")
  end
  if (A_SET_BYTES < WB || B_SET_BYTES < WB || (A_SET_BYTES & (A_SET_BYTES - 1)) != 0 || (B_SET_BYTES & (B_SET_BYTES - 1)) != 0) begin : g_err_sz
    `SF_CFG_FATAL("sf_ts_agu: A_SET_BYTES / B_SET_BYTES must be powers of two >= WORD_BYTES")
  end

  localparam logic [3:0] S_IDLE = 4'd0, S_CHK = 4'd1, S_M0 = 4'd2, S_M1 = 4'd3, S_K0 = 4'd4, S_K1 = 4'd5, S_FIN = 4'd6, S_OUT = 4'd7;
  logic [3:0] state;

  // latched descriptor
  logic [ADDR_W-1:0] a_addr_q, lda_q, b_addr_q, ldb_q;
  logic [IDX_W-1:0]  m0_q, n0_q, matm_q, matn_q;
  logic [K_W-1:0]    k0_q, matk_q, tk_q;
  logic [TAG_W-1:0]  tag_q;
  logic [SETW-1:0]   set_q;
  logic [RMW-1:0]    em_q;
  logic [CNW-1:0]    en_q;
  logic [K_W-1:0]    ek_q;
  logic [PW-1:0]     p_a0, p_a1, p_b0, p_b1;
  logic [3:0]        code_q;

  assign tile_ready = (state == S_IDLE) & room_i;
  assign busy_o     = (state != S_IDLE);

  // ------------------------------------------------------------ S_CHK: cheap checks and effective sizes
  logic [3:0]      chk_code;
  logic [RMW-1:0]  chk_em;
  logic [CNW-1:0]  chk_en;
  logic [K_W-1:0]  chk_ek;
  always_comb begin
    chk_code = `TS_TERR_OK;
    if (!own_ok_i)                                                                            chk_code = `TS_TERR_OWNER;
    else if (tk_q == '0 || m0_q >= matm_q || n0_q >= matn_q || k0_q >= matk_q)               chk_code = `TS_TERR_EMPTY;
    else if ((PW'(lda_q) < (PW'(matk_q) << LEB)) || (PW'(ldb_q) < (PW'(matn_q) << LEB)))      chk_code = `TS_TERR_LD;
    else if (((a_addr_q | lda_q | b_addr_q | ldb_q) & ADDR_W'(WB - 1)) != '0)                 chk_code = `TS_TERR_ALIGN;
    else if (PW'(tk_q) > PW'(TILE_K))                                                         chk_code = `TS_TERR_K_RANGE;
    // effective sizes (only meaningful when the code is OK)
    chk_em = (PW'(matm_q) - PW'(m0_q) > PW'(R)) ? RMW'(R) : RMW'(matm_q - m0_q);
    chk_en = (PW'(matn_q) - PW'(n0_q) > PW'(C)) ? CNW'(C) : CNW'(matn_q - n0_q);
    chk_ek = (PW'(matk_q) - PW'(k0_q) > PW'(tk_q)) ? tk_q : (matk_q - k0_q);
  end

  // ------------------------------------------------------------ one shared multiplier, one product per step
  // operands: an index (<= MAXW+1 bits: m0 + eff_m - 1 etc.) times a pitch (ADDR_W bits); the product is exactly XW + ADDR_W bits wide, so the
  // multiplier is sized by its real operands, not by the wide address arithmetic below
  localparam int XW = MAXW + 1;
  logic [XW-1:0]          mul_x;
  logic [ADDR_W-1:0]      mul_y;
  logic [XW+ADDR_W-1:0]   mul_p;
  always_comb begin
    mul_x = '0; mul_y = '0;
    case (state)
      S_M0: begin mul_x = XW'(m0_q);                           mul_y = lda_q; end
      S_M1: begin mul_x = XW'(m0_q) + XW'(em_q) - XW'(1);      mul_y = lda_q; end
      S_K0: begin mul_x = XW'(k0_q);                           mul_y = ldb_q; end
      S_K1: begin mul_x = XW'(k0_q) + XW'(ek_q) - XW'(1);      mul_y = ldb_q; end
      default: ;
    endcase
    mul_p = mul_x * mul_y;
  end

  // ------------------------------------------------------------ S_FIN: addresses, range checks, stream parameters
  logic [PW-1:0] a0, alast, b0, blast;
  logic [3:0]    fin_code;
  always_comb begin
    a0    = PW'(a_addr_q) + p_a0 + (PW'(k0_q) << LEB);
    alast = PW'(a_addr_q) + p_a1 + ((PW'(k0_q) + PW'(ek_q)) << LEB) - PW'(1);
    b0    = PW'(b_addr_q) + p_b0 + (PW'(n0_q) << LEB);
    blast = PW'(b_addr_q) + p_b1 + ((PW'(n0_q) + PW'(en_q)) << LEB) - PW'(1);
    fin_code = `TS_TERR_OK;
    if (alast >= (PW'(1) << ADDR_W))               fin_code = `TS_TERR_A_OVF;
    else if (alast >= PW'(A_SET_BYTES))            fin_code = `TS_TERR_A_RANGE;
    else if (blast >= (PW'(1) << ADDR_W))          fin_code = `TS_TERR_B_OVF;
    else if (blast >= PW'(B_SET_BYTES))            fin_code = `TS_TERR_B_RANGE;
  end
  wire [LWB-1:0] a_offb = a0[LWB-1:0];
  wire [LWB-1:0] b_offb = b0[LWB-1:0];
  wire [PW-1:0]  nwa_f  = (PW'(a_offb) + (PW'(ek_q) << LEB) + PW'(WB) - PW'(1)) >> LWB;
  wire [PW-1:0]  nwb_f  = (PW'(b_offb) + (PW'(en_q) << LEB) + PW'(WB) - PW'(1)) >> LWB;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; res_valid <= 1'b0; res_err <= 1'b0; res_code <= '0; res_tag <= '0; res_set <= '0;
      res_m0 <= '0; res_n0 <= '0; res_k0 <= '0; res_eff_m <= '0; res_eff_n <= '0; res_eff_k <= '0;
      res_a_word <= '0; res_a_sa <= '0; res_a_nwords <= '0; res_a_off <= '0;
      res_b_word <= '0; res_b_sb <= '0; res_b_nw <= '0; res_b_off <= '0;
      a_addr_q <= '0; lda_q <= '0; b_addr_q <= '0; ldb_q <= '0; m0_q <= '0; n0_q <= '0; matm_q <= '0; matn_q <= '0;
      k0_q <= '0; matk_q <= '0; tk_q <= '0; tag_q <= '0; set_q <= '0; em_q <= '0; en_q <= '0; ek_q <= '0;
      p_a0 <= '0; p_a1 <= '0; p_b0 <= '0; p_b1 <= '0; code_q <= '0;
    end else begin
      res_valid <= 1'b0;
      case (state)
        S_IDLE: if (tile_valid & tile_ready) begin
          a_addr_q <= tile_a_addr; lda_q <= tile_lda; b_addr_q <= tile_b_addr; ldb_q <= tile_ldb;
          m0_q <= tile_m0; n0_q <= tile_n0; k0_q <= tile_k0; matm_q <= tile_mat_m; matn_q <= tile_mat_n;
          matk_q <= tile_mat_k; tk_q <= tile_k; tag_q <= tile_tag;
          state <= S_CHK;
        end
        S_CHK: begin
          code_q <= chk_code; set_q <= own_set_i; em_q <= chk_em; en_q <= chk_en; ek_q <= chk_ek;
          state  <= (chk_code != `TS_TERR_OK) ? S_OUT : S_M0;
        end
        S_M0: begin p_a0 <= PW'(mul_p); state <= S_M1; end
        S_M1: begin p_a1 <= PW'(mul_p); state <= S_K0; end
        S_K0: begin p_b0 <= PW'(mul_p); state <= S_K1; end
        S_K1: begin p_b1 <= PW'(mul_p); state <= S_FIN; end
        S_FIN: begin
          code_q <= fin_code;
          res_a_word <= AWWA'(a0 >> LWB); res_a_sa <= AWWA'(lda_q >> LWB); res_a_nwords <= CW'(nwa_f);
          res_a_off  <= LEPW'(a_offb >> LEB);
          res_b_word <= AWWB'(b0 >> LWB); res_b_sb <= AWWB'(ldb_q >> LWB); res_b_nw <= NWW'(nwb_f);
          res_b_off  <= LEPW'(b_offb >> LEB);
          state <= S_OUT;
        end
        S_OUT: begin
          res_valid <= 1'b1; res_code <= code_q; res_err <= (code_q != `TS_TERR_OK);
          res_tag <= tag_q; res_set <= set_q; res_m0 <= m0_q; res_n0 <= n0_q; res_k0 <= k0_q;
          if (code_q == `TS_TERR_OK) begin res_eff_m <= em_q; res_eff_n <= en_q; res_eff_k <= ek_q; end
          else begin res_eff_m <= '0; res_eff_n <= '0; res_eff_k <= '0; end
          state <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase
    end
  end
  wire unused_ok = &{1'b0, a0[PW-1:LWB], b0[PW-1:LWB], nwa_f[PW-1:CW], nwb_f[PW-1:NWW]};
endmodule

`default_nettype wire
