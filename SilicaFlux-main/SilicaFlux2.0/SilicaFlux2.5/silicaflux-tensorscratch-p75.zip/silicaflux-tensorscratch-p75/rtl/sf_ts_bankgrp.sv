// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_bankgrp
// The banked storage of ONE operand buffer (A or B) plus its bank arbitration.
//
// ---------------------------------------------------------------- legality (the point of this module)
//   Every physical bank is an sf_ts_bank = sf_sram_bank = ONE single-port SRAM: one access (read OR write) per cycle.
//   Operand bandwidth is obtained only by (a) several banks being read in the same cycle, (b) each read returning a
//   whole WORD (DW bits = WORD_BYTES operands) that the stream FIFOs then spend over several slices.  Nothing here ever
//   issues two accesses to one bank in one cycle: per bank the winner is picked among its read requesters (round robin)
//   and the DMA write (reads first, bounded wait for the write, see STARVE_LIMIT).
//
// ---------------------------------------------------------------- address map (word addressed, set = ping-pong half)
//   word w inside a set:  bank = w mod NB,   row = w / NB            (consecutive words rotate through the banks)
//   SPLIT = 1 (and NSETS = 2): set s has its own NB banks (group s): a DMA fill of one set and compute reads of the other
//                              never touch the same physical bank.
//   SPLIT = 0: both sets share the NB banks, the set is the MSB of the physical row; fill and compute contend (counted).
//
// ---------------------------------------------------------------- ports
//   rq_*  : NS read requesters (streams), all addressing set rq_set.  rq_gnt = served this cycle (request presented and won).
//   rp_*  : read data, READ_LATENCY cycles after the grant, back to the stream that asked (routed by the bank tag).
//   wr_*  : the single DMA write port (word write with byte enables).  wr_gnt = the bank accepted it this cycle.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_ts_bankgrp #(
  parameter int NS           = 4,
  parameter int NB           = 4,
  parameter int NSETS        = 1,
  parameter int SPLIT        = 0,
  parameter int SET_WORDS    = 1024,
  parameter int DW           = 32,
  parameter int READ_LATENCY = 1,
  parameter int BACKEND      = `SF_BACKEND_BEHAV,
  parameter int SIM_INIT     = 2,
  parameter int STARVE_LIMIT = 8,
  // ---- derived (do not override)
  parameter int AWW          = $clog2(SET_WORDS),
  parameter int SIDW         = (NS > 1) ? $clog2(NS) : 1,
  parameter int SETW         = (NSETS > 1) ? $clog2(NSETS) : 1,
  parameter int NG           = (SPLIT != 0 && NSETS > 1) ? NSETS : 1,
  parameter int NP           = NG * NB,
  parameter int ROWS_SET     = SET_WORDS / NB,
  parameter int DEPTH        = (NSETS > 1 && SPLIT == 0) ? NSETS * ROWS_SET : ROWS_SET,
  parameter int RW           = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int BE_W         = DW / 8,
  parameter int WCW          = $clog2(STARVE_LIMIT + 2)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // read requesters
  input  wire logic [NS-1:0]       rq_valid,
  input  wire logic [SETW-1:0]     rq_set,
  input  wire logic [NS*AWW-1:0]   rq_addr,
  output logic      [NS-1:0]       rq_gnt,
  output logic      [NS-1:0]       rp_valid,
  output logic      [NS*DW-1:0]    rp_data,
  // DMA write port
  input  wire logic                wr_valid,
  input  wire logic [SETW-1:0]     wr_set,
  input  wire logic [AWW-1:0]      wr_addr,
  input  wire logic [DW-1:0]       wr_data,
  input  wire logic [BE_W-1:0]     wr_be,
  output logic                     wr_gnt,
  // events (counts for this cycle)
  output logic [7:0]               ev_rd_words,      // reads granted
  output logic [7:0]               ev_conflict,      // banks with >= 2 read requesters
  output logic [7:0]               ev_rd_wr_block,   // read requesters that lost their bank to the DMA write
  output logic                     ev_wr_stall,      // a DMA write is waiting
  output logic                     ev_wr_forced      // the write won against at least one read (starvation limit)
);
  if (NB < 1 || (NB & (NB - 1)) != 0) begin : g_err_nb
    `SF_CFG_FATAL("sf_ts_bankgrp: NB must be a power of two")
  end
  if (SET_WORDS < 2 * NB || (SET_WORDS % NB) != 0) begin : g_err_sw
    `SF_CFG_FATAL("sf_ts_bankgrp: SET_WORDS must be a multiple of NB and at least 2*NB")
  end
  if (NSETS != 1 && NSETS != 2) begin : g_err_ns
    `SF_CFG_FATAL("sf_ts_bankgrp: NSETS must be 1 or 2")
  end
  if (DW < 8 || (DW % 8) != 0) begin : g_err_dw
    `SF_CFG_FATAL("sf_ts_bankgrp: DW must be a multiple of 8")
  end

  localparam int SET_ROW_BASE = (NSETS > 1 && SPLIT == 0) ? ROWS_SET : 0;

  // ------------------------------------------------------------ request decode (per stream, per write)
  logic [31:0] s_bank [NS];     // physical bank of stream s
  logic [31:0] s_row  [NS];     // physical row
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] w_bank, w_row;
  /* verilator lint_on UNUSEDSIGNAL */
  always_comb begin
    for (int s = 0; s < NS; s++) begin
      s_bank[s] = ((NG > 1) ? 32'(rq_set) * NB : 0) + (32'(rq_addr[s*AWW +: AWW]) % NB);
      s_row[s]  = ((SET_ROW_BASE != 0) ? 32'(rq_set) * ROWS_SET : 0) + (32'(rq_addr[s*AWW +: AWW]) / NB);
    end
    w_bank = ((NG > 1) ? 32'(wr_set) * NB : 0) + (32'(wr_addr) % NB);
    w_row  = ((SET_ROW_BASE != 0) ? 32'(wr_set) * ROWS_SET : 0) + (32'(wr_addr) / NB);
  end

  // ------------------------------------------------------------ DMA write starvation counter (one pending write at a time)
  logic [WCW-1:0] wwait_q;
  logic           wr_force;
  assign wr_force = (wwait_q >= WCW'(STARVE_LIMIT));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) wwait_q <= '0;
    else if (!wr_valid || wr_gnt) wwait_q <= '0;
    else if (wwait_q != WCW'(STARVE_LIMIT + 1)) wwait_q <= wwait_q + 1'b1;
  end

  // ------------------------------------------------------------ per-bank arbitration and banks
  logic [NP-1:0] b_wr_win, b_rd_win, b_wr_forced;
  logic [7:0]    b_conf [NP];
  logic [7:0]    b_blk  [NP];
  logic [NP*NS-1:0] rsp_route_v;                           // [p*NS + s]
  logic [DW-1:0]    rsp_route_d [NP*NS];
  logic [NS-1:0]    gnt_p [NP];

  for (genvar p = 0; p < NP; p++) begin : g_bank
    logic [NS-1:0]   cand;
    logic [SIDW-1:0] rr_q, win_id;
    logic            rd_any, wr_here;
    logic [NS-1:0]   hi_mask;                      // NS wide (a fixed 32-bit mask broke arbitration for more than 32 requesters)
    logic [NS-1:0]   hi;
    logic [7:0]      ncand;

    always_comb begin
      for (int s = 0; s < NS; s++) cand[s] = rq_valid[s] & (s_bank[s] == 32'(p));
      rd_any  = |cand;
      wr_here = wr_valid & (w_bank == 32'(p));
      hi_mask = {NS{1'b1}} << (32'(rr_q) + 32'd1);
      hi      = cand & hi_mask;
      win_id  = '0;
      for (int s = NS - 1; s >= 0; s--) if (cand[s]) begin win_id = SIDW'(s); end                  // lowest set bit overall
      for (int s = NS - 1; s >= 0; s--) if (hi[s])   begin win_id = SIDW'(s); end                  // lowest set bit above rr
      ncand = 8'd0;
      for (int s = 0; s < NS; s++) ncand = ncand + 8'(cand[s]);
    end
    assign b_wr_win[p]    = wr_here & (~rd_any | wr_force);
    assign b_wr_forced[p] = wr_here & rd_any & wr_force;
    assign b_rd_win[p]    = rd_any & ~b_wr_win[p];
    assign b_conf[p]      = (ncand >= 8'd2) ? 8'd1 : 8'd0;
    assign b_blk[p]       = (b_wr_win[p] ? ncand : 8'd0);
    always_comb begin
      gnt_p[p] = '0;
      if (b_rd_win[p]) gnt_p[p][win_id] = 1'b1;
    end
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) rr_q <= '0;
      else if (b_rd_win[p]) rr_q <= win_id;
    end

    // the bank itself
    logic            bq_valid, bq_we;
    logic [RW-1:0]   bq_row;
    logic [DW-1:0]   bq_wdata;
    logic [BE_W-1:0] bq_be;
    logic [SIDW-1:0] bq_tag;
    logic            bq_ready, br_valid, br_we;
    logic [DW-1:0]   br_data;
    logic [SIDW-1:0] br_tag;
    always_comb begin
      bq_valid = b_wr_win[p] | b_rd_win[p];
      bq_we    = b_wr_win[p];
      bq_row   = '0;
      if (b_wr_win[p]) bq_row = RW'(w_row);
      else             bq_row = RW'(s_row[win_id]);
      bq_wdata = wr_data;
      bq_be    = b_wr_win[p] ? wr_be : '0;
      bq_tag   = win_id;
    end
    sf_ts_bank #(.DEPTH(DEPTH), .DW(DW), .TAG_W(SIDW), .READ_LATENCY(READ_LATENCY), .BACKEND(BACKEND), .SIM_INIT(SIM_INIT)) u_bank (
      .clk(clk), .rst_n(rst_n), .req_valid(bq_valid), .req_we(bq_we), .req_row(bq_row), .req_wdata(bq_wdata), .req_be(bq_be),
      .req_tag(bq_tag), .req_ready(bq_ready), .rsp_valid(br_valid), .rsp_rdata(br_data), .rsp_tag(br_tag), .rsp_we(br_we));
    for (genvar s = 0; s < NS; s++) begin : g_route
      assign rsp_route_v[p*NS + s] = br_valid & ~br_we & (br_tag == SIDW'(s));
      assign rsp_route_d[p*NS + s] = rsp_route_v[p*NS + s] ? br_data : '0;
    end
`ifdef SF_ASSERT
    always_ff @(posedge clk) if (rst_n) begin
      `SF_CHK(!bq_valid || bq_ready, "sf_ts_bankgrp: a bank was not ready (ECC / init modes are not supported here)")
      `SF_CHK(!(b_wr_win[p] && b_rd_win[p]), "sf_ts_bankgrp: read and write granted to one bank in one cycle")
    end
`endif
    wire unused_p = &{1'b0, bq_ready};
  end

  // ------------------------------------------------------------ gather
  always_comb begin
    rq_gnt = '0;
    for (int p = 0; p < NP; p++) rq_gnt = rq_gnt | gnt_p[p];
    wr_gnt = |b_wr_win;
    rp_valid = '0; rp_data = '0;
    for (int s = 0; s < NS; s++)
      for (int p = 0; p < NP; p++) begin
        rp_valid[s]         = rp_valid[s] | rsp_route_v[p*NS + s];
        rp_data[s*DW +: DW] = rp_data[s*DW +: DW] | rsp_route_d[p*NS + s];
      end
    ev_rd_words = 8'd0; ev_conflict = 8'd0; ev_rd_wr_block = 8'd0; ev_wr_forced = 1'b0;
    for (int p = 0; p < NP; p++) begin
      ev_rd_words    = ev_rd_words + 8'(b_rd_win[p]);
      ev_conflict    = ev_conflict + b_conf[p];
      ev_rd_wr_block = ev_rd_wr_block + b_blk[p];
      ev_wr_forced   = ev_wr_forced | b_wr_forced[p];
    end
    ev_wr_stall = wr_valid & ~wr_gnt;
  end
endmodule

`default_nettype wire
