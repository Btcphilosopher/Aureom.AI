// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_defs.svh
// Constants of the tensor scratchpad (sf_tensor_scratchpad).  A `define header and not a package, for the same
// tool-portability reason as sf_sram_defs.svh (Yosys 0.33 cannot resolve package references in parameter lists;
// every synthesizable module must elaborate unaided in Verilator 5.020, Icarus 12 and Yosys 0.33).
// Values are part of the interface contract (docs/INTERFACES.md): never renumber, only append.
// =============================================================================
`ifndef SF_TS_DEFS_SVH
`define SF_TS_DEFS_SVH

`include "sf_sram_defs.svh"

// ------------------------------------------------------------ operand-set ownership (2 bits per set)
`define TS_SET_FREE    2'd0   // nobody owns it; a fill may begin
`define TS_SET_FILLING 2'd1   // owned by DMA: operand writes allowed, compute refused
`define TS_SET_READY   2'd2   // fully written and visible; waiting for compute
`define TS_SET_IN_USE  2'd3   // owned by compute: tiles may read, DMA writes refused

// ------------------------------------------------------------ DMA port response codes (3 bits)
// Same numbering as the TensorCore 03 operand buffer / Module 04 port, so the same DMA master can drive either.
`define TS_DERR_OK     3'd0
`define TS_DERR_RANGE  3'd1   // outside the A / B window (incl. the hole between them): no side effect
`define TS_DERR_ALIGN  3'd2   // byte address not word aligned: no side effect
`define TS_DERR_OWNER  3'd6   // target set is not FILLING: no side effect
`define TS_DERR_UNSUP  3'd7   // read request: the fill port is write-only: no side effect

// ------------------------------------------------------------ tile response codes (4 bits); first match wins
// 0..7 keep the TensorCore 03 numbering; 8 and 9 are new.
`define TS_TERR_OK      4'd0
`define TS_TERR_EMPTY   4'd1  // tile_k == 0, or tile origin outside the matrix (m0>=mat_m, n0>=mat_n, k0>=mat_k)
`define TS_TERR_LD      4'd2  // lda < mat_k*EB or ldb < mat_n*EB (rows would overlap)
`define TS_TERR_A_OVF   4'd3  // last A byte address >= 2^ADDR_W
`define TS_TERR_A_RANGE 4'd4  // last A byte address >= A_SET_BYTES (the tile would cross the buffer boundary)
`define TS_TERR_B_OVF   4'd5
`define TS_TERR_B_RANGE 4'd6
`define TS_TERR_OWNER   4'd7  // no set is IN_USE
`define TS_TERR_ALIGN   4'd8  // a_addr / lda / b_addr / ldb is not a multiple of WORD_BYTES
`define TS_TERR_K_RANGE 4'd9  // tile_k > TILE_K

// ------------------------------------------------------------ accumulator slot ownership (2 bits per slot)
`define TS_SLOT_FREE     2'd0 // storage content of the slot is dead; may be claimed
`define TS_SLOT_ACTIVE   2'd1 // claimed: the accumulator owns it (storage reads/writes legal)
`define TS_SLOT_COMPLETE 2'd2 // accumulator finished: content is the final tile; external reads legal; no writes

// ------------------------------------------------------------ external accumulator port response codes (3 bits)
`define TS_XERR_OK     3'd0
`define TS_XERR_RANGE  3'd1   // slot / row outside the buffer
`define TS_XERR_OWNER  3'd2   // slot is not in the state this operation needs (read: COMPLETE, write: FREE)

// ------------------------------------------------------------ event vector (ev_inc): EV_W bits per event, one field per event
// Every field is the number of events in that cycle (multi-event increments), directly usable as inc_i of the
// Module 07 counter bank.  Never renumber, only append.
`define TS_EV_CYCLES        0   // 1 every cycle
`define TS_EV_ACTIVE        1   // a tile is being delivered (the assembler holds a context)
`define TS_EV_SLICES        2   // k-slices delivered (s_valid && s_ready)
`define TS_EV_STARVE        3   // COMPUTE STARVATION: a tile is active, the output stage is free, operands are missing
`define TS_EV_STARVE_A      4   //   ... of which a live A lane had no staged word
`define TS_EV_STARVE_B      5   //   ... of which a live B stream had no staged word
`define TS_EV_ARRAY_BP      6   // s_valid && !s_ready (consumer back-pressure)
`define TS_EV_A_RD_WORDS    7   // A bank words read this cycle
`define TS_EV_B_RD_WORDS    8   // B bank words read this cycle
`define TS_EV_A_RD_STALL    9   // A-BUFFER STALL: A lane requests that were not granted
`define TS_EV_B_RD_STALL   10   // B-BUFFER STALL: B stream requests that were not granted
`define TS_EV_A_BANK_CONF  11   // BANK CONFLICT: A banks with >= 2 read requesters (one served, the rest wait)
`define TS_EV_B_BANK_CONF  12   // BANK CONFLICT: B banks with >= 2 read requesters
`define TS_EV_RD_WR_BLOCK  13   // read requesters blocked by a DMA write (1RW bank)
`define TS_EV_DMA_WR_STALL 14   // DMA CONFLICT: a legal DMA write waited for its bank this cycle
`define TS_EV_DMA_WR_WORDS 15   // DMA words written
`define TS_EV_DMA_WR_FORCE 16   // DMA writes that displaced a read (write-starvation limit reached)
`define TS_EV_DMA_ERR      17   // DMA error responses produced
`define TS_EV_TILE_OK      18   // tile descriptors accepted without error
`define TS_EV_TILE_ERR     19   // tile descriptors rejected
`define TS_EV_OVERLAP      20   // cycles in which a DMA word was written AND a slice was delivered
`define TS_EV_ACC_RD       21   // accumulator storage reads accepted
`define TS_EV_ACC_WR       22   // accumulator storage writes accepted
`define TS_EV_ACC_RD_DENY  23   // ACCUMULATOR STALL: st_rd_ready low (a starved external access was forced in)
`define TS_EV_ACC_WR_FRZ   24   // ACCUMULATOR STALL: st_wr_ready low (write buffer full: the drain could not keep up with the writes)
`define TS_EV_ACC_EXT_WAIT 25   // DMA/ext CONFLICT: an external accumulator access waited for a bank
`define TS_EV_ACC_EXT_OK   26   // external accumulator accesses completed
`define TS_EV_ACC_EXT_ERR  27   // external accumulator accesses rejected
`define TS_EV_ACC_VIOL     28   // accumulator protocol violations (illegal write blocked / illegal state transition)
`define TS_EV_ACC_FWD       29   // accumulator reads served from the write buffer (a pending write to the same entry)
`define TS_NUM_EV          30

`endif // SF_TS_DEFS_SVH
