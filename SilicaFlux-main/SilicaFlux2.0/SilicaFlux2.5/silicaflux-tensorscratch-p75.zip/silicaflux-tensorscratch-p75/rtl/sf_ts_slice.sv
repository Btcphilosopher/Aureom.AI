// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_slice     (SYSTOLIC DATA ALIGNMENT / k-SLICE ASSEMBLER)
// Builds the stream the implemented array consumes.  TENSORCORE 02 (output stationary, A east / B south) takes ONE k-slice per
// handshake:  s_a = A[:,k] (lane i = row i),  s_b = B[k,:] (lane j = column j)  and skews the lanes ITSELF (tensor_skew delays A
// lane i by 1+i and B lane j by 1+j registers) so that A[i][k] and B[k][j] meet at PE(i,j).  The scratchpad therefore delivers
// UNSKEWED, k-aligned slices and must never skew them again (that would pair A[i][k] with B[k+1][j]).
//
// ---------------------------------------------------------------- how alignment is guaranteed
//   * The A lanes and the B streams are fetched independently and arrive at different times (bank conflicts, DMA writes,
//     different word boundaries).  A slice is emitted ONLY when every live A lane AND every live B stream has the word that
//     holds its element for the SAME k (kcnt):  go = all heads valid & output register free.  Nothing is consumed otherwise.
//   * A lane i supplies element (a_off + kcnt) mod EPW of its head word and the head is popped after that word's last element
//     or after the tile's last slice; the B streams are popped on EVERY slice (one row of B per slice).  The pop pattern is a
//     pure function of kcnt, so the k each operand is taken for is the slice counter, never a FIFO position.
//   * each slice carries s_k (k inside the tile = the array's expected s_k), s_kg (global k), s_m0/s_n0 (matrix coordinates of
//     lane 0 / column 0), row/column masks (boundary tiles: dead lanes are forced to 0) and first/last flags.
//   * the output register holds all fields stable while s_ready is low (back-pressure safe).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_ts_defs.svh"
`default_nettype none

module sf_ts_slice #(
  parameter int R     = 4,
  parameter int C     = 4,
  parameter int OW    = 8,            // operand width in bits
  parameter int WB    = 4,
  parameter int NWB   = 2,
  parameter int K_W   = 17,
  parameter int IDX_W = 16,
  parameter int TAG_W = 8,
  parameter int SETW  = 1,
  // ---- derived
  parameter int EB    = OW / 8,
  parameter int DW    = 8 * WB,
  parameter int EPW   = WB / EB,
  parameter int LEPW  = (EPW > 1) ? $clog2(EPW) : 1,
  parameter int RMW   = $clog2(R + 1),
  parameter int CNW   = $clog2(C + 1),
  parameter int NWW   = $clog2(NWB + 1)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // tile context at the head of the assembly queue
  input  wire logic                ctx_valid,
  input  wire logic [SETW-1:0]     ctx_set,
  input  wire logic [TAG_W-1:0]    ctx_tag,
  input  wire logic [IDX_W-1:0]    ctx_m0,
  input  wire logic [IDX_W-1:0]    ctx_n0,
  input  wire logic [K_W-1:0]      ctx_k0,
  input  wire logic [RMW-1:0]      ctx_eff_m,
  input  wire logic [CNW-1:0]      ctx_eff_n,
  input  wire logic [K_W-1:0]      ctx_eff_k,
  input  wire logic [LEPW-1:0]     ctx_a_off,
  input  wire logic [LEPW-1:0]     ctx_b_off,
  input  wire logic [NWW-1:0]      ctx_b_nw,
  output logic                     ctx_done,       // last slice of the context accepted into the output register
  // staged words
  input  wire logic [R-1:0]        a_head_valid,
  input  wire logic [R*DW-1:0]     a_head_data,
  output logic      [R-1:0]        a_pop,
  input  wire logic [NWB-1:0]      b_head_valid,
  input  wire logic [NWB*DW-1:0]   b_head_data,
  output logic      [NWB-1:0]      b_pop,
  // k-slice stream (to tensor_systolic_array s_*)
  output logic                     s_valid,
  input  wire logic                s_ready,
  output logic      [R*OW-1:0]     s_a,
  output logic      [C*OW-1:0]     s_b,
  output logic      [K_W-1:0]      s_k,
  output logic      [K_W-1:0]      s_kg,
  output logic      [IDX_W-1:0]    s_m0,
  output logic      [IDX_W-1:0]    s_n0,
  output logic      [R-1:0]        s_row_mask,
  output logic      [C-1:0]        s_col_mask,
  output logic                     s_first,
  output logic                     s_last,
  output logic      [TAG_W-1:0]    s_tag,
  output logic      [SETW-1:0]     s_set,
  // events
  output logic                     ev_active,
  output logic                     ev_slice,
  output logic                     ev_starve,
  output logic                     ev_starve_a,
  output logic                     ev_starve_b,
  output logic                     ev_bp
);
  logic [K_W-1:0] kcnt_q;

  // ------------------------------------------------------------ readiness
  logic [R-1:0]   a_live;
  logic [NWB-1:0] b_live;
  always_comb begin
    for (int i = 0; i < R; i++)   a_live[i] = (i < 32'(ctx_eff_m));
    for (int j = 0; j < NWB; j++) b_live[j] = (j < 32'(ctx_b_nw));
  end
  wire a_ok      = &(a_head_valid | ~a_live);
  wire b_ok      = &(b_head_valid | ~b_live);
  wire slot_free = ~s_valid | s_ready;
  wire go        = ctx_valid & a_ok & b_ok & slot_free;
  wire last      = (kcnt_q + 1'b1 == ctx_eff_k);
  wire [LEPW-1:0] pos = LEPW'(ctx_a_off + kcnt_q[LEPW-1:0]) & LEPW'(EPW - 1);
  wire a_adv     = (pos == LEPW'(EPW - 1)) | last;       // the head word is exhausted after this slice

  assign a_pop    = {R{go & a_adv}} & a_live;
  assign b_pop    = {NWB{go}} & b_live;
  assign ctx_done = go & last;

  // ------------------------------------------------------------ operand selection
  logic [R*OW-1:0] a_sel;
  logic [C*OW-1:0] b_sel;
  logic [NWB*DW-1:0] b_row;
  logic [NWB*DW-1:0] b_shift;
  always_comb begin
    for (int i = 0; i < R; i++)
      a_sel[i*OW +: OW] = a_live[i] ? a_head_data[i*DW + 32'(pos) * OW +: OW] : '0;
    b_row   = b_head_data;
    b_shift = b_row >> (32'(ctx_b_off) * OW);
    for (int j = 0; j < C; j++)
      b_sel[j*OW +: OW] = (j < 32'(ctx_eff_n)) ? b_shift[j*OW +: OW] : '0;
  end

  logic [R-1:0] rmask;
  logic [C-1:0] cmask;
  always_comb begin
    for (int i = 0; i < R; i++) rmask[i] = (i < 32'(ctx_eff_m));
    for (int j = 0; j < C; j++) cmask[j] = (j < 32'(ctx_eff_n));
  end

  // ------------------------------------------------------------ output register
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s_valid <= 1'b0; s_a <= '0; s_b <= '0; s_k <= '0; s_kg <= '0; s_m0 <= '0; s_n0 <= '0;
      s_row_mask <= '0; s_col_mask <= '0; s_first <= 1'b0; s_last <= 1'b0; s_tag <= '0; s_set <= '0; kcnt_q <= '0;
    end else begin
      if (go) begin
        s_valid <= 1'b1; s_a <= a_sel; s_b <= b_sel; s_k <= kcnt_q; s_kg <= ctx_k0 + kcnt_q;
        s_m0 <= ctx_m0; s_n0 <= ctx_n0; s_row_mask <= rmask; s_col_mask <= cmask;
        s_first <= (kcnt_q == '0); s_last <= last; s_tag <= ctx_tag; s_set <= ctx_set;
        kcnt_q <= last ? '0 : kcnt_q + 1'b1;
      end else if (s_valid & s_ready) begin
        s_valid <= 1'b0;
      end
    end
  end

  assign ev_active   = ctx_valid;
  assign ev_slice    = s_valid & s_ready;
  assign ev_starve   = ctx_valid & slot_free & ~(a_ok & b_ok);
  assign ev_starve_a = ctx_valid & slot_free & ~a_ok;
  assign ev_starve_b = ctx_valid & slot_free & ~b_ok;
  assign ev_bp       = s_valid & ~s_ready;
endmodule

`default_nettype wire
