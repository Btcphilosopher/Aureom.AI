// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_bank
// One single-port (1RW) SRAM bank of the tensor scratchpad: a thin wrapper that instantiates the verified MemoryCore
// sf_sram_bank (ECC off, no init / scrub / MBIST / fault injection) and ties its maintenance ports off.
//   * one access per clock edge; a write is committed at the accepting edge, a read accepted at edge t returns its
//     data (rsp_valid / rsp_rdata / rsp_tag) READ_LATENCY cycles later (sf_sram_bank contract, docs/CONTRACT.md).
//   * req_ready is a function of registered state only; with ECC off and INIT_ON_RESET = 0 it is constant 1, so the
//     scratchpad arbiters never have to wait for a bank to become ready (checked by an assertion in the arbiter).
//   * the array is never reset: SIM_INIT = 2 shows a poison pattern for never-written rows in simulation, so a read of
//     unwritten data cannot silently look like valid operands.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`default_nettype none

module sf_ts_bank #(
  parameter int DEPTH        = 256,
  parameter int DW           = 32,
  parameter int TAG_W        = 3,
  parameter int READ_LATENCY = 1,
  parameter int BACKEND      = `SF_BACKEND_BEHAV,
  parameter int SIM_INIT     = 2,
  parameter int AW           = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int BE_W         = DW / 8
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              req_valid,
  input  wire logic              req_we,
  input  wire logic [AW-1:0]     req_row,
  input  wire logic [DW-1:0]     req_wdata,
  input  wire logic [BE_W-1:0]   req_be,
  input  wire logic [TAG_W-1:0]  req_tag,
  output logic                   req_ready,
  output logic                   rsp_valid,
  output logic [DW-1:0]          rsp_rdata,
  output logic [TAG_W-1:0]       rsp_tag,
  output logic                   rsp_we
);
  localparam int R_ECC   = $clog2(DW + $clog2(DW + 1) + 1);
  localparam int STORE_W = DW;                       // ECC_EN = 0
  localparam int FBW     = (STORE_W > 1) ? $clog2(STORE_W) : 1;

  logic        rsp_ce_unused, init_busy_unused, idle_unused, ev_ce_unused, ev_ue_unused;
  logic [2:0]  rsp_status_unused;
  logic [AW-1:0] ev_row_unused, first_ce_unused, first_ue_unused;
  logic [1:0]  ev_kind_unused;
  logic [15:0] ce_cnt_unused, ue_cnt_unused;
  logic [STORE_W-1:0] tst_rdata_unused;

  sf_sram_bank #(.DEPTH(DEPTH), .DW(DW), .READ_LATENCY(READ_LATENCY), .ECC_EN(0), .TAG_W(TAG_W), .INIT_ON_RESET(0),
                 .SIM_INIT(SIM_INIT), .FAULT_INJECT(0), .BACKEND(BACKEND), .SCRUB_EN(0)) u_bank (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_ready(req_ready), .req_we(req_we), .req_row(req_row), .req_wdata(req_wdata),
    .req_be(req_be), .req_tag(req_tag),
    .rsp_valid(rsp_valid), .rsp_rdata(rsp_rdata), .rsp_tag(rsp_tag), .rsp_we(rsp_we), .rsp_status(rsp_status_unused),
    .rsp_ce(rsp_ce_unused),
    .init_start_i(1'b0), .init_busy_o(init_busy_unused), .scrub_en_i(1'b0), .idle_o(idle_unused),
    .ev_ce_o(ev_ce_unused), .ev_ue_o(ev_ue_unused), .ev_row_o(ev_row_unused), .ev_kind_o(ev_kind_unused),
    .cnt_clr_i(1'b0), .ce_cnt_o(ce_cnt_unused), .ue_cnt_o(ue_cnt_unused), .first_ce_row_o(first_ce_unused),
    .first_ue_row_o(first_ue_unused),
    .tst_active_i(1'b0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i('0), .tst_wdata_i('0), .tst_rdata_o(tst_rdata_unused),
    .fi_type(4'd0), .fi_row('0), .fi_row2('0), .fi_bit({FBW{1'b0}}), .fi_bit2({FBW{1'b0}}), .fi_val(1'b0), .fi_val2(1'b0),
    .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));

  wire unused_ok = &{1'b0, rsp_ce_unused, init_busy_unused, idle_unused, ev_ce_unused, ev_ue_unused, rsp_status_unused,
                     ev_row_unused, first_ce_unused, first_ue_unused, ev_kind_unused, ce_cnt_unused, ue_cnt_unused,
                     tst_rdata_unused, R_ECC[0]};
endmodule

`default_nettype wire
