// =============================================================================
// SilicaFlux TensorScratch :: sf_ts_dbuf_ctrl     (DOUBLE-BUFFER / OPERAND-SET OWNERSHIP CONTROLLER)
// NSETS = 1: single buffering, the four phases are strictly sequential.   NSETS = 2: ping-pong, the DMA may fill one set
// while the array computes from the other.  Each set (one A tile region + one B tile region) is in exactly one state:
//
//      FREE --fill_begin--> FILLING --fill_end--> READY --cmp_begin--> IN_USE --cmp_end--> FREE
//
//   FREE    nobody owns it.            FILLING  DMA owns it: operand writes legal, compute reads refused.
//   READY   fully written, visible.    IN_USE   compute owns it: tiles may read, DMA writes refused (OWNER error).
//
// Sets are used in ring order (fill_ptr, cmp_ptr advance modulo NSETS), so tile order is preserved.  Commands are valid/ready; a
// command waits (ready low) while its precondition is false - it is never silently dropped.  The two hazard gates are inputs:
//   fill_quiet_i : no legal DMA write of the filling set is pending or being presented (refused requests do not count).  fill_end waits for it, so READY implies every
//                  accepted write has been performed in the banks (a write is committed at its accepting edge).
//   cmp_idle_i   : no tile of the computing set is queued, being addressed, being fetched or waiting in the output register.
//                  cmp_end waits for it, so a set can never be released (and then overwritten) while a read of it is outstanding.
// At most one set is FILLING and at most one is IN_USE at a time.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_ts_defs.svh"
`default_nettype none

module sf_ts_dbuf_ctrl #(
  parameter int NSETS = 2,
  parameter int SETW  = (NSETS > 1) ? $clog2(NSETS) : 1
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                fill_begin_valid,
  output logic                     fill_begin_ready,
  input  wire logic                fill_end_valid,
  output logic                     fill_end_ready,
  input  wire logic                cmp_begin_valid,
  output logic                     cmp_begin_ready,
  input  wire logic                cmp_end_valid,
  output logic                     cmp_end_ready,
  input  wire logic                fill_quiet_i,
  input  wire logic                cmp_idle_i,
  output logic      [SETW-1:0]     fill_set,
  output logic      [SETW-1:0]     cmp_set,
  output logic                     fill_active,
  output logic                     cmp_active,
  output logic      [NSETS*2-1:0]  set_state,
  output logic                     ev_fill_done,     // pulses
  output logic                     ev_cmp_begin,
  output logic                     ev_cmp_done
);
  if (NSETS != 1 && NSETS != 2) begin : g_err_ns
    `SF_CFG_FATAL("sf_ts_dbuf_ctrl: NSETS must be 1 (single buffer) or 2 (ping-pong)")
  end
  logic [1:0]      st [NSETS];
  logic [SETW-1:0] fill_ptr, cmp_ptr;

  assign fill_begin_ready = ~fill_active & (st[fill_ptr] == `TS_SET_FREE);
  assign fill_end_ready   = fill_active & fill_quiet_i;
  assign cmp_begin_ready  = ~cmp_active & (st[cmp_ptr] == `TS_SET_READY);
  assign cmp_end_ready    = cmp_active & cmp_idle_i;
  always_comb for (int i = 0; i < NSETS; i++) set_state[i*2 +: 2] = st[i];

  wire do_fb = fill_begin_valid & fill_begin_ready;
  wire do_fe = fill_end_valid   & fill_end_ready;
  wire do_cb = cmp_begin_valid  & cmp_begin_ready;
  wire do_ce = cmp_end_valid    & cmp_end_ready;
  wire [SETW-1:0] last_set = SETW'(NSETS - 1);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NSETS; i++) st[i] <= `TS_SET_FREE;
      fill_ptr <= '0; cmp_ptr <= '0; fill_set <= '0; cmp_set <= '0; fill_active <= 1'b0; cmp_active <= 1'b0;
      ev_fill_done <= 1'b0; ev_cmp_begin <= 1'b0; ev_cmp_done <= 1'b0;
    end else begin
      ev_fill_done <= do_fe; ev_cmp_begin <= do_cb; ev_cmp_done <= do_ce;
      if (do_fb) begin st[fill_ptr] <= `TS_SET_FILLING; fill_active <= 1'b1; fill_set <= fill_ptr; end
      if (do_fe) begin
        st[fill_set] <= `TS_SET_READY; fill_active <= 1'b0;
        fill_ptr <= (fill_ptr == last_set) ? '0 : fill_ptr + 1'b1;
      end
      if (do_cb) begin st[cmp_ptr] <= `TS_SET_IN_USE; cmp_active <= 1'b1; cmp_set <= cmp_ptr; end
      if (do_ce) begin
        st[cmp_set] <= `TS_SET_FREE; cmp_active <= 1'b0;
        cmp_ptr <= (cmp_ptr == last_set) ? '0 : cmp_ptr + 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
