# SilicaFlux TensorScratch — high-bandwidth tensor SRAM subsystem (Project 75)

Aureom.AI | SilicaFlux TensorCore.  Primary RTL: **`rtl/sf_tensor_scratchpad.sv`**.  SystemVerilog + Python tooling, verified with Verilator / Icarus, synthesized (generic gates) with Yosys.

> **Read first.**  Every number in this package is an **RTL-simulation** result, a Yosys **generic-gate** count, or a Python-model result.  There is no silicon, FPGA, timing, area or power data and no formal proof (`docs/KNOWN_LIMITATIONS.md`).
> A *different* module also named `sf_tensor_scratchpad` already exists in the MemoryCore pack; this one is new and the two must not be compiled together (L1).  This package is **a ZIP; nothing was committed to git**.

## What it is

A scratchpad for the SilicaFlux 4 x 4 INT8 output-stationary systolic array: A and B operand buffers, an accumulator buffer, a DMA fill port, ping-pong ownership, tile address generation and k-slice delivery, on **single-port SRAM banks**
(the verified MemoryCore `sf_sram_bank`).  It delivers the array's real operand interface (TENSORCORE 02 `s_*`: 4 A + 4 B operands per cycle = **8 INT8 operands per cycle**) and implements the real accumulator storage interface (TENSORCORE 04 `st_*`).

* **Operand bandwidth without multi-port assumptions.**  Each bank read returns a 32-bit word; an A lane spends it over four slices, B reads one word (two when a row straddles a word) per slice from separate bank groups; a bank never gets more than one access per cycle (`docs/ARCHITECTURE.md` section 1).
* **Aligned delivery.**  A slice is emitted only when every live A lane and B stream holds the word for the *same* `k`; boundary tiles zero the dead lanes; slices carry `s_k, s_kg, s_m0, s_n0`, masks, first / last, and stay stable under back-pressure.  (The array skews internally, so slices are un-skewed.)
* **No duplicated accumulation.**  The accumulator buffer is the backing store of TENSORCORE 04's storage interface, **not** an adder: that engine already adds each K chunk exactly once.
* **Ping-pong with enforced ownership** (FREE / FILLING / READY / IN_USE); writes into a set that is in use are refused and counted, also while it streams.
* **Everything that loses cycles is an event**: compute starvation, A / B stalls, bank conflicts, DMA conflicts, accumulator stalls (`ev_inc`, Module 07 style).

## Results at a glance (generated; `docs/VERIFICATION.md`, `docs/BANDWIDTH.md`, `reports/`)

| item | result |
|---|---|
| sustained operand rate, 4 x 4 INT8, conflict-free layout | **8.000 operands/cycle** (1.0000 slice/cycle, 32 back-to-back tiles, data-checked) |
| same, pitch that makes all four A lanes request the same bank at their first word | 1.0000 slice/cycle with `B_STAGE` = 8 (lower with shallower staging, `docs/BANDWIDTH.md`) |
| system runs through the real TENSORCORE 02 + 04, 28 configurations | **503 / 503** pass; 2183 GEMM problems, 144,348 C elements equal to `numpy` int64 matmul |
| lint / unit / directed | 31 / 31 lint checks; 18 / 18 unit tests; 463 directed error / boundary / ownership checks |
| accumulator buffer vs TENSORCORE 04 reference storage | bit-exact lock-step, 12 configurations, 1,622,652 checks |
| bandwidth benchmark | 125 rows, 0 data errors, 0 analytical-bound violations |
| synthesis (Yosys generic gates, no PDK / timing) | baseline 4 x 4: 3,592 flip-flops, 33,081 logic cells, 139,232 SRAM-bank bits; integrated with TC02 + TC04: 10,806 flip-flops, 85,458 logic cells; `check -assert` clean (20 / 20), 0 latches |

## Deliverables (brief section 11)

| deliverable | where |
|---|---|
| `sf_tensor_scratchpad.sv` | `rtl/sf_tensor_scratchpad.sv` |
| A / B buffer controllers | `rtl/sf_ts_abuf_ctrl.sv`, `rtl/sf_ts_bbuf_ctrl.sv` (+ `sf_ts_stream.sv`, `sf_ts_bankgrp.sv`, `sf_ts_bank.sv`) |
| Tensor address generators | `rtl/sf_ts_agu.sv` (descriptor validation, boundary protection), stream address generation in `sf_ts_stream.sv` |
| Accumulator storage interface | `rtl/sf_ts_accbuf.sv` |
| Double-buffer controller | `rtl/sf_ts_dbuf_ctrl.sv` (+ ownership checks in `rtl/sf_ts_dma_port.sv`) |
| Slice assembly (alignment) | `rtl/sf_ts_slice.sv` |
| Reference integration with TENSORCORE 02 + 04 | `integration/ts_tc_system.sv` |
| Self-checking tests | `tb/tb_ts_system.sv`, `tb_ts_errors.sv`, `tb_ts_acc.sv`, `tb_ts_smoke.sv`; `model/check_dump.py` (numpy) |
| Bandwidth benchmark | `tb/tb_ts_bench.sv`, `scripts/run_bench.py`, `model/bw_model.py`, `reports/bandwidth.*`, `docs/BANDWIDTH.md` |
| Synthesis report | `reports/synthesis.md`, `docs/SYNTHESIS.md`, `scripts/run_synth.py` |

## Quick start

```bash
make smoke                # one 4x4 tile (seconds)             make errors   # error / boundary / ownership tests
make system               # GEMM stress through TC02 + TC04 + numpy check
make quick                # 10 configurations                  make regress  # everything (5 min 6 s on 4 cores, final run)
make bench synth          # bandwidth sweep, synthesis report  make third_party  # reused files still byte-identical?
```

Tools: Verilator 5.020, Icarus Verilog 12, Yosys 0.33, Python 3 with numpy.  Build products go to `build/` (safe to delete); `reports/` holds the committed results.  `make regress bench synth` regenerates the reports; `python3 scripts/fill_docs.py` regenerates the generated tables in the docs.

## Layout

| path | content |
|---|---|
| `rtl/` | the new RTL (`sf_ts_*.sv`, `sf_tensor_scratchpad.sv`, `sf_ts_defs.svh`) |
| `integration/` | `ts_tc_system.sv`: scratchpad + TENSORCORE 02 array + TENSORCORE 04 accumulator |
| `third_party/` | reused SilicaFlux code, **byte-identical**, SHA-256 manifest and provenance (MemoryCore `sf_sram_*`, TENSORCORE 02 / 04) |
| `tb/`, `model/`, `scripts/`, `sim/`, `syn/` | testbenches, numpy checker + bandwidth model, drivers, file lists, Yosys read script |
| `docs/` | `AUDIT`, `ARCHITECTURE`, `INTERFACES`, `VERIFICATION`, `BANDWIDTH`, `SYNTHESIS`, `KNOWN_LIMITATIONS` |
| `reports/` | JSON / Markdown / CSV results of the final runs |

## Definition of done — status

| requirement (brief) | status |
|---|---|
| supplies the required operand streams (4 A + 4 B per cycle) from legal single-port banking | **done, measured**: 8.000 operands/cycle (rate 1.0000 slice/cycle) sustained over 32 back-to-back tiles for a conflict-free layout; 1.0000 slice/cycle even when all four A lanes share one bank (`B_STAGE` = 8) |
| preserves accumulator data during verified tensor workloads | **done, verified**: committed rows and external read-back compared with an independent GEMM; lock-step equal to TENSORCORE 04's own storage |
| accurately reports bank conflicts and starvation | **done, measured**: events checked against the analytical bound and the benchmark's expectations; see `docs/BANDWIDTH.md` for what each counter means (and does not) |
| start with one tile, then tiling, then double buffering | followed in that order (`tb_ts_smoke` -> `tb_ts_system` blocks / chunks -> ping-pong) |
| **not done / not claimed** | silicon / FPGA / timing / area / power; formal proofs; TENSORCORE 06 / 07 and Module 07 in the loop; unaligned pitches; ECC and non-behavioural SRAM backends; K beyond the hundreds simulated here |

Provenance and reuse: `docs/AUDIT.md` (what exists in the repository, including TENSORCORE 03, which already covers much of the operand-buffer scope and is **not** replaced or compared against), `third_party/PROVENANCE.md`.
