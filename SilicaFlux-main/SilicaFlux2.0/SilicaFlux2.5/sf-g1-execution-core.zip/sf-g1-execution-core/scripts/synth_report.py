#!/usr/bin/env python3
"""Build results/synth/SUMMARY.md from the tool logs written by synth.sh. Every number is parsed
from a log produced by an actual Yosys / nextpnr run; nothing is computed or estimated here."""
import glob
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
D = os.path.join(ROOT, "results", "synth")


def parse_stat(path):
    """Return {module: {cell: count}} from a Yosys `stat` dump."""
    mods, cur, in_cells = {}, None, False
    for line in open(path):
        m = re.match(r"=== (\S+) ===", line.strip())
        if m:
            cur = m.group(1); mods[cur] = {}; in_cells = False; continue
        if cur is None:
            continue
        m = re.match(r"\s+(\d+)\s+cells\s*$", line)
        if m:
            in_cells = True; continue
        m = re.match(r"\s+(\d+)\s+(\S+)\s*$", line)
        if in_cells and m and not line.strip().startswith(("wires", "wire", "public", "ports", "port")):
            mods[cur][m.group(2)] = int(m.group(1))
    return mods


def pnr(path):
    txt = open(path).read()
    fm = re.findall(r"Max frequency for clock\s+'[^']*':\s+([\d.]+) MHz", txt)
    util = {}
    blocks = txt.split("Device utilisation:")
    if len(blocks) > 1:
        for l in blocks[-1].splitlines()[:16]:
            m = re.match(r"Info:\s+(\S+):\s+(\d+)/\s*(\d+)\s+(\d+)%", l)
            if m:
                util[m.group(1)] = (int(m.group(2)), int(m.group(3)))
    return (float(fm[-1]) if fm else None), (float(fm[0]) if fm else None), util


def tot(c, keys):
    return sum(v for k, v in c.items() if any(k == x or k.startswith(x) for x in keys))


out = ["# Synthesis results (measured)\n",
       "Produced by `scripts/synth.sh` with Yosys 0.71 (slang frontend) and nextpnr-ecp5 0.11 (YoWASP builds).",
       "Counts are mapped-cell counts straight from Yosys `stat`; Fmax figures are nextpnr post-route numbers.",
       "No Vivado/Quartus run was performed, so there is **no Xilinx or Intel timing** here.\n"]

xc = sorted(glob.glob(os.path.join(D, "xc7_L*_D*.stat.txt")))
flat = [p for p in xc if "_hier" not in p]
if flat:
    out += ["## Xilinx 7-series mapping (`synth_xilinx -family xc7`, utilisation only)\n",
            "| LANES | RF style | LUT (all) | of which LUT6 | FF | RAM32M (LUTRAM) | RAMB18/36 | DSP48E1 | CARRY4 |", "|---|---|---|---|---|---|---|---|---|"]
    for p in sorted(flat, key=lambda p: (int(re.search(r"_B(\d)", p).group(1)), int(re.search(r"_L(\d+)_", p).group(1)))):
        c = list(parse_stat(p).values())[0]
        lanes = re.search(r"_L(\d+)_", p).group(1); bram = re.search(r"_B(\d)", p).group(1)
        out.append(f"| {lanes} | {'block RAM' if bram == '1' else 'distributed (LUTRAM)'} | {tot(c, ['LUT'])} | {c.get('LUT6', 0)} | {tot(c, ['FDRE', 'FDSE', 'FDCE', 'FDPE'])} | "
                   f"{c.get('RAM32M', 0) + c.get('RAM32X1D', 0) + c.get('RAM32X1S', 0)} | {c.get('RAMB18E1', 0)}/{c.get('RAMB36E1', 0)} | {c.get('DSP48E1', 0)} | {c.get('CARRY4', 0)} |")
    out.append("")

mods = sorted(glob.glob(os.path.join(D, "xc7_mod_*.stat.txt")))
if mods:
    out += ["## Per-block breakdown, Xilinx 7-series (each block synthesised standalone as its own top)\n",
            "The slang frontend flattens the hierarchy, so blocks are measured separately; standalone numbers can differ slightly",
            "from the same block inside the full core (cross-boundary optimisation). `regfile` is for LANES=4 and already contains the",
            "per-lane RAMs, bypass registers and predicate file; `lane` is ONE lane (operand mux, X regs, ALU, multiplier, product reg, W reg);",
            "`fifo` is the 44-bit-wide, depth-2 input buffer (32 insn + 4 mask + 8 tag).\n",
            "| block | LUT | FF | RAM32M | DSP48E1 | CARRY4 |", "|---|---|---|---|---|---|"]
    rows = {}
    for p in mods:
        c = list(parse_stat(p).values())[0]
        name = re.search(r"xc7_mod_(.+)\.stat", p).group(1)
        rows[name] = c
        out.append(f"| {name} | {tot(c, ['LUT'])} | {tot(c, ['FDRE', 'FDSE', 'FDCE', 'FDPE'])} | {c.get('RAM32M', 0)} | {c.get('DSP48E1', 0)} | {c.get('CARRY4', 0)} |")
    full = [p for p in flat if "_L4_B0_" in p]
    if full and {"lane", "regfile_L4", "scoreboard", "decode", "fifo_44b_d2"} <= set(rows):
        t = list(parse_stat(full[0]).values())[0]
        sum_lut = 4 * tot(rows["lane"], ["LUT"]) + sum(tot(rows[k], ["LUT"]) for k in ("regfile_L4", "scoreboard", "decode", "fifo_44b_d2"))
        sum_ff = 4 * tot(rows["lane"], ["FDRE", "FDSE"]) + sum(tot(rows[k], ["FDRE", "FDSE"]) for k in ("regfile_L4", "scoreboard", "decode", "fifo_44b_d2"))
        out += ["", f"LANES=4 core total: {tot(t, ['LUT'])} LUT / {tot(t, ['FDRE', 'FDSE'])} FF. 4 x lane + regfile + scoreboard + decode + fifo = {sum_lut} LUT / {sum_ff} FF;",
                f"the remainder ({tot(t, ['LUT']) - sum_lut} LUT / {tot(t, ['FDRE', 'FDSE']) - sum_ff} FF; negative = cross-boundary optimisation) is the core's pipeline control, O/X/M/W control registers and result-channel logic.", ""]

ec = sorted(glob.glob(os.path.join(D, "ecp5_L*_D*.stat.txt")))
ec = [p for p in ec if "_hier" not in p]
if ec:
    out += ["## Lattice ECP5 (LFE5U-85F-6, CABGA381): Yosys mapping and nextpnr place & route\n",
            "| LANES | LUT4 | FF | TRELLIS_DPR16X4 | DP16KD | MULT18X18D | CCU2C | post-route Fmax (MHz, clk) | target | I/O pins used |", "|---|---|---|---|---|---|---|---|---|---|"]
    for p in sorted(ec, key=lambda p: int(re.search(r"_L(\d+)_", p).group(1))):
        c = list(parse_stat(p).values())[0]
        lanes = re.search(r"_L(\d+)_", p).group(1)
        lg = p.replace(".stat.txt", ".pnr.log")
        fm, est, util = (pnr(lg) if os.path.exists(lg) else (None, None, {}))
        io = util.get("TRELLIS_IO")
        out.append(f"| {lanes} | {c.get('LUT4', 0)} | {c.get('TRELLIS_FF', 0)} | {c.get('TRELLIS_DPR16X4', 0)} | {c.get('DP16KD', 0)} | {c.get('MULT18X18D', 0)} | {c.get('CCU2C', 0)} | "
                   f"{('%.1f' % fm) if fm else 'not run (I/O pins exceed device)'} | {('100 MHz req.' if fm else '-')} | {('%d/%d' % io) if io else '-'} |")
    out.append("")
crit = []
for lg in sorted(glob.glob(os.path.join(D, "ecp5_L*_B0_D2.pnr.log"))):
    txt = open(lg).read()
    blocks = txt.split("Critical path report for clock")
    if len(blocks) < 2:
        continue
    blk = blocks[-1].split("Critical path report for cross-domain")[0]
    # the post-route report is the last one for the clock domain; first and last cell on the path
    src = re.findall(r"Source (\S+)", blk)
    tot_ns = re.findall(r"\s+(\d+\.\d+)\s+(\d+\.\d+) Source", blk)
    lanes = re.search(r"_L(\d+)_", lg).group(1)
    if src and tot_ns:
        crit.append(f"- LANES={lanes}: from `{src[0][:70]}` to `{src[-1][:70]}` ({tot_ns[-1][1]} ns total, {len(src)} cells)")
if crit:
    out += ["### Post-route critical path (nextpnr, clk domain) -- what limits the ECP5 Fmax", ""] + crit + [""]
open(os.path.join(D, "SUMMARY.md"), "w").write("\n".join(out) + "\n")
print("\n".join(out))
