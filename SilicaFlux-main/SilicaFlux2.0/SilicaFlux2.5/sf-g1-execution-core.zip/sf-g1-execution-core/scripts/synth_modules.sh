#!/usr/bin/env bash
# Standalone Xilinx-7-series synthesis of each sub-module (per-module resource breakdown).
# The slang frontend flattens the hierarchy, so each block is synthesised as its own top.
# "core control" in the report = full-core total minus the sum of these blocks.
set -euo pipefail
YOSYS=${YOSYS:-yowasp-yosys}
cd "$(dirname "$0")/.."
OUT=results/synth; mkdir -p "$OUT"
FILES=$(sed 's#^#rtl/#' rtl/filelist.f | tr '\n' ' ')
run() {  # name  top  params...
  local name=$1 top=$2; shift 2
  $YOSYS -l "$OUT/xc7_mod_$name.log" -p "read_slang -j 1 --top $top $* $FILES; synth_xilinx -family xc7 -top $top -noiopad -flatten; tee -o $OUT/xc7_mod_$name.stat.txt stat" > /dev/null
  echo "wrote $OUT/xc7_mod_$name.stat.txt"
}
run lane        sfg1_lane
run regfile_L4  sfg1_regfile    -G LANES=4 -G USE_BRAM=1\'b0
run scoreboard  sfg1_scoreboard
run decode      sfg1_decode
run fifo_44b_d2 sfg1_fifo       -G W=44 -G DEPTH=2
