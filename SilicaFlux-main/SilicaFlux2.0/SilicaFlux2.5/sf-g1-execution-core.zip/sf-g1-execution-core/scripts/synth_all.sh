#!/usr/bin/env bash
# Run the full synthesis matrix reported in results/synth/SUMMARY.md (takes a few minutes).
set -euo pipefail
cd "$(dirname "$0")"
for L in 1 2 4 8 16; do ./synth.sh xc7 $L 0 2 1; done          # Xilinx 7-series, LUTRAM register file
./synth.sh xc7 4 1 2 1                                          # same, block-RAM register file
./synth_modules.sh                                              # per-module breakdown (each block as its own top)
for L in 1 2 4; do ./synth.sh ecp5 $L 0 2 1 1 100; done         # ECP5 + place & route (fits the I/O budget)
for L in 8 16; do ./synth.sh ecp5 $L 0 2 1 0; done              # ECP5 mapping only
python3 ./synth_report.py
