#!/usr/bin/env python3
"""Mutation campaign: prove the verification environment can actually catch bugs.

Each mutation is a single textual change to the RTL (a plausible design error).  For every one
we build the directed and differential simulators from the mutated copy, run them, and report
which layer noticed: SVA assertion, directed-TB check, SV reference model, or the Python
comparator.  A mutation nobody notices is a SURVIVOR and must be explained (equivalent
mutant) or fixed (test gap).

    python3 scripts/mutate.py [--only M03 M07] [--jobs 4]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))
from sfg1 import compare, gen  # noqa: E402

# (id, file, old, new, description)
MUTANTS = [
 ("M01", "sfg1_regfile.sv", "hit_a[k]        <= we_l[k] && (wa == rs1);", "hit_a[k]        <= 1'b0;", "no same-cycle forwarding into read port A"),
 ("M02", "sfg1_regfile.sv", "hit_b[k]        <= we_l[k] && (wa == rs2);", "hit_b[k]        <= 1'b0;", "no same-cycle forwarding into read port B"),
 ("M03", "sfg1_regfile.sv", "p_hit  <= pw_ok ? (pw_lane & {LANES{pw_addr == psel}}) : {LANES{1'b0}};", "p_hit  <= {LANES{1'b0}};", "no same-cycle forwarding for predicates"),
 ("M04", "sfg1_regfile.sv", "we_l = (gw_en && gw_addr != 5'd0) ? gw_lane : {LANES{1'b0}};", "we_l = (gw_en && gw_addr != 5'd0) ? {LANES{1'b1}} : {LANES{1'b0}};", "GPR write ignores lane mask (writes inactive lanes)"),
 ("M05", "sfg1_scoreboard.sv", "((q_dk == DK_GPR)           && pg_eff[q_dst]) ||", "1'b0 ||", "WAW check on GPR destination removed"),
 ("M06", "sfg1_scoreboard.sv", "(q_rs2_v && (q_rs2 != 5'd0) && pg_eff[q_rs2]) ||", "1'b0 ||", "RAW check on rs2 removed"),
 ("M07", "sfg1_scoreboard.sv", "((q_gsel != 3'd0)           && pp_eff[q_gsel]) ||", "1'b0 ||", "RAW check on guard predicate removed"),
 ("M08", "sfg1_core.sv", "wire slot_conflict = ~o_dec.is_mul & x_valid & x_is_mul;", "wire slot_conflict = 1'b0;", "writeback-slot hazard check removed"),
 ("M09", "sfg1_lane.sv", "if (adv) w_data <= sel_m ? m_y : fast_y;", "w_data <= sel_m ? m_y : fast_y;", "W data register not held during a stall"),
 ("M10", "sfg1_lane_alu.sv", "assign sra = $unsigned($signed(a) >>> sh);", "assign sra = a >> sh;", "SAR is logical"),
 ("M11", "sfg1_core.sv", "x_sb      <= (o_dec.mul_op == MUL_HS);", "x_sb      <= (o_dec.mul_op == MUL_HS) | (o_dec.mul_op == MUL_HSU);", "MULHSU treats rs2 as signed"),
 ("M12", "sfg1_lane_alu.sv", "ALU_SHL:  y = a << sh;", "ALU_SHL:  y = a << b[5:0];", "shift amount uses 6 bits"),
 ("M13", "sfg1_core.sv", "o_guard = o_guard ^ {LANES{o_dec.gneg}};", "o_guard = o_guard;", "guard negate ignored"),
 ("M14", "sfg1_scoreboard.sv", "      pg <= '0;\n      pp <= '0;\n    end else begin", "      pg <= pg;\n      pp <= pp;\n    end else begin", "reset does not clear the scoreboard"),
 ("M15", "sfg1_fifo.sv", "if (do_push) mem[wpos] <= din;", "if (do_push && !do_pop) mem[wpos] <= din;", "FIFO drops an entry on simultaneous push+pop"),
 ("M16", "sfg1_core.sv", "assign xw_ready = rst_n & ~busy & ~ib_valid &", "assign xw_ready = rst_n & ~busy &", "external write not ordered behind queued instructions"),
 ("M17", "sfg1_regfile.sv", "if (clr_cnt == 5'd31) busy <= 1'b0;", "if (clr_cnt == 5'd30) busy <= 1'b0;", "clear sequence one cycle short (r31 not cleared)"),
 ("M18", "sfg1_core.sv", "x_illegal <= ~o_dec.legal;", "x_illegal <= 1'b0;", "illegal flag never reported"),
 ("M19", "sfg1_lane_alu.sv", "4'd2:    cmp = lts;", "4'd2:    cmp = ltu;", "SETP.LT uses unsigned compare"),
 ("M20", "sfg1_lane.sv", "wire [31:0] m_y = m_hi ? m_prod[63:32] : m_prod[31:0];", "wire [31:0] m_y = m_hi ? m_prod[31:0] : m_prod[63:32];", "MUL hi/lo word select swapped"),
 ("M21", "sfg1_scoreboard.sv", "    if (clr_g) pg_eff[clr_idx]     = 1'b0;\n", "", "same-cycle scoreboard release removed (timing only)"),
 ("M22", "sfg1_scoreboard.sv", "      if (clr_g) pg[clr_idx]      <= 1'b0;\n      if (clr_p) pp[clr_idx[2:0]] <= 1'b0;\n      if (set_g) pg[set_idx]      <= 1'b1;\n      if (set_p) pp[set_idx[2:0]] <= 1'b1;",
             "      if (set_g) pg[set_idx]      <= 1'b1;\n      if (set_p) pp[set_idx[2:0]] <= 1'b1;\n      if (clr_g) pg[clr_idx]      <= 1'b0;\n      if (clr_p) pp[clr_idx[2:0]] <= 1'b0;", "scoreboard clear beats set on a same-cycle collision"),
 ("M23", "sfg1_core.sv", "    if (!stall) begin\n      // X", "    if (1'b1) begin\n      // X", "stage data registers advance during a stall"),
 ("M24", "sfg1_core.sv", ".pw_lane(w_wmask)", ".pw_lane({LANES{1'b1}})", "predicate write ignores lane mask"),
 ("M25", "sfg1_core.sv", "o_wmask = (o_dec.dkind != DK_NONE) ? o_emask : {LANES{1'b0}};", "o_wmask = o_emask;", "mask reported for a discarded destination"),
 ("M26", "sfg1_core.sv", "assign res_valid   = w_valid & rst_n;", "assign res_valid   = w_valid;", "result valid during reset"),
 ("M27", "sfg1_core.sv", "assign iss_ready = rst_n & ~busy & ~ib_full & ~xw_valid;", "assign iss_ready = rst_n & ~ib_full & ~xw_valid;", "issue accepted during the RF clear sequence"),
 ("M28", "sfg1_decode.sv", "dec.imm    = (opc == OPC_MOVI) ? {{16{insn[15]}}, insn[15:0]} : {insn[15:0], 16'd0};", "dec.imm    = (opc == OPC_MOVI) ? {16'd0, insn[15:0]} : {insn[15:0], 16'd0};", "MOVI zero-extends instead of sign-extends"),
 ("M29", "sfg1_lane_alu.sv", "ALU_SLTU: y = {31'd0, ltu};", "ALU_SLTU: y = {31'd0, lts};", "SLTU uses signed compare"),
 ("M30", "sfg1_core.sv", "assign xw_ready = rst_n & ~busy & ~ib_valid & ~(w_valid & (w_dk == DK_GPR)) & ~xw_pending;", "assign xw_ready = rst_n & ~busy & ~ib_valid & ~(w_valid & (w_dk == DK_GPR));", "external write ignores in-flight writer of the same register"),
 ("M31", "sfg1_core.sv", "assign iss_ready = rst_n & ~busy & ~ib_full & ~xw_valid;", "assign iss_ready = rst_n & ~busy & ~ib_full;", "external write loses priority (instructions keep being accepted)"),
 ("M32", "sfg1_regfile.sv", "z_a <= (rs1 == 5'd0);", "z_a <= 1'b0; // r0 mask on port A removed", "(sanity) r0 read mask removed on A -- equivalent while RAM[0]==0"),
 # multi-edit mutant: old/new are tuples of replacements, all applied
 ("M33", "sfg1_regfile.sv", ("z_a <= (rs1 == 5'd0);", "z_b <= (rs2 == 5'd0);", "we_l = (gw_en && gw_addr != 5'd0) ? gw_lane : {LANES{1'b0}};"),
  ("z_a <= 1'b0;", "z_b <= 1'b0;", "we_l = gw_en ? gw_lane : {LANES{1'b0}};"), "r0 is writable AND its read mask is removed (both r0 protections gone)"),
]


def run(cmd, **kw):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, **kw)
    except subprocess.TimeoutExpired as e:        # a hung simulation is a detection (deadlock)
        out = (e.stdout or b"") if isinstance(e.stdout, (bytes, type(None))) else e.stdout
        if isinstance(out, bytes):
            out = out.decode(errors="replace")
        return subprocess.CompletedProcess(cmd, 124, out + "\nWATCHDOG: wall-clock timeout\n", "")


def classify(out: str):
    hits = []
    if re.search(r"SFG1[^\n]*:|Assertion failed in TOP.*sfg1_core|%Error:.*sfg1_core", out):
        hits.append("assertion")
    if "ERROR @cyc" in out:
        hits.append("TB-check/SV-model")
    if "WATCHDOG" in out:
        hits.append("watchdog(deadlock)")
    return hits


def test_mutant(m, workdir, lanes, seeds):
    mid, fname, old, new, desc = m
    d = os.path.join(workdir, mid)
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(os.path.join(ROOT, "rtl"), os.path.join(d, "rtl"))
    path = os.path.join(d, "rtl", fname)
    src = open(path).read()
    olds, news = (old, new) if isinstance(old, tuple) else ((old,), (new,))
    for o in olds:
        if src.count(o) != 1:
            return mid, desc, ["MUTATION-NOT-APPLIED"], f"pattern {o[:40]!r} occurs {src.count(o)}x in {fname}"
    for o, n in zip(olds, news):
        src = src.replace(o, n)
    open(path, "w").write(src)
    env = dict(os.environ, SFG1_RTL_DIR=os.path.join(d, "rtl"))
    exes = {}
    for tb in ("tb_sfg1_diff", "tb_sfg1_directed"):
        out = os.path.join(d, tb)
        # -O0: simulations are tiny, compile time dominates (3x faster builds)
        r = run([os.path.join(ROOT, "scripts", "vbuild.sh"), tb, out, f"-GLANES={lanes}", "-CFLAGS", "-O0"], env=env)
        exe = os.path.join(out, f"V{tb}")
        if not os.path.exists(exe):
            return mid, desc, ["BUILD-FAILED"], (r.stdout + r.stderr)[-600:]
        exes[tb] = exe
    layers = set()
    # differential: a handful of runs over all profiles
    for prof in sorted(gen.PROFILES):
        for seed in range(seeds):
            base = os.path.join(d, f"{prof}_{seed}")
            open(base + ".stim", "w").write(gen.generate(lanes, seed, prof, 400))
            r = run([exes["tb_sfg1_diff"], f"+stim={base}.stim", f"+log={base}.dut", "+verilator+rand+reset+2", f"+verilator+seed+{seed + 1}"], timeout=300)
            out = r.stdout + r.stderr
            if r.returncode != 0 or "TB_RESULT: PASS" not in out:
                layers.update(classify(out) or ["diff-TB(other)"])
            if os.path.exists(base + ".dut"):
                try:
                    ok, _, _ = compare.compare(base + ".dut")
                except Exception as e:                      # a broken log is itself a detection
                    ok = False
                if not ok:
                    layers.add("python-compare")
    r = run([exes["tb_sfg1_directed"], "+seed=1", "+iters=8", "+verilator+rand+reset+2", "+verilator+seed+1"], timeout=600)
    out = r.stdout + r.stderr
    if r.returncode != 0 or "TB_RESULT: PASS" not in out:
        layers.update(classify(out) or ["directed-TB(other)"])
        ph = re.findall(r"(T\d+):\s+FAILED", out)
        if ph:
            layers.add("directed:" + ",".join(ph))
    shutil.rmtree(d, ignore_errors=True)
    return mid, desc, sorted(layers), ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--lanes", type=int, default=4)
    ap.add_argument("--seeds", type=int, default=2)
    ap.add_argument("--workdir", default=os.path.join(tempfile.gettempdir(), "sfg1_mut"))
    ap.add_argument("--out", default=os.path.join(ROOT, "results", "mutation.txt"))
    a = ap.parse_args()
    os.makedirs(a.workdir, exist_ok=True)
    muts = [m for m in MUTANTS if not a.only or m[0] in a.only]
    res = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        def safe(m):
            try:
                return test_mutant(m, a.workdir, a.lanes, a.seeds)
            except Exception as e:                           # never let one mutant abort the campaign
                return m[0], m[4], ["HARNESS-ERROR"], repr(e)
        for r in ex.map(safe, muts):
            res.append(r)
            print(f"{r[0]}  {'KILLED  ' if r[2] and not set(r[2]) & {'MUTATION-NOT-APPLIED','BUILD-FAILED'} else 'SURVIVED' if not r[2] else 'ERROR   '} "
                  f"{r[1]:62s} {', '.join(r[2])} {r[3]}", flush=True)
    killed = sum(1 for r in res if r[2] and not set(r[2]) & {"MUTATION-NOT-APPLIED", "BUILD-FAILED", "HARNESS-ERROR"})
    surv = [r for r in res if not r[2]]
    lines = [f"{r[0]} {'KILLED' if r[2] else 'SURVIVED'} | {r[1]} | {', '.join(r[2])}" for r in res]
    lines.append(f"\n{killed}/{len(res)} mutants detected; survivors: {[r[0] for r in surv]}")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    open(a.out, "w").write("\n".join(lines) + "\n")
    print(lines[-1])
    return 0


if __name__ == "__main__":
    sys.exit(main())
