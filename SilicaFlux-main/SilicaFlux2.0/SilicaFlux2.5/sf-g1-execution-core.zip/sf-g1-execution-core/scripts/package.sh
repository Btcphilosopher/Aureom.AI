#!/usr/bin/env bash
# Package the project (sources, docs, and the *results of actual runs*) into a zip.
# Usage: scripts/package.sh <output.zip>
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=$(realpath -m "${1:?output zip path}")
TMP=$(mktemp -d)
NAME=sf-g1-execution-core
mkdir -p "$TMP/$NAME"
cp -r README.md Makefile docs rtl tb python scripts "$TMP/$NAME/"
mkdir -p "$TMP/$NAME/results/synth"
for f in results/regression.txt results/mutation.txt results/unit_tests.txt results/lint.txt results/synth/SUMMARY.md; do
  [ -f "$f" ] && cp "$f" "$TMP/$NAME/$f"
done
# tool logs behind SUMMARY.md (skip any stale/obsolete *_hier* leftovers and the large netlists)
for f in results/synth/*.stat.txt results/synth/*.pnr.log results/synth/*.log; do
  case "$f" in *_hier*) continue;; esac
  [ -f "$f" ] && cp "$f" "$TMP/$NAME/results/synth/"
done
find "$TMP/$NAME" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null || true
find "$TMP/$NAME" -name .pytest_cache -type d -prune -exec rm -rf {} + 2>/dev/null || true
rm -f "$OUT"
(cd "$TMP" && zip -qr "$OUT" "$NAME")
rm -rf "$TMP"
unzip -l "$OUT" | tail -1
