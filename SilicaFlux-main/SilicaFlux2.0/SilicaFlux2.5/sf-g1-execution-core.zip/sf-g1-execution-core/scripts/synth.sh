#!/usr/bin/env bash
# Technology-mapped synthesis with Yosys (slang SystemVerilog frontend).
#
#   scripts/synth.sh <family> <lanes> [rf_bram=0] [in_depth=2] [flatten=1] [pnr=1] [freq_mhz=100]
#       family: xc7   Xilinx 7-series primitives (LUT/FF/CARRY4/RAM32M/RAMB/DSP48E1). Utilisation only:
#                     there is no open-source place & route for Xilinx here, so NO Xilinx timing is produced.
#               ecp5  Lattice ECP5 (LFE5U-85F, CABGA381, speed grade 6), then nextpnr-ecp5 place & route
#                     (post-route Fmax of the clk domain). pnr=0 skips P&R (needed when the port count
#                     exceeds the device's I/O pins, i.e. LANES >= 8 as a standalone top).
#
# Requires a Yosys with the `slang` plugin, e.g.   pip install yowasp-yosys yowasp-nextpnr-ecp5
# (override with YOSYS=... / NEXTPNR=...).  Run from anywhere; the script cd's to the project root
# because the WASI build of Yosys can only see the current directory.
# Writes results/synth/<tag>.{log,stat.txt[,pnr.log]}.
set -euo pipefail
FAM=${1:?family xc7|ecp5}; L=${2:?lanes}; BRAM=${3:-0}; DEPTH=${4:-2}; FLAT=${5:-1}; PNR=${6:-1}; FREQ=${7:-100}
YOSYS=${YOSYS:-yowasp-yosys}
NEXTPNR=${NEXTPNR:-yowasp-nextpnr-ecp5}
cd "$(dirname "$0")/.."
OUT=results/synth; mkdir -p "$OUT"
TAG="${FAM}_L${L}_B${BRAM}_D${DEPTH}"; [ "$FLAT" = 0 ] && TAG="${TAG}_hier"
FILES=$(sed 's#^#rtl/#' rtl/filelist.f | tr '\n' ' ')
READ="read_slang -j 1 --top sfg1_core -G LANES=$L -G RF_BRAM=1'b$BRAM -G IN_DEPTH=$DEPTH $FILES"
FL=""; [ "$FLAT" = 1 ] && FL="-flatten"

case "$FAM" in
  xc7)
    $YOSYS -l "$OUT/$TAG.log" -p "$READ; synth_xilinx -family xc7 -top sfg1_core -noiopad $FL; tee -o $OUT/$TAG.stat.txt stat; write_json $OUT/$TAG.json" > /dev/null
    ;;
  ecp5)
    NF=""; [ "$FLAT" = 0 ] && NF="-noflatten"
    $YOSYS -l "$OUT/$TAG.log" -p "$READ; synth_ecp5 -top sfg1_core $NF -json $OUT/$TAG.json; tee -o $OUT/$TAG.stat.txt stat" > /dev/null
    if [ "$PNR" = 1 ]; then
      $NEXTPNR --85k --package CABGA381 --json "$OUT/$TAG.json" --freq "$FREQ" --seed 1 --timing-allow-fail \
               -l "$OUT/$TAG.pnr.log" > /dev/null 2>&1 || true
    fi
    ;;
  *) echo "unknown family $FAM"; exit 2;;
esac
rm -f "$OUT/$TAG.json"      # netlists are large (10-20 MB); keep logs and statistics only
echo "wrote $OUT/$TAG.*"
