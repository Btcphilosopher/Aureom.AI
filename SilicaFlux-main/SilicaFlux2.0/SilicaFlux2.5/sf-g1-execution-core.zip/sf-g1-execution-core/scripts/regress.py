#!/usr/bin/env python3
"""Full regression: build + run the directed testbench and the differential testbench over a
configuration matrix (lane count x input-FIFO depth x register-file style), in parallel.

    python3 scripts/regress.py                       # default matrix
    python3 scripts/regress.py --quick               # 3 configs, fewer seeds
    python3 scripts/regress.py --configs 8:2:0 4:1:1 --seeds 10 --n 800

A config is LANES:IN_DEPTH:RF_BRAM.  Exit status is non-zero if anything fails.
Everything is derived from actual simulator runs; nothing is estimated.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import os
import re
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))
from sfg1 import compare, gen  # noqa: E402

DEFAULT = ["1:2:0", "2:2:0", "3:2:0", "4:2:0", "8:2:0", "16:2:0", "32:2:0", "4:1:0", "4:4:0", "4:2:1", "8:2:1"]
QUICK = ["1:2:0", "4:2:0", "8:2:0"]


def parse_cfg(s):
    l, d, b = (int(x) for x in s.split(":"))
    return l, d, b


def build(tb, cfg, workdir):
    l, d, b = cfg
    out = os.path.join(workdir, f"{tb}_L{l}_D{d}_B{b}")
    # -O0: the simulations take well under a second; compile time dominates
    cmd = [os.path.join(ROOT, "scripts", "vbuild.sh"), tb, out, f"-GLANES={l}", f"-GIN_DEPTH={d}", f"-GRF_BRAM={b}", "-CFLAGS", "-O0"]
    t = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True)
    exe = os.path.join(out, f"V{tb}")
    if r.returncode != 0 or not os.path.exists(exe):
        return (tb, cfg, None, r.stdout[-3000:] + r.stderr[-1000:], time.time() - t)
    return (tb, cfg, exe, "", time.time() - t)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", nargs="*")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--seeds", type=int, default=6, help="differential seeds per profile per config")
    ap.add_argument("--n", type=int, default=600, help="random instructions per differential test")
    ap.add_argument("--directed-seeds", type=int, default=3)
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--workdir", default=os.path.join(ROOT, "build"))
    ap.add_argument("--out", default=os.path.join(ROOT, "results"))
    a = ap.parse_args()

    cfgs = [parse_cfg(c) for c in (a.configs or (QUICK if a.quick else DEFAULT))]
    seeds = 2 if a.quick and a.seeds == 6 else a.seeds
    os.makedirs(a.workdir, exist_ok=True)
    os.makedirs(a.out, exist_ok=True)
    lines = []

    def log(s=""):
        print(s, flush=True)
        lines.append(s)

    # ---------------------------------------------------------------- build
    t0 = time.time()
    log(f"== building {2 * len(cfgs)} simulators with {a.jobs} jobs")
    jobs = [(tb, c) for c in cfgs for tb in ("tb_sfg1_directed", "tb_sfg1_diff")]
    exes = {}
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for tb, cfg, exe, msg, dt in ex.map(lambda j: build(*j, a.workdir), jobs):
            if exe is None:
                log(f"BUILD FAILED {tb} {cfg}:\n{msg}")
                return 2
            exes[(tb, cfg)] = exe
    log(f"   built in {time.time() - t0:.0f}s")

    fails = 0
    # ------------------------------------------------------------- directed
    log("\n== directed testbench (self-checking; SV model + assertions + literal vectors)")
    log(f"{'config (LANES:DEPTH:BRAM)':28s} {'seed':>4s} {'result':>7s}  summary")
    for cfg in cfgs:
        for s in range(1, a.directed_seeds + 1):
            # randomised power-up state: no flop/RAM may be assumed zero before reset
            r = subprocess.run([exes[("tb_sfg1_directed", cfg)], f"+seed={s}", "+iters=20", "+verilator+rand+reset+2", f"+verilator+seed+{s}"],
                               capture_output=True, text=True)
            out = r.stdout + r.stderr
            ok = r.returncode == 0 and "TB_RESULT: PASS" in out
            sm = re.search(r"SUMMARY: (.*)", out)
            asserts = [l for l in out.splitlines() if "Assertion failed" in l or "SFG1" in l and "ERROR" in l.upper()]
            log(f"{':'.join(map(str, cfg)):28s} {s:4d} {'PASS' if ok else 'FAIL':>7s}  {sm.group(1) if sm else ''}")
            if not ok:
                fails += 1
                log("\n".join(out.splitlines()[-25:]))
            if s == 1 and ok:
                cov = re.search(r"SFG1_COV (.*)", out)
                if cov:
                    log(f"{'':28s}      coverage: {cov.group(1)}")

    # --------------------------------------------------------- differential
    log("\n== differential testbench: RTL vs SV model (in sim) vs Python simulator (compare.py)")
    log(f"{'config':14s} {'runs':>5s} {'pass':>5s} {'instr':>8s} {'retired':>8s} {'dropped':>8s} {'resets':>6s} {'xw':>6s}")
    tot = dict(runs=0, ok=0, acc=0, ret=0, drop=0, rst=0, xw=0)
    tmp = os.path.join(a.workdir, "stim")
    os.makedirs(tmp, exist_ok=True)
    for cfg in cfgs:
        lanes = cfg[0]
        c = dict(runs=0, ok=0, acc=0, ret=0, drop=0, rst=0, xw=0)
        for prof in sorted(gen.PROFILES):
            for seed in range(seeds):
                base = os.path.join(tmp, f"L{lanes}_D{cfg[1]}_B{cfg[2]}_{prof}_{seed}")
                open(base + ".stim", "w").write(gen.generate(lanes, seed, prof, a.n))
                r = subprocess.run([exes[("tb_sfg1_diff", cfg)], f"+stim={base}.stim", f"+log={base}.dut",
                                    "+verilator+rand+reset+2", f"+verilator+seed+{seed + 1}"],
                                   capture_output=True, text=True)
                sim_ok = r.returncode == 0 and "TB_RESULT: PASS" in r.stdout
                py_ok, st, msgs = compare.compare(base + ".dut") if os.path.exists(base + ".dut") else (False, {}, ["no log"])
                c["runs"] += 1
                c["ok"] += int(sim_ok and py_ok)
                c["acc"] += st.get("accepted", 0); c["ret"] += st.get("retired", 0)
                c["drop"] += st.get("dropped_by_reset", 0); c["rst"] += st.get("resets", 0); c["xw"] += st.get("xw", 0)
                if not (sim_ok and py_ok):
                    fails += 1
                    log(f"FAIL {base}  sim_ok={sim_ok} python_ok={py_ok}")
                    log("\n".join(r.stdout.splitlines()[-8:]))
                    for m in msgs:
                        log("   " + m)
                else:
                    for ext in (".stim", ".dut"):       # keep only failing artefacts
                        os.remove(base + ext)
        log(f"{':'.join(map(str, cfg)):14s} {c['runs']:5d} {c['ok']:5d} {c['acc']:8d} {c['ret']:8d} {c['drop']:8d} {c['rst']:6d} {c['xw']:6d}")
        for k in tot:
            tot[k] += c[k]
    log(f"{'TOTAL':14s} {tot['runs']:5d} {tot['ok']:5d} {tot['acc']:8d} {tot['ret']:8d} {tot['drop']:8d} {tot['rst']:6d} {tot['xw']:6d}")

    log(f"\n== {'ALL PASSED' if fails == 0 else str(fails) + ' FAILURE(S)'}  (total {time.time() - t0:.0f}s)")
    with open(os.path.join(a.out, "regression.txt"), "w") as f:
        f.write("\n".join(lines) + "\n")
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
