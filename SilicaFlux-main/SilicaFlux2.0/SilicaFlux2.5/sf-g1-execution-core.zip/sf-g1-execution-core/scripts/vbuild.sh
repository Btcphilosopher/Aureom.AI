#!/usr/bin/env bash
# usage: vbuild.sh <tb_top> <outdir> [extra verilator args, e.g. -GLANES=8]
# Builds a Verilator --binary simulation of tb/<tb_top>.sv with assertions on.
set -euo pipefail
TOP=$1; OUT=$2; shift 2
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RTLDIR="${SFG1_RTL_DIR:-$ROOT/rtl}"          # override to build a modified copy of the RTL (mutation testing)
RTL=$(sed "s#^#$RTLDIR/#" "$ROOT/rtl/filelist.f" | tr '\n' ' ')
verilator --binary --timing --timescale 1ns/1ps --assert -DSFG1_ASSERT --x-initial unique --x-assign unique -Wall \
  -Wno-DECLFILENAME -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-WIDTHEXPAND -Wno-WIDTHTRUNC -Wno-INITIALDLY \
  -Wno-BLKSEQ -Wno-SYNCASYNCNET -Wno-VARHIDDEN -Wno-CASEINCOMPLETE -Wno-STMTDLY -Wno-LATCH \
  -Wno-PINCONNECTEMPTY -Wno-MULTIDRIVEN -Wno-WIDTHCONCAT \
  -I"$ROOT/tb" -I"$RTLDIR" --top-module "$TOP" -Mdir "$OUT" -o "V$TOP" \
  $RTL "$ROOT/tb/$TOP.sv" "$@" 2>&1
