# SilicaFlux SF-G1 integer execution core (SystemVerilog)

A configurable-lane SIMT integer execution core: instruction decode, operand select, per-lane register file,
predicate/execution-mask handling, scoreboarded pipeline with backpressure, same-cycle forwarding, ALU +
pipelined multiplier, and a ready/valid interface with documented transaction ownership — plus RTL, a
self-checking testbench, assertions, a Python reference simulator, differential tests, a mutation campaign, and
**measured** synthesis results.

> ## ⚠ The SF-G1 specification was not available
> No SF-G1 ISA/configuration document exists in the repository this was built in (searched all text, PDFs and zip
> contents). As instructed, `docs/SF-G1_SPEC.md` states the interface assumptions explicitly and provides a
> minimal compatible specification. It is anchored to the one real artefact found — the SilicaFlux **v1** ISA
> (`sfx_asm.py`): the `ALU_R` encodings/funct codes are byte-identical, which is checked by a test.
> **Everything beyond that (SIMT lanes, masks, predicates, `SETP`/`MOVI`, channel signals) is an assumption** and
> must be reconciled if the real SF-G1 spec turns up.

## Layout

```
docs/SF-G1_SPEC.md          spec status, assumptions, ISA, arithmetic semantics, interfaces + ownership, latency table
docs/MICROARCHITECTURE.md   pipeline, hazards, RF read/write conflicts + forwarding, reset, FPGA mapping, limitations
docs/VERIFICATION.md        test strategy, how to run, results of the runs, what is NOT covered
rtl/                        synthesizable SystemVerilog (+ sfg1_core_checks.svh: assertions, simulation only)
tb/                         tb_sfg1_directed.sv (self-checking), tb_sfg1_diff.sv (stimulus replay), sfg1_tb_common.svh
python/sfg1/                isa.py (encoder/decoder/assembler), sim.py (reference simulator), gen.py, compare.py
python/tests/               pytest unit tests (ISA, simulator, comparator incl. corrupted-log detection)
scripts/                    regress.py, mutate.py, synth*.sh, vbuild.sh, package.sh
results/                    logs of the runs that the documents quote (regression, mutation, synthesis)
```

## Quick start

Needs: `verilator` ≥ 5.020, `python3`, `pytest`. (Synthesis additionally: `pip install yowasp-yosys yowasp-nextpnr-ecp5`.)

```bash
make unit          # Python unit tests (ISA, simulator, comparator)
make lint          # Verilator -Wall lint, several configurations
make quick         # build + run directed and differential testbenches, 3 configurations (~1.5 min)
make regress       # full matrix: LANES 1/2/3/4/8/16/32, FIFO depth 1/2/4, LUTRAM/BRAM register file (~7 min)
make mutate        # inject 33 bugs into the RTL and confirm the testbenches catch them (~25 min)
make synth         # Yosys (Xilinx 7-series + ECP5) and nextpnr-ecp5 -> results/synth/SUMMARY.md
```

Set `SFX_ASM=/path/to/sfx_asm.py` to also run the SilicaFlux-v1 encoding compatibility test.

## Using the core

```systemverilog
sfg1_core #(.LANES(8), .TAG_W(8), .IN_DEPTH(2), .RF_BRAM(1'b0)) u_core (
  .clk, .rst_n,                                           // synchronous, active-low reset
  .iss_valid, .iss_ready, .iss_insn, .iss_mask, .iss_tag, // issue channel
  .xw_valid, .xw_ready, .xw_rd, .xw_mask, .xw_data,       // external register write
  .res_valid, .res_ready, .res_tag, .res_dkind, .res_rd,  // result channel (= commit point)
  .res_mask, .res_data, .res_illegal,
  .busy, .idle);
```

Compile RTL with `rtl/filelist.f` (package first). Define `SFG1_ASSERT` to enable assertions and coverage
counters in simulation (Verilator `--assert`); never define it for synthesis.

## Headline facts (details and evidence in the docs)

* Latency: fast ops 4 cycles accept→result, multiplies 5; dependent instructions issue in the same cycle their
  producer commits (same-cycle forwarding), i.e. 3/4 cycles producer-result→consumer-result; throughput 1/cycle.
* Overflow wraps modulo 2³² (no saturation, no flags); shifts use `rs2[4:0]`; four multiply variants (low, signed-high,
  unsigned-high, signed×unsigned-high).
* Verification is layered (SV model + Python simulator + assertions + mutation testing); see `results/`.
* Synthesis numbers are only those in `results/synth/SUMMARY.md`; there is **no Xilinx/Intel timing**.
