// =============================================================================
//  sfg1_tb_common.svh -- shared harness (included INSIDE a testbench module)
//
//  Provides: clock, DUT, channel drivers, an independent behavioural reference
//  model of the ISA, and a per-transaction scoreboard that checks
//    * result data/mask/destination/illegal vs the reference model
//    * exactly-once retirement (unknown / duplicate / post-reset tags)
//    * program order of results that target the same destination register
//    * no handshake completes while rst_n is low
//    * global watchdog (deadlock detection)
//
//  Drive convention: the TB drives inputs on negedge clk and the DUT/monitor
//  sample on posedge clk, so there are no races.
//
//  The reference model here is written separately from the RTL decode (plain
//  behavioural SV with 64-bit arithmetic) and separately from the Python
//  simulator; the three are only ever compared at the transaction level.
// =============================================================================

  // ---------------------------------------------------------------- clock/reset
  logic clk   = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------------- DUT I/O
  logic                 iss_valid = 1'b0;
  wire                  iss_ready;
  logic [31:0]          iss_insn  = '0;
  logic [LANES-1:0]     iss_mask  = '0;
  logic [TAG_W-1:0]     iss_tag   = '0;

  logic                 xw_valid  = 1'b0;
  wire                  xw_ready;
  logic [4:0]           xw_rd     = '0;
  logic [LANES-1:0]     xw_mask   = '0;
  logic [LANES*32-1:0]  xw_data   = '0;

  wire                  res_valid;
  logic                 res_ready = 1'b0;
  wire  [TAG_W-1:0]     res_tag;
  wire  [1:0]           res_dkind;
  wire  [4:0]           res_rd;
  wire  [LANES-1:0]     res_mask;
  wire  [LANES*32-1:0]  res_data;
  wire                  res_illegal;
  wire                  busy, idle;

  sfg1_core #(.LANES(LANES), .TAG_W(TAG_W), .IN_DEPTH(IN_DEPTH), .RF_BRAM(RF_BRAM)) dut (
    .clk(clk), .rst_n(rst_n),
    .iss_valid(iss_valid), .iss_ready(iss_ready), .iss_insn(iss_insn),
    .iss_mask(iss_mask), .iss_tag(iss_tag),
    .xw_valid(xw_valid), .xw_ready(xw_ready), .xw_rd(xw_rd),
    .xw_mask(xw_mask), .xw_data(xw_data),
    .res_valid(res_valid), .res_ready(res_ready), .res_tag(res_tag),
    .res_dkind(res_dkind), .res_rd(res_rd), .res_mask(res_mask),
    .res_data(res_data), .res_illegal(res_illegal),
    .busy(busy), .idle(idle));

  localparam logic [LANES-1:0] FULL = {LANES{1'b1}};
  localparam int NTAGS = (1 << TAG_W);

  // ------------------------------------------------------------ random source
  // xorshift32: identical on every simulator, seedable from the command line.
  logic [31:0] rng_s = 32'h1234_5678;
  function automatic logic [31:0] rnd();
    rng_s = rng_s ^ (rng_s << 13);
    rng_s = rng_s ^ (rng_s >> 17);
    rng_s = rng_s ^ (rng_s << 5);
    return rng_s;
  endfunction
  function automatic int rnd_n(input int n);      // 0 .. n-1
    return int'(rnd() % n);
  endfunction

  // ------------------------------------------------------ reference-model state
  typedef struct packed {
    logic                 illegal;
    logic [1:0]           dkind;
    logic [4:0]           idx;
    logic [LANES-1:0]     wmask;
    logic [LANES*32-1:0]  data;
  } rec_t;

  logic [31:0]      m_gpr  [0:LANES-1][0:31];
  logic [LANES-1:0] m_pred [0:7];

  task automatic model_reset();
    for (int l = 0; l < LANES; l++) for (int r = 0; r < 32; r++) m_gpr[l][r] = 32'd0;
    for (int p = 0; p < 8; p++) m_pred[p] = '0;
    m_pred[0] = FULL;
  endtask

  function automatic logic [31:0] f_sext(input logic [31:0] v, input int bits);
    logic [31:0] r;
    r = v;
    for (int i = 0; i < 32; i++) if (i >= bits) r[i] = v[bits-1];
    return r;
  endfunction

  // 64-bit behavioural arithmetic
  function automatic logic [31:0] f_alu(input int fn, input logic [31:0] a, input logic [31:0] b);
    logic signed [63:0] sa, sb, sp;
    logic        [63:0] ua, ub, up;
    int sh;
    sa = 64'(signed'(a));  sb = 64'(signed'(b));
    ua = {32'd0, a};       ub = {32'd0, b};
    sh = int'(b & 32'h1f);
    case (fn)
      0:  return a + b;
      1:  return a - b;
      2:  begin up = ua * ub; return up[31:0]; end
      3:  return a & b;
      4:  return a | b;
      5:  return a ^ b;
      6:  return a << sh;
      7:  return a >> sh;
      8:  begin sp = sa >>> sh; return sp[31:0]; end
      9:  return (sa < sb) ? 32'd1 : 32'd0;
      10: return (ua < ub) ? 32'd1 : 32'd0;
      11: begin sp = sa * sb; return sp[63:32]; end
      12: begin up = ua * ub; return up[63:32]; end
      13: begin sp = sa * $signed(ub); return sp[63:32]; end
      default: return 32'hDEAD_BEEF;
    endcase
  endfunction

  function automatic bit f_cond(input int c, input logic [31:0] a, input logic [31:0] b);
    logic signed [31:0] sa, sb;
    sa = a; sb = b;
    case (c)
      0: return a == b;   1: return a != b;
      2: return sa <  sb; 3: return sa <= sb; 4: return sa >  sb; 5: return sa >= sb;
      6: return a <  b;   7: return a <= b;   8: return a >  b;   9: return a >= b;
      default: return 1'b0;
    endcase
  endfunction

  // Execute one instruction in the model; returns the expected result record.
  function automatic rec_t model_step(input logic [31:0] insn, input logic [LANES-1:0] imask);
    rec_t r;
    int   opc, ra, rb, rc, dd, ff;
    bit   legal, is_r, isimm, writes_pred, gneg;
    int   kind;                 // 0 none, 1 alu/mul(R), 2 setp, 3 mov
    int   gsel;
    logic [LANES-1:0] em;
    logic [31:0] a, b, y;
    bit   g;

    r = '0;
    opc = int'(insn[31:26]); ra = int'(insn[25:21]); rb = int'(insn[20:16]);
    rc = int'(insn[15:11]);  dd = int'(insn[10:6]);  ff = int'(insn[5:0]);
    legal = 0; kind = 0; isimm = 0; gsel = 0; gneg = 0; writes_pred = 0;

    if (opc == 1) begin
      if (insn[25:0] == 0) legal = 1;                    // NOP
    end else if (opc == 8) begin
      if (ff <= 13) begin legal = 1; kind = 1; isimm = dd[4]; gsel = dd & 7; gneg = dd[3]; end
    end else if (opc == 56) begin
      if (ff <= 9 && ra < 8) begin legal = 1; kind = 2; isimm = dd[4]; gsel = dd & 7; gneg = dd[3]; writes_pred = 1; end
    end else if (opc == 57 || opc == 15) begin
      if (rb < 16) begin legal = 1; kind = 3; gsel = rb & 7; gneg = rb[3]; end
    end

    if (!legal) begin r.illegal = 1'b1; return r; end
    if (kind == 0) return r;                              // NOP

    em = '0;
    for (int l = 0; l < LANES; l++) begin
      g = (gsel == 0) ? 1'b1 : m_pred[gsel][l];
      g = g ^ gneg;
      em[l] = imask[l] & g;
    end

    // destination after r0 / p0 discard
    if (writes_pred) begin
      if ((ra & 7) != 0) begin r.dkind = 2'd2; r.idx = 5'(ra & 7); end
    end else begin
      if (ra != 0) begin r.dkind = 2'd1; r.idx = 5'(ra); end
    end

    for (int l = 0; l < LANES; l++) begin
      if (!em[l]) continue;
      if (kind == 3) begin
        y = (opc == 57) ? f_sext({16'd0, insn[15:0]}, 16) : {insn[15:0], 16'd0};
      end else begin
        a = m_gpr[l][rb];
        b = isimm ? f_sext({27'd0, 5'(rc)}, 5) : m_gpr[l][rc];
        y = (kind == 2) ? {31'd0, f_cond(ff, a, b)} : f_alu(ff, a, b);
      end
      if (r.dkind != 2'd0) r.data[32*l +: 32] = y;
      if (r.dkind == 2'd1 && r.idx != 0) m_gpr[l][r.idx] = y;
      if (r.dkind == 2'd2)               m_pred[r.idx][l] = y[0];
    end
    if (r.dkind != 2'd0) r.wmask = em;
    return r;
  endfunction

  // ------------------------------------------------------ transaction bookkeeping
  rec_t     exp_rec     [0:NTAGS-1];
  bit       tag_infl    [0:NTAGS-1];
  longint   acc_cyc     [0:NTAGS-1];
  longint   ret_cyc     [0:NTAGS-1];
  longint   seq_of_tag  [0:NTAGS-1];
  longint   last_seq    [0:95];            // per destination (dkind*32+idx)
  int       infl_q[$];
  longint   cyc = 0;
  longint   seq_ctr = 0;
  int       errors = 0, n_acc = 0, n_ret = 0, n_drop = 0, n_xw = 0, n_rst = 0, n_illegal_seen = 0;
  bit       log_en = 0;
  int       log_fd = 0;
  bit       prev_rst_low = 0;
  rec_t     last_ret;                 // most recent result seen on the channel
  int       last_ret_tag = -1;
  bit       abort_send = 0;           // set to make a blocked send() give up (reset tests)

  task automatic fail(input string msg);
    errors++;
    if (errors <= 20) $display("[%0t] ERROR @cyc %0d: %s", $time, cyc, msg);
  endtask

  always @(posedge clk) cyc <= cyc + 1;

  // log helpers (diff TB)
  task automatic log_hex_data(input logic [LANES*32-1:0] d);
    for (int l = 0; l < LANES; l++) $fwrite(log_fd, " %08x", d[32*l +: 32]);
  endtask

  // The monitor: runs once per posedge, in the order  reset / xw / accept / retire.
  always @(posedge clk) begin : monitor
    rec_t e;
    int   tg;
    if (!rst_n) begin
      if (res_valid || iss_ready || xw_ready) fail("handshake output active while rst_n low");
      if (!prev_rst_low) begin
        n_rst++;
        n_drop += infl_q.size();
        foreach (infl_q[i]) tag_infl[infl_q[i]] = 1'b0;
        infl_q.delete();
        model_reset();
        for (int i = 0; i < 96; i++) last_seq[i] = -1;
        if (log_en) $fwrite(log_fd, "RST\n");
      end
      prev_rst_low <= 1'b1;
    end else begin
      prev_rst_low <= 1'b0;

      if (xw_valid && xw_ready) begin
        n_xw++;
        if (xw_rd != 0)
          for (int l = 0; l < LANES; l++)
            if (xw_mask[l]) m_gpr[l][xw_rd] = xw_data[32*l +: 32];
        if (log_en) begin
          $fwrite(log_fd, "XWA %0d %0x", xw_rd, xw_mask);
          log_hex_data(xw_data);
          $fwrite(log_fd, "\n");
        end
      end

      if (iss_valid && iss_ready) begin
        tg = int'(iss_tag);
        if (tag_infl[tg]) fail($sformatf("TB: tag %0d accepted while still in flight", tg));
        exp_rec[tg]    = model_step(iss_insn, iss_mask);
        tag_infl[tg]   = 1'b1;
        acc_cyc[tg]    = cyc;
        seq_of_tag[tg] = seq_ctr++;
        infl_q.push_back(tg);
        n_acc++;
        if (log_en) $fwrite(log_fd, "ACC %0d %08x %0x\n", tg, iss_insn, iss_mask);
      end

      if (res_valid && res_ready) begin
        tg = int'(res_tag);
        n_ret++;
        if (!tag_infl[tg]) begin
          fail($sformatf("result with unknown or duplicate tag %0d", tg));
        end else begin
          e = exp_rec[tg];
          ret_cyc[tg] = cyc;
          last_ret = '{illegal: res_illegal, dkind: res_dkind, idx: res_rd, wmask: res_mask, data: res_data};
          last_ret_tag = tg;
          if (res_dkind !== e.dkind || res_rd !== e.idx || res_mask !== e.wmask || res_illegal !== e.illegal)
            fail($sformatf("tag %0d: header got {dk=%0d rd=%0d mask=%0x ill=%0b} exp {dk=%0d rd=%0d mask=%0x ill=%0b}",
                           tg, res_dkind, res_rd, res_mask, res_illegal, e.dkind, e.idx, e.wmask, e.illegal));
          else
            for (int l = 0; l < LANES; l++)
              if (e.wmask[l] && res_data[32*l +: 32] !== e.data[32*l +: 32])
                fail($sformatf("tag %0d lane %0d: data got %08x exp %08x (insn %08x)", tg, l,
                               res_data[32*l +: 32], e.data[32*l +: 32], 32'h0));
          if (res_dkind != 2'd0) begin
            if (seq_of_tag[tg] < last_seq[int'(res_dkind)*32 + int'(res_rd)])
              fail($sformatf("tag %0d: same-destination results retired out of program order", tg));
            last_seq[int'(res_dkind)*32 + int'(res_rd)] = seq_of_tag[tg];
          end
          if (e.illegal) n_illegal_seen++;
          tag_infl[tg] = 1'b0;
          for (int i = 0; i < infl_q.size(); i++) if (infl_q[i] == tg) begin infl_q.delete(i); break; end
          if (log_en) begin
            $fwrite(log_fd, "RET %0d %0d %0d %0x %0d", tg, res_dkind, res_rd, res_mask, res_illegal);
            log_hex_data(res_data);
            $fwrite(log_fd, "\n");
          end
        end
      end
    end
  end

  // --------------------------------------------------------- result-side driver
  // mode 0: always ready; 1: random (rr_pct % of cycles NOT ready); 2: held low
  int rr_mode = 0;
  int rr_pct  = 0;
  always @(negedge clk) begin
    case (rr_mode)
      0: res_ready <= 1'b1;
      1: res_ready <= (rnd_n(100) >= rr_pct);
      default: res_ready <= 1'b0;
    endcase
  end

  // ----------------------------------------------------------- watchdog
  int unsigned wd_limit = WD_LIMIT;       // each TB defines WD_LIMIT before including this file
  always @(posedge clk) if (cyc > wd_limit) begin
    $display("WATCHDOG: exceeded %0d cycles (acc=%0d ret=%0d)", wd_limit, n_acc, n_ret);
    $display("  state: rst_n=%0b busy=%0b iss_valid=%0b iss_ready=%0b xw_valid=%0b xw_ready=%0b res_valid=%0b res_ready=%0b rr_mode=%0d",
             rst_n, busy, iss_valid, iss_ready, xw_valid, xw_ready, res_valid, res_ready, rr_mode);
    $display("  core : ib_valid=%0b ib_count=%0d hazard=%0b stall=%0b o_valid=%0b x_valid=%0b m_valid=%0b w_valid=%0b o_go=%0b issue_go=%0b",
             dut.ib_valid, dut.ib_count, dut.hazard, dut.stall, dut.o_valid, dut.x_valid, dut.m_valid, dut.w_valid, dut.o_go, dut.issue_go);
    $display("  sb   : pend_g=%08x pend_p=%02x  head insn=%08x rs1=%0d(u%0b) rs2=%0d(u%0b) dst=%0d dk=%0d gsel=%0d",
             dut.pend_g, dut.pend_p, dut.ib_insn, dut.dec.rs1, dut.dec.rs1_used, dut.dec.rs2, dut.dec.rs2_used,
             dut.dec.dst, dut.dec.dkind, dut.dec.gsel);
    $display("  tb   : infl=%0d xw_rd=%0d next_tag=%0d", infl_q.size(), xw_rd, next_tag);
    $fatal(1, "watchdog");
  end

  // --------------------------------------------------------- issue-side driver
  int   next_tag   = 0;
  int   iss_gap_pct = 0;      // % chance of idling a cycle before offering an instruction

  // Offer one instruction; returns when accepted. Called on a negedge.
  task automatic send(input logic [31:0] insn, input logic [LANES-1:0] mask, output int tag);
    // NOTE: keep the random draw out of the loop condition. Verilator 5.020 never terminates
    // `while (cond_with_side_effects()) @(negedge clk);` (reproduced in isolation); this
    // explicit form is equivalent and works.
    forever begin
      if (iss_gap_pct <= 0) break;
      if (rnd_n(100) >= iss_gap_pct) break;
      @(negedge clk);
    end
    tag = next_tag; next_tag++;
    if (next_tag >= NTAGS) $fatal(1, "TB: tag space exhausted");
    iss_valid = 1'b1; iss_insn = insn; iss_mask = mask; iss_tag = TAG_W'(tag);
    @(posedge clk);
    while (!(iss_ready && rst_n)) begin               // accepted at the posedge where this exits
      if (abort_send) begin @(negedge clk); iss_valid = 1'b0; return; end
      @(posedge clk);
    end
    @(negedge clk);
    iss_valid = 1'b0;
  endtask

  task automatic send_nt(input logic [31:0] insn, input logic [LANES-1:0] mask);
    int t;
    send(insn, mask, t);
  endtask

  // External write; returns when accepted.
  task automatic xwrite(input int rd, input logic [LANES-1:0] mask, input logic [LANES*32-1:0] data);
    xw_valid = 1'b1; xw_rd = 5'(rd); xw_mask = mask; xw_data = data;
    @(posedge clk);
    while (!(xw_ready && rst_n)) @(posedge clk);
    @(negedge clk);
    xw_valid = 1'b0;
  endtask

  task automatic xwrite_all(input int rd, input logic [31:0] v);        // same value, all lanes
    logic [LANES*32-1:0] d;
    for (int l = 0; l < LANES; l++) d[32*l +: 32] = v;
    xwrite(rd, FULL, d);
  endtask

  // wait until every accepted instruction has retired and the core reports idle
  task automatic drain();
    int guard;
    guard = 0;
    while (!(infl_q.size() == 0 && idle && !iss_valid)) begin
      @(negedge clk);
      guard++;
      if (guard > 200000) begin fail("drain timeout"); return; end
    end
    @(negedge clk);
  endtask

  task automatic wait_cycles(input int n);
    repeat (n) @(negedge clk);
  endtask

  // synchronous reset pulse (on negedges)
  task automatic do_reset(input int hold);
    rst_n = 1'b0;
    repeat (hold) @(negedge clk);
    rst_n = 1'b1;
  endtask

  task automatic wait_not_busy();
    int guard;
    guard = 0;
    while (busy || !rst_n) begin
      @(negedge clk);
      guard++;
      if (guard > 1000) begin fail("busy never deasserted"); return; end
    end
  endtask

  initial begin
    for (int t = 0; t < NTAGS; t++) begin tag_infl[t] = 1'b0; end
    for (int i = 0; i < 96; i++) last_seq[i] = -1;
    model_reset();
  end

  // ----------------------------------------------------------------- encoders
  function automatic logic [31:0] e_r(input int opc, input int rd, input int rs1, input int rs2,
                                      input int fn, input int pred, input bit neg, input bit imm);
    return {6'(opc), 5'(rd), 5'(rs1), 5'(rs2), imm, neg, 3'(pred), 6'(fn)};
  endfunction
  function automatic logic [31:0] e_alu(input int fn, input int rd, input int rs1, input int rs2);
    return e_r(8, rd, rs1, rs2, fn, 0, 0, 0);
  endfunction
  function automatic logic [31:0] e_alui(input int fn, input int rd, input int rs1, input int imm5);
    return e_r(8, rd, rs1, imm5 & 31, fn, 0, 0, 1);
  endfunction
  function automatic logic [31:0] e_alug(input int fn, input int rd, input int rs1, input int rs2,
                                         input int pred, input bit neg);
    return e_r(8, rd, rs1, rs2, fn, pred, neg, 0);
  endfunction
  function automatic logic [31:0] e_setp(input int cond, input int pd, input int rs1, input int rs2);
    return e_r(56, pd, rs1, rs2, cond, 0, 0, 0);
  endfunction
  function automatic logic [31:0] e_setpg(input int cond, input int pd, input int rs1, input int rs2,
                                          input int pred, input bit neg);
    return e_r(56, pd, rs1, rs2, cond, pred, neg, 0);
  endfunction
  function automatic logic [31:0] e_movi(input int rd, input int imm16, input int pred, input bit neg);
    return {6'd57, 5'(rd), 1'b0, neg, 3'(pred), 16'(imm16)};
  endfunction
  function automatic logic [31:0] e_lui(input int rd, input int imm16, input int pred, input bit neg);
    return {6'd15, 5'(rd), 1'b0, neg, 3'(pred), 16'(imm16)};
  endfunction

  localparam int F_ADD = 0, F_SUB = 1, F_MUL = 2, F_AND = 3, F_OR = 4, F_XOR = 5, F_SHL = 6, F_SHR = 7,
                 F_SAR = 8, F_SLT = 9, F_SLTU = 10, F_MULH = 11, F_MULHU = 12, F_MULHSU = 13;
