// =============================================================================
//  tb_sfg1_diff -- stimulus-replay testbench for differential testing
//
//  Reads a numeric stimulus file produced by python/sfg1/gen.py, drives the DUT
//  (with random result back-pressure / producer gaps / reset events), and writes
//  a transaction log that python/sfg1/compare.py replays through the Python
//  reference simulator.  The harness monitor ALSO checks every result against
//  the SV reference model, so a run is a three-way comparison:
//      RTL  vs  SV model   (inline, this simulation)
//      RTL  vs  Python simulator (compare.py, after the run)
//
//  Stimulus ops (one per line, all numbers; %d decimal, %h hex):
//    0 <lanes> <pi> <pr> <seed>        header: lane check, % producer gaps, % result stalls, rng seed
//    1 <insn> <mask>                   issue one instruction (tag = running count of op-1 lines)
//    2 <rd> <mask> <d0> ... <dL-1>     external write after draining the core
//    6 <rd> <mask> <d0> ... <dL-1>     external write, stream-ordered (no drain)
//    3                                 drain: wait until everything accepted has retired
//    4 <after_n_accepts> <extra> <hold> arm a reset: fires <extra> cycles after <n> more accepts
//    7                                 wait until any armed reset has fired and the clear finished
//    9                                 end of stimulus
// =============================================================================
module tb_sfg1_diff;
  parameter int LANES    = 8;
  parameter int TAG_W    = 16;
  parameter int IN_DEPTH = 2;
  parameter bit RF_BRAM  = 1'b0;

  localparam int unsigned WD_LIMIT = 300_000;        // a 600-instruction run needs well under 100k cycles
  `include "sfg1_tb_common.svh"

  string stim_path, log_path;
  int    fd, op, hdr_lanes, hdr_pi, hdr_pr, hdr_seed;
  int    n_lines;

  // reset controller -----------------------------------------------------------
  bit rst_arm = 0;
  int rst_target = 0, rst_extra = 0, rst_hold = 1;
  int n_reset_fired = 0;
  initial begin
    forever begin
      @(negedge clk);
      if (rst_arm && n_acc >= rst_target) begin
        repeat (rst_extra) @(negedge clk);
        rst_n = 1'b0;
        repeat (rst_hold) @(negedge clk);
        rst_n = 1'b1;
        rst_arm = 0;
        n_reset_fired++;
      end
    end
  end

  task automatic read_data(output logic [LANES*32-1:0] d);
    logic [31:0] w;
    int unused;
    d = '0;
    for (int l = 0; l < LANES; l++) begin
      unused = $fscanf(fd, "%h", w);
      d[32*l +: 32] = w;
    end
  endtask

  initial begin
    logic [31:0] insn, m32;
    logic [LANES*32-1:0] d;
    int rd, a, b, c, t, unused;
    bit done;
    stim_path = "stim.txt"; log_path = "dut.log";
    void'($value$plusargs("stim=%s", stim_path));
    void'($value$plusargs("log=%s", log_path));
    fd = $fopen(stim_path, "r");
    if (fd == 0) $fatal(1, "cannot open stimulus %s", stim_path);
    log_fd = $fopen(log_path, "w");
    if (log_fd == 0) $fatal(1, "cannot open log %s", log_path);
    $fwrite(log_fd, "HDR %0d %0d %0d\n", LANES, TAG_W, IN_DEPTH);
    log_en = 1;

    unused = $fscanf(fd, "%d", op);
    if (op != 0) $fatal(1, "stimulus must start with a header line");
    unused = $fscanf(fd, "%d %d %d %d", hdr_lanes, hdr_pi, hdr_pr, hdr_seed);
    if (hdr_lanes != LANES) $fatal(1, "stimulus is for %0d lanes, DUT has %0d", hdr_lanes, LANES);
    iss_gap_pct = hdr_pi;
    rr_pct      = hdr_pr;
    rr_mode     = (hdr_pr > 0) ? 1 : 0;
    rng_s       = 32'hC0FF_EE11 ^ 32'(hdr_seed * 32'd2654435761);
    if (rng_s == 0) rng_s = 32'h1;

    @(negedge clk); @(negedge clk);
    rst_n = 1'b1;
    wait_not_busy();
    done = 0;
    n_lines = 0;
    while (!done) begin
      if ($fscanf(fd, "%d", op) != 1) break;
      n_lines++;
      case (op)
        1: begin
          unused = $fscanf(fd, "%h %h", insn, m32);
          send(insn, LANES'(m32), t);
        end
        2, 6: begin
          unused = $fscanf(fd, "%d %h", rd, m32);
          read_data(d);
          if (op == 2) drain();
          xwrite(rd, LANES'(m32), d);
        end
        3: drain();
        4: begin
          unused = $fscanf(fd, "%d %d %d", a, b, c);
          rst_target = n_acc + a; rst_extra = b; rst_hold = (c < 1) ? 1 : c;
          rst_arm = 1;
        end
        7: begin
          while (rst_arm || !rst_n || busy) @(negedge clk);
          @(negedge clk);
        end
        9: done = 1;
        default: $fatal(1, "bad stimulus op %0d", op);
      endcase
    end
    rst_arm = 0;
    drain();
    $fwrite(log_fd, "END %0d %0d %0d %0d\n", n_acc, n_ret, n_drop, n_rst);
    $fclose(log_fd);
    $display("tb_sfg1_diff: LANES=%0d IN_DEPTH=%0d RF_BRAM=%0d lines=%0d accepted=%0d retired=%0d dropped=%0d xw=%0d resets=%0d cycles=%0d sv_model_errors=%0d",
             LANES, IN_DEPTH, RF_BRAM, n_lines, n_acc, n_ret, n_drop, n_xw, n_rst, cyc, errors);
    if (errors == 0 && n_acc == n_ret + n_drop) begin
      $display("TB_RESULT: PASS");
      $finish;
    end else begin
      $display("TB_RESULT: FAIL");
      $fatal(1, "differential testbench failed");
    end
  end
endmodule
