// =============================================================================
//  tb_sfg1_directed -- self-checking directed + constrained-random testbench
//
//  Every retired result is checked by the harness monitor against the SV
//  reference model (sfg1_tb_common.svh); on top of that the tests below assert
//  exact timing (latency/throughput/forwarding distances), protocol behaviour
//  under stalls, external-write arbitration, reset during activity, and a
//  literal-expectation table for arithmetic boundaries that does NOT depend
//  on any model code.
//
//  Exit status: $fatal (non-zero) on any failure; prints "TB_RESULT: PASS" otherwise.
//  Parameters:  LANES, IN_DEPTH, RF_BRAM  (+seed=N, +iters=N plusargs)
// =============================================================================
module tb_sfg1_directed;
  parameter int LANES    = 8;
  parameter int TAG_W    = 16;
  parameter int IN_DEPTH = 2;
  parameter bit RF_BRAM  = 1'b0;

  localparam int unsigned WD_LIMIT = 2_000_000;      // a clean run needs ~90k cycles
  `include "sfg1_tb_common.svh"

  localparam logic [31:0] NOP_W = 32'h0400_0000;   // opcode 0x01

  // Peak instruction rate depends on the input FIFO depth: iss_ready is registered occupancy
  // (~full), so with a single entry it cannot rise in the cycle the entry frees -> one accept
  // every 2 cycles. Depth >= 2 sustains one per cycle. (Documented in the spec; measured by T4.)
  localparam int TPUT_GAP = (IN_DEPTH == 1) ? 2 : 1;

  // boundary values used by the sweeps
  localparam int NV = 20;
  logic [31:0] V [0:NV-1];
  initial begin
    V[0]  = 32'h0000_0000; V[1]  = 32'h0000_0001; V[2]  = 32'h0000_0002; V[3]  = 32'h0000_0003;
    V[4]  = 32'h0000_001F; V[5]  = 32'h0000_0020; V[6]  = 32'h0000_0021; V[7]  = 32'h7FFF_FFFF;
    V[8]  = 32'h8000_0000; V[9]  = 32'h8000_0001; V[10] = 32'hFFFF_FFFF; V[11] = 32'hFFFF_FFFE;
    V[12] = 32'h0000_FFFF; V[13] = 32'hFFFF_0000; V[14] = 32'h0001_0000; V[15] = 32'h5555_5555;
    V[16] = 32'hAAAA_AAAA; V[17] = 32'h1234_5678; V[18] = 32'hDEAD_BEEF; V[19] = 32'h7FFF_FFFE;
  end

  // ------------------------------------------------------------------ helpers
  task automatic check(input bit cond, input string msg);
    if (!cond) fail(msg);
  endtask

  function automatic logic [LANES*32-1:0] lane_vec(input int base, input int stride);
    logic [LANES*32-1:0] d;
    for (int l = 0; l < LANES; l++) d[32*l +: 32] = 32'(base + stride * l);
    return d;
  endfunction

  // Read back every architectural register through the datapath. The monitor
  // compares each copy with the reference-model state, so any lane written (or
  // not written) wrongly anywhere earlier shows up here.
  task automatic readback_all();
    int t;
    send(e_alu(F_OR, 29, 0, 0), FULL, t);                                // r0 as rs1 and rs2: must read zero
    send(e_alui(F_ADD, 30, 0, 0), FULL, t);                              // r0 with an immediate
    for (int r = 1; r <= 28; r++) send(e_alui(F_ADD, 29 + (r % 3), r, 0), FULL, t);
    for (int r = 29; r <= 31; r++) send(e_alui(F_ADD, r - 28, r, 0), FULL, t);
    for (int p = 1; p <= 7; p++) send(e_movi(31, 1, p, 0), FULL, t);     // @pN MOVI r31, 1
    drain();
  endtask

  task automatic lit(input int fn, input logic [31:0] a, input logic [31:0] b, input logic [31:0] exp);
    int t;
    xwrite_all(1, a); xwrite_all(2, b);
    send(e_alu(fn, 3, 1, 2), FULL, t);
    drain();
    for (int l = 0; l < LANES; l++)
      if (last_ret.data[32*l +: 32] !== exp)
        fail($sformatf("literal fn=%0d a=%08x b=%08x lane %0d: got %08x exp %08x",
                       fn, a, b, l, last_ret.data[32*l +: 32], exp));
  endtask

  int phase_errs;
  task automatic phase_begin(input string n);
    phase_errs = errors;
    $display("---- %s", n);
  endtask
  task automatic phase_end(input string n);
    $display("     %s: %s", n, (errors == phase_errs) ? "ok" : "FAILED");
  endtask

  // ====================================================================== tests
  task automatic t_reset_clear();
    int n, t;
    phase_begin("T1 reset / RF clear sequence");
    rst_n = 1'b0;
    wait_cycles(4);
    check(!iss_ready && !xw_ready && !res_valid, "outputs not quiet during reset");
    rst_n = 1'b1;
    n = 0;
    // count cycles with rst_n=1 and busy=1, checking the ready outputs stay low
    @(posedge clk);
    while (busy) begin
      n++;
      if (iss_ready || xw_ready) fail("ready asserted during clear sequence");
      @(posedge clk);
    end
    $display("     busy high for %0d cycles after reset release", n);
    check(n == 32, $sformatf("clear sequence length %0d != 32", n));
    @(negedge clk);
    check(iss_ready && xw_ready, "ready low after clear sequence");
    readback_all();                         // all zeros (model state is zero)
    phase_end("T1");
  endtask

  task automatic t_arith_literals();
    phase_begin("T2 arithmetic boundary literals");
    lit(F_ADD, 32'h7FFFFFFF, 32'h1, 32'h80000000);       // signed overflow wraps
    lit(F_ADD, 32'hFFFFFFFF, 32'h1, 32'h00000000);       // unsigned carry wraps
    lit(F_ADD, 32'h80000000, 32'h80000000, 32'h00000000);
    lit(F_SUB, 32'h0, 32'h1, 32'hFFFFFFFF);
    lit(F_SUB, 32'h80000000, 32'h1, 32'h7FFFFFFF);
    lit(F_SUB, 32'h7FFFFFFF, 32'hFFFFFFFF, 32'h80000000);
    lit(F_AND, 32'hF0F0F0F0, 32'hFFFF0000, 32'hF0F00000);
    lit(F_OR,  32'hF0F0F0F0, 32'h0F0F0F0F, 32'hFFFFFFFF);
    lit(F_XOR, 32'hFFFFFFFF, 32'h0F0F0F0F, 32'hF0F0F0F0);
    lit(F_SHL, 32'h1, 32'd31, 32'h80000000);
    lit(F_SHL, 32'h1, 32'd32, 32'h00000001);             // amount is b[4:0]: 32 -> 0
    lit(F_SHL, 32'hFFFFFFFF, 32'hFFFFFFE4, 32'hFFFFFFF0);// upper bits of b ignored: 4
    lit(F_SHR, 32'h80000000, 32'd31, 32'h00000001);
    lit(F_SHR, 32'h80000000, 32'd32, 32'h80000000);
    lit(F_SAR, 32'h80000000, 32'd31, 32'hFFFFFFFF);
    lit(F_SAR, 32'h80000000, 32'd32, 32'h80000000);
    lit(F_SAR, 32'h7FFFFFFF, 32'd31, 32'h00000000);
    lit(F_SLT, 32'h80000000, 32'h7FFFFFFF, 32'h1);
    lit(F_SLT, 32'h7FFFFFFF, 32'h80000000, 32'h0);
    lit(F_SLT, 32'h5, 32'h5, 32'h0);
    lit(F_SLTU, 32'h80000000, 32'h7FFFFFFF, 32'h0);
    lit(F_SLTU, 32'h0, 32'hFFFFFFFF, 32'h1);
    lit(F_MUL, 32'h00010000, 32'h00010000, 32'h0);
    lit(F_MUL, 32'hFFFFFFFF, 32'hFFFFFFFF, 32'h1);
    lit(F_MUL, 32'h80000000, 32'hFFFFFFFF, 32'h80000000);
    lit(F_MUL, 32'h80000000, 32'h80000000, 32'h0);
    lit(F_MUL, 32'h12345678, 32'h9ABCDEF0, 32'h242D2080);
    lit(F_MULH, 32'h80000000, 32'h80000000, 32'h40000000);
    lit(F_MULH, 32'hFFFFFFFF, 32'hFFFFFFFF, 32'h0);
    lit(F_MULH, 32'h7FFFFFFF, 32'h7FFFFFFF, 32'h3FFFFFFF);
    lit(F_MULH, 32'h80000000, 32'h7FFFFFFF, 32'hC0000000);
    lit(F_MULHU, 32'hFFFFFFFF, 32'hFFFFFFFF, 32'hFFFFFFFE);
    lit(F_MULHU, 32'h80000000, 32'h00000002, 32'h00000001);
    lit(F_MULHSU, 32'hFFFFFFFF, 32'hFFFFFFFF, 32'hFFFFFFFF);
    lit(F_MULHSU, 32'h80000000, 32'hFFFFFFFF, 32'h80000000);
    lit(F_MULHSU, 32'h7FFFFFFF, 32'hFFFFFFFF, 32'h7FFFFFFE);
    lit(F_MULHSU, 32'h00000001, 32'hFFFFFFFF, 32'h00000000);
    phase_end("T2");
  endtask

  // Exhaustive boundary cross-product for every ALU/MUL op and every SETP
  // condition (lane 0 sees every pair; the other lanes see rotated pairs).
  task automatic t_arith_sweep();
    int t;
    logic [LANES*32-1:0] da, db;
    phase_begin("T3 boundary cross-product sweep (R-type, imm5, SETP)");
    for (int fn = 0; fn <= 13; fn++) begin
      for (int ia = 0; ia < NV; ia++) begin
        for (int l = 0; l < LANES; l++) da[32*l +: 32] = V[(ia + l) % NV];
        xwrite(1, FULL, da);
        for (int ib = 0; ib < NV; ib++) begin
          for (int l = 0; l < LANES; l++) db[32*l +: 32] = V[(ib + 3 * l) % NV];
          xwrite(2, FULL, db);
          send(e_alu(fn, 3, 1, 2), FULL, t);
          drain();
        end
        for (int im = -16; im <= 15; im += 7) begin
          send(e_alui(fn, 4, 1, im), FULL, t);
          drain();
        end
      end
    end
    for (int c = 0; c <= 9; c++) begin
      for (int ia = 0; ia < NV; ia++) begin
        for (int l = 0; l < LANES; l++) da[32*l +: 32] = V[(ia + l) % NV];
        xwrite(1, FULL, da);
        for (int ib = 0; ib < NV; ib++) begin
          for (int l = 0; l < LANES; l++) db[32*l +: 32] = V[(ib + 3 * l) % NV];
          xwrite(2, FULL, db);
          send(e_setp(c, 1 + (ib % 7), 1, 2), FULL, t);
          drain();
        end
      end
    end
    readback_all();
    phase_end("T3");
  endtask

  // --------------------------------------------------------- latency / throughput
  task automatic t_latency();
    int t[0:31];
    int ts;
    phase_begin("T4 latency, dependency distance, throughput");
    rr_mode = 0; iss_gap_pct = 0;
    xwrite_all(1, 32'd5); xwrite_all(2, 32'd7); xwrite_all(3, 32'd9);

    // isolated instructions: accept -> result = 4 cycles (fast), 5 (MUL)
    send(e_alu(F_ADD, 10, 1, 2), FULL, t[0]);   drain();
    check(ret_cyc[t[0]] - acc_cyc[t[0]] == 4, $sformatf("fast latency %0d != 4", ret_cyc[t[0]] - acc_cyc[t[0]]));
    send(e_alu(F_MUL, 11, 1, 2), FULL, t[0]);   drain();
    check(ret_cyc[t[0]] - acc_cyc[t[0]] == 5, $sformatf("MUL latency %0d != 5", ret_cyc[t[0]] - acc_cyc[t[0]]));
    send(e_alu(F_MULH, 12, 1, 2), FULL, t[0]);  drain();
    check(ret_cyc[t[0]] - acc_cyc[t[0]] == 5, "MULH latency != 5");
    send(e_setp(0, 1, 1, 2), FULL, t[0]);       drain();
    check(ret_cyc[t[0]] - acc_cyc[t[0]] == 4, "SETP latency != 4");
    send(e_movi(13, 1234, 0, 0), FULL, t[0]);   drain();
    check(ret_cyc[t[0]] - acc_cyc[t[0]] == 4, "MOVI latency != 4");
    send(32'h0000_0000, FULL, t[0]);            drain();
    check(ret_cyc[t[0]] - acc_cyc[t[0]] == 4, "illegal latency != 4");

    // RAW distance: consumer retires 3 (fast) / 4 (MUL) cycles after the producer,
    // because it issues in the very cycle the producer commits (same-cycle forwarding)
    for (int pk = 0; pk < 2; pk++) begin           // producer fast / MUL
      for (int ck = 0; ck < 2; ck++) begin         // consumer fast / MUL
        send(e_alu(pk ? F_MUL : F_ADD, 20, 1, 2), FULL, t[0]);
        send(e_alu(ck ? F_MUL : F_ADD, 21, 20, 3), FULL, t[1]);
        drain();
        check(ret_cyc[t[1]] - ret_cyc[t[0]] == (ck ? 4 : 3),
              $sformatf("RAW gap prod=%0s cons=%0s: %0d", pk ? "MUL" : "fast", ck ? "MUL" : "fast",
                        ret_cyc[t[1]] - ret_cyc[t[0]]));
      end
    end
    // RAW through rs2 and through the guard predicate
    send(e_alu(F_ADD, 22, 1, 2), FULL, t[0]);
    send(e_alu(F_ADD, 23, 3, 22), FULL, t[1]);
    drain();
    check(ret_cyc[t[1]] - ret_cyc[t[0]] == 3, "RAW(rs2) gap != 3");
    send(e_setp(2, 1, 1, 2), FULL, t[0]);                          // p1 = (5 < 7)
    send(e_alug(F_ADD, 24, 1, 2, 1, 0), FULL, t[1]);               // @p1 ADD
    drain();
    check(ret_cyc[t[1]] - ret_cyc[t[0]] == 3, "RAW(guard) gap != 3");

    // throughput: 16 independent fast ops retire every TPUT_GAP cycles (1 for IN_DEPTH >= 2)
    for (int i = 0; i < 16; i++) send(e_alu(F_ADD, 1 + i, 20, 21), FULL, t[i]);
    drain();
    for (int i = 1; i < 16; i++)
      check(ret_cyc[t[i]] - ret_cyc[t[i-1]] == TPUT_GAP, $sformatf("throughput gap %0d != %0d at %0d", ret_cyc[t[i]] - ret_cyc[t[i-1]], TPUT_GAP, i));
    check(ret_cyc[t[0]] - acc_cyc[t[0]] == 4, "stream first-result latency != 4");
    // independent MULs are fully pipelined
    for (int i = 0; i < 8; i++) send(e_alu(F_MUL, 1 + i, 20, 21), FULL, t[i]);
    drain();
    for (int i = 1; i < 8; i++) check(ret_cyc[t[i]] - ret_cyc[t[i-1]] == TPUT_GAP, $sformatf("MUL throughput gap %0d != %0d", ret_cyc[t[i]] - ret_cyc[t[i-1]], TPUT_GAP));

    // writeback-slot structural hazard: a fast op issued exactly one cycle behind a MUL loses one cycle.
    // TPUT_GAP (= accept cadence) is 1 for IN_DEPTH >= 2. With IN_DEPTH == 1 consecutive instructions are
    // issued >= 2 cycles apart, so that collision cannot happen: the slot conflict is unreachable there and the
    // expected gaps follow from the cadence instead (ADD->MUL: cadence+1; MUL->ADD: 1; ADD->ADD after MUL: cadence).
    ts = int'(dut.cv_slot);
    send(e_alu(F_MUL, 5, 1, 2), FULL, t[0]);
    send(e_alu(F_ADD, 6, 1, 2), FULL, t[1]);
    drain();
    check(ret_cyc[t[1]] - ret_cyc[t[0]] == 1, $sformatf("MUL,ADD retire gap %0d != 1", ret_cyc[t[1]] - ret_cyc[t[0]]));
    if (TPUT_GAP == 1) check(int'(dut.cv_slot) > ts, "slot conflict not observed");
    else               check(int'(dut.cv_slot) == ts, "slot conflict observed at IN_DEPTH=1 (should be unreachable)");
    send(e_alu(F_ADD, 6, 1, 2), FULL, t[0]);
    send(e_alu(F_MUL, 5, 1, 2), FULL, t[1]);
    drain();
    check(ret_cyc[t[1]] - ret_cyc[t[0]] == TPUT_GAP + 1, $sformatf("ADD,MUL retire gap %0d != %0d", ret_cyc[t[1]] - ret_cyc[t[0]], TPUT_GAP + 1));
    // MUL, ADD, ADD: only one bubble in total
    send(e_alu(F_MUL, 5, 1, 2), FULL, t[0]);
    send(e_alu(F_ADD, 6, 1, 2), FULL, t[1]);
    send(e_alu(F_ADD, 7, 1, 2), FULL, t[2]);
    drain();
    check(ret_cyc[t[1]] - ret_cyc[t[0]] == 1 && ret_cyc[t[2]] - ret_cyc[t[1]] == TPUT_GAP, "MUL,ADD,ADD retire pattern");
    readback_all();
    phase_end("T4");
  endtask

  // ------------------------------------------------------------- forwarding sweep
  task automatic t_forwarding();
    int t, fw0;
    phase_begin("T5 forwarding / hazard sweep (distance 0..8 between producer and consumer)");
    rr_mode = 0; iss_gap_pct = 0;
    fw0 = int'(dut.cv_fwd);
    for (int i = 1; i <= 7; i++) xwrite(i, FULL, lane_vec(100 * i, 37 * i + 1));
    for (int pk = 0; pk < 2; pk++) begin
      for (int k = 0; k <= 8; k++) begin
        // producer -> k independent fillers -> consumers of every flavour
        send(e_alu(pk ? F_MUL : F_SUB, 10, 1, 2), FULL, t);
        for (int i = 0; i < k; i++) send(e_alu(F_ADD, 20 + i, 3, 4), FULL, t);
        send(e_alu(F_ADD, 11, 10, 3), FULL, t);                    // RAW rs1
        send(e_alu(F_XOR, 12, 4, 10), FULL, t);                    // RAW rs2
        send(e_alui(F_ADD, 13, 10, 1), FULL, t);                   // RAW rs1, imm
        drain();
        // predicate producer -> fillers -> guarded consumer
        send(e_setp(2, 1, 1, 2), FULL, t);
        for (int i = 0; i < k; i++) send(e_alu(F_OR, 20 + i, 3, 4), FULL, t);
        send(e_alug(F_ADD, 14, 5, 6, 1, 0), FULL, t);
        send(e_alug(F_ADD, 15, 5, 6, 1, 1), FULL, t);              // negated guard
        drain();
        // WAW: older MUL / younger fast to the same register; younger must win
        send(e_alu(F_MUL, 16, 1, 2), FULL, t);
        for (int i = 0; i < k; i++) send(e_alu(F_ADD, 20 + i, 3, 4), FULL, t);
        send(e_alu(F_ADD, 16, 3, 4), FULL, t);
        send(e_alu(F_SUB, 17, 16, 3), FULL, t);                    // reads the younger value
        drain();
        // WAR: reader of r5 then writer of r5 -- reader must see the old value
        send(e_alu(F_ADD, 18, 5, 5), FULL, t);
        for (int i = 0; i < k; i++) send(e_alu(F_ADD, 20 + i, 3, 4), FULL, t);
        send(e_alu(F_MUL, 5, 1, 2), FULL, t);
        send(e_alu(F_ADD, 19, 5, 3), FULL, t);
        drain();
        xwrite(5, FULL, lane_vec(500, 11));                        // restore r5
      end
    end
    readback_all();
    check(int'(dut.cv_fwd) > fw0, "same-cycle forwarding was never exercised");
    $display("     same-cycle forwards observed: %0d", int'(dut.cv_fwd) - fw0);
    phase_end("T5");
  endtask

  // ------------------------------------------------------------ masked execution
  task automatic t_masking();
    int t;
    logic [LANES-1:0] pats [0:7];
    phase_begin("T6 predicate / execution-mask handling");
    rr_mode = 0; iss_gap_pct = 0;
    pats[0] = '0;  pats[1] = FULL;  pats[2] = LANES'(1);  pats[3] = LANES'(1) << (LANES - 1);
    pats[4] = {LANES{2'b01}};  pats[5] = {LANES{2'b10}};  pats[6] = LANES'(32'h5A5A_5A5A);  pats[7] = ~LANES'(1);
    for (int i = 1; i <= 7; i++) xwrite(i, FULL, lane_vec(10 * i, 7 + i));
    for (int pi = 0; pi < 8; pi++) begin
      // issue mask only
      send(e_alu(F_ADD, 8, 1, 2), pats[pi], t);
      send(e_alu(F_MUL, 9, 1, 2), pats[pi], t);
      send(e_setp(2, 1 + (pi % 7), 1, 2), pats[pi], t);          // masked predicate write
      send(e_movi(10, 16'h8000, 0, 0), pats[pi], t);
      drain();
      // guard x issue mask (guard predicates come from lane-varying compares)
      send(e_setp(2, 1, 2, 3), FULL, t);                         // p1 = r2 < r3
      send(e_setp(4, 2, 2, 3), FULL, t);                         // p2 = r2 > r3
      for (int g = 0; g <= 2; g++) begin
        for (int n = 0; n < 2; n++) begin
          send(e_alug(F_ADD, 11, 1, 2, g, n[0]), pats[pi], t);
          send(e_alug(F_MUL, 12, 1, 2, g, n[0]), pats[pi], t);
          send(e_setpg(0, 3, 1, 1, g, n[0]), pats[pi], t);
          send(e_movi(13, 16'h1111 * (g + 1), g, n[0]), pats[pi], t);
        end
      end
      drain();
      readback_all();                                            // untouched lanes must be intact
    end
    // fully masked and r0 / p0 destinations still retire exactly once
    send(e_alu(F_ADD, 0, 1, 2), FULL, t);
    send(e_setp(0, 0, 1, 2), FULL, t);
    send(e_alug(F_ADD, 3, 1, 2, 0, 1), FULL, t);                  // !@PT : never executes
    send(e_alu(F_MUL, 0, 1, 2), FULL, t);
    drain();
    check(last_ret.dkind == 0 && last_ret.wmask == 0, "r0 destination reported a write");
    readback_all();
    phase_end("T6");
  endtask

  // -------------------------------------------------------- illegal / NOP
  task automatic t_illegal();
    int t;
    logic [31:0] bad [0:8];
    phase_begin("T7 illegal words and NOP");
    rr_mode = 0; iss_gap_pct = 0;
    bad[0] = 32'h0000_0000;                       // ILLEGAL opcode
    bad[1] = 32'hFC00_0000;                       // reserved opcode 0x3F
    bad[2] = e_r(8, 3, 1, 2, 14, 0, 0, 0);        // ALU_R funct 14
    bad[3] = e_r(56, 1, 1, 2, 10, 0, 0, 0);       // SETP cond 10
    bad[4] = e_r(56, 9, 1, 2, 0, 0, 0, 0);        // SETP pd > 7
    bad[5] = 32'h0400_0001;                       // NOP with reserved bits
    bad[6] = {6'd57, 5'd3, 5'b10000, 16'h1};      // MOVI with G[4]
    bad[7] = {6'd16, 5'd10, 5'd10, 5'd10, 11'd0}; // VPU opcode: not handled by this core
    bad[8] = e_r(63, 10, 10, 10, 0, 0, 0, 0);     // illegal word naming a pending register
    xwrite_all(1, 32'd3); xwrite_all(2, 32'd4);
    for (int i = 0; i < 9; i++) begin
      int tm;
      send(e_alu(F_MUL, 10, 1, 2), FULL, tm);     // r10 pending while the illegal word issues
      send(bad[i], FULL, t);
      drain();
      // an illegal word never waits on the scoreboard: it retires right behind the MUL
      // (fast path + one-cycle writeback-slot bubble), not 3-4 cycles later like a consumer
      check(ret_cyc[t] - ret_cyc[tm] <= 1, $sformatf("illegal word %0d waited on a hazard (gap %0d)", i, ret_cyc[t] - ret_cyc[tm]));
    end
    send(NOP_W, FULL, t); drain();
    check(!last_ret.illegal && last_ret.dkind == 0, "NOP result");
    send(e_alu(F_ADD, 5, 1, 2), FULL, t); drain();
    readback_all();
    check(n_illegal_seen >= 9, $sformatf("illegal count %0d", n_illegal_seen));
    phase_end("T7");
  endtask

  // ------------------------------------------------- stalls & backpressure
  logic sender_done;
  task automatic t_stalls();
    int t, acc0, held_acc, n_send;
    int hold_cycles;
    logic [TAG_W-1:0] snap_tag;
    phase_begin("T8 result backpressure and input FIFO back-pressure");
    iss_gap_pct = 0;
    xwrite_all(1, 32'd5); xwrite_all(2, 32'd7);

    // (a) hold res_ready low while a producer keeps offering instructions
    rr_mode = 2;
    sender_done = 0;
    acc0 = n_acc;
    n_send = 24;
    fork
      begin : sender
        int tt;
        for (int i = 0; i < n_send; i++) begin
          // chain through r3 -> serialises on the scoreboard as well
          send(e_alu((i % 3 == 0) ? F_MUL : F_ADD, 3 + (i % 5), 1 + (i % 2), 2), FULL, tt);
        end
        sender_done = 1;
      end
    join_none
    wait_cycles(60);
    held_acc = n_acc - acc0;
    check(!sender_done, "producer never saw back-pressure");
    check(!iss_ready, "iss_ready still high while the core is stalled and full");
    check(res_valid, "result channel not holding a result during the stall");
    check(held_acc <= IN_DEPTH + 4, $sformatf("accepted %0d instructions during a stall (too many)", held_acc));
    $display("     accepted while stalled: %0d (IN_DEPTH=%0d); retired: %0d", held_acc, IN_DEPTH, n_ret);
    // payload must be held for the whole stall (SVA a_res_hold also checks)
    snap_tag = res_tag;
    wait_cycles(10);
    check(res_tag == snap_tag, "result tag moved during stall");
    rr_mode = 0;
    while (!sender_done) @(negedge clk);
    drain();
    check(n_acc - acc0 == n_send, "accepted count mismatch");
    readback_all();

    // (b) short random stalls interleaved with a dependent stream
    for (int pct = 20; pct <= 90; pct += 35) begin
      rr_mode = 1; rr_pct = pct; iss_gap_pct = pct / 2;
      for (int i = 0; i < 60; i++)
        send(e_alu(rnd_n(14), 1 + rnd_n(4), rnd_n(5), rnd_n(5)), FULL, t);
      drain();
    end
    rr_mode = 0; iss_gap_pct = 0;
    readback_all();
    phase_end("T8");
  endtask

  // ---------------------------------------------------- external write port
  task automatic t_xw();
    int t, blocked0, tm;
    phase_begin("T9 external register write: arbitration and hazards");
    rr_mode = 0; iss_gap_pct = 0;
    xwrite_all(1, 32'd5); xwrite_all(2, 32'd7);

    // (a) write to a register with a MUL still in flight is refused until it retires
    send(e_alu(F_MUL, 6, 1, 2), FULL, tm);
    xw_valid = 1; xw_rd = 6; xw_mask = FULL; xw_data = lane_vec(777, 1);
    blocked0 = 0;
    @(posedge clk);
    while (!xw_ready) begin blocked0++; @(posedge clk); end
    check(blocked0 >= 3, $sformatf("xw to a pending register accepted after only %0d cycles", blocked0));
    @(negedge clk); xw_valid = 0;
    drain();
    readback_all();                                   // r6 must hold the xw value (xw is younger)

    // (b) write while W holds a stalled GPR result is refused
    rr_mode = 2;
    send(e_alu(F_ADD, 7, 1, 2), FULL, t);
    wait_cycles(8);
    check(res_valid, "no result at W");
    xw_valid = 1; xw_rd = 9; xw_mask = FULL; xw_data = lane_vec(4242, 3);
    wait_cycles(4);
    check(!xw_ready, "xw_ready high while W holds a GPR result");
    rr_mode = 0;
    @(posedge clk);
    while (!xw_ready) @(posedge clk);
    @(negedge clk); xw_valid = 0;
    drain();
    readback_all();

    // (c) write to r0 is accepted and dropped: r0 must still read zero through both operand ports
    xwrite(0, FULL, lane_vec(99, 1));
    send(e_alu(F_OR, 5, 0, 0), FULL, t);
    drain();
    for (int l = 0; l < LANES; l++)
      check(last_ret.data[32*l +: 32] === 32'd0, $sformatf("r0 read %08x on lane %0d after an external write to r0", last_ret.data[32*l +: 32], l));
    send(e_alu(F_ADD, 6, 3, 0), FULL, t);                                // r0 as rs2
    send(e_alu(F_ADD, 7, 0, 3), FULL, t);                                // r0 as rs1
    drain();
    readback_all();

    // (d) concurrent: stream of independent ALU ops + xw writes to other registers
    blocked0 = int'(dut.cv_xw_block);
    fork
      begin : stream
        int tt;
        for (int i = 0; i < 80; i++) send(e_alu(F_ADD, 10 + (i % 10), 1, 2), FULL, tt);
      end
      begin : writer
        for (int i = 0; i < 12; i++) begin
          xwrite(21 + (i % 7), (i % 3 == 0) ? FULL : LANES'(32'hA5A5_A5A5), lane_vec(1000 * i + 1, i + 1));
          wait_cycles(rnd_n(6));
        end
      end
    join
    drain();
    readback_all();
    $display("     xw blocked cycles during concurrent traffic: %0d", int'(dut.cv_xw_block) - blocked0);
    phase_end("T9");
  endtask

  // -------------------------------------------------- reset during activity
  function automatic logic [LANES-1:0] rand_mask();
    case (rnd_n(8))
      0: return '0;
      1, 2, 3: return FULL;
      default: return LANES'(rnd());
    endcase
  endfunction

  function automatic logic [31:0] rand_insn();
    int k, fn, rd, a, b, g, pd;
    bit neg;
    k = rnd_n(100);
    rd = rnd_n(8); a = rnd_n(8); b = rnd_n(8);
    g = (rnd_n(100) < 40) ? 1 + rnd_n(7) : 0;
    neg = rnd_n(2);
    if (k < 52)      return e_alug(rnd_n(14), rd, a, b, g, neg);
    else if (k < 68) return e_r(8, rd, a, rnd_n(32), rnd_n(14), g, neg, 1);
    else if (k < 84) return e_r(56, 1 + rnd_n(7), a, b, rnd_n(10), g, neg, rnd_n(2));
    else if (k < 90) return e_movi(rd, int'(rnd() & 16'hFFFF), g, neg);
    else if (k < 94) return e_lui(rd, int'(rnd() & 16'hFFFF), g, neg);
    else if (k < 97) return NOP_W;
    else             return rnd();                       // random word, mostly illegal
  endfunction

  task automatic t_reset_activity(input int iters);
    int t, n, nbusy;
    bit kill;
    phase_begin("T10 reset during activity");
    for (int it = 0; it < iters; it++) begin
      kill = (it % 2 == 0);
      rr_mode = (it % 3 == 0) ? 1 : 0; rr_pct = 50; iss_gap_pct = (it % 4 == 1) ? 30 : 0;
      for (int i = 1; i <= 7; i++) xwrite(i, FULL, lane_vec(rnd() & 32'hFFFF, 3 * i + it));
      abort_send = 0;
      fork
        begin : stream
          for (int i = 0; i < 40; i++) begin
            int tt;
            send(rand_insn(), rand_mask(), tt);
            if (abort_send) break;
          end
        end
      join_none
      wait_cycles(1 + rnd_n(14));
      // assert reset in the middle of the stream
      if (kill) abort_send = 1;
      rst_n = 1'b0;
      if (kill) begin @(negedge clk); iss_valid = 1'b0; end
      repeat (1 + rnd_n(3)) @(negedge clk);
      check(!res_valid && !iss_ready && !xw_ready, "outputs active during reset");
      rst_n = 1'b1;
      abort_send = 0;
      // clear sequence: busy for 32 cycles, ready low throughout
      nbusy = 0;
      @(posedge clk);
      while (busy) begin
        nbusy++;
        if (iss_ready || xw_ready) fail("ready during clear after reset");
        @(posedge clk);
      end
      check(nbusy == 32, $sformatf("clear sequence %0d cycles != 32", nbusy));
      if (kill) begin
        // the producer abandoned its stream: everything must be quiet and zero
        @(negedge clk);
        drain();
        readback_all();                                        // all zero, scoreboard clean
        // scoreboard must be empty: dependent code runs without waiting on ghosts
        send(e_movi(1, 5, 0, 0), FULL, t);
        send(e_alu(F_MUL, 2, 1, 1), FULL, t);
        send(e_alu(F_ADD, 3, 2, 1), FULL, t);
        drain();
        check(last_ret.data[31:0] === 32'd30 || last_ret.wmask == 0, "post-reset dependent chain wrong");
      end else begin
        // stream continues across the reset (instruction offered during reset is accepted afterwards)
        while (infl_q.size() > 0 || !idle) @(negedge clk);
        @(negedge clk);
      end
      // let the forked stream finish before the next iteration
      wait_cycles(3);
      if (!kill) begin
        // make sure the background stream is done (it is bounded to 40 sends)
        drain();
      end
      abort_send = 1; wait_cycles(2); abort_send = 0;
      drain();
    end
    rr_mode = 0; iss_gap_pct = 0;
    readback_all();
    phase_end("T10");
  endtask

  // ------------------------------------------------------------ random stress
  task automatic t_random(input int n_instr);
    int t, done;
    phase_begin("T11 constrained-random stress with random back-pressure");
    for (int round = 0; round < 6; round++) begin
      rr_mode = (round % 3 == 0) ? 0 : 1;
      rr_pct  = (round == 1) ? 15 : (round == 4) ? 70 : 45;
      iss_gap_pct = (round % 2) ? 25 : 0;
      for (int i = 1; i <= 7; i++) begin
        logic [LANES*32-1:0] d;
        for (int l = 0; l < LANES; l++) d[32*l +: 32] = (rnd_n(3) == 0) ? V[rnd_n(NV)] : rnd();
        xwrite(i, FULL, d);
      end
      for (int i = 0; i < n_instr / 6; i++) begin
        send(rand_insn(), rand_mask(), t);
        if (rnd_n(97) == 0) begin                       // occasional quiesce + re-initialise
          drain();
          xwrite(1 + rnd_n(7), rand_mask(), lane_vec(int'(rnd()), int'(rnd())));
        end
      end
      drain();
      readback_all();
    end
    rr_mode = 0; iss_gap_pct = 0;
    phase_end("T11");
  endtask

  // ----------------------------------------------------------------------- main
  int iters_arg, seed_arg;
  initial begin
    iters_arg = 20; seed_arg = 1;
    void'($value$plusargs("iters=%d", iters_arg));
    void'($value$plusargs("seed=%d", seed_arg));
    rng_s = 32'h9E37_79B9 ^ 32'(seed_arg * 32'h0101_0101 + 1);
    $display("tb_sfg1_directed: LANES=%0d IN_DEPTH=%0d RF_BRAM=%0d seed=%0d", LANES, IN_DEPTH, RF_BRAM, seed_arg);

    @(negedge clk);
    t_reset_clear();
    t_arith_literals();
    t_arith_sweep();
    t_latency();
    t_forwarding();
    t_masking();
    t_illegal();
    t_stalls();
    t_xw();
    t_reset_activity(iters_arg);
    t_random(1800);

    drain();
    $display("SUMMARY: accepted=%0d retired=%0d dropped_by_reset=%0d xw=%0d resets=%0d cycles=%0d",
             n_acc, n_ret, n_drop, n_xw, n_rst, cyc);
    check(n_acc == n_ret + n_drop, "accepted != retired + dropped at end");
    if (errors == 0) begin
      $display("TB_RESULT: PASS (LANES=%0d IN_DEPTH=%0d RF_BRAM=%0d)", LANES, IN_DEPTH, RF_BRAM);
      $finish;
    end else begin
      $display("TB_RESULT: FAIL (%0d errors)", errors);
      $fatal(1, "directed testbench failed");
    end
  end
endmodule
