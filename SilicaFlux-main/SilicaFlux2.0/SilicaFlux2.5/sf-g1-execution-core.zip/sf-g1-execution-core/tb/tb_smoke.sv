module tb_smoke;
  parameter int LANES = 4;
  parameter int TAG_W = 16;
  parameter int IN_DEPTH = 2;
  parameter bit RF_BRAM = 1'b0;
  `include "sfg1_tb_common.svh"
  initial begin
    int t0, t1, t2;
    @(negedge clk); @(negedge clk);
    rst_n = 1'b1;
    // busy duration
    begin
      int n = 0;
      @(negedge clk);
      while (busy) begin n++; @(negedge clk); end
      $display("busy cycles (observed at negedges) = %0d", n);
    end
    xwrite_all(1, 32'd5); xwrite_all(2, 32'd7);
    rr_mode = 0;
    send(e_alu(F_ADD, 3, 1, 2), FULL, t0);
    drain();
    $display("ADD lat acc->ret = %0d", ret_cyc[t0]-acc_cyc[t0]);
    send(e_alu(F_MUL, 4, 1, 2), FULL, t1);
    drain();
    $display("MUL lat acc->ret = %0d", ret_cyc[t1]-acc_cyc[t1]);
    send(e_alu(F_ADD, 5, 3, 4), FULL, t1);   // depends on r3 r4 (already retired)
    send(e_alu(F_ADD, 6, 5, 5), FULL, t2);   // RAW on r5
    drain();
    $display("dep fast->fast retire gap = %0d", ret_cyc[t2]-ret_cyc[t1]);
    $display("errors=%0d acc=%0d ret=%0d", errors, n_acc, n_ret);
    $finish;
  end
endmodule
