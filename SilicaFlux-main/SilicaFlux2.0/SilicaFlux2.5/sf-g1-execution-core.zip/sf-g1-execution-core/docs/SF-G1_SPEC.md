# SF-G1 Execution Core — Minimal Specification (v0.1, assumed)

## 0. Status of the SF-G1 specification  ← read this first

**The "previously defined SF-G1 ISA and configuration" was not available to this work.**
The repository the work was done in (`Aureom.AI`) was searched for `SF-G1` / `SFG1` / `SF_G1` in every
text file, in every PDF (via `pdftotext`) and inside every `.zip` it contains. The only matches were
binary/base64 coincidences inside image data (e.g. `silicaflux-memoryflow.zip`, `silicaflux-powerlink.zip`,
`SilicaFlux ThermalLab (1).zip`, an Aardvark JSON snapshot). No file defines an SF-G1 instruction set,
register model, or configuration.

What *does* exist, and what was used as the anchor:

| Artefact | Used for |
|---|---|
| `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/sfx_asm.py` — "the normative definition of the SilicaFlux **v1** instruction encoding" | `ALU_R` opcode `0x08`, funct6 `0x00–0x0A` (ADD, SUB, MUL, AND, OR, XOR, SHL, SHR, SAR, SLT, SLTU), `NOP`=`0x01`, `ILLEGAL`=`0x00`, `LUI`=`0x0F`, `r0`≡0 (writes discarded), 32 scalar registers, 32-bit data, shift amount = `rs2[4:0]` |
| `SilicaFlux-main/alu.sf` (scalar out-of-order ALU) | Consulted only. It has N/Z/C/V flags and optional saturation; **neither is adopted** (see §2, "Not implemented") |
| `register_bank.sf`, `forwarding_unit.sf` | Consulted for vocabulary (write-through vs. forwarding); not reused |

**No SF-G1 Python simulator was found either.** The "Python simulator" used for differential testing is therefore new:
`python/sfg1/sim.py` (an architectural/ISA-level model; deliberately written with plain Python big-int arithmetic so that
its structure differs from the RTL). Its own unit tests use hand-computed literal expectations, not model output.

**Compatibility that is tested, not just claimed:** `python/tests/test_isa_sim.py::test_sfx_v1_alu_encoding_compat`
assembles `ADD/SUB/MUL/AND/OR/XOR/SHL/SHR/SAR/SLT/SLTU r3, r1, r2` with the repository's own `sfx_asm.py`
and requires byte-identical words to this project's encoder (it passed; the test is skipped when
`sfx_asm.py` is not reachable — set `SFX_ASM=/path/to/sfx_asm.py`).

Everything else in this document — SIMT lanes, execution mask, guard predicates, `SETP`, `MOVI`, the
`imm5` flag, the channel signals and tags — is an **assumption** introduced here so that a complete,
testable core could be built. If the real SF-G1 specification exists it must be reconciled against
§1 (assumption list) and §3 (encoding); the RTL is parameterised/structured so that the decode
(`sfg1_decode.sv`) and `python/sfg1/isa.py` are the only places that encode the ISA.

## 1. Assumptions (explicit)

| # | Assumption |
|---|---|
| A1 | **SIMT execution core.** One instruction per cycle is issued to `LANES` identical lanes (`LANES ≥ 1`, any value, default 8). Each lane has private copies of all registers. |
| A2 | Lane data width is 32 bits. Integer only. |
| A3 | A **front end** (outside this core) supplies, with each instruction, an *active lane mask* (`iss_mask`). Divergence/convergence stacks, warps, branches and memory operations live outside the core. Opcodes the core does not implement decode as illegal. |
| A4 | The front end also supplies an opaque **tag** (`iss_tag`) that is returned unchanged with the result. |
| A5 | Per lane: 32 GPRs (`r0` reads 0, writes discarded) and 8 predicate registers (`p0` = constant true "PT", writes discarded; `p1..p7` writable), 1 bit per lane. |
| A6 | An **external write channel** (`xw_*`) exists to inject operand data into GPRs (stand-in for a load/DMA return path, and what lets tests create lane-varying data). |
| A7 | A **result channel** (`res_*`) reports every retired instruction. It is the architectural commit point. |
| A8 | One in-flight context (no multithreading across warps). |
| A9 | Results of independent instructions may complete out of order (fast path vs. multiplier); results to the *same register* always complete in program order. |
| A10 | Reset is synchronous, active low, and destroys all in-flight work. |

## 2. Architectural semantics

### 2.1 Instruction formats (32-bit words, little-endian bit numbering as in SFX v1)

```
R-type  (ALU_R 0x08, SETP 0x38)
 31    26 25   21 20   16 15   11 10 9 8   6 5      0
+--------+-------+-------+-------+--+--+-----+--------+
| opcode |  rd   |  rs1  |rs2/imm| I| N|  P  | funct6 |      D field = insn[10:6] = {I, N, P[2:0]}
+--------+-------+-------+-------+--+--+-----+--------+

I16-type (MOVI 0x39, LUI 0x0F)
+--------+-------+-+-+-----+----------------------+
| opcode |  rd   |0|N|  P  |        imm16         |        G field = insn[20:16] = {0, N, P[2:0]}
+--------+-------+-+-+-----+----------------------+
```

* `P` selects the **guard predicate** (0 = PT, always true); `N` negates it. `N=1,P=0` (`!@PT`) is a legal "never execute".
* `I=1` makes operand B the **sign-extended 5-bit immediate** in `insn[15:11]` instead of `RF[rs2]`.
  (The assembler additionally accepts shift amounts 16..31 as the same 5-bit field; non-shift ops accept −16..15.)
* An SFX-v1 `ALU_R` word with a zero D field is a valid SF-G1 instruction (guard PT, register B).

### 2.2 Opcode map

| opcode | mnemonic | notes |
|---|---|---|
| `0x00` | ILLEGAL | any bits |
| `0x01` | NOP | bits [25:0] must be 0, else illegal |
| `0x08` | ALU_R | `rd = rs1 ∘ B`, funct6 below; funct6 > 13 illegal |
| `0x0F` | LUI | `rd = imm16 << 16` |
| `0x38` | SETP | `pd = rd[2:0] = rs1 ⋈ B`; `rd[4:3]` must be 0; funct6 = condition (0–9), else illegal |
| `0x39` | MOVI | `rd = sign_extend(imm16)` |
| other | — | illegal (the core handles only the integer-ALU functional unit) |

Reserved bits (`LUI/MOVI` G[4]; `NOP` payload) must be zero or the word is illegal.
An **illegal word is inert**: no registers read, no destination, no guard, never causes a hazard; it
still occupies one pipeline slot and retires exactly once with `res_illegal=1`.

### 2.3 ALU_R functions (funct6) — signedness, overflow, shifts

| funct6 | op | result (per active lane) | signedness / overflow / edge behaviour |
|---|---|---|---|
| 0x00 | ADD | `A + B` mod 2³² | two's complement; **wraps silently**. No trap, no saturation, no sticky flag. `0x7FFFFFFF+1=0x80000000`, `0xFFFFFFFF+1=0` |
| 0x01 | SUB | `A − B` mod 2³² | wraps. `0−1=0xFFFFFFFF`, `0x80000000−1=0x7FFFFFFF` |
| 0x02 | MUL | low 32 bits of `A×B` | identical for signed and unsigned operands |
| 0x03/04/05 | AND/OR/XOR | bitwise | — |
| 0x06 | SHL | `A << B[4:0]` | amount is the **low 5 bits of B**; B[31:5] ignored; amount 32 ≡ 0 (no saturation to zero) |
| 0x07 | SHR | `A >> B[4:0]` logical | zero fill |
| 0x08 | SAR | `A >>> B[4:0]` arithmetic | sign fill; `0x80000000>>>31=0xFFFFFFFF` |
| 0x09 | SLT | `1` if `signed(A) < signed(B)` else `0` | 32-bit 0/1 |
| 0x0A | SLTU | `1` if `A < B` unsigned else `0` | 32-bit 0/1 |
| 0x0B | MULH | high 32 bits of `signed(A)×signed(B)` | `INT_MIN×INT_MIN → 0x40000000` |
| 0x0C | MULHU | high 32 bits of `A×B` unsigned | `0xFFFFFFFF² → 0xFFFFFFFE` |
| 0x0D | MULHSU | high 32 bits of `signed(A)×unsigned(B)` | `−1×0xFFFFFFFF → 0xFFFFFFFF` |

`SETP` conditions (funct6): `0 EQ, 1 NE, 2 LT, 3 LE, 4 GT, 5 GE` (signed), `6 LTU, 7 LEU, 8 GTU, 9 GEU`
(unsigned). The 1-bit result is written to predicate `pd`; `SETP p0,…` computes and discards.

`MOVI` sign-extends its 16-bit immediate (`MOVI r1, 0x8000` → `0xFFFF8000`); `LUI` places it in the upper half.

**There is no carry/overflow/zero/negative flag register.** Carry and signed overflow are recoverable
with `SLTU`/`SLT`-style compares (e.g. unsigned carry-out of `s = a+b` ⇔ `SLTU(s, a)`).
**Not implemented** (deliberately, not forgotten): saturating arithmetic (the SFX `alu.sf` `SAT_EN`),
condition flags, division/remainder, 64-bit operations, floating point, byte/half-word forms, branches, memory.

### 2.4 Predicates and execution mask

```
guard[k]  = (P == 0 ? 1 : p_P[k]) XOR N
active[k] = iss_mask[k] AND guard[k]            -- the "effective mask"
```
* Only lanes with `active[k]=1` compute, write the destination register, write the destination predicate, and
  appear in `res_mask`. **A lane that is not active is never written and never forwarded to.**
* `res_mask` is the set of lanes actually written: it is `0` whenever the destination is discarded
  (`r0`, `p0`), the instruction is a NOP, or it is illegal. A fully masked instruction still retires.
* The guard predicate is a normal register read: a pending write to it is a RAW hazard.

### 2.5 Result record (one per accepted instruction)

`{tag, dkind (0 none / 1 GPR / 2 PRED), rd, mask, data[LANES], illegal}` — `data` is meaningful only on lanes
with `mask[k]=1`; for a `PRED` destination `data[k]` is bit 0 (0 or 1).

## 3. Interfaces (ready/valid) and transaction ownership

All signals are sampled on the rising edge of `clk`. A transfer happens on a cycle where `valid && ready`.
While `rst_n` is low **no transfer can complete** (all three `ready`/`valid` outputs are forced low).

| channel | direction | signals | payload ownership |
|---|---|---|---|
| **issue** | front end → core | `iss_valid`, `iss_ready`, `iss_insn[31:0]`, `iss_mask[LANES]`, `iss_tag[TAG_W]` | Producer owns the payload until `valid&&ready`; it **must hold `valid` and all payload bits stable until accepted** (no retraction). Acceptance transfers ownership to the core. From then on the core guarantees **exactly one result transaction** for it, unless reset intervenes. `iss_ready` depends only on registered state and `xw_valid` — never on `iss_valid` or the payload. |
| **result** | core → consumer | `res_valid`, `res_ready`, `res_tag`, `res_dkind`, `res_rd`, `res_mask`, `res_data`, `res_illegal` | Core owns the payload while `valid && !ready`: it is **held stable, never retracted** (checked by an SVA). Acceptance transfers ownership to the consumer **and is the architectural commit**: the register/predicate write and the scoreboard release happen in that same cycle. `res_ready` may be deasserted for any number of cycles. |
| **external write** | agent → core | `xw_valid`, `xw_ready`, `xw_rd`, `xw_mask`, `xw_data` | Producer owns the payload until accepted and must hold it stable. `xw_ready` may depend combinationally on `xw_rd` (pending-writer check). Writes to `r0` are accepted and dropped. |
| status | core → | `busy` (RF clear running after reset, 32 cycles), `idle` (no accepted instruction still in flight) | — |

**Ordering rules**
1. Instructions issue to the datapath in the order accepted.
2. A result for register R retires after the results of all older instructions that write R.
3. Results of independent instructions may retire out of order (a fast op can overtake an older MUL). The
   `tag` identifies them.
4. **The external write is ordered against the issue channel.** It is accepted only when the input FIFO is
   empty (every previously accepted instruction has already issued, so none can read the old value late or
   overwrite the new one later), no issued instruction still has a write to `xw_rd` in flight, and the
   pipeline is not using the GPR write port. While `xw_valid` is high `iss_ready` is held low so a continuous
   instruction stream cannot starve it. Instructions accepted after the external write see its data.
5. **Reset** drops every instruction that has not yet produced its result transaction (including those
   queued at the input). The producer must treat those as void. After reset all architectural registers
   are zero (see §5 of the microarchitecture document for the 32-cycle clear sequence).

## 4. Latency and throughput (verified by directed tests, `tb_sfg1_directed` T4)

Measured in cycles from the cycle the instruction is *accepted* (`iss_valid&&iss_ready`) to the cycle its
result handshake is sampled, with `res_ready=1` and an empty pipeline:

| instruction class | accept → result | issue → result (issue = leaves the input FIFO) |
|---|---|---|
| ADD/SUB/logic/shift/SLT/SLTU/SETP/MOVI/LUI/NOP/illegal | **4** | 3 |
| MUL / MULH / MULHU / MULHSU | **5** | 4 |

| scenario | result |
|---|---|
| Dependent instruction (RAW through rs1, rs2 or the guard), consumer fast | retires **3** cycles after the producer's result (fast or MUL producer) |
| Dependent consumer is a MUL | retires **4** cycles after the producer's result |
| Independent fast instructions | 1 result per cycle (throughput 1.0) |
| Independent MULs | 1 result per cycle (fully pipelined) |
| MUL immediately followed by an independent fast op | the fast op retires 1 cycle after the MUL (one-cycle writeback-slot bubble) |
| fast op immediately followed by a MUL | MUL retires 2 cycles later (no bubble) |
| `res_ready` low | whole pipeline freezes; input FIFO fills then `iss_ready` drops |

A consumer may *issue* in the same cycle its producer commits (same-cycle release + same-cycle forwarding),
which is what produces the 3/4-cycle distances.

## 5. Configuration

| parameter | default | meaning |
|---|---|---|
| `LANES` | 8 | lane count, any integer ≥ 1 (verified at 1, 2, 3, 4, 8, 16, 32) |
| `TAG_W` | 8 | tag width (pass-through) |
| `IN_DEPTH` | 2 | input FIFO depth ≥ 1 (verified 1, 2, 4). Depth 1 halves the peak rate (`iss_ready` is registered occupancy and cannot rise in the cycle the single slot frees): measured, independent instructions retire every 2 cycles instead of every cycle |
| `RF_BRAM` | 0 | 0 = LUTRAM register file, 1 = block-RAM-style (`ram_style="block"`) |

Fixed by the spec: 32-bit lanes, 32 GPRs, 8 predicates.
