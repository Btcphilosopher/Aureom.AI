# SF-G1 Execution Core — Micro-architecture

Companion to `SF-G1_SPEC.md` (read its §0: the SF-G1 spec was not available; ISA and interfaces here are
*assumed*). Source of truth is the RTL in `../rtl`; every behavioural statement below is covered by a test
(see `VERIFICATION.md`) or an assertion (`rtl/sfg1_core_checks.svh`).

## 1. Block diagram

```
 iss_* ──► [ input FIFO IB, IN_DEPTH ]──► I ────────► O ────────► X ────────► M ────────► W ──► res_*
 (valid/                                  │decode     │operand    │fast ALU    │product     │result reg
  ready)                                  │hazard chk │select     │SETP cmp    │register    │= result channel
                                          │RF read    │guard→mask │multiplier  │(MUL only)  │RF commit on
                                          │ launch    │dispatch   │ array      │            │ res_valid&&res_ready
                                          ▼           ▲
                                   ┌─ scoreboard ◄────┼──────────── set at issue, clear at commit
                                   └─ regfile (per-lane: 2 RAMs + bypass) ──► rdata (valid in O)
 xw_* ──► ordering / arbitration ──► RF write port (shared with W commit)
```

Files: `sfg1_decode` (comb decode) · `sfg1_fifo` (input buffer) · `sfg1_scoreboard` · `sfg1_regfile` +
`sfg1_gpr_ram` (per-lane memories, bypass, predicate file, clear sequencer) · `sfg1_lane` + `sfg1_lane_alu`
(operand select, X regs, ALU, multiplier, W data) · `sfg1_core` (pipeline control, arbitration, channels).

## 2. Pipeline and timing

| stage | what happens (all lanes in parallel) |
|---|---|
| **IB** | 2-entry (default) shift FIFO. `iss_ready = rst_n & ~busy & ~full & ~xw_valid` — registered occupancy only; independent of `iss_valid` and the payload. |
| **I** | Decode the FIFO head; scoreboard hazard check; if clear and the O stage is free: pop the FIFO, set the destination's pending bit, **launch the register-file read** (rs1, rs2, guard predicate). |
| **O** | Register data (incl. same-cycle forwarded data) is available. Operand select (`a_imm`/`b_imm` mux). Guard → effective mask = `iss_mask & (guard ^ neg)`. Dispatch to X, or hold one cycle on a writeback-slot conflict (§4). |
| **X** | Operands registered. Fast ALU / `SETP` comparator result is computed → W register. A MUL's 33×33 product is computed → M register. |
| **M** | Product register (MUL only). Hi/lo word is selected into W. |
| **W** | Result register **is** the result channel. The register/predicate write and the scoreboard release **commit in the cycle `res_valid && res_ready`**. |

Cycle example, `ADD r3,…` (P) accepted in cycle *a*, dependent `ADD r4,r3,…` (C) accepted in *a+1*:

| cycle | a+1 | a+2 | a+3 | a+4 | a+5 | a+6 | a+7 |
|---|---|---|---|---|---|---|---|
| P | I (issue, pend r3) | O | X | **W: commit, res handshake** | | | |
| C | in FIFO | I: hazard (r3 pending) | I: hazard | **I: issues — r3 released this cycle, RF read launched, write data forwarded** | O (forwarded r3) | X | **W: result** |

C's result arrives 3 cycles after P's: the figure in the spec's latency table.

**Global freeze.** `stall = w_valid & ~res_ready`. While stalled every stage register, the RF read registers
and the scoreboard hold; nothing issues. Only the input FIFO keeps accepting (until it is full, then
`iss_ready` falls). A stall cycle is a pure no-op cycle, so back-pressure cannot lose, duplicate or reorder
instructions (SVA: `a_freeze`, `a_stall_no_issue`, `a_res_hold`, `a_conserve`).
Cost: `res_ready` fans out combinationally to all stage-enable signals; a registered result skid buffer is
the standard way to cut that path if it becomes critical.

## 3. Hazards and the scoreboard

* **Granularity**: one pending bit per GPR `r1..r31` and predicate `p1..p7` (not per lane — one instruction
  is issued for all lanes; a masked instruction still marks the whole register pending).
* **RAW**: rs1, rs2 (if used) and the guard predicate (if `P≠0`) must not be pending.
* **WAW**: the destination must not be pending. Needed because the MUL path (one stage longer) would otherwise
  let a younger fast write overtake an older MUL write to the same register.
* **WAR** cannot occur: operands are read at issue, in order.
* **Same-cycle release**: a commit in the current cycle hides its pending bit from the hazard check, so a
  consumer can issue in the very cycle its producer commits. If a set (issue) and a clear (commit) hit the
  same bit in one cycle, **set wins** (the new producer is the pending one) — mutation M22 verifies this.
* r0/p0 are never pending; illegal words and NOPs have no sources and no destination, so they never stall.
* Independent re-check at the moment of issue (SVA `a_issue_raw1/raw2/rawp/wawg/wawp`), and a global conservation
  law: *number of pending bits == number of in-flight instructions with a destination* (`a_sb_conserve`) —
  catches leaked bits and overlapping writers.

## 4. Writeback slot (structural hazard)

Only one result can enter W per cycle. A MUL in X reaches W two cycles later; a fast op dispatched from O in the
same cycle would reach W then as well. The rule: **a fast-path instruction in O is held for one cycle while X
contains a MUL** (`slot_conflict`). The older MUL wins; nothing is buffered, dropped or re-arbitrated.
Effect: a fast op immediately behind a MUL retires 1 cycle after it (not simultaneously). SVA `a_slot`
asserts the two paths are never both feeding W; mutation M08 (rule removed) is detected.
With `IN_DEPTH=1` instructions are accepted at most every second cycle, so a fast op can never be issued exactly one cycle behind
a MUL: the conflict is unreachable there (the directed test checks the conflict counter stays at 0 in that configuration).

## 5. Register file — conflicts and forwarding made explicit (`sfg1_regfile`)

Per lane: two replicated 32×32 RAMs (A feeds rs1, B feeds rs2; same write data) → **2 read ports + 1 write port
with no read-port conflicts**. A 1-bit-per-lane predicate file (flops) has 1 read port and 1 write port.

| conflict | rule |
|---|---|
| read & write, **different** addresses, same cycle | independent |
| read & write, **same** address, same cycle (read launched in the cycle the write commits) | RAM is `READ_FIRST` (returns the old word, true for LUTRAM and BRAM). The regfile captures the committing write data + a per-lane hit at launch and muxes it over the RAM output ⇒ the reader gets the **new** data ("same-cycle forwarding"). Exercised 479–755 times per directed run (coverage counter) and verified by mutations M01–M03. |
| write one cycle *before* a read launch | the data is in the RAM; ordinary read |
| write in a cycle *after* a read launch | not visible (the reader already has its operands). No hazard exists: the scoreboard blocks it unless the writer is the *same-cycle* committer |
| forwarding to an **inactive lane** | never: the hit is `we_lane[k]` per lane, so an unwritten lane keeps its RAM value |
| write & write, same cycle | impossible by construction: the pipeline commit owns the GPR write port; `xw` is refused while W holds a GPR result. One GPR write/cycle, one predicate write/cycle |
| write to r0 / p0 | dropped in the regfile (and never decoded as a destination) |
| read of r0 / p0 | r0 → 0 via a registered mask (independent of RAM contents); p0 → all ones |
| clear sequencer vs. everything | clear has absolute priority; `iss_ready`, `xw_ready` are low while `busy` |

Read data is *held* while no new read is launched (RAM read enable = issue), so a stalled or slot-held O stage keeps its operands.

### Per-lane write enables = "no inactive lane is written"
The write mask `w_wmask` is computed in O as `dkind≠NONE ? iss_mask & guard : 0`, travels with the instruction, and drives
each lane's RAM write-enable (and predicate-bit write). SVA `a_lane_subset` additionally tracks the *issue* mask
in a shadow pipeline and checks `w_wmask ⊆ issue_mask`; mutations M04 and M24 (mask ignored) are detected.

### External write (`xw`)
Ordering and arbitration rules are in the spec (§3 rule 4). Implementation: `xw_ready = rst_n & ~busy & ~ib_valid &
~(w_valid & w_dk==GPR) & ~pending[xw_rd]`; `iss_ready` is held low while `xw_valid`. A race found during development
(an xw accepted while an older instruction to the same register was still queued, silently overwritten later) was fixed
by the `~ib_valid` term; mutation M16 reintroduces it and is detected.

## 6. Reset

Synchronous, active low. In a cycle with `rst_n=0`: `iss_ready`, `xw_ready`, `res_valid` are forced low (no transfer can
complete), commits are suppressed, and at the clock edge every valid bit, the FIFO, the scoreboard and the predicate
file clear. **Everything accepted but not yet retired is dropped.**
RAM contents cannot be cleared in one cycle, so after `rst_n` rises a **clear sequencer writes zero to r0..r31 of every
lane through the normal write port**: `busy` is high for exactly 32 cycles (checked), during which no instruction is
accepted. Result: after reset all registers are zero, regardless of the (randomised, in simulation) power-up state.
Reset applied *during* the clear sequence simply restarts it. Data-path registers (X/M/W data, RF read registers) are
not reset — their valid bits are — which keeps reset fan-out small.

## 7. Mapping to FPGA memory and arithmetic resources

**Register file (the main memory-mapping decision).** Each lane needs 2 × (32 words × 32 bits) = 2 Kib with one
write port, two read ports, per-lane write enable, 1-cycle registered read. Two physical RAMs per lane (replication) give
the second read port; no multi-write-port tricks (LVT/XOR banking) are needed because there is exactly one GPR write
port. The RAM is described once in `sfg1_gpr_ram` with the standard synchronous-read inference pattern and a
`ram_style` attribute chosen by `RF_BRAM`:

| `RF_BRAM` | attribute | intended mapping | when to use |
|---|---|---|---|
| 0 (default) | `ram_style="distributed"` | LUTRAM (async read + the output register that the "registered read" implies) | depth 32 per lane: a block RAM would be ~94 % unused *per RAM* (32 of 512 words) |
| 1 | `ram_style="block"` | block RAM, synchronous read, no output reg beyond the RAM's own | when the per-lane depth grows (multiple warps/contexts ≥ 256 words) |

READ_FIRST (old data on a same-address collision) is what Xilinx LUTRAM/BRAM (`READ_FIRST`) and Intel RAM "old data" modes
provide; Intel behaviour was not tested here. Because the design does **not** rely on read-during-write behaviour (the bypass
covers the collision), it should be insensitive to the vendor choice — but that is an expectation, not a measurement.
Per-lane write enable is a whole-word enable (each lane has its own RAM), so no byte-enable RAM features are needed.

**What was actually measured** (Yosys 0.71 + slang; full tables and logs in `results/synth/SUMMARY.md`):

* Xilinx 7-series mapping, LANES=4, LUTRAM: **48 `RAM32M`** (= 8 RAMs × 6) + 3113 LUT + 1361 FF + 16 DSP48E1; no block RAM.
* Same with `RF_BRAM=1`: **8 `RAMB18E1`** (one per RAM), 0 RAM32M, 1105 FF.
* ECP5, LANES=4: 128 `TRELLIS_DPR16X4` (distributed RAM), 16 `MULT18X18D`, 0 `DP16KD`.
* Multiplier: 4 DSP48E1 per lane (Xilinx) / 4 MULT18X18D per lane (ECP5) for the 33×33 signed product.
* Scaling (derived from the Xilinx table, LANES 1→16): FF +275 per added lane exactly; LUT +550…720 per added lane
  (varies with tool optimisation); RAM32M +12 and DSP48E1 +4 per lane. The lane-independent part (decode, scoreboard,
  input FIFO, pipeline control) is therefore roughly 590 LUT / 261 FF.
* **Timing**: only measured on **ECP5** via nextpnr: post-route Fmax 69–76 MHz for LANES=1/2/4 (100 MHz requested, not
  met). **No Xilinx or Intel timing was measured** — there was no Vivado/Quartus run, and Yosys alone does not produce
  Xilinx timing. Do not read the ECP5 number as a Xilinx estimate.
* Critical paths seen (ECP5): (a) the 33×33 multiplier — the 18×18 hard multipliers' partial products are summed
  in fabric carry chains inside the single X→M cycle; (b) the control path `res_ready → stall → issue_go → input-FIFO
  clock-enable`. Obvious remedies (not implemented): a second multiplier pipeline stage (MUL latency 5→6; the
  slot-conflict window would widen to two cycles) and a registered result skid buffer.

Not verified in this work: that Vivado/Quartus infer exactly the intended RAM primitives from the same source, and
post-synthesis/post-route simulation (only RTL simulation was run).

## 8. Limitations and design trade-offs (honest list)

* Scoreboard is per register (all lanes): a masked/partially active instruction still blocks consumers of the register.
* Single in-flight context; no warps, branches, divergence handling or memory operations.
* Illegal instructions do not trap; they retire flagged. There is no precise-exception machinery.
* Results can retire out of order across different destinations (tags identify them); same-destination order is guaranteed.
* The result channel has no decoupling FIFO: one slow consumer freezes the pipeline (by design, §2).
* `xw` has priority over new instructions and requires an empty input FIFO, so heavy `xw` traffic costs issue bandwidth.
* After reset the core is unavailable for 32 cycles (RF clear). If a post-reset state is not required, a configuration
  without the sequencer would be a trivial change, but the spec here defines zeroed registers.
* The multiplier is a single combinational 33×33 per lane between X and M; see the timing note above.
