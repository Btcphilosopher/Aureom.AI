# SF-G1 Execution Core — Verification

Everything below was produced by running the tools in this repository (Verilator 5.020 as the simulator, Yosys
0.71 / nextpnr 0.11 for synthesis, CPython 3.13). The numbers are copied from the files in `results/`, which are the
raw outputs of those runs.

## 1. Strategy: independent layers that cross-check each other

| layer | what it is | what it catches |
|---|---|---|
| **Python simulator** `python/sfg1/sim.py` | architectural reference model; written with plain big-int arithmetic | spec-level semantics |
| **Python unit tests** `python/tests` | hand-computed **literal** expectations (not produced by the model), encode/decode round-trips, SFX-v1 encoder compatibility, and tests that the *comparator itself* rejects corrupted logs | mistakes in the Python model/comparator |
| **SV reference model** (`tb/sfg1_tb_common.svh`) | a second, separately written behavioural model inside the testbench; checks **every** retired result inline | RTL vs. a model written differently from both the RTL and the Python |
| **Directed self-checking TB** `tb_sfg1_directed` | exact-timing, protocol, stall, arbitration, reset and boundary tests + literal vector table | cycle-level behaviour the architectural models do not describe |
| **Differential TB** `tb_sfg1_diff` + `gen.py` + `compare.py` | random programs → RTL → transaction log → replayed through the Python simulator | divergence between RTL and the Python simulator under random hazards, masks, back-pressure, resets |
| **Assertions** `rtl/sfg1_core_checks.svh` | 25 concurrent SVA (23 on the core, 2 on the environment's protocol obligations) always on in simulation | protocol violations, lost/duplicated instructions, hazard-rule violations, writes outside the mask |
| **Mutation campaign** `scripts/mutate.py` | ~30 injected single-point RTL bugs | whether the layers above can actually *fail* |

A run is a **three-way comparison** (RTL ⇄ SV model inline, RTL ⇄ Python after the run).

## 2. What is checked

* **Dependencies**: RAW (rs1, rs2, guard predicate), WAW (older MUL vs. younger fast op), WAR, at producer→consumer
  distances 0…8 for both fast and MUL producers (T5); exact consumer-after-producer cycle distances (T4); same-cycle
  forwarding exercised hundreds of times (coverage counter) and removing it is detected (M01–M03).
* **Masked execution**: issue masks {0, all, single lane, alternating, random}; guard predicates positive/negated/PT/!PT
  combined with masks; masked predicate writes; fully-masked instructions retire exactly once; r0/p0 destinations (T6);
  every run re-reads *all* registers and predicates through the datapath so any wrongly written/unwritten lane shows up.
* **Pipeline stalls / backpressure**: `res_ready` held low with a producer pushing (input FIFO fills, `iss_ready` falls,
  bounded acceptance, payload held, nothing lost) and random `res_ready` / producer-gap patterns (T8, every diff run).
* **Reset during activity**: reset at random points with in-flight instructions, a pending `valid`, and back-pressure;
  clear sequence length (exactly 32), quiescence during reset, all registers zero afterwards, no ghost scoreboard bits,
  no result from a pre-reset instruction after reset (T10, and `RESET` events in the differential runs).
* **Arithmetic boundaries**: 37 hand-written literal vectors (T2); an exhaustive cross-product of 20 boundary values for
  all 14 ALU/MUL functions, immediate forms, and all 10 `SETP` conditions (T3); boundary-biased random data in every
  differential run. Covers INT_MIN/INT_MAX wrap, ±1, 0, 0xFFFFFFFF, shift amounts 0/31/32/>32, MULH/MULHU/MULHSU extremes.
* **External write**: refused while a writer is in flight, while W holds a GPR result, ordered behind queued
  instructions, priority over the instruction stream; r0 writes dropped; concurrent traffic (T9). A real race found by
  this test during development was fixed in the RTL (see MICROARCHITECTURE §5).
* **Protocol**: exactly-once retirement (unknown/duplicate/post-reset tags), program order for same-destination results,
  `a_res_hold` (payload stable under stall), accepted − retired = in flight at every cycle (`a_conserve`).
* **Power-up state**: all runs use `+verilator+rand+reset+2` (randomised initial flop/RAM contents) with the seed varied.

## 3. Results

### 3.0 Summary of the runs quoted below

| run | result |
|---|---|
| Python unit tests (`results/unit_tests.txt`) | 59 passed with `SFX_ASM` set (58 passed + 1 skipped without it) |
| Verilator `-Wall` lint (`results/lint.txt`) | 0 warnings, 0 errors: LANES 1/2/3/4/8/16 with assertions; `IN_DEPTH` 1 and 4; `RF_BRAM=1` |
| Directed testbench, 11 configurations x 3 seeds | **33 / 33 PASS** |
| Differential testbench, 11 configurations x 8 profiles x 6 seeds | **528 / 528 PASS**: 350922 instructions accepted, 350225 retired, 697 dropped by reset, 726 resets, 11492 external writes |
| Mutation campaign (`results/mutation.txt`) | **32/33 mutants detected** (the survivor is an equivalent mutant, see below) |

Configurations are `LANES:IN_DEPTH:RF_BRAM` = 1:2:0, 2:2:0, 3:2:0, 4:2:0, 8:2:0, 16:2:0, 32:2:0, 4:1:0, 4:4:0, 4:2:1, 8:2:1.
Same-cycle forwarding was exercised 479–755 times per directed run (coverage counter `same_cycle_fwd`).

### 3.0.1 Mutation campaign (33 injected RTL bugs; LANES=4, IN_DEPTH=2)

"Layer" says what noticed the bug: **assertion** = SVA, **TB-check/SV-model** = directed-TB check or the inline SV reference model,
**python-compare** = the differential comparator, **watchdog** = deadlock detection; `directed:Tn` lists the failing directed phases.

| id | injected bug | detected by |
|---|---|---|
| M01 | no same-cycle forwarding into read port A | TB-check/SV-model, directed:T4,T5,T6,T7,T8,T9,T10,T11, python-compare |
| M02 | no same-cycle forwarding into read port B | TB-check/SV-model, directed:T4,T10,T11, python-compare |
| M03 | no same-cycle forwarding for predicates | TB-check/SV-model, directed:T4,T10,T11, python-compare |
| M04 | GPR write ignores lane mask (writes inactive lanes) | TB-check/SV-model, directed:T5,T6,T7,T8,T9,T10,T11, python-compare |
| M05 | WAW check on GPR destination removed | assertion, python-compare |
| M06 | RAW check on rs2 removed | assertion, python-compare |
| M07 | RAW check on guard predicate removed | assertion, python-compare |
| M08 | writeback-slot hazard check removed | assertion, python-compare |
| M09 | W data register not held during a stall | assertion, python-compare |
| M10 | SAR is logical | TB-check/SV-model, directed:T2,T3,T11, python-compare |
| M11 | MULHSU treats rs2 as signed | TB-check/SV-model, directed:T2,T3,T11, python-compare |
| M12 | shift amount uses 6 bits | TB-check/SV-model, directed:T2,T3,T11, python-compare |
| M13 | guard negate ignored | TB-check/SV-model, directed:T5,T6,T7,T8,T9,T10,T11, python-compare |
| M14 | reset does not clear the scoreboard | assertion, python-compare |
| M15 | FIFO drops an entry on simultaneous push+pop | TB-check/SV-model, directed:T1, python-compare, watchdog(deadlock) |
| M16 | external write not ordered behind queued instructions | TB-check/SV-model, assertion, python-compare |
| M17 | clear sequence one cycle short (r31 not cleared) | TB-check/SV-model, directed:T1,T10, python-compare |
| M18 | illegal flag never reported | TB-check/SV-model, directed:T4,T7,T10,T11, python-compare |
| M19 | SETP.LT uses unsigned compare | TB-check/SV-model, directed:T3,T11, python-compare |
| M20 | MUL hi/lo word select swapped | TB-check/SV-model, directed:T2,T3,T4,T5,T6,T7,T8,T9,T10,T11, python-compare |
| M21 | same-cycle scoreboard release removed (timing only) | TB-check/SV-model, directed:T4 |
| M22 | scoreboard clear beats set on a same-cycle collision | assertion, python-compare |
| M23 | stage data registers advance during a stall | assertion, python-compare |
| M24 | predicate write ignores lane mask | TB-check/SV-model, directed:T6,T7,T8,T9,T10,T11, python-compare |
| M25 | mask reported for a discarded destination | assertion, python-compare |
| M26 | result valid during reset | assertion, python-compare |
| M27 | issue accepted during the RF clear sequence | TB-check/SV-model, assertion, python-compare |
| M28 | MOVI zero-extends instead of sign-extends | TB-check/SV-model, directed:T6,T10,T11, python-compare |
| M29 | SLTU uses signed compare | TB-check/SV-model, directed:T2,T3,T11, python-compare |
| M30 | external write ignores in-flight writer of the same register | TB-check/SV-model, assertion, python-compare |
| M31 | external write loses priority (instructions keep being accepted) | assertion, python-compare |
| M32 | (sanity) r0 read mask removed on A -- equivalent while RAM[0]==0 | **SURVIVED** |
| M33 | r0 is writable AND its read mask is removed (both r0 protections gone) | TB-check/SV-model, directed:T9, python-compare |

**M32 (survivor) is an equivalent mutant, not a test gap**: it removes the r0 read mask on read port A only. `RAM[0]` is zeroed by the
clear sequence and writes to address 0 are dropped inside the regfile, so the mask is redundant and its removal is unobservable.
Removing *both* r0 protections (M33) **is** observable and is detected — M33 initially survived and exposed a real test gap (§3.1 #2).
Directed phases: T1 reset/clear, T2 literals, T3 boundary sweep, T4 latency/throughput, T5 forwarding, T6 masks, T7 illegal,
T8 backpressure, T9 external write, T10 reset during activity, T11 random stress.

### 3.0.2 Regression log (excerpt; full log in `results/regression.txt`)

```
== differential testbench: RTL vs SV model (in sim) vs Python simulator (compare.py)
config          runs  pass    instr  retired  dropped resets     xw
1:2:0             48    48    31902    31843       59     66   1012
2:2:0             48    48    31902    31838       64     66   1049
3:2:0             48    48    31902    31843       59     66   1001
4:2:0             48    48    31902    31833       69     66   1087
8:2:0             48    48    31902    31842       60     66   1017
16:2:0            48    48    31902    31845       57     66   1009
32:2:0            48    48    31902    31841       61     66   1039
4:1:0             48    48    31902    31859       43     66   1087
4:4:0             48    48    31902    31806       96     66   1087
4:2:1             48    48    31902    31833       69     66   1087
8:2:1             48    48    31902    31842       60     66   1017
TOTAL            528   528   350922   350225      697    726  11492

== ALL PASSED  (total 391s)
```


### 3.1 Problems the verification itself surfaced during development (all fixed)

| # | what | kind | how it was found | resolution |
|---|---|---|---|---|
| 1 | An external write accepted while an *older* instruction to the same register was still sitting in the input FIFO was silently overwritten later | **RTL design bug** | directed T9(a) (model said xw is younger, DUT disagreed) | `xw_ready` now also requires an empty input FIFO; `iss_ready` is held low while `xw_valid` (priority, no starvation). Assertions `a_xw_ordered`, `a_xw_priority`; mutants M16, M30, M31 |
| 2 | "r0 reads zero even after an external write to r0" was not directly tested: both r0 protections could be removed (mutant M33) and every test still passed | **test gap** | mutation campaign: M33 survived | `readback_all()` and T9(c) now read r0 through both operand ports; the differential generator now targets r0 with external writes and reads it back. M33 is now killed (by T9 and the Python comparator) |
| 3 | `a_sb_zero` fired in the first cycles of simulation | assertion bug | randomised power-up state (`+verilator+rand+reset+2`) | assertion now has `disable iff (!rst_n)` (state before the first reset edge is undefined) |
| 4 | T4 throughput checks failed at `IN_DEPTH=1` | test assumption | full configuration matrix | not a DUT defect: with a single FIFO entry `iss_ready` cannot rise in the cycle the slot frees, so peak rate is one instruction per 2 cycles (documented in the spec). Expectation is now `TPUT_GAP = (IN_DEPTH==1) ? 2 : 1` |
| 5 | A testbench hang that looked like a deadlock | simulator quirk | watchdog state dump showed an idle, healthy core | Verilator 5.020 never terminates `while (f_with_side_effects()) @(negedge clk);`; reproduced standalone; testbench draws outside the loop condition |
| 6 | Mutation campaign crashed on a truncated log, and recorded a hung simulation as "not detected" | tooling bugs | first campaign attempts | comparator reports truncated records as errors (unit-tested); a wall-clock timeout is classified as a watchdog detection |

Note on the final test edit: the T4 `TPUT_GAP` change (row 4) was made after the mutation campaign had completed; it only alters
expectations when `IN_DEPTH==1`, and the campaign ran at the default `IN_DEPTH=2`, where behaviour is identical.

## 4. How to reproduce

```bash
make unit && make lint && make regress && make mutate     # simulation results
make synth                                                 # needs: pip install yowasp-yosys yowasp-nextpnr-ecp5
```
`results/*.txt` are the logs of the runs quoted here; they are overwritten when the commands are rerun.

## 5. What is NOT covered (read this before trusting it)

* **Single simulator.** Everything ran on Verilator 5.020. No second simulator (Icarus/commercial) was used; the RTL uses
  SystemVerilog packages/structs/enums/SVA that Icarus does not fully support.
* **RTL only.** No post-synthesis or post-place-and-route simulation, no gate-level checks, no CDC/RDC analysis (single clock domain).
* **No formal proof.** The assertions are simulation-checked only. (SymbiYosys was installable but was not used.)
* **Synthesis ≠ Vivado/Quartus.** Resource numbers come from Yosys; timing only from nextpnr on ECP5. Whether a vendor tool infers
  the same RAM/DSP primitives from the same source is expected but unverified.
* **The specification itself is assumed** (see `SF-G1_SPEC.md` §0). The tests prove the RTL matches *this* spec and the
  Python model, not an SF-G1 specification that was unavailable.
* **Mutation score is relative to the chosen mutants.** Mutants are single-point edits I chose; a surviving or absent
  mutant class is not covered. The one expected survivor (M32) is an *equivalent* mutant (see below).
* Random stimulus is bounded (hundreds of instructions per run, tens of thousands overall); there is no coverage-driven closure
  beyond the coverage counters printed by the RTL (`SFG1_COV` lines).
* Timing assertions in the directed TB (latency numbers) are valid for the default pipeline; they are not parameterised.
* LANES > 32 is untested (the differential stimulus format packs masks into ≤ 32 bits).

### A simulator quirk worth knowing
While running the regression a testbench hang turned out **not** to be a DUT deadlock (the DUT state dump at the watchdog showed
an idle, healthy core): Verilator 5.020 never terminates `while (cond_with_side_effects()) @(negedge clk);` — here a random draw
in the loop condition. Reproduced in a 30-line standalone program; the testbench now draws outside the condition (commented in
`sfg1_tb_common.svh`). The watchdog state dump that found it is kept in the harness.
