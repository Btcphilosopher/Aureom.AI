// =============================================================================
//  sfg1_gpr_ram -- one 32 x W memory, 1 write port + 1 registered read port.
//
//  Read-during-write contract (identical for LUTRAM and BRAM mappings):
//    READ_FIRST. If `re` and `we` hit the same address in one cycle, `rdata`
//    captures the OLD contents. The enclosing regfile adds an explicit bypass
//    for that case; nothing upstream relies on tool-specific RDW behaviour.
//    `rdata` only updates when `re` is high (held otherwise), so a stalled
//    operand stage keeps its data.
//
//  FPGA mapping (see docs/MICROARCHITECTURE.md):
//    USE_BRAM=0 -> (* ram_style = "distributed" *) : LUTRAM + output register
//    USE_BRAM=1 -> (* ram_style = "block" *)       : block RAM, sync read
// =============================================================================
module sfg1_gpr_ram #(
  parameter int unsigned W        = 32,
  parameter bit          USE_BRAM = 1'b0
) (
  input  logic         clk,
  input  logic         we,
  input  logic [4:0]   waddr,
  input  logic [W-1:0] wdata,
  input  logic         re,
  input  logic [4:0]   raddr,
  output logic [W-1:0] rdata
);
  generate
    if (USE_BRAM) begin : g_bram
      (* ram_style = "block" *) logic [W-1:0] mem [0:31];
      always_ff @(posedge clk) begin
        if (we) mem[waddr] <= wdata;
        if (re) rdata      <= mem[raddr];
      end
    end else begin : g_lut
      (* ram_style = "distributed" *) logic [W-1:0] mem [0:31];
      always_ff @(posedge clk) begin
        if (we) mem[waddr] <= wdata;
        if (re) rdata      <= mem[raddr];
      end
    end
  endgenerate
endmodule
