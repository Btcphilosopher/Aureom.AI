// =============================================================================
//  sfg1_core -- SF-G1 SIMT integer execution core
//
//  See docs/SF-G1_SPEC.md (ISA, interfaces) and docs/MICROARCHITECTURE.md.
//
//  PIPELINE (one instruction per cycle, in-order issue, completion order may
//  differ between the fast path and the multiplier path):
//
//   iss_* --> [IB input FIFO] --> I --> O --> X --> W  (fast path,  3 cycles issue->W)
//                                         \-> X --> M --> W  (MUL path,   4 cycles)
//
//    I  decode, hazard check (scoreboard), launch register-file read, set pending
//    O  read data + same-cycle forwarding arrive; operand select; guard
//       predicate -> effective lane mask; dispatch to X (or hold, see below)
//    X  fast ALU / SETP comparator, or multiplier array
//    M  multiplier product register (MUL path only)
//    W  result register == result channel; the RF/predicate write COMMITS in the
//       cycle res_valid && res_ready, together with the scoreboard release
//
//  GLOBAL FREEZE: stall = w_valid & ~res_ready. While stalled every stage
//  register (O, X, M, W, RF read registers, scoreboard) holds, nothing issues,
//  and only the input FIFO keeps accepting until it is full. A stall cycle is
//  therefore a pure "do nothing" cycle: instructions can neither be lost,
//  duplicated nor reordered by backpressure.
//
//  WRITEBACK SLOT: the single W register can only take one result per cycle. A
//  MUL in X will reach W two cycles later; a fast op dispatched from O in the
//  same cycle would reach W at the same time. The O stage therefore holds a
//  fast-path instruction for one cycle whenever X contains a MUL
//  (`slot_conflict`). The older MUL keeps priority; no result is ever dropped
//  or buffered.
//
//  TRANSACTION OWNERSHIP
//   issue  (iss_*): producer owns payload until valid&&ready, and must keep
//          valid and payload stable until accepted. iss_ready is a function of
//          registered state and xw_valid (the external write has priority); it
//          never depends on iss_valid or the payload. Acceptance transfers
//          ownership to the core.
//          The core then guarantees exactly ONE result transaction for the
//          instruction (illegal, NOP, fully-masked and r0-destination
//          instructions included) unless reset intervenes.
//   result (res_*): core owns payload while res_valid&&!res_ready (stable, never
//          retracted); acceptance transfers ownership to the consumer and
//          is the architectural commit point.
//   xw     (xw_*): external register write; producer owns the payload until
//          xw_valid&&xw_ready. xw_ready may depend on xw_rd (pending-write check).
//   reset: while rst_n=0 no transfer can complete (all three ready/valid outputs
//          are forced low). Reset destroys every instruction that has not yet
//          produced its result transaction; the producer must treat those as void.
// =============================================================================
module sfg1_core
  import sfg1_pkg::*;
#(
  parameter int unsigned LANES    = 8,     // >= 1
  parameter int unsigned TAG_W    = 8,
  parameter int unsigned IN_DEPTH = 2,     // input FIFO depth (>= 1)
  parameter bit          RF_BRAM  = 1'b0   // 0: LUTRAM register file, 1: block RAM
) (
  input  logic                   clk,
  input  logic                   rst_n,      // synchronous, active low

  // ---- issue channel --------------------------------------------------------
  input  logic                   iss_valid,
  output logic                   iss_ready,
  input  logic [31:0]            iss_insn,
  input  logic [LANES-1:0]       iss_mask,   // lanes enabled by the front end
  input  logic [TAG_W-1:0]       iss_tag,    // opaque, returned on the result

  // ---- external register write channel -------------------------------------
  input  logic                   xw_valid,
  output logic                   xw_ready,
  input  logic [4:0]             xw_rd,
  input  logic [LANES-1:0]       xw_mask,
  input  logic [LANES*32-1:0]    xw_data,

  // ---- result channel -------------------------------------------------------
  output logic                   res_valid,
  input  logic                   res_ready,
  output logic [TAG_W-1:0]       res_tag,
  output logic [1:0]             res_dkind,   // dkind_e: 0 none, 1 GPR, 2 PRED
  output logic [4:0]             res_rd,      // register / predicate index
  output logic [LANES-1:0]       res_mask,    // lanes written (0 when dkind==NONE)
  output logic [LANES*32-1:0]    res_data,    // valid on lanes with res_mask=1; PRED: bit 0
  output logic                   res_illegal,

  // ---- status ---------------------------------------------------------------
  output logic                   busy,        // post-reset RF clear sequence (32 cycles)
  output logic                   idle         // nothing accepted is still in flight
);

  // ===========================================================================
  //  Input elastic buffer
  // ===========================================================================
  localparam int unsigned IBW = 32 + LANES + TAG_W;

  logic             ib_full, ib_valid, issue_go;
  logic [IBW-1:0]   ib_dout;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(IN_DEPTH+1)-1:0] ib_count;    // observed by assertions only
  /* verilator lint_on UNUSEDSIGNAL */

  logic [31:0]      ib_insn;
  logic [LANES-1:0] ib_mask;
  logic [TAG_W-1:0] ib_tag;
  assign {ib_tag, ib_mask, ib_insn} = ib_dout;

  // xw has priority over new instructions: while an external write is waiting the
  // input FIFO is allowed to drain, so a continuous instruction stream cannot starve it.
  assign iss_ready = rst_n & ~busy & ~ib_full & ~xw_valid;
  wire   ib_push   = iss_valid & iss_ready;

  sfg1_fifo #(.W(IBW), .DEPTH(IN_DEPTH)) u_ib (
    .clk(clk), .rst_n(rst_n),
    .push(ib_push), .din({iss_tag, iss_mask, iss_insn}), .full(ib_full),
    .pop(issue_go), .valid(ib_valid), .dout(ib_dout), .count(ib_count));

  // ===========================================================================
  //  I stage: decode + hazard check
  // ===========================================================================
  dec_t dec;
  sfg1_decode u_dec (.insn(ib_insn), .dec(dec));

  // stage valids / control declared up-front (used across stages)
  logic o_valid, x_valid, m_valid, w_valid;
  logic x_is_mul;
  logic stall, o_go;

  logic        hazard;
  logic        sb_clr_v;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] pend_g;                        // observed by assertions only
  logic [7:0]  pend_p;
  /* verilator lint_on UNUSEDSIGNAL */
  logic        xw_pending;

  // W-stage registers (result channel)
  logic [TAG_W-1:0] w_tag;
  dkind_e           w_dk;
  logic [4:0]       w_dst;
  logic [LANES-1:0] w_wmask;
  logic             w_illegal;
  logic [LANES*32-1:0] w_data;

  assign stall    = w_valid & ~res_ready;
  wire   w_fire   = w_valid & res_ready & rst_n;          // result commit
  assign sb_clr_v = w_fire;

  wire o_free = ~o_valid | o_go;
  assign issue_go = ib_valid & ~hazard & ~stall & ~busy & o_free & rst_n;

  sfg1_scoreboard u_sb (
    .clk(clk), .rst_n(rst_n),
    .q_rs1_v(dec.rs1_used), .q_rs1(dec.rs1),
    .q_rs2_v(dec.rs2_used), .q_rs2(dec.rs2),
    .q_gsel(dec.gsel), .q_dk(dec.dkind), .q_dst(dec.dst),
    .hazard(hazard),
    .clr_v(sb_clr_v), .clr_dk(w_dk), .clr_idx(w_dst),
    .set_v(issue_go), .set_dk(dec.dkind), .set_idx(dec.dst),
    .xq_idx(xw_rd), .xq_pending(xw_pending),
    .pend_g_o(pend_g), .pend_p_o(pend_p));

  // ===========================================================================
  //  Register file (read launched here, data arrives in O)
  // ===========================================================================
  logic                gw_en, pw_en;
  logic [LANES-1:0]    gw_lane;
  logic [4:0]          gw_addr;
  logic [LANES*32-1:0] gw_data;
  logic [LANES*32-1:0] rf_a, rf_b;
  logic [LANES-1:0]    pdata;

  wire w_gpr_wr = w_fire & (w_dk == DK_GPR);
  wire w_prd_wr = w_fire & (w_dk == DK_PRED);

  // External write. It is strictly ORDERED with respect to the issue channel:
  //   * every instruction accepted before it has already issued (input FIFO empty),
  //     so no queued instruction can read the old value late or overwrite it later;
  //   * no issued instruction still has a write to the target register in flight
  //     (scoreboard), so there is no WAW race;
  //   * the pipeline writeback owns the single GPR write port: xw is refused while
  //     W holds a GPR result (committing or stalled) and during the clear sequence.
  // Instructions accepted after it (iss_ready is low while xw_valid) see its data.
  assign xw_ready = rst_n & ~busy & ~ib_valid & ~(w_valid & (w_dk == DK_GPR)) & ~xw_pending;
  wire   xw_fire  = xw_valid & xw_ready;

  assign gw_en   = w_gpr_wr | xw_fire;
  assign gw_addr = w_gpr_wr ? w_dst   : xw_rd;
  assign gw_lane = w_gpr_wr ? w_wmask : xw_mask;
  assign gw_data = w_gpr_wr ? w_data  : xw_data;
  assign pw_en   = w_prd_wr;

  logic [LANES-1:0] pw_bits;
  genvar k;
  generate
    for (k = 0; k < LANES; k++) begin : g_pbits
      assign pw_bits[k] = w_data[32*k];
    end
  endgenerate

  sfg1_regfile #(.LANES(LANES), .USE_BRAM(RF_BRAM)) u_rf (
    .clk(clk), .rst_n(rst_n), .busy(busy),
    .gw_en(gw_en), .gw_lane(gw_lane), .gw_addr(gw_addr), .gw_data(gw_data),
    .pw_en(pw_en), .pw_lane(w_wmask), .pw_addr(w_dst[2:0]), .pw_data(pw_bits),
    .rd_en(issue_go), .rs1(dec.rs1), .rs2(dec.rs2), .psel(dec.gsel),
    .rdata_a(rf_a), .rdata_b(rf_b), .pdata(pdata));

  // ===========================================================================
  //  O stage registers
  // ===========================================================================
  /* verilator lint_off UNUSEDSIGNAL */
  dec_t             o_dec;                    // rs1/rs2/use flags are consumed at issue, not in O
  /* verilator lint_on UNUSEDSIGNAL */
  logic [LANES-1:0] o_mask;
  logic [TAG_W-1:0] o_tag;

  always_ff @(posedge clk) begin
    if (!rst_n)        o_valid <= 1'b0;
    else if (issue_go) o_valid <= 1'b1;
    else if (o_go)     o_valid <= 1'b0;
  end

  always_ff @(posedge clk) begin
    if (issue_go) begin
      o_dec  <= dec;
      o_mask <= ib_mask;
      o_tag  <= ib_tag;
    end
  end

  // guard -> effective mask (O stage)
  logic [LANES-1:0] o_guard, o_emask, o_wmask;
  always_comb begin
    o_guard = (o_dec.gsel == 3'd0) ? {LANES{1'b1}} : pdata;
    o_guard = o_guard ^ {LANES{o_dec.gneg}};
    o_emask = o_mask & o_guard;
    o_wmask = (o_dec.dkind != DK_NONE) ? o_emask : {LANES{1'b0}};
  end

  // dispatch: a fast-path op must not follow a MUL by exactly one cycle
  wire slot_conflict = ~o_dec.is_mul & x_valid & x_is_mul;
  assign o_go = o_valid & ~stall & ~slot_conflict & rst_n;

  // ===========================================================================
  //  X / M / W control and registers
  // ===========================================================================
  alu_op_e          x_alu_op;
  logic [3:0]       x_cond;
  logic             x_sa, x_sb, x_hi;
  logic [TAG_W-1:0] x_tag;
  dkind_e           x_dk;
  logic [4:0]       x_dst;
  logic [LANES-1:0] x_wmask;
  logic             x_illegal;

  logic             m_hi;
  logic [TAG_W-1:0] m_tag;
  dkind_e           m_dk;
  logic [4:0]       m_dst;
  logic [LANES-1:0] m_wmask;
  logic             m_illegal;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      x_valid <= 1'b0;
      m_valid <= 1'b0;
      w_valid <= 1'b0;
    end else if (!stall) begin
      x_valid <= o_go;
      m_valid <= x_valid & x_is_mul;
      w_valid <= (x_valid & ~x_is_mul) | m_valid;
    end
  end

  always_ff @(posedge clk) begin
    if (!stall) begin
      // X
      x_alu_op  <= o_dec.alu_op;
      x_cond    <= o_dec.cond;
      x_is_mul  <= o_dec.is_mul;
      x_sa      <= (o_dec.mul_op == MUL_HS) | (o_dec.mul_op == MUL_HSU);
      x_sb      <= (o_dec.mul_op == MUL_HS);
      x_hi      <= (o_dec.mul_op != MUL_LO);
      x_tag     <= o_tag;
      x_dk      <= o_dec.dkind;
      x_dst     <= o_dec.dst;
      x_wmask   <= o_wmask;
      x_illegal <= ~o_dec.legal;
      // M
      m_hi      <= x_hi;
      m_tag     <= x_tag;
      m_dk      <= x_dk;
      m_dst     <= x_dst;
      m_wmask   <= x_wmask;
      m_illegal <= x_illegal;
      // W  (MUL path has priority; the two are never both valid, see slot_conflict)
      w_tag     <= m_valid ? m_tag     : x_tag;
      w_dk      <= m_valid ? m_dk      : x_dk;
      w_dst     <= m_valid ? m_dst     : x_dst;
      w_wmask   <= m_valid ? m_wmask   : x_wmask;
      w_illegal <= m_valid ? m_illegal : x_illegal;
    end
  end

  // ===========================================================================
  //  Lanes
  // ===========================================================================
  generate
    for (k = 0; k < LANES; k++) begin : g_lane
      sfg1_lane u_lane (
        .clk(clk), .adv(~stall),
        .rf_a(rf_a[32*k +: 32]), .rf_b(rf_b[32*k +: 32]),
        .imm(o_dec.imm), .a_imm(o_dec.a_imm), .b_imm(o_dec.b_imm),
        .x_alu_op(x_alu_op), .x_cond(x_cond), .x_sa(x_sa), .x_sb(x_sb),
        .m_hi(m_hi), .sel_m(m_valid),
        .w_data(w_data[32*k +: 32]));
    end
  endgenerate

  // ===========================================================================
  //  Result channel / status
  // ===========================================================================
  assign res_valid   = w_valid & rst_n;
  assign res_tag     = w_tag;
  assign res_dkind   = w_dk;
  assign res_rd      = w_dst;
  assign res_mask    = w_wmask;
  assign res_data    = w_data;
  assign res_illegal = w_illegal;

  assign idle = ~ib_valid & ~o_valid & ~x_valid & ~m_valid & ~w_valid & ~busy;

`ifdef SFG1_ASSERT
  `include "sfg1_core_checks.svh"
`endif

endmodule
