// =============================================================================
//  sfg1_lane_alu -- one lane's single-cycle integer unit (combinational).
//  All arithmetic is 32-bit two's complement, modulo 2^32:
//    ADD/SUB   wrap silently; no trap, no saturation, no sticky flag.
//    shifts    amount = b[4:0]; b[31:5] ignored; amount 0..31 (32 == 0).
//    SHR       logical (zero fill)      SAR  arithmetic (sign fill)
//    SLT/SLTU  signed/unsigned a<b -> 32-bit 0 or 1
//    CMP       condition code `cond` -> bit 0 (SETP); upper bits zero
//    PASS      y = a
// =============================================================================
module sfg1_lane_alu
  import sfg1_pkg::*;
(
  input  alu_op_e     op,
  input  logic [3:0]  cond,
  input  logic [31:0] a,
  input  logic [31:0] b,
  output logic [31:0] y
);
  wire [4:0] sh  = b[4:0];
  wire       eq  = (a == b);
  wire       lts = ($signed(a) < $signed(b));
  wire       ltu = (a < b);

  logic cmp;
  always_comb begin
    case (cond)
      4'd0:    cmp = eq;
      4'd1:    cmp = ~eq;
      4'd2:    cmp = lts;
      4'd3:    cmp = lts | eq;
      4'd4:    cmp = ~(lts | eq);
      4'd5:    cmp = ~lts;
      4'd6:    cmp = ltu;
      4'd7:    cmp = ltu | eq;
      4'd8:    cmp = ~(ltu | eq);
      4'd9:    cmp = ~ltu;
      default: cmp = 1'b0;
    endcase
  end

  logic [31:0] sra;
  assign sra = $unsigned($signed(a) >>> sh);

  always_comb begin
    case (op)
      ALU_ADD:  y = a + b;
      ALU_SUB:  y = a - b;
      ALU_AND:  y = a & b;
      ALU_OR:   y = a | b;
      ALU_XOR:  y = a ^ b;
      ALU_SHL:  y = a << sh;
      ALU_SHR:  y = a >> sh;
      ALU_SAR:  y = sra;
      ALU_SLT:  y = {31'd0, lts};
      ALU_SLTU: y = {31'd0, ltu};
      ALU_CMP:  y = {31'd0, cmp};
      ALU_PASS: y = a;
      default:  y = 32'd0;
    endcase
  end
endmodule
