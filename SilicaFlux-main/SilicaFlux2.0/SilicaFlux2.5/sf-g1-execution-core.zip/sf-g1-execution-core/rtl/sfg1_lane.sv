// =============================================================================
//  sfg1_lane -- one lane's datapath: operand select, X-stage registers, fast
//  ALU, pipelined multiplier, and the W-stage data register.
//
//  O stage (comb):   opa = a_imm ? imm : rf_a      opb = b_imm ? imm : rf_b
//  X stage (regs):   x_a/x_b hold operands; fast ALU result and the multiplier
//                    product are computed from them in this cycle
//  M stage (regs):   m_prod holds the 64-bit product (MUL path only)
//  W stage (regs):   w_data <= sel_m ? (m_hi ? prod[63:32] : prod[31:0]) : fast_y
//
//  `adv` is the core's global advance (= ~stall). All data registers hold when
//  adv=0, so a stalled pipeline keeps every in-flight value. Data registers are
//  not reset (valid bits in the core qualify them) -> no reset fan-out.
//
//  The product is a 33x33 signed multiply: each 32-bit operand is extended by
//  one bit (sign or zero, per MUL variant) so one multiplier covers signed x
//  signed, unsigned x unsigned and signed x unsigned.
// =============================================================================
module sfg1_lane
  import sfg1_pkg::*;
(
  input  logic        clk,
  input  logic        adv,
  // O-stage operand select
  input  logic [31:0] rf_a,
  input  logic [31:0] rf_b,
  input  logic [31:0] imm,
  input  logic        a_imm,
  input  logic        b_imm,
  // X-stage controls (registered in the core, broadcast to all lanes)
  input  alu_op_e     x_alu_op,
  input  logic [3:0]  x_cond,
  input  logic        x_sa,        // treat operand A as signed
  input  logic        x_sb,        // treat operand B as signed
  // M / W controls
  input  logic        m_hi,        // select high word of the product
  input  logic        sel_m,       // W takes the MUL path (else the fast path)
  output logic [31:0] w_data
);
  logic [31:0] x_a, x_b;

  wire [31:0] opa = a_imm ? imm : rf_a;
  wire [31:0] opb = b_imm ? imm : rf_b;

  always_ff @(posedge clk) begin
    if (adv) begin
      x_a <= opa;
      x_b <= opb;
    end
  end

  logic [31:0] fast_y;
  sfg1_lane_alu u_alu (.op(x_alu_op), .cond(x_cond), .a(x_a), .b(x_b), .y(fast_y));

  wire signed [32:0] ma   = {x_sa & x_a[31], x_a};
  wire signed [32:0] mb   = {x_sb & x_b[31], x_b};
  /* verilator lint_off UNUSEDSIGNAL */
  wire signed [65:0] prod = ma * mb;          // [65:64] are sign copies: dropped
  /* verilator lint_on UNUSEDSIGNAL */

  logic [63:0] m_prod;
  always_ff @(posedge clk) begin
    if (adv) m_prod <= prod[63:0];
  end

  wire [31:0] m_y = m_hi ? m_prod[63:32] : m_prod[31:0];

  always_ff @(posedge clk) begin
    if (adv) w_data <= sel_m ? m_y : fast_y;
  end
endmodule
