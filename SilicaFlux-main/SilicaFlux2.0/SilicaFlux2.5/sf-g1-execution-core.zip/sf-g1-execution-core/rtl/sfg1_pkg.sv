// =============================================================================
//  SF-G1 execution core -- shared types and encodings
//  Normative ISA definition: python/sfg1/isa.py and docs/SF-G1_SPEC.md
// =============================================================================
package sfg1_pkg;
  /* verilator lint_off UNUSEDPARAM */

  localparam int unsigned XLEN  = 32;
  localparam int unsigned NGPR  = 32;   // r0 reads as zero, writes discarded
  localparam int unsigned NPRED = 8;    // p0 = PT (constant true), p1..p7 writable

  // Major opcodes insn[31:26]. 0x00/0x01/0x08/0x0F follow SilicaFlux v1 (sfx_asm.py).
  localparam logic [5:0] OPC_ILLEGAL = 6'h00;
  localparam logic [5:0] OPC_NOP     = 6'h01;
  localparam logic [5:0] OPC_ALU_R   = 6'h08;
  localparam logic [5:0] OPC_LUI     = 6'h0F;
  localparam logic [5:0] OPC_SETP    = 6'h38;   // SF-G1 extension (SFX "XU" port)
  localparam logic [5:0] OPC_MOVI    = 6'h39;   // SF-G1 extension

  // Single-cycle ("fast path") datapath operations.
  typedef enum logic [3:0] {
    ALU_ADD  = 4'd0,
    ALU_SUB  = 4'd1,
    ALU_AND  = 4'd2,
    ALU_OR   = 4'd3,
    ALU_XOR  = 4'd4,
    ALU_SHL  = 4'd5,
    ALU_SHR  = 4'd6,
    ALU_SAR  = 4'd7,
    ALU_SLT  = 4'd8,
    ALU_SLTU = 4'd9,
    ALU_CMP  = 4'd10,   // SETP: condition code selects the comparison
    ALU_PASS = 4'd11    // result = operand A (MOVI / LUI)
  } alu_op_e;

  // Multiplier variants (long path).
  typedef enum logic [1:0] {
    MUL_LO  = 2'd0,     // low 32 bits, sign-agnostic
    MUL_HS  = 2'd1,     // high 32 bits, signed   x signed
    MUL_HU  = 2'd2,     // high 32 bits, unsigned x unsigned
    MUL_HSU = 2'd3      // high 32 bits, signed rs1 x unsigned rs2
  } mul_op_e;

  // Destination class reported on the result channel.
  typedef enum logic [1:0] {
    DK_NONE = 2'd0,     // illegal / NOP / r0 / p0 destination: nothing is written
    DK_GPR  = 2'd1,
    DK_PRED = 2'd2
  } dkind_e;

  // Decoded instruction (output of sfg1_decode, registered at issue).
  typedef struct packed {
    logic        legal;
    logic        is_mul;
    alu_op_e     alu_op;
    mul_op_e     mul_op;
    logic [3:0]  cond;
    logic [4:0]  rs1;
    logic [4:0]  rs2;
    logic        rs1_used;
    logic        rs2_used;
    logic        a_imm;       // operand A = imm (MOVI/LUI) instead of RF[rs1]
    logic        b_imm;       // operand B = imm (R-type with I flag) instead of RF[rs2]
    logic [31:0] imm;
    dkind_e      dkind;
    logic [4:0]  dst;         // GPR index, or predicate index in [2:0]
    logic [2:0]  gsel;        // guard predicate select (0 = PT)
    logic        gneg;        // guard negate
  } dec_t;

  /* verilator lint_on UNUSEDPARAM */
endpackage
