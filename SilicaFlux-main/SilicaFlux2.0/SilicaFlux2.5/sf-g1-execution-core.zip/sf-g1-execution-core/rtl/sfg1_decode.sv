// =============================================================================
//  sfg1_decode -- purely combinational instruction decode.
//  Illegal words decode to a no-op: no register use, no destination, no guard,
//  so they can never raise a hazard or write state; they still flow through
//  the pipeline and retire exactly once with res_illegal=1.
// =============================================================================
module sfg1_decode
  import sfg1_pkg::*;
(
  input  logic [31:0] insn,
  output dec_t        dec
);
  logic [5:0] opc, f;
  logic [4:0] ra, rb, rc, d;
  logic [4:0] imm5;

  assign opc  = insn[31:26];
  assign ra   = insn[25:21];
  assign rb   = insn[20:16];
  assign rc   = insn[15:11];
  assign d    = insn[10:6];
  assign f    = insn[5:0];
  assign imm5 = rc;

  always_comb begin
    dec          = '0;
    dec.alu_op   = ALU_ADD;
    dec.mul_op   = MUL_LO;
    dec.dkind    = DK_NONE;

    case (opc)
      OPC_NOP: begin
        dec.legal = (insn[25:0] == 26'd0);
      end

      OPC_ALU_R: begin
        dec.legal = 1'b1;
        case (f)
          6'd0:  dec.alu_op = ALU_ADD;
          6'd1:  dec.alu_op = ALU_SUB;
          6'd2:  begin dec.is_mul = 1'b1; dec.mul_op = MUL_LO;  end
          6'd3:  dec.alu_op = ALU_AND;
          6'd4:  dec.alu_op = ALU_OR;
          6'd5:  dec.alu_op = ALU_XOR;
          6'd6:  dec.alu_op = ALU_SHL;
          6'd7:  dec.alu_op = ALU_SHR;
          6'd8:  dec.alu_op = ALU_SAR;
          6'd9:  dec.alu_op = ALU_SLT;
          6'd10: dec.alu_op = ALU_SLTU;
          6'd11: begin dec.is_mul = 1'b1; dec.mul_op = MUL_HS;  end
          6'd12: begin dec.is_mul = 1'b1; dec.mul_op = MUL_HU;  end
          6'd13: begin dec.is_mul = 1'b1; dec.mul_op = MUL_HSU; end
          default: dec.legal = 1'b0;
        endcase
        if (dec.legal) begin
          dec.rs1      = rb;
          dec.rs2      = rc;
          dec.rs1_used = 1'b1;
          dec.rs2_used = ~d[4];
          dec.b_imm    = d[4];
          dec.imm      = {{27{imm5[4]}}, imm5};
          dec.dst      = ra;
          dec.dkind    = (ra != 5'd0) ? DK_GPR : DK_NONE;
          dec.gsel     = d[2:0];
          dec.gneg     = d[3];
        end
      end

      OPC_SETP: begin
        dec.legal = (f <= 6'd9) && (ra[4:3] == 2'b00);
        if (dec.legal) begin
          dec.alu_op   = ALU_CMP;
          dec.cond     = f[3:0];
          dec.rs1      = rb;
          dec.rs2      = rc;
          dec.rs1_used = 1'b1;
          dec.rs2_used = ~d[4];
          dec.b_imm    = d[4];
          dec.imm      = {{27{imm5[4]}}, imm5};
          dec.dst      = {2'b00, ra[2:0]};
          dec.dkind    = (ra[2:0] != 3'd0) ? DK_PRED : DK_NONE;
          dec.gsel     = d[2:0];
          dec.gneg     = d[3];
        end
      end

      OPC_MOVI, OPC_LUI: begin
        dec.legal = ~rb[4];                       // G[4] reserved
        if (dec.legal) begin
          dec.alu_op = ALU_PASS;
          dec.a_imm  = 1'b1;
          dec.imm    = (opc == OPC_MOVI) ? {{16{insn[15]}}, insn[15:0]} : {insn[15:0], 16'd0};
          dec.dst    = ra;
          dec.dkind  = (ra != 5'd0) ? DK_GPR : DK_NONE;
          dec.gsel   = rb[2:0];
          dec.gneg   = rb[3];
        end
      end

      default: dec.legal = 1'b0;
    endcase
  end
endmodule
