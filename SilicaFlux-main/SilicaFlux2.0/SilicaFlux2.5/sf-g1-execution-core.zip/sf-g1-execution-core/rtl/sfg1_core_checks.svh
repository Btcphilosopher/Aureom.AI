// =============================================================================
//  sfg1_core_checks.svh -- assertions + functional coverage counters.
//  Included inside sfg1_core under `ifdef SFG1_ASSERT (never synthesised).
//  Written as concurrent SVA; simulated with Verilator --assert (5.020).
//  "a_env_*" check the DRIVER of the channels (protocol obligations of the
//  environment); everything else checks the core.
// =============================================================================

  // ------------------------------------------------------------------ protocol
  a_env_iss_stable: assert property (@(posedge clk) disable iff (!rst_n)
      (iss_valid && !iss_ready) |=>
        (iss_valid && $stable(iss_insn) && $stable(iss_mask) && $stable(iss_tag)))
    else $error("SFG1 ENV: issue valid dropped or payload changed before acceptance");

  a_env_xw_stable: assert property (@(posedge clk) disable iff (!rst_n)
      (xw_valid && !xw_ready) |=>
        (xw_valid && $stable(xw_rd) && $stable(xw_mask) && $stable(xw_data)))
    else $error("SFG1 ENV: xw valid dropped or payload changed before acceptance");

  a_res_hold: assert property (@(posedge clk) disable iff (!rst_n)
      (res_valid && !res_ready) |=>
        (res_valid && $stable(res_tag) && $stable(res_dkind) && $stable(res_rd) &&
         $stable(res_mask) && $stable(res_data) && $stable(res_illegal)))
    else $error("SFG1: result channel retracted or changed while stalled");

  a_rst_quiet: assert property (@(posedge clk)
      !rst_n |-> (!res_valid && !iss_ready && !xw_ready))
    else $error("SFG1: handshake outputs active during reset");

  a_busy_quiet: assert property (@(posedge clk) disable iff (!rst_n)
      busy |-> (!iss_ready && !xw_ready && !res_valid && !gw_en && !pw_en))
    else $error("SFG1: activity during RF clear sequence");

  a_ib_no_overflow: assert property (@(posedge clk) disable iff (!rst_n)
      ib_push |-> !ib_full)
    else $error("SFG1: push into full input FIFO");

  // ----------------------------------------------- exactly-once instruction flow
  int unsigned acc_cnt, ret_cnt;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      acc_cnt <= 0;
      ret_cnt <= 0;
    end else begin
      if (ib_push) acc_cnt <= acc_cnt + 1;
      if (w_fire)  ret_cnt <= ret_cnt + 1;
    end
  end

  a_conserve: assert property (@(posedge clk) disable iff (!rst_n)
      (acc_cnt - ret_cnt) ==
        (int'(ib_count) + int'(o_valid) + int'(x_valid) + int'(m_valid) + int'(w_valid)))
    else $error("SFG1: instruction lost or duplicated (accepted-retired != in flight)");

  // ----------------------------------------------------------------- scoreboard
  function automatic int unsigned has_dst(input logic v, input dkind_e dk);
    return (v && dk != DK_NONE) ? 1 : 0;
  endfunction

  a_sb_conserve: assert property (@(posedge clk) disable iff (!rst_n)
      ($countones(pend_g) + $countones(pend_p)) ==
        (has_dst(o_valid, o_dec.dkind) + has_dst(x_valid, x_dk) +
         has_dst(m_valid, m_dk) + has_dst(w_valid, w_dk)))
    else $error("SFG1: scoreboard bits != in-flight destinations (leak or WAW overlap)");

  a_sb_zero: assert property (@(posedge clk) disable iff (!rst_n) !pend_g[0] && !pend_p[0])
    else $error("SFG1: r0/p0 marked pending");

  // independent re-check of the hazard rule at the moment of issue
  wire rel_g1 = w_fire && (w_dk == DK_GPR)  && (w_dst == dec.rs1);
  wire rel_g2 = w_fire && (w_dk == DK_GPR)  && (w_dst == dec.rs2);
  wire rel_gd = w_fire && (w_dk == DK_GPR)  && (w_dst == dec.dst);
  wire rel_pg = w_fire && (w_dk == DK_PRED) && (w_dst[2:0] == dec.gsel);
  wire rel_pd = w_fire && (w_dk == DK_PRED) && (w_dst[2:0] == dec.dst[2:0]);

  a_issue_raw1: assert property (@(posedge clk) disable iff (!rst_n)
      (issue_go && dec.rs1_used && dec.rs1 != 0) |-> (!pend_g[dec.rs1] || rel_g1))
    else $error("SFG1: issued with pending rs1 (RAW)");
  a_issue_raw2: assert property (@(posedge clk) disable iff (!rst_n)
      (issue_go && dec.rs2_used && dec.rs2 != 0) |-> (!pend_g[dec.rs2] || rel_g2))
    else $error("SFG1: issued with pending rs2 (RAW)");
  a_issue_rawp: assert property (@(posedge clk) disable iff (!rst_n)
      (issue_go && dec.gsel != 0) |-> (!pend_p[dec.gsel] || rel_pg))
    else $error("SFG1: issued with pending guard predicate (RAW)");
  a_issue_wawg: assert property (@(posedge clk) disable iff (!rst_n)
      (issue_go && dec.dkind == DK_GPR) |-> (!pend_g[dec.dst] || rel_gd))
    else $error("SFG1: issued with pending GPR destination (WAW)");
  a_issue_wawp: assert property (@(posedge clk) disable iff (!rst_n)
      (issue_go && dec.dkind == DK_PRED) |-> (!pend_p[dec.dst[2:0]] || rel_pd))
    else $error("SFG1: issued with pending predicate destination (WAW)");

  // --------------------------------------------------------- pipeline structure
  a_slot: assert property (@(posedge clk) disable iff (!rst_n)
      !(x_valid && !x_is_mul && m_valid))
    else $error("SFG1: fast op and MUL would both reach W (writeback slot conflict)");

  a_freeze: assert property (@(posedge clk) disable iff (!rst_n)
      stall |=> ($stable({o_valid, x_valid, m_valid, w_valid}) && $stable(w_data) &&
                 $stable(w_tag) && $stable(pend_g) && $stable(pend_p)))
    else $error("SFG1: pipeline state moved during a stall");

  a_stall_no_issue: assert property (@(posedge clk) disable iff (!rst_n)
      stall |-> !issue_go && !o_go)
    else $error("SFG1: issue/dispatch during stall");

  // ----------------------------------------------------------- result integrity
  a_none_nomask: assert property (@(posedge clk) disable iff (!rst_n)
      (w_valid && w_dk == DK_NONE) |-> (w_wmask == '0))
    else $error("SFG1: lanes written for a NONE destination");

  a_illegal_inert: assert property (@(posedge clk) disable iff (!rst_n)
      (w_valid && w_illegal) |-> (w_dk == DK_NONE))
    else $error("SFG1: illegal instruction has a destination");

  a_dst_valid: assert property (@(posedge clk) disable iff (!rst_n)
      w_valid |-> ((w_dk == DK_GPR  && w_dst != 5'd0) ||
                   (w_dk == DK_PRED && w_dst[4:3] == 2'b00 && w_dst[2:0] != 3'd0) ||
                   (w_dk == DK_NONE)))
    else $error("SFG1: W holds a write to r0/p0 or a bad predicate index");

  // ------------------------------------------------- inactive lanes never written
  // shadow of the ISSUE mask carried alongside the pipeline (checking only)
  logic [LANES-1:0] sh_o, sh_x, sh_m, sh_w;
  always_ff @(posedge clk) begin
    if (issue_go) sh_o <= ib_mask;
    if (!stall) begin
      sh_x <= sh_o;
      sh_m <= sh_x;
      sh_w <= m_valid ? sh_m : sh_x;
    end
  end

  a_lane_subset: assert property (@(posedge clk) disable iff (!rst_n)
      w_valid |-> ((w_wmask & ~sh_w) == '0))
    else $error("SFG1: write mask has lanes outside the issue mask");

  a_gpr_lanes: assert property (@(posedge clk) disable iff (!rst_n)
      w_gpr_wr |-> (gw_lane == w_wmask && !xw_fire))
    else $error("SFG1: GPR write port lanes/arbitration wrong");

  a_xw_ordered: assert property (@(posedge clk) disable iff (!rst_n)
      xw_fire |-> (!ib_valid && !iss_ready))
    else $error("SFG1: external write accepted while instructions were still queued");

  a_xw_priority: assert property (@(posedge clk) disable iff (!rst_n)
      xw_valid |-> !iss_ready)
    else $error("SFG1: instruction accepted while an external write is waiting");

  a_xw_safe: assert property (@(posedge clk) disable iff (!rst_n)
      xw_fire |-> (xw_rd == 5'd0 || !pend_g[xw_rd]))
    else $error("SFG1: external write accepted onto a register with a write in flight");

  // ------------------------------------------------------------------- coverage
  // m_valid delayed by one advancing cycle == "the result now in W came from the MUL path"
  logic m_valid_d;
  always_ff @(posedge clk) if (!stall) m_valid_d <= m_valid;

  int unsigned cv_stall, cv_slot, cv_haz, cv_fwd, cv_xw_block, cv_ib_full;
  int unsigned cv_mask_zero, cv_mask_part, cv_illegal, cv_mul, cv_pred_wr;
  always_ff @(posedge clk) begin
    if (rst_n) begin
      if (stall)                          cv_stall    <= cv_stall + 1;
      if (o_valid && slot_conflict)       cv_slot     <= cv_slot + 1;
      if (ib_valid && hazard)             cv_haz      <= cv_haz + 1;
      if (issue_go && w_fire &&
          ((w_dk == DK_GPR  && ((dec.rs1_used && dec.rs1 == w_dst) || (dec.rs2_used && dec.rs2 == w_dst))) ||
           (w_dk == DK_PRED && dec.gsel != 0 && dec.gsel == w_dst[2:0])))
                                          cv_fwd      <= cv_fwd + 1;
      if (xw_valid && !xw_ready)          cv_xw_block <= cv_xw_block + 1;
      if (ib_full)                        cv_ib_full  <= cv_ib_full + 1;
      if (w_fire && w_dk != DK_NONE && w_wmask == '0)           cv_mask_zero <= cv_mask_zero + 1;
      if (w_fire && w_dk != DK_NONE && w_wmask != '0 && w_wmask != {LANES{1'b1}})
                                          cv_mask_part <= cv_mask_part + 1;
      if (w_fire && w_illegal)            cv_illegal  <= cv_illegal + 1;
      if (w_fire && m_valid_d)            cv_mul      <= cv_mul + 1;
      if (w_fire && w_dk == DK_PRED)      cv_pred_wr  <= cv_pred_wr + 1;
    end
  end
  initial begin
    cv_stall = 0; cv_slot = 0; cv_haz = 0; cv_fwd = 0; cv_xw_block = 0; cv_ib_full = 0;
    cv_mask_zero = 0; cv_mask_part = 0; cv_illegal = 0; cv_mul = 0; cv_pred_wr = 0;
  end

  final begin
    $display("SFG1_COV lanes=%0d accepted=%0d retired=%0d stall_cycles=%0d slot_conflicts=%0d hazard_stall_cycles=%0d same_cycle_fwd=%0d xw_blocked_cycles=%0d ib_full_cycles=%0d mask_zero=%0d mask_partial=%0d illegal=%0d mul_retired=%0d pred_wr=%0d",
             LANES, acc_cnt, ret_cnt, cv_stall, cv_slot, cv_haz, cv_fwd, cv_xw_block, cv_ib_full,
             cv_mask_zero, cv_mask_part, cv_illegal, cv_mul, cv_pred_wr);
  end
