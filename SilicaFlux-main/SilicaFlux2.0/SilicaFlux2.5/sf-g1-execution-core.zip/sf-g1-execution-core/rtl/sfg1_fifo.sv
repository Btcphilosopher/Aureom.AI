// =============================================================================
//  sfg1_fifo -- small shift-register elastic buffer (input stage of the core).
//    * head entry is always entry 0 -> `dout` comes straight from flops
//    * `full` / `valid` are functions of the occupancy register only, so the
//      core's iss_ready never depends on iss_valid or on the payload
//    * push when full is ignored (caller must not do it; asserted in the core)
// =============================================================================
module sfg1_fifo #(
  parameter int unsigned W     = 32,
  parameter int unsigned DEPTH = 2
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         push,
  input  logic [W-1:0] din,
  output logic         full,
  input  logic         pop,
  output logic         valid,
  output logic [W-1:0] dout,
  output logic [$clog2(DEPTH+1)-1:0] count
);
  localparam int unsigned IW = (DEPTH > 1) ? $clog2(DEPTH) : 1;   // entry index width
  localparam int unsigned CW = $clog2(DEPTH+1);                    // occupancy width

  logic [W-1:0] mem [DEPTH];
  logic [CW-1:0] cnt;

  assign count = cnt;
  assign full  = (cnt == CW'(DEPTH));
  assign valid = (cnt != '0);
  assign dout  = mem[0];

  wire do_push = push & ~full;
  wire do_pop  = pop & valid;
  /* verilator lint_off UNUSEDSIGNAL */
  wire [CW-1:0] wpos_full = do_pop ? (cnt - 1'b1) : cnt;
  /* verilator lint_on UNUSEDSIGNAL */
  wire [IW-1:0] wpos      = wpos_full[IW-1:0];      // < DEPTH whenever do_push is legal

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      cnt <= '0;
    end else begin
      case ({do_push, do_pop})
        2'b10:   cnt <= cnt + 1'b1;
        2'b01:   cnt <= cnt - 1'b1;
        default: cnt <= cnt;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    if (do_pop) begin
      for (int i = 0; i < int'(DEPTH) - 1; i++) mem[i] <= mem[i+1];
    end
    if (do_push) mem[wpos] <= din;      // later NBA wins over the shift above
  end
endmodule
