// =============================================================================
//  sfg1_scoreboard -- per-register "write in flight" bits (GPR r1..r31, P p1..p7)
//
//  A bit is SET when an instruction with that destination issues, and CLEARED
//  when that instruction commits its result (retires).  Granularity is the whole
//  register (all lanes): the core issues one instruction for all lanes at once.
//
//  Hazards checked for the instruction presented at the issue stage:
//    RAW  source rs1 / rs2 / guard predicate pending
//    WAW  destination pending (needed because the MUL path is longer than the
//         fast path, so a younger fast write could otherwise overtake an
//         older MUL write to the same register)
//    WAR  cannot occur: operands are read at issue, in order.
//
//  SAME-CYCLE RELEASE: a commit happening in the current cycle (clr_*) hides
//  the corresponding pending bit from the hazard query, so a dependent
//  instruction may issue in the very cycle its producer retires.  The
//  register file forwards the committed data to that reader (see sfg1_regfile).
//  If an issue (set_*) and a commit (clr_*) hit the same bit in one cycle,
//  SET wins (the new producer is now the pending one).
// =============================================================================
module sfg1_scoreboard
  import sfg1_pkg::*;
(
  input  logic        clk,
  input  logic        rst_n,
  // hazard query (instruction at the issue stage)
  input  logic        q_rs1_v,
  input  logic [4:0]  q_rs1,
  input  logic        q_rs2_v,
  input  logic [4:0]  q_rs2,
  input  logic [2:0]  q_gsel,         // 0 = PT: never a hazard
  input  dkind_e      q_dk,
  input  logic [4:0]  q_dst,
  output logic        hazard,
  // commit (retire) this cycle
  input  logic        clr_v,
  input  dkind_e      clr_dk,
  input  logic [4:0]  clr_idx,
  // issue this cycle
  input  logic        set_v,
  input  dkind_e      set_dk,
  input  logic [4:0]  set_idx,
  // external-write query (raw state, no same-cycle release)
  input  logic [4:0]  xq_idx,
  output logic        xq_pending,
  // observation (assertions / debug)
  output logic [31:0] pend_g_o,
  output logic [7:0]  pend_p_o
);
  logic [31:0] pg;     // bit 0 is never set
  logic [7:0]  pp;     // bit 0 is never set

  wire clr_g = clr_v & (clr_dk == DK_GPR);
  wire clr_p = clr_v & (clr_dk == DK_PRED);
  wire set_g = set_v & (set_dk == DK_GPR);
  wire set_p = set_v & (set_dk == DK_PRED);

  // effective pending after same-cycle release
  logic [31:0] pg_eff;
  logic [7:0]  pp_eff;
  always_comb begin
    pg_eff = pg;
    pp_eff = pp;
    if (clr_g) pg_eff[clr_idx]     = 1'b0;
    if (clr_p) pp_eff[clr_idx[2:0]] = 1'b0;
  end

  assign hazard =
      (q_rs1_v && (q_rs1 != 5'd0) && pg_eff[q_rs1]) ||
      (q_rs2_v && (q_rs2 != 5'd0) && pg_eff[q_rs2]) ||
      ((q_gsel != 3'd0)           && pp_eff[q_gsel]) ||
      ((q_dk == DK_GPR)           && pg_eff[q_dst]) ||
      ((q_dk == DK_PRED)          && pp_eff[q_dst[2:0]]);

  assign xq_pending = (xq_idx != 5'd0) && pg[xq_idx];
  assign pend_g_o   = pg;
  assign pend_p_o   = pp;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      pg <= '0;
      pp <= '0;
    end else begin
      // clears first, sets last: SET wins on a same-bit collision
      if (clr_g) pg[clr_idx]      <= 1'b0;
      if (clr_p) pp[clr_idx[2:0]] <= 1'b0;
      if (set_g) pg[set_idx]      <= 1'b1;
      if (set_p) pp[set_idx[2:0]] <= 1'b1;
    end
  end
endmodule
