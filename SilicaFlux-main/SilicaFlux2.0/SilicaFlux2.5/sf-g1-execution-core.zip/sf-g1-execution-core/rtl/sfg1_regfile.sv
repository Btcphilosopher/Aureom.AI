// =============================================================================
//  sfg1_regfile -- per-lane GPR file (32 x 32b x LANES) + predicate file
//
//  PORTS / TIMING
//    write  : one GPR write port (gw_*), one predicate write port (pw_*),
//             per-lane write enables. A write commits at the clock edge that
//             ends the cycle in which gw_en/pw_en are high.
//    read   : launched in cycle t with rd_en (rs1, rs2, psel); data is valid in
//             cycle t+1 and held until the next rd_en.  Two GPR read ports
//             (rs1, rs2) + one predicate read port, always available together:
//             there are NO read-port conflicts (each lane owns two replicated
//             RAMs, A for rs1 and B for rs2).
//
//  READ/WRITE CONFLICT RULES  (the contract the core relies on)
//    R1  A write committed in cycle t is visible to every read launched in a
//        cycle > t (it is in the RAM).
//    R2  A write committed in cycle t IS ALSO visible to a read launched in the
//        SAME cycle t ("same-cycle forwarding"). The RAMs are READ_FIRST, so they
//        return the old word; this module captures the incoming write data
//        and a per-lane "hit" flag at launch and muxes it over the RAM output.
//        The hit is per lane: a lane whose write enable is off keeps the RAM
//        value (an inactive lane is never forwarded and never written).
//    R3  Reads of r0 return zero regardless of RAM contents; writes to r0 are
//        dropped here (belt and braces: decode never issues them).
//    R4  Predicate p0 reads as all-ones (PT); writes to p0 are dropped.
//    R5  Only one GPR write per cycle exists by construction (the core
//        arbitrates the pipeline writeback and the external write port).
//
//  RESET: GPR contents live in RAM and cannot be reset in one cycle. After
//    rst_n goes high a clear sequencer writes zero to r0..r31 of all lanes
//    through the normal write port; `busy` is high for exactly 32 cycles.
//    Predicate flops are reset directly.
// =============================================================================
module sfg1_regfile #(
  parameter int unsigned LANES    = 8,
  parameter bit          USE_BRAM = 1'b0
) (
  input  logic                 clk,
  input  logic                 rst_n,
  output logic                 busy,        // clear sequencer running
  // GPR write
  input  logic                 gw_en,
  input  logic [LANES-1:0]     gw_lane,
  input  logic [4:0]           gw_addr,
  input  logic [LANES*32-1:0]  gw_data,
  // predicate write
  input  logic                 pw_en,
  input  logic [LANES-1:0]     pw_lane,
  input  logic [2:0]           pw_addr,
  input  logic [LANES-1:0]     pw_data,
  // read launch
  input  logic                 rd_en,
  input  logic [4:0]           rs1,
  input  logic [4:0]           rs2,
  input  logic [2:0]           psel,
  // read data (valid the cycle after rd_en)
  output logic [LANES*32-1:0]  rdata_a,
  output logic [LANES*32-1:0]  rdata_b,
  output logic [LANES-1:0]     pdata
);
  // ---------------------------------------------------------------- clear FSM
  logic [4:0] clr_cnt;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      busy    <= 1'b1;
      clr_cnt <= 5'd0;
    end else if (busy) begin
      clr_cnt <= clr_cnt + 5'd1;
      if (clr_cnt == 5'd31) busy <= 1'b0;
    end
  end

  // ------------------------------------------------------ effective write port
  logic [4:0]          wa;
  logic [LANES-1:0]    we_l;
  logic [LANES*32-1:0] wd;
  always_comb begin
    if (busy) begin
      wa   = clr_cnt;
      we_l = {LANES{1'b1}};
      wd   = '0;
    end else begin
      wa   = gw_addr;
      we_l = (gw_en && gw_addr != 5'd0) ? gw_lane : {LANES{1'b0}};   // R3
      wd   = gw_data;
    end
  end

  // ----------------------------------------------------------------- GPR lanes
  logic [LANES*32-1:0] ra_raw, rb_raw;
  logic [LANES*32-1:0] byp;                // write data captured at launch
  logic [LANES-1:0]    hit_a, hit_b;       // same-cycle write hit (per lane)
  logic                z_a, z_b;           // read of r0

  genvar k;
  generate
    for (k = 0; k < LANES; k++) begin : g_lane
      sfg1_gpr_ram #(.W(32), .USE_BRAM(USE_BRAM)) u_a (
        .clk(clk), .we(we_l[k]), .waddr(wa), .wdata(wd[32*k +: 32]),
        .re(rd_en), .raddr(rs1), .rdata(ra_raw[32*k +: 32]));
      sfg1_gpr_ram #(.W(32), .USE_BRAM(USE_BRAM)) u_b (
        .clk(clk), .we(we_l[k]), .waddr(wa), .wdata(wd[32*k +: 32]),
        .re(rd_en), .raddr(rs2), .rdata(rb_raw[32*k +: 32]));

      always_ff @(posedge clk) begin
        if (rd_en) begin
          hit_a[k]        <= we_l[k] && (wa == rs1);
          hit_b[k]        <= we_l[k] && (wa == rs2);
          byp[32*k +: 32] <= wd[32*k +: 32];
        end
      end

      assign rdata_a[32*k +: 32] = z_a ? 32'd0 : (hit_a[k] ? byp[32*k +: 32] : ra_raw[32*k +: 32]);
      assign rdata_b[32*k +: 32] = z_b ? 32'd0 : (hit_b[k] ? byp[32*k +: 32] : rb_raw[32*k +: 32]);
    end
  endgenerate

  always_ff @(posedge clk) begin
    if (rd_en) begin
      z_a <= (rs1 == 5'd0);
      z_b <= (rs2 == 5'd0);
    end
  end

  // ---------------------------------------------------------------- predicates
  /* verilator lint_off UNUSEDSIGNAL */
  logic [7:0][LANES-1:0] prf;              // entry 0 (PT) is never written: constant, removed by synthesis
  /* verilator lint_on UNUSEDSIGNAL */
  logic [LANES-1:0]      pg_raw, p_byp, p_hit;
  logic                  p_pt;

  wire pw_ok = pw_en && (pw_addr != 3'd0);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      prf <= '0;
    end else if (pw_ok) begin
      for (int i = 0; i < LANES; i++) begin
        if (pw_lane[i]) prf[pw_addr][i] <= pw_data[i];
      end
    end
  end

  always_ff @(posedge clk) begin
    if (rd_en) begin
      p_pt   <= (psel == 3'd0);
      pg_raw <= (psel == 3'd0) ? {LANES{1'b1}} : prf[psel];
      p_byp  <= pw_data;
      p_hit  <= pw_ok ? (pw_lane & {LANES{pw_addr == psel}}) : {LANES{1'b0}};
    end
  end

  assign pdata = p_pt ? {LANES{1'b1}} : ((p_hit & p_byp) | (~p_hit & pg_raw));   // R2, R4
endmodule
