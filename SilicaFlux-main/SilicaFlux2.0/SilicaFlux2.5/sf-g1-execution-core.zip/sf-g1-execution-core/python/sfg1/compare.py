"""Differential comparator: replay a DUT transaction log through the Python simulator.

Log lines (written by tb/tb_sfg1_diff.sv):
    HDR  lanes tag_w in_depth
    ACC  tag insn mask                     instruction accepted on the issue channel
    XWA  rd mask d0 .. dL-1                external write accepted
    RET  tag dkind idx mask illegal d0..   result transaction (committed write)
    RST                                    reset asserted (epoch boundary)
    END  accepted retired dropped resets

For every epoch (reset to reset) the simulator executes the ACCEPTED instructions
in acceptance order from a zeroed state and the DUT's results must match:
  * each RET tag was accepted in this epoch and retires exactly once
  * dkind / register index / write mask / illegal flag identical
  * data identical on every lane that was written (mask bit set)
  * results to the same destination register retire in program order
  * at the end of the last epoch every accepted instruction has retired
Instructions in flight when a reset hits are *dropped*: they never retire and
their effects must not be visible (post-reset state is zero; the generator
reads every register back to prove it).
"""
from __future__ import annotations

import sys
from collections import defaultdict
from typing import List, Tuple

from .isa import DKind
from .sim import Core


_MIN_FIELDS = {"HDR": 4, "ACC": 4, "XWA": 3, "RET": 6, "RST": 1, "END": 5}


def _check_shape(k, p, lanes):
    """Raise if a record is truncated (a simulation that aborts mid-write leaves a partial last line)."""
    if k not in _MIN_FIELDS:
        raise ValueError(f"unknown record type {k}")
    if len(p) < _MIN_FIELDS[k]:
        raise IndexError("too few fields")
    if k == "XWA" and lanes is not None and len(p) < 3 + lanes:
        raise IndexError("too few data words")
    if k == "RET" and lanes is not None and len(p) < 6 + lanes:
        raise IndexError("too few data words")
    for x in p[1:]:
        int(x, 16)           # every field is a number (decimal fields are also valid hex digits)


def compare(path: str, max_msgs: int = 10) -> Tuple[bool, dict, List[str]]:
    msgs: List[str] = []
    stats = defaultdict(int)

    def err(m):
        stats["errors"] += 1
        if len(msgs) < max_msgs:
            msgs.append(m)

    lanes = None
    core = None
    expected = {}        # tag -> (seq, ResultRec)
    last_seq = {}
    seq = 0
    end_line = None

    def new_epoch():
        nonlocal core, expected, last_seq, seq
        stats["dropped"] += len(expected)
        core = Core(lanes)
        expected, last_seq, seq = {}, {}, 0

    with open(path) as f:
        for ln, line in enumerate(f, 1):
            p = line.split()
            if not p:
                continue
            k = p[0]
            try:
                _check_shape(k, p, lanes)
            except (ValueError, IndexError) as e:
                err(f"line {ln}: malformed or truncated log record {line.strip()[:60]!r} ({e})")
                continue
            if k == "HDR":
                lanes = int(p[1])
                core = Core(lanes)
            elif k == "ACC":
                tag, insn, mask = int(p[1]), int(p[2], 16), int(p[3], 16)
                if tag in expected:
                    err(f"line {ln}: tag {tag} accepted twice without retiring")
                expected[tag] = (seq, core.step(insn, mask))
                seq += 1
                stats["accepted"] += 1
            elif k == "XWA":
                rd, mask = int(p[1]), int(p[2], 16)
                core.xw(rd, mask, [int(x, 16) for x in p[3:3 + lanes]])
                stats["xw"] += 1
            elif k == "RET":
                tag, dk, idx, mask, ill = int(p[1]), int(p[2]), int(p[3]), int(p[4], 16), int(p[5])
                data = [int(x, 16) for x in p[6:6 + lanes]]
                stats["retired"] += 1
                if tag not in expected:
                    err(f"line {ln}: result for tag {tag} that is not in flight (duplicate, stale or invented)")
                    continue
                s, exp = expected.pop(tag)
                got = (dk, idx, mask, tuple(data[l] if (mask >> l) & 1 else 0 for l in range(lanes)), bool(ill))
                want = exp.key_fields()
                if got != want:
                    err(f"line {ln}: tag {tag} mismatch\n    DUT  : dk={got[0]} idx={got[1]} mask={got[2]:x} ill={int(got[4])} data={[f'{x:08x}' for x in got[3]]}"
                        f"\n    MODEL: dk={want[0]} idx={want[1]} mask={want[2]:x} ill={int(want[4])} data={[f'{x:08x}' for x in want[3]]}")
                if dk != DKind.NONE:
                    key = (dk, idx)
                    if s < last_seq.get(key, -1):
                        err(f"line {ln}: tag {tag}: same-destination results out of program order")
                    last_seq[key] = s
            elif k == "RST":
                new_epoch()
                stats["resets"] += 1
            elif k == "END":
                end_line = p
    if lanes is None:
        err("log has no header")
    if end_line is None:
        err("log has no END record (simulation did not finish)")
    if expected:
        err(f"{len(expected)} accepted instruction(s) never retired in the final epoch: tags {sorted(expected)[:8]}")
    stats["dropped_by_reset"] = stats.pop("dropped", 0)
    return stats["errors"] == 0, dict(stats), msgs


def main(argv=None):
    argv = argv or sys.argv[1:]
    ok_all = True
    for path in argv:
        ok, stats, msgs = compare(path)
        print(("PASS" if ok else "FAIL"), path, dict(stats))
        for m in msgs:
            print("  ", m)
        ok_all &= ok
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
