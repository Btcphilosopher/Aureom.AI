"""SF-G1 execution-core ISA: encodings, decoder, mini assembler, disassembler.

STATUS OF THE SPECIFICATION
    No document named "SF-G1" exists in the repository this work was done in
    (searched all text, PDF and zip contents).  This module therefore *is* the
    normative definition of the minimal SF-G1 execution-core ISA used by the
    RTL in ../../rtl and by the reference simulator in sim.py.  It is anchored
    to the one related artefact that does exist, the SilicaFlux v1 assembler
    (``sfx_asm.py``): ``ALU_R`` opcode 0x08, funct6 0x00-0x0A, r0 == 0, 32-bit
    data, NOP == opcode 0x01, opcode 0x00 == ILLEGAL.  Every SFX-v1 ``ALU_R``
    word with a zero D field is a valid SF-G1 instruction with the same
    per-lane meaning.

INSTRUCTION WORD (32 bits)
    R-type  (ALU_R, SETP)
      31    26 25   21 20   16 15   11 10 9 8   6 5      0
     +--------+-------+-------+-------+--+--+-----+--------+
     | opcode |  rd   |  rs1  |rs2/imm| I| N|  P  | funct6 |
     +--------+-------+-------+-------+--+--+-----+--------+
      D field = insn[10:6] = {I, N, P[2:0]}
        P    guard predicate select (0 = PT, constant true; 1..7 = p1..p7)
        N    guard negate
        I    1: operand B is sign_extend(imm5 = insn[15:11]); 0: operand B = rs2
    I16-type (MOVI, LUI)
     | opcode |  rd   |0 N  P |        imm16          |
      G field = insn[20:16] = {0, N, P[2:0]} (bit 20 reserved, must be 0)
"""

from __future__ import annotations

import enum
from dataclasses import dataclass
from typing import Optional

XLEN = 32
MASK32 = 0xFFFF_FFFF
NUM_GPR = 32
NUM_PRED = 8        # p0 == PT (constant true, writes discarded), p1..p7 writable


class Opc(enum.IntEnum):
    ILLEGAL = 0x00
    NOP = 0x01
    ALU_R = 0x08     # SFX v1 numbering
    LUI = 0x0F       # SFX v1 numbering (B field = guard in SF-G1)
    SETP = 0x38      # SF-G1 extension, SFX "XU" dispatch port 7
    MOVI = 0x39      # SF-G1 extension


class Fn(enum.IntEnum):
    """funct6 of ALU_R.  0x00-0x0A are identical to SFX v1 AluFn."""
    ADD = 0x00
    SUB = 0x01
    MUL = 0x02       # low 32 bits (sign-agnostic)
    AND = 0x03
    OR = 0x04
    XOR = 0x05
    SHL = 0x06
    SHR = 0x07       # logical
    SAR = 0x08       # arithmetic
    SLT = 0x09       # signed   rd = (rs1 <  rs2) ? 1 : 0
    SLTU = 0x0A      # unsigned
    MULH = 0x0B      # high 32 of signed   x signed
    MULHU = 0x0C     # high 32 of unsigned x unsigned
    MULHSU = 0x0D    # high 32 of signed rs1 x unsigned rs2


class Cond(enum.IntEnum):
    """funct6 of SETP."""
    EQ = 0
    NE = 1
    LT = 2
    LE = 3
    GT = 4
    GE = 5
    LTU = 6
    LEU = 7
    GTU = 8
    GEU = 9


class DKind(enum.IntEnum):
    """Destination class reported on the result channel."""
    NONE = 0
    GPR = 1
    PRED = 2


MUL_FNS = (Fn.MUL, Fn.MULH, Fn.MULHU, Fn.MULHSU)


def sext(v: int, bits: int) -> int:
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v


def u32(v: int) -> int:
    return v & MASK32


def s32(v: int) -> int:
    return sext(v, 32)


# --------------------------------------------------------------------------
# Encoding
# --------------------------------------------------------------------------

def guard_bits(pred: int = 0, neg: bool = False) -> int:
    assert 0 <= pred < NUM_PRED
    return (int(neg) << 3) | pred


def enc_r(opc: int, rd: int, rs1: int, rs2_or_imm: int, funct: int,
          pred: int = 0, neg: bool = False, imm: bool = False) -> int:
    assert 0 <= rd < 32 and 0 <= rs1 < 32 and 0 <= (rs2_or_imm & 31) < 32
    d = (int(imm) << 4) | guard_bits(pred, neg)
    return (int(opc) << 26) | (rd << 21) | (rs1 << 16) | ((rs2_or_imm & 31) << 11) | (d << 6) | int(funct)


def enc_alu(fn: Fn, rd: int, rs1: int, rs2: int, **g) -> int:
    return enc_r(Opc.ALU_R, rd, rs1, rs2, fn, **g)


SHIFT_FNS = (Fn.SHL, Fn.SHR, Fn.SAR)


def enc_alu_imm(fn: Fn, rd: int, rs1: int, imm5: int, **g) -> int:
    # imm5 is sign-extended at execute.  Shifts only use the low 5 bits, so the
    # assembler also accepts the shift amounts 16..31 (same field value as -16..-1).
    hi = 31 if fn in SHIFT_FNS else 15
    assert -16 <= imm5 <= hi, f"imm5 {imm5} out of range for {fn.name}"
    return enc_r(Opc.ALU_R, rd, rs1, imm5 & 31, fn, imm=True, **g)


def enc_setp(cond: Cond, pd: int, rs1: int, rs2: int, **g) -> int:
    assert 0 <= pd < NUM_PRED
    return enc_r(Opc.SETP, pd, rs1, rs2, cond, **g)


def enc_setp_imm(cond: Cond, pd: int, rs1: int, imm5: int, **g) -> int:
    assert -16 <= imm5 <= 15 and 0 <= pd < NUM_PRED
    return enc_r(Opc.SETP, pd, rs1, imm5 & 31, cond, imm=True, **g)


def enc_i16(opc: int, rd: int, imm16: int, pred: int = 0, neg: bool = False) -> int:
    assert 0 <= rd < 32
    return (int(opc) << 26) | (rd << 21) | (guard_bits(pred, neg) << 16) | (imm16 & 0xFFFF)


def enc_movi(rd: int, imm16: int, **g) -> int:
    return enc_i16(Opc.MOVI, rd, imm16, **g)


def enc_lui(rd: int, imm16: int, **g) -> int:
    return enc_i16(Opc.LUI, rd, imm16, **g)


NOP_WORD = Opc.NOP << 26
ILLEGAL_WORD = 0


# --------------------------------------------------------------------------
# Decoder (architectural, bit-exact twin of rtl/sfg1_decode.sv)
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Decoded:
    legal: bool
    kind: str = "illegal"            # illegal | nop | alu | mul | setp | mov
    fn: Optional[int] = None         # Fn or Cond value
    rd: int = 0                      # destination index (GPR or predicate)
    dkind: DKind = DKind.NONE        # after r0/p0-discard normalisation
    rs1: int = 0
    rs2: int = 0
    rs1_used: bool = False
    rs2_used: bool = False
    use_imm: bool = False
    imm: int = 0                     # 32-bit value of immediate operand (B for R-type, A for MOVI/LUI)
    gsel: int = 0
    gneg: bool = False

    @property
    def guard_used(self) -> bool:
        return self.gsel != 0


_ILLEGAL = Decoded(legal=False)


def decode(insn: int) -> Decoded:
    insn &= MASK32
    opc = insn >> 26
    ra = (insn >> 21) & 31
    rb = (insn >> 16) & 31
    rc = (insn >> 11) & 31
    d = (insn >> 6) & 31
    f = insn & 63

    if opc == Opc.NOP:
        return Decoded(True, "nop") if (insn & 0x03FF_FFFF) == 0 else _ILLEGAL

    if opc in (Opc.ALU_R, Opc.SETP):
        use_imm = bool(d >> 4)
        gneg = bool((d >> 3) & 1)
        gsel = d & 7
        imm = u32(sext(rc, 5)) if use_imm else 0
        if opc == Opc.ALU_R:
            if f > Fn.MULHSU:
                return _ILLEGAL
            fn = Fn(f)
            dk = DKind.GPR if ra != 0 else DKind.NONE
            return Decoded(True, "mul" if fn in MUL_FNS else "alu", int(fn), ra, dk,
                           rb, rc, True, not use_imm, use_imm, imm, gsel, gneg)
        # SETP
        if f > Cond.GEU or (ra >> 3) != 0:
            return _ILLEGAL
        pd = ra & 7
        dk = DKind.PRED if pd != 0 else DKind.NONE
        return Decoded(True, "setp", f, pd, dk, rb, rc, True, not use_imm, use_imm, imm, gsel, gneg)

    if opc in (Opc.MOVI, Opc.LUI):
        g = rb
        if g >> 4:
            return _ILLEGAL
        imm16 = insn & 0xFFFF
        val = u32(sext(imm16, 16)) if opc == Opc.MOVI else u32(imm16 << 16)
        dk = DKind.GPR if ra != 0 else DKind.NONE
        return Decoded(True, "mov", None, ra, dk, 0, 0, False, False, True, val, g & 7, bool((g >> 3) & 1))

    return _ILLEGAL


# --------------------------------------------------------------------------
# Mini assembler / disassembler  (for tests and readable traces)
#   [(@|!@)pN] MNEMONIC operands          e.g.  @p1 ADD r3, r1, r2
#   imm operands:  #-5   (5-bit signed, R-type)   MOVI/LUI take a 16-bit value
#   SETP.LT p1, r2, r3   SETP.GEU p2, r4, #3
# --------------------------------------------------------------------------

def _reg(tok: str, prefix: str, limit: int) -> int:
    tok = tok.strip().lower()
    assert tok.startswith(prefix), f"expected {prefix}N, got {tok!r}"
    n = int(tok[len(prefix):])
    assert 0 <= n < limit, tok
    return n


def asm(line: str) -> int:
    line = line.split(";")[0].strip()
    pred, neg = 0, False
    if line.startswith("@") or line.startswith("!@"):
        guard, _, line = line.partition(" ")
        neg = guard.startswith("!")
        gname = guard.lstrip("!@").lower()
        pred = 0 if gname == "pt" else int(gname.lstrip("p"))
        line = line.strip()
    mnem, _, rest = line.partition(" ")
    mnem = mnem.upper()
    ops = [o.strip() for o in rest.split(",")] if rest.strip() else []
    g = dict(pred=pred, neg=neg)
    if mnem == "NOP":
        return NOP_WORD
    if mnem in ("MOVI", "LUI"):
        rd = _reg(ops[0], "r", 32)
        imm = int(ops[1], 0)
        return (enc_movi if mnem == "MOVI" else enc_lui)(rd, imm, **g)
    if mnem.startswith("SETP."):
        cond = Cond[mnem.split(".")[1]]
        pd = _reg(ops[0], "p", 8)
        rs1 = _reg(ops[1], "r", 32)
        if ops[2].startswith("#"):
            return enc_setp_imm(cond, pd, rs1, int(ops[2][1:], 0), **g)
        return enc_setp(cond, pd, rs1, _reg(ops[2], "r", 32), **g)
    fn = Fn[mnem]
    rd, rs1 = _reg(ops[0], "r", 32), _reg(ops[1], "r", 32)
    if ops[2].startswith("#"):
        return enc_alu_imm(fn, rd, rs1, int(ops[2][1:], 0), **g)
    return enc_alu(fn, rd, rs1, _reg(ops[2], "r", 32), **g)


def disasm(insn: int) -> str:
    dec = decode(insn)
    if not dec.legal:
        return f".illegal 0x{insn & MASK32:08x}"
    gtxt = ""
    if dec.gsel:
        gtxt = ("!@p%d " if dec.gneg else "@p%d ") % dec.gsel
    elif dec.gneg:
        gtxt = "!@pt "
    if dec.kind == "nop":
        return "NOP"
    if dec.kind == "mov":
        opc = insn >> 26
        v = (insn & 0xFFFF)
        return f"{gtxt}{'MOVI' if opc == Opc.MOVI else 'LUI'} r{dec.rd}, 0x{v:x}"
    b = f"#{s32(dec.imm)}" if dec.use_imm else f"r{dec.rs2}"
    if dec.kind == "setp":
        return f"{gtxt}SETP.{Cond(dec.fn).name} p{dec.rd}, r{dec.rs1}, {b}"
    return f"{gtxt}{Fn(dec.fn).name} r{dec.rd}, r{dec.rs1}, {b}"
