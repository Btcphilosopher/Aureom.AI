"""Stimulus generator for tb/tb_sfg1_diff.sv (see that file for the line format).

Random programs are biased to stress exactly the things that go wrong in this
kind of core: tight register pools (RAW / WAW / WAR chains), mixed fast and MUL
operations (out-of-order completion), predicate producer->guard chains, sparse
and zero execution masks, boundary-valued operands, mid-stream external writes,
producer gaps, result back-pressure and resets in the middle of activity.
"""
from __future__ import annotations

import argparse
import random
from dataclasses import dataclass
from typing import List

from . import isa
from .isa import Cond, Fn

BOUNDARY = [0, 1, 2, 3, 31, 32, 33, 0x7FFFFFFF, 0x80000000, 0x80000001, 0xFFFFFFFF, 0xFFFFFFFE,
            0x0000FFFF, 0xFFFF0000, 0x00010000, 0x55555555, 0xAAAAAAAA, 0x12345678, 0xDEADBEEF, 0x7FFFFFFE]


@dataclass
class Profile:
    name: str
    pool: int            # number of distinct GPRs used (small => dense hazards)
    mul: float = 0.20
    setp: float = 0.15
    imm: float = 0.20
    mov: float = 0.06
    nop: float = 0.02
    bad: float = 0.02
    guard: float = 0.35
    xw_mid: float = 0.02  # probability of a mid-stream external write
    pi: int = 0           # % producer idle cycles
    pr: int = 0           # % result stall cycles
    mask_full: float = 0.35
    mask_zero: float = 0.05
    resets: int = 0


PROFILES = {
    "mixed":   Profile("mixed", 8, pi=10, pr=25),
    "hazard":  Profile("hazard", 3, mul=0.30, pi=0, pr=0),
    "mul":     Profile("mul", 6, mul=0.65, setp=0.08, pi=0, pr=30),
    "pred":    Profile("pred", 6, setp=0.40, guard=0.75, pi=5, pr=15),
    "wide":    Profile("wide", 24, mul=0.10, pi=0, pr=0, xw_mid=0.01),
    "sparse":  Profile("sparse", 6, mask_full=0.05, mask_zero=0.15, pi=20, pr=40),
    "stall":   Profile("stall", 5, pi=30, pr=75),
    "reset":   Profile("reset", 6, pi=10, pr=25, resets=3),
}


class Stim:
    def __init__(self, lanes: int):
        self.lanes = lanes
        self.lines: List[str] = []
        self.ntag = 0

    def header(self, pi, pr, seed):
        self.lines.append(f"0 {self.lanes} {pi} {pr} {seed}")

    def insn(self, word, mask):
        self.lines.append(f"1 {word & 0xFFFFFFFF:08x} {mask:x}")
        self.ntag += 1

    def xw(self, rd, mask, data, drain=True):
        self.lines.append(f"{2 if drain else 6} {rd} {mask:x} " + " ".join(f"{d & 0xFFFFFFFF:08x}" for d in data))

    def drain(self):
        self.lines.append("3")

    def arm_reset(self, n, extra, hold):
        self.lines.append(f"4 {n} {extra} {hold}")

    def wait_reset(self):
        self.lines.append("7")

    def end(self):
        self.lines.append("9")

    def text(self):
        return "\n".join(self.lines) + "\n"


def readback(st: Stim, full_mask: int):
    """Copy every GPR (and expose every predicate) through the datapath. r0 is read too: it must be 0."""
    st.insn(isa.enc_alu(Fn.OR, 29, 0, 0), full_mask)
    st.insn(isa.enc_alu_imm(Fn.ADD, 30, 0, 0), full_mask)
    for r in range(1, 29):
        st.insn(isa.enc_alu_imm(Fn.ADD, 29 + (r % 3), r, 0), full_mask)
    for r in range(29, 32):
        st.insn(isa.enc_alu_imm(Fn.ADD, r - 28, r, 0), full_mask)
    for p in range(1, 8):
        st.insn(isa.enc_movi(31, 1, pred=p), full_mask)
    st.drain()


def rand_data(rng, lanes):
    return [rng.choice(BOUNDARY) if rng.random() < 0.5 else rng.getrandbits(32) for _ in range(lanes)]


def rand_mask(rng, lanes, prof: Profile):
    full = (1 << lanes) - 1
    x = rng.random()
    if x < prof.mask_full:
        return full
    if x < prof.mask_full + prof.mask_zero:
        return 0
    k = rng.random()
    if k < 0.15:
        return 1 << rng.randrange(lanes)
    if k < 0.30:
        return full & ~(1 << rng.randrange(lanes))
    if k < 0.40:
        return int("01" * lanes, 2) & full
    return rng.getrandbits(lanes)


def rand_insn(rng, prof: Profile, pool: List[int]) -> int:
    def reg(dst=False):
        if rng.random() < 0.08:
            return 0
        return rng.choice(pool)

    gp, gn = 0, False
    if rng.random() < prof.guard:
        gp, gn = rng.randrange(0, 8), rng.random() < 0.5
    x = rng.random()
    t = 0.0
    t += prof.bad
    if x < t:
        k = rng.random()
        if k < 0.5:
            return rng.getrandbits(32)
        return rng.choice([0, 0xFC000000, isa.enc_r(isa.Opc.ALU_R, 1, 1, 1, 14), isa.enc_r(isa.Opc.SETP, 1, 1, 1, 10),
                           isa.enc_r(isa.Opc.SETP, 9, 1, 1, 0), isa.NOP_WORD | 1, (isa.Opc.MOVI << 26) | (1 << 20),
                           (0x10 << 26) | rng.getrandbits(26)])
    t += prof.nop
    if x < t:
        return isa.NOP_WORD
    t += prof.mov
    if x < t:
        f = isa.enc_movi if rng.random() < 0.6 else isa.enc_lui
        return f(reg(True), rng.getrandbits(16), pred=gp, neg=gn)
    t += prof.setp
    if x < t:
        pd = rng.randrange(0, 8) if rng.random() < 0.1 else rng.randrange(1, 8)
        cond = Cond(rng.randrange(10))
        if rng.random() < prof.imm:
            return isa.enc_setp_imm(cond, pd, reg(), rng.randrange(-16, 16), pred=gp, neg=gn)
        return isa.enc_setp(cond, pd, reg(), reg(), pred=gp, neg=gn)
    if rng.random() < prof.mul / max(1e-9, 1 - t):
        fn = rng.choice([Fn.MUL, Fn.MUL, Fn.MULH, Fn.MULHU, Fn.MULHSU])
    else:
        fn = rng.choice([Fn.ADD, Fn.SUB, Fn.AND, Fn.OR, Fn.XOR, Fn.SHL, Fn.SHR, Fn.SAR, Fn.SLT, Fn.SLTU])
    if rng.random() < prof.imm:
        hi = 31 if fn in isa.SHIFT_FNS else 15
        return isa.enc_alu_imm(fn, reg(True), reg(), rng.randrange(-16, hi + 1), pred=gp, neg=gn)
    return isa.enc_alu(fn, reg(True), reg(), reg(), pred=gp, neg=gn)


def generate(lanes: int, seed: int, profile: str = "mixed", n: int = 500) -> str:
    rng = random.Random(f"{seed}/{profile}/{lanes}")      # str seeding is deterministic across runs
    prof = PROFILES[profile]
    full = (1 << lanes) - 1
    st = Stim(lanes)
    st.header(prof.pi, prof.pr, seed)
    pool = rng.sample(range(1, 32), prof.pool)

    def init_regs():
        for r in pool:
            st.xw(r, full, rand_data(rng, lanes), drain=True)
        # seed the predicates from the data so guards are lane-varying
        for p in range(1, 8):
            a, b = rng.choice(pool), rng.choice(pool)
            st.insn(isa.enc_setp(Cond(rng.randrange(10)), p, a, b), full)
        st.drain()

    init_regs()
    reset_points = sorted(rng.sample(range(n // 6, n - n // 6), prof.resets)) if prof.resets else []
    done = 0
    while done < n:
        if reset_points and done >= reset_points[0]:
            reset_points.pop(0)
            st.arm_reset(rng.randrange(1, 12), rng.randrange(0, 10), rng.randrange(1, 4))
            for _ in range(24):                       # stream that the reset will land in
                st.insn(rand_insn(rng, prof, pool), rand_mask(rng, lanes, prof))
                done += 1
            st.wait_reset()
            st.drain()
            readback(st, full)                        # post-reset architectural state must be all zero
            init_regs()
            continue
        st.insn(rand_insn(rng, prof, pool), rand_mask(rng, lanes, prof))
        done += 1
        if rng.random() < prof.xw_mid:
            r = 0 if rng.random() < 0.06 else rng.choice(pool)       # xw to r0 must be accepted and dropped
            st.xw(r, rand_mask(rng, lanes, prof) or full, rand_data(rng, lanes), drain=rng.random() < 0.3)
    st.drain()
    readback(st, full)
    st.end()
    return st.text()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--lanes", type=int, required=True)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--profile", choices=sorted(PROFILES), default="mixed")
    ap.add_argument("-n", type=int, default=500)
    ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    open(a.out, "w").write(generate(a.lanes, a.seed, a.profile, a.n))


if __name__ == "__main__":
    main()
