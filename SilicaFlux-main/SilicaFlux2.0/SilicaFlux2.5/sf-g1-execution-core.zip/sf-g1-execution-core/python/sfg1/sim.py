"""SF-G1 reference simulator (architectural / ISA level).

Executes one instruction at a time, in issue order, on LANES lanes.  It models
*architecture only*: results, register state, masks, illegal handling.  Timing
(latency, stalls, forwarding) is a micro-architecture property and is checked
by the SystemVerilog directed testbench, not here.

Result record == one transaction on the RTL result channel:
    ResultRec(dkind, idx, wmask, data[lanes], illegal)
      * dkind  NONE for illegal/NOP/r0/p0 destinations (write discarded)
      * wmask  lanes actually written = issue_mask & guard when dkind != NONE,
               and 0 when dkind == NONE (illegal, NOP, r0/p0 destination)
      * data   per-lane 32-bit result; only lanes with wmask[k]=1 are defined.
               For PRED destinations data[k] is 0 or 1.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .isa import (Cond, DKind, Fn, MASK32, NUM_GPR, NUM_PRED, decode, s32, u32)


@dataclass
class ResultRec:
    dkind: DKind
    idx: int
    wmask: int
    data: List[int]
    illegal: bool

    def key_fields(self):
        """Comparable view: data only on lanes with wmask set."""
        d = [self.data[k] if (self.wmask >> k) & 1 else 0 for k in range(len(self.data))]
        return (int(self.dkind), self.idx, self.wmask, tuple(d), self.illegal)


def alu_fast(fn: int, a: int, b: int) -> int:
    a, b = u32(a), u32(b)
    sh = b & 31
    if fn == Fn.ADD:
        return u32(a + b)
    if fn == Fn.SUB:
        return u32(a - b)
    if fn == Fn.AND:
        return a & b
    if fn == Fn.OR:
        return a | b
    if fn == Fn.XOR:
        return a ^ b
    if fn == Fn.SHL:
        return u32(a << sh)
    if fn == Fn.SHR:
        return a >> sh
    if fn == Fn.SAR:
        return u32(s32(a) >> sh)
    if fn == Fn.SLT:
        return int(s32(a) < s32(b))
    if fn == Fn.SLTU:
        return int(a < b)
    raise ValueError(fn)


def alu_mul(fn: int, a: int, b: int) -> int:
    a, b = u32(a), u32(b)
    if fn == Fn.MUL:
        return u32(a * b)
    if fn == Fn.MULH:
        return u32((s32(a) * s32(b)) >> 32)
    if fn == Fn.MULHU:
        return u32((a * b) >> 32)
    if fn == Fn.MULHSU:
        return u32((s32(a) * b) >> 32)
    raise ValueError(fn)


def compare(cond: int, a: int, b: int) -> int:
    a, b = u32(a), u32(b)
    sa, sb = s32(a), s32(b)
    return int({
        Cond.EQ: a == b, Cond.NE: a != b,
        Cond.LT: sa < sb, Cond.LE: sa <= sb, Cond.GT: sa > sb, Cond.GE: sa >= sb,
        Cond.LTU: a < b, Cond.LEU: a <= b, Cond.GTU: a > b, Cond.GEU: a >= b,
    }[Cond(cond)])


class Core:
    def __init__(self, lanes: int):
        self.lanes = lanes
        self.full = (1 << lanes) - 1
        self.reset()

    def reset(self):
        self.gpr = [[0] * self.lanes for _ in range(NUM_GPR)]
        # pred[0] is the constant-true predicate PT; stored for convenience
        self.pred = [[0] * self.lanes for _ in range(NUM_PRED)]
        self.pred[0] = [1] * self.lanes

    # ---- external register write (xw channel) -------------------------
    def xw(self, rd: int, mask: int, data: List[int]):
        if rd == 0:
            return
        for k in range(self.lanes):
            if (mask >> k) & 1:
                self.gpr[rd][k] = u32(data[k])

    # ---- one instruction ----------------------------------------------
    def step(self, insn: int, issue_mask: int) -> ResultRec:
        d = decode(insn)
        issue_mask &= self.full
        if not d.legal:
            return ResultRec(DKind.NONE, 0, 0, [0] * self.lanes, True)
        if d.kind == "nop":
            return ResultRec(DKind.NONE, 0, 0, [0] * self.lanes, False)

        emask = 0
        for k in range(self.lanes):
            g = 1 if d.gsel == 0 else self.pred[d.gsel][k]
            g ^= int(d.gneg)
            if g and (issue_mask >> k) & 1:
                emask |= 1 << k

        data = [0] * self.lanes
        for k in range(self.lanes):
            if not (emask >> k) & 1:
                continue
            if d.kind == "mov":
                data[k] = d.imm
                continue
            a = self.gpr[d.rs1][k]
            b = d.imm if d.use_imm else self.gpr[d.rs2][k]
            if d.kind == "alu":
                data[k] = alu_fast(d.fn, a, b)
            elif d.kind == "mul":
                data[k] = alu_mul(d.fn, a, b)
            elif d.kind == "setp":
                data[k] = compare(d.fn, a, b)

        if d.dkind == DKind.NONE:       # discarded destination: nothing written
            return ResultRec(DKind.NONE, 0, 0, [0] * self.lanes, False)
        rec = ResultRec(d.dkind, d.rd, emask, data, False)
        # commit: only active lanes, never r0 / p0
        if d.dkind == DKind.GPR:
            for k in range(self.lanes):
                if (emask >> k) & 1:
                    self.gpr[d.rd][k] = data[k]
        elif d.dkind == DKind.PRED:
            for k in range(self.lanes):
                if (emask >> k) & 1:
                    self.pred[d.rd][k] = data[k] & 1
        return rec
