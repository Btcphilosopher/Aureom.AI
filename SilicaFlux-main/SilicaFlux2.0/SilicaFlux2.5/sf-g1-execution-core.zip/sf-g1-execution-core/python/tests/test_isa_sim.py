"""Unit tests for the SF-G1 Python ISA layer and reference simulator.

Expected values are hand-computed literals (NOT produced by the model code), so
that these tests can catch a mistaken understanding in sim.py itself.
"""
import importlib.util
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from sfg1 import isa, sim  # noqa: E402
from sfg1.isa import DKind, Fn, Cond, asm, decode, disasm  # noqa: E402

INT_MIN, INT_MAX, M1 = 0x80000000, 0x7FFFFFFF, 0xFFFFFFFF


def run1(fn, a, b, lanes=1):
    c = sim.Core(lanes)
    c.xw(1, (1 << lanes) - 1, [a] * lanes)
    c.xw(2, (1 << lanes) - 1, [b] * lanes)
    r = c.step(isa.enc_alu(fn, 3, 1, 2), (1 << lanes) - 1)
    return r.data[0]


@pytest.mark.parametrize("fn,a,b,exp", [
    # add / sub wrap modulo 2^32, no trap
    (Fn.ADD, INT_MAX, 1, INT_MIN), (Fn.ADD, M1, 1, 0), (Fn.ADD, INT_MIN, INT_MIN, 0),
    (Fn.SUB, 0, 1, M1), (Fn.SUB, INT_MIN, 1, INT_MAX), (Fn.SUB, INT_MAX, M1, INT_MIN),
    # logic
    (Fn.AND, 0xF0F0F0F0, 0xFFFF0000, 0xF0F00000), (Fn.OR, 0xF0F0F0F0, 0x0F0F0F0F, M1),
    (Fn.XOR, M1, 0x0F0F0F0F, 0xF0F0F0F0),
    # shifts: amount = rs2[4:0]; 32 behaves as 0 (no saturation)
    (Fn.SHL, 1, 31, INT_MIN), (Fn.SHL, 1, 32, 1), (Fn.SHL, 0xFFFFFFFF, 0xFFFFFFE4, 0xFFFFFFF0),
    (Fn.SHR, INT_MIN, 31, 1), (Fn.SHR, INT_MIN, 32, INT_MIN), (Fn.SHR, M1, 4, 0x0FFFFFFF),
    (Fn.SAR, INT_MIN, 31, M1), (Fn.SAR, INT_MIN, 32, INT_MIN), (Fn.SAR, 0x7FFFFFFF, 31, 0),
    (Fn.SAR, 0xFFFFFFF0, 4, M1),
    # compares to GPR
    (Fn.SLT, INT_MIN, INT_MAX, 1), (Fn.SLT, INT_MAX, INT_MIN, 0), (Fn.SLT, M1, 0, 1), (Fn.SLT, 5, 5, 0),
    (Fn.SLTU, INT_MIN, INT_MAX, 0), (Fn.SLTU, 0, M1, 1), (Fn.SLTU, M1, 0, 0),
    # multiply: low word is sign-agnostic
    (Fn.MUL, 0x10000, 0x10000, 0), (Fn.MUL, M1, M1, 1), (Fn.MUL, INT_MIN, M1, INT_MIN),
    (Fn.MUL, INT_MIN, INT_MIN, 0), (Fn.MUL, 0x12345678, 0x9ABCDEF0, 0x242d2080),
    # high words
    (Fn.MULH, INT_MIN, INT_MIN, 0x40000000), (Fn.MULH, M1, M1, 0), (Fn.MULH, INT_MIN, M1, 0),
    (Fn.MULH, INT_MAX, INT_MAX, 0x3FFFFFFF), (Fn.MULH, INT_MIN, INT_MAX, 0xC0000000),
    (Fn.MULHU, M1, M1, 0xFFFFFFFE), (Fn.MULHU, INT_MIN, 2, 1), (Fn.MULHU, INT_MIN, INT_MIN, 0x40000000),
    (Fn.MULHSU, M1, M1, M1), (Fn.MULHSU, INT_MIN, M1, 0x80000000), (Fn.MULHSU, INT_MAX, M1, 0x7FFFFFFE),
    (Fn.MULHSU, 1, M1, 0),
])
def test_alu_vectors(fn, a, b, exp):
    assert run1(fn, a, b) == exp


def test_setp_all_conditions():
    # a = -1 (0xFFFFFFFF), b = 1: signed a<b, unsigned a>b
    cases = {Cond.EQ: 0, Cond.NE: 1, Cond.LT: 1, Cond.LE: 1, Cond.GT: 0, Cond.GE: 0,
             Cond.LTU: 0, Cond.LEU: 0, Cond.GTU: 1, Cond.GEU: 1}
    for cond, exp in cases.items():
        c = sim.Core(1)
        c.xw(1, 1, [M1]); c.xw(2, 1, [1])
        r = c.step(isa.enc_setp(cond, 1, 1, 2), 1)
        assert (r.dkind, r.data[0], c.pred[1][0]) == (DKind.PRED, exp, exp), cond
    c = sim.Core(1)
    c.xw(1, 1, [7]); c.xw(2, 1, [7])
    for cond, exp in {Cond.EQ: 1, Cond.NE: 0, Cond.LE: 1, Cond.GE: 1, Cond.LEU: 1, Cond.GEU: 1,
                      Cond.LT: 0, Cond.GT: 0, Cond.LTU: 0, Cond.GTU: 0}.items():
        assert c.step(isa.enc_setp(cond, 1, 1, 2), 1).data[0] == exp, cond


def test_immediates_and_movi_lui():
    c = sim.Core(1)
    assert c.step(asm("MOVI r1, 0x8000"), 1).data[0] == 0xFFFF8000          # sign-extended
    assert c.step(asm("MOVI r2, 0x7FFF"), 1).data[0] == 0x00007FFF
    assert c.step(asm("LUI r3, 0x8000"), 1).data[0] == 0x80000000
    assert c.step(asm("ADD r4, r3, #-1"), 1).data[0] == 0x7FFFFFFF          # imm5 sign-extends
    assert c.step(asm("SHL r5, r2, #31"), 1).data[0] == 0x80000000          # #31 -> sext -1 -> low5 = 31
    assert c.step(asm("SLTU r6, r0, #-1"), 1).data[0] == 1                  # 0 < 0xFFFFFFFF
    with pytest.raises(AssertionError):
        asm("ADD r1, r2, #16")                                              # non-shift imm5 is strict
    assert asm("SHR r1, r2, #31") == asm("SHR r1, r2, #-1")                 # same field value


def test_r0_p0_semantics():
    c = sim.Core(2)
    r = c.step(asm("MOVI r0, 5"), 3)
    assert (r.dkind, r.wmask) == (DKind.NONE, 0) and c.gpr[0] == [0, 0]
    r = c.step(asm("SETP.EQ p0, r0, r0"), 3)
    assert r.dkind == DKind.NONE and c.pred[0] == [1, 1]


def test_masking_and_guard():
    c = sim.Core(4)
    c.xw(1, 0xF, [10, 20, 30, 40])
    c.step(asm("SETP.GT p1, r1, #15"), 0xF)                   # lanes 1,2,3 true
    assert c.pred[1] == [0, 1, 1, 1]
    r = c.step(asm("@p1 MOVI r2, 7"), 0b1110 & 0b0111)        # issue mask 0111 & p1 -> lanes 1,2
    assert r.wmask == 0b0110 and c.gpr[2] == [0, 7, 7, 0]
    r = c.step(asm("!@p1 MOVI r3, 9"), 0xF)                   # only lane 0
    assert r.wmask == 0b0001 and c.gpr[3] == [9, 0, 0, 0]
    r = c.step(asm("!@pt MOVI r4, 1"), 0xF)                   # never executes
    assert r.wmask == 0 and r.dkind == DKind.GPR and c.gpr[4] == [0] * 4
    # predicate write also honours the mask
    c.step(asm("SETP.EQ p1, r0, r0"), 0b0001)
    assert c.pred[1] == [1, 1, 1, 1]  # lane 0 rewritten to 1 (was 0); others already 1
    c.step(asm("SETP.NE p1, r0, r0"), 0b1000)
    assert c.pred[1] == [1, 1, 1, 0]


def test_illegal_and_reserved():
    assert not decode(0).legal
    assert not decode(0x3F << 26).legal
    assert not decode(isa.enc_r(isa.Opc.ALU_R, 1, 1, 1, 0x0E)).legal          # funct > MULHSU
    assert not decode(isa.enc_r(isa.Opc.SETP, 1, 1, 1, 10)).legal             # cond > GEU
    assert not decode(isa.enc_r(isa.Opc.SETP, 8, 1, 1, 0)).legal              # pd > 7
    assert not decode(isa.NOP_WORD | 1).legal                                  # NOP reserved bits
    assert not decode((isa.Opc.MOVI << 26) | (1 << 20)).legal                  # G[4] reserved
    r = sim.Core(2).step(0, 3)
    assert (r.illegal, r.dkind, r.wmask) == (True, DKind.NONE, 0)


def test_disasm_roundtrip():
    for line in ["ADD r3, r1, r2", "@p2 SUB r4, r5, #-3", "!@p7 MULHSU r31, r30, r29",
                 "SETP.GEU p3, r4, #15", "@p1 MOVI r9, 0xffff", "LUI r1, 0x1234", "NOP"]:
        w = asm(line)
        assert asm(disasm(w)) == w, (line, disasm(w))


def _load_sfx():
    sys.dont_write_bytecode = True          # never leave a __pycache__ next to someone else's source
    here = os.path.dirname(os.path.abspath(__file__))
    cands = [os.environ.get("SFX_ASM", "")]
    d = here
    for _ in range(8):
        d = os.path.dirname(d)
        cands.append(os.path.join(d, "SilicaFlux-main", "SilicaFlux2.0", "SilicaFlux2.5", "sfx_asm.py"))
    for p in cands:
        if p and os.path.isfile(p):
            spec = importlib.util.spec_from_file_location("sfx_asm", p)
            m = importlib.util.module_from_spec(spec)
            sys.modules["sfx_asm"] = m
            spec.loader.exec_module(m)
            return m
    return None


def test_sfx_v1_alu_encoding_compat():
    sfx = _load_sfx()
    if sfx is None:
        pytest.skip("sfx_asm.py not found (set SFX_ASM=path to enable)")
    for fn in (Fn.ADD, Fn.SUB, Fn.MUL, Fn.AND, Fn.OR, Fn.XOR, Fn.SHL, Fn.SHR, Fn.SAR, Fn.SLT, Fn.SLTU):
        word = isa.enc_alu(fn, 3, 1, 2)
        # encode with the SFX v1 assembler and compare
        src = f"{fn.name} r3, r1, r2"
        img = _sfx_assemble_one(sfx, src)
        assert img == word, (src, hex(img), hex(word))
        assert decode(img).legal


def _sfx_assemble_one(sfx, text):
    # sfx_asm exposes a two-pass assembler; use its documented entry point
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        sf = os.path.join(td, "a.s"); base = os.path.join(td, "a"); hx = base + ".hex"
        open(sf, "w").write(".text\n" + text + "\n")
        import subprocess
        subprocess.run([sys.executable, "-I", sfx.__file__, sf, "-o", base, "-f", "hex"], check=True, capture_output=True)
        words = [l.strip() for l in open(hx) if l.strip() and not l.startswith("//")]
        return int(words[0], 16)
