"""The differential comparator must accept a correct log and flag every kind of corruption."""
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from sfg1 import compare, isa, sim  # noqa: E402
from sfg1.isa import Fn  # noqa: E402

LANES = 4


def make_log(tmp_path, mutate=None):
    """A 'perfect DUT': results come straight from the Python model, retired in issue order."""
    rng = random.Random(5)
    core = sim.Core(LANES)
    lines = [f"HDR {LANES} 16 2"]
    prog = [isa.enc_movi(1, 0x1234), isa.enc_movi(2, 0x00FF), isa.enc_alu(Fn.MUL, 3, 1, 2),
            isa.enc_alu(Fn.ADD, 4, 3, 1), isa.enc_setp(isa.Cond.GT, 1, 4, 2), isa.enc_alu(Fn.SUB, 5, 4, 1, pred=1)]
    core.xw(7, 0xF, [1, 2, 3, 4])
    lines.append("XWA 7 f " + " ".join(f"{v:08x}" for v in [1, 2, 3, 4]))
    recs = []
    for tag, w in enumerate(prog):
        mask = 0xF if tag != 5 else 0b0110
        lines.append(f"ACC {tag} {w:08x} {mask:x}")
        recs.append((tag, core.step(w, mask)))
    for tag, r in recs:
        lines.append(f"RET {tag} {int(r.dkind)} {r.idx} {r.wmask:x} {int(r.illegal)} " +
                     " ".join(f"{d:08x}" for d in r.data))
    lines.append("END 6 6 0 0")
    if mutate:
        lines = mutate(lines)
    p = tmp_path / "t.dut"
    p.write_text("\n".join(lines) + "\n")
    return str(p)


def test_good_log_passes(tmp_path):
    ok, stats, msgs = compare.compare(make_log(tmp_path))
    assert ok, msgs
    assert stats["accepted"] == 6 and stats["retired"] == 6


def _bad(tmp_path, mutate):
    ok, stats, msgs = compare.compare(make_log(tmp_path, mutate))
    assert not ok
    return msgs


def test_flipped_data_bit_detected(tmp_path):
    def m(ls):
        i = next(i for i, l in enumerate(ls) if l.startswith("RET 2 "))
        p = ls[i].split()
        p[6] = f"{int(p[6], 16) ^ 1:08x}"
        ls[i] = " ".join(p)
        return ls
    _bad(tmp_path, m)


def test_inactive_lane_data_ignored_but_mask_checked(tmp_path):
    def wrong_mask(ls):
        i = next(i for i, l in enumerate(ls) if l.startswith("RET 5 "))
        p = ls[i].split()
        p[4] = "f"                      # claims all lanes written
        ls[i] = " ".join(p)
        return ls
    _bad(tmp_path, wrong_mask)


def test_lost_instruction_detected(tmp_path):
    _bad(tmp_path, lambda ls: [l for l in ls if not l.startswith("RET 3 ")])


def test_duplicate_result_detected(tmp_path):
    def m(ls):
        i = next(i for i, l in enumerate(ls) if l.startswith("RET 3 "))
        ls.insert(i + 1, ls[i])
        return ls
    _bad(tmp_path, m)


def test_result_after_reset_detected(tmp_path):
    def m(ls):
        i = next(i for i, l in enumerate(ls) if l.startswith("RET 4 "))
        ls.insert(i, "RST")             # reset before tag 4+ retire -> they must not appear
        return ls
    _bad(tmp_path, m)


def test_wrong_destination_detected(tmp_path):
    def m(ls):
        i = next(i for i, l in enumerate(ls) if l.startswith("RET 3 "))
        p = ls[i].split()
        p[3] = "9"
        ls[i] = " ".join(p)
        return ls
    _bad(tmp_path, m)


def _two_writes_log(tmp_path, swap):
    """Two ADDs to r4 with individually correct data; `swap` retires them in the wrong order."""
    core = sim.Core(LANES)
    w0, w1 = isa.enc_movi(4, 7), isa.enc_alu_imm(Fn.ADD, 4, 4, 1)
    lines = [f"HDR {LANES} 16 2"]
    recs = []
    for tag, w in enumerate((w0, w1)):
        lines.append(f"ACC {tag} {w:08x} f")
        recs.append((tag, core.step(w, 0xF)))
    for tag, r in (reversed(recs) if swap else recs):
        lines.append(f"RET {tag} {int(r.dkind)} {r.idx} {r.wmask:x} {int(r.illegal)} " +
                     " ".join(f"{d:08x}" for d in r.data))
    lines.append("END 2 2 0 0")
    path = tmp_path / "o.dut"
    path.write_text("\n".join(lines) + "\n")
    return str(path)


def test_same_dest_order_only_flagged_when_swapped(tmp_path):
    ok, _, _ = compare.compare(_two_writes_log(tmp_path, swap=False))
    assert ok
    ok, _, msgs = compare.compare(_two_writes_log(tmp_path, swap=True))
    assert not ok and any("program order" in m for m in msgs), msgs


def test_truncated_log_is_an_error_not_a_crash(tmp_path):
    path = make_log(tmp_path)
    txt = open(path).read()
    cut = txt.rsplit("RET 5", 1)[0] + "RET 5 1 5 6 0 0000"      # simulation died mid-record
    open(path, "w").write(cut)
    ok, stats, msgs = compare.compare(path)
    assert not ok
    assert any("truncated" in m for m in msgs), msgs
