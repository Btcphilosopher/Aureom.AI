# Synthesis results (measured)

Produced by `scripts/synth.sh` with Yosys 0.71 (slang frontend) and nextpnr-ecp5 0.11 (YoWASP builds).
Counts are mapped-cell counts straight from Yosys `stat`; Fmax figures are nextpnr post-route numbers.
No Vivado/Quartus run was performed, so there is **no Xilinx or Intel timing** here.

## Xilinx 7-series mapping (`synth_xilinx -family xc7`, utilisation only)

| LANES | RF style | LUT (all) | of which LUT6 | FF | RAM32M (LUTRAM) | RAMB18/36 | DSP48E1 | CARRY4 |
|---|---|---|---|---|---|---|---|---|
| 1 | distributed (LUTRAM) | 1247 | 321 | 536 | 12 | 0/0 | 4 | 36 |
| 2 | distributed (LUTRAM) | 1796 | 334 | 811 | 24 | 0/0 | 8 | 70 |
| 4 | distributed (LUTRAM) | 3113 | 511 | 1361 | 48 | 0/0 | 16 | 138 |
| 8 | distributed (LUTRAM) | 5994 | 845 | 2461 | 96 | 0/0 | 32 | 274 |
| 16 | distributed (LUTRAM) | 11102 | 1545 | 4661 | 192 | 0/0 | 64 | 546 |
| 4 | block RAM | 3109 | 543 | 1105 | 0 | 8/0 | 16 | 138 |

## Per-block breakdown, Xilinx 7-series (each block synthesised standalone as its own top)

The slang frontend flattens the hierarchy, so blocks are measured separately; standalone numbers can differ slightly
from the same block inside the full core (cross-boundary optimisation). `regfile` is for LANES=4 and already contains the
per-lane RAMs, bypass registers and predicate file; `lane` is ONE lane (operand mux, X regs, ALU, multiplier, product reg, W reg);
`fifo` is the 44-bit-wide, depth-2 input buffer (32 insn + 4 mask + 8 tag).

| block | LUT | FF | RAM32M | DSP48E1 | CARRY4 |
|---|---|---|---|---|---|
| decode | 99 | 0 | 0 | 0 | 0 |
| fifo_44b_d2 | 50 | 90 | 0 | 0 | 0 |
| lane | 618 | 160 | 0 | 4 | 34 |
| regfile_L4 | 467 | 445 | 48 | 0 | 2 |
| scoreboard | 196 | 40 | 0 | 0 | 0 |

LANES=4 core total: 3113 LUT / 1361 FF. 4 x lane + regfile + scoreboard + decode + fifo = 3284 LUT / 1215 FF;
the remainder (-171 LUT / 146 FF; negative = cross-boundary optimisation) is the core's pipeline control, O/X/M/W control registers and result-channel logic.

## Lattice ECP5 (LFE5U-85F-6, CABGA381): Yosys mapping and nextpnr place & route

| LANES | LUT4 | FF | TRELLIS_DPR16X4 | DP16KD | MULT18X18D | CCU2C | post-route Fmax (MHz, clk) | target | I/O pins used |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1985 | 535 | 32 | 0 | 4 | 92 | 75.9 | 100 MHz req. | 138/365 |
| 2 | 2412 | 809 | 64 | 0 | 8 | 178 | 68.7 | 100 MHz req. | 205/365 |
| 4 | 4303 | 1359 | 128 | 0 | 16 | 350 | 70.7 | 100 MHz req. | 339/365 |
| 8 | 7644 | 2459 | 256 | 0 | 32 | 691 | not run (I/O pins exceed device) | - | - |
| 16 | 14430 | 4659 | 512 | 0 | 64 | 1379 | not run (I/O pins exceed device) | - | - |

### Post-route critical path (nextpnr, clk domain) -- what limits the ECP5 Fmax

- LANES=1: from `g_lane[0].u_lane.mb_TRELLIS_FF_Q_31.Q` to `g_lane[0].u_lane.m_prod_TRELLIS_FF_Q_19.DI` (13.18 ns total, 51 cells)
- LANES=2: from `u_ib.mem[0]_TRELLIS_FF_Q_7.Q` to `u_ib.mem[0]_TRELLIS_FF_Q_8.CE` (14.56 ns total, 17 cells)
- LANES=4: from `g_lane[2].u_lane.mb_TRELLIS_FF_Q_31.Q` to `g_lane[2].u_lane.m_prod_TRELLIS_FF_Q.DI` (14.14 ns total, 50 cells)

