#!/usr/bin/env python3
"""Build and run tb_adapter (engine -> adapter -> real TensorScratch)."""
import os, subprocess, sys, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import sim

TS = "third_party/tensorscratch"
TS_FILES = [l.strip() for l in open(os.path.join(ROOT, TS, "sim", "files_rtl.f")) if l.strip() and not l.startswith("+")]

def main():
    rtl = [l.strip() for l in open(os.path.join(ROOT, "rtl", "files.f")) if l.strip()]
    files = [os.path.normpath(os.path.join(ROOT, "rtl", p)) for p in rtl]
    files += [os.path.join(ROOT, "rtl", "sf_sparse_tensor_adapter.sv"),
              os.path.join(ROOT, "third_party", "memory_guard", "sf_memory_guard_regions.sv")]
    files += [os.path.join(ROOT, TS, f) for f in TS_FILES]
    files += [os.path.join(ROOT, "tb", "tb_adapter.sv")]
    mdir = os.path.join(ROOT, "build", "adapter")
    shutil.rmtree(mdir, ignore_errors=True); os.makedirs(mdir)
    cmd = [sim.verilator(), "--binary", "--timing", "--assert", "-j", "4", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
           "-CFLAGS", "--std=c++20 -fcoroutines", "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include", "--x-assign", "unique", "--x-initial", "unique",
           "--top-module", "tb_adapter", "-Mdir", mdir, "-o", "simv",
           f"-I{ROOT}/{TS}/rtl", f"-I{ROOT}/{TS}/third_party/memorycore/rtl", f"-I{ROOT}/{TS}/third_party/memorycore/ras_secded"] + files
    r = subprocess.run(cmd, cwd=os.path.join(ROOT, TS), capture_output=True, text=True)
    if r.returncode != 0:
        out = r.stdout + r.stderr
        errs = [l for l in out.splitlines() if "%Error" in l or "error:" in l.lower()]
        sys.stderr.write("\n".join(l[:400] for l in errs[:30]) + "\n")
        sys.exit("build failed (first errors above)")
    p = subprocess.run([os.path.join(mdir, "simv")], capture_output=True, text=True)
    sys.stdout.write(p.stdout)
    sys.exit(0 if "ADAPTER_ALL_PASS" in p.stdout else 1)

if __name__ == "__main__":
    main()
