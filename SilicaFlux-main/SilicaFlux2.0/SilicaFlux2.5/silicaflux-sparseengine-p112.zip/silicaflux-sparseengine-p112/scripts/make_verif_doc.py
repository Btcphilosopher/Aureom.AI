#!/usr/bin/env python3
"""Render docs/05_verification.md from reports/final_regression.json, reports/mutation.json, reports/adapter.txt, reports/nc_regression.json."""
import json, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = lambda n: os.path.join(ROOT, "reports", n)
reg = json.load(open(R("final_regression.json")))
mut = json.load(open(R("mutation.json")))
adapter = open(R("adapter.txt")).read() if os.path.exists(R("adapter.txt")) else ""
nc = json.load(open(R("nc_regression.json"))) if os.path.exists(R("nc_regression.json")) else []
cfgs = sorted({r["cfg"] for r in reg}, key=lambda c: [r["cfg"] for r in reg].index(c))
suites = []
for r in reg:
    if r["suite"] not in suites:
        suites.append(r["suite"])
P = sum(r.get("passed", 0) for r in reg); F = sum(max(r.get("failed", 0), 0) for r in reg)
E = sum(r.get("elems", 0) for r in reg); B = sum(r.get("bytes", 0) for r in reg); RQ = sum(r.get("reqs", 0) for r in reg)
RO = sum(r.get("reordered", 0) for r in reg)
killed = [m for m in mut if m["status"] == "KILLED"]; surv = [m for m in mut if m["status"] == "SURVIVED"]; inv = [m for m in mut if m["status"] == "INVALID"]
m_adapter = re.search(r"ADAPTER checks=(\d+) errors=(\d+) ts_writes=(\d+)", adapter)

L = ["# 05 — Verification", "",
     "Simulation (Verilator 5.49) against an independent Python reference model, a mutation campaign, and generic Yosys elaboration. "
     "No formal proof, no coverage-closure metric, no second simulator (docs/08 §5).", "",
     "## 1. Method", "",
     "* **`model/sp_model.py`** is a pure-Python implementation of `docs/02` (decode, the MemoryGuard verdict, per-element faults, gather, scatter with the "
     "duplicate rule, CSR traversal, SpMV with tensor_pe's per-step clamp). It shares **no code** with the RTL or the bench and was written from the specification.",
     "* **`model/gen_scenarios.py`** builds scenarios (memory image, region table, command, error injection, timing knobs), runs the model and writes the expected "
     "completion record, the expected output-buffer bytes and the expected memory image.",
     "* **`tb/tb_sparse.sv`** executes a scenario file and compares: the completion record (fault, guard fault, ALP status, element, address, count, overflow, "
     "tid); **every output-buffer byte** (bytes the command must write = expected data; every other byte = its pre-command value); and **the entire memory image** "
     "(a gather must not modify memory; a scatter must modify exactly the expected bytes). It also checks that the engine is idle after completion and that no "
     "request is left outstanding.",
     "* **Target model** (in the bench): configurable latency / jitter / banks / service time, `req_ready` and response back-pressure, **in-order or out-of-order "
     "completion** (oldest-first, earliest-ready-first, or random), per-beat error injection, and *writes that take effect at completion time*, so an engine ordering "
     "bug changes the result. Link rules are checked on every run: tag not reused while outstanding, outstanding ≤ limit, request held until accepted, illegal "
     "requests, **no two writes to one beat in flight** — plus the vendored **ALP link checker** (ALP-REQ-02, OUT-01, TAG-01, ORD-01, RSP-xx, RST-xx) in every in-order run.",
     "* **Link byte monitor** (added after the first mutation campaign, see §5): on every request the engine puts on the link, **every byte whose byte enable is set must lie inside a region "
     "of the command's domain that allows the operation** (read for reads, write for writes). It is independent of the engine's checker and works at byte level, so it checks the "
     "claim *requested bytes = validated bytes* directly; scenarios whose arrays start mid-beat inside regions that end exactly where the arrays end make it sensitive to a reader "
     "that touches a neighbouring byte. It also asserts the walker's interface invariant (an empty-row event is both first and last).",
     "* **Rogue response** (`ROGUE` scenario token, out-of-order bench only): after the first data request the target injects one response that answers no request.",
     "* **MemoryGuard:** the real `sf_memory_guard_regions` programs the table through its command port. **CacheForge:** the real cache (clean+invalidate-all after "
     "every command, as its DMA rules require). **TensorScratch:** the real scratchpad (`tb/tb_adapter.sv`).", "",
     "## 2. Results (final RTL)", "",
     f"**{P:,} scenarios passed, {F} failed** across {len(cfgs)} configurations; {E:,} elements / {B:,} useful bytes compared byte-exact; "
     f"{RQ:,} link requests; {RO:,} responses that overtook an older request (out-of-order targets).", "",
     "| configuration | " + " | ".join(suites) + " |", "|---|" + "---|" * len(suites)]
for c in cfgs:
    row = []
    for s in suites:
        rr = [r for r in reg if r["cfg"] == c and r["suite"] == s]
        if not rr:
            row.append("-")
        else:
            row.append(f"{sum(r.get('passed', 0) for r in rr)}" + ("" if all(r["ok"] for r in rr) else " **FAIL**"))
    L.append(f"| {c} | " + " | ".join(row) + " |")
bc = {su: sum(r.get("passed", 0) for r in reg if r["cfg"] == "base" and r["suite"] == su) for su in suites}
L += ["", "`addr48` has 3 fewer scenarios than the other rows: the generator omits `f1_dec_base_over_space`, `f1_dec_idxbase_over_space` and `f3c_addr_over_space`, whose out-of-space address "
      "(`2^ADDR_W + 0x1000`) cannot be encoded in the 48-bit command address field at that width.", "",
      f"Suites (scenario counts in `base`): `stage1` (gather, {bc.get('stage1','-')}), `faults` (gather faults, fault-arbitration sweep, tight index regions, {bc.get('faults','-')}), "
      f"`chains` (recovery after faults, back-to-back, mid-command reset, {bc.get('chains','-')}), `stage2` (reordering / back-pressure / rogue responses, in-order + out-of-order, {bc.get('stage2','-')}), "
      f"`scatter` ({bc.get('scatter','-')}), `chain3` (scatter→gather read-back, fault recovery, {bc.get('chain3','-')}), `csr` (traversal, SpMV, validation, boundaries, tight regions, {bc.get('csr','-')}), "
      f"`csrovf` (saturation / wrap, only in the narrow-accumulator configurations plus the real 32-bit long rows in `base`, {bc.get('csrovf','-')}), `nc` (cacheable = 0, {bc.get('nc','-')}). "
      "Counts per cell are scenarios; the per-group (in-order / out-of-order target) split is in `reports/final_regression.md`.",
      "Configurations: `base`; request-table `nrt2 nrt4 nrt32`; reorder `rob16 rob64`; index reader `idx_small idx_big`; `tiny` (everything minimal); "
      "address width `addr24 addr32 addr48`; arithmetic `acc20 wrap20 acc16`; through CacheForge `cache` (1 MSHR) `cache_mshr4` `cache_mshr2`.", ""]
if nc:
    L += [f"`nc` through the three cache configurations (run separately after the main regression, same binaries): "
          f"{sum(r.get('passed',0) for r in nc)} scenarios passed, {sum(max(r.get('failed',0),0) for r in nc)} failed.", ""]
if m_adapter:
    L += ["**Tensor adapter** (`tb/tb_adapter.sv`, real TensorScratch): " + f"{int(m_adapter.group(1)):,} operand comparisons on the k-slice stream, "
          f"{m_adapter.group(2)} errors, {int(m_adapter.group(3)):,} words written to the scratchpad. Includes ping-pong fill while a tile is consumed, a fill "
          "with no free set (adapter waits, nothing written), invalid parameters (no side effect), the ownership guard, scratchpad RANGE / ALIGN / OWNER errors "
          "(a write aimed at a READY tile is refused and the tile is delivered intact) and 40 random tiles.", ""]
L += ["Frozen evidence of the build stages: `reports/stage1_2_frozen/` (gather + reordering only, 12 configurations: 3,178 scenarios) and "
      "`reports/stage3_frozen/` (+ scatter, CSR, SpMV, 15 configurations: 8,417 scenarios).", "",
      "## 3. What is exercised by the scenario families", "",
      "See the traceability table in `docs/01_overview.md` §2. In addition: back-pressure on every handshake (`req_ready`, response valid gaps, index-push gaps, "
      "`maxout = 1`), reset in the middle of a command (3 / 12 / 30 / 60 cycles, also with stream indices) followed by a clean command, and a table of 2 entries "
      "(`nrt2`) against 256-byte elements.", "",
      "## 4. Sensitivity checks done by hand before the campaign", "",
      "* Breaking the lane-rotation direction made 46 of the 81 stage-1 scenarios fail.",
      "* Removing the write-ordering dependency made 10 of the 17 out-of-order scatter scenarios fail while **all 127 in-order scatter scenarios still passed** — an in-order "
      "target hides that bug, which is why the out-of-order target model exists; the write-after-write monitor was added so that the in-order run also catches it "
      "(it now fires on dozens of scenarios).", "",
      "## 5. Mutation campaign (`scripts/run_mutation.py`)", "",
      f"{len(mut)} single-defect mutants across the coalescer, reorder buffer, address generator, beat splitter, engine, CSR walker, SpMV wrapper, index buffer and stream reader. "
      f"Each runs the base-configuration suites against an in-order and an out-of-order target and counts as killed if a scenario fails, the run hits the per-scenario watchdog "
      f"or a protocol assertion fires; mutants of the arithmetic path also run the narrow-accumulator build. A mutant that **does not build is INVALID, not killed**, and a process "
      f"time-out is INCONCLUSIVE (the first version of the harness counted a build failure as a kill: `eng_wr_perm` and `eng_align` were recorded as killed by \"build failed\" in the first run, "
      f"which also ran while the build disk was full, so that result says nothing about the tests; the rule was removed and both are killed by real scenario failures in the final run). **{len(killed)} killed, {len(surv)} survived, {len(inv)} invalid, {len([m for m in mut if m['status']=='INCONCLUSIVE'])} inconclusive.**", "",
      "**How the campaign changed the tests.** The first full run (42 mutants, before the changes below) left 7 survivors; 5 were genuine gaps. Each was closed with a test, not an excuse:",
      "",
      "| survivor | why the tests missed it | what was added |", "|---|---|---|",
      "| `wk_nnz` (row-pointer bound off by one) | the bad pointers were `nnz + 6` or larger, never exactly `nnz + 1` | `f3c_rp_mid_eq_nnz_*` (legal), `f3c_rp_mid_nnz_plus1_*` (fault) |",
      "| `eng_min_fault` (arbiter picks the highest element) | two faults never reached the arbiter in the same cycle | `f1_race_*` / `f3_race_*`: memory error on element 5 against a front-end fault on element 5+d, swept over latency and d |",
      "| `sr_be` (index reads touch bytes before the array) | regions were wide, so the extra bytes were still permitted | the link byte monitor + `f1_tight_idx_*`, `f3_tight_idx_*`, `f3c_tight_*` (arrays start mid-beat in regions that end exactly at the array) |",
      "| `co_rs_range` (response-tag range off by one) | no test ever sent a response with a bad tag (the `SP_F_PROTO` path was untested) | `s2_rogue_*` (rogue response injected by the out-of-order target) |",
      "| `spmv_ovf` (overflow flag never reported) | the campaign ran only the 32-bit accumulator, which cannot overflow on test data | harness phase: the `csrovf` suite on a `SPMV_ACC_W = 20` build |",
      "",
      "Two survivors were *equivalent mutants* and are explained below rather than tested: `co_err_data` (ALP-RSP-05 makes error data all-zero, so a conforming target cannot expose the difference) "
      "and `spmv_emit` (the walker's empty-row event is always first = last, so the two expressions are the same signal).", ""]
if surv:
    L += ["### Survivors", ""]
    for m in surv:
        L.append(f"* **{m['id']}** — {m.get('note','')}. " + (f"Argued to be equivalent (not proven): {m['equivalent'].removeprefix('equivalent: ')}." if m.get("equivalent") else "**Not explained: a gap in the tests.**"))
    L += [""]
L += ["Full table: `reports/mutation.md`.", "",
      "## 6. Defects the verification found along the way (kept, not hidden)", "",
      "**In the RTL**", "",
      "1. **`NRT = 32` hung every command.** `5'(NRT)` truncates 32 to 0, so every response was classed out of range. Nothing in the default configuration shows it; the "
      "configuration sweep did. (Fixed: 6-bit compare.)",
      "2. **An error on an *index-array* beat discarded the elements before it.** The output writer was told to stop for *any* memory error, but an index error is a front-end fault "
      "and must not stop earlier elements. (`f1_memerr_index_beat`; fixed: only a delivery-side error stops the writer.)",
      "3. **A CSR-walker fault flushed the elements ahead of it** — rows that should have completed were lost (16 `f3c_*` scenarios). Two causes: the index buffer / address "
      "generator were flushed (everything downstream of the walker is *earlier*, not later), and the element stage dropped everything once any fault existed. Fixed: the index buffer "
      "closes after draining on a walker fault; elements are dropped by *position* (at or after the fault).",
      "4. **The tensor adapter sampled the scratchpad's `fill_set` in the handshake cycle**, one cycle too early (the scratchpad updates it the cycle after `fill_begin`). "
      "Found by the ping-pong test; the first test happened to pass because both sets were 0.",
      "5. *Found in review before any test ran:* a write allocated in the same cycle that its dependency's response arrived would have kept a dependency nobody clears (deadlock). Fixed, and "
      "the `co_no_dep` mutant covers the mechanism.",
      "6. Verilator `MULTIDRIVEN` on three adapter registers (reset and non-reset blocks both driving them) — fixed.",
      "7. A 24-bit address configuration failed to elaborate inside the *unmodified* MemoryGuard checker (`AW ≥ LW`): the engine now clamps the checker's length width to `ADDR_W`.",
      "8. Yosys rejected constructs Verilator accepts (indexing an unpacked array of structs, `import` inside a module, `$bits(struct)`, `$signed()` on a port connection); rewritten "
      "with no behaviour change, and the full regression re-run afterwards.",
      "9. **A spurious response made a command unable to complete.** The outstanding-request counter was decremented by *every* response, so a response the engine had just rejected "
      "(`SP_F_PROTO`) pushed it below the true count and the real response then underflowed it; the command waited for `out == 0` forever. Found while designing the test for the "
      "untested `SP_F_PROTO` path, before any simulation of it; fixed (a rejected response is not counted), and the mutant `eng_out_cnt` that restores the old behaviour is killed by `s2_rogue_*`.", "",
      "**In the verification environment (not the RTL)**", "",
      "* Declarations with initialisers inside a static `always` / `initial` block run **once at time 0** — three bench bugs of this kind (target-model response beat, two in the adapter bench). "
      "They made correct RTL look wrong; found by tracing, not by guessing.",
      "* Reset asserted in the same time step as a clock edge raced the link checker; the target's `rsp_valid` was not gated by reset; the poison flag must equal `(status == ECC_UNCORR)` (ALP-RSP-05) — all in the target model.",
      "* The input buffer was not cleared between scenarios, so stale scatter data leaked into a later scenario.",
      "* **Stale results:** the scenario path was a compile-time parameter, and a cached binary was reused after the RTL changed — a regression silently re-ran an older file. Fixed (runtime `+scen=`, "
      "binaries older than any source are rebuilt). Several parallel builds into one directory raced; builds are now one per configuration.",
      "* **A model gap, not a bug:** behind CacheForge a failing beat fails its whole 64-byte line, and the first failing request is the first beat of the line. The model now takes the target's error granularity as a parameter.",
      "* **A specification choice made explicit:** `fault_addr` is reported only for permission faults and scatter write errors (the reorder structure does not carry addresses), so the model and RTL agree on `0` elsewhere.", ""]
open(os.path.join(ROOT, "docs", "05_verification.md"), "w").write("\n".join(L) + "\n")
print("docs/05_verification.md written")
