#!/usr/bin/env python3
"""
Write third_party/PROVENANCE.md and third_party/SHA256SUMS.

Every file under third_party/ is a byte-identical copy of a member of an archive in the SilicaFlux repository.  When
--audit-dir (a directory holding those archives extracted as <archive-stem>/...) is given, each file is compared with
its original and the result is recorded; without it only the checksums are written.
"""
import argparse, hashlib, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TP = os.path.join(ROOT, "third_party")
# vendored prefix -> (archive, member prefix inside the extracted archive, purpose)
MAP = [
 ("albioncore/",            "silicaflux-cacheforge-p106.zip",  "silicaflux-cacheforge/third_party/albioncore/",          "AlbionCore 0.1.0: ALP v1 package; link / channel checkers (tests only)"),
 ("memory_guard/",          "silicaflux-memoryguard-p104.zip", "silicaflux-memoryguard-p104/rtl/memory_guard/",             "MemoryGuard P104: package, checker (ingress), region table (testbench)"),
 ("tensorcore01/",          "silicaflux-tensorcore01-tensor_pe.zip", "silicaflux-tensorcore01/rtl/",                       "TensorCore 01 tensor_pe: the SpMV arithmetic lane"),
 ("cacheforge/rtl/",        "silicaflux-cacheforge-p106.zip",  "silicaflux-cacheforge/rtl/",                              "CacheForge P106 RTL (testbench / benchmarks)"),
 ("cacheforge/third_party/", "silicaflux-cacheforge-p106.zip", "silicaflux-cacheforge/third_party/",                      "SRAMMacroBridge P79 (CacheForge's RAM wrapper)"),
 ("tensorscratch/",         "silicaflux-tensorscratch-p75.zip", "silicaflux-tensorscratch-p75/",                          "TensorScratch P75 (adapter testbench)"),
]
def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--audit-dir"); a = ap.parse_args()
    rows, sums = [], []
    for dp, _, fs in sorted(os.walk(TP)):
        for f in sorted(fs):
            if f in ("PROVENANCE.md", "SHA256SUMS"):
                continue
            full = os.path.join(dp, f); rel = os.path.relpath(full, TP)
            h = sha(full); sums.append(f"{h}  {rel}")
            arch = member = purpose = None
            for pref, ar, mem, pur in MAP:
                if rel.startswith(pref):
                    arch, member, purpose = ar, mem + rel[len(pref):], pur
                    break
            status = "not compared"
            if a.audit_dir and arch:
                orig = os.path.join(a.audit_dir, arch[:-4], member)
                if os.path.exists(orig):
                    status = "identical" if sha(orig) == h else "DIFFERS"
                else:
                    status = "original not found"
            rows.append((rel, arch or "?", member or "?", h[:16], status, purpose or ""))
    open(os.path.join(TP, "SHA256SUMS"), "w").write("\n".join(sums) + "\n")
    L = ["# Provenance of vendored third-party files", "",
         "All files below are **byte-identical copies, unmodified**, of members of archives in the SilicaFlux repository "
         "(`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`). `SHA256SUMS` lists the full digests; `scripts/check_third_party.py` re-checks them.", ""]
    by_arch = {}
    for r in rows:
        by_arch.setdefault((r[1], r[5]), []).append(r)
    bad = [r for r in rows if r[4] not in ("identical", "not compared")]
    L += [f"{len(rows)} files; comparison with the archive originals: "
          + (f"**{sum(r[4]=='identical' for r in rows)} identical, {len(bad)} not identical / not found**" if a.audit_dir else "not run"), "",
          "| component | archive | files | compared |", "|---|---|---|---|"]
    for (ar, pur), rs in sorted(by_arch.items()):
        cmpd = sum(r[4] == "identical" for r in rs)
        L.append(f"| {pur} | `{ar}` | {len(rs)} | {cmpd} identical |")
    L += ["", "## Files", "", "| vendored file | source member | sha256 (first 16) | vs archive |", "|---|---|---|---|"]
    for r in rows:
        L.append(f"| `{r[0]}` | `{r[1]}:{r[2]}` | `{r[3]}` | {r[4]} |")
    open(os.path.join(TP, "PROVENANCE.md"), "w").write("\n".join(L) + "\n")
    print(f"{len(rows)} files; not identical: {len(bad)}")
    sys.exit(1 if bad else 0)
if __name__ == "__main__":
    main()
