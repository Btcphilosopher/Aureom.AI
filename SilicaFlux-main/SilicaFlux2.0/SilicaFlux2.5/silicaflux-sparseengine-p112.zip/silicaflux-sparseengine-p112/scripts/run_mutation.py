#!/usr/bin/env python3
"""
Mutation campaign: plant one plausible defect at a time in the RTL and check that the regression notices.

Every mutant is a textual patch (file, old, new) applied to a private copy of the tree; `old` must occur exactly once.
A mutant is KILLED when the bench reports a failing scenario, hangs on its per-scenario watchdog, or aborts on a protocol
assertion.  A mutant that does not BUILD is INVALID (a broken patch proves nothing about the tests) and a run that exceeds the
process time-out is INCONCLUSIVE; neither is counted as a kill.  A SURVIVOR is reported with the reason it is believed to
survive; nothing is hidden.  Mutants listed in ARITH also run the narrow-accumulator build (SPMV_ACC_W=20, suite csrovf).

Scenario files must exist already (the base-configuration suites of run_regression.py).
usage: run_mutation.py [--jobs 3] [--only id,id]
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ProcessPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COAL = "rtl/sf_sparse_request_coalescer.sv"; ROB = "rtl/sf_sparse_reorder.sv"; AG = "rtl/sf_sparse_address_gen.sv"
ENG = "rtl/sf_sparse_memory_engine.sv"; WK = "rtl/sf_sparse_csr_walker.sv"; SPMV = "rtl/sf_sparse_spmv.sv"
IB = "rtl/sf_sparse_index_buffer.sv"; SR = "rtl/sf_sparse_stream_rd.sv"

# id, file, old, new, note (expected-survivor explanation or "")
MUTANTS = [
 ("co_cov_be",     COAL, "((in_be_i & ~be_q[i]) == 16'd0);", "1'b1;", "duplicate hit ignores byte-enable coverage"),
 ("co_no_release", COAL, "- NREFW'((rel_valid_i && (rel_rt_i == RTW'(i))) ? 1 : 0);", "- NREFW'(0);", "table entries are never freed"),
 ("co_wr_merge_old", COAL, "data_d[m_idx] = (data_q[m_idx] & ~expand_be) | (in_wdata_i & expand_be);", "data_d[m_idx] = (data_q[m_idx] & expand_be) | (in_wdata_i & ~expand_be);", "scatter merge keeps the OLD bytes (first writer wins)"),
 ("co_no_dep",     COAL, "depv_d[a_idx]  = dep_found && !(rs_ok && (rs_i == dep_idx));", "depv_d[a_idx]  = 1'b0;", "no write-ordering dependency"),
 ("co_dep_flight_only", COAL, "fw[i] = in_wr_i && same[i] && ((st_q[i] == S_PEND) || (st_q[i] == S_FLIGHT));", "fw[i] = in_wr_i && same[i] && (st_q[i] == S_FLIGHT);", "dependency ignores older pending writes (matters with merging off)"),
 ("co_rs_range",   COAL, "({1'b0, rs_idx_i} < 6'(NRT));", "({1'b0, rs_idx_i} <= 6'(NRT));", "response index range off by one (only reachable with a bad tag)"),
 ("co_tag",        COAL, "{sf_sparse_pkg::SP_TAGSRC_DATA, 5'(sel_idx)};", "{sf_sparse_pkg::SP_TAGSRC_DATA, 5'(sel_idx) ^ 5'd1};", "request tag does not name the table entry"),
 ("co_pend_stale", COAL, "pend_ok[i] = same[i] && (st_q[i] == S_PEND) && !sel_now[i];", "pend_ok[i] = same[i] && (st_q[i] == S_PEND);", "merge into the entry that is being issued this cycle (lost update)"),
 ("co_err_data",   COAL, "data_d[rs_i] = (rs_stat_i == 4'd0) ? rs_data_i : 128'd0;", "data_d[rs_i] = rs_data_i;", "error data not zeroed", "equivalent: ALP-RSP-05 (asserted by the link checker in every in-order run) makes the data of every non-OKAY response all-zero, so a conforming target never presents the non-zero data the mutant would pass through; the data of an errored beat is never written anyway"),
 ("rob_lane",      ROB,  "dv_lane_q <= slot_lane_q[head_q];", "dv_lane_q <= '0;", "delivered lane forgotten"),
 ("rob_full",      ROB,  "assign rob_ready_o = (cnt_q != (PW+1)'(ROB_DEPTH));", "assign rob_ready_o = 1'b1;", "reorder buffer overflows"),
 ("rob_no_done",   ROB,  "wire head_ok  = (cnt_q != '0) && rd_done_i;", "wire head_ok  = (cnt_q != '0);", "delivers before the response arrived"),
 ("rob_rel_rt",    ROB,  "assign rel_rt_o    = slot_rt_q[head_q];", "assign rel_rt_o    = slot_rt_q[tail_q];", "releases the wrong table entry"),
 ("ag_no_ovf",     AG,   "ovf2  = |(sum2 >> ADDR_W);", "ovf2  = 1'b0;", "address overflow not detected"),
 ("ag_limit",      AG,   "(val1_q >= idx_limit_i)", "(val1_q > idx_limit_i)", "index limit off by one"),
 ("ag_neg",        AG,   "else if (neg1_q)                                        flt1 = sf_sparse_pkg::SP_F_NEG_INDEX;", "else if (1'b0)                                        flt1 = sf_sparse_pkg::SP_F_NEG_INDEX;", "negative index not detected"),
 ("sp_be",         AG,   "({1'b0, 4'(i)} < ({1'b0, addr_q[3:0]} + 5'(elem_bytes_i[4:0])));", "({1'b0, 4'(i)} <= ({1'b0, addr_q[3:0]} + 5'(elem_bytes_i[4:0])));", "byte-enable mask one byte too wide"),
 ("sp_nb",         AG,   "elem_bytes_i[EB_W-1:4] - 1'b1);", "elem_bytes_i[EB_W-1:4]);", "large elements split into one beat too many"),
 ("eng_rot",       ENG,  "rsh  = dl - sl;", "rsh  = sl - dl;", "output lane rotation direction"),
 ("eng_wmask",     ENG,  "(5'(b) < ({1'b0, dl} + w_nbytes));", "(5'(b) <= ({1'b0, dl} + w_nbytes));", "output byte mask one byte too wide"),
 ("eng_min_fault", ENG,  "(cd_elem[k] < nf_elem))", "(cd_elem[k] > nf_elem))", "fault arbitration picks the HIGHEST element"),
 ("eng_take_min",  ENG,  "(!flt_v_q || (nf_elem < flt_elem_q))", "(!flt_v_q)", "a later fault never replaces an earlier one"),
 ("eng_drop",      ENG,  "wire ea_drop       = ea_valid && flt_v_q && (ea_idx >= flt_elem_q);", "wire ea_drop       = ea_valid && flt_v_q;", "elements ahead of a front-end fault are discarded"),
 ("eng_wr_perm",   ENG,  "chk_op   = sf_sparse_pkg::SP_OP_SCATTER == c_q.op ? sf_memory_guard_pkg::OP_WRITE : sf_memory_guard_pkg::OP_READ;" if False else "chk_op   = is_scatter ? sf_memory_guard_pkg::OP_WRITE : sf_memory_guard_pkg::OP_READ;", "chk_op   = sf_memory_guard_pkg::OP_READ;", "scatter checked for READ permission"),
 ("eng_align",     ENG,  "else if ((c_q.base[11:0] & e_amask) != 12'd0)                                dec_fault = sf_sparse_pkg::SP_F_ALIGN;\n      else if (!c_q.idx_stream", "else if (1'b0)                                dec_fault = sf_sparse_pkg::SP_F_ALIGN;\n      else if (!c_q.idx_stream", "table base alignment not checked"),
 ("eng_buf",       ENG,  "{44'd0, buf_off} + span > (is_scatter", "{44'd0, buf_off} + span >= (is_scatter", "buffer range off by one"),
 ("eng_idxlim",    ENG,  ".idx_limit_i(is_csr ? c_q.ncols : c_q.idx_limit),", ".idx_limit_i(32'd0),", "index limit never applied"),
 ("eng_yrow",      ENG,  "{sp_y_row[sf_sparse_pkg::SP_OFF_W-3:0], 2'b00};", "{sp_y_row[sf_sparse_pkg::SP_OFF_W-4:0], 3'b000};", "SpMV result stored at the wrong stride"),
 ("eng_sx_sat",    ENG,  "wire evf_ok   = evf_empty || (flt_v_q && evf_head_nz);", "wire evf_ok   = evf_empty;", "completion waits for orphan events (hang after a fault)"),
 ("eng_close",     ENG,  ".close_i(wk_flt_valid),", ".close_i(1'b0),", "index buffer never closes after a walker fault (hang)"),
 ("wk_mono",       WK,   "else if ((p1_in < p0_q) || (p1_in > nnz_q)", "else if ((p1_in <= p0_q) || (p1_in > nnz_q)", "empty rows rejected as non-monotonic"),
 ("wk_nnz",        WK,   "(p1_in > nnz_q)", "(p1_in > nnz_q + 32'd1)", "row pointer bound off by one"),
 ("wk_total",      WK,   "|| ((row_q == nrows_q - 32'd1) && (p1_in != nnz_q)))", ")", "final row pointer != nnz accepted"),
 ("wk_first",      WK,   "else if (p1_in != 32'd0)      begin f_new = 1'b1; f_code = sf_sparse_pkg::SP_F_CSR_ROWPTR;", "else if (1'b0)      begin f_new = 1'b1; f_code = sf_sparse_pkg::SP_F_CSR_ROWPTR;", "row_ptr[0] != 0 accepted"),
 ("wk_col",        WK,   "end else if (col_in >= ncols_q) begin", "end else if (col_in > ncols_q) begin", "column bound off by one"),
 ("spmv_clear",    SPMV, ".clear_acc_i(fire && (ev_first_i || !ev_nz_i)),", ".clear_acc_i(fire && !ev_nz_i),", "rows accumulate into each other"),
 ("spmv_emit",     SPMV, "tok_e_q <= {tok_e_q[L-2:0], fire && (ev_last_i || !ev_nz_i)};", "tok_e_q <= {tok_e_q[L-2:0], fire && ev_last_i};", "empty rows produce no result", "equivalent: the walker's empty-row event always has first = last = 1 (sf_sparse_csr_walker W_EMPTY; the bench asserts it on every event), so `ev_last_i || !ev_nz_i` and `ev_last_i` are the same signal on every reachable input"),
 ("spmv_ovf",      SPMV, "if (pe_ovf) ovf_q <= 1'b1;", "", "overflow flag never reported"),
 ("ib_sign",       IB,   "rd_neg   = signed_q && rd_out_data[31];", "rd_neg   = 1'b0;", "32-bit signed indices never negative"),
 ("sr_be",         SR,   "wire [4:0]  iss_lo   = (iss_j_q == 32'd0) ? {1'b0, lane0_q} : 5'd0;", "wire [4:0]  iss_lo   = 5'd0;", "index array reads touch bytes before the array"),
 ("eng_tag_ci",    ENG,  "rq_tag[3]  = {sf_sparse_pkg::SP_TAGSRC_CI,  5'(wk_rq_slot[1])};", "rq_tag[3]  = {sf_sparse_pkg::SP_TAGSRC_RP,  5'(wk_rq_slot[1])};", "column reader responses routed to the row-pointer reader"),
 ("eng_out_cnt",   ENG,  "out_q <= out_q + 8'(link_fire) - 8'(rsp_counted);", "out_q <= out_q + 8'(link_fire) - 8'(rsp_valid_i);", "outstanding counter also counts a protocol-invalid response (the command never completes after SP_F_PROTO)"),
 ("eng_sg_rot",    ENG,  "sg_rsh = sg_lane_q - sg_slane_q;", "sg_rsh = sg_slane_q - sg_lane_q;", "scatter source lane rotation direction"),
]

SUITES_INORDER = ["stage1", "faults", "chains", "scatter_in", "csr_in", "chain3"]
SUITES_OOO = ["scatter_ooo", "csr_ooo", "s2_ooo"]
ARITH = {"spmv_ovf"}            # arithmetic mutants only visible with a narrow accumulator

def sh(cmd, cwd, timeout):
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired:
        return 124, "TIMEOUT"

def run_mutant(m):
    mid, f, old, new, note = m[:5]
    equiv = m[5] if len(m) > 5 else ""
    wd = os.path.join(ROOT, "build", "mut", mid)
    shutil.rmtree(wd, ignore_errors=True); os.makedirs(wd)
    for d in ("rtl", "tb", "third_party", "scripts"):
        shutil.copytree(os.path.join(ROOT, d), os.path.join(wd, d))
    src = open(os.path.join(wd, f)).read()
    if src.count(old) != 1:
        return dict(id=mid, status="INVALID", note=f"patch site occurs {src.count(old)} times")
    open(os.path.join(wd, f), "w").write(src.replace(old, new, 1))
    env = dict(os.environ)
    sim = os.path.join(wd, "scripts", "sim.py")
    killed, how = False, ""
    inval, inconc = "", ""

    def first_error(out):
        for l in out.splitlines():
            if "%Error" in l or "error:" in l.lower():
                return l.strip()[:160]
        return out.strip()[-160:]

    def classify(rc, out, what):
        """-> (killed, how, invalid, inconclusive) for one simulator invocation"""
        if "No space left" in out:
            return False, "", "", f"{what}: no space left on device"
        if "verilator build failed" in out:
            return False, "", f"build failed: {first_error(out)}", ""
        if rc == 124:
            return False, "", "", f"{what}: process time-out"
        if rc != 0 or "ALL_PASS" not in out or "%Error" in out:
            return True, f"{what} failed", "", ""
        return False, "", "", ""

    for group, suites, ordc in (("inorder", SUITES_INORDER, 1), ("ooo", SUITES_OOO, 0)):
        rc, out = sh([sys.executable, sim, "--scen", os.path.join(ROOT, "build", suites[0] + ".txt"), "--build", f"m_{group}", "--ord-check", str(ordc)], wd, 900)
        killed, how, inval, inconc = classify(rc, out, suites[0])
        if killed or inval or inconc:
            break
        for s_ in suites[1:]:
            exe = os.path.join(wd, "build", f"m_{group}", "simv")
            try:
                p = subprocess.run([exe, f"+scen={os.path.join(ROOT, 'build', s_ + '.txt')}"], capture_output=True, text=True, timeout=600)
                killed, how, inval, inconc = classify(p.returncode, p.stdout + p.stderr, s_)
            except subprocess.TimeoutExpired:
                killed, how, inval, inconc = False, "", "", f"{s_}: process time-out"
            if killed or inval or inconc:
                break
        if killed or inval or inconc:
            break
    if not (killed or inval or inconc) and mid in ARITH:
        rc, out = sh([sys.executable, sim, "--scen", os.path.join(ROOT, "build", "csrovf_acc20.txt"), "--build", "m_arith",
                      "-G", "SPMV_ACC_W=20", "--ord-check", "1"], wd, 900)
        killed, how, inval, inconc = classify(rc, out, "csrovf (acc20)")
    shutil.rmtree(wd, ignore_errors=True)
    if inval:
        return dict(id=mid, status="INVALID", by=inval, note=note)
    if inconc:
        return dict(id=mid, status="INCONCLUSIVE", by=inconc, note=note)
    return dict(id=mid, status="KILLED" if killed else "SURVIVED", by=how, note=note, equivalent=equiv)

# scenario files the campaign needs: file name -> (generator suite, group)
NEEDED = {"stage1": ("stage1", "inorder"), "faults": ("faults", "inorder"), "chains": ("chains", "inorder"),
          "scatter_in": ("scatter", "inorder"), "scatter_ooo": ("scatter", "ooo"), "csr_in": ("csr", "inorder"),
          "csr_ooo": ("csr", "ooo"), "chain3": ("chain3", "inorder"), "s2_ooo": ("stage2", "ooo"), "s2_in": ("stage2", "inorder")}

def ensure_scenarios():
    """(Re)generate every scenario file the campaign reads when it is missing or older than the generator / model."""
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    srcs = [os.path.join(ROOT, "model", f) for f in ("gen_scenarios.py", "sp_model.py")]
    newest = max(os.path.getmtime(f) for f in srcs)
    jobs = [(name, suite, ["--group", group]) for name, (suite, group) in NEEDED.items()]
    jobs.append(("csrovf_acc20", "csrovf", ["--acc-w", "20"]))
    for name, suite, extra in jobs:
        out = os.path.join(ROOT, "build", name + ".txt")
        if not os.path.exists(out) or os.path.getmtime(out) < newest:
            subprocess.run([sys.executable, os.path.join(ROOT, "model", "gen_scenarios.py"), suite, out] + extra, check=True,
                           capture_output=True)

def main():
    ap = argparse.ArgumentParser()
    ensure_scenarios()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", default="")
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "mutation"))
    a = ap.parse_args()
    ms = [m for m in MUTANTS if not a.only or m[0] in a.only.split(",")]
    with ProcessPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(run_mutant, ms))
    json.dump(res, open(a.out + ".json", "w"), indent=1)
    k = sum(r["status"] == "KILLED" for r in res)
    L = ["# Mutation campaign", "", f"{len(res)} planted defects; **{k} killed**, {sum(r['status']=='SURVIVED' for r in res)} survived, "
         f"{sum(r['status']=='INVALID' for r in res)} invalid (did not build), {sum(r['status']=='INCONCLUSIVE' for r in res)} inconclusive (time-out).", "",
         "| id | planted defect | result | detected by |", "|---|---|---|---|"]
    for r in res:
        L.append(f"| {r['id']} | {r.get('note','')} | {r['status']} | {r.get('by','').replace('|', '/')} |")
    sv = [r for r in res if r["status"] == "SURVIVED"]
    if sv:
        L += ["", "## Survivors", ""] + [f"* **{r['id']}** - {r.get('note','')}. {('Believed equivalent: ' + r['equivalent']) if r.get('equivalent') else 'NOT explained: a test gap.'}" for r in sv]
    open(a.out + ".md", "w").write("\n".join(L) + "\n")
    print("\n".join(L[:6]))
    for r in res:
        if r["status"] != "KILLED":
            print(r)

if __name__ == "__main__":
    main()
