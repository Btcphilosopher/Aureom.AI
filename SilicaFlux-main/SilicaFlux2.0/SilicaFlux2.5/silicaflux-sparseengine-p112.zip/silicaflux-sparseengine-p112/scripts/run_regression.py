#!/usr/bin/env python3
"""
Full regression: DUT configurations x scenario suites x (in-order | out-of-order) target models.

For every configuration the Python reference model is re-instantiated with the SAME parameters
(ADDR_W, MAX_ELEM_BYTES, OBUF/IBUF size, ROB depth), scenarios are regenerated, the Verilator
test bench is built for that configuration and run.  Output: reports/regression.{json,md}.

usage: run_regression.py [--suites a,b,c] [--configs x,y] [--jobs N] [--out reports/regression]
"""
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ProcessPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "model"))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import sim  # noqa: E402

BASE = dict(ADDR_W=40, NRT=16, ROB_DEPTH=32, IDX_NSLOT=4, IDX_FIFO=4, MAX_ELEM_BYTES=256, OBUF_BYTES=8192, IBUF_BYTES=8192,
            SPMV_ACC_W=32, SPMV_OVF_WRAP=0, USE_CACHE=0, NUM_MSHR=1, MEM_OUT_LIMIT=4)
CONFIGS = {
    "base":       {},
    "nrt2":       dict(NRT=2),
    "nrt4":       dict(NRT=4),
    "nrt32":      dict(NRT=32),
    "rob16":      dict(ROB_DEPTH=16),
    "rob64":      dict(ROB_DEPTH=64),
    "idx_small":  dict(IDX_NSLOT=2, IDX_FIFO=2),
    "idx_big":    dict(IDX_NSLOT=8, IDX_FIFO=8),
    "tiny":       dict(NRT=4, ROB_DEPTH=4, MAX_ELEM_BYTES=48, OBUF_BYTES=2048, IBUF_BYTES=2048, IDX_NSLOT=2, IDX_FIFO=2),
    "addr24":     dict(ADDR_W=24),
    "addr32":     dict(ADDR_W=32),
    "addr48":     dict(ADDR_W=48),
    "acc20":      dict(SPMV_ACC_W=20),
    "wrap20":     dict(SPMV_ACC_W=20, SPMV_OVF_WRAP=1),
    "acc16":      dict(SPMV_ACC_W=16),
    "cache":      dict(USE_CACHE=1),
    "cache_mshr4": dict(USE_CACHE=1, NUM_MSHR=4, MEM_OUT_LIMIT=8),
    "cache_mshr2": dict(USE_CACHE=1, NUM_MSHR=2),
}
# configurations in which the target is a cache: only in-order target models, line-granular error behaviour
CACHE_CFGS = ("cache", "cache_mshr4", "cache_mshr2")
# suite -> (generator name, groups present)
SUITES = {
    "stage1": ("stage1", ["inorder"]),
    "faults": ("faults", ["inorder"]),
    "chains": ("chains", ["inorder"]),
    "stage2": ("stage2", ["inorder", "ooo"]),
    "scatter": ("scatter", ["inorder", "ooo"]),
    "chain3": ("chain3", ["inorder", "ooo"]),
    "csr":    ("csr", ["inorder", "ooo"]),
    "csrovf": ("csrovf", ["inorder"]),
    "nc":     ("nc", ["inorder"]),
}
# suites that only make sense for some configurations
ONLY = {"csrovf": ["base", "acc20", "wrap20", "acc16"]}
NO_CACHE_GROUPS = ("ooo",)          # CacheForge requires an in-order (ALP v1) memory behind it

def gparams(cfg_name, group, extra_g=()):
    params = dict(BASE); params.update(CONFIGS[cfg_name])
    return params, [f"{k}={v}" for k, v in params.items()] + [f"ORD_CHECK={1 if group == 'inorder' else 0}"] + list(extra_g)

def build_one(task):
    cfg_name, group, extra_g = task
    _, g = gparams(cfg_name, group, extra_g)
    sim.build(f"reg_{cfg_name}_{group}", g)
    return task

def run_one(task):
    cfg_name, suite, group, extra_g = task
    params, g = gparams(cfg_name, group, extra_g)
    wd = os.path.join(ROOT, "build", "reg", cfg_name); os.makedirs(wd, exist_ok=True)
    scen = os.path.join(wd, f"{suite}_{group}.txt")
    gen = SUITES[suite][0]
    cmd = [sys.executable, os.path.join(ROOT, "model", "gen_scenarios.py"), gen, scen, "--group", group,
           "--addr-w", str(params["ADDR_W"]), "--max-elem", str(params["MAX_ELEM_BYTES"]),
           "--obuf", str(params["OBUF_BYTES"]), "--ibuf", str(params["IBUF_BYTES"]), "--rob", str(params["ROB_DEPTH"]),
           "--acc-w", str(params["SPMV_ACC_W"])] + (["--wrap"] if params["SPMV_OVF_WRAP"] else []) + \
          (["--err-line", "4"] if params["USE_CACHE"] else [])
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        return dict(cfg=cfg_name, suite=suite, group=group, ok=False, err="generator: " + r.stderr[-500:])
    exe = os.path.join(ROOT, "build", f"reg_{cfg_name}_{group}", "simv")
    t0 = time.time()
    p = subprocess.run([exe, f"+scen={scen}"], capture_output=True, text=True)
    out = p.stdout
    m = re.search(r"SUMMARY pass=(\d+) fail=(\d+)", out)
    npass, nfail = (int(m.group(1)), int(m.group(2))) if m else (0, -1)
    elems = bytes_useful = reorder = reqs = 0
    for line in out.splitlines():
        if line.startswith("PERF "):
            v = line.split()[2:]
            elems += int(v[3]); bytes_useful += int(v[8])
        elif line.startswith("STAT "):
            mm = re.search(r"reqs=(\d+) ooo=(\d+)", line)
            reqs += int(mm.group(1)); reorder += int(mm.group(2))
    fails = [l for l in out.splitlines() if l.startswith("FAIL")][:10]
    aborted = ("%Error" in out) or ("%Error" in p.stderr)
    return dict(cfg=cfg_name, suite=suite, group=group, ok=(nfail == 0 and npass > 0 and not aborted and "ALL_PASS" in out),
                passed=npass, failed=nfail, elems=elems, bytes=bytes_useful, reqs=reqs, reordered=reorder,
                secs=round(time.time() - t0, 1), fails=fails + ([ (out + p.stderr)[-400:] ] if aborted else []))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suites", default=",".join(SUITES))
    ap.add_argument("--configs", default=",".join(CONFIGS))
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "regression"))
    ap.add_argument("-G", action="append", default=[])
    a = ap.parse_args()
    suites = a.suites.split(","); cfgs = a.configs.split(",")
    # build everything first (parallel), then run
    tasks = [(c, s, g, a.G) for c in cfgs for s in suites for g in SUITES[s][1] if c in ONLY.get(s, cfgs) and not (c in CACHE_CFGS and g in NO_CACHE_GROUPS)]
    builds = sorted({(c, g, tuple(a.G)) for (c, s, g, _x) in tasks})
    print(f'{len(tasks)} suite runs on {len(builds)} builds', flush=True)
    t0 = time.time()
    with ProcessPoolExecutor(max_workers=a.jobs) as ex:
        list(ex.map(build_one, builds))
        res = list(ex.map(run_one, tasks))
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    json.dump(res, open(a.out + ".json", "w"), indent=1)
    tp = sum(r.get("passed", 0) for r in res); tf = sum(max(r.get("failed", 0), 0) for r in res)
    te = sum(r.get("elems", 0) for r in res); tb = sum(r.get("bytes", 0) for r in res)
    lines = ["# Regression results", "",
             f"{len(cfgs)} configurations x {len(suites)} suites; **{tp} scenarios passed, {tf} failed**; "
             f"{te:,} elements / {tb:,} bytes compared byte-exact against the Python reference.", "",
             "| config | suite | target model | scenarios | failed | elements | link requests | reordered responses | result |", "|---|---|---|---|---|---|---|---|---|"]
    for r in res:
        lines.append(f"| {r['cfg']} | {r['suite']} | {r['group']} | {r.get('passed','-')} | {r.get('failed','-')} | {r.get('elems','-')} | {r.get('reqs','-')} | {r.get('reordered','-')} | {'PASS' if r['ok'] else 'FAIL'} |")
    bad = [r for r in res if not r["ok"]]
    for r in bad:
        lines += ["", f"### FAIL {r['cfg']}/{r['suite']}/{r['group']}", "```"] + r.get("fails", []) + ["```"]
    open(a.out + ".md", "w").write("\n".join(lines) + "\n")
    print("\n".join(lines[:4]))
    print(f"wall time {time.time()-t0:.0f}s; failing groups: {len(bad)}")
    for r in bad:
        print(r["cfg"], r["suite"], r["group"], r.get("fails", [])[:3])
    sys.exit(1 if bad else 0)

if __name__ == "__main__":
    main()
