#!/usr/bin/env python3
"""Re-check the SHA-256 digests in third_party/SHA256SUMS (the vendored files must not have been edited)."""
import hashlib, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TP = os.path.join(ROOT, "third_party")
bad = 0; n = 0
for line in open(os.path.join(TP, "SHA256SUMS")):
    h, rel = line.rstrip("\n").split("  ", 1)
    n += 1
    if hashlib.sha256(open(os.path.join(TP, rel), "rb").read()).hexdigest() != h:
        print("CHANGED:", rel); bad += 1
print(f"{n} vendored files checked, {bad} changed")
sys.exit(1 if bad else 0)
