#!/usr/bin/env python3
"""Render README.md; every number comes from reports/."""
import json, os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = lambda n: os.path.join(ROOT, "reports", n)
reg = json.load(open(R("final_regression.json")))
mut = json.load(open(R("mutation.json")))
syn = {r["name"]: r for r in json.load(open(R("synthesis.json")))}
bench = json.load(open(os.path.join(ROOT, "benchmarks", "results", "bench.json")))
adapter = open(R("adapter.txt")).read() if os.path.exists(R("adapter.txt")) else ""
nc = json.load(open(R("nc_regression.json"))) if os.path.exists(R("nc_regression.json")) else []
P = sum(r.get("passed", 0) for r in reg); F = sum(max(r.get("failed", 0), 0) for r in reg)
E = sum(r.get("elems", 0) for r in reg); B = sum(r.get("bytes", 0) for r in reg)
ncfg = len({r["cfg"] for r in reg})
k = sum(m["status"] == "KILLED" for m in mut); s = sum(m["status"] == "SURVIVED" for m in mut); inv = sum(m["status"] == "INVALID" for m in mut)
ad = re.search(r"ADAPTER checks=(\d+) errors=(\d+)", adapter)
d = syn["default"]; g = syn["gs_only"]
nrun = len(bench); ok = sum(r["correct"] for r in bench)
co = d['modules']['sf_sparse_request_coalescer']
co_share = 100 * (co['cells'] - co['ffs']) / d['logic_cells']
co_path = d['paths']['sf_sparse_request_coalescer']
get = lambda sy, wl, lat=30: next(r["elems_per_cycle"] for r in bench if r["system"] == sy and r["workload"] == wl and r["mem_latency"] == lat)
L = f"""# SilicaFlux Project 112 — SparseEngine

### Sparse AI memory access processor · Aureom.AI | SilicaFlux Cloud Semiconductor Systems

A synthesizable memory engine for irregular and sparse workloads: it **generates, validates, schedules and executes noncontiguous memory
requests** — indexed gather, indexed scatter, validated CSR traversal — and, optionally, one INT8 sparse matrix-vector product on the
existing verified arithmetic lane. **Primary RTL: `rtl/sf_sparse_memory_engine.sv`.**

```
Command Decoder → Index Buffer → Address Generator → Permission Validation → Request Coalescer / Scheduler
        → [ALP v1 link: CacheForge or any ALP target] → Response Reorder → Output Buffer
```

> **Delivered as an archive — nothing was committed to GitHub.** Evidence is **RTL simulation (Verilator 5.49) against an independent Python
> model, a mutation campaign and generic Yosys statistics.** There is **no FPGA, no silicon, no PDK, no timing, area or power figure and no formal proof**
> (`docs/08_limitations.md`). **No claim of arbitrary sparse neural-network acceleration is made**: the only arithmetic is INT8 SpMV on TensorCore 01's `tensor_pe`.
> **CacheForge is in-order**, so out-of-order response reordering was verified against the bench's target model, not against any SilicaFlux block.
> **Not hardware-coherent** (software-managed visibility, as CacheForge). **Not connected to the SFB2 DataFabric** (no bridge exists in the repository).

## Results at delivery (all generated: `reports/`)

| evidence | result |
|---|---|
| **regression** (final RTL, {ncfg} configurations: request table 2…32, reorder 4…64, address widths 24…48, narrow accumulators, three CacheForge configurations) | **{P:,} scenarios pass, {F} fail**; {E:,} elements / {B:,} bytes compared against the independent model (output buffer **byte for byte, every other byte unchanged**, and the **entire memory image**) |
| **through the real CacheForge** (1, 2, 4 MSHRs) | every in-order suite passes, plus the `cacheable = 0` bypass suite ({sum(r.get('passed',0) for r in reg if r['suite']=='nc' and r['cfg'].startswith('cache'))} scenarios on the three cache configurations) |
| **tensor adapter** against the real TensorScratch | {int(ad.group(1)):,} operand comparisons on the k-slice stream, {ad.group(2)} errors; ping-pong, no-free-set, ownership refusal, RANGE / ALIGN / OWNER |
| **mutation campaign** | {len(mut)} planted defects: **{k} killed**, {s} survived, {inv} invalid (`reports/mutation.md`). The {s} survivors are argued to be *equivalent* mutants (same behaviour on every reachable input; reasons in `docs/05` §5), not proven so; the first campaign's survivors that were real test gaps were closed with new tests |
| **link rules** | ALP link checker on every in-order run; tag reuse, outstanding limit, request stability, **no two writes to one beat in flight** on every run |
| **synthesis** (Yosys generic gates, no PDK) | full engine **{d['logic_cells']:,} logic cells, {d['flip_flops']:,} flip-flops, 0 latches, {d['ram_bits']:,} RAM bits**; gather/scatter only {g['logic_cells']:,}; `check -assert` clean. Hot spot: the request coalescer (≈{co_share:.0f}% of the logic, {co_path}-gate path, not optimised) |
| **benchmarks** | {nrun} runs ({ok} correct): 64-byte-row gather reaches **{get('direct_mo32_big','seq_E64'):.2f} elements/cycle** ({100*get('direct_mo32_big','seq_E64')/0.25:.0f}% of the 0.25 link peak) with a 32-entry request table at latency 30, **{get('direct_mo32','seq_E64'):.2f}** with the default 16; a blocking CacheForge was **slower than direct memory for every workload** when the memory sustains many outstanding requests, and {min(get('cache_blk','rand_big_E64',l)/get('direct_mo1','rand_big_E64',l) for l in (30,100,250)):.0f}–{max(get('cache_blk','rand_big_E64',l)/get('direct_mo1','rand_big_E64',l) for l in (30,100,250)):.0f}× faster than a one-outstanding path at latency ≥ 30 (`docs/06`) |

## Read first

| document | content |
|---|---|
| `docs/00_repository_audit.md` | what exists in the repository, what was reused, what is missing |
| `docs/01_overview.md` | decisions, **traceability matrix from every section of the brief**, deliverables, definition-of-done status |
| `docs/02_functional_spec.md` | the **normative** behaviour (element rules, permission rules, **duplicate-scatter policy**, CSR validation, SpMV arithmetic contract, fault semantics) |
| `docs/03_microarchitecture.md` | block diagram, request table / coalescer, reorder buffer, arbitration, CSR walker, SpMV lane |
| `docs/04_integration.md` | ports, parameters, MemoryGuard, **CacheForge (and its visibility rules)**, TensorScratch adapter, DataFabric status |
| `docs/05_verification.md` | method, results, mutation campaign, **the defects found along the way** |
| `docs/06_benchmarks.md` | measurements, cache vs no cache, latency sweep, interpretation |
| `docs/07_synthesis.md` | what the Yosys numbers are and are not; the hot spot |
| `docs/08_limitations.md` | **everything this package does not do or prove** |

## Layout

```
rtl/            sf_sparse_pkg · sf_sparse_memory_engine (top) · sf_sparse_index_buffer · sf_sparse_stream_rd · sf_sparse_address_gen (+ beat_split)
                sf_sparse_request_coalescer · sf_sparse_reorder · sf_sparse_csr_walker · sf_sparse_spmv · sf_sparse_tensor_adapter     rtl/files.f = compile order
third_party/    vendored UNMODIFIED, SHA-256 + provenance: MemoryGuard (checker, regions), AlbionCore (ALP v1 + link checkers), TensorCore 01 tensor_pe,
                CacheForge + SRAMMacroBridge, TensorScratch                       (`make check` re-verifies the digests)
tb/             tb_sparse.sv (scenario-driven, self-checking) · tb_adapter.sv (engine → adapter → real TensorScratch)
model/          sp_model.py (independent reference) · gen_scenarios.py (scenario families, {sum(r.get('passed',0) for r in reg if r['cfg']=='base')} scenarios at the base configuration)
scripts/        run_regression.py · run_mutation.py · run_adapter.py · run_synth.py · sim.py · make_*.py (documents) · lint_docs.py
benchmarks/     run_bench.py · results/ (csv + json)
reports/        regression · mutation · synthesis · stage1_2_frozen · stage3_frozen · adapter
docs/ Makefile
```

## Quick start

```bash
pip install verilator yowasp-yosys        # Verilator 5.49 (wheel 5.48.0), Yosys 0.71; Python 3.13
make check                                # vendored files unchanged, model imports
make quick                                # base configuration, all suites
make regress                              # every configuration x every suite
make adapter mutate bench synth           # tensor adapter, mutation campaign, benchmarks, synthesis statistics
```

Instantiation (defaults; see `docs/04` for every port):

```systemverilog
sf_sparse_memory_engine #(.ADDR_W(40), .NRT(16), .ROB_DEPTH(32), .OBUF_BYTES(8192), .IBUF_BYTES(8192)) u_sparse (
  .clk_i, .rst_ni,
  .cmd_valid_i, .cmd_ready_o, .cmd_i,   .done_valid_o, .done_ready_i, .done_o,
  .cfg_max_out_i(8'd1 /* <= target's advertised limit */), .cfg_merge_en_i(1'b1), .cfg_burst_en_i(1'b1),
  .ipush_valid_i, .ipush_ready_o, .ipush_data_i,
  .ibuf_we_i, .ibuf_waddr_i, .ibuf_wdata_i, .ibuf_wbe_i,   .obuf_raddr_i, .obuf_rdata_o,
  .req_valid_o, .req_ready_i, .req_o,   .rsp_valid_i, .rsp_ready_o, .rsp_i,                 // ALP v1 initiator -> CacheForge upstream port
  .t_valid_i, .t_base_i, .t_end_i, .t_r_i, .t_w_i, .t_devn_i, .t_dev_i, .t_allow_i,         // = sf_memory_guard_regions outputs
  .busy_o, .perf_o, .perf_clear_i);
```

## Honest boundaries (full list in `docs/08_limitations.md`)

* One command at a time; no abort (reset only); natural-aligned elements of 1/2/4/8 or a multiple of 16 bytes.
* **Scatter has no atomics and no scatter-add**; duplicates are last-writer-wins by element index; a memory-side *write error* leaves later elements' effect unspecified.
* **SpMV is INT8×INT8→INT32 only** (saturating or wrapping, sequential reduction); other value formats are traversed, not multiplied.
* Cache visibility is software-managed; the benchmarks show a blocking CacheForge **hurts** most sparse gathers when memory can overlap requests.
* The tensor adapter is verified against the scratchpad's slice stream, not with a GEMM through the systolic array.
* No timing, area or power claim; no formal proof; verification by the author of the RTL (independent code, same author).
"""
open(os.path.join(ROOT, "README.md"), "w").write(L)
print("README.md written")
