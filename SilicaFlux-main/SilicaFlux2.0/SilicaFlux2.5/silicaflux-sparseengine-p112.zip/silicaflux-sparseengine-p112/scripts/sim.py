#!/usr/bin/env python3
"""Build tb_sparse with Verilator and run a scenario file.

usage: sim.py --scen FILE [--build NAME] [-G NAME=VALUE ...] [--ord-check 0|1] [--rebuild]
Environment: VERILATOR (path to the verilator executable, default: verilator-cli / verilator on PATH).
"""
import argparse, os, shutil, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def verilator():
    v = os.environ.get("VERILATOR")
    if v:
        return v
    for cand in ("verilator", "verilator-cli"):
        p = shutil.which(cand)
        if p:
            return p
    sys.exit("verilator not found (set VERILATOR)")

CACHE_FILES = ["third_party/cacheforge/third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_enc.sv",
               "third_party/cacheforge/third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_dec.sv",
               "third_party/cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_be_generic.sv",
               "third_party/cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_be_fpga.sv",
               "third_party/cacheforge/third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_ihp1p.sv",
               "third_party/cacheforge/third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_gf180.sv",
               "third_party/cacheforge/third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_sky130.sv",
               "third_party/cacheforge/third_party/srammacrobridge/rtl/backends/asic/stubs/sf_sram_macro_blackboxes.sv",
               "third_party/cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_be_asic.sv",
               "third_party/cacheforge/third_party/srammacrobridge/rtl/sf_sram_macro_wrapper.sv",
               "third_party/albioncore/rtl/sf_albion_skid.sv", "third_party/albioncore/rtl/sf_albion_fifo.sv",
               "third_party/cacheforge/rtl/cache/sf_cache_pkg.sv", "third_party/cacheforge/rtl/cache/sf_cache_addr.sv",
               "third_party/cacheforge/rtl/cache/sf_cache_replacement.sv", "third_party/cacheforge/rtl/cache/sf_cache_tag_array.sv",
               "third_party/cacheforge/rtl/cache/sf_cache_data_array.sv", "third_party/cacheforge/rtl/cache/sf_cache_mshr.sv",
               "third_party/cacheforge/rtl/cache/sf_cache_memport.sv", "third_party/cacheforge/rtl/cache/sf_cache_refill.sv",
               "third_party/cacheforge/rtl/cache/sf_cache_writeback.sv", "third_party/cacheforge/rtl/cache/sf_cache_perf.sv",
               "third_party/cacheforge/rtl/cache/sf_llc_cache.sv"]
CACHE_INC = ["third_party/cacheforge/third_party/srammacrobridge/rtl", "third_party/cacheforge/third_party/srammacrobridge/rtl/ecc",
             "third_party/cacheforge/third_party/srammacrobridge/rtl/backends"]

def files(extra_rtl=(), tb=None):
    rtl = [l.strip() for l in open(os.path.join(ROOT, "rtl", "files.f")) if l.strip() and not l.startswith("#")]
    rtl = [os.path.normpath(os.path.join(ROOT, "rtl", p)) for p in rtl]
    tp = [os.path.join(ROOT, "third_party", "memory_guard", "sf_memory_guard_regions.sv"),
          os.path.join(ROOT, "third_party", "albioncore", "tests", "sf_albion_chan_checker.sv"),
          os.path.join(ROOT, "third_party", "albioncore", "tests", "sf_albion_link_checker.sv")]
    cache = [os.path.join(ROOT, f) for f in CACHE_FILES]            # always compiled; instantiated only when USE_CACHE=1
    return rtl + list(extra_rtl) + cache + tp + [os.path.join(ROOT, "tb", tb or "tb_sparse.sv")]

def build(name, gparams, extra_rtl=(), rebuild=False, top="tb_sparse", tb=None):
    """Build the bench.  Precompiled headers occasionally come out invalid when several builds run at
    once; the build directory is wiped and the build retried (serially) before giving up."""
    mdir = os.path.join(ROOT, "build", name)
    exe = os.path.join(mdir, "simv")
    if os.path.exists(exe) and not rebuild:
        newest = max(os.path.getmtime(f) for f in files(extra_rtl, tb))
        if os.path.getmtime(exe) >= newest:        # a binary older than any source file is stale: rebuild
            return exe
    last = ""
    for attempt in range(3):
        if os.path.isdir(mdir):
            shutil.rmtree(mdir)
        os.makedirs(mdir, exist_ok=True)
        cmd = [verilator(), "--binary", "--timing", "--assert", "-j", "2" if attempt else "4", "-Wno-fatal", "-Wno-lint",
               "-Wno-style", "-Wno-TIMESCALEMOD", "-CFLAGS", "--std=c++20 -fcoroutines",
               "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include", "--x-assign", "unique", "--x-initial", "unique",
               "--top-module", top, "-Mdir", mdir, "-o", "simv"]
        cmd += [f"-I{os.path.join(ROOT, d)}" for d in CACHE_INC]
        cmd += [f"-G{g}" for g in gparams]
        cmd += files(extra_rtl, tb)
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, env=dict(os.environ))
        if r.returncode == 0 and os.path.exists(exe):
            return exe
        last = (r.stdout + r.stderr)[-3000:]
    sys.stderr.write(last)
    sys.exit(f"verilator build failed ({name})")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scen", required=True)
    ap.add_argument("--build", default="default")
    ap.add_argument("-G", action="append", default=[])
    ap.add_argument("--ord-check", default="1")
    ap.add_argument("--rebuild", action="store_true")
    a = ap.parse_args()
    g = list(a.G) + [f"ORD_CHECK={a.ord_check}"]
    exe = build(a.build, g, rebuild=a.rebuild)
    r = subprocess.run([exe, f"+scen={os.path.abspath(a.scen)}"], capture_output=True, text=True)
    sys.stdout.write(r.stdout)
    sys.stderr.write(r.stderr[-3000:])
    sys.exit(0 if "ALL_PASS" in r.stdout and r.returncode == 0 else 1)

if __name__ == "__main__":
    main()
