#!/usr/bin/env python3
"""Every scenario name / glob cited in docs/*.md (e.g. `s1_E*_seq`) must match at least one generated scenario."""
import fnmatch, glob, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "model"))
import sp_model as M, gen_scenarios as G
cfg = M.Cfg()
names = set()
for suite in ("stage1", "faults", "chains", "stage2", "scatter", "chain3", "csr", "csrovf", "nc"):
    for sc in G.__dict__[{"stage1": "stage1_suite", "faults": "stage1_fault_suite", "chains": "chain_suite", "stage2": "stage2_suite",
                          "scatter": "stage3_scatter_suite", "chain3": "chain3_suite", "csr": "csr_suite", "csrovf": "csr_ovf_suite",
                          "nc": "nc_suite"}[suite]](cfg):
        names.add(sc.name)
# benchmark workloads are named in docs/06
import importlib.util
spec = importlib.util.spec_from_file_location("rb", os.path.join(ROOT, "benchmarks", "run_bench.py"))
rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)
names |= set(rb.workloads(False))
PAT = re.compile(r"`((?:s[123]c?|f[13]c?|c[13]s?|o3|nc)_[A-Za-z0-9_*]+)`")
bad = []
for f in sorted(glob.glob(os.path.join(ROOT, "docs", "*.md"))):
    txt = open(f).read()
    for tok in sorted(set(PAT.findall(txt))):
        # cited in slash-lists like `s1_E*_rev/stride/rand`: expand the last segment alternatives
        alts = [tok]
        if "/" in tok:
            head, *tails = tok.split("/")
            stem = head.rsplit("_", 1)[0]
            alts = [head] + [stem + "_" + t for t in tails]
        for t in alts:
            if not any(fnmatch.fnmatch(n, t) for n in names):
                bad.append((os.path.basename(f), t))
print(f"{len(names)} scenarios known; unmatched citations: {len(bad)}")
for b in bad:
    print("  ", b)
sys.exit(1 if bad else 0)
