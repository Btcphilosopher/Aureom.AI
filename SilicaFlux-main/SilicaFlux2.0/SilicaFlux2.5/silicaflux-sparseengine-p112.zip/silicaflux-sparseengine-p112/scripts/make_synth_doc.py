#!/usr/bin/env python3
"""Render docs/07_synthesis.md from reports/synthesis.json."""
import json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = {r["name"]: r for r in json.load(open(os.path.join(ROOT, "reports", "synthesis.json")))}
d = R["default"]
tot = d["logic_cells"]
mods = sorted(d["modules"].items(), key=lambda kv: -kv[1]["cells"])
co = d["modules"]["sf_sparse_request_coalescer"]
L = ["# 07 — Synthesis statistics", "",
     "**What this is.** Technology-independent statistics from a generic **Yosys** flow: coarse `synth`, RAM arrays kept as RAMs, "
     "`techmap`, `abc` to generic gates, `check -assert`. **What this is not:** there is no liberty file, no PDK, no static timing, no "
     "area in µm², no power, no place-and-route, no FPGA mapping. A \"cell\" is a Yosys generic gate (`$_NAND_`, `$_AND_`, `$_MUX_`, …); "
     "a \"path length\" is a number of such gates on the longest topological path of a module (`ltp -noff`), **not a delay**.", "",
     "Reproduce: `make synth` (≈ 10 minutes). Raw: `reports/synthesis.json`, logs and netlist statistics in `build/synth/<config>/`.", "",
     "## 1. Results", "",
     "| configuration | overrides | logic cells | flip-flops | latches | RAM bits | `check -assert` |", "|---|---|---|---|---|---|---|"]
for n, r in R.items():
    L.append(f"| {n} | {', '.join(f'{k}={v}' for k, v in r['params'].items()) or 'defaults'} | {r['logic_cells']:,} | {r['flip_flops']:,} | {r['latches']} | {r['ram_bits']:,} | passed |")
L += ["", "* `default` = the full engine (gather, scatter, CSR, SpMV) with `NRT = 16`, `ROB_DEPTH = 32`, 8 KiB input and output buffers.",
      "* `gs_only` = gather / scatter only (`CSR_EN = SPMV_EN = 0`): the walker, event FIFO and SpMV lane disappear "
      f"({d['logic_cells'] - R['gs_only']['logic_cells']:,} logic cells, {d['flip_flops'] - R['gs_only']['flip_flops']:,} flip-flops).",
      "* **0 latches and `check -assert` clean** in every configuration (no combinational loop, no multiple driver, no undriven net).",
      "* **RAM bits** are the arrays Yosys inferred as memories (not flattened): the two local buffers dominate "
      f"({d['ram_bits']:,} bits in `default`; 65,536 bits each for 8 KiB). The request table's data (`NRT × 128` bits) is built from **flip-flops** "
      "here, not RAM — it is read at an arbitrary index and written by three sources in one cycle.", "",
      "## 2. Where the logic is (`default`)", "", "| module | logic cells | share | flip-flops | longest path (generic gates) |", "|---|---|---|---|---|"]
for m, v in mods:
    L.append(f"| `{m}` | {v['cells'] - v['ffs']:,} | {100 * (v['cells'] - v['ffs']) / tot:.0f}% | {v['ffs']:,} | {d['paths'].get(m, '-')} |")
L += ["", "(Per-module counts are the module's own cells **per instance**; `sf_sparse_stream_rd` is instantiated four times (index buffer + the three CSR readers), so its row understates its share; the module counts sum to the design total only after weighting by instance count. `tensor_pe` and the MemoryGuard checker are the unmodified vendored cores.)", "",
      "## 3. What to take from it — and the hotspot",
      "",
      f"1. **The request coalescer is {100 * (co['cells'] - co['ffs']) / tot:.0f}% of the logic and has the longest path ({d['paths'].get('sf_sparse_request_coalescer', '?')} generic gates).** "
      "It holds the request table (`NRT` entries of 128-bit data, 44-bit beat addresses, byte enables, age, dependency), does the "
      "fully-associative match of every incoming descriptor, and performs issue selection (continuation / same line / oldest) in one "
      "cycle. The selection and merge decision is an unpipelined chain; this package made no attempt to optimise it for frequency.",
      "   *First optimisations, not done here:* pipeline the selection (register the selected index one cycle ahead), turn the linear "
      "oldest-search into a tree, narrow the per-entry latency counters, and move entry data into a RAM with a separate "
      "tag array (the cost of that is a more complex merge path). `NRT` scales this block roughly linearly "
      f"(`small`, `NRT = 4`: {R['small']['logic_cells']:,} cells in total).",
      f"2. **The MemoryGuard checker costs {100 * (d['modules']['sf_memory_guard_checker']['cells']) / tot:.0f}%** for 16 regions with 40-bit comparators "
      "(`LOOKUP_ARCH = 0`, all regions in parallel). `LOOKUP_ARCH = 1` (multiplex the claimed domain's regions first) trades area for a longer path; not evaluated here.",
      f"3. **A {d['paths'].get('sf_sparse_request_coalescer', '?')}-gate path is not a frequency.** No claim is made about the clock this design could reach; the number only says where the next timing work belongs.",
      "4. **Not covered:** the testbench-only blocks, the CacheForge / TensorScratch cores (their own reports exist), any physical effect.", ""]
open(os.path.join(ROOT, "docs", "07_synthesis.md"), "w").write("\n".join(L) + "\n")
print("docs/07_synthesis.md written")
