#!/usr/bin/env python3
"""
Technology-independent synthesis statistics with Yosys (generic gates, no liberty file, no PDK).

Flow per configuration:
    read_verilog -sv <engine + vendored cores>;  hierarchy (with -chparam overrides)
    synth  begin:fine           (coarse synthesis; memories stay $mem_v2)
    dump $mem_v2                (RAM arrays: reported in BITS, not flattened into flip-flops)
    opt / techmap / opt / abc   (generic gate netlist)
    check -assert               (no loops, no multiple drivers, no undriven nets)
    stat -json, ltp -noff       (cell counts per module, longest topological path per module)

NOTHING here is a timing, area or power claim: gate counts are Yosys generic cells (NAND/AND/MUX/...), the path
length is a number of generic gates, and RAM arrays are listed separately.  See docs/07_synthesis.md.
"""
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ProcessPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOP = "sf_sparse_memory_engine"
CONFIGS = {
    "default":   {},
    "gs_only":   dict(CSR_EN=0, SPMV_EN=0),
    "small":     dict(CSR_EN=0, SPMV_EN=0, NRT=4, ROB_DEPTH=16, MAX_ELEM_BYTES=64, OBUF_BYTES=2048, IBUF_BYTES=2048, IDX_NSLOT=2, IDX_FIFO=2),
    "large":     dict(NRT=32, ROB_DEPTH=64, OBUF_BYTES=32768, IBUF_BYTES=32768),
}

def yosys():
    import shutil
    for c in ("yowasp-yosys", "yosys"):
        p = shutil.which(c)
        if p:
            return p
    cand = os.environ.get("YOSYS")
    if cand:
        return cand
    sys.exit("yosys not found (set YOSYS)")

def run(name):
    params = CONFIGS[name]
    # YoWASP runs in a sandbox that only sees paths below the working directory: use ROOT-relative paths throughout
    wd_rel = os.path.join("build", "synth", name)
    wd = os.path.join(ROOT, wd_rel); os.makedirs(wd, exist_ok=True)
    files = [l.strip() for l in open(os.path.join(ROOT, "rtl", "files.f")) if l.strip()]
    files = [os.path.normpath(os.path.join("rtl", f)) for f in files]
    chp = " ".join(f"-chparam {k} {v}" for k, v in params.items())
    script = f"""read_verilog -sv {' '.join(files)}
hierarchy -top {TOP} {chp}
synth -top {TOP} -run begin:fine
tee -q -o {wd_rel}/mems.txt dump t:$mem_v2
opt -fast -full
techmap
opt -fast
abc
opt -fast
check -assert
tee -q -o {wd_rel}/stat.json stat -json -top {TOP} -width
tee -q -o {wd_rel}/ltp.txt ltp -noff
"""
    open(os.path.join(wd, "run.ys"), "w").write(script)
    t0 = time.time()
    p = subprocess.run([yosys(), "-s", os.path.join(wd_rel, "run.ys")], capture_output=True, text=True, cwd=ROOT)
    open(os.path.join(wd, "yosys.log"), "w").write(p.stdout + p.stderr)
    if p.returncode != 0 or not os.path.exists(os.path.join(wd, "stat.json")):
        return dict(name=name, ok=False, err=(p.stdout + p.stderr)[-1500:])
    j = json.load(open(os.path.join(wd, "stat.json")))
    mods = {}
    for mname, m in j["modules"].items():
        short = mname.split("\\")[-1]
        t = m.get("num_cells_by_type", {})
        ffs = sum(v for k, v in t.items() if "DFF" in k or "DLATCH" in k)
        lat = sum(v for k, v in t.items() if "DLATCH" in k)
        sub = sum(v for k, v in t.items() if k.startswith("$paramod") or not k.startswith("$"))
        mem = t.get("$mem_v2", 0)
        mods[short] = dict(cells=m["num_cells"] - sub - mem, ffs=ffs, latches=lat, wires=m.get("num_wires"), types=t)
    d = j["design"]
    tt = d.get("num_cells_by_type", {})
    ffs = sum(v for k, v in tt.items() if "DFF" in k)
    lat = sum(v for k, v in tt.items() if "DLATCH" in k)
    mem_cells = tt.get("$mem_v2", 0)
    logic = sum(v for k, v in tt.items() if k.startswith("$_") and "DFF" not in k and "DLATCH" not in k)
    # RAM arrays
    rams, cur = [], {}
    for line in open(os.path.join(wd, "mems.txt")):
        m = re.search(r"cell \$mem_v2 \S+\s+# (\S+)", line)
        if m:
            cur = {"name": m.group(1)}; rams.append(cur)
        m = re.search(r"parameter \\(WIDTH|SIZE) (\d+)", line)
        if m and cur is not None and rams:
            rams[-1][m.group(1).lower()] = int(m.group(2))
    for r in rams:
        r["bits"] = r.get("width", 0) * r.get("size", 0)
    # longest topological path per module
    paths = {}
    cur_mod = None
    for line in open(os.path.join(wd, "ltp.txt")):
        m = re.search(r"Longest topological path in (\S+) \(length=(\d+)\)", line)
        if m:
            paths[m.group(1).split("\\")[-1].rstrip(")")] = int(m.group(2))
    return dict(name=name, ok=True, params=params, logic_cells=logic, flip_flops=ffs, latches=lat, ram_arrays=rams,
                ram_bits=sum(r["bits"] for r in rams), mem_cells=mem_cells, modules=mods, gate_types={k: v for k, v in tt.items() if k.startswith("$_") and "DFF" not in k},
                paths=paths, secs=round(time.time() - t0, 1), check="passed (check -assert)")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default=",".join(CONFIGS))
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "synthesis"))
    a = ap.parse_args()
    names = a.configs.split(",")
    with ProcessPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(run, names))
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    json.dump(res, open(a.out + ".json", "w"), indent=1)
    L = ["# Synthesis statistics (Yosys generic gates)", "",
         "Technology-independent counts from a generic Yosys flow (`synth` coarse stage, RAM arrays kept as RAMs, `techmap`, `abc`). "
         "**No liberty file, PDK, timing, area or power is involved**; see docs/07_synthesis.md for what these numbers do and do not mean.", "",
         "| configuration | overrides | logic cells | flip-flops | latches | RAM bits (arrays) | `check -assert` |", "|---|---|---|---|---|---|---|"]
    for r in res:
        if not r["ok"]:
            L.append(f"| {r['name']} | - | FAILED | | | | {r['err'][:80]!r} |")
            continue
        L.append(f"| {r['name']} | {', '.join(f'{k}={v}' for k, v in r['params'].items()) or 'defaults'} | {r['logic_cells']:,} | {r['flip_flops']:,} | {r['latches']} | {r['ram_bits']:,} | {r['check']} |")
    for r in res:
        if not r["ok"]:
            continue
        L += ["", f"## {r['name']}", "", "### Per module (own cells; instances counted once per module type)", "",
              "| module | logic cells | flip-flops | longest path (generic gates) |", "|---|---|---|---|"]
        for m, v in sorted(r["modules"].items(), key=lambda kv: -kv[1]["cells"]):
            L.append(f"| {m} | {v['cells'] - v['ffs']:,} | {v['ffs']:,} | {r['paths'].get(m, '-')} |")
        L += ["", "### RAM arrays (not flattened into flip-flops)", "", "| array | width x depth | bits |", "|---|---|---|"]
        for ra in r["ram_arrays"]:
            L.append(f"| {ra['name']} | {ra.get('width','?')} x {ra.get('size','?')} | {ra['bits']:,} |")
    open(a.out + ".md", "w").write("\n".join(L) + "\n")
    print("\n".join(L[:12]))
    sys.exit(0 if all(r["ok"] for r in res) else 1)

if __name__ == "__main__":
    main()
