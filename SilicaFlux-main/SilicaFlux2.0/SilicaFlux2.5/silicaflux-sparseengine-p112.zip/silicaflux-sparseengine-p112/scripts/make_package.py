#!/usr/bin/env python3
"""Build ../silicaflux-sparseengine-p112.zip (plain archive: no .git, no build products) and MANIFEST.sha256."""
import hashlib, os, sys, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "silicaflux-sparseengine-p112"
SKIP_DIRS = {"build", "__pycache__", ".git", ".pytest_cache"}
SKIP_SUFFIX = (".pyc", ".pyo")
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(ROOT), NAME + ".zip")

def files():
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = sorted(d for d in dns if d not in SKIP_DIRS)
        for f in sorted(fns):
            if f.endswith(SKIP_SUFFIX) or f == "MANIFEST.sha256":
                continue
            yield os.path.join(dp, f)

sums = []
for p in files():
    sums.append(f"{hashlib.sha256(open(p, 'rb').read()).hexdigest()}  {os.path.relpath(p, ROOT)}")
open(os.path.join(ROOT, "MANIFEST.sha256"), "w").write("\n".join(sums) + "\n")
n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in list(files()) + [os.path.join(ROOT, "MANIFEST.sha256")]:
        z.write(p, os.path.join(NAME, os.path.relpath(p, ROOT)))
        n += 1
print(f"{n} files -> {OUT} ({os.path.getsize(OUT) / 1e6:.1f} MB)")
