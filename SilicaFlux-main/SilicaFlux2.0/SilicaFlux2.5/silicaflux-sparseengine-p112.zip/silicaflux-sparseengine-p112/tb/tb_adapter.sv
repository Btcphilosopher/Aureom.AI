// =============================================================================
//  tb_adapter.sv -- sparse engine -> sf_sparse_tensor_adapter -> REAL TensorScratch (P75)
//
//  Checks the "tensor input preparation" path end to end:
//    1. the engine GATHERS rows of an A table and of a B table into its output buffer;
//    2. the adapter assembles them into a row-major tile in the CURRENT FILL SET of the
//       unmodified TensorScratch through its DMA fill port;
//    3. a tile descriptor is issued and every k-slice the scratchpad delivers to the
//       systolic-array input (s_a / s_b) is compared with the operands the gather selected.
//  Also checked:
//    * ping-pong: a second tile is filled while the first is being consumed; the first
//      tile's slices must be unaffected ("do not overwrite active operand buffers");
//    * both sets busy: the adapter waits (no write reaches the scratchpad);
//    * invalid parameters: rejected before any side effect on the scratchpad;
//    * ownership guard: a set that is not FILLING receives no write;
//    * scratchpad-side error (RANGE) is reported and the transfer terminates cleanly.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_adapter;
  import sf_sparse_pkg::*;

  localparam int ADDR_W = 40;
  localparam int OBUF_BYTES = 8192;
  localparam int OBW = $clog2(OBUF_BYTES/16);
  localparam int ND = 4, NR = 4, NP = 4, PIDX = 3;
  localparam int KDIM = 8, MDIM = 4, NDIM = 4;               // tile: A is MDIM x KDIM, B is KDIM x NDIM (INT8)
  localparam longint unsigned A_TBL = 64'h10000, B_TBL = 64'h11000, IDX_A = 64'h20000, IDX_B = 64'h20400;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------------ engine
  logic                    cmd_valid = 1'b0, cmd_ready, done_valid, done_ready = 1'b0;
  sf_sp_cmd_t              cmd;
  sf_sp_done_t             done;
  logic                    ipush_ready;
  logic [OBW-1:0]          obuf_raddr;
  logic [127:0]            obuf_rdata;
  logic                    req_valid, req_ready = 1'b1, rsp_ready, rsp_valid = 1'b0;
  sf_albion_pkg::sf_req_t  req;
  sf_albion_pkg::sf_rsp_t  rsp;
  logic                    busy;
  logic [SP_PC_N*32-1:0]   perf;

  logic                    cm_en = 1'b0;
  logic [3:0]              cm_kind = '0, cm_dom = '0, cm_idx = '0, cm_port = '0;
  logic [63:0]             cm_base = '0, cm_size = '0;
  logic                    cm_r = 1'b0, cm_w = 1'b0;
  logic [15:0]             cm_allow = '0;
  logic [ND*NR-1:0]        t_valid, t_r, t_w, t_devn;
  logic [ND*NR*ADDR_W-1:0] t_base;
  logic [ND*NR*(ADDR_W+1)-1:0] t_end;
  logic [ND*NR*NP-1:0]     t_dev;
  logic [NP*ND-1:0]        t_allow;

  sf_memory_guard_regions #(.ND(ND), .NR(NR), .NP(NP), .AW(ADDR_W), .STRICT(0)) u_regs (
    .clk(clk), .rst_n(rst_n), .cm_en, .cm_kind, .cm_dom, .cm_idx, .cm_port, .cm_base, .cm_size, .cm_r, .cm_w,
    .cm_devn(1'b0), .cm_dev(8'd0), .cm_allow, .cm_ok(), .cm_err(),
    .rd_dom(4'd0), .rd_idx(4'd0), .rd_port(4'd0), .rd_valid(), .rd_base(), .rd_end(), .rd_r(), .rd_w(), .rd_devn(), .rd_dev(), .rd_allow(),
    .t_valid, .t_base, .t_end, .t_r, .t_w, .t_devn, .t_dev, .t_allow);

  // the adapter owns the output-buffer read port while it is busy
  logic [OBW-1:0] ad_ob_raddr;
  logic           ad_busy;
  assign obuf_raddr = ad_busy ? ad_ob_raddr : '0;

  sf_sparse_memory_engine #(.ADDR_W(ADDR_W), .OBUF_BYTES(OBUF_BYTES), .ND(ND), .NR(NR), .NP(NP), .PIDX(PIDX)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_i(cmd), .done_valid_o(done_valid), .done_ready_i(done_ready), .done_o(done),
    .cfg_max_out_i(8'd4), .cfg_merge_en_i(1'b1), .cfg_burst_en_i(1'b1),
    .ipush_valid_i(1'b0), .ipush_ready_o(ipush_ready), .ipush_data_i(32'd0),
    .ibuf_we_i(1'b0), .ibuf_waddr_i('0), .ibuf_wdata_i('0), .ibuf_wbe_i('0),
    .obuf_raddr_i(obuf_raddr), .obuf_rdata_o(obuf_rdata),
    .req_valid_o(req_valid), .req_ready_i(req_ready), .req_o(req), .rsp_valid_i(rsp_valid), .rsp_ready_o(rsp_ready), .rsp_i(rsp),
    .t_valid_i(t_valid), .t_base_i(t_base), .t_end_i(t_end), .t_r_i(t_r), .t_w_i(t_w), .t_devn_i(t_devn), .t_dev_i(t_dev), .t_allow_i(t_allow),
    .busy_o(busy), .perf_o(perf), .perf_clear_i(1'b0));

  // ------------------------------------------------------------------ simple in-order ALP memory (latency 3)
  logic [127:0] mem [longint unsigned];
  typedef struct { bit wr; longint unsigned beat; logic [15:0] be; logic [127:0] wd; logic [7:0] tag; int due; } mq_t;
  mq_t mq [$];
  int  now_c = 0;
  function automatic logic [127:0] bm(input logic [15:0] be);
    logic [127:0] m;
    for (int b = 0; b < 16; b++) m[b*8 +: 8] = {8{be[b]}};
    return m;
  endfunction
  always @(posedge clk) begin
    now_c++;
    rsp_valid <= 1'b0;
    if (rst_n) begin
      if (req_valid && req_ready) begin
        mq_t e;
        e.wr = (req.op == sf_albion_pkg::SF_OP_WRITE); e.beat = longint'(req.addr[63:4]); e.be = req.be; e.wd = req.data;
        e.tag = req.tag; e.due = now_c + 3;
        mq.push_back(e);
      end
      if (mq.size() > 0 && mq[0].due <= now_c + 1 && !(rsp_valid && !rsp_ready)) begin
        automatic mq_t e = mq.pop_front();
        automatic sf_albion_pkg::sf_rsp_t r = '0;
        r.tag = e.tag; r.meta.last = 1'b1; r.meta.is_write = e.wr;
        if (e.wr) mem[e.beat] = ((mem.exists(e.beat) ? mem[e.beat] : 128'd0) & ~bm(e.be)) | (e.wd & bm(e.be));
        else      r.data = (mem.exists(e.beat) ? mem[e.beat] : 128'd0) & bm(e.be);
        rsp <= r; rsp_valid <= 1'b1;
      end
    end else mq.delete();
  end

  // ------------------------------------------------------------------ TensorScratch + adapter
  logic        dma_req_valid, dma_req_ready, dma_req_we;
  logic [31:0] dma_req_addr, dma_req_wdata;
  logic [3:0]  dma_req_wstrb;
  logic [7:0]  dma_req_tag;
  logic        dma_rsp_valid, dma_rsp_err, dma_rsp_we, dma_rsp_ready;
  logic [31:0] dma_rsp_rdata;
  logic [2:0]  dma_rsp_err_code;
  logic [7:0]  dma_rsp_tag;
  logic        fill_begin_valid, fill_begin_ready, fill_end_valid, fill_end_ready;
  logic        cmp_begin_valid = 1'b0, cmp_begin_ready, cmp_end_valid = 1'b0, cmp_end_ready;
  logic [0:0]  fill_set, cmp_set;
  logic [3:0]  set_state;
  logic        tile_valid = 1'b0, tile_ready;
  logic [31:0] tile_a_addr = 0, tile_lda = 8, tile_b_addr = 0, tile_ldb = 4;
  logic [15:0] tile_m0 = 0, tile_n0 = 0, tile_mat_m = MDIM, tile_mat_n = NDIM;
  logic [16:0] tile_k0 = 0, tile_mat_k = KDIM, tile_k = KDIM;
  logic [7:0]  tile_tag = 8'h5A;
  logic        tile_rsp_valid, tile_rsp_err;
  logic [3:0]  tile_rsp_code;
  logic        s_valid, s_ready = 1'b1;
  logic [31:0] s_a, s_b;
  logic [16:0] s_k, s_kg;
  logic [15:0] s_m0, s_n0;
  logic [3:0]  s_row_mask, s_col_mask;
  logic        s_first, s_last;
  logic [7:0]  s_tag;
  logic [0:0]  s_set;
  logic        ts_busy, ts_idle;
  localparam int NSLOT = 7;
  logic [131:0] acc_st_rd_data, ext_rsp_rdata;
  logic [NSLOT*2-1:0] acc_slot_state;
  logic [3:0]  acc_viol;
  logic [29*8-1:0] ev_inc;
  logic [29*32-1:0] perf_cnt;
  logic [3:0]  set_state_seen;                                   // what the adapter is shown (can be forced)
  logic [3:0]  set_state_force = '0;
  logic        force_en = 1'b0;
  assign set_state_seen = force_en ? set_state_force : set_state;

  sf_tensor_scratchpad dut_ts (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(dma_req_valid), .dma_req_ready(dma_req_ready), .dma_req_we(dma_req_we), .dma_req_addr(dma_req_addr),
    .dma_req_wdata(dma_req_wdata), .dma_req_wstrb(dma_req_wstrb), .dma_req_tag(dma_req_tag), .dma_rsp_valid(dma_rsp_valid),
    .dma_rsp_ready(dma_rsp_ready), .dma_rsp_rdata(dma_rsp_rdata), .dma_rsp_err(dma_rsp_err), .dma_rsp_err_code(dma_rsp_err_code),
    .dma_rsp_we(dma_rsp_we), .dma_rsp_tag(dma_rsp_tag),
    .fill_begin_valid(fill_begin_valid), .fill_begin_ready(fill_begin_ready), .fill_end_valid(fill_end_valid), .fill_end_ready(fill_end_ready),
    .cmp_begin_valid(cmp_begin_valid), .cmp_begin_ready(cmp_begin_ready), .cmp_end_valid(cmp_end_valid), .cmp_end_ready(cmp_end_ready),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(set_state),
    .tile_valid(tile_valid), .tile_ready(tile_ready), .tile_a_addr(tile_a_addr), .tile_lda(tile_lda), .tile_b_addr(tile_b_addr), .tile_ldb(tile_ldb),
    .tile_m0(tile_m0), .tile_n0(tile_n0), .tile_k0(tile_k0), .tile_mat_m(tile_mat_m), .tile_mat_n(tile_mat_n), .tile_mat_k(tile_mat_k),
    .tile_k(tile_k), .tile_tag(tile_tag),
    .tile_rsp_valid(tile_rsp_valid), .tile_rsp_ready(1'b1), .tile_rsp_tag(), .tile_rsp_err(tile_rsp_err), .tile_rsp_code(tile_rsp_code),
    .tile_rsp_m(), .tile_rsp_n(), .tile_rsp_k(),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0),
    .s_row_mask(s_row_mask), .s_col_mask(s_col_mask), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .acc_st_en(1'b1), .acc_st_rd_req(1'b0), .acc_st_rd_addr('0), .acc_st_rd_ready(), .acc_st_rd_data(acc_st_rd_data),
    .acc_st_wr_req(1'b0), .acc_st_wr_addr('0), .acc_st_wr_data('0), .acc_st_wr_ready(),
    .acc_claim_valid(1'b0), .acc_claim_ready(), .acc_claim_slot('0), .acc_complete_valid(1'b0), .acc_complete_slot('0),
    .acc_release_valid(1'b0), .acc_release_slot('0), .acc_slot_state(acc_slot_state),
    .ext_req_valid(1'b0), .ext_req_ready(), .ext_req_we(1'b0), .ext_req_slot('0), .ext_req_row('0), .ext_req_wdata('0),
    .ext_rsp_valid(), .ext_rsp_ready(1'b1), .ext_rsp_rdata(ext_rsp_rdata), .ext_rsp_we(), .ext_rsp_err(), .ext_rsp_code(),
    .acc_viol_sticky(acc_viol), .busy(ts_busy), .engine_idle(ts_idle), .ev_inc(ev_inc), .perf_clear(1'b0), .perf_cnt(perf_cnt));

  logic ad_go = 1'b0, own_chk = 1'b1, par_chk = 1'b1;
  logic [12:0] a_so, b_so;
  logic [15:0] a_rows = 0, a_rb = 0, a_sp = 0, a_do = 0, a_dp = 0, b_rows = 0, b_rb = 0, b_sp = 0, b_do = 0, b_dp = 0;
  logic        ad_done, ad_err;
  logic [2:0]  ad_code;
  logic [31:0] ad_words;
  logic        a_dma_valid, a_dma_we;
  logic [31:0] a_dma_addr, a_dma_wdata;
  logic [3:0]  a_dma_wstrb;
  logic [7:0]  a_dma_tag;

  sf_sparse_tensor_adapter #(.OBUF_BYTES(OBUF_BYTES), .WB(4), .TS_ADDR_W(32), .TS_TAG_W(8), .NSETS(2), .A_SET_BYTES(4096), .B_SET_BYTES(4096)) u_ad (
    .clk_i(clk), .rst_ni(rst_n), .go_i(ad_go), .own_check_en_i(own_chk), .param_check_en_i(par_chk),
    .a_src_off_i(a_so), .a_rows_i(a_rows), .a_row_bytes_i(a_rb), .a_src_pitch_i(a_sp), .a_dst_off_i(a_do), .a_dst_pitch_i(a_dp),
    .b_src_off_i(b_so), .b_rows_i(b_rows), .b_row_bytes_i(b_rb), .b_src_pitch_i(b_sp), .b_dst_off_i(b_do), .b_dst_pitch_i(b_dp),
    .busy_o(ad_busy), .done_o(ad_done), .err_o(ad_err), .err_code_o(ad_code), .words_o(ad_words),
    .ob_raddr_o(ad_ob_raddr), .ob_rdata_i(obuf_rdata),
    .dma_req_valid_o(a_dma_valid), .dma_req_ready_i(dma_req_ready), .dma_req_we_o(a_dma_we), .dma_req_addr_o(a_dma_addr),
    .dma_req_wdata_o(a_dma_wdata), .dma_req_wstrb_o(a_dma_wstrb), .dma_req_tag_o(a_dma_tag),
    .dma_rsp_valid_i(dma_rsp_valid), .dma_rsp_ready_o(dma_rsp_ready), .dma_rsp_err_i(dma_rsp_err), .dma_rsp_err_code_i(dma_rsp_err_code),
    .fill_begin_valid_o(fill_begin_valid), .fill_begin_ready_i(fill_begin_ready), .fill_end_valid_o(fill_end_valid),
    .fill_end_ready_i(fill_end_ready), .fill_set_i(fill_set), .set_state_i(set_state_seen));
  assign dma_req_valid = a_dma_valid;
  assign dma_req_we = a_dma_we; assign dma_req_addr = a_dma_addr; assign dma_req_wdata = a_dma_wdata;
  assign dma_req_wstrb = a_dma_wstrb; assign dma_req_tag = a_dma_tag;

  // ------------------------------------------------------------------ bookkeeping
  int errors = 0, checks = 0;
  int ts_writes = 0;                 // write requests that reached the scratchpad
  always @(posedge clk) if (rst_n && dma_req_valid && dma_req_ready) ts_writes++;
  int begin_pulses = 0;
  int last_fill_set = 0;                                     // set the scratchpad granted for the most recent fill
  always @(posedge clk) if (rst_n && fill_begin_valid && fill_begin_ready) begin
    @(posedge clk); last_fill_set = int'(fill_set);
  end
  always @(posedge clk) if (rst_n && fill_begin_valid && fill_begin_ready) begin_pulses++;

  logic signed [7:0] expA [2][MDIM][KDIM];      // [set]
  logic signed [7:0] expB [2][KDIM][NDIM];
  int nslice [2];
  always @(posedge clk) if (rst_n && s_valid && s_ready) begin
    for (int i = 0; i < MDIM; i++) begin
      checks++;
      if ($signed(s_a[i*8 +: 8]) !== expA[s_set][i][s_k]) begin errors++; $display("A MISMATCH set=%0d k=%0d m=%0d got %0d exp %0d", s_set, s_k, i, $signed(s_a[i*8+:8]), expA[s_set][i][s_k]); end
    end
    for (int j = 0; j < NDIM; j++) begin
      checks++;
      if ($signed(s_b[j*8 +: 8]) !== expB[s_set][s_k][j]) begin errors++; $display("B MISMATCH set=%0d k=%0d n=%0d got %0d exp %0d", s_set, s_k, j, $signed(s_b[j*8+:8]), expB[s_set][s_k][j]); end
    end
    nslice[s_set]++;
  end

  logic [31:0] rng = 32'hC0FFEE11;
  function automatic int rnd(input int n);
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    return int'(rng % 32'(n));
  endfunction

  logic signed [7:0] tblA [128][KDIM];
  logic signed [7:0] tblB [128][NDIM];
  int idxA [MDIM], idxB [KDIM];

  task automatic put_byte(input longint unsigned addr, input logic [7:0] v);
    logic [127:0] w;
    longint unsigned beat = addr >> 4;
    int lane = int'(addr & 15);
    w = mem.exists(beat) ? mem[beat] : 128'd0;
    w[lane*8 +: 8] = v;
    mem[beat] = w;
  endtask
  task automatic put_u32(input longint unsigned addr, input logic [31:0] v);
    for (int i = 0; i < 4; i++) put_byte(addr + i, v[i*8 +: 8]);
  endtask

  task automatic guard_cmd(input logic [3:0] kind, input int dom, input int idx, input int port, input longint unsigned base,
                           input longint unsigned size, input int r, input int w, input int allow);
    @(negedge clk);
    cm_en = 1'b1; cm_kind = kind; cm_dom = 4'(dom); cm_idx = 4'(idx); cm_port = 4'(port); cm_base = 64'(base); cm_size = 64'(size);
    cm_r = r[0]; cm_w = w[0]; cm_allow = 16'(allow);
    @(negedge clk); cm_en = 1'b0;
  endtask

  task automatic run_cmd(input sf_sp_cmd_t c);
    int t = 0;
    @(negedge clk); cmd = c; cmd_valid = 1'b1;
    while (!cmd_ready) @(negedge clk);
    @(negedge clk); cmd_valid = 1'b0;
    while (!done_valid) begin @(posedge clk); if (++t > 20000) begin errors++; $display("engine watchdog"); break; end end
    #1;
    if (done.fault != SP_F_NONE) begin errors++; $display("engine fault %0d", done.fault); end
    @(negedge clk); done_ready = 1'b1; @(negedge clk); done_ready = 1'b0;
    repeat (3) @(posedge clk);
  endtask

  // build a random A (MDIM x KDIM) and B (KDIM x NDIM) tile by gathering table rows with the engine; returns the chosen rows
  logic signed [7:0] curA [MDIM][KDIM];
  logic signed [7:0] curB [KDIM][NDIM];
  task automatic commit_expect(input int set_idx);
    expA[set_idx] = curA;
    expB[set_idx] = curB;
  endtask
  task automatic gather_tile(input int unused_set);
    sf_sp_cmd_t c;
    for (int i = 0; i < MDIM; i++) begin idxA[i] = rnd(128); put_u32(IDX_A + 4*i, 32'(idxA[i])); end
    for (int k = 0; k < KDIM; k++) begin idxB[k] = rnd(128); put_u32(IDX_B + 4*k, 32'(idxB[k])); end
    c = '0; c.op = SP_OP_GATHER; c.cacheable = 1'b1; c.idx_w = 2'd2; c.base = SP_ADDR_W'(A_TBL); c.idx_base = SP_ADDR_W'(IDX_A);
    c.n = 32'(MDIM); c.elem_bytes = 12'(KDIM); c.dst_off = 20'd0; c.tid = 16'h00A1;
    run_cmd(c);
    c = '0; c.op = SP_OP_GATHER; c.cacheable = 1'b1; c.idx_w = 2'd2; c.base = SP_ADDR_W'(B_TBL); c.idx_base = SP_ADDR_W'(IDX_B);
    c.n = 32'(KDIM); c.elem_bytes = 12'(NDIM); c.dst_off = 20'd64; c.tid = 16'h00B1;
    run_cmd(c);
    for (int i = 0; i < MDIM; i++) for (int k = 0; k < KDIM; k++) curA[i][k] = tblA[idxA[i]][k];
    for (int k = 0; k < KDIM; k++) for (int j = 0; j < NDIM; j++) curB[k][j] = tblB[idxB[k]][j];
  endtask

  task automatic adapter_fields(input bit a_en, input bit b_en);
    a_so = 13'd0;  a_rows = a_en ? 16'(MDIM) : 16'd0; a_rb = 16'(KDIM); a_sp = 16'(KDIM); a_do = 16'd0; a_dp = 16'(KDIM);
    b_so = 13'd64; b_rows = b_en ? 16'(KDIM) : 16'd0; b_rb = 16'(NDIM); b_sp = 16'(NDIM); b_do = 16'd0; b_dp = 16'(NDIM);
  endtask
  task automatic adapter_pulse();
    @(negedge clk); ad_go = 1'b1; @(negedge clk); ad_go = 1'b0;
  endtask
  task automatic adapter_go(input bit a_en, input bit b_en);
    adapter_fields(a_en, b_en);
    adapter_pulse();
  endtask
  task automatic wait_adapter(input int limit, output bit ok);
    int t = 0;
    ok = 1'b0;
    while (t < limit) begin
      @(posedge clk); t++;
      if (ad_done) begin ok = 1'b1; if (!ad_err) commit_expect(last_fill_set); break; end
    end
  endtask
  task automatic ts_cmp_begin();
    @(negedge clk); cmp_begin_valid = 1'b1; @(posedge clk); while (!cmp_begin_ready) @(posedge clk); @(negedge clk); cmp_begin_valid = 1'b0;
  endtask
  task automatic ts_cmp_end();
    @(negedge clk); cmp_end_valid = 1'b1; @(posedge clk); while (!cmp_end_ready) @(posedge clk); @(negedge clk); cmp_end_valid = 1'b0;
  endtask
  task automatic ts_tile();
    @(negedge clk); tile_valid = 1'b1; @(posedge clk); while (!tile_ready) @(posedge clk); @(negedge clk); tile_valid = 1'b0;
  endtask
  task automatic expect_ok(input string what, input bit ok);
    if (!ok) begin errors++; $display("FAIL: %s did not complete", what); end
    else if (ad_err) begin errors++; $display("FAIL: %s reported error %0d", what, ad_code); end
  endtask

  initial begin
    bit ok;
    int w0, w1;
    int sl0, sl1;
    // memory contents: A table (128 rows x 8 B) and B table (128 rows x 4 B)
    for (int r = 0; r < 128; r++) begin
      for (int k = 0; k < KDIM; k++) begin tblA[r][k] = $signed(8'(rnd(256))); put_byte(A_TBL + r*KDIM + k, tblA[r][k]); end
      for (int j = 0; j < NDIM; j++) begin tblB[r][j] = $signed(8'(rnd(256))); put_byte(B_TBL + r*NDIM + j, tblB[r][j]); end
    end
    repeat (4) @(posedge clk); rst_n = 1'b1; repeat (3) @(posedge clk);
    guard_cmd(sf_memory_guard_pkg::CMD_SET_REGION, 0, 0, 0, 64'h10000, 64'h20000, 1, 1, 0);
    guard_cmd(sf_memory_guard_pkg::CMD_SET_REGION, 0, 1, 0, 64'h30000, 64'h1000, 1, 1, 0);
    guard_cmd(sf_memory_guard_pkg::CMD_BIND_PORT, 0, 0, PIDX, 0, 0, 0, 0, 1);

    // ===== 1. one tile: gather -> adapter -> scratchpad -> slice stream
    $display("--- test 1: single tile");
    gather_tile(0);
    adapter_go(1, 1);
    wait_adapter(4000, ok); expect_ok("tile 1 transfer", ok);
    if (ad_words != 32'(MDIM*KDIM/4 + KDIM*NDIM/4)) begin errors++; $display("FAIL: words=%0d", ad_words); end
    ts_cmp_begin(); ts_tile(); repeat (80) @(posedge clk);
    if (nslice[0] != KDIM) begin errors++; $display("FAIL: tile 1 delivered %0d slices (expected %0d)", nslice[0], KDIM); end
    ts_cmp_end(); repeat (4) @(posedge clk);

    // ===== 2. ping-pong: fill the other set while this one is consumed (slow consumer)
    $display("--- test 2: fill while a tile is being consumed");
    gather_tile(0);
    adapter_go(1, 1); wait_adapter(4000, ok); expect_ok("tile 2 fill", ok);        // set X
    nslice[0] = 0; nslice[1] = 0;
    s_ready = 1'b0;
    ts_cmp_begin(); ts_tile();
    repeat (10) @(posedge clk);
    // tile 2's data goes to the OTHER set while tile 1 is IN_USE (its slices are held by s_ready = 0)
    begin
      int cur;
      cur = int'(cmp_set);
      gather_tile(0);
      w0 = ts_writes;
      adapter_go(1, 1); wait_adapter(4000, ok); expect_ok("tile 3 fill (other set)", ok);
      if (ts_writes - w0 != MDIM*KDIM/4 + KDIM*NDIM/4) begin errors++; $display("FAIL: write count"); end
      s_ready = 1'b1;
      repeat (80) @(posedge clk);
      if (nslice[cur] != KDIM) begin errors++; $display("FAIL: tile in use delivered %0d slices", nslice[cur]); end
      ts_cmp_end(); repeat (4) @(posedge clk);
      // the second tile is now READY in the other set: consume it
      ts_cmp_begin(); ts_tile(); repeat (80) @(posedge clk);
      if (nslice[1-cur] != KDIM) begin errors++; $display("FAIL: second tile delivered %0d slices", nslice[1-cur]); end
      ts_cmp_end(); repeat (4) @(posedge clk);
    end

    // ===== 3. both sets busy: the adapter must wait and write nothing
    $display("--- test 3: no free set");
    gather_tile(0);
    adapter_go(1, 1); wait_adapter(4000, ok); expect_ok("fill A", ok);              // set -> READY
    ts_cmp_begin();                                                                   // -> IN_USE
    gather_tile(1);
    adapter_go(1, 1); wait_adapter(4000, ok); expect_ok("fill B", ok);              // other set -> READY
    // now: one IN_USE, one READY: no FREE set
    gather_tile(0);
    w0 = ts_writes;
    adapter_go(1, 1);
    repeat (300) @(posedge clk);
    if (!ad_busy || ts_writes != w0) begin errors++; $display("FAIL: adapter wrote while no set was free (writes %0d)", ts_writes - w0); end
    ts_cmp_end(); repeat (4) @(posedge clk);                                         // frees one set
    wait_adapter(4000, ok); expect_ok("fill C after a set was freed", ok);
    // drain: consume whatever is READY
    for (int n = 0; n < 2; n++) begin ts_cmp_begin(); ts_tile(); repeat (60) @(posedge clk); ts_cmp_end(); repeat (4) @(posedge clk); end

    // ===== 4. invalid parameters: rejected with no side effect on the scratchpad
    $display("--- test 4: parameter validation");
    begin
      int bp0;
      bp0 = begin_pulses;
      w0 = ts_writes;
      adapter_fields(1, 1); b_rb = 16'd3;                              // not a multiple of the scratchpad word
      adapter_pulse(); wait_adapter(100, ok);
      if (!ok || !ad_err || ad_code != 3'd1) begin errors++; $display("FAIL: bad row_bytes not rejected (ok=%0b err=%0b code=%0d)", ok, ad_err, ad_code); end
      adapter_fields(1, 1); a_dp = 16'd10;                             // pitch not word aligned
      adapter_pulse(); wait_adapter(100, ok);
      if (!ok || !ad_err || ad_code != 3'd1) begin errors++; $display("FAIL: bad dst_pitch not rejected"); end
      adapter_fields(1, 0); a_dp = 16'd4;                              // pitch smaller than the row
      adapter_pulse(); wait_adapter(100, ok);
      if (!ok || !ad_err || ad_code != 3'd1) begin errors++; $display("FAIL: dst_pitch < row_bytes not rejected"); end
      adapter_fields(1, 0); a_rows = 16'd10000;                        // beyond the output buffer and the set
      adapter_pulse(); wait_adapter(100, ok);
      if (!ok || !ad_err || ad_code != 3'd1) begin errors++; $display("FAIL: oversized tile not rejected"); end
      adapter_fields(0, 0);                                            // empty command
      adapter_pulse(); wait_adapter(100, ok);
      if (!ok || !ad_err || ad_code != 3'd1) begin errors++; $display("FAIL: empty command not rejected"); end
      if (ts_writes != w0 || begin_pulses != bp0) begin errors++; $display("FAIL: a rejected command touched the scratchpad"); end
    end

    // ===== 5. ownership guard: a set that is not FILLING receives no write
    $display("--- test 5: ownership guard");
    begin
      gather_tile(0);
      w0 = ts_writes;
      force_en = 1'b1; set_state_force = 4'b1111;            // the adapter is told both sets are IN_USE
      adapter_go(1, 1); wait_adapter(4000, ok);
      force_en = 1'b0;
      if (!ok || !ad_err || ad_code != 3'd2) begin errors++; $display("FAIL: ownership guard (ok=%0b err=%0b code=%0d)", ok, ad_err, ad_code); end
      if (ts_writes != w0) begin errors++; $display("FAIL: write issued to a set that was not FILLING"); end
      ts_cmp_begin(); ts_cmp_end(); repeat (4) @(posedge clk);                       // release the (empty) set the failed fill left READY
    end

    // ===== 6. scratchpad-side errors, provoked with the adapter's own checks switched off
    $display("--- test 6: scratchpad-side errors");
    begin
      // 6a. RANGE: a destination beyond the scratchpad window
      gather_tile(0);
      par_chk = 1'b0;
      adapter_fields(1, 0); a_do = 16'd20000;
      adapter_pulse(); wait_adapter(4000, ok); par_chk = 1'b1;
      if (!ok || !ad_err || ad_code != 3'd3) begin errors++; $display("FAIL: RANGE error not reported (ok=%0b err=%0b code=%0d)", ok, ad_err, ad_code); end
      ts_cmp_begin(); ts_cmp_end(); repeat (4) @(posedge clk);
      // 6b. ALIGN: a destination that is not word aligned
      gather_tile(0);
      par_chk = 1'b0;
      adapter_fields(1, 0); a_do = 16'd6;
      adapter_pulse(); wait_adapter(4000, ok); par_chk = 1'b1;
      if (!ok || !ad_err || ad_code != 3'd4) begin errors++; $display("FAIL: ALIGN error not reported (ok=%0b err=%0b code=%0d)", ok, ad_err, ad_code); end
      ts_cmp_begin(); ts_cmp_end(); repeat (4) @(posedge clk);
      // 6c. OWNER: while filling set 0, aim the writes at set 1, which holds a READY tile.  The scratchpad must
      //     refuse them and the tile in set 1 must be delivered intact.
      while (last_fill_set != 0) begin                                  // park the grant pointer: the next two grants are set 1, then set 0
        gather_tile(0); adapter_go(1, 1); wait_adapter(4000, ok); expect_ok("parking fill", ok);
        ts_cmp_begin(); ts_cmp_end(); repeat (4) @(posedge clk);
      end
      gather_tile(0);
      adapter_go(1, 1); wait_adapter(4000, ok); expect_ok("protected tile fill", ok);
      if (last_fill_set != 1) begin errors++; $display("FAIL: test 6c expected the protected tile in set 1, got set %0d", last_fill_set); end
      gather_tile(0);
      own_chk = 1'b0; par_chk = 1'b0;
      adapter_fields(1, 0); a_do = 16'd4096;                             // set 1's A region, while set 0 is being filled
      adapter_pulse(); wait_adapter(4000, ok); own_chk = 1'b1; par_chk = 1'b1;
      if (!ok || !ad_err || ad_code != 3'd2) begin errors++; $display("FAIL: scratchpad OWNER refusal not reported (ok=%0b err=%0b code=%0d)", ok, ad_err, ad_code); end
      // consume both READY sets: the protected tile must still match, the half-filled set is not consumed
      for (int n = 0; n < 2; n++) begin
        nslice[0] = 0; nslice[1] = 0;
        ts_cmp_begin();
        if (cmp_set == 1'b1) begin
          ts_tile(); repeat (80) @(posedge clk);
          if (nslice[1] != KDIM) begin errors++; $display("FAIL: protected tile delivered %0d slices after the refused writes", nslice[1]); end
        end
        ts_cmp_end(); repeat (4) @(posedge clk);
      end
      // the adapter is usable afterwards
      gather_tile(0);
      adapter_go(1, 1); wait_adapter(4000, ok); expect_ok("transfer after errors", ok);
      nslice[0] = 0; nslice[1] = 0;
      ts_cmp_begin(); ts_tile(); repeat (80) @(posedge clk);
      if (nslice[0] + nslice[1] != KDIM) begin errors++; $display("FAIL: tile after errors delivered %0d slices", nslice[0] + nslice[1]); end
      ts_cmp_end(); repeat (4) @(posedge clk);
    end

    // ===== 7. random tiles, back to back
    $display("--- test 7: 40 random tiles");
    for (int n = 0; n < 40; n++) begin
      gather_tile(0);
      adapter_go(1, 1); wait_adapter(4000, ok); expect_ok($sformatf("random tile %0d", n), ok);
      nslice[0] = 0; nslice[1] = 0;
      s_ready = (n % 3 != 0);
      ts_cmp_begin(); ts_tile(); repeat (20) @(posedge clk); s_ready = 1'b1; repeat (70) @(posedge clk);
      if (nslice[0] + nslice[1] != KDIM) begin errors++; $display("FAIL: random tile %0d delivered %0d slices", n, nslice[0] + nslice[1]); end
      ts_cmp_end(); repeat (3) @(posedge clk);
    end

    $display("ADAPTER checks=%0d errors=%0d ts_writes=%0d", checks, errors, ts_writes);
    if (errors == 0) $display("ADAPTER_ALL_PASS"); else $display("ADAPTER_FAILED");
    $finish;
  end
  initial begin #50ms; $display("ADAPTER_FAILED (global watchdog)"); $finish; end
endmodule

`default_nettype wire
