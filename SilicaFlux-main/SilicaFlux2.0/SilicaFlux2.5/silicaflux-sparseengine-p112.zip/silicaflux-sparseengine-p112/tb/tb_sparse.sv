// =============================================================================
//  tb_sparse.sv -- self-checking, scenario-driven testbench for sf_sparse_memory_engine
//
//  Scenarios come from model/gen_scenarios.py (text tokens, see docs/06_verification.md).
//  Expected results are computed by the independent Python model; this bench
//  only executes and compares:
//    * completion record (fault, guard fault, ALP status, element, address, count, tid)
//    * output-buffer bytes: bytes the command must write equal the expected data,
//      every other byte equals its pre-command value
//    * the WHOLE memory image after the command (gather must not modify memory;
//      scatter must modify exactly the expected bytes)
//
//  Environment models:
//    * ALP v1 target, configurable latency / jitter / banks / back-pressure,
//      in-order or OUT-OF-ORDER completion, error injection per beat; writes take
//      effect at completion time, so an ordering bug in the engine changes the result
//    * MemoryGuard region table: the real sf_memory_guard_regions, programmed
//      through its command port
//    * link rules checked on every run: tag not reused while outstanding,
//      outstanding <= limit, request held until accepted (+ the ALP link checker
//      in in-order mode)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sparse;
  import sf_sparse_pkg::*;

  parameter int    ADDR_W         = 40;
  parameter int    NRT            = 16;
  parameter int    ROB_DEPTH      = 32;
  parameter int    IDX_NSLOT      = 4;
  parameter int    IDX_FIFO       = 4;
  parameter int    MAX_ELEM_BYTES = 256;
  parameter int    OBUF_BYTES     = 8192;
  parameter int    IBUF_BYTES     = 8192;
  parameter int    SPMV_ACC_W     = 32;
  parameter bit    SPMV_OVF_WRAP  = 1'b0;
  parameter bit    CSR_EN         = 1'b1;
  parameter bit    SPMV_EN        = 1'b1;
  parameter int    USE_CACHE      = 0;           // 1: CacheForge between the engine and the target model
  parameter int    CACHE_BYTES    = 32768;
  parameter int    CACHE_WAYS     = 4;
  parameter int    NUM_MSHR       = 1;
  parameter int    MEM_OUT_LIMIT  = 4;           // outstanding limit of the memory-side target (cache MEM_MAX_OUT)
  parameter int    ORD_CHECK      = 1;           // 1: ALP link checker (in-order targets only)
  parameter int    WATCHDOG       = 400000;      // cycles per scenario
  parameter string SCEN_FILE      = "scen.txt";

  localparam int ND = 4, NR = 4, NP = 4, PIDX = 3;
  localparam int OBW = $clog2(OBUF_BYTES/16);
  localparam int IBW = $clog2(IBUF_BYTES/16);
  localparam int PQ_N = 64;

  // ---------------------------------------------------------------- clock / reset
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT signals
  logic                    cmd_valid = 1'b0, cmd_ready;
  sf_sp_cmd_t              cmd;
  logic                    done_valid, done_ready = 1'b0;
  sf_sp_done_t             done;
  logic [7:0]              cfg_max_out = 8'd4;
  logic                    cfg_merge = 1'b1, cfg_burst = 1'b1;
  logic                    ipush_valid = 1'b0, ipush_ready;
  logic [31:0]             ipush_data = '0;
  logic                    ibuf_we = 1'b0;
  logic [IBW-1:0]          ibuf_waddr = '0;
  logic [127:0]            ibuf_wdata = '0;
  logic [15:0]             ibuf_wbe = '0;
  logic [OBW-1:0]          obuf_raddr = '0;
  logic [127:0]            obuf_rdata;
  // memory side (what the target model sees)
  logic                    req_valid, req_ready = 1'b0;
  sf_albion_pkg::sf_req_t  req;
  logic                    rsp_valid_r = 1'b0;
  wire                     rsp_valid = rsp_valid_r & rst_n;     // a target never shows a valid while reset is asserted
  logic                    rsp_ready;
  sf_albion_pkg::sf_rsp_t  rsp;
  // engine side
  logic                    e_req_valid, e_req_ready;
  sf_albion_pkg::sf_req_t  e_req;
  logic                    e_rsp_valid, e_rsp_ready;
  sf_albion_pkg::sf_rsp_t  e_rsp;
  logic                    busy;
  logic [SP_PC_N*32-1:0]   perf;
  logic                    perf_clear = 1'b0;

  // guard table
  logic                    cm_en = 1'b0;
  logic [3:0]              cm_kind = '0, cm_dom = '0, cm_idx = '0, cm_port = '0;
  logic [63:0]             cm_base = '0, cm_size = '0;
  logic                    cm_r = 1'b0, cm_w = 1'b0;
  logic [15:0]             cm_allow = '0;
  logic                    cm_ok;
  logic [3:0]              cm_err;
  logic [ND*NR-1:0]        t_valid, t_r, t_w, t_devn;
  logic [ND*NR*ADDR_W-1:0] t_base;
  logic [ND*NR*(ADDR_W+1)-1:0] t_end;
  logic [ND*NR*NP-1:0]     t_dev;
  logic [NP*ND-1:0]        t_allow;

  sf_memory_guard_regions #(.ND(ND), .NR(NR), .NP(NP), .AW(ADDR_W), .STRICT(0)) u_regs (
    .clk(clk), .rst_n(rst_n),
    .cm_en, .cm_kind, .cm_dom, .cm_idx, .cm_port, .cm_base, .cm_size, .cm_r, .cm_w,
    .cm_devn(1'b0), .cm_dev(8'd0), .cm_allow, .cm_ok, .cm_err,
    .rd_dom(4'd0), .rd_idx(4'd0), .rd_port(4'd0),
    .rd_valid(), .rd_base(), .rd_end(), .rd_r(), .rd_w(), .rd_devn(), .rd_dev(), .rd_allow(),
    .t_valid, .t_base, .t_end, .t_r, .t_w, .t_devn, .t_dev, .t_allow
  );

  sf_sparse_memory_engine #(
    .ADDR_W(ADDR_W), .NRT(NRT), .ROB_DEPTH(ROB_DEPTH), .IDX_NSLOT(IDX_NSLOT), .IDX_FIFO(IDX_FIFO),
    .MAX_ELEM_BYTES(MAX_ELEM_BYTES), .OBUF_BYTES(OBUF_BYTES), .IBUF_BYTES(IBUF_BYTES),
    .ND(ND), .NR(NR), .NP(NP), .PIDX(PIDX), .CNT_W(32),
    .SPMV_ACC_W(SPMV_ACC_W), .SPMV_OVF_WRAP(SPMV_OVF_WRAP), .CSR_EN(CSR_EN), .SPMV_EN(SPMV_EN)
  ) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_i(cmd),
    .done_valid_o(done_valid), .done_ready_i(done_ready), .done_o(done),
    .cfg_max_out_i(cfg_max_out), .cfg_merge_en_i(cfg_merge), .cfg_burst_en_i(cfg_burst),
    .ipush_valid_i(ipush_valid), .ipush_ready_o(ipush_ready), .ipush_data_i(ipush_data),
    .ibuf_we_i(ibuf_we), .ibuf_waddr_i(ibuf_waddr), .ibuf_wdata_i(ibuf_wdata), .ibuf_wbe_i(ibuf_wbe),
    .obuf_raddr_i(obuf_raddr), .obuf_rdata_o(obuf_rdata),
    .req_valid_o(e_req_valid), .req_ready_i(e_req_ready), .req_o(e_req),
    .rsp_valid_i(e_rsp_valid), .rsp_ready_o(e_rsp_ready), .rsp_i(e_rsp),
    .t_valid_i(t_valid), .t_base_i(t_base), .t_end_i(t_end), .t_r_i(t_r), .t_w_i(t_w),
    .t_devn_i(t_devn), .t_dev_i(t_dev), .t_allow_i(t_allow),
    .busy_o(busy), .perf_o(perf), .perf_clear_i(perf_clear)
  );


  // ---------------------------------------------------------------- optional CacheForge
  logic                    c_init_done, c_busy, c_proto_err;
  logic [63:0]             c_caps;
  logic                    cmo_valid = 1'b0, cmo_ready, cmo_done;
  logic [1:0]              cmo_op = 2'd0;
  logic [28*64-1:0]        c_perf;
  logic                    c_perf_clear = 1'b0;
  if (USE_CACHE != 0) begin : g_cache
    sf_llc_cache #(.CACHE_BYTES(CACHE_BYTES), .LINE_BYTES(64), .WAYS(CACHE_WAYS), .PADDR_W(ADDR_W), .NUM_MSHR(NUM_MSHR),
                   .MEM_MAX_OUT(MEM_OUT_LIMIT), .CNT_W(64)) u_cache (
      .clk_i(clk), .rst_ni(rst_n),
      .req_valid_i(e_req_valid), .req_ready_o(e_req_ready), .req_i(e_req),
      .rsp_valid_o(e_rsp_valid), .rsp_ready_i(e_rsp_ready), .rsp_o(e_rsp),
      .mreq_valid_o(req_valid), .mreq_ready_i(req_ready), .mreq_o(req),
      .mrsp_valid_i(rsp_valid), .mrsp_ready_o(rsp_ready), .mrsp_i(rsp),
      .cmo_valid_i(cmo_valid), .cmo_ready_o(cmo_ready), .cmo_op_i(cmo_op), .cmo_all_i(1'b1), .cmo_addr_i(64'd0),
      .cmo_size_i(64'd0), .cmo_busy_o(), .cmo_done_o(cmo_done), .cmo_lines_o(), .cmo_err_o(),
      .cfg_en_i(1'b1), .cfg_nc_en_i(1'b0), .cfg_nc_base_i(64'd0), .cfg_nc_limit_i(64'd0),
      .cfg_wb_dom_i(8'h01), .cfg_wb_attr_i(8'h04),
      .init_done_o(c_init_done), .busy_o(c_busy), .err_evt_o(), .err_sticky_o(), .err_clear_i(1'b0), .err_addr_o(),
      .perf_clear_i(c_perf_clear), .perf_o(c_perf), .caps_o(c_caps), .proto_err_o(c_proto_err)
    );
    // engine <-> cache link: ALP v1 rules (the cache is in order)
    sf_albion_link_checker #(.MAX_OUTSTANDING(32), .CHECK_LEGALITY(1'b1), .CHECK_LANES(1'b1)) u_elchk (
      .clk_i(clk), .rst_ni(rst_n), .req_valid_i(e_req_valid), .req_ready_i(e_req_ready), .req_i(e_req),
      .rsp_valid_i(e_rsp_valid), .rsp_ready_i(e_rsp_ready), .rsp_i(e_rsp), .waive_req_i(1'b0), .outstanding_o()
    );
  end else begin : g_nocache
    assign req_valid   = e_req_valid;
    assign e_req_ready = req_ready;
    assign req         = e_req;
    assign e_rsp_valid = rsp_valid;
    assign rsp_ready   = e_rsp_ready;
    assign e_rsp       = rsp;
    assign c_init_done = 1'b1;
    assign c_busy      = 1'b0;
    assign c_proto_err = 1'b0;
    assign c_caps      = 64'd0;
    assign cmo_ready   = 1'b0;
    assign cmo_done    = 1'b0;
    assign c_perf      = '0;
  end
  wire [7:0] cache_max_out = (USE_CACHE != 0) ? c_caps[23:16] : 8'd255;      // caps.max_outstanding

  // clean + invalidate the whole cache: memory becomes the truth, the cache empty (software-managed visibility)
  task automatic cache_flush();
    int t;
    if (USE_CACHE != 0) begin
      @(negedge clk);
      cmo_op = 2'd3;  cmo_valid = 1'b1;                       // CLEAN_INV, all
      t = 0;
      do begin @(posedge clk); t++; end while (!cmo_ready && t < 100000);
      @(negedge clk); cmo_valid = 1'b0;
      t = 0;
      while (!cmo_done && t < 200000) begin @(posedge clk); t++; end
      if (t >= 200000) begin scen_errors++; $display("FAIL[%s]: cache CMO never completed", scen_name); end
      repeat (4) @(posedge clk);
    end
  endtask

  // ---------------------------------------------------------------- link checkers
  logic [15:0] chk_out;
  if (ORD_CHECK != 0) begin : g_lchk
    sf_albion_link_checker #(.MAX_OUTSTANDING(32), .CHECK_LEGALITY(1'b1), .CHECK_LANES(1'b1)) u_lchk (
      .clk_i(clk), .rst_ni(rst_n), .req_valid_i(req_valid), .req_ready_i(req_ready), .req_i(req),
      .rsp_valid_i(rsp_valid), .rsp_ready_i(rsp_ready), .rsp_i(rsp), .waive_req_i(1'b0), .outstanding_o(chk_out)
    );
  end else begin : g_cchk
    assign chk_out = '0;
    sf_albion_chan_checker #(.WIDTH(sf_albion_pkg::SF_REQ_W)) u_rq_chan (
      .clk_i(clk), .rst_ni(rst_n), .valid_i(req_valid), .ready_i(req_ready), .payload_i(req), .waive_i(1'b0)
    );
  end
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_chk = |chk_out;
  /* verilator lint_on UNUSEDSIGNAL */

  // ---------------------------------------------------------------- scenario state
  typedef struct { int dom; int idx; longint unsigned base; longint unsigned size; int r; int w; } reg_t;

  string       scen_name;
  string       scen_path;
  int          k_lat, k_jit, k_ooo, k_banks, k_svc, k_rdy, k_rsp, k_seed, k_maxout, k_merge, k_burst, k_ipgap;
  int          allow_mask;
  reg_t        regs_q[$];
  logic [127:0] mem   [longint unsigned];
  logic [127:0] exp_mem [longint unsigned];
  logic [127:0] emem_over [longint unsigned];
  logic [127:0] ibuf_img [longint unsigned];
  int           err_beats [longint unsigned];
  logic [31:0]  ipush_q [$];
  logic [127:0] eob_data [longint unsigned];
  logic [15:0]  eob_mask [longint unsigned];
  sf_sp_cmd_t   cmd_s;
  int           exp_fault, exp_gfault, exp_status, exp_elems;
  longint unsigned exp_elem, exp_addr;
  int           exp_ovf;
  bit           nomem;           // do not compare the memory image / output buffer (timing-dependent outcome)
  bit           cont_mode;       // scenario continues the previous one: no reset, memory kept
  int           mid_reset;       // >= 0: assert reset this many cycles after the command was issued
  bit           rogue_en;        // scenario injects one response that answers no request
  bit           rogue_armed;     // ... and has not done so yet
  logic [7:0]   rogue_tag;
  int           rogue_delay;     // cycles after the first data-source request is accepted
  int           st_perm_err;     // link bytes outside every permitted region (monitor below)

  int total_pass = 0, total_fail = 0;
  int scen_errors;

  // ---------------------------------------------------------------- xorshift RNG
  logic [31:0] rng_q = 32'h1234_5678;
  function automatic logic [31:0] rnd();
    logic [31:0] x;
    x = rng_q;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    rng_q = x;
    return x;
  endfunction
  function automatic int rnd_range(input int lo, input int hi);   // inclusive
    if (hi <= lo) return lo;
    return lo + int'(rnd() % 32'(hi - lo + 1));
  endfunction

  // ---------------------------------------------------------------- ALP target model
  typedef struct {
    bit               v;
    bit               wr;
    longint unsigned  beat;
    logic [15:0]      be;
    logic [127:0]     wd;
    logic [7:0]       tag;
    longint unsigned  t_ready;
    longint unsigned  seq;
    bit               rogue;      // an injected response that answers no request (protocol-violation test)
  } pend_t;
  pend_t           pq [PQ_N];
  longint unsigned now_c, acc_seq, bank_free [64];
  int              outst_c, sent_idx;
  int              st_ooo_resp, st_bank_conf, st_max_out, st_reqs, st_tag_err, st_out_err, st_waw_err;
  bit [255:0]      tag_busy;
  bit              rsp_pending;      // a response is on the bus (valid, not yet taken)
  longint unsigned rsp_seq_c;

  task automatic mm_reset();
    for (int i = 0; i < PQ_N; i++) pq[i].v = 1'b0;
    now_c = 0; acc_seq = 0; outst_c = 0; sent_idx = -1; rsp_pending = 1'b0; tag_busy = '0; rsp_seq_c = 0;
    for (int i = 0; i < 64; i++) bank_free[i] = 0;
    st_ooo_resp = 0; st_bank_conf = 0; st_max_out = 0; st_reqs = 0; st_tag_err = 0; st_out_err = 0; st_waw_err = 0;
  endtask

  function automatic logic [127:0] be_mask128(input logic [15:0] be);
    logic [127:0] m;
    for (int b = 0; b < 16; b++) m[b*8 +: 8] = {8{be[b]}};
    return m;
  endfunction

  always @(posedge clk) begin
    if (!rst_n) begin
      rsp_valid_r <= 1'b0;
      req_ready <= 1'b0;
    end else begin
      automatic int          free_i = -1;
      automatic int          pick   = -1;
      automatic bit          rsp_taken = rsp_valid && rsp_ready;
      automatic longint unsigned best_t = 64'hFFFF_FFFF_FFFF_FFFF;
      automatic longint unsigned oldest_seq = 64'hFFFF_FFFF_FFFF_FFFF;
      now_c++;

      // ---- response handshake just completed
      if (rsp_taken) begin
        if (!pq[sent_idx].rogue) begin
          tag_busy[pq[sent_idx].tag] = 1'b0;
          outst_c--;
        end
        pq[sent_idx].v = 1'b0;
        pq[sent_idx].rogue = 1'b0;
        rsp_pending = 1'b0;
        sent_idx = -1;
      end

      // ---- request accepted
      if (req_valid && req_ready) begin
        for (int i = 0; i < PQ_N; i++) if (!pq[i].v && free_i < 0) free_i = i;
        if (free_i < 0) begin
          $display("FAIL[%s]: target model queue overflow", scen_name); st_out_err++;
        end else begin
          automatic longint unsigned lat_t;
          automatic longint unsigned beat_a;
          automatic int              bank;
          beat_a = longint'(req.addr[63:4]);
          lat_t  = now_c + longint'(k_lat) + longint'(rnd_range(0, k_jit));
          if (k_banks > 0) begin
            bank = int'(beat_a % longint'(k_banks));
            if (bank_free[bank] > now_c) st_bank_conf++;
            if (bank_free[bank] > lat_t) lat_t = bank_free[bank];
            bank_free[bank] = lat_t + longint'(k_svc);
          end
          if ((USE_CACHE == 0) && (req.op == sf_albion_pkg::SF_OP_WRITE)) begin
            for (int i = 0; i < PQ_N; i++)
              if (pq[i].v && pq[i].wr && pq[i].beat == beat_a) begin
                st_waw_err++; $display("FAIL[%s]: two writes to beat %0h in flight (write-after-write hazard)", scen_name, beat_a);
              end
          end
          pq[free_i].v = 1'b1;
          pq[free_i].wr = (req.op == sf_albion_pkg::SF_OP_WRITE);
          pq[free_i].beat = beat_a;
          pq[free_i].be = req.be;
          pq[free_i].wd = req.data;
          pq[free_i].tag = req.tag;
          pq[free_i].t_ready = lat_t;
          pq[free_i].seq = acc_seq++;
          pq[free_i].rogue = 1'b0;
          if (tag_busy[req.tag]) begin st_tag_err++; $display("FAIL[%s]: ALP-TAG-01 tag %0h reused while outstanding", scen_name, req.tag); end
          tag_busy[req.tag] = 1'b1;
          outst_c++;
          st_reqs++;
          if (outst_c > st_max_out) st_max_out = outst_c;
          if (outst_c > ((USE_CACHE != 0) ? MEM_OUT_LIMIT : int'(cfg_max_out))) begin st_out_err++; $display("FAIL[%s]: ALP-OUT-01 outstanding %0d > limit", scen_name, outst_c); end
          if (req.be == 16'd0 || req.addr[3:0] != 4'd0 || req.attr.rsvd) begin st_out_err++; $display("FAIL[%s]: illegal request on the link", scen_name); end
          // protocol-violation test: after the first data-source request, one extra response that answers nothing
          if (rogue_armed && req.tag[7:5] == 3'b000) begin
            automatic int rf = -1;
            for (int i = 0; i < PQ_N; i++) if (!pq[i].v && i != free_i && rf < 0) rf = i;
            if (rf >= 0) begin
              pq[rf].v = 1'b1; pq[rf].wr = 1'b0; pq[rf].beat = 64'd0; pq[rf].be = 16'd0; pq[rf].wd = 128'd0;
              pq[rf].tag = rogue_tag; pq[rf].t_ready = now_c + longint'(rogue_delay); pq[rf].seq = acc_seq++; pq[rf].rogue = 1'b1;
              rogue_armed = 1'b0;
            end
          end
        end
      end

      // ---- choose the next response (visible next cycle)
      if (!rsp_pending || rsp_taken) begin
        for (int i = 0; i < PQ_N; i++) begin
          if (pq[i].v && pq[i].seq < oldest_seq) oldest_seq = pq[i].seq;
        end
        for (int i = 0; i < PQ_N; i++) begin
          if (pq[i].v && pq[i].t_ready <= now_c + 1) begin
            if (k_ooo == 0) begin
              if (pq[i].seq == oldest_seq) pick = i;                      // strictly the oldest
            end else if (k_ooo == 1) begin
              if (pick < 0 || pq[i].t_ready < best_t ||
                  (pq[i].t_ready == best_t && pq[i].seq < pq[pick].seq)) begin pick = i; best_t = pq[i].t_ready; end
            end else begin
              if (pick < 0 || rnd_range(0, 1) == 1) pick = i;              // any ready request
            end
          end
        end
        if (pick >= 0 && rnd_range(0, 99) >= k_rsp) begin
          // effect and response data
          automatic sf_albion_pkg::sf_rsp_t r;
          automatic longint unsigned b;
          automatic int st;
          b  = pq[pick].beat;
          st = 0;
          r = '0;
          r.tag = pq[pick].tag;
          if (err_beats.exists(b)) st = err_beats[b];
          r.status = sf_albion_pkg::sf_status_t'(st);
          r.meta.last = 1'b1;
          r.meta.is_write = pq[pick].wr;
          r.meta.poisoned = (st == int'(sf_albion_pkg::SF_ST_ECC_UNCORR));   // ALP-RSP-05
          if (pq[pick].wr) begin
            if (st == 0) begin
              automatic logic [127:0] cur;
              cur = mem.exists(b) ? mem[b] : 128'd0;
              mem[b] = (cur & ~be_mask128(pq[pick].be)) | (pq[pick].wd & be_mask128(pq[pick].be));
            end
          end else if (st == 0) begin
            r.data = (mem.exists(b) ? mem[b] : 128'd0) & be_mask128(pq[pick].be);
          end
          if (pq[pick].seq != oldest_seq) st_ooo_resp++;
          rsp       <= r;
          rsp_valid_r <= 1'b1;
          rsp_pending = 1'b1;
          sent_idx  = pick;
        end else begin
          rsp_valid_r <= 1'b0;
        end
      end
      req_ready <= (rnd_range(0, 99) < k_rdy);
    end
  end


  // ---------------------------------------------------------------- link byte monitor
  // Independent of the engine's checker: every byte the engine puts on ITS OWN link (byte enable set) must lie inside a region of
  // the command's domain that allows the operation.  "Requested bytes = validated bytes" (docs/02 §3) is checked here at byte level.
  // It watches the engine's port (e_req_*), not the memory side of a cache: a cache refills whole lines below the interface.
  always @(posedge clk) begin
    if (rst_n && e_req_valid && e_req_ready) begin
      for (int b = 0; b < 16; b++) begin
        if (e_req.be[b]) begin
          automatic longint unsigned a  = {e_req.addr[63:4], 4'(b)};
          automatic bit              ok = 1'b0;
          foreach (regs_q[i]) begin
            if (regs_q[i].dom == int'(cmd_s.dom) && a >= regs_q[i].base && a < regs_q[i].base + regs_q[i].size &&
                ((e_req.op == sf_albion_pkg::SF_OP_WRITE) ? (regs_q[i].w != 0) : (regs_q[i].r != 0))) ok = 1'b1;
          end
          if (!ok) begin
            st_perm_err++;
            if (st_perm_err <= 4) $display("FAIL[%s]: link byte %0h (%s) is outside every permitted region", scen_name, a,
                                           (e_req.op == sf_albion_pkg::SF_OP_WRITE) ? "write" : "read");
          end
        end
      end
    end
  end

  // CSR walker interface invariant (docs/05 §6): an empty-row event is both the first and the last event of its row
  always @(posedge clk) if (rst_n && dut.wk_ev_valid && !dut.wk_ev_nz && !(dut.wk_ev_first && dut.wk_ev_last)) begin
    st_perm_err++; $display("FAIL[%s]: empty-row event without first/last", scen_name);
  end

  // ---------------------------------------------------------------- index push driver
  int push_ptr = 0;
  bit push_en  = 1'b0;
  always @(posedge clk) begin
    if (!rst_n || !push_en) begin
      ipush_valid <= 1'b0;
    end else begin
      automatic int ptr_n = push_ptr;
      if (ipush_valid && ipush_ready) ptr_n = push_ptr + 1;
      if (ipush_valid && !ipush_ready) begin
        // hold until accepted
      end else if (ptr_n < ipush_q.size() && rnd_range(0, 99) >= k_ipgap) begin
        ipush_valid <= 1'b1;
        ipush_data  <= ipush_q[ptr_n];
      end else begin
        ipush_valid <= 1'b0;
      end
      push_ptr <= ptr_n;
    end
  end


  // ---------------------------------------------------------------- optional debug trace (+dbg)
  bit dbg_en;
  initial dbg_en = $test$plusargs("dbg");
  always @(posedge clk) if (dbg_en && rst_n) begin
    if (dut.idx_valid && dut.idx_ready) $display("%0t IDX  val=%0h neg=%0b", $time, dut.idx_val, dut.idx_neg);
    if (dut.ea_valid && dut.ea_ready)   $display("%0t EA   idx=%0d addr=%0h flt=%0d permit=%0b", $time, dut.ea_idx, dut.ea_addr, dut.ea_fault, dut.chk_permit);
    if (dut.bd_valid && dut.bd_ready)   $display("%0t BD   beat=%0h lane=%0d be=%04h elem=%0d", $time, dut.bd_beat, dut.bd_lane, dut.bd_be, dut.bd_elem);
    if (req_valid && req_ready)         $display("%0t REQ  op=%0d tag=%02h addr=%0h be=%04h", $time, req.op, req.tag, req.addr, req.be);
    if (rsp_valid && rsp_ready)         $display("%0t RSP  tag=%02h st=%0d data=%032h", $time, rsp.tag, rsp.status, rsp.data);
    if (dut.wk_ix_valid)                $display("%0t WKIX col=%0d ready=%0b", $time, dut.wk_ix_data, dut.ib_push_ready);
    if (dut.wk_ev_valid)                $display("%0t WKEV nz=%0b first=%0b last=%0b val=%0h", $time, dut.wk_ev_nz, dut.wk_ev_first, dut.wk_ev_last, dut.wk_ev_val);
    if (dut.wk_flt_valid && !dut.flt_v_q) $display("%0t WKFLT code=%0d elem=%0d", $time, dut.wk_flt_code, dut.wk_flt_elem);
    if (dut.sp_y_valid)                 $display("%0t Y    row=%0d data=%0h", $time, dut.sp_y_row, dut.sp_y_data);
    if (dut.state_q == 3 && dut.run_idle) $display("%0t RUN_IDLE ib=%0b ag=%0b sp=%0b sg=%0b wk=%0b spm=%0b evf_ok=%0b co=%0b rob=%0b out=%0d", $time, dut.ib_busy, dut.ag_busy, dut.sp_busy, dut.sg_valid_q, dut.wk_busy, dut.spm_busy, dut.evf_ok, dut.co_empty, dut.rob_empty, dut.out_q);
    if (dut.dv_valid && dut.dv_ready)   $display("%0t DV   lane=%0d stat=%0d data=%032h wr_data=%0b optr=%0h", $time, dut.dv_lane, dut.dv_stat, dut.dv_data, dut.wr_data, dut.o_ptr_q);
  end

  // ---------------------------------------------------------------- host tasks
  task automatic do_reset();
    @(negedge clk);              // reset is asserted between clock edges (asynchronous assertion)
    rst_n = 1'b0;
    cmd_valid = 1'b0; done_ready = 1'b0; ipush_valid = 1'b0; ibuf_we = 1'b0;
    repeat (4) @(posedge clk);
    mm_reset();
    @(negedge clk);
    rst_n = 1'b1;
    repeat (2) @(posedge clk);
    if (USE_CACHE != 0) begin
      int t;
      t = 0;
      while (!c_init_done && t < 100000) begin @(posedge clk); t++; end
    end
  endtask

  task automatic guard_cmd(input logic [3:0] kind, input int dom, input int idx, input int port,
                           input longint unsigned base, input longint unsigned size, input int r, input int w, input int allow);
    @(negedge clk);
    cm_en = 1'b1; cm_kind = kind; cm_dom = 4'(dom); cm_idx = 4'(idx); cm_port = 4'(port);
    cm_base = 64'(base); cm_size = 64'(size); cm_r = r[0]; cm_w = w[0]; cm_allow = 16'(allow);
    #1;
    if (!cm_ok) begin
      $display("FAIL[%s]: guard command %0d rejected (err %0d)", scen_name, kind, cm_err);
      scen_errors++;
    end
    @(negedge clk);
    cm_en = 1'b0;
  endtask

  task automatic program_guard();
    guard_cmd(sf_memory_guard_pkg::CMD_CLEAR_ALL, 0, 0, 0, 0, 0, 0, 0, 0);
    foreach (regs_q[i])
      guard_cmd(sf_memory_guard_pkg::CMD_SET_REGION, regs_q[i].dom, regs_q[i].idx, 0,
                regs_q[i].base, regs_q[i].size, regs_q[i].r, regs_q[i].w, 0);
    guard_cmd(sf_memory_guard_pkg::CMD_BIND_PORT, 0, 0, PIDX, 0, 0, 0, 0, allow_mask);
  endtask

  task automatic obuf_read_word(input int w, output logic [127:0] d);
    @(negedge clk); obuf_raddr = OBW'(w);
    @(posedge clk); @(posedge clk); #1;
    d = obuf_rdata;
  endtask

  logic [127:0] obuf_pre [int];

  task automatic run_scenario();
    int          timeout;
    logic [127:0] d, e;
    int          nerr_before;
    exp_mem = mem;
    foreach (emem_over[a]) exp_mem[a] = emem_over[a];
    rng_q = 32'(k_seed) ^ 32'hA5A5_5A5A;
    if (rng_q == 0) rng_q = 32'h1;
    scen_errors = 0;
    st_perm_err = 0;
    if (!cont_mode) do_reset();
    cfg_max_out = ((USE_CACHE != 0) && (8'(k_maxout) > cache_max_out)) ? cache_max_out : 8'(k_maxout);
    cfg_merge   = k_merge[0];
    cfg_burst   = k_burst[0];
    program_guard();
    // scatter source buffer: cleared first, so the contents the engine can read are exactly the scenario's
    for (int w = 0; w < IBUF_BYTES/16; w++) begin
      @(negedge clk);
      ibuf_we = 1'b1; ibuf_waddr = IBW'(w); ibuf_wdata = 128'd0; ibuf_wbe = 16'hFFFF;
    end
    foreach (ibuf_img[w]) begin
      @(negedge clk);
      ibuf_we = 1'b1; ibuf_waddr = IBW'(w); ibuf_wdata = ibuf_img[w]; ibuf_wbe = 16'hFFFF;
    end
    @(negedge clk); ibuf_we = 1'b0;
    // snapshot of the output buffer
    obuf_pre.delete();
    for (int w = 0; w < OBUF_BYTES/16; w++) begin obuf_read_word(w, d); obuf_pre[w] = d; end
    perf_clear = 1'b1; c_perf_clear = 1'b1; @(negedge clk); perf_clear = 1'b0; c_perf_clear = 1'b0;

    // ---- issue the command
    rogue_armed = rogue_en;
    @(negedge clk);
    cmd = cmd_s; cmd_valid = 1'b1;
    timeout = 0;
    while (!cmd_ready) begin @(negedge clk); if (++timeout > 100) begin scen_errors++; $display("FAIL[%s]: command never accepted", scen_name); break; end end
    @(negedge clk);
    cmd_valid = 1'b0;

    // ---- stream indices (idx_stream commands): driven by the clocked push process below
    push_ptr = 0;
    push_en  = cmd_s.idx_stream;

    // ---- reset in the middle of the command
    if (mid_reset >= 0) begin
      repeat (mid_reset) @(posedge clk);
      push_en = 1'b0;
      do_reset();
      if (busy)       begin scen_errors++; $display("FAIL[%s]: busy after reset", scen_name); end
      if (done_valid) begin scen_errors++; $display("FAIL[%s]: done_valid after reset", scen_name); end
      if (!cmd_ready) begin scen_errors++; $display("FAIL[%s]: cmd_ready low after reset", scen_name); end
      if (perf !== '0) begin scen_errors++; $display("FAIL[%s]: performance counters not cleared by reset", scen_name); end
      if (outst_c != 0) begin scen_errors++; $display("FAIL[%s]: target model not reset", scen_name); end
      if (scen_errors == 0) begin total_pass++; $display("PASS %s", scen_name); end
      else                  begin total_fail++; $display("FAILED %s (%0d errors)", scen_name, scen_errors); end
      return;
    end

    // ---- wait for completion
    timeout = 0;
    while (!done_valid) begin
      @(posedge clk);
      if (++timeout > WATCHDOG) begin
        scen_errors++; $display("FAIL[%s]: watchdog (no completion in %0d cycles)", scen_name, WATCHDOG); break;
      end
    end
    if (done_valid) begin
      #1;
      if (int'(done.fault) != exp_fault)    begin scen_errors++; $display("FAIL[%s]: fault %0d expected %0d", scen_name, done.fault, exp_fault); end
      if (int'(done.gfault) != exp_gfault)  begin scen_errors++; $display("FAIL[%s]: gfault %0d expected %0d", scen_name, done.gfault, exp_gfault); end
      if (int'(done.alp_status) != exp_status) begin scen_errors++; $display("FAIL[%s]: alp_status %0d expected %0d", scen_name, done.alp_status, exp_status); end
      if (longint'(done.fault_elem) != longint'(exp_elem)) begin scen_errors++; $display("FAIL[%s]: fault_elem %0d expected %0d", scen_name, done.fault_elem, exp_elem); end
      if (longint'(done.fault_addr) != longint'(exp_addr)) begin scen_errors++; $display("FAIL[%s]: fault_addr %0h expected %0h", scen_name, done.fault_addr, exp_addr); end
      // exp_elems = -1: unspecified (protocol-violation scenarios)
      if (exp_elems >= 0 && int'(done.elems_done) != exp_elems) begin scen_errors++; $display("FAIL[%s]: elems_done %0d expected %0d", scen_name, done.elems_done, exp_elems); end
      if (int'(done.ovf) != exp_ovf)        begin scen_errors++; $display("FAIL[%s]: ovf %0d expected %0d", scen_name, done.ovf, exp_ovf); end
      if (done.tid != cmd_s.tid)            begin scen_errors++; $display("FAIL[%s]: tid mismatch", scen_name); end
      @(negedge clk); done_ready = 1'b1; @(negedge clk); done_ready = 1'b0;
      // the engine must be idle after completion
      repeat (3) @(posedge clk);
      if (busy) begin scen_errors++; $display("FAIL[%s]: busy after completion", scen_name); end
    end

    push_en = 1'b0;

    // ---- cache statistics (before the maintenance operation adds its own traffic), then make memory the truth
    if (USE_CACHE != 0) begin
      string cs;
      cs = $sformatf("CPERF %s", scen_name);
      for (int i = 0; i < 28; i++) cs = {cs, $sformatf(" %0d", c_perf[i*64 +: 64])};
      $display("%s", cs);
      if (c_proto_err) begin scen_errors++; $display("FAIL[%s]: cache reports a memory-link protocol error", scen_name); end
    end
    cache_flush();

    // ---- output buffer
    if (!nomem) for (int w = 0; w < OBUF_BYTES/16; w++) begin
      logic [15:0] m;
      obuf_read_word(w, d);
      m = eob_mask.exists(w) ? eob_mask[w] : 16'd0;
      e = (obuf_pre[w] & ~be_mask128(m)) | ((eob_data.exists(w) ? eob_data[w] : 128'd0) & be_mask128(m));
      if (d !== e) begin
        scen_errors++;
        if (scen_errors < 12) $display("FAIL[%s]: OBUF word %0d = %032h expected %032h", scen_name, w, d, e);
      end
    end

    // ---- memory image
    if (!nomem) foreach (exp_mem[a]) begin
      d = mem.exists(a) ? mem[a] : 128'd0;
      if (d !== exp_mem[a]) begin scen_errors++; if (scen_errors < 12) $display("FAIL[%s]: MEM beat %0h = %032h expected %032h", scen_name, a, d, exp_mem[a]); end
    end
    if (!nomem) foreach (mem[a]) begin
      if (!exp_mem.exists(a) && mem[a] !== 128'd0) begin scen_errors++; if (scen_errors < 12) $display("FAIL[%s]: MEM beat %0h unexpectedly non-zero", scen_name, a); end
    end

    // ---- link bookkeeping
    if (st_tag_err != 0 || st_out_err != 0 || st_waw_err != 0 || st_perm_err != 0) scen_errors++;
    if (rogue_en && rogue_armed) begin scen_errors++; $display("FAIL[%s]: rogue response was never injected", scen_name); end
    if (outst_c != 0) begin scen_errors++; $display("FAIL[%s]: %0d requests still outstanding after completion", scen_name, outst_c); end

    // ---- statistics line (parsed by the regression driver)
    $display("STAT %s reqs=%0d ooo=%0d maxout=%0d bankconf=%0d cyc=%0d", scen_name, st_reqs, st_ooo_resp, st_max_out, st_bank_conf, done.cycles);
    begin
      string ps;
      ps = $sformatf("PERF %s", scen_name);
      for (int i = 0; i < SP_PC_N; i++) ps = {ps, $sformatf(" %0d", perf[i*32 +: 32])};
      $display("%s", ps);
    end
    if (scen_errors == 0) begin total_pass++; $display("PASS %s", scen_name); end
    else                  begin total_fail++; $display("FAILED %s (%0d errors)", scen_name, scen_errors); end
  endtask

  // ---------------------------------------------------------------- scenario file reader
  task automatic clear_scenario(input bit keep_mem);
    regs_q.delete(); exp_mem.delete(); emem_over.delete(); ibuf_img.delete(); err_beats.delete();
    if (!keep_mem) mem.delete();
    cont_mode = keep_mem; mid_reset = -1; nomem = 1'b0; rogue_en = 1'b0; rogue_armed = 1'b0; rogue_tag = 8'd0; rogue_delay = 1;
    ipush_q.delete(); eob_data.delete(); eob_mask.delete();
    k_lat = 2; k_jit = 0; k_ooo = 0; k_banks = 0; k_svc = 1; k_rdy = 100; k_rsp = 0; k_seed = 1;
    k_maxout = 4; k_merge = 1; k_burst = 1; k_ipgap = 0;
    allow_mask = 15;
    exp_fault = 0; exp_gfault = 0; exp_status = 0; exp_elem = 0; exp_addr = 0; exp_elems = 0; exp_ovf = 0;
    cmd_s = '0;
  endtask

  initial begin
    int fd, r;
    string w;
    longint unsigned a, b;
    logic [127:0] dd;
    logic [15:0] mm;
    int  x1;
    sf_sp_cmd_t c;
    mm_reset();
    clear_scenario(1'b0);
    if (!$value$plusargs("scen=%s", scen_path)) scen_path = SCEN_FILE;
    fd = $fopen(scen_path, "r");
    if (fd == 0) begin $display("ERROR: cannot open %s", scen_path); $finish; end
    forever begin
      r = $fscanf(fd, "%s", w);
      if (r != 1) break;
      case (w)
        "SCEN":  begin r = $fscanf(fd, "%s", scen_name); clear_scenario(1'b0); end
        "CONT":  begin clear_scenario(1'b1); end
        "MIDRESET": r = $fscanf(fd, "%d", mid_reset);
        "NOMEM": nomem = 1'b1;
        "ROGUE": begin
          int tg;
          r = $fscanf(fd, "%h %d", tg, rogue_delay); rogue_en = 1'b1;
          // 0x100 = "the first tag index outside the request table" (NRT; 31 when NRT = 32 leaves no such index)
          rogue_tag = (tg == 'h100) ? ((NRT < 32) ? 8'(NRT) : 8'd31) : 8'(tg);
        end
        "KNOB":  r = $fscanf(fd, "%d %d %d %d %d %d %d %d %d %d %d %d", k_lat, k_jit, k_ooo, k_banks, k_svc, k_rdy, k_rsp, k_seed, k_maxout, k_merge, k_burst, k_ipgap);
        "ALLOW": r = $fscanf(fd, "%h", allow_mask);
        "REGION": begin
          reg_t rg;
          r = $fscanf(fd, "%d %d %h %h %d %d", rg.dom, rg.idx, rg.base, rg.size, rg.r, rg.w);
          regs_q.push_back(rg);
        end
        "MEM":   begin r = $fscanf(fd, "%h %h", a, dd); mem[a] = dd; end
        "IBUF":  begin r = $fscanf(fd, "%h %h", a, dd); ibuf_img[a] = dd; end
        "ERR":   begin r = $fscanf(fd, "%h %d", a, x1); err_beats[a] = x1; end
        "IPUSH": begin
          r = $fscanf(fd, "%d", x1);
          for (int i = 0; i < x1; i++) begin logic [31:0] v; r = $fscanf(fd, "%h", v); ipush_q.push_back(v); end
        end
        "CMD": begin
          longint unsigned v [22];
          c = '0;
          for (int i = 0; i < 22; i++) begin r = $fscanf(fd, "%h", v[i]); end
          c.op = 4'(v[0]); c.tid = 16'(v[1]); c.dom = SP_DOM_W'(v[2]); c.cacheable = v[3][0]; c.idx_stream = v[4][0];
          c.idx_signed = v[5][0]; c.idx_w = 2'(v[6]); c.base = SP_ADDR_W'(v[7]); c.idx_base = SP_ADDR_W'(v[8]);
          c.n = 32'(v[9]); c.elem_bytes = SP_EB_W'(v[10]); c.idx_limit = 32'(v[11]); c.dst_off = SP_OFF_W'(v[12]);
          c.src_off = SP_OFF_W'(v[13]); c.rp_base = SP_ADDR_W'(v[14]); c.ci_base = SP_ADDR_W'(v[15]);
          c.val_base = SP_ADDR_W'(v[16]); c.nrows = 32'(v[17]); c.ncols = 32'(v[18]); c.nnz = 32'(v[19]);
          c.ci_w = 2'(v[20]); c.vfmt = 3'(v[21]);
          cmd_s = c;
        end
        "EXP": r = $fscanf(fd, "%d %d %d %h %h %d %d", exp_fault, exp_gfault, exp_status, exp_elem, exp_addr, exp_elems, exp_ovf);
        "EOBUF": begin r = $fscanf(fd, "%h %h %h", a, dd, mm); eob_data[a] = dd; eob_mask[a] = mm; end
        "EMEM":  begin r = $fscanf(fd, "%h %h", a, dd); emem_over[a] = dd; end
        "RUN":   run_scenario();
        default: begin $display("ERROR: unknown token '%s'", w); $finish; end
      endcase
    end
    $fclose(fd);
    $display("SUMMARY pass=%0d fail=%0d", total_pass, total_fail);
    if (total_fail == 0) $display("ALL_PASS"); else $display("SOME_FAILED");
    $finish;
  end

endmodule

`default_nettype wire
