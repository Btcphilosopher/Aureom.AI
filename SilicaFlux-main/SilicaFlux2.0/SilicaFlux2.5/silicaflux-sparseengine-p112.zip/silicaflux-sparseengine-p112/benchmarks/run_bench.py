#!/usr/bin/env python3
"""
SparseEngine benchmark harness.

Workloads x memory systems.  Every run is a normal self-checking scenario (output buffer and memory image are
compared with the Python reference), so a benchmark number is never reported for a run that computed a wrong result.
All figures are RTL-simulation clock cycles of the tb_sparse bench; the memory model's latency is a parameter, not a
claim about any real memory.

usage: run_bench.py [--out benchmarks/results/bench] [--quick]
"""
import argparse, csv, json, os, random, re, subprocess, sys, time
from concurrent.futures import ProcessPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "model")); sys.path.insert(0, os.path.join(ROOT, "scripts"))
import sp_model as M          # noqa: E402
import gen_scenarios as G     # noqa: E402
import sim                    # noqa: E402

OBUF = 65536
CFG = M.Cfg(ADDR_W=40, OBUF_BYTES=OBUF, IBUF_BYTES=OBUF)
LAT = 30                       # memory latency in cycles (a parameter of the target model)

# name -> (build parameters, scenario knobs, group)
BIG = dict(NRT=32, ROB_DEPTH=64)          # larger request table / reorder buffer
SYSTEMS = {
    "direct_mo1":     (dict(USE_CACHE=0), dict(lat=LAT, maxout=1),  "inorder"),
    "direct_mo4":     (dict(USE_CACHE=0), dict(lat=LAT, maxout=4),  "inorder"),
    "direct_mo16":    (dict(USE_CACHE=0), dict(lat=LAT, maxout=16), "inorder"),
    "direct_mo32":    (dict(USE_CACHE=0), dict(lat=LAT, maxout=32), "inorder"),
    "direct_mo32_big": (dict(USE_CACHE=0, **BIG), dict(lat=LAT, maxout=32), "inorder"),
    "banked8_big":    (dict(USE_CACHE=0, **BIG), dict(lat=LAT, maxout=32, banks=8, svc=4, ooo=1), "ooo"),
    "cache_blk":      (dict(USE_CACHE=1, NUM_MSHR=1), dict(lat=LAT, maxout=32), "inorder"),
    "cache_mshr4":    (dict(USE_CACHE=1, NUM_MSHR=4, MEM_OUT_LIMIT=8), dict(lat=LAT, maxout=32), "inorder"),
}
# latency sweep: the same few workloads at other memory latencies (system name carries the latency)
LAT_SWEEP = (10, 100, 250)
LAT_SYSTEMS = ("direct_mo1", "direct_mo32_big", "cache_blk", "cache_mshr4")
LAT_WORKLOADS = ("zipf_E64", "rand_big_E64", "rand_fit_E64", "rand_big_E4")
for _l in LAT_SWEEP:
    for _s in LAT_SYSTEMS:
        _p, _k, _g = SYSTEMS[_s]
        _k = dict(_k); _k["lat"] = _l
        SYSTEMS[f"{_s}@lat{_l}"] = (_p, _k, _g)
PERF_N = ["cycles_busy", "cmds", "cmds_fault", "elems", "data_rd", "data_wr", "meta", "bytes_req", "bytes_useful", "merges",
          "dup_hits", "burst_cont", "stall_link", "stall_rt", "stall_rob", "rob_occ_sum", "rob_occ_max", "rt_occ_max", "out_max",
          "bank_conf_est", "rdlat_sum", "rdlat_cnt", "rdlat_max", "cmdlat_sum", "cmdlat_max", "proto_err"]
CPERF_N = ["rd_hit", "rd_miss", "wr_hit", "wr_miss", "refill", "evict", "writeback", "mem_rd_beat", "mem_wr_beat", "bypass_rd", "bypass_wr",
           "cmo_line", "cmo_discard", "err_rsp", "refill_err", "wb_err", "tag_ce", "tag_ue", "data_ce", "data_ue", "dirty_lost",
           "stall", "busy", "park", "lat_sum", "lat_max", "lat_cnt", "lat_min"]


def workloads(quick: bool):
    rng = random.Random(1234)
    n64 = 256 if quick else 1024
    n4 = 1024 if quick else 4096
    rows64_big, rows64_fit = 2048, 256                  # 128 KiB (4x the 32 KiB cache) and 16 KiB (fits)
    W = {}
    W["seq_E64"]          = ("gather", 64, [i % rows64_big for i in range(n64)])
    W["rand_big_E64"]     = ("gather", 64, [rng.randrange(rows64_big) for _ in range(n64)])
    W["rand_fit_E64"]     = ("gather", 64, [rng.randrange(rows64_fit) for _ in range(n64)])
    W["zipf_E64"]         = ("gather", 64, [rng.randrange(32) if rng.random() < 0.8 else rng.randrange(rows64_big) for _ in range(n64)])
    W["stride4k_E64"]     = ("gather", 64, [(i * 64) % rows64_big for i in range(n64)])
    W["repeat4_E64"]      = ("gather", 64, [rng.randrange(rows64_big) for _ in range(n64 // 4) for _ in range(4)][:n64])
    # (the repeat pattern above draws a fresh value for each of the 4 copies; build it properly)
    base = [rng.randrange(rows64_big) for _ in range(n64 // 4)]
    W["repeat4_E64"]      = ("gather", 64, [v for v in base for _ in range(4)])
    W["seq_E4"]           = ("gather", 4, [i % 65536 for i in range(n4)])
    W["rand_big_E4"]      = ("gather", 4, [rng.randrange(65536) for _ in range(n4)])
    W["scatter_rand_E64"] = ("scatter", 64, [rng.randrange(rows64_big) for _ in range(n64)])
    W["scatter_dup_E64"]  = ("scatter", 64, [rng.randrange(128) for _ in range(n64)])
    nr = 256 if quick else 512
    W["spmv_cachefit"]    = ("spmv", 4096, [nr, 8])
    W["spmv_cachehostile"] = ("spmv", 200000, [nr, 8])
    return W


def make_scenario(name, kind, E, arg, knobs, group, cacheable=1):
    if kind == "gather":
        sc = G.gather(name, CFG, E=E, idx=arg, idx_w=2, knobs=dict(knobs), group=group, cacheable=cacheable,
                      tbl_bytes=G.TBL_SIZE)
    elif kind == "scatter":
        sc = G.scatter(name, CFG, E=E, idx=arg, idx_w=2, knobs=dict(knobs), group=group, cacheable=cacheable)
    else:
        ncols, (nrows, avg) = E, arg
        rng = random.Random(77)
        rows = [max(0, int(rng.gauss(avg, 2))) for _ in range(nrows)]
        sc = G.csr(name, CFG, rows=rows, ncols=ncols, op=M.OP_CSR_SPMV, knobs=dict(knobs), group=group, cacheable=cacheable)
    return sc


def build_one(base):
    params, knobs, group = SYSTEMS[base]
    build = dict(ADDR_W=40, OBUF_BYTES=OBUF, IBUF_BYTES=OBUF, ORD_CHECK=1 if group == "inorder" else 0, WATCHDOG=3000000,
                 MEM_OUT_LIMIT=params.get("MEM_OUT_LIMIT", 4))
    build.update(params)
    sim.build(f"bench_{base}", [f"{k}={v}" for k, v in build.items()])
    return base


def run_system(task):
    sysname, quick = task
    params, knobs, group = SYSTEMS[sysname]
    W = workloads(quick)
    if "@lat" in sysname:
        W = {k: v for k, v in W.items() if k in LAT_WORKLOADS}
    build = dict(ADDR_W=40, OBUF_BYTES=OBUF, IBUF_BYTES=OBUF, ORD_CHECK=1 if group == "inorder" else 0, WATCHDOG=3000000,
                 MEM_OUT_LIMIT=params.get("MEM_OUT_LIMIT", 4))
    build.update(params)
    base_name = sysname.split("@")[0]
    exe = sim.build(f"bench_{base_name}", [f"{k}={v}" for k, v in build.items()])
    cfg = M.Cfg(ADDR_W=40, OBUF_BYTES=OBUF, IBUF_BYTES=OBUF, ROB_DEPTH=params.get("ROB_DEPTH", 32))
    if params.get("USE_CACHE"):
        cfg.ERR_LINE_BEATS = 4
    scen = os.path.join(ROOT, "build", "bench_" + sysname.replace("@", "_") + ".txt")
    with open(scen, "w") as f:
        for wn, (kind, E, arg) in W.items():
            sc = make_scenario(wn, kind, E, arg, knobs, group)
            sc.cfg = cfg
            G.emit(f, sc, G.run_model(sc))
    t0 = time.time()
    p = subprocess.run([exe, f"+scen={scen}"], capture_output=True, text=True)
    out = p.stdout
    rows = {}
    for line in out.splitlines():
        t = line.split()
        if line.startswith("PERF "):
            rows.setdefault(t[1], {})["perf"] = dict(zip(PERF_N, map(int, t[2:])))
        elif line.startswith("CPERF "):
            rows.setdefault(t[1], {})["cperf"] = dict(zip(CPERF_N, map(int, t[2:])))
        elif line.startswith("STAT "):
            d = dict(kv.split("=") for kv in t[2:])
            rows.setdefault(t[1], {})["stat"] = {k: int(v) for k, v in d.items()}
        elif line.startswith("PASS "):
            rows.setdefault(t[1], {})["pass"] = True
        elif line.startswith("FAILED "):
            rows.setdefault(t[1], {})["pass"] = False
    return sysname, rows, round(time.time() - t0, 1), ("ALL_PASS" in out)


def derive(sysname, wl, r, kind, E):
    p, c, s = r["perf"], r.get("cperf"), r["stat"]
    cyc = s["cyc"]
    elems = p["elems"] if kind != "spmv" else p["elems"]
    row = dict(system=sysname.split("@")[0], mem_latency=int(sysname.split("@lat")[1]) if "@lat" in sysname else LAT, workload=wl, correct=int(bool(r.get("pass"))), cycles=cyc, elements=elems,
               elems_per_cycle=round(elems / cyc, 4), data_reads=p["data_rd"], data_writes=p["data_wr"], index_reqs=p["meta"],
               link_reqs_total=p["data_rd"] + p["data_wr"] + p["meta"], merges=p["merges"], dup_hits=p["dup_hits"],
               bytes_useful=p["bytes_useful"], bytes_requested=p["bytes_req"],
               link_bytes_data=16 * (p["data_rd"] + p["data_wr"]),
               useful_over_link_bytes=round(p["bytes_useful"] / max(1, 16 * (p["data_rd"] + p["data_wr"])), 4),
               burst_cont_frac=round(p["burst_cont"] / max(1, p["data_rd"] + p["data_wr"]), 4),
               rob_occ_avg=round(p["rob_occ_sum"] / max(1, cyc), 2), rob_occ_max=p["rob_occ_max"], rt_occ_max=p["rt_occ_max"],
               out_max=p["out_max"], stall_link_cycles=p["stall_link"],
               req_lat_avg=round(p["rdlat_sum"] / max(1, p["rdlat_cnt"]), 1), req_lat_max=p["rdlat_max"],
               cmd_cycles=p["cmdlat_max"], bank_conf_est=p["bank_conf_est"], bank_conf_target=s["bankconf"],
               link_reqs_seen_by_target=s["reqs"], reordered_resp=s["ooo"])
    if c:
        rd, wr = c["rd_hit"] + c["rd_miss"], c["wr_hit"] + c["wr_miss"]
        hits, acc = c["rd_hit"] + c["wr_hit"], rd + wr
        row.update(cache_hits=hits, cache_misses=c["rd_miss"] + c["wr_miss"], cache_hit_rate=round(hits / max(1, acc), 4),
                   cache_refills=c["refill"], cache_line_bytes_fetched=64 * c["refill"],
                   cache_line_util=round(p["bytes_useful"] / max(1, 64 * c["refill"]), 4) if c["refill"] else None,
                   cache_miss_lat_avg=round(c["lat_sum"] / max(1, c["lat_cnt"]), 1), cache_miss_lat_max=c["lat_max"],
                   mem_rd_beats=c["mem_rd_beat"], mem_wr_beats=c["mem_wr_beat"], writebacks=c["writeback"])
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "benchmarks", "results", "bench"))
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--jobs", type=int, default=3)
    a = ap.parse_args()
    W = workloads(a.quick)
    kinds = {w: (k, E) for w, (k, E, _) in W.items()}
    with ProcessPoolExecutor(max_workers=a.jobs) as ex:
        bases = sorted({s.split("@")[0] for s in SYSTEMS})
        list(ex.map(build_one, bases))                      # build each simulator once, then run all (system, latency) pairs
        results = list(ex.map(run_system, [(s, a.quick) for s in SYSTEMS]))
    table = []
    bad = []
    for sysname, rows, secs, ok in results:
        if not ok:
            bad.append(sysname)
        for wl, r in rows.items():
            if "perf" in r and "stat" in r:
                table.append(derive(sysname, wl, r, *kinds[wl]))
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    json.dump(table, open(a.out + ".json", "w"), indent=1)
    keys = sorted({k for r in table for k in r}, key=lambda k: (k not in ("system", "mem_latency", "workload", "correct"), k))
    with open(a.out + ".csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(table)
    print(f"{len(table)} runs; systems with failing scenarios: {bad or 'none'}")
    sys.exit(1 if bad else 0)

if __name__ == "__main__":
    main()
