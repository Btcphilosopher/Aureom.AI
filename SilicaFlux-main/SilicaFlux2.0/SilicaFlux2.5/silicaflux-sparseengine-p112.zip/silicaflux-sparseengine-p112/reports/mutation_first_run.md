<!-- SUPERSEDED: first full campaign (42 mutants), run while the build disk was full, before the test additions described in docs/05 section 5. Kept as history; reports/mutation.md is the result for the delivered tests and RTL. -->
# Mutation campaign

42 planted defects; **35 killed**, 7 survived, 0 invalid.

| id | planted defect | result | detected by |
|---|---|---|---|
| co_cov_be | duplicate hit ignores byte-enable coverage | KILLED | stage1 failed |
| co_no_release | table entries are never freed | KILLED | stage1 failed |
| co_wr_merge_old | scatter merge keeps the OLD bytes (first writer wins) | KILLED | scatter_in failed |
| co_no_dep | no write-ordering dependency | KILLED | scatter_in failed |
| co_dep_flight_only | dependency ignores older pending writes (matters with merging off) | KILLED | scatter_in failed |
| co_rs_range | response index range off by one (only reachable with a bad tag) | SURVIVED |  |
| co_tag | request tag does not name the table entry | KILLED | stage1 failed |
| co_pend_stale | merge into the entry that is being issued this cycle (lost update) | KILLED | stage1 failed |
| co_err_data | error data not zeroed | SURVIVED |  |
| rob_lane | delivered lane forgotten | KILLED | stage1 failed |
| rob_full | reorder buffer overflows | KILLED | stage1 failed |
| rob_no_done | delivers before the response arrived | KILLED | stage1 failed |
| rob_rel_rt | releases the wrong table entry | KILLED | stage1 failed |
| ag_no_ovf | address overflow not detected | KILLED | faults failed |
| ag_limit | index limit off by one | KILLED | faults failed |
| ag_neg | negative index not detected | KILLED | stage1 failed |
| sp_be | byte-enable mask one byte too wide | KILLED | scatter_in failed |
| sp_nb | large elements split into one beat too many | KILLED | stage1 failed |
| eng_rot | output lane rotation direction | KILLED | stage1 failed |
| eng_wmask | output byte mask one byte too wide | KILLED | stage1 failed |
| eng_min_fault | fault arbitration picks the HIGHEST element | SURVIVED |  |
| eng_take_min | a later fault never replaces an earlier one | KILLED | faults failed |
| eng_drop | elements ahead of a front-end fault are discarded | KILLED | csr_in failed |
| eng_wr_perm | scatter checked for READ permission | KILLED | build failed |
| eng_align | table base alignment not checked | KILLED | build failed |
| eng_buf | buffer range off by one | KILLED | stage1 failed |
| eng_idxlim | index limit never applied | KILLED | faults failed |
| eng_yrow | SpMV result stored at the wrong stride | KILLED | csr_in failed |
| eng_sx_sat | completion waits for orphan events (hang after a fault) | KILLED | csr_in failed |
| eng_close | index buffer never closes after a walker fault (hang) | KILLED | csr_in failed |
| wk_mono | empty rows rejected as non-monotonic | KILLED | csr_in failed |
| wk_nnz | row pointer bound off by one | SURVIVED |  |
| wk_total | final row pointer != nnz accepted | KILLED | csr_in failed |
| wk_first | row_ptr[0] != 0 accepted | KILLED | csr_in failed |
| wk_col | column bound off by one | KILLED | csr_in failed |
| spmv_clear | rows accumulate into each other | KILLED | csr_in failed |
| spmv_emit | empty rows produce no result | SURVIVED |  |
| spmv_ovf | overflow flag never reported | SURVIVED |  |
| ib_sign | 32-bit signed indices never negative | KILLED | faults failed |
| sr_be | index array reads touch bytes before the array | SURVIVED |  |
| eng_tag_ci | column reader responses routed to the row-pointer reader | KILLED | csr_in failed |
| eng_sg_rot | scatter source lane rotation direction | KILLED | scatter_in failed |

## Survivors

* **co_rs_range** - response index range off by one (only reachable with a bad tag). NOT explained: a test gap.
* **co_err_data** - error data not zeroed. Believed equivalent: equivalent: the target returns zero data with an error and the engine discards error data
* **eng_min_fault** - fault arbitration picks the HIGHEST element. NOT explained: a test gap.
* **wk_nnz** - row pointer bound off by one. NOT explained: a test gap.
* **spmv_emit** - empty rows produce no result. NOT explained: a test gap.
* **spmv_ovf** - overflow flag never reported. Believed equivalent: needs the narrow-accumulator build (run with --arith)
* **sr_be** - index array reads touch bytes before the array. NOT explained: a test gap.
