# Synthesis statistics (Yosys generic gates)

Technology-independent counts from a generic Yosys flow (`synth` coarse stage, RAM arrays kept as RAMs, `techmap`, `abc`). **No liberty file, PDK, timing, area or power is involved**; see docs/07_synthesis.md for what these numbers do and do not mean.

| configuration | overrides | logic cells | flip-flops | latches | RAM bits (arrays) | `check -assert` |
|---|---|---|---|---|---|---|
| default | defaults | 99,137 | 8,200 | 0 | 132,072 | passed (check -assert) |
| gs_only | CSR_EN=0, SPMV_EN=0 | 85,847 | 7,129 | 0 | 131,720 | passed (check -assert) |
| small | CSR_EN=0, SPMV_EN=0, NRT=4, ROB_DEPTH=16, MAX_ELEM_BYTES=64, OBUF_BYTES=2048, IBUF_BYTES=2048, IDX_NSLOT=2, IDX_FIFO=2 | 44,364 | 3,872 | 0 | 33,092 | passed (check -assert) |
| large | NRT=32, ROB_DEPTH=64, OBUF_BYTES=32768, IBUF_BYTES=32768 | 152,906 | 12,675 | 0 | 525,288 | passed (check -assert) |

## default

### Per module (own cells; instances counted once per module type)

| module | logic cells | flip-flops | longest path (generic gates) |
|---|---|---|---|
| sf_sparse_request_coalescer | 52,084 | 4,504 | 306 |
| sf_sparse_memory_engine | 17,443 | 1,638 | 232 |
| sf_memory_guard_checker | 12,833 | 0 | 80 |
| sf_sparse_address_gen | 2,726 | 257 | 81 |
| sf_sparse_stream_rd | 2,235 | 207 | 64 |
| sf_sparse_reorder | 1,549 | 409 | 13 |
| sf_sparse_csr_walker | 1,690 | 266 | 90 |
| sf_sparse_index_buffer | 725 | 108 | 39 |
| tensor_pe | 700 | 70 | 50 |
| sf_sparse_beat_split | 298 | 81 | 43 |
| sf_sparse_spmv | 136 | 39 | 32 |

### RAM arrays (not flattened into flip-flops)

| array | width x depth | bits |
|---|---|---|
| \sl_data_q | 128 x 4 | 512 |
| \mem_q | 34 x 4 | 136 |
| \ibuf_q | 128 x 512 | 65,536 |
| \obuf_q | 128 x 512 | 65,536 |
| \g_spmv.evf_mem | 11 x 32 | 352 |

## gs_only

### Per module (own cells; instances counted once per module type)

| module | logic cells | flip-flops | longest path (generic gates) |
|---|---|---|---|
| sf_sparse_request_coalescer | 52,084 | 4,504 | 306 |
| sf_sparse_memory_engine | 13,402 | 1,563 | 166 |
| sf_memory_guard_checker | 12,821 | 0 | 81 |
| sf_sparse_address_gen | 2,726 | 257 | 81 |
| sf_sparse_stream_rd | 2,235 | 207 | 64 |
| sf_sparse_reorder | 1,549 | 409 | 13 |
| sf_sparse_index_buffer | 725 | 108 | 39 |
| sf_sparse_beat_split | 298 | 81 | 43 |

### RAM arrays (not flattened into flip-flops)

| array | width x depth | bits |
|---|---|---|
| \mem_q | 34 x 4 | 136 |
| \ibuf_q | 128 x 512 | 65,536 |
| \obuf_q | 128 x 512 | 65,536 |
| \sl_data_q | 128 x 4 | 512 |

## small

### Per module (own cells; instances counted once per module type)

| module | logic cells | flip-flops | longest path (generic gates) |
|---|---|---|---|
| sf_sparse_memory_engine | 13,379 | 1,556 | 147 |
| sf_sparse_request_coalescer | 11,695 | 1,428 | 122 |
| sf_memory_guard_checker | 12,815 | 0 | 81 |
| sf_sparse_address_gen | 2,726 | 257 | 81 |
| sf_sparse_stream_rd | 2,153 | 199 | 64 |
| sf_sparse_reorder | 577 | 246 | 13 |
| sf_sparse_index_buffer | 714 | 105 | 40 |
| sf_sparse_beat_split | 298 | 81 | 43 |

### RAM arrays (not flattened into flip-flops)

| array | width x depth | bits |
|---|---|---|
| \mem_q | 34 x 2 | 68 |
| \ibuf_q | 128 x 128 | 16,384 |
| \obuf_q | 128 x 128 | 16,384 |
| \sl_data_q | 128 x 2 | 256 |

## large

### Per module (own cells; instances counted once per module type)

| module | logic cells | flip-flops | longest path (generic gates) |
|---|---|---|---|
| sf_sparse_request_coalescer | 104,026 | 8,650 | 540 |
| sf_sparse_memory_engine | 17,445 | 1,644 | 250 |
| sf_memory_guard_checker | 12,833 | 0 | 80 |
| sf_sparse_reorder | 3,373 | 732 | 15 |
| sf_sparse_address_gen | 2,726 | 257 | 81 |
| sf_sparse_stream_rd | 2,235 | 207 | 64 |
| sf_sparse_csr_walker | 1,691 | 266 | 93 |
| sf_sparse_index_buffer | 725 | 108 | 39 |
| tensor_pe | 700 | 70 | 50 |
| sf_sparse_beat_split | 298 | 81 | 43 |
| sf_sparse_spmv | 136 | 39 | 32 |

### RAM arrays (not flattened into flip-flops)

| array | width x depth | bits |
|---|---|---|
| \ibuf_q | 128 x 2048 | 262,144 |
| \obuf_q | 128 x 2048 | 262,144 |
| \g_spmv.evf_mem | 11 x 32 | 352 |
| \sl_data_q | 128 x 4 | 512 |
| \mem_q | 34 x 4 | 136 |
