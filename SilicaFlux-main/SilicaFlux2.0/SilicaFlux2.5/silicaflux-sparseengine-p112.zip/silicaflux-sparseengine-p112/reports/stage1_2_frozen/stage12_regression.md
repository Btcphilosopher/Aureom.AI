# Regression results

12 configurations x 4 suites; **3178 scenarios passed, 0 failed**; 148,683 elements / 1,528,988 bytes compared byte-exact against the Python reference.

| config | suite | target model | scenarios | failed | elements | link requests | reordered responses | result |
|---|---|---|---|---|---|---|---|---|
| base | stage1 | inorder | 81 | 0 | 4739 | 5452 | 0 | PASS |
| base | faults | inorder | 93 | 0 | 317 | 439 | 0 | PASS |
| base | chains | inorder | 31 | 0 | 905 | 586 | 0 | PASS |
| base | stage2 | inorder | 18 | 0 | 1880 | 1913 | 0 | PASS |
| base | stage2 | ooo | 42 | 0 | 4800 | 4888 | 2002 | PASS |
| nrt2 | stage1 | inorder | 81 | 0 | 4739 | 6082 | 0 | PASS |
| nrt2 | faults | inorder | 93 | 0 | 317 | 464 | 0 | PASS |
| nrt2 | chains | inorder | 31 | 0 | 905 | 621 | 0 | PASS |
| nrt2 | stage2 | inorder | 18 | 0 | 1880 | 2160 | 0 | PASS |
| nrt2 | stage2 | ooo | 42 | 0 | 4800 | 5325 | 884 | PASS |
| nrt4 | stage1 | inorder | 81 | 0 | 4739 | 5726 | 0 | PASS |
| nrt4 | faults | inorder | 93 | 0 | 317 | 453 | 0 | PASS |
| nrt4 | chains | inorder | 31 | 0 | 905 | 586 | 0 | PASS |
| nrt4 | stage2 | inorder | 18 | 0 | 1880 | 2024 | 0 | PASS |
| nrt4 | stage2 | ooo | 42 | 0 | 4800 | 5161 | 1433 | PASS |
| nrt32 | stage1 | inorder | 81 | 0 | 4739 | 5449 | 0 | PASS |
| nrt32 | faults | inorder | 93 | 0 | 317 | 439 | 0 | PASS |
| nrt32 | chains | inorder | 31 | 0 | 905 | 586 | 0 | PASS |
| nrt32 | stage2 | inorder | 18 | 0 | 1880 | 1901 | 0 | PASS |
| nrt32 | stage2 | ooo | 42 | 0 | 4800 | 4832 | 2055 | PASS |
| rob16 | stage1 | inorder | 81 | 0 | 4739 | 5452 | 0 | PASS |
| rob16 | faults | inorder | 93 | 0 | 317 | 439 | 0 | PASS |
| rob16 | chains | inorder | 31 | 0 | 905 | 586 | 0 | PASS |
| rob16 | stage2 | inorder | 18 | 0 | 1880 | 1919 | 0 | PASS |
| rob16 | stage2 | ooo | 42 | 0 | 4800 | 4934 | 2028 | PASS |
| rob64 | stage1 | inorder | 81 | 0 | 4739 | 5452 | 0 | PASS |
| rob64 | faults | inorder | 93 | 0 | 317 | 439 | 0 | PASS |
| rob64 | chains | inorder | 31 | 0 | 905 | 586 | 0 | PASS |
| rob64 | stage2 | inorder | 18 | 0 | 1880 | 1913 | 0 | PASS |
| rob64 | stage2 | ooo | 42 | 0 | 4800 | 4888 | 2002 | PASS |
| idx_small | stage1 | inorder | 81 | 0 | 4739 | 5457 | 0 | PASS |
| idx_small | faults | inorder | 93 | 0 | 317 | 430 | 0 | PASS |
| idx_small | chains | inorder | 31 | 0 | 905 | 574 | 0 | PASS |
| idx_small | stage2 | inorder | 18 | 0 | 1880 | 1982 | 0 | PASS |
| idx_small | stage2 | ooo | 42 | 0 | 4800 | 5095 | 1952 | PASS |
| idx_big | stage1 | inorder | 81 | 0 | 4739 | 5598 | 0 | PASS |
| idx_big | faults | inorder | 93 | 0 | 317 | 440 | 0 | PASS |
| idx_big | chains | inorder | 31 | 0 | 905 | 586 | 0 | PASS |
| idx_big | stage2 | inorder | 18 | 0 | 1880 | 1886 | 0 | PASS |
| idx_big | stage2 | ooo | 42 | 0 | 4800 | 4839 | 1957 | PASS |
| tiny | stage1 | inorder | 81 | 0 | 4351 | 4497 | 0 | PASS |
| tiny | faults | inorder | 93 | 0 | 294 | 335 | 0 | PASS |
| tiny | chains | inorder | 31 | 0 | 857 | 599 | 0 | PASS |
| tiny | stage2 | inorder | 18 | 0 | 1280 | 1486 | 0 | PASS |
| tiny | stage2 | ooo | 42 | 0 | 2850 | 2935 | 738 | PASS |
| addr24 | stage1 | inorder | 81 | 0 | 4739 | 5452 | 0 | PASS |
| addr24 | faults | inorder | 93 | 0 | 317 | 439 | 0 | PASS |
| addr24 | chains | inorder | 31 | 0 | 905 | 586 | 0 | PASS |
| addr24 | stage2 | inorder | 18 | 0 | 1880 | 1913 | 0 | PASS |
| addr24 | stage2 | ooo | 42 | 0 | 4800 | 4888 | 2002 | PASS |
| addr32 | stage1 | inorder | 81 | 0 | 4739 | 5452 | 0 | PASS |
| addr32 | faults | inorder | 93 | 0 | 317 | 439 | 0 | PASS |
| addr32 | chains | inorder | 31 | 0 | 905 | 586 | 0 | PASS |
| addr32 | stage2 | inorder | 18 | 0 | 1880 | 1913 | 0 | PASS |
| addr32 | stage2 | ooo | 42 | 0 | 4800 | 4888 | 2002 | PASS |
| addr48 | stage1 | inorder | 81 | 0 | 4739 | 5452 | 0 | PASS |
| addr48 | faults | inorder | 91 | 0 | 317 | 439 | 0 | PASS |
| addr48 | chains | inorder | 31 | 0 | 905 | 586 | 0 | PASS |
| addr48 | stage2 | inorder | 18 | 0 | 1880 | 1913 | 0 | PASS |
| addr48 | stage2 | ooo | 42 | 0 | 4800 | 4888 | 2002 | PASS |
