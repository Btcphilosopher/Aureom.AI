# Mutation campaign

43 planted defects; **41 killed**, 2 survived, 0 invalid (did not build), 0 inconclusive (time-out).

| id | planted defect | result | detected by |
|---|---|---|---|
| co_cov_be | duplicate hit ignores byte-enable coverage | KILLED | stage1 failed |
| co_no_release | table entries are never freed | KILLED | stage1 failed |
| co_wr_merge_old | scatter merge keeps the OLD bytes (first writer wins) | KILLED | scatter_in failed |
| co_no_dep | no write-ordering dependency | KILLED | scatter_in failed |
| co_dep_flight_only | dependency ignores older pending writes (matters with merging off) | KILLED | scatter_in failed |
| co_rs_range | response index range off by one (only reachable with a bad tag) | KILLED | s2_ooo failed |
| co_tag | request tag does not name the table entry | KILLED | stage1 failed |
| co_pend_stale | merge into the entry that is being issued this cycle (lost update) | KILLED | stage1 failed |
| co_err_data | error data not zeroed | SURVIVED |  |
| rob_lane | delivered lane forgotten | KILLED | stage1 failed |
| rob_full | reorder buffer overflows | KILLED | stage1 failed |
| rob_no_done | delivers before the response arrived | KILLED | stage1 failed |
| rob_rel_rt | releases the wrong table entry | KILLED | stage1 failed |
| ag_no_ovf | address overflow not detected | KILLED | faults failed |
| ag_limit | index limit off by one | KILLED | faults failed |
| ag_neg | negative index not detected | KILLED | stage1 failed |
| sp_be | byte-enable mask one byte too wide | KILLED | scatter_in failed |
| sp_nb | large elements split into one beat too many | KILLED | stage1 failed |
| eng_rot | output lane rotation direction | KILLED | stage1 failed |
| eng_wmask | output byte mask one byte too wide | KILLED | stage1 failed |
| eng_min_fault | fault arbitration picks the HIGHEST element | KILLED | faults failed |
| eng_take_min | a later fault never replaces an earlier one | KILLED | faults failed |
| eng_drop | elements ahead of a front-end fault are discarded | KILLED | csr_in failed |
| eng_wr_perm | scatter checked for READ permission | KILLED | scatter_in failed |
| eng_align | table base alignment not checked | KILLED | faults failed |
| eng_buf | buffer range off by one | KILLED | stage1 failed |
| eng_idxlim | index limit never applied | KILLED | faults failed |
| eng_yrow | SpMV result stored at the wrong stride | KILLED | csr_in failed |
| eng_sx_sat | completion waits for orphan events (hang after a fault) | KILLED | csr_in failed |
| eng_close | index buffer never closes after a walker fault (hang) | KILLED | csr_in failed |
| wk_mono | empty rows rejected as non-monotonic | KILLED | csr_in failed |
| wk_nnz | row pointer bound off by one | KILLED | csr_in failed |
| wk_total | final row pointer != nnz accepted | KILLED | csr_in failed |
| wk_first | row_ptr[0] != 0 accepted | KILLED | csr_in failed |
| wk_col | column bound off by one | KILLED | csr_in failed |
| spmv_clear | rows accumulate into each other | KILLED | csr_in failed |
| spmv_emit | empty rows produce no result | SURVIVED |  |
| spmv_ovf | overflow flag never reported | KILLED | csrovf (acc20) failed |
| ib_sign | 32-bit signed indices never negative | KILLED | faults failed |
| sr_be | index array reads touch bytes before the array | KILLED | faults failed |
| eng_tag_ci | column reader responses routed to the row-pointer reader | KILLED | csr_in failed |
| eng_out_cnt | outstanding counter also counts a protocol-invalid response (the command never completes after SP_F_PROTO) | KILLED | s2_ooo failed |
| eng_sg_rot | scatter source lane rotation direction | KILLED | scatter_in failed |

## Survivors

* **co_err_data** - error data not zeroed. Believed equivalent: equivalent: ALP-RSP-05 (asserted by the link checker in every in-order run) makes the data of every non-OKAY response all-zero, so a conforming target never presents the non-zero data the mutant would pass through; the data of an errored beat is never written anyway
* **spmv_emit** - empty rows produce no result. Believed equivalent: equivalent: the walker's empty-row event always has first = last = 1 (sf_sparse_csr_walker W_EMPTY; the bench asserts it on every event), so `ev_last_i || !ev_nz_i` and `ev_last_i` are the same signal on every reachable input
