// =============================================================================
//  sf_sparse_request_coalescer.sv -- request table, coalescer, issue scheduler
//  (SilicaFlux P112).
//
//  The request table (RT) holds up to NRT distinct 16-byte-beat memory
//  requests.  A beat descriptor (one element's bytes inside one aligned beat)
//  is either MERGED into an existing entry or allocates a new one.  The RT
//  entry is also the response buffer: a read response is stored in the entry it
//  was issued from, and the reorder buffer (sf_sparse_reorder) reads it from
//  there.  Responses may therefore arrive in ANY order and are never dropped:
//  an entry cannot be reused until every consumer has released it.
//
//  READS (gather)
//    * descriptor -> pending entry of the same beat : merge (byte enables OR-ed)
//    * descriptor -> issued / completed entry whose byte enables already cover
//      the descriptor's bytes                       : duplicate hit, no new request
//    * otherwise                                     : new entry
//    Every accepted read descriptor takes one reorder slot (nref++).  The entry
//    is freed when its last consumer releases it.
//    Reads never change memory, so merging and deduplication cannot change the
//    result; they only change how many requests are sent.
//
//  WRITES (scatter)
//    * descriptor -> pending entry of the same beat : merge; bytes overwritten in
//      descriptor order, so the HIGHEST ELEMENT INDEX WINS (docs/02 section 5)
//    * otherwise : new entry.  If an older write to the same beat is still
//      pending or in flight the new entry DEPENDS on the youngest such entry and
//      is not issued before that one has completed, so two writes to one address
//      are never in flight together and the final value never depends on the
//      target's ordering.
//    A write entry is freed by its response.
//
//  ISSUE
//    An entry is eligible when it is pending, has not been touched in the
//    previous cycle (`fresh`: gives following descriptors a cycle to merge) and
//    has no unresolved dependency.  Selection prefers (burst mode) the entry that
//    continues the previously issued beat (address + 16), then an entry in the
//    same cache line, else the oldest.  A run of BURST_MAX continuations falls
//    back to oldest, so no entry can starve.  Selected requests go to a 2-entry
//    request FIFO; the link arbiter (engine top) takes them from there.
//    Merge decisions depend on registered state only.
//
//  The request tag is the RT index (tag[7:5] = 000, SP_TAGSRC_DATA).
//
//  Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_sparse_request_coalescer #(
  parameter int unsigned ADDR_W      = 48,
  parameter int unsigned NRT         = 16,     // request-table entries, 2..32
  parameter int unsigned ROB_DEPTH   = 32,     // bound on references to one entry
  parameter int unsigned LINE_BEATS  = 4,      // cache line = 64 B (CacheForge default), power of two
  parameter int unsigned BURST_MAX   = 4,
  parameter int unsigned BANK_LOG2   = 2       // banks assumed by the conflict estimator (beat-interleaved)
) (
  input  wire logic                  clk_i,
  input  wire logic                  rst_ni,
  input  wire logic                  cfg_merge_en_i,
  input  wire logic                  cfg_burst_en_i,
  // ---- descriptor in
  input  wire logic                  in_valid_i,
  output logic                       in_ready_o,
  input  wire logic                  in_wr_i,
  input  wire logic [ADDR_W-5:0]     in_beat_i,
  input  wire logic [15:0]           in_be_i,
  input  wire logic [127:0]          in_wdata_i,
  input  wire logic [31:0]           in_elem_i,
  input  wire logic                  rob_ready_i,      // a reorder slot is free (reads)
  output logic                       alloc_valid_o,    // a READ descriptor was accepted this cycle
  output logic [$clog2(NRT)-1:0]     alloc_rt_o,       // ... and this is the entry it refers to
  // ---- release of a consumed reference
  input  wire logic                  rel_valid_i,
  input  wire logic [$clog2(NRT)-1:0] rel_rt_i,
  // ---- read port for the reorder buffer (combinational)
  input  wire logic [$clog2(NRT)-1:0] rd_rt_i,
  output logic [127:0]               rd_data_o,
  output logic                       rd_done_o,
  output logic [3:0]                 rd_stat_o,
  // ---- request channel (to the link arbiter)
  output logic                       rq_valid_o,
  input  wire logic                  rq_ready_i,
  output logic                       rq_wr_o,
  output logic [ADDR_W-5:0]          rq_beat_o,
  output logic [15:0]                rq_be_o,
  output logic [127:0]               rq_wdata_o,
  output logic [7:0]                 rq_tag_o,
  // ---- response channel
  input  wire logic                  rs_valid_i,
  input  wire logic [4:0]            rs_idx_i,
  input  wire logic [127:0]          rs_data_i,
  input  wire logic [3:0]            rs_stat_i,
  // ---- write error report (one pulse per failed write entry)
  output logic                       werr_valid_o,
  output logic [31:0]                werr_elem_o,
  output logic [3:0]                 werr_stat_o,
  output logic [ADDR_W-5:0]          werr_beat_o,
  // ---- status / events
  output logic                       empty_o,
  output logic [$clog2(NRT+1)-1:0]   occ_o,
  output logic                       proto_err_o,
  output logic                       ev_merge_o,
  output logic                       ev_dup_o,
  output logic                       ev_cont_o,
  output logic                       ev_bank_o,
  output logic                       ev_stall_rt_o,
  output logic                       ev_stall_rob_o,
  output logic                       ev_lat_valid_o,
  output logic [15:0]                ev_lat_o
);
  localparam int unsigned RTW   = $clog2(NRT);
  localparam int unsigned BA_W  = ADDR_W - 4;
  localparam int unsigned NREFW = $clog2(ROB_DEPTH + 1);
  localparam int unsigned SEQW  = 8;
  localparam int unsigned LB    = $clog2(LINE_BEATS);
  localparam int unsigned RUNW  = 4;

  localparam logic [1:0] S_FREE = 2'd0, S_PEND = 2'd1, S_FLIGHT = 2'd2, S_DONE = 2'd3;

  if (NRT < 2 || NRT > 32)                        begin : g_c1 $error("NRT must be 2..32 (5-bit tag field)"); end
  if (LINE_BEATS < 1 || (LINE_BEATS & (LINE_BEATS - 1)) != 0) begin : g_c2 $error("LINE_BEATS must be a power of two"); end
  if (BURST_MAX < 1 || BURST_MAX >= (1 << RUNW))  begin : g_c3 $error("BURST_MAX out of range"); end

  // ---------------------------------------------------------------------------
  // request-table state (packed arrays: one vector per field)
  // ---------------------------------------------------------------------------
  logic [NRT-1:0][1:0]        st_q, st_d;
  logic [NRT-1:0]             wr_q, wr_d;
  logic [NRT-1:0][BA_W-1:0]   beat_q, beat_d;
  logic [NRT-1:0][15:0]       be_q, be_d;
  logic [NRT-1:0][127:0]      data_q, data_d;
  logic [NRT-1:0][NREFW-1:0]  nref_q, nref_d;
  logic [NRT-1:0]             fresh_q, fresh_d;
  logic [NRT-1:0][SEQW-1:0]   seq_q, seq_d;
  logic [NRT-1:0][3:0]        stat_q, stat_d;
  logic [NRT-1:0]             depv_q, depv_d;
  logic [NRT-1:0][RTW-1:0]    depi_q, depi_d;
  logic [NRT-1:0][31:0]       elem_q, elem_d;
  logic [NRT-1:0][15:0]       lat_q, lat_d;
  logic [SEQW-1:0]            seq_ctr_q, seq_ctr_d;

  // last issued beat (burst tracking)
  logic                       last_v_q, last_v_d, last_wr_q, last_wr_d;
  logic [BA_W-1:0]            last_beat_q, last_beat_d;
  logic [RUNW-1:0]            run_q, run_d;

  // request FIFO (2 entries), one packed vector per field
  logic [1:0]                 rqf_wr_q;
  logic [1:0][BA_W-1:0]       rqf_beat_q;
  logic [1:0][15:0]           rqf_be_q;
  logic [1:0][127:0]          rqf_wd_q;
  logic [1:0][7:0]            rqf_tag_q;
  logic                       rqf_rp_q, rqf_wp_q;
  logic [1:0]                 rqf_cnt_q;

  // ---------------------------------------------------------------------------
  // issue selection
  // ---------------------------------------------------------------------------
  logic [NRT-1:0]   elig, cont_m, line_m, sel_mask;
  logic             sel_found, sel_fire, use_burst, sel_is_cont;
  logic [RTW-1:0]   sel_idx;

  always_comb begin
    for (int i = 0; i < NRT; i++) begin
      elig[i]   = (st_q[i] == S_PEND) && !fresh_q[i] && !depv_q[i];
      cont_m[i] = elig[i] && last_v_q && (wr_q[i] == last_wr_q) && (beat_q[i] == last_beat_q + BA_W'(1));
      line_m[i] = elig[i] && last_v_q && (wr_q[i] == last_wr_q) &&
                  (beat_q[i][BA_W-1:LB] == last_beat_q[BA_W-1:LB]);
    end
    use_burst = cfg_burst_en_i && (run_q < RUNW'(BURST_MAX));
    if      (use_burst && (|cont_m)) sel_mask = cont_m;
    else if (use_burst && (|line_m)) sel_mask = line_m;
    else                             sel_mask = elig;
    sel_found = |elig;
    // oldest entry of sel_mask (wrap-safe sequence compare)
    sel_idx = '0;
    begin
      logic            have;
      logic [SEQW-1:0] best;
      logic [SEQW-1:0] diff;
      have = 1'b0;
      best = '0;
      for (int i = 0; i < NRT; i++) begin
        diff = seq_q[i] - best;
        if (sel_mask[i] && (!have || diff[SEQW-1])) begin
          have    = 1'b1;
          best    = seq_q[i];
          sel_idx = RTW'(i);
        end
      end
    end
    sel_fire    = sel_found && (rqf_cnt_q != 2'd2);
    sel_is_cont = cont_m[sel_idx];
  end

  // ---------------------------------------------------------------------------
  // descriptor match / allocate
  // ---------------------------------------------------------------------------
  logic [NRT-1:0] same, sel_now, pend_ok, cov_ok, match, free_v, fw;
  logic           any_match, any_free;
  logic [RTW-1:0] m_idx, a_idx, dep_idx;
  logic           dep_found, rd_desc, fire, do_merge, do_alloc;
  logic [RTW-1:0] tgt;

  always_comb begin
    for (int i = 0; i < NRT; i++) begin
      same[i]    = (st_q[i] != S_FREE) && (wr_q[i] == in_wr_i) && (beat_q[i] == in_beat_i);
      sel_now[i] = sel_fire && (sel_idx == RTW'(i));
      pend_ok[i] = same[i] && (st_q[i] == S_PEND) && !sel_now[i];
      cov_ok[i]  = same[i] && !in_wr_i &&
                   ((st_q[i] == S_FLIGHT) || (st_q[i] == S_DONE) || sel_now[i]) &&
                   ((in_be_i & ~be_q[i]) == 16'd0);
      match[i]   = cfg_merge_en_i && (pend_ok[i] || cov_ok[i]);
      free_v[i]  = (st_q[i] == S_FREE);
    end
    any_match = |match;
    any_free  = |free_v;
    m_idx = '0; a_idx = '0;
    for (int i = NRT - 1; i >= 0; i--) begin
      if (match[i])  m_idx = RTW'(i);
      if (free_v[i]) a_idx = RTW'(i);
    end
    // youngest older write to the same beat (pending, selected now or in flight)
    dep_found = 1'b0;
    dep_idx   = '0;
    begin
      logic [SEQW-1:0] best, diff;
      best = '0;
      for (int i = 0; i < NRT; i++) begin
        fw[i] = in_wr_i && same[i] && ((st_q[i] == S_PEND) || (st_q[i] == S_FLIGHT));
        diff  = seq_q[i] - best;
        if (fw[i] && (!dep_found || !diff[SEQW-1])) begin     // younger than the best so far
          dep_found = 1'b1;
          best      = seq_q[i];
          dep_idx   = RTW'(i);
        end
      end
    end
    rd_desc    = !in_wr_i;
    in_ready_o = (!rd_desc || rob_ready_i) && (any_match || any_free);
    fire       = in_valid_i && in_ready_o;
    do_merge   = fire && any_match;
    do_alloc   = fire && !any_match;
    tgt        = any_match ? m_idx : a_idx;
  end

  assign alloc_valid_o = fire && rd_desc;
  assign alloc_rt_o    = tgt;

  // ---------------------------------------------------------------------------
  // response
  // ---------------------------------------------------------------------------
  wire             rs_in_range = ({1'b0, rs_idx_i} < 6'(NRT));     // 6 bits: NRT = 32 does not fit in 5
  wire [RTW-1:0]   rs_i        = rs_idx_i[RTW-1:0];
  wire             rs_ok       = rs_valid_i && rs_in_range && (st_q[rs_i] == S_FLIGHT);
  assign proto_err_o = rs_valid_i && !rs_ok;

  // ---------------------------------------------------------------------------
  // next-state
  // ---------------------------------------------------------------------------
  logic [127:0] expand_be;
  always_comb begin
    st_d = st_q; wr_d = wr_q; beat_d = beat_q; be_d = be_q; data_d = data_q; nref_d = nref_q;
    stat_d = stat_q; depv_d = depv_q; depi_d = depi_q; elem_d = elem_q; seq_d = seq_q;
    seq_ctr_d = seq_ctr_q;
    last_v_d = last_v_q; last_wr_d = last_wr_q; last_beat_d = last_beat_q; run_d = run_q;
    fresh_d = '0;                                   // freshness lasts one cycle unless renewed below
    for (int i = 0; i < NRT; i++) lat_d[i] = (st_q[i] == S_FLIGHT) ? ((lat_q[i] == 16'hFFFF) ? lat_q[i] : lat_q[i] + 16'd1) : lat_q[i];

    for (int b = 0; b < 16; b++) expand_be[b*8 +: 8] = {8{in_be_i[b]}};

    // ---- selection
    if (sel_fire) begin
      st_d[sel_idx]  = S_FLIGHT;
      lat_d[sel_idx] = 16'd0;
      last_v_d       = 1'b1;
      last_wr_d      = wr_q[sel_idx];
      last_beat_d    = beat_q[sel_idx];
      run_d          = sel_is_cont ? ((run_q == RUNW'(BURST_MAX)) ? run_q : run_q + RUNW'(1)) : RUNW'(1);
    end

    // ---- response
    if (rs_ok) begin
      if (wr_q[rs_i]) begin
        st_d[rs_i] = S_FREE;
      end else begin
        st_d[rs_i]   = S_DONE;
        data_d[rs_i] = (rs_stat_i == 4'd0) ? rs_data_i : 128'd0;
      end
      stat_d[rs_i] = rs_stat_i;
      for (int j = 0; j < NRT; j++)
        if (depv_q[j] && (depi_q[j] == rs_i)) depv_d[j] = 1'b0;
    end

    // ---- reference counting and freeing of completed read entries
    for (int i = 0; i < NRT; i++) begin
      nref_d[i] = nref_q[i]
                + NREFW'((fire && rd_desc && (tgt == RTW'(i))) ? 1 : 0)
                - NREFW'((rel_valid_i && (rel_rt_i == RTW'(i))) ? 1 : 0);
      if ((st_q[i] == S_DONE) && (nref_d[i] == '0)) begin
        st_d[i]   = S_FREE;
        depv_d[i] = 1'b0;
      end
    end

    // ---- merge into a pending entry
    if (do_merge && pend_ok[m_idx]) begin
      be_d[m_idx]    = be_q[m_idx] | in_be_i;
      if (in_wr_i) data_d[m_idx] = (data_q[m_idx] & ~expand_be) | (in_wdata_i & expand_be);
      fresh_d[m_idx] = 1'b1;
    end

    // ---- allocate
    if (do_alloc) begin
      st_d[a_idx]    = S_PEND;
      wr_d[a_idx]    = in_wr_i;
      beat_d[a_idx]  = in_beat_i;
      be_d[a_idx]    = in_be_i;
      data_d[a_idx]  = in_wr_i ? (in_wdata_i & expand_be) : 128'd0;
      stat_d[a_idx]  = 4'd0;
      fresh_d[a_idx] = 1'b1;
      seq_d[a_idx]   = seq_ctr_q;
      seq_ctr_d      = seq_ctr_q + SEQW'(1);
      elem_d[a_idx]  = in_elem_i;
      // a dependency whose response arrives in this very cycle is already resolved:
      // nobody would clear it later (the response clears only entries that already exist)
      depv_d[a_idx]  = dep_found && !(rs_ok && (rs_i == dep_idx));
      depi_d[a_idx]  = dep_idx;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q       <= '0;
      nref_q     <= '0;
      depv_q     <= '0;
      fresh_q    <= '0;
      seq_ctr_q  <= '0;
      last_v_q   <= 1'b0;
      run_q      <= '0;
      rqf_cnt_q  <= '0;
      rqf_rp_q   <= 1'b0;
      rqf_wp_q   <= 1'b0;
    end else begin
      st_q      <= st_d;
      nref_q    <= nref_d;
      depv_q    <= depv_d;
      fresh_q   <= fresh_d;
      seq_ctr_q <= seq_ctr_d;
      last_v_q  <= last_v_d;
      run_q     <= run_d;
      if (sel_fire)                       begin rqf_wp_q <= ~rqf_wp_q; end
      if (rq_valid_o && rq_ready_i)       begin rqf_rp_q <= ~rqf_rp_q; end
      rqf_cnt_q <= rqf_cnt_q + 2'(sel_fire) - 2'(rq_valid_o && rq_ready_i);
    end
  end

  always_ff @(posedge clk_i) begin
    wr_q        <= wr_d;
    beat_q      <= beat_d;
    be_q        <= be_d;
    data_q      <= data_d;
    stat_q      <= stat_d;
    depi_q      <= depi_d;
    seq_q       <= seq_d;
    elem_q      <= elem_d;
    lat_q       <= lat_d;
    last_wr_q   <= last_wr_d;
    last_beat_q <= last_beat_d;
    if (sel_fire) begin
      rqf_wr_q[rqf_wp_q]   <= wr_q[sel_idx];
      rqf_beat_q[rqf_wp_q] <= beat_q[sel_idx];
      rqf_be_q[rqf_wp_q]   <= be_q[sel_idx];
      rqf_wd_q[rqf_wp_q]   <= data_q[sel_idx];
      rqf_tag_q[rqf_wp_q]  <= {sf_sparse_pkg::SP_TAGSRC_DATA, 5'(sel_idx)};
    end
  end

  // ---------------------------------------------------------------------------
  // outputs
  // ---------------------------------------------------------------------------
  assign rq_valid_o = (rqf_cnt_q != 2'd0);
  assign rq_wr_o    = rqf_wr_q[rqf_rp_q];
  assign rq_beat_o  = rqf_beat_q[rqf_rp_q];
  assign rq_be_o    = rqf_be_q[rqf_rp_q];
  assign rq_wdata_o = rqf_wd_q[rqf_rp_q];
  assign rq_tag_o   = rqf_tag_q[rqf_rp_q];

  assign rd_data_o  = data_q[rd_rt_i];
  assign rd_done_o  = (st_q[rd_rt_i] == S_DONE);
  assign rd_stat_o  = stat_q[rd_rt_i];

  assign werr_valid_o = rs_ok && wr_q[rs_i] && (rs_stat_i != 4'd0);
  assign werr_elem_o  = elem_q[rs_i];
  assign werr_stat_o  = rs_stat_i;
  assign werr_beat_o  = beat_q[rs_i];

  always_comb begin
    occ_o = '0;
    for (int i = 0; i < NRT; i++) occ_o = occ_o + ($bits(occ_o))'(st_q[i] != S_FREE);
  end
  assign empty_o = (occ_o == '0) && (rqf_cnt_q == 2'd0);

  // events
  logic bank_hit;
  always_comb begin
    bank_hit = 1'b0;
    for (int i = 0; i < NRT; i++)
      if ((st_q[i] == S_FLIGHT) && (RTW'(i) != sel_idx) &&
          (beat_q[i][BANK_LOG2-1:0] == beat_q[sel_idx][BANK_LOG2-1:0])) bank_hit = 1'b1;
  end
  assign ev_merge_o     = do_merge && pend_ok[m_idx];
  assign ev_dup_o       = do_merge && !pend_ok[m_idx];
  assign ev_cont_o      = sel_fire && sel_is_cont;
  assign ev_bank_o      = sel_fire && bank_hit;
  assign ev_stall_rt_o  = in_valid_i && !in_ready_o && (!rd_desc ? 1'b1 : rob_ready_i);
  assign ev_stall_rob_o = in_valid_i && !in_ready_o && rd_desc && !rob_ready_i;
  assign ev_lat_valid_o = rs_ok;
  assign ev_lat_o       = lat_q[rs_i] + 16'd1;

endmodule

`default_nettype wire
