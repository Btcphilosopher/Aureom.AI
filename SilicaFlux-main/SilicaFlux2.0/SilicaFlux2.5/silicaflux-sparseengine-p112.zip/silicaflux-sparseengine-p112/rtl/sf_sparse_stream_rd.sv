// =============================================================================
//  sf_sparse_stream_rd.sv -- linear array stream reader (SilicaFlux P112)
//
//  Reads `count` consecutive elements of 1/2/4/8 bytes starting at `base` and
//  presents them in order, one per cycle.  Used for the index array of a
//  gather / scatter and for the row-pointer, column-index and value arrays of
//  a CSR matrix.
//
//  Memory side (ALP v1 beats):
//    * one READ per 16-byte beat that the array touches, ascending;
//    * the byte enables are EXACTLY the lanes that belong to the array: a beat
//      shared with a neighbouring object never asks for the neighbour's bytes
//      (the caller validated the array extent [base, base + count*esz) with the
//      MemoryGuard checker, so every enabled byte is a validated byte);
//    * the beat stays on `rq_*` with stable payload until accepted (ALP-REQ-02):
//      once `rq_valid_o` has been shown it is never withdrawn, not even by flush;
//    * up to NSLOT beats are in flight.  The slot number travels in the tag, so
//      responses may arrive in ANY order; elements are always delivered in order.
//
//  Alignment contract: base must be a multiple of the element size (checked by
//  the caller), so an element never straddles a beat.
//
//  flush_i: stop issuing, discard stored data.  busy_o stays high until every
//  request already on the link has been answered, so no response can arrive
//  for a reader that has been restarted.
//
//  Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_sparse_stream_rd #(
  parameter int unsigned ADDR_W = 48,
  parameter int unsigned NSLOT  = 4          // power of two, 2..8
) (
  input  wire logic                  clk_i,
  input  wire logic                  rst_ni,
  // ---- control
  input  wire logic                  start_i,       // pulse; ignored while busy
  input  wire logic [ADDR_W-1:0]     base_i,
  input  wire logic [1:0]            esz_log2_i,    // element bytes = 1 << esz_log2_i
  input  wire logic [31:0]           count_i,       // number of elements (0 = nothing to do)
  input  wire logic                  flush_i,
  output logic                       busy_o,
  // ---- request channel (to the link arbiter)
  output logic                       rq_valid_o,
  input  wire logic                  rq_ready_i,
  output logic [ADDR_W-5:0]          rq_beat_o,     // beat address = byte address >> 4
  output logic [15:0]                rq_be_o,
  output logic [$clog2(NSLOT)-1:0]   rq_slot_o,
  // ---- response channel (routed by tag)
  input  wire logic                  rs_valid_i,
  input  wire logic [$clog2(NSLOT)-1:0] rs_slot_i,
  input  wire logic [127:0]          rs_data_i,
  input  wire logic                  rs_err_i,
  // ---- element stream
  output logic                       out_valid_o,
  input  wire logic                  out_ready_i,
  output logic [63:0]                out_data_o,
  output logic                       out_err_o,     // the beat holding this element came back with an error
  output logic                       out_last_o
);
  localparam int unsigned SLW  = $clog2(NSLOT);
  localparam int unsigned BA_W = ADDR_W - 4;

  if (NSLOT < 2 || NSLOT > 8 || (NSLOT & (NSLOT - 1)) != 0) begin : g_chk
    $error("sf_sparse_stream_rd: NSLOT must be a power of two in 2..8");
  end

  function automatic logic [15:0] be_range(input logic [4:0] lo, input logic [4:0] hi_excl);
    logic [15:0] r;
    for (int i = 0; i < 16; i++) r[i] = (5'(i) >= lo) && (5'(i) < hi_excl);
    be_range = r;
  endfunction

  // ---------------------------------------------------------------------------
  // state
  // ---------------------------------------------------------------------------
  logic                run_q, flushing_q, rq_lock_q;
  logic [ADDR_W-1:0]   base_q;
  logic [1:0]          esz_q;
  logic [3:0]          lane0_q;
  logic [31:0]         nbeats_q;          // beats the array touches
  logic [4:0]          last_hi_q;         // exclusive upper lane of the last beat (1..16)
  // issue side
  logic [31:0]         iss_j_q;           // next beat to request (0 .. nbeats-1)
  logic [SLW-1:0]      iss_slot_q;
  logic [7:0]          outst_q;           // requests on the link not yet answered
  // slots
  logic [NSLOT-1:0]    sl_busy_q, sl_val_q, sl_err_q;
  logic [127:0]        sl_data_q [NSLOT];
  // extractor
  logic [SLW-1:0]      ex_slot_q;
  logic [31:0]         ex_j_q;
  logic [4:0]          ex_lane_q;
  logic [31:0]         rem_q;

  // ---------------------------------------------------------------------------
  // start-up arithmetic (combinational on the start inputs, registered on start)
  // ---------------------------------------------------------------------------
  logic [35:0] s_bytes, s_end, s_nbeats;
  logic [3:0]  s_end_lo;
  always_comb begin
    s_bytes  = 36'(count_i) << esz_log2_i;
    s_end    = 36'(base_i[3:0]) + s_bytes;
    s_nbeats = (s_end + 36'd15) >> 4;
    s_end_lo = s_end[3:0];
  end

  wire start_ok = start_i && !busy_o && (count_i != 32'd0);

  // ---------------------------------------------------------------------------
  // issue
  // ---------------------------------------------------------------------------
  wire        iss_more = run_q && !flushing_q && (iss_j_q < nbeats_q);
  wire        can_iss  = iss_more && !sl_busy_q[iss_slot_q];
  wire [4:0]  iss_lo   = (iss_j_q == 32'd0) ? {1'b0, lane0_q} : 5'd0;
  wire [4:0]  iss_hi   = (iss_j_q == nbeats_q - 32'd1) ? last_hi_q : 5'd16;

  assign rq_valid_o = rq_lock_q | can_iss;
  assign rq_beat_o  = base_q[ADDR_W-1:4] + BA_W'(iss_j_q);
  assign rq_be_o    = be_range(iss_lo, iss_hi);
  assign rq_slot_o  = iss_slot_q;

  wire rq_fire = rq_valid_o && rq_ready_i;

  // ---------------------------------------------------------------------------
  // extractor
  // ---------------------------------------------------------------------------
  wire [4:0]  ex_hi    = (ex_j_q == nbeats_q - 32'd1) ? last_hi_q : 5'd16;
  wire        head_val = run_q && !flushing_q && sl_val_q[ex_slot_q];
  wire [4:0]  esz_b    = 5'd1 << esz_q;
  wire [4:0]  nxt_lane = ex_lane_q + esz_b;

  logic [127:0] ex_word;
  always_comb begin
    ex_word    = sl_data_q[ex_slot_q] >> {ex_lane_q[3:0], 3'b000};
    out_data_o = '0;
    case (esz_q)
      2'd0:    out_data_o[7:0]  = ex_word[7:0];
      2'd1:    out_data_o[15:0] = ex_word[15:0];
      2'd2:    out_data_o[31:0] = ex_word[31:0];
      default: out_data_o[63:0] = ex_word[63:0];
    endcase
  end
  assign out_valid_o = head_val && (rem_q != 32'd0);
  assign out_err_o   = sl_err_q[ex_slot_q];
  assign out_last_o  = (rem_q == 32'd1);

  wire out_fire  = out_valid_o && out_ready_i;
  wire beat_done = out_fire && ((nxt_lane >= ex_hi) || (rem_q == 32'd1));

  assign busy_o = run_q || flushing_q || (outst_q != 8'd0) || rq_lock_q;

  // ---------------------------------------------------------------------------
  // sequential
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      run_q      <= 1'b0;
      flushing_q <= 1'b0;
      rq_lock_q  <= 1'b0;
      iss_j_q    <= '0;
      iss_slot_q <= '0;
      outst_q    <= '0;
      sl_busy_q  <= '0;
      sl_val_q   <= '0;
      sl_err_q   <= '0;
      ex_slot_q  <= '0;
      ex_j_q     <= '0;
      ex_lane_q  <= '0;
      rem_q      <= '0;
    end else begin
      rq_lock_q <= rq_valid_o && !rq_ready_i;

      // ---- start
      if (start_ok) begin
        run_q      <= 1'b1;
        iss_j_q    <= '0;
        iss_slot_q <= '0;
        ex_slot_q  <= '0;
        ex_j_q     <= '0;
        ex_lane_q  <= {1'b0, base_i[3:0]};
        rem_q      <= count_i;
        sl_busy_q  <= '0;
        sl_val_q   <= '0;
        sl_err_q   <= '0;
      end

      // ---- issue
      if (rq_fire) begin
        sl_busy_q[iss_slot_q] <= 1'b1;
        iss_j_q               <= iss_j_q + 32'd1;
        iss_slot_q            <= iss_slot_q + SLW'(1);
      end

      // ---- response
      if (rs_valid_i) begin
        if (flushing_q || !run_q) begin
          sl_busy_q[rs_slot_i] <= 1'b0;           // discard
          sl_val_q[rs_slot_i]  <= 1'b0;
        end else begin
          sl_val_q[rs_slot_i]  <= 1'b1;
          sl_err_q[rs_slot_i]  <= rs_err_i;
        end
      end
      outst_q <= outst_q + 8'(rq_fire) - 8'(rs_valid_i);

      // ---- extraction
      if (out_fire) begin
        rem_q     <= rem_q - 32'd1;
        ex_lane_q <= nxt_lane;
      end
      if (beat_done) begin
        sl_val_q[ex_slot_q]  <= 1'b0;
        sl_busy_q[ex_slot_q] <= 1'b0;
        ex_slot_q            <= ex_slot_q + SLW'(1);
        ex_j_q               <= ex_j_q + 32'd1;
        ex_lane_q            <= 5'd0;
      end
      if (out_fire && out_last_o) run_q <= 1'b0;

      // ---- flush
      if (flush_i && (run_q || outst_q != 8'd0 || rq_lock_q)) begin
        run_q      <= 1'b0;
        flushing_q <= 1'b1;
        sl_val_q   <= '0;
        sl_busy_q  <= sl_busy_q & ~sl_val_q;
      end
      if (flushing_q && (outst_q == 8'd0) && !rq_lock_q) begin
        flushing_q <= 1'b0;
        sl_busy_q  <= '0;
        sl_val_q   <= '0;
      end
    end
  end

  // datapath storage: not reset
  always_ff @(posedge clk_i) begin
    if (start_ok) begin
      base_q    <= base_i;
      esz_q     <= esz_log2_i;
      lane0_q   <= base_i[3:0];
      nbeats_q  <= s_nbeats[31:0];
      last_hi_q <= (s_end_lo == 4'd0) ? 5'd16 : {1'b0, s_end_lo};
    end
    if (rs_valid_i && !(flushing_q || !run_q)) sl_data_q[rs_slot_i] <= rs_data_i;
  end

endmodule

`default_nettype wire
