// =============================================================================
//  sf_sparse_index_buffer.sv -- bounded index buffer (SilicaFlux P112)
//
//  Supplies the element index stream of a gather / scatter, one index per
//  cycle, from either
//    * an index array in memory (8 / 16 / 32-bit elements, fetched beat by beat
//      through sf_sparse_stream_rd; the raw beats are held in the reader's
//      NSLOT slots and the extracted indices pass through a DEPTH-entry FIFO), or
//    * the `push_*` port (host or CSR walker supplies the indices).
//
//  Index interpretation (docs/02 section 4):
//    * the raw index has `w` = 8 << w_log2 bits; it is ZERO-extended to IDX_W;
//    * signed mode: the top bit of the raw index is the sign; a negative index
//      is reported through idx_neg_o (the engine turns it into SP_F_NEG_INDEX);
//      no sign extension is needed because a negative index is never used.
//
//  Every stage is lossless under back-pressure: the FIFO accepts an element
//  only when it has room, the reader's slots hold their beats until extracted.
//
//  flush_i abandons the current command: the FIFO is emptied and the reader is
//  flushed (busy_o stays high until no request is left on the link).
//
//  Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_sparse_index_buffer #(
  parameter int unsigned ADDR_W = 48,
  parameter int unsigned IDX_W  = 32,
  parameter int unsigned NSLOT  = 4,
  parameter int unsigned DEPTH  = 4           // element FIFO entries (power of two)
) (
  input  wire logic                  clk_i,
  input  wire logic                  rst_ni,
  // ---- control
  input  wire logic                  start_i,
  input  wire logic                  src_push_i,     // 1: take indices from push_*, 0: fetch from memory
  input  wire logic [ADDR_W-1:0]     base_i,
  input  wire logic [1:0]            w_log2_i,       // 0: 8 bit, 1: 16 bit, 2: 32 bit
  input  wire logic                  signed_i,
  input  wire logic [31:0]           count_i,
  input  wire logic                  flush_i,
  input  wire logic                  close_i,        // no more indices will be pushed: finish with what is buffered
  output logic                       busy_o,
  output logic                       done_o,         // all `count` indices have left the buffer
  // ---- memory index fetch (to the link arbiter)
  output logic                       rq_valid_o,
  input  wire logic                  rq_ready_i,
  output logic [ADDR_W-5:0]          rq_beat_o,
  output logic [15:0]                rq_be_o,
  output logic [$clog2(NSLOT)-1:0]   rq_slot_o,
  input  wire logic                  rs_valid_i,
  input  wire logic [$clog2(NSLOT)-1:0] rs_slot_i,
  input  wire logic [127:0]          rs_data_i,
  input  wire logic                  rs_err_i,
  // ---- push port
  input  wire logic                  push_valid_i,
  output logic                       push_ready_o,
  input  wire logic [IDX_W-1:0]      push_data_i,
  // ---- index stream out
  output logic                       idx_valid_o,
  input  wire logic                  idx_ready_i,
  output logic [IDX_W-1:0]           idx_val_o,
  output logic                       idx_neg_o,
  output logic                       idx_err_o       // index array read returned an error
);
  localparam int unsigned PW = (DEPTH > 1) ? $clog2(DEPTH) : 1;

  if (IDX_W < 32) begin : g_chk
    $error("sf_sparse_index_buffer: IDX_W must be >= 32 (32-bit indices are supported)");
  end

  logic                run_q, push_mode_q, signed_q;
  logic [1:0]          w_q;
  logic [31:0]         in_cnt_q, out_cnt_q, count_q;

  // ---- reader
  logic                rd_busy, rd_out_valid, rd_out_ready, rd_out_err, rd_out_last;
  logic [63:0]         rd_out_data;
  wire                 rd_start = start_i && !busy_o && !src_push_i && (count_i != 32'd0);
  wire                 rd_flush = flush_i;

  sf_sparse_stream_rd #(.ADDR_W(ADDR_W), .NSLOT(NSLOT)) u_rd (
    .clk_i, .rst_ni,
    .start_i(rd_start), .base_i, .esz_log2_i(w_log2_i), .count_i, .flush_i(rd_flush), .busy_o(rd_busy),
    .rq_valid_o, .rq_ready_i, .rq_beat_o, .rq_be_o, .rq_slot_o,
    .rs_valid_i, .rs_slot_i, .rs_data_i, .rs_err_i,
    .out_valid_o(rd_out_valid), .out_ready_i(rd_out_ready), .out_data_o(rd_out_data),
    .out_err_o(rd_out_err), .out_last_o(rd_out_last)
  );
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_last = rd_out_last;
  /* verilator lint_on UNUSEDSIGNAL */

  // ---- element FIFO  (entry = {err, neg, value})
  logic [IDX_W+1:0] mem_q [DEPTH];
  logic [PW-1:0]    wp_q, rp_q;
  logic [PW:0]      cnt_q;
  wire              fifo_full  = (cnt_q == (PW+1)'(DEPTH));
  wire              fifo_empty = (cnt_q == '0);

  // field extraction
  logic [IDX_W-1:0] rd_val, push_val;
  logic             rd_neg, push_neg;
  always_comb begin
    rd_val = '0; push_val = '0; rd_neg = 1'b0; push_neg = 1'b0;
    case (w_q)
      2'd0: begin
        rd_val[7:0]    = rd_out_data[7:0];    rd_neg   = signed_q && rd_out_data[7];
        push_val[7:0]  = push_data_i[7:0];    push_neg = signed_q && push_data_i[7];
      end
      2'd1: begin
        rd_val[15:0]   = rd_out_data[15:0];   rd_neg   = signed_q && rd_out_data[15];
        push_val[15:0] = push_data_i[15:0];   push_neg = signed_q && push_data_i[15];
      end
      default: begin
        rd_val[31:0]   = rd_out_data[31:0];   rd_neg   = signed_q && rd_out_data[31];
        push_val[31:0] = push_data_i[31:0];   push_neg = signed_q && push_data_i[31];
      end
    endcase
  end

  wire [31:0] cnt_eff = close_i ? in_cnt_q : count_q;
  wire in_room   = run_q && !fifo_full && !close_i && (in_cnt_q != count_q);
  assign push_ready_o  = in_room && push_mode_q;
  assign rd_out_ready  = in_room && !push_mode_q;
  wire push_fire = push_valid_i && push_ready_o;
  wire rd_fire   = rd_out_valid && rd_out_ready;
  wire fifo_wr   = push_fire || rd_fire;
  wire fifo_rd   = idx_valid_o && idx_ready_i;

  assign idx_valid_o = !fifo_empty;
  assign idx_val_o   = mem_q[rp_q][IDX_W-1:0];
  assign idx_neg_o   = mem_q[rp_q][IDX_W];
  assign idx_err_o   = mem_q[rp_q][IDX_W+1];

  assign done_o = !run_q;           // run_q drops when the last index has been taken
  assign busy_o = run_q || rd_busy;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      run_q       <= 1'b0;
      push_mode_q <= 1'b0;
      signed_q    <= 1'b0;
      w_q         <= '0;
      in_cnt_q    <= '0;
      out_cnt_q   <= '0;
      count_q     <= '0;
      wp_q        <= '0;
      rp_q        <= '0;
      cnt_q       <= '0;
    end else begin
      if (start_i && !busy_o && (count_i != 32'd0)) begin
        run_q       <= 1'b1;
        push_mode_q <= src_push_i;
        signed_q    <= signed_i;
        w_q         <= w_log2_i;
        count_q     <= count_i;
        in_cnt_q    <= '0;
        out_cnt_q   <= '0;
        wp_q        <= '0;
        rp_q        <= '0;
        cnt_q       <= '0;
      end
      if (fifo_wr) begin
        wp_q     <= wp_q + PW'(1);
        in_cnt_q <= in_cnt_q + 32'd1;
      end
      if (close_i && run_q) count_q <= in_cnt_q;           // the producer stopped early (CSR fault): drain, then end
      if (fifo_rd) begin
        rp_q      <= rp_q + PW'(1);
        out_cnt_q <= out_cnt_q + 32'd1;
        if (out_cnt_q == cnt_eff - 32'd1) run_q <= 1'b0;
      end else if (close_i && run_q && (out_cnt_q == in_cnt_q)) begin
        run_q <= 1'b0;                                      // nothing buffered: end now
      end
      cnt_q <= cnt_q + (PW+1)'(fifo_wr) - (PW+1)'(fifo_rd);
      if (flush_i) begin
        run_q <= 1'b0;
        wp_q  <= '0;
        rp_q  <= '0;
        cnt_q <= '0;
      end
    end
  end

  always_ff @(posedge clk_i) begin
    if (push_fire)    mem_q[wp_q] <= {1'b0, push_neg, push_val};
    else if (rd_fire) mem_q[wp_q] <= {rd_out_err, rd_neg, rd_val};
  end

endmodule

`default_nettype wire
