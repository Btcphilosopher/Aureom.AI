// =============================================================================
//  sf_sparse_tensor_adapter.sv -- gathered operands -> TensorScratch operand tile
//  (SilicaFlux P112).
//
//  Moves rows that a gather left contiguous in the engine's output buffer into
//  the A and/or B operand region of the CURRENT FILL SET of the TensorScratch
//  (Project 75) through its write-only DMA fill port, assembling them into the
//  row-major tile the tile sequencer expects (row pitch `dst_pitch`).
//
//  One transfer = one fill session on the scratchpad:
//      validate  ->  fill_begin  ->  A segment  ->  B segment  ->  drain
//      responses  ->  fill_end
//
//  Not overwriting active operand buffers:
//    * the adapter never chooses a set: the scratchpad grants a FREE set on
//      fill_begin (it waits, ready low, while no set is free) and reports it in
//      fill_set_i;
//    * before the first write and before EVERY write the adapter checks that its
//      set is in the FILLING state (own_check_en_i); if not it stops with
//      ADP_E_OWNER and writes nothing more;
//    * independently, the scratchpad refuses (err 6 OWNER) any write into a set
//      that is not FILLING; that response is also reported as ADP_E_OWNER;
//    * parameters are validated BEFORE the scratchpad is touched: an invalid
//      command has no side effect at all (ADP_E_PARAM).
//
//  The output buffer read port is shared with the host: the integrator muxes
//  ob_raddr_o in while busy_o is high.
//
//  Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_sparse_tensor_adapter #(
  parameter int unsigned OBUF_BYTES   = 8192,
  parameter int unsigned WB           = 4,           // scratchpad word bytes (power of two, <= 16)
  parameter int unsigned TS_ADDR_W    = 32,
  parameter int unsigned TS_TAG_W     = 8,
  parameter int unsigned NSETS        = 2,
  parameter int unsigned A_SET_BYTES  = 4096,
  parameter int unsigned B_SET_BYTES  = 4096,
  parameter logic [63:0] DMA_BASE     = 64'h0
) (
  input  wire logic                       clk_i,
  input  wire logic                       rst_ni,
  // ---- command
  input  wire logic                       go_i,
  input  wire logic                       own_check_en_i,      // 1 in operation; 0 only to prove the scratchpad's own refusal
  input  wire logic                       param_check_en_i,    // 1 in operation; 0 only to provoke scratchpad-side range errors
  // segment A (region A) and B (region B); *_rows = 0 disables the segment
  input  wire logic [$clog2(OBUF_BYTES)-1:0] a_src_off_i,
  input  wire logic [15:0]                a_rows_i,
  input  wire logic [15:0]                a_row_bytes_i,
  input  wire logic [15:0]                a_src_pitch_i,
  input  wire logic [15:0]                a_dst_off_i,         // byte offset inside the set's A region
  input  wire logic [15:0]                a_dst_pitch_i,
  input  wire logic [$clog2(OBUF_BYTES)-1:0] b_src_off_i,
  input  wire logic [15:0]                b_rows_i,
  input  wire logic [15:0]                b_row_bytes_i,
  input  wire logic [15:0]                b_src_pitch_i,
  input  wire logic [15:0]                b_dst_off_i,
  input  wire logic [15:0]                b_dst_pitch_i,
  // ---- status
  output logic                            busy_o,
  output logic                            done_o,              // pulse
  output logic                            err_o,               // valid with done_o
  output logic [2:0]                      err_code_o,          // ADP_E_*
  output logic [31:0]                     words_o,             // words written to the scratchpad
  // ---- output buffer read port (1-cycle latency)
  output logic [$clog2(OBUF_BYTES/16)-1:0] ob_raddr_o,
  input  wire logic [127:0]               ob_rdata_i,
  // ---- TensorScratch fill port
  output logic                            dma_req_valid_o,
  input  wire logic                       dma_req_ready_i,
  output logic                            dma_req_we_o,
  output logic [TS_ADDR_W-1:0]            dma_req_addr_o,
  output logic [8*WB-1:0]                 dma_req_wdata_o,
  output logic [WB-1:0]                   dma_req_wstrb_o,
  output logic [TS_TAG_W-1:0]             dma_req_tag_o,
  input  wire logic                       dma_rsp_valid_i,
  output logic                            dma_rsp_ready_o,
  input  wire logic                       dma_rsp_err_i,
  input  wire logic [2:0]                 dma_rsp_err_code_i,
  // ---- TensorScratch ownership handshake
  output logic                            fill_begin_valid_o,
  input  wire logic                       fill_begin_ready_i,
  output logic                            fill_end_valid_o,
  input  wire logic                       fill_end_ready_i,
  input  wire logic [(NSETS > 1 ? $clog2(NSETS) : 1)-1:0] fill_set_i,
  input  wire logic [NSETS*2-1:0]         set_state_i
);
  localparam int unsigned OBW  = $clog2(OBUF_BYTES);
  localparam int unsigned SETW = (NSETS > 1) ? $clog2(NSETS) : 1;
  localparam int unsigned A_TOT  = NSETS * A_SET_BYTES;
  localparam int unsigned B_TOT  = NSETS * B_SET_BYTES;
  localparam int unsigned REGION = (A_TOT > B_TOT) ? A_TOT : B_TOT;

  // error codes
  localparam logic [2:0] ADP_E_NONE  = 3'd0;
  localparam logic [2:0] ADP_E_PARAM = 3'd1;   // command rejected before any side effect
  localparam logic [2:0] ADP_E_OWNER = 3'd2;   // set not FILLING (own check) or scratchpad answered OWNER
  localparam logic [2:0] ADP_E_RANGE = 3'd3;   // scratchpad answered RANGE
  localparam logic [2:0] ADP_E_ALIGN = 3'd4;   // scratchpad answered ALIGN
  localparam logic [2:0] ADP_E_OTHER = 3'd5;   // any other scratchpad error
  localparam logic [1:0] TS_FILLING  = 2'd1;

  typedef enum logic [3:0] {A_IDLE, A_BEGIN, A_SEG, A_RD, A_RDW, A_WR, A_DRAIN, A_END, A_DONE} astate_e;
  astate_e st_q;

  // latched command
  logic [1:0]            seg_en_q;
  logic [OBW-1:0]        src_off_q [2];
  logic [15:0]           rows_q [2], rowb_q [2], spitch_q [2], doff_q [2], dpitch_q [2];
  logic                  seg_q;                  // 0 = A, 1 = B
  logic [15:0]           r_q;                    // row within the segment
  logic [15:0]           w_q;                    // word within the row
  logic [31:0]           words_q;
  logic [7:0]            outst_q;
  logic                  err_q;
  logic [2:0]            code_q;
  logic                  own_en_q;
  // The scratchpad updates fill_set / set_state in the cycle AFTER it accepts fill_begin and holds them for the whole
  // session, so they are read directly (never sampled in the handshake cycle itself).
  wire  [SETW-1:0]       set_q = fill_set_i;
  logic [8*WB-1:0]       wd_q;

  // ---- parameter validation (combinational on the command inputs)
  function automatic logic seg_ok(input logic [15:0] rows, input logic [15:0] rowb, input logic [15:0] spitch,
                                  input logic [15:0] doff, input logic [15:0] dpitch, input logic [OBW-1:0] soff,
                                  input int unsigned set_bytes);
    logic [31:0] last_src, last_dst;
    if (rows == 16'd0) begin
      seg_ok = 1'b1;
    end else begin
      last_src = 32'(soff) + 32'(rows - 16'd1) * 32'(spitch) + 32'(rowb);
      last_dst = 32'(doff) + 32'(rows - 16'd1) * 32'(dpitch) + 32'(rowb);
      seg_ok = (rowb != 16'd0) && ((rowb % 16'(WB)) == 16'd0) && ((spitch % 16'(WB)) == 16'd0) &&
               ((dpitch % 16'(WB)) == 16'd0) && ((doff % 16'(WB)) == 16'd0) && ((32'(soff) % WB) == 0) &&
               (spitch >= rowb) && (dpitch >= rowb) &&
               (last_src <= 32'(OBUF_BYTES)) && (last_dst <= 32'(set_bytes));
    end
  endfunction
  wire cmd_ok = (a_rows_i != 16'd0 || b_rows_i != 16'd0) &&
                seg_ok(a_rows_i, a_row_bytes_i, a_src_pitch_i, a_dst_off_i, a_dst_pitch_i, a_src_off_i, A_SET_BYTES) &&
                seg_ok(b_rows_i, b_row_bytes_i, b_src_pitch_i, b_dst_off_i, b_dst_pitch_i, b_src_off_i, B_SET_BYTES);

  // ---- addressing of the current word
  wire [31:0] src_byte = 32'(src_off_q[seg_q]) + 32'(r_q) * 32'(spitch_q[seg_q]) + 32'(w_q) * 32'(WB);
  wire [31:0] dst_byte = 32'(doff_q[seg_q]) + 32'(r_q) * 32'(dpitch_q[seg_q]) + 32'(w_q) * 32'(WB);
  wire [31:0] set_base = seg_q ? (32'(REGION) + 32'(set_q) * 32'(B_SET_BYTES)) : (32'(set_q) * 32'(A_SET_BYTES));
  wire        words_per_row_last = ({16'd0, w_q} + 32'd1 == 32'(rowb_q[seg_q]) / WB);
  wire        row_last           = (r_q + 16'd1 == rows_q[seg_q]);
  wire        owner_ok           = (set_state_i[set_q*2 +: 2] == TS_FILLING);

  assign ob_raddr_o = src_byte[OBW-1:4];

  wire wr_fire  = dma_req_valid_o && dma_req_ready_i;
  wire rsp_fire = dma_rsp_valid_i;

  always_comb begin
    dma_req_valid_o    = (st_q == A_WR) && !err_q;
    dma_req_we_o       = 1'b1;
    dma_req_addr_o     = TS_ADDR_W'(DMA_BASE) + TS_ADDR_W'(set_base) + TS_ADDR_W'(dst_byte);
    dma_req_wdata_o    = wd_q;
    dma_req_wstrb_o    = '1;
    dma_req_tag_o      = TS_TAG_W'(words_q);
    dma_rsp_ready_o    = 1'b1;
    fill_begin_valid_o = (st_q == A_BEGIN);
    fill_end_valid_o   = (st_q == A_END);
  end

  // word extraction from the (registered-read) output-buffer word
  logic [127:0] ob_shift;
  always_comb ob_shift = ob_rdata_i >> {src_byte[3:0], 3'b000};

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q    <= A_IDLE;
      outst_q <= '0;
      seg_q   <= 1'b0;
      r_q     <= '0;
      w_q     <= '0;
      err_q   <= 1'b0;
      code_q  <= ADP_E_NONE;
      words_q <= '0;
      done_o  <= 1'b0;
      err_o   <= 1'b0;
      err_code_o <= ADP_E_NONE;
    end else begin
      done_o <= 1'b0;
      outst_q <= outst_q + 8'(wr_fire) - 8'(rsp_fire);

      // first scratchpad error wins
      if (rsp_fire && dma_rsp_err_i && !err_q) begin
        err_q  <= 1'b1;
        code_q <= (dma_rsp_err_code_i == 3'd6) ? ADP_E_OWNER :
                  (dma_rsp_err_code_i == 3'd1) ? ADP_E_RANGE :
                  (dma_rsp_err_code_i == 3'd2) ? ADP_E_ALIGN : ADP_E_OTHER;
      end

      case (st_q)
        A_IDLE: begin
          if (go_i) begin
            seg_q   <= (a_rows_i == 16'd0);
            r_q     <= '0;
            w_q     <= '0;
            words_q <= '0;
            err_q   <= 1'b0;
            code_q  <= ADP_E_NONE;
            if (!cmd_ok && param_check_en_i) begin       // rejected: no side effect on the scratchpad
              err_o      <= 1'b1;
              err_code_o <= ADP_E_PARAM;
              done_o     <= 1'b1;
            end else begin
              st_q <= A_BEGIN;
            end
          end
        end
        A_BEGIN: begin
          if (fill_begin_ready_i) st_q <= A_SEG;
        end
        A_SEG: begin
          // the scratchpad granted a set; it must be FILLING before the first word is written
          if (own_en_q && set_state_i[set_q*2 +: 2] != TS_FILLING) begin
            err_q  <= 1'b1;
            code_q <= ADP_E_OWNER;
            st_q   <= A_DRAIN;
          end else if (!seg_en_q[0] && !seg_en_q[1]) begin
            st_q   <= A_DRAIN;                            // nothing to move (only reachable with param_check_en_i = 0)
          end else begin
            st_q   <= A_RD;
          end
        end
        A_RD:  st_q <= A_RDW;                             // address is presented by ob_raddr_o
        A_RDW: begin
          wd_q <= ob_shift[8*WB-1:0];
          st_q <= A_WR;
        end
        A_WR: begin
          if (err_q) begin
            st_q <= A_DRAIN;
          end else if (own_en_q && !owner_ok) begin       // ownership lost between words: stop, write nothing more
            err_q  <= 1'b1;
            code_q <= ADP_E_OWNER;
            st_q   <= A_DRAIN;
          end else if (wr_fire) begin
            words_q <= words_q + 32'd1;
            if (!words_per_row_last) begin
              w_q  <= w_q + 16'd1;
              st_q <= A_RD;
            end else begin
              w_q <= 16'd0;
              if (!row_last) begin
                r_q  <= r_q + 16'd1;
                st_q <= A_RD;
              end else if (!seg_q && seg_en_q[1]) begin
                seg_q <= 1'b1;
                r_q   <= 16'd0;
                st_q  <= A_RD;
              end else begin
                st_q <= A_DRAIN;
              end
            end
          end
        end
        A_DRAIN: begin
          if (outst_q == 8'd0 && !dma_req_valid_o) st_q <= A_END;
        end
        A_END: begin
          if (fill_end_ready_i) begin
            err_o      <= err_q;
            err_code_o <= code_q;
            done_o     <= 1'b1;
            st_q       <= A_IDLE;
          end
        end
        default: st_q <= A_IDLE;
      endcase
    end
  end

  // datapath registers
  always_ff @(posedge clk_i) begin
    if (st_q == A_IDLE && go_i) begin
      seg_en_q       <= {b_rows_i != 16'd0, a_rows_i != 16'd0};
      src_off_q[0]   <= a_src_off_i; rows_q[0] <= a_rows_i; rowb_q[0] <= a_row_bytes_i;
      spitch_q[0]    <= a_src_pitch_i; doff_q[0] <= a_dst_off_i; dpitch_q[0] <= a_dst_pitch_i;
      src_off_q[1]   <= b_src_off_i; rows_q[1] <= b_rows_i; rowb_q[1] <= b_row_bytes_i;
      spitch_q[1]    <= b_src_pitch_i; doff_q[1] <= b_dst_off_i; dpitch_q[1] <= b_dst_pitch_i;
      own_en_q       <= own_check_en_i;
    end
  end

  assign busy_o  = (st_q != A_IDLE);
  assign words_o = words_q;

endmodule

`default_nettype wire
