// =============================================================================
//  sf_sparse_pkg.sv -- SilicaFlux Project 112 (SparseEngine): shared constants,
//  command / completion records and fault codes.
//
//  This file is the single source of truth for the engine's software-visible
//  contract (docs/02_functional_spec.md).  Numbers here are ABI: never renumber,
//  only append.
//
//  Tool rules (same as the rest of the repository's SilicaFlux packages):
//    * localparams and packed structs only; no classes, no dynamic types.
//    * modules reference the package with scoped names (sf_sparse_pkg::NAME).
//
//  No process-node, timing or performance claim is made here.
// =============================================================================
`default_nettype none

package sf_sparse_pkg;
  /* verilator lint_off UNUSEDPARAM */

  // ---------------------------------------------------------------------------
  // 1. Fixed field widths of the command / completion records
  // ---------------------------------------------------------------------------
  localparam int unsigned SP_ADDR_W = 48;   // widest address the command record can carry
  localparam int unsigned SP_OFF_W  = 20;   // byte offset into the local buffers (1 MiB window)
  localparam int unsigned SP_EB_W   = 12;   // element-size field (bytes)
  localparam int unsigned SP_N_W    = 32;   // element / row / nonzero counts
  localparam int unsigned SP_TID_W  = 16;   // transaction id
  localparam int unsigned SP_DOM_W  = 2;    // protection-domain index (MemoryGuard ND = 4)

  // ---------------------------------------------------------------------------
  // 2. Operations
  // ---------------------------------------------------------------------------
  //   GATHER      out[i]  = mem[base + idx[i] * E]                     (idx from memory or pushed)
  //   SCATTER     mem[base + idx[i] * E] = in[i]                       (duplicates: highest i wins)
  //   CSR_GATHER  out[k]  = x[col[k]]  for every nonzero k of a CSR matrix, validated traversal
  //   CSR_SPMV    y[r]    = sum_k val[k] * x[col[k]]   (INT8 x INT8 -> INT32, optional arithmetic)
  localparam logic [3:0] SP_OP_NOP        = 4'd0;
  localparam logic [3:0] SP_OP_GATHER     = 4'd1;
  localparam logic [3:0] SP_OP_SCATTER    = 4'd2;
  localparam logic [3:0] SP_OP_CSR_GATHER = 4'd3;
  localparam logic [3:0] SP_OP_CSR_SPMV   = 4'd4;

  // ---------------------------------------------------------------------------
  // 3. Fault codes (completion `fault` field; 0 = success)
  // ---------------------------------------------------------------------------
  localparam logic [4:0] SP_F_NONE       = 5'd0;
  localparam logic [4:0] SP_F_BAD_OP     = 5'd1;   // opcode not implemented in this build
  localparam logic [4:0] SP_F_BAD_ELEM   = 5'd2;   // element size 0, too large, or not {1,2,4,8} / multiple of 16
  localparam logic [4:0] SP_F_BAD_IDXW   = 5'd3;   // index width code not supported
  localparam logic [4:0] SP_F_ALIGN      = 5'd4;   // base / idx_base / buffer offset not naturally aligned
  localparam logic [4:0] SP_F_BUF_RANGE  = 5'd5;   // local buffer window exceeded
  localparam logic [4:0] SP_F_NEG_INDEX  = 5'd6;   // signed index < 0
  localparam logic [4:0] SP_F_IDX_RANGE  = 5'd7;   // index >= idx_limit
  localparam logic [4:0] SP_F_ADDR_OVF   = 5'd8;   // base + idx*E does not fit the address space
  localparam logic [4:0] SP_F_PERM       = 5'd9;   // MemoryGuard denied (see `gfault`)
  localparam logic [4:0] SP_F_MEM_ERR    = 5'd10;  // target returned a non-OKAY ALP status (see `alp_status`)
  localparam logic [4:0] SP_F_CSR_DIM    = 5'd11;  // inconsistent CSR dimensions
  localparam logic [4:0] SP_F_CSR_FMT    = 5'd12;  // unsupported value / column-index format
  localparam logic [4:0] SP_F_CSR_ROWPTR = 5'd13;  // row pointer non-monotonic / out of range / wrong total
  localparam logic [4:0] SP_F_CSR_COL    = 5'd14;  // column index >= ncols
  localparam logic [4:0] SP_F_BAD_CMD    = 5'd15;  // command field outside the supported range
  localparam logic [4:0] SP_F_PROTO      = 5'd16;  // link protocol violation seen (unexpected response)
  localparam logic [4:0] SP_F_UNSUP      = 5'd17;  // legal request the arithmetic path cannot execute (SpMV non-INT8)

  // ---------------------------------------------------------------------------
  // 4. CSR value formats (cmd.vfmt)
  // ---------------------------------------------------------------------------
  localparam logic [2:0] SP_VF_INT8  = 3'd0;   // 1 byte, signed     (the only format the SpMV arithmetic executes)
  localparam logic [2:0] SP_VF_INT16 = 3'd1;   // 2 bytes, signed
  localparam logic [2:0] SP_VF_INT32 = 3'd2;   // 4 bytes, signed
  localparam logic [2:0] SP_VF_FP32  = 3'd3;   // 4 bytes, raw IEEE-754 bits (traversal only)
  // 4..7 reserved -> SP_F_CSR_FMT

  // ---------------------------------------------------------------------------
  // 5. Link tag map (8-bit ALP tag)
  //      [7:5] source   000 data request (request table index in [4:0])
  //                     001 index-array reader      010 CSR row-pointer reader
  //                     011 CSR column reader       100 CSR value reader
  //      [4:0] request-table index, or reader slot
  // ---------------------------------------------------------------------------
  localparam logic [2:0] SP_TAGSRC_DATA = 3'd0;
  localparam logic [2:0] SP_TAGSRC_IDX  = 3'd1;
  localparam logic [2:0] SP_TAGSRC_RP   = 3'd2;
  localparam logic [2:0] SP_TAGSRC_CI   = 3'd3;
  localparam logic [2:0] SP_TAGSRC_VAL  = 3'd4;

  // ---------------------------------------------------------------------------
  // 6. Command record (one command is executed at a time, to completion)
  //    Field use per operation: docs/02_functional_spec.md section 3.
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [3:0]            op;           // SP_OP_*
    logic [SP_TID_W-1:0]   tid;          // transaction id, echoed in the completion
    logic [SP_DOM_W-1:0]   dom;          // protection domain (MemoryGuard domain index)
    logic                  cacheable;    // 1: ALP NORMAL_WB (may use CacheForge), 0: NORMAL_NC (bypass)
    logic                  idx_stream;   // 1: indices pushed on the ipush port, 0: array in memory
    logic                  idx_signed;   // index is two's complement (negative = fault), else unsigned
    logic [1:0]            idx_w;        // log2(index bytes): 0 = 8 bit, 1 = 16 bit, 2 = 32 bit
    logic [SP_ADDR_W-1:0]  base;         // table / x-vector / scatter destination base address
    logic [SP_ADDR_W-1:0]  idx_base;     // index array base address (memory-resident indices)
    logic [SP_N_W-1:0]     n;            // element count (gather / scatter)
    logic [SP_EB_W-1:0]    elem_bytes;   // element size E in bytes
    logic [SP_N_W-1:0]     idx_limit;    // 0 = unchecked, else valid indices are 0 .. idx_limit-1
    logic [SP_OFF_W-1:0]   dst_off;      // output buffer byte offset (gather results / SpMV y)
    logic [SP_OFF_W-1:0]   src_off;      // input buffer byte offset (scatter source data)
    logic [SP_ADDR_W-1:0]  rp_base;      // CSR row-pointer array (uint32 x (nrows+1))
    logic [SP_ADDR_W-1:0]  ci_base;      // CSR column-index array
    logic [SP_ADDR_W-1:0]  val_base;     // CSR value array
    logic [SP_N_W-1:0]     nrows;
    logic [SP_N_W-1:0]     ncols;
    logic [SP_N_W-1:0]     nnz;
    logic [1:0]            ci_w;         // log2(column-index bytes): 0, 1, 2
    logic [2:0]            vfmt;         // SP_VF_*
  } sf_sp_cmd_t;

  // ---------------------------------------------------------------------------
  // 7. Completion record
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [SP_TID_W-1:0]   tid;
    logic [4:0]            fault;        // SP_F_*; 0 = success
    logic [3:0]            gfault;       // MemoryGuard FT_* when fault == SP_F_PERM
    logic [3:0]            alp_status;   // ALP status when fault == SP_F_MEM_ERR
    logic [SP_N_W-1:0]     fault_elem;   // element / nonzero index of the (lowest-indexed) fault
    logic [SP_ADDR_W-1:0]  fault_addr;   // address of the faulting access (0 when not applicable)
    logic [SP_N_W-1:0]     elems_done;   // elements delivered to the output buffer / committed to memory
    logic                  ovf;          // SpMV: at least one row accumulation overflowed (saturated)
    logic [31:0]           cycles;       // cycles from command accept to completion
  } sf_sp_done_t;

  // ---------------------------------------------------------------------------
  // 8. Performance counters (indices into perf_o, CNT_W bits each)
  // ---------------------------------------------------------------------------
  localparam int unsigned SP_PC_CYCLES_BUSY   = 0;   // cycles with a command active
  localparam int unsigned SP_PC_CMDS          = 1;   // commands completed
  localparam int unsigned SP_PC_CMDS_FAULT    = 2;   // commands completed with a fault
  localparam int unsigned SP_PC_ELEMS         = 3;   // elements delivered / committed
  localparam int unsigned SP_PC_DATA_RD_REQ   = 4;   // data READ requests sent on the link
  localparam int unsigned SP_PC_DATA_WR_REQ   = 5;   // data WRITE requests sent on the link
  localparam int unsigned SP_PC_META_REQ      = 6;   // index / CSR array READ requests sent on the link
  localparam int unsigned SP_PC_BYTES_REQ     = 7;   // byte lanes enabled in data requests (requested bytes)
  localparam int unsigned SP_PC_BYTES_USEFUL  = 8;   // element bytes delivered / committed (useful bytes)
  localparam int unsigned SP_PC_MERGES        = 9;   // descriptors merged into a pending request
  localparam int unsigned SP_PC_DUP_HITS      = 10;  // descriptors served by an in-flight / completed request
  localparam int unsigned SP_PC_BURST_CONT    = 11;  // issued beats that continue the previous beat (address + 16)
  localparam int unsigned SP_PC_STALL_LINK    = 12;  // cycles a request waited on the link (valid & !ready or outstanding limit)
  localparam int unsigned SP_PC_STALL_RT      = 13;  // cycles a descriptor waited for a free request-table entry
  localparam int unsigned SP_PC_STALL_ROB     = 14;  // cycles a read descriptor waited for a free reorder slot
  localparam int unsigned SP_PC_ROB_OCC_SUM   = 15;  // sum over busy cycles of reorder-buffer occupancy
  localparam int unsigned SP_PC_ROB_OCC_MAX   = 16;  // peak reorder-buffer occupancy
  localparam int unsigned SP_PC_RT_OCC_MAX    = 17;  // peak request-table occupancy
  localparam int unsigned SP_PC_OUT_MAX       = 18;  // peak link outstanding
  localparam int unsigned SP_PC_BANK_CONF     = 19;  // issued requests whose bank already had a request in flight
  localparam int unsigned SP_PC_RD_LAT_SUM    = 20;  // sum of data-read latencies (select -> response), cycles
  localparam int unsigned SP_PC_RD_LAT_CNT    = 21;  // number of data-read latency samples
  localparam int unsigned SP_PC_RD_LAT_MAX    = 22;  // largest data-read latency
  localparam int unsigned SP_PC_CMD_LAT_SUM   = 23;  // sum of command latencies
  localparam int unsigned SP_PC_CMD_LAT_MAX   = 24;  // largest command latency
  localparam int unsigned SP_PC_PROTO_ERR     = 25;  // unexpected responses seen
  localparam int unsigned SP_PC_N             = 26;

  /* verilator lint_on UNUSEDPARAM */
endpackage

`default_nettype wire
