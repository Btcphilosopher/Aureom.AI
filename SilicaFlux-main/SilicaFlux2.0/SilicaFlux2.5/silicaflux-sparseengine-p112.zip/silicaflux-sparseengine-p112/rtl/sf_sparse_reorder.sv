// =============================================================================
//  sf_sparse_reorder.sv -- bounded response reorder buffer (SilicaFlux P112)
//
//  One slot per accepted READ beat descriptor, allocated in descriptor order
//  (= element order).  A slot records WHICH request-table entry will carry its
//  data and the lane of the element inside that beat -- that is the "response
//  destination tracking": no data is copied into the slot, the request-table
//  entry is the buffer, and its reference count keeps it alive until this slot
//  has been delivered.
//
//  Memory completions may arrive in any order (the table entry is written when
//  its response arrives).  Delivery is strictly in slot order: the head slot is
//  delivered only when its entry has completed, so the output stream is the
//  original element order regardless of completion order.
//
//  Boundedness / no data loss:
//    * rob_ready_o is a function of registered state; a descriptor is accepted
//      only if a slot is free, so allocation can never overflow;
//    * a response is always accepted by the request table (its entry was
//      reserved when the request was selected) and stays there until released;
//    * delivery holds the head slot while dv_ready_i is low; the entry is
//      released in the same cycle the data is captured into the delivery
//      register, so data is never freed before it has been taken.
//
//  Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_sparse_reorder #(
  parameter int unsigned ROB_DEPTH = 32,        // slots (power of two)
  parameter int unsigned NRT       = 16
) (
  input  wire logic                   clk_i,
  input  wire logic                   rst_ni,
  // ---- allocation (from the coalescer, one per accepted read descriptor)
  input  wire logic                   alloc_valid_i,
  input  wire logic [$clog2(NRT)-1:0] alloc_rt_i,
  input  wire logic [3:0]             alloc_lane_i,
  output logic                        rob_ready_o,
  // ---- request-table read port
  output logic [$clog2(NRT)-1:0]      rd_rt_o,
  input  wire logic [127:0]           rd_data_i,
  input  wire logic                   rd_done_i,
  input  wire logic [3:0]             rd_stat_i,
  // ---- release of the consumed reference
  output logic                        rel_valid_o,
  output logic [$clog2(NRT)-1:0]      rel_rt_o,
  // ---- ordered delivery (registered)
  output logic                        dv_valid_o,
  input  wire logic                   dv_ready_i,
  output logic [127:0]                dv_data_o,
  output logic [3:0]                  dv_lane_o,
  output logic [3:0]                  dv_stat_o,
  // ---- status
  output logic                        empty_o,
  output logic [$clog2(ROB_DEPTH+1)-1:0] occ_o
);
  localparam int unsigned PW  = $clog2(ROB_DEPTH);
  localparam int unsigned RTW = $clog2(NRT);

  if (ROB_DEPTH < 2 || (ROB_DEPTH & (ROB_DEPTH - 1)) != 0) begin : g_chk
    $error("sf_sparse_reorder: ROB_DEPTH must be a power of two >= 2");
  end

  logic [ROB_DEPTH-1:0][RTW-1:0] slot_rt_q;
  logic [ROB_DEPTH-1:0][3:0]     slot_lane_q;
  logic [PW-1:0]                 head_q, tail_q;
  logic [PW:0]                   cnt_q;

  logic          dv_valid_q;
  logic [127:0]  dv_data_q;
  logic [3:0]    dv_lane_q, dv_stat_q;

  assign rob_ready_o = (cnt_q != (PW+1)'(ROB_DEPTH));
  assign rd_rt_o     = slot_rt_q[head_q];

  wire head_ok  = (cnt_q != '0) && rd_done_i;
  wire advance  = head_ok && (!dv_valid_q || dv_ready_i);
  assign rel_valid_o = advance;
  assign rel_rt_o    = slot_rt_q[head_q];

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      head_q     <= '0;
      tail_q     <= '0;
      cnt_q      <= '0;
      dv_valid_q <= 1'b0;
    end else begin
      if (alloc_valid_i) tail_q <= tail_q + PW'(1);
      if (advance)       head_q <= head_q + PW'(1);
      cnt_q <= cnt_q + (PW+1)'(alloc_valid_i) - (PW+1)'(advance);
      if (advance)       dv_valid_q <= 1'b1;
      else if (dv_ready_i) dv_valid_q <= 1'b0;
    end
  end

  always_ff @(posedge clk_i) begin
    if (alloc_valid_i) begin
      slot_rt_q[tail_q]   <= alloc_rt_i;
      slot_lane_q[tail_q] <= alloc_lane_i;
    end
    if (advance) begin
      dv_data_q <= rd_data_i;
      dv_lane_q <= slot_lane_q[head_q];
      dv_stat_q <= rd_stat_i;
    end
  end

  assign dv_valid_o = dv_valid_q;
  assign dv_data_o  = dv_data_q;
  assign dv_lane_o  = dv_lane_q;
  assign dv_stat_o  = dv_stat_q;
  assign empty_o    = (cnt_q == '0) && !dv_valid_q;
  assign occ_o      = cnt_q;

endmodule

`default_nettype wire
