// =============================================================================
//  sf_sparse_address_gen.sv -- element address generation and beat splitting
//  (SilicaFlux P112).  Two modules:
//
//  sf_sparse_address_gen   index stream  ->  element address records
//        addr(i) = base + idx(i) * E             (exact arithmetic, no wrap-around)
//      Three register stages (check / multiply / add), one element per cycle.
//      Every element leaves with a fault code; the FIRST faulting element in
//      stream order stops the command (the engine discards everything after it).
//      Fault precedence for one element (first match wins):
//          index-array read error      SP_F_MEM_ERR
//          negative signed index       SP_F_NEG_INDEX
//          idx >= idx_limit (limit!=0) SP_F_IDX_RANGE
//          base + idx*E >= 2^ADDR_W    SP_F_ADDR_OVF
//      The permission check (MemoryGuard) is the NEXT stage and needs the
//      exact address, so an overflowing address is never presented to it as if
//      it were valid.
//
//  sf_sparse_beat_split    element record -> 16-byte ALP beat descriptors
//      E < 16 (E in {1,2,4,8}, base aligned to E): one beat, lane window
//          [addr%16, addr%16 + E).
//      E >= 16 (multiple of 16, base 16-aligned): E/16 whole beats.
//      The byte-enable mask of a beat is exactly the bytes of the element in
//      that beat, so the bytes a request touches are the bytes the permission
//      check validated.
//
//  Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_sparse_address_gen #(
  parameter int unsigned ADDR_W = 48,
  parameter int unsigned IDX_W  = 32,
  parameter int unsigned EB_W   = 12
) (
  input  wire logic                  clk_i,
  input  wire logic                  rst_ni,
  input  wire logic                  start_i,       // new command: element counter := 0
  input  wire logic                  flush_i,       // discard everything in the pipeline
  // static configuration for the command
  input  wire logic [ADDR_W-1:0]     base_i,
  input  wire logic [EB_W-1:0]       elem_bytes_i,
  input  wire logic [IDX_W-1:0]      idx_limit_i,   // 0 = unchecked
  // index stream in
  input  wire logic                  idx_valid_i,
  output logic                       idx_ready_o,
  input  wire logic [IDX_W-1:0]      idx_val_i,
  input  wire logic                  idx_neg_i,
  input  wire logic                  idx_err_i,
  // element records out
  output logic                       ea_valid_o,
  input  wire logic                  ea_ready_i,
  output logic [ADDR_W-1:0]          ea_addr_o,
  output logic [31:0]                ea_idx_o,      // element number i
  output logic [4:0]                 ea_fault_o,    // SP_F_*
  output logic                       busy_o
);
  localparam int unsigned PW = IDX_W + EB_W;                // product width
  localparam int unsigned SW = ((PW > ADDR_W) ? PW : ADDR_W) + 1;   // sum width

  // ---- element counter
  logic [31:0] elem_q;

  // ---- stage 1: capture + checks
  logic                v1_q, neg1_q, err1_q;
  logic [IDX_W-1:0]    val1_q;
  logic [31:0]         el1_q;
  // ---- stage 2: product
  logic                v2_q;
  logic [PW-1:0]       prod2_q;
  logic [4:0]          flt2_q;
  logic [31:0]         el2_q;
  // ---- stage 3: sum (output)
  logic                v3_q;
  logic [ADDR_W-1:0]   addr3_q;
  logic [4:0]          flt3_q;
  logic [31:0]         el3_q;

  wire adv3 = !v3_q || ea_ready_i;
  wire adv2 = !v2_q || adv3;
  wire adv1 = !v1_q || adv2;
  assign idx_ready_o = adv1 && !flush_i;
  wire in_fire = idx_valid_i && idx_ready_o;

  // stage-1 -> stage-2 combinational
  logic [4:0]  flt1;
  logic [PW-1:0] prod1;
  always_comb begin
    if      (err1_q)                                        flt1 = sf_sparse_pkg::SP_F_MEM_ERR;
    else if (neg1_q)                                        flt1 = sf_sparse_pkg::SP_F_NEG_INDEX;
    else if ((idx_limit_i != '0) && (val1_q >= idx_limit_i)) flt1 = sf_sparse_pkg::SP_F_IDX_RANGE;
    else                                                    flt1 = sf_sparse_pkg::SP_F_NONE;
    prod1 = PW'(val1_q) * PW'(elem_bytes_i);
  end

  // stage-2 -> stage-3 combinational
  logic [SW-1:0] sum2;
  logic          ovf2;
  logic [4:0]    flt2n;
  always_comb begin
    sum2  = SW'(prod2_q) + SW'(base_i);
    ovf2  = |(sum2 >> ADDR_W);
    flt2n = (flt2_q != sf_sparse_pkg::SP_F_NONE) ? flt2_q :
            ovf2 ? sf_sparse_pkg::SP_F_ADDR_OVF : sf_sparse_pkg::SP_F_NONE;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      elem_q <= '0;
      v1_q   <= 1'b0;
      v2_q   <= 1'b0;
      v3_q   <= 1'b0;
    end else begin
      if (start_i) elem_q <= '0;
      if (adv3) v3_q <= v2_q;
      if (adv2) v2_q <= v1_q;
      if (adv1) v1_q <= in_fire;
      if (in_fire) elem_q <= elem_q + 32'd1;
      if (flush_i) begin
        v1_q <= 1'b0;
        v2_q <= 1'b0;
        v3_q <= 1'b0;
      end
    end
  end

  always_ff @(posedge clk_i) begin
    if (in_fire) begin
      val1_q <= idx_val_i;
      neg1_q <= idx_neg_i;
      err1_q <= idx_err_i;
      el1_q  <= elem_q;
    end
    if (adv2) begin
      prod2_q <= prod1;
      flt2_q  <= flt1;
      el2_q   <= el1_q;
    end
    if (adv3) begin
      addr3_q <= sum2[ADDR_W-1:0];
      flt3_q  <= flt2n;
      el3_q   <= el2_q;
    end
  end

  assign ea_valid_o = v3_q;
  assign ea_addr_o  = addr3_q;
  assign ea_idx_o   = el3_q;
  assign ea_fault_o = flt3_q;
  assign busy_o     = v1_q || v2_q || v3_q;

endmodule


// =============================================================================
module sf_sparse_beat_split #(
  parameter int unsigned ADDR_W = 48,
  parameter int unsigned EB_W   = 12
) (
  input  wire logic                  clk_i,
  input  wire logic                  rst_ni,
  input  wire logic                  flush_i,
  input  wire logic [EB_W-1:0]       elem_bytes_i,
  // element records in (already validated)
  input  wire logic                  ea_valid_i,
  output logic                       ea_ready_o,
  input  wire logic [ADDR_W-1:0]     ea_addr_i,
  input  wire logic [31:0]           ea_idx_i,
  // beat descriptors out
  output logic                       bd_valid_o,
  input  wire logic                  bd_ready_i,
  output logic [ADDR_W-5:0]          bd_beat_o,      // beat address (byte address >> 4)
  output logic [3:0]                 bd_lane_o,      // lane of the element's first byte in this beat
  output logic [15:0]                bd_be_o,        // enabled lanes
  output logic [31:0]                bd_elem_o,
  output logic                       bd_last_o,      // last beat of the element
  output logic                       busy_o
);
  localparam int unsigned BA_W = ADDR_W - 4;

  logic [ADDR_W-1:0] addr_q;
  logic [31:0]       el_q;
  logic [EB_W-5:0]   bi_q;            // beat index within the element
  logic              have_q;

  wire              e_sm = (elem_bytes_i < EB_W'(16));
  wire [EB_W-5:0]   nb_m1 = e_sm ? '0 : (elem_bytes_i[EB_W-1:4] - 1'b1);
  wire              last  = (bi_q == nb_m1);

  logic [15:0] be_small;
  always_comb begin
    be_small = '0;
    for (int i = 0; i < 16; i++)
      be_small[i] = (4'(i) >= addr_q[3:0]) && ({1'b0, 4'(i)} < ({1'b0, addr_q[3:0]} + 5'(elem_bytes_i[4:0])));
  end

  assign bd_valid_o = have_q;
  assign bd_beat_o  = addr_q[ADDR_W-1:4] + BA_W'(bi_q);
  assign bd_lane_o  = e_sm ? addr_q[3:0] : 4'd0;
  assign bd_be_o    = e_sm ? be_small : 16'hFFFF;
  assign bd_elem_o  = el_q;
  assign bd_last_o  = last;
  assign busy_o     = have_q;

  wire take = bd_valid_o && bd_ready_i;
  assign ea_ready_o = !have_q || (take && last);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      have_q <= 1'b0;
      bi_q   <= '0;
    end else begin
      if (take) begin
        if (last) begin
          have_q <= 1'b0;
          bi_q   <= '0;
        end else begin
          bi_q <= bi_q + 1'b1;
        end
      end
      if (ea_valid_i && ea_ready_o) have_q <= 1'b1;
      if (flush_i) begin
        have_q <= 1'b0;
        bi_q   <= '0;
      end
    end
  end

  always_ff @(posedge clk_i) begin
    if (ea_valid_i && ea_ready_o) begin
      addr_q <= ea_addr_i;
      el_q   <= ea_idx_i;
    end
  end

endmodule

`default_nettype wire
