// =============================================================================
//  sf_sparse_spmv.sv -- sparse matrix-vector product on the verified TensorCore
//  arithmetic lane (SilicaFlux P112, optional).
//
//      y[r] = sum over the nonzeros k of row r of   val[k] * x[col[k]]
//
//  Arithmetic contract (inherited from tensor_pe, TensorCore 01):
//    * operands        signed INT8 x signed INT8; the product is exact (16 bit)
//    * accumulator     signed ACC_W bit (default 32); y is written as INT32
//                      (sign-extended when ACC_W < 32)
//    * reduction order SEQUENTIAL in CSR order: the nonzeros of a row are
//                      accumulated one per cycle in ascending k.  There is no
//                      reordering and no tree: the order is part of the contract
//                      because saturation makes the result order dependent.
//    * overflow        the accumulator CLAMPS at every step (OVF_POLICY =
//                      SATURATE, or wraps modulo 2^ACC_W with OVF_WRAP = 1) and
//                      a sticky flag records that it happened; the flag is
//                      reported once per command (done.ovf).  With ACC_W = 32 a
//                      row of up to 131071 nonzeros cannot overflow.
//    * row boundaries  an event carries first / last; `first` starts a new
//                      accumulation (clear-and-load, no bubble), `last` makes the
//                      row result appear as y[row].  An empty row is an event with
//                      no operand and yields y = 0.  Rows are emitted in order.
//
//  Event / value pairing: events (from the CSR walker) and x elements (from the
//  gather path) are both in nonzero order, so they pair one to one.  An empty-row
//  event needs no x element.  Nothing is dropped: a missing x element stalls the
//  event stream.
//
//  Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_sparse_spmv #(
  parameter int unsigned ACC_W      = 32,
  parameter bit          OVF_WRAP   = 1'b0,    // 0: saturate, 1: wrap modulo 2^ACC_W
  parameter int unsigned MUL_STAGES = 1
) (
  input  wire logic              clk_i,
  input  wire logic              rst_ni,
  input  wire logic              start_i,        // new command: row counter and overflow flag cleared
  // ---- events from the CSR walker (value + boundaries)
  input  wire logic              ev_valid_i,
  output logic                   ev_ready_o,
  input  wire logic [7:0]        ev_val_i,
  input  wire logic              ev_nz_i,
  input  wire logic              ev_first_i,
  input  wire logic              ev_last_i,
  // ---- x elements from the gather path (in nonzero order)
  input  wire logic              x_valid_i,
  output logic                   x_ready_o,
  input  wire logic [7:0]        x_data_i,
  // ---- results
  output logic                   y_valid_o,
  output logic [31:0]            y_row_o,
  output logic [31:0]            y_data_o,       // INT32 (sign extended from ACC_W)
  output logic                   ovf_o,          // sticky: a row accumulation left the ACC_W range
  output logic                   busy_o          // tokens in the arithmetic pipeline
);
  localparam int unsigned L = MUL_STAGES + 2;     // tensor_pe latency in enabled cycles

  if (ACC_W < 16 || ACC_W > 32) begin : g_chk
    $error("sf_sparse_spmv: ACC_W must be 16..32 (y is INT32)");
  end

  wire fire = ev_valid_i && (!ev_nz_i || x_valid_i);
  assign ev_ready_o = fire;
  assign x_ready_o  = fire && ev_nz_i;

  wire signed [7:0]        pe_a = ev_val_i;      // explicit signed views: INT8 x INT8
  wire signed [7:0]        pe_b = x_data_i;
  logic signed [ACC_W-1:0] pe_acc;
  logic                    pe_valid, pe_ovf;
  /* verilator lint_off PINCONNECTEMPTY */
  tensor_pe #(
    .A_W(8), .B_W(8), .ACC_W(ACC_W), .MUL_STAGES(MUL_STAGES),
    .OVF_POLICY(OVF_WRAP ? tensor_pe_pkg::TPE_OVF_WRAP : tensor_pe_pkg::TPE_OVF_SATURATE),
    .OPERAND_GATING(1'b1), .K_LIMIT_SEVERITY(0)
  ) u_pe (
    .clk_i, .rst_ni,
    .enable_i(1'b1),
    .clear_acc_i(fire && (ev_first_i || !ev_nz_i)),
    .operand_a_i(pe_a),
    .operand_b_i(pe_b),
    .operand_valid_i(fire && ev_nz_i),
    .acc_result_o(pe_acc), .acc_valid_o(pe_valid), .overflow_o(pe_ovf),
    .a_fwd_o(), .b_fwd_o(), .valid_fwd_o(), .clear_fwd_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  // side delay line: one entry per accepted command, aligned with the PE token
  logic [L-1:0] tok_v_q, tok_e_q;               // [0] = youngest
  logic [31:0]  row_q;
  logic         ovf_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tok_v_q <= '0;
      tok_e_q <= '0;
      row_q   <= '0;
      ovf_q   <= 1'b0;
    end else begin
      tok_v_q <= {tok_v_q[L-2:0], fire};
      tok_e_q <= {tok_e_q[L-2:0], fire && (ev_last_i || !ev_nz_i)};
      if (start_i) begin
        row_q <= '0;
        ovf_q <= 1'b0;
      end
      if (y_valid_o) begin
        row_q <= row_q + 32'd1;
        if (pe_ovf) ovf_q <= 1'b1;
      end
    end
  end

  assign y_valid_o = pe_valid && tok_e_q[L-1];
  assign y_row_o   = row_q;
  assign y_data_o  = {{(32-ACC_W){pe_acc[ACC_W-1]}}, pe_acc};     // sign extension to INT32
  assign ovf_o     = ovf_q;
  assign busy_o    = |tok_v_q;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_tok = tok_v_q[L-1] ^ pe_valid;
  /* verilator lint_on UNUSEDSIGNAL */

endmodule

`default_nettype wire
