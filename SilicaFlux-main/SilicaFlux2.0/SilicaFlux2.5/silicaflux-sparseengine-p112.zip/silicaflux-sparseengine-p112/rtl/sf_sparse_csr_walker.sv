// =============================================================================
//  sf_sparse_csr_walker.sv -- validated traversal of a compressed-sparse-row
//  matrix (SilicaFlux P112).
//
//  Arrays (all read through the engine's memory link, exact byte enables):
//      row_ptr[0 .. nrows]   uint32          (rp_base)
//      col_idx[0 .. nnz-1]   uint8/16/32     (ci_base, width ci_w)
//      val[0 .. nnz-1]       1/2/4 bytes     (val_base, only when use_val_i)
//
//  The walk is strictly sequential, row by row:
//      check  row_ptr[0] == 0
//      for r = 0 .. nrows-1:
//          p1 = row_ptr[r+1]
//          check  p1 >= p0   (monotonic)           p0 = row_ptr[r]
//          check  p1 <= nnz  (in range)
//          check  p1 == nnz  when r == nrows-1     (array lengths agree)
//          for k = p0 .. p1-1:
//              check  col_idx[k] < ncols           (index bound)
//              push   col_idx[k]   to the gather pipeline (x[col] is fetched there)
//              push   {val[k], first = (k == p0), last = (k == p1-1)} to the event stream
//          if p1 == p0: push an EMPTY-row event (value stream consumers need it)
//
//  FAULT POSITION (docs/02 section 6): a fault is reported with the number of
//  nonzeros emitted before it:
//      sf_sparse_pkg::SP_F_CSR_ROWPTR  elem = p0 of the row whose row_ptr[r+1] was rejected
//                       (elem 0 for a bad row_ptr[0])
//      sf_sparse_pkg::SP_F_CSR_COL     elem = k of the nonzero whose column index was rejected
//      sf_sparse_pkg::SP_F_MEM_ERR     elem = k (or p0 for a row-pointer read error)
//  A row's p1 is validated BEFORE any of the row's nonzeros is emitted, so the
//  nonzeros of a row with a bad row_ptr[r+1] are not emitted.
//  After the first fault the walker emits nothing more.
//
//  Classification: SYNTHESIZABLE.
// =============================================================================
`default_nettype none

module sf_sparse_csr_walker #(
  parameter int unsigned ADDR_W = 48,
  parameter int unsigned NSLOT  = 4
) (
  input  wire logic                     clk_i,
  input  wire logic                     rst_ni,
  input  wire logic                     start_i,
  input  wire logic                     flush_i,
  input  wire logic [ADDR_W-1:0]        rp_base_i,
  input  wire logic [ADDR_W-1:0]        ci_base_i,
  input  wire logic [ADDR_W-1:0]        val_base_i,
  input  wire logic [31:0]              nrows_i,
  input  wire logic [31:0]              ncols_i,
  input  wire logic [31:0]              nnz_i,
  input  wire logic [1:0]               ci_w_i,        // log2(column-index bytes)
  input  wire logic [1:0]               vsz_i,         // log2(value bytes)
  input  wire logic                     use_val_i,
  output logic                          busy_o,
  // ---- memory requests of the three array readers: [0] row_ptr, [1] col_idx, [2] val
  output logic [2:0]                    rq_valid_o,
  input  wire logic [2:0]               rq_ready_i,
  output logic [2:0][ADDR_W-5:0]        rq_beat_o,
  output logic [2:0][15:0]              rq_be_o,
  output logic [2:0][$clog2(NSLOT)-1:0] rq_slot_o,
  input  wire logic [2:0]               rs_valid_i,    // one-hot: which reader the response belongs to
  input  wire logic [$clog2(NSLOT)-1:0] rs_slot_i,
  input  wire logic [127:0]             rs_data_i,
  input  wire logic                     rs_err_i,
  // ---- column indices into the gather pipeline
  output logic                          ix_valid_o,
  input  wire logic                     ix_ready_i,
  output logic [31:0]                   ix_data_o,
  // ---- value / row-boundary events (SpMV)
  output logic                          ev_valid_o,
  input  wire logic                     ev_ready_i,
  output logic [31:0]                   ev_val_o,
  output logic                          ev_nz_o,        // 1: a nonzero, 0: an empty row
  output logic                          ev_first_o,     // first nonzero of its row (or an empty row)
  output logic                          ev_last_o,      // last nonzero of its row (or an empty row)
  // ---- fault
  output logic                          flt_valid_o,
  output logic [4:0]                    flt_code_o,
  output logic [31:0]                   flt_elem_o,
  output logic [3:0]                    flt_stat_o
);
  localparam int unsigned SLW = $clog2(NSLOT);

  typedef enum logic [2:0] {W_IDLE, W_RP0, W_ROW, W_EMPTY, W_EMIT, W_DONE, W_FAULT} wstate_e;
  wstate_e     st_q;
  logic [31:0] nrows_q, ncols_q, nnz_q, p0_q, p1_q, k_q, row_q;
  logic        use_val_q;
  logic        flt_v_q;
  logic [4:0]  flt_code_q;
  logic [31:0] flt_elem_q;
  logic [3:0]  flt_stat_q;

  // ---- three readers
  logic [2:0]  rd_busy, rd_ov, rd_or, rd_oe, rd_ol;
  logic [2:0][63:0] rd_od;
  logic [2:0]  rd_start;
  logic        rd_flush;
  wire  [31:0] rp_cnt = nrows_i + 32'd1;
  assign rd_start[0] = start_i && !busy_o;
  assign rd_start[1] = start_i && !busy_o && (nnz_i != 32'd0);
  assign rd_start[2] = start_i && !busy_o && (nnz_i != 32'd0) && use_val_i;
  assign rd_flush    = flush_i || flt_v_q;

  sf_sparse_stream_rd #(.ADDR_W(ADDR_W), .NSLOT(NSLOT)) u_rp (
    .clk_i, .rst_ni, .start_i(rd_start[0]), .base_i(rp_base_i), .esz_log2_i(2'd2), .count_i(rp_cnt), .flush_i(rd_flush),
    .busy_o(rd_busy[0]), .rq_valid_o(rq_valid_o[0]), .rq_ready_i(rq_ready_i[0]), .rq_beat_o(rq_beat_o[0]),
    .rq_be_o(rq_be_o[0]), .rq_slot_o(rq_slot_o[0]),
    .rs_valid_i(rs_valid_i[0]), .rs_slot_i, .rs_data_i, .rs_err_i,
    .out_valid_o(rd_ov[0]), .out_ready_i(rd_or[0]), .out_data_o(rd_od[0]), .out_err_o(rd_oe[0]), .out_last_o(rd_ol[0])
  );
  sf_sparse_stream_rd #(.ADDR_W(ADDR_W), .NSLOT(NSLOT)) u_ci (
    .clk_i, .rst_ni, .start_i(rd_start[1]), .base_i(ci_base_i), .esz_log2_i(ci_w_i), .count_i(nnz_i), .flush_i(rd_flush),
    .busy_o(rd_busy[1]), .rq_valid_o(rq_valid_o[1]), .rq_ready_i(rq_ready_i[1]), .rq_beat_o(rq_beat_o[1]),
    .rq_be_o(rq_be_o[1]), .rq_slot_o(rq_slot_o[1]),
    .rs_valid_i(rs_valid_i[1]), .rs_slot_i, .rs_data_i, .rs_err_i,
    .out_valid_o(rd_ov[1]), .out_ready_i(rd_or[1]), .out_data_o(rd_od[1]), .out_err_o(rd_oe[1]), .out_last_o(rd_ol[1])
  );
  sf_sparse_stream_rd #(.ADDR_W(ADDR_W), .NSLOT(NSLOT)) u_val (
    .clk_i, .rst_ni, .start_i(rd_start[2]), .base_i(val_base_i), .esz_log2_i(vsz_i), .count_i(nnz_i), .flush_i(rd_flush),
    .busy_o(rd_busy[2]), .rq_valid_o(rq_valid_o[2]), .rq_ready_i(rq_ready_i[2]), .rq_beat_o(rq_beat_o[2]),
    .rq_be_o(rq_be_o[2]), .rq_slot_o(rq_slot_o[2]),
    .rs_valid_i(rs_valid_i[2]), .rs_slot_i, .rs_data_i, .rs_err_i,
    .out_valid_o(rd_ov[2]), .out_ready_i(rd_or[2]), .out_data_o(rd_od[2]), .out_err_o(rd_oe[2]), .out_last_o(rd_ol[2])
  );
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ol = |rd_ol;
  /* verilator lint_on UNUSEDSIGNAL */

  // ---- combinational walk logic
  logic        rp_pop, ci_pop, val_pop;
  logic        ix_v, ev_v;
  logic        f_new;                       // a fault is detected this cycle
  logic [4:0]  f_code;
  logic [31:0] f_elem;
  logic [3:0]  f_stat;
  logic        row_fin;                      // the current row is finished this cycle
  logic        st_rp0_ok, st_row_ok, st_row_empty;
  logic [31:0] p1_in;
  logic [31:0] col_in;
  logic        emit_chk, emit_go;
  logic        ev_nz, ev_first, ev_last;
  logic [31:0] ev_val;

  always_comb begin
    rp_pop = 1'b0; ci_pop = 1'b0; val_pop = 1'b0; ix_v = 1'b0; ev_v = 1'b0;
    f_new = 1'b0; f_code = sf_sparse_pkg::SP_F_NONE; f_elem = '0; f_stat = '0; row_fin = 1'b0;
    st_rp0_ok = 1'b0; st_row_ok = 1'b0; st_row_empty = 1'b0;
    p1_in  = rd_od[0][31:0];
    col_in = rd_od[1][31:0];
    ev_nz = 1'b0; ev_first = 1'b0; ev_last = 1'b0; ev_val = rd_od[2][31:0];
    emit_chk = rd_ov[1] && (!use_val_q || rd_ov[2]);
    emit_go  = 1'b0;

    case (st_q)
      W_RP0: begin
        if (rd_ov[0]) begin
          if (rd_oe[0])                 begin f_new = 1'b1; f_code = sf_sparse_pkg::SP_F_MEM_ERR;    f_elem = 32'd0; f_stat = sf_albion_pkg::SF_ST_TARGET_ERR; end
          else if (p1_in != 32'd0)      begin f_new = 1'b1; f_code = sf_sparse_pkg::SP_F_CSR_ROWPTR; f_elem = 32'd0; end
          else begin rp_pop = 1'b1; st_rp0_ok = 1'b1; end
        end
      end
      W_ROW: begin
        if (rd_ov[0]) begin
          if (rd_oe[0])                 begin f_new = 1'b1; f_code = sf_sparse_pkg::SP_F_MEM_ERR;    f_elem = p0_q; f_stat = sf_albion_pkg::SF_ST_TARGET_ERR; end
          else if ((p1_in < p0_q) || (p1_in > nnz_q) || ((row_q == nrows_q - 32'd1) && (p1_in != nnz_q)))
                                        begin f_new = 1'b1; f_code = sf_sparse_pkg::SP_F_CSR_ROWPTR; f_elem = p0_q; end
          else begin
            rp_pop = 1'b1; st_row_ok = 1'b1; st_row_empty = (p1_in == p0_q);
            if (p1_in == p0_q && !use_val_q) row_fin = 1'b1;          // empty row, nobody needs an event
          end
        end
      end
      W_EMPTY: begin
        ev_v = 1'b1; ev_nz = 1'b0; ev_first = 1'b1; ev_last = 1'b1; ev_val = '0;
        if (ev_ready_i) row_fin = 1'b1;
      end
      W_EMIT: begin
        if (emit_chk) begin
          if (rd_oe[1] || (use_val_q && rd_oe[2])) begin
            f_new = 1'b1; f_code = sf_sparse_pkg::SP_F_MEM_ERR; f_elem = k_q; f_stat = sf_albion_pkg::SF_ST_TARGET_ERR;
          end else if (col_in >= ncols_q) begin
            f_new = 1'b1; f_code = sf_sparse_pkg::SP_F_CSR_COL; f_elem = k_q;
          end else if (ix_ready_i && (!use_val_q || ev_ready_i)) begin
            emit_go = 1'b1; ci_pop = 1'b1; val_pop = use_val_q;
            ix_v = 1'b1;
            ev_v = use_val_q; ev_nz = 1'b1; ev_first = (k_q == p0_q); ev_last = (k_q + 32'd1 == p1_q);
            if (k_q + 32'd1 == p1_q) row_fin = 1'b1;
          end
        end
      end
      default: ;
    endcase
  end
  assign rd_or[0] = rp_pop;
  assign rd_or[1] = ci_pop;
  assign rd_or[2] = val_pop;

  assign ix_valid_o = ix_v;
  assign ix_data_o  = col_in;
  assign ev_valid_o = ev_v;
  assign ev_val_o   = ev_val;
  assign ev_nz_o    = ev_nz;
  assign ev_first_o = ev_first;
  assign ev_last_o  = ev_last;

  wire last_row = (row_q + 32'd1 == nrows_q);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q    <= W_IDLE;
      flt_v_q <= 1'b0;
    end else begin
      if (start_i && !busy_o) begin
        st_q    <= W_RP0;
        flt_v_q <= 1'b0;
      end
      if (f_new && !flt_v_q) begin
        flt_v_q    <= 1'b1;
        st_q       <= W_FAULT;
      end else begin
        case (st_q)
          W_RP0: if (st_rp0_ok) st_q <= (nrows_q == 32'd0) ? W_DONE : W_ROW;
          W_ROW: if (st_row_ok) begin
            if (row_fin)          st_q <= last_row ? W_DONE : W_ROW;
            else if (st_row_empty) st_q <= W_EMPTY;
            else                   st_q <= W_EMIT;
          end
          W_EMPTY: if (row_fin) st_q <= last_row ? W_DONE : W_ROW;
          W_EMIT:  if (row_fin) st_q <= last_row ? W_DONE : W_ROW;
          default: ;
        endcase
      end
      if (flush_i) st_q <= W_IDLE;                 // abort by the engine (fault elsewhere): fall back to idle
    end
  end

  always_ff @(posedge clk_i) begin
    if (start_i && !busy_o) begin
      nrows_q   <= nrows_i;
      ncols_q   <= ncols_i;
      nnz_q     <= nnz_i;
      use_val_q <= use_val_i;
      p0_q      <= 32'd0;
      row_q     <= 32'd0;
      k_q       <= 32'd0;
    end
    if (f_new && !flt_v_q) begin
      flt_code_q <= f_code;
      flt_elem_q <= f_elem;
      flt_stat_q <= f_stat;
    end
    if (st_row_ok) p1_q <= p1_in;
    if (st_row_ok) k_q  <= p0_q;
    if (emit_go)   k_q  <= k_q + 32'd1;
    if (row_fin) begin
      row_q <= row_q + 32'd1;
      p0_q  <= (st_q == W_ROW) ? p1_in : p1_q;
    end
  end

  assign busy_o      = (st_q != W_IDLE && st_q != W_DONE && st_q != W_FAULT) || (|rd_busy);
  assign flt_valid_o = flt_v_q;
  assign flt_code_o  = flt_code_q;
  assign flt_elem_o  = flt_elem_q;
  assign flt_stat_o  = flt_stat_q;

endmodule

`default_nettype wire
