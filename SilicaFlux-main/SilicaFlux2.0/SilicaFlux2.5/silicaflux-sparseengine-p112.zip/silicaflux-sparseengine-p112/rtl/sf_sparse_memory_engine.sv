// =============================================================================
//  sf_sparse_memory_engine.sv -- SilicaFlux Project 112 (SparseEngine), top level
//
//  Command Decoder -> Index Buffer -> Address Generator -> Permission Validation
//  -> Request Coalescer / Scheduler -> (ALP v1 link) -> Response Reorder
//  -> Output Buffer.
//
//  STAGE 1 (this revision): integer-index GATHER.
//
//    out[i] = memory[base + index[i] * element_size]        i = 0 .. n-1
//
//  The memory link is Albion Link Protocol v1 (sf_albion_pkg): 64-bit address,
//  128-bit data, 16 byte enables, 8-bit tag, single-beat requests.  The engine
//  can sit directly on CacheForge's upstream port or on any ALP v1 target.
//  It also tolerates targets that complete out of order (it is a superset of
//  what ALP v1 requires of an initiator; see docs/02 section 9).
//
//  Everything software can observe is specified in docs/02_functional_spec.md.
//  Classification: SYNTHESIZABLE.  No timing / area / power claim is made.
// =============================================================================
`default_nettype none

module sf_sparse_memory_engine #(
  parameter int unsigned ADDR_W         = 40,     // implemented address bits (<= sf_sparse_pkg::SP_ADDR_W <= 48)
  parameter int unsigned NRT            = 16,     // request-table entries (2..32)
  parameter int unsigned ROB_DEPTH      = 32,     // reorder slots (power of two)
  parameter int unsigned IDX_NSLOT      = 4,      // index-reader beat slots
  parameter int unsigned IDX_FIFO       = 4,      // index element FIFO depth
  parameter int unsigned MAX_ELEM_BYTES = 256,    // largest element size E accepted
  parameter int unsigned OBUF_BYTES     = 8192,   // output buffer
  parameter int unsigned IBUF_BYTES     = 8192,   // input (scatter source) buffer
  parameter int unsigned ND             = 4,      // MemoryGuard domains
  parameter int unsigned NR             = 4,      // MemoryGuard regions per domain
  parameter int unsigned NP             = 4,      // MemoryGuard ports
  parameter int unsigned PIDX           = 3,      // this engine's MemoryGuard port (compute accelerator)
  parameter int unsigned CHK_LW         = 30,     // width of the checker length field: extents up to 2^30-1 bytes
  parameter int unsigned LINE_BEATS     = 4,      // 64-byte lines
  parameter int unsigned BANK_LOG2      = 2,
  parameter bit          CSR_EN         = 1'b1,   // CSR traversal ops (CSR_GATHER, CSR_SPMV)
  parameter bit          SPMV_EN        = 1'b1,   // SpMV arithmetic (needs CSR_EN)
  parameter int unsigned SPMV_ACC_W     = 32,     // SpMV accumulator width (16..32)
  parameter bit          SPMV_OVF_WRAP  = 1'b0,   // 0: saturate, 1: wrap
  parameter int unsigned WK_NSLOT       = 4,      // beat slots of each CSR array reader
  parameter int unsigned EV_DEPTH       = 32,     // value / row-boundary event FIFO
  parameter int unsigned CNT_W          = 32
) (
  input  wire logic                                  clk_i,
  input  wire logic                                  rst_ni,
  // ---- command / completion
  input  wire logic                                  cmd_valid_i,
  output logic                                       cmd_ready_o,
  input  sf_sparse_pkg::sf_sp_cmd_t                  cmd_i,
  output logic                                       done_valid_o,
  input  wire logic                                  done_ready_i,
  output sf_sparse_pkg::sf_sp_done_t                 done_o,
  // ---- runtime configuration (static while busy)
  input  wire logic [7:0]                            cfg_max_out_i,     // outstanding link requests allowed (<= target's advertised limit)
  input  wire logic                                  cfg_merge_en_i,    // request merging / deduplication
  input  wire logic                                  cfg_burst_en_i,    // burst-seeking issue order
  // ---- index push port (idx_stream commands)
  input  wire logic                                  ipush_valid_i,
  output logic                                       ipush_ready_o,
  input  wire logic [31:0]                           ipush_data_i,
  // ---- input buffer, host write port (scatter source data)
  input  wire logic                                  ibuf_we_i,
  input  wire logic [$clog2(IBUF_BYTES/16)-1:0]      ibuf_waddr_i,      // 16-byte word address
  input  wire logic [127:0]                          ibuf_wdata_i,
  input  wire logic [15:0]                           ibuf_wbe_i,
  // ---- output buffer, host read port (registered: data one cycle after the address)
  input  wire logic [$clog2(OBUF_BYTES/16)-1:0]      obuf_raddr_i,
  output logic [127:0]                               obuf_rdata_o,
  // ---- ALP v1 link (initiator)
  output logic                                       req_valid_o,
  input  wire logic                                  req_ready_i,
  output sf_albion_pkg::sf_req_t                     req_o,
  input  wire logic                                  rsp_valid_i,
  output logic                                       rsp_ready_o,
  input  sf_albion_pkg::sf_rsp_t                     rsp_i,
  // ---- MemoryGuard region table (flat, as exported by sf_memory_guard_regions)
  input  wire logic [ND*NR-1:0]                      t_valid_i,
  input  wire logic [ND*NR*ADDR_W-1:0]               t_base_i,
  input  wire logic [ND*NR*(ADDR_W+1)-1:0]           t_end_i,
  input  wire logic [ND*NR-1:0]                      t_r_i,
  input  wire logic [ND*NR-1:0]                      t_w_i,
  input  wire logic [ND*NR-1:0]                      t_devn_i,
  input  wire logic [ND*NR*NP-1:0]                   t_dev_i,
  input  wire logic [NP*ND-1:0]                      t_allow_i,
  // ---- status / performance
  output logic                                       busy_o,
  output logic [sf_sparse_pkg::SP_PC_N*CNT_W-1:0]    perf_o,
  input  wire logic                                  perf_clear_i
);

  // the MemoryGuard checker needs AW >= LW; a length of 2^ADDR_W or more can never be valid anyway
  localparam int unsigned LW         = (CHK_LW < ADDR_W) ? CHK_LW : ADDR_W;
  localparam int unsigned OBUF_WORDS = OBUF_BYTES / 16;
  localparam int unsigned IBUF_WORDS = IBUF_BYTES / 16;
  localparam int unsigned OBW        = $clog2(OBUF_WORDS);
  localparam int unsigned IBW        = $clog2(IBUF_WORDS);
  localparam int unsigned BA_W       = ADDR_W - 4;
  localparam int unsigned RTW        = $clog2(NRT);
  localparam int unsigned NSRC       = 5;     // link requesters: 0 coalescer, 1 index reader, 2..4 CSR readers (stage 3)

  if (ADDR_W < 20 || ADDR_W > sf_sparse_pkg::SP_ADDR_W)           begin : g_c1 $error("ADDR_W must be 20..sf_sparse_pkg::SP_ADDR_W"); end
  if (MAX_ELEM_BYTES > 4095)                       begin : g_c2 $error("MAX_ELEM_BYTES must fit the 12-bit element field"); end
  if (MAX_ELEM_BYTES >= 16 && (MAX_ELEM_BYTES % 16) != 0) begin : g_c3 $error("MAX_ELEM_BYTES must be < 16 or a multiple of 16"); end
  if (MAX_ELEM_BYTES / 16 > ROB_DEPTH)             begin : g_c4 $error("a maximal element must fit the reorder buffer"); end
  if ((OBUF_BYTES % 16) != 0 || (OBUF_WORDS & (OBUF_WORDS - 1)) != 0) begin : g_c5 $error("OBUF_BYTES: power-of-two multiple of 16"); end
  if ((IBUF_BYTES % 16) != 0 || (IBUF_WORDS & (IBUF_WORDS - 1)) != 0) begin : g_c6 $error("IBUF_BYTES: power-of-two multiple of 16"); end
  if (CHK_LW > 30 || CHK_LW < 12)                  begin : g_c7 $error("CHK_LW must be 12..30"); end

  // ===========================================================================
  // control state
  // ===========================================================================
  typedef enum logic [2:0] {S_IDLE, S_DECODE, S_CHECK, S_RUN, S_DONE} state_e;
  state_e state_q;

  sf_sparse_pkg::sf_sp_cmd_t  c_q;
  logic [31:0] cyc_q;
  logic        go;                     // pulse in the last CHECK cycle: start the pipelines

  // fault record
  logic        flt_v_q;
  logic [4:0]  flt_code_q;
  logic [3:0]  flt_g_q, flt_s_q;
  logic [31:0] flt_elem_q;
  logic [ADDR_W-1:0] flt_addr_q;
  logic        deliver_abort_q;

  // ===========================================================================
  // command decode (from the registered command)
  // ===========================================================================
  wire [11:0] E       = c_q.elem_bytes;
  wire        e_small = (E < 12'd16);
  wire [11:0] e_amask = e_small ? (E - 12'd1) : 12'd15;      // alignment mask of an element
  wire [2:0]  iw_b    = 3'd1 << c_q.idx_w;                    // index bytes
  wire        is_gather  = (c_q.op == sf_sparse_pkg::SP_OP_GATHER);
  wire        is_scatter = (c_q.op == sf_sparse_pkg::SP_OP_SCATTER);
  wire        is_csr_g   = CSR_EN && (c_q.op == sf_sparse_pkg::SP_OP_CSR_GATHER);
  wire        is_spmv    = CSR_EN && SPMV_EN && (c_q.op == sf_sparse_pkg::SP_OP_CSR_SPMV);
  wire        is_csr     = is_csr_g || is_spmv;
  wire        is_gs      = is_gather || is_scatter;
  wire [sf_sparse_pkg::SP_OFF_W-1:0] buf_off = is_scatter ? c_q.src_off : c_q.dst_off;   // local-buffer window of the command
  wire [2:0]  ci_b    = 3'd1 << c_q.ci_w;                     // column-index bytes
  wire        e_valid = !(E == 12'd0 || E > 12'(MAX_ELEM_BYTES) ||
                          (e_small && ((E & (E - 12'd1)) != 12'd0)) ||
                          (!e_small && (E[3:0] != 4'd0)));

  logic [4:0] dec_fault;
  always_comb begin
    logic [63:0] span;
    dec_fault = sf_sparse_pkg::SP_F_NONE;
    span      = 64'd0;
    if (is_gs) begin
      // ---- gather / scatter
      span = {32'd0, c_q.n} * {52'd0, E};
      if (!e_valid)                                                                dec_fault = sf_sparse_pkg::SP_F_BAD_ELEM;
      else if (c_q.idx_w == 2'd3)                                                  dec_fault = sf_sparse_pkg::SP_F_BAD_IDXW;
      else if ((c_q.base[11:0] & e_amask) != 12'd0)                                dec_fault = sf_sparse_pkg::SP_F_ALIGN;
      else if (!c_q.idx_stream && ((c_q.idx_base[2:0] & (iw_b - 3'd1)) != 3'd0))  dec_fault = sf_sparse_pkg::SP_F_ALIGN;
      else if ((buf_off[11:0] & e_amask) != 12'd0)                                 dec_fault = sf_sparse_pkg::SP_F_ALIGN;
      else if ({44'd0, buf_off} + span > (is_scatter ? 64'(IBUF_BYTES) : 64'(OBUF_BYTES))) dec_fault = sf_sparse_pkg::SP_F_BUF_RANGE;
      else if (c_q.base[sf_sparse_pkg::SP_ADDR_W-1:ADDR_W] != '0)                                 dec_fault = sf_sparse_pkg::SP_F_ADDR_OVF;
      else if (!c_q.idx_stream && (c_q.idx_base[sf_sparse_pkg::SP_ADDR_W-1:ADDR_W] != '0))        dec_fault = sf_sparse_pkg::SP_F_ADDR_OVF;
    end else if (is_csr) begin
      // ---- CSR traversal / SpMV
      span = is_spmv ? ({32'd0, c_q.nrows} << 2) : ({32'd0, c_q.nnz} * {52'd0, E});
      if (!e_valid)                                                                dec_fault = sf_sparse_pkg::SP_F_BAD_ELEM;
      else if (c_q.ci_w == 2'd3 || c_q.vfmt > 3'd3)                                dec_fault = sf_sparse_pkg::SP_F_CSR_FMT;
      else if ((c_q.nrows == 32'd0 || c_q.ncols == 32'd0) && c_q.nnz != 32'd0)     dec_fault = sf_sparse_pkg::SP_F_CSR_DIM;
      else if (is_spmv && (c_q.vfmt != sf_sparse_pkg::SP_VF_INT8 || E != 12'd1))                  dec_fault = sf_sparse_pkg::SP_F_UNSUP;
      else if ((c_q.base[11:0] & e_amask) != 12'd0)                                dec_fault = sf_sparse_pkg::SP_F_ALIGN;
      else if (c_q.rp_base[1:0] != 2'd0)                                           dec_fault = sf_sparse_pkg::SP_F_ALIGN;
      else if ((c_q.ci_base[2:0] & (ci_b - 3'd1)) != 3'd0)                         dec_fault = sf_sparse_pkg::SP_F_ALIGN;
      else if (((is_spmv ? 12'd3 : e_amask) & c_q.dst_off[11:0]) != 12'd0)         dec_fault = sf_sparse_pkg::SP_F_ALIGN;
      else if ({44'd0, c_q.dst_off} + span > 64'(OBUF_BYTES))                      dec_fault = sf_sparse_pkg::SP_F_BUF_RANGE;
      else if (c_q.base[sf_sparse_pkg::SP_ADDR_W-1:ADDR_W] != '0 || c_q.rp_base[sf_sparse_pkg::SP_ADDR_W-1:ADDR_W] != '0 ||
               c_q.ci_base[sf_sparse_pkg::SP_ADDR_W-1:ADDR_W] != '0 || (is_spmv && c_q.val_base[sf_sparse_pkg::SP_ADDR_W-1:ADDR_W] != '0))
                                                                                   dec_fault = sf_sparse_pkg::SP_F_ADDR_OVF;
    end else begin
      dec_fault = sf_sparse_pkg::SP_F_BAD_OP;
    end
  end

  // ===========================================================================
  // validation sequencer: array extents checked once, up front
  // ===========================================================================
  logic [2:0]  chk_step_q;
  logic        item_v;
  logic [ADDR_W-1:0] item_addr;
  logic [47:0] item_len;
  always_comb begin
    item_v    = 1'b0;
    item_addr = '0;
    item_len  = '0;
    case (chk_step_q)
      3'd0: begin   // gather / scatter: index array
        item_v    = is_gs && !c_q.idx_stream && (c_q.n != 32'd0);
        item_addr = c_q.idx_base[ADDR_W-1:0];
        item_len  = 48'(c_q.n) << c_q.idx_w;
      end
      3'd1: begin   // CSR: row-pointer array, nrows + 1 words
        item_v    = is_csr;
        item_addr = c_q.rp_base[ADDR_W-1:0];
        item_len  = (48'(c_q.nrows) + 48'd1) << 2;
      end
      3'd2: begin   // CSR: column-index array
        item_v    = is_csr && (c_q.nnz != 32'd0);
        item_addr = c_q.ci_base[ADDR_W-1:0];
        item_len  = 48'(c_q.nnz) << c_q.ci_w;
      end
      3'd3: begin   // SpMV: value array (INT8)
        item_v    = is_spmv && (c_q.nnz != 32'd0);
        item_addr = c_q.val_base[ADDR_W-1:0];
        item_len  = 48'(c_q.nnz);
      end
      3'd4: begin   // CSR: the whole x vector, ncols elements
        item_v    = is_csr && (c_q.nnz != 32'd0);
        item_addr = c_q.base[ADDR_W-1:0];
        item_len  = 48'(c_q.ncols) * 48'(E);
      end
      default: ;
    endcase
  end
  wire        item_big    = (item_len >= (48'd1 << LW));
  wire        chk_last    = is_csr ? (chk_step_q == 3'd4) : (chk_step_q == 3'd0);

  // ===========================================================================
  // element pipeline
  // ===========================================================================
  // ---- index buffer
  logic                  ib_start, ib_flush, ib_busy, ib_done;
  logic                  ib_rq_valid, ib_rq_ready;
  logic [BA_W-1:0]       ib_rq_beat;
  logic [15:0]           ib_rq_be;
  logic [$clog2(IDX_NSLOT)-1:0] ib_rq_slot, ib_rs_slot;
  logic                  ib_rs_valid, ib_rs_err;
  logic                  idx_valid, idx_ready, idx_neg, idx_err;
  logic [31:0]           idx_val;
  logic                  ib_push_ready;
  logic                  wk_ix_valid;
  logic [31:0]           wk_ix_data;
  wire  [31:0]           ib_count = is_csr ? c_q.nnz : c_q.n;
  assign ipush_ready_o = ib_push_ready && !is_csr;

  sf_sparse_index_buffer #(.ADDR_W(ADDR_W), .IDX_W(32), .NSLOT(IDX_NSLOT), .DEPTH(IDX_FIFO)) u_ib (
    .clk_i, .rst_ni,
    .start_i(ib_start), .src_push_i(c_q.idx_stream || is_csr), .base_i(c_q.idx_base[ADDR_W-1:0]),
    .w_log2_i(is_csr ? 2'd2 : c_q.idx_w), .signed_i(!is_csr && c_q.idx_signed), .count_i(ib_count), .flush_i(ib_flush),
    .close_i(wk_flt_valid),
    .busy_o(ib_busy), .done_o(ib_done),
    .rq_valid_o(ib_rq_valid), .rq_ready_i(ib_rq_ready), .rq_beat_o(ib_rq_beat), .rq_be_o(ib_rq_be), .rq_slot_o(ib_rq_slot),
    .rs_valid_i(ib_rs_valid), .rs_slot_i(ib_rs_slot), .rs_data_i(rsp_i.data), .rs_err_i(ib_rs_err),
    .push_valid_i(is_csr ? wk_ix_valid : ipush_valid_i), .push_ready_o(ib_push_ready),
    .push_data_i(is_csr ? wk_ix_data : ipush_data_i),
    .idx_valid_o(idx_valid), .idx_ready_i(idx_ready), .idx_val_o(idx_val), .idx_neg_o(idx_neg), .idx_err_o(idx_err)
  );
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ib_done = ib_done;
  /* verilator lint_on UNUSEDSIGNAL */

  // ---- address generator
  logic                  ag_flush, ag_busy;
  logic                  ea_valid, ea_ready;
  logic [ADDR_W-1:0]     ea_addr;
  logic [31:0]           ea_idx;
  logic [4:0]            ea_fault;

  sf_sparse_address_gen #(.ADDR_W(ADDR_W), .IDX_W(32), .EB_W(12)) u_ag (
    .clk_i, .rst_ni, .start_i(ib_start), .flush_i(ag_flush),
    .base_i(c_q.base[ADDR_W-1:0]), .elem_bytes_i(E), .idx_limit_i(is_csr ? c_q.ncols : c_q.idx_limit),
    .idx_valid_i(idx_valid), .idx_ready_o(idx_ready), .idx_val_i(idx_val), .idx_neg_i(idx_neg), .idx_err_i(idx_err),
    .ea_valid_o(ea_valid), .ea_ready_i(ea_ready), .ea_addr_o(ea_addr), .ea_idx_o(ea_idx), .ea_fault_o(ea_fault),
    .busy_o(ag_busy)
  );

  // ---- permission validation (MemoryGuard checker, unmodified)
  logic [1:0]            chk_op;
  logic [ADDR_W-1:0]     chk_addr;
  logic [LW-1:0]         chk_len;
  logic [sf_sparse_pkg::SP_DOM_W-1:0]   chk_dom;
  logic                  chk_permit;
  logic [3:0]            chk_fault;
  wire                   chk_elem_mode = (state_q == S_RUN);
  always_comb begin
    chk_dom = c_q.dom;
    if (chk_elem_mode) begin
      chk_op   = is_scatter ? sf_memory_guard_pkg::OP_WRITE : sf_memory_guard_pkg::OP_READ;
      chk_addr = ea_addr;
      chk_len  = LW'(E);
    end else begin
      chk_op   = sf_memory_guard_pkg::OP_READ;
      chk_addr = item_addr;
      chk_len  = item_len[LW-1:0];
    end
  end

  sf_memory_guard_checker #(
    .ND(ND), .NR(NR), .NP(NP), .AW(ADDR_W), .LW(LW), .DOMW(sf_sparse_pkg::SP_DOM_W), .PIDX(PIDX),
    .MAXLEN((1 << LW) - 1), .LEN_POW2(0), .LOOKUP_ARCH(0), .DIAG_PRECISE(1)
  ) u_chk (
    .c_op(chk_op), .c_addr(chk_addr), .c_len(chk_len), .c_dom(chk_dom),
    .allow(t_allow_i[PIDX*ND +: ND]),
    .t_valid(t_valid_i), .t_base(t_base_i), .t_end(t_end_i), .t_r(t_r_i), .t_w(t_w_i),
    .t_devn(t_devn_i), .t_dev(t_dev_i),
    .permit(chk_permit), .fault(chk_fault), .edom()
  );

  // ---- element -> beat descriptors
  logic                  sp_ea_valid, sp_ea_ready;
  logic                  bd_valid, bd_last, sp_busy;
  logic [BA_W-1:0]       bd_beat;
  logic [3:0]            bd_lane;
  logic [15:0]           bd_be;
  logic [31:0]           bd_elem;

  sf_sparse_beat_split #(.ADDR_W(ADDR_W), .EB_W(12)) u_sp (
    .clk_i, .rst_ni, .flush_i(1'b0), .elem_bytes_i(E),
    .ea_valid_i(sp_ea_valid), .ea_ready_o(sp_ea_ready), .ea_addr_i(ea_addr), .ea_idx_i(ea_idx),
    .bd_valid_o(bd_valid), .bd_ready_i(bd_ready), .bd_beat_o(bd_beat), .bd_lane_o(bd_lane), .bd_be_o(bd_be),
    .bd_elem_o(bd_elem), .bd_last_o(bd_last), .busy_o(sp_busy)
  );
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_bd_last = bd_last;
  /* verilator lint_on UNUSEDSIGNAL */

  // ---- scatter source stage: input-buffer read + lane alignment, in front of the coalescer
  //      (gather bypasses it: its descriptors go straight to the coalescer)
  logic [127:0]          ibuf_q [IBUF_WORDS];
  logic [127:0]          ibuf_rd_q;
  logic [sf_sparse_pkg::SP_OFF_W-1:0]   s_ptr_q;               // byte offset of the source bytes of the next beat
  logic                  sg_valid_q, sg_last_q;
  logic [BA_W-1:0]       sg_beat_q;
  logic [3:0]            sg_lane_q, sg_slane_q;
  logic [15:0]           sg_be_q;
  logic [31:0]           sg_elem_q;
  logic                  co_in_ready;
  logic [31:0]           sc_elems_q;
  wire                   sg_ready  = !sg_valid_q || co_in_ready;
  wire                   sg_accept = is_scatter && bd_valid && sg_ready;
  wire                   sg_fire   = sg_valid_q && co_in_ready;
  wire                   bd_ready  = is_scatter ? sg_ready : co_in_ready;
  logic [3:0]            sg_rsh;
  logic [127:0]          sg_rot;
  always_comb begin
    sg_rsh = sg_lane_q - sg_slane_q;
    sg_rot = 128'(({ibuf_rd_q, ibuf_rd_q} >> {((5'd16 - {1'b0, sg_rsh}) & 5'h0F), 3'b000}));
  end
  wire                   co_in_valid = is_scatter ? sg_valid_q : bd_valid;
  wire [BA_W-1:0]        co_in_beat  = is_scatter ? sg_beat_q  : bd_beat;
  wire [15:0]            co_in_be    = is_scatter ? sg_be_q    : bd_be;
  wire [31:0]            co_in_elem  = is_scatter ? sg_elem_q  : bd_elem;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sg_valid_q <= 1'b0;
    end else begin
      if (sg_ready) sg_valid_q <= sg_accept;
    end
  end
  always_ff @(posedge clk_i) begin
    if (sg_accept) begin
      sg_beat_q  <= bd_beat;
      sg_lane_q  <= bd_lane;
      sg_slane_q <= s_ptr_q[3:0];
      sg_be_q    <= bd_be;
      sg_elem_q  <= bd_elem;
      sg_last_q  <= bd_last;
      ibuf_rd_q  <= ibuf_q[s_ptr_q[IBW+3:4]];
    end
    if (ibuf_we_i) begin
      for (int b = 0; b < 16; b++)
        if (ibuf_wbe_i[b]) ibuf_q[ibuf_waddr_i][b*8 +: 8] <= ibuf_wdata_i[b*8 +: 8];
    end
  end

  // element-stage decision
  wire ea_pass      = ea_valid && (ea_fault == sf_sparse_pkg::SP_F_NONE) && chk_permit;
  wire ea_fault_new = ea_valid && !(ea_fault == sf_sparse_pkg::SP_F_NONE && chk_permit);
  // An element is discarded when a fault exists AT OR BEFORE it (position based: a fault raised by the CSR walker
  // is later in stream order than the elements still travelling through this stage, which must complete).
  wire ea_drop       = ea_valid && flt_v_q && (ea_idx >= flt_elem_q);
  assign sp_ea_valid = (state_q == S_RUN) && ea_pass && !ea_drop;
  assign ea_ready    = (state_q == S_RUN) && (ea_drop || ea_fault_new || sp_ea_ready);

  // ---- request coalescer / table / reorder buffer
  logic                  co_alloc_valid;
  logic [RTW-1:0]        co_alloc_rt;
  logic                  rob_ready;
  logic                  co_rel_valid;
  logic [RTW-1:0]        co_rel_rt, co_rd_rt;
  logic [127:0]          co_rd_data;
  logic                  co_rd_done;
  logic [3:0]            co_rd_stat;
  logic                  co_rq_valid, co_rq_ready, co_rq_wr;
  logic [BA_W-1:0]       co_rq_beat;
  logic [15:0]           co_rq_be;
  logic [127:0]          co_rq_wdata;
  logic [7:0]            co_rq_tag;
  logic                  co_rs_valid;
  logic [4:0]            co_rs_idx;
  logic                  co_empty, co_proto;
  logic [$clog2(NRT+1)-1:0] co_occ;
  logic                  ev_merge, ev_dup, ev_cont, ev_bank, ev_stall_rt, ev_stall_rob, ev_lat_v;
  logic [15:0]           ev_lat;
  logic                  werr_valid;
  logic [31:0]           werr_elem;
  logic [3:0]            werr_stat;
  logic [BA_W-1:0]       werr_beat;

  sf_sparse_request_coalescer #(
    .ADDR_W(ADDR_W), .NRT(NRT), .ROB_DEPTH(ROB_DEPTH), .LINE_BEATS(LINE_BEATS), .BANK_LOG2(BANK_LOG2)
  ) u_co (
    .clk_i, .rst_ni, .cfg_merge_en_i, .cfg_burst_en_i,
    .in_valid_i(co_in_valid), .in_ready_o(co_in_ready), .in_wr_i(is_scatter), .in_beat_i(co_in_beat), .in_be_i(co_in_be),
    .in_wdata_i(sg_rot), .in_elem_i(co_in_elem), .rob_ready_i(rob_ready),
    .alloc_valid_o(co_alloc_valid), .alloc_rt_o(co_alloc_rt),
    .rel_valid_i(co_rel_valid), .rel_rt_i(co_rel_rt),
    .rd_rt_i(co_rd_rt), .rd_data_o(co_rd_data), .rd_done_o(co_rd_done), .rd_stat_o(co_rd_stat),
    .rq_valid_o(co_rq_valid), .rq_ready_i(co_rq_ready), .rq_wr_o(co_rq_wr), .rq_beat_o(co_rq_beat),
    .rq_be_o(co_rq_be), .rq_wdata_o(co_rq_wdata), .rq_tag_o(co_rq_tag),
    .rs_valid_i(co_rs_valid), .rs_idx_i(co_rs_idx), .rs_data_i(rsp_i.data), .rs_stat_i(rsp_i.status),
    .werr_valid_o(werr_valid), .werr_elem_o(werr_elem), .werr_stat_o(werr_stat), .werr_beat_o(werr_beat),
    .empty_o(co_empty), .occ_o(co_occ), .proto_err_o(co_proto),
    .ev_merge_o(ev_merge), .ev_dup_o(ev_dup), .ev_cont_o(ev_cont), .ev_bank_o(ev_bank),
    .ev_stall_rt_o(ev_stall_rt), .ev_stall_rob_o(ev_stall_rob), .ev_lat_valid_o(ev_lat_v), .ev_lat_o(ev_lat)
  );

  logic                  dv_valid, dv_ready, rob_empty;
  logic [127:0]          dv_data;
  logic [3:0]            dv_lane, dv_stat;
  logic [$clog2(ROB_DEPTH+1)-1:0] rob_occ;

  sf_sparse_reorder #(.ROB_DEPTH(ROB_DEPTH), .NRT(NRT)) u_rob (
    .clk_i, .rst_ni,
    .alloc_valid_i(co_alloc_valid), .alloc_rt_i(co_alloc_rt), .alloc_lane_i(bd_lane), .rob_ready_o(rob_ready),
    .rd_rt_o(co_rd_rt), .rd_data_i(co_rd_data), .rd_done_i(co_rd_done), .rd_stat_i(co_rd_stat),
    .rel_valid_o(co_rel_valid), .rel_rt_o(co_rel_rt),
    .dv_valid_o(dv_valid), .dv_ready_i(dv_ready), .dv_data_o(dv_data), .dv_lane_o(dv_lane), .dv_stat_o(dv_stat),
    .empty_o(rob_empty), .occ_o(rob_occ)
  );

  // ===========================================================================
  // CSR traversal (walker), value / row-boundary events and the SpMV arithmetic lane
  // ===========================================================================
  logic [2:0]                            wk_rq_valid, wk_rq_ready, wk_rs_valid;
  logic [2:0][BA_W-1:0]                  wk_rq_beat;
  logic [2:0][15:0]                      wk_rq_be;
  logic [2:0][$clog2(WK_NSLOT)-1:0]      wk_rq_slot;
  logic                                  wk_busy, wk_start, wk_flush, wk_rs_err;
  logic                                  wk_flt_valid;
  logic [4:0]                            wk_flt_code;
  logic [31:0]                           wk_flt_elem;
  logic [3:0]                            wk_flt_stat;
  logic                                  wk_ev_valid, wk_ev_ready, wk_ev_nz, wk_ev_first, wk_ev_last;
  logic [31:0]                           wk_ev_val;
  logic                                  sp_x_valid, sp_x_ready, spm_busy, sp_y_valid, sp_ovf, sp_start;
  logic [31:0]                           sp_y_row, sp_y_data;
  logic                                  evf_empty, evf_head_nz;

  if (CSR_EN) begin : g_csr
    sf_sparse_csr_walker #(.ADDR_W(ADDR_W), .NSLOT(WK_NSLOT)) u_wk (
      .clk_i, .rst_ni, .start_i(wk_start), .flush_i(wk_flush),
      .rp_base_i(c_q.rp_base[ADDR_W-1:0]), .ci_base_i(c_q.ci_base[ADDR_W-1:0]), .val_base_i(c_q.val_base[ADDR_W-1:0]),
      .nrows_i(c_q.nrows), .ncols_i(c_q.ncols), .nnz_i(c_q.nnz), .ci_w_i(c_q.ci_w), .vsz_i(2'd0), .use_val_i(is_spmv),
      .busy_o(wk_busy),
      .rq_valid_o(wk_rq_valid), .rq_ready_i(wk_rq_ready), .rq_beat_o(wk_rq_beat), .rq_be_o(wk_rq_be), .rq_slot_o(wk_rq_slot),
      .rs_valid_i(wk_rs_valid), .rs_slot_i(rsp_i.tag[$clog2(WK_NSLOT)-1:0]), .rs_data_i(rsp_i.data), .rs_err_i(wk_rs_err),
      .ix_valid_o(wk_ix_valid), .ix_ready_i(ib_push_ready), .ix_data_o(wk_ix_data),
      .ev_valid_o(wk_ev_valid), .ev_ready_i(wk_ev_ready), .ev_val_o(wk_ev_val), .ev_nz_o(wk_ev_nz),
      .ev_first_o(wk_ev_first), .ev_last_o(wk_ev_last),
      .flt_valid_o(wk_flt_valid), .flt_code_o(wk_flt_code), .flt_elem_o(wk_flt_elem), .flt_stat_o(wk_flt_stat)
    );
  end else begin : g_nocsr
    assign wk_busy = 1'b0;
    assign wk_rq_valid = '0; assign wk_rq_beat = '0; assign wk_rq_be = '0; assign wk_rq_slot = '0;
    assign wk_ix_valid = 1'b0; assign wk_ix_data = '0;
    assign wk_ev_valid = 1'b0; assign wk_ev_val = '0; assign wk_ev_nz = 1'b0; assign wk_ev_first = 1'b0; assign wk_ev_last = 1'b0;
    assign wk_flt_valid = 1'b0; assign wk_flt_code = '0; assign wk_flt_elem = '0; assign wk_flt_stat = '0;
  end

  if (CSR_EN && SPMV_EN) begin : g_spmv
    localparam int unsigned EVW = $clog2(EV_DEPTH);
    logic [10:0]       evf_mem [EV_DEPTH];          // {last, first, nz, val[7:0]}
    logic [EVW-1:0]    evf_wp_q, evf_rp_q;
    logic [EVW:0]      evf_cnt_q;
    wire               evf_clear = (state_q == S_DECODE) || (state_q == S_DONE);
    wire               evf_full  = (evf_cnt_q == (EVW+1)'(EV_DEPTH));
    wire               evf_push  = wk_ev_valid && !evf_full;
    wire [10:0]        evf_head  = evf_mem[evf_rp_q];
    logic              sp_ev_ready;
    wire               evf_pop   = sp_ev_ready && !evf_empty;
    assign wk_ev_ready = !evf_full;
    assign evf_empty   = (evf_cnt_q == '0);
    assign evf_head_nz = evf_head[8];
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        evf_wp_q <= '0; evf_rp_q <= '0; evf_cnt_q <= '0;
      end else if (evf_clear) begin
        evf_wp_q <= '0; evf_rp_q <= '0; evf_cnt_q <= '0;
      end else begin
        if (evf_push) evf_wp_q <= evf_wp_q + EVW'(1);
        if (evf_pop)  evf_rp_q <= evf_rp_q + EVW'(1);
        evf_cnt_q <= evf_cnt_q + (EVW+1)'(evf_push) - (EVW+1)'(evf_pop);
      end
    end
    always_ff @(posedge clk_i) if (evf_push) evf_mem[evf_wp_q] <= {wk_ev_last, wk_ev_first, wk_ev_nz, wk_ev_val[7:0]};

    sf_sparse_spmv #(.ACC_W(SPMV_ACC_W), .OVF_WRAP(SPMV_OVF_WRAP), .MUL_STAGES(1)) u_spmv (
      .clk_i, .rst_ni, .start_i(sp_start),
      .ev_valid_i(!evf_empty), .ev_ready_o(sp_ev_ready), .ev_val_i(evf_head[7:0]), .ev_nz_i(evf_head[8]),
      .ev_first_i(evf_head[9]), .ev_last_i(evf_head[10]),
      .x_valid_i(sp_x_valid), .x_ready_o(sp_x_ready), .x_data_i(dv_data[{dv_lane, 3'b000} +: 8]),
      .y_valid_o(sp_y_valid), .y_row_o(sp_y_row), .y_data_o(sp_y_data), .ovf_o(sp_ovf), .busy_o(spm_busy)
    );
  end else begin : g_nospmv
    assign wk_ev_ready = 1'b1;
    assign evf_empty = 1'b1; assign evf_head_nz = 1'b0;
    assign sp_x_ready = 1'b1; assign sp_y_valid = 1'b0; assign sp_y_row = '0; assign sp_y_data = '0;
    assign sp_ovf = 1'b0; assign spm_busy = 1'b0;
  end

  // ===========================================================================
  // link arbiter (requesters 0..NSRC-1), response routing by tag
  // ===========================================================================
  logic [NSRC-1:0]           rq_v;
  logic [NSRC-1:0]           rq_rd;                // 1 = READ
  logic [NSRC-1:0][BA_W-1:0] rq_beat;
  logic [NSRC-1:0][15:0]     rq_be;
  logic [NSRC-1:0][127:0]    rq_wd;
  logic [NSRC-1:0][7:0]      rq_tag;
  logic [NSRC-1:0]           rq_gnt;

  always_comb begin
    rq_v = '0; rq_rd = '1; rq_beat = '0; rq_be = '0; rq_wd = '0; rq_tag = '0;
    rq_v[0]    = co_rq_valid;
    rq_rd[0]   = !co_rq_wr;
    rq_beat[0] = co_rq_beat;
    rq_be[0]   = co_rq_be;
    rq_wd[0]   = co_rq_wdata;
    rq_tag[0]  = co_rq_tag;
    rq_v[1]    = ib_rq_valid;
    rq_beat[1] = ib_rq_beat;
    rq_be[1]   = ib_rq_be;
    rq_tag[1]  = {sf_sparse_pkg::SP_TAGSRC_IDX, 5'(ib_rq_slot)};
    for (int i = 0; i < 3; i++) begin
      rq_v[2+i]    = wk_rq_valid[i];
      rq_beat[2+i] = wk_rq_beat[i];
      rq_be[2+i]   = wk_rq_be[i];
    end
    rq_tag[2]  = {sf_sparse_pkg::SP_TAGSRC_RP,  5'(wk_rq_slot[0])};
    rq_tag[3]  = {sf_sparse_pkg::SP_TAGSRC_CI,  5'(wk_rq_slot[1])};
    rq_tag[4]  = {sf_sparse_pkg::SP_TAGSRC_VAL, 5'(wk_rq_slot[2])};
  end

  logic [7:0]       out_q;
  logic             lock_q;
  logic [NSRC-1:0]  gnt_q;
  logic [2:0]       rr_q;
  logic [NSRC-1:0]  gnt;
  wire              out_ok = (out_q < cfg_max_out_i);

  always_comb begin
    int unsigned jj;
    logic        found;
    gnt   = '0;
    found = 1'b0;
    jj    = 0;
    if (lock_q) begin
      gnt = gnt_q;
    end else begin
      for (int k = 0; k < NSRC; k++) begin
        jj = int'(rr_q) + k;
        if (jj >= NSRC) jj = jj - NSRC;
        if (!found && rq_v[jj]) begin
          gnt[jj] = 1'b1;
          found   = 1'b1;
        end
      end
    end
  end
  wire link_valid = (|(gnt & rq_v)) && out_ok;
  wire link_fire  = link_valid && req_ready_i;
  assign rq_gnt   = gnt & {NSRC{link_fire}};
  assign co_rq_ready = rq_gnt[0];
  assign ib_rq_ready = rq_gnt[1];
  assign wk_rq_ready = rq_gnt[4:2];

  always_comb begin
    req_o       = '0;
    req_o.op    = sf_albion_pkg::SF_OP_READ;
    for (int j = 0; j < NSRC; j++) begin
      if (gnt[j]) begin
        req_o.op   = rq_rd[j] ? sf_albion_pkg::SF_OP_READ : sf_albion_pkg::SF_OP_WRITE;
        req_o.tag  = rq_tag[j];
        req_o.addr = {{(64-ADDR_W){1'b0}}, rq_beat[j], 4'b0000};
        req_o.be   = rq_be[j];
        req_o.data = rq_wd[j];
      end
    end
    req_o.dom       = sf_albion_pkg::SF_DOM_TENANT_FIRST + 8'(c_q.dom);
    req_o.attr      = '0;
    req_o.attr.mem_type = c_q.cacheable ? sf_albion_pkg::SF_MEM_NORMAL_WB : sf_albion_pkg::SF_MEM_NORMAL_NC;
  end
  assign req_valid_o = link_valid;
  assign rsp_ready_o = 1'b1;

  // A response the engine has just identified as protocol-invalid (unknown source tag, or a data-path tag that names no
  // in-flight table entry) answers none of its requests, so it must not be counted against the outstanding total:
  // counting it would make the real response underflow the counter and the command could never complete (docs/02 §7).
  wire [2:0] rsp_src     = rsp_i.tag[7:5];
  wire       rsp_unknown = rsp_valid_i && (rsp_src > sf_sparse_pkg::SP_TAGSRC_VAL);
  wire       rsp_counted = rsp_valid_i && !rsp_unknown && !co_proto;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      lock_q <= 1'b0;
      gnt_q  <= '0;
      rr_q   <= '0;
      out_q  <= '0;
    end else begin
      lock_q <= link_valid && !req_ready_i;
      gnt_q  <= gnt;
      if (link_fire) begin
        for (int j = 0; j < NSRC; j++) if (gnt[j]) rr_q <= 3'((j + 1) % NSRC);
      end
      out_q <= out_q + 8'(link_fire) - 8'(rsp_counted);
    end
  end

  // response routing
  always_comb begin
    co_rs_valid = rsp_valid_i && (rsp_src == sf_sparse_pkg::SP_TAGSRC_DATA);
    co_rs_idx   = rsp_i.tag[4:0];
    ib_rs_valid = rsp_valid_i && (rsp_src == sf_sparse_pkg::SP_TAGSRC_IDX);
    ib_rs_slot  = rsp_i.tag[$clog2(IDX_NSLOT)-1:0];
    ib_rs_err   = (rsp_i.status != sf_albion_pkg::SF_ST_OKAY);
    wk_rs_valid[0] = rsp_valid_i && (rsp_src == sf_sparse_pkg::SP_TAGSRC_RP);
    wk_rs_valid[1] = rsp_valid_i && (rsp_src == sf_sparse_pkg::SP_TAGSRC_CI);
    wk_rs_valid[2] = rsp_valid_i && (rsp_src == sf_sparse_pkg::SP_TAGSRC_VAL);
    wk_rs_err   = (rsp_i.status != sf_albion_pkg::SF_ST_OKAY);
  end

  // ===========================================================================
  // output writer (gather): in-order beats -> lane rotation -> output buffer
  // ===========================================================================
  logic [127:0] obuf_q [OBUF_WORDS];
  logic [127:0] obuf_rd_q;
  logic [sf_sparse_pkg::SP_OFF_W-1:0] o_ptr_q;
  logic [7:0]          o_beat_q;
  logic [31:0]         o_elem_q;
  logic [31:0]         elems_done_q;
  logic [31:0]         y_cnt_q;

  wire        e_big_nb_last = (o_beat_q == ((e_small) ? 8'd0 : 8'(E[11:4] - 1'b1)));
  wire [4:0]  w_nbytes      = e_small ? E[4:0] : 5'd16;
  wire        wr_go         = dv_valid && (is_gather || is_csr_g || is_spmv);
  wire        wr_err        = wr_go && (dv_stat != 4'd0);
  // SpMV consumes the x stream; an error beat or an aborted command drains it without feeding the lane
  assign dv_ready           = is_spmv ? (sp_x_ready || wr_err || deliver_abort_q) : 1'b1;
  assign sp_x_valid         = dv_valid && is_spmv && !wr_err && !deliver_abort_q;
  // a front-end fault does not stop delivery of the elements before it; only a memory error does
  wire        wr_data       = wr_go && dv_ready && !wr_err && !deliver_abort_q;

  logic [127:0] rot;
  logic [15:0]  wmask;
  logic [3:0]   dl, sl, rsh;
  always_comb begin
    dl   = o_ptr_q[3:0];
    sl   = dv_lane;
    rsh  = dl - sl;
    rot  = 128'(({dv_data, dv_data} >> {((5'd16 - {1'b0, rsh}) & 5'h0F), 3'b000}));
    wmask = '0;
    for (int b = 0; b < 16; b++) wmask[b] = (5'(b) >= {1'b0, dl}) && (5'(b) < ({1'b0, dl} + w_nbytes));
  end

  // one write port: gather results, or the INT32 y[row] of the SpMV
  logic                 ow_en;
  logic [OBW-1:0]       ow_word;
  logic [127:0]         ow_data;
  logic [15:0]          ow_mask;
  wire  [sf_sparse_pkg::SP_OFF_W-1:0]  y_off = c_q.dst_off + {sp_y_row[sf_sparse_pkg::SP_OFF_W-3:0], 2'b00};
  always_comb begin
    if (is_spmv) begin
      ow_en   = sp_y_valid;
      ow_word = y_off[OBW+3:4];
      ow_data = {96'd0, sp_y_data} << {y_off[3:2], 5'b00000};
      ow_mask = 16'h000F << {y_off[3:2], 2'b00};
    end else begin
      ow_en   = wr_data;
      ow_word = o_ptr_q[OBW+3:4];
      ow_data = rot;
      ow_mask = wmask;
    end
  end

  always_ff @(posedge clk_i) begin
    if (ow_en) begin
      for (int b = 0; b < 16; b++)
        if (ow_mask[b]) obuf_q[ow_word][b*8 +: 8] <= ow_data[b*8 +: 8];
    end
    obuf_rd_q <= obuf_q[obuf_raddr_i];
  end
  assign obuf_rdata_o = obuf_rd_q;

  // ===========================================================================
  // fault arbitration: the lowest element index wins (docs/02 section 7)
  // ===========================================================================
  localparam int unsigned NCAND = 6;
  logic        nf_v;                       // winning fault candidate this cycle
  logic        nf_from_delivery;           // ... raised by the output writer (a response came back with an error)
  logic        nf_front;                   // ... raised at the very front (CSR walker): the elements ahead of it must finish
  logic [4:0]  nf_code;
  logic [3:0]  nf_g, nf_s;
  logic [31:0] nf_elem;
  logic [ADDR_W-1:0] nf_addr;
  logic [NCAND-1:0]                cd_v;
  logic [NCAND-1:0][4:0]           cd_code;
  logic [NCAND-1:0][3:0]           cd_g, cd_s;
  logic [NCAND-1:0][31:0]          cd_elem;
  logic [NCAND-1:0][ADDR_W-1:0]    cd_addr;
  always_comb begin
    cd_v = '0; cd_code = '0; cd_g = '0; cd_s = '0; cd_elem = '0; cd_addr = '0;
    // 0: array extent refused by the permission checker (before the run starts)
    cd_v[0]    = (state_q == S_CHECK) && item_v && (item_big || !chk_permit);
    cd_code[0] = sf_sparse_pkg::SP_F_PERM;
    cd_g[0]    = item_big ? sf_memory_guard_pkg::FT_BADLEN : chk_fault;
    cd_addr[0] = item_addr;
    // 1: element fault from the address generator / permission checker (stream order)
    cd_v[1]    = (state_q == S_RUN) && ea_fault_new && !ea_drop;
    cd_elem[1] = ea_idx;
    if (ea_fault != sf_sparse_pkg::SP_F_NONE) begin
      cd_code[1] = ea_fault;
      cd_s[1]    = (ea_fault == sf_sparse_pkg::SP_F_MEM_ERR) ? sf_albion_pkg::SF_ST_TARGET_ERR : 4'd0;
    end else begin
      cd_code[1] = sf_sparse_pkg::SP_F_PERM; cd_g[1] = chk_fault; cd_addr[1] = ea_addr;   // address reported for permission faults only
    end
    // 2: a read response came back with an error (seen at in-order delivery)
    cd_v[2]    = (state_q == S_RUN) && wr_err && !deliver_abort_q;
    cd_code[2] = sf_sparse_pkg::SP_F_MEM_ERR; cd_s[2] = dv_stat; cd_elem[2] = o_elem_q;
    // 3: a write response came back with an error
    cd_v[3]    = (state_q == S_RUN) && werr_valid;
    cd_code[3] = sf_sparse_pkg::SP_F_MEM_ERR; cd_s[3] = werr_stat; cd_elem[3] = werr_elem; cd_addr[3] = {werr_beat, 4'b0000};
    // 4: link protocol violation (response without a matching request)
    cd_v[4]    = (state_q == S_RUN) && co_proto;
    cd_code[4] = sf_sparse_pkg::SP_F_PROTO; cd_elem[4] = o_elem_q;
    // 5: the CSR walker rejected the matrix (row pointer / column index) or an array read failed
    cd_v[5]    = (state_q == S_RUN) && wk_flt_valid;
    cd_code[5] = wk_flt_code; cd_s[5] = wk_flt_stat; cd_elem[5] = wk_flt_elem;
  end
  always_comb begin
    nf_v = 1'b0; nf_code = sf_sparse_pkg::SP_F_NONE; nf_g = '0; nf_s = '0; nf_elem = '0; nf_addr = '0; nf_from_delivery = 1'b0; nf_front = 1'b0;
    for (int k = 0; k < NCAND; k++) begin
      if (cd_v[k] && (!nf_v || (cd_elem[k] < nf_elem))) begin
        nf_v = 1'b1; nf_code = cd_code[k]; nf_g = cd_g[k]; nf_s = cd_s[k]; nf_elem = cd_elem[k]; nf_addr = cd_addr[k];
        nf_from_delivery = (k == 2);
        nf_front         = (k == 5);
      end
    end
  end
  wire nf_take = nf_v && (!flt_v_q || (nf_elem < flt_elem_q));

  // A fault raised at the back end (element checker, delivery, write response) makes everything UPSTREAM of it
  // later than the fault, so it is discarded.  A fault raised by the CSR walker is at the very front: everything
  // downstream is earlier and completes; the walker just stops (and the index buffer closes after draining).
  logic flush_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)                          flush_q <= 1'b0;
    else if (state_q == S_DECODE)         flush_q <= 1'b0;
    else if (nf_take && !nf_front)        flush_q <= 1'b1;
  end
  assign ag_flush = flush_q || (nf_take && !nf_front);
  assign ib_flush = flush_q || (nf_take && !nf_front);
  assign wk_flush = flush_q || (nf_take && !nf_front);

  // ===========================================================================
  // main FSM
  // ===========================================================================
  // SpMV events that can never be paired (their x element was never produced because of a fault) are orphans
  wire evf_ok   = evf_empty || (flt_v_q && evf_head_nz);
  wire run_idle = !ib_busy && !ag_busy && !sp_busy && !sg_valid_q && !wk_busy && !spm_busy && evf_ok &&
                  co_empty && rob_empty && (out_q == 8'd0) && (rq_v == '0);

  wire chk_adv = (state_q == S_CHECK) && (!item_v || (!item_big && chk_permit));
  assign go    = chk_adv && chk_last;
  assign wk_start = go && is_csr;
  assign sp_start = go && is_spmv;
  assign ib_start = go && (ib_count != 32'd0);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q         <= S_IDLE;
      chk_step_q      <= '0;
      cyc_q           <= '0;
      flt_v_q         <= 1'b0;
      deliver_abort_q <= 1'b0;
      o_beat_q        <= '0;
      o_elem_q        <= '0;
      elems_done_q    <= '0;
      sc_elems_q      <= '0;
      y_cnt_q         <= '0;
    end else begin
      if (state_q != S_IDLE) cyc_q <= cyc_q + 32'd1;

      if (sg_accept) s_ptr_q <= s_ptr_q + sf_sparse_pkg::SP_OFF_W'(e_small ? E : 12'd16);
      if (sp_y_valid && is_spmv) y_cnt_q <= y_cnt_q + 32'd1;
      if (sg_fire && sg_last_q) sc_elems_q <= sc_elems_q + 32'd1;

      if (nf_take) begin
        flt_v_q    <= 1'b1;
        flt_code_q <= nf_code;
        flt_g_q    <= nf_g;
        flt_s_q    <= nf_s;
        flt_elem_q <= nf_elem;
        flt_addr_q <= nf_addr;
        if (nf_from_delivery) deliver_abort_q <= 1'b1;     // only an error seen at DELIVERY stops the output writer
      end

      case (state_q)
        S_IDLE: begin
          if (cmd_valid_i) begin
            state_q         <= S_DECODE;
            cyc_q           <= 32'd1;
            flt_v_q         <= 1'b0;
            deliver_abort_q <= 1'b0;
            chk_step_q      <= '0;
            o_beat_q        <= '0;
            o_elem_q        <= '0;
            elems_done_q    <= '0;
            sc_elems_q      <= '0;
            y_cnt_q         <= '0;
          end
        end
        S_DECODE: begin
          o_ptr_q <= c_q.dst_off;
          s_ptr_q <= c_q.src_off;
          if (dec_fault != sf_sparse_pkg::SP_F_NONE) begin
            flt_v_q    <= 1'b1;
            flt_code_q <= dec_fault;
            flt_g_q    <= '0;
            flt_s_q    <= '0;
            flt_elem_q <= '0;
            flt_addr_q <= '0;
            state_q    <= S_DONE;
          end else if (is_gs && c_q.n == 32'd0) begin
            state_q    <= S_DONE;
          end else begin
            state_q    <= S_CHECK;
          end
        end
        S_CHECK: begin
          if (nf_take) begin
            state_q <= S_DONE;
          end else if (chk_adv) begin
            if (chk_last) state_q <= S_RUN;
            else          chk_step_q <= chk_step_q + 3'd1;
          end
        end
        S_RUN: begin
          // output writer bookkeeping
          if (wr_go) begin
            if (wr_data) begin
              o_ptr_q <= o_ptr_q + sf_sparse_pkg::SP_OFF_W'(e_small ? E : 12'd16);
              if (e_big_nb_last) begin
                o_beat_q     <= '0;
                o_elem_q     <= o_elem_q + 32'd1;
                elems_done_q <= elems_done_q + 32'd1;
              end else begin
                o_beat_q <= o_beat_q + 8'd1;
              end
            end
          end
          if (run_idle && !ea_valid && !idx_valid && !go) state_q <= S_DONE;
        end
        S_DONE: begin
          if (done_ready_i) state_q <= S_IDLE;
        end
        default: state_q <= S_IDLE;
      endcase
    end
  end

  // command capture
  always_ff @(posedge clk_i) begin
    if (state_q == S_IDLE && cmd_valid_i) c_q <= cmd_i;
  end

  assign cmd_ready_o  = (state_q == S_IDLE);
  assign done_valid_o = (state_q == S_DONE);
  always_comb begin
    done_o            = '0;
    done_o.tid        = c_q.tid;
    done_o.fault      = flt_v_q ? flt_code_q : sf_sparse_pkg::SP_F_NONE;
    done_o.gfault     = flt_v_q ? flt_g_q : 4'd0;
    done_o.alp_status = flt_v_q ? flt_s_q : 4'd0;
    done_o.fault_elem = flt_v_q ? flt_elem_q : 32'd0;
    done_o.fault_addr = flt_v_q ? {{(sf_sparse_pkg::SP_ADDR_W-ADDR_W){1'b0}}, flt_addr_q} : '0;
    done_o.elems_done = is_spmv ? y_cnt_q :
                        is_scatter ? ((flt_v_q && flt_code_q == sf_sparse_pkg::SP_F_MEM_ERR) ? flt_elem_q : sc_elems_q) : elems_done_q;
    done_o.ovf        = is_spmv && sp_ovf;
    done_o.cycles     = cyc_q;
  end
  assign busy_o = (state_q != S_IDLE);

  // ===========================================================================
  // performance counters
  // ===========================================================================
  logic [sf_sparse_pkg::SP_PC_N-1:0][CNT_W-1:0] pc_q;
  wire  rd_fire_data = link_fire && gnt[0] && rq_rd[0];
  wire  wr_fire_data = link_fire && gnt[0] && !rq_rd[0];
  wire  meta_fire    = link_fire && (gnt[1] | gnt[2] | gnt[3] | gnt[4]);
  wire  stall_link   = (|rq_v) && !link_fire;
  wire  cmd_done_ev  = (state_q == S_DONE) && done_ready_i;
  logic [4:0] pop_be;
  always_comb begin
    pop_be = '0;
    for (int b = 0; b < 16; b++) pop_be = pop_be + 5'(co_rq_be[b]);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      pc_q <= '0;
    end else if (perf_clear_i) begin
      pc_q <= '0;
    end else begin
      if (state_q != S_IDLE) pc_q[sf_sparse_pkg::SP_PC_CYCLES_BUSY] <= pc_q[sf_sparse_pkg::SP_PC_CYCLES_BUSY] + CNT_W'(1);
      if (cmd_done_ev) begin
        pc_q[sf_sparse_pkg::SP_PC_CMDS]       <= pc_q[sf_sparse_pkg::SP_PC_CMDS] + CNT_W'(1);
        pc_q[sf_sparse_pkg::SP_PC_CMD_LAT_SUM] <= pc_q[sf_sparse_pkg::SP_PC_CMD_LAT_SUM] + CNT_W'(cyc_q);
        if (CNT_W'(cyc_q) > pc_q[sf_sparse_pkg::SP_PC_CMD_LAT_MAX]) pc_q[sf_sparse_pkg::SP_PC_CMD_LAT_MAX] <= CNT_W'(cyc_q);
        if (flt_v_q) pc_q[sf_sparse_pkg::SP_PC_CMDS_FAULT] <= pc_q[sf_sparse_pkg::SP_PC_CMDS_FAULT] + CNT_W'(1);
      end
      if (wr_data && (e_big_nb_last)) pc_q[sf_sparse_pkg::SP_PC_ELEMS] <= pc_q[sf_sparse_pkg::SP_PC_ELEMS] + CNT_W'(1);
      if (wr_data) pc_q[sf_sparse_pkg::SP_PC_BYTES_USEFUL] <= pc_q[sf_sparse_pkg::SP_PC_BYTES_USEFUL] + CNT_W'(w_nbytes);
      if (sg_fire && sg_last_q) begin
        pc_q[sf_sparse_pkg::SP_PC_ELEMS]        <= pc_q[sf_sparse_pkg::SP_PC_ELEMS] + CNT_W'(1);
        pc_q[sf_sparse_pkg::SP_PC_BYTES_USEFUL] <= pc_q[sf_sparse_pkg::SP_PC_BYTES_USEFUL] + CNT_W'(E);
      end
      if (rd_fire_data) begin
        pc_q[sf_sparse_pkg::SP_PC_DATA_RD_REQ] <= pc_q[sf_sparse_pkg::SP_PC_DATA_RD_REQ] + CNT_W'(1);
        pc_q[sf_sparse_pkg::SP_PC_BYTES_REQ]   <= pc_q[sf_sparse_pkg::SP_PC_BYTES_REQ] + CNT_W'(pop_be);
      end
      if (wr_fire_data) begin
        pc_q[sf_sparse_pkg::SP_PC_DATA_WR_REQ] <= pc_q[sf_sparse_pkg::SP_PC_DATA_WR_REQ] + CNT_W'(1);
        pc_q[sf_sparse_pkg::SP_PC_BYTES_REQ]   <= pc_q[sf_sparse_pkg::SP_PC_BYTES_REQ] + CNT_W'(pop_be);
      end
      if (meta_fire)    pc_q[sf_sparse_pkg::SP_PC_META_REQ]  <= pc_q[sf_sparse_pkg::SP_PC_META_REQ] + CNT_W'(1);
      if (ev_merge)     pc_q[sf_sparse_pkg::SP_PC_MERGES]    <= pc_q[sf_sparse_pkg::SP_PC_MERGES] + CNT_W'(1);
      if (ev_dup)       pc_q[sf_sparse_pkg::SP_PC_DUP_HITS]  <= pc_q[sf_sparse_pkg::SP_PC_DUP_HITS] + CNT_W'(1);
      if (ev_cont)      pc_q[sf_sparse_pkg::SP_PC_BURST_CONT] <= pc_q[sf_sparse_pkg::SP_PC_BURST_CONT] + CNT_W'(1);
      if (stall_link)   pc_q[sf_sparse_pkg::SP_PC_STALL_LINK] <= pc_q[sf_sparse_pkg::SP_PC_STALL_LINK] + CNT_W'(1);
      if (ev_stall_rt)  pc_q[sf_sparse_pkg::SP_PC_STALL_RT]  <= pc_q[sf_sparse_pkg::SP_PC_STALL_RT] + CNT_W'(1);
      if (ev_stall_rob) pc_q[sf_sparse_pkg::SP_PC_STALL_ROB] <= pc_q[sf_sparse_pkg::SP_PC_STALL_ROB] + CNT_W'(1);
      if (state_q == S_RUN) pc_q[sf_sparse_pkg::SP_PC_ROB_OCC_SUM] <= pc_q[sf_sparse_pkg::SP_PC_ROB_OCC_SUM] + CNT_W'(rob_occ);
      if (CNT_W'(rob_occ) > pc_q[sf_sparse_pkg::SP_PC_ROB_OCC_MAX]) pc_q[sf_sparse_pkg::SP_PC_ROB_OCC_MAX] <= CNT_W'(rob_occ);
      if (CNT_W'(co_occ) > pc_q[sf_sparse_pkg::SP_PC_RT_OCC_MAX])   pc_q[sf_sparse_pkg::SP_PC_RT_OCC_MAX]  <= CNT_W'(co_occ);
      if (CNT_W'(out_q) > pc_q[sf_sparse_pkg::SP_PC_OUT_MAX])       pc_q[sf_sparse_pkg::SP_PC_OUT_MAX]     <= CNT_W'(out_q);
      if (ev_bank)      pc_q[sf_sparse_pkg::SP_PC_BANK_CONF] <= pc_q[sf_sparse_pkg::SP_PC_BANK_CONF] + CNT_W'(1);
      if (ev_lat_v) begin
        pc_q[sf_sparse_pkg::SP_PC_RD_LAT_SUM] <= pc_q[sf_sparse_pkg::SP_PC_RD_LAT_SUM] + CNT_W'(ev_lat);
        pc_q[sf_sparse_pkg::SP_PC_RD_LAT_CNT] <= pc_q[sf_sparse_pkg::SP_PC_RD_LAT_CNT] + CNT_W'(1);
        if (CNT_W'(ev_lat) > pc_q[sf_sparse_pkg::SP_PC_RD_LAT_MAX]) pc_q[sf_sparse_pkg::SP_PC_RD_LAT_MAX] <= CNT_W'(ev_lat);
      end
      if (co_proto || rsp_unknown) pc_q[sf_sparse_pkg::SP_PC_PROTO_ERR] <= pc_q[sf_sparse_pkg::SP_PC_PROTO_ERR] + CNT_W'(1);
    end
  end
  always_comb begin
    for (int i = 0; i < sf_sparse_pkg::SP_PC_N; i++) perf_o[i*CNT_W +: CNT_W] = pc_q[i];
  end


endmodule

`default_nettype wire
