#!/usr/bin/env python3
"""
SilicaFlux P112 SparseEngine -- independent software reference model.

Written from docs/02_functional_spec.md and the MemoryGuard contract
(third_party/memory_guard/sf_memory_guard_checker.sv header), NOT from the RTL.
Pure Python integers; no numpy; no shared code with the testbench.

What it models (architecturally visible behaviour only -- never timing):
  * command decode faults and their precedence
  * the MemoryGuard permission verdict for every access the engine makes
  * per-element faults in stream order, "lowest element index wins" when a
    memory-side error and a front-end fault compete
  * gather results (output buffer bytes), scatter results (memory image), CSR
    traversal and SpMV results
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

# ----------------------------------------------------------------------------- constants (docs/02)
OP_NOP, OP_GATHER, OP_SCATTER, OP_CSR_GATHER, OP_CSR_SPMV = 0, 1, 2, 3, 4

F_NONE, F_BAD_OP, F_BAD_ELEM, F_BAD_IDXW, F_ALIGN, F_BUF_RANGE = 0, 1, 2, 3, 4, 5
F_NEG_INDEX, F_IDX_RANGE, F_ADDR_OVF, F_PERM, F_MEM_ERR = 6, 7, 8, 9, 10
F_CSR_DIM, F_CSR_FMT, F_CSR_ROWPTR, F_CSR_COL, F_BAD_CMD, F_PROTO, F_UNSUP = 11, 12, 13, 14, 15, 16, 17

# MemoryGuard fault codes (sf_memory_guard_pkg)
FT_NONE, FT_NOMAP, FT_PERM, FT_SPAN, FT_OVERFLOW, FT_ZEROLEN, FT_BADOP, FT_BADDOM, FT_SPOOF, FT_DEVICE, FT_BADLEN = range(11)

ST_TARGET_ERR = 7     # ALP SF_ST_TARGET_ERR
VF_BYTES = {0: 1, 1: 2, 2: 4, 3: 4}


@dataclass
class Cfg:
    """Build-time configuration of the engine under test (must match the RTL parameters)."""
    ADDR_W: int = 40
    MAX_ELEM_BYTES: int = 256
    OBUF_BYTES: int = 8192
    IBUF_BYTES: int = 8192
    CHK_LW: int = 30
    ND: int = 4
    ROB_DEPTH: int = 32
    CSR_EN: bool = True
    SPMV_EN: bool = True
    SPMV_ACC_W: int = 32
    SPMV_SATURATE: bool = True
    ERR_LINE_BEATS: int = 1         # error granularity of the target: 1 = per 16-byte beat; 4 = a failing beat fails its whole
                                    # 64-byte line (a cache refills whole lines and fails the first request of the line)


@dataclass
class Cmd:
    op: int = OP_GATHER
    tid: int = 0
    dom: int = 0
    cacheable: int = 1
    idx_stream: int = 0
    idx_signed: int = 0
    idx_w: int = 2
    base: int = 0
    idx_base: int = 0
    n: int = 0
    elem_bytes: int = 4
    idx_limit: int = 0
    dst_off: int = 0
    src_off: int = 0
    rp_base: int = 0
    ci_base: int = 0
    val_base: int = 0
    nrows: int = 0
    ncols: int = 0
    nnz: int = 0
    ci_w: int = 2
    vfmt: int = 0


@dataclass
class Result:
    fault: int = F_NONE
    gfault: int = 0
    alp_status: int = 0
    fault_elem: int = 0
    fault_addr: int = 0
    elems_done: int = 0
    ovf: int = 0
    obuf: Dict[int, int] = field(default_factory=dict)       # byte offset -> value written
    mem: Dict[int, bytearray] = field(default_factory=dict)  # beat -> final 16 bytes (only beats that exist)


# ----------------------------------------------------------------------------- memory image helpers
class Mem:
    """Sparse byte-addressed memory made of 16-byte beats (missing beat = zeros)."""

    def __init__(self, beats: Optional[Dict[int, int]] = None):
        self.b: Dict[int, bytearray] = {}
        for k, v in (beats or {}).items():
            self.b[k] = bytearray(v.to_bytes(16, "little"))

    def rd(self, addr: int, n: int) -> bytes:
        out = bytearray()
        for i in range(n):
            a = addr + i
            beat = self.b.get(a >> 4)
            out.append(beat[a & 15] if beat is not None else 0)
        return bytes(out)

    def wr(self, addr: int, data: bytes) -> None:
        for i, v in enumerate(data):
            a = addr + i
            beat = self.b.setdefault(a >> 4, bytearray(16))
            beat[a & 15] = v

    def beats_int(self) -> Dict[int, int]:
        return {k: int.from_bytes(bytes(v), "little") for k, v in self.b.items()}


# ----------------------------------------------------------------------------- MemoryGuard model
class Guard:
    """Region-table verdict, per the checker's documented contract (whole transfer in ONE region)."""

    def __init__(self, cfg: Cfg, regions, allow_mask: int):
        # regions: list of (dom, idx, base, size, r, w)
        self.cfg = cfg
        self.allow = allow_mask
        self.reg: Dict[int, List[Tuple[int, int, int, int]]] = {d: [] for d in range(cfg.ND)}
        for (d, _i, base, size, r, w) in regions:
            self.reg[d].append((base, base + size, r, w))

    def check(self, dom: int, op_write: bool, addr: int, length: int) -> int:
        cfg = self.cfg
        maxlen = (1 << cfg.CHK_LW) - 1
        if length == 0:
            return FT_ZEROLEN
        if length > maxlen:
            return FT_BADLEN
        end = addr + length
        if end > (1 << cfg.ADDR_W):
            return FT_OVERFLOW
        if dom >= cfg.ND:
            return FT_BADDOM
        if not (self.allow >> dom) & 1:
            return FT_SPOOF
        any_cont = any_ovl = False
        for (b, e, r, w) in self.reg[dom]:
            if b <= addr and end <= e:
                any_cont = True
                if (w if op_write else r):
                    return FT_NONE
            if addr < e and b < end:
                any_ovl = True
        if any_cont:
            return FT_PERM
        if any_ovl:
            return FT_SPAN
        return FT_NOMAP


# ----------------------------------------------------------------------------- decode
def e_valid(cfg: Cfg, e: int) -> bool:
    if e == 0 or e > cfg.MAX_ELEM_BYTES:
        return False
    if e < 16:
        return (e & (e - 1)) == 0
    return e % 16 == 0


def elem_align(e: int) -> int:
    return e if e < 16 else 16


def decode_fault(cfg: Cfg, c: Cmd, ops_supported) -> int:
    if c.op not in ops_supported:
        return F_BAD_OP
    if c.op in (OP_GATHER, OP_SCATTER):
        e = c.elem_bytes
        if not e_valid(cfg, e) or (e >= 16 and e // 16 > cfg.ROB_DEPTH):
            return F_BAD_ELEM
        if c.idx_w == 3:
            return F_BAD_IDXW
        al = elem_align(e)
        if c.base % al:
            return F_ALIGN
        if not c.idx_stream and c.idx_base % (1 << c.idx_w):
            return F_ALIGN
        buf_off = c.dst_off if c.op == OP_GATHER else c.src_off
        if buf_off % al:
            return F_ALIGN
        limit = cfg.OBUF_BYTES if c.op == OP_GATHER else cfg.IBUF_BYTES
        if buf_off + c.n * e > limit:
            return F_BUF_RANGE
        if c.base >> cfg.ADDR_W:
            return F_ADDR_OVF
        if (not c.idx_stream) and (c.idx_base >> cfg.ADDR_W):
            return F_ADDR_OVF
    return F_NONE


# ----------------------------------------------------------------------------- shared element machinery
def raw_index_from_mem(mem: Mem, c: Cmd, i: int) -> int:
    nb = 1 << c.idx_w
    return int.from_bytes(mem.rd(c.idx_base + i * nb, nb), "little")


def element_prefault(cfg: Cfg, c: Cmd, raw: int, guard: Guard, write: bool) -> Tuple[int, int, int, int]:
    """Front-end verdict for one element: (fault, gfault, addr_for_perm, idx)."""
    bits = 8 << c.idx_w
    neg = bool(c.idx_signed and (raw >> (bits - 1)) & 1)
    idx = raw & ((1 << bits) - 1)
    if neg:
        return F_NEG_INDEX, 0, 0, idx
    if c.idx_limit and idx >= c.idx_limit:
        return F_IDX_RANGE, 0, 0, idx
    addr = c.base + idx * c.elem_bytes
    if addr >= (1 << cfg.ADDR_W):
        return F_ADDR_OVF, 0, 0, idx
    g = guard.check(c.dom, write, addr, c.elem_bytes)
    if g != FT_NONE:
        return F_PERM, g, addr, idx
    return F_NONE, 0, addr, idx


def beats_of(addr: int, nbytes: int) -> List[int]:
    return list(range(addr >> 4, ((addr + nbytes - 1) >> 4) + 1))


def array_extent_check(cfg: Cfg, guard: Guard, c: Cmd, base: int, length: int):
    """Up-front permission check of a whole array extent. Returns (fault, gfault, addr) or None."""
    if length == 0:
        return None
    if length >= (1 << cfg.CHK_LW):
        return F_PERM, FT_BADLEN, base
    g = guard.check(c.dom, False, base, length)
    if g != FT_NONE:
        return F_PERM, g, base
    return None


# ----------------------------------------------------------------------------- GATHER
def model_gather(cfg: Cfg, c: Cmd, mem: Mem, guard: Guard, ipush: List[int],
                 err_beats: Dict[int, int]) -> Result:
    r = Result()
    f = decode_fault(cfg, c, (OP_GATHER,))
    if f:
        r.fault = f
        return r
    if c.n == 0:
        return r
    # index array extent
    if not c.idx_stream:
        chk = array_extent_check(cfg, guard, c, c.idx_base, c.n << c.idx_w)
        if chk:
            r.fault, r.gfault, r.fault_addr = chk
            return r
    # walk the elements in order; find the first front-end fault f_i
    pre = None
    plan = []   # per element: (addr)
    for i in range(c.n):
        # index fetch error?  (the beat of the index array holding index i came back with an error)
        if not c.idx_stream:
            ia = c.idx_base + i * (1 << c.idx_w)
            if (ia >> 4) in err_beats:
                pre = (i, F_MEM_ERR, 0, ST_TARGET_ERR, 0)
                break
            raw = raw_index_from_mem(mem, c, i)
        else:
            raw = ipush[i]
        fl, gf, addr, _idx = element_prefault(cfg, c, raw, guard, write=False)
        if fl:
            pre = (i, fl, gf, 0, addr if fl == F_PERM else 0)
            break
        plan.append(addr)
    n_ok = len(plan)
    # data-side memory errors: the lowest element whose bytes touch an erroring beat
    data_err = None
    for i, addr in enumerate(plan):
        for b in beats_of(addr, c.elem_bytes):
            if b in err_beats:
                data_err = (i, err_beats[b])
                break
        if data_err:
            break
    if data_err is not None:
        r.fault, r.alp_status, r.fault_elem = F_MEM_ERR, data_err[1], data_err[0]
        r.elems_done = data_err[0]
        deliver = data_err[0]
    elif pre is not None:
        i, fl, gf, st, addr = pre
        r.fault, r.gfault, r.alp_status, r.fault_elem, r.fault_addr = fl, gf, st, i, addr
        r.elems_done = n_ok
        deliver = n_ok
    else:
        r.elems_done = c.n
        deliver = c.n
    for i in range(deliver):
        data = mem.rd(plan[i], c.elem_bytes)
        for k, v in enumerate(data):
            r.obuf[c.dst_off + i * c.elem_bytes + k] = v
    return r


def ibuf_bytes(ibuf: Dict[int, int], off: int, n: int) -> bytes:
    out = bytearray()
    for i in range(n):
        a = off + i
        w = ibuf.get(a >> 4, 0)
        out.append((w >> (8 * (a & 15))) & 0xFF)
    return bytes(out)


def model_scatter(cfg: Cfg, c: Cmd, mem: Mem, guard: Guard, ipush: List[int], ibuf: Dict[int, int],
                  err_beats: Dict[int, int]) -> Result:
    """
    memory[base + idx[i]*E .. +E) = ibuf[src_off + i*E .. +E)       applied in element order i = 0..n-1.

    DUPLICATE DESTINATIONS (documented, deterministic): two elements whose destination bytes overlap are
    committed in element order, so for every overlapping byte the element with the HIGHEST index wins.
    A fault at element f commits exactly the elements 0 .. f-1 (all of them, before the command completes).
    A write error returned by the target: the failed beat is not written; elements after the failing one
    may or may not have been committed (not recalled) -- the model then reports only the record, and the
    scenario must not compare memory (scenario flag NOMEM).
    """
    r = Result()
    f = decode_fault(cfg, c, (OP_SCATTER,))
    if f:
        r.fault = f
        return r
    if c.n == 0:
        return r
    if not c.idx_stream:
        chk = array_extent_check(cfg, guard, c, c.idx_base, c.n << c.idx_w)
        if chk:
            r.fault, r.gfault, r.fault_addr = chk
            return r
    pre = None
    plan = []
    for i in range(c.n):
        if not c.idx_stream:
            ia = c.idx_base + i * (1 << c.idx_w)
            if (ia >> 4) in err_beats:
                pre = (i, F_MEM_ERR, 0, ST_TARGET_ERR, 0)
                break
            raw = raw_index_from_mem(mem, c, i)
        else:
            raw = ipush[i]
        fl, gf, addr, _idx = element_prefault(cfg, c, raw, guard, write=True)
        if fl:
            pre = (i, fl, gf, 0, addr if fl == F_PERM else 0)
            break
        plan.append(addr)
    # write errors: the lowest element touching an erroring beat (its first element is what the target reports)
    werr = None
    for i, addr in enumerate(plan):
        for b in beats_of(addr, c.elem_bytes):
            if b in err_beats:
                werr = (i, err_beats[b], b << 4)
                break
        if werr:
            break
    if werr is not None:
        r.fault, r.alp_status, r.fault_elem, r.fault_addr = F_MEM_ERR, werr[1], werr[0], werr[2]
        r.elems_done = werr[0]
    elif pre is not None:
        i, fl, gf, st, addr = pre
        r.fault, r.gfault, r.alp_status, r.fault_elem, r.fault_addr = fl, gf, st, i, addr
        r.elems_done = len(plan)
    else:
        r.elems_done = c.n
    # memory effects, in element order; beats that the target fails are not written
    out = Mem(mem.beats_int())
    for i, addr in enumerate(plan):
        data = ibuf_bytes(ibuf, c.src_off + i * c.elem_bytes, c.elem_bytes)
        for k, v in enumerate(data):
            a = addr + k
            if (a >> 4) in err_beats:
                continue
            out.wr(a, bytes([v]))
    r.mem = out.b
    return r


# ----------------------------------------------------------------------------- CSR traversal and SpMV
def csr_decode_fault(cfg: Cfg, c: Cmd) -> int:
    spmv = c.op == OP_CSR_SPMV
    if not cfg.CSR_EN or (spmv and not cfg.SPMV_EN):
        return F_BAD_OP
    e = c.elem_bytes
    if not e_valid(cfg, e):
        return F_BAD_ELEM
    if c.ci_w == 3 or c.vfmt > 3:
        return F_CSR_FMT
    if (c.nrows == 0 or c.ncols == 0) and c.nnz != 0:
        return F_CSR_DIM
    if spmv and (c.vfmt != 0 or e != 1):
        return F_UNSUP
    if c.base % elem_align(e):
        return F_ALIGN
    if c.rp_base % 4:
        return F_ALIGN
    if c.ci_base % (1 << c.ci_w):
        return F_ALIGN
    if c.dst_off % (4 if spmv else elem_align(e)):
        return F_ALIGN
    span = c.nrows * 4 if spmv else c.nnz * e
    if c.dst_off + span > cfg.OBUF_BYTES:
        return F_BUF_RANGE
    bases = [c.base, c.rp_base, c.ci_base] + ([c.val_base] if spmv else [])
    if any(b >> cfg.ADDR_W for b in bases):
        return F_ADDR_OVF
    return F_NONE


def sat_acc(cfg: Cfg, acc: int, prod: int):
    """tensor_pe step: exact add, then clamp (or wrap) on overflow; returns (acc, overflowed)."""
    w = cfg.SPMV_ACC_W
    lo, hi = -(1 << (w - 1)), (1 << (w - 1)) - 1
    s = acc + prod
    if lo <= s <= hi:
        return s, False
    if cfg.SPMV_SATURATE:
        return (hi if s > hi else lo), True
    s &= (1 << w) - 1
    if s >> (w - 1):
        s -= 1 << w
    return s, True


def model_csr(cfg: Cfg, c: Cmd, mem: Mem, guard: Guard, err_beats: Dict[int, int]) -> Result:
    r = Result()
    f = csr_decode_fault(cfg, c)
    if f:
        r.fault = f
        return r
    spmv = c.op == OP_CSR_SPMV
    E = c.elem_bytes
    # ---- array extents, in the order the engine checks them
    exts = [(c.rp_base, (c.nrows + 1) * 4)]
    if c.nnz:
        exts.append((c.ci_base, c.nnz << c.ci_w))
        if spmv:
            exts.append((c.val_base, c.nnz))
        exts.append((c.base, c.ncols * E))
    for (b, ln) in exts:
        chk = array_extent_check(cfg, guard, c, b, ln)
        if chk:
            r.fault, r.gfault, r.fault_addr = chk
            return r

    def rd_u(addr: int, nb: int) -> int:
        return int.from_bytes(mem.rd(addr, nb), "little")

    def err_at(addr: int) -> bool:
        return (addr >> 4) in err_beats

    rp_at = lambda i: rd_u(c.rp_base + 4 * i, 4)
    nrows, nnz = c.nrows, c.nnz
    fault = None            # (code, nonzero position, rows_complete, status)
    emitted: List[tuple] = []   # (k, row, col, val)
    # ---- the walk
    if err_at(c.rp_base):
        fault = (F_MEM_ERR, 0, 0, ST_TARGET_ERR)
    elif rp_at(0) != 0:
        fault = (F_CSR_ROWPTR, 0, 0, 0)
    else:
        p0 = 0
        for row in range(nrows):
            ia = c.rp_base + 4 * (row + 1)
            if err_at(ia):
                fault = (F_MEM_ERR, p0, row, ST_TARGET_ERR)
                break
            p1 = rp_at(row + 1)
            if p1 < p0 or p1 > nnz or (row == nrows - 1 and p1 != nnz):
                fault = (F_CSR_ROWPTR, p0, row, 0)
                break
            for k in range(p0, p1):
                ca = c.ci_base + k * (1 << c.ci_w)
                va = c.val_base + k
                if err_at(ca) or (spmv and err_at(va)):
                    fault = (F_MEM_ERR, k, row, ST_TARGET_ERR)
                    break
                col = rd_u(ca, 1 << c.ci_w)
                if col >= c.ncols:
                    fault = (F_CSR_COL, k, row, 0)
                    break
                emitted.append((k, row, col, rd_u(va, 1) if spmv else 0))
            if fault:
                break
            p0 = p1
    # ---- gather side: front-end then data faults on the emitted nonzeros (lowest nonzero wins)
    delivered = len(emitted)
    rows_done = None
    fe = None
    for i, (k, row, col, val) in enumerate(emitted):
        fl, gf, addr, _ = element_prefault(cfg, Cmd(op=OP_GATHER, base=c.base, elem_bytes=E, idx_w=2, idx_signed=0,
                                                    idx_limit=c.ncols, dom=c.dom), col, guard, write=False)
        if fl:
            fe = (i, fl, gf, addr if fl == F_PERM else 0, row)
            break
    n_pre = fe[0] if fe else len(emitted)
    data_err = None
    for i in range(n_pre):
        k, row, col, val = emitted[i]
        for b in beats_of(c.base + col * E, E):
            if b in err_beats:
                data_err = (i, err_beats[b], row)
                break
        if data_err:
            break
    if data_err is not None:
        r.fault, r.alp_status, r.fault_elem = F_MEM_ERR, data_err[1], data_err[0]
        delivered, rows_done = data_err[0], data_err[2]
    elif fe is not None:
        r.fault, r.gfault, r.fault_elem, r.fault_addr = fe[1], fe[2], fe[0], fe[3]
        delivered, rows_done = fe[0], fe[4]
    elif fault is not None:
        r.fault, r.fault_elem, r.alp_status = fault[0], fault[1], fault[3]
        delivered, rows_done = len(emitted), fault[2]
    else:
        rows_done = nrows
    done = emitted[:delivered]
    if not spmv:
        r.elems_done = delivered
        for i, (k, row, col, val) in enumerate(done):
            data = mem.rd(c.base + col * E, E)
            for j, v in enumerate(data):
                r.obuf[c.dst_off + i * E + j] = v
        return r
    # ---- SpMV: rows whose events all precede the fault are complete and written
    ptr = [rp_at(i) for i in range(nrows + 1)] if nrows < 10 ** 6 else []
    acc_by_row: Dict[int, tuple] = {}
    for (k, row, col, val) in done:
        acc, ov = acc_by_row.get(row, (0, False))
        xv = rd_u(c.base + col, 1)
        sx = xv - 256 if xv >= 128 else xv
        sv = val - 256 if val >= 128 else val
        acc, o2 = sat_acc(cfg, acc, sv * sx)
        acc_by_row[row] = (acc, ov or o2)
    ovf = 0
    for row in range(rows_done):
        acc, ov = acc_by_row.get(row, (0, False))
        ovf |= int(ov)
        y = acc & 0xFFFFFFFF
        for j, v in enumerate(y.to_bytes(4, "little")):
            r.obuf[c.dst_off + 4 * row + j] = v
    r.elems_done = rows_done
    r.ovf = ovf
    return r


SUPPORTED_OPS = (OP_GATHER, OP_SCATTER, OP_CSR_GATHER, OP_CSR_SPMV)


def expand_errors(cfg: Cfg, err_beats: Dict[int, int]) -> Dict[int, int]:
    if cfg.ERR_LINE_BEATS <= 1:
        return dict(err_beats)
    L = cfg.ERR_LINE_BEATS
    out: Dict[int, int] = {}
    for b in sorted(err_beats):                       # the status of the lowest failing beat of a line is reported
        for bb in range((b // L) * L, (b // L) * L + L):
            out.setdefault(bb, err_beats[b])
    return out


def model(cfg: Cfg, c: Cmd, mem: Mem, regions, allow_mask: int, ipush=None, ibuf=None, err_beats=None) -> Result:
    guard = Guard(cfg, regions, allow_mask)
    ipush = ipush or []
    err_beats = expand_errors(cfg, err_beats or {})
    if c.op == OP_GATHER:
        return model_gather(cfg, c, mem, guard, ipush, err_beats)
    if c.op == OP_SCATTER:
        return model_scatter(cfg, c, mem, guard, ipush, ibuf or {}, err_beats)
    if c.op in (OP_CSR_GATHER, OP_CSR_SPMV):
        return model_csr(cfg, c, mem, guard, err_beats)
    r = Result()
    r.fault = F_BAD_OP
    return r
