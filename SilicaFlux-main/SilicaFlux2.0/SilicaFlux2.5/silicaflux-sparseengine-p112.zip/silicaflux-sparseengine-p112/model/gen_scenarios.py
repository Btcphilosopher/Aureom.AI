#!/usr/bin/env python3
"""
Scenario generator for tb/tb_sparse.sv.

Builds a memory image, a region table and a command, runs the independent
reference model (sp_model.py) and writes a self-contained scenario with the
expected completion record, output-buffer bytes and final memory image.

Usage:  gen_scenarios.py <suite> <outfile> [--addr-w N]
        suites are defined at the bottom (stage1, stage2, stage3, ...).
"""
import random
import sys
import zlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import sp_model as M

# default knobs (decimal): lat jit ooo banks svc rdy rsp seed maxout merge burst ipgap
KNOBS_DEFAULT = dict(lat=2, jit=0, ooo=0, banks=0, svc=1, rdy=100, rsp=0, seed=1, maxout=4, merge=1, burst=1, ipgap=0)


@dataclass
class Scenario:
    name: str
    cfg: M.Cfg
    cmd: M.Cmd
    mem: Dict[int, int] = field(default_factory=dict)           # beat -> int128
    regions: List[tuple] = field(default_factory=list)          # (dom, idx, base, size, r, w)
    allow: int = 15
    ipush: List[int] = field(default_factory=list)
    ibuf: Dict[int, int] = field(default_factory=dict)          # word -> int128
    err_beats: Dict[int, int] = field(default_factory=dict)     # beat -> ALP status
    knobs: Dict[str, int] = field(default_factory=lambda: dict(KNOBS_DEFAULT))
    group: str = "inorder"                                      # "inorder" | "ooo": which TB build runs it
    cont: bool = False                                          # continues the previous scenario (no reset, memory kept)
    base_mem: Optional[Dict[int, int]] = None                   # full initial image for the model (cont scenarios); mem = own additions
    mid_reset: Optional[int] = None                             # assert reset N cycles after the command is issued
    nomem: bool = False                                         # outcome depends on timing: do not compare memory / OBUF
    rogue: Optional[tuple] = None                               # (tag, delay, expect_proto): the target injects one response that answers no request


def seeded(name: str, extra: int = 0) -> random.Random:
    return random.Random(zlib.crc32(name.encode()) ^ extra)


# ----------------------------------------------------------------------------- memory helpers
def put_bytes(mem: Dict[int, int], addr: int, data: bytes) -> None:
    m = M.Mem(mem)
    m.wr(addr, data)
    mem.clear()
    mem.update(m.beats_int())


def fill_random(mem: Dict[int, int], base: int, nbytes: int, rng: random.Random) -> bytes:
    data = bytes(rng.getrandbits(8) for _ in range(nbytes))
    put_bytes(mem, base, data)
    return data


def put_array(mem: Dict[int, int], base: int, vals: List[int], width_bytes: int) -> None:
    data = b"".join((v & ((1 << (8 * width_bytes)) - 1)).to_bytes(width_bytes, "little") for v in vals)
    put_bytes(mem, base, data)


# default memory map (ADDR_W independent): table 256 KiB at 0x1_0000, indices 64 KiB at 0x8_0000
TBL_BASE = 0x10000
TBL_SIZE = 0x40000
IDX_BASE = 0x80000
IDX_SIZE = 0x10000


def std_regions(dom: int = 0):
    return [(dom, 0, TBL_BASE, TBL_SIZE, 1, 1), (dom, 1, IDX_BASE, IDX_SIZE, 1, 1)]


def init_image(sc: Scenario) -> Dict[int, int]:
    return sc.base_mem if sc.base_mem is not None else sc.mem


def run_model(sc: Scenario) -> M.Result:
    if sc.rogue is not None and sc.rogue[2]:
        # SP_F_PROTO (docs/02 §7): the code and the element that was next to be delivered when the rogue response arrived (0: the
        # real response is still outstanding) are specified; what happens to later elements is not (elems_done = -1: not compared)
        return M.Result(fault=M.F_PROTO, elems_done=-1)
    return M.model(sc.cfg, sc.cmd, M.Mem(init_image(sc)), sc.regions, sc.allow, sc.ipush, sc.ibuf, sc.err_beats)


# ----------------------------------------------------------------------------- emission
def emit(f, sc: Scenario, res: M.Result) -> None:
    c = sc.cmd
    k = sc.knobs
    f.write(f"SCEN {sc.name}\n")
    if sc.cont:
        f.write("CONT\n")
    if sc.mid_reset is not None:
        f.write(f"MIDRESET {sc.mid_reset}\n")
    if sc.nomem:
        f.write("NOMEM\n")
    if sc.rogue is not None:
        f.write(f"ROGUE {sc.rogue[0]:x} {sc.rogue[1]}\n")
    f.write("KNOB {lat} {jit} {ooo} {banks} {svc} {rdy} {rsp} {seed} {maxout} {merge} {burst} {ipgap}\n".format(**k))
    f.write(f"ALLOW {sc.allow:x}\n")
    for (d, i, b, s, r, w) in sc.regions:
        f.write(f"REGION {d} {i} {b:x} {s:x} {r} {w}\n")
    for beat in sorted(sc.mem):
        f.write(f"MEM {beat:x} {sc.mem[beat]:032x}\n")
    for w in sorted(sc.ibuf):
        f.write(f"IBUF {w:x} {sc.ibuf[w]:032x}\n")
    for b in sorted(sc.err_beats):
        f.write(f"ERR {b:x} {sc.err_beats[b]}\n")
    if sc.ipush:
        f.write(f"IPUSH {len(sc.ipush)} " + " ".join(f"{v:x}" for v in sc.ipush) + "\n")
    f.write("CMD {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x} {:x}\n".format(
        c.op, c.tid, c.dom, c.cacheable, c.idx_stream, c.idx_signed, c.idx_w, c.base, c.idx_base, c.n,
        c.elem_bytes, c.idx_limit, c.dst_off, c.src_off, c.rp_base, c.ci_base, c.val_base,
        c.nrows, c.ncols, c.nnz, c.ci_w, c.vfmt))
    f.write(f"EXP {res.fault} {res.gfault} {res.alp_status} {res.fault_elem:x} {res.fault_addr:x} {res.elems_done} {res.ovf}\n")
    # expected OBUF bytes: group by 16-byte word with a byte mask
    words: Dict[int, List[int]] = {}
    for off, v in res.obuf.items():
        w = off >> 4
        ent = words.setdefault(w, [0, 0])
        ent[0] |= v << (8 * (off & 15))
        ent[1] |= 1 << (off & 15)
    for w in sorted(words):
        f.write(f"EOBUF {w:x} {words[w][0]:032x} {words[w][1]:04x}\n")
    init_img = M.Mem(init_image(sc)).beats_int()
    final_img = init_img if not res.mem else {k2: int.from_bytes(bytes(v), "little") for k2, v in res.mem.items()}
    for beat in sorted(set(init_img) | set(final_img)):
        if final_img.get(beat, 0) != init_img.get(beat, 0):
            f.write(f"EMEM {beat:x} {final_img.get(beat, 0):032x}\n")
    f.write("RUN\n")


def final_image(sc: Scenario, res: M.Result) -> Dict[int, int]:
    if res.mem:
        return {k: int.from_bytes(bytes(v), "little") for k, v in res.mem.items()}
    return M.Mem(init_image(sc)).beats_int()


def chain(scs: List[Scenario]) -> List[Scenario]:
    """Make scs[1:] continue scs[0]: no reset, memory carried over (initial image = previous final image)."""
    state = None
    for i, sc in enumerate(scs):
        if i > 0:
            sc.cont = True
            init = dict(state)
            init.update(sc.mem)
            sc.base_mem = init
        res = run_model(sc)
        state = final_image(sc, res)
    return scs


# ----------------------------------------------------------------------------- gather builders
def gather(name: str, cfg: M.Cfg, *, E: int, idx: List[int], idx_w: int = 2, signed: int = 0, stream: int = 0,
           limit: int = 0, base: int = TBL_BASE, dst_off: int = 0, dom: int = 0, tid: Optional[int] = None,
           regions=None, allow: int = 15, knobs: Optional[dict] = None, group: str = "inorder",
           cacheable: int = 1, err_beats: Optional[Dict[int, int]] = None, tbl_bytes: int = TBL_SIZE,
           idx_base: int = IDX_BASE, raw_idx: Optional[List[int]] = None, seed_tag: int = 0) -> Scenario:
    rng = seeded(name, seed_tag)
    mem: Dict[int, int] = {}
    n = len(idx)
    vals = raw_idx if raw_idx is not None else idx
    span = min(tbl_bytes, (max([abs(v) for v in vals] + [0]) + 2) * E + 64)
    fill_random(mem, base if TBL_BASE <= base < TBL_BASE + TBL_SIZE else TBL_BASE, min(span, TBL_SIZE), rng)
    sc = Scenario(name=name, cfg=cfg, cmd=M.Cmd(op=M.OP_GATHER, tid=(tid if tid is not None else rng.getrandbits(16)),
                                               dom=dom, cacheable=cacheable, idx_stream=stream, idx_signed=signed,
                                               idx_w=idx_w, base=base, idx_base=idx_base, n=n, elem_bytes=E,
                                               idx_limit=limit, dst_off=dst_off),
                  mem=mem, regions=regions if regions is not None else std_regions(dom), allow=allow, group=group,
                  err_beats=err_beats or {})
    if stream:
        sc.ipush = [v & ((1 << (8 << idx_w)) - 1) for v in vals]
    else:
        put_array(sc.mem, idx_base, vals, 1 << idx_w)
    if knobs:
        sc.knobs.update(knobs)
    return sc


def stage1_suite(cfg: M.Cfg) -> List[Scenario]:
    out: List[Scenario] = []
    rows = {1: 4096, 2: 4096, 4: 4096, 8: 2048, 16: 1024, 32: 512, 48: 512, 64: 512, 256: 128}

    def uni(name, E, n, kind, rng):
        nrow = rows[E]
        if kind == "seq":
            return [i % nrow for i in range(n)]
        if kind == "rev":
            return [(n - 1 - i) % nrow for i in range(n)]
        if kind == "rand":
            return [rng.randrange(nrow) for _ in range(n)]
        if kind == "same":
            return [rng.randrange(nrow)] * n
        if kind == "alt":
            a, b = rng.randrange(nrow), rng.randrange(nrow)
            return [a if i % 2 == 0 else b for i in range(n)]
        if kind == "stride":
            return [(i * 7) % nrow for i in range(n)]
        raise ValueError(kind)

    # --- one scenario per (element size, pattern) -- in-order memory, 1 request per cycle
    for E in (1, 2, 4, 8, 16, 32, 48, 64, 256):
        for kind in ("seq", "rand", "same", "alt", "rev", "stride"):
            name = f"s1_E{E}_{kind}"
            rng = seeded(name)
            n = 70 if E <= 16 else 40
            out.append(gather(name, cfg, E=E, idx=uni(name, E, n, kind, rng), idx_w=2))
    # --- index widths and signedness
    for w in (0, 1, 2):
        for sg in (0, 1):
            for st in (0, 1):
                name = f"s1_idxw{w}_s{sg}_stream{st}"
                rng = seeded(name)
                lim = 200 if w == 0 else 1000
                idx = [rng.randrange(lim) for _ in range(90)]
                out.append(gather(name, cfg, E=4, idx=idx, idx_w=w, signed=sg, stream=st, dst_off=64,
                                  knobs=dict(ipgap=30 if st else 0)))
    # --- sizes of n: 0, 1, 2, ROB-sized and larger than every buffer
    for n in (0, 1, 2, 3, 31, 32, 33, 64, 200):
        name = f"s1_n{n}"
        rng = seeded(name)
        out.append(gather(name, cfg, E=8, idx=[rng.randrange(2000) for _ in range(n)], idx_w=1))
    # --- local buffer placement
    out.append(gather("s1_dst_off_4k", cfg, E=16, idx=list(range(0, 60, 3)), dst_off=4096))
    out.append(gather("s1_dst_full_buffer", cfg, E=64, idx=list(range(cfg.OBUF_BYTES // 64)), dst_off=0))
    # --- table at an unaligned (but element-aligned) base, element straddling no beat
    out.append(gather("s1_base_unaligned_E4", cfg, E=4, idx=list(range(100)), base=TBL_BASE + 12))
    out.append(gather("s1_base_unaligned_E2", cfg, E=2, idx=list(range(100)), base=TBL_BASE + 2))
    out.append(gather("s1_base_unaligned_E1", cfg, E=1, idx=list(range(100)), base=TBL_BASE + 7))
    # --- top of the address space region (overflow boundary)
    top = (1 << cfg.ADDR_W) - 0x2000
    rg = [(0, 0, top, 0x2000, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1)]
    sc = gather("s1_top_of_space_ok", cfg, E=8, idx=list(range(0, 1024, 5)), base=top, regions=rg)
    for beat in range(top >> 4, (top + 0x2000) >> 4):
        sc.mem[beat] = random.Random(beat).getrandbits(128)
    out.append(sc)
    return out


def elem_beats(sc: Scenario, j: int) -> List[int]:
    """Beats (data table) touched by element j of a gather scenario (from the stored index array / push list)."""
    c = sc.cmd
    raw = sc.ipush[j] if c.idx_stream else M.raw_index_from_mem(M.Mem(sc.mem), c, j)
    idx = raw & ((1 << (8 << c.idx_w)) - 1)
    return M.beats_of(c.base + idx * c.elem_bytes, c.elem_bytes)


def idx_beat(sc: Scenario, j: int) -> int:
    return (sc.cmd.idx_base + j * (1 << sc.cmd.idx_w)) >> 4


def override(sc: Scenario, **kw) -> Scenario:
    for k, v in kw.items():
        setattr(sc.cmd, k, v)
    return sc


def stage1_fault_suite(cfg: M.Cfg) -> List[Scenario]:
    out: List[Scenario] = []
    base_idx = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 8, 9, 7, 9, 3]

    # ---- negative indices: first / middle / last element, every width
    for w in (0, 1, 2):
        for pos in (0, 7, len(base_idx) - 1):
            raw = list(base_idx)
            raw[pos] = (1 << (8 << w)) - 3            # -3 in two's complement
            out.append(gather(f"f1_neg_w{w}_pos{pos}", cfg, E=4, idx=base_idx, raw_idx=raw, idx_w=w, signed=1))
            # same raw value, unsigned: a huge index -> out of the table region / address overflow, never "negative"
            out.append(gather(f"f1_negraw_unsigned_w{w}_pos{pos}", cfg, E=4, idx=base_idx, raw_idx=raw, idx_w=w, signed=0))
    # largest positive signed value is not negative
    out.append(gather("f1_signed_maxpos_w0", cfg, E=1, idx=[127, 0, 5], idx_w=0, signed=1, base=TBL_BASE))
    # ---- idx_limit
    for pos in (0, 5, 15):
        idx = [i % 10 for i in base_idx]
        idx[pos] = 10
        out.append(gather(f"f1_limit_hit_pos{pos}", cfg, E=8, idx=idx, limit=10))
    out.append(gather("f1_limit_edge_ok", cfg, E=8, idx=[9, 0, 9, 9], limit=10))
    out.append(gather("f1_limit_stream", cfg, E=8, idx=[1, 2, 3, 40, 5], limit=10, stream=1, knobs=dict(ipgap=20)))
    out.append(gather("f1_limit_1", cfg, E=8, idx=[0, 0, 1], limit=1))
    # ---- address overflow (exactly at the top of the address space is legal)
    top = (1 << cfg.ADDR_W) - 0x1000
    rg = [(0, 0, top, 0x1000, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1)]
    for pos in (0, 3):
        idx = [0, 1, 2, 3, 4, 5]
        idx[pos] = 64
        sc = gather(f"f1_addr_ovf_pos{pos}", cfg, E=64, idx=idx, base=top, regions=rg)
        for b in range(top >> 4, (top + 0x1000) >> 4):
            sc.mem[b] = random.Random(b).getrandbits(128)
        out.append(sc)
    sc = gather("f1_addr_last_elem_fits", cfg, E=64, idx=[63, 62, 0], base=top, regions=rg)
    for b in range(top >> 4, (top + 0x1000) >> 4):
        sc.mem[b] = random.Random(b ^ 77).getrandbits(128)
    out.append(sc)
    out.append(gather("f1_addr_huge_index", cfg, E=256, idx=[1, 2], raw_idx=[1, 0xFFFFFFFF], idx_w=2))
    out.append(gather("f1_addr_huge_index_stream", cfg, E=256, idx=[1, 2], raw_idx=[1, 0xFFFFFFFF], idx_w=2, stream=1))

    # ---- permissions (MemoryGuard)
    out.append(gather("f1_perm_no_regions", cfg, E=4, idx=base_idx, regions=[]))
    out.append(gather("f1_perm_no_regions_stream", cfg, E=4, idx=base_idx, regions=[], stream=1))
    out.append(gather("f1_perm_idx_array_unmapped", cfg, E=4, idx=base_idx, regions=[(0, 0, TBL_BASE, TBL_SIZE, 1, 1)]))
    out.append(gather("f1_perm_table_write_only", cfg, E=4, idx=base_idx,
                      regions=[(0, 0, TBL_BASE, TBL_SIZE, 0, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1)]))
    out.append(gather("f1_perm_idx_write_only", cfg, E=4, idx=base_idx,
                      regions=[(0, 0, TBL_BASE, TBL_SIZE, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 0, 1)]))
    out.append(gather("f1_perm_table_read_only_ok", cfg, E=4, idx=base_idx,
                      regions=[(0, 0, TBL_BASE, TBL_SIZE, 1, 0), (0, 1, IDX_BASE, IDX_SIZE, 1, 0)]))
    # element crossing the end of its region (span / partial overlap), and exactly fitting the end
    reg_sz = 0x400
    for E in (4, 16, 64):
        rgn = [(0, 0, TBL_BASE, reg_sz, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1)]
        last_ok = reg_sz // E - 1
        out.append(gather(f"f1_region_end_exact_E{E}", cfg, E=E, idx=[0, last_ok, last_ok], regions=rgn))
        out.append(gather(f"f1_region_end_cross_E{E}", cfg, E=E, idx=[0, last_ok, last_ok + 1, 2], regions=rgn))
    # a straddling element inside two ADJACENT regions is still denied (must lie in ONE region)
    rgn = [(0, 0, TBL_BASE, 0x400, 1, 1), (0, 2, TBL_BASE + 0x400, 0x400, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1)]
    out.append(gather("f1_adjacent_regions_straddle", cfg, E=16, idx=[0, 63, 64, 65], regions=rgn, base=TBL_BASE + 0x3F8 - 0x3F8 + 8 - 8))
    out.append(gather("f1_adjacent_regions_straddle_E8", cfg, E=8, idx=[0, 127, 128], regions=rgn, base=TBL_BASE + 4 - 4))
    # sub-beat element at the edge of a region that is not 16-byte aligned: its OWN bytes are validated, not the whole beat
    rgn = [(0, 0, TBL_BASE + 5, 0x100 - 5, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1)]
    out.append(gather("f1_region_unaligned_edge_E1", cfg, E=1, idx=[5, 6, 100, 250], regions=rgn))
    out.append(gather("f1_region_unaligned_edge_E1_below", cfg, E=1, idx=[6, 5, 4], regions=rgn))
    # tenant isolation: domain, allow mask, spoofing
    two = [(0, 0, TBL_BASE, TBL_SIZE, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1),
           (1, 0, TBL_BASE + 0x8000, 0x1000, 1, 1), (1, 1, IDX_BASE, IDX_SIZE, 1, 1)]
    out.append(gather("f1_tenant_own_region_ok", cfg, E=4, idx=[0, 1, 2, 3], dom=1, base=TBL_BASE + 0x8000, regions=two))
    out.append(gather("f1_tenant_foreign_table", cfg, E=4, idx=[0, 1, 2, 3], dom=1, base=TBL_BASE, regions=two))
    out.append(gather("f1_tenant_foreign_table_mid", cfg, E=4, idx=[0, 1, 2, 1024, 3], dom=1, base=TBL_BASE + 0x8000 , regions=two))
    out.append(gather("f1_tenant_spoof_not_allowed", cfg, E=4, idx=[0, 1, 2, 3], dom=1, base=TBL_BASE + 0x8000, regions=two, allow=0b0001))
    out.append(gather("f1_tenant_spoof_stream", cfg, E=4, idx=[0, 1, 2, 3], dom=1, base=TBL_BASE + 0x8000, regions=two, allow=0b0001, stream=1))
    out.append(gather("f1_tenant_allow_only_dom1", cfg, E=4, idx=[0, 1, 2, 3], dom=1, base=TBL_BASE + 0x8000, regions=two, allow=0b0010))
    out.append(gather("f1_tenant_dom0_denied_when_only_dom1_bound", cfg, E=4, idx=[0, 1], dom=0, regions=two, allow=0b0010))
    out.append(gather("f1_tenant_dom3_empty_table", cfg, E=4, idx=[0, 1], dom=3, regions=two, allow=0b1111))

    # ---- decode faults
    out.append(gather("f1_dec_E0", cfg, E=4, idx=base_idx))
    override(out[-1], elem_bytes=0)
    for E in (3, 5, 6, 7, 9, 12, 15, 17, 24, 100, cfg.MAX_ELEM_BYTES + 16):
        sc = gather(f"f1_dec_bad_elem_{E}", cfg, E=4, idx=base_idx[:4])
        override(sc, elem_bytes=E)
        out.append(sc)
    out.append(override(gather("f1_dec_idxw3", cfg, E=4, idx=base_idx[:4]), idx_w=3))
    out.append(override(gather("f1_dec_align_base_E4", cfg, E=4, idx=base_idx[:4]), base=TBL_BASE + 2))
    out.append(override(gather("f1_dec_align_base_E8", cfg, E=8, idx=base_idx[:4]), base=TBL_BASE + 4))
    out.append(override(gather("f1_dec_align_base_E32", cfg, E=32, idx=base_idx[:4]), base=TBL_BASE + 8))
    out.append(override(gather("f1_dec_align_idxbase", cfg, E=4, idx=base_idx[:4]), idx_base=IDX_BASE + 2))
    out.append(override(gather("f1_dec_align_idxbase_w1", cfg, E=4, idx=base_idx[:4], idx_w=1), idx_base=IDX_BASE + 1))
    out.append(override(gather("f1_dec_align_dst", cfg, E=4, idx=base_idx[:4]), dst_off=2))
    out.append(override(gather("f1_dec_align_dst_E32", cfg, E=32, idx=base_idx[:4]), dst_off=8))
    out.append(override(gather("f1_dec_buf_range", cfg, E=16, idx=list(range(8))), dst_off=cfg.OBUF_BYTES - 64))
    out.append(override(gather("f1_dec_buf_range_exact_ok", cfg, E=16, idx=list(range(8))), dst_off=cfg.OBUF_BYTES - 128))
    if (1 << cfg.ADDR_W) + 0x1000 < (1 << 48):       # not representable in the 48-bit command field otherwise
        out.append(override(gather("f1_dec_base_over_space", cfg, E=4, idx=base_idx[:4]), base=(1 << cfg.ADDR_W) + 0x1000))
        out.append(override(gather("f1_dec_idxbase_over_space", cfg, E=4, idx=base_idx[:4]), idx_base=(1 << cfg.ADDR_W) + 0x1000))
    out.append(override(gather("f1_dec_op_nop", cfg, E=4, idx=base_idx[:4]), op=M.OP_NOP))
    out.append(override(gather("f1_dec_op_reserved", cfg, E=4, idx=base_idx[:4]), op=9))
    out.append(override(gather("f1_dec_n_zero_bad_elem", cfg, E=4, idx=[]), elem_bytes=3))

    # ---- memory-side errors
    for st in (7, 10):
        sc = gather(f"f1_memerr_data_first_st{st}", cfg, E=4, idx=[10, 11, 12, 13, 200, 201])
        sc.err_beats = {b: st for b in elem_beats(sc, 0)}
        out.append(sc)
        sc = gather(f"f1_memerr_data_mid_st{st}", cfg, E=4, idx=[10, 11, 12, 13, 200, 201, 300, 301])
        sc.err_beats = {b: st for b in elem_beats(sc, 4)}
        out.append(sc)
        sc = gather(f"f1_memerr_data_last_st{st}", cfg, E=64, idx=list(range(6)))
        sc.err_beats = {b: st for b in elem_beats(sc, 5)}
        out.append(sc)
    sc = gather("f1_memerr_shared_beat", cfg, E=4, idx=[50, 51, 52, 53, 54, 55, 56, 57, 58])       # many elements share one erroring beat
    sc.err_beats = {elem_beats(sc, 4)[0]: 7}
    out.append(sc)
    sc = gather("f1_memerr_two_beats", cfg, E=4, idx=[10, 400, 800, 1200, 1600])
    sc.err_beats = {elem_beats(sc, 4)[0]: 7, elem_beats(sc, 2)[0]: 10}
    out.append(sc)
    sc = gather("f1_memerr_index_beat", cfg, E=4, idx=list(range(24)))
    sc.err_beats = {idx_beat(sc, 9): 7}
    out.append(sc)
    sc = gather("f1_memerr_index_beat_first", cfg, E=4, idx=list(range(24)))
    sc.err_beats = {idx_beat(sc, 0): 7}
    out.append(sc)
    # a memory error earlier in the stream wins over a later front-end fault (lowest element index)
    raw = list(range(20)); raw[15] = (1 << 31) + 5
    sc = gather("f1_memerr_before_neg", cfg, E=4, idx=raw, raw_idx=raw, signed=1)
    sc.err_beats = {elem_beats(sc, 3)[0]: 7}
    out.append(sc)
    sc = gather("f1_neg_before_memerr", cfg, E=4, idx=raw, raw_idx=raw, signed=1)
    sc.err_beats = {elem_beats(sc, 3)[0]: 7}
    sc.cmd.idx_signed = 1
    raw2 = list(raw); raw2[2] = (1 << 31) + 1
    put_array(sc.mem, sc.cmd.idx_base, raw2, 4)
    out.append(sc)
    # ---- same-cycle fault arbitration.  A memory error on element 5 is seen at DELIVERY, about <latency> cycles after its
    #      request; a front-end (permission) fault on element 5+d is seen at the address generator.  For some d both reach the
    #      fault arbiter in the same cycle, and the LOWEST element must win in every case.  Swept over latency and distance.
    for lat in (2, 4, 6, 9):
        for d in list(range(-2, 0)) + list(range(1, 26)):
            raw = [16 * k for k in range(40)]
            raw[5 + d] = 100000                                   # beyond the table region
            sc = gather(f"f1_race_l{lat}_d{d + 2:02d}", cfg, E=4, idx=raw, raw_idx=raw, tbl_bytes=4096, knobs=dict(lat=lat))
            sc.err_beats = {elem_beats(sc, 5)[0]: 7}
            out.append(sc)
    # ---- an index array that starts mid-beat, inside a region that ends exactly where the array ends: the index reader may
    #      request only the array's own bytes (the link byte monitor of the bench checks every byte on the link)
    for w, offs in ((2, (4, 8, 12)), (1, (2, 6, 14)), (0, (1, 5, 15))):
        for off in offs:
            idx = [(7 * k + 3) % 200 for k in range(21)]
            ib = IDX_BASE + off
            out.append(gather(f"f1_tight_idx_w{w}_off{off}", cfg, E=4, idx=idx, idx_w=w, idx_base=ib,
                              regions=[(0, 0, TBL_BASE, TBL_SIZE, 1, 1), (0, 1, ib, len(idx) << w, 1, 0)]))
    return out


def chain_suite(cfg: M.Cfg) -> List[Scenario]:
    """Command sequences without reset: recovery after faults, back-to-back commands, mid-command reset."""
    out: List[Scenario] = []
    idx_ok = [5, 9, 1, 77, 5, 12, 13, 14]
    # fault then good command: the engine must be fully clean afterwards
    for kind in ("neg", "perm", "memerr", "limit", "decode"):
        a = gather(f"c1_{kind}_then_ok_A", cfg, E=4, idx=list(range(40)), signed=1)
        if kind == "neg":
            raw = list(range(40)); raw[20] = 0xFFFFFFFF
            a = gather(f"c1_{kind}_then_ok_A", cfg, E=4, idx=list(range(40)), raw_idx=raw, signed=1)
        elif kind == "perm":
            a = gather(f"c1_{kind}_then_ok_A", cfg, E=4, idx=list(range(40)), raw_idx=list(range(39)) + [100000])
        elif kind == "memerr":
            a.err_beats = {elem_beats(a, 17)[0]: 7}
        elif kind == "limit":
            a = gather(f"c1_{kind}_then_ok_A", cfg, E=4, idx=list(range(40)), limit=25)
        elif kind == "decode":
            override(a, elem_bytes=6)
        b = gather(f"c1_{kind}_then_ok_B", cfg, E=4, idx=idx_ok, dst_off=256)
        c = gather(f"c1_{kind}_then_ok_C", cfg, E=16, idx=[3, 2, 1, 0, 3], dst_off=512)
        out += chain([a, b, c])
    # back-to-back good commands with different shapes
    s1 = gather("c2_b2b_A", cfg, E=8, idx=list(range(50)))
    s2 = gather("c2_b2b_B", cfg, E=1, idx=[i * 3 for i in range(70)], idx_w=1, dst_off=1024)
    s3 = gather("c2_b2b_C", cfg, E=64, idx=[5, 5, 5, 6], dst_off=2048, stream=1)
    s4 = gather("c2_b2b_D", cfg, E=2, idx=list(range(100, 140)), idx_w=0 if False else 1, dst_off=4096)
    out += chain([s1, s2, s3, s4])
    # reset in the middle of a command, then a clean command
    for cyc in (3, 12, 30, 60):
        a = gather(f"c3_midreset_{cyc}", cfg, E=16, idx=list(range(120)), knobs=dict(lat=6, jit=3))
        a.mid_reset = cyc
        b = gather(f"c3_after_reset_{cyc}", cfg, E=16, idx=[7, 6, 5, 4, 7, 7, 1], dst_off=128)
        out += chain([a, b])
    for cyc in (5, 40):
        a = gather(f"c3_midreset_stream_{cyc}", cfg, E=8, idx=list(range(100)), stream=1, knobs=dict(ipgap=30))
        a.mid_reset = cyc
        b = gather(f"c3_after_reset_stream_{cyc}", cfg, E=8, idx=[7, 6, 5, 4, 7, 7, 1], stream=1)
        out += chain([a, b])
    return out


def stage2_suite(cfg: M.Cfg) -> List[Scenario]:
    """Response reordering, coalescing and back-pressure: workloads x timing environments."""
    out: List[Scenario] = []
    work = {}
    rows = {1: 4096, 4: 4096, 8: 2048, 16: 1024, 64: 512, 256: 128}
    rngw = random.Random(12345)
    for E in (1, 4, 16, 64, 256):
        nrow = rows[E]
        work[f"E{E}_rand"] = (E, [rngw.randrange(nrow) for _ in range(150)])
        work[f"E{E}_seq"] = (E, [i % nrow for i in range(150)])
        work[f"E{E}_hot"] = (E, [rngw.choice([3, 4, 5, 90, 91, 700 % nrow]) for _ in range(150)])
    envs = []
    r = random.Random(7)
    for lat in (1, 3, 10):
        for jit in (0, 8):
            for ooo in (0, 1, 2):
                for banks in (0, 4):
                    envs.append(dict(lat=lat, jit=jit, ooo=ooo, banks=banks, svc=r.choice([1, 2, 4]),
                                     rdy=r.choice([100, 60, 25]), rsp=r.choice([0, 40, 70]),
                                     maxout=r.choice([1, 2, 4, 8, 16, 32]), merge=r.choice([1, 1, 0]),
                                     burst=r.choice([1, 0]), seed=r.randrange(1, 1000)))
    wl = sorted(work)
    k = 0
    for env in envs:
        name_w = wl[k % len(wl)]
        k += 1
        E, idx = work[name_w]
        name = f"s2_{name_w}_l{env['lat']}j{env['jit']}o{env['ooo']}b{env['banks']}_{k}"
        out.append(gather(name, cfg, E=E, idx=idx, idx_w=2, knobs=dict(env), group=("ooo" if env["ooo"] else "inorder"),
                          dst_off=0 if E * len(idx) <= cfg.OBUF_BYTES else 0))
    # explicit out-of-order stress: many outstanding, long jittered latency, tiny table (many dup / merge hits), big elements
    for E in (4, 16, 64):
        for mo in (8, 16, 32):
            idx = [rngw.randrange(64) for _ in range(200)]
            out.append(gather(f"s2_ooo_stress_E{E}_mo{mo}", cfg, E=E, idx=idx,
                              knobs=dict(lat=2, jit=30, ooo=1, banks=0, rdy=100, rsp=0, maxout=mo, seed=mo * 7 + E),
                              group="ooo"))
            out.append(gather(f"s2_ooo_random_pick_E{E}_mo{mo}", cfg, E=E, idx=[rngw.randrange(nr) for nr in [rows[E]] * 200],
                              knobs=dict(lat=4, jit=6, ooo=2, banks=0, rdy=80, rsp=20, maxout=mo, seed=mo * 11 + E),
                              group="ooo"))
    # fully backpressured memory (1 outstanding, slow ready)
    out.append(gather("s2_bp_maxout1", cfg, E=8, idx=[rngw.randrange(2000) for _ in range(100)],
                      knobs=dict(maxout=1, rdy=30, rsp=50, lat=3)))
    out.append(gather("s2_bp_stream_slow", cfg, E=8, idx=[rngw.randrange(2000) for _ in range(100)], stream=1,
                      knobs=dict(maxout=2, rdy=50, rsp=50, lat=3, ipgap=60)))
    # merge / burst ablations on the same workload (in-order, deterministic)
    base_idx = [rngw.randrange(512) for _ in range(120)]
    for m in (0, 1):
        for b in (0, 1):
            out.append(gather(f"s2_ablate_merge{m}_burst{b}", cfg, E=16, idx=base_idx, knobs=dict(merge=m, burst=b, lat=4)))
    # ---- protocol violation by the target: ONE response that answers no request.  ALP v1 forbids it; the engine must report
    #      SP_F_PROTO at once (nothing delivered), still complete (the real response is still outstanding), and run the next
    #      command cleanly.  The rogue response must overtake the real one and the in-order link checker must be absent,
    #      hence an out-of-order target (group "ooo").  "free": a tag index that names an idle table entry; "alias": the index
    #      NRT (0x100 = resolved by the bench; 31 when NRT = 32), out of range, which would alias entry 0 (in flight) if the
    #      range check were off by one.
    rg = dict(lat=6, jit=0, ooo=1, banks=0, rdy=100, rsp=0, maxout=4, seed=3)
    for nm, tag_idx in (("free", 1), ("alias", 0x100)):
        a = gather(f"s2_rogue_{nm}", cfg, E=4, idx=[11], stream=1, knobs=dict(rg), group="ooo")
        a.rogue = (tag_idx, 1, True)
        a.nomem = True                                            # OBUF / memory beyond the reported element are unspecified
        b = gather(f"s2_rogue_{nm}_then_ok", cfg, E=4, idx=[5, 9, 1, 77, 5, 12], knobs=dict(rg), group="ooo")
        out += chain([a, b])
    # an unassigned source tag is ignored (counted, not acted on): the command still completes correctly
    a = gather("s2_rogue_unknown_src", cfg, E=4, idx=list(range(8, 40, 3)), knobs=dict(rg), group="ooo")
    a.rogue = (0xE0, 1, False)
    out.append(a)
    return out


# ----------------------------------------------------------------------------- scatter builders
def put_ibuf(ibuf: Dict[int, int], off: int, data: bytes) -> None:
    for i, v in enumerate(data):
        a = off + i
        w = ibuf.get(a >> 4, 0)
        w &= ~(0xFF << (8 * (a & 15)))
        w |= v << (8 * (a & 15))
        ibuf[a >> 4] = w


def scatter(name: str, cfg: M.Cfg, *, E: int, idx: List[int], idx_w: int = 2, signed: int = 0, stream: int = 0,
            limit: int = 0, base: int = TBL_BASE, src_off: int = 0, dom: int = 0, regions=None, allow: int = 15,
            knobs: Optional[dict] = None, group: str = "inorder", cacheable: int = 1,
            err_beats: Optional[Dict[int, int]] = None, raw_idx: Optional[List[int]] = None, seed_tag: int = 0,
            idx_base: int = IDX_BASE) -> Scenario:
    rng = seeded(name, seed_tag)
    mem: Dict[int, int] = {}
    n = len(idx)
    vals = raw_idx if raw_idx is not None else idx
    span = min(TBL_SIZE, (max([abs(v) for v in vals] + [0]) + 2) * E + 64)
    fill_random(mem, TBL_BASE, span, rng)               # existing contents: untouched bytes must survive
    sc = Scenario(name=name, cfg=cfg, cmd=M.Cmd(op=M.OP_SCATTER, tid=rng.getrandbits(16), dom=dom, cacheable=cacheable,
                                               idx_stream=stream, idx_signed=signed, idx_w=idx_w, base=base,
                                               idx_base=idx_base, n=n, elem_bytes=E, idx_limit=limit, src_off=src_off),
                  mem=mem, regions=regions if regions is not None else std_regions(dom), allow=allow, group=group,
                  err_beats=err_beats or {})
    put_ibuf(sc.ibuf, src_off, bytes(rng.getrandbits(8) for _ in range(n * E)))
    if stream:
        sc.ipush = [v & ((1 << (8 << idx_w)) - 1) for v in vals]
    else:
        put_array(sc.mem, idx_base, vals, 1 << idx_w)
    if knobs:
        sc.knobs.update(knobs)
    return sc


def stage3_scatter_suite(cfg: M.Cfg) -> List[Scenario]:
    out: List[Scenario] = []
    rows = {1: 4096, 2: 4096, 4: 4096, 8: 2048, 16: 1024, 32: 512, 48: 512, 64: 512, 256: 128}
    rngw = random.Random(2024)

    def idxs(kind, E, n):
        nr = rows[E]
        if kind == "seq":    return [i % nr for i in range(n)]
        if kind == "rev":    return [(n - 1 - i) % nr for i in range(n)]
        if kind == "rand":   return [rngw.randrange(nr) for _ in range(n)]
        if kind == "dup":    return [rngw.randrange(max(2, n // 6)) for _ in range(n)]      # heavy duplicates
        if kind == "same":   return [rngw.randrange(nr)] * n
        if kind == "alt":
            a, b = rngw.randrange(nr), rngw.randrange(nr)
            return [a if i % 2 == 0 else b for i in range(n)]
        if kind == "stride": return [(i * 5) % nr for i in range(n)]
        raise ValueError(kind)

    # ---- every element size x index pattern (in-order, deterministic)
    for E in (1, 2, 4, 8, 16, 32, 48, 64, 256):
        for kind in ("seq", "rev", "rand", "dup", "same", "alt", "stride"):
            n = 60 if E <= 16 else 30
            out.append(scatter(f"s3_E{E}_{kind}", cfg, E=E, idx=idxs(kind, E, n)))
    # ---- index widths / signedness / stream
    for w in (0, 1, 2):
        for st in (0, 1):
            lim = 200 if w == 0 else 900
            out.append(scatter(f"s3_idxw{w}_stream{st}", cfg, E=4, idx=[rngw.randrange(lim) for _ in range(70)], idx_w=w,
                               stream=st, signed=w % 2, src_off=32, knobs=dict(ipgap=25 if st else 0)))
    # ---- sizes of n and source-buffer placement
    for n in (0, 1, 2, 3, 31, 32, 33, 64, 200):
        out.append(scatter(f"s3_n{n}", cfg, E=8, idx=[rngw.randrange(2000) for _ in range(n)], idx_w=1))
    out.append(scatter("s3_src_off_4k", cfg, E=16, idx=list(range(40)), src_off=4096))
    out.append(scatter("s3_src_full_buffer", cfg, E=64, idx=[rngw.randrange(500) for _ in range(cfg.IBUF_BYTES // 64)]))
    # ---- the duplicate-destination policy, spelled out: last write wins, bytes of other elements preserved
    out.append(scatter("s3_dup_last_wins_E4", cfg, E=4, idx=[7, 7, 7, 8, 7, 9, 8, 7]))
    out.append(scatter("s3_dup_last_wins_E1", cfg, E=1, idx=[3, 3, 4, 3, 3, 5, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]))
    out.append(scatter("s3_dup_last_wins_E64", cfg, E=64, idx=[2, 2, 3, 2, 2, 2, 3]))
    out.append(scatter("s3_dup_far_apart", cfg, E=16, idx=[5] + [rngw.randrange(100, 500) for _ in range(80)] + [5, 5]))
    # ---- write ordering against slow / reordering targets (a violated per-address order changes the result)
    for ooo, jit in ((0, 0), (1, 25), (2, 25)):
        for mo in (2, 16, 32):
            for E in (4, 16):
                idx = [rngw.randrange(24) for _ in range(150)]            # few distinct beats, many duplicates
                out.append(scatter(f"s3_order_ooo{ooo}_mo{mo}_E{E}", cfg, E=E, idx=idx, group=("ooo" if ooo else "inorder"),
                                   knobs=dict(lat=3, jit=jit, ooo=ooo, maxout=mo, rdy=70, rsp=30, seed=mo * 13 + E + ooo)))
    for merge in (0, 1):
        for burst in (0, 1):
            out.append(scatter(f"s3_order_merge{merge}_burst{burst}", cfg, E=4, idx=[rngw.randrange(20) for _ in range(120)],
                               knobs=dict(merge=merge, burst=burst, lat=5, jit=12, ooo=1, maxout=16), group="ooo"))
    # ---- backpressure and banked targets
    out.append(scatter("s3_bp_maxout1", cfg, E=8, idx=[rngw.randrange(600) for _ in range(100)], knobs=dict(maxout=1, rdy=30, rsp=50, lat=3)))
    out.append(scatter("s3_banked_ooo", cfg, E=16, idx=[rngw.randrange(300) for _ in range(150)],
                       knobs=dict(banks=4, svc=3, lat=4, jit=4, ooo=1, maxout=16), group="ooo"))
    # ---- faults: elements before the fault are committed, nothing at or after it
    base_idx = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 8, 9, 7, 9, 3]
    for pos in (0, 6, len(base_idx) - 1):
        raw = list(base_idx); raw[pos] = 0xFFFFFFFD
        out.append(scatter(f"f3_neg_pos{pos}", cfg, E=4, idx=base_idx, raw_idx=raw, signed=1))
        idx = list(base_idx); idx[pos] = 10 ** 6
        out.append(scatter(f"f3_limit_pos{pos}", cfg, E=4, idx=idx, limit=500))
    out.append(scatter("f3_perm_region_read_only", cfg, E=4, idx=base_idx,
                       regions=[(0, 0, TBL_BASE, TBL_SIZE, 1, 0), (0, 1, IDX_BASE, IDX_SIZE, 1, 0)]))
    out.append(scatter("f3_perm_region_read_only_stream", cfg, E=4, idx=base_idx, stream=1,
                       regions=[(0, 0, TBL_BASE, TBL_SIZE, 1, 0)]))
    reg_sz = 0x200
    rgn = [(0, 0, TBL_BASE, reg_sz, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1)]
    for E in (4, 16, 64):
        last_ok = reg_sz // E - 1
        out.append(scatter(f"f3_region_end_exact_E{E}", cfg, E=E, idx=[0, last_ok, 1, last_ok], regions=rgn))
        out.append(scatter(f"f3_region_end_cross_E{E}", cfg, E=E, idx=[0, 1, last_ok, last_ok + 1, 2, 3], regions=rgn))
    two = [(0, 0, TBL_BASE, TBL_SIZE, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1),
           (1, 0, TBL_BASE + 0x8000, 0x1000, 1, 1), (1, 1, IDX_BASE, IDX_SIZE, 1, 1)]
    out.append(scatter("f3_tenant_own_ok", cfg, E=4, idx=[0, 1, 2, 3, 700], dom=1, base=TBL_BASE + 0x8000, regions=two))
    out.append(scatter("f3_tenant_foreign", cfg, E=4, idx=[0, 1, 2, 3], dom=1, base=TBL_BASE, regions=two))
    out.append(scatter("f3_tenant_foreign_mid", cfg, E=4, idx=[0, 1, 2, 1100, 4], dom=1, base=TBL_BASE + 0x8000, regions=two))
    out.append(scatter("f3_tenant_spoof", cfg, E=4, idx=[0, 1, 2], dom=1, base=TBL_BASE + 0x8000, regions=two, allow=0b0001))
    out.append(scatter("f3_no_regions", cfg, E=4, idx=base_idx, regions=[]))
    top = (1 << cfg.ADDR_W) - 0x1000
    rg = [(0, 0, top, 0x1000, 1, 1), (0, 1, IDX_BASE, IDX_SIZE, 1, 1)]
    for pos in (0, 3):
        idx = [0, 1, 2, 3, 4, 5]; idx[pos] = 64
        sc = scatter(f"f3_addr_ovf_pos{pos}", cfg, E=64, idx=idx, base=top, regions=rg)
        for b in range(top >> 4, (top + 0x1000) >> 4):
            sc.mem[b] = random.Random(b).getrandbits(128)
        out.append(sc)
    # ---- decode faults
    out.append(override(scatter("f3_dec_bad_elem", cfg, E=4, idx=base_idx[:4]), elem_bytes=6))
    out.append(override(scatter("f3_dec_align_base", cfg, E=8, idx=base_idx[:4]), base=TBL_BASE + 4))
    out.append(override(scatter("f3_dec_align_src", cfg, E=8, idx=base_idx[:4]), src_off=4))
    out.append(override(scatter("f3_dec_align_src_E32", cfg, E=32, idx=base_idx[:4]), src_off=8))
    out.append(override(scatter("f3_dec_src_range", cfg, E=16, idx=list(range(8))), src_off=cfg.IBUF_BYTES - 64))
    out.append(override(scatter("f3_dec_src_range_exact_ok", cfg, E=16, idx=list(range(8))), src_off=cfg.IBUF_BYTES - 128))
    out.append(override(scatter("f3_dec_idxw3", cfg, E=4, idx=base_idx[:4]), idx_w=3))
    # ---- memory-side write errors.  Deterministic only when the failing element is the LAST one
    #      (later elements are not recalled), so the memory image is compared in those cases only.
    def last_beat(sc):
        c = sc.cmd
        raw = sc.ipush[-1] if c.idx_stream else M.raw_index_from_mem(M.Mem(sc.mem), c, c.n - 1)
        return M.beats_of(c.base + raw * c.elem_bytes, c.elem_bytes)
    for st in (7, 10):
        sc = scatter(f"f3_werr_last_st{st}", cfg, E=4, idx=[10, 11, 12, 13, 200, 201, 5000])
        sc.err_beats = {b: st for b in last_beat(sc)}
        out.append(sc)
        sc = scatter(f"f3_werr_last_E64_st{st}", cfg, E=64, idx=[10, 11, 12, 13, 200, 201, 202])
        sc.err_beats = {last_beat(sc)[1]: st}
        out.append(sc)
    sc = scatter("f3_werr_last_shared_beat", cfg, E=4, idx=[20, 21, 22, 23, 24, 25, 26, 27])       # all in beats 5-6; last beat fails
    sc.err_beats = {last_beat(sc)[0]: 7}
    out.append(sc)
    for mid in (0, 3):
        sc = scatter(f"f3_werr_mid_{mid}", cfg, E=4, idx=[10, 400, 800, 1200, 1600, 2000], knobs=dict(lat=4))
        c = sc.cmd
        sc.err_beats = {M.beats_of(c.base + (sc.ipush[mid] if c.idx_stream else M.raw_index_from_mem(M.Mem(sc.mem), c, mid)) * 4, 4)[0]: 7}
        sc.nomem = True                                   # later elements may or may not have been committed
        out.append(sc)
    sc = scatter("f3_werr_index_beat", cfg, E=4, idx=list(range(30)))
    sc.err_beats = {(IDX_BASE + 9 * 4) >> 4: 7}
    out.append(sc)
    # ---- same-cycle fault arbitration (scatter): a write error on element 5 (seen when its response returns) against an
    #      index-limit fault on element 5+d (seen at the address generator); the lowest element wins
    for lat in (2, 4, 6, 9):
        for d in list(range(-2, 0)) + list(range(1, 26)):
            raw = [16 * k for k in range(40)]
            raw[5 + d] = 5000
            sc = scatter(f"f3_race_l{lat}_d{d + 2:02d}", cfg, E=4, idx=raw, raw_idx=raw, limit=700, knobs=dict(lat=lat))
            sc.err_beats = {elem_beats(sc, 5)[0]: 7}
            sc.nomem = True                                       # later elements may or may not have been committed
            out.append(sc)
    # ---- index array starting mid-beat inside a region that ends exactly where the array ends
    for w, offs in ((2, (4, 8, 12)), (1, (2, 6, 14)), (0, (1, 5, 15))):
        for off in offs:
            idx = [(7 * k + 3) % 200 for k in range(21)]
            ib = IDX_BASE + off
            out.append(scatter(f"f3_tight_idx_w{w}_off{off}", cfg, E=4, idx=idx, idx_w=w, idx_base=ib,
                               regions=[(0, 0, TBL_BASE, TBL_SIZE, 1, 1), (0, 1, ib, len(idx) << w, 1, 0)]))
    return out


def chain3_suite(cfg: M.Cfg) -> List[Scenario]:
    """Scatter then gather read-back, scatter fault then recovery, back-to-back scatters (no reset in between)."""
    out: List[Scenario] = []
    rngw = random.Random(99)
    for E in (4, 16, 64):
        idx = list(range(0, 90, 3))
        a = scatter(f"c3s_roundtrip_E{E}", cfg, E=E, idx=idx)
        b = gather(f"c3s_roundtrip_E{E}_rd", cfg, E=E, idx=idx, dst_off=0)
        out += chain([a, b])
    idx = [rngw.randrange(40) for _ in range(120)]          # duplicates: the read-back sees the winners
    a = scatter("c3s_dups_roundtrip", cfg, E=8, idx=idx, knobs=dict(lat=4, jit=10, ooo=1, maxout=16), group="ooo")
    b = gather("c3s_dups_roundtrip_rd", cfg, E=8, idx=sorted(set(idx)), dst_off=0, group="ooo", knobs=dict(lat=4, jit=10, ooo=1, maxout=16))
    out += chain([a, b])
    for kind in ("neg", "perm", "limit"):
        raw = list(range(30))
        kw = {}
        if kind == "neg":
            raw[12] = 0xFFFFFFFF; kw = dict(signed=1)
        elif kind == "perm":
            raw[12] = 10 ** 7
        else:
            kw = dict(limit=20)
        a = scatter(f"c3s_{kind}_then_ok_A", cfg, E=4, idx=list(range(30)), raw_idx=raw, **kw)
        b = scatter(f"c3s_{kind}_then_ok_B", cfg, E=4, idx=[5, 6, 7, 5], src_off=256)
        c = gather(f"c3s_{kind}_then_ok_C", cfg, E=4, idx=list(range(30)), dst_off=512)
        out += chain([a, b, c])
    s1 = scatter("c3s_b2b_A", cfg, E=8, idx=list(range(50)))
    s2 = scatter("c3s_b2b_B", cfg, E=1, idx=[i * 3 for i in range(70)], idx_w=1, src_off=1024)
    s3 = scatter("c3s_b2b_C", cfg, E=64, idx=[5, 5, 5, 6], src_off=2048, stream=1)
    out += chain([s1, s2, s3])
    return out


# ----------------------------------------------------------------------------- CSR builders
RP_BASE = 0x80000
CI_BASE = 0x84000
VAL_BASE = 0x8A000


def csr(name: str, cfg: M.Cfg, *, rows: List[int], ncols: int, op: int = M.OP_CSR_SPMV, E: int = 1, ci_w: int = 2,
        vfmt: int = 0, dst_off: int = 0, dom: int = 0, regions=None, allow: int = 15, knobs: Optional[dict] = None,
        group: str = "inorder", cacheable: int = 1, err_beats=None, rp: Optional[List[int]] = None,
        cols: Optional[List[int]] = None, vals: Optional[List[int]] = None, nnz: Optional[int] = None,
        nrows: Optional[int] = None, ncols_cmd: Optional[int] = None, seed_tag: int = 0, colgen: str = "rand",
        ci_base: int = CI_BASE, val_base: int = VAL_BASE, rp_base: int = RP_BASE) -> Scenario:
    rng = seeded(name, seed_tag)
    total = sum(rows)
    rp_v = rp if rp is not None else [sum(rows[:i]) for i in range(len(rows) + 1)]
    if cols is None:
        cols = []
        for ln in rows:
            if colgen == "rand":
                cols += [rng.randrange(ncols) for _ in range(ln)]
            elif colgen == "sorted":
                cols += sorted(rng.randrange(ncols) for _ in range(ln))
            elif colgen == "hot":
                cols += [rng.choice([0, 1, ncols - 1, ncols // 2]) for _ in range(ln)]
            else:
                cols += [(len(cols) + j) % ncols for j in range(ln)]
    if vals is None:
        vals = [rng.randrange(256) for _ in range(total)]
    mem: Dict[int, int] = {}
    fill_random(mem, TBL_BASE, min(TBL_SIZE, max(1, ncols) * E + 64), rng)       # x vector
    put_array(mem, rp_base, rp_v, 4)
    put_array(mem, ci_base, cols, 1 << ci_w)
    put_array(mem, val_base, vals, 1)
    cmd = M.Cmd(op=op, tid=rng.getrandbits(16), dom=dom, cacheable=cacheable, base=TBL_BASE, elem_bytes=E, dst_off=dst_off,
                rp_base=rp_base, ci_base=ci_base, val_base=val_base, nrows=(len(rows) if nrows is None else nrows),
                ncols=(ncols if ncols_cmd is None else ncols_cmd), nnz=(total if nnz is None else nnz), ci_w=ci_w, vfmt=vfmt)
    sc = Scenario(name=name, cfg=cfg, cmd=cmd, mem=mem, regions=regions if regions is not None else std_regions(dom),
                  allow=allow, group=group, err_beats=err_beats or {})
    if knobs:
        sc.knobs.update(knobs)
    return sc


def rand_rows(rng: random.Random, nrows: int, maxlen: int, p_empty: float) -> List[int]:
    return [0 if rng.random() < p_empty else rng.randrange(1, maxlen + 1) for _ in range(nrows)]


def csr_suite(cfg: M.Cfg) -> List[Scenario]:
    out: List[Scenario] = []
    rngw = random.Random(31337)
    # ---- CSR_GATHER: x[col[k]] for every nonzero, element sizes and column widths
    for E in (1, 2, 4, 8, 16, 64):
        for ci_w in (0, 1, 2):
            ncols = 200 if ci_w == 0 else 700
            rows = rand_rows(rngw, 30, 6, 0.25)
            out.append(csr(f"s3c_gather_E{E}_ciw{ci_w}", cfg, rows=rows, ncols=ncols, op=M.OP_CSR_GATHER, E=E, ci_w=ci_w,
                           dst_off=32 if E < 16 else 0))
    for pattern in ("rand", "sorted", "hot", "seq"):
        rows = rand_rows(rngw, 40, 12, 0.2)
        out.append(csr(f"s3c_gather_cols_{pattern}", cfg, rows=rows, ncols=500, op=M.OP_CSR_GATHER, E=4, colgen=pattern))
    # ---- CSR_SPMV
    for ci_w in (0, 1, 2):
        for k in range(3):
            ncols = 200 if ci_w == 0 else 900
            rows = rand_rows(rngw, 25 + 10 * k, 9, 0.2)
            out.append(csr(f"s3c_spmv_ciw{ci_w}_{k}", cfg, rows=rows, ncols=ncols, ci_w=ci_w, dst_off=16 * k))
    shapes = {
        "all_empty":        [0] * 20,
        "first_empty":      [0, 0, 0, 4, 2, 5],
        "last_empty":       [3, 2, 0, 0, 0],
        "alternating":      [1, 0] * 20,
        "single_row":       [40],
        "single_row_long":  [150],
        "rows_of_one":      [1] * 50,
        "row_eq_rob":       [cfg.ROB_DEPTH, 1, cfg.ROB_DEPTH, 0, cfg.ROB_DEPTH + 1],
        "one_big_rest_empty": [0, 0, 90, 0, 0],
        "empty_mix":        rand_rows(rngw, 60, 5, 0.7),
        "dense":            [8] * 20,
    }
    for nm, rows in shapes.items():
        out.append(csr(f"s3c_spmv_{nm}", cfg, rows=rows, ncols=64))
    out.append(csr("s3c_spmv_one_row_one_col", cfg, rows=[1], ncols=1))
    out.append(csr("s3c_spmv_empty_matrix", cfg, rows=[], ncols=10))                  # nrows = 0, nnz = 0
    out.append(csr("s3c_gather_empty_matrix", cfg, rows=[], ncols=10, op=M.OP_CSR_GATHER))
    out.append(csr("s3c_gather_all_empty_rows", cfg, rows=[0] * 12, ncols=10, op=M.OP_CSR_GATHER))
    out.append(csr("s3c_spmv_dst_off", cfg, rows=rand_rows(rngw, 30, 4, 0.2), ncols=50, dst_off=1024))
    out.append(csr("s3c_spmv_full_buffer", cfg, rows=[1] * (cfg.OBUF_BYTES // 4), ncols=20))
    # ---- column indices at the very edge of the bound
    out.append(csr("s3c_col_edge_ok", cfg, rows=[3, 2], ncols=100, cols=[99, 0, 99, 99, 50]))
    out.append(csr("s3c_col_edge_8bit", cfg, rows=[3, 2], ncols=256, ci_w=0, cols=[255, 0, 255, 128, 1]))
    out.append(csr("s3c_col_edge_16bit", cfg, rows=[2, 2], ncols=65536, ci_w=1, cols=[65535, 0, 65535, 1]))
    # ---- ordering / timing environments
    for ooo, jit, mo in ((0, 0, 4), (1, 20, 16), (2, 12, 32)):
        out.append(csr(f"s3c_spmv_env_ooo{ooo}", cfg, rows=rand_rows(rngw, 80, 10, 0.2), ncols=300,
                       knobs=dict(lat=3, jit=jit, ooo=ooo, maxout=mo, rdy=70, rsp=25, seed=mo + ooo),
                       group="ooo" if ooo else "inorder"))
        out.append(csr(f"s3c_gather_env_ooo{ooo}", cfg, rows=rand_rows(rngw, 80, 10, 0.2), ncols=300, op=M.OP_CSR_GATHER, E=4,
                       knobs=dict(lat=3, jit=jit, ooo=ooo, maxout=mo, rdy=70, rsp=25, seed=mo + ooo + 1),
                       group="ooo" if ooo else "inorder"))
    out.append(csr("s3c_spmv_maxout1", cfg, rows=rand_rows(rngw, 40, 6, 0.2), ncols=80, knobs=dict(maxout=1, rdy=40, rsp=40, lat=3)))
    out.append(csr("s3c_spmv_banked", cfg, rows=rand_rows(rngw, 60, 8, 0.2), ncols=400,
                   knobs=dict(banks=4, svc=3, lat=4, jit=4, ooo=1, maxout=16), group="ooo"))
    # ---- validation faults of the traversal
    rows = [3, 0, 4, 2, 5]
    ok_rp = [0, 3, 3, 7, 9, 14]
    for pos in range(len(ok_rp)):
        rp = list(ok_rp)
        rp[pos] = rp[pos] + 100 if pos else 5
        out.append(csr(f"f3c_rp_bad_{pos}", cfg, rows=rows, ncols=50, rp=rp))
    out.append(csr("f3c_rp_nonmonotonic", cfg, rows=rows, ncols=50, rp=[0, 3, 2, 7, 9, 14]))
    out.append(csr("f3c_rp_nonmonotonic_last", cfg, rows=rows, ncols=50, rp=[0, 3, 3, 7, 9, 8]))
    out.append(csr("f3c_rp_last_short", cfg, rows=rows, ncols=50, rp=[0, 3, 3, 7, 9, 13]))
    out.append(csr("f3c_rp_last_long", cfg, rows=rows, ncols=50, rp=[0, 3, 3, 7, 9, 15]))
    out.append(csr("f3c_rp_mid_beyond_nnz", cfg, rows=rows, ncols=50, rp=[0, 3, 3, 20, 20, 14]))
    out.append(csr("f3c_rp_first_nonzero", cfg, rows=rows, ncols=50, rp=[1, 3, 3, 7, 9, 14]))
    out.append(csr("f3c_rp_huge", cfg, rows=rows, ncols=50, rp=[0, 3, 3, 0xFFFFFFFF, 9, 14]))
    for op in (M.OP_CSR_GATHER, M.OP_CSR_SPMV):
        tag = "gather" if op == M.OP_CSR_GATHER else "spmv"
        out.append(csr(f"f3c_rp_bad_{tag}_mid", cfg, rows=[4, 3, 5, 2, 6, 1], ncols=40, op=op, E=1, rp=[0, 4, 7, 12, 11, 17, 18]))
        for pos in (0, 5, 13):
            cols = [rngw.randrange(50) for _ in range(14)]
            cols[pos] = 50
            out.append(csr(f"f3c_col_oob_{tag}_{pos}", cfg, rows=rows, ncols=50, cols=cols, op=op))
        cols = [rngw.randrange(50) for _ in range(14)]
        cols[6] = 0xFFFFFFFF
        out.append(csr(f"f3c_col_huge_{tag}", cfg, rows=rows, ncols=50, cols=cols, op=op))
    out.append(csr("f3c_col_oob_8bit", cfg, rows=[3, 2], ncols=100, ci_w=0, cols=[99, 100, 3, 4, 5]))
    out.append(csr("f3c_col_oob_16bit", cfg, rows=[3, 2], ncols=1000, ci_w=1, cols=[99, 1, 1000, 4, 5]))
    # dimensions, formats, arithmetic support
    out.append(csr("f3c_dim_nrows0_nnz", cfg, rows=[3], ncols=10, nrows=0))
    out.append(csr("f3c_dim_ncols0_nnz", cfg, rows=[3], ncols=10, ncols_cmd=0))
    out.append(csr("f3c_dim_nrows0_nnz0_ok", cfg, rows=[], ncols=0, ncols_cmd=0))
    for vf in (4, 5, 7):
        out.append(csr(f"f3c_fmt_vfmt{vf}", cfg, rows=rows, ncols=50, vfmt=vf))
        out.append(csr(f"f3c_fmt_vfmt{vf}_gather", cfg, rows=rows, ncols=50, vfmt=vf, op=M.OP_CSR_GATHER))
    out.append(csr("f3c_fmt_ciw3", cfg, rows=rows, ncols=50, ci_w=3))
    for vf in (1, 2, 3):
        out.append(csr(f"f3c_unsup_spmv_vfmt{vf}", cfg, rows=rows, ncols=50, vfmt=vf))
        out.append(csr(f"f3c_gather_ok_vfmt{vf}", cfg, rows=rows, ncols=50, vfmt=vf, op=M.OP_CSR_GATHER, E=4))
    out.append(csr("f3c_unsup_spmv_E4", cfg, rows=rows, ncols=50, E=4))
    out.append(csr("f3c_bad_elem", cfg, rows=rows, ncols=50, op=M.OP_CSR_GATHER, E=6))
    # alignment and buffer range
    sc = csr("f3c_align_rp", cfg, rows=rows, ncols=50); sc.cmd.rp_base += 2; out.append(sc)
    sc = csr("f3c_align_ci_w2", cfg, rows=rows, ncols=50); sc.cmd.ci_base += 2; out.append(sc)
    sc = csr("f3c_align_ci_w1", cfg, rows=rows, ncols=50, ci_w=1); sc.cmd.ci_base += 1; out.append(sc)
    sc = csr("f3c_align_x_E4", cfg, rows=rows, ncols=50, op=M.OP_CSR_GATHER, E=4); sc.cmd.base += 2; out.append(sc)
    sc = csr("f3c_align_dst_spmv", cfg, rows=rows, ncols=50, dst_off=2); out.append(sc)
    out.append(csr("f3c_buf_range_spmv", cfg, rows=[1] * 10, ncols=50, dst_off=cfg.OBUF_BYTES - 20))
    out.append(csr("f3c_buf_range_gather", cfg, rows=[1] * 10, ncols=50, op=M.OP_CSR_GATHER, E=16, dst_off=cfg.OBUF_BYTES - 100))
    sc = csr("f3c_addr_over_space", cfg, rows=rows, ncols=50); sc.cmd.rp_base = (1 << cfg.ADDR_W) + 0x1000
    if (1 << cfg.ADDR_W) + 0x1000 < (1 << 48):
        out.append(sc)
    # permissions: every array, the x extent, tenants
    full = [(0, 0, TBL_BASE, TBL_SIZE, 1, 1), (0, 1, RP_BASE, 0x4000, 1, 1), (0, 2, CI_BASE, 0x6000, 1, 1), (0, 3, VAL_BASE, 0x6000, 1, 1)]
    out.append(csr("f3c_perm_ok_split_regions", cfg, rows=rows, ncols=50, regions=full))
    out.append(csr("f3c_perm_no_rp", cfg, rows=rows, ncols=50, regions=[r for r in full if r[1] != 1]))
    out.append(csr("f3c_perm_no_ci", cfg, rows=rows, ncols=50, regions=[r for r in full if r[1] != 2]))
    out.append(csr("f3c_perm_no_val", cfg, rows=rows, ncols=50, regions=[r for r in full if r[1] != 3]))
    out.append(csr("f3c_perm_no_val_gather_ok", cfg, rows=rows, ncols=50, regions=[r for r in full if r[1] != 3], op=M.OP_CSR_GATHER, E=4))
    out.append(csr("f3c_perm_no_x", cfg, rows=rows, ncols=50, regions=[r for r in full if r[1] != 0]))
    out.append(csr("f3c_perm_rp_write_only", cfg, rows=rows, ncols=50, regions=[(0, 0, TBL_BASE, TBL_SIZE, 1, 1), (0, 1, RP_BASE, 0x4000, 0, 1), (0, 2, CI_BASE, 0x6000, 1, 1), (0, 3, VAL_BASE, 0x6000, 1, 1)]))
    out.append(csr("f3c_perm_x_too_short", cfg, rows=rows, ncols=50, regions=[(0, 0, TBL_BASE, 40, 1, 1)] + full[1:]))     # extent crosses the region end
    out.append(csr("f3c_perm_x_exact", cfg, rows=rows, ncols=50, regions=[(0, 0, TBL_BASE, 50, 1, 1)] + full[1:]))
    out.append(csr("f3c_perm_x_exact_E4", cfg, rows=rows, ncols=50, E=4, op=M.OP_CSR_GATHER, regions=[(0, 0, TBL_BASE, 200, 1, 1)] + full[1:]))
    out.append(csr("f3c_perm_x_one_short_E4", cfg, rows=rows, ncols=50, E=4, op=M.OP_CSR_GATHER, regions=[(0, 0, TBL_BASE, 199, 1, 1)] + full[1:]))
    out.append(csr("f3c_perm_spoof", cfg, rows=rows, ncols=50, dom=1, allow=0b0001,
                   regions=[(1, 0, TBL_BASE, TBL_SIZE, 1, 1), (1, 1, RP_BASE, 0x4000, 1, 1), (1, 2, CI_BASE, 0x6000, 1, 1), (1, 3, VAL_BASE, 0x6000, 1, 1)]))
    out.append(csr("f3c_perm_tenant_ok", cfg, rows=rows, ncols=50, dom=2, allow=0b0100,
                   regions=[(2, 0, TBL_BASE, TBL_SIZE, 1, 1), (2, 1, RP_BASE, 0x4000, 1, 1), (2, 2, CI_BASE, 0x6000, 1, 1), (2, 3, VAL_BASE, 0x6000, 1, 1)]))
    # ---- memory-side errors on each array and on x
    def beat(addr):
        return addr >> 4
    out.append(csr("f3c_memerr_rp0", cfg, rows=rows, ncols=50, err_beats={beat(RP_BASE): 7}))
    out.append(csr("f3c_memerr_rp_mid", cfg, rows=[1] * 40, ncols=50, err_beats={beat(RP_BASE + 4 * 22): 7}))
    out.append(csr("f3c_memerr_ci", cfg, rows=[1] * 40, ncols=50, err_beats={beat(CI_BASE + 4 * 17): 10}))
    out.append(csr("f3c_memerr_val", cfg, rows=[1] * 40, ncols=50, err_beats={beat(VAL_BASE + 21): 7}))
    out.append(csr("f3c_memerr_val_gather_ignored", cfg, rows=[1] * 40, ncols=50, op=M.OP_CSR_GATHER, E=1, err_beats={beat(VAL_BASE + 21): 7}))
    for op in (M.OP_CSR_GATHER, M.OP_CSR_SPMV):
        sc = csr(f"f3c_memerr_x_{op}", cfg, rows=[2, 3, 0, 2, 4, 3], ncols=300, op=op, E=1, cols=[10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140],
                 )
        sc.err_beats = {beat(TBL_BASE + 70): 7}
        out.append(sc)
    # ---- row pointers exactly at the nnz boundary (nnz = 14): a middle pointer == nnz is legal (the rows behind it are empty),
    #      == nnz + 1 is not, and the walker must not read the column index at position nnz
    rows14 = [3, 0, 4, 2, 5]
    for op, tag in ((M.OP_CSR_SPMV, "spmv"), (M.OP_CSR_GATHER, "gather")):
        out.append(csr(f"f3c_rp_mid_eq_nnz_{tag}", cfg, rows=rows14, ncols=50, op=op, E=1, rp=[0, 3, 3, 14, 14, 14]))
        out.append(csr(f"f3c_rp_mid_nnz_plus1_{tag}", cfg, rows=rows14, ncols=50, op=op, E=1, rp=[0, 3, 3, 15, 14, 14]))
        out.append(csr(f"f3c_rp_mid_nnz_plus1_b_{tag}", cfg, rows=rows14, ncols=50, op=op, E=1, rp=[0, 3, 3, 7, 15, 15]))
    # ---- arrays that start mid-beat inside regions that end exactly where the arrays end: every reader may request only its
    #      own bytes (the link byte monitor of the bench checks every byte on the link)
    for op, tag, E in ((M.OP_CSR_SPMV, "spmv", 1), (M.OP_CSR_GATHER, "gather", 4)):
        for ci_w, ci_off in ((2, 8), (1, 2), (0, 3)):
            rows = [4, 0, 5, 2, 6]
            nnz = sum(rows)
            sc = csr(f"f3c_tight_{tag}_ciw{ci_w}", cfg, rows=rows, ncols=50, op=op, E=E, ci_w=ci_w,
                     rp_base=RP_BASE + 4, ci_base=CI_BASE + ci_off, val_base=VAL_BASE + 3)
            sc.regions = [(0, 0, TBL_BASE, 50 * E, 1, 1), (0, 1, RP_BASE + 4, 4 * (len(rows) + 1), 1, 0),
                          (0, 2, CI_BASE + ci_off, nnz << ci_w, 1, 0), (0, 3, VAL_BASE + 3, nnz, 1, 0)]
            out.append(sc)
    return out


def csr_ovf_suite(cfg: M.Cfg) -> List[Scenario]:
    """Saturation / wrap behaviour of the SpMV accumulator (built with a narrow SPMV_ACC_W, see run_regression)."""
    out: List[Scenario] = []
    rngw = random.Random(4242)
    maxk = (1 << (cfg.SPMV_ACC_W - 15)) - 1                      # exact for up to this many INT8 products per row
    big = [-128 & 0xFF] * (maxk + 40)
    # x = -128, val = -128: every product is +16384
    sc = csr("o3_sat_pos", cfg, rows=[maxk + 40, 3], ncols=4, cols=[0] * (maxk + 40) + [0, 1, 2], vals=big + [1, 2, 3])
    put_bytes(sc.mem, TBL_BASE, bytes([0x80, 0x80, 0x80, 0x80]))
    out.append(sc)
    # mixed signs: saturate high, then come back down (the clamp, not the exact sum, is carried on)
    sc = csr("o3_sat_then_negative", cfg, rows=[maxk + 5 + 60], ncols=2,
             cols=[0] * (maxk + 5) + [1] * 60, vals=[0x80] * (maxk + 5) + [0x7F] * 60)
    put_bytes(sc.mem, TBL_BASE, bytes([0x80, 0x80]))           # x0 = x1 = -128
    out.append(sc)
    # negative saturation
    sc = csr("o3_sat_neg", cfg, rows=[maxk + 50], ncols=1, cols=[0] * (maxk + 50), vals=[0x7F] * (maxk + 50))
    put_bytes(sc.mem, TBL_BASE, bytes([0x80]))
    out.append(sc)
    # exactly at the exact bound: no overflow flagged
    sc = csr("o3_exact_bound_no_ovf", cfg, rows=[maxk], ncols=1, cols=[0] * maxk, vals=[0x80] * maxk)
    put_bytes(sc.mem, TBL_BASE, bytes([0x80]))
    out.append(sc)
    sc = csr("o3_one_past_bound_ovf", cfg, rows=[maxk + 1], ncols=1, cols=[0] * (maxk + 1), vals=[0x80] * (maxk + 1))
    put_bytes(sc.mem, TBL_BASE, bytes([0x80]))
    out.append(sc)
    # rows after an overflowed row are independent (clear-and-load), the flag stays sticky for the command
    sc = csr("o3_independent_rows", cfg, rows=[maxk + 3, 4, 0, 5], ncols=1, cols=[0] * (maxk + 12), vals=[0x80] * (maxk + 3) + [1, 2, 3, 4] + [5] * 5)
    put_bytes(sc.mem, TBL_BASE, bytes([0x80]))
    out.append(sc)
    if cfg.SPMV_ACC_W == 32 and cfg.SPMV_SATURATE:
        # the real 32-bit lane: 131071 products of (+16384) are exact, the 131072nd leaves the range
        big_regions = [(0, 0, TBL_BASE, TBL_SIZE, 1, 1), (0, 1, 0x80000, 0x80000, 1, 1)]
        for ln, nm in ((131071, "exact"), (131072, "ovf"), (131075, "ovf_more")):
            sc = csr(f"o3_acc32_row_{nm}", cfg, rows=[ln, 2], ncols=4, ci_w=0, cols=[0] * (ln + 2), vals=[0x80] * ln + [3, 4],
                     ci_base=0xA8000, val_base=0xD0000, regions=big_regions, knobs=dict(lat=2))
            put_bytes(sc.mem, TBL_BASE, bytes([0x80, 0x01, 0x02, 0x03]))
            out.append(sc)
    # random small rows never overflow
    out.append(csr("o3_random_no_ovf", cfg, rows=rand_rows(rngw, 60, 12, 0.2), ncols=100))
    # extreme single products
    out.append(csr("o3_extremes", cfg, rows=[2, 2], ncols=3, cols=[0, 1, 0, 2], vals=[0x80, 0x7F, 0x80, 0x7F]))
    return out


def nc_suite(cfg: M.Cfg) -> List[Scenario]:
    """cacheable = 0 (ALP NORMAL_NC: bypass in a cache): same results, different path."""
    out: List[Scenario] = []
    rngw = random.Random(555)
    for E in (4, 16, 64):
        out.append(gather(f"nc_gather_E{E}", cfg, E=E, idx=[rngw.randrange(400) for _ in range(80)], cacheable=0))
        out.append(scatter(f"nc_scatter_E{E}", cfg, E=E, idx=[rngw.randrange(60) for _ in range(80)], cacheable=0))
    out.append(csr("nc_spmv", cfg, rows=rand_rows(rngw, 40, 6, 0.2), ncols=120, cacheable=0))
    out.append(csr("nc_csr_gather", cfg, rows=rand_rows(rngw, 40, 6, 0.2), ncols=120, op=M.OP_CSR_GATHER, E=4, cacheable=0))
    a = scatter("nc_chain_scatter", cfg, E=8, idx=list(range(40)), cacheable=0)
    b = gather("nc_chain_readback", cfg, E=8, idx=list(range(40)), cacheable=0)
    c = gather("nc_chain_readback_cached", cfg, E=8, idx=list(range(40)), cacheable=1)   # cached read after uncached writes
    out += chain([a, b, c])
    return out


def write_suite(suite: str, outfile: str, cfg: M.Cfg, group: Optional[str] = None) -> int:
    builders = {"stage1": stage1_suite, "faults": stage1_fault_suite, "chains": chain_suite, "stage2": stage2_suite, "scatter": stage3_scatter_suite, "chain3": chain3_suite, "csr": csr_suite, "csrovf": csr_ovf_suite, "nc": nc_suite}
    scs = builders[suite](cfg)
    if group:
        scs = [s for s in scs if s.group == group]
    with open(outfile, "w") as f:
        for sc in scs:
            emit(f, sc, run_model(sc))
    return len(scs)


if __name__ == "__main__":
    suite, outfile = sys.argv[1], sys.argv[2]
    cfg = M.Cfg()
    for flag, attr in (("--addr-w", "ADDR_W"), ("--max-elem", "MAX_ELEM_BYTES"), ("--obuf", "OBUF_BYTES"),
                       ("--ibuf", "IBUF_BYTES"), ("--rob", "ROB_DEPTH"), ("--acc-w", "SPMV_ACC_W")):
        if flag in sys.argv:
            setattr(cfg, attr, int(sys.argv[sys.argv.index(flag) + 1]))
    if "--err-line" in sys.argv:
        cfg.ERR_LINE_BEATS = int(sys.argv[sys.argv.index("--err-line") + 1])
    if "--wrap" in sys.argv:
        cfg.SPMV_SATURATE = False
    if "--no-csr" in sys.argv:
        cfg.CSR_EN = False
    if "--no-spmv" in sys.argv:
        cfg.SPMV_EN = False
    cfg.CHK_LW = min(cfg.CHK_LW, cfg.ADDR_W)       # the engine clamps the checker's length field to the address width
    grp = sys.argv[sys.argv.index("--group") + 1] if "--group" in sys.argv else None
    print(f"{write_suite(suite, outfile, cfg, grp)} scenarios -> {outfile}")
