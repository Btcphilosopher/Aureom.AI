# Provenance of vendored third-party files

All files below are **byte-identical copies, unmodified**, of members of archives in the SilicaFlux repository (`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`). `SHA256SUMS` lists the full digests; `scripts/check_third_party.py` re-checks them.

81 files; comparison with the archive originals: **81 identical, 0 not identical / not found**

| component | archive | files | compared |
|---|---|---|---|
| AlbionCore 0.1.0: ALP v1 package; link / channel checkers (tests only) | `silicaflux-cacheforge-p106.zip` | 6 | 6 identical |
| CacheForge P106 RTL (testbench / benchmarks) | `silicaflux-cacheforge-p106.zip` | 11 | 11 identical |
| SRAMMacroBridge P79 (CacheForge's RAM wrapper) | `silicaflux-cacheforge-p106.zip` | 17 | 17 identical |
| MemoryGuard P104: package, checker (ingress), region table (testbench) | `silicaflux-memoryguard-p104.zip` | 3 | 3 identical |
| TensorCore 01 tensor_pe: the SpMV arithmetic lane | `silicaflux-tensorcore01-tensor_pe.zip` | 2 | 2 identical |
| TensorScratch P75 (adapter testbench) | `silicaflux-tensorscratch-p75.zip` | 42 | 42 identical |

## Files

| vendored file | source member | sha256 (first 16) | vs archive |
|---|---|---|---|
| `albioncore/rtl/sf_albion_fifo.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/albioncore/rtl/sf_albion_fifo.sv` | `04d4782aa436b6b2` | identical |
| `albioncore/rtl/sf_albion_pkg.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/albioncore/rtl/sf_albion_pkg.sv` | `0126952bb99f2b5d` | identical |
| `albioncore/rtl/sf_albion_regslice.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/albioncore/rtl/sf_albion_regslice.sv` | `e84d941fa061f42b` | identical |
| `albioncore/rtl/sf_albion_skid.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/albioncore/rtl/sf_albion_skid.sv` | `46fd1b45ac2a0717` | identical |
| `albioncore/tests/sf_albion_chan_checker.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/albioncore/tests/sf_albion_chan_checker.sv` | `25b7c8efc0418acd` | identical |
| `albioncore/tests/sf_albion_link_checker.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/albioncore/tests/sf_albion_link_checker.sv` | `9c8ecaff4c532908` | identical |
| `cacheforge/rtl/cache/sf_cache_addr.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_addr.sv` | `71ae5371283767a2` | identical |
| `cacheforge/rtl/cache/sf_cache_data_array.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_data_array.sv` | `bc51dfa44e78957b` | identical |
| `cacheforge/rtl/cache/sf_cache_memport.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_memport.sv` | `8a34e28386477a93` | identical |
| `cacheforge/rtl/cache/sf_cache_mshr.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_mshr.sv` | `5d29f12044e194c5` | identical |
| `cacheforge/rtl/cache/sf_cache_perf.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_perf.sv` | `fe243b91f9ce56be` | identical |
| `cacheforge/rtl/cache/sf_cache_pkg.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_pkg.sv` | `68e210b49be693f8` | identical |
| `cacheforge/rtl/cache/sf_cache_refill.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_refill.sv` | `ef14060b14438f05` | identical |
| `cacheforge/rtl/cache/sf_cache_replacement.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_replacement.sv` | `3ea858bed68ff729` | identical |
| `cacheforge/rtl/cache/sf_cache_tag_array.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_tag_array.sv` | `23601e7840133752` | identical |
| `cacheforge/rtl/cache/sf_cache_writeback.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_cache_writeback.sv` | `4fdf650e5964f5b3` | identical |
| `cacheforge/rtl/cache/sf_llc_cache.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/rtl/cache/sf_llc_cache.sv` | `fe065373b0e7eb32` | identical |
| `cacheforge/third_party/srammacrobridge/files.f.orig` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/files.f.orig` | `e866fc895502073a` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/sf_sram_macro_defs.svh` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/sf_sram_macro_defs.svh` | `92a2575eac9d7409` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/sf_sram_macro_funcs.svh` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/sf_sram_macro_funcs.svh` | `2c7b81becacb03ce` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/sf_sram_macro_ids.svh` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/sf_sram_macro_ids.svh` | `c90d803915c0568b` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/sf_sram_macro_wrapper.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/sf_sram_macro_wrapper.sv` | `33ece897d1d69e18` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_array_body.svh` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_array_body.svh` | `704adeb6ecf32d6e` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_array_init.svh` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_array_init.svh` | `3c3866c0a6c594b0` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_be_asic.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_be_asic.sv` | `6532cef30d9b9f27` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_be_fpga.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_be_fpga.sv` | `3166829d8edaa956` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_be_generic.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/backends/sf_sram_be_generic.sv` | `e1c74ed6c47be5e6` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_gf180.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_gf180.sv` | `c47fd44a13e60716` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_ihp1p.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_ihp1p.sv` | `de98879a08c8e8ba` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_sky130.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/backends/asic/sf_sram_leaf_sky130.sv` | `619933b700a38eaf` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/backends/asic/stubs/sf_sram_macro_blackboxes.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/backends/asic/stubs/sf_sram_macro_blackboxes.sv` | `0d5852fcfdbe31e7` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/ecc/sf_ecc_h.svh` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/ecc/sf_ecc_h.svh` | `48c16d3114172730` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_dec.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_dec.sv` | `9b97187ca14a8060` | identical |
| `cacheforge/third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_enc.sv` | `silicaflux-cacheforge-p106.zip:silicaflux-cacheforge/third_party/srammacrobridge/rtl/ecc/sf_ecc_secded_enc.sv` | `4e086f22b436d307` | identical |
| `memory_guard/sf_memory_guard_checker.sv` | `silicaflux-memoryguard-p104.zip:silicaflux-memoryguard-p104/rtl/memory_guard/sf_memory_guard_checker.sv` | `157e4be2c0728fcf` | identical |
| `memory_guard/sf_memory_guard_pkg.sv` | `silicaflux-memoryguard-p104.zip:silicaflux-memoryguard-p104/rtl/memory_guard/sf_memory_guard_pkg.sv` | `647ef1f6a82e9872` | identical |
| `memory_guard/sf_memory_guard_regions.sv` | `silicaflux-memoryguard-p104.zip:silicaflux-memoryguard-p104/rtl/memory_guard/sf_memory_guard_regions.sv` | `d2e39640f4345624` | identical |
| `tensorcore01/tensor_pe.sv` | `silicaflux-tensorcore01-tensor_pe.zip:silicaflux-tensorcore01/rtl/tensor_pe.sv` | `7ea83632e953a01c` | identical |
| `tensorcore01/tensor_pe_pkg.sv` | `silicaflux-tensorcore01-tensor_pe.zip:silicaflux-tensorcore01/rtl/tensor_pe_pkg.sv` | `280125c16889e4d7` | identical |
| `tensorscratch/rtl/sf_tensor_scratchpad.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_tensor_scratchpad.sv` | `4514092dfd3e84db` | identical |
| `tensorscratch/rtl/sf_ts_abuf_ctrl.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_abuf_ctrl.sv` | `28e6fb4a04593e26` | identical |
| `tensorscratch/rtl/sf_ts_accbuf.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_accbuf.sv` | `f0c0641e63695921` | identical |
| `tensorscratch/rtl/sf_ts_agu.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_agu.sv` | `23d4361bd5caf39d` | identical |
| `tensorscratch/rtl/sf_ts_bank.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_bank.sv` | `2a1a9331f7cce2de` | identical |
| `tensorscratch/rtl/sf_ts_bankgrp.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_bankgrp.sv` | `e162f26287912ef0` | identical |
| `tensorscratch/rtl/sf_ts_bbuf_ctrl.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_bbuf_ctrl.sv` | `66077e43813b832f` | identical |
| `tensorscratch/rtl/sf_ts_dbuf_ctrl.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_dbuf_ctrl.sv` | `22177360161012b0` | identical |
| `tensorscratch/rtl/sf_ts_defs.svh` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_defs.svh` | `f13c27977af32eac` | identical |
| `tensorscratch/rtl/sf_ts_dma_port.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_dma_port.sv` | `3d56fee4e31a49b8` | identical |
| `tensorscratch/rtl/sf_ts_perf.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_perf.sv` | `b9106ddb3141074b` | identical |
| `tensorscratch/rtl/sf_ts_slice.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_slice.sv` | `74c4fe36f5e74be9` | identical |
| `tensorscratch/rtl/sf_ts_stream.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/rtl/sf_ts_stream.sv` | `f6097bd35c278594` | identical |
| `tensorscratch/sim/files_acc.f` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/sim/files_acc.f` | `1d481d2fea3c01da` | identical |
| `tensorscratch/sim/files_mc.f` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/sim/files_mc.f` | `e851ad5e65584cab` | identical |
| `tensorscratch/sim/files_rtl.f` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/sim/files_rtl.f` | `d5b6c736304a722b` | identical |
| `tensorscratch/sim/files_sys.f` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/sim/files_sys.f` | `ec72e075bdad9916` | identical |
| `tensorscratch/sim/files_tc.f` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/sim/files_tc.f` | `15617009dfc61907` | identical |
| `tensorscratch/third_party/memorycore/ras_secded/sfras_defs.svh` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/ras_secded/sfras_defs.svh` | `af06beb45166e3f7` | identical |
| `tensorscratch/third_party/memorycore/ras_secded/sfras_ecc_funcs.svh` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/ras_secded/sfras_ecc_funcs.svh` | `b34b9d923e5f6422` | identical |
| `tensorscratch/third_party/memorycore/ras_secded/sfras_secded_dec.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/ras_secded/sfras_secded_dec.sv` | `571840dcb0f9c494` | identical |
| `tensorscratch/third_party/memorycore/ras_secded/sfras_secded_enc.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/ras_secded/sfras_secded_enc.sv` | `19cae462eb4c9b7f` | identical |
| `tensorscratch/third_party/memorycore/rtl/sf_ecc_counters.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/sf_ecc_counters.sv` | `07de0b6c472b9ad1` | identical |
| `tensorscratch/third_party/memorycore/rtl/sf_ecc_dec.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/sf_ecc_dec.sv` | `50421b82eb5b4ae9` | identical |
| `tensorscratch/third_party/memorycore/rtl/sf_ecc_enc.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/sf_ecc_enc.sv` | `7cd6a8e3b7c8b180` | identical |
| `tensorscratch/third_party/memorycore/rtl/sf_sram_bank.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/sf_sram_bank.sv` | `3c26e2e21ffdaba9` | identical |
| `tensorscratch/third_party/memorycore/rtl/sf_sram_core.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/sf_sram_core.sv` | `69e07e344f8612e3` | identical |
| `tensorscratch/third_party/memorycore/rtl/sf_sram_defs.svh` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/sf_sram_defs.svh` | `a89cb8824f394ee5` | identical |
| `tensorscratch/third_party/memorycore/rtl/sf_sram_macro_wrapper.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/sf_sram_macro_wrapper.sv` | `0e76b94249eec647` | identical |
| `tensorscratch/third_party/memorycore/rtl/sf_sync_fifo.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/sf_sync_fifo.sv` | `c4760dfb1e41811a` | identical |
| `tensorscratch/third_party/memorycore/rtl/backends/sf_sram_asic_sky130.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/backends/sf_sram_asic_sky130.sv` | `25419e9ad3771358` | identical |
| `tensorscratch/third_party/memorycore/rtl/backends/sf_sram_fpga_bram.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/memorycore/rtl/backends/sf_sram_fpga_bram.sv` | `ee5d91ed07e9bcae` | identical |
| `tensorscratch/third_party/tensorcore02/rtl/tensor_output_collect.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore02/rtl/tensor_output_collect.sv` | `ae2bf95f200152b8` | identical |
| `tensorscratch/third_party/tensorcore02/rtl/tensor_pe.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore02/rtl/tensor_pe.sv` | `f931027f5c65b87b` | identical |
| `tensorscratch/third_party/tensorcore02/rtl/tensor_skew.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore02/rtl/tensor_skew.sv` | `a69f279fa282f22e` | identical |
| `tensorscratch/third_party/tensorcore02/rtl/tensor_systolic_array.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore02/rtl/tensor_systolic_array.sv` | `07be2f4be73cb018` | identical |
| `tensorscratch/third_party/tensorcore04/rtl/tensor_acc_fifo.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore04/rtl/tensor_acc_fifo.sv` | `063393ee2000a3d5` | identical |
| `tensorscratch/third_party/tensorcore04/rtl/tensor_acc_out_router.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore04/rtl/tensor_acc_out_router.sv` | `12c387c028ef6c69` | identical |
| `tensorscratch/third_party/tensorcore04/rtl/tensor_acc_pkg.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore04/rtl/tensor_acc_pkg.sv` | `839c395a324a1e04` | identical |
| `tensorscratch/third_party/tensorcore04/rtl/tensor_acc_storage.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore04/rtl/tensor_acc_storage.sv` | `e0927b856835f207` | identical |
| `tensorscratch/third_party/tensorcore04/rtl/tensor_acc_subsystem.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore04/rtl/tensor_acc_subsystem.sv` | `6dadcd3e2d4bd14b` | identical |
| `tensorscratch/third_party/tensorcore04/rtl/tensor_accumulator.sv` | `silicaflux-tensorscratch-p75.zip:silicaflux-tensorscratch-p75/third_party/tensorcore04/rtl/tensor_accumulator.sv` | `bb1cce9bee4eed62` | identical |
