# 08 — Limitations: what this package does not do, claim or prove

Read this before relying on anything else. It is deliberately specific.

## 1. Scope of the claims

* **Evidence is RTL simulation (Verilator 5.49), a reference-model comparison, a mutation campaign and generic Yosys statistics.**
  There is **no FPGA, no silicon, no PDK, no static timing, no area, no power**, and **no formal proof**. Nothing in the repository
  can say how fast this engine would run or how big it would be on a real process. Cycle counts are simulation cycles against a
  *model* memory whose latency is a parameter.
* **"Sparse neural-network acceleration" is not claimed.** The engine prepares and moves sparse data (indexed gather / scatter,
  CSR traversal) and, optionally, computes one INT8 sparse matrix-vector product on the existing arithmetic lane. It implements
  no activation, quantisation, pruning, sparse convolution, attention or training arithmetic.
* The verification was written by the author of the RTL. The Python model is independent *code* (no shared source with the RTL
  or the bench; written from `docs/02`) but not an independent *author*. The mutation campaign (docs/05 §5) is the check that the tests can
  fail, not a proof that they cover everything.

## 2. Functional limits

| limit | detail |
|---|---|
| one command at a time | no queue, no overlap of commands, **no abort** (reset only) |
| element sizes | `E ∈ {1,2,4,8}` or a multiple of 16, ≤ `MAX_ELEM_BYTES`; **natural alignment required** (no straddling elements, no arbitrary-byte element sizes such as 12 or 24) |
| index width | 8 / 16 / 32 bit; counts up to 2³²−1; negative signed indices are faults (no backwards offsets) |
| extents | an array of 2^`CHK_LW` bytes (1 GiB by default) or more is refused up front; split larger arrays |
| CSR | `row_ptr` is uint32; column indices 8/16/32 bit; values INT8 for arithmetic (INT16 / INT32 / FP32-raw are only *accepted* and traversed, not multiplied); `CSR_GATHER` does not read values |
| SpMV | INT8×INT8→INT32 only, 1 MAC/cycle, sequential reduction; no FP32, no sparse-sparse, no SpMM |
| scatter | **no atomics and no scatter-add**; duplicates are last-writer-wins by element order. Memory-side write errors leave later elements' effect unspecified (docs/02 §4.2) |
| faults | `fault_addr` is set only for permission faults and scatter write errors; index-array read errors report `SF_ST_TARGET_ERR` rather than the target's actual status |
| local buffers | plain RAMs: the host must not write `IBUF` during a scatter nor expect `OBUF` contents beyond the delivered prefix after a fault; neither is cleared by reset |

## 3. Protocol and integration limits

* **ALP v1 is in-order; out-of-order completion is outside the protocol.** The engine tolerates it (and the reorder structure is
  verified against a target that does it), but **CacheForge is in-order and blocking**, so the reordering is *not* exercised against any
  real SilicaFlux block — only against the testbench's target model. A real out-of-order target would need an ALP profile that allows it.
* **No coherence.** Visibility around a command is software-managed (docs/04 §4). There is no CoherenceDirectory in the repository.
* **DataFabric (SFB2) is not connected** and no bridge was written; MemoryMatrix and StreamDMA are not instantiated; AtomicEngine is not integrated.
* **CacheForge** was exercised only with an **in-order** memory behind it, with `ADDR_W ≥ 32` (its `PADDR_W` range), with the default
  line size and associativity, and with 1, 2 and 4 MSHRs. ECC injection and the cache's own maintenance sequences beyond
  "clean and invalidate all" were not exercised.
* **MemoryGuard:** only the **checker** is on the engine's ingress. Changing the region table while a command runs is outside the
  contract (change it while `busy_o` is low). The engine does not implement MemoryGuard's drain-then-commit handshake; it exposes `busy_o` only.
  The protection model is protection, not translation.
* **Beat granularity.** The bytes the engine requests are exactly the bytes it validated (byte enables), but a target that
  ignores byte enables, or a cache refilling a whole line, touches neighbouring bytes below the interface; the engine neither
  causes nor can prevent that.
* **TensorScratch adapter:** verified against the scratchpad's fill port and its **slice stream**. A full GEMM through the systolic
  array and accumulator (TENSORCORE 02/04) was **not** run with gathered operands; the ownership and layout contract is the evidence.

## 4. Performance limits

* The default `NRT = 16` / `ROB_DEPTH = 32` cap 64-byte-row gathers at ~0.11 elements/cycle at latency 30; the 32/64 configuration
  reaches ~0.22. They are not tuned.
* **Hot spot, not optimised:** the request coalescer is about half of the logic and has the longest combinational path (docs/07 gives the exact figures). No timing
  closure was attempted; **no frequency is claimed**.
* Benchmarks use one table layout, one cache configuration, one seed per workload, and a fixed-latency target; they show *relative*
  behaviour (and where caching helps or hurts) under those assumptions, nothing absolute.
* The bank-conflict figure from the engine is an **estimator** (requests whose bank, beat mod 4, already had one in flight), not a
  measurement of any real memory.

## 5. Verification limits

* No formal verification, no coverage-driven closure metric (code / functional coverage was not collected), no gate-level or
  multi-simulator cross-check (Verilator only; Yosys elaborates and synthesises the RTL).
* Random scenarios use fixed seeds; each is reproducible but the space is sampled, not exhausted (docs/05 lists what was sampled).
* **`SP_F_BAD_CMD` is reserved in the package and never produced** (every malformed command has a more specific code), so it is not covered.
* **`SP_F_PROTO` is covered only for the detectable cases** (docs/02 §7): a rogue response with an out-of-range or idle-entry tag is
  provoked by the out-of-order bench target (`s2_rogue_*`). A stray response that carries the tag of a live entry or of an
  index / CSR reader slot is **not detected** — the readers and the outstanding counters trust the link — and no test exercises it.
* The mutation campaign plants **single textual defects** (43; 41 killed). **Two survive** (`co_err_data`, `spmv_emit`); both are *argued* to be equivalent to the
  original on every reachable input (docs/05 §5), which is a code-reading argument backed by a bench invariant, **not a proof**. The first campaign's real gaps were closed with new tests;
  a mutation score says the tests can fail on these 43 defects, not that no other defect escapes.
* The configuration sweep covers address widths 24/32/40/48, `NRT` 2…32, `ROB_DEPTH` 4…64, reader sizing, buffer sizes and three cache
  configurations — not the full cross product.

## 6. Packaging

* This is a **plain archive; nothing was committed to GitHub.** No `.git` directory.
* The vendored third-party files are byte-identical to the repository's archives (SHA-256 in `third_party/PROVENANCE.md`); two of
  them (`sf_albion_pkg.sv` and friends) also appear inside CacheForge's package and were compared against it.
