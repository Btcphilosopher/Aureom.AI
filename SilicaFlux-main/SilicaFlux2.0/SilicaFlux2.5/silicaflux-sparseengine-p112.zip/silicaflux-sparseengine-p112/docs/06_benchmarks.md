# 06 — Benchmarks

**Everything here is RTL-simulation clock cycles** of `tb/tb_sparse.sv`. The memory is a *model* whose latency is a parameter (30 cycles unless stated); no figure is a claim about any real DRAM, HBM or silicon, and no wall-clock, energy or frequency figure is given. **Every benchmark run is also a correctness run:** the same scenario is checked byte-for-byte against the Python reference, and a number is reported only if the run passed (144 of 144 runs passed).

Reproduce: `make bench` (about 10 minutes on 4 cores). Raw data: `benchmarks/results/bench.csv` / `.json`.

## 1. Systems and workloads

| system | memory path | notes |
|---|---|---|
| `direct_moN` | engine → target, ≤ N requests outstanding | `NRT = 16`, `ROB_DEPTH = 32` (defaults) |
| `direct_mo32_big` | engine → target, ≤ 32 outstanding | `NRT = 32`, `ROB_DEPTH = 64` |
| `banked8_big` | engine → 8-bank target, service 4 cycles/request, completes **out of order** | `NRT = 32`, `ROB_DEPTH = 64` |
| `cache_blk` | engine → CacheForge (32 KiB, 4-way, 64 B lines, **1 MSHR = blocking**) → memory | cache advertises 1 outstanding |
| `cache_mshr4` | engine → CacheForge with 4 MSHRs → memory | cache advertises 8 outstanding |

| workload | description |
|---|---|
| `seq_E64` | gather 64-byte rows, sequential indices (table 128 KiB) |
| `rand_big_E64` | 64-byte rows, uniform random over 128 KiB (4x the cache) |
| `rand_fit_E64` | 64-byte rows, uniform random over 16 KiB (fits the cache) |
| `zipf_E64` | 64-byte rows, 80% of accesses to 32 hot rows |
| `stride4k_E64` | 64-byte rows at a 4 KiB stride (cache set conflicts) |
| `repeat4_E64` | each random row requested 4 times in a row |
| `seq_E4` | 4-byte elements, sequential |
| `rand_big_E4` | 4-byte elements, uniform random over 256 KiB |
| `scatter_rand_E64` | scatter 64-byte rows, random |
| `scatter_dup_E64` | scatter with many duplicate destinations (128 rows) |
| `spmv_cachefit` | SpMV, ~8 nnz/row, x vector 4 KiB |
| `spmv_cachehostile` | SpMV, ~8 nnz/row, x vector 200 KB (random columns) |

## 2. Elements per cycle (memory latency 30)

`elements / command cycles`; an element is one gathered/scattered row or one SpMV nonzero, command cycles include decode, validation and drain.

| workload | direct_mo1 | direct_mo4 | direct_mo16 | direct_mo32 | direct_mo32_big | banked8_big | cache_blk | cache_mshr4 |
|---|---|---|---|---|---|---|---|---|
| `seq_E64` | 0.008 | 0.030 | 0.110 | 0.111 | 0.219 | 0.213 | 0.014 | 0.015 |
| `rand_big_E64` | 0.008 | 0.030 | 0.113 | 0.111 | 0.219 | 0.215 | 0.015 | 0.017 |
| `rand_fit_E64` | 0.008 | 0.031 | 0.112 | 0.112 | 0.220 | 0.216 | 0.024 | 0.028 |
| `zipf_E64` | 0.008 | 0.033 | 0.116 | 0.116 | 0.226 | 0.221 | 0.026 | 0.030 |
| `stride4k_E64` | 0.008 | 0.030 | 0.110 | 0.111 | 0.219 | 0.214 | 0.014 | 0.015 |
| `repeat4_E64` | 0.026 | 0.103 | 0.225 | 0.225 | 0.245 | 0.245 | 0.049 | 0.059 |
| `seq_E4` | 0.065 | 0.258 | 0.454 | 0.454 | 0.454 | 0.454 | 0.119 | 0.188 |
| `rand_big_E4` | 0.026 | 0.103 | 0.410 | 0.442 | 0.454 | 0.446 | 0.021 | 0.062 |
| `scatter_rand_E64` | 0.008 | 0.030 | 0.115 | 0.114 | 0.225 | 0.222 | 0.013 | 0.014 |
| `scatter_dup_E64` | 0.008 | 0.031 | 0.113 | 0.113 | 0.217 | 0.215 | 0.031 | 0.038 |
| `spmv_cachefit` | 0.025 | 0.099 | 0.383 | 0.447 | 0.447 | 0.440 | 0.076 | 0.112 |
| `spmv_cachehostile` | 0.024 | 0.096 | 0.381 | 0.442 | 0.447 | 0.439 | 0.021 | 0.062 |

## 3. What limits throughput

* **Request table, not the link.** With the default `NRT = 16` a 64-byte row (4 beats) reaches 0.111 elements/cycle whatever `maxout` is above 16; doubling `NRT`/`ROB_DEPTH` gives 0.219 = 88% of the link peak (1 request/cycle ÷ 4 beats = 0.25). Throughput ≈ min(1 request/cycle, `NRT` ÷ latency) ÷ beats per element — Little's law on the request table (latency sweep, §5). `NRT` and `ROB_DEPTH` are the sizing knobs; their defaults are not tuned for 64-byte rows at latency 30.
* **Memory-level parallelism matters more than anything else.** Going from 1 to 4 to 16 outstanding requests changes `rand_big_E64` from 0.008 to 0.030 to 0.113.
* **Sub-beat elements** are limited by the 16-byte beat, not the element: `rand_big_E4` moves 4 useful bytes per 16-byte beat (useful/link bytes = 0.2501); `seq_E4` merges four elements into one request (3072 merges) and reaches 0.454 elements/cycle.

## 4. Requests, coalescing and bursts (`direct_mo32_big`, latency 30)

| workload | elements | data requests | index requests | merges | duplicate hits | useful bytes / link bytes | beats continuing a burst | reorder occ. avg / max | peak outstanding |
|---|---|---|---|---|---|---|---|---|---|
| `seq_E64` | 1024 | 4096 | 256 | 0 | 0 | 1.0 | 100% | 30.61 / 32 | 30 |
| `rand_big_E64` | 1024 | 4084 | 256 | 0 | 12 | 1.0029 | 75% | 30.63 / 34 | 30 |
| `rand_fit_E64` | 1024 | 3988 | 256 | 0 | 108 | 1.0271 | 75% | 30.74 / 35 | 30 |
| `zipf_E64` | 1024 | 3537 | 256 | 0 | 559 | 1.158 | 75% | 31.55 / 36 | 30 |
| `stride4k_E64` | 1024 | 4096 | 256 | 0 | 0 | 1.0 | 75% | 30.61 / 32 | 30 |
| `repeat4_E64` | 1024 | 1024 | 256 | 0 | 3072 | 4.0 | 75% | 34.35 / 35 | 11 |
| `seq_E4` | 4096 | 1024 | 1024 | 3072 | 0 | 1.0 | 100% | 16.8 / 18 | 8 |
| `rand_big_E4` | 4096 | 4095 | 1024 | 0 | 1 | 0.2501 | 0% | 16.12 / 18 | 20 |
| `scatter_rand_E64` | 1024 | 4096 | 256 | 0 | 0 | 1.0 | 75% | 0.0 / 0 | 30 |
| `scatter_dup_E64` | 1024 | 4096 | 256 | 0 | 0 | 1.0 | 75% | 0.0 / 0 | 30 |
| `spmv_cachefit` | 3796 | 3776 | 1316 | 9 | 11 | 0.0628 | 0% | 15.4 / 18 | 22 |
| `spmv_cachehostile` | 3796 | 3795 | 1316 | 0 | 1 | 0.0625 | 0% | 15.4 / 18 | 22 |

*useful bytes / link bytes* = bytes delivered to the output buffer (committed, for scatter) ÷ (16 × data requests). It is 1.0 for a gather of whole beats, 0.25 for 4-byte elements that each cost a beat, **above 1 when duplicate hits avoid requests** (`repeat4_E64`: 4.0), and about 0.06 for SpMV, where only the 1-byte `x` operand counts as useful. *Beats continuing a burst* counts issued beats whose address is the previous beat + 16; ALP v1 has no bursts, so this is the measure of how many consecutive beats were issued back to back.

## 5. Memory-latency sweep

Elements per cycle; the same workloads at other memory latencies.

| workload | system | lat 10 | lat 30 | lat 100 | lat 250 |
|---|---|---|---|---|---|
| `zipf_E64` | `direct_mo1` | 0.0229 | 0.0081 | 0.0025 | 0.0010 |
| `zipf_E64` | `direct_mo32_big` | 0.2468 | 0.2258 | 0.0791 | 0.0325 |
| `zipf_E64` | `cache_blk` | 0.0301 | 0.0257 | 0.0169 | 0.0098 |
| `zipf_E64` | `cache_mshr4` | 0.0351 | 0.0302 | 0.0194 | 0.0109 |
| `rand_big_E64` | `direct_mo1` | 0.0214 | 0.0076 | 0.0023 | 0.0009 |
| `rand_big_E64` | `direct_mo32_big` | 0.2342 | 0.2190 | 0.0735 | 0.0297 |
| `rand_big_E64` | `cache_blk` | 0.0211 | 0.0153 | 0.0077 | 0.0038 |
| `rand_big_E64` | `cache_mshr4` | 0.0233 | 0.0167 | 0.0084 | 0.0040 |
| `rand_fit_E64` | `direct_mo1` | 0.0216 | 0.0077 | 0.0024 | 0.0009 |
| `rand_fit_E64` | `direct_mo32_big` | 0.2384 | 0.2198 | 0.0744 | 0.0301 |
| `rand_fit_E64` | `cache_blk` | 0.0284 | 0.0242 | 0.0159 | 0.0092 |
| `rand_fit_E64` | `cache_mshr4` | 0.0330 | 0.0284 | 0.0182 | 0.0102 |
| `rand_big_E4` | `direct_mo1` | 0.0728 | 0.0258 | 0.0079 | 0.0032 |
| `rand_big_E4` | `direct_mo32_big` | 0.7964 | 0.4542 | 0.1517 | 0.0625 |
| `rand_big_E4` | `cache_blk` | 0.0361 | 0.0214 | 0.0088 | 0.0039 |
| `rand_big_E4` | `cache_mshr4` | 0.0880 | 0.0624 | 0.0202 | 0.0082 |

## 5b. Gather / scatter / SpMV latency

*Command cycles* = cycles from command accept to completion (decode, validation, execution, drain) for the whole command. *Request latency* = the engine's own measurement from selecting a data request to receiving its response (avg / max), which includes time held in the 2-entry request FIFO and waiting for the link. Memory latency is 30 cycles.

| workload | elements | direct_mo32_big cycles | cache_blk cycles | cache_mshr4 cycles | request latency avg / max (`direct_mo32_big`) | request latency avg / max (`cache_blk`) |
|---|---|---|---|---|---|---|
| `seq_E64` | 1024 | 4681 | 73480 | 67694 | 31.1 / 32 | 50.7 / 111 |
| `rand_big_E64` | 1024 | 4676 | 67142 | 61257 | 31.1 / 32 | 46.1 / 111 |
| `rand_fit_E64` | 1024 | 4659 | 42354 | 36047 | 31.1 / 32 | 28.3 / 111 |
| `zipf_E64` | 1024 | 4534 | 39916 | 33920 | 31.1 / 32 | 28.3 / 111 |
| `stride4k_E64` | 1024 | 4681 | 73921 | 68135 | 31.1 / 32 | 51.1 / 111 |
| `repeat4_E64` | 1024 | 4174 | 20847 | 17376 | 31.0 / 32 | 54.7 / 111 |
| `seq_E4` | 4096 | 9021 | 34315 | 21815 | 31.0 / 31 | 72.6 / 102 |
| `rand_big_E4` | 4096 | 9019 | 191734 | 65649 | 31.4 / 32 | 134.3 / 189 |
| `scatter_rand_E64` | 1024 | 4556 | 82035 | 74069 | 31.1 / 32 | 56.7 / 194 |
| `scatter_dup_E64` | 1024 | 4708 | 33438 | 27085 | 31.1 / 32 | 21.9 / 109 |
| `spmv_cachefit` | 3796 | 8487 | 49950 | 34013 | 31.3 / 34 | 33.3 / 295 |
| `spmv_cachehostile` | 3796 | 8487 | 178920 | 61324 | 31.3 / 34 | 133.4 / 295 |

## 6. Cache behaviour (CacheForge counters)

| workload | system | hit rate | cache-line utilisation | misses | refills | avg miss latency | engine request latency (avg) |
|---|---|---|---|---|---|---|---|
| `seq_E64` | `cache_blk` | 0.750 | 0.9412 | 1088 | 1088 | 44.5 | 50.7 |
| `seq_E64` | `cache_mshr4` | 0.750 | 0.9412 | 1088 | 1088 | 45.5 | 59.1 |
| `rand_big_E64` | `cache_blk` | 0.786 | 1.1011 | 930 | 930 | 44.5 | 46.1 |
| `rand_big_E64` | `cache_mshr4` | 0.786 | 1.1011 | 930 | 930 | 45.5 | 53.2 |
| `rand_fit_E64` | `cache_blk` | 0.927 | 3.2611 | 314 | 314 | 44.0 | 28.3 |
| `rand_fit_E64` | `cache_mshr4` | 0.927 | 3.2611 | 314 | 314 | 45.7 | 29.9 |
| `zipf_E64` | `cache_blk` | 0.927 | 3.4712 | 295 | 295 | 44.0 | 28.3 |
| `zipf_E64` | `cache_mshr4` | 0.927 | 3.4712 | 295 | 295 | 45.8 | 29.9 |
| `stride4k_E64` | `cache_blk` | 0.750 | 0.9412 | 1088 | 1088 | 44.9 | 51.1 |
| `stride4k_E64` | `cache_mshr4` | 0.750 | 0.9412 | 1088 | 1088 | 45.9 | 59.5 |
| `repeat4_E64` | `cache_blk` | 0.762 | 3.3684 | 304 | 304 | 44.0 | 54.7 |
| `repeat4_E64` | `cache_mshr4` | 0.762 | 3.3684 | 304 | 304 | 45.1 | 60.1 |
| `seq_E4` | `cache_blk` | 0.750 | 0.5 | 512 | 512 | 44.0 | 72.6 |
| `seq_E4` | `cache_mshr4` | 0.750 | 0.5 | 512 | 512 | 46.5 | 65.9 |
| `rand_big_E4` | `cache_blk` | 0.235 | 0.0655 | 3911 | 3911 | 44.9 | 134.3 |
| `rand_big_E4` | `cache_mshr4` | 0.235 | 0.0654 | 3913 | 3913 | 64.2 | 94.3 |
| `scatter_rand_E64` | `cache_blk` | 0.785 | 1.0975 | 933 | 933 | 63.8 | 56.7 |
| `scatter_rand_E64` | `cache_mshr4` | 0.785 | 1.0975 | 933 | 933 | 65.8 | 62.3 |
| `scatter_dup_E64` | `cache_blk` | 0.955 | 5.3333 | 192 | 192 | 44.0 | 21.9 |
| `scatter_dup_E64` | `cache_mshr4` | 0.955 | 5.3333 | 192 | 192 | 45.5 | 22.3 |
| `spmv_cachefit` | `cache_blk` | 0.920 | 0.1502 | 395 | 395 | 44.1 | 33.3 |
| `spmv_cachefit` | `cache_mshr4` | 0.920 | 0.1502 | 395 | 395 | 49.3 | 36.0 |
| `spmv_cachehostile` | `cache_blk` | 0.297 | 0.0165 | 3591 | 3591 | 44.9 | 133.4 |
| `spmv_cachehostile` | `cache_mshr4` | 0.297 | 0.0165 | 3592 | 3592 | 62.4 | 92.4 |

*Hit rate* = (read + write hits) ÷ cache accesses, **index-array reads included**. A 64-byte row is four beats of one line, so a perfectly random gather already shows 75% hits (1 miss + 3 hits per row): that is spatial locality inside the element, not reuse. *Cache-line utilisation* = useful gathered bytes ÷ (64 × refills); it exceeds 1 under reuse. *Avg miss latency* is CacheForge's own counter (refill, memory latency included).

## 7. Conclusions — and what not to conclude

1. **Do not assume caching helps a sparse gather.** In this benchmark a blocking CacheForge was *slower* than a memory path that sustains many outstanding requests for **every** workload — including the skewed one (`zipf_E64`: 0.026 vs 0.226) and the cache-resident one — and the gap did not close at latency 250 (0.0098 vs 0.0325). The reasons are structural: the cache serves one request at a time (a read hit takes ~6 cycles), so it caps the engine near 0.17 requests/cycle however good the hit rate is, while the engine alone can keep `NRT` requests in flight.
2. **A cache does help when the memory path has no memory-level parallelism.** Against a one-outstanding path (`direct_mo1`, the SFB2 DataFabric case) CacheForge is faster on `zipf_E64` at every latency (0.0301 vs 0.0229 at 10 cycles, 0.0098 vs 0.0010 at 250: 10×), and on the random 64-byte gather 1.0x at latency 10, 2.0x at latency 30, 3.3x at latency 100, 4.2x at latency 250, because one line refill brings in all four beats of a row.
3. **More MSHRs help only a little here** (`cache_mshr4` vs `cache_blk`): the cache's front end still accepts requests one at a time.
4. **Where each result comes from is stated** — nothing above extrapolates beyond the model: one table layout, one cache configuration, one seed per workload, a fixed-latency target with no bank or row-buffer behaviour except in `banked8_big`.
5. **Bank conflicts.** `banked8_big` completes requests out of order (the reorder structure absorbs it: 196 responses overtook an older request on `rand_big_E64`) and costs 1.9% throughput relative to the conflict-free target. The engine's own estimator counts issued requests whose bank (beat mod 4) already had a request in flight; the target counts busy-bank accepts for its 8 banks. They use different bank counts, so they are not expected to be equal.

