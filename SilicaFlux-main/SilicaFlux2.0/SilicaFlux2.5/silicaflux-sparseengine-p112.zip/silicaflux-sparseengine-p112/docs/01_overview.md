# 01 — Overview, decisions and traceability

SilicaFlux Project 112 **SparseEngine** is a synthesizable memory engine for irregular access: indexed gather, indexed scatter,
validated CSR traversal and an optional INT8 sparse matrix-vector product. Primary RTL: `rtl/sf_sparse_memory_engine.sv`.

Build order followed (as the brief asks): **(1) integer-index gather → (2) response reordering → (3) scatter and CSR**, then cache,
tensor adapter and arithmetic. The evidence of each stage was frozen when the stage was finished and is kept in `reports/`:
`stage1_2_frozen/` (gather + reordering: 12 configurations), `stage3_frozen/` (+ scatter, CSR, SpMV), `final_regression.md` (everything, final RTL).

## 1. Decisions (and why)

| decision | reason |
|---|---|
| memory protocol = **ALP v1** | the only repository protocol with 64-bit address, tags and byte enables; it is also CacheForge's interface (docs/00 §3) |
| **element = natural-aligned, E ∈ {1,2,4,8} ∪ 16k** | an element never straddles a 16-byte beat, so one element is one beat (or whole beats) and its byte-enable window is exact; arbitrary sizes would need a straddle splitter and a two-beat assembly path |
| **validate array extents once, every element again** | a refused array never reaches memory (cheap), and every calculated address is still checked (the brief's rule) |
| **requested bytes = validated bytes** (byte enables, union on merge) | the permission check is only meaningful if the engine cannot read what it did not check |
| **first fault in stream order stops the command; the lowest element wins** | deterministic, specifiable, and testable by an independent model; partial results are well defined (`docs/02` §7) |
| **scatter duplicates: highest element wins; no two writes to a beat in flight** | deterministic regardless of target ordering; matches VectorScratch; no write race by construction |
| **the request table is the response buffer** | out-of-order completions land in a reserved entry and cannot be lost; the reorder buffer only holds references |
| **ROB tolerates out-of-order completion but ALP v1 is in-order** | the brief asks for it; it is tested against a purpose-built target, not claimed for CacheForge |
| **CSR walker pushes column indices into the existing index buffer** | the whole gather pipeline (coalescing, permission, reordering) is reused for `x[col]` |
| **SpMV on the existing verified `tensor_pe`** | no arithmetic invented; the contract adds only reduction order and row boundaries |
| **MemoryGuard checker unmodified; table taken flat from `sf_memory_guard_regions`** | reuse of a verified contract; plug-compatible with the platform's table |

## 2. Traceability: brief → code → evidence

"Evidence" names scenario families (`model/gen_scenarios.py`); counts are in the generated reports.

| brief § | requirement | where | evidence |
|---|---|---|---|
| 1 | repository audit | `docs/00_repository_audit.md` | name search + read of the listed archives |
| 2 | decoder → index buffer → address gen → permission → scheduler → reorder → output buffer | `sf_sparse_memory_engine`, `sf_sparse_index_buffer`, `sf_sparse_address_gen`, `sf_sparse_request_coalescer`, `sf_sparse_reorder` | `docs/03` |
| 3 | gather: element size, index width, count, destination buffer, transaction id, protection domain; **validate every address** | engine decode + `sf_sparse_address_gen` + MemoryGuard checker | `s1_*` (81), `f1_*` (210, incl. the fault-arbitration sweep `f1_race_*` and `f1_tight_idx_*`), `c1_*` (31) |
| 4 | scatter; **duplicate policy documented**; no silent races | `docs/02` §4.2; coalescer write dependency | `s3_*`, `f3_*`, `c3s_*`; write-after-write monitor; **link byte monitor** (every byte on the link lies in a permitted region); mutants `co_no_dep`, `co_wr_merge_old` |
| 5 | CSR: row pointers, column indices, values, dims, nnz; validate monotonic / bounds / lengths / formats | `sf_sparse_csr_walker`, `docs/02` §6 | `s3c_*`, `f3c_*` (incl. row pointers exactly at `nnz` / `nnz + 1`: `f3c_rp_mid_*`, and arrays that start mid-beat in tight regions: `f3c_tight_*`) |
| 6 | coalescing: window grouping, **burst formation**, request queue, **duplicate-index optimisation**, response destination tracking, **preserve order** | `sf_sparse_request_coalescer` | merges / dup hits / burst counters in `docs/06` §4; `s2_ablate_*`; order checked in every scenario |
| 7 | bounded reorder buffer, out-of-order completions, no loss under backpressure | `sf_sparse_reorder` + request table | `s2_ooo_*`, `s2_bp_*`, `NRT`/`ROB` sweeps; mutants `rob_*` |
| 8 | CacheForge through its documented interface; hits, misses, random latency, coalescing, line utilisation; *do not assume all workloads benefit* | `tb/tb_sparse.sv` (`USE_CACHE`), `benchmarks/` | every in-order suite through the real cache; `docs/06` §6–7 |
| 9 | adapter to TensorScratch; contiguous tile; **do not overwrite active operand buffers** | `sf_sparse_tensor_adapter` | `tb/tb_adapter.sv` (real scratchpad) |
| 10 | optional SpMV with a verified lane; define width, precision, overflow, order, row boundaries | `sf_sparse_spmv`, `docs/02` §6.1 | `s3c_spmv_*`, `o3_*` (saturate / wrap, 32-bit long rows) |
| 11 | performance: elements/cycle, requests, burst efficiency, hit rate, reorder occupancy, bank conflicts, useful bytes, latency | `perf_o` counters, `benchmarks/run_bench.py` | `docs/06` |
| 12 | verification list | `tb/`, `model/` | table below |
| 13 | deliverables | table in §3 | — |

### Verification list (brief §12)

| required test | scenarios |
|---|---|
| sequential indices | `s1_E*_seq`, `s3_E*_seq`, `seq_*` benchmarks |
| random indices | `s1_E*_rand`, `s3_E*_rand`, `s2_*_rand_*` |
| repeated indices | `s1_E*_same/alt`, `s3_E*_same/alt`, `s3_dup_*`, `repeat4_E64` |
| unsorted indices | `s1_E*_rev/stride/rand` |
| negative / invalid indices | `f1_neg_*`, `f1_negraw_*`, `f1_limit_*`, `f3_neg_*`, `f3c_col_oob_*` |
| out-of-range addresses | `f1_addr_*`, `f1_perm_*`, `f1_region_end_*`, `f3_region_end_*`, `f1_dec_*` |
| duplicate scatter destinations | `s3_dup_last_wins_*`, `s3_dup_far_apart`, `s3_order_*` (reordering target), `c3s_dups_roundtrip` |
| CSR boundaries | `s3c_col_edge_*`, `f3c_rp_*`, `f3c_col_*`, `s3c_spmv_one_row_one_col`, `s3c_*_empty_matrix` |
| empty sparse rows | `s3c_spmv_all_empty / first_empty / last_empty / alternating / empty_mix`, `s3c_gather_all_empty_rows` |
| response reordering | `s2_ooo_*`, `s3_order_ooo*`, `s3c_*_env_ooo*`, `banked` scenarios (reordered-response counts in `reports/`) |
| robustness against a misbehaving target | `s2_rogue_*` (a response that answers no request → `SP_F_PROTO`, completion, clean next command) |
| backpressure | `s2_bp_*`, `s3_bp_*`, `s3c_spmv_maxout1`, random `rdy` / `rsp` knobs, stream index gaps, `NRT = 2/4` configurations |
| reset | `c3_midreset_*` (mid-command reset at 3/12/30/60 cycles, then a clean command), reset at every scenario start |
| tenant permission violations | `f1_tenant_*`, `f3_tenant_*`, `f3c_perm_*` (foreign table, spoofed claim, domain not bound, region read-only / write-only, boundary-crossing element, tight region ends) |

All results are compared with the **independent Python model** (`model/sp_model.py`); each scenario compares the completion
record, every output-buffer byte (written bytes against the expected data, **every other byte against its pre-command value**)
and the **entire memory image**.

## 3. Deliverables

| required | file |
|---|---|
| `sf_sparse_memory_engine.sv` | `rtl/sf_sparse_memory_engine.sv` |
| `sf_sparse_address_gen.sv` | `rtl/sf_sparse_address_gen.sv` (also holds `sf_sparse_beat_split`) |
| `sf_sparse_index_buffer.sv` | `rtl/sf_sparse_index_buffer.sv` (+ `rtl/sf_sparse_stream_rd.sv`, its array reader) |
| `sf_sparse_request_coalescer.sv` | `rtl/sf_sparse_request_coalescer.sv` |
| `sf_sparse_reorder.sv` | `rtl/sf_sparse_reorder.sv` |
| `sf_sparse_csr_walker.sv` | `rtl/sf_sparse_csr_walker.sv` |
| `sf_sparse_tensor_adapter.sv` | `rtl/sf_sparse_tensor_adapter.sv` |
| (optional arithmetic) | `rtl/sf_sparse_spmv.sv`, `rtl/sf_sparse_pkg.sv` |
| verification | `tb/`, `model/`, `scripts/run_regression.py`, `scripts/run_mutation.py`, `reports/` |
| benchmarks | `benchmarks/run_bench.py`, `benchmarks/results/`, `docs/06_benchmarks.md` |
| synthesis reports | `scripts/run_synth.py`, `reports/synthesis.md`, `docs/07_synthesis.md` |

## 4. Definition of done — status

> *The engine executes indexed gathers and supported scatter operations with byte-accurate results, safe bounds checking and correct
> output ordering despite memory contention.*

* **byte-accurate results** — every scenario compares every output byte and the whole memory image with the independent model;
* **safe bounds checking** — every calculated address is checked (overflow-exact arithmetic, index limit, MemoryGuard per element, array
  extents up front), and the bytes put on the link are the bytes that were checked;
* **correct output ordering despite memory contention** — verified with in-order, banked, randomly-reordering and back-pressured targets,
  with a request table as small as 2 entries, and through the real CacheForge;
* **what is *not* established** is listed in `docs/08_limitations.md` (no formal proof, no timing, no silicon, no coherence, CacheForge never completes out of order).
