# 00 — Repository audit: what exists, what was reused, what is missing

Scope: `btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/` (HDL is delivered as ~140 archives under
`SilicaFlux2.0/SilicaFlux2.5/`; `.sf` files are plain SystemVerilog). **Method:** every archive named in the brief was
extracted into a scratch directory and *read* (README, interface documents, RTL headers and port lists, verification
reports); a name search over the whole repository and over the file lists of all SilicaFlux 2.5 archives looked for sparse,
CSR, gather, scatter and embedding support. Nothing in the repository was modified and nothing was committed.
"Verified" below means *what the dependency's own report claims*, plus what was independently exercised **here**
(stated explicitly); claims in dependency reports were not re-derived.

## 1. Summary

| brief item | archive | what it is | here |
|---|---|---|---|
| **TensorCore 01** `tensor_pe` | `silicaflux-tensorcore01-tensor_pe` | INT8×INT8 MAC lane, `ACC_W` ≥ 16, saturate/wrap, sticky overflow, defined exact bound (`2^(ACC_W−15)−1` products) | **reused unmodified** as the SpMV lane. Its own report: unit tests, exhaustive INT8 products, Yosys SAT proof of the arithmetic core |
| TensorCore 02/03/04/05/06/07/09/10 | `silicaflux-tensorcore0x` | systolic array, operand buffers, accumulator, quantiser, tile controller, 2-D strided tensor DMA (SFB2), verification framework, benchmark lab | not instantiated. Several of them carry **their own file named `tensor_pe.sv`** (a different implementation); this package vendors TC01's only. TC07 moves *dense 2-D strided* tiles over SFB2 — no indexed access |
| **TensorScratch (P75)** | `silicaflux-tensorscratch-p75` | A/B operand buffers + accumulator buffer, write-only DMA fill port, FREE/FILLING/READY/IN_USE ownership, k-slice delivery to the array | **adapter target**, vendored unmodified; exercised through its real fill port and slice stream (docs/04 §3). Its report: 503/503 system runs vs numpy, no formal, no silicon |
| **VectorScratch (P76)** | `silicaflux-vectorscratch-p76` | vector scratchpad with **strided / indexed gather / scatter inside the scratchpad** (`GS_EN`), DMA port, ownership | different scope (local scratchpad, no external-memory interface, elements ≥ one bank word). **Reused: the duplicate-scatter rule** ("highest lane wins", docs/06 of that package) so both blocks agree |
| **MemoryMatrix (P101)** | `silicaflux-memorymatrix-p101` | multi-bank single-port SRAM, 64-bit words, per-bank round-robin, in-order responses, ECC | not instantiated. The engine's local buffers are simple RAMs and its external side is ALP, not MemoryMatrix's port. A banked target for future experiments |
| **StreamDMA (P103)** | `silicaflux-streamdma-p103` | descriptor-driven DMA over SFB2 / MemoryMatrix, burst planner `sf_stream_dma_plan` (4 KiB boundaries, beat alignment), permission hooks | not reused: contiguous segments and SFB2. The burst-planning idea (beat envelope, lane offsets) is the same one `sf_sparse_beat_split` applies per element |
| **CacheForge (P106)** | `silicaflux-cacheforge-p106` | 32 KiB 4-way write-back LLC; **ALP v1 both sides, in-order**; software-managed visibility; counters for hits / misses / refills / miss latency | **used through its documented interface**, vendored unmodified (with SRAMMacroBridge P79 and AlbionCore); 504/504 own regression, formal for selected blocks. Exercised here with every in-order suite |
| **DataFabric (P03, + NoC v1/v2)** | `silicaflux-datafabric*` | SFB2 crossbar + DMA: 32-bit address, **no tag**, one outstanding per port, 1-bit error | **not connected**. No SFB2 ↔ ALP bridge exists in the repository (also stated by AlbionCore's and CacheForge's audits) |
| **MemoryGuard (P104)** | `silicaflux-memoryguard-p104` | region-based protection (4 domains × 4 regions, 4 ingress ports), stateless checker with a documented contract; `sf_memory_guard_regions` exports the flat table the checker consumes | **checker used unmodified at the engine's ingress**; the testbench uses the real `sf_memory_guard_regions`. Its report: 22/22 formal proofs, 35/35 formal mutants, 31/33 simulation mutants |
| address-generation modules | `sf_vspm_agu` (P76), `sf_ts_agu` (P75), `sf_stream_dma_plan` (P103), TC06 tile controller | local-scratchpad or tile addressing; segment burst planning | none generates **external-memory element addresses from an index stream with exact overflow detection and per-element protection**; `sf_sparse_address_gen` is new |
| AlbionCore (ALP v1) | vendored via CacheForge | the only repository protocol with 64-bit address, 128-bit data, tags, byte enables | **the engine's memory protocol**; the ALP link checkers run on the engine's link in every in-order simulation |
| AtomicEngine (P109) | `silicaflux-atomicengine-p109` | atomic memory-operation engine | not integrated. **This engine's scatter has no atomic read-modify-write and no scatter-add**; an atomic scatter would route through P109 |

## 2. Existing sparse support: none

* No archive or file in the repository is named for sparse, CSR (compressed sparse row), gather, scatter, SpMV or embedding
  support (name search over `git ls-files` and over the file lists of every SilicaFlux 2.5 archive).
* **Naming collision:** the many `*_csr.sv` files (`extmem_csr`, `sfdma_csr`, `sf_hbm_csr`, `sf_albion_host_csr`) are
  *control / status registers*, not compressed sparse row.
* `silicaflux-hbmcore` ships memory **address traces** for its controller benchmarks (`vector_gather_fp32`,
  `vector_sparse_random`, `vector_spmv_csr`): `(cycle, R/W, address, id)` records only — no index or value data — so they cannot
  drive this engine. They are a possible future cross-check of access patterns, not an input here.

## 3. Consequences for the design

1. **One protocol: ALP v1** on the memory side. It is the only repository protocol that carries 64-bit addresses, tags and
   byte enables, which the engine needs for exact-byte requests and for matching out-of-order completions.
2. **CacheForge is in-order and blocking.** The brief's "response reordering" therefore cannot be exercised against the
   cache; the reorder structure is exercised against a purpose-built target model that completes out of order (a deliberate
   superset of ALP v1), and the cache path is exercised with the in-order model behind it (docs/05).
3. **Permission checking is reused, not re-invented**: the MemoryGuard checker's contract (whole transfer in one region, wrap
   detection, trusted port binding) is exactly what per-element validation needs.
4. **The SpMV arithmetic is not invented**: `tensor_pe` is reused with its published overflow contract; this package only
   defines the reduction order and row boundaries around it (docs/02 §6.1).
5. **Duplicate scatter**: aligned with VectorScratch ("highest wins") so the two scatter implementations agree.

## 4. What was not checked

* The contents of the ~100 archives not named in the brief were not read (only their file names were searched).
* Dependency verification claims (CacheForge's 504/504, MemoryGuard's 22 proofs, TensorScratch's 503/503, …) were not re-run;
  the engine's own tests exercise the dependencies through their interfaces.
* No bridge to SFB2 was written; DataFabric integration is therefore **not** claimed.
