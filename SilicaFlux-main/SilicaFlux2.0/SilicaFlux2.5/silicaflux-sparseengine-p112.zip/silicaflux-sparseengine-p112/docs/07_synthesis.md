# 07 — Synthesis statistics

**What this is.** Technology-independent statistics from a generic **Yosys** flow: coarse `synth`, RAM arrays kept as RAMs, `techmap`, `abc` to generic gates, `check -assert`. **What this is not:** there is no liberty file, no PDK, no static timing, no area in µm², no power, no place-and-route, no FPGA mapping. A "cell" is a Yosys generic gate (`$_NAND_`, `$_AND_`, `$_MUX_`, …); a "path length" is a number of such gates on the longest topological path of a module (`ltp -noff`), **not a delay**.

Reproduce: `make synth` (≈ 10 minutes). Raw: `reports/synthesis.json`, logs and netlist statistics in `build/synth/<config>/`.

## 1. Results

| configuration | overrides | logic cells | flip-flops | latches | RAM bits | `check -assert` |
|---|---|---|---|---|---|---|
| default | defaults | 99,137 | 8,200 | 0 | 132,072 | passed |
| gs_only | CSR_EN=0, SPMV_EN=0 | 85,847 | 7,129 | 0 | 131,720 | passed |
| small | CSR_EN=0, SPMV_EN=0, NRT=4, ROB_DEPTH=16, MAX_ELEM_BYTES=64, OBUF_BYTES=2048, IBUF_BYTES=2048, IDX_NSLOT=2, IDX_FIFO=2 | 44,364 | 3,872 | 0 | 33,092 | passed |
| large | NRT=32, ROB_DEPTH=64, OBUF_BYTES=32768, IBUF_BYTES=32768 | 152,906 | 12,675 | 0 | 525,288 | passed |

* `default` = the full engine (gather, scatter, CSR, SpMV) with `NRT = 16`, `ROB_DEPTH = 32`, 8 KiB input and output buffers.
* `gs_only` = gather / scatter only (`CSR_EN = SPMV_EN = 0`): the walker, event FIFO and SpMV lane disappear (13,290 logic cells, 1,071 flip-flops).
* **0 latches and `check -assert` clean** in every configuration (no combinational loop, no multiple driver, no undriven net).
* **RAM bits** are the arrays Yosys inferred as memories (not flattened): the two local buffers dominate (132,072 bits in `default`; 65,536 bits each for 8 KiB). The request table's data (`NRT × 128` bits) is built from **flip-flops** here, not RAM — it is read at an arbitrary index and written by three sources in one cycle.

## 2. Where the logic is (`default`)

| module | logic cells | share | flip-flops | longest path (generic gates) |
|---|---|---|---|---|
| `sf_sparse_request_coalescer` | 52,084 | 53% | 4,504 | 306 |
| `sf_sparse_memory_engine` | 17,443 | 18% | 1,638 | 232 |
| `sf_memory_guard_checker` | 12,833 | 13% | 0 | 80 |
| `sf_sparse_address_gen` | 2,726 | 3% | 257 | 81 |
| `sf_sparse_stream_rd` | 2,235 | 2% | 207 | 64 |
| `sf_sparse_reorder` | 1,549 | 2% | 409 | 13 |
| `sf_sparse_csr_walker` | 1,690 | 2% | 266 | 90 |
| `sf_sparse_index_buffer` | 725 | 1% | 108 | 39 |
| `tensor_pe` | 700 | 1% | 70 | 50 |
| `sf_sparse_beat_split` | 298 | 0% | 81 | 43 |
| `sf_sparse_spmv` | 136 | 0% | 39 | 32 |

(Per-module counts are the module's own cells **per instance**; `sf_sparse_stream_rd` is instantiated four times (index buffer + the three CSR readers), so its row understates its share; the module counts sum to the design total only after weighting by instance count. `tensor_pe` and the MemoryGuard checker are the unmodified vendored cores.)

## 3. What to take from it — and the hotspot

1. **The request coalescer is 53% of the logic and has the longest path (306 generic gates).** It holds the request table (`NRT` entries of 128-bit data, 44-bit beat addresses, byte enables, age, dependency), does the fully-associative match of every incoming descriptor, and performs issue selection (continuation / same line / oldest) in one cycle. The selection and merge decision is an unpipelined chain; this package made no attempt to optimise it for frequency.
   *First optimisations, not done here:* pipeline the selection (register the selected index one cycle ahead), turn the linear oldest-search into a tree, narrow the per-entry latency counters, and move entry data into a RAM with a separate tag array (the cost of that is a more complex merge path). `NRT` scales this block roughly linearly (`small`, `NRT = 4`: 44,364 cells in total).
2. **The MemoryGuard checker costs 13%** for 16 regions with 40-bit comparators (`LOOKUP_ARCH = 0`, all regions in parallel). `LOOKUP_ARCH = 1` (multiplex the claimed domain's regions first) trades area for a longer path; not evaluated here.
3. **A 306-gate path is not a frequency.** No claim is made about the clock this design could reach; the number only says where the next timing work belongs.
4. **Not covered:** the testbench-only blocks, the CacheForge / TensorScratch cores (their own reports exist), any physical effect.

