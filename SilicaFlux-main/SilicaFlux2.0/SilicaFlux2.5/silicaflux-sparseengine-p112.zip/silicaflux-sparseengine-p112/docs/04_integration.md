# 04 — Integration: ports, MemoryGuard, CacheForge, TensorScratch, DataFabric

## 1. Ports of `sf_sparse_memory_engine`

| group | signals | notes |
|---|---|---|
| clock / reset | `clk_i`, `rst_ni` | active-low, asynchronous assert, synchronous release supplied by the platform; reset the memory target with the engine |
| command | `cmd_valid_i`, `cmd_ready_o`, `cmd_i` (`sf_sp_cmd_t`) | `cmd_ready_o` high only when idle; the command is captured on the handshake |
| completion | `done_valid_o`, `done_ready_i`, `done_o` (`sf_sp_done_t`) | exactly one record per command, held until `done_ready_i` |
| configuration (static while busy) | `cfg_max_out_i`, `cfg_merge_en_i`, `cfg_burst_en_i` | `cfg_max_out_i` **must be ≤ the target's advertised outstanding limit** (CacheForge: `caps_o[31:16]`); the two enables exist for measurement (merging and burst-seeking off = one request per descriptor, oldest first) |
| index push | `ipush_valid_i`, `ipush_ready_o`, `ipush_data_i[31:0]` | used by `idx_stream` commands: exactly `n` indices are accepted per command |
| input buffer (host write) | `ibuf_we_i`, `ibuf_waddr_i` (16-byte word), `ibuf_wdata_i`, `ibuf_wbe_i` | write only while no scatter is running |
| output buffer (host read) | `obuf_raddr_i`, `obuf_rdata_o` | registered read: data one cycle after the address; shared with the tensor adapter (mux while the adapter is busy) |
| ALP link | `req_valid_o/req_ready_i/req_o`, `rsp_valid_i/rsp_ready_o/rsp_i` (`sf_albion_pkg::sf_req_t/sf_rsp_t`) | `rsp_ready_o` is constant 1 |
| MemoryGuard table | `t_valid_i t_base_i t_end_i t_r_i t_w_i t_devn_i t_dev_i t_allow_i` | **exactly the outputs of `sf_memory_guard_regions`** (same flattening); `PIDX` selects this engine's port binding |
| status | `busy_o`, `perf_o`, `perf_clear_i` | counters: `docs/02` §9 |

### Parameters

`ADDR_W` (40; ≤ 48) · `NRT` (16; 2–32) · `ROB_DEPTH` (32; power of two) · `IDX_NSLOT` (4) · `IDX_FIFO` (4) · `WK_NSLOT` (4) · `EV_DEPTH` (32) ·
`MAX_ELEM_BYTES` (256) · `OBUF_BYTES`, `IBUF_BYTES` (8192; power of two, ≥ 16) · `ND`, `NR`, `NP`, `PIDX` (4, 4, 4, 3) · `CHK_LW` (30) ·
`LINE_BEATS` (4) · `BANK_LOG2` (2) · `CSR_EN`, `SPMV_EN` (1) · `SPMV_ACC_W` (32) · `SPMV_OVF_WRAP` (0) · `CNT_W` (32).
Illegal combinations are rejected at elaboration (`$error` in generate blocks).

## 2. MemoryGuard (P104)

`sf_memory_guard_pkg` and `sf_memory_guard_checker` are used **unmodified** (vendored, SHA-256 in `third_party/PROVENANCE.md`).
The platform instantiates `sf_memory_guard_regions` (table + port bindings, configured through the privileged bus of
`sf_memory_guard_regs`) and connects its `t_*` outputs to the engine. The testbench does exactly that with the real
`sf_memory_guard_regions`, programmed through its command port, so the region-install rules (overlap rejection, size
checks) are exercised too.

* **Domain model:** the command's `dom` is a MemoryGuard domain index (`< ND`); the claim must be allowed for this port
  (`t_allow_i[PIDX*ND +: ND]`), otherwise it is a spoof fault. The ALP domain field is `0x10 + dom`.
* **Quiescing.** MemoryGuard's contract is *drain-then-commit*: a table change must not happen while a request that was
  checked against the old table is in flight. Use `busy_o`: change the table only while the engine is idle (the engine
  validates each element at the point it is issued, so a table change during a command would apply to some elements and
  not others). `sf_memory_guard` itself (the in-line enforcement point) is **not** instantiated: the engine uses the checker
  at its own ingress, which is the check-only usage the checker's header describes.
* **What this does and does not protect.** Every byte the engine puts on the link was checked (docs/02 §3). MemoryGuard is
  protection, not translation; the engine does not translate.

## 3. TensorScratch (P75) — `sf_sparse_tensor_adapter`

Moves rows from `OBUF` into the A and/or B region of the scratchpad's **current fill set** through its write-only DMA fill
port, in one fill session: `validate → fill_begin → A segment → B segment → drain responses → fill_end`.

* **Do not overwrite active operand buffers** — four independent mechanisms: (1) the adapter never picks a set; the scratchpad
  grants a FREE set on `fill_begin` (the begin waits while there is none); (2) the adapter checks that its set is FILLING
  before the first and before every write (`own_check_en_i`); (3) the scratchpad itself refuses any write to a set that is not
  FILLING (`OWNER`, no side effect); (4) parameters are validated before the scratchpad is touched.
* **Timing detail.** The scratchpad updates `fill_set` / `set_state` in the cycle *after* it accepts `fill_begin`; the adapter
  therefore reads them directly and never samples them in the handshake cycle (a bug found by the ping-pong test).
* **Tile layout.** Each segment is `rows` × `row_bytes`, read from `OBUF` with `src_pitch` and written with `dst_pitch`
  (both multiples of the scratchpad word, `dst_pitch ≥ row_bytes`), at a set-relative offset. For gathered rows the natural
  choice is `src_pitch = dst_pitch = row_bytes` — a contiguous tile. A gathered tile of `A` rows and one of `B` rows fill one
  operand set; the tile descriptor then reads it with `lda = dst_pitch_A`, `ldb = dst_pitch_B`.
* **Errors:** `ADP_E_PARAM` (rejected up front), `ADP_E_OWNER`, `ADP_E_RANGE`, `ADP_E_ALIGN`, `ADP_E_OTHER`. After an error the
  transfer drains its outstanding responses, issues `fill_end` (to keep the scratchpad's ownership state machine consistent)
  and reports the error with `done_o`; the consumer must discard that tile.
* **Verification** (`tb/tb_adapter.sv`): the real, unmodified scratchpad; every k-slice it delivers to the array input is
  compared with the rows the engine gathered — 3,008 operand comparisons in the final run, including a fill into one set while
  the other is being consumed, a fill with no free set (the adapter waits and writes nothing), and a write aimed at a set holding
  a READY tile (refused by the scratchpad, tile delivered intact). It does **not** run a GEMM through the systolic array and
  accumulator (docs/08).

## 4. CacheForge (P106)

The engine sits on CacheForge's upstream ALP v1 port (`req_*` / `rsp_*`) with no glue. CacheForge is **in-order** and has a
documented outstanding limit (`caps_o`): set `cfg_max_out_i` to it (1 for the blocking cache, `2·NUM_MSHR` with MSHRs).

**Visibility is software-managed — CacheForge is not coherent and neither is the engine** (there is no CoherenceDirectory in
the repository). Follow CacheForge's DMA rules (`CacheForge docs/05` §2) around a command:

| situation | software must |
|---|---|
| the engine will read data that another agent wrote | `INVAL` / `CLEAN_INVAL` the range before the command |
| the engine scatters data that another agent will read | `CLEAN` the range after the command completes (a scatter through a write-back cache leaves dirty lines) |
| the engine's tables and indices were written by the host | `CLEAN` after writing, before the command |

`cacheable = 0` selects ALP `NORMAL_NC` (bypass): the request is forwarded to memory in order, no lookup, no maintenance needed.
The testbench cleans and invalidates the whole cache after every command before it compares memory, and re-loads memory only
after that — it exercises the rule rather than assuming coherence.

**Error granularity behind a cache.** CacheForge refills whole 64-byte lines; one failing beat fails every access to its
line, and the first failing request is the first beat of the line. The reference model takes the target's error granularity as a
parameter (`ERR_LINE_BEATS`).

**Measured, not assumed.** `docs/06_benchmarks.md`: a blocking CacheForge was slower than direct memory for every workload when
the memory sustains many outstanding requests; it was far faster than a one-outstanding path.

## 5. DataFabric (P03, SFB2)

**Not connected, and not claimed.** SFB2 has a 32-bit address, no tag, a single outstanding transaction per crossbar port and a
1-bit error; no SFB2 ↔ ALP bridge exists in the repository (AlbionCore's and CacheForge's audits say the same). A bridge would have
to reject or split addresses ≥ 2^32, set `cfg_max_out_i = 1`, and map ALP statuses onto the single error bit. The engine's
`ADDR_W` could be set to 32 for such a system; nothing in this package does it.

## 6. Reset and bring-up

1. Reset the engine, the target and (if present) the MemoryGuard table together; hold `rst_ni` low ≥ 2 edges.
2. If CacheForge is the target, wait for `init_done_o` (`SETS` cycles); the engine's request is simply held until the cache is ready.
3. Program the MemoryGuard table and port binding; load `IBUF` (scatter) if needed.
4. Set `cfg_max_out_i` from the target's capabilities; issue a command; wait for `done_valid_o`; read `OBUF`.
