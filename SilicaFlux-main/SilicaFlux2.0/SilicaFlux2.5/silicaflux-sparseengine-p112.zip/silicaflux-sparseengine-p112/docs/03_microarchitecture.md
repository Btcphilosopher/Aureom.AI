# 03 — Microarchitecture

```
                   cmd ─► Command decoder / validation sequencer ──┐ (decode faults, array-extent checks)
                                                                    ▼
 index array in memory ─► [stream reader] ─┐                 MemoryGuard checker (one instance, shared)
 index push port ────────────────────────┬─┴► Index Buffer ─► Address Generator ─► [permission check] ─► beat splitter
 CSR walker (col indices) ───────────────┘                    (3 stages)          per element           element → beats
                                                                                                             │
                     scatter: IBUF read + lane align ◄────────── (scatter only) ◄────────────────────────────┤ gather
                                   │                                                                          │
                                   └──────────────► Request coalescer / request table (NRT entries) ◄─────────┘
                                                         │ merge · dedupe · burst-seeking issue · 2-entry request FIFO
                                                         ▼
          index / CSR-array readers ─────────► link arbiter (round-robin, locked until accepted) ─► ALP v1 link
                                                         ▲ responses routed by tag[7:5]
                          Reorder buffer (ROB_DEPTH slots, delivery in element order) ◄── request-table data
                                   │
                                   ├─► output writer (lane rotation) ─► OBUF
                                   └─► SpMV lane (tensor_pe) ◄── event FIFO ◄── CSR walker (val, row boundaries)
```

## 1. Block by block

| block (file) | job | notes |
|---|---|---|
| command decoder / validation sequencer (`sf_sparse_memory_engine`) | decode faults; check each array extent with the MemoryGuard checker, one per cycle | states `IDLE → DECODE → CHECK → RUN → DONE` |
| `sf_sparse_stream_rd` | read `count` consecutive 1/2/4/8-byte elements through beat requests | exact byte enables; up to `NSLOT` beats in flight, slot number travels in the tag; delivers in order; a presented request is never withdrawn (ALP-REQ-02) |
| `sf_sparse_index_buffer` | bounded index source: memory array (reader) or push port, plus a `DEPTH`-entry FIFO | zero-extends; reports negative signed indices; `close_i` ends the stream after what is buffered (CSR fault) |
| `sf_sparse_address_gen` | `base + idx·E` in three register stages (checks / multiply / add), exact arithmetic | first matching fault: array read error, negative, `idx ≥ limit`, overflow |
| permission check (in the top) | the unmodified `sf_memory_guard_checker` on every element `[addr, addr+E)` | the same instance validates array extents during `CHECK` |
| `sf_sparse_beat_split` | element → 16-byte beat descriptors with the byte-enable window | `E<16`: one beat, lane window; `E≥16`: `E/16` whole beats |
| scatter source stage (in the top) | read the `IBUF` word, rotate the element into the beat lane | skipped by gather |
| `sf_sparse_request_coalescer` | **request table**: merge, deduplicate, order writes, select and issue | §2 |
| `sf_sparse_reorder` | **reorder buffer**: element-order delivery of completed read data | §3 |
| link arbiter (in the top) | 5 requesters (coalescer, index reader, 3 CSR readers), round-robin, outstanding limit | grant locked while a request is not accepted |
| output writer (in the top) | rotate the delivered lane to its place in the destination word, byte-masked write to `OBUF` | the same write port carries SpMV `y` |
| `sf_sparse_csr_walker` | validated CSR traversal, three stream readers | §5 |
| `sf_sparse_spmv` | `tensor_pe` + event pairing + row bookkeeping | §6 |
| `sf_sparse_tensor_adapter` | OBUF → TensorScratch fill port | separate module, docs/04 §3 |

## 2. Request table and coalescer

The request table (RT) has `NRT` entries (2…32). An entry holds one 16-byte beat request: `{state, op, beat, byte
enables, 128-bit data, reference count, age, status, element, dependency}`. States: `FREE → PEND → FLIGHT → DONE → FREE`.
**The entry is also the response buffer**: a read response is written into the entry it was issued from (tag = entry index),
so it can arrive at any time in any order and cannot be lost — an entry is not reused until every consumer has released it.

**Accepting a beat descriptor** (all decisions use registered state only):

* *read*, a **pending** entry of the same beat → **merge**: the byte enables are OR-ed (this is how sub-beat elements of one
  beat become one request);
* *read*, an **issued or completed** entry of the same beat whose byte enables already cover the descriptor's bytes →
  **duplicate hit**: no new request; the descriptor just takes a reference;
* *write*, a **pending** entry of the same beat → **merge**: data bytes are overwritten in descriptor order
  (**highest element index wins**) and the enables OR-ed;
* otherwise → allocate a free entry (stall if there is none). A new **write** to a beat for which an older write is still
  pending or in flight records a **dependency** on the youngest such entry and is not issued before that one has been
  answered, so two writes to a beat are never in flight together and the final value never depends on the target's ordering.
  (A dependency whose response arrives in the allocation cycle is already resolved — see `docs/05` §6.)

Every accepted read descriptor takes one reorder slot (reference count + 1). Entries are freed when the last consumer
releases them; write entries are freed by their response.

**Issue.** A pending entry is eligible when it has not been touched in the previous cycle (`fresh`: gives the following
descriptors one cycle to merge) and has no unresolved dependency. Selection prefers **the entry that continues the previously
issued beat (address + 16)** — this forms bursts of consecutive beats — then an entry in the **same 64-byte line**, else the
**oldest**; after `BURST_MAX` continuations it falls back to oldest, so nothing starves. Selected requests enter a 2-entry
request FIFO, so one request can be issued every cycle; a merge never races with an issue because the entry being selected
is treated as issued from that cycle on (its enables are fixed).

**There are no bursts on the link**: ALP v1 has single-beat requests only. "Burst formation" means issuing runs of
consecutive-address beats back to back (which a cache turns into one line refill and a banked memory into row hits) and
counting them (`SP_PC_BURST_CONT`).

## 3. Reorder buffer and backpressure

The reorder buffer is a ring of `ROB_DEPTH` slots allocated in element order, one per accepted read descriptor. A slot
records *which RT entry will hold its data* and the lane of the element in the beat — that is the **response destination
tracking**; no data is copied. Delivery is strictly in slot order and only when the head slot's entry is `DONE`.

**No data loss under backpressure**, by construction:

* a descriptor is accepted only if a reorder slot (reads) and a table entry are free, and both facts are registered state;
  otherwise the upstream stages simply stall (the address generator, then the index buffer, then the index reader);
* the link's `rsp_ready_o` is constant 1 — a response always has a reserved RT entry to land in;
* delivery holds the head slot while the consumer is not ready; the entry is released in the same cycle the data is
  captured into the delivery register;
* an error response is carried to the delivery point and turned into a fault there, so it is attributed to the right
  element.

Deadlock freedom: the head slot's entry was allocated before any younger one, so it is always either issued or issuable;
it completes (the target answers), is delivered and released, which frees space. Writes depend only on older writes.

## 4. Link arbitration and tags

Requesters: 0 coalescer (data), 1 index reader, 2/3/4 CSR row-pointer / column / value readers. Round-robin; once a request
is shown to the link the grant is **locked** until it is accepted, so the request channel is stable (ALP-REQ-02). A request
is presented only while `outstanding < cfg_max_out_i`.

Tag map (`sf_sparse_pkg`): `tag[7:5]` = source (000 data, 001 index, 010 row-ptr, 011 column, 100 value),
`tag[4:0]` = RT index or reader slot. Hence `NRT ≤ 32` and at most 8 slots per reader.

## 5. CSR walker

A small FSM over three stream readers (`IDLE, RP0, ROW, EMPTY, EMIT, DONE, FAULT`): it reads `row_ptr[0]`, then per row `p1`,
validates, and streams the row's nonzeros one per cycle — each nonzero pushes the column index into the index buffer
(push mode, so the whole gather pipeline is reused) and, for SpMV, an event `{value, first, last}` into a 32-entry FIFO.
The walker is at the very **front** of the pipeline: after a walker fault everything downstream is *earlier* and must
finish, so the engine closes the index buffer after draining it instead of flushing it (a fault raised at the back end
flushes everything upstream, which is all *later*).

## 6. SpMV lane

`tensor_pe` is instantiated unmodified (A = B = 8 bit, `ACC_W` configurable, 1 multiplier stage, latency 3). Events and
gathered `x` elements are both in nonzero order and pair one to one; an empty-row event needs no `x` and issues a
clear-only token. A delay line aligned with the lane's latency marks which tokens end a row; the row result is written to
`OBUF[dst_off + 4·row]`. `x` data for a faulting nonzero never arrives, so events behind it simply stay unpaired and are
discarded when the command ends (the orphan rule in `docs/05` §6).

## 7. Cost model — where throughput comes from

Steady-state element rate is `min(1 request / cycle ÷ beats per element, NRT ÷ latency ÷ beats per element)`; the second
term is Little's law on the request table. Merging and duplicate hits reduce the number of requests; `ROB_DEPTH` must be
≥ the number of in-flight read beats to avoid reorder stalls. `docs/06_benchmarks.md` measures all of this.
