# 02 — Functional specification (normative)

This is the behaviour that **both** the RTL and the independent Python model (`model/sp_model.py`) implement. It is
timing-independent: nothing here depends on latency, back-pressure, the order in which a target completes requests, or
the configuration of the engine's buffers (except where a parameter is named). Rule ids (`R-…`) are referenced by the
tests and by `docs/01_overview.md`.

## 1. Execution model

* **One command at a time.** `cmd_ready_o` is high only when the engine is idle; a command runs to completion (or to its
  first fault) and then produces exactly one completion record (`done_valid_o`). There is no command queue and no abort
  command; reset is the only way to cancel a running command (R-RST).
* **The memory link is ALP v1** (`sf_albion_pkg`: 64-bit address, 128-bit data, 16 byte enables, 8-bit tag, single-beat
  requests, non-posted writes). The engine is an ALP *initiator*; it can be connected directly to CacheForge's upstream
  port or to any other ALP v1 target.
* **Local buffers.** `IBUF` (scatter source, host-written) and `OBUF` (gather / SpMV results, host-read) are plain
  16-byte-wide RAMs inside the engine. `dst_off` / `src_off` are byte offsets into them.
* **Software visibility.** The engine is not coherent with anything (docs/04 §4). If the target is a cache, software
  makes memory visible with clean / invalidate operations around a command.

## 2. Commands (`sf_sp_cmd_t`)

| op | meaning | fields used |
|---|---|---|
| `GATHER` | `OBUF[dst_off + i·E ..) = mem[base + idx[i]·E ..)` for `i = 0 … n-1` | `base idx_base idx_stream idx_signed idx_w n elem_bytes idx_limit dst_off dom cacheable tid` |
| `SCATTER` | `mem[base + idx[i]·E ..) = IBUF[src_off + i·E ..)` | as above with `src_off` |
| `CSR_GATHER` | for every nonzero `k` of a CSR matrix: `OBUF[dst_off + k·E ..) = x[col[k]]` | `base`(= x) `elem_bytes rp_base ci_base nrows ncols nnz ci_w vfmt dst_off dom cacheable tid` |
| `CSR_SPMV` | `y[r] = Σ val[k]·x[col[k]]` (INT8 × INT8 → INT32), `y` stored as INT32 at `OBUF[dst_off + 4r]` | as `CSR_GATHER` + `val_base`, `vfmt = INT8`, `elem_bytes = 1` |

`E` = `elem_bytes`. Fields not listed for an op are ignored. `n = 0` (gather / scatter) completes successfully without any
memory access.

### 2.1 Element size, alignment and index width (R-ELEM)

* `E ∈ {1, 2, 4, 8}` or `E` a multiple of 16, and `1 ≤ E ≤ MAX_ELEM_BYTES` (parameter, default 256). Anything else is `SP_F_BAD_ELEM`.
* **Alignment:** `base`, `dst_off` / `src_off` must be multiples of `min(E, 16)` (SpMV: `dst_off` a multiple of 4); the index array base must be a multiple of the
  index width in bytes; `rp_base` of 4; `ci_base` of the column-index width. Violation is `SP_F_ALIGN`.
  Consequence: an element never straddles a 16-byte beat. `E < 16` → one beat with a lane window; `E ≥ 16` → `E/16` whole beats.
* **Index width** `idx_w ∈ {0,1,2}` = 8 / 16 / 32 bit (`3` → `SP_F_BAD_IDXW`). The raw index is zero-extended.
* **Signed indices** (`idx_signed = 1`): the top bit of the raw index is a sign; a **negative index is a fault**
  (`SP_F_NEG_INDEX`), it is never used as a backwards offset. Unsigned indices cannot be negative; huge ones fail the
  range / overflow / permission checks.
* **`idx_limit`**: if non-zero, valid indices are `0 … idx_limit-1` (`SP_F_IDX_RANGE`). For CSR commands the limit is `ncols`.
* **Buffer windows**: `dst_off + n·E ≤ OBUF_BYTES` (gather), `src_off + n·E ≤ IBUF_BYTES` (scatter),
  `dst_off + 4·nrows ≤ OBUF_BYTES` (SpMV) — else `SP_F_BUF_RANGE`. Every base address must be `< 2^ADDR_W` — else `SP_F_ADDR_OVF`.

### 2.2 Decode precedence (R-DEC)

First match wins, and a decode fault has no side effect (no memory access, no buffer write):
`BAD_OP` → `BAD_ELEM` → `BAD_IDXW` → `ALIGN` (base, index base, buffer offset) → `BUF_RANGE` → `ADDR_OVF`.
CSR: `BAD_ELEM` → `CSR_FMT` → `CSR_DIM` → `UNSUP` → `ALIGN` → `BUF_RANGE` → `ADDR_OVF` (§6).

## 3. Permission validation (R-PERM)

Every access the engine makes is checked by the **unmodified MemoryGuard checker** (`sf_memory_guard_checker`) against the
region table of the command's protection domain `dom`, using the contract in its header: the whole byte range must lie in
**one** region of that domain with the right (read / write); an address that wraps or a domain claim not allowed for this
port is denied.

1. **Array extents are checked once, before anything runs**, in this order: index array (`n << idx_w` bytes) — or for CSR:
   row pointers (`(nrows+1)·4`), column indices (`nnz << ci_w`), values (`nnz`, SpMV only), the whole `x` vector
   (`ncols · E`). An extent of `2^CHK_LW` bytes or more (default `2^30`) is refused as too long (guard fault `BADLEN`).
   A refused extent is `SP_F_PERM` with the guard's fault code in `gfault`, `fault_addr` = the array base, `fault_elem` = 0,
   and nothing has been read.
2. **Every element address is checked again**, individually, with the exact length `E` (read for gather, write for scatter).
3. **The bytes on the link are the bytes that were checked.** Read requests carry byte enables equal to the validated
   bytes (index/CSR array reads: exactly the array's lanes of a shared beat). Merging requests can only widen the enables to
   the **union of validated bytes**. A target that honours byte enables never returns, and the engine never uses, a byte it
   did not validate. *(A cache refills whole lines below the interface; that is outside the engine — docs/04 §4.)*
4. The engine's ALP domain field is `0x10 + dom` (tenant range). Whether a claim `dom` is acceptable for this engine is the
   MemoryGuard *port binding* (`t_allow_i`), supplied by the platform; a claim that is not allowed is a `SPOOF` fault.

## 4. Gather and scatter

### 4.1 Gather (R-GATHER)

For `i = 0 … n-1` the engine reads `E` bytes at `base + idx[i]·E` and stores them at `dst_off + i·E` in `OBUF`.
Results are **delivered in element order** regardless of the order in which the target completes requests. After a
fault at element `f` (§7), `OBUF` holds exactly elements `0 … f-1`; every other byte of `OBUF` is unchanged.
Memory is never modified by a gather.

### 4.2 Scatter and duplicate destinations (R-SCATTER)

`mem[base + idx[i]·E ..) = IBUF[src_off + i·E ..)`.

**Policy for duplicate destinations — deterministic, documented, race free:**

* Writes take effect **in element order**. If two elements write overlapping bytes, **the element with the higher index
  wins** those bytes; bytes written by only one of them are unaffected. (Because all elements have the same size and
  stride, two destinations are either identical or disjoint.)
* This holds whatever the target does with ordering: the engine never has two writes to the same 16-byte beat in
  flight. A later write to a beat is either **merged** into the still-unissued earlier request (later bytes overwrite) or
  **held back until the earlier request has been answered**.
* A fault at element `f` commits **exactly** elements `0 … f-1` (all of them, completed before the completion record) and
  nothing at or after `f`. (VectorScratch, P76, uses the same "highest index wins" rule for its scatter.)
* **Exception — write errors from the target.** If the target answers a write with an error, that beat is not
  written, the engine stops issuing, and elements *after* the failing one that were already in the pipeline may or may not
  have been committed (they are not recalled). The completion record names the lowest failing element; memory beyond
  "elements before it are committed" is **not specified**. The tests compare memory exactly only when the failing element is
  the last one.

## 5. Output order, reordering and ordering guarantees (R-ORDER)

* ALP v1 itself is in-order and CacheForge honours that. The engine does **not rely on it**: responses are matched by
  tag and delivered in element order through a bounded reorder structure, so it also works with a target that completes
  requests out of order (banked memory, several channels). Such a target is outside ALP v1 (`SF_FEAT_OUT_OF_ORDER` is 0 in v1)
  and is used in the tests as a deliberate superset.
* The request channel obeys ALP-REQ-02 (a presented request is held until accepted), ALP-TAG-01 (no tag is reused while
  outstanding) and ALP-OUT-01 (at most `cfg_max_out_i` requests outstanding — set it ≤ the target's advertised limit).

## 6. CSR traversal (R-CSR)

Arrays: `row_ptr[0 … nrows]` (uint32), `col_idx[0 … nnz-1]` (8/16/32 bit), `val[0 … nnz-1]` (INT8 for SpMV).

**Command validation (no side effect on failure)**

| check | fault |
|---|---|
| `ci_w = 3` or `vfmt > 3` (value formats: INT8, INT16, INT32, FP32-raw) | `SP_F_CSR_FMT` |
| `nnz ≠ 0` and (`nrows = 0` or `ncols = 0`) | `SP_F_CSR_DIM` |
| SpMV with `vfmt ≠ INT8` or `E ≠ 1` | `SP_F_UNSUP` (traversal is legal; the arithmetic lane is INT8×INT8 only) |
| array extents (§3.1) | `SP_F_PERM` |

**Traversal** is strictly sequential, row by row, and **validates as it goes**:

1. `row_ptr[0] == 0` — else `SP_F_CSR_ROWPTR` at nonzero position 0.
2. For `r = 0 … nrows-1`, with `p0 = row_ptr[r]` and `p1 = row_ptr[r+1]`:
   `p1 ≥ p0` (monotonic), `p1 ≤ nnz` (in range), and for the last row `p1 == nnz` (the arrays agree). Any failure is
   `SP_F_CSR_ROWPTR` with `fault_elem = p0`. **This is checked before any nonzero of row `r` is emitted.**
3. For `k = p0 … p1-1`: `col_idx[k] < ncols` — else `SP_F_CSR_COL`, `fault_elem = k`. A valid column index is
   gathered (`x[col]`, with the full per-element permission check).
4. Empty rows (`p1 == p0`) are legal anywhere. A matrix with `nrows = 0, nnz = 0` is legal.

**Faults and positions.** `fault_elem` is always a *nonzero position*: the number of nonzeros that were emitted before
the fault. Everything before that position completes (gather results delivered; SpMV rows complete). The first fault in
traversal order wins; a data-side fault on an earlier, already emitted nonzero (permission, memory error) has a lower
position and wins (§7).

**CSR_GATHER** writes `x[col[k]]` for the emitted nonzeros to `OBUF[dst_off + k·E]`; values are not read. `elems_done` =
nonzeros delivered.

### 6.1 SpMV arithmetic (R-SPMV) — optional, `SPMV_EN`

Implemented with the repository's verified **TensorCore 01 `tensor_pe`**, unmodified. Defined here because saturation makes
the result order dependent:

| property | definition |
|---|---|
| operands | `val[k]` and `x[col[k]]` signed INT8; product exact (16 bit) |
| accumulator | signed `SPMV_ACC_W` bit (default **32**, 16…32 allowed); `y` is stored as INT32, sign-extended |
| **reduction order** | **sequential in CSR order**: the nonzeros of a row are accumulated one per cycle in ascending `k`. No reordering, no tree |
| **overflow** | after every step the exact sum is clamped to `[−2^(W−1), 2^(W−1)−1]` (`SPMV_OVF_WRAP = 0`) or wrapped modulo `2^W` (`= 1`), and a sticky flag is set; the flag is reported once per command in `done.ovf` (only rows that completed contribute). With `W = 32` a row of up to 131 071 nonzeros is exact |
| **row boundaries** | each row starts from zero (clear-and-load, no bubble); an **empty row** yields `y = 0`; rows are produced in order; `y[r]` is written when its last nonzero has been accumulated |
| `elems_done` | number of `y` entries written |

**Partial results.** If a fault stops the command, `y[r]` has been written for exactly the rows `r` that complete before the
faulting position (all rows strictly before the row containing the fault); the faulting row and later rows are not written.

## 7. Faults (R-FAULT)

`done.fault` is one of the `SP_F_*` codes (`rtl/sf_sparse_pkg.sv`); 0 = success.

* **Detection order per element** (gather / scatter): index-array read error (`MEM_ERR`) → negative signed index →
  `idx ≥ idx_limit` → `base + idx·E ≥ 2^ADDR_W` (`ADDR_OVF`, computed exactly, no wrap-around) → MemoryGuard (`PERM`, guard
  code in `gfault`).
* **The lowest element index wins.** A front-end fault (any of the above) at element `f` stops the command: elements
  `0 … f-1` complete, `f` and everything after are discarded. A memory error returned for an *earlier* element than `f` replaces
  the recorded fault. The record always names the lowest faulting position.
* **Record fields.** `fault_elem`: the element (or nonzero position). `fault_addr`: the address presented to the permission
  checker (`SP_F_PERM`), or the beat-aligned address of a failing scatter write (`MEM_ERR` on scatter); **0 otherwise**.
  `alp_status`: the ALP status for `MEM_ERR` (index-array read errors report `SF_ST_TARGET_ERR`). `elems_done`: gather /
  CSR_GATHER = elements delivered; scatter = elements committed (for `MEM_ERR`: the failing element index, see §4.2);
  SpMV = rows written.
* **Memory-side errors.** A non-OKAY ALP status on a data read, an index/CSR array read, or a write is `SP_F_MEM_ERR`.
  Error data (poisoned or zero) is never delivered.
* **Link protocol violation** (a response that matches no request) is `SP_F_PROTO`. ALP v1 forbids such a response, so
  this is a robustness path, not an expected one. **Detected:** a data-path response whose tag index is outside the request table
  or names an entry that is not in flight. **Contract:** the code is reported, the command completes (the engine waits for the
  requests that really are outstanding: a response the engine has rejected as invalid is *not* counted against them), the
  engine is idle and usable afterwards, and `fault_elem` is the element that was next to be delivered when the response arrived.
  **Not specified:** the contents of the output buffer / memory beyond that element, and `elems_done`. **Not detected:** a stray
  response whose tag names a *live* entry or a slot of an index / CSR array reader (it is indistinguishable from the real one,
  and the readers trust the link); a response with an unassigned source tag (`tag[7:5] > 4`) is ignored and counted in the
  `PROTO_ERR` counter, with no fault.

## 8. Reset (R-RST)

`rst_ni` is active-low, asynchronous assert, synchronous release supplied by the platform (AlbionCore convention).
Reset abandons the running command and every outstanding request on the link; the **target must be reset with the engine**
(or must discard those requests). Performance counters clear. `IBUF` / `OBUF` are RAMs and keep their contents. After
reset the engine is idle, `done_valid_o` is low and `cmd_ready_o` is high.

## 9. Performance counters (R-PERF)

`perf_o` holds `SP_PC_N` counters of `CNT_W` bits (index in `sf_sparse_pkg::SP_PC_*`): busy cycles, commands, faulting
commands, elements, data read / write requests, index/CSR array requests, requested bytes, **useful bytes**, merges,
duplicate hits, burst continuations, link stall cycles, request-table / reorder stalls, reorder occupancy (sum, max),
request-table occupancy (max), outstanding (max), bank-conflict estimate, data-read latency (sum, count, max), command
latency (sum, max), protocol errors. `perf_clear_i` clears them. Definitions and the interpretation of each are in
`docs/06_benchmarks.md`.
