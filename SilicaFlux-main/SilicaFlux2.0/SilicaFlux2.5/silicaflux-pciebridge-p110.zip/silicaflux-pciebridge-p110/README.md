# SilicaFlux Project 110 — PCIeBridge: a cloud host transaction interface

**Primary RTL:** `rtl/sf_pcie_transaction_bridge.sv` · Aureom.AI / SilicaFlux · delivered as this archive — **nothing was committed to GitHub**.

PCIeBridge is a synthesizable **transaction-layer bridge** between the SilicaFlux DataFabric / StreamDMA and a PCIe **endpoint
controller's application-side stream interface** (AMD UltraScale+ style CQ / CC / RQ / RC AXI4-Stream, DWORD-aligned,
128 or 256 bit). It lets a host CPU

* read and write chip **registers** and DataFabric windows through BAR MMIO (memory read / write TLPs, byte enables, completions),
* submit **protected DMA** descriptors per context and have the chip move data to and from host memory through StreamDMA,
* receive **interrupts** (MSI, or a documented polling-only mode),
* and recover from **link loss, FLR and soft resets** without ever reporting a lost transaction as a success.

> **Status — read this first.** Everything below is **RTL simulation** (Verilator, two stream widths) against an independent
> transaction-level host and a *simulated* endpoint, plus lint, mutation testing and Yosys generic-gate elaboration/synthesis
> estimates. **There is no PCIe endpoint controller, PHY, SerDes or FPGA PCIe hard-IP wrapper in this repository
> (`docs/00_AUDIT.md`), so this bridge has never been connected to one.** The endpoint interface is the publicly documented
> AMD UltraScale+ application interface, written from its public description and cross-checked only against open-source
> implementations — **not verified against a generated IP instance**. This is **not** a PCIe controller and makes **no
> compliance, interoperability, timing, area or power claim**. No hardware was used.

## Definition of done (brief) → status

| Required | Status |
|---|---|
| A transaction-level host accesses registers | **Met in simulation** (`tb_mmio`, both widths) |
| …initiates supported transfers | **Met in simulation** (`tb_dma`, `tb_rand`: host↔device DMA through StreamDMA, translated and untranslated; `tb_hostile`: the DMA adapter driven directly by an adversarial AXI master) |
| …receives correct completions | **Met in simulation** (independent monitors on every CC / RQ TLP, byte-exact data checks) |
| Bridge ready for a real compatible endpoint IP | **Prepared, not proven**: the interface is explicit and parameterised, every assumption is listed (`docs/02_ENDPOINT_INTERFACE.md §6`) and a bring-up plan exists (`docs/ENDPOINT_INTEGRATION_GUIDE.md`); none of it could be executed without IP and hardware |
| "Start with MMIO registers and a simulated endpoint; add real FPGA PCIe integration only when valid endpoint IP and hardware are available" | **Followed** |

## Results at a glance

| Item | Result |
|---|---|
| Regression (both widths + 4-tag `tb_dma`) | **15634 checks, 0 failures** |
| Pack/unpack unit test (4 configurations) | **1,004,890 checks, 0 failures** |
| Mutation testing | **99 / 99 planted defects killed**, 0 survived |
| Verilator `-Wall` lint | 0 warnings (DATA_W 128 and 256) |
| Yosys 0.33 `check -assert`, latch scan | all runs pass, no latches; top: 432,821 cells / 42,014 flip-flop cells (DATA_W 256), 299,337 / 40,275 (DATA_W 128) — **structure only, no timing/area/power claim** |
| Vendored StreamDMA sources | byte-identical to the repository archive (`make vendor`) |
| Real endpoint / hardware | **none** — never connected |


## Layout

```
rtl/          the bridge (sf_pcie_*.sv, sf_pcie_defs.svh, sf_pcie_regs.svh [generated], files.f)
tb/sv/        sf_pcie_sim_top.sv  (bridge + vendored StreamDMA + guard stand-in + mtype splitter + adversarial master)
tb/cpp/       the C++ transaction-level host, endpoint / root-complex / fabric / device models, scoreboards, benches
scripts/      build + run + lint + synth + mutation + register generator + vendor check
third_party/  StreamDMA P103 and its dependencies, UNMODIFIED (SHA256SUMS, PROVENANCE.md; `make vendor` re-verifies)
docs/         00 audit · 01 architecture · 02 endpoint interface · 03 register map (generated) · 04 ordering/errors ·
              05 DMA & protection · 06 interrupts · 07 reset/recovery · 08 simulation host · 09 verification ·
              10 performance · 11 limitations · ENDPOINT_INTEGRATION_GUIDE
reports/      regression.log · lint.log · mutation.md · perf_w128.md · perf_w256.md · synth/ (Yosys summary + logs)
```

## Deliverables (brief §14)

| Deliverable | Where |
|---|---|
| `sf_pcie_transaction_bridge.sv` | `rtl/` — the top: wiring, recovery FSM, CSR/IRQ/DMA fan-out |
| `sf_pcie_request_adapter.sv` | CQ descriptor decode, store-and-forward, TLP validation |
| `sf_pcie_completion_adapter.sv` | CC formatter + posted-write **ordering gate**; RC decode |
| `sf_pcie_bar_decoder.sv` | BAR / MMIO window decode and address validation |
| `sf_pcie_tag_tracker.sv` | outstanding table, out-of-order completion matching, timeouts, quarantine |
| `sf_pcie_dma_adapter.sv` | StreamDMA host port ⇄ RQ/RC, egress protection, planners, in-order delivery |
| `sf_pcie_interrupt_adapter.sv` | status/mask/vector map, MSI request, ordering gate, polling-only mode |
| supporting modules | `sf_pcie_axis_unpack/pack`, `sf_pcie_mmio_engine`, `sf_pcie_csr`, `sf_pcie_dma_submit`, `sf_pcie_dma_ctx`, `sf_pcie_win_check`, `sf_pcie_perf`, `sf_pcie_fifo` |
| simulation host + verification | `tb/`, `docs/08_SIM_HOST.md`, `docs/09_VERIFICATION.md` |
| endpoint integration guide | `docs/ENDPOINT_INTEGRATION_GUIDE.md` |
| synthesis reports | `reports/synth/` — **Yosys generic-gate estimates only** (no timing, no vendor mapping) |

## Quick start

```bash
make lint test axis        # Verilator lint, every bench at both widths, pack/unpack unit test
make perf                  # performance tables
make mutate                # 99-defect mutation campaign (about an hour on 4 cores)
make synth vendor          # Yosys estimates; verify the vendored sources
```

Requirements: Verilator ≥ 5.020, Yosys 0.33, Python 3, a C++17 compiler (Icarus 12 accepts the RTL too).

## What is *not* here

A PCIe link, PHY, SerDes, data-link layer, config space, BAR sizing, MSI-X, SR-IOV, atomics, I/O requests, messages, ECRC,
PageWalker/IOMMU-style translation (none exists in the repository — a contiguous-window constant-offset translation is provided),
timing/area/power numbers, hardware results. See `docs/11_LIMITATIONS.md` for the full list, the open items, and the
**common-mode risk** that limits what a green simulation can tell you.
