// Unit test of sf_pcie_axis_unpack / sf_pcie_axis_pack against an independent wire-format reference.
#include "Vtb_axis_unit.h"
#include "common.h"
#ifndef DW
#define DW 256
#endif
#ifndef HDW
#define HDW 4
#endif
static const int K = DW / 32;
struct Pkt { std::vector<uint32_t> hdr, pay; uint8_t user; };

static Vtb_axis_unit* d; static Checker C;
static void tick() { d->clk = 1; d->eval(); d->clk = 0; d->eval(); }

// independent reference: wire beats of a packet
struct WireBeat { std::vector<uint32_t> dw; uint32_t keep; bool last; };
static std::vector<WireBeat> encode(const Pkt& p, bool bad_hole = false) {
  std::vector<uint32_t> s = p.hdr; s.insert(s.end(), p.pay.begin(), p.pay.end());
  std::vector<WireBeat> out;
  for (size_t i = 0; i < s.size(); i += K) {
    WireBeat b; b.dw.assign(K, 0); b.keep = 0;
    for (int j = 0; j < K && i + j < s.size(); j++) { b.dw[j] = s[i + j]; b.keep |= 1u << j; }
    b.last = (i + K >= s.size()); out.push_back(b);
  }
  (void)bad_hole; return out;
}
static Pkt rand_pkt(Rng& r, int maxpay) {
  Pkt p; p.user = r.u32();
  for (int i = 0; i < HDW; i++) p.hdr.push_back(r.u32());
  int n = r.chance(15) ? 0 : (int)r.range(1, maxpay);
  for (int i = 0; i < n; i++) p.pay.push_back(r.u32());
  return p;
}
static void drive_wire(const WireBeat& b, uint8_t user) {
  uint32_t* w = W(d->u_tdata); for (int i = 0; i < DW / 32; i++) w[i] = b.dw[i];
  d->u_tkeep = b.keep; d->u_tlast = b.last; d->u_tuser = user;
}

static void test_unpack(Rng& r, int npk, int in_gap_pct, int out_stall_pct, bool inject, const char* name) {
  C.tag = name;
  std::deque<Pkt> exp; std::vector<std::vector<WireBeat>> wires; std::vector<bool> badflag;
  std::vector<std::vector<uint32_t>> gotpay(npk); std::vector<std::vector<uint32_t>> gothdr(npk);
  std::vector<int> gotbeats(npk, 0), gotsop(npk, 0), goteop(npk, 0), gotbad(npk, 0), gotuser(npk, -1), gotnonfull(npk, 0);
  std::vector<Pkt> pk;
  for (int i = 0; i < npk; i++) {
    Pkt p = rand_pkt(r, 70); pk.push_back(p);
    auto w = encode(p); bool bad = false;
    if (inject && r.chance(40)) {                 // framing defects
      int kind = r.below(3);
      if (kind == 0 && w.size() >= 2) { bad = true; w[0].keep = w[0].keep & ~(1u << (K - 1)); }              // short non-final beat
      else if (kind == 1 && w.back().keep != 0 && __builtin_popcount(w.back().keep) >= 2) { bad = true; w.back().keep &= ~1u; } // hole at lane 0 of last beat
      else if (kind == 2 && w.size() == 1) { bad = true; w[0].keep = 1; }                                       // header incomplete
    }
    wires.push_back(w); badflag.push_back(bad);
  }
  size_t pi = 0, bi = 0; int cur = 0; int cycles = 0; int done = 0;
  bool eop_seen_all = false;
  while (!eop_seen_all && cycles < 200000) {
    cycles++;
    bool offer = pi < wires.size() && !r.chance(in_gap_pct);
    d->u_tvalid = offer;
    if (pi < wires.size()) drive_wire(wires[pi][bi], pk[pi].user);
    d->u_ready = !r.chance(out_stall_pct);
    d->eval();
    if (d->u_tvalid && d->u_tready) { bi++; if (bi == wires[pi].size()) { pi++; bi = 0; } }
    if (d->u_valid && d->u_ready) {
      int k = cur; if (k >= npk) { C.ok(false, "extra output beat"); break; }
      const uint32_t* dd = WC(d->u_data); int n = d->u_ndw;
      if (d->u_sop) { gotsop[k]++; const uint32_t* h = WC(d->u_hdr); for (int i = 0; i < HDW; i++) gothdr[k].push_back(h[i]); gotuser[k] = d->u_user; }
      for (int i = 0; i < n; i++) gotpay[k].push_back(dd[i]);
      if (!d->u_eop && n != K) gotnonfull[k]++;
      gotbeats[k]++;
      if (d->u_eop) { goteop[k]++; gotbad[k] = d->u_bad; cur++; done++; if (done == npk) eop_seen_all = true; }
    }
    tick();
  }
  C.ok(eop_seen_all, "all packets emerged", done, npk);
  for (int k = 0; k < npk && k < done; k++) {
    C.ok(gotsop[k] == 1, "exactly one sop per packet", gotsop[k]);
    C.ok(goteop[k] == 1, "exactly one eop per packet", goteop[k]);
    C.ok(gotnonfull[k] == 0, "non-final beats are full");
    C.ok((bool)gotbad[k] == badflag[k], "bad flag matches injected defect", gotbad[k], badflag[k]);
    if (!badflag[k]) {
      C.ok(gothdr[k] == pk[k].hdr, "header identical");
      C.ok(gotpay[k] == pk[k].pay, "payload identical", gotpay[k].size(), pk[k].pay.size());
      { int n = (int)pk[k].pay.size(); int nb = std::max(1, (n + K - 1) / K);
        C.ok(gotbeats[k] == nb, "canonical beat count (no empty trailing beat)", gotbeats[k], nb); }
      C.ok(gotuser[k] == pk[k].user, "user captured at sop", gotuser[k], pk[k].user);
    }
  }
}

static void test_pack(Rng& r, int npk, int in_gap_pct, int out_stall_pct, const char* name) {
  C.tag = name;
  std::vector<Pkt> pk; for (int i = 0; i < npk; i++) pk.push_back(rand_pkt(r, 70));
  // expected wire beats of every packet concatenated
  std::vector<WireBeat> exp; std::vector<uint8_t> expuser;
  for (auto& p : pk) { auto w = encode(p); for (auto& b : w) { exp.push_back(b); expuser.push_back(p.user); } }
  size_t pi = 0; size_t beat = 0; size_t got = 0; int cycles = 0;
  while (got < exp.size() && cycles < 400000) {
    cycles++;
    bool have = pi < pk.size();
    int n = have ? (int)pk[pi].pay.size() : 0; int nb = std::max(1, (n + K - 1) / K);
    d->p_valid = have && !r.chance(in_gap_pct);
    d->p_sop = beat == 0; d->p_eop = (int)beat == nb - 1;
    uint32_t* w = W(d->p_data); for (int i = 0; i < K; i++) w[i] = 0;
    int cnt = 0; if (have) { for (int i = 0; i < K; i++) { size_t ix = beat * K + i; if (ix < pk[pi].pay.size()) { w[i] = pk[pi].pay[ix]; cnt++; } } }
    d->p_ndw = cnt;
    uint32_t* h = W(d->p_hdr); if (have) for (int i = 0; i < HDW; i++) h[i] = pk[pi].hdr[i];
    d->p_user = have ? pk[pi].user : 0;
    d->m_tready = !r.chance(out_stall_pct);
    d->eval();
    if (d->p_valid && d->p_ready) { beat++; if ((int)beat == nb) { beat = 0; pi++; } }
    if (d->m_tvalid && d->m_tready) {
      C.ok(got < exp.size(), "no extra wire beat"); if (got >= exp.size()) break;
      const uint32_t* o = WC(d->m_tdata);
      C.ok((uint32_t)d->m_tkeep == exp[got].keep, "tkeep", d->m_tkeep, exp[got].keep);
      C.ok((bool)d->m_tlast == exp[got].last, "tlast", d->m_tlast, exp[got].last);
      for (int i = 0; i < K; i++) if (exp[got].keep & (1u << i)) C.ok(o[i] == exp[got].dw[i], "wire dword", o[i], exp[got].dw[i]);
      C.ok((uint8_t)d->m_tuser == expuser[got], "tuser", d->m_tuser, expuser[got]);
      got++;
    }
    tick();
  }
  C.ok(got == exp.size(), "all wire beats produced", got, exp.size());
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  d = new Vtb_axis_unit; Rng r(0xA11CE + DW + HDW);
  d->clk = 0; d->rst_n = 0; d->flush = 0; d->u_tvalid = 0; d->u_ready = 0; d->p_valid = 0; d->m_tready = 0; d->eval();
  for (int i = 0; i < 3; i++) tick(); d->rst_n = 1; tick();
  const int gaps[3] = {0, 30, 70}, stalls[3] = {0, 30, 70};
  for (int g = 0; g < 3; g++) for (int s = 0; s < 3; s++) {
    char nm[64];
    std::snprintf(nm, sizeof nm, "unpack gap%d stall%d", gaps[g], stalls[s]); test_unpack(r, 400, gaps[g], stalls[s], false, nm);
    std::snprintf(nm, sizeof nm, "pack gap%d stall%d", gaps[g], stalls[s]);   test_pack(r, 400, gaps[g], stalls[s], nm);
  }
  test_unpack(r, 600, 20, 20, true, "unpack malformed framing");
  // flush in the middle of a packet: the next packet must be clean
  {
    C.tag = "unpack flush";
    Pkt p = rand_pkt(r, 70); while (p.pay.size() < 3 * K) p.pay.push_back(r.u32());
    auto w = encode(p);
    for (size_t i = 0; i + 1 < w.size(); i++) {   // send all but the last beat
      d->u_tvalid = 1; drive_wire(w[i], p.user); d->u_ready = 1; d->eval(); if (d->u_tready) { tick(); } else { tick(); i--; }
    }
    d->u_tvalid = 0; d->flush = 1; tick(); d->flush = 0; tick();
    test_unpack(r, 50, 10, 10, false, "unpack after flush");
  }
  std::printf("tb_axis_unit DATA_W=%d HDR_DW=%d: %d checks, %d failures\n", DW, HDW, C.checks, C.fails);
  delete d; return C.fails ? 1 : 0;
}
