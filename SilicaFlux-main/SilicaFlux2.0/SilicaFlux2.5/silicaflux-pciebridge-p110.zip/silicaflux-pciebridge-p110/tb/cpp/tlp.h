// TLP model + AMD UltraScale+ style CQ/CC/RQ/RC stream codec for the P110 benches.
// Written independently of the RTL, from the field tables in docs/02_ENDPOINT_INTERFACE.md.
#pragma once
#include "common.h"
#include <type_traits>

namespace tlp {

enum ReqType { MRD = 0, MWR = 1, IORD = 2, IOWR = 3, FADD = 4, SWAP = 5, CAS = 6, MRDLK = 7, MSG = 8, MSGV = 9 };
enum CplStatus { SC = 0, UR = 1, CRS = 2, CA = 4 };
enum RcErr { RCE_NONE = 0, RCE_POISON = 1, RCE_BADSTATUS = 2, RCE_INVLEN = 3, RCE_MISMATCH = 4, RCE_INVADDR = 5, RCE_INVTAG = 6, RCE_FLR = 8, RCE_TIMEOUT = 9 };

struct Req {                                   // a request TLP as seen at CQ (host -> device) or RQ (device -> host)
  int type = MRD; uint64_t addr = 0; uint32_t ndw = 1; uint8_t fbe = 0xF, lbe = 0; uint16_t tag = 0; uint16_t reqid = 0x0100;
  uint8_t tc = 0, attr = 0, at = 0; bool poison = false; uint8_t bar_id = 0, bar_ap = 16, func = 0; uint8_t seq = 0;
  std::vector<uint32_t> data;
};
struct Cpl {                                   // completion at CC (device -> host) or RC (host -> device)
  uint8_t status = SC; uint16_t reqid = 0x0100; uint16_t tag = 0; uint8_t lower = 0; uint16_t bytecnt = 0; uint32_t ndw = 0;
  uint8_t err = 0; bool poison = false; bool req_done = false; uint8_t tc = 0, attr = 0; uint16_t cplid = 0;
  std::vector<uint32_t> data;
};
struct Beat { std::vector<uint32_t> dw; uint32_t keep = 0; bool last = false; uint64_t user = 0; bool tbad = false; };

inline int K(int dw) { return dw / 32; }

// ---- DW sequence <-> beats ----------------------------------------------------------------------------------------
inline std::vector<Beat> pack(const std::vector<uint32_t>& s, int dw) {
  int k = K(dw); std::vector<Beat> out;
  for (size_t i = 0; i < s.size(); i += k) {
    Beat b; b.dw.assign(k, 0);
    for (int j = 0; j < k && i + j < s.size(); j++) { b.dw[j] = s[i + j]; b.keep |= 1u << j; }
    b.last = (i + k >= s.size()); out.push_back(b);
  }
  return out;
}

// ---- CQ (host -> device request) ------------------------------------------------------------------------------------
inline std::vector<uint32_t> cq_hdr(const Req& r) {
  std::vector<uint32_t> h(4, 0);
  h[0] = (uint32_t)(r.addr & 0xFFFFFFFCull) | (r.at & 3);
  h[1] = (uint32_t)(r.addr >> 32);
  h[2] = (r.ndw & 0x7FF) | ((uint32_t)(r.type & 0xF) << 11) | ((uint32_t)r.poison << 15) | ((uint32_t)r.reqid << 16);
  h[3] = (r.tag & 0xFF) | ((uint32_t)r.func << 8) | ((uint32_t)(r.bar_id & 7) << 16) | ((uint32_t)(r.bar_ap & 63) << 19) |
         ((uint32_t)(r.tc & 7) << 25) | ((uint32_t)(r.attr & 7) << 28);
  return h;
}
// beats of a CQ TLP; `payload_override` lets tests send a stream that disagrees with the descriptor
inline std::vector<Beat> cq_beats(const Req& r, int dw, const std::vector<uint32_t>* payload_override = nullptr, int disc_beat = -1) {
  std::vector<uint32_t> s = cq_hdr(r); const auto& p = payload_override ? *payload_override : r.data;
  s.insert(s.end(), p.begin(), p.end());
  auto b = pack(s, dw);
  b[0].user = (r.fbe & 0xF) | ((uint64_t)(r.lbe & 0xF) << 4);                  // first/last BE are valid on the first beat only
  if (disc_beat >= 0 && disc_beat < (int)b.size()) b[disc_beat].user |= (1ull << 41);
  return b;
}

// ---- RC (host -> device completion) --------------------------------------------------------------------------------
inline std::vector<Beat> rc_beats(const Cpl& c, int dw) {
  std::vector<uint32_t> s(3, 0);
  s[0] = (c.lower & 0x7F) | ((uint32_t)(c.err & 0xF) << 12) | ((uint32_t)(c.bytecnt & 0x1FFF) << 16) | ((uint32_t)c.req_done << 30);
  s[1] = (c.ndw & 0x7FF) | ((uint32_t)(c.status & 7) << 11) | ((uint32_t)c.poison << 14) | ((uint32_t)c.reqid << 16);
  s[2] = (c.tag & 0xFF) | ((uint32_t)c.cplid << 8) | ((uint32_t)(c.tc & 7) << 25) | ((uint32_t)(c.attr & 7) << 28);
  s.insert(s.end(), c.data.begin(), c.data.end());
  return pack(s, dw);
}

// ---- decode helpers (device -> host streams) ------------------------------------------------------------------------
inline std::vector<uint32_t> flat(const std::vector<Beat>& bs) {
  std::vector<uint32_t> s;
  for (auto& b : bs) for (size_t j = 0; j < b.dw.size(); j++) if (b.keep & (1u << j)) s.push_back(b.dw[j]);
  return s;
}
inline bool cc_decode(const std::vector<Beat>& bs, Cpl& c) {          // false if the stream is too short to hold a descriptor
  auto s = flat(bs); if (s.size() < 3) return false;
  c = Cpl();
  c.lower = s[0] & 0x7F; c.bytecnt = (s[0] >> 16) & 0x1FFF; c.ndw = s[1] & 0x7FF; c.status = (s[1] >> 11) & 7; c.poison = (s[1] >> 14) & 1;
  c.reqid = s[1] >> 16; c.tag = s[2] & 0xFF; c.cplid = (s[2] >> 8) & 0xFFFF; c.tc = (s[2] >> 25) & 7; c.attr = (s[2] >> 28) & 7;
  c.data.assign(s.begin() + 3, s.end()); return true;
}
inline bool rq_decode(const std::vector<Beat>& bs, Req& r) {
  auto s = flat(bs); if (s.size() < 4) return false;
  r = Req();
  r.at = s[0] & 3; r.addr = ((uint64_t)s[1] << 32) | (s[0] & 0xFFFFFFFCu); r.ndw = s[2] & 0x7FF; r.type = (s[2] >> 11) & 0xF;
  r.poison = (s[2] >> 15) & 1; r.reqid = s[2] >> 16; r.tag = s[3] & 0xFF; r.tc = (s[3] >> 25) & 7; r.attr = (s[3] >> 28) & 7;
  r.fbe = bs[0].user & 0xF; r.lbe = (bs[0].user >> 4) & 0xF;
  r.seq = ((bs[0].user >> 24) & 0xF) | (((bs[0].user >> 60) & 3) << 4);
  r.data.assign(s.begin() + 4, s.end()); return true;
}

// ---- PCIe rules used by the independent checkers -----------------------------------------------------------------------
inline int lo_byte(uint8_t be) { for (int i = 0; i < 4; i++) if (be & (1 << i)) return i; return 0; }
inline int hi_byte(uint8_t be) { for (int i = 3; i >= 0; i--) if (be & (1 << i)) return i; return 0; }
// bytes a read request asks for (byte count of its first completion)
inline uint32_t read_bytes(uint32_t ndw, uint8_t fbe, uint8_t lbe) {
  if (ndw == 1) return fbe ? (hi_byte(fbe) - lo_byte(fbe) + 1) : 1;
  return 4 * ndw - lo_byte(fbe) - (3 - hi_byte(lbe));
}
inline bool be_legal(uint32_t ndw, uint8_t f, uint8_t l) {              // the byte-enable policy of the bridge (docs/04)
  if (ndw == 1) return l == 0;
  if (ndw == 2) return f != 0 && l != 0;
  bool fo = f == 0xF || f == 0xE || f == 0xC || f == 0x8; bool lo = l == 0xF || l == 0x7 || l == 0x3 || l == 0x1;
  return fo && lo;
}
inline bool crosses_4k(uint64_t addr, uint32_t ndw) { return ((addr & 0xFFF) + 4ull * ndw) > 4096; }

}  // namespace tlp
