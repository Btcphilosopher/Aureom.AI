// All test programs in one executable (one Verilator compile per mutant).  usage: bench [quick|full]
#include <cstring>
#include <cstdio>
#include <cstdarg>
#include "tb_dma_lib.h"          // common headers at global scope; the test files' own includes become no-ops
#define main mmio_main
namespace t_mmio {
#include "tb_mmio.cpp"
}
#undef main
#define main dma_main
namespace t_dma {
#include "tb_dma.cpp"
}
#undef main
#define main irq_main
namespace t_irq {
#include "tb_irq.cpp"
}
#undef main
#define main reset_main
namespace t_reset {
#include "tb_reset.cpp"
}
#undef main
#define main hostile_main
namespace t_hostile {
#include "tb_hostile.cpp"
}
#undef main
#define main rand_main
namespace t_rand {
#include "tb_rand.cpp"
}
#undef main
#define main race_main
namespace t_race {
#include "tb_race.cpp"
}
#undef main

int main(int argc, char** argv) {
  const char* only = argc > 1 ? argv[1] : nullptr;                      // run a single program, e.g. "mmio"
  char* a0[] = {argv[0], nullptr};
  struct { const char* n; int (*f)(int, char**); } progs[] = {
    {"mmio", t_mmio::mmio_main}, {"hostile", t_hostile::hostile_main}, {"irq", t_irq::irq_main}, {"dma", t_dma::dma_main},
    {"reset", t_reset::reset_main}, {"race", t_race::race_main}, {"rand", t_rand::rand_main}};
  int rc = 0;
  for (auto& p : progs) {
    if (only && std::strcmp(only, p.n)) continue;
    int r;
    if (!std::strcmp(p.n, "rand")) { char s1[] = "25", s2[] = "40", s3[] = "5000"; char* a[] = {argv[0], s1, s2, s3, nullptr}; r = p.f(4, a); }
    else r = p.f(1, a0);
    std::printf("[%s] %s\n", p.n, r ? "FAIL" : "ok");
    if (r) { rc = 1; break; }
  }
  return rc;
}
