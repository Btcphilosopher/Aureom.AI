// Reset / recovery tests: link down, FLR, soft resets, hard reset, repeated flaps -- under MMIO and DMA load.
// Rule under test: a transaction that was lost is NEVER reported as successful, and the device comes back usable.
#include "tb_dma_lib.h"
#ifdef PUBLIC_DBG
#include "Vsf_pcie_sim_top___024root.h"
#endif
using namespace env;
static Checker C;
struct Test { const char* name; std::function<void(Env&)> fn; };
static void finish(Env& e, const char* what) { e.idle(400); C.ok(e.no_violations(), what, e.n_viol); if (!e.no_violations()) e.print_violations(); }

static bool wait_recovered(Env& e, uint64_t maxc = 400000) {
  e.idle(4);
  return e.run_until([&]() { return e.d->rec_state == 0 && !e.d->rec_flush_mmio && !e.d->rec_flush_dma && e.link_up && !e.flr; }, maxc);
}
static void flap(Env& e, int down_cycles = 60) { e.link_down(); e.idle(down_cycles); e.link_up = true; }

// polls for the (single) record or the LOST flag; returns true if the transfer is accounted for as FAILED
static bool failed_not_ok(Env& e, Dma& dma, int ctx, uint32_t len, const char* what) {
  uint32_t pg = dma.page(ctx);
  uint32_t st = e.r32(0, pg + sfpb::C_CPL_STATUS);
  bool have = (st & 0xF) != 0, lost = (st >> 9) & 1;
  if (have) {
    CplRec r; dma.wait_record(ctx, r);
    bool ok = r.status != 0 || r.done < len;
    C.ok(ok, what, r.status, r.done);
    C.ok(!(r.status == 0 && r.done == len), "an interrupted transfer is never reported as complete", r.status);
    return ok;
  }
  C.ok(lost, "no record -> the LOST flag tells the host (never a silent success)", st);
  return lost;
}
static void expect_good_dma(Env& e, Dma& dma, uint16_t txn, const char* what) {
  e.w32(0, sfpb::R_CTRL, 0x27);
  uint64_t src = HOST0_IOVA + 0x300, dst = DEV_BASE + 0x500; const uint32_t len = 1000;
  dma.fill_host(0, src, len); auto s = dma.h2d(0, txn, src, dst, len);
  C.ok(s.status() == 1, "post-recovery descriptor accepted", s.status(), s.code());
  CplRec r; bool got = dma.wait_record(0, r); C.ok(got && r.status == 0 && r.done == len, what, r.status, r.done);
#ifdef PUBLIC_DBG
  if (!(got && r.status == 0 && r.done == len)) {
    auto* rp = e.d->rootp;
    std::printf("   [dbg] dma_idle=%d sub_busy=%d sd_busy=%d arp_v=%d awp_v=%d rp_v=%d wp_v=%d rdc=%d wrc=%d wm=%d bq=%d b_st=%d sq_st=%d r_busy=%d wb_used=%d st_out=%d zomb=%d slot0=%d/%d/%d slot1=%d/%d/%d\n",
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__dma_idle, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__sub_busy, (int)rp->sf_pcie_sim_top__DOT__sd_busy,
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__arp_v, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__awp_v,
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__rp_v, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__wp_v,
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__rdc_out_v, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__wrc_out_v,
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__wm_out_v, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__bq_out_v,
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__b_st, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__sq_st,
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__r_busy, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__wb_used,
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__trk_out, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__st_zombie,
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__slot_busy[0], (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__slot_all[0], (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__slot_pend[0],
      (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__slot_busy[1], (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__slot_all[1], (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__slot_pend[1]);
  }
#endif
  if (!(got && r.status == 0 && r.done == len)) std::printf("    rec: txn=0x%x status=%d err=0x%02X detail=%d perr=0x%02X done=%u total=%u eaddr=0x%llx\n", r.txn, r.status, r.err, r.detail, r.perr, r.done, r.total, (unsigned long long)r.eaddr);
  C.ok(dma.dev_equals_host(0, dst, src, len), "post-recovery DMA data identical");
}

static void t_link_idle(Env& e) {
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 200); e.w32(0, sfpb::R_IRQ_MASK, 0xFF);
  e.w32(0, sfpb::R_ERR_LOG_CLR, 1); e.w32(0, sfpb::R_ERR_STATUS, 0xFFFF);
  flap(e); C.ok(wait_recovered(e), "recovery completes");
  e.idle(50);
  uint32_t es = e.r32(0, sfpb::R_ERR_STATUS); C.ok((es >> 11) & 1, "ERR_STATUS.LINK set", es); C.ok((es >> 13) & 1, "ERR_STATUS.RECOVERED set (host must re-initialise)", es);
  uint32_t l0 = e.r32(0, sfpb::R_ERR_LOG0); C.ok((l0 & 0x100) && (l0 & 0x3F) == 0x3C, "error log names LINK_DOWN", l0);
  C.ok((e.r32(0, sfpb::R_IRQ_STATUS) >> 3) & 1, "recovery interrupt source is pending");
  uint32_t st = e.r32(0, sfpb::R_STATUS); C.ok(((st >> 8) & 0xFF) == 0 && ((st >> 16) & 0xFF) == 0, "no outstanding requests, no quarantined tags", st);
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0, "(a link loss alone does not reset host-visible registers: scratch unchanged = 0)");
  e.w32(0, sfpb::R_SCRATCH, 0xABCD1234); e.idle(100); flap(e); wait_recovered(e); C.ok(e.r32(0, sfpb::R_SCRATCH) == 0xABCD1234u, "link loss alone preserves host-visible register state");
  expect_good_dma(e, dma, 0x10, "DMA works after the link flap");
  finish(e, "link_idle: no violations");
}

static void t_dma_read(Env& e) {
  e.cfg.host_lat_lo = 80; e.cfg.host_lat_hi = 250;
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 400);
  const uint32_t len = 65536; dma.fill_host(0, HOST0_IOVA, len);
  auto s = dma.h2d(0, 0x20, HOST0_IOVA, DEV_BASE, len); C.ok(s.status() == 1, "accepted", s.status(), s.code());
  C.ok(e.run_until([&]() { return e.rq_accepted >= 8 && e.n_rc_tlps >= 2; }, 100000), "transfer is under way");
  flap(e, 120); C.ok(wait_recovered(e), "recovery completes under load");
  failed_not_ok(e, dma, 0, len, "interrupted read transfer reported as FAILED");
  // all device-side state was wiped: nothing pending, no zombies
  e.idle(100); uint32_t st = e.r32(0, sfpb::R_STATUS); C.ok(((st >> 8) & 0xFF) == 0 && ((st >> 16) & 0xFF) == 0 && !((st >> 3) & 1), "nothing outstanding, no zombies, DMA idle", st);
  uint32_t cs = e.r32(0, dma.page(0) + sfpb::C_CPL_STATUS); C.ok((cs >> 16) == 0, "per-context pending count was reset", cs >> 16);
  e.w32(0, dma.page(0) + sfpb::C_CPL_POP, 4);                       // clear LOST
  expect_good_dma(e, dma, 0x21, "fresh DMA after recovery");
  finish(e, "reset_dma_read: no violations");
}

static void t_dma_write(Env& e) {
  e.cfg.link_rq = 100;
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 400);
  const uint32_t len = 65536; dma.fill_dev(DEV_BASE, len);
  auto s = dma.d2h(0, 0x30, DEV_BASE, HOST0_IOVA, len); C.ok(s.status() == 1, "accepted", s.status(), s.code());
  C.ok(e.run_until([&]() { return e.rq_accepted >= 6; }, 100000), "writes are under way");
  flap(e, 100); C.ok(wait_recovered(e), "recovery completes under load");
  failed_not_ok(e, dma, 0, len, "interrupted write transfer reported as FAILED");
  e.w32(0, dma.page(0) + sfpb::C_CPL_POP, 4);
  expect_good_dma(e, dma, 0x31, "fresh DMA after recovery");
  finish(e, "reset_dma_write: no violations");
}

static void t_mmio(Env& e) {
  e.cfg.fab_lat_lo = 30; e.cfg.fab_lat_hi = 60;
  e.w32(0, sfpb::R_REC_QUIET, 200);
  for (int i = 0; i < 16; i++) e.w32(2, 4 * i, 0x1000 + i);
  e.run_until([&]() { return e.cq_q.empty() && !e.cq_offer; }, 100000); e.idle(400);   // the writes must have been executed before the link drops
  for (int i = 0; i < 24; i++) e.mmio_read_start(2, 4 * (i % 16));
  e.idle(40);                                                         // some are mid-flight
  flap(e, 80); C.ok(wait_recovered(e), "recovery completes");
  e.idle(500);                                                        // any stale completion would now show up as 'unknown tag' violations
  int bad = 0; for (int i = 0; i < 16; i++) { auto h = e.mmio_read(2, 4 * i); if (h.bad || h.data.size() != 1 || h.data[0] != (uint32_t)(0x1000 + i)) bad++; }
  C.ok(bad == 0, "MMIO works after recovery and earlier writes persisted", bad);
  C.ok(e.no_violations(), "no stale completion was emitted after the recovery", e.n_viol);
  if (!e.no_violations()) e.print_violations();
  uint32_t st = e.r32(0, sfpb::R_STATUS); C.ok(!((st >> 2) & 1), "fabric port is not fatal after a clean recovery", st);
  finish(e, "reset_mmio: no violations");
}

static void t_flr(Env& e) {
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 200);
  e.w32(0, sfpb::R_SCRATCH, 0x13572468); e.w32(0, sfpb::R_IRQ_MASK, 0xFF); e.w32(0, sfpb::R_ERR_MASK, 0x0001); e.w32(0, sfpb::R_DMA_TYPE_EN, 0x1F);
  e.w32(0, sfpb::R_ERR_LOG_CLR, 1);
  dma.fill_host(0, HOST0_IOVA, 32768); auto s = dma.h2d(0, 0x40, HOST0_IOVA, DEV_BASE, 32768); C.ok(s.status() == 1, "accepted", s.status());
  e.run_until([&]() { return e.rq_accepted >= 3; }, 100000);
  e.link_down(); e.link_up = true; e.flr = true;                       // FLR: link stays up, function reset in progress
  bool saw_done = e.run_until([&]() { return e.d->ep_flr_done == 1; }, 100000); C.ok(saw_done, "the bridge reports FLR cleanup done (ep_flr_done)");
  e.flr = false; C.ok(wait_recovered(e), "recovery completes");
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0, "FLR returns host-visible registers to defaults (scratch)");
  C.ok(e.r32(0, sfpb::R_IRQ_MASK) == 0 && e.r32(0, sfpb::R_ERR_MASK) == 0xFFFF && e.r32(0, sfpb::R_DMA_TYPE_EN) == 3, "masks and DMA type enables are back to reset values");
  C.ok(e.r32(0, sfpb::R_CTRL) == 0x23, "CTRL is back to reset (DMA disabled until the driver re-enables it)", e.r32(0, sfpb::R_CTRL));
  uint32_t l0 = e.r32(0, sfpb::R_ERR_LOG0); C.ok((l0 & 0x100) && (l0 & 0x3F) == 0x3D, "diagnostics survive: error log names FLR", l0);
  uint32_t ci = e.priv_rd(0x00 + sfpb::P_CTX_CTRL); C.ok((ci & 1) == 1, "the privileged context table survives (it is not host state)", ci);
  auto s2 = dma.h2d(0, 0x41, HOST0_IOVA, DEV_BASE, 64); C.ok(s2.status() == 3 && s2.code() == 0x30, "DMA is disabled until re-enabled (NO_CTX/disabled)", s2.status(), s2.code());
  expect_good_dma(e, dma, 0x42, "DMA works after the driver re-initialises");
  finish(e, "flr: no violations");
}

static void t_soft(Env& e) {
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 200);
  e.w32(0, sfpb::R_SCRATCH, 0x24681357);
  e.w32(0, sfpb::R_CTRL, 0x127);                                        // SOFT_RESET (bit 8) with DMA_EN
  C.ok(wait_recovered(e), "soft reset recovery completes"); e.idle(50);
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0, "soft reset restores register defaults");
  uint32_t l0 = e.r32(0, sfpb::R_ERR_LOG0); C.ok((l0 & 0x3F) == 0x3E, "error log names SOFT_RESET", l0);
  expect_good_dma(e, dma, 0x50, "DMA works after the soft reset");
  finish(e, "soft: no violations");
}

static void t_dma_soft(Env& e) {
  e.cfg.host_lat_lo = 100; e.cfg.host_lat_hi = 200;
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 800);
  e.w32(0, sfpb::R_SCRATCH, 0x77777777);
  dma.fill_host(0, HOST0_IOVA, 65536); auto s = dma.h2d(0, 0x60, HOST0_IOVA, DEV_BASE, 65536); C.ok(s.status() == 1, "accepted", s.status());
  e.run_until([&]() { return e.rq_accepted >= 4; }, 100000);
  e.w32(0, sfpb::R_DMA_CTRL, 2);                                        // DMA_CTRL.SOFT_RESET: only the DMA path is recovered
  C.ok(e.run_until([&]() { return e.d->rec_state == 4; }, 200000), "the recovery reaches its quiet period");     // 4 = SFPB_REC_QUIET (MMIO is NOT flushed in a DMA-only recovery)
  { uint32_t stq = e.r32(0, sfpb::R_STATUS); C.ok(((stq >> 16) & 0xFF) > 0, "tags lost to the reset are quarantined during the quiet period (N_ZOMBIE > 0)", (stq >> 16) & 0xFF); }
  int served = 0, bad = 0;                                              // MMIO keeps being served during the recovery
  for (int i = 0; i < 12; i++) { auto h = e.mmio_read(0, sfpb::R_ID); served++; if (h.bad || h.data.empty() || h.data[0] != 0x53465042u) bad++; }
  C.ok(bad == 0, "MMIO reads were answered while the DMA path recovered", bad, served);
  C.ok(wait_recovered(e), "DMA-only recovery completes");
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0x77777777u, "host-visible state untouched by a DMA-only reset");
  failed_not_ok(e, dma, 0, 65536, "the interrupted transfer is reported as FAILED");
  e.w32(0, dma.page(0) + sfpb::C_CPL_POP, 4);
  expect_good_dma(e, dma, 0x61, "DMA works after the DMA-only reset");
  finish(e, "dma_soft: no violations");
}

static void t_read_midburst(Env& e) {
  // A read burst is loaded in the planner but its TLPs cannot be issued (non-posted credits withheld) when the link dies.  The
  // planner's abort path must fail the burst: handing the slot to StreamDMA as "OKAY" would let a transfer whose data was NEVER
  // fetched report success.  (256 B with MRRS = 128 B is two TLPs; the abort path is the same wherever in the burst the planner is.)
  e.cfg.mrrs_code = 0; e.cfg.host_lat_lo = 100; e.cfg.host_lat_hi = 200;
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 200);
  e.hook_drive = [&]() { e.d->fc_np_ok = 0; };
  dma.fill_host(0, HOST0_IOVA, 256);
  auto s = dma.h2d(0, 0x80, HOST0_IOVA, DEV_BASE, 256); C.ok(s.status() == 1, "accepted", s.status());
  e.idle(300);
  size_t reads = 0; for (auto& r : e.rqlog) reads += (r.type == MRD);
  C.ok(reads == 0, "precondition: no read TLP has left (the burst is parked in the planner)", reads);
  flap(e); C.ok(wait_recovered(e), "recovery completes");
  e.hook_drive = nullptr; e.d->fc_np_ok = 1;
  failed_not_ok(e, dma, 0, 256, "the parked burst is reported as FAILED");
  e.w32(0, dma.page(0) + sfpb::C_CPL_POP, 4);
  expect_good_dma(e, dma, 0x81, "DMA works after the recovery");
  finish(e, "read_midburst: no violations");
}

static void t_wait_link(Env& e) {
  // After the DMA path was wiped the FSM must WAIT in WAIT_LINK for as long as the link is down (not run the quiet period against a dead link).
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 100);
  e.link_down();
  bool seen = false; int bad = 0, n = 0;
  e.hook_sample = [&]() { int s = e.d->rec_state; if (s == 3) seen = true; if (seen) { n++; if (s != 3) bad++; } };       // 3 = SFPB_REC_WAIT_LINK
  e.idle(2500);
  e.hook_sample = nullptr;
  C.ok(seen && n > 1500 && bad == 0, "the FSM stays in WAIT_LINK for as long as the link is down", bad, n);
  e.link_up = true; C.ok(wait_recovered(e), "recovery completes once the link returns");
  expect_good_dma(e, dma, 0xA0, "DMA works after the long outage");
  finish(e, "wait_link: no violations");
}

static void t_lost(Env& e) {
  // The device side stops answering write responses, so StreamDMA's transfer cannot finish and the recovery's drain times out.  The wipe
  // then drops a descriptor for which NO completion record will ever exist: the LOST flag is the host's only evidence that it is gone.
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 100);
  e.dev_hold_b = true;
  dma.fill_host(0, HOST0_IOVA, 4096); auto s = dma.h2d(0, 0x90, HOST0_IOVA, DEV_BASE, 4096); C.ok(s.status() == 1, "accepted", s.status());
  e.idle(3000);
  uint32_t st0 = e.r32(0, dma.page(0) + sfpb::C_CPL_STATUS); C.ok((st0 & 0xF) == 0 && (st0 >> 16) == 1, "precondition: the transfer is stuck (no record, one descriptor pending)", st0);
  flap(e); C.ok(wait_recovered(e, 800000), "recovery completes (after the drain timeout)");
  e.dev_hold_b = false;
  uint32_t st = e.r32(0, dma.page(0) + sfpb::C_CPL_STATUS);
  C.ok((st & 0xF) == 0 && ((st >> 9) & 1) && (st >> 16) == 0, "no record exists, LOST is set and nothing is left pending", st);
  e.w32(0, dma.page(0) + sfpb::C_CPL_POP, 4);
  expect_good_dma(e, dma, 0x91, "DMA works afterwards");
  finish(e, "lost: no violations");
}

static void t_hard(Env& e) {
  Dma dma(e); dma.setup_defaults();
  e.w32(0, sfpb::R_SCRATCH, 0x99999999);
  dma.fill_host(0, HOST0_IOVA, 32768); dma.h2d(0, 0x70, HOST0_IOVA, DEV_BASE, 32768);
  e.run_until([&]() { return e.rq_accepted >= 2; }, 100000);
  for (int i = 0; i < 10; i++) e.mmio_read_start(2, 4 * i);
  e.idle(20);
  e.cq_q.clear(); e.cq_offer = false; e.cq_i = 0; e.rc_ready.clear(); e.rc_sched.clear(); e.rc_offer = false; e.rc_i = 0; e.arrivals.clear(); e.ack_due.clear(); e.reads.clear(); e.root_tags.clear(); e.root_ord.clear(); e.root_open.clear();
  e.reset_dut(); e.idle(50);
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0, "asynchronous reset returns everything to defaults");
  uint32_t st = e.r32(0, sfpb::R_STATUS); C.ok((st & 1) && ((st >> 8) & 0xFF) == 0 && (st >> 24 & 0xF) == 0, "status is clean after a hard reset", st);
  uint32_t ci = e.priv_rd(sfpb::P_CTX_CTRL); C.ok((ci & 1) == 0, "the context table is cleared by a hard reset (must be reprogrammed)", ci);
  Dma d2(e); d2.setup_defaults(); expect_good_dma(e, d2, 0x71, "DMA works after hard reset + re-programming");
  finish(e, "hard: no violations");
}

static void t_flaps(Env& e) {
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_REC_QUIET, 150);
  e.cfg.host_lat_lo = 20; e.cfg.host_lat_hi = 120; e.cfg.fab_lat_hi = 8;
  for (int round = 0; round < 8; round++) {
    // random mixed load
    uint32_t len = 2048 + e.rng.below(20000); bool h2d = round & 1;
    if (h2d) { dma.fill_host(0, HOST0_IOVA + 0x1000, len); dma.h2d(0, 0x80 + round, HOST0_IOVA + 0x1000, DEV_BASE + 0x100, len); }
    else     { dma.fill_dev(DEV_BASE + 0x100, len); dma.d2h(0, 0x80 + round, DEV_BASE + 0x100, HOST0_IOVA + 0x1000, len); }
    for (int i = 0; i < 6; i++) { e.w32(2, 4 * e.rng.below(64), e.rng.u32()); e.mmio_read_start(2, 4 * e.rng.below(64)); }
    e.idle(20 + e.rng.below(400));
    flap(e, 10 + e.rng.below(150));
    C.ok(wait_recovered(e), "recovered from a flap under random load", round);
    e.idle(10);
    // invariants after every recovery
    uint32_t st = e.r32(0, sfpb::R_STATUS);
    C.ok((st & 1) && !((st >> 1) & 1) && ((st >> 8) & 0xFF) == 0 && !((st >> 3) & 1), "link up, not recovering, nothing outstanding, DMA idle", st);
#ifdef PUBLIC_DBG
    if (!(!((st >> 3) & 1))) {
      auto* rp = e.d->rootp;
      std::printf("   [dbg] round %d: dma_idle=%d sub_busy=%d sd_busy=%d any_slot..: arp_v=%d awp_v=%d rp_v=%d wp_v=%d rdc_out_v=%d wrc_out_v=%d wm_out_v=%d bq_out_v=%d b_st=%d sq_st=%d r_busy=%d wb_used=%d st_out=%d pk_idle=%d\n", round,
        (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__dma_idle, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__sub_busy, (int)rp->sf_pcie_sim_top__DOT__sd_busy,
        (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__arp_v, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__awp_v,
        (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__rp_v, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__wp_v,
        (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__rdc_out_v, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__wrc_out_v,
        (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__wm_out_v, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__bq_out_v,
        (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__b_st, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__sq_st,
        (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__r_busy, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__wb_used,
        (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__trk_out, (int)rp->sf_pcie_sim_top__DOT__u_bridge__DOT__u_dma__DOT__pk_idle);
    }
#endif
    uint32_t cs = e.r32(0, dma.page(0) + sfpb::C_CPL_STATUS);
    while ((cs & 0xF) != 0) { CplRec r; dma.wait_record(0, r); cs = e.r32(0, dma.page(0) + sfpb::C_CPL_STATUS); }
    C.ok((cs >> 16) == 0, "pending count back to zero", cs >> 16);
    e.w32(0, dma.page(0) + sfpb::C_CPL_POP, 6);
    e.w32(0, sfpb::R_CTRL, 0x27); e.w32(0, sfpb::R_ERR_STATUS, 0xFFFF);
  }
  e.w32(0, sfpb::R_CTRL, 0x2F7 & 0x3F | 0x800 | 0x27); e.idle(50); e.w32(0, sfpb::R_CTRL, 0x27);
  expect_good_dma(e, dma, 0x90, "DMA works after eight flaps");
  C.ok(e.r32(2, 0x10) != 0xDEADBEEF, "MMIO works after eight flaps");
  finish(e, "flaps: no violations");
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  std::vector<Test> tests = {{"link_idle", t_link_idle}, {"dma_read", t_dma_read}, {"dma_write", t_dma_write}, {"mmio", t_mmio}, {"flr", t_flr},
                             {"soft", t_soft}, {"dma_soft", t_dma_soft}, {"read_midburst", t_read_midburst}, {"wait_link", t_wait_link}, {"lost", t_lost}, {"hard", t_hard}, {"flaps", t_flaps}};
  const char* only = argc > 1 ? argv[1] : nullptr;
  for (auto& t : tests) {
    if (only && std::strcmp(only, t.name)) continue;
    int f0 = C.fails;
    for (int mode = 0; mode < 2; mode++) {
      Env e(900 + mode * 17 + std::strlen(t.name));
      if (mode == 1) { e.cfg.cq_gap = 15; e.cfg.cc_stall = 25; e.cfg.rq_stall = 25; e.cfg.rc_gap = 20; e.cfg.split = 3; }
      C.tag = std::string(t.name) + (mode ? "/bp" : "");
      t.fn(e);
    }
    std::printf("  %-18s %s\n", t.name, C.fails == f0 ? "PASS" : "FAIL");
  }
  std::printf("tb_reset DATA_W=%d: %d checks, %d failures\n", DW, C.checks, C.fails);
  return C.fails ? 1 : 0;
}
