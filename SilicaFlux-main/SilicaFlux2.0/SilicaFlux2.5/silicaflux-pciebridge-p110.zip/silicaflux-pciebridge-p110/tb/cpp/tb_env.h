// =============================================================================
// P110 verification environment: transaction-level host + simulated endpoint + device models + independent scoreboards.
//
//   Env drives the CQ and RC streams and consumes CC / RQ exactly as a vendor endpoint core would (PG213-style, DWORD
//   aligned), models the PCIe link as per-direction latencies, acts as the root complex for the device's DMA
//   (host memory, completion splitting / reordering / fault injection), answers MSI requests, models the DataFabric
//   (SFB2 slave) and the device memory, and checks everything against references that are NOT derived from the RTL.
// =============================================================================
#pragma once
#include "Vsf_pcie_sim_top.h"
#include "tlp.h"
#include "sf_pcie_regs.h"
#include <functional>
#include <set>
#include <unordered_map>

#ifndef DW
#define DW 256
#endif

namespace env {
using namespace tlp;
using Top = Vsf_pcie_sim_top;
constexpr int KK = DW / 32;
constexpr uint64_t BAR0_BASE = 0xF000'0000ull, BAR2_BASE = 0xE000'0000ull;
constexpr uint32_t FAB_REG_BASE = 0x4000'0000u, FAB_REG_SIZE = 0x8000u, FAB_MEM_BASE = 0x8000'0000u, FAB_MEM_SIZE = 0x10'0000u;
constexpr uint64_t DEV_BASE = 0x1000'0000ull, DEV_SIZE = 0x10'0000ull;

// ---------------------------------------------------------------------------------------------------------------------
struct HostMem {                                       // sparse byte-addressable host memory
  std::unordered_map<uint64_t, std::vector<uint8_t>> pg;
  uint8_t rd(uint64_t a) { auto it = pg.find(a >> 12); return it == pg.end() ? 0 : it->second[a & 0xFFF]; }
  void wr(uint64_t a, uint8_t v) { auto& p = pg[a >> 12]; if (p.empty()) p.assign(4096, 0); p[a & 0xFFF] = v; }
  uint32_t rd32(uint64_t a) { return rd(a) | (rd(a + 1) << 8) | (rd(a + 2) << 16) | ((uint32_t)rd(a + 3) << 24); }
  void wr32(uint64_t a, uint32_t v) { for (int i = 0; i < 4; i++) wr(a + i, v >> (8 * i)); }
  void fill(uint64_t a, size_t n, Rng& r) { for (size_t i = 0; i < n; i++) wr(a + i, (uint8_t)r.u32()); }
};

struct Fault {                                         // completion fault injection for the next matching read
  enum Kind { NONE, UR, CA, POISON, DROP, BAD_BC, BAD_LOWER, SHORT, LONG, DUP_FIRST, WRONG_TAG, WRONG_REQID, TRUNC, IPERR, RCE_FLR, OVERLEN } kind = NONE;
  int skip = 0; int count = 1; uint64_t addr_lo = 0, addr_hi = ~0ull;
};

struct RqRec { uint64_t accept_cyc, arrive_cyc; int type; uint64_t addr; uint32_t ndw; uint8_t fbe, lbe; uint16_t tag; bool arrived; uint64_t order; bool posted; };
struct FabTx { uint64_t cyc; bool wr; uint32_t addr, data; uint8_t strb; };

struct HostRead {                                      // outstanding MMIO read (host side)
  uint64_t addr = 0; uint32_t ndw = 0; uint8_t fbe = 0, lbe = 0; uint32_t total_bytes = 0, got_bytes = 0; uint32_t next_lower = 0;
  bool done = false; uint8_t status = SC; std::vector<uint32_t> data; int ncpl = 0; uint64_t rq_before = 0; uint64_t cq_cyc = 0; uint64_t done_cyc = 0;
  bool first_seen = false; uint64_t first_cyc = 0; bool bad = false; std::string why;
};

struct Env {
  Top* d; Rng rng; uint64_t cyc = 0;
  struct Cfg {
    int cq_gap = 0, cc_stall = 0, rq_stall = 0, rc_gap = 0;           // percent
    int link_rq = 6, link_cc = 6, link_msi = 6;                       // cycles from endpoint accept to arrival at the root
    int fab_lat_lo = 1, fab_lat_hi = 3, fab_ready_pct = 100;
    int dev_lat_lo = 2, dev_lat_hi = 6;
    int host_lat_lo = 20, host_lat_hi = 50;                           // root-complex read service time
    int split = 1;                                                    // 0 whole request, 1 RCB 64, 2 RCB 128, 3 random dword boundaries
    int msi_delay = 3;
    int mps_code = 1, mrrs_code = 2;                                  // 256 B / 512 B
    int np_ok_pct = 100, p_ok_pct = 100;
  } cfg;

  // ---- host side bookkeeping -----------------------------------------------------------------------------------
  HostMem hm;
  std::vector<RqRec> rqlog; uint64_t rq_accepted = 0, arr_order = 0;
  std::vector<FabTx> fablog;
  std::vector<std::string> violations;                                // protocol / ordering violations found by the monitors
  int viol_limit = 30;
  void viol(const std::string& s) { if ((int)violations.size() < viol_limit) violations.push_back(s); else if ((int)violations.size() == viol_limit) violations.push_back("... (more)"); n_viol++; }
  int n_viol = 0;

  // CQ driver
  struct CqItem { std::vector<Beat> beats; bool is_read = false; uint16_t tag = 0; bool is_irqset = false; };
  std::deque<CqItem> cq_q; size_t cq_i = 0; bool cq_offer = false; bool cq_sop_this = false;
  // RC driver
  struct RcItem { uint64_t due; std::vector<Beat> beats; uint16_t tag; bool final_cpl; };
  std::deque<RcItem> rc_ready; size_t rc_i = 0; bool rc_offer = false;
  std::vector<RcItem> rc_sched;                                       // not yet due
  // CC / RQ monitors
  std::vector<Beat> cc_acc, rq_acc; int link_epoch = 0, cc_acc_epoch = 0, rq_acc_epoch = 0;
  // outstanding host reads (by tag)
  std::map<uint16_t, HostRead> reads; uint16_t next_tag = 0;
  std::map<uint16_t, HostRead> finished;
  // arrivals in flight
  struct Arr { uint64_t t, order; int kind; Req rq; Cpl cc; uint32_t msi; size_t rq_idx; };
  std::vector<Arr> arrivals;
  std::vector<uint64_t> ack_due;                                      // RQ sequence acknowledges
  bool drop_acks = false;                                             // fault injection: the endpoint never returns them
  // device-side outstanding tags as seen by the root (tag reuse check)
  std::set<uint16_t> root_tags;                                       // tags of reads outstanding at the root complex
  std::vector<Fault> faults;
  std::vector<std::pair<uint64_t, int>> msis;                         // (cycle observed, vector)
  uint64_t msi_arrive_last = 0;
  int msi_fail_inject = 0; int msi_wait = -1; int msi_vec = -1;
  uint64_t irq_cause_rq = 0;                                          // RQ TLPs accepted when the last IRQ_SET write was handshaken
  bool irq_cause_valid = false;
  std::vector<std::vector<uint32_t>> cc_unmatched;
  uint64_t n_cc_tlps = 0, n_rq_tlps = 0, n_rc_tlps = 0;
  uint64_t cq_beats_acc = 0;

  // fabric model
  std::vector<uint8_t> fab_reg, fab_mem;
  struct FabResp { uint64_t due; uint32_t data; bool err; };
  std::deque<FabResp> fab_resp; bool fab_hang = false; uint32_t fab_err_lo = 1, fab_err_hi = 0;
  uint64_t fab_hang_at = ~0ull;
  // device memory model
  std::vector<uint8_t> dev_mem;
  struct DevRd { uint64_t due; uint32_t id; std::vector<uint8_t> bytes; size_t beat; int nbeats; bool err; };
  std::vector<DevRd> dev_rd; struct DevWr { uint32_t id; uint64_t addr; int nbeats; };
  std::deque<DevWr> dev_aw; struct DevB { uint64_t due; uint32_t id; uint8_t resp; };
  std::deque<DevB> dev_b;
  struct WBurst { std::vector<std::vector<uint8_t>> d, s; };
  std::deque<WBurst> dev_wb; WBurst dev_wcur;
  uint64_t dev_wr_cnt = 0, dev_rd_cnt = 0;
  bool dev_hold_b = false;

  std::function<void()> hook_drive, hook_sample;                       // extra agents (e.g. an adversarial AXI master)
  uint64_t reorder_events = 0, root_ctr = 0; std::map<uint16_t, uint64_t> root_ord; std::set<uint64_t> root_open;
  // link / misc controls
  bool link_up = true, flr = false; int msi_en = 1, msi_mm = 3;
  uint64_t mps_dw() const { return 32u << cfg.mps_code; }
  uint64_t mrrs_dw() const { return 32u << cfg.mrrs_code; }
  bool check_rq = true;

  explicit Env(uint64_t seed = 1) : rng(seed) {
    d = new Top; fab_reg.assign(FAB_REG_SIZE, 0); fab_mem.assign(FAB_MEM_SIZE, 0); dev_mem.assign(DEV_SIZE, 0);
    d->clk = 0; d->rst_n = 0; zero_inputs(); d->eval();
    for (int i = 0; i < 4; i++) { d->clk = 1; d->eval(); d->clk = 0; d->eval(); }
    d->rst_n = 1; d->eval();
  }
  ~Env() { delete d; }

  void zero_inputs() {
    d->s_axis_cq_tvalid = 0; d->s_axis_cq_tlast = 0; d->s_axis_cq_tkeep = 0; d->m_axis_cc_tready = 0; d->m_axis_rq_tready = 0;
    d->rq_seq_vld0 = 0; d->rq_seq_vld1 = 0; d->s_axis_rc_tvalid = 0; d->s_axis_rc_tlast = 0; d->s_axis_rc_tkeep = 0;
    d->ep_link_up = 1; d->ep_flr_in_process = 0; d->cfg_max_payload = cfg.mps_code; d->cfg_max_read_req = cfg.mrrs_code;
    d->cfg_req_id = 0x0100; d->cfg_check_reqid = 1; d->fc_np_ok = 1; d->fc_p_ok = 1; d->msi_enable = 1; d->msi_mmenable = 3;
    d->msi_sent = 0; d->msi_fail = 0; d->sfb_req_ready = 0; d->sfb_rsp_valid = 0; d->sfb_rsp_rdata = 0; d->sfb_rsp_error = 0;
    d->dev_ar_ready = 0; d->dev_r_valid = 0; d->dev_aw_ready = 0; d->dev_w_ready = 0; d->dev_b_valid = 0;
    d->priv_req_valid = 0; d->priv_req_write = 0; d->priv_req_addr = 0; d->priv_req_wdata = 0; d->priv_rsp_ready = 1;
    d->tw_en = 0; d->irq_ext = 0; d->x_sel = 0; d->x_ar_valid = 0; d->x_r_ready = 1; d->x_aw_valid = 0; d->x_w_valid = 0; d->x_b_ready = 1;
    for (auto* p : {&d->s_axis_cq_tuser}) { (void)p; }
  }

  // =========================================================================================================
  // host-side API
  // =========================================================================================================
  static Req mk_req(int type, uint64_t addr, uint32_t ndw, uint8_t fbe, uint8_t lbe, int bar_id, int bar_ap, uint16_t tag = 0) {
    Req r; r.type = type; r.addr = addr; r.ndw = ndw; r.fbe = fbe; r.lbe = lbe; r.bar_id = bar_id; r.bar_ap = bar_ap; r.tag = tag; return r;
  }
  void post_cq(const std::vector<Beat>& b, bool is_read = false, uint16_t tag = 0, bool irqset = false) { cq_q.push_back({b, is_read, tag, irqset}); }
  // raw TLP injection (tests build their own, possibly malformed, requests); a read gets a host-side record when track_read is set
  void post_raw(const Req& r, const std::vector<uint32_t>* payload_override = nullptr, int disc_beat = -1, bool track_read = false) {
    if (track_read) {
      HostRead h; h.addr = r.addr; h.ndw = r.ndw; h.fbe = r.fbe; h.lbe = r.lbe; h.total_bytes = read_bytes(r.ndw, r.fbe, r.lbe);
      h.next_lower = ((r.addr & 0x7C) | lo_byte(r.fbe)) & 0x7F; reads[r.tag] = h;
    }
    post_cq(cq_beats(r, DW, payload_override, disc_beat), track_read, r.tag);
  }
  void mmio_write(int bar, uint32_t off, const std::vector<uint32_t>& v, uint8_t fbe = 0xF, uint8_t lbe = 0xF) {
    uint64_t base = bar == 0 ? BAR0_BASE : BAR2_BASE; int ap = bar == 0 ? 16 : 20;
    Req r = mk_req(MWR, base + off, (uint32_t)v.size(), fbe, v.size() == 1 ? 0 : lbe, bar, ap); r.data = v;
    bool irqset = (bar == 0 && off == sfpb::R_IRQ_SET);
    post_cq(cq_beats(r, DW), false, 0, irqset);
  }
  void w32(int bar, uint32_t off, uint32_t v, uint8_t be = 0xF) { mmio_write(bar, off, {v}, be, 0); }
  uint16_t alloc_tag() { for (int i = 0; i < 256; i++) { uint16_t t = (next_tag++) & 0xFF; if (!reads.count(t) && !finished.count(t)) return t; } viol("host model: no free tag"); return 0; }
  uint16_t mmio_read_start(int bar, uint32_t off, uint32_t ndw = 1, uint8_t fbe = 0xF, uint8_t lbe = 0xF) {
    uint64_t base = bar == 0 ? BAR0_BASE : BAR2_BASE; int ap = bar == 0 ? 16 : 20;
    uint16_t t = alloc_tag(); Req r = mk_req(MRD, base + off, ndw, fbe, ndw == 1 ? 0 : lbe, bar, ap, t);
    HostRead h; h.addr = base + off; h.ndw = ndw; h.fbe = fbe; h.lbe = r.lbe; h.total_bytes = read_bytes(ndw, fbe, r.lbe);
    h.next_lower = ((h.addr & 0x7C) | lo_byte(fbe)) & 0x7F; if (ndw == 1 && fbe == 0) h.next_lower = h.addr & 0x7C;
    reads[t] = h; post_cq(cq_beats(r, DW), true, t); return t;
  }
  bool read_done(uint16_t t) { return finished.count(t) != 0; }
  HostRead wait_read(uint16_t t, uint64_t maxc = 200000) {
    uint64_t c0 = cyc; while (!read_done(t) && cyc - c0 < maxc) cycle();
    if (!read_done(t)) { HostRead h = reads.count(t) ? reads[t] : HostRead(); h.bad = true; h.why = "timeout waiting for completion"; return h; }
    HostRead h = finished[t]; finished.erase(t); return h;
  }
  HostRead mmio_read(int bar, uint32_t off, uint32_t ndw = 1, uint8_t fbe = 0xF, uint8_t lbe = 0xF) { return wait_read(mmio_read_start(bar, off, ndw, fbe, lbe)); }
  uint32_t r32(int bar, uint32_t off) { auto h = mmio_read(bar, off); return h.data.empty() ? 0xDEADBEEF : h.data[0]; }
  void idle(uint64_t n) { for (uint64_t i = 0; i < n; i++) cycle(); }
  bool run_until(const std::function<bool()>& p, uint64_t maxc = 200000) { uint64_t c0 = cyc; while (!p() && cyc - c0 < maxc) cycle(); return p(); }
  bool quiet() { return cq_q.empty() && !cq_offer && rc_ready.empty() && rc_sched.empty() && arrivals.empty() && reads.empty() && !rc_offer; }

  // privileged port (ControlCore stand-in)
  uint32_t priv_rd(uint32_t a) {
    d->priv_req_valid = 1; d->priv_req_write = 0; d->priv_req_addr = a;
    for (int i = 0; i < 20; i++) { d->clk = 0; d->eval(); bool acc = d->priv_req_ready; d->clk = 1; d->eval(); d->clk = 0; cyc++; if (acc) break; }
    d->priv_req_valid = 0; d->eval();
    for (int i = 0; i < 20; i++) { d->clk = 0; d->eval(); if (d->priv_rsp_valid) { uint32_t v = d->priv_rsp_rdata; d->clk = 1; d->eval(); d->clk = 0; cyc++; return v; } d->clk = 1; d->eval(); d->clk = 0; cyc++; }
    return 0xBAD0BAD0;
  }
  bool priv_wr(uint32_t a, uint32_t v) {
    d->priv_req_valid = 1; d->priv_req_write = 1; d->priv_req_addr = a; d->priv_req_wdata = v;
    for (int i = 0; i < 20; i++) { d->clk = 0; d->eval(); bool acc = d->priv_req_ready; d->clk = 1; d->eval(); d->clk = 0; cyc++; if (acc) break; }
    d->priv_req_valid = 0; d->eval();
    for (int i = 0; i < 20; i++) { d->clk = 0; d->eval(); if (d->priv_rsp_valid) { bool e = d->priv_rsp_error; d->clk = 1; d->eval(); d->clk = 0; cyc++; return !e; } d->clk = 1; d->eval(); d->clk = 0; cyc++; }
    return false;
  }
  // context programming through the privileged port; returns COMMIT_STATUS
  uint32_t ctx_program(int c, bool valid, bool rd_ok, bool wr_ok, bool xlat, uint64_t ib, uint64_t is, uint64_t bb, uint64_t db, uint64_t ds, uint32_t maxlen) {
    uint32_t b = c * 0x40;
    priv_wr(b + sfpb::P_IOVA_BASE_LO, (uint32_t)ib); priv_wr(b + sfpb::P_IOVA_BASE_HI, ib >> 32);
    priv_wr(b + sfpb::P_IOVA_SIZE_LO, (uint32_t)is); priv_wr(b + sfpb::P_IOVA_SIZE_HI, is >> 32);
    priv_wr(b + sfpb::P_BUS_BASE_LO, (uint32_t)bb); priv_wr(b + sfpb::P_BUS_BASE_HI, bb >> 32);
    priv_wr(b + sfpb::P_DEV_BASE_LO, (uint32_t)db); priv_wr(b + sfpb::P_DEV_BASE_HI, db >> 32);
    priv_wr(b + sfpb::P_DEV_SIZE_LO, (uint32_t)ds); priv_wr(b + sfpb::P_DEV_SIZE_HI, ds >> 32);
    priv_wr(b + sfpb::P_MAX_LEN, maxlen);
    priv_wr(b + sfpb::P_CTX_CTRL, (valid ? 1 : 0) | (rd_ok ? 2 : 0) | (wr_ok ? 4 : 0) | (xlat ? 8 : 0));
    priv_wr(b + sfpb::P_COMMIT, 1);
    return priv_rd(b + sfpb::P_COMMIT_STATUS);
  }
  void guard_add(int idx, int dom, int asid, uint64_t base, uint64_t size, uint64_t pa, int perm) {
    d->tw_en = 1; d->tw_idx = idx; d->tw_valid = 1; d->tw_domain = dom; d->tw_asid = asid; d->tw_base = base; d->tw_size = size; d->tw_pa = pa; d->tw_perm = perm;
    d->clk = 0; d->eval(); d->clk = 1; d->eval(); d->clk = 0; d->eval(); cyc++; d->tw_en = 0; d->eval();
  }

  // =========================================================================================================
  // one clock cycle
  // =========================================================================================================
  void cycle() {
    drive();
    if (hook_drive) hook_drive();
    d->clk = 0; d->eval();
    sample();
    if (hook_sample) hook_sample();
    d->clk = 1; d->eval(); d->clk = 0;
    cyc++;
    host_step();
  }

  // ---- drive inputs -----------------------------------------------------------------------------------------
  void drive() {
    d->msi_enable = msi_en; d->msi_mmenable = msi_mm;
    d->ep_link_up = link_up; d->ep_flr_in_process = flr; d->cfg_max_payload = cfg.mps_code; d->cfg_max_read_req = cfg.mrrs_code;
    d->fc_np_ok = !rng.chance(100 - cfg.np_ok_pct) ; d->fc_p_ok = !rng.chance(100 - cfg.p_ok_pct);
    // CQ
    if (!cq_offer && !cq_q.empty() && !rng.chance(cfg.cq_gap)) cq_offer = true;
    if (cq_offer) {
      const Beat& b = cq_q.front().beats[cq_i];
      uint32_t* w = W(d->s_axis_cq_tdata); for (int i = 0; i < KK; i++) w[i] = b.dw[i];
      d->s_axis_cq_tkeep = b.keep; d->s_axis_cq_tlast = b.last;
      uint32_t* u = W(d->s_axis_cq_tuser); u[0] = (uint32_t)b.user; u[1] = (uint32_t)(b.user >> 32); u[2] = 0;
      d->s_axis_cq_tvalid = 1;
    } else d->s_axis_cq_tvalid = 0;
    // RC
    while (!rc_sched.empty()) {                                      // move due completions to the ready queue in time order
      size_t best = 0; for (size_t i = 1; i < rc_sched.size(); i++) if (rc_sched[i].due < rc_sched[best].due) best = i;
      if (rc_sched[best].due > cyc) break;
      rc_ready.push_back(rc_sched[best]); rc_sched.erase(rc_sched.begin() + best);
    }
    if (!rc_offer && !rc_ready.empty() && !rng.chance(cfg.rc_gap)) rc_offer = true;
    if (rc_offer) {
      const Beat& b = rc_ready.front().beats[rc_i];
      uint32_t* w = W(d->s_axis_rc_tdata); for (int i = 0; i < KK; i++) w[i] = b.dw[i];
      d->s_axis_rc_tkeep = b.keep; d->s_axis_rc_tlast = b.last; d->s_axis_rc_tvalid = 1;
      uint32_t* u = W(d->s_axis_rc_tuser); u[0] = u[1] = u[2] = 0;
    } else d->s_axis_rc_tvalid = 0;
    // sinks
    d->m_axis_cc_tready = !rng.chance(cfg.cc_stall);
    d->m_axis_rq_tready = !rng.chance(cfg.rq_stall);
    // RQ sequence acknowledges (up to two per cycle)
    int acks = 0; for (auto it = ack_due.begin(); it != ack_due.end() && acks < 2;) { if (*it <= cyc) { acks++; it = ack_due.erase(it); } else ++it; }
    d->rq_seq_vld0 = acks >= 1; d->rq_seq_vld1 = acks >= 2;
    // MSI
    d->msi_sent = 0; d->msi_fail = 0;
    if (msi_wait == 0) {
      if (msi_fail_inject > 0) { d->msi_fail = 1; msi_fail_inject--; }
      else { d->msi_sent = 1; arrivals.push_back({cyc + cfg.link_msi, arr_order++, 3, Req(), Cpl(), (uint32_t)msi_vec, 0}); msis.push_back({cyc, msi_vec}); }
      msi_wait = -1;
    } else if (msi_wait > 0) msi_wait--;
    // fabric
    bool fready = !fab_hang && (rng.below(100) < (uint32_t)cfg.fab_ready_pct);
    d->sfb_req_ready = fready;
    if (!fab_resp.empty() && fab_resp.front().due <= cyc && !fab_hang) {
      d->sfb_rsp_valid = 1; d->sfb_rsp_rdata = fab_resp.front().data; d->sfb_rsp_error = fab_resp.front().err;
    } else { d->sfb_rsp_valid = 0; d->sfb_rsp_rdata = 0; d->sfb_rsp_error = 0; }
    dev_drive();
  }

  // ---- sample outputs / complete handshakes -----------------------------------------------------------------
  void sample() {
    // CQ handshake
    if (cq_offer && d->s_axis_cq_tready) {
      auto& it = cq_q.front();
      if (cq_i == 0) {
        if (it.is_read) { reads[it.tag].rq_before = rq_accepted; reads[it.tag].cq_cyc = cyc; }
        if (it.is_irqset) { irq_cause_rq = rq_accepted; irq_cause_valid = true; }
      }
      cq_beats_acc++;
      if (++cq_i == it.beats.size()) { cq_q.pop_front(); cq_i = 0; cq_offer = false; }
    }
    // RC handshake
    if (rc_offer && d->s_axis_rc_tready) {
      auto& it = rc_ready.front();
      if (rc_i == 0 && root_ord.count(it.tag) && !root_open.empty() && *root_open.begin() < root_ord[it.tag]) reorder_events++;
      if (++rc_i == it.beats.size()) {
        if (it.final_cpl && root_ord.count(it.tag)) { root_open.erase(root_ord[it.tag]); root_ord.erase(it.tag); }
        n_rc_tlps++; if (it.final_cpl) root_tags.erase(it.tag);
        rc_ready.pop_front(); rc_i = 0; rc_offer = false;
      }
    }
    // CC monitor
    if (d->m_axis_cc_tvalid && d->m_axis_cc_tready) {
      Beat b; const uint32_t* w = WC(d->m_axis_cc_tdata); b.dw.assign(w, w + KK); b.keep = d->m_axis_cc_tkeep; b.last = d->m_axis_cc_tlast;
      uint32_t k = b.keep; if (k & (k + 1)) viol("CC tkeep not contiguous from lane 0");
      if (cc_acc.empty()) cc_acc_epoch = link_epoch;
      cc_acc.push_back(b);
      if (b.last) {
        for (size_t i = 0; i + 1 < cc_acc.size(); i++) if (cc_acc[i].keep != (1u << KK) - 1) viol("CC non-final beat not full");
        Cpl c; if (!cc_decode(cc_acc, c)) viol("CC packet shorter than its descriptor");
        else if (cc_acc_epoch != link_epoch || !link_up) { /* began before a link loss, or handed over while the link is down: dropped */ }
        else { n_cc_tlps++; arrivals.push_back({cyc + cfg.link_cc, arr_order++, 1, Req(), c, 0, 0}); }
        cc_acc.clear();
      }
    }
    // RQ monitor
    if (d->m_axis_rq_tvalid && d->m_axis_rq_tready) {
      Beat b; const uint32_t* w = WC(d->m_axis_rq_tdata); b.dw.assign(w, w + KK); b.keep = d->m_axis_rq_tkeep; b.last = d->m_axis_rq_tlast; b.user = d->m_axis_rq_tuser;
      uint32_t k = b.keep; if (k & (k + 1)) viol("RQ tkeep not contiguous from lane 0");
      if (rq_acc.empty()) rq_acc_epoch = link_epoch;
      rq_acc.push_back(b);
      if (b.last) {
        for (size_t i = 0; i + 1 < rq_acc.size(); i++) if (rq_acc[i].keep != (1u << KK) - 1) viol("RQ non-final beat not full");
        Req r; if (!rq_decode(rq_acc, r)) viol("RQ packet shorter than its descriptor");
        else if (rq_acc_epoch != link_epoch || !link_up) { rqlog.push_back({cyc, cyc, r.type, r.addr, r.ndw, r.fbe, r.lbe, (uint16_t)r.tag, true, 0, false}); rq_accepted++; }          // lost with the link, but the bridge counted it: keep the sequence in step
        else rq_arrive(r);
        rq_acc.clear();
      }
    }
    // fabric
    if (d->sfb_req_valid && d->sfb_req_ready) {
      uint32_t a = d->sfb_req_addr; bool wr = d->sfb_req_write; uint32_t wd = d->sfb_req_wdata; uint8_t st = d->sfb_req_wstrb;
      fablog.push_back({cyc, wr, a, wd, (uint8_t)(wr ? st : 0)});
      uint32_t rd = 0; bool err = false; uint8_t* base = nullptr; uint32_t off = 0;
      if (a >= FAB_REG_BASE && a < FAB_REG_BASE + FAB_REG_SIZE) { base = fab_reg.data(); off = a - FAB_REG_BASE; }
      else if (a >= FAB_MEM_BASE && a < FAB_MEM_BASE + FAB_MEM_SIZE) { base = fab_mem.data(); off = a - FAB_MEM_BASE; }
      else err = true;
      if (a & 3) err = true;
      if (fab_err_lo <= fab_err_hi && a >= fab_err_lo && a <= fab_err_hi) err = true;
      if (!err) {
        if (wr) { for (int i = 0; i < 4; i++) if (st & (1 << i)) base[off + i] = wd >> (8 * i); }
        else rd = base[off] | (base[off + 1] << 8) | (base[off + 2] << 16) | ((uint32_t)base[off + 3] << 24);
      }
      uint64_t lat = rng.range(cfg.fab_lat_lo, cfg.fab_lat_hi);
      uint64_t due = std::max<uint64_t>(cyc + 1 + lat - 1, fab_resp.empty() ? 0 : fab_resp.back().due);   // in order, never in the accept cycle
      fab_resp.push_back({due, err ? 0u : rd, err});
      if (cyc >= fab_hang_at) fab_hang = true;
    }
    if (d->sfb_rsp_valid && d->sfb_rsp_ready && !fab_resp.empty()) fab_resp.pop_front();
    // MSI request observation
    if (d->msi_int != 0 && msi_wait < 0 && !d->msi_sent && !d->msi_fail) {            // (msi_int is still high in the cycle sent/fail is pulsed)
      uint32_t v = d->msi_int; int bit = __builtin_ctz(v); if (v & (v - 1)) viol("msi_int is not one-hot");
      msi_vec = bit; msi_wait = cfg.msi_delay;
    }
    dev_sample();
  }

  // ---- RQ TLP accepted by the endpoint ---------------------------------------------------------------------
  void rq_arrive(const Req& r) {
    n_rq_tlps++;
    uint64_t idx = rqlog.size();
    RqRec rec{cyc, cyc + cfg.link_rq, r.type, r.addr, r.ndw, r.fbe, r.lbe, r.tag, false, 0, r.type == MWR}; rqlog.push_back(rec);
    rq_accepted++;
    if (check_rq) {
      if (r.type != MRD && r.type != MWR) viol("RQ: unsupported request type emitted");
      if (r.seq != (uint8_t)((rq_accepted - 1) & 63)) viol("RQ: sequence number not the running TLP count (got " + std::to_string(r.seq) + ")");
      if (r.tc != 0 || r.attr != 0 || r.at != 0 || r.poison) viol("RQ: TC/attr/AT/poison not zero");
      if (r.ndw < 1 || r.ndw > 1024) viol("RQ: bad length");
      if (crosses_4k(r.addr, r.ndw)) viol("RQ: crosses 4 KiB");
      if (r.type == MWR) {
        if (r.data.size() != r.ndw) viol("RQ MWr: payload length != dword count");
        if (r.ndw > mps_dw()) viol("RQ MWr: exceeds max payload");
        if (!be_legal(r.ndw, r.fbe, r.lbe) && !(r.ndw == 1 && r.fbe == 0)) viol("RQ MWr: illegal byte enables");
      } else {
        if (!r.data.empty()) viol("RQ MRd: carries payload");
        if (r.ndw > mrrs_dw()) viol("RQ MRd: exceeds max read request");
        bool flushrd = (r.ndw == 1 && r.fbe == 0 && r.lbe == 0);
        if (!flushrd && !be_legal(r.ndw, r.fbe, r.lbe)) viol("RQ MRd: illegal byte enables");
        if (root_tags.count(r.tag)) viol("RQ MRd: tag " + std::to_string(r.tag) + " reused while outstanding");
        root_tags.insert(r.tag);
      }
    }
    if (!drop_acks) ack_due.push_back(cyc + cfg.link_rq);
    arrivals.push_back({cyc + cfg.link_rq, arr_order++, 0, r, Cpl(), 0, (size_t)idx});
  }

  // ---- arrivals at the root complex, in time order ---------------------------------------------------------
  void host_step() {
    for (;;) {
      size_t best = arrivals.size(); for (size_t i = 0; i < arrivals.size(); i++) if (arrivals[i].t <= cyc && (best == arrivals.size() || arrivals[i].t < arrivals[best].t || (arrivals[i].t == arrivals[best].t && arrivals[i].order < arrivals[best].order))) best = i;
      if (best == arrivals.size()) break;
      Arr a = arrivals[best]; arrivals.erase(arrivals.begin() + best);
      if (a.kind == 0) root_receive(a.rq, a.rq_idx);
      else if (a.kind == 1) host_cc(a.cc);
      else if (a.kind == 3) host_msi(a.msi);
    }
  }
  void host_msi(uint32_t vec) {
    (void)vec;
    if (irq_cause_valid) for (uint64_t i = 0; i < irq_cause_rq && i < rqlog.size(); i++) if (rqlog[i].posted && !rqlog[i].arrived) { viol("ORDER: MSI arrived before an earlier posted write"); break; }
  }
  void host_cc(const Cpl& c) {
    auto it = reads.find(c.tag);
    // ordering: posted writes accepted before the request was received must have arrived before its completion
    if (it == reads.end()) { viol("CC: completion for unknown tag " + std::to_string(c.tag)); return; }
    HostRead& h = it->second;
    for (uint64_t i = 0; i < h.rq_before && i < rqlog.size(); i++) if (rqlog[i].posted && !rqlog[i].arrived) { viol("ORDER: completion overtook an earlier posted write"); break; }
    if (c.reqid != 0x0100) { viol("CC: wrong requester id"); h.bad = true; }
    if (!h.first_seen) { h.first_seen = true; h.first_cyc = cyc; }
    h.ncpl++;
    if (c.status != SC) {
      h.status = c.status; h.done = true; h.done_cyc = cyc; if (!c.data.empty()) { viol("CC: error completion carries data"); h.bad = true; }
      finished[c.tag] = h; reads.erase(it); return;
    }
    uint32_t remaining = h.total_bytes - h.got_bytes;
    uint32_t first_off = (h.got_bytes == 0) ? lo_byte(h.fbe) : 0;
    uint32_t cbytes = 4 * c.ndw - first_off;
    bool final_c = (c.bytecnt == cbytes) || (c.ndw * 4 >= remaining + first_off);
    if (c.bytecnt != remaining) { viol("CC: byte count " + std::to_string(c.bytecnt) + " != remaining " + std::to_string(remaining)); h.bad = true; h.why = "byte count"; }
    if (c.lower != (h.next_lower & 0x7F)) { viol("CC: lower address " + std::to_string(c.lower) + " != expected " + std::to_string(h.next_lower & 0x7F)); h.bad = true; h.why = "lower address"; }
    if (c.data.size() != c.ndw) { viol("CC: payload length != dword count"); h.bad = true; h.why = "length"; }
    if (c.ndw == 0 || c.ndw > 32 || c.ndw > mps_dw()) { viol("CC: completion size out of range"); h.bad = true; }
    for (uint32_t w : c.data) h.data.push_back(w);
    h.got_bytes += std::min<uint32_t>(cbytes, remaining);
    // next lower address: DW aligned address after this completion
    uint64_t next = (h.addr & ~3ull) + 4ull * h.data.size(); h.next_lower = next & 0x7C;
    if (!final_c && (next & 127)) { viol("CC: non-final completion does not end on a 128-byte boundary"); h.bad = true; }
    if (h.got_bytes >= h.total_bytes) { h.done = true; h.done_cyc = cyc; finished[c.tag] = h; reads.erase(it); }
  }

  // ---- root complex ------------------------------------------------------------------------------------------
  Fault* match_fault(const Req& r) {
    for (auto& f : faults) if (f.kind != Fault::NONE && f.count > 0 && r.addr >= f.addr_lo && r.addr <= f.addr_hi) { if (f.skip > 0) { f.skip--; return nullptr; } return &f; }
    return nullptr;
  }
  void root_receive(const Req& r, size_t idx) {
    rqlog[idx].arrived = true; rqlog[idx].arrive_cyc = cyc;
    if (r.type == MWR) {
      for (uint32_t i = 0; i < r.ndw && i < r.data.size(); i++) {
        uint8_t be = (i == 0) ? r.fbe : (i == r.ndw - 1 ? r.lbe : 0xF);
        for (int b = 0; b < 4; b++) if (be & (1 << b)) hm.wr(r.addr + 4 * i + b, r.data[i] >> (8 * b));
      }
      return;
    }
    // read request
    bool flushrd = (r.ndw == 1 && r.fbe == 0);
    Fault* f = match_fault(r); Fault::Kind fk = f ? f->kind : Fault::NONE; if (f) f->count--;
    uint64_t lat = rng.range(cfg.host_lat_lo, cfg.host_lat_hi); uint64_t t = cyc + lat;
    std::vector<uint32_t> data; for (uint32_t i = 0; i < r.ndw; i++) data.push_back(hm.rd32(r.addr + 4 * i));
    uint32_t total = flushrd ? 1 : 4 * r.ndw;
    auto emit = [&](Cpl c, bool fin) {
      c.reqid = 0x0100; c.tag = r.tag;               // the endpoint IP inserts its own requester id; the root answers to it
       if (fk == Fault::WRONG_TAG) c.tag = (r.tag + 1) & 0xFF; if (fk == Fault::WRONG_REQID) c.reqid = 0x0999;
      RcItem it{t, rc_beats(c, DW), r.tag, fin}; rc_sched.push_back(it); t += 1 + rng.below(6);
    };
    root_ord[r.tag] = root_ctr; root_open.insert(root_ctr); root_ctr++;
    if (fk == Fault::DROP) { root_open.erase(root_ord[r.tag]); root_ord.erase(r.tag); return; }       // the root never answers (tag stays outstanding forever)
    if (fk == Fault::UR || fk == Fault::CA) { Cpl c; c.status = fk == Fault::UR ? UR : CA; c.bytecnt = 4; c.lower = r.addr & 0x7F; emit(c, true); return; }
    if (fk == Fault::IPERR) { Cpl c; c.status = SC; c.err = RCE_TIMEOUT; c.ndw = 0; emit(c, true); return; }
    if (fk == Fault::RCE_FLR) { Cpl c; c.status = SC; c.err = RCE_FLR; emit(c, true); return; }
    // split into completions
    std::vector<std::pair<uint32_t, uint32_t>> pieces;                              // (first dword, count)
    uint32_t n = r.ndw; uint32_t pos = 0;
    uint32_t rcb = cfg.split == 1 ? 64 : cfg.split == 2 ? 128 : 0;
    uint32_t maxdw = std::min<uint32_t>(mps_dw(), 32 * 1);                       // keep each completion <= 128 B in this model unless mps allows more
    maxdw = (uint32_t)mps_dw();
    while (pos < n) {
      uint32_t c;
      if (cfg.split == 0) c = std::min<uint32_t>(n - pos, (uint32_t)mps_dw());
      else if (cfg.split == 3) c = 1 + rng.below(std::min<uint32_t>(n - pos, 24));
      else { uint64_t a = r.addr + 4ull * pos; uint32_t to_b = rcb / 4 - ((a / 4) % (rcb / 4)); c = std::min<uint32_t>(to_b, n - pos); c = std::min<uint32_t>(c, maxdw); }
      pieces.push_back({pos, c}); pos += c;
    }
    if (flushrd) pieces = {{0, 1}};
    uint32_t remaining = flushrd ? 1 : read_bytes(r.ndw, r.fbe, r.lbe);
    uint32_t first_off = lo_byte(r.fbe);
    int short_piece = -1; for (size_t pi = 0; pi < pieces.size(); pi++) if (pieces[pi].second > 1) short_piece = (int)pi;     // last piece that can lose a dword
    if (fk == Fault::SHORT && short_piece < 0) fk = Fault::LONG;                                                           // nothing to shorten: inject the opposite defect instead
    for (size_t pi = 0; pi < pieces.size(); pi++) {
      Cpl c; c.status = SC; uint32_t cnt = pieces[pi].second;
      for (uint32_t i = 0; i < cnt; i++) c.data.push_back(data[pieces[pi].first + i]);
      c.ndw = cnt; c.bytecnt = remaining;
      uint64_t a = r.addr + 4ull * pieces[pi].first;
      c.lower = (pi == 0) ? (a & 0x7C) | (flushrd ? 0 : first_off) : (a & 0x7F);
      uint32_t cb = 4 * cnt - (pi == 0 ? first_off : 0); if (cb > remaining) cb = remaining;
      bool last = (pi + 1 == pieces.size());
      if (fk == Fault::POISON && pi == 0) c.poison = true;
      if (fk == Fault::BAD_BC && pi == 0) c.bytecnt = remaining + 4;
      if (fk == Fault::BAD_LOWER && pi == 0) c.lower ^= 0x08;
      if (fk == Fault::SHORT && (int)pi == short_piece) c.data.pop_back();
      if (fk == Fault::LONG && last) c.data.push_back(0xAAAA5555);
      if (fk == Fault::OVERLEN && last) { c.data.push_back(0xAAAA5555); c.data.push_back(0x5555AAAA); c.ndw = cnt + 2; }     // descriptor AND payload longer than what is owed; byte count still consistent
      remaining -= cb;
      c.req_done = last;
      emit(c, last);
      if (fk == Fault::DUP_FIRST && pi == 0) emit(c, false);
      if (fk == Fault::TRUNC && pi == 0) break;                                    // only the first completion is delivered
    }
  }

  // =========================================================================================================
  // device memory model (StreamDMA non-host types)
  // =========================================================================================================
  void dev_drive() {
    d->dev_ar_ready = rng.chance(70); d->dev_aw_ready = rng.chance(70); d->dev_w_ready = rng.chance(70);
    // read data: pick one ready burst at random, one beat per cycle
    d->dev_r_valid = 0;
    std::vector<size_t> ready; for (size_t i = 0; i < dev_rd.size(); i++) if (dev_rd[i].due <= cyc) ready.push_back(i);
    if (!ready.empty()) {
      cur_dev_idx = (int)ready[rng.below((uint32_t)ready.size())];
      DevRd& r = dev_rd[cur_dev_idx];
      d->dev_r_valid = 1; d->dev_r_id = r.id; d->dev_r_resp = r.err ? 2 : 0; d->dev_r_last = (r.beat + 1 == (size_t)r.nbeats);
      uint32_t* w = W(d->dev_r_data); for (int i = 0; i < 4; i++) w[i] = 0;
      if (!r.err) for (int by = 0; by < 16; by++) w[by / 4] |= (uint32_t)r.bytes[r.beat * 16 + by] << (8 * (by % 4));
    } else cur_dev_idx = -1;
    d->dev_b_valid = 0;
    if (!dev_hold_b && !dev_b.empty() && dev_b.front().due <= cyc) { d->dev_b_valid = 1; d->dev_b_id = dev_b.front().id; d->dev_b_resp = dev_b.front().resp; }
  }
  int cur_dev_idx = -1;
  void dev_sample() {
    if (d->sd_soft_active) { dev_rd.clear(); dev_aw.clear(); dev_wb.clear(); dev_wcur = WBurst(); dev_b.clear(); cur_dev_idx = -1; return; }   // StreamDMA integration contract: the memory fabric is reset with the core
    if (d->dev_r_valid && d->dev_r_ready && cur_dev_idx >= 0) {            // complete the R handshake first (the vector may grow below)
      if (++dev_rd[cur_dev_idx].beat == (size_t)dev_rd[cur_dev_idx].nbeats) dev_rd.erase(dev_rd.begin() + cur_dev_idx);
    }
    cur_dev_idx = -1;
    if (d->dev_ar_valid && d->dev_ar_ready) {
      uint64_t a = d->dev_ar_addr; int nb = d->dev_ar_len + 1; DevRd r; r.due = cyc + rng.range(cfg.dev_lat_lo, cfg.dev_lat_hi); r.id = d->dev_ar_id; r.beat = 0; r.nbeats = nb;
      r.err = !(a >= DEV_BASE && a + 16ull * nb <= DEV_BASE + DEV_SIZE);
      if (!r.err) r.bytes.assign(dev_mem.begin() + (a - DEV_BASE), dev_mem.begin() + (a - DEV_BASE) + 16 * nb);
      dev_rd.push_back(r); dev_rd_cnt++;
    }
    if (d->dev_aw_valid && d->dev_aw_ready) { DevWr w; w.id = d->dev_aw_id; w.addr = d->dev_aw_addr; w.nbeats = d->dev_aw_len + 1; dev_aw.push_back(w); }
    if (d->dev_w_valid && d->dev_w_ready) {
      std::vector<uint8_t> by(16), st(16); const uint32_t* w = WC(d->dev_w_data); uint32_t s = d->dev_w_strb;
      for (int i = 0; i < 16; i++) { by[i] = w[i / 4] >> (8 * (i % 4)); st[i] = (s >> i) & 1; }
      dev_wcur.d.push_back(by); dev_wcur.s.push_back(st);
      if (d->dev_w_last) { dev_wb.push_back(dev_wcur); dev_wcur = WBurst(); }
    }
    while (!dev_aw.empty() && !dev_wb.empty()) {
      DevWr w = dev_aw.front(); dev_aw.pop_front(); WBurst bd = dev_wb.front(); dev_wb.pop_front();
      bool err = !(w.addr >= DEV_BASE && w.addr + 16ull * w.nbeats <= DEV_BASE + DEV_SIZE) || (int)bd.d.size() != w.nbeats;
      if (!err) for (int b = 0; b < w.nbeats; b++) for (int i = 0; i < 16; i++) if (bd.s[b][i]) dev_mem[w.addr - DEV_BASE + b * 16 + i] = bd.d[b][i];
      dev_b.push_back({cyc + rng.range(cfg.dev_lat_lo, cfg.dev_lat_hi), w.id, (uint8_t)(err ? 2 : 0)}); dev_wr_cnt++;
    }
    if (d->dev_b_valid && d->dev_b_ready) dev_b.pop_front();
  }

  // =========================================================================================================
  // helpers for tests
  // =========================================================================================================
  // the link dies: everything in flight is lost on both sides (the host also forgets its outstanding requests)
  void link_down() {
    for (auto& r : rqlog) if (!r.arrived) r.arrived = true;               // TLPs lost with the link impose no ordering any more
    link_up = false; arrivals.clear(); rc_sched.clear(); rc_ready.clear(); rc_offer = false; rc_i = 0; ack_due.clear();
    cq_q.clear(); cq_offer = false; cq_i = 0; link_epoch++; root_tags.clear(); root_ord.clear(); root_open.clear();
    reads.clear(); finished.clear();
  }
  void reset_dut() {
    rq_accepted = 0; rqlog.clear(); cc_acc.clear(); rq_acc.clear(); fab_resp.clear(); dev_rd.clear(); dev_aw.clear(); dev_wb.clear(); dev_b.clear(); dev_wcur = WBurst();
    d->rst_n = 0; for (int i = 0; i < 4; i++) { d->clk = 0; d->eval(); d->clk = 1; d->eval(); } d->clk = 0; d->rst_n = 1; d->eval();
  }
  bool no_violations() const { return n_viol == 0; }
  void print_violations() const { for (auto& v : violations) std::printf("    VIOLATION: %s\n", v.c_str()); }
};

}  // namespace env
