// Cycle-collision tests.  A sticky status bit is cleared by software with write-1-to-clear; if the event that sets the bit
// arrives in the SAME cycle as the clear, it must survive (otherwise an interrupt / error is silently lost -- the classic
// lost-wakeup race).  The collision cycle depends on internal latencies, so the test does not assume it: it SWEEPS the
// event's arrival time across the clear, reads the bench-only probes (dbg_*, hierarchical references in sf_pcie_sim_top)
// to learn whether event and clear really did land in the same cycle in that run, and demands "bit still set" exactly then.
// A sweep that never produced a collision fails the test (the probe would be useless).
#include "tb_dma_lib.h"
using namespace env;
static Checker C;

static void t_irq_status(void) {
  int collisions = 0, bad = 0; bool seen_set = false, non_monotone = false;
  for (int off = 0; off < 70; off++) {
    Env e(900 + off);
    e.w32(0, sfpb::R_IRQ_MASK, 0xFF); e.w32(0, sfpb::R_IRQ_SET, 1 << 5); e.idle(60);      // EXT0 bit is set: the clear has something to do
    bool collided = false; uint64_t c0 = 0;
    e.hook_drive  = [&]() { e.d->irq_ext = (e.cyc == c0 + (uint64_t)off) ? 1 : 0; };         // one-cycle pulse on ext0 at a swept time
    e.hook_sample = [&]() { if (e.d->dbg_irq_w1c && e.d->irq_ext) collided = true; };
    c0 = e.cyc; e.w32(0, sfpb::R_IRQ_STATUS, 1 << 5);
    e.idle(120);
    e.hook_drive = nullptr; e.hook_sample = nullptr; e.d->irq_ext = 0;
    bool set = (e.r32(0, sfpb::R_IRQ_STATUS) >> 5) & 1;
    if (collided) { collisions++; bad += !set; }
    if (set) seen_set = true; else if (seen_set) non_monotone = true;                       // an event AFTER the clear must never be lost either
    C.ok(e.no_violations(), "no protocol violations", off);
  }
  C.ok(collisions > 0, "the sweep produced at least one same-cycle collision (probe is live)", collisions);
  C.ok(bad == 0, "IRQ_STATUS: an event in the same cycle as its write-1-to-clear survives", bad);
  C.ok(!non_monotone, "IRQ_STATUS: once the pulse lands after the clear the bit stays set for every later offset");
}

static void t_err_status(void) {
  // Asynchronous error source: an egress violation on the host-memory port (adversarial AXI master wired in through x_*) raises
  // ERR_STATUS.DMA_PROT (bit 9) at a time unrelated to the in-order MMIO engine that performs the clear.  The AR is fired at a swept
  // cycle around the cycle at which the clear (a posted MWr to ERR_STATUS) gets performed.
  int collisions = 0, bad = 0;
  for (int off = -30; off <= 40; off++) {
    Env e(1300 + off + 30);
    e.d->x_sel = 1; e.d->x_r_ready = 1; e.d->x_b_ready = 1;
    auto fire_ar = [&](bool v) {
      e.d->x_ar_valid = v; e.d->x_ar_id = 0; e.d->x_ar_addr = 0x1000; e.d->x_ar_len = 0; e.d->x_ar_size = 4; e.d->x_ar_burst = 1;
      e.d->x_ar_mtype = 0; e.d->x_ar_domain = 9;                                                // domain 9 owns no context: refused, class DMA_PROT
    };
    // warm-up: raise DMA_PROT once so the clear has something to clear
    { bool done = false; e.hook_drive = [&]() { fire_ar(!done); }; e.hook_sample = [&]() { if (e.d->x_ar_valid && e.d->x_ar_ready) done = true; };
      e.idle(200); e.hook_drive = nullptr; e.hook_sample = nullptr; fire_ar(false); }
    bool pre = (e.r32(0, sfpb::R_ERR_STATUS) >> 9) & 1; C.ok(pre, "precondition: DMA_PROT is set before the clear", off);
    bool collided = false, accepted = false; uint64_t c0 = 0;
    e.hook_drive  = [&]() { fire_ar(!accepted && e.cyc >= c0 + (uint64_t)(30 + off)); };       // hold valid until the AR is accepted
    e.hook_sample = [&]() { if (e.d->x_ar_valid && e.d->x_ar_ready) accepted = true; if (e.d->dbg_err_w1c && e.d->dbg_err_ev) collided = true; };
    c0 = e.cyc; e.w32(0, sfpb::R_ERR_STATUS, 0x200, 0x2);                                       // clear bit 9 (byte 1 only)
    e.idle(400);
    e.hook_drive = nullptr; e.hook_sample = nullptr; fire_ar(false); e.d->x_sel = 0; e.idle(5);
    bool set = (e.r32(0, sfpb::R_ERR_STATUS) >> 9) & 1;
    if (collided) { collisions++; bad += !set; }
    C.ok(accepted, "the violating AR was accepted by the bridge", off);
  }
  C.ok(collisions > 0, "the sweep produced at least one same-cycle collision (probe is live)", collisions);
  C.ok(bad == 0, "ERR_STATUS: a class raised in the same cycle as its write-1-to-clear survives", bad);
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  int f0 = C.fails; C.tag = "irq_status"; t_irq_status(); std::printf("  %-18s %s\n", "irq_status", C.fails == f0 ? "PASS" : "FAIL");
  f0 = C.fails;     C.tag = "err_status"; t_err_status(); std::printf("  %-18s %s\n", "err_status", C.fails == f0 ? "PASS" : "FAIL");
  std::printf("tb_race DATA_W=%d: %d checks, %d failures\n", DW, C.checks, C.fails);
  return C.fails ? 1 : 0;
}
