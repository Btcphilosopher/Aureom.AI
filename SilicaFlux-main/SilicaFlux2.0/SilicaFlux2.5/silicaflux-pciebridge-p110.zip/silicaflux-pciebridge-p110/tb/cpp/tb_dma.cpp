// DMA tests: host <-> device transfers through the bridge, StreamDMA and the simulated root complex.
// Covers: byte accuracy (aligned / unaligned), completion reordering and splitting, translation, strict write
// acknowledge, posted-write ordering against MMIO completions, protection (submit and egress), host-side faults,
// tag exhaustion and quarantine.
#include "tb_dma_lib.h"
using namespace env;
static Checker C;
struct Test { const char* name; std::function<void(Env&)> fn; };

static void finish(Env& e, const char* what) {
  e.idle(400); C.ok(e.no_violations(), what, e.n_viol); if (!e.no_violations()) e.print_violations();
}
static void dump(Env& e, const CplRec& r) {
  std::printf("    rq tlps=%llu rc tlps=%llu cc=%llu viol=%d\n", (unsigned long long)e.n_rq_tlps, (unsigned long long)e.n_rc_tlps, (unsigned long long)e.n_cc_tlps, e.n_viol);
  std::printf("    rec: status=%d err=0x%02X detail=%d perr=0x%02X done=%u total=%u eaddr=0x%llx\n", r.status, r.err, r.detail, r.perr, r.done, r.total, (unsigned long long)r.eaddr);
  e.print_violations();
}
static bool expect_ok(Env& e, Dma& dma, int ctx, uint16_t txn, uint32_t len, const char* what) {
  CplRec r; bool got = dma.wait_record(ctx, r);
  C.ok(got, what, txn);
  if (!got) return false;
  bool ok = r.status == 0 && r.done == len && r.total == len && r.txn == txn;
  C.ok(r.status == 0, "completion status OK", r.status, 0);
  C.ok(r.done == len && r.total == len, "bytes done == bytes total == length", r.done, len);
  C.ok(r.txn == txn, "txn id returned", r.txn, txn);
  if (!ok) dump(e, r);
  return ok;
}
// completion timeout (in 16-cycle ticks) comfortably above the root's worst service time in this mode
static uint32_t safe_timeout_ticks(const Env& e) { return (e.cfg.host_lat_hi + 400 + 2 * e.cfg.link_rq) / 16 + 4; }
static uint64_t host_bus(int ctx, uint64_t iova) { return ctx == 1 ? HOST1_BUS + (iova - HOST1_IOVA) : iova; }

// ---------------------------------------------------------------------------------------------------------------------
static void t_h2d_basic(Env& e) {
  Dma dma(e); dma.setup_defaults();
  for (uint32_t len : {16u, 64u, 256u, 1024u, 4096u}) {
    uint64_t src = HOST0_IOVA + 0x1000, dst = DEV_BASE + 0x2000;
    dma.fill_host(0, src, len); for (uint32_t i = 0; i < len + 64; i++) e.dev_mem[dst - DEV_BASE + i] = 0xEE;
    auto s = dma.h2d(0, 0x100 + len % 97, src, dst, len);
    C.ok(s.status() == 1, "descriptor accepted", s.status(), s.code());
    expect_ok(e, dma, 0, 0x100 + len % 97, len, "h2d completes");
    C.ok(dma.dev_equals_host(0, dst, src, len), "device memory equals host memory (byte exact)", len);
    bool canary = true; for (uint32_t i = len; i < len + 64; i++) canary &= (e.dev_mem[dst - DEV_BASE + i] == 0xEE); C.ok(canary, "bytes after the destination untouched", len);
  }
  finish(e, "h2d_basic: no violations");
}
static void t_d2h_basic(Env& e) {
  Dma dma(e); dma.setup_defaults();
  for (uint32_t len : {16u, 64u, 256u, 1024u, 4096u}) {
    uint64_t dst = HOST0_IOVA + 0x8000, src = DEV_BASE + 0x4000;
    dma.fill_dev(src, len); for (uint32_t i = 0; i < len + 64; i++) e.hm.wr(dst + i, 0xCC); for (int i = 1; i <= 32; i++) e.hm.wr(dst - i, 0xCC);
    auto s = dma.d2h(0, 0x200 + len % 89, src, dst, len);
    C.ok(s.status() == 1, "descriptor accepted", s.status(), s.code());
    expect_ok(e, dma, 0, 0x200 + len % 89, len, "d2h completes");
    C.ok(dma.dev_equals_host(0, src, dst, len), "host memory equals device memory (byte exact)", len);
    bool canary = true; for (uint32_t i = len; i < len + 64; i++) canary &= (e.hm.rd(dst + i) == 0xCC); for (int i = 1; i <= 32; i++) canary &= (e.hm.rd(dst - i) == 0xCC);
    C.ok(canary, "host bytes around the destination untouched", len);
  }
  finish(e, "d2h_basic: no violations");
}

static void t_unaligned(Env& e) {
  Dma dma(e); dma.setup_defaults();
  for (int it = 0; it < 40; it++) {
    bool h2d = it & 1; uint32_t len = (it % 7 == 6) ? 1000 + e.rng.below(2500) : 1 + e.rng.below(300);
    uint64_t host = HOST0_IOVA + 0x4000 + e.rng.below(0x2000), dev = DEV_BASE + 0x8000 + e.rng.below(0x2000);
    uint16_t txn = 0x300 + it;
    // canaries around the destination
    if (h2d) { dma.fill_host(0, host, len); for (uint32_t i = 0; i < len + 80; i++) e.dev_mem[dev - DEV_BASE - 40 + i] = 0xEE; }
    else     { dma.fill_dev(dev, len); for (uint32_t i = 0; i < len + 80; i++) e.hm.wr(host - 40 + i, 0xCC); }
    auto s = h2d ? dma.h2d(0, txn, host, dev, len) : dma.d2h(0, txn, dev, host, len);
    C.ok(s.status() == 1, "descriptor accepted", s.status(), s.code());
    if (!expect_ok(e, dma, 0, txn, len, "unaligned transfer completes")) continue;
    C.ok(dma.dev_equals_host(0, dev, host, len), "unaligned copy is byte exact", len, h2d);
    bool canary = true;
    for (int i = 1; i <= 40; i++) {
      if (h2d) { canary &= (e.dev_mem[dev - DEV_BASE - i] == 0xEE); canary &= (e.dev_mem[dev - DEV_BASE + len - 1 + i] == 0xEE); }
      else     { canary &= (e.hm.rd(host - i) == 0xCC); canary &= (e.hm.rd(host + len - 1 + i) == 0xCC); }
    }
    C.ok(canary, "no byte outside the destination range was written", len, h2d);
  }
  finish(e, "unaligned: no violations");
}

static void t_reorder(Env& e) {
  e.cfg.mrrs_code = 0; e.cfg.host_lat_lo = 10; e.cfg.host_lat_hi = 400; e.cfg.split = 3;       // 128 B reads, 10..400 cycle service time, random split points
  Dma dma(e); dma.setup_defaults();
  const uint32_t len = 32768; uint64_t src = HOST0_IOVA, dst = DEV_BASE;
  dma.fill_host(0, src, len);
  auto s = dma.h2d(0, 0x400, src, dst, len); C.ok(s.status() == 1, "descriptor accepted", s.status(), s.code());
  expect_ok(e, dma, 0, 0x400, len, "32 KiB read with heavy completion reordering");
  C.ok(dma.dev_equals_host(0, dst, src, len), "data identical despite reordered, split completions");
  C.ok(e.reorder_events > 5, "completions really were reordered across requests", e.reorder_events, 5);
  // many requests were in flight at once
  e.w32(0, sfpb::R_PERF_SEL, sfpb::PC_OUT_MAX); uint32_t om = e.r32(0, sfpb::R_PERF_LO);
  C.ok(om >= 4 && om <= 16, "outstanding requests peaked within the tag budget", om, 16);
  finish(e, "reorder: no violations");
}

static void t_translated(Env& e) {
  Dma dma(e); dma.setup_defaults();
  uint64_t iova = HOST1_IOVA + 0x100, dev = DEV_BASE + 0x100; uint32_t len = 3000;
  dma.fill_host(1, iova, len);
  auto s = dma.h2d(1, 0x500, iova, dev, len); C.ok(s.status() == 1, "descriptor accepted (translated ctx)", s.status(), s.code());
  expect_ok(e, dma, 1, 0x500, len, "translated h2d");
  C.ok(dma.dev_equals_host(1, dev, iova, len), "device got the bytes from the TRANSLATED bus address");
  // the IOVA itself holds nothing: the translation really happened
  bool zero = true; for (uint32_t i = 0; i < 64; i++) zero &= (e.hm.rd(iova + i) == 0); C.ok(zero, "nothing was read from the untranslated address");
  uint64_t dst = HOST1_IOVA + 0x2000; dma.fill_dev(dev + 0x4000, 700);
  s = dma.d2h(1, 0x501, dev + 0x4000, dst, 700); C.ok(s.status() == 1, "d2h accepted", s.status(), s.code());
  expect_ok(e, dma, 1, 0x501, 700, "translated d2h");
  bool eq = true; for (uint32_t i = 0; i < 700; i++) eq &= (e.hm.rd(HOST1_BUS + 0x2000 + i) == e.dev_mem[dev + 0x4000 - DEV_BASE + i]); C.ok(eq, "device bytes landed at the translated bus address");
  finish(e, "translated: no violations");
}

static void t_strict_ack(Env& e) {
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_CTRL, 0x2F);                              // WR_FLUSH_EN
  const uint32_t len = 2048; uint64_t src = DEV_BASE + 0x100, dst = HOST0_IOVA + 0x100; dma.fill_dev(src, len);
  size_t n0 = e.rqlog.size();
  auto s = dma.d2h(0, 0x600, src, dst, len); C.ok(s.status() == 1, "descriptor accepted", s.status(), s.code());
  expect_ok(e, dma, 0, 0x600, len, "d2h with strict write acknowledge");
  int mwr = 0, fl = 0; bool order_ok = true; std::set<uint64_t> written;
  for (size_t i = n0; i < e.rqlog.size(); i++) {
    auto& r = e.rqlog[i];
    if (r.type == MWR) { mwr++; written.insert(r.addr); }
    else if (r.ndw == 1 && r.fbe == 0 && r.lbe == 0) { fl++; if (!written.count(r.addr)) order_ok = false; }   // the flush targets the start of an already-sent write TLP
  }
  C.ok(fl == len / 256, "one zero-length flush read per 256-byte write burst", fl, len / 256);
  C.ok(order_ok, "every flush read follows (in the RQ stream) the write TLP whose address it names");
  C.ok(dma.dev_equals_host(0, src, dst, len), "data identical");
  // the flush reads completed: nothing outstanding
  uint32_t st = e.r32(0, sfpb::R_STATUS); C.ok(((st >> 8) & 0xFF) == 0, "no request outstanding after completion", (st >> 8) & 0xFF);
  finish(e, "strict_ack: no violations");
}

static void t_mmio_during_dma(Env& e) {
  e.cfg.link_rq = 90; e.cfg.link_cc = 4;                                                       // posted writes are SLOW, completions FAST: the ordering gate must hold completions back
  Dma dma(e); dma.setup_defaults();
  std::vector<uint8_t> shadow(256, 0);
  const uint32_t len = 4096; uint64_t src = DEV_BASE, dst = HOST0_IOVA + 0x10000; dma.fill_dev(src, len);
  auto s = dma.d2h(0, 0x700, src, dst, len); C.ok(s.status() == 1, "descriptor accepted", s.status(), s.code());
  int reads = 0, bad = 0;
  for (int it = 0; it < 120; it++) {
    uint32_t off = 4 * (it % 60); uint32_t v = e.rng.u32();
    e.mmio_write(2, off, {v}); for (int b = 0; b < 4; b++) shadow[off + b] = v >> (8 * b);
    auto h = e.mmio_read(2, off); reads++; if (h.bad || h.data.size() != 1 || h.data[0] != v) bad++;
    if (it % 10 == 0) e.r32(0, sfpb::R_SCRATCH);
  }
  C.ok(bad == 0, "MMIO reads during DMA returned the right data", bad, reads);
  expect_ok(e, dma, 0, 0x700, len, "DMA completes while the host hammers MMIO");
  C.ok(dma.dev_equals_host(0, src, dst, len), "DMA data identical");
  C.ok(e.rq_accepted >= 16, "posted writes were actually issued", e.rq_accepted);
  e.w32(0, sfpb::R_PERF_SEL, sfpb::PC_ORD_STALL); uint32_t os = e.r32(0, sfpb::R_PERF_LO);
  C.ok(os > 0, "the ordering gate really held completions behind posted writes (not a vacuous pass)", os);
  finish(e, "mmio_during_dma: no ordering violations");
}

// ---------------------------------------------------------------------------------------------------------------------
static void t_submit_rejects(Env& e) {
  Dma dma(e); dma.setup_defaults();
  uint64_t h = HOST0_IOVA + 0x1000, dv = DEV_BASE + 0x1000;
  size_t rq0 = e.rqlog.size(); uint64_t cnt0 = e.dev_wr_cnt + e.dev_rd_cnt;
  struct Case { const char* name; SubmitRes r; int expect; };
  std::vector<Case> cs;
  cs.push_back({"valid control case", dma.h2d(0, 1, h, dv, 64), 1});
  { CplRec r; dma.wait_record(0, r); }
  cs.push_back({"unprogrammed context", dma.h2d(3, 2, h, dv, 64), 0x30});
  cs.push_back({"version 2", dma.submit(0, 3, 0, 1, h, dv, 64, 0x3, -1, 2), 0x35});
  cs.push_back({"opcode 1", dma.submit(0, 4, 0, 1, h, dv, 64, 0x3, -1, 1, 1), 0x35});
  cs.push_back({"flags without FIRST|LAST (chain)", dma.submit(0, 5, 0, 1, h, dv, 64, 0x1), 0x35});
  cs.push_back({"reserved flag bit", dma.submit(0, 6, 0, 1, h, dv, 64, 0x3 | 0x20), 0x35});
  cs.push_back({"reserved W2 bits", dma.submit(0, 7, 0, 1, h, dv, 64, 0x3, -1, 1, 0, 0x100), 0x35});
  cs.push_back({"domain spoof (ctx0 page claims domain 1)", dma.submit(0, 8, 0, 1, h, dv, 64, 0x3, 1), 0x32});
  cs.push_back({"host-to-host", dma.submit(0, 9, 0, 0, h, h + 0x400, 64), 0x34});
  cs.push_back({"device-to-device", dma.submit(0, 10, 1, 1, dv, dv + 0x400, 64), 0x34});
  cs.push_back({"zero length", dma.h2d(0, 11, h, dv, 0), 0x33});
  cs.push_back({"length above the context maximum", dma.h2d(0, 12, h, dv, 0x20000), 0x33});
  cs.push_back({"source below the window", dma.h2d(0, 13, HOST0_IOVA - 0x1000, dv, 64), 0x31});
  cs.push_back({"source above the window", dma.h2d(0, 14, HOST0_IOVA + WIN_SIZE + 0x1000, dv, 64), 0x31});
  cs.push_back({"source straddles the window end", dma.h2d(0, 15, HOST0_IOVA + WIN_SIZE - 32, dv, 64), 0x31});
  cs.push_back({"64-bit wrap-around range", dma.h2d(0, 16, 0xFFFF'FFFF'FFFF'F000ull, dv, 0x2000), 0x31});
  cs.push_back({"device range outside the device window", dma.h2d(0, 17, h, DEV_BASE + DEV_SIZE - 16, 64), 0x31});
  cs.push_back({"write to host through a read-only context", dma.d2h(2, 18, dv, HOST2_IOVA + 0x100, 64), 0x32});
  cs.push_back({"read from host through a read-only context (allowed)", dma.h2d(2, 19, HOST2_IOVA + 0x100, dv, 64), 1});
  for (auto& c : cs) {
    bool ok = (c.expect == 1) ? c.r.status() == 1 : (c.r.status() == 3 && c.r.code() == c.expect);
    C.ok(ok, c.name, c.r.status() * 1000 + c.r.code(), c.expect);
  }
  // let the two accepted descriptors finish, then check that the rejected ones left no trace on PCIe / device memory
  CplRec r; dma.wait_record(2, r);
  e.idle(500);
  size_t mrd = 0; for (size_t i = rq0; i < e.rqlog.size(); i++) if (e.rqlog[i].type == MRD) mrd++;
  C.ok(mrd <= 2, "rejected descriptors produced no PCIe traffic (only the 2 accepted reads)", mrd, 2);
  C.ok((e.dev_wr_cnt + e.dev_rd_cnt) - cnt0 <= 4, "rejected descriptors caused no device-memory traffic");
  uint32_t es = e.r32(0, sfpb::R_ERR_STATUS); C.ok((es >> 9) & 1, "ERR_STATUS.DMA_PROT is set", es);
  // DMA disabled
  e.w32(0, sfpb::R_CTRL, 0x23);
  auto d = dma.h2d(0, 20, h, dv, 64); C.ok(d.status() == 3 && d.code() == 0x30, "DMA disabled by CTRL.DMA_EN = 0", d.status(), d.code());
  finish(e, "submit_rejects: no violations");
}

static void t_egress_overreach(Env& e) {
  // window exactly covers the byte range, but StreamDMA reads/writes a beat-aligned ENVELOPE that sticks out of it:
  // the egress check refuses it, nothing is sent, the DMA reports an error and the log names the violation.
  Dma dma(e); dma.setup_defaults();
  uint64_t wbase = HOST0_IOVA + 0x7008;                                                       // 8 bytes past a 16-byte boundary
  dma.setup(0, wbase, 0x100, true, true, false, 0);
  size_t rq0 = e.rqlog.size();
  dma.fill_host(0, wbase, 0x100);
  auto s = dma.h2d(0, 0x800, wbase, DEV_BASE + 0x100, 0x100); C.ok(s.status() == 1, "submit passes (exact range is inside the window)", s.status(), s.code());
  CplRec r; bool got = dma.wait_record(0, r); C.ok(got, "record arrives");
  C.ok(r.status == 1 && r.err == 0x30, "DMA fails with a bus read error (the envelope was refused)", r.status, r.err);
  C.ok(r.done == 0, "no byte moved", r.done);
  size_t mrd = 0; for (size_t i = rq0; i < e.rqlog.size(); i++) mrd += (e.rqlog[i].type == MRD);
  C.ok(mrd == 0, "no read request left the device", mrd, 0);
  uint32_t l0 = e.r32(0, sfpb::R_DMA_ERR_LOG0); C.ok(((l0 >> 12) & 1) && (l0 & 0x3F) == 0x31, "DMA_ERR_LOG names DMA_WINDOW", l0);
  uint32_t es = e.r32(0, sfpb::R_ERR_STATUS); C.ok((es >> 9) & 1, "ERR_STATUS.DMA_PROT", es);
  // the same for a write (device -> host): the strobes would only touch inside the window but the AW envelope does not fit
  dma.fill_dev(DEV_BASE + 0x400, 0x100); r = CplRec();
  s = dma.d2h(0, 0x801, DEV_BASE + 0x400, wbase, 0x100); got = dma.wait_record(0, r);
  C.ok(got && r.status == 1 && r.err == 0x31, "write envelope over-reach is refused (B error)", r.status, r.err);
  size_t mwr = 0; for (size_t i = rq0; i < e.rqlog.size(); i++) mwr += (e.rqlog[i].type == MWR); C.ok(mwr == 0, "no posted write left the device", mwr, 0);
  finish(e, "egress_overreach: no violations");
}

// ---------------------------------------------------------------------------------------------------------------------
struct FaultCase { const char* name; Fault::Kind k; uint32_t expect_perr; bool timeout_based; };
static void t_host_faults(Env& e) {
  Dma dma(e); dma.setup_defaults();
  e.w32(0, sfpb::R_CPL_TIMEOUT, safe_timeout_ticks(e));
  const FaultCase cases[] = {
    {"completion UR", Fault::UR, 0x20, false}, {"completion CA", Fault::CA, 0x21, false}, {"poisoned data", Fault::POISON, 0x23, false},
    {"byte count too large", Fault::BAD_BC, 0x25, false}, {"lower address wrong", Fault::BAD_LOWER, 0x25, false},
    {"payload shorter than the descriptor says", Fault::SHORT, 0x25, false}, {"payload longer than the descriptor says", Fault::LONG, 0x25, false},
    {"endpoint reports a timeout", Fault::IPERR, 0x24, false}, {"endpoint reports FLR", Fault::RCE_FLR, 0x2B, false},
    {"no completion at all", Fault::DROP, 0x24, true},
    // completions that must NOT be accepted for the request they pretend to answer (the request then times out / fails)
    {"completion longer than the request owes (dword count and payload; byte count consistent)", Fault::OVERLEN, 0x28, false},
    {"completion with the wrong requester id (check enabled)", Fault::WRONG_REQID, 0x24, true},
    {"completion with a tag that owns nothing", Fault::WRONG_TAG, 0x24, true},
    {"first completion delivered twice", Fault::DUP_FIRST, 0x25, false},
    {"only the first of several completions ever arrives", Fault::TRUNC, 0x24, true},
  };
  int ntag_leak = 0;
  for (auto& fc : cases) {
    e.root_tags.clear();
    uint64_t src = HOST0_IOVA + 0x2000, dst = DEV_BASE + 0x3000; uint32_t len = 128;              // one burst, one TLP: the destination must stay untouched on failure
    dma.fill_host(0, src, len); for (uint32_t i = 0; i < 256; i++) e.dev_mem[dst - DEV_BASE + i] = 0xEE;
    Fault f; f.kind = fc.k; f.addr_lo = host_bus(0, src); f.addr_hi = host_bus(0, src) + len; e.faults = {f};
    const int split0 = e.cfg.split; if (fc.k == Fault::DUP_FIRST || fc.k == Fault::TRUNC) e.cfg.split = 1;      // these faults only exist when the completion is split (RCB 64 B: two pieces)
    auto s = dma.h2d(0, 0x900, src, dst, len); C.ok(s.status() == 1, "descriptor accepted", s.status(), s.code());
    CplRec r; bool got = dma.wait_record(0, r, 600000); C.ok(got, fc.name); e.cfg.split = split0;
    if (!got) continue;
    C.ok(r.status == 1, "transfer is reported as FAILED, never as success", r.status);
    C.ok(r.err == 0x30, "StreamDMA reports a bus read error", r.err);
    C.ok(r.perr == fc.expect_perr, fc.name, r.perr, fc.expect_perr);
    C.ok(r.done == 0, "no bytes counted as transferred", r.done);
    bool untouched = true; for (uint32_t i = 0; i < 256; i++) untouched &= (e.dev_mem[dst - DEV_BASE + i] == 0xEE);
    C.ok(untouched, "no partial data reached the destination", fc.k);
    e.faults.clear(); e.idle(600);
    uint32_t st = e.r32(0, sfpb::R_STATUS); uint32_t nz = (st >> 16) & 0xFF;
    // the faulted request must not leave a request outstanding; zombies only for failures that may still produce late completions
    C.ok(((st >> 8) & 0xFF) == 0, "nothing left outstanding", (st >> 8) & 0xFF, fc.k);
    ntag_leak += nz; C.ok(nz <= 1, "at most the faulted tag is quarantined", nz);
    e.w32(0, sfpb::R_CTRL, 0x2F7 & 0x3F | 0x800 | 0x27); e.w32(0, sfpb::R_ERR_STATUS, 0xFFFF);  // ZOMBIE_CLR + clear sticky errors
    e.idle(10);
    uint32_t st2 = e.r32(0, sfpb::R_STATUS); C.ok(((st2 >> 16) & 0xFF) == 0, "ZOMBIE_CLR releases quarantined tags", (st2 >> 16) & 0xFF);
    e.w32(0, sfpb::R_CTRL, 0x27);
  }
  (void)ntag_leak;
  finish(e, "host_faults: no violations (no tag reuse while quarantined)");
}

static void t_tag_quarantine(Env& e) {
  Dma dma(e); dma.setup_defaults();
  e.w32(0, sfpb::R_CPL_TIMEOUT, safe_timeout_ticks(e));
  uint64_t src = HOST0_IOVA + 0x100; dma.fill_host(0, src, 256);
  Fault f; f.kind = Fault::DROP; f.addr_lo = host_bus(0, src); f.addr_hi = host_bus(0, src) + 64; f.count = 1; e.faults = {f};
  auto s = dma.h2d(0, 0xA00, src, DEV_BASE, 64); C.ok(s.status() == 1, "accepted", s.status(), s.code());
  CplRec r; dma.wait_record(0, r); C.ok(r.status == 1 && r.perr == 0x24, "first transfer fails by timeout", r.status, r.perr);
  uint32_t st = e.r32(0, sfpb::R_STATUS); C.ok(((st >> 16) & 0xFF) == 1, "exactly one tag is quarantined", (st >> 16) & 0xFF, 1);
  // now run far more requests than there are tags: the quarantined tag must never be handed out again
  for (int i = 0; i < 6; i++) {
    uint64_t a = HOST0_IOVA + 0x4000; dma.fill_host(0, a, 4096);
    s = dma.h2d(0, 0xA10 + i, a, DEV_BASE + 0x1000, 4096); expect_ok(e, dma, 0, 0xA10 + i, 4096, "traffic continues around the quarantined tag");
  }
  C.ok(e.no_violations(), "the quarantined tag was never reused (monitor would flag reuse of an unanswered tag)", e.n_viol);
  // a LATE completion for the quarantined tag is dropped and counted, never mistaken for anything else
  e.root_tags.clear(); e.w32(0, sfpb::R_CTRL, 0x827);                                       // ZOMBIE_CLR
  finish(e, "tag_quarantine: no violations");
}

static void t_tag_exhaustion(Env& e) {
  e.cfg.host_lat_lo = 300; e.cfg.host_lat_hi = 500; e.cfg.mrrs_code = 0;                       // slow root: all 16 tags are needed
  Dma dma(e); dma.setup_defaults();
  const uint32_t len = 65536; uint64_t src = HOST0_IOVA, dst = DEV_BASE; dma.fill_host(0, src, len);
  auto s = dma.h2d(0, 0xB00, src, dst, len); C.ok(s.status() == 1, "accepted", s.status(), s.code());
  expect_ok(e, dma, 0, 0xB00, len, "64 KiB through 16 tags");
  C.ok(dma.dev_equals_host(0, dst, src, len), "data identical");
  e.w32(0, sfpb::R_PERF_SEL, sfpb::PC_OUT_MAX); uint32_t om = e.r32(0, sfpb::R_PERF_LO);
#ifdef TAGS_FEW
  C.ok(om == 4, "every one of the 4 tags was in use at once", om, 4);
#else
  C.ok(om == 8, "4 read slots x 2 TLPs per burst = 8 tags in use at once", om, 8);
#endif
  e.w32(0, sfpb::R_PERF_SEL, sfpb::PC_TAG_STALL); uint32_t ts = e.r32(0, sfpb::R_PERF_LO);
#ifdef TAGS_FEW
  C.ok(ts > 0, "the bridge stalled for lack of tags (and did not reuse any)", ts);
#endif
  finish(e, "tag_exhaustion: no violations");
}

static void t_cpl_isolation(Env& e) {
  // a context that never drains its completion queue loses records (flagged) but cannot stall another context
  Dma dma(e); dma.setup_defaults();
  uint64_t h0 = HOST0_IOVA + 0x100, h1 = HOST1_IOVA + 0x100;
  for (int i = 0; i < 8; i++) { dma.fill_host(0, h0, 64); auto s = dma.h2d(0, 0xC00 + i, h0, DEV_BASE + 0x100 * i, 64); C.ok(s.status() == 1 || s.status() == 2, "ctx0 submit", s.status());
    if (s.status() == 2) { e.idle(2000); i--; } else e.idle(100); }
  e.idle(3000);
  uint32_t cs = e.r32(0, 0x1000 + sfpb::C_CPL_STATUS); C.ok((cs & 0xF) == 4, "ctx0 queue is full (4 records)", cs & 0xF); C.ok((cs >> 8) & 1, "ctx0 overflow flag is set (records were lost, visibly)", cs);
  dma.fill_host(1, h1, 128); auto s = dma.h2d(1, 0xC80, h1, DEV_BASE + 0x2000, 128); C.ok(s.status() == 1, "ctx1 submit", s.status(), s.code());
  expect_ok(e, dma, 1, 0xC80, 128, "ctx1 is not blocked by ctx0's full queue");
  // EVERY context's queue full: StreamDMA must still never be back-pressured (an undrained record may be dropped, never waited for)
  dma.setup(3, HOST0_IOVA + 0x40000, 0x10000, true, true, false, 0);                  // context 3 exists too (its queue was empty until now)
  e.w32(0, sfpb::R_CTRL, 0x27);
  const int cx[3] = {1, 2, 3}; const uint64_t base[3] = {HOST1_IOVA, HOST2_IOVA, HOST0_IOVA + 0x40000};
  for (int k = 0; k < 3; k++) for (int i = 0; i < 6; i++) {
    int c = cx[k]; uint64_t a = base[k] + 0x100; dma.fill_host(c, a, 64);
    auto q = dma.h2d(c, 0xD00 + 16 * k + i, a, DEV_BASE + 0x4000 + 0x100 * i, 64);
    if (q.status() == 2) { e.idle(2000); i--; } else e.idle(300);
  }
  e.idle(3000);
  for (int c = 0; c < 4; c++) { uint32_t q = e.r32(0, 0x1000 * (1 + c) + sfpb::C_CPL_STATUS); C.ok((q & 0xF) == 4, "every context's completion queue is full", q & 0xF, c); }
  dma.fill_host(0, h0, 64); auto s2 = dma.h2d(0, 0xDF0, h0, DEV_BASE + 0x5000, 64); C.ok(s2.status() == 1, "one more transfer is accepted", s2.status(), s2.code());
  e.idle(4000);
  uint32_t c0 = e.r32(0, 0x1000 + sfpb::C_CPL_STATUS);
  C.ok((c0 >> 16) == 0, "its completion was CONSUMED although every queue is full (StreamDMA is never back-pressured)", c0 >> 16);
  C.ok(dma.dev_equals_host(0, DEV_BASE + 0x5000, h0, 64), "and its data arrived");
  finish(e, "cpl_isolation: no violations");
}

static void t_missing_acks(Env& e) {
  // The endpoint never returns the RQ sequence-number acknowledge (its contract is broken).  Completions are held by the ordering gate
  // until the watchdog resynchronises the counters after ORD_TIMEOUT cycles: nothing may be held forever, and the broken contract
  // must be REPORTED (DMA_ORDER), never silent.
  e.drop_acks = true;
  Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_ERR_LOG_CLR, 1);
  dma.fill_dev(DEV_BASE, 256); auto s = dma.d2h(0, 0xF10, DEV_BASE, HOST0_IOVA + 0x3000, 256); C.ok(s.status() == 1, "device->host DMA accepted", s.status(), s.code());
  CplRec r; bool got = dma.wait_record(0, r, 600000); C.ok(got && r.status == 0, "the DMA itself completes (posted writes need no acknowledge)", r.status);
  uint64_t t0 = e.cyc; auto h = e.mmio_read(0, sfpb::R_ID);
  C.ok(!h.bad && h.data.size() == 1 && h.data[0] == 0x53465042u, "a completion held by the ordering gate is released by the watchdog (nothing is held forever)");
  uint32_t l0 = e.r32(0, sfpb::R_ERR_LOG0);
  C.ok((l0 & 0x100) && (l0 & 0x3F) == 0x39, "the missing acknowledge is REPORTED as DMA_ORDER (0x39), not silent", l0);
  e.drop_acks = false; e.idle(50);
  finish(e, "missing_acks: no violations");
}

static void t_ctx_rules(Env& e) {
  // privileged table: atomic commit, refusal rules, lock; the host has no path to it
  Dma dma(e); dma.setup_defaults();
  uint32_t cs;
  cs = e.priv_rd(3 * 0x40 + sfpb::P_COMMIT_STATUS); (void)cs;
  // inconsistent entries are refused and leave the old mapping alone
  cs = e.ctx_program(3, true, true, true, true, HOST0_IOVA, WIN_SIZE, HOST0_IOVA + 2, DEV_BASE, DEV_SIZE, 4096);       // translation breaks dword alignment
  C.ok(!(cs & 1) && ((cs >> 4) & 0xF) == 2, "translation that breaks dword alignment is refused (code 2)", cs);
  cs = e.ctx_program(3, true, true, true, false, 0, 0, 0, DEV_BASE, DEV_SIZE, 4096);                                   // empty window
  C.ok(!(cs & 1) && ((cs >> 4) & 0xF) == 3, "empty window is refused (code 3)", cs);
  cs = e.ctx_program(3, true, true, true, false, 0xFFFF'FFFF'FFFF'F000ull, 0x2000, 0, DEV_BASE, DEV_SIZE, 4096);        // wraps
  C.ok(!(cs & 1) && ((cs >> 4) & 0xF) == 3, "wrapping window is refused (code 3)", cs);
  C.ok((e.r32(0, 0x4000 + sfpb::C_CTX_INFO) & 1) == 0, "refused commits left context 3 invalid");
  // commit while a transfer is outstanding is refused, the running transfer is unaffected
  e.cfg.host_lat_lo = 200; e.cfg.host_lat_hi = 200; dma.fill_host(0, HOST0_IOVA, 4096);
  auto s = dma.h2d(0, 0x1, HOST0_IOVA, DEV_BASE, 4096); C.ok(s.status() == 1, "accepted", s.status(), s.code());
  e.idle(100);
  cs = e.ctx_program(0, true, true, true, false, HOST0_IOVA + 0x100000, WIN_SIZE, 0, DEV_BASE, DEV_SIZE, 4096);
  C.ok(!(cs & 1) && ((cs >> 4) & 0xF) == 1, "re-mapping while DMA is in flight is refused (code 1: quiesce first)", cs);
  expect_ok(e, dma, 0, 1, 4096, "the running transfer completes with the OLD mapping");
  C.ok(dma.dev_equals_host(0, DEV_BASE, HOST0_IOVA, 4096), "data from the old mapping");
  e.idle(300);
  cs = e.ctx_program(0, true, true, true, false, HOST0_IOVA + 0x100000, WIN_SIZE, 0, DEV_BASE, DEV_SIZE, 4096);
  C.ok((cs & 1) == 1, "the same commit succeeds once quiescent", cs);
  // revoke: a context made invalid refuses new descriptors immediately
  cs = e.ctx_program(0, false, false, false, false, 0, 0, 0, 0, 0, 0); C.ok((cs & 1) == 1, "a context can be revoked", cs);
  auto r = dma.h2d(0, 0x2, HOST0_IOVA, DEV_BASE, 64); C.ok(r.status() == 3 && r.code() == 0x30, "descriptors for a revoked context are refused", r.status(), r.code());
  // the host cannot reach the table: hammering every register of every page changes nothing
  uint32_t info1 = e.r32(0, 0x2000 + sfpb::C_CTX_INFO);
  for (uint32_t pg = 0; pg < 5; pg++) for (uint32_t off = 0; off < 0x100; off += 4) e.w32(0, 0x1000 * pg + off, 0xFFFFFFFF);
  e.w32(0, sfpb::R_CTRL, 0x27);
  C.ok(e.r32(0, 0x2000 + sfpb::C_CTX_INFO) == info1, "host writes to every BAR0 register do not change the trusted context", info1);
  // lock: set-only, freezes the table until reset
  e.priv_wr(sfpb::P_PRIV_CTRL, 1); C.ok((e.priv_rd(sfpb::P_PRIV_CTRL) & 1) == 1, "LOCK is set");
  cs = e.ctx_program(1, true, true, true, false, HOST0_IOVA, WIN_SIZE, 0, DEV_BASE, DEV_SIZE, 4096);
  C.ok(!(cs & 1) && ((cs >> 4) & 0xF) == 4, "commits are refused after LOCK (code 4)", cs);
  e.priv_wr(sfpb::P_PRIV_CTRL, 0); C.ok((e.priv_rd(sfpb::P_PRIV_CTRL) & 1) == 1, "LOCK cannot be cleared by software");
  finish(e, "ctx_rules: no violations");
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  std::vector<Test> tests = {{"h2d_basic", t_h2d_basic}, {"d2h_basic", t_d2h_basic}, {"unaligned", t_unaligned}, {"reorder", t_reorder},
                             {"translated", t_translated}, {"strict_ack", t_strict_ack}, {"mmio_during_dma", t_mmio_during_dma},
                             {"submit_rejects", t_submit_rejects}, {"egress_overreach", t_egress_overreach}, {"host_faults", t_host_faults},
                             {"tag_quarantine", t_tag_quarantine}, {"tag_exhaustion", t_tag_exhaustion}, {"cpl_isolation", t_cpl_isolation}, {"missing_acks", t_missing_acks}, {"ctx_rules", t_ctx_rules}};
  const char* only = argc > 1 && argv[1][0] != '+' ? argv[1] : nullptr;
  for (auto& t : tests) {
    if (only && std::strcmp(only, t.name)) continue;
    int f0 = C.fails;
    for (int mode = 0; mode < 3; mode++) {
      Env e(300 + mode * 13 + std::strlen(t.name));
      if (mode == 1) { e.cfg.cq_gap = 20; e.cfg.cc_stall = 30; e.cfg.rq_stall = 30; e.cfg.rc_gap = 25; e.cfg.split = 2; e.cfg.host_lat_lo = 5; e.cfg.host_lat_hi = 200; e.cfg.dev_lat_hi = 20; }
      if (mode == 2) { e.cfg.split = 3; e.cfg.mrrs_code = 0; e.cfg.mps_code = 0; e.cfg.host_lat_lo = 30; e.cfg.host_lat_hi = 300; e.cfg.np_ok_pct = 70; e.cfg.p_ok_pct = 70; }
      C.tag = std::string(t.name) + (mode == 0 ? "" : mode == 1 ? "/congested" : "/stress");
      if (std::getenv("SFPB_TRACE")) std::printf("[mode] %s\n", C.tag.c_str());
      t.fn(e);
    }
    std::printf("  %-18s %s\n", t.name, C.fails == f0 ? "PASS" : "FAIL");
  }
  std::printf("tb_dma DATA_W=%d: %d checks, %d failures\n", DW, C.checks, C.fails);
  return C.fails ? 1 : 0;
}
