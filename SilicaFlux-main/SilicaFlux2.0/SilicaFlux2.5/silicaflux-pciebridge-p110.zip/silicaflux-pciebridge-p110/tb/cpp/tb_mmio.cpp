// MMIO milestone: register read/write, multi-beat payloads, byte enables, tagging, against the simulated endpoint.
#include "tb_env.h"
using namespace env;

static Checker C;
struct Test { const char* name; std::function<void(Env&)> fn; };

static void finish(Env& e, const char* what) {
  e.idle(300);
  C.ok(e.no_violations(), what, e.n_viol);
  if (!e.no_violations()) e.print_violations();
}

static void t_ident(Env& e) {
  C.ok(e.r32(0, sfpb::R_ID) == 0x53465042u, "ID reads 'SFPB'");
  C.ok(e.r32(0, sfpb::R_VERSION) == 0x01000000u, "VERSION");
  uint32_t caps = e.r32(0, sfpb::R_CAPS0);
  C.ok((caps & 0xFF) == (uint32_t)KK, "CAPS0.K matches the stream width", caps & 0xFF, KK);
  C.ok(((caps >> 8) & 0xFF) == 16, "CAPS0.TAGS");
  C.ok(((caps >> 16) & 0xF) == 4, "CAPS0.NCTX");
  uint32_t caps1 = e.r32(0, sfpb::R_CAPS1);
  C.ok((caps1 & 0xFFFF) == 64 && (caps1 >> 16) == 32, "CAPS1 limits", caps1);
  finish(e, "ident: no protocol violations");
}

static void t_scratch(Env& e) {
  e.w32(0, sfpb::R_SCRATCH, 0x12345678);
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0x12345678u, "scratch write/read");
  e.w32(0, sfpb::R_SCRATCH, 0xAABBCCDD, 0x5);                       // bytes 0 and 2 only
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0x12BB56DDu, "scratch byte enables 0101", 0, 0);
  e.w32(0, sfpb::R_SCRATCH, 0x11223344, 0x8);
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0x11BB56DDu, "scratch byte enable 1000");
  e.w32(0, sfpb::R_SCRATCH, 0xFFFFFFFF, 0x0);                       // zero byte enables: no-op
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0x11BB56DDu, "scratch write with no byte enables is a no-op");
  // a different BAR base address: the bridge uses only the offset below the aperture
  e.mmio_write(0, sfpb::R_SCRATCH, {0xCAFEF00D});
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0xCAFEF00Du, "scratch rewrite");
  finish(e, "scratch: no protocol violations");
}

static void t_fabric_reg(Env& e) {
  const uint32_t base = 0x8000;
  for (int i = 0; i < 16; i++) e.w32(0, base + 4 * i, 0x1000 + i);
  for (int i = 0; i < 16; i++) C.ok(e.r32(0, base + 4 * i) == (uint32_t)(0x1000 + i), "fabric register window readback", i);
  C.ok(e.fablog.size() == 32, "fabric saw exactly 16 writes + 16 reads", e.fablog.size(), 32);
  for (size_t i = 0; i < e.fablog.size() && i < 32; i++) {
    bool wr = i < 16; int k = i % 16;
    C.ok(e.fablog[i].wr == wr && e.fablog[i].addr == FAB_REG_BASE + 4 * k, "fabric transaction order/address", e.fablog[i].addr, FAB_REG_BASE + 4 * k);
  }
  finish(e, "fabric_reg: no protocol violations");
}

static void t_fabric_mem_burst(Env& e) {
  // every length 1..64 dwords, write then read back, through BAR2 at different alignments
  std::vector<uint8_t> shadow(FAB_MEM_SIZE, 0);
  for (uint32_t n = 1; n <= 64; n++) {
    uint32_t off = (e.rng.below(1000) * 4);
    while (((off & 0xFFF) / 4 + n) > 1024) off -= 4;                 // stay inside one 4 KiB page
    std::vector<uint32_t> v(n); for (auto& x : v) x = e.rng.u32();
    e.mmio_write(2, off, v);
    for (uint32_t i = 0; i < n; i++) for (int b = 0; b < 4; b++) shadow[off + 4 * i + b] = v[i] >> (8 * b);
    auto h = e.mmio_read(2, off, n);
    bool ok = !h.bad && h.status == SC && h.data.size() == n;
    C.ok(ok, "burst read completes", n);
    if (ok) { bool eq = true; for (uint32_t i = 0; i < n; i++) eq &= (h.data[i] == v[i]); C.ok(eq, "burst data identical", n); }
    if (h.bad) std::printf("   read problem: %s\n", h.why.c_str());
  }
  C.ok(std::equal(shadow.begin(), shadow.end(), e.fab_mem.begin()), "fabric memory equals the shadow model");
  finish(e, "fabric_mem_burst: no protocol violations");
}

static void t_byte_enables(Env& e) {
  std::vector<uint8_t> shadow(256, 0);
  e.mmio_write(2, 0, std::vector<uint32_t>(32, 0));
  for (int it = 0; it < 300; it++) {
    uint32_t n = 1 + e.rng.below(12); uint32_t off = 4 * e.rng.below(40);
    std::vector<uint32_t> v(n); for (auto& x : v) x = e.rng.u32();
    uint8_t f, l;
    if (n == 1) { f = e.rng.below(16); l = 0; }
    else if (n == 2) { f = 1 + e.rng.below(15); l = 1 + e.rng.below(15); }
    else { static const uint8_t fs[4] = {0xF, 0xE, 0xC, 0x8}, ls[4] = {0xF, 0x7, 0x3, 0x1}; f = fs[e.rng.below(4)]; l = ls[e.rng.below(4)]; }
    e.mmio_write(2, off, v, f, l);
    for (uint32_t i = 0; i < n; i++) {
      uint8_t be = (i == 0) ? f : (i == n - 1 ? l : 0xF);
      for (int b = 0; b < 4; b++) if (be & (1 << b)) shadow[off + 4 * i + b] = v[i] >> (8 * b);
    }
  }
  e.idle(50);
  auto h = e.mmio_read(2, 0, 64);
  bool eq = h.data.size() == 64; for (int i = 0; eq && i < 64; i++) { uint32_t x = shadow[4*i] | (shadow[4*i+1] << 8) | (shadow[4*i+2] << 16) | ((uint32_t)shadow[4*i+3] << 24); eq &= (h.data[i] == x); }
  C.ok(eq, "memory equals shadow after 300 random byte-enable writes");
  // read byte counts / lower addresses for partial reads are checked by the host monitor
  for (int it = 0; it < 200; it++) {
    uint32_t n = 1 + e.rng.below(10); uint32_t off = 4 * e.rng.below(40); uint8_t f, l;
    if (n == 1) { f = e.rng.below(16); l = 0; }
    else if (n == 2) { f = 1 + e.rng.below(15); l = 1 + e.rng.below(15); }
    else { static const uint8_t fs[4] = {0xF, 0xE, 0xC, 0x8}, ls[4] = {0xF, 0x7, 0x3, 0x1}; f = fs[e.rng.below(4)]; l = ls[e.rng.below(4)]; }
    auto r = e.mmio_read(2, off, n, f, l);
    C.ok(!r.bad && r.status == SC, "partial-BE read completes cleanly", n, f);
  }
  finish(e, "byte_enables: no protocol violations");
}

static void t_tags(Env& e) {
  // many reads outstanding at once; every one must come back with its own tag and the right data
  for (int i = 0; i < 64; i++) e.w32(0, 0x8000 + 4 * i, 0xA0000000u + i);
  std::vector<uint16_t> tg; for (int i = 0; i < 64; i++) tg.push_back(e.mmio_read_start(0, 0x8000 + 4 * i));
  std::set<uint16_t> uniq(tg.begin(), tg.end()); C.ok(uniq.size() == tg.size(), "64 distinct tags in flight");
  for (int i = 0; i < 64; i++) { auto h = e.wait_read(tg[i]); C.ok(!h.bad && h.data.size() == 1 && h.data[0] == 0xA0000000u + i, "tagged read returns its own data", i); }
  finish(e, "tags: no protocol violations");
}


// ---------------------------------------------------------------------------------------------------------------------
// error handling
static uint32_t take_err(Env& e) {                      // first logged error code (0xFF if none), then clear log + sticky status
  e.idle(80);
  uint32_t v = e.r32(0, sfpb::R_ERR_LOG0); e.w32(0, sfpb::R_ERR_LOG_CLR, 1); e.w32(0, sfpb::R_ERR_STATUS, 0xFFFF); e.idle(5);
  return (v & 0x100) ? (v & 0x3F) : 0xFF;
}
// issue a read at an arbitrary place; returns the host record (status UR etc.)
static HostRead raw_read(Env& e, uint64_t addr, uint32_t ndw, int bar_id, int bar_ap, uint8_t fbe = 0xF, uint8_t lbe = 0xF, int type = MRD, uint8_t tc = 0, uint8_t at = 0, bool poison = false) {
  uint16_t t = e.alloc_tag(); Req r = Env::mk_req(type, addr, ndw, fbe, ndw == 1 ? 0 : lbe, bar_id, bar_ap, t); r.tc = tc; r.at = at; r.poison = poison;
  e.post_raw(r, nullptr, -1, true); return e.wait_read(t, 20000);
}
static void raw_write(Env& e, uint64_t addr, std::vector<uint32_t> v, int bar_id, int bar_ap, uint8_t fbe = 0xF, uint8_t lbe = 0xF, int type = MWR, uint8_t tc = 0, uint8_t at = 0, bool poison = false) {
  Req r = Env::mk_req(type, addr, (uint32_t)v.size(), fbe, v.size() == 1 ? 0 : lbe, bar_id, bar_ap); r.data = v; r.tc = tc; r.at = at; r.poison = poison; e.post_raw(r);
}

static void t_invalid_bar(Env& e) {
  struct C1 { const char* name; int bar; int ap; uint64_t base; uint32_t off; uint32_t ndw; uint32_t code; };
  const C1 cases[] = {
    {"BAR id 1 is not implemented",              1, 16, 0xD000'0000ull, 0x0000, 1, 0x10},
    {"BAR id 3 is not implemented",              3, 20, 0xD000'0000ull, 0x0000, 1, 0x10},
    {"BAR0 aperture reported as 15 bits",        0, 15, BAR0_BASE,      0x0010, 1, 0x11},
    {"BAR2 aperture reported as 21 bits",        2, 21, BAR2_BASE,      0x0010, 1, 0x11},
    {"BAR0 offset in the unmapped hole",         0, 16, BAR0_BASE,      0x6000, 1, 0x12},
    {"BAR0 context page beyond NCTX",            0, 16, BAR0_BASE,      0x5000, 1, 0x12},
    {"CSR page access of 3 dwords",              0, 16, BAR0_BASE,      0x0010, 3, 0x13},
    {"fabric memory read of 65 dwords",          2, 20, BAR2_BASE,      0x0000, 65, 0x13},
  };
  for (auto& c : cases) {
    take_err(e); size_t f0 = e.fablog.size();
    auto h = raw_read(e, c.base + c.off, c.ndw, c.bar, c.ap);
    C.ok(!h.bad && h.status == UR && h.data.empty(), (std::string("read: UR completion - ") + c.name).c_str(), h.status, UR);
    C.ok(take_err(e) == c.code, (std::string("read: error code - ") + c.name).c_str());
    std::vector<uint32_t> d(c.ndw, 0x5A5A5A5A); raw_write(e, c.base + c.off, d, c.bar, c.ap);
    C.ok(take_err(e) == (c.ndw == 65 ? 0x07u : c.code), (std::string("write: dropped and logged - ") + c.name).c_str());     // a 65-dword WRITE is refused by the adapter first (OVERSIZE)
    C.ok(e.fablog.size() == f0, (std::string("no fabric transaction - ") + c.name).c_str());
  }
  // register-level: write-only / read-only registers
  take_err(e);
  auto h = e.mmio_read(0, sfpb::R_IRQ_SET); C.ok(h.status == UR, "read of a write-only register is UR", h.status);
  C.ok(take_err(e) == 0x15, "a UR caused by a register-level error is logged (CSR_ERR)");
  e.w32(0, sfpb::R_ID, 0x1234);                                       // write to a read-only register
  C.ok(take_err(e) == 0x15, "write to a read-only register is dropped and logged (CSR_ERR)");
  C.ok(e.r32(0, sfpb::R_ID) == 0x53465042u, "read-only register unchanged");
  h = e.mmio_read(0, 0x0F00); C.ok(h.status == UR, "read of an undefined register is UR", h.status); take_err(e);
  // fabric windows disabled by control
  e.mmio_write(2, 0, {0x11111111});
  e.w32(0, sfpb::R_CTRL, 0x22);                                       // FWIN_RD_EN = 0
  h = e.mmio_read(2, 0); C.ok(h.status == UR, "fabric reads refused while FWIN_RD_EN = 0", h.status);
  C.ok(take_err(e) == 0x14, "BAR_PERM logged");
  e.w32(0, sfpb::R_CTRL, 0x21);                                       // FWIN_WR_EN = 0, reads back on
  size_t f1 = e.fablog.size(); e.mmio_write(2, 0, {0x22222222}); C.ok(take_err(e) == 0x14 && e.fablog.size() == f1, "fabric writes refused while FWIN_WR_EN = 0 (no side effect)");
  e.w32(0, sfpb::R_CTRL, 0x23);
  C.ok(e.r32(2, 0) == 0x11111111u, "memory still holds the pre-refusal value");
  finish(e, "invalid_bar: no protocol violations");
}

static void t_malformed(Env& e) {
  const uint64_t B2 = BAR2_BASE; const int AP = 20;
  auto settle = [&]() { e.idle(150); };
  auto check_follow_up = [&](const char* what) {                      // the stream must still be in sync: a good write + read works
    uint32_t v = e.rng.u32(); e.mmio_write(2, 0x40, {v}); auto h = e.mmio_read(2, 0x40);
    C.ok(!h.bad && h.data.size() == 1 && h.data[0] == v, what);
  };
  struct M { const char* name; std::function<void()> inj; uint32_t code; bool nonposted; };
  uint32_t pay2[2] = {1, 2};
  auto wr = [&](uint32_t ndw, uint8_t f, uint8_t l, std::vector<uint32_t> pay, int disc = -1, uint32_t addr_off = 0x100, int type = MWR) {
    Req r = Env::mk_req(type, B2 + addr_off, ndw, f, l, 2, AP); r.data = std::vector<uint32_t>(ndw, 0xBADC0DE0); e.post_raw(r, &pay, disc);
  };
  auto rd = [&](uint32_t ndw, uint8_t f, uint8_t l, std::vector<uint32_t> pay, uint32_t addr_off = 0x100) {
    uint16_t t = e.alloc_tag(); Req r = Env::mk_req(MRD, B2 + addr_off, ndw, f, l, 2, AP, t); r.data = pay; e.post_raw(r, &pay, -1, true); return t;
  };
  (void)pay2;
  std::vector<M> ms;
  ms.push_back({"write: stream shorter than the descriptor", [&]{ wr(8, 0xF, 0xF, std::vector<uint32_t>(5, 7)); }, 0x01, false});
  ms.push_back({"write: stream longer than the descriptor", [&]{ wr(4, 0xF, 0xF, std::vector<uint32_t>(9, 7)); }, 0x01, false});
  ms.push_back({"write: dword count 0", [&]{ wr(0, 0xF, 0xF, {}); }, 0x03, false});
  ms.push_back({"write: 1 dword with last-BE set", [&]{ wr(1, 0xF, 0x3, {9}); }, 0x04, false});
  ms.push_back({"write: 2 dwords with first-BE 0", [&]{ wr(2, 0x0, 0xF, {1, 2}); }, 0x04, false});
  ms.push_back({"write: 3 dwords with sparse first-BE", [&]{ wr(3, 0x5, 0xF, {1, 2, 3}); }, 0x04, false});
  ms.push_back({"write: crosses a 4 KiB boundary", [&]{ wr(4, 0xF, 0xF, {1, 2, 3, 4}, -1, 0xFF8); }, 0x05, false});
  ms.push_back({"write: larger than the store-and-forward buffer", [&]{ wr(100, 0xF, 0xF, std::vector<uint32_t>(100, 5)); }, 0x07, false});
  ms.push_back({"write: endpoint flagged the TLP as discontinued", [&]{ wr(4, 0xF, 0xF, {1, 2, 3, 4}, 0); }, 0x02, false});
  ms.push_back({"read: carries a payload", [&]{ (void)rd(4, 0xF, 0xF, {1, 2, 3, 4}); }, 0x06, true});
  ms.push_back({"read: dword count 0", [&]{ (void)rd(0, 0xF, 0xF, {}); }, 0x03, true});
  ms.push_back({"read: 4 KiB crossing", [&]{ (void)rd(4, 0xF, 0xF, {}, 0xFF8); }, 0x05, true});
  for (auto& m : ms) {
    take_err(e); size_t f0 = e.fablog.size(); size_t cc0 = e.n_cc_tlps; uint32_t st0 = e.r32(0, sfpb::R_STATUS); (void)st0;
    size_t cc1 = e.n_cc_tlps; (void)cc0;
    m.inj(); settle();
    C.ok(take_err(e) == m.code, (std::string("logged: ") + m.name).c_str());
    C.ok(e.fablog.size() == f0, (std::string("nothing executed: ") + m.name).c_str());
    size_t unanswered = 0; for (auto& kv : e.reads) if (!e.finished.count(kv.first) && kv.second.cq_cyc != 0) unanswered++;
    (void)unanswered; (void)cc1;
    e.reads.clear(); e.finished.clear();                              // malformed non-posted requests are never completed (the host would time out)
    check_follow_up((std::string("stream still in sync after: ") + m.name).c_str());
  }
  // unsupported-but-wellformed requests
  take_err(e);
  for (int ty : {IORD, MRDLK}) {
    auto h = raw_read(e, B2 + 0x100, 1, 2, AP, 0xF, 0xF, ty);
    C.ok(!h.bad && h.status == UR, "unsupported non-posted type gets a UR completion", ty);
    C.ok(take_err(e) == 0x08, "logged as UNSUP_TYPE", ty);
  }
  for (int ty : {FADD, SWAP, CAS}) {                                  // atomics carry operands: the payload is consumed, the request answered UR
    Req r = Env::mk_req(ty, B2 + 0x100, ty == CAS ? 2 : 1, 0xF, ty == CAS ? 0xF : 0, 2, AP); r.data = std::vector<uint32_t>(r.ndw, 3);
    uint16_t tg = e.alloc_tag(); r.tag = tg; e.post_raw(r, nullptr, -1, true); auto h = e.wait_read(tg, 20000);
    C.ok(!h.bad && h.status == UR, "atomic request gets UR (payload consumed)", ty); C.ok(take_err(e) == 0x08, "atomic logged as UNSUP_TYPE", ty);
  }
  { Req r = Env::mk_req(IOWR, B2 + 0x100, 1, 0xF, 0, 2, AP); r.data = {1}; uint16_t t = e.alloc_tag(); r.tag = t; e.post_raw(r, nullptr, -1, true); auto h = e.wait_read(t, 20000);
    C.ok(!h.bad && h.status == UR, "I/O write (non-posted, with payload) gets UR and its payload is consumed"); take_err(e); }
  { Req r = Env::mk_req(MSG, B2, 1, 0, 0, 2, AP); r.data = {}; size_t f0 = e.fablog.size(); e.post_raw(r); settle();
    C.ok(take_err(e) == 0x08 && e.fablog.size() == f0, "posted message is dropped and logged"); }
  check_follow_up("in sync after unsupported types");
  // poison, address type, traffic class
  auto h = raw_read(e, B2 + 0x40, 1, 2, AP, 0xF, 0, MRD, 0, 0, true); C.ok(h.status == UR, "poisoned read -> UR", h.status); C.ok(take_err(e) == 0x09, "poisoned read logged");
  size_t f0 = e.fablog.size(); raw_write(e, B2 + 0x40, {0xDEAD}, 2, AP, 0xF, 0, MWR, 0, 0, true); settle(); C.ok(take_err(e) == 0x09 && e.fablog.size() == f0, "poisoned write dropped, no side effect");
  h = raw_read(e, B2 + 0x40, 1, 2, AP, 0xF, 0, MRD, 0, 1); C.ok(h.status == UR, "AT != 0 -> UR", h.status); C.ok(take_err(e) == 0x0A, "AT logged");
  h = raw_read(e, B2 + 0x40, 1, 2, AP, 0xF, 0, MRD, 3, 0); C.ok(h.status == UR, "TC != 0 -> UR", h.status); C.ok(take_err(e) == 0x0B, "TC logged");
  e.w32(0, sfpb::R_CTRL, 0x33);                                        // TC_ANY
  h = raw_read(e, B2 + 0x40, 1, 2, AP, 0xF, 0, MRD, 3, 0); C.ok(h.status == SC, "TC accepted when TC_ANY is set", h.status);
  e.w32(0, sfpb::R_CTRL, 0x23);
  // everything above counted
  C.ok(e.r32(0, sfpb::R_ERR_STATUS) == 0, "error status was cleared by the helper");
  finish(e, "malformed: no protocol violations");
}

static void t_queue_saturation(Env& e) {
  e.cfg.fab_ready_pct = 25; e.cfg.fab_lat_lo = 4; e.cfg.fab_lat_hi = 12; e.cfg.cc_stall = 50;
  std::vector<uint8_t> shadow(1024, 0); std::vector<std::pair<uint32_t, uint32_t>> exp_wr; std::vector<std::pair<uint16_t, std::vector<uint32_t>>> exp_rd;
  const int N = 600;
  for (int i = 0; i < N; i++) {
    uint32_t n = 1 + e.rng.below(8); uint32_t off = 4 * e.rng.below(100); std::vector<uint32_t> v(n); for (auto& x : v) x = e.rng.u32();
    e.mmio_write(2, off, v);
    for (uint32_t k = 0; k < n; k++) { for (int b = 0; b < 4; b++) shadow[off + 4 * k + b] = v[k] >> (8 * b); exp_wr.push_back({off + 4 * k, v[k]}); }
    if (i % 5 == 4) {                                                  // read straight after, never waiting: must see ALL earlier writes
      uint32_t rn = 1 + e.rng.below(6), roff = 4 * e.rng.below(100); uint16_t t = e.mmio_read_start(2, roff, rn);
      std::vector<uint32_t> x(rn); for (uint32_t k = 0; k < rn; k++) x[k] = shadow[roff + 4 * k] | (shadow[roff + 4 * k + 1] << 8) | (shadow[roff + 4 * k + 2] << 16) | ((uint32_t)shadow[roff + 4 * k + 3] << 24);
      exp_rd.push_back({t, x});
    }
  }
  bool bp_seen = e.run_until([&]() { return e.cq_q.size() > 100; }, 2000);
  (void)bp_seen;
  int bad = 0; for (auto& r : exp_rd) { auto h = e.wait_read(r.first, 3000000); if (h.bad || h.data != r.second) bad++; }
  C.ok(bad == 0, "every read returned the data implied by ALL earlier writes (posted writes are not reordered)", bad, (int)exp_rd.size());
  // independent scoreboard of the fabric transaction stream: writes in submission order, every dword, nothing lost or duplicated
  size_t wi = 0; bool order_ok = true; size_t nwr = 0;
  for (auto& t : e.fablog) if (t.wr) { nwr++; if (wi < exp_wr.size() && (t.addr != FAB_MEM_BASE + exp_wr[wi].first || t.data != exp_wr[wi].second || t.strb != 0xF)) order_ok = false; wi++; }
  C.ok(nwr == exp_wr.size(), "the fabric saw exactly the submitted write dwords", nwr, exp_wr.size());
  C.ok(order_ok, "in submission order, with the right data");
  e.idle(300);
  e.w32(0, sfpb::R_PERF_SEL, sfpb::PC_BP_CQ); uint32_t bp = e.r32(0, sfpb::R_PERF_LO); C.ok(bp > 100, "the CQ interface was back-pressured (saturation really happened)", bp);
  e.w32(0, sfpb::R_PERF_SEL, sfpb::PC_HDRQ_MAX); uint32_t hq = e.r32(0, sfpb::R_PERF_LO); C.ok(hq >= 3, "request-header queue reached (near) capacity", hq);
  C.ok(e.r32(0, sfpb::R_ERR_STATUS) == 0, "no error was raised by saturation");
  finish(e, "queue_saturation: no protocol violations");
}

static void t_fabric_errors(Env& e) {
  // SFB2 error on read -> completer abort; on write -> logged, no completion
  e.mmio_write(2, 0x100, {0x01020304}); e.fab_err_lo = FAB_MEM_BASE + 0x200; e.fab_err_hi = FAB_MEM_BASE + 0x2FF;
  take_err(e);
  auto h = e.mmio_read(2, 0x200); C.ok(h.status == CA && h.data.empty(), "fabric error on a read -> completion with CA, no data", h.status, CA);
  C.ok(take_err(e) == 0x18, "fabric error logged");
  e.mmio_write(2, 0x204, {0x55}); C.ok(take_err(e) == 0x18, "fabric error on a posted write is logged (no completion exists)");
  h = e.mmio_read(2, 0x100, 4); C.ok(!h.bad && h.status == SC, "a multi-dword read that includes a failing dword -> CA"  , h.status, SC);
  h = e.mmio_read(2, 0x1F8, 4); C.ok(h.status == CA, "read spanning into the failing region -> CA", h.status, CA); take_err(e);
  e.fab_err_lo = 1; e.fab_err_hi = 0;
  C.ok(e.r32(2, 0x100) == 0x01020304u, "good traffic unaffected afterwards");
  // fabric hang: bounded wait, then the port goes FATAL; CSR keeps working; recovery needs the fabric to come back
  e.w32(0, sfpb::R_SFB_TIMEOUT, 150); e.idle(20);
  e.fab_hang = true;
  h = e.mmio_read(2, 0x100); C.ok(h.status == CA, "a read to a hung fabric is aborted (CA) after the timeout, not hung", h.status, CA);
  { uint32_t tc = take_err(e); if (tc != 0x19) std::printf("   [dbg] timeout log code=0x%02X\n", tc); C.ok(tc == 0x19, "FAB_TIMEOUT logged"); }   // after take_err the sticky class is cleared; the state bit remains
  uint32_t st = e.r32(0, sfpb::R_STATUS); C.ok(st & 4, "STATUS.FABRIC_FATAL is set", st);
  h = e.mmio_read(2, 0x100); C.ok(h.status == CA, "further fabric reads are refused immediately while fatal", h.status, CA); C.ok(take_err(e) == 0x1A, "FAB_FATAL logged");
  e.mmio_write(2, 0x100, {0xFFFFFFFF}); C.ok(take_err(e) == 0x1A, "fabric writes are dropped and logged while fatal");
  { uint32_t idv = e.r32(0, sfpb::R_ID); if (idv != 0x53465042u) std::printf("   [dbg] ID read returned 0x%08X\n", idv); C.ok(idv == 0x53465042u, "registers (the way back) stay accessible while the fabric port is fatal"); }
  e.w32(0, sfpb::R_CTRL, 0x223);                                      // CLR_FATAL while the fabric still owes a response: refused
  st = e.r32(0, sfpb::R_STATUS); C.ok(st & 4, "CLR_FATAL is refused while a response is still owed", st);
  e.fab_hang = false; e.idle(100);
  e.w32(0, sfpb::R_CTRL, 0x223); e.idle(20);
  st = e.r32(0, sfpb::R_STATUS); C.ok(!(st & 4), "CLR_FATAL succeeds once the fabric has answered", st);
  e.fab_resp.clear();
  C.ok(e.r32(2, 0x100) == 0x01020304u, "fabric access works again");
  take_err(e);
  finish(e, "fabric_errors: no protocol violations");
}


static void t_window_edges(Env& e) {
  // first / last dword of every window and bursts that end exactly on a window end are legal; one step outside is not
  e.mmio_write(2, 0xFFFFC, {0xA5A5A5A5});                                            // last dword of BAR2
  C.ok(e.r32(2, 0xFFFFC) == 0xA5A5A5A5u, "last dword of BAR2 is accessible");
  std::vector<uint32_t> v(64); for (auto& x : v) x = e.rng.u32();
  e.mmio_write(2, 0xFFF00, v);                                                       // 64 dwords ending exactly on the BAR end
  auto h = e.mmio_read(2, 0xFFF00, 64); C.ok(!h.bad && h.data == v, "64-dword burst ending exactly at the BAR end", h.data.size());
  e.w32(0, 0xFFFC, 0xC3C3C3C3u);                                                     // last dword of the register window
  C.ok(e.r32(0, 0xFFFC) == 0xC3C3C3C3u, "last dword of the DataFabric register window");
  e.mmio_write(0, 0xFFF8, {0x11, 0x22}); auto h2 = e.mmio_read(0, 0xFFF8, 2); C.ok(!h2.bad && h2.data.size() == 2 && h2.data[0] == 0x11 && h2.data[1] == 0x22, "2-dword access ending exactly at the window end");
  e.w32(0, 0x8000, 0x0F0F0F0F); C.ok(e.r32(0, 0x8000) == 0x0F0F0F0Fu, "first dword of the register window");
  take_err(e);
  auto g = e.mmio_read(0, 0x7FFC); C.ok(g.status == UR, "last dword BEFORE the register window is unmapped (UR)", g.status); C.ok(take_err(e) == 0x12, "logged as BAR_RANGE");
  g = e.mmio_read(0, 0x5000); C.ok(g.status == UR, "first dword after the last context page is unmapped", g.status); C.ok(take_err(e) == 0x12, "logged as BAR_RANGE");
  g = e.mmio_read(0, 0x4FFC); C.ok(g.status == UR, "an undefined register at the end of the last context page is UR", g.status); take_err(e);
  g = e.mmio_read(0, 0x1000 + sfpb::C_CTX_INFO); C.ok(g.status == SC, "context page 1 is mapped and readable", g.status);
  g = e.mmio_read(0, 0x4000 + sfpb::C_CTX_INFO); C.ok(g.status == SC, "context page 4 (the last) is mapped", g.status);
  take_err(e);
  finish(e, "window_edges: no protocol violations");
}

static void t_zero_len(Env& e) {
  // A 1-dword read with first-BE = 0 is PCIe's "zero-length read" (used as a flush): nothing is read and one dword of ZEROS comes back.
  e.w32(0, sfpb::R_SCRATCH, 0xDEADBEEF); e.idle(20);
  C.ok(e.r32(0, sfpb::R_SCRATCH) == 0xDEADBEEFu, "scratch holds the pattern (and the engine's read buffer now holds it too)");
  auto z = e.mmio_read(0, sfpb::R_SCRATCH, 1, 0x0, 0);
  C.ok(!z.bad && z.status == SC && z.data.size() == 1 && z.data[0] == 0, "zero-length read of a register returns one dword of zeros (no stale data)", z.data.empty() ? -1 : (long long)z.data[0]);
  e.w32(2, 0x40, 0xCAFEF00D); e.idle(30); C.ok(e.r32(2, 0x40) == 0xCAFEF00Du, "fabric memory holds the pattern");
  size_t f0 = e.fablog.size();
  auto z2 = e.mmio_read(2, 0x40, 1, 0x0, 0);
  C.ok(!z2.bad && z2.status == SC && z2.data.size() == 1 && z2.data[0] == 0, "zero-length read of fabric memory returns zeros", z2.data.empty() ? -1 : (long long)z2.data[0]);
  C.ok(e.fablog.size() == f0, "... and issues no SFB2 access", (long long)(e.fablog.size() - f0));
  finish(e, "zero_len: no protocol violations");
}

static void t_errlog(Env& e) {
  // single-entry error log: it keeps the FIRST error since the last clear and counts the ones it could not record (saturating)
  auto bad = [&]() { Req r = Env::mk_req(MWR, BAR2_BASE + 0x100, 1, 0xF, 0x3, 2, 20); std::vector<uint32_t> pay = {9}; r.data = pay; e.post_raw(r, &pay); };   // MAL_BE
  auto drain = [&]() { e.run_until([&]() { return e.quiet(); }, 400000); e.idle(150); };
  take_err(e);
  bad(); drain();
  uint32_t l0 = e.r32(0, sfpb::R_ERR_LOG0);
  C.ok((l0 & 0x100) && (l0 & 0x3F) == 0x04 && ((l0 >> 16) & 0xFF) == 0, "the first error is recorded; nothing lost yet", l0);
  for (int i = 0; i < 4; i++) bad(); drain();
  l0 = e.r32(0, sfpb::R_ERR_LOG0);
  C.ok(((l0 >> 16) & 0xFF) == 4, "four further errors are counted as not recorded", (l0 >> 16) & 0xFF);
  C.ok((l0 & 0x3F) == 0x04 && (l0 & 0x100), "the log still holds the first error");
  for (int i = 0; i < 300; i++) bad(); drain();
  l0 = e.r32(0, sfpb::R_ERR_LOG0);
  C.ok(((l0 >> 16) & 0xFF) == 0xFF, "the count saturates at 255 (does not wrap)", (l0 >> 16) & 0xFF);
  e.w32(0, sfpb::R_ERR_LOG_CLR, 1); e.idle(30); l0 = e.r32(0, sfpb::R_ERR_LOG0);
  C.ok((l0 & 0x100) == 0 && ((l0 >> 16) & 0xFF) == 0, "ERR_LOG_CLR clears the valid bit and the count", l0);
  take_err(e); finish(e, "errlog: no protocol violations");
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  std::vector<Test> tests = {{"ident", t_ident}, {"scratch", t_scratch}, {"fabric_reg", t_fabric_reg}, {"fabric_mem_burst", t_fabric_mem_burst},
                             {"byte_enables", t_byte_enables}, {"tags", t_tags}, {"invalid_bar", t_invalid_bar}, {"malformed", t_malformed},
                             {"queue_saturation", t_queue_saturation}, {"fabric_errors", t_fabric_errors}, {"window_edges", t_window_edges},
                             {"zero_len", t_zero_len}, {"errlog", t_errlog}};
  const char* only = argc > 1 ? argv[1] : nullptr;
  for (auto& t : tests) {
    if (only && std::strcmp(only, t.name)) continue;
    int f0 = C.fails; C.tag = t.name;
    for (int mode = 0; mode < 3; mode++) {                           // clean, back-pressured, slow-fabric
      Env e(100 + mode * 7 + std::strlen(t.name));
      if (mode == 1) { e.cfg.cq_gap = 30; e.cfg.cc_stall = 40; e.cfg.fab_ready_pct = 60; }
      if (mode == 2) { e.cfg.fab_lat_lo = 2; e.cfg.fab_lat_hi = 12; e.cfg.cc_stall = 20; e.cfg.cq_gap = 10; }
      C.tag = std::string(t.name) + (mode == 0 ? "" : mode == 1 ? "/bp" : "/slow");
      if (!only || !std::strcmp(only, t.name)) t.fn(e);
    }
    std::printf("  %-18s %s\n", t.name, C.fails == f0 ? "PASS" : "FAIL");
  }
  std::printf("tb_mmio DATA_W=%d: %d checks, %d failures\n", DW, C.checks, C.fails);
  return C.fails ? 1 : 0;
}
