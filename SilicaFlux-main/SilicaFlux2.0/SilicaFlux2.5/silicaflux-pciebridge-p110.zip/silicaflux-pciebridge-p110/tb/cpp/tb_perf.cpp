// Performance measurement (simulation, RTL cycles; no timing/frequency claim).  Writes reports/performance_w<W>.md.
#include "tb_dma_lib.h"
#include <cstdarg>
using namespace env;
static FILE* out;
static void P(const char* fmt, ...) { va_list a; va_start(a, fmt); vprintf(fmt, a); va_end(a); va_start(a, fmt); if (out) vfprintf(out, fmt, a); va_end(a); }

static uint64_t pc(Env& e, uint32_t idx) { e.w32(0, sfpb::R_PERF_SEL, idx); uint32_t lo = e.r32(0, sfpb::R_PERF_LO), hi = e.r32(0, sfpb::R_PERF_HI); return ((uint64_t)hi << 32) | lo; }
static void pclear(Env& e) { e.w32(0, sfpb::R_CTRL, 0x427); e.idle(10); e.w32(0, sfpb::R_CTRL, 0x27); e.idle(10); }

struct Snap { uint64_t v[sfpb::PC_N]; };
static Snap snap(Env& e) { Snap s; for (uint32_t i = 0; i < sfpb::PC_N; i++) s.v[i] = pc(e, i); return s; }

static void mmio_latency(Env& e) {
  P("\n### MMIO latency (cycles at the endpoint boundary: request SOP accepted on CQ -> completion SOP accepted on CC)\n\n");
  P("| access | fabric latency | n | min | avg | max | DUT counter avg (engine accept -> first CC beat) |\n|---|---|---|---|---|---|---|\n");
  for (int fl : {1, 4, 8}) for (int kind = 0; kind < 3; kind++) {
    Env x(500 + fl * 10 + kind); x.cfg.fab_lat_lo = x.cfg.fab_lat_hi = fl; x.cfg.link_cc = 1;
    pclear(x);
    std::vector<uint64_t> lats; int n = 40;
    for (int i = 0; i < n; i++) {
      uint16_t t = kind == 0 ? x.mmio_read_start(0, sfpb::R_SCRATCH) : kind == 1 ? x.mmio_read_start(2, 4 * (i % 50), 1) : x.mmio_read_start(2, 4 * (i % 20), 16);
      auto h = x.wait_read(t); x.idle(30);
      lats.push_back(h.first_cyc - x.cfg.link_cc - h.cq_cyc);
    }
    uint64_t mn = *std::min_element(lats.begin(), lats.end()), mx = *std::max_element(lats.begin(), lats.end()), sm = 0; for (auto l : lats) sm += l;
    uint64_t dsum = pc(x, sfpb::PC_MMIO_RD_LAT_SUM), dcnt = pc(x, sfpb::PC_MMIO_RD_LAT_CNT);
    P("| %s | %d | %d | %llu | %.1f | %llu | %.1f |\n", kind == 0 ? "CSR read, 1 DW" : kind == 1 ? "fabric read, 1 DW" : "fabric read, 16 DW", fl, n, (unsigned long long)mn, (double)sm / n, (unsigned long long)mx, dcnt ? (double)dsum / dcnt : 0.0);
    if (kind == 0 && fl != 1) { /* CSR latency does not depend on the fabric */ }
  }
  (void)e;
}

static void mmio_write_rate(Env&) {
  P("\n### MMIO posted-write rate into the DataFabric (fabric always ready, 1-cycle response)\n\n| TLP | dwords/TLP | TLPs | cycles | dwords per cycle |\n|---|---|---|---|---|\n");
  for (int ndw : {1, 4, 16, 64}) {
    Env x(900 + ndw); x.cfg.fab_lat_lo = x.cfg.fab_lat_hi = 1; int n = 64 * 4 / ndw + 8;
    std::vector<uint32_t> v(ndw, 0x55);
    for (int i = 0; i < n; i++) x.mmio_write(2, 0, v);
    uint64_t c0 = 0; bool started = false;
    x.run_until([&]() { if (!started && !x.fablog.empty()) { started = true; c0 = x.fablog.front().cyc; } return x.fablog.size() >= (size_t)n * ndw; }, 200000);
    uint64_t c1 = x.fablog.empty() ? 0 : x.fablog.back().cyc; double cyc = (double)(c1 - c0 + 1);
    P("| MWr to BAR2 | %d | %d | %.0f | %.3f |\n", ndw, n, cyc, (double)(n * ndw) / cyc);
  }
}

static void dma_throughput(Env&) {
  P("\n### DMA throughput (bytes/cycle = length / StreamDMA transaction latency; 16 B/cycle is the 128-bit datapath ceiling)\n\n");
  P("| direction | length | MRRS/MPS | root latency | strict ack | cycles | bytes/cycle | tags in flight (max / avg) | avg completion latency | TLPs (rd+wr) | header B per payload B |\n|---|---|---|---|---|---|---|---|---|---|---|\n");
  struct Cfg { int len, mrrs, lat; bool strict; };
  for (int dir = 0; dir < 2; dir++) {
    std::vector<Cfg> cs = {{1024, 2, 20, false}, {4096, 2, 20, false}, {16384, 2, 20, false}, {65536, 2, 20, false}, {65536, 1, 20, false}, {65536, 0, 20, false},
                           {65536, 2, 100, false}, {65536, 2, 300, false}, {16384, 2, 20, true}};
    for (auto& c : cs) {
      if (dir == 0 && c.strict) continue;
      Env x(1300 + c.len + c.mrrs * 7 + c.lat + dir);
      x.cfg.mrrs_code = c.mrrs; x.cfg.mps_code = std::min(c.mrrs, 1); x.cfg.host_lat_lo = c.lat; x.cfg.host_lat_hi = c.lat + c.lat / 5; x.cfg.split = 1; x.cfg.dev_lat_lo = 2; x.cfg.dev_lat_hi = 3;
      Dma dma(x); dma.setup_defaults(); if (c.strict) x.w32(0, sfpb::R_CTRL, 0x2F);
      x.w32(0, sfpb::R_CPL_TIMEOUT, 2000);
      uint64_t host = HOST0_IOVA, dev = DEV_BASE; if (dir == 0) dma.fill_host(0, host, c.len); else dma.fill_dev(dev, c.len);
      pclear(x); Snap s0 = snap(x);
      uint64_t t0 = x.cyc; auto s = dir == 0 ? dma.h2d(0, 1, host, dev, c.len) : dma.d2h(0, 1, dev, host, c.len);
      CplRec r; dma.wait_record(0, r, 4000000); uint64_t wall = x.cyc - t0;
      Snap s1 = snap(x);
      bool ok = r.status == 0 && r.done == (uint32_t)c.len && s.status() == 1;
      double thr = r.lat ? (double)c.len / r.lat : 0;
      uint64_t tlps = s1.v[sfpb::PC_RQ_MRD] + s1.v[sfpb::PC_RQ_MWR]; double ovh = (double)(s1.v[sfpb::PC_HDR_BYTES]) / std::max<uint64_t>(1, s1.v[sfpb::PC_PAY_BYTES]);
      double avg_out = (double)(s1.v[sfpb::PC_OUT_SUM]) / std::max<uint64_t>(1, s1.v[sfpb::PC_CYCLES]);
      double cl = s1.v[sfpb::PC_CPL_LAT_CNT] ? (double)s1.v[sfpb::PC_CPL_LAT_SUM] / s1.v[sfpb::PC_CPL_LAT_CNT] : 0;
      P("| %s | %d B | %d/%d B | %d | %s | %u | %.2f%s | %llu / %.2f | %.0f | %llu | %.3f |\n", dir == 0 ? "host -> device" : "device -> host", c.len, 128 << c.mrrs, 128 << std::min(c.mrrs, 1), c.lat, c.strict ? "yes" : "no", r.lat, thr, ok ? "" : " (FAILED)",
        (unsigned long long)s1.v[sfpb::PC_OUT_MAX], avg_out, cl, (unsigned long long)tlps, ovh);
      (void)s0; (void)wall;
    }
  }
}

static void queues_and_bp(Env&) {
  P("\n### Queue occupancy, back-pressure and overhead under a CQ flood with a slow fabric and a stalled completion path\n\n");
  Env x(77); x.cfg.fab_ready_pct = 30; x.cfg.fab_lat_lo = 3; x.cfg.fab_lat_hi = 8; x.cfg.cc_stall = 70; x.cfg.rq_stall = 50;
  pclear(x);
  for (int i = 0; i < 300; i++) { x.mmio_write(2, 4 * (i % 100), std::vector<uint32_t>(1 + i % 8, i)); if (i % 6 == 5) x.mmio_read_start(2, 4 * (i % 100), 4); }
  x.run_until([&]() { return x.cq_q.empty() && x.reads.empty(); }, 3000000); x.idle(500);
  Snap s = snap(x);
  P("| counter | value |\n|---|---|\n");
  struct N { const char* n; uint32_t i; };
  const N names[] = {{"CYCLES", sfpb::PC_CYCLES}, {"CQ_TLPS", sfpb::PC_CQ_TLPS}, {"CQ_MRD (executed)", sfpb::PC_CQ_MRD}, {"CQ_MWR (executed)", sfpb::PC_CQ_MWR}, {"CC_TLPS", sfpb::PC_CC_TLPS},
                     {"HDRQ_MAX (request-header queue, entries)", sfpb::PC_HDRQ_MAX}, {"PAYQ_MAX (payload RAM, beats)", sfpb::PC_PAYQ_MAX}, {"BP_CQ (cycles)", sfpb::PC_BP_CQ},
                     {"BP_CC (cycles)", sfpb::PC_BP_CC}, {"BP_SFB (cycles)", sfpb::PC_BP_SFB}, {"HDR_BYTES", sfpb::PC_HDR_BYTES}, {"PAY_BYTES", sfpb::PC_PAY_BYTES}, {"ERR_EVENTS", sfpb::PC_ERR_EVENTS}};
  for (auto& n : names) P("| %s | %llu |\n", n.n, (unsigned long long)s.v[n.i]);
  P("\nHeader overhead in this workload: %.2f header bytes per payload byte.\n", (double)s.v[sfpb::PC_HDR_BYTES] / std::max<uint64_t>(1, s.v[sfpb::PC_PAY_BYTES]));
  (void)s;
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  char fn[128]; std::snprintf(fn, sizeof fn, "perf_w%d.md", DW); out = std::fopen(argc > 1 ? argv[1] : fn, "w");
  P("## DATA_W = %d bit endpoint stream (%d dwords/beat), DMA datapath 128 bit\n", DW, KK);
  Env dummy(1);
  mmio_latency(dummy); mmio_write_rate(dummy); dma_throughput(dummy); queues_and_bp(dummy);
  if (out) std::fclose(out);
  return 0;
}
