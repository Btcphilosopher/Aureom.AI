// Adapter-level tests with an ADVERSARIAL AXI master wired straight into the bridge's host-memory port (StreamDMA bypassed).
// Everything the egress protection must refuse -- and every legal shape of read / write burst it must carry exactly.
#include "tb_dma_lib.h"
using namespace env;
static Checker C;
struct Test { const char* name; std::function<void(Env&)> fn; };
static void finish(Env& e, const char* what) { e.idle(400); C.ok(e.no_violations(), what, e.n_viol); if (!e.no_violations()) e.print_violations(); }

struct XM {                                        // the adversarial master
  Env& e;
  struct AR { uint32_t id; uint64_t addr; uint32_t len, size, burst, mtype, dom; };
  struct AW { uint32_t id; uint64_t addr; uint32_t len, size, burst, mtype, dom; };
  struct Wb { uint8_t data[16]; uint32_t strb; bool last; };
  std::deque<AR> ar; std::deque<AW> aw; std::deque<Wb> wq; bool ar_o = false, aw_o = false, w_o = false;
  struct Rb { uint32_t id; uint8_t data[16]; uint32_t resp; bool last; }; std::vector<Rb> rb; struct Bb { uint32_t id, resp; }; std::vector<Bb> bb;
  int r_stall = 0, b_stall = 0, v_gap = 0;
  explicit XM(Env& env) : e(env) {
    e.d->x_sel = 1;
    e.hook_drive = [this]() { drive(); }; e.hook_sample = [this]() { sample(); };
  }
  ~XM() { e.hook_drive = nullptr; e.hook_sample = nullptr; e.d->x_sel = 0; e.d->x_ar_valid = 0; e.d->x_aw_valid = 0; e.d->x_w_valid = 0; }
  void drive() {
    if (!ar_o && !ar.empty() && !e.rng.chance(v_gap)) ar_o = true;
    if (!aw_o && !aw.empty() && !e.rng.chance(v_gap)) aw_o = true;
    if (!w_o && !wq.empty() && !e.rng.chance(v_gap)) w_o = true;
    auto* d = e.d;
    d->x_ar_valid = ar_o; if (ar_o) { auto& a = ar.front(); d->x_ar_id = a.id; d->x_ar_addr = a.addr; d->x_ar_len = a.len; d->x_ar_size = a.size; d->x_ar_burst = a.burst; d->x_ar_mtype = a.mtype; d->x_ar_domain = a.dom; }
    d->x_aw_valid = aw_o; if (aw_o) { auto& a = aw.front(); d->x_aw_id = a.id; d->x_aw_addr = a.addr; d->x_aw_len = a.len; d->x_aw_size = a.size; d->x_aw_burst = a.burst; d->x_aw_mtype = a.mtype; d->x_aw_domain = a.dom; }
    d->x_w_valid = w_o; if (w_o) { auto& w = wq.front(); uint32_t* p = W(d->x_w_data); for (int i = 0; i < 4; i++) p[i] = w.data[4*i] | (w.data[4*i+1] << 8) | (w.data[4*i+2] << 16) | ((uint32_t)w.data[4*i+3] << 24); d->x_w_strb = w.strb; d->x_w_last = w.last; }
    d->x_r_ready = !e.rng.chance(r_stall); d->x_b_ready = !e.rng.chance(b_stall);
  }
  void sample() {
    auto* d = e.d;
    if (ar_o && d->x_ar_ready) { ar.pop_front(); ar_o = false; }
    if (aw_o && d->x_aw_ready) { aw.pop_front(); aw_o = false; }
    if (w_o && d->x_w_ready) { wq.pop_front(); w_o = false; }
    if (d->x_r_valid && d->x_r_ready) { Rb r; r.id = d->x_r_id; const uint32_t* p = WC(d->x_r_data); for (int i = 0; i < 16; i++) r.data[i] = p[i / 4] >> (8 * (i % 4)); r.resp = d->x_r_resp; r.last = d->x_r_last; rb.push_back(r); }
    if (d->x_b_valid && d->x_b_ready) bb.push_back({(uint32_t)d->x_b_id, (uint32_t)d->x_b_resp});
  }
  void read(uint32_t id, uint64_t addr, uint32_t len = 15, uint32_t size = 4, uint32_t burst = 1, uint32_t mtype = 0, uint32_t dom = 0) { ar.push_back({id, addr, len, size, burst, mtype, dom}); }
  void write(uint32_t id, uint64_t addr, const std::vector<std::vector<uint8_t>>& data, const std::vector<uint32_t>& strb, uint32_t len = ~0u, uint32_t size = 4, uint32_t burst = 1, uint32_t mtype = 0, uint32_t dom = 0, bool w_first = false) {
    if (len == ~0u) len = data.size() - 1;
    auto push_w = [&]() { for (size_t i = 0; i < data.size(); i++) { Wb w; for (int b = 0; b < 16; b++) w.data[b] = data[i][b]; w.strb = strb[i]; w.last = (i + 1 == data.size()); wq.push_back(w); } };
    if (w_first) push_w();
    aw.push_back({id, addr, len, size, burst, mtype, dom});
    if (!w_first) push_w();
  }
  bool wait_r(size_t nbeats, uint64_t maxc = 200000) { return e.run_until([&]() { return rb.size() >= nbeats; }, maxc); }
  bool wait_b(size_t n, uint64_t maxc = 200000) { return e.run_until([&]() { return bb.size() >= n; }, maxc); }
};
static std::vector<std::vector<uint8_t>> rand_data(Env& e, int beats) { std::vector<std::vector<uint8_t>> d(beats, std::vector<uint8_t>(16)); for (auto& b : d) for (auto& x : b) x = e.rng.u32(); return d; }
static uint32_t dma_log_code(Env& e) { e.idle(60); uint32_t v = e.r32(0, sfpb::R_DMA_ERR_LOG0); e.w32(0, sfpb::R_ERR_LOG_CLR, 1); e.idle(5); return (v & 0x1000) ? (v & 0x3F) : 0xFF; }
static size_t count_type_at(Env& e, size_t from, int type, uint64_t lo, uint64_t hi) { size_t n = 0; for (size_t i = from; i < e.rqlog.size(); i++) n += (e.rqlog[i].type == type && e.rqlog[i].addr >= lo && e.rqlog[i].addr < hi); return n; }
static size_t count_type(Env& e, size_t from, int type) { size_t n = 0; for (size_t i = from; i < e.rqlog.size(); i++) n += (e.rqlog[i].type == type); return n; }

static void t_reads(Env& e) {
  Dma dma(e); dma.setup_defaults(); XM x(e);
  // legal reads of every burst length, both ids
  for (uint32_t len = 0; len < 16; len++) {
    uint64_t a = HOST0_IOVA + 0x1000 + 16 * e.rng.below(100); dma.fill_host(0, a, 16 * (len + 1));
    x.rb.clear(); x.read(len & 3, a, len); bool ok = x.wait_r(len + 1);
    C.ok(ok, "burst read completes", len);
    if (!ok) continue;
    bool good = true; for (uint32_t b = 0; b <= len && b < x.rb.size(); b++) { good &= (x.rb[b].resp == 0) && (x.rb[b].last == (b == len)); for (int i = 0; i < 16; i++) good &= (x.rb[b].data[i] == e.hm.rd(a + 16 * b + i)); }
    C.ok(good && x.rb.size() == len + 1, "data identical, RLAST on the last beat only", len);
  }
  struct Bad { const char* name; std::function<void()> go; uint32_t code; size_t beats = 4; };
  uint64_t g = HOST0_IOVA + 0x2000;
  std::vector<Bad> bad = {
    {"size != full width",      [&]{ x.read(0, g, 3, 3); }, 0x35}, {"FIXED burst", [&]{ x.read(0, g, 3, 4, 0); }, 0x35}, {"WRAP burst", [&]{ x.read(0, g, 3, 4, 2); }, 0x35},
    {"memory type != host",     [&]{ x.read(0, g, 3, 4, 1, 1); }, 0x34}, {"unaligned envelope", [&]{ x.read(0, g + 4, 3); }, 0x35},
    {"17 beats (above the burst limit)", [&]{ x.read(0, g, 16); }, 0x33, 17},
    {"domain 3 (no context)",   [&]{ x.read(0, g, 3, 4, 1, 0, 3); }, 0x30}, {"domain 9 (not a context)", [&]{ x.read(0, g, 3, 4, 1, 0, 9); }, 0x30},
    {"below the window",        [&]{ x.read(0, HOST0_IOVA - 0x1000, 3); }, 0x31}, {"above the window", [&]{ x.read(0, HOST0_IOVA + WIN_SIZE, 3); }, 0x31},
    {"straddles the window end",[&]{ x.read(0, HOST0_IOVA + WIN_SIZE - 32, 3); }, 0x31}, {"wrap-around address", [&]{ x.read(0, 0xFFFF'FFFF'FFFF'FFF0ull, 3); }, 0x31},
  };
  for (auto& b : bad) {
    dma_log_code(e); size_t rq0 = e.rqlog.size(); x.rb.clear(); b.go(); bool ok = x.wait_r(b.beats); e.idle(50);
    C.ok(ok, (std::string("error response arrives: ") + b.name).c_str());
    bool allerr = ok; for (auto& r : x.rb) allerr &= (r.resp == 2) && [&]{ for (int i = 0; i < 16; i++) if (r.data[i]) return false; return true; }();
    C.ok(allerr && x.rb.size() == b.beats && x.rb.back().last, (std::string("SLVERR with zero data, burst length respected: ") + b.name).c_str());
    C.ok(dma_log_code(e) == b.code, (std::string("violation logged: ") + b.name).c_str());
    C.ok(count_type(e, rq0, MRD) == 0, (std::string("no TLP left the device: ") + b.name).c_str());
  }
  // a READ through a write-only context is impossible to express (ctx2 is read-only); the converse is in t_writes.
  // ID reuse while the first request is still in flight
  e.cfg.host_lat_lo = 300; e.cfg.host_lat_hi = 300; dma_log_code(e); x.rb.clear();
  dma.fill_host(0, g, 256); x.read(1, g, 15); x.read(1, g + 0x100, 15);
  C.ok(x.wait_r(32, 100000), "both bursts answered");
  int ok_b = 0, err_b = 0; for (auto& r : x.rb) { if (r.last) { (r.resp == 0 ? ok_b : err_b)++; } }
  // the first burst is genuine, the second (same id still in flight) is a protocol error and is answered
  C.ok(err_b == 1, "the duplicate id is refused (PROTO) while the first is in flight", err_b);
  e.cfg.host_lat_lo = 20; e.cfg.host_lat_hi = 50;
  // permission: ctx2 is read-only -> its reads work
  x.rb.clear(); dma.fill_host(2, HOST2_IOVA, 64); x.read(0, HOST2_IOVA, 3, 4, 1, 0, 2); C.ok(x.wait_r(4) && x.rb[0].resp == 0, "read through the read-only context works");
  // translated context
  x.rb.clear(); dma.fill_host(1, HOST1_IOVA + 0x40, 64); x.read(0, HOST1_IOVA + 0x40, 3, 4, 1, 0, 1); C.ok(x.wait_r(4) && x.rb[0].resp == 0, "translated read works");
  bool tr = true; for (int b = 0; b < 4 && b < (int)x.rb.size(); b++) for (int i = 0; i < 16; i++) tr &= (x.rb[b].data[i] == e.hm.rd(HOST1_BUS + 0x40 + 16 * b + i)); C.ok(tr, "data came from the translated bus address");
  finish(e, "reads: no violations");
}

static void t_writes(Env& e) {
  Dma dma(e); dma.setup_defaults(); XM x(e);
  // random contiguous strobe runs, byte exact against a shadow model
  std::vector<uint8_t> shadow(0x4000, 0xCC); for (size_t i = 0; i < shadow.size(); i++) e.hm.wr(HOST0_IOVA + 0x8000 + i, 0xCC);
  for (int it = 0; it < 120; it++) {
    uint32_t beats = 1 + e.rng.below(16); uint64_t base = HOST0_IOVA + 0x8000 + 16 * e.rng.below(200);
    uint32_t first = e.rng.below(16), last = e.rng.below(16);
    if (beats == 1) { uint32_t a = e.rng.below(16), b = e.rng.below(16); first = std::min(a, b); last = std::max(a, b); }
    auto data = rand_data(e, beats); std::vector<uint32_t> strb(beats, 0xFFFF);
    strb[0] = (0xFFFFu << first) & 0xFFFF; if (beats == 1) strb[0] &= (0xFFFFu >> (15 - last)); else strb[beats - 1] = 0xFFFFu >> (15 - last);
    x.bb.clear(); x.write(it & 3, base, data, strb, ~0u, 4, 1, 0, 0, it % 5 == 0);
    bool ok = x.wait_b(1); C.ok(ok && x.bb.size() == 1 && x.bb[0].resp == 0, "write burst acknowledged OKAY", it);
    for (uint32_t b = 0; b < beats; b++) for (int i = 0; i < 16; i++) if (strb[b] & (1u << i)) shadow[base - HOST0_IOVA - 0x8000 + 16 * b + i] = data[b][i];
  }
  e.idle(600);                                                                       // posted data lands
  bool eq = true; for (size_t i = 0; i < shadow.size(); i++) eq &= (e.hm.rd(HOST0_IOVA + 0x8000 + i) == shadow[i]);
  C.ok(eq, "host memory equals the strobe-exact shadow after 120 random bursts");
  // refusals
  struct BadW { const char* name; std::function<void()> go; uint32_t code; };
  auto d4 = rand_data(e, 4); std::vector<uint32_t> full(4, 0xFFFF); uint64_t g = HOST0_IOVA + 0x1000;
  std::vector<uint32_t> sparse = {0xFFFF, 0xF0F0, 0xFFFF, 0xFFFF}, gap = {0x00FF, 0xFFFF, 0xFFFF, 0xFFFF}, gap2 = {0xFFFF, 0x00FF, 0xFFFF, 0xFFFF}, gap3 = {0xFFFF, 0xFFFF, 0, 0xFFFF},
                        hole_first = {0xFF0F, 0xFFFF, 0xFFFF, 0xFFFF}, hole_later = {0xFFFF, 0xFF0F, 0xFFFF, 0xFFFF}, late_start = {0xFFFF, 0xFFF0, 0xFFFF, 0xFFFF};
  std::vector<BadW> bad = {
    {"sparse strobes inside a beat", [&]{ x.write(0, g, d4, sparse); }, 0x36}, {"strobe gap between beats (low half only, then more)", [&]{ x.write(0, g, d4, gap); }, 0x36},
    {"strobe run that stops mid-burst and resumes", [&]{ x.write(0, g, d4, gap3); }, 0x36}, {"short beat in the middle of a burst", [&]{ x.write(0, g, d4, gap2); }, 0x36},
    // each of the three strobe-run conditions in isolation (the cases above trip two of them at once, which hides a broken one)
    {"hole inside the FIRST beat", [&]{ x.write(0, g, d4, hole_first); }, 0x36},
    {"hole inside a later beat whose run starts at byte 0", [&]{ x.write(0, g, d4, hole_later); }, 0x36},
    {"a later beat starting mid-beat after a full beat (contiguous inside the beat, hole in the burst)", [&]{ x.write(0, g, d4, late_start); }, 0x36},
    {"size != full width", [&]{ x.write(0, g, d4, full, ~0u, 3); }, 0x35}, {"FIXED burst", [&]{ x.write(0, g, d4, full, ~0u, 4, 0); }, 0x35},
    {"memory type != host", [&]{ x.write(0, g, d4, full, ~0u, 4, 1, 1); }, 0x34}, {"unaligned envelope", [&]{ x.write(0, g + 4, d4, full); }, 0x35},
    {"domain 3 (no context)", [&]{ x.write(0, g, d4, full, ~0u, 4, 1, 0, 3); }, 0x30}, {"outside the window", [&]{ x.write(0, HOST0_IOVA + WIN_SIZE, d4, full); }, 0x31},
    {"straddles the window end", [&]{ x.write(0, HOST0_IOVA + WIN_SIZE - 32, d4, full); }, 0x31},
    {"write through the READ-ONLY context", [&]{ x.write(0, HOST2_IOVA + 0x100, d4, full, ~0u, 4, 1, 0, 2); }, 0x32},
    {"W/AW mismatch: 4 beats announced, 3 sent", [&]{ auto d3 = rand_data(e, 3); std::vector<uint32_t> f3(3, 0xFFFF); x.write(0, g, d3, f3, 3); }, 0x37},
    {"W/AW mismatch: 2 beats announced, 4 sent", [&]{ x.write(0, g, d4, full, 1); }, 0x37},
  };
  for (auto& b : bad) {
    for (int i = 0; i < 4; i++) e.hm.wr(g + i, 0x5A);
    dma_log_code(e); size_t rq0 = e.rqlog.size(); x.bb.clear(); b.go(); bool ok = x.wait_b(1);
    C.ok(ok && x.bb.size() == 1 && x.bb[0].resp == 2, (std::string("B = SLVERR: ") + b.name).c_str());
    C.ok(dma_log_code(e) == b.code || b.code == 0x36 || b.code == 0x37, (std::string("violation logged: ") + b.name).c_str());
    e.idle(300);
    C.ok(count_type(e, rq0, MWR) == 0, (std::string("no TLP left the device: ") + b.name).c_str());
    bool untouched = true; for (int i = 0; i < 4; i++) untouched &= (e.hm.rd(g + i) == 0x5A); C.ok(untouched, (std::string("host memory untouched: ") + b.name).c_str());
    // the write path must still be in step afterwards
    x.bb.clear(); auto ok4 = rand_data(e, 2); std::vector<uint32_t> f2(2, 0xFFFF); x.write(1, HOST0_IOVA + 0xC000, ok4, f2); C.ok(x.wait_b(1) && x.bb[0].resp == 0, (std::string("a legal write works afterwards: ") + b.name).c_str());
    x.wq.clear(); x.aw.clear();
  }
  // all-zero strobes: nothing to send, B OKAY
  size_t rq0 = e.rqlog.size(); x.bb.clear(); std::vector<uint32_t> z(2, 0); x.write(0, g, rand_data(e, 2), z); C.ok(x.wait_b(1) && x.bb[0].resp == 0, "all-zero strobes: acknowledged without any TLP"); e.idle(100); C.ok(count_type_at(e, rq0, MWR, g, g + 32) == 0, "no TLP for an empty write");   // (address-filtered: the previous legal write is posted and may still be leaving)
  // W before AW is accepted
  x.bb.clear(); auto dd = rand_data(e, 3); std::vector<uint32_t> f3(3, 0xFFFF); x.write(2, HOST0_IOVA + 0xD000, dd, f3, ~0u, 4, 1, 0, 0, true); C.ok(x.wait_b(1) && x.bb[0].resp == 0, "W data presented before AW is carried");
  finish(e, "writes: no violations");
}

static void t_split(Env& e) {
  // MPS 128 B: a 256 B burst becomes two TLPs; a translated window that makes the burst straddle a 4 KiB boundary on the BUS splits there
  e.cfg.mps_code = 0; e.cfg.mrrs_code = 0;
  Dma dma(e); dma.setup_defaults();
  dma.setup(1, HOST1_IOVA, 0x4'0000, true, true, true, HOST1_BUS + 0xF80);                    // bus address = iova + 0x...F80 (not 4 KiB aligned)
  XM x(e);
  auto data = rand_data(e, 16); std::vector<uint32_t> full(16, 0xFFFF);
  size_t n0 = e.rqlog.size(); x.write(0, HOST1_IOVA, data, full, ~0u, 4, 1, 0, 1); C.ok(x.wait_b(1) && x.bb[0].resp == 0, "translated write acknowledged");
  e.idle(600);
  size_t nw = count_type(e, n0, MWR); C.ok(nw == 2, "256 B at bus ...F80 with MPS 128: 0xF80..0xFFF + 0x1000..0x107F (split exactly at the 4 KiB boundary, each <= MPS)", nw, 2);
  bool eq = true; for (int b = 0; b < 16; b++) for (int i = 0; i < 16; i++) eq &= (e.hm.rd(HOST1_BUS + 0xF80 + 16 * b + i) == data[b][i]); C.ok(eq, "all 256 bytes landed at the right bus addresses");
  // translated read straddling the boundary
  dma.fill_host(1, HOST1_IOVA + 0x400, 256); x.rb.clear(); x.read(0, HOST1_IOVA + 0x400, 15, 4, 1, 0, 1); C.ok(x.wait_r(16), "translated read answered");
  bool rd = true; for (int b = 0; b < 16 && b < (int)x.rb.size(); b++) for (int i = 0; i < 16; i++) rd &= (x.rb[b].data[i] == e.hm.rd(HOST1_BUS + 0xF80 + 0x400 + 16 * b + i)); C.ok(rd, "read data identical across the split");
  finish(e, "split: no violations");
}


static void t_boundary(Env& e) {
  // The 4 KiB rule with MPS = 256 B and MRRS = 512 B (the bench defaults): the boundary is closer than the size limit, so ONLY the
  // 4 KiB rule decides where a TLP ends.  (t_split puts the boundary exactly at the size limit, where the two rules coincide.)
  Dma dma(e); dma.setup_defaults(); XM x(e);
  const uint64_t page = HOST0_IOVA + 0x10000;                                   // 4 KiB aligned, inside context 0's window (identity)
  for (uint32_t o : {0xF00u, 0xF10u, 0xF40u, 0xF80u, 0xFC0u, 0xFF0u}) {
    const uint64_t a = page + o; const uint32_t nb = 16, bytes = 256, first = std::min<uint32_t>(bytes, 0x1000 - o);
    auto shape_ok = [&](size_t n0, int type) {
      std::vector<RqRec> v; for (size_t i = n0; i < e.rqlog.size(); i++) if (e.rqlog[i].type == type) v.push_back(e.rqlog[i]);
      if (first == bytes) return v.size() == 1 && v[0].addr == a && v[0].ndw == bytes / 4;
      return v.size() == 2 && v[0].addr == a && v[0].ndw == first / 4 && v[1].addr == page + 0x1000 && v[1].ndw == (bytes - first) / 4;
    };
    auto data = rand_data(e, nb); std::vector<uint32_t> full(nb, 0xFFFF);
    size_t n0 = e.rqlog.size(); x.bb.clear(); x.write(0, a, data, full);
    C.ok(x.wait_b(1) && x.bb[0].resp == 0, "write acknowledged", o); e.idle(500);
    C.ok(shape_ok(n0, MWR), "write: the first TLP ends exactly at the 4 KiB boundary (no TLP crosses it)", o);
    bool eq = true; for (uint32_t b = 0; b < nb; b++) for (int i = 0; i < 16; i++) eq &= (e.hm.rd(a + 16 * b + i) == data[b][i]);
    C.ok(eq, "write: all bytes landed at the right addresses", o);
    dma.fill_host(0, a, bytes); n0 = e.rqlog.size(); x.rb.clear(); x.read(0, a, nb - 1);
    C.ok(x.wait_r(nb), "read answered", o); e.idle(100);
    C.ok(shape_ok(n0, MRD), "read: the first TLP ends exactly at the 4 KiB boundary (no TLP crosses it)", o);
    bool rd = x.rb.size() == nb; for (uint32_t b = 0; rd && b < nb; b++) { rd &= (x.rb[b].resp == 0); for (int i = 0; i < 16; i++) rd &= (x.rb[b].data[i] == e.hm.rd(a + 16 * b + i)); }
    C.ok(rd, "read: data identical across the split", o);
  }
  finish(e, "boundary: no violations");
}

static void t_recovery(Env& e) {
  // StreamDMA is bypassed, so nothing aborts the adversarial master: what the adapter itself returns during a recovery is visible.
  // A read burst is loaded in the planner with its TLPs unable to leave (non-posted credits withheld) when the link dies; every
  // R beat must come back SLVERR with zero data.  OKAY (with whatever the slot buffer holds) would let a request that was
  // never carried out report success.
  e.cfg.mrrs_code = 0; e.cfg.np_ok_pct = 0;                                       // MRRS 128 B: this 256 B burst needs two read TLPs; none can leave
  Dma dma(e); dma.setup_defaults(); XM x(e); e.w32(0, sfpb::R_REC_QUIET, 200);
  dma.fill_host(0, HOST0_IOVA + 0x2000, 256); x.rb.clear(); x.read(1, HOST0_IOVA + 0x2000, 15);
  e.idle(300);
  size_t reads = 0; for (auto& r : e.rqlog) reads += (r.type == MRD);
  C.ok(reads == 0 && x.rb.empty(), "precondition: the burst is parked in the planner (no TLP left, no response yet)", reads);
  e.link_down(); e.idle(60); e.link_up = true;
  bool got = x.wait_r(16, 400000); C.ok(got, "the parked burst is answered (not left hanging)");
  bool allerr = got && x.rb.size() == 16; for (auto& r : x.rb) { allerr &= (r.resp == 2); for (int i = 0; i < 16; i++) allerr &= (r.data[i] == 0); }
  C.ok(allerr && x.rb.back().last && x.rb.front().id == 1, "every beat is SLVERR with zero data (a lost request is never OKAY)", got ? (long long)x.rb.size() : -1);
  C.ok(e.run_until([&]() { return e.d->rec_state == 0 && !e.d->rec_flush_mmio && !e.d->rec_flush_dma && e.link_up; }, 400000), "recovery completes");
  e.cfg.np_ok_pct = 100; e.idle(10);
  dma.fill_host(0, HOST0_IOVA + 0x3000, 64); x.rb.clear(); x.read(2, HOST0_IOVA + 0x3000, 3);
  bool ok2 = x.wait_r(4); bool good = ok2; for (int b = 0; good && b < 4; b++) { good &= (x.rb[b].resp == 0); for (int i = 0; i < 16; i++) good &= (x.rb[b].data[i] == e.hm.rd(HOST0_IOVA + 0x3000 + 16 * b + i)); }
  C.ok(good, "the adapter serves a normal read after the recovery");
  // the same for a posted WRITE parked in the write planner (posted credits withheld) when the link dies
  const uint64_t wa = HOST0_IOVA + 0x5000; for (int i = 0; i < 64; i++) e.hm.wr(wa + i, 0xCC);
  e.cfg.p_ok_pct = 0; auto wd = rand_data(e, 4); std::vector<uint32_t> wfull(4, 0xFFFF); size_t w0 = e.rqlog.size(); x.bb.clear(); x.write(1, wa, wd, wfull);
  e.idle(300);
  C.ok(count_type(e, w0, MWR) == 0 && x.bb.empty(), "precondition: the write burst is parked in the planner (no TLP, no B)", count_type(e, w0, MWR));
  e.link_down(); e.idle(60); e.link_up = true;
  bool gotb = x.wait_b(1, 400000); C.ok(gotb && x.bb[0].resp == 2, "the parked write is answered SLVERR (a lost write is never acknowledged as done)", x.bb.empty() ? -1 : (long long)x.bb[0].resp);
  C.ok(e.run_until([&]() { return e.d->rec_state == 0 && !e.d->rec_flush_mmio && !e.d->rec_flush_dma && e.link_up; }, 400000), "recovery completes (write case)");
  e.cfg.p_ok_pct = 100; e.idle(200);
  bool untouched = true; for (int i = 0; i < 64; i++) untouched &= (e.hm.rd(wa + i) == 0xCC);
  C.ok(untouched, "nothing of the aborted write reached host memory");
  x.bb.clear(); x.write(2, wa, wd, wfull); bool w2 = x.wait_b(1) && x.bb[0].resp == 0; e.idle(300);
  bool eq2 = w2; for (int b = 0; b < 4; b++) for (int i = 0; i < 16; i++) eq2 &= (e.hm.rd(wa + 16 * b + i) == wd[b][i]);
  C.ok(eq2, "the adapter serves a normal write after the recovery");
  finish(e, "recovery: no violations");
}

static void t_credits(Env& e) {
  // The posted-credit hint withheld: NO write TLP may leave and no B may be returned; once released the burst goes out.
  Dma dma(e); dma.setup_defaults(); XM x(e);
  const uint64_t a = HOST0_IOVA + 0x6000; for (int i = 0; i < 64; i++) e.hm.wr(a + i, 0xCC);
  e.cfg.p_ok_pct = 0;
  auto data = rand_data(e, 4); std::vector<uint32_t> full(4, 0xFFFF); size_t n0 = e.rqlog.size(); x.bb.clear(); x.write(0, a, data, full);
  e.idle(400);
  C.ok(count_type(e, n0, MWR) == 0 && x.bb.empty(), "no write TLP leaves and no B is returned while posted credits are withheld", count_type(e, n0, MWR));
  e.cfg.p_ok_pct = 100; C.ok(x.wait_b(1) && x.bb[0].resp == 0, "released: the burst goes out and is acknowledged");
  e.idle(400); bool eq = true; for (int b = 0; b < 4; b++) for (int i = 0; i < 16; i++) eq &= (e.hm.rd(a + 16 * b + i) == data[b][i]);
  C.ok(eq, "and its data landed");
  finish(e, "credits: no violations");
}

static void t_backpressure(Env& e) {
  e.cfg.rq_stall = 60; e.cfg.rc_gap = 40;
  Dma dma(e); dma.setup_defaults(); XM x(e); x.r_stall = 60; x.b_stall = 60; x.v_gap = 30;
  int nr = 0, nw = 0, bad = 0; std::vector<std::pair<uint64_t, std::vector<std::vector<uint8_t>>>> wr;
  int rd_issued = 0;
  auto last_beats = [&]() { int n = 0; for (auto& r : x.rb) n += r.last; return n; };
  for (int i = 0; i < 40; i++) {
    uint64_t a = HOST0_IOVA + 0x10000 + 256 * i;
    if (i & 1) { auto d = rand_data(e, 16); std::vector<uint32_t> f(16, 0xFFFF); x.write(i & 3, a, d, f); wr.push_back({a, d}); nw++; }
    else {
      e.run_until([&]() { return rd_issued - last_beats() < 4; }, 2000000);                 // read ids must be unique among OUTSTANDING reads (the contract StreamDMA's slot ids satisfy)
      dma.fill_host(0, a, 256); x.read(rd_issued & 3, a, 15); rd_issued++; nr++;
    }
  }
  C.ok(x.wait_r(nr * 16, 2000000) && x.wait_b(nw, 2000000), "everything completes under back-pressure on every channel");
  C.ok(x.rb.size() == (size_t)nr * 16 && x.bb.size() == (size_t)nw, "no beat or response lost or duplicated", x.rb.size(), nr * 16);
  for (auto& r : x.rb) bad += (r.resp != 0); for (auto& b : x.bb) bad += (b.resp != 0); C.ok(bad == 0, "all OKAY", bad);
  e.idle(800); bool eq = true; for (auto& w : wr) for (int b = 0; b < 16; b++) for (int i = 0; i < 16; i++) eq &= (e.hm.rd(w.first + 16 * b + i) == w.second[b][i]); C.ok(eq, "every write landed byte-exact");
  finish(e, "backpressure: no violations");
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  std::vector<Test> tests = {{"reads", t_reads}, {"writes", t_writes}, {"split", t_split}, {"boundary", t_boundary}, {"recovery", t_recovery}, {"credits", t_credits}, {"backpressure", t_backpressure}};
  const char* only = argc > 1 ? argv[1] : nullptr;
  for (auto& t : tests) {
    if (only && std::strcmp(only, t.name)) continue;
    int f0 = C.fails;
    for (int mode = 0; mode < 2; mode++) {
      Env e(1100 + mode * 19 + std::strlen(t.name));
      if (mode == 1) { e.cfg.rq_stall = 30; e.cfg.rc_gap = 25; e.cfg.split = 3; e.cfg.host_lat_hi = 150; }
      e.w32(0, sfpb::R_CTRL, 0x27); e.w32(0, sfpb::R_CPL_TIMEOUT, 200);
      C.tag = std::string(t.name) + (mode ? "/stress" : "");
      t.fn(e);
    }
    std::printf("  %-18s %s\n", t.name, C.fails == f0 ? "PASS" : "FAIL");
  }
  std::printf("tb_hostile DATA_W=%d: %d checks, %d failures\n", DW, C.checks, C.fails);
  return C.fails ? 1 : 0;
}
