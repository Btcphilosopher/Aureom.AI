// Shared helpers for the Verilator C++ benches (P110).
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <deque>
#include <map>
#include <algorithm>
#include "verilated.h"

struct Rng {                                 // xorshift64*, deterministic across platforms
  uint64_t s;
  explicit Rng(uint64_t seed = 1) : s(seed ? seed : 0x9E3779B97F4A7C15ull) { for (int i = 0; i < 4; i++) next(); }
  uint64_t next() { s ^= s >> 12; s ^= s << 25; s ^= s >> 27; return s * 0x2545F4914F6CDD1Dull; }
  uint32_t u32() { return (uint32_t)(next() >> 32); }
  uint32_t below(uint32_t n) { return n ? (uint32_t)(((next() >> 11) * (uint64_t)n) >> 53) : 0; }
  bool     chance(uint32_t pct) { return below(100) < pct; }
  uint32_t range(uint32_t lo, uint32_t hi) { return lo + below(hi - lo + 1); }
};

// Verilator exposes signals wider than 64 bits as VlWide<N>; these helpers treat any such signal as uint32_t words.
template <class T> inline uint32_t* W(T& sig) { return reinterpret_cast<uint32_t*>(&sig); }
template <class T> inline const uint32_t* WC(const T& sig) { return reinterpret_cast<const uint32_t*>(&sig); }

inline void put_bits(uint32_t* w, int lsb, int width, uint64_t v) {   // write up to 64 bits at bit offset lsb
  for (int i = 0; i < width; i++) {
    int b = lsb + i;
    uint32_t m = 1u << (b & 31);
    if ((v >> i) & 1) w[b >> 5] |= m; else w[b >> 5] &= ~m;
  }
}
inline uint64_t get_bits(const uint32_t* w, int lsb, int width) {
  uint64_t v = 0;
  for (int i = 0; i < width; i++) { int b = lsb + i; v |= (uint64_t)((w[b >> 5] >> (b & 31)) & 1) << i; }
  return v;
}

struct Checker {                             // failure accounting shared by every bench
  int fails = 0, checks = 0;
  std::string tag;
  void ok(bool c, const char* what, long long a = 0, long long b = 0) {
    checks++;
    if (!c) { fails++; if (fails <= 40) std::printf("  FAIL[%s] %s (%lld vs %lld)\n", tag.c_str(), what, a, b); }
  }
};
