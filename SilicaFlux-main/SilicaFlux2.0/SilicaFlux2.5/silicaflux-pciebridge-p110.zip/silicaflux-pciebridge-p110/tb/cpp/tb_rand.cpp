// Constrained-random system regression.  Per seed: a random environment (back-pressure, link latencies, completion
// splitting policy, MPS/MRRS, credit limits, fabric speed), then a random mix of MMIO reads/writes, DMA transfers in both
// directions (two contexts, one translated), host-side completion faults, invalid and malformed accesses and interrupts.
// Independent scoreboards: byte-exact shadow of fabric memory and registers, byte-exact reference for every DMA,
// ordered fabric transaction log, host-side protocol monitors, error-class accounting.
#include "tb_dma_lib.h"
using namespace env;
static Checker C;

static uint64_t host_bus_of(int ctx, uint64_t iova) { return ctx == 1 ? HOST1_BUS + (iova - HOST1_IOVA) : iova; }

struct Board {                                                     // shadow models
  std::vector<uint8_t> mem = std::vector<uint8_t>(FAB_MEM_SIZE, 0);
  uint32_t scratch = 0;
  std::vector<std::pair<uint32_t, uint32_t>> wr_log;               // expected fabric writes (addr, data) in order
  uint32_t expect_classes = 0;                                     // bits of ERR_STATUS that injected errors may legitimately raise
};

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  int nseeds = argc > 1 ? std::atoi(argv[1]) : 10; int ops = argc > 2 ? std::atoi(argv[2]) : 50; uint64_t seed0 = argc > 3 ? std::strtoull(argv[3], nullptr, 10) : 1;
  for (int sd = 0; sd < nseeds; sd++) {
    uint64_t seed = seed0 + sd; Env e(seed * 7919); Rng& R = e.rng; C.tag = "seed " + std::to_string(seed);
    // ---- random environment -------------------------------------------------------------------------------------
    e.cfg.cq_gap = R.below(40); e.cfg.cc_stall = R.below(50); e.cfg.rq_stall = R.below(50); e.cfg.rc_gap = R.below(40);
    e.cfg.link_rq = 2 + R.below(60); e.cfg.link_cc = 2 + R.below(60); e.cfg.link_msi = 2 + R.below(40);
    e.cfg.fab_lat_lo = 1 + R.below(3); e.cfg.fab_lat_hi = e.cfg.fab_lat_lo + R.below(10); e.cfg.fab_ready_pct = 30 + R.below(71);
    e.cfg.dev_lat_lo = 1 + R.below(4); e.cfg.dev_lat_hi = e.cfg.dev_lat_lo + R.below(30);
    e.cfg.host_lat_lo = 5 + R.below(40); e.cfg.host_lat_hi = e.cfg.host_lat_lo + R.below(200); e.cfg.split = R.below(4);
    e.cfg.mps_code = R.below(3); e.cfg.mrrs_code = R.below(4); e.cfg.np_ok_pct = 60 + R.below(41); e.cfg.p_ok_pct = 60 + R.below(41);
    e.cfg.msi_delay = 1 + R.below(10);
    Dma dma(e); dma.setup_defaults(); e.w32(0, sfpb::R_CPL_TIMEOUT, (e.cfg.host_lat_hi + 600 + 2 * e.cfg.link_rq) / 16 + 4);
    if (R.chance(30)) e.w32(0, sfpb::R_CTRL, 0x2F);                    // strict write acknowledge
    e.w32(0, sfpb::R_IRQ_MASK, 0xFF); e.msi_mm = 4;
    Board B; int dmas = 0, mmio_w = 0, mmio_r = 0, faults = 0, invalids = 0, bad_reads = 0; int f0 = C.fails;
    std::vector<std::pair<uint16_t, std::vector<uint32_t>>> pending_reads;
    uint16_t txn = 1;
    for (int op = 0; op < ops; op++) {
      int kind = R.below(100);
      if (kind < 30) {                                                 // MMIO write to fabric memory
        uint32_t n = 1 + R.below(24); uint32_t off = 4 * R.below(200); while (((off & 0xFFF) / 4 + n) > 1024) off -= 4;
        std::vector<uint32_t> v(n); for (auto& x : v) x = R.u32(); uint8_t f, l;
        if (n == 1) { f = R.below(16); l = 0; } else if (n == 2) { f = 1 + R.below(15); l = 1 + R.below(15); }
        else { static const uint8_t fs[4] = {0xF, 0xE, 0xC, 0x8}, ls[4] = {0xF, 0x7, 0x3, 0x1}; f = fs[R.below(4)]; l = ls[R.below(4)]; }
        e.mmio_write(2, off, v, f, l);
        for (uint32_t i = 0; i < n; i++) { uint8_t be = i == 0 ? f : (i == n - 1 ? l : 0xF); for (int b = 0; b < 4; b++) if (be & (1 << b)) B.mem[off + 4 * i + b] = v[i] >> (8 * b);
          if (be) { uint32_t cur = 0; (void)cur; B.wr_log.push_back({FAB_MEM_BASE + off + 4 * i, 0}); } }
        mmio_w++;
      } else if (kind < 50) {                                          // MMIO read (not waited for: the data must reflect every earlier write)
        uint32_t n = 1 + R.below(20); uint32_t off = 4 * R.below(200); while (((off & 0xFFF) / 4 + n) > 1024) off -= 4;
        uint16_t t = e.mmio_read_start(2, off, n);
        std::vector<uint32_t> x(n); for (uint32_t i = 0; i < n; i++) x[i] = B.mem[off + 4 * i] | (B.mem[off + 4 * i + 1] << 8) | (B.mem[off + 4 * i + 2] << 16) | ((uint32_t)B.mem[off + 4 * i + 3] << 24);
        pending_reads.push_back({t, x}); mmio_r++;
      } else if (kind < 56) {                                          // scratch register
        uint32_t v = R.u32(); uint8_t be = 1 + R.below(15); e.w32(0, sfpb::R_SCRATCH, v, be);
        for (int b = 0; b < 4; b++) if (be & (1 << b)) B.scratch = (B.scratch & ~(0xFFu << (8 * b))) | (v & (0xFFu << (8 * b)));
        uint16_t t = e.mmio_read_start(0, sfpb::R_SCRATCH); pending_reads.push_back({t, {B.scratch}});
      } else if (kind < 82) {                                          // DMA transfer
        int ctx = R.below(2); bool h2d = R.below(2); uint32_t len = 1 + R.below(R.chance(20) ? 6000 : 700);
        uint64_t iova = (ctx == 0 ? HOST0_IOVA : HOST1_IOVA) + 0x400 + R.below(0x8000), dev = DEV_BASE + 0x400 + R.below(0x8000);
        bool inject = R.chance(12); Fault f;
        if (h2d && inject) { static const Fault::Kind ks[] = {Fault::UR, Fault::CA, Fault::POISON, Fault::BAD_BC, Fault::BAD_LOWER, Fault::SHORT, Fault::LONG, Fault::DROP}; f.kind = ks[R.below(8)]; f.addr_lo = host_bus_of(ctx, iova); f.addr_hi = f.addr_lo + len; f.count = 1; f.skip = R.below(2); e.faults = {f}; B.expect_classes |= (1u << 6) | (1u << 7) | (1u << 3) | (1u << 8) | (1u << 10); faults++; }
        uint8_t canary = h2d ? 0xEE : 0xCC;
        if (h2d) { dma.fill_host(ctx, iova, len); for (uint32_t i = 0; i < len + 64; i++) e.dev_mem[dev - DEV_BASE - 32 + i] = canary; }
        else { dma.fill_dev(dev, len); for (uint32_t i = 0; i < len + 64; i++) e.hm.wr(host_bus_of(ctx, iova) - 32 + i, canary); }
        auto s = h2d ? dma.h2d(ctx, txn, iova, dev, len) : dma.d2h(ctx, txn, dev, iova, len);
        C.ok(s.status() == 1 || s.status() == 2, "descriptor accepted or busy", s.status(), s.code());
        if (s.status() == 2) { e.idle(2000); continue; }
        // background MMIO while the transfer runs
        for (int k = 0; k < 4; k++) { e.w32(0, sfpb::R_SCRATCH, R.u32()); B.scratch = 0; uint16_t t = e.mmio_read_start(0, sfpb::R_ID); pending_reads.push_back({t, {0x53465042u}}); }
        { uint32_t v = R.u32(); e.w32(0, sfpb::R_SCRATCH, v); B.scratch = v; }
        CplRec r; bool got = dma.wait_record(ctx, r, 3000000); C.ok(got, "DMA record arrives", txn);
        if (got) {
          if (inject && h2d && f.kind != Fault::NONE) {
            bool fired = e.faults.empty() || e.faults[0].count == 0 || true; (void)fired;
            // the fault may not have matched any request (skip); then the transfer legitimately succeeds
            if (r.status == 0) C.ok(r.done == len && dma.dev_equals_host(ctx, dev, iova, len), "unmatched fault: transfer still byte exact", len);
            else { C.ok(r.status == 1 && r.err == 0x30, "faulted transfer is FAILED (bus read error)", r.status, r.err);
                   uint32_t st = e.r32(0, sfpb::R_STATUS); (void)st; e.w32(0, sfpb::R_CTRL, 0x827 | (R.chance(30) ? 8 : 0)); e.idle(20); e.root_tags.clear(); }
            e.faults.clear();
          } else {
            C.ok(r.status == 0 && r.done == len && r.total == len, "transfer completes OK", r.status, r.done);
            if (r.status == 0) {
              C.ok(h2d ? dma.dev_equals_host(ctx, dev, iova, len) : dma.dev_equals_host(ctx, dev, iova, len), "byte-exact copy", len, h2d);
              bool can = true; for (int i = 1; i <= 32; i++) { if (h2d) { can &= (e.dev_mem[dev - DEV_BASE - i] == canary) && (e.dev_mem[dev - DEV_BASE + len - 1 + i] == canary); } else { can &= (e.hm.rd(host_bus_of(ctx, iova) - i) == canary) && (e.hm.rd(host_bus_of(ctx, iova) + len - 1 + i) == canary); } }
              C.ok(can, "nothing written outside the destination range", len);
            }
          }
          e.w32(0, sfpb::R_CTRL, e.d->rec_state ? 0x27 : 0x27);
        }
        txn++; dmas++;
      } else if (kind < 90) {                                          // invalid / malformed access
        invalids++; uint32_t sub = R.below(4);
        if (sub == 0) { auto h = e.mmio_read(0, 0x6000 + 4 * R.below(100)); C.ok(h.status == UR, "unmapped BAR0 read -> UR", h.status); B.expect_classes |= (1u << 2); }
        else if (sub == 1) { Req r = Env::mk_req(MWR, BAR2_BASE + 0x100, 8, 0xF, 0xF, 2, 20); r.data = std::vector<uint32_t>(5, 1); e.post_raw(r); B.expect_classes |= (1u << 0); }
        else if (sub == 2) { Req r = Env::mk_req(MWR, BAR2_BASE + 0xFF8, 4, 0xF, 0xF, 2, 20); r.data = {1, 2, 3, 4}; e.post_raw(r); B.expect_classes |= (1u << 0); }
        else { Req r = Env::mk_req(IORD, BAR2_BASE + 0x40, 1, 0xF, 0, 2, 20); uint16_t t = e.alloc_tag(); r.tag = t; e.post_raw(r, nullptr, -1, true); auto h = e.wait_read(t, 50000); C.ok(h.status == UR, "I/O read -> UR", h.status); B.expect_classes |= (1u << 1); }
      } else if (kind < 95) {                                          // software interrupt
        e.w32(0, sfpb::R_IRQ_STATUS, 0xFF); e.w32(0, sfpb::R_IRQ_SET, 1u << (5 + R.below(3)));
      } else e.idle(R.below(200));
    }
    // ---- drain and final scoreboards ------------------------------------------------------------------------------
    int bad = 0;
    for (auto& p : pending_reads) { auto h = e.wait_read(p.first, 4000000); if (h.bad || h.status != SC || h.data != p.second) { bad++; if (bad < 4) std::printf("   bad read tag %u: bad=%d status=%d got %zu dw (%s)\n", p.first, (int)h.bad, h.status, h.data.size(), h.why.c_str()); } }
    C.ok(bad == 0, "every MMIO read returned the shadow-model data", bad, (int)pending_reads.size());
    e.idle(2000);
    size_t wi = 0; bool order_ok = true; size_t nwr = 0;
    for (auto& t : e.fablog) if (t.wr) { nwr++; if (wi < B.wr_log.size() && t.addr != B.wr_log[wi].first) order_ok = false; wi++; }
    C.ok(order_ok && nwr == B.wr_log.size(), "fabric write stream equals the submitted stream (order, address, count)", nwr, B.wr_log.size());
    C.ok(std::equal(B.mem.begin(), B.mem.end(), e.fab_mem.begin()), "fabric memory equals the shadow model");
    uint32_t st = e.r32(0, sfpb::R_STATUS); C.ok(((st >> 8) & 0xFF) == 0 && !((st >> 3) & 1), "nothing outstanding, DMA idle at the end", st);
    uint32_t es = e.r32(0, sfpb::R_ERR_STATUS); uint32_t allowed = B.expect_classes | (1u << 13) | (1u << 6) | (1u << 7) | (1u << 8);
    C.ok((es & ~allowed) == 0, "no error class was raised that was not injected", es, allowed);
    C.ok(e.no_violations(), "no protocol / ordering violation observed by the host monitors", e.n_viol);
    if (!e.no_violations()) e.print_violations();
    std::printf("  seed %-4llu W=%d: %d mmio writes, %d reads, %d dma (%d faulted), %d invalid | rq=%llu cc=%llu rc=%llu reorders=%llu | %s\n", (unsigned long long)seed, DW, mmio_w, mmio_r, dmas, faults, invalids,
                (unsigned long long)e.n_rq_tlps, (unsigned long long)e.n_cc_tlps, (unsigned long long)e.n_rc_tlps, (unsigned long long)e.reorder_events, C.fails == f0 ? "PASS" : "FAIL");
    (void)bad_reads;
  }
  std::printf("tb_rand DATA_W=%d: %d checks, %d failures\n", DW, C.checks, C.fails);
  return C.fails ? 1 : 0;
}
