// Host-driver helpers for DMA tests: context + guard setup, descriptor submission, completion retrieval, reference copy.
#pragma once
#include "tb_env.h"
namespace env {

struct CplRec { bool valid = false; uint16_t txn = 0; uint8_t dom = 0, status = 0, err = 0, detail = 0, perr = 0; bool partial = false; uint32_t done = 0, total = 0, lat = 0; uint64_t eaddr = 0; };
struct SubmitRes { uint32_t raw = 0; int status() const { return raw & 0xF; } int code() const { return (raw >> 8) & 0x3F; } };

constexpr uint64_t HOST0_IOVA = 0x2'0000'0000ull;         // ctx0: identity window
constexpr uint64_t HOST1_IOVA = 0x4000'0000ull;           // ctx1: translated window
constexpr uint64_t HOST1_BUS  = 0x9'8000'0000ull;
constexpr uint64_t HOST2_IOVA = 0x3'0000'0000ull;         // ctx2: read-only window
constexpr uint64_t WIN_SIZE   = 0x10'0000ull;

struct Dma {
  Env& e;
  explicit Dma(Env& env) : e(env) {}
  uint64_t bus_of(int ctx, uint64_t iova) const { return ctx == 1 ? HOST1_BUS + (iova - HOST1_IOVA) : iova; }

  // programs context c in the bridge (privileged) and the matching entries of StreamDMA's own guard
  uint32_t setup(int c, uint64_t iova_base, uint64_t size, bool rd, bool wr, bool xlat, uint64_t bus_base, uint32_t maxlen = 0x10000,
                 uint64_t dev_base = DEV_BASE, uint64_t dev_size = DEV_SIZE) {
    uint32_t cs = e.ctx_program(c, true, rd, wr, xlat, iova_base, size, bus_base, dev_base, dev_size, maxlen);
    int perm = (rd ? 1 : 0) | (wr ? 2 : 0);
    e.guard_add(2 * c, c, 0, iova_base & ~0xFFFull, ((iova_base & 0xFFF) + size + 0xFFF) & ~0xFFFull, iova_base & ~0xFFFull, 3);
    e.guard_add(2 * c + 1, c, 1, dev_base, dev_size, dev_base, 3);
    (void)perm;
    return cs;
  }
  void setup_defaults() {
    setup(0, HOST0_IOVA, WIN_SIZE, true, true, false, 0);
    setup(1, HOST1_IOVA, 0x4'0000, true, true, true, HOST1_BUS);
    setup(2, HOST2_IOVA, WIN_SIZE, true, false, false, 0);
    e.w32(0, sfpb::R_CTRL, 0x27);                                // host enables DMA (FWIN_RD/WR, DMA_EN, PERF_EN)
    e.idle(40);   // the CTRL write is a posted TLP: DMA_EN only takes effect once it has landed (device-initiated traffic
                  // started in the very next cycle is refused with SFPB_E_DMA_NO_CTX -- by design, and tested in tb_dma)
  }

  uint32_t page(int ctx) const { return 0x1000u * (1 + ctx); }
  SubmitRes submit(int ctx, uint16_t txn, uint8_t src_t, uint8_t dst_t, uint64_t src, uint64_t dst, uint32_t len, uint32_t flags = 0x3,
                   int claim = -1, uint32_t version = 1, uint32_t opcode = 0, uint32_t w2_extra = 0) {
    uint32_t pg = page(ctx); if (claim < 0) claim = ctx;
    e.mmio_write(0, pg + sfpb::C_DESC0, {version | (opcode << 8) | (flags << 16), txn | ((uint32_t)claim << 16)});
    e.mmio_write(0, pg + sfpb::C_DESC2, {(uint32_t)src_t | ((uint32_t)dst_t << 4) | w2_extra, len});
    e.mmio_write(0, pg + sfpb::C_DESC4, {(uint32_t)src, (uint32_t)(src >> 32)});
    e.mmio_write(0, pg + sfpb::C_DESC6, {(uint32_t)dst, (uint32_t)(dst >> 32)});
    e.w32(0, pg + sfpb::C_DOORBELL, 1);
    SubmitRes r; r.raw = e.r32(0, pg + sfpb::C_SUBMIT_STATUS); return r;
  }
  SubmitRes h2d(int ctx, uint16_t txn, uint64_t iova, uint64_t dev, uint32_t len, uint32_t flags = 0x3) { return submit(ctx, txn, 0, 1, iova, dev, len, flags); }
  SubmitRes d2h(int ctx, uint16_t txn, uint64_t dev, uint64_t iova, uint32_t len, uint32_t flags = 0x3) { return submit(ctx, txn, 1, 0, dev, iova, len, flags); }

  // wait for the next completion record of a context by polling, then pop it
  bool wait_record(int ctx, CplRec& r, uint64_t maxc = 400000) {
    uint32_t pg = page(ctx); uint64_t c0 = e.cyc;
    for (;;) {
      uint32_t st = e.r32(0, pg + sfpb::C_CPL_STATUS);
      if ((st & 0xF) != 0 && st != 0xDEADBEEF) break;
      if (e.cyc - c0 > maxc) return false;
    }
    uint32_t r0 = e.r32(0, pg + sfpb::C_CPL_REC0), r1 = e.r32(0, pg + sfpb::C_CPL_REC1), r2 = e.r32(0, pg + sfpb::C_CPL_REC2),
             r3 = e.r32(0, pg + sfpb::C_CPL_REC3), r4 = e.r32(0, pg + sfpb::C_CPL_REC4), r5 = e.r32(0, pg + sfpb::C_CPL_REC5), r6 = e.r32(0, pg + sfpb::C_CPL_REC6);
    r.valid = true; r.txn = r0 & 0xFFFF; r.dom = (r0 >> 16) & 0xF; r.status = (r0 >> 24) & 0xF; r.partial = r0 >> 31;
    r.err = r1 & 0xFF; r.detail = (r1 >> 8) & 0xF; r.perr = (r1 >> 16) & 0x3F; r.done = r2; r.total = r3; r.eaddr = ((uint64_t)r5 << 32) | r4; r.lat = r6;
    e.w32(0, pg + sfpb::C_CPL_POP, 1);
    return true;
  }

  // ---- independent reference ------------------------------------------------------------------------------------
  void fill_host(int ctx, uint64_t iova, uint32_t n) { e.hm.fill(bus_of(ctx, iova), n, e.rng); }
  void fill_dev(uint64_t a, uint32_t n) { for (uint32_t i = 0; i < n; i++) e.dev_mem[a - DEV_BASE + i] = (uint8_t)e.rng.u32(); }
  bool dev_equals_host(int ctx, uint64_t dev, uint64_t iova, uint32_t n) {
    for (uint32_t i = 0; i < n; i++) if (e.dev_mem[dev - DEV_BASE + i] != e.hm.rd(bus_of(ctx, iova) + i)) return false;
    return true;
  }
};

}  // namespace env
