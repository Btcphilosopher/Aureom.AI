// Interrupt tests: polling-only mode, MSI request/ack handshake, vector folding, retry / give-up, masking, ordering.
#include "tb_dma_lib.h"
using namespace env;
static Checker C;
struct Test { const char* name; std::function<void(Env&)> fn; };
static void finish(Env& e, const char* what) { e.idle(400); C.ok(e.no_violations(), what, e.n_viol); if (!e.no_violations()) e.print_violations(); }

static void t_poll(Env& e) {
  e.w32(0, sfpb::R_IRQ_CTRL, 0x30);                                    // MSI_EN = 0: polling only
  e.w32(0, sfpb::R_IRQ_MASK, 0xFF);
  e.w32(0, sfpb::R_IRQ_SET, 1 << 5);
  e.idle(200);
  C.ok(e.r32(0, sfpb::R_IRQ_STATUS) == (1u << 5), "status bit is pending for the poller");
  C.ok(e.d->irq_level == 1, "INTx-style level is high");
  C.ok(e.msis.empty(), "no MSI is requested in polling-only mode", e.msis.size());
  C.ok(e.d->msi_int == 0, "msi_int stays low");
  e.w32(0, sfpb::R_IRQ_STATUS, 1 << 5);
  C.ok(e.r32(0, sfpb::R_IRQ_STATUS) == 0, "write-1-to-clear");
  e.idle(10); C.ok(e.d->irq_level == 0, "level drops");
  // masked sources do not signal
  e.w32(0, sfpb::R_IRQ_MASK, 0); e.w32(0, sfpb::R_IRQ_SET, 1 << 6); e.idle(100);
  C.ok(e.r32(0, sfpb::R_IRQ_STATUS) == (1u << 6) && e.d->irq_level == 0, "a masked source sets status but does not raise the level");
  finish(e, "poll: no violations");
}

static void t_msi(Env& e) {
  e.msi_mm = 4;                                                        // 16 vectors enabled
  e.w32(0, sfpb::R_IRQ_MASK, 0xFF);
  e.w32(0, sfpb::R_IRQ_SET, 1 << 5); e.idle(200);
  if (std::getenv("SFPB_TRACE")) { std::printf("   msis:"); for (auto& m : e.msis) std::printf(" (cyc %llu vec %d)", (unsigned long long)m.first, m.second); std::printf("  status=0x%x\n", e.r32(0, sfpb::R_IRQ_STATUS)); }
  C.ok(e.msis.size() == 1 && e.msis[0].second == 5, "source 5 requests MSI vector 5", e.msis.size(), 5);
  C.ok(e.r32(0, sfpb::R_IRQ_SENT_CNT) == 1, "IRQ_SENT_CNT counts the delivery");
  e.w32(0, sfpb::R_IRQ_SET, 1 << 5); e.idle(200);
  C.ok(e.msis.size() == 1, "a source that is still pending does not re-request (coalescing)", e.msis.size());
  e.w32(0, sfpb::R_IRQ_STATUS, 1 << 5); e.w32(0, sfpb::R_IRQ_SET, 1 << 5); e.idle(200);
  C.ok(e.msis.size() == 2 && e.msis[1].second == 5, "after clear, a new event requests again", e.msis.size());
  // custom vector map: move source 6 to vector 12
  e.w32(0, sfpb::R_IRQ_VECMAP, 0x76543210u & ~(0xFu << 24) | (12u << 24)); e.w32(0, sfpb::R_IRQ_SET, 1 << 6); e.idle(200);
  C.ok(e.msis.size() == 3 && e.msis[2].second == 12, "IRQ_VECMAP selects the vector", e.msis.size() ? e.msis.back().second : -1, 12);
  // several sources at once: all delivered, none lost
  e.w32(0, sfpb::R_IRQ_STATUS, 0xFF); e.msis.clear();
  e.w32(0, sfpb::R_IRQ_SET, 0xE0); e.idle(600);
  std::set<int> v; for (auto& m : e.msis) v.insert(m.second);
  C.ok(e.msis.size() == 3 && v.count(5) && v.count(12) && v.count(7), "three simultaneous events -> three distinct vectors", e.msis.size(), 3);
  finish(e, "msi: no violations");
}

static void t_fold(Env& e) {
  e.msi_mm = 1;                                                        // the host enabled only 2 vectors
  e.w32(0, sfpb::R_IRQ_MASK, 0xFF);
  for (int s = 4; s < 8; s++) { e.msis.clear(); e.w32(0, sfpb::R_IRQ_SET, 1u << s); e.idle(200); C.ok(e.msis.size() == 1 && e.msis[0].second == (s & 1), "vector folded into the enabled range", s, e.msis.empty() ? -1 : e.msis[0].second); }
  e.msi_mm = 0; e.msis.clear(); e.w32(0, sfpb::R_IRQ_STATUS, 0xFF); e.w32(0, sfpb::R_IRQ_SET, 1u << 7); e.idle(200);
  C.ok(e.msis.size() == 1 && e.msis[0].second == 0, "single-vector MSI: everything maps to vector 0");
  finish(e, "fold: no violations");
}

static void t_retry(Env& e) {
  e.w32(0, sfpb::R_IRQ_MASK, 0xFF);
  e.msi_fail_inject = 2; e.w32(0, sfpb::R_IRQ_SET, 1 << 5); e.idle(500);
  C.ok(e.msis.size() == 1, "two failures then success: delivered once", e.msis.size());
  C.ok(e.r32(0, sfpb::R_IRQ_FAIL_CNT) == 2, "IRQ_FAIL_CNT counts the failures", e.r32(0, sfpb::R_IRQ_FAIL_CNT));
  // permanent failure: retries are bounded and the give-up is REPORTED
  e.w32(0, sfpb::R_IRQ_STATUS, 0xFF); e.msis.clear(); e.msi_fail_inject = 100;
  e.w32(0, sfpb::R_ERR_LOG_CLR, 1); e.w32(0, sfpb::R_ERR_STATUS, 0xFFFF);
  e.w32(0, sfpb::R_IRQ_SET, 1 << 5); e.idle(1500);
  C.ok(e.msis.empty(), "a permanently failing MSI is never reported as delivered");
  uint32_t l0 = e.r32(0, sfpb::R_ERR_LOG0); C.ok((l0 & 0x100) && (l0 & 0x3F) == 0x3A, "give-up is logged (IRQ_FAIL)", l0);
  C.ok((e.r32(0, sfpb::R_ERR_STATUS) >> 14) & 1, "ERR_STATUS.IRQ_FAIL is set");
  int used = 100 - e.msi_fail_inject; e.idle(4000);
  C.ok(used <= 8 && e.msi_fail_inject == 100 - used, "retries are bounded (<= 4 per request; the error interrupt that reports the failure also fails, 2 x 4 at most) and then stop", used, 8);
  C.ok(((e.r32(0, sfpb::R_IRQ_STATUS)) >> 5) & 1, "the status bit remains for polling");
  finish(e, "retry: no violations");
}

static void t_disabled_by_host(Env& e) {
  e.w32(0, sfpb::R_IRQ_MASK, 0xFF);
  e.msi_en = 0;                                                        // the OS has not enabled MSI in the capability yet
  e.w32(0, sfpb::R_IRQ_SET, 1 << 5); e.idle(300);
  C.ok(e.msis.empty() && e.d->msi_int == 0, "no MSI while the host has MSI disabled");
  e.msi_en = 1; e.idle(300);
  C.ok(e.msis.size() == 1 && e.msis[0].second == 5, "the pending interrupt is delivered once MSI is enabled (not lost)", e.msis.size());
  finish(e, "disabled_by_host: no violations");
}

static void t_ordering(Env& e) {
  // posted DMA data is still in flight (slow link) when an interrupt becomes pending: the MSI must not arrive first
  e.cfg.link_rq = 140; e.cfg.link_msi = 3; e.cfg.link_cc = 3;
  Dma dma(e); dma.setup_defaults();
  e.w32(0, sfpb::R_IRQ_MASK, 0xFF);
  const uint32_t len = 4096; dma.fill_dev(DEV_BASE, len);
  auto s = dma.d2h(0, 0xD00, DEV_BASE, HOST0_IOVA, len); C.ok(s.status() == 1, "accepted", s.status(), s.code());
  C.ok(e.run_until([&]() { return e.rq_accepted >= 6; }, 100000), "posted writes are in flight");
  e.w32(0, sfpb::R_IRQ_SET, 1 << 5);                                   // the 'cause' marker is taken when this write is handshaken
  C.ok(e.run_until([&]() { return !e.msis.empty(); }, 100000), "the interrupt is eventually delivered");
  e.idle(1000);
  e.w32(0, sfpb::R_PERF_SEL, sfpb::PC_ORD_STALL); uint32_t os = e.r32(0, sfpb::R_PERF_LO);
  C.ok(os > 0, "the ordering gate held the MSI behind posted data (not vacuous)", os);
  C.ok(e.no_violations(), "MSI arrived after every earlier posted write", e.n_viol);
  if (!e.no_violations()) e.print_violations();
  CplRec r; dma.wait_record(0, r); C.ok(r.status == 0, "DMA itself completed OK", r.status);
  finish(e, "ordering: no violations");
}

static void t_sources(Env& e) {
  Dma dma(e); dma.setup_defaults();
  e.w32(0, sfpb::R_IRQ_MASK, 0xFF);
  dma.fill_host(0, HOST0_IOVA, 64);
  auto s = dma.h2d(0, 0xE00, HOST0_IOVA, DEV_BASE, 64, 0x3 | 0x10); C.ok(s.status() == 1, "accepted (with StreamDMA IRQ_EN)", s.status(), s.code());
  e.idle(2500);
  std::set<int> v; for (auto& m : e.msis) v.insert(m.second);
  C.ok(v.count(0), "DMA completion record raises source 0 -> vector 0");
  C.ok(v.count(4), "StreamDMA's own irq line raises source 4 -> vector 4");
  uint32_t st = e.r32(0, sfpb::R_IRQ_STATUS); C.ok((st & 0x11) == 0x11, "both are visible in IRQ_STATUS", st);
  CplRec r; dma.wait_record(0, r);
  // a bridge error raises source 2
  e.msis.clear(); e.w32(0, sfpb::R_IRQ_STATUS, 0xFF); e.w32(0, sfpb::R_ERR_STATUS, 0xFFFF);
  e.w32(0, 0x6000, 1);                                                   // BAR0 hole: dropped + logged
  e.idle(500); v.clear(); for (auto& m : e.msis) v.insert(m.second);
  C.ok(v.count(2), "a logged error raises source 2 -> vector 2");
  // DMA error raises source 1
  e.msis.clear(); e.w32(0, sfpb::R_IRQ_STATUS, 0xFF);
  s = dma.h2d(0, 0xE01, HOST0_IOVA + WIN_SIZE + 0x1000, DEV_BASE, 64); C.ok(s.status() == 3, "rejected synchronously", s.status());
  e.idle(300);
  // a failing transfer produces an error record -> source 1
  e.faults = {Fault()}; e.faults[0].kind = Fault::UR; e.faults[0].addr_lo = 0; e.faults[0].addr_hi = ~0ull;
  e.w32(0, sfpb::R_IRQ_STATUS, 0xFF);
  s = dma.h2d(0, 0xE02, HOST0_IOVA, DEV_BASE, 64); C.ok(s.status() == 1, "accepted", s.status(), s.code());
  dma.wait_record(0, r); e.idle(300); e.faults.clear();
  C.ok(r.status == 1, "UR from the host fails the transfer", r.status);
  uint32_t st2 = e.r32(0, sfpb::R_IRQ_STATUS); C.ok((st2 >> 1) & 1, "a failed transfer raises source 1 (DMA_ERR)", st2);
  finish(e, "sources: no violations");
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  std::vector<Test> tests = {{"poll", t_poll}, {"msi", t_msi}, {"fold", t_fold}, {"retry", t_retry}, {"disabled_by_host", t_disabled_by_host},
                             {"ordering", t_ordering}, {"sources", t_sources}};
  const char* only = argc > 1 ? argv[1] : nullptr;
  for (auto& t : tests) {
    if (only && std::strcmp(only, t.name)) continue;
    int f0 = C.fails;
    for (int mode = 0; mode < 2; mode++) {
      Env e(700 + mode * 11 + std::strlen(t.name));
      if (mode == 1) { e.cfg.cq_gap = 20; e.cfg.cc_stall = 30; e.cfg.msi_delay = 15; }
      C.tag = std::string(t.name) + (mode ? "/bp" : "");
      t.fn(e);
    }
    std::printf("  %-18s %s\n", t.name, C.fails == f0 ? "PASS" : "FAIL");
  }
  std::printf("tb_irq DATA_W=%d: %d checks, %d failures\n", DW, C.checks, C.fails);
  return C.fails ? 1 : 0;
}
