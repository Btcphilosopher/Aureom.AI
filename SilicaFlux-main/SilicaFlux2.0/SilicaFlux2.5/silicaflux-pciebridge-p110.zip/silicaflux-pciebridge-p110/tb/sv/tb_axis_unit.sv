// Unit-test wrapper: one unpack and one pack instance with independent ports.
`default_nettype none
module tb_axis_unit #(parameter int DATA_W = 256, parameter int HDR_DW = 4, parameter int USER_W = 8,
                      localparam int K = DATA_W/32, localparam int NW = $clog2(K+1)) (
  input  wire logic clk, input wire logic rst_n, input wire logic flush,
  // unpack
  input  wire logic [DATA_W-1:0] u_tdata, input wire logic [K-1:0] u_tkeep, input wire logic u_tlast,
  input  wire logic [USER_W-1:0] u_tuser, input wire logic u_tvalid, output logic u_tready,
  output logic u_valid, input wire logic u_ready, output logic u_sop, output logic u_eop,
  output logic [DATA_W-1:0] u_data, output logic [NW-1:0] u_ndw, output logic [HDR_DW*32-1:0] u_hdr,
  output logic [USER_W-1:0] u_user, output logic u_bad,
  // pack
  input  wire logic p_valid, output logic p_ready, input wire logic p_sop, input wire logic p_eop,
  input  wire logic [DATA_W-1:0] p_data, input wire logic [NW-1:0] p_ndw, input wire logic [HDR_DW*32-1:0] p_hdr,
  input  wire logic [USER_W-1:0] p_user,
  output logic [DATA_W-1:0] m_tdata, output logic [K-1:0] m_tkeep, output logic m_tlast,
  output logic [USER_W-1:0] m_tuser, output logic m_tvalid, input wire logic m_tready, output logic p_idle
);
  sf_pcie_axis_unpack #(.DATA_W(DATA_W), .HDR_DW(HDR_DW), .USER_W(USER_W)) u_unpack (
    .clk(clk), .rst_n(rst_n), .flush(flush), .s_tdata(u_tdata), .s_tkeep(u_tkeep), .s_tlast(u_tlast), .s_tuser(u_tuser), .s_tbad(1'b0),
    .s_tvalid(u_tvalid), .s_tready(u_tready), .o_valid(u_valid), .o_ready(u_ready), .o_sop(u_sop), .o_eop(u_eop),
    .o_data(u_data), .o_ndw(u_ndw), .o_hdr(u_hdr), .o_user(u_user), .o_bad(u_bad));
  sf_pcie_axis_pack #(.DATA_W(DATA_W), .HDR_DW(HDR_DW), .USER_W(USER_W)) u_pack (
    .clk(clk), .rst_n(rst_n), .flush(flush), .i_valid(p_valid), .i_ready(p_ready), .i_sop(p_sop), .i_eop(p_eop),
    .i_data(p_data), .i_ndw(p_ndw), .i_hdr(p_hdr), .i_user(p_user), .m_tdata(m_tdata), .m_tkeep(m_tkeep),
    .m_tlast(m_tlast), .m_tuser(m_tuser), .m_tvalid(m_tvalid), .m_tready(m_tready), .idle(p_idle));
endmodule
`default_nettype wire
