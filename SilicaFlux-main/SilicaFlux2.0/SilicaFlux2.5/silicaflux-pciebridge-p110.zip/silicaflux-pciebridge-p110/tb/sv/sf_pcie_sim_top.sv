// =============================================================================
// sf_pcie_sim_top -- simulation system for the PCIe transaction bridge (Verilator).
//
//   endpoint stream ports (CQ/CC/RQ/RC, MSI, link/FLR, config)  <-- driven by the C++ transaction-level host + endpoint model
//   sf_pcie_transaction_bridge  <->  SFB2 master port           --> C++ DataFabric model (registers / RAM, errors, hangs)
//          |  h_* host-memory port
//   sf_stream_dma (vendored, unmodified) + sfdma_perm_table (guard stand-in, as in StreamDMA's own bench)
//          |  mtype split: HOST_MTYPE -> bridge, others -> dev_* port --> C++ device-memory model
//
// This is a SIMULATION wrapper, not an integration reference for a real endpoint: no PCIe protocol logic lives here.
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
module sf_pcie_sim_top #(
  parameter int DATA_W     = 256,
  parameter int TAGS       = 16,
  parameter int NCTX       = 4,
  parameter int RD_SLOTS   = 4,
  parameter int WR_SLOTS   = 4,
  parameter int BURST_LEN  = 16,
  parameter int AW         = 48,
  parameter int RQ_ACK_ON_ACCEPT = 0,
  parameter int ORD_TIMEOUT = 4096,
  parameter int TICK_LOG2  = 4,
  parameter int MMIO_MAX_DW = 64,
  parameter int SFB_MAX_OUT = 2,
  parameter int DRAIN_TIMEOUT = 20000,
  localparam int K         = DATA_W / 32,
  localparam int DMA_DW    = 128,
  localparam int DOM_W     = 4,
  localparam int TOT_W     = 31,
  localparam int RIDW      = (RD_SLOTS > 1) ? $clog2(RD_SLOTS) : 1,
  localparam int WIDW      = (WR_SLOTS > 1) ? $clog2(WR_SLOTS) : 1
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // endpoint streams
  input  wire logic [DATA_W-1:0]       s_axis_cq_tdata,
  input  wire logic [K-1:0]            s_axis_cq_tkeep,
  input  wire logic                    s_axis_cq_tlast,
  input  wire logic [84:0]             s_axis_cq_tuser,
  input  wire logic                    s_axis_cq_tvalid,
  output logic                         s_axis_cq_tready,
  output logic [DATA_W-1:0]            m_axis_cc_tdata,
  output logic [K-1:0]                 m_axis_cc_tkeep,
  output logic                         m_axis_cc_tlast,
  output logic [32:0]                  m_axis_cc_tuser,
  output logic                         m_axis_cc_tvalid,
  input  wire logic                    m_axis_cc_tready,
  output logic [DATA_W-1:0]            m_axis_rq_tdata,
  output logic [K-1:0]                 m_axis_rq_tkeep,
  output logic                         m_axis_rq_tlast,
  output logic [61:0]                  m_axis_rq_tuser,
  output logic                         m_axis_rq_tvalid,
  input  wire logic                    m_axis_rq_tready,
  input  wire logic                    rq_seq_vld0,
  input  wire logic                    rq_seq_vld1,
  input  wire logic [DATA_W-1:0]       s_axis_rc_tdata,
  input  wire logic [K-1:0]            s_axis_rc_tkeep,
  input  wire logic                    s_axis_rc_tlast,
  input  wire logic [74:0]             s_axis_rc_tuser,
  input  wire logic                    s_axis_rc_tvalid,
  output logic                         s_axis_rc_tready,
  input  wire logic                    ep_link_up,
  input  wire logic                    ep_flr_in_process,
  output logic                         ep_flr_done,
  input  wire logic [2:0]              cfg_max_payload,
  input  wire logic [2:0]              cfg_max_read_req,
  input  wire logic [15:0]             cfg_req_id,
  input  wire logic                    cfg_check_reqid,
  input  wire logic                    fc_np_ok,
  input  wire logic                    fc_p_ok,
  input  wire logic                    msi_enable,
  input  wire logic [2:0]              msi_mmenable,
  output logic [31:0]                  msi_int,
  input  wire logic                    msi_sent,
  input  wire logic                    msi_fail,
  // DataFabric (SFB2 master)
  output logic                         sfb_req_valid,
  input  wire logic                    sfb_req_ready,
  output logic                         sfb_req_write,
  output logic [31:0]                  sfb_req_addr,
  output logic [31:0]                  sfb_req_wdata,
  output logic [3:0]                   sfb_req_wstrb,
  input  wire logic                    sfb_rsp_valid,
  output logic                         sfb_rsp_ready,
  input  wire logic [31:0]             sfb_rsp_rdata,
  input  wire logic                    sfb_rsp_error,
  // device memory (non-host memory types of StreamDMA)
  output logic                         dev_ar_valid,
  input  wire logic                    dev_ar_ready,
  output logic [RIDW-1:0]              dev_ar_id,
  output logic [AW-1:0]                dev_ar_addr,
  output logic [7:0]                   dev_ar_len,
  input  wire logic                    dev_r_valid,
  output logic                         dev_r_ready,
  input  wire logic [RIDW-1:0]         dev_r_id,
  input  wire logic [DMA_DW-1:0]       dev_r_data,
  input  wire logic [1:0]              dev_r_resp,
  input  wire logic                    dev_r_last,
  output logic                         dev_aw_valid,
  input  wire logic                    dev_aw_ready,
  output logic [WIDW-1:0]              dev_aw_id,
  output logic [AW-1:0]                dev_aw_addr,
  output logic [7:0]                   dev_aw_len,
  output logic                         dev_w_valid,
  input  wire logic                    dev_w_ready,
  output logic [DMA_DW-1:0]            dev_w_data,
  output logic [DMA_DW/8-1:0]          dev_w_strb,
  output logic                         dev_w_last,
  input  wire logic                    dev_b_valid,
  output logic                         dev_b_ready,
  input  wire logic [WIDW-1:0]         dev_b_id,
  input  wire logic [1:0]              dev_b_resp,
  // privileged port
  input  wire logic                    priv_req_valid,
  output logic                         priv_req_ready,
  input  wire logic                    priv_req_write,
  input  wire logic [11:0]             priv_req_addr,
  input  wire logic [31:0]             priv_req_wdata,
  output logic                         priv_rsp_valid,
  input  wire logic                    priv_rsp_ready,
  output logic [31:0]                  priv_rsp_rdata,
  output logic                         priv_rsp_error,
  // guard table (MemoryGuard stand-in) programming + misc
  input  wire logic                    tw_en,
  input  wire logic [3:0]              tw_idx,
  input  wire logic                    tw_valid,
  input  wire logic [DOM_W-1:0]        tw_domain,
  input  wire logic [3:0]              tw_asid,
  input  wire logic [AW-1:0]           tw_base,
  input  wire logic [AW:0]             tw_size,
  input  wire logic [AW-1:0]           tw_pa,
  input  wire logic [1:0]              tw_perm,
  output logic                         tw_rej,
  input  wire logic [2:0]              irq_ext,
  output logic                         irq_level,
  output logic [3:0]                   rec_state,
  output logic                         rec_flush_mmio,
  output logic                         rec_flush_dma,
  output logic                         sd_busy,
  output logic                         sd_fenced,
  output logic                         sd_proto_err,
  output logic                         sd_soft_active,
  // adversarial AXI-style master straight into the bridge's host-memory port (used when x_sel = 1; StreamDMA is then bypassed)
  input  wire logic                    x_sel,
  input  wire logic                    x_ar_valid,
  output logic                         x_ar_ready,
  input  wire logic [RIDW-1:0]         x_ar_id,
  input  wire logic [AW-1:0]           x_ar_addr,
  input  wire logic [7:0]              x_ar_len,
  input  wire logic [2:0]              x_ar_size,
  input  wire logic [1:0]              x_ar_burst,
  input  wire logic [3:0]              x_ar_mtype,
  input  wire logic [DOM_W-1:0]        x_ar_domain,
  output logic                         x_r_valid,
  input  wire logic                    x_r_ready,
  output logic [RIDW-1:0]              x_r_id,
  output logic [DMA_DW-1:0]            x_r_data,
  output logic [1:0]                   x_r_resp,
  output logic                         x_r_last,
  input  wire logic                    x_aw_valid,
  output logic                         x_aw_ready,
  input  wire logic [WIDW-1:0]         x_aw_id,
  input  wire logic [AW-1:0]           x_aw_addr,
  input  wire logic [7:0]              x_aw_len,
  input  wire logic [2:0]              x_aw_size,
  input  wire logic [1:0]              x_aw_burst,
  input  wire logic [3:0]              x_aw_mtype,
  input  wire logic [DOM_W-1:0]        x_aw_domain,
  input  wire logic                    x_w_valid,
  output logic                         x_w_ready,
  input  wire logic [DMA_DW-1:0]       x_w_data,
  input  wire logic [DMA_DW/8-1:0]     x_w_strb,
  input  wire logic                    x_w_last,
  output logic                         x_b_valid,
  input  wire logic                    x_b_ready,
  output logic [WIDW-1:0]              x_b_id,
  output logic [1:0]                   x_b_resp,
  // bench-only probes (hierarchical): let a test see the exact cycle on which a sticky-status clear and an event coincide
  output logic                         dbg_irq_w1c,   // a write-1-to-clear of IRQ_STATUS[5] is performed in this cycle
  output logic                         dbg_err_w1c,   // a write-1-to-clear of ERR_STATUS[9] (DMA_PROT) is performed in this cycle
  output logic                         dbg_err_ev
);
  // ---- bridge ------------------------------------------------------------------------------------------------------
  logic                 dma_desc_valid, dma_desc_ready, dma_cpl_valid, dma_cpl_ready, dma_irq;
  logic [255:0]         dma_desc_data;
  logic [DOM_W-1:0]     dma_desc_domain, dma_cpl_domain;
  logic [15:0]          dma_cpl_txn_id;
  logic [3:0]           dma_cpl_status, dma_cpl_detail;
  logic [7:0]           dma_cpl_err;
  logic [TOT_W-1:0]     dma_cpl_bytes_done, dma_cpl_bytes_total;
  logic [AW-1:0]        dma_cpl_err_addr;
  logic [31:0]          dma_cpl_latency, dma_cfg_timeout;
  logic                 dma_cpl_partial, dma_ctl_abort, dma_ctl_soft_reset, sd_soft_pend;
  logic [15:0]          dma_cfg_type_en;
  logic [5:0]           dma_perf_sel;
  logic [63:0]          dma_perf_data;

  // signals of the splitter (StreamDMA side) -- s_h_*  -- and of the bridge port -- h_* ; x_sel muxes the adversarial master in
  logic                 s_h_ar_valid, s_h_ar_ready, s_h_r_valid, s_h_r_ready, s_h_r_last, s_h_aw_valid, s_h_aw_ready, s_h_w_valid, s_h_w_ready, s_h_w_last;
  logic                 s_h_b_valid, s_h_b_ready;
  logic [RIDW-1:0]      s_h_ar_id, s_h_r_id;
  logic [AW-1:0]        s_h_ar_addr, s_h_aw_addr;
  logic [7:0]           s_h_ar_len, s_h_aw_len;
  logic [2:0]           s_h_ar_size, s_h_aw_size;
  logic [1:0]           s_h_ar_burst, s_h_aw_burst, s_h_r_resp, s_h_b_resp;
  logic [3:0]           s_h_ar_mtype, s_h_aw_mtype;
  logic [DOM_W-1:0]     s_h_ar_domain, s_h_aw_domain;
  logic [DMA_DW-1:0]    s_h_r_data, s_h_w_data;
  logic [WIDW-1:0]      s_h_aw_id, s_h_b_id;
  logic [DMA_DW/8-1:0]  s_h_w_strb;

  logic                 h_ar_valid, h_ar_ready, h_r_valid, h_r_ready, h_r_last, h_aw_valid, h_aw_ready, h_w_valid, h_w_ready, h_w_last;
  logic                 h_b_valid, h_b_ready;
  logic [RIDW-1:0]      h_ar_id, h_r_id;
  logic [AW-1:0]        h_ar_addr, h_aw_addr;
  logic [7:0]           h_ar_len, h_aw_len;
  logic [2:0]           h_ar_size, h_aw_size;
  logic [1:0]           h_ar_burst, h_aw_burst, h_r_resp, h_b_resp;
  logic [3:0]           h_ar_mtype, h_aw_mtype;
  logic [DOM_W-1:0]     h_ar_domain, h_aw_domain;
  logic [DMA_DW-1:0]    h_r_data, h_w_data;
  logic [WIDW-1:0]      h_aw_id, h_b_id;
  logic [DMA_DW/8-1:0]  h_w_strb;

  // bridge port inputs: the splitter or the adversarial master
  assign h_ar_valid = x_sel ? x_ar_valid : s_h_ar_valid;  assign h_ar_id = x_sel ? x_ar_id : s_h_ar_id;
  assign h_ar_addr = x_sel ? x_ar_addr : s_h_ar_addr;      assign h_ar_len = x_sel ? x_ar_len : s_h_ar_len;
  assign h_ar_size = x_sel ? x_ar_size : s_h_ar_size;      assign h_ar_burst = x_sel ? x_ar_burst : s_h_ar_burst;
  assign h_ar_mtype = x_sel ? x_ar_mtype : s_h_ar_mtype;   assign h_ar_domain = x_sel ? x_ar_domain : s_h_ar_domain;
  assign h_r_ready = x_sel ? x_r_ready : s_h_r_ready;
  assign h_aw_valid = x_sel ? x_aw_valid : s_h_aw_valid;  assign h_aw_id = x_sel ? x_aw_id : s_h_aw_id;
  assign h_aw_addr = x_sel ? x_aw_addr : s_h_aw_addr;      assign h_aw_len = x_sel ? x_aw_len : s_h_aw_len;
  assign h_aw_size = x_sel ? x_aw_size : s_h_aw_size;      assign h_aw_burst = x_sel ? x_aw_burst : s_h_aw_burst;
  assign h_aw_mtype = x_sel ? x_aw_mtype : s_h_aw_mtype;   assign h_aw_domain = x_sel ? x_aw_domain : s_h_aw_domain;
  assign h_w_valid = x_sel ? x_w_valid : s_h_w_valid;     assign h_w_data = x_sel ? x_w_data : s_h_w_data;
  assign h_w_strb = x_sel ? x_w_strb : s_h_w_strb;         assign h_w_last = x_sel ? x_w_last : s_h_w_last;
  assign h_b_ready = x_sel ? x_b_ready : s_h_b_ready;
  // bridge port outputs go to both
  assign s_h_ar_ready = h_ar_ready && !x_sel;  assign x_ar_ready = h_ar_ready && x_sel;
  assign s_h_r_valid = h_r_valid && !x_sel;    assign x_r_valid = h_r_valid && x_sel;
  assign s_h_r_id = h_r_id; assign s_h_r_data = h_r_data; assign s_h_r_resp = h_r_resp; assign s_h_r_last = h_r_last;
  assign x_r_id = h_r_id; assign x_r_data = h_r_data; assign x_r_resp = h_r_resp; assign x_r_last = h_r_last;
  assign s_h_aw_ready = h_aw_ready && !x_sel;  assign x_aw_ready = h_aw_ready && x_sel;
  assign s_h_w_ready = h_w_ready && !x_sel;    assign x_w_ready = h_w_ready && x_sel;
  assign s_h_b_valid = h_b_valid && !x_sel;    assign x_b_valid = h_b_valid && x_sel;
  assign s_h_b_id = h_b_id; assign s_h_b_resp = h_b_resp; assign x_b_id = h_b_id; assign x_b_resp = h_b_resp;

  sf_pcie_transaction_bridge #(.DATA_W(DATA_W), .TAGS(TAGS), .NCTX(NCTX), .MMIO_MAX_DW(MMIO_MAX_DW), .SFB_MAX_OUT(SFB_MAX_OUT),
                               .DMA_DW(DMA_DW), .AW(AW), .TOT_W(TOT_W), .RD_SLOTS(RD_SLOTS), .WR_SLOTS(WR_SLOTS), .BURST_LEN(BURST_LEN),
                               .DOM_W(DOM_W), .TICK_LOG2(TICK_LOG2), .ORD_TIMEOUT(ORD_TIMEOUT), .RQ_ACK_ON_ACCEPT(RQ_ACK_ON_ACCEPT),
                               .DRAIN_TIMEOUT(DRAIN_TIMEOUT)) u_bridge (
    .clk(clk), .rst_n(rst_n),
    .s_axis_cq_tdata(s_axis_cq_tdata), .s_axis_cq_tkeep(s_axis_cq_tkeep), .s_axis_cq_tlast(s_axis_cq_tlast),
    .s_axis_cq_tuser(s_axis_cq_tuser), .s_axis_cq_tvalid(s_axis_cq_tvalid), .s_axis_cq_tready(s_axis_cq_tready),
    .m_axis_cc_tdata(m_axis_cc_tdata), .m_axis_cc_tkeep(m_axis_cc_tkeep), .m_axis_cc_tlast(m_axis_cc_tlast),
    .m_axis_cc_tuser(m_axis_cc_tuser), .m_axis_cc_tvalid(m_axis_cc_tvalid), .m_axis_cc_tready(m_axis_cc_tready),
    .m_axis_rq_tdata(m_axis_rq_tdata), .m_axis_rq_tkeep(m_axis_rq_tkeep), .m_axis_rq_tlast(m_axis_rq_tlast),
    .m_axis_rq_tuser(m_axis_rq_tuser), .m_axis_rq_tvalid(m_axis_rq_tvalid), .m_axis_rq_tready(m_axis_rq_tready),
    .rq_seq_num0(6'd0), .rq_seq_vld0(rq_seq_vld0), .rq_seq_num1(6'd0), .rq_seq_vld1(rq_seq_vld1),
    .s_axis_rc_tdata(s_axis_rc_tdata), .s_axis_rc_tkeep(s_axis_rc_tkeep), .s_axis_rc_tlast(s_axis_rc_tlast),
    .s_axis_rc_tuser(s_axis_rc_tuser), .s_axis_rc_tvalid(s_axis_rc_tvalid), .s_axis_rc_tready(s_axis_rc_tready),
    .ep_link_up(ep_link_up), .ep_flr_in_process(ep_flr_in_process), .ep_flr_done(ep_flr_done),
    .cfg_max_payload(cfg_max_payload), .cfg_max_read_req(cfg_max_read_req), .cfg_req_id(cfg_req_id), .cfg_check_reqid(cfg_check_reqid),
    .fc_np_ok(fc_np_ok), .fc_p_ok(fc_p_ok),
    .msi_enable(msi_enable), .msi_mmenable(msi_mmenable), .msi_int(msi_int), .msi_sent(msi_sent), .msi_fail(msi_fail),
    .sfb_req_valid(sfb_req_valid), .sfb_req_ready(sfb_req_ready), .sfb_req_write(sfb_req_write), .sfb_req_addr(sfb_req_addr),
    .sfb_req_wdata(sfb_req_wdata), .sfb_req_wstrb(sfb_req_wstrb), .sfb_rsp_valid(sfb_rsp_valid), .sfb_rsp_ready(sfb_rsp_ready),
    .sfb_rsp_rdata(sfb_rsp_rdata), .sfb_rsp_error(sfb_rsp_error),
    .dma_desc_valid(dma_desc_valid), .dma_desc_ready(dma_desc_ready), .dma_desc_data(dma_desc_data), .dma_desc_domain(dma_desc_domain),
    .dma_cpl_valid(dma_cpl_valid), .dma_cpl_ready(dma_cpl_ready), .dma_cpl_txn_id(dma_cpl_txn_id), .dma_cpl_domain(dma_cpl_domain),
    .dma_cpl_status(dma_cpl_status), .dma_cpl_err(dma_cpl_err), .dma_cpl_detail(dma_cpl_detail), .dma_cpl_bytes_done(dma_cpl_bytes_done),
    .dma_cpl_bytes_total(dma_cpl_bytes_total), .dma_cpl_err_addr(dma_cpl_err_addr), .dma_cpl_latency(dma_cpl_latency),
    .dma_cpl_partial(dma_cpl_partial), .dma_irq(dma_irq), .dma_ctl_abort(dma_ctl_abort), .dma_ctl_soft_reset(dma_ctl_soft_reset),
    .dma_cfg_timeout(dma_cfg_timeout), .dma_cfg_type_en(dma_cfg_type_en), .dma_perf_sel(dma_perf_sel), .dma_perf_data(dma_perf_data),
    .dma_busy(sd_busy), .dma_fenced(sd_fenced), .dma_proto_err(sd_proto_err), .dma_soft_pend(sd_soft_pend), .dma_soft_active(sd_soft_active),
    .h_ar_valid(h_ar_valid), .h_ar_ready(h_ar_ready), .h_ar_id(h_ar_id), .h_ar_addr(h_ar_addr), .h_ar_len(h_ar_len), .h_ar_size(h_ar_size),
    .h_ar_burst(h_ar_burst), .h_ar_mtype(h_ar_mtype), .h_ar_domain(h_ar_domain),
    .h_r_valid(h_r_valid), .h_r_ready(h_r_ready), .h_r_id(h_r_id), .h_r_data(h_r_data), .h_r_resp(h_r_resp), .h_r_last(h_r_last),
    .h_aw_valid(h_aw_valid), .h_aw_ready(h_aw_ready), .h_aw_id(h_aw_id), .h_aw_addr(h_aw_addr), .h_aw_len(h_aw_len), .h_aw_size(h_aw_size),
    .h_aw_burst(h_aw_burst), .h_aw_mtype(h_aw_mtype), .h_aw_domain(h_aw_domain),
    .h_w_valid(h_w_valid), .h_w_ready(h_w_ready), .h_w_data(h_w_data), .h_w_strb(h_w_strb), .h_w_last(h_w_last),
    .h_b_valid(h_b_valid), .h_b_ready(h_b_ready), .h_b_id(h_b_id), .h_b_resp(h_b_resp),
    .priv_req_valid(priv_req_valid), .priv_req_ready(priv_req_ready), .priv_req_write(priv_req_write), .priv_req_addr(priv_req_addr),
    .priv_req_wdata(priv_req_wdata), .priv_rsp_valid(priv_rsp_valid), .priv_rsp_ready(priv_rsp_ready), .priv_rsp_rdata(priv_rsp_rdata),
    .priv_rsp_error(priv_rsp_error),
    .irq_ext(irq_ext), .irq_level(irq_level), .rec_state(rec_state), .rec_flush_mmio(rec_flush_mmio), .rec_flush_dma(rec_flush_dma));

  // ---- guard stand-in (as in StreamDMA's own bench) ----------------------------------------------------------------------
  logic                 gq_valid, gq_ready, gq_write, gq_id, gr_valid, gr_ready, gr_id, gr_ok;
  logic [DOM_W-1:0]     gq_dom;
  logic [3:0]           gq_asid, gr_fault;
  logic [AW-1:0]        gq_addr, gr_pa;
  logic [15:0]          gq_bytes;
  logic [31:0]          rej_count;
  // ---- bench-only collision probes (read the DUT's internals by hierarchical reference; no effect on the design) -------------
  assign dbg_irq_w1c = u_bridge.u_irq.wr_valid && ({u_bridge.u_irq.wr_addr[7:2], 2'b00} == 8'h40) && u_bridge.u_irq.wr_strb[0] && u_bridge.u_irq.wr_data[5];
  assign dbg_err_w1c = u_bridge.u_csr.wr_valid && !u_bridge.u_csr.wr_err && !u_bridge.u_csr.wr_irq &&
                       ({u_bridge.u_csr.wr_addr[11:2], 2'b00} == 12'h01C) && u_bridge.u_csr.wr_strb[1] && u_bridge.u_csr.wr_data[9];
  assign dbg_err_ev  = u_bridge.u_csr.cls_all[9];

  sfdma_perm_table #(.AW(AW), .DOM_W(DOM_W), .IDW(1), .NENT(16), .LAT(2)) u_guard (
    .clk(clk), .rst_n(rst_n),
    .tw_en(tw_en), .tw_idx(tw_idx), .tw_valid(tw_valid), .tw_domain(tw_domain), .tw_asid(tw_asid), .tw_base(tw_base),
    .tw_size(tw_size), .tw_pa(tw_pa), .tw_perm(tw_perm), .tw_rej(tw_rej), .rej_count(rej_count),
    .req_valid(gq_valid), .req_ready(gq_ready), .req_domain(gq_dom), .req_asid(gq_asid), .req_write(gq_write),
    .req_addr(gq_addr), .req_bytes(gq_bytes), .req_id(gq_id),
    .rsp_valid(gr_valid), .rsp_ready(gr_ready), .rsp_id(gr_id), .rsp_ok(gr_ok), .rsp_fault(gr_fault), .rsp_pa(gr_pa));

  // ---- StreamDMA -----------------------------------------------------------------------------------------------------------
  logic                 ar_valid, ar_ready, r_valid, r_ready, r_last, aw_valid, aw_ready, w_valid, w_ready, w_last, b_valid, b_ready;
  logic [RIDW-1:0]      ar_id, r_id;
  logic [AW-1:0]        ar_addr, aw_addr;
  logic [7:0]           ar_len, aw_len;
  logic [2:0]           ar_size, aw_size;
  logic [1:0]           ar_burst, aw_burst, r_resp, b_resp;
  logic [3:0]           ar_mtype, aw_mtype;
  logic [DOM_W-1:0]     ar_domain, aw_domain;
  logic [DMA_DW-1:0]    r_data, w_data;
  logic [WIDW-1:0]      aw_id, b_id;
  logic [DMA_DW/8-1:0]  w_strb;

  sf_stream_dma #(.DATA_WIDTH(DMA_DW), .ADDR_WIDTH(AW), .NUM_CHANNELS(1), .BURST_LENGTH(BURST_LEN), .FIFO_DEPTH(64),
                  .MAX_OUTSTANDING_READS(RD_SLOTS), .MAX_OUTSTANDING_WRITES(WR_SLOTS), .DESCRIPTOR_DEPTH(4), .DOM_W(DOM_W),
                  .MAX_SEG_LOG2(24), .MAX_TXN_LOG2(TOT_W - 1)) u_sd (
    .clk(clk), .rst_n(rst_n), .ctl_abort(dma_ctl_abort), .ctl_soft_reset(dma_ctl_soft_reset), .cfg_timeout(dma_cfg_timeout),
    .cfg_type_en(dma_cfg_type_en),
    .desc_valid(dma_desc_valid), .desc_ready(dma_desc_ready), .desc_data(dma_desc_data), .desc_domain(dma_desc_domain),
    .cpl_valid(dma_cpl_valid), .cpl_ready(dma_cpl_ready), .cpl_txn_id(dma_cpl_txn_id), .cpl_domain(dma_cpl_domain),
    .cpl_status(dma_cpl_status), .cpl_err(dma_cpl_err), .cpl_detail(dma_cpl_detail), .cpl_bytes_done(dma_cpl_bytes_done),
    .cpl_bytes_total(dma_cpl_bytes_total), .cpl_err_addr(dma_cpl_err_addr), .cpl_latency(dma_cpl_latency),
    .cpl_partial(dma_cpl_partial), .irq(dma_irq),
    .guard_req_valid(gq_valid), .guard_req_ready(gq_ready), .guard_req_domain(gq_dom), .guard_req_asid(gq_asid),
    .guard_req_write(gq_write), .guard_req_addr(gq_addr), .guard_req_bytes(gq_bytes), .guard_req_id(gq_id),
    .guard_rsp_valid(gr_valid), .guard_rsp_ready(gr_ready), .guard_rsp_id(gr_id), .guard_rsp_ok(gr_ok),
    .guard_rsp_fault(gr_fault), .guard_rsp_pa(gr_pa),
    .ar_valid(ar_valid), .ar_ready(ar_ready), .ar_id(ar_id), .ar_addr(ar_addr), .ar_len(ar_len), .ar_size(ar_size),
    .ar_burst(ar_burst), .ar_mtype(ar_mtype), .ar_domain(ar_domain),
    .r_valid(r_valid), .r_ready(r_ready), .r_id(r_id), .r_data(r_data), .r_resp(r_resp), .r_last(r_last),
    .aw_valid(aw_valid), .aw_ready(aw_ready), .aw_id(aw_id), .aw_addr(aw_addr), .aw_len(aw_len), .aw_size(aw_size),
    .aw_burst(aw_burst), .aw_mtype(aw_mtype), .aw_domain(aw_domain),
    .w_valid(w_valid), .w_ready(w_ready), .w_data(w_data), .w_strb(w_strb), .w_last(w_last),
    .b_valid(b_valid), .b_ready(b_ready), .b_id(b_id), .b_resp(b_resp),
    .busy(sd_busy), .fenced(sd_fenced), .guard_proto_err(sd_proto_err), .soft_reset_pending(sd_soft_pend), .soft_reset_active(sd_soft_active),
    .perf_clear(1'b0), .perf_sel(dma_perf_sel), .perf_data(dma_perf_data));

  // ---- memory-type splitter ------------------------------------------------------------------------------------------------
  wire ar_host = (ar_mtype == `SFPB_SD_MT_DRAM);
  wire aw_host = (aw_mtype == `SFPB_SD_MT_DRAM);

  assign s_h_ar_valid = ar_valid && ar_host;   assign dev_ar_valid = ar_valid && !ar_host;
  assign ar_ready   = ar_host ? s_h_ar_ready : dev_ar_ready;
  assign s_h_ar_id = ar_id; assign s_h_ar_addr = ar_addr; assign s_h_ar_len = ar_len; assign s_h_ar_size = ar_size; assign s_h_ar_burst = ar_burst;
  assign s_h_ar_mtype = ar_mtype; assign s_h_ar_domain = ar_domain;
  assign dev_ar_id = ar_id; assign dev_ar_addr = ar_addr; assign dev_ar_len = ar_len;

  logic r_pri;                                                   // alternate between the two sources, beat by beat
  wire  r_sel_host = s_h_r_valid && (!dev_r_valid || r_pri);
  assign r_valid = s_h_r_valid || dev_r_valid;
  assign r_id    = r_sel_host ? s_h_r_id   : dev_r_id;
  assign r_data  = r_sel_host ? s_h_r_data : dev_r_data;
  assign r_resp  = r_sel_host ? s_h_r_resp : dev_r_resp;
  assign r_last  = r_sel_host ? s_h_r_last : dev_r_last;
  assign s_h_r_ready   = r_ready && r_sel_host;
  assign dev_r_ready = r_ready && !r_sel_host;

  assign s_h_aw_valid = aw_valid && aw_host;   assign dev_aw_valid = aw_valid && !aw_host;
  assign aw_ready   = aw_host ? s_h_aw_ready : dev_aw_ready;
  assign s_h_aw_id = aw_id; assign s_h_aw_addr = aw_addr; assign s_h_aw_len = aw_len; assign s_h_aw_size = aw_size; assign s_h_aw_burst = aw_burst;
  assign s_h_aw_mtype = aw_mtype; assign s_h_aw_domain = aw_domain;
  assign dev_aw_id = aw_id; assign dev_aw_addr = aw_addr; assign dev_aw_len = aw_len;

  // W routing follows the accepted AW order
  logic [3:0] wr_route; logic [2:0] wr_n;
  wire  aw_fire = aw_valid && aw_ready;
  wire  w_head_v = (wr_n != 3'd0);
  wire  w_head_h = wr_route[0];
  assign s_h_w_valid   = w_valid && w_head_v && w_head_h;
  assign dev_w_valid = w_valid && w_head_v && !w_head_h;
  assign w_ready     = w_head_v && (w_head_h ? s_h_w_ready : dev_w_ready);
  assign s_h_w_data = w_data; assign s_h_w_strb = w_strb; assign s_h_w_last = w_last;
  assign dev_w_data = w_data; assign dev_w_strb = w_strb; assign dev_w_last = w_last;
  wire w_pop = w_valid && w_ready && w_last;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin wr_route <= '0; wr_n <= '0; r_pri <= 1'b0; end
    else if (sd_soft_active) begin wr_route <= '0; wr_n <= '0; end            // the memory fabric is reset with the StreamDMA core (its integration contract)
    else begin
      if (r_valid && r_ready) r_pri <= !r_pri;
      case ({aw_fire, w_pop})
        2'b10: begin wr_route[wr_n[1:0]] <= aw_host; wr_n <= wr_n + 3'd1; end
        2'b01: begin wr_route <= {1'b0, wr_route[3:1]}; wr_n <= wr_n - 3'd1; end
        2'b11: begin wr_route <= {1'b0, wr_route[3:1]}; wr_route[wr_n[1:0] - 2'd1] <= aw_host; end
        default: ;
      endcase
    end
  end

  logic b_pri;
  wire  b_sel_host = s_h_b_valid && (!dev_b_valid || b_pri);
  assign b_valid = s_h_b_valid || dev_b_valid;
  assign b_id    = b_sel_host ? s_h_b_id : dev_b_id;
  assign b_resp  = b_sel_host ? s_h_b_resp : dev_b_resp;
  assign s_h_b_ready   = b_ready && b_sel_host;
  assign dev_b_ready = b_ready && !b_sel_host;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) b_pri <= 1'b0; else if (b_valid && b_ready) b_pri <= !b_pri;
  end

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = &{1'b0, rej_count, 1'b0};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
