# SilicaFlux StreamDMA — Project 103 (revision 2)

A high-throughput, synthesizable, **protected scatter-gather DMA engine** (`sf_stream_dma`): descriptor queue → descriptor validator → MemoryGuard → read request engine →
data buffer → write request engine → completion engine, on an AXI4-style ready/valid memory port with IDs, bursts and explicit byte strobes — **now also verified against the repository's real SRAM subsystem, MemoryMatrix (P101)**, through a new bridge.

**Scope (as briefed: "first one fully verified channel, then parallel outstanding requests"):** one DMA channel (`NUM_CHANNELS` must be 1), one transaction in flight; `MAX_OUTSTANDING_READS/WRITES` parameterised
(initial configuration 1/1, verified up to 8/8), 128-bit initial datapath (32..512 supported).
**Evidence level: RTL simulation + formal on RTL + Yosys synthesis estimates. No FPGA, no silicon, no timing closure; no frequency, power or µm² figure is claimed.** Read `docs/08_LIMITATIONS.md` first.
Delivered as a ZIP; **nothing was committed to git.**

## Deliverables

| Brief | Where |
|---|---|
| `sf_stream_dma.sv` (+ `_descriptor`, `_read`, `_write`, `_queue`, `_perf`) | `rtl/stream_dma/` — plus helpers `_dcheck`, `_plan`, `_buffer`, `_align`, `_cpl`, `_defs.svh`, and the new `_mm_bridge` (file lists: `rtl/filelist.f`, `rtl/filelist_mm.f`) |
| `tests/stream_dma/` | Verilator C++ bench, AXI slave model, monitors, **independent byte-accurate reference model**; `tests/stream_dma/mm/`: MemoryMatrix integration bench + adversarial bridge unit test |
| `formal/stream_dma/` | Yosys / Z3 / Yosys-SAT harnesses and runners |
| `benchmarks/stream_dma/` | workloads, raw counter data (`results.csv`, `mm_results.csv`), analysis (`REPORT.md`, `REPORT_MM.md`) |
| docs | `docs/00_AUDIT … 10_MEMORYMATRIX_INTEGRATION`, `CHANGELOG.md` |
| evidence | `reports/` (regression, integration, formal, formal sensitivity, mutation ×2, lint, synthesis, tools) |
| reused, byte-identical | `third_party/` (35 files, SHA-256 manifest, compared with the repository archives: `scripts/check_vendor.py --repo <root>`) |

## Results (all reproducible with `make all REPO=<repository root>`; every number below is read from `reports/`)

| Item | Result |
|---|---|
| Baseline reproduction | every revision-1 result re-run on a fresh toolchain before any change; all reproduced (CHANGELOG) |
| DMA regression | 7 configurations × 5 seeds = 35 bench runs, **all pass**: 55,265 descriptor streams, 75.5 M simulated cycles, every byte / write count / completion field compared with the reference model, plus per-cycle protocol, protection, stray-access monitors and (new) the `cpl_partial` check (`reports/regression.md`) |
| Mutation testing (DMA core) | **42 / 42** injected RTL bugs detected, 0 survivors (41 from revision 1 + `cpl-partial-registered`; `reports/mutation.md`) |
| Formal | planner and descriptor checker **proved exhaustively**; byte realigner, ring buffer and completion engine **bounded** (BMC); 12 / 12 jobs pass, and 13 / 13 injected bugs are found by their harness (incl. the `cpl_partial` property added in revision 2; `reports/formal.md`, `formal_mutants.md`) |
| Lint | Verilator `-Wall` clean in 13 parameterisations (DMA 9, bridge 4); 19 illegal parameter sets rejected by their intended check (`reports/lint.md`) |
| **MemoryMatrix integration** | 6 matrix configurations × 5 seeds = 30 bench runs, **all pass**; 21,000 descriptor streams / directed cases, 22.2 M simulated cycles (`reports/integration_mm.md`) |
| Bridge adversarial unit test | **PASS**, 175 checks (`reports/unit_bridge.txt`) |
| Bridge mutation | **28 / 28** injected bridge bugs detected (24 by the StreamDMA system bench, 4 only by the adversarial unit test), baseline-gated (`reports/mutation_mm.md`) |
| Throughput, stand-alone (simulation) | 128 KiB copy, 128-bit: **Phase 1** (1 outstanding) 12.8 / 9.1 / 5.3 / 2.6 B/cycle at memory latency 2 / 10 / 30 / 80; **Phase 2** (2–8 outstanding) 15.9 B/cycle = 99 % of the 16 B/cycle datapath peak, matching the bandwidth-delay formula within ~2 %. 64-byte transactions ≈ 1.4 B/cycle (`benchmarks/stream_dma/REPORT.md`) |
| Throughput, against the real MemoryMatrix (simulation) | 1 outstanding (initial configuration) 10.8 B/cycle; **2 outstanding 14.9** (+38 %), 4 outstanding 14.9 (no further gain); 4 banks lose to DMA-internal bank conflicts (14.52 → **15.37** with a one-beat destination skew); 64-byte transactions 1.94 B/cycle, 4 KiB 13.79 (`benchmarks/stream_dma/REPORT_MM.md`) |
| Synthesis (Yosys, no PDK) | `reports/synth.md`, `docs/07_SYNTHESIS.md` |

## What revision 2 found (details: CHANGELOG, docs/00 §0, docs/05 §6)

1. **A real RTL defect in the "verified" DMA**: `cpl_partial` was one cycle stale in the first cycle of a completion record; the old bench never read the flag and the formal harness had no property for it. Fixed; now checked by both benches, by a proved formal property, and by two mutants that catch the old behaviour.
2. **An error in the earlier audit**: MemoryMatrix does exist (P101); the DMA is now integrated with it and benchmarked against it.
3. **Measured, not assumed**: with a real banked SRAM, going from 1 to 2 outstanding bursts is worth +38 %, the 4-bank loss was bank conflicts between the DMA's own streams (a one-beat destination skew removes them), and a deeper matrix queue does nothing — one of my own hypotheses, refuted by the data.
4. **Bench defects found and fixed along the way** (eight, listed in docs/10 §6), and a mutation harness that now refuses to run on a failing baseline after it once "killed" a mutant for the wrong reason.

## What the design guarantees (and where it is checked)

* **Byte accuracy under backpressure and contention:** unaligned source/destination, partial first/last beats with explicit strobes, ≥ 2 outstanding bursts, reordered and interleaved read responses (matched by ID), reordered write responses — and, through the matrix, bank conflicts from other masters.
* **Completion only after the destination accepted the writes:** `status OK` only when every issued write burst was answered `OKAY` and `bytes_done == bytes_total`; checked against the bus itself, **including against the real matrix's write acknowledgements in the cycle each record is accepted** (docs/04, docs/10 §5).
* **Protection:** every AR/AW address is the physical address granted by the MemoryGuard for that burst; the trusted domain is a hardware sideband captured at push, never a descriptor field, and reaches the matrix as `prot.secure` for a second check; descriptors are validated against overflow, range, overlap, flags, versions, chain structure (docs/02, 03, 10).
* **No silent corruption of overlaps:** overlapping copies inside a segment are rejected (no memmove); cross-segment read-after-write / write-after-write are interlocked.
* **Faults, abort, timeout, reset:** error status with partial-completion accounting, drain-then-flush, watchdog + fence, deferred soft reset that cannot leak a stale guard answer, hard-reset cancellation (docs/04).

## Reuse (docs/00_AUDIT.md)

Vendored unchanged: P61 `sfd_fifo`, P64 `sfdma_perm_checker` / `sfdma_perm_table` / `silicaflux_dma_pkg`, **P101 MemoryMatrix (30 files)**. **No module named MemoryGuard exists in the repository**; the MemoryGuard interface is defined here as the verified IOMMU contract of the P64 checker.
SRAMController is superseded by the matrix; MeridianQoS, TensorCore compute RTL, Vector Engine, DataFabric were audited but are **not integrated** (reasons in the audit).

## Quick start

Tools (Ubuntu 24.04 packages): `verilator` 5.020, `yosys` 0.33, `z3` 4.8, `python3`, `g++`, `make` (`reports/tools.txt`).

```bash
python3 scripts/check_vendor.py --repo <repository root>      # vendored files intact and identical to the repository archives
make lint                                                      # lint: DMA, bridge, integration top, 19 negative elaboration tests
bash scripts/build_tb.sh initial && build/tb_initial/tb_initial 1 all      # the initial configuration, stand-alone bench
bash scripts/run_bridge_unit.sh                                # adversarial bridge unit test (real matrix)
python3 scripts/run_mm.py                                      # MemoryMatrix integration: 6 configs x 5 seeds
make regress formal mutate bench synth mutate-mm bench-mm      # full evidence (synth, mutate and mutate-mm are slow)
```

## Known limits (summary of docs/08)

One channel, one transaction in flight (small transactions are slow: 64 B ≈ 1.9 B/cycle on the integrated system); no memmove; no rollback; data buffer is register-file style (an SRAM macro is needed for ASIC; 8.6 k flops in the generic flow);
control logic depth is dominated by the validator (≈ 120 gate levels) — frequency is unknown; the guard, memory and reference model are models written for this project; the bridge has no formal harness; MemoryMatrix reset is global;
platform requirements for isolation are in `docs/09_INTEGRATION.md`.
