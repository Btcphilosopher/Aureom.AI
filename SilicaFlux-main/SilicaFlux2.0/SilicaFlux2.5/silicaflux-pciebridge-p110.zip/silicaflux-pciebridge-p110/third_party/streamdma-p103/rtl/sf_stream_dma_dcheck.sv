// =============================================================================
// StreamDMA :: sf_stream_dma_dcheck -- combinational descriptor validation (first failing rule wins)
// Pure function of {descriptor, trusted domain, transaction context, enabled memory types}.  Proven exhaustively in
// formal/stream_dma/fv_dcheck.sv: err==0  =>  every field is well formed, no address/length overflow, no
// same-type src/dst overlap, domain claim == trusted binding.
// Rule order and codes: docs/02_DESCRIPTOR_ABI.md
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
`include "sf_stream_dma_defs.svh"
module sf_stream_dma_dcheck #(
  parameter int AW           = 40,
  parameter int DOM_W        = 4,
  parameter int MAX_SEG_LOG2 = 24,
  parameter int MAX_TXN_LOG2 = 30
) (
  input  wire logic [255:0]            desc,
  input  wire logic [DOM_W-1:0]        trusted_domain,
  input  wire logic [15:0]             type_en,
  input  wire logic                    in_txn,
  input  wire logic [15:0]             cur_txn_id,
  input  wire logic [DOM_W-1:0]        cur_domain,
  input  wire logic [MAX_TXN_LOG2:0]   cur_total,
  output logic [7:0]                   err
);
  wire [7:0]  version = desc[7:0];
  wire [7:0]  opcode  = desc[15:8];
  /* verilator lint_off UNUSEDSIGNAL */
  wire [15:0] flags   = desc[31:16];
  /* verilator lint_on UNUSEDSIGNAL */
  wire [15:0] txn_id  = desc[47:32];
  wire [15:0] dom_cl  = desc[63:48];
  wire [3:0]  s_type  = desc[67:64];
  wire [3:0]  d_type  = desc[71:68];
  wire [23:0] rsvd0   = desc[95:72];
  wire [31:0] len     = desc[127:96];
  wire [63:0] src     = desc[191:128];
  wire [63:0] dst     = desc[255:192];

  wire f_first = flags[`SFSD_F_FIRST];
  wire f_cpl   = flags[`SFSD_F_CPL_EN];
  wire f_irq   = flags[`SFSD_F_IRQ_EN];

  wire dom_bad   = (dom_cl != 16'(trusted_domain));
  wire flags_bad = (|flags[15:5]) || (!f_first && (f_cpl || f_irq));
  wire rsvd_bad  = (|rsvd0);

  wire first_bad = in_txn ? f_first : !f_first;
  wire txn_bad   = in_txn && (txn_id != cur_txn_id);
  wire dom2_bad  = in_txn && (trusted_domain != cur_domain);

  wire s_type_bad = (s_type > 4'(`SFSD_NUM_MT - 1)) || !type_en[s_type];
  wire d_type_bad = (d_type > 4'(`SFSD_NUM_MT - 1)) || !type_en[d_type];

  wire len_zero = (len == 32'd0);
  wire len_big  = ({1'b0, len} > (33'd1 << MAX_SEG_LOG2));
  wire [MAX_TXN_LOG2+1:0] tot_sum = {1'b0, cur_total} + (MAX_TXN_LOG2+2)'(len);
  wire tot_big  = (tot_sum > ((MAX_TXN_LOG2+2)'(1) << MAX_TXN_LOG2));

  wire [127:0] lim_a    = 128'd1 << AW;
  wire         rng_bad  = ({64'd0, src} >= lim_a) || ({64'd0, dst} >= lim_a);
  wire [127:0] s_end    = {64'd0, src} + {96'd0, len};
  wire [127:0] d_end    = {64'd0, dst} + {96'd0, len};
  wire         ovf_bad  = (s_end > lim_a) || (d_end > lim_a);
  wire         ovl_bad  = (s_type == d_type) && ({64'd0, src} < d_end) && ({64'd0, dst} < s_end);

  always_comb begin
    if      (version != `SFSD_DESC_VERSION) err = `SFSD_ERR_VERSION;
    else if (opcode  != `SFSD_OP_COPY)      err = `SFSD_ERR_OPCODE;
    else if (dom_bad)                       err = `SFSD_ERR_DOMAIN;
    else if (flags_bad)                     err = `SFSD_ERR_FLAGS;
    else if (rsvd_bad)                      err = `SFSD_ERR_RSVD;
    else if (first_bad)                     err = `SFSD_ERR_CHAIN_FIRST;
    else if (txn_bad)                       err = `SFSD_ERR_CHAIN_TXN;
    else if (dom2_bad)                      err = `SFSD_ERR_DOMAIN;
    else if (s_type_bad || d_type_bad)      err = `SFSD_ERR_MEMTYPE;
    else if (len_zero)                      err = `SFSD_ERR_LEN_ZERO;
    else if (len_big)                       err = `SFSD_ERR_LEN_BIG;
    else if (tot_big)                       err = `SFSD_ERR_TOTAL_BIG;
    else if (rng_bad)                       err = `SFSD_ERR_ADDR_RANGE;
    else if (ovf_bad)                       err = `SFSD_ERR_ADDR_OVFL;
    else if (ovl_bad)                       err = `SFSD_ERR_OVERLAP;
    else                                    err = `SFSD_ERR_NONE;
  end
endmodule
`default_nettype wire
