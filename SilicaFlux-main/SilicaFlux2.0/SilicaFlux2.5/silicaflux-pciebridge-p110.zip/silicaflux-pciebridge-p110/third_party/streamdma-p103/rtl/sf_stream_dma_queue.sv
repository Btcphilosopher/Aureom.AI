// =============================================================================
// StreamDMA :: sf_stream_dma_queue -- descriptor queue (DESCRIPTOR_DEPTH entries, ready/valid both sides)
// Each entry stores the 256-bit descriptor TOGETHER WITH the trusted-domain sideband that accompanied it at push time,
// so the domain binding is captured when the descriptor is accepted and cannot be altered afterwards.
// Reuse: storage is the vendored, repository-verified `sfd_fifo` (CloudDPU P61), unchanged.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stream_dma_queue #(
  parameter int DEPTH = 4,
  parameter int DOM_W = 4,
  localparam int LW   = $clog2(DEPTH + 1)
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic               flush,
  // push side (control plane)
  input  wire logic               push_valid,
  output logic                    push_ready,
  input  wire logic [255:0]       push_desc,
  input  wire logic [DOM_W-1:0]   push_domain,        // TRUSTED binding supplied by the hardware path, not by software
  // pop side (validator)
  output logic                    pop_valid,
  input  wire logic               pop_ready,
  output logic [255:0]            pop_desc,
  output logic [DOM_W-1:0]        pop_domain,
  output logic [LW-1:0]           level
);
  sfd_fifo #(.WIDTH(256 + DOM_W), .DEPTH(DEPTH)) u_fifo (
    .clk(clk), .rst_n(rst_n), .flush(flush),
    .in_valid(push_valid), .in_ready(push_ready), .in_data({push_domain, push_desc}),
    .out_valid(pop_valid), .out_ready(pop_ready), .out_data({pop_domain, pop_desc}),
    .level(level)
  );
endmodule
`default_nettype wire
