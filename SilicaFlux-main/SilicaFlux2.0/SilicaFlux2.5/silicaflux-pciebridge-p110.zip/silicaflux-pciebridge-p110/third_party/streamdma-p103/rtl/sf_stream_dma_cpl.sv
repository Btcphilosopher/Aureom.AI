// =============================================================================
// StreamDMA :: sf_stream_dma_cpl -- completion engine, error/abort sequencing, watchdog
//
// One transaction is active at a time.  States:
//   IDLE   no transaction.                       start_evt (validator admitted FIRST / an error marker) -> RUN
//   RUN    executing.  Completion contract: the transaction completes OK only when the end of the transaction was
//          reached, EVERY issued write burst has been answered OKAY (writes quiet), the read side is quiet and
//          acked_bytes == bytes_total.  Anything else is an error.
//          first fault / ctl_abort -> DRAIN;  watchdog -> CPL(TIMEOUT, fenced)
//   DRAIN  kill=1: engines start nothing new; wait until every request already on the bus was answered
//          (rd_quiet && wr_drained), then flush the data path -> CPL.  (watchdog also runs here)
//   CPL    present the completion record (held until cpl_ready); then txn_done -> IDLE
//   FENCED after a timeout the bus is presumed hung: kill stays 1 forever, nothing is flushed, no txn_done;
//          only ctl_soft_reset (core reset) restores the channel.
// A completion record is pushed on error ALWAYS; on success only when CPL_EN was set.  irq pulses if IRQ_EN or on error.
// bytes_done = destination bytes acknowledged OKAY (no rollback of bytes already written: partial completion).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
`include "sf_stream_dma_defs.svh"
module sf_stream_dma_cpl #(
  parameter int AW           = 40,
  parameter int DOM_W        = 4,
  parameter int MAX_TXN_LOG2 = 30,
  localparam int TOT_W       = MAX_TXN_LOG2 + 1
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic [31:0]        cfg_timeout,        // cycles without progress while the bus owes work; 0 = disabled
  input  wire logic               ctl_abort,
  // from validator
  input  wire logic               start_evt,
  input  wire logic [15:0]        start_txn_id,
  input  wire logic [DOM_W-1:0]   start_domain,
  input  wire logic               start_cpl_en,
  input  wire logic               start_irq_en,
  input  wire logic [TOT_W-1:0]   val_total,
  // from the data path
  input  wire logic               end_ok_evt,
  input  wire logic [TOT_W-1:0]   end_total,
  input  wire logic               end_err_evt,
  input  wire logic [7:0]         end_err_code,
  input  wire logic               fault_evt,
  input  wire logic [7:0]         fault_code,
  input  wire logic [3:0]         fault_detail,
  input  wire logic [AW-1:0]      fault_addr,
  input  wire logic               rd_quiet,
  input  wire logic               wr_quiet,
  input  wire logic               wr_drained,
  input  wire logic [TOT_W-1:0]   acked_bytes,
  input  wire logic               progress,
  // control out
  output logic                    kill,
  output logic                    flush,
  output logic                    txn_done,
  output logic                    fenced,
  output logic                    txn_active,
  // completion port
  output logic                    cpl_valid,
  input  wire logic               cpl_ready,
  output logic [15:0]             cpl_txn_id,
  output logic [DOM_W-1:0]        cpl_domain,
  output logic [3:0]              cpl_status,
  output logic [7:0]              cpl_err,
  output logic [3:0]              cpl_detail,
  output logic [TOT_W-1:0]        cpl_bytes_done,
  output logic [TOT_W-1:0]        cpl_bytes_total,
  output logic [AW-1:0]           cpl_err_addr,
  output logic [31:0]             cpl_latency,
  output logic                    cpl_partial,
  output logic                    irq,
  // events
  output logic                    ev_txn_done,
  output logic                    ev_txn_err,
  output logic [31:0]             ev_latency,
  output logic                    ev_timeout
);
  localparam logic [2:0] ST_IDLE = 3'd0, ST_RUN = 3'd1, ST_DRAIN = 3'd2, ST_CPL = 3'd3, ST_FENCED = 3'd4;
  logic [2:0]        st;
  logic              end_seen, end_is_err, t_cpl, t_irq, rec_en;
  logic [7:0]        end_code;
  logic [31:0]       now, t0, wd;
  logic              fenced_q;

  assign kill       = (st == ST_DRAIN) || fenced_q || flush;   // flush is a registered pulse: nothing may start in its cycle
  assign fenced     = fenced_q;
  assign txn_active = (st != ST_IDLE);

  wire watch   = (st == ST_RUN || st == ST_DRAIN) && !(rd_quiet && wr_drained);
  wire wd_hit  = watch && (cfg_timeout != 32'd0) && (wd >= cfg_timeout);

  wire ok_ready = (st == ST_RUN) && end_seen && wr_quiet && rd_quiet;
  wire sum_ok   = end_is_err || (acked_bytes == end_total);
  wire [31:0] lat_now = now - t0;

  assign cpl_valid = (st == ST_CPL) && rec_en;
  // partial = bytes were acknowledged but the transaction did not end OK.  A pure function of the record, so it is correct in the FIRST cycle the
  // record is presented (an earlier revision registered it, one cycle behind the record: an immediately accepted record carried a stale flag).
  assign cpl_partial = (cpl_bytes_done != '0) && (cpl_status != `SFSD_ST_OK);
  wire   cpl_fin   = (st == ST_CPL) && (!rec_en || cpl_ready);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= ST_IDLE; end_seen <= 1'b0; end_is_err <= 1'b0; end_code <= '0; t_cpl <= 1'b0; t_irq <= 1'b0; rec_en <= 1'b0;
      now <= '0; t0 <= '0; wd <= '0; fenced_q <= 1'b0;
      flush <= 1'b0; txn_done <= 1'b0; irq <= 1'b0; ev_txn_done <= 1'b0; ev_txn_err <= 1'b0; ev_latency <= '0; ev_timeout <= 1'b0;
      cpl_txn_id <= '0; cpl_domain <= '0; cpl_status <= '0; cpl_err <= '0; cpl_detail <= '0;
      cpl_bytes_done <= '0; cpl_bytes_total <= '0; cpl_err_addr <= '0; cpl_latency <= '0;
    end else begin
      now <= now + 32'd1;
      flush <= 1'b0; txn_done <= 1'b0; irq <= 1'b0; ev_txn_done <= 1'b0; ev_txn_err <= 1'b0; ev_timeout <= 1'b0;
      if (progress || !watch) wd <= '0; else wd <= wd + 32'd1;

      case (st)
        ST_IDLE: if (start_evt) begin
          st <= ST_RUN; end_seen <= 1'b0; end_is_err <= 1'b0; end_code <= '0;
          cpl_txn_id <= start_txn_id; cpl_domain <= start_domain; t_cpl <= start_cpl_en; t_irq <= start_irq_en;
          t0 <= now; cpl_status <= `SFSD_ST_OK; cpl_err <= `SFSD_ERR_NONE; cpl_detail <= '0; cpl_err_addr <= '0;
          cpl_bytes_done <= '0; cpl_bytes_total <= '0; cpl_latency <= '0;
        end
        ST_RUN: begin
          if (end_ok_evt)  end_seen <= 1'b1;
          if (end_err_evt) begin end_seen <= 1'b1; end_is_err <= 1'b1; end_code <= end_err_code; end
          if (wd_hit) begin
            st <= ST_CPL; fenced_q <= 1'b1; ev_timeout <= 1'b1; rec_en <= 1'b1;
            cpl_status <= `SFSD_ST_TIMEOUT; cpl_detail <= '0; cpl_err <= `SFSD_ERR_TIMEOUT;
            cpl_bytes_done <= acked_bytes; cpl_bytes_total <= val_total; cpl_latency <= lat_now; ev_latency <= lat_now;
          end else if (ctl_abort) begin
            st <= ST_DRAIN; cpl_status <= `SFSD_ST_ABORTED; cpl_err <= `SFSD_ERR_ABORT; cpl_detail <= '0; cpl_err_addr <= '0;
          end else if (fault_evt) begin
            st <= ST_DRAIN; cpl_status <= `SFSD_ST_ERROR; cpl_err <= fault_code; cpl_detail <= fault_detail; cpl_err_addr <= fault_addr;
          end else if (ok_ready) begin
            st <= ST_CPL; flush <= 1'b1; rec_en <= t_cpl;
            cpl_bytes_done <= acked_bytes; cpl_latency <= lat_now; ev_latency <= lat_now;
            if (end_is_err) begin
              cpl_status <= `SFSD_ST_ERROR; cpl_err <= end_code; cpl_bytes_total <= val_total; rec_en <= 1'b1;
            end else if (!sum_ok) begin
              cpl_status <= `SFSD_ST_ERROR; cpl_err <= `SFSD_ERR_INTERNAL; cpl_bytes_total <= end_total; rec_en <= 1'b1;
            end else begin
              cpl_bytes_total <= end_total;
            end
          end
        end
        ST_DRAIN: begin
          if (wd_hit) begin
            st <= ST_CPL; fenced_q <= 1'b1; ev_timeout <= 1'b1; rec_en <= 1'b1;
            cpl_detail <= cpl_err[3:0]; cpl_status <= `SFSD_ST_TIMEOUT; cpl_err <= `SFSD_ERR_TIMEOUT;
            cpl_bytes_done <= acked_bytes; cpl_bytes_total <= val_total; cpl_latency <= lat_now; ev_latency <= lat_now;
          end else if (rd_quiet && wr_drained) begin
            st <= ST_CPL; flush <= 1'b1; rec_en <= 1'b1;
            cpl_bytes_done <= acked_bytes; cpl_bytes_total <= val_total; cpl_latency <= lat_now; ev_latency <= lat_now;
          end
        end
        ST_CPL: if (cpl_fin) begin
          irq <= t_irq || (cpl_status != `SFSD_ST_OK);
          ev_txn_done <= 1'b1; ev_txn_err <= (cpl_status != `SFSD_ST_OK);
          if (fenced_q) st <= ST_FENCED;
          else begin st <= ST_IDLE; txn_done <= 1'b1; end
        end
        default: ;
      endcase
    end
  end
endmodule
`default_nettype wire
