// =============================================================================
// SilicaFlux StreamDMA (Project 103) :: sf_stream_dma -- high-bandwidth, protected scatter-gather DMA engine (top)
//
//   desc push -> Descriptor Queue -> Descriptor Validator -> segment FIFOs -+-> Read Request Engine -> Data Buffer
//                                                                           |        (MemoryGuard read)      |
//                                                                           +-> Write Request Engine <--------+
//                                                                                    (MemoryGuard write)
//                                                          Completion Engine <-- all events ---+
//   MemoryGuard : every AR and AW address is the PHYSICAL address granted by the guard for that very burst
//                 (vendored CloudDMA permission checker; the guard itself is outside, behind guard_req/rsp)
//   Memory port : AXI4-style master, ready/valid on AR/R/AW/W/B, IDs, INCR bursts, full-width beats, explicit W strobes
// Scope of this release: ONE channel (NUM_CHANNELS must be 1), ONE transaction in flight; memory-level parallelism
// (MAX_OUTSTANDING_READS/WRITES) is a parameter.  See docs/.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
`include "sf_stream_dma_defs.svh"
module sf_stream_dma #(
  parameter int DATA_WIDTH            = 128,
  parameter int ADDR_WIDTH            = 40,
  parameter int NUM_CHANNELS          = 1,
  parameter int BURST_LENGTH          = 16,
  parameter int FIFO_DEPTH            = 64,     // data buffer, beats, power of two
  parameter int MAX_OUTSTANDING_READS = 1,
  parameter int MAX_OUTSTANDING_WRITES= 1,
  parameter int DESCRIPTOR_DEPTH      = 4,
  parameter int DOM_W                 = 4,
  parameter int SEG_DEPTH             = 2,
  parameter int PLAN_DEPTH            = 2,      // burst look-ahead (guard/AR/AW queues)
  parameter int WR_FIFO_DEPTH         = 2 * BURST_LENGTH,
  parameter int GUARD_OUT             = 2,      // requests in flight at the guard (<= 2 clients)
  parameter int MAX_SEG_LOG2          = 24,
  parameter int MAX_TXN_LOG2          = 30,
  parameter int CNT_W                 = 48,
  localparam int W                    = DATA_WIDTH / 8,
  localparam int AW                   = ADDR_WIDTH,
  localparam int RIDW                 = (MAX_OUTSTANDING_READS  > 1) ? $clog2(MAX_OUTSTANDING_READS)  : 1,
  localparam int WIDW                 = (MAX_OUTSTANDING_WRITES > 1) ? $clog2(MAX_OUTSTANDING_WRITES) : 1,
  localparam int TOT_W                = MAX_TXN_LOG2 + 1,
  localparam int SEG_W                = MAX_SEG_LOG2 + 1
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // ---- control / configuration
  input  wire logic                    ctl_abort,          // pulse: cancel the active transaction (completes ABORTED)
  input  wire logic                    ctl_soft_reset,     // pulse: reset the whole core (not the perf counters); clears a fence
  input  wire logic [31:0]             cfg_timeout,        // watchdog, cycles without progress while the bus owes work; 0 = off
  input  wire logic [15:0]             cfg_type_en,        // enabled memory types (bit per SFSD_MT_*)
  // ---- descriptor push (control plane)
  input  wire logic                    desc_valid,
  output logic                         desc_ready,
  input  wire logic [255:0]            desc_data,
  input  wire logic [DOM_W-1:0]        desc_domain,        // TRUSTED domain binding from the hardware path
  // ---- completion port
  output logic                         cpl_valid,
  input  wire logic                    cpl_ready,
  output logic [15:0]                  cpl_txn_id,
  output logic [DOM_W-1:0]             cpl_domain,
  output logic [3:0]                   cpl_status,
  output logic [7:0]                   cpl_err,
  output logic [3:0]                   cpl_detail,
  output logic [TOT_W-1:0]             cpl_bytes_done,
  output logic [TOT_W-1:0]             cpl_bytes_total,
  output logic [AW-1:0]                cpl_err_addr,
  output logic [31:0]                  cpl_latency,
  output logic                         cpl_partial,
  output logic                         irq,
  // ---- MemoryGuard (IOMMU contract of the vendored checker/table)
  output logic                         guard_req_valid,
  input  wire logic                    guard_req_ready,
  output logic [DOM_W-1:0]             guard_req_domain,
  output logic [3:0]                   guard_req_asid,
  output logic                         guard_req_write,
  output logic [AW-1:0]                guard_req_addr,
  output logic [15:0]                  guard_req_bytes,
  output logic                         guard_req_id,
  input  wire logic                    guard_rsp_valid,
  output logic                         guard_rsp_ready,
  input  wire logic                    guard_rsp_id,
  input  wire logic                    guard_rsp_ok,
  input  wire logic [3:0]              guard_rsp_fault,
  input  wire logic [AW-1:0]           guard_rsp_pa,
  // ---- memory port: read address / data
  output logic                         ar_valid,
  input  wire logic                    ar_ready,
  output logic [RIDW-1:0]              ar_id,
  output logic [AW-1:0]                ar_addr,
  output logic [7:0]                   ar_len,             // beats - 1
  output logic [2:0]                   ar_size,            // log2(bytes per beat), always full width
  output logic [1:0]                   ar_burst,           // INCR
  output logic [3:0]                   ar_mtype,           // memory type sideband
  output logic [DOM_W-1:0]             ar_domain,          // trusted domain sideband (second, independent check point)
  input  wire logic                    r_valid,
  output logic                         r_ready,
  input  wire logic [RIDW-1:0]         r_id,
  input  wire logic [DATA_WIDTH-1:0]   r_data,
  input  wire logic [1:0]              r_resp,
  input  wire logic                    r_last,
  // ---- memory port: write address / data / response
  output logic                         aw_valid,
  input  wire logic                    aw_ready,
  output logic [WIDW-1:0]              aw_id,
  output logic [AW-1:0]                aw_addr,
  output logic [7:0]                   aw_len,
  output logic [2:0]                   aw_size,
  output logic [1:0]                   aw_burst,
  output logic [3:0]                   aw_mtype,
  output logic [DOM_W-1:0]             aw_domain,
  output logic                         w_valid,
  input  wire logic                    w_ready,
  output logic [DATA_WIDTH-1:0]        w_data,
  output logic [W-1:0]                 w_strb,
  output logic                         w_last,
  input  wire logic                    b_valid,
  output logic                         b_ready,
  input  wire logic [WIDW-1:0]         b_id,
  input  wire logic [1:0]              b_resp,
  // ---- status
  output logic                         busy,
  output logic                         fenced,
  output logic                         guard_proto_err,
  output logic                         soft_reset_pending, // ctl_soft_reset seen, waiting for the MemoryGuard to go quiet
  output logic                         soft_reset_active,  // the core is being reset in this cycle: reset the memory fabric NOW too
  // ---- performance counters
  input  wire logic                    perf_clear,
  input  wire logic [5:0]              perf_sel,
  output logic [63:0]                  perf_data
);
  // ------------------------------------------------------------------ static configuration checks
  generate
    if (NUM_CHANNELS != 1) begin : g_chk_nch
      NUM_CHANNELS_must_be_1_in_this_release u_err ();
    end
    if (DATA_WIDTH < 32 || DATA_WIDTH > 512 || (DATA_WIDTH & (DATA_WIDTH - 1)) != 0) begin : g_chk_dw
      DATA_WIDTH_must_be_a_power_of_two_in_32_512 u_err ();
    end
    if (BURST_LENGTH < 1 || BURST_LENGTH > 256 || BURST_LENGTH * W > 4096) begin : g_chk_bl
      BURST_LENGTH_must_be_1_256_and_BURST_LENGTH_x_bytes_per_beat_le_4096 u_err ();
    end
    if ((FIFO_DEPTH & (FIFO_DEPTH - 1)) != 0 || FIFO_DEPTH < BURST_LENGTH) begin : g_chk_fd
      FIFO_DEPTH_must_be_a_power_of_two_ge_BURST_LENGTH u_err ();
    end
    if (WR_FIFO_DEPTH < BURST_LENGTH) begin : g_chk_wfd
      WR_FIFO_DEPTH_must_be_ge_BURST_LENGTH u_err ();
    end
    if (ADDR_WIDTH < 16 || ADDR_WIDTH > 64) begin : g_chk_aw
      ADDR_WIDTH_must_be_16_64 u_err ();
    end
    if (MAX_OUTSTANDING_READS < 1 || MAX_OUTSTANDING_WRITES < 1 || DESCRIPTOR_DEPTH < 1 || SEG_DEPTH < 1 || PLAN_DEPTH < 1) begin : g_chk_n
      depth_and_outstanding_parameters_must_be_ge_1 u_err ();
    end
    if (DOM_W < 1 || DOM_W > 16) begin : g_chk_dom
      DOM_W_must_be_1_16 u_err ();
    end
  endgenerate

  // ------------------------------------------------------------------ soft reset
  // ctl_soft_reset is DEFERRED until the MemoryGuard has nothing in flight for this DMA: a guard response that outlived the
  // reset could otherwise be matched to a later request and hand it somebody else's physical address.  While the reset is
  // pending, no new work starts (kill_i).  If the guard never answers an accepted request only rst_n clears the condition.
  // The reset itself is a registered pulse (glitch free) on top of rst_n; perf counters are not affected.
  logic [7:0] g_infl;
  logic       soft_pend, soft_q;
  wire g_req_hs = guard_req_valid && guard_req_ready;
  wire g_rsp_hs = guard_rsp_valid && guard_rsp_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      g_infl <= 8'd0; soft_pend <= 1'b0; soft_q <= 1'b0;
    end else begin
      g_infl <= g_infl + {7'd0, g_req_hs} - {7'd0, g_rsp_hs};
      soft_q <= 1'b0;
      if (ctl_soft_reset) soft_pend <= 1'b1;
      if (soft_pend && g_infl == 8'd0 && !guard_req_valid) begin soft_q <= 1'b1; soft_pend <= 1'b0; end
    end
  end
  wire rstc_n = rst_n & ~soft_q;
  assign soft_reset_pending = soft_pend;
  assign soft_reset_active  = soft_q;

  // ------------------------------------------------------------------ control wires from the completion engine
  logic kill_c, flush, txn_done;
  wire  kill = kill_c || soft_pend;

  // ------------------------------------------------------------------ descriptor queue + validator
  logic          q_valid, q_ready;
  logic [255:0]  q_desc;
  logic [DOM_W-1:0] q_dom;
  logic [$clog2(DESCRIPTOR_DEPTH+1)-1:0] q_level;
  sf_stream_dma_queue #(.DEPTH(DESCRIPTOR_DEPTH), .DOM_W(DOM_W)) u_queue (
    .clk(clk), .rst_n(rstc_n), .flush(1'b0),
    .push_valid(desc_valid), .push_ready(desc_ready), .push_desc(desc_data), .push_domain(desc_domain),
    .pop_valid(q_valid), .pop_ready(q_ready), .pop_desc(q_desc), .pop_domain(q_dom), .level(q_level));

  logic              v_seg_valid, v_seg_ready;
  logic [AW-1:0]     v_src, v_dst;
  logic [SEG_W-1:0]  v_len;
  logic [3:0]        v_stype, v_dtype;
  logic              v_first, v_last, v_fence, v_cpl_en, v_irq_en;
  logic [15:0]       v_txn_id;
  logic [DOM_W-1:0]  v_domain;
  logic [TOT_W-1:0]  v_start_off, v_total, val_total;
  logic [7:0]        v_err;
  logic              start_evt, start_cpl, start_irq, v_busy, v_in_txn;
  logic [15:0]       start_id;
  logic [DOM_W-1:0]  start_dom;
  logic              ev_desc_ok, ev_desc_rej, ev_desc_drop;
  sf_stream_dma_descriptor #(.AW(AW), .DOM_W(DOM_W), .MAX_SEG_LOG2(MAX_SEG_LOG2), .MAX_TXN_LOG2(MAX_TXN_LOG2)) u_desc (
    .clk(clk), .rst_n(rstc_n), .type_en(cfg_type_en),
    .q_valid(q_valid), .q_ready(q_ready), .q_desc(q_desc), .q_domain(q_dom),
    .seg_valid(v_seg_valid), .seg_ready(v_seg_ready), .seg_src(v_src), .seg_dst(v_dst), .seg_len(v_len),
    .seg_stype(v_stype), .seg_dtype(v_dtype), .seg_first(v_first), .seg_last(v_last), .seg_fence(v_fence),
    .seg_cpl_en(v_cpl_en), .seg_irq_en(v_irq_en), .seg_txn_id(v_txn_id), .seg_domain(v_domain),
    .seg_start_off(v_start_off), .seg_total(v_total), .seg_err(v_err),
    .txn_done(txn_done), .kill(kill),
    .txn_start_evt(start_evt), .start_txn_id(start_id), .start_domain(start_dom), .start_cpl_en(start_cpl), .start_irq_en(start_irq),
    .val_total(val_total), .busy(v_busy), .in_txn_o(v_in_txn),
    .ev_desc_ok(ev_desc_ok), .ev_desc_rej(ev_desc_rej), .ev_desc_drop(ev_desc_drop));

  // ------------------------------------------------------------------ segment FIFOs (one per engine)
  localparam int RSW = 1 + AW + AW + SEG_W + 4 + 4 + 1 + TOT_W + DOM_W;
  localparam int WSW = 1 + 8 + AW + SEG_W + 4 + 1 + DOM_W + TOT_W;
  logic          rs_in_ready, ws_in_ready, rs_out_valid, ws_out_valid, rs_out_ready, ws_out_ready;
  logic [RSW-1:0] rs_in, rs_out;
  logic [WSW-1:0] ws_in, ws_out;
  assign rs_in = {(v_err != 8'd0), v_src, v_dst, v_len, v_stype, v_dtype, v_fence, v_start_off, v_domain};
  assign ws_in = {(v_err != 8'd0), v_err, v_dst, v_len, v_dtype, v_last, v_domain, v_total};
  assign v_seg_ready = rs_in_ready && ws_in_ready;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(SEG_DEPTH+1)-1:0] rs_level, ws_level;
  /* verilator lint_on UNUSEDSIGNAL */
  sfd_fifo #(.WIDTH(RSW), .DEPTH(SEG_DEPTH)) u_rseg (
    .clk(clk), .rst_n(rstc_n), .flush(flush),
    .in_valid(v_seg_valid && ws_in_ready), .in_ready(rs_in_ready), .in_data(rs_in),
    .out_valid(rs_out_valid), .out_ready(rs_out_ready), .out_data(rs_out), .level(rs_level));
  sfd_fifo #(.WIDTH(WSW), .DEPTH(SEG_DEPTH)) u_wseg (
    .clk(clk), .rst_n(rstc_n), .flush(flush),
    .in_valid(v_seg_valid && rs_in_ready), .in_ready(ws_in_ready), .in_data(ws_in),
    .out_valid(ws_out_valid), .out_ready(ws_out_ready), .out_data(ws_out), .level(ws_level));

  wire                 r_marker = rs_out[RSW-1];
  wire [AW-1:0]        r_src    = rs_out[RSW-2 -: AW];
  wire [AW-1:0]        r_dst    = rs_out[RSW-2-AW -: AW];
  wire [SEG_W-1:0]     r_len    = rs_out[RSW-2-2*AW -: SEG_W];
  wire [3:0]           r_stype  = rs_out[RSW-2-2*AW-SEG_W -: 4];
  wire [3:0]           r_dtype  = rs_out[RSW-2-2*AW-SEG_W-4 -: 4];
  wire                 r_fence  = rs_out[RSW-2-2*AW-SEG_W-8];
  wire [TOT_W-1:0]     r_start  = rs_out[DOM_W +: TOT_W];
  wire [DOM_W-1:0]     r_dom    = rs_out[DOM_W-1:0];

  wire                 w_marker = ws_out[WSW-1];
  wire [7:0]           w_err    = ws_out[WSW-2 -: 8];
  wire [AW-1:0]        w_dst    = ws_out[WSW-10 -: AW];
  wire [SEG_W-1:0]     w_len    = ws_out[WSW-10-AW -: SEG_W];
  wire [3:0]           w_dtype  = ws_out[WSW-10-AW-SEG_W -: 4];
  wire                 w_last_s = ws_out[WSW-10-AW-SEG_W-4];
  wire [DOM_W-1:0]     w_dom    = ws_out[TOT_W +: DOM_W];
  wire [TOT_W-1:0]     w_total  = ws_out[TOT_W-1:0];

  // ------------------------------------------------------------------ data buffer
  localparam int IW = $clog2(FIFO_DEPTH);
  localparam int LW = $clog2(W);
  localparam int CW = $clog2(FIFO_DEPTH + 1);
  logic              rsv_valid, rsv_ok, fill_valid, head_valid, head_pop, buf_empty;
  logic [8:0]        rsv_n;
  logic [IW-1:0]     rsv_base, fill_idx;
  logic [DATA_WIDTH-1:0] fill_data, head_data;
  logic [LW:0]       fill_nbytes, head_nbytes;
  logic [CW-1:0]     buf_occ, buf_rsv;
  sf_stream_dma_buffer #(.DW(DATA_WIDTH), .DEPTH(FIFO_DEPTH)) u_buf (
    .clk(clk), .rst_n(rstc_n), .flush(flush),
    .rsv_valid(rsv_valid), .rsv_n(rsv_n), .rsv_ok(rsv_ok), .rsv_base(rsv_base),
    .fill_valid(fill_valid), .fill_idx(fill_idx), .fill_data(fill_data), .fill_nbytes(fill_nbytes),
    .head_valid(head_valid), .head_data(head_data), .head_nbytes(head_nbytes), .head_pop(head_pop),
    .occ(buf_occ), .rsv(buf_rsv), .empty(buf_empty));

  // ------------------------------------------------------------------ MemoryGuard checker (2 clients: 0 = read, 1 = write)
  logic          rg_valid, rg_ready, wg_valid, wg_ready;
  logic [DOM_W-1:0] rg_dom, wg_dom;
  logic [3:0]    rg_type, wg_type;
  logic [AW-1:0] rg_addr, wg_addr;
  logic [15:0]   rg_bytes, wg_bytes;
  logic          rg_rv, rg_ok, wg_rv, wg_ok;
  logic [3:0]    rg_f, wg_f;
  logic [AW-1:0] rg_pa, wg_pa;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [1:0]    c_rsp_valid_u;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [1:0]    c_rsp_ok;
  logic [7:0]    c_rsp_fault;
  logic [2*AW-1:0] c_rsp_pa;
  sfdma_perm_checker #(.NCLI(2), .AW(AW), .DOM_W(DOM_W), .DW(DATA_WIDTH), .PERM_OUT(GUARD_OUT)) u_guard (
    .clk(clk), .rst_n(rstc_n), .asid_en(cfg_type_en),
    .c_req_valid({wg_valid, rg_valid}), .c_req_ready({wg_ready, rg_ready}),
    .c_req_domain({wg_dom, rg_dom}), .c_req_asid({wg_type, rg_type}), .c_req_write({1'b1, 1'b0}),
    .c_req_addr({wg_addr, rg_addr}), .c_req_bytes({wg_bytes, rg_bytes}),
    .c_rsp_valid(c_rsp_valid_u), .c_rsp_ok(c_rsp_ok), .c_rsp_fault(c_rsp_fault), .c_rsp_pa(c_rsp_pa),
    .iommu_req_valid(guard_req_valid), .iommu_req_ready(guard_req_ready), .iommu_req_domain(guard_req_domain),
    .iommu_req_asid(guard_req_asid), .iommu_req_write(guard_req_write), .iommu_req_addr(guard_req_addr),
    .iommu_req_bytes(guard_req_bytes), .iommu_req_id(guard_req_id),
    .iommu_rsp_valid(guard_rsp_valid), .iommu_rsp_ready(guard_rsp_ready), .iommu_rsp_id(guard_rsp_id),
    .iommu_rsp_ok(guard_rsp_ok), .iommu_rsp_fault(guard_rsp_fault), .iommu_rsp_pa(guard_rsp_pa),
    .proto_err_evt(guard_proto_err));
  assign rg_rv = c_rsp_valid_u[0]; assign wg_rv = c_rsp_valid_u[1];
  assign rg_ok = c_rsp_ok[0];      assign wg_ok = c_rsp_ok[1];
  assign rg_f  = c_rsp_fault[3:0]; assign wg_f  = c_rsp_fault[7:4];
  assign rg_pa = c_rsp_pa[AW-1:0]; assign wg_pa = c_rsp_pa[2*AW-1:AW];

  // ------------------------------------------------------------------ read / write engines
  logic [TOT_W-1:0] acked_bytes;
  logic             rd_quiet, rd_busy, rd_fault, wr_quiet, wr_drained, wr_busy, wr_fault;
  logic [7:0]       rd_fcode, wr_fcode;
  logic [3:0]       rd_fdet, wr_fdet;
  logic [AW-1:0]    rd_faddr, wr_faddr;
  logic             e_rd_ar_stall, e_rd_buf, e_rd_out, e_rd_grd, e_haz_stall, e_haz_event, e_rd_burst;
  logic [8:0]       e_rd_beats;
  logic [LW+1:0]    e_rd_bytes;
  logic [31:0]      rd_out_cnt, wr_out_cnt;
  sf_stream_dma_read #(.AW(AW), .DW(DATA_WIDTH), .BL(BURST_LENGTH), .DOM_W(DOM_W), .NSLOT(MAX_OUTSTANDING_READS),
                       .PLAN_DEPTH(PLAN_DEPTH), .RING_DEPTH(FIFO_DEPTH), .MAX_SEG_LOG2(MAX_SEG_LOG2), .MAX_TXN_LOG2(MAX_TXN_LOG2)) u_rd (
    .clk(clk), .rst_n(rstc_n), .flush(flush), .kill(kill),
    .seg_valid(rs_out_valid), .seg_ready(rs_out_ready), .seg_src(r_src), .seg_dst(r_dst), .seg_len(r_len),
    .seg_stype(r_stype), .seg_dtype(r_dtype), .seg_fence(r_fence), .seg_start_off(r_start), .seg_domain(r_dom),
    .seg_marker(r_marker), .wr_acked_bytes(acked_bytes),
    .g_req_valid(rg_valid), .g_req_ready(rg_ready), .g_req_domain(rg_dom), .g_req_type(rg_type), .g_req_addr(rg_addr),
    .g_req_bytes(rg_bytes), .g_rsp_valid(rg_rv), .g_rsp_ok(rg_ok), .g_rsp_fault(rg_f), .g_rsp_pa(rg_pa),
    .rsv_valid(rsv_valid), .rsv_n(rsv_n), .rsv_ok(rsv_ok), .rsv_base(rsv_base),
    .fill_valid(fill_valid), .fill_idx(fill_idx), .fill_data(fill_data), .fill_nbytes(fill_nbytes),
    .ar_valid(ar_valid), .ar_ready(ar_ready), .ar_id(ar_id), .ar_addr(ar_addr), .ar_len(ar_len), .ar_mtype(ar_mtype), .ar_domain(ar_domain),
    .r_valid(r_valid), .r_ready(r_ready), .r_id(r_id), .r_data(r_data), .r_resp(r_resp), .r_last(r_last),
    .rd_quiet(rd_quiet), .rd_busy(rd_busy),
    .fault_evt(rd_fault), .fault_code(rd_fcode), .fault_detail(rd_fdet), .fault_addr(rd_faddr),
    .ev_ar_stall(e_rd_ar_stall), .ev_buf_stall(e_rd_buf), .ev_out_stall(e_rd_out), .ev_guard_stall(e_rd_grd),
    .ev_haz_stall(e_haz_stall), .ev_haz_event(e_haz_event), .ev_rd_burst(e_rd_burst), .ev_rd_beats(e_rd_beats),
    .ev_rd_bytes(e_rd_bytes), .outstanding(rd_out_cnt));
  assign ar_size  = 3'(LW);
  assign ar_burst = 2'b01;

  logic             end_ok, end_err;
  logic [7:0]       end_code;
  logic [TOT_W-1:0] end_total;
  logic             e_aw_stall, e_w_stall, e_data, e_wbuf, e_wout, e_wgrd, e_wr_burst;
  logic [8:0]       e_wr_beats;
  logic [12:0]      e_wr_bytes;
  localparam int WCW = $clog2(WR_FIFO_DEPTH + 1);
  logic [WCW-1:0]   wf_level;
  sf_stream_dma_write #(.AW(AW), .DW(DATA_WIDTH), .BL(BURST_LENGTH), .DOM_W(DOM_W), .NSLOT(MAX_OUTSTANDING_WRITES),
                        .PLAN_DEPTH(PLAN_DEPTH), .WFIFO_DEPTH(WR_FIFO_DEPTH), .MAX_SEG_LOG2(MAX_SEG_LOG2), .MAX_TXN_LOG2(MAX_TXN_LOG2)) u_wr (
    .clk(clk), .rst_n(rstc_n), .flush(flush), .kill(kill),
    .seg_valid(ws_out_valid), .seg_ready(ws_out_ready), .seg_dst(w_dst), .seg_len(w_len), .seg_dtype(w_dtype),
    .seg_last(w_last_s), .seg_domain(w_dom), .seg_marker(w_marker), .seg_err(w_err), .seg_total(w_total),
    .head_valid(head_valid), .head_data(head_data), .head_nbytes(head_nbytes), .head_pop(head_pop),
    .g_req_valid(wg_valid), .g_req_ready(wg_ready), .g_req_domain(wg_dom), .g_req_type(wg_type), .g_req_addr(wg_addr),
    .g_req_bytes(wg_bytes), .g_rsp_valid(wg_rv), .g_rsp_ok(wg_ok), .g_rsp_fault(wg_f), .g_rsp_pa(wg_pa),
    .aw_valid(aw_valid), .aw_ready(aw_ready), .aw_id(aw_id), .aw_addr(aw_addr), .aw_len(aw_len), .aw_mtype(aw_mtype), .aw_domain(aw_domain),
    .w_valid(w_valid), .w_ready(w_ready), .w_data(w_data), .w_strb(w_strb), .w_last(w_last),
    .b_valid(b_valid), .b_ready(b_ready), .b_id(b_id), .b_resp(b_resp),
    .acked_bytes(acked_bytes), .end_ok_evt(end_ok), .end_err_evt(end_err), .end_err_code(end_code), .end_total(end_total),
    .wr_quiet(wr_quiet), .wr_drained(wr_drained), .wr_busy(wr_busy),
    .fault_evt(wr_fault), .fault_code(wr_fcode), .fault_detail(wr_fdet), .fault_addr(wr_faddr),
    .ev_aw_stall(e_aw_stall), .ev_w_stall(e_w_stall), .ev_data_stall(e_data), .ev_wbuf_stall(e_wbuf), .ev_out_stall(e_wout),
    .ev_guard_stall(e_wgrd), .ev_wr_burst(e_wr_burst), .ev_wr_beats(e_wr_beats), .ev_wr_bytes(e_wr_bytes),
    .wf_level(wf_level), .outstanding(wr_out_cnt));
  assign aw_size  = 3'(LW);
  assign aw_burst = 2'b01;

  // ------------------------------------------------------------------ completion engine
  wire any_fault = rd_fault || wr_fault;
  wire [7:0]    f_code = rd_fault ? rd_fcode : wr_fcode;
  wire [3:0]    f_det  = rd_fault ? rd_fdet  : wr_fdet;
  wire [AW-1:0] f_addr = rd_fault ? rd_faddr : wr_faddr;
  wire progress = (ar_valid && ar_ready) || (aw_valid && aw_ready) || (w_valid && w_ready) || r_valid || b_valid ||
                  rg_rv || wg_rv || (rg_valid && rg_ready) || (wg_valid && wg_ready);
  logic txn_active, ev_txn_done, ev_txn_err, ev_timeout;
  logic [31:0] ev_latency;
  sf_stream_dma_cpl #(.AW(AW), .DOM_W(DOM_W), .MAX_TXN_LOG2(MAX_TXN_LOG2)) u_cpl (
    .clk(clk), .rst_n(rstc_n), .cfg_timeout(cfg_timeout), .ctl_abort(ctl_abort),
    .start_evt(start_evt), .start_txn_id(start_id), .start_domain(start_dom), .start_cpl_en(start_cpl), .start_irq_en(start_irq),
    .val_total(val_total),
    .end_ok_evt(end_ok), .end_total(end_total), .end_err_evt(end_err), .end_err_code(end_code),
    .fault_evt(any_fault), .fault_code(f_code), .fault_detail(f_det), .fault_addr(f_addr),
    .rd_quiet(rd_quiet), .wr_quiet(wr_quiet), .wr_drained(wr_drained), .acked_bytes(acked_bytes), .progress(progress),
    .kill(kill_c), .flush(flush), .txn_done(txn_done), .fenced(fenced), .txn_active(txn_active),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_txn_id(cpl_txn_id), .cpl_domain(cpl_domain), .cpl_status(cpl_status),
    .cpl_err(cpl_err), .cpl_detail(cpl_detail), .cpl_bytes_done(cpl_bytes_done), .cpl_bytes_total(cpl_bytes_total),
    .cpl_err_addr(cpl_err_addr), .cpl_latency(cpl_latency), .cpl_partial(cpl_partial), .irq(irq),
    .ev_txn_done(ev_txn_done), .ev_txn_err(ev_txn_err), .ev_latency(ev_latency), .ev_timeout(ev_timeout));

  assign busy = v_busy || (q_level != '0) || txn_active || soft_pend;

  // ------------------------------------------------------------------ performance counters
  logic [`SFSD_PC_N*32-1:0] pinc;
  logic [31:0] occ32, wocc32;
  assign occ32  = 32'(buf_occ);
  assign wocc32 = 32'(wf_level);
  always_comb begin
    pinc = '0;
    pinc[32*`SFSD_PC_CYCLES +: 32]        = 32'd1;
    pinc[32*`SFSD_PC_ACTIVE +: 32]        = 32'(busy);
    pinc[32*`SFSD_PC_BYTES_WR +: 32]      = 32'(e_wr_bytes);
    pinc[32*`SFSD_PC_BYTES_RD +: 32]      = 32'(e_rd_bytes);
    pinc[32*`SFSD_PC_RD_BURSTS +: 32]     = 32'(e_rd_burst);
    pinc[32*`SFSD_PC_WR_BURSTS +: 32]     = 32'(e_wr_burst);
    pinc[32*`SFSD_PC_RD_BEATS +: 32]      = 32'(e_rd_beats);
    pinc[32*`SFSD_PC_WR_BEATS +: 32]      = 32'(e_wr_beats);
    pinc[32*`SFSD_PC_RD_STALL_AR +: 32]   = 32'(e_rd_ar_stall);
    pinc[32*`SFSD_PC_RD_STALL_BUF +: 32]  = 32'(e_rd_buf);
    pinc[32*`SFSD_PC_RD_STALL_OUT +: 32]  = 32'(e_rd_out);
    pinc[32*`SFSD_PC_RD_STALL_GRD +: 32]  = 32'(e_rd_grd);
    pinc[32*`SFSD_PC_WR_STALL_AW +: 32]   = 32'(e_aw_stall);
    pinc[32*`SFSD_PC_WR_STALL_W +: 32]    = 32'(e_w_stall);
    pinc[32*`SFSD_PC_WR_STALL_DATA +: 32] = 32'(e_data);
    pinc[32*`SFSD_PC_WR_STALL_WBUF +: 32] = 32'(e_wbuf);
    pinc[32*`SFSD_PC_WR_STALL_OUT +: 32]  = 32'(e_wout);
    pinc[32*`SFSD_PC_WR_STALL_GRD +: 32]  = 32'(e_wgrd);
    pinc[32*`SFSD_PC_HAZ_CYCLES +: 32]    = 32'(e_haz_stall);
    pinc[32*`SFSD_PC_HAZ_EVENTS +: 32]    = 32'(e_haz_event);
    pinc[32*`SFSD_PC_OCC_SUM +: 32]       = occ32;
    pinc[32*`SFSD_PC_OCC_MAX +: 32]       = occ32;
    pinc[32*`SFSD_PC_WOCC_SUM +: 32]      = wocc32;
    pinc[32*`SFSD_PC_WOCC_MAX +: 32]      = wocc32;
    pinc[32*`SFSD_PC_TXN_DONE +: 32]      = 32'(ev_txn_done);
    pinc[32*`SFSD_PC_TXN_ERR +: 32]       = 32'(ev_txn_err);
    pinc[32*`SFSD_PC_LAT_SUM +: 32]       = ev_txn_done ? ev_latency : 32'd0;
    pinc[32*`SFSD_PC_LAT_MAX +: 32]       = ev_txn_done ? ev_latency : 32'd0;
    pinc[32*`SFSD_PC_LAT_LAST +: 32]      = ev_txn_done ? ev_latency : 32'd0;
    pinc[32*`SFSD_PC_DESC_OK +: 32]       = 32'(ev_desc_ok);
    pinc[32*`SFSD_PC_DESC_REJ +: 32]      = 32'(ev_desc_rej);
    pinc[32*`SFSD_PC_DESC_DROP +: 32]     = 32'(ev_desc_drop);
    pinc[32*`SFSD_PC_GUARD_VIOL +: 32]    = 32'((rg_rv && !rg_ok) || (wg_rv && !wg_ok));
    pinc[32*`SFSD_PC_BUS_ERR +: 32]       = 32'(any_fault && (f_code == `SFSD_ERR_BUS_RD || f_code == `SFSD_ERR_BUS_WR));
    pinc[32*`SFSD_PC_PROTO_ERR +: 32]     = 32'((any_fault && f_code == `SFSD_ERR_PROTO) || guard_proto_err);
    pinc[32*`SFSD_PC_TIMEOUTS +: 32]      = 32'(ev_timeout);
  end
  sf_stream_dma_perf #(.CNT_W(CNT_W)) u_perf (
    .clk(clk), .rst_n(rst_n), .clear(perf_clear), .inc(pinc), .sel(perf_sel), .data(perf_data));

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = &{1'b0, v_first, v_cpl_en, v_irq_en, v_txn_id, v_in_txn, rd_busy, wr_busy, rd_out_cnt, wr_out_cnt,
                     buf_rsv, buf_empty, ev_txn_err, 1'b0};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
