// =============================================================================
// StreamDMA :: sf_stream_dma_read -- read request engine
//
//   segment -> hazard interlock -> burst planner -> MemoryGuard (read) -> AR queue -> AR issue (slot + ring reservation)
//   R response ingest: slot lookup by RID, per-burst beat counter, byte-lane right-shift, write into the reservation ring
//
//   * Each outstanding read burst owns one SLOT; ARID = slot index.  A response is matched by RID, so responses may
//     return reordered and beats of different IDs may interleave; the ring (sf_stream_dma_buffer) restores program order.
//     In-order return is NOT assumed.  RLAST must be set exactly on the burst's final beat.
//   * The AR address is the physical address returned by the guard for that very burst; nothing else forms a bus address.
//   * Hazard interlock (single transaction in flight, so segments are ordered): a segment whose source overlaps the
//     destination of an earlier un-retired segment (RAW), whose destination overlaps an earlier destination (WAW), or
//     that carries FENCE, does not start reading until every earlier write is acknowledged (wr_acked_bytes == start_off).
//     The un-retired destinations are tracked as one [lo,hi) hull per memory type (conservative: false positives only).
//   * kill: no new guard request / AR is started; responses are still absorbed (data dropped) so the bus drains.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stream_dma_read #(
  parameter int AW           = 40,
  parameter int DW           = 128,
  parameter int BL           = 16,
  parameter int DOM_W        = 4,
  parameter int NSLOT        = 1,
  parameter int PLAN_DEPTH   = 2,
  parameter int RING_DEPTH   = 64,
  parameter int MAX_SEG_LOG2 = 24,
  parameter int MAX_TXN_LOG2 = 30,
  localparam int W           = DW/8,
  localparam int LW          = $clog2(DW/8),
  localparam int IDW         = (NSLOT > 1) ? $clog2(NSLOT) : 1,
  localparam int IW          = $clog2(RING_DEPTH),
  localparam int SEG_W       = MAX_SEG_LOG2 + 1,
  localparam int TOT_W       = MAX_TXN_LOG2 + 1
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic               flush,
  input  wire logic               kill,
  // segment input
  input  wire logic               seg_valid,
  output logic                    seg_ready,
  input  wire logic [AW-1:0]      seg_src,
  input  wire logic [AW-1:0]      seg_dst,
  input  wire logic [SEG_W-1:0]   seg_len,
  input  wire logic [3:0]         seg_stype,
  input  wire logic [3:0]         seg_dtype,
  input  wire logic               seg_fence,
  input  wire logic [TOT_W-1:0]   seg_start_off,
  input  wire logic [DOM_W-1:0]   seg_domain,
  input  wire logic               seg_marker,
  input  wire logic [TOT_W-1:0]   wr_acked_bytes,
  // MemoryGuard client (read)
  output logic                    g_req_valid,
  input  wire logic               g_req_ready,
  output logic [DOM_W-1:0]        g_req_domain,
  output logic [3:0]              g_req_type,
  output logic [AW-1:0]           g_req_addr,
  output logic [15:0]             g_req_bytes,
  input  wire logic               g_rsp_valid,
  input  wire logic               g_rsp_ok,
  input  wire logic [3:0]         g_rsp_fault,
  input  wire logic [AW-1:0]      g_rsp_pa,
  // data buffer
  output logic                    rsv_valid,
  output logic [8:0]              rsv_n,
  input  wire logic               rsv_ok,
  input  wire logic [IW-1:0]      rsv_base,
  output logic                    fill_valid,
  output logic [IW-1:0]           fill_idx,
  output logic [DW-1:0]           fill_data,
  output logic [LW:0]             fill_nbytes,
  // AR / R channels
  output logic                    ar_valid,
  input  wire logic               ar_ready,
  output logic [IDW-1:0]          ar_id,
  output logic [AW-1:0]           ar_addr,
  output logic [7:0]              ar_len,
  output logic [3:0]              ar_mtype,
  output logic [DOM_W-1:0]        ar_domain,
  input  wire logic               r_valid,
  output logic                    r_ready,
  input  wire logic [IDW-1:0]     r_id,
  input  wire logic [DW-1:0]      r_data,
  input  wire logic [1:0]         r_resp,
  input  wire logic               r_last,
  // status / events
  output logic                    rd_quiet,
  output logic                    rd_busy,           // segment in progress or anything outstanding
  output logic                    fault_evt,
  output logic [7:0]              fault_code,
  output logic [3:0]              fault_detail,
  output logic [AW-1:0]           fault_addr,
  output logic                    ev_ar_stall,
  output logic                    ev_buf_stall,
  output logic                    ev_out_stall,
  output logic                    ev_guard_stall,
  output logic                    ev_haz_stall,
  output logic                    ev_haz_event,
  output logic                    ev_rd_burst,
  output logic [8:0]              ev_rd_beats,
  output logic [LW+1:0]           ev_rd_bytes,       // payload bytes received this cycle
  output logic [31:0]             outstanding
);
  `include "sf_stream_dma_defs.svh"
  localparam logic [1:0] S_IDLE = 2'd0, S_HAZ = 2'd1, S_RUN = 2'd2;

  // ------------------------------------------------------------------ segment sequencing + hazard interlock
  logic [1:0]        st;
  logic [AW-1:0]     cur_addr, hz_dst;
  logic [SEG_W-1:0]  cur_rem, hz_len;
  logic [3:0]        cur_type, hz_dtype;
  logic [DOM_W-1:0]  cur_dom;
  logic              hz_fence;
  logic [TOT_W-1:0]  hz_start;
  logic [AW-1:0]     hz_src;

  logic [`SFSD_NUM_MT-1:0] hull_v;
  logic [AW:0]             hull_lo [`SFSD_NUM_MT];
  logic [AW:0]             hull_hi [`SFSD_NUM_MT];

  wire [AW:0] sr_lo = {1'b0, hz_src};
  wire [AW:0] sr_hi = {1'b0, hz_src} + (AW+1)'(hz_len);
  wire [AW:0] dr_lo = {1'b0, hz_dst};
  wire [AW:0] dr_hi = {1'b0, hz_dst} + (AW+1)'(hz_len);
  logic hz_conflict;
  logic [3:0] hz_stype_i;
  always_comb begin
    hz_conflict = hz_fence;
    for (int t = 0; t < `SFSD_NUM_MT; t++) begin
      if (hull_v[t] && (hz_stype_i == 4'(t)) && (sr_lo < hull_hi[t]) && (hull_lo[t] < sr_hi)) hz_conflict = 1'b1;
      if (hull_v[t] && (hz_dtype == 4'(t))   && (dr_lo < hull_hi[t]) && (hull_lo[t] < dr_hi)) hz_conflict = 1'b1;
    end
  end
  wire quiesced = (wr_acked_bytes == hz_start);
  wire hz_go    = !hz_conflict || quiesced;

  // ------------------------------------------------------------------ burst planner + guard stage
  logic [12:0] p_nbytes; logic [8:0] p_nbeats; logic [LW-1:0] p_off, p_endl;
  sf_stream_dma_plan #(.DW(DW), .BL(BL), .REM_W(SEG_W)) u_plan (
    .addr_lo(cur_addr[11:0]), .rem(cur_rem), .nbytes(p_nbytes), .nbeats(p_nbeats), .off(p_off), .endl(p_endl));

  logic              g_v, g_pend;
  logic [AW-1:0]     g_iova;
  logic [8:0]        g_nbeats;
  logic [LW-1:0]     g_off, g_endl;
  logic [3:0]        g_type;
  logic [DOM_W-1:0]  g_dom;

  // AR queue: {mtype, pa, iova, nbeats, off, endl}
  localparam int QW = 4 + AW + AW + 9 + LW + LW;
  /* verilator lint_off UNUSEDSIGNAL */
  logic              q_in_ready;
  /* verilator lint_on UNUSEDSIGNAL */
  logic              q_in_valid, q_out_valid, q_out_ready;
  logic [QW-1:0]     q_in_data, q_out_data;
  logic [$clog2(PLAN_DEPTH+1)-1:0] q_level;
  sfd_fifo #(.WIDTH(QW), .DEPTH(PLAN_DEPTH)) u_arq (
    .clk(clk), .rst_n(rst_n), .flush(flush),
    .in_valid(q_in_valid), .in_ready(q_in_ready), .in_data(q_in_data),
    .out_valid(q_out_valid), .out_ready(q_out_ready), .out_data(q_out_data), .level(q_level));

  wire rsp_take = g_pend && g_rsp_valid;
  assign q_in_valid = rsp_take && g_rsp_ok;
  assign q_in_data  = {g_type, g_rsp_pa, g_iova, g_nbeats, g_off, g_endl};

  wire [3:0]    q_type  = q_out_data[QW-1 -: 4];
  wire [AW-1:0] q_pa    = q_out_data[QW-5 -: AW];
  wire [AW-1:0] q_iova  = q_out_data[QW-5-AW -: AW];
  wire [8:0]    q_nb    = q_out_data[2*LW + 8 : 2*LW];
  wire [LW-1:0] q_off   = q_out_data[2*LW-1 : LW];
  wire [LW-1:0] q_endl  = q_out_data[LW-1 : 0];

  wire plan_room = (32'(q_level) < PLAN_DEPTH);
  wire plan_go   = (st == S_RUN) && !g_v && !g_pend && plan_room && !kill;
  wire seg_end_now = plan_go && (cur_rem == SEG_W'(p_nbytes));

  assign g_req_valid  = g_v;
  assign g_req_domain = g_dom;
  assign g_req_type   = g_type;
  assign g_req_addr   = g_iova & ~(AW'(W) - AW'(1));
  assign g_req_bytes  = 16'(g_nbeats) * 16'(W);

  assign seg_ready = (st == S_IDLE) && !kill;

  // ------------------------------------------------------------------ AR issue + slot table
  logic [NSLOT-1:0]  s_v;
  logic [IW-1:0]     s_base [NSLOT];
  logic [8:0]        s_n    [NSLOT];
  logic [8:0]        s_cnt  [NSLOT];
  logic [LW-1:0]     s_off  [NSLOT];
  logic [LW-1:0]     s_endl [NSLOT];
  logic [AW-1:0]     s_iova [NSLOT];

  logic              fs_found;
  logic [IDW-1:0]    fs;
  always_comb begin
    fs_found = 1'b0; fs = '0;
    for (int i = NSLOT - 1; i >= 0; i--) if (!s_v[i]) begin fs_found = 1'b1; fs = IDW'(i); end
  end
  wire ar_free  = !ar_valid || ar_ready;
  wire ar_blk   = q_out_valid && !kill;
  wire ar_issue = ar_blk && fs_found && rsv_ok && ar_free;
  assign q_out_ready = ar_issue;
  assign rsv_valid   = ar_issue;
  assign rsv_n       = q_nb;

  // ------------------------------------------------------------------ R ingest (registered input stage, r_ready = 1)
  logic              rq_v;
  logic [IDW-1:0]    rq_id;
  logic [DW-1:0]     rq_data;
  logic [1:0]        rq_resp;
  logic              rq_last;
  assign r_ready = 1'b1;

  logic              id_in, k_known;
  logic [8:0]        k_cnt, k_n;
  logic [LW-1:0]     k_off, k_endl;
  logic [IW-1:0]     k_base;
  logic [AW-1:0]     k_iova;
  always_comb begin
    id_in = (32'(rq_id) < NSLOT);
    k_known = 1'b0; k_cnt = '0; k_n = '0; k_off = '0; k_endl = '0; k_base = '0; k_iova = '0;
    for (int i = 0; i < NSLOT; i++) if (32'(rq_id) == i) begin
      k_known = s_v[i]; k_cnt = s_cnt[i]; k_n = s_n[i]; k_off = s_off[i]; k_endl = s_endl[i];
      k_base = s_base[i]; k_iova = s_iova[i];
    end
    k_known = k_known && id_in && rq_v;
  end
  wire        k_lastexp = (k_cnt == (k_n - 9'd1));
  wire        k_good    = k_known && (rq_last == k_lastexp) && (rq_resp == 2'b00);
  wire [LW-1:0] b_lo    = (k_cnt == 9'd0) ? k_off : '0;
  wire [LW-1:0] b_hi    = k_lastexp ? k_endl : LW'(W - 1);
  wire [LW:0]   b_nb    = {1'b0, b_hi} - {1'b0, b_lo} + 1'b1;
  logic [DW-1:0] b_sh, b_mask;
  always_comb begin
    b_sh = rq_data >> (8 * 32'(b_lo));
    for (int i = 0; i < W; i++) b_mask[8*i +: 8] = (i < 32'(b_nb)) ? 8'hFF : 8'h00;
  end
  assign fill_valid  = k_good && !kill;
  assign fill_idx    = k_base + k_cnt[IW-1:0];
  assign fill_data   = b_sh & b_mask;
  assign fill_nbytes = b_nb;

  // faults
  logic f_proto, f_bus, f_guard;
  assign f_proto = rq_v && (!k_known || (rq_last != k_lastexp));
  assign f_bus   = k_known && (rq_resp != 2'b00);
  assign f_guard = rsp_take && !g_rsp_ok;
  always_comb begin
    fault_evt = f_proto || f_bus || f_guard;
    fault_code = `SFSD_ERR_NONE; fault_detail = 4'd0; fault_addr = '0;
    if (f_proto)      begin fault_code = `SFSD_ERR_PROTO;    fault_detail = 4'd0;           fault_addr = k_iova; end
    else if (f_bus)   begin fault_code = `SFSD_ERR_BUS_RD;   fault_detail = {2'b00, rq_resp}; fault_addr = k_iova; end
    else if (f_guard) begin fault_code = `SFSD_ERR_GUARD_RD; fault_detail = g_rsp_fault;    fault_addr = g_iova; end
  end

  // ------------------------------------------------------------------ sequential state
  logic [31:0] n_out;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; cur_addr <= '0; cur_rem <= '0; cur_type <= '0; cur_dom <= '0;
      hz_dst <= '0; hz_len <= '0; hz_dtype <= '0; hz_fence <= 1'b0; hz_start <= '0; hz_src <= '0; hz_stype_i <= '0;
      hull_v <= '0;
      g_v <= 1'b0; g_pend <= 1'b0; g_iova <= '0; g_nbeats <= '0; g_off <= '0; g_endl <= '0; g_type <= '0; g_dom <= '0;
      s_v <= '0; ar_valid <= 1'b0; ar_id <= '0; ar_addr <= '0; ar_len <= '0; ar_mtype <= '0; ar_domain <= '0;
      rq_v <= 1'b0; rq_id <= '0; rq_data <= '0; rq_resp <= '0; rq_last <= 1'b0;
      ev_haz_event <= 1'b0;
      for (int i = 0; i < NSLOT; i++) begin s_base[i] <= '0; s_n[i] <= '0; s_cnt[i] <= '0; s_off[i] <= '0; s_endl[i] <= '0; s_iova[i] <= '0; end
      for (int t = 0; t < `SFSD_NUM_MT; t++) begin hull_lo[t] <= '0; hull_hi[t] <= '0; end
    end else begin
      ev_haz_event <= 1'b0;
      rq_v <= r_valid; rq_id <= r_id; rq_data <= r_data; rq_resp <= r_resp; rq_last <= r_last;
      if (ar_valid && ar_ready) ar_valid <= 1'b0;

      if (flush) begin
        st <= S_IDLE; hull_v <= '0; g_v <= 1'b0; g_pend <= 1'b0; s_v <= '0; ar_valid <= 1'b0; cur_rem <= '0;
      end else begin
        // ---- segment sequencing
        case (st)
          S_IDLE: if (seg_valid && !kill) begin
            if (!seg_marker) begin
              cur_addr <= seg_src; cur_rem <= seg_len; cur_type <= seg_stype; cur_dom <= seg_domain;
              hz_src <= seg_src; hz_dst <= seg_dst; hz_len <= seg_len; hz_dtype <= seg_dtype; hz_stype_i <= seg_stype;
              hz_fence <= seg_fence; hz_start <= seg_start_off;
              st <= S_HAZ;
            end
          end
          S_HAZ: if (hz_go) begin
            ev_haz_event <= hz_conflict;
            for (int t = 0; t < `SFSD_NUM_MT; t++) begin
              if (hz_conflict) begin
                hull_v[t] <= (hz_dtype == 4'(t));
                if (hz_dtype == 4'(t)) begin hull_lo[t] <= dr_lo; hull_hi[t] <= dr_hi; end
              end else if (hz_dtype == 4'(t)) begin
                hull_v[t] <= 1'b1;
                if (!hull_v[t] || (dr_lo < hull_lo[t])) hull_lo[t] <= dr_lo;
                if (!hull_v[t] || (dr_hi > hull_hi[t])) hull_hi[t] <= dr_hi;
              end
            end
            st <= S_RUN;
          end
          default: ;
        endcase
        if (kill && st != S_IDLE) begin st <= S_IDLE; end

        // ---- planner -> guard request
        if (plan_go) begin
          g_v <= 1'b1; g_iova <= cur_addr; g_nbeats <= p_nbeats; g_off <= p_off; g_endl <= p_endl;
          g_type <= cur_type; g_dom <= cur_dom;
          cur_addr <= cur_addr + AW'(p_nbytes);
          cur_rem  <= cur_rem - SEG_W'(p_nbytes);
          if (seg_end_now) st <= S_IDLE;
        end
        if (g_v && g_req_ready) begin g_v <= 1'b0; g_pend <= 1'b1; end
        if (rsp_take) g_pend <= 1'b0;

        // ---- AR issue
        if (ar_issue) begin
          ar_valid <= 1'b1; ar_id <= fs; ar_addr <= q_pa; ar_len <= 8'(q_nb - 9'd1);
          ar_mtype <= q_type; ar_domain <= g_dom;
          s_v[fs] <= 1'b1; s_base[fs] <= rsv_base; s_n[fs] <= q_nb; s_cnt[fs] <= '0;
          s_off[fs] <= q_off; s_endl[fs] <= q_endl; s_iova[fs] <= q_iova;
        end
        // ---- R ingest bookkeeping
        if (k_known) begin
          for (int i = 0; i < NSLOT; i++) if (32'(rq_id) == i) begin
            s_cnt[i] <= s_cnt[i] + 9'd1;
            if (k_lastexp || rq_last) s_v[i] <= 1'b0;
          end
        end
      end
    end
  end

  // ------------------------------------------------------------------ status / events
  always_comb begin
    n_out = 32'd0;
    for (int i = 0; i < NSLOT; i++) n_out = n_out + 32'(s_v[i]);
  end
  assign outstanding = n_out;
  assign rd_quiet = (s_v == '0) && !ar_valid && !g_v && !g_pend;
  assign rd_busy  = !rd_quiet || (st != S_IDLE) || q_out_valid;
  assign ev_ar_stall    = ar_valid && !ar_ready;
  assign ev_buf_stall   = q_out_valid && fs_found && !rsv_ok;
  assign ev_out_stall   = q_out_valid && !fs_found;
  assign ev_guard_stall = (g_v || g_pend) && !q_out_valid && (s_v == '0);
  assign ev_haz_stall   = (st == S_HAZ) && !hz_go;
  assign ev_rd_burst    = ar_issue;
  assign ev_rd_beats    = ar_issue ? q_nb : 9'd0;
  assign ev_rd_bytes    = (k_good && !kill) ? (LW+2)'(b_nb) : '0;
endmodule
`default_nettype wire
