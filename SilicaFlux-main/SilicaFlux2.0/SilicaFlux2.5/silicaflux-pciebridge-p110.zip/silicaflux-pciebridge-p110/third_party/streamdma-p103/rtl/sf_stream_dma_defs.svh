// =============================================================================
// SilicaFlux StreamDMA (Project 103) :: shared constants (macros, so no package is needed -- Yosys 0.33 rules)
// Descriptor ABI v1 (256 bits, little endian words; word n = bits [32n+31:32n]):
//   W0 [7:0] VERSION (=1)  [15:8] OPCODE (0 = COPY)  [31:16] FLAGS
//   W1 [15:0] TXN_ID       [31:16] DOMAIN (a CLAIM; must equal the trusted sideband captured at push)
//   W2 [3:0] SRC_TYPE  [7:4] DST_TYPE  [31:8] reserved (must be 0)
//   W3 LENGTH (bytes, 1 .. 2**MAX_SEG_LOG2)
//   W4,W5 SRC_ADDR (64-bit, low word first)      W6,W7 DST_ADDR
// =============================================================================
`ifndef SF_STREAM_DMA_DEFS_SVH
`define SF_STREAM_DMA_DEFS_SVH

`define SFSD_DESC_W          256
`define SFSD_DESC_VERSION    8'd1
`define SFSD_OP_COPY         8'd0

// FLAGS bit positions (inside W0[31:16])
`define SFSD_F_FIRST         0   // first (or only) segment of a transaction
`define SFSD_F_LAST          1   // last  (or only) segment of a transaction
`define SFSD_F_FENCE         2   // do not start reading this segment before every earlier write is acknowledged
`define SFSD_F_CPL_EN        3   // FIRST only: push a completion record on success (errors always push one)
`define SFSD_F_IRQ_EN        4   // FIRST only: pulse irq when the transaction completes
// bits 5..15 reserved, must be zero

// memory types (same numbering as CloudDMA ASIDs so the vendored permission checker/table are reused unchanged)
`define SFSD_MT_DRAM         4'd0  // system DRAM / HBM
`define SFSD_MT_SRAM         4'd1  // local SRAM (SRAMController)
`define SFSD_MT_STORAGE      4'd2  // storage window
`define SFSD_MT_NET          4'd3  // network packet buffers
`define SFSD_MT_COMPUTE      4'd4  // compute scratchpad (TensorCore / Vector Engine)
`define SFSD_NUM_MT          5

// completion status
`define SFSD_ST_OK           4'd0
`define SFSD_ST_ERROR        4'd1  // error; bytes_done tells how much was acknowledged before it (partial completion)
`define SFSD_ST_ABORTED      4'd2  // ctl_abort
`define SFSD_ST_TIMEOUT      4'd3  // watchdog: channel is fenced until ctl_soft_reset

// error codes (8 bit).  0x01..0x0E: descriptor validation (no byte of the failing descriptor moved)
`define SFSD_ERR_NONE        8'h00
`define SFSD_ERR_VERSION     8'h01
`define SFSD_ERR_OPCODE      8'h02
`define SFSD_ERR_DOMAIN      8'h03  // isolation violation: claimed domain != trusted binding (or binding changed mid-transaction)
`define SFSD_ERR_FLAGS       8'h04
`define SFSD_ERR_RSVD        8'h05
`define SFSD_ERR_CHAIN_FIRST 8'h06
`define SFSD_ERR_CHAIN_TXN   8'h07
`define SFSD_ERR_MEMTYPE     8'h08
`define SFSD_ERR_LEN_ZERO    8'h09
`define SFSD_ERR_LEN_BIG     8'h0A
`define SFSD_ERR_TOTAL_BIG   8'h0B
`define SFSD_ERR_ADDR_RANGE  8'h0C
`define SFSD_ERR_ADDR_OVFL   8'h0D
`define SFSD_ERR_OVERLAP     8'h0E
// execution faults
`define SFSD_ERR_GUARD_RD    8'h20  // MemoryGuard refused a source read   (detail = FAULT_* from the guard)
`define SFSD_ERR_GUARD_WR    8'h21  // MemoryGuard refused a destination write
`define SFSD_ERR_BUS_RD      8'h30  // read response SLVERR / DECERR
`define SFSD_ERR_BUS_WR      8'h31  // write response SLVERR / DECERR
`define SFSD_ERR_PROTO       8'h32  // unexpected response id / bad RLAST / spurious response
`define SFSD_ERR_TIMEOUT     8'h33
`define SFSD_ERR_ABORT       8'h34
`define SFSD_ERR_INTERNAL    8'h35  // completion contract self-check failed (must never happen)


// performance counter indices (sf_stream_dma_perf)
`define SFSD_PC_CYCLES        0
`define SFSD_PC_ACTIVE        1
`define SFSD_PC_BYTES_WR      2   // destination bytes acknowledged (OKAY) -- "bytes transferred"
`define SFSD_PC_BYTES_RD      3   // payload bytes received on R
`define SFSD_PC_RD_BURSTS     4
`define SFSD_PC_WR_BURSTS     5
`define SFSD_PC_RD_BEATS      6
`define SFSD_PC_WR_BEATS      7
`define SFSD_PC_RD_STALL_AR   8   // AR valid && !ready
`define SFSD_PC_RD_STALL_BUF  9   // burst ready to issue but the data buffer has no room
`define SFSD_PC_RD_STALL_OUT  10  // burst ready to issue but all read slots are busy
`define SFSD_PC_RD_STALL_GRD  11  // read path starved by the MemoryGuard round trip
`define SFSD_PC_WR_STALL_AW   12
`define SFSD_PC_WR_STALL_W    13  // W valid && !ready
`define SFSD_PC_WR_STALL_DATA 14  // assembler waiting for source data (read underrun)
`define SFSD_PC_WR_STALL_WBUF 15  // assembler blocked by a full W FIFO
`define SFSD_PC_WR_STALL_OUT  16  // complete burst waiting for a free write slot
`define SFSD_PC_WR_STALL_GRD  17  // complete burst waiting for the MemoryGuard
`define SFSD_PC_HAZ_CYCLES    18  // memory conflicts: cycles a segment waited on the RAW/WAW/FENCE interlock
`define SFSD_PC_HAZ_EVENTS    19  // memory conflicts: segments that hit the interlock
`define SFSD_PC_OCC_SUM       20  // sum over cycles of data-buffer occupancy (beats)
`define SFSD_PC_OCC_MAX       21
`define SFSD_PC_WOCC_SUM      22  // sum over cycles of W FIFO occupancy (beats)
`define SFSD_PC_WOCC_MAX      23
`define SFSD_PC_TXN_DONE      24
`define SFSD_PC_TXN_ERR       25
`define SFSD_PC_LAT_SUM       26
`define SFSD_PC_LAT_MAX       27
`define SFSD_PC_LAT_LAST      28
`define SFSD_PC_DESC_OK       29
`define SFSD_PC_DESC_REJ      30
`define SFSD_PC_DESC_DROP     31
`define SFSD_PC_GUARD_VIOL    32  // MemoryGuard refusals
`define SFSD_PC_BUS_ERR       33
`define SFSD_PC_PROTO_ERR     34
`define SFSD_PC_TIMEOUTS      35
`define SFSD_PC_N             36

`endif
