// =============================================================================
// StreamDMA :: sf_stream_dma_plan -- burst planner (pure combinational)
// Given the low 12 address bits and the bytes remaining in a segment it returns the next burst:
//   nbytes = min(rem, BURST_LENGTH*W - off, 4096 - addr[11:0])      (never crosses a 4 KiB boundary)
//   nbeats = ceil((off + nbytes) / W)       beats are full-width; byte lanes off..endl of the burst are payload
//   off    = addr mod W        first-beat lane of the first payload byte
//   endl   = (off + nbytes - 1) mod W       last payload lane of the last beat
// Properties (formal/stream_dma/fv_plan.sv): 1 <= nbytes <= rem, nbytes <= 4096, 1 <= nbeats <= BURST_LENGTH,
// beat envelope inside one 4 KiB page, payload bytes == (nbeats-1)*W + endl - off + 1.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stream_dma_plan #(
  parameter int DW    = 128,
  parameter int BL    = 16,
  parameter int REM_W = 25,
  localparam int LW   = $clog2(DW/8)
) (
  input  wire logic [11:0]       addr_lo,
  input  wire logic [REM_W-1:0]  rem,
  output logic [12:0]            nbytes,
  output logic [8:0]             nbeats,
  output logic [LW-1:0]          off,
  output logic [LW-1:0]          endl
);
  localparam int W = DW/8;
  localparam logic [13:0] BEAT_MAX = 14'(BL * W);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [13:0] m1;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [13:0] lim_beat, lim_pg, lim, sum;
  wire  [31:0] rem_x = 32'(rem);                    // zero-extended: REM_W may be smaller than 14 in small configurations
  logic [13:0] rem_c;
  always_comb begin
    off      = addr_lo[LW-1:0];
    lim_beat = BEAT_MAX - 14'(off);
    lim_pg   = 14'd4096 - 14'(addr_lo);
    rem_c    = (rem_x > 32'd4096) ? 14'd4096 : rem_x[13:0];
    lim      = (lim_beat < lim_pg) ? lim_beat : lim_pg;
    nbytes   = 13'(((rem_c < lim) ? rem_c : lim));
    sum      = 14'(off) + 14'(nbytes);
    nbeats   = 9'((sum + 14'(W - 1)) >> LW);
    m1       = sum - 14'd1;
    endl     = m1[LW-1:0];
  end
endmodule
`default_nettype wire
