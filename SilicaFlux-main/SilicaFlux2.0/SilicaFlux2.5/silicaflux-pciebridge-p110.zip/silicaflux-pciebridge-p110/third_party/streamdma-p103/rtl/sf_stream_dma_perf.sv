// =============================================================================
// StreamDMA :: sf_stream_dma_perf -- performance counter bank
//
// SFSD_PC_N counters of CNT_W bits (saturating), read through an index (perf_sel -> perf_data, 64-bit, zero-extended).
// The top computes one 32-bit increment/sample per counter every cycle (`inc`); the bank applies the counter's kind:
//   ADD  c += inc            MAX  c = max(c, inc)            SET  c = inc when inc != 0
// Counters are cleared by `clear` (a pulse).  They are NOT reset by the core's soft reset, so they can be read after
// a fault.  Derived metrics (done in software / the benchmark scripts, never in hardware):
//   effective bandwidth [B/cycle] = BYTES_WR / ACTIVE        burst utilisation = RD_BEATS / (RD_BURSTS * BURST_LENGTH)
//   mean data-buffer occupancy    = OCC_SUM / CYCLES          mean transaction latency = LAT_SUM / TXN_DONE
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
`include "sf_stream_dma_defs.svh"
module sf_stream_dma_perf #(
  parameter int CNT_W = 48
) (
  input  wire logic                          clk,
  input  wire logic                          rst_n,
  input  wire logic                          clear,
  input  wire logic [`SFSD_PC_N*32-1:0]      inc,
  input  wire logic [5:0]                    sel,
  output logic [63:0]                        data
);
  logic [CNT_W-1:0] c [`SFSD_PC_N];

  function automatic int kind(input int i);
    if (i == `SFSD_PC_OCC_MAX || i == `SFSD_PC_WOCC_MAX || i == `SFSD_PC_LAT_MAX) kind = 1;
    else if (i == `SFSD_PC_LAT_LAST) kind = 2;
    else kind = 0;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < `SFSD_PC_N; i++) c[i] <= '0;
    end else if (clear) begin
      for (int i = 0; i < `SFSD_PC_N; i++) c[i] <= '0;
    end else begin
      for (int i = 0; i < `SFSD_PC_N; i++) begin
        logic [CNT_W:0] s;
        logic [31:0]    v;
        v = inc[32*i +: 32];
        s = {1'b0, c[i]} + {{(CNT_W-31){1'b0}}, v};
        case (kind(i))
          0: c[i] <= s[CNT_W] ? {CNT_W{1'b1}} : s[CNT_W-1:0];
          1: if (v > 32'(c[i][CNT_W-1:0] & {{(CNT_W-32){1'b0}}, 32'hFFFF_FFFF})) c[i] <= {{(CNT_W-32){1'b0}}, v};
          default: if (v != 32'd0) c[i] <= {{(CNT_W-32){1'b0}}, v};
        endcase
      end
    end
  end

  always_comb begin
    data = 64'd0;
    for (int i = 0; i < `SFSD_PC_N; i++) if (sel == 6'(i)) data = 64'(c[i]);
  end
endmodule
`default_nettype wire
