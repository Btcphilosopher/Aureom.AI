// =============================================================================
// StreamDMA :: sf_stream_dma_descriptor -- descriptor validator + transaction tracker
//
// Pops descriptors from the queue, validates each with sf_stream_dma_dcheck against the running transaction context,
// and emits ONE registered validated-segment record (or an error MARKER when validation fails).
//   * A transaction = descriptors FIRST .. LAST with equal TXN_ID and an unchanged trusted domain.
//   * Only ONE transaction is admitted at a time: a descriptor that would START a transaction waits until the previous
//     transaction's completion was delivered (txn_done).  This is the "one outstanding transfer" contract.
//   * A rejected descriptor ends the transaction: already-validated segments still execute (partial completion), an
//     error marker follows them in order, and the remaining descriptors of that transaction are dropped (skip mode) up to
//     and including the next LAST, or until a FIRST descriptor is seen.
//   * `kill` (execution fault / ctl_abort) does the same: in-transaction -> skip mode.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
`include "sf_stream_dma_defs.svh"
module sf_stream_dma_descriptor #(
  parameter int AW           = 40,
  parameter int DOM_W        = 4,
  parameter int MAX_SEG_LOG2 = 24,
  parameter int MAX_TXN_LOG2 = 30,
  localparam int SEG_W       = MAX_SEG_LOG2 + 1,
  localparam int TOT_W       = MAX_TXN_LOG2 + 1
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic [15:0]        type_en,
  // queue head
  input  wire logic               q_valid,
  output logic                    q_ready,
  input  wire logic [255:0]       q_desc,
  input  wire logic [DOM_W-1:0]   q_domain,
  // validated segment (registered)
  output logic                    seg_valid,
  input  wire logic               seg_ready,
  output logic [AW-1:0]           seg_src,
  output logic [AW-1:0]           seg_dst,
  output logic [SEG_W-1:0]        seg_len,
  output logic [3:0]              seg_stype,
  output logic [3:0]              seg_dtype,
  output logic                    seg_first,
  output logic                    seg_last,
  output logic                    seg_fence,
  output logic                    seg_cpl_en,
  output logic                    seg_irq_en,
  output logic [15:0]             seg_txn_id,
  output logic [DOM_W-1:0]        seg_domain,
  output logic [TOT_W-1:0]        seg_start_off,
  output logic [TOT_W-1:0]        seg_total,
  output logic [7:0]              seg_err,           // != 0: error marker (no data movement)
  // control
  input  wire logic               txn_done,          // completion of the active transaction was delivered
  input  wire logic               kill,             // level: stop, and skip the rest of the open transaction
  output logic                    txn_start_evt,
  output logic [15:0]             start_txn_id,
  output logic [DOM_W-1:0]        start_domain,
  output logic                    start_cpl_en,
  output logic                    start_irq_en,
  output logic [TOT_W-1:0]        val_total,         // bytes validated in the current/last transaction
  output logic                    busy,
  output logic                    in_txn_o,
  // events
  output logic                    ev_desc_ok,
  output logic                    ev_desc_rej,
  output logic                    ev_desc_drop
);
  logic              in_txn, skip;
  logic [15:0]       cur_txn_id;
  logic [DOM_W-1:0]  cur_domain;
  logic [TOT_W-1:0]  cur_total;
  logic              cur_cpl, cur_irq;

  wire [TOT_W-1:0]   ctx_total = in_txn ? cur_total : '0;
  logic [7:0]        err;
  sf_stream_dma_dcheck #(.AW(AW), .DOM_W(DOM_W), .MAX_SEG_LOG2(MAX_SEG_LOG2), .MAX_TXN_LOG2(MAX_TXN_LOG2)) u_chk (
    .desc(q_desc), .trusted_domain(q_domain), .type_en(type_en), .in_txn(in_txn),
    .cur_txn_id(cur_txn_id), .cur_domain(cur_domain), .cur_total(ctx_total), .err(err));

  wire        h_first = q_desc[16 + `SFSD_F_FIRST];
  wire        h_last  = q_desc[16 + `SFSD_F_LAST];
  wire [TOT_W-1:0] h_len = TOT_W'(q_desc[96 +: SEG_W]);
  wire [15:0] h_id    = q_desc[47:32];

  wire out_free  = !seg_valid || seg_ready;
  wire drop_now  = q_valid && !kill && skip && !h_first;
  wire can_proc  = q_valid && !kill && !(skip && !h_first) && out_free && (in_txn || !busy);
  assign q_ready = drop_now || can_proc;
  wire proc      = can_proc;
  wire proc_ok   = proc && (err == `SFSD_ERR_NONE);
  wire proc_bad  = proc && (err != `SFSD_ERR_NONE);

  assign in_txn_o = in_txn;
  assign val_total = cur_total;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      in_txn <= 1'b0; skip <= 1'b0; busy <= 1'b0;
      cur_txn_id <= '0; cur_domain <= '0; cur_total <= '0; cur_cpl <= 1'b0; cur_irq <= 1'b0;
      seg_valid <= 1'b0; txn_start_evt <= 1'b0;
      start_txn_id <= '0; start_domain <= '0; start_cpl_en <= 1'b0; start_irq_en <= 1'b0;
      ev_desc_ok <= 1'b0; ev_desc_rej <= 1'b0; ev_desc_drop <= 1'b0;
      seg_src <= '0; seg_dst <= '0; seg_len <= '0; seg_stype <= '0; seg_dtype <= '0; seg_first <= 1'b0;
      seg_last <= 1'b0; seg_fence <= 1'b0; seg_cpl_en <= 1'b0; seg_irq_en <= 1'b0; seg_txn_id <= '0;
      seg_domain <= '0; seg_start_off <= '0; seg_total <= '0; seg_err <= '0;
    end else begin
      txn_start_evt <= 1'b0;
      ev_desc_ok <= proc_ok; ev_desc_rej <= proc_bad; ev_desc_drop <= drop_now;
      if (seg_valid && seg_ready) seg_valid <= 1'b0;

      if (kill) begin
        // stop: whatever is staged is dropped; the rest of an open transaction is skipped
        seg_valid <= 1'b0;
        if (in_txn) skip <= 1'b1;
        in_txn <= 1'b0;
      end else if (drop_now) begin
        if (h_last) skip <= 1'b0;
      end else if (proc_ok) begin
        skip       <= 1'b0;
        seg_valid  <= 1'b1;
        seg_src    <= q_desc[128 +: AW];
        seg_dst    <= q_desc[192 +: AW];
        seg_len    <= q_desc[96 +: SEG_W];
        seg_stype  <= q_desc[67:64];
        seg_dtype  <= q_desc[71:68];
        seg_first  <= h_first;
        seg_last   <= h_last;
        seg_fence  <= q_desc[16 + `SFSD_F_FENCE];
        seg_err    <= `SFSD_ERR_NONE;
        seg_txn_id <= h_id;
        seg_domain <= q_domain;
        seg_start_off <= ctx_total;
        seg_total  <= ctx_total + h_len;
        cur_total  <= ctx_total + h_len;
        if (h_first) begin
          cur_txn_id <= h_id; cur_domain <= q_domain;
          cur_cpl <= q_desc[16 + `SFSD_F_CPL_EN]; cur_irq <= q_desc[16 + `SFSD_F_IRQ_EN];
          busy <= 1'b1; txn_start_evt <= 1'b1;
          start_txn_id <= h_id; start_domain <= q_domain;
          start_cpl_en <= q_desc[16 + `SFSD_F_CPL_EN]; start_irq_en <= q_desc[16 + `SFSD_F_IRQ_EN];
          seg_cpl_en <= q_desc[16 + `SFSD_F_CPL_EN]; seg_irq_en <= q_desc[16 + `SFSD_F_IRQ_EN];
        end else begin
          seg_cpl_en <= cur_cpl; seg_irq_en <= cur_irq;
        end
        in_txn <= !h_last;
      end else if (proc_bad) begin
        // error marker: ends the transaction (in order, after the prefix that was already accepted)
        skip       <= !h_last;
        in_txn     <= 1'b0;
        seg_valid  <= 1'b1;
        seg_err    <= err;
        seg_src <= '0; seg_dst <= '0; seg_len <= '0; seg_stype <= '0; seg_dtype <= '0;
        seg_first  <= !in_txn; seg_last <= 1'b1; seg_fence <= 1'b0;
        seg_txn_id <= in_txn ? cur_txn_id : h_id;
        seg_domain <= q_domain;
        seg_start_off <= ctx_total; seg_total <= ctx_total;
        seg_cpl_en <= in_txn ? cur_cpl : 1'b0;
        seg_irq_en <= in_txn ? cur_irq : 1'b0;
        if (!in_txn) begin
          cur_total <= '0; cur_txn_id <= h_id; cur_domain <= q_domain; cur_cpl <= 1'b0; cur_irq <= 1'b0;
          busy <= 1'b1; txn_start_evt <= 1'b1;
          start_txn_id <= h_id; start_domain <= q_domain; start_cpl_en <= 1'b0; start_irq_en <= 1'b0;
        end
      end
      if (txn_done) busy <= 1'b0;
    end
  end
endmodule
`default_nettype wire
