// =============================================================================
// StreamDMA :: sf_stream_dma_write -- write request engine
//
//   segment -> burst planner -+-> assembly queue -> ASSEMBLER (realigner + byte strobes) -> W FIFO
//                             +-> guard queue    -> MemoryGuard (write) -> AW queue
//   AW issue: a burst is issued only when (a) the guard granted it, (b) ALL of its beats are already in the W FIFO
//   (store-and-forward at burst granularity, so a started burst can always complete), (c) a write slot is free.
//   W beats follow their AW in order and never depend on AWREADY (AXI rule: a master must not wait for AWREADY to drive W).
//   B responses are matched by BID against the slot table; they may return in any order across IDs.
//   acked_bytes counts destination bytes whose burst got an OKAY response -- the completion contract's ground truth.
//
//   kill: no new burst is planned/assembled/issued; bursts whose AW was already generated finish their W beats and are
//   answered normally (the bus drains); everything not yet issued is discarded by the later flush.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stream_dma_write #(
  parameter int AW           = 40,
  parameter int DW           = 128,
  parameter int BL           = 16,
  parameter int DOM_W        = 4,
  parameter int NSLOT        = 1,
  parameter int PLAN_DEPTH   = 2,
  parameter int WFIFO_DEPTH  = 32,
  parameter int MAX_SEG_LOG2 = 24,
  parameter int MAX_TXN_LOG2 = 30,
  localparam int W           = DW/8,
  localparam int LW          = $clog2(DW/8),
  localparam int IDW         = (NSLOT > 1) ? $clog2(NSLOT) : 1,
  localparam int SEG_W       = MAX_SEG_LOG2 + 1,
  localparam int TOT_W       = MAX_TXN_LOG2 + 1,
  localparam int WCW         = $clog2(WFIFO_DEPTH + 1)
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic               flush,
  input  wire logic               kill,
  // segment input
  input  wire logic               seg_valid,
  output logic                    seg_ready,
  input  wire logic [AW-1:0]      seg_dst,
  input  wire logic [SEG_W-1:0]   seg_len,
  input  wire logic [3:0]         seg_dtype,
  input  wire logic               seg_last,
  input  wire logic [DOM_W-1:0]   seg_domain,
  input  wire logic               seg_marker,
  input  wire logic [7:0]         seg_err,
  input  wire logic [TOT_W-1:0]   seg_total,
  // byte stream from the data buffer
  input  wire logic               head_valid,
  input  wire logic [DW-1:0]      head_data,
  input  wire logic [LW:0]        head_nbytes,
  output logic                    head_pop,
  // MemoryGuard client (write)
  output logic                    g_req_valid,
  input  wire logic               g_req_ready,
  output logic [DOM_W-1:0]        g_req_domain,
  output logic [3:0]              g_req_type,
  output logic [AW-1:0]           g_req_addr,
  output logic [15:0]             g_req_bytes,
  input  wire logic               g_rsp_valid,
  input  wire logic               g_rsp_ok,
  input  wire logic [3:0]         g_rsp_fault,
  input  wire logic [AW-1:0]      g_rsp_pa,
  // AW / W / B
  output logic                    aw_valid,
  input  wire logic               aw_ready,
  output logic [IDW-1:0]          aw_id,
  output logic [AW-1:0]           aw_addr,
  output logic [7:0]              aw_len,
  output logic [3:0]              aw_mtype,
  output logic [DOM_W-1:0]        aw_domain,
  output logic                    w_valid,
  input  wire logic               w_ready,
  output logic [DW-1:0]           w_data,
  output logic [W-1:0]            w_strb,
  output logic                    w_last,
  input  wire logic               b_valid,
  output logic                    b_ready,
  input  wire logic [IDW-1:0]     b_id,
  input  wire logic [1:0]         b_resp,
  // completion bookkeeping
  output logic [TOT_W-1:0]        acked_bytes,
  output logic                    end_ok_evt,        // last AW of the transaction was generated
  output logic                    end_err_evt,       // validation-error marker reached
  output logic [7:0]              end_err_code,
  output logic [TOT_W-1:0]        end_total,
  output logic                    wr_quiet,          // nothing left anywhere in the write path
  output logic                    wr_drained,        // nothing committed to the bus is still outstanding
  output logic                    wr_busy,
  output logic                    fault_evt,
  output logic [7:0]              fault_code,
  output logic [3:0]              fault_detail,
  output logic [AW-1:0]           fault_addr,
  // events
  output logic                    ev_aw_stall,
  output logic                    ev_w_stall,
  output logic                    ev_data_stall,
  output logic                    ev_wbuf_stall,
  output logic                    ev_out_stall,
  output logic                    ev_guard_stall,
  output logic                    ev_wr_burst,
  output logic [8:0]              ev_wr_beats,
  output logic [12:0]             ev_wr_bytes,
  output logic [WCW-1:0]          wf_level,
  output logic [31:0]             outstanding
);
  `include "sf_stream_dma_defs.svh"
  localparam logic [0:0] P_IDLE = 1'b0, P_RUN = 1'b1;

  // ------------------------------------------------------------------ planner
  logic              pst;
  logic [AW-1:0]     cur_addr;
  logic [SEG_W-1:0]  cur_rem;
  logic [3:0]        cur_type;
  logic [DOM_W-1:0]  cur_dom;
  logic              cur_last;
  logic [12:0] p_nbytes; logic [8:0] p_nbeats; logic [LW-1:0] p_off, p_endl;
  sf_stream_dma_plan #(.DW(DW), .BL(BL), .REM_W(SEG_W)) u_plan (
    .addr_lo(cur_addr[11:0]), .rem(cur_rem), .nbytes(p_nbytes), .nbeats(p_nbeats), .off(p_off), .endl(p_endl));

  // assembly queue {nbeats, off, endl}
  localparam int AQW = 9 + 2*LW;
  logic              aq_in_ready, aq_out_valid, aq_out_ready;
  logic [AQW-1:0]    aq_out_data;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(PLAN_DEPTH+1)-1:0] aq_level, gq_level;
  /* verilator lint_on UNUSEDSIGNAL */
  // guard queue {iova, nbeats, nbytes, type, txn_last}
  localparam int GQW = AW + 9 + 13 + 4 + 1;
  logic              gq_in_ready, gq_out_valid, gq_out_ready;
  logic [GQW-1:0]    gq_out_data;

  wire plan_go = (pst == P_RUN) && aq_in_ready && gq_in_ready && !kill;
  wire plan_last_burst = (cur_rem == SEG_W'(p_nbytes));
  wire txn_last_item   = plan_last_burst && cur_last;

  sfd_fifo #(.WIDTH(AQW), .DEPTH(PLAN_DEPTH)) u_aq (
    .clk(clk), .rst_n(rst_n), .flush(flush),
    .in_valid(plan_go && gq_in_ready), .in_ready(aq_in_ready), .in_data({p_nbeats, p_off, p_endl}),
    .out_valid(aq_out_valid), .out_ready(aq_out_ready), .out_data(aq_out_data), .level(aq_level));
  sfd_fifo #(.WIDTH(GQW), .DEPTH(PLAN_DEPTH)) u_gq (
    .clk(clk), .rst_n(rst_n), .flush(flush),
    .in_valid(plan_go && aq_in_ready), .in_ready(gq_in_ready),
    .in_data({cur_addr, p_nbeats, p_nbytes, cur_type, txn_last_item}),
    .out_valid(gq_out_valid), .out_ready(gq_out_ready), .out_data(gq_out_data), .level(gq_level));

  assign seg_ready = (pst == P_IDLE) && !kill;
  logic [TOT_W-1:0] last_total;

  // ------------------------------------------------------------------ assembler
  logic [8:0]        a_j;
  wire  [8:0]        a_nb  = aq_out_data[AQW-1 -: 9];
  wire  [LW-1:0]     a_off = aq_out_data[2*LW-1 : LW];
  wire  [LW-1:0]     a_endl= aq_out_data[LW-1 : 0];
  wire               a_first = (a_j == 9'd0);
  wire               a_lastb = (a_j == (a_nb - 9'd1));
  wire  [LW-1:0]     a_lo  = a_first ? a_off : '0;
  wire  [LW-1:0]     a_hi  = a_lastb ? a_endl : LW'(W - 1);
  wire  [LW:0]       a_need = {1'b0, a_hi} - {1'b0, a_lo} + 1'b1;

  logic              wf_in_ready, wf_out_valid, wf_out_ready, wf_in_valid;
  logic [DW+W:0]     wf_in_data, wf_out_data;
  sfd_fifo #(.WIDTH(DW + W + 1), .DEPTH(WFIFO_DEPTH)) u_wf (
    .clk(clk), .rst_n(rst_n), .flush(flush),
    .in_valid(wf_in_valid), .in_ready(wf_in_ready), .in_data(wf_in_data),
    .out_valid(wf_out_valid), .out_ready(wf_out_ready), .out_data(wf_out_data), .level(wf_level));

  logic              al_pop_ok;
  logic [DW-1:0]     al_data;
  logic [W-1:0]      al_strb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [LW+1:0]     al_cnt;
  /* verilator lint_on UNUSEDSIGNAL */
  logic              al_in_ready;
  wire asm_req = aq_out_valid && wf_in_ready && !kill;
  sf_stream_dma_align #(.DW(DW)) u_al (
    .clk(clk), .rst_n(rst_n), .flush(flush),
    .in_valid(head_valid), .in_ready(al_in_ready), .in_data(head_data), .in_nbytes(head_nbytes),
    .pop_req(asm_req), .pop_lo(a_lo), .pop_n(a_need), .pop_ok(al_pop_ok),
    .out_data(al_data), .out_strb(al_strb), .cnt(al_cnt));
  assign head_pop = al_in_ready;                 // buffer pops iff the aligner accepts (valid && ready)
  wire asm_beat = asm_req && al_pop_ok;
  assign wf_in_valid = asm_beat;
  assign wf_in_data  = {al_data, al_strb, a_lastb};
  assign aq_out_ready = asm_beat && a_lastb;

  logic [7:0] rdy_bursts;                        // complete bursts sitting in the W FIFO whose AW is not yet generated

  // ------------------------------------------------------------------ guard stage
  logic              g_v, g_pend;
  logic [AW-1:0]     g_iova;
  logic [8:0]        g_nbeats;
  logic [12:0]       g_nbytes;
  logic [3:0]        g_type;
  logic              g_tlast;
  logic [DOM_W-1:0]  g_dom;

  // AW queue {mtype, pa, iova, nbeats, nbytes, txn_last}
  localparam int WQW = 4 + AW + AW + 9 + 13 + 1;
  logic              wq_in_valid, wq_out_valid, wq_out_ready;
  /* verilator lint_off UNUSEDSIGNAL */
  logic              wq_in_ready;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [WQW-1:0]    wq_out_data;
  logic [$clog2(PLAN_DEPTH+1)-1:0] wq_level;
  wire rsp_take = g_pend && g_rsp_valid;
  assign wq_in_valid = rsp_take && g_rsp_ok;
  sfd_fifo #(.WIDTH(WQW), .DEPTH(PLAN_DEPTH)) u_wq (
    .clk(clk), .rst_n(rst_n), .flush(flush),
    .in_valid(wq_in_valid), .in_ready(wq_in_ready), .in_data({g_type, g_rsp_pa, g_iova, g_nbeats, g_nbytes, g_tlast}),
    .out_valid(wq_out_valid), .out_ready(wq_out_ready), .out_data(wq_out_data), .level(wq_level));

  wire gd_room = (32'(wq_level) < PLAN_DEPTH);
  wire gd_load = gq_out_valid && !g_v && !g_pend && gd_room && !kill;
  assign gq_out_ready = gd_load;
  assign g_req_valid  = g_v;
  assign g_req_domain = g_dom;
  assign g_req_type   = g_type;
  assign g_req_addr   = g_iova & ~(AW'(W) - AW'(1));
  assign g_req_bytes  = 16'(g_nbeats) * 16'(W);

  // ------------------------------------------------------------------ AW issue + slot table
  logic [NSLOT-1:0]  s_v;
  logic [12:0]       s_bytes [NSLOT];
  logic [AW-1:0]     s_iova  [NSLOT];
  logic              fs_found;
  logic [IDW-1:0]    fs;
  always_comb begin
    fs_found = 1'b0; fs = '0;
    for (int i = NSLOT - 1; i >= 0; i--) if (!s_v[i]) begin fs_found = 1'b1; fs = IDW'(i); end
  end
  wire [3:0]       wq_type  = wq_out_data[WQW-1 -: 4];
  wire [AW-1:0]    wq_pa    = wq_out_data[WQW-5 -: AW];
  wire [AW-1:0]    wq_iova  = wq_out_data[WQW-5-AW -: AW];
  wire [8:0]       wq_nb    = wq_out_data[13 + 9 : 14];
  wire [12:0]      wq_nbytes= wq_out_data[13 : 1];
  wire             wq_tlast = wq_out_data[0];
  wire aw_free  = !aw_valid || aw_ready;
  wire aw_issue = wq_out_valid && (rdy_bursts != 8'd0) && fs_found && aw_free && !kill;
  assign wq_out_ready = aw_issue;

  logic [15:0] committed;                         // W beats owed for AWs that were generated
  assign w_valid = (committed != 16'd0) && wf_out_valid;
  assign {w_data, w_strb, w_last} = wf_out_data;
  assign wf_out_ready = w_valid && w_ready;
  wire   w_hs = w_valid && w_ready;

  // ------------------------------------------------------------------ B ingest
  logic              bq_v;
  logic [IDW-1:0]    bq_id;
  logic [1:0]        bq_resp;
  assign b_ready = 1'b1;
  logic              b_known;
  logic [12:0]       b_bytes;
  logic [AW-1:0]     b_iova;
  always_comb begin
    b_known = 1'b0; b_bytes = '0; b_iova = '0;
    for (int i = 0; i < NSLOT; i++) if (32'(bq_id) == i) begin b_known = s_v[i]; b_bytes = s_bytes[i]; b_iova = s_iova[i]; end
    b_known = b_known && (32'(bq_id) < NSLOT) && bq_v;
  end
  wire b_ok = b_known && (bq_resp == 2'b00);

  logic f_proto, f_bus, f_guard;
  assign f_proto = bq_v && !b_known;
  assign f_bus   = b_known && (bq_resp != 2'b00);
  assign f_guard = rsp_take && !g_rsp_ok;
  always_comb begin
    fault_evt = f_proto || f_bus || f_guard;
    fault_code = `SFSD_ERR_NONE; fault_detail = 4'd0; fault_addr = '0;
    if (f_proto)      begin fault_code = `SFSD_ERR_PROTO;    fault_detail = 4'd1;              fault_addr = '0; end
    else if (f_bus)   begin fault_code = `SFSD_ERR_BUS_WR;   fault_detail = {2'b00, bq_resp};  fault_addr = b_iova; end
    else if (f_guard) begin fault_code = `SFSD_ERR_GUARD_WR; fault_detail = g_rsp_fault;       fault_addr = g_iova; end
  end

  // ------------------------------------------------------------------ sequential
  logic [31:0] n_out;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pst <= P_IDLE; cur_addr <= '0; cur_rem <= '0; cur_type <= '0; cur_dom <= '0; cur_last <= 1'b0; last_total <= '0;
      a_j <= '0; rdy_bursts <= '0; committed <= '0;
      g_v <= 1'b0; g_pend <= 1'b0; g_iova <= '0; g_nbeats <= '0; g_nbytes <= '0; g_type <= '0; g_tlast <= 1'b0; g_dom <= '0;
      s_v <= '0; aw_valid <= 1'b0; aw_id <= '0; aw_addr <= '0; aw_len <= '0; aw_mtype <= '0; aw_domain <= '0;
      bq_v <= 1'b0; bq_id <= '0; bq_resp <= '0; acked_bytes <= '0;
      end_ok_evt <= 1'b0; end_err_evt <= 1'b0; end_err_code <= '0; end_total <= '0;
      for (int i = 0; i < NSLOT; i++) begin s_bytes[i] <= '0; s_iova[i] <= '0; end
    end else begin
      end_ok_evt <= 1'b0; end_err_evt <= 1'b0;
      bq_v <= b_valid; bq_id <= b_id; bq_resp <= b_resp;
      if (aw_valid && aw_ready) aw_valid <= 1'b0;

      if (flush) begin
        pst <= P_IDLE; a_j <= '0; rdy_bursts <= '0; committed <= '0; g_v <= 1'b0; g_pend <= 1'b0;
        s_v <= '0; aw_valid <= 1'b0; acked_bytes <= '0;
      end else begin
        // ---- segment sequencing
        if (pst == P_IDLE && seg_valid && !kill) begin
          if (seg_marker) begin
            end_err_evt <= 1'b1; end_err_code <= seg_err; end_total <= seg_total;
          end else begin
            cur_addr <= seg_dst; cur_rem <= seg_len; cur_type <= seg_dtype; cur_dom <= seg_domain;
            cur_last <= seg_last; last_total <= seg_total;
            pst <= P_RUN;
          end
        end
        if (plan_go) begin
          cur_addr <= cur_addr + AW'(p_nbytes);
          cur_rem  <= cur_rem - SEG_W'(p_nbytes);
          if (plan_last_burst) pst <= P_IDLE;
        end
        if (kill && pst == P_RUN) pst <= P_IDLE;

        // ---- assembler beat counter / burst accounting
        if (asm_beat) a_j <= a_lastb ? 9'd0 : (a_j + 9'd1);
        rdy_bursts <= rdy_bursts + ((asm_beat && a_lastb) ? 8'd1 : 8'd0) - (aw_issue ? 8'd1 : 8'd0);

        // ---- guard stage
        if (gd_load) begin
          g_v <= 1'b1;
          {g_iova, g_nbeats, g_nbytes, g_type, g_tlast} <= gq_out_data;
          g_dom <= cur_dom;
        end
        if (g_v && g_req_ready) begin g_v <= 1'b0; g_pend <= 1'b1; end
        if (rsp_take) g_pend <= 1'b0;

        // ---- AW issue
        if (aw_issue) begin
          aw_valid <= 1'b1; aw_id <= fs; aw_addr <= wq_pa; aw_len <= 8'(wq_nb - 9'd1);
          aw_mtype <= wq_type; aw_domain <= g_dom;
          s_v[fs] <= 1'b1; s_bytes[fs] <= wq_nbytes; s_iova[fs] <= wq_iova;
          if (wq_tlast) begin end_ok_evt <= 1'b1; end_total <= last_total; end
        end
        committed <= committed + (aw_issue ? 16'(wq_nb) : 16'd0) - (w_hs ? 16'd1 : 16'd0);

        // ---- B ingest
        if (b_known) for (int i = 0; i < NSLOT; i++) if (32'(bq_id) == i) s_v[i] <= 1'b0;
        if (b_ok) acked_bytes <= acked_bytes + TOT_W'(b_bytes);
      end
    end
  end

  always_comb begin
    n_out = 32'd0;
    for (int i = 0; i < NSLOT; i++) n_out = n_out + 32'(s_v[i]);
  end
  assign outstanding = n_out;
  assign wr_drained = (s_v == '0) && !aw_valid && (committed == 16'd0) && !g_v && !g_pend;
  assign wr_quiet   = wr_drained && !aq_out_valid && !gq_out_valid && !wq_out_valid && (pst == P_IDLE) && !wf_out_valid;
  assign wr_busy    = !wr_quiet;

  assign ev_aw_stall    = aw_valid && !aw_ready;
  assign ev_w_stall     = w_valid && !w_ready;
  assign ev_data_stall  = asm_req && !al_pop_ok;
  assign ev_wbuf_stall  = aq_out_valid && !wf_in_ready && !kill;
  assign ev_out_stall   = wq_out_valid && (rdy_bursts != 8'd0) && !fs_found;
  assign ev_guard_stall = (rdy_bursts != 8'd0) && !wq_out_valid && (gq_out_valid || g_v || g_pend);
  assign ev_wr_burst    = aw_issue;
  assign ev_wr_beats    = aw_issue ? wq_nb : 9'd0;
  assign ev_wr_bytes    = b_ok ? b_bytes : 13'd0;
endmodule
`default_nettype wire
