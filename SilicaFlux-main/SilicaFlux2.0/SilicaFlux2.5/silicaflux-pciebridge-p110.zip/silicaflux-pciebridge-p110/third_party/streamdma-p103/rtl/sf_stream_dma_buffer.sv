// =============================================================================
// StreamDMA :: sf_stream_dma_buffer -- the data buffer: a reservation ring (reorder-tolerant beat FIFO)
//
// Space for a whole read burst is RESERVED, in issue order, when its AR is issued (rsv_*).  Response beats are written
// at (base + beat) in ANY order across bursts (fill_*), each marking its entry valid.  The consumer sees the entries in
// reservation order only: head_valid = the head entry has arrived.  This is what lets read responses return reordered
// or interleaved (different IDs) while the byte stream stays in program order, and it guarantees that response data
// always has a place to land (R never needs backpressure).
// DEPTH must be a power of two.  occ counts arrived-and-unconsumed beats, rsv counts reserved-and-unconsumed beats.
// Classification: SYNTHESIZABLE (storage is a register-file style array with one write and one asynchronous read port)
// =============================================================================
`default_nettype none
module sf_stream_dma_buffer #(
  parameter int DW    = 128,
  parameter int DEPTH = 64,
  localparam int LW   = $clog2(DW/8),
  localparam int IW   = $clog2(DEPTH),
  localparam int CW   = $clog2(DEPTH + 1)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             flush,
  // reservation
  input  wire logic             rsv_valid,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [8:0]       rsv_n,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic                  rsv_ok,
  output logic [IW-1:0]         rsv_base,
  // fill (response beat)
  input  wire logic             fill_valid,
  input  wire logic [IW-1:0]    fill_idx,
  input  wire logic [DW-1:0]    fill_data,
  input  wire logic [LW:0]      fill_nbytes,
  // drain
  output logic                  head_valid,
  output logic [DW-1:0]         head_data,
  output logic [LW:0]           head_nbytes,
  input  wire logic             head_pop,
  // status
  output logic [CW-1:0]         occ,
  output logic [CW-1:0]         rsv,
  output logic                  empty
);
  logic [DW-1:0] mem_d [DEPTH];
  logic [LW:0]   mem_n [DEPTH];
  logic [DEPTH-1:0] vld;
  logic [IW-1:0] rp, wp;                 // head pointer, reservation pointer

  assign rsv_ok   = ((16'(rsv) + 16'(rsv_n)) <= 16'(DEPTH));
  assign rsv_base = wp;
  wire   do_rsv   = rsv_valid && rsv_ok;
  assign head_valid = vld[rp];
  assign head_data  = mem_d[rp];
  assign head_nbytes = mem_n[rp];
  assign empty = (rsv == '0);

  wire pop = head_valid && head_pop;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      vld <= '0; rp <= '0; wp <= '0; occ <= '0; rsv <= '0;
    end else if (flush) begin
      vld <= '0; rp <= '0; wp <= '0; occ <= '0; rsv <= '0;
    end else begin
      if (do_rsv) wp <= wp + rsv_n[IW-1:0];
      if (pop)    rp <= rp + 1'b1;
      rsv <= rsv + (do_rsv ? rsv_n[CW-1:0] : '0) - (pop ? CW'(1) : '0);
      occ <= occ + (fill_valid ? CW'(1) : '0) - (pop ? CW'(1) : '0);
      if (fill_valid) vld[fill_idx] <= 1'b1;
      if (pop)        vld[rp] <= 1'b0;
    end
  end
  always_ff @(posedge clk) begin
    if (fill_valid) begin mem_d[fill_idx] <= fill_data; mem_n[fill_idx] <= fill_nbytes; end
  end
endmodule
`default_nettype wire
