// =============================================================================
// StreamDMA :: sf_stream_dma_align -- byte realigner (accumulator "gearbox")
//
// Input : runs of `in_nbytes` payload bytes, packed in lanes 0..in_nbytes-1 of in_data, in stream order.
// Output: a pop of `pop_n` bytes placed at lane offset `pop_lo`, with an explicit byte strobe.
// The accumulator holds up to 2*W bytes; bytes beyond `cnt` are always zero (an invariant the formal bench proves),
// so insertion is a shifted OR.  Push and pop may happen in the same cycle (pop uses the pre-push content).
// in_ready only needs the room for ONE FULL BEAT (cnt - popped <= W), which keeps ready independent of the data.
// Byte order is preserved: out byte stream == in byte stream (fv_align.sv).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_stream_dma_align #(
  parameter int DW  = 128,
  localparam int W  = DW/8,
  localparam int LW = $clog2(DW/8),
  localparam int CW = $clog2(2*DW/8 + 1)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              flush,
  input  wire logic              in_valid,
  output logic                   in_ready,
  input  wire logic [DW-1:0]     in_data,
  input  wire logic [LW:0]       in_nbytes,
  input  wire logic              pop_req,
  input  wire logic [LW-1:0]     pop_lo,
  input  wire logic [LW:0]       pop_n,
  output logic                   pop_ok,
  output logic [DW-1:0]          out_data,
  output logic [W-1:0]           out_strb,
  output logic [CW-1:0]          cnt
);
  logic [2*DW-1:0] acc;
  wire do_pop  = pop_req && pop_ok;
  wire do_push = in_valid && in_ready;
  assign pop_ok   = (cnt >= CW'(pop_n)) && (pop_n != '0);
  wire [CW-1:0] cnt_p = cnt - (do_pop ? CW'(pop_n) : '0);
  assign in_ready = (cnt_p <= CW'(W));

  // pop: bytes 0..pop_n-1 of acc -> lanes pop_lo..pop_lo+pop_n-1
  logic [DW-1:0] lowbytes;
  logic [W-1:0]  nmask;
  always_comb begin
    for (int i = 0; i < W; i++) begin
      nmask[i]    = (i < 32'(pop_n));
      lowbytes[8*i +: 8] = nmask[i] ? acc[8*i +: 8] : 8'h00;
    end
  end
  assign out_data = lowbytes << (8 * 32'(pop_lo));
  assign out_strb = nmask << pop_lo;

  wire [2*DW-1:0] acc_sh  = do_pop ? (acc >> (8 * 32'(pop_n))) : acc;
  wire [2*DW-1:0] ins     = {{DW{1'b0}}, in_data} << (8 * 32'(cnt_p));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      acc <= '0; cnt <= '0;
    end else if (flush) begin
      acc <= '0; cnt <= '0;
    end else begin
      acc <= acc_sh | (do_push ? ins : '0);
      cnt <= cnt_p + (do_push ? CW'(in_nbytes) : '0);
    end
  end
endmodule
`default_nettype wire
