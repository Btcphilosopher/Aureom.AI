# Vendored sources (unmodified)

Copied byte-for-byte from the SilicaFlux repository archive
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-streamdma-p103-r2.zip`
(archive SHA-256 10ef00dcb4ea6cda723a2433e508307690e3e09a3be4fa61915e5109066d01c7):

| Directory | Origin inside that archive | Role in P110 |
|---|---|---|
| `streamdma-p103/rtl/` | `silicaflux-streamdma-p103/rtl/stream_dma/` | StreamDMA core (the DMA engine the bridge connects to) |
| `p61-clouddpu/rtl/sfd_fifo.sv` | `.../third_party/p61-clouddpu/rtl/` | FIFO used by StreamDMA |
| `clouddma-p64/rtl/` | `.../third_party/clouddma-p64/rtl/` | `sfdma_perm_checker` (inside StreamDMA) and `sfdma_perm_table` (used here ONLY as the simulation stand-in for the MemoryGuard, exactly as StreamDMA's own bench does) |

`SHA256SUMS` lists every file; `scripts/check_vendor.py` re-verifies them against the repository archive.
Nothing here was edited. StreamDMA's own documentation is kept as `streamdma-p103/README_P103.md`.
