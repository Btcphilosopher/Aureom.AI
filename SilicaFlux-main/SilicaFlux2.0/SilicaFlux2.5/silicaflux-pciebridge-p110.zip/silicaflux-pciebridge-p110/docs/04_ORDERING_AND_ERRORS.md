# 04 — Transaction ordering, tags, completions, errors

## 1. Supported transaction set

| Direction | Handled | Everything else |
|---|---|---|
| host → chip (CQ) | **MRd, MWr** to the BAR windows (32/64-bit addresses, 1…`MMIO_MAX_DW` dwords for fabric windows, 1–2 dwords for registers) | I/O, atomics, locked read: **UR completion**, no data (`UNSUP_TYPE`). Messages and any other type: **dropped and logged** (`UNSUP_TYPE`). Config requests never arrive here (the endpoint owns config space) |
| chip → host (CC) | **Cpl, CplD** (SC / UR / CA) answering the above | CRS is never generated |
| chip → host (RQ) | **MRd, MWr** only (`SFPB_RT_MEM_RD/WR`), TC0, no RO/NS/IDO, 32/64-bit addresses as given by the context | nothing else is ever emitted (monitored: *"RQ: unsupported request type emitted"*) |
| host → chip (RC) | **Cpl, CplD** matched to an outstanding read tag | unexpected / late / inconsistent completions are counted and logged, never delivered |

## 2. Host → chip ordering (completer side)

The MMIO engine handles **one request TLP at a time, strictly in arrival order**. Consequences (all tested):

* **Posted writes are performed in order.** A write is "performed" when its SFB2 response has been seen; the next TLP is
  not even looked at before that (rule *R7*). There is no write buffering that could reorder or drop writes silently: if
  the engine or the stores are busy, `s_axis_cq_tready` drops and the endpoint back-pressures the link.
* **A read never passes an earlier write** — same mechanism: the earlier write has completed on SFB2 before the read starts.
* **Completions are generated in request order.** (PCIe permits reordering of completions; in-order is a legal subset and
  keeps the host-visible behaviour simple.) Between different tags nothing relies on order at the host.
* **Request boundaries.** A TLP that crosses a 4 KiB boundary, whose payload length differs from its dword count, whose
  byte enables violate the rules (below), or whose framing is wrong is **malformed**: it is *never executed (not even
  partially)*, never completed (PCIe: malformed TLPs are not completed), and is logged (`MAL_*`, `ERR_STATUS.MALFORMED`).
  This holds even though the payload arrives before the verdict: the request adapter is **store-and-forward** and rolls
  back a rejected TLP's payload.
* **Byte-enable policy** (`be_ok`): 1 dword → last-BE must be 0 (first-BE may be anything incl. 0 = zero-length read);
  2 dwords → both first and last non-zero; >2 dwords → first-BE ∈ {F,E,C,8}, last-BE ∈ {F,7,3,1} (contiguous from the
  outside in). Writes honour the byte enables per dword. Reads fetch and return **whole dwords**: bytes whose enable is 0 are *not* masked (PCIe leaves their value unspecified, so a host must not rely on them), but the completion's byte count and lower address are computed from the enables and checked by the root-model monitor (*"CC: byte count …"*, *"CC: lower address …"*). A 1-dword read with first-BE = 0 (the zero-length "flush" read) touches nothing and returns one dword of zeros.
* **Ordering attributes.** `attr` (RO / NS / IDO) is echoed in completions and otherwise **ignored**: the bridge always
  behaves as if strict ordering were requested. TC must be 0 unless `CTRL.TC_ANY` (then it is echoed).
* **Flow control.** The bridge has no credit logic. The endpoint owns link-layer credits; the bridge back-pressures CQ
  with `tready`. Queue sizes are parameters; occupancy and back-pressure cycles are counters (`HDRQ_MAX`, `PAYQ_MAX`,
  `BP_CQ`, `BP_CC`, `BP_SFB`).

## 3. Chip → host ordering (requester side)

* **Posted writes leave in order**: one write planner handles one burst at a time, its TLPs are emitted in address order,
  every MWr carries first/last BE from the strobes. B responses are returned in AW order.
* **Reads vs. writes.** DMA reads and DMA writes are independent transactions as on AXI (AR and AW have no mutual
  ordering) and share one RQ stream in the order the sequencer picks them (round-robin). The bridge promises ordering
  *within* a class and the three cross-class guarantees below, not a global read-behind-write order.
* **Write visibility ("strict" mode).** With `CTRL.WR_FLUSH_EN = 1` B is withheld until a zero-length memory read of the
  last written address has completed — PCIe orders a read behind earlier posted writes from the same requester, so its
  completion proves the data reached the root complex ordering point. Default (`0`) is "posted-accepted": B means the
  last TLP was handed to the endpoint.
* **No read data before it is complete and verified.** R beats are delivered in AR order only after the whole burst has
  arrived and passed every check; any failure returns the *whole* burst as SLVERR with zero data.

### 3.1 The posted-write ordering gate (cross-class guarantees)

Two things must not overtake posted writes the device has issued: **completions** (CC) answering a host read, and **MSI
interrupts**. CC and RQ are independent streams inside the endpoint, so "I emitted the write first" is not enough.

* Every RQ TLP carries a 6-bit running sequence number; the endpoint returns it (`rq_seq_num0/1`, `rq_seq_vld0/1`) when
  it has accepted the TLP into its own transmit path. The DMA adapter keeps modular counters `issued` and `acked`.
* When a completion (or an MSI) becomes ready, the gate **snapshots `issued`**; the first beat is held until `acked` has
  reached the snapshot (modular compare), then released. Later writes do not delay it (no starvation by new traffic).
* **Watchdog.** If TLPs are outstanding and no acknowledge arrives for `ORD_TIMEOUT` cycles (default 4096) the counters are
  resynchronised and a `DMA_ORDER` error is logged — the endpoint broke its acknowledge contract and the bridge says so
  rather than hanging. It still cannot produce a *wrong-order* delivery silently.
* **Weaker mode.** `RQ_ACK_ON_ACCEPT = 1` (endpoints with no sequence-number acknowledge) counts `tready` acceptance of
  the last beat as the acknowledge. That orders against the endpoint's *input stream*, not against the link; if the
  endpoint can re-order internally (or has independent CC/RQ transmit paths with different latencies) the guarantee is
  weaker. This is stated in the integration guide and was not verifiable without real IP.

Verified in simulation by an independent monitor in the root-complex model that checks, for every completion and MSI,
that no earlier posted write was still in flight (*"ORDER: completion overtook an earlier posted write"*, *"ORDER: MSI
arrived before an earlier posted write"*), with the gate removed as a mutation (M33, M34, M83, M69, M70).

## 4. Tags, outstanding table, completion matching (`sf_pcie_tag_tracker`)

* `TAGS` (default 16) tags, allocated **round-robin** so a freed tag is reused as late as possible. A read TLP that
  cannot get a tag waits (`TAG_STALL` counter); the bridge never reuses a live tag (monitored: *"RQ MRd: tag … reused"*).
* A completion is matched **by tag only**. Completions of one request arrive in address order and may be split
  arbitrarily; completions of *different* requests may interleave and complete in any order — nothing assumes in-order
  completion (tested with a root model that reorders and interleaves).
* Per completion, checked: tag owner · requester id (if `cfg_check_reqid`) · status · endpoint error code · poison ·
  dword count against the remainder · byte count against the remainder · lower address against the expected next address ·
  at the end, stream length = descriptor dword count and clean framing. A mismatch fails the request
  (`CPL_MISMATCH`/`OVERRUN`/`POISONED`/`UR`/`CA`/…) and returns zero data to the DMA.
* **Exactly one outcome per request** (OK or one error code).
* **Timeouts.** A per-tag age counter advances once per `2^TICK_LOG2` cycles (`TICK_LOG2` = 8); the request fails when
  age ≥ `CPL_TIMEOUT` ticks (default 0x40). *Choose `CPL_TIMEOUT` for your clock so it lies inside the PCIe completion
  timeout range your system uses; the default is a simulation value, not a recommendation.*
* **ZOMBIE quarantine.** A tag whose request failed in a way that can still produce a completion (timeout, inconsistent
  completion, reset) is **not reused**; late completions for it are dropped, counted and logged (`CPL_LATE`). Zombies are
  released by recovery after a quiet period (`REC_QUIET`) or by `CTRL.ZOMBIE_CLR`. If all tags become zombies the read
  path stalls visibly (`STATUS.N_ZOMBIE`, `TAG_STALL`) instead of risking tag aliasing.
* **Reset / FLR / link down:** every outstanding request fails with `CPL_RESET`. **A lost transaction is never reported as
  success** (mutations M63, M68 and M95 each break exactly that and are killed; M42 removes the quarantine of tags lost to a reset and is killed too).

## 5. Error handling summary

| Condition | Host sees | Device records |
|---|---|---|
| Malformed TLP (length, framing, BE, 4 KiB, discontinue, oversize) | nothing (no completion) | `ERR_STATUS.MALFORMED`, `ERR_LOG`, `CQ_BAD` counter |
| Unsupported non-posted type (I/O, atomic, locked) | Completion **UR** | `UNSUPPORTED` |
| Unsupported posted type / message | nothing | `UNSUPPORTED` |
| Poisoned request / AT≠0 / TC≠0 | non-posted: **UR**; posted: dropped | `POISONED` / `UNSUPPORTED` |
| Bad BAR id / aperture / out of window / spans windows / too long / window disabled | non-posted: **UR**; posted: dropped | `BAR` |
| Register read of an undefined offset, write to RO | read: **UR**; write: dropped | `CSR` |
| SFB2 read error | Completion **CA** | `FABRIC` |
| SFB2 write error | nothing (posted) | `FABRIC` |
| SFB2 response timeout | engine enters the **fatal** state; later fabric requests: reads **CA**, writes dropped + logged, registers keep working; `CTRL.CLR_FATAL` leaves it only when the fabric owes nothing | `FAB_TIMEOUT` / `FAB_FATAL` |
| DMA request violating its context (window, direction, format, strobes, W/AW) | SLVERR to StreamDMA, no TLP | `DMA_PROT`, `DMA_ERR_LOG*` |
| DMA read: UR / CA / poison / mismatch / timeout / reset | whole burst SLVERR with zero data | `CPL_ERR` / `CPL_TIMEOUT` / `CPL_UNEXP` / `DMA_BUS` |
| Unexpected completion (no owner) / late completion (zombie tag) | dropped | `CPL_UNEXP`, `CPL_UNEXPECTED` counter |
| Link down / FLR / soft reset | recovery FSM (§07) | `LINK` / `FLR` / `RECOVERED` |

Every row is exercised by a directed test and, where it has a mutation, by a mutant that is killed (§09).
