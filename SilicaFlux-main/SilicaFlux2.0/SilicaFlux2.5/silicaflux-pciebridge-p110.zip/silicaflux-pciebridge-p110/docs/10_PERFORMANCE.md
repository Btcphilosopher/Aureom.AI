# 10 — Performance measurement

**What these numbers are:** simulation **cycles at the endpoint stream boundary** (`tb/cpp/tb_perf.cpp`), with the bench's
link model (6 cycles per direction, `Env::cfg`), a configurable root-complex read latency and an SFB2 fabric model. They show
the *shape* of the bridge's behaviour — where it is latency-bound, where it is width-bound, what the overheads are. They are
**not** link throughput, not wall-clock time, and not a prediction for a real endpoint, whose own latency and credit behaviour
will dominate. Full tables: `reports/perf_w128.md`, `reports/perf_w256.md` (`make perf` regenerates both).

## 1. What is measured (and by what)

| Brief item | Measured by | Counter(s) in the chip (`PERF_SEL`) |
|---|---|---|
| MMIO latency | bench timestamps: CQ SOP accepted → CC SOP accepted; also the DUT's own counters | `MMIO_RD_LAT_SUM/CNT/MIN/MAX`, `MMIO_WR_LAT_SUM/CNT` |
| Outstanding requests | max / average tags in flight | `OUT_MAX`, `OUT_SUM`; `STATUS.N_OUTSTANDING` |
| DMA throughput | bytes / StreamDMA transaction latency (`len / cycles` from submit to completion record) | `DMA_RD_BYTES`, `DMA_WR_BYTES`, `DMA_ACTIVE` |
| Completion latency | RQ→RC per read request | `CPL_LAT_SUM/CNT/MAX` |
| Queue occupancy | high-water marks | `HDRQ_MAX`, `PAYQ_MAX` |
| Back-pressure cycles | cycles each interface was blocked | `BP_CQ`, `BP_CC`, `BP_RQ`, `BP_SFB` |
| Protocol overhead | header bytes vs payload bytes | `HDR_BYTES`, `PAY_BYTES` |
| Error events | events logged | `ERR_EVENTS`, `CPL_UNEXPECTED`; plus stall reasons `ORD_STALL`, `TAG_STALL`, `CRED_STALL` |

Counters are 64-bit, enabled by `CTRL.PERF_EN`, cleared by `CTRL.PERF_CLEAR`; read `PERF_LO` first (it latches `PERF_HI`).
36 counters (`SFPB_PC_*` in `rtl/sf_pcie_regs.svh`).

## 2. Results (DATA_W = 256; DATA_W = 128 differs only where noted)

**MMIO read latency** (cycles, CQ SOP → CC SOP; constant in the sweep, so min = avg = max):

| access | fabric latency 1 | 4 | 8 |
|---|---|---|---|
| CSR read, 1 dword | 7 | 7 | 7 |
| fabric read, 1 dword | 8 | 11 | 15 |
| fabric read, 16 dwords | 25 (27 @128) | 48 (50) | 72 (74) |

The 1-dword CSR read costs 7 cycles of which ≈ 3 are inside the engine (the DUT counter); the rest is store-and-forward framing
and completion packing. Fabric reads add the SFB2 latency plus roughly one cycle per dword (the engine issues one SFB2
request per dword — the fabric is a 32-bit port).

**Posted-write rate into the DataFabric** (fabric always ready): 1 dword/TLP → 0.17 dwords/cycle; 4 → 0.45; 16 → 0.73
(0.67 @128); 64 → 0.85 (0.77 @128). Single-dword writes are bounded by the in-order, one-TLP-at-a-time engine (≈ 6 cycles per
TLP including the SFB2 response wait); large writes approach the 1 dword/cycle SFB2 port limit.

**DMA throughput** (bytes/cycle, 16 B/cycle is the 128-bit StreamDMA datapath ceiling):

| direction | 1 KiB | 64 KiB, root latency 20 | 64 KiB, latency 100 | 64 KiB, latency 300 |
|---|---|---|---|---|
| host → device (reads) | 5.5 | 11.0 | 6.4 | 2.7 |
| device → host (posted writes) | 6.7 | 15.7 | — | 15.7 |

* **Reads are latency-bound**: throughput ≈ (bytes in flight) / (completion latency). With 4 read slots of 256 B the bridge has
  ≈ 1 KiB in flight; the measured average completion latency (44 / 134 / 352 cycles) explains the curve. More throughput at long
  latency needs more slots/tags (`RD_SLOTS`, `TAGS`, `BURST_LEN` are parameters; **only the defaults were built and verified**).
  The store-and-forward read return (a burst is delivered to StreamDMA only when whole and verified) is a deliberate
  correctness trade (no partial data, §04).
* **Writes are posted**, so they are unaffected by root latency and run at the datapath ceiling (15.7 of 16 B/cycle).
* Small transfers are dominated by fixed latency (submission → first TLP → completion → record).
* **MRRS/MPS 128/128 vs 512/256** changes the TLP count (512 vs 256 for 64 KiB) and header overhead (0.53 vs 0.49 header
  bytes per payload byte for reads) but barely the throughput.
* Tags in flight: ≤ 4 with the default slot count; 8 when 128-byte reads split each burst into two TLPs.

**Queue occupancy / back-pressure / overhead** (a CQ flood against a slow fabric with a stalled completion path; 356 TLPs,
10 168 cycles): request-header queue high-water 4, payload RAM high-water 4 beats; CQ back-pressured 8 957 cycles (88 %,
because the fabric is the bottleneck: `BP_SFB` 3 618), CC back-pressured 205 cycles; 1.28 header bytes per payload byte (small
register-sized TLPs); no error events. The queues are sized for the in-order engine; nothing was dropped (the
`queue_saturation` test fills them and checks every request is eventually served in order).

## 3. How to use this on hardware

Run a known DMA/MMIO workload, `PERF_CLEAR`, run, read the counters. Compare `BP_*` and `*_STALL` first: they say which
interface limits throughput (CQ/CC = host-side path, `BP_SFB` = fabric, `TAG_STALL`/`CRED_STALL` = requester resources,
`ORD_STALL` = the posted-write ordering gate waiting for acknowledges). Treat the simulation figures above as a *shape* check:
the same ratios (latency-bound reads, datapath-bound writes) should show up; the absolute values will not.
