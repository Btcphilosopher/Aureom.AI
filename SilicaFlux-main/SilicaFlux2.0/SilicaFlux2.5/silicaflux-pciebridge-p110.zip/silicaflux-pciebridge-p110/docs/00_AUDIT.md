# 00 — Repository audit (what existed, what was reused, what was missing)

Performed on the `btcphilosopher/Aureom.AI` checkout before any RTL was written. The SilicaFlux material lives as
archives under `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`; each was inspected by listing its files and reading its
README / docs, and the relevant RTL was read where it was going to be reused. Nothing in the repository was modified.

## 1. Answer to the central question

**There is no PCIe endpoint controller, PHY, SerDes or FPGA PCIe hard-IP wrapper anywhere in the repository**, and no
module that already speaks PCIe TLPs. The existing host-side blocks stop *above* the endpoint, at a declared boundary, and
say so themselves. Consequently this project builds the transaction layer that sits between such an endpoint and the
rest of SilicaFlux, verifies it against a simulated endpoint, and leaves the endpoint itself as an explicit, documented
integration point (`docs/ENDPOINT_INTEGRATION_GUIDE.md`). This is exactly the brief's instruction ("start with MMIO
registers and a simulated endpoint; add real FPGA PCIe integration only when valid endpoint IP and hardware are
available").

## 2. Findings per block

| Block (archive) | What it is | Relevance to P110 | Used? |
|---|---|---|---|
| **StreamDMA P103** (`silicaflux-streamdma-p103-r2.zip`) | Descriptor-driven copy engine with an AXI-style host-memory port (`ar/r/aw/w/b`, `mtype` + `domain` sidebands, beat-aligned bursts, strobe runs), a trusted-domain/guard contract, soft-reset contract | **The DMA engine the bridge connects to.** Its host-memory port is what the DMA adapter terminates and turns into RQ/RC TLPs | **Vendored unmodified** (`third_party/streamdma-p103`, SHA-256 listed) |
| **CloudDMA P64** (`sfdma_perm_checker`, `sfdma_perm_table`) | Permission checker (inside StreamDMA) and a permission table | The checker is part of StreamDMA. The table is what StreamDMA's own bench uses as the guard | **Vendored unmodified**; the table is used **only as the simulation stand-in for the MemoryGuard**, exactly as StreamDMA's bench does |
| **MemoryGuard P104** | Region-based memory *protection* (domain-bound range/permission checks). Its own README: "protection, **not translation** — not an IOMMU" | Natural guard for StreamDMA on a real chip | **Not integrated** (open item). P110 enforces its own per-context window at the PCIe egress instead (§05 of the docs), independently of any guard |
| **Meridian P83 / MeridianQoS P102 / DataFabric / DataFabric-NoC** | On-chip interconnect and the SFB2 bus protocol (valid/ready, one beat per transaction, in-order responses, rules R1–R12) | The bridge's DataFabric side is an **SFB2 32-bit master** that obeys those rules | The master follows the SFB2 rules by construction (one beat per transaction, request held until accepted, responses taken in order). The fabric itself is a **C++ model** that records every transaction and answers in order; **no standalone SFB2 protocol checker is included** in the bench, so rule conformance is exercised, not independently monitored (open item) |
| **ControlCore P21** | RV32 control subsystem with SFB2 control bus, interrupt controller, DMA | Intended owner of the *privileged* side (DMA context table, lock) | Interface only: the privileged port `priv_*` is what ControlCore would drive; no ControlCore instance in the bench |
| **PageWalker** | **Does not exist.** A name search of every archive for `walker / ptw / mmu / iommu / page_table` found only descriptor-chain walkers (`*desc_walker*`) and IOMMU-named guard interfaces in DomainGuard / MemoryGuard; none is an address-translation page walker | The brief says "PageWalker-or-equivalent" | **Equivalent provided**: per-context IOVA window with constant-offset translation (`sf_pcie_dma_ctx`, `sf_pcie_win_check`). It is *not* a page-table walker; see §05 for what that does and does not give you |
| **VirtualFoundry P87** | VirtIO block/net **device model** for simulated guests, bound to protection domains; "not a hypervisor and not PCIe SR-IOV" | Potential future client of the DMA contexts | Not used |
| **HostBridge M96** (`silicaflux-hostbridge-m96.zip`) | Albion host bridge speaking an internal "HTI" interface *after* header decode; its `docs/PCIE_INTEGRATION.md` specifies the **shim** to a third-party endpoint "(not provided or simulated)", and states nothing in the repository claims PCIe compliance | Closest prior art. HTI is a different protocol (flat host address, 8-bit table tags, in-order completions) from SFB2 + StreamDMA | **Not reused.** P110 is the TLP-level adapter that document describes as missing, but for the SFB2/StreamDMA side of the chip. Its guidance (UR/CA mapping, 4 KiB rule, BE handling, poisoned-write policy) was used as a cross-check |
| **HostLink P25** | BAR0 register ABI, queues, DMA engine, MSI *requests*, behind a generic AXI endpoint boundary, "no PCIe protocol logic" | Prior host ABI | Not reused (different register ABI); noted as a possible later software-compatibility layer |
| **IOShell P37** (`docs/04_PCIE_MILESTONE.md`) | Typed endpoint boundary (`pcie_bar_req_t`, `pcie_dma_req_t`, `pcie_msi_req_t`, `pcie_link_t`), `PCIE_EN = 0`; controller and PHY recorded as **BLOCKED**, "none in the repository" | Confirms the gap | Not reused |
| **NVMe HostCore P57** (`sfn_tb_pcie_host.sv`) | A testbench host model for an NVMe controller | Different abstraction level | Not reused |
| **FPGA material** (`silicaflux_de10_synth`) | Board-level synthesis scripts | No PCIe hard-IP wrapper (`qsys/.qip/pcie/hip` names absent) | Not applicable |
| **Interrupt controller** | ControlCore has one for the MCU; HostLink issues MSI *requests* | Neither is an endpoint-facing MSI adapter | P110 adds `sf_pcie_interrupt_adapter` |

## 3. Consequences for the design

1. **The endpoint interface had to be chosen, not discovered.** There is no vendor IP in the repository to read a port
   list from. The adapter targets the AMD UltraScale+ "Integrated Block for PCI Express" application interface
   (CQ/CC/RQ/RC AXI4-Stream, DWORD-aligned) because it is publicly documented and widely implemented. The descriptor
   bit layouts were written from the public description and **cross-checked only against open-source implementations
   of the same interface — not against a generated IP instance**. This is stated at every place it matters and again in
   `docs/ENDPOINT_INTEGRATION_GUIDE.md`. Everything vendor-specific is confined to `sf_pcie_request_adapter`,
   `sf_pcie_completion_adapter`, `sf_pcie_axis_{un,}pack`, the RQ descriptor builder inside `sf_pcie_dma_adapter`, and the
   MSI ports of `sf_pcie_interrupt_adapter`.
2. **No translation engine to call.** The DMA path therefore carries its own protection (context table + window checks +
   constant-offset translation), keeping the trust boundary inside this project rather than assuming a block that does
   not exist.
3. **The guard is a simulation stand-in.** StreamDMA is verified with the same `sfdma_perm_table` its own bench uses; a
   chip needs MemoryGuard (or equivalent) wired to StreamDMA's guard port. Listed as an open item, not hidden.
4. **Nothing from the repository was modified.** Vendored files are byte-identical (`third_party/SHA256SUMS`,
   `scripts/check_vendor.py`).
