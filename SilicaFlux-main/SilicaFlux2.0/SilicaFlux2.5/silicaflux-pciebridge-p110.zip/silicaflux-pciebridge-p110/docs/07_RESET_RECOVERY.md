# 07 — Reset, FLR, link-down and recovery

**Rule: a transaction lost to a reset is never reported as success.** Everything below follows from it.

## 1. Triggers

| Trigger | Detected by | Host-visible CSR state | DMA contexts (privileged table) |
|---|---|---|---|
| Link down (`ep_link_up` falls) | recovery FSM | **kept** (the host did not reset the function) | kept |
| FLR (`ep_flr_in_process` rises) | recovery FSM | **reset to defaults** (`CTRL` back to `0x23`: DMA disabled until the driver re-enables it) | kept (privileged) |
| `CTRL.SOFT_RESET` (W1) | CSR | reset to defaults | kept |
| `DMA_CTRL.SOFT_RESET` (W1) | CSR | unchanged | kept — only the DMA path is recovered |
| `rst_n` (hardware) | integrator | everything | everything (the lock bit too) |

## 2. The recovery FSM (`STATUS.REC_STATE`, port `rec_state`)

```
 RUN ──(fault)──► QUIESCE ──► DMA_DRAIN ──► WAIT_LINK ──► QUIET ──► DONE ──► RUN
                      │ (DMA-only soft reset skips WAIT_LINK)  ▲        │ link lost again → WAIT_LINK
```

* **RUN → QUIESCE.** Flush signals `rec_flush_mmio` / `rec_flush_dma` are raised (a DMA-only soft reset leaves MMIO
  alone). The DMA path is aborted (`dma_ctl_abort`). The event (`LINK_DOWN` / `FLR` / `SOFT_RESET`) is logged.
* **QUIESCE.** Wait until the completer engine, the CC path, the DMA adapter and StreamDMA are idle and the tag table is empty:
  the DMA gets one chance to finish *by itself* — every outstanding read fails with `CPL_RESET` (tags become **ZOMBIE**), every
  half-issued burst is answered with SLVERR, every posted-but-unacknowledged write burst is answered SLVERR (`CPL_RESET`).
  If that does not happen within `DRAIN_TIMEOUT` cycles the FSM proceeds anyway and logs `FAB_TIMEOUT` ("drain timeout
  is reported, never hidden").
* **DMA_DRAIN.** The adapter is wiped (`clr`) and StreamDMA's core is soft-reset (`dma_ctl_soft_reset`; the platform contract
  is `dma_soft_active`, which the adapter uses to restart its AR/AW/W streams clean). Host-visible registers are reset here for FLR / soft reset.
  Descriptors the host submitted that never finished are flagged **LOST** (per context, `CPL_STATUS[9]`, sticky) —
  the host learns they will never complete.
* **WAIT_LINK.** Wait for `ep_link_up && !ep_flr_in_process`; `ep_flr_done` tells the endpoint the function-level cleanup is done.
* **QUIET.** `REC_QUIET` cycles (default 0x400) with a good link, so late completions for lost tags can drain: they hit
  ZOMBIE tags and are dropped and counted (`CPL_LATE`), never delivered, never matched to a *new* request. A link
  drop during QUIET returns to WAIT_LINK.
* **DONE.** Zombies are released, `RECOVERED` is logged (sticky `ERR_STATUS.RECOVERED`, IRQ source 3): **the host must
  re-initialise** (re-enable `CTRL.DMA_EN`, re-read the LOST flags, resubmit). Flushes are released and the FSM returns to RUN.
  Zombies can also be released by software with `CTRL.ZOMBIE_CLR`.

## 3. What each part guarantees

| Part | Guarantee | Verified by |
|---|---|---|
| MMIO engine | A request in flight is dropped (reads: no completion is fabricated for a request the host will itself time out); the in-order engine restarts clean; the SFB2 fatal state is independent (`CLR_FATAL`) | `tb_reset/mmio`, `link_idle` |
| Tag tracker | Every outstanding request ends in exactly one `CPL_RESET` event; tags are quarantined, not reused | `tb_reset/dma_read`, `tb_dma/tag_quarantine` |
| DMA adapter | All bursts answered (R: SLVERR + zero data, B: SLVERR with `CPL_RESET`); planners and slot buffers wiped; ordering counters resynchronised | `tb_reset/dma_read`, `dma_write` |
| DMA submit | Accepted-but-unfinished descriptors flagged LOST; submissions refused during recovery (`DMA_RECOVERY`) | `tb_reset/dma_soft`, `hard` |
| Interrupts | A recovery raises source 3 (`RECOVERY`); masks and the vector map are reset only on FLR / soft reset (by construction: the `soft_rst` branch of `sf_pcie_interrupt_adapter`) | `tb_reset` checks that the recovery source is pending after a link flap; the reset-only-on-FLR/soft property is not separately tested |
| Ordering gate | Counters resynchronise on clear; no MSI/CC is held forever by writes lost to the reset | `tb_reset/*` + ordering monitor |

Scenarios run (`tb_reset`): link down while idle; during DMA read; during DMA write; during MMIO; FLR; soft reset;
DMA-only soft reset (with MMIO served and the quarantined tags visible in `STATUS`); a read burst parked in the planner;
a long outage (the FSM must hold `WAIT_LINK`); a stuck device whose drain times out (LOST is the only evidence);
hard reset under load; link flapping (down during QUIET, repeatedly). `tb_hostile/recovery` additionally checks what the
DMA adapter itself returns during a recovery, with StreamDMA out of the loop (parked read **and** parked write). Each recovery is followed by post-recovery checks
(registers read back as specified in §1, a new DMA descriptor is accepted and its data arrives byte-identical).

## 4. Integration notes

* After link-up the endpoint may re-enumerate; the bridge keeps its CSR values across a plain link loss but the *host's*
  BAR assignment can change — that is the endpoint's business, not the bridge's.
* `ep_flr_in_process` / `ep_flr_done` follow the AMD-style FLR handshake (`cfg_flr_in_process` / `cfg_flr_done`) as an
  assumption; check it against your IP (§6 of `02_ENDPOINT_INTERFACE.md`).
* Everything not listed here (hot reset, PERST#, power states, ASPM, error-message generation) is the endpoint's.
