# 11 — Limitations, open items, and what is *not* claimed

## 1. Not claimed

* **No PCIe compliance of any kind** — electrical, protocol, interoperability, or "compatible with" a specific vendor
  core. This is a transaction-layer bridge to a *documented stream interface*; the link, PHY, SerDes, data-link layer,
  flow-control credits, replay, config space and BAR sizing belong to an endpoint IP that does not exist in this repository.
* **No real-hardware result.** Nothing was run on an FPGA, with vendor IP, with a vendor root-port BFM, or on a host.
* **No timing, area, power or frequency claim.** `reports/synth*` are Yosys generic-gate *estimates* of structure; they carry no
  timing and no vendor/PDK mapping. Performance numbers are **simulation cycles at the endpoint stream boundary**, not
  wall-clock or link throughput.
* **No claim about the endpoint's behaviour.** Every endpoint assumption is listed in `02_ENDPOINT_INTERFACE.md §6`; none was
  verified.

## 2. Verification limits (read before trusting a green run)

* **Common-mode risk.** The RTL and the simulated endpoint/root model were written by the same author from the same
  description of the stream interface. They are independent *implementations* (the model's checks are not derived from the
  RTL), but a shared misreading of the vendor interface — a wrong bit position, a wrong `tuser` field — is invisible to
  this testbench by construction. This is the single largest residual risk and is only closed by a real endpoint or a
  vendor BFM.
* Simulation only (Verilator, two stream widths). No formal proof, no gate-level simulation, no CDC/RDC analysis, no
  coverage-closure metric beyond the directed list and the mutation campaign.
* Mutation testing shows the tests detect all 99 planted defects (`reports/mutation.md`; no mutant is classed as equivalent — see
  `09_VERIFICATION.md §5` for the survivors that were found and closed on the way); it does not prove the absence of other defects.
* No standalone SFB2 protocol checker (only a fabric model that answers in order).
* The write-1-to-clear same-cycle race fix is exercised for `IRQ_STATUS` and `ERR_STATUS[15:8]` (via an asynchronous egress event).
  `ERR_STATUS[7:0]` uses the identical expression but has no asynchronous event source in the bench.
* StreamDMA is verified with the simulation guard stand-in (`sfdma_perm_table`), not the MemoryGuard.

## 3. Functional limits

| Area | Limit |
|---|---|
| Transactions | MRd/MWr only (host→chip and chip→host); I/O, atomics, locked, messages, config are refused explicitly; no ECRC, no peer-to-peer, no relaxed-ordering / ID-based-ordering / no-snoop, no TPH, TC0 only (`CTRL.TC_ANY` accepts and echoes others), 8-bit tags (no 10-bit extended tags) |
| Functions | one physical function, no SR-IOV; the CQ function field is ignored |
| BARs | two memory BARs by parameter (default 64 KiB register + 1 MiB memory); no I/O BAR, no expansion ROM |
| Stream format | DWORD-aligned, 128/256 bit, no straddle, no 512 bit, no address-aligned mode |
| MMIO throughput | one TLP at a time, strictly in order; ≈ 0.17 dword/cycle for 1-dword posted writes, ≈ 0.85 for 64-dword (simulated; `10_PERFORMANCE.md`). Completions in request order, split at 128 B. Register reads should be single-dword |
| DMA translation | contiguous window + constant offset only: no page table, IOTLB, scatter-gather, ATS or per-page permissions; no PageWalker exists in the repository |
| DMA write shape | write bursts must have one contiguous strobe run (else SLVERR, nothing sent) — a design choice that matches StreamDMA, not a PCIe limit |
| DMA read latency/BW | a read burst is delivered only when whole and verified (store-and-forward); 4 read slots × 16 B beats and `TAGS` = 16 bound throughput at high root latency (measured: ≈ 11 B/cycle at 20-cycle latency, ≈ 2.7 B/cycle at 300 cycles) |
| Ordering | strong gate for completions and MSI against the bridge's own posted writes, **given** sequence-number acknowledges (`RQ_ACK_ON_ACCEPT = 1` orders only against the endpoint's input stream). Independent DMA reads and writes are not ordered against each other (as on AXI) |
| Interrupts | MSI only (single function, 16 vectors addressable); **MSI-X not implemented**; MSI request semantics unverified; INTx is a level output only |
| Recovery | exercised against a simulated endpoint's reset behaviour; a real IP may reset its stream interfaces differently or hold `tready` low during FLR |
| Discontinue | CQ discontinue (`tuser[41]`) honoured; RC discontinue **not connected by default** (`RC_DISC_BIT = -1`) |
| Completion timeout | counted in bridge cycles via a prescaled tick; the default is a simulation value |

## 4. Open items (what remains to make this ship-ready)

1. Connect a real endpoint and confirm every item in `02_ENDPOINT_INTERFACE.md §6` (bit layouts, `tuser`, sequence acknowledge,
   MSI semantics, FLR handshake, tag mode). Re-run the regression with the endpoint model replaced by a vendor BFM.
2. Integrate MemoryGuard (or equivalent) on StreamDMA's guard port and re-run the DMA tests with it in place of the stand-in.
3. Wire `priv_*` to ControlCore / the secure side and prove (by construction in the SoC) that the host cannot reach it.
4. A standalone SFB2 protocol monitor on the bridge's DataFabric port.
5. Formal properties for the ordering gate and the tag-quarantine invariant (candidates: "no completion/MSI before its snapshot is
   acknowledged", "a tag in ZOMBIE is never allocated").
6. MSI-X, if a host driver needs more than the MSI vectors.
7. Real synthesis with the target FPGA/ASIC flow: timing closure for the CQ→unpack→adapter and tag-tracker check chains; CDC if
   the fabric clock differs.
8. Parity/ECRC handling in the endpoint wrapper if the IP requires it.

## 5. Things that look wrong but are intended

* `CTRL` resets to `0x23` (DMA **disabled**) and is reset to that by an FLR / soft reset: the driver must re-enable DMA.
* Malformed requests get **no completion** (PCIe: malformed TLPs are not completed); the host will see a completion timeout of
  its own — the event is in `ERR_LOG` / `ERR_STATUS.MALFORMED`.
* The error log keeps the **first** error until cleared and counts the rest (saturating at 255); the DMA error log keeps the **last**.
* A quarantined (ZOMBIE) tag stays unusable until recovery completes or software clears it (`CTRL.ZOMBIE_CLR`): a stalled read
  path with `N_ZOMBIE > 0` is the bridge refusing to risk tag aliasing, not a hang.
