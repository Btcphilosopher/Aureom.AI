# 02 — Endpoint interface (the explicit adapter)

> **Verification status of this document.** There is no vendor PCIe IP in the repository, so none of what follows could
> be checked against a generated IP instance. The layouts are those of the **AMD UltraScale+ "Integrated Block for PCI
> Express" application interface (CQ / CC / RQ / RC AXI4-Stream, DWORD-aligned, 128 / 256 bit)** as described in its
> public product guide, and were **cross-checked only against open-source implementations of the same interface**.
> Treat every bit position as *to be confirmed against the product guide of the IP you actually generate* (§6 lists
> every assumption). The bridge does not invent a link protocol: it speaks this documented stream interface and
> nothing else.

All four streams use `DATA_W = 128` or `256` and the endpoint's **DWORD-aligned** mode: a packet is `HDR_DW` header
dwords immediately followed by the payload dwords, packed back-to-back, `K = DATA_W/32` dwords per beat, `tkeep` one bit
per dword, `tlast` on the last beat. (`sf_pcie_axis_unpack` / `sf_pcie_axis_pack` are the only modules that know this.)
Straddle mode (several TLPs per beat), address-aligned mode and 512-bit widths are **not** supported.

## 1. Completer request — CQ (host → chip): `s_axis_cq_*`

Descriptor = first 128 bits (4 dwords) of the packet:

| Bits | Field | Use in the bridge |
|---|---|---|
| `[1:0]` | AT | must be 0, else UR (non-posted) / drop (posted) |
| `[63:2]` | address[63:2] | BAR offset computed from it (`BAR base` is *not* needed: the IP supplies BAR id + aperture) |
| `[74:64]` | dword count (0 = 1024) | validated against the stream length |
| `[78:75]` | request type | `0` MRd, `1` MWr executed; `2/3` I/O, `4-6` atomics, `7` locked read → UR; messages and everything else → dropped + logged |
| `[79]` | poisoned | poisoned request → UR (non-posted) / drop (posted), never executed |
| `[95:80]` | requester id | echoed in the completion |
| `[103:96]` | tag | echoed in the completion |
| `[111:104]` | target function | **ignored** — single-function design; pair it with a single-function endpoint (requests are not distinguished by function) |
| `[114:112]` | BAR id | selects BAR_REG (default 0) / BAR_MEM (default 2); any other id → UR (reads) / dropped + logged (posted writes) |
| `[120:115]` | BAR aperture (log2 size) | must equal `BAR_*_AP` (16 → 64 KiB, 20 → 1 MiB), else refused as above |
| `[123:121]` | TC | must be 0 unless `CTRL.TC_ANY`, else UR / drop |
| `[126:124]` | attr | echoed |

`tuser` (`CQ_USER_W = 85`): `[3:0]` first-BE, `[7:4]` last-BE, `[41]` discontinue (parameter `CQ_DISC_BIT`; `-1` if not
connected). A discontinued TLP is treated as malformed and never executed. Other `tuser` bits are not used.

## 2. Completer completion — CC (chip → host): `m_axis_cc_*`

96-bit descriptor: `[6:0]` lower address, `[9:8]` AT=0, `[28:16]` byte count, `[29]` locked=0, `[42:32]` dword count,
`[45:43]` status (0 SC, 1 UR, 4 CA), `[46]` poisoned=0, `[63:48]` requester id, `[71:64]` tag, `[87:72]` completer id,
`[88]` completer-id-enable = 0 (**the IP inserts its own completer id**), `[91:89]` TC, `[94:92]` attr, `[95]` force-ECRC = 0.
`tuser` (`CC_USER_W = 33`) is driven 0 (no parity generation: **if your IP is configured to require parity, this is a
mismatch to resolve at integration**). Completions with data are split at the 128-byte boundary (RCB) and every
non-final completion ends on one. Error completions (UR / CA) carry no data.

## 3. Requester request — RQ (chip → host): `m_axis_rq_*`

128-bit descriptor: `[1:0]` AT=0, `[63:2]` address, `[74:64]` dword count, `[78:75]` type (`0` MRd, `1` MWr — nothing
else is ever emitted), `[79]` poison=0, `[95:80]` requester id = **0 with `[120]` requester-id-enable = 0 (the IP uses its
own)**, `[103:96]` tag (allocated by `sf_pcie_tag_tracker`, reads only), `[123:121]` TC = 0, `[126:124]` attr = 0 (no
relaxed ordering, no no-snoop, no ID-based ordering), `[127]` ECRC = 0.
`tuser` (`RQ_USER_W = 62`): `[3:0]` first-BE, `[7:4]` last-BE, `[27:24]` and `[61:60]` the 6-bit **sequence number**
(`seq = running TLP count mod 64`), everything else 0 (**no TPH, no parity**). `addr_offset`, `discontinue` are 0.

The sequence number is how the bridge learns when a posted write has actually been taken by the link layer
(`rq_seq_num0/1` + `rq_seq_vld0/1` from the endpoint) — the ordering gate depends on it (§04). **An endpoint
configuration that does not return these acknowledges cannot use the gate**; the parameter `RQ_ACK_ON_ACCEPT = 1` then
counts `tready` acceptance as the acknowledge instead, which orders against the *stream* but **not** against the link —
a weaker guarantee, documented in §04.

## 4. Requester completion — RC (host → chip): `s_axis_rc_*`

96-bit descriptor: `[6:0]` lower address, `[15:12]` error code (0 none, 1 poisoned, 2 bad status, 3 invalid length,
4 mismatch, 5 invalid address, 6 invalid tag, 8 FLR, 9 timeout — the IP's own receive checks), `[28:16]` byte count,
`[29]` locked, `[30]` request completed, `[42:32]` dword count, `[45:43]` status, `[46]` poisoned, `[63:48]` requester
id, `[71:64]` tag, `[87:72]` completer id, `[91:89]` TC, `[94:92]` attr. `tuser` (`RC_USER_W = 75`) is not interpreted
except an optional discontinue bit (`RC_DISC_BIT`, default `-1` = not connected — *check your product guide for the bit
position in your configuration*). An RC error code that the bridge does not know is reported as `SFPB_E_CPL_IPERR`.

## 5. Sideband used (read-only observation of the endpoint)

| Port | Meaning | If your IP lacks it |
|---|---|---|
| `ep_link_up` | link/DL up | tie high **only** for a fixed-link bench; link-down recovery is then never triggered |
| `ep_flr_in_process`, `ep_flr_done` | FLR in progress / bridge's "function-level cleanup done" | tie `in_process` low; FLR recovery then never triggers |
| `cfg_max_payload`, `cfg_max_read_req` (3 bit: 0 = 128 B … 5 = 4096 B) | negotiated MPS / MRRS bounding every TLP the bridge emits | must be connected: the bridge never exceeds them |
| `cfg_req_id`, `cfg_check_reqid` | requester id the endpoint uses; the tracker rejects completions that carry another id when enabled | tie `cfg_check_reqid` low |
| `fc_np_ok`, `fc_p_ok` | credit *hints* (e.g. "at least one NP/P header credit available") | tie high if the stream back-pressures by itself |
| `rq_seq_num0/1`, `rq_seq_vld0/1` | sequence-number acknowledge (two ports) | see §3 |
| `msi_enable`, `msi_mmenable[2:0]`, `msi_int[31:0]`, `msi_sent`, `msi_fail` | MSI request interface (`cfg_interrupt_msi_*` style, single function) | polling-only mode (`IRQ_CTRL.MSI_EN = 0`) |

## 6. Assumptions that **must** be confirmed at integration (none could be checked here)

1. CQ/CC/RQ/RC descriptor bit positions and `tuser` fields above (including the CQ discontinue bit 41, RQ sequence bits
   `[27:24]`+`[61:60]`, CC/RQ parity not required).
2. DWORD-aligned operation at the chosen width with the IP's "no straddle" setting.
3. Tag management: the bridge allocates RQ tags itself (`TAGS` ≤ 256, default 16). If the IP can be configured to
   assign/own RQ tags, that mode must be **off**.
4. The IP inserts requester / completer id when the descriptor id-enable bits are 0.
5. Extended-tag, relaxed-ordering, ID-based-ordering and no-snoop behaviour: the bridge neither sets nor expects them.
6. The IP returns every non-posted completion on RC with correct byte count / lower address (the bridge *checks* them and
   fails the request rather than trusting them).
7. The semantics of `msi_sent` / `msi_fail` and the one-hot hold (§06).
8. FLR / link-down signalling and the reset the IP applies to its own interfaces during recovery.

If any of these differ, only the modules listed in `00_AUDIT.md §3` change; the tag tracker, MMIO engine, BAR decoder,
planners, protection and CSRs do not.
