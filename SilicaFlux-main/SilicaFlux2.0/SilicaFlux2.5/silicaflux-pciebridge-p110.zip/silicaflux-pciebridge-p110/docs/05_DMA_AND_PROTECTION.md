# 05 — Host DMA through StreamDMA, and what protects the host

The device reads and writes host memory **only** through StreamDMA's host-memory port, which this bridge terminates
(`sf_pcie_dma_adapter`). Nothing else in the chip can originate a memory TLP: the RQ stream has a single driver.

## 1. Flow

```
host driver ──MWr to BAR0 page 0x1000*(1+c)──► sf_pcie_dma_submit ──► StreamDMA desc port (trusted desc_domain = c)
                                                                         │ copy engine (host <-> device memory)
 StreamDMA host-memory port (ar/r/aw/w/b + mtype + domain) ◄────────────┘
        │
        ▼
 sf_pcie_dma_adapter: EGRESS CHECK ──► read / write planners ──► tag tracker ──► RQ TLPs  /  RC completions
        │ violation: SLVERR to StreamDMA, DMA_ERR_LOG, no TLP
 StreamDMA completion record ──► per-context completion queue ──► host pops CPL_* ──► (IRQ_STATUS.DMA_CPL / DMA_ERR)
```

## 2. The trust anchors

| Question | Answer in this design |
|---|---|
| Who chooses the DMA context? | **Hardware**: the BAR0 page the host wrote. A descriptor's domain field is only a *claim* and must equal the page's context (`DMA_PERM` otherwise). The StreamDMA domain sideband on AR/AW is what the egress check trusts; StreamDMA derives it from the descriptor the bridge delivered with `desc_domain = context`. |
| Who configures windows? | **Only the privileged port `priv_*`** (to be wired to ControlCore / the secure side). The host BAR has **no path** to the context table. `PRIV_CTRL.LOCK` freezes it until reset. *If an integrator wires `priv_*` to host-reachable logic, the protection is void — stated in the integration guide.* |
| Can a context be edited while DMA is in flight? | No. Entries are staged and published atomically by `COMMIT`, which is refused while any DMA request is outstanding, when the entry is inconsistent (alignment, range overflow), or when locked. |
| Is a context's authority bounded? | Yes: `{valid, read-allowed, write-allowed, IOVA window, optional constant-offset translation, device window, max length}`. The context index **is** the StreamDMA trusted domain. |

## 3. Three independent checks (defence in depth — each one alone refuses an overreach)

1. **Submission** (`sf_pcie_dma_submit`, before StreamDMA sees the descriptor): `CTRL.DMA_EN`, ABI version / opcode / flags
   (single-descriptor `FIRST|LAST` only), memory types (exactly one side is host memory), length ≤ the context's maximum, the
   host range wholly inside the IOVA window with the right direction permitted, the device range inside the device
   window, domain claim = context. A rejected descriptor never reaches StreamDMA. Reject code in `SUBMIT_STATUS[13:8]`.
2. **StreamDMA's own guard** (domain-bound permission check inside the vendored core). In simulation this is
   `sfdma_perm_table`, the same stand-in StreamDMA's own bench uses; **on a chip it must be the MemoryGuard (or
   equivalent) — not integrated here (open item, see `11_LIMITATIONS.md`)**.
3. **Egress** (`sf_pcie_dma_adapter`, *before any TLP is formed*), on **every** AR and AW, independently of 1 and 2:
   context valid and `CTRL.DMA_EN` · direction permitted · memory type = host · size = full beat and INCR burst · beat-aligned
   envelope · burst within `BURST_LEN` · **the whole byte range inside the IOVA window with 65-bit arithmetic** (no
   wrap-around, no overflow) · for writes, strobes forming one contiguous run · W beat count = AW length · no id reuse
   while a read slot is busy. A violating request is answered with SLVERR (R beats with zero data / B), logged in
   `DMA_ERR_LOG0-2` (+ `ERR_STATUS.DMA_PROT`) and **no TLP leaves**.

The adversarial bench (`tb_hostile`, StreamDMA bypassed, a malicious AXI master wired to the host port) drives every
refusal above plus every legal burst shape; the host-memory model additionally asserts *"no TLP left the device"* and
*"host memory untouched"* for each refusal.

## 4. Address translation — what it is, and what it is not

The brief asks for a PageWalker "or equivalent". **No page walker exists in the repository** (`00_AUDIT.md`). What is
provided: per context, a **single contiguous IOVA window** and, with `XLAT_EN`, a **constant offset**
`bus = IOVA - IOVA_BASE + BUS_BASE` (otherwise identity). The window/offset is range-checked as a whole (65-bit) at
submission and again at egress for every burst; the TLP address is the translated bus address. There is **no page table,
no IOTLB, no per-page permissions, no scatter-gather, no ATS**. That is sufficient to confine a context to one
contiguous host buffer (e.g. a pinned region the driver registered); it is not a substitute for an IOMMU. The
`sf_pcie_win_check` module is the single shared implementation of the range check so the two sites cannot diverge.

## 5. Splitting and PCIe format rules

* Reads: one AR burst → 1..n MRd TLPs, each ≤ `MRRS` (from `cfg_max_read_req`) and ≤ `RD_MAX_TLP_BYTES`, **never crossing a
  4 KiB boundary**, each with its own tag; first/last BE from the byte range.
* Writes: one AW/W burst → 1..n MWr TLPs, each ≤ `MPS` (`cfg_max_payload`), never crossing 4 KiB; first/last BE derived from
  the leading/trailing strobes of the contiguous run (mutations M57/M58 break these; both killed — see `reports/mutation.md`).
* All-zero strobes → B OKAY with **no TLP** (nothing to send).
* The root-complex model in the bench *monitors every emitted TLP* for MPS/MRRS limits, 4 KiB crossing, BE legality,
  payload length, tag reuse, type, sequence number — independent of the RTL's own planner arithmetic.

## 6. Completion tracking and error propagation

* Reads complete only when every byte has arrived and every check passed (§04). R beats come back **in AR order**; a
  failed burst returns SLVERR on every beat with zero data and its own error code. Partial data is never delivered.
* Writes are acknowledged in AW order: B = OKAY (posted-accepted, or flush-confirmed with `CTRL.WR_FLUSH_EN`) or SLVERR
  with the egress / recovery code.
* StreamDMA turns SLVERR into a failed transaction; its completion record carries its own error code (R1[7:0]) **and** the
  bridge's PCIe-level code (R1[21:16], `SFPB_E_*`), plus bytes done / total and the error address. The host pops it
  from the context's own queue. Queues are **per context and never back-pressure StreamDMA**: a context that does not
  drain loses records (sticky `CPL_STATUS.OVERFLOW`), it cannot stall other contexts (mutation M79 breaks this; killed).
* A recovery that wipes an accepted-but-unfinished descriptor sets the sticky **`CPL_STATUS.LOST`** (cleared with
  `CPL_POP` bit 2): the host learns the descriptor will never complete instead of waiting forever (mutation M95).

## 7. Concurrency with MMIO

DMA and MMIO share the endpoint but not state: MMIO executes in the completer engine, DMA in the requester path.
`tb_dma/mmio_during_dma` runs register and fabric accesses while DMA is in flight and checks both. DMA submission
registers are ordinary BAR0 writes, so they obey §04 ordering (a doorbell write after the descriptor words is performed
after them).
