# 01 — Architecture

`sf_pcie_transaction_bridge` is a **transaction-layer** bridge. It contains no PCIe link, data-link, PHY, SerDes or
configuration-space logic and makes **no PCIe compliance claim**. It talks to the application-side stream interfaces of a
vendor endpoint core (AMD UltraScale+ style CQ / CC / RQ / RC, DWORD-aligned, 128 or 256 bit) that must be generated,
configured and verified separately.

```
 host CPU ── PCIe link ── [ endpoint IP: PHY, DLL, TL framing, config space, BAR sizing, MSI capability ]   (NOT in this repo)
                                │ CQ ▲CC            │ RQ   ▲ RC          cfg/status sideband        MSI request
                                ▼    │              ▼      │                  │                          ▲
 ┌──────────────────────────────────────────────────────────────────────────────────────────────────────┴─────────────┐
 │ sf_pcie_transaction_bridge                                                                                           │
 │                                                                                                                      │
 │  completer side (host -> chip)                              requester side (chip -> host, protected DMA)             │
 │  ───────────────────────────────                            ─────────────────────────────────────────────────         │
 │  sf_pcie_axis_unpack ─► sf_pcie_request_adapter             StreamDMA  ar/r/aw/w/b  (host-memory port, mtype/domain)  │
 │        (CQ framing)      store-and-forward, validation              │                                                │
 │                              │ validated request                    ▼                                                │
 │                              ▼                              sf_pcie_dma_adapter ◄── sf_pcie_win_check / ctx table     │
 │                   sf_pcie_mmio_engine                         egress protection, read/write planners,                 │
 │          classify ─ sf_pcie_bar_decoder                       RQ sequencer ─► sf_pcie_axis_pack ─► RQ                 │
 │          execute in order ──► sf_pcie_csr                                   ▲                                          │
 │                           ├─► sf_pcie_dma_submit ─► StreamDMA desc port     │ tag alloc / match                       │
 │                           │     (+ sf_pcie_dma_ctx, priv_* port)    sf_pcie_tag_tracker ◄── RC ◄─ completion adapter │
 │                           └─► SFB2 master (32-bit) ─► DataFabric                                                      │
 │                              │ completion beats                                                                       │
 │                              ▼                                                                                        │
 │  sf_pcie_completion_adapter (TX): CC descriptor builder + POSTED-WRITE ORDERING GATE ─► sf_pcie_axis_pack ─► CC        │
 │  sf_pcie_interrupt_adapter: status/mask/vector map, MSI request, ordering gate, polling-only mode                      │
 │  sf_pcie_perf: counters (latency, outstanding, throughput, occupancy, back-pressure, overhead, errors)                │
 │  recovery FSM (in the top): link-down / FLR / soft reset  ─ quiesce ─ drain ─ wait link ─ quiet ─ done               │
 └──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

## Module responsibilities

| Module | Responsibility | Vendor-specific? |
|---|---|---|
| `sf_pcie_axis_unpack` | CQ/RC framing: header on first beat, payload re-aligned to lane 0, `tkeep` hole / short-beat / header-shorter-than-descriptor detection, per-beat discontinue flag → `o_bad` on the last beat | yes (stream format) |
| `sf_pcie_axis_pack` | CC/RQ framing: header dwords immediately followed by payload, K dwords per beat, `tkeep` per dword | yes |
| `sf_pcie_request_adapter` | Decode the 128-bit CQ descriptor; **store-and-forward**: payload parked in a RAM and the header released only after the whole TLP was seen and validated (length vs descriptor, framing, byte-enable rules, 4 KiB rule, oversize); rejected TLPs are rolled back, never partially executed | yes (descriptor layout) |
| `sf_pcie_bar_decoder` | Map (BAR id, aperture, offset, length, direction) to a target (CSR page, DMA page, DataFabric register window, DataFabric memory window) or an explicit error code; a request must lie wholly inside one window; nothing is aliased | no |
| `sf_pcie_mmio_engine` | Classification (types, poison, AT, TC, BAR errors, fatal fabric), **strictly in-order** execution, SFB2 master, completion generation (split at 128 B, byte count / lower address from the byte enables, UR / CA with no data) | no |
| `sf_pcie_csr` | Global register page (identity, control, status, error status / log, timeouts, StreamDMA control, performance window) | no |
| `sf_pcie_dma_submit` + `sf_pcie_dma_ctx` | Per-context 4 KiB submission pages, descriptor validation against the **trusted context**, per-context completion queues; privileged context table with atomic commit / lock | no |
| `sf_pcie_completion_adapter` | TX: CC descriptor builder and the **ordering gate**. RX: RC descriptor decode + payload re-alignment for the tag tracker | yes (descriptor layout) |
| `sf_pcie_tag_tracker` | Outstanding-request table, out-of-order completion matching by tag, consistency checks, timeouts, **ZOMBIE quarantine**, flush on reset (never success) | no |
| `sf_pcie_dma_adapter` | StreamDMA host port ⇄ RQ/RC: egress protection, read/write planners (MRRS/MPS/4 KiB), strobe-run MWr formation, RQ sequencer with sequence-number accounting, in-order R delivery, B acknowledge modes | yes (RQ descriptor + `tuser`) |
| `sf_pcie_interrupt_adapter` | Sticky sources, masks, vector map folded to the host-enabled vectors, edge-triggered coalescing MSI request with retry / give-up logging, ordering gate, polling-only mode, `irq_level` | yes (MSI request ports) |
| `sf_pcie_perf` | 64-bit counters (36) behind `PERF_SEL/LO/HI` | no |
| `sf_pcie_fifo`, `sf_pcie_win_check` | Shared helpers (FWFT FIFO with flush; 65-bit window / range check used by both DMA checks) | no |

## Data paths

**MMIO write (host → chip).** CQ beats → unpack → request adapter (payload to RAM; on `tlast` the whole TLP is validated)
→ header FIFO → MMIO engine pops the header, the BAR decoder classifies it, payload dwords are written to the target
(CSR page / DMA page / SFB2 request with the dword's byte strobes). The engine does not look at the next TLP until the
SFB2 response of the previous write has been seen, so a later read can never pass an earlier write.

**MMIO read.** Same until classification; the engine reads the target, assembles the completion payload, and emits
one or more completion beats streams (split at the 128-byte boundary) to the completion adapter, which holds the first
beat until the **ordering gate** opens (§04), then packs it onto CC.

**DMA read (chip ← host memory).** StreamDMA issues an AR burst → egress check (context, direction, window, format) →
planner splits it into memory-read TLPs (≤ MRRS, ≤ `RD_MAX_TLP_BYTES`, never crossing 4 KiB), each owning a tag →
RQ. Completions come back on RC in any order across tags; the tag tracker validates and the data is deposited by
position into the burst's slot buffer; R beats are delivered in AR order once the burst is whole and clean. Any failure
returns the **whole** burst as SLVERR with zero data.

**DMA write (chip → host memory).** AW + W burst is store-and-forwarded, strobes must form one contiguous run, then
1..n memory-write TLPs (≤ MPS, 4 KiB rule) with first/last byte enables from the strobes. B is returned when the last
TLP was handed to the endpoint (default) or after a flush read completed (`CTRL.WR_FLUSH_EN`).

**Interrupts.** DMA record / DMA error / bridge error / recovery / StreamDMA IRQ / 3 external → sticky `IRQ_STATUS` →
(status & mask) rising edge → vector map → MSI request (held until the endpoint says sent/fail) or polling.

## Parameters (top level; defaults in `sf_pcie_transaction_bridge`)

`DATA_W` 128|256 · `TAGS` 16 · `NCTX` 4 · `MMIO_MAX_DW` 64 · `CPL_MAX_DW` 32 · `SFB_MAX_OUT` 2 · `BAR_REG_ID/AP` 0/16 (64 KiB) ·
`BAR_MEM_ID/AP` 2/20 (1 MiB) · `FREG_OFF/SIZE` 0x8000/0x8000 · `SFB_REG_BASE/SFB_MEM_BASE` · `RD_SLOTS/WR_SLOTS` 4/4 ·
`BURST_LEN` 16 · `ORD_W/ORD_TIMEOUT` 8/4096 · `TICK_LOG2` 8 · `RQ_ACK_ON_ACCEPT` 0 · `*_USER_W` (CQ 85, CC 33, RQ 62, RC 75) ·
`CQ_DISC_BIT` 41 · `DRAIN_TIMEOUT` 65536 · `HOST_MTYPE`.

## Clocks and resets

One clock (`clk`), the endpoint's user clock. `rst_n` is asynchronous-assert; **release must be synchronised by the
integrator**. Clock-domain crossing to the DataFabric / StreamDMA clock, if they differ, is the integrator's job and is
not modelled. Every internal soft reset (FLR, link-down, `CTRL.SOFT_RESET`, `DMA_CTRL.SOFT_RESET`) is sequenced by the
recovery FSM (§07).

## What is deliberately not here

Configuration-space handling (the endpoint owns it), BAR sizing, MSI-X, ATS/PRI, SR-IOV, atomics, I/O requests, messages
(anything but MRd/MWr/Cpl/CplD is refused explicitly), ECRC, peer-to-peer, multi-function. See `docs/11_LIMITATIONS.md`.
