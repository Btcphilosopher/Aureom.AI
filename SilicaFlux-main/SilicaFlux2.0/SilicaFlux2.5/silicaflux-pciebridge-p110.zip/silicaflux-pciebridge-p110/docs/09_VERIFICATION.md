# 09 — Verification

Everything here is **simulation** (Verilator 5.020) against the transaction-level host described in `08_SIM_HOST.md`. Read
`11_LIMITATIONS.md §2` first: the largest residual risk — a misreading of the vendor stream interface shared by RTL and
model — is invisible to this testbench by construction.

## 1. How to run

```bash
make lint      # Verilator -Wall over the bridge, both widths            -> reports/lint.log
make test      # every bench at DATA_W = 128 and 256 (+ tb_dma with 4 tags) -> reports/regression.log
make axis      # pack/unpack unit test, 4 width/header configurations
make perf      # performance measurement                                  -> reports/perf_w*.md
make mutate    # 99 planted defects (about an hour on 4 cores)           -> reports/mutation.md
make synth     # Yosys generic-gate estimates                             -> reports/synth/
make vendor    # vendored StreamDMA sources are byte-identical to the import
```

## 2. Brief §13 checklist → tests

| Required | Where it is verified (bench / test) |
|---|---|
| Register read/write | `tb_mmio`: `ident`, `scratch`, `fabric_reg` (every CSR, RO/W1C/WO behaviour, reserved offsets → UR, byte-strobe merge) |
| Multi-beat payloads | `fabric_mem_burst` (1…64 dwords, every alignment), `window_edges` (64 dwords ending on the BAR end), `queue_saturation` (600 mixed writes/reads) |
| Byte enables | `byte_enables` (300 random byte-enable writes against a byte-exact shadow; 200 partial-BE reads), `zero_len`, `malformed` (illegal BE patterns) |
| Tagging | `tags` (64 reads outstanding, each returns its own data), `tb_dma/tag_exhaustion`, root-model monitor *"tag reused while outstanding"* |
| Completion reordering | `tb_dma/reorder` (root completes different tags in any order, interleaves splits), `tb_rand` (random split / latency / reorder), `host_faults` (duplicate / truncated / wrong-tag / wrong-requester / over-long completions) |
| Invalid BAR | `invalid_bar` (unknown BAR id, wrong aperture, hole, spans two windows, too long, window disabled — reads UR, writes dropped + logged, no fabric access), `window_edges` |
| Malformed lengths | `malformed` (stream shorter/longer than descriptor, zero count, BE rules, 4 KiB crossing, oversize, discontinue, read with payload); `tb_hostile` for the DMA side; `tb_axis_unit` for framing |
| DMA permission errors | `tb_dma/submit_rejects`, `egress_overreach`, `ctx_rules` (privileged table: commit/lock/quiesce), `tb_hostile` (adversarial master: window, permission, domain, format, strobes, W/AW) |
| Queue saturation | `queue_saturation`, `tb_dma/tag_exhaustion`, `tb_hostile/backpressure` (stalls everywhere) |
| Reset under load | `tb_reset` (link-idle, DMA read, DMA write, MMIO, FLR, soft, DMA-only soft, parked read burst, long outage, stuck device, hard reset, flapping), `tb_hostile/recovery` (what the adapter itself returns during a recovery) |
| Error propagation | `fabric_errors`, `host_faults`, `cpl_isolation`, every `tb_reset` scenario (never "success" for a lost transaction) |
| Independent scoreboards | `08_SIM_HOST.md §3`: shadow models, TLP monitors, ordering monitor, memory side-effect checks; none reads RTL internals (the only exception, the three `dbg_*` probes of `tb_race`, observe collisions and judge a property of the outputs) |

## 3. Benches

| Bench | Content |
|---|---|
| `tb_mmio` | MMIO milestone: identity/registers, fabric windows, byte enables, tags, invalid BAR, malformed TLPs, queue saturation, fabric errors/timeouts, window edges, zero-length reads, error-log semantics — each in 3 modes (clean / back-pressured / slow fabric) |
| `tb_dma` | host↔device DMA: basic, unaligned, reorder, translated, strict acknowledge, MMIO during DMA, submission rejects, egress overreach, host faults (UR/CA/poison/bad count/lower/short/long/over-long/duplicate/truncated/wrong tag/wrong requester id/IP error codes/no completion), tag quarantine/exhaustion, completion-queue isolation (including *every* queue full), missing sequence-number acknowledges (watchdog + `DMA_ORDER`), privileged context rules. Also built with **4 tags** (`-GTAGS=4`, `TAGS_FEW`) so the tag table really runs out |
| `tb_irq` | polling-only mode, MSI (vector map, one-hot, coalescing), folding, retry/give-up, MSI disabled by the host, ordering behind posted writes, every source |
| `tb_reset` | link-down / FLR / soft / DMA-only / hard reset / flapping; quarantine during recovery; a parked read burst; the FSM waiting in `WAIT_LINK` through a long outage; a stuck device leaving the LOST flag as the only evidence; post-recovery checks |
| `tb_hostile` | StreamDMA bypassed, adversarial AXI master: every legal burst shape, every refusal (reads, writes, each strobe-run condition in isolation, domain, window, format), 4 KiB splitting with the boundary closer than MPS/MRRS, posted-credit hold, back-pressure, responses during a recovery (parked read **and** parked write) |
| `tb_race` | same-cycle collision of an event with its write-1-to-clear (IRQ_STATUS, ERR_STATUS) found by sweeping the event time |
| `tb_rand` | constrained-random system regression: random environment (back-pressure, latencies, completion splitting, MPS/MRRS, credits, fabric speed) and a random mix of MMIO, DMA in both directions (two contexts, one translated), host-side completion faults, invalid/malformed accesses and interrupts, against all scoreboards. (No link/reset events — those are `tb_reset`.) |
| `tb_axis_unit` | pack/unpack against an independent wire-format reference (4 configurations) |
| `tb_perf` | performance tables (`10_PERFORMANCE.md`) |

## 4. Results

Final run on the shipped RTL (`reports/regression.log`, `reports/axis_unit.log`, `reports/lint.log`):

```
tb_mmio DATA_W=128: 1833 checks, 0 failures
tb_dma DATA_W=128: 1995 checks, 0 failures
tb_irq DATA_W=128: 98 checks, 0 failures
tb_reset DATA_W=128: 255 checks, 0 failures
tb_hostile DATA_W=128: 718 checks, 0 failures
tb_race DATA_W=128: 217 checks, 0 failures
tb_rand DATA_W=128: 713 checks, 0 failures
tb_mmio DATA_W=256: 1833 checks, 0 failures
tb_dma DATA_W=256: 1995 checks, 0 failures
tb_irq DATA_W=256: 98 checks, 0 failures
tb_reset DATA_W=256: 256 checks, 0 failures
tb_hostile DATA_W=256: 718 checks, 0 failures
tb_race DATA_W=256: 217 checks, 0 failures
tb_rand DATA_W=256: 692 checks, 0 failures
[TAGS=4] tb_dma DATA_W=128: 1998 checks, 0 failures
[TAGS=4] tb_dma DATA_W=256: 1998 checks, 0 failures
ALL BENCHES PASS

tb_axis_unit DATA_W=128 HDR_DW=4: 288193 checks, 0 failures
tb_axis_unit DATA_W=128 HDR_DW=3: 276537 checks, 0 failures
tb_axis_unit DATA_W=256 HDR_DW=4: 223301 checks, 0 failures
tb_axis_unit DATA_W=256 HDR_DW=3: 216859 checks, 0 failures

DATA_W=128: 0 warning(s)/error(s)
DATA_W=256: 0 warning(s)/error(s)
```

* **15634 directed/random checks** across the benches (both stream widths, plus `tb_dma` with 4 tags) and **1,004,890 unit-test checks** in `tb_axis_unit`: **0 failures**.
* Verilator `-Wall` lint: 0 warnings at both widths. Icarus 12 elaborates the bridge. Yosys 0.33: all 17 runs (every module, and the top at both widths) pass `check -assert`, no latches (`reports/synth/summary.md`).
* Performance tables: `reports/perf_w128.md`, `reports/perf_w256.md` (`10_PERFORMANCE.md`).


## 5. Mutation testing (`scripts/mutate.py`)

`make mutate` plants **one defect at a time** in a scratch copy of the RTL, rebuilds the combined bench (every program of §3, `DATA_W = 256`) and runs it. A mutant is **killed** if any test fails. Two further killers exist where the combined bench is structurally blind: the pack/unpack unit test (framing mutants whose effect the request adapter tolerates, e.g. an empty trailing beat) and `tb_dma` built with 4 tags (tag-allocation mutants — the default build never runs out of tags). The whole project tree is **frozen into a snapshot** before the run, so edits made while it runs can never leak into a mutant build, and the unmodified baseline must pass first.

**Final campaign: 99 mutants, 99 killed, 0 survived, 0 did not build** (`reports/mutation.md`, one row per mutant with the first failing check).


### Survivors found along the way and how each was closed

The first complete runs on the original test suite left **19 survivors**. None was an equivalent mutant: each exposed a **test gap**,
closed by a new test (no RTL change was needed for any of them). Two mutants were added later (M98, M99) with a real RTL fix.

| Mutant | Why it survived | Closed by |
|---|---|---|
| M01 | an exactly-full final beat spilling into an empty trailing beat is invisible at system level (the request adapter tolerates it) | `tb_axis_unit` invariant "canonical beat count" counts as a killer |
| M15 | a window-start error is masked by the BAR decoder's own redundant self-check (`win_lo > boff`) | mutant redefined to move bound **and** self-check; `window_edges` kills it |
| M20 | zero-length read returned stale data; nothing checked the data | `tb_mmio/zero_len` |
| M32 | error-log "events not recorded" counter frozen; nothing read it | `tb_mmio/errlog` (also exposed that the register-map text said "last error" while the log keeps the **first**) |
| M40 | an over-long completion with a consistent byte count was never injected | new fault `OVERLEN` in `tb_dma/host_faults` |
| M42 | quarantine of tags lost to a reset is visible only *during* the recovery window | `tb_reset/dma_soft` reads `STATUS.N_ZOMBIE` in the quiet period (MMIO is not flushed in a DMA-only recovery) |
| M44 | the requester-id check was never exercised | fault cases `WRONG_REQID`, `WRONG_TAG`, `DUP_FIRST`, `TRUNC` |
| M55, M56 | the three strobe-run conditions masked each other (every refusal test tripped two at once) | isolating strobe patterns in `tb_hostile/writes` |
| M59, M61 | the 4 KiB limit coincided with MPS/MRRS in every test, so "one dword too many" never showed | `tb_hostile/boundary` (boundary closer than MPS/MRRS, six offsets, reads and writes) |
| M63 | the read planner's abort path cannot be seen through StreamDMA (the recovery's abort masks it) | `tb_hostile/recovery`: adversarial master, burst parked by withheld credits, link killed |
| M68 | same for a posted write parked in the write planner | `tb_hostile/recovery` (write part) |
| M71 | a missing sequence-number acknowledge was never injected | `Env::drop_acks`, `tb_dma/missing_acks` |
| M72 | the posted-credit hint was never withheld | `tb_hostile/credits` |
| M73 | the default build has 16 tags and never runs out | `tb_dma` built with 4 tags (regression configuration **and** second mutation killer) |
| M79 | isolation only matters when **every** context's queue is full (an empty fourth queue hid it) | `tb_dma/cpl_isolation` extended to all four contexts |
| M94 | holding `WAIT_LINK` through an outage was never observed | `tb_reset/wait_link` |
| M95 | the LOST flag is the only evidence only when the device is stuck and no record can exist | `tb_reset/lost` (device holds write responses, the drain times out) |
| M98, M99 | added when a code review found that a sticky bit lost an event arriving in the **same cycle** as its write-1-to-clear | RTL fix + `tb_race` (cycle-exact collision sweep) |

**What mutation testing does and does not show.** It shows that the tests notice these 99 defects, which were chosen by the author
and concentrate on the properties the brief names (framing, BAR decode, ordering, tagging, quarantine, protection, recovery). It
is not a coverage metric, it does not prove the absence of other defects, and — like the rest of this verification — it cannot
reveal a misunderstanding of the vendor interface that the RTL and the bench share (`11_LIMITATIONS.md §2`).


## 6. Defects the verification and tooling found in this project's own RTL

Recorded because they show what the process is worth, and because each is now covered by a test or a tool check:

| Found by | Defect | Fix |
|---|---|---|
| directed test | fatal-state abort also hit register accesses | engine abort limited to fabric reads |
| directed test | interrupt vector search had no wrap-around | wrap-around added (M84) |
| directed test | the MSI retry-limit default landed in the wrong nibble of `IRQ_CTRL` | fixed (M85) |
| reset test | tag tracker ignored `zombie_clr` while flushing; recovery-done event never set; descriptors lost to a wipe left "pending" forever (no LOST flag) | fixed; LOST flag (M95) |
| reset test | adapter not wiped at StreamDMA's actual core reset (`dma_soft_active`) | contract wired |
| directed test | a same-ID AR could corrupt an in-flight slot | error-entry redesign |
| synthesis (Yosys 0.33) | `int'()` casts not accepted by the repository's flat-SV subset | `32'()` |
| mutation testing | `ERR_LOG` count / zero-length-read data / 4 KiB limit one dword too loose / strobe-run conditions masking each other / tracker over-length and requester-id checks untested / planner abort path unobserved | tests added (§5) |
| code review while documenting | a sticky status bit lost an event arriving in the **same cycle** as its write-1-to-clear (`IRQ_STATUS`, `ERR_STATUS`) | `(status & ~clear) \| event`; `tb_race` + M98/M99 |
| Yosys `check -assert` | `acked_q` driven from two `always_ff` blocks (simulation tolerated it) | single driver |
| Yosys elaboration | `sf_pcie_perf` mixed a synchronous clear into an asynchronous-reset condition (simulation tolerated it) | separate async-reset and sync-clear branches |
| bench race exposed by the `DMA_EN` gate | tests started DMA before the posted `CTRL` write had landed | settle delay in the setup helper (the gate is correct) |
