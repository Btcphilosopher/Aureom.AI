# 08 — The transaction-level simulation host (and what it is *not*)

Verification of the bridge uses a **transaction-level host + simulated endpoint**. It is deliberately separate from
physical-link verification: nothing here exercises or claims anything about the PCIe link.

**It does not model, and therefore does not verify:** PHY / SerDes / equalisation, LTSSM, data-link layer (ACK/NAK,
replay, sequence numbers on the wire), flow-control credits and updates, ECRC, config space / BAR sizing / capability
lists, MSI capability registers, power states, hot reset, correctable/uncorrectable AER, ordering *inside* a real
switch or root complex, real vendor-IP timing or reset behaviour. A passing run says **"the bridge's transaction logic
behaves correctly against this independently written model of the endpoint's stream interface"** — nothing more.

## 1. Structure

```
   C++ bench (tb/cpp/*.cpp)                                     Verilated RTL (tb/sv/sf_pcie_sim_top.sv)
   ┌────────────────────────────────────────┐                  ┌────────────────────────────────────────────────┐
   │ Env (tb_env.h)                          │  CQ / RC beats   │  sf_pcie_transaction_bridge   (DUT)            │
   │  host driver: MMIO read/write/raw TLP   ├─────────────────►│                                                │
   │  endpoint model: CQ/CC/RQ/RC streams,   │◄─────────────────┤  CC / RQ beats, MSI request, SFB2 master       │
   │    link latency, back-pressure, MSI     │                  │                                                │
   │  root complex: host memory, completion  │   h_* port       │  sf_stream_dma (vendored, unmodified)          │
   │    split/reorder/fault injection        │◄───────────────► │  sfdma_perm_table (guard stand-in)             │
   │  DataFabric model (SFB2 slave)          │                  │  mtype splitter (HOST → bridge, else → dev_*)  │
   │  device-memory model (StreamDMA dev port)│                 │  adversarial AXI master (x_*, selectable)      │
   │  monitors + independent scoreboards     │  dbg_* probes    │  bench-only collision probes (hierarchical)    │
   └────────────────────────────────────────┘                  └────────────────────────────────────────────────┘
```

## 2. What the model does

* **Host driver.** Memory read/write TLPs to BAR0 / BAR2 with arbitrary lengths, byte enables, alignments and tags;
  *raw* TLP injection for malformed requests (wrong length, bad byte enables, 4 KiB crossing, discontinue on any beat,
  payload larger/shorter than declared, unsupported types, poisoned); multiple reads outstanding with their own tags.
* **Endpoint behaviour.** Drives CQ/RC and consumes CC/RQ exactly as the stream interfaces in `02_ENDPOINT_INTERFACE.md`
  describe (header packing, `tkeep`, `tlast`, `tuser`), with configurable per-direction latency, random `tvalid` gaps and
  `tready` stalls, credit hints (`fc_np_ok`/`fc_p_ok`), sequence-number acknowledges, link-up/FLR sidebands, MSI
  `sent`/`fail` (with injected failures), and negotiated MPS/MRRS (`cfg_max_payload`/`cfg_max_read_req`).
* **Root complex for DMA.** Sparse host memory; serves the bridge's reads after a configurable service time, splitting
  the completion (whole / at 64 B / at 128 B / at random dword boundaries), **reordering and interleaving completions of
  different tags**, and injecting faults for the next matching read: UR, CA, poison, dropped completion, bad byte count,
  bad lower address, short, long, duplicated first completion, wrong tag, wrong requester id, truncated, endpoint IP error
  code, FLR error code. Posted writes land in order after the link latency.
* **Fabric and device.** An SFB2 slave (registers + RAM, random latency/ready, injected errors and hangs) and a device
  memory behind StreamDMA's device port.
* **Adversarial master.** A selectable AXI master wired straight into the bridge's host-memory port (StreamDMA bypassed)
  for the egress-protection tests.

## 3. Independent checking

Everything is judged against references that are **not derived from the RTL**:

| Check | Source of truth |
|---|---|
| Register / memory / byte-enable results | a software shadow model written in the bench |
| Every CC TLP | monitor: byte count, lower address, size ≤ 128-B RCB rule, error completions carry no data, tag/requester id known, payload = dword count, non-final beats full, `tkeep` contiguous |
| Every RQ TLP | monitor: type ∈ {MRd, MWr}, ≤ MPS / MRRS, no 4 KiB crossing, legal byte enables, length = payload, TC/attr/AT/poison zero, **tag not reused while outstanding**, **sequence number = running TLP count** |
| Ordering | monitor: no completion and no MSI reaches the root while an earlier posted write is still in flight |
| DMA data | byte-for-byte comparison of device memory against host memory (and against a strobe-exact shadow for writes) |
| Host memory side-effects of refused requests | memory untouched, "no TLP left the device" |
| MSI | one-hot, vector as mapped / folded, count, ordering |
| Error reporting | `ERR_LOG` / `DMA_ERR_LOG` codes compared with what the test injected |

A scoreboard failure aborts the bench with a non-zero exit code (`run_all.sh`, `make test`).

## 4. Bench-only probes

`sf_pcie_sim_top` exposes three `dbg_*` outputs that read internal strobes by hierarchical reference. They exist for one
test (`tb_race`), which needs to know the exact cycle on which an event and a write-1-to-clear coincide. They do not exist
in the design and are not part of any deliverable RTL.

## 5. What a real-endpoint bring-up still needs

See `ENDPOINT_INTEGRATION_GUIDE.md`: connect the real IP, re-run the same tests with the C++ endpoint model replaced by a
vendor-supplied PCIe BFM (root-port VIP) or by hardware, and confirm each assumption in `02_ENDPOINT_INTERFACE.md §6`.
