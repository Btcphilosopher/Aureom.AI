# Endpoint integration guide

> **Status: a plan, not an experience report.** No PCIe endpoint IP and no hardware was available while this was built
> (`docs/00_AUDIT.md`). Nothing in this guide has been executed against a real endpoint. It tells the integrator what the
> bridge needs, what to configure, what to connect, what to confirm and how to bring it up in an order that localises
> faults. Where the guide says *confirm*, the bridge was written to a public description and **could not be checked**.

The brief's rule applies: **add real FPGA PCIe integration only when valid endpoint IP and hardware are available.**
The bridge, the simulated endpoint and the register map are ready for that step; this document is what the step needs.

## 1. What you must bring

1. A PCIe endpoint IP with an **AXI4-Stream CQ / CC / RQ / RC application interface in DWORD-aligned mode, 128 or 256 bit,
   single function** (the AMD UltraScale+ "Integrated Block for PCI Express" interface is the one this bridge was written to;
   see `02_ENDPOINT_INTERFACE.md`). Other interfaces (Avalon-ST, address-aligned AXI-S, straddle, 512 bit, AXI-MM bridge mode)
   need a different adapter — only the modules listed in `00_AUDIT.md §3` change.
2. The endpoint's user clock as the bridge clock (or a clock-domain crossing you provide, see §4).
3. The StreamDMA instance (vendored in `third_party/`) and its guard (MemoryGuard or equivalent — **not** the simulation
   `sfdma_perm_table`), the DataFabric SFB2 slave side, and a privileged-side master for the `priv_*` port.

## 2. Endpoint IP configuration checklist (confirm each against the product guide)

| Setting | Required | Why |
|---|---|---|
| Interface width | 128 or 256 bit = `DATA_W` | framing modules |
| Alignment mode | DWORD-aligned, **no straddle** | `sf_pcie_axis_{un,}pack` assume header immediately followed by payload |
| BAR0 | memory, 64 KiB, BAR id 0 (`BAR_REG_ID/AP` = 0/16) | CSR page, DMA pages, fabric register window |
| BAR2 | memory, 1 MiB, BAR id 2 (`BAR_MEM_ID/AP` = 2/20) | fabric memory window |
| Other BARs | disabled | any other BAR id is refused with UR |
| Functions | 1 physical function, no SR-IOV | the function field is ignored |
| Max payload / read-request | any; wire `cfg_max_payload`, `cfg_max_read_req` | every emitted TLP obeys them |
| RQ tag handling | **bridge assigns tags** (up to `TAGS`); IP-managed tags **off** | the tracker owns the tag space |
| Parity on CC/RQ `tuser` | off (the bridge drives 0) | else a parity generator is needed in the wrapper |
| Sequence-number acknowledge (`rq_seq_num/vld`) | enabled and wired | needed for the ordering gate (else `RQ_ACK_ON_ACCEPT = 1`, weaker) |
| MSI | enabled, single function, ≥ the number of vectors you map; wire `msi_*` | else run polling-only |
| FLR | supported; wire `ep_flr_in_process` / `ep_flr_done` | else tie in-process low |
| Completion timeout | note its range; choose `CPL_TIMEOUT` inside it | the default is a simulation value |

## 3. Port connections

| Bridge port | Connect to | Note |
|---|---|---|
| `s_axis_cq_*` | IP CQ master (`m_axis_cq_*`) | `CQ_USER_W`, `CQ_DISC_BIT` must match the IP's `tuser` |
| `m_axis_cc_*` | IP CC slave | `CC_USER_W` (parity ⇒ extend the wrapper) |
| `m_axis_rq_*`, `rq_seq_num0/1`, `rq_seq_vld0/1` | IP RQ slave and sequence-number outputs | `RQ_USER_W = 62` is the 256-bit/128-bit layout assumed |
| `s_axis_rc_*` | IP RC master | `RC_USER_W`, `RC_DISC_BIT` (default: not connected) |
| `ep_link_up` | IP "user link up" | falling edge = recovery |
| `ep_flr_in_process`, `ep_flr_done` | IP FLR in-process / done | |
| `cfg_max_payload`, `cfg_max_read_req` | IP negotiated values | |
| `cfg_req_id`, `cfg_check_reqid` | the id the IP uses; tie `cfg_check_reqid = 0` if you cannot supply it | |
| `fc_np_ok`, `fc_p_ok` | "credit available" hints, or **tie to 1** | the stream already back-pressures |
| `msi_enable`, `msi_mmenable`, `msi_int`, `msi_sent`, `msi_fail` | IP `cfg_interrupt_msi_*` | **verify semantics** (§06 of the docs) |
| `sfb_*` | DataFabric SFB2 slave port | 32-bit |
| `dma_*` ⇄ StreamDMA | descriptor / completion / control ports | `dma_soft_active` is StreamDMA's soft-reset contract |
| `h_*` | StreamDMA host-memory port (**HOST**-typed accesses only; route other memory types elsewhere) | |
| `priv_*` | **a privileged master only** (ControlCore / secure side) | **Never expose this to anything the host can reach.** It is the trust anchor of DMA protection |
| `irq_ext[2:0]`, `irq_level` | optional | |
| `rst_n` | reset, asynchronous assert, **release synchronised to `clk` by you** | |

## 4. Clocking

The bridge is single-clock. If the DataFabric or StreamDMA runs on another clock, put a proper CDC in front of the SFB2
and StreamDMA ports (valid/ready handshakes are CDC-friendly; the bridge contains no synchronisers). If the IP's user clock
changes frequency with link speed/width, the bridge's cycle-based timeouts (`CPL_TIMEOUT` ticks, `SFB_TIMEOUT`, `REC_QUIET`,
`DMA_TIMEOUT`, `ORD_TIMEOUT`) scale with it; set them for the **slowest** clock.

## 5. Bring-up order (each step has an observable pass criterion)

Do not skip ahead; each step isolates one layer. *(Unexecuted plan.)*

1. **Endpoint alone.** Enumerate the device with the bridge's CQ/CC/RQ/RC left unconnected (CQ ready = 0 is fine). `lspci -vv`
   shows BAR0 = 64 KiB and BAR2 = 1 MiB memory regions, MSI capability, correct link speed/width. This validates the IP,
   not the bridge.
2. **MMIO read of constants.** Connect CQ/CC only. Read BAR0 + `0x000` → `0x53465042` ('SFPB'), `+0x004` → version, `+0x008/0x00C`
   → `CAPS` (K, TAGS, NCTX, …). *If nothing returns:* `STATUS`/`ERR_STATUS`/`ERR_LOG*` (read through the same path once
   anything works) or probe `s_axis_cq_tready`; check `CQ_USER_W`/descriptor layout assumptions first.
3. **Register write/read, byte enables.** `SCRATCH` write/readback with partial byte enables; reserved-offset read ⇒ UR
   (host sees completer-abort/UR as an all-ones read); invalid BAR offset ⇒ dropped + `ERR_STATUS.BAR`.
4. **DataFabric windows.** `CTRL.FWIN_RD_EN/WR_EN` (reset value `0x23` enables both); BAR0+`0x8000` register window and BAR2
   memory window against known fabric registers/RAM; multi-dword bursts. Check `PERF` counters (`CQ_TLPS`, `BP_*`).
5. **Privileged setup.** From the privileged master program a context (`priv_*`, see `03_REGISTER_MAP.md §3`), `COMMIT`, then `LOCK`
   when finished.
6. **DMA host → device, small.** Pin a host buffer, write the descriptor words and `DOORBELL` in the context's BAR0 page, poll
   `CPL_STATUS`, pop the record. *If it fails:* `SUBMIT_STATUS` reject code (`SFPB_E_*`), `DMA_ERR_LOG0-2`, then the RC side:
   `ERR_STATUS.CPL_*`, `PERF` (`RQ_MRD`, `RC_TLPS`, `CPL_UNEXPECTED`, `TAG_STALL`).
7. **DMA device → host and ordering.** Write a buffer, confirm data, then enable `CTRL.WR_FLUSH_EN` and repeat to compare.
8. **MSI** — only after confirming the interface semantics (§06): enable `IRQ_CTRL.MSI_EN`, map a vector, `IRQ_SET` to
   self-test, check `IRQ_SENT_CNT`, then a real DMA-complete interrupt with data checked *after* the interrupt (ordering).
9. **Fault injection / recovery.** Link retrain/flap, FLR from the host (`echo 1 > /sys/bus/pci/devices/…/reset`), and
   `CTRL.SOFT_RESET`; expect `ERR_STATUS.LINK|FLR|RECOVERED`, `STATUS.REC_STATE` returning to 0, host re-initialisation
   (`CTRL.DMA_EN`).
10. **Stress.** Many outstanding reads (check `OUT_MAX`), small and large DMA mixes, back-pressure; compare PERF counters with
    `reports/perf_*.md` *as a sanity check of shape only* (simulation numbers are not link numbers).

## 6. Symptom → first look

| Symptom | Likely cause | Look at |
|---|---|---|
| Every host read returns all-ones | CQ/CC framing or tuser layout wrong, or CC `tuser` parity required | endpoint's own error status; `PERF.CQ_BAD`; `ERR_LOG` |
| Reads work, writes vanish | BE or discontinue mapping wrong; `CTRL.FWIN_WR_EN = 0` | `ERR_STATUS.MALFORMED/BAR`, `ERR_LOG0` |
| DMA read times out | RC tuser/error-code layout, requester-id mismatch, tag handling mode | `ERR_STATUS.CPL_TIMEOUT/CPL_UNEXP`, `STATUS.N_ZOMBIE`, `cfg_check_reqid` |
| Completions held forever | no sequence-number acknowledge | `PERF.ORD_STALL`; `DMA_ORDER` in error log; try `RQ_ACK_ON_ACCEPT = 1` |
| MSI never arrives | semantics of `msi_sent/fail`, `msi_enable` | `IRQ_SENT_CNT/FAIL_CNT`, `ERR_STATUS.IRQ_FAIL` |
| After FLR DMA is refused | expected: `CTRL` reset to `0x23` | rewrite `CTRL = 0x27` |
| `TAG_STALL` high, DMA slow | few tags, or zombies | `STATUS.N_ZOMBIE`, `CTRL.ZOMBIE_CLR` |

## 7. What integration will probably change in this repository

`sf_pcie_request_adapter` / `sf_pcie_completion_adapter` / the RQ header builder in `sf_pcie_dma_adapter` / the MSI ports if the
IP's field positions or sidebands differ; `*_USER_W` and `*_DISC_BIT` parameters; the `tb/` endpoint model should then be
updated to match so the regression keeps proving the same properties. Nothing in the tag tracker, MMIO engine, BAR decoder,
protection, CSRs or recovery should need to change.
