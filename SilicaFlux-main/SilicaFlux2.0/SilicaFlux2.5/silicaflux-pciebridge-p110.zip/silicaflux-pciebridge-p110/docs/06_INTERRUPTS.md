# 06 — Interrupts

The brief requires interrupts "through a verified endpoint interface **or** a documented polling-only mode". The MSI
request interface below is modelled on the AMD UltraScale+ `cfg_interrupt_msi_*` signals and is **not verified against
real IP** (no IP exists here). Therefore **polling-only mode is a first-class, fully tested mode**, and MSI is an option
that is enabled only when the integrator has confirmed the endpoint behaviour (§4).

## 1. Sources and status

`IRQ_STATUS` (`0x040`, write-1-to-clear, sticky) has eight sources:

| Bit | Source | Raised by |
|---|---|---|
| 0 | `DMA_CPL` | a DMA completion record was queued (any context) |
| 1 | `DMA_ERR` | a DMA completion with an error status / a DMA egress violation |
| 2 | `ERR` | an `ERR_STATUS` class enabled in `ERR_MASK` |
| 3 | `RECOVERY` | a reset / link-down / FLR recovery finished |
| 4 | `STREAMDMA` | StreamDMA's `irq` line (descriptor `IRQ_EN` flag) |
| 5–7 | `EXT0..2` | `irq_ext[2:0]` |

`IRQ_SET` (write-1) raises status bits from software (self-test). `IRQ_MASK` enables sources. A write-1-to-clear that
races a new event cannot lose the event (the status update ORs the event in the same cycle).

## 2. Polling-only mode (always available)

* `IRQ_CTRL.MSI_EN = 0` (or the host has not enabled MSI: `msi_enable = 0`): the adapter **requests nothing**; vectors that
  become pending stay latched.
* The host polls `IRQ_STATUS` / `STATUS.IRQ_PENDING` (and the per-context `CPL_STATUS`).
* `irq_level` = `|(IRQ_STATUS & IRQ_MASK)` is available as a level for an INTx-capable endpoint (not wired to anything
  in the bench; INTx assert/deassert messages are the endpoint's business).
* Tested: `tb_irq/poll`, `tb_irq/disabled_by_host` (MSI disabled by the host mid-run → pending vectors are re-latched,
  nothing is lost or sent).

## 3. MSI mode

* **Edge-triggered per vector, coalescing.** A source whose `(status & mask)` bit *rises* marks its vector pending; further
  events on a pending vector coalesce into the same request. (Level-style re-requests while pending are a mutation, M88.)
* **Vector map.** `IRQ_VECMAP` holds 4 bits per source (reset `0x76543210`: source *n* → vector *n*). The number is **folded
  into the range the host enabled** (`msi_mmenable`: 0 → 1 vector … ≥4 → 16 vectors), i.e. `vec & (2^k - 1)`. Only 16
  vectors are addressable through the 4-bit map. (Mutation M89.)
* **Request protocol.** One vector at a time, round-robin with wrap-around (M84): `msi_int` is driven **one-hot** and held until
  the endpoint answers `msi_sent` (done, `IRQ_SENT_CNT++`) or `msi_fail` (`IRQ_FAIL_CNT++`, retry up to
  `IRQ_CTRL[7:4]` times, default 3, then **give up and log** `SFPB_E_IRQ_FAIL` → `ERR_STATUS.IRQ_FAIL`; never silent
  — mutations M85, M86). If the host disables MSI while a request is pending the request is withdrawn and re-latched.
* **Ordering.** An interrupt must not overtake the posted writes it announces ("DMA data, then done interrupt"). When a vector is
  granted the adapter snapshots the RQ `issued` counter and holds `msi_int` until the endpoint has acknowledged that many
  RQ TLPs (§04 *posted-write ordering gate*; M83 removes it, killed). The root-model monitor checks *"MSI arrived before an
  earlier posted write"* on every interrupt.
* **Not implemented: MSI-X.** It needs a vector table and pending-bit array in BAR space plus the endpoint's MSI-X
  request interface; neither is specified here. A future `sf_pcie_msix_adapter` would slot in beside this module.

## 4. What must be confirmed before enabling MSI on real hardware

1. The endpoint's request interface really is "one-hot vector held until `sent` or `fail`" and which of `sent`/`fail`
   it asserts for a masked or disabled vector.
2. `msi_enable` / `msi_mmenable` are the *function's* MSI capability state (single function).
3. That `msi_sent` means the MSI memory write was **handed to the link** — if it only means "accepted by the interface" the
   ordering guarantee in §3 is correspondingly weaker.
4. Whether the IP needs `pending_status` or per-function signals driven (not provided).

Until then, run with `IRQ_CTRL.MSI_EN = 0` and poll.

## 5. Tests (`tb_irq`)

`poll` · `msi` (every source, vector mapping, one-hot, sent counting) · `fold` (1/2/4/8/16 enabled vectors) · `retry` (fail
→ retry → give up → logged; later requests still work) · `disabled_by_host` · `ordering` (interrupt behind posted DMA
writes with a slow acknowledge) · `sources` (each source and masking). Independent scoreboard: the root model answers
`msi_*` and records every request and its relation to the posted-write stream.
