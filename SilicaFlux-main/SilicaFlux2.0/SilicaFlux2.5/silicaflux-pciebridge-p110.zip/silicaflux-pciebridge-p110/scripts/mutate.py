#!/usr/bin/env python3
"""Mutation testing of the P110 RTL.  Each mutant plants ONE defect in a scratch copy of rtl/, rebuilds the combined bench
(tb/cpp/tb_all.cpp = every test program) and runs it; a mutant is KILLED if any test fails.

  python3 scripts/mutate.py              # run everything (4 workers)
  python3 scripts/mutate.py --check      # only verify that every mutation site exists exactly once
  python3 scripts/mutate.py --only M07 M12
Writes reports/mutation.md.   A baseline run on the unmodified RTL must pass first (otherwise 'killed' would mean nothing).
"""
import os, re, shutil, subprocess, sys, tempfile, concurrent.futures as cf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
W = os.environ.get("MUT_WIDTH", "256")

# (id, file, old, new, description)  -- every `old` must occur exactly once in the file
M = [
 # ---- stream framing ----------------------------------------------------------------------------------------------
 ("M01", "sf_pcie_axis_unpack.sv", "if (tot <= (NW+1)'(K)) begin\n            o_eop <= 1'b1;", "if (tot < (NW+1)'(K)) begin\n            o_eop <= 1'b1;", "unpack: a final beat that is exactly full spills into an empty trailing beat"),
 ("M02", "sf_pcie_axis_pack.sv", "keepmask = K'((1 << n) - 1);", "keepmask = K'((1 << n) - 2);", "pack: tkeep one dword short"),
 ("M03", "sf_pcie_axis_unpack.sv", "beat_bad = s_tbad || !keep_ok", "beat_bad = !keep_ok", "unpack: per-beat discontinue flag ignored"),
 # ---- request adapter ---------------------------------------------------------------------------------------------
 ("M04", "sf_pcie_request_adapter.sv", "if (n == 11'd1)      be_ok = (l == 4'b0000);", "if (n == 11'd1)      be_ok = 1'b1;", "request adapter: 1-dword request with last-BE set accepted"),
 ("M05", "sf_pcie_request_adapter.sv", "> 12'd1024)) begin\n      v_bad = 1'b1; v_code = `SFPB_E_MAL_4K;", ">= 12'd1024)) begin\n      v_bad = 1'b1; v_code = `SFPB_E_MAL_4K;", "request adapter: request ending exactly on a 4 KiB boundary rejected"),
 ("M06", "sf_pcie_request_adapter.sv", "end else if (t_checked && d_ndw == 11'd0) begin", "end else if (1'b0) begin", "request adapter: zero dword count accepted"),
 ("M07", "sf_pcie_request_adapter.sv", "end else if (t_checked && (pcnt_nx != {1'b0, exp_dw})) begin", "end else if (t_checked && (pcnt_nx > {1'b0, exp_dw})) begin", "request adapter: stream SHORTER than the descriptor accepted"),
 ("M08", "sf_pcie_request_adapter.sv", "if (v_bad || !t_has_dat) wr_ptr <= cm_ptr;", "if (!t_has_dat) wr_ptr <= cm_ptr;", "request adapter: payload of a REJECTED TLP stays visible (no rollback)"),
 ("M09", "sf_pcie_request_adapter.sv", "if (u_bad) begin\n      v_bad = 1'b1; v_code = `SFPB_E_MAL_FRAMING;", "if (1'b0) begin\n      v_bad = 1'b1; v_code = `SFPB_E_MAL_FRAMING;", "request adapter: framing violations not rejected"),
 ("M10", "sf_pcie_request_adapter.sv", "end else if (t_checked && v_spill) begin", "end else if (1'b0) begin", "request adapter: oversize payload not rejected"),
 # ---- BAR decoder -------------------------------------------------------------------------------------------------
 ("M11", "sf_pcie_bar_decoder.sv", "end else if (bend > win_hi) begin", "end else if (bend >= win_hi) begin", "BAR decoder: access ending exactly on the window end rejected"),
 ("M12", "sf_pcie_bar_decoder.sv", "end else if (bar_ap != exp_ap) begin", "end else if (1'b0) begin", "BAR decoder: aperture mismatch not detected"),
 ("M13", "sf_pcie_bar_decoder.sv", "(is_write ? !cfg_fwin_wr_en : !cfg_fwin_rd_en)", "(is_write ? !cfg_fwin_rd_en : !cfg_fwin_wr_en)", "BAR decoder: read/write permission swapped"),
 ("M14", "sf_pcie_bar_decoder.sv", "end else if ({1'b0, ndw} > max_dw) begin", "end else if ({1'b0, ndw} > max_dw + 12'd1) begin", "BAR decoder: one dword too many allowed"),
 ("M15", "sf_pcie_bar_decoder.sv", "end else if (boff >= 25'(FREG_OFF) && boff < 25'(FREG_OFF + FREG_SIZE)) begin\n          tgt = `SFPB_TGT_FREG; win_lo = 25'(FREG_OFF);", "end else if (boff >= 25'(FREG_OFF - 4) && boff < 25'(FREG_OFF + FREG_SIZE)) begin\n          tgt = `SFPB_TGT_FREG; win_lo = 25'(FREG_OFF - 4);", "BAR decoder: register window starts one dword early (lower bound moved together with its self-check, which would otherwise mask a single-site error)"),
 # ---- MMIO engine ---------------------------------------------------------------------------------------------------
 ("M16", "sf_pcie_mmio_engine.sv", "else                        tot_bytes = {h_ndw, 2'b00} - 13'(lo_idx(h_fbe)) - (13'd3 - 13'(hi_idx(h_lbe)));", "else                        tot_bytes = {h_ndw, 2'b00} - 13'(lo_idx(h_fbe));", "MMIO engine: byte count ignores the last-BE tail"),
 ("M17", "sf_pcie_mmio_engine.sv", "cpl_lower  = cpl_err_mode ? h_addr[6:0] : (cp_first ? {h_addr[6:2], lo_off}", "cpl_lower  = cpl_err_mode ? h_addr[6:0] : (cp_first ? {h_addr[6:2], 2'b00}", "MMIO engine: lower address ignores the first-BE offset"),
 ("M18", "sf_pcie_mmio_engine.sv", "else if (cp_tobnd < cp_eff)      cp_next_chunk = cp_tobnd;", "else if (1'b0)                  cp_next_chunk = cp_tobnd;", "MMIO engine: completions not split at 128-byte boundaries"),
 ("M19", "sf_pcie_mmio_engine.sv", "else if (dwi == h_ndw - 11'd1)          dw_strb = h_lbe;", "else if (dwi == h_ndw - 11'd1)          dw_strb = h_fbe;", "MMIO engine: last dword uses the first byte enables"),
 ("M20", "sf_pcie_mmio_engine.sv", "rdbuf[0] <= 32'd0; state <= S_CPL;", "state <= S_CPL;", "MMIO engine: zero-length read returns stale data instead of zeros"),
 ("M21", "sf_pcie_mmio_engine.sv", "d_code = `SFPB_E_POISONED_REQ; d_act = is_mrd ? A_UR : A_DROP;", "d_code = `SFPB_E_POISONED_REQ; d_act = A_EXEC;", "MMIO engine: poisoned requests are executed"),
 ("M22", "sf_pcie_mmio_engine.sv", "d_code = `SFPB_E_UNSUP_TYPE; d_act = nonposted ? A_UR : A_DROP;", "d_code = `SFPB_E_UNSUP_TYPE; d_act = A_DROP;", "MMIO engine: unsupported non-posted requests get no completion"),
 ("M23", "sf_pcie_mmio_engine.sv", "end else if (fab_tgt && st_fatal) begin", "end else if (1'b0) begin", "MMIO engine: fatal fabric state does not stop fabric accesses"),
 ("M24", "sf_pcie_mmio_engine.sv", "if (sfb_rsp_error) rd_err <= 1'b1;\n      end\n      if (rsp_fire && (state == S_WR", "if (1'b0) rd_err <= 1'b1;\n      end\n      if (rsp_fire && (state == S_WR", "MMIO engine: SFB2 read errors ignored"),
 ("M25", "sf_pcie_mmio_engine.sv", "if (rsp_fire && (state == S_WR || state == S_WR_WAIT) && sfb_rsp_error) wr_err <= 1'b1;", "if (1'b0) wr_err <= 1'b1;", "MMIO engine: SFB2 write errors ignored"),
 ("M26", "sf_pcie_mmio_engine.sv", "if (tmo_hit) st_fatal <= 1'b1;", "if (1'b0) st_fatal <= 1'b1;", "MMIO engine: fabric timeout never trips"),
 ("M27", "sf_pcie_mmio_engine.sv", "S_WR_WAIT: begin\n          if (!tgt_is_fab || (!sq_valid && pend == 4'd0)) begin", "S_WR_WAIT: begin\n          if (1'b1) begin", "MMIO engine: next request starts before the write's SFB2 response"),
 ("M28", "sf_pcie_mmio_engine.sv", "end else if (st_fatal && tgt_is_fab) begin                          // only fabric reads can be stranded by a dead port", "end else if (st_fatal) begin                          // only fabric reads can be stranded by a dead port", "MMIO engine: register reads aborted by the fatal fabric state"),
 # ---- CSR -----------------------------------------------------------------------------------------------------------
 ("M29", "sf_pcie_csr.sv", "if (wr_strb[0]) r_err_status[7:0]  <= (r_err_status[7:0]  & ~wr_data[7:0])  | cls_all[7:0];", "if (wr_strb[0]) r_err_status[7:0]  <= (r_err_status[7:0]  | wr_data[7:0])  | cls_all[7:0];", "CSR: ERR_STATUS write-1-to-clear sets instead"),
 ("M30", "sf_pcie_csr.sv", "r_scratch   <= merge(r_scratch, wr_data, wr_strb);", "r_scratch   <= wr_data;", "CSR: byte enables ignored on register writes"),
 ("M31", "sf_pcie_csr.sv", "`SFPB_R_ERR_LOG_CLR: if (wr_strb[0] && wr_data[0]) begin log_valid <= 1'b0; log_cnt <= '0; dlog_valid <= 1'b0; end", "`SFPB_R_ERR_LOG_CLR: if (wr_strb[0] && wr_data[0]) begin log_cnt <= '0; end", "CSR: error log can never be cleared"),
 ("M98", "sf_pcie_csr.sv", "if (wr_strb[1]) r_err_status[15:8] <= (r_err_status[15:8] & ~wr_data[15:8]) | cls_all[15:8];", "if (wr_strb[1]) r_err_status[15:8] <= (r_err_status[15:8] | cls_all[15:8]) & ~wr_data[15:8];", "CSR: an error class raised in the same cycle as its write-1-to-clear is lost"),
 ("M32", "sf_pcie_csr.sv", "end else if (log_cnt != 8'hFF) log_cnt <= log_cnt + 8'd1;", "end", "CSR: lost-event counter of the error log frozen"),
 ("M99", "sf_pcie_interrupt_adapter.sv", "if (wr_strb[0]) status <= (status & ~wr_data[NS-1:0]) | ev;", "if (wr_strb[0]) status <= (status | ev) & ~wr_data[NS-1:0];", "interrupts: an event in the same cycle as its write-1-to-clear is lost"),
 # ---- completion adapter / ordering gate -----------------------------------------------------------------------------
 ("M33", "sf_pcie_completion_adapter.sv", "wire               gate_ok  = !diff[ORD_W-1];", "wire               gate_ok  = 1'b1;", "ORDERING: completion gate removed"),
 ("M34", "sf_pcie_completion_adapter.sv", "if (cpl_valid && cpl_sop && !snap_v) begin snap_v <= 1'b1; snap <= ord_issued; end", "if (cpl_valid && cpl_sop && !snap_v) begin snap_v <= 1'b1; snap <= ord_acked; end", "ORDERING: snapshot of the wrong counter"),
 ("M35", "sf_pcie_completion_adapter.sv", "cc_desc[28:16]  = cpl_bytecnt;", "cc_desc[28:16]  = cpl_bytecnt + 13'd1;", "completion adapter: byte count field wrong"),
 ("M36", "sf_pcie_completion_adapter.sv", "cc_desc[71:64]  = cpl_tag;", "cc_desc[71:64]  = cpl_tag ^ 8'h01;", "completion adapter: tag corrupted"),
 # ---- tag tracker ---------------------------------------------------------------------------------------------------
 ("M37", "sf_pcie_tag_tracker.sv", "else if (p_bytecnt != rem_b)                      h_code = `SFPB_E_CPL_MISMATCH;", "else if (1'b0)                                   h_code = `SFPB_E_CPL_MISMATCH;", "tracker: byte-count consistency not checked"),
 ("M38", "sf_pcie_tag_tracker.sv", "else if (p_lower != e_lo[pt])                     h_code = `SFPB_E_CPL_MISMATCH;", "else if (1'b0)                                   h_code = `SFPB_E_CPL_MISMATCH;", "tracker: lower-address consistency not checked"),
 ("M39", "sf_pcie_tag_tracker.sv", "else if (p_poison)                                h_code = `SFPB_E_CPL_POISONED;", "else if (1'b0)                                   h_code = `SFPB_E_CPL_POISONED;", "tracker: poisoned data accepted"),
 ("M40", "sf_pcie_tag_tracker.sv", "else if ({1'b0, p_dwcnt} > rem_h)                 h_code = `SFPB_E_CPL_OVERRUN;", "else if (1'b0)                                   h_code = `SFPB_E_CPL_OVERRUN;", "tracker: completion longer than the request accepted"),
 ("M41", "sf_pcie_tag_tracker.sv", "e_st[exp_idx] <= T_ZOMB;", "e_st[exp_idx] <= T_FREE;", "QUARANTINE: a timed-out tag is reused immediately"),
 ("M42", "sf_pcie_tag_tracker.sv", "e_st[fl_idx] <= T_ZOMB;", "e_st[fl_idx] <= T_FREE;", "QUARANTINE: tags lost to a reset are reused immediately"),
 ("M43", "sf_pcie_tag_tracker.sv", "end else if (st_h == T_ZOMB) begin\n      h_diag = 1'b1; h_diag_code = `SFPB_E_CPL_LATE;\n    end else if", "end else if (1'b0) begin\n      h_diag = 1'b1; h_diag_code = `SFPB_E_CPL_LATE;\n    end else if", "tracker: late completions for quarantined tags are not recognised"),
 ("M44", "sf_pcie_tag_tracker.sv", "end else if (cfg_check_reqid && (p_reqid != cfg_req_id)) begin", "end else if (1'b0) begin", "tracker: requester id never checked"),
 ("M45", "sf_pcie_tag_tracker.sv", "e_lo[ctx_tag]  <= e_lo[ctx_tag] + {p_dwcnt[4:0], 2'b00};", "e_lo[ctx_tag]  <= e_lo[ctx_tag];", "tracker: expected next address not advanced across split completions"),
 ("M46", "sf_pcie_tag_tracker.sv", "if (p_status != `SFPB_CPL_SC) begin\n        h_code", "if (1'b0) begin\n        h_code", "tracker: non-success completion status ignored"),
 ("M47", "sf_pcie_tag_tracker.sv", "if (tick) for (n = 0; n < TAGS; n++) if (e_st[n] == T_WAIT && e_age[n] != 8'hFF) e_age[n] <= e_age[n] + 8'd1;", "if (1'b0) for (n = 0; n < TAGS; n++) if (e_st[n] == T_WAIT && e_age[n] != 8'hFF) e_age[n] <= e_age[n] + 8'd1;", "tracker: completion timeout never advances"),
 ("M48", "sf_pcie_tag_tracker.sv", "if (zombie_clr) for (n = 0; n < TAGS; n++) if (e_st[n] == T_ZOMB) e_st[n] <= T_FREE;", "if (1'b0) for (n = 0; n < TAGS; n++) if (e_st[n] == T_ZOMB) e_st[n] <= T_FREE;", "tracker: quarantined tags can never be released"),
 # ---- DMA adapter -----------------------------------------------------------------------------------------------------
 ("M49", "sf_pcie_dma_adapter.sv", "else if (!w_ok)                                                         c_err = w_err;", "else if (1'b0)                                                          c_err = w_err;", "EGRESS: window / permission check bypassed"),
 ("M50", "sf_pcie_dma_adapter.sv", ".valid(a_valid), .perm_ok(pick_wr ? a_wr_ok : a_rd_ok)", ".valid(a_valid), .perm_ok(pick_wr ? a_rd_ok : a_wr_ok)", "EGRESS: read/write permission swapped"),
 ("M51", "sf_pcie_dma_adapter.sv", "else if (c_mt != HOST_MTYPE)                                            c_err = `SFPB_E_DMA_BADMTYPE;", "else if (1'b0)                                                          c_err = `SFPB_E_DMA_BADMTYPE;", "EGRESS: memory type not checked"),
 ("M52", "sf_pcie_dma_adapter.sv", "else if (c_addr[BEAT_LOG2-1:0] != '0)                                   c_err = `SFPB_E_DMA_BADFORMAT;", "else if (1'b0)                                                          c_err = `SFPB_E_DMA_BADFORMAT;", "EGRESS: unaligned envelope accepted"),
 ("M53", "sf_pcie_dma_adapter.sv", "else if (!pick_wr && slot_busy[c_id[SLW-1:0]])                          c_err = `SFPB_E_DMA_PROTO;", "else if (1'b0)                                                          c_err = `SFPB_E_DMA_PROTO;", "EGRESS: id reuse while in flight not detected"),
 ("M54", "sf_pcie_dma_adapter.sv", "else if (c_size != SIZE_LOG2 || c_burst != 2'b01)                       c_err = `SFPB_E_DMA_BADFORMAT;", "else if (c_size != SIZE_LOG2)                                           c_err = `SFPB_E_DMA_BADFORMAT;", "EGRESS: burst type not checked"),
 ("M55", "sf_pcie_dma_adapter.sv", "if (ing_seen && (s_lo != '0)) n_gap = 1'b1;", "if (1'b0) n_gap = 1'b1;", "write path: a beat that starts mid-beat after valid data is not flagged"),
 ("M56", "sf_pcie_dma_adapter.sv", "if (!s_contig)  n_gap = 1'b1;", "if (1'b0)  n_gap = 1'b1;", "write path: sparse strobes inside a beat accepted"),
 ("M57", "sf_pcie_dma_adapter.sv", "wire [3:0]      pl_fm    = 4'hF << wm_fv[1:0];", "wire [3:0]      pl_fm    = 4'hF;", "write path: first byte enables ignore the leading strobes"),
 ("M58", "sf_pcie_dma_adapter.sv", "wire [3:0]      pl_lm    = 4'hF >> (2'd3 - wm_lv_b[1:0]);", "wire [3:0]      pl_lm    = 4'hF;", "write path: last byte enables ignore the trailing strobes"),
 ("M59", "sf_pcie_dma_adapter.sv", "wire [12:0]     wp_to4k  = 13'd1024 - {3'd0, wp_addr[11:2]};", "wire [12:0]     wp_to4k  = 13'd1025 - {3'd0, wp_addr[11:2]};", "write path: write TLPs may cross 4 KiB by one dword"),
 ("M60", "sf_pcie_dma_adapter.sv", "if (wp_chunk > {1'b0, cfg_mps_dw}) wp_chunk = {1'b0, cfg_mps_dw};", "if (1'b0) wp_chunk = {1'b0, cfg_mps_dw};", "write path: max payload size ignored"),
 ("M61", "sf_pcie_dma_adapter.sv", "wire  [15:0]       rp_to4k = 16'd4096 - {4'd0, rp_addr[11:0]};", "wire  [15:0]       rp_to4k = 16'd4100 - {4'd0, rp_addr[11:0]};", "read path: read requests may cross 4 KiB"),
 ("M62", "sf_pcie_dma_adapter.sv", "if (rp_chunk > rp_mrrs)               rp_chunk = rp_mrrs;", "if (1'b0)                           rp_chunk = rp_mrrs;", "read path: max read request size ignored"),
 ("M63", "sf_pcie_dma_adapter.sv", "rp_v <= 1'b0; slot_err[rp_slot] <= 1'b1; slot_code[rp_slot] <= `SFPB_E_CPL_RESET; slot_all[rp_slot] <= 1'b1;", "rp_v <= 1'b0; slot_err[rp_slot] <= 1'b0; slot_code[rp_slot] <= `SFPB_E_CPL_RESET; slot_all[rp_slot] <= 1'b1;", "RESET: a read aborted by recovery is completed as SUCCESS"),
 ("M64", "sf_pcie_dma_adapter.sv", "if (tev_valid && !tev_fk && !tev_ok) begin\n        if (!slot_err[tev_slot]) begin slot_err[tev_slot] <= 1'b1; slot_code[tev_slot] <= tev_err; end\n      end", "if (1'b0) begin\n        if (!slot_err[tev_slot]) begin slot_err[tev_slot] <= 1'b1; slot_code[tev_slot] <= tev_err; end\n      end", "ERRORS: a failed completion is delivered to the DMA as success"),
 ("M65", "sf_pcie_dma_adapter.sv", "wire  [8:0]        head_nb   = o_err ? o_nb : {1'b0, slot_nbeats[o_id]};", "wire  [8:0]        head_nb   = {1'b0, slot_nbeats[o_id]};", "R path: error responses use the wrong burst length"),
 ("M66", "sf_pcie_dma_adapter.sv", "for (int i = 0; i < BEAT_DW; i++) r_data[i*32 +: 32] = sbuf[32'(o_id) * SLOT_DW + 32'(r_beat) * BEAT_DW + i];", "for (int i = 0; i < BEAT_DW; i++) r_data[i*32 +: 32] = sbuf[32'(o_id) * SLOT_DW + 32'(r_beat) * BEAT_DW + (BEAT_DW - 1 - i)];", "R path: dwords of a beat reversed"),
 ("M67", "sf_pcie_dma_adapter.sv", "bq_fl <= cfg_wr_flush_en;", "bq_fl <= 1'b0;", "write ack: strict (flush-read) mode ignored"),
 ("M68", "sf_pcie_dma_adapter.sv", "if (wp_v && flush) begin\n          wp_v <= 1'b0; bq_push <= 1'b1; bq_id <= wp_id; bq_dom <= wp_dom; bq_fl <= 1'b0; bq_code <= `SFPB_E_CPL_RESET;", "if (wp_v && flush) begin\n          wp_v <= 1'b0; bq_push <= 1'b1; bq_id <= wp_id; bq_dom <= wp_dom; bq_fl <= 1'b0; bq_code <= `SFPB_E_NONE;", "RESET: a write aborted by recovery is acknowledged as SUCCESS"),
 ("M69", "sf_pcie_dma_adapter.sv", "issued_q <= issued_q + 1'b1; st_hdr_bytes <= 8'd16;", "issued_q <= issued_q; st_hdr_bytes <= 8'd16;", "ORDERING: TLP counter never advances"),
 ("M70", "sf_pcie_dma_adapter.sv", "else acked_q <= acked_q + ORD_W'(ack_n);", "else acked_q <= acked_q + ORD_W'(ack_n) + ORD_W'(ack_n);", "ORDERING: acknowledges counted twice"),
 ("M71", "sf_pcie_dma_adapter.sv", "      else if (ack_wait < 32'(ORD_TIMEOUT)) ack_wait <= ack_wait + 1'b1;\n      else begin ord_fault <= 1'b1; ack_wait <= '0; end", "      else if (ack_wait < 32'(ORD_TIMEOUT)) ack_wait <= ack_wait + 1'b1;\n      else begin ack_wait <= '0; end", "ORDERING: a missing endpoint acknowledge is not reported"),
 ("M72", "sf_pcie_dma_adapter.sv", "ok_wr = want_wr && rq_p_ok && inflight_ok;", "ok_wr = want_wr && inflight_ok;", "flow control: posted-credit hint ignored"),
 ("M73", "sf_pcie_dma_adapter.sv", "ok_rd = want_rd && rq_np_ok && al_ready && inflight_ok;", "ok_rd = want_rd && rq_np_ok && inflight_ok;", "tags: a read is issued without a free tag (tag reuse)"),
 # ---- DMA submission / contexts ----------------------------------------------------------------------------------------
 ("M74", "sf_pcie_dma_submit.sv", "else if (w[1][31:16] != {12'd0, wr_ctx})                                  v_code = `SFPB_E_DMA_PERM;", "else if (1'b0)                                                           v_code = `SFPB_E_DMA_PERM;", "TRUST: the domain claim of a descriptor is not checked"),
 ("M75", "sf_pcie_dma_submit.sv", "else if (len == 32'd0 || len > b_max_len)                                 v_code = `SFPB_E_DMA_BADLEN;", "else if (len == 32'd0)                                                   v_code = `SFPB_E_DMA_BADLEN;", "submit: context length limit ignored"),
 ("M76", "sf_pcie_dma_submit.sv", ".perm_ok(src_h ? b_rd_ok : b_wr_ok)", ".perm_ok(src_h ? b_wr_ok : b_rd_ok)", "submit: direction permission swapped"),
 ("M77", "sf_pcie_dma_submit.sv", "else if (src_h == dst_h)                                                  v_code = `SFPB_E_DMA_BADMTYPE;", "else if (1'b0)                                                           v_code = `SFPB_E_DMA_BADMTYPE;", "submit: host-to-host / device-to-device copies accepted"),
 ("M78", "sf_pcie_dma_submit.sv", "else if (!dv_ok)                                                          v_code", "else if (1'b0)                                                           v_code", "submit: device-side window not checked"),
 ("M79", "sf_pcie_dma_submit.sv", "assign sd_cpl_ready = 1'b1;                                   // never back-pressure StreamDMA (isolation)", "assign sd_cpl_ready = (q_in_r != '0);", "ISOLATION: a full completion queue back-pressures StreamDMA"),
 ("M80", "sf_pcie_dma_submit.sv", "hold_d <= {w[7], w[6], w[5], w[4], w[3], w[2], w[1], (w[0] | 32'h0008_0000)};", "hold_d <= {w[7], w[6], w[5], w[4], w[3], w[2], w[1], w[0]};", "submit: CPL_EN not forced (a successful transfer produces no record)"),
 ("M81", "sf_pcie_dma_ctx.sv", "else if (!quiescent)                                          begin chk_ok = 1'b0; chk_code = 4'd1; end", "else if (1'b0)                                               begin chk_ok = 1'b0; chk_code = 4'd1; end", "TRUST: contexts can be re-mapped while DMA is in flight"),
 ("M82", "sf_pcie_dma_ctx.sv", "if (priv_req_write && priv_req_wdata[0]) locked <= 1'b1;             // set-only", "if (priv_req_write && priv_req_wdata[0]) locked <= 1'b0;             // set-only", "TRUST: the privileged table LOCK never engages"),
 ("M96", "sf_pcie_dma_ctx.sv", "if ((s_bb[i][1:0] != s_ib[i][1:0]) && s_xl[i])              begin chk_ok = 1'b0; chk_code = 4'd2; end", "if (1'b0)                                                     begin chk_ok = 1'b0; chk_code = 4'd2; end", "TRUST: a translation that breaks dword alignment can be committed"),
 ("M97", "sf_pcie_dma_ctx.sv", "else if (ib_end[64] || db_end[64] || s_is[i] == 64'd0)      begin chk_ok = 1'b0; chk_code = 4'd3; end", "else if (1'b0)                                                begin chk_ok = 1'b0; chk_code = 4'd3; end", "TRUST: a wrapping / empty window can be committed"),
 # ---- interrupts ------------------------------------------------------------------------------------------------------
 ("M83", "sf_pcie_interrupt_adapter.sv", "else if (gate_ok) begin msi_int <= 32'd1 << m_vec; m_st <= M_SEND; end", "else begin msi_int <= 32'd1 << m_vec; m_st <= M_SEND; end", "ORDERING: MSI sent without waiting for earlier posted writes"),
 ("M84", "sf_pcie_interrupt_adapter.sv", "if (idx >= 6'(NVEC)) idx = idx - 6'(NVEC);", "if (idx >= 6'(NVEC)) idx = 6'd63;", "interrupts: vector search does not wrap around"),
 ("M85", "sf_pcie_interrupt_adapter.sv", "if (m_try + 4'd1 > ctrl_retry[3:0]) begin", "if (1'b1) begin", "interrupts: no retry after a failed MSI"),
 ("M86", "sf_pcie_interrupt_adapter.sv", "ev_fail_valid <= 1'b1; ev_fail_code <= `SFPB_E_IRQ_FAIL;", "ev_fail_valid <= 1'b0; ev_fail_code <= `SFPB_E_IRQ_FAIL;", "interrupts: a given-up MSI is not reported"),
 ("M87", "sf_pcie_interrupt_adapter.sv", "wire          msi_on = ctrl_msi && msi_enable;", "wire          msi_on = ctrl_msi;", "interrupts: host MSI-enable state ignored"),
 ("M88", "sf_pcie_interrupt_adapter.sv", "wire [NS-1:0] rise = act & ~act_q;", "wire [NS-1:0] rise = act;", "interrupts: level instead of edge (re-requests while pending)"),
 ("M89", "sf_pcie_interrupt_adapter.sv", "vec_of[s] = vecmap[s*4 +: 4] & ((msi_mmenable >= 3'd4) ? 4'hF : (4'hF >> (3'd4 - msi_mmenable)));", "vec_of[s] = vecmap[s*4 +: 4];", "interrupts: vectors not folded into the enabled range"),
 # ---- recovery ---------------------------------------------------------------------------------------------------------
 ("M90", "sf_pcie_transaction_bridge.sv", "rec_zombie_clr <= 1'b1; rec_done_ev <= 1'b1; rst_st <= `SFPB_REC_DONE;", "rec_done_ev <= 1'b1; rst_st <= `SFPB_REC_DONE;", "RECOVERY: quarantined tags never released"),
 ("M91", "sf_pcie_transaction_bridge.sv", "if (!rst_dma_only) rec_soft_rst <= rst_host_reset;", "if (!rst_dma_only) rec_soft_rst <= 1'b1;", "RECOVERY: a link loss resets host-visible registers"),
 ("M92", "sf_pcie_transaction_bridge.sv", "dma_clr <= 1'b1; rec_dma_soft <= 1'b1;                                    // wipe the adapter, reset StreamDMA's core", "dma_clr <= 1'b0; rec_dma_soft <= 1'b1;                                    // wipe the adapter, reset StreamDMA's core", "RECOVERY: the DMA adapter is not wiped"),
 ("M93", "sf_pcie_transaction_bridge.sv", "if ((eng_idle || rst_dma_only) && (cc_idle || rst_dma_only) && dma_idle && !trk_flushing && (trk_out == 9'd0) && !dma_busy) rst_st <= `SFPB_REC_DMA_DRAIN;", "if (1'b1) rst_st <= `SFPB_REC_DMA_DRAIN;", "RECOVERY: does not wait for the machines to drain"),
 ("M94", "sf_pcie_transaction_bridge.sv", "if (ep_link_up && !ep_flr_in_process) begin rst_st <= `SFPB_REC_QUIET; rst_cnt <= '0; end", "begin rst_st <= `SFPB_REC_QUIET; rst_cnt <= '0; end", "RECOVERY: does not wait for the link to return"),
 ("M95", "sf_pcie_dma_submit.sv", "if (pending[i] != 16'd0 || (hold_v && hold_dom == 4'(i))) lost[i] <= 1'b1;", "if (1'b0) lost[i] <= 1'b1;", "RECOVERY: descriptors lost to a wipe are not flagged"),
]

def rd(p):
    with open(p) as f: return f.read()

def apply(rtl_dir, m):
    mid, fn, old, new, desc = m
    p = os.path.join(rtl_dir, fn); s = rd(p)
    n = s.count(old)
    if n != 1: raise RuntimeError("%s: mutation site occurs %d times in %s" % (mid, n, fn))
    open(p, "w").write(s.replace(old, new))

AXIS_FILES = ("sf_pcie_axis_unpack.sv", "sf_pcie_axis_pack.sv")
AXIS_CFGS = (("256", "4"), ("128", "3"))        # (DATA_W, HDR_DW): both stream widths, both header sizes

def axis_unit(rtl, d):
    """The pack/unpack unit test (tb_axis_unit) -- framing defects can be invisible at system level (the request adapter
    tolerates e.g. an empty trailing beat), so for mutants of the two framing modules this test also counts as a killer.
    Returns None if it passes, else the first failing line."""
    for w, h in AXIS_CFGS:
        D = os.path.join(d, "axis_w%sh%s" % (w, h))
        os.makedirs(D, exist_ok=True)
        b = subprocess.run(["verilator", "--cc", "--exe", "--build", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--Mdir", D, "-GDATA_W=" + w, "-GHDR_DW=" + h,
                            "-CFLAGS", "-DDW=%s -DHDW=%s -O1 -I%s" % (w, h, os.path.join(SNAP, "tb", "cpp")), "--top-module", "tb_axis_unit", "-I" + rtl,
                            os.path.join(rtl, "sf_pcie_axis_unpack.sv"), os.path.join(rtl, "sf_pcie_axis_pack.sv"),
                            os.path.join(SNAP, "tb", "sv", "tb_axis_unit.sv"), os.path.join(SNAP, "tb", "cpp", "tb_axis_unit.cpp"), "-o", "tb"],
                           capture_output=True, text=True)
        if b.returncode != 0: return "axis unit build error: " + (b.stdout + b.stderr)[-200:]
        try: r = subprocess.run([os.path.join(D, "tb")], capture_output=True, text=True, timeout=300)
        except subprocess.TimeoutExpired: return "axis unit W=%s H=%s: timeout (hang)" % (w, h)
        if r.returncode != 0:
            f = [l.strip() for l in r.stdout.splitlines() if "FAIL" in l][:1]
            return "[axis_unit W=%s H=%s] %s" % (w, h, f[0] if f else "failed")
    return None

TAG_FILES = ("sf_pcie_dma_adapter.sv", "sf_pcie_tag_tracker.sv")

def fewtags_dma(rtl, d, snap):
    """tb_dma built with only 4 request tags (-GTAGS=4 -DTAGS_FEW): the tag table really runs out there.  For mutants of the tag
    allocation / tracker this configuration is a second killer.  Returns None if it passes, else the first failing line."""
    env = dict(os.environ, RTL_DIR=rtl, BUILD_DIR=os.path.join(d, "fewtags"))
    b = subprocess.run([os.path.join(snap, "scripts", "build_sim.sh"), W, os.path.join(snap, "tb", "cpp", "tb_dma.cpp"), "-GTAGS=4", "-CFLAGS", "-DTAGS_FEW"],
                       env=env, capture_output=True, text=True)
    if b.returncode != 0: return "fewtags build error: " + (b.stdout + b.stderr)[-200:]
    try: r = subprocess.run([b.stdout.strip().splitlines()[-1]], capture_output=True, text=True, timeout=600)
    except subprocess.TimeoutExpired: return "[dma TAGS=4] timeout (hang)"
    if r.returncode == 0: return None
    f = [l.strip() for l in r.stdout.splitlines() if "FAIL[" in l or "VIOLATION" in l][:1]
    return "[dma TAGS=4] FAIL " + (f[0] if f else "failed")

SNAP = None   # one frozen copy of the WHOLE project tree (rtl, tb, scripts, third_party) per campaign: edits made while the
              # campaign runs can never leak into a mutant build (a half-old / half-new tree would "kill" mutants for the wrong reason)

def run_one(m, workdir):
    mid = m[0]; d = os.path.join(workdir, mid); os.makedirs(d, exist_ok=True)
    rtl = os.path.join(d, "rtl"); shutil.copytree(os.path.join(SNAP, "rtl"), rtl)
    apply(rtl, m)
    if m[1] in AXIS_FILES:
        a = axis_unit(rtl, d)
        if a: return (mid, "KILLED", a)
    env = dict(os.environ, RTL_DIR=rtl, BUILD_DIR=os.path.join(d, "build"))
    b = subprocess.run([os.path.join(SNAP, "scripts", "build_sim.sh"), W, os.path.join(SNAP, "tb", "cpp", "tb_all.cpp")], env=env, capture_output=True, text=True)
    if b.returncode != 0: return (mid, "BUILD-ERROR", (b.stdout + b.stderr)[-300:])
    exe = b.stdout.strip().splitlines()[-1]
    try: r = subprocess.run([exe], capture_output=True, text=True, timeout=900)
    except subprocess.TimeoutExpired: return (mid, "KILLED", "timeout (hang)")
    out = r.stdout
    if r.returncode == 0:
        if m[1] in TAG_FILES:
            f = fewtags_dma(rtl, d, SNAP)
            if f: return (mid, "KILLED", f)
        return (mid, "SURVIVED", "")
    prog = [l for l in out.splitlines() if l.startswith("[") and "FAIL" in l]
    firstfail = [l.strip() for l in out.splitlines() if "FAIL[" in l or "VIOLATION" in l][:1]
    return (mid, "KILLED", (prog[0] if prog else "") + " " + (firstfail[0] if firstfail else ""))

def main():
    ids = None
    if "--only" in sys.argv: ids = set(sys.argv[sys.argv.index("--only") + 1:])
    muts = [m for m in M if (ids is None or m[0] in ids)]
    bad = 0
    for m in muts:                                              # every site must exist exactly once
        s = rd(os.path.join(ROOT, "rtl", m[1]))
        if s.count(m[2]) != 1: print("BAD SITE", m[0], m[1], "count", s.count(m[2])); bad += 1
    if bad: sys.exit(2)
    if "--check" in sys.argv: print("all %d mutation sites found exactly once" % len(muts)); return
    global SNAP
    wd = tempfile.mkdtemp(prefix="p110mut_", dir=os.path.join(ROOT, "build"))
    SNAP = os.path.join(wd, "frozen"); shutil.copytree(ROOT, SNAP, ignore=shutil.ignore_patterns("build", "reports", "docs", ".git", "__pycache__", "*.zip"))
    print("baseline ...", flush=True)
    a = axis_unit(os.path.join(SNAP, "rtl"), os.path.join(wd, "baseline_axis"))
    if a: print("BASELINE FAILS (axis unit) -- refusing to run mutants:", a); sys.exit(3)
    base = subprocess.run([os.path.join(SNAP, "scripts", "build_sim.sh"), W, os.path.join(SNAP, "tb", "cpp", "tb_all.cpp")],
                          env=dict(os.environ, RTL_DIR=os.path.join(SNAP, "rtl"), BUILD_DIR=os.path.join(wd, "baseline_build")), capture_output=True, text=True)
    f0 = fewtags_dma(os.path.join(SNAP, "rtl"), os.path.join(wd, "baseline_fewtags"), SNAP)
    if f0: print("BASELINE FAILS (TAGS=4 configuration) -- refusing to run mutants:", f0); sys.exit(3)
    exe = base.stdout.strip().splitlines()[-1]; r = subprocess.run([exe], capture_output=True, text=True)
    if r.returncode != 0: print("BASELINE FAILS -- refusing to run mutants"); print(r.stdout[-2000:]); sys.exit(3)
    print("baseline passes; running %d mutants on 4 workers" % len(muts), flush=True)
    res = {}
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        futs = {ex.submit(run_one, m, wd): m for m in muts}
        for f in cf.as_completed(futs):
            mid, st, info = f.result(); res[mid] = (st, info); print("  %-4s %-9s %s" % (mid, st, info[:110]), flush=True)
    killed = sum(1 for v in res.values() if v[0] == "KILLED"); surv = [k for k, v in res.items() if v[0] == "SURVIVED"]; err = [k for k, v in res.items() if v[0] == "BUILD-ERROR"]
    lines = ["# Mutation testing (generated by scripts/mutate.py)", "",
             "Each row plants ONE defect in a scratch copy of the RTL, rebuilds the combined bench (every test program, DATA_W=%s) and runs it. "
             "KILLED = at least one test failed (also counted: the pack/unpack unit test for mutants of the two framing modules, and tb_dma built with 4 tags "
             "for mutants of the tag allocation / tracker -- structurally blind spots of the combined bench). The baseline (unmodified RTL) passed first, "
             "and the whole project tree was frozen into a snapshot before the run." % W, "",
             "**%d mutants: %d killed, %d survived, %d did not build.**" % (len(muts), killed, len(surv), len(err)), "",
             "| id | file | defect | result | first failing check |", "|---|---|---|---|---|"]
    for m in muts:
        st, info = res[m[0]]
        lines.append("| %s | `%s` | %s | %s | %s |" % (m[0], m[1], m[4], st, info.replace("|", "/")[:140]))
    open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(lines) + "\n")
    print("\n%d mutants: %d killed, %d survived %s, %d build errors %s" % (len(muts), killed, len(surv), surv, len(err), err))
    shutil.rmtree(wd, ignore_errors=True)

if __name__ == "__main__":
    main()
