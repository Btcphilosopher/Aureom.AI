#!/bin/bash
# Build and run every bench at both stream widths.  Results (pass/fail + check counts) go to reports/regression.log
# usage: scripts/run_all.sh [bench ...]      (default: all)
P="$(cd "$(dirname "$0")/.." && pwd)"
BENCHES=${@:-"tb_mmio tb_dma tb_irq tb_reset tb_hostile tb_race tb_rand"}
mkdir -p "$P/reports"; LOG="$P/reports/regression.log"; : > "$LOG"
fail=0
for w in 128 256; do
  for b in $BENCHES; do
    [ -f "$P/tb/cpp/$b.cpp" ] || continue
    exe=$("$P/scripts/build_sim.sh" $w "$P/tb/cpp/$b.cpp" 2>&1 | tail -1)
    if [ ! -x "$exe" ]; then echo "BUILD FAILED: $b W=$w" | tee -a "$LOG"; fail=1; continue; fi
    out=$("$exe" 2>&1); rc=$?
    echo "$out" | tail -1 | tee -a "$LOG"
    [ $rc -ne 0 ] && { echo "$out" | grep -E "FAIL|VIOLATION" | head -20 | tee -a "$LOG"; fail=1; }
  done
done
# extra configuration: only 4 request tags, so the tag table really runs out (TAGS_FEW changes tb_dma's expectations accordingly)
case " $BENCHES " in *" tb_dma "*)
  for w in 128 256; do
    exe=$(BUILD_DIR="$P/build/tb_dma_fewtags-w$w" "$P/scripts/build_sim.sh" $w "$P/tb/cpp/tb_dma.cpp" -GTAGS=4 -CFLAGS -DTAGS_FEW 2>&1 | tail -1)
    if [ ! -x "$exe" ]; then echo "BUILD FAILED: tb_dma TAGS=4 W=$w" | tee -a "$LOG"; fail=1; continue; fi
    out=$("$exe" 2>&1); rc=$?
    echo "[TAGS=4] $(echo "$out" | tail -1)" | tee -a "$LOG"
    [ $rc -ne 0 ] && { echo "$out" | grep -E "FAIL|VIOLATION" | head -20 | tee -a "$LOG"; fail=1; }
  done;;
esac
[ $fail -eq 0 ] && echo "ALL BENCHES PASS" | tee -a "$LOG" || echo "FAILURES PRESENT" | tee -a "$LOG"
exit $fail
