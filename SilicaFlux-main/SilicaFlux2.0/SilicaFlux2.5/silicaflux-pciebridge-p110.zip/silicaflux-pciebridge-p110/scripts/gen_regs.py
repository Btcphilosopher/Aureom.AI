#!/usr/bin/env python3
"""Single source of truth for the SilicaFlux PCIe bridge register ABI (Project 110).

Generates:  rtl/sf_pcie_regs.svh      (macros for the RTL)
            tb/cpp/sf_pcie_regs.h     (constants for the C++ benches / a driver)
            docs/03_REGISTER_MAP.md   (human-readable map)
Run:  python3 scripts/gen_regs.py          (writes the three files)
      python3 scripts/gen_regs.py --check  (exit 1 if a generated file is stale)
"""
import os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ----------------------------------------------------------------------------------------------------------------------
# BAR layout (defaults; the apertures / windows are RTL parameters of sf_pcie_bar_decoder)
# ----------------------------------------------------------------------------------------------------------------------
BARS = [
    ("BAR0 (BAR id 0), 64 KiB default aperture", [
        ("0x0000-0x0FFF", "global register page (this table, section 1)"),
        ("0x1000-0x1FFF x NCTX", "one 4 KiB DMA submission page per context c at 0x1000*(1+c) (section 2)"),
        ("0x8000-0xFFFF", "DataFabric register window: SFB2 address = SFB_REG_BASE + (offset - 0x8000)"),
        ("everything else", "unmapped: reads complete with UR, writes are dropped and logged (BAR_RANGE)"),
    ]),
    ("BAR2 (BAR id 2), 1 MiB default aperture", [
        ("0x00000-0xFFFFF", "DataFabric memory window: SFB2 address = SFB_MEM_BASE + offset"),
    ]),
]

# (name, offset, access, reset, text)
GLOBAL = [
    ("ID",            0x000, "RO",  "0x53465042", "ASCII 'SFPB'"),
    ("VERSION",       0x004, "RO",  "0x01000000", "[31:24] ABI major, [23:16] minor, [15:0] patch"),
    ("CAPS0",         0x008, "RO",  "(params)",   "[7:0] K = DATA_W/32, [15:8] TAGS, [19:16] NCTX, [24] DMA present, [25] MSI capable, [26] ordering gate present"),
    ("CAPS1",         0x00C, "RO",  "(params)",   "[15:0] MMIO_MAX_DW, [31:16] CPL_MAX_DW"),
    ("SCRATCH",       0x010, "RW",  "0",          "software scratch, byte-enable aware"),
    ("CTRL",          0x014, "RW",  "0x00000023", "[0] FWIN_RD_EN, [1] FWIN_WR_EN, [2] DMA_EN, [3] WR_FLUSH_EN (B only after a flush read returns), [4] TC_ANY, [5] PERF_EN, "
                                                  "[8] SOFT_RESET (W1, self-clearing: runs the recovery sequence), [9] CLR_FATAL (W1: leave the fabric-fatal state), "
                                                  "[10] PERF_CLEAR (W1), [11] ZOMBIE_CLR (W1: release quarantined tags)"),
    ("STATUS",        0x018, "RO",  "-",          "[0] LINK_UP, [1] RECOVERING, [2] FABRIC_FATAL, [3] DMA_BUSY, [4] DMA_FENCED, [5] IRQ_PENDING, [6] NP_CREDIT_OK, [7] P_CREDIT_OK, "
                                                  "[15:8] N_OUTSTANDING tags, [23:16] N_ZOMBIE tags, [27:24] REC_STATE"),
    ("ERR_STATUS",    0x01C, "W1C", "0",          "sticky error classes (bit per class, see SFPB_ES_*)"),
    ("ERR_MASK",      0x020, "RW",  "0xFFFF",     "classes that raise the ERR interrupt source"),
    ("ERR_LOG0",      0x024, "RO",  "0",          "FIRST error since the last ERR_LOG_CLR (single-entry log): [5:0] code (SFPB_E_*), [8] valid, [23:16] number of further errors NOT recorded (saturates at 255)"),
    ("ERR_LOG1",      0x028, "RO",  "0",          "first error: address [31:0]"),
    ("ERR_LOG2",      0x02C, "RO",  "0",          "first error: address [63:32]"),
    ("ERR_LOG3",      0x030, "RO",  "0",          "first error: [7:0] tag, [23:8] requester id, [27:24] request type, [31:28] context/domain"),
    ("ERR_LOG_CLR",   0x034, "WO",  "-",          "write 1: clear the error log (valid bit and the not-recorded count); the next error is recorded"),
    ("IRQ_STATUS",    0x040, "W1C", "0",          "[0] DMA_CPL, [1] DMA_ERR, [2] ERR, [3] RECOVERY, [4] STREAMDMA_IRQ, [7:5] EXT0..2"),
    ("IRQ_MASK",      0x044, "RW",  "0",          "enable bits for IRQ_STATUS"),
    ("IRQ_VECMAP",    0x048, "RW",  "0x76543210", "4 bits per source: MSI vector number (folded to the vectors the host enabled)"),
    ("IRQ_CTRL",      0x04C, "RW",  "0x00000031", "[0] MSI_EN (0 = polling-only), [7:4] MSI retry limit"),
    ("IRQ_FAIL_CNT",  0x050, "RO",  "0",          "MSI requests the endpoint reported as failed"),
    ("IRQ_SENT_CNT",  0x054, "RO",  "0",          "MSI requests the endpoint reported as sent"),
    ("IRQ_SET",       0x058, "WO",  "-",          "write 1 bits: raise IRQ_STATUS bits (software interrupt / self-test)"),
    ("CPL_TIMEOUT",   0x060, "RW",  "0x00000040", "completion timeout in tag-timer ticks (0 = disabled)"),
    ("SFB_TIMEOUT",   0x064, "RW",  "0x00001000", "DataFabric response timeout in cycles (0 = disabled)"),
    ("REC_QUIET",     0x068, "RW",  "0x00000400", "cycles of quiet after link-up before quarantined tags are released"),
    ("DMA_CTRL",      0x070, "RW",  "0",          "[0] ABORT (W1 pulse), [1] SOFT_RESET (W1 pulse)"),
    ("DMA_STATUS",    0x074, "RO",  "-",          "[0] busy, [1] fenced, [2] guard protocol error, [3] soft reset pending"),
    ("DMA_TIMEOUT",   0x078, "RW",  "0x00010000", "StreamDMA watchdog (cycles without progress), 0 = off"),
    ("DMA_TYPE_EN",   0x07C, "RW",  "0x00000003", "StreamDMA enabled memory types (bit per type)"),
    ("DMA_PERF_SEL",  0x080, "RW",  "0",          "StreamDMA performance counter index"),
    ("DMA_PERF_LO",   0x084, "RO",  "-",          "selected StreamDMA counter [31:0] (reading LO latches HI)"),
    ("DMA_PERF_HI",   0x088, "RO",  "-",          "selected StreamDMA counter [63:32]"),
    ("DMA_ERR_LOG0",  0x090, "RO",  "0",          "last DMA egress violation: [5:0] code, [11:8] domain, [12] valid, [13] write"),
    ("DMA_ERR_LOG1",  0x094, "RO",  "0",          "last DMA egress violation: IOVA [31:0]"),
    ("DMA_ERR_LOG2",  0x098, "RO",  "0",          "last DMA egress violation: IOVA [63:32]"),
    ("PERF_SEL",      0x0A0, "RW",  "0",          "bridge performance counter index (SFPB_PC_*)"),
    ("PERF_LO",       0x0A4, "RO",  "-",          "selected counter [31:0] (reading LO latches HI)"),
    ("PERF_HI",       0x0A8, "RO",  "-",          "selected counter [63:32]"),
    ("PERF_N",        0x0AC, "RO",  "(const)",    "number of counters"),
]

# DMA submission page, offsets inside page 1+c
CTXPAGE = [
    ("DESC0",         0x000, "RW", "0", "StreamDMA descriptor word 0 .. 7 (ABI v1, 256 bit): W0 [7:0] version=1, [15:8] opcode=0 (COPY), [31:16] flags"),
    ("DESC1",         0x004, "RW", "0", "W1 [15:0] txn id, [31:16] domain claim (must equal this context's domain)"),
    ("DESC2",         0x008, "RW", "0", "W2 [3:0] source memory type, [7:4] destination memory type"),
    ("DESC3",         0x00C, "RW", "0", "W3 length in bytes"),
    ("DESC4",         0x010, "RW", "0", "W4 source address [31:0]   (a host IOVA when the type is HOST)"),
    ("DESC5",         0x014, "RW", "0", "W5 source address [63:32]"),
    ("DESC6",         0x018, "RW", "0", "W6 destination address [31:0]"),
    ("DESC7",         0x01C, "RW", "0", "W7 destination address [63:32]"),
    ("DOORBELL",      0x020, "WO", "-", "write bit 0: validate the staged descriptor and submit it"),
    ("SUBMIT_STATUS", 0x024, "RO", "0", "[3:0] 0 none, 1 accepted, 2 busy (retry), 3 rejected; [13:8] reject code (SFPB_E_*)"),
    ("CPL_STATUS",    0x028, "RO", "0", "[3:0] completion records queued, [8] overflow (a record was dropped), [9] LOST (a recovery wiped descriptors that were accepted but unfinished; sticky), [31:16] submitted-minus-completed"),
    ("CPL_POP",       0x02C, "WO", "-", "bit 0: pop the head record; bit 1: clear the overflow flag; bit 2: clear the LOST flag"),
    ("CPL_REC0",      0x030, "RO", "0", "head record R0 [15:0] txn id, [19:16] domain, [27:24] status (0 OK, 1 ERROR, 2 ABORTED, 3 TIMEOUT), [31] partial"),
    ("CPL_REC1",      0x034, "RO", "0", "R1 [7:0] StreamDMA error code, [11:8] detail, [21:16] bridge/PCIe error code (SFPB_E_*)"),
    ("CPL_REC2",      0x038, "RO", "0", "R2 bytes done [31:0]"),
    ("CPL_REC3",      0x03C, "RO", "0", "R3 bytes total [31:0]"),
    ("CPL_REC4",      0x040, "RO", "0", "R4 error address [31:0]"),
    ("CPL_REC5",      0x044, "RO", "0", "R5 error address [63:32]"),
    ("CPL_REC6",      0x048, "RO", "0", "R6 latency in cycles"),
    ("CTX_INFO",      0x050, "RO", "-", "[0] context valid, [1] read (host->device) allowed, [2] write (device->host) allowed, [3] translation on, [7:4] domain"),
]

# Privileged configuration port: address bits [11:0]; context table at ctx*0x40
PRIV_CTX = [
    ("CTX_CTRL",      0x00, "RW", "0", "[0] VALID, [1] RD_OK (device may read host memory), [2] WR_OK (device may write host memory), [3] XLAT_EN"),
    ("IOVA_BASE_LO",  0x04, "RW", "0", "host IOVA window base [31:0]"),
    ("IOVA_BASE_HI",  0x08, "RW", "0", "[63:32]"),
    ("IOVA_SIZE_LO",  0x0C, "RW", "0", "window size in bytes [31:0]"),
    ("IOVA_SIZE_HI",  0x10, "RW", "0", "[63:32]"),
    ("BUS_BASE_LO",   0x14, "RW", "0", "PCIe bus address that IOVA_BASE translates to [31:0] (XLAT_EN), otherwise ignored (identity)"),
    ("BUS_BASE_HI",   0x18, "RW", "0", "[63:32]"),
    ("DEV_BASE_LO",   0x1C, "RW", "0", "device-side window base [31:0]"),
    ("DEV_BASE_HI",   0x20, "RW", "0", "[63:32]"),
    ("DEV_SIZE_LO",   0x24, "RW", "0", "device-side window size [31:0]"),
    ("DEV_SIZE_HI",   0x28, "RW", "0", "[63:32]"),
    ("MAX_LEN",       0x2C, "RW", "0", "largest descriptor length in bytes (0 = nothing allowed)"),
    ("COMMIT",        0x30, "WO", "-", "write 1: atomically publish the staged entry (refused while DMA is not quiescent)"),
    ("COMMIT_STATUS", 0x34, "RO", "0", "[0] last commit applied, [7:4] refusal code: 1 busy, 2 alignment, 3 range overflow, 4 locked"),
]
PRIV_GLOBAL = [
    ("PRIV_CTRL",     0x800, "RW", "0", "[0] LOCK (set-only until reset): no further context commits"),
    ("PRIV_STATUS",   0x804, "RO", "-", "[0] locked, [1] DMA quiescent"),
]

# bridge performance counters (index -> name, meaning)
PERF = [
    ("CYCLES",         "cycles counted while PERF_EN"),
    ("CQ_TLPS",        "request TLPs accepted from the endpoint (all types)"),
    ("CQ_MRD",         "memory reads accepted"),
    ("CQ_MWR",         "memory writes accepted"),
    ("CQ_BAD",         "request TLPs rejected by the adapter (malformed / oversize)"),
    ("CC_TLPS",        "completion TLPs sent"),
    ("RQ_MRD",         "memory read requests sent (DMA, flush)"),
    ("RQ_MWR",         "memory write requests sent"),
    ("RC_TLPS",        "completion TLPs received"),
    ("MMIO_RD_LAT_SUM", "sum over MMIO reads of cycles from request accepted to first completion beat out"),
    ("MMIO_RD_LAT_CNT", "number of MMIO reads measured"),
    ("MMIO_RD_LAT_MIN", "minimum MMIO read latency (cycles)"),
    ("MMIO_RD_LAT_MAX", "maximum MMIO read latency (cycles)"),
    ("MMIO_WR_LAT_SUM", "sum over MMIO writes of cycles from request accepted to last effect (response seen)"),
    ("MMIO_WR_LAT_CNT", "number of MMIO writes measured"),
    ("CPL_LAT_SUM",    "sum over DMA read requests of cycles from request issue to final completion"),
    ("CPL_LAT_CNT",    "number of DMA read requests completed"),
    ("CPL_LAT_MAX",    "maximum completion latency (cycles)"),
    ("DMA_RD_BYTES",   "payload bytes delivered to StreamDMA (host -> device)"),
    ("DMA_WR_BYTES",   "payload bytes sent to the host (device -> host)"),
    ("DMA_ACTIVE",     "cycles with any DMA request outstanding in the adapter"),
    ("OUT_MAX",        "peak outstanding non-posted requests"),
    ("OUT_SUM",        "sum over cycles of outstanding non-posted requests (divide by CYCLES for the average)"),
    ("HDRQ_MAX",       "peak request-header queue occupancy"),
    ("PAYQ_MAX",       "peak request-payload RAM occupancy (beats)"),
    ("BP_CQ",          "cycles the endpoint offered a CQ beat that was not accepted"),
    ("BP_CC",          "cycles a CC beat was waiting for the endpoint"),
    ("BP_RQ",          "cycles an RQ beat was waiting for the endpoint"),
    ("BP_SFB",         "cycles an SFB2 request was waiting for the fabric"),
    ("HDR_BYTES",      "TLP header bytes moved (all four channels)"),
    ("PAY_BYTES",      "TLP payload bytes moved (all four channels)"),
    ("ERR_EVENTS",     "error events logged (all classes)"),
    ("ORD_STALL",      "cycles a completion or interrupt was held by the posted-write ordering gate"),
    ("CPL_UNEXPECTED", "completions that matched no outstanding request"),
    ("TAG_STALL",      "cycles a DMA read waited for a free tag"),
    ("CRED_STALL",     "cycles a request waited for flow-control credit"),
]

ES = ["MALFORMED", "UNSUPPORTED", "BAR", "POISONED", "FABRIC", "CSR", "CPL_ERR", "CPL_TIMEOUT", "CPL_UNEXP", "DMA_PROT",
      "DMA_BUS", "LINK", "FLR", "RECOVERED", "IRQ_FAIL", "OVERFLOW"]


def svh():
    o = ["// GENERATED by scripts/gen_regs.py -- do not edit.", "`ifndef SF_PCIE_REGS_SVH", "`define SF_PCIE_REGS_SVH", ""]
    o.append("// ---- global register page (BAR0 + 0x000) ----")
    for n, off, *_ in GLOBAL:
        o.append("`define SFPB_R_%-14s 12'h%03X" % (n, off))
    o.append("\n// ---- DMA submission page registers (offsets inside page 1+c) ----")
    for n, off, *_ in CTXPAGE:
        o.append("`define SFPB_C_%-14s 12'h%03X" % (n, off))
    o.append("\n// ---- privileged port: per-context entry (offset inside ctx*0x40) and global registers ----")
    for n, off, *_ in PRIV_CTX:
        o.append("`define SFPB_P_%-14s 6'h%02X" % (n, off))
    for n, off, *_ in PRIV_GLOBAL:
        o.append("`define SFPB_P_%-14s 12'h%03X" % (n, off))
    o.append("\n// ---- bridge performance counter indices ----")
    for i, (n, _) in enumerate(PERF):
        o.append("`define SFPB_PC_%-16s %d" % (n, i))
    o.append("`define SFPB_PC_N                %d" % len(PERF))
    o.append("\n`endif")
    return "\n".join(o) + "\n"


def hdr():
    o = ["// GENERATED by scripts/gen_regs.py -- do not edit.", "#pragma once", "#include <cstdint>", "namespace sfpb {"]
    o.append("// global register page")
    for n, off, *_ in GLOBAL:
        o.append("constexpr uint32_t R_%s = 0x%03X;" % (n, off))
    o.append("// DMA submission page registers (add 0x1000*(1+ctx))")
    for n, off, *_ in CTXPAGE:
        o.append("constexpr uint32_t C_%s = 0x%03X;" % (n, off))
    o.append("// privileged port")
    for n, off, *_ in PRIV_CTX:
        o.append("constexpr uint32_t P_%s = 0x%02X;" % (n, off))
    for n, off, *_ in PRIV_GLOBAL:
        o.append("constexpr uint32_t P_%s = 0x%03X;" % (n, off))
    o.append("// performance counters")
    for i, (n, _) in enumerate(PERF):
        o.append("constexpr uint32_t PC_%s = %d;" % (n, i))
    o.append("constexpr uint32_t PC_N = %d;" % len(PERF))
    o.append("// ERR_STATUS classes")
    for i, n in enumerate(ES):
        o.append("constexpr uint32_t ES_%s = 1u << %d;" % (n, i))
    o.append("}")
    return "\n".join(o) + "\n"


def md():
    o = ["# 03 — Register map (generated)", "",
         "Generated by `scripts/gen_regs.py` from one table; the RTL (`rtl/sf_pcie_regs.svh`) and the C++ benches "
         "(`tb/cpp/sf_pcie_regs.h`) use the same offsets. Do not edit by hand.", "",
         "All registers are 32 bit, little-endian, accessed with memory read/write TLPs. Writes honour the TLP byte enables; "
         "a read always returns the full dword. Reads of read-sensitive registers must be single-dword requests.", "",
         "## BAR layout", ""]
    for title, rows in BARS:
        o.append("**%s**" % title)
        o.append("")
        o.append("| Offset | Contents |")
        o.append("|---|---|")
        for a, b in rows:
            o.append("| `%s` | %s |" % (a, b))
        o.append("")
    o += ["## 1. Global register page (BAR0 `0x000`–`0xFFF`)", "", "| Offset | Name | Access | Reset | Description |", "|---|---|---|---|---|"]
    for n, off, acc, rst, txt in GLOBAL:
        o.append("| `0x%03X` | `%s` | %s | `%s` | %s |" % (off, n, acc, rst, txt))
    o += ["", "## 2. DMA submission page (BAR0 `0x1000*(1+c)`, context `c`)", "",
          "The context is selected by **which page the host writes**, not by a descriptor field: the page index is "
          "the hardware-derived identity that becomes the trusted `desc_domain` of the StreamDMA descriptor "
          "(domain = context index). A host cannot name another context's domain.", "",
          "| Offset | Name | Access | Reset | Description |", "|---|---|---|---|---|"]
    for n, off, acc, rst, txt in CTXPAGE:
        o.append("| `0x%03X` | `%s` | %s | `%s` | %s |" % (off, n, acc, rst, txt))
    o += ["", "## 3. Privileged configuration port (`priv_*`, **not** reachable from the host BAR)", "",
          "Per-context table entry at `ctx*0x40 + offset`. Writes go to a staging copy; `COMMIT` publishes it atomically "
          "and only while no DMA request is outstanding (`quiesce before unmapping`). `domain == context index`.", "",
          "| Offset | Name | Access | Reset | Description |", "|---|---|---|---|---|"]
    for n, off, acc, rst, txt in PRIV_CTX:
        o.append("| `0x%02X` | `%s` | %s | `%s` | %s |" % (off, n, acc, rst, txt))
    for n, off, acc, rst, txt in PRIV_GLOBAL:
        o.append("| `0x%03X` | `%s` | %s | `%s` | %s |" % (off, n, acc, rst, txt))
    o += ["", "## 4. ERR_STATUS classes", "", "| Bit | Class |", "|---|---|"]
    for i, n in enumerate(ES):
        o.append("| %d | `%s` |" % (i, n))
    o += ["", "## 5. Performance counters (`PERF_SEL` index)", "", "64-bit; read `PERF_LO` first (it latches `PERF_HI`).", "",
          "| Index | Name | Meaning |", "|---|---|---|"]
    for i, (n, t) in enumerate(PERF):
        o.append("| %d | `%s` | %s |" % (i, n, t))
    return "\n".join(o) + "\n"


def main():
    outs = {os.path.join(ROOT, "rtl", "sf_pcie_regs.svh"): svh(),
            os.path.join(ROOT, "tb", "cpp", "sf_pcie_regs.h"): hdr(),
            os.path.join(ROOT, "docs", "03_REGISTER_MAP.md"): md()}
    stale = False
    for p, s in outs.items():
        if "--check" in sys.argv:
            if not os.path.exists(p) or open(p).read() != s:
                print("STALE:", p); stale = True
        else:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "w").write(s)
    if "--check" in sys.argv:
        sys.exit(1 if stale else 0)
    print("generated", len(outs), "files;", len(PERF), "perf counters")


if __name__ == "__main__":
    main()
