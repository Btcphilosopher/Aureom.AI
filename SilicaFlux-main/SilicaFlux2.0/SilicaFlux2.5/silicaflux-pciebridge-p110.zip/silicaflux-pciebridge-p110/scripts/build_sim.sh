#!/bin/bash
# Build a Verilated simulation of sf_pcie_sim_top and a C++ bench.  usage: build_sim.sh <DATA_W> <bench.cpp> [extra verilator args]
set -e
P="$(cd "$(dirname "$0")/.." && pwd)"
W=$1; SRC=$(realpath "$2"); shift 2
NAME=$(basename "$SRC" .cpp)
D="${BUILD_DIR:-$P/build/$NAME-w$W}"
RTLD="${RTL_DIR:-$P/rtl}"
mkdir -p "$D"
RTL=$(sed "s|^|$RTLD/|" "$RTLD/files.f" | tr '\n' ' ')
TP="$P/third_party"
SD="$TP/streamdma-p103/rtl/sf_stream_dma_plan.sv $TP/streamdma-p103/rtl/sf_stream_dma_dcheck.sv $TP/streamdma-p103/rtl/sf_stream_dma_queue.sv
    $TP/streamdma-p103/rtl/sf_stream_dma_descriptor.sv $TP/streamdma-p103/rtl/sf_stream_dma_buffer.sv $TP/streamdma-p103/rtl/sf_stream_dma_align.sv
    $TP/streamdma-p103/rtl/sf_stream_dma_read.sv $TP/streamdma-p103/rtl/sf_stream_dma_write.sv $TP/streamdma-p103/rtl/sf_stream_dma_cpl.sv
    $TP/streamdma-p103/rtl/sf_stream_dma_perf.sv $TP/streamdma-p103/rtl/sf_stream_dma.sv $TP/p61-clouddpu/rtl/sfd_fifo.sv
    $TP/clouddma-p64/rtl/silicaflux_dma_pkg.sv $TP/clouddma-p64/rtl/sfdma_perm_checker.sv $TP/clouddma-p64/rtl/sfdma_perm_table.sv"
verilator --cc --exe --build -Wno-fatal -Wno-lint -Wno-style --Mdir "$D" -O1 \
  -GDATA_W=$W "$@" -CFLAGS "-DDW=$W -O1 -I$P/tb/cpp -std=c++17" \
  --top-module sf_pcie_sim_top -I"$RTLD" -I"$TP/streamdma-p103/rtl" \
  $RTL $SD "$P/tb/sv/sf_pcie_sim_top.sv" "$SRC" -o bench > "$D/build.log" 2>&1 || { grep -E "%Error|error:" "$D/build.log" | head -30; exit 1; }
echo "$D/bench"
