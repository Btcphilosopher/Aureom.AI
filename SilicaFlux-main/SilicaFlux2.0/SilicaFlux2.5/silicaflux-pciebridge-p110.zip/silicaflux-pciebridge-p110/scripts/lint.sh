#!/bin/bash
# Verilator -Wall over the whole bridge.  The log goes to reports/lint.log; the exit status is non-zero on any warning.
P="$(cd "$(dirname "$0")/.." && pwd)"; mkdir -p "$P/reports"
FILES=$(sed "s|^|$P/rtl/|" "$P/rtl/files.f" | tr '\n' ' ')
{ echo "# verilator $(verilator --version)"; echo "# verilator --lint-only -Wall -Wno-DECLFILENAME --top-module sf_pcie_transaction_bridge (DATA_W 128 and 256)"; } > "$P/reports/lint.log"
rc=0
for w in 128 256; do
  out=$(verilator --lint-only -Wall -Wno-DECLFILENAME -GDATA_W=$w --top-module sf_pcie_transaction_bridge -I"$P/rtl" $FILES 2>&1)
  n=$(echo "$out" | grep -c "^%Warning\|^%Error")
  echo "DATA_W=$w: $n warning(s)/error(s)" | tee -a "$P/reports/lint.log"
  [ "$n" -ne 0 ] && { echo "$out" | head -40 | tee -a "$P/reports/lint.log"; rc=1; }
done
exit $rc
