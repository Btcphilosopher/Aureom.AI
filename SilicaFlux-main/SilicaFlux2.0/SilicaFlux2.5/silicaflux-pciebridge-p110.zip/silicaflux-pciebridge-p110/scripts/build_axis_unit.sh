#!/bin/bash
# Build and run the pack/unpack unit test for every width/header combination.
set -e
P="$(cd "$(dirname "$0")/.." && pwd)"; mkdir -p "$P/build/axis"
for cfg in "128 4" "128 3" "256 4" "256 3"; do
  set -- $cfg; D="$P/build/axis/w$1h$2"; rm -rf "$D"
  verilator --cc --exe --build -Wall -Wno-fatal --Mdir "$D" -GDATA_W=$1 -GHDR_DW=$2 \
    -CFLAGS "-DDW=$1 -DHDW=$2 -O1 -I$P/tb/cpp" --top-module tb_axis_unit -I"$P/rtl" \
    "$P/rtl/sf_pcie_axis_unpack.sv" "$P/rtl/sf_pcie_axis_pack.sv" "$P/tb/sv/tb_axis_unit.sv" "$P/tb/cpp/tb_axis_unit.cpp" -o tb > "$D.build.log" 2>&1 || { tail -30 "$D.build.log"; exit 1; }
  "$D/tb"
done
