#!/bin/bash
# Performance measurement at both stream widths -> reports/perf_w128.md, reports/perf_w256.md
P="$(cd "$(dirname "$0")/.." && pwd)"; mkdir -p "$P/reports"
for w in 128 256; do
  exe=$("$P/scripts/build_sim.sh" $w "$P/tb/cpp/tb_perf.cpp" 2>&1 | tail -1)
  [ -x "$exe" ] || { echo "BUILD FAILED W=$w"; exit 1; }
  ( cd "$P/reports" && "$exe" "$P/reports/perf_w$w.md" ) || exit 1
  echo "wrote reports/perf_w$w.md"
done
