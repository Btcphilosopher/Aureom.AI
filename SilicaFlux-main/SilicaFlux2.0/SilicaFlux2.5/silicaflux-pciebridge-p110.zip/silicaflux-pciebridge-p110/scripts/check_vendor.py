#!/usr/bin/env python3
"""Verify the vendored third-party sources.

  python3 scripts/check_vendor.py                      # every file matches third_party/SHA256SUMS
  python3 scripts/check_vendor.py --archive <zip>      # ... and is byte-identical to the file inside the SilicaFlux archive
                                                       #     silicaflux-streamdma-p103-r2.zip (sha256 10ef00dc...01c7)

Nothing under third_party/ is ever edited by this project; this is the proof.
"""
import hashlib, os, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TP = os.path.join(ROOT, "third_party")
ARCHIVE_SHA256 = "10ef00dcb4ea6cda723a2433e508307690e3e09a3be4fa61915e5109066d01c7"
# vendored directory -> directory inside the archive
MAP = {
    "streamdma-p103/rtl/":          "silicaflux-streamdma-p103/rtl/stream_dma/",
    "streamdma-p103/README_P103.md": "silicaflux-streamdma-p103/README.md",          # renamed on import (this project has its own README)
    "p61-clouddpu/rtl/":            "silicaflux-streamdma-p103/third_party/p61-clouddpu/rtl/",
    "clouddma-p64/rtl/":            "silicaflux-streamdma-p103/third_party/clouddma-p64/rtl/",
}

def sha(b): return hashlib.sha256(b).hexdigest()

def main():
    bad = 0
    listed = {}
    for line in open(os.path.join(TP, "SHA256SUMS")):
        h, p = line.split(None, 1); listed[os.path.normpath(p.strip())] = h
    for p, h in sorted(listed.items()):
        f = os.path.join(TP, p)
        if not os.path.isfile(f): print("MISSING ", p); bad += 1; continue
        if sha(open(f, "rb").read()) != h: print("MODIFIED", p); bad += 1
    have = set()
    for dp, _, fs in os.walk(TP):
        for f in fs:
            r = os.path.normpath(os.path.relpath(os.path.join(dp, f), TP))
            if r not in ("SHA256SUMS", "PROVENANCE.md"): have.add(r)
    for r in sorted(have - set(listed)): print("UNLISTED", r); bad += 1
    print("%d vendored files checked against SHA256SUMS: %s" % (len(listed), "OK" if not bad else "%d problem(s)" % bad))
    if "--archive" in sys.argv:
        z = sys.argv[sys.argv.index("--archive") + 1]
        if sha(open(z, "rb").read()) != ARCHIVE_SHA256: print("archive sha256 differs from the recorded one"); bad += 1
        zf = zipfile.ZipFile(z); names = set(zf.namelist()); n = 0
        for p in sorted(listed):
            src = None
            for vd, ad in MAP.items():
                if p.replace(os.sep, "/").startswith(vd.rstrip("/")) and (vd.endswith("/") or p.replace(os.sep, "/") == vd):
                    src = ad + p.replace(os.sep, "/")[len(vd):] if vd.endswith("/") else ad; break
            if src is None or src not in names: print("NOT IN ARCHIVE", p, src); bad += 1; continue
            if zf.read(src) != open(os.path.join(TP, p), "rb").read(): print("DIFFERS FROM ARCHIVE", p); bad += 1
            n += 1
        print("%d files compared with the archive: %s" % (n, "OK" if not bad else "problems found"))
    sys.exit(1 if bad else 0)

if __name__ == "__main__":
    main()
