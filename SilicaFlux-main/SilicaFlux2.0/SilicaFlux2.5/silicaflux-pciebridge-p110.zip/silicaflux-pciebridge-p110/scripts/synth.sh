#!/bin/bash
# Yosys generic-gate synthesis of every module and of the bridge top at DATA_W = 128 and 256.
#
# WHAT THIS IS: structural estimates (cell counts, flip-flop bits, memory bits, latch / loop checks) from Yosys's technology-
# independent `synth`.  WHAT IT IS NOT: there is no timing, no vendor / PDK mapping, no place-and-route, no power -- so there is
# no area, frequency or power claim anywhere in this project.  Memory arrays are mapped to flip-flops (no RAM macro is assumed).
# usage: scripts/synth.sh [jobs]        -> reports/synth/*.log, reports/synth/summary.md
P="$(cd "$(dirname "$0")/.." && pwd)"; OUT="$P/reports/synth"; mkdir -p "$OUT"; JOBS=${1:-3}
FILES=$(sed "s|^|$P/rtl/|" "$P/rtl/files.f" | tr '\n' ' ')
MODS="sf_pcie_fifo sf_pcie_axis_unpack sf_pcie_axis_pack sf_pcie_request_adapter sf_pcie_bar_decoder sf_pcie_mmio_engine sf_pcie_csr sf_pcie_perf sf_pcie_completion_adapter sf_pcie_win_check sf_pcie_dma_ctx sf_pcie_dma_submit sf_pcie_tag_tracker sf_pcie_dma_adapter sf_pcie_interrupt_adapter"
run() {   # $1 = top module, $2 = tag, $3 = optional DATA_W
  top=$1; tag=$2; w=$3; log="$OUT/$tag.log"
  chp=""; [ -n "$w" ] && chp="chparam -set DATA_W $w $top;"
  yosys -l "$log" -q -p "read_verilog -sv -I$P/rtl $FILES; $chp hierarchy -check -top $top; proc; opt_clean; check -assert; \
                         tee -o $OUT/$tag.mem.txt stat; \
                         synth -top $top -flatten; opt_clean -purge; check -assert; tee -o $OUT/$tag.stat.txt stat" > "$OUT/$tag.run" 2>&1
  echo "$tag: exit $?"
}
export -f run; export OUT FILES P
{ for m in $MODS; do echo "$m $m"; done; echo "sf_pcie_transaction_bridge top_w256 256"; echo "sf_pcie_transaction_bridge top_w128 128"; } \
  | xargs -P "$JOBS" -L1 bash -c 'run $0 $1 $2'
sed -i "s|$P|<project>|g" "$OUT"/*.log "$OUT"/*.run "$OUT"/*.txt 2>/dev/null     # no build-machine paths in the shipped logs
python3 "$P/scripts/synth_summary.py" "$OUT" > "$OUT/summary.md"
echo "wrote $OUT/summary.md"
