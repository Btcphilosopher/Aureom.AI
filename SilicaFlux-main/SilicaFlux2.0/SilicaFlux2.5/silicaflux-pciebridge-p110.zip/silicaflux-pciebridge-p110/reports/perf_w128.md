## DATA_W = 128 bit endpoint stream (4 dwords/beat), DMA datapath 128 bit

### MMIO latency (cycles at the endpoint boundary: request SOP accepted on CQ -> completion SOP accepted on CC)

| access | fabric latency | n | min | avg | max | DUT counter avg (engine accept -> first CC beat) |
|---|---|---|---|---|---|---|
| CSR read, 1 DW | 1 | 40 | 7 | 7.0 | 7 | 2.9 |
| fabric read, 1 DW | 1 | 40 | 8 | 8.0 | 8 | 3.8 |
| fabric read, 16 DW | 1 | 40 | 27 | 27.0 | 27 | 18.1 |
| CSR read, 1 DW | 4 | 40 | 7 | 7.0 | 7 | 2.9 |
| fabric read, 1 DW | 4 | 40 | 11 | 11.0 | 11 | 6.7 |
| fabric read, 16 DW | 4 | 40 | 50 | 50.0 | 50 | 40.0 |
| CSR read, 1 DW | 8 | 40 | 7 | 7.0 | 7 | 2.9 |
| fabric read, 1 DW | 8 | 40 | 15 | 15.0 | 15 | 10.5 |
| fabric read, 16 DW | 8 | 40 | 74 | 74.0 | 74 | 62.9 |

### MMIO posted-write rate into the DataFabric (fabric always ready, 1-cycle response)

| TLP | dwords/TLP | TLPs | cycles | dwords per cycle |
|---|---|---|---|---|
| MWr to BAR2 | 1 | 264 | 1579 | 0.167 |
| MWr to BAR2 | 4 | 72 | 643 | 0.448 |
| MWr to BAR2 | 16 | 24 | 571 | 0.673 |
| MWr to BAR2 | 64 | 12 | 1003 | 0.766 |

### DMA throughput (bytes/cycle = length / StreamDMA transaction latency; 16 B/cycle is the 128-bit datapath ceiling)

| direction | length | MRRS/MPS | root latency | strict ack | cycles | bytes/cycle | tags in flight (max / avg) | avg completion latency | TLPs (rd+wr) | header B per payload B |
|---|---|---|---|---|---|---|---|---|---|---|
| host -> device | 1024 B | 512/256 B | 20 | no | 207 | 4.95 | 4 / 0.24 | 90 | 4 | 2.935 |
| host -> device | 4096 B | 512/256 B | 20 | no | 486 | 8.43 | 4 / 0.55 | 61 | 16 | 1.381 |
| host -> device | 16384 B | 512/256 B | 20 | no | 1559 | 10.51 | 4 / 1.21 | 54 | 64 | 0.689 |
| host -> device | 65536 B | 512/256 B | 20 | no | 5948 | 11.02 | 4 / 1.83 | 52 | 256 | 0.484 |
| host -> device | 65536 B | 256/256 B | 20 | no | 5860 | 11.18 | 4 / 1.86 | 52 | 256 | 0.481 |
| host -> device | 65536 B | 128/128 B | 20 | no | 5914 | 11.08 | 8 / 3.34 | 47 | 512 | 0.539 |
| host -> device | 65536 B | 512/256 B | 100 | no | 10650 | 6.15 | 4 / 3.02 | 141 | 256 | 0.616 |
| host -> device | 65536 B | 512/256 B | 300 | no | 24947 | 2.63 | 4 / 3.52 | 361 | 256 | 0.999 |
| device -> host | 1024 B | 512/256 B | 20 | no | 146 | 7.01 | 0 / 0.00 | 0 | 4 | 2.776 |
| device -> host | 4096 B | 512/256 B | 20 | no | 364 | 11.25 | 0 / 0.00 | 0 | 16 | 1.143 |
| device -> host | 16384 B | 512/256 B | 20 | no | 1167 | 14.04 | 0 / 0.00 | 0 | 64 | 0.411 |
| device -> host | 65536 B | 512/256 B | 20 | no | 4443 | 14.75 | 0 / 0.00 | 0 | 256 | 0.193 |
| device -> host | 65536 B | 256/256 B | 20 | no | 4451 | 14.72 | 0 / 0.00 | 0 | 256 | 0.194 |
| device -> host | 65536 B | 128/128 B | 20 | no | 4688 | 13.98 | 0 / 0.00 | 0 | 512 | 0.271 |
| device -> host | 65536 B | 512/256 B | 100 | no | 4449 | 14.73 | 0 / 0.00 | 0 | 256 | 0.194 |
| device -> host | 65536 B | 512/256 B | 300 | no | 4428 | 14.80 | 0 / 0.00 | 0 | 256 | 0.193 |
| device -> host | 16384 B | 512/256 B | 20 | yes | 1169 | 14.02 | 0 / 0.00 | 0 | 64 | 0.411 |

### Queue occupancy, back-pressure and overhead under a CQ flood with a slow fabric and a stalled completion path

| counter | value |
|---|---|
| CYCLES | 10309 |
| CQ_TLPS | 356 |
| CQ_MRD (executed) | 54 |
| CQ_MWR (executed) | 305 |
| CC_TLPS | 60 |
| HDRQ_MAX (request-header queue, entries) | 4 |
| PAYQ_MAX (payload RAM, beats) | 8 |
| BP_CQ (cycles) | 8833 |
| BP_CC (cycles) | 378 |
| BP_SFB (cycles) | 3844 |
| HDR_BYTES | 8336 |
| PAY_BYTES | 6536 |
| ERR_EVENTS | 0 |

Header overhead in this workload: 1.28 header bytes per payload byte.
