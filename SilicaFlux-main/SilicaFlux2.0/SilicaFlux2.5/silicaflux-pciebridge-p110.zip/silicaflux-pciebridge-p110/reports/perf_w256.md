## DATA_W = 256 bit endpoint stream (8 dwords/beat), DMA datapath 128 bit

### MMIO latency (cycles at the endpoint boundary: request SOP accepted on CQ -> completion SOP accepted on CC)

| access | fabric latency | n | min | avg | max | DUT counter avg (engine accept -> first CC beat) |
|---|---|---|---|---|---|---|
| CSR read, 1 DW | 1 | 40 | 7 | 7.0 | 7 | 2.9 |
| fabric read, 1 DW | 1 | 40 | 8 | 8.0 | 8 | 3.8 |
| fabric read, 16 DW | 1 | 40 | 25 | 25.0 | 25 | 18.1 |
| CSR read, 1 DW | 4 | 40 | 7 | 7.0 | 7 | 2.9 |
| fabric read, 1 DW | 4 | 40 | 11 | 11.0 | 11 | 6.7 |
| fabric read, 16 DW | 4 | 40 | 48 | 48.0 | 48 | 40.0 |
| CSR read, 1 DW | 8 | 40 | 7 | 7.0 | 7 | 2.9 |
| fabric read, 1 DW | 8 | 40 | 15 | 15.0 | 15 | 10.5 |
| fabric read, 16 DW | 8 | 40 | 72 | 72.0 | 72 | 62.9 |

### MMIO posted-write rate into the DataFabric (fabric always ready, 1-cycle response)

| TLP | dwords/TLP | TLPs | cycles | dwords per cycle |
|---|---|---|---|---|
| MWr to BAR2 | 1 | 264 | 1579 | 0.167 |
| MWr to BAR2 | 4 | 72 | 643 | 0.448 |
| MWr to BAR2 | 16 | 24 | 523 | 0.734 |
| MWr to BAR2 | 64 | 12 | 907 | 0.847 |

### DMA throughput (bytes/cycle = length / StreamDMA transaction latency; 16 B/cycle is the 128-bit datapath ceiling)

| direction | length | MRRS/MPS | root latency | strict ack | cycles | bytes/cycle | tags in flight (max / avg) | avg completion latency | TLPs (rd+wr) | header B per payload B |
|---|---|---|---|---|---|---|---|---|---|---|
| host -> device | 1024 B | 512/256 B | 20 | no | 185 | 5.54 | 4 / 0.18 | 64 | 4 | 2.918 |
| host -> device | 4096 B | 512/256 B | 20 | no | 481 | 8.52 | 4 / 0.45 | 49 | 16 | 1.381 |
| host -> device | 16384 B | 512/256 B | 20 | no | 1555 | 10.54 | 4 / 1.04 | 46 | 64 | 0.691 |
| host -> device | 65536 B | 512/256 B | 20 | no | 5962 | 10.99 | 4 / 1.58 | 44 | 256 | 0.486 |
| host -> device | 65536 B | 256/256 B | 20 | no | 6010 | 10.90 | 4 / 1.58 | 45 | 256 | 0.486 |
| host -> device | 65536 B | 128/128 B | 20 | no | 5837 | 11.23 | 8 / 2.86 | 40 | 512 | 0.534 |
| host -> device | 65536 B | 512/256 B | 100 | no | 10303 | 6.36 | 4 / 2.96 | 134 | 256 | 0.611 |
| host -> device | 65536 B | 512/256 B | 300 | no | 24302 | 2.70 | 4 / 3.53 | 352 | 256 | 0.984 |
| device -> host | 1024 B | 512/256 B | 20 | no | 154 | 6.65 | 0 / 0.00 | 0 | 4 | 2.802 |
| device -> host | 4096 B | 512/256 B | 20 | no | 349 | 11.74 | 0 / 0.00 | 0 | 16 | 1.180 |
| device -> host | 16384 B | 512/256 B | 20 | no | 1107 | 14.80 | 0 / 0.00 | 0 | 64 | 0.460 |
| device -> host | 65536 B | 512/256 B | 20 | no | 4177 | 15.69 | 0 / 0.00 | 0 | 256 | 0.244 |
| device -> host | 65536 B | 256/256 B | 20 | no | 4177 | 15.69 | 0 / 0.00 | 0 | 256 | 0.245 |
| device -> host | 65536 B | 128/128 B | 20 | no | 4188 | 15.65 | 0 / 0.00 | 0 | 512 | 0.306 |
| device -> host | 65536 B | 512/256 B | 100 | no | 4174 | 15.70 | 0 / 0.00 | 0 | 256 | 0.245 |
| device -> host | 65536 B | 512/256 B | 300 | no | 4181 | 15.67 | 0 / 0.00 | 0 | 256 | 0.245 |
| device -> host | 16384 B | 512/256 B | 20 | yes | 1105 | 14.83 | 0 / 0.00 | 0 | 64 | 0.457 |

### Queue occupancy, back-pressure and overhead under a CQ flood with a slow fabric and a stalled completion path

| counter | value |
|---|---|
| CYCLES | 10168 |
| CQ_TLPS | 356 |
| CQ_MRD (executed) | 54 |
| CQ_MWR (executed) | 305 |
| CC_TLPS | 60 |
| HDRQ_MAX (request-header queue, entries) | 4 |
| PAYQ_MAX (payload RAM, beats) | 4 |
| BP_CQ (cycles) | 8957 |
| BP_CC (cycles) | 205 |
| BP_SFB (cycles) | 3618 |
| HDR_BYTES | 8336 |
| PAY_BYTES | 6536 |
| ERR_EVENTS | 0 |

Header overhead in this workload: 1.28 header bytes per payload byte.
