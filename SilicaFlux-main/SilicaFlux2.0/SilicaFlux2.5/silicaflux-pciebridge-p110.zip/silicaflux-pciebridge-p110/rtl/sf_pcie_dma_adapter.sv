// =============================================================================
// sf_pcie_dma_adapter -- StreamDMA host-memory port  <->  endpoint Requester interface (RQ / RC).
//
//   StreamDMA ar/r/aw/w/b  --[egress check]--> read planner  -> RQ sequencer -> sf_pcie_axis_pack -> endpoint RQ
//                                              write planner ->      ^
//   endpoint RC -> (completion adapter) -> sf_pcie_tag_tracker -> slot buffers -> in-order R beats
//
// Egress protection (nothing reaches PCIe unless this passes): every AR / AW is checked against the trusted context
// selected by the StreamDMA domain sideband: context valid, direction permitted, whole byte range inside the IOVA
// window (65-bit arithmetic), beat-aligned envelope, INCR full-width bursts within the adapter's burst limit.  A
// violating request is answered with an error response (R beats / B with SLVERR) and logged; no TLP is formed.
//
// Reads:   one AR burst becomes 1..n memory-read TLPs (<= MRRS, <= RD_MAX_TLP_BYTES, never crossing 4 KiB).  Each
//          TLP owns a tag.  Completions may arrive in ANY order across tags (and split arbitrarily within a tag, in
//          address order); data is deposited by position into the burst's slot buffer and R beats are returned in AR
//          order once the whole burst has arrived and passed every check.  Any failure (UR/CA/poison/mismatch/timeout/
//          reset) returns the whole burst with SLVERR and zero data -- partial data is never handed to the DMA.
// Writes:  a burst is store-and-forwarded, its byte strobes must form ONE contiguous run (else error, nothing sent),
//          and becomes 1..n memory-write TLPs (<= MPS, never crossing 4 KiB) with first/last byte enables derived from
//          the strobes.  B is returned after the last TLP was handed to the endpoint ("posted accepted") or, with
//          flush_en, after a zero-length read of the written address has completed (writes visible at the root
//          complex ordering point; PCIe orders a read behind earlier posted writes from the same requester).
// Ordering: TLPs leave in a single stream.  Posted writes stay in order (one write burst at a time, address order);
//          DMA reads and writes are independent as on AXI (no AR/AW ordering is implied) and are interleaved round-robin;
//          a flush read is issued only after its own write's last TLP.  The counters ord_issued / ord_acked
//          (sequence-number acknowledge) feed the gate that stops completions and interrupts from overtaking these writes.
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
/* verilator lint_off PINCONNECTEMPTY */
module sf_pcie_dma_adapter #(
  parameter int DATA_W     = 256,           // endpoint stream width (128 | 256)
  parameter int DMA_DW     = 128,           // StreamDMA datapath width
  parameter int AW         = 48,            // StreamDMA address width
  parameter int RD_SLOTS   = 4,             // outstanding AR bursts (>= StreamDMA MAX_OUTSTANDING_READS)
  parameter int WR_SLOTS   = 4,             // outstanding AW bursts
  parameter int BURST_LEN  = 16,            // largest burst in beats
  parameter int DOM_W      = 4,
  parameter int TAGS       = 16,
  parameter int SEQ_W      = 6,             // sequence-number width of the endpoint's RQ interface
  parameter int ORD_W      = 8,             // modular TLP counters (inflight limit is 2**(ORD_W-2))
  parameter int RQ_USER_W  = 62,
  parameter int RQ_ACK_ON_ACCEPT = 0,       // 1: no sequence-number acknowledge from the endpoint -> count RQ accepts (weaker)
  parameter int RD_MAX_TLP_BYTES = 256,
  parameter int ORD_TIMEOUT = 4096,
  parameter int TICK_LOG2  = 8,
  parameter logic [3:0] HOST_MTYPE = `SFPB_SD_MT_DRAM,
  localparam int K         = DATA_W / 32,
  localparam int NW        = $clog2(K + 1),
  localparam int BEAT_B    = DMA_DW / 8,
  localparam int BEAT_DW   = DMA_DW / 32,
  localparam int BEAT_LOG2 = $clog2(BEAT_B),
  localparam int SLOT_DW   = BURST_LEN * BEAT_DW,
  localparam int OFF_W     = $clog2(SLOT_DW) + 1,
  localparam int SLW       = (RD_SLOTS > 1) ? $clog2(RD_SLOTS) : 1,
  localparam int WIW       = (WR_SLOTS > 1) ? $clog2(WR_SLOTS) : 1,
  localparam int TW        = $clog2(TAGS),
  localparam int WB_DW     = 2 * SLOT_DW,
  localparam int WBW       = $clog2(WB_DW)
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  input  wire logic                   flush,           // level: error out everything, accept nothing new
  input  wire logic                   clr,             // pulse: wipe all queues and slot state (after the DMA was reset)
  input  wire logic                   cfg_dma_en,
  input  wire logic                   cfg_wr_flush_en,
  input  wire logic [10:0]            cfg_mps_dw,      // endpoint max payload (dwords)
  input  wire logic [10:0]            cfg_mrrs_dw,     // endpoint max read request (dwords)
  input  wire logic                   rq_np_ok,        // flow control: a non-posted request may be sent
  input  wire logic                   rq_p_ok,         // flow control: a posted request may be sent
  // trusted context lookup
  output logic [3:0]                  a_ctx,
  input  wire logic                   a_valid, a_rd_ok, a_wr_ok, a_xlat,
  input  wire logic [63:0]            a_iova_base, a_iova_size, a_bus_base,
  // StreamDMA memory port (this block is the slave)
  input  wire logic                   ar_valid,
  output logic                        ar_ready,
  input  wire logic [SLW-1:0]         ar_id,
  input  wire logic [AW-1:0]          ar_addr,
  input  wire logic [7:0]             ar_len,
  input  wire logic [2:0]             ar_size,
  input  wire logic [1:0]             ar_burst,
  input  wire logic [3:0]             ar_mtype,
  input  wire logic [DOM_W-1:0]       ar_domain,
  output logic                        r_valid,
  input  wire logic                   r_ready,
  output logic [SLW-1:0]              r_id,
  output logic [DMA_DW-1:0]           r_data,
  output logic [1:0]                  r_resp,
  output logic                        r_last,
  input  wire logic                   aw_valid,
  output logic                        aw_ready,
  input  wire logic [WIW-1:0]         aw_id,
  input  wire logic [AW-1:0]          aw_addr,
  input  wire logic [7:0]             aw_len,
  input  wire logic [2:0]             aw_size,
  input  wire logic [1:0]             aw_burst,
  input  wire logic [3:0]             aw_mtype,
  input  wire logic [DOM_W-1:0]       aw_domain,
  input  wire logic                   w_valid,
  output logic                        w_ready,
  input  wire logic [DMA_DW-1:0]      w_data,
  input  wire logic [BEAT_B-1:0]      w_strb,
  input  wire logic                   w_last,
  output logic                        b_valid,
  input  wire logic                   b_ready,
  output logic [WIW-1:0]              b_id,
  output logic [1:0]                  b_resp,
  // endpoint RQ stream
  output logic [DATA_W-1:0]           m_rq_tdata,
  output logic [K-1:0]                m_rq_tkeep,
  output logic                        m_rq_tlast,
  output logic [RQ_USER_W-1:0]        m_rq_tuser,
  output logic                        m_rq_tvalid,
  input  wire logic                   m_rq_tready,
  input  wire logic                   rq_ack0, rq_ack1,    // endpoint sequence-number acknowledge (0..2 per cycle)
  // inbound completion beat stream
  input  wire logic                   rcv_valid,
  output logic                        rcv_ready,
  input  wire logic                   rcv_sop,
  input  wire logic                   rcv_eop,
  input  wire logic [DATA_W-1:0]      rcv_data,
  input  wire logic [NW-1:0]          rcv_ndw,
  input  wire logic                   rcv_bad,
  input  wire logic [6:0]             rcv_lower,
  input  wire logic [3:0]             rcv_err,
  input  wire logic [12:0]            rcv_bytecnt,
  input  wire logic [10:0]            rcv_dwcnt,
  input  wire logic [2:0]             rcv_status,
  input  wire logic                   rcv_poison,
  input  wire logic [15:0]            rcv_reqid,
  input  wire logic [7:0]             rcv_tag,
  // tracker configuration
  input  wire logic                   zombie_clr,
  input  wire logic [31:0]            cfg_timeout_ticks,
  input  wire logic [15:0]            cfg_req_id,
  input  wire logic                   cfg_check_reqid,
  // ordering counters
  output logic [ORD_W-1:0]            ord_issued,
  output logic [ORD_W-1:0]            ord_acked,
  // events
  output logic                        dmaev_valid,          // egress violation (DMA error log)
  output logic [5:0]                  dmaev_code,
  output logic [3:0]                  dmaev_dom,
  output logic                        dmaev_write,
  output logic [63:0]                 dmaev_addr,
  output logic                        ev_e_valid,           // generic error event, egress side
  output logic [5:0]                  ev_e_code,
  output logic [63:0]                 ev_e_addr,
  output logic [3:0]                  ev_e_ctx,
  output logic                        ev_c_valid,           // generic error event, completion / response side
  output logic [5:0]                  ev_c_code,
  output logic [63:0]                 ev_c_addr,
  output logic [3:0]                  ev_c_ctx,
  output logic                        ev_b_valid,           // generic error event, write-response side
  output logic [5:0]                  ev_b_code,
  output logic [63:0]                 ev_b_addr,
  output logic [3:0]                  ev_b_ctx,
  output logic                        ev_o_valid,           // ordering-contract violation by the endpoint (sequence acknowledge missing)
  output logic [5:0]                  ev_o_code,
  output logic                        dg_valid,             // tracker diagnostics (unexpected / late completion)
  output logic [5:0]                  dg_code,
  output logic [7:0]                  dg_tag,
  output logic                        pe_valid,             // PCIe-side error attributed to a domain
  output logic [3:0]                  pe_dom,
  output logic [5:0]                  pe_code,
  // status / statistics
  output logic                        idle,
  output logic [8:0]                  st_out,
  output logic [8:0]                  st_zombie,
  output logic                        st_flushing,
  output logic                        st_active,
  output logic                        st_rq_mrd,
  output logic                        st_rq_mwr,
  output logic [15:0]                 st_rd_bytes,
  output logic [15:0]                 st_wr_bytes,
  output logic [7:0]                  st_hdr_bytes,
  output logic [15:0]                 st_pay_bytes,
  output logic                        st_lat_valid,
  output logic [15:0]                 st_lat,
  output logic                        st_tag_stall,
  output logic                        st_cred_stall,
  output logic                        st_rq_bp
);
  generate
    if (DMA_DW != 128 && DMA_DW != 256 && DMA_DW != 64) begin : g_chk_dw
      sf_pcie_dma_adapter_DMA_DW_must_be_64_128_256 u_err ();
    end
    if ((WB_DW & (WB_DW - 1)) != 0) begin : g_chk_wb
      sf_pcie_dma_adapter_BURST_LEN_x_BEAT_DW_must_be_a_power_of_two u_err ();
    end
    if (RD_SLOTS < 1 || WR_SLOTS < 1 || BURST_LEN < 1 || BURST_LEN > 256) begin : g_chk_n
      sf_pcie_dma_adapter_slot_or_burst_parameter_out_of_range u_err ();
    end
    if (ORD_W < 4 || ORD_W > 16) begin : g_chk_ord
      sf_pcie_dma_adapter_ORD_W_out_of_range u_err ();
    end
    if (RQ_USER_W != 62 || SEQ_W != 6) begin : g_chk_rq
      sf_pcie_dma_adapter_this_release_supports_only_the_62_bit_RQ_tuser_with_6_bit_sequence_numbers u_err ();
    end
  endgenerate

  localparam logic [2:0] SIZE_LOG2 = 3'(BEAT_LOG2);
  localparam int INFLIGHT_MAX = (1 << (ORD_W - 2));
  localparam int RD_ORD_DEPTH = RD_SLOTS;

  // ===========================================================================================================
  // 0. common
  // ===========================================================================================================
  logic [ORD_W-1:0] issued_q, acked_q;
  assign ord_issued = issued_q;
  assign ord_acked  = acked_q;
  logic              r_busy, r_free;
  logic [8:0]        r_beat;
  logic              wm_full;

  // ===========================================================================================================
  // 1. egress check stage: AR and AW are captured in one-entry registers and checked one per cycle (alternating)
  // ===========================================================================================================
  logic              arp_v, awp_v;
  logic [SLW-1:0]    arp_id;  logic [AW-1:0] arp_addr; logic [7:0] arp_len; logic [2:0] arp_size; logic [1:0] arp_burst;
  logic [3:0]        arp_mt;  logic [DOM_W-1:0] arp_dom;
  logic [WIW-1:0]    awp_id;  logic [AW-1:0] awp_addr; logic [7:0] awp_len; logic [2:0] awp_size; logic [1:0] awp_burst;
  logic [3:0]        awp_mt;  logic [DOM_W-1:0] awp_dom;
  logic              last_was_wr;                          // fairness between AR and AW

  assign ar_ready = !arp_v;
  assign aw_ready = !awp_v;

  logic              rdc_full, wrc_full, ord_full;         // downstream queue space
  wire               pick_wr  = awp_v && (!arp_v || !last_was_wr);
  wire               pick_rd  = arp_v && !pick_wr;
  wire               chk_go   = (pick_wr && !wrc_full) || (pick_rd && !rdc_full && !ord_full);

  // fields of the request being checked
  wire [3:0]         c_dom4   = 4'(pick_wr ? awp_dom : arp_dom);
  assign a_ctx = c_dom4;
  wire [AW-1:0]      c_addr   = pick_wr ? awp_addr  : arp_addr;
  wire [7:0]         c_len    = pick_wr ? awp_len   : arp_len;
  wire [2:0]         c_size   = pick_wr ? awp_size  : arp_size;
  wire [1:0]         c_burst  = pick_wr ? awp_burst : arp_burst;
  wire [3:0]         c_mt     = pick_wr ? awp_mt    : arp_mt;
  wire [31:0]        c_id     = pick_wr ? 32'(awp_id) : 32'(arp_id);
  wire [15:0]        c_bytes  = 16'({8'd0, c_len} + 16'd1) << BEAT_LOG2;

  logic              slot_busy [0:RD_SLOTS-1];

  logic              w_ok;    logic [5:0] w_err; logic [63:0] w_bus;
  sf_pcie_win_check #(.BW(16)) u_win (
    .valid(a_valid), .perm_ok(pick_wr ? a_wr_ok : a_rd_ok), .xlat(a_xlat), .iova_base(a_iova_base), .iova_size(a_iova_size),
    .bus_base(a_bus_base), .addr(64'(c_addr)), .nbytes(c_bytes), .ok(w_ok), .err(w_err), .bus_addr(w_bus));

  logic [5:0]        c_err;
  always_comb begin
    c_err = `SFPB_E_NONE;
    if (flush)                                                              c_err = `SFPB_E_DMA_RECOVERY;
    else if (!cfg_dma_en)                                                   c_err = `SFPB_E_DMA_NO_CTX;        // the host switched DMA off
    else if (c_size != SIZE_LOG2 || c_burst != 2'b01)                       c_err = `SFPB_E_DMA_BADFORMAT;
    else if ({1'b0, c_len} >= 9'(BURST_LEN))                                c_err = `SFPB_E_DMA_BADLEN;
    else if (c_mt != HOST_MTYPE)                                            c_err = `SFPB_E_DMA_BADMTYPE;
    else if (c_addr[BEAT_LOG2-1:0] != '0)                                   c_err = `SFPB_E_DMA_BADFORMAT;
    else if (!pick_wr && (c_id >= 32'(RD_SLOTS)))                           c_err = `SFPB_E_DMA_BADFORMAT;
    else if (pick_wr && (c_id >= 32'(WR_SLOTS)))                            c_err = `SFPB_E_DMA_BADFORMAT;
    else if (!pick_wr && slot_busy[c_id[SLW-1:0]])                          c_err = `SFPB_E_DMA_PROTO;
    else if (!w_ok)                                                         c_err = w_err;
    else if (w_bus[1:0] != 2'b00)                                           c_err = `SFPB_E_DMA_BADFORMAT;
  end

  // command queues
  localparam int RCW = SLW + 64 + 16 + 6 + 4 + 64;           // slot, bus addr, bytes, err, dom, iova
  localparam int WCW = WIW + 64 + 8 + 6 + 4 + 64;            // id, bus addr, beats, err, dom, iova
  logic              rdc_in_v, rdc_out_v, rdc_out_r, wrc_in_v, wrc_out_v, wrc_out_r;
  logic [RCW-1:0]    rdc_out;
  logic [WCW-1:0]    wrc_out;
  logic [$clog2(RD_SLOTS+1)-1:0] rdc_lv, rdc_pk;
  logic [$clog2(WR_SLOTS+1)-1:0] wrc_lv, wrc_pk;
  sf_pcie_fifo #(.WIDTH(RCW), .DEPTH(RD_SLOTS)) u_rdc (
    .clk(clk), .rst_n(rst_n), .flush(clr), .in_valid(rdc_in_v), .in_ready(), .in_data({arp_id, w_bus, c_bytes, c_err, 4'(arp_dom), 64'(arp_addr)}),
    .out_valid(rdc_out_v), .out_ready(rdc_out_r), .out_data(rdc_out), .level(rdc_lv), .peak(rdc_pk));
  sf_pcie_fifo #(.WIDTH(WCW), .DEPTH(WR_SLOTS)) u_wrc (
    .clk(clk), .rst_n(rst_n), .flush(clr), .in_valid(wrc_in_v), .in_ready(), .in_data({awp_id, w_bus, c_len + 8'd1, c_err, 4'(awp_dom), 64'(awp_addr)}),
    .out_valid(wrc_out_v), .out_ready(wrc_out_r), .out_data(wrc_out), .level(wrc_lv), .peak(wrc_pk));
  assign rdc_full = (32'(rdc_lv) == RD_SLOTS);
  assign wrc_full = (32'(wrc_lv) == WR_SLOTS);
  assign rdc_in_v = chk_go && pick_rd && (c_err == `SFPB_E_NONE);          // only accepted requests become TLP work
  assign wrc_in_v = chk_go && pick_wr;

  // R delivery order
  // The in-order R queue.  A normal entry names the slot whose data will be returned; a REFUSED request is a
  // self-contained error entry {id, beat count} that never touches slot state (so a request that reuses an in-flight id
  // cannot corrupt the genuine one).
  localparam int OW = 1 + 9 + SLW;
  logic              ord_in_v, ord_out_v, ord_out_r;
  logic [OW-1:0]     ord_out;
  logic [$clog2(RD_ORD_DEPTH+1)-1:0] ord_lv, ord_pk;
  wire               ord_in_err = (c_err != `SFPB_E_NONE);
  sf_pcie_fifo #(.WIDTH(OW), .DEPTH(RD_ORD_DEPTH)) u_ord (
    .clk(clk), .rst_n(rst_n), .flush(clr), .in_valid(ord_in_v), .in_ready(), .in_data({ord_in_err, 9'({1'b0, c_len} + 9'd1), arp_id}),
    .out_valid(ord_out_v), .out_ready(ord_out_r), .out_data(ord_out), .level(ord_lv), .peak(ord_pk));
  assign ord_full = (32'(ord_lv) == RD_ORD_DEPTH);
  assign ord_in_v = chk_go && pick_rd;
  wire               o_err = ord_out[OW-1];
  wire  [8:0]        o_nb  = ord_out[OW-2 -: 9];
  wire  [SLW-1:0]    o_id  = ord_out[SLW-1:0];

  // violation logging (egress)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      arp_v <= 1'b0; awp_v <= 1'b0; last_was_wr <= 1'b0;
      arp_id <= '0; arp_addr <= '0; arp_len <= '0; arp_size <= '0; arp_burst <= '0; arp_mt <= '0; arp_dom <= '0;
      awp_id <= '0; awp_addr <= '0; awp_len <= '0; awp_size <= '0; awp_burst <= '0; awp_mt <= '0; awp_dom <= '0;
      dmaev_valid <= 1'b0; dmaev_code <= '0; dmaev_dom <= '0; dmaev_write <= 1'b0; dmaev_addr <= '0;
      ev_e_valid <= 1'b0; ev_e_code <= '0; ev_e_addr <= '0; ev_e_ctx <= '0;
    end else begin
      dmaev_valid <= 1'b0; ev_e_valid <= 1'b0;
      if (clr) begin arp_v <= 1'b0; awp_v <= 1'b0; end
      else begin
        if (ar_valid && ar_ready) begin
          arp_v <= 1'b1; arp_id <= ar_id; arp_addr <= ar_addr; arp_len <= ar_len; arp_size <= ar_size; arp_burst <= ar_burst;
          arp_mt <= ar_mtype; arp_dom <= ar_domain;
        end
        if (aw_valid && aw_ready) begin
          awp_v <= 1'b1; awp_id <= aw_id; awp_addr <= aw_addr; awp_len <= aw_len; awp_size <= aw_size; awp_burst <= aw_burst;
          awp_mt <= aw_mtype; awp_dom <= aw_domain;
        end
        if (chk_go) begin
          if (pick_wr) begin awp_v <= 1'b0; last_was_wr <= 1'b1; end else begin arp_v <= 1'b0; last_was_wr <= 1'b0; end
          if (c_err != `SFPB_E_NONE) begin
            dmaev_valid <= 1'b1; dmaev_code <= c_err; dmaev_dom <= c_dom4; dmaev_write <= pick_wr; dmaev_addr <= 64'(c_addr);
            ev_e_valid <= 1'b1; ev_e_code <= c_err; ev_e_addr <= 64'(c_addr); ev_e_ctx <= c_dom4;
          end
        end
      end
    end
  end

  // ===========================================================================================================
  // 2. tag tracker + read slots
  // ===========================================================================================================
  logic              al_valid, al_ready;
  logic [TW-1:0]     al_tag;
  logic [SLW-1:0]    al_slot;
  logic [OFF_W-1:0]  al_off;
  logic [11:0]       al_ndw;
  logic              al_fk;
  logic [6:0]        al_lo;
  logic              bw_valid;
  logic [SLW-1:0]    bw_slot;
  logic [OFF_W-1:0]  bw_dw;
  logic [DATA_W-1:0] bw_data;
  logic [NW-1:0]     bw_ndw;
  logic              tev_valid, tev_ok, tev_fk;
  logic [TW-1:0]     tev_tag;
  logic [SLW-1:0]    tev_slot;
  logic [5:0]        tev_err;

  sf_pcie_tag_tracker #(.DATA_W(DATA_W), .TAGS(TAGS), .SLOT_W(SLW), .OFF_W(OFF_W), .TICK_LOG2(TICK_LOG2)) u_trk (
    .clk(clk), .rst_n(rst_n), .flush(flush), .zombie_clr(zombie_clr), .cfg_timeout_ticks(cfg_timeout_ticks),
    .cfg_req_id(cfg_req_id), .cfg_check_reqid(cfg_check_reqid),
    .al_valid(al_valid), .al_ready(al_ready), .al_tag(al_tag), .al_slot(al_slot), .al_off(al_off), .al_ndw(al_ndw),
    .al_flush_kind(al_fk), .al_addr_lo(al_lo),
    .rcv_valid(rcv_valid), .rcv_ready(rcv_ready), .rcv_sop(rcv_sop), .rcv_eop(rcv_eop), .rcv_data(rcv_data), .rcv_ndw(rcv_ndw),
    .rcv_bad(rcv_bad), .rcv_lower(rcv_lower), .rcv_err(rcv_err), .rcv_bytecnt(rcv_bytecnt), .rcv_dwcnt(rcv_dwcnt),
    .rcv_status(rcv_status), .rcv_poison(rcv_poison), .rcv_reqid(rcv_reqid), .rcv_tag(rcv_tag),
    .bw_valid(bw_valid), .bw_slot(bw_slot), .bw_dw(bw_dw), .bw_data(bw_data), .bw_ndw(bw_ndw),
    .ev_valid(tev_valid), .ev_tag(tev_tag), .ev_slot(tev_slot), .ev_ok(tev_ok), .ev_err(tev_err), .ev_flush_kind(tev_fk),
    .dg_valid(dg_valid), .dg_code(dg_code), .dg_tag(dg_tag),
    .st_out(st_out), .st_zombie(st_zombie), .st_lat_valid(st_lat_valid), .st_lat(st_lat), .st_flushing(st_flushing));

  // slot state
  logic [31:0]       sbuf   [0:RD_SLOTS*SLOT_DW-1];
  logic [7:0]        slot_nbeats [0:RD_SLOTS-1];
  logic [7:0]        slot_pend   [0:RD_SLOTS-1];
  logic              slot_all    [0:RD_SLOTS-1];
  logic              slot_err    [0:RD_SLOTS-1];
  logic [5:0]        slot_code   [0:RD_SLOTS-1];
  logic [3:0]        slot_dom    [0:RD_SLOTS-1];
  logic [63:0]       slot_iova   [0:RD_SLOTS-1];

  // buffer write from the tracker
  always_ff @(posedge clk) begin
    if (bw_valid) begin
      for (int i = 0; i < K; i++) begin
        if (i < 32'(bw_ndw) && (32'(bw_dw) + i) < SLOT_DW && 32'(bw_slot) < RD_SLOTS)
          sbuf[32'(bw_slot) * SLOT_DW + 32'(bw_dw) + i] <= bw_data[i*32 +: 32];
      end
    end
  end

  // ===========================================================================================================
  // 3. read planner
  // ===========================================================================================================
  logic              rp_v;
  logic [SLW-1:0]    rp_slot;
  logic [63:0]       rp_addr;
  logic [15:0]       rp_rem;
  logic [OFF_W-1:0]  rp_off;
  logic              rd_tlp_v, rd_sent;
  wire  [15:0]       rp_to4k = 16'd4096 - {4'd0, rp_addr[11:0]};
  wire  [15:0]       rp_mrrs = {3'd0, cfg_mrrs_dw, 2'b00};
  logic [15:0]       rp_chunk;
  always_comb begin
    rp_chunk = rp_rem;
    if (rp_chunk > rp_mrrs)               rp_chunk = rp_mrrs;
    if (rp_chunk > rp_to4k)               rp_chunk = rp_to4k;
    if (rp_chunk > 16'(RD_MAX_TLP_BYTES)) rp_chunk = 16'(RD_MAX_TLP_BYTES);
  end
  assign rd_tlp_v = rp_v && !flush && (rp_chunk != 16'd0);

  wire [SLW-1:0]  rc_slot = rdc_out[RCW-1 -: SLW];
  wire [63:0]     rc_bus  = rdc_out[RCW-1-SLW -: 64];
  wire [15:0]     rc_byt  = rdc_out[RCW-1-SLW-64 -: 16];
  wire [5:0]      rc_err_unused = rdc_out[RCW-1-SLW-64-16 -: 6];
  wire [3:0]      rc_dom  = rdc_out[RCW-1-SLW-64-16-6 -: 4];
  wire [63:0]     rc_iova = rdc_out[63:0];
  assign rdc_out_r = rdc_out_v && !rp_v;

  // slot bookkeeping is updated from several places; do it in one block
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rp_v <= 1'b0; rp_slot <= '0; rp_addr <= '0; rp_rem <= '0; rp_off <= '0;
      for (int i = 0; i < RD_SLOTS; i++) begin
        slot_busy[i] <= 1'b0; slot_nbeats[i] <= '0; slot_pend[i] <= '0; slot_all[i] <= 1'b0; slot_err[i] <= 1'b0;
        slot_code[i] <= '0; slot_dom[i] <= '0; slot_iova[i] <= '0;
      end
    end else if (clr) begin
      rp_v <= 1'b0;
      for (int i = 0; i < RD_SLOTS; i++) begin
        slot_busy[i] <= 1'b0; slot_pend[i] <= '0; slot_all[i] <= 1'b0; slot_err[i] <= 1'b0;
      end
    end else begin
      // AR accepted by the check stage: claim the slot now (R order is AR order)
      if (rdc_in_v) begin
        slot_busy[arp_id] <= 1'b1; slot_nbeats[arp_id] <= c_len + 8'd1; slot_pend[arp_id] <= '0; slot_all[arp_id] <= 1'b0;
        slot_err[arp_id] <= 1'b0; slot_code[arp_id] <= `SFPB_E_NONE; slot_dom[arp_id] <= 4'(arp_dom); slot_iova[arp_id] <= 64'(arp_addr);
      end
      // load a command (refused requests never get here: they are error entries in the R queue)
      if (rdc_out_v && !rp_v) begin
        rp_v <= 1'b1; rp_slot <= rc_slot; rp_addr <= rc_bus; rp_rem <= rc_byt; rp_off <= '0;
      end
      // abort during recovery
      if (rp_v && flush) begin
        rp_v <= 1'b0; slot_err[rp_slot] <= 1'b1; slot_code[rp_slot] <= `SFPB_E_CPL_RESET; slot_all[rp_slot] <= 1'b1;
      end
      // chunk issued
      if (rd_sent) begin
        rp_addr <= rp_addr + {48'd0, rp_chunk}; rp_rem <= rp_rem - rp_chunk; rp_off <= rp_off + OFF_W'(rp_chunk >> 2);
        if (rp_rem == rp_chunk) begin rp_v <= 1'b0; slot_all[rp_slot] <= 1'b1; end
      end
      // per-slot outstanding count: +1 per TLP issued, -1 per tracker outcome
      for (int i = 0; i < RD_SLOTS; i++) begin
        if ((rd_sent && 32'(rp_slot) == i) && !(tev_valid && !tev_fk && 32'(tev_slot) == i)) slot_pend[i] <= slot_pend[i] + 8'd1;
        else if (!(rd_sent && 32'(rp_slot) == i) && (tev_valid && !tev_fk && 32'(tev_slot) == i)) slot_pend[i] <= slot_pend[i] - 8'd1;
      end
      if (tev_valid && !tev_fk && !tev_ok) begin
        if (!slot_err[tev_slot]) begin slot_err[tev_slot] <= 1'b1; slot_code[tev_slot] <= tev_err; end
      end
      // R drain releases the slot
      if (r_free && !o_err) begin
        slot_busy[o_id] <= 1'b0; slot_all[o_id] <= 1'b0; slot_err[o_id] <= 1'b0;
      end
    end
  end

  // ===========================================================================================================
  // 4. R drain (in AR order)
  // ===========================================================================================================
  wire               head_done = ord_out_v && (o_err || (slot_busy[o_id] && slot_all[o_id] && (slot_pend[o_id] == 8'd0)));
  wire  [8:0]        head_nb   = o_err ? o_nb : {1'b0, slot_nbeats[o_id]};
  wire               head_bad  = o_err || slot_err[o_id];
  always_comb begin
    r_valid = r_busy;
    r_id    = o_id;
    r_resp  = head_bad ? 2'b10 : 2'b00;
    r_last  = (r_beat + 9'd1 == head_nb);
    r_data  = '0;
    if (!head_bad) begin
      for (int i = 0; i < BEAT_DW; i++) r_data[i*32 +: 32] = sbuf[32'(o_id) * SLOT_DW + 32'(r_beat) * BEAT_DW + i];
    end
  end
  assign ord_out_r = r_free;
  assign r_free    = r_busy && r_ready && r_last;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin r_busy <= 1'b0; r_beat <= '0; ev_c_valid <= 1'b0; ev_c_code <= '0; ev_c_addr <= '0; ev_c_ctx <= '0;
                      pe_valid <= 1'b0; pe_dom <= '0; pe_code <= '0; st_rd_bytes <= '0; end
    else begin
      ev_c_valid <= 1'b0; pe_valid <= 1'b0; st_rd_bytes <= '0;
      if (bq_out_r && (b_code_r != `SFPB_E_NONE)) begin pe_valid <= 1'b1; pe_dom <= bh_dom; pe_code <= b_code_r; end
      if (clr) begin r_busy <= 1'b0; r_beat <= '0; end
      else begin
        if (!r_busy && head_done) begin r_busy <= 1'b1; r_beat <= '0; end
        if (r_busy && r_ready) begin
          if (!head_bad) st_rd_bytes <= 16'(BEAT_B);
          if (r_last) begin
            r_busy <= 1'b0; r_beat <= '0;
            if (!o_err && slot_err[o_id]) begin                          // a slot failed on the PCIe side (refused requests were logged at the check stage)
              ev_c_valid <= 1'b1; ev_c_code <= slot_code[o_id]; ev_c_addr <= slot_iova[o_id]; ev_c_ctx <= slot_dom[o_id];
              pe_valid <= 1'b1; pe_dom <= slot_dom[o_id]; pe_code <= slot_code[o_id];
            end
          end else r_beat <= r_beat + 9'd1;
        end
      end
    end
  end

  // ===========================================================================================================
  // 5. write path: W ingest (store-and-forward bursts), write planner
  // ===========================================================================================================
  logic [31:0]       wb      [0:WB_DW-1];
  logic [WBW:0]      wb_used;                       // dwords held (ingested, not yet released)
  logic [WBW-1:0]    wb_wp;                         // write pointer (dword index)
  // per-burst scan while receiving
  logic [WBW-1:0]    ing_base;                      // start of the burst being received
  logic [8:0]        ing_beats;
  logic [11:0]       ing_fv, ing_lv;                // first / last valid byte index inside the burst
  logic              ing_seen, ing_closed, ing_gap;
  // burst metadata FIFO
  localparam int WMW = WBW + 9 + 12 + 12 + 1 + 1;   // base, beats, fv, lv, gap, none
  logic              wm_in_v, wm_out_v, wm_out_r;
  logic [WMW-1:0]    wm_out;
  logic [$clog2(WR_SLOTS+2)-1:0] wm_lv, wm_pk;
  logic [WMW-1:0]    wm_in;

  // strobe analysis of the incoming beat
  logic [BEAT_B-1:0] s_in;
  logic              s_any, s_contig;
  logic [$clog2(BEAT_B):0] s_lo, s_hi;
  always_comb begin
    s_in = w_strb; s_any = |w_strb; s_lo = '0; s_hi = '0;
    for (int i = BEAT_B - 1; i >= 0; i--) if (w_strb[i]) s_lo = ($clog2(BEAT_B)+1)'(i);
    for (int i = 0; i < BEAT_B; i++) if (w_strb[i]) s_hi = ($clog2(BEAT_B)+1)'(i);
    s_contig = 1'b1;
    for (int i = 0; i < BEAT_B; i++) begin
      if (s_any && (i >= 32'(s_lo)) && (i <= 32'(s_hi)) && !w_strb[i]) s_contig = 1'b0;
    end
  end

  wire               wb_room  = (wb_used <= (WBW+1)'(WB_DW - BEAT_DW));
  assign w_ready = wb_room && !wm_full;
  assign wm_full = (32'(wm_lv) == WR_SLOTS + 1);
  wire               w_fire = w_valid && w_ready;

  wire  [11:0]       beat_byte0 = 12'({3'd0, ing_beats} << BEAT_LOG2);
  logic [11:0]       n_fv, n_lv;
  logic              n_seen, n_closed, n_gap;
  always_comb begin
    n_fv = ing_fv; n_lv = ing_lv; n_seen = ing_seen; n_closed = ing_closed; n_gap = ing_gap;
    if (s_any) begin
      if (ing_closed) n_gap = 1'b1;
      if (!s_contig)  n_gap = 1'b1;
      if (ing_seen && (s_lo != '0)) n_gap = 1'b1;
      if (!ing_seen) begin n_fv = beat_byte0 + 12'(s_lo); n_seen = 1'b1; end
      n_lv = beat_byte0 + 12'(s_hi);
      if (32'(s_hi) != (BEAT_B - 1)) n_closed = 1'b1;
    end else if (ing_seen) n_closed = 1'b1;
  end
  assign wm_in_v = w_fire && w_last;
  assign wm_in   = {ing_base, ing_beats + 9'd1, n_fv, n_lv, n_gap, !n_seen};
  sf_pcie_fifo #(.WIDTH(WMW), .DEPTH(WR_SLOTS + 1)) u_wm (
    .clk(clk), .rst_n(rst_n), .flush(clr), .in_valid(wm_in_v), .in_ready(), .in_data(wm_in),
    .out_valid(wm_out_v), .out_ready(wm_out_r), .out_data(wm_out), .level(wm_lv), .peak(wm_pk));

  logic              wb_free_pulse;                 // planner finished a burst: release its dwords
  logic [WBW:0]      wb_free_n;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wb_used <= '0; wb_wp <= '0; ing_base <= '0; ing_beats <= '0; ing_fv <= '0; ing_lv <= '0; ing_seen <= 1'b0; ing_closed <= 1'b0; ing_gap <= 1'b0;
    end else if (clr) begin
      wb_used <= '0; wb_wp <= '0; ing_base <= '0; ing_beats <= '0; ing_seen <= 1'b0; ing_closed <= 1'b0; ing_gap <= 1'b0;
    end else begin
      if (w_fire) begin
        for (int i = 0; i < BEAT_DW; i++) wb[wb_wp + WBW'(i)] <= w_data[i*32 +: 32];
        wb_wp <= wb_wp + WBW'(BEAT_DW);
        ing_fv <= n_fv; ing_lv <= n_lv; ing_seen <= n_seen; ing_closed <= n_closed; ing_gap <= n_gap;
        ing_beats <= ing_beats + 9'd1;
        if (w_last) begin
          ing_base <= wb_wp + WBW'(BEAT_DW); ing_beats <= '0; ing_fv <= '0; ing_lv <= '0; ing_seen <= 1'b0; ing_closed <= 1'b0; ing_gap <= 1'b0;
        end
      end
      wb_used <= wb_used + ((w_fire) ? (WBW+1)'(BEAT_DW) : '0) - (wb_free_pulse ? wb_free_n : '0);
    end
  end
  /* strobes are consumed during ingest; the data path only needs them for the scan above */

  // ---- write planner -------------------------------------------------------------------------------------------
  logic              wp_v;
  logic [WIW-1:0]    wp_id;
  logic [63:0]       wp_addr;                      // bus address of the next TLP's first dword
  logic [3:0]        wp_dom;
  logic [63:0]       wp_iova;
  logic [WBW-1:0]    wp_base;                      // burst base in wb
  logic [11:0]       wp_start;                     // first dword index (relative to the burst) that is sent
  logic [11:0]       wp_total;                     // dwords to send in total
  logic [11:0]       wp_done;                      // dwords already sent
  logic [3:0]        wp_fmask, wp_lmask;
  logic [WBW:0]      wp_free;                      // dwords to release when the burst ends
  logic              wr_tlp_v, wr_sent;
  logic              bq_push; logic [3:0] bq_dom; logic [WIW-1:0] bq_id; logic [5:0] bq_code; logic bq_fl; logic [63:0] bq_addr;

  wire [WIW-1:0]  wc_id   = wrc_out[WCW-1 -: WIW];
  wire [63:0]     wc_bus  = wrc_out[WCW-1-WIW -: 64];
  wire [7:0]      wc_nb   = wrc_out[WCW-1-WIW-64 -: 8];
  wire [5:0]      wc_err  = wrc_out[WCW-1-WIW-64-8 -: 6];
  wire [3:0]      wc_dom  = wrc_out[WCW-1-WIW-64-8-6 -: 4];
  wire [63:0]     wc_iova = wrc_out[63:0];
  wire [WBW-1:0]  wm_base = wm_out[WMW-1 -: WBW];
  wire [8:0]      wm_nb   = wm_out[WMW-1-WBW -: 9];
  wire [11:0]     wm_fv   = wm_out[WMW-1-WBW-9 -: 12];
  wire [11:0]     wm_lv_b = wm_out[WMW-1-WBW-9-12 -: 12];
  wire            wm_gap  = wm_out[1];
  wire            wm_none = wm_out[0];

  wire            wp_load  = !wp_v && wrc_out_v && wm_out_v;
  assign wrc_out_r = wp_load;
  assign wm_out_r  = wp_load;

  // plan derived from the loaded metadata (combinational, used at load time)
  wire [11:0]     pl_sdw   = {2'b00, wm_fv[11:2]};
  wire [11:0]     pl_edw   = {2'b00, wm_lv_b[11:2]};
  wire [11:0]     pl_total = pl_edw - pl_sdw + 12'd1;
  wire [3:0]      pl_fm    = 4'hF << wm_fv[1:0];
  wire [3:0]      pl_lm    = 4'hF >> (2'd3 - wm_lv_b[1:0]);

  // chunk of the current TLP
  wire [11:0]     wp_rem   = wp_total - wp_done;
  wire [12:0]     wp_to4k  = 13'd1024 - {3'd0, wp_addr[11:2]};
  logic [11:0]    wp_chunk;
  always_comb begin
    wp_chunk = wp_rem;
    if (wp_chunk > {1'b0, cfg_mps_dw}) wp_chunk = {1'b0, cfg_mps_dw};
    if ({1'b0, wp_chunk} > wp_to4k)  wp_chunk = wp_to4k[11:0];
  end
  wire            wp_is_first = (wp_done == 12'd0);
  wire            wp_is_last  = (wp_done + wp_chunk == wp_total);
  logic [3:0]     wp_fbe, wp_lbe;
  always_comb begin
    if (wp_chunk == 12'd1) begin
      wp_lbe = 4'b0000;
      wp_fbe = (wp_is_first && wp_is_last) ? (wp_fmask & wp_lmask) : wp_is_first ? wp_fmask : wp_is_last ? wp_lmask : 4'hF;
    end else begin
      wp_fbe = wp_is_first ? wp_fmask : 4'hF;
      wp_lbe = wp_is_last  ? wp_lmask : 4'hF;
    end
  end
  assign wr_tlp_v = wp_v && !flush && (wp_chunk != 12'd0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp_v <= 1'b0; wp_id <= '0; wp_addr <= '0; wp_dom <= '0; wp_iova <= '0; wp_base <= '0; wp_start <= '0; wp_total <= '0;
      wp_done <= '0; wp_fmask <= '0; wp_lmask <= '0; wp_free <= '0;
      bq_push <= 1'b0; bq_id <= '0; bq_dom <= '0; bq_code <= '0; bq_fl <= 1'b0; bq_addr <= '0; wb_free_pulse <= 1'b0; wb_free_n <= '0;
      st_wr_bytes <= '0;
    end else begin
      bq_push <= 1'b0; wb_free_pulse <= 1'b0; st_wr_bytes <= '0;
      if (clr) wp_v <= 1'b0;
      else begin
        if (wp_load) begin
          wp_id <= wc_id; wp_dom <= wc_dom; wp_iova <= wc_iova; wp_base <= wm_base; wp_free <= (WBW+1)'(wm_nb) * (WBW+1)'(BEAT_DW);
          wp_addr <= wc_bus + {52'd0, pl_sdw[9:0], 2'b00};                  // address of the first dword that is sent
          wp_start <= pl_sdw; wp_total <= pl_total; wp_done <= '0; wp_fmask <= pl_fm; wp_lmask <= pl_lm;
          if (flush || wc_err != `SFPB_E_NONE || {1'b0, wm_nb[7:0]} != {1'b0, wc_nb} || wm_gap) begin
            // refuse: nothing goes to PCIe; answer B = SLVERR, release the data
            bq_push <= 1'b1; bq_id <= wc_id; bq_dom <= wc_dom; bq_fl <= 1'b0; bq_addr <= wc_bus;
            bq_code <= flush ? `SFPB_E_DMA_RECOVERY : (wc_err != `SFPB_E_NONE) ? wc_err : wm_gap ? `SFPB_E_DMA_STRB : `SFPB_E_DMA_PROTO;
            wb_free_pulse <= 1'b1; wb_free_n <= (WBW+1)'(wm_nb) * (WBW+1)'(BEAT_DW);
          end else if (wm_none) begin
            bq_push <= 1'b1; bq_id <= wc_id; bq_dom <= wc_dom; bq_fl <= 1'b0; bq_code <= `SFPB_E_NONE; bq_addr <= wc_bus;
            wb_free_pulse <= 1'b1; wb_free_n <= (WBW+1)'(wm_nb) * (WBW+1)'(BEAT_DW);
          end else begin
            wp_v <= 1'b1;
          end
        end
        if (wp_v && flush) begin
          wp_v <= 1'b0; bq_push <= 1'b1; bq_id <= wp_id; bq_dom <= wp_dom; bq_fl <= 1'b0; bq_code <= `SFPB_E_CPL_RESET; bq_addr <= wp_addr;
          wb_free_pulse <= 1'b1; wb_free_n <= wp_free;
        end
        if (wr_sent) begin
          st_wr_bytes <= 16'({wp_chunk, 2'b00});
          wp_done <= wp_done + wp_chunk; wp_addr <= wp_addr + {50'd0, wp_chunk, 2'b00};
          if (wp_is_last) begin
            wp_v <= 1'b0; bq_push <= 1'b1; bq_id <= wp_id; bq_dom <= wp_dom; bq_code <= `SFPB_E_NONE; bq_fl <= cfg_wr_flush_en;
            bq_addr <= wp_addr;                                              // flush read targets the last chunk's address
            wb_free_pulse <= 1'b1; wb_free_n <= wp_free;
          end
        end
      end
    end
  end

  // ===========================================================================================================
  // 6. RQ sequencer: one TLP at a time into the packer
  // ===========================================================================================================
  logic              pk_valid, pk_ready, pk_sop, pk_eop;
  logic [DATA_W-1:0] pk_data;
  logic [NW-1:0]     pk_ndw;
  logic [127:0]      pk_hdr;
  logic [RQ_USER_W-1:0] pk_user;
  logic              pk_idle;
  sf_pcie_axis_pack #(.DATA_W(DATA_W), .HDR_DW(4), .USER_W(RQ_USER_W)) u_pk (
    .clk(clk), .rst_n(rst_n), .flush(clr),
    .i_valid(pk_valid), .i_ready(pk_ready), .i_sop(pk_sop), .i_eop(pk_eop), .i_data(pk_data), .i_ndw(pk_ndw),
    .i_hdr(pk_hdr), .i_user(pk_user),
    .m_tdata(m_rq_tdata), .m_tkeep(m_rq_tkeep), .m_tlast(m_rq_tlast), .m_tuser(m_rq_tuser), .m_tvalid(m_rq_tvalid),
    .m_tready(m_rq_tready), .idle(pk_idle));

  // flush-read (strict write acknowledge) request, driven by the B engine
  logic              fl_tlp_v, fl_sent;
  logic [63:0]       fl_addr;

  localparam logic [1:0] Q_IDLE = 2'd0, Q_RD = 2'd1, Q_WR = 2'd2, Q_FL = 2'd3;
  logic [1:0]        sq_st;
  logic [1:0]        sq_rr;                    // round-robin start
  logic [11:0]       sq_beat;                  // payload beats sent in the current write TLP
  wire  [ORD_W-1:0]  inflight = issued_q - acked_q;
  wire               inflight_ok = (inflight < ORD_W'(INFLIGHT_MAX));

  // header builder -----------------------------------------------------------------------------------------------
  logic [127:0] hdr_rd, hdr_wr, hdr_fl;
  logic [SEQ_W-1:0] seq_n;
  assign seq_n = SEQ_W'(issued_q);
  /* verilator lint_off UNUSEDSIGNAL */
  function automatic logic [127:0] mk_hdr(input logic [63:0] a, input logic [10:0] ndw, input logic [3:0] typ, input logic [7:0] tag);
    mk_hdr = 128'd0;
    mk_hdr[1:0] = 2'b00; mk_hdr[63:2] = a[63:2]; mk_hdr[74:64] = ndw; mk_hdr[78:75] = typ; mk_hdr[79] = 1'b0;
    mk_hdr[95:80] = 16'd0; mk_hdr[103:96] = tag; mk_hdr[119:104] = 16'd0; mk_hdr[120] = 1'b0;
    mk_hdr[123:121] = 3'd0; mk_hdr[126:124] = 3'd0; mk_hdr[127] = 1'b0;                 // TC0, no RO / NS / IDO
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */
  function automatic logic [RQ_USER_W-1:0] mk_user(input logic [3:0] fbe, input logic [3:0] lbe, input logic [SEQ_W-1:0] seq);
    mk_user = '0;
    mk_user[3:0] = fbe; mk_user[7:4] = lbe;
    mk_user[27:24] = seq[3:0];
    mk_user[61:60] = seq[5:4];
  endfunction

  wire [63:0] tag_ext = {56'd0, 8'(al_tag)};
  assign hdr_rd = mk_hdr(rp_addr, 11'(rp_chunk >> 2), `SFPB_RT_MEM_RD, 8'(al_tag));
  assign hdr_fl = mk_hdr(fl_addr, 11'd1, `SFPB_RT_MEM_RD, 8'(al_tag));
  assign hdr_wr = mk_hdr(wp_addr, 11'(wp_chunk), `SFPB_RT_MEM_WR, 8'd0);

  // payload beat of the current write TLP: dwords [sq_beat*K, ...) of the chunk
  logic [DATA_W-1:0] wr_pay;
  logic [NW-1:0]     wr_pay_n;
  wire  [11:0]       wr_left = wp_chunk - sq_beat * 12'(K);
  always_comb begin
    wr_pay = '0;
    wr_pay_n = (wr_left >= 12'(K)) ? NW'(K) : NW'(wr_left);
    for (int i = 0; i < K; i++) begin
      if (i < 32'(wr_pay_n))
        wr_pay[i*32 +: 32] = wb[wp_base + WBW'(wp_start) + WBW'(wp_done) + WBW'(sq_beat * 12'(K)) + WBW'(i)];
    end
  end

  logic [1:0] pick;
  logic       want_rd, want_wr, want_fl, ok_rd, ok_wr, ok_fl;
  always_comb begin
    want_rd = rd_tlp_v; want_wr = wr_tlp_v; want_fl = fl_tlp_v;
    ok_rd = want_rd && rq_np_ok && al_ready && inflight_ok;
    ok_fl = want_fl && rq_np_ok && al_ready && inflight_ok;
    ok_wr = want_wr && rq_p_ok && inflight_ok;
    pick = Q_IDLE;
    // round robin over {rd, wr, fl}
    case (sq_rr)
      2'd0: pick = ok_rd ? Q_RD : ok_wr ? Q_WR : ok_fl ? Q_FL : Q_IDLE;
      2'd1: pick = ok_wr ? Q_WR : ok_fl ? Q_FL : ok_rd ? Q_RD : Q_IDLE;
      default: pick = ok_fl ? Q_FL : ok_rd ? Q_RD : ok_wr ? Q_WR : Q_IDLE;
    endcase
  end
  assign st_tag_stall  = (want_rd || want_fl) && !al_ready;
  assign st_cred_stall = ((want_rd || want_fl) && !rq_np_ok) || (want_wr && !rq_p_ok) || ((want_rd || want_wr || want_fl) && !inflight_ok);

  always_comb begin
    pk_valid = 1'b0; pk_sop = 1'b0; pk_eop = 1'b0; pk_data = '0; pk_ndw = '0; pk_hdr = '0; pk_user = '0;
    al_valid = 1'b0; al_slot = rp_slot; al_off = rp_off; al_ndw = 12'(rp_chunk >> 2); al_fk = 1'b0; al_lo = rp_addr[6:0];
    rd_sent = 1'b0; wr_sent = 1'b0; fl_sent = 1'b0;
    case (sq_st)
      Q_IDLE: begin
        // the header of a read / flush goes out in the cycle of the pick (single-beat TLP); a write starts with its first beat
        if (pick == Q_RD && pk_ready) begin
          pk_valid = 1'b1; pk_sop = 1'b1; pk_eop = 1'b1; pk_hdr = hdr_rd; pk_user = mk_user(4'hF, (rp_chunk == 16'd4) ? 4'h0 : 4'hF, seq_n);
          al_valid = 1'b1; rd_sent = 1'b1;
        end else if (pick == Q_FL && pk_ready) begin
          pk_valid = 1'b1; pk_sop = 1'b1; pk_eop = 1'b1; pk_hdr = hdr_fl; pk_user = mk_user(4'h0, 4'h0, seq_n);
          al_valid = 1'b1; al_slot = '0; al_off = '0; al_ndw = 12'd1; al_fk = 1'b1; al_lo = fl_addr[6:0]; fl_sent = 1'b1;
        end else if (pick == Q_WR && pk_ready) begin
          pk_valid = 1'b1; pk_sop = 1'b1; pk_hdr = hdr_wr; pk_user = mk_user(wp_fbe, wp_lbe, seq_n);
          pk_eop = (wp_chunk <= 12'(K)); pk_ndw = (wp_chunk >= 12'(K)) ? NW'(K) : NW'(wp_chunk);
          for (int i = 0; i < K; i++)
            if (i < 32'(pk_ndw)) pk_data[i*32 +: 32] = wb[wp_base + WBW'(wp_start) + WBW'(wp_done) + WBW'(i)];
          wr_sent = pk_eop;
        end
      end
      Q_WR: begin
        pk_valid = 1'b1; pk_sop = 1'b0; pk_hdr = hdr_wr; pk_user = mk_user(wp_fbe, wp_lbe, seq_n);
        pk_data = wr_pay; pk_ndw = wr_pay_n; pk_eop = (wr_left <= 12'(K));
        wr_sent = pk_valid && pk_ready && pk_eop;
      end
      default: ;
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sq_st <= Q_IDLE; sq_rr <= 2'd0; sq_beat <= '0; issued_q <= '0;                       // (acked_q has its own always_ff below: ONE driver per register)
      st_rq_mrd <= 1'b0; st_rq_mwr <= 1'b0; st_hdr_bytes <= '0; st_pay_bytes <= '0; st_rq_bp <= 1'b0;
    end else begin
      st_rq_mrd <= 1'b0; st_rq_mwr <= 1'b0; st_hdr_bytes <= '0; st_pay_bytes <= '0;
      st_rq_bp <= m_rq_tvalid && !m_rq_tready;
      if (clr) begin sq_st <= Q_IDLE; sq_beat <= '0; end
      else case (sq_st)
        Q_IDLE: begin
          if (pk_valid && pk_ready) begin
            issued_q <= issued_q + 1'b1; st_hdr_bytes <= 8'd16;
            if (pick == Q_RD || pick == Q_FL) begin st_rq_mrd <= 1'b1; sq_rr <= 2'd1; end
            else begin
              st_rq_mwr <= 1'b1; sq_rr <= 2'd2; st_pay_bytes <= 16'({pk_ndw, 2'b00});
              if (!pk_eop) begin sq_st <= Q_WR; sq_beat <= 12'd1; end
            end
          end
        end
        Q_WR: begin
          if (pk_valid && pk_ready) begin
            st_pay_bytes <= 16'({pk_ndw, 2'b00});
            if (pk_eop) begin sq_st <= Q_IDLE; sq_beat <= '0; end else sq_beat <= sq_beat + 12'd1;
          end
        end
        default: sq_st <= Q_IDLE;
      endcase
    end
  end

  // acknowledge counting + watchdog
  logic [ORD_W-1:0] stall_cnt;
  logic [31:0]      ack_wait;
  wire  [1:0]       ack_n = (RQ_ACK_ON_ACCEPT != 0) ? {1'b0, (m_rq_tvalid && m_rq_tready && m_rq_tlast)} : ({1'b0, rq_ack0} + {1'b0, rq_ack1});
  logic             ord_fault;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin ack_wait <= '0; ord_fault <= 1'b0; stall_cnt <= '0; end
    else begin
      ord_fault <= 1'b0;
      if (issued_q == acked_q || ack_n != 2'd0) ack_wait <= '0;
      else if (ack_wait < 32'(ORD_TIMEOUT)) ack_wait <= ack_wait + 1'b1;
      else begin ord_fault <= 1'b1; ack_wait <= '0; end
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) acked_q <= '0;
    else if (ord_fault || clr) acked_q <= issued_q;                           // resynchronise: the endpoint's acknowledge contract was violated
    else acked_q <= acked_q + ORD_W'(ack_n);
  end
  // an acknowledge fault is reported on the egress event port together with the other protection events
  // (merged below with the strict-write flush events)

  // ===========================================================================================================
  // 7. B engine: write acknowledge (optionally behind a zero-length flush read)
  // ===========================================================================================================
  localparam int BQW = 4 + WIW + 6 + 1 + 64;
  logic              bq_out_v, bq_out_r;
  logic [BQW-1:0]    bq_out;
  logic [$clog2(WR_SLOTS+3)-1:0] bq_lv, bq_pk;
  sf_pcie_fifo #(.WIDTH(BQW), .DEPTH(WR_SLOTS + 2)) u_bq (
    .clk(clk), .rst_n(rst_n), .flush(clr), .in_valid(bq_push), .in_ready(), .in_data({bq_dom, bq_id, bq_code, bq_fl, bq_addr}),
    .out_valid(bq_out_v), .out_ready(bq_out_r), .out_data(bq_out), .level(bq_lv), .peak(bq_pk));
  wire [3:0]      bh_dom  = bq_out[BQW-1 -: 4];
  wire [WIW-1:0]  bh_id   = bq_out[BQW-5 -: WIW];
  wire [5:0]      bh_code = bq_out[BQW-5-WIW -: 6];
  wire            bh_fl   = bq_out[64];
  wire [63:0]     bh_addr = bq_out[63:0];

  localparam logic [1:0] B_IDLE = 2'd0, B_REQ = 2'd1, B_WAIT = 2'd2, B_OUT = 2'd3;
  logic [1:0]        b_st;
  logic [5:0]        b_code_r;
  assign fl_tlp_v = (b_st == B_REQ) && !flush;
  assign fl_addr  = bh_addr;
  assign bq_out_r = (b_st == B_OUT) && b_valid && b_ready;
  assign b_id     = bh_id;
  assign b_resp   = (b_code_r != `SFPB_E_NONE) ? 2'b10 : 2'b00;
  assign b_valid  = (b_st == B_OUT);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin b_st <= B_IDLE; b_code_r <= '0; end
    else if (clr) b_st <= B_IDLE;
    else case (b_st)
      B_IDLE: if (bq_out_v) begin
        b_code_r <= bh_code;
        if (bh_fl && bh_code == `SFPB_E_NONE) b_st <= flush ? B_OUT : B_REQ; else b_st <= B_OUT;
        if (bh_fl && bh_code == `SFPB_E_NONE && flush) b_code_r <= `SFPB_E_CPL_RESET;
      end
      B_REQ:  begin
        if (fl_sent) b_st <= B_WAIT;
        else if (flush) begin b_st <= B_OUT; b_code_r <= `SFPB_E_CPL_RESET; end
      end
      B_WAIT: if (tev_valid && tev_fk) begin b_st <= B_OUT; b_code_r <= tev_ok ? `SFPB_E_NONE : tev_err; end
      B_OUT:  if (b_ready) b_st <= B_IDLE;
      default: b_st <= B_IDLE;
    endcase
  end

  // write-response errors become events (egress violations were already logged by the check stage)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin ev_b_valid <= 1'b0; ev_b_code <= '0; ev_b_ctx <= '0; ev_b_addr <= '0; ev_o_valid <= 1'b0; ev_o_code <= '0; end
    else begin
      ev_b_valid <= bq_out_r && (b_code_r != `SFPB_E_NONE) && (b_code_r != `SFPB_E_DMA_RECOVERY) &&
                    (b_code_r != `SFPB_E_DMA_BADFORMAT) && (b_code_r != `SFPB_E_DMA_BADLEN) && (b_code_r != `SFPB_E_DMA_BADMTYPE) &&
                    (b_code_r != `SFPB_E_DMA_NO_CTX) && (b_code_r != `SFPB_E_DMA_WINDOW) && (b_code_r != `SFPB_E_DMA_PERM);
      ev_b_code <= b_code_r; ev_b_addr <= bh_addr; ev_b_ctx <= bh_dom;
      ev_o_valid <= ord_fault; ev_o_code <= `SFPB_E_DMA_ORDER;
    end
  end

  // ===========================================================================================================
  // 8. idle
  // ===========================================================================================================
  logic any_slot;
  always_comb begin
    any_slot = 1'b0;
    for (int i = 0; i < RD_SLOTS; i++) if (slot_busy[i]) any_slot = 1'b1;
  end
  assign idle = !any_slot && !arp_v && !awp_v && !rp_v && !wp_v && !rdc_out_v && !wrc_out_v && !wm_out_v && !bq_out_v &&
                (b_st == B_IDLE) && (sq_st == Q_IDLE) && pk_idle && (st_out == 9'd0) && (wb_used == '0) && !r_busy && !ord_out_v;
  assign st_active = !idle;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = &{1'b0, rc_err_unused, rc_dom, rc_iova, wp_iova, tev_tag, bq_lv, wm_nb[8], wp_start[11:7], tag_ext, stall_cnt, hdr_wr[0], s_in, rdc_pk, wrc_pk, ord_pk, wm_pk, bq_pk, bh_id, wc_iova, st_lat, 1'b0};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
