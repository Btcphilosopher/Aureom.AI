// =============================================================================
// sf_pcie_axis_unpack -- RX framing for the endpoint's AXI4-Stream transaction interfaces (CQ and RC).
//
// Wire format (AMD UltraScale+ style, DWORD-aligned mode, no straddling, DATA_W = 128 or 256):
//   a packet is  HDR_DW header dwords  followed by payload dwords, packed back to back into K = DATA_W/32
//   dword lanes per beat; tkeep is one bit per dword; tlast marks the last beat.
//   (CQ / RQ descriptors are 4 dwords, CC / RC descriptors are 3 dwords.)
//
// Output: a "packet beat" stream, easier for the logic behind it:
//   * the header is presented once, on the first beat (o_sop);
//   * payload dwords are re-aligned so that payload dword 0 is lane 0 of the first output beat;
//   * every output beat except the last carries exactly K dwords; the last carries o_ndw in 0..K
//     (0 only for header-only packets, or for a malformed stream that ends without payload).
// Framing violations (hole in tkeep, short non-final beat, header shorter than HDR_DW) set o_bad on the last beat.
// The module never drops or invents payload: what it cannot explain it flags.
// =============================================================================
`default_nettype none
module sf_pcie_axis_unpack #(
  parameter int DATA_W = 256,               // 128 | 256
  parameter int HDR_DW = 4,                 // 4 (CQ / RQ) | 3 (CC / RC)
  parameter int USER_W = 1,
  localparam int K     = DATA_W / 32,
  localparam int NW    = $clog2(K + 1)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                flush,        // synchronous clear of all partial state
  input  wire logic [DATA_W-1:0]   s_tdata,
  input  wire logic [K-1:0]        s_tkeep,
  input  wire logic                s_tlast,
  input  wire logic [USER_W-1:0]   s_tuser,
  input  wire logic                s_tbad,       // per-beat error flag from the endpoint (e.g. tuser.discontinue)
  input  wire logic                s_tvalid,
  output logic                     s_tready,
  output logic                     o_valid,
  input  wire logic                o_ready,
  output logic                     o_sop,
  output logic                     o_eop,
  output logic [DATA_W-1:0]        o_data,
  output logic [NW-1:0]            o_ndw,
  output logic [HDR_DW*32-1:0]     o_hdr,        // valid with o_sop
  output logic [USER_W-1:0]        o_user,       // valid with o_sop (sampled on the packet's first input beat)
  output logic                     o_bad         // valid with o_eop
);
  generate
    if (DATA_W != 128 && DATA_W != 256) begin : g_chk_w
      sf_pcie_axis_unpack_DATA_W_must_be_128_or_256 u_err ();
    end
    if (HDR_DW != 3 && HDR_DW != 4) begin : g_chk_h
      sf_pcie_axis_unpack_HDR_DW_must_be_3_or_4 u_err ();
    end
  endgenerate

  localparam int CATW = 2 * DATA_W;

  // ---- packet state --------------------------------------------------------------------------------------------
  logic                  in_pkt;           // at least one beat of the current packet accepted
  logic                  sop_pend;         // next emitted beat is the packet's first
  logic [DATA_W-1:0]     carry;            // payload dwords waiting for a full beat (lane 0 upward)
  logic [NW-1:0]         cn;               // number of valid dwords in carry
  logic [HDR_DW*32-1:0]  hdr_r;
  logic [USER_W-1:0]     user_r;
  logic                  bad_acc;
  // tail beat (second output of a final input beat)
  logic                  tail_valid;
  logic [DATA_W-1:0]     tail_data;
  logic [NW-1:0]         tail_n;
  logic                  tail_bad;

  // ---- combinational analysis of the input beat ----------------------------------------------------------------
  logic [NW-1:0]         v;                // contiguous dwords from lane 0
  logic                  keep_ok;
  logic [NW-1:0]         pv;               // payload dwords carried by this input beat
  logic [DATA_W-1:0]     pl;               // those payload dwords, lane 0 upward
  logic [CATW-1:0]       cat;
  logic [NW:0]           tot;              // carry + payload dwords (can reach 2K-1)
  logic                  beat_bad;
  logic                  is_first;

  always_comb begin
    v = '0;
    for (int i = 0; i < K; i++) begin
      if (s_tkeep[i] && (v == NW'(i))) v = NW'(i + 1);
    end
    keep_ok  = (s_tkeep == K'((1 << v) - 1));
    is_first = !in_pkt;
    if (is_first) pv = (v > NW'(HDR_DW)) ? (v - NW'(HDR_DW)) : '0;
    else          pv = v;
    pl = '0;
    for (int i = 0; i < K; i++) begin
      if (i < 32'(pv)) begin
        if (is_first) begin
          if (i + HDR_DW < K) pl[i*32 +: 32] = s_tdata[(i + HDR_DW)*32 +: 32];
        end else begin
          pl[i*32 +: 32] = s_tdata[i*32 +: 32];
        end
      end
    end
    cat = {{DATA_W{1'b0}}, pl} << ({{(32-NW){1'b0}}, cn} * 32);
    cat = cat | {{DATA_W{1'b0}}, carry};
    tot = {1'b0, cn} + {1'b0, pv};
    beat_bad = s_tbad || !keep_ok || (is_first && (v < NW'(HDR_DW))) || (!s_tlast && (v != NW'(K)));
  end

  // ---- handshakes ----------------------------------------------------------------------------------------------
  wire out_free = !o_valid || o_ready;
  assign s_tready = !tail_valid && out_free && !flush;
  wire in_fire = s_tvalid && s_tready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      in_pkt <= 1'b0; sop_pend <= 1'b1; carry <= '0; cn <= '0; hdr_r <= '0; user_r <= '0; bad_acc <= 1'b0;
      tail_valid <= 1'b0; tail_data <= '0; tail_n <= '0; tail_bad <= 1'b0;
      o_valid <= 1'b0; o_sop <= 1'b0; o_eop <= 1'b0; o_data <= '0; o_ndw <= '0; o_hdr <= '0; o_user <= '0; o_bad <= 1'b0;
    end else if (flush) begin
      in_pkt <= 1'b0; sop_pend <= 1'b1; carry <= '0; cn <= '0; bad_acc <= 1'b0;
      tail_valid <= 1'b0; o_valid <= 1'b0;
    end else begin
      if (o_valid && o_ready) o_valid <= 1'b0;

      if (tail_valid && out_free) begin               // second beat of a final input beat
        o_valid <= 1'b1; o_sop <= 1'b0; o_eop <= 1'b1; o_data <= tail_data; o_ndw <= tail_n; o_bad <= tail_bad;
        o_hdr <= hdr_r; o_user <= user_r;
        tail_valid <= 1'b0;
      end

      if (in_fire) begin
        if (is_first) begin hdr_r <= s_tdata[HDR_DW*32-1:0]; user_r <= s_tuser; end
        if (s_tlast) begin
          in_pkt <= 1'b0; carry <= '0; cn <= '0; bad_acc <= 1'b0;
          // final output: one beat when everything fits, otherwise a full beat now and the rest as the tail
          o_valid <= 1'b1;
          o_sop   <= sop_pend;
          o_hdr   <= is_first ? s_tdata[HDR_DW*32-1:0] : hdr_r;
          o_user  <= is_first ? s_tuser : user_r;
          o_data  <= cat[DATA_W-1:0];
          if (tot <= (NW+1)'(K)) begin
            o_eop <= 1'b1; o_ndw <= tot[NW-1:0];
            o_bad <= bad_acc | beat_bad;
            sop_pend <= 1'b1;
          end else begin
            o_eop <= 1'b0; o_ndw <= NW'(K);
            o_bad <= 1'b0;
            tail_valid <= 1'b1; tail_data <= cat[CATW-1:DATA_W]; tail_n <= NW'(tot - (NW+1)'(K));
            tail_bad <= bad_acc | beat_bad;
            sop_pend <= 1'b1;                         // the tail is not a start of packet; next packet restarts
          end
        end else begin
          in_pkt <= 1'b1; bad_acc <= bad_acc | beat_bad;
          if (tot >= (NW+1)'(K)) begin                // a full output beat is ready
            o_valid <= 1'b1; o_sop <= sop_pend; o_eop <= 1'b0; o_data <= cat[DATA_W-1:0]; o_ndw <= NW'(K); o_bad <= 1'b0;
            o_hdr <= is_first ? s_tdata[HDR_DW*32-1:0] : hdr_r;
            o_user <= is_first ? s_tuser : user_r;
            sop_pend <= 1'b0;
            carry <= cat[CATW-1:DATA_W]; cn <= NW'(tot - (NW+1)'(K));
          end else begin                              // not enough yet (first beat of a packet only)
            carry <= cat[DATA_W-1:0]; cn <= tot[NW-1:0];
          end
        end
      end
    end
  end
endmodule
`default_nettype wire
