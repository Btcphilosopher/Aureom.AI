// =============================================================================
// sf_pcie_fifo -- synchronous first-word-fall-through ready/valid FIFO (register array, asynchronous read).
// DEPTH >= 1 (any value).  `flush` is a synchronous clear (recovery); push while flushing is dropped.
// `level` is the live occupancy; `peak` is the high-water mark since reset (diagnostic, feeds performance counters).
// =============================================================================
`default_nettype none
module sf_pcie_fifo #(
  parameter int WIDTH = 32,
  parameter int DEPTH = 4,
  localparam int CW   = $clog2(DEPTH + 1),
  localparam int PW   = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             flush,
  input  wire logic             in_valid,
  output logic                  in_ready,
  input  wire logic [WIDTH-1:0] in_data,
  output logic                  out_valid,
  input  wire logic             out_ready,
  output logic [WIDTH-1:0]      out_data,
  output logic [CW-1:0]         level,
  output logic [CW-1:0]         peak
);
  generate
    if (DEPTH < 1) begin : g_chk
      sf_pcie_fifo_DEPTH_must_be_ge_1 u_err ();
    end
  endgenerate

  logic [WIDTH-1:0] mem [0:DEPTH-1];
  logic [PW-1:0]    wp, rp;
  logic [CW-1:0]    cnt;

  assign in_ready  = (cnt != CW'(DEPTH));
  assign out_valid = (cnt != '0);
  assign out_data  = mem[rp];
  assign level     = cnt;

  wire do_push = in_valid && in_ready && !flush;
  wire do_pop  = out_valid && out_ready;

  function automatic logic [PW-1:0] inc(input logic [PW-1:0] p);
    if (DEPTH == 1)                   inc = '0;
    else if (p == PW'(DEPTH - 1))     inc = '0;
    else                              inc = p + 1'b1;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0; cnt <= '0; peak <= '0;
    end else if (flush) begin
      wp <= '0; rp <= '0; cnt <= '0;
    end else begin
      if (do_push) begin mem[wp] <= in_data; wp <= inc(wp); end
      if (do_pop)  rp <= inc(rp);
      cnt <= cnt + CW'(do_push) - CW'(do_pop);
      if (do_push && !do_pop && (cnt + 1'b1 > peak)) peak <= cnt + 1'b1;
    end
  end
endmodule
`default_nettype wire
