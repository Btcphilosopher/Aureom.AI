// =============================================================================
// sf_pcie_perf -- bridge performance counters (read through the CSR window; see docs/10_PERFORMANCE.md).
// All counters are 64-bit, count only while `en`, and are cleared together by `clr`.  Latency statistics are
// kept as sum / count / min / max so that averages are computed by software without losing information.
// =============================================================================
`default_nettype none
`include "sf_pcie_regs.svh"
module sf_pcie_perf (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        en,
  input  wire logic        clr,
  // event pulses
  input  wire logic        e_cq_tlp, e_cq_mrd, e_cq_mwr, e_cq_bad, e_cc_tlp, e_rq_mrd, e_rq_mwr, e_rc_tlp,
  input  wire logic        e_rdlat_valid, input wire logic [15:0] e_rdlat,
  input  wire logic        e_wrlat_valid, input wire logic [15:0] e_wrlat,
  input  wire logic        e_cpllat_valid, input wire logic [15:0] e_cpllat,
  input  wire logic [15:0] e_dma_rd_bytes,
  input  wire logic [15:0] e_dma_wr_bytes,
  input  wire logic        l_dma_active,
  input  wire logic [8:0]  l_outstanding,
  input  wire logic [3:0]  l_hdrq,
  input  wire logic [15:0] l_payq,
  input  wire logic        l_bp_cq, l_bp_cc, l_bp_rq, l_bp_sfb,
  input  wire logic [7:0]  e_hdr_bytes,
  input  wire logic [15:0] e_pay_bytes,
  input  wire logic [3:0]  e_err_events,
  input  wire logic        l_ord_stall, e_cpl_unexpected, l_tag_stall, l_cred_stall,
  // read port
  input  wire logic [5:0]  sel,
  output logic [63:0]      data
);
  logic [63:0] c [0:`SFPB_PC_N-1];

  // asynchronous reset (rst_n) and SYNCHRONOUS clear (clr) are separate branches: folding clr into the asynchronous condition
  // would make it an asynchronous clear driven by logic, which no synthesis flow accepts (Yosys: "multiple edge sensitive events")
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < `SFPB_PC_N; i++) c[i] <= 64'd0;
      c[`SFPB_PC_MMIO_RD_LAT_MIN] <= 64'h0000_0000_FFFF_FFFF;
    end else if (clr) begin
      for (int i = 0; i < `SFPB_PC_N; i++) c[i] <= 64'd0;
      c[`SFPB_PC_MMIO_RD_LAT_MIN] <= 64'h0000_0000_FFFF_FFFF;
    end else if (en) begin
      c[`SFPB_PC_CYCLES]  <= c[`SFPB_PC_CYCLES] + 64'd1;
      c[`SFPB_PC_CQ_TLPS] <= c[`SFPB_PC_CQ_TLPS] + 64'(e_cq_tlp);
      c[`SFPB_PC_CQ_MRD]  <= c[`SFPB_PC_CQ_MRD]  + 64'(e_cq_mrd);
      c[`SFPB_PC_CQ_MWR]  <= c[`SFPB_PC_CQ_MWR]  + 64'(e_cq_mwr);
      c[`SFPB_PC_CQ_BAD]  <= c[`SFPB_PC_CQ_BAD]  + 64'(e_cq_bad);
      c[`SFPB_PC_CC_TLPS] <= c[`SFPB_PC_CC_TLPS] + 64'(e_cc_tlp);
      c[`SFPB_PC_RQ_MRD]  <= c[`SFPB_PC_RQ_MRD]  + 64'(e_rq_mrd);
      c[`SFPB_PC_RQ_MWR]  <= c[`SFPB_PC_RQ_MWR]  + 64'(e_rq_mwr);
      c[`SFPB_PC_RC_TLPS] <= c[`SFPB_PC_RC_TLPS] + 64'(e_rc_tlp);
      if (e_rdlat_valid) begin
        c[`SFPB_PC_MMIO_RD_LAT_SUM] <= c[`SFPB_PC_MMIO_RD_LAT_SUM] + 64'(e_rdlat);
        c[`SFPB_PC_MMIO_RD_LAT_CNT] <= c[`SFPB_PC_MMIO_RD_LAT_CNT] + 64'd1;
        if ({48'd0, e_rdlat} < c[`SFPB_PC_MMIO_RD_LAT_MIN]) c[`SFPB_PC_MMIO_RD_LAT_MIN] <= {48'd0, e_rdlat};
        if ({48'd0, e_rdlat} > c[`SFPB_PC_MMIO_RD_LAT_MAX]) c[`SFPB_PC_MMIO_RD_LAT_MAX] <= {48'd0, e_rdlat};
      end
      if (e_wrlat_valid) begin
        c[`SFPB_PC_MMIO_WR_LAT_SUM] <= c[`SFPB_PC_MMIO_WR_LAT_SUM] + 64'(e_wrlat);
        c[`SFPB_PC_MMIO_WR_LAT_CNT] <= c[`SFPB_PC_MMIO_WR_LAT_CNT] + 64'd1;
      end
      if (e_cpllat_valid) begin
        c[`SFPB_PC_CPL_LAT_SUM] <= c[`SFPB_PC_CPL_LAT_SUM] + 64'(e_cpllat);
        c[`SFPB_PC_CPL_LAT_CNT] <= c[`SFPB_PC_CPL_LAT_CNT] + 64'd1;
        if ({48'd0, e_cpllat} > c[`SFPB_PC_CPL_LAT_MAX]) c[`SFPB_PC_CPL_LAT_MAX] <= {48'd0, e_cpllat};
      end
      c[`SFPB_PC_DMA_RD_BYTES] <= c[`SFPB_PC_DMA_RD_BYTES] + 64'(e_dma_rd_bytes);
      c[`SFPB_PC_DMA_WR_BYTES] <= c[`SFPB_PC_DMA_WR_BYTES] + 64'(e_dma_wr_bytes);
      c[`SFPB_PC_DMA_ACTIVE]   <= c[`SFPB_PC_DMA_ACTIVE]   + 64'(l_dma_active);
      if ({55'd0, l_outstanding} > c[`SFPB_PC_OUT_MAX]) c[`SFPB_PC_OUT_MAX] <= {55'd0, l_outstanding};
      c[`SFPB_PC_OUT_SUM]      <= c[`SFPB_PC_OUT_SUM] + {55'd0, l_outstanding};
      if ({60'd0, l_hdrq} > c[`SFPB_PC_HDRQ_MAX]) c[`SFPB_PC_HDRQ_MAX] <= {60'd0, l_hdrq};
      if ({48'd0, l_payq} > c[`SFPB_PC_PAYQ_MAX]) c[`SFPB_PC_PAYQ_MAX] <= {48'd0, l_payq};
      c[`SFPB_PC_BP_CQ]  <= c[`SFPB_PC_BP_CQ]  + 64'(l_bp_cq);
      c[`SFPB_PC_BP_CC]  <= c[`SFPB_PC_BP_CC]  + 64'(l_bp_cc);
      c[`SFPB_PC_BP_RQ]  <= c[`SFPB_PC_BP_RQ]  + 64'(l_bp_rq);
      c[`SFPB_PC_BP_SFB] <= c[`SFPB_PC_BP_SFB] + 64'(l_bp_sfb);
      c[`SFPB_PC_HDR_BYTES] <= c[`SFPB_PC_HDR_BYTES] + 64'(e_hdr_bytes);
      c[`SFPB_PC_PAY_BYTES] <= c[`SFPB_PC_PAY_BYTES] + 64'(e_pay_bytes);
      c[`SFPB_PC_ERR_EVENTS]<= c[`SFPB_PC_ERR_EVENTS]+ 64'(e_err_events);
      c[`SFPB_PC_ORD_STALL] <= c[`SFPB_PC_ORD_STALL] + 64'(l_ord_stall);
      c[`SFPB_PC_CPL_UNEXPECTED] <= c[`SFPB_PC_CPL_UNEXPECTED] + 64'(e_cpl_unexpected);
      c[`SFPB_PC_TAG_STALL] <= c[`SFPB_PC_TAG_STALL] + 64'(l_tag_stall);
      c[`SFPB_PC_CRED_STALL]<= c[`SFPB_PC_CRED_STALL]+ 64'(l_cred_stall);
    end
  end

  always_comb begin
    data = 64'd0;
    if (32'(sel) < `SFPB_PC_N) data = c[sel];
  end
endmodule
`default_nettype wire
