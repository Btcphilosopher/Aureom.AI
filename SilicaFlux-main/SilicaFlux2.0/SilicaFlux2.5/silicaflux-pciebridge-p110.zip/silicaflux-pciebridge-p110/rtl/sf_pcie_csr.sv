// =============================================================================
// sf_pcie_csr -- global register page of the PCIe bridge (BAR_REG offset 0x000-0xFFF).
// Per-context DMA pages live in sf_pcie_dma_submit; interrupt registers (0x040-0x058) live in
// sf_pcie_interrupt_adapter and are reached through the pass-through port below.
//
// Access rules: writes honour byte strobes; undefined offsets (and writes to RO registers) are errors that the
// engine turns into UR (reads) / a logged drop (writes); read-only status registers are never writable.
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
`include "sf_pcie_regs.svh"
module sf_pcie_csr #(
  parameter int K            = 8,
  parameter int TAGS         = 16,
  parameter int NCTX         = 4,
  parameter int MMIO_MAX_DW  = 64,
  parameter int CPL_MAX_DW   = 32,
  parameter int DMA_PRESENT  = 1,
  parameter int MSI_CAPABLE  = 1,
  parameter int NEV          = 4            // error-event input ports
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              soft_rst,      // FLR / SOFT_RESET: host-visible control state returns to defaults
  // host register bus (from the MMIO engine; page 0 only)
  input  wire logic              wr_valid,
  /* verilator lint_off UNUSEDSIGNAL */  // registers are dword aligned
  input  wire logic [11:0]       wr_addr,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [31:0]       wr_data,
  input  wire logic [3:0]        wr_strb,
  output logic                   wr_err,
  input  wire logic              rd_valid,
  /* verilator lint_off UNUSEDSIGNAL */  // registers are dword aligned
  input  wire logic [11:0]       rd_addr,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic                   rd_dvalid,
  output logic [31:0]            rd_data,
  output logic                   rd_err,
  // interrupt register pass-through (0x040-0x058)
  output logic                   irq_wr_valid,
  output logic [7:0]             irq_wr_addr,
  output logic [31:0]            irq_wr_data,
  output logic [3:0]             irq_wr_strb,
  output logic [7:0]             irq_rd_addr,
  input  wire logic [31:0]       irq_rd_data,
  // control outputs
  output logic                   cfg_fwin_rd_en,
  output logic                   cfg_fwin_wr_en,
  output logic                   cfg_dma_en,
  output logic                   cfg_wr_flush_en,
  output logic                   cfg_tc_any,
  output logic                   cfg_perf_en,
  output logic [31:0]            cfg_cpl_timeout,
  output logic [31:0]            cfg_sfb_timeout,
  output logic [31:0]            cfg_rec_quiet,
  output logic [31:0]            cfg_dma_timeout,
  output logic [15:0]            cfg_dma_type_en,
  output logic                   ctl_soft_reset,
  output logic                   ctl_fatal_clr,
  output logic                   ctl_perf_clear,
  output logic                   ctl_zombie_clr,
  output logic                   ctl_dma_abort,
  output logic                   ctl_dma_soft_reset,
  output logic [5:0]             dma_perf_sel,
  input  wire logic [63:0]       dma_perf_data,
  // status inputs
  input  wire logic              st_link_up,
  input  wire logic              st_recovering,
  input  wire logic              st_fatal,
  input  wire logic              st_dma_busy,
  input  wire logic              st_dma_fenced,
  input  wire logic              st_dma_proto,
  input  wire logic              st_dma_soft_pend,
  input  wire logic              st_irq_pending,
  input  wire logic              st_np_ok,
  input  wire logic              st_p_ok,
  input  wire logic [7:0]        st_outstanding,
  input  wire logic [7:0]        st_zombies,
  input  wire logic [3:0]        st_rec_state,
  // error events (priority: port 0 first); every valid event sets its class bit and bumps the event counter
  input  wire logic [NEV-1:0]       ev_valid,
  input  wire logic [NEV*6-1:0]     ev_code,
  input  wire logic [NEV*64-1:0]    ev_addr,
  input  wire logic [NEV*8-1:0]     ev_tag,
  input  wire logic [NEV*16-1:0]    ev_reqid,
  input  wire logic [NEV*4-1:0]     ev_type,
  input  wire logic [NEV*4-1:0]     ev_ctx,
  output logic                      err_irq,            // ERR_STATUS & ERR_MASK != 0
  output logic [3:0]                err_events_now,     // events accepted this cycle (statistics)
  // last DMA egress violation
  input  wire logic              dmaev_valid,
  input  wire logic [5:0]        dmaev_code,
  input  wire logic [3:0]        dmaev_dom,
  input  wire logic              dmaev_write,
  input  wire logic [63:0]       dmaev_addr,
  // performance counter window
  output logic [5:0]             perf_sel,
  input  wire logic [63:0]       perf_data
);
  // ---- error class mapping -----------------------------------------------------------------------------------------
  function automatic logic [15:0] class_of(input logic [5:0] c);
    class_of = 16'd0;
    case (c)
      `SFPB_E_MAL_LEN, `SFPB_E_MAL_FRAMING, `SFPB_E_MAL_ZERO_LEN, `SFPB_E_MAL_BE, `SFPB_E_MAL_4K,
      `SFPB_E_MAL_RD_PAYLOAD, `SFPB_E_OVERSIZE:                                        class_of[`SFPB_ES_MALFORMED] = 1'b1;
      `SFPB_E_UNSUP_TYPE, `SFPB_E_UNSUP_AT, `SFPB_E_UNSUP_TC:                          class_of[`SFPB_ES_UNSUPPORTED] = 1'b1;
      `SFPB_E_POISONED_REQ, `SFPB_E_CPL_POISONED:                                      class_of[`SFPB_ES_POISONED] = 1'b1;
      `SFPB_E_BAR_INVALID, `SFPB_E_BAR_APERTURE, `SFPB_E_BAR_RANGE, `SFPB_E_BAR_LEN, `SFPB_E_BAR_PERM:
                                                                                       class_of[`SFPB_ES_BAR] = 1'b1;
      `SFPB_E_FAB_ERR, `SFPB_E_FAB_TIMEOUT, `SFPB_E_FAB_FATAL:                         class_of[`SFPB_ES_FABRIC] = 1'b1;
      `SFPB_E_CSR_ERR:                                                                 class_of[`SFPB_ES_CSR] = 1'b1;
      `SFPB_E_CPL_UR, `SFPB_E_CPL_CA, `SFPB_E_CPL_CRS, `SFPB_E_CPL_MISMATCH, `SFPB_E_CPL_OVERRUN,
      `SFPB_E_CPL_BAD_REQID, `SFPB_E_CPL_FRAMING, `SFPB_E_CPL_IPERR, `SFPB_E_CPL_RESET: class_of[`SFPB_ES_CPL_ERR] = 1'b1;
      `SFPB_E_CPL_TIMEOUT:                                                             class_of[`SFPB_ES_CPL_TIMEOUT] = 1'b1;
      `SFPB_E_CPL_UNEXPECTED, `SFPB_E_CPL_LATE:                                        class_of[`SFPB_ES_CPL_UNEXP] = 1'b1;
      `SFPB_E_DMA_NO_CTX, `SFPB_E_DMA_WINDOW, `SFPB_E_DMA_PERM, `SFPB_E_DMA_BADLEN, `SFPB_E_DMA_BADMTYPE,
      `SFPB_E_DMA_BADFORMAT, `SFPB_E_DMA_STRB, `SFPB_E_DMA_PROTO, `SFPB_E_DMA_RECOVERY, `SFPB_E_DMA_ORDER:
                                                                                       class_of[`SFPB_ES_DMA_PROT] = 1'b1;
      `SFPB_E_LINK_DOWN:                                                               class_of[`SFPB_ES_LINK] = 1'b1;
      `SFPB_E_IRQ_FAIL:                                                                class_of[`SFPB_ES_IRQ_FAIL] = 1'b1;
      `SFPB_E_RECOVERED:                                                               class_of[`SFPB_ES_RECOVERED] = 1'b1;
      `SFPB_E_FLR, `SFPB_E_SOFT_RESET:                                                 class_of[`SFPB_ES_FLR] = 1'b1;
      default:                                                                         class_of[`SFPB_ES_OVERFLOW] = 1'b1;
    endcase
  endfunction

  // ---- registers -----------------------------------------------------------------------------------------------------
  logic [31:0] r_scratch, r_ctrl, r_err_mask, r_cpl_to, r_sfb_to, r_rec_quiet, r_dma_to, r_dma_type, r_dma_psel, r_psel;
  logic [15:0] r_err_status;
  logic        log_valid; logic [5:0] log_code; logic [7:0] log_cnt; logic [63:0] log_addr; logic [7:0] log_tag;
  logic [15:0] log_rid; logic [3:0] log_type, log_ctx;
  logic        dlog_valid, dlog_write; logic [5:0] dlog_code; logic [3:0] dlog_dom; logic [63:0] dlog_addr;
  logic [31:0] perf_hi_q, dperf_hi_q;

  function automatic logic [31:0] merge(input logic [31:0] old, input logic [31:0] nw, input logic [3:0] st);
    merge = {st[3] ? nw[31:24] : old[31:24], st[2] ? nw[23:16] : old[23:16], st[1] ? nw[15:8] : old[15:8], st[0] ? nw[7:0] : old[7:0]};
  endfunction

  localparam logic [31:0] CTRL_RESET = 32'h0000_0023;       // FWIN_RD_EN, FWIN_WR_EN, PERF_EN

  assign cfg_fwin_rd_en  = r_ctrl[0];
  assign cfg_fwin_wr_en  = r_ctrl[1];
  assign cfg_dma_en      = r_ctrl[2];
  assign cfg_wr_flush_en = r_ctrl[3];
  assign cfg_tc_any      = r_ctrl[4];
  assign cfg_perf_en     = r_ctrl[5];
  assign cfg_cpl_timeout = r_cpl_to;
  assign cfg_sfb_timeout = r_sfb_to;
  assign cfg_rec_quiet   = r_rec_quiet;
  assign cfg_dma_timeout = r_dma_to;
  assign cfg_dma_type_en = r_dma_type[15:0];
  assign dma_perf_sel    = r_dma_psel[5:0];
  assign perf_sel        = r_psel[5:0];
  assign err_irq         = |(r_err_status & r_err_mask[15:0]);

  // ---- write decode --------------------------------------------------------------------------------------------------
  wire [11:0] wa = {wr_addr[11:2], 2'b00};
  wire [11:0] ra = {rd_addr[11:2], 2'b00};
  wire        wr_irq = (wa >= `SFPB_R_IRQ_STATUS) && (wa <= `SFPB_R_IRQ_SET);
  wire        rd_irq = (ra >= `SFPB_R_IRQ_STATUS) && (ra <= `SFPB_R_IRQ_SET);

  function automatic logic wr_defined(input logic [11:0] a);
    case (a)
      `SFPB_R_SCRATCH, `SFPB_R_CTRL, `SFPB_R_ERR_STATUS, `SFPB_R_ERR_MASK, `SFPB_R_ERR_LOG_CLR, `SFPB_R_CPL_TIMEOUT,
      `SFPB_R_SFB_TIMEOUT, `SFPB_R_REC_QUIET, `SFPB_R_DMA_CTRL, `SFPB_R_DMA_TIMEOUT, `SFPB_R_DMA_TYPE_EN,
      `SFPB_R_DMA_PERF_SEL, `SFPB_R_PERF_SEL: wr_defined = 1'b1;
      default: wr_defined = 1'b0;
    endcase
  endfunction

  always_comb begin
    wr_err = 1'b0;
    if (wr_valid) begin
      if (wr_irq) wr_err = (wa != `SFPB_R_IRQ_STATUS) && (wa != `SFPB_R_IRQ_MASK) && (wa != `SFPB_R_IRQ_VECMAP) &&
                           (wa != `SFPB_R_IRQ_CTRL) && (wa != `SFPB_R_IRQ_SET);
      else        wr_err = !wr_defined(wa);
    end
  end

  assign irq_wr_valid = wr_valid && wr_irq;
  assign irq_wr_addr  = wa[7:0];
  assign irq_wr_data  = wr_data;
  assign irq_wr_strb  = wr_strb;
  assign irq_rd_addr  = ra[7:0];

  // events: priority-select the one that is logged
  logic        any_ev; logic [3:0] ev_sel; logic [15:0] cls_all;
  logic [3:0]  nev;
  always_comb begin
    any_ev = 1'b0; ev_sel = 4'd0; cls_all = 16'd0; nev = 4'd0;
    for (int i = NEV - 1; i >= 0; i--) begin
      if (ev_valid[i]) begin any_ev = 1'b1; ev_sel = 4'(i); cls_all = cls_all | class_of(ev_code[i*6 +: 6]); nev = nev + 4'd1; end
    end
  end
  assign err_events_now = nev;

  // ---- sequential ------------------------------------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      r_scratch <= '0; r_ctrl <= CTRL_RESET; r_err_mask <= 32'h0000_FFFF; r_cpl_to <= 32'h40; r_sfb_to <= 32'h1000;
      r_rec_quiet <= 32'h400; r_dma_to <= 32'h1_0000; r_dma_type <= 32'h3; r_dma_psel <= '0; r_psel <= '0;
      r_err_status <= '0;
      log_valid <= 1'b0; log_code <= '0; log_cnt <= '0; log_addr <= '0; log_tag <= '0; log_rid <= '0; log_type <= '0; log_ctx <= '0;
      dlog_valid <= 1'b0; dlog_write <= 1'b0; dlog_code <= '0; dlog_dom <= '0; dlog_addr <= '0;
      perf_hi_q <= '0; dperf_hi_q <= '0;
      ctl_soft_reset <= 1'b0; ctl_fatal_clr <= 1'b0; ctl_perf_clear <= 1'b0; ctl_zombie_clr <= 1'b0;
      ctl_dma_abort <= 1'b0; ctl_dma_soft_reset <= 1'b0;
      rd_dvalid <= 1'b0; rd_data <= '0; rd_err <= 1'b0;
    end else begin
      ctl_soft_reset <= 1'b0; ctl_fatal_clr <= 1'b0; ctl_perf_clear <= 1'b0; ctl_zombie_clr <= 1'b0;
      ctl_dma_abort <= 1'b0; ctl_dma_soft_reset <= 1'b0;
      rd_dvalid <= rd_valid; rd_err <= 1'b0;

      if (soft_rst) begin                                 // function-level reset: host-visible control state to defaults
        r_scratch <= '0; r_ctrl <= CTRL_RESET; r_err_mask <= 32'h0000_FFFF; r_dma_type <= 32'h3;
      end

      // sticky errors and log
      r_err_status <= r_err_status | cls_all;
      if (any_ev) begin
        if (!log_valid) begin
          log_valid <= 1'b1; log_code <= ev_code[ev_sel*6 +: 6]; log_addr <= ev_addr[ev_sel*64 +: 64];
          log_tag <= ev_tag[ev_sel*8 +: 8]; log_rid <= ev_reqid[ev_sel*16 +: 16]; log_type <= ev_type[ev_sel*4 +: 4];
          log_ctx <= ev_ctx[ev_sel*4 +: 4];
        end else if (log_cnt != 8'hFF) log_cnt <= log_cnt + 8'd1;     // events lost to the single-entry log
      end
      if (dmaev_valid) begin
        dlog_valid <= 1'b1; dlog_code <= dmaev_code; dlog_dom <= dmaev_dom; dlog_write <= dmaev_write; dlog_addr <= dmaev_addr;
      end

      if (wr_valid && !wr_err && !wr_irq) begin
        case (wa)
          `SFPB_R_SCRATCH:     r_scratch   <= merge(r_scratch, wr_data, wr_strb);
          `SFPB_R_CTRL: begin
            r_ctrl <= merge(r_ctrl, wr_data, wr_strb) & 32'h0000_003F;
            if (wr_strb[1]) begin
              ctl_soft_reset <= wr_data[8]; ctl_fatal_clr <= wr_data[9]; ctl_perf_clear <= wr_data[10]; ctl_zombie_clr <= wr_data[11];
            end
          end
          `SFPB_R_ERR_STATUS: begin
            if (wr_strb[0]) r_err_status[7:0]  <= (r_err_status[7:0]  & ~wr_data[7:0])  | cls_all[7:0];     // a class raised in the same cycle survives the clear
            if (wr_strb[1]) r_err_status[15:8] <= (r_err_status[15:8] & ~wr_data[15:8]) | cls_all[15:8];
          end
          `SFPB_R_ERR_MASK:    r_err_mask  <= merge(r_err_mask, wr_data, wr_strb);
          `SFPB_R_ERR_LOG_CLR: if (wr_strb[0] && wr_data[0]) begin log_valid <= 1'b0; log_cnt <= '0; dlog_valid <= 1'b0; end
          `SFPB_R_CPL_TIMEOUT: r_cpl_to    <= merge(r_cpl_to, wr_data, wr_strb);
          `SFPB_R_SFB_TIMEOUT: r_sfb_to    <= merge(r_sfb_to, wr_data, wr_strb);
          `SFPB_R_REC_QUIET:   r_rec_quiet <= merge(r_rec_quiet, wr_data, wr_strb);
          `SFPB_R_DMA_CTRL:    if (wr_strb[0]) begin ctl_dma_abort <= wr_data[0]; ctl_dma_soft_reset <= wr_data[1]; end
          `SFPB_R_DMA_TIMEOUT: r_dma_to    <= merge(r_dma_to, wr_data, wr_strb);
          `SFPB_R_DMA_TYPE_EN: r_dma_type  <= merge(r_dma_type, wr_data, wr_strb);
          `SFPB_R_DMA_PERF_SEL:r_dma_psel  <= merge(r_dma_psel, wr_data, wr_strb);
          `SFPB_R_PERF_SEL:    r_psel      <= merge(r_psel, wr_data, wr_strb);
          default: ;
        endcase
      end

      // reads (registered: data valid one cycle after rd_valid)
      if (rd_valid) begin
        rd_data <= 32'd0;
        if (rd_irq) begin
          rd_data <= irq_rd_data;
          if (ra == `SFPB_R_IRQ_SET) rd_err <= 1'b1;             // write-only
        end else begin
          case (ra)
            `SFPB_R_ID:          rd_data <= 32'h5346_5042;
            `SFPB_R_VERSION:     rd_data <= 32'h0100_0000;
            `SFPB_R_CAPS0:       rd_data <= {5'd0, 1'b1, 1'(MSI_CAPABLE), 1'(DMA_PRESENT), 4'd0, 4'(NCTX), 8'((TAGS > 255) ? 255 : TAGS), 8'(K)};
            `SFPB_R_CAPS1:       rd_data <= {16'(CPL_MAX_DW), 16'(MMIO_MAX_DW)};
            `SFPB_R_SCRATCH:     rd_data <= r_scratch;
            `SFPB_R_CTRL:        rd_data <= {20'd0, 4'd0, 2'd0, r_ctrl[5:0]};
            `SFPB_R_STATUS:      rd_data <= {4'd0, st_rec_state, st_zombies, st_outstanding, st_p_ok, st_np_ok, st_irq_pending,
                                             st_dma_fenced, st_dma_busy, st_fatal, st_recovering, st_link_up};
            `SFPB_R_ERR_STATUS:  rd_data <= {16'd0, r_err_status};
            `SFPB_R_ERR_MASK:    rd_data <= {16'd0, r_err_mask[15:0]};
            `SFPB_R_ERR_LOG0:    rd_data <= {8'd0, log_cnt, 7'd0, log_valid, 2'd0, log_code};
            `SFPB_R_ERR_LOG1:    rd_data <= log_addr[31:0];
            `SFPB_R_ERR_LOG2:    rd_data <= log_addr[63:32];
            `SFPB_R_ERR_LOG3:    rd_data <= {log_ctx, log_type, log_rid, log_tag};
            `SFPB_R_CPL_TIMEOUT: rd_data <= r_cpl_to;
            `SFPB_R_SFB_TIMEOUT: rd_data <= r_sfb_to;
            `SFPB_R_REC_QUIET:   rd_data <= r_rec_quiet;
            `SFPB_R_DMA_CTRL:    rd_data <= 32'd0;
            `SFPB_R_DMA_STATUS:  rd_data <= {28'd0, st_dma_soft_pend, st_dma_proto, st_dma_fenced, st_dma_busy};
            `SFPB_R_DMA_TIMEOUT: rd_data <= r_dma_to;
            `SFPB_R_DMA_TYPE_EN: rd_data <= r_dma_type;
            `SFPB_R_DMA_PERF_SEL:rd_data <= r_dma_psel;
            `SFPB_R_DMA_PERF_LO: begin rd_data <= dma_perf_data[31:0]; dperf_hi_q <= dma_perf_data[63:32]; end
            `SFPB_R_DMA_PERF_HI: rd_data <= dperf_hi_q;
            `SFPB_R_DMA_ERR_LOG0:rd_data <= {18'd0, dlog_write, dlog_valid, dlog_dom, 2'd0, dlog_code};
            `SFPB_R_DMA_ERR_LOG1:rd_data <= dlog_addr[31:0];
            `SFPB_R_DMA_ERR_LOG2:rd_data <= dlog_addr[63:32];
            `SFPB_R_PERF_SEL:    rd_data <= r_psel;
            `SFPB_R_PERF_LO:     begin rd_data <= perf_data[31:0]; perf_hi_q <= perf_data[63:32]; end
            `SFPB_R_PERF_HI:     rd_data <= perf_hi_q;
            `SFPB_R_PERF_N:      rd_data <= 32'(`SFPB_PC_N);
            default:             begin rd_data <= 32'd0; rd_err <= 1'b1; end
          endcase
          if (ra == `SFPB_R_ERR_LOG_CLR) rd_err <= 1'b1;
        end
      end
    end
  end

  // (an error class raised in the same cycle as a clearing write is not lost: cls_all is OR-ed in before the clear)
endmodule
`default_nettype wire
