// =============================================================================
// sf_pcie_win_check -- window check + offset translation for one access (combinational).
//
// The host-memory side of DMA is protected by one window per context:  [iova_base, iova_base + iova_size).  The WHOLE
// byte range of an access must lie inside it, computed in 65 bits so that wrap-around is an error, never a pass.
// With xlat = 1 the IOVA is translated by a constant offset (bus = bus_base + (iova - iova_base)); otherwise the
// bus address equals the IOVA (identity, bounds-checked).  This is the "equivalent protected translation" this
// bridge provides: the repository contains no page-walker, and a page-granular IOMMU (DomainGuard P97) can replace
// this block behind the same contract (docs/05_DMA_AND_PROTECTION.md).
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
module sf_pcie_win_check #(
  parameter int BW = 16                     // width of the byte-length input
) (
  input  wire logic          valid,         // context is valid
  input  wire logic          perm_ok,       // direction permitted
  input  wire logic          xlat,
  input  wire logic [63:0]   iova_base,
  input  wire logic [63:0]   iova_size,
  input  wire logic [63:0]   bus_base,
  input  wire logic [63:0]   addr,          // IOVA of the first byte
  input  wire logic [BW-1:0] nbytes,        // access length (> 0)
  output logic               ok,
  output logic [5:0]         err,
  output logic [63:0]        bus_addr
);
  logic [64:0] a_end, w_end;
  always_comb begin
    a_end = {1'b0, addr} + {{(65-BW){1'b0}}, nbytes};
    w_end = {1'b0, iova_base} + {1'b0, iova_size};
    ok = 1'b0; err = `SFPB_E_NONE; bus_addr = 64'd0;
    if (!valid)                          err = `SFPB_E_DMA_NO_CTX;
    else if (nbytes == '0)               err = `SFPB_E_DMA_BADLEN;
    else if (a_end[64] || w_end[64])     err = `SFPB_E_DMA_WINDOW;      // wrap-around anywhere is a violation
    else if (addr < iova_base)           err = `SFPB_E_DMA_WINDOW;
    else if (a_end > w_end)              err = `SFPB_E_DMA_WINDOW;
    else if (!perm_ok)                   err = `SFPB_E_DMA_PERM;
    else begin
      ok = 1'b1;
      bus_addr = xlat ? (bus_base + (addr - iova_base)) : addr;
    end
  end
endmodule
`default_nettype wire
