// =============================================================================
// sf_pcie_bar_decoder -- BAR / MMIO window decode and address validation (combinational).
//
// The endpoint IP owns configuration space and BAR sizing; it reports, per request, the BAR id and the BAR aperture
// (log2 of the BAR size) with the full address.  This block never claims to own those: it only checks that what the
// IP reports matches the apertures this bridge was built for (BAR_*_AP) and maps the offset inside the BAR onto
// bridge targets:
//
//   BAR_REG (default id 0, 64 KiB):  0x0000 CSR page | 0x1000*(1+c) DMA submission page of context c |
//                                     FREG_OFF.. DataFabric register window (SFB2) | else unmapped
//   BAR_MEM (default id 2, 1 MiB):    DataFabric memory window (SFB2)
//
// A request must lie completely inside ONE window.  Any violation yields an explicit SFPB_E_* code; nothing is
// ever aliased or wrapped.
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
module sf_pcie_bar_decoder #(
  parameter int NCTX        = 4,
  parameter int BAR_REG_ID  = 0,
  parameter int BAR_REG_AP  = 16,            // log2(bytes)
  parameter int BAR_MEM_ID  = 2,
  parameter int BAR_MEM_AP  = 20,
  parameter int FREG_OFF    = 32'h8000,      // register window inside BAR_REG
  parameter int FREG_SIZE   = 32'h8000,
  parameter int MMIO_MAX_DW = 64,
  parameter logic [31:0] SFB_REG_BASE = 32'h4000_0000,
  parameter logic [31:0] SFB_MEM_BASE = 32'h8000_0000
) (
  input  wire logic [2:0]  bar_id,
  input  wire logic [5:0]  bar_ap,
  /* verilator lint_off UNUSEDSIGNAL */  // only the offset below the largest aperture (24 bits) is used: the endpoint strips the BAR base
  input  wire logic [63:0] addr,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [10:0] ndw,
  input  wire logic        is_write,
  input  wire logic        cfg_fwin_rd_en,
  input  wire logic        cfg_fwin_wr_en,
  output logic [5:0]       err,              // SFPB_E_NONE when the access maps cleanly
  output logic [2:0]       tgt,              // SFPB_TGT_*
  output logic [15:0]      off,              // CSR / CTX targets: offset inside BAR_REG (page-aligned: bits[15:12] = page)
  output logic [31:0]      sfb_addr          // FREG / FMEM targets: byte address on SFB2
);
  generate
    if (BAR_REG_ID == BAR_MEM_ID) begin : g_chk_id
      sf_pcie_bar_decoder_BAR_ids_must_differ u_err ();
    end
    if (BAR_REG_AP < 13 || BAR_REG_AP > 24 || BAR_MEM_AP < 12 || BAR_MEM_AP > 24) begin : g_chk_ap
      sf_pcie_bar_decoder_aperture_must_be_12_24_bits u_err ();
    end
    if (NCTX < 1 || NCTX > 15) begin : g_chk_nctx
      sf_pcie_bar_decoder_NCTX_must_be_1_15 u_err ();
    end
    if (FREG_OFF < 32'h1000 * (1 + NCTX)) begin : g_chk_freg
      sf_pcie_bar_decoder_FREG_window_overlaps_context_pages u_err ();
    end
    if (FREG_OFF + FREG_SIZE > (1 << BAR_REG_AP)) begin : g_chk_fsz
      sf_pcie_bar_decoder_FREG_window_exceeds_BAR u_err ();
    end
  endgenerate

  logic [24:0] boff;                     // offset inside the BAR (up to 24 bits + 1 spare)
  logic [24:0] bend;                     // first byte after the access
  logic [24:0] win_lo, win_hi;           // bounds of the window the access starts in
  logic [5:0]  exp_ap;
  logic        bar_known;
  logic        in_reg;
  logic [3:0]  page;
  logic [11:0] max_dw;

  always_comb begin
    err = `SFPB_E_NONE; tgt = `SFPB_TGT_NONE; off = '0; sfb_addr = '0;
    in_reg = (bar_id == 3'(BAR_REG_ID));
    bar_known = in_reg || (bar_id == 3'(BAR_MEM_ID));
    exp_ap = in_reg ? 6'(BAR_REG_AP) : 6'(BAR_MEM_AP);
    boff = addr[24:0] & ((25'd1 << exp_ap) - 25'd1);
    bend = boff + {12'd0, ndw, 2'b00};
    page = boff[15:12];
    win_lo = '0; win_hi = '0; max_dw = 12'd2;

    if (!bar_known) begin
      err = `SFPB_E_BAR_INVALID;
    end else if (bar_ap != exp_ap) begin
      err = `SFPB_E_BAR_APERTURE;
    end else begin
      if (in_reg) begin
        if (boff < 25'h1000) begin
          tgt = `SFPB_TGT_CSR; win_lo = 25'h0; win_hi = 25'h1000; off = boff[15:0];
        end else if (boff < 25'(32'h1000 * (1 + NCTX))) begin
          tgt = `SFPB_TGT_CTX; win_lo = {9'd0, page, 12'd0}; win_hi = win_lo + 25'h1000; off = boff[15:0];
        end else if (boff >= 25'(FREG_OFF) && boff < 25'(FREG_OFF + FREG_SIZE)) begin
          tgt = `SFPB_TGT_FREG; win_lo = 25'(FREG_OFF); win_hi = 25'(FREG_OFF + FREG_SIZE);
          sfb_addr = SFB_REG_BASE + {7'd0, boff - 25'(FREG_OFF)}; max_dw = 12'(MMIO_MAX_DW);
        end
      end else begin
        tgt = `SFPB_TGT_FMEM; win_lo = '0; win_hi = 25'd1 << BAR_MEM_AP;
        sfb_addr = SFB_MEM_BASE + {7'd0, boff}; max_dw = 12'(MMIO_MAX_DW);
      end
      if (tgt == `SFPB_TGT_NONE) begin
        err = `SFPB_E_BAR_RANGE;
      end else if (bend > win_hi) begin
        err = `SFPB_E_BAR_RANGE;                                 // spills out of (or across) its window
      end else if ({1'b0, ndw} > max_dw) begin
        err = `SFPB_E_BAR_LEN;
      end else if ((tgt == `SFPB_TGT_FREG || tgt == `SFPB_TGT_FMEM) && (is_write ? !cfg_fwin_wr_en : !cfg_fwin_rd_en)) begin
        err = `SFPB_E_BAR_PERM;
      end
    end
    if (err != `SFPB_E_NONE) begin tgt = `SFPB_TGT_NONE; end
    if (win_lo > boff) err = `SFPB_E_BAR_RANGE;                  // (unreachable by construction; kept as a self-check)
  end
endmodule
`default_nettype wire
