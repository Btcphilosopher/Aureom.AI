// =============================================================================
// sf_pcie_axis_pack -- TX framing for the endpoint's AXI4-Stream transaction interfaces (CC and RQ).
// Inverse of sf_pcie_axis_unpack: takes a "packet beat" stream (header on the first beat, payload dwords from
// lane 0, K dwords per beat except the last) and emits the wire format (header dwords immediately followed by the
// payload dwords, K lanes per beat, tkeep per dword, tlast on the last beat).
//
// Producer contract: every beat except the one with i_eop carries exactly K payload dwords (i_ndw = K); the
// beat with i_eop carries 0..K.  A header-only packet is a single beat with i_sop = i_eop = 1 and i_ndw = 0.
// =============================================================================
`default_nettype none
module sf_pcie_axis_pack #(
  parameter int DATA_W = 256,               // 128 | 256
  parameter int HDR_DW = 4,                 // 4 (RQ) | 3 (CC)
  parameter int USER_W = 1,
  localparam int K     = DATA_W / 32,
  localparam int NW    = $clog2(K + 1)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                flush,
  input  wire logic                i_valid,
  output logic                     i_ready,
  input  wire logic                i_sop,
  input  wire logic                i_eop,
  input  wire logic [DATA_W-1:0]   i_data,
  input  wire logic [NW-1:0]       i_ndw,
  input  wire logic [HDR_DW*32-1:0] i_hdr,   // sampled on i_sop
  input  wire logic [USER_W-1:0]   i_user,   // sampled on i_sop
  output logic [DATA_W-1:0]        m_tdata,
  output logic [K-1:0]             m_tkeep,
  output logic                     m_tlast,
  output logic [USER_W-1:0]        m_tuser,
  output logic                     m_tvalid,
  input  wire logic                m_tready,
  output logic                     idle          // nothing buffered inside
);
  generate
    if (DATA_W != 128 && DATA_W != 256) begin : g_chk_w
      sf_pcie_axis_pack_DATA_W_must_be_128_or_256 u_err ();
    end
    if (HDR_DW != 3 && HDR_DW != 4) begin : g_chk_h
      sf_pcie_axis_pack_HDR_DW_must_be_3_or_4 u_err ();
    end
  endgenerate

  localparam int CATW = 2 * DATA_W;

  logic [DATA_W-1:0]  carry;
  logic [NW-1:0]      cn;
  logic [USER_W-1:0]  user_r;
  logic               tail_valid;
  logic [DATA_W-1:0]  tail_data;
  logic [NW-1:0]      tail_n;

  logic [DATA_W-1:0]  c_in;                // carry as seen by this beat (the header for a first beat)
  logic [NW-1:0]      cn_in;
  logic [DATA_W-1:0]  pl;
  logic [CATW-1:0]    cat;
  logic [NW:0]        tot;

  always_comb begin
    c_in  = carry;
    cn_in = cn;
    if (i_sop) begin
      c_in = '0;
      c_in[HDR_DW*32-1:0] = i_hdr;
      cn_in = NW'(HDR_DW);
    end
    pl = '0;
    for (int i = 0; i < K; i++) begin
      if (i < 32'(i_ndw)) pl[i*32 +: 32] = i_data[i*32 +: 32];
    end
    cat = {{DATA_W{1'b0}}, pl} << ({{(32-NW){1'b0}}, cn_in} * 32);
    cat = cat | {{DATA_W{1'b0}}, c_in};
    tot = {1'b0, cn_in} + {1'b0, i_ndw};
  end

  wire out_free = !m_tvalid || m_tready;
  assign i_ready = !tail_valid && out_free && !flush;
  wire in_fire = i_valid && i_ready;
  assign idle = !m_tvalid && !tail_valid && (cn == '0);

  function automatic logic [K-1:0] keepmask(input logic [NW:0] n);
    keepmask = K'((1 << n) - 1);
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      carry <= '0; cn <= '0; user_r <= '0; tail_valid <= 1'b0; tail_data <= '0; tail_n <= '0;
      m_tdata <= '0; m_tkeep <= '0; m_tlast <= 1'b0; m_tuser <= '0; m_tvalid <= 1'b0;
    end else if (flush) begin
      carry <= '0; cn <= '0; tail_valid <= 1'b0; m_tvalid <= 1'b0;
    end else begin
      if (m_tvalid && m_tready) m_tvalid <= 1'b0;

      if (tail_valid && out_free) begin
        m_tvalid <= 1'b1; m_tdata <= tail_data; m_tkeep <= keepmask({1'b0, tail_n}); m_tlast <= 1'b1; m_tuser <= user_r;
        tail_valid <= 1'b0;
      end

      if (in_fire) begin
        if (i_sop) user_r <= i_user;
        if (i_eop) begin
          carry <= '0; cn <= '0;
          m_tvalid <= 1'b1; m_tdata <= cat[DATA_W-1:0]; m_tuser <= i_sop ? i_user : user_r;
          if (tot <= (NW+1)'(K)) begin
            m_tkeep <= keepmask(tot); m_tlast <= 1'b1;
          end else begin
            m_tkeep <= {K{1'b1}}; m_tlast <= 1'b0;
            tail_valid <= 1'b1; tail_data <= cat[CATW-1:DATA_W]; tail_n <= NW'(tot - (NW+1)'(K));
          end
        end else begin
          // non-final beats are full (producer contract); with the header merged in, a full output beat is always ready
          m_tvalid <= 1'b1; m_tdata <= cat[DATA_W-1:0]; m_tkeep <= {K{1'b1}}; m_tlast <= 1'b0; m_tuser <= i_sop ? i_user : user_r;
          carry <= cat[CATW-1:DATA_W]; cn <= NW'(tot - (NW+1)'(K));
        end
      end
    end
  end
endmodule
`default_nettype wire
