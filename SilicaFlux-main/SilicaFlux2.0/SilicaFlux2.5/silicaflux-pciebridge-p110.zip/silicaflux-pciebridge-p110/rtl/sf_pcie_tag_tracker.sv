// =============================================================================
// sf_pcie_tag_tracker -- outstanding non-posted request table, completion matching, timeouts.
//
// * allocation:  a free tag is offered while al_ready; al_valid && al_ready claims it (the DMA adapter builds the RQ
//   header with al_tag in the same cycle).  Tags are handed out round-robin so a freed tag is reused as late as possible.
// * matching:    every completion is matched by tag against the table.  Completions of ONE request arrive in address
//   order, completions of DIFFERENT requests may arrive in any order and interleave -- nothing here assumes otherwise.
//   Checked per completion: tag owner, requester id (optional), status, endpoint error code, poison, dword count against
//   the remainder, byte count against the remainder, lower address against the expected next address, and at the end of
//   the completion that the stream length equals the descriptor's dword count and framing was clean.
// * data:        accepted payload is written to the owner's slot buffer at the right dword position (bw_*).
// * outcome:     every request ends in exactly ONE event: OK (all bytes received and consistent) or an error code.
// * quarantine:  a tag whose request failed in a way that may still produce completions (timeout, inconsistent
//   completion, reset) becomes ZOMBIE: it is NOT reused (a late completion must not be mistaken for a new request) and
//   late completions for it are dropped and counted.  Zombies are released by zombie_clr (after recovery / by software).
// * timeout:     per-tag age counters advance on a prescaled tick; age >= cfg_timeout_ticks fails the request (ZOMBIE).
// * flush:       (reset / FLR / link down) every outstanding request fails with SFPB_E_CPL_RESET -- never as success.
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
module sf_pcie_tag_tracker #(
  parameter int DATA_W    = 256,
  parameter int TAGS      = 16,              // power of two, 2..256
  parameter int SLOT_W    = 2,
  parameter int OFF_W     = 7,               // dword offset inside a slot buffer
  parameter int TICK_LOG2 = 8,               // age counters advance every 2**TICK_LOG2 cycles
  localparam int K        = DATA_W / 32,
  localparam int NW       = $clog2(K + 1),
  localparam int TW       = $clog2(TAGS)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              flush,            // level: fail everything outstanding, accept nothing new
  input  wire logic              zombie_clr,       // pulse: release quarantined tags
  input  wire logic [31:0]       cfg_timeout_ticks,// 0 = disabled
  input  wire logic [15:0]       cfg_req_id,
  input  wire logic              cfg_check_reqid,
  // allocation
  input  wire logic              al_valid,
  output logic                   al_ready,
  output logic [TW-1:0]          al_tag,
  input  wire logic [SLOT_W-1:0] al_slot,
  input  wire logic [OFF_W-1:0]  al_off,
  input  wire logic [11:0]       al_ndw,           // dwords requested (>= 1)
  input  wire logic              al_flush_kind,    // zero-length flush read: expects one 1-dword completion
  input  wire logic [6:0]        al_addr_lo,       // request address [6:0] (dword aligned)
  // inbound completion stream
  input  wire logic              rcv_valid,
  output logic                   rcv_ready,
  input  wire logic              rcv_sop,
  input  wire logic              rcv_eop,
  input  wire logic [DATA_W-1:0] rcv_data,
  input  wire logic [NW-1:0]     rcv_ndw,
  input  wire logic              rcv_bad,
  input  wire logic [6:0]        rcv_lower,
  input  wire logic [3:0]        rcv_err,
  input  wire logic [12:0]       rcv_bytecnt,
  input  wire logic [10:0]       rcv_dwcnt,
  input  wire logic [2:0]        rcv_status,
  input  wire logic              rcv_poison,
  input  wire logic [15:0]       rcv_reqid,
  input  wire logic [7:0]        rcv_tag,
  // slot buffer write port
  output logic                   bw_valid,
  output logic [SLOT_W-1:0]      bw_slot,
  output logic [OFF_W-1:0]       bw_dw,
  output logic [DATA_W-1:0]      bw_data,
  output logic [NW-1:0]          bw_ndw,
  // per-request outcome (one pulse per request)
  output logic                   ev_valid,
  output logic [TW-1:0]          ev_tag,
  output logic [SLOT_W-1:0]      ev_slot,
  output logic                   ev_ok,
  output logic [5:0]             ev_err,
  output logic                   ev_flush_kind,
  // diagnostics (log events that are not request outcomes)
  output logic                   dg_valid,
  output logic [5:0]             dg_code,
  output logic [7:0]             dg_tag,
  // status / statistics
  output logic [8:0]             st_out,           // requests outstanding
  output logic [8:0]             st_zombie,
  output logic                   st_lat_valid,
  output logic [15:0]            st_lat,
  output logic                   st_flushing       // flush level still has work to do
);
  generate
    if (TAGS < 2 || TAGS > 256 || (TAGS & (TAGS - 1)) != 0) begin : g_chk_tags
      sf_pcie_tag_tracker_TAGS_must_be_a_power_of_two_2_256 u_err ();
    end
  endgenerate

  localparam logic [1:0] T_FREE = 2'd0, T_WAIT = 2'd1, T_ZOMB = 2'd2;

  logic [1:0]        e_st    [0:TAGS-1];
  logic [SLOT_W-1:0] e_slot  [0:TAGS-1];
  logic [OFF_W-1:0]  e_off   [0:TAGS-1];
  logic [11:0]       e_total [0:TAGS-1];
  logic [11:0]       e_got   [0:TAGS-1];
  logic [6:0]        e_lo    [0:TAGS-1];
  logic              e_fk    [0:TAGS-1];
  logic [7:0]        e_age   [0:TAGS-1];
  logic [15:0]       e_ts    [0:TAGS-1];

  logic [15:0]       now;
  logic [TICK_LOG2-1:0] pre;
  wire               tick = (pre == '1);
  logic [TW-1:0]     rr;

  // ---- allocation: first FREE tag at or after rr ---------------------------------------------------------------
  logic              any_free;
  logic [TW-1:0]     free_tag;
  always_comb begin
    any_free = 1'b0; free_tag = '0;
    for (int j = TAGS - 1; j >= 0; j--) begin
      logic [TW-1:0] idx;
      idx = rr + TW'(j);
      if (e_st[idx] == T_FREE) begin any_free = 1'b1; free_tag = idx; end
    end
  end
  assign al_tag   = free_tag;
  assign al_ready = any_free && !flush;
  wire   alloc    = al_valid && al_ready;

  // ---- stage 1: register the completion beat -------------------------------------------------------------------
  logic              p_valid, p_sop, p_eop, p_bad;
  logic [DATA_W-1:0] p_data;
  logic [NW-1:0]     p_ndw;
  logic [6:0]        p_lower; logic [3:0] p_err; logic [12:0] p_bytecnt; logic [10:0] p_dwcnt; logic [2:0] p_status;
  logic              p_poison; logic [15:0] p_reqid; logic [7:0] p_tag;
  assign rcv_ready = 1'b1;                    // always accepted: processing never stalls (one event per cycle by construction)

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      p_valid <= 1'b0; p_sop <= 1'b0; p_eop <= 1'b0; p_bad <= 1'b0; p_data <= '0; p_ndw <= '0; p_lower <= '0; p_err <= '0;
      p_bytecnt <= '0; p_dwcnt <= '0; p_status <= '0; p_poison <= 1'b0; p_reqid <= '0; p_tag <= '0;
    end else begin
      p_valid <= rcv_valid && rcv_ready;
      p_sop <= rcv_sop; p_eop <= rcv_eop; p_bad <= rcv_bad; p_data <= rcv_data; p_ndw <= rcv_ndw; p_lower <= rcv_lower;
      p_err <= rcv_err; p_bytecnt <= rcv_bytecnt; p_dwcnt <= rcv_dwcnt; p_status <= rcv_status; p_poison <= rcv_poison;
      p_reqid <= rcv_reqid; p_tag <= rcv_tag;
    end
  end

  // ---- stage 2: processing ---------------------------------------------------------------------------------------
  wire  [11:0]       pndw12 = {{(12-NW){1'b0}}, p_ndw};
  logic              cur_act;                 // a matched, accepted completion is in progress
  logic [TW-1:0]     cur_tag;
  logic [11:0]       cur_cnt;                 // dwords of the running completion deposited so far

  wire               in_range = (p_tag < 8'(TAGS));
  wire  [TW-1:0]     pt       = p_tag[TW-1:0];
  wire  [1:0]        st_h     = in_range ? e_st[pt] : T_FREE;
  wire  [11:0]       rem_h    = e_total[pt] - e_got[pt];
  wire  [12:0]       rem_b    = {rem_h, 1'b0} + {rem_h, 1'b0};          // 4 * remaining (13 bit)

  // header verdict (valid on p_sop)
  logic              h_match, h_ok, h_term_free;
  logic [5:0]        h_code;
  logic              h_diag;                 // the beat belongs to no outstanding request
  logic [5:0]        h_diag_code;
  always_comb begin
    h_match = 1'b0; h_ok = 1'b0; h_term_free = 1'b0; h_code = `SFPB_E_NONE; h_diag = 1'b0; h_diag_code = `SFPB_E_NONE;
    if (!in_range || st_h == T_FREE) begin
      h_diag = 1'b1; h_diag_code = `SFPB_E_CPL_UNEXPECTED;
    end else if (st_h == T_ZOMB) begin
      h_diag = 1'b1; h_diag_code = `SFPB_E_CPL_LATE;
    end else if (cfg_check_reqid && (p_reqid != cfg_req_id)) begin
      h_diag = 1'b1; h_diag_code = `SFPB_E_CPL_BAD_REQID;
    end else begin
      h_match = 1'b1;
      if (p_err != `SFPB_RCE_NONE) begin
        case (p_err)
          `SFPB_RCE_POISONED:   h_code = `SFPB_E_CPL_POISONED;
          `SFPB_RCE_BAD_STATUS: begin
            h_code = (p_status == `SFPB_CPL_UR) ? `SFPB_E_CPL_UR : (p_status == `SFPB_CPL_CA) ? `SFPB_E_CPL_CA : `SFPB_E_CPL_CRS;
            h_term_free = 1'b1;
          end
          `SFPB_RCE_INV_LEN, `SFPB_RCE_MISMATCH, `SFPB_RCE_INV_ADDR, `SFPB_RCE_INV_TAG: h_code = `SFPB_E_CPL_MISMATCH;
          `SFPB_RCE_FLR:        h_code = `SFPB_E_CPL_RESET;
          `SFPB_RCE_TIMEOUT:    h_code = `SFPB_E_CPL_TIMEOUT;
          default:              h_code = `SFPB_E_CPL_IPERR;
        endcase
      end else if (p_status != `SFPB_CPL_SC) begin
        h_code = (p_status == `SFPB_CPL_UR) ? `SFPB_E_CPL_UR : (p_status == `SFPB_CPL_CA) ? `SFPB_E_CPL_CA : `SFPB_E_CPL_CRS;
        h_term_free = 1'b1;                      // UR / CA end the request: no further completions follow
      end else if (e_fk[pt]) begin
        if (p_dwcnt != 11'd1) h_code = `SFPB_E_CPL_MISMATCH; else h_ok = 1'b1;
      end else if (p_dwcnt == 11'd0)                    h_code = `SFPB_E_CPL_MISMATCH;
      else if ({1'b0, p_dwcnt} > rem_h)                 h_code = `SFPB_E_CPL_OVERRUN;
      else if (p_bytecnt != rem_b)                      h_code = `SFPB_E_CPL_MISMATCH;
      else if (p_lower != e_lo[pt])                     h_code = `SFPB_E_CPL_MISMATCH;
      else if (p_poison)                                h_code = `SFPB_E_CPL_POISONED;
      else                                              h_ok = 1'b1;
    end
  end

  // which beat context applies
  wire               ctx_act   = p_sop ? (h_match && h_ok) : cur_act;
  wire  [TW-1:0]     ctx_tag   = p_sop ? pt : cur_tag;
  wire  [11:0]       ctx_cnt   = p_sop ? 12'd0 : cur_cnt;
  wire               dep_en    = p_valid && ctx_act && !e_fk[ctx_tag] && !flush;
  wire  [11:0]       dep_room  = p_dwcnt - ctx_cnt;
  wire  [11:0]       dep_n12   = (pndw12 > dep_room) ? dep_room : pndw12;

  assign bw_valid = dep_en && (dep_n12 != 12'd0) && (p_ndw != '0);
  assign bw_slot  = e_slot[ctx_tag];
  assign bw_dw    = e_off[ctx_tag] + OFF_W'(e_got[ctx_tag]) + OFF_W'(ctx_cnt);
  assign bw_data  = p_data;
  assign bw_ndw   = NW'(dep_n12);

  // completion at eop
  wire  [11:0]       cnt_all   = ctx_cnt + pndw12;
  wire               len_ok    = (cnt_all == {1'b0, p_dwcnt}) || e_fk[ctx_tag];
  wire               done_all  = (e_got[ctx_tag] + {1'b0, p_dwcnt}) == e_total[ctx_tag];

  // ---- timeout scan ----------------------------------------------------------------------------------------------
  logic              exp_any;
  logic [TW-1:0]     exp_idx;
  always_comb begin
    exp_any = 1'b0; exp_idx = '0;
    for (int j = TAGS - 1; j >= 0; j--) begin
      if (e_st[j] == T_WAIT && cfg_timeout_ticks != 32'd0 && {24'd0, e_age[j]} >= cfg_timeout_ticks &&
          !(cur_act && cur_tag == TW'(j))) begin
        exp_any = 1'b1; exp_idx = TW'(j);
      end
    end
  end
  // flush scan: first WAIT entry
  logic              fl_any;
  logic [TW-1:0]     fl_idx;
  always_comb begin
    fl_any = 1'b0; fl_idx = '0;
    for (int j = TAGS - 1; j >= 0; j--) begin
      if (e_st[j] == T_WAIT) begin fl_any = 1'b1; fl_idx = TW'(j); end
    end
  end
  assign st_flushing = flush && (fl_any || cur_act);

  // outcome produced by the beat stage this cycle?
  logic              s_ev;           // stage-2 event
  logic              s_ev_ok;
  logic [5:0]        s_ev_err;
  logic [TW-1:0]     s_ev_tag;
  logic              s_ev_free;      // entry -> FREE (else ZOMBIE) on failure
  always_comb begin
    s_ev = 1'b0; s_ev_ok = 1'b0; s_ev_err = `SFPB_E_NONE; s_ev_tag = ctx_tag; s_ev_free = 1'b0;
    if (p_valid && !flush) begin
      if (p_sop && h_match && !h_ok) begin                      // matched but unacceptable
        s_ev = 1'b1; s_ev_err = h_code; s_ev_tag = pt; s_ev_free = h_term_free;
      end else if (p_eop && ctx_act) begin
        s_ev_tag = ctx_tag;
        if (p_bad)         begin s_ev = 1'b1; s_ev_err = `SFPB_E_CPL_FRAMING;  end
        else if (!len_ok)  begin s_ev = 1'b1; s_ev_err = `SFPB_E_CPL_MISMATCH; end
        else if (done_all) begin s_ev = 1'b1; s_ev_ok = 1'b1; end
      end
    end
  end
  wire t_ev = !s_ev && !flush && exp_any;                       // timeout event (only when the beat stage is silent)
  wire f_ev = flush && fl_any;                                  // flush event

  always_comb begin
    ev_valid = 1'b0; ev_tag = '0; ev_slot = '0; ev_ok = 1'b0; ev_err = `SFPB_E_NONE; ev_flush_kind = 1'b0;
    if (f_ev) begin
      ev_valid = 1'b1; ev_tag = fl_idx; ev_err = `SFPB_E_CPL_RESET;
    end else if (s_ev) begin
      ev_valid = 1'b1; ev_tag = s_ev_tag; ev_ok = s_ev_ok; ev_err = s_ev_err;
    end else if (t_ev) begin
      ev_valid = 1'b1; ev_tag = exp_idx; ev_err = `SFPB_E_CPL_TIMEOUT;
    end
    ev_slot = e_slot[ev_tag]; ev_flush_kind = e_fk[ev_tag];
  end

  assign dg_valid = p_valid && p_sop && h_diag && !flush;
  assign dg_code  = h_diag_code;
  assign dg_tag   = p_tag;

`ifndef SYNTHESIS
`ifdef SF_PCIE_DEBUG
  always_ff @(posedge clk) begin
    if (p_valid && p_sop) $display("[trk %0t] hdr tag=%0d st=%0d match=%b ok=%b code=%h dwcnt=%0d bytecnt=%0d rem_b=%0d lower=%0h e_lo=%0h status=%0d err=%0d ndw=%0d sop=%b eop=%b", $time, p_tag, st_h, h_match, h_ok, h_code, p_dwcnt, p_bytecnt, rem_b, p_lower, e_lo[pt], p_status, p_err, p_ndw, p_sop, p_eop);
    if (ev_valid) $display("[trk %0t] event tag=%0d ok=%b err=%h", $time, ev_tag, ev_ok, ev_err);
    if (alloc) $display("[trk %0t] alloc tag=%0d slot=%0d off=%0d ndw=%0d", $time, al_tag, al_slot, al_off, al_ndw);
    if (rcv_valid) $display("[trk %0t] rcv sop=%b eop=%b ndw=%0d tag=%0d dwcnt=%0d bytecnt=%0d lower=%0h status=%0d", $time, rcv_sop, rcv_eop, rcv_ndw, rcv_tag, rcv_dwcnt, rcv_bytecnt, rcv_lower, rcv_status);
  end
`endif
`endif
  // ---- sequential --------------------------------------------------------------------------------------------------
  integer n;
  logic [8:0] c_wait, c_zomb;
  always_comb begin
    c_wait = '0; c_zomb = '0;
    for (int j = 0; j < TAGS; j++) begin
      if (e_st[j] == T_WAIT) c_wait = c_wait + 9'd1;
      if (e_st[j] == T_ZOMB) c_zomb = c_zomb + 9'd1;
    end
  end
  assign st_out = c_wait;
  assign st_zombie = c_zomb;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (n = 0; n < TAGS; n++) begin
        e_st[n] <= T_FREE; e_age[n] <= '0; e_ts[n] <= '0; e_slot[n] <= '0; e_off[n] <= '0; e_total[n] <= '0; e_got[n] <= '0;
        e_lo[n] <= '0; e_fk[n] <= 1'b0;
      end
      now <= '0; pre <= '0; rr <= '0; cur_act <= 1'b0; cur_tag <= '0; cur_cnt <= '0;
      st_lat_valid <= 1'b0; st_lat <= '0;
    end else begin
      now <= now + 16'd1; pre <= pre + 1'b1; st_lat_valid <= 1'b0;
      if (tick) for (n = 0; n < TAGS; n++) if (e_st[n] == T_WAIT && e_age[n] != 8'hFF) e_age[n] <= e_age[n] + 8'd1;

      if (zombie_clr) for (n = 0; n < TAGS; n++) if (e_st[n] == T_ZOMB) e_st[n] <= T_FREE;      // (a flush conversion later in this block wins over the release)

      if (alloc) begin
        e_st[al_tag] <= T_WAIT; e_slot[al_tag] <= al_slot; e_off[al_tag] <= al_off; e_total[al_tag] <= al_ndw; e_got[al_tag] <= '0;
        e_lo[al_tag] <= al_addr_lo; e_fk[al_tag] <= al_flush_kind; e_age[al_tag] <= '0; e_ts[al_tag] <= now;
        rr <= al_tag + 1'b1;
      end

      // beat stage
      if (flush) begin
        cur_act <= 1'b0; cur_cnt <= '0;
      end else if (p_valid) begin
        if (p_sop) begin
          cur_tag <= pt;
          cur_act <= h_match && h_ok;
          cur_cnt <= pndw12;
          if (h_match) e_age[pt] <= '0;
        end else cur_cnt <= cur_cnt + pndw12;
        if (p_eop) begin
          cur_act <= 1'b0; cur_cnt <= '0;
          if (ctx_act && !p_bad && len_ok) begin
            e_got[ctx_tag] <= e_got[ctx_tag] + p_dwcnt;
            e_lo[ctx_tag]  <= e_lo[ctx_tag] + {p_dwcnt[4:0], 2'b00};
            e_age[ctx_tag] <= '0;
          end
        end
      end

      // outcomes
      if (f_ev) begin
        e_st[fl_idx] <= T_ZOMB;
      end else if (s_ev) begin
        if (s_ev_ok) begin
          e_st[s_ev_tag] <= T_FREE;
          st_lat_valid <= 1'b1; st_lat <= now - e_ts[s_ev_tag];
        end else e_st[s_ev_tag] <= s_ev_free ? T_FREE : T_ZOMB;
      end else if (t_ev) begin
        e_st[exp_idx] <= T_ZOMB;
      end
    end
  end
endmodule
`default_nettype wire
