// =============================================================================
// sf_pcie_interrupt_adapter -- interrupt status / masking and the endpoint's MSI request interface.
//
// Sources (sticky status bits, W1C): DMA record queued, DMA error, bridge error, recovery, StreamDMA irq line, 3 external.
// A source whose (status & mask) bit RISES requests the MSI vector it is mapped to (IRQ_VECMAP, folded to the number
// of vectors the host enabled).  Requests are edge-triggered per vector and coalesce while one is pending.
//
// MSI delivery is requested through the endpoint's MSI request interface (cfg_interrupt_msi_* of the AMD UltraScale+
// block: a one-hot request vector held until `sent` or `fail`).  THIS INTERFACE IS NOT VERIFIED AGAINST REAL IP; with
// IRQ_CTRL.MSI_EN = 0 (or MSI disabled by the host) the adapter runs in POLLING-ONLY mode: nothing is requested, the
// host polls IRQ_STATUS, and irq_level is available for an INTx-capable endpoint.  MSI-X is NOT implemented (it
// needs a user-logic vector table in BAR space; see docs/06_INTERRUPTS.md).
//
// ORDERING: an interrupt must not overtake the posted writes it announces (e.g. DMA data -> "done" interrupt).  A
// granted vector is held until the endpoint has acknowledged every RQ TLP that had been handed over at grant time.
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
`include "sf_pcie_regs.svh"
module sf_pcie_interrupt_adapter #(
  parameter int NVEC  = 16,
  parameter int ORD_W = 8
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              soft_rst,
  // register access (CSR pass-through)
  input  wire logic              wr_valid,
  /* verilator lint_off UNUSEDSIGNAL */  // registers are dword aligned
  input  wire logic [7:0]        wr_addr,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [31:0]       wr_data,
  input  wire logic [3:0]        wr_strb,
  /* verilator lint_off UNUSEDSIGNAL */  // registers are dword aligned
  input  wire logic [7:0]        rd_addr,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [31:0]            rd_data,
  // event sources (one-cycle pulses)
  input  wire logic [`SFPB_IS_N-1:0] ev,
  // endpoint MSI request interface
  input  wire logic              msi_enable,
  input  wire logic [2:0]        msi_mmenable,         // log2(vectors the host enabled)
  output logic [31:0]            msi_int,
  input  wire logic              msi_sent,
  input  wire logic              msi_fail,
  // posted-write ordering gate
  input  wire logic [ORD_W-1:0]  ord_issued,
  input  wire logic [ORD_W-1:0]  ord_acked,
  output logic                   ord_stall,
  // outputs
  output logic                   irq_pending,          // (status & mask) != 0
  output logic                   irq_level,            // INTx-style level
  output logic                   ev_fail_valid,        // MSI gave up: report to the error log
  output logic [5:0]             ev_fail_code
);
  localparam int NS = `SFPB_IS_N;
  localparam int VW = $clog2(NVEC);
  logic [NS-1:0] status, mask, act_q;
  logic [31:0]   vecmap;
  /* verilator lint_off UNUSEDSIGNAL */  // the retry limit lives in the low nibble
  logic [7:0]    ctrl_retry;
  /* verilator lint_on UNUSEDSIGNAL */
  logic          ctrl_msi;
  logic [15:0]   fail_cnt, sent_cnt;
  logic [NVEC-1:0] vp;                                  // vector pending latches

  function automatic logic [31:0] merge(input logic [31:0] old, input logic [31:0] nw, input logic [3:0] st);
    merge = {st[3] ? nw[31:24] : old[31:24], st[2] ? nw[23:16] : old[23:16], st[1] ? nw[15:8] : old[15:8], st[0] ? nw[7:0] : old[7:0]};
  endfunction

  /* verilator lint_off UNUSEDSIGNAL */  // only NS mask bits exist
  wire [31:0]   mask_m = merge({{(32-NS){1'b0}}, mask}, wr_data, wr_strb);
  /* verilator lint_on UNUSEDSIGNAL */
  wire [NS-1:0] act  = status & mask;
  wire [NS-1:0] rise = act & ~act_q;
  assign irq_pending = |act;
  assign irq_level   = |act;

  // folded vector of every source
  logic [3:0] vec_of [0:NS-1];
  always_comb begin
    for (int s = 0; s < NS; s++) begin
      vec_of[s] = vecmap[s*4 +: 4] & ((msi_mmenable >= 3'd4) ? 4'hF : (4'hF >> (3'd4 - msi_mmenable)));
    end
  end

  // ---- registers ---------------------------------------------------------------------------------------------------
  always_comb begin
    rd_data = 32'd0;
    case ({rd_addr[7:2], 2'b00})
      8'(`SFPB_R_IRQ_STATUS):    rd_data = {{(32-NS){1'b0}}, status};
      8'(`SFPB_R_IRQ_MASK):      rd_data = {{(32-NS){1'b0}}, mask};
      8'(`SFPB_R_IRQ_VECMAP):    rd_data = vecmap;
      8'(`SFPB_R_IRQ_CTRL):      rd_data = {24'd0, ctrl_retry[3:0], 3'd0, ctrl_msi};
      8'(`SFPB_R_IRQ_FAIL_CNT):  rd_data = {16'd0, fail_cnt};
      8'(`SFPB_R_IRQ_SENT_CNT):  rd_data = {16'd0, sent_cnt};
      default:                   rd_data = 32'd0;
    endcase
  end

  // ---- MSI engine ----------------------------------------------------------------------------------------------------
  localparam logic [1:0] M_IDLE = 2'd0, M_ORD = 2'd1, M_SEND = 2'd2;
  logic [1:0]   m_st;
  logic [4:0]   m_vec;
  logic [ORD_W-1:0] m_snap;
  logic [3:0]   m_try;
  logic [4:0]   rrp;                                    // round-robin pointer
  logic [4:0]   pick; logic pick_v;
  wire          msi_on = ctrl_msi && msi_enable;

  always_comb begin
    pick_v = 1'b0; pick = '0;
    for (int j = NVEC - 1; j >= 0; j--) begin                      // first pending vector at or after the pointer, wrapping around
      logic [5:0] idx;
      idx = {1'b0, rrp} + 6'(j);
      if (idx >= 6'(NVEC)) idx = idx - 6'(NVEC);
      if (vp[idx[VW-1:0]]) begin pick_v = 1'b1; pick = idx[4:0]; end
    end
  end

  wire [ORD_W-1:0] diff = ord_acked - m_snap;
  wire             gate_ok = !diff[ORD_W-1];
  assign ord_stall = (m_st == M_ORD) && !gate_ok;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      status <= '0; mask <= '0; act_q <= '0; vecmap <= 32'h7654_3210; ctrl_retry <= 8'h03; ctrl_msi <= 1'b1;
      fail_cnt <= '0; sent_cnt <= '0; vp <= '0; m_st <= M_IDLE; m_vec <= '0; m_snap <= '0; m_try <= '0; rrp <= '0;
      msi_int <= '0; ev_fail_valid <= 1'b0; ev_fail_code <= `SFPB_E_NONE;
    end else begin
      ev_fail_valid <= 1'b0;
      act_q <= act;
      if (soft_rst) begin mask <= '0; vecmap <= 32'h7654_3210; ctrl_msi <= 1'b1; ctrl_retry <= 8'h03; end

      // status: sticky set by events, cleared by W1C
      status <= status | ev;
      if (wr_valid) begin
        case ({wr_addr[7:2], 2'b00})
          8'(`SFPB_R_IRQ_STATUS): if (wr_strb[0]) status <= (status & ~wr_data[NS-1:0]) | ev;   // an event in the same cycle survives the clear
          8'(`SFPB_R_IRQ_MASK):   mask <= mask_m[NS-1:0];
          8'(`SFPB_R_IRQ_VECMAP): vecmap <= merge(vecmap, wr_data, wr_strb);
          8'(`SFPB_R_IRQ_CTRL):   begin
            if (wr_strb[0]) begin ctrl_msi <= wr_data[0]; ctrl_retry[3:0] <= wr_data[7:4]; end
          end
          8'(`SFPB_R_IRQ_SET):    if (wr_strb[0]) status <= status | ev | wr_data[NS-1:0];
          default: ;
        endcase
      end

      // vector pending: rising (status & mask) requests its vector
      for (int s = 0; s < NS; s++) if (rise[s] && (32'(vec_of[s]) < NVEC)) vp[vec_of[s][VW-1:0]] <= 1'b1;

      case (m_st)
        M_IDLE: if (msi_on && pick_v) begin
          m_vec <= pick; vp[pick[VW-1:0]] <= 1'b0; m_snap <= ord_issued; m_try <= '0; m_st <= M_ORD;
          rrp <= (pick + 5'd1 >= 5'(NVEC)) ? 5'd0 : pick + 5'd1;
        end
        M_ORD: begin
          if (!msi_on) begin vp[m_vec[VW-1:0]] <= 1'b1; m_st <= M_IDLE; end
          else if (gate_ok) begin msi_int <= 32'd1 << m_vec; m_st <= M_SEND; end
        end
        M_SEND: begin
          if (!msi_on) begin msi_int <= '0; vp[m_vec[VW-1:0]] <= 1'b1; m_st <= M_IDLE; end
          else if (msi_sent) begin msi_int <= '0; sent_cnt <= sent_cnt + 16'd1; m_st <= M_IDLE; end
          else if (msi_fail) begin
            msi_int <= '0; fail_cnt <= fail_cnt + 16'd1;
            if (m_try + 4'd1 > ctrl_retry[3:0]) begin
              m_st <= M_IDLE; ev_fail_valid <= 1'b1; ev_fail_code <= `SFPB_E_IRQ_FAIL;     // give up: reported, never silent
            end else begin m_try <= m_try + 4'd1; m_st <= M_ORD; end
          end
        end
        default: m_st <= M_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
