// =============================================================================
// sf_pcie_dma_ctx -- trusted DMA context table + privileged configuration port.
//
// A context is the unit of DMA authority: {valid, permitted directions, host IOVA window (+ optional constant-offset
// translation), device-side window, maximum transfer length}.  The context index IS the StreamDMA trusted domain.
//
// Trust anchor: the table can only be written through the privileged port `priv_*` (to be connected to ControlCore /
// the secure side of the chip); the host BAR has no path to it.  Entries are written into a staging copy and
// published atomically by COMMIT -- refused while any DMA request is outstanding ("quiesce before unmapping"), when
// the table is locked, or when the entry is inconsistent.  PRIV_CTRL.LOCK freezes the table until reset.
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
`include "sf_pcie_regs.svh"
module sf_pcie_dma_ctx #(
  parameter int NCTX = 4
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          quiescent,           // no DMA request outstanding anywhere
  // privileged port (SFB2 style: one response, one cycle after the request)
  input  wire logic          priv_req_valid,
  output logic               priv_req_ready,
  input  wire logic          priv_req_write,
  /* verilator lint_off UNUSEDSIGNAL */  // registers are dword aligned
  input  wire logic [11:0]   priv_req_addr,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [31:0]   priv_req_wdata,
  output logic               priv_rsp_valid,
  input  wire logic          priv_rsp_ready,
  output logic [31:0]        priv_rsp_rdata,
  output logic               priv_rsp_error,
  // lookup ports (combinational)
  input  wire logic [3:0]    a_ctx,
  output logic               a_valid, a_rd_ok, a_wr_ok, a_xlat,
  output logic [63:0]        a_iova_base, a_iova_size, a_bus_base, a_dev_base, a_dev_size,
  output logic [31:0]        a_max_len,
  input  wire logic [3:0]    b_ctx,
  output logic               b_valid, b_rd_ok, b_wr_ok, b_xlat,
  output logic [63:0]        b_iova_base, b_iova_size, b_bus_base, b_dev_base, b_dev_size,
  output logic [31:0]        b_max_len,
  input  wire logic [3:0]    c_ctx,                // read-only info port for the host-visible CTX_INFO register
  output logic [3:0]         c_info                // {xlat, wr_ok, rd_ok, valid}
);
  generate
    if (NCTX < 1 || NCTX > 15) begin : g_chk
      sf_pcie_dma_ctx_NCTX_must_be_1_15 u_err ();
    end
  endgenerate

  // staging and live copies
  logic        s_valid [0:NCTX-1], s_rd [0:NCTX-1], s_wr [0:NCTX-1], s_xl [0:NCTX-1];
  logic [63:0] s_ib [0:NCTX-1], s_is [0:NCTX-1], s_bb [0:NCTX-1], s_db [0:NCTX-1], s_ds [0:NCTX-1];
  logic [31:0] s_ml [0:NCTX-1];
  logic        l_valid [0:NCTX-1], l_rd [0:NCTX-1], l_wr [0:NCTX-1], l_xl [0:NCTX-1];
  logic [63:0] l_ib [0:NCTX-1], l_is [0:NCTX-1], l_bb [0:NCTX-1], l_db [0:NCTX-1], l_ds [0:NCTX-1];
  logic [31:0] l_ml [0:NCTX-1];
  logic        commit_ok [0:NCTX-1];
  logic [3:0]  commit_code [0:NCTX-1];
  logic        locked;

  // ---- lookups -----------------------------------------------------------------------------------------------------
  always_comb begin
    a_valid = 1'b0; a_rd_ok = 1'b0; a_wr_ok = 1'b0; a_xlat = 1'b0; a_iova_base = '0; a_iova_size = '0; a_bus_base = '0;
    a_dev_base = '0; a_dev_size = '0; a_max_len = '0;
    b_valid = 1'b0; b_rd_ok = 1'b0; b_wr_ok = 1'b0; b_xlat = 1'b0; b_iova_base = '0; b_iova_size = '0; b_bus_base = '0;
    b_dev_base = '0; b_dev_size = '0; b_max_len = '0;
    c_info = 4'd0;
    for (int i = 0; i < NCTX; i++) begin
      if (a_ctx == 4'(i)) begin
        a_valid = l_valid[i]; a_rd_ok = l_rd[i]; a_wr_ok = l_wr[i]; a_xlat = l_xl[i]; a_iova_base = l_ib[i]; a_iova_size = l_is[i];
        a_bus_base = l_bb[i]; a_dev_base = l_db[i]; a_dev_size = l_ds[i]; a_max_len = l_ml[i];
      end
      if (b_ctx == 4'(i)) begin
        b_valid = l_valid[i]; b_rd_ok = l_rd[i]; b_wr_ok = l_wr[i]; b_xlat = l_xl[i]; b_iova_base = l_ib[i]; b_iova_size = l_is[i];
        b_bus_base = l_bb[i]; b_dev_base = l_db[i]; b_dev_size = l_ds[i]; b_max_len = l_ml[i];
      end
      if (c_ctx == 4'(i)) c_info = {l_xl[i], l_wr[i], l_rd[i], l_valid[i]};
    end
  end

  // ---- privileged port -----------------------------------------------------------------------------------------------
  assign priv_req_ready = !priv_rsp_valid || priv_rsp_ready;
  wire        req_fire = priv_req_valid && priv_req_ready;
  wire [3:0]  pc       = priv_req_addr[9:6];                   // context index (ctx * 0x40)
  wire [5:0]  po       = {priv_req_addr[5:2], 2'b00};          // register offset inside the entry
  wire        wa_ctrl  = ({priv_req_addr[11:2], 2'b00} == `SFPB_P_PRIV_CTRL);
  wire        wa_stat  = ({priv_req_addr[11:2], 2'b00} == `SFPB_P_PRIV_STATUS);
  wire        in_tab   = (priv_req_addr[11:10] == 2'b00) && (32'(pc) < NCTX);

  // consistency of the staged entry `pc`
  logic        chk_ok; logic [3:0] chk_code;
  /* verilator lint_off UNUSEDSIGNAL */  // only the carry-out bit is examined
  logic [64:0] ib_end, db_end;
  /* verilator lint_on UNUSEDSIGNAL */
  always_comb begin
    chk_ok = 1'b1; chk_code = 4'd0; ib_end = '0; db_end = '0;
    for (int i = 0; i < NCTX; i++) begin
      if (pc == 4'(i)) begin
        ib_end = {1'b0, s_ib[i]} + {1'b0, s_is[i]};
        db_end = {1'b0, s_db[i]} + {1'b0, s_ds[i]};
        if (locked)                                                   begin chk_ok = 1'b0; chk_code = 4'd4; end
        else if (!quiescent)                                          begin chk_ok = 1'b0; chk_code = 4'd1; end
        else if (s_valid[i]) begin
          if ((s_bb[i][1:0] != s_ib[i][1:0]) && s_xl[i])              begin chk_ok = 1'b0; chk_code = 4'd2; end
          else if (ib_end[64] || db_end[64] || s_is[i] == 64'd0)      begin chk_ok = 1'b0; chk_code = 4'd3; end
        end
      end
    end
  end

  logic [31:0] rdata;
  always_comb begin
    rdata = 32'd0;
    if (wa_ctrl)   rdata = {31'd0, locked};
    else if (wa_stat) rdata = {30'd0, quiescent, locked};
    else if (in_tab) begin
      for (int i = 0; i < NCTX; i++) begin
        if (pc == 4'(i)) begin
          case (po)
            `SFPB_P_CTX_CTRL:      rdata = {28'd0, s_xl[i], s_wr[i], s_rd[i], s_valid[i]};
            `SFPB_P_IOVA_BASE_LO:  rdata = s_ib[i][31:0];
            `SFPB_P_IOVA_BASE_HI:  rdata = s_ib[i][63:32];
            `SFPB_P_IOVA_SIZE_LO:  rdata = s_is[i][31:0];
            `SFPB_P_IOVA_SIZE_HI:  rdata = s_is[i][63:32];
            `SFPB_P_BUS_BASE_LO:   rdata = s_bb[i][31:0];
            `SFPB_P_BUS_BASE_HI:   rdata = s_bb[i][63:32];
            `SFPB_P_DEV_BASE_LO:   rdata = s_db[i][31:0];
            `SFPB_P_DEV_BASE_HI:   rdata = s_db[i][63:32];
            `SFPB_P_DEV_SIZE_LO:   rdata = s_ds[i][31:0];
            `SFPB_P_DEV_SIZE_HI:   rdata = s_ds[i][63:32];
            `SFPB_P_MAX_LEN:       rdata = s_ml[i];
            `SFPB_P_COMMIT_STATUS: rdata = {24'd0, commit_code[i], 3'd0, commit_ok[i]};
            default:               rdata = 32'd0;
          endcase
        end
      end
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      priv_rsp_valid <= 1'b0; priv_rsp_rdata <= '0; priv_rsp_error <= 1'b0; locked <= 1'b0;
      for (int i = 0; i < NCTX; i++) begin
        s_valid[i] <= 1'b0; s_rd[i] <= 1'b0; s_wr[i] <= 1'b0; s_xl[i] <= 1'b0; s_ib[i] <= '0; s_is[i] <= '0; s_bb[i] <= '0;
        s_db[i] <= '0; s_ds[i] <= '0; s_ml[i] <= '0;
        l_valid[i] <= 1'b0; l_rd[i] <= 1'b0; l_wr[i] <= 1'b0; l_xl[i] <= 1'b0; l_ib[i] <= '0; l_is[i] <= '0; l_bb[i] <= '0;
        l_db[i] <= '0; l_ds[i] <= '0; l_ml[i] <= '0; commit_ok[i] <= 1'b0; commit_code[i] <= 4'd0;
      end
    end else begin
      if (priv_rsp_valid && priv_rsp_ready) priv_rsp_valid <= 1'b0;
      if (req_fire) begin
        priv_rsp_valid <= 1'b1; priv_rsp_rdata <= priv_req_write ? 32'd0 : rdata; priv_rsp_error <= 1'b0;
        if (wa_ctrl) begin
          if (priv_req_write && priv_req_wdata[0]) locked <= 1'b1;             // set-only
        end else if (wa_stat) begin
          if (priv_req_write) priv_rsp_error <= 1'b1;
        end else if (!in_tab) begin
          priv_rsp_error <= 1'b1;
        end else if (priv_req_write) begin
          for (int i = 0; i < NCTX; i++) begin
            if (pc == 4'(i)) begin
              case (po)
                `SFPB_P_CTX_CTRL:      begin s_valid[i] <= priv_req_wdata[0]; s_rd[i] <= priv_req_wdata[1]; s_wr[i] <= priv_req_wdata[2]; s_xl[i] <= priv_req_wdata[3]; end
                `SFPB_P_IOVA_BASE_LO:  s_ib[i][31:0]  <= priv_req_wdata;
                `SFPB_P_IOVA_BASE_HI:  s_ib[i][63:32] <= priv_req_wdata;
                `SFPB_P_IOVA_SIZE_LO:  s_is[i][31:0]  <= priv_req_wdata;
                `SFPB_P_IOVA_SIZE_HI:  s_is[i][63:32] <= priv_req_wdata;
                `SFPB_P_BUS_BASE_LO:   s_bb[i][31:0]  <= priv_req_wdata;
                `SFPB_P_BUS_BASE_HI:   s_bb[i][63:32] <= priv_req_wdata;
                `SFPB_P_DEV_BASE_LO:   s_db[i][31:0]  <= priv_req_wdata;
                `SFPB_P_DEV_BASE_HI:   s_db[i][63:32] <= priv_req_wdata;
                `SFPB_P_DEV_SIZE_LO:   s_ds[i][31:0]  <= priv_req_wdata;
                `SFPB_P_DEV_SIZE_HI:   s_ds[i][63:32] <= priv_req_wdata;
                `SFPB_P_MAX_LEN:       s_ml[i]        <= priv_req_wdata;
                `SFPB_P_COMMIT: begin
                  if (priv_req_wdata[0]) begin
                    commit_ok[i] <= chk_ok; commit_code[i] <= chk_code;
                    if (chk_ok) begin
                      l_valid[i] <= s_valid[i]; l_rd[i] <= s_rd[i]; l_wr[i] <= s_wr[i]; l_xl[i] <= s_xl[i];
                      l_ib[i] <= s_ib[i]; l_is[i] <= s_is[i]; l_bb[i] <= s_bb[i]; l_db[i] <= s_db[i]; l_ds[i] <= s_ds[i];
                      l_ml[i] <= s_ml[i];
                    end
                  end
                end
                default: priv_rsp_error <= 1'b1;
              endcase
            end
          end
        end else if (po == `SFPB_P_COMMIT) begin
          priv_rsp_error <= 1'b1;                                               // write-only register read
        end
      end
    end
  end
endmodule
`default_nettype wire
