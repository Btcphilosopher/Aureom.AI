// =============================================================================
// sf_pcie_mmio_engine -- request classification + in-order MMIO execution + completion generation.
//
// One request TLP is handled at a time, strictly in arrival order.  That single rule gives the PCIe ordering the
// supported subset needs: posted writes are performed in order; a read never passes an earlier write (the write has
// been performed -- its SFB2 response seen, rule R7 -- before the next request is looked at); completions are
// generated in request order.
//
// Classification (see docs/04_ORDERING_AND_ERRORS.md):
//   memory read / write ........................ executed
//   I/O, atomic, locked read (non-posted) ...... Completion UR, no data            (SFPB_E_UNSUP_TYPE)
//   messages and anything else (posted) ........ dropped, logged                   (SFPB_E_UNSUP_TYPE)
//   adapter-rejected (malformed) TLP ........... dropped, logged, NO completion    (PCIe: malformed TLPs are not completed)
//   poisoned / AT != 0 / TC != 0 / BAR error ... non-posted: UR;  posted: dropped, logged
//   fabric port fatal .......................... non-posted: CA;  posted: dropped, logged
//   SFB2 error on a read ........................ Completion CA, no data
//   SFB2 error on a write ....................... logged (posted writes have no completion)
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
module sf_pcie_mmio_engine #(
  parameter int DATA_W      = 256,
  parameter int MMIO_MAX_DW = 64,
  parameter int CPL_MAX_DW  = 32,           // largest completion payload (dwords); <= 32 keeps splits RCB-128 aligned
  parameter int SFB_MAX_OUT = 2,
  parameter int NCTX        = 4,
  parameter int BAR_REG_ID  = 0,
  parameter int BAR_REG_AP  = 16,
  parameter int BAR_MEM_ID  = 2,
  parameter int BAR_MEM_AP  = 20,
  parameter int FREG_OFF    = 32'h8000,
  parameter int FREG_SIZE   = 32'h8000,
  parameter logic [31:0] SFB_REG_BASE = 32'h4000_0000,
  parameter logic [31:0] SFB_MEM_BASE = 32'h8000_0000,
  localparam int K          = DATA_W / 32,
  localparam int NW         = $clog2(K + 1)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              flush,
  // validated request channel
  input  wire logic              req_valid,
  output logic                   req_ready,
  input  wire logic [3:0]        req_type,
  input  wire logic [63:0]       req_addr,
  input  wire logic [10:0]       req_ndw,
  input  wire logic [3:0]        req_first_be,
  input  wire logic [3:0]        req_last_be,
  input  wire logic [7:0]        req_tag,
  input  wire logic [15:0]       req_reqid,
  input  wire logic [2:0]        req_tc,
  input  wire logic [2:0]        req_attr,
  input  wire logic [1:0]        req_at,
  input  wire logic              req_poison,
  input  wire logic [2:0]        req_bar_id,
  input  wire logic [5:0]        req_bar_ap,
  input  wire logic              req_bad,
  input  wire logic [5:0]        req_code,
  input  wire logic              req_has_pay,
  input  wire logic              pay_valid,
  output logic                   pay_ready,
  input  wire logic [DATA_W-1:0] pay_data,
  input  wire logic [NW-1:0]     pay_ndw,
  input  wire logic              pay_last,
  // completion beat stream (to sf_pcie_completion_adapter)
  output logic                   cpl_valid,
  input  wire logic              cpl_ready,
  output logic                   cpl_sop,
  output logic                   cpl_eop,
  output logic [DATA_W-1:0]      cpl_data,
  output logic [NW-1:0]          cpl_ndw,
  output logic [2:0]             cpl_status,
  output logic [6:0]             cpl_lower,
  output logic [12:0]            cpl_bytecnt,
  output logic [10:0]            cpl_dwcnt,
  output logic [15:0]            cpl_reqid,
  output logic [7:0]             cpl_tag,
  output logic [2:0]             cpl_tc,
  output logic [2:0]             cpl_attr,
  // register block (global CSR page and DMA submission pages)
  output logic                   csr_wr_valid,
  output logic [15:0]            csr_wr_addr,
  output logic [31:0]            csr_wr_data,
  output logic [3:0]             csr_wr_strb,
  input  wire logic              csr_wr_err,          // same cycle as csr_wr_valid
  output logic                   csr_rd_valid,
  output logic [15:0]            csr_rd_addr,
  input  wire logic              csr_rd_dvalid,       // one cycle after csr_rd_valid
  input  wire logic [31:0]       csr_rd_data,
  input  wire logic              csr_rd_err,
  // SFB2 master (DataFabric)
  output logic                   sfb_req_valid,
  input  wire logic              sfb_req_ready,
  output logic                   sfb_req_write,
  output logic [31:0]            sfb_req_addr,
  output logic [31:0]            sfb_req_wdata,
  output logic [3:0]             sfb_req_wstrb,
  input  wire logic              sfb_rsp_valid,
  output logic                   sfb_rsp_ready,
  input  wire logic [31:0]       sfb_rsp_rdata,
  input  wire logic              sfb_rsp_error,
  // control / configuration
  input  wire logic              cfg_fwin_rd_en,
  input  wire logic              cfg_fwin_wr_en,
  input  wire logic              cfg_tc_any,
  input  wire logic [31:0]       cfg_sfb_timeout,
  input  wire logic [10:0]       cfg_mps_dw,
  input  wire logic              fatal_clr,
  // status / events
  output logic                   st_fatal,
  output logic                   idle,                 // nothing in flight (flush may complete)
  output logic                   ev_err_valid,
  output logic [5:0]             ev_err_code,
  output logic [63:0]            ev_err_addr,
  output logic [7:0]             ev_err_tag,
  output logic [15:0]            ev_err_reqid,
  output logic [3:0]             ev_err_type,
  output logic                   ev_rd_valid,          // pulse: first completion beat of a read accepted
  output logic [15:0]            ev_rd_lat,
  output logic                   ev_wr_valid,          // pulse: write fully performed
  output logic [15:0]            ev_wr_lat,
  output logic                   ev_exec_rd,           // pulse per executed memory read / write (statistics)
  output logic                   ev_exec_wr
);
  generate
    if (MMIO_MAX_DW < 2 || MMIO_MAX_DW > 1024) begin : g_chk_max
      sf_pcie_mmio_engine_MMIO_MAX_DW_out_of_range u_err ();
    end
    if (CPL_MAX_DW < 1 || CPL_MAX_DW > 32) begin : g_chk_cpl
      sf_pcie_mmio_engine_CPL_MAX_DW_must_be_1_32 u_err ();
    end
    if (SFB_MAX_OUT < 1 || SFB_MAX_OUT > 8) begin : g_chk_out
      sf_pcie_mmio_engine_SFB_MAX_OUT_must_be_1_8 u_err ();
    end
  endgenerate

  // ---- states ----------------------------------------------------------------------------------------------------
  localparam logic [3:0] S_IDLE = 4'd0, S_DRAIN = 4'd2, S_WR = 4'd3, S_WR_WAIT = 4'd4, S_RD = 4'd5,
                         S_CPL = 4'd6, S_CPL_ERR = 4'd7, S_FLUSH = 4'd8;
  localparam logic [1:0] A_EXEC = 2'd0, A_DROP = 2'd1, A_UR = 2'd2, A_CA = 2'd3;

  logic [3:0]  state;

  // latched header
  logic [3:0]  h_type; logic [63:0] h_addr; logic [10:0] h_ndw; logic [3:0] h_fbe, h_lbe; logic [7:0] h_tag;
  logic [15:0] h_rid; logic [2:0] h_tc, h_attr;
  logic [2:0]  h_tgt; logic [15:0] h_off; logic [31:0] h_sfb;
  logic [1:0]  h_after;                         // action to take after the payload has been drained
  logic [15:0] lat;

  // ---- BAR decode of the *incoming* (not yet latched) header: one decoder serves both ----------------------------
  logic [5:0]  d_err; logic [2:0] d_tgt; logic [15:0] d_off; logic [31:0] d_sfb;
  sf_pcie_bar_decoder #(.NCTX(NCTX), .BAR_REG_ID(BAR_REG_ID), .BAR_REG_AP(BAR_REG_AP), .BAR_MEM_ID(BAR_MEM_ID),
                        .BAR_MEM_AP(BAR_MEM_AP), .FREG_OFF(FREG_OFF), .FREG_SIZE(FREG_SIZE), .MMIO_MAX_DW(MMIO_MAX_DW),
                        .SFB_REG_BASE(SFB_REG_BASE), .SFB_MEM_BASE(SFB_MEM_BASE)) u_bar (
    .bar_id(req_bar_id), .bar_ap(req_bar_ap), .addr(req_addr), .ndw(req_ndw), .is_write(req_type == `SFPB_RT_MEM_WR),
    .cfg_fwin_rd_en(cfg_fwin_rd_en), .cfg_fwin_wr_en(cfg_fwin_wr_en),
    .err(d_err), .tgt(d_tgt), .off(d_off), .sfb_addr(d_sfb));

  // classification of the incoming header (combinational; registered into h_* with the header)
  logic        nonposted, is_mrd, is_mwr, fab_tgt;
  logic [1:0]  d_act;
  logic [5:0]  d_code;
  always_comb begin
    is_mrd    = (req_type == `SFPB_RT_MEM_RD);
    is_mwr    = (req_type == `SFPB_RT_MEM_WR);
    nonposted = (req_type <= `SFPB_RT_MEM_RD_LOCK) && !is_mwr;
    fab_tgt   = (d_tgt == `SFPB_TGT_FREG) || (d_tgt == `SFPB_TGT_FMEM);
    d_act     = A_EXEC; d_code = `SFPB_E_NONE;
    if (req_bad) begin
      d_act = A_DROP; d_code = req_code;
    end else if (!is_mrd && !is_mwr) begin
      d_code = `SFPB_E_UNSUP_TYPE; d_act = nonposted ? A_UR : A_DROP;
    end else if (req_poison) begin
      d_code = `SFPB_E_POISONED_REQ; d_act = is_mrd ? A_UR : A_DROP;
    end else if (req_at != 2'b00) begin
      d_code = `SFPB_E_UNSUP_AT; d_act = is_mrd ? A_UR : A_DROP;
    end else if ((req_tc != 3'd0) && !cfg_tc_any) begin
      d_code = `SFPB_E_UNSUP_TC; d_act = is_mrd ? A_UR : A_DROP;
    end else if (d_err != `SFPB_E_NONE) begin
      d_code = d_err; d_act = is_mrd ? A_UR : A_DROP;
    end else if (fab_tgt && st_fatal) begin
      d_code = `SFPB_E_FAB_FATAL; d_act = is_mrd ? A_CA : A_DROP;
    end
  end

  // ---- BE helpers ------------------------------------------------------------------------------------------------
  function automatic logic [1:0] lo_idx(input logic [3:0] be);       // lowest enabled byte (0 if none)
    if (be[0]) lo_idx = 2'd0; else if (be[1]) lo_idx = 2'd1; else if (be[2]) lo_idx = 2'd2; else if (be[3]) lo_idx = 2'd3; else lo_idx = 2'd0;
  endfunction
  /* verilator lint_off UNUSEDSIGNAL */
  function automatic logic [1:0] hi_idx(input logic [3:0] be);       // highest enabled byte (0 if none)
    if (be[3]) hi_idx = 2'd3; else if (be[2]) hi_idx = 2'd2; else if (be[1]) hi_idx = 2'd1; else hi_idx = 2'd0;
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */

  wire [1:0]  lo_off = lo_idx(h_fbe);
  wire        zero_len = (h_ndw == 11'd1) && (h_fbe == 4'b0000);
  logic [12:0] tot_bytes;
  always_comb begin
    if (zero_len)               tot_bytes = 13'd1;
    else if (h_ndw == 11'd1)    tot_bytes = 13'(hi_idx(h_fbe)) - 13'(lo_idx(h_fbe)) + 13'd1;
    else                        tot_bytes = {h_ndw, 2'b00} - 13'(lo_idx(h_fbe)) - (13'd3 - 13'(hi_idx(h_lbe)));
  end

  // ---- SFB2 port block: one presented request, in-order response accounting --------------------------------------
  logic        sq_valid;                          // request presented
  logic        sq_write; logic [31:0] sq_addr, sq_wdata; logic [3:0] sq_wstrb;
  logic [3:0]  pend;                              // accepted, response not yet seen
  logic [31:0] tmo;                               // cycles without progress while something is owed
  logic        issue;                             // pulse from the FSM: load a new request into the port
  logic        issue_write; logic [31:0] issue_addr, issue_wdata; logic [3:0] issue_strb;
  wire         sq_fire  = sq_valid && sfb_req_ready;
  wire         rsp_fire = sfb_rsp_valid;           // sfb_rsp_ready is constant 1
  wire         port_free = !sq_valid || sfb_req_ready;
  wire         can_issue = port_free && (pend + {3'd0, sq_valid && !sfb_req_ready} < 4'(SFB_MAX_OUT)) && !st_fatal;
  wire         owed = sq_valid || (pend != 4'd0);

  assign sfb_req_valid = sq_valid;
  assign sfb_req_write = sq_write;
  assign sfb_req_addr  = sq_addr;
  assign sfb_req_wdata = sq_wdata;
  assign sfb_req_wstrb = sq_wstrb;
  assign sfb_rsp_ready = 1'b1;

  logic        tmo_hit;
  assign tmo_hit = (cfg_sfb_timeout != 32'd0) && owed && (tmo >= cfg_sfb_timeout);

  // response collection (for reads)
  logic [31:0] rdbuf [0:MMIO_MAX_DW-1];
  logic [10:0] rsp_idx;                           // next rdbuf slot a response fills
  logic        rd_err, wr_err;
  logic [10:0] req_idx;                           // dwords issued so far in this operation
  logic        want_rsp_data;                     // responses belong to the running read (not discarded)

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sq_valid <= 1'b0; sq_write <= 1'b0; sq_addr <= '0; sq_wdata <= '0; sq_wstrb <= '0; pend <= '0; tmo <= '0;
      st_fatal <= 1'b0;
    end else begin
      if (sq_fire) sq_valid <= 1'b0;
      if (issue) begin
        sq_valid <= 1'b1; sq_write <= issue_write; sq_addr <= issue_addr; sq_wdata <= issue_wdata; sq_wstrb <= issue_strb;
      end
      pend <= pend + {3'd0, sq_fire} - {3'd0, rsp_fire && (pend != 4'd0)};
      // watchdog: progress = a request accepted or a response seen
      if (!owed || sq_fire || rsp_fire) tmo <= '0; else if (!(&tmo)) tmo <= tmo + 1'b1;
      if (tmo_hit) st_fatal <= 1'b1;
      if (fatal_clr && !owed) st_fatal <= 1'b0;
    end
  end

  // ---- completion generation state ------------------------------------------------------------------------------
  logic [10:0] cp_done;                           // dwords already completed
  logic [12:0] cp_sent;                           // bytes already completed
  logic [10:0] cp_chunk;                          // dwords in the current completion
  logic [10:0] cp_beat;                           // beat index inside the current completion
  logic        cp_first;
  logic        cp_started;                        // chunk size latched
  logic [2:0]  cp_status;                         // status of the error completion
  logic        lat_done;

  wire  [10:0] cp_rem   = h_ndw - cp_done;
  wire  [10:0] cp_eff   = (cfg_mps_dw < 11'(CPL_MAX_DW)) ? cfg_mps_dw : 11'(CPL_MAX_DW);
  wire  [4:0]  cp_pos   = h_addr[6:2] + cp_done[4:0];
  wire  [10:0] cp_tobnd = 11'd32 - {6'd0, cp_pos};
  logic [10:0] cp_next_chunk;
  always_comb begin
    if (cp_rem <= cp_eff)            cp_next_chunk = cp_rem;
    else if (cp_tobnd < cp_eff)      cp_next_chunk = cp_tobnd;
    else                             cp_next_chunk = cp_eff;
  end
  wire  [10:0] cp_c = cp_started ? cp_chunk : cp_next_chunk;     // chunk size valid combinationally from the first cycle

  int          ix;
  logic [10:0] beat_base;
  logic [10:0] beat_left;
  always_comb begin
    beat_base = cp_done + cp_beat * 11'(K);
    beat_left = cp_c - cp_beat * 11'(K);
  end

  // completion beat outputs
  logic cpl_err_mode;
  assign cpl_err_mode = (state == S_CPL_ERR);
  always_comb begin
    cpl_valid  = (state == S_CPL) || (state == S_CPL_ERR);
    cpl_sop    = cpl_err_mode ? 1'b1 : (cp_beat == 11'd0);
    cpl_eop    = cpl_err_mode ? 1'b1 : (beat_left <= 11'(K));
    cpl_ndw    = cpl_err_mode ? '0 : ((beat_left >= 11'(K)) ? NW'(K) : NW'(beat_left));
    cpl_status = cpl_err_mode ? cp_status : `SFPB_CPL_SC;
    cpl_lower  = cpl_err_mode ? h_addr[6:0] : (cp_first ? {h_addr[6:2], lo_off} : {h_addr[6:2] + cp_done[4:0], 2'b00});
    cpl_bytecnt= cpl_err_mode ? 13'd4 : (tot_bytes - cp_sent);
    cpl_dwcnt  = cpl_err_mode ? 11'd0 : cp_c;
    cpl_reqid  = h_rid; cpl_tag = h_tag; cpl_tc = h_tc; cpl_attr = h_attr;
    cpl_data   = '0;
    ix = 0;
    if (!cpl_err_mode) begin
      for (int i = 0; i < K; i++) begin
        ix = 32'(beat_base) + i;
        if (i < 32'(cpl_ndw) && ix < MMIO_MAX_DW) cpl_data[i*32 +: 32] = rdbuf[ix];
      end
    end
  end
  wire cpl_fire = cpl_valid && cpl_ready;

  // ---- payload beat register (write path) ------------------------------------------------------------------------
  logic              pb_valid, pb_last;
  logic [DATA_W-1:0] pb_data;
  logic [NW-1:0]     pb_n, pb_i;
  logic [10:0]       dwi;                          // dword index inside the TLP (writes)
  logic              csr_busy_rd;                  // a CSR read is awaiting its data

  // byte strobes for dword `dwi` of the running TLP
  logic [3:0] dw_strb;
  always_comb begin
    if (dwi == 11'd0)                       dw_strb = h_fbe;
    else if (dwi == h_ndw - 11'd1)          dw_strb = h_lbe;
    else                                    dw_strb = 4'b1111;
  end

  wire tgt_is_fab = (h_tgt == `SFPB_TGT_FREG) || (h_tgt == `SFPB_TGT_FMEM);
  wire [31:0] cur_sfb_addr = h_sfb + {19'd0, dwi, 2'b00};          // write path
  wire [15:0] cur_csr_addr = h_off + {3'd0, dwi, 2'b00};
  wire [31:0] rd_sfb_addr  = h_sfb + {19'd0, req_idx, 2'b00};      // read path
  wire [15:0] rd_csr_addr  = h_off + {3'd0, req_idx, 2'b00};

  // a write dword is consumed this cycle: CSR writes always; fabric writes when the port can take it (or nothing to send)
  wire wr_adv = (h_tgt == `SFPB_TGT_CSR || h_tgt == `SFPB_TGT_CTX) ? 1'b1 : ((dw_strb == 4'b0000) || can_issue);

  // ---- main FSM --------------------------------------------------------------------------------------------------
  always_comb begin
    req_ready = (state == S_IDLE) && !flush;
    pay_ready = 1'b0;
    csr_wr_valid = 1'b0; csr_wr_addr = cur_csr_addr; csr_wr_data = pb_data[pb_i*32 +: 32]; csr_wr_strb = dw_strb;
    csr_rd_valid = 1'b0; csr_rd_addr = rd_csr_addr;
    issue = 1'b0; issue_write = 1'b0; issue_addr = cur_sfb_addr; issue_wdata = pb_data[pb_i*32 +: 32]; issue_strb = dw_strb;
    if (state == S_DRAIN) pay_ready = 1'b1;
    if (state == S_WR) begin
      if (!pb_valid) pay_ready = 1'b1;
      else if (h_tgt == `SFPB_TGT_CSR || h_tgt == `SFPB_TGT_CTX) csr_wr_valid = (dw_strb != 4'b0000);
      else if (tgt_is_fab && dw_strb != 4'b0000 && can_issue) begin issue = 1'b1; issue_write = 1'b1; end
    end
    if (state == S_RD) begin
      if (h_tgt == `SFPB_TGT_CSR || h_tgt == `SFPB_TGT_CTX) begin
        if (!csr_busy_rd && (req_idx < h_ndw) && !zero_len) csr_rd_valid = 1'b1;
      end else if (tgt_is_fab && (req_idx < h_ndw) && !zero_len && can_issue) begin
        issue = 1'b1; issue_write = 1'b0; issue_addr = rd_sfb_addr; issue_wdata = 32'd0; issue_strb = 4'b1111;
      end
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE;
      h_type <= '0; h_addr <= '0; h_ndw <= '0; h_fbe <= '0; h_lbe <= '0; h_tag <= '0; h_rid <= '0; h_tc <= '0; h_attr <= '0;
      h_tgt <= '0; h_off <= '0; h_sfb <= '0; h_after <= '0; lat <= '0;
      rsp_idx <= '0; rd_err <= 1'b0; wr_err <= 1'b0; req_idx <= '0; want_rsp_data <= 1'b0;
      cp_done <= '0; cp_sent <= '0; cp_chunk <= '0; cp_beat <= '0; cp_first <= 1'b1; cp_started <= 1'b0; cp_status <= '0;
      lat_done <= 1'b0;
      pb_valid <= 1'b0; pb_last <= 1'b0; pb_data <= '0; pb_n <= '0; pb_i <= '0; dwi <= '0; csr_busy_rd <= 1'b0;
      ev_err_valid <= 1'b0; ev_err_code <= '0; ev_err_addr <= '0; ev_err_tag <= '0; ev_err_reqid <= '0; ev_err_type <= '0;
      ev_rd_valid <= 1'b0; ev_rd_lat <= '0; ev_wr_valid <= 1'b0; ev_wr_lat <= '0; ev_exec_rd <= 1'b0; ev_exec_wr <= 1'b0;
    end else begin
      ev_err_valid <= 1'b0; ev_rd_valid <= 1'b0; ev_wr_valid <= 1'b0; ev_exec_rd <= 1'b0; ev_exec_wr <= 1'b0;
      if (state != S_IDLE && lat != 16'hFFFF) lat <= lat + 1'b1;

      // late SFB2 responses and read data
      if (rsp_fire && want_rsp_data) begin
        if (rsp_idx < 11'(MMIO_MAX_DW)) rdbuf[rsp_idx[$clog2(MMIO_MAX_DW)-1:0]] <= sfb_rsp_rdata;
        rsp_idx <= rsp_idx + 1'b1;
        if (sfb_rsp_error) rd_err <= 1'b1;
      end
      if (rsp_fire && (state == S_WR || state == S_WR_WAIT) && sfb_rsp_error) wr_err <= 1'b1;
      if (csr_rd_dvalid && csr_busy_rd) begin
        rdbuf[rsp_idx[$clog2(MMIO_MAX_DW)-1:0]] <= csr_rd_data; rsp_idx <= rsp_idx + 1'b1; csr_busy_rd <= 1'b0;
        if (csr_rd_err) rd_err <= 1'b1;
      end

      case (state)
        // ---------------------------------------------------------------------------------------------------------
        S_IDLE: begin
          if (req_valid && req_ready) begin
            h_type <= req_type; h_addr <= req_addr; h_ndw <= req_ndw; h_fbe <= req_first_be; h_lbe <= req_last_be;
            h_tag <= req_tag; h_rid <= req_reqid; h_tc <= req_tc; h_attr <= req_attr;
            h_tgt <= d_tgt; h_off <= d_off; h_sfb <= d_sfb; h_after <= d_act;
            lat <= 16'd0; lat_done <= 1'b0; dwi <= '0; req_idx <= '0; rsp_idx <= '0; rd_err <= 1'b0; wr_err <= 1'b0;
            pb_valid <= 1'b0; cp_done <= '0; cp_sent <= '0; cp_beat <= '0; cp_first <= 1'b1; cp_started <= 1'b0;
            want_rsp_data <= 1'b0; csr_busy_rd <= 1'b0;
            if (d_code != `SFPB_E_NONE) begin
              ev_err_valid <= 1'b1; ev_err_code <= d_code; ev_err_addr <= req_addr; ev_err_tag <= req_tag;
              ev_err_reqid <= req_reqid; ev_err_type <= req_type;
            end
            case (d_act)
              A_EXEC: begin
                if (is_mwr) begin state <= S_WR; ev_exec_wr <= 1'b1; end
                else        begin state <= S_RD; ev_exec_rd <= 1'b1; want_rsp_data <= (d_tgt == `SFPB_TGT_FREG) || (d_tgt == `SFPB_TGT_FMEM); end
              end
              A_DROP: state <= req_has_pay ? S_DRAIN : S_IDLE;
              A_UR:   begin state <= req_has_pay ? S_DRAIN : S_CPL_ERR; cp_status <= `SFPB_CPL_UR; end
              default: begin state <= req_has_pay ? S_DRAIN : S_CPL_ERR; cp_status <= `SFPB_CPL_CA; end
            endcase
          end
        end
        // ---------------------------------------------------------------------------------------------------------
        S_DRAIN: begin
          if (pay_valid && pay_last) begin
            if (h_after == A_UR || h_after == A_CA) state <= S_CPL_ERR; else state <= S_IDLE;
          end
        end
        // ---------------------------------------------------------------------------------------------------------
        S_WR: begin
          if (!pb_valid) begin
            if (pay_valid) begin pb_valid <= 1'b1; pb_data <= pay_data; pb_n <= pay_ndw; pb_i <= '0; pb_last <= pay_last; end
          end else begin
            if (st_fatal && tgt_is_fab) begin                         // fabric port is dead: stop executing, drop the rest
              ev_err_valid <= 1'b1; ev_err_code <= `SFPB_E_FAB_TIMEOUT; ev_err_addr <= h_addr; ev_err_tag <= h_tag;
              ev_err_reqid <= h_rid; ev_err_type <= h_type;
              pb_valid <= 1'b0;
              if (pb_last) state <= S_IDLE; else begin h_after <= A_DROP; state <= S_DRAIN; end
            end else if (wr_adv) begin
              if (h_tgt == `SFPB_TGT_CSR || h_tgt == `SFPB_TGT_CTX) begin
              if (dw_strb != 4'b0000 && csr_wr_err) begin
                ev_err_valid <= 1'b1; ev_err_code <= `SFPB_E_CSR_ERR; ev_err_addr <= h_addr + {51'd0, dwi, 2'b00};
                ev_err_tag <= h_tag; ev_err_reqid <= h_rid; ev_err_type <= h_type;
              end
              end
              dwi <= dwi + 1'b1;
              if (pb_i == pb_n - 1'b1) begin
                pb_valid <= 1'b0;
                if (pb_last) state <= S_WR_WAIT;
              end else pb_i <= pb_i + 1'b1;
            end
          end
        end
        // ---------------------------------------------------------------------------------------------------------
        S_WR_WAIT: begin
          if (!tgt_is_fab || (!sq_valid && pend == 4'd0)) begin                  // register writes never wait on the fabric port
            if (wr_err) begin
              ev_err_valid <= 1'b1; ev_err_code <= `SFPB_E_FAB_ERR; ev_err_addr <= h_addr; ev_err_tag <= h_tag;
              ev_err_reqid <= h_rid; ev_err_type <= h_type;
            end
            ev_wr_valid <= 1'b1; ev_wr_lat <= lat;
            state <= S_IDLE;
          end else if (st_fatal) begin
            ev_err_valid <= 1'b1; ev_err_code <= `SFPB_E_FAB_TIMEOUT; ev_err_addr <= h_addr; ev_err_tag <= h_tag;
            ev_err_reqid <= h_rid; ev_err_type <= h_type;
            state <= S_IDLE;
          end
        end
        // ---------------------------------------------------------------------------------------------------------
        S_RD: begin
          if (zero_len) begin
            // zero-length read (flush): no register is touched; one dword of zeros comes back
            rdbuf[0] <= 32'd0; state <= S_CPL;
          end else begin
            if (issue || csr_rd_valid) req_idx <= req_idx + 1'b1;
            if (csr_rd_valid) csr_busy_rd <= 1'b1;
            if ((req_idx == h_ndw) && (rsp_idx == h_ndw)) begin
              if (rd_err) begin
                ev_err_valid <= 1'b1; ev_err_code <= tgt_is_fab ? `SFPB_E_FAB_ERR : `SFPB_E_CSR_ERR; ev_err_addr <= h_addr;
                ev_err_tag <= h_tag; ev_err_reqid <= h_rid; ev_err_type <= h_type;
                cp_status <= (tgt_is_fab) ? `SFPB_CPL_CA : `SFPB_CPL_UR; state <= S_CPL_ERR;
              end else state <= S_CPL;
            end else if (st_fatal && tgt_is_fab) begin                          // only fabric reads can be stranded by a dead port
              ev_err_valid <= 1'b1; ev_err_code <= `SFPB_E_FAB_TIMEOUT; ev_err_addr <= h_addr; ev_err_tag <= h_tag;
              ev_err_reqid <= h_rid; ev_err_type <= h_type;
              cp_status <= `SFPB_CPL_CA; state <= S_CPL_ERR;
            end
          end
        end
        // ---------------------------------------------------------------------------------------------------------
        S_CPL: begin
          if (!cp_started) begin cp_chunk <= cp_next_chunk; cp_started <= 1'b1; end
          if (cpl_fire) begin
            if (!lat_done) begin lat_done <= 1'b1; ev_rd_valid <= 1'b1; ev_rd_lat <= lat; end
            if (beat_left <= 11'(K)) begin               // last beat of this completion
              cp_done <= cp_done + cp_c;
              cp_sent <= cp_sent + 13'({cp_c, 2'b00}) - (cp_first ? 13'(lo_off) : 13'd0);
              cp_beat <= '0; cp_first <= 1'b0; cp_started <= 1'b0;
              if (cp_done + cp_c >= h_ndw) state <= S_IDLE;
            end else cp_beat <= cp_beat + 1'b1;
          end
        end
        // ---------------------------------------------------------------------------------------------------------
        S_CPL_ERR: begin
          if (cpl_fire) begin
            if (!lat_done) begin lat_done <= 1'b1; ev_rd_valid <= 1'b1; ev_rd_lat <= lat; end
            state <= S_IDLE;
          end
        end
        // ---------------------------------------------------------------------------------------------------------
        S_FLUSH: begin
          if (!owed || st_fatal) state <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase

      if (flush && state != S_IDLE && state != S_FLUSH) begin
        state <= S_FLUSH; pb_valid <= 1'b0; csr_busy_rd <= 1'b0; want_rsp_data <= 1'b0;
      end
    end
  end

  assign idle = (state == S_IDLE) && !owed;
endmodule
`default_nettype wire
