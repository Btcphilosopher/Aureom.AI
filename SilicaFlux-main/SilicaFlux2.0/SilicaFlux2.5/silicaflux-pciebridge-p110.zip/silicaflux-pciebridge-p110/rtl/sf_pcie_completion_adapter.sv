// =============================================================================
// sf_pcie_completion_adapter -- both directions of completion traffic at the endpoint boundary.
//
//  TX  "completion formatter":  completion beat stream (from the MMIO engine)  ->  Completer-Completion (CC) stream.
//      * builds the 96-bit CC descriptor and hands it with the payload to sf_pcie_axis_pack;
//      * ORDERING GATE: a completion may not overtake posted writes this device issued earlier.  CC and RQ are
//        independent streams inside the endpoint, so the gate holds the first beat of every completion until the
//        endpoint has acknowledged (sequence-number acknowledge) every request TLP that had been handed to RQ
//        when the completion first became ready.  See docs/04_ORDERING_AND_ERRORS.md.
//
//  RX  Requester-Completion (RC) stream  ->  completion beat stream for the tag tracker (header decoded, payload
//      re-aligned, framing violations flagged on the last beat).
//
// CC descriptor (96 bit):  [6:0] lower address  [9:8] AT  [28:16] byte count  [29] locked  [42:32] dword count
//   [45:43] status  [46] poisoned  [63:48] requester id  [71:64] tag  [87:72] completer id  [88] completer id enable
//   [91:89] TC  [94:92] attr  [95] force ECRC
// RC descriptor (96 bit):  [6:0] lower address  [15:12] error code  [28:16] byte count  [29] locked  [30] request
//   completed  [42:32] dword count  [45:43] status  [46] poisoned  [63:48] requester id  [71:64] tag
//   [87:72] completer id  [91:89] TC  [94:92] attr
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
module sf_pcie_completion_adapter #(
  parameter int DATA_W      = 256,
  parameter int CC_USER_W   = 33,
  parameter int RC_USER_W   = 75,
  parameter int RC_DISC_BIT = -1,           // tuser bit carrying `discontinue` on RC (-1: not connected)
  parameter int ORD_W       = 8,            // width of the issued/acknowledged TLP counters
  localparam int K          = DATA_W / 32,
  localparam int NW         = $clog2(K + 1)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                flush_tx,          // clears the CC side (MMIO recovery)
  input  wire logic                flush_rx,          // clears the RC side (DMA recovery)
  // ---- TX -------------------------------------------------------------------------------------------------------
  input  wire logic                cpl_valid,
  output logic                     cpl_ready,
  input  wire logic                cpl_sop,
  input  wire logic                cpl_eop,
  input  wire logic [DATA_W-1:0]   cpl_data,
  input  wire logic [NW-1:0]       cpl_ndw,
  input  wire logic [2:0]          cpl_status,
  input  wire logic [6:0]          cpl_lower,
  input  wire logic [12:0]         cpl_bytecnt,
  input  wire logic [10:0]         cpl_dwcnt,
  input  wire logic [15:0]         cpl_reqid,
  input  wire logic [7:0]          cpl_tag,
  input  wire logic [2:0]          cpl_tc,
  input  wire logic [2:0]          cpl_attr,
  input  wire logic [ORD_W-1:0]    ord_issued,       // request TLPs handed to RQ so far (modular)
  input  wire logic [ORD_W-1:0]    ord_acked,        // request TLPs the endpoint has acknowledged (modular)
  output logic                     ord_stall,        // pulse-per-cycle: a completion is held by the gate
  output logic [DATA_W-1:0]        m_cc_tdata,
  output logic [K-1:0]             m_cc_tkeep,
  output logic                     m_cc_tlast,
  output logic [CC_USER_W-1:0]     m_cc_tuser,
  output logic                     m_cc_tvalid,
  input  wire logic                m_cc_tready,
  output logic                     st_cc_tlp,        // pulse: a completion TLP left
  output logic                     cc_idle,
  // ---- RX -------------------------------------------------------------------------------------------------------
  input  wire logic [DATA_W-1:0]   s_rc_tdata,
  input  wire logic [K-1:0]        s_rc_tkeep,
  input  wire logic                s_rc_tlast,
  input  wire logic [RC_USER_W-1:0] s_rc_tuser,
  input  wire logic                s_rc_tvalid,
  output logic                     s_rc_tready,
  output logic                     rcv_valid,
  input  wire logic                rcv_ready,
  output logic                     rcv_sop,
  output logic                     rcv_eop,
  output logic [DATA_W-1:0]        rcv_data,
  output logic [NW-1:0]            rcv_ndw,
  output logic                     rcv_bad,          // framing violation (valid with rcv_eop)
  output logic [6:0]               rcv_lower,
  output logic [3:0]               rcv_err,          // endpoint-reported receive error code (SFPB_RCE_*)
  output logic [12:0]              rcv_bytecnt,
  output logic                     rcv_req_done,
  output logic [10:0]              rcv_dwcnt,
  output logic [2:0]               rcv_status,
  output logic                     rcv_poison,
  output logic [15:0]              rcv_reqid,
  output logic [7:0]               rcv_tag,
  output logic [2:0]               rcv_tc,
  output logic [2:0]               rcv_attr
);
  // =========================== TX ===========================================================================
  // ---- ordering gate ----------------------------------------------------------------------------------------
  logic              snap_v;
  logic [ORD_W-1:0]  snap;
  wire  [ORD_W-1:0]  snap_eff = snap_v ? snap : ord_issued;
  wire  [ORD_W-1:0]  diff     = ord_acked - snap_eff;
  wire               gate_ok  = !diff[ORD_W-1];                 // acked has reached the snapshot (modular compare)
  wire               hold     = cpl_valid && cpl_sop && !gate_ok;
  assign ord_stall = hold;

  wire               i_ready;
  wire               i_valid = cpl_valid && !hold;
  assign cpl_ready = i_ready && !hold;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin snap_v <= 1'b0; snap <= '0; end
    else if (flush_tx) snap_v <= 1'b0;
    else begin
      if (cpl_valid && cpl_sop && !snap_v) begin snap_v <= 1'b1; snap <= ord_issued; end
      if (cpl_valid && cpl_ready && cpl_sop) snap_v <= 1'b0;            // consumed with the first beat
    end
  end

  logic [95:0] cc_desc;
  always_comb begin
    cc_desc = '0;
    cc_desc[6:0]    = cpl_lower;
    cc_desc[9:8]    = 2'b00;
    cc_desc[28:16]  = cpl_bytecnt;
    cc_desc[29]     = 1'b0;
    cc_desc[42:32]  = cpl_dwcnt;
    cc_desc[45:43]  = cpl_status;
    cc_desc[46]     = 1'b0;
    cc_desc[63:48]  = cpl_reqid;
    cc_desc[71:64]  = cpl_tag;
    cc_desc[87:72]  = 16'd0;           // completer id: inserted by the endpoint
    cc_desc[88]     = 1'b0;            // completer id enable = 0
    cc_desc[91:89]  = cpl_tc;
    cc_desc[94:92]  = cpl_attr;
    cc_desc[95]     = 1'b0;
  end

  logic pack_idle;
  sf_pcie_axis_pack #(.DATA_W(DATA_W), .HDR_DW(3), .USER_W(CC_USER_W)) u_pack (
    .clk(clk), .rst_n(rst_n), .flush(flush_tx),
    .i_valid(i_valid), .i_ready(i_ready), .i_sop(cpl_sop), .i_eop(cpl_eop), .i_data(cpl_data), .i_ndw(cpl_ndw),
    .i_hdr(cc_desc), .i_user({CC_USER_W{1'b0}}),
    .m_tdata(m_cc_tdata), .m_tkeep(m_cc_tkeep), .m_tlast(m_cc_tlast), .m_tuser(m_cc_tuser), .m_tvalid(m_cc_tvalid),
    .m_tready(m_cc_tready), .idle(pack_idle));
  assign cc_idle    = pack_idle;
  assign st_cc_tlp  = m_cc_tvalid && m_cc_tready && m_cc_tlast;

  // =========================== RX ===========================================================================
  wire rc_disc = (RC_DISC_BIT >= 0) ? s_rc_tuser[(RC_DISC_BIT >= 0) ? RC_DISC_BIT : 0] : 1'b0;
  /* verilator lint_off UNUSEDSIGNAL */  // RC descriptor fields this bridge does not need (locked-read, completer id, ...)
  logic [95:0]          r_hdr;
  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_off UNUSEDSIGNAL */  // RC sideband is not used in DWORD-aligned mode
  logic [RC_USER_W-1:0] r_user;
  /* verilator lint_on UNUSEDSIGNAL */
  sf_pcie_axis_unpack #(.DATA_W(DATA_W), .HDR_DW(3), .USER_W(RC_USER_W)) u_unpack (
    .clk(clk), .rst_n(rst_n), .flush(flush_rx),
    .s_tdata(s_rc_tdata), .s_tkeep(s_rc_tkeep), .s_tlast(s_rc_tlast), .s_tuser(s_rc_tuser), .s_tbad(rc_disc),
    .s_tvalid(s_rc_tvalid), .s_tready(s_rc_tready),
    .o_valid(rcv_valid), .o_ready(rcv_ready), .o_sop(rcv_sop), .o_eop(rcv_eop), .o_data(rcv_data), .o_ndw(rcv_ndw),
    .o_hdr(r_hdr), .o_user(r_user), .o_bad(rcv_bad));

  assign rcv_lower    = r_hdr[6:0];
  assign rcv_err      = r_hdr[15:12];
  assign rcv_bytecnt  = r_hdr[28:16];
  assign rcv_req_done = r_hdr[30];
  assign rcv_dwcnt    = r_hdr[42:32];
  assign rcv_status   = r_hdr[45:43];
  assign rcv_poison   = r_hdr[46];
  assign rcv_reqid    = r_hdr[63:48];
  assign rcv_tag      = r_hdr[71:64];
  assign rcv_tc       = r_hdr[91:89];
  assign rcv_attr     = r_hdr[94:92];
endmodule
`default_nettype wire
