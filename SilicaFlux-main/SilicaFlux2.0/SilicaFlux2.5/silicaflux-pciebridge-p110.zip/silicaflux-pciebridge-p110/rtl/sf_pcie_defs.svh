// =============================================================================
// SilicaFlux PCIe Transaction Bridge (Project 110) :: shared constants
// Macros instead of a package, per the SilicaFlux RTL coding rules (flat SV subset accepted unchanged by
// the Verilator 5.020, Icarus 12 and Yosys 0.33 front ends).  Register offsets: sf_pcie_regs.svh (generated).
//
// The request-type, completion-status and descriptor layouts below follow the AMD UltraScale+ "Integrated
// Block for PCI Express" AXI4-Stream interface (CQ/CC/RQ/RC) as documented publicly and as implemented by
// the open-source pcie_us_if_* adapters used as a cross-check (docs/02_ENDPOINT_INTERFACE.md).
// THEY HAVE NOT BEEN VERIFIED AGAINST A GENERATED IP INSTANCE: no vendor IP exists in this repository.
// =============================================================================
`ifndef SF_PCIE_DEFS_SVH
`define SF_PCIE_DEFS_SVH

// ---- request type field (CQ/RQ descriptor bits [78:75]) ---------------------------------------------------------
`define SFPB_RT_MEM_RD       4'd0
`define SFPB_RT_MEM_WR       4'd1
`define SFPB_RT_IO_RD        4'd2
`define SFPB_RT_IO_WR        4'd3
`define SFPB_RT_ATOM_FADD    4'd4
`define SFPB_RT_ATOM_SWAP    4'd5
`define SFPB_RT_ATOM_CAS     4'd6
`define SFPB_RT_MEM_RD_LOCK  4'd7
`define SFPB_RT_MSG          4'd8   // CQ encoding; (RQ encodes config at 8..11 and messages at 12..14)
`define SFPB_RT_MSG_VENDOR   4'd9
`define SFPB_RT_MSG_ATS      4'd10

// ---- completion status (CC/RC descriptor) -----------------------------------------------------------------------
`define SFPB_CPL_SC          3'd0   // successful completion
`define SFPB_CPL_UR          3'd1   // unsupported request
`define SFPB_CPL_CRS         3'd2   // configuration request retry status (never generated here)
`define SFPB_CPL_CA          3'd4   // completer abort

// ---- RC descriptor "error code" field [15:12] (endpoint IP reports its own receive-side checks here) ------------
`define SFPB_RCE_NONE        4'd0
`define SFPB_RCE_POISONED    4'd1
`define SFPB_RCE_BAD_STATUS  4'd2
`define SFPB_RCE_INV_LEN     4'd3
`define SFPB_RCE_MISMATCH    4'd4
`define SFPB_RCE_INV_ADDR    4'd5
`define SFPB_RCE_INV_TAG     4'd6
`define SFPB_RCE_FLR         4'd8
`define SFPB_RCE_TIMEOUT     4'd9

// ---- unified 6-bit error / event code (error log, DMA completion detail, tracker events) ------------------------
`define SFPB_E_NONE            6'h00
// host -> device request side
`define SFPB_E_MAL_LEN         6'h01   // stream payload length != descriptor dword count
`define SFPB_E_MAL_FRAMING     6'h02   // tkeep/tlast framing violation
`define SFPB_E_MAL_ZERO_LEN    6'h03   // descriptor dword count = 0
`define SFPB_E_MAL_BE          6'h04   // byte-enable rule violated
`define SFPB_E_MAL_4K          6'h05   // request crosses a 4 KiB boundary
`define SFPB_E_MAL_RD_PAYLOAD  6'h06   // non-posted request that carries payload (or write without)
`define SFPB_E_OVERSIZE        6'h07   // payload larger than the store-and-forward buffer / MPS
`define SFPB_E_UNSUP_TYPE      6'h08
`define SFPB_E_POISONED_REQ    6'h09
`define SFPB_E_UNSUP_AT        6'h0A
`define SFPB_E_UNSUP_TC        6'h0B
`define SFPB_E_BAR_INVALID     6'h10   // BAR id not implemented
`define SFPB_E_BAR_APERTURE    6'h11   // endpoint-reported aperture != expected
`define SFPB_E_BAR_RANGE       6'h12   // unmapped / outside window / spans two targets
`define SFPB_E_BAR_LEN         6'h13   // too many dwords for the window
`define SFPB_E_BAR_PERM        6'h14   // window disabled or access type not allowed
`define SFPB_E_CSR_ERR         6'h15   // register-level error (write to RO, reserved offset)
`define SFPB_E_FAB_ERR         6'h18   // SFB2 rsp_error
`define SFPB_E_FAB_TIMEOUT     6'h19   // SFB2 response did not arrive
`define SFPB_E_FAB_FATAL       6'h1A   // request refused: fabric port is in the fatal state
// requester (DMA) completion side
`define SFPB_E_CPL_UR          6'h20
`define SFPB_E_CPL_CA          6'h21
`define SFPB_E_CPL_CRS         6'h22
`define SFPB_E_CPL_POISONED    6'h23
`define SFPB_E_CPL_TIMEOUT     6'h24
`define SFPB_E_CPL_MISMATCH    6'h25   // byte count / lower address / length inconsistent with the request
`define SFPB_E_CPL_UNEXPECTED  6'h26   // no outstanding request owns the tag
`define SFPB_E_CPL_LATE        6'h27   // completion for a quarantined (timed-out) tag
`define SFPB_E_CPL_OVERRUN     6'h28   // more data than requested
`define SFPB_E_CPL_BAD_REQID   6'h29
`define SFPB_E_CPL_FRAMING     6'h2A
`define SFPB_E_CPL_RESET       6'h2B   // request lost to reset / FLR / link down (NEVER reported as success)
`define SFPB_E_CPL_IPERR       6'h2C   // endpoint IP reported an error code this bridge does not understand
// DMA egress protection
`define SFPB_E_DMA_NO_CTX      6'h30
`define SFPB_E_DMA_WINDOW      6'h31
`define SFPB_E_DMA_PERM        6'h32
`define SFPB_E_DMA_BADLEN      6'h33
`define SFPB_E_DMA_BADMTYPE    6'h34
`define SFPB_E_DMA_BADFORMAT   6'h35
`define SFPB_E_DMA_STRB        6'h36   // write strobes not one contiguous run
`define SFPB_E_DMA_PROTO       6'h37   // W/AW mismatch
`define SFPB_E_DMA_RECOVERY    6'h38   // request arrived while recovering
`define SFPB_E_DMA_ORDER       6'h39   // endpoint sequence-number acknowledge out of contract
`define SFPB_E_IRQ_FAIL        6'h3A   // MSI request failed after all retries
`define SFPB_E_RECOVERED       6'h3B   // a reset / link-down recovery completed: host must re-initialise
// link / reset events
`define SFPB_E_LINK_DOWN       6'h3C
`define SFPB_E_FLR             6'h3D
`define SFPB_E_SOFT_RESET      6'h3E

// ---- ERR_STATUS sticky classes (bit index) ----------------------------------------------------------------------
`define SFPB_ES_MALFORMED      0
`define SFPB_ES_UNSUPPORTED    1
`define SFPB_ES_BAR            2
`define SFPB_ES_POISONED       3
`define SFPB_ES_FABRIC         4
`define SFPB_ES_CSR            5
`define SFPB_ES_CPL_ERR        6    // UR / CA / poisoned / mismatch / overrun / framing from the host
`define SFPB_ES_CPL_TIMEOUT    7
`define SFPB_ES_CPL_UNEXP      8    // unexpected or late completion
`define SFPB_ES_DMA_PROT       9    // DMA egress protection violation
`define SFPB_ES_DMA_BUS        10   // DMA transaction failed on the PCIe side
`define SFPB_ES_LINK           11   // link down
`define SFPB_ES_FLR            12
`define SFPB_ES_RECOVERED      13   // a recovery completed: host must re-initialise
`define SFPB_ES_IRQ_FAIL       14
`define SFPB_ES_OVERFLOW       15   // internal queue overflow / dropped event
`define SFPB_ES_N              16

// ---- interrupt sources -----------------------------------------------------------------------------------------
`define SFPB_IS_DMA_CPL        0
`define SFPB_IS_DMA_ERR        1
`define SFPB_IS_ERR            2
`define SFPB_IS_RECOVERY       3
`define SFPB_IS_STREAMDMA      4    // StreamDMA irq line (descriptor IRQ_EN flag)
`define SFPB_IS_EXT0           5
`define SFPB_IS_EXT1           6
`define SFPB_IS_EXT2           7
`define SFPB_IS_N              8

// ---- recovery FSM state (visible in STATUS) --------------------------------------------------------------------
`define SFPB_REC_RUN           4'd0
`define SFPB_REC_QUIESCE       4'd1
`define SFPB_REC_DMA_DRAIN     4'd2
`define SFPB_REC_WAIT_LINK     4'd3
`define SFPB_REC_QUIET         4'd4
`define SFPB_REC_DONE          4'd5

// ---- BAR window targets ----------------------------------------------------------------------------------------
`define SFPB_TGT_NONE          3'd0
`define SFPB_TGT_CSR           3'd1    // global register page
`define SFPB_TGT_CTX           3'd2    // per-context DMA submission page
`define SFPB_TGT_FREG          3'd3    // DataFabric register window (SFB2)
`define SFPB_TGT_FMEM          3'd4    // DataFabric memory window   (SFB2)

// ---- StreamDMA constants this bridge relies on (mirrors vendored sf_stream_dma_defs.svh) -------------------------
`define SFPB_SD_VERSION        8'd1
`define SFPB_SD_OP_COPY        8'd0
`define SFPB_SD_FLAGS_MASK     16'h001F
`define SFPB_SD_MT_DRAM        4'd0
`define SFPB_SD_MT_SRAM        4'd1

`endif
