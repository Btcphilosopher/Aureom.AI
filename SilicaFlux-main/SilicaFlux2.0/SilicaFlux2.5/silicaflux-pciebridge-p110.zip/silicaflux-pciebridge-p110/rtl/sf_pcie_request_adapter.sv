// =============================================================================
// sf_pcie_request_adapter -- endpoint Completer-Request (CQ) interface  ->  validated request channel.
//
// Explicit adapter to the AMD UltraScale+ style CQ AXI4-Stream interface (descriptor in the first 128 bits of the
// first beat, DWORD-aligned payload, tuser = {.. discontinue, .. last_be, first_be}).  Everything vendor-specific
// is decoded here and nowhere else; the rest of the bridge sees the decoded fields below.
//
// Store-and-forward: a TLP's payload is parked in a small RAM and its header is released only after the whole TLP
// has been seen and validated, so a malformed or discontinued TLP can never partially execute.  The payload of a
// rejected TLP is rolled back (never visible to the consumer).  The adapter does not classify or execute requests;
// it only guarantees framing, length, byte-enable and 4 KiB-boundary sanity and reports the first violation found.
//
// CQ descriptor (128 bit, from the endpoint IP):
//   [1:0] AT   [63:2] address[63:2]   [74:64] dword count   [78:75] request type   [79] poisoned
//   [95:80] requester id   [103:96] tag   [111:104] target function   [114:112] BAR id   [120:115] BAR aperture
//   [123:121] TC   [126:124] attr
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
module sf_pcie_request_adapter #(
  parameter int DATA_W     = 256,           // 128 | 256
  parameter int CQ_USER_W  = 85,
  parameter int CQ_DISC_BIT = 41,           // tuser bit carrying `discontinue` (-1: not connected)
  parameter int MAX_PAY_DW = 64,            // largest payload that is stored; longer TLPs are rejected as OVERSIZE
  parameter int HDR_DEPTH  = 4,
  localparam int K         = DATA_W / 32,
  localparam int NW        = $clog2(K + 1),
  localparam int MAXB      = (MAX_PAY_DW + K - 1) / K,        // stored beats per TLP
  localparam int PB        = $clog2(2 * MAXB + 2),            // RAM depth = 2**PB beats
  localparam int HBW       = $clog2(MAXB + 1)
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  flush,
  // endpoint CQ stream
  input  wire logic [DATA_W-1:0]     s_cq_tdata,
  input  wire logic [K-1:0]          s_cq_tkeep,
  input  wire logic                  s_cq_tlast,
  input  wire logic [CQ_USER_W-1:0]  s_cq_tuser,
  input  wire logic                  s_cq_tvalid,
  output logic                       s_cq_tready,
  // validated request channel
  output logic                       req_valid,
  input  wire logic                  req_ready,
  output logic [3:0]                 req_type,
  output logic [63:0]                req_addr,
  output logic [10:0]                req_ndw,
  output logic [3:0]                 req_first_be,
  output logic [3:0]                 req_last_be,
  output logic [7:0]                 req_tag,
  output logic [15:0]                req_reqid,
  output logic [2:0]                 req_tc,
  output logic [2:0]                 req_attr,
  output logic [1:0]                 req_at,
  output logic                       req_poison,
  output logic [2:0]                 req_bar_id,
  output logic [5:0]                 req_bar_ap,
  output logic [7:0]                 req_func,
  output logic                       req_bad,       // adapter-level violation: do not execute
  output logic [5:0]                 req_code,      // SFPB_E_* when req_bad
  output logic                       req_has_pay,   // payload beats follow on pay_*
  // payload of the request at the head (valid only after its header was accepted)
  output logic                       pay_valid,
  input  wire logic                  pay_ready,
  output logic [DATA_W-1:0]          pay_data,
  output logic [NW-1:0]              pay_ndw,
  output logic                       pay_last,
  // statistics
  output logic                       st_tlp,        // pulse: a TLP header was queued
  output logic                       st_bad,        // pulse: ... and it was rejected
  output logic [HBW+PB:0]            st_pay_level,
  output logic [3:0]                 st_hdr_level
);
  localparam int DEPTH_B = 1 << PB;

  // ---- unpack -------------------------------------------------------------------------------------------------
  logic              u_valid, u_ready, u_sop, u_eop, u_bad;
  logic [DATA_W-1:0] u_data;
  logic [NW-1:0]     u_ndw;
  logic [127:0]      u_hdr;
  /* verilator lint_off UNUSEDSIGNAL */  // only first_be / last_be (bits [7:0]) of the CQ sideband are used
  logic [CQ_USER_W-1:0] u_user;
  /* verilator lint_on UNUSEDSIGNAL */
  wire disc = (CQ_DISC_BIT >= 0) ? s_cq_tuser[(CQ_DISC_BIT >= 0) ? CQ_DISC_BIT : 0] : 1'b0;

  sf_pcie_axis_unpack #(.DATA_W(DATA_W), .HDR_DW(4), .USER_W(CQ_USER_W)) u_unpack (
    .clk(clk), .rst_n(rst_n), .flush(flush),
    .s_tdata(s_cq_tdata), .s_tkeep(s_cq_tkeep), .s_tlast(s_cq_tlast), .s_tuser(s_cq_tuser), .s_tbad(disc),
    .s_tvalid(s_cq_tvalid), .s_tready(s_cq_tready),
    .o_valid(u_valid), .o_ready(u_ready), .o_sop(u_sop), .o_eop(u_eop), .o_data(u_data), .o_ndw(u_ndw),
    .o_hdr(u_hdr), .o_user(u_user), .o_bad(u_bad));

  // ---- descriptor decode (live on sop; the header is kept in hdr_q for the remaining beats) ---------------------
  /* verilator lint_off UNUSEDSIGNAL */  // descriptor bit 127 is reserved
  logic [127:0] h_cur;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [127:0] hdr_q;
  logic [3:0]   fbe_q, lbe_q;
  always_comb begin
    h_cur = u_sop ? u_hdr : hdr_q;
  end
  wire [1:0]  d_at    = h_cur[1:0];
  wire [63:0] d_addr  = {h_cur[63:2], 2'b00};
  wire [10:0] d_ndw   = h_cur[74:64];
  wire [3:0]  d_type  = h_cur[78:75];
  wire        d_poi   = h_cur[79];
  wire [15:0] d_rid   = h_cur[95:80];
  wire [7:0]  d_tag   = h_cur[103:96];
  wire [7:0]  d_func  = h_cur[111:104];
  wire [2:0]  d_barid = h_cur[114:112];
  wire [5:0]  d_barap = h_cur[120:115];
  wire [2:0]  d_tc    = h_cur[123:121];
  wire [2:0]  d_attr  = h_cur[126:124];
  wire [3:0]  d_fbe   = u_sop ? u_user[3:0] : fbe_q;
  wire [3:0]  d_lbe   = u_sop ? u_user[7:4] : lbe_q;

  wire t_checked = (d_type <= `SFPB_RT_MEM_RD_LOCK);                       // memory / IO / atomic / locked
  wire t_has_dat = (d_type == `SFPB_RT_MEM_WR) || (d_type == `SFPB_RT_IO_WR) ||
                   (d_type == `SFPB_RT_ATOM_FADD) || (d_type == `SFPB_RT_ATOM_SWAP) || (d_type == `SFPB_RT_ATOM_CAS);
  wire [10:0] exp_dw = t_has_dat ? d_ndw : 11'd0;

  function automatic logic be_ok(input logic [10:0] n, input logic [3:0] f, input logic [3:0] l);
    if (n == 11'd1)      be_ok = (l == 4'b0000);
    else if (n == 11'd2) be_ok = (f != 4'b0000) && (l != 4'b0000);
    else                 be_ok = ((f == 4'b1111) || (f == 4'b1110) || (f == 4'b1100) || (f == 4'b1000)) &&
                                 ((l == 4'b1111) || (l == 4'b0111) || (l == 4'b0011) || (l == 4'b0001));
  endfunction

  // ---- per-packet accumulation ---------------------------------------------------------------------------------
  logic [11:0]    pcnt;                    // payload dwords seen so far in this TLP (saturating)
  logic [HBW-1:0] bcnt;                    // beats stored so far
  logic           spill;                   // payload exceeded the store: stop storing, reject at eop

  // payload RAM with commit / rollback
  logic [DATA_W-1:0] pram [0:DEPTH_B-1];
  logic [NW-1:0]     pnd  [0:DEPTH_B-1];
  logic [PB:0]       wr_ptr, cm_ptr, rd_ptr;
  wire  [PB:0]       used = wr_ptr - rd_ptr;
  wire               ram_full = (used == (PB+1)'(DEPTH_B));

  // header FIFO
  localparam int HW = 4 + 64 + 11 + 4 + 4 + 8 + 16 + 3 + 3 + 2 + 1 + 3 + 6 + 8 + 1 + 6 + 1 + HBW;
  logic          hf_in_valid, hf_in_ready, hf_out_valid;
  logic [HW-1:0] hf_in, hf_out;
  localparam int HCW = $clog2(HDR_DEPTH + 1);
  /* verilator lint_off UNUSEDSIGNAL */  // the peak marker is a spare diagnostic
  logic [HCW-1:0] hf_level, hf_peak;
  /* verilator lint_on UNUSEDSIGNAL */
  sf_pcie_fifo #(.WIDTH(HW), .DEPTH(HDR_DEPTH)) u_hf (
    .clk(clk), .rst_n(rst_n), .flush(flush),
    .in_valid(hf_in_valid), .in_ready(hf_in_ready), .in_data(hf_in),
    .out_valid(hf_out_valid), .out_ready(req_ready), .out_data(hf_out), .level(hf_level), .peak(hf_peak));
  assign st_hdr_level = 4'(hf_level);

  // ---- beat processing -------------------------------------------------------------------------------------------
  wire [11:0] pcnt_in  = u_sop ? 12'd0 : pcnt;
  wire [HBW-1:0] bcnt_in = u_sop ? '0 : bcnt;
  wire        spill_in = u_sop ? 1'b0 : spill;
  wire [12:0] pcnt_sum = {1'b0, pcnt_in} + {{(13-NW){1'b0}}, u_ndw};
  wire [11:0] pcnt_nx  = (pcnt_sum > 13'd4095) ? 12'd4095 : pcnt_sum[11:0];
  wire        store_it = (u_ndw != '0) && (bcnt_in < HBW'(MAXB)) && !spill_in && t_checked;
  wire        will_spill = (u_ndw != '0) && !store_it && t_checked;

  // ready: need RAM room to store; at eop need header FIFO room
  assign u_ready = u_valid && !flush &&
                   (!store_it || !ram_full) &&
                   (!u_eop || hf_in_ready);

  // verdict (evaluated on the eop beat, using values including this beat)
  logic        v_bad;
  logic [5:0]  v_code;
  logic        v_spill;
  logic [HBW-1:0] v_bcnt;
  always_comb begin
    v_spill = spill_in | will_spill;
    v_bcnt  = bcnt_in + HBW'(store_it);
    v_bad   = 1'b0;
    v_code  = `SFPB_E_NONE;
    if (u_bad) begin
      v_bad = 1'b1; v_code = `SFPB_E_MAL_FRAMING;
    end else if (t_checked && d_ndw == 11'd0) begin
      v_bad = 1'b1; v_code = `SFPB_E_MAL_ZERO_LEN;
    end else if (t_checked && !t_has_dat && (pcnt_nx != 12'd0)) begin
      v_bad = 1'b1; v_code = `SFPB_E_MAL_RD_PAYLOAD;
    end else if (t_checked && (pcnt_nx != {1'b0, exp_dw})) begin
      v_bad = 1'b1; v_code = `SFPB_E_MAL_LEN;
    end else if (t_checked && v_spill) begin
      v_bad = 1'b1; v_code = `SFPB_E_OVERSIZE;
    end else if (t_checked && !be_ok(d_ndw, d_fbe, d_lbe)) begin
      v_bad = 1'b1; v_code = `SFPB_E_MAL_BE;
    end else if (t_checked && (({2'b00, d_addr[11:2]} + {1'b0, d_ndw}) > 12'd1024)) begin
      v_bad = 1'b1; v_code = `SFPB_E_MAL_4K;
    end
  end

  assign hf_in_valid = u_valid && u_ready && u_eop;
  assign hf_in = {d_type, d_addr, d_ndw, d_fbe, d_lbe, d_tag, d_rid, d_tc, d_attr, d_at, d_poi, d_barid, d_barap, d_func,
                  v_bad, v_code, (t_has_dat && !v_bad && (v_bcnt != '0)), (v_bad || !t_has_dat) ? HBW'(0) : v_bcnt};

  assign st_tlp = hf_in_valid;
  assign st_bad = hf_in_valid && v_bad;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pcnt <= '0; bcnt <= '0; spill <= 1'b0; hdr_q <= '0; fbe_q <= '0; lbe_q <= '0;
      wr_ptr <= '0; cm_ptr <= '0;
    end else if (flush) begin
      pcnt <= '0; bcnt <= '0; spill <= 1'b0; wr_ptr <= '0; cm_ptr <= '0;
    end else if (u_valid && u_ready) begin
      if (u_sop) begin hdr_q <= u_hdr; fbe_q <= u_user[3:0]; lbe_q <= u_user[7:4]; end
      pcnt <= pcnt_nx; bcnt <= v_bcnt; spill <= v_spill;
      if (store_it) begin
        pram[wr_ptr[PB-1:0]] <= u_data; pnd[wr_ptr[PB-1:0]] <= u_ndw; wr_ptr <= wr_ptr + 1'b1;
      end
      if (u_eop) begin
        pcnt <= '0; bcnt <= '0; spill <= 1'b0;
        if (v_bad || !t_has_dat) wr_ptr <= cm_ptr;                                   // roll back: payload never visible
        else                     cm_ptr <= wr_ptr + (store_it ? (PB+1)'(1) : (PB+1)'(0));
      end
    end
  end

  // ---- output side -----------------------------------------------------------------------------------------------
  logic        o_bad_f, o_has;
  logic [HBW-1:0] o_nb;
  logic [5:0]  o_code;
  assign {req_type, req_addr, req_ndw, req_first_be, req_last_be, req_tag, req_reqid, req_tc, req_attr, req_at, req_poison,
          req_bar_id, req_bar_ap, req_func, o_bad_f, o_code, o_has, o_nb} = hf_out;
  assign req_valid   = hf_out_valid;
  assign req_bad     = o_bad_f;
  assign req_code    = o_code;
  assign req_has_pay = o_has;

  logic [HBW-1:0] left;                    // payload beats still to deliver for the header at the head
  logic           left_v;                  // `left` belongs to a header already accepted
  assign pay_valid = left_v && (rd_ptr != cm_ptr);
  assign pay_data  = pram[rd_ptr[PB-1:0]];
  assign pay_ndw   = pnd[rd_ptr[PB-1:0]];
  assign pay_last  = (left == HBW'(1));
  assign st_pay_level = (HBW+PB+1)'(used);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_ptr <= '0; left <= '0; left_v <= 1'b0;
    end else if (flush) begin
      rd_ptr <= '0; left <= '0; left_v <= 1'b0;
    end else begin
      if (req_valid && req_ready) begin
        left   <= o_nb;
        left_v <= o_has;
      end
      if (pay_valid && pay_ready) begin
        rd_ptr <= rd_ptr + 1'b1;
        left   <= left - 1'b1;
        if (left == HBW'(1)) left_v <= 1'b0;
      end
    end
  end
endmodule
`default_nettype wire
