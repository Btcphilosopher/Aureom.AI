// =============================================================================
// sf_pcie_dma_submit -- host-visible DMA submission pages (one 4 KiB BAR page per context) in front of StreamDMA.
//
//   host writes DESC0..7 + DOORBELL  ->  validate against the TRUSTED context  ->  StreamDMA descriptor port
//   StreamDMA completion record      ->  per-context completion queue the host pops through CPL_*
//
// What makes this "protected DMA":
//  * the context is selected by the BAR page the host wrote (hardware identity), never by a descriptor field; the
//    descriptor's DOMAIN field is only a claim and must equal the context's domain (domain == context index);
//  * the descriptor is checked before it reaches StreamDMA: ABI version / opcode / flags (single-descriptor
//    transactions only), memory types (exactly one side is host memory), length <= the context maximum, the host
//    side range inside the context's IOVA window with the right direction permitted, the device side range inside
//    the context's device window.  A rejected descriptor never reaches StreamDMA (and later never reaches PCIe);
//  * StreamDMA and the egress adapter check again (domain binding, windows) -- defence in depth, not trust;
//  * completion queues are per context and never back-pressure StreamDMA: a context that does not drain its queue
//    loses records (sticky overflow flag), it cannot stall anyone else.
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
`include "sf_pcie_regs.svh"
module sf_pcie_dma_submit #(
  parameter int NCTX      = 4,
  parameter int TOT_W     = 31,            // StreamDMA byte-count width
  parameter int AW        = 48,            // StreamDMA address width
  parameter int CPL_DEPTH = 4,
  parameter logic [3:0] HOST_MTYPE = `SFPB_SD_MT_DRAM
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              soft_rst,
  input  wire logic              cfg_dma_en,
  input  wire logic              wipe,              // pulse: StreamDMA / the adapter were wiped by a recovery: accepted-but-unfinished descriptors are LOST
  input  wire logic              rec_active,        // recovery in progress: submissions are refused
  // host register bus (offset inside the page; ctx = page - 1)
  input  wire logic              wr_valid,
  input  wire logic [3:0]        wr_ctx,
  /* verilator lint_off UNUSEDSIGNAL */  // registers are dword aligned
  input  wire logic [11:0]       wr_off,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [31:0]       wr_data,
  input  wire logic [3:0]        wr_strb,
  output logic                   wr_err,
  input  wire logic              rd_valid,
  input  wire logic [3:0]        rd_ctx,
  /* verilator lint_off UNUSEDSIGNAL */  // registers are dword aligned
  input  wire logic [11:0]       rd_off,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic                   rd_dvalid,
  output logic [31:0]            rd_data,
  output logic                   rd_err,
  // trusted context lookups
  output logic [3:0]             b_ctx,
  input  wire logic              b_valid, b_rd_ok, b_wr_ok, b_xlat,
  input  wire logic [63:0]       b_iova_base, b_iova_size, b_bus_base, b_dev_base, b_dev_size,
  input  wire logic [31:0]       b_max_len,
  output logic [3:0]             c_ctx,
  input  wire logic [3:0]        c_info,
  // StreamDMA descriptor + completion ports
  output logic                   sd_desc_valid,
  input  wire logic              sd_desc_ready,
  output logic [255:0]           sd_desc_data,
  output logic [3:0]             sd_desc_domain,
  input  wire logic              sd_cpl_valid,
  output logic                   sd_cpl_ready,
  input  wire logic [15:0]       sd_cpl_txn_id,
  input  wire logic [3:0]        sd_cpl_domain,
  input  wire logic [3:0]        sd_cpl_status,
  input  wire logic [7:0]        sd_cpl_err,
  input  wire logic [3:0]        sd_cpl_detail,
  input  wire logic [TOT_W-1:0]  sd_cpl_bytes_done,
  input  wire logic [TOT_W-1:0]  sd_cpl_bytes_total,
  input  wire logic [AW-1:0]     sd_cpl_err_addr,
  input  wire logic [31:0]       sd_cpl_latency,
  input  wire logic              sd_cpl_partial,
  // PCIe-side errors attributed to a domain (from the egress adapter / tag tracker)
  input  wire logic              pe_valid,
  input  wire logic [3:0]        pe_dom,
  input  wire logic [5:0]        pe_code,
  // events
  output logic                   ev_valid,          // a submission was rejected (log it)
  output logic [5:0]             ev_code,
  output logic [63:0]            ev_addr,
  output logic [3:0]             ev_ctx,
  output logic                   irq_cpl,           // pulse: a successful record was queued
  output logic                   irq_err,           // pulse: an error record was queued / a record was dropped
  output logic                   busy               // submission hold or any request pending (not quiescent)
);
  localparam int CW  = $clog2(CPL_DEPTH + 1);
  localparam int CXW = (NCTX > 1) ? $clog2(NCTX) : 1;

  // ---- staging registers ---------------------------------------------------------------------------------------------
  logic [31:0] desc [0:NCTX*8-1];
  logic [3:0]  sub_status [0:NCTX-1];
  logic [5:0]  sub_code   [0:NCTX-1];
  logic [15:0] pending    [0:NCTX-1];
  logic        ovf        [0:NCTX-1];
  logic        lost       [0:NCTX-1];
  logic [5:0]  last_perr  [0:NCTX-1];

  function automatic logic [31:0] merge(input logic [31:0] old, input logic [31:0] nw, input logic [3:0] st);
    merge = {st[3] ? nw[31:24] : old[31:24], st[2] ? nw[23:16] : old[23:16], st[1] ? nw[15:8] : old[15:8], st[0] ? nw[7:0] : old[7:0]};
  endfunction

  wire              wr_ctx_ok = (32'(wr_ctx) < NCTX);
  wire [CXW-1:0]    wci       = wr_ctx[CXW-1:0];
  wire [CXW-1:0]    rci       = rd_ctx[CXW-1:0];
  wire              sd_dom_ok = (32'(sd_cpl_domain) < NCTX);
  wire [CXW-1:0]    sdi       = sd_cpl_domain[CXW-1:0];
  wire              pe_dom_ok = (32'(pe_dom) < NCTX);
  wire [CXW-1:0]    pei       = pe_dom[CXW-1:0];
  wire [11:0]       woff      = {wr_off[11:2], 2'b00};
  wire [11:0]       roff      = {rd_off[11:2], 2'b00};
  wire              wr_is_desc = (woff < 12'h020);
  wire              wr_is_bell = (woff == `SFPB_C_DOORBELL);
  wire              wr_is_pop  = (woff == `SFPB_C_CPL_POP);
  always_comb begin
    wr_err = 1'b0;
    if (wr_valid) wr_err = !wr_ctx_ok || !(wr_is_desc || wr_is_bell || wr_is_pop);
  end

  // ---- descriptor validation (combinational on the context named by the doorbell) --------------------------------------
  logic [31:0] w [0:7];
  always_comb begin
    for (int i = 0; i < 8; i++) w[i] = '0;
    for (int i = 0; i < 8; i++) if (wr_ctx_ok) w[i] = desc[32'(wci) * 8 + i];
  end
  assign b_ctx = wr_ctx;
  assign c_ctx = rd_ctx;

  wire [3:0]  src_t   = w[2][3:0];
  wire [3:0]  dst_t   = w[2][7:4];
  wire        src_h   = (src_t == HOST_MTYPE);
  wire        dst_h   = (dst_t == HOST_MTYPE);
  wire [63:0] src_a   = {w[5], w[4]};
  wire [63:0] dst_a   = {w[7], w[6]};
  wire [63:0] host_a  = src_h ? src_a : dst_a;
  wire [63:0] dev_a   = src_h ? dst_a : src_a;
  wire [31:0] len     = w[3];

  logic        hw_ok;  logic [5:0] hw_err; logic [63:0] hw_bus;
  sf_pcie_win_check #(.BW(32)) u_hw (
    .valid(b_valid), .perm_ok(src_h ? b_rd_ok : b_wr_ok), .xlat(b_xlat), .iova_base(b_iova_base), .iova_size(b_iova_size),
    .bus_base(b_bus_base), .addr(host_a), .nbytes(len), .ok(hw_ok), .err(hw_err), .bus_addr(hw_bus));
  logic        dv_ok;  logic [5:0] dv_err; logic [63:0] dv_bus;
  sf_pcie_win_check #(.BW(32)) u_dv (
    .valid(b_valid), .perm_ok(1'b1), .xlat(1'b0), .iova_base(b_dev_base), .iova_size(b_dev_size),
    .bus_base(64'd0), .addr(dev_a), .nbytes(len), .ok(dv_ok), .err(dv_err), .bus_addr(dv_bus));

  logic [5:0] v_code;
  always_comb begin
    v_code = `SFPB_E_NONE;
    if (rec_active)                                                           v_code = `SFPB_E_DMA_RECOVERY;
    else if (!cfg_dma_en || !b_valid)                                         v_code = `SFPB_E_DMA_NO_CTX;
    else if (w[0][7:0] != `SFPB_SD_VERSION || w[0][15:8] != `SFPB_SD_OP_COPY)  v_code = `SFPB_E_DMA_BADFORMAT;
    else if ((w[0][31:16] & ~16'h001F) != 16'd0 || (w[0][17:16] != 2'b11))     v_code = `SFPB_E_DMA_BADFORMAT;  // FIRST|LAST required: single-descriptor transactions only
    else if (w[2][31:8] != 24'd0)                                             v_code = `SFPB_E_DMA_BADFORMAT;
    else if (w[1][31:16] != {12'd0, wr_ctx})                                  v_code = `SFPB_E_DMA_PERM;        // domain claim != the context's trusted domain
    else if (src_h == dst_h)                                                  v_code = `SFPB_E_DMA_BADMTYPE;    // exactly one side must be host memory
    else if (len == 32'd0 || len > b_max_len)                                 v_code = `SFPB_E_DMA_BADLEN;
    else if (!hw_ok)                                                          v_code = hw_err;
    else if (!dv_ok)                                                          v_code = (dv_err == `SFPB_E_DMA_BADLEN) ? `SFPB_E_DMA_BADLEN : `SFPB_E_DMA_WINDOW;
  end

  // ---- hold register toward StreamDMA ---------------------------------------------------------------------------------
  logic         hold_v;
  logic [255:0] hold_d;
  logic [3:0]   hold_dom;
  assign sd_desc_valid  = hold_v;
  assign sd_desc_data   = hold_d;
  assign sd_desc_domain = hold_dom;

  logic any_pending;
  always_comb begin
    any_pending = 1'b0;
    for (int i = 0; i < NCTX; i++) if (pending[i] != 16'd0) any_pending = 1'b1;
  end
  assign busy = hold_v || any_pending;

  // ---- completion queues (status is part of the stored record) ---------------------------------------------------------
  localparam int RW = 16 + 4 + 4 + 8 + 4 + 32 + 32 + 64 + 32 + 1 + 6;
  logic [NCTX-1:0]    q_in_v, q_in_r, q_out_v, q_pop;
  logic [RW-1:0]      q_out [0:NCTX-1];
  logic [CW-1:0]      q_level [0:NCTX-1];
  logic [CW-1:0]      q_peak  [0:NCTX-1];
  wire  [RW-1:0]      rec_in = {sd_cpl_txn_id, sd_cpl_domain, sd_cpl_status, sd_cpl_err, sd_cpl_detail, 32'(sd_cpl_bytes_done),
                                32'(sd_cpl_bytes_total), 64'(sd_cpl_err_addr), sd_cpl_latency, sd_cpl_partial,
                                sd_dom_ok ? last_perr[sdi] : 6'd0};
  generate
    for (genvar g = 0; g < NCTX; g++) begin : g_q
      sf_pcie_fifo #(.WIDTH(RW), .DEPTH(CPL_DEPTH)) u_q (
        .clk(clk), .rst_n(rst_n), .flush(soft_rst),
        .in_valid(q_in_v[g]), .in_ready(q_in_r[g]), .in_data(rec_in),
        .out_valid(q_out_v[g]), .out_ready(q_pop[g]), .out_data(q_out[g]), .level(q_level[g]), .peak(q_peak[g]));
    end
  endgenerate
  assign sd_cpl_ready = 1'b1;                                   // never back-pressure StreamDMA (isolation)
  always_comb begin
    q_in_v = '0;
    if (sd_cpl_valid && sd_dom_ok) q_in_v[sdi] = 1'b1;
    q_pop = '0;
    if (wr_valid && !wr_err && wr_is_pop && wr_strb[0] && wr_data[0]) q_pop[wci] = q_out_v[wci];
  end

  // head record of the context being read
  logic [RW-1:0] hrec;
  logic          hrec_v;
  always_comb begin
    hrec = '0; hrec_v = 1'b0;
    for (int i = 0; i < NCTX; i++) if (rd_ctx == 4'(i)) begin hrec = q_out[i]; hrec_v = q_out_v[i]; end
  end
  wire [15:0] h_txn   = hrec[RW-1   -: 16];
  wire [3:0]  h_dom   = hrec[RW-17  -: 4];
  wire [3:0]  h_stat  = hrec[RW-21  -: 4];
  wire [7:0]  h_err   = hrec[RW-25  -: 8];
  wire [3:0]  h_det   = hrec[RW-33  -: 4];
  wire [31:0] h_done  = hrec[RW-37  -: 32];
  wire [31:0] h_total = hrec[RW-69  -: 32];
  wire [63:0] h_eaddr = hrec[RW-101 -: 64];
  wire [31:0] h_lat   = hrec[RW-165 -: 32];
  wire        h_part  = hrec[6];
  wire [5:0]  h_perr  = hrec[5:0];

  // ---- sequential --------------------------------------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NCTX*8; i++) desc[i] <= '0;
      for (int i = 0; i < NCTX; i++) begin
        sub_status[i] <= '0; sub_code[i] <= '0; pending[i] <= '0; ovf[i] <= 1'b0; lost[i] <= 1'b0; last_perr[i] <= '0;
      end
      hold_v <= 1'b0; hold_d <= '0; hold_dom <= '0;
      ev_valid <= 1'b0; ev_code <= '0; ev_addr <= '0; ev_ctx <= '0; irq_cpl <= 1'b0; irq_err <= 1'b0;
      rd_dvalid <= 1'b0; rd_data <= '0; rd_err <= 1'b0;
    end else begin
      ev_valid <= 1'b0; irq_cpl <= 1'b0; irq_err <= 1'b0; rd_dvalid <= rd_valid; rd_err <= 1'b0;

      if (soft_rst) begin
        for (int i = 0; i < NCTX*8; i++) desc[i] <= '0;
        for (int i = 0; i < NCTX; i++) begin sub_status[i] <= '0; sub_code[i] <= '0; ovf[i] <= 1'b0; lost[i] <= 1'b0; end
      end

      if (pe_valid && pe_dom_ok) last_perr[pei] <= pe_code;
      if (hold_v && sd_desc_ready) hold_v <= 1'b0;
      if (wipe) begin                                                                  // lost descriptors are flagged, never reported as done
        for (int i = 0; i < NCTX; i++) begin
          if (pending[i] != 16'd0 || (hold_v && hold_dom == 4'(i))) lost[i] <= 1'b1;
          pending[i] <= 16'd0;
        end
        hold_v <= 1'b0;
      end

      // host writes
      if (wr_valid && !wr_err) begin
        if (wr_is_desc) desc[32'(wci) * 8 + 32'(woff[4:2])] <= merge(desc[32'(wci) * 8 + 32'(woff[4:2])], wr_data, wr_strb);
        if (wr_is_pop && wr_strb[0] && wr_data[1]) ovf[wci] <= 1'b0;
        if (wr_is_pop && wr_strb[0] && wr_data[2]) lost[wci] <= 1'b0;
        if (wr_is_bell && wr_strb[0] && wr_data[0]) begin
          if (v_code != `SFPB_E_NONE) begin
            sub_status[wci] <= 4'd3; sub_code[wci] <= v_code;
            ev_valid <= 1'b1; ev_code <= v_code; ev_addr <= host_a; ev_ctx <= wr_ctx;
          end else if (hold_v) begin
            sub_status[wci] <= 4'd2; sub_code[wci] <= `SFPB_E_NONE;                          // busy: retry
          end else begin
            sub_status[wci] <= 4'd1; sub_code[wci] <= `SFPB_E_NONE;
            hold_v <= 1'b1; hold_dom <= wr_ctx;
            hold_d <= {w[7], w[6], w[5], w[4], w[3], w[2], w[1], (w[0] | 32'h0008_0000)};   // CPL_EN forced: every transaction yields a record
            pending[wci] <= pending[wci] + 16'd1;
            last_perr[wci] <= '0;
          end
        end
      end

      // completion records
      if (sd_cpl_valid && sd_dom_ok) begin
        if (pending[sdi] != 16'd0) pending[sdi] <= pending[sdi] - 16'd1;
        if (q_in_r[sdi]) begin
          if (sd_cpl_status == 4'd0) irq_cpl <= 1'b1; else irq_err <= 1'b1;
        end else begin
          ovf[sdi] <= 1'b1; irq_err <= 1'b1;                                          // record lost: flagged, never silent
        end
      end

      // reads
      if (rd_valid) begin
        rd_data <= 32'd0;
        if (32'(rd_ctx) >= NCTX) rd_err <= 1'b1;
        else case (roff)
          `SFPB_C_DESC0, `SFPB_C_DESC1, `SFPB_C_DESC2, `SFPB_C_DESC3, `SFPB_C_DESC4, `SFPB_C_DESC5, `SFPB_C_DESC6, `SFPB_C_DESC7:
                                 rd_data <= desc[32'(rci) * 8 + 32'(roff[4:2])];
          `SFPB_C_SUBMIT_STATUS: rd_data <= {18'd0, sub_code[rci], 4'd0, sub_status[rci]};
          `SFPB_C_CPL_STATUS:    rd_data <= {pending[rci], 6'd0, lost[rci], ovf[rci], 4'd0, 4'(q_level[rci])};
          `SFPB_C_CPL_REC0:      rd_data <= hrec_v ? {h_part, 3'd0, h_stat, 4'd0, h_dom, h_txn} : 32'd0;
          `SFPB_C_CPL_REC1:      rd_data <= hrec_v ? {10'd0, h_perr, 4'd0, h_det, h_err} : 32'd0;
          `SFPB_C_CPL_REC2:      rd_data <= hrec_v ? h_done : 32'd0;
          `SFPB_C_CPL_REC3:      rd_data <= hrec_v ? h_total : 32'd0;
          `SFPB_C_CPL_REC4:      rd_data <= hrec_v ? h_eaddr[31:0] : 32'd0;
          `SFPB_C_CPL_REC5:      rd_data <= hrec_v ? h_eaddr[63:32] : 32'd0;
          `SFPB_C_CPL_REC6:      rd_data <= hrec_v ? h_lat : 32'd0;
          `SFPB_C_CTX_INFO:      rd_data <= {24'd0, rd_ctx, c_info};
          default:               rd_err <= 1'b1;                         // DOORBELL / CPL_POP are write-only
        endcase
      end
    end
  end
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = &{1'b0, dv_bus, hw_bus, q_peak[0], 1'b0};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
