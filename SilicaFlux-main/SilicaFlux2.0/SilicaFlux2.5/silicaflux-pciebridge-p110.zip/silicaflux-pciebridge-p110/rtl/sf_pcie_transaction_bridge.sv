// =============================================================================
// sf_pcie_transaction_bridge -- SilicaFlux Project 110: PCIe host transaction interface.  PRIMARY RTL.
//
//   PCIe endpoint IP (vendor, verified, NOT part of this project)
//     CQ  -> sf_pcie_request_adapter  -> sf_pcie_mmio_engine (classification, sf_pcie_bar_decoder) -> SFB2 (DataFabric)
//                                          sf_pcie_csr  /  sf_pcie_dma_submit + sf_pcie_dma_ctx (protected DMA)
//     CC  <- sf_pcie_completion_adapter  (completion formatter + posted-write ordering gate)  <- mmio engine
//     RQ  <- sf_pcie_dma_adapter  <- StreamDMA host-memory port               (endpoint-initiated DMA)
//     RC  -> sf_pcie_completion_adapter -> sf_pcie_tag_tracker (inside the DMA adapter)
//     MSI <- sf_pcie_interrupt_adapter
//
// This is a TRANSACTION-layer bridge.  It contains no PCIe link, data-link, PHY, SerDes or configuration-space logic and
// makes no PCIe compliance claim: it talks to the stream interfaces of a vendor endpoint core (AMD UltraScale+ style
// CQ/CC/RQ/RC, DWORD-aligned, 128/256-bit) that must be generated, configured and verified separately.
// See docs/ENDPOINT_INTEGRATION_GUIDE.md for the endpoint requirements and docs/00_AUDIT.md for what was and was not
// available when this was built.
// =============================================================================
`default_nettype none
`include "sf_pcie_defs.svh"
module sf_pcie_transaction_bridge #(
  parameter int DATA_W       = 256,            // endpoint stream width: 128 | 256
  parameter int TAGS         = 16,
  parameter int NCTX         = 4,
  parameter int MMIO_MAX_DW  = 64,
  parameter int CPL_MAX_DW   = 32,
  parameter int SFB_MAX_OUT  = 2,
  parameter int BAR_REG_ID   = 0,
  parameter int BAR_REG_AP   = 16,
  parameter int BAR_MEM_ID   = 2,
  parameter int BAR_MEM_AP   = 20,
  parameter int FREG_OFF     = 32'h8000,
  parameter int FREG_SIZE    = 32'h8000,
  parameter logic [31:0] SFB_REG_BASE = 32'h4000_0000,
  parameter logic [31:0] SFB_MEM_BASE = 32'h8000_0000,
  parameter int DMA_DW       = 128,
  parameter int AW           = 48,             // StreamDMA address width
  parameter int TOT_W        = 31,             // StreamDMA byte-count width (MAX_TXN_LOG2 + 1)
  parameter int RD_SLOTS     = 4,
  parameter int WR_SLOTS     = 4,
  parameter int BURST_LEN    = 16,
  parameter int DOM_W        = 4,
  parameter int ORD_W        = 8,
  parameter int ORD_TIMEOUT  = 4096,
  parameter int TICK_LOG2    = 8,
  parameter int RQ_ACK_ON_ACCEPT = 0,
  parameter int CQ_USER_W    = 85,
  parameter int CC_USER_W    = 33,
  parameter int RQ_USER_W    = 62,
  parameter int RC_USER_W    = 75,
  parameter int CQ_DISC_BIT  = 41,
  parameter int RC_DISC_BIT  = -1,
  parameter int DRAIN_TIMEOUT = 65536,
  parameter logic [3:0] HOST_MTYPE = `SFPB_SD_MT_DRAM,
  localparam int K           = DATA_W / 32,
  localparam int RIDW        = (RD_SLOTS > 1) ? $clog2(RD_SLOTS) : 1,
  localparam int WIDW        = (WR_SLOTS > 1) ? $clog2(WR_SLOTS) : 1,
  localparam int BEAT_B      = DMA_DW / 8
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,           // active low; asynchronous assert, synchronous release done by the integrator
  // ---- endpoint: Completer Request (CQ) -----------------------------------------------------------------------------
  input  wire logic [DATA_W-1:0]       s_axis_cq_tdata,
  input  wire logic [K-1:0]            s_axis_cq_tkeep,
  input  wire logic                    s_axis_cq_tlast,
  input  wire logic [CQ_USER_W-1:0]    s_axis_cq_tuser,
  input  wire logic                    s_axis_cq_tvalid,
  output logic                         s_axis_cq_tready,
  // ---- endpoint: Completer Completion (CC) --------------------------------------------------------------------------
  output logic [DATA_W-1:0]            m_axis_cc_tdata,
  output logic [K-1:0]                 m_axis_cc_tkeep,
  output logic                         m_axis_cc_tlast,
  output logic [CC_USER_W-1:0]         m_axis_cc_tuser,
  output logic                         m_axis_cc_tvalid,
  input  wire logic                    m_axis_cc_tready,
  // ---- endpoint: Requester Request (RQ) -----------------------------------------------------------------------------
  output logic [DATA_W-1:0]            m_axis_rq_tdata,
  output logic [K-1:0]                 m_axis_rq_tkeep,
  output logic                         m_axis_rq_tlast,
  output logic [RQ_USER_W-1:0]         m_axis_rq_tuser,
  output logic                         m_axis_rq_tvalid,
  input  wire logic                    m_axis_rq_tready,
  input  wire logic [5:0]              rq_seq_num0,
  input  wire logic                    rq_seq_vld0,
  input  wire logic [5:0]              rq_seq_num1,
  input  wire logic                    rq_seq_vld1,
  // ---- endpoint: Requester Completion (RC) --------------------------------------------------------------------------
  input  wire logic [DATA_W-1:0]       s_axis_rc_tdata,
  input  wire logic [K-1:0]            s_axis_rc_tkeep,
  input  wire logic                    s_axis_rc_tlast,
  input  wire logic [RC_USER_W-1:0]    s_axis_rc_tuser,
  input  wire logic                    s_axis_rc_tvalid,
  output logic                         s_axis_rc_tready,
  // ---- endpoint: configuration / status / flow control (read-only observation of the endpoint) -----------------------
  input  wire logic                    ep_link_up,
  input  wire logic                    ep_flr_in_process,
  output logic                         ep_flr_done,
  input  wire logic [2:0]              cfg_max_payload,     // 0:128 B .. 5:4096 B
  input  wire logic [2:0]              cfg_max_read_req,
  input  wire logic [15:0]             cfg_req_id,          // requester id the endpoint uses (bus/dev/func)
  input  wire logic                    cfg_check_reqid,
  input  wire logic                    fc_np_ok,            // flow-control credit hints (tie high if the stream back-pressures)
  input  wire logic                    fc_p_ok,
  // ---- endpoint: MSI request interface --------------------------------------------------------------------------------
  input  wire logic                    msi_enable,
  input  wire logic [2:0]              msi_mmenable,
  output logic [31:0]                  msi_int,
  input  wire logic                    msi_sent,
  input  wire logic                    msi_fail,
  // ---- DataFabric (SFB2 master, 32-bit) -------------------------------------------------------------------------------
  output logic                         sfb_req_valid,
  input  wire logic                    sfb_req_ready,
  output logic                         sfb_req_write,
  output logic [31:0]                  sfb_req_addr,
  output logic [31:0]                  sfb_req_wdata,
  output logic [3:0]                   sfb_req_wstrb,
  input  wire logic                    sfb_rsp_valid,
  output logic                         sfb_rsp_ready,
  input  wire logic [31:0]             sfb_rsp_rdata,
  input  wire logic                    sfb_rsp_error,
  // ---- StreamDMA control / descriptor / completion ----------------------------------------------------------------------
  output logic                         dma_desc_valid,
  input  wire logic                    dma_desc_ready,
  output logic [255:0]                 dma_desc_data,
  output logic [DOM_W-1:0]             dma_desc_domain,
  input  wire logic                    dma_cpl_valid,
  output logic                         dma_cpl_ready,
  input  wire logic [15:0]             dma_cpl_txn_id,
  input  wire logic [DOM_W-1:0]        dma_cpl_domain,
  input  wire logic [3:0]              dma_cpl_status,
  input  wire logic [7:0]              dma_cpl_err,
  input  wire logic [3:0]              dma_cpl_detail,
  input  wire logic [TOT_W-1:0]        dma_cpl_bytes_done,
  input  wire logic [TOT_W-1:0]        dma_cpl_bytes_total,
  input  wire logic [AW-1:0]           dma_cpl_err_addr,
  input  wire logic [31:0]             dma_cpl_latency,
  input  wire logic                    dma_cpl_partial,
  input  wire logic                    dma_irq,
  output logic                         dma_ctl_abort,
  output logic                         dma_ctl_soft_reset,
  output logic [31:0]                  dma_cfg_timeout,
  output logic [15:0]                  dma_cfg_type_en,
  output logic [5:0]                   dma_perf_sel,
  input  wire logic [63:0]             dma_perf_data,
  input  wire logic                    dma_busy,
  input  wire logic                    dma_fenced,
  input  wire logic                    dma_proto_err,
  input  wire logic                    dma_soft_pend,
  input  wire logic                    dma_soft_active,     // StreamDMA's core is being reset in this cycle: its AR/AW/W streams restart clean
  // ---- StreamDMA host-memory port (this bridge is the memory-side slave for HOST-typed accesses) ------------------------
  input  wire logic                    h_ar_valid,
  output logic                         h_ar_ready,
  input  wire logic [RIDW-1:0]         h_ar_id,
  input  wire logic [AW-1:0]           h_ar_addr,
  input  wire logic [7:0]              h_ar_len,
  input  wire logic [2:0]              h_ar_size,
  input  wire logic [1:0]              h_ar_burst,
  input  wire logic [3:0]              h_ar_mtype,
  input  wire logic [DOM_W-1:0]        h_ar_domain,
  output logic                         h_r_valid,
  input  wire logic                    h_r_ready,
  output logic [RIDW-1:0]              h_r_id,
  output logic [DMA_DW-1:0]            h_r_data,
  output logic [1:0]                   h_r_resp,
  output logic                         h_r_last,
  input  wire logic                    h_aw_valid,
  output logic                         h_aw_ready,
  input  wire logic [WIDW-1:0]         h_aw_id,
  input  wire logic [AW-1:0]           h_aw_addr,
  input  wire logic [7:0]              h_aw_len,
  input  wire logic [2:0]              h_aw_size,
  input  wire logic [1:0]              h_aw_burst,
  input  wire logic [3:0]              h_aw_mtype,
  input  wire logic [DOM_W-1:0]        h_aw_domain,
  input  wire logic                    h_w_valid,
  output logic                         h_w_ready,
  input  wire logic [DMA_DW-1:0]       h_w_data,
  input  wire logic [BEAT_B-1:0]       h_w_strb,
  input  wire logic                    h_w_last,
  output logic                         h_b_valid,
  input  wire logic                    h_b_ready,
  output logic [WIDW-1:0]              h_b_id,
  output logic [1:0]                   h_b_resp,
  // ---- privileged configuration port (ControlCore / secure side) ------------------------------------------------------
  input  wire logic                    priv_req_valid,
  output logic                         priv_req_ready,
  input  wire logic                    priv_req_write,
  input  wire logic [11:0]             priv_req_addr,
  input  wire logic [31:0]             priv_req_wdata,
  output logic                         priv_rsp_valid,
  input  wire logic                    priv_rsp_ready,
  output logic [31:0]                  priv_rsp_rdata,
  output logic                         priv_rsp_error,
  // ---- misc -------------------------------------------------------------------------------------------------------------
  input  wire logic [2:0]              irq_ext,
  output logic                         irq_level,           // INTx-style level (for INTx-capable endpoints)
  output logic [3:0]                   rec_state,
  output logic                         rec_flush_mmio,
  output logic                         rec_flush_dma
);
  localparam int NEV  = 8;
  localparam int MAXB = (MMIO_MAX_DW + K - 1) / K;
  localparam int PLW  = $clog2(MAXB + 1) + $clog2(2 * MAXB + 2) + 1;

  // ===========================================================================================================
  // recovery (reset / FLR / link down / soft reset)
  // ===========================================================================================================
  logic        ctl_soft_reset, ctl_fatal_clr, ctl_perf_clear, ctl_zombie_clr, ctl_dma_abort_csr, ctl_dma_soft_csr;
  logic [31:0] cfg_rec_quiet;
  logic        fl_mmio, fl_dma, dma_clr, rec_zombie_clr, rec_soft_rst, rec_dma_abort, rec_dma_soft, rec_done_ev;
  logic        rec_ev_valid; logic [5:0] rec_ev_code;
  logic        eng_idle, cc_idle, dma_idle, trk_flushing;
  logic [8:0]  trk_out;

  logic        link_q, flr_q;
  logic [3:0]  rst_st;
  logic [31:0] rst_cnt;
  logic        rst_dma_only, rst_host_reset;
  logic        fault_link, fault_flr, fault_soft;
  assign fault_link = link_q && !ep_link_up;
  assign fault_flr  = !flr_q && ep_flr_in_process;
  assign fault_soft = ctl_soft_reset;
  wire   dma_soft_req = ctl_dma_soft_csr;                 // CSR DMA_CTRL.SOFT_RESET: recover the DMA path only

  assign rec_state      = rst_st;
  assign rec_flush_mmio = fl_mmio;
  assign rec_flush_dma  = fl_dma;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rst_st <= `SFPB_REC_RUN; rst_cnt <= '0; rst_dma_only <= 1'b0; rst_host_reset <= 1'b0; link_q <= 1'b1; flr_q <= 1'b0;
      fl_mmio <= 1'b0; fl_dma <= 1'b0; dma_clr <= 1'b0; rec_zombie_clr <= 1'b0; rec_soft_rst <= 1'b0; rec_dma_abort <= 1'b0;
      rec_dma_soft <= 1'b0; rec_ev_valid <= 1'b0; rec_ev_code <= '0; rec_done_ev <= 1'b0; ep_flr_done <= 1'b0;
    end else begin
      link_q <= ep_link_up; flr_q <= ep_flr_in_process;
      dma_clr <= 1'b0; rec_zombie_clr <= 1'b0; rec_soft_rst <= 1'b0; rec_dma_abort <= 1'b0; rec_dma_soft <= 1'b0;
      rec_ev_valid <= 1'b0; rec_done_ev <= 1'b0;
      case (rst_st)
        `SFPB_REC_RUN: begin
          ep_flr_done <= 1'b0;
          if (fault_link || fault_flr || fault_soft || dma_soft_req) begin
            rst_st <= `SFPB_REC_QUIESCE; rst_cnt <= '0;
            rst_dma_only <= dma_soft_req && !(fault_link || fault_flr || fault_soft);
            rst_host_reset <= fault_flr || fault_soft;                                   // link loss alone keeps host-visible CSR state
            fl_dma <= 1'b1; fl_mmio <= !(dma_soft_req && !(fault_link || fault_flr || fault_soft));
            rec_dma_abort <= 1'b1;
            rec_ev_valid <= 1'b1;
            rec_ev_code <= fault_link ? `SFPB_E_LINK_DOWN : fault_flr ? `SFPB_E_FLR : `SFPB_E_SOFT_RESET;
          end
        end
        `SFPB_REC_QUIESCE: begin
          // wait for the endpoint-facing machines to drain; the DMA gets one chance to finish by itself
          rst_cnt <= rst_cnt + 32'd1;
          if ((eng_idle || rst_dma_only) && (cc_idle || rst_dma_only) && dma_idle && !trk_flushing && (trk_out == 9'd0) && !dma_busy) rst_st <= `SFPB_REC_DMA_DRAIN;
          else if (rst_cnt >= 32'(DRAIN_TIMEOUT)) begin
            rst_st <= `SFPB_REC_DMA_DRAIN;
            rec_ev_valid <= 1'b1; rec_ev_code <= `SFPB_E_FAB_TIMEOUT;                // drain timeout is reported, never hidden
          end
        end
        `SFPB_REC_DMA_DRAIN: begin
          dma_clr <= 1'b1; rec_dma_soft <= 1'b1;                                    // wipe the adapter, reset StreamDMA's core
          rst_cnt <= '0; rst_st <= rst_dma_only ? `SFPB_REC_QUIET : `SFPB_REC_WAIT_LINK;
          if (!rst_dma_only) rec_soft_rst <= rst_host_reset;
        end
        `SFPB_REC_WAIT_LINK: begin
          if (ep_flr_in_process) ep_flr_done <= 1'b1;                                // function-level cleanup finished
          if (ep_link_up && !ep_flr_in_process) begin rst_st <= `SFPB_REC_QUIET; rst_cnt <= '0; end
          if (fault_soft) begin rst_cnt <= '0; end
        end
        `SFPB_REC_QUIET: begin
          rst_cnt <= rst_cnt + 32'd1;
          if (!rst_dma_only && (!ep_link_up || ep_flr_in_process)) rst_st <= `SFPB_REC_WAIT_LINK;
          else if (rst_cnt >= cfg_rec_quiet) begin
            rec_zombie_clr <= 1'b1; rec_done_ev <= 1'b1; rst_st <= `SFPB_REC_DONE;
            rec_ev_valid <= 1'b1; rec_ev_code <= `SFPB_E_RECOVERED;                 // sticky ERR_STATUS.RECOVERED: the host must re-initialise
          end
        end
        default: begin                                                              // DONE: release the machines
          fl_mmio <= 1'b0; fl_dma <= 1'b0; rst_st <= `SFPB_REC_RUN;
        end
      endcase
    end
  end

  // ===========================================================================================================
  // CQ -> request adapter -> MMIO engine
  // ===========================================================================================================
  logic              req_valid, req_ready, req_poison, req_bad, req_has_pay;
  logic [3:0]        req_type, req_first_be, req_last_be;
  logic [63:0]       req_addr;
  logic [10:0]       req_ndw;
  logic [7:0]        req_tag, req_func;
  logic [15:0]       req_reqid;
  logic [2:0]        req_tc, req_attr, req_bar_id;
  logic [1:0]        req_at;
  logic [5:0]        req_bar_ap, req_code;
  logic              pay_valid, pay_ready, pay_last;
  logic [DATA_W-1:0] pay_data;
  logic [$clog2(K+1)-1:0] pay_ndw;
  logic              st_cq_tlp, st_cq_bad;
  logic [PLW-1:0]    st_pay_level;
  logic [3:0]        st_hdr_level;

  sf_pcie_request_adapter #(.DATA_W(DATA_W), .CQ_USER_W(CQ_USER_W), .CQ_DISC_BIT(CQ_DISC_BIT), .MAX_PAY_DW(MMIO_MAX_DW)) u_req (
    .clk(clk), .rst_n(rst_n), .flush(fl_mmio),
    .s_cq_tdata(s_axis_cq_tdata), .s_cq_tkeep(s_axis_cq_tkeep), .s_cq_tlast(s_axis_cq_tlast), .s_cq_tuser(s_axis_cq_tuser),
    .s_cq_tvalid(s_axis_cq_tvalid), .s_cq_tready(s_axis_cq_tready),
    .req_valid(req_valid), .req_ready(req_ready), .req_type(req_type), .req_addr(req_addr), .req_ndw(req_ndw),
    .req_first_be(req_first_be), .req_last_be(req_last_be), .req_tag(req_tag), .req_reqid(req_reqid), .req_tc(req_tc),
    .req_attr(req_attr), .req_at(req_at), .req_poison(req_poison), .req_bar_id(req_bar_id), .req_bar_ap(req_bar_ap),
    .req_func(req_func), .req_bad(req_bad), .req_code(req_code), .req_has_pay(req_has_pay),
    .pay_valid(pay_valid), .pay_ready(pay_ready), .pay_data(pay_data), .pay_ndw(pay_ndw), .pay_last(pay_last),
    .st_tlp(st_cq_tlp), .st_bad(st_cq_bad), .st_pay_level(st_pay_level), .st_hdr_level(st_hdr_level));

  // completion beat stream from the engine
  logic              cpl_valid, cpl_ready, cpl_sop, cpl_eop;
  logic [DATA_W-1:0] cpl_data;
  logic [$clog2(K+1)-1:0] cpl_ndw;
  logic [2:0]        cpl_status, cpl_tc, cpl_attr;
  logic [6:0]        cpl_lower;
  logic [12:0]       cpl_bytecnt;
  logic [10:0]       cpl_dwcnt;
  logic [15:0]       cpl_reqid;
  logic [7:0]        cpl_tag;

  // register bus
  logic              csr_wr_valid, csr_rd_valid, csr_wr_err, csr_rd_dvalid, csr_rd_err;
  logic [15:0]       csr_wr_addr, csr_rd_addr;
  logic [31:0]       csr_wr_data, csr_rd_data;
  logic [3:0]        csr_wr_strb;

  logic              eng_fatal, ev0_valid;
  logic [5:0]        ev0_code; logic [63:0] ev0_addr; logic [7:0] ev0_tag; logic [15:0] ev0_rid; logic [3:0] ev0_type;
  logic              ev_rd_valid, ev_wr_valid, ev_exec_rd, ev_exec_wr;
  logic [15:0]       ev_rd_lat, ev_wr_lat;
  logic              cfg_fwin_rd_en, cfg_fwin_wr_en, cfg_dma_en, cfg_wr_flush_en, cfg_tc_any, cfg_perf_en;
  logic [31:0]       cfg_cpl_timeout, cfg_sfb_timeout, cfg_dma_timeout_w;
  logic [10:0]       cfg_mps_dw, cfg_mrrs_dw;
  assign cfg_mps_dw  = 11'd32 << cfg_max_payload;
  assign cfg_mrrs_dw = 11'd32 << cfg_max_read_req;

  sf_pcie_mmio_engine #(.DATA_W(DATA_W), .MMIO_MAX_DW(MMIO_MAX_DW), .CPL_MAX_DW(CPL_MAX_DW), .SFB_MAX_OUT(SFB_MAX_OUT), .NCTX(NCTX),
                        .BAR_REG_ID(BAR_REG_ID), .BAR_REG_AP(BAR_REG_AP), .BAR_MEM_ID(BAR_MEM_ID), .BAR_MEM_AP(BAR_MEM_AP),
                        .FREG_OFF(FREG_OFF), .FREG_SIZE(FREG_SIZE), .SFB_REG_BASE(SFB_REG_BASE), .SFB_MEM_BASE(SFB_MEM_BASE)) u_eng (
    .clk(clk), .rst_n(rst_n), .flush(fl_mmio),
    .req_valid(req_valid), .req_ready(req_ready), .req_type(req_type), .req_addr(req_addr), .req_ndw(req_ndw),
    .req_first_be(req_first_be), .req_last_be(req_last_be), .req_tag(req_tag), .req_reqid(req_reqid), .req_tc(req_tc),
    .req_attr(req_attr), .req_at(req_at), .req_poison(req_poison), .req_bar_id(req_bar_id), .req_bar_ap(req_bar_ap),
    .req_bad(req_bad), .req_code(req_code), .req_has_pay(req_has_pay),
    .pay_valid(pay_valid), .pay_ready(pay_ready), .pay_data(pay_data), .pay_ndw(pay_ndw), .pay_last(pay_last),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_sop(cpl_sop), .cpl_eop(cpl_eop), .cpl_data(cpl_data), .cpl_ndw(cpl_ndw),
    .cpl_status(cpl_status), .cpl_lower(cpl_lower), .cpl_bytecnt(cpl_bytecnt), .cpl_dwcnt(cpl_dwcnt), .cpl_reqid(cpl_reqid),
    .cpl_tag(cpl_tag), .cpl_tc(cpl_tc), .cpl_attr(cpl_attr),
    .csr_wr_valid(csr_wr_valid), .csr_wr_addr(csr_wr_addr), .csr_wr_data(csr_wr_data), .csr_wr_strb(csr_wr_strb), .csr_wr_err(csr_wr_err),
    .csr_rd_valid(csr_rd_valid), .csr_rd_addr(csr_rd_addr), .csr_rd_dvalid(csr_rd_dvalid), .csr_rd_data(csr_rd_data), .csr_rd_err(csr_rd_err),
    .sfb_req_valid(sfb_req_valid), .sfb_req_ready(sfb_req_ready), .sfb_req_write(sfb_req_write), .sfb_req_addr(sfb_req_addr),
    .sfb_req_wdata(sfb_req_wdata), .sfb_req_wstrb(sfb_req_wstrb), .sfb_rsp_valid(sfb_rsp_valid), .sfb_rsp_ready(sfb_rsp_ready),
    .sfb_rsp_rdata(sfb_rsp_rdata), .sfb_rsp_error(sfb_rsp_error),
    .cfg_fwin_rd_en(cfg_fwin_rd_en), .cfg_fwin_wr_en(cfg_fwin_wr_en), .cfg_tc_any(cfg_tc_any), .cfg_sfb_timeout(cfg_sfb_timeout),
    .cfg_mps_dw(cfg_mps_dw), .fatal_clr(ctl_fatal_clr),
    .st_fatal(eng_fatal), .idle(eng_idle),
    .ev_err_valid(ev0_valid), .ev_err_code(ev0_code), .ev_err_addr(ev0_addr), .ev_err_tag(ev0_tag), .ev_err_reqid(ev0_rid), .ev_err_type(ev0_type),
    .ev_rd_valid(ev_rd_valid), .ev_rd_lat(ev_rd_lat), .ev_wr_valid(ev_wr_valid), .ev_wr_lat(ev_wr_lat),
    .ev_exec_rd(ev_exec_rd), .ev_exec_wr(ev_exec_wr));

  // ===========================================================================================================
  // completion adapter (CC formatter + RC parser)
  // ===========================================================================================================
  logic [ORD_W-1:0]  ord_issued, ord_acked;
  logic              cc_ord_stall, st_cc_tlp;
  logic              rcv_valid, rcv_ready, rcv_sop, rcv_eop, rcv_bad, rcv_req_done, rcv_poison;
  logic [DATA_W-1:0] rcv_data;
  logic [$clog2(K+1)-1:0] rcv_ndw;
  logic [6:0]        rcv_lower;
  logic [3:0]        rcv_err;
  logic [12:0]       rcv_bytecnt;
  logic [10:0]       rcv_dwcnt;
  logic [2:0]        rcv_status, rcv_tc, rcv_attr;
  logic [15:0]       rcv_reqid;
  logic [7:0]        rcv_tag;

  sf_pcie_completion_adapter #(.DATA_W(DATA_W), .CC_USER_W(CC_USER_W), .RC_USER_W(RC_USER_W), .RC_DISC_BIT(RC_DISC_BIT), .ORD_W(ORD_W)) u_cpl (
    .clk(clk), .rst_n(rst_n), .flush_tx(fl_mmio), .flush_rx(fl_dma),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_sop(cpl_sop), .cpl_eop(cpl_eop), .cpl_data(cpl_data), .cpl_ndw(cpl_ndw),
    .cpl_status(cpl_status), .cpl_lower(cpl_lower), .cpl_bytecnt(cpl_bytecnt), .cpl_dwcnt(cpl_dwcnt), .cpl_reqid(cpl_reqid),
    .cpl_tag(cpl_tag), .cpl_tc(cpl_tc), .cpl_attr(cpl_attr),
    .ord_issued(ord_issued), .ord_acked(ord_acked), .ord_stall(cc_ord_stall),
    .m_cc_tdata(m_axis_cc_tdata), .m_cc_tkeep(m_axis_cc_tkeep), .m_cc_tlast(m_axis_cc_tlast), .m_cc_tuser(m_axis_cc_tuser),
    .m_cc_tvalid(m_axis_cc_tvalid), .m_cc_tready(m_axis_cc_tready), .st_cc_tlp(st_cc_tlp), .cc_idle(cc_idle),
    .s_rc_tdata(s_axis_rc_tdata), .s_rc_tkeep(s_axis_rc_tkeep), .s_rc_tlast(s_axis_rc_tlast), .s_rc_tuser(s_axis_rc_tuser),
    .s_rc_tvalid(s_axis_rc_tvalid), .s_rc_tready(s_axis_rc_tready),
    .rcv_valid(rcv_valid), .rcv_ready(rcv_ready), .rcv_sop(rcv_sop), .rcv_eop(rcv_eop), .rcv_data(rcv_data), .rcv_ndw(rcv_ndw),
    .rcv_bad(rcv_bad), .rcv_lower(rcv_lower), .rcv_err(rcv_err), .rcv_bytecnt(rcv_bytecnt), .rcv_req_done(rcv_req_done),
    .rcv_dwcnt(rcv_dwcnt), .rcv_status(rcv_status), .rcv_poison(rcv_poison), .rcv_reqid(rcv_reqid), .rcv_tag(rcv_tag),
    .rcv_tc(rcv_tc), .rcv_attr(rcv_attr));

  // ===========================================================================================================
  // DMA: context table, submission pages, adapter
  // ===========================================================================================================
  logic [3:0]  a_ctx, b_ctx, c_ctx, c_info;
  logic        a_valid, a_rd_ok, a_wr_ok, a_xlat, b_valid, b_rd_ok, b_wr_ok, b_xlat;
  logic [63:0] a_iova_base, a_iova_size, a_bus_base, a_dev_base, a_dev_size, b_iova_base, b_iova_size, b_bus_base, b_dev_base, b_dev_size;
  logic [31:0] a_max_len, b_max_len;
  logic        sub_busy;

  sf_pcie_dma_ctx #(.NCTX(NCTX)) u_ctx (
    .clk(clk), .rst_n(rst_n), .quiescent(dma_idle && !sub_busy && !dma_busy),
    .priv_req_valid(priv_req_valid), .priv_req_ready(priv_req_ready), .priv_req_write(priv_req_write), .priv_req_addr(priv_req_addr),
    .priv_req_wdata(priv_req_wdata), .priv_rsp_valid(priv_rsp_valid), .priv_rsp_ready(priv_rsp_ready), .priv_rsp_rdata(priv_rsp_rdata),
    .priv_rsp_error(priv_rsp_error),
    .a_ctx(a_ctx), .a_valid(a_valid), .a_rd_ok(a_rd_ok), .a_wr_ok(a_wr_ok), .a_xlat(a_xlat), .a_iova_base(a_iova_base),
    .a_iova_size(a_iova_size), .a_bus_base(a_bus_base), .a_dev_base(a_dev_base), .a_dev_size(a_dev_size), .a_max_len(a_max_len),
    .b_ctx(b_ctx), .b_valid(b_valid), .b_rd_ok(b_rd_ok), .b_wr_ok(b_wr_ok), .b_xlat(b_xlat), .b_iova_base(b_iova_base),
    .b_iova_size(b_iova_size), .b_bus_base(b_bus_base), .b_dev_base(b_dev_base), .b_dev_size(b_dev_size), .b_max_len(b_max_len),
    .c_ctx(c_ctx), .c_info(c_info));

  // register-bus demux: page 0 = global CSR, page 1+c = DMA submission page of context c
  wire [3:0]  wr_page = csr_wr_addr[15:12];
  wire [3:0]  rd_page = csr_rd_addr[15:12];
  logic       csr_g_wr_err, csr_g_dv, csr_g_rerr, sub_wr_err, sub_dv, sub_rerr;
  logic [31:0] csr_g_rd, sub_rd;
  assign csr_wr_err    = (wr_page == 4'd0) ? csr_g_wr_err : sub_wr_err;
  assign csr_rd_dvalid = csr_g_dv | sub_dv;
  assign csr_rd_data   = csr_g_dv ? csr_g_rd : sub_rd;
  assign csr_rd_err    = csr_g_dv ? csr_g_rerr : sub_rerr;

  logic        sub_ev_valid, sub_irq_cpl, sub_irq_err; logic [5:0] sub_ev_code; logic [63:0] sub_ev_addr; logic [3:0] sub_ev_ctx;
  logic        pe_valid; logic [3:0] pe_dom; logic [5:0] pe_code;

  sf_pcie_dma_submit #(.NCTX(NCTX), .TOT_W(TOT_W), .AW(AW), .HOST_MTYPE(HOST_MTYPE)) u_sub (
    .clk(clk), .rst_n(rst_n), .soft_rst(rec_soft_rst), .cfg_dma_en(cfg_dma_en), .wipe(dma_clr), .rec_active(fl_dma),
    .wr_valid(csr_wr_valid && (wr_page != 4'd0)), .wr_ctx(wr_page - 4'd1), .wr_off(csr_wr_addr[11:0]), .wr_data(csr_wr_data),
    .wr_strb(csr_wr_strb), .wr_err(sub_wr_err),
    .rd_valid(csr_rd_valid && (rd_page != 4'd0)), .rd_ctx(rd_page - 4'd1), .rd_off(csr_rd_addr[11:0]), .rd_dvalid(sub_dv),
    .rd_data(sub_rd), .rd_err(sub_rerr),
    .b_ctx(b_ctx), .b_valid(b_valid), .b_rd_ok(b_rd_ok), .b_wr_ok(b_wr_ok), .b_xlat(b_xlat), .b_iova_base(b_iova_base),
    .b_iova_size(b_iova_size), .b_bus_base(b_bus_base), .b_dev_base(b_dev_base), .b_dev_size(b_dev_size), .b_max_len(b_max_len),
    .c_ctx(c_ctx), .c_info(c_info),
    .sd_desc_valid(dma_desc_valid), .sd_desc_ready(dma_desc_ready), .sd_desc_data(dma_desc_data), .sd_desc_domain(dma_desc_domain),
    .sd_cpl_valid(dma_cpl_valid), .sd_cpl_ready(dma_cpl_ready), .sd_cpl_txn_id(dma_cpl_txn_id), .sd_cpl_domain(dma_cpl_domain),
    .sd_cpl_status(dma_cpl_status), .sd_cpl_err(dma_cpl_err), .sd_cpl_detail(dma_cpl_detail), .sd_cpl_bytes_done(dma_cpl_bytes_done),
    .sd_cpl_bytes_total(dma_cpl_bytes_total), .sd_cpl_err_addr(dma_cpl_err_addr), .sd_cpl_latency(dma_cpl_latency),
    .sd_cpl_partial(dma_cpl_partial),
    .pe_valid(pe_valid), .pe_dom(pe_dom), .pe_code(pe_code),
    .ev_valid(sub_ev_valid), .ev_code(sub_ev_code), .ev_addr(sub_ev_addr), .ev_ctx(sub_ev_ctx),
    .irq_cpl(sub_irq_cpl), .irq_err(sub_irq_err), .busy(sub_busy));

  logic        dmaev_valid, dmaev_write; logic [5:0] dmaev_code; logic [3:0] dmaev_dom; logic [63:0] dmaev_addr;
  logic        eve_valid, evc_valid, evb_valid, evo_valid, dg_valid;
  logic [5:0]  eve_code, evc_code, evb_code, evo_code, dg_code;
  logic [63:0] eve_addr, evc_addr, evb_addr; logic [3:0] eve_ctx, evc_ctx, evb_ctx; logic [7:0] dg_tag;
  logic        st_active, st_rq_mrd, st_rq_mwr, st_lat_valid, st_tag_stall, st_cred_stall, st_rq_bp;
  logic [15:0] st_rd_bytes, st_wr_bytes, st_pay_bytes, st_lat;
  logic [7:0]  st_hdr_bytes;
  /* verilator lint_off UNUSEDSIGNAL */  // only the low 8 bits are reported in STATUS
  logic [8:0]  st_zombie;
  /* verilator lint_on UNUSEDSIGNAL */

  sf_pcie_dma_adapter #(.DATA_W(DATA_W), .DMA_DW(DMA_DW), .AW(AW), .RD_SLOTS(RD_SLOTS), .WR_SLOTS(WR_SLOTS), .BURST_LEN(BURST_LEN),
                        .DOM_W(DOM_W), .TAGS(TAGS), .ORD_W(ORD_W), .RQ_USER_W(RQ_USER_W), .RQ_ACK_ON_ACCEPT(RQ_ACK_ON_ACCEPT),
                        .ORD_TIMEOUT(ORD_TIMEOUT), .TICK_LOG2(TICK_LOG2), .HOST_MTYPE(HOST_MTYPE)) u_dma (
    .clk(clk), .rst_n(rst_n), .flush(fl_dma), .clr(dma_clr | dma_soft_active), .cfg_dma_en(cfg_dma_en), .cfg_wr_flush_en(cfg_wr_flush_en),
    .cfg_mps_dw(cfg_mps_dw), .cfg_mrrs_dw(cfg_mrrs_dw), .rq_np_ok(fc_np_ok), .rq_p_ok(fc_p_ok),
    .a_ctx(a_ctx), .a_valid(a_valid), .a_rd_ok(a_rd_ok), .a_wr_ok(a_wr_ok), .a_xlat(a_xlat), .a_iova_base(a_iova_base),
    .a_iova_size(a_iova_size), .a_bus_base(a_bus_base),
    .ar_valid(h_ar_valid), .ar_ready(h_ar_ready), .ar_id(h_ar_id), .ar_addr(h_ar_addr), .ar_len(h_ar_len), .ar_size(h_ar_size),
    .ar_burst(h_ar_burst), .ar_mtype(h_ar_mtype), .ar_domain(h_ar_domain),
    .r_valid(h_r_valid), .r_ready(h_r_ready), .r_id(h_r_id), .r_data(h_r_data), .r_resp(h_r_resp), .r_last(h_r_last),
    .aw_valid(h_aw_valid), .aw_ready(h_aw_ready), .aw_id(h_aw_id), .aw_addr(h_aw_addr), .aw_len(h_aw_len), .aw_size(h_aw_size),
    .aw_burst(h_aw_burst), .aw_mtype(h_aw_mtype), .aw_domain(h_aw_domain),
    .w_valid(h_w_valid), .w_ready(h_w_ready), .w_data(h_w_data), .w_strb(h_w_strb), .w_last(h_w_last),
    .b_valid(h_b_valid), .b_ready(h_b_ready), .b_id(h_b_id), .b_resp(h_b_resp),
    .m_rq_tdata(m_axis_rq_tdata), .m_rq_tkeep(m_axis_rq_tkeep), .m_rq_tlast(m_axis_rq_tlast), .m_rq_tuser(m_axis_rq_tuser),
    .m_rq_tvalid(m_axis_rq_tvalid), .m_rq_tready(m_axis_rq_tready), .rq_ack0(rq_seq_vld0), .rq_ack1(rq_seq_vld1),
    .rcv_valid(rcv_valid), .rcv_ready(rcv_ready), .rcv_sop(rcv_sop), .rcv_eop(rcv_eop), .rcv_data(rcv_data), .rcv_ndw(rcv_ndw),
    .rcv_bad(rcv_bad), .rcv_lower(rcv_lower), .rcv_err(rcv_err), .rcv_bytecnt(rcv_bytecnt), .rcv_dwcnt(rcv_dwcnt),
    .rcv_status(rcv_status), .rcv_poison(rcv_poison), .rcv_reqid(rcv_reqid), .rcv_tag(rcv_tag),
    .zombie_clr(rec_zombie_clr | ctl_zombie_clr), .cfg_timeout_ticks(cfg_cpl_timeout), .cfg_req_id(cfg_req_id), .cfg_check_reqid(cfg_check_reqid),
    .ord_issued(ord_issued), .ord_acked(ord_acked),
    .dmaev_valid(dmaev_valid), .dmaev_code(dmaev_code), .dmaev_dom(dmaev_dom), .dmaev_write(dmaev_write), .dmaev_addr(dmaev_addr),
    .ev_e_valid(eve_valid), .ev_e_code(eve_code), .ev_e_addr(eve_addr), .ev_e_ctx(eve_ctx),
    .ev_c_valid(evc_valid), .ev_c_code(evc_code), .ev_c_addr(evc_addr), .ev_c_ctx(evc_ctx),
    .ev_b_valid(evb_valid), .ev_b_code(evb_code), .ev_b_addr(evb_addr), .ev_b_ctx(evb_ctx),
    .ev_o_valid(evo_valid), .ev_o_code(evo_code),
    .dg_valid(dg_valid), .dg_code(dg_code), .dg_tag(dg_tag),
    .pe_valid(pe_valid), .pe_dom(pe_dom), .pe_code(pe_code),
    .idle(dma_idle), .st_out(trk_out), .st_zombie(st_zombie), .st_flushing(trk_flushing), .st_active(st_active),
    .st_rq_mrd(st_rq_mrd), .st_rq_mwr(st_rq_mwr), .st_rd_bytes(st_rd_bytes), .st_wr_bytes(st_wr_bytes), .st_hdr_bytes(st_hdr_bytes),
    .st_pay_bytes(st_pay_bytes), .st_lat_valid(st_lat_valid), .st_lat(st_lat), .st_tag_stall(st_tag_stall),
    .st_cred_stall(st_cred_stall), .st_rq_bp(st_rq_bp));

  assign dma_ctl_abort      = ctl_dma_abort_csr | rec_dma_abort;
  assign dma_ctl_soft_reset = rec_dma_soft;          // a CSR soft-reset request goes through the recovery FSM (flush -> drain -> reset)
  assign dma_cfg_timeout    = cfg_dma_timeout_w;

  // ===========================================================================================================
  // interrupt adapter
  // ===========================================================================================================
  logic [`SFPB_IS_N-1:0] irq_ev;
  logic        irq_wr_valid; logic [7:0] irq_wr_addr, irq_rd_addr; logic [31:0] irq_wr_data, irq_rd_data; logic [3:0] irq_wr_strb;
  logic        irq_pending, irq_ord_stall, irq_fail_valid; logic [5:0] irq_fail_code;
  logic        err_irq, err_irq_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) err_irq_q <= 1'b0; else err_irq_q <= err_irq;
  end
  always_comb begin
    irq_ev = '0;
    irq_ev[`SFPB_IS_DMA_CPL]  = sub_irq_cpl;
    irq_ev[`SFPB_IS_DMA_ERR]  = sub_irq_err;
    irq_ev[`SFPB_IS_ERR]      = err_irq && !err_irq_q;
    irq_ev[`SFPB_IS_RECOVERY] = rec_done_ev;
    irq_ev[`SFPB_IS_STREAMDMA]= dma_irq;
    irq_ev[`SFPB_IS_EXT0]     = irq_ext[0];
    irq_ev[`SFPB_IS_EXT1]     = irq_ext[1];
    irq_ev[`SFPB_IS_EXT2]     = irq_ext[2];
  end
  sf_pcie_interrupt_adapter #(.NVEC(16), .ORD_W(ORD_W)) u_irq (
    .clk(clk), .rst_n(rst_n), .soft_rst(rec_soft_rst),
    .wr_valid(irq_wr_valid), .wr_addr(irq_wr_addr), .wr_data(irq_wr_data), .wr_strb(irq_wr_strb), .rd_addr(irq_rd_addr), .rd_data(irq_rd_data),
    .ev(irq_ev), .msi_enable(msi_enable), .msi_mmenable(msi_mmenable), .msi_int(msi_int), .msi_sent(msi_sent), .msi_fail(msi_fail),
    .ord_issued(ord_issued), .ord_acked(ord_acked), .ord_stall(irq_ord_stall),
    .irq_pending(irq_pending), .irq_level(irq_level), .ev_fail_valid(irq_fail_valid), .ev_fail_code(irq_fail_code));

  // ===========================================================================================================
  // global CSR page + performance counters
  // ===========================================================================================================
  logic [NEV-1:0]       cev_valid;
  logic [NEV*6-1:0]     cev_code;
  logic [NEV*64-1:0]    cev_addr;
  logic [NEV*8-1:0]     cev_tag;
  logic [NEV*16-1:0]    cev_rid;
  logic [NEV*4-1:0]     cev_type;
  logic [NEV*4-1:0]     cev_ctx;
  always_comb begin
    cev_valid = '0; cev_code = '0; cev_addr = '0; cev_tag = '0; cev_rid = '0; cev_type = '0; cev_ctx = '0;
    cev_valid[0] = ev0_valid;   cev_code[0*6 +: 6] = ev0_code;  cev_addr[0*64 +: 64] = ev0_addr; cev_tag[0*8 +: 8] = ev0_tag;
    cev_rid[0*16 +: 16] = ev0_rid; cev_type[0*4 +: 4] = ev0_type;
    cev_valid[1] = eve_valid;   cev_code[1*6 +: 6] = eve_code;  cev_addr[1*64 +: 64] = eve_addr; cev_ctx[1*4 +: 4] = eve_ctx;
    cev_valid[2] = evc_valid;   cev_code[2*6 +: 6] = evc_code;  cev_addr[2*64 +: 64] = evc_addr; cev_ctx[2*4 +: 4] = evc_ctx;
    cev_valid[3] = evb_valid;   cev_code[3*6 +: 6] = evb_code;  cev_addr[3*64 +: 64] = evb_addr; cev_ctx[3*4 +: 4] = evb_ctx;
    cev_valid[4] = dg_valid;    cev_code[4*6 +: 6] = dg_code;   cev_tag[4*8 +: 8] = dg_tag;
    cev_valid[5] = rec_ev_valid; cev_code[5*6 +: 6] = rec_ev_code;
    cev_valid[6] = sub_ev_valid; cev_code[6*6 +: 6] = sub_ev_code; cev_addr[6*64 +: 64] = sub_ev_addr; cev_ctx[6*4 +: 4] = sub_ev_ctx;
    cev_valid[7] = evo_valid | irq_fail_valid; cev_code[7*6 +: 6] = evo_valid ? evo_code : irq_fail_code;
  end

  logic [3:0]  err_ev_n;
  logic [5:0]  perf_sel; logic [63:0] perf_data;
  sf_pcie_csr #(.K(K), .TAGS(TAGS), .NCTX(NCTX), .MMIO_MAX_DW(MMIO_MAX_DW), .CPL_MAX_DW(CPL_MAX_DW), .NEV(NEV)) u_csr (
    .clk(clk), .rst_n(rst_n), .soft_rst(rec_soft_rst),
    .wr_valid(csr_wr_valid && (wr_page == 4'd0)), .wr_addr(csr_wr_addr[11:0]), .wr_data(csr_wr_data), .wr_strb(csr_wr_strb), .wr_err(csr_g_wr_err),
    .rd_valid(csr_rd_valid && (rd_page == 4'd0)), .rd_addr(csr_rd_addr[11:0]), .rd_dvalid(csr_g_dv), .rd_data(csr_g_rd), .rd_err(csr_g_rerr),
    .irq_wr_valid(irq_wr_valid), .irq_wr_addr(irq_wr_addr), .irq_wr_data(irq_wr_data), .irq_wr_strb(irq_wr_strb),
    .irq_rd_addr(irq_rd_addr), .irq_rd_data(irq_rd_data),
    .cfg_fwin_rd_en(cfg_fwin_rd_en), .cfg_fwin_wr_en(cfg_fwin_wr_en), .cfg_dma_en(cfg_dma_en), .cfg_wr_flush_en(cfg_wr_flush_en),
    .cfg_tc_any(cfg_tc_any), .cfg_perf_en(cfg_perf_en), .cfg_cpl_timeout(cfg_cpl_timeout), .cfg_sfb_timeout(cfg_sfb_timeout),
    .cfg_rec_quiet(cfg_rec_quiet), .cfg_dma_timeout(cfg_dma_timeout_w), .cfg_dma_type_en(dma_cfg_type_en),
    .ctl_soft_reset(ctl_soft_reset), .ctl_fatal_clr(ctl_fatal_clr), .ctl_perf_clear(ctl_perf_clear), .ctl_zombie_clr(ctl_zombie_clr),
    .ctl_dma_abort(ctl_dma_abort_csr), .ctl_dma_soft_reset(ctl_dma_soft_csr), .dma_perf_sel(dma_perf_sel), .dma_perf_data(dma_perf_data),
    .st_link_up(ep_link_up), .st_recovering(rst_st != `SFPB_REC_RUN), .st_fatal(eng_fatal), .st_dma_busy(dma_busy || !dma_idle || sub_busy),
    .st_dma_fenced(dma_fenced), .st_dma_proto(dma_proto_err), .st_dma_soft_pend(dma_soft_pend), .st_irq_pending(irq_pending),
    .st_np_ok(fc_np_ok), .st_p_ok(fc_p_ok), .st_outstanding(trk_out[7:0]), .st_zombies(st_zombie[7:0]), .st_rec_state(rst_st),
    .ev_valid(cev_valid), .ev_code(cev_code), .ev_addr(cev_addr), .ev_tag(cev_tag), .ev_reqid(cev_rid), .ev_type(cev_type), .ev_ctx(cev_ctx),
    .err_irq(err_irq), .err_events_now(err_ev_n),
    .dmaev_valid(dmaev_valid), .dmaev_code(dmaev_code), .dmaev_dom(dmaev_dom), .dmaev_write(dmaev_write), .dmaev_addr(dmaev_addr),
    .perf_sel(perf_sel), .perf_data(perf_data));

  // performance counters
  wire [15:0] w_req_b = {3'd0, req_ndw, 2'b00};
  wire [15:0] w_cpl_b = {3'd0, cpl_dwcnt, 2'b00};
  wire [15:0] w_rcv_b = {3'd0, rcv_dwcnt, 2'b00};
  wire rc_tlp_pulse = rcv_valid && rcv_ready && rcv_eop;
  wire [7:0]  hdr_b = (st_cq_tlp ? 8'd16 : 8'd0) + (st_cc_tlp ? 8'd12 : 8'd0) + st_hdr_bytes + (rc_tlp_pulse ? 8'd12 : 8'd0);
  wire [15:0] pay_b = ((req_valid && req_ready && req_type == `SFPB_RT_MEM_WR && !req_bad) ? w_req_b : 16'd0) +
                      ((cpl_valid && cpl_ready && cpl_sop) ? w_cpl_b : 16'd0) + st_pay_bytes +
                      ((rcv_valid && rcv_ready && rcv_sop && rcv_status == `SFPB_CPL_SC) ? w_rcv_b : 16'd0);
  sf_pcie_perf u_perf (
    .clk(clk), .rst_n(rst_n), .en(cfg_perf_en), .clr(ctl_perf_clear),
    .e_cq_tlp(st_cq_tlp), .e_cq_mrd(ev_exec_rd), .e_cq_mwr(ev_exec_wr), .e_cq_bad(st_cq_bad), .e_cc_tlp(st_cc_tlp),
    .e_rq_mrd(st_rq_mrd), .e_rq_mwr(st_rq_mwr), .e_rc_tlp(rc_tlp_pulse),
    .e_rdlat_valid(ev_rd_valid), .e_rdlat(ev_rd_lat), .e_wrlat_valid(ev_wr_valid), .e_wrlat(ev_wr_lat),
    .e_cpllat_valid(st_lat_valid), .e_cpllat(st_lat), .e_dma_rd_bytes(st_rd_bytes), .e_dma_wr_bytes(st_wr_bytes),
    .l_dma_active(st_active), .l_outstanding(trk_out), .l_hdrq(st_hdr_level), .l_payq(16'(st_pay_level)),
    .l_bp_cq(s_axis_cq_tvalid && !s_axis_cq_tready), .l_bp_cc(m_axis_cc_tvalid && !m_axis_cc_tready), .l_bp_rq(st_rq_bp),
    .l_bp_sfb(sfb_req_valid && !sfb_req_ready), .e_hdr_bytes(hdr_b), .e_pay_bytes(pay_b), .e_err_events(err_ev_n),
    .l_ord_stall(cc_ord_stall | irq_ord_stall), .e_cpl_unexpected(dg_valid), .l_tag_stall(st_tag_stall), .l_cred_stall(st_cred_stall),
    .sel(perf_sel), .data(perf_data));

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = &{1'b0, rq_seq_num0, rq_seq_num1, req_func, rcv_req_done, rcv_tc, rcv_attr, a_dev_base, a_dev_size, a_max_len, 1'b0};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
