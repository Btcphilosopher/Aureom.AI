"""Regression scenarios.

Each scenario returns (workload, program, checker).  Two independent checks
are applied: (1) bit-exact equality of RTL (Verilator and Icarus) against the
Python reference model; (2) the scenario's own *analytic* checker, which
compares readbacks against values computed directly from the stimulus
definition (closed-form totals, known latencies, known pulse timings) without
using the reference model.
"""
import random

import sftel.spec as S
from sftel.spec import A, EV, DEV, pack, live_addr, snap_addr, dsnap_addr, dlive_addr, ctrl_value
from sftel.stim import Program

M32, M64 = 0xFFFFFFFF, (1 << 64) - 1
P = S.P


class Scenario:
    def __init__(self, name, phase, fn, cnt_w_agnostic=False, desc=""):
        self.name, self.phase, self.fn = name, phase, fn
        self.cnt_w_agnostic = cnt_w_agnostic
        self.desc = desc

    def build(self):
        return self.fn()


# ---------------------------------------------------------------------- helpers
class WL:
    """Sparse workload builder."""

    def __init__(self, n):
        self.c = [dict() for _ in range(n)]

    def ensure(self, n):
        while len(self.c) < n:
            self.c.append(dict())

    def set(self, k, **f):
        self.ensure(k + 1)
        self.c[k].update(f)

    def mark(self, k, stage, tag, dom=None):
        self.ensure(k + 1)
        s = S.STAGES.index(stage)
        d = self.c[k]
        mv = d.get("mk_valid", 0)
        assert not (mv >> s) & 1, f"two {stage} marks in cycle {k}"
        d["mk_valid"] = mv | (1 << s)
        d["mk_tag"] = d.get("mk_tag", 0) | (tag << (s * P["TAG_W"]))
        if stage == "ARRIVE" and dom is not None:
            d["mk_arr_dom"] = dom


def rd64(p, addr, label, priv=1, user=0, at=0):
    p.r(addr, priv, user, at=at, label=label + ".lo")
    p.r(addr + 4, priv, user, label=label + ".hi")


def v64(reads, label):
    lo, hi = reads[label + ".lo"], reads[label + ".hi"]
    assert lo[1] == 0 and hi[1] == 0, f"{label}: PSLVERR on read"
    return (hi[0] << 32) | lo[0]


def snapshot(p, label, events, at=0, doms=False):
    p.w(A["CMD"], S.CMD["SNAPSHOT"], at=at, label=label + ".cmd")
    p.r(A["SNAP_SEQ"], label=label + ".seq")
    for n in events:
        rd64(p, snap_addr(EV[n]), f"{label}.{n}")
    if doms:
        for d in range(S.NUM_DOM):
            for e in S.DOM_EVENTS:
                rd64(p, dsnap_addr(d, DEV[e["name"]]), f"{label}.d{d}.{e['name']}")


def enable(p, at=0, **extra):
    p.w(A["CTRL"], ctrl_value(global_en=1, **extra), at=at, label="enable")


def acc_cycle(p, label):
    for op in p.ops:
        if op.label == label:
            return op.access_cycle
    raise KeyError(label)


P1_EVENTS = ["CYCLES", "CMD_ARRIVED", "CMD_COMPLETED", "DMA_RD_BYTES", "DMA_WR_BYTES",
             "PKT_ACCEPTED", "PKT_FORWARDED", "PKT_DROPPED", "NET_TX_BYTES"]


# ====================================================================== phase 1
def p1_core_events():
    """Cycle counters, DMA bytes, packet counters, command completions."""
    N0, N = 60, 400
    w = WL(N0 + N + 20)
    exp = {n: 0 for n in P1_EVENTS}
    tag = 0
    for k in range(N0, N0 + N):
        f = dict(dma_rd_bytes=pack([64, 32], 8), dma_wr_bytes=pack([16, 0], 8),
                 net_pkt_accept=0b1111, net_pkt_fwd=0b0101,
                 net_pkt_drop=0b1000 if k % 2 else 0,
                 net_tx_bytes=pack([64, 64, 64, 1], 8))
        w.set(k, **f)
        exp["DMA_RD_BYTES"] += 96
        exp["DMA_WR_BYTES"] += 16
        exp["PKT_ACCEPTED"] += 4
        exp["PKT_FORWARDED"] += 2
        exp["PKT_DROPPED"] += 1 if k % 2 else 0
        exp["NET_TX_BYTES"] += 193
        if (k - N0) % 4 == 0 and k + 3 < N0 + N:
            w.mark(k, "ARRIVE", tag % 32, dom=0)
            w.mark(k + 3, "COMPLETE", tag % 32)
            exp["CMD_ARRIVED"] += 1
            exp["CMD_COMPLETED"] += 1
            tag += 1
    p = Program()
    for n in ("ID", "VERSION", "CAPS0", "CAPS1"):
        p.r(A[n], label=n)
    enable(p, at=20)
    snapshot(p, "s1", P1_EVENTS, at=N0 + N + 5)
    p.w(A["CTRL"], 0, label="disable")
    # traffic after disable must not count
    for k in range(N0 + N + 200, N0 + N + 260):
        w.set(k, dma_rd_bytes=pack([255, 255], 8), net_pkt_accept=0xF)
    snapshot(p, "s2", P1_EVENTS, at=N0 + N + 300)
    # live reads, privileged
    for n in P1_EVENTS:
        rd64(p, live_addr(EV[n]), f"live.{n}")

    def check(reads, model):
        err = []
        if reads["ID"][0] != S.SPEC["id_value"]:
            err.append("ID mismatch")
        if reads["CAPS0"][0] & 0xFF != S.NUM_EV:
            err.append("CAPS0.NUM_EV")
        cyc = acc_cycle(p, "s1.cmd") - acc_cycle(p, "enable") - 1
        e = dict(exp, CYCLES=cyc)
        for n in P1_EVENTS:
            got = v64(reads, f"s1.{n}")
            if got != e[n]:
                err.append(f"s1 {n}: got {got} expected {e[n]}")
        dis_cyc = acc_cycle(p, "disable") - acc_cycle(p, "enable")
        for n in P1_EVENTS:
            got = v64(reads, f"s2.{n}")
            want = dis_cyc if n == "CYCLES" else e[n]
            if got != want:
                err.append(f"s2 (after disable) {n}: got {got} expected {want}")
            if v64(reads, f"live.{n}") != want:
                err.append(f"live {n} != snapshot after disable")
        if reads["s2.seq"][0] != 2:
            err.append("SNAP_SEQ should be 2")
        return err
    return w.c, p, check


def p1_simultaneous_lanes():
    """All lanes of every phase-1 multi-lane event retire in the same cycle."""
    N0, N = 40, 300
    w = WL(N0 + N + 10)
    for k in range(N0, N0 + N):
        w.set(k, dma_rd_bytes=pack([255, 255], 8), dma_wr_bytes=pack([255, 255], 8),
              net_pkt_accept=0xF, net_pkt_fwd=0xF, net_pkt_drop=0xF,
              net_tx_bytes=pack([255] * 4, 8))
    p = Program()
    enable(p, at=10)
    snapshot(p, "s", P1_EVENTS, at=N0 + N + 5)

    def check(reads, model):
        err = []
        want = dict(DMA_RD_BYTES=510 * N, DMA_WR_BYTES=510 * N, PKT_ACCEPTED=4 * N,
                    PKT_FORWARDED=4 * N, PKT_DROPPED=4 * N, NET_TX_BYTES=1020 * N)
        for n, x in want.items():
            g = v64(reads, f"s.{n}")
            if g != x:
                err.append(f"{n}: got {g} expected {x} (lanes must be summed)")
        return err
    return w.c, p, check


# ====================================================================== phase 2
def simultaneous_all():
    """Every multi-unit event at its maximum per-cycle increment, every event at once."""
    N0, N = 40, 250
    w = WL(N0 + N + 10)
    maxv = dict(cmp_tensor_ops=pack([255] * P["TL"], 8), cmp_vector_ops=pack([255] * P["VL"], 8),
                cmp_kernel_done=(1 << P["KP"]) - 1, cmp_busy=1, cmp_stall=1,
                net_pkt_accept=0xF, net_pkt_fwd=0xF, net_pkt_drop=0xF,
                net_tx_bytes=pack([255] * 4, 8), net_q_occ=0xFFFF,
                dma_rd_bytes=pack([255, 255], 8), dma_wr_bytes=pack([255, 255], 8), dma_stall=1,
                mem_rd_bytes=255, mem_wr_bytes=255, mig_bytes=255, sram_conflict=0xFF,
                sto_cmd=1, sto_rd_done=1, sto_wr_done=1, sto_err=1, sto_integ_fail=1,
                sec_auth_fail=1, sec_perm_viol=1, sec_invalid_cmd=1, ras_ecc_corr=0xF,
                ras_ecc_uncorr=1, ras_dma_fail=1, ras_ctrl_reset=1, ras_watchdog=1,
                core_clk_en=1, temp_valid=1, temp_code=100, pwr_state=2)
    for k in range(N0, N0 + N):
        w.set(k, **maxv)
    p = Program()
    p.w(A["ERRLOG_MASK"], 0)          # avoid filling the log; counted only
    enable(p, at=10)
    names = [e["name"] for e in S.EVENTS]
    snapshot(p, "s", names, at=N0 + N + 5)

    def check(reads, model):
        err = []
        skip = {"CYCLES", "CMD_ARRIVED", "CMD_COMPLETED", "RAS_THERMAL_FAULT", "RAS_FATAL",
                "PWR_STATE_TRANSITIONS", "PSTATE0_CYCLES", "PSTATE1_CYCLES", "PSTATE3_CYCLES",
                "THERMAL_WARN_EVENTS", "TEL_ACCESS_DENIED", "TRACE_RECORDS", "TRACE_DROPS",
                "ERRLOG_DROPS"}
        for e in S.EVENTS:
            n = e["name"]
            if n in skip:
                continue
            want = e["max_inc"] * N
            g = v64(reads, f"s.{n}")
            if g != want:
                err.append(f"{n}: got {g} expected {want}")
        if v64(reads, "s.PWR_STATE_TRANSITIONS") != 2:
            err.append("expected exactly 2 power-state transitions (0->2->0)")
        return err
    return w.c, p, check


def wrap_saturate():
    """64-bit wraparound, saturation, sticky overflow, W1C, IRQ, coherent LO/HI."""
    p = Program()
    w = WL(3000)
    cw_probe = {}
    # preload DMA_RD_BYTES (wrap) and DMA_WR_BYTES (saturate) near the top
    top = None  # filled with model.cmax at check time
    p.w(A["IRQ_EN"], S.IRQ["OVF"])
    p.w(A["SAT0"], 1 << EV["DMA_WR_BYTES"])
    p.w(A["PRELOAD_HI"], 0xFFFFFFFF)
    p.w(live_addr(EV["DMA_RD_BYTES"]), 0xFFFFFF00, label="pre_rd")
    p.w(live_addr(EV["DMA_WR_BYTES"]), 0xFFFFFF00, label="pre_wr")
    # counter for LO/HI coherence: just below a 32-bit carry
    p.w(A["PRELOAD_HI"], 0x00000007)
    p.w(live_addr(EV["NET_TX_BYTES"]), 0xFFFFF000, label="pre_tx")
    enable(p, at=40)
    # traffic: 510 bytes/cycle each direction, 1020 tx bytes/cycle, cycles 100..899
    for k in range(100, 900):
        w.set(k, dma_rd_bytes=pack([255, 255], 8), dma_wr_bytes=pack([255, 255], 8),
              net_tx_bytes=pack([255] * 4, 8))
    # live LO/HI reads of NET_TX_BYTES while it carries across bit 32
    for i in range(12):
        rd64(p, live_addr(EV["NET_TX_BYTES"]), f"tx{i}", at=100 + i * 7)
    p.r(A["OVF0"], at=1000, label="ovf0")
    p.r(A["IRQ_STATUS"], label="irqs")
    rd64(p, live_addr(EV["DMA_RD_BYTES"]), "rd_final")
    rd64(p, live_addr(EV["DMA_WR_BYTES"]), "wr_final")
    p.w(A["OVF0"], 1 << EV["DMA_RD_BYTES"], label="w1c")
    p.r(A["OVF0"], label="ovf0_after")
    p.w(A["IRQ_STATUS"], S.IRQ["OVF"])
    p.r(A["IRQ_STATUS"], label="irqs_after")
    # privileged write to a HI address is a decode error
    p.w(live_addr(EV["DMA_RD_BYTES"]) + 4, 0, label="bad_hi_write")
    # domain counter saturation
    p.w(A["DOM_CTRL"], 0x1FF)
    p.w(A["PRELOAD_HI"], 0xFFFFFFFF)
    p.w(dlive_addr(1, DEV["D_DMA_RD_BYTES"]), 0xFFFFFFF0)
    for k in range(1300, 1310):
        w.set(k, dma_rd_bytes=pack([100, 0], 8), dma_rd_dom=pack([1, 0], 2))
    rd64(p, dlive_addr(1, DEV["D_DMA_RD_BYTES"]), "dsat", at=1400)
    p.r(A["DOM_OVF"], label="dovf")

    def check(reads, model):
        err = []
        cmax = model.cmax
        n = 800
        rd_start = ((0xFFFFFFFF << 32) | 0xFFFFFF00) & cmax
        exp_rd = (rd_start + 510 * n) & cmax
        if v64(reads, "rd_final") != exp_rd:
            err.append(f"wrap: got {v64(reads, 'rd_final'):#x} expected {exp_rd:#x}")
        if v64(reads, "wr_final") != cmax:
            err.append("saturating counter did not stick at max")
        ovf = reads["ovf0"][0]
        for e in ("DMA_RD_BYTES", "DMA_WR_BYTES"):
            if not (ovf >> EV[e]) & 1:
                err.append(f"OVF0 bit for {e} not set")
        if (reads["ovf0_after"][0] >> EV["DMA_RD_BYTES"]) & 1:
            err.append("W1C did not clear DMA_RD_BYTES overflow")
        if not (reads["ovf0_after"][0] >> EV["DMA_WR_BYTES"]) & 1:
            err.append("W1C cleared an unrelated overflow bit")
        if not reads["irqs"][0] & S.IRQ["OVF"]:
            err.append("IRQ_STATUS.OVF not set")
        if reads["bad_hi_write"][1] != 1:
            err.append("privileged write to live HI should PSLVERR")
        # coherence: consecutive composed values advance exactly 1020/cycle
        vals = [v64(reads, f"tx{i}") for i in range(12)]
        lo_cycles = []
        for op in p.ops:
            if op.label and op.label.startswith("tx") and op.label.endswith(".lo"):
                lo_cycles.append(op.setup_cycle)
        tx0 = (0x7 << 32) | 0xFFFFF000
        for i in range(12):
            # value held before setup edge S = preload + 1020 * #updates in [101, min(S-1, 900)]
            n_upd = max(0, min(lo_cycles[i] - 1, 900) - 101 + 1)
            want = (tx0 + 1020 * n_upd) & cmax
            if vals[i] != want:
                err.append(f"torn/incoherent 64-bit read {i}: {vals[i]:#x} != {want:#x}")
        if cmax > M32 and not any(((v >> 32) & 0xF) == 8 for v in vals):
            err.append("test did not cross the 32-bit carry")
        if v64(reads, "dsat") != cmax:
            err.append("domain counter did not saturate")
        if not (reads["dovf"][0] >> (1 * S.NUM_DEV + DEV["D_DMA_RD_BYTES"])) & 1:
            err.append("DOM_OVF bit not set")
        return err
    return w.c, p, check


def reset_freeze():
    """RESET_COUNTERS, snapshot+reset (atomic read-and-clear), SW freeze, freeze-on-fatal."""
    w = WL(4000)
    for k in range(50, 3500):
        w.set(k, dma_rd_bytes=pack([10, 0], 8))
    w.set(2000, ras_fatal=1, ras_info=0xFA7A)
    p = Program()
    p.w(A["IRQ_EN"], S.IRQ["HW_FREEZE"] | S.IRQ["RAS"])
    enable(p, at=20, freeze_on_fatal=1)
    # read-and-clear at ~600
    p.w(A["CMD"], S.CMD["SNAPSHOT"] | S.CMD["RESET_COUNTERS"], at=600, label="rc1")
    rd64(p, snap_addr(EV["DMA_RD_BYTES"]), "rc1.rd")
    rd64(p, snap_addr(EV["CYCLES"]), "rc1.cyc")
    # software freeze window
    p.w(A["CTRL"], ctrl_value(global_en=1, sw_freeze=1, freeze_on_fatal=1), at=900, label="frz")
    snapshot(p, "f1", ["DMA_RD_BYTES", "CYCLES"], at=1000)
    snapshot(p, "f2", ["DMA_RD_BYTES", "CYCLES"], at=1200)
    p.w(A["CTRL"], ctrl_value(global_en=1, freeze_on_fatal=1), at=1300, label="unfrz")
    p.w(A["CMD"], S.CMD["SNAPSHOT"] | S.CMD["RESET_COUNTERS"], at=1500, label="rc2")
    rd64(p, snap_addr(EV["DMA_RD_BYTES"]), "rc2.rd")
    rd64(p, snap_addr(EV["CYCLES"]), "rc2.cyc")
    # fatal at input cycle 2000 -> hardware freeze
    p.r(A["STATUS"], at=2100, label="st_frozen")
    snapshot(p, "hf1", ["DMA_RD_BYTES", "CYCLES", "RAS_FATAL"], at=2200)
    snapshot(p, "hf2", ["DMA_RD_BYTES", "CYCLES", "RAS_FATAL"], at=2400)
    p.r(A["IRQ_STATUS"], label="irqs")
    p.w(A["CMD"], S.CMD["UNFREEZE"], at=2500, label="unfreeze")
    p.r(A["STATUS"], label="st_after")
    snapshot(p, "hf3", ["DMA_RD_BYTES", "CYCLES"], at=2700)

    def check(reads, model):
        err = []
        en, rc1 = acc_cycle(p, "enable"), acc_cycle(p, "rc1.cmd" if False else "rc1")
        # traffic starts at input cycle 50 -> applied from edge 51
        exp_c1 = rc1 - en - 1
        exp_b1 = 10 * (rc1 - 51)
        if v64(reads, "rc1.cyc") != exp_c1:
            err.append(f"rc1 CYCLES {v64(reads, 'rc1.cyc')} != {exp_c1}")
        if v64(reads, "rc1.rd") != exp_b1:
            err.append(f"rc1 bytes {v64(reads, 'rc1.rd')} != {exp_b1}")
        if v64(reads, "f1.DMA_RD_BYTES") != v64(reads, "f2.DMA_RD_BYTES"):
            err.append("counter moved during SW freeze")
        if v64(reads, "f1.CYCLES") != v64(reads, "f2.CYCLES"):
            err.append("CYCLES moved during SW freeze")
        # counted window after rc1: (rc1, frz] then (unfrz, rc2)
        frz, unf, rc2 = acc_cycle(p, "frz"), acc_cycle(p, "unfrz"), acc_cycle(p, "rc2")
        exp_c2 = (frz - rc1) + (rc2 - unf - 1)
        if v64(reads, "rc2.cyc") != exp_c2:
            err.append(f"rc2 CYCLES {v64(reads, 'rc2.cyc')} != {exp_c2}")
        if v64(reads, "rc2.rd") != 10 * exp_c2:
            err.append("rc2 bytes not 10/cycle of counted window")
        if not (reads["st_frozen"][0] >> 2) & 1:
            err.append("STATUS.hw_frozen not set after fatal")
        if v64(reads, "hf1.DMA_RD_BYTES") != v64(reads, "hf2.DMA_RD_BYTES"):
            err.append("counter moved while hw-frozen")
        if v64(reads, "hf1.RAS_FATAL") != 1:
            err.append("fatal event itself must be counted before freeze")
        # frozen from edge 2002: counted window (rc2, 2001]
        if v64(reads, "hf1.CYCLES") != 2001 - rc2:
            err.append(f"freeze point: CYCLES {v64(reads, 'hf1.CYCLES')} != {2001 - rc2}")
        if not reads["irqs"][0] & S.IRQ["HW_FREEZE"]:
            err.append("IRQ HW_FREEZE not raised")
        if (reads["st_after"][0] >> 2) & 1:
            err.append("UNFREEZE did not clear hw_frozen")
        if v64(reads, "hf3.CYCLES") <= v64(reads, "hf2.CYCLES"):
            err.append("counting did not resume after UNFREEZE")
        return err
    return w.c, p, check


def snapshot_atomic():
    """Repeated snapshots under constant traffic; all counters in a snapshot are
    from the same edge; snapshot registers static between snapshots; seqlock."""
    rates = dict(DMA_RD_BYTES=300, DMA_WR_BYTES=17, NET_TX_BYTES=1000, PKT_ACCEPTED=3,
                 TENSOR_OPS=800, VECTOR_OPS=9, MEM_RD_BYTES=200, NET_QOCC_ACCUM=12345,
                 COMPUTE_BUSY_CYCLES=1, CORE_CLK_EN_CYCLES=1)
    w = WL(6000)
    for k in range(0, 5800):
        w.set(k, dma_rd_bytes=pack([150, 150], 8), dma_wr_bytes=pack([17, 0], 8),
              net_tx_bytes=pack([250] * 4, 8), net_pkt_accept=0b0111,
              cmp_tensor_ops=pack([200] * 4, 8), cmp_vector_ops=pack([4, 5], 8),
              mem_rd_bytes=200, net_q_occ=12345, cmp_busy=1, core_clk_en=1)
    p = Program()
    enable(p, at=10)
    names = ["CYCLES"] + list(rates)
    for i in range(8):
        snapshot(p, f"s{i}", names, at=300 + i * 600)
        p.r(A["SNAP_SEQ"], label=f"s{i}.seq2")
        rd64(p, snap_addr(EV["DMA_RD_BYTES"]), f"s{i}.again")
        rd64(p, A["SNAP_TS_LO"], f"s{i}.ts")

    def check(reads, model):
        err = []
        for i in range(8):
            cyc = v64(reads, f"s{i}.CYCLES")
            for n, r in rates.items():
                g = v64(reads, f"s{i}.{n}")
                if g != r * cyc:
                    err.append(f"snapshot {i}: {n}={g} not {r}*CYCLES({cyc}) -> not atomic")
            if v64(reads, f"s{i}.again") != v64(reads, f"s{i}.DMA_RD_BYTES"):
                err.append(f"snapshot {i} changed between reads")
            if reads[f"s{i}.seq"][0] != i + 1 or reads[f"s{i}.seq2"][0] != i + 1:
                err.append(f"snapshot {i}: SNAP_SEQ wrong")
            if v64(reads, f"s{i}.ts") != acc_cycle(p, f"s{i}.cmd"):
                err.append(f"snapshot {i}: SNAP_TS != snapshot edge")
        return err
    return w.c, p, check


def domains_isolation():
    """Per-domain attribution with mixed-domain lanes; tenant isolation; coarsening."""
    rng = random.Random(69)
    w = WL(5000)
    tag = 0
    tot = {}
    for k in range(100, 3000):
        rb = [rng.randrange(256) for _ in range(2)]
        rdm = [rng.randrange(4) for _ in range(2)]
        wb = [rng.randrange(256) for _ in range(2)]
        wdm = [rng.randrange(4) for _ in range(2)]
        tx = [rng.randrange(256) for _ in range(4)]
        nd = [rng.randrange(4) for _ in range(4)]
        fw = rng.randrange(16)
        cd = rng.randrange(4)
        w.set(k, dma_rd_bytes=pack(rb, 8), dma_rd_dom=pack(rdm, 2), dma_wr_bytes=pack(wb, 8),
              dma_wr_dom=pack(wdm, 2), net_tx_bytes=pack(tx, 8), net_lane_dom=pack(nd, 2),
              net_pkt_fwd=fw, cmp_tensor_ops=pack([rng.randrange(256) for _ in range(4)], 8),
              cmp_dom=cd, cmp_busy=rng.randrange(2))
        if k % 10 == 0 and k + 6 < 3000:
            w.mark(k, "ARRIVE", tag % 32, dom=rng.randrange(4))
            w.mark(k + 6, "COMPLETE", tag % 32)
            tag += 1
    p = Program()
    enable(p, at=20)
    snapshot(p, "s", ["DMA_RD_BYTES", "DMA_WR_BYTES", "NET_TX_BYTES", "PKT_FORWARDED",
                      "TENSOR_OPS", "COMPUTE_BUSY_CYCLES", "CMD_ARRIVED", "CMD_COMPLETED",
                      "CYCLES"], at=3100, doms=True)
    denied = 0
    # tenant d reads its own page: permitted and equal to privileged view
    for d in range(4):
        for e in S.DOM_EVENTS:
            rd64(p, dsnap_addr(d, DEV[e["name"]]), f"t{d}.own.{e['name']}", priv=0, user=d)
    # tenant 2 reads tenant 1 page / live window / CTRL / writes -> denied
    neg = [("other_page", dsnap_addr(1, 0), "R"), ("other_page_hi", dsnap_addr(3, 2) + 4, "R"),
           ("dom_live", dlive_addr(2, 0), "R"), ("glob_live", live_addr(0), "R"),
           ("glob_snap", snap_addr(0), "R"), ("ctrl", A["CTRL"], "R"), ("ts", A["TS_LO"], "R"),
           ("w_ctrl", A["CTRL"], "W"), ("w_cmd", A["CMD"], "W"), ("w_own", dsnap_addr(2, 0), "W"),
           ("unmapped", 0x3FC, "R")]
    for lab, addr, kind in neg:
        if kind == "R":
            p.r(addr, priv=0, user=2, label=f"neg.{lab}")
        else:
            p.w(addr, 0x1F, priv=0, user=2, label=f"neg.{lab}")
        denied += 1
    for lab, addr in (("id", A["ID"]), ("seq", A["SNAP_SEQ"]), ("clk", A["TEL_CLK_HZ"])):
        p.r(addr, priv=0, user=2, label=f"pos.{lab}")
    p.r(A["VIOL_INFO"], label="viol")
    # shared counters: enable with mask on CYCLES and PKT_FORWARDED, coarsen 6 bits
    p.w(A["TENANT_MASK0"], (1 << EV["CYCLES"]) | (1 << EV["PKT_FORWARDED"]))
    p.w(A["CTRL"], ctrl_value(global_en=1, tenant_shared_en=1, tenant_coarsen=6))
    rd64(p, snap_addr(EV["CYCLES"]), "sh.cyc", priv=0, user=3)
    rd64(p, snap_addr(EV["PKT_FORWARDED"]), "sh.fwd", priv=0, user=0)
    p.r(snap_addr(EV["DMA_RD_BYTES"]), priv=0, user=0, label="sh.masked")
    denied += 1
    p.w(A["CMD"], S.CMD["SNAPSHOT"], label="s_final")
    rd64(p, snap_addr(EV["TEL_ACCESS_DENIED"]), "denied_cnt")

    def check(reads, model):
        err = []
        pairs = [("DMA_RD_BYTES", "D_DMA_RD_BYTES"), ("DMA_WR_BYTES", "D_DMA_WR_BYTES"),
                 ("NET_TX_BYTES", "D_NET_TX_BYTES"), ("PKT_FORWARDED", "D_PKT_FORWARDED"),
                 ("TENSOR_OPS", "D_TENSOR_OPS"), ("COMPUTE_BUSY_CYCLES", "D_COMPUTE_BUSY_CYCLES"),
                 ("CMD_ARRIVED", "D_CMD_ARRIVED"), ("CMD_COMPLETED", "D_CMD_COMPLETED")]
        for g, de in pairs:
            tot = sum(v64(reads, f"s.d{d}.{de}") for d in range(4))
            if tot != v64(reads, f"s.{g}"):
                err.append(f"sum over domains of {de} ({tot}) != {g} ({v64(reads, f's.{g}')})")
        nonzero = sum(1 for d in range(4) if v64(reads, f"s.d{d}.D_DMA_RD_BYTES"))
        if nonzero < 4:
            err.append("expected traffic in all 4 domains")
        for d in range(4):
            for e in S.DOM_EVENTS:
                if v64(reads, f"t{d}.own.{e['name']}") != v64(reads, f"s.d{d}.{e['name']}"):
                    err.append(f"tenant {d} own-page view differs from privileged view")
        for lab, _, kind in neg:
            r = reads[f"neg.{lab}"]
            if r[1] != 1 or (kind == "R" and r[0] != 0):
                err.append(f"tenant access '{lab}' not refused (rdata={r[0]:#x} err={r[1]})")
        for lab in ("id", "seq", "clk"):
            if reads[f"pos.{lab}"][1] != 0:
                err.append(f"tenant read of {lab} refused")
        vi = reads["viol"][0]
        if vi >> 31 != 1 or (vi & 0xFFFF) != 0x3FC or ((vi >> 24) & 3) != 2:
            err.append(f"VIOL_INFO wrong {vi:#x}")
        cy = v64(reads, "s.CYCLES")
        if v64(reads, "sh.cyc") != (cy & ~0x3F):
            err.append("shared CYCLES not coarsened to 64-cycle granularity")
        if v64(reads, "sh.fwd") != (v64(reads, "s.PKT_FORWARDED") & ~0x3F):
            err.append("shared PKT_FORWARDED not coarsened")
        if reads["sh.masked"][1] != 1:
            err.append("unmasked shared counter readable by tenant")
        if v64(reads, "denied_cnt") != denied:
            err.append(f"TEL_ACCESS_DENIED={v64(reads, 'denied_cnt')} expected {denied}")
        return err
    return w.c, p, check


def cdc_thermal_fault():
    """Asynchronous active-low thermal fault pin through the 2-flop synchronizer."""
    w = WL(2000)
    for k in range(2000):
        w.set(k, thermal_fault_n=1)
    pulses = [(200, 1), (300, 2), (400, 5), (500, 50), (700, 1), (702, 1)]
    for st, ln in pulses:
        for k in range(st, st + ln):
            w.set(k, thermal_fault_n=0)
    p = Program()
    enable(p, at=10)
    snapshot(p, "s", ["RAS_THERMAL_FAULT"], at=1000)
    p.r(A["STATUS"], label="st")
    for i in range(len(pulses)):
        p.r(A["ERRLOG_HEAD0"], label=f"e{i}.h")
        p.r(A["ERRLOG_HEAD_TS_LO"], label=f"e{i}.ts")
        p.w(A["ERRLOG_POP"], 1)
    p.r(A["ERRLOG_HEAD0"], label="empty")

    def check(reads, model):
        err = []
        if v64(reads, "s.RAS_THERMAL_FAULT") != len(pulses):
            err.append(f"fault count {v64(reads, 's.RAS_THERMAL_FAULT')} != {len(pulses)}")
        for i, (st, _) in enumerate(pulses):
            h = reads[f"e{i}.h"][0]
            if not h >> 31 or not (h >> 16) & S.ES["THERMAL_FAULT"]:
                err.append(f"errlog entry {i} missing thermal source")
            # input sampled low at edge st -> s1 at st, s2 at st+1, edge detect at st+2
            if reads[f"e{i}.ts"][0] != st + 2:
                err.append(f"pulse {i}: detected at {reads[f'e{i}.ts'][0]} expected {st + 2} (2-FF latency)")
        if reads["empty"][0] != 0:
            err.append("errlog not empty after popping all")
        return err
    return w.c, p, check


def errlog_ras():
    """All RAS sources, simultaneous sources, masking, overflow/drops, first error, clear."""
    w = WL(3000)
    srcs = ["ras_ecc_uncorr", "ras_dma_fail", "ras_ctrl_reset", "ras_watchdog", "ras_fatal",
            "sto_integ_fail"]
    t = 100
    expect = []
    for i, s in enumerate(srcs):
        w.set(t, **{s: 1, "ras_info": 0x100 + i})
        expect.append((t, 0x100 + i))
        t += 7
    w.set(t, ras_ecc_uncorr=1, ras_dma_fail=1, ras_watchdog=1, ras_info=0xBEEF)  # simultaneous
    expect.append((t, 0xBEEF))
    t += 5
    w.set(t, ras_ecc_corr=0b1011, ras_info=0x0C0C)   # masked by default -> counted, not logged
    ecc_masked_cycle = t
    t += 5
    # 12 more errors -> log holds 16, rest dropped
    for i in range(12):
        w.set(t, ras_dma_fail=1, ras_info=0x200 + i)
        t += 3
    p = Program()
    p.w(A["IRQ_EN"], S.IRQ["RAS"])
    enable(p, at=20)
    p.r(A["STATUS"], at=t + 20, label="st_full")
    p.r(A["FIRST_ERR_INFO"], label="first")
    p.r(A["FIRST_ERR_TS_LO"], label="first_ts")
    for i in range(16):
        p.r(A["ERRLOG_HEAD0"], label=f"h{i}")
        p.r(A["ERRLOG_HEAD_TS_LO"], label=f"ts{i}")
        p.w(A["ERRLOG_POP"], 0)
    p.r(A["ERRLOG_HEAD0"], label="empty")
    p.w(A["CMD"], S.CMD["SNAPSHOT"])
    for n in ("RAS_ECC_UNCORR", "RAS_DMA_FAIL", "RAS_WATCHDOG", "RAS_ECC_CORR", "ERRLOG_DROPS",
              "STO_INTEGRITY_FAIL", "RAS_FATAL", "RAS_CTRL_RESET"):
        rd64(p, snap_addr(EV[n]), f"c.{n}")
    # enable ECC_CORR logging, inject, clear
    p.w(A["ERRLOG_MASK"], 0xFF, label="mask_all")
    p.w(A["CMD"], S.CMD["ERRLOG_CLEAR"], at=t + 400, label="clr")
    p.r(A["FIRST_ERR_INFO"], label="first_after_clr")
    w.set(t + 600, ras_ecc_corr=0b0001, ras_info=0xECC0)
    p.r(A["ERRLOG_HEAD0"], at=t + 650, label="ecc_logged")
    p.r(A["FIRST_ERR_INFO"], label="first2")
    p.r(A["IRQ_STATUS"], label="irqs")

    def check(reads, model):
        err = []
        st = reads["st_full"][0]
        if (st >> 16) & 0x1F != 16:
            err.append(f"errlog count {(st >> 16) & 0x1F} != 16")
        f = reads["first"][0]
        if f >> 31 != 1 or (f & 0xFFFF) != 0x100 or reads["first_ts"][0] != 100:
            err.append(f"first error capture wrong {f:#x}")
        for i in range(16):
            h = reads[f"h{i}"][0]
            if i < len(expect):
                if (h & 0xFFFF) != expect[i][1] or reads[f"ts{i}"][0] != expect[i][0]:
                    err.append(f"log entry {i}: info {h & 0xFFFF:#x} ts {reads[f'ts{i}'][0]}")
            if i == 6:
                bm = (h >> 16) & 0xFF
                want = S.ES["ECC_UNCORR"] | S.ES["DMA_FAIL"] | S.ES["WATCHDOG"]
                if bm != want:
                    err.append(f"simultaneous sources bitmap {bm:#x} != {want:#x}")
        if reads["empty"][0] != 0:
            err.append("log not empty")
        if v64(reads, "c.ERRLOG_DROPS") != 3:
            err.append(f"ERRLOG_DROPS {v64(reads, 'c.ERRLOG_DROPS')} != 3")
        if v64(reads, "c.RAS_ECC_CORR") != 3:
            err.append("ECC corrections must be popcounted (3)")
        if v64(reads, "c.RAS_DMA_FAIL") != 1 + 1 + 12:
            err.append("RAS_DMA_FAIL count")
        if reads["first_after_clr"][0] != 0:
            err.append("ERRLOG_CLEAR did not clear first-error")
        e = reads["ecc_logged"][0]
        if not (e >> 16) & S.ES["ECC_CORR"] or (e & 0xFFFF) != 0xECC0:
            err.append("ECC_CORR not logged after enabling mask")
        if not reads["irqs"][0] & S.IRQ["RAS"]:
            err.append("IRQ RAS not set")
        _ = ecc_masked_cycle
        return err
    return w.c, p, check


def trace_latency():
    """Well-formed transactions with known stage times + protocol corner cases,
    sampling, filtering, FIFO overflow/drops, flush, histogram."""
    rng = random.Random(1969)
    w = WL(12000)
    used = {}   # (cycle, stage) occupied

    def free(k, st):
        return (k, st) not in used

    txns = []
    k = 200
    tag = 0
    inflight = {}
    # phase A: 60 well-formed transactions, all traced (sample all)
    while len(txns) < 60:
        t = tag % 32
        if t in inflight and inflight[t] >= k:
            tag += 1
            continue
        times = [k]
        cur = k
        for st in range(1, 7):
            cur += rng.choice([0, 1, 2, 3, 5, 8, 13, 40]) if st != 6 else rng.randrange(1, 30)
            while not free(cur, st):
                cur += 1
            times.append(cur)
        if not free(k, 0):
            k += 1
            continue
        for st, tt in enumerate(times):
            used[(tt, st)] = True
            w.mark(tt, S.STAGES[st], t, dom=(len(txns) % 4) if st == 0 else None)
        inflight[t] = times[6]
        txns.append(dict(tag=t, dom=len(txns) % 4, times=times))
        tag += 1
        k += rng.randrange(20, 40)
    end_a = max(x["times"][6] for x in txns)
    p = Program()
    enable(p, at=20, trace_en=1)
    # drain one record per known completion (single consumer, never pops an
    # empty/unread head: the drain for completion i is issued after it happened)
    recs = []
    for nrec, tx in enumerate(sorted(txns, key=lambda x: x["times"][6])):
        for wd in range(10):
            p.r(A[f"TRACE_HEAD{wd}"], at=tx["times"][6] + 2, label=f"A{nrec}.w{wd}")
        p.w(A["TRACE_POP"], 1)
        recs.append(nrec)
    rd64(p, live_addr(EV["TRACE_DROPS"]), "a_drops")
    # phase B: corner cases (after phase A traffic)
    b0 = end_a + 400
    # B1 arrive+dispatch same cycle; comp_done + complete same cycle
    w.mark(b0, "ARRIVE", 1, dom=3); w.mark(b0, "DISPATCH", 1)
    w.mark(b0 + 4, "DMA_START", 1); w.mark(b0 + 9, "DMA_DONE", 1)
    w.mark(b0 + 12, "COMP_START", 1); w.mark(b0 + 20, "COMP_DONE", 1); w.mark(b0 + 20, "COMPLETE", 1)
    # B2 duplicate stage mark
    w.mark(b0 + 30, "ARRIVE", 2, dom=1); w.mark(b0 + 32, "DISPATCH", 2); w.mark(b0 + 35, "DISPATCH", 2)
    w.mark(b0 + 40, "COMPLETE", 2)
    # B3 orphan marks: stage + complete for never-arrived tag 9
    w.mark(b0 + 50, "DMA_START", 9); w.mark(b0 + 51, "COMPLETE", 9)
    # B4 tag reuse: arrive 3, arrive 3 again before completion
    w.mark(b0 + 60, "ARRIVE", 3, dom=0); w.mark(b0 + 65, "ARRIVE", 3, dom=2); w.mark(b0 + 70, "COMPLETE", 3)
    # B5 complete and re-arrive same tag same cycle
    w.mark(b0 + 80, "ARRIVE", 4, dom=1); w.mark(b0 + 90, "COMPLETE", 4); w.mark(b0 + 90, "ARRIVE", 4, dom=2)
    w.mark(b0 + 95, "COMPLETE", 4)
    corner_tags = [1, 2, 3, 4, 4]
    for i in range(len(corner_tags)):
        for wd in range(10):
            p.r(A[f"TRACE_HEAD{wd}"], at=b0 + 200, label=f"B{i}.w{wd}")
        p.w(A["TRACE_POP"], 1)
    p.r(A["TRACE_PROTO"], label="proto")
    # phase C: sampling 1-in-3 with tag filter (even tags), no drain -> overflow
    c0 = b0 + 600
    p.w(A["TRACE_SAMPLE"], 3, at=c0 - 50)
    p.w(A["TRACE_FILTER"], (0 << 0) | (1 << 8))       # match tag bit0 == 0
    p.w(A["CMD"], S.CMD["SNAPSHOT"] | S.CMD["RESET_COUNTERS"] | S.CMD["TRACE_FLUSH"],
        label="c_reset")
    nC = 0
    for i in range(160):
        kk = c0 + i * 8
        w.mark(kk, "ARRIVE", i % 32, dom=0)
        w.mark(kk + 5, "COMPLETE", i % 32)
        nC += 1
    cend = c0 + 160 * 8 + 20
    snapshot(p, "c", ["TRACE_RECORDS", "TRACE_DROPS", "CMD_COMPLETED"], at=cend)
    p.r(A["STATUS"], label="c_status")
    rd64(p, A["HIST_SUM_LO"], "hsum")
    p.r(A["HIST_SAMPLES"], label="hsamp")
    p.r(A["HIST_MAX"], label="hmax")
    p.r(A["HIST_BIN2"], label="hbin2")
    p.r(A["HIST_BIN3"], label="hbin3")
    p.w(A["CMD"], S.CMD["TRACE_FLUSH"], label="flush")
    p.r(A["TRACE_HEAD0"], label="after_flush")

    def check(reads, model):
        err = []

        def rec(prefix):
            return [reads[f"{prefix}.w{i}"][0] for i in range(10)]
        got = []
        for i in recs:
            r = rec(f"A{i}")
            if r[0] >> 31:
                got.append(r)
        if len(got) != len(txns):
            err.append(f"phase A: drained {len(got)} records, expected {len(txns)}")
        # records come out in completion order
        by_done = sorted(txns, key=lambda x: x["times"][6])
        for r, tx in zip(got, by_done):
            if (r[0] & 31) != tx["tag"] or ((r[0] >> 8) & 3) != tx["dom"]:
                err.append(f"record tag/dom mismatch {r[0]:#x} vs {tx['tag']}")
                continue
            if r[2] != tx["times"][0]:
                err.append(f"tag {tx['tag']}: arrival ts {r[2]} != {tx['times'][0]}")
            for s in range(1, 7):
                if r[3 + s] != tx["times"][s] - tx["times"][0]:
                    err.append(f"tag {tx['tag']} stage {s}: delta {r[3 + s]} != "
                               f"{tx['times'][s] - tx['times'][0]}")
            if ((r[0] >> 16) & 0x7F) != 0x7F:
                err.append("stage_valid incomplete")
            ds = [r[4 + s] for s in range(6)]
            if ds != sorted(ds):
                err.append(f"tag {tx['tag']}: stage deltas out of order {ds}")
        if v64(reads, "a_drops") != 0:
            err.append("phase A should not drop records")
        seqs = [r[1] for r in got]
        if seqs != list(range(len(seqs))):
            err.append("record sequence numbers not contiguous")
        B = [rec(f"B{i}") for i in range(5)]
        if B[0][4] != 0 or B[0][8] != 20 or B[0][9] != 20:
            err.append(f"B1 same-cycle stages wrong {B[0][4:]}")
        if not (B[1][0] >> 29) & 1 or B[1][4] != 2:
            err.append("B2 duplicate stage: flag or first-mark-wins violated")
        if (B[2][0] & 31) != 3 or ((B[2][0] >> 8) & 3) != 2 or B[2][9] != 5:
            err.append("B4 reused tag record should belong to the second arrival")
        if B[3][9] != 10 or ((B[3][0] >> 8) & 3) != 1:
            err.append("B5 first incarnation record wrong")
        if B[4][9] != 5 or ((B[4][0] >> 8) & 3) != 2:
            err.append("B5 second incarnation record wrong")
        pr = reads["proto"][0]
        if (pr & 0xFFFF) != 2 or (pr >> 16) != 1:
            err.append(f"TRACE_PROTO orphan={pr & 0xFFFF} reuse={pr >> 16} (expected 2,1)")
        # phase C: candidates = even tags (80), selected = every 3rd -> 27
        sel = len(range(0, 80, 3))
        recs_c = v64(reads, "c.TRACE_RECORDS")
        drops_c = v64(reads, "c.TRACE_DROPS")
        if recs_c + drops_c != sel:
            err.append(f"phase C records+drops {recs_c}+{drops_c} != {sel}")
        if recs_c != 16:
            err.append(f"phase C stored {recs_c} records, FIFO depth is 16")
        if (reads["c_status"][0] >> 8) & 0x1F != 16:
            err.append("trace FIFO count != 16")
        if v64(reads, "c.CMD_COMPLETED") != nC:
            err.append("CMD_COMPLETED in phase C")
        if reads["hsamp"][0] != nC or v64(reads, "hsum") != 5 * nC or reads["hmax"][0] != 5:
            err.append(f"histogram samples/sum/max wrong: {reads['hsamp'][0]} {v64(reads, 'hsum')}")
        if reads["hbin2"][0] != nC or reads["hbin3"][0] != 0:
            err.append("latency 5 must land in bin 2 [4,8)")
        if reads["after_flush"][0] != 0:
            err.append("TRACE_FLUSH did not empty FIFO")
        return err
    return w.c, p, check


def power_thermal_gauges():
    """Temperature gauges & warning episodes, power-state residency/transitions,
    clock-enable duty, measured-power accumulation, queue high-water."""
    w = WL(3000)
    for c in range(3000):
        w.set(c, pwr_sensor_present=1)
    temps = []
    k = 100
    seq = list(range(500, 900, 25)) + list(range(900, 400, -50)) + list(range(400, 1000, 100))
    for tcode in seq:
        w.set(k, temp_valid=1, temp_code=tcode)
        temps.append(tcode)
        k += 10
    thr = 800
    episodes = 0
    prev_above = False
    for tcode in temps:
        a = tcode >= thr
        if a and not prev_above:
            episodes += 1
        prev_above = a
    pst = [(1000, 0), (1100, 1), (1150, 3), (1300, 2), (1310, 2), (1400, 0)]
    for k2 in range(1000, 1500):
        st = [s for c, s in pst if c <= k2][-1]
        w.set(k2, pwr_state=st, core_clk_en=int(k2 % 4 != 0), pwr_sensor_present=1)
    pw = [(1600 + 7 * i, 1000 + i) for i in range(30)]
    for c, code in pw:
        w.set(c, pwr_meas_valid=1, pwr_meas_code=code, pwr_sensor_present=1)
    for c in range(1600, 1900):
        w.set(c, pwr_sensor_present=1, net_q_occ=(c * 37) % 5000)
    p = Program()
    p.w(A["TEMP_WARN_THRESH"], thr)
    p.w(A["IRQ_EN"], S.IRQ["THERM_WARN"])
    enable(p, at=20)
    p.r(A["TEMP_LAST"], at=k + 20, label="tl")
    p.r(A["TEMP_MINMAX"], label="tmm")
    p.r(A["STATUS"], label="st")
    snapshot(p, "s", ["THERMAL_WARN_EVENTS", "TEMP_SAMPLES", "PWR_STATE_TRANSITIONS",
                      "PSTATE0_CYCLES", "PSTATE1_CYCLES", "PSTATE2_CYCLES", "PSTATE3_CYCLES",
                      "CORE_CLK_EN_CYCLES"], at=2000)
    p.r(A["PWR_STATUS"], label="ps")
    p.r(A["PWR_MEAS_SAMPLES"], label="pws")
    rd64(p, A["PWR_MEAS_SUM_LO"], "pwsum")
    p.r(A["PWR_MEAS_LAST"], label="pwl")
    p.r(A["QOCC_MAX"], label="qmax")
    p.w(A["CMD"], S.CMD["GAUGE_CLEAR"])
    p.r(A["TEMP_MINMAX"], label="tmm_clr")
    p.r(A["PWR_MEAS_SAMPLES"], label="pws_clr")

    def check(reads, model):
        err = []
        if reads["tl"][0] != (1 << 31) | temps[-1]:
            err.append("TEMP_LAST")
        mm = reads["tmm"][0]
        if (mm & 0xFFF) != min(temps) or (mm >> 16) != max(temps):
            err.append(f"TEMP_MINMAX {mm:#x}")
        if v64(reads, "s.THERMAL_WARN_EVENTS") != episodes:
            err.append(f"warn episodes {v64(reads, 's.THERMAL_WARN_EVENTS')} != {episodes}")
        if v64(reads, "s.TEMP_SAMPLES") != len(temps):
            err.append("TEMP_SAMPLES")
        if not (reads["st"][0] >> 3) & 1:
            err.append("warn_state should be set (last sample above threshold)")
        en = acc_cycle(p, "enable")
        tot = acc_cycle(p, "s.cmd") - en - 1
        res = [0, 0, 0, 0]
        # inputs at edge j counted if j+1 in counted window (en+1 .. snap-1) -> j in [en, snap-2]
        snap = acc_cycle(p, "s.cmd")
        trans = 0
        prev = 0
        for j in range(0, snap - 1):
            st = [s for c, s in pst if c <= j][-1] if 1000 <= j < 1500 else 0
            if j >= en:
                res[st] += 1
                if st != prev:
                    trans += 1
            prev = st
        for i in range(4):
            if v64(reads, f"s.PSTATE{i}_CYCLES") != res[i]:
                err.append(f"PSTATE{i} residency {v64(reads, f's.PSTATE{i}_CYCLES')} != {res[i]}")
        if sum(res) != tot:
            err.append("residency does not sum to CYCLES")
        if v64(reads, "s.PWR_STATE_TRANSITIONS") != trans:
            err.append(f"transitions {v64(reads, 's.PWR_STATE_TRANSITIONS')} != {trans}")
        if v64(reads, "s.CORE_CLK_EN_CYCLES") != sum(1 for j in range(1000, 1500) if j % 4):
            err.append("CORE_CLK_EN_CYCLES")
        if reads["pws"][0] != len(pw) or v64(reads, "pwsum") != sum(c for _, c in pw):
            err.append("power sensor accumulation")
        if reads["pwl"][0] != pw[-1][1] or not (reads["ps"][0] >> 2) & 1:
            err.append("power last / present")
        if reads["qmax"][0] != max((c * 37) % 5000 for c in range(1600, 1900)):
            err.append("QOCC_MAX")
        if reads["tmm_clr"][0] != 0xFFF or reads["pws_clr"][0] != 0:
            err.append("GAUGE_CLEAR")
        return err
    return w.c, p, check


# ---------------------------------------------------------------------- random soak
def _rand_vector(rng, density):
    f = {}
    for n, wdt, idle in S.WORKLOAD_FIELDS:
        if n == "thermal_fault_n":
            f[n] = 0 if rng.random() < 0.02 else 1
        elif n == "pwr_sensor_present":
            f[n] = 1
        elif n.startswith("ras_") and n != "ras_info":
            f[n] = rng.getrandbits(wdt) if rng.random() < density * 0.05 else 0
        elif rng.random() < density:
            f[n] = rng.getrandbits(wdt)
    return f


def _rand_program(rng, n_ops, span):
    regs = [r for r in S.SPEC["regs"]]
    p = Program()
    p.w(A["CTRL"], ctrl_value(global_en=1, trace_en=1), label="en")
    t = 0
    for i in range(n_ops):
        t += rng.randrange(0, max(1, 2 * span // n_ops))
        priv = 1 if rng.random() < 0.8 else 0
        user = rng.randrange(4)
        roll = rng.random()
        if roll < 0.30:
            addr = live_addr(rng.randrange(S.NUM_EV)) + 4 * rng.randrange(2)
        elif roll < 0.45:
            addr = snap_addr(rng.randrange(S.NUM_EV)) + 4 * rng.randrange(2)
        elif roll < 0.55:
            addr = (dsnap_addr if rng.random() < 0.5 else dlive_addr)(
                rng.randrange(4), rng.randrange(S.NUM_DEV)) + 4 * rng.randrange(2)
        elif roll < 0.95:
            addr = rng.choice(regs)["offset"]
        else:
            addr = rng.randrange(0x4000) & ~(0 if rng.random() < 0.3 else 3)
        if rng.random() < 0.25:
            r = S.REG_BY_OFF.get(addr)
            if r and r["name"] == "CMD":
                data = rng.getrandbits(7) & (0x7F if rng.random() < 0.3 else 0x01)
            elif r and r["name"] == "CTRL":
                data = rng.getrandbits(32) | 1 if rng.random() < 0.9 else rng.getrandbits(32)
                data &= ~0x2 if rng.random() < 0.7 else ~0
            else:
                data = rng.getrandbits(32)
            p.w(addr, data, priv, user, at=t)
        else:
            p.r(addr, priv, user, at=t)
    return p


def make_random(seed, n_cycles=12000, density=0.35, n_ops=1500):
    def fn():
        rng = random.Random(seed)
        w = [_rand_vector(rng, density) for _ in range(n_cycles)]
        p = _rand_program(rng, n_ops, n_cycles)
        return w, p, None
    return fn


def make_random_tx(seed, n_cycles=10000):
    """Random but protocol-valid transaction traffic + random APB, heavy tracing."""
    def fn():
        rng = random.Random(seed)
        w = WL(n_cycles)
        busy = {}
        for k in range(50, n_cycles - 200):
            if rng.random() < 0.15:
                tg = rng.randrange(32)
                if busy.get(tg, -1) >= k:
                    continue
                times = [k]
                cur = k
                ok = True
                for st in range(1, 7):
                    cur += rng.randrange(0, 20)
                    times.append(cur)
                for st, tt in enumerate(times):
                    if tt < len(w.c) and (w.c[tt].get("mk_valid", 0) >> st) & 1:
                        ok = False
                if not ok:
                    continue
                for st, tt in enumerate(times):
                    if rng.random() < 0.9 or st in (0, 6):
                        w.mark(tt, S.STAGES[st], tg, dom=rng.randrange(4) if st == 0 else None)
                busy[tg] = times[6]
            w.set(k, **{f: v for f, v in _rand_vector(rng, 0.2).items() if f not in
                        ("mk_valid", "mk_tag", "mk_arr_dom")})
        p = Program()
        p.w(A["TRACE_SAMPLE"], rng.choice([0, 1, 2, 5]))
        p.w(A["CTRL"], ctrl_value(global_en=1, trace_en=1))
        t = 0
        while t < n_cycles:
            t += rng.randrange(20, 120)
            for wd in range(10):
                p.r(A[f"TRACE_HEAD{wd}"], at=t)
            p.w(A["TRACE_POP"], 1)
            if rng.random() < 0.1:
                p.w(A["CMD"], S.CMD["SNAPSHOT"])
                for i in rng.sample(range(S.NUM_EV), 6):
                    rd64(p, snap_addr(i), f"x{t}.{i}")
            if rng.random() < 0.03:
                p.w(A["CMD"], rng.choice([S.CMD["HIST_CLEAR"], S.CMD["TRACE_FLUSH"],
                                          S.CMD["RESET_COUNTERS"]]))
            if rng.random() < 0.05:
                p.r(A[f"HIST_BIN{rng.randrange(16)}"])
        return w.c, p, None
    return fn


ALL = [
    Scenario("p1_core_events", 1, p1_core_events,
             desc="cycle counters, DMA bytes, packet counters, command completions; enable/disable"),
    Scenario("p1_simultaneous_lanes", 1, p1_simultaneous_lanes,
             desc="all phase-1 lanes retire in the same cycle at maximum value"),
    Scenario("simultaneous_all", 2, simultaneous_all,
             desc="every event at maximum per-cycle increment simultaneously"),
    Scenario("wrap_saturate", 2, wrap_saturate, cnt_w_agnostic=True,
             desc="wrap, saturate, sticky overflow, W1C, IRQ, coherent LO/HI across carry"),
    Scenario("reset_freeze", 2, reset_freeze,
             desc="reset, atomic read-and-clear, SW freeze, freeze-on-fatal, unfreeze"),
    Scenario("snapshot_atomic", 2, snapshot_atomic,
             desc="atomic snapshots under constant traffic, static snapshot regs, seqlock"),
    Scenario("domains_isolation", 2, domains_isolation,
             desc="per-domain attribution, tenant isolation, coarsened shared counters"),
    Scenario("cdc_thermal_fault", 2, cdc_thermal_fault,
             desc="async thermal fault pin through 2-FF synchronizer, exact latency"),
    Scenario("errlog_ras", 2, errlog_ras,
             desc="RAS sources, simultaneous errors, masking, overflow, first-error, clear"),
    Scenario("trace_latency", 2, trace_latency,
             desc="trace records vs known stage times, corner cases, sampling, drops, histogram"),
    Scenario("power_thermal_gauges", 2, power_thermal_gauges,
             desc="temperature gauges, warning episodes, P-state residency, clock duty, power"),
    Scenario("random_soak_s1", 2, make_random(1), cnt_w_agnostic=True,
             desc="random inputs + random APB (incl. tenant, unmapped, commands)"),
    Scenario("random_soak_s2", 2, make_random(2, density=0.7), cnt_w_agnostic=True,
             desc="dense random inputs + random APB"),
    Scenario("random_soak_s3", 2, make_random(3, density=0.1, n_ops=3000), cnt_w_agnostic=True,
             desc="sparse inputs, APB-heavy"),
    Scenario("random_tx_s4", 2, make_random_tx(4), cnt_w_agnostic=True,
             desc="random protocol-valid transactions, tracing and drains"),
    Scenario("random_tx_s5", 2, make_random_tx(5), cnt_w_agnostic=True,
             desc="random protocol-valid transactions, tracing and drains"),
]
