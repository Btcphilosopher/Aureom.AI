#!/usr/bin/env python3
"""SilicaFlux CloudTelemetry RTL regression.

For every scenario:
  1. build per-cycle input vectors (workload + APB program)
  2. run the Python reference model -> expected log
  3. run the RTL on Verilator and on Icarus with the same vectors -> logs
  4. require bit-exact equality of every APB readback, PSLVERR and irq edge
  5. run scenario-specific invariant checks on the readbacks

Phase gating: phase-1 scenarios (cycle counters, DMA bytes, packet counters,
command completions) run first; expansion scenarios only run if they pass.

Mutation mode (--mutations): rebuild the RTL with each deliberate bug and
require that at least one scenario FAILS for every mutant.
"""
import argparse
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "host"))
sys.path.insert(0, os.path.join(ROOT, "regress"))

from sftel import stim  # noqa: E402
from sftel.refmodel import TelemetryModel  # noqa: E402
import scenarios  # noqa: E402

BUILD = os.path.join(ROOT, "build")
RES = os.path.join(ROOT, "results")

MUTATIONS = {
    "SF_TEL_MUT_LANE_OR": "multi-lane packet accept counted with OR instead of popcount",
    "SF_TEL_MUT_SNAP_POST": "snapshot captures post-increment value (non-atomic)",
    "SF_TEL_MUT_WRAP_NO_OVF": "wrap does not set the sticky overflow flag",
    "SF_TEL_MUT_TENANT_LEAK": "tenant may read any domain's snapshot page",
    "SF_TEL_MUT_SYNC1": "thermal fault pin with single-flop synchronizer",
    "SF_TEL_MUT_DOM_FIRST_LANE": "DMA read lanes attributed to lane-0's domain",
    "SF_TEL_MUT_DOM_DROP_LANE1": "DMA write lane 1 never attributed to any domain",
}


def sh(cmd, **kw):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, **kw)


def build(sim, defines=(), tag="base", cnt_w=None):
    files = os.path.join(ROOT, "rtl", "files.f")
    dfl = " ".join(f"+define+{d}" for d in defines)
    gp = f"-GCNT_WIDTH={cnt_w}" if cnt_w else ""
    if sim == "verilator":
        mdir = os.path.join(BUILD, f"vl_{tag}")
        exe = os.path.join(mdir, "tb_player")
        # CNT_WIDTH override reaches the DUT through a TB define
        tdef = f"+define+SF_TEL_TB_CNT_W={cnt_w}" if cnt_w else ""
        cmd = (f"cd {ROOT} && verilator --binary --timing --assert -j 4 -Wno-fatal -Wno-UNUSEDPARAM "
               f"-Wno-WIDTHTRUNC -Wno-WIDTHEXPAND --top-module tb_player -Itb -Irtl {dfl} {tdef} "
               f"-f {files} tb/tb_player.sv --Mdir {mdir} -o tb_player")
        r = sh(cmd)
        if r.returncode != 0 or not os.path.exists(exe):
            raise RuntimeError("verilator build failed:\n" + r.stdout[-3000:] + r.stderr[-3000:])
        return exe
    exe = os.path.join(BUILD, f"iv_{tag}.vvp")
    dfl_iv = " ".join(f"-D{d}" for d in defines)
    tdef = f"-DSF_TEL_TB_CNT_W={cnt_w}" if cnt_w else ""
    r = sh(f"cd {ROOT} && iverilog -g2012 -Itb {dfl_iv} {tdef} -o {exe} -f {files} tb/tb_player.sv")
    if r.returncode != 0:
        raise RuntimeError("iverilog build failed:\n" + r.stderr[-3000:])
    return exe


def run_sim(sim, exe, stim_path, out_path):
    if sim == "verilator":
        cmd = f"{exe} +STIM={stim_path} +OUT={out_path}"
    else:
        cmd = f"vvp -n {exe} +STIM={stim_path} +OUT={out_path}"
    t0 = time.time()
    r = sh(cmd, timeout=3600)
    dt = time.time() - t0
    if r.returncode != 0:
        raise RuntimeError(f"{sim} run failed: {r.stdout[-2000:]} {r.stderr[-2000:]}")
    with open(out_path) as f:
        return [ln.rstrip("\n") for ln in f if ln.strip()], dt


def compare(expected, got):
    for i, (e, g) in enumerate(zip(expected, got)):
        if e != g:
            lo = max(0, i - 3)
            ctx = "\n".join(f"   exp: {a}\n   got: {b}" for a, b in zip(expected[lo:i + 1], got[lo:i + 1]))
            return f"first mismatch at log line {i}:\n{ctx}"
    if len(expected) != len(got):
        return f"length mismatch exp={len(expected)} got={len(got)}"
    return None


def reads_by_label(prog, log):
    """Map op label -> (rdata, err) using the access cycle recorded by merge()."""
    acc = {}
    for ln in log:
        if ln.startswith("A "):
            _, e, w, a, d, err = ln.split()
            acc[int(e)] = (int(d, 16), int(err))
    out = {}
    for op in prog.ops:
        if op.label is not None:
            out[op.label] = acc.get(op.access_cycle)
    return out


def coverage(vectors):
    """Which events/domain events received increments, and multi-unit increments."""
    from sftel.refmodel import TelemetryModel as TM
    import sftel.spec as S
    m = TM()
    seen, multi = set(), set()
    dseen = set()
    for v in vectors:
        m.step(v)
        for i, x in enumerate(m.inc_q):
            if x:
                seen.add(S.EVENTS[i]["name"])
                if x > 1:
                    multi.add(S.EVENTS[i]["name"])
        for i, x in enumerate(m.dinc_q):
            if x:
                dseen.add(S.DOM_EVENTS[i % S.NUM_DEV]["name"])
    return seen, multi, dseen


def run(selected=None, sims=("verilator", "icarus"), defines=(), tag="base", quiet=False,
        stop_on_fail=False, cnt_w=None, gate=True):
    os.makedirs(BUILD, exist_ok=True)
    work = os.path.join(BUILD, f"work_{tag}")
    os.makedirs(work, exist_ok=True)
    exes = {s: build(s, defines, tag, cnt_w) for s in sims}
    results = []
    all_scen = scenarios.ALL
    order = sorted(all_scen, key=lambda sc: sc.phase)
    phase1_failed = False
    for sc in order:
        if selected and sc.name not in selected:
            continue
        if gate and sc.phase > 1 and phase1_failed:
            results.append(dict(name=sc.name, phase=sc.phase, status="SKIPPED (phase-1 gate)"))
            continue
        if cnt_w and not sc.cnt_w_agnostic:
            continue
        t0 = time.time()
        workload, prog, checker = sc.build()
        vecs = stim.merge(workload, prog)
        sp = os.path.join(work, f"{sc.name}.stim")
        stim.write_stim(sp, vecs)
        model = TelemetryModel(cnt_w=cnt_w or 64)
        exp = stim.run_model(model, vecs)
        tm = time.time() - t0
        rec = dict(name=sc.name, phase=sc.phase, cycles=len(vecs),
                   apb_ops=len(prog.ops), model_s=round(tm, 2), sims={})
        ok = True
        for s in sims:
            try:
                got, dt = run_sim(s, exes[s], sp, os.path.join(work, f"{sc.name}.{s}.log"))
                diff = compare(exp, got)
            except RuntimeError as ex:      # simulator abort (e.g. RTL assertion)
                got, dt, diff = [], 0.0, f"simulator aborted: {str(ex)[:400]}"

            rec["sims"][s] = dict(status="PASS" if diff is None else "FAIL", seconds=round(dt, 2),
                                  log_lines=len(got))
            if diff:
                rec["sims"][s]["diff"] = diff
                ok = False
        # invariant checks on the model's predicted readbacks (identical to RTL when PASS)
        inv = []
        if checker:
            reads = reads_by_label(prog, exp)
            try:
                inv = checker(reads, model) or []
            except AssertionError as e:
                inv = [f"invariant assertion: {e}"]
        rec["invariants"] = "PASS" if not inv else inv
        if inv:
            ok = False
        rec["status"] = "PASS" if ok else "FAIL"
        if sc.phase == 1 and not ok:
            phase1_failed = True
        results.append(rec)
        if not quiet:
            sims_s = " ".join(f"{s}={rec['sims'][s]['status']}({rec['sims'][s]['seconds']}s)"
                              for s in sims)
            print(f"  [{rec['status']}] p{sc.phase} {sc.name:28s} cycles={len(vecs):7d} "
                  f"ops={len(prog.ops):5d} {sims_s} inv={'PASS' if not inv else 'FAIL'}")
            if not ok:
                for s in sims:
                    if "diff" in rec["sims"][s]:
                        print(f"      {s}: {rec['sims'][s]['diff']}")
                if inv:
                    for m in inv[:10]:
                        print("      invariant:", m)
        if stop_on_fail and not ok:
            break
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--sims", default="verilator,icarus")
    ap.add_argument("--mutations", action="store_true")
    ap.add_argument("--cnt-w", type=int, default=None)
    ap.add_argument("--defines", nargs="*", default=[])
    ap.add_argument("--out", default=os.path.join(RES, "regression_summary.json"))
    a = ap.parse_args()
    sims = tuple(a.sims.split(","))
    os.makedirs(RES, exist_ok=True)
    if a.mutations:
        print("Mutation analysis (each deliberate RTL bug must be caught):")
        summary = {}
        all_caught = True
        for d, desc in MUTATIONS.items():
            res = run(a.only, sims=("verilator",), defines=(d,), tag=d.lower(), quiet=True,
                      gate=False)
            failed = [r["name"] for r in res if r["status"] == "FAIL"]
            caught = bool(failed)
            all_caught &= caught
            summary[d] = dict(description=desc, caught=caught, failing_scenarios=failed)
            print(f"  {'CAUGHT ' if caught else 'MISSED '} {d:28s} by {failed if failed else '-'}")
        with open(os.path.join(RES, "mutation_summary.json"), "w") as f:
            json.dump(summary, f, indent=1)
        return 0 if all_caught else 1
    print(f"RTL regression on {', '.join(sims)}" + (f" (CNT_WIDTH={a.cnt_w})" if a.cnt_w else ""))
    t0 = time.time()
    tag = (f"w{a.cnt_w}" if a.cnt_w else "base") + ("_" + "_".join(a.defines).lower() if a.defines else "")
    res = run(a.only, sims=sims, cnt_w=a.cnt_w, tag=tag, defines=tuple(a.defines))
    n_pass = sum(r["status"] == "PASS" for r in res)
    print(f"{n_pass}/{len(res)} scenarios passed in {time.time() - t0:.1f}s")
    if not a.only and not a.cnt_w and not a.defines:
        # event coverage across all scenarios
        import sftel.spec as S
        seen, multi, dseen = set(), set(), set()
        for sc in scenarios.ALL:
            w, p, _ = sc.build()
            s1, m1, d1 = coverage(stim.merge(w, p))
            seen |= s1; multi |= m1; dseen |= d1
        allpass = n_pass == len(res)
        cov = {}
        for e in S.EVENTS:
            n = e["name"]
            if n in seen and allpass and (e["max_inc"] == 1 or n in multi):
                st = "verified" + (" (multi-unit/cycle)" if n in multi else "")
            elif n in seen:
                st = "exercised, multi-unit increments NOT covered" if allpass else "FAILING"
            else:
                st = "NOT exercised"
            cov[n] = dict(status=st, exercised=n in seen, multi=n in multi)
        for e in S.DOM_EVENTS:
            n = e["name"]
            cov[n] = dict(status=("verified" if (n in dseen and allpass) else
                                  ("NOT exercised" if n not in dseen else "FAILING")))
        with open(os.path.join(RES, "event_coverage.json"), "w") as f:
            json.dump(cov, f, indent=1)
        missing = [k for k, v in cov.items() if not v["status"].startswith("verified")]
        print(f"event coverage: {len(cov) - len(missing)}/{len(cov)} verified"
              + (f"; not verified: {missing}" if missing else ""))
    with open(a.out, "w") as f:
        json.dump(dict(generated=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                       sims=list(sims), results=res), f, indent=1)
    return 0 if n_pass == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
