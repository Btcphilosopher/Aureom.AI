# Clocks, timestamps and units

* **Counter clock.** Everything in the block runs on `clk`, the *telemetry
  clock*. Every timestamp (`TS`, `SNAP_TS`, trace arrival, stage deltas,
  error-log and first-error timestamps, histogram latencies) is a count of
  `clk` rising edges since reset. It is never host wall-clock time.
* **Cycle numbering in tests.** Edge 0 is the first rising edge after reset
  release; the value of `ts` used by a mark at edge *e* is *e*.
* **Seconds.** The hardware does not know its frequency. `TEL_CLK_HZ` is a
  register that firmware writes with the *nominal* frequency (0 = unknown).
  The collector derives per-second values only when it is non-zero and labels
  them "derived from the firmware-configured nominal clock, not measured". In
  the simulated experiments it is set to 250 MHz purely as a nominal
  conversion factor - there is no physical clock in simulation.
* **Host time.** The collector records `time.monotonic_ns()` before and after
  each snapshot as separate fields. It never subtracts host time from device
  cycles. A host-observed clock ratio could be estimated from two snapshots,
  but read latency makes it an estimate with uncertainty, and none is
  reported.
* **Effective core clock.** `CORE_CLK_EN_CYCLES / CYCLES x TEL_CLK_HZ` assumes
  the core clock is the telemetry clock gated by `core_clk_en`. It is a duty
  cycle, not a frequency measurement. A real frequency counter would need a
  second clock domain (with a CDC-safe Gray-coded crossing), not built here.
* **Clock-domain crossings.** Only `thermal_fault_n` is asynchronous: a single
  quasi-static level bit through a 2-flop synchronizer, then edge detection.
  Its exact 2-cycle detection latency is tested; a 1-flop variant
  (`SF_TEL_MUT_SYNC1`) is caught. All other inputs must be synchronous to
  `clk`; multi-bit crossings are not supported.
* **Simulation vs hardware read timing.** In the Verilator harness an APB read
  takes 2 device cycles. Real MMIO reads over PCIe take hundreds of
  nanoseconds to microseconds, so collector drain rates (and therefore trace
  drop rates) in simulation are optimistic and not predictive of hardware.
