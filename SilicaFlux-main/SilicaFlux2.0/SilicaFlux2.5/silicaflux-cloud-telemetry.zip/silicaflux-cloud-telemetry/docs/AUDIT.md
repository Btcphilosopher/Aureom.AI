# Repository audit (brief section 1)

**Date:** 2026-11-14. **Scope:** the workspace this build was produced in.

The brief asks to inspect existing SilicaFlux blocks and reuse verified
counters. The workspace contained **no SilicaFlux source code at all**: no
repository, RTL, testbench or host software from earlier projects. Earlier
SilicaFlux projects (PowerClock P27, ThermalLab P09, TensorCore 02,
InferenceScheduler P66, VirtualIO P63 and others) were delivered as separate
archives that are not present here. Nothing was assumed about their internals.

| Item to inspect | Found | Consequence in this build |
|---|---|---|
| Existing HPC performance counters | No | Counter bank written from scratch (`sf_tel_counter_bank.sv`); nothing reused, so no "verified counter" claims are inherited. |
| Tensor benchmark infrastructure | No | TensorCore activity is modelled by input contracts (`cmp_*` ports) driven by labelled stimulus. |
| Storage RAS | No | Error-log record format (`sf_tel_ras_log.sv`) is a generic first-error + FIFO design. **Must be reconciled with the Storage RAS architecture when that RTL is available.** |
| CloudDMA | No | `dma_*` lane ports define the expected per-lane byte/domain strobes. |
| PacketCore | No | `net_*` lane ports define accept/forward/drop strobes, TX bytes and queue occupancy. |
| PowerClock | No | `pwr_state`, `core_clk_en` ports. No DVFS or frequency-measurement claims. |
| ThermalLab | No (ThermalLab is a Python simulator, not RTL) | Raw sensor-code inputs; conversion to degrees C is a host-side calibration step. |
| Host runtime | No | New Python collector `host/sftel`. |
| Debug interface | No | APB4-style slave with PPROT/PAUSER-style sideband; the PCIe-to-APB bridge is outside this block. |

## Integration status of every source

Every external event is defined precisely as a port contract in
`docs/EVENT_CATALOGUE.md` (column *Integration*: `PENDING (source RTL absent)`).
The regression proves the telemetry engine counts those contracts correctly;
it cannot prove that a future CloudDMA/PacketCore/TensorCore will drive them
with the documented semantics. Integration is **blocked** on those blocks and
must include:

1. a per-source assertion that each strobe obeys its contract (e.g. at most one
   COMPLETE mark per cycle, lane byte counts <= 255 per cycle);
2. a re-run of the event-definition review with the source owner;
3. reconciliation of the RAS record format with Storage RAS.
