# Domain attribution and tenant isolation

## Attribution

Four accounting domains x eight domain events (`D_*`, see the catalogue).
Each DMA lane and each packet lane carries its own domain id, so lanes of
different domains retiring in the same cycle are split correctly; the
TensorCore is owned by one domain per cycle (`cmp_dom`); command completions
inherit the domain recorded at ARRIVE. Conservation (sum over domains ==
global counter for every byte/op/cycle event) is checked every cycle by an
in-RTL assertion (`SF_TEL_ASSERT`) and in the `domains_isolation` scenario.

Not attributed (by design): packets accepted/dropped (the domain of a packet
is known only at egress in the PacketCore contract), memory traffic, storage,
security and RAS events. Attributing those would need domain ids in the source
contracts; they are not invented here.

## Access policy (APB)

| Requester | Permitted | Everything else |
|---|---|---|
| Privileged (`PPROT[0]=1`) | all mapped registers; writes to RW/WO/W1C CSRs and live-counter LO (preload) | PSLVERR (decode error, not counted as a denial) |
| Tenant *d* (`PPROT[0]=0`, `PAUSER=d`) | reads of ID, VERSION, CAPS0/1, TEL_CLK_HZ, SNAP_SEQ, SNAP_TS; its own `DOM_SNAP` page *d*; shared snapshot counters only if `CTRL.TENANT_SHARED_EN` and the counter's bit is set in `TENANT_MASK0/1` | PSLVERR, read data 0, `TEL_ACCESS_DENIED++`, `VIOL_INFO` updated |

Tenants can never write, never read live counters (no fine-grained timing),
never read another domain's page, never read the trace/error logs or gauges.

## Limiting shared-resource leakage

Shared counters (e.g. global packet or DMA totals) can reveal a co-tenant's
activity. Mitigations implemented:

1. off by default (`TENANT_SHARED_EN=0`, `TENANT_MASK=0`);
2. per-counter opt-in by firmware;
3. snapshot-only: tenants see values only at firmware-chosen snapshot times;
4. coarsening: the low `CTRL.TENANT_COARSEN` bits (0-31) are zeroed in tenant
   reads of shared counters.

These reduce precision; they do **not** constitute a proof of side-channel
freedom. Snapshot timing chosen by firmware, `SNAP_TS`, and coarse totals can
still leak information. Policy review is needed before enabling shared
counters in production.

## Trust assumptions

* `PPROT`/`PAUSER` are driven by the PCIe-to-APB bridge from the requesting
  function (PF = privileged, VF *n* = domain *n*). Software cannot choose them.
  The bridge is outside this block and must be verified separately.
* Domain ids on event inputs come from the source blocks; a misattributing
  source cannot be detected here (only conservation can).
* Tenant ids are accounting labels, not a substitute for the DMA permission
  checks in CloudDMA/VirtualIO.
