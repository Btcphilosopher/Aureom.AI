# CloudTelemetry architecture

```
 CloudDMA  PacketCore  TensorCore  Memory  Storage  Security  RAS  PowerClock  Sensors  Cmd front-end/completion
    │          │           │          │       │        │        │       │         │            │ (stage marks)
    └──────────┴───────────┴──────────┴───────┴────────┴────────┴───────┴─────────┴────────────┘
                                         │  (all synchronous to clk, except thermal_fault_n)
                 ┌───────────────────────▼────────────────────────┐   ┌──────────────┐
                 │ sf_tel_event_collect                            │   │ sf_tel_sync2 │◄─ thermal_fault_n (async)
                 │  lane adder trees / popcounts → inc_d[47]       │◄──┤ + edge detect│
                 │  per-domain attribution        → dinc_d[4×8]    │   └──────────────┘
                 │  registered: inc_q, dinc_q                      │
                 └──────┬──────────────────────────┬───────────────┘
              ┌─────────▼─────────┐       ┌────────▼─────────┐   ┌───────────────────┐   ┌──────────────┐
              │ global bank (47)  │       │ domain bank (32) │   │ sf_tel_trace      │   │ sf_tel_ras_log│
              │ cnt ─snap→ shadow │       │ cnt ─snap→ shadow│   │ tag table (32)    │   │ FIFO(16)+first│
              │ wrap/sat, OVF     │       │ wrap/sat, OVF    │   │ record FIFO (16)  │   └──────┬───────┘
              └─────────┬─────────┘       └────────┬─────────┘   │ → sf_tel_hist     │          │
                        │                          │             └─────────┬─────────┘          │
                        └──────────────┬───────────┴───────────────────────┴──────────┬─────────┘
                                ┌──────▼──────────────────────────────────────────────▼──┐  ┌──────────────┐
                                │ sf_tel_regs: APB slave, access policy, CSRs, commands,  │◄─┤ sf_tel_gauges│
                                │ seqlock snapshot, HI latch, freeze, IRQ                 │  └──────────────┘
                                └──────────────────────────┬──────────────────────────────┘
                                                           │ APB (PCIe-to-APB bridge outside this block)
                                                    host collector (host/sftel)
```

Top: `rtl/silicaflux_cloud_telemetry.sv` (parameter `CNT_WIDTH`, default 64).
One clock domain (`clk`). Reset is asynchronous active-low.

## Timing contract (exact; the reference model implements exactly this)

All state changes on rising edges. "Edge *j*" decisions use the state held
before edge *j*.

| What | When |
|---|---|
| Event inputs sampled | edge *j* → `inc_q` |
| Counter update | edge *j+1*: `cnt += inc_q` if `GLOBAL_EN && !SW_FREEZE && !hw_frozen && EV_EN[i]` (control state held before edge *j+1*) |
| Snapshot | the edge of the CMD write: `shadow <= cnt` (pre-update) for all 79 counters at once; `SNAP_SEQ++`, `SNAP_TS <= ts` |
| RESET_COUNTERS | same edge: counters, OVF, histogram, trace protocol stats, record sequence and VIOL_INFO cleared; increment due that edge discarded. With SNAPSHOT in the same write this is an atomic read-and-clear. |
| Preload (debug) | privileged write to a live LO address sets `{PRELOAD_HI, wdata}`; that counter's increment that edge is discarded |
| Timebase `ts` | +1 every edge from reset; never cleared by software; marks/records use `ts` before the edge |
| APB setup edge | decode, access policy, read data capture (`rdata_q`), live-LO HI latch, denial counted |
| APB access edge | writes and command pulses take effect; PSLVERR driven in the access phase |
| Histogram | sample registered at edge *j*, applied at *j+1* with the same gating as the counters |
| Freeze-on-fatal | fatal sampled at *j* → `hw_frozen` set at *j+1* → counting stops from *j+2* (the fatal cycle's own increments are captured) |
| Thermal fault pin | low sampled at *p* → s1@*p*, s2@*p+1*, falling edge detected at *p+2* (event, error log, timestamp *p+2*) |

## Counters

* Width `CNT_WIDTH` (64 default; 32 also regression-tested). Per-event wrap or
  saturate (`SAT0/1`, `DOM_CTRL[8]`). Sticky overflow on carry-out (wrap) or
  clipping (saturate); set beats write-1-to-clear in the same edge.
* Increment width 16 bits; every event's maximum per-cycle increment is in the
  catalogue and is < 2^16 (enforced by the spec checker).
* Multi-lane events are adder trees / popcounts (`SF_TEL_MUT_LANE_OR` proves
  the regression catches an OR).

## 64-bit reads on a 32-bit bus

* **Snapshot registers** are static between snapshots: read LO and HI in any
  order. Coherence across many registers uses the **seqlock**: write SNAPSHOT,
  read `SNAP_SEQ`, read the window, read `SNAP_SEQ` again, retry on change.
* **Live pairs** (`LIVE_CNT`, `DOM_LIVE`, `TS`, `PWR_MEAS_SUM`, `HIST_SUM`):
  reading LO latches the high word into a single shared `HI_LATCH`; HI returns
  the latch. Consecutive LO/HI pairs must not be interleaved by two agents.
  Verified across a 32-bit carry under continuous counting.

## Latency tracing

* Seven single-mark ports (ARRIVE, DISPATCH, DMA_START, DMA_DONE, COMP_START,
  COMP_DONE, COMPLETE), each `{valid, tag}`; ARRIVE also carries the domain.
* A 32-entry tag table holds the arrival timestamp (64-bit) and 32-bit
  saturating deltas for intermediate stages. COMPLETE emits a 10-word record
  for *selected* transactions (filter: tag match/mask, domain; 1-in-N
  sampling decided at ARRIVE) into a 16-deep FIFO. Every selected completion
  increments the record sequence number, so drops are visible as gaps and in
  `TRACE_DROPS`.
* Corner cases are defined and tested: same-cycle ARRIVE + stage marks (delta
  0, new incarnation), COMPLETE + stage marks (included), COMPLETE + ARRIVE on
  the same tag (old closes, new opens), duplicate stage (first mark wins,
  flagged), orphan marks and tag reuse (counted in `TRACE_PROTO`).
* The log2 histogram counts **all** completions with a known arrival, not only
  traced ones.

## RAS

One error-log record per cycle in which any enabled source fires, carrying the
bitmap of all sources in that cycle, the 16-bit `ras_info` syndrome and the
timestamp. First-error capture is independent of FIFO space. `ECC_CORR` is
counted always but logged only if enabled in `ERRLOG_MASK` (default off, to
avoid flooding).

## Power and thermal

Gauges (not gated by enable/freeze): temperature last/min/max (raw codes),
warning episodes (rising crossings of `TEMP_WARN_THRESH`), power-state,
power-sensor last/samples/sum (raw codes, meaningful only with the
sensor-present strap), queue high-water. Counters: P-state residency and
transitions, clock-enable cycles.

## Interrupt

`irq = |(IRQ_STATUS & IRQ_EN)`; sources: counter overflow, error-log push,
trace record stored, thermal warning episode, hardware freeze. W1C, set wins.

## Resources (indicative, from the RTL structure - not a synthesis result)

Flip-flops dominated by 79 x 64-bit counters + 79 x 64-bit shadows (~10.1 kb),
the trace tag table (32 x ~235 b ~ 7.5 kb) and FIFOs (16 x 320 b + 16 x 88 b).
No synthesis numbers are claimed: Yosys 0.33 (the only synthesis tool
available) does not parse packed multi-dimensional port arrays.
