# Limitations and open items (honest status)

1. **No source blocks.** CloudDMA, PacketCore, TensorCore, storage, security,
   RAS, PowerClock and sensors are not in the repository. Events are driven by
   labelled stimulus. Integration is blocked (see `AUDIT.md`).
2. **No hardware, no FPGA.** No measurement from silicon or an FPGA exists.
   All experiment data are simulation with synthetic workloads, labelled as
   such everywhere (reports, exports, dashboard).
3. **No synthesis/timing results.** Yosys 0.33 cannot parse the packed 2-D
   ports. Area, Fmax and power are unknown. The single-cycle 64-bit adds, the
   47:1 / 32:1 read muxes and the 32-entry tag table read in the completion
   path are the likely timing hot spots; pipelining the read mux (a wait state)
   would be the first change if needed.
4. **Formal verification not done.** Verification is simulation-based (two
   simulators, independent model, analytic checks, mutation analysis). No
   SymbiYosys/JasperGold proofs.
5. **One mark per stage per cycle.** A front-end accepting two commands per
   cycle needs extra ARRIVE ports (or serialisation).
6. **Shared HI latch.** Live 64-bit pairs from two agents can interleave;
   use snapshots (seqlock) for multi-agent access.
7. **Single trace consumer.** Check-then-pop drain assumes one consumer.
8. **Trace capacity.** 16 records. MMIO drain over PCIe will be far slower
   than in simulation; expect drops at high command rates unless sampling is
   used. Drops are always counted and visible as sequence gaps.
9. **Side channels.** Tenant shared-counter coarsening and snapshot-only
   access reduce, but do not eliminate, cross-tenant leakage.
10. **Energy.** No calibrated activity model exists; the example coefficients
    are placeholders, and their output is labelled an uncalibrated estimate.
11. **Temperature.** Raw sensor codes only; conversion needs the real sensor's
    transfer function and per-part calibration.
12. **PCI IDs.** `0xFFFF:0x0069` are placeholders.
13. **Rust collector.** The brief allowed Rust or Python; Python was chosen so
    the collector shares one spec and one reference model with the regression.
14. **Dashboard fonts** load from Google Fonts (Bebas Neue, DM Mono) with
    system fallbacks when offline. Dark theme only (brand surface); the
    categorical palette is validated for that surface only.
