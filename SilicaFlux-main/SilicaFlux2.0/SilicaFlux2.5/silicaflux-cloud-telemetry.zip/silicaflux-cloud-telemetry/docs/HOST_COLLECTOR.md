# Host collector (`host/sftel`, Python 3.10+, no third-party runtime deps)

```
cd host
python3 -m sftel.cli discover                    # PCIe sysfs scan (placeholder IDs, see below)
python3 -m sftel.cli experiment mixed_tenants --cycles 120000 --out ../experiments
python3 -m sftel.cli summary ../experiments/mixed_tenants.json
python3 -m sftel.cli export ../experiments/mixed_tenants.json --format prom
python3 -m sftel.cli dashboard --experiments ../experiments -o ../dashboard/index.html
python3 -m sftel.cli snapshot --bar /sys/bus/pci/devices/<BDF>/resource0   # hardware
```

## Backends (`sftel.backends`)

| Backend | Origin label | What it is |
|---|---|---|
| `VerilatorBackend` | `simulation` | Spawns `build/vl_harness/sftel_harness` (the real RTL compiled by Verilator) and talks to it over a line protocol; workload vectors keep playing while the host reads. |
| `ModelBackend` | `simulation` | The cycle-accurate reference model with identical cycle semantics. The same collector session on both backends yields byte-identical reports (tested). |
| `PcieBackend` + `discover()` | `hardware` | sysfs scan for vendor/device IDs and `mmap` of `resource0`. **The IDs `0xFFFF:0x0069` are placeholders** (no PCI ID has been assigned); tested only against a synthetic sysfs tree. |

## Driver protocol (`sftel.device`)

* `identify()` checks ID and that CAPS (event count, domains, widths) match the
  host spec; mismatches are fatal.
* `snapshot()` uses the seqlock (retries if `SNAP_SEQ` changes).
* `drain_trace()` / `drain_errlog()` are check-then-pop, single consumer.

## Report (`sftel-report/1`)

Every statistic carries `{origin, backend, registers, snapshot_seq,
window_ts_cycles}`, a `kind` (`counter`, `gauge`, `derived`, `measured_raw`,
`estimate`) and, for derived values, the formula. Sections: metrics, domains,
time series, latency (exact quantiles from observed records + histogram
bounds + stage breakdown + integrity), RAS, snapshots, verification.

* **Quantiles** are nearest-rank values of observed records and are flagged
  `insufficient` when n < 1/(1-p) (e.g. P99.9 needs at least 1000 samples).
* **Histogram quantiles** are bucket bounds `[lower, upper)` over all
  completions (log2 resolution, up to 2x uncertainty).
* **Utilisation** is reported only against an explicit platform profile; the
  default profile states its capacities are assumptions matching the
  synthetic workload, not CloudDMA datasheet values.
* **Power**: `measured_raw` values come only from the power-sensor path when
  the present strap is set (in simulation the sensor input is synthetic
  stimulus, and the note says so). `estimate` values come only from an
  activity model file; the bundled `energy_model_example.json` is marked
  uncalibrated, so its output is an index, not energy.

## Exports

* JSON: the full report.
* CSV: one row per metric with origin/backend/registers/snapshot/derivation columns.
* Prometheus text exposition: every sample has `origin`, `backend`, `kind`
  and `experiment` labels, so simulated series are never mistaken for
  production series; HELP text names the source registers.
