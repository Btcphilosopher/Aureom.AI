"""SilicaFlux Project 69 - CloudTelemetry: single source of truth.

Everything that must agree between the RTL, the testbenches, the
cycle-accurate reference model and the host collector is defined here:

  * structural parameters (lanes, domains, tags, depths)
  * the global and per-domain event catalogue (IDs, units, definitions)
  * the register map (offsets, access types, reset values, tenant policy)
  * the stimulus layout used by the SV vector player and the C++ harness

`tools/gen_all.py` turns this module into:
  rtl/sf_tel_pkg.sv, tb/sf_tel_stim_layout.svh, sim/sf_tel_stim_layout.h,
  host/sftel/data/telemetry_spec.json, docs/REGISTER_MAP.md,
  docs/EVENT_CATALOGUE.md

Do not hand-edit the generated files.
"""

# ---------------------------------------------------------------------------
# Structural parameters
# ---------------------------------------------------------------------------
PARAMS = {
    "CNT_W": 64,          # counter width (bits); parameter of the top module
    "INC_W": 16,          # max per-cycle increment width of any event
    "NUM_DOM": 4,         # tenant/accounting domains
    "DOM_W": 2,
    "TAG_W": 5,           # command tag width -> 32 outstanding commands tracked
    "NUM_STAGES": 7,
    "TRACE_DEPTH_LOG2": 4,   # 16 completion records
    "ERRLOG_DEPTH_LOG2": 4,  # 16 error-log records
    "HIST_BINS": 16,
    "TL": 4,              # tensor lanes  (ops retired per lane per cycle, 8b)
    "VL": 2,              # vector lanes
    "KP": 2,              # kernel-completion ports
    "PL": 4,              # packet lanes
    "DL": 2,              # DMA lanes (read and write each)
    "SB": 8,              # SRAM banks (conflict strobes)
    "ECC_N": 4,           # ECC-protected memory instances (correction strobes)
}

ID_VALUE = 0x5F7E0069        # "SF TEL 69"
VERSION_VALUE = 0x00010000   # 1.0

STAGES = ["ARRIVE", "DISPATCH", "DMA_START", "DMA_DONE",
          "COMP_START", "COMP_DONE", "COMPLETE"]

# ---------------------------------------------------------------------------
# Global event catalogue.  Index in this list == event ID == counter index.
# max_inc: largest legal per-cycle increment (must fit INC_W).
# phase: 1 = first verified set (cycles, DMA bytes, packets, completions),
#        2 = expansion set.
# ---------------------------------------------------------------------------
P = PARAMS
EVENTS = [
    dict(name="CYCLES", group="core", unit="cycles", max_inc=1, phase=1,
         source="telemetry", signals=["(internal)"],
         definition="+1 on every telemetry-clock edge at which counting is active "
                    "(CTRL.GLOBAL_EN=1 and not frozen). Denominator for all rates."),
    dict(name="CMD_ARRIVED", group="core", unit="commands", max_inc=1, phase=1,
         source="host front-end", signals=["mk_valid[ARRIVE]"],
         definition="+1 per cycle in which the ARRIVE mark port is valid (one command "
                    "accepted by the command front-end)."),
    dict(name="CMD_COMPLETED", group="core", unit="commands", max_inc=1, phase=1,
         source="completion engine", signals=["mk_valid[COMPLETE]"],
         definition="+1 per cycle in which the COMPLETE mark port is valid. Counts "
                    "every completion pulse, including completions whose tag had no "
                    "recorded arrival (those are also counted in TRACE_PROTO.orphan)."),
    dict(name="DMA_RD_BYTES", group="dma", unit="bytes", max_inc=P["DL"] * 255, phase=1,
         source="CloudDMA", signals=["dma_rd_bytes[DL][8]"],
         definition="Sum over all DMA read lanes of bytes retired this cycle "
                    "(host->device). Lanes are summed, never OR-ed."),
    dict(name="DMA_WR_BYTES", group="dma", unit="bytes", max_inc=P["DL"] * 255, phase=1,
         source="CloudDMA", signals=["dma_wr_bytes[DL][8]"],
         definition="Sum over all DMA write lanes of bytes retired this cycle "
                    "(device->host)."),
    dict(name="PKT_ACCEPTED", group="network", unit="packets", max_inc=P["PL"], phase=1,
         source="PacketCore", signals=["net_pkt_accept[PL]"],
         definition="Population count of packet lanes signalling 'packet accepted "
                    "into ingress' this cycle."),
    dict(name="PKT_FORWARDED", group="network", unit="packets", max_inc=P["PL"], phase=1,
         source="PacketCore", signals=["net_pkt_fwd[PL]"],
         definition="Population count of lanes signalling 'packet forwarded to egress'."),
    dict(name="PKT_DROPPED", group="network", unit="packets", max_inc=P["PL"], phase=1,
         source="PacketCore", signals=["net_pkt_drop[PL]"],
         definition="Population count of lanes signalling 'packet dropped' (any reason)."),
    dict(name="NET_TX_BYTES", group="network", unit="bytes", max_inc=P["PL"] * 255, phase=1,
         source="PacketCore", signals=["net_tx_bytes[PL][8]"],
         definition="Sum over packet lanes of bytes transmitted on egress this cycle."),
    dict(name="DMA_STALL_CYCLES", group="dma", unit="cycles", max_inc=1, phase=2,
         source="CloudDMA", signals=["dma_stall"],
         definition="+1 per cycle with dma_stall asserted (DMA engine has work but "
                    "cannot issue)."),
    dict(name="NET_QOCC_ACCUM", group="network", unit="entry-cycles", max_inc=65535, phase=2,
         source="PacketCore", signals=["net_q_occ[16]"],
         definition="Adds the instantaneous egress-queue occupancy every cycle. "
                    "Mean occupancy = delta(NET_QOCC_ACCUM)/delta(CYCLES)."),
    dict(name="TENSOR_OPS", group="compute", unit="ops", max_inc=P["TL"] * 255, phase=2,
         source="TensorCore", signals=["cmp_tensor_ops[TL][8]"],
         definition="Sum over tensor lanes of MAC operations retired this cycle."),
    dict(name="VECTOR_OPS", group="compute", unit="ops", max_inc=P["VL"] * 255, phase=2,
         source="Vector unit", signals=["cmp_vector_ops[VL][8]"],
         definition="Sum over vector lanes of element operations retired this cycle."),
    dict(name="KERNELS_COMPLETED", group="compute", unit="kernels", max_inc=P["KP"], phase=2,
         source="TensorCore", signals=["cmp_kernel_done[KP]"],
         definition="Population count of kernel-completion ports pulsing this cycle."),
    dict(name="COMPUTE_BUSY_CYCLES", group="compute", unit="cycles", max_inc=1, phase=2,
         source="TensorCore", signals=["cmp_busy"],
         definition="+1 per cycle with cmp_busy asserted."),
    dict(name="COMPUTE_STALL_CYCLES", group="compute", unit="cycles", max_inc=1, phase=2,
         source="TensorCore", signals=["cmp_stall"],
         definition="+1 per cycle with cmp_stall asserted (busy but waiting on operands)."),
    dict(name="MEM_RD_BYTES", group="memory", unit="bytes", max_inc=255, phase=2,
         source="on-chip memory", signals=["mem_rd_bytes[8]"],
         definition="Bytes read from on-chip memory this cycle."),
    dict(name="MEM_WR_BYTES", group="memory", unit="bytes", max_inc=255, phase=2,
         source="on-chip memory", signals=["mem_wr_bytes[8]"],
         definition="Bytes written to on-chip memory this cycle."),
    dict(name="SRAM_BANK_CONFLICTS", group="memory", unit="conflicts", max_inc=P["SB"], phase=2,
         source="on-chip memory", signals=["sram_conflict[SB]"],
         definition="Population count of SRAM banks reporting an access conflict this cycle."),
    dict(name="MIGRATION_BYTES", group="memory", unit="bytes", max_inc=255, phase=2,
         source="memory migration engine", signals=["mig_bytes[8]"],
         definition="Bytes moved by the page/buffer migration engine this cycle."),
    dict(name="STO_CMDS", group="storage", unit="commands", max_inc=1, phase=2,
         source="storage controller", signals=["sto_cmd"],
         definition="+1 per I/O command accepted by the storage controller."),
    dict(name="STO_READS_DONE", group="storage", unit="commands", max_inc=1, phase=2,
         source="storage controller", signals=["sto_rd_done"],
         definition="+1 per completed storage read."),
    dict(name="STO_WRITES_DONE", group="storage", unit="commands", max_inc=1, phase=2,
         source="storage controller", signals=["sto_wr_done"],
         definition="+1 per completed storage write."),
    dict(name="STO_ERRORS", group="storage", unit="events", max_inc=1, phase=2,
         source="storage controller", signals=["sto_err"],
         definition="+1 per storage command completed with error status."),
    dict(name="STO_INTEGRITY_FAIL", group="storage", unit="events", max_inc=1, phase=2,
         source="storage controller", signals=["sto_integ_fail"],
         definition="+1 per end-to-end data-integrity check failure. Also an error-log source."),
    dict(name="SEC_AUTH_FAIL", group="security", unit="events", max_inc=1, phase=2,
         source="security block", signals=["sec_auth_fail"],
         definition="+1 per authentication failure reported by the security block."),
    dict(name="SEC_PERM_VIOL", group="security", unit="events", max_inc=1, phase=2,
         source="security block", signals=["sec_perm_viol"],
         definition="+1 per permission violation reported by the security block "
                    "(e.g. DMA outside a domain's window)."),
    dict(name="SEC_INVALID_CMD", group="security", unit="events", max_inc=1, phase=2,
         source="security block", signals=["sec_invalid_cmd"],
         definition="+1 per malformed/invalid command rejected."),
    dict(name="RAS_ECC_CORR", group="ras", unit="events", max_inc=P["ECC_N"], phase=2,
         source="ECC memories", signals=["ras_ecc_corr[ECC_N]"],
         definition="Population count of ECC instances reporting a corrected error this cycle."),
    dict(name="RAS_ECC_UNCORR", group="ras", unit="events", max_inc=1, phase=2,
         source="ECC memories", signals=["ras_ecc_uncorr"],
         definition="+1 per uncorrectable ECC error pulse. Error-log source."),
    dict(name="RAS_DMA_FAIL", group="ras", unit="events", max_inc=1, phase=2,
         source="CloudDMA", signals=["ras_dma_fail"],
         definition="+1 per DMA transfer failure. Error-log source."),
    dict(name="RAS_CTRL_RESET", group="ras", unit="events", max_inc=1, phase=2,
         source="controllers", signals=["ras_ctrl_reset"],
         definition="+1 per controller reset event. Error-log source."),
    dict(name="RAS_THERMAL_FAULT", group="ras", unit="events", max_inc=1, phase=2,
         source="thermal sensor alert pin", signals=["thermal_fault_n (async)"],
         definition="+1 per falling edge of the asynchronous active-low thermal fault "
                    "pin, after a 2-flop synchronizer. Error-log source."),
    dict(name="RAS_WATCHDOG", group="ras", unit="events", max_inc=1, phase=2,
         source="watchdog", signals=["ras_watchdog"],
         definition="+1 per watchdog expiry pulse. Error-log source."),
    dict(name="RAS_FATAL", group="ras", unit="events", max_inc=1, phase=2,
         source="RAS aggregator", signals=["ras_fatal"],
         definition="+1 per fatal error pulse. Error-log source; triggers hardware freeze "
                    "when CTRL.FREEZE_ON_FATAL=1."),
    dict(name="PWR_STATE_TRANSITIONS", group="power", unit="transitions", max_inc=1, phase=2,
         source="PowerClock", signals=["pwr_state[2]"],
         definition="+1 per cycle where sampled pwr_state differs from the previous sampled "
                    "value (previous value resets to P0)."),
    dict(name="PSTATE0_CYCLES", group="power", unit="cycles", max_inc=1, phase=2,
         source="PowerClock", signals=["pwr_state[2]"],
         definition="+1 per cycle with pwr_state == 0 (residency)."),
    dict(name="PSTATE1_CYCLES", group="power", unit="cycles", max_inc=1, phase=2,
         source="PowerClock", signals=["pwr_state[2]"],
         definition="+1 per cycle with pwr_state == 1 (residency)."),
    dict(name="PSTATE2_CYCLES", group="power", unit="cycles", max_inc=1, phase=2,
         source="PowerClock", signals=["pwr_state[2]"],
         definition="+1 per cycle with pwr_state == 2 (residency)."),
    dict(name="PSTATE3_CYCLES", group="power", unit="cycles", max_inc=1, phase=2,
         source="PowerClock", signals=["pwr_state[2]"],
         definition="+1 per cycle with pwr_state == 3 (residency)."),
    dict(name="CORE_CLK_EN_CYCLES", group="power", unit="cycles", max_inc=1, phase=2,
         source="PowerClock", signals=["core_clk_en"],
         definition="+1 per telemetry cycle in which the core clock-enable is high. "
                    "Effective core clock = TEL_CLK_HZ * dCORE_CLK_EN_CYCLES/dCYCLES "
                    "(derived, assumes core clock == telemetry clock gated by enable)."),
    dict(name="TEMP_SAMPLES", group="thermal", unit="samples", max_inc=1, phase=2,
         source="temperature sensor", signals=["temp_valid"],
         definition="+1 per valid temperature sample."),
    dict(name="THERMAL_WARN_EVENTS", group="thermal", unit="episodes", max_inc=1, phase=2,
         source="telemetry", signals=["temp_valid", "temp_code[12]", "TEMP_WARN_THRESH"],
         definition="+1 when a temperature sample >= TEMP_WARN_THRESH arrives and the "
                    "previous sample (or reset state) was below threshold (rising crossing)."),
    dict(name="TEL_ACCESS_DENIED", group="telemetry", unit="accesses", max_inc=1, phase=2,
         source="telemetry", signals=["APB"],
         definition="+1 per APB access refused by the domain access policy "
                    "(unprivileged access outside its permitted set)."),
    dict(name="TRACE_RECORDS", group="telemetry", unit="records", max_inc=1, phase=2,
         source="telemetry", signals=["(internal)"],
         definition="+1 per completion record written into the trace FIFO."),
    dict(name="TRACE_DROPS", group="telemetry", unit="records", max_inc=1, phase=2,
         source="telemetry", signals=["(internal)"],
         definition="+1 per selected completion whose record could not be stored "
                    "(FIFO full or flushed in the same cycle)."),
    dict(name="ERRLOG_DROPS", group="telemetry", unit="records", max_inc=1, phase=2,
         source="telemetry", signals=["(internal)"],
         definition="+1 per error-log entry that could not be stored (log full or cleared "
                    "in the same cycle)."),
]

DOM_EVENTS = [
    dict(name="D_CMD_ARRIVED", unit="commands", global_event="CMD_ARRIVED",
         definition="ARRIVE marks whose mk_arr_dom == d."),
    dict(name="D_CMD_COMPLETED", unit="commands", global_event="CMD_COMPLETED",
         definition="COMPLETE marks whose tag has a recorded arrival with domain d "
                    "(domain captured at ARRIVE). Orphan completions are not attributed."),
    dict(name="D_DMA_RD_BYTES", unit="bytes", global_event="DMA_RD_BYTES",
         definition="Sum over DMA read lanes with dma_rd_dom[lane] == d."),
    dict(name="D_DMA_WR_BYTES", unit="bytes", global_event="DMA_WR_BYTES",
         definition="Sum over DMA write lanes with dma_wr_dom[lane] == d."),
    dict(name="D_TENSOR_OPS", unit="ops", global_event="TENSOR_OPS",
         definition="All tensor-lane ops this cycle if cmp_dom == d (one domain owns "
                    "the TensorCore per cycle)."),
    dict(name="D_COMPUTE_BUSY_CYCLES", unit="cycles", global_event="COMPUTE_BUSY_CYCLES",
         definition="cmp_busy && cmp_dom == d."),
    dict(name="D_PKT_FORWARDED", unit="packets", global_event="PKT_FORWARDED",
         definition="Popcount of net_pkt_fwd lanes with net_lane_dom[lane] == d."),
    dict(name="D_NET_TX_BYTES", unit="bytes", global_event="NET_TX_BYTES",
         definition="Sum over packet lanes with net_lane_dom[lane] == d."),
]

# Error-log source bitmap bit positions.
ERRLOG_SRCS = ["ECC_UNCORR", "DMA_FAIL", "CTRL_RESET", "THERMAL_FAULT",
               "WATCHDOG", "FATAL", "STO_INTEGRITY_FAIL", "ECC_CORR"]

IRQ_BITS = ["OVF", "RAS", "TRACE", "THERM_WARN", "HW_FREEZE"]

CMD_BITS = ["SNAPSHOT", "RESET_COUNTERS", "UNFREEZE", "TRACE_FLUSH",
            "HIST_CLEAR", "ERRLOG_CLEAR", "GAUGE_CLEAR"]

CTRL_FIELDS = [
    ("GLOBAL_EN", 0, 1), ("SW_FREEZE", 1, 1), ("TRACE_EN", 2, 1),
    ("TENANT_SHARED_EN", 3, 1), ("FREEZE_ON_FATAL", 4, 1), ("TENANT_COARSEN", 8, 5),
]

# ---------------------------------------------------------------------------
# Register map.  access:
#   RO   read-only            RW  read/write          WO  write-only (reads 0)
#   W1C  write-1-to-clear     LO  64-bit live LO (read latches HI into HI_LATCH)
#   HI   returns HI_LATCH (latched by the most recent LO read of any live pair)
# tenant: "read" = readable by unprivileged requesters of any domain
# ---------------------------------------------------------------------------
NUM_EV = len(EVENTS)
EV_EN1_RESET = (1 << (NUM_EV - 32)) - 1

REGS = [
    ("ID",             0x000, "RO",  ID_VALUE, "read", "Identification value 0x5F7E0069."),
    ("VERSION",        0x004, "RO",  VERSION_VALUE, "read", "Major[31:16].Minor[15:0]."),
    ("CAPS0",          0x008, "RO",  None, "read", "[7:0] NUM_EV, [15:8] NUM_DOM_EV, [19:16] NUM_DOM, [26:20] CNT_W."),
    ("CAPS1",          0x00C, "RO",  None, "read", "[3:0] TAG_W, [7:4] log2 trace depth, [11:8] log2 errlog depth, [16:12] HIST_BINS."),
    ("TEL_CLK_HZ",     0x010, "RW",  0, "read", "Firmware-programmed nominal telemetry clock (Hz). 0 = unknown. Informational: never measured by hardware."),
    ("CTRL",           0x014, "RW",  0, None, "[0] GLOBAL_EN [1] SW_FREEZE [2] TRACE_EN [3] TENANT_SHARED_EN [4] FREEZE_ON_FATAL [12:8] TENANT_COARSEN."),
    ("CMD",            0x018, "WO",  0, None, "Write-1 pulses: [0] SNAPSHOT [1] RESET_COUNTERS [2] UNFREEZE [3] TRACE_FLUSH [4] HIST_CLEAR [5] ERRLOG_CLEAR [6] GAUGE_CLEAR."),
    ("STATUS",         0x01C, "RO",  None, None, "[0] counting_active [1] sw_freeze [2] hw_frozen [3] temp_warn_state [12:8] trace_count [20:16] errlog_count."),
    ("SNAP_SEQ",       0x020, "RO",  0, "read", "Increments on every SNAPSHOT (seqlock for coherent multi-register reads)."),
    ("SNAP_TS_LO",     0x024, "RO",  0, "read", "Timebase value captured at the last SNAPSHOT [31:0]."),
    ("SNAP_TS_HI",     0x028, "RO",  0, "read", "Timebase value captured at the last SNAPSHOT [63:32]."),
    ("TS_LO",          0x02C, "LO",  0, None, "Live 64-bit telemetry timebase (cycles since reset) [31:0]; latches [63:32]."),
    ("TS_HI",          0x030, "HI",  0, None, "HI_LATCH (from most recent live LO read)."),
    ("EV_EN0",         0x034, "RW",  0xFFFFFFFF, None, "Per-event count enable, events 0..31."),
    ("EV_EN1",         0x038, "RW",  EV_EN1_RESET, None, "Per-event count enable, events 32..NUM_EV-1."),
    ("SAT0",           0x03C, "RW",  0, None, "Per-event mode: 1 = saturate, 0 = wrap (events 0..31)."),
    ("SAT1",           0x040, "RW",  0, None, "Per-event mode, events 32..NUM_EV-1."),
    ("OVF0",           0x044, "W1C", 0, None, "Sticky overflow (wrapped or saturated), events 0..31."),
    ("OVF1",           0x048, "W1C", 0, None, "Sticky overflow, events 32..NUM_EV-1."),
    ("DOM_CTRL",       0x04C, "RW",  0xFF, None, "[7:0] per-domain-event enable, [8] domain counters saturate (1) / wrap (0)."),
    ("DOM_OVF",        0x050, "W1C", 0, None, "Sticky overflow of domain counter (bit d*8+e)."),
    ("IRQ_STATUS",     0x054, "W1C", 0, None, "[0] OVF [1] RAS [2] TRACE [3] THERM_WARN [4] HW_FREEZE."),
    ("IRQ_EN",         0x058, "RW",  0, None, "Interrupt enable mask; irq = |(IRQ_STATUS & IRQ_EN)."),
    ("VIOL_INFO",      0x05C, "RO",  0, None, "Last denied access: [31] valid [30] write [25:24] domain [15:0] address."),
    ("TENANT_MASK0",   0x060, "RW",  0, None, "Shared snapshot counters 0..31 readable by tenants when TENANT_SHARED_EN."),
    ("TENANT_MASK1",   0x064, "RW",  0, None, "Shared snapshot counters 32..NUM_EV-1 readable by tenants."),
    ("PRELOAD_HI",     0x068, "RW",  0, None, "Upper 32 bits used when a live counter LO address is written (debug preload)."),
    ("TEMP_LAST",      0x080, "RO",  0, None, "[11:0] last raw sensor code, [31] at least one sample seen."),
    ("TEMP_MINMAX",    0x084, "RO",  0x00000FFF, None, "[11:0] min code, [27:16] max code since GAUGE_CLEAR."),
    ("TEMP_WARN_THRESH", 0x088, "RW", 0xFFF, None, "[11:0] warning threshold (raw sensor code)."),
    ("PWR_STATUS",     0x08C, "RO",  0, None, "[1:0] current power state, [2] power sensor present strap."),
    ("PWR_MEAS_LAST",  0x090, "RO",  0, None, "[15:0] last raw power-sensor code."),
    ("PWR_MEAS_SAMPLES", 0x094, "RO", 0, None, "Number of power-sensor samples (saturating)."),
    ("PWR_MEAS_SUM_LO", 0x098, "LO", 0, None, "Sum of raw power codes [31:0]; latches [63:32]."),
    ("PWR_MEAS_SUM_HI", 0x09C, "HI", 0, None, "HI_LATCH."),
    ("QOCC_MAX",       0x0A0, "RO",  0, None, "[15:0] egress queue occupancy high-water mark."),
    ("TRACE_FILTER",   0x0C0, "RW",  0, None, "[4:0] tag match [12:8] tag mask [16] domain filter enable [21:20] domain."),
    ("TRACE_SAMPLE",   0x0C4, "RW",  0, None, "[15:0] select every N-th candidate arrival (0/1 = all). Write resets sample phase."),
    ("TRACE_POP",      0x0C8, "WO",  0, None, "Any write pops the trace FIFO head."),
    ("TRACE_PROTO",    0x0CC, "RO",  0, None, "[15:0] orphan stage marks, [31:16] tag reuse before completion (saturating)."),
] + [
    (f"TRACE_HEAD{i}", 0x0D0 + 4 * i, "RO", 0, None, d) for i, d in enumerate([
        "[31] valid [30] delta_saturated [29] duplicate_stage [22:16] stage_valid [9:8] domain [4:0] tag.",
        "Record sequence number (counts selected completions incl. dropped ones).",
        "Arrival timestamp [31:0] (telemetry cycles).",
        "Arrival timestamp [63:32].",
        "DISPATCH - ARRIVE (cycles, 0xFFFFFFFF = saturated).",
        "DMA_START - ARRIVE.",
        "DMA_DONE - ARRIVE.",
        "COMP_START - ARRIVE.",
        "COMP_DONE - ARRIVE.",
        "COMPLETE - ARRIVE (end-to-end latency).",
    ])
] + [
    (f"HIST_BIN{i}", 0x100 + 4 * i, "RO", 0, None,
     ("End-to-end latency count, " +
      ("latency in [0,2)" if i == 0 else
       (f"latency >= 2^{i}" if i == 15 else f"latency in [2^{i},2^{i+1})")) + " cycles (saturating)."))
    for i in range(16)
] + [
    ("HIST_SAMPLES",   0x140, "RO",  0, None, "Completions accumulated into the histogram (saturating)."),
    ("HIST_MAX",       0x144, "RO",  0, None, "Maximum end-to-end latency seen (cycles, saturating 32b)."),
    ("HIST_SUM_LO",    0x148, "LO",  0, None, "Sum of latencies [31:0]; latches [63:32]."),
    ("HIST_SUM_HI",    0x14C, "HI",  0, None, "HI_LATCH."),
    ("ERRLOG_MASK",    0x180, "RW",  0x7F, None, "Error-log source enable (bit per source; ECC_CORR disabled by default)."),
    ("ERRLOG_POP",     0x184, "WO",  0, None, "Any write pops the error-log head."),
    ("ERRLOG_HEAD0",   0x188, "RO",  0, None, "[31] valid [23:16] source bitmap [15:0] ras_info."),
    ("ERRLOG_HEAD_TS_LO", 0x18C, "RO", 0, None, "Head record timestamp [31:0]."),
    ("ERRLOG_HEAD_TS_HI", 0x190, "RO", 0, None, "Head record timestamp [63:32]."),
    ("FIRST_ERR_INFO", 0x194, "RO",  0, None, "First error since ERRLOG_CLEAR: [31] valid [23:16] sources [15:0] info."),
    ("FIRST_ERR_TS_LO", 0x198, "RO", 0, None, "First error timestamp [31:0]."),
    ("FIRST_ERR_TS_HI", 0x19C, "RO", 0, None, "First error timestamp [63:32]."),
]

WINDOWS = [
    dict(name="LIVE_CNT", base=0x0400, stride=8, count=NUM_EV, access="LO/HI",
         tenant=None,
         desc="Live global counter i at base+8i (LO, latches HI) and base+8i+4 (HI_LATCH). "
              "Writing LO preloads {PRELOAD_HI, wdata} (privileged debug)."),
    dict(name="SNAP_CNT", base=0x0800, stride=8, count=NUM_EV, access="RO",
         tenant="TENANT_SHARED_EN && TENANT_MASK bit, coarsened",
         desc="Snapshot copy of global counter i (static between snapshots)."),
    dict(name="DOM_SNAP", base=0x1000, stride=8, count=len(DOM_EVENTS), access="RO",
         page_stride=0x100, pages=PARAMS["NUM_DOM"], tenant="own domain only",
         desc="Snapshot copy of domain d counter e at base+0x100*d+8e."),
    dict(name="DOM_LIVE", base=0x2000, stride=8, count=len(DOM_EVENTS), access="LO/HI",
         page_stride=0x100, pages=PARAMS["NUM_DOM"], tenant=None,
         desc="Live domain counter at base+0x100*d+8e (privileged; LO write preloads)."),
]

# ---------------------------------------------------------------------------
# Stimulus layout (per-cycle input vector). (name, width, idle_value)
# Packed lane arrays are flattened: lane l occupies bits [l*W +: W].
# ---------------------------------------------------------------------------
WORKLOAD_FIELDS = [
    ("cmp_tensor_ops", P["TL"] * 8, 0), ("cmp_vector_ops", P["VL"] * 8, 0),
    ("cmp_kernel_done", P["KP"], 0), ("cmp_busy", 1, 0), ("cmp_stall", 1, 0),
    ("cmp_dom", P["DOM_W"], 0),
    ("net_pkt_accept", P["PL"], 0), ("net_pkt_fwd", P["PL"], 0), ("net_pkt_drop", P["PL"], 0),
    ("net_tx_bytes", P["PL"] * 8, 0), ("net_lane_dom", P["PL"] * P["DOM_W"], 0),
    ("net_q_occ", 16, 0),
    ("dma_rd_bytes", P["DL"] * 8, 0), ("dma_wr_bytes", P["DL"] * 8, 0),
    ("dma_rd_dom", P["DL"] * P["DOM_W"], 0), ("dma_wr_dom", P["DL"] * P["DOM_W"], 0),
    ("dma_stall", 1, 0),
    ("mem_rd_bytes", 8, 0), ("mem_wr_bytes", 8, 0), ("mig_bytes", 8, 0),
    ("sram_conflict", P["SB"], 0),
    ("sto_cmd", 1, 0), ("sto_rd_done", 1, 0), ("sto_wr_done", 1, 0), ("sto_err", 1, 0),
    ("sto_integ_fail", 1, 0),
    ("sec_auth_fail", 1, 0), ("sec_perm_viol", 1, 0), ("sec_invalid_cmd", 1, 0),
    ("ras_ecc_corr", P["ECC_N"], 0), ("ras_ecc_uncorr", 1, 0), ("ras_dma_fail", 1, 0),
    ("ras_ctrl_reset", 1, 0), ("ras_watchdog", 1, 0), ("ras_fatal", 1, 0),
    ("ras_info", 16, 0), ("thermal_fault_n", 1, 1),
    ("pwr_state", 2, 0), ("core_clk_en", 1, 0), ("temp_valid", 1, 0), ("temp_code", 12, 0),
    ("pwr_meas_valid", 1, 0), ("pwr_meas_code", 16, 0), ("pwr_sensor_present", 1, 0),
    ("mk_valid", P["NUM_STAGES"], 0), ("mk_tag", P["NUM_STAGES"] * P["TAG_W"], 0),
    ("mk_arr_dom", P["DOM_W"], 0),
]

APB_FIELDS = [
    ("psel", 1, 0), ("penable", 1, 0), ("pwrite", 1, 0), ("paddr", 16, 0),
    ("pwdata", 32, 0), ("pprot", 3, 0), ("pauser", P["DOM_W"], 0),
]


def event_index(name):
    for i, e in enumerate(EVENTS):
        if e["name"] == name:
            return i
    raise KeyError(name)


def dom_event_index(name):
    for i, e in enumerate(DOM_EVENTS):
        if e["name"] == name:
            return i
    raise KeyError(name)


def reg_offset(name):
    for r in REGS:
        if r[0] == name:
            return r[1]
    raise KeyError(name)


def _check():
    assert NUM_EV <= 64
    names = [e["name"] for e in EVENTS]
    assert len(set(names)) == len(names)
    for e in EVENTS:
        assert e["max_inc"] < (1 << P["INC_W"]), e["name"]
    offs = [r[1] for r in REGS]
    assert len(set(offs)) == len(offs), "duplicate register offset"
    assert all(o < 0x400 and o % 4 == 0 for o in offs)
    for f, w, _ in WORKLOAD_FIELDS + APB_FIELDS:
        assert w <= 64, f
    for de in DOM_EVENTS:
        event_index(de["global_event"])


_check()

# Implemented (writable/readable) bits of RW registers.  Unimplemented bits
# read as zero.  Shared by RTL review, reference model and docs.
RW_MASKS = {
    "TEL_CLK_HZ": 0xFFFFFFFF,
    "CTRL": 0x00001F1F,
    "EV_EN0": 0xFFFFFFFF, "EV_EN1": EV_EN1_RESET,
    "SAT0": 0xFFFFFFFF, "SAT1": EV_EN1_RESET,
    "DOM_CTRL": 0x000001FF,
    "IRQ_EN": 0x0000001F,
    "TENANT_MASK0": 0xFFFFFFFF, "TENANT_MASK1": EV_EN1_RESET,
    "PRELOAD_HI": 0xFFFFFFFF,
    "TEMP_WARN_THRESH": 0x00000FFF,
    "TRACE_FILTER": 0x00311F1F,
    "TRACE_SAMPLE": 0x0000FFFF,
    "ERRLOG_MASK": 0x000000FF,
}
