"""Host-side unit and integration tests (pytest).

Fast tests use the reference-model backend; tests marked `rtl` need Verilator
(they are skipped automatically when it is not installed).
"""
import json
import os
import re
import shutil
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "host"))

from sftel import export, latency as L, spec as S  # noqa: E402
from sftel.backends.base import Backend  # noqa: E402
from sftel.backends.pcie import PcieBackend, discover  # noqa: E402
from sftel.backends.sim import ModelBackend  # noqa: E402
from sftel.collector import run_experiment  # noqa: E402
from sftel.device import DeviceError, TelemetryDevice  # noqa: E402
from sftel.stim import Program, merge, run_model  # noqa: E402
from sftel.refmodel import TelemetryModel  # noqa: E402

HAVE_VERILATOR = shutil.which("verilator") is not None
rtl = pytest.mark.skipif(not HAVE_VERILATOR, reason="verilator not installed")


# ------------------------------------------------------------------ latency statistics
def test_nearest_rank_quantiles_are_observed_values():
    xs = list(range(1, 101))            # 1..100
    s = L.summarize(xs)
    assert s["p50"] == 50 and s["p95"] == 95 and s["p99"] == 99
    assert s["p999"] == 100 and s["p999_insufficient"] is True   # n=100 < 1000
    assert s["p99_insufficient"] is False
    assert all(s[q] in xs for q in ("p50", "p95", "p99", "p999"))


def test_quantiles_empty_and_single():
    assert L.summarize([])["p50"] is None
    s = L.summarize([7])
    assert s["p50"] == s["p999"] == 7 and s["p95_insufficient"]


def test_histogram_bounds():
    bins = [0] * 16
    bins[3] = 90       # [8,16)
    bins[6] = 10       # [64,128)
    h = L.hist_bounds(dict(bins=bins, samples=100, max=100, sum=0))
    assert h["p50"] == dict(lower=8, upper=16)
    assert h["p99"] == dict(lower=64, upper=128)
    assert h["bins"][15]["upper"] is None


def test_ordering_validation_detects_violations_and_gaps():
    recs = [dict(seq=0, tag=1, deltas={"DISPATCH": 5, "DMA_START": 3, "COMPLETE": 9},
                 duplicate_stage=False, delta_saturated=False),
            dict(seq=2, tag=2, deltas={"DISPATCH": 1, "COMPLETE": 4},
                 duplicate_stage=True, delta_saturated=False)]
    v = L.validate_ordering(recs)
    assert v["order_violations"] == 1 and v["seq_gaps"] == 1 and v["duplicate_stage_flags"] == 1


# ------------------------------------------------------------------ device protocol
class FakeSeqBackend(Backend):
    """Reference model whose SNAP_SEQ is bumped by a 'second agent' once."""
    origin = "simulation"

    def __init__(self):
        self.inner = ModelBackend()
        self.bumped = False
        self.seq_reads = 0

    def read32(self, addr, priv=1, user=0):
        if addr == S.A["SNAP_SEQ"]:
            self.seq_reads += 1
            if self.seq_reads == 2 and not self.bumped:
                self.bumped = True
                self.inner.write32(S.A["CMD"], S.CMD["SNAPSHOT"])   # concurrent snapshot
        return self.inner.read32(addr, priv, user)

    def write32(self, addr, data, priv=1, user=0):
        return self.inner.write32(addr, data, priv, user)

    def step(self, n):
        self.inner.step(n)


def test_snapshot_seqlock_retries_on_concurrent_snapshot():
    b = FakeSeqBackend()
    dev = TelemetryDevice(b)
    dev.identify()
    s = dev.snapshot()
    assert s.retries == 1 and b.bumped


def test_identify_rejects_wrong_id():
    class Bad(ModelBackend):
        def read32(self, addr, priv=1, user=0):
            if addr == S.A["ID"]:
                return 0xDEADBEEF, 0
            return super().read32(addr, priv, user)
    with pytest.raises(DeviceError):
        TelemetryDevice(Bad()).identify()


def test_drain_on_empty_fifo_never_pops():
    b = ModelBackend()
    dev = TelemetryDevice(b)
    w0 = b.n_writes
    assert dev.drain_trace() == [] and dev.drain_errlog() == []
    assert b.n_writes == w0


def test_tenant_isolation_through_model_backend():
    b = ModelBackend()
    # tenant 2 may read its own page, not domain 1's, and may not write
    assert b.read32(S.dsnap_addr(2, 0), priv=0, user=2)[1] == 0
    assert b.read32(S.dsnap_addr(1, 0), priv=0, user=2) == (0, 1)
    assert b.read32(S.live_addr(0), priv=0, user=2) == (0, 1)
    assert b.write32(S.A["CTRL"], 1, priv=0, user=2) == 1
    assert b.read32(S.A["ID"], priv=0, user=2) == (S.SPEC["id_value"], 0)


def test_live_64bit_read_is_coherent_across_carry():
    """Counter just below a 32-bit carry, incremented every cycle: LO-then-HI
    must never produce a torn value."""
    m = TelemetryModel()
    vecs = []
    p = Program()
    p.w(S.A["PRELOAD_HI"], 0x5)
    p.w(S.live_addr(S.EV["NET_TX_BYTES"]), 0xFFFFFF00)
    p.w(S.A["CTRL"], S.ctrl_value(global_en=1))
    for i in range(20):
        p.r(S.live_addr(S.EV["NET_TX_BYTES"]), label=f"lo{i}")
        p.r(S.live_addr(S.EV["NET_TX_BYTES"]) + 4, label=f"hi{i}")
    wl = [dict(net_tx_bytes=S.pack([255] * 4, 8)) for _ in range(200)]
    vecs = merge(wl, p)
    log = run_model(m, vecs)
    acc = {int(ln.split()[1]): int(ln.split()[4], 16) for ln in log if ln.startswith("A ")}
    vals = [(acc[op_hi.access_cycle] << 32) | acc[op_lo.access_cycle]
            for op_lo, op_hi in zip(p.ops[3::2], p.ops[4::2])]
    assert vals == sorted(vals)
    assert any(v >> 32 == 6 for v in vals)            # crossed the carry
    assert all(5 <= v >> 32 <= 6 for v in vals)        # never torn


# ------------------------------------------------------------------ PCIe discovery
def test_pcie_discovery_and_mmio_on_fake_sysfs(tmp_path):
    for bdf, ven, dev in (("0000:01:00.0", "0x8086", "0x1234"), ("0000:02:00.0", "0xffff", "0x0069")):
        d = tmp_path / bdf
        d.mkdir()
        (d / "vendor").write_text(ven + "\n")
        (d / "device").write_text(dev + "\n")
        (d / "resource0").write_bytes(b"\0" * 0x4000)
    found = discover(str(tmp_path))
    assert [f["bdf"] for f in found] == ["0000:02:00.0"] and found[0]["bar_present"]
    with PcieBackend(found[0]["bar"], bdf=found[0]["bdf"]) as b:
        b.write32(0x10, 0x12345678)
        assert b.read32(0x10) == (0x12345678, 0)
        assert b.describe()["origin"] == "hardware"


# ------------------------------------------------------------------ experiments
@pytest.fixture(scope="module")
def model_report(tmp_path_factory):
    return run_experiment("mixed_tenants", backend="model", cycles=6000, deterministic=True,
                          workdir=str(tmp_path_factory.mktemp("wk")))


def test_experiment_matches_ground_truth_on_model(model_report):
    v = model_report["verification"]
    assert v["passed"], v["failures"][:5]
    assert v["n_checks"] > 60


def test_every_metric_carries_its_source(model_report):
    for m in model_report["metrics"]:
        assert m["source"]["origin"] == "simulation"
        assert m["source"]["backend"]
        assert m["kind"] in ("counter", "gauge", "derived", "measured_raw", "estimate")
    assert "NOT production" in model_report["disclaimer"]


def test_exports_keep_provenance(model_report, tmp_path):
    csv_t = export.to_csv(model_report, str(tmp_path / "r.csv"))
    hdr = csv_t.splitlines()[0].split(",")
    assert {"origin", "backend", "registers", "derivation"} <= set(hdr)
    prom = export.to_prometheus(model_report)
    samples = [ln for ln in prom.splitlines() if ln and not ln.startswith("#")]
    assert samples and all('origin="simulation"' in ln for ln in samples)
    assert re.search(r"^# TYPE sftel_dma_rd_bytes_total counter$", prom, re.M)


def test_seconds_are_labelled_nominal(model_report):
    for m in model_report["metrics"]:
        if m["unit"].endswith("/s") or m["name"].endswith("_per_second"):
            assert "TEL_CLK_HZ" in m["source"]["registers"]
            assert "nominal" in (m["note"] or "")


@rtl
def test_rtl_and_model_backends_produce_identical_reports(tmp_path):
    def strip(r):
        r = json.loads(json.dumps(r, default=str))
        r.pop("backend")
        r["experiment"].pop("generated_utc")
        for s in r["snapshots"]:
            s.pop("host_ns_before")
            s.pop("host_ns_after")

        def scrub(o):
            if isinstance(o, dict):
                o.pop("backend", None)
                for v in o.values():
                    scrub(v)
            elif isinstance(o, list):
                for v in o:
                    scrub(v)
        scrub(r)
        return r
    a = run_experiment("ras_fault_injection", backend="verilator", cycles=5000,
                       deterministic=True, workdir=str(tmp_path))
    b = run_experiment("ras_fault_injection", backend="model", cycles=5000,
                       deterministic=True, workdir=str(tmp_path))
    assert a["verification"]["passed"]
    assert strip(a) == strip(b)


# ------------------------------------------------------------------ spec / generated files
def test_generated_package_matches_spec():
    pkg = open(os.path.join(ROOT, "rtl", "sf_tel_pkg.sv")).read()
    assert f"localparam int NUM_EV  = {S.NUM_EV};" in pkg
    for i, e in enumerate(S.EVENTS):
        assert f"localparam int EV_{e['name']} = {i};" in pkg
    for r in S.SPEC["regs"]:
        assert f"A_{r['name']} = 16'h{r['offset']:04X};" in pkg
