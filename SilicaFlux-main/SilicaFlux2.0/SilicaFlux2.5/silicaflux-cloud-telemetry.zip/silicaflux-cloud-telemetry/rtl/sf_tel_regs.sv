// SilicaFlux CloudTelemetry - APB register interface, access policy,
// control/status registers, command pulses, freeze and interrupt logic.
//
// APB timing (zero wait states, PREADY=1):
//   setup edge  (PSEL & !PENABLE): address decoded, access policy applied,
//                read data captured into rdata_q (state as held before this
//                edge), live LO reads latch the high word into HI_LATCH,
//                denied accesses are counted and recorded in VIOL_INFO.
//   access edge (PSEL & PENABLE) : write committed if the setup phase did not
//                flag an error; command pulses act at this edge.
// PSLVERR is driven during the access phase.
module sf_tel_regs
  import sf_tel_pkg::*;
#(
  parameter int CW = 64
) (
  input  logic                          clk,
  input  logic                          rst_n,
  // APB
  input  logic                          psel,
  input  logic                          penable,
  input  logic                          pwrite,
  input  logic [15:0]                   paddr,
  input  logic [31:0]                   pwdata,
  input  logic [2:0]                    pprot,
  input  logic [DOM_W-1:0]              pauser,
  output logic                          pready,
  output logic [31:0]                   prdata,
  output logic                          pslverr,
  output logic                          irq,
  // counter bank read ports
  output logic [6:0]                    g_rd_idx,
  input  logic [CW-1:0]                 g_live,
  input  logic [CW-1:0]                 g_snap,
  output logic [4:0]                    d_rd_idx,
  input  logic [CW-1:0]                 d_live,
  input  logic [CW-1:0]                 d_snap,
  input  logic [NUM_EV-1:0]             ovf_g,
  input  logic [NUM_DCNT-1:0]           ovf_d,
  input  logic                          ovf_event,
  // other read sources
  input  logic [63:0]                   ts,
  input  logic [9:0][31:0]              trace_head,
  input  logic [TRACE_DEPTH_LOG2:0]     trace_count,
  input  logic [31:0]                   trace_proto,
  input  logic                          trace_pushed,
  input  logic [HIST_BINS-1:0][31:0]    hist_bins,
  input  logic [31:0]                   hist_samples,
  input  logic [31:0]                   hist_max,
  input  logic [63:0]                   hist_sum,
  input  logic [31:0]                   el_head0,
  input  logic [63:0]                   el_head_ts,
  input  logic [ERRLOG_DEPTH_LOG2:0]    el_count,
  input  logic [31:0]                   el_first_info,
  input  logic [63:0]                   el_first_ts,
  input  logic                          el_log_req,
  input  logic [31:0]                   temp_last_r,
  input  logic [31:0]                   temp_minmax_r,
  input  logic [31:0]                   pwr_status_r,
  input  logic [15:0]                   pwr_last,
  input  logic [31:0]                   pwr_samples,
  input  logic [63:0]                   pwr_sum,
  input  logic [15:0]                   qocc_max,
  input  logic                          warn_state,
  input  logic                          ev_warn,
  input  logic                          ras_fatal,
  // control outputs
  output logic                          count_active,
  output logic [NUM_EV-1:0]             ev_en,
  output logic [NUM_EV-1:0]             sat_mode,
  output logic [NUM_DEV-1:0]            dom_ev_en,
  output logic                          dom_sat,
  output logic                          trace_en,
  output logic [TAG_W-1:0]              f_match,
  output logic [TAG_W-1:0]              f_mask,
  output logic                          f_dom_en,
  output logic [DOM_W-1:0]              f_dom,
  output logic [15:0]                   sample_n,
  output logic                          sample_rst,
  output logic [11:0]                   warn_thresh,
  output logic [7:0]                    errlog_mask,
  // command pulses
  output logic                          c_snap,
  output logic                          c_reset,
  output logic                          c_trace_flush,
  output logic                          c_hist_clear,
  output logic                          c_errlog_clear,
  output logic                          c_gauge_clear,
  output logic                          c_trace_pop,
  output logic                          c_errlog_pop,
  output logic [NUM_EV-1:0]             ovf_w1c_g,
  output logic [NUM_DCNT-1:0]           ovf_w1c_d,
  output logic                          g_pre_we,
  output logic [CW-1:0]                 pre_val,
  output logic                          d_pre_we,
  output logic                          ev_denied
);
  // ------------------------------------------------------------------ state
  logic [31:0] tel_clk_hz, ctrl, ev_en0, ev_en1, sat0, sat1, dom_ctrl, irq_en,
               tmask0, tmask1, preload_hi, warn_thr_r, trace_filter, trace_sample,
               el_mask_r, viol_info, snap_seq;
  logic [63:0] snap_ts;
  logic [31:0] hi_latch;
  logic [4:0]  irq_status;
  logic        hw_frozen, fatal_pend;
  logic [31:0] rdata_q;
  logic        err_q;

  localparam logic [31:0] EVM1 = EV_EN1_RESET;

  // ------------------------------------------------------------------ control decode
  logic sw_freeze, global_en, tenant_shared, freeze_on_fatal;
  logic [4:0] coarsen;
  assign global_en       = ctrl[CTRL_GLOBAL_EN];
  assign sw_freeze       = ctrl[CTRL_SW_FREEZE];
  assign trace_en        = ctrl[CTRL_TRACE_EN];
  assign tenant_shared   = ctrl[CTRL_TENANT_SHARED_EN];
  assign freeze_on_fatal = ctrl[CTRL_FREEZE_ON_FATAL];
  assign coarsen         = ctrl[CTRL_TENANT_COARSEN +: 5];
  assign count_active    = global_en && !sw_freeze && !hw_frozen;
  assign ev_en           = {ev_en1[NUM_EV-33:0], ev_en0};
  assign sat_mode        = {sat1[NUM_EV-33:0], sat0};
  assign dom_ev_en       = dom_ctrl[7:0];
  assign dom_sat         = dom_ctrl[8];
  assign f_match         = trace_filter[4:0];
  assign f_mask          = trace_filter[12:8];
  assign f_dom_en        = trace_filter[16];
  assign f_dom           = trace_filter[21:20];
  assign sample_n        = trace_sample[15:0];
  assign warn_thresh     = warn_thr_r[11:0];
  assign errlog_mask     = el_mask_r[7:0];

  logic [NUM_EV-1:0] tmask;
  assign tmask = {tmask1[NUM_EV-33:0], tmask0};

  // ------------------------------------------------------------------ address decode
  logic aligned, in_csr, in_live, in_snap, in_dsnap, in_dlive;
  logic [6:0] gidx;
  logic [3:0] dsel;
  logic [4:0] eidx;
  logic       hiw;
  assign aligned  = (paddr[1:0] == 2'b00);
  assign in_csr   = (paddr[15:10] == 6'b000000);
  assign in_live  = (paddr[15:10] == 6'b000001);
  assign in_snap  = (paddr[15:10] == 6'b000010);
  assign in_dsnap = (paddr[15:12] == 4'h1);
  assign in_dlive = (paddr[15:12] == 4'h2);
  assign gidx     = paddr[9:3];
  assign dsel     = paddr[11:8];
  assign eidx     = paddr[7:3];
  assign hiw      = paddr[2];
  logic g_ok, d_ok;
  assign g_ok = (int'(gidx) < NUM_EV);
  assign d_ok = (int'(dsel) < NUM_DOM) && (int'(eidx) < NUM_DEV);
  assign g_rd_idx = gidx;
  assign d_rd_idx = 5'(int'(dsel) * NUM_DEV + int'(eidx));

  // CSR decode
  logic        c_hit, c_wr_ok, c_tenant, c_is_lo, c_is_hi;
  logic [31:0] c_val;
  logic [63:0] c_lo64;
  always_comb begin
    c_hit = 1'b1; c_wr_ok = 1'b0; c_tenant = 1'b0; c_is_lo = 1'b0; c_is_hi = 1'b0;
    c_val = '0; c_lo64 = '0;
    case (paddr[9:0])
      A_ID[9:0]:            begin c_val = ID_VALUE; c_tenant = 1'b1; end
      A_VERSION[9:0]:       begin c_val = VERSION_VALUE; c_tenant = 1'b1; end
      A_CAPS0[9:0]:         begin c_val = {5'd0, 7'(CW), 4'(NUM_DOM), 8'(NUM_DEV), 8'(NUM_EV)}; c_tenant = 1'b1; end
      A_CAPS1[9:0]:         begin c_val = {15'd0, 5'(HIST_BINS), 4'(ERRLOG_DEPTH_LOG2), 4'(TRACE_DEPTH_LOG2), 4'(TAG_W)}; c_tenant = 1'b1; end
      A_TEL_CLK_HZ[9:0]:    begin c_val = tel_clk_hz; c_wr_ok = 1'b1; c_tenant = 1'b1; end
      A_CTRL[9:0]:          begin c_val = ctrl; c_wr_ok = 1'b1; end
      A_CMD[9:0]:           begin c_val = '0; c_wr_ok = 1'b1; end
      A_STATUS[9:0]:        c_val = {11'd0, 5'(el_count), 3'd0, 5'(trace_count), 4'd0,
                                     warn_state, hw_frozen, sw_freeze, count_active};
      A_SNAP_SEQ[9:0]:      begin c_val = snap_seq; c_tenant = 1'b1; end
      A_SNAP_TS_LO[9:0]:    begin c_val = snap_ts[31:0]; c_tenant = 1'b1; end
      A_SNAP_TS_HI[9:0]:    begin c_val = snap_ts[63:32]; c_tenant = 1'b1; end
      A_TS_LO[9:0]:         begin c_is_lo = 1'b1; c_lo64 = ts; end
      A_TS_HI[9:0]:         c_is_hi = 1'b1;
      A_EV_EN0[9:0]:        begin c_val = ev_en0; c_wr_ok = 1'b1; end
      A_EV_EN1[9:0]:        begin c_val = ev_en1; c_wr_ok = 1'b1; end
      A_SAT0[9:0]:          begin c_val = sat0; c_wr_ok = 1'b1; end
      A_SAT1[9:0]:          begin c_val = sat1; c_wr_ok = 1'b1; end
      A_OVF0[9:0]:          begin c_val = ovf_g[31:0]; c_wr_ok = 1'b1; end
      A_OVF1[9:0]:          begin c_val = 32'(ovf_g[NUM_EV-1:32]); c_wr_ok = 1'b1; end
      A_DOM_CTRL[9:0]:      begin c_val = dom_ctrl; c_wr_ok = 1'b1; end
      A_DOM_OVF[9:0]:       begin c_val = 32'(ovf_d); c_wr_ok = 1'b1; end
      A_IRQ_STATUS[9:0]:    begin c_val = {27'd0, irq_status}; c_wr_ok = 1'b1; end
      A_IRQ_EN[9:0]:        begin c_val = irq_en; c_wr_ok = 1'b1; end
      A_VIOL_INFO[9:0]:     c_val = viol_info;
      A_TENANT_MASK0[9:0]:  begin c_val = tmask0; c_wr_ok = 1'b1; end
      A_TENANT_MASK1[9:0]:  begin c_val = tmask1; c_wr_ok = 1'b1; end
      A_PRELOAD_HI[9:0]:    begin c_val = preload_hi; c_wr_ok = 1'b1; end
      A_TEMP_LAST[9:0]:     c_val = temp_last_r;
      A_TEMP_MINMAX[9:0]:   c_val = temp_minmax_r;
      A_TEMP_WARN_THRESH[9:0]: begin c_val = warn_thr_r; c_wr_ok = 1'b1; end
      A_PWR_STATUS[9:0]:    c_val = pwr_status_r;
      A_PWR_MEAS_LAST[9:0]: c_val = {16'd0, pwr_last};
      A_PWR_MEAS_SAMPLES[9:0]: c_val = pwr_samples;
      A_PWR_MEAS_SUM_LO[9:0]:  begin c_is_lo = 1'b1; c_lo64 = pwr_sum; end
      A_PWR_MEAS_SUM_HI[9:0]:  c_is_hi = 1'b1;
      A_QOCC_MAX[9:0]:      c_val = {16'd0, qocc_max};
      A_TRACE_FILTER[9:0]:  begin c_val = trace_filter; c_wr_ok = 1'b1; end
      A_TRACE_SAMPLE[9:0]:  begin c_val = trace_sample; c_wr_ok = 1'b1; end
      A_TRACE_POP[9:0]:     begin c_val = '0; c_wr_ok = 1'b1; end
      A_TRACE_PROTO[9:0]:   c_val = trace_proto;
      A_TRACE_HEAD0[9:0]:   c_val = trace_head[0];
      A_TRACE_HEAD1[9:0]:   c_val = trace_head[1];
      A_TRACE_HEAD2[9:0]:   c_val = trace_head[2];
      A_TRACE_HEAD3[9:0]:   c_val = trace_head[3];
      A_TRACE_HEAD4[9:0]:   c_val = trace_head[4];
      A_TRACE_HEAD5[9:0]:   c_val = trace_head[5];
      A_TRACE_HEAD6[9:0]:   c_val = trace_head[6];
      A_TRACE_HEAD7[9:0]:   c_val = trace_head[7];
      A_TRACE_HEAD8[9:0]:   c_val = trace_head[8];
      A_TRACE_HEAD9[9:0]:   c_val = trace_head[9];
      A_HIST_SAMPLES[9:0]:  c_val = hist_samples;
      A_HIST_MAX[9:0]:      c_val = hist_max;
      A_HIST_SUM_LO[9:0]:   begin c_is_lo = 1'b1; c_lo64 = hist_sum; end
      A_HIST_SUM_HI[9:0]:   c_is_hi = 1'b1;
      A_ERRLOG_MASK[9:0]:   begin c_val = el_mask_r; c_wr_ok = 1'b1; end
      A_ERRLOG_POP[9:0]:    begin c_val = '0; c_wr_ok = 1'b1; end
      A_ERRLOG_HEAD0[9:0]:  c_val = el_head0;
      A_ERRLOG_HEAD_TS_LO[9:0]: c_val = el_head_ts[31:0];
      A_ERRLOG_HEAD_TS_HI[9:0]: c_val = el_head_ts[63:32];
      A_FIRST_ERR_INFO[9:0]:    c_val = el_first_info;
      A_FIRST_ERR_TS_LO[9:0]:   c_val = el_first_ts[31:0];
      A_FIRST_ERR_TS_HI[9:0]:   c_val = el_first_ts[63:32];
      default: begin
        if (paddr[9:6] == 4'b0100)   // 0x100..0x13C histogram bins
          c_val = hist_bins[paddr[5:2]];
        else
          c_hit = 1'b0;
      end
    endcase
    if (!in_csr) c_hit = 1'b0;
  end

  // ------------------------------------------------------------------ access policy
  logic priv, setup, access, wr_commit;
  logic permitted, err_d, denied;
  logic live_g, snap_g, snap_d, live_d;
  assign priv   = pprot[0];   // PPROT[0]: privileged. PPROT[2:1] are not used.
  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_pprot;
  assign unused_pprot = ^pprot[2:1];
  /* verilator lint_on UNUSEDSIGNAL */
  assign setup  = psel && !penable;
  assign access = psel && penable;
  assign live_g = aligned && in_live  && g_ok;
  assign snap_g = aligned && in_snap  && g_ok;
  assign snap_d = aligned && in_dsnap && d_ok;
  assign live_d = aligned && in_dlive && d_ok;

  always_comb begin
    if (priv) begin
      if (!pwrite) permitted = aligned && (c_hit || live_g || snap_g || snap_d || live_d);
      else         permitted = aligned && ((c_hit && c_wr_ok) || (live_g && !hiw) || (live_d && !hiw));
      denied = 1'b0;
    end else begin
`ifdef SF_TEL_MUT_TENANT_LEAK
      permitted = !pwrite && aligned && ((c_hit && c_tenant) ||
                  (snap_g && tenant_shared && tmask[gidx[5:0]]) || snap_d);   // MUTATION: no domain check
`else
      permitted = !pwrite && aligned && ((c_hit && c_tenant) ||
                  (snap_g && tenant_shared && tmask[gidx[5:0]]) ||
                  (snap_d && (dsel == 4'(pauser))));
`endif
      denied = !permitted;
    end
    err_d = !permitted;
  end
  assign ev_denied = setup && denied;

  // read value
  logic [63:0] gl64, gs64, dl64, ds64, cmask;
  assign gl64  = 64'(g_live);
  assign gs64  = 64'(g_snap);
  assign dl64  = 64'(d_live);
  assign ds64  = 64'(d_snap);
  assign cmask = ~((64'd1 << coarsen) - 64'd1);

  logic [31:0] rd_val;
  logic        latch_we;
  logic [31:0] latch_val;
  always_comb begin
    logic [63:0] v;
    rd_val = '0; latch_we = 1'b0; latch_val = '0; v = '0;
    if (!err_d && !pwrite) begin
      if (c_hit) begin
        if (c_is_lo)      begin rd_val = c_lo64[31:0]; latch_we = 1'b1; latch_val = c_lo64[63:32]; end
        else if (c_is_hi) rd_val = hi_latch;
        else              rd_val = c_val;
      end else if (live_g || live_d) begin
        v = live_g ? gl64 : dl64;
        if (hiw) rd_val = hi_latch;
        else begin rd_val = v[31:0]; latch_we = 1'b1; latch_val = v[63:32]; end
      end else if (snap_g || snap_d) begin
        v = snap_g ? gs64 : ds64;
        if (!priv && snap_g) v = v & cmask;
        rd_val = hiw ? v[63:32] : v[31:0];
      end
    end
  end

  // ------------------------------------------------------------------ write strobes
  assign wr_commit = access && pwrite && !err_q;
  // NOTE: all inputs are explicit arguments so that continuous assignments
  // using this function are sensitive to them on every simulator.
  function automatic logic wmatch(input logic en, input logic [15:0] a, input logic [15:0] b);
    return en && (a == b);
  endfunction

  assign c_snap         = wmatch(wr_commit, paddr, A_CMD) && pwdata[CMD_SNAPSHOT];
  assign c_reset        = wmatch(wr_commit, paddr, A_CMD) && pwdata[CMD_RESET_COUNTERS];
  assign c_trace_flush  = wmatch(wr_commit, paddr, A_CMD) && pwdata[CMD_TRACE_FLUSH];
  assign c_hist_clear   = wmatch(wr_commit, paddr, A_CMD) && pwdata[CMD_HIST_CLEAR];
  assign c_errlog_clear = wmatch(wr_commit, paddr, A_CMD) && pwdata[CMD_ERRLOG_CLEAR];
  assign c_gauge_clear  = wmatch(wr_commit, paddr, A_CMD) && pwdata[CMD_GAUGE_CLEAR];
  logic  c_unfreeze;
  assign c_unfreeze     = wmatch(wr_commit, paddr, A_CMD) && pwdata[CMD_UNFREEZE];
  assign c_trace_pop    = wmatch(wr_commit, paddr, A_TRACE_POP);
  assign c_errlog_pop   = wmatch(wr_commit, paddr, A_ERRLOG_POP);
  assign sample_rst     = wmatch(wr_commit, paddr, A_TRACE_SAMPLE);
  assign ovf_w1c_g      = { (wmatch(wr_commit, paddr, A_OVF1) ? pwdata[NUM_EV-33:0] : {(NUM_EV-32){1'b0}}),
                            (wmatch(wr_commit, paddr, A_OVF0) ? pwdata : 32'd0) };
  assign ovf_w1c_d      = wmatch(wr_commit, paddr, A_DOM_OVF) ? pwdata[NUM_DCNT-1:0] : {NUM_DCNT{1'b0}};
  assign g_pre_we       = wr_commit && in_live  && g_ok && !hiw;
  assign d_pre_we       = wr_commit && in_dlive && d_ok && !hiw;
  assign pre_val        = CW'({preload_hi, pwdata});

  // ------------------------------------------------------------------ sequential
  logic [4:0] irq_set;
  always_comb begin
    irq_set = '0;
    irq_set[IRQ_OVF]        = ovf_event;
    irq_set[IRQ_RAS]        = el_log_req;
    irq_set[IRQ_TRACE]      = trace_pushed;
    irq_set[IRQ_THERM_WARN] = ev_warn;
    irq_set[IRQ_HW_FREEZE]  = fatal_pend && !hw_frozen;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tel_clk_hz <= '0; ctrl <= '0; ev_en0 <= 32'hFFFF_FFFF; ev_en1 <= EVM1;
      sat0 <= '0; sat1 <= '0; dom_ctrl <= 32'h0000_00FF; irq_en <= '0;
      tmask0 <= '0; tmask1 <= '0; preload_hi <= '0; warn_thr_r <= 32'h0000_0FFF;
      trace_filter <= '0; trace_sample <= '0; el_mask_r <= 32'h0000_007F;
      viol_info <= '0; snap_seq <= '0; snap_ts <= '0; hi_latch <= '0;
      irq_status <= '0; hw_frozen <= 1'b0; fatal_pend <= 1'b0;
      rdata_q <= '0; err_q <= 1'b0;
    end else begin
      // setup phase
      if (setup) begin
        rdata_q <= rd_val;
        err_q   <= err_d;
        if (latch_we && priv) hi_latch <= latch_val;
        if (denied) viol_info <= {1'b1, pwrite, 4'd0, 2'(pauser), 8'd0, paddr};
      end
      // access phase writes
      if (wmatch(wr_commit, paddr, A_TEL_CLK_HZ))       tel_clk_hz   <= pwdata;
      if (wmatch(wr_commit, paddr, A_CTRL))             ctrl         <= pwdata & 32'h0000_1F1F;
      if (wmatch(wr_commit, paddr, A_EV_EN0))           ev_en0       <= pwdata;
      if (wmatch(wr_commit, paddr, A_EV_EN1))           ev_en1       <= pwdata & EVM1;
      if (wmatch(wr_commit, paddr, A_SAT0))             sat0         <= pwdata;
      if (wmatch(wr_commit, paddr, A_SAT1))             sat1         <= pwdata & EVM1;
      if (wmatch(wr_commit, paddr, A_DOM_CTRL))         dom_ctrl     <= pwdata & 32'h0000_01FF;
      if (wmatch(wr_commit, paddr, A_IRQ_EN))           irq_en       <= pwdata & 32'h0000_001F;
      if (wmatch(wr_commit, paddr, A_TENANT_MASK0))     tmask0       <= pwdata;
      if (wmatch(wr_commit, paddr, A_TENANT_MASK1))     tmask1       <= pwdata & EVM1;
      if (wmatch(wr_commit, paddr, A_PRELOAD_HI))       preload_hi   <= pwdata;
      if (wmatch(wr_commit, paddr, A_TEMP_WARN_THRESH)) warn_thr_r   <= pwdata & 32'h0000_0FFF;
      if (wmatch(wr_commit, paddr, A_TRACE_FILTER))     trace_filter <= pwdata & 32'h0031_1F1F;
      if (wmatch(wr_commit, paddr, A_TRACE_SAMPLE))     trace_sample <= pwdata & 32'h0000_FFFF;
      if (wmatch(wr_commit, paddr, A_ERRLOG_MASK))      el_mask_r    <= pwdata & 32'h0000_00FF;
      if (c_reset && !(setup && denied)) viol_info <= '0;
      if (c_snap) begin
        snap_seq <= snap_seq + 32'd1;
        snap_ts  <= ts;
      end
      // freeze: a fatal sampled at edge j freezes counting from edge j+2, so
      // the fatal cycle's own increments (applied at j+1) are captured.
      fatal_pend <= ras_fatal && freeze_on_fatal;
      if (fatal_pend)      hw_frozen <= 1'b1;
      else if (c_unfreeze) hw_frozen <= 1'b0;
      // interrupts: set beats write-1-to-clear
      irq_status <= (irq_status & ~(wmatch(wr_commit, paddr, A_IRQ_STATUS) ? pwdata[4:0] : 5'd0)) | irq_set;
    end
  end

  assign pready  = 1'b1;
  assign prdata  = rdata_q;
  assign pslverr = access && err_q;
  assign irq     = |(irq_status & irq_en[4:0]);
endmodule
