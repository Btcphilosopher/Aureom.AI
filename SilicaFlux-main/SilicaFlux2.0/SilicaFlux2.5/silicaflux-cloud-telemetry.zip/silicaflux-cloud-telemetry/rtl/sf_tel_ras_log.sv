// SilicaFlux CloudTelemetry - reliability (RAS) error log.
//
// One record per cycle in which any enabled error source fires.  A record
// carries the bitmap of ALL sources that fired in that cycle (so simultaneous
// errors are never silently merged), the 16-bit ras_info syndrome and the
// telemetry timestamp.  First-error capture is independent of log space.
// clear (ERRLOG_CLEAR) empties the log and first-error; an error arriving at
// the same edge is dropped (counted in ERRLOG_DROPS) and not captured.
module sf_tel_ras_log
  import sf_tel_pkg::*;
(
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic [ECC_N-1:0]                  ecc_corr,
  input  logic                              ecc_uncorr,
  input  logic                              dma_fail,
  input  logic                              ctrl_reset,
  input  logic                              therm_fault,
  input  logic                              watchdog,
  input  logic                              fatal,
  input  logic                              sto_integ_fail,
  input  logic [15:0]                       info,
  input  logic [7:0]                        mask,
  input  logic [63:0]                       ts,
  input  logic                              pop,
  input  logic                              clear,
  output logic                              log_req,
  output logic                              ev_drop,
  output logic [31:0]                       head0,
  output logic [63:0]                       head_ts,
  output logic [ERRLOG_DEPTH_LOG2:0]        count,
  output logic [31:0]                       first_info,
  output logic [63:0]                       first_ts
);
  logic [7:0]  srcs;
  logic        push_ok;
  logic [87:0] head_rec;
  logic        first_v;
  logic [23:0] first_q;
  logic [63:0] first_ts_q;

  always_comb begin
    srcs = '0;
    srcs[ES_ECC_UNCORR]         = ecc_uncorr;
    srcs[ES_DMA_FAIL]           = dma_fail;
    srcs[ES_CTRL_RESET]         = ctrl_reset;
    srcs[ES_THERMAL_FAULT]      = therm_fault;
    srcs[ES_WATCHDOG]           = watchdog;
    srcs[ES_FATAL]              = fatal;
    srcs[ES_STO_INTEGRITY_FAIL] = sto_integ_fail;
    srcs[ES_ECC_CORR]           = |ecc_corr;
    srcs = srcs & mask;
  end

  assign log_req = |srcs;
  assign ev_drop = log_req && !push_ok;

  sf_tel_fifo #(.W(88), .DL2(ERRLOG_DEPTH_LOG2)) u_fifo (
    .clk, .rst_n, .push(log_req), .din({ts, srcs, info}), .pop, .flush(clear),
    .head(head_rec), .count, .push_ok
  );

  assign head0   = (count != '0) ? {1'b1, 7'd0, head_rec[23:16], head_rec[15:0]} : '0;
  assign head_ts = head_rec[87:24];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      first_v <= 1'b0; first_q <= '0; first_ts_q <= '0;
    end else if (clear) begin
      first_v <= 1'b0; first_q <= '0; first_ts_q <= '0;
    end else if (log_req && !first_v) begin
      first_v <= 1'b1; first_q <= {srcs, info}; first_ts_q <= ts;
    end
  end
  assign first_info = first_v ? {1'b1, 7'd0, first_q} : '0;
  assign first_ts   = first_ts_q;
endmodule
