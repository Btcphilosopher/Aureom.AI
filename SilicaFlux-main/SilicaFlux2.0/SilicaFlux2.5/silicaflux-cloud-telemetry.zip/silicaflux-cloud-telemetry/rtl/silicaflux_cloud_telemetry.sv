// =============================================================================
// SilicaFlux Project 69 - CloudTelemetry
// Aureom.AI | SilicaFlux-CLOUD
//
// Unified hardware performance, power, thermal and reliability monitoring
// engine for the SilicaFlux CloudDPU.
//
//   Hardware events -> Event collection -> Counter banks -> Snapshot logic
//   -> APB/MMIO telemetry interface -> Host metrics collector
//
// Single clock domain (clk).  The only asynchronous input is the active-low
// thermal fault pin, which passes through a 2-flop synchronizer.  Every
// timestamp produced by this block is a count of clk cycles since reset
// (the "telemetry timebase"); it is never host wall-clock time.
//
// Source blocks (CloudDMA, PacketCore, TensorCore, storage, security, RAS,
// PowerClock, sensors) are NOT present in this repository; their event
// contracts are the input ports below (see docs/AUDIT.md, EVENT_CATALOGUE.md).
// =============================================================================
module silicaflux_cloud_telemetry
  import sf_tel_pkg::*;
#(
  parameter int CNT_WIDTH = CNT_W
) (
  input  logic                              clk,
  input  logic                              rst_n,
  // ---------------- APB (APB4-style + PAUSER-style domain sideband) -------
  input  logic                              psel,
  input  logic                              penable,
  input  logic                              pwrite,
  input  logic [15:0]                       paddr,
  input  logic [31:0]                       pwdata,
  input  logic [2:0]                        pprot,
  input  logic [DOM_W-1:0]                  pauser,
  output logic                              pready,
  output logic [31:0]                       prdata,
  output logic                              pslverr,
  output logic                              irq,
  // ---------------- compute -------------------------------------------
  input  logic [TL-1:0][7:0]                cmp_tensor_ops,
  input  logic [VL-1:0][7:0]                cmp_vector_ops,
  input  logic [KP-1:0]                     cmp_kernel_done,
  input  logic                              cmp_busy,
  input  logic                              cmp_stall,
  input  logic [DOM_W-1:0]                  cmp_dom,
  // ---------------- network -------------------------------------------
  input  logic [PL-1:0]                     net_pkt_accept,
  input  logic [PL-1:0]                     net_pkt_fwd,
  input  logic [PL-1:0]                     net_pkt_drop,
  input  logic [PL-1:0][7:0]                net_tx_bytes,
  input  logic [PL-1:0][DOM_W-1:0]          net_lane_dom,
  input  logic [15:0]                       net_q_occ,
  // ---------------- DMA -----------------------------------------------
  input  logic [DL-1:0][7:0]                dma_rd_bytes,
  input  logic [DL-1:0][7:0]                dma_wr_bytes,
  input  logic [DL-1:0][DOM_W-1:0]          dma_rd_dom,
  input  logic [DL-1:0][DOM_W-1:0]          dma_wr_dom,
  input  logic                              dma_stall,
  // ---------------- memory --------------------------------------------
  input  logic [7:0]                        mem_rd_bytes,
  input  logic [7:0]                        mem_wr_bytes,
  input  logic [7:0]                        mig_bytes,
  input  logic [SB-1:0]                     sram_conflict,
  // ---------------- storage -------------------------------------------
  input  logic                              sto_cmd,
  input  logic                              sto_rd_done,
  input  logic                              sto_wr_done,
  input  logic                              sto_err,
  input  logic                              sto_integ_fail,
  // ---------------- security ------------------------------------------
  input  logic                              sec_auth_fail,
  input  logic                              sec_perm_viol,
  input  logic                              sec_invalid_cmd,
  // ---------------- RAS -----------------------------------------------
  input  logic [ECC_N-1:0]                  ras_ecc_corr,
  input  logic                              ras_ecc_uncorr,
  input  logic                              ras_dma_fail,
  input  logic                              ras_ctrl_reset,
  input  logic                              ras_watchdog,
  input  logic                              ras_fatal,
  input  logic [15:0]                       ras_info,
  input  logic                              thermal_fault_n,     // ASYNC, active low
  // ---------------- power / thermal -----------------------------------
  input  logic [1:0]                        pwr_state,
  input  logic                              core_clk_en,
  input  logic                              temp_valid,
  input  logic [11:0]                       temp_code,
  input  logic                              pwr_meas_valid,
  input  logic [15:0]                       pwr_meas_code,
  input  logic                              pwr_sensor_present,
  // ---------------- transaction stage marks ---------------------------
  input  logic [NUM_STAGES-1:0]             mk_valid,
  input  logic [NUM_STAGES-1:0][TAG_W-1:0]  mk_tag,
  input  logic [DOM_W-1:0]                  mk_arr_dom
);
  localparam int CW = CNT_WIDTH;

  // ---------------------------------------------------------------- timebase
  logic [63:0] ts;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) ts <= '0; else ts <= ts + 64'd1;

  // ---------------------------------------------------------------- CDC: thermal fault pin
  logic tf_sync, tf_prev, ev_therm_fault;
  sf_tel_sync2 #(.RESET_VAL(1'b1)) u_tf_sync (
    .clk, .rst_n, .d_async(thermal_fault_n), .q(tf_sync));
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) tf_prev <= 1'b1; else tf_prev <= tf_sync;
  assign ev_therm_fault = tf_prev && !tf_sync;      // synchronized falling edge

  // ---------------------------------------------------------------- wires
  logic                        count_active, dom_sat, trace_en, f_dom_en, sample_rst;
  logic [NUM_EV-1:0]           ev_en, sat_mode, ovf_g, ovf_w1c_g;
  logic [NUM_DEV-1:0]          dom_ev_en;
  logic [NUM_DCNT-1:0]         ovf_d, ovf_w1c_d;
  logic [TAG_W-1:0]            f_match, f_mask;
  logic [DOM_W-1:0]            f_dom;
  logic [15:0]                 sample_n;
  logic [11:0]                 warn_thresh;
  logic [7:0]                  errlog_mask;
  logic c_snap, c_reset, c_trace_flush, c_hist_clear, c_errlog_clear, c_gauge_clear,
        c_trace_pop, c_errlog_pop, g_pre_we, d_pre_we, ev_denied;
  logic [CW-1:0]               pre_val, g_live, g_snap, d_live, d_snap;
  logic [6:0]                  g_rd_idx;
  logic [4:0]                  d_rd_idx;
  logic                        ovf_ev_g, ovf_ev_d;

  // trace
  logic                        ev_rec, ev_drop, dc_valid, hist_valid;
  logic [DOM_W-1:0]            dc_dom;
  logic [31:0]                 hist_lat, trace_proto;
  logic [9:0][31:0]            trace_head;
  logic [TRACE_DEPTH_LOG2:0]   trace_count;
  // histogram
  logic [HIST_BINS-1:0][31:0]  hist_bins;
  logic [31:0]                 hist_samples, hist_max;
  logic [63:0]                 hist_sum;
  // ras
  logic                        el_log_req, el_drop;
  logic [31:0]                 el_head0, el_first_info;
  logic [63:0]                 el_head_ts, el_first_ts;
  logic [ERRLOG_DEPTH_LOG2:0]  el_count;
  // gauges
  logic                        ev_warn, ev_pstate_trans, warn_state;
  logic [31:0]                 temp_last_r, temp_minmax_r, pwr_status_r, pwr_samples;
  logic [15:0]                 pwr_last, qocc_max;
  logic [63:0]                 pwr_sum;
  // increments
  logic [NUM_EV-1:0][INC_W-1:0]   inc_q;
  logic [NUM_DCNT-1:0][INC_W-1:0] dinc_q;

  // ---------------------------------------------------------------- event collection
  sf_tel_event_collect u_collect (
    .clk, .rst_n,
    .cmp_tensor_ops, .cmp_vector_ops, .cmp_kernel_done, .cmp_busy, .cmp_stall, .cmp_dom,
    .net_pkt_accept, .net_pkt_fwd, .net_pkt_drop, .net_tx_bytes, .net_lane_dom, .net_q_occ,
    .dma_rd_bytes, .dma_wr_bytes, .dma_rd_dom, .dma_wr_dom, .dma_stall,
    .mem_rd_bytes, .mem_wr_bytes, .mig_bytes, .sram_conflict,
    .sto_cmd, .sto_rd_done, .sto_wr_done, .sto_err, .sto_integ_fail,
    .sec_auth_fail, .sec_perm_viol, .sec_invalid_cmd,
    .ras_ecc_corr, .ras_ecc_uncorr, .ras_dma_fail, .ras_ctrl_reset, .ras_watchdog, .ras_fatal,
    .pwr_state, .core_clk_en, .temp_valid,
    .mk_valid, .mk_arr_dom,
    .ev_pstate_trans, .ev_therm_warn(ev_warn), .ev_therm_fault, .ev_denied,
    .ev_trace_rec(ev_rec), .ev_trace_drop(ev_drop), .ev_errlog_drop(el_drop),
    .dc_valid, .dc_dom,
    .inc_q, .dinc_q
  );

  // ---------------------------------------------------------------- counter banks
  sf_tel_counter_bank #(.N(NUM_EV), .CW(CW), .IW(INC_W), .XW(7)) u_gbank (
    .clk, .rst_n, .inc(inc_q), .count_active, .ev_en, .sat_mode,
    .clear(c_reset), .snap(c_snap), .ovf_w1c(ovf_w1c_g),
    .preload_we(g_pre_we), .preload_idx(g_rd_idx), .preload_val(pre_val),
    .rd_idx(g_rd_idx), .rd_live(g_live), .rd_snap(g_snap),
    .ovf(ovf_g), .ovf_event(ovf_ev_g)
  );

  logic [NUM_DCNT-1:0] d_en;
  always_comb for (int i = 0; i < NUM_DCNT; i++) d_en[i] = dom_ev_en[i % NUM_DEV];

  sf_tel_counter_bank #(.N(NUM_DCNT), .CW(CW), .IW(INC_W), .XW(5)) u_dbank (
    .clk, .rst_n, .inc(dinc_q), .count_active, .ev_en(d_en), .sat_mode({NUM_DCNT{dom_sat}}),
    .clear(c_reset), .snap(c_snap), .ovf_w1c(ovf_w1c_d),
    .preload_we(d_pre_we), .preload_idx(d_rd_idx), .preload_val(pre_val),
    .rd_idx(d_rd_idx), .rd_live(d_live), .rd_snap(d_snap),
    .ovf(ovf_d), .ovf_event(ovf_ev_d)
  );

  // ---------------------------------------------------------------- latency tracing
  sf_tel_trace u_trace (
    .clk, .rst_n, .mk_valid, .mk_tag, .mk_arr_dom, .ts,
    .trace_en, .f_match, .f_mask, .f_dom_en, .f_dom, .sample_n, .sample_rst,
    .pop(c_trace_pop), .flush(c_trace_flush), .reset_counters(c_reset),
    .ev_rec, .ev_drop, .dc_valid, .dc_dom, .hist_valid, .hist_lat,
    .head(trace_head), .count(trace_count), .proto(trace_proto)
  );

  sf_tel_hist u_hist (
    .clk, .rst_n, .in_valid(hist_valid), .in_lat(hist_lat), .count_active,
    .clear(c_hist_clear || c_reset),
    .hbins(hist_bins), .samples(hist_samples), .lat_max(hist_max), .lat_sum(hist_sum)
  );

  // ---------------------------------------------------------------- reliability
  sf_tel_ras_log u_ras (
    .clk, .rst_n, .ecc_corr(ras_ecc_corr), .ecc_uncorr(ras_ecc_uncorr),
    .dma_fail(ras_dma_fail), .ctrl_reset(ras_ctrl_reset), .therm_fault(ev_therm_fault),
    .watchdog(ras_watchdog), .fatal(ras_fatal), .sto_integ_fail, .info(ras_info),
    .mask(errlog_mask), .ts, .pop(c_errlog_pop), .clear(c_errlog_clear),
    .log_req(el_log_req), .ev_drop(el_drop), .head0(el_head0), .head_ts(el_head_ts),
    .count(el_count), .first_info(el_first_info), .first_ts(el_first_ts)
  );

  // ---------------------------------------------------------------- gauges
  sf_tel_gauges u_gauges (
    .clk, .rst_n, .temp_valid, .temp_code, .warn_thresh, .pwr_meas_valid, .pwr_meas_code,
    .pwr_sensor_present, .net_q_occ, .pwr_state, .clear(c_gauge_clear),
    .ev_warn, .ev_pstate_trans, .warn_state, .temp_last_r, .temp_minmax_r, .pwr_status_r,
    .pwr_last, .pwr_samples, .pwr_sum, .qocc_max
  );

  // ---------------------------------------------------------------- registers
  sf_tel_regs #(.CW(CW)) u_regs (
    .clk, .rst_n, .psel, .penable, .pwrite, .paddr, .pwdata, .pprot, .pauser,
    .pready, .prdata, .pslverr, .irq,
    .g_rd_idx, .g_live, .g_snap, .d_rd_idx, .d_live, .d_snap,
    .ovf_g, .ovf_d, .ovf_event(ovf_ev_g || ovf_ev_d),
    .ts, .trace_head, .trace_count, .trace_proto, .trace_pushed(ev_rec),
    .hist_bins, .hist_samples, .hist_max, .hist_sum,
    .el_head0, .el_head_ts, .el_count, .el_first_info, .el_first_ts, .el_log_req,
    .temp_last_r, .temp_minmax_r, .pwr_status_r, .pwr_last, .pwr_samples, .pwr_sum,
    .qocc_max, .warn_state, .ev_warn, .ras_fatal,
    .count_active, .ev_en, .sat_mode, .dom_ev_en, .dom_sat,
    .trace_en, .f_match, .f_mask, .f_dom_en, .f_dom, .sample_n, .sample_rst,
    .warn_thresh, .errlog_mask,
    .c_snap, .c_reset, .c_trace_flush, .c_hist_clear, .c_errlog_clear, .c_gauge_clear,
    .c_trace_pop, .c_errlog_pop, .ovf_w1c_g, .ovf_w1c_d,
    .g_pre_we, .pre_val, .d_pre_we, .ev_denied
  );

  // Unused-by-design inputs (documented): pwr_meas_* only feed gauges.
endmodule
