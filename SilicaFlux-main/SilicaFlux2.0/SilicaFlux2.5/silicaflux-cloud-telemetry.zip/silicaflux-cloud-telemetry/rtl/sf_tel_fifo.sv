// SilicaFlux CloudTelemetry - synchronous record FIFO.
//
// Semantics at a clock edge (all decided from pre-edge state):
//   flush         : FIFO becomes empty; a same-edge push is NOT stored.
//   push_ok       : push && !flush && count < DEPTH   (a same-edge pop does
//                   not make room - conservative, documented)
//   pop           : removes head if count > 0 and !flush; ignored when empty.
// head reads all-zero when the FIFO is empty.
module sf_tel_fifo #(
  parameter int W   = 32,
  parameter int DL2 = 4
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          push,
  input  logic [W-1:0]  din,
  input  logic          pop,
  input  logic          flush,
  output logic [W-1:0]  head,
  output logic [DL2:0]  count,
  output logic          push_ok
);
  localparam int DEPTH = 1 << DL2;

  logic [W-1:0]   mem [DEPTH];
  logic [DL2-1:0] wp, rp;
  logic [DL2:0]   cnt_q;
  logic           pop_eff;

  assign push_ok = push && !flush && (cnt_q < DEPTH[DL2:0]);
  assign pop_eff = pop  && !flush && (cnt_q != '0);
  assign count   = cnt_q;
  assign head    = (cnt_q != '0) ? mem[rp] : '0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0; cnt_q <= '0;
    end else if (flush) begin
      wp <= '0; rp <= '0; cnt_q <= '0;
    end else begin
      if (push_ok) wp <= wp + 1'b1;
      if (pop_eff) rp <= rp + 1'b1;
      cnt_q <= cnt_q + {{DL2{1'b0}}, push_ok} - {{DL2{1'b0}}, pop_eff};
    end
  end

  // Storage has no reset (contents are only visible through head when
  // count > 0, and head is forced to zero when empty).
  always_ff @(posedge clk) begin
    if (push_ok) mem[wp] <= din;
  end
endmodule
