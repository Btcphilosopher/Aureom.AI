// SilicaFlux CloudTelemetry - counter bank with atomic snapshot.
//
// N counters of CW bits.  Per edge, from pre-edge state:
//   snap          : shadow[i] <= cnt[i]  (pre-update value; all N in one edge)
//   clear         : cnt <= 0, ovf <= 0   (increment at this edge discarded)
//   preload_we    : cnt[preload_idx] <= preload_val (that counter's increment
//                   at this edge discarded; ovf untouched)
//   otherwise     : if count_active && ev_en[i] && inc[i] != 0:
//                     sum = cnt + inc (CW+1 bits)
//                     carry -> wrap: cnt = sum mod 2^CW ; sat: cnt = 2^CW-1
//                     carry -> ovf[i] <= 1 (sticky; set beats W1C)
// ovf_event pulses when any counter overflows at this edge.
module sf_tel_counter_bank #(
  parameter int N  = 8,
  parameter int CW = 64,
  parameter int IW = 16,
  parameter int XW = (N > 1) ? $clog2(N) : 1
) (
  input  logic                 clk,
  input  logic                 rst_n,
  input  logic [N-1:0][IW-1:0] inc,
  input  logic                 count_active,
  input  logic [N-1:0]         ev_en,
  input  logic [N-1:0]         sat_mode,
  input  logic                 clear,
  input  logic                 snap,
  input  logic [N-1:0]         ovf_w1c,
  input  logic                 preload_we,
  input  logic [XW-1:0]        preload_idx,
  input  logic [CW-1:0]        preload_val,
  input  logic [XW-1:0]        rd_idx,
  output logic [CW-1:0]        rd_live,
  output logic [CW-1:0]        rd_snap,
  output logic [N-1:0]         ovf,
  output logic                 ovf_event
);
  logic [CW-1:0] cnt  [N];
  logic [CW-1:0] shad [N];
  logic [N-1:0]  ovf_q;
  logic [N-1:0]  hit;     // increment applied with carry-out this edge
  logic [N-1:0]  do_inc;
  logic [CW-1:0] nxt  [N];

  assign ovf = ovf_q;

  always_comb begin
    for (int i = 0; i < N; i++) begin
      logic [CW:0] s;
      s = {1'b0, cnt[i]} + {{(CW + 1 - IW){1'b0}}, inc[i]};
      do_inc[i] = count_active && ev_en[i] && (inc[i] != '0) && !clear &&
                  !(preload_we && (preload_idx == XW'(i)));
      hit[i]    = do_inc[i] && s[CW];
`ifdef SF_TEL_MUT_WRAP_NO_OVF
      if (s[CW] && !sat_mode[i]) hit[i] = 1'b0;   // MUTATION: wrap loses ovf
`endif
      if (s[CW]) nxt[i] = sat_mode[i] ? {CW{1'b1}} : s[CW-1:0];
      else       nxt[i] = s[CW-1:0];
    end
  end

  assign ovf_event = |hit;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < N; i++) begin
        cnt[i]  <= '0;
        shad[i] <= '0;
      end
      ovf_q <= '0;
    end else begin
      for (int i = 0; i < N; i++) begin
`ifdef SF_TEL_MUT_SNAP_POST
        if (snap) shad[i] <= do_inc[i] ? nxt[i] : cnt[i];  // MUTATION: non-atomic post value
`else
        if (snap) shad[i] <= cnt[i];
`endif
        if (clear)                                          cnt[i] <= '0;
        else if (preload_we && (preload_idx == XW'(i)))     cnt[i] <= preload_val;
        else if (do_inc[i])                                 cnt[i] <= nxt[i];
      end
      if (clear) ovf_q <= '0;
      else       ovf_q <= (ovf_q & ~ovf_w1c) | hit;
    end
  end

  localparam int AW = (N > 1) ? $clog2(N) : 1;
  assign rd_live = (int'(rd_idx) < N) ? cnt[rd_idx[AW-1:0]]  : '0;
  assign rd_snap = (int'(rd_idx) < N) ? shad[rd_idx[AW-1:0]] : '0;
endmodule
