// SilicaFlux CloudTelemetry - end-to-end latency histogram.
//
// Log2 buckets over ALL completed commands (not only traced ones):
//   bin 0: latency in [0,2) ; bin b (1..14): [2^b, 2^(b+1)) ; bin 15: >= 2^15
// The sample produced at edge j is registered and applied at edge j+1 with
// the same gating as the counter banks (count_active), so the histogram and
// the counters always cover the same interval.  clear discards the sample
// being applied at that edge.  Bins/samples saturate at 2^32-1.
module sf_tel_hist
  import sf_tel_pkg::*;
(
  input  logic                          clk,
  input  logic                          rst_n,
  input  logic                          in_valid,
  input  logic [31:0]                   in_lat,
  input  logic                          count_active,
  input  logic                          clear,
  output logic [HIST_BINS-1:0][31:0]    hbins,
  output logic [31:0]                   samples,
  output logic [31:0]                   lat_max,
  output logic [63:0]                   lat_sum
);
  logic        s_valid;
  logic [31:0] s_lat;
  logic [3:0]  bidx;

  always_comb begin
    bidx = 4'd0;
    for (int b = 1; b < HIST_BINS; b++)
      if (s_lat >= (32'd1 << b)) bidx = 4'(b);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s_valid <= 1'b0; s_lat <= '0;
      hbins <= '0; samples <= '0; lat_max <= '0; lat_sum <= '0;
    end else begin
      s_valid <= in_valid;
      s_lat   <= in_lat;
      if (clear) begin
        hbins <= '0; samples <= '0; lat_max <= '0; lat_sum <= '0;
      end else if (s_valid && count_active) begin
        if (hbins[bidx] != 32'hFFFF_FFFF) hbins[bidx] <= hbins[bidx] + 32'd1;
        if (samples   != 32'hFFFF_FFFF) samples    <= samples + 32'd1;
        if (s_lat > lat_max) lat_max <= s_lat;
        lat_sum <= lat_sum + {32'd0, s_lat};
      end
    end
  end
endmodule
