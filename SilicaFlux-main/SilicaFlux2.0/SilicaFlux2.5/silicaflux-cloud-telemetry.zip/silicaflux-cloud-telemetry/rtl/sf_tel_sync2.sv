// SilicaFlux CloudTelemetry - 2-flop level synchronizer.
// Only for single-bit, level (quasi-static) asynchronous inputs such as a
// sensor alert pin.  Multi-bit values must never be passed through this cell.
module sf_tel_sync2 #(
  parameter logic RESET_VAL = 1'b0
) (
  input  logic clk,
  input  logic rst_n,
  input  logic d_async,
  output logic q
);
  logic s1, s2;
`ifdef SF_TEL_MUT_SYNC1
  // MUTATION: single-flop "synchronizer" (metastability hazard, 1-cycle
  // earlier).  Regression must detect the timing difference.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin s1 <= RESET_VAL; s2 <= RESET_VAL; end
    else begin s1 <= d_async; s2 <= d_async; end
  end
`else
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin s1 <= RESET_VAL; s2 <= RESET_VAL; end
    else begin s1 <= d_async; s2 <= s1; end
  end
`endif
  assign q = s2;
endmodule
