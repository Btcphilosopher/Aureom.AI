// SilicaFlux CloudTelemetry - power / thermal / occupancy gauges.
//
// Gauges are observations, not counts: they are NOT gated by GLOBAL_EN or
// freeze.  GAUGE_CLEAR resets min/max/last/samples/sum and a sample arriving
// at the same edge is applied on top of the cleared value.
// Temperature and power are kept as RAW sensor codes; conversion to physical
// units is a host-side, per-part calibration step.
module sf_tel_gauges (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        temp_valid,
  input  logic [11:0] temp_code,
  input  logic [11:0] warn_thresh,
  input  logic        pwr_meas_valid,
  input  logic [15:0] pwr_meas_code,
  input  logic        pwr_sensor_present,
  input  logic [15:0] net_q_occ,
  input  logic [1:0]  pwr_state,
  input  logic        clear,
  output logic        ev_warn,
  output logic        ev_pstate_trans,
  output logic        warn_state,
  output logic [31:0] temp_last_r,
  output logic [31:0] temp_minmax_r,
  output logic [31:0] pwr_status_r,
  output logic [15:0] pwr_last,
  output logic [31:0] pwr_samples,
  output logic [63:0] pwr_sum,
  output logic [15:0] qocc_max
);
  logic        t_seen;
  logic [11:0] t_last, t_min, t_max;
  logic [1:0]  pstate_q;
  logic        present_q;
  logic        above;

  assign above           = (temp_code >= warn_thresh);
  assign ev_warn         = temp_valid && above && !warn_state;
  assign ev_pstate_trans = (pwr_state != pstate_q);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      t_seen <= 1'b0; t_last <= '0; t_min <= 12'hFFF; t_max <= '0;
      warn_state <= 1'b0;
      pwr_last <= '0; pwr_samples <= '0; pwr_sum <= '0; qocc_max <= '0;
      pstate_q <= '0; present_q <= 1'b0;
    end else begin
      logic        b_seen;
      logic [11:0] b_last, b_min, b_max;
      logic [15:0] b_plast, b_q;
      logic [31:0] b_ps;
      logic [63:0] b_sum;
      b_seen  = clear ? 1'b0   : t_seen;
      b_last  = clear ? 12'd0  : t_last;
      b_min   = clear ? 12'hFFF : t_min;
      b_max   = clear ? 12'd0  : t_max;
      b_plast = clear ? 16'd0  : pwr_last;
      b_ps    = clear ? 32'd0  : pwr_samples;
      b_sum   = clear ? 64'd0  : pwr_sum;
      b_q     = clear ? 16'd0  : qocc_max;
      if (temp_valid) begin
        t_seen <= 1'b1;
        t_last <= temp_code;
        t_min  <= (temp_code < b_min) ? temp_code : b_min;
        t_max  <= (temp_code > b_max) ? temp_code : b_max;
        warn_state <= above;
      end else begin
        t_seen <= b_seen; t_last <= b_last; t_min <= b_min; t_max <= b_max;
      end
      if (pwr_meas_valid) begin
        pwr_last    <= pwr_meas_code;
        pwr_samples <= (b_ps == 32'hFFFF_FFFF) ? b_ps : b_ps + 32'd1;
        pwr_sum     <= b_sum + {48'd0, pwr_meas_code};
      end else begin
        pwr_last <= b_plast; pwr_samples <= b_ps; pwr_sum <= b_sum;
      end
      qocc_max  <= (net_q_occ > b_q) ? net_q_occ : b_q;
      pstate_q  <= pwr_state;
      present_q <= pwr_sensor_present;
    end
  end

  assign temp_last_r   = {t_seen, 19'd0, t_last};
  assign temp_minmax_r = {4'd0, t_max, 4'd0, t_min};
  assign pwr_status_r  = {29'd0, present_q, pstate_q};
endmodule
