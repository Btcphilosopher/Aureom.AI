// SilicaFlux CloudTelemetry - transaction latency tracer.
//
// A tag table (2^TAG_W entries) records the arrival timestamp and domain of
// every in-flight command, plus 32-bit deltas (cycles since arrival) for the
// intermediate stages DISPATCH, DMA_START, DMA_DONE, COMP_START, COMP_DONE.
// Timestamps are telemetry-clock cycles (ts), NOT host wall-clock time.
//
// One mark port per stage; at most one mark per stage per cycle.
// Rules (evaluated against the pre-edge table):
//   * ARRIVE(t)  opens entry t (overwrites; counts tag_reuse if t was open and
//                is not completing in the same cycle).  Selection for tracing
//                is decided here (filter + 1-in-N sampling) and fixed.
//   * stage s(t) for an open t stores delta = ts - ts_arr (first mark wins;
//                a repeated mark sets duplicate_stage).  A mark for t in the
//                same cycle as ARRIVE(t) belongs to the new entry (delta 0).
//                A mark for a tag that is not open counts as an orphan.
//   * COMPLETE(c) for an open c closes it, feeds the latency histogram and
//                domain completion accounting, and, if selected, emits a
//                completion record including same-cycle stage marks for c.
//                COMPLETE for a non-open tag is an orphan.
module sf_tel_trace
  import sf_tel_pkg::*;
(
  input  logic                              clk,
  input  logic                              rst_n,
  input  logic [NUM_STAGES-1:0]             mk_valid,
  input  logic [NUM_STAGES-1:0][TAG_W-1:0]  mk_tag,
  input  logic [DOM_W-1:0]                  mk_arr_dom,
  input  logic [63:0]                       ts,
  // configuration
  input  logic                              trace_en,
  input  logic [TAG_W-1:0]                  f_match,
  input  logic [TAG_W-1:0]                  f_mask,
  input  logic                              f_dom_en,
  input  logic [DOM_W-1:0]                  f_dom,
  input  logic [15:0]                       sample_n,
  input  logic                              sample_rst,
  // commands
  input  logic                              pop,
  input  logic                              flush,
  input  logic                              reset_counters,
  // events
  output logic                              ev_rec,
  output logic                              ev_drop,
  output logic                              dc_valid,
  output logic [DOM_W-1:0]                  dc_dom,
  output logic                              hist_valid,
  output logic [31:0]                       hist_lat,
  // readout
  output logic [9:0][31:0]                  head,
  output logic [TRACE_DEPTH_LOG2:0]         count,
  output logic [31:0]                       proto
);
  localparam int T  = 1 << TAG_W;
  localparam int NS = 5;               // stored intermediate stages 1..5
  localparam int RW = 32 * 10;

  logic [T-1:0]        a_valid, sel_v, dup_v, dsat_v;
  logic [DOM_W-1:0]    dom_t  [T];
  logic [63:0]         ts_arr [T];
  logic [NS:1]         sv     [T];
  logic [NS*32-1:0]    delta  [T];        // stage s at [(s-1)*32 +: 32]
  logic [15:0]         sphase, orphan_q, reuse_q;
  logic [31:0]         rec_seq;

  logic                arr, cmp;
  logic [TAG_W-1:0]    a, c;
  assign arr = mk_valid[STG_ARRIVE];
  assign cmp = mk_valid[STG_COMPLETE];
  assign a   = mk_tag[STG_ARRIVE];
  assign c   = mk_tag[STG_COMPLETE];

  function automatic logic [32:0] sat32(input logic [63:0] d);
    // {saturated, value}
    return (|d[63:32]) ? {1'b1, 32'hFFFF_FFFF} : {1'b0, d[31:0]};
  endfunction

  // ---------------- selection at arrival ----------------
  logic cand, sel_dec;
  assign cand    = trace_en && (((a ^ f_match) & f_mask) == '0) &&
                   (!f_dom_en || (mk_arr_dom == f_dom));
  assign sel_dec = cand && (sphase == 16'd0);

  // ---------------- completion / record formation ----------------
  logic        cmp_hit;
  logic [NS:1] same_c, rec_sv;
  logic [31:0] rec_d [NS+1];
  logic        dupx, satx;
  logic [32:0] d6;
  logic [RW-1:0] rec;
  logic        rec_req, push_ok;
  logic [3:0]  n_orphan;

  always_comb begin
    logic [32:0] dn;
    cmp_hit = cmp && a_valid[c];
    dupx = 1'b0; satx = 1'b0;
    for (int s = 1; s <= NS; s++) begin
      same_c[s] = mk_valid[s] && (mk_tag[s] == c) && !(arr && (a == c));
      dn = sat32(ts - ts_arr[c]);
      if (same_c[s] && !sv[c][s]) begin
        rec_d[s] = dn[31:0];
        satx = satx | dn[32];
      end else begin
        rec_d[s] = delta[c][(s-1)*32 +: 32];
      end
      if (same_c[s] && sv[c][s]) dupx = 1'b1;
      rec_sv[s] = sv[c][s] | same_c[s];
    end
    rec_d[0] = '0;
    d6 = sat32(ts - ts_arr[c]);
    satx = satx | d6[32];
    // word 0 at the LSB: {d6, d5..d1, ts_hi, ts_lo, seq, word0}
    rec = { d6[31:0], rec_d[5], rec_d[4], rec_d[3], rec_d[2], rec_d[1],
            ts_arr[c][63:32], ts_arr[c][31:0], rec_seq,
            {1'b1, dsat_v[c] | satx, dup_v[c] | dupx, 6'b0,
             1'b1, rec_sv[5], rec_sv[4], rec_sv[3], rec_sv[2], rec_sv[1], 1'b1,
             6'b0, dom_t[c], 3'b0, c} };

    // orphan marks this cycle
    n_orphan = '0;
    for (int s = 1; s <= NS; s++) begin
      if (mk_valid[s] && !(arr && (mk_tag[s] == a)) && !a_valid[mk_tag[s]])
        n_orphan = n_orphan + 4'd1;
    end
    if (cmp && !a_valid[c]) n_orphan = n_orphan + 4'd1;
  end

  assign rec_req    = cmp_hit && sel_v[c];
  assign ev_rec     = push_ok;
  assign ev_drop    = rec_req && !push_ok;
  assign dc_valid   = cmp_hit;
  assign dc_dom     = dom_t[c];
  assign hist_valid = cmp_hit;
  assign hist_lat   = d6[31:0];
  assign proto      = {reuse_q, orphan_q};

  logic [RW-1:0] head_flat;
  sf_tel_fifo #(.W(RW), .DL2(TRACE_DEPTH_LOG2)) u_fifo (
    .clk, .rst_n, .push(rec_req), .din(rec), .pop, .flush,
    .head(head_flat), .count, .push_ok
  );
  always_comb for (int w = 0; w < 10; w++) head[w] = head_flat[w*32 +: 32];

  // ---------------- table update ----------------
  logic reuse_ev;
  assign reuse_ev = arr && a_valid[a] && !(cmp && (c == a));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      a_valid <= '0; sel_v <= '0; dup_v <= '0; dsat_v <= '0;
      for (int t = 0; t < T; t++) begin
        dom_t[t] <= '0; ts_arr[t] <= '0; sv[t] <= '0; delta[t] <= '0;
      end
      sphase <= '0; orphan_q <= '0; reuse_q <= '0; rec_seq <= '0;
    end else begin
      // intermediate stage marks for open entries (not arriving / completing now)
      for (int s = 1; s <= NS; s++) begin
        if (mk_valid[s] && a_valid[mk_tag[s]] &&
            !(arr && (mk_tag[s] == a)) && !(cmp && (mk_tag[s] == c))) begin
          if (sv[mk_tag[s]][s]) begin
            dup_v[mk_tag[s]] <= 1'b1;
          end else begin
            logic [32:0] dd;
            dd = sat32(ts - ts_arr[mk_tag[s]]);
            sv[mk_tag[s]][s] <= 1'b1;
            delta[mk_tag[s]][(s-1)*32 +: 32] <= dd[31:0];
            if (dd[32]) dsat_v[mk_tag[s]] <= 1'b1;
          end
        end
      end
      if (cmp_hit) a_valid[c] <= 1'b0;
      if (arr) begin
        logic [NS:1] nsv;
        for (int s = 1; s <= NS; s++) nsv[s] = mk_valid[s] && (mk_tag[s] == a);
        a_valid[a] <= 1'b1;
        sel_v[a]   <= sel_dec;
        dup_v[a]   <= 1'b0;
        dsat_v[a]  <= 1'b0;
        dom_t[a]   <= mk_arr_dom;
        ts_arr[a]  <= ts;
        sv[a]      <= nsv;
        delta[a]   <= '0;
      end
      // sample phase
      if (sample_rst) sphase <= '0;
      else if (arr && cand) begin
        if (sample_n <= 16'd1)               sphase <= '0;
        else if (sphase + 16'd1 >= sample_n) sphase <= '0;
        else                                 sphase <= sphase + 16'd1;
      end
      // protocol statistics and record sequence
      if (reset_counters) begin
        orphan_q <= '0; reuse_q <= '0; rec_seq <= '0;
      end else begin
        if (n_orphan != '0)
          orphan_q <= ({1'b0, orphan_q} + {13'd0, n_orphan} > 17'h0FFFF) ? 16'hFFFF
                                                                       : orphan_q + {12'd0, n_orphan};
        if (reuse_ev && reuse_q != 16'hFFFF) reuse_q <= reuse_q + 16'd1;
        if (rec_req) rec_seq <= rec_seq + 32'd1;
      end
    end
  end
endmodule
