// SilicaFlux CloudTelemetry - event collection stage.
//
// Converts raw source-block strobes/lane values into one increment per
// global event and one increment per (domain, domain-event).  Multi-lane
// sources are SUMMED (adder tree / population count): two lanes retiring in
// the same cycle add 2, never 1.  The increments are registered (inc_q):
// inputs sampled at edge j are applied to the counter banks at edge j+1.
module sf_tel_event_collect
  import sf_tel_pkg::*;
(
  input  logic                         clk,
  input  logic                         rst_n,
  // compute
  input  logic [TL-1:0][7:0]           cmp_tensor_ops,
  input  logic [VL-1:0][7:0]           cmp_vector_ops,
  input  logic [KP-1:0]                cmp_kernel_done,
  input  logic                         cmp_busy,
  input  logic                         cmp_stall,
  input  logic [DOM_W-1:0]             cmp_dom,
  // network
  input  logic [PL-1:0]                net_pkt_accept,
  input  logic [PL-1:0]                net_pkt_fwd,
  input  logic [PL-1:0]                net_pkt_drop,
  input  logic [PL-1:0][7:0]           net_tx_bytes,
  input  logic [PL-1:0][DOM_W-1:0]     net_lane_dom,
  input  logic [15:0]                  net_q_occ,
  // DMA
  input  logic [DL-1:0][7:0]           dma_rd_bytes,
  input  logic [DL-1:0][7:0]           dma_wr_bytes,
  input  logic [DL-1:0][DOM_W-1:0]     dma_rd_dom,
  input  logic [DL-1:0][DOM_W-1:0]     dma_wr_dom,
  input  logic                         dma_stall,
  // memory
  input  logic [7:0]                   mem_rd_bytes,
  input  logic [7:0]                   mem_wr_bytes,
  input  logic [7:0]                   mig_bytes,
  input  logic [SB-1:0]                sram_conflict,
  // storage
  input  logic                         sto_cmd,
  input  logic                         sto_rd_done,
  input  logic                         sto_wr_done,
  input  logic                         sto_err,
  input  logic                         sto_integ_fail,
  // security
  input  logic                         sec_auth_fail,
  input  logic                         sec_perm_viol,
  input  logic                         sec_invalid_cmd,
  // RAS
  input  logic [ECC_N-1:0]             ras_ecc_corr,
  input  logic                         ras_ecc_uncorr,
  input  logic                         ras_dma_fail,
  input  logic                         ras_ctrl_reset,
  input  logic                         ras_watchdog,
  input  logic                         ras_fatal,
  // power
  input  logic [1:0]                   pwr_state,
  input  logic                         core_clk_en,
  input  logic                         temp_valid,
  // transaction marks
  input  logic [NUM_STAGES-1:0]        mk_valid,
  input  logic [DOM_W-1:0]             mk_arr_dom,
  // internally generated events
  input  logic                         ev_pstate_trans,
  input  logic                         ev_therm_warn,
  input  logic                         ev_therm_fault,
  input  logic                         ev_denied,
  input  logic                         ev_trace_rec,
  input  logic                         ev_trace_drop,
  input  logic                         ev_errlog_drop,
  input  logic                         dc_valid,
  input  logic [DOM_W-1:0]             dc_dom,
  // registered increments
  output logic [NUM_EV-1:0][INC_W-1:0]   inc_q,
  output logic [NUM_DCNT-1:0][INC_W-1:0] dinc_q
);
  logic [NUM_EV-1:0][INC_W-1:0]   inc_d;
  logic [NUM_DCNT-1:0][INC_W-1:0] dinc_d;

  function automatic logic [INC_W-1:0] b2i(input logic b);
    return {{(INC_W-1){1'b0}}, b};
  endfunction

  always_comb begin
    logic [INC_W-1:0] t_ops, v_ops, kdone, acc, fwd, drp, txb, rdb, wrb, sconf, ecc;
    t_ops = '0; v_ops = '0; kdone = '0; acc = '0; fwd = '0; drp = '0; txb = '0;
    rdb = '0; wrb = '0; sconf = '0; ecc = '0;
    for (int l = 0; l < TL; l++) t_ops = t_ops + {8'd0, cmp_tensor_ops[l]};
    for (int l = 0; l < VL; l++) v_ops = v_ops + {8'd0, cmp_vector_ops[l]};
    for (int l = 0; l < KP; l++) kdone = kdone + b2i(cmp_kernel_done[l]);
    for (int l = 0; l < PL; l++) begin
`ifdef SF_TEL_MUT_LANE_OR
      acc = |net_pkt_accept ? 16'd1 : 16'd0;   // MUTATION: OR instead of popcount
`else
      acc = acc + b2i(net_pkt_accept[l]);
`endif
      fwd = fwd + b2i(net_pkt_fwd[l]);
      drp = drp + b2i(net_pkt_drop[l]);
      txb = txb + {8'd0, net_tx_bytes[l]};
    end
    for (int l = 0; l < DL; l++) begin
      rdb = rdb + {8'd0, dma_rd_bytes[l]};
      wrb = wrb + {8'd0, dma_wr_bytes[l]};
    end
    for (int l = 0; l < SB; l++)    sconf = sconf + b2i(sram_conflict[l]);
    for (int l = 0; l < ECC_N; l++) ecc   = ecc   + b2i(ras_ecc_corr[l]);

    inc_d = '0;
    inc_d[EV_CYCLES]               = 16'd1;
    inc_d[EV_CMD_ARRIVED]          = b2i(mk_valid[STG_ARRIVE]);
    inc_d[EV_CMD_COMPLETED]        = b2i(mk_valid[STG_COMPLETE]);
    inc_d[EV_DMA_RD_BYTES]         = rdb;
    inc_d[EV_DMA_WR_BYTES]         = wrb;
    inc_d[EV_PKT_ACCEPTED]         = acc;
    inc_d[EV_PKT_FORWARDED]        = fwd;
    inc_d[EV_PKT_DROPPED]          = drp;
    inc_d[EV_NET_TX_BYTES]         = txb;
    inc_d[EV_DMA_STALL_CYCLES]     = b2i(dma_stall);
    inc_d[EV_NET_QOCC_ACCUM]       = net_q_occ;
    inc_d[EV_TENSOR_OPS]           = t_ops;
    inc_d[EV_VECTOR_OPS]           = v_ops;
    inc_d[EV_KERNELS_COMPLETED]    = kdone;
    inc_d[EV_COMPUTE_BUSY_CYCLES]  = b2i(cmp_busy);
    inc_d[EV_COMPUTE_STALL_CYCLES] = b2i(cmp_stall);
    inc_d[EV_MEM_RD_BYTES]         = {8'd0, mem_rd_bytes};
    inc_d[EV_MEM_WR_BYTES]         = {8'd0, mem_wr_bytes};
    inc_d[EV_SRAM_BANK_CONFLICTS]  = sconf;
    inc_d[EV_MIGRATION_BYTES]      = {8'd0, mig_bytes};
    inc_d[EV_STO_CMDS]             = b2i(sto_cmd);
    inc_d[EV_STO_READS_DONE]       = b2i(sto_rd_done);
    inc_d[EV_STO_WRITES_DONE]      = b2i(sto_wr_done);
    inc_d[EV_STO_ERRORS]           = b2i(sto_err);
    inc_d[EV_STO_INTEGRITY_FAIL]   = b2i(sto_integ_fail);
    inc_d[EV_SEC_AUTH_FAIL]        = b2i(sec_auth_fail);
    inc_d[EV_SEC_PERM_VIOL]        = b2i(sec_perm_viol);
    inc_d[EV_SEC_INVALID_CMD]      = b2i(sec_invalid_cmd);
    inc_d[EV_RAS_ECC_CORR]         = ecc;
    inc_d[EV_RAS_ECC_UNCORR]       = b2i(ras_ecc_uncorr);
    inc_d[EV_RAS_DMA_FAIL]         = b2i(ras_dma_fail);
    inc_d[EV_RAS_CTRL_RESET]       = b2i(ras_ctrl_reset);
    inc_d[EV_RAS_THERMAL_FAULT]    = b2i(ev_therm_fault);
    inc_d[EV_RAS_WATCHDOG]         = b2i(ras_watchdog);
    inc_d[EV_RAS_FATAL]            = b2i(ras_fatal);
    inc_d[EV_PWR_STATE_TRANSITIONS] = b2i(ev_pstate_trans);
    inc_d[EV_PSTATE0_CYCLES]       = b2i(pwr_state == 2'd0);
    inc_d[EV_PSTATE1_CYCLES]       = b2i(pwr_state == 2'd1);
    inc_d[EV_PSTATE2_CYCLES]       = b2i(pwr_state == 2'd2);
    inc_d[EV_PSTATE3_CYCLES]       = b2i(pwr_state == 2'd3);
    inc_d[EV_CORE_CLK_EN_CYCLES]   = b2i(core_clk_en);
    inc_d[EV_TEMP_SAMPLES]         = b2i(temp_valid);
    inc_d[EV_THERMAL_WARN_EVENTS]  = b2i(ev_therm_warn);
    inc_d[EV_TEL_ACCESS_DENIED]    = b2i(ev_denied);
    inc_d[EV_TRACE_RECORDS]        = b2i(ev_trace_rec);
    inc_d[EV_TRACE_DROPS]          = b2i(ev_trace_drop);
    inc_d[EV_ERRLOG_DROPS]         = b2i(ev_errlog_drop);
  end

  // Per-domain attribution.  Each lane carries its own domain id, so lanes
  // of different domains retiring in the same cycle are split correctly.
  always_comb begin
    dinc_d = '0;
    for (int d = 0; d < NUM_DOM; d++) begin
      logic [INC_W-1:0] rd, wr, fw, tx, tops;
      rd = '0; wr = '0; fw = '0; tx = '0; tops = '0;
      for (int l = 0; l < DL; l++) begin
`ifdef SF_TEL_MUT_DOM_FIRST_LANE
        if (dma_rd_dom[0] == DOM_W'(d)) rd = rd + {8'd0, dma_rd_bytes[l]};  // MUTATION
`else
        if (dma_rd_dom[l] == DOM_W'(d)) rd = rd + {8'd0, dma_rd_bytes[l]};
`endif
`ifdef SF_TEL_MUT_DOM_DROP_LANE1
        if (dma_wr_dom[l] == DOM_W'(d) && l == 0) wr = wr + {8'd0, dma_wr_bytes[l]};  // MUTATION
`else
        if (dma_wr_dom[l] == DOM_W'(d)) wr = wr + {8'd0, dma_wr_bytes[l]};
`endif
      end
      for (int l = 0; l < PL; l++) begin
        if (net_lane_dom[l] == DOM_W'(d)) begin
          fw = fw + b2i(net_pkt_fwd[l]);
          tx = tx + {8'd0, net_tx_bytes[l]};
        end
      end
      for (int l = 0; l < TL; l++) tops = tops + {8'd0, cmp_tensor_ops[l]};
      dinc_d[d*NUM_DEV + DEV_CMD_ARRIVED]   = b2i(mk_valid[STG_ARRIVE] && (mk_arr_dom == DOM_W'(d)));
      dinc_d[d*NUM_DEV + DEV_CMD_COMPLETED] = b2i(dc_valid && (dc_dom == DOM_W'(d)));
      dinc_d[d*NUM_DEV + DEV_DMA_RD_BYTES]  = rd;
      dinc_d[d*NUM_DEV + DEV_DMA_WR_BYTES]  = wr;
      dinc_d[d*NUM_DEV + DEV_TENSOR_OPS]    = (cmp_dom == DOM_W'(d)) ? tops : '0;
      dinc_d[d*NUM_DEV + DEV_COMPUTE_BUSY_CYCLES] = b2i(cmp_busy && (cmp_dom == DOM_W'(d)));
      dinc_d[d*NUM_DEV + DEV_PKT_FORWARDED] = fw;
      dinc_d[d*NUM_DEV + DEV_NET_TX_BYTES]  = tx;
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      inc_q  <= '0;
      dinc_q <= '0;
    end else begin
      inc_q  <= inc_d;
      dinc_q <= dinc_d;
    end
  end

`ifdef SF_TEL_ASSERT
  // Conservation: per-domain byte attribution must equal the global sum
  // every cycle (each lane belongs to exactly one domain).
  always_ff @(posedge clk) if (rst_n) begin
    logic [INC_W+2:0] srd, swr, stx;
    srd = '0; swr = '0; stx = '0;
    for (int d = 0; d < NUM_DOM; d++) begin
      srd = srd + dinc_d[d*NUM_DEV + DEV_DMA_RD_BYTES];
      swr = swr + dinc_d[d*NUM_DEV + DEV_DMA_WR_BYTES];
      stx = stx + dinc_d[d*NUM_DEV + DEV_NET_TX_BYTES];
    end
    assert (srd == inc_d[EV_DMA_RD_BYTES]) else $error("domain DMA_RD attribution mismatch");
    assert (swr == inc_d[EV_DMA_WR_BYTES]) else $error("domain DMA_WR attribution mismatch");
    assert (stx == inc_d[EV_NET_TX_BYTES]) else $error("domain NET_TX attribution mismatch");
  end
`endif
endmodule
