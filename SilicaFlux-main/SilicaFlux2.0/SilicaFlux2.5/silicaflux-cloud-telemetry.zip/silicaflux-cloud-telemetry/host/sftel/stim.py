"""Stimulus construction shared by the RTL regression and the collector.

A *workload* is a list of per-cycle dicts holding only the non-idle input
fields.  An *APB program* is a list of operations issued back-to-back by an
APB master (setup cycle + access cycle each, zero wait states).  `merge`
interleaves them into full per-cycle input vectors.
"""
from dataclasses import dataclass, field
from typing import Optional

from . import spec as S


@dataclass
class ApbOp:
    kind: str                  # "R" or "W"
    addr: int
    data: int = 0
    priv: int = 1
    user: int = 0
    not_before: int = 0        # earliest cycle for the setup phase
    label: Optional[str] = None
    gap: int = 0               # idle APB cycles inserted before this op
    # filled by merge():
    setup_cycle: int = -1
    access_cycle: int = -1


@dataclass
class Program:
    ops: list = field(default_factory=list)

    def w(self, addr, data, priv=1, user=0, at=0, label=None, gap=0):
        self.ops.append(ApbOp("W", addr, data & 0xFFFFFFFF, priv, user, at, label, gap))
        return self

    def r(self, addr, priv=1, user=0, at=0, label=None, gap=0):
        self.ops.append(ApbOp("R", addr, 0, priv, user, at, label, gap))
        return self

    def idle(self, n):
        """Insert n idle APB cycles before the next op."""
        self._pending_gap = getattr(self, "_pending_gap", 0) + n
        return self


def full_vector(sparse):
    v = dict(S.IDLE)
    if sparse:
        v.update(sparse)
    return v


def merge(workload, prog, tail_idle=4):
    """Return list of full input vectors. Op cycle numbers are recorded on ops."""
    ops = list(prog.ops) if prog else []
    out = []
    k = 0
    oi = 0
    phase = 0          # 0: free, 1: setup issued (access next)
    gap_left = ops[0].gap if ops else 0
    n_w = len(workload)
    while True:
        if k >= n_w and oi >= len(ops) and phase == 0:
            break
        vec = full_vector(workload[k] if k < n_w else None)
        if phase == 1:
            op = ops[oi]
            vec.update(psel=1, penable=1, pwrite=int(op.kind == "W"), paddr=op.addr,
                       pwdata=op.data, pprot=op.priv, pauser=op.user)
            op.access_cycle = k
            oi += 1
            phase = 0
            gap_left = ops[oi].gap if oi < len(ops) else 0
        elif oi < len(ops):
            op = ops[oi]
            if gap_left > 0:
                gap_left -= 1
            elif k >= op.not_before:
                vec.update(psel=1, penable=0, pwrite=int(op.kind == "W"), paddr=op.addr,
                           pwdata=op.data, pprot=op.priv, pauser=op.user)
                op.setup_cycle = k
                phase = 1
        out.append(vec)
        k += 1
    for _ in range(tail_idle):
        out.append(full_vector(None))
    return out


def write_stim(path, vectors, fields=None):
    """Write run-length-encoded hex stimulus: 'rep f0 f1 ...' per line.

    Only vectors with idle APB (psel=0) are merged, so every APB phase is its
    own line."""
    fields = fields or S.ALL_FIELDS
    names = [f[0] for f in fields]
    lines = []
    prev = None
    rep = 0
    for v in vectors:
        key = tuple(v[n] for n in names)
        if prev is not None and key == prev and not v.get("psel", 0):
            rep += 1
            continue
        if prev is not None:
            lines.append(f"{rep:x} " + " ".join(f"{x:x}" for x in prev))
        prev, rep = key, 1
    if prev is not None:
        lines.append(f"{rep:x} " + " ".join(f"{x:x}" for x in prev))
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")
    return len(lines)


def run_model(model, vectors):
    """Run vectors through the reference model; return the expected log lines
    in the exact format written by tb/tb_player.sv."""
    log = [f"I -1 {model.irq()}"]
    irq_prev = model.irq()
    for e, v in enumerate(vectors):
        if v["psel"] and v["penable"]:
            pass
        res = model.step(v)
        if res is not None:
            rd, err = res
            data = v["pwdata"] if v["pwrite"] else rd
            log.append(f"A {e} {v['pwrite']} {v['paddr']:04x} {data:08x} {err}")
        irq = model.irq()
        if irq != irq_prev:
            log.append(f"I {e} {irq}")
            irq_prev = irq
    log.append(f"E {len(vectors)}")
    return log
