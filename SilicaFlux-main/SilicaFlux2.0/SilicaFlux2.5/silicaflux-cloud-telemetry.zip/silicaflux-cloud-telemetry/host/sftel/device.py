"""CloudTelemetry device driver (register-level protocol).

All multi-register reads use one of two coherent mechanisms:
  * snapshot registers + seqlock: write CMD.SNAPSHOT, read SNAP_SEQ, read the
    snapshot window, read SNAP_SEQ again; retry if it changed (another agent
    snapshotted in between).
  * live 64-bit pairs: read LO (hardware latches HI), then HI immediately.
    The HI latch is shared, so live pairs must not be interleaved.
Trace/errlog FIFOs are drained check-then-pop by a single consumer: read
HEAD0, stop if not valid, read the remaining words, then POP.  (Popping
without checking validity can discard a record that arrived after the head
was read - found and fixed during regression development.)
"""
import time
from dataclasses import dataclass, field

from . import spec as S
from .spec import A, EV, live_addr, snap_addr, dsnap_addr, ctrl_value


class DeviceError(Exception):
    pass


@dataclass
class Snapshot:
    seq: int
    ts_cycles: int
    counters: dict
    dom_counters: dict            # {domain: {event: value}}
    overflow: dict                # {event: bool}
    dom_overflow: dict
    host_ns_before: int
    host_ns_after: int
    device_cycle_after: object    # simulation only (backend clock), else None
    retries: int = 0
    registers: dict = field(default_factory=dict)


class TelemetryDevice:
    def __init__(self, backend, priv=1, user=0):
        self.b = backend
        self.priv = priv
        self.user = user
        self.caps = None
        self.reads = 0

    # ------------------------------------------------------------ primitives
    def rd(self, addr):
        v, err = self.b.read32(addr, self.priv, self.user)
        self.reads += 1
        if err:
            raise DeviceError(f"PSLVERR reading 0x{addr:04x}")
        return v

    def wr(self, addr, data):
        err = self.b.write32(addr, data, self.priv, self.user)
        if err:
            raise DeviceError(f"PSLVERR writing 0x{addr:04x}")

    def rd64_live(self, lo_addr):
        lo = self.rd(lo_addr)
        hi = self.rd(lo_addr + 4)
        return (hi << 32) | lo

    def rd64_static(self, lo_addr):
        return self.rd(lo_addr) | (self.rd(lo_addr + 4) << 32)

    # ------------------------------------------------------------ identity
    def identify(self):
        idv = self.rd(A["ID"])
        if idv != S.SPEC["id_value"]:
            raise DeviceError(f"unexpected ID 0x{idv:08x}")
        ver = self.rd(A["VERSION"])
        c0, c1 = self.rd(A["CAPS0"]), self.rd(A["CAPS1"])
        caps = dict(num_ev=c0 & 0xFF, num_dev=(c0 >> 8) & 0xFF, num_dom=(c0 >> 16) & 0xF,
                    cnt_w=(c0 >> 20) & 0x7F, tag_w=c1 & 0xF, trace_depth=1 << ((c1 >> 4) & 0xF),
                    errlog_depth=1 << ((c1 >> 8) & 0xF), hist_bins=(c1 >> 12) & 0x1F,
                    version=f"{ver >> 16}.{ver & 0xFFFF}", id=f"0x{idv:08X}")
        if caps["num_ev"] != S.NUM_EV or caps["num_dev"] != S.NUM_DEV or caps["num_dom"] != S.NUM_DOM:
            raise DeviceError(f"device capabilities {caps} do not match host spec")
        self.caps = caps
        return caps

    # ------------------------------------------------------------ configuration
    def configure(self, trace=True, sample=1, tel_clk_hz=0, freeze_on_fatal=False,
                  temp_warn=None, errlog_mask=None, reset=True):
        if tel_clk_hz:
            self.wr(A["TEL_CLK_HZ"], tel_clk_hz)
        if temp_warn is not None:
            self.wr(A["TEMP_WARN_THRESH"], temp_warn)
        if errlog_mask is not None:
            self.wr(A["ERRLOG_MASK"], errlog_mask)
        self.wr(A["TRACE_SAMPLE"], sample)
        if reset:
            self.wr(A["CMD"], S.CMD["RESET_COUNTERS"] | S.CMD["TRACE_FLUSH"] |
                    S.CMD["ERRLOG_CLEAR"] | S.CMD["GAUGE_CLEAR"])
        self.wr(A["CTRL"], ctrl_value(global_en=1, trace_en=int(trace),
                                      freeze_on_fatal=int(freeze_on_fatal)))

    # ------------------------------------------------------------ snapshot
    def snapshot(self, with_domains=True, max_retries=5):
        for attempt in range(max_retries + 1):
            t0 = time.monotonic_ns()
            self.wr(A["CMD"], S.CMD["SNAPSHOT"])
            seq0 = self.rd(A["SNAP_SEQ"])
            ts = self.rd64_static(A["SNAP_TS_LO"])
            cnt = {e["name"]: self.rd64_static(snap_addr(i)) for i, e in enumerate(S.EVENTS)}
            dom = {}
            if with_domains:
                for d in range(S.NUM_DOM):
                    dom[d] = {e["name"]: self.rd64_static(dsnap_addr(d, j))
                              for j, e in enumerate(S.DOM_EVENTS)}
            seq1 = self.rd(A["SNAP_SEQ"])
            ovf = self.rd(A["OVF0"]) | (self.rd(A["OVF1"]) << 32)
            dovf = self.rd(A["DOM_OVF"])
            t1 = time.monotonic_ns()
            if seq0 == seq1:
                return Snapshot(
                    seq=seq0, ts_cycles=ts, counters=cnt, dom_counters=dom,
                    overflow={e["name"]: bool((ovf >> i) & 1) for i, e in enumerate(S.EVENTS)},
                    dom_overflow={(d, e["name"]): bool((dovf >> (d * S.NUM_DEV + j)) & 1)
                                  for d in range(S.NUM_DOM) for j, e in enumerate(S.DOM_EVENTS)},
                    host_ns_before=t0, host_ns_after=t1,
                    device_cycle_after=self.b.now_cycles(), retries=attempt)
        raise DeviceError("snapshot sequence kept changing (concurrent snapshot agents)")

    # ------------------------------------------------------------ status/gauges
    def status(self):
        st = self.rd(A["STATUS"])
        return dict(counting_active=st & 1, sw_freeze=(st >> 1) & 1, hw_frozen=(st >> 2) & 1,
                    temp_warn_state=(st >> 3) & 1, trace_count=(st >> 8) & 0x1F,
                    errlog_count=(st >> 16) & 0x1F, raw=st)

    def gauges(self):
        tl, tmm = self.rd(A["TEMP_LAST"]), self.rd(A["TEMP_MINMAX"])
        ps = self.rd(A["PWR_STATUS"])
        g = dict(temp_seen=tl >> 31, temp_last_code=tl & 0xFFF, temp_min_code=tmm & 0xFFF,
                 temp_max_code=(tmm >> 16) & 0xFFF, temp_warn_thresh=self.rd(A["TEMP_WARN_THRESH"]),
                 pstate=ps & 3, pwr_sensor_present=(ps >> 2) & 1,
                 pwr_last_code=self.rd(A["PWR_MEAS_LAST"]),
                 pwr_samples=self.rd(A["PWR_MEAS_SAMPLES"]),
                 pwr_sum_code=self.rd64_live(A["PWR_MEAS_SUM_LO"]),
                 qocc_max=self.rd(A["QOCC_MAX"]), tel_clk_hz=self.rd(A["TEL_CLK_HZ"]))
        return g

    def histogram(self):
        bins = [self.rd(A[f"HIST_BIN{i}"]) for i in range(S.P["HIST_BINS"])]
        return dict(bins=bins, samples=self.rd(A["HIST_SAMPLES"]), max=self.rd(A["HIST_MAX"]),
                    sum=self.rd64_live(A["HIST_SUM_LO"]))

    def trace_proto(self):
        v = self.rd(A["TRACE_PROTO"])
        return dict(orphan_marks=v & 0xFFFF, tag_reuse=v >> 16)

    # ------------------------------------------------------------ FIFO drains
    def drain_trace(self, limit=1 << 30):
        out = []
        while len(out) < limit:
            w0 = self.rd(A["TRACE_HEAD0"])
            if not w0 >> 31:
                break
            w = [w0] + [self.rd(A[f"TRACE_HEAD{i}"]) for i in range(1, 10)]
            self.wr(A["TRACE_POP"], 1)
            out.append(decode_trace(w))
        return out

    def drain_errlog(self, limit=1 << 30):
        out = []
        while len(out) < limit:
            h = self.rd(A["ERRLOG_HEAD0"])
            if not h >> 31:
                break
            ts = self.rd64_static(A["ERRLOG_HEAD_TS_LO"])
            self.wr(A["ERRLOG_POP"], 1)
            out.append(decode_errlog(h, ts))
        return out

    def first_error(self):
        h = self.rd(A["FIRST_ERR_INFO"])
        if not h >> 31:
            return None
        return decode_errlog(h, self.rd64_static(A["FIRST_ERR_TS_LO"]))


def decode_trace(w):
    sv = (w[0] >> 16) & 0x7F
    deltas = {}
    for s in range(1, 7):
        if (sv >> s) & 1:
            deltas[S.STAGES[s]] = w[3 + s]
    return dict(tag=w[0] & 0x1F, domain=(w[0] >> 8) & 3, seq=w[1],
                arrival_ts=w[2] | (w[3] << 32), deltas=deltas, stage_valid=sv,
                delta_saturated=bool((w[0] >> 30) & 1), duplicate_stage=bool((w[0] >> 29) & 1),
                raw=w)


def decode_errlog(h, ts):
    bm = (h >> 16) & 0xFF
    return dict(sources=[n for i, n in enumerate(S.SPEC["errlog_srcs"]) if (bm >> i) & 1],
                bitmap=bm, info=h & 0xFFFF, ts_cycles=ts)
