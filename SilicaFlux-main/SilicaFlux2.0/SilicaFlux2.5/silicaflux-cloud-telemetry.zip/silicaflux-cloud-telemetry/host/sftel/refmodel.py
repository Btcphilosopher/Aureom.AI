"""Cycle-accurate reference (specification) model of silicaflux_cloud_telemetry.

Written from the documented semantics (docs/ARCHITECTURE.md, register map and
event catalogue), not transliterated from the RTL.  It is driven with exactly
the same per-cycle input vectors as the RTL testbench and predicts every APB
read value, PSLVERR and every change of the irq output.  The regression
requires bit-exact agreement.

Conventions:
  * `step(x)` models one rising clock edge.  `x` maps every input field name
    (workload + APB) to an int.  All decisions use the state held BEFORE the
    edge; the new state is committed at the end.
  * Returned value: None, or (rdata, pslverr) when the cycle is an APB access
    phase (that is what the APB master samples at this edge).
"""
from . import spec as S

P = S.P
NUM_EV, NUM_DEV, NUM_DOM, NUM_DCNT = S.NUM_EV, S.NUM_DEV, S.NUM_DOM, S.NUM_DCNT
TAG_W, NS = P["TAG_W"], 5
T = 1 << TAG_W
TRACE_DEPTH = 1 << P["TRACE_DEPTH_LOG2"]
ERRLOG_DEPTH = 1 << P["ERRLOG_DEPTH_LOG2"]
M32, M64 = 0xFFFFFFFF, (1 << 64) - 1
EVM1 = S.SPEC["ev_en1_reset"]
EVI = S.EV
DEVI = S.DEV
ES_BIT = {n: i for i, n in enumerate(S.SPEC["errlog_srcs"])}


def _sat32(d):
    d &= M64
    return (M32, True) if d > M32 else (d, False)


def _pop(v):
    return bin(v).count("1")


class TelemetryModel:
    def __init__(self, cnt_w=64):
        self.cw = cnt_w
        self.cmax = (1 << cnt_w) - 1
        self.reset()

    # ------------------------------------------------------------------ reset
    def reset(self):
        self.cnt = [0] * NUM_EV
        self.shad = [0] * NUM_EV
        self.ovf = 0
        self.dcnt = [0] * NUM_DCNT
        self.dshad = [0] * NUM_DCNT
        self.dovf = 0
        self.inc_q = [0] * NUM_EV
        self.dinc_q = [0] * NUM_DCNT
        self.ts = 0
        self.s1 = self.s2 = self.tf_prev = 1
        self.r = {n: (r["reset"] or 0) for n, r in S.REGS.items() if r["access"] == "RW"}
        self.viol_info = 0
        self.snap_seq = 0
        self.snap_ts = 0
        self.hi_latch = 0
        self.irq_status = 0
        self.hw_frozen = 0
        self.fatal_pend = 0
        self.rdata_q = 0
        self.err_q = 0
        # trace table
        self.a_valid = [0] * T
        self.sel = [0] * T
        self.dup = [0] * T
        self.dsat = [0] * T
        self.tdom = [0] * T
        self.ts_arr = [0] * T
        self.sv = [[0] * (NS + 1) for _ in range(T)]
        self.delta = [[0] * (NS + 1) for _ in range(T)]
        self.sphase = 0
        self.orphan = 0
        self.reuse = 0
        self.rec_seq = 0
        self.tfifo = []
        # histogram
        self.h_sv = 0
        self.h_sl = 0
        self.hbins = [0] * P["HIST_BINS"]
        self.h_samples = 0
        self.h_max = 0
        self.h_sum = 0
        # errlog
        self.efifo = []
        self.first_v = 0
        self.first_info = 0
        self.first_ts = 0
        # gauges
        self.t_seen = 0
        self.t_last = 0
        self.t_min = 0xFFF
        self.t_max = 0
        self.warn_state = 0
        self.p_last = 0
        self.p_samples = 0
        self.p_sum = 0
        self.q_max = 0
        self.pstate_q = 0
        self.present_q = 0

    # ------------------------------------------------------------------ helpers
    def ctrl(self, name):
        lsb, w = S.CTRL[name]
        return (self.r["CTRL"] >> lsb) & ((1 << w) - 1)

    def count_active(self):
        return bool(self.ctrl("GLOBAL_EN") and not self.ctrl("SW_FREEZE") and not self.hw_frozen)

    def ev_en(self, i):
        v = self.r["EV_EN0"] | (self.r["EV_EN1"] << 32)
        return (v >> i) & 1

    def sat_mode(self, i):
        v = self.r["SAT0"] | (self.r["SAT1"] << 32)
        return (v >> i) & 1

    def irq(self):
        return int((self.irq_status & self.r["IRQ_EN"] & 0x1F) != 0)

    def status_word(self):
        return (self.count_active() | (self.ctrl("SW_FREEZE") << 1) | (self.hw_frozen << 2) |
                (self.warn_state << 3) | (len(self.tfifo) << 8) | (len(self.efifo) << 16))

    def trace_head(self):
        return list(self.tfifo[0]) if self.tfifo else [0] * 10

    def csr_value(self, name):
        """(value32, lo64 or None) for a CSR as seen before the edge."""
        if name in self.r:
            return self.r[name], None
        fixed = {
            "ID": S.SPEC["id_value"], "VERSION": S.SPEC["version_value"],
            "CAPS0": NUM_EV | (NUM_DEV << 8) | (NUM_DOM << 16) | (self.cw << 20),
            "CAPS1": TAG_W | (P["TRACE_DEPTH_LOG2"] << 4) | (P["ERRLOG_DEPTH_LOG2"] << 8) |
                     (P["HIST_BINS"] << 12),
        }
        if name in fixed:
            return fixed[name], None
        if name in ("CMD", "TRACE_POP", "ERRLOG_POP"):
            return 0, None
        if name == "STATUS":
            return self.status_word(), None
        if name == "SNAP_SEQ":
            return self.snap_seq, None
        if name == "SNAP_TS_LO":
            return self.snap_ts & M32, None
        if name == "SNAP_TS_HI":
            return self.snap_ts >> 32, None
        if name == "TS_LO":
            return None, self.ts
        if name == "PWR_MEAS_SUM_LO":
            return None, self.p_sum
        if name == "HIST_SUM_LO":
            return None, self.h_sum
        if name.endswith("_HI") and S.REGS[name]["access"] == "HI":
            return self.hi_latch, None
        if name == "OVF0":
            return self.ovf & M32, None
        if name == "OVF1":
            return self.ovf >> 32, None
        if name == "DOM_OVF":
            return self.dovf, None
        if name == "IRQ_STATUS":
            return self.irq_status, None
        if name == "VIOL_INFO":
            return self.viol_info, None
        if name == "TEMP_LAST":
            return (self.t_seen << 31) | self.t_last, None
        if name == "TEMP_MINMAX":
            return (self.t_max << 16) | self.t_min, None
        if name == "PWR_STATUS":
            return (self.present_q << 2) | self.pstate_q, None
        if name == "PWR_MEAS_LAST":
            return self.p_last, None
        if name == "PWR_MEAS_SAMPLES":
            return self.p_samples, None
        if name == "QOCC_MAX":
            return self.q_max, None
        if name == "TRACE_PROTO":
            return (self.reuse << 16) | self.orphan, None
        if name.startswith("TRACE_HEAD"):
            return self.trace_head()[int(name[10:])], None
        if name.startswith("HIST_BIN"):
            return self.hbins[int(name[8:])], None
        if name == "HIST_SAMPLES":
            return self.h_samples, None
        if name == "HIST_MAX":
            return self.h_max, None
        eh = self.efifo[0] if self.efifo else None
        if name == "ERRLOG_HEAD0":
            return ((1 << 31) | (eh[0] << 16) | eh[1]) if eh else 0, None
        if name == "ERRLOG_HEAD_TS_LO":
            return (eh[2] & M32) if eh else 0, None
        if name == "ERRLOG_HEAD_TS_HI":
            return (eh[2] >> 32) if eh else 0, None
        if name == "FIRST_ERR_INFO":
            return ((1 << 31) | self.first_info) if self.first_v else 0, None
        if name == "FIRST_ERR_TS_LO":
            return self.first_ts & M32, None
        if name == "FIRST_ERR_TS_HI":
            return self.first_ts >> 32, None
        raise KeyError(name)

    # ------------------------------------------------------------------ APB decode
    def decode(self, paddr, pwrite, priv, pauser):
        """Return dict(kind, ...) describing the target of an access."""
        if paddr & 3:
            return {"kind": None}
        if paddr < 0x400:
            r = S.REG_BY_OFF.get(paddr)
            return {"kind": "csr", "reg": r} if r else {"kind": None}
        hiw = (paddr >> 2) & 1
        if 0x400 <= paddr < 0x800 or 0x800 <= paddr < 0xC00:
            idx = (paddr >> 3) & 0x7F
            if idx >= NUM_EV:
                return {"kind": None}
            return {"kind": "live" if paddr < 0x800 else "snap", "idx": idx, "hi": hiw}
        if (paddr >> 12) in (1, 2):
            d = (paddr >> 8) & 0xF
            e = (paddr >> 3) & 0x1F
            if d >= NUM_DOM or e >= NUM_DEV:
                return {"kind": None}
            return {"kind": "dsnap" if (paddr >> 12) == 1 else "dlive", "d": d, "e": e,
                    "idx": d * NUM_DEV + e, "hi": hiw}
        return {"kind": None}

    def policy(self, t, pwrite, priv, pauser):
        """(permitted, denied)."""
        k = t["kind"]
        if priv:
            if k is None:
                return False, False
            if not pwrite:
                return True, False
            if k == "csr":
                return t["reg"]["access"] in ("RW", "WO", "W1C"), False
            if k in ("live", "dlive"):
                return not t["hi"], False
            return False, False
        if pwrite or k is None:
            return False, True
        if k == "csr":
            ok = t["reg"]["tenant"] == "read"
        elif k == "snap":
            tm = self.r["TENANT_MASK0"] | (self.r["TENANT_MASK1"] << 32)
            ok = bool(self.ctrl("TENANT_SHARED_EN") and (tm >> t["idx"]) & 1)
        elif k == "dsnap":
            ok = t["d"] == pauser
        else:
            ok = False
        return ok, not ok

    def read_value(self, t, priv):
        """(rdata, latch_value or None) for a permitted read."""
        k = t["kind"]
        if k == "csr":
            v, lo64 = self.csr_value(t["reg"]["name"])
            if lo64 is not None:
                return lo64 & M32, (lo64 >> 32) & M32
            return v & M32, None
        if k in ("live", "dlive"):
            if t["hi"]:
                return self.hi_latch, None
            v = self.cnt[t["idx"]] if k == "live" else self.dcnt[t["idx"]]
            return v & M32, (v >> 32) & M32
        v = self.shad[t["idx"]] if k == "snap" else self.dshad[t["idx"]]
        if k == "snap" and not priv:
            k_c = self.ctrl("TENANT_COARSEN")
            v &= ~((1 << k_c) - 1) & M64
        return ((v >> 32) & M32 if t["hi"] else v & M32), None

    # ------------------------------------------------------------------ edge
    def step(self, x):
        psel, pen, pwr = x["psel"], x["penable"], x["pwrite"]
        paddr, wdata = x["paddr"], x["pwdata"]
        priv, pauser = x["pprot"] & 1, x["pauser"]
        setup = psel and not pen
        access = psel and pen
        result = (self.rdata_q, self.err_q) if access else None
        count_active = self.count_active()

        # ---------------- APB setup phase
        n_rdata, n_err, latch, denied = self.rdata_q, self.err_q, None, False
        if setup:
            t = self.decode(paddr, pwr, priv, pauser)
            permitted, denied = self.policy(t, pwr, priv, pauser)
            n_err = int(not permitted)
            n_rdata = 0
            if permitted and not pwr:
                n_rdata, latch = self.read_value(t, priv)
        ev_denied = bool(setup and denied)

        # ---------------- APB access phase writes / command pulses
        wr = access and pwr and not self.err_q
        tw = self.decode(paddr, pwr, priv, pauser) if wr else {"kind": None}
        wname = tw["reg"]["name"] if tw["kind"] == "csr" else None
        cmd = wdata if wname == "CMD" else 0
        c_snap = bool(cmd & S.CMD["SNAPSHOT"])
        c_reset = bool(cmd & S.CMD["RESET_COUNTERS"])
        c_unfreeze = bool(cmd & S.CMD["UNFREEZE"])
        c_tflush = bool(cmd & S.CMD["TRACE_FLUSH"])
        c_hclear = bool(cmd & S.CMD["HIST_CLEAR"]) or c_reset
        c_eclear = bool(cmd & S.CMD["ERRLOG_CLEAR"])
        c_gclear = bool(cmd & S.CMD["GAUGE_CLEAR"])
        c_tpop = wname == "TRACE_POP"
        c_epop = wname == "ERRLOG_POP"
        sample_rst = wname == "TRACE_SAMPLE"
        w1c_g = (wdata if wname == "OVF0" else 0) | ((wdata & EVM1) << 32 if wname == "OVF1" else 0)
        w1c_d = wdata if wname == "DOM_OVF" else 0
        w1c_irq = (wdata & 0x1F) if wname == "IRQ_STATUS" else 0
        g_pre = tw["kind"] == "live"
        d_pre = tw["kind"] == "dlive"
        pre_val = ((self.r["PRELOAD_HI"] << 32) | wdata) & self.cmax

        # ---------------- gauges (combinational part)
        thr = self.r["TEMP_WARN_THRESH"] & 0xFFF
        above = x["temp_code"] >= thr
        ev_warn = bool(x["temp_valid"] and above and not self.warn_state)
        ev_pstate = x["pwr_state"] != self.pstate_q

        # ---------------- freeze-on-fatal request (uses pre-edge CTRL)
        new_pend = int(bool(x["ras_fatal"] and self.ctrl("FREEZE_ON_FATAL")))

        # ---------------- thermal fault synchronizer
        ev_tf = bool(self.tf_prev and not self.s2)

        # ---------------- trace (combinational part)
        mkv = x["mk_valid"]
        tags = S.unpack(x["mk_tag"], TAG_W, P["NUM_STAGES"])
        v = [(mkv >> s) & 1 for s in range(P["NUM_STAGES"])]
        arr, cmp = v[0], v[6]
        a, c = tags[0], tags[6]
        adom = x["mk_arr_dom"]
        fil = self.r["TRACE_FILTER"]
        f_match, f_mask, f_den, f_dom = fil & 31, (fil >> 8) & 31, (fil >> 16) & 1, (fil >> 20) & 3
        cand = bool(self.ctrl("TRACE_EN") and ((a ^ f_match) & f_mask) == 0 and
                    (not f_den or adom == f_dom))
        sel_dec = cand and self.sphase == 0
        cmp_hit = bool(cmp and self.a_valid[c])
        ts = self.ts
        satx = dupx = False
        rec_d = [0] * (NS + 1)
        rec_sv = [0] * (NS + 1)
        for s in range(1, NS + 1):
            same = v[s] and tags[s] == c and not (arr and a == c)
            if same and not self.sv[c][s]:
                rec_d[s], st = _sat32(ts - self.ts_arr[c])
                satx |= st
            else:
                rec_d[s] = self.delta[c][s]
            if same and self.sv[c][s]:
                dupx = True
            rec_sv[s] = int(self.sv[c][s] or same)
        d6, st6 = _sat32(ts - self.ts_arr[c])
        satx |= st6
        rec_req = cmp_hit and self.sel[c]
        push_ok = rec_req and not c_tflush and len(self.tfifo) < TRACE_DEPTH
        ev_rec, ev_drop = push_ok, (rec_req and not push_ok)
        n_orph = 0
        for s in range(1, NS + 1):
            if v[s] and not (arr and tags[s] == a) and not self.a_valid[tags[s]]:
                n_orph += 1
        if cmp and not self.a_valid[c]:
            n_orph += 1
        reuse_ev = bool(arr and self.a_valid[a] and not (cmp and c == a))
        dc_valid, dc_dom = cmp_hit, self.tdom[c]
        record = None
        if push_ok:
            svbits = 1 | (rec_sv[1] << 1) | (rec_sv[2] << 2) | (rec_sv[3] << 3) | \
                (rec_sv[4] << 4) | (rec_sv[5] << 5) | (1 << 6)
            w0 = ((1 << 31) | (int(self.dsat[c] or satx) << 30) | (int(self.dup[c] or dupx) << 29) |
                  (svbits << 16) | (self.tdom[c] << 8) | c)
            record = [w0, self.rec_seq, self.ts_arr[c] & M32, self.ts_arr[c] >> 32,
                      rec_d[1], rec_d[2], rec_d[3], rec_d[4], rec_d[5], d6]

        # ---------------- errlog (combinational part)
        src = 0
        src |= x["ras_ecc_uncorr"] << ES_BIT["ECC_UNCORR"]
        src |= x["ras_dma_fail"] << ES_BIT["DMA_FAIL"]
        src |= x["ras_ctrl_reset"] << ES_BIT["CTRL_RESET"]
        src |= int(ev_tf) << ES_BIT["THERMAL_FAULT"]
        src |= x["ras_watchdog"] << ES_BIT["WATCHDOG"]
        src |= x["ras_fatal"] << ES_BIT["FATAL"]
        src |= x["sto_integ_fail"] << ES_BIT["STO_INTEGRITY_FAIL"]
        src |= int(x["ras_ecc_corr"] != 0) << ES_BIT["ECC_CORR"]
        src &= self.r["ERRLOG_MASK"] & 0xFF
        log_req = src != 0
        e_push = log_req and not c_eclear and len(self.efifo) < ERRLOG_DEPTH
        ev_edrop = log_req and not e_push

        # ---------------- event collection (combinational)
        inc = [0] * NUM_EV
        u = S.unpack
        tops = sum(u(x["cmp_tensor_ops"], 8, P["TL"]))
        inc[EVI["CYCLES"]] = 1
        inc[EVI["CMD_ARRIVED"]] = arr
        inc[EVI["CMD_COMPLETED"]] = cmp
        inc[EVI["DMA_RD_BYTES"]] = sum(u(x["dma_rd_bytes"], 8, P["DL"]))
        inc[EVI["DMA_WR_BYTES"]] = sum(u(x["dma_wr_bytes"], 8, P["DL"]))
        inc[EVI["PKT_ACCEPTED"]] = _pop(x["net_pkt_accept"])
        inc[EVI["PKT_FORWARDED"]] = _pop(x["net_pkt_fwd"])
        inc[EVI["PKT_DROPPED"]] = _pop(x["net_pkt_drop"])
        inc[EVI["NET_TX_BYTES"]] = sum(u(x["net_tx_bytes"], 8, P["PL"]))
        inc[EVI["DMA_STALL_CYCLES"]] = x["dma_stall"]
        inc[EVI["NET_QOCC_ACCUM"]] = x["net_q_occ"]
        inc[EVI["TENSOR_OPS"]] = tops
        inc[EVI["VECTOR_OPS"]] = sum(u(x["cmp_vector_ops"], 8, P["VL"]))
        inc[EVI["KERNELS_COMPLETED"]] = _pop(x["cmp_kernel_done"])
        inc[EVI["COMPUTE_BUSY_CYCLES"]] = x["cmp_busy"]
        inc[EVI["COMPUTE_STALL_CYCLES"]] = x["cmp_stall"]
        inc[EVI["MEM_RD_BYTES"]] = x["mem_rd_bytes"]
        inc[EVI["MEM_WR_BYTES"]] = x["mem_wr_bytes"]
        inc[EVI["SRAM_BANK_CONFLICTS"]] = _pop(x["sram_conflict"])
        inc[EVI["MIGRATION_BYTES"]] = x["mig_bytes"]
        for n, f in (("STO_CMDS", "sto_cmd"), ("STO_READS_DONE", "sto_rd_done"),
                     ("STO_WRITES_DONE", "sto_wr_done"), ("STO_ERRORS", "sto_err"),
                     ("STO_INTEGRITY_FAIL", "sto_integ_fail"), ("SEC_AUTH_FAIL", "sec_auth_fail"),
                     ("SEC_PERM_VIOL", "sec_perm_viol"), ("SEC_INVALID_CMD", "sec_invalid_cmd"),
                     ("RAS_ECC_UNCORR", "ras_ecc_uncorr"), ("RAS_DMA_FAIL", "ras_dma_fail"),
                     ("RAS_CTRL_RESET", "ras_ctrl_reset"), ("RAS_WATCHDOG", "ras_watchdog"),
                     ("RAS_FATAL", "ras_fatal"), ("CORE_CLK_EN_CYCLES", "core_clk_en"),
                     ("TEMP_SAMPLES", "temp_valid")):
            inc[EVI[n]] = x[f]
        inc[EVI["RAS_ECC_CORR"]] = _pop(x["ras_ecc_corr"])
        inc[EVI["RAS_THERMAL_FAULT"]] = int(ev_tf)
        inc[EVI["PWR_STATE_TRANSITIONS"]] = int(ev_pstate)
        for k in range(4):
            inc[EVI[f"PSTATE{k}_CYCLES"]] = int(x["pwr_state"] == k)
        inc[EVI["THERMAL_WARN_EVENTS"]] = int(ev_warn)
        inc[EVI["TEL_ACCESS_DENIED"]] = int(ev_denied)
        inc[EVI["TRACE_RECORDS"]] = int(ev_rec)
        inc[EVI["TRACE_DROPS"]] = int(ev_drop)
        inc[EVI["ERRLOG_DROPS"]] = int(ev_edrop)

        dinc = [0] * NUM_DCNT
        rdb = u(x["dma_rd_bytes"], 8, P["DL"]); rdd = u(x["dma_rd_dom"], 2, P["DL"])
        wrb = u(x["dma_wr_bytes"], 8, P["DL"]); wrd = u(x["dma_wr_dom"], 2, P["DL"])
        txb = u(x["net_tx_bytes"], 8, P["PL"]); nd = u(x["net_lane_dom"], 2, P["PL"])
        fwd = u(x["net_pkt_fwd"], 1, P["PL"])
        for d in range(NUM_DOM):
            b = d * NUM_DEV
            dinc[b + DEVI["D_CMD_ARRIVED"]] = int(arr and adom == d)
            dinc[b + DEVI["D_CMD_COMPLETED"]] = int(dc_valid and dc_dom == d)
            dinc[b + DEVI["D_DMA_RD_BYTES"]] = sum(rdb[l] for l in range(P["DL"]) if rdd[l] == d)
            dinc[b + DEVI["D_DMA_WR_BYTES"]] = sum(wrb[l] for l in range(P["DL"]) if wrd[l] == d)
            dinc[b + DEVI["D_TENSOR_OPS"]] = tops if x["cmp_dom"] == d else 0
            dinc[b + DEVI["D_COMPUTE_BUSY_CYCLES"]] = int(x["cmp_busy"] and x["cmp_dom"] == d)
            dinc[b + DEVI["D_PKT_FORWARDED"]] = sum(fwd[l] for l in range(P["PL"]) if nd[l] == d)
            dinc[b + DEVI["D_NET_TX_BYTES"]] = sum(txb[l] for l in range(P["PL"]) if nd[l] == d)

        # ================================================================ commit
        # counter banks (apply registered increments)
        ovf_event = False
        g_idx = tw.get("idx") if g_pre else None
        d_idx = tw.get("idx") if d_pre else None
        ovf_hit = 0
        for i in range(NUM_EV):
            if c_snap:
                self.shad[i] = self.cnt[i]
            if c_reset:
                self.cnt[i] = 0
                continue
            if g_idx == i:
                self.cnt[i] = pre_val
                continue
            iv = self.inc_q[i]
            if count_active and self.ev_en(i) and iv:
                s_ = self.cnt[i] + iv
                if s_ > self.cmax:
                    ovf_hit |= 1 << i
                    s_ = self.cmax if self.sat_mode(i) else s_ & self.cmax
                self.cnt[i] = s_
        self.ovf = 0 if c_reset else ((self.ovf & ~w1c_g) | ovf_hit)
        ovf_event |= ovf_hit != 0
        dctrl = self.r["DOM_CTRL"]
        dsat_mode = (dctrl >> 8) & 1
        dhit = 0
        for i in range(NUM_DCNT):
            if c_snap:
                self.dshad[i] = self.dcnt[i]
            if c_reset:
                self.dcnt[i] = 0
                continue
            if d_idx == i:
                self.dcnt[i] = pre_val
                continue
            iv = self.dinc_q[i]
            if count_active and (dctrl >> (i % NUM_DEV)) & 1 and iv:
                s_ = self.dcnt[i] + iv
                if s_ > self.cmax:
                    dhit |= 1 << i
                    s_ = self.cmax if dsat_mode else s_ & self.cmax
                self.dcnt[i] = s_
        self.dovf = 0 if c_reset else ((self.dovf & ~w1c_d) | dhit)
        ovf_event |= dhit != 0
        self.inc_q = inc
        self.dinc_q = dinc

        # histogram (registered sample applied with counter gating)
        if c_hclear:
            self.hbins = [0] * P["HIST_BINS"]
            self.h_samples = self.h_max = self.h_sum = 0
        elif self.h_sv and count_active:
            lat = self.h_sl
            b = 0
            for k in range(1, P["HIST_BINS"]):
                if lat >= (1 << k):
                    b = k
            self.hbins[b] = min(M32, self.hbins[b] + 1)
            self.h_samples = min(M32, self.h_samples + 1)
            self.h_max = max(self.h_max, lat)
            self.h_sum = (self.h_sum + lat) & M64
        self.h_sv, self.h_sl = int(cmp_hit), d6

        # trace table
        for s in range(1, NS + 1):
            tg = tags[s]
            if v[s] and self.a_valid[tg] and not (arr and tg == a) and not (cmp and tg == c):
                if self.sv[tg][s]:
                    self.dup[tg] = 1
                else:
                    dd, st = _sat32(ts - self.ts_arr[tg])
                    self.sv[tg][s] = 1
                    self.delta[tg][s] = dd
                    if st:
                        self.dsat[tg] = 1
        if cmp_hit:
            self.a_valid[c] = 0
        if arr:
            self.a_valid[a] = 1
            self.sel[a] = int(sel_dec)
            self.dup[a] = 0
            self.dsat[a] = 0
            self.tdom[a] = adom
            self.ts_arr[a] = ts
            self.sv[a] = [0] + [int(v[s] and tags[s] == a) for s in range(1, NS + 1)]
            self.delta[a] = [0] * (NS + 1)
        n_samp = self.r["TRACE_SAMPLE"] & 0xFFFF
        if sample_rst:
            self.sphase = 0
        elif arr and cand:
            if n_samp <= 1 or self.sphase + 1 >= n_samp:
                self.sphase = 0
            else:
                self.sphase += 1
        if c_reset:
            self.orphan = self.reuse = self.rec_seq = 0
        else:
            self.orphan = min(0xFFFF, self.orphan + n_orph)
            self.reuse = min(0xFFFF, self.reuse + int(reuse_ev))
            if rec_req:
                self.rec_seq = (self.rec_seq + 1) & M32
        # trace FIFO
        if c_tflush:
            self.tfifo = []
        else:
            if c_tpop and self.tfifo:
                self.tfifo.pop(0)
            if push_ok:
                self.tfifo.append(record)

        # errlog
        if c_eclear:
            self.efifo = []
            self.first_v = 0
            self.first_info = 0
            self.first_ts = 0
        else:
            if c_epop and self.efifo:
                self.efifo.pop(0)
            if e_push:
                self.efifo.append((src, x["ras_info"], ts))
            if log_req and not self.first_v:
                self.first_v = 1
                self.first_info = (src << 16) | x["ras_info"]
                self.first_ts = ts

        # gauges
        if c_gclear:
            b_seen, b_last, b_min, b_max = 0, 0, 0xFFF, 0
            b_plast, b_ps, b_sum, b_q = 0, 0, 0, 0
        else:
            b_seen, b_last, b_min, b_max = self.t_seen, self.t_last, self.t_min, self.t_max
            b_plast, b_ps, b_sum, b_q = self.p_last, self.p_samples, self.p_sum, self.q_max
        if x["temp_valid"]:
            tc = x["temp_code"]
            self.t_seen, self.t_last = 1, tc
            self.t_min, self.t_max = min(b_min, tc), max(b_max, tc)
            self.warn_state = int(above)
        else:
            self.t_seen, self.t_last, self.t_min, self.t_max = b_seen, b_last, b_min, b_max
        if x["pwr_meas_valid"]:
            self.p_last = x["pwr_meas_code"]
            self.p_samples = min(M32, b_ps + 1)
            self.p_sum = (b_sum + x["pwr_meas_code"]) & M64
        else:
            self.p_last, self.p_samples, self.p_sum = b_plast, b_ps, b_sum
        self.q_max = max(b_q, x["net_q_occ"])
        self.pstate_q = x["pwr_state"]
        self.present_q = x["pwr_sensor_present"]

        # registers
        if setup:
            self.rdata_q, self.err_q = n_rdata, n_err
            if latch is not None and priv:
                self.hi_latch = latch
            if denied:
                self.viol_info = (1 << 31) | (pwr << 30) | (pauser << 24) | paddr
        if wname in self.r:
            self.r[wname] = wdata & S.RW_MASKS[wname]
        if c_reset and not (setup and denied):
            self.viol_info = 0
        if c_snap:
            self.snap_seq = (self.snap_seq + 1) & M32
            self.snap_ts = ts
        irq_set = 0
        if ovf_event:
            irq_set |= S.IRQ["OVF"]
        if log_req:
            irq_set |= S.IRQ["RAS"]
        if ev_rec:
            irq_set |= S.IRQ["TRACE"]
        if ev_warn:
            irq_set |= S.IRQ["THERM_WARN"]
        if self.fatal_pend and not self.hw_frozen:
            irq_set |= S.IRQ["HW_FREEZE"]
        if self.fatal_pend:
            self.hw_frozen = 1
        elif c_unfreeze:
            self.hw_frozen = 0
        self.fatal_pend = new_pend
        self.irq_status = (self.irq_status & ~w1c_irq) | irq_set

        # synchronizer and timebase
        self.tf_prev = self.s2
        self.s2 = self.s1
        self.s1 = x["thermal_fault_n"]
        self.ts = (ts + 1) & M64
        return result
