"""Report exporters: JSON, CSV and Prometheus text exposition format.

Every exported value carries its source: CSV has origin/backend/registers/
snapshot/derivation columns; Prometheus samples carry origin, backend and
kind labels (so simulated values can never be mistaken for production
series), and HELP text names the source registers.
"""
import csv
import io
import json
import re


def to_json(rep, path):
    with open(path, "w") as f:
        json.dump(rep, f, indent=1, default=str)


CSV_COLS = ["name", "value", "unit", "kind", "group", "origin", "backend", "registers",
            "snapshot_seq", "window_ts_cycles", "derivation", "note"]


def to_csv(rep, path=None):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(CSV_COLS)
    for m in rep["metrics"]:
        s = m["source"]
        w.writerow([m["name"], m["value"], m["unit"], m["kind"], m["group"], s.get("origin"),
                    s.get("backend"), ";".join(s.get("registers", [])),
                    json.dumps(s.get("snapshot_seq")), json.dumps(s.get("window_ts_cycles")),
                    m.get("derivation") or "", m.get("note") or ""])
    for d in rep["domains"]:
        s = d["source"]
        w.writerow([f"domain{d['domain']}_{d['event'].lower()}", d["value"], d["unit"], "counter",
                    "domain", s.get("origin"), s.get("backend"), ";".join(s["registers"]),
                    json.dumps(s.get("snapshot_seq")), json.dumps(s.get("window_ts_cycles")),
                    f"DOM_SNAP delta; share of {d['global_event']}={d['share']}", ""])
    lat = rep["latency"]
    for q in ("p50", "p95", "p99", "p999", "max"):
        w.writerow([f"latency_e2e_{q}", lat["traced"][q], "cycles", "derived", "latency",
                    rep["data_origin"], rep["backend"].get("backend"), "TRACE_HEAD0..9", "", "",
                    f"nearest-rank over n={lat['traced']['n']} traced records",
                    "INSUFFICIENT SAMPLES" if lat["traced"].get(q + "_insufficient") else ""])
    text = buf.getvalue()
    if path:
        with open(path, "w") as f:
            f.write(text)
    return text


def _pname(n):
    return "sftel_" + re.sub(r"[^a-zA-Z0-9_]", "_", n).lower()


def to_prometheus(rep, path=None, device="sftel0"):
    lines = []
    base = dict(device=device, origin=rep["data_origin"], backend=rep["backend"].get("backend", ""),
                experiment=rep["experiment"]["name"])

    def lab(extra=None):
        d = dict(base, **(extra or {}))
        return "{" + ",".join(f'{k}="{v}"' for k, v in d.items()) + "}"
    seen = set()
    for m in rep["metrics"]:
        if m["value"] is None:
            continue
        kind = m["kind"]
        name = _pname(m["name"]) + ("_total" if kind == "counter" else "")
        if name in seen:
            continue
        seen.add(name)
        ptype = "counter" if kind == "counter" else "gauge"
        regs = ",".join(m["source"].get("registers", []))
        help_ = f"{m['unit']}; kind={kind}; source={regs}"
        if m.get("derivation"):
            help_ += f"; {m['derivation']}"
        if m.get("note"):
            help_ += f"; {m['note']}"
        lines.append(f"# HELP {name} {help_}")
        lines.append(f"# TYPE {name} {ptype}")
        lines.append(f"{name}{lab({'kind': kind})} {m['value']}")
    lines.append("# HELP sftel_domain_events_total per-domain counter delta; source=DOM_SNAP")
    lines.append("# TYPE sftel_domain_events_total counter")
    for d in rep["domains"]:
        lines.append(f"sftel_domain_events_total{lab({'domain': d['domain'], 'event': d['event'].lower(), 'kind': 'counter'})} {d['value']}")
    lat = rep["latency"]["traced"]
    lines.append("# HELP sftel_latency_e2e_cycles end-to-end latency quantiles (nearest-rank, "
                 "observed traced records); source=TRACE_HEAD")
    lines.append("# TYPE sftel_latency_e2e_cycles gauge")
    for q, p in (("p50", "0.5"), ("p95", "0.95"), ("p99", "0.99"), ("p999", "0.999")):
        if lat[q] is not None:
            lines.append(f"sftel_latency_e2e_cycles{lab({'quantile': p, 'samples': lat['n'], 'insufficient': str(lat[q + '_insufficient']).lower()})} {lat[q]}")
    text = "\n".join(lines) + "\n"
    if path:
        with open(path, "w") as f:
            f.write(text)
    return text
