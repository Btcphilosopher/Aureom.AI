"""Build the self-contained SilicaFlux telemetry dashboard (single HTML file).

Reports are embedded as JSON (bulky raw snapshot counters and full check
lists are kept; per-record raw words are dropped).  The page renders only
what is in the reports - it computes no metric of its own except per-window
rates already defined in the report's timeseries and display binning.
"""
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TEMPLATE = os.path.join(ROOT, "dashboard", "template.html")


def _trim(rep):
    r = dict(rep)
    r["snapshots"] = [dict(seq=s["seq"], ts_cycles=s["ts_cycles"], overflow=s["overflow"])
                      for s in rep["snapshots"]]
    lat = dict(rep["latency"])
    lat["samples"] = [dict(seq=x["seq"], tag=x["tag"], domain=x["domain"], deltas=x["deltas"])
                      for x in lat["samples"]]
    r["latency"] = lat
    return r


def build_dashboard(reports, out_path):
    with open(TEMPLATE) as f:
        html = f.read()
    order = ["baseline_p1", "mixed_tenants", "ras_fault_injection", "thermal_power"]
    reports = sorted(reports, key=lambda r: (order.index(r["experiment"]["name"])
                                             if r["experiment"]["name"] in order else 99,
                                             r["experiment"]["name"]))
    data = json.dumps([_trim(r) for r in reports], separators=(",", ":"), default=str)
    data = data.replace("</", "<\\/")   # keep the embedded JSON inert inside <script>
    html = html.replace("/*__SFTEL_DATA__*/null", data)
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    with open(out_path, "w") as f:
        f.write(html)
    return out_path
