"""`sftel` command-line interface.

  sftel discover   [--sysfs ROOT] [--vendor 0xFFFF --device 0x0069]
  sftel experiment NAME [--backend verilator|model] [--cycles N] [--seed S] [--out DIR]
  sftel summary    REPORT.json
  sftel export     REPORT.json --format csv|prom|json [-o FILE]
  sftel dashboard  [--experiments DIR] [-o dashboard/index.html]
  sftel snapshot   --bar /sys/bus/pci/devices/BDF/resource0     (hardware)
"""
import argparse
import glob
import json
import os
import sys

from . import export, summary


def main(argv=None):
    ap = argparse.ArgumentParser(prog="sftel")
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("discover")
    d.add_argument("--sysfs", default="/sys/bus/pci/devices")
    d.add_argument("--vendor", type=lambda x: int(x, 0), default=None)
    d.add_argument("--device", type=lambda x: int(x, 0), default=None)
    e = sub.add_parser("experiment")
    e.add_argument("name")
    e.add_argument("--backend", default="verilator", choices=["verilator", "model"])
    e.add_argument("--cycles", type=int, default=60000)
    e.add_argument("--seed", type=int, default=69)
    e.add_argument("--out", default="experiments")
    e.add_argument("--energy-model", default=None)
    s = sub.add_parser("summary")
    s.add_argument("report")
    x = sub.add_parser("export")
    x.add_argument("report")
    x.add_argument("--format", choices=["csv", "prom", "json"], required=True)
    x.add_argument("-o", "--output", default=None)
    db = sub.add_parser("dashboard")
    db.add_argument("--experiments", default="experiments")
    db.add_argument("-o", "--output", default=os.path.join("dashboard", "index.html"))
    sn = sub.add_parser("snapshot")
    sn.add_argument("--bar", required=True)
    a = ap.parse_args(argv)

    if a.cmd == "discover":
        from .backends import pcie
        kw = {}
        if a.vendor is not None:
            kw["vendor"] = a.vendor
        if a.device is not None:
            kw["device"] = a.device
        found = pcie.discover(a.sysfs, **kw)
        print(json.dumps(dict(sysfs=a.sysfs, matches=found,
                              note="PCI IDs are placeholders until assigned"), indent=1))
        return 0 if found else 1
    if a.cmd == "experiment":
        from .collector import run_experiment
        em = None
        if a.energy_model:
            with open(a.energy_model) as f:
                em = json.load(f)
        rep = run_experiment(a.name, backend=a.backend, seed=a.seed, cycles=a.cycles,
                             out_dir=a.out, energy_model=em)
        base = os.path.join(a.out, a.name)
        export.to_csv(rep, base + ".csv")
        export.to_prometheus(rep, base + ".prom")
        print(summary.diagnostic_summary(rep))
        return 0 if rep["verification"]["passed"] else 2
    if a.cmd == "summary":
        with open(a.report) as f:
            print(summary.diagnostic_summary(json.load(f)))
        return 0
    if a.cmd == "export":
        with open(a.report) as f:
            rep = json.load(f)
        if a.format == "csv":
            t = export.to_csv(rep, a.output)
        elif a.format == "prom":
            t = export.to_prometheus(rep, a.output)
        else:
            t = json.dumps(rep, indent=1)
            if a.output:
                with open(a.output, "w") as f:
                    f.write(t)
        if not a.output:
            sys.stdout.write(t)
        return 0
    if a.cmd == "dashboard":
        from .dashboard import build_dashboard
        reps = []
        for p in sorted(glob.glob(os.path.join(a.experiments, "*.json"))):
            with open(p) as f:
                r = json.load(f)
            if r.get("report_format") == "sftel-report/1":
                reps.append(r)
        build_dashboard(reps, a.output)
        print(f"wrote {a.output} with {len(reps)} experiment(s)")
        return 0
    if a.cmd == "snapshot":
        from .backends.pcie import PcieBackend
        from .device import TelemetryDevice
        with PcieBackend(a.bar) as b:
            dev = TelemetryDevice(b)
            caps = dev.identify()
            s = dev.snapshot()
            print(json.dumps(dict(origin="hardware", caps=caps, seq=s.seq, ts_cycles=s.ts_cycles,
                                  counters=s.counters), indent=1))
        return 0
    return 1


if __name__ == "__main__":
    sys.exit(main())
