"""SilicaFlux Project 69 CloudTelemetry - host-side software.

  sftel.spec       runtime spec (generated from spec/telemetry_spec.py)
  sftel.refmodel   cycle-accurate reference model of the RTL (spec model)
  sftel.stim       stimulus/scenario construction
  sftel.backends   MMIO backends: Verilator RTL harness, reference model, PCIe sysfs
  sftel.device     driver: identify, seqlock snapshots, trace / errlog drains
  sftel.collector  metrics with provenance, derived statistics
  sftel.latency    quantiles from observed trace records, histogram bounds
  sftel.export     JSON / CSV / Prometheus text exposition
  sftel.cli        `sftel` command-line entry point
"""
__version__ = "1.0.0"
