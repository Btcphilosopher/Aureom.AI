"""Metrics collection with provenance, and the experiment runner.

Every statistic in a report is a dict:
  {name, value, unit, kind, group, source:{origin, backend, registers,
   snapshot_seq, window_ts_cycles}, derivation, note}
kind is one of:
  counter      difference of a hardware counter between two snapshots
  gauge        a hardware gauge register read at a known time
  derived      arithmetic on counters/gauges (formula in `derivation`)
  measured_raw raw sensor code from the measured-power path
  estimate     activity-model estimate (never presented as measured)
origin is "simulation" or "hardware"; nothing synthetic is ever labelled
production data.
"""
import json
import os
import time

from . import latency as L
from . import spec as S
from .device import TelemetryDevice

DEFAULT_PROFILE = {
    "name": "synthetic-workload-profile",
    "assumption": "Capacities match the synthetic workload generator (64 B/beat DMA lanes). "
                  "They are NOT CloudDMA datasheet values; replace with the real platform "
                  "profile before quoting utilisation on hardware.",
    "dma_rd_bytes_per_cycle": 2 * 64,
    "dma_wr_bytes_per_cycle": 2 * 64,
}


def _src(ctx, regs, sa=None, sb=None, extra=None):
    s = dict(origin=ctx["origin"], backend=ctx["backend"], registers=regs)
    if sa is not None and sb is not None:
        s["snapshot_seq"] = [sa.seq, sb.seq]
        s["window_ts_cycles"] = [sa.ts_cycles, sb.ts_cycles]
    elif sb is not None:
        s["snapshot_seq"] = sb.seq
        s["ts_cycles"] = sb.ts_cycles
    if extra:
        s.update(extra)
    return s


def M(name, value, unit, kind, src, group, derivation=None, note=None):
    return dict(name=name, value=value, unit=unit, kind=kind, group=group, source=src,
                derivation=derivation, note=note)


def window_metrics(ctx, sa, sb, gauges=None, profile=DEFAULT_PROFILE, energy_model=None):
    """All metrics for the window between snapshots sa and sb."""
    out = []
    d = {n: (sb.counters[n] - sa.counters[n]) & ((1 << 64) - 1) for n in sa.counters}
    cyc = d["CYCLES"]
    hz = ctx.get("tel_clk_hz") or 0

    def reg(n):
        return f"SNAP_CNT[{S.EV[n]}]({n})"
    for e in S.EVENTS:
        n = e["name"]
        out.append(M(n.lower(), d[n], e["unit"], "counter", _src(ctx, [reg(n)], sa, sb), e["group"],
                     derivation=f"SNAP_CNT[{S.EV[n]}]@seq{sb.seq} - @seq{sa.seq}",
                     note="OVERFLOW flag set" if sb.overflow.get(n) else None))

    def rate(n, unit, group, scale=1.0, label=None):
        if cyc == 0:
            return
        nm = label or (n.lower() + "_per_cycle")
        out.append(M(nm, d[n] * scale / cyc, unit, "derived",
                     _src(ctx, [reg(n), reg("CYCLES")], sa, sb), group,
                     derivation=f"delta({n}) / delta(CYCLES)"))
        if hz:
            out.append(M(nm.replace("_per_cycle", "_per_second"), d[n] * scale / cyc * hz,
                         unit.replace("/cycle", "/s"), "derived",
                         _src(ctx, [reg(n), reg("CYCLES"), "TEL_CLK_HZ"], sa, sb), group,
                         derivation=f"delta({n}) / delta(CYCLES) * TEL_CLK_HZ",
                         note="seconds derived from the firmware-configured nominal clock "
                              "TEL_CLK_HZ, not measured"))
    for n, u, g in [("DMA_RD_BYTES", "bytes/cycle", "dma"), ("DMA_WR_BYTES", "bytes/cycle", "dma"),
                    ("NET_TX_BYTES", "bytes/cycle", "network"),
                    ("PKT_ACCEPTED", "packets/cycle", "network"),
                    ("PKT_FORWARDED", "packets/cycle", "network"),
                    ("PKT_DROPPED", "packets/cycle", "network"),
                    ("TENSOR_OPS", "ops/cycle", "compute"), ("VECTOR_OPS", "ops/cycle", "compute"),
                    ("MEM_RD_BYTES", "bytes/cycle", "memory"), ("MEM_WR_BYTES", "bytes/cycle", "memory"),
                    ("MIGRATION_BYTES", "bytes/cycle", "memory"),
                    ("CMD_COMPLETED", "commands/cycle", "core")]:
        rate(n, u, g)
    if cyc:
        def frac(name, num, den_n, group, deriv, note=None, den=None):
            den_v = den if den is not None else d[den_n]
            if den_v:
                regs = [reg(x) for x in num] + ([reg(den_n)] if den_n else [])
                out.append(M(name, sum(d[x] for x in num) / den_v, "fraction", "derived",
                             _src(ctx, regs, sa, sb), group, derivation=deriv, note=note))
        frac("tensor_busy_fraction", ["COMPUTE_BUSY_CYCLES"], "CYCLES", "compute",
             "delta(COMPUTE_BUSY_CYCLES)/delta(CYCLES)")
        frac("tensor_stall_fraction_of_busy", ["COMPUTE_STALL_CYCLES"], "COMPUTE_BUSY_CYCLES",
             "compute", "delta(COMPUTE_STALL_CYCLES)/delta(COMPUTE_BUSY_CYCLES)")
        frac("dma_stall_fraction", ["DMA_STALL_CYCLES"], "CYCLES", "dma",
             "delta(DMA_STALL_CYCLES)/delta(CYCLES)")
        frac("net_mean_queue_occupancy", ["NET_QOCC_ACCUM"], "CYCLES", "network",
             "delta(NET_QOCC_ACCUM)/delta(CYCLES)  (time-average occupancy, entries)")
        if d["PKT_ACCEPTED"] + d["PKT_DROPPED"]:
            out.append(M("net_drop_ratio", d["PKT_DROPPED"] / (d["PKT_ACCEPTED"] + d["PKT_DROPPED"]),
                         "fraction", "derived",
                         _src(ctx, [reg("PKT_DROPPED"), reg("PKT_ACCEPTED")], sa, sb), "network",
                         derivation="dropped / (accepted + dropped)"))
        frac("sram_conflicts_per_kcycle", ["SRAM_BANK_CONFLICTS"], "CYCLES", "memory",
             "1000*delta(SRAM_BANK_CONFLICTS)/delta(CYCLES)", den=cyc / 1000.0)
        if d["STO_CMDS"]:
            frac("storage_error_ratio", ["STO_ERRORS"], "STO_CMDS", "storage",
                 "delta(STO_ERRORS)/delta(STO_CMDS)")
        frac("core_clock_enable_duty", ["CORE_CLK_EN_CYCLES"], "CYCLES", "power",
             "delta(CORE_CLK_EN_CYCLES)/delta(CYCLES)",
             note="fraction of telemetry cycles with the core clock enabled")
        if hz:
            out.append(M("effective_core_clock_hz", d["CORE_CLK_EN_CYCLES"] / cyc * hz, "Hz",
                         "derived", _src(ctx, [reg("CORE_CLK_EN_CYCLES"), reg("CYCLES"),
                                               "TEL_CLK_HZ"], sa, sb), "power",
                         derivation="duty * TEL_CLK_HZ",
                         note="assumes core clock = telemetry clock gated by core_clk_en; "
                              "TEL_CLK_HZ is nominal (firmware-configured)"))
        for i in range(4):
            frac(f"pstate{i}_residency", [f"PSTATE{i}_CYCLES"], "CYCLES", "power",
                 f"delta(PSTATE{i}_CYCLES)/delta(CYCLES)")
        for key, n in (("dma_rd_bytes_per_cycle", "DMA_RD_BYTES"),
                       ("dma_wr_bytes_per_cycle", "DMA_WR_BYTES")):
            cap = profile.get(key)
            if cap:
                out.append(M(n.lower() + "_utilisation", d[n] / (cyc * cap), "fraction", "derived",
                             _src(ctx, [reg(n), reg("CYCLES")], sa, sb,
                                  extra={"profile": profile["name"]}), "dma",
                             derivation=f"delta({n}) / (delta(CYCLES) * {cap} B/cycle)",
                             note=profile["assumption"]))
    if energy_model:
        tot = 0.0
        terms = []
        for n, pj in energy_model["pj_per_event"].items():
            tot += pj * d[n]
            terms.append(f"{pj}pJ*{n}")
        out.append(M("energy_estimate", tot * 1e-12, "J", "estimate",
                     _src(ctx, [reg(n) for n in energy_model["pj_per_event"]], sa, sb,
                          extra={"energy_model": energy_model.get("name"),
                                 "calibrated": bool(energy_model.get("calibrated"))}),
                     "power", derivation=" + ".join(terms),
                     note="ACTIVITY-BASED ESTIMATE" + ("" if energy_model.get("calibrated")
                                                      else " with UNCALIBRATED coefficients")
                          + "; not a power measurement"))
    return out


def domain_metrics(ctx, sa, sb):
    out = []
    if not sb.dom_counters:
        return out
    for dmn in range(S.NUM_DOM):
        for j, e in enumerate(S.DOM_EVENTS):
            n = e["name"]
            v = (sb.dom_counters[dmn][n] - sa.dom_counters[dmn][n]) & ((1 << 64) - 1)
            g = (sb.counters[e["global_event"]] - sa.counters[e["global_event"]]) & ((1 << 64) - 1)
            out.append(dict(domain=dmn, event=n, value=v, unit=e["unit"],
                            share=(v / g) if g else None, global_event=e["global_event"],
                            source=_src(ctx, [f"DOM_SNAP[{dmn}][{j}]({n})",
                                              f"SNAP_CNT[{S.EV[e['global_event']]}]"], sa, sb),
                            kind="counter"))
    return out


def gauge_metrics(ctx, g, at_snapshot):
    src = _src(ctx, [], None, at_snapshot)
    out = [
        M("temp_last_code", g["temp_last_code"] if g["temp_seen"] else None, "raw sensor code",
          "gauge", dict(src, registers=["TEMP_LAST"]), "thermal",
          note="raw code; conversion to degC needs the sensor's per-part calibration"),
        M("temp_min_code", g["temp_min_code"] if g["temp_seen"] else None, "raw sensor code",
          "gauge", dict(src, registers=["TEMP_MINMAX"]), "thermal"),
        M("temp_max_code", g["temp_max_code"] if g["temp_seen"] else None, "raw sensor code",
          "gauge", dict(src, registers=["TEMP_MINMAX"]), "thermal"),
        M("temp_warn_threshold_code", g["temp_warn_thresh"], "raw sensor code", "gauge",
          dict(src, registers=["TEMP_WARN_THRESH"]), "thermal"),
        M("pstate_current", g["pstate"], "state", "gauge", dict(src, registers=["PWR_STATUS"]),
          "power"),
        M("net_queue_occupancy_max", g["qocc_max"], "entries", "gauge",
          dict(src, registers=["QOCC_MAX"]), "network"),
    ]
    if g["pwr_sensor_present"] and g["pwr_samples"]:
        out.append(M("power_sensor_mean_code", g["pwr_sum_code"] / g["pwr_samples"], "raw sensor code",
                     "measured_raw", dict(src, registers=["PWR_MEAS_SUM", "PWR_MEAS_SAMPLES"]),
                     "power", derivation="PWR_MEAS_SUM / PWR_MEAS_SAMPLES",
                     note="MEASURED path (power sensor input)"
                          + ("; in simulation the sensor input is synthetic stimulus"
                             if ctx["origin"] == "simulation" else "")))
        out.append(M("power_sensor_samples", g["pwr_samples"], "samples", "measured_raw",
                     dict(src, registers=["PWR_MEAS_SAMPLES"]), "power"))
    else:
        out.append(M("power_sensor_mean_code", None, "raw sensor code", "measured_raw",
                     dict(src, registers=["PWR_STATUS", "PWR_MEAS_SAMPLES"]), "power",
                     note="no power sensor present or no samples: nothing measured"))
    return out


TS_SERIES = ["DMA_RD_BYTES", "DMA_WR_BYTES", "NET_TX_BYTES", "PKT_ACCEPTED", "PKT_FORWARDED",
             "PKT_DROPPED", "TENSOR_OPS", "COMPUTE_BUSY_CYCLES", "COMPUTE_STALL_CYCLES",
             "MEM_RD_BYTES", "MEM_WR_BYTES", "SRAM_BANK_CONFLICTS", "NET_QOCC_ACCUM",
             "CMD_COMPLETED", "DMA_STALL_CYCLES", "STO_CMDS", "STO_READS_DONE", "STO_WRITES_DONE",
             "RAS_ECC_CORR", "CORE_CLK_EN_CYCLES", "PSTATE0_CYCLES", "PSTATE1_CYCLES",
             "PSTATE2_CYCLES", "PSTATE3_CYCLES"]


def timeseries(snaps, gauges_at):
    rows = []
    for i in range(1, len(snaps)):
        a, b = snaps[i - 1], snaps[i]
        cyc = b.counters["CYCLES"] - a.counters["CYCLES"]
        if cyc <= 0:
            continue
        row = dict(t_cycles=b.ts_cycles, window_cycles=cyc, snapshot_seq=b.seq)
        for n in TS_SERIES:
            row[n.lower() + "_per_cycle"] = (b.counters[n] - a.counters[n]) / cyc
        for dmn in range(S.NUM_DOM):
            for n in ("D_DMA_RD_BYTES", "D_TENSOR_OPS", "D_NET_TX_BYTES"):
                if b.dom_counters:
                    row[f"d{dmn}_{n.lower()}_per_cycle"] = \
                        (b.dom_counters[dmn][n] - a.dom_counters[dmn][n]) / cyc
        g = gauges_at.get(b.seq)
        if g:
            row["temp_code"] = g["temp_last_code"] if g["temp_seen"] else None
            row["pstate"] = g["pstate"]
        rows.append(row)
    return rows


def snap_to_dict(s):
    return dict(seq=s.seq, ts_cycles=s.ts_cycles, counters=s.counters,
                dom_counters={str(k): v for k, v in s.dom_counters.items()},
                overflow=[k for k, v in s.overflow.items() if v],
                host_ns_before=s.host_ns_before, host_ns_after=s.host_ns_after,
                device_cycle_after=s.device_cycle_after, retries=s.retries)


# ======================================================================= experiment
def run_experiment(name, backend="verilator", seed=69, cycles=60000, snap_every=2500,
                   out_dir=None, tel_clk_hz=250_000_000, energy_model=None, workdir=None,
                   deterministic=False):
    from . import workload
    from .backends.sim import ModelBackend, VerilatorBackend, write_workload
    vecs, truth, meta = workload.generate(name, seed=seed, cycles=cycles)
    # Idle tail that keeps static board straps (sensor-present) driven while the
    # collector performs its final reads after the workload has finished.
    TAIL = 20000
    strap = vecs[-1].get("pwr_sensor_present", 0)
    vecs = vecs + [dict(pwr_sensor_present=strap, thermal_fault_n=1) for _ in range(TAIL)]
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    workdir = workdir or os.path.join(root, "build", "experiments")   # scratch, regenerable
    os.makedirs(workdir, exist_ok=True)
    if backend == "verilator":
        wp = os.path.join(workdir, f"{name}_s{seed}.workload")
        write_workload(wp, [dict(S.IDLE, **v) for v in vecs])
        b = VerilatorBackend(wp, label=name)
    elif backend == "model":
        b = ModelBackend([dict(S.IDLE, **v) for v in vecs], label=name)
    else:
        raise ValueError(backend)
    t_wall0 = time.time()
    dev = TelemetryDevice(b)
    caps = dev.identify()
    dev.configure(trace=True, sample=meta["sample"], tel_clk_hz=tel_clk_hz,
                  temp_warn=meta.get("temp_warn"), errlog_mask=meta.get("errlog_mask"))
    ctx = dict(b.describe(), tel_clk_hz=dev.rd(S.A["TEL_CLK_HZ"]))
    snaps, gauges_at, records, errlog = [], {}, [], []
    s0 = dev.snapshot()
    snaps.append(s0)
    gauges_at[s0.seq] = dev.gauges()
    next_snap = (b.now_cycles() or 0) + snap_every
    while True:
        rem = b.workload_remaining()
        got = dev.drain_trace(limit=6)
        records += got
        errlog += dev.drain_errlog()
        if (b.now_cycles() or 0) >= next_snap:
            s = dev.snapshot()
            snaps.append(s)
            gauges_at[s.seq] = dev.gauges()
            next_snap += snap_every
        if rem <= TAIL:
            break
        if not got:
            b.step(min(40, rem - TAIL))
    records += dev.drain_trace()
    errlog += dev.drain_errlog()
    sf = dev.snapshot()
    snaps.append(sf)
    gf = dev.gauges()
    gauges_at[sf.seq] = gf
    hist = dev.histogram()
    status = dev.status()
    proto = dev.trace_proto()
    first = dev.first_error()
    t_wall1 = time.time()
    rep = build_report(name, meta, ctx, caps, snaps, gauges_at, records, errlog, hist, status,
                       proto, first, energy_model=energy_model)
    rep["collection"] = dict(apb_reads=getattr(b, "n_reads", None),
                             apb_writes=getattr(b, "n_writes", None),
                             device_cycles=b.now_cycles(),
                             host_wall_seconds=None if deterministic else round(t_wall1 - t_wall0, 3))
    rep["verification"] = verify_against_truth(rep, truth, snaps, records, errlog, hist, gf)
    b.close()
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
        with open(os.path.join(out_dir, f"{name}.json"), "w") as f:
            json.dump(rep, f, indent=1, default=str)
    return rep


def build_report(name, meta, ctx, caps, snaps, gauges_at, records, errlog, hist, status, proto,
                 first, energy_model=None):
    s0, sf = snaps[0], snaps[-1]
    gf = gauges_at[sf.seq]
    metrics = window_metrics(ctx, s0, sf, energy_model=energy_model)
    metrics += gauge_metrics(ctx, gf, sf)
    e2e = [r["deltas"]["COMPLETE"] for r in records
           if "COMPLETE" in r["deltas"] and not r["delta_saturated"]]
    lat = dict(
        clock="telemetry clock cycles (convert with TEL_CLK_HZ only if configured)",
        traced=L.summarize(e2e),
        traced_note=f"from {len(records)} completion records of SELECTED transactions "
                    f"(1-in-{meta['sample']} sampling); quantiles are observed values",
        stages=L.stage_breakdown(records),
        histogram=L.hist_bounds(hist),
        ordering=L.validate_ordering(records),
        trace_records_counter=sf.counters["TRACE_RECORDS"] - s0.counters["TRACE_RECORDS"],
        trace_drops_counter=sf.counters["TRACE_DROPS"] - s0.counters["TRACE_DROPS"],
        protocol=proto,
        per_domain={d: L.summarize([r["deltas"]["COMPLETE"] for r in records
                                    if r["domain"] == d and "COMPLETE" in r["deltas"]])
                    for d in range(S.NUM_DOM)},
        source=dict(origin=ctx["origin"], backend=ctx["backend"],
                    registers=["TRACE_HEAD0..9", "HIST_BIN0..15", "HIST_SAMPLES", "HIST_MAX",
                               "HIST_SUM"]),
        samples=[dict(seq=r["seq"], tag=r["tag"], domain=r["domain"],
                      arrival_ts=r["arrival_ts"], deltas=r["deltas"]) for r in records],
    )
    ras_names = [e["name"] for e in S.EVENTS if e["group"] == "ras"] + ["STO_INTEGRITY_FAIL",
                                                                     "ERRLOG_DROPS"]
    ras = dict(counters={n: sf.counters[n] - s0.counters[n] for n in ras_names},
               errlog=errlog, first_error=first,
               source=dict(origin=ctx["origin"], backend=ctx["backend"],
                           registers=["SNAP_CNT", "ERRLOG_HEAD*", "FIRST_ERR_*"]))
    return dict(
        report_format="sftel-report/1",
        experiment=dict(name=name, description=meta["description"], seed=meta["seed"],
                        workload_cycles=meta["workload_cycles"], sample=meta["sample"],
                        generated_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())),
        data_origin=ctx["origin"],
        disclaimer=("SIMULATION: synthetic workload driven into the CloudTelemetry RTL. "
                    "Values are telemetry derived from simulated hardware events; they are NOT "
                    "production or silicon measurements.") if ctx["origin"] == "simulation"
        else "HARDWARE: values read from a physical device.",
        backend=ctx, device=caps,
        clock=dict(timebase="telemetry clk cycles since reset", tel_clk_hz=ctx.get("tel_clk_hz"),
                   tel_clk_hz_source="TEL_CLK_HZ register (firmware-configured nominal; not measured)",
                   host_time="host monotonic ns recorded per snapshot, never mixed with device cycles"),
        window=dict(first_snapshot=s0.seq, last_snapshot=sf.seq, ts_cycles=[s0.ts_cycles, sf.ts_cycles],
                    cycles_counted=sf.counters["CYCLES"] - s0.counters["CYCLES"]),
        status=status,
        metrics=metrics,
        domains=domain_metrics(ctx, s0, sf),
        timeseries=timeseries(snaps, gauges_at),
        latency=lat,
        ras=ras,
        snapshots=[snap_to_dict(s) for s in snaps],
    )


def verify_against_truth(rep, truth, snaps, records, errlog, hist, gauges):
    """Independent check: telemetry vs the workload generator's ground truth."""
    s0, sf = snaps[0], snaps[-1]
    checks = []

    def chk(name, got, exp):
        checks.append(dict(check=name, telemetry=got, ground_truth=exp, ok=(got == exp)))
    for n, v in sorted(truth["totals"].items()):
        if n.startswith("_"):
            continue
        chk(f"total {n}", sf.counters[n] - s0.counters[n], v)
    for n in S.EV:
        if n not in truth["totals"] and n not in ("CYCLES", "TEL_ACCESS_DENIED", "TRACE_RECORDS",
                                                  "TRACE_DROPS", "ERRLOG_DROPS", "PSTATE0_CYCLES"):
            chk(f"total {n} (no activity generated)", sf.counters[n] - s0.counters[n], 0)
    for d, c in truth["domains"].items():
        for n in S.DEV:
            chk(f"domain {d} {n}", sf.dom_counters[int(d)][n] - s0.dom_counters[int(d)][n], c.get(n, 0))
    # every drained record against the generator's stage times
    by_key = {(c["tag"], c["times"]["ARRIVE"]): c for c in truth["commands"]}
    bad = 0
    for r in records:
        c = by_key.get((r["tag"], r["arrival_ts"]))
        if c is None:
            bad += 1
            continue
        for st, dv in r["deltas"].items():
            if dv != c["times"][st] - c["times"]["ARRIVE"]:
                bad += 1
                break
        if r["domain"] != c["domain"]:
            bad += 1
    chk("trace records matching ground-truth stage times", len(records) - bad, len(records))
    chk("histogram samples == completed commands", hist["samples"], len(truth["commands"]))
    exp_bins = [0] * S.P["HIST_BINS"]
    for c in truth["commands"]:
        lat = c["times"]["COMPLETE"] - c["times"]["ARRIVE"]
        b = 0
        for k in range(1, S.P["HIST_BINS"]):
            if lat >= (1 << k):
                b = k
        exp_bins[b] += 1
    chk("histogram bins", hist["bins"], exp_bins)
    chk("histogram max", hist["max"], max((c["times"]["COMPLETE"] - c["times"]["ARRIVE"]
                                           for c in truth["commands"]), default=0))
    if "_ERRLOG" in truth["totals"]:
        chk("error-log source bits", sum(bin(e["bitmap"]).count("1") for e in errlog),
            truth["totals"]["_ERRLOG"])
    if "_PWR_SAMPLES" in truth["totals"]:
        chk("power sensor samples", gauges["pwr_samples"], truth["totals"]["_PWR_SAMPLES"])
        chk("power sensor sum", gauges["pwr_sum_code"], truth["totals"]["_PWR_SUM"])
    # exact quantiles of the traced subset recomputed from ground truth
    traced_truth = sorted(by_key[(r["tag"], r["arrival_ts"])]["times"]["COMPLETE"] -
                          r["arrival_ts"] for r in records if (r["tag"], r["arrival_ts"]) in by_key)
    for q, p in L.QUANTILES:
        chk(f"traced {q}", rep["latency"]["traced"][q], L.nearest_rank(traced_truth, p))
    n_ok = sum(c["ok"] for c in checks)
    return dict(passed=n_ok == len(checks), n_checks=len(checks), n_passed=n_ok,
                failures=[c for c in checks if not c["ok"]], checks=checks,
                method="final-minus-initial snapshot counters, drained trace records, histogram "
                       "and sensor accumulators compared with totals accumulated by the "
                       "synthetic workload generator while it produced the stimulus")
