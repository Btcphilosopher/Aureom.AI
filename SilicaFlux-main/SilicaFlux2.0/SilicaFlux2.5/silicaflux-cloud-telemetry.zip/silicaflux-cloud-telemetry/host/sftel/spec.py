"""Runtime access to the generated telemetry spec (single source of truth)."""
import json
import os

_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "telemetry_spec.json")

with open(_PATH) as _f:
    SPEC = json.load(_f)

P = SPEC["params"]
EVENTS = SPEC["events"]
DOM_EVENTS = SPEC["dom_events"]
NUM_EV = len(EVENTS)
NUM_DEV = len(DOM_EVENTS)
NUM_DOM = P["NUM_DOM"]
NUM_DCNT = NUM_DEV * NUM_DOM
STAGES = SPEC["stages"]
EV = {e["name"]: i for i, e in enumerate(EVENTS)}
DEV = {e["name"]: i for i, e in enumerate(DOM_EVENTS)}
REGS = {r["name"]: r for r in SPEC["regs"]}
REG_BY_OFF = {r["offset"]: r for r in SPEC["regs"]}
A = {r["name"]: r["offset"] for r in SPEC["regs"]}
W = {w["name"]: w for w in SPEC["windows"]}
RW_MASKS = SPEC["rw_masks"]
CMD = {n: 1 << i for i, n in enumerate(SPEC["cmd_bits"])}
IRQ = {n: 1 << i for i, n in enumerate(SPEC["irq_bits"])}
ES = {n: 1 << i for i, n in enumerate(SPEC["errlog_srcs"])}
CTRL = {n: (lsb, w) for n, lsb, w in SPEC["ctrl_fields"]}
WORKLOAD_FIELDS = [tuple(f) for f in SPEC["workload_fields"]]
APB_FIELDS = [tuple(f) for f in SPEC["apb_fields"]]
WF_NAMES = [f[0] for f in WORKLOAD_FIELDS]
ALL_FIELDS = WORKLOAD_FIELDS + APB_FIELDS
IDLE = {n: v for n, _, v in ALL_FIELDS}
WIDTH = {n: w for n, w, _ in ALL_FIELDS}


def live_addr(i):
    return W["LIVE_CNT"]["base"] + 8 * i


def snap_addr(i):
    return W["SNAP_CNT"]["base"] + 8 * i


def dsnap_addr(d, e):
    return W["DOM_SNAP"]["base"] + 0x100 * d + 8 * e


def dlive_addr(d, e):
    return W["DOM_LIVE"]["base"] + 0x100 * d + 8 * e


def ctrl_value(**kw):
    v = 0
    for k, val in kw.items():
        lsb, w = CTRL[k.upper()]
        v |= (int(val) & ((1 << w) - 1)) << lsb
    return v


def pack(values, width):
    """Pack a list of lane values into a flattened packed-array integer."""
    v = 0
    for i, x in enumerate(values):
        assert 0 <= x < (1 << width), (x, width)
        v |= x << (i * width)
    return v


def unpack(v, width, n):
    m = (1 << width) - 1
    return [(v >> (i * width)) & m for i in range(n)]
