class Backend:
    origin = "unknown"

    def read32(self, addr, priv=1, user=0):
        raise NotImplementedError

    def write32(self, addr, data, priv=1, user=0):
        raise NotImplementedError

    def step(self, n):
        raise NotImplementedError

    def now_cycles(self):
        return None

    def workload_remaining(self):
        return 0

    def describe(self):
        return {"origin": self.origin, "backend": type(self).__name__}

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
