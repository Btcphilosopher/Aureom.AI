"""MMIO backends for the CloudTelemetry register interface.

Every backend implements:
    read32(addr, priv=1, user=0) -> (data, slverr)
    write32(addr, data, priv=1, user=0) -> slverr
    step(n)              advance device time (simulation) / wait (hardware)
    now_cycles()         device timebase if cheaply known (simulation) else None
    describe()           dict describing data origin, used for provenance

`origin` is "simulation" for the Verilator RTL and reference-model backends
and "hardware" only for a real device reached through PCIe sysfs.
"""
from .base import Backend  # noqa: F401
