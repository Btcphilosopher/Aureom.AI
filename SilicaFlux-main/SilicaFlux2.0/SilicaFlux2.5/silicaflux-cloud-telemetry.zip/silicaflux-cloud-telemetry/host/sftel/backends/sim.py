"""Simulation backends: Verilator RTL harness and the Python reference model.

Both present identical cycle semantics: an APB read or write occupies two
device clock cycles (setup + access) during which workload vectors keep being
applied, exactly like the RTL harness.  Running the same collector session on
both must therefore produce bit-identical register traffic.
"""
import os
import subprocess

from .. import spec as S
from ..refmodel import TelemetryModel
from .base import Backend

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
HARNESS = os.path.join(ROOT, "build", "vl_harness", "sftel_harness")


def build_harness(force=False):
    if os.path.exists(HARNESS) and not force:
        return HARNESS
    files = os.path.join(ROOT, "rtl", "files.f")
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)   # verilator won't create parents
    cmd = (f"cd {ROOT} && verilator --cc --exe --build -j 4 -O3 -Wno-fatal -Wno-UNUSEDPARAM "
           f"--top-module silicaflux_cloud_telemetry -Irtl -f {files} {ROOT}/sim/harness.cpp "
           f"-CFLAGS -I{ROOT}/sim --Mdir build/vl_harness -o sftel_harness")
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(HARNESS):
        raise RuntimeError("harness build failed:\n" + r.stderr[-3000:])
    return HARNESS


def write_workload(path, vectors):
    """RLE workload file (workload fields only) for the harness."""
    from ..stim import write_stim
    return write_stim(path, vectors, fields=S.WORKLOAD_FIELDS)


class VerilatorBackend(Backend):
    origin = "simulation"

    def __init__(self, workload_path=None, label=None):
        exe = build_harness()
        args = [exe] + ([f"+WORKLOAD={workload_path}"] if workload_path else [])
        self.p = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True,
                                  bufsize=1)
        self.cycle = 0
        self.remaining = 0
        self.label = label
        self.workload_path = workload_path
        self.n_reads = self.n_writes = 0

    def _cmd(self, s):
        self.p.stdin.write(s + "\n")
        self.p.stdin.flush()
        return self.p.stdout.readline().split()

    def read32(self, addr, priv=1, user=0):
        r = self._cmd(f"R {addr:x} {priv:x} {user:x}")
        assert r[0] == "D", r
        self.cycle = int(r[3], 16)
        self.n_reads += 1
        return int(r[1], 16), int(r[2], 16)

    def write32(self, addr, data, priv=1, user=0):
        r = self._cmd(f"W {addr:x} {data & 0xFFFFFFFF:x} {priv:x} {user:x}")
        assert r[0] == "K", r
        self.cycle = int(r[2], 16)
        self.n_writes += 1
        return int(r[1], 16)

    def step(self, n):
        if n <= 0:
            return
        r = self._cmd(f"S {n:x}")
        self.cycle = int(r[2], 16)

    def now_cycles(self):
        return self.cycle

    def poll(self):
        r = self._cmd("T")
        self.cycle = int(r[1], 16)
        self.remaining = int(r[3], 16)
        return dict(cycle=self.cycle, irq=int(r[2], 16), workload_remaining=self.remaining)

    def workload_remaining(self):
        return self.poll()["workload_remaining"]

    def describe(self):
        return {"origin": "simulation", "backend": "verilator-rtl",
                "rtl_top": "silicaflux_cloud_telemetry", "harness": os.path.relpath(HARNESS, ROOT),
                "workload": os.path.basename(self.workload_path) if self.workload_path else None,
                "note": "RTL simulated with Verilator; APB reads take 2 device cycles "
                        "(no PCIe/host latency modelled)"}

    def close(self):
        if self.p and self.p.poll() is None:
            try:
                self.p.stdin.write("Q\n")
                self.p.stdin.flush()
            except BrokenPipeError:
                pass
            self.p.wait(timeout=10)


class ModelBackend(Backend):
    """Reference-model backend with the same cycle semantics as the harness."""
    origin = "simulation"

    def __init__(self, vectors=None, label=None):
        self.m = TelemetryModel()
        self.wl = list(vectors or [])
        self.k = 0
        self.cycle = 0
        self.label = label
        self.n_reads = self.n_writes = 0

    def _vec(self, apb=None):
        base = dict(self.wl[self.k]) if self.k < len(self.wl) else dict(S.IDLE)
        for n, _, idle in S.APB_FIELDS:
            base[n] = idle
        if apb:
            base.update(apb)
        self.k += 1
        return base

    def _txn(self, write, addr, data, priv, user):
        a = dict(psel=1, penable=0, pwrite=write, paddr=addr, pwdata=data, pprot=priv, pauser=user)
        self.m.step(self._vec(a))
        a["penable"] = 1
        res = self.m.step(self._vec(a))
        self.cycle += 2
        return res

    def read32(self, addr, priv=1, user=0):
        self.n_reads += 1
        return self._txn(0, addr, 0, priv, user)

    def write32(self, addr, data, priv=1, user=0):
        self.n_writes += 1
        return self._txn(1, addr, data & 0xFFFFFFFF, priv, user)[1]

    def step(self, n):
        for _ in range(n):
            self.m.step(self._vec())
        self.cycle += max(0, n)

    def now_cycles(self):
        return self.cycle

    def workload_remaining(self):
        return max(0, len(self.wl) - self.k)

    def describe(self):
        return {"origin": "simulation", "backend": "python-reference-model",
                "note": "cycle-accurate specification model (not RTL)"}
