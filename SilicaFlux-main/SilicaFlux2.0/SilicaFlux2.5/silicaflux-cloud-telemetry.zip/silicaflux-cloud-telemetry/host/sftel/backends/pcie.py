"""PCIe sysfs discovery and BAR MMIO backend (for real hardware).

No SilicaFlux silicon or FPGA board exists in this repository, so this
backend is exercised in tests only against a synthetic sysfs tree and a plain
file standing in for a BAR.  The PCI vendor/device IDs below are UNASSIGNED
PLACEHOLDERS and must be replaced with the IDs programmed into the real
device's configuration space.

Privilege: on real hardware the APB PPROT/PAUSER sideband is driven by the
PCIe-to-APB bridge from the requesting function (PF = privileged, VF n =
tenant n).  A host process mapping the PF BAR is therefore privileged; the
`priv`/`user` arguments are accepted for interface compatibility but cannot
be chosen by software.
"""
import glob
import mmap
import os
import struct
import time

from .base import Backend

PLACEHOLDER_VENDOR = 0xFFFF   # NOT a real allocation - configure per device
PLACEHOLDER_DEVICE = 0x0069
TELEMETRY_BAR = 0
TELEMETRY_BAR_OFFSET = 0x0     # offset of the telemetry block inside the BAR


def discover(sysfs_root="/sys/bus/pci/devices", vendor=PLACEHOLDER_VENDOR,
             device=PLACEHOLDER_DEVICE):
    """Return a list of dicts for PCI functions matching vendor/device."""
    found = []
    for d in sorted(glob.glob(os.path.join(sysfs_root, "*"))):
        try:
            with open(os.path.join(d, "vendor")) as f:
                v = int(f.read().strip(), 16)
            with open(os.path.join(d, "device")) as f:
                dv = int(f.read().strip(), 16)
        except (OSError, ValueError):
            continue
        if v == vendor and dv == device:
            res = os.path.join(d, f"resource{TELEMETRY_BAR}")
            found.append(dict(bdf=os.path.basename(d), sysfs=d, vendor=v, device=dv,
                              bar=res, bar_present=os.path.exists(res)))
    return found


class PcieBackend(Backend):
    origin = "hardware"

    def __init__(self, bar_path, offset=TELEMETRY_BAR_OFFSET, size=0x4000, bdf=None):
        self.fd = os.open(bar_path, os.O_RDWR | os.O_SYNC)
        self.size = size
        self.mm = mmap.mmap(self.fd, offset + size, mmap.MAP_SHARED,
                            mmap.PROT_READ | mmap.PROT_WRITE)
        self.base = offset
        self.bdf = bdf
        self.bar_path = bar_path

    def read32(self, addr, priv=1, user=0):
        # PCIe MMIO cannot return PSLVERR in-band; the bridge typically returns
        # all-ones on error.  Report slverr as unknown (0) and let the caller
        # validate (ID check, sequence numbers).
        o = self.base + addr
        return struct.unpack_from("<I", self.mm, o)[0], 0

    def write32(self, addr, data, priv=1, user=0):
        struct.pack_into("<I", self.mm, self.base + addr, data & 0xFFFFFFFF)
        return 0

    def step(self, n):
        # Device time advances on its own; sleep a token amount.
        time.sleep(0)

    def describe(self):
        return {"origin": "hardware", "backend": "pcie-sysfs", "bdf": self.bdf,
                "bar": self.bar_path}

    def close(self):
        try:
            self.mm.close()
        finally:
            os.close(self.fd)
