"""Human-readable diagnostic summary of a report."""


def _m(rep, name):
    for m in rep["metrics"]:
        if m["name"] == name:
            return m
    return None


def _v(rep, name, fmt="{:.4g}"):
    m = _m(rep, name)
    if m is None or m["value"] is None:
        return "n/a"
    return fmt.format(m["value"]) if isinstance(m["value"], float) else str(m["value"])


def diagnostic_summary(rep):
    L = []
    e = rep["experiment"]
    L.append(f"SilicaFlux CloudTelemetry - {e['name']}  (seed {e['seed']})")
    L.append(f"  DATA ORIGIN: {rep['data_origin'].upper()} via {rep['backend'].get('backend')}")
    L.append(f"  {rep['disclaimer']}")
    w = rep["window"]
    L.append(f"  window: snapshots {w['first_snapshot']}..{w['last_snapshot']}, "
             f"{w['cycles_counted']} counted cycles; clock "
             f"{rep['clock']['tel_clk_hz'] or 'unknown'} Hz ({rep['clock']['tel_clk_hz_source']})")
    L.append("")
    L.append("  throughput (per telemetry cycle):")
    for n in ("dma_rd_bytes_per_cycle", "dma_wr_bytes_per_cycle", "net_tx_bytes_per_cycle",
              "pkt_forwarded_per_cycle", "tensor_ops_per_cycle", "cmd_completed_per_cycle"):
        L.append(f"    {n:32s} {_v(rep, n)}")
    L.append("  utilisation / ratios:")
    for n in ("tensor_busy_fraction", "tensor_stall_fraction_of_busy", "dma_stall_fraction",
              "dma_rd_bytes_utilisation", "net_drop_ratio", "net_mean_queue_occupancy",
              "core_clock_enable_duty", "storage_error_ratio"):
        L.append(f"    {n:32s} {_v(rep, n)}")
    lat = rep["latency"]["traced"]
    L.append(f"  end-to-end latency (cycles, {lat['n']} traced records, nearest-rank):")
    for q in ("p50", "p95", "p99", "p999"):
        flag = "  [INSUFFICIENT SAMPLES: need >= %d]" % lat[q + "_min_samples"] \
            if lat[q + "_insufficient"] else ""
        L.append(f"    {q:6s} {lat[q]}{flag}")
    L.append(f"    max    {lat['max']}")
    h = rep["latency"]["histogram"]
    if h["n"]:
        L.append(f"  histogram (all {h['n']} completions, log2 bounds): "
                 + ", ".join(f"{q}=[{h[q]['lower']},{h[q]['upper'] or 'inf'})"
                             for q in ("p50", "p99", "p999") if h.get(q)))
    o = rep["latency"]["ordering"]
    L.append(f"  trace integrity: order violations={o['order_violations']} seq gaps={o['seq_gaps']} "
             f"drops(counter)={rep['latency']['trace_drops_counter']} "
             f"orphans={rep['latency']['protocol']['orphan_marks']} "
             f"tag reuse={rep['latency']['protocol']['tag_reuse']}")
    r = rep["ras"]
    nz = {k: v for k, v in r["counters"].items() if v}
    L.append(f"  RAS: {nz if nz else 'no events'}; error-log records={len(r['errlog'])}")
    if r["first_error"]:
        fe = r["first_error"]
        L.append(f"       first error at cycle {fe['ts_cycles']}: {fe['sources']} info=0x{fe['info']:04x}")
    L.append("  power/thermal:")
    for n in ("temp_last_code", "temp_max_code", "thermal_warn_events", "pwr_state_transitions",
              "pstate0_residency", "pstate1_residency", "pstate2_residency", "pstate3_residency",
              "power_sensor_mean_code", "energy_estimate"):
        m = _m(rep, n)
        if m:
            tag = {"measured_raw": " [MEASURED path, raw code]", "estimate": " [ESTIMATE]"}.get(m["kind"], "")
            L.append(f"    {n:32s} {_v(rep, n)}{tag}")
    ov = [k for s in rep["snapshots"][-1:] for k in s["overflow"]]
    if ov:
        L.append(f"  WARNING: counter overflow flags set: {ov}")
    if "verification" in rep:
        v = rep["verification"]
        L.append(f"  ground-truth verification: {v['n_passed']}/{v['n_checks']} checks "
                 f"{'PASSED' if v['passed'] else 'FAILED'}")
        for f in v["failures"][:10]:
            L.append(f"    FAIL {f['check']}: telemetry={f['telemetry']} truth={f['ground_truth']}")
    return "\n".join(L)
