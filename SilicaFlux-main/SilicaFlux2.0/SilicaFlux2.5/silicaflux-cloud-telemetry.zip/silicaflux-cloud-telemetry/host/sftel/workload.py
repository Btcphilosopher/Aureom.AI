"""Synthetic experiment workloads with ground truth.

These workloads are SYNTHETIC: a small discrete-event model of a CloudDPU
(command front-end, 2 DMA read + 2 DMA write lanes, one TensorCore, 4 packet
lanes with egress queues, storage, sensors).  They exist to drive the RTL
telemetry engine with realistic-looking, *known* activity.  The generator
accumulates ground truth at the semantic level (bytes moved, ops retired,
stage times of every command) while it writes the per-cycle input vectors,
so the telemetry collected through the RTL can be checked exactly against it.

Nothing produced from these workloads is production data.
"""
import math
import random
from collections import Counter

from . import spec as S
from .spec import P

TAGS = 1 << P["TAG_W"]
START = 3000          # first workload cycle (leaves time for configuration)


class Gen:
    def __init__(self, n, seed):
        self.n = n
        self.rng = random.Random(seed)
        self.c = [dict() for _ in range(n)]
        self.truth = Counter()
        self.dtruth = {d: Counter() for d in range(S.NUM_DOM)}
        self.cmds = []
        self.used = set()          # (cycle, stage)
        self.pulse_used = {}       # field -> set(cycles)

    # ---- vector helpers -------------------------------------------------
    def lane(self, k, field, lane, width, value):
        cur = self.c[k].get(field, 0)
        m = ((1 << width) - 1) << (lane * width)
        assert cur & m == 0, (k, field, lane)
        self.c[k][field] = cur | (value << (lane * width))

    def put(self, k, **f):
        self.c[k].update(f)

    def add(self, k, field, v, maxv):
        nv = self.c[k].get(field, 0) + v
        assert nv <= maxv, (k, field, nv)
        self.c[k][field] = nv

    def pulse(self, k, field):
        """Single-bit strobe, at most one per cycle: shift to next free cycle."""
        used = self.pulse_used.setdefault(field, set())
        while k in used:
            k += 1
        used.add(k)
        if k < self.n:
            self.c[k][field] = 1
        return k

    def mark(self, k, stage, tag, dom=None):
        s = S.STAGES.index(stage)
        while (k, s) in self.used:
            k += 1
        self.used.add((k, s))
        d = self.c[k]
        d["mk_valid"] = d.get("mk_valid", 0) | (1 << s)
        d["mk_tag"] = d.get("mk_tag", 0) | (tag << (s * P["TAG_W"]))
        if dom is not None:
            d["mk_arr_dom"] = dom
        return k

    def t(self, ev, v=1, dom=None, dev=None):
        self.truth[ev] += v
        if dom is not None and dev is not None:
            self.dtruth[dom][dev] += v


def _commands(g, end, rate, weights, size_rng, compute_scale, load_fn=None):
    """Command lifecycle: ARRIVE -> DISPATCH -> DMA read -> compute -> DMA write -> COMPLETE."""
    rng = g.rng
    tag_free_at = [0] * TAGS
    rd_lane_free = [0] * P["DL"]
    wr_lane_free = [0] * P["DL"]
    tensor_free = 0
    disp_free = 0
    k = START
    stall_cycles = set()
    while True:
        r = rate * (load_fn(k) if load_fn else 1.0)
        k += max(1, int(rng.expovariate(r))) if r > 0 else 50
        if k >= end:
            break
        # tag allocation (front-end back-pressure if none free)
        tag = min(range(TAGS), key=lambda t: tag_free_at[t])
        arr = max(k, tag_free_at[tag] + 1)
        dom = rng.choices(range(S.NUM_DOM), weights=weights)[0]
        arr = g.mark(arr, "ARRIVE", tag, dom)
        disp = g.mark(max(arr + rng.randrange(0, 3), disp_free), "DISPATCH", tag)
        disp_free = disp + 2
        nbytes = size_rng()
        # DMA read on least-busy lane
        lane = min(range(P["DL"]), key=lambda l: rd_lane_free[l])
        want = disp + rng.randrange(1, 4)
        ds = max(want, rd_lane_free[lane])
        for c in range(want, ds):
            stall_cycles.add(c)
        ds = g.mark(ds, "DMA_START", tag)
        beats = math.ceil(nbytes / 64)
        rem = nbytes
        for b in range(beats):
            kk = ds + b
            x = min(64, rem)
            rem -= x
            if kk < g.n:
                g.lane(kk, "dma_rd_bytes", lane, 8, x)
                g.lane(kk, "dma_rd_dom", lane, 2, dom)
                g.add(kk, "mem_wr_bytes", x, 255)
            g.t("DMA_RD_BYTES", x, dom, "D_DMA_RD_BYTES")
            g.t("MEM_WR_BYTES", x)
        rd_lane_free[lane] = ds + beats
        dd = g.mark(ds + beats - 1 + 1, "DMA_DONE", tag)
        # compute on the single TensorCore
        cs = g.mark(max(dd + rng.randrange(1, 4), tensor_free), "COMP_START", tag)
        ncyc = max(4, int(nbytes * compute_scale / 512))
        kk = cs
        done = 0
        while done < ncyc:
            if kk < g.n:
                stall = rng.random() < 0.08
                g.put(kk, cmp_busy=1, cmp_dom=dom)
                g.t("COMPUTE_BUSY_CYCLES", 1, dom, "D_COMPUTE_BUSY_CYCLES")
                if stall:
                    g.put(kk, cmp_stall=1)
                    g.t("COMPUTE_STALL_CYCLES")
                else:
                    ops = [rng.choice([96, 128, 128, 160]) for _ in range(P["TL"])]
                    g.put(kk, cmp_tensor_ops=S.pack(ops, 8), mem_rd_bytes=192)
                    g.t("TENSOR_OPS", sum(ops), dom, "D_TENSOR_OPS")
                    g.t("MEM_RD_BYTES", 192)
                    nconf = rng.choice([0, 0, 0, 1, 1, 2])
                    banks = rng.sample(range(P["SB"]), nconf)
                    g.put(kk, sram_conflict=sum(1 << b for b in banks))
                    g.t("SRAM_BANK_CONFLICTS", nconf)
                    if rng.random() < 0.2:
                        vo = [rng.randrange(1, 64) for _ in range(P["VL"])]
                        g.put(kk, cmp_vector_ops=S.pack(vo, 8))
                        g.t("VECTOR_OPS", sum(vo))
                    done += 1
            else:
                done += 1
            kk += 1
        tensor_free = kk
        cd = g.mark(kk, "COMP_DONE", tag)
        if cd < g.n:
            g.put(cd, cmp_kernel_done=1)
            g.t("KERNELS_COMPLETED")
        # DMA write of results
        wbytes = max(64, nbytes // 4)
        wl = min(range(P["DL"]), key=lambda l: wr_lane_free[l])
        ws = max(cd + 1, wr_lane_free[wl])
        beats = math.ceil(wbytes / 64)
        rem = wbytes
        for b in range(beats):
            kk = ws + b
            x = min(64, rem)
            rem -= x
            if kk < g.n:
                g.lane(kk, "dma_wr_bytes", wl, 8, x)
                g.lane(kk, "dma_wr_dom", wl, 2, dom)
            g.t("DMA_WR_BYTES", x, dom, "D_DMA_WR_BYTES")
        wr_lane_free[wl] = ws + beats
        comp = g.mark(ws + beats, "COMPLETE", tag)
        tag_free_at[tag] = comp
        times = dict(ARRIVE=arr, DISPATCH=disp, DMA_START=ds, DMA_DONE=dd, COMP_START=cs,
                     COMP_DONE=cd, COMPLETE=comp)
        g.cmds.append(dict(tag=tag, domain=dom, times=times, bytes=nbytes))
        g.t("CMD_ARRIVED", 1, dom, "D_CMD_ARRIVED")
        g.t("CMD_COMPLETED", 1, dom, "D_CMD_COMPLETED")
    for c in stall_cycles:
        if c < g.n:
            g.put(c, dma_stall=1)
    g.truth["DMA_STALL_CYCLES"] += sum(1 for c in stall_cycles if c < g.n)


def _packets(g, end, p_arrive, weights, qcap=24, p_serve=0.6, load_fn=None):
    rng = g.rng
    q = [[] for _ in range(P["PL"])]
    for k in range(START, end):
        occ_total = 0
        load = load_fn(k) if load_fn else 1.0
        for l in range(P["PL"]):
            if rng.random() < p_arrive * load:
                dom = rng.choices(range(S.NUM_DOM), weights=weights)[0]
                size = rng.randrange(64, 256)
                if len(q[l]) < qcap:
                    q[l].append((dom, size))
                    g.lane(k, "net_pkt_accept", l, 1, 1)
                    g.t("PKT_ACCEPTED")
                else:
                    g.lane(k, "net_pkt_drop", l, 1, 1)
                    g.t("PKT_DROPPED")
            if q[l] and rng.random() < p_serve:
                dom, size = q[l].pop(0)
                g.lane(k, "net_pkt_fwd", l, 1, 1)
                g.lane(k, "net_tx_bytes", l, 8, size)
                g.lane(k, "net_lane_dom", l, 2, dom)
                g.t("PKT_FORWARDED", 1, dom, "D_PKT_FORWARDED")
                g.t("NET_TX_BYTES", size, dom, "D_NET_TX_BYTES")
            occ_total += len(q[l])
        if occ_total:
            g.put(k, net_q_occ=occ_total)
            g.t("NET_QOCC_ACCUM", occ_total)


def _storage_security(g, end, sto_rate=1 / 180, err_p=0.02):
    rng = g.rng
    k = START
    while True:
        k += max(1, int(rng.expovariate(sto_rate)))
        if k >= end - 400:
            break
        k = g.pulse(k, "sto_cmd")
        g.t("STO_CMDS")
        done = k + rng.randrange(40, 160)
        if rng.random() < 0.6:
            d = g.pulse(done, "sto_rd_done")
            g.t("STO_READS_DONE")
        else:
            d = g.pulse(done, "sto_wr_done")
            g.t("STO_WRITES_DONE")
        if rng.random() < err_p:
            g.pulse(d, "sto_err")
            g.t("STO_ERRORS")
    for _ in range(max(1, (end - START) // 25000)):
        g.pulse(rng.randrange(START, end), "sec_auth_fail")
        g.t("SEC_AUTH_FAIL")
    for _ in range(max(1, (end - START) // 30000)):
        g.pulse(rng.randrange(START, end), "sec_invalid_cmd")
        g.t("SEC_INVALID_CMD")
    # page migration bursts
    for _ in range(max(1, (end - START) // 15000)):
        s0 = rng.randrange(START, end - 64)
        for kk in range(s0, s0 + 32):
            g.put(kk, mig_bytes=128)
            g.t("MIGRATION_BYTES", 128)


def _power_thermal(g, end, phases, temp_amb=820, temp_gain=0.8, sensor=True):
    """P-state phases [(start, state)], clock-enable duty, simulated sensors."""
    duty = {0: 1.0, 1: 0.75, 2: 0.5, 3: 0.25}
    temp = float(temp_amb)
    prev = 0
    for k in range(START, end):
        st = [s for c, s in phases if c <= k][-1]
        if st:
            g.put(k, pwr_state=st)
            g.t(f"PSTATE{st}_CYCLES")
        if st != prev:
            g.t("PWR_STATE_TRANSITIONS")
        prev = st
        en = (k % 4) < int(duty[st] * 4)
        if en:
            g.put(k, core_clk_en=1)
            g.t("CORE_CLK_EN_CYCLES")
        act = 1.0 if g.c[k].get("cmp_busy") else 0.0
        temp += (temp_amb + temp_gain * 600 * act * duty[st] - temp) * 0.002
        if k % 256 == 0:
            g.put(k, temp_valid=1, temp_code=int(temp))
            g.t("TEMP_SAMPLES")
        if sensor:
            if k % 512 == 0:
                code = int(3000 + 9000 * act * duty[st] + g.rng.randrange(0, 200))
                g.put(k, pwr_meas_valid=1, pwr_meas_code=code)
                g.truth["_PWR_SAMPLES"] += 1
                g.truth["_PWR_SUM"] += code
    if prev != 0:
        g.t("PWR_STATE_TRANSITIONS")   # back to P0 when the workload ends
    if sensor:                          # static board strap: present for the whole run
        for k in range(g.n):
            g.c[k]["pwr_sensor_present"] = 1


def _thermal_warn_truth(g, thresh):
    above = False
    n = 0
    for k in range(g.n):
        if g.c[k].get("temp_valid"):
            a = g.c[k]["temp_code"] >= thresh
            if a and not above:
                n += 1
            above = a
    g.truth["THERMAL_WARN_EVENTS"] = n


def _faults(g, schedule):
    for k, kind, info in schedule:
        if kind == "thermal_pin":
            for kk in range(k, k + 40):
                g.put(kk, thermal_fault_n=0)
            g.t("RAS_THERMAL_FAULT")
            g.truth["_ERRLOG"] += 1
            continue
        k = g.pulse(k, kind)
        g.put(k, ras_info=info)
        if kind == "ras_ecc_corr":
            g.c[k]["ras_ecc_corr"] = 0b0101
            g.t("RAS_ECC_CORR", 2)
            continue
        ev = {"ras_ecc_uncorr": "RAS_ECC_UNCORR", "ras_dma_fail": "RAS_DMA_FAIL",
              "ras_ctrl_reset": "RAS_CTRL_RESET", "ras_watchdog": "RAS_WATCHDOG",
              "ras_fatal": "RAS_FATAL", "sto_integ_fail": "STO_INTEGRITY_FAIL"}[kind]
        g.t(ev)
        g.truth["_ERRLOG"] += 1


SCENARIOS = {}


def scenario(name, desc):
    def deco(fn):
        SCENARIOS[name] = (fn, desc)
        return fn
    return deco


@scenario("baseline_p1", "Phase-1 event set only: cycles, DMA bytes, packets, command completions")
def _baseline(seed, cycles):
    end = START + cycles
    g = Gen(end + 2000, seed)
    _commands(g, end, 1 / 60, [1, 1, 1, 1], lambda: g.rng.choice([512, 1024, 2048]), 0.0001)
    # strip compute-side activity so only phase-1 events are exercised
    for k in range(g.n):
        for f in ("cmp_busy", "cmp_stall", "cmp_tensor_ops", "cmp_vector_ops", "mem_rd_bytes",
                  "sram_conflict", "cmp_kernel_done", "cmp_dom", "mem_wr_bytes", "dma_stall"):
            g.c[k].pop(f, None)
    for ev in ("COMPUTE_BUSY_CYCLES", "COMPUTE_STALL_CYCLES", "TENSOR_OPS", "VECTOR_OPS",
               "MEM_RD_BYTES", "SRAM_BANK_CONFLICTS", "KERNELS_COMPLETED", "MEM_WR_BYTES",
               "DMA_STALL_CYCLES"):
        g.truth.pop(ev, None)
    for d in g.dtruth.values():
        d.pop("D_TENSOR_OPS", None)
        d.pop("D_COMPUTE_BUSY_CYCLES", None)
    _packets(g, end, 0.25, [1, 1, 1, 1])
    return g, dict(sample=1, temp_warn=0xFFF, phases=None)


@scenario("mixed_tenants", "Four tenant domains with unequal load: commands, DMA, TensorCore, packets, storage")
def _mixed(seed, cycles):
    end = START + cycles
    g = Gen(end + 3000, seed)
    w = [5, 3, 1.5, 0.5]

    def load(k):
        x = (k - START) / cycles
        return 0.6 + 0.8 * math.sin(math.pi * x) ** 2
    _commands(g, end, 1 / 45, w, lambda: g.rng.choice([256, 512, 1024, 2048, 4096]), 6.0, load)
    _packets(g, end, 0.30, w, qcap=8, p_serve=0.5, load_fn=load)
    _storage_security(g, end)
    ph = [(0, 0), (START, 1), (START + cycles // 5, 0), (START + 4 * cycles // 5, 2), (end, 0)]
    _power_thermal(g, end, ph)
    _thermal_warn_truth(g, 900)
    return g, dict(sample=2, temp_warn=900, phases=ph)


@scenario("ras_fault_injection", "Moderate load with scheduled RAS faults (ECC, DMA failure, watchdog, thermal pin, fatal)")
def _ras(seed, cycles):
    end = START + cycles
    g = Gen(end + 3000, seed)
    _commands(g, end, 1 / 70, [2, 2, 1, 1], lambda: g.rng.choice([512, 1024]), 4.0)
    _packets(g, end, 0.15, [1, 1, 1, 1])
    _storage_security(g, end, err_p=0.05)
    rng = g.rng
    sched = []
    for i in range(12):
        sched.append((START + rng.randrange(cycles), "ras_ecc_corr", 0xC000 + i))
    sched += [(START + cycles // 6, "ras_ecc_uncorr", 0xE001),
              (START + cycles // 4, "ras_dma_fail", 0xD001),
              (START + cycles // 3, "thermal_pin", 0),
              (START + cycles // 2, "ras_watchdog", 0x0D06),
              (START + cycles // 2 + 500, "ras_ctrl_reset", 0x0C01),
              (START + 2 * cycles // 3, "sto_integ_fail", 0x5101),
              (START + 3 * cycles // 4, "ras_dma_fail", 0xD002),
              (START + 5 * cycles // 6, "thermal_pin", 0),
              (START + cycles - 2000, "ras_fatal", 0xFA7A)]
    _faults(g, sched)
    ph = [(0, 0), (START, 0), (end, 0)]
    _power_thermal(g, end, ph)
    _thermal_warn_truth(g, 0xFFF)
    return g, dict(sample=1, temp_warn=0xFFF, phases=ph, errlog_mask=0x7F)


@scenario("thermal_power", "Compute-heavy bursts driving the simulated thermal model across the warning threshold; P-state phases")
def _thermal(seed, cycles):
    end = START + cycles
    g = Gen(end + 3000, seed)

    def load(k):
        return 1.6 if ((k - START) // 8000) % 2 == 0 else 0.2
    _commands(g, end, 1 / 40, [1, 1, 1, 1], lambda: g.rng.choice([2048, 4096]), 5.0, load)
    _packets(g, end, 0.05, [1, 1, 1, 1])
    q = cycles // 6
    ph = [(0, 0), (START, 0), (START + q, 1), (START + 2 * q, 0), (START + 3 * q, 2),
          (START + 4 * q, 3), (START + 5 * q, 0), (end, 0)]
    _power_thermal(g, end, ph, temp_gain=0.9)
    _thermal_warn_truth(g, 1100)
    return g, dict(sample=4, temp_warn=1100, phases=ph)


def generate(name, seed=69, cycles=60000):
    fn, desc = SCENARIOS[name]
    g, meta = fn(seed, cycles)
    for k in range(g.n):
        if "thermal_fault_n" not in g.c[k]:
            g.c[k]["thermal_fault_n"] = 1
    meta.update(name=name, description=desc, seed=seed, workload_cycles=cycles,
                start_cycle=START, total_vectors=g.n)
    truth = dict(totals=dict(g.truth), domains={d: dict(c) for d, c in g.dtruth.items()},
                 commands=g.cmds)
    return g.c, truth, meta
