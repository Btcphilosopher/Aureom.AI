"""Latency statistics from OBSERVED trace data only.

Quantiles use the nearest-rank definition on the sorted sample:
    q_p = x[ceil(p * n) - 1]
so every reported quantile is an actually observed latency.  A quantile is
flagged `insufficient` when n < 1/(1-p) (e.g. fewer than 1000 samples for
P99.9): with that few samples the tail quantile degenerates to the maximum.

The hardware histogram covers ALL completed commands (not only traced ones)
but has log2 buckets, so from it we can only report the bucket that contains
a quantile, i.e. a [lower, upper) bound with up to 2x uncertainty.
"""
import math

from . import spec as S

QUANTILES = [("p50", 0.50), ("p95", 0.95), ("p99", 0.99), ("p999", 0.999)]


def nearest_rank(sorted_x, p):
    n = len(sorted_x)
    if n == 0:
        return None
    r = max(1, math.ceil(p * n))
    return sorted_x[r - 1]


def summarize(samples, unit="cycles"):
    xs = sorted(samples)
    n = len(xs)
    out = dict(n=n, unit=unit, method="nearest-rank on observed samples",
               min=xs[0] if n else None, max=xs[-1] if n else None,
               mean=(sum(xs) / n) if n else None)
    for name, p in QUANTILES:
        need = math.ceil(1 / (1 - p) - 1e-9)
        out[name] = nearest_rank(xs, p)
        out[name + "_insufficient"] = n < need
        out[name + "_min_samples"] = need
    return out


STAGE_SEGMENTS = [
    ("queue (arrive->dispatch)", None, "DISPATCH"),
    ("dispatch->dma_start", "DISPATCH", "DMA_START"),
    ("dma read (start->done)", "DMA_START", "DMA_DONE"),
    ("dma_done->compute_start", "DMA_DONE", "COMP_START"),
    ("compute (start->done)", "COMP_START", "COMP_DONE"),
    ("compute_done->complete", "COMP_DONE", "COMPLETE"),
    ("end-to-end (arrive->complete)", None, "COMPLETE"),
]


def stage_breakdown(records):
    segs = {}
    for name, a, b in STAGE_SEGMENTS:
        xs = []
        for r in records:
            d = r["deltas"]
            if b not in d or (a is not None and a not in d):
                continue
            if r["delta_saturated"]:
                continue
            xs.append(d[b] - (d[a] if a else 0))
        segs[name] = summarize(xs)
    return segs


def validate_ordering(records):
    """Stage deltas must be non-decreasing in stage order for every record."""
    viol = []
    for r in records:
        prev = 0
        for st in S.STAGES[1:]:
            if st in r["deltas"]:
                if r["deltas"][st] < prev:
                    viol.append(dict(seq=r["seq"], tag=r["tag"], stage=st))
                    break
                prev = r["deltas"][st]
    seqs = [r["seq"] for r in records]
    gaps = sum(b - a - 1 for a, b in zip(seqs, seqs[1:]) if b > a + 1)
    nonmono = sum(1 for a, b in zip(seqs, seqs[1:]) if b <= a)
    return dict(records=len(records), order_violations=len(viol), violations=viol[:20],
                seq_gaps=gaps, seq_non_monotonic=nonmono,
                duplicate_stage_flags=sum(r["duplicate_stage"] for r in records),
                saturated_flags=sum(r["delta_saturated"] for r in records))


def hist_bounds(hist):
    """Quantile bounds from the all-population log2 histogram."""
    bins = hist["bins"]
    n = sum(bins)
    edges = [(0, 2)] + [(1 << b, 1 << (b + 1)) for b in range(1, len(bins) - 1)] + \
        [(1 << (len(bins) - 1), None)]
    out = dict(n=n, method="log2-bucket containing nearest-rank position (all completions)",
               limitation="bucket resolution only: true quantile lies in [lower, upper); "
                          "upper bucket is open-ended", max=hist["max"],
               mean=(hist["sum"] / hist["samples"]) if hist["samples"] else None,
               bins=[dict(lower=lo, upper=hi, count=c) for (lo, hi), c in zip(edges, bins)])
    for name, p in QUANTILES:
        if n == 0:
            out[name] = None
            continue
        r = max(1, math.ceil(p * n))
        acc = 0
        for (lo, hi), c in zip(edges, bins):
            acc += c
            if acc >= r:
                out[name] = dict(lower=lo, upper=hi)
                break
    return out
