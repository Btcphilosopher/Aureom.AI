// SilicaFlux CloudTelemetry - interactive Verilator harness.
//
// Runs the RTL (silicaflux_cloud_telemetry) and plays a workload file into
// the event inputs, one vector per clock, while a host process (the Python
// collector) performs APB reads/writes through a line protocol on
// stdin/stdout.  Time does not stop while the host reads: workload vectors
// keep being applied during every APB setup/access cycle.
//
// Protocol (hex numbers, one command per line):
//   R <addr> <prot> <user>          -> D <data> <pslverr> <cycle>
//   W <addr> <data> <prot> <user>   -> K <pslverr> <cycle>
//   S <n>                           -> K 0 <cycle>        (n idle-APB cycles)
//   T                               -> T <cycle> <irq> <workload_remaining>
//   Q                               -> exits
// <cycle> = number of rising edges since reset release.
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

#include "Vsilicaflux_cloud_telemetry.h"
#include "verilated.h"
#include "sf_tel_stim_layout.h"

static Vsilicaflux_cloud_telemetry* top;
static std::vector<SfTelVec> wl;
static size_t wl_i = 0;
static uint64_t wl_rep_left = 0;
static uint64_t cycle = 0;
static uint64_t wl_total = 0, wl_done = 0;

static void apply_next_workload() {
  SfTelVec v;
  if (wl_i < wl.size()) {
    if (wl_rep_left == 0) wl_rep_left = wl[wl_i].rep;
    v = wl[wl_i];
    wl_rep_left--;
    wl_done++;
    if (wl_rep_left == 0) wl_i++;
  } else {
    sf_tel_idle(v);
  }
  sf_tel_apply(top, v);
}

static void set_apb(int psel, int pen, int pwr, uint32_t addr, uint32_t data, int prot, int user) {
  top->psel = psel; top->penable = pen; top->pwrite = pwr;
  top->paddr = addr; top->pwdata = data; top->pprot = prot; top->pauser = user;
}

// One clock: inputs already applied while clk=0; evaluate, rising edge, fall.
static void tick() {
  top->eval();
  top->clk = 1; top->eval();
  cycle++;
  top->clk = 0; top->eval();
}

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  top = new Vsilicaflux_cloud_telemetry;
  const char* wpath = nullptr;
  for (int i = 1; i < argc; i++)
    if (!strncmp(argv[i], "+WORKLOAD=", 10)) wpath = argv[i] + 10;
  if (wpath) {
    FILE* f = fopen(wpath, "r");
    if (!f) { fprintf(stderr, "cannot open %s\n", wpath); return 2; }
    char* line = nullptr; size_t cap = 0;
    while (getline(&line, &cap, f) > 0) {
      SfTelVec v;
      if (sf_tel_parse(line, v)) { wl.push_back(v); wl_total += v.rep; }
    }
    free(line); fclose(f);
  }
  // reset: 3 cycles low, release while clk low (same as tb_player.sv)
  SfTelVec idle; sf_tel_idle(idle); sf_tel_apply(top, idle);
  set_apb(0, 0, 0, 0, 0, 0, 0);
  top->clk = 0; top->rst_n = 0; top->eval();
  for (int i = 0; i < 3; i++) { top->clk = 1; top->eval(); top->clk = 0; top->eval(); }
  top->rst_n = 1; top->eval();
  cycle = 0;

  char buf[256];
  setvbuf(stdout, nullptr, _IOFBF, 1 << 16);
  while (fgets(buf, sizeof buf, stdin)) {
    char c = buf[0];
    if (c == 'Q') break;
    if (c == 'R' || c == 'W') {
      unsigned addr = 0, data = 0, prot = 1, user = 0;
      if (c == 'R') sscanf(buf + 1, "%x %x %x", &addr, &prot, &user);
      else          sscanf(buf + 1, "%x %x %x %x", &addr, &data, &prot, &user);
      int w = (c == 'W');
      apply_next_workload(); set_apb(1, 0, w, addr, data, prot, user); tick();   // setup
      apply_next_workload(); set_apb(1, 1, w, addr, data, prot, user); top->eval();
      unsigned rd = top->prdata, err = top->pslverr;
      tick();                                                                    // access
      set_apb(0, 0, 0, 0, 0, 0, 0);
      if (w) printf("K %x %llx\n", err, (unsigned long long)cycle);
      else   printf("D %x %x %llx\n", rd, err, (unsigned long long)cycle);
    } else if (c == 'S') {
      unsigned long long n = strtoull(buf + 1, nullptr, 16);
      for (unsigned long long i = 0; i < n; i++) { apply_next_workload(); tick(); }
      printf("K 0 %llx\n", (unsigned long long)cycle);
    } else if (c == 'T') {
      top->eval();
      printf("T %llx %x %llx\n", (unsigned long long)cycle, (unsigned)top->irq,
             (unsigned long long)(wl_total - wl_done));
    } else {
      printf("? %s", buf);
    }
    fflush(stdout);
  }
  top->final();
  delete top;
  return 0;
}
