# SilicaFlux Project 69 — CloudTelemetry

**Aureom.AI | SilicaFlux-CLOUD** · Hardware performance, power and reliability monitoring for the SilicaFlux CloudDPU

```
Hardware events → Event collection → Counter banks → Snapshot logic → APB/MMIO → Host metrics collector → Dashboard
```

Primary RTL: [`rtl/silicaflux_cloud_telemetry.sv`](rtl/silicaflux_cloud_telemetry.sv)

## What is here

| Path | Contents |
|---|---|
| `spec/telemetry_spec.py` | **Single source of truth**: parameters, 47 global + 8 per-domain events, register map, stimulus layout |
| `tools/gen_all.py` | Generates the SV package, TB/C++ layouts, runtime JSON, register map, event catalogue |
| `rtl/` | `silicaflux_cloud_telemetry.sv` (top), `sf_tel_pkg` (event package), `sf_tel_event_collect` (lane summation + domain attribution), `sf_tel_counter_bank` (counters + atomic snapshot), `sf_tel_trace` + `sf_tel_hist` (latency tracing), `sf_tel_ras_log`, `sf_tel_gauges`, `sf_tel_regs` (APB, access policy, CSRs), `sf_tel_fifo`, `sf_tel_sync2` |
| `tb/tb_player.sv` | Simulator-agnostic vector-player testbench (Verilator + Icarus) |
| `host/sftel/refmodel.py` | Cycle-accurate reference (specification) model |
| `regress/` | Scenarios, regression runner, phase gating, mutation analysis |
| `sim/harness.cpp` | Interactive Verilator harness: the host collector talks to the real RTL |
| `host/sftel/` | Host collector: backends (Verilator, model, PCIe sysfs), driver, metrics with provenance, latency statistics, JSON/CSV/Prometheus export, CLI, dashboard builder, synthetic workloads with ground truth |
| `experiments/` | Four simulated experiments (JSON, CSV, Prometheus, text summaries) |
| `dashboard/index.html` | Self-contained SilicaFlux dashboard (open in a browser) |
| `docs/` | Architecture, register map, event catalogue, verification report, security/domains, clocks, host collector, audit, limitations |
| `results/` | Regression, mutation, coverage, lint, pytest and palette-validation outputs |

## Quick start

```
make all          # gen, lint, regress (Verilator+Icarus), CNT_WIDTH=32, assertions,
                  # mutations, pytest, experiments through the RTL, dashboard, reports
make regress      # RTL vs reference model + analytic checks
make experiments dashboard
```
Requirements: Python ≥ 3.10 with pytest, Verilator ≥ 5.0, Icarus Verilog ≥ 12, g++.

## Status (from the result files in this archive)

* **RTL regression**: 16/16 scenarios bit-exact against the reference model on **both** Verilator and Icarus, and all analytic checks pass. Phase-1 events (cycles, DMA bytes, packets, command completions) are verified first and gate the rest.
* **Event coverage**: 55/55 events (47 global + 8 domain) verified, including the maximum multi-lane per-cycle increment of every multi-unit event.
* **Mutation analysis**: 7/7 deliberate RTL bugs caught (OR-instead-of-sum lanes, non-atomic snapshot, missing overflow flag, tenant leak, 1-flop synchronizer, two domain-attribution bugs).
* **CNT_WIDTH=32** variant and **in-RTL assertions** pass.
* **Experiments**: four synthetic workloads run through the RTL. Every counter total, per-domain total, trace record, histogram bin and traced quantile **matches the workload generator's ground truth exactly**.
* **Host tests**: pytest suite passes. It includes RTL-vs-model collector equivalence (byte-identical reports).

See [`docs/VERIFICATION.md`](docs/VERIFICATION.md) for tables and the bugs testing found.

## What this is *not*

All data is simulation with synthetic workloads, and every report, export and dashboard view says so. No CloudDMA, PacketCore, TensorCore, storage, RAS, PowerClock or sensor RTL was present to integrate (see [`docs/AUDIT.md`](docs/AUDIT.md)). There are no silicon or FPGA measurements, no synthesis or timing numbers, and no formal proofs. Full list: [`docs/LIMITATIONS.md`](docs/LIMITATIONS.md).
