# Provenance of vendored CloudDMA

Copied byte-identically from `SilicaFlux-main/silicaflux-cloudruntime-0.1.0.zip`
(sha256 `b896ab1a8545ebf8aa950d025fba1b7ed20217fbcd7b61af67e4528a7290ef88`), paths
`silicaflux-cloudruntime-0.1.0/rtl/vendor/clouddpu-p61/rtl/{dpu/sfd_clouddma.sv,pkg/silicaflux_cloud_pkg.sv}`.
Nothing was edited (`sha256sum -c SHA256SUMS`). Used ONLY by tb/tb_clouddma_int.sv, to show that the real CloudDMA channel can
load and extract scratchpad data through the scratchpad's DMA port.
