# Provenance of vendored code

Everything below is copied **byte-identically** from the SilicaFlux MemoryCore package
(`SilicaFlux-main/silicaflux-memorycore-sram.zip`, sha256 `b6a9b5ed0adb51915a954f67e8a69e4915e2b515d15bb77d4797ca2398807771`).
Nothing was edited. `SHA256SUMS` lists the hashes; `sha256sum -c SHA256SUMS` re-checks them.

| file | role here |
|---|---|
| `rtl/sf_sram_defs.svh` | shared constants (`SF_ST_*` status codes, backend ids, `SF_CFG_FATAL`, `SF_CHK`) |
| `rtl/sf_sram_core.sv` | verified single-port synchronous SRAM with byte enables (behavioural backend) |
| `rtl/sf_sram_macro_wrapper.sv` | one port list over behavioural / FPGA-BRAM / ASIC-macro backends |
| `rtl/backends/sf_sram_fpga_bram.sv` | block-RAM inference template |
| `rtl/backends/sf_sram_asic_sky130.sv` | SKY130 OpenRAM macro tiling adapter (structural) |
| `sim_models/sky130_sram_standin.sv` | labelled stand-in model of the SKY130 macro (**not** a vendor model) |

Evidence carried with these modules in their own package: `sf_sram_core` / wrapper regression 52/52 cases (Verilator 5.020),
41/41 mutants killed (see that package's `docs/VERIFICATION.md`). That evidence is **inherited**, not re-derived here; this
package re-exercises the modules only through its own testbenches.
