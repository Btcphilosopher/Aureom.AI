// =============================================================================
// SilicaFlux VectorScratch :: tb_bench -- reproducible bandwidth / latency workloads
//
// One simulation = one DUT configuration running a FIXED list of workloads (deterministic xorshift, seed in SEED).  Each
// workload prints ONE line "BENCH,..." (parsed by sim/run_bench.py).  Every number comes from the design's own performance
// counters; the testbench independently counts cycles, requests and useful bytes and the two must agree (checked, `errors`).
//
// Vector port: requests are offered back-to-back (the source never idles, the consumer is always ready) except for the SERIAL
// workloads, where the next request is offered only after the previous response (isolated latency).
// DMA port (optional): a streaming agent offers one beat per cycle with probability DMA_DUTY percent, alternating write / read,
// walking its own region (the vector workloads use only regions 0..NRGN-2, the DMA region NRGN-1, owned by the DMA).
//
// "useful bytes" = popcount of the byte-enable mask of every vector request that reached memory.  Peak = VEC_BYTES per cycle
// (one request per cycle); the banks' own ceiling is NB * BANK_BYTES per cycle.  Nothing here measures silicon.
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"

module tb_bench #(
  parameter int VEC_BYTES    = 16,
  parameter int BANK_BYTES   = 4,
  parameter int NB           = 4,
  parameter int DEPTH        = 256,
  parameter int BANK_MAP     = 0,
  parameter int ALIGN_POLICY = 2,
  parameter int GS_EN        = 0,
  parameter int GS_ES        = 4,
  parameter int READ_LATENCY = 1,
  parameter int CQ_DEPTH     = 8,
  parameter int DMA_BYTES    = 16,
  parameter int ARB_POLICY   = 2,
  parameter int NRGN         = 4,
  parameter int NREQ         = 2000,
  parameter int SEED         = 32'hBE7C0001,
  parameter string NAME      = "bench"
);
  localparam int AW = 24, IDW = 8, IDXW = 32;
  localparam int VEC_W = VEC_BYTES * 8, DMA_W = DMA_BYTES * 8;
  localparam int CAP = NB * DEPTH * BANK_BYTES;
  localparam int RGN = CAP / NRGN;
  localparam int VSPAN = RGN * (NRGN - 1);                       // the vector workloads stay in regions 0 .. NRGN-2
  localparam int LANES = (GS_EN != 0) ? VEC_BYTES / GS_ES : 1;
  localparam int RGW = (NRGN > 1) ? $clog2(NRGN) : 1;
  localparam int CNT_W = 32, PC_N = `SF_PC_N;
  localparam int NPROG = 8192;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic                    v_req_valid = 1'b0, v_req_ready, v_req_we = 1'b0, v_rsp_valid, v_rsp_ready = 1'b1, v_rsp_we;
  logic [1:0]              v_req_mode = '0;
  logic [AW-1:0]           v_req_addr = '0, v_req_stride = '0;
  logic [LANES*IDXW-1:0]   v_req_idx = '0;
  logic [VEC_BYTES-1:0]    v_req_mask = '0;
  logic [VEC_W-1:0]        v_req_wdata = '0, v_rsp_rdata;
  logic [IDW-1:0]          v_req_id = '0, v_rsp_id;
  logic [2:0]              v_rsp_status;
  logic                    d_req_valid = 1'b0, d_req_ready, d_req_write = 1'b0, d_rsp_valid, d_rsp_ready = 1'b1, d_rsp_error;
  logic [AW-1:0]           d_req_addr = '0;
  logic [DMA_W-1:0]        d_req_wdata = '0, d_rsp_rdata;
  logic [DMA_BYTES-1:0]    d_req_wstrb = {DMA_BYTES{1'b1}};
  logic [2:0]              d_rsp_err_code;
  logic                    own_req_valid = 1'b0, own_req_ready, own_ack, own_err;
  logic [RGW-1:0]          own_req_rgn = '0;
  logic [1:0]              own_req_val = '0;
  logic [NRGN*2-1:0]       own_state;
  logic                    busy, err_sticky, err_port, perf_clear = 1'b0;
  logic [2:0]              err_code;
  logic [AW-1:0]           err_addr;
  logic [CNT_W-1:0]        err_cnt;
  logic [PC_N*CNT_W-1:0]   perf;
  logic [NB*CNT_W-1:0]     perf_bank_acc, perf_bank_conf;
  logic [1:0]              ev_rd, ev_wr, ev_cf;

  sf_vector_scratchpad #(.AW(AW), .IDW(IDW), .VEC_BYTES(VEC_BYTES), .BANK_BYTES(BANK_BYTES), .NB(NB), .DEPTH(DEPTH),
                         .BANK_MAP(BANK_MAP), .ALIGN_POLICY(ALIGN_POLICY), .GS_EN(GS_EN), .GS_ES(GS_ES), .IDXW(IDXW),
                         .READ_LATENCY(READ_LATENCY), .SIM_INIT(1), .CQ_DEPTH(CQ_DEPTH), .DMA_EN(1), .DMA_BYTES(DMA_BYTES),
                         .DMA_CQ_DEPTH(4), .ARB_POLICY(ARB_POLICY), .NRGN(NRGN), .OWN_RESET(`SF_VM_OWN_VEC), .PERF_EN(1), .CNT_W(CNT_W)) dut (
    .clk(clk), .rst_n(rst_n),
    .v_req_valid(v_req_valid), .v_req_ready(v_req_ready), .v_req_we(v_req_we), .v_req_mode(v_req_mode), .v_req_addr(v_req_addr),
    .v_req_stride(v_req_stride), .v_req_idx(v_req_idx), .v_req_mask(v_req_mask), .v_req_wdata(v_req_wdata), .v_req_id(v_req_id),
    .v_rsp_valid(v_rsp_valid), .v_rsp_ready(v_rsp_ready), .v_rsp_rdata(v_rsp_rdata), .v_rsp_id(v_rsp_id), .v_rsp_we(v_rsp_we),
    .v_rsp_status(v_rsp_status),
    .d_req_valid(d_req_valid), .d_req_ready(d_req_ready), .d_req_write(d_req_write), .d_req_addr(d_req_addr),
    .d_req_wdata(d_req_wdata), .d_req_wstrb(d_req_wstrb), .d_rsp_valid(d_rsp_valid), .d_rsp_ready(d_rsp_ready),
    .d_rsp_rdata(d_rsp_rdata), .d_rsp_error(d_rsp_error), .d_rsp_err_code(d_rsp_err_code),
    .own_req_valid(own_req_valid), .own_req_ready(own_req_ready), .own_req_rgn(own_req_rgn), .own_req_val(own_req_val),
    .own_ack_o(own_ack), .own_err_o(own_err), .own_state_o(own_state),
    .err_clear_i(1'b0), .busy_o(busy), .err_sticky_o(err_sticky), .err_code_o(err_code), .err_addr_o(err_addr),
    .err_port_o(err_port), .err_cnt_o(err_cnt),
    .perf_clear_i(perf_clear), .perf_o(perf), .perf_bank_acc_o(perf_bank_acc), .perf_bank_conf_o(perf_bank_conf),
    .ev_spm_read_o(ev_rd), .ev_spm_write_o(ev_wr), .ev_spm_conflict_o(ev_cf));

  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic int rndn(input int n);
    logic [31:0] r;
    r = rnd();
    return int'(r % 32'(n));
  endfunction

  // ---------------------------------------------------------------- program of the vector port
  logic              p_we   [NPROG];
  logic [1:0]        p_mode [NPROG];
  logic [AW-1:0]     p_addr [NPROG];
  logic [AW-1:0]     p_str  [NPROG];
  logic [LANES*IDXW-1:0] p_idx [NPROG];
  logic [VEC_BYTES-1:0]  p_mask [NPROG];
  int p_n = 0, p_ptr = 0;
  longint useful_exp = 0;
  int errs = 0;
  longint cycle = 0;
  always @(posedge clk) cycle <= cycle + 1;

  task automatic padd(input bit we, input int mode, input longint a, input longint stride, input logic [LANES*IDXW-1:0] ix, input logic [VEC_BYTES-1:0] m);
    int pc;
    p_we[p_n] = we; p_mode[p_n] = mode[1:0]; p_addr[p_n] = AW'(a); p_str[p_n] = AW'(stride); p_idx[p_n] = ix; p_mask[p_n] = m;
    pc = 0;
    for (int j = 0; j < VEC_BYTES; j++) pc += int'(m[j]);
    useful_exp += pc;
    p_n++;
  endtask
  function automatic logic [VEC_BYTES-1:0] full();
    return {VEC_BYTES{1'b1}};
  endfunction
  function automatic logic [VEC_BYTES-1:0] tailm(input int n);
    logic [VEC_BYTES-1:0] m;
    for (int j = 0; j < VEC_BYTES; j++) m[j] = (j < n);
    return m;
  endfunction

  // ---------------------------------------------------------------- driver (vector port) + DMA agent + response counters
  bit v_run = 0, d_run = 0, serial = 0;
  int dma_duty = 0;
  longint dma_addr_ptr = 0;
  int d_beats = 0, d_rsp_beats = 0, d_pending_out = 0;
  longint v_acc = 0, v_rsp = 0, t_first = 0, t_last = 0;
  bit v_offering = 0, d_offering = 0, started = 0;
  bit serial_wait = 0;
  bit starved = 0;
  always @(posedge clk) begin
    if (rst_n) begin
      if (v_rsp_valid && v_rsp_ready) begin v_rsp++; t_last = cycle; serial_wait = 0; end
      if (d_rsp_valid && d_rsp_ready) begin d_rsp_beats++; end
      if (v_req_valid && v_req_ready) begin
        if (!started) begin started = 1; t_first = cycle; end
        v_acc++; p_ptr++; v_offering = 0;
        if (serial) serial_wait = 1;
      end
      if (d_req_valid && d_req_ready) begin d_beats++; d_offering = 0; end
      // next cycle
      if (v_run && !v_offering && p_ptr < p_n && !serial_wait) begin
        v_req_valid <= 1'b1; v_req_we <= p_we[p_ptr]; v_req_mode <= p_mode[p_ptr]; v_req_addr <= p_addr[p_ptr];
        v_req_stride <= p_str[p_ptr]; v_req_idx <= p_idx[p_ptr]; v_req_mask <= p_mask[p_ptr];
        v_req_wdata <= {VEC_BYTES/4{rnd()}}; v_req_id <= IDW'(p_ptr);
        v_offering = 1;
      end else if (!v_offering) v_req_valid <= 1'b0;
      if (d_run && !d_offering && rndn(100) < dma_duty) begin
        d_req_valid <= 1'b1; d_req_write <= ((d_beats & 1) == 0); d_req_addr <= AW'(longint'(RGN) * (NRGN - 1) + (dma_addr_ptr % RGN));
        d_req_wdata <= {DMA_BYTES/4{rnd()}};
        dma_addr_ptr = dma_addr_ptr + DMA_BYTES;
        d_offering = 1;
      end else if (!d_offering) d_req_valid <= 1'b0;
    end
  end

  // ---------------------------------------------------------------- one measured workload
  task automatic measure(input string wl, input int duty, input bit ser);
    logic [PC_N*CNT_W-1:0] p;
    longint cyc, bytes_ld, bytes_st, rd_sum, rd_cnt, wr_sum, wr_cnt, wacc, bsum;
    int t;
    longint dbytes;
    // reset every counter and the driver
    perf_clear = 1'b1; @(posedge clk); #1 perf_clear = 1'b0; @(posedge clk);
    p_ptr = 0; v_acc = 0; v_rsp = 0; started = 0; d_beats = 0; d_rsp_beats = 0; dma_addr_ptr = 0; serial = ser; serial_wait = 0;
    dma_duty = duty;
    v_run = 1; d_run = (duty > 0);
    t = 0;
    // a workload that cannot finish within 20x its ideal time is STARVED (possible with a fixed-priority arbiter and a saturating
    // DMA): the run is cut and reported as such, with the number of requests completed
    while ((v_rsp < p_n) && t < p_n * 20 + 2000) begin @(posedge clk); t++; end
    starved = (v_rsp < p_n);
    v_run = 0; d_run = 0;
    repeat (12) @(posedge clk);
    p = perf;
    cyc = starved ? longint'(t) : (t_last - t_first + 1);
    bytes_ld = p[`SF_PC_V_BYTES_LD*CNT_W +: CNT_W]; bytes_st = p[`SF_PC_V_BYTES_ST*CNT_W +: CNT_W];
    rd_sum = p[`SF_PC_LAT_RD_SUM*CNT_W +: CNT_W]; rd_cnt = p[`SF_PC_LAT_RD_CNT*CNT_W +: CNT_W];
    wr_sum = p[`SF_PC_LAT_WR_SUM*CNT_W +: CNT_W]; wr_cnt = p[`SF_PC_LAT_WR_CNT*CNT_W +: CNT_W];
    wacc = p[`SF_PC_V_WORD_ACC*CNT_W +: CNT_W];
    bsum = 0;
    for (int b = 0; b < NB; b++) bsum += perf_bank_acc[b*CNT_W +: CNT_W];
    // internal consistency: counters vs the testbench's own accounting
    if (!starved && (v_acc != p_n || p[`SF_PC_V_REQ*CNT_W +: CNT_W] != p_n)) begin errs++; $display("  [FAIL] %s: request count", wl); end
    if (!starved && bytes_ld + bytes_st != useful_exp) begin errs++; $display("  [FAIL] %s: useful bytes %0d vs expected %0d", wl, bytes_ld + bytes_st, useful_exp); end
    if (p[`SF_PC_V_ERR*CNT_W +: CNT_W] != 0) begin errs++; $display("  [FAIL] %s: unexpected error responses", wl); end
    if (bsum != wacc + p[`SF_PC_D_WORD_ACC*CNT_W +: CNT_W]) begin errs++; $display("  [FAIL] %s: per-bank accesses %0d != vector+dma words %0d", wl, bsum, wacc + p[`SF_PC_D_WORD_ACC*CNT_W +: CNT_W]); end
    dbytes = (p[`SF_PC_D_BYTES_RD*CNT_W +: CNT_W]) + (p[`SF_PC_D_BYTES_WR*CNT_W +: CNT_W]);
    // BENCH,name,workload,dma_duty,vec_req,completed,cycles,useful_bytes,v_word_acc,conf_stall,arb_stall,align_xtra,split_req,rd_lat_sum,rd_cnt,wr_lat_sum,wr_cnt,
    //       starve,req_blocked,rsp_bp,dma_req,dma_bytes,dma_arb_stall,dma_blocked,bank_acc_total,dma_words,max_bank_acc
    begin
      longint mx;
      mx = 0;
      for (int b = 0; b < NB; b++) if (longint'(perf_bank_acc[b*CNT_W +: CNT_W]) > mx) mx = perf_bank_acc[b*CNT_W +: CNT_W];
      $display("BENCH,%s,%s,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
               NAME, wl, duty, p_n, v_rsp, cyc, bytes_ld + bytes_st, wacc, p[`SF_PC_V_STALL_CONF*CNT_W +: CNT_W], p[`SF_PC_V_STALL_ARB*CNT_W +: CNT_W],
               p[`SF_PC_V_ALIGN_XTRA*CNT_W +: CNT_W], p[`SF_PC_V_SPLIT_REQ*CNT_W +: CNT_W], rd_sum, rd_cnt, wr_sum, wr_cnt,
               p[`SF_PC_V_STARVE*CNT_W +: CNT_W], p[`SF_PC_V_REQ_BLOCKED*CNT_W +: CNT_W], p[`SF_PC_V_RSP_BP*CNT_W +: CNT_W],
               p[`SF_PC_D_REQ*CNT_W +: CNT_W], dbytes, p[`SF_PC_D_STALL_ARB*CNT_W +: CNT_W], p[`SF_PC_D_REQ_BLOCKED*CNT_W +: CNT_W],
               bsum, p[`SF_PC_D_WORD_ACC*CNT_W +: CNT_W], mx);
    end
  endtask

  task automatic reset_prog();
    p_n = 0; p_ptr = 0; useful_exp = 0;
  endtask

  // ---------------------------------------------------------------- workload generators (all inside VSPAN)
  localparam int U = (ALIGN_POLICY == 0) ? VEC_BYTES : ((ALIGN_POLICY == 1) ? BANK_BYTES : 1);
  longint a;
  logic [LANES*IDXW-1:0] ix;
  initial begin
    repeat (5) @(posedge clk);
    #2 rst_n = 1'b1;
    repeat (4) @(posedge clk);
    // the DMA owns the last region (used only by the DMA-contention runs; the vector never touches it)
    own_req_valid = 1'b1; own_req_rgn = RGW'(NRGN - 1); own_req_val = `SF_VM_OWN_DMA;
    @(posedge clk); #1 own_req_valid = 1'b0;
    repeat (8) @(posedge clk);

    // ===== aligned streams
    reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b0, 0, longint'((i * VEC_BYTES) % VSPAN), 0, '0, full());
    measure("seq_load_aligned", 0, 0);
    reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b1, 0, longint'((i * VEC_BYTES) % VSPAN), 0, '0, full());
    measure("seq_store_aligned", 0, 0);
    reset_prog(); for (int i = 0; i < NREQ; i++) begin padd(1'b0, 0, longint'((i * VEC_BYTES) % (VSPAN / 2)), 0, '0, full()); padd(1'b1, 0, longint'(VSPAN / 2 + (i * VEC_BYTES) % (VSPAN / 2)), 0, '0, full()); end
    measure("copy_aligned", 0, 0);
    reset_prog(); for (int i = 0; i < NREQ / 2; i++) begin
      padd(1'b0, 0, longint'((i * VEC_BYTES) % (VSPAN / 3)), 0, '0, full());
      padd(1'b0, 0, longint'(VSPAN / 3 + (i * VEC_BYTES) % (VSPAN / 3)), 0, '0, full());
      padd(1'b1, 0, longint'(2 * (VSPAN / 3) + (i * VEC_BYTES) % (VSPAN / 3)), 0, '0, full());
    end
    measure("fp32_triad_aligned", 0, 0);
    // ===== misaligned streams (only where the policy accepts them)
    if (ALIGN_POLICY >= 1) begin
      reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b0, 0, longint'((i * VEC_BYTES + BANK_BYTES) % (VSPAN - 2 * VEC_BYTES)), 0, '0, full());
      measure("seq_load_off1word", 0, 0);
      reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b1, 0, longint'((i * VEC_BYTES + BANK_BYTES) % (VSPAN - 2 * VEC_BYTES)), 0, '0, full());
      measure("seq_store_off1word", 0, 0);
    end
    if (ALIGN_POLICY >= 2) begin
      reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b0, 0, longint'((i * VEC_BYTES + 1) % (VSPAN - 2 * VEC_BYTES)), 0, '0, full());
      measure("seq_load_off1byte", 0, 0);
      reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b1, 0, longint'((i * VEC_BYTES + 1) % (VSPAN - 2 * VEC_BYTES)), 0, '0, full());
      measure("seq_store_off1byte", 0, 0);
    end
    // ===== random
    reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b0, 0, longint'(rndn(VSPAN / VEC_BYTES - 1)) * VEC_BYTES, 0, '0, full());
    measure("random_load_aligned", 0, 0);
    reset_prog(); for (int i = 0; i < NREQ; i++) padd(rnd() & 1, 0, longint'(rndn(VSPAN / VEC_BYTES - 1)) * VEC_BYTES, 0, '0, full());
    measure("random_mix_aligned", 0, 0);
    if (ALIGN_POLICY >= 2) begin
      reset_prog(); for (int i = 0; i < NREQ; i++) padd(rnd() & 1, 0, longint'(rndn(VSPAN - 2 * VEC_BYTES)), 0, '0, full());
      measure("random_mix_bytes", 0, 0);
    end
    // ===== partial final vectors: arrays of (3 vectors - 1 lane) floats, tail-masked last vector, one array per 4 vectors of space
    reset_prog();
    for (int i = 0; i < NREQ / 3; i++) begin
      longint base;
      base = longint'((i * 4 * VEC_BYTES) % (VSPAN - 4 * VEC_BYTES));
      padd(1'b1, 0, base, 0, '0, full());
      padd(1'b1, 0, base + VEC_BYTES, 0, '0, full());
      padd(1'b1, 0, base + 2 * VEC_BYTES, 0, '0, tailm(VEC_BYTES - 4));
    end
    measure("tail_masked_store", 0, 0);
    // ===== serial (isolated) latency
    reset_prog(); for (int i = 0; i < 200; i++) padd(1'b0, 0, longint'((i * VEC_BYTES) % VSPAN), 0, '0, full());
    measure("iso_load_aligned", 0, 1);
    reset_prog(); for (int i = 0; i < 200; i++) padd(1'b1, 0, longint'((i * VEC_BYTES) % VSPAN), 0, '0, full());
    measure("iso_store_aligned", 0, 1);
    if (ALIGN_POLICY >= 2) begin
      reset_prog(); for (int i = 0; i < 200; i++) padd(1'b0, 0, longint'((i * VEC_BYTES + 1) % (VSPAN - 2 * VEC_BYTES)), 0, '0, full());
      measure("iso_load_off1byte", 0, 1);
    end
    // ===== strided / gather (GS configurations)
    if (GS_EN != 0) begin
      reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b0, 1, longint'((i * 64) % (VSPAN / 2)), longint'(GS_ES), '0, full());
      measure("gs_stride_1elem", 0, 0);
      reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b0, 1, longint'((i * 64) % (VSPAN / 2)), longint'(NB * BANK_BYTES), '0, full());
      measure("gs_stride_nb_words", 0, 0);
      reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b0, 1, longint'((i * 64) % (VSPAN / 2)), longint'(GS_ES * 5), '0, full());
      measure("gs_stride_5elem", 0, 0);
      reset_prog();
      for (int i = 0; i < NREQ; i++) begin
        ix = '0;
        for (int l = 0; l < LANES; l++) ix[l*IDXW +: IDXW] = 32'(GS_ES * rndn(VSPAN / GS_ES - 1));
        padd(1'b0, 2, 0, 0, ix, full());
      end
      measure("gs_gather_random", 0, 0);
      reset_prog();
      for (int i = 0; i < NREQ; i++) begin
        ix = '0;
        for (int l = 0; l < LANES; l++) ix[l*IDXW +: IDXW] = 32'(GS_ES * rndn(VSPAN / GS_ES - 1));
        padd(1'b1, 2, 0, 0, ix, full());
      end
      measure("gs_scatter_random", 0, 0);
    end
    // ===== DMA contention: a vector stream and a DMA stream at several duty cycles
    for (int d = 0; d < 4; d++) begin
      int duty;
      duty = (d == 0) ? 25 : (d == 1) ? 50 : (d == 2) ? 75 : 100;
      reset_prog(); for (int i = 0; i < NREQ; i++) padd(1'b0, 0, longint'((i * VEC_BYTES) % VSPAN), 0, '0, full());
      measure("dma_vs_seq_load", duty, 0);
      reset_prog(); for (int i = 0; i < NREQ; i++) begin padd(1'b0, 0, longint'((i * VEC_BYTES) % (VSPAN / 2)), 0, '0, full()); padd(1'b1, 0, longint'(VSPAN / 2 + (i * VEC_BYTES) % (VSPAN / 2)), 0, '0, full()); end
      measure("dma_vs_copy", duty, 0);
    end
    $display("RESULT %s tests=1 checks=0 errors=%0d cycles=%0d %s", NAME, errs, cycle, (errs == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #2000000000; $display("RESULT %s TIMEOUT errors=1 FAIL", NAME); $finish; end
endmodule
