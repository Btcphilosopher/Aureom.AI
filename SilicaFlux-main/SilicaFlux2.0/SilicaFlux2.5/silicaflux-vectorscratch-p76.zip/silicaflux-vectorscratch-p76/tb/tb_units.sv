// =============================================================================
// SilicaFlux VectorScratch :: tb_units -- unit-level checks of the leaf blocks and of sf_vmem_pkg
//
//  U1  package constants == the `define header the RTL uses (sf_vspm_defs.svh / sf_sram_defs.svh)
//  U2  sf_vspm_bankmap (RTL) == sf_vmem_pkg::word_bank / word_row for EVERY word index, all three maps, and every map is a
//      bijection over (bank,row): each (bank,row) is hit by exactly one word (no aliasing, no hole)
//  U3  sf_vspm_split + sf_vspm_merge against a byte-level reference: for every (offset, mask) [exhaustive when the mask space
//      is small, random otherwise]:
//        split : window byte (off+j) carries vector byte j exactly where mask[j] = 1, window mask is mask << off,
//                nothing else is enabled
//        merge : fed a window whose NON-accessed bytes hold garbage, vector byte j = window byte (off+j) if mask[j] else 0
//        round trip : merge(split(x)) == x & mask
//  U4  sf_vmem_pkg helpers: lane_to_byte_mask, tail_mask, array_vector_mask (partial final vector), words_touched, bank_cycles,
//      isolated_latency against brute-force recomputation
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"

module tb_units #(
  parameter int VEC_BYTES = 16,
  parameter int BB        = 4,
  parameter int NRAND     = 200000,
  parameter int SEED      = 32'hC0FFEE01
);
  import sf_vmem_pkg::*;
  localparam int NW   = VEC_BYTES / BB + 1;
  localparam int OFFW = $clog2(BB);
  int n_checks = 0, n_err = 0;
  task automatic fail(input string m);
    n_err++;
    if (n_err <= 20) $display("  [FAIL] %s", m);
  endtask
  task automatic check(input bit c, input string m);
    n_checks++;
    if (!c) fail(m);
  endtask

  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction

  // ---------------------------------------------------------------- U2 : RTL bank map instances (one per map)
  localparam int NBM = 8, DPM = 32, WIWM = $clog2(NBM * DPM);
  logic [WIWM-1:0] widx;
  logic [2:0] bk [3];
  logic [4:0] rw [3];
  genvar gm;
  generate
    for (gm = 0; gm < 3; gm++) begin : g_map
      sf_vspm_bankmap #(.NB(NBM), .DEPTH(DPM), .BANK_MAP(gm), .WIW(WIWM)) u (.widx(widx), .bank(bk[gm]), .row(rw[gm]));
    end
  endgenerate

  // ---------------------------------------------------------------- U3 : split / merge instances
  logic [VEC_BYTES*8-1:0] wdata, rdata;
  logic [VEC_BYTES-1:0]   mask;
  logic [OFFW-1:0]        off;
  logic [NW*BB*8-1:0]     wwd, win;
  logic [NW*BB-1:0]       wmask;
  sf_vspm_split #(.VEC_BYTES(VEC_BYTES), .BB(BB), .NW(NW)) u_split (.wdata(wdata), .mask(mask), .off(off), .wwd(wwd), .wmask(wmask));
  sf_vspm_merge #(.VEC_BYTES(VEC_BYTES), .BB(BB), .NW(NW)) u_merge (.win(win), .off(off), .mask(mask), .rdata(rdata));

  task automatic split_merge_case(input logic [VEC_BYTES-1:0] m, input int o);
    logic [NW*BB*8-1:0] gar;
    logic [NW*BB-1:0]   exp_wm;
    logic [NW*BB*8-1:0] exp_wd;
    logic [VEC_BYTES*8-1:0] exp_rd;
    wdata = '0;
    for (int i = 0; i < VEC_BYTES / 4; i++) wdata[i*32 +: 32] = rnd();
    mask = m; off = OFFW'(o);
    exp_wm = '0; exp_wd = '0;
    for (int j = 0; j < VEC_BYTES; j++) if (m[j]) begin exp_wm[o + j] = 1'b1; exp_wd[(o + j)*8 +: 8] = wdata[j*8 +: 8]; end
    #1;
    check(wmask === exp_wm, $sformatf("split mask: off=%0d mask=%h got %h exp %h", o, m, wmask, exp_wm));
    // data only has to match where the window mask is set (bytes that are not enabled never reach an array)
    for (int k = 0; k < NW * BB; k++) if (exp_wm[k]) check(wwd[k*8 +: 8] === exp_wd[k*8 +: 8], $sformatf("split data byte %0d off=%0d mask=%h", k, o, m));
    // merge: a window with garbage everywhere, the accessed bytes holding the "memory" values
    gar = '0;
    for (int i = 0; i < NW * BB / 4 + 1; i++) if (i * 32 < NW * BB * 8) gar[i*32 +: 32] = rnd();
    win = gar;
    exp_rd = '0;
    for (int j = 0; j < VEC_BYTES; j++) if (m[j]) exp_rd[j*8 +: 8] = gar[(o + j)*8 +: 8];
    #1;
    check(rdata === exp_rd, $sformatf("merge: off=%0d mask=%h got %h exp %h", o, m, rdata, exp_rd));
    // round trip: what split puts in the window, merge returns (masked)
    win = wwd;
    #1;
    check(rdata === (wdata & expand(m)), $sformatf("round trip off=%0d mask=%h", o, m));
  endtask
  function automatic logic [VEC_BYTES*8-1:0] expand(input logic [VEC_BYTES-1:0] m);
    logic [VEC_BYTES*8-1:0] e;
    for (int j = 0; j < VEC_BYTES; j++) e[j*8 +: 8] = {8{m[j]}};
    return e;
  endfunction

  // ---------------------------------------------------------------- main
  int hit [NBM * DPM];
  logic [VEC_BYTES-1:0] mm;
  logic [63:0] r64;
  longint wtouch_exp;
  initial begin
    // ---------------- U1
    check(ST_OK == `SF_ST_OK && ST_RANGE == `SF_ST_RANGE && ST_ALIGN == `SF_ST_ALIGN && ST_OWNER == `SF_ST_OWNER && ST_BADOP == `SF_ST_BADOP, "U1 status codes");
    check(MODE_CONTIG == `SF_VM_MODE_CONTIG && MODE_STRIDED == `SF_VM_MODE_STRIDED && MODE_INDEXED == `SF_VM_MODE_INDEXED, "U1 modes");
    check(ALIGN_VEC == `SF_VM_ALIGN_VEC && ALIGN_WORD == `SF_VM_ALIGN_WORD && ALIGN_ANY == `SF_VM_ALIGN_ANY, "U1 align policies");
    check(MAP_LOW == `SF_VM_MAP_LOW && MAP_XOR == `SF_VM_MAP_XOR && MAP_BLOCK == `SF_VM_MAP_BLOCK, "U1 bank maps");
    check(ARB_VEC == `SF_VM_ARB_VEC && ARB_DMA == `SF_VM_ARB_DMA && ARB_RR == `SF_VM_ARB_RR, "U1 arbitration");
    check(OWN_SHARED == `SF_VM_OWN_SHARED && OWN_VEC == `SF_VM_OWN_VEC && OWN_DMA == `SF_VM_OWN_DMA, "U1 owners");
    check(PC_CYCLES == `SF_PC_CYCLES && PC_V_REQ == `SF_PC_V_REQ && PC_V_WORD_ACC == `SF_PC_V_WORD_ACC && PC_LAT_RD_MAX == `SF_PC_LAT_RD_MAX &&
          PC_LAT_WR_MAX == `SF_PC_LAT_WR_MAX && PC_D_STALL_ARB == `SF_PC_D_STALL_ARB && PC_ERR_BADOP == `SF_PC_ERR_BADOP && PC_N == `SF_PC_N, "U1 perf indices");
    // ---------------- U2
    for (int m = 0; m < 3; m++) begin
      for (int i = 0; i < NBM * DPM; i++) hit[i] = 0;
      for (int w = 0; w < NBM * DPM; w++) begin
        widx = WIWM'(w); #1;
        check(int'(bk[m]) == word_bank(w, NBM, DPM, m) && int'(rw[m]) == word_row(w, NBM, DPM, m), $sformatf("U2 map %0d word %0d: rtl (%0d,%0d) pkg (%0d,%0d)", m, w, bk[m], rw[m], word_bank(w, NBM, DPM, m), word_row(w, NBM, DPM, m)));
        hit[int'(bk[m]) * DPM + int'(rw[m])]++;
      end
      for (int i = 0; i < NBM * DPM; i++) check(hit[i] == 1, $sformatf("U2 map %0d is not a bijection at (bank,row) %0d: hit %0d times", m, i, hit[i]));
    end
    // ---------------- U3
    for (int o = 0; o < BB; o++) begin
      if (VEC_BYTES <= 16) begin
        for (int m = 0; m < (1 << VEC_BYTES); m++) split_merge_case(VEC_BYTES'(m), o);     // exhaustive: every mask, every offset
      end
      for (int i = 0; i < NRAND / BB; i++) begin
        r64 = {rnd(), rnd()};
        mm = r64[VEC_BYTES-1:0];
        split_merge_case(mm, o);
      end
      split_merge_case({VEC_BYTES{1'b1}}, o);
      split_merge_case('0, o);
    end
    // ---------------- U4
    check(tail_mask(0) == '0 && tail_mask(5) == 64'h1F && tail_mask(64) == '1, "U4 tail_mask");
    begin
      logic [63:0] bm;
      bm = lane_to_byte_mask(64'b1011, 4);
      check(bm[15:0] == 16'b1111_0000_1111_1111 && bm[63:16] == '0, $sformatf("U4 lane_to_byte_mask 32-bit lanes: %h", bm[15:0]));
      bm = lane_to_byte_mask(64'b0101, 8);
      // 64-bit lanes 0 and 2 enabled -> bytes 0..7 and 16..23
      check(bm[7:0] == 8'hFF && bm[15:8] == 8'h00 && bm[23:16] == 8'hFF && bm[31:24] == 8'h00 && bm[63:32] == '0,
            $sformatf("U4 lane_to_byte_mask 64-bit lanes: %h", bm));
    end
    // a 10-float array in 128-bit (4 lane) vectors: vectors 0,1 full, vector 2 has 2 floats, vector 3 none
    check(array_vector_mask(10, 0, 16, 4) == tail_mask(16) && array_vector_mask(10, 1, 16, 4) == tail_mask(16) &&
          array_vector_mask(10, 2, 16, 4) == tail_mask(8) && array_vector_mask(10, 3, 16, 4) == '0, "U4 array_vector_mask");
    // words_touched / bank_cycles: brute force over byte addresses
    for (int i = 0; i < 20000; i++) begin
      longint a;
      int nb_, dp_, mp_, wt, bc, bcnt [64];
      bit seenw [4096];
      logic [MAX_VEC_BYTES-1:0] mk;
      a = longint'(rnd() % 4000);
      nb_ = 1 << (rnd() % 4);
      dp_ = 64;
      mp_ = int'(rnd() % 3);
      r64 = {rnd(), rnd()};
      mk = r64;
      if ((rnd() & 3) == 0) mk = tail_mask(int'(rnd() % (VEC_BYTES + 1)));
      for (int j = VEC_BYTES; j < MAX_VEC_BYTES; j++) mk[j] = 1'b0;
      for (int b = 0; b < 64; b++) bcnt[b] = 0;
      for (int w = 0; w < 4096; w++) seenw[w] = 0;
      wt = 0;
      for (int j = 0; j < VEC_BYTES; j++) if (mk[j]) begin
        longint wi;
        wi = (a + j) / BB;
        if (!seenw[int'(wi % 4096)]) begin seenw[int'(wi % 4096)] = 1; wt++; bcnt[word_bank(wi, nb_, dp_, mp_)]++; end
      end
      bc = 0;
      for (int b = 0; b < 64; b++) if (bcnt[b] > bc) bc = bcnt[b];
      check(words_touched(a, mk, VEC_BYTES, BB) == wt, $sformatf("U4 words_touched a=%0d", a));
      check(bank_cycles(a, mk, VEC_BYTES, BB, nb_, dp_, mp_) == bc, $sformatf("U4 bank_cycles a=%0d nb=%0d map=%0d", a, nb_, mp_));
    end
    check(isolated_latency(1, 0) == 1 && isolated_latency(1, 1) == 3 && isolated_latency(2, 2) == 5 && isolated_latency(3, 1) == 5, "U4 isolated_latency");
    $display("RESULT units_%0d_%0d tests=4 checks=%0d errors=%0d %s", VEC_BYTES, BB, n_checks, n_err, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule
