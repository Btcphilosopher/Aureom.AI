// =============================================================================
// SilicaFlux VectorScratch :: tb_vspm  -- self-checking testbench for sf_vector_scratchpad
//
// INDEPENDENT REFERENCE.  Every expectation comes from a flat BYTE ARRAY (ref_mem) updated by predict_access(), which is
// written byte-by-byte (addr + j, per-byte range / alignment / ownership checks, bank map with / and %), sharing no code
// and no word-slot idea with the RTL.  A request's effect on the model is applied at the clock edge where the DUT
// ACCEPTS it, in acceptance order (vector port first, then DMA port in the same cycle).  Concurrent vector + DMA phases use
// disjoint regions (ownership) so that this order is unambiguous; the shared-region phase uses per-word atomicity checks.
//
// WHAT IS CHECKED, in every phase
//   * every response: id, we, status, full rdata (masked bytes 0), in request order, exactly one per request
//   * stability: a response that is presented and not accepted stays unchanged until accepted
//   * no response without a request; no request lost (queue empty and DUT idle at the end of a phase)
//   * BACKDOOR: after each phase every array byte (read straight out of the bank arrays, not through the DUT read path) equals
//     the model: this is what proves that masked-off bytes and errored requests changed NOTHING
//   * perf counters vs independently computed totals (isolated-request phase)
// One RESULT line is printed at the end:  RESULT <name> tests=.. checks=.. errors=.. PASS|FAIL
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"

module tb_vspm #(
  parameter int VEC_BYTES    = 16,
  parameter int BANK_BYTES   = 4,
  parameter int NB           = 4,
  parameter int DEPTH        = 64,
  parameter int BANK_MAP     = 0,
  parameter int ALIGN_POLICY = 2,
  parameter int GS_EN        = 0,
  parameter int GS_ES        = 4,
  parameter int READ_LATENCY = 1,
  parameter int CQ_DEPTH     = 8,
  parameter int DMA_EN       = 1,
  parameter int DMA_BYTES    = 16,
  parameter int DMA_CQ_DEPTH = 4,
  parameter int ARB_POLICY   = 2,
  parameter int NRGN         = 4,
  parameter int SIM_INIT     = 1,
  parameter int BACKEND      = 0,
  parameter int STAGE        = 9,            // 1 aligned only | 2 + masks/tails/FP32 | 3 + misaligned/cross-bank | 4 + DMA/ownership | 5 + GS | 9 all
  parameter int NRAND        = 1500,
  parameter int SEED         = 32'h5EED0001,
  parameter string NAME      = "run"
);
  localparam int AW        = 24;
  localparam int IDW       = 8;
  localparam int IDXW      = 32;
  localparam int VEC_W     = VEC_BYTES * 8;
  localparam int DMA_W     = DMA_BYTES * 8;
  localparam int CAP       = NB * DEPTH * BANK_BYTES;
  localparam int LANES     = (GS_EN != 0) ? VEC_BYTES / GS_ES : 1;
  localparam int RGW       = (NRGN > 1) ? $clog2(NRGN) : 1;
  localparam int RGN_BYTES = CAP / NRGN;
  localparam int MAXB      = (VEC_BYTES > DMA_BYTES) ? VEC_BYTES : DMA_BYTES;
  localparam int CNT_W     = 32;
  localparam int NPROG     = 4096;
  localparam int NEXP      = 8192;
  localparam int PC_N      = `SF_PC_N;
  // region roles of the ownership phases: two vector-owned and two DMA-owned regions (they coincide when NRGN = 2)
  localparam int RV0 = 0;
  localparam int RV1 = (NRGN >= 4) ? 2 : 0;
  localparam int RD0 = 1;
  localparam int RD1 = (NRGN >= 4) ? 3 : 1;
  localparam int UNIT      = (ALIGN_POLICY == 0) ? VEC_BYTES : ((ALIGN_POLICY == 1) ? BANK_BYTES : 1);

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT
  logic                    v_req_valid = 1'b0, v_req_ready, v_req_we = 1'b0, v_rsp_valid, v_rsp_ready = 1'b0, v_rsp_we;
  logic [1:0]              v_req_mode = '0;
  logic [AW-1:0]           v_req_addr = '0, v_req_stride = '0;
  logic [LANES*IDXW-1:0]   v_req_idx = '0;
  logic [VEC_BYTES-1:0]    v_req_mask = '0;
  logic [VEC_W-1:0]        v_req_wdata = '0, v_rsp_rdata;
  logic [IDW-1:0]          v_req_id = '0, v_rsp_id;
  logic [2:0]              v_rsp_status;
  logic                    d_req_valid = 1'b0, d_req_ready, d_req_write = 1'b0, d_rsp_valid, d_rsp_ready = 1'b0, d_rsp_error;
  logic [AW-1:0]           d_req_addr = '0;
  logic [DMA_W-1:0]        d_req_wdata = '0, d_rsp_rdata;
  logic [DMA_BYTES-1:0]    d_req_wstrb = '0;
  logic [2:0]              d_rsp_err_code;
  logic                    own_req_valid = 1'b0, own_req_ready, own_ack, own_err;
  logic [RGW-1:0]          own_req_rgn = '0;
  logic [1:0]              own_req_val = '0;
  logic [NRGN*2-1:0]       own_state;
  logic                    err_clear = 1'b0, busy, err_sticky, err_port, perf_clear = 1'b0;
  logic [2:0]              err_code;
  logic [AW-1:0]           err_addr;
  logic [CNT_W-1:0]        err_cnt;
  logic [PC_N*CNT_W-1:0]   perf;
  logic [NB*CNT_W-1:0]     perf_bank_acc, perf_bank_conf;
  logic [1:0]              ev_rd, ev_wr, ev_cf;

  sf_vector_scratchpad #(.AW(AW), .IDW(IDW), .VEC_BYTES(VEC_BYTES), .BANK_BYTES(BANK_BYTES), .NB(NB), .DEPTH(DEPTH),
                         .BANK_MAP(BANK_MAP), .ALIGN_POLICY(ALIGN_POLICY), .GS_EN(GS_EN), .GS_ES(GS_ES), .IDXW(IDXW),
                         .READ_LATENCY(READ_LATENCY), .BACKEND(BACKEND), .SIM_INIT(SIM_INIT), .CQ_DEPTH(CQ_DEPTH),
                         .DMA_EN(DMA_EN), .DMA_BYTES(DMA_BYTES), .DMA_CQ_DEPTH(DMA_CQ_DEPTH), .ARB_POLICY(ARB_POLICY),
                         .NRGN(NRGN), .OWN_RESET(`SF_VM_OWN_VEC), .PERF_EN(1), .CNT_W(CNT_W)) dut (
    .clk(clk), .rst_n(rst_n),
    .v_req_valid(v_req_valid), .v_req_ready(v_req_ready), .v_req_we(v_req_we), .v_req_mode(v_req_mode), .v_req_addr(v_req_addr),
    .v_req_stride(v_req_stride), .v_req_idx(v_req_idx), .v_req_mask(v_req_mask), .v_req_wdata(v_req_wdata), .v_req_id(v_req_id),
    .v_rsp_valid(v_rsp_valid), .v_rsp_ready(v_rsp_ready), .v_rsp_rdata(v_rsp_rdata), .v_rsp_id(v_rsp_id), .v_rsp_we(v_rsp_we),
    .v_rsp_status(v_rsp_status),
    .d_req_valid(d_req_valid), .d_req_ready(d_req_ready), .d_req_write(d_req_write), .d_req_addr(d_req_addr),
    .d_req_wdata(d_req_wdata), .d_req_wstrb(d_req_wstrb), .d_rsp_valid(d_rsp_valid), .d_rsp_ready(d_rsp_ready),
    .d_rsp_rdata(d_rsp_rdata), .d_rsp_error(d_rsp_error), .d_rsp_err_code(d_rsp_err_code),
    .own_req_valid(own_req_valid), .own_req_ready(own_req_ready), .own_req_rgn(own_req_rgn), .own_req_val(own_req_val),
    .own_ack_o(own_ack), .own_err_o(own_err), .own_state_o(own_state),
    .err_clear_i(err_clear), .busy_o(busy), .err_sticky_o(err_sticky), .err_code_o(err_code), .err_addr_o(err_addr),
    .err_port_o(err_port), .err_cnt_o(err_cnt),
    .perf_clear_i(perf_clear), .perf_o(perf), .perf_bank_acc_o(perf_bank_acc), .perf_bank_conf_o(perf_bank_conf),
    .ev_spm_read_o(ev_rd), .ev_spm_write_o(ev_wr), .ev_spm_conflict_o(ev_cf));

  // ---------------------------------------------------------------- backdoor access to the bank arrays
  int bd_row = 0;
  logic [NB*BANK_BYTES*8-1:0] bd_word;
  genvar gb;
  generate
    for (gb = 0; gb < NB; gb++) begin : g_bd
      if (BACKEND == 0) begin : g_b0
        assign bd_word[gb*BANK_BYTES*8 +: BANK_BYTES*8] = dut.u_banks.g_bank[gb].u_wrap.g_behav.u_mem.mem[bd_row];
      end else if (BACKEND == 1) begin : g_b1
        assign bd_word[gb*BANK_BYTES*8 +: BANK_BYTES*8] = dut.u_banks.g_bank[gb].u_wrap.g_fpga.u_mem.mem[bd_row];
      end else begin : g_b2
        assign bd_word[gb*BANK_BYTES*8 +: BANK_BYTES*8] = '0;
      end
    end
  endgenerate

  // ---------------------------------------------------------------- random numbers (xorshift32, identical in every simulator)
  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic int rndn(input int n);
    logic [31:0] r;
    r = rnd();
    return int'(r % 32'(n));
  endfunction
  function automatic logic [MAXB*8-1:0] rnd_data();
    logic [MAXB*8-1:0] d;
    d = '0;
    for (int i = 0; i < MAXB / 4; i++) d[i*32 +: 32] = rnd();
    return d;
  endfunction

  // ---------------------------------------------------------------- reference model state
  byte unsigned ref_mem [CAP];
  byte unsigned ref_resp [CAP];                     // state after every RESPONDED request (reset-phase bookkeeping)
  logic [1:0]   own_ref [NRGN];
  int           n_checks = 0, n_err = 0, n_tests = 0;
  string        cur = "";
  longint       cycle = 0;

  task automatic fail(input string m);
    n_err++;
    if (n_err <= 30) $display("  [FAIL] %s @cycle %0d (%s)", m, cycle, cur);
  endtask
  task automatic check(input bit c, input string m);
    n_checks++;
    if (!c) fail(m);
  endtask

  // independent bank map (division / modulo form)
  function automatic int tb_bank(input longint w);
    case (BANK_MAP)
      1: tb_bank = int'((w % NB) ^ ((w / NB) % NB));
      2: tb_bank = int'(w / DEPTH);
      default: tb_bank = int'(w % NB);
    endcase
  endfunction
  function automatic int tb_row(input longint w);
    case (BANK_MAP)
      2: tb_row = int'(w % DEPTH);
      default: tb_row = int'(w / NB);
    endcase
  endfunction

  // ---------------------------------------------------------------- the reference access: status + data, applies stores
  // port: 0 vector, 1 DMA.   nb = bytes of the port's request.
  longint sc_ba [MAXB];                              // scratch: byte address of every request byte
  task automatic predict_access(input int port, input bit we, input int mode, input longint addr, input longint stride,
                                input logic [LANES*IDXW-1:0] idx, input logic [MAXB-1:0] mask, input logic [MAXB*8-1:0] wd,
                                input int nb, output int st, output logic [MAXB*8-1:0] rd);
    int es, lane, sub, region;
    bit rng_bad, al_bad, own_bad, badop, lane_en;
    longint base, lane_addr;
    logic signed [IDXW-1:0] ix;
    st = `SF_ST_OK;
    rd = '0;
    es = (GS_EN != 0) ? GS_ES : 1;
    badop = (mode == 3) || (mode != 0 && GS_EN == 0) || (port == 1 && mode != 0);
    rng_bad = 0; al_bad = 0; own_bad = 0;
    if (!badop) begin
      // byte addresses
      for (int j = 0; j < nb; j++) begin
        if (mode == 0) sc_ba[j] = addr + j;
        else begin
          lane = j / es; sub = j % es;
          if (mode == 1) lane_addr = addr + lane * stride;
          else begin
            ix = idx[lane*IDXW +: IDXW];
            lane_addr = addr + longint'(ix);
          end
          sc_ba[j] = lane_addr + sub;
        end
      end
      // range / ownership: only ENABLED bytes count
      for (int j = 0; j < nb; j++) begin
        if (mask[j]) begin
          if (sc_ba[j] < 0 || sc_ba[j] >= CAP) rng_bad = 1;
          else begin
            region = int'(sc_ba[j] / RGN_BYTES);
            if (!(own_ref[region] == `SF_VM_OWN_SHARED || own_ref[region] == ((port == 0) ? `SF_VM_OWN_VEC : `SF_VM_OWN_DMA))) own_bad = 1;
          end
        end
      end
      // alignment
      if (mode == 0) begin
        if (port == 1)                al_bad = (addr % nb) != 0;
        else if (ALIGN_POLICY == 0)   al_bad = (addr % VEC_BYTES) != 0;
        else if (ALIGN_POLICY == 1)   al_bad = (addr % BANK_BYTES) != 0;
      end else begin
        for (int l = 0; l < nb / es; l++) begin
          lane_en = 0;
          for (int i = 0; i < es; i++) if (mask[l*es + i]) lane_en = 1;
          if (lane_en && (sc_ba[l*es] % es) != 0) al_bad = 1;
        end
      end
    end
    if (badop)        st = `SF_ST_BADOP;
    else if (al_bad)  st = `SF_ST_ALIGN;
    else if (rng_bad) st = `SF_ST_RANGE;
    else if (own_bad) st = `SF_ST_OWNER;
    if (st == `SF_ST_OK) begin
      if (!we) begin
        for (int j = 0; j < nb; j++) if (mask[j]) rd[j*8 +: 8] = ref_mem[int'(sc_ba[j])];
      end else begin
        for (int j = 0; j < nb; j++) if (mask[j]) ref_mem[int'(sc_ba[j])] = wd[j*8 +: 8];       // ascending order: highest lane wins
      end
    end
  endtask

  // ---------------------------------------------------------------- programs (requests of a phase)
  logic              pv_we   [NPROG];
  logic [1:0]        pv_mode [NPROG];
  logic [AW-1:0]     pv_addr [NPROG];
  logic [AW-1:0]     pv_str  [NPROG];
  logic [LANES*IDXW-1:0] pv_idx [NPROG];
  logic [VEC_BYTES-1:0]  pv_mask [NPROG];
  logic [VEC_W-1:0]  pv_wd   [NPROG];
  int pv_n = 0, pv_ptr = 0;
  logic              pd_we   [NPROG];
  logic [AW-1:0]     pd_addr [NPROG];
  logic [DMA_BYTES-1:0]  pd_strb [NPROG];
  logic [DMA_W-1:0]  pd_wd   [NPROG];
  int pd_n = 0, pd_ptr = 0;

  // expected response queues
  logic [IDW-1:0]    ev_id   [NEXP];
  logic              ev_we   [NEXP];
  logic [2:0]        ev_st   [NEXP];
  logic [VEC_W-1:0]  ev_data [NEXP];
  longint            ev_t0   [NEXP];
  int                ev_h = 0, ev_t = 0;
  logic              ed_we   [NEXP];
  logic [2:0]        ed_st   [NEXP];
  logic [DMA_W-1:0]  ed_data [NEXP];
  int                ed_h = 0, ed_t = 0;

  // agent knobs
  bit   v_run = 0, d_run = 0;
  int   v_gap_pct = 0, v_rdy_pct = 100, d_gap_pct = 0, d_rdy_pct = 100;
  int   next_id = 0;
  // latency bookkeeping (independent of the DUT counters)
  longint lat_rd_sum = 0, lat_wr_sum = 0, lat_rd_max = 0, lat_wr_max = 0;
  int     lat_rd_n = 0, lat_wr_n = 0;
  // stability tracking
  bit              pv_hold = 0, pd_hold = 0;
  logic [VEC_W-1:0] pv_data, pd_dummy;
  logic [IDW-1:0]  pv_id_q;
  logic            pv_we_q;
  logic [2:0]      pv_st_q;
  logic [DMA_W-1:0] pd_data_q;
  logic            pd_err_q;
  logic [2:0]      pd_code_q;
  // ownership command
  bit              own_go = 0;
  int              own_rgn_c = 0, own_val_c = 0;
  int              own_done_cnt = 0;
  bit              own_inflight = 0;
  // accounting
  int  v_acc_n = 0, v_rsp_n = 0, d_acc_n = 0, d_rsp_n = 0;
  int  st_hist [8];
  int  std_hist [8];
  // request currently being offered (held until accepted)
  bit              v_offering = 0, d_offering = 0;

  longint last_lat = 0;
  bit own_pending = 0;               // an ownership request was accepted and not yet acknowledged: the ports must not accept
  int exp_rd_hook, exp_wr_hook;
  // the single clocked agent -------------------------------------------------------------------------------------------
  int          pst;
  logic [MAXB*8-1:0] prd;
  logic [MAXB-1:0]   pmask;
  logic [MAXB*8-1:0] pwd;
  always @(posedge clk) begin
    cycle <= cycle + 1;
    if (rst_n) begin
      // (0) tile-level counter hooks: one read / write event per accepted request, per port
      exp_rd_hook = int'(v_req_valid && v_req_ready && !v_req_we) + int'(d_req_valid && d_req_ready && !d_req_write);
      exp_wr_hook = int'(v_req_valid && v_req_ready &&  v_req_we) + int'(d_req_valid && d_req_ready &&  d_req_write);
      check(int'(ev_rd) == exp_rd_hook && int'(ev_wr) == exp_wr_hook, "ev_spm_read/write hook");
      // (1) ownership acknowledge -> the model follows
      if (own_ack) begin
        // when the change takes effect every earlier access of BOTH ports is complete and its response delivered
        check(ev_h == ev_t && ed_h == ed_t, "ownership acknowledged while accesses were still in flight");
        own_ref[own_rgn_c] = own_val_c[1:0];
        own_pending = 0;
        own_inflight = 0;
        own_done_cnt++;
      end
      if (own_err) begin own_inflight = 0; own_done_cnt++; end
      // (2) vector response check
      if (v_rsp_valid) begin
        if (pv_hold) begin
          check(v_rsp_id === pv_id_q && v_rsp_we === pv_we_q && v_rsp_status === pv_st_q && v_rsp_rdata === pv_data, "vector response changed while stalled");
        end
        if (ev_h == ev_t) fail("vector response without request");
        else if (v_rsp_ready) begin
          check(v_rsp_id === ev_id[ev_h % NEXP], $sformatf("v id: got %0d exp %0d", v_rsp_id, ev_id[ev_h % NEXP]));
          check(v_rsp_we === ev_we[ev_h % NEXP], "v we");
          check(v_rsp_status === ev_st[ev_h % NEXP], $sformatf("v status: got %0d exp %0d (id %0d)", v_rsp_status, ev_st[ev_h % NEXP], ev_id[ev_h % NEXP]));
          check(v_rsp_rdata === ev_data[ev_h % NEXP], $sformatf("v rdata: got %h exp %h (id %0d)", v_rsp_rdata, ev_data[ev_h % NEXP], ev_id[ev_h % NEXP]));
          if (ev_we[ev_h % NEXP]) begin lat_wr_sum += cycle - ev_t0[ev_h % NEXP]; lat_wr_n++; if (cycle - ev_t0[ev_h % NEXP] > lat_wr_max) lat_wr_max = cycle - ev_t0[ev_h % NEXP]; end
          else begin lat_rd_sum += cycle - ev_t0[ev_h % NEXP]; lat_rd_n++; if (cycle - ev_t0[ev_h % NEXP] > lat_rd_max) lat_rd_max = cycle - ev_t0[ev_h % NEXP]; end
          st_hist[ev_st[ev_h % NEXP]]++;
          last_lat = cycle - ev_t0[ev_h % NEXP];
          ev_h++; v_rsp_n++;
        end
        pv_hold = !v_rsp_ready;
        pv_id_q = v_rsp_id; pv_we_q = v_rsp_we; pv_st_q = v_rsp_status; pv_data = v_rsp_rdata;
      end else begin
        pv_hold = 0;
      end
      // (3) DMA response check
      if (d_rsp_valid) begin
        if (pd_hold) begin
          check(d_rsp_rdata === pd_data_q && d_rsp_error === pd_err_q && d_rsp_err_code === pd_code_q, "dma response changed while stalled");
        end
        if (ed_h == ed_t) fail("dma response without request");
        else if (d_rsp_ready) begin
          check(d_rsp_err_code === ed_st[ed_h % NEXP], $sformatf("d status: got %0d exp %0d", d_rsp_err_code, ed_st[ed_h % NEXP]));
          check(d_rsp_error === (ed_st[ed_h % NEXP] != 0), "d error flag");
          check(d_rsp_rdata === ed_data[ed_h % NEXP], $sformatf("d rdata: got %h exp %h", d_rsp_rdata, ed_data[ed_h % NEXP]));
          std_hist[ed_st[ed_h % NEXP]]++;
          ed_h++; d_rsp_n++;
        end
        pd_hold = !d_rsp_ready;
        pd_data_q = d_rsp_rdata; pd_err_q = d_rsp_error; pd_code_q = d_rsp_err_code;
      end else begin
        pd_hold = 0;
      end
      // (4) vector acceptance -> predict
      if (v_req_valid && v_req_ready) begin
        check(!own_pending, "vector request accepted while an ownership change is pending");
        pmask = '0; pmask[VEC_BYTES-1:0] = v_req_mask;
        pwd = '0;   pwd[VEC_W-1:0] = v_req_wdata;
        predict_access(0, v_req_we, int'(v_req_mode), longint'(v_req_addr), longint'($signed({{(64-AW){v_req_stride[AW-1]}}, v_req_stride})), v_req_idx, pmask, pwd, VEC_BYTES, pst, prd);
        ev_id[ev_t % NEXP] = v_req_id; ev_we[ev_t % NEXP] = v_req_we; ev_st[ev_t % NEXP] = pst[2:0];
        ev_data[ev_t % NEXP] = prd[VEC_W-1:0]; ev_t0[ev_t % NEXP] = cycle;
        ev_t++; v_acc_n++;
        v_offering = 0;
        pv_ptr++;
      end
      // (5) DMA acceptance -> predict
      if (d_req_valid && d_req_ready) begin
        check(!own_pending, "DMA request accepted while an ownership change is pending");
        pmask = '0; pmask[DMA_BYTES-1:0] = d_req_write ? d_req_wstrb : {DMA_BYTES{1'b1}};
        pwd = '0;   pwd[DMA_W-1:0] = d_req_wdata;
        predict_access(1, d_req_write, 0, longint'(d_req_addr), 0, '0, pmask, pwd, DMA_BYTES, pst, prd);
        ed_we[ed_t % NEXP] = d_req_write; ed_st[ed_t % NEXP] = pst[2:0];
        ed_data[ed_t % NEXP] = prd[DMA_W-1:0];
        ed_t++; d_acc_n++;
        d_offering = 0;
        pd_ptr++;
      end
      if (own_req_valid && own_req_ready) own_pending = 1;           // from the NEXT edge on the ports are blocked
      // (6) drive the next cycle
      if (v_run && !v_offering && pv_ptr < pv_n && rndn(100) >= v_gap_pct) begin
        v_req_valid <= 1'b1; v_req_we <= pv_we[pv_ptr]; v_req_mode <= pv_mode[pv_ptr]; v_req_addr <= pv_addr[pv_ptr];
        v_req_stride <= pv_str[pv_ptr]; v_req_idx <= pv_idx[pv_ptr]; v_req_mask <= pv_mask[pv_ptr]; v_req_wdata <= pv_wd[pv_ptr];
        v_req_id <= IDW'(next_id); next_id++;
        v_offering = 1;
      end else if (!v_offering) begin
        v_req_valid <= 1'b0;
        v_req_id <= IDW'(rnd());                      // payload noise while idle: a DUT must ignore it
        v_req_addr <= AW'(rnd()); v_req_wdata <= rnd_data(); v_req_mask <= '0; v_req_we <= rnd();
      end
      if (d_run && !d_offering && pd_ptr < pd_n && rndn(100) >= d_gap_pct) begin
        d_req_valid <= 1'b1; d_req_write <= pd_we[pd_ptr]; d_req_addr <= pd_addr[pd_ptr];
        d_req_wstrb <= pd_strb[pd_ptr]; d_req_wdata <= pd_wd[pd_ptr];
        d_offering = 1;
      end else if (!d_offering) begin
        d_req_valid <= 1'b0;
        d_req_addr <= AW'(rnd());
      end
      v_rsp_ready <= (rndn(100) < v_rdy_pct);
      d_rsp_ready <= (rndn(100) < d_rdy_pct);
      // ownership command
      if (own_go && own_req_ready && !own_inflight) begin
        own_req_valid <= 1'b1; own_req_rgn <= RGW'(own_rgn_c); own_req_val <= own_val_c[1:0];
        own_go = 0; own_inflight = 1;
      end else begin
        own_req_valid <= 1'b0;
      end
    end
  end

  // ---------------------------------------------------------------- bank arbitration fairness monitor (white box)
  // per bank: how many CONSECUTIVE cycles did a port present a candidate and not get the bank?  Round robin bounds it by 1.
  int run_v [NB];
  int run_d [NB];
  int max_loss_v = 0, max_loss_d = 0;
  always @(posedge clk) begin
    if (rst_n) begin
      for (int b = 0; b < NB; b++) begin
        if (dut.c0_valid[b] && !dut.g0[b]) begin run_v[b]++; if (run_v[b] > max_loss_v) max_loss_v = run_v[b]; end else run_v[b] = 0;
        if (dut.c1_valid[b] && !dut.g1[b]) begin run_d[b]++; if (run_d[b] > max_loss_d) max_loss_d = run_d[b]; end else run_d[b] = 0;
      end
    end else begin
      for (int b = 0; b < NB; b++) begin run_v[b] = 0; run_d[b] = 0; end
    end
  end

  // ---------------------------------------------------------------- phase helpers
  task automatic wait_cycles(input int n);
    repeat (n) @(posedge clk);
  endtask

  task automatic clear_progs();
    pv_n = 0; pv_ptr = 0; pd_n = 0; pd_ptr = 0;
  endtask

  task automatic vadd(input bit we, input int mode, input longint addr, input longint stride, input logic [LANES*IDXW-1:0] idx,
                      input logic [VEC_BYTES-1:0] mask, input logic [VEC_W-1:0] wd);
    pv_we[pv_n] = we; pv_mode[pv_n] = mode[1:0]; pv_addr[pv_n] = AW'(addr); pv_str[pv_n] = AW'(stride);
    pv_idx[pv_n] = idx; pv_mask[pv_n] = mask; pv_wd[pv_n] = wd;
    pv_n++;
    if (pv_n >= NPROG) $fatal(1, "program overflow");
  endtask
  task automatic vld(input longint addr, input logic [VEC_BYTES-1:0] mask);
    vadd(1'b0, 0, addr, 0, '0, mask, '0);
  endtask
  task automatic vst(input longint addr, input logic [VEC_BYTES-1:0] mask, input logic [VEC_W-1:0] wd);
    vadd(1'b1, 0, addr, 0, '0, mask, wd);
  endtask
  task automatic dadd(input bit we, input longint addr, input logic [DMA_BYTES-1:0] strb, input logic [DMA_W-1:0] wd);
    pd_we[pd_n] = we; pd_addr[pd_n] = AW'(addr); pd_strb[pd_n] = strb; pd_wd[pd_n] = wd;
    pd_n++;
    if (pd_n >= NPROG) $fatal(1, "dma program overflow");
  endtask

  // start the programs without waiting (so that a phase can interfere while they run)
  task automatic start_progs(input bit vrun, input bit drun);
    v_run = vrun; d_run = drun;
    pv_ptr = 0; pd_ptr = 0;
    if (!vrun) pv_n = 0;
    if (!drun) pd_n = 0;
  endtask
  // wait for every accepted request to be answered, with a deadlock timeout
  task automatic finish_progs();
    int t;
    t = 0;
    while ((pv_ptr < pv_n || pd_ptr < pd_n || ev_h != ev_t || ed_h != ed_t || own_go || own_inflight) && t < 400000) begin
      @(posedge clk);
      t++;
    end
    if (t >= 400000) fail("TIMEOUT: phase did not complete (deadlock or lost response)");
    v_run = 0; d_run = 0;
    wait_cycles(6);
    check(!busy, "busy after phase completion");
    check(ev_h == ev_t && ed_h == ed_t, "responses outstanding after phase");
    ev_h = ev_t; ed_h = ed_t;
  endtask
  task automatic run_progs(input bit vrun, input bit drun);
    start_progs(vrun, drun);
    finish_progs();
  endtask

  // backdoor: read one byte of the real arrays
  task automatic backdoor_compare(input string what);
    int w, bank, row, bad, first;
    longint ww;
    bad = 0; first = -1;
    if (BACKEND <= 1) begin
      for (w = 0; w < NB * DEPTH; w++) begin
        ww = w;
        bank = tb_bank(ww); row = tb_row(ww);
        bd_row = row;
        #1;
        for (int j = 0; j < BANK_BYTES; j++) begin
          n_checks++;
          if (bd_word[bank*BANK_BYTES*8 + j*8 +: 8] !== ref_mem[w*BANK_BYTES + j]) begin
            bad++;
            if (first < 0) first = w * BANK_BYTES + j;
          end
        end
      end
      if (bad != 0) fail($sformatf("%s: backdoor mismatch: %0d bytes differ, first at byte %0d", what, bad, first));
    end
  endtask

  task automatic phase(input string nm);
    cur = nm;
    n_tests++;
  endtask

  // ---------------------------------------------------------------- mask / address generators
  function automatic logic [VEC_BYTES-1:0] mk_full();
    return {VEC_BYTES{1'b1}};
  endfunction
  function automatic logic [VEC_BYTES-1:0] mk_tail(input int n);                     // n low bytes enabled
    logic [VEC_BYTES-1:0] m;
    m = '0;
    for (int j = 0; j < VEC_BYTES; j++) m[j] = (j < n);
    return m;
  endfunction
  function automatic logic [VEC_BYTES-1:0] mk_rand_mask(input int kind);
    logic [VEC_BYTES-1:0] m;
    int k;
    m = '0;
    case (kind % 8)
      0: m = {VEC_BYTES{1'b1}};
      1: for (int j = 0; j < VEC_BYTES; j++) m[j] = rnd() & 1;
      2: m[rndn(VEC_BYTES)] = 1'b1;
      3: m = mk_tail(1 + rndn(VEC_BYTES));
      4: begin k = 1 + rndn(VEC_BYTES); for (int j = 0; j < VEC_BYTES; j++) m[j] = (j >= VEC_BYTES - k); end
      5: for (int j = 0; j < VEC_BYTES / BANK_BYTES; j++) if (rnd() & 1) for (int i = 0; i < BANK_BYTES; i++) m[j*BANK_BYTES + i] = 1'b1;
      6: for (int j = 0; j < VEC_BYTES; j++) m[j] = (rndn(10) == 0);
      default: m = '0;
    endcase
    return m;
  endfunction
  // random start address of a full vector inside the aperture (aligned to `unit`)
  function automatic longint rnd_addr(input int unit);
    int nunits;
    nunits = (CAP - VEC_BYTES) / unit + 1;
    return longint'(rndn(nunits)) * unit;
  endfunction

  // ===========================================================================
  //                                   PHASES
  // ===========================================================================
  // -- fill the whole array through the DUT with random data (also initialises poison arrays)
  task automatic ph_init_fill();
    logic [VEC_W-1:0] d;
    phase("init_fill");
    clear_progs();
    v_gap_pct = 0; v_rdy_pct = 100;
    for (int a = 0; a < CAP; a += VEC_BYTES) begin
      d = rnd_data();
      vst(a, mk_full(), d);
    end
    run_progs(1, 0);
    backdoor_compare("init_fill");
  endtask

  // -- aligned full-vector loads / stores, sequential then random
  task automatic ph_aligned();
    logic [VEC_W-1:0] d;
    phase("aligned");
    clear_progs();
    v_gap_pct = 0; v_rdy_pct = 100;
    for (int a = 0; a < CAP && pv_n < 600; a += VEC_BYTES) begin           // sequential store sweep then load sweep
      d = rnd_data(); vst(a, mk_full(), d);
    end
    for (int a = 0; a < CAP && pv_n < 1200; a += VEC_BYTES) vld(a, mk_full());
    run_progs(1, 0);
    backdoor_compare("aligned seq");
    clear_progs();
    for (int i = 0; i < NRAND / 3; i++) begin
      d = rnd_data();
      if (rnd() & 1) vst(rnd_addr(VEC_BYTES), mk_full(), d); else vld(rnd_addr(VEC_BYTES), mk_full());
    end
    run_progs(1, 0);
    backdoor_compare("aligned random");
  endtask

  // -- FP32 element sequences: raw bits must survive exactly (NaN payloads, -0, denormals, infinities)
  task automatic ph_fp32();
    logic [VEC_W-1:0] d;
    logic [31:0] sp [8];
    int n_lane;
    logic [31:0] expect_w;
    phase("fp32_elements");
    sp[0] = 32'h7FC1_2345; sp[1] = 32'h8000_0000; sp[2] = 32'h0000_0001; sp[3] = 32'h7F80_0000;
    sp[4] = 32'hFF7F_FFFF; sp[5] = 32'h3F80_0000; sp[6] = 32'hFFC0_0001; sp[7] = 32'h007F_FFFF;
    n_lane = VEC_BYTES / 4;
    clear_progs();
    v_gap_pct = 0; v_rdy_pct = 100;
    for (int v = 0; v < 16; v++) begin
      d = '0;
      for (int l = 0; l < n_lane; l++) d[l*32 +: 32] = sp[(v + l) % 8] ^ ((v >= 8) ? 32'h0 : 32'h0);
      vst(longint'(v) * VEC_BYTES, mk_full(), d);
    end
    for (int v = 0; v < 16; v++) vld(longint'(v) * VEC_BYTES, mk_full());
    run_progs(1, 0);
    // literal expectations (independent of the model): re-read through the model and compare to the pattern directly
    for (int v = 0; v < 16; v++) begin
      for (int l = 0; l < n_lane; l++) begin
        expect_w = sp[(v + l) % 8];
        for (int by = 0; by < 4; by++) begin
          n_checks++;
          if (ref_mem[v*VEC_BYTES + l*4 + by] !== expect_w[by*8 +: 8]) fail("fp32 raw bits differ from the literal pattern (model)");
        end
      end
    end
    backdoor_compare("fp32");
    // a ramp of consecutive element indices (lane l of vector v holds the float32 bit pattern of v*lanes + l)
    clear_progs();
    for (int v = 0; v < 24; v++) begin
      d = '0;
      for (int l = 0; l < n_lane; l++) d[l*32 +: 32] = 32'h3F80_0000 + 32'((v * n_lane + l) * 32'h0000_2000);
      vst(longint'(v) * VEC_BYTES, mk_full(), d);
    end
    for (int v = 0; v < 24; v++) vld(longint'(v) * VEC_BYTES, mk_full());
    run_progs(1, 0);
    backdoor_compare("fp32 ramp");
  endtask

  // -- byte-mask stores: inactive lanes must not overwrite existing data
  task automatic ph_masks();
    logic [VEC_W-1:0] d;
    int u;
    phase("byte_masks");
    u = (ALIGN_POLICY == 0) ? VEC_BYTES : BANK_BYTES;
    v_gap_pct = 0; v_rdy_pct = 100;
    // (a) one-hot and tail masks over a pre-filled vector, read back
    clear_progs();
    for (int a = 0; a < 8 * VEC_BYTES; a += VEC_BYTES) begin d = rnd_data(); vst(a, mk_full(), d); end
    for (int j = 0; j < VEC_BYTES; j++) begin
      logic [VEC_BYTES-1:0] oh;
      oh = '0; oh[j] = 1'b1;
      d = rnd_data(); vst(longint'(j % 8) * VEC_BYTES, oh, d);
      vld(longint'(j % 8) * VEC_BYTES, mk_full());
    end
    for (int n = 0; n <= VEC_BYTES; n++) begin
      d = rnd_data(); vst(longint'(n % 8) * VEC_BYTES, mk_tail(n), d);                 // n = 0 : empty mask, no effect at all
      vld(longint'(n % 8) * VEC_BYTES, mk_full());
    end
    run_progs(1, 0);
    backdoor_compare("masks onehot/tail");
    // (b) random masks everywhere, store then masked/unmasked loads
    clear_progs();
    for (int i = 0; i < NRAND / 3; i++) begin
      d = rnd_data();
      if (rnd() & 1) vst(rnd_addr(u), mk_rand_mask(rndn(8)), d); else vld(rnd_addr(u), mk_rand_mask(rndn(8)));
    end
    run_progs(1, 0);
    backdoor_compare("masks random");
    // (c) partial FINAL vector of an array whose length is not a multiple of the vector: n floats, last vector tail-masked
    clear_progs();
    for (int nf = 1; nf <= 3 * (VEC_BYTES / 4) + 2; nf += 1 + (nf % 3)) begin
      int full, rem;
      full = nf / (VEC_BYTES / 4); rem = nf % (VEC_BYTES / 4);
      for (int v = 0; v < full; v++) begin d = rnd_data(); vst(longint'(v) * VEC_BYTES, mk_full(), d); end
      if (rem != 0) begin d = rnd_data(); vst(longint'(full) * VEC_BYTES, mk_tail(rem * 4), d); end
    end
    run_progs(1, 0);
    backdoor_compare("partial final vector");
  endtask

  // -- out-of-bounds: errors, no side effect; masked-off bytes beyond the end are legal
  task automatic ph_range();
    logic [VEC_W-1:0] d;
    phase("out_of_bounds");
    v_gap_pct = 0; v_rdy_pct = 100;
    clear_progs();
    // vectors straddling / beyond the end of the aperture (starts aligned to a word at least)
    for (int k = 1; k <= VEC_BYTES; k += BANK_BYTES) begin
      d = rnd_data();
      vst(longint'(CAP - VEC_BYTES + k), mk_full(), d);          // k bytes beyond the end enabled -> RANGE
      vld(longint'(CAP - VEC_BYTES + k), mk_full());
      vst(longint'(CAP - VEC_BYTES + k), mk_tail(VEC_BYTES - k), d);   // only the in-range bytes enabled -> legal (partial final vector)
      vld(longint'(CAP - VEC_BYTES + k), mk_tail(VEC_BYTES - k));
    end
    for (int m = 1; m < VEC_BYTES / BANK_BYTES; m++) begin                                    // word-ALIGNED vectors straddling the end
      d = rnd_data();
      vst(longint'(CAP - VEC_BYTES + m * BANK_BYTES), mk_full(), d);                          // RANGE (or ALIGN under the vector policy)
      vld(longint'(CAP - VEC_BYTES + m * BANK_BYTES), mk_full());
      vst(longint'(CAP - VEC_BYTES + m * BANK_BYTES), mk_tail(VEC_BYTES - m * BANK_BYTES), d);   // only in-range bytes: legal where the policy allows
      vld(longint'(CAP - VEC_BYTES + m * BANK_BYTES), mk_tail(VEC_BYTES - m * BANK_BYTES));
    end
    d = rnd_data(); vst(longint'(CAP), mk_full(), d); vld(longint'(CAP), mk_full());       // wholly outside
    d = rnd_data(); vst(longint'(CAP + 4096), mk_full(), d); vld(longint'((1 << AW) - VEC_BYTES), mk_full());
    d = rnd_data(); vst(longint'(CAP), '0, d); vld(longint'(CAP), '0);                       // empty mask outside: no access, OK
    run_progs(1, 0);
    backdoor_compare("out_of_bounds");
  endtask

  // -- alignment policy: every start offset over several words, loads and masked stores, crossing every bank boundary
  task automatic ph_misaligned();
    logic [VEC_W-1:0] d;
    phase("misaligned");
    v_gap_pct = 0; v_rdy_pct = 100;
    clear_progs();
    for (int a = 0; a < 2 * VEC_BYTES + 2 * NB * BANK_BYTES; a += VEC_BYTES) begin d = rnd_data(); vst(a, mk_full(), d); end
    run_progs(1, 0);
    clear_progs();
    for (int off = 0; off < VEC_BYTES + 2 * BANK_BYTES + 1; off++) begin           // every byte offset (rejected ones included)
      d = rnd_data(); vst(longint'(off) + 3 * 0, mk_full(), d);
      vld(longint'(off), mk_full());
      vld(longint'(off) + 1, mk_full());
      d = rnd_data(); vst(longint'(off) + longint'(NB * BANK_BYTES) - 1, mk_rand_mask(off), d);
      vld(longint'(off) + longint'(NB * BANK_BYTES) - 1, mk_full());
    end
    run_progs(1, 0);
    backdoor_compare("misaligned sweep");
    // wrap over the rows of every bank: start addresses crossing the NB*BANK_BYTES stripe boundary and the row boundary
    clear_progs();
    for (int r = 0; r < 4; r++) begin
      for (int off = -BANK_BYTES; off <= BANK_BYTES; off++) begin
        longint a;
        a = longint'(r) * NB * BANK_BYTES * 3 + longint'(NB * BANK_BYTES) + off;
        if (a >= 0) begin d = rnd_data(); vst(a, mk_full(), d); vld(a, mk_full()); end
      end
    end
    run_progs(1, 0);
    backdoor_compare("misaligned stripe");
    // random byte addresses, random masks, loads and stores
    clear_progs();
    for (int i = 0; i < NRAND; i++) begin
      longint a;
      a = longint'(rndn(CAP + (rndn(8) == 0 ? 3 * VEC_BYTES : 0)));            // sometimes beyond the end
      d = rnd_data();
      if (rnd() & 1) vst(a, mk_rand_mask(rndn(8)), d); else vld(a, mk_rand_mask(rndn(8)));
    end
    run_progs(1, 0);
    backdoor_compare("misaligned random");
  endtask

  // -- back-to-back dependent operations at full rate and with gaps
  task automatic ph_b2b(input int gap, input int rdy);
    logic [VEC_W-1:0] d;
    longint a;
    int u;
    phase("back_to_back");
    u = (ALIGN_POLICY == 0) ? VEC_BYTES : ((ALIGN_POLICY == 1) ? BANK_BYTES : 1);
    v_gap_pct = gap; v_rdy_pct = rdy;
    clear_progs();
    for (int i = 0; i < NRAND / 2; i++) begin
      // a small window of addresses so that consecutive requests overlap: RAW / WAR / WAW at byte level
      a = longint'(rndn(4 * VEC_BYTES / u)) * u;
      d = rnd_data();
      case (rndn(5))
        0: begin vst(a, mk_full(), d); vld(a, mk_full()); end                                    // store -> load, same address
        1: begin vst(a, mk_rand_mask(rndn(8)), d); vst(a, mk_rand_mask(rndn(8)), rnd_data()); vld(a, mk_full()); end   // WAW
        2: begin vld(a, mk_full()); vst(a, mk_full(), d); vld(a, mk_full()); end                 // WAR then RAW
        3: begin vst(a, mk_full(), d); vst(a + u, mk_rand_mask(rndn(8)), rnd_data()); vld(a, mk_full()); vld(a + u, mk_full()); end // overlapping neighbours
        default: begin vld(a, mk_full()); vld(a, mk_full()); vld(a + u, mk_full()); end
      endcase
    end
    run_progs(1, 0);
    backdoor_compare("back_to_back");
  endtask

  // -- gather / scatter / strided
  task automatic ph_gs();
    logic [VEC_W-1:0] d;
    logic [LANES*IDXW-1:0] ix;
    longint stride;
    int es;
    phase("strided_gather_scatter");
    es = GS_ES;
    v_gap_pct = 0; v_rdy_pct = 100;
    clear_progs();
    for (int i = 0; i < 40; i++) begin d = rnd_data(); vst(longint'(i) * VEC_BYTES, mk_full(), d); end
    // strided: positive, negative, zero (broadcast), non-contiguous, large; loads and stores
    for (int s = -3; s <= 7; s++) begin
      stride = longint'(s) * es;
      d = rnd_data();
      vadd(1'b0, 1, longint'(20 * es) + 7 * VEC_BYTES, stride, '0, mk_full(), '0);
      vadd(1'b1, 1, longint'(20 * es) + 7 * VEC_BYTES, stride, '0, mk_rand_mask(rndn(8)), d);
      vadd(1'b0, 1, longint'(20 * es) + 7 * VEC_BYTES, stride, '0, mk_full(), '0);
    end
    // misaligned element addresses -> ALIGN, unsupported mode 3 -> BADOP
    d = rnd_data();
    vadd(1'b0, 1, 5, es, '0, mk_full(), '0);
    vadd(1'b1, 1, 5, es, '0, mk_full(), d);
    vadd(1'b0, 3, 0, 0, '0, mk_full(), '0);
    // random gathers / scatters: NON-ZERO base, signed offsets (negative ones land inside the aperture), duplicates, outside lanes
    for (int i = 0; i < NRAND / 2; i++) begin
      longint gbase;
      gbase = longint'(es) * rndn(CAP / es);
      ix = '0;
      for (int l = 0; l < LANES; l++) begin
        int kind;
        longint target;
        kind = rndn(16);
        target = longint'(es) * rndn(CAP / es);
        if (kind == 0)      ix[l*IDXW +: IDXW] = 32'(target - gbase) + 32'(es * (CAP / es));       // beyond the end
        else if (kind < 4 && l > 0) ix[l*IDXW +: IDXW] = ix[(l - 1)*IDXW +: IDXW];                  // duplicate of the previous lane
        else                ix[l*IDXW +: IDXW] = 32'(target - gbase);                                // signed offset, usually negative half the time
      end
      d = rnd_data();
      vadd(rnd() & 1, 2, gbase, 0, ix, (rndn(4) == 0) ? mk_rand_mask(rndn(8)) : mk_full(), d);
    end
    run_progs(1, 0);
    backdoor_compare("gs");
  endtask

  // -- gather/scatter overlap semantics: duplicate addresses inside one scatter, HIGHEST LANE WINS
  task automatic ph_scatter_overlap();
    logic [VEC_W-1:0] d1, d2;
    logic [LANES*IDXW-1:0] ix;
    phase("scatter_overlap");
    v_gap_pct = 0; v_rdy_pct = 100;
    clear_progs();
    for (int l = 0; l < LANES; l++) ix[l*IDXW +: IDXW] = 32'(GS_ES * 3);                  // every lane to element 3
    d1 = rnd_data();
    vadd(1'b1, 2, 0, 0, ix, mk_full(), d1);
    vadd(1'b0, 2, 0, 0, ix, mk_full(), '0);                                              // gather it back: every lane sees the winner
    for (int l = 0; l < LANES; l++) ix[l*IDXW +: IDXW] = 32'(GS_ES * (l % 2));            // two interleaved duplicate groups
    d2 = rnd_data();
    vadd(1'b1, 2, 128, 0, ix, mk_full(), d2);
    vadd(1'b0, 2, 128, 0, ix, mk_full(), '0);
    vadd(1'b0, 0, 128, 0, '0, mk_full(), '0);
    run_progs(1, 0);
    // LITERAL expectations (written from the rule, not from the model): element 3 holds lane LANES-1's data
    for (int by = 0; by < GS_ES; by++) begin
      n_checks++;
      if (ref_mem[GS_ES*3 + by] !== d1[(LANES-1)*GS_ES*8 + by*8 +: 8]) fail("scatter overlap: element 3 is not the last lane's data (model)");
      n_checks++;
      if (ref_mem[128 + by] !== d2[((LANES % 2 == 0) ? LANES - 2 : LANES - 1)*GS_ES*8 + by*8 +: 8]) fail("scatter overlap: even-lane group is not the last even lane (model)");
      if (LANES > 1) begin
        n_checks++;
        if (ref_mem[128 + GS_ES + by] !== d2[((LANES % 2 == 0) ? LANES - 1 : LANES - 2)*GS_ES*8 + by*8 +: 8]) fail("scatter overlap: odd-lane group is not the last odd lane (model)");
      end
    end
    backdoor_compare("scatter_overlap");        // and the DUT array holds exactly that
  endtask

  // -- reset in the middle of traffic
  task automatic ph_reset();
    logic [VEC_W-1:0] d;
    int w, bank, row;
    longint ww;
    int nbad;
    phase("reset_mid_traffic");
    v_gap_pct = 0; v_rdy_pct = 70;
    clear_progs();
    // disjoint vector-sized slots: every in-flight store touches bytes nobody else touches, so each byte is old or new after reset
    for (int i = 0; i < 24; i++) begin
      d = rnd_data();
      if (i % 2 == 0) vst(longint'(i) * VEC_BYTES, mk_full(), d); else vld(longint'(i - 1) * VEC_BYTES, mk_full());
    end
    for (int b = 0; b < CAP; b++) ref_resp[b] = ref_mem[b];
    v_run = 1; pv_ptr = 0;
    repeat (9) @(posedge clk);
    // snapshot the byte values before the reset hits (model after acceptance = NEW values for in-flight stores)
    #2 rst_n = 1'b0;                                           // asynchronous assertion in the middle of the cycle
    v_run = 0; d_run = 0; v_offering = 0; d_offering = 0;
    v_req_valid = 1'b0;
    repeat (3) @(posedge clk);
    #2 rst_n = 1'b1;
    ev_h = ev_t; ed_h = ed_t; pv_n = 0; pv_ptr = 0;
    repeat (4) @(posedge clk);
    check(!v_rsp_valid && !d_rsp_valid, "response valid right after reset");
    check(!busy, "busy after reset");
    // every byte must be NEW (store executed) or OLD (not executed): old = 'ref before the phase' (saved in ref_resp)
    nbad = 0;
    if (BACKEND <= 1) begin
      for (w = 0; w < NB * DEPTH; w++) begin
        ww = w; bank = tb_bank(ww); row = tb_row(ww); bd_row = row; #1;
        for (int j = 0; j < BANK_BYTES; j++) begin
          logic [7:0] got;
          got = bd_word[bank*BANK_BYTES*8 + j*8 +: 8];
          n_checks++;
          if (got !== ref_mem[w*BANK_BYTES + j] && got !== ref_resp[w*BANK_BYTES + j]) nbad++;
          ref_mem[w*BANK_BYTES + j] = got;                    // the model follows the array (memory is NOT reset)
        end
      end
      if (nbad != 0) fail($sformatf("reset: %0d bytes are neither old nor new", nbad));
    end
    // the design works normally after reset
    clear_progs();
    for (int i = 0; i < 40; i++) begin d = rnd_data(); if (i % 2) vld(longint'(i) * VEC_BYTES % (CAP - VEC_BYTES), mk_full()); else vst(longint'(i) * VEC_BYTES % (CAP - VEC_BYTES), mk_full(), d); end
    v_gap_pct = 0; v_rdy_pct = 100;
    run_progs(1, 0);
    backdoor_compare("after reset");
  endtask

  // -- vector port with response back-pressure and request gaps (queue-full, stall stability)
  task automatic ph_backpressure();
    logic [VEC_W-1:0] d;
    int u;
    phase("backpressure");
    u = (ALIGN_POLICY == 0) ? VEC_BYTES : ((ALIGN_POLICY == 1) ? BANK_BYTES : 1);
    for (int pass = 0; pass < 3; pass++) begin
      clear_progs();
      case (pass)
        0: begin v_gap_pct = 0;  v_rdy_pct = 10; end               // consumer almost never ready: the CQ fills, requests block
        1: begin v_gap_pct = 60; v_rdy_pct = 100; end              // sparse requests
        default: begin v_gap_pct = 30; v_rdy_pct = 40; end
      endcase
      for (int i = 0; i < NRAND / 4; i++) begin
        d = rnd_data();
        if (rnd() & 1) vst(longint'(rndn(CAP / VEC_BYTES)) * VEC_BYTES + ((u == 1) ? 0 : 0), mk_rand_mask(rndn(8)), d); else vld(longint'(rndn(CAP / VEC_BYTES)) * VEC_BYTES, mk_full());
      end
      run_progs(1, 0);
      backdoor_compare("backpressure");
    end
    v_gap_pct = 0; v_rdy_pct = 100;
  endtask

  // -- ownership protocol + DMA concurrency (disjoint regions): ping-pong
  task automatic ph_dma_own();
    logic [VEC_W-1:0] d;
    logic [DMA_W-1:0] dd;
    int r;
    longint base;
    phase("dma_ownership");
    // (a) default owner is VEC: every DMA access is refused with OWNER and has no effect
    err_clear = 1'b1; @(posedge clk); #1 err_clear = 1'b0; wait_cycles(2);
    clear_progs();
    for (int i = 0; i < 8; i++) begin dd = rnd_data(); dadd(1'b1, longint'(i) * DMA_BYTES, {DMA_BYTES{1'b1}}, dd); dadd(1'b0, longint'(i) * DMA_BYTES, '1, '0); end
    d_gap_pct = 0; d_rdy_pct = 100;
    run_progs(0, 1);
    backdoor_compare("dma refused");
    check(err_sticky && err_code == `SF_ST_OWNER && err_port == 1'b1 && err_addr == 0 && err_cnt == 16,
          $sformatf("first-error registers after DMA refusals: sticky=%0d code=%0d port=%0d addr=%0d cnt=%0d", err_sticky, err_code, err_port, err_addr, err_cnt));
    err_clear = 1'b1; @(posedge clk); #1 err_clear = 1'b0; wait_cycles(2);
    check(std_hist[`SF_ST_OWNER] == 16, $sformatf("DMA OWNER refusals: %0d exp 16", std_hist[`SF_ST_OWNER]));
    // (b) hand regions 1 and 3 to the DMA; vector keeps 0 and 2
    own_rgn_c = RD0; own_val_c = `SF_VM_OWN_DMA; own_go = 1; run_progs(0, 0);
    own_rgn_c = RD1; own_val_c = `SF_VM_OWN_DMA; own_go = 1; run_progs(0, 0);
    check(own_state[RD0*2 +: 2] == `SF_VM_OWN_DMA && own_state[RD1*2 +: 2] == `SF_VM_OWN_DMA && own_state[RV0*2 +: 2] == `SF_VM_OWN_VEC, "ownership state readback");
    // (c) concurrent traffic: DMA streams over regions 1/3, vector over 0/2; each also pokes the other's region (refused)
    for (int pass = 0; pass < 4; pass++) begin
      clear_progs();
      v_gap_pct = (pass == 1) ? 40 : 0; v_rdy_pct = (pass == 3) ? 50 : 100;
      d_gap_pct = (pass == 2) ? 50 : 0; d_rdy_pct = (pass == 3) ? 60 : 100;
      for (int i = 0; i < NRAND / 3; i++) begin
        int rg;
        rg = (rndn(8) == 0) ? ((rndn(2) == 0) ? RD0 : RD1) : ((rndn(2) == 0) ? RV0 : RV1);   // mostly own regions, sometimes a foreign one
        base = longint'(rg) * RGN_BYTES;
        d = rnd_data();
        if (rnd() & 1) vst(base + longint'(rndn(RGN_BYTES / VEC_BYTES)) * VEC_BYTES, mk_rand_mask(rndn(8)), d);
        else           vld(base + longint'(rndn(RGN_BYTES / VEC_BYTES)) * VEC_BYTES, mk_full());
      end
      for (int i = 0; i < NRAND / 3; i++) begin
        int rg;
        rg = (rndn(8) == 0) ? ((rndn(2) == 0) ? RV0 : RV1) : ((rndn(2) == 0) ? RD0 : RD1);
        base = longint'(rg) * RGN_BYTES;
        dd = rnd_data();
        if (rnd() & 1) dadd(1'b1, base + longint'(rndn(RGN_BYTES / DMA_BYTES)) * DMA_BYTES, (rndn(3) == 0) ? mk_dma_strb() : {DMA_BYTES{1'b1}}, dd);
        else           dadd(1'b0, base + longint'(rndn(RGN_BYTES / DMA_BYTES)) * DMA_BYTES, '1, '0);
      end
      run_progs(1, 1);
      backdoor_compare("dma concurrent");
    end
    // (d) hand-over: DMA fills region 1 (acknowledged writes), ownership moves to the vector port, which reads it back
    clear_progs();
    for (int i = 0; i < RGN_BYTES / DMA_BYTES; i++) begin dd = rnd_data(); dadd(1'b1, longint'(RD0) * RGN_BYTES + longint'(i) * DMA_BYTES, {DMA_BYTES{1'b1}}, dd); end
    d_gap_pct = 0; d_rdy_pct = 100;
    run_progs(0, 1);
    own_rgn_c = RD0; own_val_c = `SF_VM_OWN_VEC; own_go = 1; run_progs(0, 0);
    clear_progs();
    for (int a = 0; a < RGN_BYTES; a += VEC_BYTES) vld(longint'(RD0) * RGN_BYTES + a, mk_full());
    v_gap_pct = 0; v_rdy_pct = 100;
    run_progs(1, 0);
    // (e) reserved owner value 3 is rejected and changes nothing
    own_rgn_c = 0; own_val_c = 3; own_go = 1; run_progs(0, 0);
    check(own_state[1:0] == `SF_VM_OWN_VEC, "reserved ownership value changed the state");
    // (f) everything shared again
    for (int rr = 0; rr < NRGN; rr++) begin own_rgn_c = rr; own_val_c = `SF_VM_OWN_SHARED; own_go = 1; run_progs(0, 0); end
    backdoor_compare("dma_ownership end");
  endtask
  function automatic logic [DMA_BYTES-1:0] mk_dma_strb();
    logic [DMA_BYTES-1:0] m;
    m = '0;
    for (int j = 0; j < DMA_BYTES; j++) m[j] = rnd() & 1;
    return m;
  endfunction

  // -- ownership change while BOTH ports are streaming: the change must quiesce (every earlier access answered)
  task automatic ph_own_live();
    logic [VEC_W-1:0] d;
    logic [DMA_W-1:0] dd;
    longint base;
    phase("ownership_change_under_traffic");
    for (int rr = 0; rr < NRGN; rr++) begin own_rgn_c = rr; own_val_c = (rr == RD0) ? `SF_VM_OWN_DMA : `SF_VM_OWN_VEC; own_go = 1; run_progs(0, 0); end
    clear_progs();
    v_gap_pct = 0; v_rdy_pct = 100; d_gap_pct = 0; d_rdy_pct = 100;
    for (int i = 0; i < NRAND / 2; i++) begin
      base = longint'((rndn(2) == 0) ? RV0 : RV1) * RGN_BYTES;                     // vector-owned regions
      d = rnd_data();
      if (rnd() & 1) vst(base + longint'(rndn(RGN_BYTES / VEC_BYTES)) * VEC_BYTES, mk_rand_mask(rndn(8)), d);
      else           vld(base + longint'(rndn(RGN_BYTES / VEC_BYTES)) * VEC_BYTES, mk_full());
      dd = rnd_data();
      if (rnd() & 1) dadd(1'b1, longint'(RD0) * RGN_BYTES + longint'(rndn(RGN_BYTES / DMA_BYTES)) * DMA_BYTES, {DMA_BYTES{1'b1}}, dd);
      else           dadd(1'b0, longint'(RD0) * RGN_BYTES + longint'(rndn(RGN_BYTES / DMA_BYTES)) * DMA_BYTES, '1, '0);
    end
    start_progs(1, (DMA_EN != 0));
    for (int i = 0; i < 12; i++) begin
      wait_cycles(3 + rndn(40));
      // the second DMA region flips between owners; the first one (DMA streaming into it) goes DMA -> SHARED -> DMA
      // (with NRGN = 2 both are the same region and the flips cause legal OWNER refusals, which the model predicts)
      if (i % 2 == 0) begin own_rgn_c = RD1; own_val_c = (i % 4 == 0) ? `SF_VM_OWN_DMA : `SF_VM_OWN_VEC; end
      else            begin own_rgn_c = RD0; own_val_c = ((i / 2) % 2 == 0) ? `SF_VM_OWN_SHARED : `SF_VM_OWN_DMA; end
      own_go = 1;
      while ((own_go || own_inflight) && (pv_ptr < pv_n || pd_ptr < pd_n || ev_h != ev_t)) @(posedge clk);
    end
    finish_progs();
    check(own_done_cnt >= 12, "ownership changes did not all complete");
    backdoor_compare("ownership under traffic");
    for (int rr = 0; rr < NRGN; rr++) begin own_rgn_c = rr; own_val_c = `SF_VM_OWN_VEC; own_go = 1; run_progs(0, 0); end
  endtask

  // -- shared region: both ports write the SAME bytes (full vectors / beats with distinguishable patterns) at the same time.
  //    No order exists between the two ports for these bytes, so the model cannot predict them: the vector port only STORES
  //    into the shared region, and the phase checks the one property that holds without an order, per-WORD atomicity: after
  //    the race every bank word is entirely 0xAA.. or entirely 0x55.. (a word is never half and half).  Meanwhile the vector
  //    port also runs fully CHECKED traffic in a private region, to show the race does not disturb unrelated data.
  task automatic ph_shared();
    logic [VEC_W-1:0] d;
    logic [DMA_W-1:0] dd;
    int bank, row, nbad, t, shb, nw;
    longint ww, priv;
    phase("shared_region_atomicity");
    for (int q = 0; q < CAP; q++) ref_resp_shared[q] = ref_mem[q];
    shb = (RGN_BYTES < 8 * VEC_BYTES) ? RGN_BYTES : 8 * VEC_BYTES;
    for (int rr = 0; rr < NRGN; rr++) begin own_rgn_c = rr; own_val_c = (rr == 0) ? `SF_VM_OWN_SHARED : `SF_VM_OWN_VEC; own_go = 1; run_progs(0, 0); end
    clear_progs();
    priv = (NRGN >= 3) ? longint'(2) * RGN_BYTES : longint'(CAP - 4 * VEC_BYTES);
    for (int i = 0; i < 96; i++) begin
      for (int j = 0; j < VEC_BYTES; j++) d[j*8 +: 8] = 8'hAA;
      vst(longint'(rndn(shb / VEC_BYTES)) * VEC_BYTES, mk_full(), d);
      d = rnd_data();
      if (rnd() & 1) vst(priv + longint'(rndn(4)) * VEC_BYTES, mk_rand_mask(rndn(8)), d); else vld(priv + longint'(rndn(4)) * VEC_BYTES, mk_full());
    end
    for (int i = 0; i < 96; i++) begin
      for (int j = 0; j < DMA_BYTES; j++) dd[j*8 +: 8] = 8'h55;
      dadd(1'b1, longint'(rndn(shb / DMA_BYTES)) * DMA_BYTES, {DMA_BYTES{1'b1}}, dd);
    end
    v_gap_pct = 0; v_rdy_pct = 100; d_gap_pct = 0; d_rdy_pct = 100;
    run_progs(1, 1);
    nbad = 0;
    nw = shb / BANK_BYTES;
    if (BACKEND <= 1) begin
      for (int w = 0; w < nw; w++) begin
        logic [BANK_BYTES*8-1:0] wv;
        bit old_same;
        ww = w; bank = tb_bank(ww); row = tb_row(ww); bd_row = row; #1;
        wv = bd_word[bank*BANK_BYTES*8 +: BANK_BYTES*8];
        old_same = 1;
        for (int j = 0; j < BANK_BYTES; j++) if (wv[j*8 +: 8] !== ref_resp_shared[w*BANK_BYTES + j]) old_same = 0;
        n_checks++;
        // a word was written atomically by exactly one port, or by nobody
        if (!(wv == {BANK_BYTES{8'hAA}} || wv == {BANK_BYTES{8'h55}} || old_same)) nbad++;
        for (int j = 0; j < BANK_BYTES; j++) ref_mem[w*BANK_BYTES + j] = wv[j*8 +: 8];     // the model follows the arbitrated outcome
      end
      if (nbad != 0) fail($sformatf("shared: %0d words are neither one port's pattern nor unchanged (non-atomic word access)", nbad));
    end
    for (int rr = 0; rr < NRGN; rr++) begin own_rgn_c = rr; own_val_c = `SF_VM_OWN_VEC; own_go = 1; run_progs(0, 0); end
  endtask
  byte unsigned ref_resp_shared [CAP];

  // -- perf counters vs the TB's independent computation, isolated requests (one outstanding at a time)
  task automatic ph_perf();
    logic [VEC_W-1:0] d;
    logic [PC_N*CNT_W-1:0] p0, p1;
    longint a;
    int pnt, nslot_exp, maxload, nreq, stall_exp, words_exp;
    int exp_ld, exp_st, exp_err, exp_split, exp_xtra, exp_bytes_ld, exp_bytes_st, exp_words, exp_conf;
    int bank_cnt [NB];
    int bank_acc_exp [NB];
    int n_rng, n_al, n_own, n_bad;
    logic [VEC_BYTES-1:0] mk;
    int mode;
    int bank, row;
    int sw [64];
    int nsw;
    int nneed, nneed0, base_w, off;
    bit first_seen;
    int first_code;
    longint first_addr;
    longint exp_lat;
    phase("perf_counters");
    first_seen = 0; first_code = 0; first_addr = 0;
    if (NRGN >= 2) begin own_rgn_c = NRGN - 1; own_val_c = `SF_VM_OWN_DMA; own_go = 1; run_progs(0, 0); end    // some addresses now raise OWNER
    v_gap_pct = 0; v_rdy_pct = 100;
    err_clear = 1'b1; @(posedge clk); #1 err_clear = 1'b0; wait_cycles(2);
    exp_ld = 0; exp_st = 0; exp_err = 0; exp_split = 0; exp_xtra = 0; exp_bytes_ld = 0; exp_bytes_st = 0; exp_words = 0; exp_conf = 0;
    n_rng = 0; n_al = 0; n_own = 0; n_bad = 0;
    for (int b = 0; b < NB; b++) bank_acc_exp[b] = 0;
    perf_clear = 1'b1; @(posedge clk); #1 perf_clear = 1'b0; wait_cycles(2);
    lat_rd_sum = 0; lat_wr_sum = 0; lat_rd_max = 0; lat_wr_max = 0; lat_rd_n = 0; lat_wr_n = 0;
    nreq = 300;
    for (int i = 0; i < nreq; i++) begin
      // one isolated request: draw it, predict it by hand, run it alone
      clear_progs();
      mode = (GS_EN != 0 && rndn(3) == 0) ? 1 + rndn(2) : 0;
      mk = (rndn(3) == 0) ? mk_rand_mask(rndn(8)) : mk_full();
      d = rnd_data();
      a = (ALIGN_POLICY == 2) ? longint'(rndn(CAP - VEC_BYTES + 8)) : longint'(rndn((CAP - VEC_BYTES) / UNIT + 1)) * UNIT;
      if (mode == 0) begin
        case (rndn(12))
          0: a = longint'(CAP) - longint'(rndn(VEC_BYTES));                         // straddles / beyond the end
          1: begin a = longint'(CAP) + longint'(rndn(64)); mk = mk_full(); end        // outside
          2: a = a | 1;                                                               // odd address: rejected by the A policies
          default: ;
        endcase
        if (rndn(40) == 0) begin vadd(rnd() & 1, 3, a, 0, '0, mk, d); end             // unsupported mode
        else if (rnd() & 1) vst(a, mk, d); else vld(a, mk);
      end else if (mode == 1) begin
        a = longint'(rndn(CAP / (4 * GS_ES) )) * GS_ES;
        vadd(rnd() & 1, 1, a, longint'(GS_ES * (1 + rndn(5))), '0, mk, d);
      end else begin
        logic [LANES*IDXW-1:0] ixx;
        ixx = '0;
        for (int l = 0; l < LANES; l++) ixx[l*IDXW +: IDXW] = 32'(GS_ES * rndn(CAP / GS_ES));
        vadd(rnd() & 1, 2, 0, 0, ixx, mk, d);
      end
      // --- independent expectation of the counters (slot analysis written from the spec)
      nsw = 0;
      begin
        bit we_x; int md; longint ad, sd; logic [VEC_BYTES-1:0] mx;
        we_x = pv_we[0]; md = int'(pv_mode[0]); ad = longint'(pv_addr[0]); mx = pv_mask[0];
        sd = longint'($signed({{(64-AW){pv_str[0][AW-1]}}, pv_str[0]}));
        // would the request reach memory? (reuse the byte-level model WITHOUT applying stores: run on a copy of the state)
        begin
          int stx; logic [MAXB*8-1:0] rdx; logic [MAXB-1:0] mm; logic [MAXB*8-1:0] ww2;
          byte unsigned save_mem [CAP];
          mm = '0; mm[VEC_BYTES-1:0] = mx; ww2 = '0; ww2[VEC_W-1:0] = pv_wd[0];
          for (int q = 0; q < CAP; q++) save_mem[q] = ref_mem[q];
          predict_access(0, we_x, md, ad, sd, pv_idx[0], mm, ww2, VEC_BYTES, stx, rdx);
          for (int q = 0; q < CAP; q++) ref_mem[q] = save_mem[q];
          if (stx != 0 && !first_seen) begin first_seen = 1; first_code = stx; first_addr = ad; end
          exp_lat = 1;
          if (stx == `SF_ST_RANGE) n_rng++;
          else if (stx == `SF_ST_ALIGN) n_al++;
          else if (stx == `SF_ST_OWNER) n_own++;
          else if (stx == `SF_ST_BADOP) n_bad++;
          if (we_x) exp_st++; else exp_ld++;
          if (stx != 0) exp_err++;
          else begin
            // slots = distinct (word window position) with an enabled byte; computed from the byte addresses
            for (int b = 0; b < NB; b++) bank_cnt[b] = 0;
            if (md == 0) begin
              off = int'(ad % BANK_BYTES);
              base_w = int'(ad / BANK_BYTES);
              nneed = 0; nneed0 = 0;
              for (int k = 0; k < VEC_BYTES / BANK_BYTES + 1; k++) begin
                bit anyb;
                anyb = 0;
                for (int j = 0; j < VEC_BYTES; j++) if (mx[j] && ((off + j) / BANK_BYTES) == k) anyb = 1;
                if (anyb) begin bank = tb_bank(longint'(base_w + k)); row = tb_row(longint'(base_w + k)); bank_cnt[bank]++; nneed++; end
              end
              for (int k = 0; k < VEC_BYTES / BANK_BYTES; k++) begin
                bit anyb;
                anyb = 0;
                for (int j = 0; j < VEC_BYTES; j++) if (mx[j] && (j / BANK_BYTES) == k) anyb = 1;
                if (anyb) nneed0++;
              end
              if (nneed > nneed0) begin exp_split++; exp_xtra += nneed - nneed0; end
            end else begin
              nneed = 0;
              for (int l = 0; l < VEC_BYTES / GS_ES; l++) begin
                longint ea;
                logic signed [IDXW-1:0] ixs;
                ixs = pv_idx[0][l*IDXW +: IDXW];
                ea = (md == 1) ? ad + l * sd : ad + longint'(ixs);
                for (int sub = 0; sub < GS_ES / BANK_BYTES; sub++) begin
                  bit anyb;
                  anyb = 0;
                  for (int i2 = 0; i2 < BANK_BYTES; i2++) if (mx[l*GS_ES + sub*BANK_BYTES + i2]) anyb = 1;
                  if (anyb) begin bank = tb_bank((ea / BANK_BYTES) + sub); row = tb_row((ea / BANK_BYTES) + sub); bank_cnt[bank]++; nneed++; end
                end
              end
            end
            maxload = 0;
            for (int b = 0; b < NB; b++) begin if (bank_cnt[b] > maxload) maxload = bank_cnt[b]; bank_acc_exp[b] += bank_cnt[b]; end
            exp_words += nneed;
            if (maxload > 1) exp_conf += maxload - 1;
            exp_lat = (nneed == 0) ? 1 : (READ_LATENCY + 2 + (maxload - 1));
            begin
              int nb2;
              nb2 = 0;
              for (int j = 0; j < VEC_BYTES; j++) if (mx[j]) nb2++;
              if (we_x) exp_bytes_st += nb2; else exp_bytes_ld += nb2;
            end
          end
        end
      end
      run_progs(1, 0);
      check(last_lat == exp_lat, $sformatf("isolated request latency %0d exp %0d (READ_LATENCY %0d + 2 + busiest-bank excess)", last_lat, exp_lat, READ_LATENCY));
    end
    // read the counters
    p1 = perf;
    check(p1[`SF_PC_V_REQ*CNT_W +: CNT_W] == nreq, $sformatf("perf V_REQ %0d exp %0d", p1[`SF_PC_V_REQ*CNT_W +: CNT_W], nreq));
    check(p1[`SF_PC_V_LD*CNT_W +: CNT_W] == exp_ld, "perf V_LD");
    check(p1[`SF_PC_V_ST*CNT_W +: CNT_W] == exp_st, "perf V_ST");
    check(p1[`SF_PC_V_RSP*CNT_W +: CNT_W] == nreq, "perf V_RSP");
    check(p1[`SF_PC_V_BYTES_LD*CNT_W +: CNT_W] == exp_bytes_ld, $sformatf("perf V_BYTES_LD %0d exp %0d", p1[`SF_PC_V_BYTES_LD*CNT_W +: CNT_W], exp_bytes_ld));
    check(p1[`SF_PC_V_BYTES_ST*CNT_W +: CNT_W] == exp_bytes_st, $sformatf("perf V_BYTES_ST %0d exp %0d", p1[`SF_PC_V_BYTES_ST*CNT_W +: CNT_W], exp_bytes_st));
    check(p1[`SF_PC_V_ERR*CNT_W +: CNT_W] == exp_err, $sformatf("perf V_ERR %0d exp %0d", p1[`SF_PC_V_ERR*CNT_W +: CNT_W], exp_err));
    check(p1[`SF_PC_ERR_RANGE*CNT_W +: CNT_W] == n_rng && p1[`SF_PC_ERR_ALIGN*CNT_W +: CNT_W] == n_al &&
          p1[`SF_PC_ERR_OWNER*CNT_W +: CNT_W] == n_own && p1[`SF_PC_ERR_BADOP*CNT_W +: CNT_W] == n_bad, "perf error-type counters");
    check(p1[`SF_PC_V_SPLIT_REQ*CNT_W +: CNT_W] == exp_split, $sformatf("perf V_SPLIT_REQ %0d exp %0d", p1[`SF_PC_V_SPLIT_REQ*CNT_W +: CNT_W], exp_split));
    check(p1[`SF_PC_V_ALIGN_XTRA*CNT_W +: CNT_W] == exp_xtra, $sformatf("perf V_ALIGN_XTRA %0d exp %0d", p1[`SF_PC_V_ALIGN_XTRA*CNT_W +: CNT_W], exp_xtra));
    check(p1[`SF_PC_V_WORD_ACC*CNT_W +: CNT_W] == exp_words, $sformatf("perf V_WORD_ACC %0d exp %0d", p1[`SF_PC_V_WORD_ACC*CNT_W +: CNT_W], exp_words));
    check(p1[`SF_PC_V_STALL_CONF*CNT_W +: CNT_W] == exp_conf, $sformatf("perf V_STALL_CONF %0d exp %0d (isolated requests: busiest bank - 1)", p1[`SF_PC_V_STALL_CONF*CNT_W +: CNT_W], exp_conf));
    check(p1[`SF_PC_V_STALL_ARB*CNT_W +: CNT_W] == 0, "perf V_STALL_ARB must be 0 without DMA traffic");
    for (int b = 0; b < NB; b++)
      check(perf_bank_acc[b*CNT_W +: CNT_W] == bank_acc_exp[b], $sformatf("perf bank %0d accesses %0d exp %0d", b, perf_bank_acc[b*CNT_W +: CNT_W], bank_acc_exp[b]));
    check(p1[`SF_PC_LAT_RD_SUM*CNT_W +: CNT_W] == lat_rd_sum && p1[`SF_PC_LAT_RD_CNT*CNT_W +: CNT_W] == lat_rd_n && p1[`SF_PC_LAT_RD_MAX*CNT_W +: CNT_W] == lat_rd_max,
          $sformatf("perf read latency sum/cnt/max %0d/%0d/%0d exp %0d/%0d/%0d", p1[`SF_PC_LAT_RD_SUM*CNT_W +: CNT_W], p1[`SF_PC_LAT_RD_CNT*CNT_W +: CNT_W],
                    p1[`SF_PC_LAT_RD_MAX*CNT_W +: CNT_W], lat_rd_sum, lat_rd_n, lat_rd_max));
    check(p1[`SF_PC_LAT_WR_SUM*CNT_W +: CNT_W] == lat_wr_sum && p1[`SF_PC_LAT_WR_CNT*CNT_W +: CNT_W] == lat_wr_n && p1[`SF_PC_LAT_WR_MAX*CNT_W +: CNT_W] == lat_wr_max,
          $sformatf("perf write latency sum/cnt/max %0d/%0d/%0d exp %0d/%0d/%0d", p1[`SF_PC_LAT_WR_SUM*CNT_W +: CNT_W], p1[`SF_PC_LAT_WR_CNT*CNT_W +: CNT_W],
                    p1[`SF_PC_LAT_WR_MAX*CNT_W +: CNT_W], lat_wr_sum, lat_wr_n, lat_wr_max));
    backdoor_compare("perf phase");
    // error reporting registers: counted every error response, first error recorded
    check(err_cnt == exp_err, $sformatf("err_cnt %0d exp %0d", err_cnt, exp_err));
    check(err_sticky == (exp_err != 0), "err_sticky");
    check(!first_seen || (err_code == first_code[2:0] && longint'(err_addr) == first_addr && err_port == 1'b0),
          $sformatf("first error register code=%0d addr=%0d port=%0d exp code=%0d addr=%0d", err_code, err_addr, err_port, first_code, first_addr));
    err_clear = 1'b1; @(posedge clk); #1 err_clear = 1'b0; wait_cycles(2);
    check(!err_sticky && err_cnt == 0, "err_clear");
  endtask

  // ---------------------------------------------------------------- main
  initial begin
    for (int i = 0; i < 8; i++) begin st_hist[i] = 0; std_hist[i] = 0; end
    for (int r = 0; r < NRGN; r++) own_ref[r] = `SF_VM_OWN_VEC;
    for (int i = 0; i < CAP; i++) begin ref_mem[i] = 8'h00; ref_resp[i] = 8'h00; end
    rst_n = 1'b0;
    repeat (4) @(posedge clk);
    #2 rst_n = 1'b1;
    repeat (3) @(posedge clk);
    check(!v_rsp_valid && !d_rsp_valid && !busy, "state after reset");
    check(v_req_ready === 1'b1, "vector port ready after reset");
    ph_init_fill();                                       // initialises poison arrays too; ref and DUT agree
    // ---- stage 1 : aligned vectors
    ph_aligned();
    ph_b2b(0, 100);
    if (STAGE >= 2 || STAGE == 9) begin ph_fp32(); ph_masks(); ph_range(); end
    // ---- stage 3 : misaligned / cross-bank / reset / back-pressure
    if (STAGE >= 3) begin
      ph_misaligned();
      ph_b2b(0, 100);
      ph_b2b(35, 55);
      ph_backpressure();
      ph_reset();
    end
    // ---- stage 4 : DMA, ownership, shared words
    if ((STAGE >= 4) && DMA_EN != 0) begin ph_dma_own(); ph_own_live(); ph_shared(); end
    // ---- stage 5 : strided / gather / scatter (BADOP check is part of ph_gs when GS_EN = 0 -> see below)
    if (STAGE >= 5 && GS_EN != 0) begin ph_gs(); ph_scatter_overlap(); end
    if (STAGE >= 5 && GS_EN == 0) begin
      phase("badop_when_gs_disabled");
      clear_progs(); v_gap_pct = 0; v_rdy_pct = 100;
      vadd(1'b0, 1, 0, 4, '0, mk_full(), '0);
      vadd(1'b1, 2, 0, 0, '0, mk_full(), rnd_data());
      vadd(1'b0, 3, 0, 0, '0, mk_full(), '0);
      vld(0, mk_full());
      run_progs(1, 0);
      backdoor_compare("badop");
    end
    if (STAGE >= 3) ph_perf();
    backdoor_compare("final");
    if (ARB_POLICY == `SF_VM_ARB_RR && DMA_EN != 0 && STAGE >= 4) begin
      check(max_loss_v <= 1 && max_loss_d <= 1, $sformatf("round robin violated: a port lost the same bank %0d (vector) / %0d (DMA) cycles in a row", max_loss_v, max_loss_d));
    end
    $display("INFO %s max consecutive bank-arbitration losses: vector %0d, dma %0d", NAME, max_loss_v, max_loss_d);
    $display("RESULT %s tests=%0d checks=%0d errors=%0d cycles=%0d %s", NAME, n_tests, n_checks, n_err, cycle, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end

  // global watchdog
  initial begin
    #500000000;
    $display("RESULT %s TIMEOUT errors=%0d FAIL", NAME, n_err + 1);
    $finish;
  end
endmodule
