// =============================================================================
// SilicaFlux VectorScratch :: tb_lane_glue -- the vector-engine-facing contract
//
// hpc_vector_array (Module 03) delivers result beats of NUM_LANES x 32-bit lanes (lane l in bits [32l +: 32]) with a per-LANE
// write mask res_mask (bit l = lane l carries a result).  This testbench MODELS such a beat stream (it does not instantiate the
// FP32 array) and stores / loads it through the scratchpad using sf_vmem_pkg::lane_to_byte_mask:
//   * an array of VL elements (VL not a multiple of the lane count) -> the last beat has a partial mask ("partial final vector")
//   * arbitrary per-lane masks (the array's vm / lane_hold masks)
//   * 32-bit (FP32) and 64-bit elements (a 64-bit element = 2 adjacent lanes with the same mask bit)
//   * aligned and word / byte MISALIGNED array base addresses (policy ANY)
// Data are random 32-bit patterns incl. NaN payloads / -0 / denormals: memory is raw bits.  Every disabled lane must leave its
// previous bytes untouched (checked after each array against the model) and load back as 0.
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"
module tb_lane_glue #(
  parameter int VEC_BYTES = 16,
  parameter int ELEM_BYTES = 4,
  parameter int NB = 8,
  parameter int NARR = 60,
  parameter int SEED = 32'h1A9E610E
);
  import sf_vmem_pkg::*;
  localparam int AW = 20, BB = 4, DEPTH = 128, CAP = NB * DEPTH * BB, VEC_W = VEC_BYTES * 8, NEL = VEC_BYTES / ELEM_BYTES;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  logic v_req_valid = 1'b0, v_req_ready, v_req_we = 1'b0, v_rsp_valid, v_rsp_ready = 1'b1;
  logic [AW-1:0] v_req_addr = '0;
  logic [VEC_BYTES-1:0] v_req_mask = '0;
  logic [VEC_W-1:0] v_req_wdata = '0, v_rsp_rdata;
  logic [2:0] v_rsp_status;
  logic [7:0] v_rsp_id; logic v_rsp_we;
  logic d_rsp_valid_u, d_req_ready_u, d_rsp_error_u; logic [2:0] ec_u; logic [127:0] d_rdata_u;
  logic own_req_ready_u, own_ack_u, own_err_u; logic [7:0] own_state_u;
  logic busy_u, es_u, ep_u; logic [2:0] ecode_u; logic [AW-1:0] ea_u; logic [31:0] ecnt_u;
  logic [`SF_PC_N*32-1:0] perf_u; logic [8*32-1:0] pba_u, pbc_u; logic [1:0] x1, x2, x3;
  sf_vector_scratchpad #(.AW(AW), .VEC_BYTES(VEC_BYTES), .BANK_BYTES(BB), .NB(NB), .DEPTH(DEPTH), .DMA_EN(0), .SIM_INIT(1)) dut (
    .clk(clk), .rst_n(rst_n), .v_req_valid(v_req_valid), .v_req_ready(v_req_ready), .v_req_we(v_req_we), .v_req_mode(2'd0), .v_req_addr(v_req_addr),
    .v_req_stride({AW{1'b0}}), .v_req_idx(1'b0), .v_req_mask(v_req_mask), .v_req_wdata(v_req_wdata), .v_req_id(8'd0),
    .v_rsp_valid(v_rsp_valid), .v_rsp_ready(v_rsp_ready), .v_rsp_rdata(v_rsp_rdata), .v_rsp_id(v_rsp_id), .v_rsp_we(v_rsp_we), .v_rsp_status(v_rsp_status),
    .d_req_valid(1'b0), .d_req_ready(d_req_ready_u), .d_req_write(1'b0), .d_req_addr({AW{1'b0}}), .d_req_wdata(128'd0), .d_req_wstrb(16'd0),
    .d_rsp_valid(d_rsp_valid_u), .d_rsp_ready(1'b1), .d_rsp_rdata(d_rdata_u), .d_rsp_error(d_rsp_error_u), .d_rsp_err_code(ec_u),
    .own_req_valid(1'b0), .own_req_ready(own_req_ready_u), .own_req_rgn(2'd0), .own_req_val(2'd0), .own_ack_o(own_ack_u), .own_err_o(own_err_u), .own_state_o(own_state_u),
    .err_clear_i(1'b0), .busy_o(busy_u), .err_sticky_o(es_u), .err_code_o(ecode_u), .err_addr_o(ea_u), .err_port_o(ep_u), .err_cnt_o(ecnt_u),
    .perf_clear_i(1'b0), .perf_o(perf_u), .perf_bank_acc_o(pba_u[NB*32-1:0]), .perf_bank_conf_o(pbc_u[NB*32-1:0]), .ev_spm_read_o(x1), .ev_spm_write_o(x2), .ev_spm_conflict_o(x3));
  byte unsigned ref_mem [CAP];
  int n_checks = 0, n_err = 0;
  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  task automatic check(input bit c, input string m);
    n_checks++;
    if (!c) begin n_err++; if (n_err <= 20) $display("  [FAIL] %s", m); end
  endtask
  task automatic vreq(input bit we, input longint a, input logic [VEC_BYTES-1:0] mk, input logic [VEC_W-1:0] wd, output logic [VEC_W-1:0] rd, output logic [2:0] st);
    @(posedge clk); #1;
    v_req_valid = 1'b1; v_req_we = we; v_req_addr = AW'(a); v_req_mask = mk; v_req_wdata = wd;
    @(posedge clk); while (!v_req_ready) @(posedge clk);
    #1 v_req_valid = 1'b0;
    @(posedge clk); while (!v_rsp_valid) @(posedge clk);
    rd = v_rsp_rdata; st = v_rsp_status;
  endtask
  logic [31:0] elem [256];
  logic [255:0] vmask;
  initial begin
    for (int i = 0; i < CAP; i++) ref_mem[i] = 8'h00;
    rst_n = 1'b0; repeat (4) @(posedge clk); #2 rst_n = 1'b1; repeat (3) @(posedge clk);
    for (int arr = 0; arr < NARR; arr++) begin
      int vl, nbeats, base;
      longint a;
      vl = 1 + int'(rnd() % 90);
      base = int'(rnd() % (CAP - 90 * ELEM_BYTES - 2 * VEC_BYTES));
      if (arr % 3 == 0) base = base & ~(VEC_BYTES - 1);                 // vector aligned
      else if (arr % 3 == 1) base = base & ~3;                          // word aligned
      nbeats = (vl + NEL - 1) / NEL;
      for (int e = 0; e < vl; e++) elem[e] = rnd();
      vmask = '0;
      for (int e = 0; e < vl; e++) vmask[e] = (arr % 2 == 0) ? 1'b1 : ((rnd() % 4) != 0);    // odd arrays: arbitrary vm mask
      // store the beats: beat g = elements g*NEL .. ; res_mask bit l = element exists AND vm
      for (int g = 0; g < nbeats; g++) begin
        logic [VEC_W-1:0] d; logic [MAX_VEC_BYTES-1:0] bm; logic [MAX_VEC_BYTES-1:0] lm; logic [VEC_W-1:0] rd; logic [2:0] st;
        d = '0; lm = '0;
        for (int l = 0; l < NEL; l++) begin
          int e;
          e = g * NEL + l;
          if (ELEM_BYTES == 4) begin
            d[l*32 +: 32] = (e < vl) ? elem[e] : 32'hDEAD_BEEF;       // garbage in disabled lanes must never be written
          end else begin
            d[l*64 +: 32] = (e < vl) ? elem[e] : 32'hDEAD_BEEF; d[l*64 + 32 +: 32] = (e < vl) ? ~elem[e] : 32'hDEAD_BEEF;
          end
          lm[l] = (e < vl) && vmask[e];
        end
        bm = lane_to_byte_mask(lm, ELEM_BYTES);
        a = longint'(base) + longint'(g) * VEC_BYTES;
        vreq(1'b1, a, bm[VEC_BYTES-1:0], d, rd, st);
        check(st == `SF_ST_OK, "glue store status");
        for (int j = 0; j < VEC_BYTES; j++) if (bm[j]) ref_mem[a + j] = d[j*8 +: 8];
      end
      // load the beats back with the same masks: enabled lanes = stored values, disabled lanes = 0
      for (int g = 0; g < nbeats; g++) begin
        logic [VEC_W-1:0] rd; logic [2:0] st; logic [MAX_VEC_BYTES-1:0] bm, lm; logic [VEC_W-1:0] exp_d;
        lm = '0;
        for (int l = 0; l < NEL; l++) lm[l] = ((g * NEL + l) < vl) && vmask[g * NEL + l];
        bm = lane_to_byte_mask(lm, ELEM_BYTES);
        a = longint'(base) + longint'(g) * VEC_BYTES;
        vreq(1'b0, a, bm[VEC_BYTES-1:0], '0, rd, st);
        exp_d = '0;
        for (int j = 0; j < VEC_BYTES; j++) if (bm[j]) exp_d[j*8 +: 8] = ref_mem[a + j];
        check(st == `SF_ST_OK && rd === exp_d, $sformatf("glue load beat %0d of array %0d (vl %0d base %0d): got %h exp %h", g, arr, vl, base, rd, exp_d));
        // literal element check for enabled lanes
        for (int l = 0; l < NEL; l++) if (lm[l]) begin
          if (ELEM_BYTES == 4) check(rd[l*32 +: 32] === elem[g*NEL + l], "glue FP32 element bits");
          else check(rd[l*64 +: 32] === elem[g*NEL + l] && rd[l*64 + 32 +: 32] === ~elem[g*NEL + l], "glue 64-bit element bits");
        end
      end
      // the whole array region: unmodified bytes (disabled lanes, beyond the last element) still equal the model
      for (int a2 = 0; a2 < CAP; a2 += VEC_BYTES) begin
        logic [VEC_W-1:0] rd; logic [2:0] st; bit ok;
        if ((arr % 10) == 9) begin
          vreq(1'b0, a2, {VEC_BYTES{1'b1}}, '0, rd, st);
          ok = 1;
          for (int j = 0; j < VEC_BYTES; j++) if (rd[j*8 +: 8] !== ref_mem[a2 + j]) ok = 0;
          check(ok, $sformatf("glue: bytes outside the enabled lanes changed (vector at %0d)", a2));
        end
      end
    end
    $display("RESULT lane_glue_%0d_%0d tests=%0d checks=%0d errors=%0d cycles=0 %s", VEC_BYTES, ELEM_BYTES, NARR, n_checks, n_err, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #500000000; $display("RESULT lane_glue TIMEOUT errors=1 FAIL"); $finish; end
endmodule
