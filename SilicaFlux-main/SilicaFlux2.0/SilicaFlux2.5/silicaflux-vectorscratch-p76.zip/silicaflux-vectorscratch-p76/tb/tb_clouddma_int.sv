// =============================================================================
// SilicaFlux VectorScratch :: tb_clouddma_int -- the REAL CloudDMA channel (sfd_clouddma, vendored byte-identical) loading
// and extracting scratchpad data through the scratchpad's DMA port.
//
//   host memory (behavioural SFB2 slave) <--hm_*--  sfd_clouddma  --sm_*-->  sf_vector_scratchpad DMA port  <-- vector port
//
// Flow (every expectation comes from byte arrays kept by this testbench):
//   1  the vector port pre-fills region 1 with a known pattern (so that any byte the DMA must NOT touch is recognisable)
//   2  region 1 is handed to the DMA (ownership quiesce protocol), H2D transfers of several lengths, INCLUDING lengths that end
//      inside a 4-byte beat (CloudDMA then uses a partial strobe: the scratchpad must leave the rest of that word untouched)
//   3  region 1 is handed back; the vector port reads the whole region: it must equal the model, byte for byte
//   4  D2H extraction of ragged lengths into a pre-filled host buffer: bytes outside [dst, dst+len) must be unchanged
//   5  error paths: SRAM address in a region owned by the vector port, outside the aperture, or not beat aligned: CloudDMA must
//      report ERR_SRAM_RESP, done_commit = 0, and nothing in either memory may change
// RESULT line at the end.
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"

module tb_clouddma_int #(
  parameter int NB       = 4,
  parameter int DEPTH    = 64,
  parameter int VEC_BYTES = 16,
  parameter int NRAND    = 24,
  parameter int SEED     = 32'hC10DD0A5
);
  localparam int AW = 24, BB = 4, NRGN = 4;
  localparam int CAP = NB * DEPTH * BB;
  localparam int RGN = CAP / NRGN;
  localparam int HSZ = 4096;
  localparam int VEC_W = VEC_BYTES * 8;
  localparam logic [7:0] ERR_NONE = 8'h00, ERR_SRAM_RESP = 8'h21;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- scratchpad
  logic                v_req_valid = 1'b0, v_req_ready, v_req_we = 1'b0, v_rsp_valid, v_rsp_ready = 1'b1, v_rsp_we;
  logic [AW-1:0]       v_req_addr = '0;
  logic [VEC_BYTES-1:0] v_req_mask = '0;
  logic [VEC_W-1:0]    v_req_wdata = '0, v_rsp_rdata;
  logic [7:0]          v_rsp_id;
  logic [2:0]          v_rsp_status;
  logic                d_req_valid, d_req_ready, d_req_write, d_rsp_valid, d_rsp_ready, d_rsp_error;
  logic [AW-1:0]       d_req_addr;
  logic [31:0]         d_req_wdata, d_rsp_rdata;
  logic [3:0]          d_req_wstrb;
  logic [2:0]          d_rsp_err_code;
  logic                own_req_valid = 1'b0, own_req_ready, own_ack, own_err;
  logic [1:0]          own_req_rgn = '0, own_req_val = '0;
  logic [NRGN*2-1:0]   own_state;
  logic                busy, err_sticky, err_port;
  logic [2:0]          err_code;
  logic [AW-1:0]       err_addr;
  logic [31:0]         err_cnt;
  logic [`SF_PC_N*32-1:0] perf;
  logic [NB*32-1:0]    pba, pbc;
  logic [1:0]          e1, e2, e3;

  sf_vector_scratchpad #(.AW(AW), .VEC_BYTES(VEC_BYTES), .BANK_BYTES(BB), .NB(NB), .DEPTH(DEPTH), .DMA_BYTES(4), .NRGN(NRGN),
                         .SIM_INIT(1), .OWN_RESET(`SF_VM_OWN_VEC)) dut (
    .clk(clk), .rst_n(rst_n),
    .v_req_valid(v_req_valid), .v_req_ready(v_req_ready), .v_req_we(v_req_we), .v_req_mode(2'd0), .v_req_addr(v_req_addr),
    .v_req_stride({AW{1'b0}}), .v_req_idx(1'b0), .v_req_mask(v_req_mask), .v_req_wdata(v_req_wdata), .v_req_id(8'd0),
    .v_rsp_valid(v_rsp_valid), .v_rsp_ready(v_rsp_ready), .v_rsp_rdata(v_rsp_rdata), .v_rsp_id(v_rsp_id), .v_rsp_we(v_rsp_we), .v_rsp_status(v_rsp_status),
    .d_req_valid(d_req_valid), .d_req_ready(d_req_ready), .d_req_write(d_req_write), .d_req_addr(d_req_addr), .d_req_wdata(d_req_wdata),
    .d_req_wstrb(d_req_wstrb), .d_rsp_valid(d_rsp_valid), .d_rsp_ready(d_rsp_ready), .d_rsp_rdata(d_rsp_rdata), .d_rsp_error(d_rsp_error),
    .d_rsp_err_code(d_rsp_err_code),
    .own_req_valid(own_req_valid), .own_req_ready(own_req_ready), .own_req_rgn(own_req_rgn), .own_req_val(own_req_val),
    .own_ack_o(own_ack), .own_err_o(own_err), .own_state_o(own_state),
    .err_clear_i(1'b0), .busy_o(busy), .err_sticky_o(err_sticky), .err_code_o(err_code), .err_addr_o(err_addr), .err_port_o(err_port),
    .err_cnt_o(err_cnt), .perf_clear_i(1'b0), .perf_o(perf), .perf_bank_acc_o(pba), .perf_bank_conf_o(pbc),
    .ev_spm_read_o(e1), .ev_spm_write_o(e2), .ev_spm_conflict_o(e3));

  // ---------------------------------------------------------------- CloudDMA (the real module)
  logic        cmd_valid = 1'b0, cmd_ready, cmd_dir = 1'b0, done_valid, done_commit, dma_busy;
  logic [31:0] cmd_haddr = '0, cmd_saddr = '0, cmd_len = '0, done_bytes, sm_req_addr, sm_req_wdata, sm_rsp_rdata;
  logic [7:0]  done_err;
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr, hm_req_wdata, hm_rsp_rdata;
  logic [3:0]  hm_req_wstrb, sm_req_wstrb;
  logic        sm_req_valid, sm_req_ready, sm_req_write, sm_rsp_valid, sm_rsp_ready, sm_rsp_error;
  logic        ev_h2d, ev_d2h;
  logic [7:0]  ev_bytes;
  sfd_clouddma #(.DW(32), .AW(32)) cdma (
    .clk(clk), .rst_n(rst_n), .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_dir(cmd_dir), .cmd_haddr(cmd_haddr), .cmd_saddr(cmd_saddr), .cmd_len(cmd_len),
    .done_valid(done_valid), .done_err(done_err), .done_bytes(done_bytes), .done_commit(done_commit), .busy(dma_busy),
    .hm_req_valid(hm_req_valid), .hm_req_ready(hm_req_ready), .hm_req_write(hm_req_write), .hm_req_addr(hm_req_addr), .hm_req_wdata(hm_req_wdata),
    .hm_req_wstrb(hm_req_wstrb), .hm_rsp_valid(hm_rsp_valid), .hm_rsp_ready(hm_rsp_ready), .hm_rsp_rdata(hm_rsp_rdata), .hm_rsp_error(hm_rsp_error),
    .sm_req_valid(sm_req_valid), .sm_req_ready(sm_req_ready), .sm_req_write(sm_req_write), .sm_req_addr(sm_req_addr), .sm_req_wdata(sm_req_wdata),
    .sm_req_wstrb(sm_req_wstrb), .sm_rsp_valid(sm_rsp_valid), .sm_rsp_ready(sm_rsp_ready), .sm_rsp_rdata(sm_rsp_rdata), .sm_rsp_error(sm_rsp_error),
    .g_viol(1'b0), .ev_h2d_beat(ev_h2d), .ev_d2h_beat(ev_d2h), .ev_beat_bytes(ev_bytes));

  // CloudDMA's SRAM master -> the scratchpad DMA port (the SFB2 single-beat fields map one to one)
  assign d_req_valid   = sm_req_valid;
  assign sm_req_ready  = d_req_ready;
  assign d_req_write   = sm_req_write;
  assign d_req_addr    = sm_req_addr[AW-1:0];
  assign d_req_wdata   = sm_req_wdata;
  assign d_req_wstrb   = sm_req_wstrb;
  assign sm_rsp_valid  = d_rsp_valid;
  assign d_rsp_ready   = sm_rsp_ready;
  assign sm_rsp_rdata  = d_rsp_rdata;
  assign sm_rsp_error  = d_rsp_error;
  wire unused_hi = &{1'b0, sm_req_addr[31:AW], d_rsp_err_code, err_code, err_addr, err_port, err_cnt, err_sticky, perf, pba, pbc, e1, e2, e3,
                     done_valid, dma_busy, ev_h2d, ev_d2h, ev_bytes, own_err, v_rsp_id, v_rsp_we, busy};

  // ---------------------------------------------------------------- host memory: SFB2 single-beat slave, 1 request at a time
  byte unsigned hmem [HSZ];
  logic        hm_pend;
  logic        hm_pend_w;
  logic [31:0] hm_pend_a, hm_pend_d;
  logic [3:0]  hm_pend_s;
  assign hm_req_ready = !hm_pend;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin hm_pend <= 1'b0; hm_rsp_valid <= 1'b0; hm_rsp_rdata <= '0; hm_rsp_error <= 1'b0; end
    else begin
      if (hm_req_valid && hm_req_ready) begin
        hm_pend <= 1'b1;  hm_pend_w <= hm_req_write; hm_pend_a <= hm_req_addr; hm_pend_d <= hm_req_wdata; hm_pend_s <= hm_req_wstrb;
      end else if (hm_pend && !hm_rsp_valid) begin
        hm_rsp_valid <= 1'b1;
        hm_rsp_error <= (hm_pend_a + 4 > HSZ);
        hm_rsp_rdata <= '0;
        if (hm_pend_a + 4 <= HSZ) begin
          if (hm_pend_w) begin
            for (int b = 0; b < 4; b++) if (hm_pend_s[b]) hmem[hm_pend_a + b] <= hm_pend_d[b*8 +: 8];
          end else begin
            for (int b = 0; b < 4; b++) hm_rsp_rdata[b*8 +: 8] <= hmem[hm_pend_a + b];
          end
        end
      end else if (hm_rsp_valid && hm_rsp_ready) begin
        hm_rsp_valid <= 1'b0; hm_pend <= 1'b0;
      end
    end
  end

  // ---------------------------------------------------------------- model, randomness, checks
  byte unsigned ref_mem [CAP];
  byte unsigned href [HSZ];
  int n_checks = 0, n_err = 0, n_tests = 0;
  logic [31:0] rng = SEED;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 17); rng = rng ^ (rng << 5);
    return rng;
  endfunction
  task automatic check(input bit c, input string m);
    n_checks++;
    if (!c) begin n_err++; if (n_err <= 20) $display("  [FAIL] %s", m); end
  endtask

  // vector-port helpers (blocking, one request at a time)
  task automatic vreq(input bit we, input longint a, input logic [VEC_BYTES-1:0] mk, input logic [VEC_W-1:0] wd,
                      output logic [VEC_W-1:0] rd, output logic [2:0] st);
    @(posedge clk); #1;
    v_req_valid = 1'b1; v_req_we = we; v_req_addr = AW'(a); v_req_mask = mk; v_req_wdata = wd;
    @(posedge clk);
    while (!v_req_ready) @(posedge clk);
    #1 v_req_valid = 1'b0;
    @(posedge clk);
    while (!v_rsp_valid) @(posedge clk);
    rd = v_rsp_rdata; st = v_rsp_status;
  endtask
  task automatic vstore(input longint a, input logic [VEC_BYTES-1:0] mk, input logic [VEC_W-1:0] wd);
    logic [VEC_W-1:0] r; logic [2:0] s;
    vreq(1'b1, a, mk, wd, r, s);
    check(s == `SF_ST_OK, $sformatf("vector store status %0d", s));
    for (int j = 0; j < VEC_BYTES; j++) if (mk[j]) ref_mem[a + j] = wd[j*8 +: 8];
  endtask
  task automatic vload_check(input longint a, input string what);
    logic [VEC_W-1:0] r; logic [2:0] s; bit ok;
    vreq(1'b0, a, {VEC_BYTES{1'b1}}, '0, r, s);
    ok = (s == `SF_ST_OK);
    for (int j = 0; j < VEC_BYTES; j++) if (r[j*8 +: 8] !== ref_mem[a + j]) ok = 0;
    check(ok, $sformatf("%s: vector load of %0d differs from the model", what, a));
  endtask
  task automatic set_owner(input int rgn, input int val);
    @(posedge clk); #1; own_req_valid = 1'b1; own_req_rgn = 2'(rgn); own_req_val = 2'(val);
    @(posedge clk); while (!own_req_ready) @(posedge clk);
    #1 own_req_valid = 1'b0;
    @(posedge clk); while (!own_ack) @(posedge clk);
  endtask
  // one CloudDMA job; returns its completion fields
  logic [7:0] r_err; logic [31:0] r_bytes; logic r_commit;
  task automatic dma_job(input bit dir, input longint haddr, input longint saddr, input longint len);
    @(posedge clk); #1;
    cmd_valid = 1'b1; cmd_dir = dir; cmd_haddr = 32'(haddr); cmd_saddr = 32'(saddr); cmd_len = 32'(len);
    @(posedge clk);
    while (!cmd_ready) @(posedge clk);
    #1 cmd_valid = 1'b0;
    @(posedge clk);
    while (!done_valid) @(posedge clk);
    r_err = done_err; r_bytes = done_bytes; r_commit = done_commit;
  endtask
  task automatic compare_array(input string what);
    int bank, row, bad;
    bad = 0;
    for (int w = 0; w < NB * DEPTH; w++) begin
      bank = w % NB; row = w / NB;
      begin
        logic [BB*8-1:0] wv;
        force_idx = row;
        #1;
        wv = bd_word[bank*BB*8 +: BB*8];
        for (int j = 0; j < BB; j++) begin n_checks++; if (wv[j*8 +: 8] !== ref_mem[w*BB + j]) bad++; end
      end
    end
    if (bad != 0) begin n_err++; $display("  [FAIL] %s: backdoor mismatch, %0d bytes", what, bad); end
  endtask
  int force_idx = 0;
  logic [NB*BB*8-1:0] bd_word;
  genvar gb;
  generate
    for (gb = 0; gb < NB; gb++) begin : g_bd
      assign bd_word[gb*BB*8 +: BB*8] = dut.u_banks.g_bank[gb].u_wrap.g_behav.u_mem.mem[force_idx];
    end
  endgenerate

  // ---------------------------------------------------------------- the test
  logic [VEC_W-1:0] dv;
  longint lens [10];
  initial begin
    for (int i = 0; i < CAP; i++) ref_mem[i] = 8'h00;
    for (int i = 0; i < HSZ; i++) begin hmem[i] = 8'h00; href[i] = 8'h00; end
    lens[0] = 64; lens[1] = 37; lens[2] = 1; lens[3] = 4; lens[4] = 5; lens[5] = 3; lens[6] = 255; lens[7] = 8; lens[8] = 129; lens[9] = 2;
    rst_n = 1'b0; repeat (4) @(posedge clk); #2 rst_n = 1'b1; repeat (3) @(posedge clk);

    // 1 pre-fill region 1 (vector owns it)
    n_tests++;
    for (int a = RGN; a < 2 * RGN; a += VEC_BYTES) begin
      for (int i = 0; i < VEC_BYTES / 4; i++) dv[i*32 +: 32] = rnd();
      vstore(a, {VEC_BYTES{1'b1}}, dv);
    end
    compare_array("pre-fill");

    // 2 H2D with ragged lengths, region 1 owned by the DMA
    n_tests++;
    set_owner(1, `SF_VM_OWN_DMA);
    for (int t = 0; t < 10; t++) begin
      longint hsrc, sdst, ln;
      ln = lens[t];
      hsrc = 64 + 8 * t + 4 * (t % 3) * 4;                     // beat aligned (multiples of 4)
      hsrc = hsrc & ~64'd3;
      sdst = RGN + 4 * (rnd() % 16);                           // beat aligned inside region 1
      if (sdst + ln > 2 * RGN) ln = 2 * RGN - sdst;
      for (int i = 0; i < ln + 8; i++) begin hmem[hsrc + i] = rnd(); href[hsrc + i] = hmem[hsrc + i]; end
      dma_job(1'b0, hsrc, sdst, ln);
      check(r_err == ERR_NONE, $sformatf("H2D len %0d: done_err %0h", ln, r_err));
      check(r_bytes == ln, $sformatf("H2D len %0d: done_bytes %0d", ln, r_bytes));
      for (int i = 0; i < ln; i++) ref_mem[sdst + i] = href[hsrc + i];
    end
    // 3 hand region 1 back: the vector port sees exactly the model (bytes after each ragged tail untouched)
    n_tests++;
    set_owner(1, `SF_VM_OWN_VEC);
    for (int a = RGN; a < 2 * RGN; a += VEC_BYTES) vload_check(a, "after H2D");
    compare_array("after H2D");

    // 4 D2H extraction into a pre-filled host buffer: bytes outside [dst, dst+len) must stay
    n_tests++;
    set_owner(1, `SF_VM_OWN_DMA);
    for (int t = 0; t < 10; t++) begin
      longint hdst, ssrc, ln;
      ln = lens[(t + 3) % 10];
      hdst = (1024 + 256 * (t % 6)) & ~64'd3;
      ssrc = RGN + 4 * (rnd() % 16);
      if (ssrc + ln > 2 * RGN) ln = 2 * RGN - ssrc;
      for (int i = 0; i < 300; i++) begin hmem[hdst + i] = rnd(); href[hdst + i] = hmem[hdst + i]; end
      dma_job(1'b1, hdst, ssrc, ln);
      check(r_err == ERR_NONE && r_commit, $sformatf("D2H len %0d: err %0h commit %0d", ln, r_err, r_commit));
      check(r_bytes == ln, $sformatf("D2H len %0d: done_bytes %0d", ln, r_bytes));
      for (int i = 0; i < ln; i++) href[hdst + i] = ref_mem[ssrc + i];
      for (int i = 0; i < 300; i++) begin n_checks++; if (hmem[hdst + i] !== href[hdst + i]) begin n_err++; if (n_err <= 20) $display("  [FAIL] D2H len %0d: host byte %0d is %0h exp %0h", ln, i, hmem[hdst + i], href[hdst + i]); end end
    end

    // 5 error paths: nothing may change anywhere
    n_tests++;
    for (int t = 0; t < 8; t++) hmem[2048 + t] = 8'hC0 + t;
    for (int t = 0; t < 8; t++) href[2048 + t] = 8'hC0 + t;
    dma_job(1'b0, 2048, 0, 8);                                    // H2D into region 0 (owned by the vector port)
    check(r_err == ERR_SRAM_RESP && !r_commit, $sformatf("foreign-region H2D: err %0h", r_err));
    dma_job(1'b1, 2304, 0, 8);                                    // D2H out of region 0
    check(r_err == ERR_SRAM_RESP && !r_commit, $sformatf("foreign-region D2H: err %0h", r_err));
    dma_job(1'b0, 2048, CAP, 8);                                  // outside the aperture
    check(r_err == ERR_SRAM_RESP && !r_commit, $sformatf("out-of-range H2D: err %0h", r_err));
    dma_job(1'b0, 2048, RGN + 2, 8);                              // SRAM address not beat aligned
    check(r_err == ERR_SRAM_RESP && !r_commit, $sformatf("misaligned H2D: err %0h", r_err));
    dma_job(1'b1, 2560, RGN + 6, 8);
    check(r_err == ERR_SRAM_RESP && !r_commit, $sformatf("misaligned D2H: err %0h", r_err));
    for (int t = 0; t < 8; t++) check(hmem[2560 + t] === href[2560 + t], "host memory changed by a failed D2H");
    // all of that must not have changed the scratchpad
    set_owner(1, `SF_VM_OWN_VEC);
    for (int a = 0; a < CAP; a += VEC_BYTES) vload_check(a, "after error paths");
    compare_array("final");

    $display("RESULT clouddma_int tests=%0d checks=%0d errors=%0d cycles=0 %s", n_tests, n_checks, n_err, (n_err == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #200000000; $display("RESULT clouddma_int TIMEOUT errors=1 FAIL"); $finish; end
endmodule
