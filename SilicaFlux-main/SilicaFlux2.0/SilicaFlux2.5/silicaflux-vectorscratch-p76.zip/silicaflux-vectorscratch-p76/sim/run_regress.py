#!/usr/bin/env python3
"""SilicaFlux VectorScratch regression runner (Verilator 5.x, --binary --timing; optional Icarus cross-run).

  python3 sim/run_regress.py [--jobs 4] [--only NAME ...] [--icarus] [--out reports/regress.json]
  python3 sim/run_regress.py --list

A CASE is a set of -G overrides of tb_vspm.  Each case is built into build/reg/<name>/ and run; it PASSES only when the
testbench printed a RESULT line with errors=0 and PASS, the process exited 0 and no assertion / $fatal text appeared.
Nothing is assumed: a missing RESULT line is a failure.
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES_F = os.path.join(ROOT, "sim", "files_rtl.f")
VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-DECLFILENAME", "--assert", "-DSF_ASSERT"]

def C(name, **ov):
    return dict(name=name, over=ov)

# widths are bytes: VEC_BYTES 16 = 128 bit, 32 = 256 bit, 64 = 512 bit (the "wider vectors" path)
CASES = [
    # ---- the three user-visible stages on the default 128-bit shape (staged runs of the same testbench)
    C("stage1_aligned128", STAGE=1),
    C("stage2_masks128", STAGE=2),
    C("stage3_misaligned128", STAGE=3),
    C("stage4_dma128", STAGE=4),
    C("full128"),
    # ---- 256-bit
    C("stage1_aligned256", VEC_BYTES=32, NB=8, DEPTH=64, STAGE=1),
    C("stage2_masks256", VEC_BYTES=32, NB=8, DEPTH=64, STAGE=2),
    C("full256_nb8", VEC_BYTES=32, NB=8, DEPTH=64),
    C("full256_nb4_conflicts", VEC_BYTES=32, NB=4, DEPTH=128),
    C("full256_nb16", VEC_BYTES=32, NB=16, DEPTH=32),
    C("full256_dma32", VEC_BYTES=32, NB=8, DEPTH=64, DMA_BYTES=32),
    # ---- wider path
    C("full512_nb16", VEC_BYTES=64, NB=16, DEPTH=32, DMA_BYTES=32, NRAND=600),
    C("full512_nb8", VEC_BYTES=64, NB=8, DEPTH=64, NRAND=600),
    # ---- banking
    C("nb8_128", NB=8, DEPTH=32),
    C("nb2_128", NB=2, DEPTH=128),
    C("nb1_128_single_bank", NB=1, DEPTH=256),
    C("map_xor_128", BANK_MAP=1),
    C("map_block_128", BANK_MAP=2),
    C("map_xor_256", VEC_BYTES=32, NB=8, DEPTH=64, BANK_MAP=1),
    C("map_block_256", VEC_BYTES=32, NB=8, DEPTH=64, BANK_MAP=2),
    # ---- alignment policies (A: reject)
    C("align_vec_128", ALIGN_POLICY=0),
    C("align_word_128", ALIGN_POLICY=1),
    C("align_vec_256", ALIGN_POLICY=0, VEC_BYTES=32, NB=8, DEPTH=64),
    C("align_word_256", ALIGN_POLICY=1, VEC_BYTES=32, NB=8, DEPTH=64),
    # ---- bank word width (SRAM data width independent of the vector width)
    C("bank8B_128", BANK_BYTES=8, NB=4, DEPTH=32),
    C("bank8B_256", BANK_BYTES=8, VEC_BYTES=32, NB=4, DEPTH=32),
    C("bank16B_128_oldstyle", BANK_BYTES=16, NB=4, DEPTH=16, DMA_BYTES=16),
    C("bank16B_256", BANK_BYTES=16, VEC_BYTES=32, NB=4, DEPTH=16, DMA_BYTES=16),
    # ---- strided / gather / scatter (optional)
    C("gs_128", GS_EN=1),
    C("gs_256", GS_EN=1, VEC_BYTES=32, NB=8, DEPTH=64),
    C("gs_128_es8", GS_EN=1, GS_ES=8),
    C("gs_128_xor", GS_EN=1, BANK_MAP=1),
    C("gs_256_nb4", GS_EN=1, VEC_BYTES=32, NB=4, DEPTH=128),
    # ---- pipeline depth / queues
    C("lat2_128", READ_LATENCY=2, CQ_DEPTH=8),
    C("lat3_128", READ_LATENCY=3, CQ_DEPTH=10),
    C("lat3_256", READ_LATENCY=3, CQ_DEPTH=10, VEC_BYTES=32, NB=8, DEPTH=64),
    C("cq2_dmacq2", CQ_DEPTH=2, DMA_CQ_DEPTH=2),
    C("cq3_lat2", CQ_DEPTH=3, DMA_CQ_DEPTH=3, READ_LATENCY=2),
    # ---- DMA
    C("dma4B", DMA_BYTES=4),
    C("dma8B", DMA_BYTES=8),
    C("dma_off", DMA_EN=0, STAGE=3),
    C("arb_vec_priority", ARB_POLICY=0),
    C("arb_dma_priority", ARB_POLICY=1),
    C("nrgn2", NRGN=2),
    C("nrgn8", NRGN=8, DEPTH=128),
    # ---- memory backends / initial contents
    C("poison_init", SIM_INIT=2),
    C("backend_fpga_bram", BACKEND=1),
    C("backend_asic_standin_L2", BACKEND=2, READ_LATENCY=2, DEPTH=256, CQ_DEPTH=8, NRAND=600),
    # ---- seeds
    C("seed2", SEED=0x1234ABCD),
    C("seed3_256", SEED=0x0BADF00D, VEC_BYTES=32, NB=8, DEPTH=64),
]

def build_args(c):
    return [f"-G{k}={v}" for k, v in c["over"].items()] + [f'-GNAME="{c["name"]}"']

def run_case(c, out_root, icarus=False):
    d = os.path.join(out_root, c["name"])
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    t0 = time.time()
    if icarus:
        # Icarus cross-run: same testbench, -P overrides, plain 2012 mode
        if c["over"].get("BACKEND") == 2:      # the vendored SKY130 adapter has an Icarus-only part-select limitation: Verilator only
            return dict(name=c["name"], status="SKIPPED", detail="BACKEND=2 (vendored sf_sram_asic_sky130.sv does not elaborate in Icarus 12)")
        ov = [f"-Ptb_vspm.{k}={v}" for k, v in c["over"].items()] + [f'-Ptb_vspm.NAME="{c["name"]}"']
        cmd = ["iverilog", "-g2012", "-o", os.path.join(d, "simv.vvp"), "-DSF_ASSERT"] + ov + ["-f", FILES_F, os.path.join(ROOT, "tb", "tb_vspm.sv"), "-s", "tb_vspm"]
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
        if r.returncode != 0:
            return dict(name=c["name"], status="BUILD-FAIL", detail=(r.stdout + r.stderr)[-400:])
        r = subprocess.run(["vvp", os.path.join(d, "simv.vvp")], cwd=ROOT, capture_output=True, text=True, timeout=3000)
    else:
        cmd = ["verilator"] + VFLAGS + ["--top-module", "tb_vspm", "-f", FILES_F, os.path.join("tb", "tb_vspm.sv"), "-Mdir", d, "-o", "simv"] + build_args(c)
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
        if r.returncode != 0:
            return dict(name=c["name"], status="BUILD-FAIL", detail=(r.stdout + r.stderr)[-400:])
        r = subprocess.run([os.path.join(d, "simv")], cwd=ROOT, capture_output=True, text=True, timeout=3000)
    out = r.stdout + r.stderr
    m = re.search(r"RESULT (\S+) tests=(\d+) checks=(\d+) errors=(\d+) cycles=(\d+) (PASS|FAIL)", out)
    bad = re.search(r"%Error|Assertion|assert.*fail|\$fatal|TIMEOUT", out, re.I)
    if not m:
        return dict(name=c["name"], status="FAIL", detail="no RESULT line: " + out[-300:].replace("\n", " "))
    tests, checks, errs, cycles, verdict = int(m.group(2)), int(m.group(3)), int(m.group(4)), int(m.group(5)), m.group(6)
    ok = (verdict == "PASS" and errs == 0 and r.returncode == 0 and not bad)
    first = next((l.strip() for l in out.splitlines() if "[FAIL]" in l), "")
    return dict(name=c["name"], status="PASS" if ok else "FAIL", tests=tests, checks=checks, errors=errs, cycles=cycles,
                secs=round(time.time() - t0, 1), detail=first[:200], over=c["over"])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--icarus", action="store_true")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    if a.list:
        for c in CASES: print(c["name"], c["over"])
        return 0
    cases = [c for c in CASES if not a.only or c["name"] in a.only]
    out_root = os.path.join(ROOT, "build", "icarus" if a.icarus else "reg")
    os.makedirs(out_root, exist_ok=True)
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(lambda c: run_case(c, out_root, a.icarus), cases))
    npass = sum(1 for r in res if r["status"] == "PASS")
    nskip = sum(1 for r in res if r["status"] == "SKIPPED")
    tot_checks = sum(r.get("checks", 0) for r in res)
    out = a.out or os.path.join(ROOT, "reports", "regress_icarus.json" if a.icarus else "regress.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    tool = subprocess.run(["iverilog" if a.icarus else "verilator", "-V" if a.icarus else "--version"], capture_output=True, text=True).stdout.splitlines()[0]
    json.dump(dict(tool=tool, passed=npass, skipped=nskip, total=len(res) - nskip, checks=tot_checks, results=res), open(out, "w"), indent=1)
    for r in res:
        print(f"{r['name']:30s} {r['status']:10s} tests={r.get('tests','-')} checks={r.get('checks','-')} errors={r.get('errors','-')} {r.get('secs','-')}s {r.get('detail','')[:100]}")
    print(f"{npass}/{len(res) - nskip} cases PASS ({nskip} skipped), {tot_checks} checks")
    return 0 if npass == len(res) - nskip else 1

if __name__ == "__main__":
    sys.exit(main())
