// package (compile before any testbench that imports it)
rtl/sf_vmem_pkg.sv
