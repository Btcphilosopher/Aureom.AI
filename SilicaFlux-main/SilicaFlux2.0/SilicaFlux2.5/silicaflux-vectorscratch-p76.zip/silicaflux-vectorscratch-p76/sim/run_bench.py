#!/usr/bin/env python3
"""Reproducible bandwidth / latency sweep of sf_vector_scratchpad (Verilator RTL simulation of tb/tb_bench.sv).

  python3 sim/run_bench.py [--jobs 4] [--only NAME ...]   ->  reports/bench.csv, reports/bench.json

Every row is one (configuration, workload) pair measured on the RTL.  The deterministic workloads are ALSO predicted by an
independent Python model (sum over requests of the busiest-bank load, plus pipeline fill READ_LATENCY + 2) and the two must
agree: this is the check that the measured stall behaviour is the bank-conflict behaviour and nothing else.
"""
import argparse, csv, json, os, re, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES_F = os.path.join(ROOT, "sim", "files_rtl.f")
VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-DECLFILENAME", "--assert", "-DSF_ASSERT"]
NREQ = 2000

def C(name, **ov):
    d = dict(VEC_BYTES=16, BANK_BYTES=4, NB=4, DEPTH=256, BANK_MAP=0, ALIGN_POLICY=2, GS_EN=0, GS_ES=4, READ_LATENCY=1, CQ_DEPTH=8, DMA_BYTES=16, ARB_POLICY=2)
    d.update(ov)
    d["NAME"] = name
    return d

CONFIGS = [
    # 128-bit vectors
    C("v128_nb2_low", NB=2, DEPTH=512),
    C("v128_nb4_low"),
    C("v128_nb8_low", NB=8, DEPTH=128),
    C("v128_nb4_xor", BANK_MAP=1),
    C("v128_nb4_block", BANK_MAP=2),
    C("v128_nb4_low_alignword", ALIGN_POLICY=1),
    C("v128_nb4_low_alignvec", ALIGN_POLICY=0),
    C("v128_bank16B_nb4", BANK_BYTES=16, DEPTH=64),
    C("v128_nb4_low_lat2", READ_LATENCY=2, CQ_DEPTH=10),
    C("v128_nb4_low_lat3", READ_LATENCY=3, CQ_DEPTH=12),
    C("v128_nb4_dma4B", DMA_BYTES=4),
    C("v128_nb4_arb_vec", ARB_POLICY=0),
    C("v128_nb4_arb_dma", ARB_POLICY=1),
    # 256-bit vectors
    C("v256_nb4_low", VEC_BYTES=32, NB=4, DEPTH=256),
    C("v256_nb8_low", VEC_BYTES=32, NB=8, DEPTH=128),
    C("v256_nb16_low", VEC_BYTES=32, NB=16, DEPTH=64),
    C("v256_nb8_xor", VEC_BYTES=32, NB=8, DEPTH=128, BANK_MAP=1),
    C("v256_nb8_block", VEC_BYTES=32, NB=8, DEPTH=128, BANK_MAP=2),
    C("v256_bank8B_nb4", VEC_BYTES=32, BANK_BYTES=8, NB=4, DEPTH=128),
    C("v256_bank16B_nb4", VEC_BYTES=32, BANK_BYTES=16, NB=4, DEPTH=64),
    # wider path
    C("v512_nb16_low", VEC_BYTES=64, NB=16, DEPTH=64, DMA_BYTES=32),
    # strided / gather / scatter
    C("v128_nb4_low_gs", GS_EN=1),
    C("v128_nb8_low_gs", GS_EN=1, NB=8, DEPTH=128),
    C("v128_nb4_xor_gs", GS_EN=1, BANK_MAP=1),
    C("v256_nb8_low_gs", VEC_BYTES=32, NB=8, DEPTH=128, GS_EN=1),
    C("v256_nb8_xor_gs", VEC_BYTES=32, NB=8, DEPTH=128, GS_EN=1, BANK_MAP=1),
]

# ------------------------------------------------------------------ independent analytical model
def bank_of(w, c):
    nb, dp, m = c["NB"], c["DEPTH"], c["BANK_MAP"]
    if m == 1: return (w % nb) ^ ((w // nb) % nb)
    if m == 2: return w // dp
    return w % nb

def cyc_contig(addr, mask, c):
    """bank cycles of one isolated contiguous request: max number of its words on one bank"""
    bb, vb = c["BANK_BYTES"], c["VEC_BYTES"]
    off, w0 = addr % bb, addr // bb
    words = {}
    for j in range(vb):
        if (mask >> j) & 1:
            words[(off + j) // bb] = 1
    load = {}
    for k in words:
        b = bank_of(w0 + k, c)
        load[b] = load.get(b, 0) + 1
    return max(load.values()) if load else 0

def cyc_elem(addr, stride, mask, c):
    bb, vb, es = c["BANK_BYTES"], c["VEC_BYTES"], c["GS_ES"]
    load = {}
    for l in range(vb // es):
        ea = addr + l * stride
        for sub in range(es // bb):
            if any((mask >> (l * es + sub * bb + i)) & 1 for i in range(bb)):
                b = bank_of(ea // bb + sub, c)
                load[b] = load.get(b, 0) + 1
    return max(load.values()) if load else 0

def predict(c, wl):
    """predicted cycles for a deterministic single-port workload, or None"""
    vb, bb, nb, dp = c["VEC_BYTES"], c["BANK_BYTES"], c["NB"], c["DEPTH"]
    cap = nb * dp * bb
    rgn = cap // 4
    vspan = rgn * 3
    full = (1 << vb) - 1
    fill = c["READ_LATENCY"] + 2
    seq = lambda f, n=NREQ: sum(cyc_contig(f(i), full, c) for i in range(n))
    if wl in ("seq_load_aligned", "seq_store_aligned"):
        return seq(lambda i: (i * vb) % vspan) + fill
    if wl == "copy_aligned":
        return sum(cyc_contig((i * vb) % (vspan // 2), full, c) + cyc_contig(vspan // 2 + (i * vb) % (vspan // 2), full, c) for i in range(NREQ)) + fill
    if wl == "fp32_triad_aligned":
        t = 0
        for i in range(NREQ // 2):
            t += cyc_contig((i * vb) % (vspan // 3), full, c) + cyc_contig(vspan // 3 + (i * vb) % (vspan // 3), full, c) + cyc_contig(2 * (vspan // 3) + (i * vb) % (vspan // 3), full, c)
        return t + fill
    if wl in ("seq_load_off1word", "seq_store_off1word"):
        return seq(lambda i: (i * vb + bb) % (vspan - 2 * vb)) + fill
    if wl in ("seq_load_off1byte", "seq_store_off1byte"):
        return seq(lambda i: (i * vb + 1) % (vspan - 2 * vb)) + fill
    if wl == "tail_masked_store":
        t = 0
        for i in range(NREQ // 3):
            base = (i * 4 * vb) % (vspan - 4 * vb)
            t += cyc_contig(base, full, c) + cyc_contig(base + vb, full, c) + cyc_contig(base + 2 * vb, (1 << (vb - 4)) - 1, c)
        return t + fill
    if wl == "gs_stride_1elem":
        return sum(cyc_elem((i * 64) % (vspan // 2), c["GS_ES"], full, c) for i in range(NREQ)) + fill
    if wl == "gs_stride_nb_words":
        return sum(cyc_elem((i * 64) % (vspan // 2), nb * bb, full, c) for i in range(NREQ)) + fill
    if wl == "gs_stride_5elem":
        return sum(cyc_elem((i * 64) % (vspan // 2), c["GS_ES"] * 5, full, c) for i in range(NREQ)) + fill
    return None

# ------------------------------------------------------------------ run
def run_cfg(c, out_root):
    d = os.path.join(out_root, c["NAME"])
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    gs = [f"-G{k}={v}" for k, v in c.items() if k != "NAME"] + [f'-GNAME="{c["NAME"]}"', f"-GNREQ={NREQ}"]
    r = subprocess.run(["verilator"] + VFLAGS + ["--top-module", "tb_bench", "-f", FILES_F, "tb/tb_bench.sv", "-Mdir", d, "-o", "simv"] + gs,
                       cwd=ROOT, capture_output=True, text=True)
    if r.returncode != 0:
        return c["NAME"], None, "BUILD-FAIL " + (r.stdout + r.stderr)[-300:]
    r = subprocess.run([os.path.join(d, "simv")], cwd=ROOT, capture_output=True, text=True, timeout=3000)
    rows = [l for l in r.stdout.splitlines() if l.startswith("BENCH,")]
    res = re.search(r"RESULT .* errors=(\d+) .* (PASS|FAIL)", r.stdout)
    ok = res and res.group(2) == "PASS" and res.group(1) == "0"
    return c["NAME"], rows, None if ok else "TB reported FAIL: " + r.stdout[-300:]

FIELDS = ["config", "workload", "dma_duty", "vec_req", "completed", "cycles", "useful_bytes", "v_word_acc", "conf_stall", "arb_stall", "align_xtra", "split_req",
          "rd_lat_sum", "rd_cnt", "wr_lat_sum", "wr_cnt", "starve", "req_blocked", "rsp_bp", "dma_req", "dma_bytes", "dma_arb_stall", "dma_blocked",
          "bank_acc_total", "dma_words", "max_bank_acc"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", nargs="*")
    a = ap.parse_args()
    cfgs = [c for c in CONFIGS if not a.only or c["NAME"] in a.only]
    out_root = os.path.join(ROOT, "build", "bench")
    os.makedirs(out_root, exist_ok=True)
    with ThreadPoolExecutor(a.jobs) as ex:
        results = list(ex.map(lambda c: run_cfg(c, out_root), cfgs))
    by_name = {c["NAME"]: c for c in CONFIGS}
    allrows, problems, model_checks, model_bad = [], [], 0, []
    for name, rows, err in results:
        if err:
            problems.append((name, err))
            continue
        c = by_name[name]
        for line in rows:
            f = line.split(",")[1:]
            rec = dict(zip(FIELDS, [f[0]] + [f[1]] + [int(x) for x in f[2:]]))
            rec["workload"] = f[1]
            rec["config"] = f[0]
            cfg = by_name[name]
            rec["VEC_BYTES"], rec["BANK_BYTES"], rec["NB"], rec["BANK_MAP"], rec["ALIGN_POLICY"] = cfg["VEC_BYTES"], cfg["BANK_BYTES"], cfg["NB"], cfg["BANK_MAP"], cfg["ALIGN_POLICY"]
            rec["READ_LATENCY"], rec["ARB_POLICY"], rec["GS_EN"], rec["DMA_BYTES"] = cfg["READ_LATENCY"], cfg["ARB_POLICY"], cfg["GS_EN"], cfg["DMA_BYTES"]
            rec["bytes_per_cycle"] = round(rec["useful_bytes"] / rec["cycles"], 3)
            rec["peak_vec_bytes"] = cfg["VEC_BYTES"]
            rec["bank_ceiling_bytes"] = cfg["NB"] * cfg["BANK_BYTES"]
            rec["bank_util"] = round(rec["bank_acc_total"] / (cfg["NB"] * rec["cycles"]), 4)
            rec["rd_lat_avg"] = round(rec["rd_lat_sum"] / rec["rd_cnt"], 3) if rec["rd_cnt"] else None
            rec["wr_lat_avg"] = round(rec["wr_lat_sum"] / rec["wr_cnt"], 3) if rec["wr_cnt"] else None
            rec["vec_req_per_cycle"] = round(rec["completed"] / rec["cycles"], 4)
            rec["starved"] = int(rec["completed"] < rec["vec_req"])
            if rec["dma_duty"] == 0 and not rec["workload"].startswith("iso_") and not rec["workload"].startswith("random") and "gather" not in rec["workload"] and "scatter" not in rec["workload"]:
                p = predict(cfg, rec["workload"])
                if p is not None:
                    model_checks += 1
                    rec["model_cycles"] = p
                    if p != rec["cycles"]:
                        model_bad.append((name, rec["workload"], rec["cycles"], p))
            allrows.append(rec)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    cols = FIELDS + ["bytes_per_cycle", "peak_vec_bytes", "bank_ceiling_bytes", "bank_util", "rd_lat_avg", "wr_lat_avg", "vec_req_per_cycle", "starved", "model_cycles",
                     "VEC_BYTES", "BANK_BYTES", "NB", "BANK_MAP", "ALIGN_POLICY", "READ_LATENCY", "ARB_POLICY", "GS_EN", "DMA_BYTES"]
    with open(os.path.join(ROOT, "reports", "bench.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in allrows: w.writerow(r)
    json.dump(dict(rows=allrows, problems=problems, model_checks=model_checks, model_mismatches=model_bad), open(os.path.join(ROOT, "reports", "bench.json"), "w"), indent=1)
    print(f"{len(allrows)} measured rows from {len(cfgs) - len(problems)} configurations; {len(problems)} configuration problems")
    for p in problems: print("PROBLEM", p)
    print(f"analytical model vs RTL: {model_checks - len(model_bad)}/{model_checks} deterministic workloads match exactly")
    for m in model_bad: print("MISMATCH", m)
    return 0 if not problems and not model_bad else 1

if __name__ == "__main__":
    sys.exit(main())
