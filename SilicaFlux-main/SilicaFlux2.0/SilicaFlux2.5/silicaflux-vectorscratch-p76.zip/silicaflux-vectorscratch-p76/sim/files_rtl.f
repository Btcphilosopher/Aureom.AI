// SilicaFlux VectorScratch RTL file list (paths relative to the project root)
+incdir+rtl
+incdir+third_party/memorycore/rtl
third_party/memorycore/rtl/sf_sram_core.sv
third_party/memorycore/rtl/backends/sf_sram_fpga_bram.sv
third_party/memorycore/rtl/backends/sf_sram_asic_sky130.sv
third_party/memorycore/rtl/sf_sram_macro_wrapper.sv
third_party/memorycore/sim_models/sky130_sram_standin.sv
rtl/sf_vspm_bankmap.sv
rtl/sf_vspm_split.sv
rtl/sf_vspm_merge.sv
rtl/sf_vspm_agu.sv
rtl/sf_vspm_port.sv
rtl/sf_vspm_bank_sched.sv
rtl/sf_vspm_banks.sv
rtl/sf_vspm_own.sv
rtl/sf_vspm_perf.sv
rtl/sf_vector_scratchpad.sv
