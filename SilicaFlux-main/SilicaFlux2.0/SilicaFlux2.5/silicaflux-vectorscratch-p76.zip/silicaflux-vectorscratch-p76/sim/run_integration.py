#!/usr/bin/env python3
"""Integration testbenches -> reports/integration.json
   tb_clouddma_int : the REAL sfd_clouddma channel (vendored) loading / extracting scratchpad data through the DMA port
   tb_lane_glue    : hpc_vector_array-style lane-masked result beats (FP32 and 64-bit elements) through the vector port
"""
import json, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VF = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-DECLFILENAME", "--assert", "-DSF_ASSERT"]
CASES = [
    ("clouddma_nb4", "tb_clouddma_int", "tb/tb_clouddma_int.sv", ["-f", "sim/files_cdma.f"], {}),
    ("clouddma_nb8", "tb_clouddma_int", "tb/tb_clouddma_int.sv", ["-f", "sim/files_cdma.f"], {"NB": 8, "DEPTH": 32}),
    ("glue_v128_fp32", "tb_lane_glue", "tb/tb_lane_glue.sv", ["-f", "sim/files_pkg.f"], {"VEC_BYTES": 16, "ELEM_BYTES": 4, "NB": 8}),
    ("glue_v256_fp32", "tb_lane_glue", "tb/tb_lane_glue.sv", ["-f", "sim/files_pkg.f"], {"VEC_BYTES": 32, "ELEM_BYTES": 4, "NB": 8}),
    ("glue_v128_64bit", "tb_lane_glue", "tb/tb_lane_glue.sv", ["-f", "sim/files_pkg.f"], {"VEC_BYTES": 16, "ELEM_BYTES": 8, "NB": 8}),
    ("glue_v256_64bit", "tb_lane_glue", "tb/tb_lane_glue.sv", ["-f", "sim/files_pkg.f"], {"VEC_BYTES": 32, "ELEM_BYTES": 8, "NB": 4}),
]
def run(c):
    name, top, tb, extra, ov = c
    d = os.path.join(ROOT, "build", "int_" + name)
    os.makedirs(d, exist_ok=True)
    r = subprocess.run(["verilator"] + VF + ["--top-module", top, "-f", "sim/files_rtl.f"] + extra + [tb, "-Mdir", d, "-o", "simv"] + [f"-G{k}={v}" for k, v in ov.items()],
                       cwd=ROOT, capture_output=True, text=True)
    if r.returncode != 0:
        return dict(name=name, status="BUILD-FAIL", detail=r.stderr[-300:])
    r = subprocess.run([os.path.join(d, "simv")], cwd=ROOT, capture_output=True, text=True, timeout=1800)
    m = re.search(r"RESULT \S+ tests=(\d+) checks=(\d+) errors=(\d+)", r.stdout)
    if not m:
        return dict(name=name, status="FAIL", detail="no RESULT line")
    return dict(name=name, status="PASS" if m.group(3) == "0" and "PASS" in r.stdout else "FAIL", tests=int(m.group(1)), checks=int(m.group(2)), errors=int(m.group(3)))
if __name__ == "__main__":
    with ThreadPoolExecutor(3) as ex:
        res = list(ex.map(run, CASES))
    json.dump(res, open(os.path.join(ROOT, "reports", "integration.json"), "w"), indent=1)
    for r in res: print(r)
    sys.exit(0 if all(r["status"] == "PASS" for r in res) else 1)
