#!/usr/bin/env bash
# Full verification chain.  Each step writes its JSON / Markdown into reports/.  Stops at the first failing step.
set -e
cd "$(dirname "$0")/.."
J=${JOBS:-4}
python3 sim/run_regress.py --jobs $J                 # Verilator: configuration matrix of the full testbench
python3 sim/run_regress.py --icarus --jobs $J        # Icarus 12 cross-simulation of the same matrix
python3 sim/run_units.py                             # leaf blocks + package, exhaustive / random
python3 sim/run_integration.py                       # real CloudDMA, lane-mask glue
python3 tools/mutate.py --jobs $J                    # mutation testing of the testbench
python3 sim/run_bench.py --jobs $J                   # reproducible bandwidth / latency workloads + analytical model check
python3 syn/run_synth.py --jobs 3                    # Yosys: generic gates, FPGA block RAM, SKY130 macro tiling
python3 tools/make_report.py                         # figures + BANDWIDTH_REPORT.md + SUMMARY.md from the reports above
