#!/usr/bin/env python3
"""Build and run the unit-level testbench tb/tb_units.sv for several (VEC_BYTES, BANK_BYTES) shapes -> reports/units.json"""
import json, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VF = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-DECLFILENAME", "--assert", "-DSF_ASSERT"]
SHAPES = [(16, 4), (32, 4), (32, 8), (64, 4), (64, 16), (16, 16)]
def run(shape):
    vb, bb = shape
    d = os.path.join(ROOT, "build", f"units_{vb}_{bb}")
    os.makedirs(d, exist_ok=True)
    r = subprocess.run(["verilator"] + VF + ["--top-module", "tb_units", "-f", "sim/files_rtl.f", "-f", "sim/files_pkg.f", "tb/tb_units.sv", "-Mdir", d,
                        f"-GVEC_BYTES={vb}", f"-GBB={bb}", "-GNRAND=300000", "-o", "simv"], cwd=ROOT, capture_output=True, text=True)
    if r.returncode != 0:
        return dict(vec_bytes=vb, bank_bytes=bb, status="BUILD-FAIL", detail=r.stderr[-300:])
    r = subprocess.run([os.path.join(d, "simv")], cwd=ROOT, capture_output=True, text=True, timeout=1800)
    m = re.search(r"RESULT \S+ tests=(\d+) checks=(\d+) errors=(\d+) (PASS|FAIL)", r.stdout)
    if not m:
        return dict(vec_bytes=vb, bank_bytes=bb, status="FAIL", detail="no RESULT line")
    return dict(vec_bytes=vb, bank_bytes=bb, status="PASS" if m.group(4) == "PASS" and m.group(3) == "0" else "FAIL", checks=int(m.group(2)), errors=int(m.group(3)))
if __name__ == "__main__":
    with ThreadPoolExecutor(3) as ex:
        res = list(ex.map(run, SHAPES))
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "units.json"), "w"), indent=1)
    for r in res: print(r)
    sys.exit(0 if all(r["status"] == "PASS" for r in res) else 1)
