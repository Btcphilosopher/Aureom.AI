# VectorScratch (Project 76) - verification and results summary

Generated from `reports/*.json` by `tools/make_report.py`. Every row is a tool result; "not run" is stated where a step was not run.

| check | result | source |
|---|---|---|
| Verilator regression: configuration matrix of `tb_vspm` | **50/50 cases PASS**, 7,498,876 self-checks | `regress.json` (Verilator 5.020 2024-01-01 rev (Debian 5.020-1)) |
| Icarus cross-simulation of the same matrix | **49/49 cases PASS** (1 skipped: BACKEND=2), 7,516,382 self-checks | `regress_icarus.json` (Icarus Verilog version 12.0 (stable) ()) |
| unit tests: bank map, split/merge (exhaustive masks), package | **6/6 shapes PASS**, 53,675,504 checks | `units.json` |
| integration: real CloudDMA, lane-masked beats (FP32 / 64-bit) | **6/6 PASS**, 32,984 checks | `integration.json` |
| mutation testing of the testbench | **55/55 injected bugs killed** (0 survived, 0 invalid) | `mutation.json`, `mutation.md` |
| bandwidth sweep | 613 measured rows, 26 configurations; **243/243** deterministic workloads equal the independent analytical model | `bench.csv`, `bench.json` |
| synthesis (Yosys generic gates) | 27/27 configurations / blocks synthesize, 0 latches | `synthesis.md` |
| FPGA block-RAM inference (`synth_xilinx xc7`) | 9/9 configurations | `synthesis.md` |
| SKY130 macro tiling (structural) | 6/6 macro counts equal the tiling formula | `synthesis.md` |

Not run / not available: Vivado, Quartus, OpenROAD, Liberty-based synthesis, SymbiYosys (no formal proof of this design), gate-level simulation, FPGA hardware.
