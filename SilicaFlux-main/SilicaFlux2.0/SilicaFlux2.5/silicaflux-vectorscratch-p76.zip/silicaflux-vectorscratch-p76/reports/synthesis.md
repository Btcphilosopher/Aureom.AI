# Synthesis results (Yosys 0.33 (git sha1 2584903a060))

No PDK, no timing, no place-and-route anywhere in this file. Cell counts are **generic-gate counts, not area**; no clock frequency or power is claimed.

## A. Generic logic synthesis (`synth -flatten`, `abc -fast`; SRAM arrays left as `$mem` cells)

| configuration / block | status | flip-flops | other logic cells | `$mem` cells | latches | s |
|---|---|---:|---:|---:|---:|---:|
| v128 NB4 default (ANY, DMA, perf) | OK | 4203 | 26605 | 4 | 0 | 27.2 |
| v128 NB4 ALIGN_WORD (no byte shifter) | OK | 3882 | 18733 | 4 | 0 | 15.1 |
| v128 NB4 ALIGN_VEC | OK | 3882 | 18735 | 4 | 0 | 15.3 |
| v128 NB4 vector-only (DMA_EN=0, PERF_EN=0) | OK | 1945 | 13208 | 4 | 0 | 14.7 |
| v128 NB4 PERF_EN=0 | OK | 2779 | 19197 | 4 | 0 | 21.4 |
| v128 NB4 + strided/gather/scatter | OK | 4215 | 29131 | 4 | 0 | 27.2 |
| v128 NB8 | OK | 4495 | 39513 | 8 | 0 | 40.3 |
| v128 NB4 bank word 16 B | OK | 4879 | 18701 | 4 | 0 | 23.7 |
| v256 NB8 default | OK | 5894 | 56989 | 8 | 0 | 65.8 |
| v256 NB8 ALIGN_WORD | OK | 5578 | 44196 | 8 | 0 | 39.8 |
| v256 NB8 + strided/gather/scatter | OK | 5915 | 63034 | 8 | 0 | 73.6 |
| v256 NB4 | OK | 5598 | 38357 | 4 | 0 | 47.2 |
| v256 NB16 | OK | 6486 | 94042 | 16 | 0 | 105.5 |
| v512 NB16 default | OK | 10085 | 173862 | 16 | 0 | 237.0 |
| sf_vspm_port v128 NB4 | OK | 1962 | 13117 | 0 | 0 | 15.9 |
| sf_vspm_port v256 NB8 | OK | 3353 | 37250 | 0 | 0 | 45.8 |
| sf_vspm_port DMA 16 B (policy VEC) | OK | 921 | 5941 | 0 | 0 | 5.2 |
| sf_vspm_agu v128 NB4 | OK | 0 | 488 | 0 | 0 | 0.5 |
| sf_vspm_agu v256 NB8 + GS | OK | 0 | 7103 | 0 | 0 | 1.9 |
| sf_vspm_split v128 | OK | 0 | 325 | 0 | 0 | 0.3 |
| sf_vspm_merge v128 | OK | 0 | 417 | 0 | 0 | 0.4 |
| sf_vspm_split v256 | OK | 0 | 613 | 0 | 0 | 0.4 |
| sf_vspm_merge v256 | OK | 0 | 817 | 0 | 0 | 0.5 |
| sf_vspm_bank_sched NB4 | OK | 4 | 448 | 0 | 0 | 0.4 |
| sf_vspm_bank_sched NB8 | OK | 8 | 896 | 0 | 0 | 0.5 |
| sf_vspm_perf NB4 (33 counters x 32 b) | OK | 1280 | 8939 | 0 | 0 | 2.8 |
| sf_vspm_own 4 regions | OK | 15 | 61 | 0 | 0 | 0.4 |

## B. FPGA block-RAM inference (`synth_xilinx -family xc7`; same 16 KiB at different bank word widths)

RAMB36 = 32 Kb of data (+ 4 Kb parity, unused here); RAMB18 = 16 Kb of data. *efficiency* = stored data bits / data bits of the block RAMs the tool used.

| configuration | RAMB36 | RAMB18 | stored data bits | block-RAM data bits | efficiency | LUT | FF |
|---|---:|---:|---:|---:|---:|---:|---:|
| v128 NB4 BB4  1024x32  (16 KiB) | 4 | 0 | 131072 | 131072 | 1.0 | 7198 | 1956 |
| v128 NB4 BB16 256x128 (16 KiB) | 8 | 0 | 131072 | 262144 | 0.5 | 13304 | 2685 |
| v128 NB8 BB4  512x32  (16 KiB) | 0 | 8 | 131072 | 131072 | 1.0 | 11664 | 1984 |
| v256 NB8 BB4  512x32  (16 KiB) | 0 | 8 | 131072 | 131072 | 1.0 | 20873 | 3404 |
| v256 NB4 BB8  512x64  (16 KiB) | 4 | 0 | 131072 | 131072 | 1.0 | 14452 | 3547 |
| v256 NB4 BB16 256x128 (16 KiB) | 8 | 0 | 131072 | 262144 | 0.5 | 19129 | 4076 |
| v512 NB16 BB4 256x32  (16 KiB) | 0 | 16 | 131072 | 262144 | 0.5 | 62253 | 6308 |
| v128 NB4 BB4  256x32  (4 KiB, shallow) | 0 | 4 | 32768 | 65536 | 0.5 | 7195 | 1946 |
| v128 NB4 BB4  64x32   (1 KiB, tiny) | 0 | 4 | 8192 | 65536 | 0.125 | 7246 | 1936 |

## C. SKY130 macro tiling (structural; pin-only black box of `sky130_sram_1kbyte_1rw1r_32x256_8`, 8 Kb each)

| configuration | macros | expected (ceil tiling) | stored data bits | macro bits | efficiency |
|---|---:|---:|---:|---:|---:|
| v128 NB4 BB4  256x32  (4 KiB) | 4 | 4 | 32768 | 32768 | 1.0 |
| v128 NB4 BB4  1024x32 (16 KiB) | 16 | 16 | 131072 | 131072 | 1.0 |
| v128 NB4 BB16 256x128 (16 KiB) | 16 | 16 | 131072 | 131072 | 1.0 |
| v256 NB8 BB4  512x32  (16 KiB) | 16 | 16 | 131072 | 131072 | 1.0 |
| v128 NB4 BB4  64x32   (1 KiB, tiny) | 4 | 4 | 8192 | 32768 | 0.25 |
| v128 NB4 BB4  300x32  (non-multiple depth) | 8 | 8 | 65536 | 65536 | 1.0 |
