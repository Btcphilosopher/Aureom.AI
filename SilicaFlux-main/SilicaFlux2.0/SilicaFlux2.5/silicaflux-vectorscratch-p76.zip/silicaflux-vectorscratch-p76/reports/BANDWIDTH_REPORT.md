# VectorScratch bandwidth report

*SilicaFlux-HPC Project 76 - `sf_vector_scratchpad`. Everything below is **RTL simulation** (Verilator 5.020, `tb/tb_bench.sv`) with the design's own
performance counters; no number is a silicon, timing or power measurement.* Reproduce: `python3 sim/run_bench.py` then `python3 tools/make_report.py`.

## How to read the numbers

* **Useful bytes per cycle** = sum over completed vector requests of the number of ENABLED bytes (mask popcount) divided by the cycles from the first
  accepted request to the last response handshake. A 2000-request run includes the pipeline fill (3 cycles), so a perfect stream reads 15.98, not 16.
* **Vector peak** = one request per cycle = `VEC_BYTES` per cycle (16 for 128-bit, 32 for 256-bit, 64 for 512-bit). **Bank ceiling** = `NB x bank word`
  bytes per cycle: with fewer banks than the vector has words, the banks - not the vector port - are the limit, and the report shows that limit, not the peak.
* Banks are **single-port**: one access per bank per cycle. When two words of one request (or of the two ports) want one bank, the accesses are serialised, the
  conflict is counted (`V_STALL_CONF`, `V_STALL_ARB`, per-bank counters) and the request takes more cycles. **Nothing in this report assumes full vector
  bandwidth where the banks cannot deliver it.**
* The source never idles and the consumer is always ready (except the serial `iso_*` latency workloads); the DMA agent offers one 16-byte beat on the stated
  share of cycles. Workloads are deterministic (fixed seeds), so every row is reproducible bit for bit.

## 1 Aligned streams: full bandwidth when the banks allow it

![128-bit bandwidth by bank count](figs/fig1_v128_bank_count.svg)

![256-bit bandwidth by bank count](figs/fig2_v256_bank_count.svg)

Useful bytes per cycle, all configurations (32-bit banks unless the "banks x word" column says otherwise):

| configuration | vector bits | banks x word | map | align policy | bank ceiling B/cyc | seq load | seq store | copy | triad (2 ld + 1 st) | bank util (seq load) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| v128_nb2_low | 128 | 2x32b | LOW | any | 8 | 7.99 | 7.99 | 8.00 | 8.00 | 100% |
| v128_nb4_low | 128 | 4x32b | LOW | any | 16 | 15.98 | 15.98 | 15.99 | 15.98 | 100% |
| v128_nb8_low | 128 | 8x32b | LOW | any | 32 | 15.98 | 15.98 | 15.99 | 15.98 | 50% |
| v128_nb4_xor | 128 | 4x32b | XOR | any | 16 | 15.98 | 15.98 | 15.99 | 15.98 | 100% |
| v128_nb4_block | 128 | 4x32b | BLOCK | any | 16 | 4.00 | 4.00 | 4.00 | 4.00 | 25% |
| v128_nb4_low_alignword | 128 | 4x32b | LOW | word | 16 | 15.98 | 15.98 | 15.99 | 15.98 | 100% |
| v128_nb4_low_alignvec | 128 | 4x32b | LOW | vec | 16 | 15.98 | 15.98 | 15.99 | 15.98 | 100% |
| v128_bank16B_nb4 | 128 | 4x128b | LOW | any | 64 | 15.98 | 15.98 | 15.99 | 15.98 | 25% |
| v128_nb4_low_lat2 | 128 | 4x32b | LOW | any | 16 | 15.97 | 15.97 | 15.98 | 15.98 | 100% |
| v128_nb4_low_lat3 | 128 | 4x32b | LOW | any | 16 | 15.96 | 15.96 | 15.98 | 15.97 | 100% |
| v128_nb4_dma4B | 128 | 4x32b | LOW | any | 16 | 15.98 | 15.98 | 15.99 | 15.98 | 100% |
| v128_nb4_arb_vec | 128 | 4x32b | LOW | any | 16 | 15.98 | 15.98 | 15.99 | 15.98 | 100% |
| v128_nb4_arb_dma | 128 | 4x32b | LOW | any | 16 | 15.98 | 15.98 | 15.99 | 15.98 | 100% |
| v256_nb4_low | 256 | 4x32b | LOW | any | 16 | 15.99 | 15.99 | 15.99 | 15.99 | 100% |
| v256_nb8_low | 256 | 8x32b | LOW | any | 32 | 31.95 | 31.95 | 31.98 | 31.97 | 100% |
| v256_nb16_low | 256 | 16x32b | LOW | any | 64 | 31.95 | 31.95 | 31.98 | 31.97 | 50% |
| v256_nb8_xor | 256 | 8x32b | XOR | any | 32 | 31.95 | 31.95 | 31.98 | 31.97 | 100% |
| v256_nb8_block | 256 | 8x32b | BLOCK | any | 32 | 4.00 | 4.00 | 4.00 | 4.00 | 12% |
| v256_bank8B_nb4 | 256 | 4x64b | LOW | any | 32 | 31.95 | 31.95 | 31.98 | 31.97 | 100% |
| v256_bank16B_nb4 | 256 | 4x128b | LOW | any | 64 | 31.95 | 31.95 | 31.98 | 31.97 | 50% |
| v512_nb16_low | 512 | 16x32b | LOW | any | 64 | 63.90 | 63.90 | 63.95 | 63.94 | 100% |
| v128_nb4_low_gs | 128 | 4x32b | LOW | any | 16 | 15.98 | 15.98 | 15.99 | 15.98 | 100% |
| v128_nb8_low_gs | 128 | 8x32b | LOW | any | 32 | 15.98 | 15.98 | 15.99 | 15.98 | 50% |
| v128_nb4_xor_gs | 128 | 4x32b | XOR | any | 16 | 15.98 | 15.98 | 15.99 | 15.98 | 100% |
| v256_nb8_low_gs | 256 | 8x32b | LOW | any | 32 | 31.95 | 31.95 | 31.98 | 31.97 | 100% |
| v256_nb8_xor_gs | 256 | 8x32b | XOR | any | 32 | 31.95 | 31.95 | 31.98 | 31.97 | 100% |

Findings (each one is checked against the data by `tools/make_report.py` before it is printed):

* An aligned vector stream runs at **one vector per cycle** whenever the banks can supply it (`NB x word >= vector bytes`, LOW or XOR map) and at the bank
  ceiling otherwise (2 banks x 4 B = 8 B/cycle for a 128-bit vector).
* Loads, stores and a copy / triad mix all sustain the same rate: reads and writes share the same single-port banks and neither costs extra cycles.
* The **BLOCK** map puts a contiguous vector in a single bank, so the stream collapses to **one bank word per cycle (4 B/cycle)** - the deliberate worst case.

## 2 Alignment overhead (the split / merge datapath)

| configuration | aligned | +1 word | +1 byte (load) | +1 byte (store) | extra words / request | conflict-stall cycles / request | cycles / request (+1 byte) |
|---|---:|---:|---:|---:|---:|---:|---:|
| v128_nb2_low | 7.99 | 7.99 | 5.33 | 5.33 | 1.00 | 2.00 | 3.00 |
| v128_nb4_low | 15.98 | 15.98 | 7.99 | 7.99 | 1.00 | 1.00 | 2.00 |
| v128_nb8_low | 15.98 | 15.98 | 15.98 | 15.98 | 1.00 | 0.00 | 1.00 |
| v128_nb4_xor | 15.98 | 7.99 | 7.99 | 7.99 | 1.00 | 1.00 | 2.00 |
| v128_nb4_block | 4.00 | 4.01 | 3.21 | 3.21 | 1.00 | 3.99 | 4.99 |
| v128_bank16B_nb4 | 15.98 | 15.98 | 15.98 | 15.98 | 1.00 | 0.00 | 1.00 |
| v256_nb4_low | 15.99 | 15.99 | 10.66 | 10.66 | 1.00 | 2.00 | 3.00 |
| v256_nb8_low | 31.95 | 31.95 | 15.99 | 15.99 | 1.00 | 1.00 | 2.00 |
| v256_nb16_low | 31.95 | 31.95 | 31.95 | 31.95 | 1.00 | 0.00 | 1.00 |
| v256_nb8_xor | 31.95 | 15.99 | 15.99 | 15.99 | 1.00 | 1.00 | 2.00 |
| v256_nb8_block | 4.00 | 4.03 | 3.58 | 3.58 | 1.00 | 7.95 | 8.95 |
| v256_bank8B_nb4 | 31.95 | 31.95 | 15.99 | 15.99 | 1.00 | 1.00 | 2.00 |
| v256_bank16B_nb4 | 31.95 | 31.95 | 31.95 | 31.95 | 1.00 | 0.00 | 1.00 |
| v512_nb16_low | 63.90 | 63.90 | 31.98 | 31.98 | 1.00 | 1.00 | 2.00 |

A vector that starts inside a word touches `VEC_BYTES / word + 1` words. With LOW mapping and `NB >= vector words + 1` they all sit in distinct banks and the
byte-misaligned stream runs at **full rate**; with `NB = vector words` the extra word lands on the bank of the first one and every request takes **two cycles
(half rate)**; with fewer banks it is worse (2 banks: 3 cycles for a 128-bit vector). The cost is conflict stalls, not data movement: the split / merge itself
is free in cycles. *Word*-misaligned streams (start offset a multiple of 4 B) never add words and are conflict free under LOW.

Alignment *policy* A (reject misaligned requests) costs nothing and answers `SF_ST_ALIGN`; the `v128_nb4_low_alignword` / `_alignvec` rows run only the supported
workloads. Wide (16-byte) banks make byte-misaligned 128-bit vectors free (2 words in 2 banks) but cost bank bandwidth elsewhere, see section 6.

## 3 Bank mapping

| configuration | seq load | seq load +1 word | random aligned load | stride 1 elem | stride NB words | stride 5 elems | random gather |
|---|---:|---:|---:|---:|---:|---:|---:|
| v128_nb4_low | 15.98 | 15.98 | 15.98 | - | - | - | - |
| v128_nb4_xor | 15.98 | 7.99 | 15.98 | - | - | - | - |
| v128_nb4_block | 4.00 | 4.01 | 4.00 | - | - | - | - |
| v256_nb8_low | 31.95 | 31.95 | 31.95 | - | - | - | - |
| v256_nb8_xor | 31.95 | 15.99 | 31.95 | - | - | - | - |
| v256_nb8_block | 4.00 | 4.03 | 4.00 | - | - | - | - |
| v128_nb4_low_gs | 15.98 | 15.98 | 15.98 | 15.98 | 4.00 | 15.98 | 7.55 |
| v128_nb4_xor_gs | 15.98 | 7.99 | 15.98 | 15.98 | 15.98 | 4.00 | 7.54 |
| v256_nb8_low_gs | 31.95 | 31.95 | 31.95 | 31.95 | 4.00 | 31.95 | 12.31 |
| v256_nb8_xor_gs | 31.95 | 15.99 | 31.95 | 31.95 | 31.95 | 15.99 | 12.37 |

* **LOW** serves contiguous and word-misaligned vectors at full rate but puts a stride of `NB` words on a single bank.
* **XOR** spreads the stride-`NB` pattern over all banks, **but it is worse than LOW for word-misaligned contiguous streams** (half rate in the 128-bit, 4-bank
  case): a vector that straddles a row boundary sees two different XOR keys, so two of its words can land on the same bank. XOR trades contiguous
  misaligned performance for power-of-two-stride performance; choose by workload.
* **BLOCK** is for isolation (each bank is a contiguous region, so a DMA buffer can have a bank to itself), not for bandwidth.

## 4 Latency

| configuration | READ_LATENCY | isolated load (cycles) | isolated store (cycles) | isolated load, +1 byte | mean load latency in the stream | starved cycles in the stream (2000 loads) |
|---|---:|---:|---:|---:|---:|---:|
| v128_nb4_low | 1 | 3.00 | 3.00 | 4.00 | 3.00 | 2 |
| v128_nb4_low_lat2 | 2 | 4.00 | 4.00 | 5.00 | 4.00 | 3 |
| v128_nb4_low_lat3 | 3 | 5.00 | 5.00 | 6.00 | 5.00 | 4 |
| v256_nb8_low | 1 | 3.00 | 3.00 | 4.00 | 3.00 | 2 |
| v512_nb16_low | 1 | 3.00 | 3.00 | 4.00 | 3.00 | 2 |

A load or store that hits distinct banks completes in `READ_LATENCY + 2` cycles from the accepting edge to the response handshake (accept, issue,
`READ_LATENCY` bank cycles, window capture; the response is combinational from the completion queue). Every extra access to the busiest bank adds one cycle. A request
with an error status or an empty mask never touches a bank and completes in one cycle. The exact formula is asserted for every isolated request by `tb/tb_vspm.sv`.
The stream rows show the design sustains one request per cycle with 3 cycles of latency, so a consumer that issues loads early enough is never starved: the
**starved cycles** column (consumer ready, nothing deliverable, work outstanding) is just the 2 pipeline-fill cycles; the isolated loads of the serial workload show
the starvation a consumer sees when it cannot hide the latency (2 cycles per load).

## 5 DMA and vector traffic on the same banks

![vector bandwidth while the DMA streams](figs/fig3_dma_vector_bw.svg)

![DMA bandwidth while the vector port streams](figs/fig4_dma_dma_bw.svg)

| arbitration | DMA offered | vector requests completed | vector B/cycle | DMA B/cycle | vector arbitration-loss cycles | DMA arbitration-loss cycles | bank utilisation | vector starved cycles |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| round robin | 25% | 2000/2000 | 12.16 | 3.82 | 629 | 183 | 100% | 631 |
| round robin | 50% | 2000/2000 | 9.10 | 6.89 | 1513 | 1034 | 100% | 1515 |
| round robin | 75% | 2000/2000 | 8.10 | 7.90 | 1947 | 1794 | 100% | 1949 |
| round robin | 100% | 2000/2000 | 8.00 | 8.01 | 1999 | 2000 | 100% | 2001 |
| vector priority | 25% | 2000/2000 | 15.98 | 0.03 | 0 | 1998 | 100% | 2 |
| vector priority | 50% | 2000/2000 | 15.98 | 0.03 | 0 | 1999 | 100% | 2 |
| vector priority | 75% | 2000/2000 | 15.98 | 0.02 | 0 | 1999 | 100% | 2 |
| vector priority | 100% | 2000/2000 | 15.98 | 0.03 | 0 | 2000 | 100% | 2 |
| DMA priority | 25% | 2000/2000 | 12.10 | 3.89 | 642 | 0 | 100% | 644 |
| DMA priority | 50% | 2000/2000 | 8.07 | 7.92 | 1963 | 0 | 100% | 1965 |
| DMA priority | 75% | 2000/2000 | 4.00 | 12.00 | 6001 | 0 | 100% | 6003 |
| DMA priority | 100% | 2/2000 | 0.00 | 16.00 | 42000 | 0 | 100% | 42002 |

* **Round robin** (default): both ports always make progress; at 100% offered DMA load each gets half of what one port could (8 B/cycle each) and the
  banks are 100% busy. The per-bank bound (a port loses a bank at most once in a row) is checked in `tb/tb_vspm.sv`.
* **Vector priority** keeps the vector stream at full rate and **starves the DMA** (< 0.1 B/cycle). **DMA priority** does the reverse and **starves the vector
  port completely** when the DMA saturates the banks (the vector run was cut after 20x its ideal time with only a few requests done). Both are available because
  some systems want them; they are measured here so nobody finds out in the field.
* Isolation by mapping or ownership needs no arbitration at all: region ownership (`sf_vspm_own`) keeps the ports' data apart, and with the BLOCK map and a
  DMA region on its own bank the two streams do not collide.

## 6 Strided, gather and scatter (optional, `GS_EN = 1`)

| configuration | stride 1 elem | stride NB words | stride 5 elems | random gather | random scatter |
|---|---:|---:|---:|---:|---:|
| v128_nb4_low_gs | 15.98 | 4.00 | 15.98 | 7.55 | 7.55 |
| v128_nb8_low_gs | 15.98 | 4.00 | 15.98 | 9.81 | 9.66 |
| v128_nb4_xor_gs | 15.98 | 15.98 | 4.00 | 7.54 | 7.53 |
| v256_nb8_low_gs | 31.95 | 4.00 | 31.95 | 12.31 | 12.41 |
| v256_nb8_xor_gs | 31.95 | 31.95 | 15.99 | 12.37 | 12.41 |

Element accesses are limited by how many of the lanes' words share a bank: a unit stride (1 element) is conflict free; a stride of `NB` words puts all lanes on
one bank under LOW (4 cycles for 4 lanes); the XOR map removes exactly that case; random gathers behave like random bank loads. Overlapping scatter lanes are
executed in lane order: **the highest lane wins** (checked bit-exactly).

## 7 Bank word width, useful bytes and memory utilisation

| configuration | bank word | random byte-addressed mix B/cycle | bank accesses / request | useful / accessed bytes (random bytes) | useful / accessed bytes (partial final vectors) |
|---|---:|---:|---:|---:|---:|
| v128_bank16B_nb4 | 128b | 15.98 | 1.93 | 0.52 | 0.92 |
| v128_nb4_low | 32b | 9.06 | 4.76 | 0.84 | 1.00 |
| v128_nb8_low | 32b | 15.98 | 4.74 | 0.84 | 1.00 |
| v256_bank16B_nb4 | 128b | 31.95 | 2.93 | 0.68 | 0.96 |
| v256_bank8B_nb4 | 64b | 17.07 | 4.87 | 0.82 | 0.96 |
| v256_nb8_low | 32b | 18.12 | 8.76 | 0.91 | 1.00 |

A bank access always moves a whole bank word; **useful / accessed bytes** says how much of it was wanted. Narrow (32-bit) banks waste little on partial final
vectors and byte-granular masks; 16-byte banks make misaligned vectors free but touch 4x the bytes per access (higher energy per useful byte in a real macro -
not measured here). The vector width and the bank word width are independent knobs; see `docs/05_memory_mapping.md` for how each maps onto block RAM / macros.

## 8 Validation of the measurements

243 deterministic (workload, configuration) pairs were also predicted by an independent Python model (sum over requests of the busiest-bank load
plus `READ_LATENCY + 2`, `sim/run_bench.py`). **All 243 agree with the RTL cycle for cycle.** Random workloads and
DMA contention cannot be predicted that way; they are checked for internal consistency instead (counted requests, useful bytes and per-bank accesses equal the
testbench's own accounting in every run).

## 9 Checked claims

* v128_nb2_low: aligned stream reaches the lower of the vector peak (16 B/cycle) and the bank ceiling (8 B/cycle): measured 7.994
* v128_nb4_low: aligned stream reaches the lower of the vector peak (16 B/cycle) and the bank ceiling (16 B/cycle): measured 15.976
* v128_nb4_low: byte-misaligned stream runs at half rate (NB 4 = vector words 4): 7.994 vs 15.976
* v128_nb8_low: aligned stream reaches the lower of the vector peak (16 B/cycle) and the bank ceiling (32 B/cycle): measured 15.976
* v128_nb8_low: byte-misaligned stream is as fast as the aligned one (NB 8 >= vector words 4 + 1): 15.976 vs 15.976
* v256_nb4_low: aligned stream reaches the lower of the vector peak (32 B/cycle) and the bank ceiling (16 B/cycle): measured 15.988
* v256_nb8_low: aligned stream reaches the lower of the vector peak (32 B/cycle) and the bank ceiling (32 B/cycle): measured 31.952
* v256_nb8_low: byte-misaligned stream runs at half rate (NB 8 = vector words 8): 15.988 vs 31.952
* v256_nb16_low: aligned stream reaches the lower of the vector peak (32 B/cycle) and the bank ceiling (64 B/cycle): measured 31.952
* v256_nb16_low: byte-misaligned stream is as fast as the aligned one (NB 16 >= vector words 8 + 1): 31.952 vs 31.952
* v512_nb16_low: aligned stream reaches the lower of the vector peak (64 B/cycle) and the bank ceiling (64 B/cycle): measured 63.904
* v512_nb16_low: byte-misaligned stream runs at half rate (NB 16 = vector words 16): 31.976 vs 63.904
* v128_nb2_low: with 2 banks a 4-word vector needs 2 cycles aligned (8 B/cycle) and 3 cycles byte-misaligned (5.33 B/cycle)
* BLOCK map confines a contiguous vector to one bank: 4 B/cycle (one 32-bit bank) for 128-bit and for 256-bit vectors
* XOR map halves a word-misaligned stream that LOW serves at full rate (row-boundary words collide): 128-bit NB4
* 16-byte banks (NB 4) serve byte-misaligned 128-bit vectors at full rate: a misaligned vector spans 2 words in 2 different banks
* partial final vectors cost no cycles: tail-masked stores run at one request per cycle (useful bytes/cycle = mask fraction x peak)
* v128_nb4_low: isolated aligned read latency is READ_LATENCY + 2 = 3 cycles, write latency the same
* v128_nb4_low_lat2: isolated aligned read latency is READ_LATENCY + 2 = 4 cycles, write latency the same
* v128_nb4_low_lat3: isolated aligned read latency is READ_LATENCY + 2 = 5 cycles, write latency the same
* a byte-misaligned isolated load on 4 banks costs one extra cycle (latency 4)
* round robin at 50% DMA offered load: neither port is starved (both finish; vector 9.10 B/cycle, DMA 6.89 B/cycle)
* round robin at 100% DMA offered load: neither port is starved (both finish; vector 8.00 B/cycle, DMA 8.01 B/cycle)
* round robin at 100% offered load shares the banks equally (within 1%)
* vector priority starves the DMA (< 0.1 B/cycle at 100% offered load)
* DMA priority starves the vector port at 100% offered DMA load (the vector stream does not complete)
* bank utilisation reaches 100% of bank-cycles when both ports saturate the banks
* deterministic workloads match the independent analytical model exactly
* strided access with stride = NB words puts every lane on one bank under LOW: 4 cycles per request

## 10 Limits

RTL simulation only: no timing (so no GB/s), no power, no place-and-route. Arrival patterns are synthetic. Random workloads are single-seed. The DMA agent is a
simple streaming source, not a particular DMA engine (the real CloudDMA is exercised for correctness in `tb/tb_clouddma_int.sv`, not for bandwidth).
