# Mutation testing of the testbench

55 mutants: **55 killed**, 0 survived, 0 build errors (invalid mutations, not counted as killed).

| mutant | file | what is broken | result | first failure seen |
|---|---|---|---|---|
| split_no_shift | sf_vspm_split.sv | store mask not shifted by the byte offset | **KILLED** | [FAIL] v rdata: got 00edf97838983e6fe39a79df37888d29 exp d522f96538983e6fe39a79df37888d29  |
| split_data_no_shift | sf_vspm_split.sv | store data not shifted by the byte offset | **KILLED** | [FAIL] v rdata: got 0081edf96538983e6fe39a79df37888d exp d522f96538983e6fe39a79df37888d29  |
| merge_no_shift | sf_vspm_merge.sv | load data not shifted back by the offset | **KILLED** | [FAIL] v rdata: got 22f96538983e6fe39a79df37888d2971 exp d522f96538983e6fe39a79df37888d29  |
| merge_no_zero | sf_vspm_merge.sv | masked-off load bytes not zeroed | **KILLED** | [FAIL] v rdata: got d857e6adf629d83e430a2438efe117f3 exp 00000000f629d83e430a243800000000  |
| off_ignored_port | sf_vspm_port.sv | port always uses offset 0 (misaligned data wrong) | **KILLED** | [FAIL] v rdata: got d5ed226538983e6fe39a79df37888d29 exp d522f96538983e6fe39a79df37888d29  |
| off_stored_wrong | sf_vspm_port.sv | response merge uses offset 0 | **KILLED** | [FAIL] v rdata: got 22f96538983e6fe39a79df37888d2971 exp d522f96538983e6fe39a79df37888d29  |
| agu_slot_plus_zero | sf_vspm_agu.sv | slot k maps to the wrong word for k >= 2 | **KILLED** | [FAIL] init_fill: backdoor mismatch: 1020 bytes differ, first at byte 0 @cycle 170 (init_f |
| agu_range_off_by_one | sf_vspm_agu.sv | last word of the aperture wrongly out of range | **KILLED** | [FAIL] v status: got 1 exp 0 (id 63) @cycle 73 (init_fill) |
| agu_range_ignored | sf_vspm_agu.sv | range check removed | **KILLED** | [FAIL] v status: got 0 exp 1 (id 197) @cycle 5313 (out_of_bounds) |
| agu_range_unneeded | sf_vspm_agu.sv | range error raised for words that are fully masked off | **KILLED** | [FAIL] v status: got 1 exp 0 (id 63) @cycle 73 (init_fill) |
| agu_align_inverted | sf_vspm_agu.sv | word-alignment rejection removed | **KILLED** | [FAIL] v status: got 0 exp 2 (id 197) @cycle 3859 (out_of_bounds) |
| agu_align_vec_removed | sf_vspm_agu.sv | vector-alignment rejection removed | **KILLED** | [FAIL] v status: got 0 exp 2 (id 197) @cycle 3859 (out_of_bounds) |
| agu_need_all | sf_vspm_agu.sv | every slot accessed regardless of the mask | **KILLED** | [FAIL] v status: got 1 exp 0 (id 63) @cycle 136 (init_fill) |
| agu_own_ignored | sf_vspm_agu.sv | ownership not enforced | **KILLED** | [FAIL] d status: got 0 exp 4 @cycle 21527 (dma_ownership) |
| agu_own_port_swapped | sf_vspm_agu.sv | owners swapped between the ports | **KILLED** | [FAIL] v status: got 4 exp 0 (id 0) @cycle 8 (init_fill) |
| agu_prec_swapped | sf_vspm_agu.sv | error precedence ALIGN/RANGE swapped | **KILLED** | [FAIL] v status: got 1 exp 2 (id 201) @cycle 3861 (out_of_bounds) |
| bankmap_low_wrong_row | sf_vspm_bankmap.sv | LOW map row = w (aliasing) | **KILLED** | [FAIL] init_fill: backdoor mismatch: 1018 bytes differ, first at byte 0 @cycle 106 (init_f |
| bankmap_xor_plain | sf_vspm_bankmap.sv | XOR map degenerates to LOW | **KILLED** | [FAIL] init_fill: backdoor mismatch: 764 bytes differ, first at byte 16 @cycle 106 (init_f |
| bankmap_block_wrong | sf_vspm_bankmap.sv | BLOCK map uses the low bits as the bank | **KILLED** | [FAIL] init_fill: backdoor mismatch: 959 bytes differ, first at byte 0 @cycle 106 (init_fi |
| agu_stride_sign | sf_vspm_agu.sv | stride zero-extended instead of sign-extended | **KILLED** | [FAIL] v status: got 1 exp 0 (id 252) @cycle 27682 (strided_gather_scatter) |
| agu_idx_unsigned | sf_vspm_agu.sv | gather index zero-extended | **KILLED** | [FAIL] v status: got 1 exp 0 (id 32) @cycle 27738 (strided_gather_scatter) |
| sched_highest_slot_first | sf_vspm_port.sv | highest slot wins a bank: scatter overlap order reversed | **KILLED** | [FAIL] TIMEOUT: phase did not complete (deadlock or lost response) @cycle 400805 (back_to_ |
| issue_lost_on_conflict | sf_vspm_port.sv | S1 released although a conflicting slot was not granted | **KILLED** | [FAIL] TIMEOUT: phase did not complete (deadlock or lost response) @cycle 421595 (dma_owne |
| accept_when_full | sf_vspm_port.sv | completion queue overrun | **KILLED** | [FAIL] v id: got 34 exp 31 @cycle 11297 (back_to_back) |
| complete_early | sf_vspm_port.sv | response presented after the FIRST slot returned (multi-slot requests) | **KILLED** | [FAIL] v rdata: got 0022f96538983e6fe39a79df37888d29 exp d522f96538983e6fe39a79df37888d29  |
| got_not_cleared | sf_vspm_port.sv | got mask not cleared on allocation | **KILLED** | [175000] %Error: sf_vspm_port.sv:352: Assertion failed in TOP.tb_vspm.dut.u_vport.unnamedb |
| status_dropped | sf_vspm_port.sv | error status hidden | **KILLED** | [FAIL] v status: got 0 exp 1 (id 197) @cycle 5310 (out_of_bounds) |
| rdata_on_error | sf_vspm_port.sv | data returned with an error status | **KILLED** | [FAIL] v rdata: got fbe82b0e51fd51e0d40cd248b6198428 exp 00000000000000000000000000000000  |
| rsp_id_wrong | sf_vspm_port.sv | response id taken from the wrong entry | **KILLED** | [FAIL] v id: got 0 exp 1 @cycle 11 (init_fill) |
| err_has_effect | sf_vspm_port.sv | errored request still accesses memory | **KILLED** | [FAIL] out_of_bounds: backdoor mismatch: 16 bytes differ, first at byte 0 @cycle 5386 (out |
| wdata_wrong_slot | sf_vspm_port.sv | store data routed by bank number instead of slot | **KILLED** | [FAIL] v rdata: got 38723e6fe39a79df37888d2900edf965 exp d522f96538983e6fe39a79df37888d29  |
| be_wrong_slot | sf_vspm_port.sv | byte enables forced on | **KILLED** | [FAIL] v rdata: got d5221e78e9983e6fe39a79df37888d29 exp d522f96538983e6fe39a79df37888d29  |
| ret_slot_swapped | sf_vspm_port.sv | returned word placed into the wrong window slot | **KILLED** | [FAIL] v rdata: got 0000000010a09133738046fcb860726a exp 10a09133738046fcb860726ae734c833  |
| rsp_not_held | sf_vspm_port.sv | response dropped while the consumer stalls | **KILLED** | [FAIL] vector response changed while stalled @cycle 11286 (back_to_back) |
| cq_ptr_wrap | sf_vspm_port.sv | completion-queue pointer wraps one entry late (non power of two depth) | **KILLED** | [135000] %Error: sf_vspm_port.sv:353: Assertion failed in TOP.tb_vspm.dut.u_vport.unnamedb |
| dma_strobe_ignored | sf_vector_scratchpad.sv | DMA byte strobes ignored: partial beats overwrite neighbouring bytes | **KILLED** | [FAIL] d rdata: got c89e2d1da40dd5e5f12eeb64281a65b2 exp 639e2d1dce55b450f12ee8dd288c656d  |
| own_region_decode | sf_vspm_agu.sv | region taken from the low word bits instead of the high ones | **KILLED** | [FAIL] d status: got 4 exp 0 @cycle 21597 (dma_ownership) |
| sched_prio_stuck | sf_vspm_bank_sched.sv | round-robin pointer does not move after a DMA win (vector starves) | **KILLED** | [FAIL] round robin violated: a port lost the same bank 451 (vector) / 0 (DMA) cycles in a  |
| hook_read_write_swapped | sf_vector_scratchpad.sv | tile hook counts writes as reads | **KILLED** | [FAIL] ev_spm_read/write hook @cycle 7 (init_fill) |
| first_err_port | sf_vector_scratchpad.sv | error port always reported as the vector port | **KILLED** | [FAIL] first-error registers after DMA refusals: sticky=1 code=4 port=0 addr=0 cnt=16 @cyc |
| latency_extra_cycle | sf_vspm_port.sv | response presented one cycle late (caught by the exact-latency check) | **KILLED** | [FAIL] isolated request latency 4 exp 3 (READ_LATENCY 1 + 2 + busiest-bank excess) @cycle  |
| sched_dma_always | sf_vspm_bank_sched.sv | round robin replaced by DMA priority (vector port starves) | **KILLED** | [FAIL] round robin violated: a port lost the same bank 451 (vector) / 0 (DMA) cycles in a  |
| sched_both_granted | sf_vspm_bank_sched.sv | both ports granted the same bank (single-port violated) | **KILLED** | [FAIL] TIMEOUT: phase did not complete (deadlock or lost response) @cycle 421595 (dma_owne |
| sched_tag_port_bit | sf_vspm_bank_sched.sv | DMA responses routed to the vector port | **KILLED** | [215985000] %Error: sf_vspm_port.sv:353: Assertion failed in TOP.tb_vspm.dut.u_vport.unnam |
| own_no_drain | sf_vspm_own.sv | ownership change without draining in-flight accesses | **KILLED** | [FAIL] ownership acknowledged while accesses were still in flight @cycle 25749 (ownership_ |
| own_no_block | sf_vspm_own.sv | ports keep accepting while the owner changes | **KILLED** | [FAIL] DMA request accepted while an ownership change is pending @cycle 25748 (ownership_c |
| own_reserved_accepted | sf_vspm_own.sv | reserved owner value 3 written to the state | **KILLED** | [FAIL] reserved ownership value changed the state @cycle 25636 (dma_ownership) |
| perf_bank_acc | sf_vspm_perf.sv | bank access counter increments by two | **KILLED** | [FAIL] perf bank 0 accesses 348 exp 174 @cycle 30820 (perf_counters) |
| perf_conf_stall | sf_vspm_port.sv | intra-request conflict not reported | **KILLED** | [FAIL] perf V_STALL_CONF 0 exp 96 (isolated requests: busiest bank - 1) @cycle 30820 (perf |
| perf_xtra | sf_vspm_port.sv | alignment overhead under-counted | **KILLED** | [FAIL] perf V_ALIGN_XTRA 108 exp 109 @cycle 30820 (perf_counters) |
| perf_bytes | sf_vspm_port.sv | bytes counted for errored requests | **KILLED** | [FAIL] perf V_BYTES_LD 1896 exp 1087 @cycle 30820 (perf_counters) |
| perf_lat_ref | sf_vspm_port.sv | latency measured from the wrong entry | **KILLED** | [FAIL] perf read latency sum/cnt/max 11489/150/124 exp 363/150/4 @cycle 30820 (perf_counte |
| err_first_overwritten | sf_vector_scratchpad.sv | first-error register overwritten by later errors | **KILLED** | [FAIL] first-error registers after DMA refusals: sticky=1 code=4 port=1 addr=112 cnt=16 @c |
| w256_split | sf_vspm_split.sv | 256-bit: store mask not shifted | **KILLED** | [FAIL] v rdata: got 004a3c61f7593c2f6d76b8fb7a3435dc89b4d7f93327c9d78f72808604fb5fc7 exp c |
| w256_merge | sf_vspm_merge.sv | 256-bit: load data not shifted | **KILLED** | [FAIL] v rdata: got 4a3c61f7593c2f6d76b8fb7a3435dc89b4d7f93327c9d78f72808604fb5fc7a7 exp c |
