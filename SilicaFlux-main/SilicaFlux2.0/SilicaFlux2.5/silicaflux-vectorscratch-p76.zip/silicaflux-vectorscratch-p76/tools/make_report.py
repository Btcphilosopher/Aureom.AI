#!/usr/bin/env python3
"""Generate reports/BANDWIDTH_REPORT.md, reports/SUMMARY.md and reports/figs/*.svg from the measured reports/*.json.

Every number in the generated files comes from those JSON files (RTL simulation / Yosys output).  Every QUALITATIVE claim in the
bandwidth report is first checked against the data by `claim()`; if the data does not support it the script fails instead of
printing it, and the checked claims are listed at the end of the report.
"""
import json, math, os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = os.path.join(ROOT, "reports")
FIG = os.path.join(R, "figs")
os.makedirs(FIG, exist_ok=True)

def load(name, default=None):
    p = os.path.join(R, name)
    return json.load(open(p)) if os.path.exists(p) else default

bench = load("bench.json")
rows = bench["rows"]
claims = []

def get(cfg, wl, duty=0):
    m = [r for r in rows if r["config"] == cfg and r["workload"] == wl and r["dma_duty"] == duty]
    return m[0] if m else None

def claim(text, cond):
    if not cond:
        sys.exit(f"CLAIM NOT SUPPORTED BY THE DATA: {text}")
    claims.append(text)

def bpc(cfg, wl, duty=0):
    r = get(cfg, wl, duty)
    return r["bytes_per_cycle"] if r else None

def f2(x):
    return "-" if x is None else f"{x:.2f}"

# ---------------------------------------------------------------- SVG: grouped horizontal bars (palette validated with validate_palette.js)
LIGHT = dict(surface="#fcfcfb", ink="#0b0b0b", ink2="#52514e", muted="#898781", grid="#e1e0d9", axis="#c3c2b7", s=["#2a78d6", "#eb6834", "#1baf7a"])
DARK = dict(surface="#1a1a19", ink="#f0efec", ink2="#c3c2b7", muted="#898781", grid="#2c2c2a", axis="#383835", s=["#3987e5", "#d95926", "#199e70"])

def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

def grouped_hbars(fname, title, subtitle, cats, series, xlabel, ref=None, xmax=None):
    """series: [(name, [values per category])], at most 3 (validated slots 1-3).  ref: (value, label) vertical reference line."""
    n = len(series)
    barh, gap, grp_gap = 11, 2, 14
    grp = n * barh + (n - 1) * gap
    left, right, top = 200, 40, 84
    W = 760
    H = top + len(cats) * (grp + grp_gap) + 44
    vmax = xmax or max(max(v for v in s[1] if v is not None) for s in series)
    step = 1
    for st in (1, 2, 4, 5, 8, 10, 16, 20, 25, 50, 100):
        if vmax / st <= 7:
            step = st
            break
    xmax = step * math.ceil(vmax / step)
    px = lambda v: left + (W - left - right) * v / xmax
    css = f"""<style>
svg{{--surface:{LIGHT['surface']};--ink:{LIGHT['ink']};--ink2:{LIGHT['ink2']};--muted:{LIGHT['muted']};--grid:{LIGHT['grid']};--axis:{LIGHT['axis']};--s1:{LIGHT['s'][0]};--s2:{LIGHT['s'][1]};--s3:{LIGHT['s'][2]}}}
@media (prefers-color-scheme:dark){{svg{{--surface:{DARK['surface']};--ink:{DARK['ink']};--ink2:{DARK['ink2']};--muted:{DARK['muted']};--grid:{DARK['grid']};--axis:{DARK['axis']};--s1:{DARK['s'][0]};--s2:{DARK['s'][1]};--s3:{DARK['s'][2]}}}}}
text{{font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}}
.bg{{fill:var(--surface)}}.t1{{fill:var(--ink);font-size:15px;font-weight:600}}.t2{{fill:var(--ink2);font-size:12px}}.t3{{fill:var(--muted);font-size:11px}}.cat{{fill:var(--ink2);font-size:12px}}
.grid{{stroke:var(--grid);stroke-width:1}}.axis{{stroke:var(--axis);stroke-width:1}}.ref{{stroke:var(--ink2);stroke-width:1}}
.b1{{fill:var(--s1)}}.b2{{fill:var(--s2)}}.b3{{fill:var(--s3)}}
</style>"""
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" role="img" aria-label="{esc(title)}">', css,
         f'<rect class="bg" width="{W}" height="{H}"/>',
         f'<text class="t1" x="16" y="24">{esc(title)}</text>', f'<text class="t2" x="16" y="42">{esc(subtitle)}</text>']
    lx = 16
    for i, (nm, _) in enumerate(series):                      # legend (always present for >= 2 series)
        o.append(f'<rect class="b{i+1}" x="{lx}" y="53" width="10" height="10" rx="2"/>')
        o.append(f'<text class="t2" x="{lx+15}" y="62">{esc(nm)}</text>')
        lx += 15 + 7 * len(nm) + 22
    ytop, ybot = top - 6, H - 38
    for t in range(0, int(xmax / step) + 1):                  # recessive hairline grid + tick labels
        x = px(t * step)
        o.append(f'<line class="grid" x1="{x:.1f}" y1="{ytop}" x2="{x:.1f}" y2="{ybot}"/>')
        o.append(f'<text class="t3" x="{x:.1f}" y="{ybot+14}" text-anchor="middle">{t*step:g}</text>')
    o.append(f'<line class="axis" x1="{left}" y1="{ytop}" x2="{left}" y2="{ybot}"/>')
    o.append(f'<text class="t3" x="{(left + W - right)/2:.0f}" y="{H-8}" text-anchor="middle">{esc(xlabel)}</text>')
    for ci, cat in enumerate(cats):
        y0 = top + ci * (grp + grp_gap)
        o.append(f'<text class="cat" x="{left-10}" y="{y0 + grp/2 + 4:.1f}" text-anchor="end">{esc(cat)}</text>')
        for si, (nm, vals) in enumerate(series):
            v = vals[ci]
            if v is None:
                continue
            y = y0 + si * (barh + gap)
            w = max(px(v) - left, 0.5)
            r = min(4, w / 2)                                 # 4px rounded data end, square at the baseline
            o.append(f'<path class="b{si+1}" d="M{left},{y} H{left+w-r:.1f} Q{left+w:.1f},{y} {left+w:.1f},{y+r:.1f} V{y+barh-r:.1f} Q{left+w:.1f},{y+barh} {left+w-r:.1f},{y+barh} H{left} Z">'
                     f'<title>{esc(nm)} - {esc(cat)}: {v:.2f}</title></path>')
    if ref:
        x = px(ref[0])
        o.append(f'<line class="ref" x1="{x:.1f}" y1="{ytop}" x2="{x:.1f}" y2="{ybot}"/>')
        o.append(f'<text class="t2" x="{x:.1f}" y="{ytop-4}" text-anchor="end">{esc(ref[1])}</text>')
    o.append("</svg>")
    open(os.path.join(FIG, fname), "w").write("\n".join(o))

W1 = [("seq_load_aligned", "sequential load, aligned"), ("copy_aligned", "copy (load+store), aligned"), ("seq_load_off1word", "sequential load, +1 word"),
      ("seq_load_off1byte", "sequential load, +1 byte"), ("random_mix_aligned", "random load/store, aligned"), ("random_mix_bytes", "random load/store, any byte"),
      ("tail_masked_store", "stores, partial final vector")]

def fig_bw(fname, title, cfgs, labels, peak):
    cats = [w[1] for w in W1]
    series = [(labels[i], [bpc(c, w[0]) for w in W1]) for i, c in enumerate(cfgs)]
    grouped_hbars(fname, title, "useful bytes per cycle, RTL simulation, 2000 requests per workload, LOW bank map, 32-bit banks", cats, series,
                  "useful vector bytes per cycle", ref=(peak, f"vector peak {peak} B/cycle"), xmax=peak * 1.0)

fig_bw("fig1_v128_bank_count.svg", "128-bit vectors: bandwidth by number of banks",
       ["v128_nb2_low", "v128_nb4_low", "v128_nb8_low"], ["2 banks", "4 banks", "8 banks"], 16)
fig_bw("fig2_v256_bank_count.svg", "256-bit vectors: bandwidth by number of banks",
       ["v256_nb4_low", "v256_nb8_low", "v256_nb16_low"], ["4 banks", "8 banks", "16 banks"], 32)
duties = [25, 50, 75, 100]
arb = [("round robin", "v128_nb4_low"), ("vector priority", "v128_nb4_arb_vec"), ("DMA priority", "v128_nb4_arb_dma")]
grouped_hbars("fig3_dma_vector_bw.svg", "Vector stream while the DMA streams: vector bandwidth",
              "128-bit vectors, 4 banks; DMA offers a 16 B beat on the given share of cycles", [f"DMA offers {d}% of cycles" for d in duties],
              [(n, [bpc(c, "dma_vs_seq_load", d) for d in duties]) for n, c in arb], "vector useful bytes per cycle", ref=(16, "vector peak 16 B/cycle"), xmax=16)
def dma_bpc(c, d):
    r = get(c, "dma_vs_seq_load", d)
    return round(r["dma_bytes"] / r["cycles"], 3)
grouped_hbars("fig4_dma_dma_bw.svg", "Vector stream while the DMA streams: DMA bandwidth",
              "same runs; DMA bytes moved divided by the vector stream's run time", [f"DMA offers {d}% of cycles" for d in duties],
              [(n, [dma_bpc(c, d) for d in duties]) for n, c in arb], "DMA bytes per cycle", ref=(16, "DMA beat 16 B/cycle"), xmax=16)

# ---------------------------------------------------------------- numbers used by the text
CFG = {r["config"]: r for r in rows}
def vw(c):   # vector words
    return CFG[c]["VEC_BYTES"] // CFG[c]["BANK_BYTES"]
def peak(c):
    return CFG[c]["VEC_BYTES"]

low_cfgs = [c for c in CFG if CFG[c]["BANK_MAP"] == 0 and CFG[c]["BANK_BYTES"] == 4 and CFG[c]["ALIGN_POLICY"] == 2 and not c.endswith(("_gs", "lat2", "lat3", "dma4B", "arb_vec", "arb_dma"))]
for c in low_cfgs:
    nb = CFG[c]["NB"]
    a = bpc(c, "seq_load_aligned"); b = bpc(c, "seq_load_off1byte")
    ceil = min(peak(c), nb * 4)
    claim(f"{c}: aligned stream reaches the lower of the vector peak ({peak(c)} B/cycle) and the bank ceiling ({nb*4} B/cycle): measured {a}", abs(a - ceil) / ceil < 0.01)
    if nb >= vw(c) + 1:
        claim(f"{c}: byte-misaligned stream is as fast as the aligned one (NB {nb} >= vector words {vw(c)} + 1): {b} vs {a}", abs(a - b) / a < 0.01)
    if nb == vw(c):
        claim(f"{c}: byte-misaligned stream runs at half rate (NB {nb} = vector words {vw(c)}): {b} vs {a}", abs(b / a - 0.5) < 0.01)
claim("v128_nb2_low: with 2 banks a 4-word vector needs 2 cycles aligned (8 B/cycle) and 3 cycles byte-misaligned (5.33 B/cycle)",
      abs(bpc("v128_nb2_low", "seq_load_aligned") - 8) < 0.1 and abs(bpc("v128_nb2_low", "seq_load_off1byte") - 16 / 3) < 0.1)
claim("BLOCK map confines a contiguous vector to one bank: 4 B/cycle (one 32-bit bank) for 128-bit and for 256-bit vectors",
      abs(bpc("v128_nb4_block", "seq_load_aligned") - 4) < 0.1 and abs(bpc("v256_nb8_block", "seq_load_aligned") - 4) < 0.1)
claim("XOR map halves a word-misaligned stream that LOW serves at full rate (row-boundary words collide): 128-bit NB4",
      abs(bpc("v128_nb4_xor", "seq_load_off1word") / bpc("v128_nb4_low", "seq_load_off1word") - 0.5) < 0.02)
claim("16-byte banks (NB 4) serve byte-misaligned 128-bit vectors at full rate: a misaligned vector spans 2 words in 2 different banks",
      abs(bpc("v128_bank16B_nb4", "seq_load_off1byte") - 16) < 0.1)
claim("partial final vectors cost no cycles: tail-masked stores run at one request per cycle (useful bytes/cycle = mask fraction x peak)",
      get("v128_nb4_low", "tail_masked_store")["cycles"] <= get("v128_nb4_low", "tail_masked_store")["vec_req"] + 4)
rd = lambda c, w: get(c, w)["rd_lat_sum"] / get(c, w)["rd_cnt"]
wr = lambda c, w: get(c, w)["wr_lat_sum"] / get(c, w)["wr_cnt"]
for c, L in (("v128_nb4_low", 1), ("v128_nb4_low_lat2", 2), ("v128_nb4_low_lat3", 3)):
    claim(f"{c}: isolated aligned read latency is READ_LATENCY + 2 = {L+2} cycles, write latency the same", rd(c, "iso_load_aligned") == L + 2 and wr(c, "iso_store_aligned") == L + 2)
claim("a byte-misaligned isolated load on 4 banks costs one extra cycle (latency 4)", rd("v128_nb4_low", "iso_load_off1byte") == 4)
for d in (50, 100):
    rr = get("v128_nb4_low", "dma_vs_seq_load", d)
    claim(f"round robin at {d}% DMA offered load: neither port is starved (both finish; vector {rr['bytes_per_cycle']:.2f} B/cycle, DMA {rr['dma_bytes']/rr['cycles']:.2f} B/cycle)", rr["completed"] == rr["vec_req"] and rr["dma_bytes"] > 0)
claim("round robin at 100% offered load shares the banks equally (within 1%)",
      abs(dma_bpc("v128_nb4_low", 100) - bpc("v128_nb4_low", "dma_vs_seq_load", 100)) / 8 < 0.01)
claim("vector priority starves the DMA (< 0.1 B/cycle at 100% offered load)", dma_bpc("v128_nb4_arb_vec", 100) < 0.1)
claim("DMA priority starves the vector port at 100% offered DMA load (the vector stream does not complete)", get("v128_nb4_arb_dma", "dma_vs_seq_load", 100)["starved"] == 1)
claim("bank utilisation reaches 100% of bank-cycles when both ports saturate the banks", get("v128_nb4_low", "dma_vs_seq_load", 100)["bank_util"] > 0.99)
claim("deterministic workloads match the independent analytical model exactly", bench["model_checks"] > 0 and not bench["model_mismatches"])
if get("v128_nb4_low_gs", "gs_stride_nb_words"):
    claim("strided access with stride = NB words puts every lane on one bank under LOW: 4 cycles per request",
          abs(bpc("v128_nb4_low_gs", "gs_stride_nb_words") - 4) < 0.1 and bpc("v128_nb4_xor_gs", "gs_stride_nb_words") > 15)

# ---------------------------------------------------------------- tables
def md_table(head, body):
    return "\n".join(["| " + " | ".join(head) + " |", "|" + "|".join("---:" if i else "---" for i in range(len(head))) + "|"] + ["| " + " | ".join(str(x) for x in r) + " |" for r in body]) + "\n"

order = [c for c in [x["config"] for x in rows] if True]
seen = []
for c in order:
    if c not in seen: seen.append(c)
t1 = []
for c in seen:
    r = CFG[c]
    t1.append([c, f"{r['VEC_BYTES']*8}", f"{r['NB']}x{r['BANK_BYTES']*8}b", ["LOW", "XOR", "BLOCK"][r["BANK_MAP"]], ["vec", "word", "any"][r["ALIGN_POLICY"]], r["NB"] * r["BANK_BYTES"],
               f2(bpc(c, "seq_load_aligned")), f2(bpc(c, "seq_store_aligned")), f2(bpc(c, "copy_aligned")), f2(bpc(c, "fp32_triad_aligned")),
               f"{get(c, 'seq_load_aligned')['bank_util']*100:.0f}%"])
T1 = md_table(["configuration", "vector bits", "banks x word", "map", "align policy", "bank ceiling B/cyc", "seq load", "seq store", "copy", "triad (2 ld + 1 st)", "bank util (seq load)"], t1)

t2 = []
for c in seen:
    if CFG[c]["ALIGN_POLICY"] != 2 or c.endswith(("_gs", "lat2", "lat3", "dma4B", "arb_vec", "arb_dma")):
        continue
    a = get(c, "seq_load_aligned"); o = get(c, "seq_load_off1byte"); w = get(c, "seq_load_off1word"); s = get(c, "seq_store_off1byte")
    t2.append([c, f2(a["bytes_per_cycle"]), f2(w["bytes_per_cycle"]), f2(o["bytes_per_cycle"]), f2(s["bytes_per_cycle"]), f"{o['align_xtra']/o['vec_req']:.2f}",
               f"{o['conf_stall']/o['vec_req']:.2f}", f"{o['cycles']/o['vec_req']:.2f}"])
T2 = md_table(["configuration", "aligned", "+1 word", "+1 byte (load)", "+1 byte (store)", "extra words / request", "conflict-stall cycles / request", "cycles / request (+1 byte)"], t2)

t3 = []
for c in [x for x in seen if x.startswith(("v128_nb4_low", "v128_nb4_xor", "v128_nb4_block", "v256_nb8_low", "v256_nb8_xor", "v256_nb8_block")) and not x.endswith(("lat2", "lat3", "dma4B", "arb_vec", "arb_dma", "alignword", "alignvec"))]:
    t3.append([c, f2(bpc(c, "seq_load_aligned")), f2(bpc(c, "seq_load_off1word")), f2(bpc(c, "random_load_aligned")), f2(bpc(c, "gs_stride_1elem")), f2(bpc(c, "gs_stride_nb_words")),
               f2(bpc(c, "gs_stride_5elem")), f2(bpc(c, "gs_gather_random"))])
T3 = md_table(["configuration", "seq load", "seq load +1 word", "random aligned load", "stride 1 elem", "stride NB words", "stride 5 elems", "random gather"], t3)

t4 = []
for c in ("v128_nb4_low", "v128_nb4_low_lat2", "v128_nb4_low_lat3", "v256_nb8_low", "v512_nb16_low"):
    t4.append([c, CFG[c]["READ_LATENCY"], f"{rd(c, 'iso_load_aligned'):.2f}", f"{wr(c, 'iso_store_aligned'):.2f}",
               f"{rd(c, 'iso_load_off1byte'):.2f}" if get(c, "iso_load_off1byte") else "-", f"{rd(c, 'seq_load_aligned'):.2f}",
               get(c, "seq_load_aligned")["starve"]])
T4 = md_table(["configuration", "READ_LATENCY", "isolated load (cycles)", "isolated store (cycles)", "isolated load, +1 byte", "mean load latency in the stream", "starved cycles in the stream (2000 loads)"], t4)

t5 = []
for n, c in arb:
    for d in duties:
        r = get(c, "dma_vs_seq_load", d)
        t5.append([n, f"{d}%", f"{r['completed']}/{r['vec_req']}", f2(r["bytes_per_cycle"]), f2(r["dma_bytes"] / r["cycles"]), r["arb_stall"], r["dma_arb_stall"],
                   f"{r['bank_util']*100:.0f}%", r["starve"]])
T5 = md_table(["arbitration", "DMA offered", "vector requests completed", "vector B/cycle", "DMA B/cycle", "vector arbitration-loss cycles", "DMA arbitration-loss cycles", "bank utilisation", "vector starved cycles"], t5)

t6 = []
for c in [x for x in seen if x.endswith("_gs")]:
    t6.append([c, f2(bpc(c, "gs_stride_1elem")), f2(bpc(c, "gs_stride_nb_words")), f2(bpc(c, "gs_stride_5elem")), f2(bpc(c, "gs_gather_random")), f2(bpc(c, "gs_scatter_random"))])
T6 = md_table(["configuration", "stride 1 elem", "stride NB words", "stride 5 elems", "random gather", "random scatter"], t6)

t7 = []
for c in ("v128_bank16B_nb4", "v128_nb4_low", "v128_nb8_low", "v256_bank16B_nb4", "v256_bank8B_nb4", "v256_nb8_low"):
    a = get(c, "random_mix_bytes"); b = get(c, "tail_masked_store")
    t7.append([c, f"{CFG[c]['BANK_BYTES']*8}b", f2(a["bytes_per_cycle"]), f"{a['v_word_acc']/a['vec_req']:.2f}", f"{a['useful_bytes']/(a['v_word_acc']*CFG[c]['BANK_BYTES']):.2f}",
               f"{b['useful_bytes']/(b['v_word_acc']*CFG[c]['BANK_BYTES']):.2f}"])
T7 = md_table(["configuration", "bank word", "random byte-addressed mix B/cycle", "bank accesses / request", "useful / accessed bytes (random bytes)", "useful / accessed bytes (partial final vectors)"], t7)

# ---------------------------------------------------------------- BANDWIDTH_REPORT.md
rep = f"""# VectorScratch bandwidth report

*SilicaFlux-HPC Project 76 - `sf_vector_scratchpad`. Everything below is **RTL simulation** (Verilator 5.020, `tb/tb_bench.sv`) with the design's own
performance counters; no number is a silicon, timing or power measurement.* Reproduce: `python3 sim/run_bench.py` then `python3 tools/make_report.py`.

## How to read the numbers

* **Useful bytes per cycle** = sum over completed vector requests of the number of ENABLED bytes (mask popcount) divided by the cycles from the first
  accepted request to the last response handshake. A 2000-request run includes the pipeline fill (3 cycles), so a perfect stream reads 15.98, not 16.
* **Vector peak** = one request per cycle = `VEC_BYTES` per cycle (16 for 128-bit, 32 for 256-bit, 64 for 512-bit). **Bank ceiling** = `NB x bank word`
  bytes per cycle: with fewer banks than the vector has words, the banks - not the vector port - are the limit, and the report shows that limit, not the peak.
* Banks are **single-port**: one access per bank per cycle. When two words of one request (or of the two ports) want one bank, the accesses are serialised, the
  conflict is counted (`V_STALL_CONF`, `V_STALL_ARB`, per-bank counters) and the request takes more cycles. **Nothing in this report assumes full vector
  bandwidth where the banks cannot deliver it.**
* The source never idles and the consumer is always ready (except the serial `iso_*` latency workloads); the DMA agent offers one 16-byte beat on the stated
  share of cycles. Workloads are deterministic (fixed seeds), so every row is reproducible bit for bit.

## 1 Aligned streams: full bandwidth when the banks allow it

![128-bit bandwidth by bank count](figs/fig1_v128_bank_count.svg)

![256-bit bandwidth by bank count](figs/fig2_v256_bank_count.svg)

Useful bytes per cycle, all configurations (32-bit banks unless the "banks x word" column says otherwise):

{T1}
Findings (each one is checked against the data by `tools/make_report.py` before it is printed):

* An aligned vector stream runs at **one vector per cycle** whenever the banks can supply it (`NB x word >= vector bytes`, LOW or XOR map) and at the bank
  ceiling otherwise (2 banks x 4 B = 8 B/cycle for a 128-bit vector).
* Loads, stores and a copy / triad mix all sustain the same rate: reads and writes share the same single-port banks and neither costs extra cycles.
* The **BLOCK** map puts a contiguous vector in a single bank, so the stream collapses to **one bank word per cycle (4 B/cycle)** - the deliberate worst case.

## 2 Alignment overhead (the split / merge datapath)

{T2}
A vector that starts inside a word touches `VEC_BYTES / word + 1` words. With LOW mapping and `NB >= vector words + 1` they all sit in distinct banks and the
byte-misaligned stream runs at **full rate**; with `NB = vector words` the extra word lands on the bank of the first one and every request takes **two cycles
(half rate)**; with fewer banks it is worse (2 banks: 3 cycles for a 128-bit vector). The cost is conflict stalls, not data movement: the split / merge itself
is free in cycles. *Word*-misaligned streams (start offset a multiple of 4 B) never add words and are conflict free under LOW.

Alignment *policy* A (reject misaligned requests) costs nothing and answers `SF_ST_ALIGN`; the `v128_nb4_low_alignword` / `_alignvec` rows run only the supported
workloads. Wide (16-byte) banks make byte-misaligned 128-bit vectors free (2 words in 2 banks) but cost bank bandwidth elsewhere, see section 6.

## 3 Bank mapping

{T3}
* **LOW** serves contiguous and word-misaligned vectors at full rate but puts a stride of `NB` words on a single bank.
* **XOR** spreads the stride-`NB` pattern over all banks, **but it is worse than LOW for word-misaligned contiguous streams** (half rate in the 128-bit, 4-bank
  case): a vector that straddles a row boundary sees two different XOR keys, so two of its words can land on the same bank. XOR trades contiguous
  misaligned performance for power-of-two-stride performance; choose by workload.
* **BLOCK** is for isolation (each bank is a contiguous region, so a DMA buffer can have a bank to itself), not for bandwidth.

## 4 Latency

{T4}
A load or store that hits distinct banks completes in `READ_LATENCY + 2` cycles from the accepting edge to the response handshake (accept, issue,
`READ_LATENCY` bank cycles, window capture; the response is combinational from the completion queue). Every extra access to the busiest bank adds one cycle. A request
with an error status or an empty mask never touches a bank and completes in one cycle. The exact formula is asserted for every isolated request by `tb/tb_vspm.sv`.
The stream rows show the design sustains one request per cycle with 3 cycles of latency, so a consumer that issues loads early enough is never starved: the
**starved cycles** column (consumer ready, nothing deliverable, work outstanding) is just the 2 pipeline-fill cycles; the isolated loads of the serial workload show
the starvation a consumer sees when it cannot hide the latency (2 cycles per load).

## 5 DMA and vector traffic on the same banks

![vector bandwidth while the DMA streams](figs/fig3_dma_vector_bw.svg)

![DMA bandwidth while the vector port streams](figs/fig4_dma_dma_bw.svg)

{T5}
* **Round robin** (default): both ports always make progress; at 100% offered DMA load each gets half of what one port could (8 B/cycle each) and the
  banks are 100% busy. The per-bank bound (a port loses a bank at most once in a row) is checked in `tb/tb_vspm.sv`.
* **Vector priority** keeps the vector stream at full rate and **starves the DMA** (< 0.1 B/cycle). **DMA priority** does the reverse and **starves the vector
  port completely** when the DMA saturates the banks (the vector run was cut after 20x its ideal time with only a few requests done). Both are available because
  some systems want them; they are measured here so nobody finds out in the field.
* Isolation by mapping or ownership needs no arbitration at all: region ownership (`sf_vspm_own`) keeps the ports' data apart, and with the BLOCK map and a
  DMA region on its own bank the two streams do not collide.

## 6 Strided, gather and scatter (optional, `GS_EN = 1`)

{T6}
Element accesses are limited by how many of the lanes' words share a bank: a unit stride (1 element) is conflict free; a stride of `NB` words puts all lanes on
one bank under LOW (4 cycles for 4 lanes); the XOR map removes exactly that case; random gathers behave like random bank loads. Overlapping scatter lanes are
executed in lane order: **the highest lane wins** (checked bit-exactly).

## 7 Bank word width, useful bytes and memory utilisation

{T7}
A bank access always moves a whole bank word; **useful / accessed bytes** says how much of it was wanted. Narrow (32-bit) banks waste little on partial final
vectors and byte-granular masks; 16-byte banks make misaligned vectors free but touch 4x the bytes per access (higher energy per useful byte in a real macro -
not measured here). The vector width and the bank word width are independent knobs; see `docs/05_memory_mapping.md` for how each maps onto block RAM / macros.

## 8 Validation of the measurements

{bench['model_checks']} deterministic (workload, configuration) pairs were also predicted by an independent Python model (sum over requests of the busiest-bank load
plus `READ_LATENCY + 2`, `sim/run_bench.py`). **All {bench['model_checks'] - len(bench['model_mismatches'])} agree with the RTL cycle for cycle.** Random workloads and
DMA contention cannot be predicted that way; they are checked for internal consistency instead (counted requests, useful bytes and per-bank accesses equal the
testbench's own accounting in every run).

## 9 Checked claims

{chr(10).join('* ' + c for c in claims)}

## 10 Limits

RTL simulation only: no timing (so no GB/s), no power, no place-and-route. Arrival patterns are synthetic. Random workloads are single-seed. The DMA agent is a
simple streaming source, not a particular DMA engine (the real CloudDMA is exercised for correctness in `tb/tb_clouddma_int.sv`, not for bandwidth).
"""
open(os.path.join(R, "BANDWIDTH_REPORT.md"), "w").write(rep)

# ---------------------------------------------------------------- SUMMARY.md
reg = load("regress.json"); ric = load("regress_icarus.json"); un = load("units.json"); it = load("integration.json"); mu = load("mutation.json"); sy = load("synthesis.json")
tool = lambda n, d: d.get(n) if d else None
lines = ["# VectorScratch (Project 76) - verification and results summary", "",
         "Generated from `reports/*.json` by `tools/make_report.py`. Every row is a tool result; \"not run\" is stated where a step was not run.", "",
         "| check | result | source |", "|---|---|---|"]
if reg:
    lines.append(f"| Verilator regression: configuration matrix of `tb_vspm` | **{reg['passed']}/{reg['total']} cases PASS**, {reg['checks']:,} self-checks | `regress.json` ({reg['tool']}) |")
if ric:
    lines.append(f"| Icarus cross-simulation of the same matrix | **{ric['passed']}/{ric['total']} cases PASS** ({ric.get('skipped', 0)} skipped: BACKEND=2), {ric['checks']:,} self-checks | `regress_icarus.json` ({ric['tool']}) |")
if un:
    lines.append(f"| unit tests: bank map, split/merge (exhaustive masks), package | **{sum(1 for u in un if u['status']=='PASS')}/{len(un)} shapes PASS**, {sum(u.get('checks', 0) for u in un):,} checks | `units.json` |")
if it:
    lines.append(f"| integration: real CloudDMA, lane-masked beats (FP32 / 64-bit) | **{sum(1 for u in it if u['status']=='PASS')}/{len(it)} PASS**, {sum(u.get('checks', 0) for u in it):,} checks | `integration.json` |")
if mu:
    k = sum(1 for m in mu if m["status"] == "KILLED")
    lines.append(f"| mutation testing of the testbench | **{k}/{len(mu)} injected bugs killed** ({sum(1 for m in mu if m['status']=='SURVIVED')} survived, {sum(1 for m in mu if m['status']=='BUILD-ERROR')} invalid) | `mutation.json`, `mutation.md` |")
lines.append(f"| bandwidth sweep | {len(rows)} measured rows, {len(set(r['config'] for r in rows))} configurations; **{bench['model_checks'] - len(bench['model_mismatches'])}/{bench['model_checks']}** deterministic workloads equal the independent analytical model | `bench.csv`, `bench.json` |")
if sy:
    g = sy["generic"]
    lines.append(f"| synthesis (Yosys generic gates) | {sum(1 for r in g if r['status']=='OK')}/{len(g)} configurations / blocks synthesize, 0 latches | `synthesis.md` |")
    lines.append(f"| FPGA block-RAM inference (`synth_xilinx xc7`) | {sum(1 for r in sy['fpga'] if r['status']=='OK')}/{len(sy['fpga'])} configurations | `synthesis.md` |")
    lines.append(f"| SKY130 macro tiling (structural) | {sum(1 for r in sy['asic'] if r['status']=='OK' and r['macros']==r['expected_macros'])}/{len(sy['asic'])} macro counts equal the tiling formula | `synthesis.md` |")
lines += ["", "Not run / not available: Vivado, Quartus, OpenROAD, Liberty-based synthesis, SymbiYosys (no formal proof of this design), gate-level simulation, FPGA hardware.", ""]
open(os.path.join(R, "SUMMARY.md"), "w").write("\n".join(lines))
print("wrote BANDWIDTH_REPORT.md, SUMMARY.md and 4 figures;", len(claims), "claims verified against the data")
