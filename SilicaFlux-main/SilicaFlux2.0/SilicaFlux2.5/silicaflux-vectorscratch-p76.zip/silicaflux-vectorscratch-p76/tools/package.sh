#!/usr/bin/env bash
# Build the deliverable zip: everything except build products; MANIFEST.sha256 is regenerated first.
# zip -FS makes the archive match the files on disk, so a stale archive is replaced without deleting anything.
set -e
cd "$(dirname "$0")/.."
NAME=$(basename "$PWD")
OUT=$(realpath -m "${1:-../$NAME.zip}")      # resolved BEFORE changing directory
find . -type f ! -path './build/*' ! -name 'MANIFEST.sha256' ! -name '*.pyc' ! -path '*/__pycache__/*' | sort | xargs sha256sum > MANIFEST.sha256
cd ..
zip -qrD -FS "$OUT" "$NAME" -x "$NAME/build/*" -x "*/__pycache__/*" -x "*.pyc"
echo "wrote $OUT ($(du -h "$OUT" | cut -f1)); $(unzip -l "$OUT" | tail -1)"
