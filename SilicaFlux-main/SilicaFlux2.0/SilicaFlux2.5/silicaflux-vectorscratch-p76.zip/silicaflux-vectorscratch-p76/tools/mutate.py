#!/usr/bin/env python3
"""Mutation testing of the testbench: inject ONE textual bug into a copy of the RTL, rebuild, run, require the testbench to FAIL.

    python3 tools/mutate.py [--jobs 3] [--only NAME ...] [--list]   ->  reports/mutation.json, reports/mutation.md

A mutant that still prints `PASS` SURVIVED: the testbench cannot see that bug.  A mutant whose build fails is reported as
BUILD-ERROR (the mutation itself was invalid) and does NOT count as killed.  The mutant list is hand written (what could go
wrong in a design like this); a full kill count says nothing about faults nobody thought to inject.
Each mutant states the TB configuration (-G overrides) it is run with, chosen so that the mutated logic is exercised.
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-DECLFILENAME", "--assert", "-DSF_ASSERT"]

def M(name, f, old, new, cfg, why, count=1):
    return dict(name=name, file=f, old=old, new=new, cfg=cfg, why=why, count=count)

BASE = {"STAGE": 9}
G2 = dict(BASE, GS_EN=1)                      # gather / scatter configuration
W256 = dict(BASE, VEC_BYTES=32, NB=8, DMA_BYTES=16)
MUTANTS = [
    # ---- alignment / split / merge
    M("split_no_shift", "sf_vspm_split.sv", "wmask = m_ext << off;", "wmask = m_ext;", BASE, "store mask not shifted by the byte offset"),
    M("split_data_no_shift", "sf_vspm_split.sv", "wwd   = d_ext << {off, 3'b000};", "wwd   = d_ext;", BASE, "store data not shifted by the byte offset"),
    M("merge_no_shift", "sf_vspm_merge.sv", "sh = win >> {off, 3'b000};", "sh = win;", BASE, "load data not shifted back by the offset"),
    M("merge_no_zero", "sf_vspm_merge.sv", "rdata[j*8 +: 8] = mask[j] ? sh[j*8 +: 8] : 8'h00;", "rdata[j*8 +: 8] = sh[j*8 +: 8];", BASE, "masked-off load bytes not zeroed"),
    M("off_ignored_port", "sf_vspm_port.sv", "req_addr[OFFW-1:0] : '0;", "'0 : '0;", BASE, "port always uses offset 0 (misaligned data wrong)"),
    M("off_stored_wrong", "sf_vspm_port.sv", "cq_off[e*OFFW +: OFFW]         <= off;", "cq_off[e*OFFW +: OFFW]         <= '0;", BASE, "response merge uses offset 0"),
    # ---- AGU / mapping
    M("agu_slot_plus_zero", "sf_vspm_agu.sv", "assign wi_c = (AWX'(addr) >> LBB) + AWX'(s);", "assign wi_c = (AWX'(addr) >> LBB) + AWX'(s & 1);", BASE, "slot k maps to the wrong word for k >= 2"),
    M("agu_range_off_by_one", "sf_vspm_agu.sv", "wire inr = ((wi >> LTW) == '0);", "wire inr = (((wi + 1) >> LTW) == '0);", BASE, "last word of the aperture wrongly out of range"),
    M("agu_range_ignored", "sf_vspm_agu.sv", "assign bad_range[s] = need[s] & ~inr;", "assign bad_range[s] = 1'b0;", BASE, "range check removed"),
    M("agu_range_unneeded", "sf_vspm_agu.sv", "assign bad_range[s] = need[s] & ~inr;", "assign bad_range[s] = ~inr;", BASE, "range error raised for words that are fully masked off"),
    M("agu_align_inverted", "sf_vspm_agu.sv", "`SF_VM_ALIGN_WORD: align_bad = |addr[LBB-1:0];", "`SF_VM_ALIGN_WORD: align_bad = 1'b0;", dict(BASE, ALIGN_POLICY=1), "word-alignment rejection removed"),
    M("agu_align_vec_removed", "sf_vspm_agu.sv", "`SF_VM_ALIGN_VEC:  align_bad = |addr[LVB-1:0];", "`SF_VM_ALIGN_VEC:  align_bad = 1'b0;", dict(BASE, ALIGN_POLICY=0), "vector-alignment rejection removed"),
    M("agu_need_all", "sf_vspm_agu.sv", "assign need[s] = |wmask[s*BB +: BB];", "assign need[s] = 1'b1;", BASE, "every slot accessed regardless of the mask"),
    M("agu_own_ignored", "sf_vspm_agu.sv", "wire allowed = (o == `SF_VM_OWN_SHARED) || (o == ((PORT == 0) ? `SF_VM_OWN_VEC : `SF_VM_OWN_DMA));", "wire allowed = 1'b1;", BASE, "ownership not enforced"),
    M("agu_own_port_swapped", "sf_vspm_agu.sv", "(o == ((PORT == 0) ? `SF_VM_OWN_VEC : `SF_VM_OWN_DMA))", "(o == ((PORT == 0) ? `SF_VM_OWN_DMA : `SF_VM_OWN_VEC))", BASE, "owners swapped between the ports"),
    M("agu_prec_swapped", "sf_vspm_agu.sv", "else if (align_bad)      err = `SF_ST_ALIGN;\n    else if (|bad_range)     err = `SF_ST_RANGE;", "else if (|bad_range)     err = `SF_ST_RANGE;\n    else if (align_bad)      err = `SF_ST_ALIGN;", dict(BASE, ALIGN_POLICY=1), "error precedence ALIGN/RANGE swapped"),
    M("bankmap_low_wrong_row", "sf_vspm_bankmap.sv", "row  = RW'(w_hi_nb);\n      end\n    endcase", "row  = RW'(widx);\n      end\n    endcase", BASE, "LOW map row = w (aliasing)"),
    M("bankmap_xor_plain", "sf_vspm_bankmap.sv", "bank = BW'((widx ^ w_hi_nb) & WIW'(NB - 1));", "bank = BW'(widx & WIW'(NB - 1));", dict(BASE, BANK_MAP=1), "XOR map degenerates to LOW"),
    M("bankmap_block_wrong", "sf_vspm_bankmap.sv", "bank = BW'(w_hi_rw & WIW'(NB - 1));", "bank = BW'(widx & WIW'(NB - 1));", dict(BASE, BANK_MAP=2), "BLOCK map uses the low bits as the bank"),
    M("agu_stride_sign", "sf_vspm_agu.sv", "str_s   = $signed({{(AWX - AW){stride[AW-1]}}, stride});", "str_s   = $signed({{(AWX - AW){1'b0}}, stride});", G2, "stride zero-extended instead of sign-extended"),
    M("agu_idx_unsigned", "sf_vspm_agu.sv", "idx_s = $signed({{(AWX - IDXW){idx[l*IDXW + IDXW - 1]}}, idx[l*IDXW +: IDXW]});", "idx_s = $signed({{(AWX - IDXW){1'b0}}, idx[l*IDXW +: IDXW]});", G2, "gather index zero-extended"),
    # ---- port: scheduling, ordering, completion
    M("sched_highest_slot_first", "sf_vspm_port.sv", "if (pend[k] && !cand_valid[b] && 32'(s1_bank[k*BW +: BW]) == b) begin", "if (pend[k] && 32'(s1_bank[k*BW +: BW]) == b) begin", G2, "highest slot wins a bank: scatter overlap order reversed"),
    M("issue_lost_on_conflict", "sf_vspm_port.sv", "assign s1_free = s1_valid && ((pend & ~slot_gnt) == '0);", "assign s1_free = s1_valid && ((pend & ~slot_cand) == '0);", BASE, "S1 released although a conflicting slot was not granted"),
    M("accept_when_full", "sf_vspm_port.sv", "wire cq_space = (cq_cnt != CNTW'(CQ_DEPTH));", "wire cq_space = 1'b1;", dict(BASE, CQ_DEPTH=3), "completion queue overrun"),
    M("complete_early", "sf_vspm_port.sv", "wire             h_done = (cq_cnt != '0) && (h_got == h_need);", "wire             h_done = (cq_cnt != '0) && ((h_got | h_need) != '0) && (h_got != '0 || h_need == '0);", BASE, "response presented after the FIRST slot returned (multi-slot requests)"),
    M("got_not_cleared", "sf_vspm_port.sv", "cq_got[e*NW +: NW]             <= '0;", "cq_got[e*NW +: NW]             <= cq_got[e*NW +: NW];", BASE, "got mask not cleared on allocation"),
    M("status_dropped", "sf_vspm_port.sv", "assign rsp_status = h_st;", "assign rsp_status = `SF_ST_OK;", BASE, "error status hidden"),
    M("rdata_on_error", "sf_vspm_port.sv", "assign rsp_rdata  = (h_we || h_st != `SF_ST_OK) ? '0 : merged;", "assign rsp_rdata  = h_we ? '0 : merged;", BASE, "data returned with an error status"),
    M("rsp_id_wrong", "sf_vspm_port.sv", "assign rsp_id     = cq_id[32'(cq_head)*IDW +: IDW];", "assign rsp_id     = cq_id[32'(cq_tail)*IDW +: IDW];", BASE, "response id taken from the wrong entry"),
    M("err_has_effect", "sf_vspm_port.sv", "wire [NW-1:0] need_eff = (err == `SF_ST_OK) ? need : '0;", "wire [NW-1:0] need_eff = need;", BASE, "errored request still accesses memory"),
    M("wdata_wrong_slot", "sf_vspm_port.sv", "cand_wd[b*BB*8 +: BB*8] = s1_wd[k*BB*8 +: BB*8];", "cand_wd[b*BB*8 +: BB*8] = s1_wd[b*BB*8 +: BB*8];", BASE, "store data routed by bank number instead of slot"),
    M("be_wrong_slot", "sf_vspm_port.sv", "cand_be[b*BB +: BB]     = s1_be[k*BB +: BB];", "cand_be[b*BB +: BB]     = {BB{1'b1}};", BASE, "byte enables forced on"),
    M("ret_slot_swapped", "sf_vspm_port.sv", "cq_win[(e*NW + s)*BB*8 +: BB*8] <= wr_d[s*BB*8 +: BB*8];", "cq_win[(e*NW + s)*BB*8 +: BB*8] <= wr_d[((s + 1) % NW)*BB*8 +: BB*8];", BASE, "returned word placed into the wrong window slot"),
    M("rsp_not_held", "sf_vspm_port.sv", "wire pop = rsp_valid & rsp_ready;", "wire pop = rsp_valid;", BASE, "response dropped while the consumer stalls"),
    M("cq_ptr_wrap", "sf_vspm_port.sv", "inc_ptr = (32'(p) == CQ_DEPTH - 1) ? '0 : p + 1'b1;", "inc_ptr = (32'(p) == CQ_DEPTH) ? '0 : p + 1'b1;", dict(BASE, CQ_DEPTH=3), "completion-queue pointer wraps one entry late (non power of two depth)"),
    M("dma_strobe_ignored", "sf_vector_scratchpad.sv", ".req_mask(d_req_write ? d_req_wstrb : {DMA_BYTES{1'b1}})", ".req_mask({DMA_BYTES{1'b1}})", BASE, "DMA byte strobes ignored: partial beats overwrite neighbouring bytes"),
    M("own_region_decode", "sf_vspm_agu.sv", "assign rg = wi[LTW-1 -: RGW];", "assign rg = wi[RGW-1:0];", BASE, "region taken from the low word bits instead of the high ones"),
    M("sched_prio_stuck", "sf_vspm_bank_sched.sv", "if (g1[b]) prio[b] <= 1'b0;                          // DMA won: the vector port is next", "if (g1[b]) prio[b] <= 1'b1;", BASE, "round-robin pointer does not move after a DMA win (vector starves)"),
    M("hook_read_write_swapped", "sf_vector_scratchpad.sv", "assign ev_spm_read_o     = add2(v_ld, d_rd);", "assign ev_spm_read_o     = add2(v_st, d_wr);", BASE, "tile hook counts writes as reads"),
    M("first_err_port", "sf_vector_scratchpad.sv", "e_port = ~v_ev_acc_err;", "e_port = 1'b0;", BASE, "error port always reported as the vector port"),
    M("latency_extra_cycle", "sf_vspm_port.sv", "assign rsp_valid  = h_done;", "logic h_done_q;\n  always_ff @(posedge clk) h_done_q <= h_done;\n  assign rsp_valid  = h_done & h_done_q;", BASE, "response presented one cycle late (caught by the exact-latency check)"),
    # ---- scheduler / DMA
    M("sched_dma_always", "sf_vspm_bank_sched.sv", "default:        begin if (prio[b]) g1[b] = 1'b1; else g0[b] = 1'b1; end", "default:        begin g1[b] = 1'b1; end", BASE, "round robin replaced by DMA priority (vector port starves)"),
    M("sched_both_granted", "sf_vspm_bank_sched.sv", "default:        begin if (prio[b]) g1[b] = 1'b1; else g0[b] = 1'b1; end", "default:        begin g1[b] = 1'b1; g0[b] = 1'b1; end", BASE, "both ports granted the same bank (single-port violated)"),
    M("sched_tag_port_bit", "sf_vspm_bank_sched.sv", "b_tag[b*TWB + TWB - 1]   = 1'b1;                   // port bit: DMA", "b_tag[b*TWB + TWB - 1]   = 1'b0;", BASE, "DMA responses routed to the vector port"),
    M("own_no_drain", "sf_vspm_own.sv", "end else if (idle_i) begin", "end else begin", BASE, "ownership change without draining in-flight accesses"),
    M("own_no_block", "sf_vspm_own.sv", "assign blk_o     = busy;", "assign blk_o     = 1'b0;", BASE, "ports keep accepting while the owner changes"),
    M("own_reserved_accepted", "sf_vspm_own.sv", "if (val_q == 2'd3) err_o <= 1'b1;\n        else if", "if (1'b0) err_o <= 1'b1;\n        else if", BASE, "reserved owner value 3 written to the state"),
    # ---- reuse / counters
    M("perf_bank_acc", "sf_vspm_perf.sv", "if (bank_acc_i[i]  && ca != ALL1) ca <= ca + 1'b1;", "if (bank_acc_i[i]  && ca != ALL1) ca <= ca + 2'd2;", BASE, "bank access counter increments by two"),
    M("perf_conf_stall", "sf_vspm_port.sv", "assign ev_stall_conf = |(pend & ~slot_cand);", "assign ev_stall_conf = 1'b0;", BASE, "intra-request conflict not reported"),
    M("perf_xtra", "sf_vspm_port.sv", "nneed > nneed0) ? XW'(nneed - nneed0) : '0;", "nneed > nneed0) ? XW'(1) : '0;", BASE, "alignment overhead under-counted"),
    M("perf_bytes", "sf_vspm_port.sv", "ev_bytes    = (acc && err == `SF_ST_OK) ? BYW'(nbytes) : '0;", "ev_bytes    = (acc) ? BYW'(nbytes) : '0;", BASE, "bytes counted for errored requests"),
    M("perf_lat_ref", "sf_vspm_port.sv", "assign ev_lat        = cyc_i - cq_t0[32'(cq_head)*LATW +: LATW];", "assign ev_lat        = cyc_i - cq_t0[32'(cq_tail)*LATW +: LATW];", BASE, "latency measured from the wrong entry"),
    M("err_first_overwritten", "sf_vector_scratchpad.sv", "if (!err_sticky_o) begin", "if (1'b1) begin", BASE, "first-error register overwritten by later errors"),
    # ---- 256-bit
    M("w256_split", "sf_vspm_split.sv", "wmask = m_ext << off;", "wmask = m_ext;", W256, "256-bit: store mask not shifted"),
    M("w256_merge", "sf_vspm_merge.sv", "sh = win >> {off, 3'b000};", "sh = win;", W256, "256-bit: load data not shifted"),
]


def build_and_run(mut, outdir):
    d = os.path.join(outdir, mut["name"])
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(os.path.join(d, "rtl"))
    for fn in os.listdir(os.path.join(ROOT, "rtl")):
        shutil.copy(os.path.join(ROOT, "rtl", fn), os.path.join(d, "rtl", fn))
    p = os.path.join(d, "rtl", mut["file"])
    src = open(p).read()
    if mut["old"] not in src:
        return dict(name=mut["name"], status="BUILD-ERROR", detail="pattern not found")
    open(p, "w").write(src.replace(mut["old"], mut["new"], mut["count"]))
    fl = []
    for line in open(os.path.join(ROOT, "sim", "files_rtl.f")):
        line = line.rstrip("\n")
        if line.startswith("rtl/"):
            line = os.path.join(d, line)
        elif line.startswith("+incdir+rtl"):
            line = "+incdir+" + os.path.join(d, "rtl")
        elif not line.startswith(("//", "+")) and line.strip():
            line = os.path.join(ROOT, line)
        elif line.startswith("+incdir+"):
            line = "+incdir+" + os.path.join(ROOT, line[len("+incdir+"):])
        fl.append(line)
    flist = os.path.join(d, "files.f")
    open(flist, "w").write("\n".join(fl) + "\n")
    gs = [f"-G{k}={v}" for k, v in mut["cfg"].items()]
    r = subprocess.run(["verilator"] + VFLAGS + ["--top-module", "tb_vspm", "-f", flist, os.path.join(ROOT, "tb", "tb_vspm.sv"),
                        "-Mdir", d, "-o", "simv"] + gs, capture_output=True, text=True)
    if r.returncode != 0:
        return dict(name=mut["name"], status="BUILD-ERROR", detail=(r.stdout + r.stderr)[-300:])
    t0 = time.time()
    try:
        r = subprocess.run([os.path.join(d, "simv")], capture_output=True, text=True, timeout=900)
    except subprocess.TimeoutExpired:
        return dict(name=mut["name"], status="KILLED", detail="timeout (deadlock)", secs=900)
    out = r.stdout + r.stderr
    m = re.search(r"RESULT .*", out)
    res = m.group(0) if m else "no RESULT line"
    killed = ("FAIL" in res) or (not m) or ("%Error" in out) or ("Assertion" in out) or ("assert" in out.lower() and "failed" in out.lower())
    first = next((l.strip() for l in out.splitlines() if "[FAIL]" in l or "rror" in l), "")
    return dict(name=mut["name"], status="KILLED" if killed else "SURVIVED", detail=(first or res)[:200], secs=round(time.time() - t0, 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        for m in MUTANTS:
            print(f"{m['name']:28s} {m['file']:22s} {m['why']}")
        return 0
    muts = [m for m in MUTANTS if not a.only or m["name"] in a.only]
    outdir = os.path.join(ROOT, "build", "mutants")
    os.makedirs(outdir, exist_ok=True)
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(lambda m: build_and_run(m, outdir), muts))
    why = {m["name"]: m for m in MUTANTS}
    for r in res:
        r["file"] = why[r["name"]]["file"]
        r["why"] = why[r["name"]]["why"]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "mutation.json"), "w"), indent=1)
    k = sum(1 for r in res if r["status"] == "KILLED")
    be = sum(1 for r in res if r["status"] == "BUILD-ERROR")
    md = ["# Mutation testing of the testbench", "",
          f"{len(res)} mutants: **{k} killed**, {sum(1 for r in res if r['status'] == 'SURVIVED')} survived, {be} build errors (invalid mutations, not counted as killed).", "",
          "| mutant | file | what is broken | result | first failure seen |", "|---|---|---|---|---|"]
    for r in res:
        md.append(f"| {r['name']} | {r['file']} | {r['why']} | **{r['status']}** | {r.get('detail', '').replace('|', '/')[:90]} |")
    open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(md) + "\n")
    for r in res:
        print(f"{r['name']:28s} {r['status']:12s} {r.get('detail', '')[:90]}")
    print(f"killed {k}/{len(res)}  build-errors {be}")
    return 0 if k == len(res) else 1

if __name__ == "__main__":
    sys.exit(main())
