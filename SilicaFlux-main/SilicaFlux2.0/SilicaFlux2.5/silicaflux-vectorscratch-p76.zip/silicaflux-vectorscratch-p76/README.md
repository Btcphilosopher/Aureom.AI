# SilicaFlux VectorScratch (Project 76) - wide-vector SRAM scratchpad

Aureom.AI | SilicaFlux-HPC. Synthesizable SystemVerilog + executable verification + measured bandwidth / synthesis reports for `sf_vector_scratchpad`, the memory subsystem of the SilicaFlux FP32 vector engine.

> **Read first.** Everything here is **RTL simulation** (Verilator 5.020, Icarus 12.0) and **Yosys 0.33 synthesis / inference** results. There is **no silicon, timing, power or place-and-route data**, no formal proof, and the design is not wired into the HPC tile (docs/08). Generic-gate counts are not area; no clock frequency or GB/s figure is claimed. See `docs/KNOWN_LIMITATIONS.md`.
> Nothing was committed to git; this package was produced as a zip as requested.

## What it does

* **Wide loads and stores** of `VEC_BYTES` bytes (16 = 128 bit, 32 = 256 bit, 64 = 512 bit tested; any power of two by parameter) with a **per-byte enable mask** on every access: masked-off bytes of a store are never modified, masked-off bytes of a load read 0, a word whose bytes are all masked off is not accessed. Memory is **raw bits** (FP32 NaN payloads, -0, denormals and 64-bit elements round-trip unchanged).
* **Byte addressing and alignment.** Policy A (reject unsupported alignment with `SF_ST_ALIGN`) or policy B (**split / merge** across adjacent words and banks, any byte address) by parameter. Crossing a word, bank, row or the aperture end is handled; tail masks and partial final vectors work.
* **Banking.** `NB` single-port banks of 32-bit words (default; 16-byte banks are a configuration too), bank maps LOW / XOR / BLOCK, a per-bank **scheduler** that serialises slots that share a bank, conflict counters, per-bank utilisation counters. **The design never reports more bandwidth than its banks can deliver** (the bandwidth report shows the half-rate and bank-limited cases explicitly).
* **Pipeline** with back-pressure on both channels, in-order completion queue, exactly one response per request, errored requests with **no side effect** (`RANGE`, `ALIGN`, `OWNER`, `BADOP`), sticky first-error registers.
* **DMA coordination.** SFB2 single-beat DMA port (verified against the real **CloudDMA**), per-bank round-robin / fixed-priority arbitration, and **region ownership** with a quiesced hand-over protocol.
* **Optional strided / gather / scatter** (`GS_EN`), built only after the contiguous path was verified; overlapping scatter lanes are deterministic (highest lane wins).
* **Performance counters**: useful bytes, bank conflicts (intra-request and inter-port), alignment overhead, read / write latency, DMA stalls, lane starvation, bank utilisation.

## Results at a glance (all regenerated from `reports/`)

| check | result | source |
|---|---|---|
| Verilator regression: configuration matrix of `tb_vspm` | **50/50 cases PASS**, 7,498,876 self-checks | `regress.json` (Verilator 5.020 2024-01-01 rev (Debian 5.020-1)) |
| Icarus cross-simulation of the same matrix | **49/49 cases PASS** (1 skipped: BACKEND=2), 7,516,382 self-checks | `regress_icarus.json` (Icarus Verilog version 12.0 (stable) ()) |
| unit tests: bank map, split/merge (exhaustive masks), package | **6/6 shapes PASS**, 53,675,504 checks | `units.json` |
| integration: real CloudDMA, lane-masked beats (FP32 / 64-bit) | **6/6 PASS**, 32,984 checks | `integration.json` |
| mutation testing of the testbench | **55/55 injected bugs killed** (0 survived, 0 invalid) | `mutation.json`, `mutation.md` |
| bandwidth sweep | 613 measured rows, 26 configurations; **243/243** deterministic workloads equal the independent analytical model | `bench.csv`, `bench.json` |
| synthesis (Yosys generic gates) | 27/27 configurations / blocks synthesize, 0 latches | `synthesis.md` |
| FPGA block-RAM inference (`synth_xilinx xc7`) | 9/9 configurations | `synthesis.md` |
| SKY130 macro tiling (structural) | 6/6 macro counts equal the tiling formula | `synthesis.md` |

Not run / not available: Vivado, Quartus, OpenROAD, Liberty-based synthesis, SymbiYosys (no formal proof of this design), gate-level simulation, FPGA hardware.

Headline measurements (RTL simulation, `reports/BANDWIDTH_REPORT.md`; 32-bit banks, LOW map):

| | 128-bit vector | 256-bit vector |
|---|---|---|
| aligned stream, enough banks | 15.98 of 16 B/cycle (4 or 8 banks) | 31.95 of 32 B/cycle (8 or 16 banks) |
| byte-misaligned stream | 7.99 B/cycle with 4 banks (**half rate**: the 5th word collides with the 1st), 15.98 with 8 banks | 15.99 with 8 banks (half), 31.95 with 16 banks |
| latency (isolated, distinct banks) | 3 cycles load and store at `READ_LATENCY = 1` (= `READ_LATENCY + 2`) | same |
| worst case, BLOCK map | 4 B/cycle (one bank) | 4 B/cycle |

Two results worth knowing: the **XOR bank map is worse than LOW for word-misaligned streams** (half rate), and a **saturating DMA with fixed priority starves the other port completely**; round robin gives each port half. Both are measured, not assumed.

## Deliverables (brief section 13)

| required | where |
|---|---|
| `sf_vector_scratchpad.sv` | `rtl/sf_vector_scratchpad.sv` |
| vector memory request package | `rtl/sf_vmem_pkg.sv` (+ `rtl/sf_vspm_defs.svh`, the synthesizable-side constants) |
| alignment / split-merge logic | `rtl/sf_vspm_split.sv`, `rtl/sf_vspm_merge.sv`, `rtl/sf_vspm_agu.sv`; docs/04 |
| bank access scheduler | `rtl/sf_vspm_bank_sched.sv` (per-bank arbitration), slot scheduling in `rtl/sf_vspm_port.sv`; `rtl/sf_vspm_bankmap.sv` |
| performance counters | `rtl/sf_vspm_perf.sv`; docs/03 |
| tests | `tb/` (`tb_vspm`, `tb_units`, `tb_clouddma_int`, `tb_lane_glue`, `tb_bench`), `sim/`, `tools/mutate.py`; docs/07 |
| bandwidth report | `reports/BANDWIDTH_REPORT.md` (+ `reports/figs/*.svg`, `reports/bench.csv`) |
| synthesis results | `reports/synthesis.md` (+ `.json`) |
| audit of the repository | `docs/00_repository_audit.md` |

## Layout

| path | content |
|---|---|
| `rtl/` | the design: `sf_vector_scratchpad` (top), `sf_vspm_port`, `_agu`, `_bankmap`, `_split`, `_merge`, `_bank_sched`, `_banks`, `_own`, `_perf`, package, defs header |
| `third_party/memorycore/` | **reused unmodified** `sf_sram_core`, `sf_sram_macro_wrapper`, backends, `sf_sram_defs.svh`, SKY130 stand-in (SHA-256 + provenance) |
| `third_party/clouddma/` | **reused unmodified** `sfd_clouddma` + its package (integration test only) |
| `tb/`, `sim/` | testbenches, file lists, runners (`run_regress.py`, `run_units.py`, `run_integration.py`, `run_bench.py`, `run_all.sh`) |
| `tools/` | `mutate.py`, `make_report.py`, `package.sh` |
| `syn/` | Yosys synthesis runner, SKY130 pin-only black box |
| `docs/` | 00 audit, 01 architecture, 02 interface and contract, 03 microarchitecture, 04 alignment, 05 memory mapping, 06 gather / DMA / ownership, 07 verification, 08 integration, `KNOWN_LIMITATIONS.md` |
| `reports/` | JSON / CSV / Markdown / SVG of every run described above |

## Quick start

```bash
make regress            # configuration matrix of the full testbench (Verilator)
make icarus units integ # cross-simulation, leaf blocks, real CloudDMA + lane-mask glue
make mutate             # mutation testing of the testbench
make bench synth report # bandwidth sweep, synthesis, generated reports
make lint               # Verilator -Wall on the RTL
```

Needs Verilator 5.x, Icarus Verilog 12, Yosys 0.33, Python 3 (the Yosys-only RTL subset is documented in `docs/KNOWN_LIMITATIONS.md`, item 18). Build products go to `build/` (safe to delete by hand).

## Instantiating

```systemverilog
sf_vector_scratchpad #(.VEC_BYTES(16), .BANK_BYTES(4), .NB(4), .DEPTH(256), .ALIGN_POLICY(2) /* split / merge */) u_spm (...);
```
`VEC_BYTES = 4 * NUM_LANES` of the `hpc_vector_array`; lane l is at `[32l +: 32]`; `v_req_mask = sf_vmem_pkg::lane_to_byte_mask(res_mask, 4)`. Port list: docs/02. For the best aligned and byte-misaligned bandwidth use `NB >= VEC_BYTES / BANK_BYTES + 1` banks (docs/05).

## Definition of done

*"The vector engine can correctly perform supported wide memory operations with measured stall and alignment behaviour, preserving all unmodified bytes."*

| part | status |
|---|---|
| wide loads / stores, 128 and 256 bit (512 as the parameterised path) | done, verified against the independent byte model, every array byte compared directly after each phase |
| unmodified bytes preserved (masks, tails, split stores, errors) | done; whole-array backdoor compare in every phase; mutation-tested |
| measured stall behaviour | done: conflict / arbitration / back-pressure / starvation counters, exact analytical model agreement on 243 workloads |
| measured alignment behaviour | done: split overhead per request, half-rate cases, policy A vs B |
| DMA coordination | done against the real CloudDMA; ownership + arbitration; starvation cases measured |
| gather / scatter | done (optional), overlap semantics defined and tested |
| **not done** | wide-port LSU / tile integration, ECC, formal proof, timing / area / power, FPGA place-and-route (docs/08, `KNOWN_LIMITATIONS.md`) |

## Provenance

Reused code is byte-identical to the SilicaFlux archives (`third_party/*/PROVENANCE.md`, `SHA256SUMS`). `MANIFEST.sha256` lists every file of this package.
