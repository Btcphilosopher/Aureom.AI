// =============================================================================
// SilicaFlux VectorScratch :: sf_vspm_banks
// NB single-port banks of DEPTH rows x BB bytes, each one an sf_sram_macro_wrapper (verified MemoryCore module):
// behavioural array (BACKEND 0), FPGA block-RAM template (1) or SKY130 macro tiling (2), all with the same contract:
// one access per clock edge (en/we/addr/wdata/be); the result (valid, tag, rdata) appears READ_LATENCY cycles after the
// accepting edge, for loads AND stores (a store result is the commit acknowledgement).  The arrays are never reset.
// BB (bank word) is the SRAM data width: 32 bits by default, which tiles exactly onto 32-bit macros / 36-bit block RAM
// and is independent of the vector width (VEC_BYTES / BB banks are used in parallel), see docs/05_memory_mapping.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"
`default_nettype none

module sf_vspm_banks #(
  parameter int NB            = 4,
  parameter int DEPTH         = 256,
  parameter int BB            = 4,
  parameter int READ_LATENCY  = 1,
  parameter int BACKEND       = `SF_BACKEND_BEHAV,
  parameter int SIM_INIT      = 2,
  parameter int TWB           = 8,
  parameter int RW            = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic [NB-1:0]       b_en,
  input  wire logic [NB-1:0]       b_we,
  input  wire logic [NB*RW-1:0]    b_row,
  input  wire logic [NB*BB*8-1:0]  b_wd,
  input  wire logic [NB*BB-1:0]    b_be,
  input  wire logic [NB*TWB-1:0]   b_tag,
  output logic [NB-1:0]            r_valid,
  output logic [NB*TWB-1:0]        r_tag,
  output logic [NB*BB*8-1:0]       r_data
);
  localparam int FBW = $clog2(BB * 8);
  genvar b;
  generate
    for (b = 0; b < NB; b++) begin : g_bank
      logic rwe_unused;
      sf_sram_macro_wrapper #(.BACKEND(BACKEND), .DEPTH(DEPTH), .DATA_W(BB*8), .BE_W(BB), .READ_LATENCY(READ_LATENCY),
                              .RDW(`SF_RDW_READ_FIRST), .SIM_INIT(SIM_INIT), .TAG_W(TWB), .FAULT_INJECT(0)) u_wrap (
        .clk(clk), .rst_n(rst_n), .en(b_en[b]), .we(b_we[b]), .addr(b_row[b*RW +: RW]),
        .wdata(b_wd[b*BB*8 +: BB*8]), .be(b_be[b*BB +: BB]), .tag_i(b_tag[b*TWB +: TWB]),
        .rvalid(r_valid[b]), .rwe(rwe_unused), .rtag(r_tag[b*TWB +: TWB]), .rdata(r_data[b*BB*8 +: BB*8]),
        .fi_type(4'd0), .fi_row({RW{1'b0}}), .fi_row2({RW{1'b0}}), .fi_bit({FBW{1'b0}}), .fi_bit2({FBW{1'b0}}),
        .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row({RW{1'b0}}), .seu_mask({(BB*8){1'b0}}));
    end
  endgenerate
endmodule

`default_nettype wire
