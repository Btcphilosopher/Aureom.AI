// =============================================================================
// SilicaFlux VectorScratch :: sf_vspm_split   (STORE side of the alignment logic)
// Places the VEC_BYTES vector bytes (and their byte-enable mask) into a word-aligned WINDOW of NW bank words:
//   window byte (off + j) <- vector byte j,  window mask bit (off + j) <- mask bit j,   off = addr mod BANK_BYTES.
// Window word k is the word at index w0 + k, so a vector that starts `off` bytes into a word touches at most
// ceil((off + VEC_BYTES) / BANK_BYTES) words: the vector is SPLIT across adjacent words (and, through the bank map,
// across adjacent banks).  A window byte whose mask bit is 0 never reaches an array: the bank write-enable of that byte
// lane is 0, which is what preserves every unmodified byte.  With NW*BB == VEC_BYTES (policies VEC / WORD) off is 0 and
// this block is wires.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_vspm_split #(
  parameter int VEC_BYTES = 16,
  parameter int BB        = 4,
  parameter int NW        = 5,
  parameter int OFFW      = (BB > 1) ? $clog2(BB) : 1
) (
  input  wire logic [VEC_BYTES*8-1:0] wdata,
  input  wire logic [VEC_BYTES-1:0]   mask,
  input  wire logic [OFFW-1:0]        off,
  output logic [NW*BB*8-1:0]          wwd,
  output logic [NW*BB-1:0]            wmask
);
  localparam int WB = NW * BB;
  logic [WB*8-1:0] d_ext;
  logic [WB-1:0]   m_ext;
  always_comb begin
    d_ext = '0;
    m_ext = '0;
    d_ext[VEC_BYTES*8-1:0] = wdata;
    m_ext[VEC_BYTES-1:0]   = mask;
    wwd   = d_ext << {off, 3'b000};
    wmask = m_ext << off;
  end
endmodule

`default_nettype wire
