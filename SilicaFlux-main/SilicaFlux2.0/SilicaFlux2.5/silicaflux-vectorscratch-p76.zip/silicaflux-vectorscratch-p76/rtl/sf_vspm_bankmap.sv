// =============================================================================
// SilicaFlux VectorScratch :: sf_vspm_bankmap
// Word index -> (bank, row).  Purely combinational; one instance per word slot of an access.  The three maps of
// BANK_MAP (sf_vspm_defs.svh) are all BIJECTIVE over [0, NB*DEPTH): every (bank,row) holds exactly one word.
//   LOW   bank = w mod NB          row = w / NB         consecutive words rotate through the banks
//   XOR   bank = (w mod NB) ^ ((w / NB) mod NB)  row = w / NB   same row, banks permuted per row: a stride of NB words,
//                                                      which hits ONE bank under LOW, spreads over all banks under XOR
//   BLOCK bank = w / DEPTH         row = w mod DEPTH    banks are contiguous regions: a contiguous vector sits in ONE
//                                                      bank (worst case, kept to measure conflicts; also gives each
//                                                      bank a private address region for DMA / vector separation)
// NB and DEPTH are powers of two (checked by the top level).  widx must be < NB*DEPTH (the AGU range-checks first).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"
`default_nettype none

module sf_vspm_bankmap #(
  parameter int NB       = 4,
  parameter int DEPTH    = 256,
  parameter int BANK_MAP = `SF_VM_MAP_LOW,
  parameter int WIW      = 10,                       // >= log2(NB*DEPTH)
  parameter int BW       = (NB > 1) ? $clog2(NB) : 1,
  parameter int RW       = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic [WIW-1:0] widx,
  output logic [BW-1:0]       bank,
  output logic [RW-1:0]       row
);
  localparam int NBW = (NB > 1) ? $clog2(NB) : 0;
  localparam int RWL = (DEPTH > 1) ? $clog2(DEPTH) : 0;
  logic [WIW-1:0] w_hi_nb, w_hi_rw;
  always_comb begin
    w_hi_nb = widx >> NBW;
    w_hi_rw = widx >> RWL;
    bank = '0;
    row  = '0;
    case (BANK_MAP)
      `SF_VM_MAP_XOR: begin
        bank = BW'((widx ^ w_hi_nb) & WIW'(NB - 1));
        row  = RW'(w_hi_nb);
      end
      `SF_VM_MAP_BLOCK: begin
        bank = BW'(w_hi_rw & WIW'(NB - 1));
        row  = RW'(widx & WIW'(DEPTH - 1));
      end
      default: begin                                    // LOW
        bank = BW'(widx & WIW'(NB - 1));
        row  = RW'(w_hi_nb);
      end
    endcase
  end
endmodule

`default_nettype wire
