// =============================================================================
// SilicaFlux VectorScratch :: sf_vspm_bank_sched   (bank access scheduler)
// Per-bank arbitration between the two requester ports and routing onto the bank request buses.
// Each port presents at most ONE candidate per bank per cycle (its lowest pending slot for that bank, see sf_vspm_port).
// A single-port bank accepts at most one access per cycle, so per bank:
//   both ports present a candidate -> ARB_POLICY decides:
//        VEC  vector port wins (DMA waits; can starve under sustained vector traffic: measured, not hidden)
//        DMA  DMA port wins
//        RR   round robin: after a grant to port p the OTHER port wins the next contention for that bank, so a port
//             that keeps requesting waits at most one grant of the other port
//   one port presents a candidate -> it is granted (a bank is never idle while a request for it is waiting).
// A candidate that is not granted is simply presented again next cycle, unchanged (the port holds its issue stage);
// nothing is dropped, duplicated or reordered.  Per-bank events (bank_acc, bank_conf) feed the utilisation counters.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"
`default_nettype none

module sf_vspm_bank_sched #(
  parameter int NB         = 4,
  parameter int RW         = 8,
  parameter int BB         = 4,
  parameter int TW0        = 6,
  parameter int TW1        = 4,
  parameter int ARB_POLICY = `SF_VM_ARB_RR,
  parameter int TWB        = 1 + ((TW0 > TW1) ? TW0 : TW1)
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // port 0 (vector)
  input  wire logic [NB-1:0]         c0_valid,
  input  wire logic                  c0_we,
  input  wire logic [NB*RW-1:0]      c0_row,
  input  wire logic [NB*BB*8-1:0]    c0_wd,
  input  wire logic [NB*BB-1:0]      c0_be,
  input  wire logic [NB*TW0-1:0]     c0_tag,
  output logic [NB-1:0]              g0,
  // port 1 (DMA)
  input  wire logic [NB-1:0]         c1_valid,
  input  wire logic                  c1_we,
  input  wire logic [NB*RW-1:0]      c1_row,
  input  wire logic [NB*BB*8-1:0]    c1_wd,
  input  wire logic [NB*BB-1:0]      c1_be,
  input  wire logic [NB*TW1-1:0]     c1_tag,
  output logic [NB-1:0]              g1,
  // bank request buses
  output logic [NB-1:0]              b_en,
  output logic [NB-1:0]              b_we,
  output logic [NB*RW-1:0]           b_row,
  output logic [NB*BB*8-1:0]         b_wd,
  output logic [NB*BB-1:0]           b_be,
  output logic [NB*TWB-1:0]          b_tag,
  // events
  output logic [NB-1:0]              ev_bank_conf      // both ports wanted this bank in this cycle
);
  logic [NB-1:0] prio;                                    // RR: 1 = DMA port wins the next tie
  always_comb begin
    g0 = '0; g1 = '0; b_en = '0; b_we = '0; b_row = '0; b_wd = '0; b_be = '0; b_tag = '0; ev_bank_conf = '0;
    for (int b = 0; b < NB; b++) begin
      ev_bank_conf[b] = c0_valid[b] & c1_valid[b];
      if (c0_valid[b] && c1_valid[b]) begin
        case (ARB_POLICY)
          `SF_VM_ARB_VEC: begin g0[b] = 1'b1; end
          `SF_VM_ARB_DMA: begin g1[b] = 1'b1; end
          default:        begin if (prio[b]) g1[b] = 1'b1; else g0[b] = 1'b1; end
        endcase
      end else begin
        g0[b] = c0_valid[b];
        g1[b] = c1_valid[b];
      end
      b_en[b] = g0[b] | g1[b];
      if (g1[b]) begin
        b_we[b]                  = c1_we;
        b_row[b*RW +: RW]        = c1_row[b*RW +: RW];
        b_wd[b*BB*8 +: BB*8]     = c1_wd[b*BB*8 +: BB*8];
        b_be[b*BB +: BB]         = c1_be[b*BB +: BB];
        b_tag[b*TWB +: TWB]      = TWB'(c1_tag[b*TW1 +: TW1]);
        b_tag[b*TWB + TWB - 1]   = 1'b1;                   // port bit: DMA
      end else if (g0[b]) begin
        b_we[b]                  = c0_we;
        b_row[b*RW +: RW]        = c0_row[b*RW +: RW];
        b_wd[b*BB*8 +: BB*8]     = c0_wd[b*BB*8 +: BB*8];
        b_be[b*BB +: BB]         = c0_be[b*BB +: BB];
        b_tag[b*TWB +: TWB]      = TWB'(c0_tag[b*TW0 +: TW0]);
      end
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) prio <= '0;
    else for (int b = 0; b < NB; b++) begin
      if (g1[b]) prio[b] <= 1'b0;                          // DMA won: the vector port is next
      else if (g0[b]) prio[b] <= 1'b1;
    end
  end
endmodule

`default_nettype wire
