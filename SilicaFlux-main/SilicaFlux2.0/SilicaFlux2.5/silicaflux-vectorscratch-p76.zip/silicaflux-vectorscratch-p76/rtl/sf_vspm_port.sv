// =============================================================================
// SilicaFlux VectorScratch :: sf_vspm_port
// One requester port of the vector scratchpad: request acceptance, address generation, split, slot scheduling,
// in-order completion queue, merge and response formatting.  The top level instantiates it twice (vector port, DMA port).
//
// ---------------------------------------------------------------- pipeline (docs/03_microarchitecture.md)
//   1 acceptance + 2 address generation   cycle A : req_valid && req_ready.  The AGU (sf_vspm_agu) and the split
//        (sf_vspm_split) run combinationally on the request; the result is registered into the ISSUE STAGE S1 and one
//        entry of the completion queue (CQ) is allocated.  A request with an error status, or with no enabled byte,
//        creates its CQ entry only (need = 0): it never touches S1 or a bank and completes as soon as it is the oldest.
//   3 bank routing                        cycle A+1.. : the issue stage presents, for every bank, the LOWEST pending slot
//        that maps to it (one candidate per bank).  The bank scheduler (sf_vspm_bank_sched) grants at most one access
//        per bank per cycle across both ports.  Slots that were not granted stay pending: that is the SPLIT of a
//        transaction over several cycles when several slots map to one bank.  S1 is released in the cycle its last
//        slot is granted, so the next request enters S1 the same cycle (back-to-back, one request per cycle when the
//        slots hit distinct banks).
//   4 memory access                       the bank (sf_sram_macro_wrapper) returns READ_LATENCY cycles after the grant,
//        echoing the tag {port, CQ entry, slot}; every granted slot (load AND store) returns exactly once.
//   5 alignment (merge)                   completion queue -> window -> sf_vspm_merge (byte shift by `off`, mask zeroing)
//   6 response formatting + 7 completion the oldest CQ entry whose got == need is presented (responses are IN ORDER).
//
// ---------------------------------------------------------------- ordering inside the port
//   * One request occupies S1 at a time, so ALL slots of request i are granted before ANY slot of request i+1: for every
//     bank, accesses happen in request order.  A load accepted after a store therefore reads the stored bytes
//     (RAW/WAR/WAW hold byte-exactly); a store response means the data is in the array.
//   * Inside a request, slots of the same bank are granted lowest slot (= lowest address / lowest lane) first.  For a
//     scatter with duplicate addresses the highest lane is written last: HIGHEST LANE WINS (deterministic).
//   * A request is never partially executed because of an error: all checks are made before any access.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"
`default_nettype none

module sf_vspm_port #(
  parameter int AW           = 32,
  parameter int IDW          = 8,
  parameter int VEC_BYTES    = 16,
  parameter int BB           = 4,
  parameter int NB           = 4,
  parameter int DEPTH        = 256,
  parameter int BANK_MAP     = `SF_VM_MAP_LOW,
  parameter int ALIGN_POLICY = `SF_VM_ALIGN_ANY,
  parameter int GS_EN        = 0,
  parameter int GS_ES        = 4,
  parameter int IDXW         = 32,
  parameter int NRGN         = 4,
  parameter int PORT         = 0,
  parameter int CQ_DEPTH     = 8,
  parameter int LATW         = 16,
  // ---- derived (do not override)
  parameter int VEC_W        = VEC_BYTES * 8,
  parameter int VW           = VEC_BYTES / BB,
  parameter int NW           = VW + ((ALIGN_POLICY == `SF_VM_ALIGN_ANY) ? 1 : 0),
  parameter int BW           = (NB > 1) ? $clog2(NB) : 1,
  parameter int RW           = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int SLW          = (NW > 1) ? $clog2(NW) : 1,
  parameter int CQW          = (CQ_DEPTH > 1) ? $clog2(CQ_DEPTH) : 1,
  parameter int TW           = CQW + SLW,
  parameter int LANES        = (GS_EN != 0) ? VEC_BYTES / GS_ES : 1,
  parameter int OFFW         = (BB > 1) ? $clog2(BB) : 1,
  parameter int BYW          = $clog2(VEC_BYTES + 1),
  parameter int XW           = $clog2(NW + 1)
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------------- request / response
  input  wire logic                   req_valid,
  output logic                        req_ready,
  input  wire logic                   req_we,
  input  wire logic [1:0]             req_mode,
  input  wire logic [AW-1:0]          req_addr,
  input  wire logic [AW-1:0]          req_stride,
  input  wire logic [LANES*IDXW-1:0]  req_idx,
  input  wire logic [VEC_BYTES-1:0]   req_mask,
  input  wire logic [VEC_W-1:0]       req_wdata,
  input  wire logic [IDW-1:0]         req_id,
  output logic                        rsp_valid,
  input  wire logic                   rsp_ready,
  output logic [VEC_W-1:0]            rsp_rdata,
  output logic [IDW-1:0]              rsp_id,
  output logic                        rsp_we,
  output logic [2:0]                  rsp_status,
  // ---------------------------------------------------------------- control
  input  wire logic                   blk_i,            // 1 = do not accept (ownership quiesce)
  output logic                        idle_o,           // no request in flight
  input  wire logic [NRGN*2-1:0]      own_i,
  input  wire logic [LATW-1:0]        cyc_i,
  // ---------------------------------------------------------------- bank scheduler side (one candidate per bank)
  output logic [NB-1:0]               cand_valid,
  output logic                        cand_we,
  output logic [NB*RW-1:0]            cand_row,
  output logic [NB*BB*8-1:0]          cand_wd,
  output logic [NB*BB-1:0]            cand_be,
  output logic [NB*TW-1:0]            cand_tag,
  input  wire logic [NB-1:0]          gnt,
  input  wire logic [NB-1:0]          ret_valid,        // already filtered to this port
  input  wire logic [NB*TW-1:0]       ret_tag,
  input  wire logic [NB*BB*8-1:0]     ret_data,
  // ---------------------------------------------------------------- events (one cycle wide / small counts)
  output logic                        ev_acc,
  output logic                        ev_acc_err,
  output logic [2:0]                  ev_err_code,
  output logic [AW-1:0]               ev_err_addr,
  output logic [BYW-1:0]              ev_bytes,
  output logic [XW-1:0]               ev_xtra,
  output logic [XW-1:0]               ev_words,
  output logic                        ev_stall_conf,
  output logic [NB-1:0]               ev_bank_multi,    // bank b has >= 2 pending slots of the same request
  output logic                        ev_stall_arb,
  output logic                        ev_blocked,
  output logic                        ev_rsp,
  output logic [LATW-1:0]             ev_lat,
  output logic                        ev_rsp_bp,
  output logic                        ev_starve
);
  localparam int WIN_B = NW * BB;
  localparam int WIN_W = WIN_B * 8;
  localparam int CNTW  = $clog2(CQ_DEPTH + 1);

  if (BB < 2 || (BB & (BB - 1)) != 0) begin : g_e_bb
    `SF_CFG_FATAL("sf_vspm_port: BB must be a power of two >= 2")
  end
  if (VEC_BYTES < BB || (VEC_BYTES & (VEC_BYTES - 1)) != 0) begin : g_e_vb
    `SF_CFG_FATAL("sf_vspm_port: VEC_BYTES must be a power of two >= BB")
  end
  if (CQ_DEPTH < 2) begin : g_e_cq
    `SF_CFG_FATAL("sf_vspm_port: CQ_DEPTH must be >= 2")
  end
  if (GS_EN != 0 && (GS_ES < BB || GS_ES > VEC_BYTES || (GS_ES & (GS_ES - 1)) != 0)) begin : g_e_es
    `SF_CFG_FATAL("sf_vspm_port: GS_ES must be a power of two with BB <= GS_ES <= VEC_BYTES")
  end

  // ------------------------------------------------------------ request decode: split + AGU
  wire [OFFW-1:0] off = (ALIGN_POLICY == `SF_VM_ALIGN_ANY && req_mode == `SF_VM_MODE_CONTIG) ? req_addr[OFFW-1:0] : '0;
  logic [WIN_W-1:0] wwd;
  logic [WIN_B-1:0] wmask;
  sf_vspm_split #(.VEC_BYTES(VEC_BYTES), .BB(BB), .NW(NW)) u_split (
    .wdata(req_wdata), .mask(req_mask), .off(off), .wwd(wwd), .wmask(wmask));

  logic [NW-1:0]    need;
  logic [NW*BW-1:0] slot_bank;
  logic [NW*RW-1:0] slot_row;
  logic [2:0]       err;
  sf_vspm_agu #(.AW(AW), .VEC_BYTES(VEC_BYTES), .BB(BB), .NB(NB), .DEPTH(DEPTH), .BANK_MAP(BANK_MAP),
                .ALIGN_POLICY(ALIGN_POLICY), .GS_EN(GS_EN), .GS_ES(GS_ES), .IDXW(IDXW), .NRGN(NRGN), .PORT(PORT)) u_agu (
    .addr(req_addr), .mode(req_mode), .stride(req_stride), .idx(req_idx), .mask(req_mask), .wmask(wmask),
    .own(own_i), .need(need), .slot_bank(slot_bank), .slot_row(slot_row), .err(err));

  wire [NW-1:0] need_eff = (err == `SF_ST_OK) ? need : '0;

  // ------------------------------------------------------------ issue stage S1
  logic              s1_valid, s1_we;
  logic [CQW-1:0]    s1_entry;
  logic [NW-1:0]     s1_need, issued;
  logic [NW*BW-1:0]  s1_bank;
  logic [NW*RW-1:0]  s1_row;
  logic [WIN_W-1:0]  s1_wd;
  logic [WIN_B-1:0]  s1_be;

  logic [NW-1:0]     pend, slot_gnt, slot_cand;
  logic [NB*NW-1:0]  cand_oh;
  logic              s1_free;

  assign pend = s1_need & ~issued & {NW{s1_valid}};

  always_comb begin
    cand_valid = '0;
    cand_oh    = '0;
    cand_row   = '0;
    cand_wd    = '0;
    cand_be    = '0;
    cand_tag   = '0;
    slot_cand  = '0;
    for (int b = 0; b < NB; b++) begin
      for (int k = 0; k < NW; k++) begin
        if (pend[k] && !cand_valid[b] && 32'(s1_bank[k*BW +: BW]) == b) begin
          cand_valid[b]       = 1'b1;
          cand_oh[b*NW + k]   = 1'b1;
          cand_row[b*RW +: RW]    = s1_row[k*RW +: RW];
          cand_wd[b*BB*8 +: BB*8] = s1_wd[k*BB*8 +: BB*8];
          cand_be[b*BB +: BB]     = s1_be[k*BB +: BB];
          cand_tag[b*TW +: TW]    = {s1_entry, SLW'(k)};
          slot_cand[k]            = 1'b1;
        end
      end
    end
  end
  assign cand_we = s1_we;

  always_comb begin
    slot_gnt = '0;
    for (int b = 0; b < NB; b++)
      for (int k = 0; k < NW; k++)
        if (gnt[b] && cand_oh[b*NW + k]) slot_gnt[k] = 1'b1;
  end
  assign s1_free = s1_valid && ((pend & ~slot_gnt) == '0);

  // ------------------------------------------------------------ completion queue
  logic [CQW-1:0]  cq_head, cq_tail;
  logic [CNTW-1:0] cq_cnt;
  logic [CQ_DEPTH-1:0]              cq_we;
  logic [CQ_DEPTH*3-1:0]            cq_st;
  logic [CQ_DEPTH*IDW-1:0]          cq_id;
  logic [CQ_DEPTH*OFFW-1:0]         cq_off;
  logic [CQ_DEPTH*VEC_BYTES-1:0]    cq_mask;
  logic [CQ_DEPTH*LATW-1:0]         cq_t0;
  logic [CQ_DEPTH*NW-1:0]           cq_need, cq_got;
  logic [CQ_DEPTH*WIN_W-1:0]        cq_win;

  wire cq_space = (cq_cnt != CNTW'(CQ_DEPTH));
  assign req_ready = ~blk_i & cq_space & (~s1_valid | s1_free);
  wire acc    = req_valid & req_ready;
  wire acc_s1 = acc & (|need_eff);

  // return decode: slot s of the CQ entry named by the tag of the bank that returned it
  logic [NW-1:0]      wr_s;
  logic [NW*CQW-1:0]  wr_e;
  logic [NW*BB*8-1:0] wr_d;
  always_comb begin
    wr_s = '0;
    wr_e = '0;
    wr_d = '0;
    for (int b = 0; b < NB; b++) begin
      if (ret_valid[b] && 32'(ret_tag[b*TW +: SLW]) < NW) begin
        wr_s[32'(ret_tag[b*TW +: SLW])]                      = 1'b1;
        wr_e[32'(ret_tag[b*TW +: SLW])*CQW +: CQW]           = ret_tag[b*TW + SLW +: CQW];
        wr_d[32'(ret_tag[b*TW +: SLW])*BB*8 +: BB*8]         = ret_data[b*BB*8 +: BB*8];
      end
    end
  end

  // head of the queue
  wire [NW-1:0]    h_need = cq_need[32'(cq_head)*NW +: NW];
  wire [NW-1:0]    h_got  = cq_got[32'(cq_head)*NW +: NW];
  wire             h_done = (cq_cnt != '0) && (h_got == h_need);
  wire             h_we   = cq_we[cq_head];
  wire [2:0]       h_st   = cq_st[32'(cq_head)*3 +: 3];
  wire [OFFW-1:0]  h_off  = cq_off[32'(cq_head)*OFFW +: OFFW];
  wire [VEC_BYTES-1:0] h_mask = cq_mask[32'(cq_head)*VEC_BYTES +: VEC_BYTES];
  wire [WIN_W-1:0] h_win  = cq_win[32'(cq_head)*WIN_W +: WIN_W];
  logic [VEC_W-1:0] merged;
  sf_vspm_merge #(.VEC_BYTES(VEC_BYTES), .BB(BB), .NW(NW)) u_merge (
    .win(h_win), .off(h_off), .mask(h_mask), .rdata(merged));

  assign rsp_valid  = h_done;
  assign rsp_we     = h_we;
  assign rsp_status = h_st;
  assign rsp_id     = cq_id[32'(cq_head)*IDW +: IDW];
  assign rsp_rdata  = (h_we || h_st != `SF_ST_OK) ? '0 : merged;
  wire pop = rsp_valid & rsp_ready;

  assign idle_o = (cq_cnt == '0) && !s1_valid;

  // ------------------------------------------------------------ sequential state
  function automatic logic [CQW-1:0] inc_ptr(input logic [CQW-1:0] p);
    inc_ptr = (32'(p) == CQ_DEPTH - 1) ? '0 : p + 1'b1;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s1_valid <= 1'b0;
      issued   <= '0;
      cq_head  <= '0;
      cq_tail  <= '0;
      cq_cnt   <= '0;
    end else begin
      if (acc_s1) begin
        s1_valid <= 1'b1;
        issued   <= '0;
      end else if (s1_free) begin
        s1_valid <= 1'b0;
        issued   <= '0;
      end else if (s1_valid) begin
        issued   <= issued | slot_gnt;
      end
      if (acc) cq_tail <= inc_ptr(cq_tail);
      if (pop) cq_head <= inc_ptr(cq_head);
      cq_cnt <= cq_cnt + CNTW'(acc) - CNTW'(pop);
    end
  end

  always_ff @(posedge clk) begin
    if (acc_s1) begin
      s1_we    <= req_we;
      s1_entry <= cq_tail;
      s1_need  <= need_eff;
      s1_bank  <= slot_bank;
      s1_row   <= slot_row;
      s1_wd    <= wwd;
      s1_be    <= wmask;
    end
    // completion-queue entries: returns first, then (never the same entry) the allocation
    for (int e = 0; e < CQ_DEPTH; e++) begin
      for (int s = 0; s < NW; s++) begin
        if (wr_s[s] && 32'(wr_e[s*CQW +: CQW]) == e) begin
          cq_got[e*NW + s] <= 1'b1;
          cq_win[(e*NW + s)*BB*8 +: BB*8] <= wr_d[s*BB*8 +: BB*8];
        end
      end
      if (acc && 32'(cq_tail) == e) begin
        cq_we[e]                       <= req_we;
        cq_st[e*3 +: 3]                <= err;
        cq_id[e*IDW +: IDW]            <= req_id;
        cq_off[e*OFFW +: OFFW]         <= off;
        cq_mask[e*VEC_BYTES +: VEC_BYTES] <= req_mask;
        cq_t0[e*LATW +: LATW]          <= cyc_i;
        cq_need[e*NW +: NW]            <= need_eff;
        cq_got[e*NW +: NW]             <= '0;
      end
    end
  end

  // ------------------------------------------------------------ events
  integer nneed, nneed0, nbytes, nwords;
  always_comb begin
    nneed = 0; nneed0 = 0; nbytes = 0; nwords = 0;
    for (int k = 0; k < NW; k++) nneed += 32'(need_eff[k]);
    for (int k = 0; k < VW; k++) nneed0 += 32'(|req_mask[k*BB +: BB]);
    for (int j = 0; j < VEC_BYTES; j++) nbytes += 32'(req_mask[j]);
    for (int k = 0; k < NW; k++) nwords += 32'(slot_gnt[k]);
    ev_acc      = acc;
    ev_acc_err  = acc & (err != `SF_ST_OK);
    ev_err_code = err;
    ev_err_addr = req_addr;
    ev_bytes    = (acc && err == `SF_ST_OK) ? BYW'(nbytes) : '0;
    ev_xtra     = (acc && err == `SF_ST_OK && req_mode == `SF_VM_MODE_CONTIG && nneed > nneed0) ? XW'(nneed - nneed0) : '0;
    ev_words    = XW'(nwords);
  end
  assign ev_stall_conf = |(pend & ~slot_cand);
  integer n_same;
  always_comb begin
    for (int b = 0; b < NB; b++) begin
      n_same = 0;
      for (int k = 0; k < NW; k++) if (pend[k] && 32'(s1_bank[k*BW +: BW]) == b) n_same = n_same + 1;
      ev_bank_multi[b] = (n_same >= 2);
    end
  end
  assign ev_stall_arb  = |(cand_valid & ~gnt);
  assign ev_blocked    = req_valid & ~req_ready;
  assign ev_rsp        = pop;
  assign ev_lat        = cyc_i - cq_t0[32'(cq_head)*LATW +: LATW];
  assign ev_rsp_bp     = rsp_valid & ~rsp_ready;
  assign ev_starve     = rsp_ready & ~rsp_valid & (cq_cnt != '0);

`ifdef SF_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      for (int b = 0; b < NB; b++) begin
        if (ret_valid[b]) begin
          `SF_CHK(32'(ret_tag[b*TW +: SLW]) < NW, "sf_vspm_port: return names a slot beyond the window")
          `SF_CHK(!cq_got[32'(ret_tag[b*TW + SLW +: CQW])*NW + 32'(ret_tag[b*TW +: SLW])], "sf_vspm_port: slot returned twice")
          `SF_CHK(cq_need[32'(ret_tag[b*TW + SLW +: CQW])*NW + 32'(ret_tag[b*TW +: SLW])], "sf_vspm_port: slot returned that was not needed")
        end
      end
      `SF_CHK(!(acc && !cq_space), "sf_vspm_port: accepted into a full completion queue")
    end
  end
`endif
endmodule

`default_nettype wire
