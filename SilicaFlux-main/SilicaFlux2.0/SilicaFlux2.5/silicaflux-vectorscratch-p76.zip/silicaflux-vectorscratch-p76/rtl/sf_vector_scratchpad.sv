// =============================================================================
// SilicaFlux VectorScratch (Project 76) :: sf_vector_scratchpad
// Wide-vector SRAM scratchpad for the SilicaFlux FP32 vector engine: wide loads / stores with per-byte enables, byte
// addressing, misaligned (split / merge) accesses, banking with reported conflicts, back-pressure, DMA coordination,
// optional strided / gather / scatter, performance counters.  Memory holds RAW BITS: no floating-point semantics here.
//
//   vector port   v_req_* / v_rsp_*     VEC_BYTES per request (16 = 128 bit, 32 = 256 bit, 64 = 512 bit, ...)
//   DMA port      d_req_* / d_rsp_*     single-beat, SFB2-style (same shape as hpc_dma_spm_port / sfd_clouddma sm_*):
//                                       DMA_BYTES per beat, beat aligned, byte strobes, in-order responses
//   ownership     own_req_*             region owner SHARED / VEC / DMA, quiesced change (sf_vspm_own)
//
// ---------------------------------------------------------------- memory organisation
//   NB banks x DEPTH rows x BANK_BYTES bytes (default 4 x 256 x 4 B = 4 KiB).  The byte address space [0, CAP_BYTES) is
//   cut into BANK_BYTES-byte words; word w lives in (bank, row) = BANK_MAP(w).  Every bank is a SINGLE-PORT SRAM: one
//   access per bank per cycle.  A vector of VEC_BYTES bytes occupies VEC_BYTES/BANK_BYTES words (one more when it starts
//   inside a word); with LOW mapping and NB >= that many words they sit in distinct banks and are accessed in ONE cycle
//   (full bandwidth).  When several words of an access (or of both ports) target one bank the accesses are serialised by
//   the scheduler, the conflict is counted and the access takes more cycles: the design never reports more bandwidth
//   than the banks can deliver.
//
// ---------------------------------------------------------------- request fields (vector port)
//   v_req_we     0 load, 1 store
//   v_req_mode   0 CONTIG   bytes [addr, addr + VEC_BYTES)                       (the normal case)
//                1 STRIDED  element l (GS_ES bytes) at addr + l * stride         (GS_EN = 1)
//                2 INDEXED  element l at addr + sext(v_req_idx[l])              gather / scatter (GS_EN = 1)
//   v_req_mask   per-byte enable.  Store: a 0 bit never modifies the byte.  Load: a 0 bit returns 0 and the word is not
//                read at all if every one of its bytes is masked off (no bank traffic, no range error)
//   v_req_wdata  VEC_BYTES bytes, byte j in bits [8j +: 8]; for FP32 lane l = bits [32l +: 32] (hpc_vector_array layout)
//   v_req_id     returned with the response (responses come back IN ORDER)
//   Response: v_rsp_rdata (0 for stores, errors and masked bytes), v_rsp_status (SF_ST_*), v_rsp_we.
//   A store response means the data is committed in the array.  An errored request has NO side effect at all.
//
// Full documentation: docs/  (02 interface and contract, 03 microarchitecture, 04 alignment, 05 mapping, 06 ordering ...)
// Classification: SYNTHESIZABLE (BACKEND = 0 / 1; BACKEND = 2 is structural, see docs/05_memory_mapping.md)
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"
`default_nettype none

module sf_vector_scratchpad #(
  parameter int AW           = 32,
  parameter int IDW          = 8,
  parameter int VEC_BYTES    = 16,
  parameter int BANK_BYTES   = 4,
  parameter int NB           = 4,
  parameter int DEPTH        = 256,
  parameter int BANK_MAP     = `SF_VM_MAP_LOW,
  parameter int ALIGN_POLICY = `SF_VM_ALIGN_ANY,
  parameter int GS_EN        = 0,
  parameter int GS_ES        = 4,
  parameter int IDXW         = 32,
  parameter int READ_LATENCY = 1,
  parameter int BACKEND      = `SF_BACKEND_BEHAV,
  parameter int SIM_INIT     = 2,
  parameter int CQ_DEPTH     = 8,
  parameter int DMA_EN       = 1,
  parameter int DMA_BYTES    = 16,
  parameter int DMA_CQ_DEPTH = 4,
  parameter int ARB_POLICY   = `SF_VM_ARB_RR,
  parameter int NRGN         = 4,
  parameter int OWN_RESET    = 1,                 // 0 SHARED, 1 VEC, 2 DMA (SF_VM_OWN_*)
  parameter int PERF_EN      = 1,
  parameter int CNT_W        = 32,
  parameter int LATW         = 16,
  // ---- derived (do not override)
  parameter int VEC_W        = VEC_BYTES * 8,
  parameter int DMA_W        = DMA_BYTES * 8,
  parameter int LANES        = (GS_EN != 0) ? VEC_BYTES / GS_ES : 1,
  parameter int RGW          = (NRGN > 1) ? $clog2(NRGN) : 1
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // ---------------------------------------------------------------- vector port
  input  wire logic                    v_req_valid,
  output logic                         v_req_ready,
  input  wire logic                    v_req_we,
  input  wire logic [1:0]              v_req_mode,
  input  wire logic [AW-1:0]           v_req_addr,
  input  wire logic [AW-1:0]           v_req_stride,
  input  wire logic [LANES*IDXW-1:0]   v_req_idx,
  input  wire logic [VEC_BYTES-1:0]    v_req_mask,
  input  wire logic [VEC_W-1:0]        v_req_wdata,
  input  wire logic [IDW-1:0]          v_req_id,
  output logic                         v_rsp_valid,
  input  wire logic                    v_rsp_ready,
  output logic [VEC_W-1:0]             v_rsp_rdata,
  output logic [IDW-1:0]               v_rsp_id,
  output logic                         v_rsp_we,
  output logic [2:0]                   v_rsp_status,
  // ---------------------------------------------------------------- DMA port (SFB2-style single beat)
  input  wire logic                    d_req_valid,
  output logic                         d_req_ready,
  input  wire logic                    d_req_write,
  input  wire logic [AW-1:0]           d_req_addr,
  input  wire logic [DMA_W-1:0]        d_req_wdata,
  input  wire logic [DMA_BYTES-1:0]    d_req_wstrb,
  output logic                         d_rsp_valid,
  input  wire logic                    d_rsp_ready,
  output logic [DMA_W-1:0]             d_rsp_rdata,
  output logic                         d_rsp_error,
  output logic [2:0]                   d_rsp_err_code,
  // ---------------------------------------------------------------- ownership
  input  wire logic                    own_req_valid,
  output logic                         own_req_ready,
  input  wire logic [RGW-1:0]          own_req_rgn,
  input  wire logic [1:0]              own_req_val,
  output logic                         own_ack_o,
  output logic                         own_err_o,
  output logic [NRGN*2-1:0]            own_state_o,
  // ---------------------------------------------------------------- status / error reporting
  input  wire logic                    err_clear_i,
  output logic                         busy_o,
  output logic                         err_sticky_o,     // an error response was produced since the last clear
  output logic [2:0]                   err_code_o,       // status of the FIRST error
  output logic [AW-1:0]                err_addr_o,       // request address of the first error
  output logic                         err_port_o,       // 0 vector, 1 DMA
  output logic [CNT_W-1:0]             err_cnt_o,        // number of error responses since the last clear
  // ---------------------------------------------------------------- performance
  input  wire logic                    perf_clear_i,
  output logic [`SF_PC_N*CNT_W-1:0]    perf_o,
  output logic [NB*CNT_W-1:0]          perf_bank_acc_o,
  output logic [NB*CNT_W-1:0]          perf_bank_conf_o,
  // tile-level counter hooks (hpc_perf_counters SPM_READS / SPM_WRITES / SPM_CONFLICTS definitions)
  output logic [1:0]                   ev_spm_read_o,
  output logic [1:0]                   ev_spm_write_o,
  output logic [1:0]                   ev_spm_conflict_o
);
  // ------------------------------------------------------------ configuration checks
  localparam int CAP_BYTES = NB * DEPTH * BANK_BYTES;
  if (NB < 1 || (NB & (NB - 1)) != 0)       begin : g_e_nb  `SF_CFG_FATAL("sf_vector_scratchpad: NB must be a power of two") end
  if (DEPTH < 2 || (DEPTH & (DEPTH - 1)) != 0) begin : g_e_dp `SF_CFG_FATAL("sf_vector_scratchpad: DEPTH must be a power of two >= 2") end
  if (BANK_BYTES < 2 || (BANK_BYTES & (BANK_BYTES - 1)) != 0) begin : g_e_bb `SF_CFG_FATAL("sf_vector_scratchpad: BANK_BYTES must be a power of two >= 2") end
  if (VEC_BYTES < BANK_BYTES || (VEC_BYTES & (VEC_BYTES - 1)) != 0) begin : g_e_vb `SF_CFG_FATAL("sf_vector_scratchpad: VEC_BYTES must be a power of two >= BANK_BYTES") end
  if (NRGN < 1 || (NRGN & (NRGN - 1)) != 0 || NRGN > NB * DEPTH) begin : g_e_rg `SF_CFG_FATAL("sf_vector_scratchpad: NRGN must be a power of two <= NB*DEPTH") end
  if (DMA_EN != 0 && (DMA_BYTES < BANK_BYTES || (DMA_BYTES & (DMA_BYTES - 1)) != 0)) begin : g_e_db `SF_CFG_FATAL("sf_vector_scratchpad: DMA_BYTES must be a power of two >= BANK_BYTES") end
  if (AW < 16 || (AW < 32 && CAP_BYTES > (1 << AW))) begin : g_e_aw `SF_CFG_FATAL("sf_vector_scratchpad: AW too small for the aperture") end
  if (BANK_MAP < 0 || BANK_MAP > 2) begin : g_e_mp `SF_CFG_FATAL("sf_vector_scratchpad: BANK_MAP must be 0, 1 or 2") end
  if (ALIGN_POLICY < 0 || ALIGN_POLICY > 2) begin : g_e_ap `SF_CFG_FATAL("sf_vector_scratchpad: ALIGN_POLICY must be 0, 1 or 2") end
  if (GS_EN != 0 && GS_ES < BANK_BYTES) begin : g_e_gs `SF_CFG_FATAL("sf_vector_scratchpad: strided / indexed elements must be at least one bank word (GS_ES >= BANK_BYTES)") end

  localparam int RW   = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int VW0  = VEC_BYTES / BANK_BYTES;
  localparam int NW0  = VW0 + ((ALIGN_POLICY == `SF_VM_ALIGN_ANY) ? 1 : 0);
  localparam int NW1  = DMA_BYTES / BANK_BYTES;
  localparam int SLW0 = (NW0 > 1) ? $clog2(NW0) : 1;
  localparam int SLW1 = (NW1 > 1) ? $clog2(NW1) : 1;
  localparam int CQW0 = (CQ_DEPTH > 1) ? $clog2(CQ_DEPTH) : 1;
  localparam int CQW1 = (DMA_CQ_DEPTH > 1) ? $clog2(DMA_CQ_DEPTH) : 1;
  localparam int TW0  = CQW0 + SLW0;
  localparam int TW1  = CQW1 + SLW1;
  localparam int TWB  = 1 + ((TW0 > TW1) ? TW0 : TW1);
  localparam int BYW0 = $clog2(VEC_BYTES + 1);
  localparam int BYW1 = $clog2(DMA_BYTES + 1);
  localparam int XW0  = $clog2(NW0 + 1);
  localparam int XW1  = $clog2(NW1 + 1);
  localparam int ADDW = LATW;

  // ------------------------------------------------------------ free-running cycle stamp (latency measurement)
  logic [LATW-1:0] cyc;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) cyc <= '0;
    else        cyc <= cyc + 1'b1;
  end

  // ------------------------------------------------------------ ownership
  logic            v_idle, d_idle, blk;
  logic [NRGN*2-1:0] own;
  sf_vspm_own #(.NRGN(NRGN), .OWN_RESET(OWN_RESET)) u_own (
    .clk(clk), .rst_n(rst_n), .req_valid(own_req_valid), .req_ready(own_req_ready), .req_rgn(own_req_rgn),
    .req_val(own_req_val), .idle_i(v_idle & d_idle), .blk_o(blk), .ack_o(own_ack_o), .err_o(own_err_o), .own_o(own));
  assign own_state_o = own;
  assign busy_o      = ~(v_idle & d_idle);

  // Some event / status signals are unused in particular configurations (DMA_EN = 0, PERF_EN = 0): intentional.
  /* verilator lint_off UNUSEDSIGNAL */
  // ------------------------------------------------------------ bank-side buses (declared first: used by both ports)
  logic [NB-1:0]              b_en, b_we, bank_conf_ev;
  logic [NB*RW-1:0]           b_row;
  logic [NB*BANK_BYTES*8-1:0] b_wd, r_data;
  logic [NB*BANK_BYTES-1:0]   b_be;
  logic [NB*TWB-1:0]          b_tag, r_tag;
  logic [NB-1:0]              r_valid;

  // ------------------------------------------------------------ vector port
  logic [NB-1:0]       c0_valid, g0, v_bank_multi;
  logic                c0_we;
  logic [NB*RW-1:0]    c0_row;
  logic [NB*BANK_BYTES*8-1:0] c0_wd;
  logic [NB*BANK_BYTES-1:0]   c0_be;
  logic [NB*TW0-1:0]   c0_tag;
  logic [NB-1:0]       r0_valid;
  logic [NB*TW0-1:0]   r0_tag;
  logic                v_ev_acc, v_ev_acc_err, v_ev_stall_conf, v_ev_stall_arb, v_ev_blocked, v_ev_rsp, v_ev_rsp_bp, v_ev_starve;
  logic [2:0]          v_ev_err_code;
  logic [AW-1:0]       v_ev_err_addr;
  logic [BYW0-1:0]     v_ev_bytes;
  logic [XW0-1:0]      v_ev_xtra, v_ev_words;
  logic [LATW-1:0]     v_ev_lat;

  sf_vspm_port #(.AW(AW), .IDW(IDW), .VEC_BYTES(VEC_BYTES), .BB(BANK_BYTES), .NB(NB), .DEPTH(DEPTH), .BANK_MAP(BANK_MAP),
                 .ALIGN_POLICY(ALIGN_POLICY), .GS_EN(GS_EN), .GS_ES(GS_ES), .IDXW(IDXW), .NRGN(NRGN), .PORT(0),
                 .CQ_DEPTH(CQ_DEPTH), .LATW(LATW)) u_vport (
    .clk(clk), .rst_n(rst_n),
    .req_valid(v_req_valid), .req_ready(v_req_ready), .req_we(v_req_we), .req_mode(v_req_mode), .req_addr(v_req_addr),
    .req_stride(v_req_stride), .req_idx(v_req_idx), .req_mask(v_req_mask), .req_wdata(v_req_wdata), .req_id(v_req_id),
    .rsp_valid(v_rsp_valid), .rsp_ready(v_rsp_ready), .rsp_rdata(v_rsp_rdata), .rsp_id(v_rsp_id), .rsp_we(v_rsp_we),
    .rsp_status(v_rsp_status),
    .blk_i(blk), .idle_o(v_idle), .own_i(own), .cyc_i(cyc),
    .cand_valid(c0_valid), .cand_we(c0_we), .cand_row(c0_row), .cand_wd(c0_wd), .cand_be(c0_be), .cand_tag(c0_tag),
    .gnt(g0), .ret_valid(r0_valid), .ret_tag(r0_tag), .ret_data(r_data),
    .ev_acc(v_ev_acc), .ev_acc_err(v_ev_acc_err), .ev_err_code(v_ev_err_code), .ev_err_addr(v_ev_err_addr),
    .ev_bytes(v_ev_bytes), .ev_xtra(v_ev_xtra), .ev_words(v_ev_words), .ev_stall_conf(v_ev_stall_conf),
    .ev_bank_multi(v_bank_multi), .ev_stall_arb(v_ev_stall_arb), .ev_blocked(v_ev_blocked), .ev_rsp(v_ev_rsp),
    .ev_lat(v_ev_lat), .ev_rsp_bp(v_ev_rsp_bp), .ev_starve(v_ev_starve));

  // ------------------------------------------------------------ DMA port
  logic [NB-1:0]       c1_valid, g1, d_bank_multi;
  logic                c1_we;
  logic [NB*RW-1:0]    c1_row;
  logic [NB*BANK_BYTES*8-1:0] c1_wd;
  logic [NB*BANK_BYTES-1:0]   c1_be;
  logic [NB*TW1-1:0]   c1_tag;
  logic [NB-1:0]       r1_valid;
  logic [NB*TW1-1:0]   r1_tag;
  logic                d_ev_acc, d_ev_acc_err, d_ev_stall_conf, d_ev_stall_arb, d_ev_blocked, d_ev_rsp, d_ev_rsp_bp, d_ev_starve;
  logic [2:0]          d_ev_err_code;
  logic [AW-1:0]       d_ev_err_addr;
  logic [BYW1-1:0]     d_ev_bytes;
  logic [XW1-1:0]      d_ev_xtra, d_ev_words;
  logic [LATW-1:0]     d_ev_lat;
  logic                d_rsp_we_w;
  logic                d_rsp_id_unused;
  logic [2:0]          d_rsp_status_w;

  generate
    if (DMA_EN != 0) begin : g_dma
      sf_vspm_port #(.AW(AW), .IDW(1), .VEC_BYTES(DMA_BYTES), .BB(BANK_BYTES), .NB(NB), .DEPTH(DEPTH), .BANK_MAP(BANK_MAP),
                     .ALIGN_POLICY(`SF_VM_ALIGN_VEC), .GS_EN(0), .GS_ES(BANK_BYTES), .IDXW(IDXW), .NRGN(NRGN), .PORT(1),
                     .CQ_DEPTH(DMA_CQ_DEPTH), .LATW(LATW)) u_dport (
        .clk(clk), .rst_n(rst_n),
        .req_valid(d_req_valid), .req_ready(d_req_ready), .req_we(d_req_write), .req_mode(`SF_VM_MODE_CONTIG),
        .req_addr(d_req_addr), .req_stride({AW{1'b0}}), .req_idx({IDXW{1'b0}}),
        .req_mask(d_req_write ? d_req_wstrb : {DMA_BYTES{1'b1}}), .req_wdata(d_req_wdata), .req_id(1'b0),
        .rsp_valid(d_rsp_valid), .rsp_ready(d_rsp_ready), .rsp_rdata(d_rsp_rdata), .rsp_id(d_rsp_id_unused), .rsp_we(d_rsp_we_w),
        .rsp_status(d_rsp_status_w),
        .blk_i(blk), .idle_o(d_idle), .own_i(own), .cyc_i(cyc),
        .cand_valid(c1_valid), .cand_we(c1_we), .cand_row(c1_row), .cand_wd(c1_wd), .cand_be(c1_be), .cand_tag(c1_tag),
        .gnt(g1), .ret_valid(r1_valid), .ret_tag(r1_tag), .ret_data(r_data),
        .ev_acc(d_ev_acc), .ev_acc_err(d_ev_acc_err), .ev_err_code(d_ev_err_code), .ev_err_addr(d_ev_err_addr),
        .ev_bytes(d_ev_bytes), .ev_xtra(d_ev_xtra), .ev_words(d_ev_words), .ev_stall_conf(d_ev_stall_conf),
        .ev_bank_multi(d_bank_multi), .ev_stall_arb(d_ev_stall_arb), .ev_blocked(d_ev_blocked), .ev_rsp(d_ev_rsp),
        .ev_lat(d_ev_lat), .ev_rsp_bp(d_ev_rsp_bp), .ev_starve(d_ev_starve));
      assign d_rsp_error    = (d_rsp_status_w != `SF_ST_OK);
      assign d_rsp_err_code = d_rsp_status_w;
    end else begin : g_nodma
      assign d_req_ready = 1'b0;  assign d_rsp_valid = 1'b0;  assign d_rsp_rdata = '0;  assign d_rsp_error = 1'b0;
      assign d_rsp_err_code = '0; assign d_rsp_we_w = 1'b0;   assign d_rsp_status_w = '0; assign d_idle = 1'b1;
      assign c1_valid = '0; assign c1_we = 1'b0; assign c1_row = '0; assign c1_wd = '0; assign c1_be = '0; assign c1_tag = '0;
      assign d_ev_acc = 1'b0; assign d_ev_acc_err = 1'b0; assign d_ev_err_code = '0; assign d_ev_err_addr = '0;
      assign d_ev_bytes = '0; assign d_ev_xtra = '0; assign d_ev_words = '0; assign d_ev_stall_conf = 1'b0;
      assign d_bank_multi = '0; assign d_ev_stall_arb = 1'b0; assign d_ev_blocked = 1'b0; assign d_ev_rsp = 1'b0;
      assign d_ev_lat = '0; assign d_ev_rsp_bp = 1'b0; assign d_ev_starve = 1'b0;
      wire unused_dma = &{1'b0, d_req_valid, d_req_write, d_req_addr, d_req_wdata, d_req_wstrb, d_rsp_ready, g1, r1_valid, r1_tag};
    end
  endgenerate

  // ------------------------------------------------------------ bank scheduler + banks
  sf_vspm_bank_sched #(.NB(NB), .RW(RW), .BB(BANK_BYTES), .TW0(TW0), .TW1(TW1), .ARB_POLICY(ARB_POLICY)) u_sched (
    .clk(clk), .rst_n(rst_n),
    .c0_valid(c0_valid), .c0_we(c0_we), .c0_row(c0_row), .c0_wd(c0_wd), .c0_be(c0_be), .c0_tag(c0_tag), .g0(g0),
    .c1_valid(c1_valid), .c1_we(c1_we), .c1_row(c1_row), .c1_wd(c1_wd), .c1_be(c1_be), .c1_tag(c1_tag), .g1(g1),
    .b_en(b_en), .b_we(b_we), .b_row(b_row), .b_wd(b_wd), .b_be(b_be), .b_tag(b_tag), .ev_bank_conf(bank_conf_ev));

  sf_vspm_banks #(.NB(NB), .DEPTH(DEPTH), .BB(BANK_BYTES), .READ_LATENCY(READ_LATENCY), .BACKEND(BACKEND),
                  .SIM_INIT(SIM_INIT), .TWB(TWB)) u_banks (
    .clk(clk), .rst_n(rst_n), .b_en(b_en), .b_we(b_we), .b_row(b_row), .b_wd(b_wd), .b_be(b_be), .b_tag(b_tag),
    .r_valid(r_valid), .r_tag(r_tag), .r_data(r_data));

  // return routing by the port bit (MSB of the bank tag)
  always_comb begin
    r0_valid = '0; r1_valid = '0; r0_tag = '0; r1_tag = '0;
    for (int b = 0; b < NB; b++) begin
      r0_valid[b] = r_valid[b] & ~r_tag[b*TWB + TWB - 1];
      r1_valid[b] = r_valid[b] &  r_tag[b*TWB + TWB - 1];
      r0_tag[b*TW0 +: TW0] = r_tag[b*TWB +: TW0];
      r1_tag[b*TW1 +: TW1] = r_tag[b*TWB +: TW1];
    end
  end

  // ------------------------------------------------------------ error reporting
  logic              e_any;
  logic              e_port;
  logic [2:0]        e_code;
  logic [AW-1:0]     e_addr;
  logic [1:0]        e_n;
  always_comb begin
    e_any  = v_ev_acc_err | d_ev_acc_err;
    e_port = ~v_ev_acc_err;
    e_code = v_ev_acc_err ? v_ev_err_code : d_ev_err_code;
    e_addr = v_ev_acc_err ? v_ev_err_addr : d_ev_err_addr;
    e_n    = add2(v_ev_acc_err, d_ev_acc_err);
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      err_sticky_o <= 1'b0; err_code_o <= '0; err_addr_o <= '0; err_port_o <= 1'b0; err_cnt_o <= '0;
    end else if (err_clear_i) begin
      err_sticky_o <= 1'b0; err_code_o <= '0; err_addr_o <= '0; err_port_o <= 1'b0; err_cnt_o <= '0;
    end else if (e_any) begin
      if (!err_sticky_o) begin
        err_sticky_o <= 1'b1; err_code_o <= e_code; err_addr_o <= e_addr; err_port_o <= e_port;
      end
      if (err_cnt_o <= ~CNT_W'(2)) err_cnt_o <= err_cnt_o + CNT_W'(e_n);
      else err_cnt_o <= '1;
    end
  end

  // ------------------------------------------------------------ 1-bit event helpers (explicit widths, no cast-of-expression)
  wire v_ld  = v_ev_acc & ~v_req_we;
  wire v_st  = v_ev_acc &  v_req_we;
  wire d_rd  = d_ev_acc & ~d_req_write;
  wire d_wr  = d_ev_acc &  d_req_write;
  wire v_rrd = v_ev_rsp & ~v_rsp_we;
  wire v_rwr = v_ev_rsp &  v_rsp_we;
  wire v_nz_xtra = |v_ev_xtra;
  wire v_e_range = v_ev_acc_err & (v_ev_err_code == `SF_ST_RANGE);
  wire v_e_align = v_ev_acc_err & (v_ev_err_code == `SF_ST_ALIGN);
  wire v_e_owner = v_ev_acc_err & (v_ev_err_code == `SF_ST_OWNER);
  wire v_e_badop = v_ev_acc_err & (v_ev_err_code == `SF_ST_BADOP);
  wire d_e_range = d_ev_acc_err & (d_ev_err_code == `SF_ST_RANGE);
  wire d_e_align = d_ev_acc_err & (d_ev_err_code == `SF_ST_ALIGN);
  wire d_e_owner = d_ev_acc_err & (d_ev_err_code == `SF_ST_OWNER);
  wire d_e_badop = d_ev_acc_err & (d_ev_err_code == `SF_ST_BADOP);
  function automatic logic [1:0] add2(input logic a, input logic b);
    add2 = {a & b, a ^ b};
  endfunction

  // ------------------------------------------------------------ counters
  assign ev_spm_read_o     = add2(v_ld, d_rd);
  assign ev_spm_write_o    = add2(v_st, d_wr);
  assign ev_spm_conflict_o = add2(v_ev_stall_arb, d_ev_stall_arb);

  generate
    if (PERF_EN != 0) begin : g_perf
      logic [`SF_PC_N*ADDW-1:0] add;
      logic [NB-1:0] bank_acc_ev, bank_conf_all;
      always_comb begin
        add = '0;
        add[`SF_PC_CYCLES*ADDW +: ADDW]        = ADDW'(1);
        add[`SF_PC_V_REQ*ADDW +: ADDW]         = ADDW'(v_ev_acc);
        add[`SF_PC_V_LD*ADDW +: ADDW]          = ADDW'(v_ld);
        add[`SF_PC_V_ST*ADDW +: ADDW]          = ADDW'(v_st);
        add[`SF_PC_V_RSP*ADDW +: ADDW]         = ADDW'(v_ev_rsp);
        add[`SF_PC_V_BYTES_LD*ADDW +: ADDW]    = v_req_we ? '0 : ADDW'(v_ev_bytes);
        add[`SF_PC_V_BYTES_ST*ADDW +: ADDW]    = v_req_we ? ADDW'(v_ev_bytes) : '0;
        add[`SF_PC_V_ERR*ADDW +: ADDW]         = ADDW'(v_ev_acc_err);
        add[`SF_PC_V_SPLIT_REQ*ADDW +: ADDW]   = ADDW'(v_nz_xtra);
        add[`SF_PC_V_ALIGN_XTRA*ADDW +: ADDW]  = ADDW'(v_ev_xtra);
        add[`SF_PC_V_WORD_ACC*ADDW +: ADDW]    = ADDW'(v_ev_words);
        add[`SF_PC_V_STALL_CONF*ADDW +: ADDW]  = ADDW'(v_ev_stall_conf);
        add[`SF_PC_V_STALL_ARB*ADDW +: ADDW]   = ADDW'(v_ev_stall_arb);
        add[`SF_PC_V_REQ_BLOCKED*ADDW +: ADDW] = ADDW'(v_ev_blocked);
        add[`SF_PC_V_RSP_BP*ADDW +: ADDW]      = ADDW'(v_ev_rsp_bp);
        add[`SF_PC_V_STARVE*ADDW +: ADDW]      = ADDW'(v_ev_starve);
        add[`SF_PC_LAT_RD_SUM*ADDW +: ADDW]    = v_rrd ? v_ev_lat : '0;
        add[`SF_PC_LAT_RD_CNT*ADDW +: ADDW]    = ADDW'(v_rrd);
        add[`SF_PC_LAT_RD_MAX*ADDW +: ADDW]    = v_rrd ? v_ev_lat : '0;
        add[`SF_PC_LAT_WR_SUM*ADDW +: ADDW]    = v_rwr ? v_ev_lat : '0;
        add[`SF_PC_LAT_WR_CNT*ADDW +: ADDW]    = ADDW'(v_rwr);
        add[`SF_PC_LAT_WR_MAX*ADDW +: ADDW]    = v_rwr ? v_ev_lat : '0;
        add[`SF_PC_D_REQ*ADDW +: ADDW]         = ADDW'(d_ev_acc);
        add[`SF_PC_D_BYTES_RD*ADDW +: ADDW]    = d_req_write ? '0 : ADDW'(d_ev_bytes);
        add[`SF_PC_D_BYTES_WR*ADDW +: ADDW]    = d_req_write ? ADDW'(d_ev_bytes) : '0;
        add[`SF_PC_D_WORD_ACC*ADDW +: ADDW]    = ADDW'(d_ev_words);
        add[`SF_PC_D_STALL_ARB*ADDW +: ADDW]   = ADDW'(d_ev_stall_arb);
        add[`SF_PC_D_REQ_BLOCKED*ADDW +: ADDW] = ADDW'(d_ev_blocked);
        add[`SF_PC_D_ERR*ADDW +: ADDW]         = ADDW'(d_ev_acc_err);
        add[`SF_PC_ERR_RANGE*ADDW +: ADDW]     = ADDW'(add2(v_e_range, d_e_range));
        add[`SF_PC_ERR_ALIGN*ADDW +: ADDW]     = ADDW'(add2(v_e_align, d_e_align));
        add[`SF_PC_ERR_OWNER*ADDW +: ADDW]     = ADDW'(add2(v_e_owner, d_e_owner));
        add[`SF_PC_ERR_BADOP*ADDW +: ADDW]     = ADDW'(add2(v_e_badop, d_e_badop));
      end
      assign bank_acc_ev   = b_en;
      assign bank_conf_all = bank_conf_ev | v_bank_multi | d_bank_multi;
      sf_vspm_perf #(.NB(NB), .CNT_W(CNT_W), .ADDW(ADDW)) u_perf (
        .clk(clk), .rst_n(rst_n), .clear_i(perf_clear_i), .add_i(add), .bank_acc_i(bank_acc_ev), .bank_conf_i(bank_conf_all),
        .perf_o(perf_o), .bank_acc_o(perf_bank_acc_o), .bank_conf_o(perf_bank_conf_o));
    end else begin : g_noperf
      assign perf_o = '0; assign perf_bank_acc_o = '0; assign perf_bank_conf_o = '0;
      wire unused_perf = &{1'b0, perf_clear_i, v_ev_lat, d_ev_lat, v_ev_xtra, d_ev_xtra, v_ev_bytes, d_ev_bytes, v_ev_words, d_ev_words,
                           v_ev_stall_conf, d_ev_stall_conf, v_ev_blocked, d_ev_blocked, v_ev_rsp, d_ev_rsp, v_ev_rsp_bp, d_ev_rsp_bp,
                           v_ev_starve, d_ev_starve, v_bank_multi, d_bank_multi, bank_conf_ev, d_rsp_we_w, d_ev_rsp, d_ev_starve};
    end
  endgenerate

  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
