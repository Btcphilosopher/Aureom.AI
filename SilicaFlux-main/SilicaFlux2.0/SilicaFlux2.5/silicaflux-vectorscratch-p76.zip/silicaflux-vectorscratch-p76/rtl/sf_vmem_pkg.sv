// =============================================================================
// SilicaFlux VectorScratch :: sf_vmem_pkg   (vector memory request package)
// Types, constants and helper functions for the clients of sf_vector_scratchpad: the vector engine / its load-store unit,
// DMA descriptors, performance models and testbenches.
//
//   * constants   status codes, access modes, alignment policies, bank maps, owners, perf-counter indices.  They MIRROR
//                 sf_vspm_defs.svh / sf_sram_defs.svh (the RTL itself uses the `define header because Yosys 0.33 cannot
//                 resolve package references in parameter lists); tb_pkg checks that the two agree.
//   * transaction-level types   vm_req_t / vm_rsp_t.  These are NOT the RTL port list (the RTL ports are flat and sized by
//                 parameters); they carry a request at its maximum width (512-bit vector, 16 lanes) so that software models,
//                 compilers and testbenches can build / pass / compare requests with one value.
//   * helpers     lane mask -> byte-enable mask (hpc_vector_array res_mask_o -> v_req_mask), tail masks for the partial final
//                 vector of an array, bank / row of a byte address, number of words an access touches and the cycles it
//                 needs on single-port banks (an analytical bank-conflict predictor).  All are pure functions.
// Memory holds RAW BITS; nothing here interprets floating point.
// Classification: SIMULATION / MODEL SUPPORT (functions are also synthesizable constants helpers for elaboration-time use)
// =============================================================================
package sf_vmem_pkg;

  localparam int MAX_VEC_BYTES = 64;                   // largest vector this package's transaction types hold (512 bit)
  localparam int MAX_LANES     = 16;                   // 32-bit lanes of a 512-bit vector (hpc_vector_array NUM_LANES max)
  localparam int IDX_W         = 32;

  // ------------------------------------------------------------ status codes (response)
  localparam logic [2:0] ST_OK    = 3'd0;
  localparam logic [2:0] ST_RANGE = 3'd1;              // a needed word is outside the aperture: no side effect
  localparam logic [2:0] ST_ALIGN = 3'd2;              // rejected by the alignment policy / misaligned element: no side effect
  localparam logic [2:0] ST_OWNER = 3'd4;              // region owned by the other port: no side effect
  localparam logic [2:0] ST_BADOP = 3'd5;              // unsupported mode: no side effect

  // ------------------------------------------------------------ access mode
  typedef enum logic [1:0] {
    MODE_CONTIG  = 2'd0,                               // bytes [addr, addr + VEC_BYTES)
    MODE_STRIDED = 2'd1,                               // element l at addr + l * stride
    MODE_INDEXED = 2'd2                                // element l at addr + sext(idx[l])   gather / scatter
  } vm_mode_e;

  // ------------------------------------------------------------ configuration enums
  localparam int ALIGN_VEC  = 0;                       // reject unless addr % VEC_BYTES == 0
  localparam int ALIGN_WORD = 1;                       // reject unless addr % BANK_BYTES == 0
  localparam int ALIGN_ANY  = 2;                       // split / merge across words and banks
  localparam int MAP_LOW    = 0;
  localparam int MAP_XOR    = 1;
  localparam int MAP_BLOCK  = 2;
  localparam int ARB_VEC    = 0;
  localparam int ARB_DMA    = 1;
  localparam int ARB_RR     = 2;
  localparam logic [1:0] OWN_SHARED = 2'd0;
  localparam logic [1:0] OWN_VEC    = 2'd1;
  localparam logic [1:0] OWN_DMA    = 2'd2;

  // ------------------------------------------------------------ performance counter indices (perf_o)
  typedef enum int {
    PC_CYCLES = 0, PC_V_REQ, PC_V_LD, PC_V_ST, PC_V_RSP, PC_V_BYTES_LD, PC_V_BYTES_ST, PC_V_ERR, PC_V_SPLIT_REQ,
    PC_V_ALIGN_XTRA, PC_V_WORD_ACC, PC_V_STALL_CONF, PC_V_STALL_ARB, PC_V_REQ_BLOCKED, PC_V_RSP_BP, PC_V_STARVE,
    PC_LAT_RD_SUM, PC_LAT_RD_CNT, PC_LAT_RD_MAX, PC_LAT_WR_SUM, PC_LAT_WR_CNT, PC_LAT_WR_MAX,
    PC_D_REQ, PC_D_BYTES_RD, PC_D_BYTES_WR, PC_D_WORD_ACC, PC_D_STALL_ARB, PC_D_REQ_BLOCKED, PC_D_ERR,
    PC_ERR_RANGE, PC_ERR_ALIGN, PC_ERR_OWNER, PC_ERR_BADOP, PC_N
  } vm_pc_e;

  // ------------------------------------------------------------ transaction-level request / response
  typedef struct packed {
    logic                          we;                 // 0 load, 1 store
    vm_mode_e                      mode;
    logic [31:0]                   addr;               // byte address of the access (or of lane 0 for strided / indexed)
    logic [31:0]                   stride;             // STRIDED: bytes between elements (two's complement)
    logic [MAX_LANES*IDX_W-1:0]    idx;                // INDEXED: signed byte offsets, lane l in [l*32 +: 32]
    logic [MAX_VEC_BYTES-1:0]      mask;               // per-byte enable (store: 0 = byte unchanged; load: 0 = reads as 0)
    logic [MAX_VEC_BYTES*8-1:0]    wdata;              // byte j in bits [8j +: 8]; FP32 lane l in [32l +: 32]
    logic [7:0]                    id;
  } vm_req_t;

  typedef struct packed {
    logic [2:0]                    status;
    logic                          we;
    logic [MAX_VEC_BYTES*8-1:0]    rdata;              // 0 for stores, errors and masked-off bytes
    logic [7:0]                    id;
  } vm_rsp_t;

  // ------------------------------------------------------------ masks
  // lane mask (one bit per element of elem_bytes bytes, e.g. hpc_vector_array res_mask_o with 4-byte lanes) -> byte-enable mask
  function automatic logic [MAX_VEC_BYTES-1:0] lane_to_byte_mask(input logic [MAX_VEC_BYTES-1:0] lane_mask, input int elem_bytes);
    logic [MAX_VEC_BYTES-1:0] m;
    m = '0;
    for (int l = 0; l < MAX_VEC_BYTES / elem_bytes; l++)
      for (int b = 0; b < elem_bytes; b++)
        m[l*elem_bytes + b] = lane_mask[l];
    return m;
  endfunction

  // the n lowest bytes enabled (tail of a partial vector)
  function automatic logic [MAX_VEC_BYTES-1:0] tail_mask(input int n_bytes);
    logic [MAX_VEC_BYTES-1:0] m;
    m = '0;
    for (int j = 0; j < MAX_VEC_BYTES; j++) m[j] = (j < n_bytes);
    return m;
  endfunction

  // byte mask of vector number `v` of an array of n_elems elements of elem_bytes bytes (the last vector is the partial one)
  function automatic logic [MAX_VEC_BYTES-1:0] array_vector_mask(input int n_elems, input int v, input int vec_bytes, input int elem_bytes);
    int per_vec, remaining;
    per_vec   = vec_bytes / elem_bytes;
    remaining = n_elems - v * per_vec;
    if (remaining <= 0)       return '0;
    else if (remaining >= per_vec) return tail_mask(vec_bytes);
    else                       return tail_mask(remaining * elem_bytes);
  endfunction

  // ------------------------------------------------------------ banking
  function automatic int word_bank(input longint widx, input int nb, input int depth, input int bank_map);
    case (bank_map)
      MAP_XOR:   word_bank = int'((widx % nb) ^ ((widx / nb) % nb));
      MAP_BLOCK: word_bank = int'(widx / depth);
      default:   word_bank = int'(widx % nb);
    endcase
  endfunction
  function automatic int word_row(input longint widx, input int nb, input int depth, input int bank_map);
    case (bank_map)
      MAP_BLOCK: word_row = int'(widx % depth);
      default:   word_row = int'(widx / nb);
    endcase
  endfunction
  function automatic int addr_bank(input longint addr, input int bank_bytes, input int nb, input int depth, input int bank_map);
    return word_bank(addr / bank_bytes, nb, depth, bank_map);
  endfunction

  // number of bank words a CONTIGUOUS access touches (words with at least one enabled byte)
  function automatic int words_touched(input longint addr, input logic [MAX_VEC_BYTES-1:0] mask, input int vec_bytes, input int bank_bytes);
    int n, first, w;
    bit seen [MAX_VEC_BYTES + 1];
    n = 0;
    first = int'(addr % bank_bytes);
    for (int k = 0; k <= MAX_VEC_BYTES; k++) seen[k] = 0;
    for (int j = 0; j < vec_bytes; j++) if (mask[j]) begin w = (first + j) / bank_bytes; if (!seen[w]) begin seen[w] = 1; n++; end end
    return n;
  endfunction

  // cycles the banks need for ONE isolated contiguous access = the largest number of its words that map to one bank
  // (single-port banks: one access per bank per cycle).  0 for an access with no enabled byte.
  function automatic int bank_cycles(input longint addr, input logic [MAX_VEC_BYTES-1:0] mask, input int vec_bytes,
                                     input int bank_bytes, input int nb, input int depth, input int bank_map);
    int load [64];
    int first, w, mx;
    bit seen [MAX_VEC_BYTES + 1];
    for (int b = 0; b < 64; b++) load[b] = 0;
    for (int k = 0; k <= MAX_VEC_BYTES; k++) seen[k] = 0;
    first = int'(addr % bank_bytes);
    for (int j = 0; j < vec_bytes; j++) if (mask[j]) begin
      w = (first + j) / bank_bytes;
      if (!seen[w]) begin seen[w] = 1; load[word_bank(addr / bank_bytes + w, nb, depth, bank_map)]++; end
    end
    mx = 0;
    for (int b = 0; b < 64; b++) if (load[b] > mx) mx = load[b];
    return mx;
  endfunction

  // best-case read latency (cycles from the accepting edge to the response handshake with an always-ready consumer)
  // of one isolated access: READ_LATENCY + 2 plus one cycle per extra access to the busiest bank; 1 if no bank is touched
  function automatic int isolated_latency(input int read_latency, input int cycles_on_banks);
    return (cycles_on_banks == 0) ? 1 : (read_latency + 2 + (cycles_on_banks - 1));
  endfunction

endpackage
