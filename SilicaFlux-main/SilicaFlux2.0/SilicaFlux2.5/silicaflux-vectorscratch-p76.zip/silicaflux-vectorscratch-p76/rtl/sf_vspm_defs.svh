// =============================================================================
// SilicaFlux VectorScratch (Project 76) :: sf_vspm_defs.svh
// Constants shared by every sf_vspm_* module.  A `define header (not a package) for the same reason as the MemoryCore
// header it extends: Yosys 0.33 cannot resolve package references in parameter lists.  The same values are mirrored
// in the SystemVerilog package sf_vmem_pkg (testbench / system use); tb_pkg_consistency checks that both agree.
// Values are part of the interface contract (docs/02_interface_and_contract.md): never renumber.
// Response status codes come from sf_sram_defs.svh (SF_ST_OK, SF_ST_RANGE, SF_ST_ALIGN, SF_ST_OWNER, SF_ST_BADOP).
// =============================================================================
`ifndef SF_VSPM_DEFS_SVH
`define SF_VSPM_DEFS_SVH

`include "sf_sram_defs.svh"

// ------------------------------------------------------------ access mode (req_mode, 2 bits)
`define SF_VM_MODE_CONTIG   2'd0   // contiguous bytes [addr, addr + VEC_BYTES)
`define SF_VM_MODE_STRIDED  2'd1   // element l at addr + l * stride   (GS_EN = 1)
`define SF_VM_MODE_INDEXED  2'd2   // element l at addr + sext(idx[l]) (GS_EN = 1)   gather (load) / scatter (store)

// ------------------------------------------------------------ alignment policy (ALIGN_POLICY)
`define SF_VM_ALIGN_VEC     0      // REJECT (policy A): addr must be a multiple of VEC_BYTES
`define SF_VM_ALIGN_WORD    1      // REJECT (policy A): addr must be a multiple of the bank word (BANK_BYTES)
`define SF_VM_ALIGN_ANY     2      // SPLIT/MERGE (policy B): any byte address; crosses words and banks

// ------------------------------------------------------------ word -> (bank, row) maps (BANK_MAP)
`define SF_VM_MAP_LOW       0      // bank = w mod NB, row = w / NB            (consecutive words rotate through the banks)
`define SF_VM_MAP_XOR       1      // bank = (w mod NB) ^ (row mod NB)         (bijective; breaks stride-NB patterns)
`define SF_VM_MAP_BLOCK     2      // bank = w / DEPTH, row = w mod DEPTH      (banks are contiguous regions)

// ------------------------------------------------------------ per-bank arbitration between the two ports (ARB_POLICY)
`define SF_VM_ARB_VEC       0      // vector port always wins (DMA can starve; measured, not hidden)
`define SF_VM_ARB_DMA       1      // DMA port always wins (vector can starve)
`define SF_VM_ARB_RR        2      // round robin per bank: a continuously requesting port waits at most 1 grant

// ------------------------------------------------------------ region ownership (2 bits per region)
`define SF_VM_OWN_SHARED    2'd0   // both ports may access (per-word atomic only; no ordering between ports)
`define SF_VM_OWN_VEC       2'd1   // only the vector port; a DMA access is answered SF_ST_OWNER
`define SF_VM_OWN_DMA       2'd2   // only the DMA port;    a vector access is answered SF_ST_OWNER

// ------------------------------------------------------------ performance counter indices (perf_o bus, CNT_W bits each)
`define SF_PC_CYCLES        0
`define SF_PC_V_REQ         1      // vector requests accepted
`define SF_PC_V_LD          2      // ... of which loads
`define SF_PC_V_ST          3      // ... of which stores
`define SF_PC_V_RSP         4      // vector responses delivered
`define SF_PC_V_BYTES_LD    5      // useful bytes loaded (mask popcount of loads that reached memory)
`define SF_PC_V_BYTES_ST    6      // useful bytes stored
`define SF_PC_V_ERR         7      // vector requests answered with an error status
`define SF_PC_V_SPLIT_REQ   8      // vector requests that needed more word accesses than the same mask at offset 0
`define SF_PC_V_ALIGN_XTRA  9      // sum of those extra word accesses (alignment overhead)
`define SF_PC_V_WORD_ACC    10     // bank accesses granted to the vector port
`define SF_PC_V_STALL_CONF  11     // cycles a vector request waited for a bank used by another slot of the SAME request
`define SF_PC_V_STALL_ARB   12     // cycles a vector request lost a bank to the DMA port
`define SF_PC_V_REQ_BLOCKED 13     // cycles v_req_valid && !v_req_ready
`define SF_PC_V_RSP_BP      14     // cycles v_rsp_valid && !v_rsp_ready (consumer back-pressure)
`define SF_PC_V_STARVE      15     // cycles the consumer was ready, nothing was deliverable, work was outstanding (lane starvation)
`define SF_PC_LAT_RD_SUM    16     // sum of accept -> response-handshake latency over loads
`define SF_PC_LAT_RD_CNT    17
`define SF_PC_LAT_RD_MAX    18
`define SF_PC_LAT_WR_SUM    19
`define SF_PC_LAT_WR_CNT    20
`define SF_PC_LAT_WR_MAX    21
`define SF_PC_D_REQ         22     // DMA requests accepted
`define SF_PC_D_BYTES_RD    23     // DMA bytes read  (write-strobe popcount / full beat for reads)
`define SF_PC_D_BYTES_WR    24
`define SF_PC_D_WORD_ACC    25     // bank accesses granted to the DMA port
`define SF_PC_D_STALL_ARB   26     // cycles a DMA request lost a bank to the vector port
`define SF_PC_D_REQ_BLOCKED 27     // cycles d_req_valid && !d_req_ready
`define SF_PC_D_ERR         28
`define SF_PC_ERR_RANGE     29     // error responses by type (both ports)
`define SF_PC_ERR_ALIGN     30
`define SF_PC_ERR_OWNER     31
`define SF_PC_ERR_BADOP     32
`define SF_PC_N             33

`endif // SF_VSPM_DEFS_SVH
