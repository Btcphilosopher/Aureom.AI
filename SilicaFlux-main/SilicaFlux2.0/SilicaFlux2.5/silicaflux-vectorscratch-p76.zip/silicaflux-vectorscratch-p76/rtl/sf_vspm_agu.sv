// =============================================================================
// SilicaFlux VectorScratch :: sf_vspm_agu   (address generation, request checks, bank selection)
// From one request this block derives, combinationally, for each of the NW word SLOTS of the access window:
//   need[s]       slot s carries at least one enabled byte (window mask) -> it must be accessed; others are never touched
//   slot_bank[s], slot_row[s]     bank and row of the slot's word (sf_vspm_bankmap)
// and one error code for the whole request (precedence BADOP > RANGE > ALIGN > OWNER; the code is SF_ST_OK when the
// request may proceed):
//   BADOP  mode 3, or a strided / indexed mode while GS_EN = 0
//   RANGE  a NEEDED slot lies outside the aperture [0, NB*DEPTH*BANK_BYTES).  Masked-off bytes beyond the end are legal.
//   ALIGN  CONTIG: policy VEC needs addr % VEC_BYTES == 0, policy WORD needs addr % BANK_BYTES == 0 (policy ANY: never);
//          STRIDED / INDEXED: every ACTIVE lane needs its element address % GS_ES == 0
//   OWNER  a needed slot lies in a region this port does not own (2 bits per region: SHARED / VEC / DMA)
// Slot -> word mapping:
//   CONTIG   slot s = word (addr / BANK_BYTES) + s                          (the window; byte offset handled by sf_vspm_split)
//   element  slot s = lane s / WPE, sub-word s % WPE  (WPE = GS_ES / BANK_BYTES): word (ea_lane / BANK_BYTES) + s % WPE,
//            ea_lane = addr + lane * stride  (STRIDED)  or  addr + sext(idx[lane])  (INDEXED)
// Address arithmetic is done in AWX = max(AW, IDXW) + 8 bits two's complement, so no strided / indexed address can wrap
// back into the aperture: a negative or oversized element address is a RANGE error.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"
`default_nettype none

module sf_vspm_agu #(
  parameter int AW           = 32,
  parameter int VEC_BYTES    = 16,
  parameter int BB           = 4,
  parameter int NB           = 4,
  parameter int DEPTH        = 256,
  parameter int BANK_MAP     = `SF_VM_MAP_LOW,
  parameter int ALIGN_POLICY = `SF_VM_ALIGN_ANY,
  parameter int GS_EN        = 0,
  parameter int GS_ES        = 4,
  parameter int IDXW         = 32,
  parameter int NRGN         = 4,
  parameter int PORT         = 0,                       // 0 = vector port, 1 = DMA port (ownership check)
  parameter int NW           = VEC_BYTES / BB + ((ALIGN_POLICY == `SF_VM_ALIGN_ANY) ? 1 : 0),
  parameter int BW           = (NB > 1) ? $clog2(NB) : 1,
  parameter int RW           = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int LANES        = (GS_EN != 0) ? VEC_BYTES / GS_ES : 1
) (
  input  wire logic [AW-1:0]          addr,
  input  wire logic [1:0]             mode,
  input  wire logic [AW-1:0]          stride,
  input  wire logic [LANES*IDXW-1:0]  idx,
  /* verilator lint_off UNUSEDSIGNAL */                      // mask / ea_flat: used only by the strided / indexed logic (GS_EN = 1)
  input  wire logic [VEC_BYTES-1:0]   mask,             // per-byte enable of the vector
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [NW*BB-1:0]       wmask,            // window mask (after sf_vspm_split)
  input  wire logic [NRGN*2-1:0]      own,
  output logic [NW-1:0]               need,
  output logic [NW*BW-1:0]            slot_bank,
  output logic [NW*RW-1:0]            slot_row,
  output logic [2:0]                  err
);
  localparam int VW   = VEC_BYTES / BB;
  localparam int LBB  = $clog2(BB);
  localparam int LVB  = $clog2(VEC_BYTES);
  localparam int LTW  = $clog2(NB * DEPTH);
  localparam int RGNW = (NRGN > 1) ? $clog2(NRGN) : 0;
  localparam int RGW  = (RGNW > 0) ? RGNW : 1;
  localparam int AWX  = ((AW > IDXW) ? AW : IDXW) + 8;
  localparam int WPE  = (GS_EN != 0) ? GS_ES / BB : 1;
  localparam int LES  = (GS_EN != 0) ? $clog2(GS_ES) : 1;

  // ------------------------------------------------------------ element addresses (STRIDED / INDEXED)
  /* verilator lint_off UNUSEDSIGNAL */
  logic [LANES*AWX-1:0] ea_flat;
  /* verilator lint_on UNUSEDSIGNAL */
  logic signed [AWX-1:0] base_s, str_s, idx_s, e_s;
  always_comb begin
    ea_flat = '0;
    base_s  = $signed({{(AWX - AW){1'b0}}, addr});
    str_s   = $signed({{(AWX - AW){stride[AW-1]}}, stride});
    idx_s   = '0;
    e_s     = '0;
    for (int l = 0; l < LANES; l++) begin
      idx_s = $signed({{(AWX - IDXW){idx[l*IDXW + IDXW - 1]}}, idx[l*IDXW +: IDXW]});
      case (mode)
        `SF_VM_MODE_STRIDED: e_s = base_s + str_s * $signed(AWX'(l));
        `SF_VM_MODE_INDEXED: e_s = base_s + idx_s;
        default:             e_s = base_s;
      endcase
      ea_flat[l*AWX +: AWX] = e_s;
    end
  end

  // ------------------------------------------------------------ per-slot word index, range, region, bank, row
  logic [NW-1:0] bad_range, bad_own;
  genvar s;
  generate
    for (s = 0; s < NW; s++) begin : g_slot
      logic [AWX-1:0] wi, wi_c;
      assign wi_c = (AWX'(addr) >> LBB) + AWX'(s);
      if (GS_EN != 0 && s < VW) begin : g_el
        localparam int LANE = s / WPE;
        localparam int SUBW = s % WPE;
        logic signed [AWX-1:0] ea_l;
        logic [AWX-1:0]        wi_e;
        assign ea_l = $signed(ea_flat[LANE*AWX +: AWX]);
        assign wi_e = AWX'(ea_l >>> LBB) + AWX'(SUBW);
        assign wi   = (mode == `SF_VM_MODE_CONTIG) ? wi_c : wi_e;
      end else begin : g_co
        assign wi = wi_c;
      end

      wire inr = ((wi >> LTW) == '0);                      // two's complement: a negative index has high bits set
      assign need[s] = |wmask[s*BB +: BB];

      sf_vspm_bankmap #(.NB(NB), .DEPTH(DEPTH), .BANK_MAP(BANK_MAP), .WIW(LTW)) u_map (
        .widx(wi[LTW-1:0]), .bank(slot_bank[s*BW +: BW]), .row(slot_row[s*RW +: RW]));

      logic [RGW-1:0] rg;
      if (RGNW > 0) begin : g_rg
        assign rg = wi[LTW-1 -: RGW];
      end else begin : g_rg0
        assign rg = '0;
      end
      wire [1:0] o = own[rg*2 +: 2];
      wire allowed = (o == `SF_VM_OWN_SHARED) || (o == ((PORT == 0) ? `SF_VM_OWN_VEC : `SF_VM_OWN_DMA));
      assign bad_range[s] = need[s] & ~inr;
      assign bad_own[s]   = need[s] & inr & ~allowed;
    end
  endgenerate

  // ------------------------------------------------------------ alignment
  logic [LANES-1:0] lane_al_bad;
  genvar l;
  generate
    for (l = 0; l < LANES; l++) begin : g_lane
      if (GS_EN != 0) begin : g_chk
        assign lane_al_bad[l] = (|mask[l*GS_ES +: GS_ES]) & (|ea_flat[l*AWX +: LES]);
      end else begin : g_off
        assign lane_al_bad[l] = 1'b0;
      end
    end
  endgenerate

  logic align_bad;
  always_comb begin
    align_bad = 1'b0;
    if (GS_EN == 0 || mode == `SF_VM_MODE_CONTIG) begin
      case (ALIGN_POLICY)
        `SF_VM_ALIGN_VEC:  align_bad = |addr[LVB-1:0];
        `SF_VM_ALIGN_WORD: align_bad = |addr[LBB-1:0];
        default:           align_bad = 1'b0;
      endcase
    end else begin
      align_bad = |lane_al_bad;
    end
  end

  wire badop = (mode == 2'd3) | ((GS_EN == 0) & (mode != `SF_VM_MODE_CONTIG));
  always_comb begin
    if (badop)               err = `SF_ST_BADOP;
    else if (align_bad)      err = `SF_ST_ALIGN;
    else if (|bad_range)     err = `SF_ST_RANGE;
    else if (|bad_own)       err = `SF_ST_OWNER;
    else                     err = `SF_ST_OK;
  end

  wire unused = &{1'b0, stride[0], idx[0], mask[0]};
endmodule

`default_nettype wire
