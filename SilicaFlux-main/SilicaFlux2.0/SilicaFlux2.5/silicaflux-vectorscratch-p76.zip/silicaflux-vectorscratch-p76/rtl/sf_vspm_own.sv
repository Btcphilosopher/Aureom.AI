// =============================================================================
// SilicaFlux VectorScratch :: sf_vspm_own   (region ownership for DMA / vector coordination)
// The aperture is split into NRGN equal regions; each has a 2-bit owner: SHARED (both ports), VEC or DMA (exclusive; an
// access by the other port is answered SF_ST_OWNER, no array access, no side effect).  Ownership is checked at request
// acceptance by the AGU of each port.
//
// CHANGE PROTOCOL (own_req_*): a change is accepted when none is pending, then the unit QUIESCES: both ports stop accepting
// (blk_o), every request already accepted completes (all responses delivered), and only then the new owner takes effect
// and own_ack_o pulses.  Therefore, when own_ack_o is seen:
//   * every access of the previous owner to the aperture has been completed and is committed in the array, and
//   * no access of the new owner can have started before the change.
// This is the hand-over a ping-pong buffer needs: DMA finishes filling region R (DMA store responses received), software
// transfers R to the vector port, which can then read it with certainty.  The quiesce is GLOBAL (it pauses both ports for
// the drain time) and relies on the consumers accepting their responses; if a consumer never takes a response the change
// never completes.  Value 3 is reserved: the request is acknowledged with own_err_o and changes nothing.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"
`default_nettype none

module sf_vspm_own #(
  parameter int NRGN      = 4,
  parameter int OWN_RESET = `SF_VM_OWN_VEC,
  parameter int RGW       = (NRGN > 1) ? $clog2(NRGN) : 1
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                req_valid,
  output logic                     req_ready,
  input  wire logic [RGW-1:0]      req_rgn,
  input  wire logic [1:0]          req_val,
  input  wire logic                idle_i,            // both ports idle
  output logic                     blk_o,             // 1 = ports must not accept
  output logic                     ack_o,
  output logic                     err_o,
  output logic [NRGN*2-1:0]        own_o
);
  logic            busy;
  logic [RGW-1:0]  rgn_q;
  logic [1:0]      val_q;
  assign req_ready = ~busy;
  assign blk_o     = busy;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= 1'b0; rgn_q <= '0; val_q <= '0; ack_o <= 1'b0; err_o <= 1'b0;
      for (int r = 0; r < NRGN; r++) own_o[r*2 +: 2] <= 2'(OWN_RESET);
    end else begin
      ack_o <= 1'b0;
      err_o <= 1'b0;
      if (!busy) begin
        if (req_valid) begin
          busy <= 1'b1; rgn_q <= req_rgn; val_q <= req_val;
        end
      end else if (idle_i) begin
        busy <= 1'b0;
        ack_o <= 1'b1;
        if (val_q == 2'd3) err_o <= 1'b1;
        else if (32'(rgn_q) < NRGN) own_o[32'(rgn_q)*2 +: 2] <= val_q;
      end
    end
  end
endmodule

`default_nettype wire
