// =============================================================================
// SilicaFlux VectorScratch :: sf_vspm_perf   (performance counters)
// NC saturating CNT_W-bit counters (index map: SF_PC_* in sf_vspm_defs.svh) plus per-bank access and conflict counters.
// add_i[i] is the amount counter i advances this cycle (0 = no event).  The two LAT_*_MAX counters keep a maximum
// instead of a sum.  clear_i zeroes everything synchronously.  Counters never wrap: they stick at all ones.
// Every counter is an observation of the DESIGN'S OWN signals; nothing here changes behaviour.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`include "sf_vspm_defs.svh"
`default_nettype none

module sf_vspm_perf #(
  parameter int NB    = 4,
  parameter int CNT_W = 32,
  parameter int ADDW  = 16,
  parameter int NC    = `SF_PC_N
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                clear_i,
  input  wire logic [NC*ADDW-1:0]  add_i,
  input  wire logic [NB-1:0]       bank_acc_i,
  input  wire logic [NB-1:0]       bank_conf_i,
  output logic [NC*CNT_W-1:0]      perf_o,
  output logic [NB*CNT_W-1:0]      bank_acc_o,
  output logic [NB*CNT_W-1:0]      bank_conf_o
);
  localparam logic [CNT_W-1:0] ALL1 = '1;
  genvar i;
  generate
    for (i = 0; i < NC; i++) begin : g_c
      logic [CNT_W-1:0] c;
      wire  [ADDW-1:0]  a = add_i[i*ADDW +: ADDW];
      if (i == `SF_PC_LAT_RD_MAX || i == `SF_PC_LAT_WR_MAX) begin : g_max
        always_ff @(posedge clk or negedge rst_n) begin
          if (!rst_n) c <= '0;
          else if (clear_i) c <= '0;
          else if (CNT_W'(a) > c) c <= CNT_W'(a);
        end
      end else begin : g_sum
        wire [CNT_W:0] sum = {1'b0, c} + {1'b0, CNT_W'(a)};
        always_ff @(posedge clk or negedge rst_n) begin
          if (!rst_n) c <= '0;
          else if (clear_i) c <= '0;
          else if (a != '0) c <= sum[CNT_W] ? ALL1 : sum[CNT_W-1:0];
        end
      end
      assign perf_o[i*CNT_W +: CNT_W] = c;
    end
    for (i = 0; i < NB; i++) begin : g_b
      logic [CNT_W-1:0] ca, cc;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin ca <= '0; cc <= '0; end
        else if (clear_i) begin ca <= '0; cc <= '0; end
        else begin
          if (bank_acc_i[i]  && ca != ALL1) ca <= ca + 1'b1;
          if (bank_conf_i[i] && cc != ALL1) cc <= cc + 1'b1;
        end
      end
      assign bank_acc_o[i*CNT_W +: CNT_W]  = ca;
      assign bank_conf_o[i*CNT_W +: CNT_W] = cc;
    end
  endgenerate
endmodule

`default_nettype wire
