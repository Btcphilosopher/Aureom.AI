// =============================================================================
// SilicaFlux VectorScratch :: sf_vspm_merge   (LOAD side of the alignment logic)
// Reassembles the vector from the window of NW bank words returned by the banks:
//   vector byte j = window byte (off + j)  if mask bit j, else 0.
// Words of the window that were not accessed (all their mask bits 0) hold stale data in the completion queue; the mask
// zeroes every byte that was not requested, so stale data can never reach the consumer (masked-off lanes read as 0).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_vspm_merge #(
  parameter int VEC_BYTES = 16,
  parameter int BB        = 4,
  parameter int NW        = 5,
  parameter int OFFW      = (BB > 1) ? $clog2(BB) : 1
) (
  input  wire logic [NW*BB*8-1:0]     win,
  input  wire logic [OFFW-1:0]        off,
  input  wire logic [VEC_BYTES-1:0]   mask,
  output logic [VEC_BYTES*8-1:0]      rdata
);
  logic [NW*BB*8-1:0] sh;
  always_comb begin
    sh = win >> {off, 3'b000};
    for (int j = 0; j < VEC_BYTES; j++)
      rdata[j*8 +: 8] = mask[j] ? sh[j*8 +: 8] : 8'h00;
  end
endmodule

`default_nettype wire
