# 03 - Microarchitecture

## Blocks

| module | role |
|---|---|
| `sf_vector_scratchpad` | top: two ports, ownership, bank scheduler, banks, error registers, counters, tile hooks |
| `sf_vspm_port` | one requester port: acceptance, split, AGU, issue stage S1, in-order completion queue, merge, response, per-port events |
| `sf_vspm_agu` | per-slot word index -> `need`, bank, row; range / alignment / ownership / mode checks; element addresses for strided / indexed |
| `sf_vspm_bankmap` | word index -> (bank, row): LOW / XOR / BLOCK |
| `sf_vspm_split`, `sf_vspm_merge` | store-side and load-side alignment (byte shifts by the start offset) |
| `sf_vspm_bank_sched` | per-bank arbitration between the ports (VEC / DMA / round robin) and routing onto the bank buses |
| `sf_vspm_banks` | `NB` x `sf_sram_macro_wrapper` (reused) |
| `sf_vspm_own` | region ownership and the quiesced change protocol |
| `sf_vspm_perf` | saturating counters |
| `sf_vmem_pkg` | constants, transaction types, mask / bank / conflict helper functions for clients and testbenches |

## The slot model

A request describes a **window** of `NW` word slots (`NW = VEC_BYTES/BANK_BYTES`, plus one when the policy allows byte-misaligned starts). Slot k is word `w0 + k` for a
contiguous request (`w0 = addr / BANK_BYTES`), or the word of an element for strided / indexed requests. Per slot the AGU produces `need` (any enabled byte in the slot's
window mask), `bank` and `row`.

* **Issue stage S1** holds one request: `need`, `issued`, per-slot bank / row, the window data and byte enables. Each cycle, for each bank, the port presents its **lowest
  pending slot** that maps to that bank. The scheduler grants at most one candidate per bank. Granted slots are marked issued. S1 is released in the cycle its last pending slot
  is granted, and the next accepted request loads S1 in that same cycle: this is why one request per cycle is sustained when the slots hit distinct banks.
* A request whose slots collide on a bank simply needs one cycle per colliding slot. That **is** the split of a transaction across cycles; the slots of other banks go in the first cycle.
* **Completion queue** (`CQ_DEPTH` entries, circular, one entry per accepted request, allocated at acceptance): `we`, status, id, start offset, byte mask, accept timestamp,
  `need` and `got` slot masks, and the window data. Every granted slot (load or store) returns from its bank with the tag `{port, entry, slot}`, which sets `got[slot]` and, for loads,
  stores the word. An entry is complete when `got == need`; the head entry is presented when complete, so responses are in order even when a younger request completed first.
  Requests with an error or no enabled byte have `need = 0` and are complete at once (they never enter S1).
* **Merge** (response side): `window >> 8*offset`, bytes outside the request mask zeroed. Stale window words of never-accessed slots cannot leak because the mask zeroes them.

## Why this preserves unmodified bytes

A store drives each bank with the **window byte enables** (the request mask shifted by the start offset). Bytes with a 0 enable are not written by the SRAM
(`sf_sram_core` writes lane `l` only when `be[l]`); a slot with all enables 0 is not accessed at all. An errored request never reaches S1. The testbench checks, after every
phase, **every byte of every array against the byte model by reading the arrays directly** (not through the design's read path).

## Timing summary (cycle numbers relative to the accepting edge)

```
 accept (A)        S1 loaded, CQ entry written                      
 A+1               grant -> bank access begins (bank samples at the end of this cycle)
 A+1+L             bank result visible (L = READ_LATENCY)           
 A+2+L             window / got updated, response valid             -> handshake with an always-ready consumer = latency L+2
```
Extra bank collisions delay the last grant by one cycle each. The critical combinational paths are request -> AGU -> S1 (input side) and S1 -> candidate select -> arbiter ->
`req_ready` / bank address. No pipeline register separates the scheduler from the bank inputs (a deliberate latency / simplicity choice; a register there would add one cycle).

## Performance counters (`perf_o`, index = `SF_PC_*` in `sf_vspm_defs.svh`)

| counter | definition |
|---|---|
| `CYCLES` | cycles since `perf_clear_i` |
| `V_REQ / V_LD / V_ST / V_RSP` | vector requests accepted / loads / stores / responses delivered |
| `V_BYTES_LD / V_BYTES_ST` | **useful bytes**: mask popcount of error-free loads / stores |
| `V_ERR` | vector requests rejected with an error status |
| `V_SPLIT_REQ`, `V_ALIGN_XTRA` | requests that needed more word accesses than the same mask at offset 0, and the number of extra words (**alignment overhead**) |
| `V_WORD_ACC` | bank accesses granted to the vector port |
| `V_STALL_CONF` | cycles a request waited because **another slot of the same request** wanted the same bank (intra-request bank conflict) |
| `V_STALL_ARB` | cycles a request lost a bank to the DMA port |
| `V_REQ_BLOCKED`, `V_RSP_BP` | request offered and not accepted; response presented and not taken |
| `V_STARVE` | consumer ready, nothing deliverable, work outstanding (**lane starvation**) |
| `LAT_RD_*`, `LAT_WR_*` | sum / count / max of accept -> response-handshake cycles over loads / stores (includes consumer back-pressure) |
| `D_REQ`, `D_BYTES_RD / WR`, `D_WORD_ACC`, `D_STALL_ARB`, `D_REQ_BLOCKED`, `D_ERR` | the same for the DMA port (**DMA stalls**) |
| `ERR_RANGE / ALIGN / OWNER / BADOP` | error responses by type, both ports |
| `perf_bank_acc_o[b]` | accesses to bank b (**bank utilisation** = accesses / cycles) |
| `perf_bank_conf_o[b]` | cycles bank b was wanted by two ports, or by two slots of one request |

Counters saturate at all ones; `perf_clear_i` clears them synchronously. Each is checked against the testbench's own accounting (`tb_vspm` perf phase, `tb_bench`).
