# 07 - Verification

Numbers: `reports/SUMMARY.md` (generated). Commands: `sim/run_all.sh`, individually `sim/run_regress.py`, `sim/run_units.py`, `sim/run_integration.py`, `tools/mutate.py`, `sim/run_bench.py`, `syn/run_synth.py`.

## Method

* **Independent byte-array reference** (`ref_mem`, `predict_access` in `tb/tb_vspm.sv`). It is written byte by byte: every request byte has its own address, range / alignment / ownership are
  per-byte facts, the bank map uses `/` and `%`, and it knows nothing of slots, windows, completion queues or arbitration. A request's effect on the model is applied at the clock edge where the DUT accepts it.
* **One clocked agent** drives both ports, the ownership port and the checks in a single `always @(posedge clk)`, so ordering is deterministic and identical in Verilator and Icarus.
* **Checks in every phase**: every response (id, we, status, full data, order, exactly once), response stability under stall, no response without a request, nothing left in flight, the per-cycle tile hooks,
  and a **backdoor compare of every array byte** after every phase (read directly from the bank memories): this is what proves masked-off bytes and errored requests changed nothing.
* **Counters and latency** are checked against the testbench's own computation (isolated requests: expected `READ_LATENCY + 2 + busiest-bank excess` cycles, expected conflict / split / byte / per-bank / error-type counts).

## Brief section 12, item by item

| required | phase (`tb_vspm`) | also |
|---|---|---|
| 128-bit loads / stores | `aligned`, `back_to_back`; stage1 | all `v128` cases |
| 256-bit loads / stores | same, `VEC_BYTES=32` cases | `full256_*`, `stage1_aligned256`, `stage2_masks256` |
| FP32 element sequences | `fp32_elements` (NaN payloads, -0, denormals, infinities, a ramp) with literal pattern checks | `tb_lane_glue` (FP32 and 64-bit lanes) |
| byte-mask stores | `byte_masks`: one-hot, every tail length, random masks, partial final vectors | arrays compared directly |
| misaligned accesses | `misaligned`: every start offset, stripe / row boundaries, random bytes | policy A rejection in `align_vec_*`, `align_word_*` |
| cross-bank transactions | the same phase with `NB` 1 / 2 / 4 / 8 / 16, LOW / XOR / BLOCK | `nb1_*`, `map_*` cases |
| random vector addresses | `aligned` (random), `misaligned` (random bytes, some beyond the end), `backpressure` | |
| back-to-back operations | `back_to_back`: RAW / WAR / WAW chains with overlap, no gaps and with gaps | |
| read / write contention | `dma_ownership`, `ownership_change_under_traffic`, `shared_region_atomicity` | `tb_bench` DMA runs |
| reset | `reset_mid_traffic`: reset while requests are in flight; every byte old or new; works afterwards | |
| out-of-bounds | `out_of_bounds`: straddling, beyond, empty-mask outside, masked overhang | RANGE counted in the perf phase |

## Configuration matrix (`sim/run_regress.py`)

Staged runs `stage1 .. stage4` reproduce the requested order (aligned 128 -> masks / FP32 -> misaligned / back-pressure / reset -> DMA / ownership) with the same testbench. Then: 128 / 256 / 512-bit
vectors; 1 / 2 / 4 / 8 / 16 banks; LOW / XOR / BLOCK maps; reject and split policies; bank words of 4 / 8 / 16 bytes; strided-gather configurations (`GS_ES` 4 and 8); `READ_LATENCY` 1 / 2 / 3;
tiny and non-power-of-two completion queues; DMA beats of 4 / 8 / 16 / 32 bytes, DMA off, all three arbitration policies; 2 / 4 / 8 regions; poison initial contents; FPGA-BRAM and SKY130 stand-in backends;
different seeds. **Icarus 12** runs the same matrix (BACKEND 2 excluded: the vendored SKY130 adapter does not elaborate in Icarus).

## Other testbenches

* `tb_units`: bank map vs package, bijectivity, split / merge against a byte reference **exhaustively over every mask and offset** (16-byte vectors) and randomly (wider), package helpers.
* `tb_clouddma_int`: the real CloudDMA, see docs/06.
* `tb_lane_glue`: lane-masked FP32 / 64-bit beat streams, partial final beats, misaligned bases.
* `tb_bench`: reproducible workloads for the bandwidth report, with the analytical model check.

## Mutation testing (`tools/mutate.py`)

A hand-written list of single-bug mutants of the RTL (byte shift removed, mask forced, wrong slot, range / alignment / ownership checks removed or inverted, precedence swapped, bank maps broken, completion
queue overrun / pointer wrap, scheduler order reversed, response not held, DMA strobe ignored, ownership drain / block removed, counters wrong, latency regression ...). Each must make the testbench **fail**; a
surviving mutant is a hole in the test. The process found real holes. The first run killed 41 of 48 mutants (6 survived, 1 mutation pattern was invalid): no gather offsets that are negative from a non-zero base, no round-robin
fairness check, ownership never changed under live traffic (two survivors), almost no error requests in the counter phase, first-error registers never compared. All were closed by strengthening
the testbench; the next run (55 mutants) killed 54 and showed one more hole (nothing checked that the ports stop accepting while an ownership change is pending), which a new check closed.
The final result is in `reports/mutation.md`. A full kill count says nothing about faults nobody thought to inject.

## Findings made by the verification

* The first implementation answered `RANGE` before `ALIGN`; the independent model disagreed under the rejecting policies because a rejected request's window has no spare slot. The precedence is now
  explicit (BADOP > ALIGN > RANGE > OWNER) in RTL, model and docs/02.
* The first version of the benchmark treated a saturated DMA-priority run as a failure; it is a real starvation result and is now reported (`completed X of N`).
* The XOR bank map halves word-misaligned streams: not a bug, a measured property (docs/05).

## What is NOT verified

No formal proof (SymbiYosys is not available); simulation only, two-state in Verilator and four-state in Icarus with defined stimulus; no code-coverage tool was run; random phases are seeded
(three seeds in the matrix), not exhaustive; gate-level simulation, timing and X-propagation behaviour are not exercised; the vector engine's FP32 arithmetic and the existing tile LSU are not instantiated.
