# 08 - Integration and next actions

## Connecting the vector engine

* Operand beats: `opnd_a_i` etc. of `hpc_vector_array` are `NUM_LANES x 32` bits with lane l at `[32l +: 32]`: that is `v_rsp_rdata` / `v_req_wdata` with `VEC_BYTES = 4 * NUM_LANES`
  (16 -> 4 lanes, 32 -> 8 lanes, 64 -> 16 lanes).
* Result beats: `res_mask_o` (one bit per lane) -> `v_req_mask = lane_to_byte_mask(res_mask, 4)`; a vector of `VL` elements is `ceil(VL / NUM_LANES)` stores whose last mask is `array_vector_mask(VL, v, VEC_BYTES, 4)`.
  Masked-off lanes keep their memory; loads of masked lanes read 0 (give the array a per-lane mask only where that is wanted).
* Keep at most `CQ_DEPTH` requests in flight; responses are in order, so the id is only needed for debug. Hide the `READ_LATENCY + 2` cycle latency by issuing operand loads ahead of the array.
* `ev_spm_read_o / ev_spm_write_o / ev_spm_conflict_o` feed the tile's `SPM_READS / SPM_WRITES / SPM_CONFLICTS` counters (event definitions of Module 07).

## Not done, in order of importance

1. **A wide-port LSU.** `hpc_tile_lsu` issues word requests on P ports; to benefit from the wide port a new LSU must issue one `VEC_BYTES` request per beat. Not written; the lane-mask contract is tested
   with a model of the beat stream (`tb_lane_glue`), not with the real array.
2. **Top-level tile integration** (address window `SPM_BASE` subtraction, DataFabric adapter, the host window, command scheduler hazard rules). The DMA port is verified against CloudDMA only; the HPC
   `hpc_dma_spm_port` / `hpc_dma_adapter` were not instantiated.
3. **ECC / parity / MBIST** on the banks (reserved status `SF_ST_ECC_UE`); the 32-bit word makes SECDED awkward (39-bit stored words).
4. **Map-specific rotator** for the LOW map: the general slot-to-bank crossbar costs logic that grows with `slots x banks` (synthesis.md); a barrel rotator would be much smaller.
5. **Overlapping the tail of one request with the head of the next** (cross-request bank packing): a byte-misaligned stream on `NB = vector words` banks currently runs at half rate because requests do not overlap in S1.
   Per-bank order would make it safe (accesses to different banks never alias); not implemented.
6. Timing closure, an FPGA place-and-route run, power: none done; no clock frequency is claimed anywhere.
