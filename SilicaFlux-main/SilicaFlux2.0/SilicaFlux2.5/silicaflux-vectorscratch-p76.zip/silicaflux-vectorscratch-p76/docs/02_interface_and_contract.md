# 02 - Interface and contract

All handshakes are valid / ready. Reset `rst_n` is active low, **asynchronous assert**; release it synchronously (the module does not synchronise it).

## Vector port

| signal | dir | width | meaning |
|---|---|---|---|
| `v_req_valid / v_req_ready` | in / out | 1 | request handshake. The request payload must be held until accepted. `v_req_ready` depends only on registered state (never on `v_req_valid` or the payload) |
| `v_req_we` | in | 1 | 0 load, 1 store |
| `v_req_mode` | in | 2 | 0 CONTIG, 1 STRIDED, 2 INDEXED (1, 2 need `GS_EN`); 3 reserved. Anything else answers `SF_ST_BADOP` |
| `v_req_addr` | in | `AW` | byte address (CONTIG: first byte; STRIDED / INDEXED: base) |
| `v_req_stride` | in | `AW` | STRIDED: signed byte stride between elements |
| `v_req_idx` | in | `LANES*IDXW` | INDEXED: signed byte offsets, element l in `[l*IDXW +: IDXW]` (`LANES = VEC_BYTES / GS_ES`) |
| `v_req_mask` | in | `VEC_BYTES` | per-byte enable. Store: a 0 byte is never modified. Load: a 0 byte returns 0 |
| `v_req_wdata` | in | `8*VEC_BYTES` | byte j in `[8j +: 8]`; FP32 lane l in `[32l +: 32]` |
| `v_req_id` | in | `IDW` | returned with the response |
| `v_rsp_valid / v_rsp_ready` | out / in | 1 | response handshake. A presented response is **held unchanged** until accepted; `v_rsp_valid` does not depend on `v_rsp_ready` |
| `v_rsp_rdata` | out | `8*VEC_BYTES` | load data; **0** for stores, errors and masked-off bytes |
| `v_rsp_id / v_rsp_we / v_rsp_status` | out | `IDW / 1 / 3` | id, echo of `we`, `SF_ST_*` |

## DMA port (SFB2 single beat; same shape as `hpc_dma_spm_port` and the `sm_*` master of `sfd_clouddma`)

`d_req_valid/ready`, `d_req_write`, `d_req_addr`, `d_req_wdata` (`8*DMA_BYTES`), `d_req_wstrb` (`DMA_BYTES`, byte strobes; a read always reads the whole beat),
`d_rsp_valid/ready`, `d_rsp_rdata`, `d_rsp_error`, `d_rsp_err_code` (`SF_ST_*`). Addresses must be **beat aligned** (`addr % DMA_BYTES == 0`, else `SF_ST_ALIGN`).
One response per request, in order, held while stalled. A write response means the data is committed in the array (the property CloudDMA's `done_commit` relies on).

## Ownership, status, performance

| signal | meaning |
|---|---|
| `own_req_valid/ready`, `own_req_rgn`, `own_req_val` | change the owner of one region (0 SHARED, 1 VEC, 2 DMA; 3 reserved). `own_req_ready` is low while a change is pending |
| `own_ack_o`, `own_err_o`, `own_state_o` | pulse when the change took effect (`own_err_o` as well when the value was the reserved 3, which changes nothing); 2 bits per region |
| `busy_o` | a request is in flight on either port |
| `err_sticky_o`, `err_code_o`, `err_addr_o`, `err_port_o`, `err_cnt_o`, `err_clear_i` | first request rejected with an error status since the last clear: its status, request address and port (0 vector, 1 DMA), plus the number of such requests (counted when the request is accepted, so equal to the number of error responses once they are delivered) |
| `perf_o`, `perf_bank_acc_o`, `perf_bank_conf_o`, `perf_clear_i` | counters (docs/03 table) |
| `ev_spm_read_o`, `ev_spm_write_o`, `ev_spm_conflict_o` | 2-bit event counts per cycle (accepted reads / writes of both ports; ports that lost bank arbitration) for `hpc_perf_counters` |

## Status codes and their precedence

`SF_ST_OK 0`, `SF_ST_RANGE 1`, `SF_ST_ALIGN 2`, `SF_ST_OWNER 4`, `SF_ST_BADOP 5` (values from `sf_sram_defs.svh`; 3 = ECC_UE is reserved and never produced).

Precedence when several apply: **BADOP > ALIGN > RANGE > OWNER**. This differs from `sf_sram_controller` (RANGE over ALIGN) on purpose: ALIGN is a property of the
address alone, whereas RANGE and OWNER are properties of the words a request touches, and under a rejecting alignment policy the words of a misaligned request are not
defined (its window has no spare slot). Found by the testbench: the independent byte-level model disagreed with the first implementation until the rule was made explicit.

* **RANGE**: some *needed* word is outside `[0, NB*DEPTH*BANK_BYTES)`. A word whose bytes are all masked off is not needed, so a partial final vector may overhang the end of
  the array as long as the overhanging bytes are masked off. Negative and wrapped element addresses are RANGE errors (address arithmetic is wider than `AW`).
* **ALIGN**: CONTIG with policy VEC / WORD and a violating address; STRIDED / INDEXED with an *active* element whose address is not a multiple of `GS_ES`; a DMA beat not
  beat-aligned. Never raised for policy ANY with CONTIG.
* **OWNER**: a needed word in a region owned by the other port.
* **An errored request has no side effect at all**: no bank is accessed, nothing is written, the response comes in order with `rdata = 0`.

## Ordering and atomicity contract

| # | rule |
|---|---|
| O1 | Each port answers every accepted request exactly once, **in acceptance order**, including error responses. |
| O2 | Per port, memory effects follow program order byte-exactly: a load accepted after a store reads the stored bytes (RAW), a store after a load does not affect it (WAR), the later of two stores wins (WAW). Mechanism: the issue stage holds one request, so all accesses of request i to every bank precede all of request i+1's. |
| O3 | A store response means the data is **committed in the array**. |
| O4 | One bank-word access is atomic (all enabled bytes of a word change together; no byte tearing). A multi-word request is **not** atomic with respect to the other port in a SHARED region: it may observe, or be observed between, word accesses of the other port (word tearing). No lock exists. |
| O5 | Across ports there is no order in a SHARED region. In an exclusively owned region the ownership hand-over gives the order: when `own_ack_o` is seen, every earlier access of both ports is complete, answered and committed, and no request has been accepted under the new ownership yet. |
| O6 | Overlapping stores inside one request (scatter with duplicate addresses): **the highest lane wins** (slots of one bank are granted lowest slot first, so lane order is write order). Gathers with duplicate addresses simply read the same word several times. |
| O7 | Masked-off bytes: stores never modify them; loads return 0 for them; a word with every byte masked off is not accessed (no bank cycle, no range / ownership check). |
| O8 | Back-pressure: when the completion queue is full or an ownership change is pending, `req_ready` is low and nothing is lost. A consumer that never accepts responses eventually blocks the port and stalls an ownership change. |

## Reset

`rst_n` clears every control register and counter. **The memory arrays are never reset** (as in `sf_sram_core`): contents survive a reset, and after power-up they are undefined
(simulation `SIM_INIT`: 0 X, 1 zero, 2 poison pattern). A request in flight at reset is dropped without a response; a store accepted shortly before may or may not have reached
the array, **byte by byte either old or new** (tested with stores to disjoint addresses; overlapping in-flight stores were not tested). Software must treat an interrupted store as unknown.
