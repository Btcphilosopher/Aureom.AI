# 00 - Repository audit and reuse decisions

Repository `btcphilosopher/Aureom.AI`, branch `claude/festive-keller-ssrx7s`. The SilicaFlux material is stored as archives (`.zip`) under
`SilicaFlux-main/`; **every archive named below was extracted into a scratch directory and read; nothing in the repository was modified and nothing was
committed**. Tools available while this package was built: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, Python 3.13 (the same versions the earlier
SilicaFlux packages report). Not available: Vivado, Quartus, OpenROAD, a Liberty flow, SymbiYosys.

## 1 What exists

| Asset (archive in `SilicaFlux-main/...`) | What it is | Relevance here |
|---|---|---|
| `SilicaFlux2.0/silicaflux-hpc-m02-vector-lane.zip` - `hpc_vector_lane` | one FP32 / INT32 lane, valid/ready, tags, in-order completion | arithmetic only; memory is raw bits, no dependency |
| `SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m03-vector-array.zip` - `hpc_vector_array` | `NUM_LANES` (1-16) x 32-bit lanes; operand / result beats `[32l +: 32]`; per-lane `res_mask`; completion queue; reduction | **defines the data layout this scratchpad adopts**: lane l at bits `[32l +: 32]`, one mask bit per lane (see `sf_vmem_pkg::lane_to_byte_mask`). Not instantiated (FP32 arithmetic is out of scope); the beat contract is exercised by `tb/tb_lane_glue.sv` |
| `...hpc-m04-scratchpad.zip` - `hpc_scratchpad` | multi-port banked **word-wide** scratchpad (1RW / 1R1W / 2RW banks, queues, parity) | alternative memory for the tile's word-granular LSU; port-per-word, no wide-vector port, no byte-misaligned access, no vector byte masks |
| `...hpc-m05-dma-adapter.zip` - `hpc_dma_adapter`, `hpc_dma_spm_port` | SFB2 single-beat DMA -> scratchpad port | its beat shape (valid/ready, `write/addr/wdata/wstrb`, one in-order response, `rsp_error`) is the shape of this scratchpad's DMA port. **Not instantiated here** (only CloudDMA is) |
| `...hpc-m07-perf-counters.zip` - `hpc_perf_counters` | tile-level counters (`SPM_READS`, `SPM_WRITES`, `SPM_CONFLICTS`, `VEC_STALL`, ...) | `ev_spm_read_o / ev_spm_write_o / ev_spm_conflict_o` follow its event definitions (accepted read / write per port, port-cycles lost bank arbitration) |
| `...hpc-m08-tile.zip` - `hpc_tile_lsu` | streaming vector LSU: **one scratchpad word (`DW` bits, default 32) per request on each of P ports**, element groups, FIFO per group | the existing "vector load/store hardware". A vector beat is split into word requests across P ports; a wide port (`VEC_BYTES` per request, any byte offset, per-byte mask) is what this package adds. Re-wiring an LSU onto it is **not done** (docs/08) |
| `silicaflux-memorycore-sram.zip` - `sf_sram_core`, `sf_sram_macro_wrapper` (+ FPGA-BRAM and SKY130 backends), `sf_sram_defs.svh` | verified single-port synchronous SRAM with byte enables; one port list over three backends; shared constants | **reused byte-identically** as the bank storage and status-code header (`third_party/memorycore/`, SHA-256 manifest) |
| same zip - `sf_sram_bank`, `sf_sram_controller` | 4 banks x 16 B lines, multi-master arbiter, in-order responses, optional SECDED (137,128) | **not reused** (see 2) |
| same zip - `sf_vector_scratchpad` | the previous-generation front end on the controller: sub-word / 1-2-4-line accesses, DMA burst engine | **superseded** by this package; see 3 |
| `silicaflux-cloudruntime-0.1.0.zip` - `sfd_clouddma` | the CloudDMA channel: host memory <-> local SRAM, SFB2 single-beat, partial strobe on the last beat | **used unmodified** in `tb/tb_clouddma_int.sv` |
| `silicaflux-datafabric*.zip`, `silicaflux-sramlib` | SFB2 bus, crossbar, DMA, SRAM wrapper library | context; SFB2 single-beat is the DMA-port protocol |

Not found anywhere in the repository: a wide-vector LSU, a split / merge (misaligned) memory datapath, vector byte-mask stores with tail handling, a gather /
scatter memory port, per-bank utilisation counters, a memory-level ownership scheme for a vector scratchpad.

## 2 Why the existing banks / controller were not reused

* `sf_sram_controller` / `sf_sram_bank` interleave **16-byte lines**: a 16-byte vector is exactly one bank access. That is efficient but means a 4-byte access wastes
  75% of the bank (its `KNOWN_LIMITATIONS` item 16) and a byte-misaligned 16-byte vector always needs two line accesses. Narrow (32-bit) banks give the independent
  per-word bank access, the lane-to-bank mapping and the macro-friendly width this brief asks for; a 16-byte-bank configuration is still available
  (`BANK_BYTES = 16`) and is measured in the bandwidth report.
* The controller's reorder slots are per **master**; the vector port here needs several accesses of ONE request in flight, scheduled across banks, which the
  completion queue with per-slot `need / got` masks does directly.
* SECDED (137,128) is not integrated: the stored word would be 39 bits for a 32-bit bank, which does not tile onto 36-bit block RAM (docs/05).

## 3 Relationship to the existing `sf_vector_scratchpad`

The file name requested for this project is the same as an older module in the MemoryCore package, with a different port list. From reading its source header:

| | MemoryCore `sf_vector_scratchpad` | this package |
|---|---|---|
| memory | 16-byte lines through `sf_sram_controller` (NB x 1024 x 128 b) | NB single-port banks of `BANK_BYTES` (32-bit default), any `VEC_BYTES` |
| vector width | 128 / 256 / 512 b as 1 / 2 / 4 consecutive lines | any power of two `VEC_BYTES >= BANK_BYTES` (tested 16 / 32 / 64) |
| misaligned | rejects (its header: "cross-line splitting is not implemented") | policy A reject **or** policy B split / merge |
| vector byte mask | sub-line size + offset only; multi-line vectors write whole lines | arbitrary per-byte mask on every vector access, tail masks, masked loads |
| strided / gather / scatter | none | optional (`GS_EN`) |
| DMA | built-in burst engine on its own controller port | SFB2 single-beat port + region ownership + per-bank arbitration |
| counters | one conflict counter | 33 counters + per-bank accesses / conflicts + latency |

**Do not compile both modules in one design** (same module name). They are not drop-in replacements. No bandwidth comparison with the old module was measured:
the comparison above is from its source, not from a run.

## 4 Reuse decisions in one table

| Need | Decision |
|---|---|
| bank storage, three backends, byte enables | **reused unmodified**: `sf_sram_macro_wrapper` -> `sf_sram_core` / `sf_sram_fpga_bram` / `sf_sram_asic_sky130` |
| status codes (`SF_ST_*`), `SF_CFG_FATAL`, `SF_CHK` | **reused**: `sf_sram_defs.svh` |
| data layout of the vector engine (lane l at `[32l +: 32]`, per-lane mask) | **adopted** from `hpc_vector_array` |
| DMA port protocol | **adopted** SFB2 single-beat, as in `hpc_dma_spm_port` / `sfd_clouddma`; verified against the real CloudDMA |
| tile counters | **compatible event hooks** for `hpc_perf_counters` |
| bank arbiter, scheduler, split / merge, AGU, completion queue, ownership, counters | **new** (`rtl/sf_vspm_*.sv`) |
| ECC / MBIST | not integrated (docs/KNOWN_LIMITATIONS.md) |
