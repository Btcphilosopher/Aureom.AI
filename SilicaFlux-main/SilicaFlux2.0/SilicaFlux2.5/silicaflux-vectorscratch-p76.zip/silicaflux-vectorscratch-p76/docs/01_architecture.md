# 01 - Architecture

```
                     vector port                                         DMA port (SFB2 single beat)
          v_req_* / v_rsp_*  (VEC_BYTES per request)              d_req_* / d_rsp_*  (DMA_BYTES per beat, beat aligned)
                 |                                                              |
        +--------v---------+                                          +---------v--------+
        |   sf_vspm_port   |  accept -> split -> AGU -> issue stage   |   sf_vspm_port   |   (same module, PORT = 1,
        |   (PORT = 0)     |  completion queue (in order) -> merge    |   (PORT = 1)     |    alignment policy "beat")
        +--------+---------+                                          +---------+--------+
          one candidate per bank per cycle                              one candidate per bank per cycle
                 |                                                              |
        +--------v--------------------------------------------------------------v--------+
        |                        sf_vspm_bank_sched   (per-bank arbiter + routing)        |
        +----+----------------+----------------+----------------+-------------------------+
             | bank 0         | bank 1         | bank 2   ...   | bank NB-1               sf_vspm_banks
        +----v-----+     +----v-----+     +----v-----+     +----v-----+                   NB x sf_sram_macro_wrapper
        | 1RW SRAM |     | 1RW SRAM |     | 1RW SRAM |     | 1RW SRAM |                   (DEPTH x BANK_BYTES each)
        +----------+     +----------+     +----------+     +----------+
   sf_vspm_own: region owner SHARED / VEC / DMA, quiesced change      sf_vspm_perf: 33 counters + per-bank counters
```

## Organisation

* **NB banks**, each a single-port SRAM of `DEPTH` rows x `BANK_BYTES` bytes (default 4 x 256 x 4 B = 4 KiB). One access per bank per cycle, no bypass.
* The byte address space `[0, NB*DEPTH*BANK_BYTES)` is cut into **words** of `BANK_BYTES`; word `w` lives at `(bank, row) = BANK_MAP(w)` (docs/05).
* A vector request of `VEC_BYTES` bytes covers `VEC_BYTES / BANK_BYTES` words, or one more when it starts inside a word. Each word is a **slot** of the request.
  Slots are the unit of everything else: range / ownership checks, bank selection, scheduling, completion.
* **Why narrow banks.** The vector width (16 / 32 / 64 B ...) and the SRAM width are independent: a wider vector just uses more banks in parallel. 32-bit words
  match the FP32 element, tile exactly onto 32-bit macros and 36-bit block RAM, and let a byte-misaligned vector use adjacent banks. The cost is that logic grows
  with the bank count (docs/05, synthesis.md). 16-byte banks are a supported configuration.
* **Raw bits.** Nothing in the datapath interprets data. A NaN payload, `-0`, a denormal or an arbitrary 64-bit pattern round-trips unchanged (tested).

## Request life cycle (the seven stages of the brief)

| # | stage | where | cycle |
|---|---|---|---|
| 1 | request acceptance | `sf_vspm_port`: `req_valid && req_ready` (ready = completion-queue credit and issue stage free-or-freeing and not blocked by an ownership change) | A |
| 2 | address generation | `sf_vspm_agu` + `sf_vspm_split` + `sf_vspm_bankmap`, combinational on the request, registered into the issue stage S1 and a completion-queue entry | A |
| 3 | bank routing | issue stage -> one candidate per bank (lowest pending slot of that bank) -> `sf_vspm_bank_sched` grants one port per bank | A+1 .. |
| 4 | memory access | `sf_sram_macro_wrapper` (`READ_LATENCY` cycles); every granted slot, load or store, returns once with its tag `{port, entry, slot}` | grant + `READ_LATENCY` |
| 5 | alignment (optional) | `sf_vspm_merge`: byte shift by the start offset, masked-off bytes zeroed | at the response |
| 6 | response formatting | status, id, `we`, data (0 for stores / errors) | at the response |
| 7 | completion | the oldest completion-queue entry with `got == need` is presented; popped on `rsp_valid && rsp_ready` | A + `READ_LATENCY` + 2 |

Latency for an isolated request whose slots hit distinct banks is `READ_LATENCY + 2` cycles from the accepting edge to the response handshake; each additional access
to the busiest bank adds one cycle; an errored or empty-mask request completes in 1 cycle. The formula is asserted per request in the testbench.

## Parameters

| parameter | default | meaning |
|---|---|---|
| `VEC_BYTES` | 16 | vector bytes: 16 = 128 b, 32 = 256 b, 64 = 512 b ... (power of two >= `BANK_BYTES`) |
| `BANK_BYTES` | 4 | bank word bytes (power of two >= 2); the SRAM data width |
| `NB`, `DEPTH` | 4, 256 | banks and rows per bank (powers of two); capacity `NB*DEPTH*BANK_BYTES` |
| `BANK_MAP` | LOW | LOW / XOR / BLOCK |
| `ALIGN_POLICY` | ANY | VEC (reject unless `addr % VEC_BYTES == 0`), WORD (reject unless `addr % BANK_BYTES == 0`), ANY (split / merge) |
| `GS_EN`, `GS_ES`, `IDXW` | 0, 4, 32 | strided / indexed access, element bytes (`>= BANK_BYTES`), index width |
| `READ_LATENCY`, `BACKEND`, `SIM_INIT` | 1, 0, 2 | bank read latency; 0 behavioural / 1 FPGA BRAM template / 2 SKY130 macros (needs latency >= 2); simulation initial contents (2 = poison) |
| `CQ_DEPTH` | 8 | completion-queue entries of the vector port (back-pressure buffer; full rate needs about `READ_LATENCY + 3`) |
| `DMA_EN`, `DMA_BYTES`, `DMA_CQ_DEPTH` | 1, 16, 4 | DMA port presence, beat bytes (power of two >= `BANK_BYTES`), its queue |
| `ARB_POLICY` | RR | per-bank arbitration: VEC priority / DMA priority / round robin |
| `NRGN`, `OWN_RESET` | 4, VEC | ownership regions (power of two); reset owner |
| `PERF_EN`, `CNT_W`, `LATW` | 1, 32, 16 | counters present, counter width, latency-stamp width |

Elaboration checks (`SF_CFG_FATAL`) reject non-power-of-two sizes, `GS_ES < BANK_BYTES`, `AW` too small for the aperture, etc.

## Scaling and cost

The scheduler and the slot-to-bank crossbar are general (they work for any bank map and for gather), so their logic grows roughly with `slots x banks`: the
generic-gate count of the port is 13 k cells at 128-bit / 4 banks, 37 k at 256-bit / 8 banks (`reports/synthesis.md`). A map-specific rotator would be smaller for
the LOW map; that optimisation is **not done** (docs/KNOWN_LIMITATIONS.md). The 33 performance counters account for about 28% of the generic logic cells and a third of the flip-flops of the default
128-bit design (26 605 -> 19 197 other cells, 4 203 -> 2 779 flip-flops with `PERF_EN = 0`) and can be removed with `PERF_EN = 0`.
