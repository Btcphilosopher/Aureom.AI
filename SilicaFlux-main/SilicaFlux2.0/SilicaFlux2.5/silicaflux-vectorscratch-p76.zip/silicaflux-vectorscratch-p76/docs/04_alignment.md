# 04 - Alignment: policies, split / merge, partial vectors

## The two policies (parameter `ALIGN_POLICY`)

| value | policy | rule | cost |
|---|---|---|---|
| `VEC` | **A, reject** | `addr % VEC_BYTES == 0`, else `SF_ST_ALIGN` | no shifter, no extra slot |
| `WORD` | **A, reject** | `addr % BANK_BYTES == 0`, else `SF_ST_ALIGN` | word-misaligned (but word-aligned) vectors are rotated across banks by the bank map only; no byte shifter |
| `ANY` | **B, split / merge** | any byte address | one extra slot, a byte shifter on the store path (`sf_vspm_split`) and on the load path (`sf_vspm_merge`) |

A rejected request is answered in order with `SF_ST_ALIGN` and **has no effect**. The DMA port always uses "beat aligned" (`addr % DMA_BYTES == 0`).

## Split / merge datapath (policy ANY)

With `off = addr % BANK_BYTES` and `w0 = addr / BANK_BYTES`, the request is embedded in a **word-aligned window** of `NW = VEC_BYTES/BANK_BYTES + 1` words starting at word `w0`:

```
 vector byte j  (0 .. VEC_BYTES-1)  <->  window byte off + j        window word k = window bytes [k*BB, k*BB+BB)  = memory word w0 + k
 store : window data = wdata << 8*off ,  window enables = mask << off          (sf_vspm_split)
 load  : rdata[j]    = mask[j] ? window[off + j] : 0                           (sf_vspm_merge)
```

Example: 16-byte vector, 4-byte words, 4 banks, LOW map, `addr = 0x23` (`off = 3`, `w0 = 8`), full mask:

| slot | word | bank | window bytes | vector bytes |
|---|---|---|---|---|
| 0 | 8 | 0 | 0..3 | - (byte 3 -> vector byte 0) |
| 1 | 9 | 1 | 4..7 | 1..4 |
| 2 | 10 | 2 | 8..11 | 5..8 |
| 3 | 11 | 3 | 12..15 | 9..12 |
| 4 | 12 | **0** | 16..19 | 13..15 |

Slots 0 and 4 collide on bank 0: the first four are granted in cycle 1, slot 4 in cycle 2 (**two cycles, half rate**). With 8 banks slot 4 sits on bank 4 and all five go in one
cycle. The enables of slot 0 are `1000` (only byte 3 of the word is written), those of slot 4 `0111`: the other bytes of both words are untouched. A split store is performed
as separate word accesses of one request; no other access to those words can interleave inside the same port (docs/02 O2), and the response is sent only after every slot
was written.

A slot whose window enables are all zero (a word the masked request does not reach) is **not accessed**. This is why a vector that starts at byte 0 of a word with a mask of
3 bytes touches one word, and why masked-off bytes beyond the end of the array raise no range error.

## Crossing words, banks, rows

Crossing a word boundary means using the next slot; crossing a bank boundary means the next slot is in the next bank (LOW), a bank selected by the XOR key (XOR) or the same
bank (BLOCK); crossing the end of a row is the same mechanism with `row + 1`. All of these are exercised by the testbench for every start offset from 0 to
`VEC_BYTES + 2*BANK_BYTES` and at the stripe and row boundaries (`ph_misaligned`), against the byte model, with the arrays compared directly afterwards. Crossing the end of the
aperture is a RANGE error unless the overhanging bytes are masked off.

## Partial vectors and tail masks

`v_req_mask` is per byte. The array's lane mask maps through `sf_vmem_pkg::lane_to_byte_mask(lane_mask, elem_bytes)` (FP32: 4 bytes per lane, 64-bit element: 8). A vector
loop over `n` elements uses `array_vector_mask(n, v, VEC_BYTES, elem_bytes)` for vector `v`: all ones except the last, which enables only the remaining elements. Properties,
all tested: masked stores never modify disabled bytes (byte-exact whole-array compare), masked loads return 0 in disabled bytes, a zero mask is an acknowledged no-op (1 cycle, no
bank access), a tail mask costs no extra cycles (the stream of partial final vectors in the bandwidth report runs at one request per cycle).

## 64-bit elements

The memory is byte-oriented, so 64-bit elements need no special datapath: a 64-bit element is two adjacent words, always in two different banks under LOW. Strided / indexed
elements may be `GS_ES = 8` bytes (two slots per element). `tb_lane_glue` runs 64-bit element beats with per-lane masks through the vector port.
