# Known limitations (read before relying on anything)

## Not claimed / not done
1. **No silicon, timing, power or area data.** Every number is RTL simulation, a Yosys inference result or a counted macro instance. Generic-gate counts are not area. No clock frequency or GB/s figure is given.
2. **Not ASIC-ready.** The SKY130 backend is a structural adapter around a stand-in model (inherited from MemoryCore); only macro counts are reported. No Liberty / LEF / GDS / SPICE view exists in the repository.
3. **FPGA results are Yosys inference only** (`synth_xilinx`): no Vivado, no place-and-route, no timing.
4. **No formal verification.** Simulation (Verilator 5.020, Icarus 12.0) plus mutation testing of the testbench.
5. **ECC / parity / MBIST not integrated** (status code reserved).
6. **The real FP32 vector array and the existing tile LSU are not instantiated**; `hpc_dma_spm_port` was not used (CloudDMA was). No top-level integration.
7. Not compared by measurement with the older MemoryCore `sf_vector_scratchpad` (same module name, different ports; do not compile both).

## Behavioural limits
8. **Single-port banks.** Throughput is bounded by the busiest bank; there is no multi-port, no write-combining, no bypass. Byte-misaligned vectors run at half rate when `NB` equals the number of vector words (needs `NB >= words + 1`).
9. **One request in the issue stage per port**: no overlap between the tail of one request and the head of the next (docs/08).
10. **Cross-port atomicity is per bank word**; there are no locks and no atomic read-modify-write. SHARED regions can show word tearing between the ports.
11. **Ownership change pauses both ports** until every accepted request has been answered; it needs the consumers to take their responses. Ownership is not a security feature.
12. **Strided / indexed elements must be at least one bank word** and aligned to their size; no sub-word elements, no 2-D accesses.
13. **Reset**: arrays are not cleared; in-flight stores are byte-wise old-or-new (tested for disjoint stores only).
14. **XOR bank map is not universally better** than LOW (docs/05); BLOCK is for isolation only.
15. **Logic cost scales with `slots x banks`** (e.g. 94 k generic cells for a 256-bit / 16-bank design vs 26.6 k for 128-bit / 4 banks, full feature set).
16. **Latency is `READ_LATENCY + 2`** with no register between scheduler and banks; adding one for timing would change every latency number and the testbench's exact-latency checks.
17. Counters saturate; `LATW` (default 16) wraps the latency stamp, so a single request must complete within 2^16 cycles to be measured correctly.

## Tool caveats
18. Yosys 0.33 does not accept `int'(x)` casts, packages in parameter lists, or declarations inside procedural blocks; the RTL uses sized casts (`32'(x)`), a `` `define `` header, and module-level `integer`s. The package `sf_vmem_pkg` is for clients and testbenches, not read by the RTL.
19. Verilator 5.020 and Icarus 12.0 are the only simulators used. The vendored SKY130 adapter does not elaborate in Icarus (BACKEND 2 is Verilator only).
20. Random phases use a fixed xorshift sequence per seed; three seeds are in the matrix, which is a sample, not a proof.
