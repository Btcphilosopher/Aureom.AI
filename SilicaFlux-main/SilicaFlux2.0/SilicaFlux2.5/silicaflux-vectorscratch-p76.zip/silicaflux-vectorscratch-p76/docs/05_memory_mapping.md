# 05 - Bank mapping and mapping to real memories

## Word -> bank / row

`w = addr / BANK_BYTES` (word index), `NBW = log2 NB`, `RW = log2 DEPTH`:

| `BANK_MAP` | bank | row | use |
|---|---|---|---|
| LOW | `w mod NB` | `w / NB` | contiguous vectors: the words of one vector sit in distinct banks as long as `NB >=` the number of words |
| XOR | `(w mod NB) xor ((w / NB) mod NB)` | `w / NB` | breaks power-of-two strides (a stride of `NB` words hits one bank under LOW, all banks under XOR) |
| BLOCK | `w / DEPTH` | `w mod DEPTH` | each bank is a contiguous region: isolation (give a DMA buffer its own bank), and the deliberate worst case for a contiguous vector |

All three are **bijections** (every `(bank,row)` holds exactly one word): verified exhaustively against the package functions in `tb_units` (U2). `NB` and `DEPTH` must be
powers of two.

**Lane-to-bank mapping.** For an aligned contiguous vector with LOW mapping, lane l (FP32, 4 bytes) of the vector at word `w0` is word `w0 + l`, i.e. bank `(w0 + l) mod NB`: a vector
that starts at a multiple of `NB` words has lane l in bank l; otherwise the lanes are rotated, which the slot / crossbar structure handles with no extra cycle. The same function is
available to software and models: `sf_vmem_pkg::addr_bank`, `bank_cycles` (cycles a given access needs on the banks), `words_touched`.

**Measured trade-off (bandwidth report, section 3):** XOR is *worse* than LOW for word-misaligned contiguous streams (a vector that straddles a row boundary sees two XOR keys, so two
of its words can land on one bank: half rate in the 128-bit / 4-bank case) and better for stride-`NB` patterns. There is no universally best map.

## Choosing `NB`, `BANK_BYTES`

| goal | rule (LOW map, 32-bit banks) |
|---|---|
| aligned (or word-aligned) vectors at one per cycle | `NB >= VEC_BYTES / BANK_BYTES` |
| byte-misaligned vectors at one per cycle too | `NB >= VEC_BYTES / BANK_BYTES + 1` (otherwise exactly half rate when `NB = VEC_BYTES/BANK_BYTES`) |
| read + write + DMA concurrently | bank bandwidth shared: `NB * BANK_BYTES` bytes per cycle in total, DMA beats use `DMA_BYTES / BANK_BYTES` banks |

These rules are checked against the measurements by `tools/make_report.py` (it refuses to print them if the data disagree).

## Do not assume the width maps efficiently

The bank word width (`BANK_BYTES`) is the SRAM data width and is independent of the vector width. Same total capacity, different shapes, from `reports/synthesis.md`
(Yosys 0.33 inference results, **not** place-and-route):

**Xilinx 7-series block RAM (`synth_xilinx -family xc7`)** - 16 KiB total (stored data bits / block-RAM data bits):

| shape | RAMB36 | RAMB18 | efficiency |
|---|---:|---:|---:|
| 4 banks x 1024 x 32 b (128-bit vector) | 4 | 0 | 100% |
| 8 banks x 512 x 32 b (128 / 256-bit) | 0 | 8 | 100% |
| 4 banks x 512 x 64 b (256-bit vector) | 4 | 0 | 100% |
| 4 banks x 256 x 128 b (16-byte banks) | 8 | 0 | **50%** |
| 16 banks x 256 x 32 b (512-bit vector) | 0 | 16 | **50%** |
| 4 banks x 256 x 32 b (4 KiB) | 0 | 4 | **50%** |
| 4 banks x 64 x 32 b (1 KiB) | 0 | 4 | **12.5%** |

Wide words (128 b) need several block RAMs side by side; many shallow banks (many banks, small capacity) waste the depth of each block RAM. More banks buys bandwidth and costs
block-RAM fragmentation: at small capacities the bank count, not the capacity, decides the block-RAM count.

**SKY130 OpenRAM macro** `sky130_sram_1kbyte_1rw1r_32x256_8` (32 b x 256 words, 4 byte masks, 8 Kb) via the existing structural tiling adapter - 4 banks x 256 x 32 b: 4 macros, 100%;
4 banks x 1024 x 32 b: 16 macros, 100%; 4 banks x 256 x 128 b: 16 macros, 100%; 4 banks x 64 x 32 b: 4 macros, **25%** (a 256-row macro for 64 rows). The 32-bit bank word is exactly the
macro word, which is the reason it is the default. These are macro **counts** from a pin-only black box; no vendor model, Liberty, LEF or area exists in the repository (see the MemoryCore
package's `physical/asic_readiness.md`), and the stand-in simulation model proves structure only. BACKEND 2 needs `READ_LATENCY >= 2` (the macro output is not held).

**ECC.** `sf_sram_bank` with SECDED would store `32 + 7 = 39` bits per 32-bit word, which does not fit a 36-bit block RAM port and needs a read-modify-write for byte-masked stores
(`KNOWN_LIMITATIONS` of MemoryCore, item 11). ECC is therefore **not integrated** here; `SF_ST_ECC_UE (3)` is reserved in the status field for it.
