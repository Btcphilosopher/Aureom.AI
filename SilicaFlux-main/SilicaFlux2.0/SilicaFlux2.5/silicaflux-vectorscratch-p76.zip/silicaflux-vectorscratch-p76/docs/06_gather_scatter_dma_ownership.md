# 06 - Strided / gather / scatter, DMA coordination, ownership

## Strided, gather and scatter (optional: `GS_EN = 1`)

Implemented only after contiguous access was verified (the staged runs `stage1 .. stage4` precede the `gs_*` cases in `sim/run_regress.py`). Same port, same pipeline, same completion
queue; the only differences are in the AGU.

* `v_req_mode = 1` (STRIDED): element l of `GS_ES` bytes at `addr + l * stride` (signed stride; stride 0 broadcasts one element).
* `v_req_mode = 2` (INDEXED): element l at `addr + sext(idx[l])`. A load is a **gather**, a store a **scatter**.
* The element size `GS_ES` is a power of two, `BANK_BYTES <= GS_ES <= VEC_BYTES`. An element spans `GS_ES / BANK_BYTES` slots (FP32 in 32-bit banks: one slot, 64-bit: two).
  Elements smaller than a bank word are **not supported** (elaboration error): that would need a sub-word lane shifter per element.
* Each *active* element (any enabled mask byte in its group) must be `GS_ES`-aligned, else `SF_ST_ALIGN` for the whole request; any needed word outside the aperture or in a foreign region
  is `RANGE` / `OWNER` for the whole request; **an errored request touches nothing**.
* Data and mask use the same layout as a contiguous vector (element l at bytes `[l*GS_ES +: GS_ES]`); the mask refines per byte inside an element. The response of a gather is that layout,
  masked bytes 0.
* **Overlapping accesses.** Slots of one bank are granted in slot order, so lane order is write order: for a scatter with duplicate addresses **the highest lane wins**, deterministically
  (the model applies lanes in ascending order; `ph_scatter_overlap` checks literal expectations). Gathers with duplicates read the word once per lane. Relative to other requests the usual
  per-port program order (docs/02 O2) applies, so a gather after a scatter sees the scatter.
* Cost: a request needs as many cycles as its busiest bank has slots; measured in the bandwidth report (stride 1 element: conflict free; stride `NB` words: all lanes on one bank under LOW,
  conflict free under XOR; random gathers behave like random bank loads).

Not provided: byte-granular (sub-word) elements, 2-D / segment accesses, atomic read-modify-write, scatter-add.

## DMA port

The DMA port is a second instance of `sf_vspm_port` with the alignment policy "beat aligned". The SFB2 single-beat signals map one to one:

| CloudDMA `sm_*` | scratchpad DMA port |
|---|---|
| `sm_req_valid / ready / write / addr / wdata / wstrb` | `d_req_valid / ready / write / addr / wdata / wstrb` |
| `sm_rsp_valid / ready / rdata / error` | `d_rsp_valid / ready / rdata / error` (+ `d_rsp_err_code`) |

`DMA_BYTES` is the beat size (4 for CloudDMA's default `DW = 32`; 16 or more for a wider engine). A **partial strobe** (CloudDMA's ragged last beat) writes exactly the strobed bytes. Verified
against the **real, unmodified `sfd_clouddma`** in `tb/tb_clouddma_int.sv`: H2D and D2H transfers of ragged lengths (1 to 255 bytes, many ending inside a 4-byte beat, long ones clipped to the region), unmodified bytes preserved in both the
scratchpad and the host buffer, and the three error paths (foreign region, outside the aperture, misaligned address) reported as `ERR_SRAM_RESP` with no side effect anywhere.

## Arbitration between the ports (`ARB_POLICY`)

Per bank, each cycle: if both ports present a candidate, `VEC` lets the vector port win, `DMA` lets the DMA win, `RR` alternates (after a grant the other port has priority at that bank), so a
port waits at most one grant of the other port per bank (checked in the testbench by a white-box monitor). `VEC` and `DMA` can starve the loser, which the bandwidth report quantifies
(DMA < 0.1 B/cycle behind a saturating vector stream; vector port blocked when a saturating DMA has priority).

## Ownership: preventing unsafe simultaneous operations

Arbitration alone keeps every *word* access whole but says nothing about *which data* a port may touch. The aperture is divided into `NRGN` equal regions with an owner each:

| owner | vector port | DMA port |
|---|---|---|
| `VEC` (reset default) | allowed | `SF_ST_OWNER`, no effect |
| `DMA` | `SF_ST_OWNER`, no effect | allowed |
| `SHARED` | allowed | allowed (word atomicity only, docs/02 O4) |

Ownership is checked at acceptance for every needed word, so a request that straddles two regions needs both. **Changing an owner** (`own_req_*`) quiesces the whole scratchpad: no port accepts,
every accepted request completes and its response is delivered, then the owner changes and `own_ack_o` pulses. Hence when software sees the acknowledge, all earlier accesses of the old owner are
committed, which is exactly the ping-pong hand-over: DMA fills region R and gets all its write responses (CloudDMA `done`), software moves R to `VEC`, the vector engine reads R and is guaranteed
to see all of it. The cost is that **both ports pause** for the drain; its length was not measured (it is the time for the already accepted requests to complete and be taken by their consumers). The testbench checks that nothing is accepted between the request and the
acknowledge and that at the acknowledge every response has been delivered.

What ownership does not do: it is not a security boundary (the owner registers are a plain port with no privilege check), it does not protect against a consumer that never takes its responses
(the change then never completes), and it has no per-request lock.
