// Pin-only black box of the OpenRAM SKY130 macro (port list taken from sim_models/sky130_sram_standin.sv).
// Used ONLY to count macro instances in the structural ASIC-tiling check (no behaviour, no timing, no area).
(* blackbox *)
module sky130_sram_1kbyte_1rw1r_32x256_8 #(
  parameter NUM_WMASKS = 4, parameter DATA_WIDTH = 32, parameter ADDR_WIDTH = 8, parameter RAM_DEPTH = 256
) (
  input  wire                    clk0, csb0, web0,
  input  wire [NUM_WMASKS-1:0]   wmask0,
  input  wire [ADDR_WIDTH-1:0]   addr0,
  input  wire [DATA_WIDTH-1:0]   din0,
  output wire [DATA_WIDTH-1:0]   dout0,
  input  wire                    clk1, csb1,
  input  wire [ADDR_WIDTH-1:0]   addr1,
  output wire [DATA_WIDTH-1:0]   dout1
);
endmodule
