#!/usr/bin/env python3
"""Logic synthesis of sf_vector_scratchpad with Yosys 0.33 (no PDK, no timing, no place-and-route).

    python3 syn/run_synth.py [--jobs 3]   ->  reports/synthesis.json, reports/synthesis.md

Three independent flows, each reporting only what the tool printed:
  A  GENERIC     `synth -flatten -run :fine; techmap; abc -fast; stat`  per configuration and per sub-block.  Memory arrays stay
                 $mem cells (mapping to RAM is a physical step), so the table counts LOGIC and FLIP-FLOP cells only.
                 Generic-gate counts are NOT area, and no frequency / power is claimed from them.
  B  FPGA        `synth_xilinx -family xc7`  for block-RAM inference: RAMB36 / RAMB18 counts and the fraction of the provisioned
                 block-RAM bits that hold data, for several bank word widths at the same total capacity.
  C  ASIC MACROS the SKY130 adapter with a pin-only black box: counts macro instances per configuration and the fraction of the
                 macro bits that is used.  STRUCTURAL ONLY: no vendor model, no Liberty/LEF, no timing, no area in um2.
"""
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MC = "third_party/memorycore"
RTL = [f"{MC}/rtl/sf_sram_core.sv", f"{MC}/rtl/backends/sf_sram_fpga_bram.sv", f"{MC}/rtl/backends/sf_sram_asic_sky130.sv", f"{MC}/rtl/sf_sram_macro_wrapper.sv",
       "rtl/sf_vspm_bankmap.sv", "rtl/sf_vspm_split.sv", "rtl/sf_vspm_merge.sv", "rtl/sf_vspm_agu.sv", "rtl/sf_vspm_port.sv", "rtl/sf_vspm_bank_sched.sv",
       "rtl/sf_vspm_banks.sv", "rtl/sf_vspm_own.sv", "rtl/sf_vspm_perf.sv", "rtl/sf_vector_scratchpad.sv"]
INC = f"-Irtl -I{MC}/rtl"
TOP = "sf_vector_scratchpad"

def top(name, **ov):
    return (name, TOP, ov)

GENERIC = [
    top("v128 NB4 default (ANY, DMA, perf)", VEC_BYTES=16, NB=4, DEPTH=256),
    top("v128 NB4 ALIGN_WORD (no byte shifter)", VEC_BYTES=16, NB=4, DEPTH=256, ALIGN_POLICY=1),
    top("v128 NB4 ALIGN_VEC", VEC_BYTES=16, NB=4, DEPTH=256, ALIGN_POLICY=0),
    top("v128 NB4 vector-only (DMA_EN=0, PERF_EN=0)", VEC_BYTES=16, NB=4, DEPTH=256, DMA_EN=0, PERF_EN=0),
    top("v128 NB4 PERF_EN=0", VEC_BYTES=16, NB=4, DEPTH=256, PERF_EN=0),
    top("v128 NB4 + strided/gather/scatter", VEC_BYTES=16, NB=4, DEPTH=256, GS_EN=1),
    top("v128 NB8", VEC_BYTES=16, NB=8, DEPTH=128),
    top("v128 NB4 bank word 16 B", VEC_BYTES=16, BANK_BYTES=16, NB=4, DEPTH=64),
    top("v256 NB8 default", VEC_BYTES=32, NB=8, DEPTH=128),
    top("v256 NB8 ALIGN_WORD", VEC_BYTES=32, NB=8, DEPTH=128, ALIGN_POLICY=1),
    top("v256 NB8 + strided/gather/scatter", VEC_BYTES=32, NB=8, DEPTH=128, GS_EN=1),
    top("v256 NB4", VEC_BYTES=32, NB=4, DEPTH=256),
    top("v256 NB16", VEC_BYTES=32, NB=16, DEPTH=64),
    top("v512 NB16 default", VEC_BYTES=64, NB=16, DEPTH=64, DMA_BYTES=32),
    # sub-blocks (area breakdown)
    ("sf_vspm_port v128 NB4", "sf_vspm_port", dict(VEC_BYTES=16, NB=4, DEPTH=256, PORT=0)),
    ("sf_vspm_port v256 NB8", "sf_vspm_port", dict(VEC_BYTES=32, NB=8, DEPTH=128, PORT=0)),
    ("sf_vspm_port DMA 16 B (policy VEC)", "sf_vspm_port", dict(VEC_BYTES=16, NB=4, DEPTH=256, ALIGN_POLICY=0, PORT=1, CQ_DEPTH=4)),
    ("sf_vspm_agu v128 NB4", "sf_vspm_agu", dict(VEC_BYTES=16, NB=4, DEPTH=256)),
    ("sf_vspm_agu v256 NB8 + GS", "sf_vspm_agu", dict(VEC_BYTES=32, NB=8, DEPTH=128, GS_EN=1)),
    ("sf_vspm_split v128", "sf_vspm_split", dict(VEC_BYTES=16, BB=4, NW=5)),
    ("sf_vspm_merge v128", "sf_vspm_merge", dict(VEC_BYTES=16, BB=4, NW=5)),
    ("sf_vspm_split v256", "sf_vspm_split", dict(VEC_BYTES=32, BB=4, NW=9)),
    ("sf_vspm_merge v256", "sf_vspm_merge", dict(VEC_BYTES=32, BB=4, NW=9)),
    ("sf_vspm_bank_sched NB4", "sf_vspm_bank_sched", dict(NB=4, RW=8, BB=4, TW0=6, TW1=4)),
    ("sf_vspm_bank_sched NB8", "sf_vspm_bank_sched", dict(NB=8, RW=7, BB=4, TW0=7, TW1=4)),
    ("sf_vspm_perf NB4 (33 counters x 32 b)", "sf_vspm_perf", dict(NB=4)),
    ("sf_vspm_own 4 regions", "sf_vspm_own", dict(NRGN=4)),
]

FPGA = [   # same 16 KiB total, different bank word widths / shapes
    top("v128 NB4 BB4  1024x32  (16 KiB)", VEC_BYTES=16, NB=4, DEPTH=1024, BACKEND=1, DMA_EN=0, PERF_EN=0),
    top("v128 NB4 BB16 256x128 (16 KiB)", VEC_BYTES=16, BANK_BYTES=16, NB=4, DEPTH=256, BACKEND=1, DMA_EN=0, PERF_EN=0),
    top("v128 NB8 BB4  512x32  (16 KiB)", VEC_BYTES=16, NB=8, DEPTH=512, BACKEND=1, DMA_EN=0, PERF_EN=0),
    top("v256 NB8 BB4  512x32  (16 KiB)", VEC_BYTES=32, NB=8, DEPTH=512, BACKEND=1, DMA_EN=0, PERF_EN=0),
    top("v256 NB4 BB8  512x64  (16 KiB)", VEC_BYTES=32, BANK_BYTES=8, NB=4, DEPTH=512, BACKEND=1, DMA_EN=0, PERF_EN=0),
    top("v256 NB4 BB16 256x128 (16 KiB)", VEC_BYTES=32, BANK_BYTES=16, NB=4, DEPTH=256, BACKEND=1, DMA_EN=0, PERF_EN=0),
    top("v512 NB16 BB4 256x32  (16 KiB)", VEC_BYTES=64, NB=16, DEPTH=256, BACKEND=1, DMA_EN=0, PERF_EN=0),
    top("v128 NB4 BB4  256x32  (4 KiB, shallow)", VEC_BYTES=16, NB=4, DEPTH=256, BACKEND=1, DMA_EN=0, PERF_EN=0),
    top("v128 NB4 BB4  64x32   (1 KiB, tiny)", VEC_BYTES=16, NB=4, DEPTH=64, BACKEND=1, DMA_EN=0, PERF_EN=0),
]

ASIC = [
    top("v128 NB4 BB4  256x32  (4 KiB)", VEC_BYTES=16, NB=4, DEPTH=256, BACKEND=2, READ_LATENCY=2, DMA_EN=0, PERF_EN=0),
    top("v128 NB4 BB4  1024x32 (16 KiB)", VEC_BYTES=16, NB=4, DEPTH=1024, BACKEND=2, READ_LATENCY=2, DMA_EN=0, PERF_EN=0),
    top("v128 NB4 BB16 256x128 (16 KiB)", VEC_BYTES=16, BANK_BYTES=16, NB=4, DEPTH=256, BACKEND=2, READ_LATENCY=2, DMA_EN=0, PERF_EN=0),
    top("v256 NB8 BB4  512x32  (16 KiB)", VEC_BYTES=32, NB=8, DEPTH=512, BACKEND=2, READ_LATENCY=2, DMA_EN=0, PERF_EN=0),
    top("v128 NB4 BB4  64x32   (1 KiB, tiny)", VEC_BYTES=16, NB=4, DEPTH=64, BACKEND=2, READ_LATENCY=2, DMA_EN=0, PERF_EN=0),
    top("v128 NB4 BB4  300x32  (non-multiple depth)", VEC_BYTES=16, NB=4, DEPTH=512, BACKEND=2, READ_LATENCY=2, DMA_EN=0, PERF_EN=0),
]

def yosys(script, files):
    t0 = time.time()
    r = subprocess.run(["yosys", "-q", "-p", script], cwd=ROOT, capture_output=True, text=True, timeout=3000)
    return r.returncode, r.stdout + r.stderr, round(time.time() - t0, 1)

def parse_stat(out):
    types = {m.group(1): int(m.group(2)) for m in re.finditer(r"^\s+(\$?[\w$]+)\s+(\d+)\s*$", out, re.M)}
    cells = re.search(r"Number of cells:\s+(\d+)", out) or re.search(r"(\d+)\s+cells", out)
    return types, int(cells.group(1)) if cells else None

def chparams(ov, topm):
    return "; ".join(f"chparam -set {k} {v} {topm}" for k, v in ov.items())

def run_generic(item):
    name, topm, ov = item
    files = " ".join(RTL)
    # sub-blocks use their own parameter names; top-level configs pass NB/DEPTH etc.
    ys = (f"read_verilog -sv {INC} {files}; {chparams(ov, topm)}; hierarchy -check -top {topm}; synth -flatten -run :fine; "
          f"opt -fast -full; techmap; opt -fast; abc -fast; opt_clean; check; tee -o /dev/stdout stat")
    rc, out, secs = yosys(ys, files)
    types, cells = parse_stat(out)
    if cells is None and rc != 0:
        return dict(name=name, top=topm, status="FAIL", detail=out[-300:])
    mem_cells = sum(v for k, v in types.items() if k.startswith("$mem"))
    ffs = sum(v for k, v in types.items() if "dff" in k.lower() or "sdff" in k.lower())
    latches = sum(v for k, v in types.items() if "latch" in k.lower()) + len(re.findall(r"Warning: .*latch", out, re.I))
    logic = sum(v for k, v in types.items() if not k.startswith("$mem") and "dff" not in k.lower())
    return dict(name=name, top=topm, params=ov, status="OK", total_cells=cells, flip_flops=ffs, logic_cells=logic, mem_cells=mem_cells, latches=latches, secs=secs)

def run_fpga(item):
    name, topm, ov = item
    ys = (f"read_verilog -sv {INC} {' '.join(RTL)}; {chparams(ov, topm)}; hierarchy -check -top {topm}; "
          f"synth_xilinx -family xc7 -flatten -top {topm}; tee -o /dev/stdout stat")
    rc, out, secs = yosys(ys, RTL)
    types, cells = parse_stat(out)
    if cells is None:
        return dict(name=name, status="FAIL", detail=out[-300:])
    ram36 = types.get("RAMB36E1", 0)
    ram18 = types.get("RAMB18E1", 0)
    lut = sum(v for k, v in types.items() if k.startswith("LUT"))
    ff = sum(v for k, v in types.items() if k.startswith("FD"))
    data_bits = ov["NB"] * ov["DEPTH"] * ov.get("BANK_BYTES", 4) * 8
    prov = ram36 * 36864 + ram18 * 18432
    prov_data = ram36 * 32768 + ram18 * 16384                    # data bits only (parity bits excluded)
    return dict(name=name, status="OK", params=ov, ramb36=ram36, ramb18=ram18, lut=lut, ff=ff, data_bits=data_bits,
                provisioned_bits=prov, provisioned_data_bits=prov_data, bit_efficiency=round(data_bits / prov_data, 3) if prov_data else None,
                carry=types.get("CARRY4", 0), secs=secs)

def run_asic(item):
    name, topm, ov = item
    files = ["syn/sky130_macro_blackbox.v"] + RTL
    ys = (f"read_verilog -sv {INC} {' '.join(files)}; {chparams(ov, topm)}; hierarchy -check -top {topm}; proc; flatten; opt_clean; tee -o /dev/stdout stat")
    rc, out, secs = yosys(ys, files)
    types, cells = parse_stat(out)
    m = sum(v for k, v in types.items() if "sky130_sram_1kbyte_1rw1r_32x256_8" in k)
    bank_bytes = ov.get("BANK_BYTES", 4)
    data_bits = ov["NB"] * ov["DEPTH"] * bank_bytes * 8
    if cells is None:
        return dict(name=name, status="FAIL", detail=out[-300:])
    exp = ov["NB"] * (-(-ov["DEPTH"] // 256)) * (-(-(bank_bytes * 8) // 32))
    return dict(name=name, status="OK", params=ov, macros=m, expected_macros=exp, data_bits=data_bits, macro_bits=m * 8192,
                bit_efficiency=round(data_bits / (m * 8192), 3) if m else None, secs=secs)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    a = ap.parse_args()
    with ThreadPoolExecutor(a.jobs) as ex:
        g = list(ex.map(run_generic, GENERIC))
        f = list(ex.map(run_fpga, FPGA))
        s = list(ex.map(run_asic, ASIC))
    tool = subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip()
    json.dump(dict(tool=tool, generic=g, fpga=f, asic=s), open(os.path.join(ROOT, "reports", "synthesis.json"), "w"), indent=1)
    md = [f"# Synthesis results ({tool})", "",
          "No PDK, no timing, no place-and-route anywhere in this file. Cell counts are **generic-gate counts, not area**; no clock frequency or power is claimed.", "",
          "## A. Generic logic synthesis (`synth -flatten`, `abc -fast`; SRAM arrays left as `$mem` cells)", "",
          "| configuration / block | status | flip-flops | other logic cells | `$mem` cells | latches | s |", "|---|---|---:|---:|---:|---:|---:|"]
    for r in g:
        md.append(f"| {r['name']} | {r['status']} | {r.get('flip_flops', '-')} | {r.get('logic_cells', '-')} | {r.get('mem_cells', '-')} | {r.get('latches', '-')} | {r.get('secs', '-')} |")
    md += ["", "## B. FPGA block-RAM inference (`synth_xilinx -family xc7`; same 16 KiB at different bank word widths)", "",
           "RAMB36 = 32 Kb of data (+ 4 Kb parity, unused here); RAMB18 = 16 Kb of data. *efficiency* = stored data bits / data bits of the block RAMs the tool used.", "",
           "| configuration | RAMB36 | RAMB18 | stored data bits | block-RAM data bits | efficiency | LUT | FF |", "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in f:
        md.append(f"| {r['name']} | {r.get('ramb36', '-')} | {r.get('ramb18', '-')} | {r.get('data_bits', '-')} | {r.get('provisioned_data_bits', '-')} | {r.get('bit_efficiency', '-')} | {r.get('lut', '-')} | {r.get('ff', '-')} |")
    md += ["", "## C. SKY130 macro tiling (structural; pin-only black box of `sky130_sram_1kbyte_1rw1r_32x256_8`, 8 Kb each)", "",
           "| configuration | macros | expected (ceil tiling) | stored data bits | macro bits | efficiency |", "|---|---:|---:|---:|---:|---:|"]
    for r in s:
        md.append(f"| {r['name']} | {r.get('macros', '-')} | {r.get('expected_macros', '-')} | {r.get('data_bits', '-')} | {r.get('macro_bits', '-')} | {r.get('bit_efficiency', '-')} |")
    open(os.path.join(ROOT, "reports", "synthesis.md"), "w").write("\n".join(md) + "\n")
    for r in g + f + s:
        print(r["name"], r["status"], {k: v for k, v in r.items() if k in ("flip_flops", "logic_cells", "mem_cells", "latches", "ramb36", "ramb18", "lut", "macros", "bit_efficiency")})
    bad = [r for r in g + f + s if r["status"] != "OK"]
    return 0 if not bad else 1

if __name__ == "__main__":
    sys.exit(main())
