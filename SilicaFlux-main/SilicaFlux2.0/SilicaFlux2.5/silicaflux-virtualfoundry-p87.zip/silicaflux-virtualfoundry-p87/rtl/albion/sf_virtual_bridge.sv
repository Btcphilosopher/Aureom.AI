// =============================================================================
// SilicaFlux Albion -- Project 87 -- VirtualFoundry :: sf_virtual_bridge
//
// The SECOND and THIRD enforcement points of every guest-controlled DMA beat, and the only place
// where VirtualFoundry touches host memory:
//
//   guest contexts --(window-checked beats, domain tag)--> [ arbitration ] -> [ Citadel check ]
//        -> [ Albion master port: single-beat READ / WRITE to the BridgeEngine ] -> response
//
//  * Arbitration: round robin over the contexts, ONE beat outstanding in the whole bridge.  A context
//    that never completes its response therefore stalls the bridge only until RSP_TMO expires; the
//    beat then fails and the bridge isolates itself from the silent endpoint (zombie rule below).
//  * Citadel check (interface defined by Project 83, docs/meridian/03_ACCESS_CONTROL.md): one query
//    {dom, priv = 0, write, addr} per beat, exactly one verdict per accepted query, same cycle or
//    later.  DEFAULT DENY and FAIL CLOSED: no verdict within CHK_TMO cycles denies the beat (F_CITTMO);
//    the bridge then answers immediately (without querying) until a verdict arrives or 8 x CHK_TMO
//    cycles pass, so that a late verdict can never be mistaken for the verdict of a later query.
//    A domain that does not fit the DOM_W-bit Citadel / Albion domain field is denied (F_DOMAIN), never
//    truncated: truncation could alias another tenant's domain.
//  * BridgeEngine master port in the Albion transaction format (Project 83, docs/meridian/02): op,
//    tag, dom, priv, tc, addr, wdata, wstrb; response tag, dom, op, status, rdata.  The response
//    echo (tag, dom, op) is checked against the request; a mismatch or an illegal status is an
//    error response to the context (FS_ECHO), never delivered as data.  A non-OKAY status is an error
//    (FS_BRIDGE).  The BridgeEngine performs its own protected-DMA check as the third line.
//  * RSP_TMO (cycles, 0 = disabled): the beat could not be issued, or no response came.  A beat that
//    was issued and timed out leaves a ZOMBIE: new beats are denied immediately (FS_TIMEOUT) until the
//    late response with the zombie's tag arrives (consumed and dropped) or the system is reset.
//
// Every denial / error is reported to the owning context (first-fault capture in its management page)
// and counted per context here; per-context traffic counters are read through the cnt_* port (global
// management page).  Per-context = per-domain because a context is bound to exactly one domain.
// =============================================================================
module sf_virtual_bridge
  import sf_virtual_pkg::*;
#(
  parameter int NCTX    = 1,
  parameter int DOM_W   = 8,       // width of the Citadel / Albion domain field
  parameter int TAGW    = 4,
  parameter int CHK_TMO = 64,
  parameter int RSP_TMO = 2048,
  localparam int CW = (NCTX > 1) ? $clog2(NCTX) : 1
) (
  input  logic                 clk,
  input  logic                 rst_n,

  // ---- upstream: one port per context (window-checked beats) ------------------------------
  input  logic [NCTX-1:0]      u_req_valid,
  output logic [NCTX-1:0]      u_req_ready,
  input  logic [NCTX*64-1:0]   u_req_addr,
  input  logic [NCTX-1:0]      u_req_we,
  input  logic [NCTX*64-1:0]   u_req_wdata,
  input  logic [NCTX*8-1:0]    u_req_be,
  input  logic [NCTX*3-1:0]    u_req_tc,
  input  logic [NCTX*16-1:0]   u_req_dom,
  output logic [NCTX-1:0]      u_resp_valid,
  output logic [63:0]          u_resp_rdata,
  output logic                 u_resp_err,

  // ---- Citadel check interface (P83) ----------------------------------------------------------
  output logic                 cit_req_valid,
  input  logic                 cit_req_ready,
  output logic [DOM_W-1:0]     cit_req_dom,
  output logic                 cit_req_priv,
  output logic                 cit_req_write,
  output logic [63:0]          cit_req_addr,
  input  logic                 cit_rsp_valid,
  input  logic                 cit_rsp_ok,
  input  logic [3:0]           cit_rsp_fault,

  // ---- BridgeEngine: Albion master port (P83 transaction format, 64-bit single beats) -------------
  output logic                 bdg_req_valid,
  input  logic                 bdg_req_ready,
  output logic [1:0]           bdg_req_op,
  output logic [TAGW-1:0]      bdg_req_tag,
  output logic [DOM_W-1:0]     bdg_req_dom,
  output logic                 bdg_req_priv,
  output logic [2:0]           bdg_req_tc,
  output logic [63:0]          bdg_req_addr,
  output logic [63:0]          bdg_req_wdata,
  output logic [7:0]           bdg_req_wstrb,
  input  logic                 bdg_rsp_valid,
  output logic                 bdg_rsp_ready,
  input  logic [TAGW-1:0]      bdg_rsp_tag,
  input  logic [DOM_W-1:0]     bdg_rsp_dom,
  input  logic [1:0]           bdg_rsp_op,
  input  logic [2:0]           bdg_rsp_status,
  input  logic [63:0]          bdg_rsp_rdata,

  // ---- reporting to the contexts -------------------------------------------------------------------
  output logic [NCTX-1:0]      flt_pulse,      // a denial / error was returned to this context
  output logic [NCTX-1:0]      viol_pulse,     // ... of which Citadel / domain denials
  output logic [NCTX-1:0]      err_pulse,      // any error response
  output logic [63:0]          flt_addr,       // detail of the most recent pulse (valid with flt_pulse)
  output logic                 flt_write,
  output logic [3:0]           flt_src,        // FS_*
  output logic [7:0]           flt_code,       // F_* / ST_* detail

  // ---- per-context counters (global management page) ------------------------------------------
  input  logic [CW-1:0]        cnt_ctx,
  input  logic [3:0]           cnt_idx,
  output logic [31:0]          cnt_rdata,
  input  logic                 cnt_clear,
  output logic                 busy,
  output logic                 isolated,       // zombie: an endpoint stopped answering
  output logic [31:0]          orphan_cnt      // responses that matched nothing (consumed and dropped)
);

  typedef enum logic [2:0] {S_IDLE, S_CHK, S_DENY, S_ISSUE, S_WAIT, S_RESP} st_t;
  st_t st;

  localparam int NCNT = 12;

  logic [CW-1:0]    owner, rr;
  logic [63:0]      a_q, wd_q, rd_q;
  logic             we_q, err_q;
  logic [7:0]       be_q;
  logic [2:0]       tc_q;
  logic [15:0]      dom_q;
  logic [TAGW-1:0]  tag_ctr, tag_q, zombie_tag;
  logic             zombie;
  logic             cit_q;                 // the query was accepted
  logic             outage;
  logic [31:0]      chk_ctr, out_ctr, tmo_ctr, lat_ctr;
  logic [3:0]       fsrc_q;
  logic [7:0]       fcode_q;
  logic             fviol_q;
  logic             flt_req;
  logic [31:0]      orphan_q;
  assign orphan_cnt = orphan_q;

  wire dom_fits = (dom_q >> DOM_W) == 16'd0;

  // ---- round-robin grant over contexts with a pending beat ----------------------------------
  logic          any;
  logic [CW-1:0] gnt;
  always_comb begin
    any = 1'b0;
    gnt = '0;
    for (int k = NCTX; k >= 1; k--) begin
      /* verilator lint_off UNUSEDSIGNAL */
      automatic int c = (int'(rr) + k) % NCTX;
      /* verilator lint_on UNUSEDSIGNAL */
      if (u_req_valid[c]) begin
        any = 1'b1;
        gnt = CW'(c);
      end
    end
  end

  always_comb begin
    u_req_ready = '0;
    if (st == S_IDLE && any) u_req_ready[gnt] = 1'b1;
    u_resp_valid = '0;
    if (st == S_RESP) u_resp_valid[owner] = 1'b1;
  end
  assign u_resp_rdata = rd_q;
  assign u_resp_err   = err_q;
  assign busy         = (st != S_IDLE);
  assign isolated     = zombie;

  // ---- Citadel query -----------------------------------------------------------------------------------
  assign cit_req_valid = (st == S_CHK) && !cit_q;
  assign cit_req_dom   = dom_q[DOM_W-1:0];
  assign cit_req_priv  = 1'b0;                   // a guest-driven engine never presents privilege
  assign cit_req_write = we_q;
  assign cit_req_addr  = a_q;
  wire   cit_acc       = cit_req_valid && cit_req_ready;
  wire   cit_verdict   = cit_rsp_valid && (cit_q || cit_acc);

  // ---- BridgeEngine request ---------------------------------------------------------------------------
  assign bdg_req_valid = (st == S_ISSUE);
  assign bdg_req_op    = we_q ? ALB_OP_WRITE : ALB_OP_READ;
  assign bdg_req_tag   = tag_q;
  assign bdg_req_dom   = dom_q[DOM_W-1:0];
  assign bdg_req_priv  = 1'b0;
  assign bdg_req_tc    = tc_q;
  assign bdg_req_addr  = a_q;
  assign bdg_req_wdata = wd_q;
  assign bdg_req_wstrb = be_q;
  assign bdg_rsp_ready = 1'b1;                   // responses are always consumed (orphans are dropped)

  wire rsp_zombie = bdg_rsp_valid && zombie && (bdg_rsp_tag == zombie_tag);
  wire rsp_match  = (st == S_WAIT) && bdg_rsp_valid && !rsp_zombie;
  wire echo_ok    = (bdg_rsp_tag == tag_q) && (bdg_rsp_dom == dom_q[DOM_W-1:0]) &&
                    (bdg_rsp_op == (we_q ? ALB_OP_WRITE : ALB_OP_READ));

  // ---- beat byte count -----------------------------------------------------------------------------------
  wire [3:0] beat_bytes = sfv_pop8(be_q);

  // ---- per-context counters ------------------------------------------------------------------------------
  // 0 REQS  1/2 RD_BYTES lo/hi  3/4 WR_BYTES lo/hi  5 CIT_DENIED  6 BDG_ERR  7 TIMEOUT
  // 8 STALL (cycles a beat of the context waits in the bridge)  9/10 LAT_SUM lo/hi  11 LAT_MAX
  logic [31:0] cnt [NCTX][NCNT];
  assign cnt_rdata = (cnt_idx < 4'(NCNT)) ? cnt[cnt_ctx][cnt_idx] : 32'd0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st          <= S_IDLE;
      owner       <= '0;
      rr          <= CW'(NCTX - 1);
      a_q         <= '0;
      wd_q        <= '0;
      rd_q        <= '0;
      we_q        <= 1'b0;
      err_q       <= 1'b0;
      be_q        <= '0;
      tc_q        <= '0;
      dom_q       <= '0;
      tag_ctr     <= '0;
      tag_q       <= '0;
      zombie_tag  <= '0;
      zombie      <= 1'b0;
      cit_q       <= 1'b0;
      outage      <= 1'b0;
      chk_ctr     <= '0;
      out_ctr     <= '0;
      tmo_ctr     <= '0;
      lat_ctr     <= '0;
      fsrc_q      <= FS_NONE;
      fcode_q     <= '0;
      fviol_q     <= 1'b0;
      flt_req     <= 1'b0;
      orphan_q    <= '0;
      for (int k = 0; k < NCTX; k++) for (int j = 0; j < NCNT; j++) cnt[k][j] <= '0;
    end else begin
      flt_req <= 1'b0;
      if (bdg_rsp_valid && !rsp_zombie && !(st == S_WAIT)) orphan_q <= orphan_q + 32'd1;

      // a late response of the zombie: consumed and dropped, the isolation ends
      if (rsp_zombie) zombie <= 1'b0;

      // Citadel outage tracking: a verdict outside a query clears the outage (it is the late one)
      if (outage) begin
        out_ctr <= out_ctr + 32'd1;
        if (cit_rsp_valid || out_ctr >= 32'(8 * CHK_TMO)) begin outage <= 1'b0; out_ctr <= '0; end
      end

      // stall accounting: a context's beat waiting in the bridge
      if (st != S_IDLE) cnt[owner][8] <= cnt[owner][8] + 32'd1;
      lat_ctr <= lat_ctr + 32'd1;

      case (st)
        // -------------------------------------------------------------------------------------------
        S_IDLE: if (any) begin
          owner   <= gnt;
          rr      <= gnt;
          a_q     <= u_req_addr [gnt*64 +: 64];
          we_q    <= u_req_we   [gnt];
          wd_q    <= u_req_wdata[gnt*64 +: 64];
          be_q    <= u_req_be   [gnt*8 +: 8];
          tc_q    <= u_req_tc   [gnt*3 +: 3];
          dom_q   <= u_req_dom  [gnt*16 +: 16];
          lat_ctr <= 32'd1;
          cit_q   <= 1'b0;
          chk_ctr <= '0;
          tmo_ctr <= '0;
          err_q   <= 1'b0;
          cnt[gnt][0] <= cnt[gnt][0] + 32'd1;
          cnt[gnt][8] <= cnt[gnt][8] + 32'd1;
          st      <= S_CHK;
        end
        // -------------------------------------------------------------------------------------------
        S_CHK: begin
          chk_ctr <= chk_ctr + 32'd1;
          if (!dom_fits) begin                          // never truncate a domain
            fsrc_q <= FS_CITADEL; fcode_q <= {4'd0, ALB_F_DOMAIN}; fviol_q <= 1'b1; st <= S_DENY;
          end else if (zombie) begin                    // isolated from a silent endpoint
            fsrc_q <= FS_TIMEOUT; fcode_q <= 8'd1; fviol_q <= 1'b0; st <= S_DENY;
          end else if (outage && !cit_q) begin          // fail closed without querying
            fsrc_q <= FS_CITADEL; fcode_q <= {4'd0, ALB_F_CITTMO}; fviol_q <= 1'b1; st <= S_DENY;
          end else if (cit_verdict) begin
            if (cit_rsp_ok) begin
              tag_q   <= tag_ctr;
              tag_ctr <= tag_ctr + TAGW'(1);
              tmo_ctr <= '0;
              st      <= S_ISSUE;
            end else begin
              fsrc_q <= FS_CITADEL; fviol_q <= 1'b1;
              fcode_q <= (cit_rsp_fault == ALB_F_NONE) ? {4'd0, ALB_F_PERM} : {4'd0, cit_rsp_fault};
              st <= S_DENY;
            end
          end else if (chk_ctr >= 32'(CHK_TMO)) begin   // no verdict in time
            outage <= 1'b1; out_ctr <= '0;
            fsrc_q <= FS_CITADEL; fcode_q <= {4'd0, ALB_F_CITTMO}; fviol_q <= 1'b1; st <= S_DENY;
          end
          if (cit_acc) cit_q <= 1'b1;
        end
        // -------------------------------------------------------------------------------------------
        S_DENY: begin
          err_q   <= 1'b1;
          rd_q    <= '0;
          flt_req <= 1'b1;
          cnt[owner][5] <= cnt[owner][5] + (fviol_q ? 32'd1 : 32'd0);
          if (fsrc_q == FS_TIMEOUT) cnt[owner][7] <= cnt[owner][7] + 32'd1;
          if (fsrc_q == FS_CITADEL && fcode_q[3:0] == ALB_F_CITTMO) cnt[owner][7] <= cnt[owner][7] + 32'd1;
          st      <= S_RESP;
        end
        // -------------------------------------------------------------------------------------------
        S_ISSUE: begin
          tmo_ctr <= tmo_ctr + 32'd1;
          if (bdg_req_ready) begin
            tmo_ctr <= '0;
            st      <= S_WAIT;
          end else if (RSP_TMO != 0 && tmo_ctr >= 32'(RSP_TMO)) begin     // never issued: no zombie
            fsrc_q <= FS_TIMEOUT; fcode_q <= 8'd0; fviol_q <= 1'b0; st <= S_DENY;
          end
        end
        // -------------------------------------------------------------------------------------------
        S_WAIT: begin
          tmo_ctr <= tmo_ctr + 32'd1;
          if (rsp_match) begin
            if (!echo_ok) begin
              err_q <= 1'b1; rd_q <= '0; fsrc_q <= FS_ECHO; fcode_q <= {5'd0, bdg_rsp_status}; fviol_q <= 1'b0;
              flt_req <= 1'b1; cnt[owner][6] <= cnt[owner][6] + 32'd1; st <= S_RESP;
            end else if (bdg_rsp_status != ALB_ST_OKAY) begin
              err_q <= 1'b1; rd_q <= '0; fsrc_q <= FS_BRIDGE; fcode_q <= {5'd0, bdg_rsp_status}; fviol_q <= 1'b0;
              flt_req <= 1'b1; cnt[owner][6] <= cnt[owner][6] + 32'd1; st <= S_RESP;
            end else begin
              err_q <= 1'b0; rd_q <= we_q ? 64'd0 : bdg_rsp_rdata;
              if (we_q) begin
                {cnt[owner][4], cnt[owner][3]} <= {cnt[owner][4], cnt[owner][3]} + {60'd0, beat_bytes};
              end else begin
                {cnt[owner][2], cnt[owner][1]} <= {cnt[owner][2], cnt[owner][1]} + {60'd0, beat_bytes};
              end
              st <= S_RESP;
            end
            {cnt[owner][10], cnt[owner][9]} <= {cnt[owner][10], cnt[owner][9]} + {32'd0, lat_ctr};
          end else if (RSP_TMO != 0 && tmo_ctr >= 32'(RSP_TMO)) begin
            zombie <= 1'b1; zombie_tag <= tag_q;
            fsrc_q <= FS_TIMEOUT; fcode_q <= 8'd0; fviol_q <= 1'b0; st <= S_DENY;
          end
        end
        // -------------------------------------------------------------------------------------------
        S_RESP: begin
          if (lat_ctr > cnt[owner][11]) cnt[owner][11] <= lat_ctr;
          st <= S_IDLE;
        end
        default: st <= S_IDLE;
      endcase

      if (cnt_clear) begin
        for (int k = 0; k < NCTX; k++) for (int j = 0; j < NCNT; j++) cnt[k][j] <= '0;
      end
    end
  end

  // ---- reporting ---------------------------------------------------------------------------------------------------
  // flt_req is registered one cycle after the decision; the pulses are emitted together with S_RESP.
  always_comb begin
    flt_pulse = '0;
    viol_pulse = '0;
    err_pulse  = '0;
    if (flt_req) begin
      flt_pulse[owner]  = 1'b1;
      viol_pulse[owner] = fviol_q;
      err_pulse[owner]  = 1'b1;
    end
  end
  assign flt_addr  = a_q;
  assign flt_write = we_q;
  assign flt_src   = fsrc_q;
  assign flt_code  = fcode_q;

endmodule
