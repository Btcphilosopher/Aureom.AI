// =============================================================================
// SilicaFlux Albion -- Project 87 -- VirtualFoundry :: sf_virtual_network_adapter
//
// virtio-net device execution (VirtIO 1.2 s5.1) of ONE guest context over a PacketForge stream
// (the Project 62 PacketCore stream contract: 64-bit beats, keep = all ones except the last beat,
// last, no SOP, err sampled on the last beat).  receiveq = queue 0, transmitq = queue 1.
//
// Offered features (see sf_virtual_transport): VERSION_1, ACCESS_PLATFORM, NET_F_MAC, NET_F_STATUS.
// NOT offered: MRG_RXBUF, checksum / GSO / TSO / UFO offloads, control virtqueue, multiqueue, RSC.
// Consequences implemented here: the virtio_net_hdr is 12 bytes (VERSION_1), a receive buffer is ONE
// device-writable chain that must hold header + frame, and a transmit header must be {flags = 0,
// gso_type = NONE}; anything else is refused (the frame is dropped and counted), never half-handled.
//
// STORE-AND-FORWARD in both directions (docs 01_ARCHITECTURE.md s7, 03_ISOLATION.md s6):
//  * transmit: the whole frame is first read from guest memory into a per-context buffer; only then is
//    it streamed to PacketForge.  A guest whose DMA stalls or is denied can therefore never leave a
//    partial frame on the shared stream or hold the shared stream's arbitration.  A frame the guest
//    cannot supply completely is dropped; PacketForge never sees it.
//  * receive: an arriving frame is stored completely before a guest buffer is consumed.  The shared
//    PacketForge egress is never back-pressured by a guest: when the context's one frame buffer is busy
//    (the guest has not supplied buffers fast enough) the arriving frame is dropped and counted.
//
// Completion semantics (documented, not hidden):
//  * transmit used.len = 0.  The completion means "the frame was handed to PacketForge" (the last beat
//    was accepted by the stream), NOT "the frame left the wire": PacketForge decisions (rules, drops,
//    scheduling) are downstream and are not signalled back on the stream contract.
//  * receive used.len = 12 + frame length.  A buffer that cannot take the frame (too small, or carrying a
//    device-readable descriptor) is returned unused with used.len = 0 and the FRAME IS KEPT for the next
//    buffer; a DMA fault while writing a guest buffer is fatal (DEVICE_NEEDS_RESET), exactly like block.
//
// Events (one-cycle pulses, counted by sf_virtual_ctx_mgmt as the device counters, docs 02):
//   [0] tx frame handed to PacketForge  [1] rx frame delivered   [2] tx frame dropped (bad header / size /
//   direction / permission / DMA fault)  [3] rx frame dropped: buffer busy or device not enabled
//   [4] rx frame dropped: oversize / malformed   [5] rx buffer rejected (too small), frame kept
//   [6] tx DMA fault   [7] rx buffer carried a device-readable descriptor (direction error), frame kept
// =============================================================================
module sf_virtual_network_adapter
  import sf_virtual_pkg::*;
#(
  parameter int MAX_CHAIN = 16,
  parameter int FBYTES    = 2048,         // frame buffer size (maximum frame length, without FCS)
  parameter int PF_TMO    = 65536,        // cycles a ready frame may wait for PacketForge to accept its FIRST beat (0 = forever)
  localparam int SW = $clog2(MAX_CHAIN),
  localparam int CW = $clog2(MAX_CHAIN + 1),
  localparam int FW = $clog2(FBYTES + 1),
  localparam int IW = $clog2(FBYTES)
) (
  input  logic               clk,
  input  logic               rst_n,
  input  logic               flush,         // device reset: discard any stored frame
  input  logic               rx_enable,     // device operational (DRIVER_OK, receive queue ready)

  // ---- receive queue (queue 0) execution -------------------------------------------------------
  input  logic               rx_start,
  input  logic               rx_drain,
  output logic               rx_busy,
  output logic               rx_done,
  output logic               rx_fatal,
  output logic [7:0]         rx_cause,
  output logic [31:0]        rx_used_len,
  output logic               rx_work,       // a complete frame is waiting for a guest buffer
  input  logic [CW-1:0]      rx_n_r,
  input  logic [CW-1:0]      rx_n_w,
  input  logic [31:0]        rx_r_len,
  input  logic [31:0]        rx_w_len,
  input  logic               rx_r_fault,
  output logic [SW-1:0]      rx_seg_idx,
  input  logic [63:0]        rx_seg_addr,
  input  logic [31:0]        rx_seg_len,
  output logic               rx_dma_req_valid,
  input  logic               rx_dma_req_ready,
  output logic [63:0]        rx_dma_req_addr,
  output logic               rx_dma_req_we,
  output logic [63:0]        rx_dma_req_wdata,
  output logic [7:0]         rx_dma_req_be,
  input  logic               rx_dma_resp_valid,
  input  logic [63:0]        rx_dma_resp_rdata,
  input  logic               rx_dma_resp_err,

  // ---- transmit queue (queue 1) execution ---------------------------------------------------------
  input  logic               tx_start,
  input  logic               tx_drain,
  output logic               tx_busy,
  output logic               tx_done,
  output logic               tx_fatal,
  output logic [7:0]         tx_cause,
  output logic [31:0]        tx_used_len,
  input  logic [CW-1:0]      tx_n_r,
  input  logic [CW-1:0]      tx_n_w,
  input  logic [31:0]        tx_r_len,
  input  logic [31:0]        tx_w_len,
  input  logic               tx_r_fault,
  output logic [SW-1:0]      tx_seg_idx,
  input  logic [63:0]        tx_seg_addr,
  input  logic [31:0]        tx_seg_len,
  output logic               tx_dma_req_valid,
  input  logic               tx_dma_req_ready,
  output logic [63:0]        tx_dma_req_addr,
  output logic               tx_dma_req_we,
  output logic [63:0]        tx_dma_req_wdata,
  output logic [7:0]         tx_dma_req_be,
  input  logic               tx_dma_resp_valid,
  input  logic [63:0]        tx_dma_resp_rdata,
  input  logic               tx_dma_resp_err,

  // ---- PacketForge streams (this context's share; the top multiplexes / steers) --------------------------
  output logic               pf_tx_valid,
  input  logic               pf_tx_ready,
  output logic [63:0]        pf_tx_data,
  output logic [7:0]         pf_tx_keep,
  output logic               pf_tx_last,
  input  logic               pf_rx_valid,
  input  logic [63:0]        pf_rx_data,
  input  logic [7:0]         pf_rx_keep,
  input  logic               pf_rx_last,
  input  logic               pf_rx_err,

  output logic [7:0]         ev,
  output logic               be_wait
);

  localparam int HDR = VIRTIO_NET_HDR_BYTES;
  localparam int MIN_FRAME = 14;          // an Ethernet header

  // ===========================================================================
  // Frame buffers
  // ===========================================================================
  logic [7:0] rbuf [FBYTES];
  logic [7:0] tbuf [FBYTES];
  logic [FW-1:0] rlen, tlen;

  // ===========================================================================
  // Receive: stream -> frame buffer
  // ===========================================================================
  logic          rx_recv;               // inside a frame being stored
  logic          rx_drop;               // inside a frame being dropped
  logic          rx_bad;                // keep pattern violation / overflow seen in the frame being stored
  logic          rx_have;               // a complete frame is stored
  logic          rx_free;               // pulse (receive execution): the stored frame has been delivered
  logic [FW-1:0] rcnt;                  // bytes stored so far in the arriving frame
  logic [7:0]    ev_in;                 // events of the ingress side

  wire [3:0] rx_n = sfv_pop8(pf_rx_keep);
  // keep legality: all ones on a non-last beat; a non-empty contiguous low-order mask on the last beat
  wire rx_keep_ok = pf_rx_last ? ((pf_rx_keep != 8'd0) && ((pf_rx_keep & (pf_rx_keep + 8'd1)) == 8'd0))
                               : (pf_rx_keep == 8'hff);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rx_recv <= 1'b0; rx_drop <= 1'b0; rx_bad <= 1'b0; rx_have <= 1'b0; rcnt <= '0; rlen <= '0; ev_in <= '0;
    end else begin
      ev_in <= '0;
      if (rx_free) rx_have <= 1'b0;                       // delivered to the guest
      if (pf_rx_valid) begin
        automatic logic first, accept, bad_now;
        automatic logic [FW:0] base, endc;
        first  = !rx_recv && !rx_drop;
        accept = first ? (!rx_have && rx_enable && !flush) : rx_recv;
        base   = first ? {(FW+1){1'b0}} : {1'b0, rcnt};
        endc   = base + (FW+1)'(rx_n);
        bad_now = (!first && rx_bad) || !rx_keep_ok || (endc > (FW+1)'(FBYTES));
        if (first && !accept) begin                       // buffer busy / device not enabled: tail-drop the whole frame
          if (pf_rx_last) ev_in[3] <= 1'b1; else rx_drop <= 1'b1;
        end else if (accept) begin
          for (int i = 0; i < 8; i++)
            if (pf_rx_keep[i] && (base + (FW+1)'(i)) < (FW+1)'(FBYTES)) rbuf[IW'(base + (FW+1)'(i))] <= pf_rx_data[i*8 +: 8];
          rcnt   <= (endc > (FW+1)'(FBYTES)) ? FW'(FBYTES) : endc[FW-1:0];
          rx_bad <= bad_now;
          if (pf_rx_last) begin
            rx_recv <= 1'b0;
            if (pf_rx_err || bad_now || endc < (FW+1)'(MIN_FRAME)) begin
              ev_in[4] <= 1'b1;                           // malformed / oversize / runt: dropped, never delivered
            end else if (rx_enable && !flush) begin
              rlen    <= endc[FW-1:0];
              rx_have <= 1'b1;
            end else begin
              ev_in[3] <= 1'b1;
            end
          end else begin
            rx_recv <= 1'b1;
          end
        end else if (rx_drop) begin                       // the rest of a frame that is being dropped
          if (pf_rx_last) begin rx_drop <= 1'b0; ev_in[3] <= 1'b1; end
        end
      end
      if (flush || !rx_enable) rx_have <= 1'b0;           // stale frames never survive a reset / a disabled device
    end
  end

  assign rx_work = rx_have && rx_enable;

  // ===========================================================================
  // Receive execution: frame buffer -> guest buffer (header + frame, lane shifted)
  // ===========================================================================
  typedef enum logic [2:0] {R_IDLE, R_CALC, R_DMA, R_ADV} rstate_t;
  rstate_t        rst;
  logic           r_dwait;
  logic [CW-1:0]  r_widx;
  logic [31:0]    r_woff, r_pos, r_total;
  logic [3:0]     r_n;
  logic [63:0]    r_gaddr, r_dbuf;
  logic [7:0]     ev_rx;

  assign rx_busy    = (rst != R_IDLE);
  assign rx_seg_idx = r_widx[SW-1:0];

  wire [63:0] r_g_now    = rx_seg_addr + {32'd0, r_woff};
  wire [31:0] r_seg_left = rx_seg_len - r_woff;
  wire [3:0]  r_g_word   = 4'd8 - {1'b0, r_g_now[2:0]};
  wire [31:0] r_rem      = r_total - r_pos;
  wire [3:0]  r_rem8     = (r_rem < 32'd8) ? r_rem[3:0] : 4'd8;
  wire [3:0]  r_seg8     = (r_seg_left < 32'd8) ? r_seg_left[3:0] : 4'd8;
  wire [3:0]  r_n_calc   = sfv_min4(sfv_min4(r_rem8, r_seg8), r_g_word);

  // byte `p` of the receive stream: virtio_net_hdr (zeros, num_buffers = 1) then the frame
  function automatic logic [7:0] rx_stream_byte(input logic [31:0] p);
    if (p < 32'(HDR)) return (p == 32'd10) ? 8'd1 : 8'd0;
    return rbuf[IW'(p - 32'(HDR))];
  endfunction
  logic [63:0] r_word;
  always_comb begin
    for (int i = 0; i < 8; i++) r_word[i*8 +: 8] = rx_stream_byte(r_pos + 32'(i));
  end

  assign rx_dma_req_valid = (rst == R_DMA) && !r_dwait;
  assign rx_dma_req_addr  = {r_gaddr[63:3], 3'b000};
  assign rx_dma_req_we    = 1'b1;
  assign rx_dma_req_be    = sfv_be(r_n, r_gaddr[2:0]);
  assign rx_dma_req_wdata = r_dbuf << {r_gaddr[2:0], 3'b000};
  wire   r_resp           = r_dwait && rx_dma_resp_valid;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rst <= R_IDLE; r_dwait <= 1'b0; r_widx <= '0; r_woff <= '0; r_pos <= '0; r_total <= '0; r_n <= '0;
      r_gaddr <= '0; r_dbuf <= '0; rx_done <= 1'b0; rx_fatal <= 1'b0; rx_cause <= FC_NONE; rx_used_len <= '0;
      rx_free <= 1'b0; ev_rx <= '0;
    end else begin
      rx_done <= 1'b0; rx_free <= 1'b0; ev_rx <= '0;
      if (rx_dma_req_valid && rx_dma_req_ready) r_dwait <= 1'b1;
      if (r_resp) r_dwait <= 1'b0;
      case (rst)
        R_IDLE: if (rx_start) begin
          rx_fatal <= 1'b0; rx_cause <= FC_NONE;
          if (rx_drain) begin
            rst <= R_IDLE;
          end else if (rx_n_r != '0) begin                // a device-readable descriptor in a receive chain
            rx_used_len <= 32'd0; rx_done <= 1'b1; ev_rx[7] <= 1'b1;             // frame kept for the next buffer
          end else if ({1'b0, rx_w_len} < (33'(HDR) + {{(33-FW){1'b0}}, rlen})) begin   // too small for header + frame
            rx_used_len <= 32'd0; rx_done <= 1'b1; ev_rx[5] <= 1'b1;
          end else begin
            r_total <= 32'(HDR) + 32'(rlen); r_pos <= '0; r_widx <= '0; r_woff <= '0; rst <= R_CALC;
          end
        end
        R_CALC: begin
          if (rx_drain) begin
            rst <= R_IDLE;
          end else if (r_pos == r_total) begin
            rx_used_len <= r_total; rx_done <= 1'b1; rx_free <= 1'b1; ev_rx[1] <= 1'b1; rst <= R_IDLE;
          end else begin
            r_n <= r_n_calc; r_gaddr <= r_g_now; r_dbuf <= r_word; rst <= R_DMA;
          end
        end
        R_DMA: if (r_resp) begin
          if (rx_dma_resp_err) begin                      // the guest buffer is partly written: cannot complete truthfully
            rx_fatal <= 1'b1; rx_cause <= FC_DATA_WRITE_DMA; rx_done <= 1'b1; rx_free <= 1'b1; rst <= R_IDLE;
          end else if (rx_drain) begin
            rst <= R_IDLE;
          end else begin
            rst <= R_ADV;
          end
        end
        R_ADV: begin
          r_pos <= r_pos + {28'd0, r_n};
          if ((r_woff + {28'd0, r_n}) == rx_seg_len) begin r_widx <= r_widx + 1'b1; r_woff <= '0; end
          else r_woff <= r_woff + {28'd0, r_n};
          rst <= R_CALC;
        end
        default: rst <= R_IDLE;
      endcase
    end
  end

  // ===========================================================================
  // Transmit execution: guest buffer -> frame buffer -> PacketForge stream
  // ===========================================================================
  typedef enum logic [2:0] {T_IDLE, T_CALC, T_DMA, T_STORE, T_STREAM} tstate_t;
  tstate_t        tst;
  logic           t_dwait;
  logic [CW-1:0]  t_ridx;
  logic [31:0]    t_roff, t_pos, t_total;
  logic [3:0]     t_n;
  logic [63:0]    t_gaddr;
  logic [15:0]    t_hdr;               // flags, gso_type (the only header fields that matter without offloads)
  logic [7:0]     ev_tx;
  logic           t_dmaerr, t_first_sent;
  logic [31:0]    t_wait, t_sidx;

  assign tx_busy    = (tst != T_IDLE);
  assign tx_seg_idx = t_ridx[SW-1:0];

  wire [63:0] t_g_now    = tx_seg_addr + {32'd0, t_roff};
  wire [31:0] t_seg_left = tx_seg_len - t_roff;
  wire [3:0]  t_g_word   = 4'd8 - {1'b0, t_g_now[2:0]};
  wire [31:0] t_rem      = t_total - t_pos;
  wire [3:0]  t_rem8     = (t_rem < 32'd8) ? t_rem[3:0] : 4'd8;
  wire [3:0]  t_seg8     = (t_seg_left < 32'd8) ? t_seg_left[3:0] : 4'd8;
  wire [3:0]  t_n_calc   = sfv_min4(sfv_min4(t_rem8, t_seg8), t_g_word);

  assign tx_dma_req_valid = (tst == T_DMA) && !t_dwait;
  assign tx_dma_req_addr  = {t_gaddr[63:3], 3'b000};
  assign tx_dma_req_we    = 1'b0;
  assign tx_dma_req_be    = sfv_be(t_n, t_gaddr[2:0]);
  assign tx_dma_req_wdata = 64'd0;
  wire   t_resp           = t_dwait && tx_dma_resp_valid;
  wire [63:0] t_rd_word   = tx_dma_resp_rdata >> {t_gaddr[2:0], 3'b000};

  // stream beats out of the transmit frame buffer
  wire [31:0] s_left = {{(32-FW){1'b0}}, tlen} - t_sidx;
  wire        s_last = (s_left <= 32'd8);
  logic [63:0] s_word;
  always_comb begin
    for (int i = 0; i < 8; i++) s_word[i*8 +: 8] = ((t_sidx + 32'(i)) < 32'(FBYTES)) ? tbuf[IW'(t_sidx + 32'(i))] : 8'd0;
  end
  assign pf_tx_valid = (tst == T_STREAM);
  assign pf_tx_data  = s_word;
  assign pf_tx_keep  = s_last ? 8'((16'd1 << s_left[3:0]) - 16'd1) : 8'hff;
  assign pf_tx_last  = s_last;
  assign be_wait     = (tst == T_STREAM) && !pf_tx_ready;

  wire hdr_ok = (t_hdr[7:0] == 8'd0) && (t_hdr[15:8] == VIRTIO_NET_HDR_GSO_NONE);   // no offload was negotiated

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tst <= T_IDLE; t_dwait <= 1'b0; t_ridx <= '0; t_roff <= '0; t_pos <= '0; t_total <= '0; t_n <= '0; t_gaddr <= '0;
      t_hdr <= '0; tx_done <= 1'b0; tx_fatal <= 1'b0; tx_cause <= FC_NONE; tx_used_len <= '0; ev_tx <= '0;
      tlen <= '0; t_dmaerr <= 1'b0; t_first_sent <= 1'b0; t_wait <= '0; t_sidx <= '0;
    end else begin
      tx_done <= 1'b0; ev_tx <= '0; tx_fatal <= 1'b0;
      if (tx_dma_req_valid && tx_dma_req_ready) t_dwait <= 1'b1;
      if (t_resp) t_dwait <= 1'b0;
      case (tst)
        T_IDLE: if (tx_start) begin
          tx_cause <= FC_NONE; t_dmaerr <= 1'b0;
          if (tx_drain) begin
            tst <= T_IDLE;
          end else if (tx_n_w != '0 || tx_r_fault ||
                       tx_r_len < (32'(HDR) + 32'(MIN_FRAME)) || tx_r_len > (32'(HDR) + 32'(FBYTES))) begin
            // device-writable descriptor on the transmit queue (direction), a buffer the windows refused, or a
            // frame of illegal size: the buffer is returned, nothing is sent
            tx_used_len <= 32'd0; tx_done <= 1'b1; ev_tx[2] <= 1'b1;
          end else begin
            t_total <= tx_r_len; t_pos <= '0; t_ridx <= '0; t_roff <= '0; t_hdr <= '0; tst <= T_CALC;
          end
        end
        T_CALC: begin
          if (tx_drain) begin
            tst <= T_IDLE;
          end else if (t_pos == t_total) begin
            // header validation: offloads were not negotiated, so a non-zero flags / gso_type is a driver error
            if (!hdr_ok || t_dmaerr) begin
              tx_used_len <= 32'd0; tx_done <= 1'b1; ev_tx[2] <= 1'b1; if (t_dmaerr) ev_tx[6] <= 1'b1; tst <= T_IDLE;
            end else begin
              tlen <= FW'(t_total - 32'(HDR)); t_sidx <= '0; t_wait <= '0; t_first_sent <= 1'b0; tst <= T_STREAM;
            end
          end else begin
            t_n <= t_n_calc; t_gaddr <= t_g_now; tst <= T_DMA;
          end
        end
        T_DMA: if (t_resp) begin
          if (tx_dma_resp_err) begin                      // a refused / failed read of the guest's frame: drop the frame
            t_dmaerr <= 1'b1; tx_used_len <= 32'd0; tx_done <= 1'b1; ev_tx[2] <= 1'b1; ev_tx[6] <= 1'b1; tst <= T_IDLE;
          end else if (tx_drain) begin
            tst <= T_IDLE;
          end else begin
            // store the bytes of this step: header bytes into t_hdr, frame bytes into the transmit buffer
            for (int i = 0; i < 8; i++) begin
              if (4'(i) < t_n) begin
                if ((t_pos + 32'(i)) == 32'd0) t_hdr[7:0] <= t_rd_word[i*8 +: 8];
                else if ((t_pos + 32'(i)) == 32'd1) t_hdr[15:8] <= t_rd_word[i*8 +: 8];
                else if ((t_pos + 32'(i)) >= 32'(HDR)) tbuf[IW'(t_pos + 32'(i) - 32'(HDR))] <= t_rd_word[i*8 +: 8];
              end
            end
            tst <= T_STORE;
          end
        end
        T_STORE: begin
          t_pos <= t_pos + {28'd0, t_n};
          if ((t_roff + {28'd0, t_n}) == tx_seg_len) begin t_ridx <= t_ridx + 1'b1; t_roff <= '0; end
          else t_roff <= t_roff + {28'd0, t_n};
          tst <= T_CALC;
        end
        T_STREAM: begin
          if (tx_drain && !t_first_sent) begin
            tst <= T_IDLE;                                 // nothing reached the stream yet: abandon cleanly
          end else if (pf_tx_ready) begin                  // valid is high: the beat is accepted
            t_first_sent <= 1'b1; t_wait <= '0;
            if (s_last) begin
              tx_used_len <= 32'd0; tx_done <= 1'b1; ev_tx[0] <= 1'b1; tst <= T_IDLE;
            end else begin
              t_sidx <= t_sidx + 32'd8;
            end
          end else begin
            t_wait <= t_wait + 32'd1;
            if (PF_TMO != 0 && !t_first_sent && t_wait >= 32'(PF_TMO)) begin   // PacketForge never took the frame: give up
              tx_used_len <= 32'd0; tx_done <= 1'b1; ev_tx[2] <= 1'b1; tst <= T_IDLE;
            end
          end
        end
        default: tst <= T_IDLE;
      endcase
    end
  end

  // events
  assign ev = ev_in | ev_rx | ev_tx;

  // the transmit queue never reports a fatal execution error (a refused read drops the frame)
  logic unused_ok;
  assign unused_ok = ^{tx_w_len, rx_r_len, rx_r_fault, rx_dma_resp_rdata, tx_dma_req_wdata, tx_fatal, tx_cause, rx_n_w, tx_n_r};

endmodule
