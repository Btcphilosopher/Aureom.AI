// =============================================================================
// SilicaFlux Albion -- Project 87 -- VirtualFoundry :: sf_virtual_transport
//
// Guest-visible VirtIO transport of ONE guest context: "Virtio Over MMIO", Version 2 (VirtIO 1.2
// s4.2).  A context is one virtio device (block: 1 queue, network: 2 queues, receiveq = queue 0,
// transmitq = queue 1) with its own 4 KiB register window and its own interrupt line.
//
// DERIVED FROM Project 63 silicaflux_virtio_mmio_transport.sv.  Differences: NQ queues selected by
// QueueSel; device kind (block / network) chooses DeviceID, the offered feature set and the config
// space; capacity / read-only / MAC come from the privileged management plane; link status raises a
// configuration-change notification; a host-initiated reset path (host_rst_req/host_rst_done);
// queue disable drains only the selected queue.
//
//  * Feature negotiation (s2.2, s3.1.1): the device offers ONLY features it implements.
//      block   : VERSION_1, ACCESS_PLATFORM, BLK_F_SEG_MAX, BLK_F_FLUSH, BLK_F_RO (only when the extent is read-only)
//      network : VERSION_1, ACCESS_PLATFORM, NET_F_MAC, NET_F_STATUS
//    NOT offered: packed rings, indirect descriptors, EVENT_IDX, IN_ORDER, RING_RESET, NOTIFICATION_DATA,
//    multiqueue, MRG_RXBUF, checksum / GSO offloads, control virtqueue.
//    FEATURES_OK is withheld when the driver accepts a feature that was not offered or omits a feature
//    this device requires (VERSION_1 and ACCESS_PLATFORM: every buffer address is an IOVA checked
//    against the domain's windows, the Citadel and the BridgeEngine).
//  * Device status (s2.1): the driver can only set bits; writing 0 resets the device.
//    DEVICE_NEEDS_RESET is device-owned.
//  * Reset and queue disable are quiesced: the bus write is back-pressured (mmio_req_ready = 0) until
//    the affected engines have drained, so no device write can land after the driver sees the reset
//    complete.  A host reset (hypervisor) uses the same drain and then performs the same reset.
//
// Bus protocol: valid/ready request; exactly one response, one cycle after the request is accepted
// (writes return rdata = 0).
// =============================================================================
module sf_virtual_transport
  import sf_virtual_pkg::*;
#(
  parameter int DEV       = DEV_BLK,
  parameter int NQ        = 1,
  parameter int MAX_QSZ   = 256,
  parameter int MAX_CHAIN = 16
) (
  input  logic              clk,
  input  logic              rst_n,

  // ---- guest-visible register bus ----------------------------------------------
  input  logic              mmio_req_valid,
  output logic              mmio_req_ready,
  input  logic              mmio_req_we,
  input  logic [11:0]       mmio_req_addr,
  input  logic [31:0]       mmio_req_wdata,
  input  logic [3:0]        mmio_req_be,
  output logic              mmio_resp_valid,
  output logic [31:0]       mmio_resp_rdata,
  output logic              irq,

  // ---- device configuration from the management plane --------------------------
  input  logic [63:0]       cfg_capacity,      // block: sectors
  input  logic              cfg_ro,            // block: read-only extent
  input  logic [47:0]       cfg_mac,           // net: byte 0 in bits [7:0]
  input  logic              link_up,           // net: PacketForge link status

  // ---- host (hypervisor) reset -------------------------------------------------------
  input  logic              host_rst_req,
  output logic              host_rst_done,

  // ---- engine interface ----------------------------------------------------------------
  input  logic [NQ-1:0]     engine_idle,       // per queue engine fully drained (incl. in-flight DMA)
  output logic [NQ-1:0]     drain,             // drain request for reset / queue disable
  input  logic              eng_fatal_pulse,
  input  logic [NQ-1:0]     used_irq_pulse,
  output logic              cfg_fatal_pulse,   // invalid queue configuration at QueueReady = 1
  output logic              reset_pulse,       // device reset performed

  output logic [NQ-1:0]     q_ready,
  output logic [NQ*16-1:0]  q_size,
  output logic [NQ*64-1:0]  q_desc,
  output logic [NQ*64-1:0]  q_driver,
  output logic [NQ*64-1:0]  q_device,
  output logic              dev_active,
  output logic [NQ-1:0]     notify_pulse,
  output logic [63:0]       drv_features,
  output logic              needs_reset,
  output logic [7:0]        dev_status
);

  localparam int QW = (NQ > 1) ? $clog2(NQ) : 1;

  // ---------------------------------------------------------------------------
  // Offered / required features.  Only what is implemented is offered.
  // ---------------------------------------------------------------------------
  logic [63:0] dev_features;
  always_comb begin
    if (DEV == DEV_NET) begin
      dev_features = (64'd1 << VIRTIO_F_VERSION_1) | (64'd1 << VIRTIO_F_ACCESS_PLATFORM) |
                     (64'd1 << VIRTIO_NET_F_MAC)   | (64'd1 << VIRTIO_NET_F_STATUS);
    end else begin
      dev_features = (64'd1 << VIRTIO_F_VERSION_1) | (64'd1 << VIRTIO_F_ACCESS_PLATFORM) |
                     (64'd1 << VIRTIO_BLK_F_SEG_MAX) | (64'd1 << VIRTIO_BLK_F_FLUSH) |
                     (cfg_ro ? (64'd1 << VIRTIO_BLK_F_RO) : 64'd0);
    end
  end
  localparam logic [63:0] REQ_FEATURES = (64'd1 << VIRTIO_F_VERSION_1) | (64'd1 << VIRTIO_F_ACCESS_PLATFORM);
  localparam logic [31:0] SEG_MAX      = 32'(MAX_CHAIN - 2);   // data segments (excl. header + status)

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  logic [7:0]  status_q;
  logic        needs_reset_q;
  logic [31:0] dev_feat_sel, drv_feat_sel, queue_sel;
  logic [63:0] drv_feat_q;
  logic [31:0] q_num_q   [NQ];
  logic [NQ-1:0] q_ready_q;
  logic [63:0] q_desc_q  [NQ];
  logic [63:0] q_drv_q   [NQ];
  logic [63:0] q_dev_q   [NQ];
  logic [1:0]  int_status;
  logic [NQ-1:0] drain_q;
  logic [31:0] cfg_gen;
  logic        link_q;
  logic        host_rst_pend;

  wire [11:0] a  = mmio_req_addr;
  wire [31:0] wd = mmio_req_wdata;

  wire          sel_ok = (queue_sel < 32'(NQ));
  wire [QW-1:0] sel    = queue_sel[QW-1:0];

  wire is_reset_wr   = mmio_req_valid && mmio_req_we && (a == MMIO_STATUS) && (wd == 32'd0);
  wire is_qdisable   = mmio_req_valid && mmio_req_we && (a == MMIO_QUEUE_READY) && (wd[0] == 1'b0) &&
                       sel_ok && q_ready_q[sel];
  wire all_idle      = &engine_idle;
  wire all_drain     = &drain_q;

  // a bus write that must wait for the engines
  wire ready_reset   = all_drain && all_idle;
  wire ready_qdis    = drain_q[sel] && engine_idle[sel];
  assign mmio_req_ready = !(is_reset_wr || is_qdisable) ||
                          (is_reset_wr ? ready_reset : ready_qdis);
  wire acc = mmio_req_valid && mmio_req_ready;

  // host reset fires once every engine has drained
  wire host_fire = host_rst_pend && all_drain && all_idle;
  wire do_reset  = (acc && mmio_req_we && (a == MMIO_STATUS) && (wd == 32'd0)) || host_fire;

  // feature acceptance (s3.1.1 step 5)
  wire feat_ok = ((drv_feat_q & ~dev_features) == 64'd0) &&
                 ((drv_feat_q & REQ_FEATURES) == REQ_FEATURES);

  // queue configuration validity of the selected queue (s2.7: power of two, <= QueueNumMax;
  // s2.7.2 alignment: descriptor table 16, available ring 2, used ring 4)
  wire [31:0] sq_num = q_num_q[sel];
  wire qnum_pow2 = (sq_num != 32'd0) && ((sq_num & (sq_num - 32'd1)) == 32'd0);
  wire qcfg_ok   = qnum_pow2 && (sq_num <= 32'(MAX_QSZ)) &&
                   (q_desc_q[sel][3:0] == 4'd0) && (q_drv_q[sel][0] == 1'b0) &&
                   (q_dev_q[sel][1:0] == 2'd0);

  wire driver_ok_bit = status_q[2];
  wire feat_ok_bit   = status_q[3];
  wire failed_bit    = status_q[7];

  // ---------------------------------------------------------------------------
  // Read mux
  // ---------------------------------------------------------------------------
  logic [31:0] rdata;
  always_comb begin
    rdata = 32'd0;
    case (a)
      MMIO_MAGIC_VALUE:       rdata = VIRTIO_MMIO_MAGIC;
      MMIO_VERSION:           rdata = VIRTIO_MMIO_VERSION;
      MMIO_DEVICE_ID:         rdata = (DEV == DEV_NET) ? VIRTIO_ID_NET : VIRTIO_ID_BLOCK;
      MMIO_VENDOR_ID:         rdata = SFV_VIRTIO_VENDOR;
      MMIO_DEVICE_FEATURES:   rdata = (dev_feat_sel == 32'd0) ? dev_features[31:0]  :
                                      (dev_feat_sel == 32'd1) ? dev_features[63:32] : 32'd0;
      MMIO_QUEUE_NUM_MAX:     rdata = sel_ok ? 32'(MAX_QSZ) : 32'd0;
      MMIO_QUEUE_READY:       rdata = {31'd0, sel_ok && q_ready_q[sel]};
      MMIO_INTERRUPT_STATUS:  rdata = {30'd0, int_status};
      MMIO_STATUS:            rdata = {24'd0, status_q | (needs_reset_q ? VIRTIO_STATUS_DEVICE_NEEDS_RESET : 8'd0)};
      MMIO_SHM_LEN_LOW,
      MMIO_SHM_LEN_HIGH,
      MMIO_SHM_BASE_LOW,
      MMIO_SHM_BASE_HIGH:     rdata = 32'hffff_ffff;   // no shared-memory regions
      MMIO_CONFIG_GENERATION: rdata = cfg_gen;
      12'h100: rdata = (DEV == DEV_NET) ? cfg_mac[31:0]                     : cfg_capacity[31:0];
      12'h104: rdata = (DEV == DEV_NET) ? {VIRTIO_NET_S_LINK_UP & {16{link_up}}, cfg_mac[47:32]}
                                        : cfg_capacity[63:32];
      12'h108: rdata = 32'd0;                                               // block size_max (not offered)
      12'h10c: rdata = (DEV == DEV_NET) ? 32'd0 : SEG_MAX;                  // block seg_max
      default:                rdata = 32'd0;
    endcase
  end

  // ---------------------------------------------------------------------------
  // Sequential
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      status_q        <= '0;
      needs_reset_q   <= 1'b0;
      dev_feat_sel    <= '0;
      drv_feat_sel    <= '0;
      queue_sel       <= '0;
      drv_feat_q      <= '0;
      for (int q = 0; q < NQ; q++) begin
        q_num_q[q]  <= 32'(MAX_QSZ);
        q_desc_q[q] <= '0;
        q_drv_q[q]  <= '0;
        q_dev_q[q]  <= '0;
      end
      q_ready_q       <= '0;
      int_status      <= '0;
      drain_q         <= '0;
      mmio_resp_valid <= 1'b0;
      mmio_resp_rdata <= '0;
      cfg_fatal_pulse <= 1'b0;
      notify_pulse    <= '0;
      reset_pulse     <= 1'b0;
      cfg_gen         <= '0;
      link_q          <= link_up;
      host_rst_pend   <= 1'b0;
      host_rst_done   <= 1'b0;
    end else begin
      mmio_resp_valid <= acc;
      mmio_resp_rdata <= (acc && !mmio_req_we) ? rdata : 32'd0;
      cfg_fatal_pulse <= 1'b0;
      notify_pulse    <= '0;
      reset_pulse     <= 1'b0;
      host_rst_done   <= 1'b0;

      // drain requests: held while a quiescing write (or a host reset) waits for the engines
      for (int q = 0; q < NQ; q++)
        drain_q[q] <= ((mmio_req_valid && !acc) && (is_reset_wr || (is_qdisable && (sel == QW'(q))))) ||
                      (host_rst_pend && !host_fire);

      // host reset request (level, latched until performed)
      if (host_rst_req && !host_rst_pend && !host_rst_done) host_rst_pend <= 1'b1;
      if (host_fire) begin host_rst_pend <= 1'b0; host_rst_done <= 1'b1; end

      // datapath events
      if (|used_irq_pulse) int_status[VIRTIO_MMIO_INT_VRING] <= 1'b1;
      if (eng_fatal_pulse) begin
        needs_reset_q <= 1'b1;
        if (driver_ok_bit) int_status[VIRTIO_MMIO_INT_CONFIG] <= 1'b1;   // s2.1.2
      end

      // link status change: configuration-change notification (net)
      link_q <= link_up;
      if (DEV == DEV_NET && link_up != link_q) begin
        cfg_gen <= cfg_gen + 32'd1;
        if (driver_ok_bit) int_status[VIRTIO_MMIO_INT_CONFIG] <= 1'b1;
      end

      if (acc && mmio_req_we) begin
        case (a)
          MMIO_DEVICE_FEATURES_SEL: dev_feat_sel <= wd;
          MMIO_DRIVER_FEATURES_SEL: drv_feat_sel <= wd;
          MMIO_DRIVER_FEATURES: if (!feat_ok_bit) begin
            if (drv_feat_sel == 32'd0) drv_feat_q[31:0]  <= wd;
            if (drv_feat_sel == 32'd1) drv_feat_q[63:32] <= wd;
          end
          MMIO_QUEUE_SEL:        queue_sel <= wd;
          MMIO_QUEUE_NUM:        if (sel_ok && !q_ready_q[sel]) q_num_q[sel] <= wd;
          MMIO_QUEUE_DESC_LOW:   if (sel_ok && !q_ready_q[sel]) q_desc_q[sel][31:0]  <= wd;
          MMIO_QUEUE_DESC_HIGH:  if (sel_ok && !q_ready_q[sel]) q_desc_q[sel][63:32] <= wd;
          MMIO_QUEUE_DRIVER_LOW: if (sel_ok && !q_ready_q[sel]) q_drv_q[sel][31:0]   <= wd;
          MMIO_QUEUE_DRIVER_HIGH:if (sel_ok && !q_ready_q[sel]) q_drv_q[sel][63:32]  <= wd;
          MMIO_QUEUE_DEVICE_LOW: if (sel_ok && !q_ready_q[sel]) q_dev_q[sel][31:0]   <= wd;
          MMIO_QUEUE_DEVICE_HIGH:if (sel_ok && !q_ready_q[sel]) q_dev_q[sel][63:32]  <= wd;
          MMIO_QUEUE_READY: if (sel_ok) begin
            if (wd[0] && !q_ready_q[sel]) begin
              if (qcfg_ok) begin
                q_ready_q[sel] <= 1'b1;
              end else begin
                cfg_fatal_pulse <= 1'b1;
                needs_reset_q   <= 1'b1;
                if (driver_ok_bit) int_status[VIRTIO_MMIO_INT_CONFIG] <= 1'b1;
              end
            end else if (!wd[0]) begin
              q_ready_q[sel] <= 1'b0;   // quiesced by the ready gating above
            end
          end
          MMIO_QUEUE_NOTIFY: if (wd < 32'(NQ)) begin
            if (q_ready_q[wd[QW-1:0]]) notify_pulse[wd[QW-1:0]] <= 1'b1;
          end
          MMIO_INTERRUPT_ACK: int_status <= int_status & ~wd[1:0];
          MMIO_STATUS: begin
            if (wd != 32'd0) begin
              // driver may only set bits; NEEDS_RESET is device-owned
              logic [7:0] nv;
              nv = status_q | (wd[7:0] & ~VIRTIO_STATUS_DEVICE_NEEDS_RESET);
              if (wd[3] && !feat_ok_bit && !feat_ok) nv[3] = 1'b0;   // refuse FEATURES_OK
              status_q <= nv;
            end
          end
          default: ;
        endcase
      end

      // ---- device reset (s2.1, s4.2.2.1): guest Status <- 0 or host reset ----
      if (do_reset) begin
        status_q      <= '0;
        needs_reset_q <= 1'b0;
        dev_feat_sel  <= '0;
        drv_feat_sel  <= '0;
        queue_sel     <= '0;
        drv_feat_q    <= '0;
        for (int q = 0; q < NQ; q++) begin
          q_num_q[q]  <= 32'(MAX_QSZ);
          q_desc_q[q] <= '0;
          q_drv_q[q]  <= '0;
          q_dev_q[q]  <= '0;
        end
        q_ready_q     <= '0;
        int_status    <= '0;
        reset_pulse   <= 1'b1;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Outputs
  // ---------------------------------------------------------------------------
  assign irq          = |int_status;
  assign q_ready      = q_ready_q;
  always_comb begin
    for (int q = 0; q < NQ; q++) begin
      q_size  [q*16 +: 16] = q_num_q[q][15:0];
      q_desc  [q*64 +: 64] = q_desc_q[q];
      q_driver[q*64 +: 64] = q_drv_q[q];
      q_device[q*64 +: 64] = q_dev_q[q];
    end
  end
  assign drain        = drain_q;
  assign drv_features = drv_feat_q;
  assign needs_reset  = needs_reset_q;
  assign dev_status   = status_q;
  // s3.1.1 / s2.1.2: no buffers consumed before DRIVER_OK, none after FAILED or while NEEDS_RESET
  // is set; FEATURES_OK is a precondition.
  assign dev_active   = driver_ok_bit && feat_ok_bit && !failed_bit && !needs_reset_q;

  // byte enables are accepted but registers are 32-bit (s4.2.2.2: the driver MUST use 32-bit
  // accesses for registers); config space is read-only.
  logic unused_be;
  assign unused_be = ^mmio_req_be;

endmodule
