// =============================================================================
// SilicaFlux Albion -- Project 87 -- VirtualFoundry :: sf_virtual_io        (PRIMARY RTL)
//
// Hardware-assisted virtual-machine / container I/O for the Albion cloud device: guest VirtIO
// devices (split virtqueues, virtio-mmio v2) executed against a storage backend and a PacketForge
// network backend, with every guest-controlled memory access confined by three independent
// enforcement points (docs 03_ISOLATION.md).
//
//   guest 0 .. guest N-1  (one register window + one interrupt each)
//        |                                    hypervisor / Keystone (privileged management page)
//   [ sf_virtual_ctx ] x NCTX  <--------------- mgmt: domain binding, windows, extent, MAC, faults, counters
//        |  window-checked DMA beats (domain tag)            |  storage beats        |  frames
//   [ sf_virtual_bridge ]                              [ storage arbiter ]    [ PacketForge mux / demux ]
//        |  Citadel check (cit_*)   BridgeEngine master (bdg_*, Albion format)   |         |
//   Citadel                       BridgeEngine -> host memory          StorageCore    PacketForge
//
// What this is NOT (docs 08_LIMITATIONS.md): it is not a hypervisor and it is not PCIe SR-IOV.  It
// executes the device side of a fixed set of VirtIO devices; the guest "contexts" are separate
// virtio-mmio devices with separate protection domains, not PCIe virtual functions with a PF/VF
// configuration space, ARI, ATS or function-level reset.  The Citadel is a reference model and the
// BridgeEngine / StorageCore / PacketForge are bench models in this project.
//
// Management address map (16 bit):  [15:12] page: 0..NCTX-1 = context page (sf_virtual_ctx_mgmt),
// 0xF = global page; [11:0] offset.   Guest address map: one 12-bit window per context.
// =============================================================================
module sf_virtual_io
  import sf_virtual_pkg::*;
#(
  parameter int           NCTX      = 1,
  parameter int           CTX_KIND  = 0,         // bit i: 0 = virtio-blk, 1 = virtio-net
  parameter int           MAX_QSZ   = 256,
  parameter int           MAX_CHAIN = 16,
  parameter int           N_WIN     = 8,
  parameter int           SADDR_W   = 40,
  parameter int           FBYTES    = 2048,
  parameter int           DOM_W     = 8,
  parameter int           TAGW      = 4,
  parameter int           CHK_TMO   = 64,
  parameter int           RSP_TMO   = 2048,
  parameter int           ST_TMO    = 4096,     // storage response timeout in cycles (0 = disabled)
  parameter logic [159:0] BLK_ID    = "SILICAFLUX-VBLK-0001"
) (
  input  logic                 clk,
  input  logic                 rst_n,

  // ---- guest-visible VirtIO MMIO windows, one per context ---------------------------------------
  input  logic [NCTX-1:0]      mmio_req_valid,
  output logic [NCTX-1:0]      mmio_req_ready,
  input  logic [NCTX-1:0]      mmio_req_we,
  input  logic [NCTX*12-1:0]   mmio_req_addr,
  input  logic [NCTX*32-1:0]   mmio_req_wdata,
  input  logic [NCTX*4-1:0]    mmio_req_be,
  output logic [NCTX-1:0]      mmio_resp_valid,
  output logic [NCTX*32-1:0]   mmio_resp_rdata,
  output logic [NCTX-1:0]      irq,

  // ---- privileged management bus (Keystone / hypervisor) ---------------------------------------------
  input  logic                 mgmt_req_valid,
  output logic                 mgmt_req_ready,
  input  logic                 mgmt_req_we,
  input  logic [15:0]          mgmt_req_addr,
  input  logic [31:0]          mgmt_req_wdata,
  output logic                 mgmt_resp_valid,
  output logic [31:0]          mgmt_resp_rdata,

  // ---- Citadel check interface (P83) -----------------------------------------------------------------------
  output logic                 cit_req_valid,
  input  logic                 cit_req_ready,
  output logic [DOM_W-1:0]     cit_req_dom,
  output logic                 cit_req_priv,
  output logic                 cit_req_write,
  output logic [63:0]          cit_req_addr,
  input  logic                 cit_rsp_valid,
  input  logic                 cit_rsp_ok,
  input  logic [3:0]           cit_rsp_fault,

  // ---- BridgeEngine: Albion master port (P83 transaction format) -----------------------------------------------
  output logic                 bdg_req_valid,
  input  logic                 bdg_req_ready,
  output logic [1:0]           bdg_req_op,
  output logic [TAGW-1:0]      bdg_req_tag,
  output logic [DOM_W-1:0]     bdg_req_dom,
  output logic                 bdg_req_priv,
  output logic [2:0]           bdg_req_tc,
  output logic [63:0]          bdg_req_addr,
  output logic [63:0]          bdg_req_wdata,
  output logic [7:0]           bdg_req_wstrb,
  input  logic                 bdg_rsp_valid,
  output logic                 bdg_rsp_ready,
  input  logic [TAGW-1:0]      bdg_rsp_tag,
  input  logic [DOM_W-1:0]     bdg_rsp_dom,
  input  logic [1:0]           bdg_rsp_op,
  input  logic [2:0]           bdg_rsp_status,
  input  logic [63:0]          bdg_rsp_rdata,

  // ---- storage backend (shared by the block contexts; byte addressed, one request outstanding) ------------
  output logic                 st_req_valid,
  input  logic                 st_req_ready,
  output logic [1:0]           st_req_op,
  output logic [SADDR_W-1:0]   st_req_addr,
  output logic [63:0]          st_req_wdata,
  output logic [7:0]           st_req_be,
  output logic [15:0]          st_req_dom,
  input  logic                 st_resp_valid,
  input  logic [63:0]          st_resp_rdata,
  input  logic                 st_resp_err,

  // ---- PacketForge (PacketCore stream contract, DW = 64) ----------------------------------------------------------
  input  logic [NCTX-1:0]      pf_link_up,
  output logic                 pf_s_valid,        // frames toward PacketForge (ingress)
  input  logic                 pf_s_ready,
  output logic [63:0]          pf_s_data,
  output logic [7:0]           pf_s_keep,
  output logic                 pf_s_last,
  output logic                 pf_s_err,
  output logic [3:0]           pf_s_src,          // context index
  output logic [15:0]          pf_s_meta,         // domain of the context
  input  logic                 pf_m_valid,        // frames from PacketForge (egress), steered by m_queue
  output logic                 pf_m_ready,
  input  logic [63:0]          pf_m_data,
  input  logic [7:0]           pf_m_keep,
  input  logic                 pf_m_last,
  input  logic                 pf_m_err,
  input  logic [3:0]           pf_m_queue
);

  localparam int CW = (NCTX > 1) ? $clog2(NCTX) : 1;

  // elaboration-time parameter checks (an illegal configuration is refused, never silently built)
  if (NCTX < 1 || NCTX > 15)                                               begin : g_bad_nctx    $error("NCTX must be in [1, 15]"); end
  if (DOM_W < 1 || DOM_W > 16)                                             begin : g_bad_domw    $error("DOM_W must be in [1, 16]"); end
  if (TAGW < 1 || TAGW > 8)                                                begin : g_bad_tagw    $error("TAGW must be in [1, 8]"); end
  if ((MAX_QSZ & (MAX_QSZ - 1)) != 0 || MAX_QSZ < 2 || MAX_QSZ > VIRTQ_SPLIT_MAX_SIZE)
                                                                           begin : g_bad_qsz     $error("MAX_QSZ must be a power of two in [2, 32768]"); end
  if ((MAX_CHAIN & (MAX_CHAIN - 1)) != 0 || MAX_CHAIN < 4 || MAX_CHAIN > 64)
                                                                           begin : g_bad_chain   $error("MAX_CHAIN must be a power of two in [4, 64]"); end
  if ((N_WIN & (N_WIN - 1)) != 0 || N_WIN < 2 || N_WIN > 8)                begin : g_bad_win     $error("N_WIN must be a power of two in [2, 8] (window registers end at 0x140)"); end
  if (SADDR_W < 16 || SADDR_W > 56)                                        begin : g_bad_saddr   $error("SADDR_W must be in [16, 56]"); end
  if (FBYTES < 64 || FBYTES > 16384)                                       begin : g_bad_fbytes  $error("FBYTES must be in [64, 16384]"); end
  if (CHK_TMO < 1)                                                         begin : g_bad_chk     $error("CHK_TMO must be >= 1"); end

  // ---------------------------------------------------------------------------
  // Contexts
  // ---------------------------------------------------------------------------
  logic [NCTX-1:0]    cm_valid, cm_ready, cm_resp_valid, cm_we;
  logic [NCTX*32-1:0] cm_rdata;
  logic [NCTX-1:0]    d_req_valid, d_req_ready, d_req_we, d_resp_valid, d_resp_err;
  logic [NCTX*64-1:0] d_req_addr, d_req_wdata;
  logic [NCTX*8-1:0]  d_req_be;
  logic [NCTX*3-1:0]  d_req_tc;
  logic [NCTX*16-1:0] d_req_dom;
  logic [63:0]        d_resp_rdata;
  logic [NCTX-1:0]    b_flt_pulse, b_viol_pulse, b_err_pulse;
  logic               d_resp_err_b;
  logic [63:0]        b_flt_addr;
  logic               b_flt_write;
  logic [3:0]         b_flt_src;
  logic [7:0]         b_flt_code;

  logic [NCTX-1:0]      sc_valid, sc_ready, sc_resp_v, sc_resp_e;
  logic [NCTX*2-1:0]    sc_op;
  logic [NCTX*SADDR_W-1:0] sc_addr;
  logic [NCTX*64-1:0]   sc_wdata;
  logic [NCTX*8-1:0]    sc_be;
  logic [63:0]          sc_resp_d;
  logic [NCTX*16-1:0]   ctx_domain;
  logic [NCTX-1:0]      ctx_domain_valid;

  logic [NCTX-1:0]    tx_valid, tx_ready, tx_last, rx_valid;
  logic [NCTX*64-1:0] tx_data;
  logic [NCTX*8-1:0]  tx_keep;

  for (genvar k = 0; k < NCTX; k++) begin : g_ctx
    sf_virtual_ctx #(
      .DEV(CTX_KIND[k] ? DEV_NET : DEV_BLK), .MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN),
      .N_WIN(N_WIN), .SADDR_W(SADDR_W), .FBYTES(FBYTES), .BLK_ID(BLK_ID)
    ) u_ctx (
      .clk, .rst_n,
      .mmio_req_valid(mmio_req_valid[k]), .mmio_req_ready(mmio_req_ready[k]), .mmio_req_we(mmio_req_we[k]),
      .mmio_req_addr(mmio_req_addr[k*12 +: 12]), .mmio_req_wdata(mmio_req_wdata[k*32 +: 32]),
      .mmio_req_be(mmio_req_be[k*4 +: 4]), .mmio_resp_valid(mmio_resp_valid[k]),
      .mmio_resp_rdata(mmio_resp_rdata[k*32 +: 32]), .irq(irq[k]),
      .mgmt_req_valid(cm_valid[k]), .mgmt_req_ready(cm_ready[k]), .mgmt_req_we(mgmt_req_we),
      .mgmt_req_addr(mgmt_req_addr[11:0]), .mgmt_req_wdata,
      .mgmt_resp_valid(cm_resp_valid[k]), .mgmt_resp_rdata(cm_rdata[k*32 +: 32]),
      .d_req_valid(d_req_valid[k]), .d_req_ready(d_req_ready[k]), .d_req_addr(d_req_addr[k*64 +: 64]),
      .d_req_we(d_req_we[k]), .d_req_wdata(d_req_wdata[k*64 +: 64]), .d_req_be(d_req_be[k*8 +: 8]),
      .d_req_tc(d_req_tc[k*3 +: 3]), .d_req_dom(d_req_dom[k*16 +: 16]),
      .d_resp_valid(d_resp_valid[k]), .d_resp_rdata(d_resp_rdata), .d_resp_err(d_resp_err[k]),
      .b_flt_pulse(b_flt_pulse[k]), .b_viol_pulse(b_viol_pulse[k]), .b_err_pulse(b_err_pulse[k]),
      .b_flt_addr, .b_flt_write, .b_flt_src, .b_flt_code,
      .sc_req_valid(sc_valid[k]), .sc_req_ready(sc_ready[k]), .sc_req_op(sc_op[k*2 +: 2]),
      .sc_req_addr(sc_addr[k*SADDR_W +: SADDR_W]), .sc_req_wdata(sc_wdata[k*64 +: 64]),
      .sc_req_be(sc_be[k*8 +: 8]), .sc_resp_valid(sc_resp_v[k]), .sc_resp_rdata(sc_resp_d),
      .sc_resp_err(sc_resp_e[k]),
      .link_up(pf_link_up[k]),
      .pf_tx_valid(tx_valid[k]), .pf_tx_ready(tx_ready[k]), .pf_tx_data(tx_data[k*64 +: 64]),
      .pf_tx_keep(tx_keep[k*8 +: 8]), .pf_tx_last(tx_last[k]),
      .pf_rx_valid(rx_valid[k]), .pf_rx_data(pf_m_data), .pf_rx_keep(pf_m_keep), .pf_rx_last(pf_m_last),
      .pf_rx_err(pf_m_err),
      .ctx_domain(ctx_domain[k*16 +: 16]), .ctx_domain_valid(ctx_domain_valid[k])
    );
  end

  // ---------------------------------------------------------------------------
  // Bridge: arbitration, Citadel check, BridgeEngine master
  // ---------------------------------------------------------------------------
  logic [CW-1:0] cnt_ctx;
  logic [3:0]    cnt_idx;
  logic [31:0]   cnt_rdata, orphan_cnt;
  logic          cnt_clear, bridge_busy, bridge_isolated;

  sf_virtual_bridge #(.NCTX(NCTX), .DOM_W(DOM_W), .TAGW(TAGW), .CHK_TMO(CHK_TMO), .RSP_TMO(RSP_TMO)) u_bridge (
    .clk, .rst_n,
    .u_req_valid(d_req_valid), .u_req_ready(d_req_ready), .u_req_addr(d_req_addr), .u_req_we(d_req_we),
    .u_req_wdata(d_req_wdata), .u_req_be(d_req_be), .u_req_tc(d_req_tc), .u_req_dom(d_req_dom),
    .u_resp_valid(d_resp_valid), .u_resp_rdata(d_resp_rdata), .u_resp_err(d_resp_err_b),
    .cit_req_valid, .cit_req_ready, .cit_req_dom, .cit_req_priv, .cit_req_write, .cit_req_addr,
    .cit_rsp_valid, .cit_rsp_ok, .cit_rsp_fault,
    .bdg_req_valid, .bdg_req_ready, .bdg_req_op, .bdg_req_tag, .bdg_req_dom, .bdg_req_priv, .bdg_req_tc,
    .bdg_req_addr, .bdg_req_wdata, .bdg_req_wstrb,
    .bdg_rsp_valid, .bdg_rsp_ready, .bdg_rsp_tag, .bdg_rsp_dom, .bdg_rsp_op, .bdg_rsp_status, .bdg_rsp_rdata,
    .flt_pulse(b_flt_pulse), .viol_pulse(b_viol_pulse), .err_pulse(b_err_pulse),
    .flt_addr(b_flt_addr), .flt_write(b_flt_write), .flt_src(b_flt_src), .flt_code(b_flt_code),
    .cnt_ctx, .cnt_idx, .cnt_rdata, .cnt_clear, .busy(bridge_busy), .isolated(bridge_isolated),
    .orphan_cnt
  );
  assign d_resp_err = {NCTX{d_resp_err_b}};

  // ---------------------------------------------------------------------------
  // Storage arbiter: round robin over the block contexts, one request outstanding
  // ---------------------------------------------------------------------------
  logic            st_out, st_zombie, st_tmo_pulse, st_swallow;
  logic [31:0]     st_ctr, st_tmo_cnt;
  logic [CW-1:0]   st_owner, st_rr, st_gnt;
  logic            st_any;
  always_comb begin
    st_any = 1'b0;
    st_gnt = '0;
    for (int k = NCTX; k >= 1; k--) begin
      /* verilator lint_off UNUSEDSIGNAL */
      automatic int c = (int'(st_rr) + k) % NCTX;
      /* verilator lint_on UNUSEDSIGNAL */
      if (sc_valid[c]) begin st_any = 1'b1; st_gnt = CW'(c); end
    end
  end
  // A StorageCore that stops answering must not hang the guests: after ST_TMO cycles the request fails
  // with an error response and the storage port is ISOLATED (new requests are answered with an error
  // at once) until the late response arrives (it is consumed and dropped) or the system is reset.
  assign st_req_valid = st_any && !st_out && !st_zombie;
  assign st_req_op    = sc_op   [st_gnt*2 +: 2];
  assign st_req_addr  = sc_addr [st_gnt*SADDR_W +: SADDR_W];
  assign st_req_wdata = sc_wdata[st_gnt*64 +: 64];
  assign st_req_be    = sc_be   [st_gnt*8 +: 8];
  assign st_req_dom   = ctx_domain[st_gnt*16 +: 16];
  // fail-fast answer while isolated: accept the request and answer with an error in the next cycle
  logic            st_ff_v;
  logic [CW-1:0]   st_ff_o;
  always_comb begin
    sc_ready  = '0;
    sc_resp_v = '0;
    if (st_any && !st_out && !st_zombie) sc_ready[st_gnt] = st_req_ready;
    else if (st_any && !st_out && st_zombie && !st_ff_v) sc_ready[st_gnt] = 1'b1;
    if (st_out && st_resp_valid) sc_resp_v[st_owner] = 1'b1;
    if (st_tmo_pulse)            sc_resp_v[st_owner] = 1'b1;     // timed out: error response to the owner
    if (st_ff_v) sc_resp_v[st_ff_o] = 1'b1;
  end
  assign sc_resp_d = st_resp_rdata;
  assign sc_resp_e = {NCTX{st_resp_err || st_tmo_pulse || st_ff_v}};
  assign st_swallow = st_zombie && st_resp_valid && !st_out;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_out <= 1'b0; st_owner <= '0; st_rr <= CW'(NCTX - 1);
      st_zombie <= 1'b0; st_tmo_pulse <= 1'b0; st_ctr <= '0; st_tmo_cnt <= '0; st_ff_v <= 1'b0; st_ff_o <= '0;
    end else begin
      st_tmo_pulse <= 1'b0;
      st_ff_v      <= 1'b0;
      if (st_swallow) st_zombie <= 1'b0;                      // the late response: consumed, isolation ends
      if (!st_out && st_req_valid && st_req_ready) begin
        st_out <= 1'b1; st_owner <= st_gnt; st_rr <= st_gnt; st_ctr <= '0;
      end else if (st_out && st_resp_valid) begin
        st_out <= 1'b0;
      end else if (st_out) begin
        st_ctr <= st_ctr + 32'd1;
        if (ST_TMO != 0 && st_ctr >= 32'(ST_TMO)) begin
          st_out <= 1'b0; st_zombie <= 1'b1; st_tmo_pulse <= 1'b1; st_tmo_cnt <= st_tmo_cnt + 32'd1;
        end
      end else if (st_any && st_zombie && !st_ff_v) begin   // isolated: answer at once with an error
        st_ff_v <= 1'b1; st_ff_o <= st_gnt; st_rr <= st_gnt;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // PacketForge: frame-atomic transmit multiplexer, receive demultiplexer
  // ---------------------------------------------------------------------------
  logic            tx_lock;
  logic [CW-1:0]   tx_owner, tx_rr, tx_gnt, tx_sel;
  logic            tx_any;
  always_comb begin
    tx_any = 1'b0;
    tx_gnt = '0;
    for (int k = NCTX; k >= 1; k--) begin
      /* verilator lint_off UNUSEDSIGNAL */
      automatic int c = (int'(tx_rr) + k) % NCTX;
      /* verilator lint_on UNUSEDSIGNAL */
      if (tx_valid[c]) begin tx_any = 1'b1; tx_gnt = CW'(c); end
    end
    tx_sel = tx_lock ? tx_owner : tx_gnt;
  end
  assign pf_s_valid = tx_valid[tx_sel] && (tx_lock || tx_any);
  assign pf_s_data  = tx_data[tx_sel*64 +: 64];
  assign pf_s_keep  = tx_keep[tx_sel*8 +: 8];
  assign pf_s_last  = tx_last[tx_sel];
  assign pf_s_err   = 1'b0;                       // frames are store-and-forward: never partial
  assign pf_s_src   = 4'(tx_sel);
  assign pf_s_meta  = ctx_domain[tx_sel*16 +: 16];
  always_comb begin
    tx_ready = '0;
    if (pf_s_valid) tx_ready[tx_sel] = pf_s_ready;
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tx_lock <= 1'b0; tx_owner <= '0; tx_rr <= CW'(NCTX - 1);
    end else if (pf_s_valid && pf_s_ready) begin
      if (pf_s_last) begin tx_lock <= 1'b0; tx_rr <= tx_sel; end
      else           begin tx_lock <= 1'b1; tx_owner <= tx_sel; end
    end
  end

  // receive: ctx = m_queue; frames for a missing / non-network context are counted and dropped
  assign pf_m_ready = 1'b1;                       // the shared egress stream is never back-pressured
  logic [31:0] pf_unmatched;
  logic        rx_match;
  always_comb begin
    rx_valid = '0;
    rx_match = 1'b0;
    for (int k = 0; k < NCTX; k++)
      if (CTX_KIND[k] && pf_m_queue == 4'(k)) begin rx_valid[k] = pf_m_valid; rx_match = 1'b1; end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) pf_unmatched <= '0;
    else if (pf_m_valid && pf_m_last && !rx_match) pf_unmatched <= pf_unmatched + 32'd1;
  end

  // ---------------------------------------------------------------------------
  // Management bus: context pages and the global page
  // ---------------------------------------------------------------------------
  wire [3:0]  pg      = mgmt_req_addr[15:12];
  wire        pg_glob = (pg == 4'hF);
  wire        pg_ctx  = (pg < 4'(NCTX));
  wire [11:0] off     = mgmt_req_addr[11:0];

  always_comb begin
    cm_valid = '0;
    for (int k = 0; k < NCTX; k++) cm_valid[k] = mgmt_req_valid && pg_ctx && (pg == 4'(k));
  end
  assign cm_we = '0;   // (per-context write enables are the shared mgmt_req_we)
  assign mgmt_req_ready = 1'b1;

  // global page
  logic [31:0] grdata;
  wire  [3:0]  g_idx = off[5:2];
  assign cnt_ctx   = CW'(off[11:6] - 6'd4);      // 0xF100 + 0x40 * ctx
  assign cnt_idx   = g_idx;
  assign cnt_clear = mgmt_req_valid && mgmt_req_we && pg_glob && (off == 12'h014) && mgmt_req_wdata[0];
  always_comb begin
    grdata = 32'd0;
    if (off >= 12'h100 && off < (12'h100 + 12'(NCTX * 64))) begin
      grdata = cnt_rdata;
    end else begin
      case (off)
        12'h000: grdata = SFV_GLOBAL_ID;
        12'h004: grdata = {8'd0, SFV_VER_MAJOR, SFV_VER_MINOR, SFV_VER_PATCH};
        12'h008: grdata = {4'd0, 16'(CTX_KIND), 4'(DOM_W - 1), 4'(TAGW), 4'(NCTX)};
        12'h00c: grdata = {30'd0, bridge_isolated, bridge_busy};
        12'h010: grdata = orphan_cnt;
        12'h018: grdata = pf_unmatched;
        12'h01c: grdata = 32'(CHK_TMO);
        12'h020: grdata = 32'(RSP_TMO);
        12'h024: grdata = st_tmo_cnt;
        12'h028: grdata = 32'(ST_TMO);
        12'h02c: grdata = {31'd0, st_zombie};
        default: grdata = 32'd0;
      endcase
    end
  end

  // response routing: one request at a time; the page is remembered for the response cycle.  The
  // context pages register their own response data, so the data is selected in the response cycle.
  logic        resp_glob, resp_ctx, resp_rd;
  logic [3:0]  resp_pg;
  logic [31:0] g_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mgmt_resp_valid <= 1'b0;
      resp_pg         <= '0;
      resp_glob       <= 1'b0;
      resp_ctx        <= 1'b0;
      resp_rd         <= 1'b0;
      g_q             <= '0;
    end else begin
      mgmt_resp_valid <= mgmt_req_valid;
      resp_pg         <= pg;
      resp_glob       <= pg_glob;
      resp_ctx        <= pg_ctx;
      resp_rd         <= !mgmt_req_we;
      g_q             <= grdata;
    end
  end
  always_comb begin
    mgmt_resp_rdata = 32'd0;
    if (mgmt_resp_valid && resp_rd) begin
      if (resp_glob)     mgmt_resp_rdata = g_q;
      else if (resp_ctx) mgmt_resp_rdata = cm_rdata[resp_pg*32 +: 32];
    end
  end

  // unused observability taps
  logic unused_ok;
  assign unused_ok = ^{cm_ready, cm_resp_valid, cm_we, ctx_domain_valid};

endmodule
