// =============================================================================
// SilicaFlux Albion -- Project 87 -- VirtualFoundry :: sf_virtual_ctx_mgmt
//
// Privileged management page of ONE guest context (Keystone / ControlCore / hypervisor side, never
// mapped into a guest).  Provides:
//   * versioned identity and capability registers
//   * context -> protection-domain binding (locked while any queue of the context is enabled)
//   * device configuration owned by the hypervisor: storage extent {base, size, read-only}, MAC
//     (locked once the guest driver has started, because the guest may already have read it)
//   * access to the window table of the local gate
//   * host reset of the context
//   * fatal-cause and first-fault capture (sticky until cleared) with a fault counter
//   * performance counters (docs 06): descriptors, requests, DMA bytes, completion latency,
//     descriptor-walk latency, QUEUE WAITING TIME, interrupts raised / suppressed, backend stalls,
//     invalid requests, device-specific event counters
//
// DERIVED FROM Project 63 silicaflux_virtio_mgmt.sv (counters and capture logic); the register map is
// new.  runtime/virtual_foundry/include/vf_regs.h mirrors it and is checked mechanically against this file
// and sf_virtual_pkg.sv by tests/virtual_foundry/tools/check_regs.py (make check_regs).
// Register map: docs/virtual_foundry/02_REGISTER_MAP.md
// =============================================================================
module sf_virtual_ctx_mgmt
  import sf_virtual_pkg::*;
#(
  parameter int DEV       = DEV_BLK,
  parameter int NQ        = 1,
  parameter int N_WIN     = 8,
  parameter int MAX_QSZ   = 256,
  parameter int MAX_CHAIN = 16,
  localparam int WW = $clog2(N_WIN)
) (
  input  logic          clk,
  input  logic          rst_n,

  // ---- management bus (valid/ready, one response one cycle after acceptance) ----
  input  logic          mgmt_req_valid,
  output logic          mgmt_req_ready,
  input  logic          mgmt_req_we,
  input  logic [11:0]   mgmt_req_addr,
  input  logic [31:0]   mgmt_req_wdata,
  output logic          mgmt_resp_valid,
  output logic [31:0]   mgmt_resp_rdata,

  // ---- configuration out -------------------------------------------------------------
  output logic [15:0]   domain,
  output logic          domain_valid,
  output logic [63:0]   ext_base,
  output logic [63:0]   ext_size,
  output logic          ext_ro,
  output logic [47:0]   mac,
  output logic          host_rst_req,
  input  logic          host_rst_done,

  // ---- window table of the local gate ---------------------------------------------------
  output logic          cfg_we,
  output logic [WW-1:0] cfg_win,
  output logic [2:0]    cfg_field,
  output logic [31:0]   cfg_wdata,
  output logic [WW-1:0] cfg_rwin,
  output logic [2:0]    cfg_rfield,
  input  logic [31:0]   cfg_rdata,

  // ---- status in ------------------------------------------------------------------------------
  input  logic [NQ-1:0] q_ready,
  input  logic          engine_busy,
  input  logic          dev_active,
  input  logic          needs_reset,
  input  logic [7:0]    dev_status,
  input  logic          fatal_pulse,
  input  logic [7:0]    fatal_cause,

  // ---- fault capture (first fault is sticky) ----------------------------------------------
  input  logic          flt_pulse,
  input  logic [63:0]   flt_addr,
  input  logic          flt_write,
  input  logic [3:0]    flt_src,       // FS_*
  input  logic [7:0]    flt_code,      // F_* / ST_* detail
  input  logic          viol_pulse,    // permission violation (gate, descriptor pre-check, Citadel)

  // ---- events ----------------------------------------------------------------------------------
  input  logic [NQ-1:0] desc_pulse,
  input  logic [NQ-1:0] req_done_pulse,
  input  logic [NQ-1:0] head_pulse,
  input  logic [NQ*17-1:0] head_depth,
  input  logic [NQ-1:0] more_pending,
  input  logic [NQ-1:0] walk_busy,
  input  logic [NQ-1:0] notify_pulse,
  input  logic [NQ-1:0] irq_raised_pulse,
  input  logic [NQ-1:0] irq_suppressed_pulse,
  input  logic          dma_rd_beat,
  input  logic          dma_wr_beat,
  input  logic [3:0]    dma_beat_bytes,
  input  logic          stall,         // a DMA or backend request is back-pressured
  input  logic          be_wait,       // waiting for a backend response
  input  logic [7:0]    dev_ev,        // device-specific event pulses (adapter)
  input  logic          bridge_err_pulse   // BridgeEngine/Citadel error returned for a DMA beat of this context
);

  // ---------------------------------------------------------------------------
  // Register offsets
  // ---------------------------------------------------------------------------
  localparam logic [11:0] R_ID          = 12'h000;
  localparam logic [11:0] R_VER         = 12'h004;
  localparam logic [11:0] R_CAPS0       = 12'h008;
  localparam logic [11:0] R_CAPS1       = 12'h00c;
  localparam logic [11:0] R_DOMAIN      = 12'h010;
  localparam logic [11:0] R_STATUS      = 12'h014;
  localparam logic [11:0] R_FAULT_LO    = 12'h018;
  localparam logic [11:0] R_FAULT_HI    = 12'h01c;
  localparam logic [11:0] R_FAULT_INFO  = 12'h020;
  localparam logic [11:0] R_CTRL        = 12'h024;
  localparam logic [11:0] R_FAULT_CNT   = 12'h028;
  localparam logic [11:0] R_WIN_BASE    = 12'h040;     // + 0x20*i + 4*field
  localparam logic [11:0] R_EXT_SZ_LO   = 12'h180;
  localparam logic [11:0] R_EXT_SZ_HI   = 12'h184;
  localparam logic [11:0] R_EXT_BASE_LO = 12'h188;
  localparam logic [11:0] R_EXT_BASE_HI = 12'h18c;
  localparam logic [11:0] R_EXT_FLAGS   = 12'h190;
  localparam logic [11:0] R_MAC_LO      = 12'h194;
  localparam logic [11:0] R_MAC_HI      = 12'h198;
  localparam logic [11:0] R_PERF_BASE   = 12'h200;
  localparam logic [11:0] R_DEVCNT_BASE = 12'h300;

  // ---------------------------------------------------------------------------
  // Registers
  // ---------------------------------------------------------------------------
  logic        cfg_wr_ignored;
  logic [7:0]  last_cause;
  logic [63:0] fault_addr;
  logic        fault_write, fault_valid;
  logic [3:0]  fault_src;
  logic [7:0]  fault_code;
  logic [31:0] fault_cnt;

  wire wr = mgmt_req_valid && mgmt_req_we;
  wire [11:0] a = mgmt_req_addr;
  wire in_win = (a >= R_WIN_BASE) && (a < (R_WIN_BASE + 12'(32 * N_WIN)));
  wire [11:0] wofs = a - R_WIN_BASE;

  assign mgmt_req_ready = 1'b1;

  assign cfg_we     = wr && in_win && (wofs[4:2] <= 3'd5);
  assign cfg_win    = WW'(wofs >> 5);
  assign cfg_field  = wofs[4:2];
  assign cfg_wdata  = mgmt_req_wdata;
  assign cfg_rwin   = WW'(wofs >> 5);
  assign cfg_rfield = wofs[4:2];

  wire any_ready   = |q_ready;
  wire drv_started = (dev_status != 8'd0);

  // ---------------------------------------------------------------------------
  // Performance counters
  // ---------------------------------------------------------------------------
  logic [31:0] c_desc, c_req, c_irq, c_irq_sup, c_stall, c_viol, c_qd_max, c_qd_n;
  logic [31:0] c_notify, c_fatal, c_clat_max, c_wlat_max, c_qw_max, c_qw_n, c_invalid, c_bridge_err;
  logic [63:0] c_rd_bytes, c_wr_bytes, c_clat_sum, c_wlat_sum, c_qd_sum, c_busy, c_total, c_qw_sum, c_bewait;
  logic [31:0] c_dev [8];
  logic [31:0] cur_clat [NQ];
  logic [31:0] cur_wait [NQ];
  logic [NQ-1:0] in_req, wait_run, walk_busy_d;
  logic [31:0] cur_wlat [NQ];

  // ---------------------------------------------------------------------------
  // Read mux
  // ---------------------------------------------------------------------------
  logic [31:0] rdata;
  always_comb begin
    rdata = 32'd0;
    if (in_win) begin
      rdata = cfg_rdata;
    end else if (a >= R_DEVCNT_BASE && a < (R_DEVCNT_BASE + 12'h20)) begin
      rdata = c_dev[3'((a - R_DEVCNT_BASE) >> 2)];
    end else begin
      case (a)
        R_ID:         rdata = SFV_ENGINE_ID;
        R_VER:        rdata = {8'd0, SFV_VER_MAJOR, SFV_VER_MINOR, SFV_VER_PATCH};
        // CAPS0: [7:0] queues, [15:8] MAX_CHAIN, [23:16] N_WIN, [24] split ring, [25] packed ring,
        //        [26] indirect, [27] event_idx, [28] virtio multiqueue, [29] window table,
        //        [30] Citadel check path, [31] BridgeEngine path
        R_CAPS0:      rdata = {1'b1, 1'b1, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1, 8'(N_WIN), 8'(MAX_CHAIN), 8'(NQ)};
        R_CAPS1:      rdata = {(DEV == DEV_NET) ? VIRTIO_ID_NET[7:0] : VIRTIO_ID_BLOCK[7:0], 8'd0, 16'(MAX_QSZ)};
        R_DOMAIN:     rdata = {domain_valid, 15'd0, domain};
        // [0] busy [1] active [2] needs_reset [3] config write ignored (sticky) [15:8] last fatal cause
        // [23:16] device status [27:24] queue-ready bitmap
        R_STATUS:     rdata = {4'd0, 4'(q_ready), dev_status, last_cause, 4'd0, cfg_wr_ignored, needs_reset, dev_active, engine_busy};
        R_FAULT_LO:   rdata = fault_addr[31:0];
        R_FAULT_HI:   rdata = fault_addr[63:32];
        // [0] write [1] valid [7:4] source (FS_*) [15:8] detail code
        R_FAULT_INFO: rdata = {16'd0, fault_code, fault_src, 2'd0, fault_valid, fault_write};
        R_CTRL:       rdata = {31'd0, host_rst_req};
        R_FAULT_CNT:  rdata = fault_cnt;
        R_EXT_SZ_LO:  rdata = ext_size[31:0];
        R_EXT_SZ_HI:  rdata = ext_size[63:32];
        R_EXT_BASE_LO: rdata = ext_base[31:0];
        R_EXT_BASE_HI: rdata = ext_base[63:32];
        R_EXT_FLAGS:  rdata = {31'd0, ext_ro};
        R_MAC_LO:     rdata = mac[31:0];
        R_MAC_HI:     rdata = {16'd0, mac[47:32]};
        R_PERF_BASE + 12'h000: rdata = c_desc;
        R_PERF_BASE + 12'h004: rdata = c_req;
        R_PERF_BASE + 12'h008: rdata = c_rd_bytes[31:0];
        R_PERF_BASE + 12'h00c: rdata = c_rd_bytes[63:32];
        R_PERF_BASE + 12'h010: rdata = c_wr_bytes[31:0];
        R_PERF_BASE + 12'h014: rdata = c_wr_bytes[63:32];
        R_PERF_BASE + 12'h018: rdata = c_clat_sum[31:0];
        R_PERF_BASE + 12'h01c: rdata = c_clat_sum[63:32];
        R_PERF_BASE + 12'h020: rdata = c_clat_max;
        R_PERF_BASE + 12'h024: rdata = c_wlat_sum[31:0];
        R_PERF_BASE + 12'h028: rdata = c_wlat_sum[63:32];
        R_PERF_BASE + 12'h02c: rdata = c_wlat_max;
        R_PERF_BASE + 12'h030: rdata = c_irq;
        R_PERF_BASE + 12'h034: rdata = c_irq_sup;
        R_PERF_BASE + 12'h038: rdata = c_stall;
        R_PERF_BASE + 12'h03c: rdata = c_viol;
        R_PERF_BASE + 12'h040: rdata = c_qd_sum[31:0];
        R_PERF_BASE + 12'h044: rdata = c_qd_sum[63:32];
        R_PERF_BASE + 12'h048: rdata = c_qd_max;
        R_PERF_BASE + 12'h04c: rdata = c_qd_n;
        R_PERF_BASE + 12'h050: rdata = c_notify;
        R_PERF_BASE + 12'h054: rdata = c_fatal;
        R_PERF_BASE + 12'h058: rdata = c_busy[31:0];
        R_PERF_BASE + 12'h05c: rdata = c_busy[63:32];
        R_PERF_BASE + 12'h060: rdata = c_total[31:0];
        R_PERF_BASE + 12'h064: rdata = c_total[63:32];
        R_PERF_BASE + 12'h068: rdata = c_qw_sum[31:0];
        R_PERF_BASE + 12'h06c: rdata = c_qw_sum[63:32];
        R_PERF_BASE + 12'h070: rdata = c_qw_max;
        R_PERF_BASE + 12'h074: rdata = c_qw_n;
        R_PERF_BASE + 12'h078: rdata = c_invalid;
        R_PERF_BASE + 12'h07c: rdata = c_bewait[31:0];
        R_PERF_BASE + 12'h080: rdata = c_bewait[63:32];
        R_PERF_BASE + 12'h084: rdata = c_bridge_err;
        default:      rdata = 32'd0;
      endcase
    end
  end

  wire perf_clear = wr && (a == R_CTRL) && mgmt_req_wdata[1];
  wire flag_clear = wr && (a == R_CTRL) && mgmt_req_wdata[2];

  // ---------------------------------------------------------------------------
  // Configuration registers, fault capture
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mgmt_resp_valid <= 1'b0;
      mgmt_resp_rdata <= '0;
      domain          <= '0;
      domain_valid    <= 1'b0;
      ext_base        <= '0;
      ext_size        <= '0;
      ext_ro          <= 1'b0;
      mac             <= '0;
      cfg_wr_ignored  <= 1'b0;
      host_rst_req    <= 1'b0;
      last_cause      <= FC_NONE;
      fault_addr      <= '0;
      fault_write     <= 1'b0;
      fault_valid     <= 1'b0;
      fault_src       <= FS_NONE;
      fault_code      <= '0;
      fault_cnt       <= '0;
    end else begin
      mgmt_resp_valid <= mgmt_req_valid;
      mgmt_resp_rdata <= (mgmt_req_valid && !mgmt_req_we) ? rdata : 32'd0;

      if (wr && (a == R_DOMAIN)) begin
        if (!any_ready) begin
          domain       <= mgmt_req_wdata[15:0];
          domain_valid <= mgmt_req_wdata[31];
        end else begin
          cfg_wr_ignored <= 1'b1;     // binding is locked while a queue of the context is live
        end
      end
      if (wr && (a == R_EXT_SZ_LO || a == R_EXT_SZ_HI || a == R_EXT_BASE_LO || a == R_EXT_BASE_HI ||
                 a == R_EXT_FLAGS || a == R_MAC_LO || a == R_MAC_HI)) begin
        if (drv_started) begin
          cfg_wr_ignored <= 1'b1;     // the guest may already have read the configuration
        end else begin
          case (a)
            R_EXT_SZ_LO:   ext_size[31:0]  <= mgmt_req_wdata;
            R_EXT_SZ_HI:   ext_size[63:32] <= mgmt_req_wdata;
            R_EXT_BASE_LO: ext_base[31:0]  <= mgmt_req_wdata;
            R_EXT_BASE_HI: ext_base[63:32] <= mgmt_req_wdata;
            R_EXT_FLAGS:   ext_ro          <= mgmt_req_wdata[0];
            R_MAC_LO:      mac[31:0]       <= mgmt_req_wdata;
            R_MAC_HI:      mac[47:32]      <= mgmt_req_wdata[15:0];
            default: ;
          endcase
        end
      end
      if (wr && (a == R_CTRL) && mgmt_req_wdata[0]) host_rst_req <= 1'b1;
      if (host_rst_done) host_rst_req <= 1'b0;
      if (flag_clear) cfg_wr_ignored <= 1'b0;

      if (fatal_pulse) last_cause <= fatal_cause;
      if (flt_pulse) begin
        fault_cnt <= fault_cnt + 32'd1;
        if (!fault_valid) begin           // first fault is sticky until cleared
          fault_addr  <= flt_addr;
          fault_write <= flt_write;
          fault_src   <= flt_src;
          fault_code  <= flt_code;
          fault_valid <= 1'b1;
        end
      end
      if (flag_clear) begin
        fault_valid <= 1'b0;
        fault_cnt   <= '0;
        last_cause  <= FC_NONE;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Counters
  // ---------------------------------------------------------------------------
  logic [32:0] clat_add;
  logic [31:0] qd_add_n;
  logic [63:0] qd_add;
  logic [31:0] qw_add_n, qw_add;

  always_comb begin
    clat_add = '0;
    qd_add   = '0;
    qd_add_n = '0;
    for (int q = 0; q < NQ; q++) begin
      if (req_done_pulse[q] && in_req[q]) clat_add = clat_add + {1'b0, cur_clat[q]};
      if (head_pulse[q]) begin
        qd_add   = qd_add + {47'd0, head_depth[q*17 +: 17]};
        qd_add_n = qd_add_n + 32'd1;
      end
    end
    qw_add = '0; qw_add_n = '0;
    for (int q = 0; q < NQ; q++) begin
      if (head_pulse[q] && wait_run[q]) begin qw_add = qw_add + cur_wait[q]; qw_add_n = qw_add_n + 32'd1; end
    end
  end

  function automatic logic [31:0] cnt_pulses(input logic [NQ-1:0] v);
    logic [31:0] c;
    c = '0;
    for (int q = 0; q < NQ; q++) c = c + {31'd0, v[q]};
    return c;
  endfunction

  task automatic clear_counters();
    {c_desc, c_req, c_irq, c_irq_sup, c_stall, c_viol, c_qd_max, c_qd_n} <= '0;
    {c_notify, c_fatal, c_clat_max, c_wlat_max, c_qw_max, c_qw_n, c_invalid, c_bridge_err} <= '0;
    {c_rd_bytes, c_wr_bytes, c_clat_sum, c_wlat_sum, c_qd_sum, c_busy, c_total, c_qw_sum, c_bewait} <= '0;
    for (int i = 0; i < 8; i++) c_dev[i] <= '0;
    for (int q = 0; q < NQ; q++) begin cur_clat[q] <= '0; cur_wait[q] <= '0; cur_wlat[q] <= '0; end
    in_req <= '0; wait_run <= '0; walk_busy_d <= '0;
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      clear_counters();
    end else if (perf_clear) begin
      clear_counters();
    end else begin
      c_total <= c_total + 64'd1;
      if (engine_busy) c_busy   <= c_busy + 64'd1;
      if (stall)       c_stall  <= c_stall + 32'd1;
      if (be_wait)     c_bewait <= c_bewait + 64'd1;
      c_desc    <= c_desc + cnt_pulses(desc_pulse);
      c_req     <= c_req + cnt_pulses(req_done_pulse);
      c_irq     <= c_irq + cnt_pulses(irq_raised_pulse);
      c_irq_sup <= c_irq_sup + cnt_pulses(irq_suppressed_pulse);
      c_notify  <= c_notify + cnt_pulses(notify_pulse);
      if (fatal_pulse)  c_fatal  <= c_fatal + 32'd1;
      if (viol_pulse)   c_viol   <= c_viol + 32'd1;
      if (bridge_err_pulse) c_bridge_err <= c_bridge_err + 32'd1;
      // invalid requests: events that reject a guest-supplied request or buffer
      // (malformed ring/chain -> fatal, permission violation, request-level direction error)
      c_invalid <= c_invalid + {31'd0, fatal_pulse} + {31'd0, viol_pulse} + {31'd0, dev_ev[7]};
      for (int i = 0; i < 8; i++) if (dev_ev[i]) c_dev[i] <= c_dev[i] + 32'd1;
      if (dma_rd_beat) c_rd_bytes <= c_rd_bytes + {60'd0, dma_beat_bytes};
      if (dma_wr_beat) c_wr_bytes <= c_wr_bytes + {60'd0, dma_beat_bytes};

      // queue depth observed at each head fetch
      c_qd_sum <= c_qd_sum + qd_add;
      c_qd_n   <= c_qd_n + qd_add_n;
      for (int q = 0; q < NQ; q++)
        if (head_pulse[q] && ({15'd0, head_depth[q*17 +: 17]} > c_qd_max)) c_qd_max <= {15'd0, head_depth[q*17 +: 17]};

      // completion latency: head fetched -> used.idx published
      c_clat_sum <= c_clat_sum + {31'd0, clat_add};
      for (int q = 0; q < NQ; q++) begin
        if (head_pulse[q]) begin in_req[q] <= 1'b1; cur_clat[q] <= 32'd1; end
        else if (in_req[q]) cur_clat[q] <= cur_clat[q] + 32'd1;
        if (req_done_pulse[q] && in_req[q]) begin
          in_req[q] <= 1'b0;
          if (cur_clat[q] > c_clat_max) c_clat_max <= cur_clat[q];
        end
        if (fatal_pulse) in_req[q] <= 1'b0;
      end

      // queue waiting time: kick (or previous completion with a backlog) -> head fetch
      c_qw_sum <= c_qw_sum + {32'd0, qw_add};
      c_qw_n   <= c_qw_n + qw_add_n;
      for (int q = 0; q < NQ; q++) begin
        if (head_pulse[q] && wait_run[q]) begin
          wait_run[q] <= 1'b0;
          if (cur_wait[q] > c_qw_max) c_qw_max <= cur_wait[q];
        end else if (wait_run[q]) begin
          cur_wait[q] <= cur_wait[q] + 32'd1;
        end
        if (!wait_run[q] && !in_req[q] && notify_pulse[q]) begin wait_run[q] <= 1'b1; cur_wait[q] <= 32'd0; end
        else if (req_done_pulse[q] && more_pending[q])     begin wait_run[q] <= 1'b1; cur_wait[q] <= 32'd0; end
        if (fatal_pulse) wait_run[q] <= 1'b0;
      end

      // descriptor-walk latency
      walk_busy_d <= walk_busy;
      for (int q = 0; q < NQ; q++) begin
        if (walk_busy[q]) begin
          cur_wlat[q] <= cur_wlat[q] + 32'd1;
          c_wlat_sum  <= c_wlat_sum + 64'd1;
        end else if (walk_busy_d[q]) begin
          if (cur_wlat[q] > c_wlat_max) c_wlat_max <= cur_wlat[q];
          cur_wlat[q] <= '0;
        end
      end
    end
  end

endmodule
