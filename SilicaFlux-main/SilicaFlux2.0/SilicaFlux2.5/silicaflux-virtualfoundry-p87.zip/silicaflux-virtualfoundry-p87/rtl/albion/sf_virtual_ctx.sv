// =============================================================================
// SilicaFlux Albion -- Project 87 -- VirtualFoundry :: sf_virtual_ctx
//
// ONE guest context = one virtio device (block: 1 queue; network: receiveq 0 + transmitq 1) bound to
// ONE protection domain.  It owns everything that is per guest:
//
//   guest bus --> [transport] --> per queue: [queue controller] + [descriptor walker]
//                                                  |                    |
//                                           [device adapter: storage | network] --> backend port
//   every DMA client --> [round-robin arbiter, one beat outstanding] --> [window gate] --> d_* port
//   management page: [ctx_mgmt]  (domain binding, windows, extent, MAC, faults, counters, host reset)
//
// A context never shares state with another context: its own register window, its own interrupt, its
// own windows, its own rings, its own extent / frame buffers.  The only shared resources sit behind
// the d_* port (bridge: arbiter, Citadel, BridgeEngine) and the backend ports, and are arbitrated
// beat by beat so that one context cannot hold another's resources (docs 03_ISOLATION.md).
// =============================================================================
module sf_virtual_ctx
  import sf_virtual_pkg::*;
#(
  parameter int DEV       = DEV_BLK,
  parameter int MAX_QSZ   = 256,
  parameter int MAX_CHAIN = 16,
  parameter int N_WIN     = 8,
  parameter int SADDR_W   = 40,
  parameter int FBYTES    = 2048,                 // network: frame buffer bytes (store-and-forward)
  parameter logic [159:0] BLK_ID = "SILICAFLUX-VBLK-0001",
  localparam int NQ = (DEV == DEV_NET) ? 2 : 1,
  localparam int WW = $clog2(N_WIN)
) (
  input  logic               clk,
  input  logic               rst_n,

  // ---- guest-visible VirtIO MMIO window (4 KiB) and interrupt ------------------------------------
  input  logic               mmio_req_valid,
  output logic               mmio_req_ready,
  input  logic               mmio_req_we,
  input  logic [11:0]        mmio_req_addr,
  input  logic [31:0]        mmio_req_wdata,
  input  logic [3:0]         mmio_req_be,
  output logic               mmio_resp_valid,
  output logic [31:0]        mmio_resp_rdata,
  output logic               irq,

  // ---- privileged management page -----------------------------------------------------------------
  input  logic               mgmt_req_valid,
  output logic               mgmt_req_ready,
  input  logic               mgmt_req_we,
  input  logic [11:0]        mgmt_req_addr,
  input  logic [31:0]        mgmt_req_wdata,
  output logic               mgmt_resp_valid,
  output logic [31:0]        mgmt_resp_rdata,

  // ---- downstream DMA beats (window-checked) toward the bridge -------------------------------------
  output logic               d_req_valid,
  input  logic               d_req_ready,
  output logic [63:0]        d_req_addr,
  output logic               d_req_we,
  output logic [63:0]        d_req_wdata,
  output logic [7:0]         d_req_be,
  output logic [2:0]         d_req_tc,
  output logic [15:0]        d_req_dom,
  input  logic               d_resp_valid,
  input  logic [63:0]        d_resp_rdata,
  input  logic               d_resp_err,

  // ---- reports from the bridge for this context --------------------------------------------------------
  input  logic               b_flt_pulse,
  input  logic               b_viol_pulse,
  input  logic               b_err_pulse,
  input  logic [63:0]        b_flt_addr,
  input  logic               b_flt_write,
  input  logic [3:0]         b_flt_src,
  input  logic [7:0]         b_flt_code,

  // ---- block backend (StorageCore-style byte port, pre-arbitration) ---------------------------------------
  output logic               sc_req_valid,
  input  logic               sc_req_ready,
  output logic [1:0]         sc_req_op,
  output logic [SADDR_W-1:0] sc_req_addr,
  output logic [63:0]        sc_req_wdata,
  output logic [7:0]         sc_req_be,
  input  logic               sc_resp_valid,
  input  logic [63:0]        sc_resp_rdata,
  input  logic               sc_resp_err,

  // ---- network backend (PacketForge stream, pre-arbitration) ------------------------------------------------
  input  logic               link_up,
  output logic               pf_tx_valid,
  input  logic               pf_tx_ready,
  output logic [63:0]        pf_tx_data,
  output logic [7:0]         pf_tx_keep,
  output logic               pf_tx_last,
  input  logic               pf_rx_valid,
  input  logic [63:0]        pf_rx_data,
  input  logic [7:0]         pf_rx_keep,
  input  logic               pf_rx_last,
  input  logic               pf_rx_err,

  output logic [15:0]        ctx_domain,
  output logic               ctx_domain_valid
);

  // ---------------------------------------------------------------------------
  // Interconnect
  // ---------------------------------------------------------------------------
  logic [NQ-1:0]    drain, engine_idle, q_ready, notify_pulse, qc_idle, qc_fatal_pulse;
  logic [NQ-1:0]    used_irq_pulse, irq_sup_pulse, req_done_pulse, head_pulse, ring_fault_pulse, more_pending, work_pending;
  logic [NQ*8-1:0]  qc_fatal_cause;
  logic [NQ*17-1:0] head_depth;
  logic [NQ*16-1:0] q_size;
  logic [NQ*64-1:0] q_desc, q_driver, q_device;
  logic [63:0]      drv_features;
  logic             dev_active, needs_reset, cfg_fatal_pulse, reset_pulse;
  logic [7:0]       dev_status;
  logic             host_rst_req, host_rst_done;
  logic [NQ-1:0]    work_gate;

  logic [15:0]      domain;
  logic             domain_valid;
  logic [63:0]      ext_base, ext_size;
  logic             ext_ro;
  logic [47:0]      mac;

  // walker / adapter handshakes, per queue
  logic [NQ-1:0]    walk_start, walk_busy, walk_done, walk_fatal, desc_pulse, walk_viol_pulse, walk_fault_pulse;
  logic [NQ*16-1:0] walk_head;
  logic [NQ*8-1:0]  walk_cause;
  logic [NQ-1:0]    exec_start, exec_busy, exec_done, exec_fatal;
  logic [NQ*8-1:0]  exec_cause;
  logic [NQ*32-1:0] exec_used_len;
  logic [NQ*64-1:0] walk_fault_addr;

  localparam int CWW = $clog2(MAX_CHAIN + 1);
  localparam int SGW = $clog2(MAX_CHAIN);
  logic [CWW-1:0]   w_n_r [NQ];
  logic [CWW-1:0]   w_n_w [NQ];
  logic [31:0]      w_r_len [NQ];
  logic [31:0]      w_w_len [NQ];
  logic [NQ-1:0]    w_r_fault;
  logic [SGW-1:0]   w_seg_idx [NQ];
  logic [63:0]      w_seg_addr [NQ];
  logic [31:0]      w_seg_len [NQ];
  logic [NQ*64-1:0] chk_addr;
  logic [NQ*32-1:0] chk_len;
  logic [NQ-1:0]    chk_write, chk_ok;

  // DMA clients: 3 per queue = {queue controller, walker, adapter}
  localparam int NC = 3 * NQ;
  logic [NC-1:0]    c_req_valid, c_req_ready, c_req_we, c_resp_valid;
  logic [NC*64-1:0] c_req_addr, c_req_wdata;
  logic [NC*8-1:0]  c_req_be;
  logic [63:0]      c_resp_rdata;
  logic             c_resp_err, arb_busy;

  logic             m_req_valid, m_req_ready, m_req_we, m_resp_valid, m_resp_err;
  logic [63:0]      m_req_addr, m_req_wdata, m_resp_rdata;
  logic [7:0]       m_req_be;
  logic [2:0]       m_req_tc;

  logic             cfg_we;
  logic [WW-1:0]    cfg_win, cfg_rwin;
  logic [2:0]       cfg_field, cfg_rfield;
  logic [31:0]      cfg_wdata, cfg_rdata;
  logic             viol_dma_pulse, viol_dma_write;
  logic [63:0]      viol_dma_addr;

  logic [7:0]       dev_ev;
  logic             be_wait;

  assign ctx_domain       = domain;
  assign ctx_domain_valid = domain_valid;

  // ---------------------------------------------------------------------------
  // Transport
  // ---------------------------------------------------------------------------
  logic eng_fatal_pulse;
  assign eng_fatal_pulse = |qc_fatal_pulse;

  sf_virtual_transport #(.DEV(DEV), .NQ(NQ), .MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN)) u_transport (
    .clk, .rst_n,
    .mmio_req_valid, .mmio_req_ready, .mmio_req_we, .mmio_req_addr, .mmio_req_wdata, .mmio_req_be,
    .mmio_resp_valid, .mmio_resp_rdata, .irq,
    .cfg_capacity(ext_size), .cfg_ro(ext_ro), .cfg_mac(mac), .link_up,
    .host_rst_req, .host_rst_done,
    .engine_idle, .drain, .eng_fatal_pulse, .used_irq_pulse, .cfg_fatal_pulse, .reset_pulse,
    .q_ready, .q_size, .q_desc, .q_driver, .q_device, .dev_active, .notify_pulse,
    .drv_features, .needs_reset, .dev_status
  );

  // ---------------------------------------------------------------------------
  // Queues: controller + descriptor walker
  // ---------------------------------------------------------------------------
  for (genvar q = 0; q < NQ; q++) begin : g_q
    sf_virtual_queue #(.RXQ(DEV == DEV_NET && q == 0)) u_qc (
      .clk, .rst_n,
      .q_ready(q_ready[q]), .q_size(q_size[q*16 +: 16]), .q_driver(q_driver[q*64 +: 64]),
      .q_device(q_device[q*64 +: 64]), .dev_active, .domain_valid,
      .notify(notify_pulse[q]), .work_gate(work_gate[q]), .drain(drain[q]),
      .idle(qc_idle[q]), .more_pending(more_pending[q]), .work_pending(work_pending[q]),
      .fatal_pulse(qc_fatal_pulse[q]), .fatal_cause(qc_fatal_cause[q*8 +: 8]),
      .walk_start(walk_start[q]), .walk_head(walk_head[q*16 +: 16]), .walk_busy(walk_busy[q]),
      .walk_done(walk_done[q]), .walk_fatal(walk_fatal[q]), .walk_cause(walk_cause[q*8 +: 8]),
      .exec_start(exec_start[q]), .exec_busy(exec_busy[q]), .exec_done(exec_done[q]),
      .exec_fatal(exec_fatal[q]), .exec_cause(exec_cause[q*8 +: 8]), .exec_used_len(exec_used_len[q*32 +: 32]),
      .used_irq_pulse(used_irq_pulse[q]), .irq_suppressed_pulse(irq_sup_pulse[q]),
      .req_done_pulse(req_done_pulse[q]), .head_pulse(head_pulse[q]), .head_depth(head_depth[q*17 +: 17]),
      .ring_fault_pulse(ring_fault_pulse[q]),
      .dma_req_valid (c_req_valid[3*q]),            .dma_req_ready (c_req_ready[3*q]),
      .dma_req_addr  (c_req_addr[(3*q)*64 +: 64]),  .dma_req_we    (c_req_we[3*q]),
      .dma_req_wdata (c_req_wdata[(3*q)*64 +: 64]), .dma_req_be    (c_req_be[(3*q)*8 +: 8]),
      .dma_resp_valid(c_resp_valid[3*q]),           .dma_resp_rdata(c_resp_rdata),
      .dma_resp_err  (c_resp_err)
    );

    sf_virtual_descriptor #(.MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN)) u_walker (
      .clk, .rst_n,
      .start(walk_start[q]), .head(walk_head[q*16 +: 16]), .q_size(q_size[q*16 +: 16]),
      .q_desc(q_desc[q*64 +: 64]), .drain(drain[q]),
      .busy(walk_busy[q]), .done(walk_done[q]), .fatal(walk_fatal[q]), .cause(walk_cause[q*8 +: 8]),
      .n_r(w_n_r[q]), .n_w(w_n_w[q]), .r_len(w_r_len[q]), .w_len(w_w_len[q]), .r_fault(w_r_fault[q]),
      .seg_rd_idx(w_seg_idx[q]), .seg_rd_addr(w_seg_addr[q]), .seg_rd_len(w_seg_len[q]),
      .chk_addr(chk_addr[q*64 +: 64]), .chk_len(chk_len[q*32 +: 32]), .chk_write(chk_write[q]), .chk_ok(chk_ok[q]),
      .perm_viol_pulse(walk_viol_pulse[q]), .desc_pulse(desc_pulse[q]),
      .fault_pulse(walk_fault_pulse[q]), .fault_addr(walk_fault_addr[q*64 +: 64]),
      .dma_req_valid (c_req_valid[3*q+1]),              .dma_req_ready (c_req_ready[3*q+1]),
      .dma_req_addr  (c_req_addr[(3*q+1)*64 +: 64]),    .dma_req_we    (c_req_we[3*q+1]),
      .dma_req_wdata (c_req_wdata[(3*q+1)*64 +: 64]),   .dma_req_be    (c_req_be[(3*q+1)*8 +: 8]),
      .dma_resp_valid(c_resp_valid[3*q+1]),             .dma_resp_rdata(c_resp_rdata),
      .dma_resp_err  (c_resp_err)
    );
  end

  // ---------------------------------------------------------------------------
  // Device adapter
  // ---------------------------------------------------------------------------
  if (DEV == DEV_BLK) begin : g_blk
    assign work_gate = '1;
    sf_virtual_storage_adapter #(.MAX_CHAIN(MAX_CHAIN), .SADDR_W(SADDR_W), .BLK_ID(BLK_ID)) u_adapter (
      .clk, .rst_n,
      .start(exec_start[0]), .drain(drain[0]), .feat_flush(drv_features[VIRTIO_BLK_F_FLUSH]),
      .ext_base, .ext_size, .ext_ro, .ev(dev_ev), .be_wait,
      .busy(exec_busy[0]), .done(exec_done[0]), .fatal(exec_fatal[0]), .cause(exec_cause[7:0]),
      .used_len(exec_used_len[31:0]), .status_out(blk_status),
      .n_r(w_n_r[0]), .n_w(w_n_w[0]), .r_len(w_r_len[0]), .w_len(w_w_len[0]), .r_fault(w_r_fault[0]),
      .seg_rd_idx(w_seg_idx[0]), .seg_rd_addr(w_seg_addr[0]), .seg_rd_len(w_seg_len[0]),
      .dma_req_valid (c_req_valid[2]),   .dma_req_ready (c_req_ready[2]),
      .dma_req_addr  (c_req_addr[2*64 +: 64]), .dma_req_we (c_req_we[2]),
      .dma_req_wdata (c_req_wdata[2*64 +: 64]), .dma_req_be (c_req_be[2*8 +: 8]),
      .dma_resp_valid(c_resp_valid[2]),  .dma_resp_rdata(c_resp_rdata), .dma_resp_err(c_resp_err),
      .sc_req_valid, .sc_req_ready, .sc_req_op, .sc_req_addr, .sc_req_wdata, .sc_req_be,
      .sc_resp_valid, .sc_resp_rdata, .sc_resp_err
    );
    assign pf_tx_valid = 1'b0;
    assign pf_tx_data  = '0;
    assign pf_tx_keep  = '0;
    assign pf_tx_last  = 1'b0;
    logic [7:0] blk_status;
    logic unused_net;
    assign unused_net = ^{pf_tx_ready, pf_rx_valid, pf_rx_data, pf_rx_keep, pf_rx_last, pf_rx_err, blk_status, FBYTES, reset_pulse};
  end else begin : g_net
    // virtio-net: receiveq = queue 0 (device-initiated), transmitq = queue 1
    logic rx_work;
    assign work_gate[0] = rx_work;
    assign work_gate[1] = 1'b1;
    sf_virtual_network_adapter #(.MAX_CHAIN(MAX_CHAIN), .FBYTES(FBYTES)) u_adapter (
      .clk, .rst_n, .flush(reset_pulse), .rx_enable(dev_active && q_ready[0]),
      .rx_start(exec_start[0]), .rx_drain(drain[0]), .rx_busy(exec_busy[0]), .rx_done(exec_done[0]),
      .rx_fatal(exec_fatal[0]), .rx_cause(exec_cause[7:0]), .rx_used_len(exec_used_len[31:0]), .rx_work,
      .rx_n_r(w_n_r[0]), .rx_n_w(w_n_w[0]), .rx_r_len(w_r_len[0]), .rx_w_len(w_w_len[0]), .rx_r_fault(w_r_fault[0]),
      .rx_seg_idx(w_seg_idx[0]), .rx_seg_addr(w_seg_addr[0]), .rx_seg_len(w_seg_len[0]),
      .rx_dma_req_valid (c_req_valid[2]),        .rx_dma_req_ready (c_req_ready[2]),
      .rx_dma_req_addr  (c_req_addr[2*64 +: 64]), .rx_dma_req_we   (c_req_we[2]),
      .rx_dma_req_wdata (c_req_wdata[2*64 +: 64]), .rx_dma_req_be  (c_req_be[2*8 +: 8]),
      .rx_dma_resp_valid(c_resp_valid[2]),       .rx_dma_resp_rdata(c_resp_rdata), .rx_dma_resp_err(c_resp_err),
      .tx_start(exec_start[1]), .tx_drain(drain[1]), .tx_busy(exec_busy[1]), .tx_done(exec_done[1]),
      .tx_fatal(exec_fatal[1]), .tx_cause(exec_cause[15:8]), .tx_used_len(exec_used_len[63:32]),
      .tx_n_r(w_n_r[1]), .tx_n_w(w_n_w[1]), .tx_r_len(w_r_len[1]), .tx_w_len(w_w_len[1]), .tx_r_fault(w_r_fault[1]),
      .tx_seg_idx(w_seg_idx[1]), .tx_seg_addr(w_seg_addr[1]), .tx_seg_len(w_seg_len[1]),
      .tx_dma_req_valid (c_req_valid[5]),        .tx_dma_req_ready (c_req_ready[5]),
      .tx_dma_req_addr  (c_req_addr[5*64 +: 64]), .tx_dma_req_we   (c_req_we[5]),
      .tx_dma_req_wdata (c_req_wdata[5*64 +: 64]), .tx_dma_req_be  (c_req_be[5*8 +: 8]),
      .tx_dma_resp_valid(c_resp_valid[5]),       .tx_dma_resp_rdata(c_resp_rdata), .tx_dma_resp_err(c_resp_err),
      .pf_tx_valid, .pf_tx_ready, .pf_tx_data, .pf_tx_keep, .pf_tx_last,
      .pf_rx_valid, .pf_rx_data, .pf_rx_keep, .pf_rx_last, .pf_rx_err,
      .ev(dev_ev), .be_wait
    );
    assign sc_req_valid = 1'b0;
    assign sc_req_op    = '0;
    assign sc_req_addr  = '0;
    assign sc_req_wdata = '0;
    assign sc_req_be    = '0;
    logic unused_net;
    assign unused_net = ^{sc_req_ready, sc_resp_valid, sc_resp_rdata, sc_resp_err, drv_features, ext_base};
  end

  // ---------------------------------------------------------------------------
  // DMA arbiter and window gate
  // ---------------------------------------------------------------------------
  localparam logic [NC-1:0] PAYLOAD_MASK = {NQ{3'b100}};
  sf_virtual_dma_arb #(.N(NC), .PAYLOAD(PAYLOAD_MASK)) u_arb (
    .clk, .rst_n,
    .c_req_valid, .c_req_ready, .c_req_addr, .c_req_we, .c_req_wdata, .c_req_be,
    .c_resp_valid, .c_resp_rdata, .c_resp_err,
    .m_req_valid, .m_req_ready, .m_req_addr, .m_req_we, .m_req_wdata, .m_req_be, .m_req_tc,
    .m_resp_valid, .m_resp_rdata, .m_resp_err,
    .busy(arb_busy)
  );

  sf_virtual_gate #(.N_WIN(N_WIN), .NCHK(NQ)) u_gate (
    .clk, .rst_n,
    .cfg_we, .cfg_win, .cfg_field, .cfg_wdata, .cfg_rwin, .cfg_rfield, .cfg_rdata,
    .domain, .domain_valid,
    .chk_addr, .chk_len, .chk_write, .chk_ok,
    .up_req_valid(m_req_valid), .up_req_ready(m_req_ready), .up_req_addr(m_req_addr),
    .up_req_we(m_req_we), .up_req_wdata(m_req_wdata), .up_req_be(m_req_be), .up_req_tc(m_req_tc),
    .up_resp_valid(m_resp_valid), .up_resp_rdata(m_resp_rdata), .up_resp_err(m_resp_err),
    .dn_req_valid(d_req_valid), .dn_req_ready(d_req_ready), .dn_req_addr(d_req_addr),
    .dn_req_we(d_req_we), .dn_req_wdata(d_req_wdata), .dn_req_be(d_req_be), .dn_req_tc(d_req_tc),
    .dn_req_domain(d_req_dom),
    .dn_resp_valid(d_resp_valid), .dn_resp_rdata(d_resp_rdata), .dn_resp_err(d_resp_err),
    .viol_pulse(viol_dma_pulse), .viol_addr(viol_dma_addr), .viol_write(viol_dma_write)
  );

  // ---------------------------------------------------------------------------
  // Engine-level status and management page
  // ---------------------------------------------------------------------------
  always_comb begin
    for (int q = 0; q < NQ; q++)
      engine_idle[q] = qc_idle[q] && !walk_busy[q] && !exec_busy[q] && !arb_busy && !c_req_valid[3*q];
  end

  // fault capture: bridge (Citadel / BridgeEngine) > window gate > descriptor pre-check
  logic        flt_pulse, flt_write_o, viol_any;
  logic [63:0] flt_addr_o;
  logic [3:0]  flt_src_o;
  logic [7:0]  flt_code_o;
  logic        w_viol_any, w_viol_q0;
  always_comb begin
    w_viol_any = |walk_viol_pulse;
    w_viol_q0  = walk_viol_pulse[0];
    viol_any   = viol_dma_pulse || w_viol_any || b_viol_pulse;
    flt_pulse  = b_flt_pulse || viol_dma_pulse || w_viol_any;
    if (b_flt_pulse) begin
      flt_addr_o = b_flt_addr; flt_write_o = b_flt_write; flt_src_o = b_flt_src; flt_code_o = b_flt_code;
    end else if (viol_dma_pulse) begin
      flt_addr_o = viol_dma_addr; flt_write_o = viol_dma_write; flt_src_o = FS_GATE; flt_code_o = 8'd0;
    end else begin
      flt_addr_o = w_viol_q0 ? walk_fault_addr[63:0] : walk_fault_addr[(NQ-1)*64 +: 64];
      flt_write_o = 1'b0; flt_src_o = FS_DESC; flt_code_o = 8'd0;
    end
  end

  logic [NQ-1:0] qc_fatal_any;
  logic          any_fatal;
  logic [7:0]    any_cause;
  always_comb begin
    any_fatal = |qc_fatal_pulse || cfg_fatal_pulse;
    any_cause = FC_QUEUE_CFG;
    for (int q = NQ - 1; q >= 0; q--) if (qc_fatal_pulse[q]) any_cause = qc_fatal_cause[q*8 +: 8];
    qc_fatal_any = qc_fatal_pulse;
  end

  logic [3:0] beat_bytes;
  assign beat_bytes = sfv_pop8(d_req_be);
  wire dn_acc = d_req_valid && d_req_ready;
  wire stall  = (d_req_valid && !d_req_ready) || (sc_req_valid && !sc_req_ready);

  sf_virtual_ctx_mgmt #(.DEV(DEV), .NQ(NQ), .N_WIN(N_WIN), .MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN)) u_mgmt (
    .clk, .rst_n,
    .mgmt_req_valid, .mgmt_req_ready, .mgmt_req_we, .mgmt_req_addr, .mgmt_req_wdata,
    .mgmt_resp_valid, .mgmt_resp_rdata,
    .domain, .domain_valid, .ext_base, .ext_size, .ext_ro, .mac, .host_rst_req, .host_rst_done,
    .cfg_we, .cfg_win, .cfg_field, .cfg_wdata, .cfg_rwin, .cfg_rfield, .cfg_rdata,
    .q_ready, .engine_busy(!(&engine_idle) || (|(work_pending & q_ready) && dev_active)), .dev_active, .needs_reset, .dev_status,
    .fatal_pulse(any_fatal), .fatal_cause(any_cause),
    .flt_pulse, .flt_addr(flt_addr_o), .flt_write(flt_write_o), .flt_src(flt_src_o), .flt_code(flt_code_o),
    .viol_pulse(viol_any),
    .desc_pulse, .req_done_pulse, .head_pulse, .head_depth, .more_pending, .walk_busy,
    .notify_pulse, .irq_raised_pulse(used_irq_pulse), .irq_suppressed_pulse(irq_sup_pulse),
    .dma_rd_beat(dn_acc && !d_req_we), .dma_wr_beat(dn_acc && d_req_we), .dma_beat_bytes(beat_bytes),
    .stall, .be_wait, .dev_ev, .bridge_err_pulse(b_err_pulse)
  );

  // unused observability taps
  logic unused_ok;
  assign unused_ok = ^{ring_fault_pulse, walk_fault_pulse, qc_fatal_any};

endmodule
