// =============================================================================
// SilicaFlux Albion -- Project 87 -- VirtualFoundry :: sf_virtual_storage_adapter
//
// virtio-blk request execution (VirtIO 1.2 s5.2.6) over a StorageCore-style byte port.
//
// DERIVED FROM Project 63 silicaflux_virtio_blk_backend.sv (docs/virtual_foundry/00_AUDIT.md lists
// every difference).  Changes: the exported capacity is a per-context EXTENT {ext_base, ext_size,
// ext_ro} programmed by the privileged management plane instead of a build parameter, so a guest
// can reach only its own slice of the storage; request-level DIRECTION checks (IN must not carry a
// readable payload, OUT must not carry a writable one) complete with VIRTIO_BLK_S_IOERR; a
// read-only extent refuses OUT; per-request event pulses for the performance counters.
//
// Message framing (s2.6.4 / s2.7.4): no assumption about how the driver splits a request across
// descriptors.  The chain is two byte streams:
//   R = device-readable segments: [0..15] struct virtio_blk_req header { le32 type; le32 reserved;
//       le64 sector; }, then the OUT payload
//   W = device-writable segments: [0..W-2] IN payload / GET_ID string, [W-1] status byte
//
// Completion contract (s2.7.8.2: the device MUST write at least `len` bytes starting at the first
// device-writable buffer): the whole writable stream is written before completing -- payload where
// there is payload, zeros elsewhere, status in the last byte -- so used.len is exactly W for every
// completion, success or error.
//
// DURABILITY (docs 01 s8): requests are executed one at a time and strictly in order.  A completion
// is never published before every storage response of that request has returned; a FLUSH request
// issues exactly one SC_OP_FLUSH and completes only after its response, with IOERR if the storage
// reports an error.  The adapter never acknowledges a write or flush that storage did not
// acknowledge, and never reorders a write across a later flush.
//
// Supported request types: IN, OUT, FLUSH (only if VIRTIO_BLK_F_FLUSH was negotiated), GET_ID.
// Every other type completes with VIRTIO_BLK_S_UNSUPP.
//
// Copy engine: one step moves n <= 8 bytes and never crosses a guest segment boundary, a guest
// 8-byte word, or a storage 8-byte word, so any buffer alignment works by lane shifting.
// =============================================================================
module sf_virtual_storage_adapter
  import sf_virtual_pkg::*;
#(
  parameter int           MAX_CHAIN        = 16,
  parameter int           SADDR_W          = 40,
  parameter logic [159:0] BLK_ID           = "SILICAFLUX-VBLK-0001",
  localparam int SW = $clog2(MAX_CHAIN),
  localparam int CW = $clog2(MAX_CHAIN + 1)
) (
  input  logic               clk,
  input  logic               rst_n,

  input  logic               start,
  input  logic               drain,
  input  logic               feat_flush,
  input  logic [63:0]        ext_base,      // extent start, in 512-byte sectors
  input  logic [63:0]        ext_size,      // extent size, in sectors (the exported capacity)
  input  logic               ext_ro,        // read-only extent
  output logic [7:0]         ev,            // completion event pulses (see ev_calc)
  output logic               be_wait,       // waiting for a storage response

  output logic               busy,
  output logic               done,
  output logic               fatal,
  output logic [7:0]         cause,
  output logic [31:0]        used_len,
  output logic [7:0]         status_out,

  input  logic [CW-1:0]      n_r,
  input  logic [CW-1:0]      n_w,
  input  logic [31:0]        r_len,
  input  logic [31:0]        w_len,
  input  logic               r_fault,
  output logic [SW-1:0]      seg_rd_idx,
  input  logic [63:0]        seg_rd_addr,
  input  logic [31:0]        seg_rd_len,

  output logic               dma_req_valid,
  input  logic               dma_req_ready,
  output logic [63:0]        dma_req_addr,
  output logic               dma_req_we,
  output logic [63:0]        dma_req_wdata,
  output logic [7:0]         dma_req_be,
  input  logic               dma_resp_valid,
  input  logic [63:0]        dma_resp_rdata,
  input  logic               dma_resp_err,

  output logic               sc_req_valid,
  input  logic               sc_req_ready,
  output logic [1:0]         sc_req_op,
  output logic [SADDR_W-1:0] sc_req_addr,
  output logic [63:0]        sc_req_wdata,
  output logic [7:0]         sc_req_be,
  input  logic               sc_resp_valid,
  input  logic [63:0]        sc_resp_rdata,
  input  logic               sc_resp_err
);

  wire [63:0] CAP = ext_size;
  // the extent must lie inside the storage address space; otherwise every I/O request fails
  /* verilator lint_off UNUSEDSIGNAL */
  wire [64:0] ext_end  = {1'b0, ext_base} + {1'b0, ext_size};
  /* verilator lint_on UNUSEDSIGNAL */
  wire        ext_ok   = (ext_end <= (65'd1 << (SADDR_W - 9)));

  // ---------------------------------------------------------------------------
  // Phases and step states
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {PH_HDR, PH_OUT, PH_IN, PH_ID, PH_ZERO, PH_STATUS} phase_t;
  typedef enum logic [3:0] {
    B_IDLE, B_START, B_DECODE, B_FLUSH,
    X_CALC, X_SRC_DMA, X_SRC_SC, X_DST, X_DST_DMA, X_DST_SC, X_ADV
  } bstate_t;

  bstate_t       st;
  phase_t        ph;
  logic          dwait, swait;

  logic [CW-1:0] ridx, widx;          // segment cursors
  logic [31:0]   roff, woff;          // offset within current segment
  logic [31:0]   rem;                 // bytes left in phase
  logic [31:0]   k;                   // byte offset within phase (HDR / ID)
  logic [31:0]   wpos;                // bytes of W already written
  logic [SADDR_W-1:0] saddr;          // storage byte address
  /* verilator lint_off UNUSEDSIGNAL */
  logic [127:0]  hdr;                 // [63:32] 'reserved' header field is ignored
  /* verilator lint_on UNUSEDSIGNAL */
  logic [7:0]    status_q;
  typedef enum logic [2:0] {K_NONE, K_IN, K_OUT, K_FLUSH, K_GETID, K_OTHER} kind_t;
  kind_t         kind_q;
  logic          dir_bad_q, sc_err_q;

  // step registers
  logic [3:0]    n;
  logic [63:0]   gaddr;
  logic [63:0]   dbuf;                // payload of the step, at lane 0

  wire r_side = (ph == PH_HDR) || (ph == PH_OUT);
  /* verilator lint_off UNUSEDSIGNAL */
  wire [CW-1:0] cur_idx = r_side ? ridx : widx;   // MSB only set once the stream is exhausted
  /* verilator lint_on UNUSEDSIGNAL */
  assign seg_rd_idx = cur_idx[SW-1:0];
  wire [31:0] cur_off   = r_side ? roff : woff;

  // ---------------------------------------------------------------------------
  // Step size: min(rem, bytes to end of segment, bytes to end of guest word,
  //                bytes to end of storage word if storage is involved)
  // ---------------------------------------------------------------------------
  wire [63:0] g_now     = seg_rd_addr + {32'd0, cur_off};
  wire [31:0] seg_left  = seg_rd_len - cur_off;
  wire [3:0]  g_word    = 4'd8 - {1'b0, g_now[2:0]};
  wire [3:0]  s_word    = 4'd8 - {1'b0, saddr[2:0]};
  wire        uses_sc   = (ph == PH_OUT) || (ph == PH_IN);
  wire [3:0]  rem8      = (rem      < 32'd8) ? rem[3:0]      : 4'd8;
  wire [3:0]  seg8      = (seg_left < 32'd8) ? seg_left[3:0] : 4'd8;
  wire [3:0]  n_calc    = sfv_min4(sfv_min4(rem8, seg8), sfv_min4(g_word, uses_sc ? s_word : 4'd8));

  // ID-string bytes [k .. k+7] (zero past VIRTIO_BLK_ID_BYTES)
  function automatic logic [7:0] id_byte(input logic [31:0] j);
    if (j < 32'(VIRTIO_BLK_ID_BYTES)) return BLK_ID[(19 - j[4:0]) * 8 +: 8];
    return 8'd0;
  endfunction
  logic [63:0] id_word;
  always_comb begin
    for (int i = 0; i < 8; i++) id_word[i*8 +: 8] = id_byte(k + 32'(i));
  end

  // ---------------------------------------------------------------------------
  // Request decode helpers
  // ---------------------------------------------------------------------------
  wire [31:0] h_type   = hdr[31:0];
  wire [63:0] h_sector = hdr[127:64];
  wire [31:0] in_len   = w_len - 32'd1;
  wire [31:0] out_len  = r_len - 32'd16;
  function automatic logic range_ok(input logic [63:0] sector, input logic [31:0] len);
    logic [63:0] nsec;
    nsec = {41'd0, len[31:9]};
    return (len[8:0] == 9'd0) && (sector <= CAP) && (nsec <= (CAP - sector));
  endfunction
  wire [31:0] id_len   = (in_len < 32'(VIRTIO_BLK_ID_BYTES)) ? in_len : 32'(VIRTIO_BLK_ID_BYTES);

  // ---------------------------------------------------------------------------
  // Port drive
  // ---------------------------------------------------------------------------
  assign busy = (st != B_IDLE);

  assign dma_req_valid = ((st == X_SRC_DMA) || (st == X_DST_DMA)) && !dwait;
  assign dma_req_addr  = {gaddr[63:3], 3'b000};
  assign dma_req_we    = (st == X_DST_DMA);
  assign dma_req_be    = sfv_be(n, gaddr[2:0]);
  assign dma_req_wdata = dbuf << {gaddr[2:0], 3'b000};

  assign sc_req_valid  = ((st == X_SRC_SC) || (st == X_DST_SC) || (st == B_FLUSH)) && !swait;
  assign sc_req_op     = (st == B_FLUSH) ? SC_OP_FLUSH : ((st == X_DST_SC) ? SC_OP_WRITE : SC_OP_READ);
  assign sc_req_addr   = (st == B_FLUSH) ? '0 : {saddr[SADDR_W-1:3], 3'b000};
  assign sc_req_be     = (st == B_FLUSH) ? 8'h00 : sfv_be(n, saddr[2:0]);
  assign sc_req_wdata  = dbuf << {saddr[2:0], 3'b000};

  wire dresp = dwait && dma_resp_valid;
  wire sresp = swait && sc_resp_valid;

  assign status_out = status_q;
  assign be_wait    = swait;

  // completion events (one pulse per completed request): [0] IN ok, [1] OUT ok, [2] FLUSH ok,
  // [3] GET_ID ok, [4] IOERR, [5] UNSUPP, [6] storage error seen, [7] direction error
  logic [7:0] ev_calc;
  always_comb begin
    ev_calc[0] = (kind_q == K_IN)    && (status_q == VIRTIO_BLK_S_OK);
    ev_calc[1] = (kind_q == K_OUT)   && (status_q == VIRTIO_BLK_S_OK);
    ev_calc[2] = (kind_q == K_FLUSH) && (status_q == VIRTIO_BLK_S_OK);
    ev_calc[3] = (kind_q == K_GETID) && (status_q == VIRTIO_BLK_S_OK);
    ev_calc[4] = (status_q == VIRTIO_BLK_S_IOERR);
    ev_calc[5] = (status_q == VIRTIO_BLK_S_UNSUPP);
    ev_calc[6] = sc_err_q;
    ev_calc[7] = dir_bad_q;
  end

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  task automatic start_phase(input phase_t p, input logic [31:0] len);
    ph  <= p;
    rem <= len;
    k   <= '0;
    st  <= X_CALC;
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st       <= B_IDLE;
      ph       <= PH_HDR;
      dwait    <= 1'b0;
      swait    <= 1'b0;
      ridx     <= '0;
      widx     <= '0;
      roff     <= '0;
      woff     <= '0;
      rem      <= '0;
      k        <= '0;
      wpos     <= '0;
      saddr    <= '0;
      hdr      <= '0;
      status_q <= VIRTIO_BLK_S_OK;
      kind_q   <= K_NONE;
      dir_bad_q <= 1'b0;
      sc_err_q <= 1'b0;
      ev       <= '0;
      n        <= '0;
      gaddr    <= '0;
      dbuf     <= '0;
      done     <= 1'b0;
      fatal    <= 1'b0;
      cause    <= FC_NONE;
      used_len <= '0;
    end else begin
      done <= 1'b0;
      ev   <= '0;
      if (sc_resp_valid && swait && sc_resp_err) sc_err_q <= 1'b1;

      if (dma_req_valid && dma_req_ready) dwait <= 1'b1;
      if (dresp) dwait <= 1'b0;
      if (sc_req_valid && sc_req_ready) swait <= 1'b1;
      if (sresp) swait <= 1'b0;

      case (st)
        // ---------------------------------------------------------------------
        B_IDLE: if (start) begin
          ridx     <= '0;
          widx     <= n_r;
          roff     <= '0;
          woff     <= '0;
          wpos     <= '0;
          hdr      <= '0;
          fatal    <= 1'b0;
          cause    <= FC_NONE;
          status_q <= VIRTIO_BLK_S_OK;
          kind_q   <= K_NONE;
          dir_bad_q <= 1'b0;
          sc_err_q <= 1'b0;
          st       <= B_START;
        end

        B_START: begin
          if (drain) begin
            st <= B_IDLE;
          end else if (n_w == '0) begin
            fatal <= 1'b1; cause <= FC_NO_STATUS; done <= 1'b1; st <= B_IDLE;
          end else if (r_fault || (r_len < 32'd16)) begin
            status_q <= VIRTIO_BLK_S_IOERR;
            start_phase(PH_ZERO, w_len - 32'd1);
          end else begin
            start_phase(PH_HDR, 32'd16);
          end
        end

        // ---------------------------------------------------------------------
        B_DECODE: begin
          if (drain) begin
            st <= B_IDLE;
          end else if (h_type == VIRTIO_BLK_T_IN) begin
            kind_q <= K_IN;
            if (r_len != 32'd16) begin                 // a readable payload on an IN request: direction error
              status_q <= VIRTIO_BLK_S_IOERR; dir_bad_q <= 1'b1;
              start_phase(PH_ZERO, in_len);
            end else if (ext_ok && range_ok(h_sector, in_len)) begin
              saddr <= SADDR_W'((ext_base + h_sector) << 9);
              start_phase(PH_IN, in_len);
            end else begin
              status_q <= VIRTIO_BLK_S_IOERR;
              start_phase(PH_ZERO, in_len);
            end
          end else if (h_type == VIRTIO_BLK_T_OUT) begin
            kind_q <= K_OUT;
            if (w_len != 32'd1) begin                  // a writable payload on an OUT request: direction error
              status_q <= VIRTIO_BLK_S_IOERR; dir_bad_q <= 1'b1;
              start_phase(PH_ZERO, in_len);
            end else if (ext_ro || !ext_ok || !range_ok(h_sector, out_len)) begin
              status_q <= VIRTIO_BLK_S_IOERR;          // read-only extent / bad range: nothing is read or stored
              start_phase(PH_ZERO, in_len);
            end else begin
              saddr <= SADDR_W'((ext_base + h_sector) << 9);
              start_phase(PH_OUT, out_len);
            end
          end else if (h_type == VIRTIO_BLK_T_FLUSH) begin
            kind_q <= K_FLUSH;
            if (!feat_flush) begin
              status_q <= VIRTIO_BLK_S_UNSUPP;
              start_phase(PH_ZERO, in_len);
            end else if (r_len != 32'd16) begin        // FLUSH carries no payload
              status_q <= VIRTIO_BLK_S_IOERR; dir_bad_q <= 1'b1;
              start_phase(PH_ZERO, in_len);
            end else begin
              st <= B_FLUSH;
            end
          end else if (h_type == VIRTIO_BLK_T_GET_ID) begin
            kind_q <= K_GETID;
            if (r_len != 32'd16) begin
              status_q <= VIRTIO_BLK_S_IOERR; dir_bad_q <= 1'b1;
              start_phase(PH_ZERO, in_len);
            end else begin
              start_phase(PH_ID, id_len);
            end
          end else begin
            kind_q   <= K_OTHER;
            status_q <= VIRTIO_BLK_S_UNSUPP;
            start_phase(PH_ZERO, in_len);
          end
        end

        B_FLUSH: if (sresp) begin
          if (sc_resp_err) status_q <= VIRTIO_BLK_S_IOERR;
          if (drain) st <= B_IDLE;
          else       start_phase(PH_ZERO, in_len);
        end

        // ---------------------------------------------------------------------
        // Copy-engine step
        // ---------------------------------------------------------------------
        X_CALC: begin
          if (drain) begin
            st <= B_IDLE;
          end else if (rem == 32'd0) begin
            // phase complete
            case (ph)
              PH_HDR:    st <= B_DECODE;
              PH_OUT,
              PH_IN,
              PH_ID:     start_phase(PH_ZERO, in_len - wpos);
              PH_ZERO:   start_phase(PH_STATUS, 32'd1);
              PH_STATUS: begin
                used_len <= w_len;
                done     <= 1'b1;
                ev       <= ev_calc;
                st       <= B_IDLE;
              end
              default:   st <= B_IDLE;
            endcase
          end else begin
            n     <= n_calc;
            gaddr <= g_now;
            case (ph)
              PH_HDR, PH_OUT: st <= X_SRC_DMA;
              PH_IN:          st <= X_SRC_SC;
              PH_ID:     begin dbuf <= id_word;              st <= X_DST; end
              PH_ZERO:   begin dbuf <= 64'd0;                st <= X_DST; end
              PH_STATUS: begin dbuf <= {56'd0, status_q};    st <= X_DST; end
              default:   st <= B_IDLE;
            endcase
          end
        end

        X_SRC_DMA: if (dresp) begin
          if (dma_resp_err || drain) begin
            // readable stream unreadable: IOERR, finish the writable stream
            status_q <= VIRTIO_BLK_S_IOERR;
            if (drain) st <= B_IDLE;
            else       start_phase(PH_ZERO, in_len - wpos);
          end else begin
            dbuf <= dma_resp_rdata >> {gaddr[2:0], 3'b000};
            st   <= X_DST;
          end
        end

        X_SRC_SC: if (sresp) begin
          if (sc_resp_err || drain) begin
            status_q <= VIRTIO_BLK_S_IOERR;
            if (drain) st <= B_IDLE;
            else       start_phase(PH_ZERO, in_len - wpos);
          end else begin
            dbuf <= sc_resp_rdata >> {saddr[2:0], 3'b000};
            st   <= X_DST;
          end
        end

        X_DST: begin
          case (ph)
            PH_HDR: begin
              for (int i = 0; i < 8; i++)
                if (4'(i) < n) hdr[(k[3:0] + 4'(i)) * 8 +: 8] <= dbuf[i*8 +: 8];
              st <= X_ADV;
            end
            PH_OUT:  st <= X_DST_SC;
            default: st <= X_DST_DMA;    // IN, ID, ZERO, STATUS -> writable stream
          endcase
        end

        X_DST_DMA: if (dresp) begin
          if (dma_resp_err) begin
            fatal <= 1'b1; cause <= FC_DATA_WRITE_DMA; done <= 1'b1; st <= B_IDLE;
          end else if (drain) begin
            st <= B_IDLE;
          end else begin
            st <= X_ADV;
          end
        end

        X_DST_SC: if (sresp) begin
          if (drain) begin
            st <= B_IDLE;
          end else if (sc_resp_err) begin
            status_q <= VIRTIO_BLK_S_IOERR;
            start_phase(PH_ZERO, in_len - wpos);
          end else begin
            st <= X_ADV;
          end
        end

        X_ADV: begin
          rem   <= rem - {28'd0, n};
          k     <= k + {28'd0, n};
          saddr <= saddr + SADDR_W'(n);
          if (r_side) begin
            if ((roff + {28'd0, n}) == seg_rd_len) begin
              ridx <= ridx + 1'b1;
              roff <= '0;
            end else begin
              roff <= roff + {28'd0, n};
            end
          end else begin
            wpos <= wpos + {28'd0, n};
            if ((woff + {28'd0, n}) == seg_rd_len) begin
              widx <= widx + 1'b1;
              woff <= '0;
            end else begin
              woff <= woff + {28'd0, n};
            end
          end
          st <= X_CALC;
        end

        default: st <= B_IDLE;
      endcase
    end
  end

endmodule
