// =============================================================================
// SilicaFlux Albion -- Project 87 -- VirtualFoundry :: sf_virtual_pkg
//
// Constants for the VirtualFoundry virtual-I/O engine.
//
// Normative reference for every [SPEC] constant: OASIS "Virtual I/O Device (VIRTIO)
// Version 1.2", Committee Specification 01 (virtio-v1.2-cs01).  Constants marked [SFV] are
// SilicaFlux-internal and are never presented to a guest as if they were part of VirtIO.
// Constants marked [ALB] are the Albion transaction-format values defined by Project 83
// (Meridian, docs/meridian/02_PROTOCOL.md); the numeric values are copied from
// sf_meridian_pkg and checked against it by tests/virtual_foundry/tb/tb_pkg_consistency.sv.
//
// Byte order: VirtIO 1.x structures are little-endian.  Every 64-bit data lane in this design is
// little-endian: bits [8i+7:8i] carry the byte at (word_address + i).
// =============================================================================
package sf_virtual_pkg;
  /* verilator lint_off UNUSEDPARAM */

  // ---------------------------------------------------------------- [SPEC] 2.1 device status
  localparam logic [7:0] VIRTIO_STATUS_ACKNOWLEDGE        = 8'd1;
  localparam logic [7:0] VIRTIO_STATUS_DRIVER             = 8'd2;
  localparam logic [7:0] VIRTIO_STATUS_DRIVER_OK          = 8'd4;
  localparam logic [7:0] VIRTIO_STATUS_FEATURES_OK        = 8'd8;
  localparam logic [7:0] VIRTIO_STATUS_DEVICE_NEEDS_RESET = 8'd64;
  localparam logic [7:0] VIRTIO_STATUS_FAILED             = 8'd128;

  // ---------------------------------------------------------------- [SPEC] 6 reserved feature bits
  localparam int VIRTIO_F_INDIRECT_DESC     = 28;
  localparam int VIRTIO_F_EVENT_IDX         = 29;
  localparam int VIRTIO_F_VERSION_1         = 32;
  localparam int VIRTIO_F_ACCESS_PLATFORM   = 33;
  localparam int VIRTIO_F_RING_PACKED       = 34;
  localparam int VIRTIO_F_IN_ORDER          = 35;
  localparam int VIRTIO_F_NOTIFICATION_DATA = 38;
  localparam int VIRTIO_F_RING_RESET        = 40;

  // ---------------------------------------------------------------- [SPEC] 5.2.3 block feature bits
  localparam int VIRTIO_BLK_F_SEG_MAX = 2;
  localparam int VIRTIO_BLK_F_RO      = 5;
  localparam int VIRTIO_BLK_F_FLUSH   = 9;
  localparam int VIRTIO_BLK_F_MQ      = 12;

  // ---------------------------------------------------------------- [SPEC] 5.1.3 network feature bits
  localparam int VIRTIO_NET_F_CSUM       = 0;
  localparam int VIRTIO_NET_F_MAC        = 5;
  localparam int VIRTIO_NET_F_MRG_RXBUF  = 15;
  localparam int VIRTIO_NET_F_STATUS     = 16;
  localparam int VIRTIO_NET_F_CTRL_VQ    = 17;
  localparam int VIRTIO_NET_F_MQ         = 22;

  // ---------------------------------------------------------------- [SPEC] 2.7 split virtqueue
  //   struct virtq_desc { le64 addr; le32 len; le16 flags; le16 next; }               16 B, align 16
  //   struct virtq_avail { le16 flags; le16 idx; le16 ring[N]; le16 used_event; }     align 2
  //   struct virtq_used  { le16 flags; le16 idx; struct { le32 id; le32 len; } ring[N]; le16 avail_event; } align 4
  localparam logic [15:0] VIRTQ_DESC_F_NEXT          = 16'd1;
  localparam logic [15:0] VIRTQ_DESC_F_WRITE         = 16'd2;
  localparam logic [15:0] VIRTQ_DESC_F_INDIRECT      = 16'd4;
  localparam logic [15:0] VIRTQ_AVAIL_F_NO_INTERRUPT = 16'd1;
  localparam int          VIRTQ_SPLIT_MAX_SIZE       = 32768;

  // ---------------------------------------------------------------- [SPEC] 5.2 block device
  localparam logic [31:0] VIRTIO_BLK_T_IN     = 32'd0;
  localparam logic [31:0] VIRTIO_BLK_T_OUT    = 32'd1;
  localparam logic [31:0] VIRTIO_BLK_T_FLUSH  = 32'd4;
  localparam logic [31:0] VIRTIO_BLK_T_GET_ID = 32'd8;
  localparam logic [7:0]  VIRTIO_BLK_S_OK     = 8'd0;
  localparam logic [7:0]  VIRTIO_BLK_S_IOERR  = 8'd1;
  localparam logic [7:0]  VIRTIO_BLK_S_UNSUPP = 8'd2;
  localparam int          VIRTIO_BLK_ID_BYTES = 20;
  localparam logic [31:0] VIRTIO_ID_NET       = 32'd1;
  localparam logic [31:0] VIRTIO_ID_BLOCK     = 32'd2;

  // ---------------------------------------------------------------- [SPEC] 5.1 network device
  //   struct virtio_net_hdr { u8 flags; u8 gso_type; le16 hdr_len; le16 gso_size;
  //                           le16 csum_start; le16 csum_offset; le16 num_buffers; }   12 B (VERSION_1)
  localparam int          VIRTIO_NET_HDR_BYTES   = 12;
  localparam logic [7:0]  VIRTIO_NET_HDR_GSO_NONE = 8'd0;
  localparam logic [15:0] VIRTIO_NET_S_LINK_UP   = 16'd1;

  // ---------------------------------------------------------------- [SPEC] 4.2.2 virtio-mmio v2
  localparam logic [31:0] VIRTIO_MMIO_MAGIC   = 32'h7472_6976;
  localparam logic [31:0] VIRTIO_MMIO_VERSION = 32'd2;
  localparam logic [11:0] MMIO_MAGIC_VALUE         = 12'h000;
  localparam logic [11:0] MMIO_VERSION             = 12'h004;
  localparam logic [11:0] MMIO_DEVICE_ID           = 12'h008;
  localparam logic [11:0] MMIO_VENDOR_ID           = 12'h00c;
  localparam logic [11:0] MMIO_DEVICE_FEATURES     = 12'h010;
  localparam logic [11:0] MMIO_DEVICE_FEATURES_SEL = 12'h014;
  localparam logic [11:0] MMIO_DRIVER_FEATURES     = 12'h020;
  localparam logic [11:0] MMIO_DRIVER_FEATURES_SEL = 12'h024;
  localparam logic [11:0] MMIO_QUEUE_SEL           = 12'h030;
  localparam logic [11:0] MMIO_QUEUE_NUM_MAX       = 12'h034;
  localparam logic [11:0] MMIO_QUEUE_NUM           = 12'h038;
  localparam logic [11:0] MMIO_QUEUE_READY         = 12'h044;
  localparam logic [11:0] MMIO_QUEUE_NOTIFY        = 12'h050;
  localparam logic [11:0] MMIO_INTERRUPT_STATUS    = 12'h060;
  localparam logic [11:0] MMIO_INTERRUPT_ACK       = 12'h064;
  localparam logic [11:0] MMIO_STATUS              = 12'h070;
  localparam logic [11:0] MMIO_QUEUE_DESC_LOW      = 12'h080;
  localparam logic [11:0] MMIO_QUEUE_DESC_HIGH     = 12'h084;
  localparam logic [11:0] MMIO_QUEUE_DRIVER_LOW    = 12'h090;
  localparam logic [11:0] MMIO_QUEUE_DRIVER_HIGH   = 12'h094;
  localparam logic [11:0] MMIO_QUEUE_DEVICE_LOW    = 12'h0a0;
  localparam logic [11:0] MMIO_QUEUE_DEVICE_HIGH   = 12'h0a4;
  localparam logic [11:0] MMIO_SHM_SEL             = 12'h0ac;
  localparam logic [11:0] MMIO_SHM_LEN_LOW         = 12'h0b0;
  localparam logic [11:0] MMIO_SHM_LEN_HIGH        = 12'h0b4;
  localparam logic [11:0] MMIO_SHM_BASE_LOW        = 12'h0b8;
  localparam logic [11:0] MMIO_SHM_BASE_HIGH       = 12'h0bc;
  localparam logic [11:0] MMIO_QUEUE_RESET         = 12'h0c0;
  localparam logic [11:0] MMIO_CONFIG_GENERATION   = 12'h0fc;
  localparam logic [11:0] MMIO_CONFIG              = 12'h100;
  localparam int VIRTIO_MMIO_INT_VRING  = 0;
  localparam int VIRTIO_MMIO_INT_CONFIG = 1;

  // ---------------------------------------------------------------- [SFV] device kinds of a guest context
  localparam int DEV_BLK = 0;
  localparam int DEV_NET = 1;

  // ---------------------------------------------------------------- [SFV] identity and versions
  localparam logic [31:0] SFV_ENGINE_ID     = 32'h5346_5646;   // "SFVF" VirtualFoundry context
  localparam logic [31:0] SFV_GLOBAL_ID     = 32'h5346_5647;   // "SFVG" VirtualFoundry global page
  localparam logic [7:0]  SFV_VER_MAJOR     = 8'd1;
  localparam logic [7:0]  SFV_VER_MINOR     = 8'd0;
  localparam logic [7:0]  SFV_VER_PATCH     = 8'd0;
  localparam logic [31:0] SFV_VIRTIO_VENDOR = 32'h5846_4c53;   // "SLFX"

  // ---------------------------------------------------------------- [SFV] fatal (DEVICE_NEEDS_RESET) causes
  localparam logic [7:0] FC_NONE           = 8'd0;
  localparam logic [7:0] FC_QUEUE_CFG      = 8'd1;    // invalid queue configuration at QueueReady=1
  localparam logic [7:0] FC_NO_DOMAIN      = 8'd2;    // processing requested, no protection domain bound
  localparam logic [7:0] FC_AVAIL_IDX_JUMP = 8'd3;    // avail.idx ran ahead by more than the queue size
  localparam logic [7:0] FC_RING_DMA       = 8'd4;    // fault on descriptor table / available ring / used ring
  localparam logic [7:0] FC_DESC_IDX_OOR   = 8'd5;    // head or next index >= queue size
  localparam logic [7:0] FC_CHAIN_LOOP     = 8'd6;    // descriptor revisited within one chain
  localparam logic [7:0] FC_CHAIN_TOO_LONG = 8'd7;    // more than MAX_CHAIN descriptors
  localparam logic [7:0] FC_DESC_FLAGS     = 8'd8;    // INDIRECT (not offered) or reserved flag bits
  localparam logic [7:0] FC_CHAIN_ORDER    = 8'd9;    // device-readable after device-writable (2.7.4.2)
  localparam logic [7:0] FC_CHAIN_LEN_OVF  = 8'd10;   // chain length >= 2^32 (2.7.13.1)
  localparam logic [7:0] FC_WRITABLE_PERM  = 8'd11;   // device-writable buffer outside the domain's windows
  localparam logic [7:0] FC_NO_STATUS      = 8'd12;   // no device-writable byte for the block status
  localparam logic [7:0] FC_DATA_WRITE_DMA = 8'd13;   // fault while writing a device-writable buffer

  // ---------------------------------------------------------------- [SFV] backend (StorageCore) operations
  localparam logic [1:0] SC_OP_READ  = 2'd0;
  localparam logic [1:0] SC_OP_WRITE = 2'd1;
  localparam logic [1:0] SC_OP_FLUSH = 2'd2;

  // ---------------------------------------------------------------- [SFV] fault-capture source codes
  localparam logic [3:0] FS_NONE     = 4'd0;
  localparam logic [3:0] FS_GATE     = 4'd1;   // local window gate denied a DMA beat
  localparam logic [3:0] FS_DESC     = 4'd2;   // descriptor pre-check denied a buffer
  localparam logic [3:0] FS_CITADEL  = 4'd3;   // Citadel denied (detail = F_* code)
  localparam logic [3:0] FS_BRIDGE   = 4'd4;   // BridgeEngine answered with an error status (detail = ST_*)
  localparam logic [3:0] FS_TIMEOUT  = 4'd5;   // BridgeEngine did not answer in time
  localparam logic [3:0] FS_ECHO     = 4'd6;   // BridgeEngine response echo (tag/dom/op) mismatch

  // ---------------------------------------------------------------- [ALB] Albion transaction format (P83)
  localparam logic [1:0] ALB_OP_READ  = 2'd0;
  localparam logic [1:0] ALB_OP_WRITE = 2'd1;
  localparam logic [2:0] ALB_ST_OKAY    = 3'd0;
  localparam logic [2:0] ALB_ST_SLVERR  = 3'd1;
  localparam logic [2:0] ALB_ST_DECERR  = 3'd2;
  localparam logic [2:0] ALB_ST_DENIED  = 3'd3;
  localparam logic [2:0] ALB_ST_TIMEOUT = 3'd4;
  localparam logic [2:0] ALB_ST_PROTO   = 3'd5;
  localparam logic [3:0] ALB_F_NONE     = 4'd0;
  localparam logic [3:0] ALB_F_NOMAP    = 4'd1;
  localparam logic [3:0] ALB_F_PERM     = 4'd2;
  localparam logic [3:0] ALB_F_DOMAIN   = 4'd3;
  localparam logic [3:0] ALB_F_PRIV     = 4'd4;
  localparam logic [3:0] ALB_F_CITTMO   = 4'd6;
  localparam logic [2:0] ALB_TC_BULK    = 3'd1;
  localparam logic [2:0] ALB_TC_IO      = 3'd3;

  // ---------------------------------------------------------------- helpers
  // Contiguous byte-enable mask of n (1..8) bytes starting at lane `lane`.
  function automatic logic [7:0] sfv_be(input logic [3:0] n, input logic [2:0] lane);
    logic [7:0] m;
    for (int i = 0; i < 8; i++) m[i] = (4'(i) < n);
    return m << lane;
  endfunction

  function automatic logic [3:0] sfv_min4(input logic [3:0] a, input logic [3:0] b);
    return (a < b) ? a : b;
  endfunction

  // number of set bits of an 8-bit mask
  function automatic logic [3:0] sfv_pop8(input logic [7:0] m);
    logic [3:0] c;
    c = 4'd0;
    for (int i = 0; i < 8; i++) c = c + {3'd0, m[i]};
    return c;
  endfunction

  /* verilator lint_on UNUSEDPARAM */
endpackage
