#!/bin/bash
# Build the delivery archive (no build products) with a SHA-256 manifest.  Nothing is committed anywhere.
set -e
cd "$(dirname "$0")/.."
NAME=silicaflux-virtualfoundry-p87
OUT=${1:-../$NAME.zip}
rm -f MANIFEST.sha256
find . -type f ! -path './build/*' ! -name MANIFEST.sha256 ! -name '*.zip' | sort | xargs sha256sum > MANIFEST.sha256
cd ..
rm -f "$OUT"
zip -qr "$OUT" "$(basename "$OLDPWD")" -x "*/build/*" "*.o" "*/__pycache__/*"
echo "wrote $OUT ($(du -h "$OUT" | cut -f1)); verify with: sha256sum -c MANIFEST.sha256 inside the extracted tree"
