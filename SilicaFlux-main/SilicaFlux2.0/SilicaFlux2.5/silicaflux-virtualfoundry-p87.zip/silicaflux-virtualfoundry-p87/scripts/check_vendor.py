#!/usr/bin/env python3
"""Verify that the vendored Project 83 files are byte-identical to the recorded hashes (third_party/p83/SHA256SUMS)
and, when a repository checkout is given, to the member of the original archive.
usage: check_vendor.py [path/to/silicaflux-meridian-p83.zip]"""
import hashlib, pathlib, sys, zipfile
root = pathlib.Path(__file__).resolve().parents[1]
bad = 0
for line in (root / "third_party/p83/SHA256SUMS").read_text().splitlines():
    h, f = line.split()
    got = hashlib.sha256((root / f).read_bytes()).hexdigest()
    print(("OK   " if got == h else "FAIL ") + f)
    bad += got != h
if len(sys.argv) > 1:
    z = zipfile.ZipFile(sys.argv[1])
    for name in ["sf_meridian_pkg.sv", "sf_meridian_citadel_ref.sv"]:
        m = [n for n in z.namelist() if n.endswith("rtl/albion/" + name)][0]
        same = z.read(m) == (root / "third_party/p83" / name).read_bytes()
        print(("OK   " if same else "FAIL ") + name + " == archive member")
        bad += not same
sys.exit(1 if bad else 0)
