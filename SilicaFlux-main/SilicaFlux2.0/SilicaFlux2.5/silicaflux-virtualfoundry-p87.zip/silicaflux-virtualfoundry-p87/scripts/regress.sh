#!/bin/bash
# Full regression: lint, host library, register consistency, pure-SV benches, example, every configuration x tier,
# random regression over several seeds, the slow tests and the performance sweep.  Logs go to reports/logs/.
# Tier gating: tier 2 (isolation) runs only if tier 1 passed; tier 3 (multi-context, network, random) only if tier 2 passed.
set -u
cd "$(dirname "$0")/.."
J=${JOBS:-4}; SEEDS=${SEEDS:-"1 2 3 4 5 6"}; ITERS=${ITERS:-150}
mkdir -p reports/logs
L=reports/logs
fail=0
step() { echo "== $*"; }
run() { local log=$1; shift; if "$@" > "$L/$log" 2>&1; then echo "   PASS  $log"; else echo "   FAIL  $log"; fail=1; fi; }

step "static"
run lint.log make lint JOBS=$J
run hostlib.log make hostlib
run check_regs.log make check_regs
run check_vendor.log python3 scripts/check_vendor.py
run svtb.log make svtb JOBS=$J
run example.log make example JOBS=$J

step "build"
for c in blk1 small cit1 tmo blk3 multi net2; do run build_$c.log make build/sim_$c/vf_tests JOBS=$J; done

step "tier 1 (single guest, single queue)"
t1ok=1
for c in blk1 small cit1 tmo blk3; do run t1_$c.log build/sim_$c/vf_tests --tier t1 --skip-long --seed 1 || true; grep -q "FAILED" $L/t1_$c.log && t1ok=0; done
run t1_slow.log build/sim_blk1/vf_tests --only index_wrap16
[ $fail -ne 0 ] && { echo "tier 1 failed: tier 2 and 3 are NOT run"; exit 1; }

step "tier 2 (isolation between guests)"
run t2_blk3.log build/sim_blk3/vf_tests --tier t2 --seed 1
[ $fail -ne 0 ] && { echo "tier 2 failed: tier 3 is NOT run"; exit 1; }

step "tier 3 (network, random regression)"
run t3_multi.log build/sim_multi/vf_tests --tier t3 --iters $ITERS
run t3_net2.log build/sim_net2/vf_tests --tier t3 --iters $ITERS
for s in $SEEDS; do
  run t3_blk1_seed$s.log build/sim_blk1/vf_tests --only random_blk_single --iters $ITERS --seed $s
  run t3_blk3_seed$s.log build/sim_blk3/vf_tests --only random_blk_multi --iters $ITERS --seed $s
  run t3_multi_seed$s.log build/sim_multi/vf_tests --only random_net --iters 60 --seed $s
  run t3_net2_seed$s.log build/sim_net2/vf_tests --only random_net --iters 60 --seed $s
done
run t3_small.log build/sim_small/vf_tests --only random_blk_single --iters $ITERS

step "performance sweep"
VF_PERF_OUT=reports/perf_sweep.md run perf.log build/sim_blk3/vf_tests --only perf_sweep
[ $fail -eq 0 ] && echo "ALL PASS" || echo "FAILURES"
exit $fail
