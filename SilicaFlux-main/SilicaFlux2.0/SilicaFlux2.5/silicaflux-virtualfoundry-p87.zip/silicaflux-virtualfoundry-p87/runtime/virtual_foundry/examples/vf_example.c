/*
 * vf_example.c -- SilicaFlux Albion, Project 87 VirtualFoundry: definition-of-done demonstration.
 *
 *   "A simulated guest driver can submit a supported virtual I/O command, receive the correct result and
 *    remain confined to its authorised memory and queues."
 *
 * A plain C program using only the public host library (vf_host.h).  Two guests (block devices) are provisioned
 * by the "hypervisor" side of the library; guest 0 does ordinary I/O and then tries to read guest 1's memory,
 * which the hardware refuses.  Runs against the Verilator model: no PCIe hardware is needed.
 *
 *   make example
 */
#include <stdio.h>
#include <string.h>
#include "vf_host.h"
#include "vf_sim_c.h"

#define CHECK(c) do { if (!(c)) { printf("  FAILED: %s (line %d)\n", #c, __LINE__); return 1; } } while (0)

int main(void) {
  vf_sim_t *sim = vf_sim_create(2, 1);
  const vf_mgmt_t *m = vf_sim_mgmt(sim);
  /* hypervisor: guest 0 owns [1 MiB, 2 MiB) + sectors [0, 512); guest 1 owns [2 MiB, 3 MiB) + sectors [512, 1024) */
  CHECK(vf_sim_provision(sim, 0, 1, 0x100000, 0x100000, 0, 512) == 0);
  CHECK(vf_sim_provision(sim, 1, 2, 0x200000, 0x100000, 512, 512) == 0);
  unsigned nctx; uint32_t nets;
  CHECK(vf_hv_probe_global(m, &nctx, &nets) == VF_OK);
  printf("VirtualFoundry: %u guest contexts\n", nctx);

  /* guest 0: bring up virtio-blk (reset, negotiate, queue, DRIVER_OK) */
  vf_blk_t blk;
  const vf_transport_t *t0 = vf_sim_transport(sim, 0);
  CHECK(vf_blk_open(&blk, t0, 16) == VF_OK);
  printf("guest 0: virtio-blk up, capacity %llu sectors, flush %s\n", (unsigned long long)blk.capacity, blk.has_flush ? "yes" : "no");

  /* ordinary I/O: write 4 KiB, read it back */
  uint64_t buf, buf2;
  CHECK(t0->dma_alloc(t0->ctx, 4096, 8, &buf) == 0 && t0->dma_alloc(t0->ctx, 4096, 8, &buf2) == 0);
  unsigned char pat[4096], back[4096];
  for (unsigned i = 0; i < sizeof pat; i++) pat[i] = (unsigned char)(i * 7 + 3);
  t0->mem_write(t0->ctx, buf, pat, sizeof pat);
  uint8_t st = 0xff;
  CHECK(vf_blk_rw_sync(&blk, 1, 7, buf, 4096, &st) == VF_OK && st == VIRTIO_BLK_S_OK);
  CHECK(vf_blk_flush_sync(&blk, &st) == VF_OK);
  CHECK(vf_blk_rw_sync(&blk, 0, 7, buf2, 4096, &st) == VF_OK && st == VIRTIO_BLK_S_OK);
  t0->mem_read(t0->ctx, buf2, back, sizeof back);
  CHECK(memcmp(pat, back, sizeof pat) == 0);
  printf("guest 0: wrote, flushed and read back 4096 bytes at sector 7: data identical\n");

  /* confinement: guest 0 points a request at guest 1's memory (a forged guest-physical address) */
  uint64_t victim = 0x200000 + 0x1000;
  unsigned char secret[16] = "guest-1 secret";
  vf_sim_mem_write(sim, victim, secret, sizeof secret);
  int rc = vf_blk_rw_sync(&blk, 1, 9, victim, 512, &st);                   /* OUT: would copy guest 1's memory to storage */
  printf("guest 0: request reading guest 1's memory -> %s (status %u)\n", vf_strerror(rc), st);
  CHECK(rc == VF_E_IO);
  vf_hv_fault_t f;
  vf_hv_read_fault(m, 0, &f);
  printf("hypervisor: fault captured, source %s, address 0x%llx\n", vf_fault_src_name(f.src), (unsigned long long)f.addr);
  CHECK(f.valid && f.addr == victim);
  rc = vf_blk_rw_sync(&blk, 0, 9, victim, 512, &st);                       /* IN: would overwrite guest 1's memory */
  printf("guest 0: request writing guest 1's memory -> %s, device cause %s\n", vf_strerror(rc), vf_fatal_cause_name(vf_hv_fatal_cause(m, 0)));
  CHECK(rc == VF_E_NEEDS_RESET);
  unsigned char check[16];
  vf_sim_mem_read(sim, victim, check, sizeof check);
  CHECK(memcmp(check, secret, sizeof secret) == 0);
  printf("guest 1's memory is unchanged; independent monitor reports %d violations\n", vf_sim_monitor_errors(sim));
  CHECK(vf_sim_monitor_errors(sim) == 0);

  /* guest 1 is unaffected and the hypervisor can read per-domain accounting */
  vf_blk_t blk1;
  CHECK(vf_blk_open(&blk1, vf_sim_transport(sim, 1), 16) == VF_OK);
  uint64_t b1;
  CHECK(vf_sim_transport(sim, 1)->dma_alloc(vf_sim_transport(sim, 1)->ctx, 1024, 8, &b1) == 0);
  CHECK(vf_blk_rw_sync(&blk1, 0, 0, b1, 512, &st) == VF_OK);
  printf("guest 1: unaffected, read OK; domain-2 DMA read bytes %llu\n", (unsigned long long)vf_hv_bridge64(m, 1, VF_B_RD_BYTES));
  printf("guest 0: %u requests completed, %u descriptors, %llu DMA bytes read, %llu written, %u permission violations\n",
         vf_hv_perf32(m, 0, VF_P_REQ), vf_hv_perf32(m, 0, VF_P_DESC),
         (unsigned long long)vf_hv_perf64(m, 0, VF_P_RD_BYTES), (unsigned long long)vf_hv_perf64(m, 0, VF_P_WR_BYTES), vf_hv_perf32(m, 0, VF_P_VIOL));
  vf_blk_close(&blk); vf_blk_close(&blk1);
  vf_sim_destroy(sim);
  printf("DEFINITION OF DONE: MET (guest I/O correct, guest confined to its memory and queues)\n");
  return 0;
}
