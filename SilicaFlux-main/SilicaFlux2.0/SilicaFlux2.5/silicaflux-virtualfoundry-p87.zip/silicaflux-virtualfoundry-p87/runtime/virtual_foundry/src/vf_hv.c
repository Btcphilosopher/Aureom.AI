/*
 * vf_hv.c -- SilicaFlux Albion, Project 87 VirtualFoundry
 *
 * Hypervisor / Keystone helpers for the privileged management page (docs 02_REGISTER_MAP.md).
 * The management page must never be mapped into a guest: it binds contexts to protection domains,
 * programs the window table and the storage extent, and reads faults and counters.
 */
#include <string.h>
#include "vf_host.h"

static uint32_t pg(unsigned ctx) { return VF_MGMT_PAGE(ctx); }
static uint32_t rd(const vf_mgmt_t *m, uint32_t a) { return m->read32(m->ctx, a); }
static void wr(const vf_mgmt_t *m, uint32_t a, uint32_t v) { m->write32(m->ctx, a, v); }

int vf_hv_probe_ctx(const vf_mgmt_t *m, unsigned ctx, vf_hv_info_t *info) {
  uint32_t id = rd(m, pg(ctx) | VF_M_ID);
  if (id != 0x53465646u) return VF_E_NODEV;
  uint32_t v = rd(m, pg(ctx) | VF_M_VER);
  if (((v >> 16) & 0xff) != 1) return VF_E_VERSION;           /* major version gate */
  if (info) {
    info->id = id;
    info->version = v;
    info->caps0 = rd(m, pg(ctx) | VF_M_CAPS0);
    info->caps1 = rd(m, pg(ctx) | VF_M_CAPS1);
  }
  return VF_OK;
}

int vf_hv_probe_global(const vf_mgmt_t *m, unsigned *nctx, uint32_t *net_bitmap) {
  if (rd(m, VF_G_ID) != 0x53465647u) return VF_E_NODEV;
  if (((rd(m, VF_G_VER) >> 16) & 0xff) != 1) return VF_E_VERSION;
  uint32_t caps = rd(m, VF_G_CAPS);
  if (nctx) *nctx = caps & 0xfu;
  if (net_bitmap) *net_bitmap = (caps >> 12) & 0xffffu;
  return VF_OK;
}

void vf_hv_bind_domain(const vf_mgmt_t *m, unsigned ctx, uint16_t domain) {
  wr(m, pg(ctx) | VF_M_DOMAIN, 0x80000000u | domain);
}

void vf_hv_unbind_domain(const vf_mgmt_t *m, unsigned ctx) { wr(m, pg(ctx) | VF_M_DOMAIN, 0); }

void vf_hv_set_window(const vf_mgmt_t *m, unsigned ctx, unsigned w, uint16_t domain, uint64_t base,
                      uint64_t limit, int rdp, int wrp) {
  uint32_t a = pg(ctx) | (VF_M_WIN_BASE + 0x20u * w);
  wr(m, a + 0x00, 0);                                   /* invalidate first: a half-programmed window is never live */
  wr(m, a + 0x04, domain);
  wr(m, a + 0x08, (uint32_t)base);
  wr(m, a + 0x0c, (uint32_t)(base >> 32));
  wr(m, a + 0x10, (uint32_t)limit);
  wr(m, a + 0x14, (uint32_t)(limit >> 32));
  wr(m, a + 0x00, 1u | (rdp ? 2u : 0u) | (wrp ? 4u : 0u));
}

void vf_hv_clear_window(const vf_mgmt_t *m, unsigned ctx, unsigned w) {
  wr(m, pg(ctx) | (VF_M_WIN_BASE + 0x20u * w), 0);
}

void vf_hv_set_extent(const vf_mgmt_t *m, unsigned ctx, uint64_t base, uint64_t size, int ro) {
  wr(m, pg(ctx) | VF_M_EXT_SIZE_LO, (uint32_t)size);
  wr(m, pg(ctx) | VF_M_EXT_SIZE_HI, (uint32_t)(size >> 32));
  wr(m, pg(ctx) | VF_M_EXT_BASE_LO, (uint32_t)base);
  wr(m, pg(ctx) | VF_M_EXT_BASE_HI, (uint32_t)(base >> 32));
  wr(m, pg(ctx) | VF_M_EXT_FLAGS, ro ? 1u : 0u);
}

void vf_hv_set_mac(const vf_mgmt_t *m, unsigned ctx, const uint8_t mac[6]) {
  wr(m, pg(ctx) | VF_M_MAC_LO, (uint32_t)mac[0] | ((uint32_t)mac[1] << 8) | ((uint32_t)mac[2] << 16) | ((uint32_t)mac[3] << 24));
  wr(m, pg(ctx) | VF_M_MAC_HI, (uint32_t)mac[4] | ((uint32_t)mac[5] << 8));
}

int vf_hv_host_reset(const vf_mgmt_t *m, unsigned ctx, uint32_t budget) {
  wr(m, pg(ctx) | VF_M_CTRL, 1u);
  while (budget--) if (!(rd(m, pg(ctx) | VF_M_CTRL) & 1u)) return VF_OK;
  return VF_E_TIMEOUT;
}

void vf_hv_clear_counters(const vf_mgmt_t *m, unsigned ctx) { wr(m, pg(ctx) | VF_M_CTRL, 2u); }
void vf_hv_clear_faults(const vf_mgmt_t *m, unsigned ctx)   { wr(m, pg(ctx) | VF_M_CTRL, 4u); }

uint32_t vf_hv_perf32(const vf_mgmt_t *m, unsigned ctx, uint32_t off) { return rd(m, pg(ctx) | (VF_M_PERF + off)); }

uint64_t vf_hv_perf64(const vf_mgmt_t *m, unsigned ctx, uint32_t off) {
  uint32_t hi0, lo, hi1;
  do {   /* tolerate a carry between the two halves */
    hi0 = rd(m, pg(ctx) | (VF_M_PERF + off + 4));
    lo  = rd(m, pg(ctx) | (VF_M_PERF + off));
    hi1 = rd(m, pg(ctx) | (VF_M_PERF + off + 4));
  } while (hi0 != hi1);
  return ((uint64_t)hi1 << 32) | lo;
}

uint32_t vf_hv_devcnt(const vf_mgmt_t *m, unsigned ctx, unsigned idx) { return rd(m, pg(ctx) | (VF_M_DEVCNT + 4u * idx)); }
uint32_t vf_hv_bridge32(const vf_mgmt_t *m, unsigned ctx, unsigned word) { return rd(m, VF_G_BRIDGE(ctx) + 4u * word); }
uint64_t vf_hv_bridge64(const vf_mgmt_t *m, unsigned ctx, unsigned word) {
  return ((uint64_t)vf_hv_bridge32(m, ctx, word + 1) << 32) | vf_hv_bridge32(m, ctx, word);
}
uint32_t vf_hv_status(const vf_mgmt_t *m, unsigned ctx) { return rd(m, pg(ctx) | VF_M_STATUS); }
uint8_t vf_hv_fatal_cause(const vf_mgmt_t *m, unsigned ctx) { return (uint8_t)(vf_hv_status(m, ctx) >> 8); }

void vf_hv_read_fault(const vf_mgmt_t *m, unsigned ctx, vf_hv_fault_t *f) {
  uint32_t info = rd(m, pg(ctx) | VF_M_FAULT_INFO);
  memset(f, 0, sizeof *f);
  f->write = info & 1u;
  f->valid = (info >> 1) & 1u;
  f->src   = (info >> 4) & 0xfu;
  f->code  = (info >> 8) & 0xffu;
  f->addr  = ((uint64_t)rd(m, pg(ctx) | VF_M_FAULT_HI) << 32) | rd(m, pg(ctx) | VF_M_FAULT_LO);
  f->count = rd(m, pg(ctx) | VF_M_FAULT_CNT);
}
