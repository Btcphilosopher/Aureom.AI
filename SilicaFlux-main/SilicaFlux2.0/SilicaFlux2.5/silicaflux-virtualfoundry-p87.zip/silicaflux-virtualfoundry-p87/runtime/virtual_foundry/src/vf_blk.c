/*
 * vf_blk.c -- SilicaFlux Albion, Project 87 VirtualFoundry
 *
 * virtio-blk driver layer (VirtIO 1.2 s5.2) on top of vf_core.c.  Derived from the Project 63 host
 * library (sfv_blk.c).
 */
#include <string.h>
#include "vf_host.h"

#define SLOT_BYTES 32u   /* per head: 16-byte header @0, status byte @16 */

static uint64_t slot_iova(vf_blk_t *b, uint16_t head) { return b->pool_iova + (uint64_t)SLOT_BYTES * head; }

int vf_blk_open(vf_blk_t *b, const vf_transport_t *t, uint16_t qsize) {
  memset(b, 0, sizeof *b);
  int r = vf_dev_probe(&b->dev, t);
  if (r) return r;
  if (b->dev.device_id != VIRTIO_ID_BLOCK) return VF_E_NODEV;
  if ((r = vf_dev_reset(&b->dev))) return r;

  const uint64_t wanted = VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM) |
                          VF_FEAT(VIRTIO_BLK_F_SEG_MAX) | VF_FEAT(VIRTIO_BLK_F_FLUSH) | VF_FEAT(VIRTIO_BLK_F_RO);
  const uint64_t required = VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM);
  if ((r = vf_dev_negotiate(&b->dev, wanted, required))) return r;
  b->has_flush = (b->dev.drv_features & VF_FEAT(VIRTIO_BLK_F_FLUSH)) != 0;
  b->read_only = (b->dev.drv_features & VF_FEAT(VIRTIO_BLK_F_RO)) != 0;

  /* s4.2.2: read multi-word config consistently using ConfigGeneration */
  uint32_t g0, g1, lo, hi;
  do {
    g0 = t->mmio_read32(t->ctx, VIRTIO_MMIO_CONFIG_GENERATION);
    lo = vf_dev_config_read32(&b->dev, VIRTIO_BLK_CFG_CAPACITY);
    hi = vf_dev_config_read32(&b->dev, VIRTIO_BLK_CFG_CAPACITY + 4);
    g1 = t->mmio_read32(t->ctx, VIRTIO_MMIO_CONFIG_GENERATION);
  } while (g0 != g1);
  b->capacity = ((uint64_t)hi << 32) | lo;
  if (b->dev.drv_features & VF_FEAT(VIRTIO_BLK_F_SEG_MAX))
    b->seg_max = vf_dev_config_read32(&b->dev, VIRTIO_BLK_CFG_SEG_MAX);

  if ((r = vf_vq_setup(&b->dev, &b->vq, 0, qsize))) return r;
  if (t->dma_alloc(t->ctx, (size_t)SLOT_BYTES * qsize, 8, &b->pool_iova)) return VF_E_NOMEM;
  return vf_dev_driver_ok(&b->dev);
}

void vf_blk_close(vf_blk_t *b) { vf_vq_destroy(&b->vq); }

int vf_blk_status_to_err(uint8_t s) {
  switch (s) {
    case VIRTIO_BLK_S_OK: return VF_OK;
    case VIRTIO_BLK_S_IOERR: return VF_E_IO;
    case VIRTIO_BLK_S_UNSUPP: return VF_E_UNSUPP;
    default: return VF_E_PROTOCOL;
  }
}

int vf_blk_submit(vf_blk_t *b, uint32_t type, uint64_t sector, const vf_sg_t *data, unsigned ndata,
                  void *cookie, uint16_t *head) {
  const vf_transport_t *t = b->dev.t;
  if (b->seg_max && ndata > b->seg_max) return VF_E_INVAL;
  if (ndata + 2 > b->vq.num_free) return VF_E_NOSPC;
  if (ndata + 2 > 64) return VF_E_INVAL;

  uint16_t h = b->vq.free_head;            /* the head the chain will start at */
  uint8_t hdr[16];
  memset(hdr, 0, sizeof hdr);
  for (int i = 0; i < 4; i++) hdr[i] = (uint8_t)(type >> (8 * i));
  for (int i = 0; i < 8; i++) hdr[8 + i] = (uint8_t)(sector >> (8 * i));
  t->mem_write(t->ctx, slot_iova(b, h), hdr, 16);
  uint8_t sentinel = 0xa5;                 /* detects a device that never writes the status */
  t->mem_write(t->ctx, slot_iova(b, h) + 16, &sentinel, 1);

  vf_sg_t sg[64];
  unsigned n = 0;
  sg[n++] = (vf_sg_t){slot_iova(b, h), 16, 0};
  for (unsigned i = 0; i < ndata; i++) sg[n++] = data[i];
  sg[n++] = (vf_sg_t){slot_iova(b, h) + 16, 1, 1};
  return vf_vq_add(&b->vq, sg, n, cookie, head);
}

int vf_blk_poll(vf_blk_t *b, vf_blk_completion_t *c) {
  const vf_transport_t *t = b->dev.t;
  uint16_t h;
  uint32_t len;
  void *ck;
  int r = vf_vq_get_used(&b->vq, &h, &len, &ck);
  if (r <= 0) return r;
  uint8_t st;
  t->mem_read(t->ctx, slot_iova(b, h) + 16, &st, 1);
  c->head = h;
  c->used_len = len;
  c->status = st;
  c->cookie = ck;
  return 1;
}

int vf_blk_wait(vf_blk_t *b, vf_blk_completion_t *c, uint32_t budget) {
  const vf_transport_t *t = b->dev.t;
  for (;;) {
    int r = vf_blk_poll(b, c);
    if (r != 0) return r;
    if (vf_dev_check(&b->dev)) return VF_E_NEEDS_RESET;
    if (budget == 0) return VF_E_TIMEOUT;
    uint32_t step = budget < 64 ? budget : 64;
    if (t->wait_irq(t->ctx, step)) vf_dev_ack_interrupt(&b->dev);
    budget -= step;
  }
}

static int sync_req(vf_blk_t *b, uint32_t type, uint64_t sector, const vf_sg_t *sg, unsigned n,
                    uint8_t *status) {
  uint16_t h;
  vf_blk_completion_t c;
  int r = vf_blk_submit(b, type, sector, sg, n, NULL, &h);
  if (r) return r;
  vf_vq_kick(&b->vq);
  r = vf_blk_wait(b, &c, 5u * 1000u * 1000u);
  if (r < 0) return r;
  if (c.head != h) return VF_E_PROTOCOL;   /* single outstanding: must match */
  if (status) *status = c.status;
  return vf_blk_status_to_err(c.status);
}

int vf_blk_rw_sync(vf_blk_t *b, int write, uint64_t sector, uint64_t buf, uint32_t len, uint8_t *status) {
  vf_sg_t sg = {buf, len, (uint8_t)(write ? 0 : 1)};
  return sync_req(b, write ? VIRTIO_BLK_T_OUT : VIRTIO_BLK_T_IN, sector, &sg, len ? 1 : 0, status);
}

int vf_blk_flush_sync(vf_blk_t *b, uint8_t *status) {
  return sync_req(b, VIRTIO_BLK_T_FLUSH, 0, NULL, 0, status);
}

int vf_blk_get_id_sync(vf_blk_t *b, char id[VIRTIO_BLK_ID_BYTES + 1]) {
  const vf_transport_t *t = b->dev.t;
  uint64_t buf;
  if (t->dma_alloc(t->ctx, VIRTIO_BLK_ID_BYTES, 4, &buf)) return VF_E_NOMEM;
  vf_sg_t sg = {buf, VIRTIO_BLK_ID_BYTES, 1};
  uint8_t st;
  int r = sync_req(b, VIRTIO_BLK_T_GET_ID, 0, &sg, 1, &st);
  if (r) return r;
  t->mem_read(t->ctx, buf, id, VIRTIO_BLK_ID_BYTES);
  id[VIRTIO_BLK_ID_BYTES] = 0;
  return VF_OK;
}
