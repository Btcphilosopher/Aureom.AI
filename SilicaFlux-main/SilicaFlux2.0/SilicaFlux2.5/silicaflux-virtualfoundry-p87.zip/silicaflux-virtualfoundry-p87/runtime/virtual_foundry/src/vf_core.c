/*
 * vf_core.c -- SilicaFlux Albion, Project 87 VirtualFoundry
 *
 * VirtIO driver core: virtio-mmio v2 transport, device initialisation (VirtIO 1.2 s3.1.1), feature
 * negotiation and split virtqueues (s2.7).  Derived from the Project 63 host library (sfv_core.c);
 * multi-queue devices (virtio-net) and a used-index sanity check are new.  All guest-memory
 * structures are encoded little-endian explicitly, so the library is correct on any host byte order.
 */
#include <stdlib.h>
#include <string.h>
#include "vf_host.h"

/* ---- little-endian helpers -------------------------------------------------------------------- */
static void put_le16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put_le32(uint8_t *p, uint32_t v) { for (int i = 0; i < 4; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static void put_le64(uint8_t *p, uint64_t v) { for (int i = 0; i < 8; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static uint16_t get_le16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t get_le32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint32_t rd(vf_dev_t *d, uint32_t off) { return d->t->mmio_read32(d->t->ctx, off); }
static void wr(vf_dev_t *d, uint32_t off, uint32_t v) { d->t->mmio_write32(d->t->ctx, off, v); }
static void mb(vf_dev_t *d) { if (d->t->mb) d->t->mb(d->t->ctx); }

static void mem_zero(const vf_transport_t *t, uint64_t iova, size_t len) {
  uint8_t z[256];
  memset(z, 0, sizeof z);
  while (len) {
    size_t n = len < sizeof z ? len : sizeof z;
    t->mem_write(t->ctx, iova, z, n);
    iova += n;
    len -= n;
  }
}

/* ---- lifecycle ----------------------------------------------------------------------------------- */
int vf_dev_probe(vf_dev_t *d, const vf_transport_t *t) {
  memset(d, 0, sizeof *d);
  d->t = t;
  if (rd(d, VIRTIO_MMIO_MAGIC_VALUE) != VIRTIO_MMIO_MAGIC) return VF_E_NODEV;
  if (rd(d, VIRTIO_MMIO_VERSION) != 2) return VF_E_VERSION;
  d->device_id = rd(d, VIRTIO_MMIO_DEVICE_ID);
  if (d->device_id == 0) return VF_E_NODEV;   /* s4.2.2: placeholder device */
  d->vendor_id = rd(d, VIRTIO_MMIO_VENDOR_ID);
  return VF_OK;
}

int vf_dev_reset(vf_dev_t *d) {
  wr(d, VIRTIO_MMIO_STATUS, 0);
  for (int i = 0; i < 1000; i++)               /* s2.1.2: wait for status to read 0 */
    if (rd(d, VIRTIO_MMIO_STATUS) == 0) return VF_OK;
  return VF_E_TIMEOUT;
}

uint8_t vf_dev_status(vf_dev_t *d) { return (uint8_t)rd(d, VIRTIO_MMIO_STATUS); }

int vf_dev_check(vf_dev_t *d) {
  return (vf_dev_status(d) & VIRTIO_STATUS_DEVICE_NEEDS_RESET) ? VF_E_NEEDS_RESET : VF_OK;
}

uint32_t vf_dev_ack_interrupt(vf_dev_t *d) {
  uint32_t s = rd(d, VIRTIO_MMIO_INTERRUPT_STATUS);
  if (s) wr(d, VIRTIO_MMIO_INTERRUPT_ACK, s);
  return s;
}

uint32_t vf_dev_config_read32(vf_dev_t *d, uint32_t off) { return rd(d, VIRTIO_MMIO_CONFIG + off); }

int vf_dev_negotiate(vf_dev_t *d, uint64_t wanted, uint64_t required) {
  uint32_t st = VIRTIO_STATUS_ACKNOWLEDGE;
  wr(d, VIRTIO_MMIO_STATUS, st);
  st |= VIRTIO_STATUS_DRIVER;
  wr(d, VIRTIO_MMIO_STATUS, st);

  wr(d, VIRTIO_MMIO_DEVICE_FEATURES_SEL, 0);
  uint64_t f = rd(d, VIRTIO_MMIO_DEVICE_FEATURES);
  wr(d, VIRTIO_MMIO_DEVICE_FEATURES_SEL, 1);
  f |= (uint64_t)rd(d, VIRTIO_MMIO_DEVICE_FEATURES) << 32;
  d->dev_features = f;

  uint64_t drv = f & wanted;                   /* never accept a feature the device did not offer */
  if ((drv & required) != required) {
    wr(d, VIRTIO_MMIO_STATUS, st | VIRTIO_STATUS_FAILED);
    return VF_E_FEATURES;
  }
  wr(d, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 0);
  wr(d, VIRTIO_MMIO_DRIVER_FEATURES, (uint32_t)drv);
  wr(d, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 1);
  wr(d, VIRTIO_MMIO_DRIVER_FEATURES, (uint32_t)(drv >> 32));
  d->drv_features = drv;

  st |= VIRTIO_STATUS_FEATURES_OK;
  wr(d, VIRTIO_MMIO_STATUS, st);
  if (!(rd(d, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_FEATURES_OK)) {   /* s3.1.1 step 6 */
    wr(d, VIRTIO_MMIO_STATUS, st | VIRTIO_STATUS_FAILED);
    return VF_E_FEATURES;
  }
  return VF_OK;
}

int vf_dev_driver_ok(vf_dev_t *d) {
  uint32_t st = rd(d, VIRTIO_MMIO_STATUS);
  wr(d, VIRTIO_MMIO_STATUS, st | VIRTIO_STATUS_DRIVER_OK);
  return vf_dev_check(d);
}

/* ---- virtqueue ------------------------------------------------------------------------------------ */
int vf_vq_setup(vf_dev_t *d, vf_vq_t *vq, uint16_t qidx, uint16_t size) {
  const vf_transport_t *t = d->t;
  memset(vq, 0, sizeof *vq);
  wr(d, VIRTIO_MMIO_QUEUE_SEL, qidx);
  if (rd(d, VIRTIO_MMIO_QUEUE_READY) != 0) return VF_E_QUEUE;
  uint32_t max = rd(d, VIRTIO_MMIO_QUEUE_NUM_MAX);
  if (max == 0 || size == 0 || size > max || (size & (size - 1))) return VF_E_QUEUE;

  size_t desc_sz  = 16u * size;
  size_t avail_sz = 6u + 2u * size;
  size_t used_sz  = 6u + 8u * size;
  if (t->dma_alloc(t->ctx, desc_sz, 16, &vq->desc_iova)) return VF_E_NOMEM;
  if (t->dma_alloc(t->ctx, avail_sz, 2, &vq->avail_iova)) return VF_E_NOMEM;
  if (t->dma_alloc(t->ctx, used_sz, 4, &vq->used_iova)) return VF_E_NOMEM;
  mem_zero(t, vq->desc_iova, desc_sz);
  mem_zero(t, vq->avail_iova, avail_sz);
  mem_zero(t, vq->used_iova, used_sz);

  vq->next      = (uint16_t *)calloc(size, sizeof(uint16_t));
  vq->chain_len = (uint16_t *)calloc(size, sizeof(uint16_t));
  vq->cookie    = (void **)calloc(size, sizeof(void *));
  if (!vq->next || !vq->chain_len || !vq->cookie) { vf_vq_destroy(vq); return VF_E_NOMEM; }
  for (uint16_t i = 0; i < size; i++) vq->next[i] = (uint16_t)(i + 1);

  vq->dev = d;
  vq->index = qidx;
  vq->size = size;
  vq->num_free = size;
  vq->free_head = 0;

  wr(d, VIRTIO_MMIO_QUEUE_NUM, size);
  wr(d, VIRTIO_MMIO_QUEUE_DESC_LOW,    (uint32_t)vq->desc_iova);
  wr(d, VIRTIO_MMIO_QUEUE_DESC_HIGH,   (uint32_t)(vq->desc_iova >> 32));
  wr(d, VIRTIO_MMIO_QUEUE_DRIVER_LOW,  (uint32_t)vq->avail_iova);
  wr(d, VIRTIO_MMIO_QUEUE_DRIVER_HIGH, (uint32_t)(vq->avail_iova >> 32));
  wr(d, VIRTIO_MMIO_QUEUE_DEVICE_LOW,  (uint32_t)vq->used_iova);
  wr(d, VIRTIO_MMIO_QUEUE_DEVICE_HIGH, (uint32_t)(vq->used_iova >> 32));
  wr(d, VIRTIO_MMIO_QUEUE_READY, 1);
  if (rd(d, VIRTIO_MMIO_QUEUE_READY) != 1) { vf_vq_destroy(vq); return VF_E_QUEUE; }
  return VF_OK;
}

void vf_vq_destroy(vf_vq_t *vq) {
  free(vq->next);
  free(vq->chain_len);
  free(vq->cookie);
  vq->next = NULL;
  vq->chain_len = NULL;
  vq->cookie = NULL;
}

int vf_vq_add(vf_vq_t *vq, const vf_sg_t *sg, unsigned nsg, void *cookie, uint16_t *head_out) {
  const vf_transport_t *t = vq->dev->t;
  if (nsg == 0) return VF_E_INVAL;
  if (nsg > vq->num_free) return VF_E_NOSPC;

  uint16_t head = vq->free_head, cur = head;
  for (unsigned i = 0; i < nsg; i++) {
    uint8_t desc[16];
    uint16_t nxt = vq->next[cur];
    uint16_t flags = (uint16_t)((sg[i].device_writable ? VIRTQ_DESC_F_WRITE : 0) |
                                (i + 1 < nsg ? VIRTQ_DESC_F_NEXT : 0));
    put_le64(desc + 0, sg[i].addr);
    put_le32(desc + 8, sg[i].len);
    put_le16(desc + 12, flags);
    put_le16(desc + 14, (i + 1 < nsg) ? nxt : 0);
    t->mem_write(t->ctx, vq->desc_iova + 16ull * cur, desc, 16);
    if (i + 1 < nsg) cur = nxt;
    else vq->free_head = nxt;
  }
  vq->num_free = (uint16_t)(vq->num_free - nsg);
  vq->chain_len[head] = (uint16_t)nsg;
  vq->cookie[head] = cookie;

  /* s2.7.13: place the head in the avail ring, barrier, then publish avail.idx */
  uint8_t b[2];
  uint16_t slot = (uint16_t)(vq->avail_idx & (vq->size - 1));
  put_le16(b, head);
  t->mem_write(t->ctx, vq->avail_iova + 4 + 2ull * slot, b, 2);
  mb(vq->dev);
  vq->avail_idx++;
  put_le16(b, vq->avail_idx);
  t->mem_write(t->ctx, vq->avail_iova + 2, b, 2);
  mb(vq->dev);
  if (head_out) *head_out = head;
  return VF_OK;
}

void vf_vq_kick(vf_vq_t *vq) {
  mb(vq->dev);
  wr(vq->dev, VIRTIO_MMIO_QUEUE_NOTIFY, vq->index);
}

uint16_t vf_vq_device_used_idx(vf_vq_t *vq) {
  uint8_t b[2];
  vq->dev->t->mem_read(vq->dev->t->ctx, vq->used_iova + 2, b, 2);
  return get_le16(b);
}

int vf_vq_get_used(vf_vq_t *vq, uint16_t *head, uint32_t *len, void **cookie) {
  const vf_transport_t *t = vq->dev->t;
  uint16_t used = vf_vq_device_used_idx(vq);
  if (used == vq->last_used) return 0;
  if ((uint16_t)(used - vq->last_used) > vq->size) return VF_E_PROTOCOL;   /* device ran ahead of the ring */
  mb(vq->dev);   /* read used.idx before the element it covers */
  uint8_t e[8];
  uint16_t slot = (uint16_t)(vq->last_used & (vq->size - 1));
  t->mem_read(t->ctx, vq->used_iova + 4 + 8ull * slot, e, 8);
  uint32_t id = get_le32(e), l = get_le32(e + 4);
  if (id >= vq->size || vq->chain_len[id] == 0) return VF_E_PROTOCOL;     /* not a head we submitted */

  /* return the chain to the free list */
  uint16_t n = vq->chain_len[id], last = (uint16_t)id;
  for (uint16_t i = 1; i < n; i++) last = vq->next[last];
  vq->next[last] = vq->free_head;
  vq->free_head = (uint16_t)id;
  vq->num_free = (uint16_t)(vq->num_free + n);
  vq->chain_len[id] = 0;

  if (head) *head = (uint16_t)id;
  if (len) *len = l;
  if (cookie) *cookie = vq->cookie[id];
  vq->cookie[id] = NULL;
  vq->last_used++;
  return 1;
}

void vf_vq_set_no_interrupt(vf_vq_t *vq, int suppress) {
  uint8_t b[2];
  vq->avail_flags = suppress ? VIRTQ_AVAIL_F_NO_INTERRUPT : 0;
  put_le16(b, vq->avail_flags);
  vq->dev->t->mem_write(vq->dev->t->ctx, vq->avail_iova, b, 2);
  mb(vq->dev);
}

/* ---- error strings ----------------------------------------------------------------------------------- */
const char *vf_strerror(int err) {
  switch (err) {
    case VF_OK: return "ok";
    case VF_E_NODEV: return "no virtio device";
    case VF_E_VERSION: return "unsupported virtio-mmio version";
    case VF_E_FEATURES: return "feature negotiation failed";
    case VF_E_QUEUE: return "queue unavailable";
    case VF_E_NOSPC: return "no free descriptors";
    case VF_E_NEEDS_RESET: return "device needs reset";
    case VF_E_TIMEOUT: return "timeout";
    case VF_E_INVAL: return "invalid argument";
    case VF_E_NOMEM: return "out of DMA memory";
    case VF_E_IO: return "I/O error";
    case VF_E_UNSUPP: return "unsupported request";
    case VF_E_PROTOCOL: return "device protocol violation";
    default: return "unknown";
  }
}

const char *vf_fatal_cause_name(unsigned c) {
  static const char *n[] = {
    "NONE", "QUEUE_CFG", "NO_DOMAIN", "AVAIL_IDX_JUMP", "RING_DMA", "DESC_IDX_OOR",
    "CHAIN_LOOP", "CHAIN_TOO_LONG", "DESC_FLAGS", "CHAIN_ORDER", "CHAIN_LEN_OVF",
    "WRITABLE_PERM", "NO_STATUS", "DATA_WRITE_DMA"};
  return c < sizeof n / sizeof n[0] ? n[c] : "UNKNOWN";
}

const char *vf_fault_src_name(unsigned s) {
  static const char *n[] = {"NONE", "GATE", "DESC", "CITADEL", "BRIDGE", "TIMEOUT", "ECHO"};
  return s < sizeof n / sizeof n[0] ? n[s] : "UNKNOWN";
}
