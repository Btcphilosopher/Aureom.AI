/*
 * vf_net.c -- SilicaFlux Albion, Project 87 VirtualFoundry
 *
 * virtio-net driver layer (VirtIO 1.2 s5.1) on top of vf_core.c.  Only the features the device
 * offers are used: VERSION_1, ACCESS_PLATFORM, MAC, STATUS.  Receive buffers are single device-writable
 * buffers of at least 12 + the largest frame (no MRG_RXBUF, no offloads); transmit chains are
 * {12-byte virtio_net_hdr, frame}, both device-readable.
 */
#include <string.h>
#include "vf_host.h"

int vf_net_open(vf_net_t *n, const vf_transport_t *t, uint16_t rx_qsize, uint16_t tx_qsize) {
  memset(n, 0, sizeof *n);
  int r = vf_dev_probe(&n->dev, t);
  if (r) return r;
  if (n->dev.device_id != VIRTIO_ID_NET) return VF_E_NODEV;
  if ((r = vf_dev_reset(&n->dev))) return r;

  const uint64_t wanted = VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM) |
                          VF_FEAT(VIRTIO_NET_F_MAC) | VF_FEAT(VIRTIO_NET_F_STATUS);
  const uint64_t required = VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM);
  if ((r = vf_dev_negotiate(&n->dev, wanted, required))) return r;

  if (n->dev.drv_features & VF_FEAT(VIRTIO_NET_F_MAC)) {
    uint32_t g0, g1, lo, hi;
    do {
      g0 = t->mmio_read32(t->ctx, VIRTIO_MMIO_CONFIG_GENERATION);
      lo = vf_dev_config_read32(&n->dev, VIRTIO_NET_CFG_MAC);
      hi = vf_dev_config_read32(&n->dev, VIRTIO_NET_CFG_MAC + 4);
      g1 = t->mmio_read32(t->ctx, VIRTIO_MMIO_CONFIG_GENERATION);
    } while (g0 != g1);
    for (int i = 0; i < 4; i++) n->mac[i] = (uint8_t)(lo >> (8 * i));
    n->mac[4] = (uint8_t)hi;
    n->mac[5] = (uint8_t)(hi >> 8);
    n->link_up = (n->dev.drv_features & VF_FEAT(VIRTIO_NET_F_STATUS)) ? (int)((hi >> 16) & VIRTIO_NET_S_LINK_UP) : 1;
  }
  if ((r = vf_vq_setup(&n->dev, &n->rxq, 0, rx_qsize))) return r;
  if ((r = vf_vq_setup(&n->dev, &n->txq, 1, tx_qsize))) return r;
  if (t->dma_alloc(t->ctx, (size_t)VIRTIO_NET_HDR_BYTES * tx_qsize, 8, &n->hdr_pool)) return VF_E_NOMEM;
  return vf_dev_driver_ok(&n->dev);
}

void vf_net_close(vf_net_t *n) { vf_vq_destroy(&n->rxq); vf_vq_destroy(&n->txq); }

int vf_net_post_rx(vf_net_t *n, uint64_t buf, uint32_t len, void *cookie, uint16_t *head) {
  vf_sg_t sg = {buf, len, 1};
  return vf_vq_add(&n->rxq, &sg, 1, cookie, head);
}

int vf_net_send(vf_net_t *n, uint64_t frame, uint32_t len, void *cookie, uint16_t *head) {
  const vf_transport_t *t = n->dev.t;
  if (n->txq.num_free < 2) return VF_E_NOSPC;
  uint16_t h = n->txq.free_head;
  uint8_t hdr[VIRTIO_NET_HDR_BYTES];
  memset(hdr, 0, sizeof hdr);                     /* flags 0, gso_type NONE, no checksum offload */
  uint64_t hdr_iova = n->hdr_pool + (uint64_t)VIRTIO_NET_HDR_BYTES * h;
  t->mem_write(t->ctx, hdr_iova, hdr, sizeof hdr);
  vf_sg_t sg[2] = {{hdr_iova, VIRTIO_NET_HDR_BYTES, 0}, {frame, len, 0}};
  return vf_vq_add(&n->txq, sg, 2, cookie, head);
}

static int poll(vf_vq_t *vq, vf_net_completion_t *c) {
  uint16_t h;
  uint32_t len;
  void *ck;
  int r = vf_vq_get_used(vq, &h, &len, &ck);
  if (r <= 0) return r;
  c->head = h;
  c->used_len = len;
  c->cookie = ck;
  return 1;
}

int vf_net_poll_rx(vf_net_t *n, vf_net_completion_t *c) { return poll(&n->rxq, c); }
int vf_net_poll_tx(vf_net_t *n, vf_net_completion_t *c) { return poll(&n->txq, c); }
