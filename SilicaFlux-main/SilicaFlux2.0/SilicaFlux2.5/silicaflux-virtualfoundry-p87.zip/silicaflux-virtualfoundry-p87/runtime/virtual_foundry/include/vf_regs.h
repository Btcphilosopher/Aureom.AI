/*
 * vf_regs.h -- SilicaFlux Albion, Project 87 VirtualFoundry
 *
 * Register offsets and protocol constants shared by the host library, the simulation platform and
 * the tests.  Kept in sync with rtl/albion/sf_virtual_pkg.sv and sf_virtual_ctx_mgmt.sv; the check
 * is mechanical: tests/virtual_foundry/tb/tb_pkg_consistency.sv compares the SystemVerilog package
 * with tests/virtual_foundry/tools/check_regs.py, which parses this header.
 *
 * Normative reference for every VIRTIO_* constant: OASIS VIRTIO 1.2 (cs01).
 */
#ifndef VF_REGS_H
#define VF_REGS_H

#include <stdint.h>

/* ---- virtio-mmio v2 (spec 4.2.2) --------------------------------------------------------------- */
#define VIRTIO_MMIO_MAGIC_VALUE          0x000u
#define VIRTIO_MMIO_MAGIC                0x74726976u
#define VIRTIO_MMIO_VERSION              0x004u
#define VIRTIO_MMIO_DEVICE_ID            0x008u
#define VIRTIO_MMIO_VENDOR_ID            0x00cu
#define VIRTIO_MMIO_DEVICE_FEATURES      0x010u
#define VIRTIO_MMIO_DEVICE_FEATURES_SEL  0x014u
#define VIRTIO_MMIO_DRIVER_FEATURES      0x020u
#define VIRTIO_MMIO_DRIVER_FEATURES_SEL  0x024u
#define VIRTIO_MMIO_QUEUE_SEL            0x030u
#define VIRTIO_MMIO_QUEUE_NUM_MAX        0x034u
#define VIRTIO_MMIO_QUEUE_NUM            0x038u
#define VIRTIO_MMIO_QUEUE_READY          0x044u
#define VIRTIO_MMIO_QUEUE_NOTIFY         0x050u
#define VIRTIO_MMIO_INTERRUPT_STATUS     0x060u
#define VIRTIO_MMIO_INTERRUPT_ACK        0x064u
#define VIRTIO_MMIO_STATUS               0x070u
#define VIRTIO_MMIO_QUEUE_DESC_LOW       0x080u
#define VIRTIO_MMIO_QUEUE_DESC_HIGH      0x084u
#define VIRTIO_MMIO_QUEUE_DRIVER_LOW     0x090u
#define VIRTIO_MMIO_QUEUE_DRIVER_HIGH    0x094u
#define VIRTIO_MMIO_QUEUE_DEVICE_LOW     0x0a0u
#define VIRTIO_MMIO_QUEUE_DEVICE_HIGH    0x0a4u
#define VIRTIO_MMIO_CONFIG_GENERATION    0x0fcu
#define VIRTIO_MMIO_CONFIG               0x100u
#define VIRTIO_MMIO_INT_VRING            0x1u
#define VIRTIO_MMIO_INT_CONFIG           0x2u

/* ---- device status (spec 2.1) ----------------------------------------------------------------- */
#define VIRTIO_STATUS_ACKNOWLEDGE        1u
#define VIRTIO_STATUS_DRIVER             2u
#define VIRTIO_STATUS_DRIVER_OK          4u
#define VIRTIO_STATUS_FEATURES_OK        8u
#define VIRTIO_STATUS_DEVICE_NEEDS_RESET 64u
#define VIRTIO_STATUS_FAILED             128u

/* ---- feature bits ------------------------------------------------------------------------------ */
#define VIRTIO_F_INDIRECT_DESC     28
#define VIRTIO_F_EVENT_IDX         29
#define VIRTIO_F_VERSION_1         32
#define VIRTIO_F_ACCESS_PLATFORM   33
#define VIRTIO_F_RING_PACKED       34
#define VIRTIO_BLK_F_SEG_MAX       2
#define VIRTIO_BLK_F_RO            5
#define VIRTIO_BLK_F_FLUSH         9
#define VIRTIO_NET_F_MAC           5
#define VIRTIO_NET_F_MRG_RXBUF     15
#define VIRTIO_NET_F_STATUS        16

/* ---- split virtqueue (spec 2.7) --------------------------------------------------------------- */
#define VIRTQ_DESC_F_NEXT          1u
#define VIRTQ_DESC_F_WRITE         2u
#define VIRTQ_DESC_F_INDIRECT      4u
#define VIRTQ_AVAIL_F_NO_INTERRUPT 1u

/* ---- virtio-blk (spec 5.2) --------------------------------------------------------------------- */
#define VIRTIO_ID_NET              1u
#define VIRTIO_ID_BLOCK            2u
#define VIRTIO_BLK_T_IN            0u
#define VIRTIO_BLK_T_OUT           1u
#define VIRTIO_BLK_T_FLUSH         4u
#define VIRTIO_BLK_T_GET_ID        8u
#define VIRTIO_BLK_S_OK            0u
#define VIRTIO_BLK_S_IOERR         1u
#define VIRTIO_BLK_S_UNSUPP        2u
#define VIRTIO_BLK_ID_BYTES        20
#define VIRTIO_BLK_SECTOR_BYTES    512
#define VIRTIO_BLK_REQ_HDR_BYTES   16

/* ---- virtio-net (spec 5.1) --------------------------------------------------------------------- */
#define VIRTIO_NET_HDR_BYTES       12
#define VIRTIO_NET_S_LINK_UP       1u

/* ---- management bus: [15:12] page (0..NCTX-1 context, 0xF global), [11:0] offset ----------------- */
#define VF_MGMT_PAGE(ctx)          ((uint32_t)(ctx) << 12)
#define VF_MGMT_GLOBAL             0xF000u

/* context page */
#define VF_M_ID                    0x000u   /* 0x53465646 "SFVF"                                       */
#define VF_M_VER                   0x004u   /* [23:16] major [15:8] minor [7:0] patch                  */
#define VF_M_CAPS0                 0x008u   /* [7:0] queues [15:8] MAX_CHAIN [23:16] N_WIN [24] split  */
                                            /* [29] windows [30] Citadel path [31] BridgeEngine path   */
#define VF_M_CAPS1                 0x00cu   /* [15:0] MAX_QSZ [31:24] virtio device id                 */
#define VF_M_DOMAIN                0x010u   /* [15:0] domain, [31] valid; locked while a queue is live  */
#define VF_M_STATUS                0x014u   /* [0] busy [1] active [2] needs_reset [3] cfg write ignored */
                                            /* [15:8] last fatal cause [23:16] dev status [27:24] qready */
#define VF_M_FAULT_LO              0x018u
#define VF_M_FAULT_HI              0x01cu
#define VF_M_FAULT_INFO            0x020u   /* [0] write [1] valid [7:4] source FS_* [15:8] detail      */
#define VF_M_CTRL                  0x024u   /* W: [0] host reset  [1] clear counters  [2] clear sticky  */
#define VF_M_FAULT_CNT             0x028u
#define VF_M_WIN_BASE              0x040u   /* + 0x20*i : +0 ctrl [0]valid [1]rd [2]wr, +4 domain,     */
                                            /* +8/+c base lo/hi, +0x10/+0x14 limit lo/hi (inclusive)    */
#define VF_M_EXT_SIZE_LO           0x180u
#define VF_M_EXT_SIZE_HI           0x184u
#define VF_M_EXT_BASE_LO           0x188u
#define VF_M_EXT_BASE_HI           0x18cu
#define VF_M_EXT_FLAGS             0x190u   /* [0] read-only                                            */
#define VF_M_MAC_LO                0x194u
#define VF_M_MAC_HI                0x198u
#define VF_M_PERF                  0x200u
#define VF_M_DEVCNT                0x300u   /* 8 device-specific event counters                         */

/* performance counter offsets (relative to VF_M_PERF) */
#define VF_P_DESC          0x000u
#define VF_P_REQ           0x004u
#define VF_P_RD_BYTES      0x008u  /* 64-bit */
#define VF_P_WR_BYTES      0x010u  /* 64-bit */
#define VF_P_CLAT_SUM      0x018u  /* 64-bit */
#define VF_P_CLAT_MAX      0x020u
#define VF_P_WLAT_SUM      0x024u  /* 64-bit */
#define VF_P_WLAT_MAX      0x02cu
#define VF_P_IRQ           0x030u
#define VF_P_IRQ_SUP       0x034u
#define VF_P_STALL         0x038u
#define VF_P_VIOL          0x03cu
#define VF_P_QD_SUM        0x040u  /* 64-bit */
#define VF_P_QD_MAX        0x048u
#define VF_P_QD_N          0x04cu
#define VF_P_NOTIFY        0x050u
#define VF_P_FATAL         0x054u
#define VF_P_BUSY          0x058u  /* 64-bit */
#define VF_P_TOTAL         0x060u  /* 64-bit */
#define VF_P_QW_SUM        0x068u  /* 64-bit, queue waiting time */
#define VF_P_QW_MAX        0x070u
#define VF_P_QW_N          0x074u
#define VF_P_INVALID       0x078u
#define VF_P_BEWAIT        0x07cu  /* 64-bit, backend response wait cycles */
#define VF_P_BRIDGE_ERR    0x084u

/* block device event counters (VF_M_DEVCNT + 4*i) */
#define VF_DC_BLK_READ_OK   0
#define VF_DC_BLK_WRITE_OK  1
#define VF_DC_BLK_FLUSH_OK  2
#define VF_DC_BLK_GETID_OK  3
#define VF_DC_BLK_IOERR     4
#define VF_DC_BLK_UNSUPP    5
#define VF_DC_BLK_STOR_ERR  6
#define VF_DC_BLK_DIR_ERR   7
/* network device event counters */
#define VF_DC_NET_TX_OK         0
#define VF_DC_NET_RX_OK         1
#define VF_DC_NET_TX_DROP       2   /* bad header / size / direction / DMA fault: frame dropped */
#define VF_DC_NET_RX_DROP_FULL  3   /* frame buffer busy: arriving frame dropped                */
#define VF_DC_NET_RX_DROP_BAD   4   /* oversize / malformed arriving frame dropped              */
#define VF_DC_NET_RX_BUF_REJ    5   /* guest rx buffer unusable (too small / readable), retained */
#define VF_DC_NET_TX_DMA_ERR    6
#define VF_DC_NET_RX_DIR_ERR    7

/* global page */
#define VF_G_ID            0xF000u  /* 0x53465647 "SFVG"                                         */
#define VF_G_VER           0xF004u
#define VF_G_CAPS          0xF008u  /* [3:0] NCTX [7:4] TAGW [11:8] DOM_W-1 [27:12] net bitmap  */
#define VF_G_STATUS        0xF00cu  /* [0] bridge busy [1] isolated (silent endpoint)           */
#define VF_G_ORPHAN        0xF010u
#define VF_G_CTRL          0xF014u  /* W: [0] clear bridge counters                             */
#define VF_G_PF_UNMATCHED  0xF018u
#define VF_G_CHK_TMO       0xF01cu
#define VF_G_RSP_TMO       0xF020u
#define VF_G_ST_TIMEOUTS   0xF024u  /* storage responses that timed out */
#define VF_G_ST_TMO        0xF028u
#define VF_G_ST_ISOLATED   0xF02cu  /* [0] storage port isolated (silent StorageCore) */
#define VF_G_BRIDGE(ctx)   (0xF100u + 0x40u * (uint32_t)(ctx))
/* bridge counters (word index inside VF_G_BRIDGE(ctx)) */
#define VF_B_REQS          0
#define VF_B_RD_BYTES      1   /* 64-bit lo/hi */
#define VF_B_WR_BYTES      3   /* 64-bit lo/hi */
#define VF_B_CIT_DENIED    5
#define VF_B_BDG_ERR       6
#define VF_B_TIMEOUT       7
#define VF_B_STALL         8
#define VF_B_LAT_SUM       9   /* 64-bit lo/hi */
#define VF_B_LAT_MAX       11

/* fatal (DEVICE_NEEDS_RESET) causes, VF_M_STATUS[15:8] */
#define VF_FC_NONE            0
#define VF_FC_QUEUE_CFG       1
#define VF_FC_NO_DOMAIN       2
#define VF_FC_AVAIL_IDX_JUMP  3
#define VF_FC_RING_DMA        4
#define VF_FC_DESC_IDX_OOR    5
#define VF_FC_CHAIN_LOOP      6
#define VF_FC_CHAIN_TOO_LONG  7
#define VF_FC_DESC_FLAGS      8
#define VF_FC_CHAIN_ORDER     9
#define VF_FC_CHAIN_LEN_OVF   10
#define VF_FC_WRITABLE_PERM   11
#define VF_FC_NO_STATUS       12
#define VF_FC_DATA_WRITE_DMA  13

/* fault source codes, VF_M_FAULT_INFO[7:4] */
#define VF_FS_NONE     0
#define VF_FS_GATE     1
#define VF_FS_DESC     2
#define VF_FS_CITADEL  3
#define VF_FS_BRIDGE   4
#define VF_FS_TIMEOUT  5
#define VF_FS_ECHO     6

/* Albion transaction format (P83), used by the Citadel / BridgeEngine bench models */
#define VF_ALB_OP_READ     0
#define VF_ALB_OP_WRITE    1
#define VF_ALB_ST_OKAY     0
#define VF_ALB_ST_SLVERR   1
#define VF_ALB_ST_DECERR   2
#define VF_ALB_ST_DENIED   3
#define VF_ALB_ST_TIMEOUT  4
#define VF_ALB_ST_PROTO    5
#define VF_ALB_F_NONE      0
#define VF_ALB_F_NOMAP     1
#define VF_ALB_F_PERM      2
#define VF_ALB_F_DOMAIN    3
#define VF_ALB_F_PRIV      4
#define VF_ALB_F_CITTMO    6

/* ---- helpers ------------------------------------------------------------------------------------ */
#define VF_FEAT(bit)               (1ull << (bit))
#define VIRTIO_BLK_CFG_CAPACITY    0x00u   /* le64, sectors                                */
#define VIRTIO_BLK_CFG_SEG_MAX     0x0cu   /* le32                                         */
#define VIRTIO_NET_CFG_MAC         0x00u   /* 6 bytes, byte 0 first                        */
#define VIRTIO_NET_CFG_STATUS      0x06u   /* le16                                         */

#endif /* VF_REGS_H */
