/*
 * vf_host.h -- SilicaFlux Albion, Project 87 VirtualFoundry
 *
 * Minimal host library for testing and driving the VirtualFoundry device model.
 *
 *  - Guest side ("the VM driver"): virtio-mmio v2 transport, feature negotiation (VirtIO 1.2 s3.1.1),
 *    split virtqueues, virtio-blk and virtio-net request helpers.
 *  - Hypervisor side (vf_hv_*): domain binding, window table, storage extent, MAC, host reset, fault
 *    and counter readout through the privileged management page.
 *
 * The library never touches hardware directly.  Every register and memory access goes through a
 * vf_transport_t / vf_mgmt_t, so the same code runs against the Verilator co-simulation
 * (vf_sim.h, no PCIe hardware needed) or a real platform binding (MMIO mapping + DMA-coherent
 * memory).  Guest-memory structures are encoded little-endian explicitly, so the library is correct
 * on any host byte order.
 *
 * It is a test and bring-up library, not a Linux driver: it is not a replacement for virtio_blk /
 * virtio_net and has not been run against them (docs 08_LIMITATIONS.md).
 */
#ifndef VF_HOST_H
#define VF_HOST_H

#include <stddef.h>
#include <stdint.h>
#include "vf_regs.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---- error codes ------------------------------------------------------------------------------ */
enum {
  VF_OK            = 0,
  VF_E_NODEV       = -1,   /* bad magic / device id                            */
  VF_E_VERSION     = -2,   /* not virtio-mmio version 2                        */
  VF_E_FEATURES    = -3,   /* required feature missing / FEATURES_OK refused   */
  VF_E_QUEUE       = -4,   /* queue unavailable / bad size                     */
  VF_E_NOSPC       = -5,   /* not enough free descriptors                      */
  VF_E_NEEDS_RESET = -6,   /* device reported DEVICE_NEEDS_RESET               */
  VF_E_TIMEOUT     = -7,
  VF_E_INVAL       = -8,
  VF_E_NOMEM       = -9,
  VF_E_IO          = -10,  /* request completed with VIRTIO_BLK_S_IOERR        */
  VF_E_UNSUPP      = -11,  /* request completed with VIRTIO_BLK_S_UNSUPP       */
  VF_E_PROTOCOL    = -12   /* device violated the protocol (bad used entry)    */
};

/* ---- platform bindings -------------------------------------------------------------------------- */
typedef struct vf_transport {
  void *ctx;
  /* guest-visible virtio-mmio window of ONE guest context */
  uint32_t (*mmio_read32)(void *ctx, uint32_t off);
  void     (*mmio_write32)(void *ctx, uint32_t off, uint32_t val);
  /* guest memory (the IOVA space shared with the device) */
  int      (*dma_alloc)(void *ctx, size_t size, size_t align, uint64_t *iova);
  void     (*mem_write)(void *ctx, uint64_t iova, const void *src, size_t len);
  void     (*mem_read)(void *ctx, uint64_t iova, void *dst, size_t len);
  void     (*mb)(void *ctx);                        /* full barrier between driver and device views */
  /* wait for the interrupt line or until `budget` transport time units elapse; non-zero = asserted */
  int      (*wait_irq)(void *ctx, uint32_t budget);
} vf_transport_t;

/* privileged management bus (Keystone / hypervisor); never given to a guest */
typedef struct vf_mgmt {
  void *ctx;
  uint32_t (*read32)(void *ctx, uint32_t addr);     /* addr = VF_MGMT_PAGE(ctx) | offset, or VF_G_* */
  void     (*write32)(void *ctx, uint32_t addr, uint32_t val);
} vf_mgmt_t;

/* ---- scatter-gather element ------------------------------------------------------------------------ */
typedef struct vf_sg {
  uint64_t addr;             /* IOVA                                   */
  uint32_t len;
  uint8_t  device_writable;  /* 1 => VIRTQ_DESC_F_WRITE                */
} vf_sg_t;

/* ---- split virtqueue (driver side) ------------------------------------------------------------------- */
struct vf_dev;
typedef struct vf_vq {
  struct vf_dev *dev;
  uint16_t index;
  uint16_t size;
  uint64_t desc_iova, avail_iova, used_iova;
  uint16_t avail_idx;     /* next avail.idx to publish                    */
  uint16_t last_used;     /* next used entry to consume                   */
  uint16_t free_head;
  uint16_t num_free;
  uint16_t *next;         /* driver-private free list / chain links       */
  uint16_t *chain_len;    /* descriptors per in-flight head               */
  void    **cookie;       /* caller cookie per in-flight head             */
  uint16_t avail_flags;
} vf_vq_t;

typedef struct vf_dev {
  const vf_transport_t *t;
  uint32_t device_id, vendor_id;
  uint64_t dev_features;
  uint64_t drv_features;
} vf_dev_t;

/* ---- device lifecycle (VirtIO 1.2 s3.1.1) ----------------------------------------------------------------- */
int      vf_dev_probe(vf_dev_t *d, const vf_transport_t *t);
int      vf_dev_reset(vf_dev_t *d);
int      vf_dev_negotiate(vf_dev_t *d, uint64_t wanted, uint64_t required);
int      vf_vq_setup(vf_dev_t *d, vf_vq_t *vq, uint16_t qidx, uint16_t size);
void     vf_vq_destroy(vf_vq_t *vq);
int      vf_dev_driver_ok(vf_dev_t *d);
uint8_t  vf_dev_status(vf_dev_t *d);
int      vf_dev_check(vf_dev_t *d);                  /* VF_E_NEEDS_RESET if the device set it */
uint32_t vf_dev_ack_interrupt(vf_dev_t *d);          /* returns InterruptStatus               */
uint32_t vf_dev_config_read32(vf_dev_t *d, uint32_t off);

/* ---- virtqueue operations --------------------------------------------------------------------------------- */
int      vf_vq_add(vf_vq_t *vq, const vf_sg_t *sg, unsigned nsg, void *cookie, uint16_t *head);
void     vf_vq_kick(vf_vq_t *vq);
int      vf_vq_get_used(vf_vq_t *vq, uint16_t *head, uint32_t *len, void **cookie);
void     vf_vq_set_no_interrupt(vf_vq_t *vq, int suppress);
uint16_t vf_vq_device_used_idx(vf_vq_t *vq);

/* ---- virtio-blk ---------------------------------------------------------------------------------------------- */
typedef struct vf_blk {
  vf_dev_t  dev;
  vf_vq_t   vq;
  uint64_t  capacity;       /* sectors                                           */
  uint32_t  seg_max;        /* data segments per request                         */
  uint64_t  pool_iova;      /* per-head header(16) + status(1) slots, 32 B each  */
  int       has_flush;
  int       read_only;
} vf_blk_t;

typedef struct vf_blk_completion {
  uint16_t head;
  uint32_t used_len;
  uint8_t  status;
  void    *cookie;
} vf_blk_completion_t;

int  vf_blk_open(vf_blk_t *b, const vf_transport_t *t, uint16_t qsize);
void vf_blk_close(vf_blk_t *b);
int  vf_blk_submit(vf_blk_t *b, uint32_t type, uint64_t sector, const vf_sg_t *data, unsigned ndata,
                   void *cookie, uint16_t *head);
int  vf_blk_poll(vf_blk_t *b, vf_blk_completion_t *c);   /* 1 = got one, 0 = none, <0 error */
int  vf_blk_wait(vf_blk_t *b, vf_blk_completion_t *c, uint32_t budget);
int  vf_blk_rw_sync(vf_blk_t *b, int write, uint64_t sector, uint64_t buf, uint32_t len, uint8_t *status);
int  vf_blk_flush_sync(vf_blk_t *b, uint8_t *status);
int  vf_blk_get_id_sync(vf_blk_t *b, char id[VIRTIO_BLK_ID_BYTES + 1]);
int  vf_blk_status_to_err(uint8_t status);

/* ---- virtio-net -------------------------------------------------------------------------------------------------- */
typedef struct vf_net {
  vf_dev_t  dev;
  vf_vq_t   rxq;            /* queue 0 */
  vf_vq_t   txq;            /* queue 1 */
  uint8_t   mac[6];
  int       link_up;
  uint64_t  hdr_pool;       /* tx: one 12-byte header per head */
} vf_net_t;

typedef struct vf_net_completion {
  uint16_t head;
  uint32_t used_len;        /* rx: bytes written by the device (header + frame); tx: 0 */
  void    *cookie;
} vf_net_completion_t;

int  vf_net_open(vf_net_t *n, const vf_transport_t *t, uint16_t rx_qsize, uint16_t tx_qsize);
void vf_net_close(vf_net_t *n);
int  vf_net_post_rx(vf_net_t *n, uint64_t buf_iova, uint32_t len, void *cookie, uint16_t *head);
int  vf_net_send(vf_net_t *n, uint64_t frame_iova, uint32_t len, void *cookie, uint16_t *head);
int  vf_net_poll_rx(vf_net_t *n, vf_net_completion_t *c);   /* 1 got one, 0 none, <0 error */
int  vf_net_poll_tx(vf_net_t *n, vf_net_completion_t *c);

/* ---- hypervisor helpers (privileged management page) --------------------------------------------------------- */
typedef struct vf_hv_info {
  uint32_t id, version, caps0, caps1;
} vf_hv_info_t;

int      vf_hv_probe_ctx(const vf_mgmt_t *m, unsigned ctx, vf_hv_info_t *info);
int      vf_hv_probe_global(const vf_mgmt_t *m, unsigned *nctx, uint32_t *net_bitmap);
void     vf_hv_bind_domain(const vf_mgmt_t *m, unsigned ctx, uint16_t domain);
void     vf_hv_unbind_domain(const vf_mgmt_t *m, unsigned ctx);
void     vf_hv_set_window(const vf_mgmt_t *m, unsigned ctx, unsigned win, uint16_t domain,
                          uint64_t base, uint64_t limit_incl, int rd, int wr);
void     vf_hv_clear_window(const vf_mgmt_t *m, unsigned ctx, unsigned win);
void     vf_hv_set_extent(const vf_mgmt_t *m, unsigned ctx, uint64_t base_sectors, uint64_t size_sectors, int read_only);
void     vf_hv_set_mac(const vf_mgmt_t *m, unsigned ctx, const uint8_t mac[6]);
int      vf_hv_host_reset(const vf_mgmt_t *m, unsigned ctx, uint32_t budget);
void     vf_hv_clear_counters(const vf_mgmt_t *m, unsigned ctx);
void     vf_hv_clear_faults(const vf_mgmt_t *m, unsigned ctx);
uint32_t vf_hv_perf32(const vf_mgmt_t *m, unsigned ctx, uint32_t off);
uint64_t vf_hv_perf64(const vf_mgmt_t *m, unsigned ctx, uint32_t off);
uint32_t vf_hv_devcnt(const vf_mgmt_t *m, unsigned ctx, unsigned idx);
uint32_t vf_hv_bridge32(const vf_mgmt_t *m, unsigned ctx, unsigned word);
uint64_t vf_hv_bridge64(const vf_mgmt_t *m, unsigned ctx, unsigned word);
uint8_t  vf_hv_fatal_cause(const vf_mgmt_t *m, unsigned ctx);
uint32_t vf_hv_status(const vf_mgmt_t *m, unsigned ctx);
typedef struct vf_hv_fault {
  int valid, write;
  unsigned src, code;
  uint64_t addr;
  uint32_t count;
} vf_hv_fault_t;
void     vf_hv_read_fault(const vf_mgmt_t *m, unsigned ctx, vf_hv_fault_t *f);
const char *vf_fatal_cause_name(unsigned cause);
const char *vf_fault_src_name(unsigned src);
const char *vf_strerror(int err);

#ifdef __cplusplus
}
#endif

#endif /* VF_HOST_H */
