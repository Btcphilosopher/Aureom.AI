# SilicaFlux Albion — Project 87 · VirtualFoundry: cloud virtualisation and virtual I/O

**Primary RTL:** `rtl/albion/sf_virtual_io.sv` · Aureom.AI / SilicaFlux Albion · delivered as this archive — **nothing was committed to GitHub**.

VirtualFoundry accepts VirtIO commands from simulated guests (split virtqueues, virtio-mmio v2), validates every descriptor, reaches guest memory **only** through three independent enforcement points
(per-context windows → **Citadel** check → **BridgeEngine** protected DMA), executes block requests against a storage backend and network frames against a PacketForge stream, and publishes correctly formatted
completions. It is a **device model for VirtIO block and network devices bound to protection domains** — it is *not* a hypervisor and *not* PCIe SR-IOV (08_LIMITATIONS.md).

> **Status — read this first.** Everything below is **RTL simulation** (Verilator) plus an independent software model, an independent monitor, fault injection and mutation. No synthesis, timing, area, power, FPGA or formal result exists
> and **none is claimed**. The Citadel is Project 83's reference model; the BridgeEngine, StorageCore and PacketForge are **bench models** (the real blocks are not integrated); no Linux guest driver was run against it.
> Throughput is a functional baseline (≈ 0.65 bytes per cycle per guest). Details: `docs/virtual_foundry/08_LIMITATIONS.md`.

## Definition of done — met in RTL simulation

> *A simulated guest driver can submit a supported virtual I/O command, receive the correct result and remain confined to its authorised memory and queues.*

`make example` runs a plain C guest program against the Verilator model: guest 0 writes, flushes and reads back 4 KiB (identical), then points a request at guest 1's memory — the read is refused with an I/O error,
the write is refused and the device reports `WRITABLE_PERM`, guest 1's memory is unchanged, the independent monitor reports 0 violations, and the hypervisor reads the captured fault and per-domain counters.

## Results at delivery (reproduce with the commands below; raw logs in `reports/logs/`)

| Evidence | Result |
|---|---|
| Static | `make lint`: Verilator `-Wall` clean on a block build and on a mixed block / network build, **11 illegal parameter sets refused at elaboration**; host library builds clean under `gcc -std=c99 -Wall -Wextra -Werror -pedantic`; **135** register constants identical in `vf_regs.h`, the package and the RTL decode; the two vendored Project 83 files are byte-identical to the repository archive |
| Pure-SystemVerilog benches | `tb_pkg_consistency`: the Albion constants equal Meridian's — PASS; `tb_vf_io` (own guest driver, own memories, no C++): **1 038 checks, 0 failures**, forged request refused, no DMA beat outside the window |
| Definition of done | `make example`: **MET** (guest I/O correct; guest confined to its memory and queues) |
| **Tier 1** — one guest, one split virtqueue, simulated block backend | 58 distinct tests: **55/55** on the default, registered-Citadel (`CIT_LAT = 1`) and 3-context builds, 54/54 on the small build (queue 8 / chain 8 / 4 windows), 57/57 with short timeouts; ≈ 1 070 checks per build; plus a 65 600-request run through the 16-bit index wrap |
| **Tier 2** — isolation between three block guests (runs only after tier 1) | **9/9**, 264 checks: forged rings / descriptors / storage addresses, fault containment (twelve fatal errors under neighbour traffic), reset containment, fairness bound, per-domain accounting, interrupt independence, shared-storage integrity |
| **Tier 3** — virtio-net over PacketForge, random regression (runs only after tier 2) | **15/15** (block, block, net) and **14/14** (net, net); random regression over **6 seeds × 4 builds**: single guest ≈ 350 requests with injected fatals, three guests 450 requests, network 120–230 frames each — every result byte-exact against the independent model |
| Fault injection | an error status on **every** bridge beat of an IN and of an OUT request (80 beats each): never a hang, never a success with wrong data, never a byte outside the request changed, always recovers |
| Mutation | **34 / 34** deliberate RTL defects caught (`reports/mutation.md`); the first run left one survivor (a one-byte window error masked by the Citadel layer), which new boundary tests now kill |
| Totals | 341 test executions, 15 875 checks, all passing (`reports/SUMMARY.md`) |
| Size | RTL ≈ 3 970 lines, host library ≈ 1 140 lines of C99, tests and tools ≈ 4 830 lines, documentation ≈ 750 lines |
| Performance | functional baseline: ≈ **0.65 bytes/cycle** per guest, ≈ 0.33 for misaligned buffers, 1.56 aggregate for three guests (`reports/perf_sweep.md`); **not** timing-closed, not synthesised |

## What is implemented

| | |
|---|---|
| Devices | virtio-blk (ID 2, one requestq) and virtio-net (ID 1, receiveq + transmitq) over **virtio-mmio v2**; up to 15 guest contexts, each its own device, window, interrupt, protection domain, windows, rings, storage extent / frame buffers |
| Rings | **split** virtqueue (descriptor table, available ring, used ring), `QueueNum` ≤ 32768, exact descriptor format of VirtIO 1.2, free-running 16-bit indices |
| Offered features | block: `VERSION_1 ACCESS_PLATFORM SEG_MAX FLUSH` (+ `RO`); net: `VERSION_1 ACCESS_PLATFORM MAC STATUS`. **Never offered:** packed ring, indirect descriptors, EVENT_IDX, IN_ORDER, RING_RESET, MQ, MRG_RXBUF, offloads, control queue |
| Validation | queue bounds, loops (exact), maximum chain length, flags, direction, length overflow, ring alignment, buffer permissions (whole-buffer pre-check **and** per-beat gate), request-level direction / range / read-only checks |
| Isolation | local windows → Citadel (default deny, fail closed) → BridgeEngine (Albion master port, echo-checked); domain bound by the management plane only; storage extents; frame buffers per context; faults contained per context |
| Reset | guest reset, queue disable, hypervisor (host) reset, chip reset — quiesced: no DMA after a reset returns; silent BridgeEngine / StorageCore bounded by timeouts |
| Measured | descriptors, queue waiting time, DMA bytes (per context and per domain), completion latency, interrupts raised / suppressed, backend stalls, invalid requests, device event counters |
| Host software | `runtime/virtual_foundry/`: C99 library (guest driver for blk / net, hypervisor helpers), no PCIe hardware needed |

## Quick start

```bash
pip install verilator              # or a system Verilator >= 5; python3, a C++ compiler and zip are also needed
make lint hostlib check_regs svtb  # static checks, host library (strict C99), register consistency, pure-SystemVerilog benches
make example                       # the definition-of-done demonstration
make t1                            # tier 1: one guest, one split virtqueue (5 builds)
make t2                            # tier 2: isolation between guests      (runs only after t1 passed)
make t3                            # tier 3: network, random regression    (runs only after t2 passed)
make perf                          # performance sweep -> reports/perf_sweep.md
make mutate                        # 34 deliberate RTL defects, all must be caught (~12 min)
make regress                       # everything, with gating and several random seeds
```

## Layout

```
rtl/albion/                  sf_virtual_io (TOP) · _ctx · _transport · _queue · _descriptor · _storage_adapter · _network_adapter · _gate · _dma_arb · _bridge · _ctx_mgmt · _pkg
third_party/p83/             Project 83 reference Citadel + package, unmodified, SHA256SUMS (verified against the repository archive)
runtime/virtual_foundry/     include/vf_host.h vf_regs.h · src/vf_core.c vf_blk.c vf_net.c vf_hv.c · examples/vf_example.c
tests/virtual_foundry/
  sim/                       Verilator platform (host memory, BridgeEngine / StorageCore / PacketForge models, independent monitors), test suite
  tb/                        generated Verilator top (vf_tb_top.sv), pure-SystemVerilog benches (tb_vf_io.sv, tb_pkg_consistency.sv)
  mutation/mutate.py         34 mutants      tools/ check_regs.py gen_tb_top.py
docs/virtual_foundry/        00 audit · 01 architecture · 02 register map · 03 isolation · 04 VirtIO conformance · 05 backends · 06 performance · 07 verification · 08 limitations
scripts/                     regress.sh · make_zip.sh · check_vendor.py · summarize.py
reports/                     SUMMARY.md · mutation.md · perf_sweep.md · logs/
Makefile · MANIFEST.sha256
```

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit; reuse validated components | `docs/virtual_foundry/00_AUDIT.md`: P63 VirtualIO derived (difference table), P83 Citadel reference + Albion format vendored with hashes, P62 / P64 / P51 contracts adopted, nothing integrated that could not be verified |
| 2 | Minimal virtual-device engine; simulated host; one queue; block first | tier 1 (one guest, one queue, simulated block backend) comes first and gates the rest; virtio-blk chosen because P63 is the only tested VirtIO infrastructure |
| 3 | Split virtqueue: table, rings, indices, negotiation, ownership, notifications, completion status; real descriptor format; no unsupported feature advertised | `sf_virtual_queue`, `_descriptor`, `_transport`; `negotiate`, `net_identity` try every unoffered bit |
| 4 | Descriptor validation | 01 §4; the `mal_*` tests (one per fatal cause) + random fatal injection; every item of the list mapped |
| 5 | Hardware isolation: domain per queue, Citadel, BridgeEngine, buffer ownership, completion visibility | 03_ISOLATION.md; `sf_virtual_gate`, `sf_virtual_bridge`; tier 2 |
| 6 | PacketForge adapter: tx descriptors, rx buffers, completion, error propagation; only genuinely supported features | `sf_virtual_network_adapter`; 05 §2; `net_*`, `random_net` |
| 7 | Storage adapter: read, write, flush, capacity, error status; durability preserved | `sf_virtual_storage_adapter`; 05 §1; `storage_*`, `fault_sweep_*` |
| 8 | Queue management: configuration, enable / disable, reset, polling, completion, interrupts, fault reporting; multi-queue only after the single-queue model is verified | transport + management page; tier gating; virtio-net contexts have two queues |
| 9 | Performance measurements | 06_PERFORMANCE.md, `perf_counters`, `make perf` |
| 10 | Host software (C), simulated device, queues, descriptors, completions, errors, example I/O, no PCIe hardware | `runtime/virtual_foundry/`, `vf_example.c`, the C ABI of the platform (`vf_sim_c.h`) |
| 11 | Verification list | 07_VERIFICATION.md §3 maps every item to tests |
| 12 | Deliverables | `sf_virtual_io / _queue / _descriptor / _storage_adapter / _network_adapter.sv` in `rtl/albion/`; `runtime/virtual_foundry/`; `tests/virtual_foundry/` |
