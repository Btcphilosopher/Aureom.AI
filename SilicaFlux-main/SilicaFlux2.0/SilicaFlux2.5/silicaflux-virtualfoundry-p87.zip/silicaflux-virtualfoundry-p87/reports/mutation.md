# Mutation check

Each mutant is one deliberate RTL defect; the suite must fail on it.

| id | file | defect | configuration | result |
|---|---|---|---|---|
| M01 | `sf_virtual_descriptor.sv` | descriptor-loop detection removed | blk3 | killed by --tier t1 --skip-long |
| M02 | `sf_virtual_descriptor.sv` | INDIRECT descriptors accepted although not offered | blk3 | killed by --tier t1 --skip-long |
| M03 | `sf_virtual_descriptor.sv` | queue-bounds check of descriptor indices removed | blk3 | killed by --tier t1 --skip-long |
| M04 | `sf_virtual_descriptor.sv` | device-readable-after-writable (direction) check removed | blk3 | killed by --tier t1 --skip-long |
| M05 | `sf_virtual_descriptor.sv` | maximum chain length off by one | blk3 | killed by --tier t1 --skip-long |
| M06 | `sf_virtual_descriptor.sv` | pre-check of writable buffers removed | blk3 | killed by --tier t1 --skip-long |
| M07 | `sf_virtual_gate.sv` | window gate ignores the access direction | blk3 | killed by --tier t1 --skip-long |
| M08 | `sf_virtual_gate.sv` | window gate ignores the domain tag | blk3 | killed by --tier t1 --skip-long |
| M09 | `sf_virtual_gate.sv` | window upper bound off by one byte | blk3 | killed by --tier t1 --skip-long |
| M10 | `sf_virtual_bridge.sv` | Citadel verdict ignored (everything permitted) | blk3 | killed by --tier t1 --skip-long |
| M11 | `sf_virtual_bridge.sv` | Citadel timeout fails OPEN instead of closed | blk3 | killed by --tier t1 --skip-long |
| M12 | `sf_virtual_bridge.sv` | domain wider than the Citadel field is truncated, not denied | blk3 | killed by --tier t1 --skip-long |
| M13 | `sf_virtual_bridge.sv` | BridgeEngine response echo not checked | blk3 | killed by --tier t1 --skip-long |
| M14 | `sf_virtual_bridge.sv` | BridgeEngine error status delivered as data | blk3 | killed by --tier t1 --skip-long |
| M15 | `sf_virtual_bridge.sv` | bridge response routed to context 0 only | blk3 | killed by --tier t2 |
| M16 | `sf_virtual_bridge.sv` | per-domain request counter charged to the wrong domain | blk3 | killed by --tier t2 |
| M17 | `sf_virtual_queue.sv` | used.len always reported as 0 | blk3 | killed by --tier t1 --skip-long |
| M18 | `sf_virtual_queue.sv` | avail.idx jump check removed | blk3 | killed by --tier t1 --skip-long |
| M19 | `sf_virtual_queue.sv` | VIRTQ_AVAIL_F_NO_INTERRUPT ignored | blk3 | killed by --tier t1 --skip-long |
| M20 | `sf_virtual_storage_adapter.sv` | capacity check off by one sector | blk3 | killed by --tier t1 --skip-long |
| M21 | `sf_virtual_storage_adapter.sv` | storage extent base not applied (guests overlap in storage) | blk3 | killed by --tier t2 |
| M22 | `sf_virtual_storage_adapter.sv` | FLUSH acknowledged without reaching storage | blk3 | killed by --tier t1 --skip-long |
| M23 | `sf_virtual_transport.sv` | FEATURES_OK granted for unoffered features | blk3 | killed by --tier t1 --skip-long |
| M24 | `sf_virtual_transport.sv` | reset does not wait for the engine to drain | blk3 | killed by --tier t1 --skip-long |
| M25 | `sf_virtual_ctx_mgmt.sv` | domain binding not locked while the queue is live | blk3 | killed by --tier t1 --skip-long |
| M26 | `sf_virtual_io.sv` | storage response routed to context 0 | blk3 | killed by --tier t2 |
| M27 | `sf_virtual_queue.sv` | receive queue consumes buffers without a frame | multi | killed by --tier t3 --iters 30 |
| M28 | `sf_virtual_network_adapter.sv` | virtio_net_hdr num_buffers not set to 1 | multi | killed by --tier t3 --iters 30 |
| M29 | `sf_virtual_network_adapter.sv` | transmit header offload bits not validated | multi | killed by --tier t3 --iters 30 |
| M30 | `sf_virtual_network_adapter.sv` | too-small receive buffer not rejected | multi | killed by --tier t3 --iters 30 |
| M31 | `sf_virtual_network_adapter.sv` | arriving frame overwrites the stored one | multi | killed by --tier t3 --iters 30 |
| M32 | `sf_virtual_network_adapter.sv` | stored frame survives a device reset | multi | killed by --tier t3 --iters 30 |
| M33 | `sf_virtual_io.sv` | frames steered to a block context | multi | killed by --tier t3 --iters 30 |
| M34 | `sf_virtual_network_adapter.sv` | transmit frame size limits not enforced | multi | killed by --tier t3 --iters 30 |

**34 / 34 mutants killed.**
