# VirtualFoundry performance sweep (simulation cycles; 1 beat = 8 bytes; bridge and storage latency in cycles)

## 1. single guest, one request at a time, latency 1/1
| request | cycles/request | bytes/cycle |
|---|---|---|
| IN 512 B | 899 | 0.569 |
| OUT 512 B | 898 | 0.570 |
| IN 4096 B | 6274 | 0.653 |
| OUT 4096 B | 6274 | 0.653 |
| IN 16384 B | 24706 | 0.663 |
| OUT 16384 B | 24706 | 0.663 |
| FLUSH (no data) | 115 | - |

## 2. alignment of the guest buffer (IN 4096 B)
| buffer offset | cycles/request | bytes/cycle |
|---|---|---|
| +0 | 6275 | 0.653 |
| +1 | 12418 | 0.330 |
| +3 | 12418 | 0.330 |
| +7 | 12418 | 0.330 |

## 3. latency of the BridgeEngine (storage latency 1), IN 4096 B
| bridge latency | cycles/request | bytes/cycle |
|---|---|---|
| 1 | 6276 | 0.653 |
| 4 | 7857 | 0.521 |
| 16 | 14181 | 0.289 |
| 64 | 39459 | 0.104 |

## 4. aggregate throughput of N guests streaming IN 4096 B (queue depth 2 each)
| guests | cycles for 12 requests each | aggregate bytes/cycle | per-guest bytes/cycle |
|---|---|---|---|
| 1 | 75244 | 0.653 | 0.653 |
| 2 | 75548 | 1.301 | 0.651 |
| 3 | 94760 | 1.556 | 0.519 |

## 5. counters after a mixed random workload (guest 0, back-pressure 30%, latency up to 6)
| counter | value |
|---|---|
| descriptors processed | 133 |
| requests completed | 40 |
| DMA bytes read / written | 19338 / 17928 |
| completion latency avg / max (cycles) | 3790 / 9422 |
| queue waiting time avg / max (cycles) | 19 / 27 |
| descriptor-walk time avg / max (cycles) | 72 / 116 |
| avail-ring depth at head fetch avg / max | 2.50 / 5 |
| interrupts raised / suppressed | 40 / 0 |
| cycles with a request back-pressured (stall) | 3535 |
| cycles waiting for a backend response | 28501 |
| busy cycles / total cycles | 152571 / 152751 |
| invalid requests | 0 |
| bridge: requests, avg / max latency | 8737, 6.0 / 15 |
