#!/usr/bin/env python3
"""Mechanical consistency check between the SystemVerilog package, the host header and the RTL
register decode (docs/virtual_foundry/02_REGISTER_MAP.md is generated from the same constants)."""
import re, sys, pathlib
root = pathlib.Path(__file__).resolve().parents[3]
hdr = (root / "runtime/virtual_foundry/include/vf_regs.h").read_text()
pkg = (root / "rtl/albion/sf_virtual_pkg.sv").read_text()
mg = (root / "rtl/albion/sf_virtual_ctx_mgmt.sv").read_text()

def hdr_const(name):
    m = re.search(r"#define\s+%s\s+(0x[0-9a-fA-F]+|\d+)u?\b" % re.escape(name), hdr)
    return int(m.group(1), 0) if m else None

def pkg_const(name):
    m = re.search(r"localparam\s+[^=]*\b%s\s*=\s*(?:\d+'[hdb])?([0-9a-fA-F_]+)\s*;" % re.escape(name), pkg)
    if not m: return None
    txt = m.group(0)
    base = 16 if "'h" in txt else 2 if "'b" in txt else 10
    return int(m.group(1).replace("_", ""), base)

pairs = []
# virtio-mmio offsets and protocol constants: header name == package name with MMIO_ prefix mapping
for n in ["MAGIC_VALUE","VERSION","DEVICE_ID","VENDOR_ID","DEVICE_FEATURES","DEVICE_FEATURES_SEL","DRIVER_FEATURES","DRIVER_FEATURES_SEL",
          "QUEUE_SEL","QUEUE_NUM_MAX","QUEUE_NUM","QUEUE_READY","QUEUE_NOTIFY","INTERRUPT_STATUS","INTERRUPT_ACK","STATUS",
          "QUEUE_DESC_LOW","QUEUE_DESC_HIGH","QUEUE_DRIVER_LOW","QUEUE_DRIVER_HIGH","QUEUE_DEVICE_LOW","QUEUE_DEVICE_HIGH",
          "CONFIG_GENERATION","CONFIG"]:
    pairs.append(("VIRTIO_MMIO_" + n, "MMIO_" + n))
for n in ["VIRTIO_STATUS_ACKNOWLEDGE","VIRTIO_STATUS_DRIVER","VIRTIO_STATUS_DRIVER_OK","VIRTIO_STATUS_FEATURES_OK",
          "VIRTIO_STATUS_DEVICE_NEEDS_RESET","VIRTIO_STATUS_FAILED","VIRTIO_F_INDIRECT_DESC","VIRTIO_F_EVENT_IDX",
          "VIRTIO_F_VERSION_1","VIRTIO_F_ACCESS_PLATFORM","VIRTIO_F_RING_PACKED","VIRTIO_BLK_F_SEG_MAX","VIRTIO_BLK_F_RO",
          "VIRTIO_BLK_F_FLUSH","VIRTIO_NET_F_MAC","VIRTIO_NET_F_MRG_RXBUF","VIRTIO_NET_F_STATUS","VIRTIO_ID_NET","VIRTIO_ID_BLOCK",
          "VIRTIO_BLK_T_IN","VIRTIO_BLK_T_OUT","VIRTIO_BLK_T_FLUSH","VIRTIO_BLK_T_GET_ID","VIRTIO_BLK_S_OK","VIRTIO_BLK_S_IOERR",
          "VIRTIO_BLK_S_UNSUPP","VIRTIO_BLK_ID_BYTES","VIRTIO_NET_HDR_BYTES","VIRTQ_DESC_F_NEXT","VIRTQ_DESC_F_WRITE",
          "VIRTQ_DESC_F_INDIRECT","VIRTQ_AVAIL_F_NO_INTERRUPT"]:
    pairs.append((n, n))
for n in ["NONE","QUEUE_CFG","NO_DOMAIN","AVAIL_IDX_JUMP","RING_DMA","DESC_IDX_OOR","CHAIN_LOOP","CHAIN_TOO_LONG","DESC_FLAGS",
          "CHAIN_ORDER","CHAIN_LEN_OVF","WRITABLE_PERM","NO_STATUS","DATA_WRITE_DMA"]:
    pairs.append(("VF_FC_" + n, "FC_" + n))
for n in ["NONE","GATE","DESC","CITADEL","BRIDGE","TIMEOUT","ECHO"]:
    pairs.append(("VF_FS_" + n, "FS_" + n))
for n in ["OKAY","SLVERR","DECERR","DENIED","TIMEOUT","PROTO"]:
    pairs.append(("VF_ALB_ST_" + n, "ALB_ST_" + n))
for n in ["NONE","NOMAP","PERM","DOMAIN","PRIV","CITTMO"]:
    pairs.append(("VF_ALB_F_" + n, "ALB_F_" + n))
bad = 0
for h, p in pairs:
    a, b = hdr_const(h), pkg_const(p)
    if a is None or b is None or a != b:
        print("MISMATCH %s=%s  vs  %s=%s" % (h, a, p, b)); bad += 1
# management register offsets: every R_* offset in the mgmt RTL must have a VF_M_* twin in the header
rtl = {m.group(1): int(m.group(2), 16) for m in re.finditer(r"localparam logic \[11:0\] R_(\w+)\s*=\s*12'h([0-9a-fA-F]+)", mg)}
m2h = {"ID":"VF_M_ID","VER":"VF_M_VER","CAPS0":"VF_M_CAPS0","CAPS1":"VF_M_CAPS1","DOMAIN":"VF_M_DOMAIN","STATUS":"VF_M_STATUS",
       "FAULT_LO":"VF_M_FAULT_LO","FAULT_HI":"VF_M_FAULT_HI","FAULT_INFO":"VF_M_FAULT_INFO","CTRL":"VF_M_CTRL","FAULT_CNT":"VF_M_FAULT_CNT",
       "WIN_BASE":"VF_M_WIN_BASE","EXT_SZ_LO":"VF_M_EXT_SIZE_LO","EXT_SZ_HI":"VF_M_EXT_SIZE_HI","EXT_BASE_LO":"VF_M_EXT_BASE_LO",
       "EXT_BASE_HI":"VF_M_EXT_BASE_HI","EXT_FLAGS":"VF_M_EXT_FLAGS","MAC_LO":"VF_M_MAC_LO","MAC_HI":"VF_M_MAC_HI",
       "PERF_BASE":"VF_M_PERF","DEVCNT_BASE":"VF_M_DEVCNT"}
for r, h in m2h.items():
    if rtl.get(r) != hdr_const(h):
        print("MISMATCH mgmt R_%s=%s vs %s=%s" % (r, rtl.get(r), h, hdr_const(h))); bad += 1
for r in rtl:
    if r not in m2h: print("UNMAPPED mgmt register R_%s" % r); bad += 1
# performance counter offsets
perf = {m.group(1): int(m.group(2), 16) for m in re.finditer(r"R_PERF_BASE \+ 12'h([0-9a-fA-F]+):\s+rdata = (\w+)", mg) for _ in [0]} if False else {}
names = re.findall(r"R_PERF_BASE \+ 12'h([0-9a-fA-F]+):\s+rdata = (c_\w+)", mg)
rtl_perf = {}
for off, sig in names:
    rtl_perf.setdefault(sig.split("[")[0], int(off, 16))
want = {"c_desc":"VF_P_DESC","c_req":"VF_P_REQ","c_rd_bytes":"VF_P_RD_BYTES","c_wr_bytes":"VF_P_WR_BYTES","c_clat_sum":"VF_P_CLAT_SUM",
        "c_clat_max":"VF_P_CLAT_MAX","c_wlat_sum":"VF_P_WLAT_SUM","c_wlat_max":"VF_P_WLAT_MAX","c_irq":"VF_P_IRQ","c_irq_sup":"VF_P_IRQ_SUP",
        "c_stall":"VF_P_STALL","c_viol":"VF_P_VIOL","c_qd_sum":"VF_P_QD_SUM","c_qd_max":"VF_P_QD_MAX","c_qd_n":"VF_P_QD_N",
        "c_notify":"VF_P_NOTIFY","c_fatal":"VF_P_FATAL","c_busy":"VF_P_BUSY","c_total":"VF_P_TOTAL","c_qw_sum":"VF_P_QW_SUM",
        "c_qw_max":"VF_P_QW_MAX","c_qw_n":"VF_P_QW_N","c_invalid":"VF_P_INVALID","c_bewait":"VF_P_BEWAIT","c_bridge_err":"VF_P_BRIDGE_ERR"}
for sig, h in want.items():
    if rtl_perf.get(sig) != hdr_const(h):
        print("MISMATCH perf %s=%s vs %s=%s" % (sig, rtl_perf.get(sig), h, hdr_const(h))); bad += 1
print("register consistency: %d constants checked, %d mismatches" % (len(pairs) + len(m2h) + len(want), bad))
sys.exit(1 if bad else 0)
