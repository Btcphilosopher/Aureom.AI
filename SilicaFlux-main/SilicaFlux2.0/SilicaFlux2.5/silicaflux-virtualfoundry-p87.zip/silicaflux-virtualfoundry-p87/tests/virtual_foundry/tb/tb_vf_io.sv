// tb_vf_io.sv -- self-checking pure-SystemVerilog testbench: one guest, one split virtqueue, block backend
// (independent of the C++ co-simulation: its own guest driver, memories and checks).
//   make svtb
`default_nettype none
module tb_vf_io;
  localparam int DOM_W = 4, TAGW = 4;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---- DUT and the reference Citadel ----------------------------------------------------------------
  logic        mmio_req_valid = 0, mmio_req_we = 0, mmio_req_ready, mmio_resp_valid, irq;
  logic [11:0] mmio_req_addr = 0;
  logic [31:0] mmio_req_wdata = 0, mmio_resp_rdata;
  logic        mgmt_req_valid = 0, mgmt_req_we = 0, mgmt_req_ready, mgmt_resp_valid;
  logic [15:0] mgmt_req_addr = 0;
  logic [31:0] mgmt_req_wdata = 0, mgmt_resp_rdata;
  logic cit_req_valid, cit_req_ready, cit_req_priv, cit_req_write, cit_rsp_valid, cit_rsp_ok;
  logic [DOM_W-1:0] cit_req_dom; logic [63:0] cit_req_addr; logic [3:0] cit_rsp_fault;
  logic bdg_req_valid, bdg_req_ready = 1, bdg_rsp_valid = 0, bdg_rsp_ready;
  logic [1:0] bdg_req_op, bdg_rsp_op = 0; logic [TAGW-1:0] bdg_req_tag, bdg_rsp_tag = 0;
  logic [DOM_W-1:0] bdg_req_dom, bdg_rsp_dom = 0; logic bdg_req_priv; logic [2:0] bdg_req_tc, bdg_rsp_status = 0;
  logic [63:0] bdg_req_addr, bdg_req_wdata, bdg_rsp_rdata = 0; logic [7:0] bdg_req_wstrb;
  logic st_req_valid, st_req_ready = 1, st_resp_valid = 0, st_resp_err = 0; logic [1:0] st_req_op;
  logic [39:0] st_req_addr; logic [63:0] st_req_wdata, st_resp_rdata = 0; logic [7:0] st_req_be; logic [15:0] st_req_dom;
  logic pf_s_valid, pf_s_last, pf_s_err, pf_m_ready; logic [63:0] pf_s_data; logic [7:0] pf_s_keep; logic [3:0] pf_s_src; logic [15:0] pf_s_meta;
  logic pol_we = 0, pol_valid = 0, pol_priv = 0, pol_rd = 0, pol_wr = 0; logic [2:0] pol_idx = 0; logic [(1<<DOM_W)-1:0] pol_dom = 0;
  logic [63:0] pol_base = 0, pol_mask = 0;

  sf_virtual_io #(.NCTX(1), .CTX_KIND(0), .MAX_QSZ(16), .MAX_CHAIN(8), .N_WIN(4), .DOM_W(DOM_W), .TAGW(TAGW)) dut (
    .clk, .rst_n, .mmio_req_valid, .mmio_req_ready, .mmio_req_we, .mmio_req_addr, .mmio_req_wdata, .mmio_req_be(4'hf),
    .mmio_resp_valid, .mmio_resp_rdata, .irq, .mgmt_req_valid, .mgmt_req_ready, .mgmt_req_we, .mgmt_req_addr, .mgmt_req_wdata,
    .mgmt_resp_valid, .mgmt_resp_rdata, .cit_req_valid, .cit_req_ready, .cit_req_dom, .cit_req_priv, .cit_req_write, .cit_req_addr,
    .cit_rsp_valid, .cit_rsp_ok, .cit_rsp_fault, .bdg_req_valid, .bdg_req_ready, .bdg_req_op, .bdg_req_tag, .bdg_req_dom, .bdg_req_priv,
    .bdg_req_tc, .bdg_req_addr, .bdg_req_wdata, .bdg_req_wstrb, .bdg_rsp_valid, .bdg_rsp_ready, .bdg_rsp_tag, .bdg_rsp_dom, .bdg_rsp_op,
    .bdg_rsp_status, .bdg_rsp_rdata, .st_req_valid, .st_req_ready, .st_req_op, .st_req_addr, .st_req_wdata, .st_req_be, .st_req_dom,
    .st_resp_valid, .st_resp_rdata, .st_resp_err, .pf_link_up(1'b1), .pf_s_valid, .pf_s_ready(1'b1), .pf_s_data, .pf_s_keep, .pf_s_last,
    .pf_s_err, .pf_s_src, .pf_s_meta, .pf_m_valid(1'b0), .pf_m_ready, .pf_m_data(64'd0), .pf_m_keep(8'd0), .pf_m_last(1'b0),
    .pf_m_err(1'b0), .pf_m_queue(4'd0));
  sf_meridian_citadel_ref #(.NM(1), .DOMW(DOM_W), .AW(64), .NENT(8), .LAT(0)) cit (
    .clk, .rst_n, .pol_we, .pol_idx, .pol_valid, .pol_src(1'b1), .pol_dom, .pol_priv, .pol_base, .pol_mask, .pol_rd, .pol_wr,
    .cit_req_valid, .cit_req_ready, .cit_req_dom, .cit_req_priv, .cit_req_write, .cit_req_addr, .cit_rsp_valid, .cit_rsp_ok,
    .cit_rsp_fault, .tst_stall(1'b0));

  // ---- host memory (BridgeEngine target) and storage -----------------------------------------------------
  logic [7:0] mem  [0:(1<<20)-1];
  logic [7:0] stor [0:(1<<16)-1];
  int bdg_beats = 0, esc = 0;
  logic        b_pend = 0; logic [1:0] b_op; logic [TAGW-1:0] b_tag; logic [DOM_W-1:0] b_dom; logic [63:0] b_addr, b_wd; logic [7:0] b_be;
  logic        s_pend = 0; logic [1:0] s_op; logic [39:0] s_addr; logic [63:0] s_wd; logic [7:0] s_be;
  always @(posedge clk) begin
    bdg_rsp_valid <= 0; st_resp_valid <= 0;
    if (bdg_req_valid && bdg_req_ready) begin b_pend <= 1; b_op <= bdg_req_op; b_tag <= bdg_req_tag; b_dom <= bdg_req_dom; b_addr <= bdg_req_addr; b_wd <= bdg_req_wdata; b_be <= bdg_req_wstrb; bdg_beats++;
      if (bdg_req_addr < 64'h1000 || bdg_req_addr + 8 > 64'h100000) esc++;                      // independent check: nothing outside the window
    end
    if (b_pend) begin
      b_pend <= 0; bdg_rsp_valid <= 1; bdg_rsp_tag <= b_tag; bdg_rsp_dom <= b_dom; bdg_rsp_op <= b_op; bdg_rsp_status <= 0;
      bdg_rsp_rdata <= {mem[b_addr+7], mem[b_addr+6], mem[b_addr+5], mem[b_addr+4], mem[b_addr+3], mem[b_addr+2], mem[b_addr+1], mem[b_addr]};
      if (b_op == 1) for (int i = 0; i < 8; i++) if (b_be[i]) mem[b_addr + i] <= b_wd[8*i +: 8];
    end
    if (st_req_valid && st_req_ready) begin s_pend <= 1; s_op <= st_req_op; s_addr <= st_req_addr; s_wd <= st_req_wdata; s_be <= st_req_be; end
    if (s_pend) begin
      s_pend <= 0; st_resp_valid <= 1; st_resp_err <= 0;
      st_resp_rdata <= {stor[s_addr+7], stor[s_addr+6], stor[s_addr+5], stor[s_addr+4], stor[s_addr+3], stor[s_addr+2], stor[s_addr+1], stor[s_addr]};
      if (s_op == 1) for (int i = 0; i < 8; i++) if (s_be[i]) stor[s_addr + i] <= s_wd[8*i +: 8];
    end
  end

  // ---- bus tasks ---------------------------------------------------------------------------------------------------
  task automatic mmio(input bit we, input logic [11:0] a, input logic [31:0] d, output logic [31:0] q);
    @(negedge clk); mmio_req_valid = 1; mmio_req_we = we; mmio_req_addr = a; mmio_req_wdata = d;
    do @(posedge clk); while (!mmio_req_ready);
    @(negedge clk); mmio_req_valid = 0;
    do @(posedge clk); while (!mmio_resp_valid);
    q = mmio_resp_rdata;
  endtask
  task automatic mgmt(input bit we, input logic [15:0] a, input logic [31:0] d, output logic [31:0] q);
    @(negedge clk); mgmt_req_valid = 1; mgmt_req_we = we; mgmt_req_addr = a; mgmt_req_wdata = d;
    @(posedge clk); @(negedge clk); mgmt_req_valid = 0;
    do @(posedge clk); while (!mgmt_resp_valid);
    q = mgmt_resp_rdata;
  endtask

  int checks = 0, fails = 0;
  task automatic chk(input string w, input logic [63:0] got, input logic [63:0] exp);
    checks++;
    if (got !== exp) begin fails++; $display("  FAIL %s: got %h expected %h", w, got, exp); end
  endtask
  task automatic p16(input int a, input logic [15:0] v); mem[a] = v[7:0]; mem[a+1] = v[15:8]; endtask
  task automatic p32(input int a, input logic [31:0] v); for (int i = 0; i < 4; i++) mem[a+i] = v[8*i +: 8]; endtask
  task automatic p64(input int a, input logic [63:0] v); for (int i = 0; i < 8; i++) mem[a+i] = v[8*i +: 8]; endtask
  task automatic desc(input int base, input int i, input logic [63:0] addr, input int len, input logic [15:0] flags, input logic [15:0] nxt);
    p64(base + 16*i, addr); p32(base + 16*i + 8, len); p16(base + 16*i + 12, flags); p16(base + 16*i + 14, nxt);
  endtask

  localparam int DESC = 'h2000, AVAIL = 'h2100, USED = 'h2200;
  int avail_idx = 0;
  // submit {hdr(16) | data | status(1)}; wait for completion; returns the status byte
  task automatic request(input logic [31:0] ty, input int sector, input logic [63:0] data, input int len, input bit dev_writes, output logic [7:0] status);
    logic [31:0] q; int hdr = 'h3000, sta = 'h3200;
    p32(hdr, ty); p32(hdr + 4, 0); p64(hdr + 8, sector); mem[sta] = 8'ha5;
    desc(DESC, 0, hdr, 16, 16'h1, 1);
    desc(DESC, 1, data, len, dev_writes ? 16'h3 : 16'h1, 2);
    desc(DESC, 2, sta, 1, 16'h2, 0);
    p16(AVAIL + 4 + 2 * (avail_idx % 8), 0); avail_idx++; p16(AVAIL + 2, avail_idx[15:0]);
    mmio(1, 12'h050, 0, q);
    fork begin : w repeat (200000) @(posedge clk); $display("  TIMEOUT"); fails++; end
         begin wait ({mem[USED+3], mem[USED+2]} == avail_idx[15:0]); disable w; end join
    status = mem[sta];
  endtask

  logic [31:0] rd; logic [7:0] st;
  logic [7:0] pat [0:511];
  initial begin
    for (int i = 0; i < (1<<20); i++) mem[i] = 0;
    for (int i = 0; i < (1<<16); i++) stor[i] = i[7:0] ^ 8'h5a;
    repeat (4) @(posedge clk); rst_n = 1; repeat (2) @(posedge clk);
    // hypervisor: domain 1, one window [0x1000, 0xFFFFF] rw, 64-sector extent, Citadel region [0, 1 MiB)
    mgmt(1, 16'h0010, 32'h8000_0001, rd);
    mgmt(1, 16'h0040 + 16'h08, 32'h1000, rd); mgmt(1, 16'h0040 + 16'h04, 1, rd); mgmt(1, 16'h0040 + 16'h10, 32'hFFFFF, rd);
    mgmt(1, 16'h0040, 32'h7, rd);
    mgmt(1, 16'h0180, 64, rd); mgmt(1, 16'h0188, 0, rd);
    @(negedge clk); pol_idx = 0; pol_valid = 1; pol_dom = 16'h0002; pol_base = 0; pol_mask = ~64'hFFFFF; pol_rd = 1; pol_wr = 1; pol_we = 1;
    @(negedge clk); pol_we = 0;
    // identity
    mmio(0, 12'h000, 0, rd); chk("magic", rd, 32'h74726976);
    mmio(0, 12'h008, 0, rd); chk("device id", rd, 2);
    // driver bring-up (spec 3.1.1)
    mmio(1, 12'h070, 0, rd);
    mmio(1, 12'h070, 1, rd); mmio(1, 12'h070, 3, rd);
    mmio(1, 12'h014, 0, rd); mmio(0, 12'h010, 0, rd); chk("offered features lo", rd, (1<<2) | (1<<9));
    mmio(1, 12'h014, 1, rd); mmio(0, 12'h010, 0, rd); chk("offered features hi", rd, 3);
    mmio(1, 12'h024, 0, rd); mmio(1, 12'h020, (1<<9), rd);
    mmio(1, 12'h024, 1, rd); mmio(1, 12'h020, 3, rd);
    mmio(1, 12'h070, 11, rd); mmio(0, 12'h070, 0, rd); chk("FEATURES_OK sticks", rd & 8, 8);
    mmio(1, 12'h030, 0, rd); mmio(1, 12'h038, 8, rd);
    mmio(1, 12'h080, DESC, rd); mmio(1, 12'h084, 0, rd); mmio(1, 12'h090, AVAIL, rd); mmio(1, 12'h094, 0, rd); mmio(1, 12'h0a0, USED, rd); mmio(1, 12'h0a4, 0, rd);
    mmio(1, 12'h044, 1, rd); mmio(0, 12'h044, 0, rd); chk("queue ready", rd, 1);
    mmio(1, 12'h070, 15, rd);
    mmio(0, 12'h100, 0, rd); chk("capacity", rd, 64);
    // write 512 bytes to sector 3 and read them back
    for (int i = 0; i < 512; i++) begin pat[i] = (i * 13 + 7) & 8'hff; mem['h4000 + i] = pat[i]; end
    request(1, 3, 'h4000, 512, 0, st); chk("OUT status", st, 0);
    for (int i = 0; i < 512; i++) begin checks++; if (stor[3*512 + i] !== pat[i]) fails++; end
    request(0, 3, 'h5000, 512, 1, st); chk("IN status", st, 0);
    for (int i = 0; i < 512; i++) begin checks++; if (mem['h5000 + i] !== pat[i]) fails++; end
    request(4, 0, 'h6000, 0, 1, st); chk("FLUSH status", st, 0);
    // confinement: a buffer below the window is refused (IOERR) and never touched
    mem['h500] = 8'h77;
    request(1, 4, 'h500, 512, 0, st); chk("forged OUT status = IOERR", st, 1);
    chk("memory below the window untouched", mem['h500], 8'h77);
    mmio(0, 12'h070, 0, rd); chk("device not flagged NEEDS_RESET by a refused read", rd & 32'h40, 0);
    chk("no escaping DMA beat", esc, 0);
    $display("tb_vf_io: %0d checks, %0d failures, %0d DMA beats", checks, fails, bdg_beats);
    $display("%s", fails == 0 ? "PASS" : "FAIL");
    if (fails != 0) $fatal(1);
    $finish;
  end
endmodule
`default_nettype wire
