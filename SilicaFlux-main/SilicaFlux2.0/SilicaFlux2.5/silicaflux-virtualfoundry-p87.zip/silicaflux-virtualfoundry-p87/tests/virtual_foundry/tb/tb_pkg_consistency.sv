// tb_pkg_consistency.sv -- the Albion constants VirtualFoundry uses must equal the Project 83 (Meridian) package
// that defines them, and the structural sizes of the VirtIO structures must be the published ones.
//   make svtb
`default_nettype none
module tb_pkg_consistency;
  import sf_virtual_pkg::*;
  int errors = 0;
  task automatic eq(input string what, input int a, input int b);
    if (a !== b) begin $display("MISMATCH %s: virtual=%0d meridian=%0d", what, a, b); errors++; end
  endtask
  initial begin
    eq("OP_READ",  int'(ALB_OP_READ),  int'(sf_meridian_pkg::OP_READ));
    eq("OP_WRITE", int'(ALB_OP_WRITE), int'(sf_meridian_pkg::OP_WRITE));
    eq("ST_OKAY",    int'(ALB_ST_OKAY),    int'(sf_meridian_pkg::ST_OKAY));
    eq("ST_SLVERR",  int'(ALB_ST_SLVERR),  int'(sf_meridian_pkg::ST_SLVERR));
    eq("ST_DECERR",  int'(ALB_ST_DECERR),  int'(sf_meridian_pkg::ST_DECERR));
    eq("ST_DENIED",  int'(ALB_ST_DENIED),  int'(sf_meridian_pkg::ST_DENIED));
    eq("ST_TIMEOUT", int'(ALB_ST_TIMEOUT), int'(sf_meridian_pkg::ST_TIMEOUT));
    eq("ST_PROTO",   int'(ALB_ST_PROTO),   int'(sf_meridian_pkg::ST_PROTO));
    eq("F_NONE",   int'(ALB_F_NONE),   int'(sf_meridian_pkg::F_NONE));
    eq("F_NOMAP",  int'(ALB_F_NOMAP),  int'(sf_meridian_pkg::F_NOMAP));
    eq("F_PERM",   int'(ALB_F_PERM),   int'(sf_meridian_pkg::F_PERM));
    eq("F_DOMAIN", int'(ALB_F_DOMAIN), int'(sf_meridian_pkg::F_DOMAIN));
    eq("F_PRIV",   int'(ALB_F_PRIV),   int'(sf_meridian_pkg::F_PRIV));
    eq("F_CITTMO", int'(ALB_F_CITTMO), int'(sf_meridian_pkg::F_CITTMO));
    eq("TC_BULK",  int'(ALB_TC_BULK),  int'(sf_meridian_pkg::TC_BULK));
    eq("TC_IO",    int'(ALB_TC_IO),    int'(sf_meridian_pkg::TC_IO));
    // VirtIO 1.2: struct virtq_desc is 16 bytes, used element 8 bytes, virtio_net_hdr 12 bytes (VERSION_1), block header 16 bytes
    eq("virtq_desc bytes", 16, 8 + 4 + 2 + 2);
    eq("virtio_net_hdr bytes", VIRTIO_NET_HDR_BYTES, 1 + 1 + 2 + 2 + 2 + 2 + 2);
    eq("virtio_blk_req header bytes", 16, 4 + 4 + 8);
    eq("virtio-mmio magic", int'(VIRTIO_MMIO_MAGIC), 32'h74726976);
    eq("VERSION_1 bit", VIRTIO_F_VERSION_1, 32);
    eq("ACCESS_PLATFORM bit", VIRTIO_F_ACCESS_PLATFORM, 33);
    $display("tb_pkg_consistency: %s (%0d mismatches)", errors == 0 ? "PASS" : "FAIL", errors);
    if (errors != 0) $fatal(1);
    $finish;
  end
endmodule
`default_nettype wire
