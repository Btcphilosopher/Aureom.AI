// vf_sim.cpp -- SilicaFlux Albion, Project 87 VirtualFoundry: co-simulation platform
#include "vf_sim.h"

#include <cstdarg>
#include <cstdlib>
#include <cstring>
#include <stdexcept>

#include "Vvf_tb_top.h"
#include "verilated.h"

namespace {
uint64_t splitmix64(uint64_t x) {
  x += 0x9e3779b97f4a7c15ull;
  x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ull;
  x = (x ^ (x >> 27)) * 0x94d049bb133111ebull;
  return x ^ (x >> 31);
}
// contiguous byte-enable lane range; returns false if the mask is empty or not contiguous
bool be_range(uint8_t be, int *lo, int *hi) {
  if (!be) return false;
  int l = 0, h = 7;
  while (!(be & (1u << l))) l++;
  while (!(be & (1u << h))) h--;
  for (int i = l; i <= h; i++) if (!(be & (1u << i))) return false;
  *lo = l; *hi = h;
  return true;
}

// per-context port bundle of the generated top
struct CtxPorts {
  uint8_t *req_valid, *req_ready, *req_we, *resp_valid, *irq, *link_up;
  uint16_t *req_addr;
  uint32_t *req_wdata, *resp_rdata;
};
}  // namespace

static uint32_t t_mmio_rd(void *c, uint32_t off);
struct TrCtx { Sim *s; int ctx; };
static std::vector<TrCtx> g_trctx;   // stable storage for transport callbacks (one Sim at a time per process)

static uint32_t t_mmio_rd(void *c, uint32_t off) { auto *t = (TrCtx *)c; return t->s->mmio_rd(t->ctx, off); }
static void t_mmio_wr(void *c, uint32_t off, uint32_t v) { auto *t = (TrCtx *)c; t->s->mmio_wr(t->ctx, off, v); }
static int t_alloc(void *c, size_t size, size_t align, uint64_t *iova) { auto *t = (TrCtx *)c; return t->s->alloc(t->ctx, size, align, iova); }
static void t_mem_wr(void *c, uint64_t a, const void *p, size_t n) { ((TrCtx *)c)->s->mem_wr(a, p, n); }
static void t_mem_rd(void *c, uint64_t a, void *p, size_t n) { ((TrCtx *)c)->s->mem_rd(a, p, n); }
static void t_mb(void *) {}
static int t_wait_irq(void *c, uint32_t budget) {
  auto *t = (TrCtx *)c;
  for (uint32_t i = 0; i < budget; i++) {
    if (t->s->irq(t->ctx)) return 1;
    t->s->tick();
  }
  return t->s->irq(t->ctx);
}
static uint32_t m_rd(void *c, uint32_t a) { return ((Sim *)c)->mgmt_rd(a); }
static void m_wr(void *c, uint32_t a, uint32_t v) { ((Sim *)c)->mgmt_wr(a, v); }

#define CTXP(k) CtxPorts{&top_->c##k##_mmio_req_valid, &top_->c##k##_mmio_req_ready, &top_->c##k##_mmio_req_we, \
                         &top_->c##k##_mmio_resp_valid, &top_->c##k##_irq, &top_->c##k##_link_up,            \
                         &top_->c##k##_mmio_req_addr, &top_->c##k##_mmio_req_wdata, &top_->c##k##_mmio_resp_rdata}
static std::vector<CtxPorts> ports_of(Vvf_tb_top *t) {
  struct Dummy {} d; (void)d;
  Vvf_tb_top *top_ = t;
  return {CTXP(0), CTXP(1), CTXP(2), CTXP(3)};
}
static std::vector<CtxPorts> g_ports;

// ---------------------------------------------------------------------------------------------------
Sim::Sim(const Cfg &c) : rng(c.seed * 0x9e3779b97f4a7c15ull + 11), cfg_(c) {
  ctxv_ = std::make_unique<VerilatedContext>();
  ctxv_->randReset(0);
  top_ = std::make_unique<Vvf_tb_top>(ctxv_.get());
  g_ports = ports_of(top_.get());
  mem_.assign(c.memsize, 0);
  stor.assign(c.stor_bytes, 0);
  stor_dur.assign(c.stor_bytes, 0);
  bus_.assign(c.nctx, Bus{});
  reg_base_.assign(c.nctx, 0);
  reg_size_.assign(c.nctx, 0);
  alloc_ptr_.assign(c.nctx, 0);
  sh_.assign(c.nctx, ShadowCtx{});
  g_trctx.assign(c.nctx, TrCtx{this, 0});
  tr_.resize(c.nctx);
  for (int k = 0; k < c.nctx; k++) {
    g_trctx[k] = TrCtx{this, k};
    tr_[k] = vf_transport_t{&g_trctx[k], t_mmio_rd, t_mmio_wr, t_alloc, t_mem_wr, t_mem_rd, t_mb, t_wait_irq};
  }
  mg_ = vf_mgmt_t{this, m_rd, m_wr};
  stor_fill(c.seed);
  chip_reset(4);
}

Sim::~Sim() { top_->final(); }

void Sim::stor_fill(uint64_t seed) {
  for (size_t i = 0; i < stor.size(); i++) stor[i] = (uint8_t)(splitmix64(seed ^ (i >> 3)) >> (8 * (i & 7)));
  stor_dur = stor;
  dirty_.clear();
}

void Sim::power_loss() {
  for (uint64_t s : dirty_) {
    uint64_t o = s * 512;
    if (o + 512 <= stor.size()) memcpy(&stor[o], &stor_dur[o], 512);
  }
  dirty_.clear();
}

void Sim::mon_err(const char *fmt, ...) {
  char buf[512];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  if (mon_err_++ == 0) mon_first_ = buf;
  if (mon_err_ <= 3) fprintf(stderr, "    [monitor @%llu] %s\n", (unsigned long long)cyc_, buf);
}

// ---------------------------------------------------------------------------------------------------
// reset
// ---------------------------------------------------------------------------------------------------
void Sim::clear_inflight_() {
  bq_.clear(); held_.clear(); sq_.clear(); sheld_.clear(); st_hold_n_ = 0;
  inj_status_n_ = inj_echo_n_ = hold_n_ = dup_n_ = 0;
  for (auto &b : bus_) b = Bus{};
  mbus_ = Bus{};
  pf_rx_q_.clear(); pf_rx_busy_ = false; pf_tx_cur_.clear(); pf_tx_src_ = -1;
  bdg_rsp_driven_ = false;
}

void Sim::chip_reset(int cycles) {
  clear_inflight_();
  for (auto &s : sh_) s = ShadowCtx{};
  for (auto &p : spol_) p = ShadowPol{};
  auto *t = top_.get();
  t->rst_n = 0;
  t->clk = 0;
  for (int k = 0; k < 4; k++) { *g_ports[k].req_valid = 0; *g_ports[k].req_we = 0; *g_ports[k].link_up = 1; }
  t->mgmt_req_valid = 0; t->pol_we = 0; t->tst_cit_stall = 0;
  t->bdg_req_ready = 0; t->bdg_rsp_valid = 0; t->st_req_ready = 0; t->st_resp_valid = 0;
  t->pf_s_ready = 0; t->pf_m_valid = 0;
  t->eval();
  for (int i = 0; i < cycles; i++) cycle_();
  t->rst_n = 1;
  for (int i = 0; i < 2; i++) cycle_();
}

// ---------------------------------------------------------------------------------------------------
// shadow state (decoded from what the TEST wrote, independent of RTL state)
// ---------------------------------------------------------------------------------------------------
void Sim::shadow_mgmt_write(uint32_t addr, uint32_t v) {
  unsigned pg = (addr >> 12) & 0xf, off = addr & 0xfff;
  if (pg >= (unsigned)cfg_.nctx) return;
  ShadowCtx &s = sh_[pg];
  if (off == VF_M_DOMAIN) { s.dom = (uint16_t)(v & 0xffff); s.dom_valid = (v >> 31) & 1; }
  else if (off >= VF_M_WIN_BASE && off < VF_M_WIN_BASE + 0x20u * 8) {
    unsigned w = (off - VF_M_WIN_BASE) >> 5, f = ((off - VF_M_WIN_BASE) >> 2) & 7;
    ShadowWin &x = s.win[w];
    switch (f) {
      case 0: x.valid = v & 1; x.r = (v >> 1) & 1; x.w = (v >> 2) & 1; break;
      case 1: x.dom = (uint16_t)(v & 0xffff); break;
      case 2: x.base = (x.base & ~0xffffffffull) | v; break;
      case 3: x.base = (x.base & 0xffffffffull) | ((uint64_t)v << 32); break;
      case 4: x.limit = (x.limit & ~0xffffffffull) | v; break;
      case 5: x.limit = (x.limit & 0xffffffffull) | ((uint64_t)v << 32); break;
      default: break;
    }
  } else if (off == VF_M_EXT_SIZE_LO) s.ext_size = (s.ext_size & ~0xffffffffull) | v;
  else if (off == VF_M_EXT_SIZE_HI) s.ext_size = (s.ext_size & 0xffffffffull) | ((uint64_t)v << 32);
  else if (off == VF_M_EXT_BASE_LO) s.ext_base = (s.ext_base & ~0xffffffffull) | v;
  else if (off == VF_M_EXT_BASE_HI) s.ext_base = (s.ext_base & 0xffffffffull) | ((uint64_t)v << 32);
}

bool Sim::pol_allows(uint16_t dom, uint64_t addr, bool write) const {
  for (auto &p : spol_)
    if (p.valid && (addr & p.mask) == p.base && dom < 16 && ((p.dom_mask >> dom) & 1) && (write ? p.wr : p.rd)) return true;
  return false;
}

bool Sim::win_allows(uint16_t dom, uint64_t lo, uint64_t hi, bool write, int *ctx_out) const {
  if (hi < lo) return false;
  for (int k = 0; k < cfg_.nctx; k++) {
    const ShadowCtx &s = sh_[k];
    if (!s.dom_valid || s.dom != dom) continue;
    for (auto &w : s.win)
      if (w.valid && w.dom == dom && lo >= w.base && hi <= w.limit && (write ? w.w : w.r)) {
        if (ctx_out) *ctx_out = k;
        return true;
      }
  }
  return false;
}

int Sim::ctx_of_dom_(uint16_t dom) const {
  for (int k = 0; k < cfg_.nctx; k++) if (sh_[k].dom_valid && sh_[k].dom == dom) return k;
  return -1;
}

// ---------------------------------------------------------------------------------------------------
// Citadel policy
// ---------------------------------------------------------------------------------------------------
void Sim::pol_set(unsigned idx, bool valid, uint16_t dom_mask, uint64_t base, uint64_t mask, bool rd, bool wr) {
  auto *t = top_.get();
  t->pol_idx = idx & 7; t->pol_valid = valid; t->pol_dom = dom_mask; t->pol_priv = 0;
  t->pol_base = base; t->pol_mask = mask; t->pol_rd = rd; t->pol_wr = wr; t->pol_we = 1;
  spol_[idx & 7] = ShadowPol{valid, dom_mask, base, mask, rd, wr};
  tick(1);
  t->pol_we = 0;
}
void Sim::pol_region(unsigned idx, uint16_t dom, uint64_t base, uint64_t size, bool rd, bool wr) {
  if (size == 0 || (size & (size - 1)) || (base & (size - 1))) throw std::runtime_error("pol_region: size must be a power of two and base aligned");
  pol_set(idx, true, (uint16_t)(1u << dom), base, ~(size - 1), rd, wr);
}
void Sim::pol_clear(unsigned idx) { pol_set(idx, false, 0, 0, 0, false, false); }
void Sim::cit_stall(bool on) { top_->tst_cit_stall = on; }

void Sim::bdg_allow(uint16_t dom, uint64_t base, uint64_t size, bool rd, bool wr) { bdg_tab_.push_back({dom, base, size, rd, wr}); }

// ---------------------------------------------------------------------------------------------------
// guest memory
// ---------------------------------------------------------------------------------------------------
void Sim::mem_wr(uint64_t a, const void *p, size_t n) {
  if (a + n > mem_.size() || a + n < a) throw std::runtime_error("mem_wr out of range");
  memcpy(&mem_[a], p, n);
}
void Sim::mem_rd(uint64_t a, void *p, size_t n) const {
  if (a + n > mem_.size() || a + n < a) throw std::runtime_error("mem_rd out of range");
  memcpy(p, &mem_[a], n);
}
void Sim::set_region(int ctx, uint64_t base, uint64_t size) { reg_base_[ctx] = base; reg_size_[ctx] = size; alloc_ptr_[ctx] = base; }
void Sim::reset_alloc(int ctx) { alloc_ptr_[ctx] = reg_base_[ctx]; }
int Sim::alloc(int ctx, size_t size, size_t align, uint64_t *iova) {
  uint64_t p = (alloc_ptr_[ctx] + align - 1) / align * align;
  if (p + size > reg_base_[ctx] + reg_size_[ctx]) return -1;
  alloc_ptr_[ctx] = p + size;
  *iova = p;
  return 0;
}
bool Sim::irq(int ctx) { return *g_ports[ctx].irq; }
void Sim::set_link(int ctx, bool up) { *g_ports[ctx].link_up = up; }

// ---------------------------------------------------------------------------------------------------
// buses
// ---------------------------------------------------------------------------------------------------
void Sim::mmio_wr_start(int ctx, uint32_t off, uint32_t v) {
  Bus &b = bus_[ctx];
  b = Bus{}; b.active = true; b.we = true; b.addr = off; b.wdata = v;
}
bool Sim::mmio_done(int ctx) { return bus_[ctx].done; }

uint32_t Sim::mmio_rd(int ctx, uint32_t off) {
  Bus &b = bus_[ctx];
  b = Bus{}; b.active = true; b.we = false; b.addr = off;
  for (int i = 0; !b.done; i++) { if (i > 3000000) throw std::runtime_error("mmio read hang"); tick(); }
  b.active = false;
  return b.rdata;
}
void Sim::mmio_wr(int ctx, uint32_t off, uint32_t v) {
  mmio_wr_start(ctx, off, v);
  Bus &b = bus_[ctx];
  for (int i = 0; !b.done; i++) { if (i > 3000000) throw std::runtime_error("mmio write hang"); tick(); }
  b.active = false;
}
uint32_t Sim::mgmt_rd(uint32_t addr) {
  mbus_ = Bus{}; mbus_.active = true; mbus_.we = false; mbus_.addr = addr;
  for (int i = 0; !mbus_.done; i++) { if (i > 100000) throw std::runtime_error("mgmt read hang"); tick(); }
  mbus_.active = false;
  return mbus_.rdata;
}
void Sim::mgmt_wr_noshadow(uint32_t addr, uint32_t v) {
  mbus_ = Bus{}; mbus_.active = true; mbus_.we = true; mbus_.addr = addr; mbus_.wdata = v;
  for (int i = 0; !mbus_.done; i++) { if (i > 100000) throw std::runtime_error("mgmt write hang"); tick(); }
  mbus_.active = false;
}
void Sim::mgmt_wr(uint32_t addr, uint32_t v) { shadow_mgmt_write(addr, v); mgmt_wr_noshadow(addr, v); }

// ---------------------------------------------------------------------------------------------------
// bridge model helpers
// ---------------------------------------------------------------------------------------------------
uint8_t Sim::bdg_status_(const BdgReq &r) {
  { auto it = inj_at_.find(bdg_cnt_ - 1); if (it != inj_at_.end()) return it->second; }
  if (inj_status_n_ > 0) { inj_status_n_--; return inj_status_; }
  int lo = 0, hi = 7;
  if (!be_range(r.wstrb, &lo, &hi)) return VF_ALB_ST_PROTO;
  uint64_t a = r.addr + lo, e = r.addr + hi;
  if (e >= mem_.size() || e < a) return VF_ALB_ST_DECERR;
  if (bdg_enf_) {
    bool ok = false;
    for (auto &x : bdg_tab_)
      if (x.dom == r.dom && a >= x.base && e < x.base + x.size && (r.op == VF_ALB_OP_WRITE ? x.wr : x.rd)) ok = true;
    if (!ok) return VF_ALB_ST_DENIED;
  }
  return VF_ALB_ST_OKAY;
}

void Sim::bdg_apply_(const BdgReq &r, uint8_t status, uint64_t *rdata) {
  *rdata = 0xBAD0BAD0BAD0BAD0ull;
  if (status != VF_ALB_ST_OKAY) return;
  if (r.addr + 8 > mem_.size()) return;
  if (r.op == VF_ALB_OP_WRITE) {
    for (int i = 0; i < 8; i++) if (r.wstrb & (1u << i)) mem_[r.addr + i] = (uint8_t)(r.wdata >> (8 * i));
  } else {
    uint64_t v = 0;
    for (int i = 0; i < 8; i++) v |= (uint64_t)mem_[r.addr + i] << (8 * i);
    *rdata = v;
  }
}

void Sim::bdg_release_held() {
  while (!held_.empty()) { Pend p = held_.front(); held_.pop_front(); p.due = cyc_ + 1; p.held = false; bq_.push_back(p); }
}

// ---------------------------------------------------------------------------------------------------
// storage model
// ---------------------------------------------------------------------------------------------------
void Sim::pf_inject(unsigned queue, const std::vector<uint8_t> &frame) {
  std::vector<PfBeat> bs;
  for (size_t o = 0; o < frame.size(); o += 8) {
    size_t n = frame.size() - o, m = n > 8 ? 8 : n;
    uint64_t d = 0;
    for (size_t i = 0; i < m; i++) d |= (uint64_t)frame[o + i] << (8 * i);
    bs.push_back({d, (uint8_t)((1u << m) - 1), n <= 8, false});
  }
  pf_rx_q_.push_back({queue, bs});
}
void Sim::pf_inject_raw(unsigned queue, const std::vector<PfBeat> &beats) { pf_rx_q_.push_back({queue, beats}); }

void Sim::st_release_held() {
  while (!sheld_.empty()) { SPend p = sheld_.front(); sheld_.pop_front(); p.due = cyc_ + 1; sq_.push_back(p); }
}



// ---------------------------------------------------------------------------------------------------
// clock
// ---------------------------------------------------------------------------------------------------
void Sim::tick(int n) { while (n-- > 0) cycle_(); }

void Sim::cycle_() {
  if (cyc_ > max_cycles) throw std::runtime_error("watchdog: simulation cycle budget exhausted");
  auto *t = top_.get();
  auto rnd = [&](int pct) { return pct > 0 && (int)(rng() % 100) < pct; };
  auto lat = [&](int lo, int hi) { return (uint64_t)(lo + (hi > lo ? (int)(rng() % (hi - lo + 1)) : 0)); };

  // ---- drive inputs --------------------------------------------------------------------------------------
  for (int k = 0; k < cfg_.nctx; k++) {
    Bus &b = bus_[k];
    bool v = b.active && !b.acc;
    *g_ports[k].req_valid = v; *g_ports[k].req_we = b.we; *g_ports[k].req_addr = (uint16_t)b.addr; *g_ports[k].req_wdata = b.wdata;
  }
  {
    bool v = mbus_.active && !mbus_.acc;
    t->mgmt_req_valid = v; t->mgmt_req_we = mbus_.we; t->mgmt_req_addr = (uint16_t)mbus_.addr; t->mgmt_req_wdata = mbus_.wdata;
  }
  // BridgeEngine
  t->bdg_req_ready = !rnd(k.bdg_bp);
  Pend cur_rsp{};
  bool rsp_v = false;
  if (!bq_.empty() && bq_.front().due <= cyc_) {
    cur_rsp = bq_.front();
    rsp_v = true;
    uint64_t rd;
    BdgReq r = cur_rsp.r;
    uint8_t status = cur_rsp.status;
    // the memory effect is applied when the response is accepted (below); read data is read now
    bool is_read = (r.op == VF_ALB_OP_READ);
    rd = 0xBAD0BAD0BAD0BAD0ull;
    if (is_read && status == VF_ALB_ST_OKAY && r.addr + 8 <= mem_.size()) {
      uint64_t v = 0;
      for (int i = 0; i < 8; i++) v |= (uint64_t)mem_[r.addr + i] << (8 * i);
      rd = v;
    }
    uint8_t tag = r.tag, dom = r.dom, op = r.op;
    if (inj_echo_n_ > 0 && cur_rsp.status != 0xff) {
      if (inj_echo_which_ == 0) tag ^= 1; else if (inj_echo_which_ == 1) dom ^= 1; else op ^= 1;
    }
    t->bdg_rsp_valid = 1; t->bdg_rsp_tag = tag; t->bdg_rsp_dom = dom; t->bdg_rsp_op = op;
    t->bdg_rsp_status = status == 0xff ? 0 : status; t->bdg_rsp_rdata = rd;
  } else {
    t->bdg_rsp_valid = 0; t->bdg_rsp_tag = 0; t->bdg_rsp_dom = 0; t->bdg_rsp_op = 0; t->bdg_rsp_status = 0; t->bdg_rsp_rdata = 0;
  }
  // StorageCore
  t->st_req_ready = !rnd(k.st_bp);
  SPend cur_s{};
  bool s_v = false;
  if (!sq_.empty() && sq_.front().due <= cyc_) {
    cur_s = sq_.front(); s_v = true;
    uint64_t rd = 0;
    if (cur_s.op == 0 && !cur_s.err && cur_s.addr + 8 <= stor.size())
      for (int i = 0; i < 8; i++) rd |= (uint64_t)stor[cur_s.addr + i] << (8 * i);
    t->st_resp_valid = 1; t->st_resp_rdata = rd; t->st_resp_err = cur_s.err;
  } else {
    t->st_resp_valid = 0; t->st_resp_rdata = 0; t->st_resp_err = 0;
  }
  // PacketForge
  t->pf_s_ready = !rnd(k.pf_tx_bp);
  bool rx_v = false;
  if (!pf_rx_busy_ && !pf_rx_q_.empty()) {
    pf_rx_queue_ = pf_rx_q_.front().first; pf_rx_cur_ = pf_rx_q_.front().second; pf_rx_q_.pop_front();
    pf_rx_off_ = 0; pf_rx_busy_ = !pf_rx_cur_.empty();
  }
  if (pf_rx_busy_ && !(pf_rx_off_ > 0 && rnd(k.pf_rx_gap))) {
    const PfBeat &b = pf_rx_cur_[pf_rx_off_];
    t->pf_m_valid = 1; t->pf_m_data = b.data; t->pf_m_keep = b.keep;
    t->pf_m_last = b.last; t->pf_m_err = b.err; t->pf_m_queue = pf_rx_queue_;
    rx_v = true;
  } else {
    t->pf_m_valid = 0; t->pf_m_data = 0; t->pf_m_keep = 0; t->pf_m_last = 0; t->pf_m_err = 0; t->pf_m_queue = 0;
  }

  // ---- settle, sample ---------------------------------------------------------------------------------------------
  t->clk = 0;
  t->eval();

  // guest / management buses
  for (int kk = 0; kk < cfg_.nctx; kk++) {
    Bus &b = bus_[kk];
    if (b.active && b.acc && !b.done && *g_ports[kk].resp_valid) { b.done = true; b.rdata = *g_ports[kk].resp_rdata; }
    else if (b.active && !b.acc && *g_ports[kk].req_valid && *g_ports[kk].req_ready) b.acc = true;
  }
  if (mbus_.active && mbus_.acc && !mbus_.done && t->mgmt_resp_valid) { mbus_.done = true; mbus_.rdata = t->mgmt_resp_rdata; }
  else if (mbus_.active && !mbus_.acc && t->mgmt_req_valid && t->mgmt_req_ready) mbus_.acc = true;

  // BridgeEngine: request accept
  if (t->bdg_req_valid && t->bdg_req_ready) {
    BdgReq r{(uint8_t)t->bdg_req_op, (uint8_t)t->bdg_req_tag, (uint8_t)t->bdg_req_dom, (uint8_t)t->bdg_req_priv,
             (uint8_t)t->bdg_req_tc, (uint64_t)t->bdg_req_addr, (uint64_t)t->bdg_req_wdata, (uint8_t)t->bdg_req_wstrb};
    bdg_cnt_++;
    if (r.dom < 256) bdg_dom_cnt_[r.dom]++;
    if (bdg_log_on) bdg_log_.push_back(r);
    last_req_ = r;
    // independent escape monitor
    if (mon_check_bridge && !lenient) {
      int lo = 0, hi = 7;
      if (!be_range(r.wstrb, &lo, &hi)) mon_err("bridge beat with illegal byte-enable 0x%02x", r.wstrb);
      else {
        bool wr = (r.op == VF_ALB_OP_WRITE);
        if (r.priv) mon_err("bridge beat with priv=1 from a guest-driven engine");
        if (r.addr & 7) mon_err("bridge beat with unaligned address 0x%llx", (unsigned long long)r.addr);
        if (!win_allows(r.dom, r.addr + lo, r.addr + hi, wr))
          mon_err("ESCAPE (windows): dom %u %s [0x%llx..0x%llx] not covered by any window of its context",
                  r.dom, wr ? "write" : "read", (unsigned long long)(r.addr + lo), (unsigned long long)(r.addr + hi));
        if (!pol_allows(r.dom, r.addr, wr))
          mon_err("ESCAPE (Citadel): dom %u %s 0x%llx permitted by no policy entry", r.dom, wr ? "write" : "read", (unsigned long long)r.addr);
      }
    }
    Pend p{r, cyc_ + lat(k.bdg_lat_min, k.bdg_lat_max), bdg_status_(r), false};
    if (hold_n_ > 0) { hold_n_--; p.held = true; held_.push_back(p); }
    else { bq_.push_back(p); }
    int outn = (int)bq_.size() + (int)held_.size();
    if (outn > bdg_out_max_) bdg_out_max_ = outn;
    int real = 0;
    for (auto &q : bq_) if (q.status != 0xff) real++;
    if (real > 1) mon_err("more than one BridgeEngine request outstanding (%d)", real);
  }
  // BridgeEngine: response accepted (rsp_ready is always 1)
  if (rsp_v && t->bdg_rsp_ready) {
    Pend p = bq_.front(); bq_.pop_front();
    if (inj_echo_n_ > 0) inj_echo_n_--;
    uint64_t dummy;
    if (p.status != 0xff) bdg_apply_(p.r, p.status, &dummy);
    if (dup_n_ > 0 && p.status != 0xff) { dup_n_--; Pend d = p; d.due = cyc_ + 1; d.status = 0xff; bq_.push_back(d); }   // spurious duplicate
  }

  // StorageCore: request accept
  if (t->st_req_valid && t->st_req_ready) {
    SPend p{(uint8_t)t->st_req_op, (uint64_t)t->st_req_addr, (uint64_t)t->st_req_wdata, (uint8_t)t->st_req_be,
            (uint16_t)t->st_req_dom, cyc_ + lat(k.st_lat_min, k.st_lat_max), false};
    int lo = 0, hi = 7;
    if (st_log_on) st_log.push_back({p.op, p.addr});
    if (p.op == 2) {
      st_flushes++;
      p.err = fail_flush;
    } else {
      if (!be_range(p.be, &lo, &hi)) { mon_err("storage beat with illegal byte-enable 0x%02x", p.be); p.err = true; }
      else {
        uint64_t a = p.addr + lo, e = p.addr + hi;
        if (mon_check_storage && !lenient) {
          int c = ctx_of_dom_(p.dom);
          if (c < 0) mon_err("storage access from unbound domain %u", p.dom);
          else if (a < sh_[c].ext_base * 512 || e >= (sh_[c].ext_base + sh_[c].ext_size) * 512)
            mon_err("ESCAPE (storage): dom %u accessed byte [0x%llx..0x%llx] outside its extent [sector %llu +%llu]", p.dom,
                    (unsigned long long)a, (unsigned long long)e, (unsigned long long)sh_[c].ext_base, (unsigned long long)sh_[c].ext_size);
        }
        if (e >= stor.size()) p.err = true;
        else {
          bool bad = false;
          for (uint64_t s = a / 512; s <= e / 512; s++) if ((p.op == 0 ? bad_read : bad_write).count(s)) bad = true;
          p.err = bad;
          if (p.op == 1) {
            st_writes++;
            if (!bad) {
              for (int i = 0; i < 8; i++) if (p.be & (1u << i)) stor[p.addr + i] = (uint8_t)(p.wdata >> (8 * i));
              for (uint64_t s = a / 512; s <= e / 512; s++) dirty_.insert(s);
            }
          } else st_reads++;
        }
      }
    }
    if (st_hold_n_ > 0) { st_hold_n_--; sheld_.push_back(p); }
    else sq_.push_back(p);
    if (sq_.size() > 1) mon_err("more than one StorageCore request outstanding (%d)", (int)sq_.size());
  }
  if (s_v && !sq_.empty() && t->st_resp_valid) {
    SPend p = sq_.front(); sq_.pop_front();
    if (p.op == 2 && !p.err) { for (uint64_t s : dirty_) { uint64_t o = s * 512; if (o + 512 <= stor.size()) memcpy(&stor_dur[o], &stor[o], 512); } dirty_.clear(); }
  }

  // PacketForge transmit sink
  if (t->pf_s_valid && t->pf_s_ready) {
    pf_tx_beats++;
    uint8_t keep = (uint8_t)t->pf_s_keep;
    bool last = t->pf_s_last;
    int src = t->pf_s_src;
    if (pf_tx_src_ < 0) { pf_tx_src_ = src; pf_tx_meta_ = t->pf_s_meta; pf_tx_cur_.clear(); }
    if (src != pf_tx_src_) mon_err("PacketForge transmit stream interleaved: src %d inside a frame of src %d", src, pf_tx_src_);
    if (t->pf_s_err) mon_err("PacketForge transmit beat with err=1 (frames must be store-and-forward)");
    if (!last && keep != 0xff) mon_err("transmit keep 0x%02x on a non-last beat", keep);
    if (last && (keep == 0 || (keep & (keep + 1)))) mon_err("transmit keep 0x%02x on the last beat is not a contiguous low-order mask", keep);
    if (src >= 0 && src < cfg_.nctx && sh_[src].dom_valid && sh_[src].dom != t->pf_s_meta)
      mon_err("transmit meta %u != domain %u of context %d", (unsigned)t->pf_s_meta, sh_[src].dom, src);
    uint64_t d = t->pf_s_data;
    for (int i = 0; i < 8; i++) if (keep & (1u << i)) pf_tx_cur_.push_back((uint8_t)(d >> (8 * i)));
    if (last) { pf_tx.push_back(Frame{pf_tx_cur_, (unsigned)pf_tx_src_, pf_tx_meta_}); pf_tx_src_ = -1; pf_tx_cur_.clear(); }
  }
  // PacketForge receive source: the device is always ready
  if (rx_v && t->pf_m_ready) {
    if (pf_rx_cur_[pf_rx_off_].last || pf_rx_off_ + 1 >= pf_rx_cur_.size()) pf_rx_busy_ = false; else pf_rx_off_++;
  }

  // ---- clock edge ------------------------------------------------------------------------------------------------------------
  t->clk = 1;
  t->eval();
  cyc_++;
}
