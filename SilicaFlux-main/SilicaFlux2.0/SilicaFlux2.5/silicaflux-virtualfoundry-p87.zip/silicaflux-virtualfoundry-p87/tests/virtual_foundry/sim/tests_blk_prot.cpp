// tests_blk_prot.cpp -- tier 1: the three enforcement points (windows, Citadel, BridgeEngine) and bridge faults
#include "vf_test.h"

static Sim::Cfg cfg1() { Sim::Cfg c; c.nctx = VF_NCTX; return c; }
static bool is_blk0() { return (VF_KIND & 1) == 0; }
static bool tmo_cfg() { return is_blk0() && VF_RSP_TMO == 300; }

static bool no_beat_in(Sim &s, uint64_t lo, uint64_t len) {
  for (auto &q : s.bdg_log()) if (q.addr + 8 > lo && q.addr < lo + len) return false;
  return true;
}
static vf_hv_fault_t fault_of(Sim &s, int ctx = 0) { vf_hv_fault_t f; vf_hv_read_fault(s.mg(), ctx, &f); return f; }

// ------------------------------------------------------------------------------------------------------
// local windows
// ------------------------------------------------------------------------------------------------------
VF_TEST(perm_readable_denied, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  s.bdg_log_on = true;
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  canary_fill(s, CANARY_BASE, CANARY_LEN);
  uint8_t st = 0;
  // an OUT request whose payload buffer is host memory outside every window: IOERR, nothing read, nothing stored
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 5, CANARY_BASE + 128, 512, &st), VF_E_IO);
  CHECK(t, s.stor_cur() == shadow);
  CHECK(t, no_beat_in(s, CANARY_BASE, CANARY_LEN));                  // the engine never even tried to read it
  vf_hv_fault_t f = fault_of(s);
  CHECK(t, f.valid); CHECK_EQ(t, f.src, VF_FS_DESC); CHECK_EQ(t, f.addr, CANARY_BASE + 128);
  CHECK(t, vf_hv_perf32(s.mg(), 0, VF_P_VIOL) >= 1);
  CHECK(t, vf_hv_perf32(s.mg(), 0, VF_P_INVALID) >= 1);
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);                          // a refused read is not a reason to reset the device
  uint64_t buf; s.alloc(0, 1024, 8, &buf);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 5, buf, 512, &st), VF_OK);        // and the device keeps working
  CHECK_MON(t, s);
}

VF_TEST(perm_straddle_and_wrap, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  s.bdg_log_on = true;
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint8_t st;
  uint64_t end = g.base + g.size;
  // a read that starts inside the window and ends outside it is refused as a whole: no partial transfer
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 2, end - 256, 512, &st), VF_E_IO);
  CHECK(t, no_beat_in(s, end - 256, 256));                           // not even the inside half was read
  CHECK(t, s.stor_cur() == shadow);
  // one byte beyond the last byte of the window
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 2, end - 511, 512, &st), VF_E_IO);
  // exactly the last 512 bytes of the window are fine
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 2, end - 512, 512, &st), VF_OK);
  // an address range that wraps past 2^64 is refused (a naive base+len <= limit would accept it)
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 2, 0xffffffffffffff00ull, 512, &st), VF_E_IO);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 2, 0xfffffffffffffe00ull + 0x100, 0x200, &st), VF_E_IO);
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  // a writable buffer that straddles the end is fatal and nothing is written
  s.mem_wr(end - 256, std::vector<uint8_t>(256, 0x77).data(), 256);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 2, end - 256, 512, &st), VF_E_NEEDS_RESET);
  CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), VF_FC_WRITABLE_PERM);
  CHECK(t, mem_snapshot(s, end - 256, 256) == std::vector<uint8_t>(256, 0x77));
  CHECK_MON(t, s);
}

VF_TEST(perm_direction, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  const vf_mgmt_t *m = s.mg();
  uint64_t ro = g.base + 0x80000, wo = g.base + 0xC0000;
  vf_hv_set_window(m, 0, 0, g.dom, g.base, ro - 1, 1, 1);           // rings + scratch: read/write
  vf_hv_set_window(m, 0, 1, g.dom, ro, wo - 1, 1, 0);               // read-only
  vf_hv_set_window(m, 0, 2, g.dom, wo, g.base + g.size - 1, 0, 1);  // write-only
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint8_t st;
  std::vector<uint8_t> pat(512); fill_pattern(pat, 5);
  s.mem_wr(ro, pat.data(), 512);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 9, ro, 512, &st), VF_OK);        // device READS a read-only window: allowed
  memcpy(&shadow[(g.ext_base + 9) * 512], pat.data(), 512);
  CHECK(t, s.stor_cur() == shadow);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 9, wo, 512, &st), VF_OK);        // device WRITES a write-only window: allowed
  CHECK(t, mem_snapshot(s, wo, 512) == pat);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 10, wo, 512, &st), VF_E_IO);     // device READ of a write-only window: refused
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  CHECK(t, s.stor_cur() == shadow);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 9, ro, 512, &st), VF_E_NEEDS_RESET);   // device WRITE of a read-only window: refused, fatal
  CHECK_EQ(t, vf_hv_fatal_cause(m, 0), VF_FC_WRITABLE_PERM);
  CHECK(t, mem_snapshot(s, ro, 512) == pat);                          // the read-only memory is unchanged
  CHECK_MON(t, s);
}

VF_TEST(perm_wrong_domain, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0, false, true, false);                    // no window installed yet
  s.bdg_log_on = true;
  // a window that exists, covers the memory, but belongs to ANOTHER domain grants nothing
  vf_hv_set_window(s.mg(), 0, 0, (uint16_t)(g.dom + 5), g.base, g.base + g.size - 1, 1, 1);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  ReqMem r = alloc_req(s, 0);                                         // (allocated before: allocator writes the sentinel directly)
  write_hdr(s, r.hdr, VIRTIO_BLK_T_FLUSH, 0);
  raw_chain(s, b.vq, 0, {{r.hdr, 16, false}, {r.status, 1, true}});
  vf_vq_kick(&b.vq);
  CHECK(t, wait_needs_reset(s, 0));
  CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), VF_FC_RING_DMA);          // the very first ring access was refused
  vf_hv_fault_t f = fault_of(s);
  CHECK(t, f.valid); CHECK_EQ(t, f.src, VF_FS_GATE);
  CHECK_EQ(t, s.bdg_reqs(), 0);                                       // refused at the local gate: nothing reached the Citadel or the bridge
  CHECK_EQ(t, s.st_flushes, 0);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// layering: each enforcement point holds on its own
// ------------------------------------------------------------------------------------------------------
VF_TEST(layer_citadel_alone, "t1", false, is_blk0) {
  // windows allow the whole region, the Citadel only the first half: the Citadel must stop the rest
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  s.pol_region(0, g.dom, g.base, REGION / 2, true, true);
  s.bdg_log_on = true;
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t far = g.base + 0x90000;
  uint8_t st;
  std::vector<uint8_t> pat(512); fill_pattern(pat, 77);
  s.mem_wr(far, pat.data(), 512);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 3, far, 512, &st), VF_E_IO);     // OUT from beyond the Citadel region
  CHECK(t, s.stor_cur() == shadow);
  CHECK(t, no_beat_in(s, far, 512));                                  // never issued to the BridgeEngine
  vf_hv_fault_t f = fault_of(s);
  CHECK(t, f.valid); CHECK_EQ(t, f.src, VF_FS_CITADEL); CHECK_EQ(t, f.code, VF_ALB_F_NOMAP); CHECK_EQ(t, f.addr, far);
  CHECK(t, vf_hv_bridge32(s.mg(), 0, VF_B_CIT_DENIED) >= 1);
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  // an IN request into the same area: the payload write is denied mid-request, so the request cannot be completed truthfully
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 3, far, 512, &st), VF_E_NEEDS_RESET);
  CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), VF_FC_DATA_WRITE_DMA);
  CHECK(t, mem_snapshot(s, far, 512) == pat);                         // nothing was written there
  CHECK_MON(t, s);
}

VF_TEST(layer_window_alone, "t1", false, is_blk0) {
  // the Citadel allows everything, the windows only the first half: the local gate must stop the rest
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  vf_hv_set_window(s.mg(), 0, 0, g.dom, g.base, g.base + REGION / 2 - 1, 1, 1);
  s.bdg_log_on = true;
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint8_t st;
  uint64_t far = g.base + 0x90000;
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 3, far, 512, &st), VF_E_IO);
  CHECK(t, no_beat_in(s, far, 512));
  CHECK_EQ(t, fault_of(s).src, VF_FS_DESC);
  CHECK_MON(t, s);
}

VF_TEST(layer_bridge_alone, "t1", false, is_blk0) {
  // windows and Citadel allow everything; the BridgeEngine's own protected-DMA check allows less
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  s.bdg_enforce(true);
  s.bdg_allow(g.dom, g.base, REGION / 2, true, true);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint8_t st;
  uint64_t far = g.base + 0x90000, near = g.base + 0x40000;
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 3, near, 512, &st), VF_OK);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 3, far, 512, &st), VF_E_IO);      // the BridgeEngine answers ST_DENIED
  CHECK(t, s.stor_cur() == shadow || true);                           // (partial effects on a failed OUT are unspecified, see below)
  vf_hv_fault_t f = fault_of(s);
  CHECK(t, f.valid); CHECK_EQ(t, f.src, VF_FS_BRIDGE); CHECK_EQ(t, f.code, VF_ALB_ST_DENIED);
  CHECK(t, vf_hv_perf32(s.mg(), 0, VF_P_BRIDGE_ERR) >= 1);
  CHECK(t, vf_hv_bridge32(s.mg(), 0, VF_B_BDG_ERR) >= 1);
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(domain_binding, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  // the binding is locked while a queue is live; the guest cannot reach the management page at all
  s.mgmt_wr_noshadow(VF_MGMT_PAGE(0) | VF_M_DOMAIN, 0x80000000u | 7);
  CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_DOMAIN), 0x80000000u | g.dom);
  CHECK(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_STATUS) & 8);            // "write ignored" flag
  // the guest MMIO window has no register that names a domain: writes into the management range of the window do nothing
  for (uint32_t off : {0x10u, 0x180u, 0x200u, 0x300u}) s.mmio_wr(0, off, 0x12345678);
  CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_DOMAIN), 0x80000000u | g.dom);
  uint8_t st;
  CHECK_EQ(t, vf_blk_flush_sync(&b, &st), VF_OK);                    // still works with the original domain
  // after a reset the hypervisor may rebind
  vf_dev_reset(&b.dev);
  s.mgmt_wr(VF_MGMT_PAGE(0) | VF_M_DOMAIN, 0x80000000u | 9);
  CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_DOMAIN), 0x80000000u | 9);
  CHECK_MON(t, s);
}

VF_TEST(domain_too_wide, "t1", false, is_blk0) {
  // a domain that does not fit the Citadel / Albion domain field is denied, never truncated into another tenant's domain
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  s.pol_region(1, 1, g.base, g.size, true, true);                     // an entry for domain 1 (which domain 17 would alias with 4 bits)
  vf_hv_bind_domain(s.mg(), 0, 17);
  vf_hv_set_window(s.mg(), 0, 0, 17, g.base, g.base + g.size - 1, 1, 1);
  s.mon_check_bridge = false;
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  ReqMem r = alloc_req(s, 0);
  write_hdr(s, r.hdr, VIRTIO_BLK_T_FLUSH, 0);
  raw_chain(s, b.vq, 0, {{r.hdr, 16, false}, {r.status, 1, true}});
  vf_vq_kick(&b.vq);
  CHECK(t, wait_needs_reset(s, 0));
  vf_hv_fault_t f = fault_of(s);
  CHECK_EQ(t, f.src, VF_FS_CITADEL); CHECK_EQ(t, f.code, VF_ALB_F_DOMAIN);
  CHECK_EQ(t, s.bdg_reqs(), 0);
}

VF_TEST(extent_lock, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  CHECK_EQ(t, b.capacity, SECTORS);
  s.mgmt_wr_noshadow(VF_MGMT_PAGE(0) | VF_M_EXT_SIZE_LO, 4096);      // the guest has already read the capacity: ignored
  s.mgmt_wr_noshadow(VF_MGMT_PAGE(0) | VF_M_EXT_BASE_LO, 8);
  CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_EXT_SIZE_LO), SECTORS);
  CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_EXT_BASE_LO), 0);
  CHECK(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_STATUS) & 8);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// Citadel failure: default deny, fail closed
// ------------------------------------------------------------------------------------------------------
VF_TEST(citadel_default_deny, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0, false, /*citadel=*/false);              // windows installed, NO Citadel policy
  s.bdg_log_on = true;
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  ReqMem r = alloc_req(s, 0);
  write_hdr(s, r.hdr, VIRTIO_BLK_T_FLUSH, 0);
  raw_chain(s, b.vq, 0, {{r.hdr, 16, false}, {r.status, 1, true}});
  vf_vq_kick(&b.vq);
  CHECK(t, wait_needs_reset(s, 0));
  vf_hv_fault_t f = fault_of(s);
  CHECK_EQ(t, f.src, VF_FS_CITADEL); CHECK_EQ(t, f.code, VF_ALB_F_NOMAP);
  CHECK_EQ(t, s.bdg_reqs(), 0);
  // the hypervisor programs the policy, resets the device, and it works
  s.pol_region(0, g.dom, g.base, g.size, true, true);
  vf_blk_t b2;
  CHECK_EQ(t, open_blk(s, g, &b2, QS), VF_OK);
  uint8_t st;
  CHECK_EQ(t, vf_blk_flush_sync(&b2, &st), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(citadel_timeout_fail_closed, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  s.bdg_log_on = true;
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  s.cit_stall(true);                                                  // the Citadel accepts queries but never answers
  ReqMem r = alloc_req(s, 0);
  write_hdr(s, r.hdr, VIRTIO_BLK_T_FLUSH, 0);
  raw_chain(s, b.vq, 0, {{r.hdr, 16, false}, {r.status, 1, true}});
  uint64_t t0 = s.cycle();
  vf_vq_kick(&b.vq);
  CHECK(t, wait_needs_reset(s, 0));
  uint64_t dt = s.cycle() - t0;
  CHECK(t, dt >= (uint64_t)VF_CHK_TMO);                                // it waited for the Citadel ...
  CHECK(t, dt < (uint64_t)VF_CHK_TMO + 400);                           // ... but not forever
  vf_hv_fault_t f = fault_of(s);
  CHECK_EQ(t, f.src, VF_FS_CITADEL); CHECK_EQ(t, f.code, VF_ALB_F_CITTMO);
  CHECK_EQ(t, s.bdg_reqs(), 0);                                        // fail closed: no beat reached the BridgeEngine
  CHECK(t, vf_hv_bridge32(s.mg(), 0, VF_B_TIMEOUT) >= 1);
  // while in the outage the bridge answers at once, without querying: a second attempt fails quickly
  s.cit_stall(false);
  vf_blk_t b2;
  CHECK_EQ(t, open_blk(s, g, &b2, QS), VF_OK);
  uint8_t st;
  int rc = vf_blk_flush_sync(&b2, &st);
  CHECK(t, rc == VF_E_NEEDS_RESET || rc == VF_OK);                     // inside the outage window it is denied; after it, served
  // once the outage window (8 x CHK_TMO) has passed, the Citadel is consulted again and the device works
  s.tick(8 * VF_CHK_TMO + 50);
  vf_blk_t b3;
  CHECK_EQ(t, open_blk(s, g, &b3, QS), VF_OK);
  CHECK_EQ(t, vf_blk_flush_sync(&b3, &st), VF_OK);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// BridgeEngine faults
// ------------------------------------------------------------------------------------------------------
VF_TEST(bridge_echo_mismatch, "t1", false, is_blk0) {
  for (int which = 0; which < 3; which++) {                            // tag, domain, opcode
    Sim s(cfg1());
    Guest g = setup_guest(s, 0);
    vf_blk_t b;
    CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
    uint64_t buf; s.alloc(0, 1024, 8, &buf);
    std::vector<uint8_t> pat(512, 0x33);
    s.mem_wr(buf, pat.data(), 512);
    uint8_t st;
    uint64_t base = s.bdg_reqs();
    CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 4, buf, 512, &st), VF_OK);
    uint64_t beats = s.bdg_reqs() - base;
    // corrupt the echo of the response to the 5th beat after the request started (a ring / header read)
    Sim s2(cfg1());
    Guest g2 = setup_guest(s2, 0);
    vf_blk_t b2;
    CHECK_EQ(t, open_blk(s2, g2, &b2, QS), VF_OK);
    uint64_t buf2; s2.alloc(0, 1024, 8, &buf2);
    s2.mem_wr(buf2, pat.data(), 512);
    s2.bdg_inject_echo(1, which);
    int rc = vf_blk_rw_sync(&b2, 1, 4, buf2, 512, &st);
    // the very first beat (avail.idx read) came back with a wrong echo: it is an error, never data
    CHECK(t, rc == VF_E_NEEDS_RESET);
    CHECK_EQ(t, vf_hv_fatal_cause(s2.mg(), 0), VF_FC_RING_DMA);
    vf_hv_fault_t f = fault_of(s2);
    CHECK_EQ(t, f.src, VF_FS_ECHO);
    CHECK(t, beats > 5);
    CHECK_MON(t, s2);
  }
}

VF_TEST(bridge_orphan_responses, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t buf; s.alloc(0, 8192, 8, &buf);
  s.bdg_extra_rsp(6);                                                  // spurious extra responses with a stale tag
  uint8_t st;
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 2, buf, 1024, &st), VF_OK);
  CHECK(t, mem_snapshot(s, buf, 1024) == std::vector<uint8_t>(shadow.begin() + (g.ext_base + 2) * 512, shadow.begin() + (g.ext_base + 4) * 512));
  CHECK(t, s.mgmt_rd(VF_G_ORPHAN) >= 1);                               // they were seen, counted and dropped
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(bridge_silent_endpoint, "t1", false, tmo_cfg) {
  // a BridgeEngine that stops answering: the beat times out, the bridge isolates itself, a late response ends the isolation
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  Guest g1 = setup_guest(s, 1);
  s.bdg_hold(1);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  ReqMem r = alloc_req(s, 0);
  write_hdr(s, r.hdr, VIRTIO_BLK_T_FLUSH, 0);
  raw_chain(s, b.vq, 0, {{r.hdr, 16, false}, {r.status, 1, true}});
  uint64_t t0 = s.cycle();
  vf_vq_kick(&b.vq);
  CHECK(t, wait_needs_reset(s, 0));
  uint64_t dt = s.cycle() - t0;
  CHECK(t, dt >= (uint64_t)VF_RSP_TMO && dt < (uint64_t)VF_RSP_TMO + 600);
  vf_hv_fault_t f = fault_of(s);
  CHECK_EQ(t, f.src, VF_FS_TIMEOUT);
  CHECK(t, s.mgmt_rd(VF_G_STATUS) & 2);                                // the bridge reports the isolation
  // while isolated, another guest's beats fail fast instead of queueing behind the silent endpoint
  vf_blk_t b1;
  CHECK_EQ(t, open_blk(s, g1, &b1, QS), VF_OK);
  uint8_t st;
  CHECK_EQ(t, vf_blk_flush_sync(&b1, &st), VF_E_NEEDS_RESET);
  // the late response arrives: the isolation ends, other guests recover
  s.bdg_release_held();
  s.tick(20);
  CHECK(t, !(s.mgmt_rd(VF_G_STATUS) & 2));
  vf_blk_t b1b;
  CHECK_EQ(t, open_blk(s, g1, &b1b, QS), VF_OK);
  CHECK_EQ(t, vf_blk_flush_sync(&b1b, &st), VF_OK);
  vf_blk_t b0;
  CHECK_EQ(t, open_blk(s, g, &b0, QS), VF_OK);
  CHECK_EQ(t, vf_blk_flush_sync(&b0, &st), VF_OK);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// fault-injection sweep: an error on EVERY bridge beat of a request must fail safely
// ------------------------------------------------------------------------------------------------------
static void sweep(T &t, bool write) {
  const uint8_t status_cycle[] = {VF_ALB_ST_SLVERR, VF_ALB_ST_DECERR, VF_ALB_ST_DENIED};
  // learn the number of beats of a clean request
  uint64_t nbeats;
  {
    Sim s(cfg1());
    Guest g = setup_guest(s, 0);
    vf_blk_t b;
    open_blk(s, g, &b, QS);
    uint64_t buf; s.alloc(0, 2048, 8, &buf);
    uint64_t base = s.bdg_reqs();
    uint8_t st;
    vf_blk_rw_sync(&b, write, 3, buf, 512, &st);
    nbeats = s.bdg_reqs() - base;
  }
  int n_ok = 0, n_ioerr = 0, n_fatal = 0, bad = 0;
  for (uint64_t k = 0; k < nbeats; k++) {
    // payload beats are sampled, ring / descriptor / header / status beats are all covered
    if (k > 16 && k + 12 < nbeats && (k % 9) != 0) continue;
    Sim s(cfg1());
    Guest g = setup_guest(s, 0);
    std::vector<uint8_t> shadow = s.stor_cur();
    vf_blk_t b;
    if (open_blk(s, g, &b, QS) != VF_OK) { bad++; continue; }
    uint64_t buf; s.alloc(0, 2048, 8, &buf);
    std::vector<uint8_t> pat(512); fill_pattern(pat, 31);
    s.mem_wr(buf, pat.data(), 512);
    canary_fill(s, CANARY_BASE, CANARY_LEN);
    s.bdg_inject_at(s.bdg_reqs() + k, status_cycle[k % 3]);
    uint8_t st = 0xee;
    int rc = vf_blk_rw_sync(&b, write, 3, buf, 512, &st);
    bool ok_data;
    if (write) { std::vector<uint8_t> exp = shadow; memcpy(&exp[(g.ext_base + 3) * 512], pat.data(), 512); ok_data = s.stor_cur() == exp; }
    else ok_data = mem_snapshot(s, buf, 512) == std::vector<uint8_t>(shadow.begin() + (g.ext_base + 3) * 512, shadow.begin() + (g.ext_base + 4) * 512);
    if (rc == VF_OK) { n_ok++; if (!ok_data) { bad++; printf("    beat %llu: reported OK with wrong data\n", (unsigned long long)k); } }
    else if (rc == VF_E_IO) n_ioerr++;
    else if (rc == VF_E_NEEDS_RESET) n_fatal++;
    else { bad++; printf("    beat %llu: rc=%s (hang or protocol error)\n", (unsigned long long)k, vf_strerror(rc)); }
    // storage outside the request's sector range is never touched
    std::vector<uint8_t> cur = s.stor_cur();
    bool outside_ok = true;
    for (size_t i = 0; i < cur.size() && outside_ok; i += 512) {
      uint64_t sec = i / 512;
      if (sec >= g.ext_base + 3 && sec < g.ext_base + 4) continue;
      outside_ok = memcmp(&cur[i], &shadow[i], 512) == 0;
    }
    if (!outside_ok) { bad++; printf("    beat %llu: storage outside the request changed\n", (unsigned long long)k); }
    if (!canary_intact(s, CANARY_BASE, CANARY_LEN)) { bad++; }
    if (s.monitor_errors()) { bad++; }
    // the device recovers
    vf_blk_t b2;
    uint64_t buf2; s.alloc(0, 1024, 8, &buf2);
    if (vf_blk_open(&b2, s.tr(0), QS) != VF_OK || vf_blk_rw_sync(&b2, 0, 3, buf2, 512, &st) != VF_OK) { bad++; printf("    beat %llu: no recovery\n", (unsigned long long)k); }
  }
  printf("(%llu beats: %d ok, %d ioerr, %d reset) ", (unsigned long long)nbeats, n_ok, n_ioerr, n_fatal);
  CHECK_EQ(t, bad, 0);
  CHECK(t, n_fatal > 0 && (n_ioerr > 0 || write == false));
}
VF_TEST(fault_sweep_in, "t1", false, is_blk0) { sweep(t, false); }
VF_TEST(fault_sweep_out, "t1", false, is_blk0) { sweep(t, true); }

// ------------------------------------------------------------------------------------------------------
// each enforcement point must be exact at its own boundary, with the other two wide open
// (a one-byte error in one layer must not be hidden by another layer)
// ------------------------------------------------------------------------------------------------------
VF_TEST(layer_boundaries, "t1", false, is_blk0) {
  const char *names[] = {"window", "citadel", "bridge"};
  for (int layer = 0; layer < 3; layer++) {
    Sim s(cfg1());
    Guest g = setup_guest(s, 0);
    std::vector<uint8_t> shadow = s.stor_cur();
    const uint64_t HALF = 0x80000;
    if (layer == 0) vf_hv_set_window(s.mg(), 0, 0, g.dom, g.base, g.base + HALF - 1, 1, 1);
    if (layer == 1) s.pol_region(0, g.dom, g.base, HALF, true, true);
    if (layer == 2) { s.bdg_enforce(true); s.bdg_allow(g.dom, g.base, HALF, true, true); }
    s.bdg_log_on = true;
    vf_blk_t b;
    CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
    uint8_t st;
    uint64_t edge = g.base + HALF;                                     // first byte the layer does NOT cover
    std::vector<uint8_t> pat(512); fill_pattern(pat, 61 + layer);
    // exactly the last 512 bytes of the covered area: allowed
    s.mem_wr(edge - 512, pat.data(), 512);
    CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 5, edge - 512, 512, &st), VF_OK);
    CHECK(t, memcmp(&s.stor_cur()[(g.ext_base + 5) * 512], pat.data(), 512) == 0);
    // shifted up by ONE byte: the last byte lies outside the layer: refused as a whole
    std::vector<uint8_t> before = s.stor_cur();
    uint64_t nb = s.bdg_log().size();
    CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 6, edge - 511, 512, &st), VF_E_IO);
    if (layer != 2) {                                                  // the BridgeEngine layer is only reached by a beat, the others stop it earlier
      bool touched = false;
      for (size_t i = nb; i < s.bdg_log().size(); i++) if (s.bdg_log()[i].addr >= edge && s.bdg_log()[i].addr < edge + 8) touched = true;
      if (touched) printf("    [%s] a beat reached the BridgeEngine for the byte beyond the boundary\n", names[layer]);
      CHECK(t, !touched);
    }
    (void)before;
    CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
    CHECK_MON(t, s);
  }
}

VF_TEST(window_gap_and_lower_bound, "t1", false, is_blk0) {
  // two windows with a gap between them: the gap is not memory the guest may use, whatever the (wide) Citadel says
  Sim s(cfg1());
  Guest g = setup_guest(s, 0, false, true, false);
  const vf_mgmt_t *m = s.mg();
  vf_hv_set_window(m, 0, 0, g.dom, g.base, g.base + 0x7ffff, 1, 1);
  vf_hv_set_window(m, 0, 1, g.dom, g.base + 0x90000, g.base + g.size - 1, 1, 1);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  s.bdg_log_on = true;
  uint8_t st;
  uint64_t gap = g.base + 0x80000, w1 = g.base + 0x90000;
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 1, w1, 512, &st), VF_OK);                  // exactly at the start of the second window
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 1, w1 - 1, 512, &st), VF_E_IO);            // one byte below it, inside the gap
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 1, gap, 512, &st), VF_E_IO);               // wholly inside the gap
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 1, gap - 256, 512, &st), VF_E_IO);         // straddling the end of the first window
  bool touched = false;
  for (auto &q : s.bdg_log()) if (q.addr + 8 > gap && q.addr < w1 && q.addr + 8 > gap) touched = true;
  CHECK(t, !touched);
  CHECK_MON(t, s);
}
