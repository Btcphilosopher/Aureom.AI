/* vf_sim_c.h -- C ABI of the simulated platform: lets a plain C program (the host library's example, a
 * driver bring-up test) run against the Verilator model of sf_virtual_io without any PCIe hardware.
 * Implemented in vf_sim_c.cpp on top of the C++ Sim class. */
#ifndef VF_SIM_C_H
#define VF_SIM_C_H
#include <stddef.h>
#include <stdint.h>
#include "vf_host.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct vf_sim vf_sim_t;
vf_sim_t *vf_sim_create(int nctx, uint64_t seed);
void vf_sim_destroy(vf_sim_t *s);
const vf_transport_t *vf_sim_transport(vf_sim_t *s, int ctx);
const vf_mgmt_t *vf_sim_mgmt(vf_sim_t *s);
/* Provision one guest context as a hypervisor + Citadel management plane would: bind the domain, install one
 * read/write window over [mem_base, mem_base+mem_size), program the Citadel with the same region (the size must be
 * a power of two and the base aligned to it), set the storage extent, and give the guest allocator that region. */
int vf_sim_provision(vf_sim_t *s, int ctx, uint16_t domain, uint64_t mem_base, uint64_t mem_size,
                     uint64_t ext_base_sectors, uint64_t ext_size_sectors);
void vf_sim_set_latency(vf_sim_t *s, int bridge_latency, int storage_latency);
uint64_t vf_sim_cycles(vf_sim_t *s);
/* number of independent-monitor violations seen so far (any DMA / storage access outside what was provisioned) */
int vf_sim_monitor_errors(vf_sim_t *s);
void vf_sim_mem_write(vf_sim_t *s, uint64_t addr, const void *p, size_t n);
void vf_sim_mem_read(vf_sim_t *s, uint64_t addr, void *p, size_t n);
#ifdef __cplusplus
}
#endif
#endif
