// vf_test.h -- minimal test framework and fixtures for the VirtualFoundry co-simulation suite
#pragma once
#include <cstdio>
#include <cstring>
#include <functional>
#include <string>
#include <vector>

#include "vf_sim.h"

// ---- build configuration (set by the Makefile with -D) -----------------------------------------------------
#ifndef VF_NCTX
#define VF_NCTX 1
#endif
#ifndef VF_KIND
#define VF_KIND 0          /* bit i = 1: context i is virtio-net */
#endif
#ifndef VF_MAXQ
#define VF_MAXQ 256
#endif
#ifndef VF_CHAIN
#define VF_CHAIN 16
#endif
#ifndef VF_NWIN
#define VF_NWIN 8
#endif
#ifndef VF_RSP_TMO
#define VF_RSP_TMO 2048
#endif
#ifndef VF_CHK_TMO
#define VF_CHK_TMO 64
#endif
#ifndef VF_ST_TMO
#define VF_ST_TMO 4096
#endif
#ifndef VF_FBYTES
#define VF_FBYTES 2048
#endif

constexpr int QS = VF_MAXQ >= 16 ? 16 : VF_MAXQ;     // queue size used by the generic tests (the small build has QueueNumMax 8)

struct T {
  const char *name = "";
  int checks = 0, fails = 0;
  uint64_t seed = 1;
  int iters = 100;
  bool verbose = false;
};

#define CHECK(t, cond) do { (t).checks++; if (!(cond)) { (t).fails++; \
    printf("    FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); } } while (0)
#define CHECK_EQ(t, a, b) do { (t).checks++; unsigned long long _a = (unsigned long long)(a), _b = (unsigned long long)(b); \
    if (_a != _b) { (t).fails++; printf("    FAIL %s:%d: %s == %s  (0x%llx vs 0x%llx)\n", __FILE__, __LINE__, #a, #b, _a, _b); } } while (0)
#define CHECK_MON(t, sim) do { (t).checks++; if ((sim).monitor_errors()) { (t).fails++; \
    printf("    FAIL %s:%d: monitor: %s\n", __FILE__, __LINE__, (sim).monitor_first().c_str()); } } while (0)

struct TestDef {
  const char *name;
  const char *tier;                 // "t1" single queue, "t2" isolation, "t3" multi-context / net / random
  std::function<void(T &)> fn;
  bool slow;
  bool (*applies)();                // does the test apply to this build?
};
std::vector<TestDef> &registry();
struct Reg { Reg(const char *n, const char *tier, std::function<void(T &)> f, bool slow = false, bool (*ap)() = nullptr); };
#define VF_TEST(name, tier, ...) \
  static void test_##name(T &t); static Reg reg_##name(#name, tier, test_##name, ##__VA_ARGS__); static void test_##name(T &t)

// ---- fixtures ---------------------------------------------------------------------------------------------
// Memory map: guest k owns the 1 MiB region [(k+1) MiB, (k+2) MiB); the host's own memory (outside every
// guest region) lives at [0, 1 MiB) and holds canaries.  Storage: context k owns sectors [k*512, (k+1)*512).
constexpr uint64_t REGION  = 1u << 20;
constexpr uint64_t SECTORS = 512;
inline uint64_t region_of(int k) { return (uint64_t)(k + 1) * REGION; }

struct Guest {
  int ctx = 0;
  uint16_t dom = 0;
  uint64_t base = 0, size = REGION;
  uint64_t ext_base = 0, ext_size = SECTORS;
};

// Program a context the way the hypervisor + Citadel management plane would: domain binding, one
// read/write window over the guest region, one Citadel entry for the same region, storage extent.
Guest setup_guest(Sim &s, int ctx, bool ro = false, bool citadel = true, bool window = true);
// build a vf_blk for a configured guest
int open_blk(Sim &s, Guest &g, vf_blk_t *b, uint16_t qsize);

struct RawDesc { uint64_t addr; uint32_t len; uint16_t flags; uint16_t next; };
void put_desc(Sim &s, const vf_vq_t &vq, uint16_t idx, const RawDesc &d);
void raw_publish(Sim &s, vf_vq_t &vq, uint16_t head);            // avail ring slot + idx++ (no kick)
void put_u16(Sim &s, uint64_t a, uint16_t v);
uint16_t get_u16(Sim &s, uint64_t a);
uint32_t get_u32(Sim &s, uint64_t a);
bool run_until(Sim &s, const std::function<bool()> &pred, uint64_t max_cycles = 2000000);
void wait_idle(Sim &s, int ctx, uint64_t max_cycles = 2000000);
// expected-memory helpers
void fill_pattern(std::vector<uint8_t> &v, uint64_t seed);
std::vector<uint8_t> mem_snapshot(Sim &s, uint64_t a, size_t n);

// ---- raw virtqueue helpers (tests that must craft device-visible structures a driver would never build) ------
struct Seg { uint64_t addr; uint32_t len; bool w; };
// guest-memory scratch for one block request: header (16 B) + status byte, with sentinel
struct ReqMem { uint64_t hdr, status; };
ReqMem alloc_req(Sim &s, int ctx);
void write_hdr(Sim &s, uint64_t hdr, uint32_t type, uint64_t sector);
// lay the segments out as a chain starting at descriptor index `first` (first, first+1, ...), publish the head
uint16_t raw_chain(Sim &s, vf_vq_t &vq, uint16_t first, const std::vector<Seg> &segs);
// wait until the device has published `n` used entries in total
bool wait_used(Sim &s, vf_vq_t &vq, uint16_t n, uint64_t max_cycles = 400000);
// wait for DEVICE_NEEDS_RESET; returns true if it was raised
bool wait_needs_reset(Sim &s, int ctx, uint64_t max_cycles = 400000);
// full manual bring-up of a block device with explicit ring addresses (no allocator, no library queue)
struct ManualQ { uint64_t desc, avail, used; uint16_t size; vf_vq_t vq; };
int manual_init(Sim &s, int ctx, vf_dev_t *d, ManualQ *q);
// host-memory canaries (memory outside every guest region must never change)
void canary_fill(Sim &s, uint64_t base, size_t n);
bool canary_intact(Sim &s, uint64_t base, size_t n);
constexpr uint64_t CANARY_BASE = 0x1000;
constexpr size_t   CANARY_LEN  = 0x4000;

// ---- random valid-traffic worker (one guest), verified against a shared model of the storage -----------------------
struct Worker {
  Sim *s = nullptr;
  Guest g;
  vf_blk_t b;
  std::vector<uint8_t> *model = nullptr;      // model of the whole storage (all extents), updated at completion time
  std::mt19937_64 rng;
  struct Op { int kind; uint64_t sec; uint32_t nsec; std::vector<vf_sg_t> sg; std::vector<uint8_t> data; };
  std::vector<std::pair<uint16_t, Op>> inflight;   // in submission order
  uint64_t done = 0, errors = 0, mismatches = 0;
  uint64_t slot_base = 0; unsigned slot = 0, nslots = 0;
  uint64_t lat_sum = 0, lat_max = 0;
  std::vector<uint64_t> t_submit;
  int open(Sim &sim, const Guest &gg, std::vector<uint8_t> *mdl, uint64_t seed, uint16_t qsize);
  bool submit_one(unsigned allow_flush = 1);
  void kick() { vf_vq_kick(&b.vq); }
  int poll();                                  // consume every available completion and verify it
  size_t pending() const { return inflight.size(); }
};
// run the clock until every listed worker has no request in flight (polling their completions); false on timeout
bool pump(Sim &s, std::vector<Worker *> ws, uint64_t max_cycles = 3000000);

// ---- virtio-net fixtures -----------------------------------------------------------------------------------------------------
inline bool kind_net(int k) { return (VF_KIND >> k) & 1; }
inline int first_net() { for (int k = 0; k < VF_NCTX; k++) if (kind_net(k)) return k; return -1; }
std::vector<uint8_t> make_frame(size_t len, uint64_t seed);          // Ethernet-looking frame (dst, src, type, payload)
struct NetEp {
  Sim *s = nullptr;
  Guest g;
  vf_net_t n;
  uint8_t mac[6] = {0x02, 0x00, 0x5e, 0x10, 0x00, 0x00};
  std::vector<uint64_t> rxbuf;                         // posted receive buffers (2 KiB + header room)
  int open(Sim &sim, const Guest &gg, uint16_t rxq = 16, uint16_t txq = 16);
  // post one receive buffer of `len` bytes (allocated from the guest region); returns its iova
  uint64_t post_rx(uint32_t len = 2112, void *cookie = nullptr);
  void kick_rx() { vf_vq_kick(&n.rxq); }
  // transmit one frame from a (possibly misaligned) guest buffer; waits for the completion; returns 0 or an error
  int send(const std::vector<uint8_t> &f, unsigned misalign = 0, uint32_t budget = 400000);
};
