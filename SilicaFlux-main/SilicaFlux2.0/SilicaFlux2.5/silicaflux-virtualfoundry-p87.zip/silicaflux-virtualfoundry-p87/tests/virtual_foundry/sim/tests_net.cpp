// tests_net.cpp -- tier 3: virtio-net over the PacketForge stream (runs only after tier 2 passes)
#include "vf_test.h"

static Sim::Cfg cfgn() { Sim::Cfg c; c.nctx = VF_NCTX; return c; }
static bool has_net() { return first_net() >= 0; }
static bool two_nets() { int n = 0; for (int k = 0; k < VF_NCTX; k++) n += kind_net(k); return n >= 2; }

static std::vector<Guest> provision_all(Sim &s) {
  std::vector<Guest> g;
  for (int k = 0; k < VF_NCTX; k++) g.push_back(setup_guest(s, k));
  return g;
}
static uint32_t dc(Sim &s, int ctx, unsigned i) { return vf_hv_devcnt(s.mg(), ctx, i); }

// run the clock until `pred`; returns pred()
static bool until(Sim &s, const std::function<bool()> &pred, uint64_t max = 600000) { return run_until(s, pred, max); }

VF_TEST(net_identity, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  NetEp e;
  const uint8_t mac[6] = {0x02, 0xaa, 0xbb, 0xcc, 0xdd, 0xee};
  memcpy(e.mac, mac, 6);
  vf_hv_set_mac(s.mg(), k, mac);
  CHECK_EQ(t, s.mmio_rd(k, VIRTIO_MMIO_DEVICE_ID), VIRTIO_ID_NET);
  vf_hv_info_t info;
  CHECK_EQ(t, vf_hv_probe_ctx(s.mg(), k, &info), VF_OK);
  CHECK_EQ(t, info.caps0 & 0xff, 2);                                   // receiveq + transmitq
  CHECK_EQ(t, info.caps1 >> 24, VIRTIO_ID_NET);
  auto feat = [&](unsigned sel) { s.mmio_wr(k, VIRTIO_MMIO_DEVICE_FEATURES_SEL, sel); return s.mmio_rd(k, VIRTIO_MMIO_DEVICE_FEATURES); };
  // exact set: MAC(5), STATUS(16), VERSION_1(32), ACCESS_PLATFORM(33)
  CHECK_EQ(t, feat(0), (1u << 5) | (1u << 16));
  CHECK_EQ(t, feat(1), 3u);
  // features that are NOT offered must be refused: MRG_RXBUF, CSUM, CTRL_VQ, MQ, GUEST_TSO4 ...
  const unsigned unoffered[] = {0, 1, 2, 3, 7, 15, 17, 22};
  for (unsigned bit : unoffered) {
    s.mmio_wr(k, VIRTIO_MMIO_STATUS, 0);
    s.mmio_wr(k, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER);
    s.mmio_wr(k, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 0); s.mmio_wr(k, VIRTIO_MMIO_DRIVER_FEATURES, 1u << bit);
    s.mmio_wr(k, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 1); s.mmio_wr(k, VIRTIO_MMIO_DRIVER_FEATURES, 3);
    s.mmio_wr(k, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_FEATURES_OK);
    CHECK(t, !(s.mmio_rd(k, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_FEATURES_OK));
  }
  e.s = &s; e.g = gs[k];
  CHECK_EQ(t, vf_net_open(&e.n, s.tr(k), 16, 16), VF_OK);
  CHECK(t, memcmp(e.n.mac, mac, 6) == 0);                              // config space: MAC
  CHECK(t, e.n.link_up);                                               // config space: status = LINK_UP
  s.mmio_wr(k, VIRTIO_MMIO_QUEUE_SEL, 0); CHECK_EQ(t, s.mmio_rd(k, VIRTIO_MMIO_QUEUE_NUM_MAX), VF_MAXQ);
  s.mmio_wr(k, VIRTIO_MMIO_QUEUE_SEL, 1); CHECK_EQ(t, s.mmio_rd(k, VIRTIO_MMIO_QUEUE_NUM_MAX), VF_MAXQ);
  s.mmio_wr(k, VIRTIO_MMIO_QUEUE_SEL, 2); CHECK_EQ(t, s.mmio_rd(k, VIRTIO_MMIO_QUEUE_NUM_MAX), 0);
  // link-down: configuration-change notification, generation counter moves, status field follows
  uint32_t gen0 = s.mmio_rd(k, VIRTIO_MMIO_CONFIG_GENERATION);
  s.mmio_wr(k, VIRTIO_MMIO_INTERRUPT_ACK, 3);
  s.set_link(k, false);
  s.tick(4);
  CHECK(t, s.mmio_rd(k, VIRTIO_MMIO_INTERRUPT_STATUS) & VIRTIO_MMIO_INT_CONFIG);
  CHECK(t, s.mmio_rd(k, VIRTIO_MMIO_CONFIG_GENERATION) != gen0);
  CHECK_EQ(t, (s.mmio_rd(k, VIRTIO_MMIO_CONFIG + 4) >> 16) & 1, 0);
  s.set_link(k, true);
  s.tick(4);
  CHECK_EQ(t, (s.mmio_rd(k, VIRTIO_MMIO_CONFIG + 4) >> 16) & 1, 1);
  CHECK_MON(t, s);
}

VF_TEST(net_tx_basic, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  s.k.bdg_lat_max = 3; s.k.pf_tx_bp = 30;
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  const size_t sizes[] = {14, 60, 61, 64, 65, 100, 127, 128, 500, 1000, 1514, VF_FBYTES};
  std::vector<std::vector<uint8_t>> sent;
  for (size_t i = 0; i < sizeof sizes / sizeof sizes[0]; i++) {
    auto f = make_frame(sizes[i], 100 + i);
    CHECK_EQ(t, e.send(f, (unsigned)(i % 8)), VF_OK);
    sent.push_back(f);
  }
  CHECK(t, until(s, [&] { return s.pf_tx.size() >= sent.size(); }, 100000));
  CHECK_EQ(t, s.pf_tx.size(), sent.size());
  for (size_t i = 0; i < sent.size() && i < s.pf_tx.size(); i++) {
    CHECK(t, s.pf_tx[i].bytes == sent[i]);                             // byte-exact, in order
    CHECK_EQ(t, s.pf_tx[i].src, (unsigned)k);                          // the shared stream identifies the guest context ...
    CHECK_EQ(t, s.pf_tx[i].meta, gs[k].dom);                           // ... and its protection domain
  }
  CHECK_EQ(t, dc(s, k, VF_DC_NET_TX_OK), sent.size());
  CHECK_EQ(t, dc(s, k, VF_DC_NET_TX_DROP), 0);
  CHECK_EQ(t, vf_dev_check(&e.n.dev), VF_OK);
  CHECK_MON(t, s);
}

// build a raw transmit chain {hdr(12), frame...} with an explicit header
static bool raw_tx(Sim &s, NetEp &e, const uint8_t hdr[12], const std::vector<Seg> &extra) {
  uint64_t h;
  if (s.alloc(e.g.ctx, 16, 16, &h)) return false;
  s.mem_wr(h, hdr, 12);
  std::vector<Seg> segs = {{h, 12, false}};
  for (auto &x : extra) segs.push_back(x);
  uint16_t first = (uint16_t)((e.n.txq.avail_idx * 6) % e.n.txq.size);
  if (first + segs.size() > e.n.txq.size) first = 0;
  uint16_t want = (uint16_t)(vf_vq_device_used_idx(&e.n.txq) + 1);
  raw_chain(s, e.n.txq, first, segs);
  vf_vq_kick(&e.n.txq);
  return wait_used(s, e.n.txq, want, 300000);
}

VF_TEST(net_tx_checks, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  uint64_t fb; s.alloc(k, 4096, 8, &fb);
  auto f = make_frame(100, 5); s.mem_wr(fb, f.data(), f.size());
  uint8_t good[12] = {0};
  uint8_t bad_flags[12] = {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};      // NEEDS_CSUM without the feature
  uint8_t bad_gso[12]   = {0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};      // GSO_TCPV4 without the feature
  size_t before = s.pf_tx.size();
  uint32_t drops = 0;
  // header carrying an offload request the device never offered
  CHECK(t, raw_tx(s, e, bad_flags, {{fb, 100, false}})); drops++;
  CHECK(t, raw_tx(s, e, bad_gso,   {{fb, 100, false}})); drops++;
  // illegal frame sizes: shorter than an Ethernet header, longer than the frame buffer
  CHECK(t, raw_tx(s, e, good, {{fb, 13, false}})); drops++;
  CHECK(t, raw_tx(s, e, good, {{fb, 0, false}})); drops++;
  { uint64_t big; s.alloc(k, VF_FBYTES + 64, 8, &big);
    CHECK(t, raw_tx(s, e, good, {{big, (uint32_t)VF_FBYTES + 1, false}})); drops++; }
  // a device-writable descriptor on the transmit queue (direction error)
  CHECK(t, raw_tx(s, e, good, {{fb, 100, false}, {fb + 512, 16, true}})); drops++;
  // frame buffer outside the guest's windows: refused by the descriptor pre-check, nothing is read
  canary_fill(s, CANARY_BASE, CANARY_LEN);
  s.bdg_log_on = true;
  CHECK(t, raw_tx(s, e, good, {{CANARY_BASE + 64, 100, false}})); drops++;
  bool touched = false;
  for (auto &q : s.bdg_log()) if (q.addr + 8 > CANARY_BASE && q.addr < CANARY_BASE + CANARY_LEN) touched = true;
  CHECK(t, !touched);
  CHECK_EQ(t, s.pf_tx.size(), before);                                  // PacketForge never saw any of them
  CHECK_EQ(t, dc(s, k, VF_DC_NET_TX_DROP), drops);
  CHECK_EQ(t, dc(s, k, VF_DC_NET_TX_OK), 0);
  CHECK_EQ(t, vf_dev_check(&e.n.dev), VF_OK);                           // none of this is a reason to reset the device
  // and a good frame still goes out afterwards
  CHECK(t, raw_tx(s, e, good, {{fb, 100, false}}));
  CHECK(t, until(s, [&] { return s.pf_tx.size() == before + 1; }, 100000));
  CHECK(t, s.pf_tx.size() == before + 1 && s.pf_tx.back().bytes == f);
  CHECK_MON(t, s);
}

VF_TEST(net_tx_citadel_denied, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  s.pol_region((unsigned)k, gs[k].dom, gs[k].base, REGION / 2, true, true);       // Citadel allows only the first half
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  uint64_t far = gs[k].base + 0x90000;
  auto f = make_frame(200, 6); s.mem_wr(far, f.data(), f.size());
  uint8_t good[12] = {0};
  CHECK(t, raw_tx(s, e, good, {{far, 200, false}}));                    // completes (frame dropped), the device keeps running
  CHECK_EQ(t, s.pf_tx.size(), 0);
  CHECK_EQ(t, dc(s, k, VF_DC_NET_TX_DROP), 1);
  CHECK_EQ(t, dc(s, k, VF_DC_NET_TX_DMA_ERR), 1);
  vf_hv_fault_t ft; vf_hv_read_fault(s.mg(), k, &ft);
  CHECK(t, ft.valid); CHECK_EQ(t, ft.src, VF_FS_CITADEL);
  CHECK_EQ(t, vf_dev_check(&e.n.dev), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(net_rx_basic, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  s.k.bdg_lat_max = 3; s.k.pf_rx_gap = 20;
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  const size_t sizes[] = {14, 60, 61, 64, 100, 1514, 128, VF_FBYTES, 500};
  const unsigned n = sizeof sizes / sizeof sizes[0];
  for (unsigned i = 0; i < n; i++) CHECK(t, e.post_rx(VF_FBYTES + 64, (void *)(uintptr_t)(i + 1)) != 0);
  e.kick_rx();
  std::vector<std::vector<uint8_t>> frames;
  for (unsigned i = 0; i < n; i++) {
    frames.push_back(make_frame(sizes[i], 300 + i));
    s.pf_inject((unsigned)k, frames[i]);
    // one frame at a time: the device holds ONE frame buffer; a second arrival while it is occupied is dropped (tested separately)
    CHECK(t, until(s, [&] { return vf_vq_device_used_idx(&e.n.rxq) == (uint16_t)(i + 1); }, 200000));
  }
  for (unsigned i = 0; i < n; i++) {
    vf_net_completion_t c;
    CHECK_EQ(t, vf_net_poll_rx(&e.n, &c), 1);
    CHECK_EQ(t, (uintptr_t)c.cookie, i + 1);
    CHECK_EQ(t, c.used_len, 12 + sizes[i]);                            // header + frame
    auto got = mem_snapshot(s, e.rxbuf[i], 12 + sizes[i]);
    uint8_t hdr[12] = {0}; hdr[10] = 1;                                // num_buffers = 1, everything else zero
    CHECK(t, memcmp(got.data(), hdr, 12) == 0);
    CHECK(t, std::vector<uint8_t>(got.begin() + 12, got.end()) == frames[i]);
    auto tail = mem_snapshot(s, e.rxbuf[i] + 12 + sizes[i], 16);       // the device writes exactly used.len bytes
    bool poisoned = true; for (auto b : tail) poisoned &= b == 0xee;
    CHECK(t, poisoned);
  }
  CHECK_EQ(t, dc(s, k, VF_DC_NET_RX_OK), n);
  CHECK_EQ(t, dc(s, k, VF_DC_NET_RX_DROP_FULL), 0);
  CHECK_EQ(t, vf_dev_check(&e.n.dev), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(net_rx_no_buffer, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  auto f1 = make_frame(100, 1), f2 = make_frame(101, 2), f3 = make_frame(102, 3);
  s.pf_inject((unsigned)k, f1); s.pf_inject((unsigned)k, f2); s.pf_inject((unsigned)k, f3);
  CHECK(t, until(s, [&] { return s.pf_rx_idle(); }, 10000));
  s.tick(100);
  CHECK_EQ(t, dc(s, k, VF_DC_NET_RX_DROP_FULL), 2);                    // the guest supplied no buffer: the 2nd and 3rd frames are dropped, never queued without bound
  // buffers arrive: only the stored (first) frame is delivered
  uint64_t b = e.post_rx(VF_FBYTES + 64);
  e.kick_rx();
  CHECK(t, until(s, [&] { return vf_vq_device_used_idx(&e.n.rxq) == 1; }, 100000));
  CHECK(t, mem_snapshot(s, b + 12, 100) == f1);
  CHECK_EQ(t, dc(s, k, VF_DC_NET_RX_OK), 1);
  // the shared egress stream was never back-pressured by this guest
  CHECK(t, s.pf_rx_idle());
  CHECK_MON(t, s);
}

VF_TEST(net_rx_buffer_problems, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  auto f = make_frame(300, 9);
  s.pf_inject((unsigned)k, f);
  // 1) a buffer too small for header + frame: returned unused, the frame is kept
  uint64_t small = e.post_rx(100);
  // 2) a chain that carries a device-READABLE descriptor: refused, returned unused, frame kept
  uint64_t rb; s.alloc(k, 4096, 8, &rb);
  raw_chain(s, e.n.rxq, 8, {{rb, 400, false}});
  // 3) a good buffer
  uint64_t good = e.post_rx(VF_FBYTES + 64);
  e.kick_rx();
  CHECK(t, until(s, [&] { return vf_vq_device_used_idx(&e.n.rxq) == 3; }, 300000));
  CHECK_EQ(t, get_u32(s, e.n.rxq.used_iova + 4 + 8 * 0 + 4), 0);       // small buffer: used.len = 0
  CHECK_EQ(t, dc(s, k, VF_DC_NET_RX_BUF_REJ), 1);
  CHECK_EQ(t, dc(s, k, VF_DC_NET_RX_DIR_ERR), 1);
  CHECK_EQ(t, get_u32(s, e.n.rxq.used_iova + 4 + 8 * 1 + 4), 0);
  CHECK_EQ(t, get_u32(s, e.n.rxq.used_iova + 4 + 8 * 2 + 4), 312);      // the good buffer got header + frame
  CHECK(t, mem_snapshot(s, good + 12, 300) == f);
  std::vector<uint8_t> untouched = mem_snapshot(s, small, 100);
  bool p = true; for (auto b : untouched) p &= b == 0xee;
  CHECK(t, p);                                                           // nothing was written into the rejected buffers
  CHECK_EQ(t, dc(s, k, VF_DC_NET_RX_OK), 1);
  CHECK_EQ(t, vf_dev_check(&e.n.dev), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(net_rx_bad_frames, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  for (int i = 0; i < 3; i++) e.post_rx(VF_FBYTES + 64);
  e.kick_rx();
  uint32_t bad = 0;
  auto settle = [&] { CHECK(t, until(s, [&] { return s.pf_rx_idle(); }, 20000)); s.tick(60); };
  s.pf_inject((unsigned)k, make_frame(10, 1)); bad++; settle();                                    // runt: shorter than an Ethernet header
  s.pf_inject((unsigned)k, make_frame(VF_FBYTES + 8, 2)); bad++; settle();                         // oversize
  { auto fr = make_frame(80, 3); std::vector<PfBeat> bs;                                          // MAC flagged the frame bad (err on the last beat)
    for (size_t o = 0; o < fr.size(); o += 8) { size_t m = std::min<size_t>(8, fr.size() - o); uint64_t d = 0; for (size_t i = 0; i < m; i++) d |= (uint64_t)fr[o + i] << (8 * i);
      bs.push_back({d, (uint8_t)((1u << m) - 1), o + 8 >= fr.size(), o + 8 >= fr.size()}); }
    s.pf_inject_raw((unsigned)k, bs); bad++; settle(); }
  { std::vector<PfBeat> bs = {{0x1111111111111111ull, 0x7f, false, false}, {0x2222222222222222ull, 0xff, false, false}, {0x33, 0x01, true, false}};   // non-last beat with a partial keep
    s.pf_inject_raw((unsigned)k, bs); bad++; settle(); }
  { std::vector<PfBeat> bs = {{0x1111111111111111ull, 0xff, false, false}, {0x2222222222222222ull, 0xff, false, false}, {0x3333, 0x05, true, false}};   // last beat with a non-contiguous keep
    s.pf_inject_raw((unsigned)k, bs); bad++; settle(); }
  CHECK_EQ(t, dc(s, k, VF_DC_NET_RX_DROP_BAD), bad);
  CHECK_EQ(t, vf_vq_device_used_idx(&e.n.rxq), 0);                       // nothing malformed was ever delivered
  // a good frame afterwards is delivered normally
  auto f = make_frame(90, 4);
  s.pf_inject((unsigned)k, f);
  CHECK(t, until(s, [&] { return vf_vq_device_used_idx(&e.n.rxq) == 1; }, 100000));
  CHECK(t, mem_snapshot(s, e.rxbuf[0] + 12, 90) == f);
  CHECK_MON(t, s);
}

VF_TEST(net_rx_faults, "t3", false, has_net) {
  // a receive buffer the guest is not allowed to use: refused before data moves (window) or mid-way (Citadel)
  for (int variant = 0; variant < 2; variant++) {
    Sim s(cfgn());
    auto gs = provision_all(s);
    int k = first_net();
    if (variant == 1) s.pol_region((unsigned)k, gs[k].dom, gs[k].base, REGION / 2, true, true);
    NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
    auto f = make_frame(200, 11);
    s.pf_inject((unsigned)k, f);
    uint64_t target = variant == 0 ? CANARY_BASE + 256 : gs[k].base + 0x90000;
    canary_fill(s, CANARY_BASE, CANARY_LEN);
    std::vector<uint8_t> before = mem_snapshot(s, target, 512);
    uint16_t h; vf_net_post_rx(&e.n, target, 400, nullptr, &h);
    e.kick_rx();
    CHECK(t, wait_needs_reset(s, k, 300000));
    CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), k), variant == 0 ? VF_FC_WRITABLE_PERM : VF_FC_DATA_WRITE_DMA);
    CHECK(t, mem_snapshot(s, target, 512) == before);                    // nothing was written to the forbidden memory
    CHECK(t, canary_intact(s, CANARY_BASE, CANARY_LEN));
    CHECK_MON(t, s);
  }
}

VF_TEST(net_reset_discards_frames, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  s.pf_inject((unsigned)k, make_frame(120, 1));
  CHECK(t, until(s, [&] { return s.pf_rx_idle(); }, 10000));
  s.tick(50);                                                            // a frame is stored, waiting for a buffer
  s.mmio_wr(k, VIRTIO_MMIO_STATUS, 0);                                   // the driver resets the device
  NetEp e2; e2.s = &s; e2.g = gs[k];
  CHECK_EQ(t, vf_net_open(&e2.n, s.tr(k), 16, 16), VF_OK);
  e2.g = gs[k];
  uint64_t b = e2.post_rx(VF_FBYTES + 64); (void)b;
  e2.kick_rx();
  s.tick(2000);
  CHECK_EQ(t, vf_vq_device_used_idx(&e2.n.rxq), 0);                      // the old frame did not survive the reset
  // frames that arrive while the device is not operational are dropped, not kept for later
  s.mmio_wr(k, VIRTIO_MMIO_STATUS, 0);
  uint32_t d0 = dc(s, k, VF_DC_NET_RX_DROP_FULL);
  s.pf_inject((unsigned)k, make_frame(70, 2));
  CHECK(t, until(s, [&] { return s.pf_rx_idle(); }, 10000));
  s.tick(50);
  CHECK(t, dc(s, k, VF_DC_NET_RX_DROP_FULL) > d0);
  CHECK_MON(t, s);
}

VF_TEST(net_rx_unmatched, "t3", false, has_net) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int k = first_net();
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  e.post_rx(VF_FBYTES + 64); e.kick_rx();
  uint32_t u0 = s.mgmt_rd(VF_G_PF_UNMATCHED);
  s.pf_inject(9, make_frame(80, 1));                                     // queue 9: no such context
  for (int j = 0; j < VF_NCTX; j++) if (!kind_net(j)) s.pf_inject((unsigned)j, make_frame(80, 2));   // a block context is no destination either
  CHECK(t, until(s, [&] { return s.pf_rx_idle(); }, 20000));
  s.tick(100);
  uint32_t expect = 1; for (int j = 0; j < VF_NCTX; j++) if (!kind_net(j)) expect++;
  CHECK_EQ(t, s.mgmt_rd(VF_G_PF_UNMATCHED) - u0, expect);
  CHECK_EQ(t, vf_vq_device_used_idx(&e.n.rxq), 0);
  CHECK_MON(t, s);
}

VF_TEST(net_isolation, "t3", false, two_nets) {
  Sim s(cfgn());
  auto gs = provision_all(s);
  int a = -1, b = -1;
  for (int k = 0; k < VF_NCTX; k++) if (kind_net(k)) { if (a < 0) a = k; else if (b < 0) b = k; }
  s.k.bdg_lat_max = 2;
  NetEp ea, eb; CHECK_EQ(t, ea.open(s, gs[a]), VF_OK); CHECK_EQ(t, eb.open(s, gs[b]), VF_OK);
  // frames are steered by queue id to exactly one guest
  ea.post_rx(VF_FBYTES + 64); ea.post_rx(VF_FBYTES + 64); ea.kick_rx();
  eb.post_rx(VF_FBYTES + 64); eb.post_rx(VF_FBYTES + 64); eb.kick_rx();
  auto fa = make_frame(150, 21), fb = make_frame(170, 22);
  s.pf_inject((unsigned)a, fa); s.pf_inject((unsigned)b, fb);
  CHECK(t, until(s, [&] { return vf_vq_device_used_idx(&ea.n.rxq) == 1 && vf_vq_device_used_idx(&eb.n.rxq) == 1; }, 200000));
  CHECK(t, mem_snapshot(s, ea.rxbuf[0] + 12, 150) == fa);
  CHECK(t, mem_snapshot(s, eb.rxbuf[0] + 12, 170) == fb);
  CHECK_EQ(t, dc(s, a, VF_DC_NET_RX_OK), 1); CHECK_EQ(t, dc(s, b, VF_DC_NET_RX_OK), 1);
  // a guest that never supplies buffers cannot block the other one or the shared egress stream
  for (int i = 0; i < 6; i++) s.pf_inject((unsigned)a, make_frame(100 + i, 40 + i));      // guest a has no buffer left after its first frame
  eb.post_rx(VF_FBYTES + 64); eb.kick_rx();
  auto fb2 = make_frame(99, 33);
  s.pf_inject((unsigned)b, fb2);
  CHECK(t, until(s, [&] { return vf_vq_device_used_idx(&eb.n.rxq) == 2; }, 200000));
  CHECK(t, mem_snapshot(s, eb.rxbuf[1] + 12, 99) == fb2);
  // transmit from both guests: frames are never interleaved on the shared stream and carry the right source / domain
  std::vector<std::vector<uint8_t>> sa, sb;
  for (int i = 0; i < 6; i++) {
    sa.push_back(make_frame(64 + 40 * i, 50 + i)); sb.push_back(make_frame(70 + 33 * i, 70 + i));
    CHECK_EQ(t, ea.send(sa.back(), i % 4), VF_OK);
    CHECK_EQ(t, eb.send(sb.back(), (i + 1) % 4), VF_OK);
  }
  CHECK(t, until(s, [&] { return s.pf_tx.size() >= 12; }, 200000));
  size_t ia = 0, ib = 0;
  for (auto &fr : s.pf_tx) {
    if (fr.src == (unsigned)a) { CHECK(t, ia < sa.size() && fr.bytes == sa[ia]); CHECK_EQ(t, fr.meta, gs[a].dom); ia++; }
    else if (fr.src == (unsigned)b) { CHECK(t, ib < sb.size() && fr.bytes == sb[ib]); CHECK_EQ(t, fr.meta, gs[b].dom); ib++; }
    else CHECK(t, false);
  }
  CHECK_EQ(t, ia, 6); CHECK_EQ(t, ib, 6);
  CHECK_MON(t, s);
}

VF_TEST(net_blk_coexist, "t3", false, has_net) {
  // a network guest and block guests run at the same time; every transfer on both is correct
  if (VF_NCTX < 2) return;
  Sim s(cfgn());
  s.k.bdg_lat_max = 3; s.k.st_lat_max = 3; s.k.bdg_bp = 15; s.k.pf_tx_bp = 20; s.k.pf_rx_gap = 15;
  auto gs = provision_all(s);
  int k = first_net();
  std::vector<uint8_t> model = s.stor_cur();
  std::vector<Worker> wk(VF_NCTX);
  std::vector<Worker *> ws;
  for (int j = 0; j < VF_NCTX; j++) if (!kind_net(j)) { CHECK_EQ(t, wk[j].open(s, gs[j], &model, 90 + j, QS), VF_OK); ws.push_back(&wk[j]); }
  NetEp e; CHECK_EQ(t, e.open(s, gs[k]), VF_OK);
  for (int i = 0; i < 8; i++) e.post_rx(VF_FBYTES + 64);
  e.kick_rx();
  std::vector<std::vector<uint8_t>> sent, rxf;
  unsigned rx_next = 0, tx_i = 0, blk_issued = 0;
  auto blk_pending = [&] { for (auto *w : ws) if (w->pending()) return true; return false; };
  for (uint64_t c = 0; c < 6000000 && (rx_next < 6 || tx_i < 6 || blk_issued < 40 || blk_pending()); c += 8) {
    for (auto *w : ws) { w->poll(); if (blk_issued < 40 && w->pending() < 3 && w->submit_one()) { w->kick(); blk_issued++; } }
    if (tx_i < 6 && (c % 400) == 0) { sent.push_back(make_frame(80 + 57 * tx_i, 200 + tx_i)); CHECK_EQ(t, e.send(sent.back(), tx_i % 3), VF_OK); tx_i++; }
    // the device holds ONE frame: the next one is injected only after the previous one was delivered
    if (rx_next < 6 && s.pf_rx_idle() && vf_vq_device_used_idx(&e.n.rxq) == rx_next && (c % 64) == 0) {
      rxf.push_back(make_frame(60 + 71 * rx_next, 400 + rx_next)); s.pf_inject((unsigned)k, rxf.back()); rx_next++;
    }
    s.tick(8);
  }
  CHECK(t, pump(s, ws));
  CHECK(t, until(s, [&] { return s.pf_tx.size() >= sent.size() && vf_vq_device_used_idx(&e.n.rxq) >= rxf.size(); }, 400000));
  CHECK_EQ(t, s.pf_tx.size(), sent.size());
  for (size_t i = 0; i < sent.size() && i < s.pf_tx.size(); i++) CHECK(t, s.pf_tx[i].bytes == sent[i]);
  for (size_t i = 0; i < rxf.size(); i++) CHECK(t, mem_snapshot(s, e.rxbuf[i] + 12, rxf[i].size()) == rxf[i]);
  for (auto *w : ws) { CHECK_EQ(t, w->mismatches, 0); CHECK_EQ(t, w->errors, 0); }
  s.tick(1000);
  CHECK(t, s.stor_cur() == model);
  CHECK_MON(t, s);
}
