// vf_sim.h -- SilicaFlux Albion, Project 87 VirtualFoundry
//
// Co-simulation platform ("simulated host") for sf_virtual_io (Verilator):
//   * host memory shared by all guests (flat, byte addressed)
//   * BridgeEngine bench model: Albion master-port target, own protection table, programmable
//     latency / back-pressure, error / echo-corruption / silent-endpoint injection
//   * StorageCore bench model: byte-addressed store with a volatile write cache (FLUSH makes data
//     durable, power_loss() drops everything not flushed), bad sectors, flush failure, latency / back-pressure
//   * PacketForge bench model: frame sink for the transmit stream (protocol-checked), frame source
//     for the receive stream
//   * the project 83 reference Citadel (unmodified RTL, instantiated in the Verilator top) with a
//     policy programming API
//   * blocking guest MMIO and management buses used by the C host library
//   * INDEPENDENT monitors: every beat leaving the engine toward the BridgeEngine is re-checked
//     against shadow copies of the window table and the Citadel policy that are decoded from the
//     management / policy writes the TEST made (not from RTL state); every storage access is
//     re-checked against the extent of the owning context.  Any escape fails the test.
#pragma once
#include <cstdint>
#include <cstdio>
#include <deque>
#include <functional>
#include <map>
#include <memory>
#include <random>
#include <set>
#include <string>
#include <vector>

#include "vf_host.h"

class Vvf_tb_top;
class VerilatedContext;

struct Knobs {
  int bdg_bp = 0;                 // % of cycles the BridgeEngine does not accept a request
  int bdg_lat_min = 1, bdg_lat_max = 1;
  int st_bp = 0;                  // StorageCore
  int st_lat_min = 1, st_lat_max = 1;
  int pf_tx_bp = 0;               // PacketForge ingress ready
  int pf_rx_gap = 0;              // % of cycles a gap is inserted inside an injected frame
};

struct ShadowWin { bool valid = false, r = false, w = false; uint16_t dom = 0; uint64_t base = 0, limit = 0; };
struct ShadowCtx {
  uint16_t dom = 0; bool dom_valid = false;
  ShadowWin win[8];
  uint64_t ext_base = 0, ext_size = 0;      // sectors
};
struct ShadowPol { bool valid = false; uint16_t dom_mask = 0; uint64_t base = 0, mask = 0; bool rd = false, wr = false; };

struct BdgReq { uint8_t op, tag, dom, priv, tc; uint64_t addr, wdata; uint8_t wstrb; };

struct Frame { std::vector<uint8_t> bytes; unsigned src = 0; unsigned meta = 0; };
struct PfBeat { uint64_t data; uint8_t keep; bool last; bool err; };

class Sim {
 public:
  struct Cfg {
    int nctx = 1;
    uint64_t memsize = 32u << 20;
    uint64_t seed = 1;
    uint64_t stor_bytes = 1u << 20;
  };
  explicit Sim(const Cfg &c);
  ~Sim();

  // ---- clock ----------------------------------------------------------------------------------
  void tick(int n = 1);
  uint64_t cycle() const { return cyc_; }
  void chip_reset(int cycles = 4);            // rst_n low: all RTL state cleared, memory / storage kept
  uint64_t max_cycles = 400000000ull;         // watchdog for one Sim lifetime

  // ---- buses (blocking) -----------------------------------------------------------------------------
  uint32_t mmio_rd(int ctx, uint32_t off);
  void mmio_wr(int ctx, uint32_t off, uint32_t v);
  uint32_t mgmt_rd(uint32_t addr);
  void mgmt_wr(uint32_t addr, uint32_t v);    // also feeds the shadow decode
  void mgmt_wr_noshadow(uint32_t addr, uint32_t v);
  // non-blocking guest write (a quiescing write waits for the engines): start / poll
  void mmio_wr_start(int ctx, uint32_t off, uint32_t v);
  bool mmio_done(int ctx);

  // ---- memory -----------------------------------------------------------------------------------------------
  void mem_wr(uint64_t a, const void *p, size_t n);
  void mem_rd(uint64_t a, void *p, size_t n) const;
  uint64_t memsize() const { return mem_.size(); }
  void set_region(int ctx, uint64_t base, uint64_t size);
  int alloc(int ctx, size_t size, size_t align, uint64_t *iova);
  void reset_alloc(int ctx);
  uint64_t region_base(int ctx) const { return reg_base_[ctx]; }
  uint64_t region_size(int ctx) const { return reg_size_[ctx]; }

  // ---- host library bindings ----------------------------------------------------------------------------------
  vf_transport_t *tr(int ctx) { return &tr_[ctx]; }
  vf_mgmt_t *mg() { return &mg_; }
  bool irq(int ctx);
  int nctx() const { return cfg_.nctx; }
  void set_link(int ctx, bool up);

  // ---- Citadel (reference model) -----------------------------------------------------------------------------------
  void pol_set(unsigned idx, bool valid, uint16_t dom_mask, uint64_t base, uint64_t mask, bool rd, bool wr);
  // convenience: permit `dom` on [base, base+size) (size a power of two, base aligned)
  void pol_region(unsigned idx, uint16_t dom, uint64_t base, uint64_t size, bool rd, bool wr);
  void pol_clear(unsigned idx);
  void cit_stall(bool on);

  // ---- BridgeEngine bench model -----------------------------------------------------------------------------------------
  Knobs k;
  void bdg_enforce(bool on) { bdg_enf_ = on; }
  void bdg_allow(uint16_t dom, uint64_t base, uint64_t size, bool rd, bool wr);
  void bdg_clear() { bdg_tab_.clear(); }
  void bdg_inject_status(int n, uint8_t status) { inj_status_n_ = n; inj_status_ = status; }
  void bdg_inject_echo(int n, int which) { inj_echo_n_ = n; inj_echo_which_ = which; }   // 0 tag 1 dom 2 op
  void bdg_inject_at(uint64_t beat, uint8_t status) { inj_at_[beat] = status; }   // absolute beat number (bdg_reqs() when issued)
  void bdg_hold(int n) { hold_n_ = n; }               // swallow the next n responses (silent endpoint)
  void bdg_release_held();                            // deliver the swallowed responses now (late)
  void bdg_extra_rsp(int n) { dup_n_ = n; }           // send n spurious extra responses with the last tag
  uint64_t bdg_reqs() const { return bdg_cnt_; }
  uint64_t bdg_reqs_dom(unsigned d) const { return d < 256 ? bdg_dom_cnt_[d] : 0; }
  const std::vector<BdgReq> &bdg_log() const { return bdg_log_; }
  bool bdg_log_on = false;
  int bdg_outstanding_max() const { return bdg_out_max_; }

  // ---- StorageCore bench model -----------------------------------------------------------------------------------------------
  std::vector<uint8_t> stor;                          // the volatile (cache) view: what reads return
  std::vector<uint8_t> stor_dur;                      // what survives power loss
  std::set<uint64_t> bad_read, bad_write;             // 512-byte sector numbers
  bool fail_flush = false;
  void stor_fill(uint64_t seed);                      // deterministic pattern in both views
  void power_loss();                                  // drop everything not made durable by a FLUSH
  uint64_t st_reads = 0, st_writes = 0, st_flushes = 0;
  void st_hold(int n) { st_hold_n_ = n; }            // swallow the next n responses (silent StorageCore)
  void st_release_held();
  bool st_log_on = false;
  std::vector<std::pair<uint8_t, uint64_t>> st_log;     // (op, byte address) of every accepted request, in order
  const std::vector<uint8_t> &stor_cur() const { return stor; }

  // ---- PacketForge bench model -----------------------------------------------------------------------------------------------------
  void pf_inject(unsigned queue, const std::vector<uint8_t> &frame);
  void pf_inject_raw(unsigned queue, const std::vector<PfBeat> &beats);     // arbitrary (possibly illegal) stream beats
  std::deque<Frame> pf_tx;                            // frames received from the device, in order
  uint64_t pf_tx_beats = 0;
  bool pf_rx_idle() const { return pf_rx_q_.empty() && !pf_rx_busy_; }

  // ---- monitors ---------------------------------------------------------------------------------------------------------------------
  int monitor_errors() const { return mon_err_; }
  std::string monitor_first() const { return mon_first_; }
  void monitor_clear() { mon_err_ = 0; mon_first_.clear(); }
  bool lenient = false;                               // set while a test revokes windows under traffic
  bool mon_check_bridge = true, mon_check_storage = true;
  ShadowCtx &shadow(int ctx) { return sh_[ctx]; }

  std::mt19937_64 rng;
  Vvf_tb_top *top() { return top_.get(); }

 private:
  struct Bus { bool active = false, we = false, acc = false, done = false; uint32_t addr = 0, wdata = 0, rdata = 0; };
  void cycle_();
  void drive_();
  void sample_and_update_();
  void mon_err(const char *fmt, ...);
  void shadow_mgmt_write(uint32_t addr, uint32_t v);
  bool pol_allows(uint16_t dom, uint64_t addr, bool write) const;
  bool win_allows(uint16_t dom, uint64_t lo, uint64_t hi, bool write, int *ctx_out = nullptr) const;
  void bdg_apply_(const BdgReq &r, uint8_t status, uint64_t *rdata);
  uint8_t bdg_status_(const BdgReq &r);
  void clear_inflight_();
  uint64_t cyc_flush_ = 0;
  int ctx_of_dom_(uint16_t dom) const;

  Cfg cfg_;
  std::unique_ptr<VerilatedContext> ctxv_;
  std::unique_ptr<Vvf_tb_top> top_;
  std::vector<uint8_t> mem_;
  uint64_t cyc_ = 0;
  std::vector<Bus> bus_;       // per ctx mmio
  Bus mbus_;
  std::vector<uint64_t> reg_base_, reg_size_, alloc_ptr_;
  std::vector<vf_transport_t> tr_;
  vf_mgmt_t mg_;
  std::vector<ShadowCtx> sh_;
  ShadowPol spol_[8];
  struct BdgRule { uint16_t dom; uint64_t base, size; bool rd, wr; };
  std::vector<BdgRule> bdg_tab_;
  bool bdg_enf_ = false;
  // bridge model state
  struct Pend { BdgReq r; uint64_t due; uint8_t status; bool held; };
  std::deque<Pend> bq_;
  std::deque<Pend> held_;
  std::map<uint64_t, uint8_t> inj_at_;
  int inj_status_n_ = 0; uint8_t inj_status_ = 0;
  int inj_echo_n_ = 0, inj_echo_which_ = 0;
  int hold_n_ = 0, dup_n_ = 0;
  BdgReq last_req_{};
  bool bdg_rsp_driven_ = false;
  uint64_t bdg_cnt_ = 0, bdg_dom_cnt_[256] = {};
  int bdg_out_max_ = 0;
  std::vector<BdgReq> bdg_log_;
  // storage model state
  struct SPend { uint8_t op; uint64_t addr, wdata; uint8_t be; uint16_t dom; uint64_t due; bool err; };
  std::deque<SPend> sq_, sheld_;
  int st_hold_n_ = 0;
  bool pol_dirty_sectors_ = false;
  std::set<uint64_t> dirty_;
  // PacketForge model state
  std::deque<std::pair<unsigned, std::vector<PfBeat>>> pf_rx_q_;
  bool pf_rx_busy_ = false;
  std::vector<PfBeat> pf_rx_cur_; unsigned pf_rx_queue_ = 0; size_t pf_rx_off_ = 0;
  std::vector<uint8_t> pf_tx_cur_; int pf_tx_src_ = -1; unsigned pf_tx_meta_ = 0;
  std::string mon_first_;
  int mon_err_ = 0;
  bool pol_pending_ = false;
};
