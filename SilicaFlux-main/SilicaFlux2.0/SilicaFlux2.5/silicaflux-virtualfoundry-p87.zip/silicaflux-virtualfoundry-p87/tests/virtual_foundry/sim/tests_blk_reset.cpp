// tests_blk_reset.cpp -- tier 1: device reset, host reset, chip reset, queue disable, races
#include "vf_test.h"

static Sim::Cfg cfg1() { Sim::Cfg c; c.nctx = VF_NCTX; return c; }
static bool is_blk0() { return (VF_KIND & 1) == 0; }
static bool tmo_cfg() { return is_blk0() && VF_ST_TMO == 300; }

// queue a mixed batch (reads, writes, a flush) and kick; returns the number submitted
static unsigned submit_batch(Sim &s, Guest &g, vf_blk_t &b, uint64_t area, unsigned want) {
  (void)g;
  unsigned n = 0;
  for (unsigned i = 0; i < want; i++) {
    vf_sg_t sg = {area + 4096ull * i, 1024, (uint8_t)(i % 2 == 0)};
    uint16_t h;
    int r = (i % 4 == 3) ? vf_blk_submit(&b, VIRTIO_BLK_T_FLUSH, 0, nullptr, 0, nullptr, &h)
                         : vf_blk_submit(&b, (i % 2 == 0) ? VIRTIO_BLK_T_IN : VIRTIO_BLK_T_OUT, 8 * i, &sg, 1, nullptr, &h);
    if (r != VF_OK) break;
    n++;
  }
  vf_vq_kick(&b.vq);
  (void)s;
  return n;
}

struct Quiet { uint64_t bdg, st; uint16_t used; };
static Quiet quiet_snapshot(Sim &s, vf_vq_t &vq) { return {s.bdg_reqs(), s.st_reads + s.st_writes + s.st_flushes, vf_vq_device_used_idx(&vq)}; }

static void check_quiet_and_recover(T &t, Sim &s, Guest &g, vf_blk_t &b, Quiet q0, const char *what, int delay) {
  s.tick(800);
  Quiet q1 = quiet_snapshot(s, b.vq);
  if (q1.bdg != q0.bdg || q1.st != q0.st || q1.used != q0.used) printf("    [%s delay %d] activity after the reset completed: dma %llu->%llu storage %llu->%llu used %u->%u\n", what, delay,
      (unsigned long long)q0.bdg, (unsigned long long)q1.bdg, (unsigned long long)q0.st, (unsigned long long)q1.st, q0.used, q1.used);
  CHECK_EQ(t, q1.bdg, q0.bdg);            // not one more DMA beat after the reset returned
  CHECK_EQ(t, q1.st, q0.st);              // not one more storage access
  CHECK_EQ(t, q1.used, q0.used);          // the used ring was not touched
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_STATUS), 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_INTERRUPT_STATUS), 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_QUEUE_READY), 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_QUEUE_NUM), 0);                      // sel 0 after reset, QueueNum back to default (not asserted below)
  // fresh bring-up works and returns correct data
  vf_blk_t b2;
  CHECK_EQ(t, vf_blk_open(&b2, s.tr(0), QS), VF_OK);
  uint64_t buf; s.alloc(0, 2048, 8, &buf);
  uint8_t st;
  CHECK_EQ(t, vf_blk_rw_sync(&b2, 0, 11, buf, 512, &st), VF_OK);
  (void)g;
  vf_blk_close(&b2);
}

VF_TEST(reset_device_midflight, "t1", false, is_blk0) {
  const int delays[] = {1, 7, 20, 45, 80, 130, 200, 333};
  for (int d : delays) {
    Sim s(cfg1());
    s.k.bdg_lat_max = 5; s.k.st_lat_max = 6; s.k.bdg_bp = 20;
    Guest g = setup_guest(s, 0);
    vf_blk_t b;
    CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
    uint64_t area; s.alloc(0, 65536, 8, &area);
    unsigned n = submit_batch(s, g, b, area, 8);
    CHECK(t, n >= 1);
    s.tick(d);
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);                    // blocks until the engine has drained (no device write can land later)
    Quiet q0 = quiet_snapshot(s, b.vq);
    check_quiet_and_recover(t, s, g, b, q0, "guest reset", d);
    CHECK_MON(t, s);
  }
}

VF_TEST(reset_host_midflight, "t1", false, is_blk0) {
  const int delays[] = {1, 9, 30, 70, 110, 190, 300};
  for (int d : delays) {
    Sim s(cfg1());
    s.k.bdg_lat_max = 4; s.k.st_lat_max = 4;
    Guest g = setup_guest(s, 0);
    vf_blk_t b;
    CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
    uint64_t area; s.alloc(0, 65536, 8, &area);
    submit_batch(s, g, b, area, 8);
    s.tick(d);
    CHECK_EQ(t, vf_hv_host_reset(s.mg(), 0, 200000), VF_OK);     // the hypervisor resets the context
    Quiet q0 = quiet_snapshot(s, b.vq);
    check_quiet_and_recover(t, s, g, b, q0, "host reset", d);
    // management state (domain, windows, extent) survives a context reset; chip reset is what clears it
    CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_DOMAIN), 0x80000000u | g.dom);
    CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_EXT_SIZE_LO), SECTORS);
    CHECK_MON(t, s);
  }
  // host reset of an idle, never-initialised context is harmless
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  CHECK_EQ(t, vf_hv_host_reset(s.mg(), 0, 100000), VF_OK);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
}

VF_TEST(reset_chip_midflight, "t1", false, is_blk0) {
  const int delays[] = {3, 25, 90, 160};
  for (int d : delays) {
    Sim s(cfg1());
    s.k.bdg_lat_max = 4; s.k.st_lat_max = 4;
    Guest g = setup_guest(s, 0);
    vf_blk_t b;
    CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
    uint64_t area; s.alloc(0, 65536, 8, &area);
    submit_batch(s, g, b, area, 8);
    s.tick(d);
    s.chip_reset();                                          // power-on reset in the middle of traffic
    uint64_t b0 = s.bdg_reqs(); s.tick(500);
    CHECK_EQ(t, s.bdg_reqs(), b0);                           // nothing runs without configuration
    CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_DOMAIN), 0);          // management state is gone: default deny
    CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_EXT_SIZE_LO), 0);
    Guest g2 = setup_guest(s, 0);                            // the hypervisor re-provisions the context
    s.pol_region(0, g2.dom, g2.base, g2.size, true, true);
    vf_blk_t b2;
    s.reset_alloc(0);
    CHECK_EQ(t, open_blk(s, g2, &b2, QS), VF_OK);
    uint64_t buf; s.alloc(0, 2048, 8, &buf);
    uint8_t st;
    CHECK_EQ(t, vf_blk_rw_sync(&b2, 0, 11, buf, 512, &st), VF_OK);
    CHECK_MON(t, s);
  }
}

VF_TEST(queue_disable_midflight, "t1", false, is_blk0) {
  Sim s(cfg1());
  s.k.bdg_lat_max = 4; s.k.st_lat_max = 4;
  Guest g = setup_guest(s, 0);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t area; s.alloc(0, 65536, 8, &area);
  submit_batch(s, g, b, area, 8);
  s.tick(60);
  s.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 0);
  s.mmio_wr(0, VIRTIO_MMIO_QUEUE_READY, 0);                  // disable the queue: quiesced like a reset
  Quiet q0 = quiet_snapshot(s, b.vq);
  s.tick(600);
  Quiet q1 = quiet_snapshot(s, b.vq);
  CHECK_EQ(t, q1.bdg, q0.bdg); CHECK_EQ(t, q1.st, q0.st); CHECK_EQ(t, q1.used, q0.used);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_QUEUE_READY), 0);
  CHECK(t, s.mmio_rd(0, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_DRIVER_OK);   // the device itself stays up
  // re-create the queue with new rings and continue
  CHECK_EQ(t, vf_vq_setup(&b.dev, &b.vq, 0, QS), VF_OK);
  uint64_t buf; s.alloc(0, 1024, 8, &buf);
  uint8_t st;
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 12, buf, 512, &st), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(reset_races, "t1", false, is_blk0) {
  // guest reset and hypervisor reset requested at the same time, while requests are in flight
  Sim s(cfg1());
  s.k.bdg_lat_max = 6; s.k.st_lat_max = 6;
  Guest g = setup_guest(s, 0);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t area; s.alloc(0, 65536, 8, &area);
  submit_batch(s, g, b, area, 8);
  s.tick(40);
  s.mmio_wr_start(0, VIRTIO_MMIO_STATUS, 0);
  s.mgmt_wr_noshadow(VF_MGMT_PAGE(0) | VF_M_CTRL, 1);
  CHECK(t, run_until(s, [&] { return s.mmio_done(0); }, 200000));
  CHECK(t, run_until(s, [&] { return !(s.mgmt_rd(VF_MGMT_PAGE(0) | VF_M_CTRL) & 1); }, 200000));
  Quiet q0 = quiet_snapshot(s, b.vq);
  check_quiet_and_recover(t, s, g, b, q0, "reset race", 40);
  CHECK_MON(t, s);
}

VF_TEST(reset_clears_guest_state, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint8_t st;
  CHECK_EQ(t, vf_blk_flush_sync(&b, &st), VF_OK);
  CHECK(t, s.mmio_rd(0, VIRTIO_MMIO_INTERRUPT_STATUS) != 0 || true);
  s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_STATUS), 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_INTERRUPT_STATUS), 0);
  CHECK(t, !s.irq(0));
  s.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_QUEUE_READY), 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_QUEUE_NUM_MAX), VF_MAXQ);
  // a notification after the reset is ignored (the queue is not ready)
  uint64_t n0 = s.bdg_reqs();
  s.mmio_wr(0, VIRTIO_MMIO_QUEUE_NOTIFY, 0);
  s.tick(200);
  CHECK_EQ(t, s.bdg_reqs(), n0);
  // used buffers published before the reset are not published again after it
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// a StorageCore that stops answering must not hang the guest (tmo build: ST_TMO = 300)
// ------------------------------------------------------------------------------------------------------
VF_TEST(storage_silent, "t1", false, tmo_cfg) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  Guest g1 = setup_guest(s, 1);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t buf; s.alloc(0, 2048, 8, &buf);
  s.st_hold(1);
  uint8_t st = 0;
  uint64_t t0 = s.cycle();
  int rc = vf_blk_rw_sync(&b, 0, 4, buf, 512, &st);
  uint64_t dt = s.cycle() - t0;
  CHECK_EQ(t, rc, VF_E_IO);                                  // the request fails with an I/O error ...
  CHECK(t, dt >= (uint64_t)VF_ST_TMO && dt < (uint64_t)VF_ST_TMO + 2000);   // ... after the timeout, not never
  CHECK_EQ(t, s.mgmt_rd(VF_G_ST_TIMEOUTS), 1);
  CHECK(t, s.mgmt_rd(VF_G_ST_ISOLATED) & 1);
  // other guests fail fast while the storage port is isolated
  vf_blk_t b1;
  CHECK_EQ(t, open_blk(s, g1, &b1, QS), VF_OK);
  uint64_t buf1; s.alloc(1, 2048, 8, &buf1);
  t0 = s.cycle();
  CHECK_EQ(t, vf_blk_rw_sync(&b1, 0, 4, buf1, 512, &st), VF_E_IO);
  CHECK(t, s.cycle() - t0 < 2000);
  // and a guest reset is possible although the StorageCore is dead
  s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
  // the late response arrives: the isolation ends
  s.st_release_held();
  s.tick(30);
  CHECK(t, !(s.mgmt_rd(VF_G_ST_ISOLATED) & 1));
  vf_blk_t b2;
  CHECK_EQ(t, open_blk(s, g, &b2, QS), VF_OK);
  CHECK_EQ(t, vf_blk_rw_sync(&b2, 0, 4, buf, 512, &st), VF_OK);
  CHECK_MON(t, s);
}
