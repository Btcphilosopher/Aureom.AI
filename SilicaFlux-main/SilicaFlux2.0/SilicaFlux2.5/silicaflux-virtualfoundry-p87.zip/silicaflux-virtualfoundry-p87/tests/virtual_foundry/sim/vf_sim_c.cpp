// vf_sim_c.cpp -- C ABI over the C++ simulation platform
#include "vf_sim_c.h"

#include "vf_sim.h"

struct vf_sim { Sim *s; };

extern "C" {
vf_sim_t *vf_sim_create(int nctx, uint64_t seed) {
  Sim::Cfg c; c.nctx = nctx; c.seed = seed;
  auto *w = new vf_sim; w->s = new Sim(c);
  return w;
}
void vf_sim_destroy(vf_sim_t *w) { delete w->s; delete w; }
const vf_transport_t *vf_sim_transport(vf_sim_t *w, int ctx) { return w->s->tr(ctx); }
const vf_mgmt_t *vf_sim_mgmt(vf_sim_t *w) { return w->s->mg(); }
int vf_sim_provision(vf_sim_t *w, int ctx, uint16_t domain, uint64_t base, uint64_t size, uint64_t eb, uint64_t es) {
  if (!size || (size & (size - 1)) || (base & (size - 1))) return -1;
  w->s->set_region(ctx, base, size);
  vf_hv_bind_domain(w->s->mg(), ctx, domain);
  vf_hv_set_window(w->s->mg(), ctx, 0, domain, base, base + size - 1, 1, 1);
  w->s->pol_region((unsigned)ctx, domain, base, size, true, true);
  vf_hv_set_extent(w->s->mg(), ctx, eb, es, 0);
  return 0;
}
void vf_sim_set_latency(vf_sim_t *w, int b, int st) { w->s->k.bdg_lat_min = w->s->k.bdg_lat_max = b; w->s->k.st_lat_min = w->s->k.st_lat_max = st; }
uint64_t vf_sim_cycles(vf_sim_t *w) { return w->s->cycle(); }
int vf_sim_monitor_errors(vf_sim_t *w) { return w->s->monitor_errors(); }
void vf_sim_mem_write(vf_sim_t *w, uint64_t a, const void *p, size_t n) { w->s->mem_wr(a, p, n); }
void vf_sim_mem_read(vf_sim_t *w, uint64_t a, void *p, size_t n) { w->s->mem_rd(a, p, n); }
}
