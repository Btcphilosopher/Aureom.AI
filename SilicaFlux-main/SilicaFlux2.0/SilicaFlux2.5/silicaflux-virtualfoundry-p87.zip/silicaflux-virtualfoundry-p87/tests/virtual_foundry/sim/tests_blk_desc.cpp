// tests_blk_desc.cpp -- tier 1: queue engine, descriptor validation, request-level errors
#include "vf_test.h"

static Sim::Cfg cfg1() { Sim::Cfg c; c.nctx = VF_NCTX; return c; }
static bool is_blk0() { return (VF_KIND & 1) == 0; }
static bool chain_lt_q() { return is_blk0() && VF_MAXQ > VF_CHAIN; }

// ------------------------------------------------------------------------------------------------------
// valid requests with unusual (but legal) descriptor layouts
// ------------------------------------------------------------------------------------------------------
VF_TEST(valid_chains, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t area;
  CHECK_EQ(t, s.alloc(0, 65536, 8, &area), 0);
  std::vector<uint8_t> pat(16384);
  fill_pattern(pat, 99);
  auto base = [&](uint64_t sec) { return (g.ext_base + sec) * 512; };

  // (1) many small unaligned segments in one IN request (3 segments, odd sizes, odd addresses)
  {
    uint8_t st = 0xee;
    const uint32_t lens[] = {100, 412, 7, 505};          // total 1024 = 2 sectors
    vf_sg_t sg[4];
    uint64_t a = area + 1;                                // deliberately misaligned
    for (int i = 0; i < 4; i++) { sg[i] = {a, lens[i], 1}; a += lens[i] + (uint64_t)(i * 3); }
    uint16_t h; vf_blk_completion_t c;
    CHECK_EQ(t, vf_blk_submit(&b, VIRTIO_BLK_T_IN, 10, sg, 4, nullptr, &h), VF_OK);
    vf_vq_kick(&b.vq);
    CHECK_EQ(t, vf_blk_wait(&b, &c, 2000000), 1);
    CHECK_EQ(t, c.status, VIRTIO_BLK_S_OK);
    CHECK_EQ(t, c.used_len, 1024 + 1);                    // payload + status byte
    uint64_t off = 0;
    bool same = true;
    for (int i = 0; i < 4; i++) {
      auto got = mem_snapshot(s, sg[i].addr, lens[i]);
      for (uint32_t j = 0; j < lens[i]; j++) same &= got[j] == shadow[base(10) + off + j];
      off += lens[i];
    }
    CHECK(t, same);
    (void)st;
  }
  // (2) OUT request with the payload split in many unaligned pieces; compare the stored bytes
  {
    s.mem_wr(area, pat.data(), 4096);
    uint16_t h; vf_blk_completion_t c;
    vf_sg_t sg[3] = {{area + 3, 1000, 0}, {area + 1003, 1, 0}, {area + 1004, 1047, 0}};   // 2048 bytes
    CHECK_EQ(t, vf_blk_submit(&b, VIRTIO_BLK_T_OUT, 40, sg, 3, nullptr, &h), VF_OK);
    vf_vq_kick(&b.vq);
    CHECK_EQ(t, vf_blk_wait(&b, &c, 2000000), 1);
    CHECK_EQ(t, c.status, VIRTIO_BLK_S_OK);
    CHECK_EQ(t, c.used_len, 1);
    memcpy(&shadow[base(40)], &pat[3], 2048);
    CHECK(t, s.stor_cur() == shadow);
  }
  // (3) the status byte shares a descriptor with the payload (single writable descriptor: 512 + 1 bytes)
  {
    ReqMem r = alloc_req(s, 0);
    write_hdr(s, r.hdr, VIRTIO_BLK_T_IN, 3);
    uint64_t buf; s.alloc(0, 600, 8, &buf);
    vf_vq_t &vq = b.vq;
    uint16_t first = (uint16_t)(QS - 2);
    raw_chain(s, vq, first, {{r.hdr, 16, false}, {buf, 513, true}});
    vf_vq_kick(&vq);
    CHECK(t, wait_used(s, vq, vq.avail_idx));
    uint8_t stb; s.mem_rd(buf + 512, &stb, 1);
    CHECK_EQ(t, stb, VIRTIO_BLK_S_OK);
    CHECK(t, mem_snapshot(s, buf, 512) == std::vector<uint8_t>(shadow.begin() + base(3), shadow.begin() + base(3) + 512));
    uint64_t slot = (uint64_t)((vq.avail_idx - 1) & (vq.size - 1));
    CHECK_EQ(t, get_u32(s, vq.used_iova + 4 + 8 * slot), (uint32_t)(QS - 2));   // used.ring[slot].id = head
    CHECK_EQ(t, get_u32(s, vq.used_iova + 4 + 8 * slot + 4), 513);
    vq.last_used = vq.avail_idx;
  }
  // (4) the request header split over three descriptors (the device does not assume a layout, s2.6.4)
  {
    ReqMem r = alloc_req(s, 0);
    write_hdr(s, r.hdr, VIRTIO_BLK_T_IN, 6);
    uint64_t buf; s.alloc(0, 600, 8, &buf);
    vf_vq_t &vq = b.vq;
    raw_chain(s, vq, 0, {{r.hdr, 5, false}, {r.hdr + 5, 7, false}, {r.hdr + 12, 4, false}, {buf, 512, true}, {r.status, 1, true}});
    vf_vq_kick(&vq);
    CHECK(t, wait_used(s, vq, vq.avail_idx));
    uint8_t stb; s.mem_rd(r.status, &stb, 1);
    CHECK_EQ(t, stb, VIRTIO_BLK_S_OK);
    CHECK(t, mem_snapshot(s, buf, 512) == std::vector<uint8_t>(shadow.begin() + base(6), shadow.begin() + base(6) + 512));
  }
  // (5) zero-length descriptors in the middle of a chain are ignored
  {
    ReqMem r = alloc_req(s, 0);
    write_hdr(s, r.hdr, VIRTIO_BLK_T_IN, 7);
    uint64_t buf; s.alloc(0, 600, 8, &buf);
    vf_vq_t &vq = b.vq;
    raw_chain(s, vq, 0, {{r.hdr, 16, false}, {r.hdr, 0, false}, {buf, 0, true}, {buf, 512, true}, {r.status, 0, true}, {r.status, 1, true}});
    vf_vq_kick(&vq);
    CHECK(t, wait_used(s, vq, vq.avail_idx));
    uint8_t stb; s.mem_rd(r.status, &stb, 1);
    CHECK_EQ(t, stb, VIRTIO_BLK_S_OK);
    CHECK(t, mem_snapshot(s, buf, 512) == std::vector<uint8_t>(shadow.begin() + base(7), shadow.begin() + base(7) + 512));
  }
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(max_chain, "t1", false, is_blk0) {
  // exactly MAX_CHAIN descriptors is legal; seg_max = MAX_CHAIN - 2 data segments
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, VF_CHAIN * 2 <= VF_MAXQ ? VF_CHAIN * 2 : VF_MAXQ), VF_OK);
  CHECK_EQ(t, b.seg_max, VF_CHAIN - 2);
  uint64_t area; s.alloc(0, 65536, 8, &area);
  const unsigned nseg = VF_CHAIN - 2;
  std::vector<vf_sg_t> sg(nseg);
  for (unsigned i = 0; i < nseg; i++) sg[i] = {area + 512ull * i, 512, 1};
  uint16_t h; vf_blk_completion_t c;
  CHECK_EQ(t, vf_blk_submit(&b, VIRTIO_BLK_T_IN, 0, sg.data(), nseg, nullptr, &h), VF_OK);
  vf_vq_kick(&b.vq);
  CHECK_EQ(t, vf_blk_wait(&b, &c, 2000000), 1);
  CHECK_EQ(t, c.status, VIRTIO_BLK_S_OK);
  CHECK(t, mem_snapshot(s, area, 512 * nseg) == std::vector<uint8_t>(shadow.begin() + g.ext_base * 512, shadow.begin() + g.ext_base * 512 + 512 * nseg));
  // the library refuses more data segments than seg_max
  std::vector<vf_sg_t> sg2(nseg + 1, vf_sg_t{area, 512, 1});
  CHECK_EQ(t, vf_blk_submit(&b, VIRTIO_BLK_T_IN, 0, sg2.data(), nseg + 1, nullptr, &h), VF_E_INVAL);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// ring wrap-around (slot index) and 16-bit index wrap-around
// ------------------------------------------------------------------------------------------------------
VF_TEST(ring_wrap, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  vf_blk_t b;
  const uint16_t qs = 4;
  CHECK_EQ(t, open_blk(s, g, &b, qs), VF_OK);
  uint64_t area; s.alloc(0, 16384, 8, &area);
  std::vector<uint8_t> pat(512);
  int errors = 0;
  for (int i = 0; i < 6 * qs + 3; i++) {                 // several full turns of the ring
    uint8_t st;
    uint64_t sec = (uint64_t)(i * 7) % SECTORS;
    fill_pattern(pat, 1000 + i);
    s.mem_wr(area, pat.data(), 512);
    if (vf_blk_rw_sync(&b, 1, sec, area, 512, &st) != VF_OK) errors++;
    memcpy(&shadow[(g.ext_base + sec) * 512], pat.data(), 512);
    if (vf_blk_rw_sync(&b, 0, sec, area + 1024, 512, &st) != VF_OK) errors++;
    if (mem_snapshot(s, area + 1024, 512) != pat) errors++;
  }
  CHECK_EQ(t, errors, 0);
  CHECK(t, s.stor_cur() == shadow);
  // batches that fill the ring completely, repeatedly, so that avail / used indices wrap mid-batch
  for (int round = 0; round < 5; round++) {
    uint16_t heads[8]; unsigned n = 0;
    for (;; n++) {
      vf_sg_t sg = {area + 4096 + 512ull * n, 512, 1};
      if (vf_blk_submit(&b, VIRTIO_BLK_T_IN, n + round, &sg, 1, (void *)(uintptr_t)(n + 1), &heads[n]) != VF_OK) break;
    }
    CHECK_EQ(t, n, qs / 3 < 1 ? 1 : qs / 3);             // 3 descriptors per request, queue size 4: one request fits
    vf_vq_kick(&b.vq);
    for (unsigned i = 0; i < n; i++) {
      vf_blk_completion_t c;
      CHECK_EQ(t, vf_blk_wait(&b, &c, 2000000), 1);
      CHECK_EQ(t, c.status, VIRTIO_BLK_S_OK);
    }
  }
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(index_wrap16, "t1", true, is_blk0) {
  // 65 600 requests on a two-descriptor queue: avail.idx / used.idx wrap through 0xffff -> 0
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, 2), VF_OK);
  s.k.bdg_lat_max = 1;
  int errors = 0;
  for (int i = 0; i < 65600; i++) {
    uint8_t st;
    if (vf_blk_flush_sync(&b, &st) != VF_OK) { errors++; break; }
  }
  CHECK_EQ(t, errors, 0);
  CHECK_EQ(t, vf_vq_device_used_idx(&b.vq), (uint16_t)(65600 & 0xffff));
  CHECK_EQ(t, s.st_flushes, 65600);
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  CHECK_EQ(t, vf_hv_perf32(s.mg(), 0, VF_P_REQ), 65600);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// queue saturation
// ------------------------------------------------------------------------------------------------------
VF_TEST(saturation, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  vf_blk_t b;
  const uint16_t qs = VF_MAXQ >= 16 ? 16 : VF_MAXQ;
  CHECK_EQ(t, open_blk(s, g, &b, qs), VF_OK);
  uint64_t area; s.alloc(0, 65536, 8, &area);
  // fill the ring: each IN request uses 3 descriptors
  std::vector<uint16_t> heads;
  for (unsigned n = 0;; n++) {
    vf_sg_t sg = {area + 512ull * n, 512, 1};
    uint16_t h;
    int r = vf_blk_submit(&b, VIRTIO_BLK_T_IN, n, &sg, 1, (void *)(uintptr_t)(100 + n), &h);
    if (r == VF_E_NOSPC) break;
    CHECK_EQ(t, r, VF_OK);
    heads.push_back(h);
  }
  const unsigned n = (unsigned)heads.size();
  CHECK_EQ(t, n, qs / 3);                                   // saturated: the driver cannot submit another
  CHECK_EQ(t, b.vq.num_free, qs - 3 * n);
  vf_vq_kick(&b.vq);
  // all complete, in order, each with the right data and cookie
  for (unsigned i = 0; i < n; i++) {
    vf_blk_completion_t c;
    CHECK_EQ(t, vf_blk_wait(&b, &c, 2000000), 1);
    CHECK_EQ(t, c.head, heads[i]);
    CHECK_EQ(t, (uintptr_t)c.cookie, 100 + i);
    CHECK_EQ(t, c.status, VIRTIO_BLK_S_OK);
    CHECK(t, mem_snapshot(s, area + 512ull * i, 512) == std::vector<uint8_t>(shadow.begin() + (g.ext_base + i) * 512, shadow.begin() + (g.ext_base + i + 1) * 512));
  }
  CHECK_EQ(t, b.vq.num_free, qs);
  // the backlog was visible to the device: the average queue depth sampled at head fetch is > 1
  CHECK(t, vf_hv_perf32(s.mg(), 0, VF_P_QD_MAX) >= n);
  CHECK_EQ(t, vf_hv_perf32(s.mg(), 0, VF_P_QD_N), n);
  CHECK_EQ(t, vf_hv_perf32(s.mg(), 0, VF_P_REQ), n);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// request-level errors (the chain is well formed; the request is not) complete with an error status
// ------------------------------------------------------------------------------------------------------
struct ReqRes { uint8_t status; uint32_t used_len; bool done; };
static ReqRes run_raw(Sim &s, vf_vq_t &vq, uint16_t first, const std::vector<Seg> &segs, uint64_t status_addr) {
  uint16_t want = (uint16_t)(vq.avail_idx + 1);
  raw_chain(s, vq, first, segs);
  vf_vq_kick(&vq);
  ReqRes r{0xa5, 0, false};
  r.done = wait_used(s, vq, want);
  if (r.done) { s.mem_rd(status_addr, &r.status, 1); r.used_len = get_u32(s, vq.used_iova + 4 + 8 * ((want - 1) & (vq.size - 1)) + 4); }
  return r;
}

VF_TEST(request_errors, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  vf_vq_t &vq = b.vq;
  uint64_t buf; s.alloc(0, 8192, 8, &buf);
  std::vector<uint8_t> junk(2048, 0xcc);
  auto prep = [&](uint32_t type, uint64_t sector) { ReqMem r = alloc_req(s, 0); write_hdr(s, r.hdr, type, sector); s.mem_wr(buf, junk.data(), junk.size()); return r; };
  auto zero_filled = [&](uint64_t a, size_t n) { auto v = mem_snapshot(s, a, n); for (auto x : v) if (x) return false; return true; };
  auto ctr = [&](unsigned i) { return vf_hv_devcnt(s.mg(), 0, i); };
  uint16_t first = 0;
  auto nextfirst = [&]() { uint16_t f = first; first = (uint16_t)((first + 4) % QS); return f; };

  // unsupported types -> UNSUPP, nothing stored, the writable payload is zero-filled, used.len = writable bytes
  for (uint32_t ty : {2u, 3u, 11u, 13u, 99u, 0xffffffffu}) {
    ReqMem r = prep(ty, 0);
    ReqRes x = run_raw(s, vq, nextfirst(), {{r.hdr, 16, false}, {buf, 512, true}, {r.status, 1, true}}, r.status);
    CHECK(t, x.done); CHECK_EQ(t, x.status, VIRTIO_BLK_S_UNSUPP); CHECK_EQ(t, x.used_len, 513);
    CHECK(t, zero_filled(buf, 512));
  }
  CHECK_EQ(t, ctr(VF_DC_BLK_UNSUPP), 6);
  // direction errors: IN with a readable payload, OUT with a writable payload, FLUSH / GET_ID with a payload
  { ReqMem r = prep(VIRTIO_BLK_T_IN, 0);
    ReqRes x = run_raw(s, vq, nextfirst(), {{r.hdr, 16, false}, {buf, 512, false}, {r.status, 1, true}}, r.status);
    CHECK(t, x.done); CHECK_EQ(t, x.status, VIRTIO_BLK_S_IOERR); }
  { ReqMem r = prep(VIRTIO_BLK_T_OUT, 0);
    ReqRes x = run_raw(s, vq, nextfirst(), {{r.hdr, 16, false}, {buf, 512, true}, {r.status, 1, true}}, r.status);
    CHECK(t, x.done); CHECK_EQ(t, x.status, VIRTIO_BLK_S_IOERR); }
  { ReqMem r = prep(VIRTIO_BLK_T_FLUSH, 0);
    ReqRes x = run_raw(s, vq, nextfirst(), {{r.hdr, 16, false}, {buf, 512, false}, {r.status, 1, true}}, r.status);
    CHECK(t, x.done); CHECK_EQ(t, x.status, VIRTIO_BLK_S_IOERR); }
  { ReqMem r = prep(VIRTIO_BLK_T_GET_ID, 0);
    ReqRes x = run_raw(s, vq, nextfirst(), {{r.hdr, 16, false}, {buf, 20, false}, {buf + 64, 20, true}, {r.status, 1, true}}, r.status);
    CHECK(t, x.done); CHECK_EQ(t, x.status, VIRTIO_BLK_S_IOERR); }
  CHECK_EQ(t, ctr(VF_DC_BLK_DIR_ERR), 4);
  CHECK_EQ(t, s.st_flushes, 0);                              // the malformed FLUSH never reached storage
  // header shorter than 16 bytes
  { uint64_t h8; s.alloc(0, 16, 16, &h8); ReqMem r = alloc_req(s, 0);
    ReqRes x = run_raw(s, vq, nextfirst(), {{h8, 8, false}, {buf, 512, true}, {r.status, 1, true}}, r.status);
    CHECK(t, x.done); CHECK_EQ(t, x.status, VIRTIO_BLK_S_IOERR); CHECK(t, zero_filled(buf, 512)); }
  // length not a multiple of 512, sector overflow, range past the end
  { ReqMem r = prep(VIRTIO_BLK_T_IN, 0);
    ReqRes x = run_raw(s, vq, nextfirst(), {{r.hdr, 16, false}, {buf, 700, true}, {r.status, 1, true}}, r.status);
    CHECK(t, x.done); CHECK_EQ(t, x.status, VIRTIO_BLK_S_IOERR); CHECK(t, zero_filled(buf, 700)); }
  const uint64_t bad_secs[] = {SECTORS, 0x8000000000000000ull, 0xffffffffffffffffull, SECTORS - 1};
  for (uint64_t sec : bad_secs) {
    ReqMem r = prep(VIRTIO_BLK_T_IN, sec);
    ReqRes x = run_raw(s, vq, nextfirst(), {{r.hdr, 16, false}, {buf, 1024, true}, {r.status, 1, true}}, r.status);
    CHECK(t, x.done); CHECK_EQ(t, x.status, VIRTIO_BLK_S_IOERR);
    ReqMem w = prep(VIRTIO_BLK_T_OUT, sec);
    ReqRes y = run_raw(s, vq, nextfirst(), {{w.hdr, 16, false}, {buf, 1024, false}, {w.status, 1, true}}, w.status);
    CHECK(t, y.done); CHECK_EQ(t, y.status, VIRTIO_BLK_S_IOERR);
  }
  CHECK(t, s.stor_cur() == shadow);                          // not one byte of storage changed
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);                  // none of this is a reason to reset the device
  CHECK_EQ(t, s.st_writes, 0);
  CHECK_MON(t, s);
}

VF_TEST(readonly_extent, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0, true);                         // read-only extent
  std::vector<uint8_t> shadow = s.stor_cur();
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  CHECK(t, b.read_only);                                     // BLK_F_RO offered and accepted
  uint64_t buf; s.alloc(0, 4096, 8, &buf);
  uint8_t st;
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 1, buf, 512, &st), VF_OK);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 1, buf, 512, &st), VF_E_IO);   // writes are refused by the device itself
  CHECK_EQ(t, s.st_writes, 0);
  CHECK(t, s.stor_cur() == shadow);
  CHECK_MON(t, s);
}

VF_TEST(flush_not_negotiated, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  vf_dev_t d;
  CHECK_EQ(t, vf_dev_probe(&d, s.tr(0)), VF_OK);
  vf_dev_reset(&d);
  CHECK_EQ(t, vf_dev_negotiate(&d, VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM), VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM)), VF_OK);
  vf_vq_t vq;
  CHECK_EQ(t, vf_vq_setup(&d, &vq, 0, QS >= 8 ? 8 : QS), VF_OK);
  CHECK_EQ(t, vf_dev_driver_ok(&d), VF_OK);
  ReqMem r = alloc_req(s, 0);
  write_hdr(s, r.hdr, VIRTIO_BLK_T_FLUSH, 0);
  ReqRes x = run_raw(s, vq, 0, {{r.hdr, 16, false}, {r.status, 1, true}}, r.status);
  CHECK(t, x.done);
  CHECK_EQ(t, x.status, VIRTIO_BLK_S_UNSUPP);                // FLUSH was not negotiated: never forwarded to storage
  CHECK_EQ(t, s.st_flushes, 0);
  CHECK_MON(t, s);
  vf_vq_destroy(&vq);
}

// ------------------------------------------------------------------------------------------------------
// malformed rings and descriptors: every one fails safely
// ------------------------------------------------------------------------------------------------------
struct Fx1 {
  Sim s; Guest g; vf_blk_t b; uint64_t buf = 0; std::vector<uint8_t> shadow;
  Fx1() : s(cfg1()), g(setup_guest(s, 0)), shadow(s.stor_cur()) {}
};

// after a fatal error: NEEDS_RESET set, config-change interrupt, cause recorded, queue halted, no used entry,
// nothing written outside what the (valid part of the) request may touch; then a reset recovers the device.
static void expect_fatal(T &t, Fx1 &f, unsigned cause, const char *what, bool check_status_untouched = true, uint64_t status_addr = 0) {
  Sim &s = f.s;
  bool nr = wait_needs_reset(s, 0);
  if (!nr) printf("    [%s] DEVICE_NEEDS_RESET was not raised\n", what);
  CHECK(t, nr);
  CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), cause);
  if (vf_hv_fatal_cause(s.mg(), 0) != cause)
    printf("    [%s] cause %s expected %s\n", what, vf_fatal_cause_name(vf_hv_fatal_cause(s.mg(), 0)), vf_fatal_cause_name(cause));
  CHECK(t, s.mmio_rd(0, VIRTIO_MMIO_INTERRUPT_STATUS) & VIRTIO_MMIO_INT_CONFIG);   // s2.1.2 configuration-change notification
  CHECK_EQ(t, vf_vq_device_used_idx(&f.b.vq), 0);                                 // no completion for the bad request
  if (check_status_untouched) { uint8_t st; s.mem_rd(status_addr, &st, 1); CHECK_EQ(t, st, 0xa5); }
  CHECK(t, s.stor_cur() == f.shadow);
  // the queue is halted: a new, valid notification does nothing
  uint64_t before = s.bdg_reqs();
  vf_vq_kick(&f.b.vq);
  s.tick(300);
  CHECK_EQ(t, s.bdg_reqs(), before);
  // reset + re-initialisation recovers the device
  vf_blk_t b2;
  CHECK_EQ(t, vf_blk_open(&b2, s.tr(0), QS), VF_OK);
  uint8_t st;
  uint64_t buf; s.alloc(0, 1024, 8, &buf);
  CHECK_EQ(t, vf_blk_rw_sync(&b2, 0, 1, buf, 512, &st), VF_OK);
  CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), cause);                               // the cause stays readable after the reset (sticky) ...
  vf_hv_clear_faults(s.mg(), 0);
  CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), 0);                                   // ... until the hypervisor clears it
  vf_blk_close(&b2);
  CHECK_MON(t, s);
}

static ReqMem prep_in(Fx1 &f) {
  ReqMem r = alloc_req(f.s, 0);
  write_hdr(f.s, r.hdr, VIRTIO_BLK_T_IN, 2);
  if (!f.buf) f.s.alloc(0, 16384, 8, &f.buf);
  return r;
}

#define MALFORMED(NAME, CAUSE, ...) \
  VF_TEST(NAME, "t1", false, is_blk0) { Fx1 f; CHECK_EQ(t, open_blk(f.s, f.g, &f.b, QS), VF_OK); ReqMem r = prep_in(f); \
    __VA_ARGS__ ; vf_vq_kick(&f.b.vq); expect_fatal(t, f, CAUSE, #NAME, true, r.status); vf_blk_close(&f.b); }

MALFORMED(mal_head_oor, VF_FC_DESC_IDX_OOR, {
  put_u16(f.s, f.b.vq.avail_iova + 4, QS);   // head index == queue size
  put_u16(f.s, f.b.vq.avail_iova + 2, 1); f.b.vq.avail_idx = 1; })
MALFORMED(mal_next_oor, VF_FC_DESC_IDX_OOR, {
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, VIRTQ_DESC_F_NEXT, (uint16_t)QS});
  raw_publish(f.s, f.b.vq, 0); })
MALFORMED(mal_loop2, VF_FC_CHAIN_LOOP, {
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, VIRTQ_DESC_F_NEXT, 1});
  put_desc(f.s, f.b.vq, 1, {f.buf, 512, VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE, 0});
  raw_publish(f.s, f.b.vq, 0); })
MALFORMED(mal_loop_self, VF_FC_CHAIN_LOOP, {
  put_desc(f.s, f.b.vq, 3, {r.hdr, 16, VIRTQ_DESC_F_NEXT, 3});
  raw_publish(f.s, f.b.vq, 3); })
MALFORMED(mal_flags_indirect, VF_FC_DESC_FLAGS, {
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, VIRTQ_DESC_F_INDIRECT, 0});
  raw_publish(f.s, f.b.vq, 0); })
MALFORMED(mal_flags_reserved, VF_FC_DESC_FLAGS, {
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, (uint16_t)(VIRTQ_DESC_F_NEXT | 0x8), 1});
  put_desc(f.s, f.b.vq, 1, {r.status, 1, VIRTQ_DESC_F_WRITE, 0});
  raw_publish(f.s, f.b.vq, 0); })
MALFORMED(mal_order, VF_FC_CHAIN_ORDER, {   // readable descriptor after a writable one
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, VIRTQ_DESC_F_NEXT, 1});
  put_desc(f.s, f.b.vq, 1, {f.buf, 512, VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE, 2});
  put_desc(f.s, f.b.vq, 2, {r.hdr, 16, VIRTQ_DESC_F_NEXT, 3});
  put_desc(f.s, f.b.vq, 3, {r.status, 1, VIRTQ_DESC_F_WRITE, 0});
  raw_publish(f.s, f.b.vq, 0); })
MALFORMED(mal_len_overflow, VF_FC_CHAIN_LEN_OVF, {   // chain longer than 2^32 bytes (s2.7.13.1)
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, VIRTQ_DESC_F_NEXT, 1});
  put_desc(f.s, f.b.vq, 1, {f.buf, 0x80000000u, VIRTQ_DESC_F_NEXT, 2});
  put_desc(f.s, f.b.vq, 2, {f.buf, 0x80000000u, VIRTQ_DESC_F_NEXT, 3});
  put_desc(f.s, f.b.vq, 3, {r.status, 1, VIRTQ_DESC_F_WRITE, 0});
  raw_publish(f.s, f.b.vq, 0); })
MALFORMED(mal_no_status, VF_FC_NO_STATUS, {   // no device-writable byte for the status
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, 0, 0});
  raw_publish(f.s, f.b.vq, 0); })
MALFORMED(mal_avail_jump, VF_FC_AVAIL_IDX_JUMP, {   // avail.idx ran ahead by more than the queue size
  put_u16(f.s, f.b.vq.avail_iova + 2, QS + 1); })
MALFORMED(mal_writable_perm, VF_FC_WRITABLE_PERM, {   // writable buffer inside host memory, outside the guest's windows
  canary_fill(f.s, CANARY_BASE, CANARY_LEN);
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, VIRTQ_DESC_F_NEXT, 1});
  put_desc(f.s, f.b.vq, 1, {CANARY_BASE + 64, 512, VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE, 2});
  put_desc(f.s, f.b.vq, 2, {r.status, 1, VIRTQ_DESC_F_WRITE, 0});
  raw_publish(f.s, f.b.vq, 0); })

VF_TEST(mal_too_long, "t1", false, chain_lt_q) {
  Fx1 f;
  CHECK_EQ(t, open_blk(f.s, f.g, &f.b, VF_MAXQ >= 32 ? 32 : VF_MAXQ), VF_OK);
  ReqMem r = prep_in(f);
  const unsigned n = VF_CHAIN + 1;                       // one descriptor more than MAX_CHAIN
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, VIRTQ_DESC_F_NEXT, 1});
  for (unsigned i = 1; i + 1 < n; i++) put_desc(f.s, f.b.vq, (uint16_t)i, {f.buf + 512ull * i, 512, (uint16_t)(VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE), (uint16_t)(i + 1)});
  put_desc(f.s, f.b.vq, (uint16_t)(n - 1), {r.status, 1, VIRTQ_DESC_F_WRITE, 0});
  raw_publish(f.s, f.b.vq, 0);
  vf_vq_kick(&f.b.vq);
  expect_fatal(t, f, VF_FC_CHAIN_TOO_LONG, "mal_too_long", true, r.status);
  vf_blk_close(&f.b);
}

VF_TEST(mal_writable_perm_effects, "t1", false, is_blk0) {
  // the host memory the guest tried to overwrite is untouched (the gate refused before any data moved)
  Fx1 f;
  CHECK_EQ(t, open_blk(f.s, f.g, &f.b, QS), VF_OK);
  ReqMem r = prep_in(f);
  canary_fill(f.s, CANARY_BASE, CANARY_LEN);
  put_desc(f.s, f.b.vq, 0, {r.hdr, 16, VIRTQ_DESC_F_NEXT, 1});
  put_desc(f.s, f.b.vq, 1, {CANARY_BASE + 64, 512, VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE, 2});
  put_desc(f.s, f.b.vq, 2, {r.status, 1, VIRTQ_DESC_F_WRITE, 0});
  raw_publish(f.s, f.b.vq, 0);
  vf_vq_kick(&f.b.vq);
  CHECK(t, wait_needs_reset(f.s, 0));
  CHECK(t, canary_intact(f.s, CANARY_BASE, CANARY_LEN));
  vf_hv_fault_t ft; vf_hv_read_fault(f.s.mg(), 0, &ft);
  CHECK(t, ft.valid);
  CHECK_EQ(t, ft.src, VF_FS_DESC);                           // caught by the descriptor pre-check, before any DMA
  CHECK_EQ(t, ft.addr, CANARY_BASE + 64);
  CHECK(t, vf_hv_perf32(f.s.mg(), 0, VF_P_VIOL) >= 1);
  CHECK_EQ(t, f.s.bdg_reqs_dom(f.g.dom) > 0, true);          // ring accesses before the walk happened
  CHECK_MON(t, f.s);
  vf_blk_close(&f.b);
}

VF_TEST(queue_config_invalid, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  uint64_t base = g.base + 0x1000;
  struct C { uint32_t num; uint64_t desc, avail, used; const char *what; };
  const C cases[] = {
    {3, base, base + 0x400, base + 0x800, "queue size not a power of two"},
    {0, base, base + 0x400, base + 0x800, "queue size zero"},
    {VF_MAXQ * 2u, base, base + 0x400, base + 0x800, "queue size above QueueNumMax"},
    {8, base + 8, base + 0x400, base + 0x800, "descriptor table not 16-byte aligned"},
    {8, base, base + 0x401, base + 0x800, "available ring not 2-byte aligned"},
    {8, base, base + 0x400, base + 0x802, "used ring not 4-byte aligned"},
  };
  for (const C &c : cases) {
    vf_dev_t d;
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
    CHECK_EQ(t, vf_dev_probe(&d, s.tr(0)), VF_OK);
    CHECK_EQ(t, vf_dev_negotiate(&d, VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM), VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM)), VF_OK);
    s.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 0);
    s.mmio_wr(0, VIRTIO_MMIO_QUEUE_NUM, c.num);
    s.mmio_wr(0, VIRTIO_MMIO_QUEUE_DESC_LOW, (uint32_t)c.desc);   s.mmio_wr(0, VIRTIO_MMIO_QUEUE_DESC_HIGH, 0);
    s.mmio_wr(0, VIRTIO_MMIO_QUEUE_DRIVER_LOW, (uint32_t)c.avail); s.mmio_wr(0, VIRTIO_MMIO_QUEUE_DRIVER_HIGH, 0);
    s.mmio_wr(0, VIRTIO_MMIO_QUEUE_DEVICE_LOW, (uint32_t)c.used);  s.mmio_wr(0, VIRTIO_MMIO_QUEUE_DEVICE_HIGH, 0);
    s.mmio_wr(0, VIRTIO_MMIO_QUEUE_READY, 1);
    if (s.mmio_rd(0, VIRTIO_MMIO_QUEUE_READY) != 0) printf("    [%s] queue accepted\n", c.what);
    CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_QUEUE_READY), 0);
    CHECK(t, s.mmio_rd(0, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_DEVICE_NEEDS_RESET);
    CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), VF_FC_QUEUE_CFG);
  }
  // QueueNumMax for an unimplemented queue is 0 (the queue does not exist)
  s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
  s.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 1);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_QUEUE_NUM_MAX), 0);
  s.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_QUEUE_NUM_MAX), VF_MAXQ);
  // notification of a queue that does not exist is ignored
  s.mmio_wr(0, VIRTIO_MMIO_QUEUE_NOTIFY, 1);
  CHECK_EQ(t, vf_hv_perf32(s.mg(), 0, VF_P_NOTIFY), 0);
  CHECK_MON(t, s);
}

VF_TEST(no_domain, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  vf_hv_unbind_domain(s.mg(), 0);                            // the context has no protection domain
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  ReqMem r = alloc_req(s, 0);
  write_hdr(s, r.hdr, VIRTIO_BLK_T_FLUSH, 0);
  raw_chain(s, b.vq, 0, {{r.hdr, 16, false}, {r.status, 1, true}});
  vf_vq_kick(&b.vq);
  CHECK(t, wait_needs_reset(s, 0));
  CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), VF_FC_NO_DOMAIN);
  CHECK_EQ(t, s.bdg_reqs(), 0);                              // no DMA of any kind without a domain
  CHECK_MON(t, s);
}
