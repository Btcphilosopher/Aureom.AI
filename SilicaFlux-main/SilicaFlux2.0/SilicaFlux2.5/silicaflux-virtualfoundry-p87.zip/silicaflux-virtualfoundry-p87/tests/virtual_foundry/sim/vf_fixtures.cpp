// vf_fixtures.cpp -- shared helpers for the co-simulation tests
#include <stdexcept>
#include "vf_test.h"

std::vector<TestDef> &registry() { static std::vector<TestDef> r; return r; }
Reg::Reg(const char *n, const char *tier, std::function<void(T &)> f, bool slow, bool (*ap)()) {
  registry().push_back(TestDef{n, tier, std::move(f), slow, ap});
}

Guest setup_guest(Sim &s, int ctx, bool ro, bool citadel, bool window) {
  Guest g;
  g.ctx = ctx;
  g.dom = (uint16_t)(ctx + 1);                    // domain 0 is never used so a zero-initialised tag is visibly wrong
  g.base = region_of(ctx);
  g.size = REGION;
  g.ext_base = (uint64_t)ctx * SECTORS;
  g.ext_size = SECTORS;
  s.set_region(ctx, g.base, g.size);
  const vf_mgmt_t *m = s.mg();
  vf_hv_bind_domain(m, ctx, g.dom);
  if (window) vf_hv_set_window(m, ctx, 0, g.dom, g.base, g.base + g.size - 1, 1, 1);
  if (citadel) s.pol_region(ctx, g.dom, g.base, g.size, true, true);
  vf_hv_set_extent(m, ctx, g.ext_base, g.ext_size, ro);
  // the shadow decode for the extent is done by Sim::mgmt_wr; the monitor mirrors the same registers
  return g;
}

int open_blk(Sim &s, Guest &g, vf_blk_t *b, uint16_t qsize) { return vf_blk_open(b, s.tr(g.ctx), qsize); }

void put_u16(Sim &s, uint64_t a, uint16_t v) { uint8_t b[2] = {(uint8_t)v, (uint8_t)(v >> 8)}; s.mem_wr(a, b, 2); }
uint16_t get_u16(Sim &s, uint64_t a) { uint8_t b[2]; s.mem_rd(a, b, 2); return (uint16_t)(b[0] | (b[1] << 8)); }
uint32_t get_u32(Sim &s, uint64_t a) { uint8_t b[4]; s.mem_rd(a, b, 4); return (uint32_t)b[0] | ((uint32_t)b[1] << 8) | ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24); }

void put_desc(Sim &s, const vf_vq_t &vq, uint16_t idx, const RawDesc &d) {
  uint8_t b[16];
  for (int i = 0; i < 8; i++) b[i] = (uint8_t)(d.addr >> (8 * i));
  for (int i = 0; i < 4; i++) b[8 + i] = (uint8_t)(d.len >> (8 * i));
  b[12] = (uint8_t)d.flags; b[13] = (uint8_t)(d.flags >> 8);
  b[14] = (uint8_t)d.next;  b[15] = (uint8_t)(d.next >> 8);
  s.mem_wr(vq.desc_iova + 16ull * idx, b, 16);
}
void raw_publish(Sim &s, vf_vq_t &vq, uint16_t head) {
  put_u16(s, vq.avail_iova + 4 + 2ull * (vq.avail_idx & (vq.size - 1)), head);
  vq.avail_idx++;
  put_u16(s, vq.avail_iova + 2, vq.avail_idx);
}

bool run_until(Sim &s, const std::function<bool()> &pred, uint64_t max_cycles) {
  for (uint64_t i = 0; i < max_cycles; i++) { if (pred()) return true; s.tick(); }
  return pred();
}
void wait_idle(Sim &s, int ctx, uint64_t max_cycles) {
  run_until(s, [&] { return !(s.mgmt_rd(VF_MGMT_PAGE(ctx) | VF_M_STATUS) & 1u); }, max_cycles);
}

void fill_pattern(std::vector<uint8_t> &v, uint64_t seed) {
  uint64_t x = seed * 0x9e3779b97f4a7c15ull + 1;
  for (auto &b : v) { x ^= x << 13; x ^= x >> 7; x ^= x << 17; b = (uint8_t)(x >> 24); }
}
std::vector<uint8_t> mem_snapshot(Sim &s, uint64_t a, size_t n) { std::vector<uint8_t> v(n); s.mem_rd(a, v.data(), n); return v; }

ReqMem alloc_req(Sim &s, int ctx) {
  ReqMem r;
  if (s.alloc(ctx, 16, 16, &r.hdr) || s.alloc(ctx, 16, 16, &r.status)) throw std::runtime_error("guest region exhausted");
  uint8_t sent = 0xa5;
  s.mem_wr(r.status, &sent, 1);
  return r;
}
void write_hdr(Sim &s, uint64_t hdr, uint32_t type, uint64_t sector) {
  uint8_t h[16] = {};
  for (int i = 0; i < 4; i++) h[i] = (uint8_t)(type >> (8 * i));
  for (int i = 0; i < 8; i++) h[8 + i] = (uint8_t)(sector >> (8 * i));
  s.mem_wr(hdr, h, 16);
}
uint16_t raw_chain(Sim &s, vf_vq_t &vq, uint16_t first, const std::vector<Seg> &segs) {
  for (size_t i = 0; i < segs.size(); i++) {
    RawDesc d{segs[i].addr, segs[i].len, (uint16_t)((segs[i].w ? VIRTQ_DESC_F_WRITE : 0) | (i + 1 < segs.size() ? VIRTQ_DESC_F_NEXT : 0)),
              (uint16_t)(i + 1 < segs.size() ? first + i + 1 : 0)};
    put_desc(s, vq, (uint16_t)(first + i), d);
  }
  raw_publish(s, vq, first);
  return first;
}
bool wait_used(Sim &s, vf_vq_t &vq, uint16_t n, uint64_t max_cycles) {
  return run_until(s, [&] { return vf_vq_device_used_idx(&vq) == n; }, max_cycles);
}
bool wait_needs_reset(Sim &s, int ctx, uint64_t max_cycles) {
  for (uint64_t i = 0; i < max_cycles; i += 8) {
    if (s.mmio_rd(ctx, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_DEVICE_NEEDS_RESET) return true;
    s.tick(8);
  }
  return false;
}
int manual_init(Sim &s, int ctx, vf_dev_t *d, ManualQ *q) {
  int r = vf_dev_probe(d, s.tr(ctx));
  if (r) return r;
  if ((r = vf_dev_reset(d))) return r;
  if ((r = vf_dev_negotiate(d, VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM) | VF_FEAT(VIRTIO_BLK_F_SEG_MAX) | VF_FEAT(VIRTIO_BLK_F_FLUSH),
                            VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM)))) return r;
  s.mmio_wr(ctx, VIRTIO_MMIO_QUEUE_SEL, 0);
  s.mmio_wr(ctx, VIRTIO_MMIO_QUEUE_NUM, q->size);
  s.mmio_wr(ctx, VIRTIO_MMIO_QUEUE_DESC_LOW, (uint32_t)q->desc);   s.mmio_wr(ctx, VIRTIO_MMIO_QUEUE_DESC_HIGH, (uint32_t)(q->desc >> 32));
  s.mmio_wr(ctx, VIRTIO_MMIO_QUEUE_DRIVER_LOW, (uint32_t)q->avail); s.mmio_wr(ctx, VIRTIO_MMIO_QUEUE_DRIVER_HIGH, (uint32_t)(q->avail >> 32));
  s.mmio_wr(ctx, VIRTIO_MMIO_QUEUE_DEVICE_LOW, (uint32_t)q->used);  s.mmio_wr(ctx, VIRTIO_MMIO_QUEUE_DEVICE_HIGH, (uint32_t)(q->used >> 32));
  s.mmio_wr(ctx, VIRTIO_MMIO_QUEUE_READY, 1);
  q->vq = vf_vq_t{};
  q->vq.dev = d; q->vq.index = 0; q->vq.size = q->size;
  q->vq.desc_iova = q->desc; q->vq.avail_iova = q->avail; q->vq.used_iova = q->used;
  if (!(s.mmio_rd(ctx, VIRTIO_MMIO_QUEUE_READY) & 1)) return VF_E_QUEUE;
  s.mmio_wr(ctx, VIRTIO_MMIO_STATUS, s.mmio_rd(ctx, VIRTIO_MMIO_STATUS) | VIRTIO_STATUS_DRIVER_OK);
  return VF_OK;
}
void canary_fill(Sim &s, uint64_t base, size_t n) { std::vector<uint8_t> v(n, 0x5a); s.mem_wr(base, v.data(), n); }
bool canary_intact(Sim &s, uint64_t base, size_t n) {
  std::vector<uint8_t> v(n);
  s.mem_rd(base, v.data(), n);
  for (auto b : v) if (b != 0x5a) return false;
  return true;
}

// ---- Worker -----------------------------------------------------------------------------------------------------------
int Worker::open(Sim &sim, const Guest &gg, std::vector<uint8_t> *mdl, uint64_t seed, uint16_t qsize) {
  s = &sim; g = gg; model = mdl; rng.seed(seed);
  int r = vf_blk_open(&b, s->tr(g.ctx), qsize);
  if (r) return r;
  nslots = 24;
  if (s->alloc(g.ctx, (size_t)nslots * 4096, 4096, &slot_base)) return VF_E_NOMEM;
  return VF_OK;
}

bool Worker::submit_one(unsigned allow_flush) {
  Op op;
  unsigned pick = (unsigned)(rng() % 10);
  op.kind = (allow_flush && pick == 0) ? 2 : (pick < 5 ? 0 : 1);       // 0 IN, 1 OUT, 2 FLUSH
  uint16_t h;
  if (op.kind == 2) {
    if (vf_blk_submit(&b, VIRTIO_BLK_T_FLUSH, 0, nullptr, 0, nullptr, &h) != VF_OK) return false;
    inflight.push_back({h, op});
    t_submit.push_back(s->cycle());
    return true;
  }
  op.nsec = 1 + (unsigned)(rng() % 4);
  op.sec = rng() % (g.ext_size - op.nsec + 1);
  uint32_t total = op.nsec * 512;
  uint64_t buf = slot_base + 4096ull * (slot++ % nslots) + (rng() % 8);       // misaligned buffers
  unsigned nseg = 1 + (unsigned)(rng() % 3);
  uint32_t left = total, off = 0;
  for (unsigned i = 0; i < nseg; i++) {
    uint32_t len = (i + 1 == nseg) ? left : (uint32_t)(1 + rng() % (left > 1 ? left - 1 : 1));
    if (i + 1 < nseg && len >= left) len = left > 1 ? left - 1 : left;
    if (len == 0) continue;
    op.sg.push_back({buf + off + 5 * i, len, (uint8_t)(op.kind == 0)});
    off += len; left -= len;
  }
  // gaps of 5 bytes between segments: recompute because segment addresses are offset by 5*i
  if (op.kind == 1) {
    op.data.resize(total);
    fill_pattern(op.data, rng());
    uint32_t o = 0;
    for (auto &sg : op.sg) { s->mem_wr(sg.addr, &op.data[o], sg.len); o += sg.len; }
  }
  int r = vf_blk_submit(&b, op.kind == 0 ? VIRTIO_BLK_T_IN : VIRTIO_BLK_T_OUT, op.sec, op.sg.data(), (unsigned)op.sg.size(), nullptr, &h);
  if (r != VF_OK) return false;
  inflight.push_back({h, op});
  t_submit.push_back(s->cycle());
  return true;
}

int Worker::poll() {
  int n = 0;
  for (;;) {
    vf_blk_completion_t c;
    int r = vf_blk_poll(&b, &c);
    if (r < 0) { errors++; return r; }
    if (r == 0) break;
    if (inflight.empty() || inflight.front().first != c.head) { mismatches++; errors++; continue; }
    Op op = inflight.front().second;
    inflight.erase(inflight.begin());
    uint64_t t0 = t_submit.front(); t_submit.erase(t_submit.begin());
    uint64_t lat = s->cycle() - t0; lat_sum += lat; if (lat > lat_max) lat_max = lat;
    if (c.status != VIRTIO_BLK_S_OK) { errors++; continue; }
    if (op.kind == 0) {
      uint32_t o = 0;
      for (auto &sg : op.sg) {
        std::vector<uint8_t> got(sg.len);
        s->mem_rd(sg.addr, got.data(), sg.len);
        if (memcmp(got.data(), &(*model)[(g.ext_base + op.sec) * 512 + o], sg.len) != 0) mismatches++;
        o += sg.len;
      }
    } else if (op.kind == 1) {
      memcpy(&(*model)[(g.ext_base + op.sec) * 512], op.data.data(), op.data.size());
    }
    done++; n++;
  }
  return n;
}

bool pump(Sim &s, std::vector<Worker *> ws, uint64_t max_cycles) {
  for (uint64_t c = 0; c < max_cycles; c += 4) {
    bool busy = false;
    for (auto *w : ws) { w->poll(); busy |= w->pending() != 0; }
    if (!busy) return true;
    s.tick(4);
  }
  return false;
}

// ---- virtio-net fixtures ------------------------------------------------------------------------------------------------------
std::vector<uint8_t> make_frame(size_t len, uint64_t seed) {
  std::vector<uint8_t> f(len);
  fill_pattern(f, seed);
  if (len >= 14) { f[12] = 0x08; f[13] = 0x00; }
  return f;
}
int NetEp::open(Sim &sim, const Guest &gg, uint16_t rxq, uint16_t txq) {
  s = &sim; g = gg;
  vf_hv_set_mac(s->mg(), g.ctx, mac);
  return vf_net_open(&n, s->tr(g.ctx), rxq, txq);
}
uint64_t NetEp::post_rx(uint32_t len, void *cookie) {
  uint64_t b;
  if (s->alloc(g.ctx, len, 8, &b)) return 0;
  std::vector<uint8_t> junk(len, 0xee);
  s->mem_wr(b, junk.data(), len);                       // poison: anything the device does not write stays 0xee
  uint16_t h;
  if (vf_net_post_rx(&n, b, len, cookie, &h) != VF_OK) return 0;
  rxbuf.push_back(b);
  return b;
}
int NetEp::send(const std::vector<uint8_t> &f, unsigned misalign, uint32_t budget) {
  uint64_t b;
  if (s->alloc(g.ctx, f.size() + 16, 8, &b)) return VF_E_NOMEM;
  b += misalign;
  s->mem_wr(b, f.data(), f.size());
  uint16_t h;
  int r = vf_net_send(&n, b, (uint32_t)f.size(), nullptr, &h);
  if (r) return r;
  vf_vq_kick(&n.txq);
  vf_net_completion_t c;
  for (uint32_t i = 0; i < budget; i += 4) {
    int p = vf_net_poll_tx(&n, &c);
    if (p < 0) return p;
    if (p == 1) return VF_OK;
    s->tick(4);
  }
  return VF_E_TIMEOUT;
}
