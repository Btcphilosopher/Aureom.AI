// tests_iso.cpp -- tier 2: isolation between guest contexts (three block guests; runs only after tier 1 passes)
#include "vf_test.h"

static Sim::Cfg cfg3() { Sim::Cfg c; c.nctx = VF_NCTX; return c; }
static bool blk3() { return VF_NCTX >= 3 && VF_KIND == 0; }

// provision guests 0..n-1 (distinct domains, regions, Citadel entries, storage extents)
static std::vector<Guest> provision(Sim &s, int n) {
  std::vector<Guest> g;
  for (int k = 0; k < n; k++) g.push_back(setup_guest(s, k));
  return g;
}
static bool region_untouched(Sim &s, const Guest &g, const std::vector<uint8_t> &snap) { return mem_snapshot(s, g.base, snap.size()) == snap; }

// ------------------------------------------------------------------------------------------------------
// a hostile guest cannot reach another guest's memory, whatever structure it forges
// ------------------------------------------------------------------------------------------------------
VF_TEST(iso_memory, "t2", false, blk3) {
  Sim s(cfg3());
  auto g = provision(s, 3);
  s.bdg_log_on = true;
  // victim memory: guests 1 and 2 hold secrets and canaries
  std::vector<uint8_t> secret(0x4000);
  fill_pattern(secret, 4242);
  s.mem_wr(g[1].base + 0x20000, secret.data(), secret.size());
  s.mem_wr(g[2].base + 0x20000, secret.data(), secret.size());
  std::vector<uint8_t> snap1 = mem_snapshot(s, g[1].base, 0x40000), snap2 = mem_snapshot(s, g[2].base, 0x40000);
  std::vector<uint8_t> stor0 = s.stor_cur();
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g[0], &b, QS), VF_OK);
  uint8_t st;
  uint64_t victim = g[1].base + 0x20000;
  // (1) read the victim's memory into the attacker's storage (OUT payload from foreign memory)
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 3, victim, 512, &st), VF_E_IO);
  // (2) write into the victim's memory (IN payload into foreign memory): fatal for the attacker, nothing written
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 3, victim, 512, &st), VF_E_NEEDS_RESET);
  CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), VF_FC_WRITABLE_PERM);
  vf_hv_clear_faults(s.mg(), 0);
  // (3) the attacker's descriptor table / available ring / used ring placed inside victim memory
  for (int which = 0; which < 3; which++) {
    vf_dev_t d; ManualQ q; q.size = 8;
    uint64_t own = g[0].base + 0x1000 + 0x1000 * which;
    q.desc = own; q.avail = own + 0x400; q.used = own + 0x800;
    if (which == 0) q.desc = g[2].base + 0x20000;          // descriptor table in the victim: fetches would leak its contents
    if (which == 1) q.avail = g[2].base + 0x20400;         // available ring in the victim
    if (which == 2) q.used = g[2].base + 0x20800;          // used ring in the victim: completions would overwrite its memory
    CHECK_EQ(t, manual_init(s, 0, &d, &q), VF_OK);
    ReqMem r = alloc_req(s, 0);
    write_hdr(s, r.hdr, VIRTIO_BLK_T_FLUSH, 0);
    if (which == 0) {                                      // the attacker's own avail ring announces head 0; the descriptor table is the victim's
      put_u16(s, q.avail + 4, 0); put_u16(s, q.avail + 2, 1); q.vq.avail_idx = 1;
    } else if (which == 2) {                               // a normal chain in the attacker's memory, only the used ring is foreign
      raw_chain(s, q.vq, 0, {{r.hdr, 16, false}, {r.status, 1, true}});
    } else {
      q.vq.avail_idx = 1;                                  // the avail ring itself is foreign: reading avail.idx is already refused
    }
    vf_vq_kick(&q.vq);
    CHECK(t, wait_needs_reset(s, 0));
    CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), VF_FC_RING_DMA);
    vf_hv_fault_t ft; vf_hv_read_fault(s.mg(), 0, &ft);
    CHECK(t, ft.valid); CHECK_EQ(t, ft.src, VF_FS_GATE);   // refused by the attacker's own window gate: nothing left the context
    vf_hv_clear_faults(s.mg(), 0);
  }
  // nothing of the victims changed, the Bridge never saw a beat for them, the escape monitor is silent
  CHECK(t, mem_snapshot(s, g[1].base, 0x40000) == snap1);
  CHECK(t, mem_snapshot(s, g[2].base, 0x40000) == snap2);
  bool leaked = false;
  for (auto &q : s.bdg_log()) if (q.dom == g[0].dom && ((q.addr >= g[1].base && q.addr < g[1].base + g[1].size) || (q.addr >= g[2].base && q.addr < g[2].base + g[2].size))) leaked = true;
  CHECK(t, !leaked);
  for (int k = 1; k < 3; k++) CHECK_EQ(t, s.bdg_reqs_dom(g[k].dom), 0);       // guests 1 and 2 were idle: no beat was issued on their behalf
  CHECK_EQ(t, vf_hv_perf32(s.mg(), 1, VF_P_VIOL), 0);
  CHECK_EQ(t, vf_hv_perf32(s.mg(), 2, VF_P_VIOL), 0);
  CHECK(t, s.stor_cur() == stor0);                                              // the attacker's storage did not change either
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// a hostile guest cannot reach another guest's storage extent
// ------------------------------------------------------------------------------------------------------
VF_TEST(iso_storage, "t2", false, blk3) {
  Sim s(cfg3());
  auto g = provision(s, 3);
  std::vector<uint8_t> stor0 = s.stor_cur();
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g[0], &b, QS), VF_OK);
  uint64_t buf; s.alloc(0, 4096, 8, &buf);
  std::vector<uint8_t> zero(2048, 0);
  uint8_t st;
  // every sector number that belongs to another guest's extent, and the usual overflow attempts
  const uint64_t secs[] = {SECTORS, SECTORS + 1, 2 * SECTORS, 2 * SECTORS - 1, 3 * SECTORS, 0x100000000ull, 0xffffffffffffffffull, 0x8000000000000000ull, (uint64_t)-1 + 1 - 512, SECTORS - 1};
  for (uint64_t sec : secs) {
    s.mem_wr(buf, zero.data(), 2048);
    int rr = vf_blk_rw_sync(&b, 0, sec, buf, 1024, &st);                         // IN: attempt to read foreign sectors
    CHECK_EQ(t, rr, VF_E_IO);
    CHECK(t, mem_snapshot(s, buf, 2048) == zero);                                // nothing leaked into the attacker's buffer
    std::vector<uint8_t> pat(1024, 0x99); s.mem_wr(buf, pat.data(), 1024);
    rr = vf_blk_rw_sync(&b, 1, sec, buf, 1024, &st);                             // OUT: attempt to overwrite foreign sectors
    CHECK_EQ(t, rr, VF_E_IO);
  }
  CHECK(t, s.stor_cur() == stor0);                                               // the shared storage did not change at all
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  // the hypervisor widens the extent by mistake past the storage's end: every request fails closed
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// a guest in trouble does not disturb the others
// ------------------------------------------------------------------------------------------------------
VF_TEST(iso_fault_containment, "t2", false, blk3) {
  Sim s(cfg3());
  s.k.bdg_lat_max = 3; s.k.st_lat_max = 3; s.k.bdg_bp = 15;
  auto g = provision(s, 3);
  std::vector<uint8_t> model = s.stor_cur();
  Worker w1, w2;
  CHECK_EQ(t, w1.open(s, g[1], &model, 11, QS), VF_OK);
  CHECK_EQ(t, w2.open(s, g[2], &model, 22, QS), VF_OK);
  vf_blk_t bad;
  CHECK_EQ(t, open_blk(s, g[0], &bad, QS), VF_OK);
  uint64_t ba;
  s.alloc(0, 4096, 8, &ba);
  // the attacker causes every kind of failure, repeatedly, while the others run continuous traffic
  int rounds = 0;
  const unsigned fault_kinds = 6;
  for (unsigned round = 0; round < 12; round++) {
    for (int k = 0; k < 6; k++) { w1.submit_one(); w2.submit_one(); }
    w1.kick(); w2.kick();
    ReqMem r = alloc_req(s, 0);
    write_hdr(s, r.hdr, VIRTIO_BLK_T_IN, 1);
    vf_vq_t &vq = bad.vq;
    uint16_t first = (uint16_t)((round % 2) * 4);
    switch (round % fault_kinds) {
      case 0: put_desc(s, vq, first, {r.hdr, 16, VIRTQ_DESC_F_NEXT, first}); raw_publish(s, vq, first); break;                       // loop
      case 1: put_desc(s, vq, first, {r.hdr, 16, VIRTQ_DESC_F_INDIRECT, 0}); raw_publish(s, vq, first); break;                      // flags
      case 2: put_desc(s, vq, first, {r.hdr, 16, VIRTQ_DESC_F_NEXT, (uint16_t)(first + 1)});
              put_desc(s, vq, (uint16_t)(first + 1), {g[1].base + 0x20000, 512, VIRTQ_DESC_F_WRITE, 0}); raw_publish(s, vq, first); break;   // write into a neighbour
      case 3: put_desc(s, vq, first, {r.hdr, 16, 0, 0}); raw_publish(s, vq, first); break;                                         // no status
      case 4: put_desc(s, vq, first, {r.hdr, 16, VIRTQ_DESC_F_NEXT, (uint16_t)(first + 1)});
              put_desc(s, vq, (uint16_t)(first + 1), {r.hdr, 16, VIRTQ_DESC_F_NEXT, (uint16_t)(first + 2)});
              put_desc(s, vq, (uint16_t)(first + 2), {r.status, 1, VIRTQ_DESC_F_WRITE | VIRTQ_DESC_F_NEXT, (uint16_t)(first + 3)});
              put_desc(s, vq, (uint16_t)(first + 3), {r.hdr, 16, VIRTQ_DESC_F_NEXT, 0}); raw_publish(s, vq, first); break;           // order
      default: put_u16(s, vq.avail_iova + 2, (uint16_t)(vq.size + 5)); break;                                                       // avail jump
    }
    vf_vq_kick(&vq);
    CHECK(t, wait_needs_reset(s, 0));
    // the neighbours continue and finish correctly
    CHECK(t, pump(s, {&w1, &w2}));
    CHECK_EQ(t, w1.pending(), 0); CHECK_EQ(t, w2.pending(), 0);
    CHECK(t, !(s.mmio_rd(1, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_DEVICE_NEEDS_RESET));
    CHECK(t, !(s.mmio_rd(2, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_DEVICE_NEEDS_RESET));
    // the attacker's device is reset (by itself) and comes back
    vf_blk_close(&bad);
    CHECK_EQ(t, open_blk(s, g[0], &bad, QS), VF_OK);
    rounds++;
  }
  CHECK_EQ(t, rounds, 12);
  CHECK_EQ(t, w1.mismatches, 0); CHECK_EQ(t, w2.mismatches, 0);
  CHECK_EQ(t, w1.errors, 0); CHECK_EQ(t, w2.errors, 0);
  CHECK(t, w1.done >= 36 && w2.done >= 36);
  // the failures are accounted to the attacker only
  CHECK(t, vf_hv_perf32(s.mg(), 0, VF_P_FATAL) >= 12);
  for (int k = 1; k < 3; k++) {
    CHECK_EQ(t, vf_hv_perf32(s.mg(), k, VF_P_FATAL), 0);
    CHECK_EQ(t, vf_hv_perf32(s.mg(), k, VF_P_VIOL), 0);
    CHECK_EQ(t, vf_hv_perf32(s.mg(), k, VF_P_INVALID), 0);
    vf_hv_fault_t f; vf_hv_read_fault(s.mg(), k, &f); CHECK(t, !f.valid);
  }
  // wait for the storage to settle, then compare the storage with the model
  s.tick(2000);
  CHECK(t, s.stor_cur() == model);
  CHECK_MON(t, s);
}

VF_TEST(iso_reset_containment, "t2", false, blk3) {
  for (int variant = 0; variant < 2; variant++) {
    Sim s(cfg3());
    s.k.bdg_lat_max = 4; s.k.st_lat_max = 4;
    auto g = provision(s, 3);
    std::vector<uint8_t> model = s.stor_cur();
    Worker w0, w1, w2;
    CHECK_EQ(t, w0.open(s, g[0], &model, 1, QS), VF_OK);
    CHECK_EQ(t, w1.open(s, g[1], &model, 2, QS), VF_OK);
    CHECK_EQ(t, w2.open(s, g[2], &model, 3, QS), VF_OK);
    for (int k = 0; k < 5; k++) { w0.submit_one(); w1.submit_one(); w2.submit_one(); }
    w0.kick(); w1.kick(); w2.kick();
    s.tick(35 + 20 * variant);
    if (variant == 0) s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);                       // guest 0 resets its device mid-flight
    else CHECK_EQ(t, vf_hv_host_reset(s.mg(), 0, 200000), VF_OK);                // hypervisor resets context 0
    uint64_t d0 = s.bdg_reqs_dom(g[0].dom);
    CHECK(t, pump(s, {&w1, &w2}));
    CHECK_EQ(t, w1.pending(), 0); CHECK_EQ(t, w2.pending(), 0);
    CHECK_EQ(t, s.bdg_reqs_dom(g[0].dom), d0);                                   // no DMA on behalf of the reset context
    CHECK_EQ(t, w1.mismatches + w2.mismatches, 0);
    CHECK_EQ(t, w1.errors + w2.errors, 0);
    // the reset guest's partial writes may have reached its own extent: re-sync the model for it
    s.tick(500);
    model = s.stor_cur();
    CHECK_MON(t, s);
  }
}

// ------------------------------------------------------------------------------------------------------
// fairness, bounded interference, per-domain accounting
// ------------------------------------------------------------------------------------------------------
static uint64_t run_workers(Sim &s, std::vector<Worker *> &w, unsigned per_worker, unsigned depth) {
  uint64_t t0 = s.cycle();
  std::vector<unsigned> issued(w.size(), 0);
  for (uint64_t i = 0; i < 4000000; i++) {
    bool all = true;
    for (size_t k = 0; k < w.size(); k++) {
      w[k]->poll();
      bool added = false;
      while (issued[k] < per_worker && w[k]->pending() < depth && w[k]->submit_one()) { issued[k]++; added = true; }
      if (added) w[k]->kick();
      if (issued[k] < per_worker || w[k]->pending()) all = false;
    }
    if (all) break;
    s.tick(2);
  }
  return s.cycle() - t0;
}

VF_TEST(multi_fairness, "t2", false, blk3) {
  // the same workload alone and with two noisy neighbours: everyone finishes, correctness holds, interference is bounded
  uint64_t alone_lat = 0;
  for (int variant = 0; variant < 2; variant++) {
    Sim s(cfg3());
    s.k.bdg_lat_max = 2; s.k.st_lat_max = 2;
    auto g = provision(s, 3);
    std::vector<uint8_t> model = s.stor_cur();
    Worker w0, w1, w2;
    CHECK_EQ(t, w0.open(s, g[0], &model, 5, QS), VF_OK);
    CHECK_EQ(t, w1.open(s, g[1], &model, 6, QS), VF_OK);
    CHECK_EQ(t, w2.open(s, g[2], &model, 7, QS), VF_OK);
    std::vector<Worker *> ws = {&w0};
    if (variant) { ws.push_back(&w1); ws.push_back(&w2); }
    run_workers(s, ws, 30, 3);
    for (auto *w : ws) { CHECK_EQ(t, w->done, 30); CHECK_EQ(t, w->mismatches, 0); CHECK_EQ(t, w->errors, 0); }
    uint64_t avg0 = w0.lat_sum / (w0.done ? w0.done : 1);
    if (!variant) alone_lat = avg0;
    else {
      printf("(latency alone %llu, with 2 neighbours %llu cycles) ", (unsigned long long)alone_lat, (unsigned long long)avg0);
      CHECK(t, avg0 < 5 * alone_lat + 50);                                  // round-robin bound: three clients, one beat outstanding
      // nobody starved: all three finished within a factor of the slowest
      uint64_t mx = std::max(w0.lat_max, std::max(w1.lat_max, w2.lat_max));
      CHECK(t, mx < 40 * alone_lat + 2000);
    }
    CHECK_MON(t, s);
  }
}

VF_TEST(multi_per_domain_counters, "t2", false, blk3) {
  Sim s(cfg3());
  s.bdg_log_on = true;
  s.k.bdg_bp = 20; s.k.bdg_lat_max = 3; s.k.st_lat_max = 3;
  auto g = provision(s, 3);
  std::vector<uint8_t> model = s.stor_cur();
  Worker w0, w1, w2;
  CHECK_EQ(t, w0.open(s, g[0], &model, 31, QS), VF_OK);
  CHECK_EQ(t, w1.open(s, g[1], &model, 32, QS), VF_OK);
  CHECK_EQ(t, w2.open(s, g[2], &model, 33, QS), VF_OK);
  std::vector<Worker *> ws = {&w0, &w1, &w2};
  run_workers(s, ws, 20, 3);
  wait_idle(s, 0); wait_idle(s, 1); wait_idle(s, 2);
  uint64_t rd[3] = {}, wr[3] = {}, n[3] = {};
  for (auto &r : s.bdg_log()) {
    for (int k = 0; k < 3; k++) if (r.dom == g[k].dom) { n[k]++; (r.op == VF_ALB_OP_READ ? rd[k] : wr[k]) += __builtin_popcount(r.wstrb); }
  }
  for (int k = 0; k < 3; k++) {
    
    CHECK_EQ(t, vf_hv_bridge64(s.mg(), k, VF_B_RD_BYTES), rd[k]);          // per-domain DMA bytes: bridge counter == independent count
    CHECK_EQ(t, vf_hv_bridge64(s.mg(), k, VF_B_WR_BYTES), wr[k]);
    CHECK_EQ(t, vf_hv_bridge32(s.mg(), k, VF_B_REQS), n[k]);
    CHECK_EQ(t, vf_hv_perf64(s.mg(), k, VF_P_RD_BYTES), rd[k]);            // and == the context's own counter
    CHECK_EQ(t, vf_hv_perf64(s.mg(), k, VF_P_WR_BYTES), wr[k]);
    CHECK_EQ(t, vf_hv_perf32(s.mg(), k, VF_P_REQ), 20);
  }
  CHECK_MON(t, s);
}

VF_TEST(multi_irq_independence, "t2", false, blk3) {
  Sim s(cfg3());
  auto g = provision(s, 3);
  vf_blk_t b0, b1, b2;
  CHECK_EQ(t, open_blk(s, g[0], &b0, QS), VF_OK);
  CHECK_EQ(t, open_blk(s, g[1], &b1, QS), VF_OK);
  CHECK_EQ(t, open_blk(s, g[2], &b2, QS), VF_OK);
  uint64_t buf; s.alloc(1, 2048, 8, &buf);
  uint16_t h; vf_sg_t sg = {buf, 512, 1};
  CHECK_EQ(t, vf_blk_submit(&b1, VIRTIO_BLK_T_IN, 1, &sg, 1, nullptr, &h), VF_OK);
  vf_vq_kick(&b1.vq);
  CHECK(t, run_until(s, [&] { return s.irq(1); }, 100000));
  s.tick(200);
  CHECK(t, s.irq(1));
  CHECK(t, !s.irq(0));                                                     // only the owner of the completion is interrupted
  CHECK(t, !s.irq(2));
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_INTERRUPT_STATUS), 0);
  CHECK_EQ(t, s.mmio_rd(2, VIRTIO_MMIO_INTERRUPT_STATUS), 0);
  CHECK_MON(t, s);
}

VF_TEST(multi_storage_integrity, "t2", false, blk3) {
  // three guests hammer the shared storage port; every guest reads back exactly what it wrote, nobody else's data
  Sim s(cfg3());
  s.k.st_lat_max = 4; s.k.st_bp = 30; s.k.bdg_bp = 10;
  auto g = provision(s, 3);
  std::vector<uint8_t> model = s.stor_cur();
  Worker w0, w1, w2;
  CHECK_EQ(t, w0.open(s, g[0], &model, 41, QS), VF_OK);
  CHECK_EQ(t, w1.open(s, g[1], &model, 42, QS), VF_OK);
  CHECK_EQ(t, w2.open(s, g[2], &model, 43, QS), VF_OK);
  std::vector<Worker *> ws = {&w0, &w1, &w2};
  run_workers(s, ws, 60, 3);
  for (auto *w : ws) { CHECK_EQ(t, w->done, 60); CHECK_EQ(t, w->mismatches, 0); CHECK_EQ(t, w->errors, 0); }
  s.tick(1000);
  CHECK(t, s.stor_cur() == model);
  CHECK_MON(t, s);
}

VF_TEST(multi_chip_reset, "t2", false, blk3) {
  Sim s(cfg3());
  auto g = provision(s, 3);
  vf_blk_t b0;
  CHECK_EQ(t, open_blk(s, g[0], &b0, QS), VF_OK);
  s.chip_reset();
  for (int k = 0; k < 3; k++) CHECK_EQ(t, s.mgmt_rd(VF_MGMT_PAGE(k) | VF_M_DOMAIN), 0);       // default deny after power-on
  for (int k = 0; k < 3; k++) CHECK_EQ(t, s.mmio_rd(k, VIRTIO_MMIO_STATUS), 0);
  CHECK_MON(t, s);
}
