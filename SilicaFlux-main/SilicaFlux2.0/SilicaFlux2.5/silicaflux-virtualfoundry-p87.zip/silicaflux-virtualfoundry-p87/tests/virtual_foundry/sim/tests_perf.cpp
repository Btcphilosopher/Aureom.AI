// tests_perf.cpp -- performance characterisation (cycle counts from the RTL simulation; no frequency is implied)
//   make perf          -> prints the table, also written to $VF_PERF_OUT when set
#include <cstdarg>
#include <cstdlib>

#include "vf_test.h"

static Sim::Cfg cfgp() { Sim::Cfg c; c.nctx = VF_NCTX; return c; }
static bool perf_ok() { return VF_NCTX >= 3 && !kind_net(0) && !kind_net(1); }

static FILE *out() { static FILE *f = getenv("VF_PERF_OUT") ? fopen(getenv("VF_PERF_OUT"), "w") : nullptr; return f; }
static void emit(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void emit(const char *fmt, ...) {
  char b[512]; va_list ap; va_start(ap, fmt); vsnprintf(b, sizeof b, fmt, ap); va_end(ap);
  fputs(b, stdout); if (out()) fputs(b, out());
}

// time `n` back-to-back synchronous requests of one kind; returns cycles per request
static double time_reqs(Sim &s, vf_blk_t &b, int write, uint32_t bytes, int n, uint64_t buf) {
  uint8_t st;
  uint64_t c0 = s.cycle();
  for (int i = 0; i < n; i++) vf_blk_rw_sync(&b, write, (uint64_t)(i * 8) % 256, buf, bytes, &st);
  return (double)(s.cycle() - c0) / n;
}

VF_TEST(perf_sweep, "perf", false, perf_ok) {
  emit("# VirtualFoundry performance sweep (simulation cycles; 1 beat = 8 bytes; bridge and storage latency in cycles)\n\n");
  // 1. throughput versus request size, aligned, minimum latency
  emit("## 1. single guest, one request at a time, latency 1/1\n");
  emit("| request | cycles/request | bytes/cycle |\n|---|---|---|\n");
  {
    Sim s(cfgp()); Guest g = setup_guest(s, 0); vf_blk_t b; open_blk(s, g, &b, QS);
    uint64_t buf; s.alloc(0, 1 << 17, 4096, &buf);
    for (uint32_t bytes : {512u, 4096u, 16384u}) for (int w = 0; w < 2; w++) {
      double c = time_reqs(s, b, w, bytes, 6, buf);
      emit("| %s %u B | %.0f | %.3f |\n", w ? "OUT" : "IN", bytes, c, bytes / c);
    }
    uint8_t st; uint64_t c0 = s.cycle();
    for (int i = 0; i < 50; i++) vf_blk_flush_sync(&b, &st);
    emit("| FLUSH (no data) | %.0f | - |\n", (double)(s.cycle() - c0) / 50);
  }
  // 2. alignment
  emit("\n## 2. alignment of the guest buffer (IN 4096 B)\n| buffer offset | cycles/request | bytes/cycle |\n|---|---|---|\n");
  for (unsigned off : {0u, 1u, 3u, 7u}) {
    Sim s(cfgp()); Guest g = setup_guest(s, 0); vf_blk_t b; open_blk(s, g, &b, QS);
    uint64_t buf; s.alloc(0, 1 << 17, 4096, &buf);
    double c = time_reqs(s, b, 0, 4096, 6, buf + off);
    emit("| +%u | %.0f | %.3f |\n", off, c, 4096 / c);
  }
  // 3. latency sensitivity
  emit("\n## 3. latency of the BridgeEngine (storage latency 1), IN 4096 B\n| bridge latency | cycles/request | bytes/cycle |\n|---|---|---|\n");
  for (int lat : {1, 4, 16, 64}) {
    Sim s(cfgp()); s.k.bdg_lat_min = s.k.bdg_lat_max = lat; Guest g = setup_guest(s, 0); vf_blk_t b; open_blk(s, g, &b, QS);
    uint64_t buf; s.alloc(0, 1 << 17, 4096, &buf);
    double c = time_reqs(s, b, 0, 4096, 4, buf);
    emit("| %d | %.0f | %.3f |\n", lat, c, 4096 / c);
  }
  // 4. several guests share one BridgeEngine port and one StorageCore port
  emit("\n## 4. aggregate throughput of N guests streaming IN 4096 B (queue depth 2 each)\n| guests | cycles for 12 requests each | aggregate bytes/cycle | per-guest bytes/cycle |\n|---|---|---|---|\n");
  for (int ng = 1; ng <= 3; ng++) {
    Sim s(cfgp());
    std::vector<Guest> gs; for (int k = 0; k < ng; k++) gs.push_back(setup_guest(s, k));
    std::vector<uint8_t> model = s.stor_cur();
    std::vector<Worker> w(ng); std::vector<Worker *> ws;
    for (int k = 0; k < ng; k++) { w[k].open(s, gs[k], &model, 10 + k, QS); ws.push_back(&w[k]); }
    // IN-only traffic: reuse the library directly
    std::vector<uint64_t> bufs(ng); for (int k = 0; k < ng; k++) s.alloc(k, 1 << 17, 4096, &bufs[k]);
    uint64_t c0 = s.cycle();
    std::vector<int> issued(ng, 0), done(ng, 0);
    for (uint64_t c = 0; c < 8000000; c += 4) {
      bool all = true;
      for (int k = 0; k < ng; k++) {
        vf_blk_completion_t cc;
        while (vf_blk_poll(&w[k].b, &cc) == 1) done[k]++;
        while (issued[k] < 12 && issued[k] - done[k] < 2) {
          vf_sg_t sg = {bufs[k] + 4096ull * (issued[k] % 8), 4096, 1}; uint16_t h;
          if (vf_blk_submit(&w[k].b, VIRTIO_BLK_T_IN, 8ull * issued[k], &sg, 1, nullptr, &h) != VF_OK) break;
          vf_vq_kick(&w[k].b.vq); issued[k]++;
        }
        if (done[k] < 12) all = false;
      }
      if (all) break;
      s.tick(4);
    }
    double cyc = (double)(s.cycle() - c0), bytes = 12.0 * 4096 * ng;
    emit("| %d | %.0f | %.3f | %.3f |\n", ng, cyc, bytes / cyc, bytes / cyc / ng);
  }
  // 5. what the counters report for a mixed workload (the measurements the brief asks for)
  emit("\n## 5. counters after a mixed random workload (guest 0, back-pressure 30%%, latency up to 6)\n");
  {
    Sim s(cfgp()); s.k.bdg_bp = 30; s.k.bdg_lat_max = 6; s.k.st_bp = 30; s.k.st_lat_max = 6;
    Guest g = setup_guest(s, 0); std::vector<uint8_t> model = s.stor_cur();
    Worker w; w.open(s, g, &model, 4, QS);
    for (int i = 0; i < 40; i++) { while (!w.submit_one()) { w.kick(); s.tick(50); w.poll(); } w.kick(); for (int j = 0; j < 30; j++) { s.tick(10); w.poll(); } }
    pump(s, {&w}); wait_idle(s, 0);
    auto m = s.mg();
    uint32_t req = vf_hv_perf32(m, 0, VF_P_REQ);
    emit("| counter | value |\n|---|---|\n");
    emit("| descriptors processed | %u |\n| requests completed | %u |\n", vf_hv_perf32(m, 0, VF_P_DESC), req);
    emit("| DMA bytes read / written | %llu / %llu |\n", (unsigned long long)vf_hv_perf64(m, 0, VF_P_RD_BYTES), (unsigned long long)vf_hv_perf64(m, 0, VF_P_WR_BYTES));
    emit("| completion latency avg / max (cycles) | %.0f / %u |\n", (double)vf_hv_perf64(m, 0, VF_P_CLAT_SUM) / req, vf_hv_perf32(m, 0, VF_P_CLAT_MAX));
    emit("| queue waiting time avg / max (cycles) | %.0f / %u |\n", (double)vf_hv_perf64(m, 0, VF_P_QW_SUM) / (vf_hv_perf32(m, 0, VF_P_QW_N) ? vf_hv_perf32(m, 0, VF_P_QW_N) : 1), vf_hv_perf32(m, 0, VF_P_QW_MAX));
    emit("| descriptor-walk time avg / max (cycles) | %.0f / %u |\n", (double)vf_hv_perf64(m, 0, VF_P_WLAT_SUM) / req, vf_hv_perf32(m, 0, VF_P_WLAT_MAX));
    emit("| avail-ring depth at head fetch avg / max | %.2f / %u |\n", (double)vf_hv_perf64(m, 0, VF_P_QD_SUM) / (vf_hv_perf32(m, 0, VF_P_QD_N) ? vf_hv_perf32(m, 0, VF_P_QD_N) : 1), vf_hv_perf32(m, 0, VF_P_QD_MAX));
    emit("| interrupts raised / suppressed | %u / %u |\n", vf_hv_perf32(m, 0, VF_P_IRQ), vf_hv_perf32(m, 0, VF_P_IRQ_SUP));
    emit("| cycles with a request back-pressured (stall) | %u |\n| cycles waiting for a backend response | %llu |\n", vf_hv_perf32(m, 0, VF_P_STALL), (unsigned long long)vf_hv_perf64(m, 0, VF_P_BEWAIT));
    emit("| busy cycles / total cycles | %llu / %llu |\n", (unsigned long long)vf_hv_perf64(m, 0, VF_P_BUSY), (unsigned long long)vf_hv_perf64(m, 0, VF_P_TOTAL));
    emit("| invalid requests | %u |\n| bridge: requests, avg / max latency | %u, %.1f / %u |\n", vf_hv_perf32(m, 0, VF_P_INVALID), vf_hv_bridge32(m, 0, VF_B_REQS),
         (double)vf_hv_bridge64(m, 0, VF_B_LAT_SUM) / (vf_hv_bridge32(m, 0, VF_B_REQS) ? vf_hv_bridge32(m, 0, VF_B_REQS) : 1), vf_hv_bridge32(m, 0, VF_B_LAT_MAX));
  }
  CHECK(t, true);
  if (out()) fflush(out());
}
