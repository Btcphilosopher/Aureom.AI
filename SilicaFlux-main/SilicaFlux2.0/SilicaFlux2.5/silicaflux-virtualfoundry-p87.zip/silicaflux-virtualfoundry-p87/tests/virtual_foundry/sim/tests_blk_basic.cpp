// tests_blk_basic.cpp -- tier 1: one guest, one split virtqueue, simulated block backend
#include "vf_test.h"

static Sim::Cfg cfg1() { Sim::Cfg c; c.nctx = VF_NCTX; return c; }
static bool is_blk0() { return (VF_KIND & 1) == 0; }

VF_TEST(identity, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_MAGIC_VALUE), VIRTIO_MMIO_MAGIC);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_VERSION), 2);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_DEVICE_ID), VIRTIO_ID_BLOCK);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_VENDOR_ID), 0x58464c53);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_STATUS), 0);
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_CONFIG_GENERATION), 0);
  CHECK_EQ(t, s.mmio_rd(0, 0x0b0), 0xffffffffu);                        // no shared-memory regions
  vf_hv_info_t info;
  CHECK_EQ(t, vf_hv_probe_ctx(s.mg(), 0, &info), VF_OK);
  CHECK_EQ(t, info.id, 0x53465646u);
  CHECK_EQ(t, info.caps0 & 0xff, 1);                                    // one queue
  CHECK_EQ(t, (info.caps0 >> 8) & 0xff, VF_CHAIN);
  CHECK_EQ(t, (info.caps0 >> 16) & 0xff, VF_NWIN);
  CHECK(t, (info.caps0 >> 24) & 1);                                     // split ring
  CHECK(t, !((info.caps0 >> 25) & 1));                                  // no packed ring
  CHECK(t, !((info.caps0 >> 26) & 1));                                  // no indirect descriptors
  CHECK(t, !((info.caps0 >> 27) & 1));                                  // no event idx
  CHECK(t, !((info.caps0 >> 28) & 1));                                  // no virtio multiqueue
  CHECK_EQ(t, info.caps1 & 0xffff, VF_MAXQ);
  CHECK_EQ(t, info.caps1 >> 24, VIRTIO_ID_BLOCK);
  unsigned n; uint32_t nets;
  CHECK_EQ(t, vf_hv_probe_global(s.mg(), &n, &nets), VF_OK);
  CHECK_EQ(t, n, VF_NCTX);
  CHECK_EQ(t, nets, VF_KIND);
  CHECK_EQ(t, s.mgmt_rd(0x5000), 0);                                    // a page that does not exist reads as zero
  CHECK_MON(t, s);
}

VF_TEST(negotiate, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  auto feat = [&](unsigned sel) { s.mmio_wr(0, VIRTIO_MMIO_DEVICE_FEATURES_SEL, sel); return s.mmio_rd(0, VIRTIO_MMIO_DEVICE_FEATURES); };
  CHECK_EQ(t, feat(0), (1u << VIRTIO_BLK_F_SEG_MAX) | (1u << VIRTIO_BLK_F_FLUSH));
  CHECK_EQ(t, feat(1), (1u << (VIRTIO_F_VERSION_1 - 32)) | (1u << (VIRTIO_F_ACCESS_PLATFORM - 32)));
  CHECK_EQ(t, feat(2), 0);
  // a driver that accepts something the device never offered: FEATURES_OK must not stick (3.1.1 step 6)
  const unsigned unoffered_lo[] = {VIRTIO_F_INDIRECT_DESC, VIRTIO_F_EVENT_IDX, VIRTIO_BLK_F_RO};
  for (unsigned bit : unoffered_lo) {
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 0);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, 1u << bit);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 1);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, (1u << (VIRTIO_F_VERSION_1 - 32)) | (1u << (VIRTIO_F_ACCESS_PLATFORM - 32)));
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_FEATURES_OK);
    CHECK(t, !(s.mmio_rd(0, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_FEATURES_OK));
  }
  const unsigned unoffered_hi[] = {VIRTIO_F_RING_PACKED, 35 /*IN_ORDER*/, 38 /*NOTIFICATION_DATA*/, 40 /*RING_RESET*/, 37 /*SR_IOV*/};
  for (unsigned bit : unoffered_hi) {
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 0);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, 0);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 1);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, (1u << (VIRTIO_F_VERSION_1 - 32)) | (1u << (VIRTIO_F_ACCESS_PLATFORM - 32)) | (1u << (bit - 32)));
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_FEATURES_OK);
    CHECK(t, !(s.mmio_rd(0, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_FEATURES_OK));
  }
  // omitting a required feature is refused as well
  for (int omit = 0; omit < 2; omit++) {
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 1);
    s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, omit ? (1u << (VIRTIO_F_VERSION_1 - 32)) : (1u << (VIRTIO_F_ACCESS_PLATFORM - 32)));
    s.mmio_wr(0, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_FEATURES_OK);
    CHECK(t, !(s.mmio_rd(0, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_FEATURES_OK));
  }
  // features are frozen once FEATURES_OK is set
  s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
  s.mmio_wr(0, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER);
  s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 1);
  s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, (1u << (VIRTIO_F_VERSION_1 - 32)) | (1u << (VIRTIO_F_ACCESS_PLATFORM - 32)));
  s.mmio_wr(0, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_FEATURES_OK);
  CHECK(t, s.mmio_rd(0, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_FEATURES_OK);
  s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 0);
  s.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, 1u << VIRTIO_BLK_F_FLUSH);       // ignored
  // a driver that skips FLUSH: the device must then report UNSUPP for a flush request
  vf_dev_t d;
  CHECK_EQ(t, vf_dev_probe(&d, s.tr(0)), VF_OK);
  s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
  CHECK_EQ(t, vf_dev_negotiate(&d, VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM), VF_FEAT(VIRTIO_F_VERSION_1)), VF_OK);
  CHECK_EQ(t, d.drv_features, VF_FEAT(VIRTIO_F_VERSION_1) | VF_FEAT(VIRTIO_F_ACCESS_PLATFORM));
  // a read-only extent adds BLK_F_RO to the offered set, and only then
  s.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
  s.mgmt_wr(VF_MGMT_PAGE(0) | VF_M_EXT_FLAGS, 1);
  CHECK_EQ(t, feat(0), (1u << VIRTIO_BLK_F_SEG_MAX) | (1u << VIRTIO_BLK_F_FLUSH) | (1u << VIRTIO_BLK_F_RO));
  CHECK_MON(t, s);
}

VF_TEST(basic_rw, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  CHECK_EQ(t, b.capacity, SECTORS);
  CHECK_EQ(t, b.seg_max, VF_CHAIN - 2);
  CHECK(t, b.has_flush);
  CHECK(t, !b.read_only);
  uint64_t buf;
  CHECK_EQ(t, s.alloc(0, 8192, 8, &buf), 0);
  // read sector 5..8 and compare with the stored pattern
  uint8_t st = 0xee;
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 5, buf, 4 * 512, &st), VF_OK);
  CHECK_EQ(t, st, VIRTIO_BLK_S_OK);
  CHECK(t, mem_snapshot(s, buf, 2048) == std::vector<uint8_t>(shadow.begin() + (g.ext_base + 5) * 512, shadow.begin() + (g.ext_base + 9) * 512));
  // write a pattern to sectors 20..27, read it back
  std::vector<uint8_t> pat(8 * 512);
  fill_pattern(pat, 7);
  s.mem_wr(buf, pat.data(), pat.size());
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 20, buf, 8 * 512, &st), VF_OK);
  memcpy(&shadow[(g.ext_base + 20) * 512], pat.data(), pat.size());
  CHECK(t, s.stor_cur() == shadow);
  uint64_t buf2;
  CHECK_EQ(t, s.alloc(0, 8192, 8, &buf2), 0);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 20, buf2, 8 * 512, &st), VF_OK);
  CHECK(t, mem_snapshot(s, buf2, pat.size()) == pat);
  // flush, GET_ID
  CHECK_EQ(t, vf_blk_flush_sync(&b, &st), VF_OK);
  CHECK_EQ(t, s.st_flushes, 1);
  char id[VIRTIO_BLK_ID_BYTES + 1];
  CHECK_EQ(t, vf_blk_get_id_sync(&b, id), VF_OK);
  CHECK(t, strcmp(id, "SILICAFLUX-VBLK-0001") == 0);
  // last sector of the extent works, one past it is an I/O error and changes nothing
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, SECTORS - 1, buf, 512, &st), VF_OK);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, SECTORS, buf, 512, &st), VF_E_IO);
  CHECK_EQ(t, st, VIRTIO_BLK_S_IOERR);
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, SECTORS - 1, buf, 1024, &st), VF_E_IO);     // straddles the end of the extent
  CHECK(t, s.stor_cur() == shadow);
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  CHECK_MON(t, s);
  vf_blk_close(&b);
}
