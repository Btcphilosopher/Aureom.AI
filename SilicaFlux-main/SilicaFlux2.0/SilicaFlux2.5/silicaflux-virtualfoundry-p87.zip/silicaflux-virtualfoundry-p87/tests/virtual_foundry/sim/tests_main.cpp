// tests_main.cpp -- test runner of the VirtualFoundry co-simulation suite
//   vf_tests [--tier t1|t2|t3] [--only NAME] [--skip-long] [--seed N] [--iters N] [--list] [-v]
#include <cstdlib>
#include <cstring>
#include <exception>

#include "vf_test.h"
#include "verilated.h"

int main(int argc, char **argv) {
  std::string only, tier;
  bool skip_long = false, list = false, verbose = false;
  uint64_t seed = 1;
  int iters = 100;
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i];
    if (a == "--only" && i + 1 < argc) only = argv[++i];
    else if (a == "--tier" && i + 1 < argc) tier = argv[++i];
    else if (a == "--skip-long") skip_long = true;
    else if (a == "--seed" && i + 1 < argc) seed = strtoull(argv[++i], nullptr, 0);
    else if (a == "--iters" && i + 1 < argc) iters = atoi(argv[++i]);
    else if (a == "--list") list = true;
    else if (a == "-v") verbose = true;
    else { fprintf(stderr, "unknown argument %s\n", a.c_str()); return 2; }
  }
  Verilated::commandArgs(argc, argv);
  int ran = 0, passed = 0, skipped = 0;
  long long checks = 0;
  std::vector<std::string> failed;
  for (auto &d : registry()) {
    if (!only.empty() && only != d.name) continue;
    if (!tier.empty() && tier != d.tier) continue;
    if (d.applies && !d.applies()) { skipped++; continue; }
    if (skip_long && d.slow) { skipped++; continue; }
    if (list) { printf("%s %s%s\n", d.tier, d.name, d.slow ? " (slow)" : ""); continue; }
    T t;
    t.name = d.name; t.seed = seed; t.iters = iters; t.verbose = verbose;
    printf("[%s] %-34s ", d.tier, d.name);
    fflush(stdout);
    try {
      d.fn(t);
    } catch (const std::exception &e) {
      t.fails++;
      printf("\n    EXCEPTION: %s\n", e.what());
    }
    ran++;
    checks += t.checks;
    if (t.fails == 0) { passed++; printf("PASS  (%d checks)\n", t.checks); }
    else { failed.push_back(d.name); printf("FAIL  (%d of %d checks failed)\n", t.fails, t.checks); }
    fflush(stdout);
  }
  if (list) return 0;
  printf("\nSUMMARY: %d/%d tests passed, %lld checks, %d skipped\n", passed, ran, checks, skipped);
  for (auto &f : failed) printf("  FAILED: %s\n", f.c_str());
  return (ran > 0 && passed == ran) ? 0 : 1;
}
