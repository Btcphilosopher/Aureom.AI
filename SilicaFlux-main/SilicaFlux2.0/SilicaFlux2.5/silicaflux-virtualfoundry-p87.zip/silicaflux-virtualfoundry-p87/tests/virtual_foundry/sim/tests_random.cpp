// tests_random.cpp -- tier 3: constrained-random regression against an independent software model
//
// The model below is written from the documented contract (docs 01_ARCHITECTURE.md s3, the VirtIO 1.2
// text), not derived from the RTL: for every submitted request it predicts the completion status, the
// used length, the bytes the device must leave in each device-writable buffer and the effect on the
// storage.  Requests of one guest execute in order, so the "logical" storage image (state after all
// requests submitted so far) is the right reference for both the data an IN must return and the final
// storage content.  Back-pressure and latency knobs are re-rolled constantly.
#include <algorithm>
#include <deque>

#include "vf_test.h"

static Sim::Cfg cfgr() { Sim::Cfg c; c.nctx = VF_NCTX; return c; }
static bool blk_any() { for (int k = 0; k < VF_NCTX; k++) if (!kind_net(k)) return true; return false; }
static bool blk0() { return !kind_net(0); }

struct RB {
  Sim *s = nullptr;
  Guest g;
  vf_blk_t b;
  std::vector<uint8_t> *logical = nullptr;
  std::mt19937_64 rng;
  struct Exp {
    uint8_t status = 0; uint32_t used_len = 0; uint16_t head = 0;
    std::vector<vf_sg_t> sg;
    std::vector<std::vector<uint8_t>> want;       // expected bytes of each device-writable data buffer
    bool has_payload = false;
  };
  std::deque<Exp> q;
  uint64_t slot_base = 0, done = 0, bad = 0, nsub = 0, rejected = 0;
  unsigned slot = 0;
  bool ro = false;
  static constexpr unsigned NSLOT = 24, SLOTSZ = 8192;
  int open(Sim &sim, const Guest &gg, std::vector<uint8_t> *lg, uint64_t seed, bool read_only = false) {
    s = &sim; g = gg; logical = lg; rng.seed(seed); ro = read_only;
    int r = vf_blk_open(&b, s->tr(g.ctx), QS);
    if (r) return r;
    return s->alloc(g.ctx, (size_t)NSLOT * SLOTSZ, 4096, &slot_base) ? VF_E_NOMEM : VF_OK;
  }
  const uint8_t *img(uint64_t sec) const { return &(*logical)[(g.ext_base + sec) * 512]; }
  uint8_t *img_w(uint64_t sec) { return &(*logical)[(g.ext_base + sec) * 512]; }

  bool submit() {
    static const char ID[] = "SILICAFLUX-VBLK-0001";
    // 0 IN 1 OUT 2 FLUSH 3 GET_ID 4 unsupported 5 IN with readable payload (direction) 6 OUT with writable payload 7 out-of-range IN/OUT
    unsigned pick = (unsigned)(rng() % 100);
    unsigned kind = pick < 32 ? 0 : pick < 60 ? 1 : pick < 68 ? 2 : pick < 74 ? 3 : pick < 80 ? 4 : pick < 86 ? 5 : pick < 92 ? 6 : 7;
    Exp e;
    uint32_t type = VIRTIO_BLK_T_IN;
    uint64_t sector = rng() % SECTORS;
    unsigned nsec = 1 + (unsigned)(rng() % 4);
    bool payload_write = false, payload_read = false;     // device-writable / device-readable payload present
    uint32_t plen = nsec * 512;
    switch (kind) {
      case 0: type = VIRTIO_BLK_T_IN; payload_write = true; break;
      case 1: type = VIRTIO_BLK_T_OUT; payload_read = true; break;
      case 2: type = VIRTIO_BLK_T_FLUSH; plen = 0; break;
      case 3: type = VIRTIO_BLK_T_GET_ID; plen = (uint32_t)(1 + rng() % 40); payload_write = true; break;
      case 4: { const uint32_t u[] = {2, 3, 5, 6, 7, 9, 10, 11, 12, 13, 14, 99}; type = u[rng() % 12]; payload_write = rng() & 1; plen = 64; break; }
      case 5: type = VIRTIO_BLK_T_IN; payload_read = true; break;
      case 6: type = VIRTIO_BLK_T_OUT; payload_write = true; break;
      default: type = (rng() & 1) ? VIRTIO_BLK_T_IN : VIRTIO_BLK_T_OUT; payload_write = type == VIRTIO_BLK_T_IN; payload_read = !payload_write;
              sector = SECTORS - (rng() % 2) + (rng() % 3); if (sector + nsec <= SECTORS) sector = SECTORS - nsec + 1 + (rng() % 2); break;
    }
    if (kind == 4 && type == VIRTIO_BLK_T_FLUSH) type = 99;
    // segment layout: the payload split into 1..3 pieces at misaligned addresses inside this request's slot
    uint64_t sl = slot_base + (uint64_t)(slot++ % NSLOT) * SLOTSZ;
    std::vector<vf_sg_t> sgs;
    uint64_t off = (uint64_t)(rng() % 8);
    if (plen && (payload_read || payload_write)) {
      unsigned pieces = 1 + (unsigned)(rng() % 3);
      uint32_t left = plen;
      for (unsigned i = 0; i < pieces && left; i++) {
        uint32_t len = (i + 1 == pieces || left <= 1) ? left : (uint32_t)(1 + rng() % (left - 1));
        sgs.push_back({sl + off, len, (uint8_t)payload_write});
        off += len + (uint64_t)(rng() % 9);
        left -= len;
      }
    }
    if (kind == 4 && !sgs.empty() && !payload_write) for (auto &x : sgs) x.device_writable = 0;
    uint32_t r_pay = 0, w_pay = 0;
    for (auto &x : sgs) (x.device_writable ? w_pay : r_pay) += x.len;
    // payload content for readable buffers
    std::vector<uint8_t> out(r_pay);
    fill_pattern(out, rng());
    { uint32_t o = 0; for (auto &x : sgs) if (!x.device_writable) { s->mem_wr(x.addr, &out[o], x.len); o += x.len; } }
    for (auto &x : sgs) if (x.device_writable) { std::vector<uint8_t> j(x.len, 0xc3); s->mem_wr(x.addr, j.data(), x.len); }
    // ---- the model --------------------------------------------------------------------------------------
    e.used_len = w_pay + 1;
    auto range_ok = [&](uint32_t len) { return len % 512 == 0 && sector <= SECTORS && len / 512 <= SECTORS - sector; };
    std::vector<uint8_t> wbytes(w_pay, 0);           // the writable payload stream the device must produce
    bool apply = false; uint64_t apply_sector = 0; std::vector<uint8_t> apply_data;   // storage effect, applied to the model only if the request is really submitted
    if (type == VIRTIO_BLK_T_IN) {
      if (r_pay != 0 || !range_ok(w_pay)) e.status = VIRTIO_BLK_S_IOERR;
      else { e.status = VIRTIO_BLK_S_OK; memcpy(wbytes.data(), img(sector), w_pay); }
    } else if (type == VIRTIO_BLK_T_OUT) {
      if (w_pay != 0 || ro || !range_ok(r_pay)) e.status = VIRTIO_BLK_S_IOERR;
      else { e.status = VIRTIO_BLK_S_OK; apply_sector = sector; apply_data = out; apply = true; }
    } else if (type == VIRTIO_BLK_T_FLUSH) {
      e.status = (r_pay != 0) ? VIRTIO_BLK_S_IOERR : VIRTIO_BLK_S_OK;
    } else if (type == VIRTIO_BLK_T_GET_ID) {
      if (r_pay != 0) e.status = VIRTIO_BLK_S_IOERR;
      else { e.status = VIRTIO_BLK_S_OK; for (uint32_t i = 0; i < w_pay && i < 20; i++) wbytes[i] = (uint8_t)ID[i]; }
    } else {
      e.status = VIRTIO_BLK_S_UNSUPP;
    }
    { uint32_t o = 0; for (auto &x : sgs) if (x.device_writable) { e.want.push_back(std::vector<uint8_t>(wbytes.begin() + o, wbytes.begin() + o + x.len)); o += x.len; } }
    e.sg = sgs;
    uint16_t h;
    int r = vf_blk_submit(&b, type, sector, sgs.data(), (unsigned)sgs.size(), nullptr, &h);
    if (r != VF_OK) return false;                       // ring or segment limit: nothing was submitted, the model is untouched
    if (apply) memcpy(img_w(apply_sector), apply_data.data(), apply_data.size());
    e.head = h;
    q.push_back(e);
    nsub++;
    return true;
  }
  void kick() { vf_vq_kick(&b.vq); }
  void poll() {
    for (;;) {
      vf_blk_completion_t c;
      int r = vf_blk_poll(&b, &c);
      if (r <= 0) { if (r < 0) bad++; return; }
      if (q.empty() || q.front().head != c.head) { bad++; printf("    unexpected completion head %u\n", c.head); continue; }
      Exp e = q.front(); q.pop_front();
      if (c.status != e.status) { bad++; printf("    status %u expected %u\n", c.status, e.status); }
      if (c.used_len != e.used_len) { bad++; printf("    used.len %u expected %u\n", c.used_len, e.used_len); }
      size_t wi = 0;
      for (auto &x : e.sg) if (x.device_writable) {
        auto got = mem_snapshot(*s, x.addr, x.len);
        if (got != e.want[wi]) { bad++; printf("    writable buffer content mismatch (%u bytes)\n", x.len); }
        wi++;
      }
      done++;
    }
  }
};

static void roll_knobs(Sim &s, std::mt19937_64 &rng) {
  const int bps[] = {0, 0, 10, 30, 60, 85};
  s.k.bdg_bp = bps[rng() % 6]; s.k.st_bp = bps[rng() % 6];
  s.k.bdg_lat_min = 1; s.k.bdg_lat_max = 1 + (int)(rng() % 9);
  s.k.st_lat_min = 1; s.k.st_lat_max = 1 + (int)(rng() % 9);
}

// fatal chains with no side effects; returns the expected cause
static unsigned inject_fatal(Sim &s, RB &r, unsigned which) {
  ReqMem m = alloc_req(s, r.g.ctx);
  write_hdr(s, m.hdr, VIRTIO_BLK_T_IN, 1);
  uint64_t buf = r.slot_base;
  vf_vq_t &vq = r.b.vq;
  uint16_t f = 0;
  switch (which % 8) {
    case 0: put_desc(s, vq, f, {m.hdr, 16, VIRTQ_DESC_F_NEXT, f}); raw_publish(s, vq, f); return VF_FC_CHAIN_LOOP;
    case 1: put_desc(s, vq, f, {m.hdr, 16, VIRTQ_DESC_F_INDIRECT, 0}); raw_publish(s, vq, f); return VF_FC_DESC_FLAGS;
    case 2: put_desc(s, vq, f, {m.hdr, 16, VIRTQ_DESC_F_NEXT, (uint16_t)QS}); raw_publish(s, vq, f); return VF_FC_DESC_IDX_OOR;
    case 3: put_desc(s, vq, f, {m.hdr, 16, 0, 0}); raw_publish(s, vq, f); return VF_FC_NO_STATUS;
    case 4: put_desc(s, vq, f, {m.hdr, 16, VIRTQ_DESC_F_NEXT, 1}); put_desc(s, vq, 1, {CANARY_BASE + 64, 512, VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE, 2});
            put_desc(s, vq, 2, {m.status, 1, VIRTQ_DESC_F_WRITE, 0}); raw_publish(s, vq, f); return VF_FC_WRITABLE_PERM;
    case 5: put_desc(s, vq, f, {m.hdr, 16, VIRTQ_DESC_F_NEXT, 1}); put_desc(s, vq, 1, {buf, 512, VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE, 2});
            put_desc(s, vq, 2, {m.hdr, 16, VIRTQ_DESC_F_NEXT, 3}); put_desc(s, vq, 3, {m.status, 1, VIRTQ_DESC_F_WRITE, 0}); raw_publish(s, vq, f); return VF_FC_CHAIN_ORDER;
    case 6: put_u16(s, vq.avail_iova + 2, (uint16_t)(vq.avail_idx + vq.size + 3)); return VF_FC_AVAIL_IDX_JUMP;
    default: put_desc(s, vq, f, {m.hdr, 16, VIRTQ_DESC_F_NEXT, 1}); put_desc(s, vq, 1, {buf, 0x80000000u, VIRTQ_DESC_F_NEXT, 2});
             put_desc(s, vq, 2, {buf, 0x80000000u, VIRTQ_DESC_F_NEXT, 3}); put_desc(s, vq, 3, {m.status, 1, VIRTQ_DESC_F_WRITE, 0}); raw_publish(s, vq, f); return VF_FC_CHAIN_LEN_OVF;
  }
}

VF_TEST(random_blk_single, "t3", false, blk0) {
  Sim s(cfgr());
  s.rng.seed(t.seed * 7 + 1);
  std::mt19937_64 rng(t.seed * 131 + 5);
  auto gs = std::vector<Guest>{setup_guest(s, 0)};
  std::vector<uint8_t> logical = s.stor_cur();
  RB r;
  CHECK_EQ(t, r.open(s, gs[0], &logical, t.seed * 17 + 3), VF_OK);
  int fatals = 0;
  for (int it = 0; it < t.iters; it++) {
    roll_knobs(s, rng);
    unsigned burst = 1 + (unsigned)(rng() % 4);
    unsigned added = 0;
    for (unsigned i = 0; i < burst; i++) if (r.submit()) added++;
    if (added) r.kick();
    // wait for completion (verify as they arrive)
    for (uint64_t c = 0; c < 3000000 && !r.q.empty(); c += 8) { s.tick(8); r.poll(); }
    CHECK(t, r.q.empty());
    if (!r.q.empty()) break;
    if (rng() % 17 == 0) {                                  // a malformed ring / chain: must fail safely and recover
      std::vector<uint8_t> stor_before = s.stor_cur();
      canary_fill(s, CANARY_BASE, CANARY_LEN);
      unsigned want = inject_fatal(s, r, (unsigned)rng());
      r.kick();
      bool nr = wait_needs_reset(s, 0, 600000);
      CHECK(t, nr);
      CHECK_EQ(t, vf_hv_fatal_cause(s.mg(), 0), want);
      CHECK(t, s.stor_cur() == stor_before);
      CHECK(t, canary_intact(s, CANARY_BASE, CANARY_LEN));
      vf_hv_clear_faults(s.mg(), 0);
      vf_blk_close(&r.b);
      s.reset_alloc(0);
      CHECK_EQ(t, r.open(s, gs[0], &logical, t.seed * 1000 + (uint64_t)it), VF_OK);
      fatals++;
    }
  }
  s.tick(200);
  CHECK_EQ(t, r.bad, 0);
  CHECK(t, s.stor_cur() == logical);                        // the storage equals the model, byte for byte
  CHECK(t, r.done >= (uint64_t)t.iters);
  CHECK_MON(t, s);
  printf("(%llu requests, %d fatals injected) ", (unsigned long long)r.done, fatals);
}

VF_TEST(random_blk_multi, "t3", false, blk_any) {
  Sim s(cfgr());
  s.rng.seed(t.seed * 11 + 2);
  std::mt19937_64 rng(t.seed * 313 + 9);
  std::vector<Guest> gs;
  for (int k = 0; k < VF_NCTX; k++) gs.push_back(setup_guest(s, k));
  std::vector<uint8_t> logical = s.stor_cur();
  std::vector<RB> rb(VF_NCTX);
  std::vector<int> act;
  for (int k = 0; k < VF_NCTX; k++) if (!kind_net(k)) { CHECK_EQ(t, rb[k].open(s, gs[k], &logical, t.seed * 29 + (uint64_t)k * 7), VF_OK); act.push_back(k); }
  // every guest submits t.iters requests; the knobs are re-rolled all the time
  for (uint64_t cyc = 0, last_roll = 0; cyc < 40000000; cyc += 8) {
    bool all_done = true;
    for (int k : act) all_done &= rb[k].nsub >= (uint64_t)t.iters;
    if (all_done) break;
    if (cyc - last_roll > 600) { roll_knobs(s, rng); last_roll = cyc; }
    for (int k : act) {
      unsigned added = 0;
      for (unsigned i = 0; i < 2 && rb[k].q.size() < 3 && rb[k].nsub < (uint64_t)t.iters; i++) if (rb[k].submit()) added++;
      if (added) rb[k].kick();
    }
    s.tick(8);
    for (int k : act) rb[k].poll();
  }
  bool drained = run_until(s, [&] { bool e = true; for (int k : act) { rb[k].poll(); e &= rb[k].q.empty(); } return e; }, 3000000);
  CHECK(t, drained);
  s.tick(500);
  uint64_t total = 0;
  for (int k : act) { CHECK_EQ(t, rb[k].bad, 0); total += rb[k].done; CHECK_EQ(t, vf_dev_check(&rb[k].b.dev), VF_OK); }
  CHECK(t, s.stor_cur() == logical);
  CHECK_MON(t, s);
  printf("(%llu requests over %zu guests) ", (unsigned long long)total, act.size());
}

// ------------------------------------------------------------------------------------------------------
// random virtio-net traffic against a software model of the stream
// ------------------------------------------------------------------------------------------------------
static bool net_any() { return first_net() >= 0; }
static uint32_t dc(Sim &s, int ctx, unsigned i) { return vf_hv_devcnt(s.mg(), ctx, i); }

VF_TEST(random_net, "t3", false, net_any) {
  Sim s(cfgr());
  s.rng.seed(t.seed * 5 + 3);
  std::mt19937_64 rng(t.seed * 77 + 1);
  std::vector<Guest> gs;
  for (int k = 0; k < VF_NCTX; k++) gs.push_back(setup_guest(s, k));
  std::vector<int> nets;
  for (int k = 0; k < VF_NCTX; k++) if (kind_net(k)) nets.push_back(k);
  struct RxBuf { uint64_t iova; uint32_t len; };
  struct E {
    NetEp ep;
    std::vector<std::vector<uint8_t>> sent, rxsent;       // valid frames transmitted / injected
    unsigned txsub = 0, drops_expected = 0, delivered = 0, rejected = 0;
    uint64_t txbuf[2], txhdr[2];
    std::vector<RxBuf> rx;
  };
  std::vector<E> es(nets.size());
  for (size_t i = 0; i < nets.size(); i++) {
    E &e = es[i]; int k = nets[i];
    CHECK_EQ(t, e.ep.open(s, gs[k], 16, 16), VF_OK);
    // fixed pools, allocated once and re-used (the guest's rings live in the same region: nothing is ever recycled underneath them)
    for (int j = 0; j < 2; j++) { s.alloc(k, VF_FBYTES + 64, 8, &e.txbuf[j]); s.alloc(k, 16, 16, &e.txhdr[j]); }
    const uint32_t lens[] = {(uint32_t)VF_FBYTES + 64, (uint32_t)VF_FBYTES + 64, 200, (uint32_t)VF_FBYTES + 64, 120, (uint32_t)VF_FBYTES + 64};
    for (uint32_t l : lens) { uint64_t b; s.alloc(k, l, 8, &b); e.rx.push_back({b, l}); }
    for (size_t j = 0; j < e.rx.size(); j++) { uint16_t h; std::vector<uint8_t> junk(e.rx[j].len, 0xee); s.mem_wr(e.rx[j].iova, junk.data(), junk.size());
      CHECK_EQ(t, vf_net_post_rx(&e.ep.n, e.rx[j].iova, e.rx[j].len, (void *)(uintptr_t)j, &h), VF_OK); }
    e.ep.kick_rx();
  }
  for (int it = 0; it < t.iters; it++) {
    roll_knobs(s, rng);
    s.k.pf_tx_bp = (int)(rng() % 70); s.k.pf_rx_gap = (int)(rng() % 40);
    for (size_t i = 0; i < nets.size(); i++) {
      E &e = es[i]; int k = nets[i];
      // ---- transmit: a random frame split over 1..3 descriptors, occasionally with an illegal header ----
      size_t len = 14 + (size_t)(rng() % (VF_FBYTES - 13));
      if (rng() % 3 == 0) len = 14 + (size_t)(rng() % 120);
      bool bad_hdr = (rng() % 12 == 0);
      std::vector<uint8_t> f = make_frame(len, rng());
      unsigned slot = e.txsub % 2;
      s.mem_wr(e.txbuf[slot] + 3, f.data(), len);
      uint8_t hdr[12] = {0}; if (bad_hdr) hdr[1] = 1;
      s.mem_wr(e.txhdr[slot], hdr, 12);
      std::vector<Seg> segs = {{e.txhdr[slot], 12, false}};
      unsigned pieces = 1 + (unsigned)(rng() % 3); size_t o = 0;
      for (unsigned p = 0; p < pieces && o < len; p++) { size_t l = (p + 1 == pieces) ? len - o : 1 + rng() % (len - o); segs.push_back({e.txbuf[slot] + 3 + o, (uint32_t)l, false}); o += l; }
      vf_vq_t &q = e.ep.n.txq;
      uint16_t first = (uint16_t)(slot * 8);
      uint16_t want = (uint16_t)(vf_vq_device_used_idx(&q) + 1);
      raw_chain(s, q, first, segs);
      vf_vq_kick(&q);
      CHECK(t, wait_used(s, q, want, 2000000));
      e.txsub++;
      if (bad_hdr) e.drops_expected++; else e.sent.push_back(f);
      // ---- receive: one frame at a time; unusable (too small) buffers are returned unused and re-posted ----
      size_t rl = 14 + (size_t)(rng() % 900);
      auto rf = make_frame(rl, rng());
      e.rxsent.push_back(rf);
      s.pf_inject((unsigned)k, rf);
      bool got = false;
      for (uint64_t guard = 0; guard < 3000000 && !got; guard += 8) {
        s.tick(8);
        vf_net_completion_t c;
        while (vf_net_poll_rx(&e.ep.n, &c) == 1) {
          size_t j = (size_t)(uintptr_t)c.cookie;
          if (c.used_len == 0) { e.rejected++; }
          else {
            CHECK_EQ(t, c.used_len, 12 + rl);
            auto g2 = mem_snapshot(s, e.rx[j].iova, 12 + rl);
            uint8_t h0[12] = {0}; h0[10] = 1;
            CHECK(t, memcmp(g2.data(), h0, 12) == 0);
            CHECK(t, std::vector<uint8_t>(g2.begin() + 12, g2.end()) == rf);
            e.delivered++; got = true;
          }
          uint16_t h; std::vector<uint8_t> junk(e.rx[j].len, 0xee); s.mem_wr(e.rx[j].iova, junk.data(), junk.size());
          vf_net_post_rx(&e.ep.n, e.rx[j].iova, e.rx[j].len, c.cookie, &h);
          e.ep.kick_rx();
        }
      }
      CHECK(t, got);
      if (!got) break;
    }
  }
  s.tick(2000);
  // transmit side: the sink saw exactly the valid frames, per guest in order, byte-exact
  for (size_t i = 0; i < nets.size(); i++) {
    std::vector<std::vector<uint8_t>> got;
    for (auto &fr : s.pf_tx) if (fr.src == (unsigned)nets[i]) got.push_back(fr.bytes);
    CHECK_EQ(t, got.size(), es[i].sent.size());
    bool same = got.size() == es[i].sent.size();
    for (size_t j = 0; same && j < got.size(); j++) same &= got[j] == es[i].sent[j];
    CHECK(t, same);
    CHECK_EQ(t, dc(s, nets[i], VF_DC_NET_TX_DROP), es[i].drops_expected);
    CHECK_EQ(t, dc(s, nets[i], VF_DC_NET_TX_OK), es[i].sent.size());
    CHECK_EQ(t, dc(s, nets[i], VF_DC_NET_RX_OK), es[i].delivered);
    CHECK_EQ(t, dc(s, nets[i], VF_DC_NET_RX_BUF_REJ), es[i].rejected);
    CHECK_EQ(t, es[i].delivered, es[i].rxsent.size());
    CHECK_EQ(t, vf_dev_check(&es[i].ep.n.dev), VF_OK);
  }
  CHECK_MON(t, s);
  unsigned tot = 0, rej = 0; for (auto &e : es) { tot += (unsigned)e.sent.size() + e.delivered; rej += e.rejected; }
  printf("(%u frames, %u small buffers rejected and re-posted) ", tot, rej);
}
