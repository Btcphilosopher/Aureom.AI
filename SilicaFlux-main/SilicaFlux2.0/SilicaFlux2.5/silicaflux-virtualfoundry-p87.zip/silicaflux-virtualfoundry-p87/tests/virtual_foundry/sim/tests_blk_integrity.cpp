// tests_blk_integrity.cpp -- tier 1: completion integrity/visibility, storage faults and durability,
// interrupts, performance counters, back-pressure
#include "vf_test.h"

static Sim::Cfg cfg1() { Sim::Cfg c; c.nctx = VF_NCTX; return c; }
static bool is_blk0() { return (VF_KIND & 1) == 0; }

// ------------------------------------------------------------------------------------------------------
// completion visibility: the instant used.idx moves, the element, the status and the payload are final
// ------------------------------------------------------------------------------------------------------
VF_TEST(completion_visibility, "t1", false, is_blk0) {
  for (int variant = 0; variant < 3; variant++) {
    Sim s(cfg1());
    s.k.bdg_bp = variant ? 40 : 0; s.k.bdg_lat_max = variant ? 7 : 1; s.k.st_bp = variant ? 30 : 0; s.k.st_lat_max = variant ? 9 : 1;
    Guest g = setup_guest(s, 0);
    std::vector<uint8_t> shadow = s.stor_cur();
    vf_blk_t b;
    CHECK_EQ(t, open_blk(s, g, &b, 16 > VF_MAXQ ? VF_MAXQ : 16), VF_OK);
    uint64_t area; s.alloc(0, 1 << 17, 8, &area);
    struct Exp { uint16_t head; uint32_t len; uint8_t kind; uint64_t buf; uint32_t n; uint64_t sec; std::vector<uint8_t> data; };
    std::vector<Exp> exp;
    for (unsigned i = 0; i < 5; i++) {
      uint32_t nsec = 1 + i % 3;
      uint64_t buf = area + 4096ull * i, sec = 16 + 5 * i;
      uint16_t h;
      vf_sg_t sg = {buf, 512 * nsec, (uint8_t)(i % 2 == 0)};
      std::vector<uint8_t> d(512 * nsec); fill_pattern(d, 400 + i);
      if (i % 2) s.mem_wr(buf, d.data(), d.size());
      int r = vf_blk_submit(&b, (i % 2 == 0) ? VIRTIO_BLK_T_IN : VIRTIO_BLK_T_OUT, sec, &sg, 1, nullptr, &h);
      if (r != VF_OK) break;
      exp.push_back({h, (uint32_t)((i % 2 == 0) ? 512 * nsec + 1 : 1), (uint8_t)(i % 2), buf, nsec, sec, d});
    }
    CHECK(t, exp.size() >= 2);
    vf_vq_kick(&b.vq);
    uint16_t seen = 0;
    int bad = 0;
    std::vector<uint8_t> model = shadow;
    for (uint64_t cyc = 0; cyc < 400000 && seen < exp.size(); cyc++) {
      uint16_t u = vf_vq_device_used_idx(&b.vq);
      if ((uint16_t)(u - seen) > 1) { bad++; printf("    used.idx jumped from %u to %u\n", seen, u); }
      while (seen != u) {                                    // inspect each new completion at THIS cycle
        const Exp &e = exp[seen];
        uint64_t slot = seen & (b.vq.size - 1);
        if (get_u32(s, b.vq.used_iova + 4 + 8 * slot) != e.head) bad++;
        if (get_u32(s, b.vq.used_iova + 4 + 8 * slot + 4) != e.len) bad++;
        // the status byte of this request sits in the pool slot of its head
        uint8_t stb; s.mem_rd(b.pool_iova + 32ull * e.head + 16, &stb, 1);
        if (stb != VIRTIO_BLK_S_OK) bad++;
        if (e.kind == 0) { if (mem_snapshot(s, e.buf, 512 * e.n) != std::vector<uint8_t>(model.begin() + (g.ext_base + e.sec) * 512, model.begin() + (g.ext_base + e.sec + e.n) * 512)) bad++; }
        else { memcpy(&model[(g.ext_base + e.sec) * 512], e.data.data(), e.data.size()); if (s.stor_cur() != model) bad++; }
        seen++;
      }
      s.tick();
    }
    CHECK_EQ(t, seen, exp.size());
    CHECK_EQ(t, bad, 0);
    CHECK_MON(t, s);
  }
}

// ------------------------------------------------------------------------------------------------------
// storage faults and durability semantics
// ------------------------------------------------------------------------------------------------------
VF_TEST(storage_faults, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  std::vector<uint8_t> shadow = s.stor_cur();
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t buf; s.alloc(0, 16384, 8, &buf);
  uint8_t st;
  auto ctr = [&](unsigned i) { return vf_hv_devcnt(s.mg(), 0, i); };
  // a read that fails half way: IOERR, the bytes after the failure are zero, the bytes before it are valid
  s.bad_read.insert(g.ext_base + 10);
  std::vector<uint8_t> junk(2048, 0xcc);
  s.mem_wr(buf, junk.data(), junk.size());
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 8, buf, 4 * 512, &st), VF_E_IO);
  CHECK_EQ(t, st, VIRTIO_BLK_S_IOERR);
  auto got = mem_snapshot(s, buf, 2048);
  CHECK(t, std::vector<uint8_t>(got.begin(), got.begin() + 1024) == std::vector<uint8_t>(shadow.begin() + (g.ext_base + 8) * 512, shadow.begin() + (g.ext_base + 10) * 512));
  bool z = true; for (size_t i = 1024; i < 2048; i++) z &= got[i] == 0;
  CHECK(t, z);
  CHECK_EQ(t, ctr(VF_DC_BLK_STOR_ERR), 1);
  CHECK_EQ(t, ctr(VF_DC_BLK_IOERR), 1);
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  s.bad_read.clear();
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 8, buf, 4 * 512, &st), VF_OK);                 // transient: the next request works
  // a write that fails: IOERR; storage outside the failing sector range is untouched
  s.bad_write.insert(g.ext_base + 22);
  std::vector<uint8_t> pat(4 * 512); fill_pattern(pat, 12);
  s.mem_wr(buf, pat.data(), pat.size());
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 20, buf, 4 * 512, &st), VF_E_IO);
  std::vector<uint8_t> cur = s.stor_cur();
  bool outside = true;
  for (size_t sec = 0; sec * 512 < cur.size(); sec++) {
    if (sec >= g.ext_base + 20 && sec < g.ext_base + 24) continue;
    outside &= memcmp(&cur[sec * 512], &shadow[sec * 512], 512) == 0;
  }
  CHECK(t, outside);
  CHECK(t, memcmp(&cur[(g.ext_base + 22) * 512], &shadow[(g.ext_base + 22) * 512], 1024) == 0);   // the failing sector and the one after it are unchanged
  s.bad_write.clear();
  // a failing flush: IOERR, then the next flush works
  s.fail_flush = true;
  CHECK_EQ(t, vf_blk_flush_sync(&b, &st), VF_E_IO);
  s.fail_flush = false;
  CHECK_EQ(t, vf_blk_flush_sync(&b, &st), VF_OK);
  CHECK_EQ(t, vf_dev_check(&b.dev), VF_OK);
  CHECK_MON(t, s);
}

VF_TEST(storage_durability, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  s.st_log_on = true;
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t buf; s.alloc(0, 16384, 8, &buf);
  uint8_t st;
  std::vector<uint8_t> original = s.stor_cur();
  std::vector<uint8_t> a(1024), c(1024);
  fill_pattern(a, 1); fill_pattern(c, 2);
  auto sec = [&](uint64_t n) { return (g.ext_base + n) * 512; };
  // (a) acknowledged but NOT flushed: a power loss may drop it (the device never promised durability)
  s.mem_wr(buf, a.data(), a.size());
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 30, buf, 1024, &st), VF_OK);
  uint64_t rd = 0; (void)rd;
  CHECK(t, memcmp(&s.stor_cur()[sec(30)], a.data(), 1024) == 0);          // visible to reads (write cache)
  s.power_loss();
  CHECK(t, memcmp(&s.stor_cur()[sec(30)], &original[sec(30)], 1024) == 0);
  // (b) written, then FLUSH acknowledged: it survives
  s.mem_wr(buf, c.data(), c.size());
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 32, buf, 1024, &st), VF_OK);
  CHECK_EQ(t, vf_blk_flush_sync(&b, &st), VF_OK);
  s.power_loss();
  CHECK(t, memcmp(&s.stor_cur()[sec(32)], c.data(), 1024) == 0);
  // (c) the storage saw every write of the request BEFORE the flush (ordering), and exactly one flush per FLUSH request
  size_t last_flush = 0, last_write = 0, nflush = 0;
  for (size_t i = 0; i < s.st_log.size(); i++) { if (s.st_log[i].first == 2) { last_flush = i; nflush++; } if (s.st_log[i].first == 1) last_write = i; }
  CHECK_EQ(t, nflush, 1);
  CHECK(t, last_write < last_flush);
  // (d) FLUSH is not acknowledged before the storage acknowledged it: with a slow storage the completion waits
  s.k.st_lat_min = s.k.st_lat_max = 300;
  uint16_t h;
  uint64_t cyc_req = 0;
  uint16_t want = (uint16_t)(vf_vq_device_used_idx(&b.vq) + 1);
  CHECK_EQ(t, vf_blk_submit(&b, VIRTIO_BLK_T_FLUSH, 0, nullptr, 0, nullptr, &h), VF_OK);
  vf_vq_kick(&b.vq);
  uint64_t f0 = s.st_flushes;
  CHECK(t, run_until(s, [&] { return s.st_flushes > f0; }, 100000));
  cyc_req = s.cycle();
  CHECK(t, run_until(s, [&] { return vf_vq_device_used_idx(&b.vq) == want; }, 100000));
  CHECK(t, s.cycle() - cyc_req >= 299);
  s.k.st_lat_min = s.k.st_lat_max = 1;
  // (e) a failed flush is reported as an error and the data stays non-durable
  vf_blk_completion_t cc; vf_blk_wait(&b, &cc, 100000);
  s.mem_wr(buf, a.data(), a.size());
  CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 34, buf, 1024, &st), VF_OK);
  s.fail_flush = true;
  CHECK_EQ(t, vf_blk_flush_sync(&b, &st), VF_E_IO);
  s.fail_flush = false;
  s.power_loss();
  CHECK(t, memcmp(&s.stor_cur()[sec(34)], &original[sec(34)], 1024) == 0);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// interrupts and notifications
// ------------------------------------------------------------------------------------------------------
VF_TEST(interrupts, "t1", false, is_blk0) {
  Sim s(cfg1());
  Guest g = setup_guest(s, 0);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t buf; s.alloc(0, 4096, 8, &buf);
  CHECK(t, !s.irq(0));
  uint8_t st;
  CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 1, buf, 512, &st), VF_OK);
  // vf_blk_wait acknowledged any interrupt it saw; issue another request and watch the line itself
  uint16_t h;
  vf_sg_t sg = {buf, 512, 1};
  CHECK_EQ(t, vf_blk_submit(&b, VIRTIO_BLK_T_IN, 2, &sg, 1, nullptr, &h), VF_OK);
  vf_vq_kick(&b.vq);
  CHECK(t, run_until(s, [&] { return s.irq(0); }, 100000));
  CHECK_EQ(t, s.mmio_rd(0, VIRTIO_MMIO_INTERRUPT_STATUS), VIRTIO_MMIO_INT_VRING);
  CHECK_EQ(t, vf_vq_device_used_idx(&b.vq), 2);                         // the interrupt means the completion is already visible
  s.mmio_wr(0, VIRTIO_MMIO_INTERRUPT_ACK, VIRTIO_MMIO_INT_VRING);
  CHECK(t, !s.irq(0));
  vf_blk_completion_t c; CHECK_EQ(t, vf_blk_poll(&b, &c), 1);
  // VIRTQ_AVAIL_F_NO_INTERRUPT suppresses the notification, not the completion
  vf_vq_set_no_interrupt(&b.vq, 1);
  uint32_t irq0 = vf_hv_perf32(s.mg(), 0, VF_P_IRQ);
  CHECK_EQ(t, vf_blk_submit(&b, VIRTIO_BLK_T_IN, 3, &sg, 1, nullptr, &h), VF_OK);
  vf_vq_kick(&b.vq);
  CHECK(t, run_until(s, [&] { return vf_vq_device_used_idx(&b.vq) == 3; }, 100000));
  s.tick(200);
  CHECK(t, !s.irq(0));
  CHECK_EQ(t, vf_hv_perf32(s.mg(), 0, VF_P_IRQ), irq0);
  CHECK_EQ(t, vf_hv_perf32(s.mg(), 0, VF_P_IRQ_SUP), 1);
  CHECK_EQ(t, vf_blk_poll(&b, &c), 1);
  vf_vq_set_no_interrupt(&b.vq, 0);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// performance counters agree with an independent count of what crossed the interfaces
// ------------------------------------------------------------------------------------------------------
VF_TEST(perf_counters, "t1", false, is_blk0) {
  Sim s(cfg1());
  s.bdg_log_on = true;
  s.k.bdg_bp = 25; s.k.bdg_lat_max = 4; s.k.st_bp = 25; s.k.st_lat_max = 5;
  Guest g = setup_guest(s, 0);
  vf_blk_t b;
  CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
  uint64_t area; s.alloc(0, 1 << 17, 8, &area);
  vf_hv_clear_counters(s.mg(), 0);
  uint64_t log0 = s.bdg_log().size();
  uint64_t c0 = s.cycle();
  unsigned nreq = 0, kicks = 0, descs = 0;
  uint8_t st;
  for (unsigned i = 0; i < 9; i++) {
    if (i % 3 == 2) { CHECK_EQ(t, vf_blk_flush_sync(&b, &st), VF_OK); descs += 2; }
    else { CHECK_EQ(t, vf_blk_rw_sync(&b, i % 3, 4 * i, area + 8192ull * i, 1024, &st), VF_OK); descs += 3; }
    nreq++; kicks++;
  }
  wait_idle(s, 0);                                                      // the engine re-reads avail.idx once more after the last completion
  uint64_t rd = 0, wr = 0;
  for (size_t i = log0; i < s.bdg_log().size(); i++) {
    const BdgReq &r = s.bdg_log()[i];
    unsigned n = __builtin_popcount(r.wstrb);
    if (r.op == VF_ALB_OP_READ) rd += n; else wr += n;
  }
  auto m = s.mg();
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_REQ), nreq);
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_DESC), descs);
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_NOTIFY), kicks);
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_QD_N), nreq);
  CHECK_EQ(t, vf_hv_perf64(m, 0, VF_P_RD_BYTES), rd);                  // DMA bytes: context counter == what the BridgeEngine saw
  CHECK_EQ(t, vf_hv_perf64(m, 0, VF_P_WR_BYTES), wr);
  CHECK_EQ(t, vf_hv_bridge64(m, 0, VF_B_RD_BYTES), rd);                // ... == the per-domain counter of the bridge
  CHECK_EQ(t, vf_hv_bridge64(m, 0, VF_B_WR_BYTES), wr);
  CHECK_EQ(t, vf_hv_bridge32(m, 0, VF_B_REQS), s.bdg_log().size() - log0);
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_IRQ) + vf_hv_perf32(m, 0, VF_P_IRQ_SUP), nreq);
  CHECK(t, vf_hv_perf32(m, 0, VF_P_IRQ) == nreq);
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_VIOL), 0);
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_INVALID), 0);
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_FATAL), 0);
  CHECK_EQ(t, vf_hv_devcnt(m, 0, VF_DC_BLK_READ_OK), 3);
  CHECK_EQ(t, vf_hv_devcnt(m, 0, VF_DC_BLK_WRITE_OK), 3);
  CHECK_EQ(t, vf_hv_devcnt(m, 0, VF_DC_BLK_FLUSH_OK), 3);
  uint64_t tot = vf_hv_perf64(m, 0, VF_P_TOTAL), busy = vf_hv_perf64(m, 0, VF_P_BUSY);
  CHECK(t, tot >= s.cycle() - c0 - 40 && tot <= s.cycle() - c0 + 40);   // cycles since clear
  CHECK(t, busy > 0 && busy <= tot);
  uint64_t clat = vf_hv_perf64(m, 0, VF_P_CLAT_SUM);
  CHECK(t, clat > 0 && vf_hv_perf32(m, 0, VF_P_CLAT_MAX) > 0 && vf_hv_perf32(m, 0, VF_P_CLAT_MAX) * (uint64_t)nreq >= clat);
  CHECK(t, vf_hv_perf64(m, 0, VF_P_WLAT_SUM) > 0);
  CHECK(t, vf_hv_perf32(m, 0, VF_P_STALL) > 0);                         // back-pressure was applied and measured
  CHECK(t, vf_hv_perf64(m, 0, VF_P_BEWAIT) > 0);                        // backend response wait cycles
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_QW_N), nreq);                     // queue waiting time sampled once per request
  CHECK(t, vf_hv_perf64(m, 0, VF_P_QW_SUM) > 0);
  CHECK(t, vf_hv_bridge32(m, 0, VF_B_STALL) > 0 && vf_hv_bridge32(m, 0, VF_B_LAT_MAX) > 0);
  // counters clear on request
  vf_hv_clear_counters(m, 0);
  CHECK_EQ(t, vf_hv_perf32(m, 0, VF_P_REQ), 0);
  CHECK_MON(t, s);
}

// ------------------------------------------------------------------------------------------------------
// back-pressure and latency never change results
// ------------------------------------------------------------------------------------------------------
VF_TEST(backpressure_equivalence, "t1", false, is_blk0) {
  std::vector<uint8_t> ref_stor, ref_mem;
  for (int variant = 0; variant < 4; variant++) {
    Sim s(cfg1());
    s.rng.seed(1234 + variant);
    const int bp[] = {0, 50, 85, 95}, lat[] = {1, 6, 20, 3};
    s.k.bdg_bp = bp[variant]; s.k.bdg_lat_max = lat[variant]; s.k.st_bp = bp[variant]; s.k.st_lat_max = lat[variant];
    Guest g = setup_guest(s, 0);
    vf_blk_t b;
    CHECK_EQ(t, open_blk(s, g, &b, QS), VF_OK);
    uint64_t area; s.alloc(0, 1 << 17, 8, &area);
    std::vector<uint8_t> pat(4096);
    uint8_t st;
    for (unsigned i = 0; i < 10; i++) {
      fill_pattern(pat, 70 + i);
      s.mem_wr(area, pat.data(), pat.size());
      CHECK_EQ(t, vf_blk_rw_sync(&b, 1, 10 * i, area, 2048 + 512 * (i % 3), &st), VF_OK);
      CHECK_EQ(t, vf_blk_rw_sync(&b, 0, 10 * i, area + 8192, 2048 + 512 * (i % 3), &st), VF_OK);
    }
    CHECK_EQ(t, vf_blk_flush_sync(&b, &st), VF_OK);
    std::vector<uint8_t> m = mem_snapshot(s, area + 8192, 4096);
    if (variant == 0) { ref_stor = s.stor_cur(); ref_mem = m; }
    else { CHECK(t, s.stor_cur() == ref_stor); CHECK(t, m == ref_mem); }
    if (variant > 0) CHECK(t, vf_hv_perf32(s.mg(), 0, VF_P_STALL) > 0);
    CHECK_MON(t, s);
  }
}
