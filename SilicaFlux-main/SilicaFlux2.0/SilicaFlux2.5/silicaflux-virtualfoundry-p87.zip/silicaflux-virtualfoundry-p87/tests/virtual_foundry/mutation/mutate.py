#!/usr/bin/env python3
"""Mutation check of the VirtualFoundry RTL.

Every mutant is ONE deliberate defect injected into a private copy of rtl/albion.  The co-simulation
suite is rebuilt against it and must FAIL (a non-zero exit, a failed check or a crash).  A mutant that
survives means the suite cannot see that defect.  The un-mutated design is built and run first: the
baseline must pass, otherwise the result is meaningless.

usage: mutate.py [--only MXX ...] [--jobs N]        results -> reports/mutation.md
"""
import argparse, os, re, shutil, subprocess, sys, time, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[3]
W = ROOT / "build" / "mut"
RTL_FILES = ["sf_virtual_pkg.sv", "sf_virtual_descriptor.sv", "sf_virtual_queue.sv", "sf_virtual_gate.sv", "sf_virtual_dma_arb.sv",
             "sf_virtual_storage_adapter.sv", "sf_virtual_network_adapter.sv", "sf_virtual_transport.sv", "sf_virtual_ctx_mgmt.sv",
             "sf_virtual_ctx.sv", "sf_virtual_bridge.sv", "sf_virtual_io.sv"]

# configuration -> (-G flags, -D flags, test command lines)
CFG = {
  "blk3":  ("-GNCTX=3 -GCTX_KIND=0", "-DVF_NCTX=3 -DVF_KIND=0",
            [["--tier", "t1", "--skip-long"], ["--tier", "t2"], ["--only", "random_blk_multi", "--iters", "60"], ["--only", "random_blk_single", "--iters", "60"]]),
  "multi": ("-GNCTX=3 -GCTX_KIND=4", "-DVF_NCTX=3 -DVF_KIND=4",
            [["--tier", "t3", "--iters", "30"]]),
}

# id, file, old (exactly once), new, config, what it breaks
M = [
 ("M01", "sf_virtual_descriptor.sv", "end else if (visited[idx[VW-1:0]]) begin", "end else if (1'b0) begin", "blk3", "descriptor-loop detection removed"),
 ("M02", "sf_virtual_descriptor.sv", "ALLOWED_FLAGS = VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE;", "ALLOWED_FLAGS = VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE | VIRTQ_DESC_F_INDIRECT;", "blk3", "INDIRECT descriptors accepted although not offered"),
 ("M03", "sf_virtual_descriptor.sv", "end else if (idx >= q_size) begin", "end else if (1'b0) begin", "blk3", "queue-bounds check of descriptor indices removed"),
 ("M04", "sf_virtual_descriptor.sv", "end else if (!d_flags[1] && seen_w) begin", "end else if (1'b0) begin", "blk3", "device-readable-after-writable (direction) check removed"),
 ("M05", "sf_virtual_descriptor.sv", "end else if (count == CW'(MAX_CHAIN)) begin", "end else if (count == CW'(MAX_CHAIN + 1)) begin", "blk3", "maximum chain length off by one"),
 ("M06", "sf_virtual_descriptor.sv", "end else if ((d_len != 32'd0) && !chk_ok && d_flags[1]) begin", "end else if (1'b0) begin", "blk3", "pre-check of writable buffers removed"),
 ("M07", "sf_virtual_gate.sv", "(is_write ? w[i] : r[i]))", "(r[i] | w[i]))", "blk3", "window gate ignores the access direction"),
 ("M08", "sf_virtual_gate.sv", "if (v[i] && (wd[i] == dom) && (lo >= wb[i])", "if (v[i] && (1'b1) && (lo >= wb[i])", "blk3", "window gate ignores the domain tag"),
 ("M09", "sf_virtual_gate.sv", "(hi <= wl[i]) &&", "(hi <= wl[i] + 64'd1) &&", "blk3", "window upper bound off by one byte"),
 ("M10", "sf_virtual_bridge.sv", "            if (cit_rsp_ok) begin", "            if (1'b1) begin", "blk3", "Citadel verdict ignored (everything permitted)"),
 ("M11", "sf_virtual_bridge.sv", "end else if (chk_ctr >= 32'(CHK_TMO)) begin   // no verdict in time\n            outage <= 1'b1; out_ctr <= '0;\n            fsrc_q <= FS_CITADEL; fcode_q <= {4'd0, ALB_F_CITTMO}; fviol_q <= 1'b1; st <= S_DENY;",
        "end else if (chk_ctr >= 32'(CHK_TMO)) begin   // no verdict in time\n            tag_q <= tag_ctr; tag_ctr <= tag_ctr + TAGW'(1); tmo_ctr <= '0; st <= S_ISSUE;", "blk3", "Citadel timeout fails OPEN instead of closed"),
 ("M12", "sf_virtual_bridge.sv", "wire dom_fits = (dom_q >> DOM_W) == 16'd0;", "wire dom_fits = 1'b1;", "blk3", "domain wider than the Citadel field is truncated, not denied"),
 ("M13", "sf_virtual_bridge.sv", "wire echo_ok    = (bdg_rsp_tag == tag_q) && (bdg_rsp_dom == dom_q[DOM_W-1:0]) &&", "wire echo_ok    = 1'b1 || (bdg_rsp_tag == tag_q) && (bdg_rsp_dom == dom_q[DOM_W-1:0]) &&", "blk3", "BridgeEngine response echo not checked"),
 ("M14", "sf_virtual_bridge.sv", "end else if (bdg_rsp_status != ALB_ST_OKAY) begin", "end else if (1'b0) begin", "blk3", "BridgeEngine error status delivered as data"),
 ("M15", "sf_virtual_bridge.sv", "if (st == S_RESP) u_resp_valid[owner] = 1'b1;", "if (st == S_RESP) u_resp_valid[0] = 1'b1;", "blk3", "bridge response routed to context 0 only"),
 ("M16", "sf_virtual_bridge.sv", "cnt[gnt][0] <= cnt[gnt][0] + 32'd1;", "cnt[0][0] <= cnt[0][0] + 32'd1;", "blk3", "per-domain request counter charged to the wrong domain"),
 ("M17", "sf_virtual_queue.sv", "acc_bytes = 4'd4; acc_wval = used_len_q; end", "acc_bytes = 4'd4; acc_wval = 32'd0; end", "blk3", "used.len always reported as 0"),
 ("M18", "sf_virtual_queue.sv", "if ((rd16 - last_avail) > q_size) begin       // spec 2.7.13.3: idx never runs ahead > N", "if (1'b0) begin", "blk3", "avail.idx jump check removed"),
 ("M19", "sf_virtual_queue.sv", "if (rd16[0]) irq_suppressed_pulse <= 1'b1;    // VIRTQ_AVAIL_F_NO_INTERRUPT", "if (1'b0) irq_suppressed_pulse <= 1'b1;", "blk3", "VIRTQ_AVAIL_F_NO_INTERRUPT ignored"),
 ("M20", "sf_virtual_storage_adapter.sv", "(nsec <= (CAP - sector));", "(nsec <= (CAP - sector + 64'd1));", "blk3", "capacity check off by one sector"),
 ("M21", "sf_virtual_storage_adapter.sv", "saddr <= SADDR_W'((ext_base + h_sector) << 9);\n              start_phase(PH_IN, in_len);", "saddr <= SADDR_W'((h_sector) << 9);\n              start_phase(PH_IN, in_len);", "blk3", "storage extent base not applied (guests overlap in storage)"),
 ("M22", "sf_virtual_storage_adapter.sv", "              st <= B_FLUSH;\n", "              status_q <= VIRTIO_BLK_S_OK; start_phase(PH_ZERO, in_len);\n", "blk3", "FLUSH acknowledged without reaching storage"),
 ("M23", "sf_virtual_transport.sv", "wire feat_ok = ((drv_feat_q & ~dev_features) == 64'd0) &&", "wire feat_ok = 1'b1 || ((drv_feat_q & ~dev_features) == 64'd0) &&", "blk3", "FEATURES_OK granted for unoffered features"),
 ("M24", "sf_virtual_transport.sv", "wire ready_reset   = all_drain && all_idle;", "wire ready_reset   = 1'b1;", "blk3", "reset does not wait for the engine to drain"),
 ("M25", "sf_virtual_ctx_mgmt.sv", "        if (!any_ready) begin\n          domain       <= mgmt_req_wdata[15:0];", "        if (1'b1) begin\n          domain       <= mgmt_req_wdata[15:0];", "blk3", "domain binding not locked while the queue is live"),
 ("M26", "sf_virtual_io.sv", "if (st_out && st_resp_valid) sc_resp_v[st_owner] = 1'b1;", "if (st_out && st_resp_valid) sc_resp_v[0] = 1'b1;", "blk3", "storage response routed to context 0"),
 ("M27", "sf_virtual_queue.sv", "end else if ((RXQ ? (work_gate && (pending || avail_known)) : pending) && dev_active && !drain) begin", "end else if ((RXQ ? (pending || avail_known) : pending) && dev_active && !drain) begin", "multi", "receive queue consumes buffers without a frame"),
 ("M28", "sf_virtual_network_adapter.sv", "return (p == 32'd10) ? 8'd1 : 8'd0;", "return 8'd0;", "multi", "virtio_net_hdr num_buffers not set to 1"),
 ("M29", "sf_virtual_network_adapter.sv", "wire hdr_ok = (t_hdr[7:0] == 8'd0) && (t_hdr[15:8] == VIRTIO_NET_HDR_GSO_NONE);", "wire hdr_ok = 1'b1;", "multi", "transmit header offload bits not validated"),
 ("M30", "sf_virtual_network_adapter.sv", "end else if ({1'b0, rx_w_len} < (33'(HDR) + {{(33-FW){1'b0}}, rlen})) begin", "end else if (1'b0) begin", "multi", "too-small receive buffer not rejected"),
 ("M31", "sf_virtual_network_adapter.sv", "accept = first ? (!rx_have && rx_enable && !flush) : rx_recv;", "accept = first ? (rx_enable && !flush) : rx_recv;", "multi", "arriving frame overwrites the stored one"),
 ("M32", "sf_virtual_network_adapter.sv", "      if (flush || !rx_enable) rx_have <= 1'b0;           // stale frames never survive a reset / a disabled device\n", "", "multi", "stored frame survives a device reset"),
 ("M33", "sf_virtual_io.sv", "if (CTX_KIND[k] && pf_m_queue == 4'(k)) begin", "if (pf_m_queue == 4'(k)) begin", "multi", "frames steered to a block context"),
 ("M34", "sf_virtual_network_adapter.sv", "tx_r_len < (32'(HDR) + 32'(MIN_FRAME)) || tx_r_len > (32'(HDR) + 32'(FBYTES))) begin", "1'b0) begin", "multi", "transmit frame size limits not enforced"),
]

def run(cmd, cwd=ROOT, **kw):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, **kw)

def build(cfg, rtl_dir, tag, jobs):
    g, d, _ = CFG[cfg]
    out = W / tag
    shutil.rmtree(out, ignore_errors=True)
    out.mkdir(parents=True)
    files = ["third_party/p83/sf_meridian_pkg.sv", "third_party/p83/sf_meridian_citadel_ref.sv"] + [str(rtl_dir / f) for f in RTL_FILES] + \
            ["tests/virtual_foundry/tb/vf_tb_top.sv"] + \
            [f"runtime/virtual_foundry/src/{f}" for f in ["vf_core.c", "vf_blk.c", "vf_net.c", "vf_hv.c"]] + \
            sorted(str(p.relative_to(ROOT)) for p in (ROOT / "tests/virtual_foundry/sim").glob("*.cpp"))
    cf = f"-I{ROOT}/runtime/virtual_foundry/include -I{ROOT}/tests/virtual_foundry/sim -O1 -std=c++17 {d}"
    cmd = ["verilator-cli", "--cc", "--exe", "--build", "-j", str(jobs), "-O1", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-GENUNNAMED",
           "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include", "--top-module", "vf_tb_top"] + g.split() + ["-CFLAGS", cf, "-Mdir", str(out)] + files + ["-o", "vf_tests"]
    r = run(cmd)
    return (out / "vf_tests") if (out / "vf_tests").exists() else None, r.stdout + r.stderr

def tests(binary, cfg):
    log = []
    for args in CFG[cfg][2]:
        try:
            r = subprocess.run([str(binary)] + args, cwd=ROOT, capture_output=True, text=True, timeout=300)
            log.append((args, r.returncode, r.stdout[-400:]))
            if r.returncode != 0:
                return False, log           # the first failing suite kills the mutant
        except subprocess.TimeoutExpired:
            log.append((args, -9, "timeout"))
            return False, log               # a hang is also a detection
    return True, log

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    W.mkdir(parents=True, exist_ok=True)
    rows, survivors = [], []
    # baseline per configuration
    for cfg in sorted({m[4] for m in M if not a.only or m[0] in a.only}):
        t0 = time.time()
        b, msg = build(cfg, ROOT / "rtl/albion", "base_" + cfg, a.jobs)
        if b is None:
            print("baseline build failed for", cfg, msg[-800:]); sys.exit(2)
        ok, log = tests(b, cfg)
        print(f"baseline {cfg}: {'PASS' if ok else 'FAIL'} ({time.time()-t0:.0f}s)")
        if not ok:
            print(log); sys.exit(2)
    for mid, fn, old, new, cfg, what in M:
        if a.only and mid not in a.only: continue
        rd = W / ("rtl_" + mid)
        shutil.rmtree(rd, ignore_errors=True)
        shutil.copytree(ROOT / "rtl/albion", rd)
        src = (rd / fn).read_text()
        if src.count(old) != 1:
            print(f"{mid}: pattern found {src.count(old)} times in {fn}"); sys.exit(3)
        (rd / fn).write_text(src.replace(old, new))
        t0 = time.time()
        b, msg = build(cfg, rd, mid, a.jobs)
        if b is None:
            status = "killed (does not build / elaborate)"
            killed = True
        else:
            ok, log = tests(b, cfg)
            killed = not ok
            status = "killed by " + " ".join(log[-1][0]) if killed else "SURVIVED"
        print(f"{mid} {'KILLED  ' if killed else 'SURVIVED'} {what}   [{status}] ({time.time()-t0:.0f}s)", flush=True)
        rows.append((mid, fn, what, cfg, status))
        if not killed: survivors.append(mid)
        shutil.rmtree(W / mid, ignore_errors=True); shutil.rmtree(rd, ignore_errors=True)
    out = ROOT / "reports" / "mutation.md"
    with open(out, "w") as f:
        f.write("# Mutation check\n\nEach mutant is one deliberate RTL defect; the suite must fail on it.\n\n")
        f.write("| id | file | defect | configuration | result |\n|---|---|---|---|---|\n")
        for r in rows: f.write("| %s | `%s` | %s | %s | %s |\n" % r)
        f.write("\n**%d / %d mutants killed.**%s\n" % (len(rows) - len(survivors), len(rows), "" if not survivors else "  SURVIVORS: " + ", ".join(survivors)))
    print("%d/%d killed" % (len(rows) - len(survivors), len(rows)), "survivors:", survivors)
    sys.exit(1 if survivors else 0)

main()
