# 02 — Register map

Constants are in `runtime/virtual_foundry/include/vf_regs.h`; `tests/virtual_foundry/tools/check_regs.py` compares them mechanically with `sf_virtual_pkg.sv` and the RTL decode
(135 constants, 0 mismatches at delivery). Buses: valid/ready request, **one response one cycle after acceptance**; a write returns `rdata = 0`.

## A. Guest-visible window — virtio-mmio version 2 (OASIS VirtIO 1.2 §4.2.2)

One 4 KiB window per context. 32-bit accesses only.

| Offset | Name | Behaviour in this device |
|---|---|---|
| 0x000 / 0x004 | MagicValue / Version | `0x74726976` ("virt") / `2` |
| 0x008 / 0x00c | DeviceID / VendorID | `2` block, `1` network / `0x58464c53` |
| 0x010 / 0x014 | DeviceFeatures / Sel | block: sel 0 `SEG_MAX(2) FLUSH(9)` (+ `RO(5)` only when the extent is read-only), sel 1 `VERSION_1 ACCESS_PLATFORM`; network: sel 0 `MAC(5) STATUS(16)`, sel 1 `VERSION_1 ACCESS_PLATFORM`; other sel 0 |
| 0x020 / 0x024 | DriverFeatures / Sel | ignored once FEATURES_OK is set. FEATURES_OK is withheld if the driver accepts an unoffered feature or omits VERSION_1 / ACCESS_PLATFORM |
| 0x030 | QueueSel | block: queue 0; network: 0 = receiveq, 1 = transmitq |
| 0x034 | QueueNumMax | `MAX_QSZ` for an existing queue, **0** otherwise |
| 0x038 / 0x044 | QueueNum / QueueReady | QueueReady = 1 validates: power-of-two size ≤ QueueNumMax, desc 16-, avail 2-, used 4-byte aligned; otherwise NEEDS_RESET (QUEUE_CFG). QueueReady ← 0 is **quiesced** |
| 0x050 | QueueNotify | the value is the queue index (NOTIFICATION_DATA is not offered); a non-existent queue is ignored |
| 0x060 / 0x064 | InterruptStatus / ACK | bit 0 used-buffer, bit 1 configuration change |
| 0x070 | Status | the driver can only set bits; 0 = reset (**quiesced**); bit 6 NEEDS_RESET is device-owned |
| 0x080–0x0a4 | QueueDesc / Driver / Device Low/High | 16 / 2 / 4-byte alignment required |
| 0x0b0–0x0bc | SHM | `0xffffffff` (no shared-memory regions) |
| 0x0fc | ConfigGeneration | counts link-status changes (network); constant `0` for block |
| 0x100 | block: capacity[31:0] · network: MAC[31:0] | MAC byte 0 is bits [7:0] |
| 0x104 | block: capacity[63:32] · network: `{status[15:0], MAC[47:32]}` | status bit 0 = LINK_UP (follows `pf_link_up`; a change raises a configuration-change interrupt once DRIVER_OK) |
| 0x108 / 0x10c | block: size_max (0) / seg_max (`MAX_CHAIN − 2`) | |

The guest window has **no register that names a domain, a window, an extent or a counter**; writes to any other offset are ignored.

## B. Privileged management bus (Keystone / hypervisor; never mapped into a guest)

16-bit address: `[15:12]` page, `[11:0]` offset. Pages `0 … NCTX−1` are context pages; page `0xF` is the global page; any other page reads 0.

### B.1 Context page (`sf_virtual_ctx_mgmt`)

| Offset | Name | R/W | Description |
|---|---|---|---|
| 0x000 | ID | R | `0x53465646` ("SFVF") |
| 0x004 | VER | R | `[23:16]` major `[15:8]` minor `[7:0]` patch (1.0.0). The host library refuses another major |
| 0x008 | CAPS0 | R | `[7:0]` queues · `[15:8]` MAX_CHAIN · `[23:16]` N_WIN · `[24]` split ring · `[25]` packed (0) · `[26]` indirect (0) · `[27]` event_idx (0) · `[28]` virtio multiqueue (0) · `[29]` window table · `[30]` Citadel path · `[31]` BridgeEngine path |
| 0x00c | CAPS1 | R | `[15:0]` MAX_QSZ · `[31:24]` virtio device id |
| 0x010 | DOMAIN | RW | `[15:0]` domain, `[31]` valid. **Writes are ignored while any queue is ready** (status bit 3 set, sticky) |
| 0x014 | STATUS | R | `[0]` busy (incl. a pending kick) · `[1]` active · `[2]` needs_reset · `[3]` config write ignored (sticky) · `[15:8]` last fatal cause (sticky) · `[23:16]` device status · `[27:24]` queue-ready bitmap |
| 0x018 / 0x01c | FAULT_ADDR lo/hi | R | **first** fault since the last clear (sticky) |
| 0x020 | FAULT_INFO | R | `[0]` write · `[1]` valid · `[7:4]` source `FS_*` · `[15:8]` detail (`F_*` from the Citadel / `ST_*` from the BridgeEngine) |
| 0x024 | CTRL | W | `[0]` **host reset** (self-clearing when done; read back as `[0]` while pending) · `[1]` clear counters · `[2]` clear sticky flags and the fault record |
| 0x028 | FAULT_CNT | R | faults since the last clear |
| 0x040 + 0x20·i | WIN_CTRL | RW | `[0]` valid `[1]` read `[2]` write |
| +0x04 / +0x08,+0x0c / +0x10,+0x14 | WIN_DOMAIN / WIN_BASE / WIN_LIMIT | RW | limit **inclusive**; `base > limit` matches nothing |
| 0x180–0x18c | EXT_SIZE lo/hi, EXT_BASE lo/hi | RW | storage extent in 512-byte sectors; **writes ignored once the guest driver has started** (status ≠ 0) |
| 0x190 | EXT_FLAGS | RW | `[0]` read-only extent |
| 0x194 / 0x198 | MAC lo / hi | RW | network MAC; same lock as the extent |
| 0x200 + | performance counters | R | below |
| 0x300 + 4·i | device event counters 0..7 | R | block: IN ok, OUT ok, FLUSH ok, GET_ID ok, IOERR, UNSUPP, storage error seen, direction error · network: tx handed to PacketForge, rx delivered, tx dropped, rx dropped (buffer busy / device not enabled), rx dropped (oversize / malformed), rx buffer rejected (too small, frame kept), tx DMA fault, rx buffer direction error |

**Window programming rule** (the host library follows it): clear `WIN_CTRL.valid`, write domain / base / limit, set `WIN_CTRL` — a half-programmed window is never live.

Performance counters (offsets from 0x200; 64-bit values are lo/hi pairs):

| Off | Counter | Off | Counter |
|---|---|---|---|
| 0x000 | descriptors fetched | 0x060 | total cycles since clear (64) |
| 0x004 | requests completed (used.idx published) | 0x068 | **queue waiting time** sum (64): kick (or previous completion with a backlog) → head fetch |
| 0x008 / 0x010 | DMA bytes read / written (64), counted when the bridge accepts the beat | 0x070 / 0x074 | queue waiting time max / samples |
| 0x018 / 0x020 | completion latency sum (64) / max: head fetch → `used.idx` published | 0x078 | **invalid requests** (malformed → fatal, permission violation, direction error) |
| 0x024 / 0x02c | descriptor-walk time sum (64) / max | 0x07c | cycles waiting for a backend response (64) |
| 0x030 / 0x034 | interrupts raised / suppressed | 0x084 | errors returned by the bridge / Citadel for this context's beats |
| 0x038 | cycles with a DMA or backend request back-pressured | 0x040 / 0x048 / 0x04c | avail-ring depth sum (64) / max / samples at head fetch |
| 0x03c | permission violations (window gate, pre-check, Citadel) | 0x050 / 0x054 | notifications received / DEVICE_NEEDS_RESET events |
| | | 0x058 | busy cycles (64) |

### B.2 Global page (0xF000)

| Offset | Name | Description |
|---|---|---|
| 0xF000 / 0xF004 | ID / VER | `0x53465647` ("SFVG") / 1.0.0 |
| 0xF008 | CAPS | `[3:0]` NCTX · `[7:4]` TAGW · `[11:8]` DOM_W − 1 · `[27:12]` bitmap of network contexts |
| 0xF00c | STATUS | `[0]` bridge busy · `[1]` **isolated**: a BridgeEngine beat timed out and its late response has not arrived |
| 0xF010 | ORPHAN_RSP | BridgeEngine responses that matched nothing (consumed and dropped) |
| 0xF014 | CTRL | W `[0]` clear the bridge counters |
| 0xF018 | PF_UNMATCHED | PacketForge frames for a missing / non-network context (dropped) |
| 0xF01c / 0xF020 | CHK_TMO / RSP_TMO | configured timeouts |
| 0xF024 / 0xF028 / 0xF02c | ST_TIMEOUTS / ST_TMO / ST_ISOLATED | storage response timeouts, configured value, `[0]` storage port isolated |
| 0xF100 + 0x40·ctx + 4·w | per-context (= per-domain) bridge counters | w: 0 beats accepted · 1,2 read bytes (64) · 3,4 write bytes (64) · 5 Citadel denials · 6 BridgeEngine errors · 7 timeouts · 8 cycles a beat waited in the bridge · 9,10 latency sum (64) · 11 latency max |

### B.3 Fatal causes (`STATUS[15:8]`) and fault sources (`FAULT_INFO[7:4]`)

| Code | Cause | Trigger |
|---|---|---|
| 1 | QUEUE_CFG | invalid queue configuration at QueueReady = 1 |
| 2 | NO_DOMAIN | processing requested with no protection domain bound |
| 3 | AVAIL_IDX_JUMP | `avail.idx − last_avail > QueueSize` |
| 4 | RING_DMA | fault on descriptor table / available ring / used ring |
| 5 | DESC_IDX_OOR | head or next index ≥ QueueSize |
| 6 | CHAIN_LOOP | descriptor revisited within a chain |
| 7 | CHAIN_TOO_LONG | more than MAX_CHAIN descriptors |
| 8 | DESC_FLAGS | INDIRECT or reserved flag bits |
| 9 | CHAIN_ORDER | device-readable after device-writable |
| 10 | CHAIN_LEN_OVF | chain length ≥ 2³² |
| 11 | WRITABLE_PERM | device-writable buffer outside the windows |
| 12 | NO_STATUS | no device-writable byte for the block status |
| 13 | DATA_WRITE_DMA | fault while writing a device-writable buffer |

Fault sources: 1 window GATE · 2 DESC (pre-check) · 3 CITADEL (detail = `F_NOMAP 1`, `F_PERM 2`, `F_DOMAIN 3`, `F_PRIV 4`, `F_CITTMO 6`) · 4 BRIDGE (detail = `ST_*`) · 5 TIMEOUT · 6 ECHO.
