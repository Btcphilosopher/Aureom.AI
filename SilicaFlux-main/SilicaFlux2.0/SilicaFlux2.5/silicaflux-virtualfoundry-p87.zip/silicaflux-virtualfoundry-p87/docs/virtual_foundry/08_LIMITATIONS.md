# 08 — Limitations and what is not claimed

**Status: RTL simulation (Verilator) only.** No synthesis, no place-and-route, no timing, no area, no power, no FPGA, no silicon, no formal proof. Nothing here is a frequency, area or power claim.

## What this is not
* **Not a hypervisor.** It executes the *device side* of VirtIO devices. Scheduling, memory management, interrupt routing and the guest OS are outside it.
* **Not PCIe SR-IOV.** A "guest context" is a separate virtio-mmio device with its own protection domain. There is no physical / virtual function split, no PCIe configuration space, no BARs, no
  ARI, ATS, PRI, FLR, MSI-X, AER. It cannot be presented to a guest as a PCIe VF without a PCIe shell that does not exist in the repository.
* **Not a Linux driver.** The host library is a test and bring-up library; no Linux `virtio_*` driver or VMM was run against the model.

## Models and missing integrations
* The **Citadel** is P83's reference model (a default-deny table of base / mask entries, one address per query, one verdict per query). Policy regions must be power-of-two aligned; granularity must be
  ≥ 8 bytes (a beat is 8 bytes and is queried by its word address). `priv` is always 0 from this engine.
* **BridgeEngine, StorageCore, PacketForge are bench models.** No CloudDMA, StorageCore SoC or PacketCore instance is integrated; their real interfaces differ from the contracts in 05 and would need shims.
  The Albion transaction format is P83's definition (single 64-bit beats, no bursts, no posted writes).
* **Platform requirement** (01 §6): a write response on `bdg_*` must imply host visibility. If the platform violates it, completion visibility is not guaranteed.

## Functional limits
* One DMA beat outstanding per context and in the bridge: throughput ≈ 0.65 B/cycle at best (06). Misaligned buffers halve it.
* One request in flight per queue; one frame buffer per network context (an arriving frame while it is occupied is dropped).
* Network: no offloads, no MRG_RXBUF (receive buffers must hold header + frame), no control queue, no multiqueue; transmit completion = handed to PacketForge, not on the wire; frame buffer `FBYTES` bounds the frame.
* Block: no packed ring, indirect descriptors, EVENT_IDX, discard / write-zeroes, multiqueue; a failed OUT may leave a prefix of its sector range written (no atomicity); capacity changes while the driver runs are refused
  (the management write is ignored and flagged).
* A **silent** BridgeEngine or StorageCore stalls *all* contexts for up to `RSP_TMO` / `ST_TMO` before the isolation rule applies; a PacketForge stall *inside* a frame is not bounded; the Citadel outage rule delays every
  context.
* `NCTX ≤ 15`, `N_WIN ≤ 8`, one Citadel source port; domains wider than `DOM_W` bits are denied.
* Window / Citadel revocation applies to the next check; one authorised beat may complete (quiesce first).
* The independent monitor decodes the shadow configuration from the management writes **the test makes**; tests that write locked registers behind its back (the lock tests) use `mgmt_wr_noshadow` on purpose.

## Verification limits
* One simulator (Verilator 5.049; the pip wheel 5.48). The pure-SystemVerilog benches ran on the same tool.
* Bounded confidence only: random regression, a fault-injection sweep over every beat of two request kinds, 34 mutants (reports/mutation.md). Mutation shows the suite notices those defects, not that no others exist.
* Coverage was not measured with a coverage tool; it is argued from the test list (07).
* The 16-bit index wrap was exercised on a two-descriptor queue only.
* Only the defaults and the listed configurations were built; the parameter space was not swept.

## Things that look like features but are not
* "Per-domain traffic" is per **context** (a context has exactly one domain); two contexts bound to the same domain are counted separately.
* "Interrupt" is the context's `irq` line; no MSI-X, no interrupt remapping, no coalescing.
* `ACCESS_PLATFORM` is *required*, not optional: a driver that refuses it is not operated.
