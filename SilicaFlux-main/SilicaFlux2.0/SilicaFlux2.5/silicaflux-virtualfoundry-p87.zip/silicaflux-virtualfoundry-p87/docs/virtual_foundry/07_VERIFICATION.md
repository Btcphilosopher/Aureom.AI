# 07 — Verification

Evidence level: **RTL simulation** (Verilator) with an independent monitor, an independent software model, fault injection, mutation, and two pure-SystemVerilog benches. No formal proof, no hardware.
Raw logs: `reports/logs/`, summary: `reports/SUMMARY.md`, mutation: `reports/mutation.md`, performance: `reports/perf_sweep.md`.

## 1. Strategy: build up, gate on isolation

The brief says *start with one split virtqueue and a simulated block backend; add multiple guest contexts only when isolation tests pass*. The Makefile and `scripts/regress.sh` enforce it:

| Tier | Scope | Runs on | Gate |
|---|---|---|---|
| **t1** | one guest, one split virtqueue, block backend: bring-up, descriptors, malformed rings, permissions at every layer, resets, completion integrity, storage faults, interrupts, counters, back-pressure | five builds: default (256 / 16 / 8), small (8 / 8 / 4), registered Citadel (`CIT_LAT = 1`), short timeouts (`RSP_TMO = ST_TMO = 300`), and the same tests on context 0 of a 3-context build | — |
| **t2** | **isolation** between three block guests: memory, storage, fault containment, reset containment, fairness, per-domain accounting, interrupts | 3-context block build | t2 runs only after t1 passed |
| **t3** | virtio-net (two queues per context) over PacketForge, network isolation, block + network coexistence, constrained-random regression of block and network traffic | mixed (blk, blk, net) and (net, net) builds | t3 runs only after t2 passed |

## 2. The independent checks

* **Escape monitor** (`vf_sim.cpp`). Every beat the engine issues toward the BridgeEngine is re-checked against a **shadow** window table and a **shadow** Citadel policy decoded from the management / policy writes *the test made* (not from RTL state):
  a beat outside the windows of the context that owns the domain, or outside the Citadel policy, fails the test. Every storage access is re-checked against the owning context's extent. It also checks `priv = 0`, alignment, byte-enable
  legality, at most one beat outstanding on the bridge and on storage, and every PacketForge transmit beat (keep, last, interleaving, `err = 0`, `meta` = domain of `src`).
* **Independent software model** (`tests_random.cpp`, `Worker`). Written from the documented contract, not from the RTL: predicts status, `used.len`, the exact bytes left in every device-writable buffer (including zero fill) and the storage effect for random
  IN / OUT / FLUSH / GET_ID / unsupported / direction-error / out-of-range requests with random segmentation and alignment; the final storage image must equal the model **byte for byte**.
* **Cycle-by-cycle visibility check** (`completion_visibility`): a polling guest reads `used.idx` every cycle.
* **Fault-injection sweep** (`fault_sweep_in/out`): an error status injected on **every** bridge beat of an IN and an OUT request (80 beats each; ring, descriptor, header, payload — sampled —, status, used-ring and flags beats): the
  outcome must be success-with-correct-data, an I/O error, or a reset — never a hang, never a success with wrong data, never a byte of storage outside the request changed, never a byte of memory outside the guest changed — and the device must recover.
* **Register consistency** (`check_regs.py`): every constant of `vf_regs.h` equals the package / RTL decode (135 constants).
* **Constant consistency with Project 83** (`tb_pkg_consistency.sv`): the Albion constants equal `sf_meridian_pkg`.
* **Vendored files** are byte-identical to the repository archive (`scripts/check_vendor.py`).
* **Pure-SystemVerilog bench** (`tb_vf_io.sv`): its own guest driver, memories and checks (bring-up, write / read-back, flush, a forged request refused, no beat outside the window) — no C++.
* **Mutation** (`tests/virtual_foundry/mutation/mutate.py`): 34 single deliberate RTL defects; the suite must fail on each (reports/mutation.md).

## 3. Brief §11 → tests

| Required | Tests |
|---|---|
| Ring wrap-around | `ring_wrap` (several turns of a 4-entry ring, full-ring batches), `index_wrap16` (65 600 requests through the 16-bit index wrap) |
| Valid descriptors / chains | `valid_chains` (unaligned segments, header split over 3 descriptors, status inside the data descriptor, zero-length descriptors), `max_chain`, `basic_rw`, `random_blk_*` |
| Malformed descriptors | `mal_head_oor`, `mal_next_oor`, `mal_loop2`, `mal_loop_self`, `mal_flags_indirect`, `mal_flags_reserved`, `mal_order`, `mal_len_overflow`, `mal_no_status`, `mal_avail_jump`, `mal_writable_perm`, `mal_too_long`, `queue_config_invalid`, `no_domain`, `request_errors` — each checks NEEDS_RESET, cause, interrupt, no used entry, queue halted, nothing written, recovery |
| Incorrect permissions | `perm_readable_denied`, `perm_straddle_and_wrap`, `perm_direction`, `perm_wrong_domain`, `layer_citadel_alone`, `layer_window_alone`, `layer_bridge_alone`, `layer_boundaries`, `window_gap_and_lower_bound`, `citadel_default_deny`, `domain_binding`, `domain_too_wide`, `extent_lock`, `readonly_extent`, `iso_memory`, `iso_storage`, `net_tx_checks`, `net_tx_citadel_denied`, `net_rx_faults` |
| Queue saturation | `saturation`, `ring_wrap` |
| Back-pressure | `backpressure_equivalence` (four stall / latency settings give identical results), `perf_counters`, every random test |
| Device reset / host reset | `reset_device_midflight` (8 timings), `reset_host_midflight` (7), `reset_chip_midflight`, `queue_disable_midflight`, `reset_races`, `reset_clears_guest_state`, `iso_reset_containment`, `multi_chip_reset`, `net_reset_discards_frames`, `storage_silent` |
| Multiple queues | virtio-net contexts have two queues each: `net_*`, `net_isolation`, `net_blk_coexist`, `random_net` |
| Multiple guest contexts | the whole of tier 2, `random_blk_multi`, `net_*` on mixed builds |
| Completion integrity | `completion_visibility`, the byte-exact model in `random_*`, `saturation` (order, head, cookie, data), `valid_chains` (used element id / len) |
| Storage / network backend faults | `storage_faults`, `storage_durability`, `storage_silent`, `fault_sweep_in/out`, `bridge_echo_mismatch`, `bridge_orphan_responses`, `bridge_silent_endpoint`, `citadel_timeout_fail_closed`, `net_rx_bad_frames`, `net_rx_no_buffer`, `net_rx_buffer_problems`, `net_rx_unmatched`, `net_tx_checks` |

## 4. Defects found by the process

Honest account (the new code was derived from a verified design, so few were expected):

1. **`busy` status ignored a pending notification** (RTL). Found by `multi_per_domain_counters`: the controller is *idle but not quiescent* for a cycle while a kick is pending, so `STATUS.busy` could read 0 and a quiescence check returned with a beat still to come. The reset path itself waits on `engine_idle` with `drain` already asserted (which blocks the start of new work), so it was not affected; the status bit the hypervisor polls was wrong. Fixed (`work_pending` → busy).
2. **Storage-timeout response routing** (RTL, found in self-review before it was ever run): the owner of a timed-out request would not have received its error response (`st_out` is cleared in the same cycle the pulse is registered). Fixed; `storage_silent` covers it.
3. **Mutant M09** (window upper bound off by one byte) **survived the first mutation run**: the Citadel layer masked it (a beat one byte past the window was refused one layer down). New tests `layer_boundaries` and `window_gap_and_lower_bound` narrow each layer in turn with the others wide
   open; the mutant is now killed.
4. Test-side defects found and fixed along the way (not RTL): wait windows shorter than the workload's cycle count (the design runs at ≈ 0.65 B/cycle), a model that updated its storage image before the submission succeeded, a vacuous check in the SV bench.

## 5. How to run

```
make lint hostlib check_regs svtb example     # static, host library, pure-SV benches, definition-of-done demo
make t1                                       # five builds, tier 1
make t2                                       # tier 2 (needs tier 1)
make t3 ITERS=150 SEED=3                      # tier 3 (needs tier 2)
make perf                                     # performance sweep -> reports/perf_sweep.md
make mutate                                   # 34 mutants (about 12 minutes)
make regress                                  # everything above with gating, several random seeds, logs in reports/logs/
```

Tools: Verilator ≥ 5 (the pip wheel `verilator` works; it needs `-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include`, set in the Makefile), a C / C++ compiler, python3, zip. Build time of one configuration: about 10–25 s.
