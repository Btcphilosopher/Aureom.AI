# 00 — Repository audit and reuse decisions

**Project 87 VirtualFoundry · SilicaFlux Albion** · delivered as this archive — **nothing was committed to GitHub**.

## 1. What was audited

The repository (`btcphilosopher/Aureom.AI`, working tree as cloned) keeps the SilicaFlux work almost entirely inside zip archives
(`SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`); there is **no loose RTL and no `rtl/albion/` directory** in the repository
itself. The archives that could hold a VirtIO block, a PCIe/host bridge, a DMA, a storage or network subsystem, a fabric, a permission checker or a
host runtime were extracted into a scratch directory (untrusted data, never executed) and read: `silicaflux-virtualio-p63`,
`silicaflux-clouddma-p64`, `silicaflux-storagecore-p51`, `silicaflux-packetcore-p62`, `silicaflux-hostlink-project25`, `silicaflux-controlcore`,
`silicaflux-datafabric`, `silicaflux-meridian-p83`, `silicaflux-keystone-p82`, `silicaflux-clouddpu-p61`, `albioncore-0.1.0`.

## 2. The names in the brief

*Albion*, *Keystone*, *Meridian*, *BridgeEngine*, *PacketForge*, *VirtualFoundry* and *Citadel* are code names. Project 83's audit (`docs/meridian/00_AUDIT.md`)
already mapped them onto real blocks; this project adopts that map and extends it:

| Brief name | Real block in the repository | Role for VirtualFoundry | In this project |
|---|---|---|---|
| VirtualFoundry | **VirtualIO (P63)** — a verified single-queue virtio-blk engine | the block being built | derived (§3) |
| Citadel | no module; role = permission check (CloudDMA `sfdma_perm_checker`, P64). P83 defines the **check interface** and a **reference table** | per-beat policy authority | P83 `sf_meridian_citadel_ref` + `sf_meridian_pkg` **vendored unmodified** (sha256 in `third_party/p83/SHA256SUMS`); interface = `cit_*` ports of `sf_virtual_bridge` |
| BridgeEngine | CloudDMA (P64) data mover + HostLink (P25) | protected host-memory path | contract = the **Albion master port** of P83 (`bdg_*`); bench model in the test platform (not integrated) |
| PacketForge | PacketCore (P62) | network backend | contract = the PacketCore stream interface (`pf_s_*`, `pf_m_*`); bench model (not integrated) |
| StorageCore | StorageCore (P51) — an SoC with NVMe-like SQ/CQ queues, command controller, firmware and NAND model | block backend | contract = a byte-addressed read / write / flush port (`st_*`); bench model with a volatile write cache (not integrated, §4) |
| ControlCore / Keystone | ControlCore (P21), Keystone (P82) | management plane | the privileged management page (`mgmt_*`) is what Keystone programs; not integrated |
| DataFabric / Meridian | DataFabric (P22), Meridian (P83) | system fabric | VirtualFoundry is **master 3 / target 4** of the Albion configuration; the transaction format of P83 is used on `bdg_*` |
| PCIe host bridge | HostLink (P25), ExtMem bridge (P24) | host attachment | **not used**: the guest-visible transport is virtio-mmio (§4) |
| Linux host runtime | none; Project 63 shipped a small C library | host test library | derived: `runtime/virtual_foundry/` |

## 3. What was reused and how

**Vendored unmodified (byte-identical to the archive, hash-proven):**

| file | sha256 | used as |
|---|---|---|
| `third_party/p83/sf_meridian_pkg.sv` | `ae509d1ba241ecc3d3a36802b86ba62681c7414edfa225c0585e92c92ee38e8d` | package of the reference Citadel; also the source of truth for the Albion constants (checked by `tb_pkg_consistency`) |
| `third_party/p83/sf_meridian_citadel_ref.sv` | `6a4b7631c3cc95b1a10588284a10beac19f0b570cbaf2f7ac54bb60eb3729415` | the Citadel in every co-simulation and in `tb_vf_io` |

**Derived from Project 63 (VirtualIO)** — same algorithms, copied and then changed where the brief needs more. Each derived file carries a header naming
its origin. Amount of change (code lines, comments ignored; `abort` was renamed `drain` everywhere because newer Verilator reserves the word):

| P63 file | P87 file | change |
|---|---|---|
| `silicaflux_virtio_desc_walker.sv` | `sf_virtual_descriptor.sv` | **none** beyond the rename (same validation order, same termination argument) |
| `silicaflux_virtio_queue_ctrl.sv` | `sf_virtual_queue.sv` | +19 lines: `RXQ` / `work_gate` for the device-initiated receive queue, `more_pending`, `work_pending` (busy covers a pending kick) |
| `silicaflux_virtio_domain_perm.sv` | `sf_virtual_gate.sv` | +28: traffic class passes through; `NCHK` pre-check ports (one per queue) |
| `silicaflux_virtio_blk_backend.sv` | `sf_virtual_storage_adapter.sv` | +80: capacity became a per-context **extent** {base, size, read-only}; request-level **direction checks**; read-only extent; completion event pulses |
| `silicaflux_virtio_dma_arb.sv` | `sf_virtual_dma_arb.sv` | +21: round robin instead of fixed priority; traffic class of the granted client |
| `silicaflux_virtio_mmio_transport.sv` | `sf_virtual_transport.sv` | rewritten around it (+271): N queues, two device kinds, link status → configuration change, host reset, per-queue disable |
| `silicaflux_virtio_mgmt.sv` | `sf_virtual_ctx_mgmt.sv` | rewritten around its counters (+345): new register map, first-fault capture, extent / MAC, host reset, queue waiting time, per-queue latency |
| `host/src/sfv_core.c`, `sfv_blk.c`, `include/sfvirtio.h` | `vf_core.c`, `vf_blk.c`, `vf_host.h` | renamed; used-index sanity check; multi-queue |

P63's evidence (23 directed tests, 1 400 random scenarios, 16/16 mutants, a Rust model) **does not transfer** to the derived files; everything is re-verified here
(07_VERIFICATION.md). The Rust reference model of P63 was not reused: the independent model in `tests_random.cpp` was written from the documented contract.

**New in this project:** `sf_virtual_bridge` (Citadel check + Albion master port + per-context counters + silent-endpoint isolation),
`sf_virtual_network_adapter` (virtio-net over the PacketCore stream), `sf_virtual_ctx` / `sf_virtual_io` (contexts, storage arbiter, PacketForge
multiplexer), the storage-response timeout, the simulation platform with its independent monitors, the test suite, the mutation campaign.

## 4. Decisions

* **Device first: virtio-blk.** The only tested VirtIO infrastructure in the repository is P63's block engine, so the single-queue, single-guest model starts from it
  (brief §2). virtio-net was added only after the isolation tests passed (Makefile gating: `t1 → t2 → t3`).
* **virtio-mmio, not virtio-pci.** No verified PCIe block exists to attach to; claiming PCIe or SR-IOV because several virtual queues exist would be wrong. A "guest
  context" is a separate virtio-mmio **device** with its own register window, interrupt, protection domain, windows, rings and storage extent.
* **Three enforcement points** instead of P63's one: local windows (kept — they give all-or-nothing range checks, which the Citadel's per-address query cannot), the
  **Citadel** (default deny, fail closed) and the **BridgeEngine** (its own protected-DMA check). A guest-provided address is never a valid DMA address by itself.
* **Storage and network are ports, not integrations.** P51 and P62 were not instantiated: P51 is a firmware-driven SoC with a different (queue pair) interface and
  P62 is a stream processor whose frames are not acknowledged back. The adapters define the contract a shim must meet; the bench models in `tests/` implement it.

## 5. Gaps found that this project does not close

* The Albion transaction format and the Citadel have no real implementation in the repository: P83's definitions and reference model are used.
* BridgeEngine, StorageCore and PacketForge are **not integrated**; bench models stand in (08_LIMITATIONS.md).
* No licence file. No synthesis, place-and-route, timing, area or power result exists for this project (none was run) — Verilator lint and simulation only.
* No Linux guest driver was run against the model.
