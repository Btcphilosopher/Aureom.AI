# 06 — Performance

All numbers are **simulation cycle counts** of the RTL (Verilator) with the bench models; no clock frequency, area or power is implied or claimed. Reproduce with `make perf`
(output also in `reports/perf_sweep.md`).

## 1. What is measured (brief §9)

| Quantity | Counter (02 B.1 / B.2) |
|---|---|
| Descriptors processed | `PERF_DESC` |
| Queue waiting time | `PERF_QW_*`: kick (or previous completion with a backlog) → head fetch |
| DMA bytes | `PERF_RD_BYTES`, `PERF_WR_BYTES` (context) and per-domain `RD_BYTES` / `WR_BYTES` (bridge): checked equal to an independent count of the beats the BridgeEngine saw |
| Completion latency | `PERF_CLAT_*`: head fetch → `used.idx` published; bridge-level latency per context |
| Interrupt count | `PERF_IRQ` raised / `PERF_IRQ_SUP` suppressed |
| Backend stalls | `PERF_STALL` (request not accepted), `PERF_BEWAIT` (waiting for a response), `VF_B_STALL` (beat waiting in the bridge) |
| Invalid requests | `PERF_INVALID` (+ `PERF_VIOL`, `PERF_FATAL`, device direction-error counter) |
| Per-domain traffic | bridge counters per context: beats, read / write bytes, Citadel denials, errors, timeouts |

## 2. Results (default configuration, bridge and storage latency 1 unless stated)

| Request | cycles / request | bytes / cycle |
|---|---|---|
| IN or OUT 512 B | 899 | 0.57 |
| IN or OUT 4 KiB | 6 274 | 0.65 |
| IN or OUT 16 KiB | 24 706 | 0.66 |
| FLUSH (no data) | 115 | — |
| IN 4 KiB, buffer at offset +1 / +3 / +7 | 12 418 | 0.33 |

| BridgeEngine latency (cycles) | 1 | 4 | 16 | 64 |
|---|---|---|---|---|
| IN 4 KiB, bytes / cycle | 0.65 | 0.52 | 0.29 | 0.10 |

| Guests streaming IN 4 KiB (depth 2 each) | 1 | 2 | 3 |
|---|---|---|---|
| aggregate bytes / cycle | 0.65 | 1.30 | 1.56 |
| per guest | 0.65 | 0.65 | 0.52 |

Mixed random workload (back-pressure 30 %, latency up to 6): average completion latency ≈ 3 800 cycles, average queue waiting time ≈ 19 cycles, one descriptor walk ≈ 72 cycles, one interrupt per
completion, 8 737 bridge beats at an average of 6.0 cycles per beat.

## 3. Why it is slow, and what is deliberate

* **One DMA beat outstanding per context, one in the bridge.** Each 8-byte beat costs ≈ 12 cycles of handshaking through arbiter → gate (registered check) → bridge (arbitrate, Citadel,
  issue, response) even with 1-cycle endpoints; that is the 0.65 B/cycle ceiling. This was chosen for correctness (trivially correct response routing, ordering, reset draining, one
  zombie at most), not for speed. It is a functional baseline for the isolation and protocol work, not a performance claim.
* **Alignment.** An 8-byte beat never crosses a guest word, so a misaligned buffer needs one extra beat per word: half the throughput.
* **Multiple guests scale** until the shared bridge saturates (2 guests ≈ 2×, 3 guests ≈ 2.4×).

## 4. Roadmap (not done)

1. Burst DMA on the Albion port (the format is single-beat; a burst extension would be a Meridian change).
2. Several beats outstanding per context with tagged completions (needs the out-of-order mode of Meridian).
3. A pipelined Citadel check overlapped with the gate (the interface already allows a registered verdict: `CIT_LAT = 1` is regression-tested).
4. Descriptor prefetch and avail-ring batching (the controller re-reads `avail.idx` once per request).
5. Wider data path (the engine is 64-bit).
