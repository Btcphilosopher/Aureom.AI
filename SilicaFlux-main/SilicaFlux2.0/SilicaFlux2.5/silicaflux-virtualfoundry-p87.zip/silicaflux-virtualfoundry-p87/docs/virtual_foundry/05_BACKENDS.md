# 05 — Backend contracts: storage and network

Both backends are **ports**. The adapters define the contract; the bench models in `tests/virtual_foundry/sim/vf_sim.cpp` implement it. A real StorageCore / PacketForge needs a shim that
meets these contracts (08_LIMITATIONS.md).

## 1. Storage (`st_*`, `sf_virtual_storage_adapter` + storage arbiter in `sf_virtual_io`)

| Signal | Meaning |
|---|---|
| `st_req_valid/ready` | request handshake; **one request outstanding** across all block contexts (round-robin arbiter) |
| `st_req_op` | `0` READ, `1` WRITE, `2` FLUSH |
| `st_req_addr` | **byte** address, 8-byte aligned (`SADDR_W` bits); already translated by the context's extent (`(ext_base + sector) × 512`) |
| `st_req_wdata`, `st_req_be` | 64-bit write data and contiguous byte enables (a request never crosses an 8-byte word) |
| `st_req_dom` | the context's protection domain, for a backend that wants a second check |
| `st_resp_valid/rdata/err` | exactly one response per accepted request; `err = 1` is a storage error |

**Semantics the device relies on and preserves** (01 §7): requests execute one at a time and in order; a completion is published only after every response of the request; FLUSH =
exactly one `op = 2`, IOERR on error; writes are never reordered across a later flush; nothing is acknowledged that storage did not acknowledge; a failed OUT may leave a prefix
written but never touches sectors outside its range. Storage errors: IN → IOERR with zero fill after the failing byte; OUT → IOERR; FLUSH → IOERR; all counted
(`DEVCNT[6]`). An unresponsive backend is bounded by `ST_TMO` (error response, then isolation, 05 §3).

Bench model: byte store with a **volatile write cache** (`stor`, readable) and a durable image (`stor_dur`); FLUSH copies the dirty sectors; `power_loss()` reverts un-flushed sectors;
bad read / write sectors, failing FLUSH, programmable latency and back-pressure, a silent mode, an operation log. It asserts one request outstanding and re-checks every access against the owning
context's extent.

## 2. Network (`pf_s_*`, `pf_m_*`, `sf_virtual_network_adapter` + multiplexer in `sf_virtual_io`)

PacketCore stream contract (P62 `docs/INTERFACE.md`), `DW = 64`:

| Direction | Signals | Rules used here |
|---|---|---|
| to PacketForge (ingress `s_*`) | `valid/ready`, `data`, `keep`, `last`, `err`, `src`, `meta` | byte 0 of the frame = `data[7:0]` of beat 0; `keep` all ones except the last beat, where it is a contiguous low-order mask; `err` only on the last beat (always 0: frames are store-and-forward, never partial); **`src` = the context index, `meta` = its protection domain** |
| from PacketForge (egress `m_*`) | `valid`, `data`, `keep`, `last`, `err`, `queue` | `queue` selects the destination context (network contexts only); `ready` is **always 1** |

Frames exclude the FCS (PacketCore's convention). The shared ingress is frame-atomic round robin: a context holds the stream only from its first beat to its `last` beat, and it only
starts when the **whole frame is already in its buffer**, so its own DMA can never stall the stream.

**Completion semantics.** Transmit `used.len = 0`: *the frame was accepted by the stream* — PacketCore does not report its later drop / forward decision back. Receive `used.len = 12 + frame`.

**Error propagation** (all counted in the context's device counters, 02 B.1): illegal header / size / direction / refused read → frame dropped, buffer returned; arriving frame
runt / oversize / MAC-flagged / malformed `keep` → dropped, never delivered; buffer busy or device not enabled → tail-dropped; unusable receive buffer → returned unused with the frame kept; DMA
fault while writing a receive buffer → DEVICE_NEEDS_RESET.

Bench model: transmit sink that **protocol-checks every beat** (keep legality, `last` boundaries, no interleaving, `err = 0`, `meta` = the domain of `src`); receive source with programmable
gaps and arbitrary (even illegal) beat sequences; per-context link status.

## 3. Silent endpoints

| Port | Timeout | Behaviour |
|---|---|---|
| BridgeEngine | `RSP_TMO` | the beat fails; an issued-and-silent beat leaves a zombie: all new beats are denied at once until its late response (tag match) arrives, which is consumed and dropped |
| StorageCore | `ST_TMO` | same rule on the shared storage port (`storage_silent`: other guests fail fast, a guest reset still completes, the late response ends the isolation) |
| PacketForge ingress | `PF_TMO` | a ready frame that PacketForge never accepts is dropped; a stall *inside* a frame is not bounded (PacketCore's contract bounds it by its queue depth) |
