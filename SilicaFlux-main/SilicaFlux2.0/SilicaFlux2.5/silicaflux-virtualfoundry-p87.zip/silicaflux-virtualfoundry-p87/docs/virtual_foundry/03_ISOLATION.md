# 03 — Isolation: trusted domains, protected DMA, buffer ownership, completion visibility

> *A domain number is a label software can lie about* (CloudDMA, `docs/03_PROTECTION.md`). A guest-provided address is not a valid DMA address merely because the guest wrote it into
> a descriptor, and the device never relies on a domain tag being honest.

## 1. Trust model

* **Trusted:** the hardware, the management plane (Keystone / hypervisor, the only writer of the management bus), the Citadel policy, the BridgeEngine.
* **Untrusted:** everything a guest controls: register writes, ring contents, descriptors (addresses, lengths, flags, indices, chains), buffer contents, timing of its own
  notifications, its choice to reset or never to supply buffers.
* **A context is bound to exactly one protection domain** by the management plane only. The binding is locked while any queue of the context is enabled. The guest has no register
  that names a domain, a window or an extent.

## 2. Three independent enforcement points (every guest-controlled DMA beat passes all three)

| # | Where | Rule | On violation |
|---|---|---|---|
| 1 | `sf_virtual_gate` (per context) | the exact byte range of the beat lies inside **one** valid window that carries the bound domain and grants the direction; ranges that straddle two windows or wrap past 2⁶⁴ are denied. The descriptor walker applies the same rule to each **whole buffer** before any data moves (all-or-nothing) | error response to the engine; fault source GATE / DESC |
| 2 | `sf_virtual_bridge` → **Citadel** | one query `{domain, priv = 0, write, address}` per beat; *default deny*; no verdict within `CHK_TMO` → denied (fail closed); a domain too wide for the field is denied, never truncated | the beat never reaches the BridgeEngine; fault source CITADEL with the Citadel's code |
| 3 | **BridgeEngine** (Albion master port) | its own protected-DMA check; the response echo (tag, domain, opcode) is verified; a non-OKAY status or an echo mismatch is an error, never data | fault source BRIDGE / ECHO |

Why windows *and* the Citadel: the Citadel's check interface takes one address, not a range, so it cannot give all-or-nothing buffer semantics; the windows can. The Citadel is the
policy authority; the windows are the context's own enforceable copy. A defect in either layer is caught by the other **and** by the suite on its own (`layer_citadel_alone`,
`layer_window_alone`, `layer_bridge_alone`, `layer_boundaries`).

## 3. Buffer ownership

* A buffer the guest names is accessed only inside its domain's windows (above). Region ownership is therefore a property of the management configuration, not of the descriptor.
* **Storage:** each context owns an **extent** {base, size, read-only} programmed by the management plane (locked once the driver started); every request is range-checked against it
  (overflow-safe) before any storage access. `iso_storage` tries sector numbers that belong to the other guests' extents (both edges of each) and huge / wrapping values, with reads and writes: not one byte of the shared
  storage changes and nothing leaks into the attacker's buffer. The independent monitor re-checks every storage access against the owning context's extent.
* **Network:** each context has its own frame buffers; frames are steered to a context by the queue id and only to network contexts; nothing is shared between contexts except the
  arbitrated streams. A context that never supplies buffers cannot block anyone (tail-drop).
* **Ownership of a posted buffer** ends at completion: the device writes the used element and index only for the request it executed, into the ring of the queue that submitted it.
  Requests of a queue execute strictly in order and one at a time; the same head cannot be in flight twice.

## 4. Completion visibility

The guest observes a completion only through `used.idx` (and its interrupt). The device writes, in this order, each acknowledged by the platform before the next is issued:
payload / status bytes → `used.ring[slot] = {id, len}` → `used.{flags, idx + 1}` → (re-read of `avail.flags`) → interrupt request. `completion_visibility` polls the used index **every cycle**
under random back-pressure and checks that, at the instant it moves, the element, the status byte and the payload (IN) or storage (OUT) are already final. A completion is only ever
written into the ring of the queue that submitted the request, so no context sees another's completions (`multi_irq_independence`, per-domain counters).

## 5. Fault containment

A malformed guest halts **its own context**: DEVICE_NEEDS_RESET, queue halted, first fault captured (source, address, detail) in its own management page. `iso_fault_containment` makes one guest
cause every kind of fatal error twelve times while two neighbours run continuous traffic; the neighbours see no error, no reset, no violation, and their data is byte-exact.
Reset of one context (guest-driven or hypervisor-driven) does not disturb the others and produces no further DMA on behalf of the reset context (`iso_reset_containment`).

## 6. Shared resources and what they can and cannot do

| Shared | Arbitration | Isolation property | Documented limit |
|---|---|---|---|
| BridgeEngine port, Citadel port | round robin, one beat outstanding | a beat is owned by one context; round robin bounds waiting to one beat per other context | a **silent** BridgeEngine stalls every context for up to `RSP_TMO`, after which the bridge isolates and all contexts fail fast until the late response arrives; an unresponsive Citadel delays every context by `CHK_TMO` per attempt (then fail-fast for 8 × `CHK_TMO`) |
| StorageCore port | round robin, one request outstanding | extents; owner-routed responses | same silent-endpoint rule with `ST_TMO` |
| PacketForge ingress | frame-atomic round robin | frames are store-and-forward, so no guest can hold the stream | PacketForge itself must not stall indefinitely mid-frame |
| PacketForge egress | always ready | steered by queue id; tail-drop in the context | frames for an absent context are counted and dropped |

## 7. Revocation

A window or Citadel change applies to every access whose check starts after the change; at most one already-authorised beat can complete. Before re-assigning revoked memory the
hypervisor must either see `STATUS.busy = 0` or reset the context (the same rule CloudDMA states).

## 8. What is NOT claimed

* No side-channel isolation: shared arbiters, the bridge and the Citadel are observable through latency.
* No protection against a compromised management plane or against the platform violating the write-visibility requirement of 01 §6.
* The reference Citadel is a **model** (`sf_meridian_citadel_ref`, default-deny table); `priv` is always 0 from this engine and is not authenticated here.
* The BridgeEngine, StorageCore and PacketForge are bench models; their own enforcement is exercised, not proven.
* Formal proof of the gates was not done (the suite is simulation + an independent monitor + mutation).
