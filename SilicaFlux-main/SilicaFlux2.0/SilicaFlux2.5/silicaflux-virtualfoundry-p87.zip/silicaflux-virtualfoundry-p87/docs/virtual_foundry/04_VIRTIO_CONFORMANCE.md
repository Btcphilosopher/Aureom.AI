# 04 — VirtIO conformance subset

Normative reference: OASIS *Virtual I/O Device (VIRTIO) Version 1.2*, committee specification 01 (virtio-v1.2-cs01). **Only the subset below is implemented**; the device never advertises
anything it does not implement (checked by `negotiate`, `net_identity`: every unoffered feature bit is tried and FEATURES_OK must be refused).

## 1. What is offered

| Item | Block (device 2) | Network (device 1) |
|---|---|---|
| Transport | virtio-mmio v2 (§4.2) | same |
| Queue layout | **split** virtqueue (§2.7), `MAX_QSZ` ≤ 32768 | split, receiveq 0 + transmitq 1 |
| Device features | `VERSION_1`, `ACCESS_PLATFORM`, `BLK_F_SEG_MAX`, `BLK_F_FLUSH`, `BLK_F_RO` (only for a read-only extent) | `VERSION_1`, `ACCESS_PLATFORM`, `NET_F_MAC`, `NET_F_STATUS` |
| Required of the driver | `VERSION_1`, `ACCESS_PLATFORM` (every buffer address is an IOVA checked by the windows, the Citadel and the BridgeEngine) | same |
| Requests | `T_IN`, `T_OUT`, `T_FLUSH` (only if negotiated), `T_GET_ID`; everything else → `S_UNSUPP` | tx: `{virtio_net_hdr(12), frame}`; rx: one writable chain per frame |
| **Not offered** | packed ring, `INDIRECT_DESC`, `EVENT_IDX`, `IN_ORDER`, `NOTIFICATION_DATA`, `RING_RESET`, `SR_IOV`, `BLK_F_MQ`, `SIZE_MAX`, `DISCARD`, `WRITE_ZEROES`, secure erase, virtio-pci | `MRG_RXBUF`, `CSUM` / `GUEST_CSUM`, TSO / UFO / ECN, `CTRL_VQ`, `MQ`, `RSC` |

## 2. Clause checklist

| Spec clause | Requirement (summary) | Status | Evidence |
|---|---|---|---|
| 2.1, 2.1.2 | status bits; driver sets bits only; reset on 0; DEVICE_NEEDS_RESET device-owned; configuration-change interrupt when raised | implemented | `negotiate`, `reset_*`, `mal_*` |
| 2.2, 3.1.1 | feature negotiation; FEATURES_OK withheld for unoffered / missing required features; frozen after FEATURES_OK | implemented | `negotiate`, `net_identity` |
| 2.7 | split ring; free-running 16-bit indices; slot = idx & (N−1) | implemented | `ring_wrap`, `index_wrap16` (65 600 requests through 0xffff → 0) |
| 2.7.2 | alignment 16 / 2 / 4 | validated at QueueReady = 1 | `queue_config_invalid` |
| 2.7.4 | descriptor chains; readable before writable | validated | `valid_chains`, `mal_order` |
| 2.7.5 | `struct virtq_desc` {le64 addr, le32 len, le16 flags, le16 next} | exact layout | all descriptor tests; `tb_pkg_consistency` (16 bytes) |
| 2.7.8, 2.7.8.2 | used ring `{le32 id, le32 len}`; **len = bytes written** starting at the first writable buffer | implemented; whole writable stream written | `completion_visibility`, `valid_chains`, `request_errors` |
| 2.7.13 | publish order (element, then index); chain length < 2³² | implemented | `completion_visibility`, `mal_len_overflow` |
| 2.7.13 | device must not accept `avail.idx` more than N ahead | fatal AVAIL_IDX_JUMP | `mal_avail_jump` |
| 2.7.6 – 2.7.7 | `VIRTQ_AVAIL_F_NO_INTERRUPT` | implemented | `interrupts` |
| 3.1.1 | no buffers consumed before DRIVER_OK | implemented | `no_domain`, `net_reset_discards_frames` |
| 4.2.2 | register layout, MagicValue / Version / DeviceID / VendorID, ConfigGeneration, SHM = `0xffffffff` | implemented | `identity` |
| 4.2.2 | reset: the device must be quiescent when the driver sees the status as 0 | implemented (drain before the bus write completes) | `reset_device_midflight` |
| 5.2.4 | block config: capacity, seg_max | implemented; capacity = the context's extent | `basic_rw`, `iso_storage` |
| 5.2.6 | block request: header 16 bytes, payload, status last; 512-byte sectors | implemented | all block tests |
| 5.2.6 | the device MUST NOT write device-readable buffers; unsupported → `UNSUPP` | implemented | `request_errors`, `random_blk_*` |
| 5.1.4 | network config: mac, status | implemented | `net_identity` |
| 5.1.6 | `virtio_net_hdr` 12 bytes with VERSION_1; `num_buffers = 1` without MRG_RXBUF | implemented | `net_rx_basic`, `tb_pkg_consistency` |
| 5.1.6 | driver must not request offloads that were not negotiated | header validated; violating frames dropped and counted | `net_tx_checks` |

## 3. Choices the specification leaves to the device (all documented and tested)

* A device-readable descriptor in a receive chain, or a receive buffer too small for header + frame: the buffer is returned with `len = 0` and the frame is kept.
* A transmit chain that carries a device-writable descriptor, an illegal frame size or an offload header: the buffer is returned, the frame is dropped.
* Zero-length descriptors are accepted and ignored.
* `T_IN` with a readable payload (and the mirror cases) is a per-request error (`IOERR`), not a reason to reset the device.
* Unknown request types complete with `S_UNSUPP`, not NEEDS_RESET.

## 4. Not verified against a real driver

No Linux `virtio_mmio` / `virtio_blk` / `virtio_net` driver and no VMM (QEMU, Firecracker) was run against this model; the guest side is the project's own library. Conformance above is
claimed against the specification text, not against an independent driver implementation.
