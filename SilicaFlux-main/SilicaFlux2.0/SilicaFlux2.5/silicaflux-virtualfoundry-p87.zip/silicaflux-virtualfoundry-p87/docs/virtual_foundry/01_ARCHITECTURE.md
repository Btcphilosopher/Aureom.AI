# 01 — Architecture

## 1. Block diagram

```
  guest 0 ... guest N-1 (one virtio-mmio window + one interrupt each)        hypervisor / Keystone (privileged management page)
        |                                                                                  |
  +-----v-------------------------------- sf_virtual_ctx (x NCTX) ----------------+       |
  | [transport]  features, status, queue config, reset / drain, interrupt          |<------+  domain, windows, extent, MAC,
  |    |  notify, per queue:                                                        |          faults, counters, host reset
  | [queue controller] + [descriptor walker]  (split ring, validation)             |
  |    |  SG list / head                                                           |
  | [device adapter]  storage (virtio-blk)  |  network (virtio-net rx + tx)        |
  |    |  DMA clients: queue ctl / walker / adapter -> [round-robin arbiter, 1 beat] -> [window gate]  --> d_* (domain tag)
  +----|-------------------------------------------------------------------------+
       | storage beats                          | window-checked DMA beats                     | frames
  [storage arbiter + timeout]            [sf_virtual_bridge]: arbitration -> Citadel check -> Albion master port      [PacketForge mux / demux]
       |  st_*                                  |  cit_*                        |  bdg_*                                    |  pf_s_* / pf_m_*
   StorageCore                              Citadel                       BridgeEngine -> host memory                 PacketForge
```

| File | Role |
|---|---|
| `sf_virtual_io.sv` | **primary RTL**: contexts, bridge, storage arbiter, PacketForge multiplexer, management bus decode, global page |
| `sf_virtual_ctx.sv` | one guest context (one virtio device): transport + queues + adapter + arbiter + gate + management page |
| `sf_virtual_transport.sv` | virtio-mmio v2: features, status machine, queue configuration, quiesced reset, interrupts |
| `sf_virtual_queue.sv` | split-ring controller: avail / used indices, completion publication, interrupt suppression |
| `sf_virtual_descriptor.sv` | descriptor-chain walker and validator, scatter-gather list |
| `sf_virtual_storage_adapter.sv` | virtio-blk request execution over a byte port; extents; durability ordering |
| `sf_virtual_network_adapter.sv` | virtio-net rx / tx over the PacketForge stream; store-and-forward frame buffers |
| `sf_virtual_gate.sv` | per-context window table + per-beat DMA gate |
| `sf_virtual_dma_arb.sv` | per-context round-robin arbiter, one beat outstanding |
| `sf_virtual_bridge.sv` | Citadel check, Albion master port, per-context traffic counters, zombie isolation |
| `sf_virtual_ctx_mgmt.sv` | privileged page of a context: binding, windows, extent, faults, counters, host reset |
| `sf_virtual_pkg.sv` | constants (VirtIO 1.2, Albion P83, fatal causes) |

Interfaces of the top (`sf_virtual_io`): per-context `mmio_*` + `irq`; `mgmt_*` (16-bit address: `[15:12]` page, `0..NCTX-1` context, `0xF` global);
`cit_*` (Citadel); `bdg_*` (Albion master); `st_*` (storage); `pf_s_*` / `pf_m_*` / `pf_link_up` (PacketForge).

## 2. Block request lifecycle

1. **Notify.** The driver writes QueueNotify; the controller sets `pending`. Processing starts only when QueueReady, DRIVER_OK, FEATURES_OK, not FAILED, not NEEDS_RESET and a
   domain is bound hold (spec 3.1.1).
2. **Available ring.** `avail.idx` (2 B) is read; `idx − last_avail > QueueSize` is fatal (AVAIL_IDX_JUMP). Otherwise `avail.ring[last_avail & (N−1)]` is read.
3. **Walk** (§4) builds the scatter-gather list: readable segments first, then writable ones; zero-length descriptors are dropped; each non-empty segment is range-checked
   against the domain's windows **before** any data moves.
4. **Execute.** The chain is two byte streams: R = readable segments (`virtio_blk_req` header = first 16 bytes, then the OUT payload) and W = writable segments (IN
   payload / GET_ID string, **status = last byte**). No assumption is made about how the driver split the request. One step moves ≤ 8 bytes and never crosses a guest
   segment, a guest 8-byte word or a storage 8-byte word, so any alignment works by lane shifting.
5. **Complete.** The **whole writable stream** is written (payload, zeros where there is none, status last); then `used.ring[slot] = {id, len = W}` (two le32 writes),
   then `used.{flags = 0, idx + 1}` (one le32 write), then `avail.flags` is re-read and an interrupt is requested unless `VIRTQ_AVAIL_F_NO_INTERRUPT` is set.

Because the whole writable stream is always written, `used.len` is truthful for every completion including errors (spec 2.7.8.2).

## 3. Network lifecycle (virtio-net, receiveq = queue 0, transmitq = queue 1)

* **Transmit.** Chain = {12-byte `virtio_net_hdr`, frame}, all device-readable. The frame is first **read completely into a per-context buffer**; the header is validated
  (`flags = 0`, `gso_type = NONE`: no offload was negotiated); only then is the frame streamed to PacketForge (64-bit beats, `keep` all-ones except the last, `last`, `err = 0`).
  Completion (`used.len = 0`) means *handed to PacketForge*, not *on the wire*.
* **Receive.** An arriving frame is stored completely (one frame buffer per context). The receive queue consumes a buffer **only while a complete frame is waiting**
  (`work_gate`). The buffer must be one device-writable chain holding header + frame (`MRG_RXBUF` is not offered): the device writes the 12-byte header
  (`num_buffers = 1`) and the frame, and reports `used.len = 12 + frame`. An unusable buffer (too small, or carrying a device-readable descriptor) is returned with `used.len = 0`
  and **the frame is kept** for the next buffer.
* **Never blocks the shared stream.** The egress `pf_m_ready` is constant 1. When a context's frame buffer is occupied, an arriving frame is tail-dropped and counted.
  Transmit is store-and-forward so a guest whose DMA stalls or is denied cannot leave a partial frame on the shared ingress or hold its arbitration.

## 4. Descriptor validation (exact order; the independent model uses the same)

For each descriptor: (1) `idx ≥ QueueSize` → DESC_IDX_OOR; (2) already visited in this chain → CHAIN_LOOP (exact: a `MAX_QSZ`-bit bitmap); (3) `MAX_CHAIN` descriptors already taken →
CHAIN_TOO_LONG; (4) fetch two 8-byte words (a DMA error → RING_DMA); (5) `flags & ~(NEXT|WRITE)` → DESC_FLAGS (INDIRECT is not offered); (6) readable after writable →
CHAIN_ORDER; (7) running total ≥ 2³² → CHAIN_LEN_OVF; (8) `len > 0` and not permitted by the windows: writable → **WRITABLE_PERM** (fatal), readable → the request completes
with an I/O error and nothing is read. Termination is independent of guest memory (steps 2 and 3).

Where each item of the validation list of the brief is checked: **address** (window gate, Citadel, BridgeEngine; steps 4 and 8), **length** (step 7, zero-length descriptors ignored, block lengths a
multiple of 512, network frame bounds), **alignment** (descriptor table 16 / available ring 2 / used ring 4 bytes at QueueReady = 1; guest *buffers* have no alignment requirement in the specification
and any alignment works by lane shifting — a misaligned buffer only costs extra beats), **chain structure** (steps 1–3, 5, 6), **direction** (step 6 plus the request-level direction checks of 5),
**write permission** (steps 4 and 8, direction-specific windows), **queue bounds** (steps 1, 4 and the avail-index check), **loops** (step 2), **maximum chain length** (step 3).

## 5. Error policy

| Situation | Response |
|---|---|
| Malformed ring or chain (steps 1–7, avail.idx jump, invalid queue configuration) | **DEVICE_NEEDS_RESET**, configuration-change interrupt if DRIVER_OK, the queue is halted until a reset (spec 2.1.2). No used entry for the bad request. |
| Fault on the descriptor table, available ring or used ring (window gate, Citadel, BridgeEngine) | DEVICE_NEEDS_RESET (RING_DMA) |
| Device-**writable** buffer outside the windows (pre-check) | DEVICE_NEEDS_RESET (WRITABLE_PERM), nothing written |
| Device-writable payload refused **mid-request** (Citadel / BridgeEngine denial, bus error) | DEVICE_NEEDS_RESET (DATA_WRITE_DMA): the request cannot be completed truthfully |
| Device-**readable** payload outside the windows / refused / bus error | block: completes with `VIRTIO_BLK_S_IOERR`; net tx: frame dropped, completion posted |
| **Direction errors** of an otherwise well-formed chain: IN with a readable payload, OUT with a writable payload, FLUSH / GET_ID with a payload | `VIRTIO_BLK_S_IOERR`, no data moved |
| Header < 16 bytes; length not a multiple of 512; sector range outside the extent (overflow-safe); write to a read-only extent; storage error | `VIRTIO_BLK_S_IOERR`; for IN the bytes after a storage failure are zero |
| Unknown type; FLUSH without negotiated `VIRTIO_BLK_F_FLUSH` | `VIRTIO_BLK_S_UNSUPP` |
| Net: header with offload bits, frame < 14 or > FBYTES bytes, device-writable descriptor on the transmit queue | frame dropped, completion posted (`used.len = 0`), counted |
| Net receive: runt / oversize / malformed stream / MAC-flagged frame | dropped, counted, never delivered |

A fault halts only the faulting context. A failed OUT may leave a prefix of its sector range written (virtio-blk promises no atomicity); sectors outside the request's range are
never touched (tested by a fault-injection sweep on every bridge beat of a request).

## 6. DMA contract and completion visibility

Every context has **one DMA beat outstanding** (round-robin arbiter, then the gate), and the bridge has one beat outstanding for all contexts. This makes response routing,
ordering and reset draining trivially correct at a throughput cost (06_PERFORMANCE.md). **Platform requirement:** a write *response* on `bdg_*` must imply that the write is
visible to the host CPU. The used element (and every payload beat) is acknowledged before the `used.idx` write is issued, so the guest can never observe an index whose element
or payload is not yet written; `completion_visibility` checks this every cycle against a polling guest.

## 7. Durability (storage)

Requests execute **one at a time and in order**. A completion is never published before every storage response of that request has returned; FLUSH issues exactly one
`SC_OP_FLUSH` and completes only after its response (IOERR if it fails); a write is never reordered across a later flush. The device therefore never acknowledges a write or flush that
storage did not acknowledge. What survives a power loss is up to the StorageCore: the bench model has a volatile write cache and `power_loss()` drops everything not flushed
(`storage_durability` checks acknowledged-but-unflushed data may vanish and flushed data may not).

## 8. Reset

* **Guest reset** (Status ← 0) and **queue disable** (QueueReady ← 0) are **quiesced**: the bus write is held off (`mmio_req_ready = 0`) until the affected engines have drained and
  every DMA / storage beat in flight has returned, so when the driver's write completes no device write can still land (`reset_*_midflight`: no beat after the reset returns).
* **Host reset** (`CTRL[0]` of the context page) drains and then performs the same reset; the management configuration survives.
* **Chip reset** (`rst_n`) clears everything, including the management configuration (default deny until the hypervisor re-provisions).
* A StorageCore or BridgeEngine that stops answering cannot hang a reset: `ST_TMO` / `RSP_TMO` convert it into an error response and isolate the port (§9).

## 9. Timeouts

| Parameter | Default | Meaning |
|---|---|---|
| `CHK_TMO` | 64 | cycles to wait for a Citadel verdict; none → denied (`F_CITTMO`); the bridge then answers at once, without querying, until a verdict arrives or 8 × `CHK_TMO` pass (a late verdict can never be mistaken for the next query's) |
| `RSP_TMO` | 2048 | BridgeEngine: a beat that could not be issued, or got no response, fails; an issued-and-silent beat leaves a **zombie**: new beats are denied at once until the late response arrives |
| `ST_TMO` | 4096 | StorageCore response; same zombie rule on the shared storage port |
| `PF_TMO` | 65536 | a complete transmit frame waits this long for PacketForge to accept its first beat, then is dropped |

## 10. Parameters

| Parameter | Default | Constraint (checked at elaboration) |
|---|---|---|
| `NCTX` | 1 | 1 … 15 |
| `CTX_KIND` | 0 | bit i: 0 virtio-blk, 1 virtio-net |
| `MAX_QSZ` | 256 | power of two, 2 … 32768 |
| `MAX_CHAIN` | 16 | power of two, 4 … 64 (block `seg_max = MAX_CHAIN − 2`) |
| `N_WIN` | 8 | power of two, 2 … 8 |
| `SADDR_W` | 40 | 16 … 56 (storage byte-address width) |
| `FBYTES` | 2048 | 64 … 16384 (frame buffer = maximum frame) |
| `DOM_W`, `TAGW` | 8, 4 | width of the Citadel / Albion domain and tag fields |
| `CHK_TMO`, `RSP_TMO`, `ST_TMO` | 64, 2048, 4096 | ≥ 1 / 0 disables |

Configurations regression-tested: 256 / 16 / 8 (default), 8 / 8 / 4 (small), registered Citadel (`CIT_LAT = 1`), short timeouts, 1 / 2 / 3 contexts, mixed blk + net.
