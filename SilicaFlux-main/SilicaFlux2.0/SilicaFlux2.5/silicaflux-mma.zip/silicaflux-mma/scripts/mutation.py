#!/usr/bin/env python3
"""Mutation testing: inject known RTL bugs (`ifdef MUT_*` hooks) and confirm the
verification suite detects every one of them.

Each mutant is run in two modes:
  checks : the RTL's internal ownership / bound checks enabled (default build)
  e2e    : built with SF_MMA_NO_CHECKS -- only the testbench's end-to-end checks
           (reference results, stray-write monitor, counters, protocol, quiescence)
A mutant is "killed" when at least one test fails.  Writes results/mutation.json/.md.
"""
from __future__ import annotations

import argparse
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
from configs import CONFIGS                       # noqa: E402
from simlib import ROOT, BUILD, NPROC, build, run  # noqa: E402
import gen_tests                                   # noqa: E402

MUTANTS = {
    "MUT_CLAIM_ANY":    ("loader claims an operand bank that is not FREE (ownership ignored)", ["base", "sb"]),
    "MUT_FULL_EARLY":   ("bank marked FULL when all beats are requested, not when they arrived", ["base", "sb"]),
    "MUT_NO_KMASK":     ("tail k-mask removed: stale bank bytes enter the products", ["base", "odd"]),
    "MUT_NO_FIRST_CLR": ("accumulators not cleared at the first step of an output tile", ["base"]),
    "MUT_STRB_OB1":     ("write strobes cover one byte beyond the row", ["base"]),
    "MUT_SAT_NEG":      ("saturation clamps negative overflow to +MAX", ["base", "acc20"]),
    "MUT_OVF_NARROW":   ("overflow never detected (no wrap/saturate decision)", ["base", "acc20"]),
    "MUT_OB1_NOLOCK":   ("OUT_BUFS=1: next tile overwrites accumulators the writer still drains", ["sb"]),
    "MUT_OB2_NORESV":   ("OUT_BUFS=2: last step issued although the output buffer is still owned by the writer", ["base"]),
    "MUT_REL_EARLY":    ("writer releases the output tile after its first row", ["base", "sb"]),
    "MUT_NO_DRAIN":     ("job completes without waiting for outstanding reads", ["base"]),
    "MUT_EARLY_DONE":   ("DONE / record before every write is acknowledged", ["base"]),
    "MUT_KMAX_OB1":     ("accumulation-length check off by one (K_MAX+1 accepted)", ["base", "acc20"]),
    "MUT_RSP_OFF1":     ("read-beat byte routing off by one", ["base"]),
    "MUT_UNSIGNED":     ("int8 operands treated as unsigned", ["base"]),
    "MUT_NO_POISON":    ("an erroring read beat does not poison its bank", ["base", "sb"]),
    "MUT_CIN_NOWAIT":   ("accumulate mode uses C_in before it has arrived", ["base"]),
    "MUT_ALIAS_OFF":    ("C/A/B overlap check disabled", ["base"]),
    "MUT_STOP_NOHOLD":  ("abort/error withdraws a request that is already presented", ["base"]),
    "MUT_LDB_NN":       ("row-major B leading dimension validated against K instead of N", ["base"]),
    "MUT_B_STRIDE":     ("B rows fetched with A's leading dimension", ["base"]),
    "MUT_LDC":          ("C rows written with stride N instead of ldc", ["base"]),
    "MUT_BANK_STUCK":   ("compute engine never advances to the next operand bank", ["base", "wide"]),
    "MUT_STOP_LATE":    ("stop (abort / error) reaches the datapath 1000 cycles late", ["base", "sb"]),
    "MUT_STOP_LATE+MUT_NO_POISON": ("late stop AND erroring beats do not poison their bank", ["base", "sb"]),
}

# Mutants that are expected to survive, with the reason.  They are still run and reported.
EQUIVALENT = {
    "MUT_NO_POISON": "equivalent in this design: the error beat that would complete a bank also sets `stop` on the "
                     "same clock edge, and the array never issues while stopped, so a poisoned bank can never be "
                     "used. The poison bit is defence in depth -- see MUT_STOP_LATE+MUT_NO_POISON.",
    "MUT_STOP_LATE": "allowed behaviour: during the extra 1000 cycles the job keeps computing and writing CORRECT "
                     "tiles (an errored bank stays poisoned and is never used), which the old-or-new rule permits.",
}


def test_set(cfg):
    tests = gen_tests.suite_directed(cfg, long_tests=False) + gen_tests.suite_random(cfg, seed=77, ntests=2)
    d = BUILD / "mut_tests" / cfg.name
    for t in tests:
        t.write(d / t.name)
    return [d / t.name for t in tests]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mutants", default=",".join(MUTANTS))
    ap.add_argument("--modes", default="checks,e2e")
    ap.add_argument("--out", default=str(ROOT / "results"))
    a = ap.parse_args()
    names = a.mutants.split(",")
    modes = a.modes.split(",")
    cfgs = sorted({c for n in names for c in MUTANTS[n][1]})
    tsets = {c: test_set(CONFIGS[c]) for c in cfgs}

    # sanity: the unmutated design passes the same test sets in both modes
    jobs = [(None, mode, c) for mode in modes for c in cfgs] + \
           [(n, mode, c) for n in names for mode in modes for c in MUTANTS[n][1]]

    def one(job):
        mut, mode, c = job
        defs = (mut.split("+") if mut else []) + (["SF_MMA_NO_CHECKS"] if mode == "e2e" else [])
        tag = f"{(mut or 'clean').lower().replace('+', '__')}_{mode}_{c}"
        sim = build(CONFIGS[c], defines=defs, tag="mut/" + tag)
        fails = []
        for td in tsets[c]:
            r = run(sim, td, timeout=600)
            if not r["passed"]:
                fails.append(dict(test=td.name, first=(r["errors"] or r["tail"])[:2]))
        return dict(mutant=mut, mode=mode, cfg=c, killed=bool(fails), failing_tests=len(fails),
                    of=len(tsets[c]), first=fails[:3])

    with ThreadPoolExecutor(max(1, NPROC // 2)) as ex:
        res = list(ex.map(one, jobs))

    clean = [r for r in res if r["mutant"] is None]
    muts = [r for r in res if r["mutant"] is not None]
    summary = {}
    for n in names:
        summary[n] = {m: any(r["killed"] for r in muts if r["mutant"] == n and r["mode"] == m) for m in modes}
    ok_clean = not any(r["killed"] for r in clean)
    rep = dict(clean_passes=ok_clean, mutants={n: dict(description=MUTANTS[n][0], configs=MUTANTS[n][1],
                                                       killed=summary[n], expected_survivor=n in EQUIVALENT,
                                                       note=EQUIVALENT.get(n, "")) for n in names}, runs=res)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "mutation.json").write_text(json.dumps(rep, indent=1))
    L = ["# Mutation testing", "",
         "Each mutant is a deliberate RTL bug behind an `ifdef MUT_*` hook (`grep -rn MUT_ rtl/`). It is built and run",
         "against the directed suite plus two random tests of each listed configuration.",
         "*checks* = RTL internal checks enabled; *e2e* = built with `SF_MMA_NO_CHECKS`, so only the testbench's",
         "end-to-end checks can detect it.", "",
         f"Unmutated design on the same test sets: **{'all pass' if ok_clean else 'FAILURES'}**.", "",
         "| mutant | injected bug | configs | " + " | ".join(modes) + " | first detection (e2e if available) |",
         "|---|---|---|" + "---|" * len(modes) + "---|"]
    for n in names:
        det = [r for r in muts if r["mutant"] == n and r["killed"]]
        det.sort(key=lambda r: (r["mode"] != "e2e", r["cfg"]))
        first = ""
        if det:
            f = det[0]["first"][0]
            msg = (f["first"][0] if f["first"] else "").split("ERROR: ")[-1][:110].replace("|", "/")
            first = f"{det[0]['cfg']}/{f['test']} ({det[0]['failing_tests']}/{det[0]['of']} tests fail): {msg}"
        surv = "survived (expected)" if n in EQUIVALENT else "**SURVIVED**"
        L.append(f"| {n} | {MUTANTS[n][0]} | {', '.join(MUTANTS[n][1])} | " +
                 " | ".join("killed" if summary[n][m] else surv for m in modes) + f" | {first} |")
    real = [n for n in names if n not in EQUIVALENT]
    killed = {m: sum(summary[n][m] for n in real) for m in modes}
    L += ["", "Killed (non-equivalent mutants): " + ", ".join(f"{m} {killed[m]}/{len(real)}" for m in modes)]
    if any(n in EQUIVALENT for n in names):
        L += ["", "Expected survivors:", ""] + [f"* `{n}`: {EQUIVALENT[n]}" + (" -- it was killed nevertheless." if any(summary[n].values()) else "")
                                               for n in names if n in EQUIVALENT]
    (out / "mutation.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
