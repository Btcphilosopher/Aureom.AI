#!/usr/bin/env python3
"""Resource estimate with Yosys generic synthesis (no technology library, no timing).

For each configuration: `synth -top sf_mma_top` (hierarchy kept) with the
configuration's parameters, then `stat` per module and `stat -tech cmos` for a
transistor-count estimate.  Flip-flops, multipliers (as gates) and multiplexers
are what distinguish single from double buffering; these numbers are a relative
cost indication, not an ASIC/FPGA area or frequency claim.

Writes results/synth.json and results/synth.md (+ raw logs in results/synth/).
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from configs import CONFIGS  # noqa: E402
from simlib import ROOT      # noqa: E402

RTL = ["sf_mma_pkg.sv", "sf_mma_loader.sv", "sf_mma_rdport.sv", "sf_mma_opbuf.sv", "sf_mma_array.sv",
       "sf_mma_writer.sv", "sf_mma_ctrl.sv", "sf_mma_top.sv"]
BLOCKS = ["sf_mma_ctrl", "sf_mma_loader", "sf_mma_rdport", "sf_mma_opbuf", "sf_mma_array", "sf_mma_writer"]


def parse_stat(text: str) -> dict:
    """Split the `stat` output into per-module cell tables."""
    mods = {}
    for sec in re.split(r"\n=== ", text):
        m = re.match(r"(\S+) ===", sec)
        if not m:
            continue
        name = m.group(1)
        cells = {}
        tot = re.search(r"Number of cells:\s+(\d+)", sec)
        for c, n in re.findall(r"^\s+(\$_\w+_|\$\w+|\S+)\s+(\d+)\s*$", sec, re.M):
            if c.startswith("$"):
                cells[c] = int(n)
        mods[name] = dict(cells=int(tot.group(1)) if tot else 0, types=cells)
    return mods


def summarise(types: dict) -> dict:
    ff = sum(v for k, v in types.items() if "DFF" in k or "DLATCH" in k)
    mux = sum(v for k, v in types.items() if "MUX" in k)
    logic = sum(v for k, v in types.items()) - ff
    return dict(ff=ff, mux=mux, logic=logic)


def synth(cname: str, outdir: Path) -> dict:
    cfg = CONFIGS[cname]
    chp = " ".join(f"-chparam {k} {v}" for k, v in cfg.gparams().items())
    files = " ".join(str(ROOT / "rtl" / f) for f in RTL)
    script = (f"read_verilog -sv -DSYNTHESIS {files}; hierarchy -check -top sf_mma_top {chp}; "
              f"synth -top sf_mma_top; opt_clean; tee -o {outdir}/{cname}_stat.txt stat; "
              f"tee -o {outdir}/{cname}_cmos.txt stat -tech cmos; check -assert")
    log = outdir / f"{cname}.log"
    r = subprocess.run(["yosys", "-q", "-l", str(log), "-p", script], capture_output=True, text=True)
    if r.returncode != 0:
        return dict(cfg=cname, ok=False, error=(r.stderr or r.stdout)[-2000:])
    stat = (outdir / f"{cname}_stat.txt").read_text()
    cmos = (outdir / f"{cname}_cmos.txt").read_text()
    mods = parse_stat(stat)
    # the design hierarchy total is the last "design hierarchy" block
    m = re.search(r"design hierarchy ===.*?Number of cells:\s+(\d+)(.*)", stat, re.S)
    total_cells = int(m.group(1)) if m else None
    tot_types = {}
    if m:
        for c, n in re.findall(r"^\s+(\$\w+)\s+(\d+)\s*$", m.group(2), re.M):
            tot_types[c] = int(n)
    tr = re.findall(r"Estimated number of transistors:\s+(\d+)", cmos)
    blocks = {}
    for b in BLOCKS:
        for name, v in mods.items():
            if name.endswith(b) or f"\\{b}" in name or name.split("\\")[-1].startswith(b):
                blocks[b] = dict(cells=v["cells"], **summarise(v["types"]))
    return dict(cfg=cname, ok=True, params=cfg.gparams(), total_cells=total_cells, total=summarise(tot_types),
                transistors=int(tr[-1]) if tr else None, blocks=blocks)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default="sb,dbin,base,sb_iso")
    ap.add_argument("--out", default=str(ROOT / "results"))
    ap.add_argument("--jobs", type=int, default=2)
    a = ap.parse_args()
    out = Path(a.out)
    raw = out / "synth"
    raw.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(lambda c: synth(c, raw), a.configs.split(",")))
    (out / "synth.json").write_text(json.dumps(res, indent=1))
    L = ["# Resource estimate (Yosys generic synthesis)", "",
         "`yosys synth -top sf_mma_top` with each configuration's parameters, hierarchy kept, then `stat` and",
         "`stat -tech cmos`. Generic gate cells, **no technology library, no timing, no memory macros** (all local",
         "storage is flip-flops). Use the numbers to compare configurations, not as an area or frequency claim.", "",
         "| config | IN_BUFS | OUT_BUFS | KT | total cells | flip-flops | mux cells | est. transistors |",
         "|---|---|---|---|---|---|---|---|"]
    for r in res:
        if not r["ok"]:
            L.append(f"| {r['cfg']} | synthesis failed | | | | | | |")
            continue
        p = r["params"]
        L.append(f"| {r['cfg']} | {p['IN_BUFS']} | {p['OUT_BUFS']} | {p['KT']} | {r['total_cells']} | {r['total']['ff']} | "
                 f"{r['total']['mux']} | {r['transistors']} |")
    L += ["", "Per block (cells / flip-flops):", "", "| config | " + " | ".join(b.replace("sf_mma_", "") for b in BLOCKS) + " |",
          "|---|" + "---|" * len(BLOCKS)]
    for r in res:
        if r["ok"]:
            L.append(f"| {r['cfg']} | " + " | ".join(
                f"{r['blocks'][b]['cells']} / {r['blocks'][b]['ff']}" if b in r["blocks"] else "-" for b in BLOCKS) + " |")
    (out / "synth.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
