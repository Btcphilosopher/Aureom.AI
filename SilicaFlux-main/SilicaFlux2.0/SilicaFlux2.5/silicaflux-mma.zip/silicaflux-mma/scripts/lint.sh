#!/usr/bin/env bash
# lint.sh -- Verilator -Wall over several parameter sets, Icarus compile, Yosys elaboration.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
RTL="rtl/sf_mma_pkg.sv rtl/sf_mma_loader.sv rtl/sf_mma_rdport.sv rtl/sf_mma_opbuf.sv rtl/sf_mma_array.sv rtl/sf_mma_writer.sv rtl/sf_mma_ctrl.sv rtl/sf_mma_top.sv"
fail=0
while read -r name params; do
  [ -z "$name" ] && continue
  out=$(verilator --lint-only -Wall -Wno-DECLFILENAME $params $RTL --top-module sf_mma_top 2>&1)
  if [ -n "$out" ]; then echo "verilator -Wall [$name]: FAIL"; echo "$out" | head -20; fail=1; else echo "verilator -Wall [$name]: clean"; fi
done <<'CFGS'
base
sb      -GIN_BUFS=1 -GOUT_BUFS=1
odd     -GTM=3 -GTN=5 -GTK=2 -GKT=6 -GBUS_BYTES=8 -GACC_W=24 -GRD_OUT=3 -GWR_OUT=2
acc20   -GTM=4 -GTN=4 -GTK=4 -GKT=8 -GBUS_BYTES=4 -GACC_W=20 -GRD_OUT=4 -GWR_OUT=4
wide    -GTM=4 -GTN=16 -GTK=4 -GKT=16 -GBUS_BYTES=32 -GIN_BUFS=3 -GRD_OUT=24
tiny    -GTM=1 -GTN=1 -GTK=1 -GKT=1 -GBUS_BYTES=4 -GOUT_BUFS=1 -GACC_W=16 -GRD_OUT=1 -GWR_OUT=1
CFGS
if command -v iverilog >/dev/null; then
  if iverilog -g2012 -o /dev/null -s sf_mma_top $RTL 2>/tmp/sfmma_iv.$$; then
    echo "iverilog -g2012 compile: ok ($(grep -c sorry /tmp/sfmma_iv.$$) 'sorry' notes about always_* sensitivity of constant selects, no errors)"
  else echo "iverilog: FAIL"; cat /tmp/sfmma_iv.$$; fail=1; fi
  rm -f /tmp/sfmma_iv.$$
fi
if command -v yosys >/dev/null; then
  if yosys -q -p "read_verilog -sv -DSYNTHESIS $RTL; hierarchy -check -top sf_mma_top; proc; check -assert" >/dev/null 2>&1; then
    echo "yosys read/elaborate/check: ok"
  else echo "yosys: FAIL"; fail=1; fi
fi
exit $fail
