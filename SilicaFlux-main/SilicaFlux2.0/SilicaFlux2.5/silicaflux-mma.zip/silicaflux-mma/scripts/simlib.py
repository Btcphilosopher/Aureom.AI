"""simlib.py -- build / run helpers shared by the regression, mutation and benchmark scripts."""
from __future__ import annotations

import hashlib
import os
import re
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
VBUILD = ROOT / "scripts" / "vbuild.sh"
NPROC = os.cpu_count() or 4

SOURCES = sorted((ROOT / "rtl").glob("*.sv")) + sorted((ROOT / "tb").glob("*.sv")) + [VBUILD]


def _digest(flags: list[str]) -> str:
    h = hashlib.sha1()
    for p in SOURCES:
        h.update(p.read_bytes())
    h.update(" ".join(flags).encode())
    return h.hexdigest()[:12]


def build(cfg, defines: list[str] | None = None, tag: str | None = None, quiet: bool = True) -> Path:
    """Build tb_mma for an RTL configuration (+ optional -D defines); cached by content hash."""
    defines = defines or []
    flags = cfg.vflags() + [f"-D{d}" for d in defines]
    name = tag or (cfg.name + ("_" + "_".join(defines) if defines else ""))
    out = BUILD / "sim" / name
    stamp = out / "stamp"
    dg = _digest(flags)
    if stamp.exists() and stamp.read_text() == dg and (out / "sim").exists():
        return out / "sim"
    env = dict(os.environ, VJOBS=str(max(1, NPROC // 2)))
    r = subprocess.run([str(VBUILD), str(out)] + flags, capture_output=True, text=True, env=env)
    if r.returncode != 0:
        raise RuntimeError(f"build {name} failed:\n{r.stdout}\n{r.stderr}")
    stamp.write_text(dg)
    if not quiet:
        print(f"built {name}")
    return out / "sim"


METRIC_RE = re.compile(r"(\w+)=(-?\d+)")


def run(sim: Path, testdir: Path, timeout: int = 1800, extra: list[str] | None = None) -> dict:
    t0 = time.time()
    try:
        r = subprocess.run([str(sim), f"+DIR={testdir}"] + (extra or []), capture_output=True, text=True,
                           timeout=timeout)
        out = r.stdout + r.stderr
        rc = r.returncode
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        out += "\nTIMEOUT (host)"
        rc = -1
    dt = time.time() - t0
    passed = ("TB_RESULT: PASS" in out) and rc == 0
    metrics = []
    for line in out.splitlines():
        if line.startswith("METRIC "):
            metrics.append({k: int(v) for k, v in METRIC_RE.findall(line)})
    m = re.search(r"tb_mma: (\d+) jobs, (\d+) checks, (\d+) errors, (\d+) cycles", out)
    summary = dict(jobs=int(m.group(1)), checks=int(m.group(2)), n_errors=int(m.group(3)), cycles=int(m.group(4))) if m else {}
    errs = [l for l in out.splitlines() if "ERROR" in l or "%Error" in l or "Assertion" in l][:8]
    return dict(test=testdir.name, passed=passed, rc=rc, seconds=round(dt, 2), metrics=metrics, errors=errs,
                tail=out.splitlines()[-6:], **summary)
