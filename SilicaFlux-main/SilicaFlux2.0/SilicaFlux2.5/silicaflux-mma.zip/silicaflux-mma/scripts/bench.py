#!/usr/bin/env python3
"""Single- vs double-buffered comparison under identical memory constraints.

Every (workload, memory profile) job is generated with the same seed for every
configuration, so the matrices, their addresses / alignment and the memory
behaviour are identical; only the buffering differs.  Each run is verified
(results, counters, stray writes) exactly like a regression job, then its
counters are recorded.

Configurations (identical datapath: 8x8 array, TK=1, 16-byte bus, RD_OUT=16, WR_OUT=8):
  SB      sb      1 operand bank of KT=32, accumulators double as output buffer
  DB-in   dbin    2 operand banks of KT=32, accumulators double as output buffer
  DB      base    2 operand banks of KT=32, separate output buffer
  SB-iso  sb_iso  1 operand bank of KT=64 -- the same operand storage as DB

Writes results/bench.json (raw + derived) and results/bench.md.
"""
from __future__ import annotations

import argparse
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
from configs import CONFIGS                               # noqa: E402
from simlib import ROOT, BUILD, NPROC, build, run         # noqa: E402
import gen_tests                                          # noqa: E402
from gen_tests import Test                                # noqa: E402
from traffic import compulsory_bytes, Desc                # noqa: E402

BENCH_CFGS = [("SB", "sb"), ("DB-in", "dbin"), ("DB", "base"), ("SB-iso", "sb_iso")]

# deterministic memory constraints, identical for every configuration
MEMS = {
    "near":   dict(lat=16,  wlat=8,  jitter=0, p_rd=100, p_wr=100, throttle=1, stall_period=0, stall_len=0, gpu=0),
    "far":    dict(lat=100, wlat=50, jitter=0, p_rd=100, p_wr=100, throttle=1, stall_period=0, stall_len=0, gpu=0),
    "narrow": dict(lat=16,  wlat=8,  jitter=0, p_rd=100, p_wr=100, throttle=2, stall_period=0, stall_len=0, gpu=0),
    "shared": dict(lat=16,  wlat=8,  jitter=0, p_rd=100, p_wr=100, throttle=1, stall_period=0, stall_len=0, gpu=30),
}
MEM_NOTES = {
    "near":   "16-cycle read latency, 1 beat (16 B) per cycle shared by reads and writes",
    "far":    "100-cycle read latency, 1 beat per cycle; with 16 reads in flight at most 0.16 beat/cycle (Little's law)",
    "narrow": "16-cycle latency, at most 1 beat every 2 cycles (8 B/cycle)",
    "shared": "as near, but a GPU-core stand-in competes for the port in 30 % of cycles (round-robin, seeded)",
}

# name: (M, N, K, flags)
WORKLOADS = {
    "sq64":     (64, 64, 64, {}),
    "sq128":    (128, 128, 128, {}),
    "sq128_bt": (128, 128, 128, dict(trans_b=True)),
    "rect":     (200, 72, 300, dict(trans_b=True)),
    "tall":     (1024, 8, 256, dict(trans_b=True)),
    "wide":     (8, 1024, 256, {}),
    "deep_k":   (32, 32, 2048, dict(trans_b=True)),
    "tails":    (65, 65, 65, {}),
    "acc128":   (128, 128, 128, dict(accum=True, trans_b=True)),
    "small":    (9, 9, 9, {}),
}
LAT_SWEEP = [4, 16, 32, 64, 128, 256]


def make_test(cfg, wname, mems, seed, lat_sweep=False):
    M, N, K, fl = WORKLOADS[wname]
    t = Test(f"bench_{wname}" + ("_lat" if lat_sweep else ""), cfg, seed)
    for mname, prof in mems.items():
        t.add_job(M, N, K, data="uniform", profile=dict(prof), misalign=False, cpl=True, irq=True, poll=1,
                  metric=True, seed=seed, note=mname, **fl)
    return t


def derive(cfg, wname, mem, m, d: Desc):
    peak = cfg.peak_macs
    cyc = m["cyc"]
    bus = cfg.BUS_BYTES
    comp = compulsory_bytes(d)
    return dict(
        cycles=cyc,
        data_cycles=m["dcyc"],
        macs=m["macs"],
        macs_per_cycle=m["macs"] / cyc,
        utilisation=m["macs"] / (peak * cyc),
        array_busy=m["active"] / cyc,
        slot_efficiency=m["macs"] / (peak * m["active"]) if m["active"] else 0.0,
        bus_bytes=(m["rd_beats"] + m["wr_beats"]) * bus,
        useful_bytes=m["rd_bytes"] + m["wr_bytes"],
        rd_bytes=m["rd_bytes"], wr_bytes=m["wr_bytes"],
        compulsory_bytes=comp,
        refetch_factor=(m["rd_bytes"] + m["wr_bytes"]) / comp,
        bus_efficiency=(m["rd_bytes"] + m["wr_bytes"]) / ((m["rd_beats"] + m["wr_beats"]) * bus),
        bytes_per_cycle=(m["rd_beats"] + m["wr_beats"]) * bus / cyc,
        st_load=m["st_load"], st_store=m["st_store"], rd_bp=m["rd_bp"], wr_bp=m["wr_bp"],
        ld_wait=m["ld_wait"], rd_cred=m["rd_cred"],
        st_load_frac=m["st_load"] / cyc, st_store_frac=m["st_store"] / cyc,
        gpu_ops=m.get("gpu_ops", 0),
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workloads", default=",".join(WORKLOADS))
    ap.add_argument("--mems", default=",".join(MEMS))
    ap.add_argument("--no-sweep", action="store_true")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--out", default=str(ROOT / "results"))
    a = ap.parse_args()
    wl = a.workloads.split(",")
    mems = {k: MEMS[k] for k in a.mems.split(",")}

    sims = {n: build(CONFIGS[c]) for n, c in BENCH_CFGS}
    jobs = []
    for label, cname in BENCH_CFGS:
        cfg = CONFIGS[cname]
        for w in wl:
            t = make_test(cfg, w, mems, a.seed)
            d = BUILD / "bench" / cname / t.name
            t.write(d)
            jobs.append((label, cfg, w, t, d, False))
        if not a.no_sweep:
            for w in ("sq128", "sq128_bt"):
                sweep = {f"lat{L}": dict(MEMS["near"], lat=L, wlat=max(4, L // 2)) for L in LAT_SWEEP}
                t = make_test(cfg, w, sweep, a.seed, lat_sweep=True)
                d = BUILD / "bench" / cname / t.name
                t.write(d)
                jobs.append((label, cfg, w, t, d, True))

    def one(j):
        label, cfg, w, t, d, sw = j
        r = run(sims[label], d, timeout=3600)
        return j, r

    rows, sweep_rows, failures = [], [], []
    with ThreadPoolExecutor(NPROC) as ex:
        for (label, cfg, w, t, d, sw), r in ex.map(one, jobs):
            if not r["passed"]:
                failures.append(dict(cfg=label, workload=w, errors=r["errors"][:3]))
                continue
            for m in r["metrics"]:
                info = t.info[m["job"]]
                desc = Desc(**info["desc"])
                row = dict(cfg=label, rtl=cfg.name, workload=w, mem=info["note"], M=desc.M, N=desc.N, K=desc.K,
                           trans_b=desc.trans_b, accum=desc.accum, peak_macs_per_cycle=cfg.peak_macs,
                           operand_bytes=cfg.operand_bytes, output_bytes=cfg.output_bytes,
                           lower_bound=info["lb"], raw=m, **derive(cfg, w, info["note"], m, desc))
                (sweep_rows if sw else rows).append(row)

    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rep = dict(seed=a.seed, configs={l: CONFIGS[c].gparams() for l, c in BENCH_CFGS}, mems=mems, mem_notes=MEM_NOTES,
               workloads={k: dict(M=v[0], N=v[1], K=v[2], **v[3]) for k, v in WORKLOADS.items() if k in wl},
               rows=rows, sweep=sweep_rows, failures=failures)
    (out / "bench.json").write_text(json.dumps(rep, indent=1))
    print(f"bench: {len(rows)} runs + {len(sweep_rows)} sweep points, {len(failures)} failures")
    for f in failures:
        print("  FAIL", f)
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
