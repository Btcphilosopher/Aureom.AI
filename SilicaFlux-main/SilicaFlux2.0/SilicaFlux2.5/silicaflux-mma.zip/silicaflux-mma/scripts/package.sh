#!/usr/bin/env bash
# package.sh [out.zip] -- zip the project (no build/ outputs, no VCS metadata) with a SHA-256 manifest.
# `zip -FS` synchronises an existing archive with the file set, so no stale entries survive.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NAME="$(basename "$ROOT")"
OUT="${1:-$(dirname "$ROOT")/$NAME.zip}"
cd "$ROOT"
find . -type f ! -path './build/*' ! -path '*/__pycache__/*' ! -name 'MANIFEST.sha256' ! -name '*.zip' ! -path './.git/*' \
  | sed 's|^\./||' | LC_ALL=C sort | xargs sha256sum > MANIFEST.sha256
cd "$(dirname "$ROOT")"
zip -q -r -X -FS "$OUT" "$NAME" -x "$NAME/build/*" "$NAME/*__pycache__*" "$NAME/.git/*" "$NAME/*.zip"
echo "wrote $OUT ($(du -h "$OUT" | cut -f1), $(unzip -l "$OUT" | tail -1 | awk '{print $2}') files)"
