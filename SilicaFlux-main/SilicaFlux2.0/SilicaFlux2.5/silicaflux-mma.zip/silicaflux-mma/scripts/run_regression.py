#!/usr/bin/env python3
"""Full regression: every configuration x (directed suite + seeded random suites).

Writes results/regression.json and results/regression.md.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
from configs import CONFIGS                                    # noqa: E402
from simlib import ROOT, BUILD, NPROC, build, run              # noqa: E402
import gen_tests                                               # noqa: E402
from traffic import ERR_NAMES, F_ACCUM, F_SAT, F_TRANS_B       # noqa: E402

ACTIONS = {0: "none", 1: "abort", 2: "reset", 3: "start-while-busy", 4: "rewrite-while-busy"}


def coverage(tests) -> dict:
    c = Counter()
    for t in tests:
        for x in t.info:
            d = x["desc"]
            c["jobs"] += 1
            c["code:" + ERR_NAMES[x["code"]]] += 1
            c["action:" + ACTIONS[x["action"]]] += 1
            c["profile:" + x["profile"]] += 1
            if x["err"]:
                c[f"mem-error:{x['err'][0]}-{x['err'][1]}"] += 1
            if x["code"] != 0:
                continue
            cfg = t.cfg
            c["accumulate"] += bool(d["flags"] & F_ACCUM)
            c["saturate"] += bool(d["flags"] & F_SAT)
            c["B transposed"] += bool(d["flags"] & F_TRANS_B)
            c["M % TM != 0"] += d["M"] % cfg.TM != 0
            c["N % TN != 0"] += d["N"] % cfg.TN != 0
            c["K % KT != 0"] += d["K"] % cfg.KT != 0
            c["K % TK != 0"] += d["K"] % cfg.TK != 0
            c["M != N (rectangular)"] += d["M"] != d["N"]
            c["A base unaligned to bus"] += d["a"] % cfg.BUS_BYTES != 0
            c["lda > K"] += d["lda"] > d["K"]
            c["ldc > N"] += d["ldc"] > d["N"]
            if x["ovf"] is not None and x["ovf"].any():
                c["jobs with overflowed elements"] += 1
                c["overflowed elements"] += int(x["ovf"].sum())
            if x["A"] is not None and x["A"].size and (x["A"].min() == -128 or x["A"].max() == 127):
                c["operands at -128 or 127"] += 1
            if x["A"] is not None and x["A"].size and x["A"].min() < 0:
                c["negative operands"] += 1
    return dict(sorted(c.items()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default=",".join(CONFIGS))
    ap.add_argument("--seeds", type=int, default=3, help="random seeds per configuration")
    ap.add_argument("--ntests", type=int, default=3, help="random tests per seed")
    ap.add_argument("--jobs", type=int, default=NPROC)
    ap.add_argument("--quick", action="store_true", help="directed suite only, no long tests")
    ap.add_argument("--out", default=str(ROOT / "results"))
    a = ap.parse_args()

    t_start = time.time()
    report = dict(configs={}, started=time.strftime("%Y-%m-%d %H:%M:%S"))
    all_ok = True
    for name in a.configs.split(","):
        cfg = CONFIGS[name]
        tests = gen_tests.suite_directed(cfg, long_tests=not a.quick)
        if not a.quick:
            for s in range(1, a.seeds + 1):
                tests += gen_tests.suite_random(cfg, seed=s * 101 + len(name), ntests=a.ntests)
        tdir = BUILD / "tests" / name
        for t in tests:
            t.write(tdir / t.name)
        sim = build(cfg)
        with ThreadPoolExecutor(a.jobs) as ex:
            res = list(ex.map(lambda t: run(sim, tdir / t.name), tests))
        ok = all(r["passed"] for r in res)
        all_ok &= ok
        cov = coverage(tests)
        report["configs"][name] = dict(cfg=cfg.gparams(), passed=ok, tests=len(res),
                                       jobs=sum(r.get("jobs", 0) for r in res),
                                       checks=sum(r.get("checks", 0) for r in res),
                                       cycles=sum(r.get("cycles", 0) for r in res),
                                       sim_seconds=round(sum(r["seconds"] for r in res), 1),
                                       failures=[r for r in res if not r["passed"]],
                                       results=[{k: r[k] for k in ("test", "passed", "seconds")} | {
                                           "jobs": r.get("jobs"), "checks": r.get("checks"), "cycles": r.get("cycles")}
                                           for r in res],
                                       coverage=cov)
        nf = sum(not r["passed"] for r in res)
        print(f"{name:7s}: {len(res) - nf}/{len(res)} tests pass, {report['configs'][name]['jobs']} jobs, "
              f"{report['configs'][name]['checks']} checks, {report['configs'][name]['cycles']} cycles")
        for r in res:
            if not r["passed"]:
                print(f"   FAIL {r['test']}: " + " | ".join(r["errors"][:3] or r["tail"][-3:]))
    report["wall_seconds"] = round(time.time() - t_start, 1)
    report["passed"] = all_ok
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "regression.json").write_text(json.dumps(report, indent=1, default=int))
    write_md(report, out / "regression.md")
    print("REGRESSION:", "PASS" if all_ok else "FAIL", f"({report['wall_seconds']} s)")
    sys.exit(0 if all_ok else 1)


def write_md(rep, path):
    L = ["# Regression results", "",
         f"Generated by `scripts/run_regression.py` ({rep['started']}, {rep['wall_seconds']} s wall). "
         "Every job is checked against the Python reference (exact C on success, old-or-new per element when "
         "interrupted), for stray writes over the whole memory, for quiescence at completion, and -- on success -- "
         "for exact counter values.", "",
         "| config | parameters | tests | jobs | checks | simulated cycles | result |", "|---|---|---|---|---|---|---|"]
    for n, c in rep["configs"].items():
        p = c["cfg"]
        ps = (f"TM={p['TM']} TN={p['TN']} TK={p['TK']} KT={p['KT']} BUS={p['BUS_BYTES']} IN_BUFS={p['IN_BUFS']} "
              f"OUT_BUFS={p['OUT_BUFS']} ACC_W={p['ACC_W']} RD_OUT={p['RD_OUT']} WR_OUT={p['WR_OUT']}")
        L.append(f"| {n} | {ps} | {c['tests']} | {c['jobs']} | {c['checks']} | {c['cycles']} | "
                 f"{'PASS' if c['passed'] else 'FAIL'} |")
    L += ["", f"**Overall: {'PASS' if rep['passed'] else 'FAIL'}**", "", "## Scenario coverage (jobs, all configurations)", ""]
    tot = Counter()
    for c in rep["configs"].values():
        tot.update(c["coverage"])
    L += ["| scenario | jobs |", "|---|---|"] + [f"| {k} | {v} |" for k, v in sorted(tot.items())]
    L += ["", "Counts under `code:` are the completion codes the generator expects; for abort and reset jobs the",
          "accepted set is wider (OK/ABORT, or any) and the C region is checked element-wise as old-or-new.",
          "The scenario rows below `code:` count only jobs expected to complete with OK."]
    for n, c in rep["configs"].items():
        if c["failures"]:
            L += ["", f"## Failures in {n}", ""] + [f"* {f['test']}: {' | '.join(f['errors'][:4])}" for f in c["failures"]]
    path.write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    main()
