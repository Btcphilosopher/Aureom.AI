"""Named RTL parameter sets shared by the regression, mutation, benchmark and synthesis scripts."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
from traffic import Cfg  # noqa: E402

CONFIGS = {
    # reference design point: 8x8 array, 1 k per PE per cycle, 16-byte bus, double buffered in and out
    "base":  Cfg("base"),
    # identical datapath, single buffered (one operand bank, accumulators double as output buffer)
    "sb":    Cfg("sb", IN_BUFS=1, OUT_BUFS=1),
    # double-buffered operands only
    "dbin":  Cfg("dbin", IN_BUFS=2, OUT_BUFS=1),
    # single buffered with the SAME operand storage as "base" (one bank of KT=64 instead of two of 32)
    "sb_iso": Cfg("sb_iso", KT=64, IN_BUFS=1, OUT_BUFS=1),
    # non-power-of-two array, TK=2, 8-byte bus, 24-bit accumulator, minimal outstanding
    "odd":   Cfg("odd", TM=3, TN=5, TK=2, KT=6, BUS_BYTES=8, ACC_W=24, RD_OUT=3, WR_OUT=2),
    # 20-bit accumulator (K_MAX = 31), 4-byte bus
    "acc20": Cfg("acc20", TM=4, TN=4, TK=4, KT=8, BUS_BYTES=4, ACC_W=20, RD_OUT=4, WR_OUT=4),
    # wide bus, TK=4, triple-buffered operands
    "wide":  Cfg("wide", TM=4, TN=16, TK=4, KT=16, BUS_BYTES=32, IN_BUFS=3, RD_OUT=24, WR_OUT=8),
    # degenerate: 1x1x1 array, 16-bit accumulator (K_MAX = 1), one transaction in flight
    "tiny":  Cfg("tiny", TM=1, TN=1, TK=1, KT=1, BUS_BYTES=4, IN_BUFS=2, OUT_BUFS=1, ACC_W=16, RD_OUT=1, WR_OUT=1),
}
