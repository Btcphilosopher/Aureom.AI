#!/usr/bin/env bash
# vbuild.sh <build-dir> [verilator -G/-D flags ...]   -- build the SF-MMA testbench with Verilator
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$1"; shift
mkdir -p "$OUT"
verilator --binary --timing --assert --timescale 1ns/1ps \
  -Wno-fatal -Wno-WIDTH -Wno-UNUSED -Wno-DECLFILENAME -Wno-CASEINCOMPLETE -Wno-PINCONNECTEMPTY \
  -Wno-BLKSEQ -Wno-INITIALDLY -Wno-UNOPTFLAT -Wno-MULTIDRIVEN -Wno-SYMRSVDWORD -Wno-BLKLOOPINIT \
  -O2 --x-assign fast --x-initial fast --top-module tb_mma -Mdir "$OUT" -o sim -j "${VJOBS:-$(nproc)}" "$@" \
  "$ROOT/rtl/sf_mma_pkg.sv" "$ROOT/rtl/sf_mma_loader.sv" "$ROOT/rtl/sf_mma_rdport.sv" \
  "$ROOT/rtl/sf_mma_opbuf.sv" "$ROOT/rtl/sf_mma_array.sv" "$ROOT/rtl/sf_mma_writer.sv" \
  "$ROOT/rtl/sf_mma_ctrl.sv" "$ROOT/rtl/sf_mma_top.sv" \
  "$ROOT/tb/tb_mem.sv" "$ROOT/tb/tb_mma.sv" \
  > "$OUT/build.log" 2>&1 || { grep -E "^%Error" "$OUT/build.log" | head -30; echo "BUILD FAILED (see $OUT/build.log)"; exit 1; }
echo "built $OUT/sim"
