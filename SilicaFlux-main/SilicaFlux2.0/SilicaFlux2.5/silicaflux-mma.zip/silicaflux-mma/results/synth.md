# Resource estimate (Yosys generic synthesis)

`yosys synth -top sf_mma_top` with each configuration's parameters, hierarchy kept, then `stat` and
`stat -tech cmos`. Generic gate cells, **no technology library, no timing, no memory macros** (all local
storage is flip-flops). Use the numbers to compare configurations, not as an area or frequency claim.

| config | IN_BUFS | OUT_BUFS | KT | total cells | flip-flops | mux cells | est. transistors |
|---|---|---|---|---|---|---|---|
| sb | 1 | 1 | 32 | 109387 | 11537 | 13344 | 764836 |
| dbin | 2 | 1 | 32 | 118867 | 15703 | 17564 | 821866 |
| base | 2 | 2 | 32 | 120863 | 17751 | 17560 | 821562 |
| sb_iso | 1 | 1 | 64 | 124376 | 15631 | 19605 | 871458 |

Per block (cells / flip-flops):

| config | ctrl | loader | rdport | opbuf | array | writer |
|---|---|---|---|---|---|---|
| sb | 24437 / 1427 | 3601 / 302 | 5336 / 1447 | 7949 / 4167 | 56113 / 3227 | 11915 / 967 |
| dbin | 24445 / 1427 | 3603 / 302 | 5335 / 1447 | 13173 / 8333 | 60331 / 3227 | 11943 / 967 |
| base | 24449 / 1427 | 3595 / 302 | 5335 / 1447 | 13153 / 8333 | 62393 / 5275 | 11901 / 967 |
| sb_iso | 24448 / 1427 | 3587 / 300 | 7132 / 1447 | 15748 / 8263 | 61512 / 3227 | 11913 / 967 |
