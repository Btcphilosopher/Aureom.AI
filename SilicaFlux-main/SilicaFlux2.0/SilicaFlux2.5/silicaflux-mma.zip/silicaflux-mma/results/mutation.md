# Mutation testing

Each mutant is a deliberate RTL bug behind an `ifdef MUT_*` hook (`grep -rn MUT_ rtl/`). It is built and run
against the directed suite plus two random tests of each listed configuration.
*checks* = RTL internal checks enabled; *e2e* = built with `SF_MMA_NO_CHECKS`, so only the testbench's
end-to-end checks can detect it.

Unmutated design on the same test sets: **all pass**.

| mutant | injected bug | configs | checks | e2e | first detection (e2e if available) |
|---|---|---|---|---|---|
| MUT_CLAIM_ANY | loader claims an operand bank that is not FREE (ownership ignored) | base, sb | killed | killed | base/d02_full_tiles (17/20 tests fail): job 2: timeout after 137288 cycles (busy=1) |
| MUT_FULL_EARLY | bank marked FULL when all beats are requested, not when they arrived | base, sb | killed | killed | base/d01_tiny (17/20 tests fail): job 0: C[0][0] @0x00000168 = 0x00000000, expected 0x00001612 |
| MUT_NO_KMASK | tail k-mask removed: stale bank bytes enter the products | base, odd | killed | killed | odd/d01_tiny (18/20 tests fail): job 2: C[0][0] @0x00000270 = 0xfffff8a7, expected 0xffffd043 |
| MUT_NO_FIRST_CLR | accumulators not cleared at the first step of an output tile | base | killed | killed | base/d01_tiny (19/20 tests fail): job 1: C[0][0] @0x0000021c = 0x0000319c, expected 0x00001b8a |
| MUT_STRB_OB1 | write strobes cover one byte beyond the row | base | killed | killed | base/d01_tiny (18/20 tests fail): stray write to 0x0000016c (beat 0x00000160, job tag 1) |
| MUT_SAT_NEG | saturation clamps negative overflow to +MAX | base, acc20 | killed | killed | acc20/d09_overflow (2/20 tests fail): job 2: C[0][1] @0x00000584 = 0x0007ffff, expected 0xfff80000 |
| MUT_OVF_NARROW | overflow never detected (no wrap/saturate decision) | base, acc20 | killed | killed | acc20/d08_accumulate (5/20 tests fail): job 1: OVF_COUNT 0, expected 1 |
| MUT_OB1_NOLOCK | OUT_BUFS=1: next tile overwrites accumulators the writer still drains | sb | killed | killed | sb/d06_partial_tiles (9/20 tests fail): job 4: C[7][0] @0x00001490 = 0x0000013d, expected 0x000074f7 |
| MUT_OB2_NORESV | OUT_BUFS=2: last step issued although the output buffer is still owned by the writer | base | killed | killed | base/d02_full_tiles (9/20 tests fail): job 2: timeout after 137288 cycles (busy=1) |
| MUT_REL_EARLY | writer releases the output tile after its first row | base, sb | killed | killed | base/d02_full_tiles (9/20 tests fail): job 2: C[5][0] @0x00001770 = 0x00008e13, expected 0x0000284c |
| MUT_NO_DRAIN | job completes without waiting for outstanding reads | base | killed | killed | base/d14_memory_errors (3/20 tests fail): completion reported with 1 transactions outstanding |
| MUT_EARLY_DONE | DONE / record before every write is acknowledged | base | killed | killed | base/d01_tiny (20/20 tests fail): completion reported with 2 transactions outstanding |
| MUT_KMAX_OB1 | accumulation-length check off by one (K_MAX+1 accepted) | base, acc20 | killed | killed | acc20/d10_k_limit (2/20 tests fail): job 2: completion code 6 not allowed (mask 0x0004) |
| MUT_RSP_OFF1 | read-beat byte routing off by one | base | killed | killed | base/d01_tiny (19/20 tests fail): job 0: C[0][0] @0x00000168 = 0xfffff358, expected 0x00001612 |
| MUT_UNSIGNED | int8 operands treated as unsigned | base | killed | killed | base/d01_tiny (19/20 tests fail): job 1: C[0][0] @0x0000021c = 0x0000ad8a, expected 0x00001b8a |
| MUT_NO_POISON | an erroring read beat does not poison its bank | base, sb | survived (expected) | survived (expected) |  |
| MUT_CIN_NOWAIT | accumulate mode uses C_in before it has arrived | base | killed | killed | base/d08_accumulate (7/20 tests fail): job 0: C[0][0] @0x00000878 = 0x0000166a, expected 0x451d646d |
| MUT_ALIAS_OFF | C/A/B overlap check disabled | base | killed | killed | base/d11_bad_descriptors (1/20 tests fail): job 15: completion code 0 not allowed (mask 0x0040) |
| MUT_STOP_NOHOLD | abort/error withdraws a request that is already presented | base | killed | killed | base/d14_memory_errors (4/20 tests fail): wr_req_valid withdrawn before ready |
| MUT_LDB_NN | row-major B leading dimension validated against K instead of N | base | killed | killed | base/d01_tiny (19/20 tests fail): job 1: completion code 3 not allowed (mask 0x0001) |
| MUT_B_STRIDE | B rows fetched with A's leading dimension | base | killed | killed | base/d01_tiny (19/20 tests fail): job 1: C[0][0] @0x0000021c = 0xffffe5ee, expected 0x00001b8a |
| MUT_LDC | C rows written with stride N instead of ldc | base | killed | killed | base/d07_strides_alignment (4/20 tests fail): stray write to 0x000006f4 (beat 0x000006f0, job tag 1) |
| MUT_BANK_STUCK | compute engine never advances to the next operand bank | base, wide | killed | killed | base/d02_full_tiles (18/20 tests fail): job 1: timeout after 156744 cycles (busy=1) |
| MUT_STOP_LATE | stop (abort / error) reaches the datapath 1000 cycles late | base, sb | survived (expected) | survived (expected) |  |
| MUT_STOP_LATE+MUT_NO_POISON | late stop AND erroring beats do not poison their bank | base, sb | killed | killed | base/d14_memory_errors (2/20 tests fail): job 0 (code 7): C[16][0] @0x000015a4 = 0x00005366, neither old 0x9bac618c nor new 0x000022b5 |

Killed (non-equivalent mutants): checks 23/23, e2e 23/23

Expected survivors:

* `MUT_NO_POISON`: equivalent in this design: the error beat that would complete a bank also sets `stop` on the same clock edge, and the array never issues while stopped, so a poisoned bank can never be used. The poison bit is defence in depth -- see MUT_STOP_LATE+MUT_NO_POISON.
* `MUT_STOP_LATE`: allowed behaviour: during the extra 1000 cycles the job keeps computing and writing CORRECT tiles (an errored bank stays poisoned and is never used), which the old-or-new rule permits.
