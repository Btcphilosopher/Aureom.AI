# SilicaFlux MMA accelerator (SF-MMA)

A configurable, tiled **int8 matrix multiply-accumulate accelerator** in synthesizable
SystemVerilog that works **alongside the programmable SilicaFlux GPU core**: the core
programs it through MMIO registers, it moves its own data through a DMA master on the
shared memory port, and reports completion by interrupt, status register or a record
in memory. Python provides the numerical reference, the transfer model, the test
generator and the measurement flow.

```
C[M x N] = A[M x K] * B[K x N]        or        C = C + A*B (in place)
A, B: signed int8 (B row-major or transposed)   C: ACC_W-bit (default 32) integer, stored as 32-bit words
```

> **Status.** Verified by RTL simulation (Verilator 5.020) against a Python reference;
> lint-clean in Verilator `-Wall`, compiles in Icarus 12, synthesizes in Yosys 0.33. All
> performance numbers are **simulated clock cycles** with a behavioural memory model -- no
> FPGA, no silicon, no clock frequency claim. Resource numbers are generic-gate estimates.
> Nothing in this package was committed or pushed anywhere; it is delivered as this zip.

## Contents

```
rtl/      sf_mma_top.sv      top level: CSR port, DMA read/write channels, irq
          sf_mma_ctrl.sv     CSRs, descriptor validation, job FSM, errors, completion record, counters
          sf_mma_loader.sv   tile loading: byte-exact A/B row beats, bank claiming
          sf_mma_rdport.sv   read DMA: request register, outstanding credits, in-order metadata FIFO, byte routing
          sf_mma_opbuf.sv    local operand storage: NB banks + ownership state machine (+ checks)
          sf_mma_array.sv    compute scheduling, TM x TN x TK MAC array, accumulators, output buffer (+ checks)
          sf_mma_writer.sv   output accumulation (C_in), wrap/saturate, byte-masked write-back, record
          sf_mma_pkg.sv      codes, CSR map, flags
tb/       tb_mma.sv          self-checking testbench (CSR driver, interruptions, monitors, checkers)
          tb_mem.sv          memory model: latency, jitter, back-pressure, freezes, errors, GPU-core stand-in
model/    mma_ref.py         numerical reference (+ independent scalar implementation)
          traffic.py         descriptor validation + exact beat/byte/MAC model + cycle lower bound
          gen_tests.py       directed and random test generator
          test_model.py      self-tests of the reference (incl. tightness of the K bound)
scripts/  run_regression.py  mutation.py  bench.py  synth.py  report.py  lint.sh  vbuild.sh  package.sh  configs.py  simlib.py
docs/     NUMERICS.md        the arithmetic contract: widths, overflow, accumulation-length bound
          ARCHITECTURE.md    schedule, buffers, ownership protocol, tails, DMA, errors, completion
          INTEGRATION.md     ports, CSR map, programming sequence, memory and software contracts
          VERIFICATION.md    what is checked, test plan, mutation testing, bugs found, limits
          RESULTS.md         generated measurement report
results/  regression.md/json  mutation.md/json  bench.json  synth.md/json (+ logs)  ENVIRONMENT.txt
```

## Requirements -> where they are met

| requirement | where / evidence |
|---|---|
| operate alongside the programmable GPU core | MMIO CSR slave + DMA master + irq, no change to the core (`docs/INTEGRATION.md`); testbench shares the memory port with a GPU-core stand-in and verifies its data |
| configurable tiled datapath (SystemVerilog) | parameters TM, TN, TK, KT, BUS_BYTES, IN_BUFS, OUT_BUFS, ACC_W, RD_OUT, WR_OUT, DIM_W; 8 configurations verified |
| Python numerical reference | `model/mma_ref.py`, cross-checked against a scalar implementation |
| signed int8 operands, explicitly sized accumulation | ACC_W parameter (16..32); products exact in 16 bits; `docs/NUMERICS.md` |
| defined overflow behaviour | accumulator cannot overflow (K bound); C + A*B formed in ACC_W+1 bits, then wrap or saturate per job, overflowed elements counted (`OVF_CNT`, record, STATUS) |
| bound on accumulation length | K <= K_MAX = 2^(ACC_W-15) - 1 (131 071 at 32 bits), proven tight, enforced (ERR_KMAX), tested at K_MAX and K_MAX+1 |
| tile loading | `sf_mma_loader` + `sf_mma_rdport`: arbitrary byte alignment and leading dimensions, both B layouts |
| local operand storage | `sf_mma_opbuf`: NB banks of (TM+TN) x KT bytes |
| double buffering | IN_BUFS (operands) and OUT_BUFS (output) parameters, same RTL for single and double |
| compute scheduling | `sf_mma_array`: in-order bank consumption, ownership-gated issue, stall classification |
| output accumulation | output-stationary accumulators across k-tiles + in-place C_in accumulation in the writer |
| tail handling | short rows, fewer rows, k-masking, byte strobes (`docs/ARCHITECTURE.md` section 8) |
| DMA back-pressure | valid/ready on both channels, stable payload, RD_OUT/WR_OUT credits; tested with 25-50 % ready, jitter, 1500-cycle freezes, bandwidth caps, GPU traffic |
| completion reporting | DONE only after every write is acknowledged; irq, STATUS, 16-byte record (status word written last) |
| overlap only when ownership makes it safe | bank FSM FREE -> LOADING -> FULL -> BUSY, output-buffer reservation at issue; checked every cycle; 6 ownership mutants all detected |
| compare single vs double buffering under identical memory constraints | `scripts/bench.py`: same RTL, same jobs, same addresses, same deterministic memory; plus an iso-storage single-buffered variant |
| report time, utilisation, bytes, stalls, resources | `docs/RESULTS.md` sections 2-7 |
| tests: negative, extreme, rectangular, partial tiles, interrupted transfers, reset | `docs/VERIFICATION.md` section 4; all pass on 8 configurations |
| no peak throughput reported as achieved performance | peak (64 MAC/cycle) appears only as a labelled capability; every table reports useful MACs / end-to-end cycles |

## Quick start

Needs Verilator >= 5.020, Python >= 3.10 with numpy; Yosys 0.33 and Icarus 12 optional.

```bash
make test        # lint + Python model tests + directed suite on all 8 configurations   (~1 min)
make regress     # + 10 random seeds per configuration                               (~3 min)
make mutation    # 25 mutants x {RTL checks on, end-to-end only}                     (~30 min)
make bench       # single- vs double-buffered measurements                           (~15 min)
make synth       # Yosys resource estimates                                          (~10 min)
make report      # regenerate docs/RESULTS.md
```

One configuration by hand:

```bash
python3 model/gen_tests.py --cfg base --suite all --out build/tests/base
scripts/vbuild.sh build/sim/base -GTM=8 -GTN=8 -GTK=1 -GKT=32 -GBUS_BYTES=16 -GIN_BUFS=2 -GOUT_BUFS=2
build/sim/base/sim +DIR=build/tests/base/d09_overflow +VERBOSE=1     # prints TB_RESULT: PASS|FAIL
```

## Headline results

Every run is seeded and the memory model is deterministic: re-running `scripts/bench.py` with
the same arguments from the extracted archive reproduced all 48 checked benchmark runs
bit-identically (every counter). Job placement depends on the set of jobs in a test, so a
different selection of workloads/profiles moves the GPU-traffic profile by < 0.1 %.

From `docs/RESULTS.md` (8 x 8 array, TK = 1, 16-byte port, 16 reads in flight; peak capability
64 MAC/cycle). Single (SB) and double buffered (DB) run the same jobs on the same memory model.

* **Near memory (16-cycle latency, 16 B/cycle shared by reads and writes):** DB finishes
  **1.83x-2.25x** sooner than SB on the full-tile workloads, but only 1.37x on the
  tail-heavy 65x65x65 job and 1.34x on a 9x9x9 job; against a single-buffered design with
  the *same* operand storage the gain is **1.25x-1.95x**.
  Achieved compute utilisation rises from 19-38 % (SB) to **26-77 % (DB)**; DB sustains
  12.0-15.3 B/cycle of the 16 available and comes within 5 % of the analytic lower bound
  on the bandwidth-bound shapes.
* **Accumulate mode (C += A*B)** gains most (2.25x): with one output buffer the
  accumulators wait for the per-row C_in read latency; the second output buffer hides it.
* **Far memory (100-cycle latency):** only **1.16x-1.58x** and at most 16 % utilisation.
  With 16 reads in flight the port delivers at most 16 x 16 B / 100 cycles, so both
  variants wait for the same bytes. The latency sweep shows the gain falling from 1.9x at
  16 cycles to **1.07x at 256 cycles** -- double buffering does not replace more
  outstanding reads.
* **Bytes:** the output-stationary schedule re-reads A per column and B per row of output
  tiles: 1.4x-8.2x the compulsory traffic; row-major B with narrow tiles also wastes beat
  bandwidth (transposed B is cheaper). These are reported as measured, not hidden.
* **GPU co-traffic** (30 % demand): DB keeps 1.34x-2.29x (1.30x on 9x9x9); it also takes
  a larger share of the port, so the stand-in is served less often (reported).
* **Resources (Yosys generic gates, all storage in flip-flops):** SB 109 k cells / 11.5 k
  flip-flops; DB **1.10x the cells and 1.54x the flip-flops** of SB (second operand bank +
  output buffer). The single-buffered variant with DB's operand storage (SB-iso) is *larger*
  than DB (1.14x SB cells, wider read multiplexers) and 1.25x-1.95x slower. The MAC array
  is about half of the logic; the controller's descriptor checks (three 20x20 multipliers)
  and 64-bit counters are a fifth.

## Verification at a glance

* **Regression:** 8 configurations (incl. 3x5 array, TK = 2/4, 4- to 32-byte bus,
  ACC_W = 16/20/24/32, 1-3 operand banks, 1 transaction in flight), 18 directed tests (19
  where K_MAX > 4096: the 131 071-long reduction) plus 30 random tests each: **6 936 jobs, every one checked, all pass** (`results/regression.md`).
  Each job checks C against the reference (or "old-or-new per element" when interrupted),
  every byte of memory for stray writes, the counters against the traffic model, the
  completion record, irq/status, and that nothing is in flight at completion.
* **Interrupted transfers and reset:** read/write error responses, aborts at 0-110 % of a
  job, resets at 0-90 % followed by an exact retry, memory freezes -- all leave every C
  element either old or new, never wrong, and nothing outside C touched.
* **Mutation testing:** 25 deliberate RTL bugs (ownership, tails, sign handling, overflow,
  byte routing, strides, drain, completion order, protocol, validation). **All 23
  non-equivalent mutants are detected -- also with the RTL's internal checks compiled out**,
  i.e. by the end-to-end checks alone. Two are expected survivors and argued in
  `docs/VERIFICATION.md` section 5: the bank "poison" bit is redundant while `stop` is
  immediate, and a combined mutant (late stop + no poison) proves what it protects.
* **Bugs found and fixed during development** are listed in `docs/VERIFICATION.md` section 6.

## Things you should know

* Local storage is flip-flops (transposing access); see ARCHITECTURE.md section 4.
* One job at a time; the descriptor registers are a shadow, so the next job can be
  programmed while one runs.
* The memory system must answer in order and make acknowledged writes visible; SF-MMA is
  not cache coherent (INTEGRATION.md sections 6-7).
* The GPU core is represented in the tests by a traffic generator on the shared port; the
  SIMT RTL itself was not co-simulated.
* `rtl/` contains inert `MUT_*` and `SF_MMA_NO_CHECKS` hooks used only by verification.
