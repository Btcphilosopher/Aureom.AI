// =============================================================================
// sf_mma_ctrl.sv -- CSR block, job sequencer, validation, error handling,
// completion reporting and performance counters
//
// Job life cycle
//   IDLE --START--> CHECK --ok--> RUN --all tiles issued / error / abort--> DRAIN
//                     |                                                     |
//                     +--descriptor rejected--+     every outstanding read   |
//                                             v     and write answered       v
//                                            CPL <----------------------------+
//                                             | (record enabled) --> CPLW --> done
//                                             +--------------------------------> done
//
//  * START snapshots the descriptor registers; they may be reprogrammed for the
//    next job while this one runs.  START while busy is ignored and sets
//    STATUS.REJECTED.
//  * DONE is reported only after every C write has been acknowledged by memory
//    (and, if enabled, the completion record as well): a consumer that sees DONE
//    or the record sees the data.
//  * On a memory error or ABORT the datapath stops issuing, every request that
//    is already presented or outstanding is completed and its response drained,
//    then the job completes with the error code.  Nothing is left in flight.
// =============================================================================
`default_nettype none

module sf_mma_ctrl #(
  parameter int TM        = 8,
  parameter int TN        = 8,
  parameter int TK        = 1,
  parameter int KT        = 32,
  parameter int BUS_BYTES = 16,
  parameter int IN_BUFS   = 2,
  parameter int OUT_BUFS  = 2,
  parameter int ACC_W     = 32,
  parameter int RD_OUT    = 16,
  parameter int WR_OUT    = 8,
  parameter int DIM_W     = 20
)(
  input  logic             clk,
  input  logic             rst_n,
  // CSR port
  input  logic             csr_valid,
  output logic             csr_ready,
  input  logic             csr_write,
  input  logic [7:0]       csr_addr,
  input  logic [31:0]      csr_wdata,
  output logic             csr_rvalid,
  output logic [31:0]      csr_rdata,
  output logic             irq,
  output logic             busy,
  // job parameters (stable from START to done)
  output logic [31:0]      j_a,
  output logic [31:0]      j_b,
  output logic [31:0]      j_c,
  output logic [31:0]      j_cpl,
  output logic [DIM_W-1:0] j_m,
  output logic [DIM_W-1:0] j_n,
  output logic [DIM_W-1:0] j_k,
  output logic [DIM_W-1:0] j_lda,
  output logic [DIM_W-1:0] j_ldb,
  output logic [DIM_W-1:0] j_ldc,
  output logic             j_accum,
  output logic             j_sat,
  output logic             j_transb,
  output logic             job_start,
  output logic             stop,
  output logic             run,
  // datapath status
  input  logic             ld_done,
  input  logic             rd_idle,
  input  logic             pipe_busy,
  input  logic             wr_all_done,
  input  logic             wr_halted,
  input  logic             wr_idle,
  input  logic             cpl_done,
  input  logic             rd_err_v,
  input  logic [31:0]      rd_err_addr,
  input  logic             wr_err_v,
  input  logic [31:0]      wr_err_addr,
  output logic             cpl_go,
  output logic [127:0]     cpl_rec,
  // performance events
  input  logic             ev_issue,
  input  logic [31:0]      ev_macs,
  input  logic             ev_rd_fire,
  input  logic             ev_wr_fire,
  input  logic [15:0]      ev_rd_bytes,
  input  logic [15:0]      ev_wr_bytes,
  input  logic             ev_st_load,
  input  logic             ev_st_store,
  input  logic             ev_rd_bp,
  input  logic             ev_wr_bp,
  input  logic             ev_ld_wait,
  input  logic             ev_rd_cred,
  input  logic             ev_tile,
  input  logic             ev_ktile,
  input  logic [15:0]      ev_ovf,
  input  logic             ev_spurious
);

  // ---------------------------------------------------------------- accumulation-length bound
  // |int8 * int8| <= 2^14, so K products stay inside ACC_W-bit two's complement
  // iff K * 2^14 <= 2^(ACC_W-1) - 1, i.e. K <= 2^(ACC_W-15) - 1.
  localparam logic [63:0] K_MAX   = (64'd1 << (ACC_W - 15)) - 64'd1;
  localparam logic [63:0] K_DIM   = (64'd1 << DIM_W) - 64'd1;
`ifdef MUT_KMAX_OB1
  localparam logic [63:0] K_LIMIT = ((K_MAX < K_DIM) ? K_MAX : K_DIM) + 64'd1;   // MUTANT: off by one
`else
  localparam logic [63:0] K_LIMIT = (K_MAX < K_DIM) ? K_MAX : K_DIM;
`endif
  localparam logic [63:0] ASPACE = 64'h1_0000_0000;

  localparam logic [2:0] J_IDLE  = 3'd0;
  localparam logic [2:0] J_CHECK = 3'd1;
  localparam logic [2:0] J_RUN   = 3'd2;
  localparam logic [2:0] J_DRAIN = 3'd3;
  localparam logic [2:0] J_CPL   = 3'd4;
  localparam logic [2:0] J_CPLW  = 3'd5;

  // ---------------------------------------------------------------- registers
  logic [31:0] r_a, r_b, r_c, r_cpl, r_m, r_n, r_k, r_lda, r_ldb, r_ldc, r_flags, r_tag;   // shadow
  logic [31:0] s_a, s_b, s_c, s_cpl, s_m, s_n, s_k, s_lda, s_ldb, s_ldc, s_flags, s_tag;   // job
  logic [2:0]  js;
  logic        done_f, rej_f, proto_f, abort_q, stop_q, cpl_ok;
  logic [3:0]  err;
  logic [31:0] err_addr, ovf_cnt;
  logic [31:0] c_cyc, c_dcyc, c_active, c_rd_beats, c_wr_beats, c_rd_bytes, c_wr_bytes;
  logic [31:0] c_st_load, c_st_store, c_rd_bp, c_wr_bp, c_ld_wait, c_rd_cred, c_tiles, c_ktiles, c_spur;
  logic [63:0] c_macs;

  assign j_a      = s_a;
  assign j_b      = s_b;
  assign j_c      = s_c;
  assign j_cpl    = s_cpl;
  assign j_m      = s_m[DIM_W-1:0];
  assign j_n      = s_n[DIM_W-1:0];
  assign j_k      = s_k[DIM_W-1:0];
  assign j_lda    = s_lda[DIM_W-1:0];
  assign j_ldb    = s_ldb[DIM_W-1:0];
  assign j_ldc    = s_ldc[DIM_W-1:0];
  assign j_accum  = s_flags[sf_mma_pkg::F_ACCUM];
  assign j_sat    = s_flags[sf_mma_pkg::F_SAT];
  assign j_transb = s_flags[sf_mma_pkg::F_TRANS_B];
  assign busy     = (js != J_IDLE);
`ifdef MUT_STOP_LATE
  logic [9:0] stop_dly;                                              // MUTANT: stop arrives 1000 cycles late
  always_ff @(posedge clk)
    if (!rst_n || !stop_q) stop_dly <= '0;
    else if (stop_dly != 10'd1000) stop_dly <= stop_dly + 10'd1;
  assign stop     = stop_q && (stop_dly == 10'd1000);
`else
  assign stop     = stop_q;
`endif
  assign run      = (js == J_RUN) || (js == J_DRAIN);
  assign irq      = done_f && s_flags[sf_mma_pkg::F_IRQ_EN];
  assign csr_ready = 1'b1;

  // ---------------------------------------------------------------- CSR writes
  logic wr, ctrl_wr, start_req, abort_wr, clear_wr;
  assign wr        = csr_valid && csr_write;
  assign ctrl_wr   = wr && (csr_addr == sf_mma_pkg::CSR_CTRL);
  assign start_req = ctrl_wr && csr_wdata[sf_mma_pkg::CTRL_START];
  assign abort_wr  = ctrl_wr && csr_wdata[sf_mma_pkg::CTRL_ABORT];
  assign clear_wr  = ctrl_wr && csr_wdata[sf_mma_pkg::CTRL_CLEAR];

  // ---------------------------------------------------------------- descriptor validation
  logic [DIM_W-1:0] vm, vn, vk, vlda, vldb, vldc;
  assign vm = s_m[DIM_W-1:0];  assign vn = s_n[DIM_W-1:0];  assign vk = s_k[DIM_W-1:0];
  assign vlda = s_lda[DIM_W-1:0]; assign vldb = s_ldb[DIM_W-1:0]; assign vldc = s_ldc[DIM_W-1:0];

  logic        tb, cpl_en;
  logic        dims_fit, lds_fit, dim_bad, kmax_bad, ld_bad, align_bad, range_bad, alias_bad;
  logic [63:0] a_end, b_end, c_end, cpl_end;
  logic [3:0]  vcode;
  assign tb     = s_flags[sf_mma_pkg::F_TRANS_B];
  assign cpl_en = s_flags[sf_mma_pkg::F_CPL_EN];

  always_comb begin
    logic [63:0] a_ext, b_ext, c_ext;
    dims_fit = ((s_m >> DIM_W) == 0) && ((s_n >> DIM_W) == 0) && ((s_k >> DIM_W) == 0);
    lds_fit  = ((s_lda >> DIM_W) == 0) && ((s_ldb >> DIM_W) == 0) && ((s_ldc >> DIM_W) == 0);
    dim_bad  = !dims_fit || (s_m == 0) || (s_n == 0) || (s_k == 0);
    kmax_bad = (64'(s_k) > K_LIMIT);
`ifdef MUT_LDB_NN
    ld_bad   = !lds_fit || (s_lda < s_k) || (s_ldb < s_k) || (s_ldc < s_n);          // MUTANT
`else
    ld_bad   = !lds_fit || (s_lda < s_k) || (tb ? (s_ldb < s_k) : (s_ldb < s_n)) || (s_ldc < s_n);
`endif
    align_bad = (s_c[1:0] != 2'b00) || (cpl_en && (s_cpl[3:0] != 4'h0));
    // extents (exclusive end addresses), meaningful once the dimensions are legal
    a_ext = (64'(vm) - 64'd1) * 64'(vlda) + 64'(vk);
    b_ext = tb ? ((64'(vn) - 64'd1) * 64'(vldb) + 64'(vk)) : ((64'(vk) - 64'd1) * 64'(vldb) + 64'(vn));
    c_ext = ((64'(vm) - 64'd1) * 64'(vldc) + 64'(vn)) * 64'd4;
    a_end   = 64'(s_a) + a_ext;
    b_end   = 64'(s_b) + b_ext;
    c_end   = 64'(s_c) + c_ext;
    cpl_end = 64'(s_cpl) + 64'd16;
    range_bad = (a_end > ASPACE) || (b_end > ASPACE) || (c_end > ASPACE) || (cpl_en && cpl_end > ASPACE);
`ifdef MUT_ALIAS_OFF
    alias_bad = 1'b0;                                                                // MUTANT
`else
    // conservative bounding-interval test: C may not overlap A or B at all
    alias_bad = ((64'(s_c) < a_end) && (64'(s_a) < c_end)) || ((64'(s_c) < b_end) && (64'(s_b) < c_end));
`endif
    if (dim_bad)        vcode = sf_mma_pkg::ERR_DIM;
    else if (kmax_bad)  vcode = sf_mma_pkg::ERR_KMAX;
    else if (ld_bad)    vcode = sf_mma_pkg::ERR_LD;
    else if (align_bad) vcode = sf_mma_pkg::ERR_ALIGN;
    else if (range_bad) vcode = sf_mma_pkg::ERR_RANGE;
    else if (alias_bad) vcode = sf_mma_pkg::ERR_ALIAS;
    else                vcode = sf_mma_pkg::ERR_NONE;
  end

  // ---------------------------------------------------------------- sequencing
  logic quiet;
`ifdef MUT_NO_DRAIN
  assign quiet = ld_done && !pipe_busy && (wr_all_done || wr_halted) && wr_idle;          // MUTANT: reads not drained
`elsif MUT_EARLY_DONE
  assign quiet = ld_done && rd_idle && !pipe_busy && (wr_all_done || wr_halted);           // MUTANT: writes not acked
`else
  assign quiet = ld_done && rd_idle && !pipe_busy && (wr_all_done || wr_halted) && wr_idle;
`endif

  logic cplw_fin;
`ifdef MUT_EARLY_DONE
  assign cplw_fin = cpl_done;
`else
  assign cplw_fin = cpl_done && wr_idle;
`endif

  logic mem_err, abort_now;
  assign mem_err   = (rd_err_v || wr_err_v) && (js == J_RUN || js == J_DRAIN || js == J_CPLW);
  assign abort_now = abort_wr && (js == J_RUN);

  assign job_start = (js == J_CHECK) && (vcode == sf_mma_pkg::ERR_NONE) && !abort_q && !abort_wr;
  assign cpl_go    = (js == J_CPL) && cpl_ok;
  assign cpl_rec   = {32'h8000_0000 | {23'd0, (ovf_cnt != 32'd0), 4'd0, err},   // word 3: status (written last)
                      s_tag,                                                    // word 2: tag
                      ovf_cnt,                                                  // word 1: overflowed elements
                      c_dcyc};                                                  // word 0: cycles to data complete

  logic finish;
  assign finish = ((js == J_CPL) && !cpl_ok) || ((js == J_CPLW) && cplw_fin);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      {r_a, r_b, r_c, r_cpl, r_m, r_n, r_k, r_lda, r_ldb, r_ldc, r_flags, r_tag} <= '0;
      {s_a, s_b, s_c, s_cpl, s_m, s_n, s_k, s_lda, s_ldb, s_ldc, s_flags, s_tag} <= '0;
      js <= J_IDLE;
      done_f <= 1'b0; rej_f <= 1'b0; proto_f <= 1'b0; abort_q <= 1'b0; stop_q <= 1'b0; cpl_ok <= 1'b0;
      err <= '0; err_addr <= '0; ovf_cnt <= '0;
      {c_cyc, c_dcyc, c_active, c_rd_beats, c_wr_beats, c_rd_bytes, c_wr_bytes} <= '0;
      {c_st_load, c_st_store, c_rd_bp, c_wr_bp, c_ld_wait, c_rd_cred, c_tiles, c_ktiles, c_spur} <= '0;
      c_macs <= '0;
    end else begin
      // shadow descriptor registers: always writable
      if (wr) begin
        case (csr_addr)
          sf_mma_pkg::CSR_A_BASE:   r_a     <= csr_wdata;
          sf_mma_pkg::CSR_B_BASE:   r_b     <= csr_wdata;
          sf_mma_pkg::CSR_C_BASE:   r_c     <= csr_wdata;
          sf_mma_pkg::CSR_CPL_ADDR: r_cpl   <= csr_wdata;
          sf_mma_pkg::CSR_M:        r_m     <= csr_wdata;
          sf_mma_pkg::CSR_N:        r_n     <= csr_wdata;
          sf_mma_pkg::CSR_K:        r_k     <= csr_wdata;
          sf_mma_pkg::CSR_LDA:      r_lda   <= csr_wdata;
          sf_mma_pkg::CSR_LDB:      r_ldb   <= csr_wdata;
          sf_mma_pkg::CSR_LDC:      r_ldc   <= csr_wdata;
          sf_mma_pkg::CSR_FLAGS:    r_flags <= csr_wdata;
          sf_mma_pkg::CSR_TAG:      r_tag   <= csr_wdata;
          default: ;
        endcase
      end
      if (clear_wr) begin done_f <= 1'b0; rej_f <= 1'b0; end
      if (start_req && js != J_IDLE) rej_f <= 1'b1;
      if (ev_spurious) begin proto_f <= 1'b1; c_spur <= c_spur + 32'd1; end

      // performance counters (only while a job is active)
      if (js != J_IDLE) begin
        c_cyc <= c_cyc + 32'd1;
        if (js == J_CHECK || js == J_RUN || js == J_DRAIN) c_dcyc <= c_dcyc + 32'd1;
        c_active   <= c_active   + 32'(ev_issue);
        c_macs     <= c_macs     + 64'(ev_macs);
        c_rd_beats <= c_rd_beats + 32'(ev_rd_fire);
        c_wr_beats <= c_wr_beats + 32'(ev_wr_fire);
        c_rd_bytes <= c_rd_bytes + 32'(ev_rd_bytes);
        c_wr_bytes <= c_wr_bytes + 32'(ev_wr_bytes);
        c_st_load  <= c_st_load  + 32'(ev_st_load);
        c_st_store <= c_st_store + 32'(ev_st_store);
        c_rd_bp    <= c_rd_bp    + 32'(ev_rd_bp);
        c_wr_bp    <= c_wr_bp    + 32'(ev_wr_bp);
        c_ld_wait  <= c_ld_wait  + 32'(ev_ld_wait);
        c_rd_cred  <= c_rd_cred  + 32'(ev_rd_cred);
        c_tiles    <= c_tiles    + 32'(ev_tile);
        c_ktiles   <= c_ktiles   + 32'(ev_ktile);
        ovf_cnt    <= ovf_cnt    + 32'(ev_ovf);
      end

      // errors: the first one wins
      if (mem_err && err == sf_mma_pkg::ERR_NONE) begin
        err      <= rd_err_v ? sf_mma_pkg::ERR_RD : sf_mma_pkg::ERR_WR;
        err_addr <= rd_err_v ? rd_err_addr : wr_err_addr;
      end
      if (mem_err && (js == J_RUN || js == J_DRAIN)) stop_q <= 1'b1;
      if (abort_now) begin
        stop_q <= 1'b1;
        if (err == sf_mma_pkg::ERR_NONE && !mem_err) err <= sf_mma_pkg::ERR_ABORT;
      end
      if (abort_wr && js == J_CHECK) abort_q <= 1'b1;

      case (js)
        J_IDLE: if (start_req) begin
          {s_a, s_b, s_c, s_cpl, s_m, s_n, s_k, s_lda, s_ldb, s_ldc, s_flags, s_tag}
            <= {r_a, r_b, r_c, r_cpl, r_m, r_n, r_k, r_lda, r_ldb, r_ldc, r_flags, r_tag};
          js <= J_CHECK;
          done_f <= 1'b0; rej_f <= 1'b0; abort_q <= 1'b0; stop_q <= 1'b0;
          err <= '0; err_addr <= '0; ovf_cnt <= '0;
          {c_cyc, c_dcyc, c_active, c_rd_beats, c_wr_beats, c_rd_bytes, c_wr_bytes} <= '0;
          {c_st_load, c_st_store, c_rd_bp, c_wr_bp, c_ld_wait, c_rd_cred, c_tiles, c_ktiles} <= '0;
          c_macs <= '0;
        end
        J_CHECK: begin
          cpl_ok <= cpl_en && (s_cpl[3:0] == 4'h0) && (cpl_end <= ASPACE);
          if (vcode != sf_mma_pkg::ERR_NONE) begin
            err <= vcode;
            js  <= J_CPL;
          end else if (abort_q || abort_wr) begin
            err <= sf_mma_pkg::ERR_ABORT;
            js  <= J_CPL;
          end else begin
            js <= J_RUN;
          end
        end
        J_RUN:   if (stop_q || mem_err || abort_now || wr_all_done) js <= J_DRAIN;
        J_DRAIN: if (quiet) js <= J_CPL;
        J_CPL:   if (cpl_ok) js <= J_CPLW;
        default: ;
      endcase
      if (finish) begin
        js     <= J_IDLE;
        done_f <= 1'b1;
      end
    end
  end

  // ---------------------------------------------------------------- CSR reads (1-cycle latency)
  logic [31:0] rd_mux;
  always_comb begin
    case (csr_addr)
      sf_mma_pkg::CSR_ID:       rd_mux = sf_mma_pkg::ID_VALUE;
      sf_mma_pkg::CSR_VERSION:  rd_mux = sf_mma_pkg::VERSION_VALUE;
      sf_mma_pkg::CSR_CFG0:     rd_mux = {8'(BUS_BYTES), 8'(TK), 8'(TN), 8'(TM)};
      sf_mma_pkg::CSR_CFG1:     rd_mux = {8'(ACC_W), 4'(OUT_BUFS), 4'(IN_BUFS), 16'(KT)};
      sf_mma_pkg::CSR_CFG2:     rd_mux = K_LIMIT[31:0];
      sf_mma_pkg::CSR_CFG3:     rd_mux = {8'(DIM_W), 8'(WR_OUT), 16'(RD_OUT)};
      sf_mma_pkg::CSR_STATUS:   begin
        rd_mux = '0;
        rd_mux[sf_mma_pkg::ST_BUSY]     = busy;
        rd_mux[sf_mma_pkg::ST_DONE]     = done_f;
        rd_mux[sf_mma_pkg::ST_IRQ]      = irq;
        rd_mux[sf_mma_pkg::ST_REJECTED] = rej_f;
        rd_mux[sf_mma_pkg::ST_OVF]      = (ovf_cnt != 32'd0);
        rd_mux[sf_mma_pkg::ST_PROTO]    = proto_f;
        rd_mux[11:8]                    = err;
      end
      sf_mma_pkg::CSR_A_BASE:   rd_mux = r_a;
      sf_mma_pkg::CSR_B_BASE:   rd_mux = r_b;
      sf_mma_pkg::CSR_C_BASE:   rd_mux = r_c;
      sf_mma_pkg::CSR_CPL_ADDR: rd_mux = r_cpl;
      sf_mma_pkg::CSR_M:        rd_mux = r_m;
      sf_mma_pkg::CSR_N:        rd_mux = r_n;
      sf_mma_pkg::CSR_K:        rd_mux = r_k;
      sf_mma_pkg::CSR_LDA:      rd_mux = r_lda;
      sf_mma_pkg::CSR_LDB:      rd_mux = r_ldb;
      sf_mma_pkg::CSR_LDC:      rd_mux = r_ldc;
      sf_mma_pkg::CSR_FLAGS:    rd_mux = r_flags;
      sf_mma_pkg::CSR_TAG:      rd_mux = r_tag;
      sf_mma_pkg::CSR_ERR_ADDR: rd_mux = err_addr;
      sf_mma_pkg::CSR_OVF_CNT:  rd_mux = ovf_cnt;
      sf_mma_pkg::CSR_CYC:      rd_mux = c_cyc;
      sf_mma_pkg::CSR_DCYC:     rd_mux = c_dcyc;
      sf_mma_pkg::CSR_ACTIVE:   rd_mux = c_active;
      sf_mma_pkg::CSR_MACS_LO:  rd_mux = c_macs[31:0];
      sf_mma_pkg::CSR_MACS_HI:  rd_mux = c_macs[63:32];
      sf_mma_pkg::CSR_RD_BEATS: rd_mux = c_rd_beats;
      sf_mma_pkg::CSR_WR_BEATS: rd_mux = c_wr_beats;
      sf_mma_pkg::CSR_RD_BYTES: rd_mux = c_rd_bytes;
      sf_mma_pkg::CSR_WR_BYTES: rd_mux = c_wr_bytes;
      sf_mma_pkg::CSR_ST_LOAD:  rd_mux = c_st_load;
      sf_mma_pkg::CSR_ST_STORE: rd_mux = c_st_store;
      sf_mma_pkg::CSR_RD_BP:    rd_mux = c_rd_bp;
      sf_mma_pkg::CSR_WR_BP:    rd_mux = c_wr_bp;
      sf_mma_pkg::CSR_LD_WAIT:  rd_mux = c_ld_wait;
      sf_mma_pkg::CSR_RD_CRED:  rd_mux = c_rd_cred;
      sf_mma_pkg::CSR_TILES:    rd_mux = c_tiles;
      sf_mma_pkg::CSR_KTILES:   rd_mux = c_ktiles;
      sf_mma_pkg::CSR_SPURIOUS: rd_mux = c_spur;
      default:                  rd_mux = 32'd0;
    endcase
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      csr_rvalid <= 1'b0;
      csr_rdata  <= '0;
    end else begin
      csr_rvalid <= csr_valid && !csr_write;
      if (csr_valid && !csr_write) csr_rdata <= rd_mux;
    end
  end

endmodule

`default_nettype wire
