// =============================================================================
// sf_mma_pkg.sv -- shared constants of the SilicaFlux matrix multiply-accumulate
// accelerator (SF-MMA).  Only localparams live here (no types), so the RTL parses
// in Verilator 5.020, Icarus 12 and Yosys 0.33.  Modules reference constants as
// sf_mma_pkg::NAME (Yosys 0.33 does not accept `import` inside a module body).
// =============================================================================
package sf_mma_pkg;

  // ---------------------------------------------------------------------------
  // Completion / error codes  (STATUS[11:8], completion record word 3 [3:0])
  // The first error of a job wins; later errors do not overwrite the code.
  // ---------------------------------------------------------------------------
  localparam logic [3:0] ERR_NONE  = 4'd0;  // job completed, every C element written
  localparam logic [3:0] ERR_DIM   = 4'd1;  // M, N or K is zero or >= 2^DIM_W
  localparam logic [3:0] ERR_KMAX  = 4'd2;  // K > K_LIMIT (accumulation-length bound)
  localparam logic [3:0] ERR_LD    = 4'd3;  // a leading dimension is too small or >= 2^DIM_W
  localparam logic [3:0] ERR_ALIGN = 4'd4;  // C base not 4-byte / completion address not 16-byte aligned
  localparam logic [3:0] ERR_RANGE = 4'd5;  // an operand region wraps the 32-bit address space
  localparam logic [3:0] ERR_ALIAS = 4'd6;  // the C region overlaps the A or the B region
  localparam logic [3:0] ERR_RD    = 4'd7;  // memory answered a read beat with an error
  localparam logic [3:0] ERR_WR    = 4'd8;  // memory answered a write beat with an error
  localparam logic [3:0] ERR_ABORT = 4'd9;  // CTRL.ABORT while the job was running

  // ---------------------------------------------------------------------------
  // CSR map (byte offsets on the 32-bit MMIO port)
  // ---------------------------------------------------------------------------
  localparam logic [7:0] CSR_ID       = 8'h00;  // RO  0x534D4D41 "SMMA"
  localparam logic [7:0] CSR_VERSION  = 8'h04;  // RO
  localparam logic [7:0] CSR_CFG0     = 8'h08;  // RO  TM | TN<<8 | TK<<16 | BUS_BYTES<<24
  localparam logic [7:0] CSR_CFG1     = 8'h0C;  // RO  KT | IN_BUFS<<16 | OUT_BUFS<<20 | ACC_W<<24
  localparam logic [7:0] CSR_CFG2     = 8'h10;  // RO  K_LIMIT
  localparam logic [7:0] CSR_CFG3     = 8'h14;  // RO  RD_OUT | WR_OUT<<16 | DIM_W<<24
  localparam logic [7:0] CSR_CTRL     = 8'h18;  // WO  bit0 START, bit1 ABORT, bit2 CLEAR
  localparam logic [7:0] CSR_STATUS   = 8'h1C;  // RO  see STATUS bits below
  localparam logic [7:0] CSR_A_BASE   = 8'h20;
  localparam logic [7:0] CSR_B_BASE   = 8'h24;
  localparam logic [7:0] CSR_C_BASE   = 8'h28;
  localparam logic [7:0] CSR_CPL_ADDR = 8'h2C;
  localparam logic [7:0] CSR_M        = 8'h30;
  localparam logic [7:0] CSR_N        = 8'h34;
  localparam logic [7:0] CSR_K        = 8'h38;
  localparam logic [7:0] CSR_LDA      = 8'h3C;
  localparam logic [7:0] CSR_LDB      = 8'h40;
  localparam logic [7:0] CSR_LDC      = 8'h44;
  localparam logic [7:0] CSR_FLAGS    = 8'h48;
  localparam logic [7:0] CSR_TAG      = 8'h4C;
  localparam logic [7:0] CSR_ERR_ADDR = 8'h50;  // RO  beat address of the first memory error
  localparam logic [7:0] CSR_OVF_CNT  = 8'h54;  // RO  C elements that overflowed ACC_W (accumulate mode)
  // performance counters (RO, cleared by an accepted START, frozen at DONE)
  localparam logic [7:0] CSR_CYC      = 8'h60;  // START accepted .. DONE
  localparam logic [7:0] CSR_DCYC     = 8'h64;  // START accepted .. last C write acknowledged
  localparam logic [7:0] CSR_ACTIVE   = 8'h68;  // cycles in which the MAC array issued a step
  localparam logic [7:0] CSR_MACS_LO  = 8'h6C;  // useful (in-range) multiply-accumulates
  localparam logic [7:0] CSR_MACS_HI  = 8'h70;
  localparam logic [7:0] CSR_RD_BEATS = 8'h74;  // read beats accepted by memory
  localparam logic [7:0] CSR_WR_BEATS = 8'h78;  // write beats accepted by memory (incl. completion record)
  localparam logic [7:0] CSR_RD_BYTES = 8'h7C;  // useful bytes requested by reads
  localparam logic [7:0] CSR_WR_BYTES = 8'h80;  // strobed bytes written
  localparam logic [7:0] CSR_ST_LOAD  = 8'h84;  // array idle: next operand bank not yet loaded
  localparam logic [7:0] CSR_ST_STORE = 8'h88;  // array idle: output buffer still owned by the writer
  localparam logic [7:0] CSR_RD_BP    = 8'h8C;  // rd_req_valid && !rd_req_ready
  localparam logic [7:0] CSR_WR_BP    = 8'h90;  // wr_req_valid && !wr_req_ready
  localparam logic [7:0] CSR_LD_WAIT  = 8'h94;  // loader idle: no free operand bank
  localparam logic [7:0] CSR_RD_CRED  = 8'h98;  // read request held back by the outstanding-read limit
  localparam logic [7:0] CSR_TILES    = 8'h9C;  // output tiles written
  localparam logic [7:0] CSR_KTILES   = 8'hA0;  // operand k-tiles loaded
  localparam logic [7:0] CSR_SPURIOUS = 8'hA4;  // responses with nothing outstanding (protocol errors)

  // CTRL bits
  localparam int CTRL_START = 0;
  localparam int CTRL_ABORT = 1;
  localparam int CTRL_CLEAR = 2;

  // STATUS bits
  localparam int ST_BUSY     = 0;
  localparam int ST_DONE     = 1;
  localparam int ST_IRQ      = 2;
  localparam int ST_REJECTED = 3;   // a START arrived while busy (sticky until CLEAR or accepted START)
  localparam int ST_OVF      = 4;   // last job produced >= 1 overflowed element
  localparam int ST_PROTO    = 5;   // a spurious memory response was seen (sticky until reset)
  // STATUS[11:8] = error code of the last job

  // FLAGS bits
  localparam int F_ACCUM   = 0;     // C = C + A*B (C read back, in place) instead of C = A*B
  localparam int F_SAT     = 1;     // saturate on overflow (else wrap modulo 2^ACC_W)
  localparam int F_TRANS_B = 2;     // B stored N x K row-major ("B transposed")
  localparam int F_IRQ_EN  = 3;     // raise irq when DONE
  localparam int F_CPL_EN  = 4;     // write a 16-byte completion record to CPL_ADDR

  // read-beat destinations
  localparam logic [1:0] DST_A   = 2'd0;
  localparam logic [1:0] DST_B   = 2'd1;
  localparam logic [1:0] DST_CIN = 2'd2;

  // operand bank ownership states
  localparam logic [1:0] BK_FREE    = 2'd0;  // owned by nobody, may be claimed by the loader
  localparam logic [1:0] BK_LOADING = 2'd1;  // owned by the loader / DMA (written by read responses)
  localparam logic [1:0] BK_FULL    = 2'd2;  // all beats arrived, owned by the compute engine (unread)
  localparam logic [1:0] BK_BUSY    = 2'd3;  // compute engine is reading it

  localparam logic [31:0] ID_VALUE      = 32'h534D_4D41;
  localparam logic [31:0] VERSION_VALUE = 32'h0001_0000;

endpackage
