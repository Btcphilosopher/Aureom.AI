// =============================================================================
// sf_mma_opbuf.sv -- local operand storage and its ownership state machine
//
// NB banks, each holding one A k-tile (TM x KT int8) and one B k-tile (KT x TN
// int8, stored n-major as bbuf[bank][n][k] so both layouts of B in memory map
// to it).  Storage is flip-flops: DMA beats write a row of A or B at a time
// while the MAC array reads a k-column slice, a transposing access pattern a
// single-ported SRAM macro cannot serve in one cycle (see docs/ARCHITECTURE.md).
//
// Per-bank ownership:
//
//        claim (loader)          all beats in, no error        first step issued
//  FREE ---------------> LOADING ------------------------> FULL -----------------> BUSY
//   ^                                                        |                       |
//   +---------------------- last step issued (compute) ------+-----------------------+
//
//  * read-response beats may write a bank ONLY in LOADING
//  * the MAC array may read a bank ONLY in FULL / BUSY
//  * the loader may claim a bank ONLY in FREE
//  * a bank that received an error beat is poisoned: it never becomes FULL
//    (the job is being stopped; job_start returns every bank to FREE)
// These are checked every cycle in simulation (chk_fail / $error).
// =============================================================================
`default_nettype none

module sf_mma_opbuf #(
  parameter int TM    = 8,
  parameter int TN    = 8,
  parameter int KT    = 32,
  parameter int NB    = 2,
  parameter int SLOTS = 32
)(
  input  logic                   clk,
  input  logic                   rst_n,
  input  logic                   job_start,
  input  logic                   trans_b,
  // loader
  input  logic                   claim_v,
  input  logic [1:0]             claim_bank,
  input  logic [15:0]            claim_mv,
  input  logic [15:0]            claim_nv,
  input  logic [15:0]            claim_kv,
  input  logic                   claim_first,
  input  logic                   claim_last,
  input  logic                   issued_v,
  input  logic [1:0]             issued_bank,
  input  logic                   acc_v,         // a loader beat entered the read port
  input  logic [1:0]             acc_bank,
  // read responses
  input  logic                   rsp_v,
  input  logic                   rsp_err_v,
  input  logic [1:0]             rsp_dst,
  input  logic [1:0]             rsp_bank,
  input  logic [15:0]            rsp_row,
  input  logic [SLOTS-1:0]       slot_en,
  input  logic [SLOTS*8-1:0]     slot_data,
  // compute engine
  input  logic                   cp_start_v,
  input  logic [1:0]             cp_start_bank,
  input  logic                   cp_rel_v,
  input  logic [1:0]             cp_rel_bank,
  // state
  output logic [NB-1:0]          bank_free,
  output logic [NB-1:0]          bank_ready,    // FULL or BUSY
  output logic [NB*16-1:0]       d_mv,
  output logic [NB*16-1:0]       d_nv,
  output logic [NB*16-1:0]       d_kv,
  output logic [NB-1:0]          d_first,
  output logic [NB-1:0]          d_last,
  output logic [NB*TM*KT*8-1:0]  abuf,          // [bank][m][k]
  output logic [NB*TN*KT*8-1:0]  bbuf,          // [bank][n][k]
  output logic                   chk_fail
);

  logic [1:0]  bst  [NB];
  logic [15:0] pend [NB];
  logic        issd [NB];
  logic        pois [NB];

  logic rsp_any_op;   // a response (good or bad) for an operand bank
  assign rsp_any_op = (rsp_v || rsp_err_v) && (rsp_dst != sf_mma_pkg::DST_CIN);

  always_ff @(posedge clk) begin
    if (!rst_n || job_start) begin
      for (int b = 0; b < NB; b++) begin
        bst[b] <= sf_mma_pkg::BK_FREE; pend[b] <= '0; issd[b] <= 1'b0; pois[b] <= 1'b0;
      end
      if (!rst_n) begin
        d_mv <= '0; d_nv <= '0; d_kv <= '0; d_first <= '0; d_last <= '0;
      end
    end else begin
      for (int b = 0; b < NB; b++) begin
        logic [15:0] pend_n;
        logic        issd_n, pois_n;
        pend_n = pend[b] + 16'(acc_v && (32'(acc_bank) == b))
                         - 16'(rsp_any_op && (32'(rsp_bank) == b));
        issd_n = issd[b] || (issued_v && (32'(issued_bank) == b));
`ifdef MUT_NO_POISON
        pois_n = 1'b0;                                        // MUTANT: error beats do not poison
`else
        pois_n = pois[b] || (rsp_err_v && (rsp_dst != sf_mma_pkg::DST_CIN) && (32'(rsp_bank) == b));
`endif
        pend[b] <= pend_n;
        issd[b] <= issd_n;
        pois[b] <= pois_n;
        case (bst[b])
          sf_mma_pkg::BK_FREE: if (claim_v && 32'(claim_bank) == b) begin
            bst[b]  <= sf_mma_pkg::BK_LOADING;
            pend[b] <= '0; issd[b] <= 1'b0; pois[b] <= 1'b0;
            d_mv[b*16 +: 16] <= claim_mv;
            d_nv[b*16 +: 16] <= claim_nv;
            d_kv[b*16 +: 16] <= claim_kv;
            d_first[b] <= claim_first;
            d_last[b]  <= claim_last;
          end
          sf_mma_pkg::BK_LOADING:
`ifdef MUT_FULL_EARLY
            if (issd_n && !pois_n)                            // MUTANT: do not wait for the data
`else
            if (issd_n && pend_n == 16'd0 && !pois_n)
`endif
              bst[b] <= sf_mma_pkg::BK_FULL;
          sf_mma_pkg::BK_FULL:
            if (cp_rel_v && 32'(cp_rel_bank) == b)          bst[b] <= sf_mma_pkg::BK_FREE;
            else if (cp_start_v && 32'(cp_start_bank) == b) bst[b] <= sf_mma_pkg::BK_BUSY;
          default: // BK_BUSY
            if (cp_rel_v && 32'(cp_rel_bank) == b)          bst[b] <= sf_mma_pkg::BK_FREE;
        endcase
      end
    end
  end

  always_comb begin
    for (int b = 0; b < NB; b++) begin
      bank_free[b]  = (bst[b] == sf_mma_pkg::BK_FREE);
      bank_ready[b] = (bst[b] == sf_mma_pkg::BK_FULL) || (bst[b] == sf_mma_pkg::BK_BUSY);
    end
  end

  // ---------------------------------------------------------------- data writes
  // A beat of an A row:            abuf[bank][row][i]  <- slot i      (i = k)
  // A beat of a row-major B row:   bbuf[bank][i][row]  <- slot i      (row = k, i = n)
  // A beat of a transposed B row:  bbuf[bank][row][i]  <- slot i      (row = n, i = k)
  logic wr_a, wr_b;
  assign wr_a = rsp_v && (rsp_dst == sf_mma_pkg::DST_A);
  assign wr_b = rsp_v && (rsp_dst == sf_mma_pkg::DST_B);

  always_ff @(posedge clk) begin
    for (int b = 0; b < NB; b++) begin
      for (int r = 0; r < TM; r++)
        for (int i = 0; i < KT; i++)
          if (wr_a && 32'(rsp_bank) == b && 32'(rsp_row) == r && slot_en[i])
            abuf[((b*TM + r)*KT + i)*8 +: 8] <= slot_data[i*8 +: 8];
      for (int n = 0; n < TN; n++)
        for (int k = 0; k < KT; k++) begin
          if (wr_b && 32'(rsp_bank) == b) begin
            if (trans_b) begin
              if (32'(rsp_row) == n && slot_en[k]) bbuf[((b*TN + n)*KT + k)*8 +: 8] <= slot_data[k*8 +: 8];
            end else begin
              if (32'(rsp_row) == k && slot_en[n]) bbuf[((b*TN + n)*KT + k)*8 +: 8] <= slot_data[n*8 +: 8];
            end
          end
        end
    end
  end

  // ---------------------------------------------------------------- ownership checks
  logic viol;
  always_comb begin
    viol = 1'b0;
    for (int b = 0; b < NB; b++) begin
      if (rsp_v && rsp_dst != sf_mma_pkg::DST_CIN && 32'(rsp_bank) == b && bst[b] != sf_mma_pkg::BK_LOADING) viol = 1'b1;
      if (claim_v && 32'(claim_bank) == b && bst[b] != sf_mma_pkg::BK_FREE) viol = 1'b1;
      if (cp_start_v && 32'(cp_start_bank) == b && bst[b] != sf_mma_pkg::BK_FULL) viol = 1'b1;
      if (cp_rel_v && 32'(cp_rel_bank) == b && !(bst[b] == sf_mma_pkg::BK_FULL || bst[b] == sf_mma_pkg::BK_BUSY)) viol = 1'b1;
    end
    if (32'(claim_bank) >= NB && claim_v) viol = 1'b1;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) chk_fail <= 1'b0;
`ifndef SF_MMA_NO_CHECKS
    else if (viol && !job_start) begin
      chk_fail <= 1'b1;
`ifndef SYNTHESIS
      $error("sf_mma_opbuf: buffer ownership violation (claim=%0d/%0d rsp=%0d/%0d start=%0d rel=%0d)",
             claim_v, claim_bank, rsp_v, rsp_bank, cp_start_v, cp_rel_v);
`endif
    end
`endif
  end

endmodule

`default_nettype wire
