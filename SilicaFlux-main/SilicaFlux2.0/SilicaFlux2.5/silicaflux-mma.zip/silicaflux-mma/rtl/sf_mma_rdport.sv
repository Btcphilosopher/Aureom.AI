// =============================================================================
// sf_mma_rdport.sv -- read side of the DMA
//
//  * two requesters: the writer (C_in rows in accumulate mode, higher priority,
//    it is the one holding the output buffer) and the loader (A/B operand rows)
//  * one output register: once rd_req_valid is asserted, address and routing
//    metadata stay stable until rd_req_ready (valid is never withdrawn, also not
//    on abort -- the request is completed and its response drained)
//  * at most RD_OUT beats outstanding; the metadata of every accepted beat is
//    kept in an in-order FIFO, responses must arrive in request order
//  * rd_rsp_ready is constant 1: buffer space for a beat is owned by its
//    requester before the beat is requested, so a response can always be sunk.
//    Back-pressure towards memory is applied on the request side instead
//    (credit limit, bank availability, output-buffer ownership).
//  * byte extraction: destination byte i of a row receives beat byte (i - d)
//    when 0 <= i - d < BUS_BYTES and i < len
// =============================================================================
`default_nettype none

module sf_mma_rdport #(
  parameter int BUS_BYTES = 16,
  parameter int RD_OUT    = 16,
  parameter int SLOTS     = 32      // widest destination row in bytes
)(
  input  logic                   clk,
  input  logic                   rst_n,
  input  logic                   stop,
  // loader (lower priority)
  input  logic                   l_v,
  output logic                   l_rdy,
  input  logic [31:0]            l_addr,
  input  logic [1:0]             l_dst,
  input  logic [1:0]             l_bank,
  input  logic [15:0]            l_row,
  input  logic [15:0]            l_d,
  input  logic [15:0]            l_len,
  // writer C_in (higher priority)
  input  logic                   w_v,
  output logic                   w_rdy,
  input  logic [31:0]            w_addr,
  input  logic [15:0]            w_d,
  input  logic [15:0]            w_len,
  // memory read channel
  output logic                   rd_req_valid,
  input  logic                   rd_req_ready,
  output logic [31:0]            rd_req_addr,
  input  logic                   rd_rsp_valid,
  output logic                   rd_rsp_ready,
  input  logic [BUS_BYTES*8-1:0] rd_rsp_data,
  input  logic                   rd_rsp_err,
  // routed response (at most one beat per cycle)
  output logic                   rsp_v,          // good beat
  output logic                   rsp_err_v,      // error beat (data discarded)
  output logic [31:0]            rsp_addr,
  output logic [1:0]             rsp_dst,
  output logic [1:0]             rsp_bank,
  output logic [15:0]            rsp_row,
  output logic [SLOTS-1:0]       slot_en,
  output logic [SLOTS*8-1:0]     slot_data,
  output logic [15:0]            slot_cnt,       // popcount(slot_en) of a good beat
  // status
  output logic                   idle,           // nothing queued and nothing outstanding
  output logic                   fire,           // beat accepted by memory this cycle
  output logic                   bp,             // rd_req_valid && !rd_req_ready
  output logic                   cred_stall,     // queued request held back by RD_OUT
  output logic                   spurious        // response with nothing outstanding (ignored)
);

  localparam int PW = (RD_OUT > 1) ? $clog2(RD_OUT) : 1;
  localparam int CW = $clog2(RD_OUT + 1);
  localparam int LB = $clog2(BUS_BYTES);

  // ---------------------------------------------------------------- output register
  logic        oq_v;
  logic [31:0] oq_addr;
  logic [1:0]  oq_dst, oq_bank;
  logic [15:0] oq_row, oq_d, oq_len;
  logic        hold;          // presented last cycle and not accepted: must stay valid

  logic [CW-1:0] cnt;
  logic          credit;
  assign credit = (cnt < CW'(RD_OUT));

`ifdef MUT_STOP_NOHOLD
  assign rd_req_valid = oq_v && credit && !stop;           // MUTANT: withdraws a presented request
`else
  assign rd_req_valid = oq_v && credit && (!stop || hold);
`endif
  assign rd_req_addr  = oq_addr;
  assign fire         = rd_req_valid && rd_req_ready;
  assign bp           = rd_req_valid && !rd_req_ready;
  assign cred_stall   = oq_v && !credit;

  logic oq_free;
  assign oq_free = !oq_v || fire;
  assign w_rdy   = oq_free && !stop;
  assign l_rdy   = oq_free && !stop && !w_v;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      oq_v <= 1'b0; hold <= 1'b0;
      oq_addr <= '0; oq_dst <= '0; oq_bank <= '0; oq_row <= '0; oq_d <= '0; oq_len <= '0;
    end else begin
      hold <= rd_req_valid && !rd_req_ready;
      if (w_v && w_rdy) begin
        oq_v <= 1'b1; oq_addr <= w_addr; oq_dst <= sf_mma_pkg::DST_CIN; oq_bank <= '0;
        oq_row <= '0; oq_d <= w_d; oq_len <= w_len;
      end else if (l_v && l_rdy) begin
        oq_v <= 1'b1; oq_addr <= l_addr; oq_dst <= l_dst; oq_bank <= l_bank;
        oq_row <= l_row; oq_d <= l_d; oq_len <= l_len;
      end else if (fire) begin
        oq_v <= 1'b0;
      end else if (stop && !rd_req_valid) begin
        oq_v <= 1'b0;            // never presented: drop it
      end
    end
  end

  // ---------------------------------------------------------------- in-order metadata FIFO
  logic [31:0] f_addr [RD_OUT];
  logic [1:0]  f_dst  [RD_OUT];
  logic [1:0]  f_bank [RD_OUT];
  logic [15:0] f_row  [RD_OUT];
  logic [15:0] f_d    [RD_OUT];
  logic [15:0] f_len  [RD_OUT];
  logic [PW-1:0] wp, rp;

  logic pop;
  assign pop          = rd_rsp_valid && (cnt != '0);
  assign spurious     = rd_rsp_valid && (cnt == '0);
  assign rd_rsp_ready = 1'b1;

  always_ff @(posedge clk) begin
    if (fire) begin
      f_addr[wp] <= oq_addr; f_dst[wp] <= oq_dst; f_bank[wp] <= oq_bank;
      f_row[wp]  <= oq_row;  f_d[wp]   <= oq_d;   f_len[wp]  <= oq_len;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0; cnt <= '0;
    end else begin
      if (fire) wp <= (32'(wp) == RD_OUT - 1) ? '0 : wp + PW'(1);
      if (pop)  rp <= (32'(rp) == RD_OUT - 1) ? '0 : rp + PW'(1);
      cnt <= cnt + CW'(fire) - CW'(pop);
    end
  end

  assign idle = !oq_v && (cnt == '0);

  // ---------------------------------------------------------------- response routing
  logic [15:0] h_d, h_len;
  assign h_d      = f_d[rp];
  assign h_len    = f_len[rp];
  assign rsp_addr = f_addr[rp];
  assign rsp_dst  = f_dst[rp];
  assign rsp_bank = f_bank[rp];
  assign rsp_row  = f_row[rp];
  assign rsp_v     = pop && !rd_rsp_err;
  assign rsp_err_v = pop &&  rd_rsp_err;

  // destination byte i  <-  beat byte j = i - d
  always_comb begin
    slot_cnt = '0;
    for (int i = 0; i < SLOTS; i++) begin
      logic signed [17:0] j;
`ifdef MUT_RSP_OFF1
      j = 18'(i) - 18'($signed(h_d)) + 18'sd1;              // MUTANT: off-by-one byte routing
`else
      j = 18'(i) - 18'($signed(h_d));
`endif
      slot_en[i] = (j >= 18'sd0) && (j < 18'(BUS_BYTES)) && (16'(i) < h_len);
      slot_data[i*8 +: 8] = rd_rsp_data[32'(j[LB-1:0])*8 +: 8];
      slot_cnt = slot_cnt + 16'(slot_en[i]);
    end
  end

endmodule

`default_nettype wire
