// =============================================================================
// sf_mma_writer.sv -- output accumulation, write-back, completion record
//
// Takes one finished output tile at a time from the MAC array (same raster order
// as the loader) and, row by row:
//   1. accumulate mode: reads the C_in row (the C elements being updated in
//      place) through the read port and waits for every beat
//   2. forms   exact = acc + C_in   in ACC_W+1 bits (cannot overflow there:
//      |acc| < 2^(ACC_W-1) and |C_in| <= 2^(ACC_W-1)), flags elements outside
//      the ACC_W range and either wraps (two's complement, mod 2^ACC_W) or
//      saturates them; the ACC_W result is sign-extended into a 32-bit word
//   3. writes the row with BUS_BYTES-aligned beats and byte strobes covering
//      exactly the n_valid elements (nothing outside the row is touched)
// The tile's buffer is released after the last beat of its last row has been
// accepted by memory -- the beats carry the data from then on.
//
// After the controller has seen every write acknowledged it may ask for the
// 16-byte completion record; it is written with the same beat engine, in
// ascending address order, status word last.
// =============================================================================
`default_nettype none

module sf_mma_writer #(
  parameter int TM        = 8,
  parameter int TN        = 8,
  parameter int BUS_BYTES = 16,
  parameter int WR_OUT    = 8,
  parameter int ACC_W     = 32,
  parameter int DIM_W     = 20,
  parameter int SLOTS     = 32
)(
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    job_start,
  input  logic                    stop,
  input  logic [31:0]             c_base,
  input  logic [31:0]             cpl_addr,
  input  logic [DIM_W-1:0]        dim_m,
  input  logic [DIM_W-1:0]        dim_n,
  input  logic [DIM_W-1:0]        ldc,
  input  logic                    accum,
  input  logic                    sat,
  // tile hand-off from the MAC array
  input  logic                    out_v,
  input  logic [TM*TN*ACC_W-1:0]  out_data,
  output logic                    wr_rel,
  // C_in read requests (to the read port) and returning data
  output logic                    w_v,
  input  logic                    w_rdy,
  output logic [31:0]             w_addr,
  output logic [15:0]             w_d,
  output logic [15:0]             w_len,
  input  logic                    rsp_v,
  input  logic                    rsp_err_v,
  input  logic [1:0]              rsp_dst,
  input  logic [SLOTS-1:0]        slot_en,
  input  logic [SLOTS*8-1:0]      slot_data,
  // memory write channel
  output logic                    wr_req_valid,
  input  logic                    wr_req_ready,
  output logic [31:0]             wr_req_addr,
  output logic [BUS_BYTES*8-1:0]  wr_req_data,
  output logic [BUS_BYTES-1:0]    wr_req_strb,
  input  logic                    wr_rsp_valid,
  output logic                    wr_rsp_ready,
  input  logic                    wr_rsp_err,
  // completion record
  input  logic                    cpl_go,
  input  logic [127:0]            cpl_rec,
  // status
  output logic                    all_done,      // every output tile handed to memory
  output logic                    halted,        // stopped, nothing presented
  output logic                    cpl_done,      // completion record handed to memory
  output logic                    wr_idle,       // nothing outstanding, nothing presented
  output logic                    err_v,
  output logic [31:0]             err_addr,
  output logic [15:0]             ovf_inc,
  output logic                    tile_done,
  output logic                    fire,
  output logic                    bp,
  output logic [15:0]             strb_cnt,
  output logic                    spurious
);

  localparam int ROWB = (4*TN > 16) ? 4*TN : 16;           // row buffer bytes
  localparam int PW   = (WR_OUT > 1) ? $clog2(WR_OUT) : 1;
  localparam int CW   = $clog2(WR_OUT + 1);
  localparam logic [31:0] BMASK = ~(32'(BUS_BYTES) - 32'd1);

  localparam logic [3:0] W_IDLE  = 4'd0;
  localparam logic [3:0] W_TILE  = 4'd1;
  localparam logic [3:0] W_ROW   = 4'd2;
  localparam logic [3:0] W_CIN   = 4'd3;
  localparam logic [3:0] W_CINW  = 4'd4;
  localparam logic [3:0] W_CALC  = 4'd5;
  localparam logic [3:0] W_WR    = 4'd6;
  localparam logic [3:0] W_FIN   = 4'd7;
  localparam logic [3:0] W_HALT  = 4'd8;
  localparam logic [3:0] W_CPL   = 4'd9;
  localparam logic [3:0] W_CPLWR = 4'd10;
  localparam logic [3:0] W_END   = 4'd11;

  logic [3:0]       st;
  logic [DIM_W-1:0] m0, n0;
  logic [31:0]      c_m_addr;        // c_base + 4*m0*ldc
  logic [15:0]      r, t_mv, t_nv;
  logic [31:0]      row_addr, beat_addr;
  logic [15:0]      len;
  logic [ROWB*8-1:0] row_q;
  logic [4*TN*8-1:0] cin_row;
  logic [15:0]      cin_pend;
  logic             cin_pois;
  logic             hold;
  logic [CW-1:0]    wcnt;

  // ---------------------------------------------------------------- tile extents
  logic [DIM_W:0] m_rem, n_rem, n_next, m_next;
  logic [15:0]    mv, nv;
  assign m_rem  = {1'b0, dim_m} - {1'b0, m0};
  assign n_rem  = {1'b0, dim_n} - {1'b0, n0};
  assign mv     = (m_rem >= (DIM_W+1)'(TM)) ? 16'(TM) : 16'(m_rem);
  assign nv     = (n_rem >= (DIM_W+1)'(TN)) ? 16'(TN) : 16'(n_rem);
  assign n_next = {1'b0, n0} + (DIM_W+1)'(TN);
  assign m_next = {1'b0, m0} + (DIM_W+1)'(TM);

  logic [31:0] last_beat;
  assign last_beat = (row_addr + 32'(len) - 32'd1) & BMASK;
  logic row_end;
  assign row_end = (beat_addr == last_beat);

  // ---------------------------------------------------------------- C_in requests
  assign w_v    = (st == W_CIN) && !stop;
  assign w_addr = beat_addr;
  assign w_d    = 16'(beat_addr - row_addr);
  assign w_len  = len;

  logic cin_rsp;
  assign cin_rsp = (rsp_v || rsp_err_v) && (rsp_dst == sf_mma_pkg::DST_CIN);

  // ---------------------------------------------------------------- output row (stage W_CALC)
  logic [ROWB*8-1:0] row_n;
  logic [15:0]       ovf_n;
  always_comb begin
    row_n = '0;
    ovf_n = '0;
    for (int j = 0; j < TN; j++) begin
      logic [ACC_W-1:0]     v;
      logic [ACC_W-1:0]     cw;
      logic signed [ACC_W:0] ex, ev, ec;
      logic                  ovf;
      logic [ACC_W-1:0]     res;
      v = '0;
      for (int rr = 0; rr < TM; rr++)
        if (32'(r) == rr) v = out_data[(rr*TN + j)*ACC_W +: ACC_W];
      // exact = acc + C_in, both sign-extended to ACC_W+1 bits
      cw = cin_row[j*32 +: ACC_W];                       // C_in: low ACC_W bits of the word
      ev = $signed({v[ACC_W-1], v});
      ec = accum ? $signed({cw[ACC_W-1], cw}) : '0;
      ex = ev + ec;
`ifdef MUT_OVF_NARROW
      ovf = 1'b0;                                                 // MUTANT: no overflow detection
`else
      ovf = (ex[ACC_W] != ex[ACC_W-1]);
`endif
      if (ovf && sat)
`ifdef MUT_SAT_NEG
        res = {1'b0, {(ACC_W-1){1'b1}}};                         // MUTANT: clamps negatives to MAX
`else
        res = ex[ACC_W] ? {1'b1, {(ACC_W-1){1'b0}}} : {1'b0, {(ACC_W-1){1'b1}}};
`endif
      else
        res = ex[ACC_W-1:0];
      row_n[j*32 +: 32] = 32'($signed(res));
      if (ovf && 32'(j) < 32'(t_nv)) ovf_n = ovf_n + 16'd1;
    end
  end

  // ---------------------------------------------------------------- write beats
  logic in_wr, in_cplwr;
  assign in_wr    = (st == W_WR);
  assign in_cplwr = (st == W_CPLWR);

`ifdef MUT_STOP_NOHOLD
  assign wr_req_valid = (in_wr && (wcnt < CW'(WR_OUT)) && !stop) || (in_cplwr && (wcnt < CW'(WR_OUT)));
`else
  assign wr_req_valid = (in_wr && (wcnt < CW'(WR_OUT)) && (!stop || hold)) || (in_cplwr && (wcnt < CW'(WR_OUT)));
`endif
  assign wr_req_addr  = beat_addr;
  assign fire         = wr_req_valid && wr_req_ready;
  assign bp           = wr_req_valid && !wr_req_ready;

  always_comb begin
    logic signed [17:0] d;
    d = 18'($signed(16'(beat_addr - row_addr)));
    wr_req_strb = '0;
    wr_req_data = '0;
    strb_cnt    = '0;
    for (int j = 0; j < BUS_BYTES; j++) begin
      logic signed [17:0] idx;
      idx = d + 18'(j);
`ifdef MUT_STRB_OB1
      if (idx >= 18'sd0 && idx <= 18'($signed({2'b0, len}))) begin   // MUTANT: one byte too many
`else
      if (idx >= 18'sd0 && idx <  18'($signed({2'b0, len}))) begin
`endif
        wr_req_strb[j] = 1'b1;
        wr_req_data[j*8 +: 8] = row_q[32'(idx[$clog2(ROWB)-1:0])*8 +: 8];
        strb_cnt = strb_cnt + 16'd1;
      end
    end
  end

  // ---------------------------------------------------------------- write response tracking
  logic [31:0]   wa_q [WR_OUT];
  logic [PW-1:0] wp, rp;
  logic          wpop;
  assign wpop         = wr_rsp_valid && (wcnt != '0);
  assign spurious     = wr_rsp_valid && (wcnt == '0);
  assign wr_rsp_ready = 1'b1;
  assign err_v        = wpop && wr_rsp_err;
  assign err_addr     = wa_q[rp];
  assign wr_idle      = (wcnt == '0) && !wr_req_valid;

  always_ff @(posedge clk) if (fire) wa_q[wp] <= beat_addr;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0; wcnt <= '0; hold <= 1'b0;
    end else begin
      hold <= wr_req_valid && !wr_req_ready;
      if (fire) wp <= (32'(wp) == WR_OUT - 1) ? '0 : wp + PW'(1);
      if (wpop) rp <= (32'(rp) == WR_OUT - 1) ? '0 : rp + PW'(1);
      wcnt <= wcnt + CW'(fire) - CW'(wpop);
    end
  end

  // ---------------------------------------------------------------- control
  assign all_done = (st == W_FIN);
  assign halted   = (st == W_HALT);
  assign cpl_done = (st == W_END);

  logic last_row;
  assign last_row = (r + 16'd1 == t_mv);
`ifdef MUT_REL_EARLY
  assign wr_rel    = in_wr && fire && row_end && (r == 16'd0);      // MUTANT: releases after the first row
`else
  assign wr_rel    = in_wr && fire && row_end && last_row;
`endif
  assign tile_done = wr_rel;
  assign ovf_inc   = (st == W_CALC && !stop) ? ovf_n : 16'd0;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= W_IDLE;
      m0 <= '0; n0 <= '0; c_m_addr <= '0;
      r <= '0; t_mv <= '0; t_nv <= '0;
      row_addr <= '0; beat_addr <= '0; len <= '0;
      cin_pend <= '0; cin_pois <= 1'b0;
    end else if (job_start) begin
      st <= W_TILE;
      m0 <= '0; n0 <= '0; c_m_addr <= c_base;
      cin_pend <= '0; cin_pois <= 1'b0;
    end else begin
      // C_in beat accounting (requests entering the read port / responses)
      cin_pend <= cin_pend + 16'(w_v && w_rdy) - 16'(cin_rsp);
      if (rsp_err_v && rsp_dst == sf_mma_pkg::DST_CIN) cin_pois <= 1'b1;
      if (rsp_v && rsp_dst == sf_mma_pkg::DST_CIN)
        for (int i = 0; i < 4*TN; i++)
          if (slot_en[i]) cin_row[i*8 +: 8] <= slot_data[i*8 +: 8];

      case (st)
        W_TILE:
          if (stop) st <= W_HALT;
          else if (out_v) begin
            t_mv     <= mv;
            t_nv     <= nv;
            r        <= '0;
            row_addr <= c_m_addr + 32'(n0) * 32'd4;
            st       <= W_ROW;
          end
        W_ROW:
          if (stop) st <= W_HALT;
          else begin
            len       <= 16'(t_nv * 16'd4);
            beat_addr <= row_addr & BMASK;
            st        <= accum ? W_CIN : W_CALC;
          end
        W_CIN:
          if (stop) st <= W_HALT;
          else if (w_rdy) begin
            if (row_end) st <= W_CINW;
            else beat_addr <= beat_addr + 32'(BUS_BYTES);
          end
        W_CINW:
          if (stop || cin_pois) st <= W_HALT;
`ifdef MUT_CIN_NOWAIT
          else st <= W_CALC;                                     // MUTANT: use C_in before it arrived
`else
          else if (cin_pend == 16'd0) st <= W_CALC;
`endif
        W_CALC:
          if (stop) st <= W_HALT;
          else begin
            row_q     <= row_n;
            beat_addr <= row_addr & BMASK;
            st        <= W_WR;
          end
        W_WR:
          if (fire) begin
            if (!row_end) beat_addr <= beat_addr + 32'(BUS_BYTES);
            else if (!last_row) begin
              r        <= r + 16'd1;
`ifdef MUT_LDC
              row_addr <= row_addr + 32'(dim_n) * 32'd4;            // MUTANT: ignores ldc padding
`else
              row_addr <= row_addr + 32'(ldc) * 32'd4;
`endif
              st       <= W_ROW;
            end else begin
              // tile complete: advance the raster
              if (n_next < {1'b0, dim_n}) begin
                n0 <= n_next[DIM_W-1:0];
                st <= W_TILE;
              end else begin
                n0 <= '0;
                if (m_next < {1'b0, dim_m}) begin
                  m0       <= m_next[DIM_W-1:0];
                  c_m_addr <= c_m_addr + 32'(TM) * 32'(ldc) * 32'd4;
                  st       <= W_TILE;
                end else begin
                  st <= W_FIN;
                end
              end
            end
          end else if (stop && !wr_req_valid) begin
            st <= W_HALT;
          end
        W_IDLE, W_FIN, W_HALT, W_END:      // W_IDLE / W_END: job rejected before it ran
          if (cpl_go) st <= W_CPL;
        W_CPL: begin
          row_q     <= '0;
          row_q[127:0] <= cpl_rec;
          row_addr  <= cpl_addr;
          beat_addr <= cpl_addr & BMASK;
          len       <= 16'd16;
          st        <= W_CPLWR;
        end
        W_CPLWR:
          if (fire) begin
            if (!row_end) beat_addr <= beat_addr + 32'(BUS_BYTES);
            else st <= W_END;
          end
        default: ;
      endcase
    end
  end

endmodule

`default_nettype wire
