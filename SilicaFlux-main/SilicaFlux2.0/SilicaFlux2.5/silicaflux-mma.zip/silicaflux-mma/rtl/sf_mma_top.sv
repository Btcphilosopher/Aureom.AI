// =============================================================================
// sf_mma_top.sv -- SilicaFlux matrix multiply-accumulate accelerator (SF-MMA)
//
//   C[M x N] = A[M x K] * B[K x N]          (FLAGS.ACCUM = 0)
//   C[M x N] = C[M x N] + A[M x K] * B[K x N] (FLAGS.ACCUM = 1, in place)
//
//   A, B: signed int8, row-major (B optionally stored transposed, N x K)
//   C   : signed ACC_W-bit result, stored sign-extended in 32-bit words
//
// It sits next to the programmable GPU core as a peer on the memory fabric:
//   * a 32-bit MMIO CSR slave port (programmed by the core's scalar path or a host)
//   * one DMA master with independent read and write channels (valid/ready,
//     BUS_BYTES-wide beats, in-order responses, byte strobes on writes)
//   * a level interrupt and an optional completion record in memory
//
//                 +--------------------------- sf_mma_ctrl (CSR, validation, job FSM, counters)
//                 |            job params / start / stop
//    MMIO ------->|-----+-----------------+---------------------+
//                       v                 v                     v
//               sf_mma_loader -----> sf_mma_rdport <------ sf_mma_writer (C_in)
//                (A/B beats)          |      ^   \                |   ^
//                       |   claim     | rsp  |    rd channel      |   | wr channel
//                       v             v      |                    |   |
//                 sf_mma_opbuf (NB banks, ownership FSM)          |   |
//                       |  FULL banks                             |   |
//                       v                                         |   |
//                 sf_mma_array (TM x TN x TK MACs, acc, out buf) -+---+
//
// Parameters (all checked at elaboration in simulation):
//   TM, TN     output tile = MAC array rows/columns            (>= 1)
//   TK         k-elements consumed per PE per cycle            (>= 1)
//   KT         k-depth of one operand bank (multiple of TK)
//   BUS_BYTES  memory beat width, power of two                 (4 .. 128)
//   IN_BUFS    operand banks: 1 = single buffered, 2 = double  (1 .. 4)
//   OUT_BUFS   1 = accumulators double as output buffer, 2 = separate output buffer
//   ACC_W      accumulator width                               (16 + clog2(TK) .. 32)
//   RD_OUT     outstanding read beats                          (>= 1)
//   WR_OUT     outstanding write beats                         (>= 1)
//   DIM_W      width of M, N, K and leading dimensions         (<= 24)
// =============================================================================
`default_nettype none

module sf_mma_top #(
  parameter int TM        = 8,
  parameter int TN        = 8,
  parameter int TK        = 1,
  parameter int KT        = 32,
  parameter int BUS_BYTES = 16,
  parameter int IN_BUFS   = 2,
  parameter int OUT_BUFS  = 2,
  parameter int ACC_W     = 32,
  parameter int RD_OUT    = 16,
  parameter int WR_OUT    = 8,
  parameter int DIM_W     = 20
)(
  input  logic                   clk,
  input  logic                   rst_n,          // synchronous, active low
  // MMIO CSR slave
  input  logic                   csr_valid,
  output logic                   csr_ready,      // constant 1
  input  logic                   csr_write,
  input  logic [7:0]             csr_addr,
  input  logic [31:0]            csr_wdata,
  output logic                   csr_rvalid,     // read data one cycle after the request
  output logic [31:0]            csr_rdata,
  output logic                   irq,            // level: DONE && FLAGS.IRQ_EN, cleared by CTRL.CLEAR
  output logic                   busy,
  // DMA read channel
  output logic                   rd_req_valid,
  input  logic                   rd_req_ready,
  output logic [31:0]            rd_req_addr,
  input  logic                   rd_rsp_valid,
  output logic                   rd_rsp_ready,   // constant 1
  input  logic [BUS_BYTES*8-1:0] rd_rsp_data,
  input  logic                   rd_rsp_err,
  // DMA write channel
  output logic                   wr_req_valid,
  input  logic                   wr_req_ready,
  output logic [31:0]            wr_req_addr,
  output logic [BUS_BYTES*8-1:0] wr_req_data,
  output logic [BUS_BYTES-1:0]   wr_req_strb,
  input  logic                   wr_rsp_valid,
  output logic                   wr_rsp_ready,   // constant 1
  input  logic                   wr_rsp_err,
  // simulation-only checker summary (0 in a correct design)
  output logic                   chk_fail
);

  localparam int NB    = IN_BUFS;
  localparam int SLOTS = (KT > 4*TN) ? KT : 4*TN;

`ifndef SYNTHESIS
  initial begin
    if (TM < 1 || TN < 1 || TK < 1 || KT < TK || (KT % TK) != 0)
      $fatal(1, "sf_mma_top: need TM,TN,TK >= 1 and KT a positive multiple of TK");
    if (BUS_BYTES < 4 || BUS_BYTES > 128 || (BUS_BYTES & (BUS_BYTES - 1)) != 0)
      $fatal(1, "sf_mma_top: BUS_BYTES must be a power of two in 4..128");
    if (IN_BUFS < 1 || IN_BUFS > 4 || OUT_BUFS < 1 || OUT_BUFS > 2)
      $fatal(1, "sf_mma_top: IN_BUFS in 1..4, OUT_BUFS in 1..2");
    if (ACC_W > 32 || ACC_W < 16 + ((TK > 1) ? $clog2(TK) : 0))
      $fatal(1, "sf_mma_top: ACC_W must be in 16+clog2(TK) .. 32");
    if (RD_OUT < 1 || WR_OUT < 1 || DIM_W < 4 || DIM_W > 24)
      $fatal(1, "sf_mma_top: RD_OUT, WR_OUT >= 1 and DIM_W in 4..24");
  end
`endif

  // ---------------------------------------------------------------- wires
  logic [31:0]      j_a, j_b, j_c, j_cpl;
  logic [DIM_W-1:0] j_m, j_n, j_k, j_lda, j_ldb, j_ldc;
  logic             j_accum, j_sat, j_transb, job_start, stop, run;

  // loader
  logic             claim_v, claim_first, claim_last, issued_v, ld_req_v, ld_req_rdy, ld_done, ld_wait;
  logic [1:0]       claim_bank, issued_bank, ld_req_dst, ld_req_bank;
  logic [15:0]      claim_mv, claim_nv, claim_kv, ld_req_row, ld_req_d, ld_req_len;
  logic [31:0]      ld_req_addr;
  // read port
  logic             w_v, w_rdy, rsp_v, rsp_err_v, rd_idle, rd_fire, rd_bp, rd_cred, rd_spur;
  logic [31:0]      w_addr, rsp_addr;
  logic [15:0]      w_d, w_len, rsp_row, slot_cnt;
  logic [1:0]       rsp_dst, rsp_bank;
  logic [SLOTS-1:0]   slot_en;
  logic [SLOTS*8-1:0] slot_data;
  // operand buffers
  logic [NB-1:0]          bank_free, bank_ready, d_first, d_last;
  logic [NB*16-1:0]       d_mv, d_nv, d_kv;
  logic [NB*TM*KT*8-1:0]  abuf;
  logic [NB*TN*KT*8-1:0]  bbuf;
  logic                   ob_chk;
  // array
  logic                   cp_start_v, cp_rel_v, out_v, wr_rel, issue, st_load, st_store, pipe_busy, ar_chk;
  logic [1:0]             cp_start_bank, cp_rel_bank;
  logic [TM*TN*ACC_W-1:0] out_data;
  logic [31:0]            macs_inc;
  // writer
  logic                   wr_all_done, wr_halted, cpl_done, wr_idle, wr_err_v, tile_done, wr_fire, wr_bp, wr_spur, cpl_go;
  logic [31:0]            wr_err_addr;
  logic [15:0]            ovf_inc, strb_cnt;
  logic [127:0]           cpl_rec;

  logic more_work;
  assign more_work = !ld_done || (bank_free != {NB{1'b1}});
  assign chk_fail  = ob_chk || ar_chk;

  // ---------------------------------------------------------------- blocks
  sf_mma_ctrl #(
    .TM(TM), .TN(TN), .TK(TK), .KT(KT), .BUS_BYTES(BUS_BYTES), .IN_BUFS(IN_BUFS), .OUT_BUFS(OUT_BUFS),
    .ACC_W(ACC_W), .RD_OUT(RD_OUT), .WR_OUT(WR_OUT), .DIM_W(DIM_W)
  ) u_ctrl (
    .clk, .rst_n,
    .csr_valid, .csr_ready, .csr_write, .csr_addr, .csr_wdata, .csr_rvalid, .csr_rdata, .irq, .busy,
    .j_a, .j_b, .j_c, .j_cpl, .j_m, .j_n, .j_k, .j_lda, .j_ldb, .j_ldc, .j_accum, .j_sat, .j_transb,
    .job_start, .stop, .run,
    .ld_done, .rd_idle, .pipe_busy, .wr_all_done, .wr_halted, .wr_idle, .cpl_done,
    .rd_err_v(rsp_err_v), .rd_err_addr(rsp_addr), .wr_err_v, .wr_err_addr,
    .cpl_go, .cpl_rec,
    .ev_issue(issue), .ev_macs(macs_inc), .ev_rd_fire(rd_fire), .ev_wr_fire(wr_fire),
    .ev_rd_bytes(rsp_v ? slot_cnt : 16'd0), .ev_wr_bytes(wr_fire ? strb_cnt : 16'd0),
    .ev_st_load(st_load), .ev_st_store(st_store), .ev_rd_bp(rd_bp), .ev_wr_bp(wr_bp),
    .ev_ld_wait(ld_wait), .ev_rd_cred(rd_cred), .ev_tile(tile_done), .ev_ktile(issued_v),
    .ev_ovf(ovf_inc), .ev_spurious(rd_spur || wr_spur)
  );

  sf_mma_loader #(
    .TM(TM), .TN(TN), .KT(KT), .BUS_BYTES(BUS_BYTES), .NB(NB), .DIM_W(DIM_W)
  ) u_loader (
    .clk, .rst_n, .job_start, .stop,
    .a_base(j_a), .b_base(j_b), .dim_m(j_m), .dim_n(j_n), .dim_k(j_k), .lda(j_lda), .ldb(j_ldb), .trans_b(j_transb),
    .bank_free,
    .claim_v, .claim_bank, .claim_mv, .claim_nv, .claim_kv, .claim_first, .claim_last,
    .issued_v, .issued_bank,
    .req_v(ld_req_v), .req_rdy(ld_req_rdy), .req_addr(ld_req_addr), .req_dst(ld_req_dst), .req_bank(ld_req_bank),
    .req_row(ld_req_row), .req_d(ld_req_d), .req_len(ld_req_len),
    .done(ld_done), .wait_buf(ld_wait)
  );

  sf_mma_rdport #(
    .BUS_BYTES(BUS_BYTES), .RD_OUT(RD_OUT), .SLOTS(SLOTS)
  ) u_rdport (
    .clk, .rst_n, .stop,
    .l_v(ld_req_v), .l_rdy(ld_req_rdy), .l_addr(ld_req_addr), .l_dst(ld_req_dst), .l_bank(ld_req_bank),
    .l_row(ld_req_row), .l_d(ld_req_d), .l_len(ld_req_len),
    .w_v, .w_rdy, .w_addr, .w_d, .w_len,
    .rd_req_valid, .rd_req_ready, .rd_req_addr, .rd_rsp_valid, .rd_rsp_ready, .rd_rsp_data, .rd_rsp_err,
    .rsp_v, .rsp_err_v, .rsp_addr, .rsp_dst, .rsp_bank, .rsp_row, .slot_en, .slot_data, .slot_cnt,
    .idle(rd_idle), .fire(rd_fire), .bp(rd_bp), .cred_stall(rd_cred), .spurious(rd_spur)
  );

  sf_mma_opbuf #(
    .TM(TM), .TN(TN), .KT(KT), .NB(NB), .SLOTS(SLOTS)
  ) u_opbuf (
    .clk, .rst_n, .job_start, .trans_b(j_transb),
    .claim_v, .claim_bank, .claim_mv, .claim_nv, .claim_kv, .claim_first, .claim_last,
    .issued_v, .issued_bank,
    .acc_v(ld_req_v && ld_req_rdy), .acc_bank(ld_req_bank),
    .rsp_v, .rsp_err_v, .rsp_dst, .rsp_bank, .rsp_row, .slot_en, .slot_data,
    .cp_start_v, .cp_start_bank, .cp_rel_v, .cp_rel_bank,
    .bank_free, .bank_ready, .d_mv, .d_nv, .d_kv, .d_first, .d_last, .abuf, .bbuf,
    .chk_fail(ob_chk)
  );

  sf_mma_array #(
    .TM(TM), .TN(TN), .TK(TK), .KT(KT), .NB(NB), .OUT_BUFS(OUT_BUFS), .ACC_W(ACC_W)
  ) u_array (
    .clk, .rst_n, .job_start, .stop, .run, .more_work,
    .bank_ready, .d_mv, .d_nv, .d_kv, .d_first, .d_last, .abuf, .bbuf,
    .cp_start_v, .cp_start_bank, .cp_rel_v, .cp_rel_bank,
    .out_v, .out_data, .wr_rel,
    .issue, .macs_inc, .st_load, .st_store, .pipe_busy, .chk_fail(ar_chk)
  );

  sf_mma_writer #(
    .TM(TM), .TN(TN), .BUS_BYTES(BUS_BYTES), .WR_OUT(WR_OUT), .ACC_W(ACC_W), .DIM_W(DIM_W), .SLOTS(SLOTS)
  ) u_writer (
    .clk, .rst_n, .job_start, .stop,
    .c_base(j_c), .cpl_addr(j_cpl), .dim_m(j_m), .dim_n(j_n), .ldc(j_ldc), .accum(j_accum), .sat(j_sat),
    .out_v, .out_data, .wr_rel,
    .w_v, .w_rdy, .w_addr, .w_d, .w_len,
    .rsp_v, .rsp_err_v, .rsp_dst, .slot_en, .slot_data,
    .wr_req_valid, .wr_req_ready, .wr_req_addr, .wr_req_data, .wr_req_strb, .wr_rsp_valid, .wr_rsp_ready, .wr_rsp_err,
    .cpl_go, .cpl_rec,
    .all_done(wr_all_done), .halted(wr_halted), .cpl_done, .wr_idle, .err_v(wr_err_v), .err_addr(wr_err_addr),
    .ovf_inc, .tile_done, .fire(wr_fire), .bp(wr_bp), .strb_cnt, .spurious(wr_spur)
  );

endmodule

`default_nettype wire
