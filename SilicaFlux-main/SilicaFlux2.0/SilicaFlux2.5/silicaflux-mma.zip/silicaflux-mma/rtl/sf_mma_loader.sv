// =============================================================================
// sf_mma_loader.sv -- operand tile loader (address generator of the read DMA)
//
// Walks the job in the fixed schedule order shared with the compute engine and
// the writer:
//     for m0 in 0, TM, 2TM ..      (output-tile rows)
//       for n0 in 0, TN, 2TN ..    (output-tile columns)
//         for k0 in 0, KT, 2KT ..  (reduction slabs, "k-tiles")
//           load A[m0:m0+TM, k0:k0+KT] and B[k0:k0+KT, n0:n0+TN] into ONE bank
//
// Ownership rule (the only thing that makes overlap safe): the loader claims a
// bank only while that bank is FREE, and from then on it is the sole writer of
// the bank until the read port has delivered every beat (bank -> FULL).  Banks
// are claimed in strict round-robin order 0,1,..,NB-1,0,.. and the compute
// engine consumes them in the same order, so no bank id has to travel with the
// data.  With NB = 1 loading and computing therefore alternate; with NB >= 2
// the next k-tile is fetched while the current one is being multiplied.
//
// Rows are fetched byte-exactly: a row of `len` valid bytes starting at an
// arbitrary byte address becomes ceil((addr%BUS + len)/BUS) aligned beats.  Each
// beat carries (dst, bank, row, d = beat_addr - row_addr, len) so the read port
// can drop the bytes that belong to neighbouring data.  Partial tiles (M, N, K
// not multiples of TM, TN, KT) simply fetch shorter rows / fewer rows; the
// out-of-range part of a bank keeps stale data that the compute engine masks.
// =============================================================================
`default_nettype none

module sf_mma_loader #(
  parameter int TM        = 8,
  parameter int TN        = 8,
  parameter int KT        = 32,
  parameter int BUS_BYTES = 16,
  parameter int NB        = 2,     // operand banks (1 = single buffered, 2 = double buffered, <= 4)
  parameter int DIM_W     = 20
)(
  input  logic             clk,
  input  logic             rst_n,
  input  logic             job_start,     // pulse: (re)initialise for a new job
  input  logic             stop,          // abort / error: issue nothing more
  input  logic [31:0]      a_base,
  input  logic [31:0]      b_base,
  input  logic [DIM_W-1:0] dim_m,
  input  logic [DIM_W-1:0] dim_n,
  input  logic [DIM_W-1:0] dim_k,
  input  logic [DIM_W-1:0] lda,
  input  logic [DIM_W-1:0] ldb,
  input  logic             trans_b,
  // operand-bank ownership
  input  logic [NB-1:0]    bank_free,
  output logic             claim_v,
  output logic [1:0]       claim_bank,
  output logic [15:0]      claim_mv,
  output logic [15:0]      claim_nv,
  output logic [15:0]      claim_kv,
  output logic             claim_first,   // k0 == 0       : first k-tile of an output tile
  output logic             claim_last,    // k0 + KT >= K  : last k-tile of an output tile
  output logic             issued_v,      // every beat of `issued_bank` is in the read port
  output logic [1:0]       issued_bank,
  // read requests (sf_mma_rdport registers them; the request may be withdrawn)
  output logic             req_v,
  input  logic             req_rdy,
  output logic [31:0]      req_addr,      // BUS_BYTES-aligned beat address
  output logic [1:0]       req_dst,
  output logic [1:0]       req_bank,
  output logic [15:0]      req_row,
  output logic [15:0]      req_d,         // beat_addr - row_addr (two's complement)
  output logic [15:0]      req_len,       // valid bytes in this row
  // status
  output logic             done,          // every k-tile issued, or stopped
  output logic             wait_buf       // ready to claim, but the next bank is not free
);

  localparam logic [31:0] BMASK = ~(32'(BUS_BYTES) - 32'd1);

  localparam logic [1:0] L_IDLE  = 2'd0;
  localparam logic [1:0] L_CLAIM = 2'd1;
  localparam logic [1:0] L_ROWS  = 2'd2;
  localparam logic [1:0] L_DONE  = 2'd3;

  logic [1:0]       st;
  logic [DIM_W-1:0] m0, n0, k0;
  logic [31:0]      a_m_addr;   // a_base + m0*lda
  logic [31:0]      b_n_off;    // row-major B: n0        transposed B: n0*ldb
  logic [31:0]      b_k_off;    // row-major B: k0*ldb    transposed B: k0
  logic [1:0]       bank;
  logic             phase_b;    // 0: A rows, 1: B rows
  logic [15:0]      row, nrows, rlen;
  logic [31:0]      row_addr, beat_addr, stride;
  logic [15:0]      t_nv, t_kv;

  // ---------------------------------------------------------------- tile extents
  logic [DIM_W:0] m_rem, n_rem, k_rem;
  logic [15:0]    mv, nv, kv;
  assign m_rem = {1'b0, dim_m} - {1'b0, m0};
  assign n_rem = {1'b0, dim_n} - {1'b0, n0};
  assign k_rem = {1'b0, dim_k} - {1'b0, k0};
  assign mv = (m_rem >= (DIM_W+1)'(TM)) ? 16'(TM) : 16'(m_rem);
  assign nv = (n_rem >= (DIM_W+1)'(TN)) ? 16'(TN) : 16'(n_rem);
  assign kv = (k_rem >= (DIM_W+1)'(KT)) ? 16'(KT) : 16'(k_rem);

  logic [DIM_W:0] k_next, n_next, m_next;
  assign k_next = {1'b0, k0} + (DIM_W+1)'(KT);
  assign n_next = {1'b0, n0} + (DIM_W+1)'(TN);
  assign m_next = {1'b0, m0} + (DIM_W+1)'(TM);

  // first row of the B part of the current k-tile
  logic [31:0] b_row0;
  assign b_row0 = b_base + b_n_off + b_k_off;
  logic [31:0] a_row0;
  assign a_row0 = a_m_addr + 32'(k0);

  // ---------------------------------------------------------------- beat generation
  logic [31:0] last_beat;
  assign last_beat = (row_addr + 32'(rlen) - 32'd1) & BMASK;

  logic bank_ok;
`ifdef MUT_CLAIM_ANY
  assign bank_ok = 1'b1;                       // MUTANT: ignore ownership
`else
  assign bank_ok = bank_free[bank[$clog2(NB > 1 ? NB : 2)-1:0]];
`endif

  assign claim_v     = (st == L_CLAIM) && !stop && bank_ok;
  assign claim_bank  = bank;
  assign claim_mv    = mv;
  assign claim_nv    = nv;
  assign claim_kv    = kv;
  assign claim_first = (k0 == '0);
  assign claim_last  = (k_next >= {1'b0, dim_k});

  assign req_v    = (st == L_ROWS) && !stop;
  assign req_addr = beat_addr;
  assign req_dst  = phase_b ? sf_mma_pkg::DST_B : sf_mma_pkg::DST_A;
  assign req_bank = bank;
  assign req_row  = row;
  assign req_d    = 16'(beat_addr - row_addr);
  assign req_len  = rlen;

  logic fire, row_end, bank_end;
  assign fire     = req_v && req_rdy;
  assign row_end  = (beat_addr == last_beat);
  assign bank_end = fire && row_end && (row + 16'd1 == nrows) && phase_b;

  assign issued_v    = bank_end;
  assign issued_bank = bank;
  assign done        = (st == L_DONE);
  assign wait_buf    = (st == L_CLAIM) && !stop && !bank_ok;

  logic [1:0] bank_inc;
  assign bank_inc = (32'(bank) == NB - 1) ? 2'd0 : bank + 2'd1;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st <= L_IDLE;
      m0 <= '0; n0 <= '0; k0 <= '0;
      a_m_addr <= '0; b_n_off <= '0; b_k_off <= '0;
      bank <= '0; phase_b <= 1'b0;
      row <= '0; nrows <= '0; rlen <= '0;
      row_addr <= '0; beat_addr <= '0; stride <= '0;
      t_nv <= '0; t_kv <= '0;
    end else if (job_start) begin
      st <= L_CLAIM;
      m0 <= '0; n0 <= '0; k0 <= '0;
      a_m_addr <= a_base; b_n_off <= '0; b_k_off <= '0;
      bank <= '0; phase_b <= 1'b0;
    end else if (stop && st != L_IDLE) begin
      st <= L_DONE;
    end else begin
      case (st)
        L_CLAIM: if (claim_v) begin
          // the bank is ours: start with the A rows of this k-tile
          t_nv <= nv; t_kv <= kv;
          phase_b   <= 1'b0;
          row       <= '0;
          nrows     <= mv;
          rlen      <= kv;
          row_addr  <= a_row0;
          beat_addr <= a_row0 & BMASK;
          stride    <= 32'(lda);
          st        <= L_ROWS;
        end
        L_ROWS: if (fire) begin
          if (!row_end) begin
            beat_addr <= beat_addr + 32'(BUS_BYTES);
          end else if (row + 16'd1 != nrows) begin
            row       <= row + 16'd1;
            row_addr  <= row_addr + stride;
            beat_addr <= (row_addr + stride) & BMASK;
          end else if (!phase_b) begin
            // A part complete -> B part.  Row-major B: KT rows of n_valid bytes.
            // Transposed B: TN rows of k_valid bytes (both contiguous along a row).
            phase_b   <= 1'b1;
            row       <= '0;
            nrows     <= trans_b ? t_nv : t_kv;
            rlen      <= trans_b ? t_kv : t_nv;
            row_addr  <= b_row0;
            beat_addr <= b_row0 & BMASK;
`ifdef MUT_B_STRIDE
            stride    <= 32'(lda);                                  // MUTANT: B rows with A's stride
`else
            stride    <= 32'(ldb);
`endif
          end else begin
            // bank complete: advance the schedule (k innermost)
            bank <= bank_inc;
            if (k_next < {1'b0, dim_k}) begin
              k0      <= k_next[DIM_W-1:0];
              b_k_off <= b_k_off + (trans_b ? 32'(KT) : 32'(KT) * 32'(ldb));
              st      <= L_CLAIM;
            end else begin
              k0      <= '0;
              b_k_off <= '0;
              if (n_next < {1'b0, dim_n}) begin
                n0      <= n_next[DIM_W-1:0];
                b_n_off <= b_n_off + (trans_b ? 32'(TN) * 32'(ldb) : 32'(TN));
                st      <= L_CLAIM;
              end else begin
                n0      <= '0;
                b_n_off <= '0;
                if (m_next < {1'b0, dim_m}) begin
                  m0       <= m_next[DIM_W-1:0];
                  a_m_addr <= a_m_addr + 32'(TM) * 32'(lda);
                  st       <= L_CLAIM;
                end else begin
                  st <= L_DONE;
                end
              end
            end
          end
        end
        default: ;
      endcase
    end
  end

endmodule

`default_nettype wire
