// =============================================================================
// sf_mma_array.sv -- compute scheduler, TM x TN MAC array, accumulators, output
// buffer
//
// One "step" multiplies a TM x TK slice of A by a TK x TN slice of B and adds the
// TM x TN result into the accumulators: TM*TN*TK signed 8x8 multiplies per step,
// one step per cycle.  A bank holding a k-tile of k_valid columns takes
// ceil(k_valid / TK) steps.
//
//   stage I (issue): pick the next bank in round-robin order if it is FULL/BUSY,
//                    read the operand slices, zero every k >= k_valid (tail mask)
//   stage M        : products (16-bit exact) and a TK-input adder tree (PW bits)
//   stage A        : acc <= (first k-tile step ? 0 : acc) + psum;  on the last
//                    step of an output tile the final value goes to the writer
//
// Accumulator width ACC_W is exact for every legal job: |product| <= 2^14 and the
// controller rejects K > K_MAX = 2^(ACC_W-15) - 1, so |acc| <= K_MAX * 2^14
// < 2^(ACC_W-1).  (Checked every cycle in simulation.)  C_in is added later, by
// the writer, in ACC_W+1 bits.
//
// Output ownership -- reserved at ISSUE time, so the pipeline never stalls:
//   OUT_BUFS = 2: a separate output buffer.  The last step of tile t may issue
//                 only if the output buffer is neither full nor reserved; the
//                 first step of tile t+1 may issue the very next cycle.
//   OUT_BUFS = 1: the accumulators ARE the output buffer.  After the last step of
//                 tile t issues, the first step of tile t+1 waits until the
//                 writer has released the accumulators.
// Rows m >= m_valid and columns n >= n_valid of a partial tile hold garbage that
// is never written out; only the k dimension needs masking.
// =============================================================================
`default_nettype none

module sf_mma_array #(
  parameter int TM       = 8,
  parameter int TN       = 8,
  parameter int TK       = 1,
  parameter int KT       = 32,
  parameter int NB       = 2,
  parameter int OUT_BUFS = 2,
  parameter int ACC_W    = 32
)(
  input  logic                  clk,
  input  logic                  rst_n,
  input  logic                  job_start,
  input  logic                  stop,
  input  logic                  run,           // job in RUN/DRAIN: stale banks of a previous job are never issued
  input  logic                  more_work,     // loads still to come or a bank not yet free
  // operand banks
  input  logic [NB-1:0]         bank_ready,
  input  logic [NB*16-1:0]      d_mv,
  input  logic [NB*16-1:0]      d_nv,
  input  logic [NB*16-1:0]      d_kv,
  input  logic [NB-1:0]         d_first,
  input  logic [NB-1:0]         d_last,
  input  logic [NB*TM*KT*8-1:0] abuf,
  input  logic [NB*TN*KT*8-1:0] bbuf,
  output logic                  cp_start_v,
  output logic [1:0]            cp_start_bank,
  output logic                  cp_rel_v,
  output logic [1:0]            cp_rel_bank,
  // writer hand-off
  output logic                  out_v,
  output logic [TM*TN*ACC_W-1:0] out_data,
  input  logic                  wr_rel,
  // status / performance
  output logic                  issue,
  output logic [31:0]           macs_inc,
  output logic                  st_load,
  output logic                  st_store,
  output logic                  pipe_busy,
  output logic                  chk_fail
);

  localparam int KS = KT / TK;                                  // steps of a full bank
  localparam int PW = 16 + ((TK > 1) ? $clog2(TK) : 0);         // exact width of a TK-term dot product

  // ---------------------------------------------------------------- issue stage
  logic [1:0]  cb;          // bank being computed
  logic [15:0] cs;          // step within the bank
  /* verilator lint_off UNUSEDSIGNAL */
  logic        ob_full, ob_resv;     // OUT_BUFS = 2 (ob_resv unused when OUT_BUFS = 1)
  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_off UNUSEDSIGNAL */
  logic        acc_lock, acc_own;    // OUT_BUFS = 1 (acc_lock unused when OUT_BUFS = 2)
  /* verilator lint_on UNUSEDSIGNAL */

  logic [15:0] cur_mv, cur_nv, cur_kv;
  logic        cur_first, cur_last, cur_ready;
  always_comb begin
    cur_mv = '0; cur_nv = '0; cur_kv = '0; cur_first = 1'b0; cur_last = 1'b0; cur_ready = 1'b0;
    for (int b = 0; b < NB; b++)
      if (32'(cb) == b) begin
        cur_mv    = d_mv[b*16 +: 16];
        cur_nv    = d_nv[b*16 +: 16];
        cur_kv    = d_kv[b*16 +: 16];
        cur_first = d_first[b];
        cur_last  = d_last[b];
        cur_ready = bank_ready[b];
      end
  end

  logic [15:0] step_k0;
  logic        last_step, t_first, t_last, out_ok;
  assign step_k0   = 16'(32'(cs) * TK);
  assign last_step = (32'(step_k0) + TK >= 32'(cur_kv));
`ifdef MUT_NO_FIRST_CLR
  assign t_first   = 1'b0;                                      // MUTANT: never clear the accumulators
`else
  assign t_first   = cur_first && (cs == 16'd0);
`endif
  assign t_last    = cur_last && last_step;

  generate
    if (OUT_BUFS >= 2) begin : g_ok2
`ifdef MUT_OB2_NORESV
      assign out_ok = 1'b1;                                     // MUTANT: overwrite a full output buffer
`else
      assign out_ok = !t_last || (!ob_full && !ob_resv);
`endif
    end else begin : g_ok1
`ifdef MUT_OB1_NOLOCK
      assign out_ok = 1'b1;                                     // MUTANT: reuse accumulators too early
`else
      assign out_ok = !t_first || !acc_lock;
`endif
    end
  endgenerate

  assign issue    = run && cur_ready && out_ok && !stop;
  assign st_load  = run && more_work && !stop && !cur_ready;
  assign st_store = run && !stop && cur_ready && !out_ok;

  assign cp_start_v    = issue && (cs == 16'd0);
  assign cp_start_bank = cb;
  assign cp_rel_v      = issue && last_step;
  assign cp_rel_bank   = cb;

  logic [15:0] kcnt;
  assign kcnt     = (32'(cur_kv) - 32'(step_k0) >= TK) ? 16'(TK) : (cur_kv - step_k0);
  assign macs_inc = issue ? (32'(cur_mv) * 32'(cur_nv) * 32'(kcnt)) : 32'd0;

  // operand slices of the selected bank and step, tail-masked
  logic [TM*TK*8-1:0] opa_n;
  logic [TK*TN*8-1:0] opb_n;
  always_comb begin
    opa_n = '0;
    opb_n = '0;
    for (int b = 0; b < NB; b++)
      for (int s = 0; s < KS; s++)
        if (32'(cb) == b && 32'(cs) == s) begin
          for (int i = 0; i < TM; i++)
            for (int t = 0; t < TK; t++)
              opa_n[(i*TK + t)*8 +: 8] = abuf[((b*TM + i)*KT + s*TK + t)*8 +: 8];
          for (int t = 0; t < TK; t++)
            for (int j = 0; j < TN; j++)
              opb_n[(t*TN + j)*8 +: 8] = bbuf[((b*TN + j)*KT + s*TK + t)*8 +: 8];
        end
`ifndef MUT_NO_KMASK
    for (int t = 0; t < TK; t++)
      if (32'(step_k0) + t >= 32'(cur_kv)) begin
        for (int i = 0; i < TM; i++) opa_n[(i*TK + t)*8 +: 8] = 8'd0;
        for (int j = 0; j < TN; j++) opb_n[(t*TN + j)*8 +: 8] = 8'd0;
      end
`endif
  end

  // ---------------------------------------------------------------- pipeline registers
  logic               v1, f1, l1, v2, f2, l2;
  logic [TM*TK*8-1:0] opa1;
  logic [TK*TN*8-1:0] opb1;
  logic [TM*TN*PW-1:0] psum2;
  logic [TM*TN*ACC_W-1:0] acc, ob;

  // stage M: exact products and the TK-term reduction
  logic [TM*TN*PW-1:0] psum_n;
  always_comb begin
    for (int i = 0; i < TM; i++)
      for (int j = 0; j < TN; j++) begin
        logic signed [PW-1:0] ps;
        logic signed [15:0]   p;
        ps = '0;
        for (int t = 0; t < TK; t++) begin
`ifdef MUT_UNSIGNED
          p  = $signed({8'd0, opa1[(i*TK + t)*8 +: 8]}) * $signed({8'd0, opb1[(t*TN + j)*8 +: 8]});  // MUTANT
`else
          p  = $signed(opa1[(i*TK + t)*8 +: 8]) * $signed(opb1[(t*TN + j)*8 +: 8]);
`endif
          ps = ps + PW'(p);
        end
        psum_n[(i*TN + j)*PW +: PW] = ps;
      end
  end

  // stage A: accumulate
  logic [TM*TN*ACC_W-1:0] sum_n;
  logic                   acc_ovf;   // simulation check: must never be set
  always_comb begin
    acc_ovf = 1'b0;
    for (int e = 0; e < TM*TN; e++) begin
      logic signed [ACC_W:0] s, sa, sp;
      logic [ACC_W-1:0]      a_old;
      logic [PW-1:0]         p_new;
      a_old = f2 ? '0 : acc[e*ACC_W +: ACC_W];
      p_new = psum2[e*PW +: PW];
      sa = $signed({a_old[ACC_W-1], a_old});
      sp = $signed({{(ACC_W+1-PW){p_new[PW-1]}}, p_new});
      s  = sa + sp;
      // the sum above is evaluated in ACC_W+1 bits: an ACC_W overflow shows up as
      // a difference between bit ACC_W and bit ACC_W-1
      if (s[ACC_W] != s[ACC_W-1]) acc_ovf = 1'b1;
      sum_n[e*ACC_W +: ACC_W] = s[ACC_W-1:0];
    end
  end

  logic [1:0] cb_inc;
`ifdef MUT_BANK_STUCK
  assign cb_inc = cb;                                               // MUTANT: compute never moves to the next bank
`else
  assign cb_inc = (32'(cb) == NB - 1) ? 2'd0 : cb + 2'd1;
`endif

  always_ff @(posedge clk) begin
    if (!rst_n || job_start) begin
      cb <= '0; cs <= '0;
      v1 <= 1'b0; v2 <= 1'b0; f1 <= 1'b0; l1 <= 1'b0; f2 <= 1'b0; l2 <= 1'b0;
      ob_full <= 1'b0; ob_resv <= 1'b0; acc_lock <= 1'b0; acc_own <= 1'b0;
    end else begin
      // issue
      v1 <= issue;
      f1 <= t_first;
      l1 <= t_last;
      if (issue) begin
        opa1 <= opa_n;
        opb1 <= opb_n;
        if (last_step) begin
          cs <= '0;
          cb <= cb_inc;
        end else begin
          cs <= cs + 16'd1;
        end
      end
      // multiply
      v2 <= v1; f2 <= f1; l2 <= l1;
      if (v1) psum2 <= psum_n;
      // accumulate + hand-off
      if (v2) begin
        acc <= sum_n;
        if (l2 && OUT_BUFS >= 2) ob <= sum_n;
      end
      if (OUT_BUFS >= 2) begin
        if (issue && t_last) ob_resv <= 1'b1;
        if (v2 && l2) begin ob_full <= 1'b1; ob_resv <= 1'b0; end
        if (wr_rel)  ob_full <= 1'b0;
      end else begin
        if (issue && t_last) acc_lock <= 1'b1;
        if (v2 && l2) acc_own <= 1'b1;
        if (wr_rel) begin acc_own <= 1'b0; acc_lock <= 1'b0; end
      end
    end
  end

  assign out_v     = (OUT_BUFS >= 2) ? ob_full : acc_own;
  assign out_data  = (OUT_BUFS >= 2) ? ob : acc;
  assign pipe_busy = v1 || v2;

  // ---------------------------------------------------------------- checks
  logic viol;
  always_comb begin
    viol = 1'b0;
    if (v2 && acc_ovf) viol = 1'b1;                               // accumulator bound broken
    if (wr_rel && !out_v) viol = 1'b1;                            // release of a buffer not owned
    if (OUT_BUFS >= 2 && v2 && l2 && ob_full && !wr_rel) viol = 1'b1;   // overwrite of a full output buffer
    if (OUT_BUFS <  2 && v2 && acc_own) viol = 1'b1;              // accumulators touched while the writer owns them
  end

  always_ff @(posedge clk) begin
    if (!rst_n) chk_fail <= 1'b0;
`ifndef SF_MMA_NO_CHECKS
    else if (viol && !job_start) begin
      chk_fail <= 1'b1;
`ifndef SYNTHESIS
      $error("sf_mma_array: check failed (acc_ovf=%0d wr_rel=%0d out_v=%0d ob_full=%0d acc_own=%0d)",
             acc_ovf && v2, wr_rel, out_v, ob_full, acc_own);
`endif
    end
`endif
  end

endmodule

`default_nettype wire
