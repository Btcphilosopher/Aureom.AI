#!/usr/bin/env python3
"""Self-tests of the Python reference and traffic model (run: python3 model/test_model.py, or pytest)."""
from __future__ import annotations

import itertools
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mma_ref import (reference, reference_scalar, k_max, k_limit, acc_range, sext, PROD_MIN, PROD_MAX)  # noqa: E402
from traffic import (Cfg, Desc, validate, nbeats, job_counters, compulsory_bytes, ERR_NONE, ERR_DIM, ERR_KMAX,  # noqa: E402
                     ERR_LD, ERR_ALIGN, ERR_RANGE, ERR_ALIAS, F_TRANS_B, F_CPL_EN, F_ACCUM)


def test_product_range():
    vals = range(-128, 128)
    prods = [a * b for a in vals for b in vals]
    assert min(prods) == PROD_MIN == -16256
    assert max(prods) == PROD_MAX == 16384


def test_k_max_is_tight():
    for w in range(16, 33):
        km = k_max(w)
        lo, hi = acc_range(w)
        # K_MAX products never overflow, whatever the operands
        assert km * PROD_MAX <= hi and km * PROD_MIN >= lo
        # one more (-128)*(-128) product overflows by exactly one
        assert (km + 1) * PROD_MAX == hi + 1
    assert k_max(32) == 131071 and k_max(20) == 31 and k_max(16) == 1
    assert k_limit(32, 20) == 131071 and k_limit(32, 16) == 65535


def test_numpy_matches_scalar():
    rng = np.random.default_rng(1)
    for _ in range(300):
        w = int(rng.integers(16, 33))
        M, N = int(rng.integers(1, 6)), int(rng.integers(1, 6))
        K = int(rng.integers(1, min(k_max(w), 40) + 1))
        A = rng.choice(np.array([-128, -127, -1, 0, 1, 127]), (M, K)) if rng.random() < .5 else rng.integers(-128, 128, (M, K))
        B = rng.integers(-128, 128, (K, N))
        lo, hi = acc_range(w)
        C = (rng.choice(np.array([lo, hi, 0, -1, lo + 7, hi - 7]), (M, N)) & 0xFFFFFFFF).astype(np.uint32)
        acc, sat = bool(rng.random() < .6), bool(rng.random() < .5)
        o1, v1, _ = reference(A, B, C, accumulate=acc, saturate=sat, acc_w=w)
        o2, v2 = reference_scalar(A.tolist(), B.tolist(), C.tolist(), accumulate=acc, saturate=sat, acc_w=w)
        assert o1.tolist() == o2 and v1.tolist() == v2


def test_wrap_and_saturate_boundaries():
    w = 20
    lo, hi = acc_range(w)
    A = np.array([[-128]]); B = np.array([[-128]])       # +16384
    for c, sat, exp_word, exp_ovf in [
        (hi - 16384, False, hi, False),                    # lands exactly on MAX
        (hi - 16383, False, lo, True),                     # MAX + 1 wraps to MIN
        (hi - 16383, True, hi, True),                      # ... or saturates to MAX
    ]:
        o, v, _ = reference(A, B, np.array([[c & 0xFFFFFFFF]], np.uint32), accumulate=True, saturate=sat, acc_w=w)
        assert sext(int(o[0, 0]), 32) == exp_word and bool(v[0, 0]) == exp_ovf
    A = np.array([[-128]]); B = np.array([[127]])         # -16256
    o, v, _ = reference(A, B, np.array([[lo & 0xFFFFFFFF]], np.uint32), accumulate=True, saturate=True, acc_w=w)
    assert sext(int(o[0, 0]), 32) == lo and v[0, 0]
    o, v, _ = reference(A, B, np.array([[lo & 0xFFFFFFFF]], np.uint32), accumulate=True, saturate=False, acc_w=w)
    assert sext(int(o[0, 0]), 32) == hi - 16256 + 1 and v[0, 0]
    # only the low ACC_W bits of a C word are C_in
    o, v, _ = reference(np.array([[0]]), np.array([[0]]), np.array([[0xFFF00005]], np.uint32), accumulate=True, acc_w=20)
    assert int(o[0, 0]) == 5


def test_zero_init_never_overflows_at_k_max():
    for w in (16, 18, 20, 24):
        km = k_max(w)
        for a, b in ((-128, -128), (-128, 127), (127, 127)):
            A = np.full((1, km), a); B = np.full((km, 1), b)
            _, v, ex = reference(A, B, acc_w=w)
            assert not v.any()
            assert acc_range(w)[0] <= ex[0, 0] <= acc_range(w)[1]


def test_result_independent_of_tiling():
    """The contract has no tiling in it; summing in any block order gives the same words."""
    rng = np.random.default_rng(3)
    A = rng.integers(-128, 128, (7, 50)); B = rng.integers(-128, 128, (50, 5))
    full = A @ B
    for kt in (1, 3, 7, 16, 50):
        s = np.zeros_like(full)
        for k0 in range(0, 50, kt):
            s += A[:, k0:k0 + kt] @ B[k0:k0 + kt]
        assert (s == full).all()


def test_nbeats():
    for bus in (4, 8, 16, 32):
        for addr in range(0, 3 * bus):
            for n in range(1, 3 * bus):
                exp = len({a // bus for a in range(addr, addr + n)})
                assert nbeats(addr, n, bus) == exp


def test_validate_priorities():
    cfg = Cfg()
    ok = Desc(a=0x1000, b=0x8000, c=0x10000, cpl=0x20000, M=8, N=8, K=8, lda=8, ldb=8, ldc=8, flags=F_CPL_EN)
    assert validate(cfg, ok) == ERR_NONE
    def v(**kw):
        d = Desc(**{**ok.__dict__, **kw}); return validate(cfg, d)
    assert v(M=0) == ERR_DIM and v(K=1 << 20) == ERR_DIM
    assert v(K=k_max(32) + 1, lda=k_max(32) + 1) == ERR_KMAX
    assert v(lda=7) == ERR_LD and v(ldb=7) == ERR_LD and v(ldc=7) == ERR_LD
    assert v(ldb=8, N=9, ldc=9) == ERR_LD
    assert v(flags=F_TRANS_B | F_CPL_EN, K=9, lda=9, ldb=8) == ERR_LD
    assert v(c=0x10002) == ERR_ALIGN and v(cpl=0x20004) == ERR_ALIGN
    assert v(cpl=0x20004, flags=0) == ERR_NONE
    assert v(a=0xFFFF_FFF0, lda=8) == ERR_RANGE
    assert v(c=0x1004) == ERR_ALIAS and v(c=0x8000) == ERR_ALIAS
    assert v(M=0, lda=1) == ERR_DIM                       # DIM has priority over LD


def test_counters_simple():
    cfg = Cfg(TM=2, TN=2, TK=1, KT=4, BUS_BYTES=4)
    d = Desc(a=0, b=100, c=200, cpl=0, M=3, N=3, K=5, lda=5, ldb=3, ldc=3, flags=0)
    c = job_counters(cfg, d)
    assert c.macs == 45 and c.tiles == 4 and c.ktiles == 8
    assert c.rd_bytes == 2 * (3 * 5) + 2 * (5 * 3)        # A re-read per column of tiles, B per row of tiles
    assert c.wr_bytes == 4 * 9
    d.flags = F_ACCUM
    c2 = job_counters(cfg, d)
    assert c2.rd_bytes == c.rd_bytes + 36 and c2.wr_bytes == c.wr_bytes
    assert compulsory_bytes(d) == 15 + 15 + 2 * 36


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t()
        print(f"PASS {t.__name__}")
    print(f"{len(tests)} model tests passed")
