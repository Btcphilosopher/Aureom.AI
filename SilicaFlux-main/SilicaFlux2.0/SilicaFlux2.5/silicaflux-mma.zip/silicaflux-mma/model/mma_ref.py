"""Numerical reference for the SilicaFlux MMA accelerator (SF-MMA).

The contract (docs/NUMERICS.md) in executable form:

* A (M x K) and B (K x N) are signed 8-bit two's-complement integers.
* Every product is exact: -16256 <= a*b <= 16384 (= (-128)*(-128) = 2**14).
* The accumulator is ACC_W bits (16..32).  With K <= K_MAX(ACC_W) = 2**(ACC_W-15) - 1
  the sum of K products can never leave the ACC_W range, so  S = A @ B  is exact.
  K_MAX is tight: K_MAX + 1 products of (-128)*(-128) equal 2**(ACC_W-1), one more
  than the largest ACC_W value.  The hardware rejects K > K_MAX (ERR_KMAX).
* Accumulate mode (C = C + A*B, in place): C_in is the low ACC_W bits of each
  32-bit C word, sign-extended.  exact = S + C_in is formed in ACC_W+1 bits
  (cannot overflow there).  An element *overflows* when exact is outside
  [-2**(ACC_W-1), 2**(ACC_W-1) - 1].  Overflowed elements are either wrapped
  (two's complement, modulo 2**ACC_W) or saturated, as selected per job.
* The ACC_W-bit result is stored sign-extended in a 32-bit little-endian word.

Because wrap and saturate are applied once, to the exact sum, the result does not
depend on the order of accumulation or on the hardware tiling (TM, TN, TK, KT).
"""
from __future__ import annotations

import numpy as np

INT8_MIN, INT8_MAX = -128, 127
PROD_MIN = INT8_MIN * INT8_MAX       # -16256
PROD_MAX = INT8_MIN * INT8_MIN       #  16384


def k_max(acc_w: int) -> int:
    """Largest K for which no ACC_W-bit overflow is possible (zero initial value)."""
    if not 16 <= acc_w <= 32:
        raise ValueError("ACC_W must be in 16..32")
    return (1 << (acc_w - 15)) - 1


def k_limit(acc_w: int, dim_w: int = 20) -> int:
    """K accepted by the hardware: the numeric bound, capped by the K register width."""
    return min(k_max(acc_w), (1 << dim_w) - 1)


def acc_range(acc_w: int) -> tuple[int, int]:
    return -(1 << (acc_w - 1)), (1 << (acc_w - 1)) - 1


def sext(x, bits: int):
    """Sign-extend the low `bits` bits of x (int or int64 array)."""
    mask = (1 << bits) - 1
    sign = 1 << (bits - 1)
    if isinstance(x, np.ndarray):
        x = x.astype(np.int64) & mask
        return np.where(x & sign, x - (1 << bits), x)
    x &= mask
    return x - (1 << bits) if x & sign else x


def wrap(x, bits: int):
    """Two's-complement wrap of x into `bits` bits."""
    return sext(x, bits)


def finish(exact, acc_w: int, saturate: bool):
    """Overflow flag and stored 32-bit word for exact (int64 array) values."""
    lo, hi = acc_range(acc_w)
    ovf = (exact < lo) | (exact > hi)
    res = np.clip(exact, lo, hi) if saturate else wrap(exact, acc_w)
    words = (np.asarray(res, dtype=np.int64) & 0xFFFFFFFF).astype(np.uint32)
    return words, ovf


def reference(A, B, C_words=None, *, accumulate=False, saturate=False, acc_w=32):
    """numpy reference.  A: (M,K) int8, B: (K,N) int8 (logical orientation),
    C_words: (M,N) uint32 C memory words (needed for accumulate).
    Returns (out_words uint32 (M,N), overflow bool (M,N), exact int64 (M,N))."""
    A = np.asarray(A, dtype=np.int64)
    B = np.asarray(B, dtype=np.int64)
    M, K = A.shape
    K2, N = B.shape
    assert K == K2
    if K > k_max(acc_w):
        raise ValueError(f"K={K} exceeds K_MAX={k_max(acc_w)} for ACC_W={acc_w}")
    S = A @ B                                  # exact in int64 (|S| < 2**31)
    if accumulate:
        cin = sext(np.asarray(C_words, dtype=np.int64), acc_w)
        exact = S + cin
    else:
        exact = S
    words, ovf = finish(exact, acc_w, saturate)
    return words, ovf, exact


def reference_scalar(A, B, C_words=None, *, accumulate=False, saturate=False, acc_w=32):
    """Independent pure-Python implementation (no numpy arithmetic) used to
    cross-check `reference` on small cases."""
    M, K = len(A), len(A[0])
    N = len(B[0])
    lo, hi = -(1 << (acc_w - 1)), (1 << (acc_w - 1)) - 1
    out, ovf = [], []
    for m in range(M):
        row_o, row_v = [], []
        for n in range(N):
            s = 0
            for k in range(K):
                s += int(A[m][k]) * int(B[k][n])
            if accumulate:
                w = int(C_words[m][n]) & ((1 << acc_w) - 1)
                if w >= 1 << (acc_w - 1):
                    w -= 1 << acc_w
                s += w
            o = s < lo or s > hi
            if o and saturate:
                v = lo if s < lo else hi
            else:
                v = ((s - lo) % (1 << acc_w)) + lo
            row_o.append(v & 0xFFFFFFFF)
            row_v.append(o)
        out.append(row_o)
        ovf.append(row_v)
    return out, ovf
