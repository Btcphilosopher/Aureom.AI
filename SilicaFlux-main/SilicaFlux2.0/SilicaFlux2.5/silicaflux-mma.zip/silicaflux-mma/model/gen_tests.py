#!/usr/bin/env python3
"""Test generator for the SF-MMA testbench (tb/tb_mma.sv).

A *test* is one simulation run: a memory image plus a sequence of jobs.  For
every job the generator places A, B, C (and a completion record) in memory --
misaligned bases, padded leading dimensions, background "canary" bytes in every
gap -- computes the expected C with the numerical reference (mma_ref.py), the
expected completion code (traffic.validate), the expected counters and an
analytic cycle lower bound (traffic.job_counters / lower_bound_cycles), and
writes:

    <dir>/init.hex   memory contents before the first job ($readmemh, @addr format)
    <dir>/exp.hex    expected contents after all jobs (C regions only)
    <dir>/jobs.txt   one line of NF hex fields per job (see tb/tb_mma.sv)
    <dir>/test.json  human-readable description

Usage: gen_tests.py --cfg base --suite directed|random|all --out DIR [--seed S]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mma_ref import reference, k_max, k_limit, acc_range           # noqa: E402
from traffic import (Cfg, Desc, validate, job_counters, lower_bound_cycles, cpl_ok,  # noqa: E402
                     ERR_NONE, ERR_DIM, ERR_KMAX, ERR_LD, ERR_ALIGN, ERR_RANGE, ERR_ALIAS,
                     ERR_RD, ERR_WR, ERR_ABORT, F_ACCUM, F_SAT, F_TRANS_B, F_IRQ_EN, F_CPL_EN)

NF = 44
MEM_BYTES = 2 << 20
GPU_BYTES = 1 << 16

# memory behaviour presets (see tb/tb_mem.sv)
PROFILES = {
    "ideal": dict(lat=4,  wlat=4,  jitter=0,  p_rd=100, p_wr=100, throttle=1, stall_period=0,    stall_len=0,    gpu=0),
    "typ":   dict(lat=12, wlat=8,  jitter=4,  p_rd=100, p_wr=100, throttle=1, stall_period=0,    stall_len=0,    gpu=0),
    "bp":    dict(lat=10, wlat=10, jitter=8,  p_rd=50,  p_wr=50,  throttle=1, stall_period=0,    stall_len=0,    gpu=0),
    "heavy": dict(lat=30, wlat=20, jitter=30, p_rd=25,  p_wr=30,  throttle=1, stall_period=0,    stall_len=0,    gpu=20),
    "stall": dict(lat=10, wlat=6,  jitter=2,  p_rd=100, p_wr=100, throttle=1, stall_period=2500, stall_len=1500, gpu=0),
    "gpu":   dict(lat=12, wlat=8,  jitter=4,  p_rd=100, p_wr=100, throttle=1, stall_period=0,    stall_len=0,    gpu=40),
    "slow":  dict(lat=6,  wlat=6,  jitter=0,  p_rd=100, p_wr=100, throttle=3, stall_period=0,    stall_len=0,    gpu=0),
}

ALL_CODES = 0xFFFF


def bg_array(n: int) -> np.ndarray:
    """Background pattern of untouched memory -- identical to bg() in tb_mma.sv."""
    a = np.arange(n, dtype=np.uint64)
    h = (a * np.uint64(0x9E3779B1)) & np.uint64(0xFFFFFFFF)
    return ((h >> np.uint64(11)) & np.uint64(0xFF)).astype(np.uint8)


def gen_data(rng, kind: str, shape) -> np.ndarray:
    if kind == "uniform":
        x = rng.integers(-128, 128, shape)
    elif kind == "neg":
        x = rng.integers(-128, 0, shape)
    elif kind == "pos":
        x = rng.integers(0, 128, shape)
    elif kind == "extreme":
        x = rng.choice(np.array([-128, -127, -1, 0, 1, 126, 127]), shape)
    elif kind == "minus128":
        x = np.full(shape, -128)
    elif kind == "plus127":
        x = np.full(shape, 127)
    elif kind == "minus1":
        x = np.full(shape, -1)
    elif kind == "zero":
        x = np.zeros(shape, dtype=np.int64)
    elif kind == "sparse":
        x = rng.integers(-128, 128, shape) * (rng.random(shape) < 0.1)
    elif kind == "checker":
        i, j = np.indices(shape)
        x = np.where((i + j) % 2 == 0, -128, 127)
    else:
        raise ValueError(kind)
    return np.asarray(x, dtype=np.int64)


class Test:
    def __init__(self, name: str, cfg: Cfg, seed: int, mem_bytes: int = MEM_BYTES):
        self.name, self.cfg, self.seed = name, cfg, seed
        self.rng = np.random.default_rng(seed)
        self.mem_bytes = mem_bytes
        self.limit = mem_bytes - GPU_BYTES
        self.init = bg_array(mem_bytes)
        self.state = self.init.copy()          # memory as expected after every job completes
        self.init_regions: list[tuple[int, int]] = []
        self.exp_regions: list[tuple[int, int]] = []
        self.ptr = 0x100
        self.jobs: list[list[int]] = []
        self.info: list[dict] = []

    # ------------------------------------------------------------ placement
    def alloc(self, nbytes: int, align: int = 1, skew: int = 0) -> int:
        p = self.ptr + int(self.rng.integers(0, 48))
        p = (p + align - 1) // align * align + skew
        if p + nbytes > self.limit:
            raise MemoryError(f"{self.name}: test memory exhausted")
        self.ptr = p + max(nbytes, 1)
        return p

    def put(self, addr: int, data: np.ndarray):
        data = np.asarray(data, dtype=np.uint8).ravel()
        self.init[addr:addr + data.size] = data
        self.state[addr:addr + data.size] = data
        self.init_regions.append((addr, data.size))

    def free_bytes(self) -> int:
        return self.limit - self.ptr

    # ------------------------------------------------------------ jobs
    def add_job(self, M, N, K, *, A=None, B=None, cinit=None, data="uniform", accum=False, sat=False,
                trans_b=False, lda_pad=0, ldb_pad=0, ldc_pad=0, misalign=True, irq=False, cpl=True, poll=0,
                action=0, action_at=0, profile="typ", err=None, chk=True, metric=False, override=None,
                note="", retry_of=None, seed=None, expect=None, action_frac=None):
        cfg, rng = self.cfg, self.rng
        bus = cfg.BUS_BYTES
        prof = PROFILES[profile] if isinstance(profile, str) else profile
        flags = (F_ACCUM if accum else 0) | (F_SAT if sat else 0) | (F_TRANS_B if trans_b else 0) \
            | (F_IRQ_EN if irq else 0) | (F_CPL_EN if cpl else 0)
        tag = int(rng.integers(0, 1 << 32))

        if retry_of is not None:
            # identical descriptor and region as an earlier job (used after an interrupted run)
            prev = self.info[retry_of]
            d = Desc(**prev["desc"])
            d.cpl = self.alloc(16, 16)
            self.put(d.cpl, np.zeros(16, np.uint8))
            d.tag = tag
            d.flags = (d.flags & ~(F_IRQ_EN | F_CPL_EN)) | (F_IRQ_EN if irq else 0) | (F_CPL_EN if cpl else 0)
            A, B, words, ovf = prev["A"], prev["B"], prev["words"], prev["ovf"]
        else:
            lda = K + lda_pad
            ldb = (K + ldb_pad) if trans_b else (N + ldb_pad)
            ldc = N + ldc_pad
            if A is None:
                ka, kb = (data, data) if isinstance(data, str) else data
                A = gen_data(rng, ka, (M, K)) if M and K else np.zeros((M, K), np.int64)
                B = gen_data(rng, kb, (K, N)) if K and N else np.zeros((K, N), np.int64)
            sk = (lambda al: int(rng.integers(0, bus // al)) * al) if misalign else (lambda al: 0)
            d = Desc(a=0, b=0, c=0, cpl=0, M=M, N=N, K=K, lda=lda, ldb=ldb, ldc=ldc, flags=flags, tag=tag)
            if M and N and K and K <= 1 << 22:
                # A rows
                d.a = self.alloc((M - 1) * lda + K, bus, sk(1))
                for m in range(M):
                    self.put(d.a + m * lda, A[m].astype(np.int8).view(np.uint8))
                # B rows (row-major K x N, or transposed N x K)
                if trans_b:
                    d.b = self.alloc((N - 1) * ldb + K, bus, sk(1))
                    for n in range(N):
                        self.put(d.b + n * ldb, B[:, n].astype(np.int8).view(np.uint8))
                else:
                    d.b = self.alloc((K - 1) * ldb + N, bus, sk(1))
                    for k in range(K):
                        self.put(d.b + k * ldb, B[k].astype(np.int8).view(np.uint8))
                # C (initial words are the "old" values; in accumulate mode they are C_in)
                d.c = self.alloc(4 * ((M - 1) * ldc + N), bus, sk(4))
                if cinit is None:
                    cinit = rng.integers(0, 1 << 32, (M, N), dtype=np.uint64).astype(np.uint32)
                cinit = np.asarray(cinit, dtype=np.uint32)
                for m in range(M):
                    self.put(d.c + 4 * m * ldc, cinit[m].view(np.uint8))
            d.cpl = self.alloc(16, 16)
            self.put(d.cpl, np.zeros(16, np.uint8))
            if override:
                for k, v in override.items():
                    setattr(d, k, v)
            words = ovf = None
            if validate(cfg, d) == ERR_NONE:
                words, ovf, _ = reference(A, B, cinit, accumulate=accum, saturate=sat, acc_w=cfg.ACC_W)

        code = validate(cfg, d)
        if expect is not None and code != expect:
            raise AssertionError(f"{self.name}: job '{note}' validates to {code}, intended {expect}")
        cnt = job_counters(cfg, d)
        lb = lower_bound_cycles(cfg, d, cnt, prof["throttle"])
        if action_frac is not None:
            # interrupt at a fraction of the job's analytic duration (memory-latency aware estimate)
            est = lb + (cnt.ktiles + cnt.tiles) * prof["lat"] // max(1, cfg.IN_BUFS)
            action_at = max(1, int(action_frac * est))

        # expected memory after the job (written even for interruptible jobs: old-or-new is accepted)
        if code == ERR_NONE:
            for m in range(d.M):
                a = d.c + 4 * m * d.ldc
                self.state[a:a + 4 * d.N] = words[m].view(np.uint8)
                self.exp_regions.append((a, 4 * d.N))

        # allowed completion codes
        if code != ERR_NONE:
            mask = 1 << code
        elif action == 2:
            mask = ALL_CODES
        else:
            mask = 1 << ERR_NONE
            if action == 1:
                mask |= 1 << ERR_ABORT
        ewin = [0, 0, 0, 0]
        if err is not None and code == ERR_NONE:
            kind, what, row = err
            if what == "A":
                lo = d.a + min(row, d.M - 1) * d.lda + int(rng.integers(0, d.K))
            elif what == "B":
                rows = d.N if d.trans_b else d.K
                lo = d.b + min(row, rows - 1) * d.ldb
            else:   # "C": C_in read (accumulate) or C write
                lo = d.c + 4 * min(row, d.M - 1) * d.ldc
            if kind == "rd":
                ewin[0:2] = [lo, lo + 1]
                mask = 1 << ERR_RD
            else:
                ewin[2:4] = [lo, lo + 1]
                mask = 1 << ERR_WR
            chk = False
        if action in (1, 2):
            chk = False

        tmax = (lb + 2000) * 64 * prof["throttle"] * (100 // max(1, min(prof["p_rd"], prof["p_wr"])))
        if prof["stall_period"]:
            tmax += (lb // max(1, prof["stall_period"] - prof["stall_len"]) + 2) * prof["stall_len"] * 4
        tmax = min(tmax, 0x7FFF_FFFF)

        ovf_cnt = int(ovf.sum()) if (code == ERR_NONE and ovf is not None) else 0
        f = [0] * NF
        f[0:12] = [d.a, d.b, d.c, d.cpl, d.M, d.N, d.K, d.lda, d.ldb, d.ldc, d.flags, d.tag]
        f[12] = mask
        f[13] = ovf_cnt
        f[14], f[15] = cnt.rd_beats, cnt.wr_beats
        f[16], f[17] = cnt.macs & 0xFFFFFFFF, cnt.macs >> 32
        f[18], f[19], f[20], f[21] = cnt.rd_bytes, cnt.wr_bytes, cnt.tiles, cnt.ktiles
        f[22] = 1 if chk else 0
        f[23], f[24] = action, action_at
        f[25:34] = [prof["lat"], prof["wlat"], prof["jitter"], prof["p_rd"], prof["p_wr"], prof["throttle"],
                    prof["stall_period"], prof["stall_len"], prof["gpu"]]
        f[34:38] = ewin
        f[38] = poll
        f[39] = int(rng.integers(1, 1 << 31)) if seed is None else seed
        f[40] = 1 if metric else 0
        f[41] = tmax
        f[42] = lb if (code == ERR_NONE and chk) else 0
        self.jobs.append([int(x) & 0xFFFFFFFF for x in f])
        self.info.append(dict(desc=d.__dict__.copy(), A=A, B=B, words=words, ovf=ovf, code=code, mask=mask,
                              action=action, profile=profile if isinstance(profile, str) else "custom",
                              counters=cnt.__dict__.copy(), lb=lb, note=note, err=err, accum=accum, sat=sat,
                              trans_b=trans_b))
        return len(self.jobs) - 1

    # ------------------------------------------------------------ output
    def write(self, out: Path):
        out.mkdir(parents=True, exist_ok=True)

        def dump(path, regions, img):
            with open(path, "w") as fh:
                for a, n in sorted(set(regions)):
                    fh.write(f"@{a:x}\n")
                    fh.write("\n".join(f"{v:02x}" for v in img[a:a + n].tolist()))
                    fh.write("\n")
        dump(out / "init.hex", self.init_regions, self.init)
        dump(out / "exp.hex", self.exp_regions, self.state)
        with open(out / "jobs.txt", "w") as fh:
            for j in self.jobs:
                fh.write(" ".join(f"{x:x}" for x in j) + "\n")
        meta = dict(name=self.name, cfg=self.cfg.__dict__, seed=self.seed, jobs=[
            dict(i=i, M=x["desc"]["M"], N=x["desc"]["N"], K=x["desc"]["K"], flags=x["desc"]["flags"],
                 lda=x["desc"]["lda"], ldb=x["desc"]["ldb"], ldc=x["desc"]["ldc"],
                 a=x["desc"]["a"], b=x["desc"]["b"], c=x["desc"]["c"],
                 code=x["code"], mask=x["mask"], action=x["action"], profile=x["profile"], err=x["err"],
                 counters=x["counters"], lb=x["lb"], note=x["note"]) for i, x in enumerate(self.info)])
        (out / "test.json").write_text(json.dumps(meta, indent=1, default=int))


# =============================================================================
# suites
# =============================================================================
def suite_directed(cfg: Cfg, long_tests: bool = True) -> list[Test]:
    TM, TN, TK, KT, BUS = cfg.TM, cfg.TN, cfg.TK, cfg.KT, cfg.BUS_BYTES
    KM = k_limit(cfg.ACC_W, cfg.DIM_W)
    kmid = min(KM, 3 * KT + 5)
    tests = []

    t = Test("d01_tiny", cfg, 101)
    for (m, n, k) in [(1, 1, 1), (1, 1, 2), (2, 1, 1), (1, 2, 1), (1, 1, min(KM, TK + 1)), (2, 3, min(KM, 5))]:
        t.add_job(m, n, k, note="tiny")
    tests.append(t)

    t = Test("d02_full_tiles", cfg, 102)
    t.add_job(TM, TN, min(KM, KT), misalign=False, note="one exact tile")
    t.add_job(2 * TM, 2 * TN, min(KM, 2 * KT), misalign=False, note="2x2 tiles, 2 k-tiles")
    t.add_job(TM, 3 * TN, min(KM, KT), misalign=False, trans_b=True, note="exact tiles, B transposed")
    tests.append(t)

    t = Test("d03_negative", cfg, 103)
    t.add_job(TM + 1, TN + 2, kmid, data="neg", note="all operands negative")
    t.add_job(TM + 3, TN + 1, kmid, data=("neg", "pos"), note="negative A, positive B")
    t.add_job(5, 6, kmid, data="minus1", note="all -1")
    t.add_job(2 * TM - 1, TN, kmid, data="uniform", trans_b=True, note="mixed signs, B^T")
    tests.append(t)

    t = Test("d04_extremes", cfg, 104)
    t.add_job(TM, TN, kmid, data="minus128", note="(-128)*(-128) = 2^14, largest product")
    t.add_job(TM + 1, TN + 1, kmid, data=("minus128", "plus127"), note="(-128)*127, most negative product")
    t.add_job(TM, TN + 3, kmid, data="plus127", note="127*127")
    t.add_job(2 * TM + 1, 2 * TN - 1, kmid, data="checker", note="alternating -128/127")
    t.add_job(TM + 2, TN + 2, kmid, data="extreme", trans_b=True, note="random extremes, B^T")
    t.add_job(TM, TN, min(KM, 4 * KT), data="minus128", accum=True,
              cinit=np.zeros((TM, TN), np.uint32), note="extremes, accumulate onto 0")
    tests.append(t)

    t = Test("d05_rectangular", cfg, 105)
    for (m, n, k) in [(1, 3 * TN + 1, 7), (3 * TM + 1, 1, 7), (5, 7, 3 * KT + 3), (2 * TM + 3, max(1, TN - 1), KT + 1),
                      (37, 19, 53), (1, 1, 4 * KT + 1), (4 * TM, 2, 3)]:
        t.add_job(m, n, min(KM, k), note="rectangular")
    tests.append(t)

    t = Test("d06_partial_tiles", cfg, 106)
    for dm in (0, 1, TM - 1):
        for dn in (0, 1, TN - 1):
            for dk in (0, 1, max(1, TK - 1), KT - 1):
                m, n, k = TM + dm, TN + dn, min(KM, KT + dk)
                if m < 1 or n < 1 or k < 1:
                    continue
                t.add_job(m, n, k, trans_b=bool((dm + dn + dk) % 2), note=f"tails m+{dm} n+{dn} k+{dk}")
    tests.append(t)

    t = Test("d07_strides_alignment", cfg, 107)
    for i in range(10):
        t.add_job(TM + i, TN + (i * 3) % TN + 1, min(KM, KT + 2 * i + 1), lda_pad=int(t.rng.integers(0, 40)),
                  ldb_pad=int(t.rng.integers(0, 40)), ldc_pad=int(t.rng.integers(0, 9)), trans_b=bool(i % 2),
                  note="padded leading dims, misaligned bases")
    t.add_job(3, 5, min(KM, 9), lda_pad=BUS * 3 + 1, ldb_pad=BUS + 3, ldc_pad=BUS, note="large pads")
    tests.append(t)

    t = Test("d08_accumulate", cfg, 108)
    t.add_job(TM + 1, TN + 1, kmid, accum=True, note="C += A*B in place, random C_in")
    t.add_job(2 * TM + 3, TN - 1 if TN > 1 else 1, kmid, accum=True, trans_b=True, ldc_pad=3, note="accumulate, B^T, padded C")
    t.add_job(3, 2 * TN + 1, kmid, accum=True, sat=True, note="accumulate + saturate flag, no overflow expected")
    tests.append(t)

    # overflow: C_in close to the limits so that exact = acc + C_in leaves the ACC_W range
    t = Test("d09_overflow", cfg, 109)
    lo, hi = acc_range(cfg.ACC_W)
    for sat in (False, True):
        for trans_b in (False, True):
            m, n, k = TM + 2, TN + 1, min(KM, 2 * KT + 3)
            A = gen_data(t.rng, "extreme", (m, k))
            B = gen_data(t.rng, "extreme", (k, n))
            S = A @ B
            sel = t.rng.integers(0, 3, (m, n))
            base = np.where(sel == 0, hi - S // 2, np.where(sel == 1, lo - S // 2, t.rng.integers(lo // 2, hi // 2, (m, n))))
            base = np.clip(base, lo, hi).astype(np.int64)
            t.add_job(m, n, k, A=A, B=B, cinit=(base & 0xFFFFFFFF).astype(np.uint32), accum=True, sat=sat,
                      trans_b=trans_b, note=f"overflow {'saturate' if sat else 'wrap'}")
    # every element overflows, both directions
    m, n, k = TM, TN, min(KM, KT)
    t.add_job(m, n, k, data="minus128", accum=True, sat=False, cinit=np.full((m, n), hi & 0xFFFFFFFF, np.uint32),
              note="all overflow positive, wrap")
    t.add_job(m, n, k, data="minus128", accum=True, sat=True, cinit=np.full((m, n), hi & 0xFFFFFFFF, np.uint32),
              note="all overflow positive, saturate")
    t.add_job(m, n, k, data=("minus128", "plus127"), accum=True, sat=True,
              cinit=np.full((m, n), lo & 0xFFFFFFFF, np.uint32), note="all overflow negative, saturate")
    t.add_job(m, n, k, data=("minus128", "plus127"), accum=True, sat=False,
              cinit=np.full((m, n), lo & 0xFFFFFFFF, np.uint32), note="all overflow negative, wrap")
    if cfg.ACC_W < 32:
        # C words with bits above ACC_W set: only the low ACC_W bits are C_in
        t.add_job(TM, TN, min(KM, 5), accum=True, cinit=t.rng.integers(0, 1 << 32, (TM, TN), dtype=np.uint64).astype(np.uint32),
                  note="C_in upper bits ignored")
    tests.append(t)

    # accumulation-length bound
    t = Test("d10_k_limit", cfg, 110)
    if KM <= 4096:
        t.add_job(2, 3, KM, data="minus128", note="K = K_MAX, all (-128)^2: largest exact sum")
        t.add_job(2, 3, KM, data=("minus128", "plus127"), trans_b=True, note="K = K_MAX, most negative sum")
    t.add_job(2, 2, 4, override=dict(K=KM + 1, lda=KM + 1), note="K = K_MAX + 1 -> ERR_KMAX", expect=ERR_KMAX)
    tests.append(t)
    if long_tests and KM > 4096:
        t = Test("d10b_k_max_long", cfg, 1100)
        t.add_job(1, 1, KM, data="minus128", trans_b=True, misalign=False, profile="ideal",
                  note=f"K = K_MAX = {KM}: sum = {KM * 16384} <= 2^{cfg.ACC_W - 1}-1")
        tests.append(t)

    t = Test("d11_bad_descriptors", cfg, 111)
    # each descriptor fault, completion record enabled so the code is reported in memory too
    k4 = min(KM, 4)
    t.add_job(4, 4, k4, override=dict(M=0), note="M = 0", expect=ERR_DIM)
    t.add_job(4, 4, k4, override=dict(N=0), note="N = 0", expect=ERR_DIM)
    t.add_job(4, 4, 4, override=dict(K=0), note="K = 0", expect=ERR_DIM)
    t.add_job(4, 4, k4, override=dict(M=1 << cfg.DIM_W), note="M >= 2^DIM_W", expect=ERR_DIM)
    t.add_job(4, 4, k4, override=dict(K=KM + 1), note="K > K_LIMIT", expect=ERR_KMAX)
    k6 = min(KM, 6)
    t.add_job(4, 4, k6, override=dict(lda=k6 - 1), note="lda < K", expect=ERR_LD)
    t.add_job(4, 6, k6, override=dict(ldb=5), note="ldb < N (row-major B)", expect=ERR_LD)
    t.add_job(4, 6, k6, trans_b=True, override=dict(ldb=k6 - 1), note="ldb < K (transposed B)", expect=ERR_LD)
    t.add_job(4, 6, k6, override=dict(ldc=5), note="ldc < N", expect=ERR_LD)
    t.add_job(4, 4, k6, override=dict(lda=1 << cfg.DIM_W), note="lda >= 2^DIM_W", expect=ERR_LD)
    t.add_job(4, 4, k4, override=dict(c=t.alloc(80, 4) + 2), note="C base not 4-byte aligned", expect=ERR_ALIGN)
    t.add_job(4, 4, k4, override=dict(cpl=t.alloc(32, 16) + 4), note="completion address not 16-byte aligned", expect=ERR_ALIGN)
    t.add_job(4, 4, k4, override=dict(a=0xFFFF_FFFE), note="A wraps the address space", expect=ERR_RANGE)
    t.add_job(4, 4, k4, override=dict(c=0xFFFF_FFE0, ldc=4), note="C wraps the address space", expect=ERR_RANGE)
    k8 = min(KM, 8)
    i0 = t.add_job(4, 4, k8, note="valid job, its regions reused below")
    d0 = t.info[i0]["desc"]
    t.add_job(4, 4, k8, override=dict(a=d0["a"], b=d0["b"], c=(d0["a"] + 4) & ~3), note="C overlaps A -> ERR_ALIAS", expect=ERR_ALIAS)
    t.add_job(4, 4, k8, override=dict(a=d0["a"], b=d0["b"], c=(d0["b"] + 3) & ~3), note="C overlaps B -> ERR_ALIAS", expect=ERR_ALIAS)
    t.add_job(TM + 1, TN + 1, kmid, note="valid job after the rejected ones")
    tests.append(t)

    t = Test("d12_completion_modes", cfg, 112)
    t.add_job(TM + 1, TN + 2, kmid, irq=True, cpl=False, poll=1, note="completion by interrupt")
    t.add_job(TM + 2, TN + 1, kmid, irq=False, cpl=True, poll=2, note="completion by polling the record in memory")
    t.add_job(TM, TN, kmid, irq=True, cpl=True, poll=0, note="STATUS polling, irq and record")
    t.add_job(2, 2, 2, irq=False, cpl=False, poll=0, note="no irq, no record")
    t.add_job(TM + 3, 2 * TN, kmid, irq=True, cpl=True, poll=2, profile="bp", note="record polling under back-pressure")
    tests.append(t)

    t = Test("d13_busy_interactions", cfg, 113)
    t.add_job(3 * TM, 3 * TN, min(KM, 4 * KT), action=3, action_at=30, note="START while busy is rejected")
    t.add_job(3 * TM, 2 * TN, min(KM, 4 * KT), action=4, action_at=40, note="descriptor rewritten while busy")
    t.add_job(TM, TN, kmid, note="next job unaffected")
    tests.append(t)

    t = Test("d14_memory_errors", cfg, 114)
    big = (3 * TM + 1, 2 * TN + 1, min(KM, 3 * KT + 1))
    t.add_job(*big, err=("rd", "A", 2 * TM), note="read error in A")
    t.add_job(TM, TN, kmid, note="clean job after a read error")
    t.add_job(*big, trans_b=True, err=("rd", "B", 1), note="read error in B^T")
    t.add_job(*big, err=("rd", "B", 2), note="read error in row-major B")
    t.add_job(*big, accum=True, err=("rd", "C", TM + 1), note="read error on C_in")
    t.add_job(*big, err=("wr", "C", TM + 2), note="write error on C")
    t.add_job(*big, accum=True, err=("wr", "C", 1), profile="bp", note="write error, accumulate, back-pressure")
    t.add_job(TM + 1, TN + 1, kmid, note="clean job after errors")
    tests.append(t)

    t = Test("d15_abort", cfg, 115)
    shape = (3 * TM + 2, 3 * TN + 1, min(KM, 3 * KT + 2))
    for i, fr in enumerate((0.0, 0.05, 0.2, 0.4, 0.6, 0.8, 0.95, 1.1)):
        t.add_job(*shape, action=1, action_frac=fr, accum=bool(i % 2), profile="typ" if i % 3 else "bp",
                  note=f"abort at {fr:.2f} of the job")
    t.add_job(TM + 1, TN + 1, kmid, note="clean job after aborts")
    tests.append(t)

    t = Test("d16_reset", cfg, 116)
    shape = (3 * TM + 1, 2 * TN + 3, min(KM, 3 * KT + 1))
    for k, fr in enumerate((0.0, 0.3, 0.6, 0.9)):
        i = t.add_job(*shape, action=2, action_frac=fr, profile="heavy" if k == 1 else "typ", note=f"reset at {fr:.2f} of the job")
        t.add_job(0, 0, 0, retry_of=i, note="identical job after the reset")
    tests.append(t)

    t = Test("d17_backpressure", cfg, 117)
    for prof in ("bp", "heavy", "stall", "slow", "gpu"):
        t.add_job(2 * TM + 1, 2 * TN + 1, min(KM, 2 * KT + 3), profile=prof, accum=prof in ("heavy", "gpu"),
                  trans_b=prof in ("stall", "gpu"), note=f"profile {prof}")
    tests.append(t)

    t = Test("d18_special_values", cfg, 118)
    t.add_job(TM + 1, TN + 1, kmid, data="zero", note="zero operands")
    n = min(KM, 2 * TN + 1)
    eye = np.eye(n, dtype=np.int64)
    A = gen_data(t.rng, "uniform", (TM + 2, n))
    t.add_job(TM + 2, n, n, A=A, B=eye, note="B = identity -> C = A")
    t.add_job(TM + 2, n, n, A=A, B=-eye, trans_b=True, note="B = -identity, transposed")
    t.add_job(2 * TM, 2 * TN, kmid, data="sparse", note="sparse operands")
    tests.append(t)
    return tests


def random_job(t: Test, rng, KM: int, heavy_ops: bool = True):
    cfg = t.cfg
    TM, TN, KT = cfg.TM, cfg.TN, cfg.KT
    shape_kind = rng.choice(["small", "medium", "skinny", "deep"], p=[0.35, 0.35, 0.15, 0.15])
    if shape_kind == "small":
        M, N, K = rng.integers(1, 2 * TM + 2), rng.integers(1, 2 * TN + 2), rng.integers(1, 2 * KT + 2)
    elif shape_kind == "medium":
        M, N, K = rng.integers(TM, 5 * TM + 2), rng.integers(TN, 4 * TN + 2), rng.integers(KT, 5 * KT)
    elif shape_kind == "skinny":
        M, N, K = (rng.integers(1, 3), rng.integers(TN, 8 * TN), rng.integers(1, 3 * KT)) if rng.random() < 0.5 \
            else (rng.integers(TM, 8 * TM), rng.integers(1, 3), rng.integers(1, 3 * KT))
    else:
        M, N, K = rng.integers(1, TM + 2), rng.integers(1, TN + 2), rng.integers(4 * KT, 12 * KT)
    M, N, K = int(M), int(N), int(min(int(K), KM))
    kw = dict(data=str(rng.choice(["uniform", "extreme", "neg", "sparse", "checker", "uniform"])),
              accum=bool(rng.random() < 0.3), sat=bool(rng.random() < 0.5), trans_b=bool(rng.random() < 0.35),
              lda_pad=int(rng.integers(0, 24)) if rng.random() < 0.5 else 0,
              ldb_pad=int(rng.integers(0, 24)) if rng.random() < 0.5 else 0,
              ldc_pad=int(rng.integers(0, 6)) if rng.random() < 0.4 else 0,
              misalign=bool(rng.random() < 0.85), irq=bool(rng.random() < 0.5), cpl=bool(rng.random() < 0.7),
              profile=str(rng.choice(["ideal", "typ", "typ", "bp", "heavy", "gpu", "slow", "stall"],
                                     p=[0.15, 0.25, 0.1, 0.15, 0.1, 0.1, 0.1, 0.05])))
    kw["poll"] = int(rng.choice([0, 1, 2])) if True else 0
    if kw["poll"] == 1:
        kw["irq"] = True
    if kw["poll"] == 2:
        kw["cpl"] = True
    if kw["accum"] and rng.random() < 0.5:
        lo, hi = acc_range(cfg.ACC_W)
        kw["cinit"] = (rng.choice([lo, hi, lo + 1, hi - 1, 0, -1], (M, N)) & 0xFFFFFFFF).astype(np.uint32)
    r = rng.random()
    if heavy_ops and r < 0.06:
        kw.update(action=1, action_frac=float(rng.random() * 1.1), poll=0)
    elif heavy_ops and r < 0.10:
        kind = str(rng.choice(["rd", "wr"]))
        what = "C" if kind == "wr" else str(rng.choice(["A", "B", "C"] if kw["accum"] else ["A", "B"]))
        kw.update(err=(kind, what, int(rng.integers(0, 64))), poll=0)
    elif heavy_ops and r < 0.13:
        kw.update(action=2, action_frac=float(rng.random()), poll=0)
    elif r < 0.18:
        kw.update(action=4, action_at=int(rng.integers(5, 60)))
    return t.add_job(M, N, K, note=f"random {shape_kind}", **kw)


def suite_random(cfg: Cfg, seed: int, ntests: int = 4, jobs_per_test: int = 24) -> list[Test]:
    tests = []
    KM = k_limit(cfg.ACC_W, cfg.DIM_W)
    for i in range(ntests):
        t = Test(f"r{seed:04d}_{i:02d}", cfg, seed * 1000 + i)
        rng = np.random.default_rng(seed * 7919 + i)
        for _ in range(jobs_per_test):
            if t.free_bytes() < 200_000:
                break
            try:
                random_job(t, rng, KM)
            except MemoryError:
                break
        tests.append(t)
    return tests


def main():
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
    from configs import CONFIGS                                       # noqa: E402
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", default="base", choices=sorted(CONFIGS))
    ap.add_argument("--suite", default="directed", choices=["directed", "random", "all"])
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--ntests", type=int, default=4)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    cfg = CONFIGS[a.cfg]
    tests = []
    if a.suite in ("directed", "all"):
        tests += suite_directed(cfg)
    if a.suite in ("random", "all"):
        tests += suite_random(cfg, a.seed, a.ntests)
    for t in tests:
        t.write(Path(a.out) / t.name)
        print(f"{t.name}: {len(t.jobs)} jobs -> {Path(a.out) / t.name}")


if __name__ == "__main__":
    main()
