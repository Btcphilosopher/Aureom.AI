"""Exact transfer / work model of SF-MMA and the descriptor validation rules.

Everything here is *derived from the schedule*, not from the RTL: the loader
walks output tiles in raster order with K innermost, fetches every row of every
k-tile byte-exactly with BUS-aligned beats, and the writer writes (and in
accumulate mode first reads) every output row once.  The testbench compares the
RTL's counters with these numbers on every successful job, so the bytes reported
in the results are the bytes the RTL really moved.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from math import ceil

from mma_ref import k_limit

ERR_NONE, ERR_DIM, ERR_KMAX, ERR_LD, ERR_ALIGN, ERR_RANGE, ERR_ALIAS, ERR_RD, ERR_WR, ERR_ABORT = range(10)
ERR_NAMES = ["OK", "DIM", "KMAX", "LD", "ALIGN", "RANGE", "ALIAS", "RD", "WR", "ABORT"]

F_ACCUM, F_SAT, F_TRANS_B, F_IRQ_EN, F_CPL_EN = 1, 2, 4, 8, 16


@dataclass(frozen=True)
class Cfg:
    """RTL parameter set (must match the Verilator -G overrides)."""
    name: str = "base"
    TM: int = 8
    TN: int = 8
    TK: int = 1
    KT: int = 32
    BUS_BYTES: int = 16
    IN_BUFS: int = 2
    OUT_BUFS: int = 2
    ACC_W: int = 32
    RD_OUT: int = 16
    WR_OUT: int = 8
    DIM_W: int = 20

    def gparams(self) -> dict:
        d = asdict(self)
        d.pop("name")
        return d

    def vflags(self) -> list[str]:
        return [f"-G{k}={v}" for k, v in self.gparams().items()]

    @property
    def peak_macs(self) -> int:
        """MACs the array can issue per cycle (a hardware capability, not a result)."""
        return self.TM * self.TN * self.TK

    @property
    def operand_bytes(self) -> int:
        """Local operand storage in bytes (all banks)."""
        return self.IN_BUFS * (self.TM + self.TN) * self.KT

    @property
    def output_bytes(self) -> int:
        """Accumulator + output-buffer storage in bytes (ACC_W bits per element)."""
        return self.OUT_BUFS * self.TM * self.TN * self.ACC_W // 8


@dataclass
class Desc:
    a: int
    b: int
    c: int
    cpl: int
    M: int
    N: int
    K: int
    lda: int
    ldb: int
    ldc: int
    flags: int = 0
    tag: int = 0

    @property
    def accum(self): return bool(self.flags & F_ACCUM)
    @property
    def sat(self): return bool(self.flags & F_SAT)
    @property
    def trans_b(self): return bool(self.flags & F_TRANS_B)
    @property
    def cpl_en(self): return bool(self.flags & F_CPL_EN)


def validate(cfg: Cfg, d: Desc) -> int:
    """Completion code the controller assigns before any memory traffic."""
    dw = cfg.DIM_W
    if any(x >> dw for x in (d.M, d.N, d.K)) or 0 in (d.M, d.N, d.K):
        return ERR_DIM
    if d.K > k_limit(cfg.ACC_W, dw):
        return ERR_KMAX
    if any(x >> dw for x in (d.lda, d.ldb, d.ldc)) or d.lda < d.K or \
            (d.ldb < d.K if d.trans_b else d.ldb < d.N) or d.ldc < d.N:
        return ERR_LD
    if d.c & 3 or (d.cpl_en and d.cpl & 15):
        return ERR_ALIGN
    a_end, b_end, c_end = extents(d)
    if max(a_end, b_end, c_end) > 1 << 32 or (d.cpl_en and d.cpl + 16 > 1 << 32):
        return ERR_RANGE
    if (d.c < a_end and d.a < c_end) or (d.c < b_end and d.b < c_end):
        return ERR_ALIAS
    return ERR_NONE


def extents(d: Desc):
    a_end = d.a + (d.M - 1) * d.lda + d.K
    b_end = d.b + ((d.N - 1) * d.ldb + d.K if d.trans_b else (d.K - 1) * d.ldb + d.N)
    c_end = d.c + 4 * ((d.M - 1) * d.ldc + d.N)
    return a_end, b_end, c_end


def cpl_ok(d: Desc) -> bool:
    return d.cpl_en and d.cpl % 16 == 0 and d.cpl + 16 <= 1 << 32


def nbeats(addr: int, length: int, bus: int) -> int:
    return (addr + length - 1) // bus - addr // bus + 1


@dataclass
class Counters:
    rd_beats: int = 0
    wr_beats: int = 0
    rd_bytes: int = 0        # useful bytes requested by reads
    wr_bytes: int = 0        # strobed bytes written
    macs: int = 0
    tiles: int = 0
    ktiles: int = 0
    steps: int = 0           # MAC-array steps (cycles with an issue)
    a_beats: int = 0
    b_beats: int = 0
    cin_beats: int = 0
    c_beats: int = 0

    @property
    def mem_beats(self):
        return self.rd_beats + self.wr_beats


def job_counters(cfg: Cfg, d: Desc) -> Counters:
    """Counter values of a job that completes with ERR_NONE (or of a rejected one)."""
    c = Counters()
    if validate(cfg, d) != ERR_NONE:
        if cpl_ok(d):
            c.wr_beats = nbeats(d.cpl, 16, cfg.BUS_BYTES)
            c.wr_bytes = 16
        return c
    bus = cfg.BUS_BYTES
    TM, TN, TK, KT = cfg.TM, cfg.TN, cfg.TK, cfg.KT
    # per (n0, k0) B beats do not depend on m0: compute once per column of tiles
    for m0 in range(0, d.M, TM):
        mv = min(TM, d.M - m0)
        for n0 in range(0, d.N, TN):
            nv = min(TN, d.N - n0)
            for k0 in range(0, d.K, KT):
                kv = min(KT, d.K - k0)
                c.ktiles += 1
                c.steps += ceil(kv / TK)
                for r in range(mv):
                    c.a_beats += nbeats(d.a + (m0 + r) * d.lda + k0, kv, bus)
                c.rd_bytes += mv * kv
                if d.trans_b:
                    for j in range(nv):
                        c.b_beats += nbeats(d.b + (n0 + j) * d.ldb + k0, kv, bus)
                else:
                    for kk in range(kv):
                        c.b_beats += nbeats(d.b + (k0 + kk) * d.ldb + n0, nv, bus)
                c.rd_bytes += kv * nv
            c.tiles += 1
            for r in range(mv):
                ca = d.c + ((m0 + r) * d.ldc + n0) * 4
                nb = nbeats(ca, 4 * nv, bus)
                if d.accum:
                    c.cin_beats += nb
                    c.rd_bytes += 4 * nv
                c.c_beats += nb
                c.wr_bytes += 4 * nv
    c.rd_beats = c.a_beats + c.b_beats + c.cin_beats
    c.wr_beats = c.c_beats
    if cpl_ok(d):
        c.wr_beats += nbeats(d.cpl, 16, bus)
        c.wr_bytes += 16
    c.macs = d.M * d.N * d.K
    return c


def compulsory_bytes(d: Desc) -> int:
    """Bytes any implementation must move: each A, B element once, each C word
    written once (and read once in accumulate mode)."""
    return d.M * d.K + d.K * d.N + 4 * d.M * d.N * (2 if d.accum else 1)


def lower_bound_cycles(cfg: Cfg, d: Desc, cnt: Counters, throttle: int = 1) -> int:
    """A bound no schedule can beat on the shared one-request-per-cycle port:
    every MAC-array step needs a cycle, every beat needs an acceptance slot,
    and acceptances are at least `throttle` cycles apart."""
    if cnt.mem_beats == 0:
        return 1
    return max(cnt.steps, (cnt.mem_beats - 1) * max(1, throttle) + 1)
