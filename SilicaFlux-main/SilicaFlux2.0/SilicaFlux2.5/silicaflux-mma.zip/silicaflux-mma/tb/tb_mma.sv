// =============================================================================
// tb_mma.sv -- self-checking testbench for sf_mma_top
//
//   model/gen_tests.py --> <dir>/init.hex, exp.hex, jobs.txt
//                              |
//   TB: loads the memory image, then for every job programs the CSRs exactly as
//   GPU-core software would, starts it, optionally interrupts it (abort, reset,
//   START-while-busy, descriptor rewrite while busy), waits for completion by
//   polling STATUS, by the interrupt line or by polling the completion record in
//   memory, and checks:
//
//   * completion code is one of the allowed codes for that job
//   * OK      : every C element equals the Python reference (exp.hex)
//     not OK  : every C element is either its pre-job value or the reference
//               value (32-bit element granularity -- never torn, never wrong)
//   * no byte outside the job's C elements / completion record changed
//     (checked per write beat as it happens AND over the whole memory after
//     the job); the GPU stand-in's region matches its shadow at the end
//   * when the accelerator drops busy, nothing it issued is still outstanding
//     in memory (completion implies visibility, and nothing is left in flight)
//   * performance counters (beats, bytes, MACs, tiles) equal the Python traffic
//     model; OVF_COUNT equals the reference; CYC >= analytic lower bound
//   * completion record contents, irq level, STATUS bits, ERR_ADDR on errors
//   * protocol: request payload stable while valid && !ready, beat alignment,
//     non-empty write strobes; the DUT's own ownership checks (chk_fail)
//
// Plusargs: +DIR=<test dir>  +VERBOSE=1
// Prints METRIC lines (one per job) and finally "TB_RESULT: PASS" or "TB_RESULT: FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_mma;
  parameter int TM        = 8;
  parameter int TN        = 8;
  parameter int TK        = 1;
  parameter int KT        = 32;
  parameter int BUS_BYTES = 16;
  parameter int IN_BUFS   = 2;
  parameter int OUT_BUFS  = 2;
  parameter int ACC_W     = 32;
  parameter int RD_OUT    = 16;
  parameter int WR_OUT    = 8;
  parameter int DIM_W     = 20;
  parameter int MEM_BYTES = 2 << 20;
  parameter int GPU_BYTES = 1 << 16;

  localparam int BW      = BUS_BYTES * 8;
  localparam int NF      = 44;
  localparam int MAXJ    = 1024;
  localparam int GPU_LO  = MEM_BYTES - GPU_BYTES;

  // field indices of a job line
  localparam int F_A = 0, F_B = 1, F_C = 2, F_CPL = 3, F_M = 4, F_N = 5, F_K = 6, F_LDA = 7, F_LDB = 8, F_LDC = 9;
  localparam int F_FLAGS = 10, F_TAG = 11, F_CMASK = 12, F_OVF = 13, F_RDB = 14, F_WRB = 15, F_MACL = 16, F_MACH = 17;
  localparam int F_RDBY = 18, F_WRBY = 19, F_TILES = 20, F_KTILES = 21, F_CHKC = 22, F_ACT = 23, F_ACT_AT = 24;
  localparam int F_LAT = 25, F_WLAT = 26, F_JIT = 27, F_PRD = 28, F_PWR = 29, F_THR = 30, F_STP = 31, F_STL = 32;
  localparam int F_GPU = 33, F_ERLO = 34, F_ERHI = 35, F_EWLO = 36, F_EWHI = 37, F_POLL = 38, F_SEED = 39;
  localparam int F_METRIC = 40, F_MAXC = 41, F_LB = 42;

  // ---------------------------------------------------------------- clock / reset
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ---------------------------------------------------------------- DUT
  logic        csr_valid = 1'b0, csr_write = 1'b0;
  logic [7:0]  csr_addr  = '0;
  logic [31:0] csr_wdata = '0;
  wire         csr_ready, csr_rvalid, irq, busy, chk_fail;
  wire  [31:0] csr_rdata;
  wire         rd_req_valid, rd_req_ready, rd_rsp_valid, rd_rsp_ready, rd_rsp_err;
  wire  [31:0] rd_req_addr;
  wire  [BW-1:0] rd_rsp_data;
  wire         wr_req_valid, wr_req_ready, wr_rsp_valid, wr_rsp_ready, wr_rsp_err;
  wire  [31:0] wr_req_addr;
  wire  [BW-1:0] wr_req_data;
  wire  [BUS_BYTES-1:0] wr_req_strb;

  sf_mma_top #(
    .TM(TM), .TN(TN), .TK(TK), .KT(KT), .BUS_BYTES(BUS_BYTES), .IN_BUFS(IN_BUFS), .OUT_BUFS(OUT_BUFS),
    .ACC_W(ACC_W), .RD_OUT(RD_OUT), .WR_OUT(WR_OUT), .DIM_W(DIM_W)
  ) dut (
    .clk, .rst_n,
    .csr_valid, .csr_ready, .csr_write, .csr_addr, .csr_wdata, .csr_rvalid, .csr_rdata, .irq, .busy,
    .rd_req_valid, .rd_req_ready, .rd_req_addr, .rd_rsp_valid, .rd_rsp_ready, .rd_rsp_data, .rd_rsp_err,
    .wr_req_valid, .wr_req_ready, .wr_req_addr, .wr_req_data, .wr_req_strb, .wr_rsp_valid, .wr_rsp_ready, .wr_rsp_err,
    .chk_fail
  );

  tb_mem #(.BUS_BYTES(BUS_BYTES), .MEM_BYTES(MEM_BYTES), .GPU_BYTES(GPU_BYTES)) mem (
    .clk, .rst_n,
    .rd_req_valid, .rd_req_ready, .rd_req_addr, .rd_rsp_valid, .rd_rsp_ready, .rd_rsp_data, .rd_rsp_err,
    .wr_req_valid, .wr_req_ready, .wr_req_addr, .wr_req_data, .wr_req_strb, .wr_rsp_valid, .wr_rsp_ready, .wr_rsp_err
  );

  // ---------------------------------------------------------------- bookkeeping
  int unsigned errors = 0, checks = 0;
  int          verbose = 0;
  string       dir;

  logic [7:0]  init_img [MEM_BYTES];
  logic [7:0]  exp_img  [MEM_BYTES];
  logic [7:0]  pre_img  [MEM_BYTES];
  shortint unsigned cm_tag [MEM_BYTES];     // job number (1-based, mod 65535) owning a C byte
  logic [31:0] jf [MAXJ][NF];
  int          njobs = 0;

  // state shared with the monitors
  shortint unsigned cur_tag = 0;
  logic [31:0] cur_cpl = 0;
  bit          cur_cpl_ok = 0;
  bit          job_active = 0;

  task automatic fail(input string msg);
    errors++;
    if (errors <= 40) $display("[%0t] ERROR: %s", $time, msg);
  endtask

  function automatic logic [7:0] bg(input int unsigned a);
    logic [31:0] h;
    h = a * 32'h9E37_79B1;
    return h[18:11];
  endfunction

  // ---------------------------------------------------------------- CSR access (GPU-core MMIO)
  task automatic csr_wr(input logic [7:0] a, input logic [31:0] d);
    @(negedge clk); csr_valid = 1'b1; csr_write = 1'b1; csr_addr = a; csr_wdata = d;
    @(negedge clk); csr_valid = 1'b0; csr_write = 1'b0;
  endtask

  task automatic csr_rd(input logic [7:0] a, output logic [31:0] d);
    @(negedge clk); csr_valid = 1'b1; csr_write = 1'b0; csr_addr = a;
    @(negedge clk); csr_valid = 1'b0;
    if (!csr_rvalid) fail($sformatf("csr_rvalid missing for read of 0x%02h", a));
    d = csr_rdata;
  endtask

  task automatic expect_csr(input logic [7:0] a, input logic [31:0] e, input string what);
    logic [31:0] v;
    csr_rd(a, v);
    checks++;
    if (v !== e) fail($sformatf("%s: CSR 0x%02h = 0x%08h, expected 0x%08h", what, a, v, e));
  endtask

  // ---------------------------------------------------------------- monitors
  logic        p_rv, p_wv, p_busy;
  logic [31:0] p_ra, p_wa;
  logic [BW-1:0] p_wd;
  logic [BUS_BYTES-1:0] p_ws;
  initial begin p_rv = 0; p_wv = 0; p_busy = 0; p_ra = 0; p_wa = 0; p_wd = 0; p_ws = 0; end

  always @(posedge clk) begin
    if (rst_n) begin
      // payload stable while valid && !ready
      if (p_rv && !rd_req_valid) fail("rd_req_valid withdrawn before ready");
      if (p_rv && rd_req_valid && rd_req_addr !== p_ra) fail("rd_req_addr changed while waiting for ready");
      if (p_wv && !wr_req_valid) fail("wr_req_valid withdrawn before ready");
      if (p_wv && wr_req_valid && (wr_req_addr !== p_wa || wr_req_data !== p_wd || wr_req_strb !== p_ws))
        fail("write payload changed while waiting for ready");
      if (rd_req_valid && (rd_req_addr % BUS_BYTES) != 0) fail($sformatf("unaligned read beat 0x%08h", rd_req_addr));
      if (wr_req_valid && (wr_req_addr % BUS_BYTES) != 0) fail($sformatf("unaligned write beat 0x%08h", wr_req_addr));
      if (wr_req_valid && wr_req_strb == '0) fail("write beat with empty strobe");
      if (!busy && (rd_req_valid || wr_req_valid)) fail("memory request while not busy");
      if (irq && busy) fail("irq asserted while busy");
      if (chk_fail) fail("DUT internal check failed (chk_fail)");
      // every written byte must belong to the current job's C elements or completion record
      if (wr_req_valid && wr_req_ready) begin
        for (int j = 0; j < BUS_BYTES; j++)
          if (wr_req_strb[j]) begin
            logic [31:0] a;
            bit ok;
            a  = wr_req_addr + 32'(j);
            ok = (a < MEM_BYTES) && (cm_tag[a] == cur_tag) && job_active;
            if (cur_cpl_ok && a >= cur_cpl && a < cur_cpl + 16) ok = 1;
            if (!ok) fail($sformatf("stray write to 0x%08h (beat 0x%08h, job tag %0d)", a, wr_req_addr, cur_tag));
          end
      end
      // busy -> idle: nothing may still be outstanding
      if (p_busy && !busy && mem.outstanding() != 0)
        fail($sformatf("completion reported with %0d transactions outstanding", mem.outstanding()));
    end
    p_rv <= rd_req_valid && !rd_req_ready;  p_ra <= rd_req_addr;
    p_wv <= wr_req_valid && !wr_req_ready;  p_wa <= wr_req_addr; p_wd <= wr_req_data; p_ws <= wr_req_strb;
    p_busy <= busy && rst_n;
  end

  // ---------------------------------------------------------------- helpers
  task automatic do_reset(input int len);
    @(negedge clk); rst_n = 1'b0;
    repeat (len) @(negedge clk);
    rst_n = 1'b1;
    @(negedge clk);
  endtask

  task automatic program_desc(input int j);
    csr_wr(sf_mma_pkg::CSR_A_BASE,   jf[j][F_A]);
    csr_wr(sf_mma_pkg::CSR_B_BASE,   jf[j][F_B]);
    csr_wr(sf_mma_pkg::CSR_C_BASE,   jf[j][F_C]);
    csr_wr(sf_mma_pkg::CSR_CPL_ADDR, jf[j][F_CPL]);
    csr_wr(sf_mma_pkg::CSR_M,        jf[j][F_M]);
    csr_wr(sf_mma_pkg::CSR_N,        jf[j][F_N]);
    csr_wr(sf_mma_pkg::CSR_K,        jf[j][F_K]);
    csr_wr(sf_mma_pkg::CSR_LDA,      jf[j][F_LDA]);
    csr_wr(sf_mma_pkg::CSR_LDB,      jf[j][F_LDB]);
    csr_wr(sf_mma_pkg::CSR_LDC,      jf[j][F_LDC]);
    csr_wr(sf_mma_pkg::CSR_FLAGS,    jf[j][F_FLAGS]);
    csr_wr(sf_mma_pkg::CSR_TAG,      jf[j][F_TAG]);
  endtask

  function automatic logic [31:0] exp32(input logic [31:0] a);
    return {exp_img[a+3], exp_img[a+2], exp_img[a+1], exp_img[a]};
  endfunction
  function automatic logic [31:0] pre32(input logic [31:0] a);
    return {pre_img[a+3], pre_img[a+2], pre_img[a+1], pre_img[a]};
  endfunction
  function automatic logic [31:0] mem32(input logic [31:0] a);
    return {mem.m[a+3], mem.m[a+2], mem.m[a+1], mem.m[a]};
  endfunction

  // mark / test the C elements of job j (only when the descriptor is in range)
  function automatic bit c_marks_ok(input int j);
    logic [63:0] end_a;
    if (jf[j][F_M] == 0 || jf[j][F_N] == 0) return 0;
    if (jf[j][F_M] > 65535 || jf[j][F_N] > 65535 || jf[j][F_LDC] > 1048575) return 0;
    end_a = 64'(jf[j][F_C]) + 64'd4 * (64'(jf[j][F_M] - 1) * 64'(jf[j][F_LDC]) + 64'(jf[j][F_N]));
    return (end_a <= 64'(GPU_LO)) && (jf[j][F_LDC] >= jf[j][F_N]);
  endfunction

  // ---------------------------------------------------------------- one job
  task automatic run_job(input int j);
    logic [31:0] st, v, flags, code, ovf_csr, dcyc_csr;
    logic [31:0] cnt [32];
    longint unsigned t0, maxc;
    bit irq_en, cpl_en, accum, was_reset, finished, act_done;
    int poll, act, act_at, nbad, nold;
    flags  = jf[j][F_FLAGS];
    irq_en = flags[sf_mma_pkg::F_IRQ_EN];
    cpl_en = flags[sf_mma_pkg::F_CPL_EN];
    accum  = flags[sf_mma_pkg::F_ACCUM];
    poll   = int'(jf[j][F_POLL]);
    act    = int'(jf[j][F_ACT]);
    act_at = int'(jf[j][F_ACT_AT]);
    maxc   = longint'(jf[j][F_MAXC]);
    was_reset = 0;

    // memory behaviour for this job
    mem.lat = int'(jf[j][F_LAT]);   mem.wlat = int'(jf[j][F_WLAT]); mem.jitter = int'(jf[j][F_JIT]);
    mem.p_rd = int'(jf[j][F_PRD]);  mem.p_wr = int'(jf[j][F_PWR]);  mem.throttle = int'(jf[j][F_THR]);
    mem.stall_period = int'(jf[j][F_STP]); mem.stall_len = int'(jf[j][F_STL]); mem.gpu_pct = int'(jf[j][F_GPU]);
    mem.err_rd_lo = jf[j][F_ERLO]; mem.err_rd_hi = jf[j][F_ERHI];
    mem.err_wr_lo = jf[j][F_EWLO]; mem.err_wr_hi = jf[j][F_EWHI];
    mem.rng = {jf[j][F_SEED], 32'h9E37_79B9} ^ 64'h5DEE_CE66_D1CE_4E5B;
    mem.n_rd_err = 0; mem.n_wr_err = 0;

    // snapshot memory, mark the C elements this job may write
    for (int a = 0; a < MEM_BYTES; a++) pre_img[a] = mem.m[a];
    cur_tag = 16'((j % 65534) + 1);
    if (c_marks_ok(j))
      for (int m = 0; m < int'(jf[j][F_M]); m++)
        for (int n = 0; n < int'(jf[j][F_N]); n++)
          for (int b = 0; b < 4; b++)
            cm_tag[jf[j][F_C] + 32'd4 * (32'(m) * jf[j][F_LDC] + 32'(n)) + 32'(b)] = cur_tag;
    cur_cpl    = jf[j][F_CPL];
    cur_cpl_ok = cpl_en && (jf[j][F_CPL][3:0] == 4'h0) && (64'(jf[j][F_CPL]) + 16 <= 64'(MEM_BYTES));

    program_desc(j);
    job_active = 1;
    csr_wr(sf_mma_pkg::CSR_CTRL, 32'h1 << sf_mma_pkg::CTRL_START);
    t0 = cyc;
    act_done = (act == 0);
    finished = 0;

    while (!finished) begin
      if (!act_done && cyc >= t0 + longint'(act_at)) begin
        act_done = 1;
        case (act)
          1: csr_wr(sf_mma_pkg::CSR_CTRL, 32'h1 << sf_mma_pkg::CTRL_ABORT);
          2: begin
               do_reset(3);
               was_reset = 1;
               finished  = 1;
             end
          3: begin
               csr_rd(sf_mma_pkg::CSR_STATUS, st);
               if (st[sf_mma_pkg::ST_BUSY]) begin
                 csr_wr(sf_mma_pkg::CSR_CTRL, 32'h1 << sf_mma_pkg::CTRL_START);
                 csr_rd(sf_mma_pkg::CSR_STATUS, st);
                 checks++;
                 if (!st[sf_mma_pkg::ST_REJECTED]) fail("START while busy was not flagged as rejected");
               end
             end
          4: begin   // rewrite the shadow descriptor while the job runs: must not disturb it
               csr_wr(sf_mma_pkg::CSR_A_BASE, 32'hFFFF_FFF0);
               csr_wr(sf_mma_pkg::CSR_B_BASE, 32'h0);
               csr_wr(sf_mma_pkg::CSR_C_BASE, 32'h3);
               csr_wr(sf_mma_pkg::CSR_M, 32'd1);
               csr_wr(sf_mma_pkg::CSR_K, 32'd7);
               csr_wr(sf_mma_pkg::CSR_FLAGS, 32'h0);
             end
          default: ;
        endcase
      end
      if (finished) break;
      if (poll == 1) begin
        @(negedge clk);
        if (irq) finished = 1;
      end else if (poll == 2) begin
        // a GPU warp polling the completion record (status word = last 4 bytes)
        @(negedge clk);
        if (mem.m[jf[j][F_CPL] + 15][7]) begin
          // the record is visible: every C element must already be final
          if (c_marks_ok(j))
            for (int m = 0; m < int'(jf[j][F_M]); m++)
              for (int n = 0; n < int'(jf[j][F_N]); n++) begin
                logic [31:0] a;
                a = jf[j][F_C] + 32'd4 * (32'(m) * jf[j][F_LDC] + 32'(n));
                checks++;
                if (mem32(a) !== exp32(a))
                  fail($sformatf("job %0d: completion record visible before C[%0d][%0d] was written", j, m, n));
              end
          do begin csr_rd(sf_mma_pkg::CSR_STATUS, st); end while (st[sf_mma_pkg::ST_BUSY]);
          finished = 1;
        end
      end else begin
        repeat (6) @(negedge clk);
        csr_rd(sf_mma_pkg::CSR_STATUS, st);
        if (st[sf_mma_pkg::ST_DONE]) finished = 1;
      end
      if (!finished && cyc > t0 + maxc) begin
        fail($sformatf("job %0d: timeout after %0d cycles (busy=%0d)", j, cyc - t0, busy));
        do_reset(3);
        was_reset = 1;
        finished = 1;
      end
    end
    job_active = 0;

    if (was_reset) begin
      // after reset: idle, all CSRs at their reset values, no irq
      checks++;
      if (busy || irq) fail("busy/irq after reset");
      expect_csr(sf_mma_pkg::CSR_STATUS, 32'h0, "STATUS after reset");
      expect_csr(sf_mma_pkg::CSR_A_BASE, 32'h0, "A_BASE after reset");
      expect_csr(sf_mma_pkg::CSR_M,      32'h0, "M after reset");
      expect_csr(sf_mma_pkg::CSR_CYC,    32'h0, "CYC after reset");
      expect_csr(sf_mma_pkg::CSR_RD_BEATS, 32'h0, "RD_BEATS after reset");
      code = 32'hFFFF_FFFF;
    end else begin
      csr_rd(sf_mma_pkg::CSR_STATUS, st);
      code = 32'(st[11:8]);
      checks++;
      if (!st[sf_mma_pkg::ST_DONE] || st[sf_mma_pkg::ST_BUSY]) fail($sformatf("job %0d: STATUS 0x%08h not DONE/idle", j, st));
      if (!jf[j][F_CMASK][code[3:0]]) fail($sformatf("job %0d: completion code %0d not allowed (mask 0x%04h)", j, code, jf[j][F_CMASK]));
      if (st[sf_mma_pkg::ST_IRQ] !== irq_en || irq !== irq_en) fail($sformatf("job %0d: irq=%0d STATUS.IRQ=%0d, IRQ_EN=%0d", j, irq, st[2], irq_en));
      if (act == 4) expect_csr(sf_mma_pkg::CSR_A_BASE, 32'hFFFF_FFF0, "shadow descriptor read-back");
      // counters
      csr_rd(sf_mma_pkg::CSR_CYC,      cnt[0]);  csr_rd(sf_mma_pkg::CSR_DCYC,     cnt[1]);
      csr_rd(sf_mma_pkg::CSR_ACTIVE,   cnt[2]);  csr_rd(sf_mma_pkg::CSR_MACS_LO,  cnt[3]);
      csr_rd(sf_mma_pkg::CSR_MACS_HI,  cnt[4]);  csr_rd(sf_mma_pkg::CSR_RD_BEATS, cnt[5]);
      csr_rd(sf_mma_pkg::CSR_WR_BEATS, cnt[6]);  csr_rd(sf_mma_pkg::CSR_RD_BYTES, cnt[7]);
      csr_rd(sf_mma_pkg::CSR_WR_BYTES, cnt[8]);  csr_rd(sf_mma_pkg::CSR_ST_LOAD,  cnt[9]);
      csr_rd(sf_mma_pkg::CSR_ST_STORE, cnt[10]); csr_rd(sf_mma_pkg::CSR_RD_BP,    cnt[11]);
      csr_rd(sf_mma_pkg::CSR_WR_BP,    cnt[12]); csr_rd(sf_mma_pkg::CSR_LD_WAIT,  cnt[13]);
      csr_rd(sf_mma_pkg::CSR_RD_CRED,  cnt[14]); csr_rd(sf_mma_pkg::CSR_TILES,    cnt[15]);
      csr_rd(sf_mma_pkg::CSR_KTILES,   cnt[16]); csr_rd(sf_mma_pkg::CSR_OVF_CNT,  cnt[17]);
      csr_rd(sf_mma_pkg::CSR_ERR_ADDR, cnt[18]); csr_rd(sf_mma_pkg::CSR_SPURIOUS, cnt[19]);
      ovf_csr = cnt[17]; dcyc_csr = cnt[1];
      checks++;
      if (cnt[19] != 0) fail("spurious memory responses counted");
      if (code == sf_mma_pkg::ERR_NONE) begin
        if (ovf_csr != jf[j][F_OVF]) fail($sformatf("job %0d: OVF_COUNT %0d, expected %0d", j, ovf_csr, jf[j][F_OVF]));
        if (st[sf_mma_pkg::ST_OVF] !== (jf[j][F_OVF] != 0)) fail($sformatf("job %0d: STATUS.OVF wrong", j));
        if (jf[j][F_CHKC] != 0) begin
          if (cnt[5]  != jf[j][F_RDB])   fail($sformatf("job %0d: RD_BEATS %0d, model %0d", j, cnt[5], jf[j][F_RDB]));
          if (cnt[6]  != jf[j][F_WRB])   fail($sformatf("job %0d: WR_BEATS %0d, model %0d", j, cnt[6], jf[j][F_WRB]));
          if (cnt[3]  != jf[j][F_MACL] || cnt[4] != jf[j][F_MACH]) fail($sformatf("job %0d: MACS %0d, model %0d", j, cnt[3], jf[j][F_MACL]));
          if (cnt[7]  != jf[j][F_RDBY])  fail($sformatf("job %0d: RD_BYTES %0d, model %0d", j, cnt[7], jf[j][F_RDBY]));
          if (cnt[8]  != jf[j][F_WRBY])  fail($sformatf("job %0d: WR_BYTES %0d, model %0d", j, cnt[8], jf[j][F_WRBY]));
          if (cnt[15] != jf[j][F_TILES]) fail($sformatf("job %0d: TILES %0d, model %0d", j, cnt[15], jf[j][F_TILES]));
          if (cnt[16] != jf[j][F_KTILES]) fail($sformatf("job %0d: KTILES %0d, model %0d", j, cnt[16], jf[j][F_KTILES]));
          if (cnt[0] < jf[j][F_LB])      fail($sformatf("job %0d: CYC %0d below the analytic lower bound %0d", j, cnt[0], jf[j][F_LB]));
          if (cnt[0] < cnt[2] || cnt[1] > cnt[0]) fail($sformatf("job %0d: inconsistent cycle counters", j));
        end
      end
      if (code == sf_mma_pkg::ERR_RD) begin
        if (!(cnt[18] + BUS_BYTES > jf[j][F_ERLO] && cnt[18] < jf[j][F_ERHI])) fail($sformatf("job %0d: ERR_ADDR 0x%08h outside the read-error window", j, cnt[18]));
        if (cnt[18] != mem.first_rd_err) fail($sformatf("job %0d: ERR_ADDR 0x%08h, first erroring beat 0x%08h", j, cnt[18], mem.first_rd_err));
      end
      if (code == sf_mma_pkg::ERR_WR) begin
        if (cnt[18] != mem.first_wr_err) fail($sformatf("job %0d: ERR_ADDR 0x%08h, first erroring write 0x%08h", j, cnt[18], mem.first_wr_err));
      end
      if (code >= sf_mma_pkg::ERR_DIM && code <= sf_mma_pkg::ERR_ALIAS) begin
        if (cnt[5] != 0) fail($sformatf("job %0d: rejected descriptor issued %0d reads", j, cnt[5]));
      end
      // completion record
      if (cur_cpl_ok) begin
        logic [31:0] w3, w2, w1, w0;
        w0 = mem32(cur_cpl); w1 = mem32(cur_cpl + 4); w2 = mem32(cur_cpl + 8); w3 = mem32(cur_cpl + 12);
        checks++;
        if (code != sf_mma_pkg::ERR_WR || mem.n_wr_err == 0) begin
          if (w3 !== (32'h8000_0000 | (32'(ovf_csr != 0) << 8) | code)) fail($sformatf("job %0d: record status 0x%08h", j, w3));
          if (w2 !== jf[j][F_TAG]) fail($sformatf("job %0d: record tag 0x%08h", j, w2));
          if (w1 !== ovf_csr) fail($sformatf("job %0d: record ovf %0d vs CSR %0d", j, w1, ovf_csr));
          if (w0 !== dcyc_csr) fail($sformatf("job %0d: record cycles %0d vs DCYC %0d", j, w0, dcyc_csr));
        end
      end
      if (jf[j][F_METRIC] != 0)
        $display("METRIC job=%0d code=%0d cyc=%0d dcyc=%0d active=%0d macs=%0d rd_beats=%0d wr_beats=%0d rd_bytes=%0d wr_bytes=%0d st_load=%0d st_store=%0d rd_bp=%0d wr_bp=%0d ld_wait=%0d rd_cred=%0d tiles=%0d ktiles=%0d ovf=%0d gpu_ops=%0d",
                 j, code, cnt[0], cnt[1], cnt[2], {cnt[4], cnt[3]}, cnt[5], cnt[6], cnt[7], cnt[8], cnt[9], cnt[10],
                 cnt[11], cnt[12], cnt[13], cnt[14], cnt[15], cnt[16], cnt[17], mem.gpu_ops);
    end

    // ---- C elements: exact when OK, otherwise old-or-new per 32-bit element
    nbad = 0; nold = 0;
    if (c_marks_ok(j))
      for (int m = 0; m < int'(jf[j][F_M]); m++)
        for (int n = 0; n < int'(jf[j][F_N]); n++) begin
          logic [31:0] a, got, e, o;
          a   = jf[j][F_C] + 32'd4 * (32'(m) * jf[j][F_LDC] + 32'(n));
          got = mem32(a); e = exp32(a); o = pre32(a);
          checks++;
          if (code == sf_mma_pkg::ERR_NONE) begin
            if (got !== e) begin
              nbad++;
              if (nbad <= 5) fail($sformatf("job %0d: C[%0d][%0d] @0x%08h = 0x%08h, expected 0x%08h", j, m, n, a, got, e));
            end
          end else if (got !== e) begin
            if (got === o) nold++;
            else begin
              nbad++;
              if (nbad <= 5) fail($sformatf("job %0d (code %0d): C[%0d][%0d] @0x%08h = 0x%08h, neither old 0x%08h nor new 0x%08h", j, code, m, n, a, got, o, e));
            end
          end
        end
    if (nbad > 5) fail($sformatf("job %0d: %0d wrong C elements in total", j, nbad));

    // ---- nothing else changed
    nbad = 0;
    for (int a = 0; a < GPU_LO; a++) begin
      bit allowed;
      allowed = (cm_tag[a] == cur_tag) || (cur_cpl_ok && 32'(a) >= cur_cpl && 32'(a) < cur_cpl + 16);
      if (!allowed && mem.m[a] !== pre_img[a]) begin
        nbad++;
        if (nbad <= 3) fail($sformatf("job %0d: byte 0x%08h changed from 0x%02h to 0x%02h", j, a, pre_img[a], mem.m[a]));
      end
    end

    if (verbose != 0 || errors != 0)
      $display("job %0d: M=%0d N=%0d K=%0d flags=0x%02h act=%0d code=%0d %s (old elements left: %0d) errors so far %0d",
               j, jf[j][F_M], jf[j][F_N], jf[j][F_K], flags, act, code, was_reset ? "[reset]" : "", nold, errors);

    if (!was_reset) begin
      csr_wr(sf_mma_pkg::CSR_CTRL, 32'h1 << sf_mma_pkg::CTRL_CLEAR);
      @(negedge clk);
      checks++;
      if (irq) fail("irq still asserted after CTRL.CLEAR");
      csr_rd(sf_mma_pkg::CSR_STATUS, st);
      if (st[sf_mma_pkg::ST_DONE] || st[sf_mma_pkg::ST_REJECTED]) fail("DONE/REJECTED not cleared by CTRL.CLEAR");
    end
    // clear error windows so they cannot leak into the next job
    mem.err_rd_lo = 0; mem.err_rd_hi = 0; mem.err_wr_lo = 0; mem.err_wr_hi = 0;
    mem.gpu_pct = 0;
  endtask

  // ---------------------------------------------------------------- main
  initial begin
    int fd, r;
    logic [31:0] v;
    if (!$value$plusargs("DIR=%s", dir)) $fatal(1, "+DIR=<test directory> required");
    void'($value$plusargs("VERBOSE=%d", verbose));

    for (int a = 0; a < MEM_BYTES; a++) begin init_img[a] = bg(a); cm_tag[a] = 0; end
    $readmemh({dir, "/init.hex"}, init_img);
    for (int a = 0; a < MEM_BYTES; a++) exp_img[a] = init_img[a];
    $readmemh({dir, "/exp.hex"}, exp_img);
    for (int a = 0; a < MEM_BYTES; a++) mem.m[a] = init_img[a];
    mem.sync_gpu_shadow();

    fd = $fopen({dir, "/jobs.txt"}, "r");
    if (fd == 0) $fatal(1, "cannot open %s/jobs.txt", dir);
    while (njobs < MAXJ) begin
      int f;
      for (f = 0; f < NF; f++) begin
        r = $fscanf(fd, "%h", v);
        if (r != 1) break;
        jf[njobs][f] = v;
      end
      if (f < NF) break;
      njobs++;
    end
    $fclose(fd);
    $display("tb_mma: %0d jobs from %s  (TM=%0d TN=%0d TK=%0d KT=%0d BUS=%0d IN_BUFS=%0d OUT_BUFS=%0d ACC_W=%0d RD_OUT=%0d WR_OUT=%0d)",
             njobs, dir, TM, TN, TK, KT, BUS_BYTES, IN_BUFS, OUT_BUFS, ACC_W, RD_OUT, WR_OUT);

    do_reset(5);
    // identification / configuration registers
    expect_csr(sf_mma_pkg::CSR_ID,      sf_mma_pkg::ID_VALUE, "ID");
    expect_csr(sf_mma_pkg::CSR_VERSION, sf_mma_pkg::VERSION_VALUE, "VERSION");
    expect_csr(sf_mma_pkg::CSR_CFG0, {8'(BUS_BYTES), 8'(TK), 8'(TN), 8'(TM)}, "CFG0");
    expect_csr(sf_mma_pkg::CSR_CFG1, {8'(ACC_W), 4'(OUT_BUFS), 4'(IN_BUFS), 16'(KT)}, "CFG1");
    expect_csr(sf_mma_pkg::CSR_CFG3, {8'(DIM_W), 8'(WR_OUT), 16'(RD_OUT)}, "CFG3");
    expect_csr(sf_mma_pkg::CSR_STATUS, 32'h0, "STATUS after reset");

    for (int j = 0; j < njobs; j++) run_job(j);

    // the GPU stand-in's region must be exactly what the GPU stand-in wrote
    checks++;
    r = mem.gpu_region_mismatches();
    if (r != 0) fail($sformatf("GPU region: %0d bytes differ from the GPU shadow", r));
    if (mem.gpu_bad != 0) fail($sformatf("GPU stand-in read %0d wrong bytes", mem.gpu_bad));

    $display("tb_mma: %0d jobs, %0d checks, %0d errors, %0d cycles, gpu_ops=%0d", njobs, checks, errors, cyc, mem.gpu_ops);
    if (errors == 0) $display("TB_RESULT: PASS");
    else             $display("TB_RESULT: FAIL");
    $finish;
  end

endmodule

`default_nettype wire
