// =============================================================================
// tb_mem.sv -- behavioural byte-addressed memory for the SF-MMA testbench
//
//  * one memory port shared by three requesters: the accelerator's read
//    channel, its write channel and a GPU-core stand-in.  At most ONE request is
//    accepted per cycle (round-robin among the requesters that want a slot), so
//    reads, writes and GPU traffic compete for the same bandwidth.
//  * knobs (set by the testbench per job, all deterministic given `seed`):
//      lat / wlat      read latency / write-response latency (cycles)
//      jitter          extra 0..jitter cycles per request (responses stay in order)
//      p_rd / p_wr     % of cycles in which the read / write channel may be accepted
//      throttle        at most one acceptance every `throttle` cycles (bandwidth cap)
//      stall_period/len  the memory freezes (no accept, no response) for `len`
//                      cycles out of every `period`
//      gpu_pct         % of cycles in which the GPU stand-in wants the port
//      err_rd_lo/hi, err_wr_lo/hi  beats overlapping [lo,hi) are answered with an
//                      error (an erroring write is not performed)
//  * reads take their data at acceptance; writes are performed at acceptance and
//    acknowledged later, in order.
//  * the GPU stand-in reads and writes 4-byte words in [MEM_BYTES-GPU_BYTES,
//    MEM_BYTES) and checks every read against its own shadow copy.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_mem #(
  parameter int BUS_BYTES = 16,
  parameter int MEM_BYTES = 1 << 20,
  parameter int GPU_BYTES = 1 << 16,
  parameter int QMAX      = 256
)(
  input  logic                   clk,
  input  logic                   rst_n,
  input  logic                   rd_req_valid,
  output logic                   rd_req_ready,
  input  logic [31:0]            rd_req_addr,
  output logic                   rd_rsp_valid,
  input  logic                   rd_rsp_ready,
  output logic [BUS_BYTES*8-1:0] rd_rsp_data,
  output logic                   rd_rsp_err,
  input  logic                   wr_req_valid,
  output logic                   wr_req_ready,
  input  logic [31:0]            wr_req_addr,
  input  logic [BUS_BYTES*8-1:0] wr_req_data,
  input  logic [BUS_BYTES-1:0]   wr_req_strb,
  output logic                   wr_rsp_valid,
  input  logic                   wr_rsp_ready,
  output logic                   wr_rsp_err
);
  localparam int BW      = BUS_BYTES * 8;
  localparam int GPU_LO  = MEM_BYTES - GPU_BYTES;

  logic [7:0] m       [MEM_BYTES];
  logic [7:0] gshadow [GPU_BYTES];

  // ---------------------------------------------------------------- knobs
  int          lat = 8, wlat = 8, jitter = 0, p_rd = 100, p_wr = 100, throttle = 1;
  int          stall_period = 0, stall_len = 0, gpu_pct = 0;
  logic [31:0] err_rd_lo = 0, err_rd_hi = 0, err_wr_lo = 0, err_wr_hi = 0;
  logic [63:0] rng = 64'h0123_4567_89AB_CDEF;

  // ---------------------------------------------------------------- observations
  int unsigned n_rd_err = 0, n_wr_err = 0, gpu_ops = 0, gpu_bad = 0;
  logic [31:0] first_rd_err = 0, first_wr_err = 0;
  int unsigned n_rd_acc = 0, n_wr_acc = 0;

  typedef struct { logic [BW-1:0] data; logic err; longint unsigned t; } rd_ent_t;
  typedef struct { logic err; longint unsigned t; } wr_ent_t;
  rd_ent_t rq[$];
  wr_ent_t wq[$];
  int      rq_n = 0, wq_n = 0;

  longint unsigned now = 0, last_rd_t = 0, last_wr_t = 0, last_acc = 0;
  bit en_rd = 1, en_wr = 1, gpu_want = 0, gpu_is_wr = 0;
  int rr = 0;

  function automatic logic [63:0] xs64(input logic [63:0] s);
    logic [63:0] x;
    x = s; x = x ^ (x << 13); x = x ^ (x >> 7); x = x ^ (x << 17);
    return x;
  endfunction
  function automatic int unsigned draw();
    rng = xs64(rng);
    return rng[40:9];
  endfunction

  function automatic bit overlaps(input logic [31:0] a, input int n, input logic [31:0] lo, input logic [31:0] hi);
    return (hi > lo) && (64'(a) < 64'(hi)) && (64'(a) + 64'(n) > 64'(lo));
  endfunction

  // DUT transactions accepted but not yet answered
  function automatic int outstanding();
    return rq_n + wq_n;
  endfunction

  task automatic sync_gpu_shadow();
    for (int a = 0; a < GPU_BYTES; a++) gshadow[a] = m[GPU_LO + a];
  endtask

  function automatic int gpu_region_mismatches();
    int n; n = 0;
    for (int a = 0; a < GPU_BYTES; a++) if (m[GPU_LO + a] !== gshadow[a]) n++;
    return n;
  endfunction

  // ---------------------------------------------------------------- acceptance (combinational)
  logic stalled, thr_ok, c_rd, c_wr, c_g, g_grant;
  always_comb begin
    stalled = (stall_period > 0) && ((now % 64'(stall_period)) < 64'(stall_len));
    thr_ok  = (throttle <= 1) || (now - last_acc >= 64'(throttle)) || (last_acc == 0);
    c_rd = rst_n && !stalled && thr_ok && rd_req_valid && en_rd && (rq_n < QMAX);
    c_wr = rst_n && !stalled && thr_ok && wr_req_valid && en_wr && (wq_n < QMAX);
    c_g  = rst_n && !stalled && thr_ok && gpu_want;
    rd_req_ready = 1'b0; wr_req_ready = 1'b0; g_grant = 1'b0;
    case (rr)
      0:       if (c_rd) rd_req_ready = 1'b1; else if (c_wr) wr_req_ready = 1'b1; else if (c_g) g_grant = 1'b1;
      1:       if (c_wr) wr_req_ready = 1'b1; else if (c_g) g_grant = 1'b1; else if (c_rd) rd_req_ready = 1'b1;
      default: if (c_g) g_grant = 1'b1; else if (c_rd) rd_req_ready = 1'b1; else if (c_wr) wr_req_ready = 1'b1;
    endcase
  end

  // ---------------------------------------------------------------- sequential model
  always @(posedge clk) begin
    now <= now + 1;
    if (!rst_n) begin
      rq.delete(); wq.delete(); rq_n = 0; wq_n = 0;
      rd_rsp_valid <= 1'b0; wr_rsp_valid <= 1'b0; rd_rsp_err <= 1'b0; wr_rsp_err <= 1'b0;
      rd_rsp_data <= '0;
      last_rd_t = 0; last_wr_t = 0; last_acc = 0;
      en_rd = 1; en_wr = 1; gpu_want = 0;
    end else begin
      // 1. responses consumed in this cycle
      if (rd_rsp_valid && rd_rsp_ready) begin void'(rq.pop_front()); rq_n--; end
      if (wr_rsp_valid && wr_rsp_ready) begin void'(wq.pop_front()); wq_n--; end

      // 2. requests accepted in this cycle
      if (rd_req_valid && rd_req_ready) begin
        rd_ent_t e;
        longint unsigned t;
        e.err = overlaps(rd_req_addr, BUS_BYTES, err_rd_lo, err_rd_hi) || (64'(rd_req_addr) + BUS_BYTES > MEM_BYTES);
        for (int j = 0; j < BUS_BYTES; j++)
          e.data[j*8 +: 8] = e.err ? 8'(draw()) : m[rd_req_addr + 32'(j)];
        t = now + 64'(lat) + ((jitter > 0) ? 64'(draw() % (jitter + 1)) : 0);
        if (t <= last_rd_t) t = last_rd_t + 1;
        last_rd_t = t; e.t = t;
        rq.push_back(e); rq_n++;
        n_rd_acc++;
        if (e.err) begin if (n_rd_err == 0) first_rd_err = rd_req_addr; n_rd_err++; end
        last_acc = now;
      end
      if (wr_req_valid && wr_req_ready) begin
        wr_ent_t e;
        longint unsigned t;
        e.err = overlaps(wr_req_addr, BUS_BYTES, err_wr_lo, err_wr_hi) || (64'(wr_req_addr) + BUS_BYTES > MEM_BYTES);
        if (!e.err)
          for (int j = 0; j < BUS_BYTES; j++)
            if (wr_req_strb[j]) m[wr_req_addr + 32'(j)] = wr_req_data[j*8 +: 8];
        t = now + 64'(wlat) + ((jitter > 0) ? 64'(draw() % (jitter + 1)) : 0);
        if (t <= last_wr_t) t = last_wr_t + 1;
        last_wr_t = t; e.t = t;
        wq.push_back(e); wq_n++;
        n_wr_acc++;
        if (e.err) begin if (n_wr_err == 0) first_wr_err = wr_req_addr; n_wr_err++; end
        last_acc = now;
      end
      if (g_grant) begin
        int unsigned ga;
        ga = (draw() % (GPU_BYTES / 4)) * 4;
        if (gpu_is_wr) begin
          for (int j = 0; j < 4; j++) begin
            logic [7:0] v;
            v = 8'(draw());
            m[GPU_LO + ga + j] = v; gshadow[ga + j] = v;
          end
        end else begin
          for (int j = 0; j < 4; j++) if (m[GPU_LO + ga + j] !== gshadow[ga + j]) gpu_bad++;
        end
        gpu_ops++;
        last_acc = now;
      end
      if (rd_req_ready || wr_req_ready || g_grant) rr = (rr == 2) ? 0 : rr + 1;

      // 3. response outputs for the next cycle (heads of the in-order queues)
      begin
        bit st_next;
        st_next = (stall_period > 0) && (((now + 1) % 64'(stall_period)) < 64'(stall_len));
        if (rq_n > 0 && rq[0].t <= now + 1 && !st_next) begin
          rd_rsp_valid <= 1'b1; rd_rsp_data <= rq[0].data; rd_rsp_err <= rq[0].err;
        end else begin
          rd_rsp_valid <= 1'b0; rd_rsp_err <= 1'b0;
        end
        if (wq_n > 0 && wq[0].t <= now + 1 && !st_next) begin
          wr_rsp_valid <= 1'b1; wr_rsp_err <= wq[0].err;
        end else begin
          wr_rsp_valid <= 1'b0; wr_rsp_err <= 1'b0;
        end
      end

      // 4. permissions for the next cycle
      en_rd     = (p_rd >= 100) || ((draw() % 100) < p_rd);
      en_wr     = (p_wr >= 100) || ((draw() % 100) < p_wr);
      gpu_want  = (gpu_pct > 0) && ((draw() % 100) < gpu_pct);
      gpu_is_wr = (draw() % 2) == 1;
    end
  end

endmodule

`default_nettype wire
