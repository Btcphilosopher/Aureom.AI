# Verification

Everything here is **simulation** (Verilator 5.020, 2-state) plus lint and structural
checks (Verilator `-Wall`, Icarus 12 compile, Yosys 0.33 elaboration). There is no
formal proof, no gate-level simulation and no hardware run. Exact counts of the run
that produced this package are in `results/regression.md` and `results/mutation.md`.

## 1. Reference and stimulus

* **Numerical reference** -- `model/mma_ref.py`: exact int64 matrix product, then the
  documented C_in / overflow / wrap / saturate rules (NUMERICS.md). It contains no
  tiling and no accumulation order. An independent pure-Python implementation
  (`reference_scalar`) is cross-checked against it on 300 random cases incl. all
  extreme values (`model/test_model.py`, which also proves the K_MAX bound tight
  for every ACC_W in 16..32).
* **Traffic model** -- `model/traffic.py`: descriptor validation (same priority as the
  RTL) and the exact number of read/write beats, useful bytes, MACs, output tiles and
  k-tiles implied by the schedule, plus an analytic cycle lower bound.
* **Generator** -- `model/gen_tests.py`: places A, B, C and the completion record in a
  2 MiB image with random gaps, byte-misaligned bases and padded leading dimensions;
  untouched bytes carry a background pattern, so every gap is a canary. Every directed
  job states the completion code it is meant to produce, and generation fails if the
  descriptor does not validate to that code.

## 2. What is checked on every job (`tb/tb_mma.sv`)

| check | when |
|---|---|
| completion code is in the job's allowed set | always (abort: OK or ABORT; reset: n/a) |
| every C element equals the reference | code OK |
| every C element is its pre-job value **or** the reference value (32-bit granularity: never partial, never torn) | code not OK, and after a reset |
| no byte outside the job's C elements and completion record changed -- at every write beat (with address and time) **and** over the whole 2 MiB after the job | always |
| when `busy` falls, the memory model holds no outstanding transaction of the DUT | always |
| RD_BEATS, WR_BEATS, RD_BYTES, WR_BYTES, MACS (64-bit), TILES, KTILES equal the traffic model | code OK |
| OVF_CNT and STATUS.OVF equal the reference | code OK |
| CYC >= analytic lower bound; DCYC <= CYC; ACTIVE <= CYC | code OK |
| completion record: status word, tag, OVF count, cycles equal the CSRs | record enabled |
| record polling mode: when the status word is visible, all of C is already final | poll mode 2 |
| irq level equals FLAGS.IRQ_EN; irq and DONE cleared by CTRL.CLEAR | always |
| ERR_ADDR equals the first erroring beat seen by memory | ERR_RD / ERR_WR |
| a rejected descriptor issues no read | ERR_DIM .. ERR_ALIAS |
| START while busy sets REJECTED; descriptor rewrite while busy does not disturb the job and reads back | actions 3, 4 |
| after reset: busy = irq = 0, STATUS, descriptor registers and counters read 0 | reset jobs |
| payload stable while valid && !ready, valid never withdrawn, beats aligned, strobes non-empty, no request while idle | every cycle |
| the RTL's own ownership / accumulator-bound checks (`chk_fail`) | every cycle (unless built with SF_MMA_NO_CHECKS) |
| the GPU-core stand-in's region equals its shadow; its reads never saw foreign data | end of test |

## 3. Directed suite (every configuration)

| test | content |
|---|---|
| d01_tiny | 1x1x1, 1x1x2, 2x1x1, 1x2x1, K = TK+1, 2x3x5 |
| d02_full_tiles | exact multiples of TM/TN/KT, aligned, incl. transposed B |
| d03_negative | all-negative operands, negative x positive, all -1, mixed |
| d04_extremes | all -128 (largest product 2^14), -128 x 127 (most negative), 127 x 127, -128/127 checkerboard, random extremes, extremes accumulated onto 0 |
| d05_rectangular | 1 x (3TN+1), (3TM+1) x 1, deep K, 37x19x53, K = 4KT+1, 4TM x 2 |
| d06_partial_tiles | every combination of {0, 1, T-1} extra rows / columns / k (and K not a multiple of TK), both B layouts |
| d07_strides_alignment | random padding of LDA/LDB/LDC, all byte offsets of the bases, large pads |
| d08_accumulate | C += A*B in place with random C_in, transposed B, padded C, saturate flag without overflow |
| d09_overflow | C_in near +-2^(ACC_W-1): mixed, all-positive and all-negative overflow, wrap and saturate, both B layouts; C words with upper bits set (ACC_W < 32) |
| d10_k_limit, d10b | K = K_MAX with all -128 and with -128 x 127 (ACC_W = 32: K = 131 071, a 1x1 job of 4096 k-tiles); K = K_MAX+1 rejected |
| d11_bad_descriptors | M/N/K = 0, >= 2^DIM_W, K > K_LIMIT, LDA/LDB/LDC too small (both layouts), misaligned C and record, address wrap of A and C, C overlapping A, C overlapping B; then a valid job |
| d12_completion_modes | interrupt, polling STATUS, polling the record in memory (also under back-pressure), no irq/no record |
| d13_busy_interactions | START while busy, descriptor rewritten while busy |
| d14_memory_errors | read errors in A, transposed B, row-major B, C_in; write errors (plain and accumulate under back-pressure); clean jobs afterwards |
| d15_abort | aborts at 0, 5, 20, 40, 60, 80, 95 and 110 % of the job's estimated duration, accumulate and plain, two memory profiles |
| d16_reset | resets at 0, 30, 60, 90 % of the job, each followed by the identical job, which must be exact |
| d17_backpressure | random ready 50 % / 25 %+jitter+GPU traffic, 1500-cycle memory freezes, bandwidth cap, 40 % GPU co-traffic |
| d18_special_values | zero operands, B = identity, B = -identity (transposed), sparse operands |

**Random suite** (`suite_random`, 10 seeds x 3 tests x up to 24 jobs per configuration):
shapes small / medium / skinny / deep-K; data uniform / extremes / negative / sparse /
checkerboard; 30 % accumulate (half of them with C_in at the limits), 50 % saturate,
35 % transposed B, random padding and misalignment, every memory profile, record /
irq / STATUS polling; 6 % aborts and 3 % resets at random points, 4 % memory errors,
5 % descriptor rewrites while busy.

**Configurations**

| name | why |
|---|---|
| base | reference design point, double buffered in and out |
| sb, dbin, sb_iso | the single/partially double-buffered variants used in the comparison |
| odd | non-power-of-two array (3x5), TK = 2, KT = 6, 8-byte bus, ACC_W = 24, 3 reads / 2 writes in flight |
| acc20 | ACC_W = 20 (K_MAX = 31): overflow and K-limit cases with small matrices; 4-byte bus |
| wide | 32-byte bus, TK = 4, 3 operand banks, 24 reads in flight |
| tiny | 1x1x1 array, ACC_W = 16 (K_MAX = 1), one read and one write in flight |

## 4. Requested scenarios -> where they are tested

| scenario | tests |
|---|---|
| negative values | d03, d04, random (`neg`, `uniform`) |
| extreme operands | d04, d09, d10 (all -128, -128 x 127, 127 x 127, checkerboard, extremes in random) |
| rectangular matrices | d05, d06, random skinny/deep shapes |
| partial tiles | d06 (all tail combinations), d01, d05, random |
| interrupted transfers | d14 (read/write errors), d15 (aborts), d17 (1500-cycle freezes, 25 % ready), random |
| reset | d16 (4 points, each followed by an exact retry), random resets |
| DMA back-pressure | d17, random profiles, every `bp`/`heavy`/`slow`/`stall`/`gpu` job |
| completion reporting | d11 (record for rejected jobs), d12, record checked on every job with CPL_EN |
| operation alongside the GPU core | `gpu` and `heavy` profiles: GPU stand-in shares the port; its region is verified |

## 5. Mutation testing

`scripts/mutation.py` builds the RTL with each of 24 deliberate bugs (plus one
combined mutant) and runs the directed suite and two random tests of the relevant
configurations, once with the RTL checks and once with them compiled out
(`SF_MMA_NO_CHECKS`, so only the end-to-end checks of section 2 remain). Results:
`results/mutation.md`. **All 23 non-equivalent mutants are killed in both modes**, and the
unmutated design passes the same test sets. Two mutants are expected to survive and are
reported as such:

* `MUT_NO_POISON` (an erroring read beat does not poison its bank) is equivalent in
  this design: the beat that would complete the bank sets `stop` on the same edge,
  and nothing issues while stopped. The combined mutant `MUT_STOP_LATE+MUT_NO_POISON`
  shows the poison bit is what protects the result once `stop` can lag: it writes
  values that are neither old nor new and is killed.
* `MUT_STOP_LATE` alone only lets the job write more *correct* tiles before stopping,
  which the old-or-new contract allows.

## 6. Bugs found during development

| what | found by | fix |
|---|---|---|
| a descriptor rejected before RUN hung the job: the writer only accepted the completion-record request from its FIN/HALT states, not from IDLE | d11 timeouts | record accepted from IDLE/END too |
| after an abort, a bank left FULL was "issued" during the next job's one-cycle CHECK state; the step was discarded by job_start, but MACS over-counted by TM*TN*TK | exact counter check (d15, configs sb/odd) | array issues only while the job is RUN/DRAIN |
| testbench memory (1 MiB) smaller than the generator's layout (2 MiB) | first runs | TB parameter aligned |
| generator: a "C overlaps A" job was rejected as ALIGN first; leading-dimension and wrap tests did not fit K_LIMIT = 1 (tiny) | the generator's `expect=` assertion | descriptors made configuration-aware |
| the "end-to-end only" mutation mode still saw the RTL checker flag | review of the first mutation run | `chk_fail` compiled out with SF_MMA_NO_CHECKS; mutation re-run |

## 7. Limits

* Simulation with a behavioural memory: the protocol corner cases it does not produce
  (e.g. out-of-order responses) are excluded by contract, not tested.
* The GPU core is represented by a traffic generator that competes for the memory port
  and checks its own data; the SIMT RTL itself was not co-simulated.
* 2-state simulation; X-propagation is not examined. The RTL compiles in Icarus
  (4-state) but the testbench (queues, structs) was only run in Verilator.
* Random testing samples the space; the directed suite targets the corners. No formal
  proof of the ownership protocol was attempted (it is checked by assertions in every
  simulated cycle and by mutation).
* Performance and resource numbers are not validated against an FPGA or ASIC flow.
