# Integrating SF-MMA next to the SilicaFlux GPU core

SF-MMA is a **peer** of the programmable GPU core, not a functional unit inside its
pipeline. The SIMT control unit (`sfx_simt_ctrl`, `silicaflux-simt`) issues
instructions to a backend that lives outside it; SF-MMA attaches beside that backend:

```
          +----------------------------+        MMIO (32-bit CSR port)       +-----------+
          |  SilicaFlux GPU core       |------------------------------------->|  SF-MMA   |
          |  SIMT ctrl + backend (LSU) |<------------- irq (level) -----------|           |
          +-------------+--------------+                                      +-----+-----+
                        | LSU / cache traffic                       DMA rd/wr channels |
                        v                                                              v
                 +--------------------------- memory interconnect -------------------------+
                 |   arbitration between the core and SF-MMA (round-robin in the testbench) |
                 +----------------------------------+---------------------------------------+
                                                    v
                                                 memory
```

* The core (one thread of a kernel, the command processor or a host) writes a job
  descriptor into SF-MMA's CSRs and starts it; it continues with other work.
* SF-MMA reads A and B and reads/writes C through its own DMA master while the core
  keeps issuing its own memory traffic. The testbench models exactly this: a GPU-core
  stand-in competes for the same memory port in up to 40 % of cycles and checks that
  its own data is never disturbed.
* Completion is observed by interrupt, by polling `STATUS`, or by polling a
  completion record in memory with ordinary loads.

Nothing in the GPU core RTL has to change. What *is* required is listed in
section 6 (memory-system contract) and section 7 (software rules).

## 1. Files

`rtl/sf_mma_pkg.sv` (compile first), `sf_mma_loader.sv`, `sf_mma_rdport.sv`,
`sf_mma_opbuf.sv`, `sf_mma_array.sv`, `sf_mma_writer.sv`, `sf_mma_ctrl.sv`,
`sf_mma_top.sv` (top). SystemVerilog-2012, no interfaces/structs/classes; package
contains only localparams. Verilator 5.020 `-Wall` clean on six parameter sets;
compiles in Icarus 12; elaborates in Yosys 0.33. Single clock, synchronous active-low reset.

## 2. Ports of `sf_mma_top`

| signal | dir | description |
|---|---|---|
| `clk`, `rst_n` | in | clock; synchronous active-low reset |
| `csr_valid`, `csr_write`, `csr_addr[7:0]`, `csr_wdata[31:0]` | in | MMIO request (byte address, word aligned) |
| `csr_ready` | out | constant 1 (one access per cycle) |
| `csr_rvalid`, `csr_rdata[31:0]` | out | read data, exactly one cycle after the read request |
| `irq` | out | level: `STATUS.DONE && FLAGS.IRQ_EN`; cleared by `CTRL.CLEAR` or the next START |
| `busy` | out | a job is in progress |
| `rd_req_valid/ready`, `rd_req_addr[31:0]` | out/in/out | read beat request, `BUS_BYTES`-aligned |
| `rd_rsp_valid`, `rd_rsp_data`, `rd_rsp_err` | in | read beat response, **in request order** |
| `rd_rsp_ready` | out | constant 1 |
| `wr_req_valid/ready`, `wr_req_addr`, `wr_req_data`, `wr_req_strb` | out/in/out | write beat with byte strobes (never empty) |
| `wr_rsp_valid`, `wr_rsp_err` | in | write acknowledgement, in request order |
| `wr_rsp_ready` | out | constant 1 |
| `chk_fail` | out | simulation checker summary (always 0 in a correct design; leave open) |

Byte `j` of a beat is `data[8j+7:8j]` and lives at `addr + j` (little-endian).
Valid/ready: a request's payload is stable while `valid && !ready`; SF-MMA never
withdraws a presented request (also not on abort). Ready may depend on valid.

## 3. CSR map

| offset | name | access | content |
|---|---|---|---|
| 0x00 | ID | RO | 0x534D4D41 ("SMMA") |
| 0x04 | VERSION | RO | 0x00010000 |
| 0x08 | CFG0 | RO | TM[7:0], TN[15:8], TK[23:16], BUS_BYTES[31:24] |
| 0x0C | CFG1 | RO | KT[15:0], IN_BUFS[19:16], OUT_BUFS[23:20], ACC_W[31:24] |
| 0x10 | CFG2 | RO | K_LIMIT (largest accepted K) |
| 0x14 | CFG3 | RO | RD_OUT[15:0], WR_OUT[23:16], DIM_W[31:24] |
| 0x18 | CTRL | WO | bit0 START, bit1 ABORT, bit2 CLEAR (DONE, irq, REJECTED) |
| 0x1C | STATUS | RO | bit0 BUSY, bit1 DONE, bit2 IRQ, bit3 REJECTED, bit4 OVF, bit5 PROTO, [11:8] code |
| 0x20 | A_BASE | RW | byte address of A[0][0] (any alignment) |
| 0x24 | B_BASE | RW | byte address of B[0][0] (row-major) or B^T[0][0] (TRANS_B) |
| 0x28 | C_BASE | RW | byte address of C[0][0], 4-byte aligned |
| 0x2C | CPL_ADDR | RW | completion record address, 16-byte aligned (if CPL_EN) |
| 0x30..0x38 | M, N, K | RW | dimensions, 1 .. 2^DIM_W-1; K <= K_LIMIT |
| 0x3C | LDA | RW | A row stride in bytes (>= K) |
| 0x40 | LDB | RW | B row stride in bytes (>= N row-major, >= K transposed) |
| 0x44 | LDC | RW | C row stride in **elements** (>= N) |
| 0x48 | FLAGS | RW | bit0 ACCUM, bit1 SAT, bit2 TRANS_B, bit3 IRQ_EN, bit4 CPL_EN |
| 0x4C | TAG | RW | opaque, copied into the completion record |
| 0x50 | ERR_ADDR | RO | beat address of the first memory error of the last job |
| 0x54 | OVF_CNT | RO | overflowed C elements of the last job |
| 0x60..0xA4 | counters | RO | CYC, DCYC, ACTIVE, MACS_LO, MACS_HI, RD_BEATS, WR_BEATS, RD_BYTES, WR_BYTES, ST_LOAD, ST_STORE, RD_BP, WR_BP, LD_WAIT, RD_CRED, TILES, KTILES, SPURIOUS |

Codes: 0 OK, 1 DIM, 2 KMAX, 3 LD, 4 ALIGN, 5 RANGE, 6 ALIAS, 7 RD, 8 WR, 9 ABORT.

The descriptor registers (0x20-0x4C) are a **shadow**: START copies them, so the next
job may be written while the current one runs. START while BUSY is ignored and sets
`STATUS.REJECTED`. Reading the descriptor registers returns the shadow values.

## 4. Programming sequence (one thread of a GPU kernel, or a host)

```c
// clear the completion record (only needed when polling it)
store32(cpl + 12, 0);
mmio_write(A_BASE, a);  mmio_write(B_BASE, b);  mmio_write(C_BASE, c);  mmio_write(CPL_ADDR, cpl);
mmio_write(M, m);  mmio_write(N, n);  mmio_write(K, k);
mmio_write(LDA, lda);  mmio_write(LDB, ldb);  mmio_write(LDC, ldc);
mmio_write(FLAGS, CPL_EN | IRQ_EN | (accumulate ? ACCUM : 0) | (saturate ? SAT : 0));
mmio_write(TAG, job_id);
// make A, B (and C in accumulate mode) visible to memory before START (section 7)
fence_and_writeback(a, b, c);
mmio_write(CTRL, START);

// ... the GPU core keeps working ...

// completion, any one of:
//   (a) interrupt -> handler reads STATUS
//   (b) while (!(mmio_read(STATUS) & DONE)) ;
//   (c) while (!(load32(cpl + 12) & 0x80000000)) ;   // plain loads, works from any warp
status = mmio_read(STATUS);  code = (status >> 8) & 15;
invalidate(c);                       // drop stale cached copies of C before reading it
mmio_write(CTRL, CLEAR);
```

## 5. Completion semantics

DONE, the interrupt and the completion record all mean the same thing: **every C
write of the job has been acknowledged by memory** (and the record itself too). The
record's status word is written last (highest address; beats ascend), so a poller
that sees bit 31 set may read the other three words and all of C. The testbench checks
this directly in its record-polling mode: the moment the status word becomes visible,
every C element must already hold its final value.

## 6. Memory-system contract (what the interconnect must guarantee)

1. Read responses in request order; write acknowledgements in request order.
2. A write that has been acknowledged is visible to every later read from any master
   (the core included). If the core's L1 caches C, software must invalidate it after
   completion (SF-MMA is not cache coherent).
3. Error responses (`rd_rsp_err`, `wr_rsp_err`) for addresses that cannot be accessed;
   an erroring write must have no effect.
4. Every accepted request eventually gets a response (SF-MMA waits for all of them
   before completing, also on abort).
5. When SF-MMA is reset, its port must be reset or drained too (outstanding responses
   are no longer expected).

Ready/valid back-pressure of any duration is allowed on both request channels.

## 7. Software rules (what the GPU kernel / driver must guarantee)

* A, B (and C in accumulate mode) are in memory (written back from caches) before START,
  and nothing writes A, B or C while the job runs.
* C must not overlap A or B (checked: ERR_ALIAS); C_BASE 4-byte aligned; CPL_ADDR 16-byte aligned.
* After an error or abort, C contains a mix of old and new elements; in accumulate mode
  re-run from a saved copy.
* K <= `CFG2` (K_LIMIT). Longer reductions: split K into chunks and run them as
  accumulate-mode jobs (each chunk is bound-checked; see NUMERICS.md section 4 for the
  overflow rules of the running C).

## 8. Sharing the memory port with the core

SF-MMA issues at most one read and one write beat per cycle and holds at most
`RD_OUT` reads and `WR_OUT` writes in flight. Its sustained bandwidth demand on a
memory with read latency L is about `min(1, RD_OUT / L)` read beats per cycle; size
RD_OUT for the latency of your memory system (RESULTS.md section 5 shows the effect).
Any fair arbiter in front of memory works; the testbench uses round-robin among
{SF-MMA reads, SF-MMA writes, GPU core} with one acceptance per cycle in total,
and RESULTS.md reports SF-MMA's slowdown under 30 % GPU traffic (`shared` profile).

## 9. Bring-up checklist

1. Read ID, VERSION, CFG0-3 and check them against the parameters you built.
2. Run a 1x1x1 job with CPL_EN and check the record (tag, code 0).
3. Run a job with a deliberately bad descriptor (e.g. M = 0) and check code 1 and
   `RD_BEATS == 0`.
4. Compare C against `model/mma_ref.py` for a random job with misaligned bases.
5. Check `CSR_MACS == M*N*K` and the beat counters against `model/traffic.py`.
