# Numerical contract

This is the arithmetic SF-MMA implements, stated so that software can predict
every output bit. `model/mma_ref.py` is the executable form of this page; the
testbench compares every C element of every job against it.

## 1. Operands and products

* A (M x K) and B (K x N) are **signed 8-bit two's-complement** integers, range -128 .. 127.
  B is stored either row-major K x N (`FLAGS.TRANS_B = 0`) or as its transpose, N x K
  row-major (`FLAGS.TRANS_B = 1`); the arithmetic is the same.
* Every product is computed exactly. Its range is
  `(-128) * 127 = -16256  <=  a*b  <=  (-128) * (-128) = 16384 = 2^14`.
  (The asymmetric range of two's complement makes the largest *positive* product the
  one of two -128 operands; that case is exercised directly by the tests.)

## 2. Accumulator width and the accumulation-length bound

The accumulator is **ACC_W bits**, a synthesis parameter (16 .. 32, default 32;
at least 16 + clog2(TK) so that one step's TK-term partial sum fits).

The products of one output element are summed in that accumulator. Because
`|a*b| <= 2^14`, a sum of K products satisfies

```
-16256 * K  <=  sum  <=  16384 * K
```

and it is representable in ACC_W-bit two's complement for **every** operand value iff

```
16384 * K <= 2^(ACC_W-1) - 1        (the positive side binds; -16256*K is always the smaller magnitude)
<=>  K <= K_MAX(ACC_W) = 2^(ACC_W-15) - 1
```

| ACC_W | K_MAX | largest possible sum at K_MAX | ACC_W maximum |
|---|---|---|---|
| 16 | 1 | 16 384 | 32 767 |
| 20 | 31 | 507 904 | 524 287 |
| 24 | 511 | 8 372 224 | 8 388 607 |
| 32 | 131 071 | 2 147 467 264 | 2 147 483 647 |

The bound is **tight**: `(K_MAX + 1) * 16384 = 2^(ACC_W-1)`, one more than the largest
representable value, so K_MAX + 1 products of (-128)*(-128) would overflow.

**Supported accumulation lengths.** The controller accepts a job only if
`1 <= K <= K_LIMIT = min(K_MAX(ACC_W), 2^DIM_W - 1)` (131 071 for the default
ACC_W = 32, DIM_W = 20; readable in `CSR_CFG2`). Any larger K is rejected with
`ERR_KMAX` before any memory traffic. Consequently **the accumulator never overflows**
-- not for any operand values, not for any tiling, not for any accumulation order.
The RTL additionally checks this in simulation on every accumulate (sf_mma_array.sv,
`acc_ovf`), and the regression runs K = K_MAX with all operands -128 (ACC_W = 32:
K = 131 071, sum = 2 147 467 264) and with -128 x 127.

Long reductions beyond K_LIMIT are done by software as several jobs in accumulate
mode (section 3), each of which is again bound-checked; the overflow semantics of
section 4 then apply to the running C.

## 3. Output accumulation (C = C + A*B)

With `FLAGS.ACCUM = 1` the job updates C in place. For each element:

1. `C_in` = the **low ACC_W bits** of the 32-bit C word in memory, sign-extended
   (for ACC_W = 32 the whole word; for ACC_W < 32 the upper bits are ignored).
2. `S` = the exact sum of the K products (section 2; it is exact and `|S| < 2^(ACC_W-1)`).
3. `exact = S + C_in` is formed in **ACC_W + 1 bits**. It cannot overflow there, because
   `|S| <= 2^(ACC_W-1) - 2^14` and `-2^(ACC_W-1) <= C_in <= 2^(ACC_W-1) - 1`.

With `FLAGS.ACCUM = 0`, `exact = S` (the old C content is neither read nor used).

The hardware adds C_in once, at write-back, after the whole reduction. Since S is
exact, this equals adding C_in first and accumulating products onto it in any
order: **the result does not depend on TM, TN, TK, KT or the accumulation order.**

## 4. Overflow behaviour

An element **overflows** when `exact` lies outside `[-2^(ACC_W-1), 2^(ACC_W-1) - 1]`.
With K <= K_LIMIT this can only happen in accumulate mode (C_in close to a limit).
What is stored is selected per job:

| `FLAGS.SAT` | stored ACC_W-bit value | example, ACC_W = 32, exact = 2^31 + 5 |
|---|---|---|
| 0 (wrap) | `exact mod 2^ACC_W`, two's complement (the low ACC_W bits of exact) | -2^31 + 5 |
| 1 (saturate) | `2^(ACC_W-1) - 1` if exact is too large, `-2^(ACC_W-1)` if too small | 2^31 - 1 |

In both modes:
* the element is counted in `CSR_OVF_CNT` (and in word 1 of the completion record),
* `STATUS.OVF` is set when the count of the job is non-zero,
* the job still completes with `ERR_NONE` -- overflow is reported, not an error.

Both choices are pure functions of `exact`, so the stored value is deterministic and
order independent (a running saturating accumulator would not be).

## 5. Storage format of C

The ACC_W-bit result is **sign-extended to 32 bits** and stored little-endian at
`C_BASE + 4*(m*LDC + n)`. C_BASE must be 4-byte aligned. Bytes outside the M x N
elements -- in particular the `LDC - N` padding words of each row -- are never written.

## 6. Worked examples (all in the regression)

| case | A, B | C_in | ACC_W | K | result |
|---|---|---|---|---|---|
| largest exact sum | all -128 | -- | 32 | 131 071 | 2 147 467 264, no overflow |
| most negative sum | -128 x 127 | -- | 20 | 31 | -503 936 |
| positive overflow, wrap | all -128 | 2^31-1 | 32 | 32 | exact 2^31 - 1 + 2^19 wraps to -2^31 + 2^19 - 1, OVF counted |
| positive overflow, saturate | all -128 | 2^31-1 | 32 | 32 | 2^31 - 1, OVF counted |
| negative overflow, saturate | -128 x 127 | -2^31 | 32 | 32 | -2^31, OVF counted |
| upper C bits ignored | any | 0xFFF00005 | 20 | -- | C_in = 5 |
| K = K_MAX + 1 | -- | -- | any | -- | job rejected, ERR_KMAX, no traffic |
