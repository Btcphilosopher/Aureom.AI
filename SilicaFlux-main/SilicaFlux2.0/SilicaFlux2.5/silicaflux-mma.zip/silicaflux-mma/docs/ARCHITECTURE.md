# SF-MMA architecture

SF-MMA computes `C = A*B` or `C = C + A*B` for signed int8 A, B and an ACC_W-bit
result (arithmetic: [NUMERICS.md](NUMERICS.md)). It is a peer of the programmable
SilicaFlux GPU core: the core programs it through MMIO registers and both share the
memory port ([INTEGRATION.md](INTEGRATION.md)). This page describes how a job moves
through the hardware and why overlapping transfers with computation is safe.

```
              MMIO                                   memory port (one master, rd + wr channels)
                |                                          ^              ^
        +-------v--------+   job params, start, stop       |              |
        |  sf_mma_ctrl   |------------------+---------------+-----+        |
        | CSRs, checks,  |                  |               |     |        |
        | job FSM, perf  |          +-------v------+  +-----+-----v--+     |
        +----------------+          | sf_mma_loader|->| sf_mma_rdport|     |
                                    | A/B row beats|  | out reg, RD_OUT     |
                                    +------+-------+  | credits, FIFO |     |
                               claim bank  |          +--+------^-----+     |
                                    +------v------------v+     | C_in rows |
                                    |   sf_mma_opbuf     |     |           |
                                    | NB banks + owner FSM|    |           |
                                    +---------+----------+     |           |
                                      FULL bank|               |           |
                                    +---------v----------+   +-+-----------+--+
                                    |   sf_mma_array     |-->|  sf_mma_writer |
                                    | TM x TN x TK MACs, |   | C_in + acc,    |
                                    | acc, output buffer |<--| wrap/sat, beats|
                                    +--------------------+   | completion rec.|
                                                    release  +----------------+
```

## 1. Parameters

| parameter | default | meaning | constraint |
|---|---|---|---|
| `TM`, `TN` | 8, 8 | output tile = MAC array rows x columns | >= 1 |
| `TK` | 1 | k-elements each MAC lane consumes per cycle | >= 1 |
| `KT` | 32 | k-depth of one operand bank ("k-tile") | multiple of TK |
| `BUS_BYTES` | 16 | memory beat width | power of two, 4..128 |
| `IN_BUFS` | 2 | operand banks: 1 single, 2 double, 3-4 multi buffered | 1..4 |
| `OUT_BUFS` | 2 | 1: accumulators are the output buffer; 2: separate output buffer | 1..2 |
| `ACC_W` | 32 | accumulator width | 16 + clog2(TK) .. 32 |
| `RD_OUT` / `WR_OUT` | 16 / 8 | read / write beats in flight | >= 1 |
| `DIM_W` | 20 | width of M, N, K, LDA, LDB, LDC | 4..24 |

Peak MAC rate = TM x TN x TK per cycle (64 at the defaults) -- a capability, never an
achieved number; see [RESULTS.md](RESULTS.md) for achieved rates.

## 2. Schedule

All three engines walk the job in the same fixed order, so no tile identifiers
have to be passed between them:

```
for m0 in 0, TM, 2TM, .. < M:            # output-tile rows
  for n0 in 0, TN, 2TN, .. < N:          # output-tile columns
    for k0 in 0, KT, 2KT, .. < K:        # k-tiles: one operand bank each
      load  A[m0:m0+TM, k0:k0+KT], B[k0:k0+KT, n0:n0+TN] -> bank
      compute ceil(k_valid/TK) steps from that bank into the accumulators
    write C[m0:m0+TM, n0:n0+TN]          # (reading C_in first in accumulate mode)
```

This is output stationary: partial sums never leave the array until an output tile
is complete, so C is read at most once and written exactly once. The price is that
A is re-fetched for every column of output tiles and B for every row
(re-fetch factor in RESULTS.md); the bytes reported there are what this schedule
really moves.

## 3. Tile loading (`sf_mma_loader`)

For each k-tile the loader claims the next bank (section 5), then emits the rows of
the A tile and the B tile as memory beats:

| part | rows | row start address | valid bytes per row |
|---|---|---|---|
| A | m_valid = min(TM, M-m0) | `A_BASE + (m0+r)*LDA + k0` | k_valid = min(KT, K-k0) |
| B row-major | k_valid | `B_BASE + (k0+kk)*LDB + n0` | n_valid = min(TN, N-n0) |
| B transposed | n_valid | `B_BASE + (n0+j)*LDB + k0` | k_valid |

Addresses and leading dimensions are arbitrary byte values. A row of `len` bytes at
address `x` becomes the aligned beats `floor(x/BUS)*BUS .. floor((x+len-1)/BUS)*BUS`.
Each beat carries `(dst, bank, row, d = beat_addr - row_addr, len)` so that the read
port can deliver exactly the row's bytes (destination byte i <- beat byte i-d) and
drop neighbouring data. Row addresses are formed incrementally (adds only); the one
multiplication per tile row (`TM*LDA`) is by a constant.

## 4. Local operand storage (`sf_mma_opbuf`)

Each bank holds an A k-tile (TM x KT bytes) and a B k-tile (KT x TN bytes, stored
n-major as `bbuf[bank][n][k]` so that both B layouts land in the same place). One
bank is `(TM+TN)*KT` bytes: 512 B at the defaults.

Storage is **flip-flops**. A DMA beat writes part of one *row* of a tile while the
array reads one *k-column slice* (TM bytes of A, TN of B) per cycle -- a transposing
access that a single-ported SRAM macro cannot serve per cycle. An SRAM
implementation would store A k-major via a small transpose buffer, or require
pre-transposed A; that is outside this design and is why the resource numbers in
RESULTS.md are flip-flop heavy.

Banks are **not cleared** between k-tiles. Bytes beyond a partial tile's valid
region keep data from earlier tiles and are made harmless as described in section 8.

## 5. Double buffering and the ownership protocol

Overlap of transfers and computation is allowed **only through ownership**. Every
operand bank is in exactly one state, and exactly one agent may touch it:

```
            loader claims        all beats arrived,        first step
   FREE ------------------> LOADING ---- no error -----> FULL ------------> BUSY
    ^        (loader only)   (read responses only)        (array only)       |
    |                                                         |              |
    +------------------------- last step issued (array) ------+--------------+
```

| rule | where enforced |
|---|---|
| the loader claims a bank only when it is FREE, and only then emits its beats | `sf_mma_loader` (`bank_ok`) |
| read responses write a bank only while it is LOADING | `sf_mma_opbuf` (checked) |
| a bank becomes FULL only when every requested beat has arrived (`pending == 0` and all issued) and none returned an error | `sf_mma_opbuf` next-state logic |
| the array reads only FULL/BUSY banks, and releases a bank in the cycle its last step reads it | `sf_mma_array` (issue condition) |
| banks are claimed and consumed in the same round-robin order 0,1,..,NB-1 | loader `bank_inc`, array `cb_inc` |

With `IN_BUFS = 1` the single bank alternates between the loader and the array,
so loading and computing never overlap. With `IN_BUFS >= 2` the loader fills bank
b+1 while the array computes from bank b -- but it can never get ahead by more than
NB banks, and it never writes a bank the array may still read. A response beat for
a bank arrives only while that bank is LOADING (the loader issued it after claiming),
so no "late" data can land in a bank that has moved on.

The output side has the same discipline. The decision is made **when a step
issues**, so the 3-stage pipeline never has to stall:

* `OUT_BUFS = 2`: the last step of an output tile may issue only if the output buffer
  is neither FULL nor already reserved; it reserves it. Two cycles later the final sums
  land in the output buffer, which then belongs to the writer until it releases it.
  The first step of the next tile can issue the very next cycle.
* `OUT_BUFS = 1`: the accumulators are the output buffer. After the last step of
  tile t issues, the first step of tile t+1 (which would overwrite them) waits until
  the writer has released them.

All four rules are checked every cycle in simulation (`chk_fail`), and the mutation
tests `MUT_CLAIM_ANY`, `MUT_FULL_EARLY`, `MUT_OB1_NOLOCK`, `MUT_OB2_NORESV`,
`MUT_REL_EARLY`, `MUT_BANK_STUCK` show that breaking any of them is detected -- also
with the internal checks compiled out.

## 6. Compute scheduling (`sf_mma_array`)

```
 stage I : bank b = next in order, step s; issue if b is FULL/BUSY, output ownership allows,
           the job is running and not stopping. Read A[b][0..TM)[s*TK..+TK), B[b][..][0..TN),
           zero every k >= k_valid.
 stage M : TM x TN dot products of length TK: exact 16-bit products, PW = 16+clog2(TK) bit sums
 stage A : acc <= (first step of the tile ? 0 : acc) + psum;  last step -> output buffer / writer
```

One step per cycle when operands are present. The issue logic also classifies every
cycle of a running job in which the array does *not* issue: **load stall** (next bank
not yet FULL while loads are still expected) or **store stall** (bank ready, output
buffer still owned by the writer). These are the transfer-stall counters.

## 7. Output accumulation and write-back (`sf_mma_writer`)

The writer takes finished tiles in the same raster order and, per output row:

1. accumulate mode: requests the C_in row through the read port (higher priority than
   the loader -- it is holding an output buffer) and waits for all its beats;
2. forms `exact = acc + C_in` in ACC_W+1 bits, counts out-of-range elements, wraps or
   saturates (NUMERICS.md section 4), sign-extends to 32 bits;
3. writes the row with aligned beats whose byte strobes cover exactly the
   `n_valid` elements.

After the last beat of the tile's last row is accepted by memory, the output buffer
is released (the beats carry the data from then on). C_in is read and C written
row by row, so `C += A*B` in place has no read-after-write hazard.

## 8. Tail handling (M, N, K not multiples of TM, TN, KT, TK)

| dimension | mechanism |
|---|---|
| K tail (k_valid < KT, or not a multiple of TK) | only k_valid bytes per row are fetched; the array zeroes every operand with k >= k_valid before multiplying, so stale bank bytes never reach a product |
| M tail (m_valid < TM) | only m_valid A rows are fetched; accumulator rows >= m_valid hold garbage that is never written |
| N tail (n_valid < TN) | only n_valid B bytes/rows fetched; accumulator columns >= n_valid are never written; write strobes cover only n_valid elements |
| useful-work accounting | `CSR_MACS` adds m_valid x n_valid x (valid k of the step), so it equals M*N*K exactly |

The regression covers every combination of {0, 1, T-1} extra rows/columns/k in
each dimension, K < TK, K = 1, M = 1, N = 1, padded leading dimensions and all byte
alignments of the bases.

## 9. DMA and back-pressure

**Read channel** (`sf_mma_rdport`): one output register. Once `rd_req_valid` is
asserted, address and routing metadata stay stable until `rd_req_ready`; valid is
never withdrawn, not even on abort. At most `RD_OUT` beats are outstanding; their
metadata waits in an in-order FIFO. Memory must answer in request order.
`rd_rsp_ready` is constant 1 because buffer space is owned before a beat is requested
(bank claimed / C_in row reserved); flow control towards memory happens on the
request side instead.

**Write channel**: the writer presents one beat at a time, holds it stable until
accepted, keeps at most `WR_OUT` beats unacknowledged, and records their addresses
for error reporting. `wr_rsp_ready` is constant 1.

Back-pressure in either direction only delays: memory not accepting a request
(`rd_bp`, `wr_bp` counters), no free bank (`ld_wait`), outstanding limit reached
(`rd_cred`), operands not yet loaded (`st_load`), output buffer busy (`st_store`).
None of these drops or reorders work. The regression runs every job class with
random ready throttling (25-50 %), response jitter, 1500-cycle memory freezes,
a bandwidth cap and GPU co-traffic.

## 10. Errors, abort and reset

| event | behaviour |
|---|---|
| descriptor fault | detected in the CHECK state before any memory request; job completes with ERR_DIM/KMAX/LD/ALIGN/RANGE/ALIAS |
| read error response | bank (or C_in row) poisoned, never used; job stops with ERR_RD, `ERR_ADDR` = first erroring beat |
| write error response | job stops with ERR_WR, `ERR_ADDR` = first erroring beat |
| `CTRL.ABORT` | takes effect only in the RUN state: the job stops with ERR_ABORT. Once the writer has issued the last C beat the controller is in DRAIN and an ABORT is ignored; the job completes normally |
| reset (`rst_n` low) | everything returns to its reset state immediately (see contract below) |

**Stopping drains**: no new request is issued; a request already presented is
completed; every outstanding read and write response is awaited; only then is DONE
reported. Nothing is left in flight that could disturb the next job (checked by the
testbench at every busy -> idle transition).

**Guarantee for interrupted jobs**: every C element is either its value before the job
or its correct final value -- never a partial sum, never a torn word (each 4-byte
element lies inside one beat). Nothing outside the job's C elements and completion
record is written. This is checked element by element for every abort, error and
reset in the regression. In accumulate mode an interrupted job leaves a mix of updated
and not-updated elements; software must re-run from a saved copy of C.

**Reset contract**: `rst_n` is synchronous, active low, and clears all control state,
CSRs and counters (operand/accumulator data registers are not reset; they are never
read before being written). A reset abandons outstanding transactions, so the memory
interconnect port of the accelerator must be reset (or drained) together with it; use
`CTRL.ABORT` for a graceful stop.

## 11. Completion reporting

A job is **done** when the controller has seen every C write acknowledged and, if
enabled, the completion record written and acknowledged. Then `STATUS.DONE` is set,
`irq` rises if `FLAGS.IRQ_EN`, and the counters freeze. A reader that observes DONE,
the interrupt or the completion record is guaranteed to read the final C (assuming
the memory system makes acknowledged writes visible, see INTEGRATION.md).

The 16-byte completion record (16-byte aligned `CPL_ADDR`, `FLAGS.CPL_EN`):

| word | content |
|---|---|
| 0 | cycles from START to data complete (`CSR_DCYC`) |
| 1 | overflowed elements (`CSR_OVF_CNT`) |
| 2 | job tag (`CSR_TAG`) |
| 3 | `0x8000_0000 | OVF<<8 | code` -- written last (highest address, beats ascend) |

Software clears word 3 before START and polls bit 31. The record is written for every
outcome except an unusable record address (ERR_ALIGN/ERR_RANGE on CPL_ADDR itself).

## 12. Performance counters

Cleared by an accepted START, frozen at DONE, readable at any time:
`CYC, DCYC, ACTIVE, MACS (64-bit), RD_BEATS, WR_BEATS, RD_BYTES, WR_BYTES, ST_LOAD,
ST_STORE, RD_BP, WR_BP, LD_WAIT, RD_CRED, TILES, KTILES, SPURIOUS` (CSR map in
INTEGRATION.md). On every successful regression job the beat, byte, MAC, tile and
k-tile counters equal the Python traffic model exactly.

## 13. Known limitations

* Local storage is flip-flops (section 4); no SRAM macro mapping.
* One job at a time; no descriptor queue (the descriptor registers are a shadow copy,
  so the next job can be programmed while one runs).
* The descriptor checks treat regions as bounding intervals: a C that interleaves
  with A or B without touching it is still rejected (ERR_ALIAS).
* No reuse of A or B across output tiles (re-fetch factor > 1); a larger TM/TN or an
  A-panel buffer would reduce traffic.
* Memory must return read data in request order; there is no read reordering.
* No timing closure was attempted; the validation multipliers and the TK-term adder
  trees are single-cycle.
* Only signed int8 operands and integer accumulation; no other formats.
