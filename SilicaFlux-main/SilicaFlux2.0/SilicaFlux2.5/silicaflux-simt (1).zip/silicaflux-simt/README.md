# SilicaFlux SIMT Warp Scheduler and Control Unit

SystemVerilog front end of a single-issue SIMT core: resident-warp state, program counters,
ready/blocked states, register-dependency tracking, execution masks, branch divergence and
reconvergence (explicit `ssy`/`sync` stack), workgroup barriers, kernel completion, a deterministic
round-robin scheduler with an optional age-based policy, performance counters, assertions, and a
verification environment with two independent reference simulators.

**Read `docs/ARCHITECTURE.md` first** — it is the specification (divergence model, stack entries,
overflow/nesting limits, compiler contract, barrier semantics, invalid-barrier behaviour, downstream
contract and fairness assumptions, counter definitions, property list, limitations).

```
rtl/                       sf_simt_pkg  sf_simt_stack  sf_warp_arb  sf_simt_barrier  sf_simt_warp_ctx  sf_simt_ctrl (top)
tb/                        tb_simt (top) · sf_simt_dsm (downstream: IMEM+backend+memory, bounded random timing, injection)
                           sf_simt_checker (independent port-level checker, properties P1-P12)
model/                     sfisa.py (ISA, assembler)  sfref.py (MIMD truth + lock-step SIMT model)  sfgen.py (random legal programs)
tests/directed/*.s         hand-written programs      tests/directed_suite.py  (expectations per test/config/profile)
tests/test_isa_sync.py     keeps Python ISA/fault/counter tables identical to rtl/sf_simt_pkg.sv
scripts/                   regress_random.py  regress_all.py  xcheck_refs.py  mutation_test.py  sfrun.py
docs/ARCHITECTURE.md       specification
```

## Quick start

Requirements: Verilator ≥ 5 (`pip install verilator` works), `g++`, `make`, `perl`, Python 3 (standard library only).

```bash
make lint        # verilator -Wall on the RTL, three parameter sets
make refs        # cross-check the two reference simulators against each other
make directed    # 37 directed test cases x configs x timing profiles
make random      # random legal programs, RTL vs both references
make quick       # smoke regression      |  make regress   # full regression
make mutation    # inject 22 RTL defects into a copy of the RTL; every one must be caught (~15 min)
make zip         # package the project (without build products)
```

The first run of each hardware configuration verilates and compiles the testbench (1-3 minutes);
builds are cached in `build/` and keyed on the sources. `scripts/sfrun.py` passes the
`CFG_CXXFLAGS_PCH_I=-include` workaround needed by the `pip` Verilator build.

Hardware configurations (`scripts/sfrun.py: CONFIGS`): `rr8` (8 warps x 32 lanes, RR), `age8`
(age policy), `rr16w8` (16 warps x 8 lanes, stack 6, 2 slots), `age4` (4 warps, 3 slots),
`rr6` (6 warps — not a power of two, 16 lanes, stack 4). Timing profiles: `ideal`, `mid`, `slow`, `memhv`, `starve`.

## Design decisions in brief

* **Divergence.** Compiler-placed `ssy` (push reconvergence TOKEN) / `sync` (pop to the first entry
  that still holds live threads) with a per-warp stack of `{kind, pc, mask}`. Fall-through path first,
  deferred taken path on the stack: loops cost at most 2 stack entries. Overflow, underflow,
  divergence without a region and lost threads *fault* the workgroup instead of corrupting it; a
  launch whose declared `stack_need` exceeds the hardware depth is rejected.
* **Barriers** have no counters: a workgroup releases exactly when every member warp is in `W_BAR` or
  `W_DONE`. Exited warps (after draining their stores) do not participate; a divergent `bar` faults.
* **Dependency tracking** uses per-warp in-flight *slots*; the slot index is the completion tag, so
  duplicate, stale and wrong-context completions are dropped and flagged, never retired.
* **Scheduling.** RR is work conserving with a *monotonic pointer* (it never passes a candidate that was
  not granted), which gives a time bound of about `N*G+1` cycles under port-readiness assumption F2 — plain
  RR can phase-lock against per-port readiness. The age policy has an intrinsic `N-1` overtaking bound.
* **Counters.** issued, idle, dependency stalls, memory stalls, barrier waits (+ structural, front-end,
  ready-wait, branch/divergence/reconvergence, stack high-water mark, faults, releases, retired, drops).

## Verification summary

See §15 of the specification for the method. Each run compares, RTL against reference: all non-zero
registers, global/shared memory, fault status, the per-warp `(pc, mask)` issue trace and the counters.
The two references (per-thread MIMD and lock-step SIMT stack model) are first cross-checked against each
other. The always-on checker and inline RTL assertions run on every simulation.

### Results (final tree, clean build, all runs from scratch)

| Check | Result |
|---|---|
| Verilator `-Wall` lint, 3 parameter sets (default, 6 warps / 8 lanes / odd depths, 1 warp) | clean |
| Reference models cross-check (per-thread MIMD vs lock-step SIMT), 150 random programs, 593,669 warp-instructions | 0 mismatches |
| Directed suite: 37 test cases (30 programs) x 5 hardware configs x timing profiles = **444 runs** | 0 failures |
| Random legal programs, RTL vs both references: **980 programs** in 18 config/profile batches; 4,290,183 warp-instructions, 509,781 conditional branches (168,514 divergent), 11,320 barrier releases, 9.2 M RTL cycles | 0 failures |
| Mutation testing: 22 injected RTL defects | **22 killed, 0 survived** |

Hardware configurations run: RR and age policy, 4/6/8/16 warps, 8/16/32 lanes, stack depth 4-8, 2-4 in-flight slots.
Downstream timing profiles: `ideal` (1-cycle everything), `mid`, `slow`, `memhv` (60-cycle memory) and `starve`
(backend ports ready ~20% of cycles).

**One real defect found by the verification environment during development** (kept here because it shaped the design):
the first round-robin variant used an anti-starvation *promotion* counter and claimed an overtaking bound. The checker's
bounded-overtaking property failed on the 16-warp configuration under toggling port readiness — the claimed bound was
wrong (grants in cycles where a warp is not eligible can still move the pointer past it). The RTL matched its model
exactly; the *guarantee* was wrong. It was replaced by a monotonic-pointer round robin (the pointer never passes a
candidate that was not granted) with a provable time bound; see specification §7.1. The earlier mutation set also had
two mutants that were killed for a collateral reason; they were rewritten and a directed test
(`t34_barrier_drain_exit`) was added.


## What this is not

Simulation-only: no synthesis, timing or area numbers; no formal proofs (liveness is checked with
bounds and watchdogs under the stated fairness assumptions F1-F3); no warp-level operations, predication,
named barriers, stack spilling or multi-kernel residency. Full list: specification §16.
