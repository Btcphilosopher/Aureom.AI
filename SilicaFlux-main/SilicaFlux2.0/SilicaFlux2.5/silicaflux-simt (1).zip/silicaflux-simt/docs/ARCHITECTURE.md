# SilicaFlux SIMT Warp Scheduler and Control Unit — Architecture Specification

Status: implemented in `rtl/`, verified in simulation (Verilator) against two independent
reference simulators. Section 16 lists exactly what is *not* done or not proven.

Contents

1. Scope and block structure
2. Parameters
3. The SFT-1 instruction set (as seen by the control unit)
4. Execution model: threads, warps, workgroups, launch
5. Warp context: state, state machine
6. Fetch and issue: timeline
7. Scheduling policies and starvation freedom
8. Divergence and reconvergence
9. Register-dependency tracking and retirement
10. Workgroup barriers
11. Kernel launch, completion and faults
12. Interfaces and the downstream contract (fairness assumptions F1–F5)
13. Performance counters
14. Assertions and properties
15. Verification environment
16. Limitations and non-goals

---------------------------------------------------------------------------------------------

## 1. Scope and block structure

The unit is the front end of one single-issue SIMT core. It owns `NUM_WARPS` resident warp
contexts and decides, every cycle, which warp issues one instruction. It does **not** contain
the register file, ALUs, load/store unit or instruction memory — those are the *downstream*
(§12). Everything that decides *control* lives here: program counters, execution masks,
branch divergence and reconvergence, barriers, register-hazard tracking, scheduling, kernel
completion and the counters.

```
 launch/status ─▶ ┌────────────────────── sf_simt_ctrl ──────────────────────────────────┐
                  │  launch FSM        fetch arbiter (RR)                                │
                  │     │                   │ want_fetch                                 │
                  │     ▼                   ▼                                            │
                  │  ┌───────────────────────────────────────┐   cand/elig   ┌─────────┐ │
 IMEM ◀─ if_req ──┼──┤ sf_simt_warp_ctx x NUM_WARPS          ├──────────────▶│ sf_warp │ │
 IMEM ─▶ if_rsp ──┼─▶│  state, pc, active/live, ibuf,        │◀── grant ─────┤  _arb   │ │
                  │  │  slots+scoreboard, reconv. stack      │               │ RR | AGE│ │
 backend ◀─ iss ──┼──┤  (sf_simt_stack)                      │               └─────────┘ │
 backend ─▶ cmpl ─┼─▶│                                       │                           │
                  │  └──────────────┬────────────────────────┘                           │
                  │       warp states │ bar_release          perf counters, wg-kill       │
                  │           ┌──────▼───────┐                                           │
                  │           │ sf_simt_barrier │  (stateless: derived from warp states) │
                  └───────────┴──────────────┴───────────────────────────────────────────┘
```

| Module | Role |
|---|---|
| `sf_simt_pkg` | ISA opcodes, classes, state/fault/class enums, `sf_predecode`, counter indices |
| `sf_simt_warp_ctx` | One warp context: FSM, PC, masks, ibuf, slot table, scoreboard, all control-flow semantics |
| `sf_simt_stack` | Per-warp reconvergence stack with the “first live entry” search |
| `sf_warp_arb` | Issue arbiter: round robin with a monotonic pointer, or age matrix |
| `sf_simt_barrier` | Workgroup barrier release (pure function of warp states) |
| `sf_simt_ctrl` | Top: launch FSM, fetch arbiter, issue bus mux, completion routing, workgroup kill, counters |

## 2. Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `NUM_WARPS` | 8 | resident warp contexts (any value ≥ 1; powers of two are cheapest) |
| `WARP_SIZE` | 32 | threads (lanes) per warp = execution-mask width |
| `PC_W` | 16 | program-counter width in instruction words |
| `STACK_DEPTH` | 8 | reconvergence-stack entries **per warp** |
| `NUM_SLOTS` | 4 | in-flight backend instructions per warp (§9) |
| `POLICY` | 0 | 0 = round robin (`SF_POLICY_RR`), 1 = age based (`SF_POLICY_AGE`) |
| `PERF_W` | 32 | counter width (saturating) |

## 3. The SFT-1 instruction set

32-bit words, SilicaFlux field layout: `[31:27] op | [26:22] rd | [21:17] rs1 | [16:12] rs2 | [11:0] imm12`.
I-form instructions use `[16:0]` as a signed `imm17`. 32 registers per thread, `r0` reads as zero
and ignores writes. PCs are word addresses. All encodings are defined by `model/sfisa.py`
(single source of truth) and mirrored by `rtl/sf_simt_pkg.sv`.

| Op | Mnemonic | Class | Semantics |
|---|---|---|---|
| 00 | `nop` | local | — |
| 01 | `exit` | local | active threads terminate (§8.4) |
| 02 | `ssy off` | local | push TOKEN{pc+1+off, active} (§8.3) |
| 03 | `sync` | local | reconverge: pop to the first entry that still holds live threads |
| 04 | `bar` | local | workgroup barrier arrival (§10) |
| 05 | `jmp off` | local | warp-uniform `pc = pc+1+off` |
| 06 / 07 | `bnz rs1,off` / `bz rs1,off` | branch | per thread: taken if `rs1 != 0` / `rs1 == 0`; target `pc+1+off` |
| 08–12 | `add sub mul and or xor shl shr sar slt sltu` | ALU | `rd = rs1 op rs2` (shift amount `rs2[4:0]`, `slt` signed) |
| 13 | `addi rd,rs1,imm17` | ALU | `rd = rs1 + sext(imm17)` |
| 14 | `lui rd,imm17` | ALU | `rd = imm17 << 15` |
| 15 | `s2r rd,id` | ALU | special register: 0 lane, 1 tid, 2 ntid, 3 wgid, 4 nwg, 5 widx, 6 gtid, 7 warpid |
| 18 / 19 | `ldg rd,[rs1+simm12]` / `stg rs2,[rs1+simm12]` | load / store | global memory (word addressed, address wraps) |
| 1A / 1B | `lds` / `sts` | load / store | per-workgroup shared memory |

Anything else is an *illegal instruction* and faults when it reaches issue (§11.3).

*Local* instructions never leave the control unit; they still consume the issue slot and count
as issued. *ALU/branch* instructions use backend port 0, *load/store* use port 1.
`bnz/bz` are the only instructions whose result (a per-thread taken mask) comes back to the
control unit.

Special registers: `tid = widx*WARP_SIZE + lane`; `ntid = (wpw-1)*WARP_SIZE + last` where `last`
is the thread count of the last warp; `gtid = wgid*wpw*WARP_SIZE + tid`; `warpid = wgid*wpw + widx`.

## 4. Execution model

* A **thread** is one lane of a warp. A **warp** is `WARP_SIZE` threads that share a PC and
  execute in lock step under an *active mask*. A **workgroup** is `wpw` consecutive warps that
  share a barrier and the shared-memory scratchpad. `NUM_WARPS` bounds `num_wg * wpw`.
* A kernel is launched with `{entry_pc, num_wg, warps_per_wg, last_threads, stack_need}`.
  `last_threads` (0 = full) is the number of threads in the *last* warp of each workgroup, so
  thread counts that are not a multiple of `WARP_SIZE` are expressed by partially populated
  warps whose initial `active = live = (1<<last_threads)-1`. Non-existent lanes never execute,
  never contribute to a branch and never write.
* Only one kernel is resident at a time. Registers are zero at launch (backend duty); global
  memory persists across launches.
* **Architectural semantics are defined per thread.** For race-free programs that obey the
  compiler contract of §8.5, the result of lock-step masked execution is *identical* to each
  thread executing the program independently with a private return stack for `ssy`/`sync`.
  The per-thread model is the specification (`model/sfref.py: run_mimd`), the stack of §8 is
  one implementation, and the two are cross-checked on every random test.

## 5. Warp context

Registered per warp: `state, pc, active, live, ibuf (valid + decoded instruction), fetch_pending,
br_target, wg, widx, fault cause, slot table (valid/wr/mem/br/rd × NUM_SLOTS), pend, pendm`, plus
the reconvergence stack.

| State | Meaning | Leaves when |
|---|---|---|
| `W_FREE` | context not owned by a kernel | launch sequencer activates it |
| `W_RUN` | resident; fetching and issuing | `bnz/bz` issued → BRW; `bar` → BAR; last thread exits, a fault or a workgroup kill → DRAIN |
| `W_BRW` | conditional branch issued, waiting for its taken mask | the branch slot retires → RUN (or fault → DRAIN) |
| `W_BAR` | arrived at the workgroup barrier | barrier release → RUN |
| `W_DRAIN` | no live threads; waiting for in-flight work and an outstanding fetch to finish | slot table empty and no fetch pending → DONE |
| `W_DONE` | fully retired, owns nothing; counts as “exited” for barriers | kernel completion → FREE |

Derived (combinational) eligibility inside `W_RUN`, with `ibuf` valid:

* **candidate** = no RAW/WAW hazard, a free in-flight slot (if backend-bound), and — for `bar` —
  no in-flight operations of this warp (barrier is an implicit memory fence);
* **eligible** = candidate and the backend port it needs is ready this cycle.

A candidate stays a candidate until it is granted or its workgroup is killed (hazards can only be
removed by completions; new hazards are created only by the warp's own issues).

Per-cycle **warp class** (exactly one per resident warp, exported as `warp_class_o`):
`ISSUED` (won the slot), `READY` (eligible, lost arbitration), `DEP`, `MEM`, `STRUCT`, `FRONT`
(waiting for fetch or branch resolution), `BAR`, `DRAIN`, `DONE`, `FREE`.

## 6. Fetch and issue timeline

There is no speculative fetch. A warp in `W_RUN` with an empty instruction buffer and no
outstanding fetch requests exactly the instruction at its current PC. The fetch arbiter is a
plain round-robin over those warps (all candidates see the same IMEM readiness, so each is
reached within `NUM_WARPS` grants). The response must echo `{warp, pc}`; the buffer is filled
only if the warp is `W_RUN`, a fetch is pending and the pc matches.

Minimum timeline with 1-cycle instruction memory and a 1-cycle backend (cycle `t` = issue):

| Cycle | Event |
|---|---|
| `t` | grant; control-unit state updates at the end of `t`; backend samples operands at the issue handshake |
| `t+1` | ibuf is empty → fetch request |
| `t+2` | fetch response |
| `t+3` | ibuf valid → candidate; if granted, this is the warp's next issue (single-warp CPI = 3) |
| `t+1` | earliest cycle a completion is *presented* |
| `t+2` | scoreboard bit visible cleared → dependent instruction eligible (issue-to-use ≥ 2) |

Latency is hidden by multithreading: with ≥ 3 resident warps a 1-cycle backend sustains 1 IPC.
Completion is *registered* into the scoreboard (no completion-to-issue bypass): this keeps the
completion network off the arbitration critical path at the cost of one cycle.

## 7. Scheduling policies and starvation freedom

`grant` is one-hot or zero, always a subset of `elig`, and non-zero whenever anything is eligible (work
conserving). The policy is selected by `POLICY`. Both are fully deterministic: grants depend only on
registered arbiter state and the candidate/eligible vectors, and the state is re-initialised at every kernel
launch.

### 7.1 Round robin (default, `POLICY=0`): the pointer never passes a waiting candidate

Scan the warps cyclically from `ptr`. The **winner** is the first *eligible* warp. If a candidate that is
*not* eligible (it is hazard-free but its backend port is busy this cycle) lies before the winner in scan
order, the **first such blocked candidate** is remembered. After a grant:

```
ptr  <-  blocked candidate (if one exists)   else   winner + 1
```
If nothing is eligible, `ptr` holds. The pointer therefore **never moves past a candidate that has not been
granted** (assertion A6, and exact grant model P2).

*Why not “ptr = winner + 1” always?* That loose round robin can starve: a warp that needs the memory port
may find that port ready only in cycles where the pointer has just moved past it, while always-ready ALU warps
keep the pointer moving. Readiness of one port is correlated with another warp's grants, so “infinitely often
ready” is not enough for loose RR. (A first version of this design patched the problem with an
anti-starvation *promotion* counter; the checker's bounded-overtaking property then exposed that promotion
gives no worst-case guarantee when eligibility toggles, because grants in the cycles where the warp is
*not* eligible can still move the pointer past it. It was replaced by the monotonic pointer.)

**Bound.** Let `G` be the maximum number of cycles between two cycles in which a given backend port is ready
(downstream assumption F2). Let `w` be a candidate with `d ≤ N−1` warps between `ptr` and `w`.
1. The pointer never passes `w`, and a pointer position is left only by a grant to the warp it sits on (it
   is the first in scan order, so it wins as soon as its port is ready — within `G` cycles) or by skipping
   non-candidates. So each of the at most `N−1` positions in front of `w` costs at most `G` cycles.
2. Once the pointer reaches `w`, `w` is first in scan order and is granted at its port's next ready cycle
   (≤ `G`).

Hence a candidate is granted within about `N·G + 1` cycles, independent of the readiness pattern. The checker
asserts the generous form `(N+2)(G+1)+4` cycles (P4) and the exact grant model (P2).
The number of grants to *other* warps in that time is not bounded by `N−1` (warps after a parked pointer
keep issuing); the guarantee is in time, which is what starvation freedom needs.

### 7.2 Age based (`POLICY=1`)

`older[j][i]` = “warp `j` last issued before warp `i`” — a strict total order held in an
`N×N` matrix (reset: lower id older). The oldest eligible warp wins and becomes the youngest.
This is oldest-first by *time since last issue*, equivalent to an LRU list.

**Bound.** While a warp is eligible it is overtaken at most `NUM_WARPS−1` times, *independent of how
backend readiness behaves*: a warp `g` can only overtake `w` if `g` is older, and after its grant `g`
is younger than `w` until `w` itself issues; this holds across eligibility toggling because the relative
order only changes at grants. (P3 checks the count, P4 the time bound.) Greedy-then-oldest is intentionally
not provided: it needs an explicit anti-starvation cap, whereas this order has an intrinsic bound.

Trade-off between the two: RR is the simplest to reason about and has a pointer-based time bound; AGE gives
the tighter, readiness-independent overtaking bound and favours warps that have waited longest (it is
the better latency-fairness policy when warps stall unevenly).

## 8. Divergence and reconvergence

### 8.1 Model in one paragraph

Control flow is expressed with two *explicit* instructions, `ssy` (open a reconvergence region)
and `sync` (reach the end of a path), plus per-thread conditional branches. A reconvergence
**stack** per warp holds *what to run next and with which threads*. A divergent branch runs the
**fall-through path first** and defers the taken path on the stack; `sync` resumes whatever is
deferred and, once nothing is deferred in the region, restores the full region mask at the
reconvergence point. There is no PC comparison in the issue path and no hardware discovery of
post-dominators: the compiler places `ssy`/`sync`.

### 8.2 Stack entries

```
entry = { kind : 1 bit,  pc : PC_W,  mask : WARP_SIZE }
  kind 0  TOKEN   pushed by ssy.   pc   = reconvergence point (first instruction after the region's last sync)
                                    mask = active mask when ssy executed (all threads that enter the region)
  kind 1  DIV     pushed by a divergent bnz/bz.  pc = taken target, mask = the threads that took the branch
```

Hardware treats both kinds identically (`kind` is used for assertions and debug). Capacity is
`STACK_DEPTH` entries per warp; a stack is cleared on launch, on warp exit, on fault and on kill.

### 8.3 Instruction semantics

State: `pc, active ⊆ live, stack`. `live` = threads that have not exited.

| Instruction | Action |
|---|---|
| ordinary (`nop`, ALU, load/store) | executes for `active`; `pc ← pc+1` |
| `jmp off` | `pc ← pc+1+off` (all active threads) |
| `ssy off` | if stack full → **fault STK_OVF**; else push `TOKEN{pc+1+off, active}`; `pc ← pc+1` |
| `bnz/bz rs1,off` | issued to the backend; warp enters `W_BRW`. On the taken mask `c` (ANDed with `active`; garbage on inactive lanes is ignored), `nt = active & ~c`: <br>• `c == 0`: `pc ← pc+1` (uniform not taken) <br>• `nt == 0`: `pc ← target` (uniform taken) <br>• otherwise *divergent*: if stack empty → **fault NO_REGION**; if full → **fault STK_OVF**; else push `DIV{target, c}`, `active ← nt`, `pc ← pc+1` |
| `sync` | stack empty → **fault STK_UNF**. Else find the topmost entry `e` with `e.mask & live ≠ 0`; none → **fault LOST**. Pop `e` *and everything above it*; `pc ← e.pc; active ← e.mask & live` |
| `exit` | `live ← live & ~active`. If `live = 0` the warp drains. Else the same “topmost live entry” search as `sync` (with the new `live`) selects the next path; none → **fault LOST** |

`active ← e.mask & live` — the `& live` is what makes reconvergence safe with early exits.

### 8.4 Why one “pop to first live entry” rule is enough

* **Reconvergence.** A region executes one `sync` per path. In the divergent case the first path's `sync`
  pops the `DIV` entry (switching to the deferred path); the second path's `sync` pops the `TOKEN`,
  which restores the whole region's threads at the reconvergence point. If a region did not diverge
  (uniform branch), its single `sync` pops the `TOKEN` directly and the untaken path is simply skipped.
* **Threads that exited** vanish from every `mask & live`. Entries that became empty are skipped in the
  same cycle by the search; the resulting mask never contains an exited thread. If *all* threads of an
  inner region exit, its TOKEN is dead and the pop lands on the enclosing deferred path.
* **Parked threads** (those that finished a path and wait for the others) are represented by the TOKEN
  below the paths; no per-thread state exists.
* **Loops.** Fall-through-first is what bounds loop stack growth: in
  `ssy A; L: body; bnz c,L; sync; A:` the threads that *leave* the loop (fall through) run first and
  hit `sync`, which pops the `DIV` of the continuing threads and lets them go round again. The stack
  therefore never exceeds `TOKEN + DIV` (2 entries) for the loop, whatever the trip counts.

### 8.5 Compiler contract (relationship to compiler-generated control flow)

The hardware does not discover reconvergence points; it executes the ones the compiler emits.
Programs must satisfy:

* **C1 Regions.** Every conditional branch that may diverge is dynamically enclosed by an `ssy` whose
  region it belongs to. Regions are **properly nested** and each region's last instruction on every
  path is a `sync`; the `ssy` target is the first instruction *after* that `sync` (the reconvergence
  point).
* **C2 One sync per path.** Each thread executes exactly one `sync` per region it enters (or leaves the
  program with `exit`).
* **C3 Canonical lowerings.**

  ```
  if (c) {A} else {B}             if (c) {A}                       do {body} while (c)
    ssy  Lend                       ssy  Lend                        ssy  Lafter
    bz   c, Lelse                   bz   c, Lsync                  Lloop:
    A                               A                                body
    sync                          Lsync: sync                        bnz  c, Lloop
  Lelse:                        Lend:                                sync
    B                                                              Lafter:
    sync
  Lend:
  ```
  (`bz c, X` is taken for threads where `c == 0`; the fall-through path runs first.) `break`,
  `continue`, `goto` and early `return` out of nested regions must be lowered to predicate flags
  (`while (c && !brk)`) or to `exit`; a branch may not jump across a region boundary.
* **C4 Barriers** only where all live threads of the warp are converged (§10).
* **C5 Stack bound.** The dynamic stack need is at most **`2 × (static region nesting depth)`**
  (one TOKEN and at most one DIV per open region with the canonical lowerings). The compiler declares
  it in `launch_stack_need_i` and the launch is **rejected** if it exceeds `STACK_DEPTH`.
* **C6 Unstructured programs are not accepted silently.** A divergent branch with no region, a `sync`
  with an empty stack and a stack overflow are detected and *fault* (§8.7) — they never corrupt
  another warp or hang the unit.

The hardware cannot check C1/C2 in general (it cannot know which region a `sync` belongs to). It checks
what is checkable: empty-stack `sync`, empty-stack divergence, overflow, lost threads, and — when
`cfg_check_struct_i` is set, as an *assertion* for compliant code — that `DIV` masks are disjoint
from each other and from `active`, and that an empty stack implies `active == live`.

### 8.6 Nesting limits

With `STACK_DEPTH = D` and the canonical lowerings: region nesting up to `⌊D/2⌋` is always safe even if
every level diverges; deeper nesting is safe when levels are uniform (a uniform branch pushes only the
TOKEN, i.e. 1 entry per level). `SSY` needs 1 free entry, a divergent branch needs 1. The high-water
mark of any warp is exported (`PERF_STK_HWM`) so software can tune `STACK_DEPTH`/`stack_need`.

### 8.7 Overflow, underflow and malformed control flow

| Condition | Detected | Result |
|---|---|---|
| `ssy` with full stack | at issue | **STK_OVF**; the `ssy` is *not* executed |
| divergent branch with full stack | at branch resolution | **STK_OVF**; no push, no state change except the fault |
| `sync` with empty stack | at issue | **STK_UNF** |
| divergent branch with empty stack (no enclosing `ssy`) | at resolution | **NO_REGION** |
| `sync`/`exit` where live threads exist but no entry holds any | at issue | **LOST** |

A fault never silently drops work: the faulting warp stops (`W_DRAIN`, its in-flight operations
retire normally), its **workgroup is terminated** (§11.3), the kernel reports `kernel_fault_o`, and
the cause is readable per warp. No spill-to-memory is implemented (§16).

### 8.8 Worked example

`tests/directed/t04_ifelse.s`: odd lanes take the `then` path, even lanes the `else` path (WARP_SIZE = 32).
This is the *actual* RTL issue trace of the test (PCs are real), with the stack after each instruction:

```
 pc  instruction          active mask   stack after the instruction
  9  ssy  Lend (=15)      FFFFFFFF      [ T(pc=15, FFFFFFFF) ]
 10  bz   r3, Lelse(=13)  FFFFFFFF      [ T, D(pc=13, 55555555) ]   divergent: odd lanes (fall-through) first,
                                                                     even lanes (taken) deferred
 11  movi r5, 111         AAAAAAAA      [ T, D ]
 12  sync                 AAAAAAAA      [ T ]       pop D: active = 55555555, pc = 13
 13  movi r5, 222         55555555      [ T ]
 14  sync                 55555555      [ ]         pop T: active = FFFFFFFF & live, pc = 15  (reconverged)
 15  stg  r5, [r23+0]     FFFFFFFF
```
The `(pc, mask)` columns are the RTL's real issue trace; the stack column follows from the semantics of §8.3
(the test checks its observable consequences: one divergent branch, stack high-water mark 2). The RTL's trace must
equal the SIMT model's trace for every test.

## 9. Register-dependency tracking and retirement

Instructions issue **in order per warp**; operands are sampled by the backend at the issue handshake,
so there are no WAR hazards. RAW and WAW hazards are tracked in a per-warp scoreboard
(`pend[32]`, `pendm[32]` — the latter set only for loads). `r0` is never pending.

* **Slot table.** Each backend-bound instruction allocates one of `NUM_SLOTS` in-flight slots
  `{valid, wr, mem, br, rd}` and the slot index is the transaction tag `{warp, slot}` returned by the
  backend. A slot is freed by exactly one completion. `pend` equals the OR of `1<<rd` over valid
  slots with a destination (checked every cycle by assertion W7).
* **Issue condition.** A hazard exists if a source register (`use_rs1/use_rs2`, non-zero) or the
  destination (non-zero) is pending. `bar` additionally requires an empty slot table. No free slot ⇒
  structural stall.
* **Out-of-order completion** (a load returning after a younger ALU op) is supported: results are
  independent because WAW is blocked at issue.
* **Retirement from inactive contexts is impossible.** A completion retires only if it names a *valid slot of
  the addressed warp*. Otherwise (warp out of range, warp `FREE`/`DONE`, slot not valid, slot already
  retired, or the same slot completed twice in one cycle) it is **dropped**, `PERF_PROTO` is incremented
  and the sticky flag `err_proto_o` is raised; no scoreboard, slot, PC or counter state changes. A warp
  cannot become `W_DONE`/`W_FREE` while it still owns a slot or an outstanding fetch, so a legal
  completion can never target a context that has been recycled.
* Stale-completion detection is per *slot*: a duplicate that arrives after the slot has been
  re-allocated to a newer instruction is indistinguishable from a legal completion of that instruction
  (downstream contract F1 forbids duplicates). Adding a generation tag to `{warp,slot}` would close this
  window; it is not implemented (§16).

Stall attribution (priority in this order, per warp-cycle, only for a warp with a valid head instruction):
`MEM` = a source/dest register is pending on a *load*, or `bar` waits on an in-flight memory operation;
`DEP` = any other register hazard or `bar` waiting on non-memory work; `STRUCT` = no hazard but no free
slot or the backend port is not ready; otherwise the warp is eligible (`ISSUED`/`READY`).

## 10. Workgroup barriers

There is one barrier per workgroup (`bar`, no id). Semantics follow “all non-exited threads of the
workgroup arrive”.

* **Arrival is per warp and requires convergence.** A warp arrives when it issues `bar` with
  `active == live` (every live thread of the warp is executing this `bar`) *and* all of its earlier
  operations have retired. It then sits in `W_BAR`, its PC already advanced.
* **Participant counting without counters.** Workgroup `g` releases in the cycle where
  (a) it is not killed, (b) at least one member is in `W_BAR`, and (c) **every** member warp is in
  `W_BAR` or `W_DONE`. Release is a pure function of the warp states, so it cannot drift: there is no
  arrival counter to over-count (premature release) or to under-count after an exit (deadlock).
* **Exited warps do not participate; draining warps do not yet count as exited.** A warp that executed
  `exit` for its last threads is `W_DRAIN` until its in-flight stores/loads have retired, and only then
  `W_DONE`. Waiting for `DONE` guarantees an exiting warp's memory writes are performed before the
  barrier opens. Partially exited warps participate with their remaining threads (`live`).
* **No premature release.** (c) is the only way to release. Independently of the RTL logic, the checker
  verifies by *events*: (P7a) no warp issues past its k-th barrier before the workgroup's k-th release;
  (P7b) at the k-th release every non-exited member has executed at least k `bar` instructions and is in
  `W_BAR`; (P7c) a complete barrier is released in that same cycle.
* **Release is simultaneous for the whole workgroup** and workgroups are independent: another workgroup's
  timing never delays or advances a barrier.
* **Memory visibility.** `bar` is held until the warp's own slots are empty, and all arrivals precede the
  release, so every access issued before any warp's `bar` is complete before any warp passes it.
* **Invalid divergent barrier (`active ≠ live`).** The `bar` is **not executed**; the warp raises
  `FAULT DIV_BAR`, stops, and its workgroup is terminated (§11.3). Rationale: letting a diverged warp
  “arrive for some threads” would either deadlock (threads parked at a reconvergence point can never
  reach the barrier) or release the workgroup while threads are still missing — the fault is the only
  outcome that is both deterministic and safe. Barriers reached by threads of different warps at
  *different* `bar` instructions are not distinguished (the barrier is a count of executions per warp,
  as on the reference per-thread model).
* **Barrier and exit interplay.** If the last unarrived warp exits (reaches `W_DONE`) while the others wait,
  the barrier releases — exiting is treated as arriving (matches the per-thread reference model).

## 11. Kernel launch, completion and faults

### 11.1 Launch

`launch_valid_i && launch_ready_o` accepts a descriptor (ready only when idle). The descriptor is
validated: `num_wg ≥ 1`, `wpw ≥ 1`, `num_wg·wpw ≤ NUM_WARPS` (`LREJ_DIMS`); `last_threads ≤ WARP_SIZE`
(`LREJ_LAST`); `stack_need == 0 || stack_need ≤ STACK_DEPTH` (`LREJ_STACK`). An invalid descriptor
changes no state and produces a one-cycle `launch_reject_o` with the cause. A valid launch clears the
counters, the arbiter state, the workgroup-kill flags, per-warp fault causes and the sticky protocol-error
flag `err_proto_o` (the simulation-only `err_assert_o` stays set until reset), then activates one warp per
cycle (`total` cycles) before any warp may issue — no workgroup can reach a barrier before all of its
warps are resident.

### 11.2 Completion

When every resident warp is `W_DONE` the kernel completes: contexts return to `W_FREE` and a one-cycle
`kernel_done_o` follows. By construction no slot, scoreboard bit, stack entry or fetch is outstanding
(`P12`). `kernel_fault_o` stays high until the next launch if any warp faulted. Counters and per-warp
fault causes remain readable until then.

### 11.3 Faults

| Code | Name | Raised by |
|---|---|---|
| 1 | `STK_OVF` | §8.7 |
| 2 | `STK_UNF` | §8.7 |
| 3 | `DIV_BAR` | divergent `bar` |
| 4 | `ILLEGAL` | undefined opcode reaching issue |
| 5 | `FETCH` | instruction fetch error (`if_rsp_err_i`, e.g. pc beyond instruction memory) |
| 6 | `LOST` | §8.7 |
| 7 | `NO_REGION` | §8.7 |
| 8 | `WG_KILLED` | collateral: another warp of the same workgroup faulted |

* The faulting instruction is **not executed** (precise for the faulting warp). Illegal/failed-fetch
  instructions fault when they reach the head of the pipeline, not when they are fetched, so speculation
  never faults.
* The first fault of a warp is sticky. A fault terminates the **whole workgroup**: in the following cycle
  every non-finished warp of the workgroup is forced to `W_DRAIN`, loses its barrier wait, and is not a
  candidate. The faulting workgroup never releases a barrier. Other workgroups are unaffected.
* Delivery to *other* warps is imprecise by at most one issue slot for faults detected at branch
  resolution (another warp may issue in the same cycle); faults detected at issue consume the single
  issue slot themselves, so no sibling issues at all.
* A faulting issue slot is counted in `PERF_IDLE`, not in `PERF_ISSUED`.

## 12. Interfaces and the downstream contract

### 12.1 Ports (`sf_simt_ctrl`)

| Group | Signals |
|---|---|
| launch | `launch_valid_i/ready_o`, `launch_pc_i`, `launch_num_wg_i`, `launch_wpw_i`, `launch_last_threads_i`, `launch_stack_need_i`, `launch_reject_o`, `launch_reject_cause_o` |
| status | `busy_o`, `kernel_done_o` (pulse), `kernel_fault_o`, `warp_*_o` (state, class, pc, active, live, sp, wg, fault) |
| fetch | `if_req_valid_o/ready_i/warp_o/pc_o`; `if_rsp_valid_i/warp_i/pc_i/instr_i/err_i` |
| issue | `iss_valid_o`, `iss_port_o`, `iss_ready_i[1:0]`, `iss_warp_o`, `iss_slot_o`, `iss_pc_o`, `iss_mask_o`, `iss_instr_o`, `iss_wg_o`, `iss_widx_o` |
| completion | two interchangeable channels: `cmpl_valid_i[1:0]`, `cmpl_warp_i[2]`, `cmpl_slot_i[2]`, `cmpl_taken_i[2]` |
| trace/debug | `ev_issue_o`, `ev_exec_o`, `ev_warp_o/pc_o/mask_o/instr_o`, `ev_fill_o`, `sched_cand/elig/grant_o`, `wg_release_o`, `core_run_o` |
| counters/flags | `perf_o[PERF_N]`, `perf_clear_i`, `err_proto_o`, `err_assert_o`, `cfg_check_struct_i` |

### 12.2 Downstream obligations (assumed, and enforced by the testbench model)

* **D1** `iss_ready_i[p]` is a same-cycle input and must not depend combinationally on `iss_valid_o`.
  A backend instruction issues only in a cycle where its port is ready.
* **D2** Operands are sampled at the issue handshake. Loads and stores of one warp are performed in issue
  order (loads return later; the register is written when the completion is presented).
* **D3** Each accepted backend instruction yields **exactly one** completion `{warp, slot}` (branches
  also the per-thread taken mask), on either channel, **at least one cycle after** the issue cycle. The
  taken mask of inactive lanes may be arbitrary.
* **D4** Each fetch request is answered exactly once with the echoed `{warp, pc}`; `err_i` marks a failed
  fetch.

### 12.3 Fairness assumptions (the progress properties are conditional on these)

* **F1 Completion.** Every accepted instruction completes within finite time.
* **F2 Port readiness.** Each backend port is ready at least once in every window of
  `RDY_MAXGAP + 1` cycles (infinitely often suffices for eventual progress; the window gives the
  numeric bounds the checker uses).
* **F3 Fetch.** The instruction memory accepts requests infinitely often and answers each within
  finite time.
* **F4 No retraction.** Readiness/response timing is independent of the control unit's internal state
  other than through the handshakes above.
* **F5 Program.** Progress means the *scheduler* serves every live warp; a program that loops forever
  (or deadlocks itself, e.g. mismatched barriers whose participants wait on each other forever) is not a
  scheduler failure and no watchdog on program termination is provided.

**Eventual-progress argument** (checked in simulation as P3/P4/P9, not formally proven):
(1) a `W_RUN` warp with an empty ibuf is fetched within `NUM_WARPS−1` fetch grants and answered by F3;
(2) every pending scoreboard bit belongs to a valid slot that retires by F1, so hazards and slot
exhaustion clear; (3) a candidate is eligible whenever its port is ready (F2) and is granted within
`N·G+1` cycles (RR, pointer argument of §7.1) / after at most `N−1` overtakes while eligible (AGE, §7.2); (4) `W_BRW` ends when the
branch completes; (5) a barrier whose members all eventually arrive or finish releases in the same cycle
the last one does; (6) `DRAIN → DONE` needs only F1/F3; (7) all warps `DONE` completes the kernel.
Hence every live warp eventually executes its next instruction.

## 13. Performance counters

Indices are `PERF_*` in `sf_simt_pkg`; counters clear on launch (or `perf_clear_i`), saturate, and are
valid after `kernel_done_o` until the next launch. “Warp-cycle” counters add the number of warps in the
class every running cycle.

| Counter | Unit | Definition |
|---|---|---|
| `PERF_CYCLES` | cycles | cycles with a kernel running (`L_RUN`) |
| **`PERF_ISSUED`** | instr | instructions issued and executed (every class, incl. `nop/sync/exit/bar`) |
| **`PERF_IDLE`** | cycles | running cycles in which no instruction executed (includes faulting slots). `CYCLES = ISSUED + IDLE` |
| **`PERF_DEP_STALL`** | warp-cycles | class `DEP` |
| **`PERF_MEM_STALL`** | warp-cycles | class `MEM` |
| **`PERF_BAR_WAIT`** | warp-cycles | warps in `W_BAR` |
| `PERF_STRUCT` | warp-cycles | class `STRUCT` (slots exhausted / port not ready) |
| `PERF_FRONT` | warp-cycles | waiting for fetch or branch resolution |
| `PERF_READY_WAIT` | warp-cycles | eligible but not granted (contention) |
| `PERF_BRANCH`, `PERF_DIV` | events | conditional branches resolved / of which divergent |
| `PERF_RECONV` | events | `sync` instructions executed |
| `PERF_STK_HWM` | entries | maximum stack depth seen on any warp |
| `PERF_FAULT` | events | fault events |
| `PERF_BAR_REL` | events | workgroup barrier releases |
| `PERF_RETIRED` | events | backend completions retired |
| `PERF_PROTO` | events | dropped completions/responses |

The testbench checks these against an independent tally every kernel and against the SIMT reference
model (`issued`, branches, divergent branches, `sync` count, stack high-water mark, barrier releases).

## 14. Assertions and properties

*Inside the RTL* (simulation-only, `ifndef SYNTHESIS`; each prints `[SF-ASSERT] <instance> <id>: ...` and
raises `err_assert_o`):

| Id | Property |
|---|---|
| W1 | warp state encoding is legal |
| W2 | **bounded-resource ownership:** `FREE`/`DONE` contexts own no slot, scoreboard bit, ibuf, fetch, mask or stack entry |
| W3 | ibuf valid only in `RUN`, never together with a pending fetch; a fetch is pending only in `RUN`/`DRAIN` |
| W4 | `RUN` ⇒ `active ≠ 0`, `live ≠ 0`, `active ⊆ live` |
| W5 | `DRAIN`/`DONE`/`FREE` have empty masks; `DRAIN` has no ibuf |
| W6 | `BRW` has exactly one branch slot; no branch slot outside `BRW`/`DRAIN` |
| W7 | scoreboard == union of valid slot destinations; `r0` never pending |
| W8 | a warp in `BAR` is converged and drained |
| W9 | **no duplicate/phantom issue:** grant only to an eligible `RUN` context with a valid ibuf, not killed |
| W10 | (compliant code) empty stack ⇒ `active == live` |
| W11 | no retirement on a `FREE` context |
| S1–S4 | stack never over/under-flows; push/pop exclusive; (compliant code) `DIV` masks disjoint from each other and `active` |
| A1–A6 | arbiter: age order is a strict total order; grant ⊆ eligible, one-hot, work-conserving; **A6 (RR): the pointer never passes a candidate that was not granted** |
| T1–T4 | backend issue only when the port is ready; kernel done ⇒ nothing owned; killed workgroup never releases; no launch while busy |

*Port-level checker* (`tb/sf_simt_checker.sv`, independent shadow state): P1 grant legality; P2 exact
policy model (procedural RR/age model vs. the RTL); **P3 bounded overtaking (AGE: ≤ N−1)**; **P4 candidate-wait
bound (RR/AGE, derived from F2)**; **P5 no duplicate issue** (fills ≥ issues, ≤ 1 ahead); **P6 slot allocate-once/retire-once**,
inactive contexts own no slots; **P7 barrier ordering by events**; **P8 fault containment**; **P9
global-progress watchdog** (eventual progress under F1–F3, expressed as a bound); P10 class partition;
P11 counters against an independent tally; P12 clean completion.

Safety properties are enforced as simulation assertions on all tests; bounded liveness is *checked*
by watchdogs/bounds (P3, P4, P9), **not proven formally**.

## 15. Verification environment

```
model/sfisa.py   assembler/disassembler        model/sfref.py   run_mimd (per-thread truth) + run_simt (stack model + traces)
model/sfgen.py   structured random programs    tb/tb_simt.sv    DUT + sf_simt_dsm (IMEM, backend, memory, bounded random timing) + checker
tests/directed/  hand-written programs         tests/directed_suite.py   expectations per test/config/profile
scripts/regress_random.py   RTL vs both references         scripts/mutation_test.py   injected-bug check of the environment
```

* **Reference simulators.** `run_mimd` executes every thread independently (private PC, private `ssy`
  return stack) — it contains *no* masks and no reconvergence stack, so it is an independent oracle for
  the architectural result. `run_simt` is the lock-step stack model; it yields per-warp `(pc, mask)` traces.
  The two are cross-checked against each other (`scripts/xcheck_refs.py`) before the RTL is involved.
* **What is compared for every random/directed run:** all non-zero registers of all threads, global and
  shared memory, per-warp fault causes and kernel status (RTL vs. MIMD *and* SIMT), the per-warp issue
  trace (RTL vs. SIMT), and the counters listed in §13.
* **Random legal programs** (`sfgen.py`) follow §8.5: nested divergent if/else/loops with per-thread trip
  counts, divergent and whole-warp `exit`, partially populated warps, global loads/stores to private windows
  and a read-only table, shared-memory exchanges bracketed by barriers (also inside warp-uniform loops).
  They are race-free, so results are independent of scheduling, policy and timing.
* **Downstream timing** is randomised but bounded (profiles `ideal`, `mid`, `slow`, `memhv`): fetch/ALU/memory
  latency, port back-pressure, delayed and out-of-order completions, garbage on inactive branch lanes.
* **Directed tests** (37 cases built from 30 programs, run on 5 hardware configurations and up to 5 timing profiles) cover: RR order, dependency/load-use/structural stalls, nested divergence, divergent
  loops, partial warps, exit and dead-entry cascades, barriers (exchange, independent workgroups, exited and
  partially exited participants, barrier in a loop, invalid divergent barrier), stack overflow at `ssy` and at
  branch resolution, underflow, no-region, illegal instruction, fetch error, runaway PC, launch rejection,
  relaunch, spurious/duplicate completions and spurious fetch responses, exact counters.
* **Mutation testing** (`scripts/mutation_test.py`) injects 22 representative defects into a *copy* of the RTL
  and requires each to be detected: off-by-one barrier participant count, draining warp counted as exited,
  barrier deadlock on exit, duplicate issue, missing WAW and missing second-operand RAW checks, resurrected exited
  threads, barrier without drain, unchecked completions, stuck RR pointer, a loose RR pointer that jumps past a blocked candidate, swapped divergence
  masks, broken age matrix, missing kill gating, accepted divergent barrier, `exit` not clearing `live`, a broken
  stall counter, a missing overflow check, and four defects that **no assertion can see** and that only the
  RTL-vs-reference comparison catches (wrong `sync` resume pc, wrong branch target, off-by-one partial-warp mask,
  swapped workgroup/warp ids). Two of the first set of 16 were found to die for a collateral reason (they also broke
  kernel completion) and were rewritten to exercise the barrier unit specifically, which led to the extra directed
  test `t34_barrier_drain_exit`.

## 16. Limitations and non-goals

* **Simulation only.** Nothing here was synthesised, placed or timed; area/frequency are unknown. The assertions are
  simulation constructs (`ifndef SYNTHESIS`); no formal tool was run.
* **Liveness is checked, not proven.** P3/P4/P9 are bounded watchdogs under F1–F3; §12.3 is an argument, not a proof.
* Single issue slot, single resident kernel, one barrier per workgroup, no named barriers, no barrier-id or
  arrival-count arguments.
* No warp-level operations (shuffle, vote, ballot, atomics) and no predication — the ISA is deliberately minimal.
* No stack spilling: overflow faults the workgroup. Deep nesting must be limited by the compiler (`stack_need`).
* Reconvergence correctness (C1/C2) is the compiler's responsibility; the hardware only detects the symptoms listed in §8.7.
* Duplicate-completion detection is per slot (no generation tag); see §9.
* `LOST` is a defensive fault: no *compliant* program can reach it and it is exercised only through the reference
  model's identical rule, not by a directed RTL test.
* Faults are imprecise across warps by at most one issue slot when raised at branch resolution (§11.3).
* The backend's operand sampling, memory ordering and special-register semantics are specified here and implemented
  by the testbench model only; a real backend must meet D1–D4.
