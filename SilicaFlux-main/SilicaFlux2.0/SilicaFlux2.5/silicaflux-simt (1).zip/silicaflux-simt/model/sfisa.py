"""SilicaFlux SFT-1 SIMT ISA: opcode tables, assembler, disassembler.

Instruction word (32 bit):
    [31:27] op  [26:22] rd  [21:17] rs1  [16:12] rs2  [11:0] imm12 ; I-form: [16:0] imm17
This file is the single Python source of truth for encodings; rtl/sf_simt_pkg.sv
mirrors it (tests/test_isa_sync.py checks the two stay identical).
"""
import re

OPCODES = {
    "nop": 0x00, "exit": 0x01, "ssy": 0x02, "sync": 0x03, "bar": 0x04, "jmp": 0x05,
    "bnz": 0x06, "bz": 0x07,
    "add": 0x08, "sub": 0x09, "mul": 0x0A, "and": 0x0B, "or": 0x0C, "xor": 0x0D,
    "shl": 0x0E, "shr": 0x0F, "sar": 0x10, "slt": 0x11, "sltu": 0x12,
    "addi": 0x13, "lui": 0x14, "s2r": 0x15,
    "ldg": 0x18, "stg": 0x19, "lds": 0x1A, "sts": 0x1B,
}
OPNAME = {v: k for k, v in OPCODES.items()}

R_OPS = {"add", "sub", "mul", "and", "or", "xor", "shl", "shr", "sar", "slt", "sltu"}
NOARG = {"nop", "exit", "sync", "bar"}
LOADS = {"ldg", "lds"}
STORES = {"stg", "sts"}

SREGS = {"lane": 0, "tid": 1, "ntid": 2, "wgid": 3, "nwg": 4, "widx": 5, "gtid": 6, "warpid": 7}

MASK32 = 0xFFFFFFFF


class AsmError(Exception):
    pass


def sext(v, bits):
    v &= (1 << bits) - 1
    return v - (1 << bits) if v >> (bits - 1) else v


def _reg(tok, ln):
    m = re.fullmatch(r"r(\d+)", tok.strip().lower())
    if not m or int(m.group(1)) > 31:
        raise AsmError(f"line {ln}: bad register '{tok}'")
    return int(m.group(1))


def _imm(tok, ln, bits, signed=True):
    tok = tok.strip()
    try:
        v = int(tok, 0)
    except ValueError:
        raise AsmError(f"line {ln}: bad immediate '{tok}'")
    lo, hi = (-(1 << (bits - 1)), (1 << (bits - 1)) - 1) if signed else (0, (1 << bits) - 1)
    if not (lo <= v <= hi):
        raise AsmError(f"line {ln}: immediate {v} does not fit in {bits} bits")
    return v & ((1 << bits) - 1)


def _mem(tok, ln):
    m = re.fullmatch(r"\[\s*(r\d+)\s*(?:([+-])\s*(-?\w+))?\s*\]", tok.strip().lower())
    if not m:
        raise AsmError(f"line {ln}: bad memory operand '{tok}'")
    rs1 = _reg(m.group(1), ln)
    off = 0
    if m.group(2):
        off = int(m.group(3), 0)
        if m.group(2) == "-":
            off = -off
    if not (-2048 <= off <= 2047):
        raise AsmError(f"line {ln}: offset {off} does not fit in 12 bits")
    return rs1, off & 0xFFF


def _split_ops(s):
    # split on commas not inside brackets
    out, depth, cur = [], 0, ""
    for ch in s:
        if ch == "[":
            depth += 1
        if ch == "]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def assemble(text):
    """Assemble text -> (list of 32-bit words, label dict, listing lines)."""
    items = []   # (lineno, mnemonic, operand list, pc)
    labels = {}
    pc = 0
    for ln, raw in enumerate(text.splitlines(), 1):
        line = re.split(r"[;#]", raw, maxsplit=1)[0].strip()
        while True:
            m = re.match(r"^([A-Za-z_.$][\w.$]*)\s*:\s*(.*)$", line)
            if not m:
                break
            if m.group(1) in labels:
                raise AsmError(f"line {ln}: duplicate label '{m.group(1)}'")
            labels[m.group(1)] = pc
            line = m.group(2).strip()
        if not line:
            continue
        parts = line.split(None, 1)
        mn = parts[0].lower()
        ops = _split_ops(parts[1]) if len(parts) > 1 else []
        n = 1
        if mn == "li":
            n = 2
        items.append((ln, mn, ops, pc))
        pc += n

    words, listing = [], []

    def target(tok, ln, pcnow):
        if tok in labels:
            off = labels[tok] - (pcnow + 1)
        else:
            off = int(tok, 0)
        if not (-(1 << 16) <= off < (1 << 16)):
            raise AsmError(f"line {ln}: branch offset {off} out of range")
        return off & 0x1FFFF

    for ln, mn, ops, pcnow in items:
        def need(n):
            if len(ops) != n:
                raise AsmError(f"line {ln}: '{mn}' takes {n} operand(s)")
        ws = []
        if mn == ".word":
            need(1)
            ws.append(int(ops[0], 0) & MASK32)
        elif mn == "movi":
            need(2)
            ws.append((OPCODES["addi"] << 27) | (_reg(ops[0], ln) << 22) | _imm(ops[1], ln, 17))
        elif mn == "mov":
            need(2)
            ws.append((OPCODES["addi"] << 27) | (_reg(ops[0], ln) << 22) | (_reg(ops[1], ln) << 17))
        elif mn == "li":
            need(2)
            v = int(ops[1], 0) & MASK32
            sv = sext(v, 32)
            hi = ((sv + 0x4000) >> 15) & 0x1FFFF
            lo = sv - (sext(hi, 17) << 15)
            assert -16384 <= lo <= 16383
            rd = _reg(ops[0], ln)
            ws.append((OPCODES["lui"] << 27) | (rd << 22) | hi)
            ws.append((OPCODES["addi"] << 27) | (rd << 22) | (rd << 17) | (lo & 0x1FFFF))
        elif mn in NOARG:
            need(0)
            ws.append(OPCODES[mn] << 27)
        elif mn in R_OPS:
            need(3)
            ws.append((OPCODES[mn] << 27) | (_reg(ops[0], ln) << 22) | (_reg(ops[1], ln) << 17) |
                      (_reg(ops[2], ln) << 12))
        elif mn == "addi":
            need(3)
            ws.append((OPCODES[mn] << 27) | (_reg(ops[0], ln) << 22) | (_reg(ops[1], ln) << 17) |
                      _imm(ops[2], ln, 17))
        elif mn == "lui":
            need(2)
            ws.append((OPCODES[mn] << 27) | (_reg(ops[0], ln) << 22) | _imm(ops[1], ln, 17, signed=False))
        elif mn == "s2r":
            need(2)
            sid = SREGS[ops[1].lower()] if ops[1].lower() in SREGS else int(ops[1], 0)
            ws.append((OPCODES[mn] << 27) | (_reg(ops[0], ln) << 22) | sid)
        elif mn in ("jmp", "ssy"):
            need(1)
            ws.append((OPCODES[mn] << 27) | target(ops[0], ln, pcnow))
        elif mn in ("bnz", "bz"):
            need(2)
            ws.append((OPCODES[mn] << 27) | (_reg(ops[0], ln) << 17) | target(ops[1], ln, pcnow))
        elif mn in LOADS:
            need(2)
            rs1, off = _mem(ops[1], ln)
            ws.append((OPCODES[mn] << 27) | (_reg(ops[0], ln) << 22) | (rs1 << 17) | off)
        elif mn in STORES:
            need(2)
            rs1, off = _mem(ops[1], ln)
            ws.append((OPCODES[mn] << 27) | (rs1 << 17) | (_reg(ops[0], ln) << 12) | off)
        else:
            raise AsmError(f"line {ln}: unknown mnemonic '{mn}'")
        for w in ws:
            listing.append(f"{len(words):04x}: {w:08x}  {mn} {', '.join(ops)}")
            words.append(w)
    return words, labels, listing


def disasm(w, pc=0):
    op = (w >> 27) & 31
    rd, rs1, rs2 = (w >> 22) & 31, (w >> 17) & 31, (w >> 12) & 31
    imm17, imm12 = w & 0x1FFFF, w & 0xFFF
    name = OPNAME.get(op)
    if name is None:
        return f".illegal 0x{w:08x}"
    if name in NOARG:
        return name
    if name in R_OPS:
        return f"{name} r{rd}, r{rs1}, r{rs2}"
    if name == "addi":
        return f"addi r{rd}, r{rs1}, {sext(imm17, 17)}"
    if name == "lui":
        return f"lui r{rd}, {imm17}"
    if name == "s2r":
        return f"s2r r{rd}, {imm17}"
    if name in ("jmp", "ssy"):
        return f"{name} 0x{pc + 1 + sext(imm17, 17):x}"
    if name in ("bnz", "bz"):
        return f"{name} r{rs1}, 0x{pc + 1 + sext(imm17, 17):x}"
    if name in LOADS:
        return f"{name} r{rd}, [r{rs1} {sext(imm12, 12):+d}]"
    if name in STORES:
        return f"{name} r{rs2}, [r{rs1} {sext(imm12, 12):+d}]"
    return f".word 0x{w:08x}"


def write_hex(words, path):
    with open(path, "w") as f:
        for w in words:
            f.write(f"{w:08x}\n")
