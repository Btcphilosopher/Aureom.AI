"""Random *legal* SFT-1 program generator.

Generates structured control flow following the compiler contract of
docs/ARCHITECTURE.md section 8.5, so that a program's architectural result is
independent of warp scheduling, timing and of the SIMT reconvergence mechanism:

  * Every potentially divergent conditional branch lives inside an SSY region and
    every path of the region ends in SYNC (if/else, if, do-while loops).
  * Region nesting is bounded so the dynamic stack need (2 entries per open
    region) never exceeds the hardware depth.
  * BAR only appears where every live thread of a warp is converged and where
    all warps of the workgroup execute it the same number of times (top level
    and top level of warp-uniform loops).
  * Memory is race free: global stores go to a per-thread private window, the
    global table region [0, 1023] is read-only, and shared-memory communication
    is bracketed by barriers.
  * Termination: all loops are do-while with bounded trip counts.

Register allocation (r0 == 0):
   r1..r12  data          r13 scratch address     r14 predicate   r15 predicate 2
   r16..r19 loop counters r20 tid  r21 lane  r22 gtid  r23 private base
   r24 smem slot (tid)    r25 ntid r26 scratch    r27 wgid  r28 widx
"""
import random

from sfisa import assemble

TABLE_WORDS = 1024
PRIV_BASE = 0x1000

DATA = list(range(1, 13))
R_SCR, R_P, R_P2 = 13, 14, 15
R_LOOP = [16, 17, 18, 19]
R_TID, R_LANE, R_GTID, R_PRIV, R_SLOT, R_NTID, R_T, R_WG, R_WI = 20, 21, 22, 23, 24, 25, 26, 27, 28

ALU_R = ["add", "sub", "mul", "and", "or", "xor", "shl", "shr", "sar", "slt", "sltu"]


class Gen:
    def __init__(self, seed, max_depth=3, dyn_limit=2500, n_stmts=40, allow_exit=True, allow_bar=True,
                 warp_size=32, mem_weight=1.0, div_weight=1.0, bar_weight=1.0):
        self.r = random.Random(seed)
        self.max_depth = max_depth
        self.dyn_limit = dyn_limit
        self.n_stmts = n_stmts
        self.allow_exit = allow_exit
        self.allow_bar = allow_bar
        self.ws = warp_size
        self.mw, self.dw, self.bw = mem_weight, div_weight, bar_weight
        self.lines = []
        self.nlab = 0
        self.dyn = 0
        self.nwi = 4   # number of distinct warp-in-wg ids used by warp-uniform predicates

    # -- helpers -----------------------------------------------------------
    def emit(self, s, mult=1):
        self.lines.append("  " + s)
        self.dyn += mult

    def label(self, name):
        self.lines.append(f"{name}:")

    def newlab(self, p):
        self.nlab += 1
        return f"{p}{self.nlab}"

    def d(self):
        return self.r.choice(DATA)

    def alu(self, mult):
        r = self.r
        k = r.random()
        rd = self.d()
        if k < 0.55:
            self.emit(f"{r.choice(ALU_R)} r{rd}, r{self.d()}, r{self.d()}", mult)
        elif k < 0.75:
            self.emit(f"addi r{rd}, r{self.d()}, {r.randint(-4000, 4000)}", mult)
        elif k < 0.82:
            self.emit(f"movi r{rd}, {r.randint(-60000, 60000)}", mult)
        elif k < 0.90:
            self.emit(f"lui r{rd}, {r.randint(0, 131071)}", mult)
        elif k < 0.95:
            self.emit(f"{r.choice(ALU_R)} r{rd}, r{r.choice([R_TID, R_LANE, R_GTID, R_WG, R_WI])}, r{self.d()}", mult)
        else:
            self.emit(f"mov r{rd}, r{self.d()}", mult)

    def mem(self, mult):
        r = self.r
        k = r.random()
        if k < 0.35:
            self.emit(f"stg r{self.d()}, [r{R_PRIV} + {r.randint(0, 15)}]", mult)
        elif k < 0.7:
            self.emit(f"ldg r{self.d()}, [r{R_PRIV} + {r.randint(0, 15)}]", mult)
        else:
            # gather from the read-only table: addr = data & 1023
            self.emit(f"movi r{R_T}, {TABLE_WORDS - 1}", mult)
            self.emit(f"and r{R_SCR}, r{self.d()}, r{R_T}", mult)
            self.emit(f"ldg r{self.d()}, [r{R_SCR} + 0]", mult)

    def predicate(self, mult, rare=False):
        """Compute a predicate into R_P. Returns True if warp-uniform by construction."""
        r = self.r
        if rare:
            if r.random() < 0.4:   # whole-warp exit predicate: widx == K
                self.emit(f"movi r{R_T}, {r.randint(0, self.nwi - 1)}", mult)
                self.emit(f"xor r{R_P}, r{R_WI}, r{R_T}", mult)
                self.emit(f"movi r{R_T}, 1", mult)
                self.emit(f"sltu r{R_P}, r{R_P}, r{R_T}", mult)
                return True
            self.emit(f"movi r{R_T}, 15", mult)
            self.emit(f"and r{R_P}, r{self.d()}, r{R_T}", mult)
            self.emit(f"movi r{R_T}, 1", mult)
            self.emit(f"sltu r{R_P}, r{R_P}, r{R_T}", mult)
            return False
        k = r.random()
        if k < 0.30:      # one data bit
            self.emit(f"movi r{R_T}, {r.randint(0, 20)}", mult)
            self.emit(f"shr r{R_P}, r{self.d()}, r{R_T}", mult)
            self.emit(f"movi r{R_T}, 1", mult)
            self.emit(f"and r{R_P}, r{R_P}, r{R_T}", mult)
        elif k < 0.45:    # signed / unsigned compare of two data regs
            self.emit(f"{r.choice(['slt', 'sltu'])} r{R_P}, r{self.d()}, r{self.d()}", mult)
        elif k < 0.55:    # inequality
            self.emit(f"sub r{R_P}, r{self.d()}, r{self.d()}", mult)
        elif k < 0.70:    # lane based
            self.emit(f"movi r{R_T}, {r.randint(1, self.ws)}", mult)
            self.emit(f"slt r{R_P}, r{R_LANE}, r{R_T}", mult)
        elif k < 0.78:
            self.emit(f"movi r{R_T}, {r.choice([1, 2, 3, 7])}", mult)
            self.emit(f"and r{R_P}, r{R_LANE}, r{R_T}", mult)
        elif k < 0.90:    # warp uniform (differs across warps): widx < K
            self.emit(f"movi r{R_T}, {r.randint(0, self.nwi)}", mult)
            self.emit(f"slt r{R_P}, r{R_WI}, r{R_T}", mult)
            return True
        else:             # fully uniform
            self.emit(f"movi r{R_P}, {r.randint(0, 1)}", mult)
            return True
        return False

    # -- constructs ----------------------------------------------------------
    def block(self, depth, mult, bar_ok, n):
        for _ in range(n):
            if self.dyn > self.dyn_limit:
                self.alu(mult)
                continue
            self.stmt(depth, mult, bar_ok)

    def stmt(self, depth, mult, bar_ok):
        r = self.r
        opts = [("alu", 40), ("mem", 14 * self.mw)]
        if depth < self.max_depth:
            opts += [("if", 14 * self.dw), ("ifelse", 14 * self.dw), ("loop", 8 * self.dw)]
            if self.allow_exit:
                opts += [("exit", 2.0)]
        if bar_ok and self.allow_bar and depth == 0:
            opts += [("xchg", 7 * self.bw), ("bar", 2 * self.bw)]
        kinds, w = zip(*opts)
        k = r.choices(kinds, weights=w)[0]
        if k == "alu":
            self.alu(mult)
        elif k == "mem":
            self.mem(mult)
        elif k == "if":
            self.predicate(mult)
            lend, lsync = self.newlab("Lend"), self.newlab("Lsync")
            self.emit(f"ssy {lend}", mult)
            self.emit(f"bz r{R_P}, {lsync}", mult)
            self.block(depth + 1, mult, False, r.randint(1, 4))
            self.label(lsync)
            self.emit("sync", mult)
            self.label(lend)
        elif k == "ifelse":
            self.predicate(mult)
            lend, lelse = self.newlab("Lend"), self.newlab("Lelse")
            self.emit(f"ssy {lend}", mult)
            self.emit(f"bz r{R_P}, {lelse}", mult)
            self.block(depth + 1, mult, False, r.randint(1, 4))
            self.emit("sync", mult)
            self.label(lelse)
            self.block(depth + 1, mult, False, r.randint(1, 4))
            self.emit("sync", mult)
            self.label(lend)
        elif k == "loop":
            rc = R_LOOP[depth]
            uniform = r.random() < 0.3
            if uniform:
                trip = r.randint(1, 3)
                self.emit(f"movi r{rc}, {trip}", mult)
            else:
                trip = 4
                self.emit(f"movi r{R_T}, {r.randint(0, 24)}", mult)
                self.emit(f"shr r{rc}, r{self.d()}, r{R_T}", mult)
                self.emit(f"movi r{R_T}, 3", mult)
                self.emit(f"and r{rc}, r{rc}, r{R_T}", mult)
                self.emit(f"addi r{rc}, r{rc}, 1", mult)
            lloop, lafter = self.newlab("Lloop"), self.newlab("Lafter")
            self.emit(f"ssy {lafter}", mult)
            self.label(lloop)
            # a uniform loop at depth 0 may contain barriers
            inner_bar = bar_ok and uniform and depth == 0
            self.block(depth + 1, mult * trip, False, r.randint(1, 4))
            if inner_bar and self.allow_bar and r.random() < 0.6:
                self.xchg(mult * trip)
            self.emit(f"addi r{rc}, r{rc}, -1", mult * trip)
            self.emit(f"bnz r{rc}, {lloop}", mult * trip)
            self.emit("sync", mult)
            self.label(lafter)
        elif k == "exit":
            self.predicate(mult, rare=True)
            lend, lsync = self.newlab("Lend"), self.newlab("Lsync")
            self.emit(f"ssy {lend}", mult)
            self.emit(f"bz r{R_P}, {lsync}", mult)
            self.emit("exit", mult)
            self.label(lsync)
            self.emit("sync", mult)
            self.label(lend)
        elif k == "xchg":
            self.xchg(mult)
        elif k == "bar":
            self.emit("bar", mult)

    def xchg(self, mult):
        """Shared-memory neighbour exchange bracketed by two barriers."""
        r = self.r
        self.emit(f"sts r{self.d()}, [r{R_SLOT} + 0]", mult)
        self.emit("bar", mult)
        self.emit(f"movi r{R_T}, {r.randint(0, 255)}", mult)
        self.emit(f"add r{R_SCR}, r{R_SLOT}, r{R_T}", mult)
        self.emit(f"movi r{R_T}, 255", mult)
        self.emit(f"and r{R_SCR}, r{R_SCR}, r{R_T}", mult)
        self.emit(f"lds r{self.d()}, [r{R_SCR} + 0]", mult)
        self.emit("bar", mult)

    # -- program ------------------------------------------------------------
    def generate(self):
        r = self.r
        self.emit("s2r r20, tid")
        self.emit("s2r r21, lane")
        self.emit("s2r r22, gtid")
        self.emit("s2r r25, ntid")
        self.emit("s2r r27, wgid")
        self.emit("s2r r28, widx")
        self.emit("movi r26, 4")
        self.emit("shl r23, r22, r26")
        self.emit("movi r26, 4096")
        self.emit("add r23, r23, r26")
        self.emit("mov r24, r20")
        for i, rd in enumerate(DATA):
            self.emit(f"movi r26, {r.randint(1, 30000)}")
            self.emit(f"mul r{rd}, r{r.choice([R_TID, R_GTID, R_LANE, R_WG])}, r26")
            self.emit(f"addi r{rd}, r{rd}, {r.randint(-3000, 3000)}")
            if r.random() < 0.5:
                self.emit(f"xor r{rd}, r{rd}, r{r.choice([R_GTID, R_TID, R_WI])}")
        self.block(0, 1, True, self.n_stmts)
        for i in range(4):
            self.emit(f"stg r{DATA[i]}, [r{R_PRIV} + {i}]")
        self.emit("exit")
        return "\n".join(self.lines) + "\n"


def random_cfg(rng, num_warps, warp_size):
    wpw = rng.choice([w for w in (1, 2, 3, 4, 5, 6, 7, 8) if w <= num_warps])
    max_wg = max(1, num_warps // wpw)
    num_wg = rng.randint(1, min(max_wg, 4))
    tlast = rng.choice([0, 0, rng.randint(1, warp_size)])
    return num_wg, wpw, tlast


def gen_table(seed):
    r = random.Random(seed ^ 0x5EED)
    return [r.getrandbits(32) for _ in range(TABLE_WORDS)]


def gen_program(seed, **kw):
    text = Gen(seed, **kw).generate()
    words, labels, listing = assemble(text)
    return text, words


if __name__ == "__main__":
    import sys
    print(Gen(int(sys.argv[1]) if len(sys.argv) > 1 else 1).generate())
