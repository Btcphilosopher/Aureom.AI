"""SilicaFlux SFT-1 reference simulators.

Two independent architectural models of the same ISA:

  run_mimd : every thread is an independent sequential machine with a private
             PC and a private SSY return stack (SSY pushes a return pc, SYNC pops
             and jumps). No masks, no reconvergence stack. This is the *semantic
             ground truth* for race-free, structured programs.

  run_simt : lock-step warps with active/live masks and the reconvergence stack
             exactly as specified in docs/ARCHITECTURE.md section 8. Produces
             per-warp (pc, active-mask) issue traces, stack high-water mark,
             branch/divergence/reconvergence counts and barrier-release counts.
             Also implements the fault rules (overflow, underflow, divergent
             barrier, illegal instruction, fetch error, lost threads, ...).

For legal programs both models must produce identical architectural state, and
the RTL must match both (registers, memory, fault status, and the per-warp
issue trace against run_simt).
"""
from dataclasses import dataclass, field

from sfisa import OPNAME, OPCODES, sext, MASK32

GMEM_WORDS = 1 << 14
SMEM_WORDS = 1 << 10
IMEM_WORDS = 4096
ILLEGAL_WORD = 0xFFFFFFFF
NUM_REGS = 32

# fault codes (mirror sf_fault_e)
F_NONE, F_STK_OVF, F_STK_UNF, F_DIV_BAR, F_ILLEGAL, F_FETCH, F_LOST, F_NO_REGION, F_WG_KILLED = range(9)
FAULT_NAMES = ["NONE", "STK_OVF", "STK_UNF", "DIV_BAR", "ILLEGAL", "FETCH", "LOST", "NO_REGION", "WG_KILLED"]

LREJ_NONE, LREJ_DIMS, LREJ_STACK, LREJ_LAST = range(4)


class RefError(Exception):
    """Raised by run_mimd when a program does something illegal (generator bug)."""


@dataclass
class Cfg:
    num_warps: int = 8        # hardware warp slots
    warp_size: int = 32
    stack_depth: int = 8
    num_wg: int = 1
    wpw: int = 1              # warps per workgroup
    tlast: int = 0            # threads in last warp of each WG (0 = full)
    entry: int = 0
    stack_need: int = 0

    def last_threads(self):
        return self.warp_size if self.tlast in (0, self.warp_size) else self.tlast

    def ntid(self):
        return (self.wpw - 1) * self.warp_size + self.last_threads()

    def lanes(self, widx):
        return self.warp_size if widx < self.wpw - 1 else self.last_threads()

    def reject(self):
        if self.num_wg == 0 or self.wpw == 0 or self.num_wg * self.wpw > self.num_warps:
            return LREJ_DIMS
        if self.tlast > self.warp_size:
            return LREJ_LAST
        if self.stack_need and self.stack_need > self.stack_depth:
            return LREJ_STACK
        return LREJ_NONE


# ---------------------------------------------------------------------------
# shared instruction semantics
# ---------------------------------------------------------------------------
def alu(name, a, b):
    if name == "add":  return (a + b) & MASK32
    if name == "sub":  return (a - b) & MASK32
    if name == "mul":  return (a * b) & MASK32
    if name == "and":  return a & b
    if name == "or":   return a | b
    if name == "xor":  return a ^ b
    if name == "shl":  return (a << (b & 31)) & MASK32
    if name == "shr":  return a >> (b & 31)
    if name == "sar":  return (sext(a, 32) >> (b & 31)) & MASK32
    if name == "slt":  return 1 if sext(a, 32) < sext(b, 32) else 0
    if name == "sltu": return 1 if a < b else 0
    raise AssertionError(name)


def s2r(cfg, sid, wg, widx, lane):
    tid = widx * cfg.warp_size + lane
    if sid == 0: return lane
    if sid == 1: return tid
    if sid == 2: return cfg.ntid()
    if sid == 3: return wg
    if sid == 4: return cfg.num_wg
    if sid == 5: return widx
    if sid == 6: return wg * (cfg.wpw * cfg.warp_size) + tid
    if sid == 7: return wg * cfg.wpw + widx
    return 0


def fetch(prog, pc):
    """-> (word, err)"""
    if pc >= IMEM_WORDS:
        return 0, True
    return (prog[pc] if pc < len(prog) else ILLEGAL_WORD), False


def fields(w):
    return (OPNAME.get((w >> 27) & 31), (w >> 22) & 31, (w >> 17) & 31, (w >> 12) & 31,
            w & 0x1FFFF, w & 0xFFF)


class Mem:
    def __init__(self, cfg, gmem_init=None):
        self.cfg = cfg
        self.g = [0] * GMEM_WORDS
        if gmem_init:
            for i, v in enumerate(gmem_init):
                self.g[i] = v & MASK32
        self.s = [[0] * SMEM_WORDS for _ in range(cfg.num_wg)]


def mem_op(mem, name, wg, regs, rs1, rs2, rd, imm12):
    """Execute one load/store for a single thread. Returns loaded value or None."""
    addr = (regs[rs1] + sext(imm12, 12))
    if name == "ldg":
        regs[rd] = mem.g[addr & (GMEM_WORDS - 1)] if rd else 0
    elif name == "lds":
        regs[rd] = mem.s[wg][addr & (SMEM_WORDS - 1)] if rd else 0
    elif name == "stg":
        mem.g[addr & (GMEM_WORDS - 1)] = regs[rs2]
    elif name == "sts":
        mem.s[wg][addr & (SMEM_WORDS - 1)] = regs[rs2]


def alu_op(cfg, name, regs, rd, rs1, rs2, imm17, wg, widx, lane):
    if name == "addi":
        v = (regs[rs1] + sext(imm17, 17)) & MASK32
    elif name == "lui":
        v = (imm17 << 15) & MASK32
    elif name == "s2r":
        v = s2r(cfg, imm17, wg, widx, lane) & MASK32
    else:
        v = alu(name, regs[rs1], regs[rs2])
    if rd:
        regs[rd] = v


# ---------------------------------------------------------------------------
@dataclass
class State:
    cfg: Cfg
    regs: dict = field(default_factory=dict)       # (warp, lane) -> [32]
    mem: Mem = None
    warp_fault: dict = field(default_factory=dict)
    trace: dict = field(default_factory=dict)      # warp -> [(pc, mask)]
    kernel_fault: int = 0
    reject: int = 0
    stk_hwm: int = 0
    n_branch: int = 0
    n_div: int = 0
    n_sync: int = 0
    n_bar_rel: int = 0
    n_instr: int = 0
    n_fault: int = 0


def _new_regs(cfg, st):
    for wg in range(cfg.num_wg):
        for wi in range(cfg.wpw):
            w = wg * cfg.wpw + wi
            for lane in range(cfg.lanes(wi)):
                st.regs[(w, lane)] = [0] * NUM_REGS


# ---------------------------------------------------------------------------
# MIMD golden model
# ---------------------------------------------------------------------------
def run_mimd(prog, cfg, gmem_init=None, mem=None, max_steps=20_000_000):
    st = State(cfg)
    st.reject = cfg.reject()
    if st.reject:
        return st
    st.mem = mem if mem is not None else Mem(cfg, gmem_init)
    _new_regs(cfg, st)
    for wg in range(cfg.num_wg):
        for wi in range(cfg.wpw):
            st.warp_fault[wg * cfg.wpw + wi] = F_NONE
    steps = 0
    for wg in range(cfg.num_wg):
        threads = []
        for wi in range(cfg.wpw):
            for lane in range(cfg.lanes(wi)):
                threads.append({"w": wg * cfg.wpw + wi, "wi": wi, "lane": lane, "pc": cfg.entry,
                                "ss": [], "st": "run"})
        while True:
            alive = [t for t in threads if t["st"] != "exit"]
            if not alive:
                break
            if all(t["st"] == "bar" for t in alive):
                for t in alive:
                    t["st"] = "run"
                continue
            progressed = False
            for t in alive:
                if t["st"] != "run":
                    continue
                regs = st.regs[(t["w"], t["lane"])]
                while t["st"] == "run":
                    steps += 1
                    if steps > max_steps:
                        raise RefError("MIMD step limit exceeded")
                    word, err = fetch(prog, t["pc"])
                    if err:
                        raise RefError(f"fetch error pc={t['pc']}")
                    name, rd, rs1, rs2, imm17, imm12 = fields(word)
                    if name is None:
                        raise RefError(f"illegal instruction pc={t['pc']} {word:08x}")
                    pc = t["pc"]
                    tgt = (pc + 1 + sext(imm17, 17)) & 0xFFFF
                    t["pc"] = (pc + 1) & 0xFFFF
                    if name == "nop":
                        pass
                    elif name == "exit":
                        t["st"] = "exit"
                    elif name == "ssy":
                        t["ss"].append(tgt)
                    elif name == "sync":
                        if not t["ss"]:
                            raise RefError(f"SYNC with empty sync stack pc={pc}")
                        t["pc"] = t["ss"].pop()
                    elif name == "bar":
                        t["st"] = "bar"
                    elif name == "jmp":
                        t["pc"] = tgt
                    elif name in ("bnz", "bz"):
                        v = regs[rs1]
                        if (v != 0) == (name == "bnz"):
                            t["pc"] = tgt
                    elif name in ("ldg", "lds", "stg", "sts"):
                        mem_op(st.mem, name, wg, regs, rs1, rs2, rd, imm12)
                    else:
                        alu_op(cfg, name, regs, rd, rs1, rs2, imm17, wg, t["wi"], t["lane"])
                progressed = True
            if not progressed:
                raise RefError("MIMD deadlock")
    return st


# ---------------------------------------------------------------------------
# SIMT lock-step model (mirrors the RTL semantics)
# ---------------------------------------------------------------------------
class Warp:
    def __init__(self, w, wg, wi, nl, entry):
        self.w, self.wg, self.wi, self.nl = w, wg, wi, nl
        self.pc = entry
        self.live = self.active = (1 << nl) - 1
        self.stack = []        # list of (kind, pc, mask); kind 0=TOKEN 1=DIV
        self.state = "run"     # run | bar | done
        self.fault = F_NONE


def _search(stack, live):
    for i in range(len(stack) - 1, -1, -1):
        if stack[i][2] & live:
            return i
    return None


def run_simt(prog, cfg, gmem_init=None, mem=None, max_steps=20_000_000):
    st = State(cfg)
    st.reject = cfg.reject()
    if st.reject:
        return st
    st.mem = mem if mem is not None else Mem(cfg, gmem_init)
    _new_regs(cfg, st)
    warps = []
    for wg in range(cfg.num_wg):
        for wi in range(cfg.wpw):
            w = Warp(wg * cfg.wpw + wi, wg, wi, cfg.lanes(wi), cfg.entry)
            warps.append(w)
            st.trace[w.w] = []
    wg_killed = set()

    def fault(wp, cause):
        wp.fault = cause
        wp.state = "done"
        wp.live = wp.active = 0
        wp.stack = []
        st.kernel_fault = 1
        st.n_fault += 1
        wg_killed.add(wp.wg)
        for o in warps:
            if o.wg == wp.wg and o.state != "done":
                o.state = "done"
                o.fault = F_WG_KILLED
                o.live = o.active = 0
                o.stack = []

    steps = 0
    while True:
        running = [wp for wp in warps if wp.state == "run"]
        if not running:
            # barrier release?
            released = False
            for wg in range(cfg.num_wg):
                members = [wp for wp in warps if wp.wg == wg]
                if wg in wg_killed:
                    continue
                if any(wp.state == "bar" for wp in members) and all(wp.state in ("bar", "done") for wp in members):
                    for wp in members:
                        if wp.state == "bar":
                            wp.state = "run"
                    st.n_bar_rel += 1
                    released = True
            if released:
                continue
            if any(wp.state == "bar" for wp in warps):
                raise RefError("SIMT barrier deadlock")
            break
        for wp in running:
            steps += 1
            if steps > max_steps:
                raise RefError("SIMT step limit exceeded")
            if wp.state != "run":
                continue
            word, err = fetch(prog, wp.pc)
            if err:
                fault(wp, F_FETCH)
                continue
            name, rd, rs1, rs2, imm17, imm12 = fields(word)
            if name is None:
                fault(wp, F_ILLEGAL)
                continue
            pc = wp.pc
            tgt = (pc + 1 + sext(imm17, 17)) & 0xFFFF
            nxt = (pc + 1) & 0xFFFF
            lanes = [l for l in range(wp.nl) if (wp.active >> l) & 1]

            def executed():
                st.trace[wp.w].append((pc, wp.active))
                st.n_instr += 1

            if name == "nop":
                executed(); wp.pc = nxt
            elif name == "jmp":
                executed(); wp.pc = tgt
            elif name == "ssy":
                if len(wp.stack) == cfg.stack_depth:
                    fault(wp, F_STK_OVF); continue
                executed()
                wp.stack.append((0, tgt, wp.active))
                st.stk_hwm = max(st.stk_hwm, len(wp.stack))
                wp.pc = nxt
            elif name == "sync":
                if not wp.stack:
                    fault(wp, F_STK_UNF); continue
                i = _search(wp.stack, wp.live)
                if i is None:
                    fault(wp, F_LOST); continue
                executed()
                st.n_sync += 1
                kind, epc, emask = wp.stack[i]
                del wp.stack[i:]
                wp.pc = epc
                wp.active = emask & wp.live
            elif name == "exit":
                new_live = wp.live & ~wp.active
                if new_live == 0:
                    executed()
                    wp.live = wp.active = 0
                    wp.stack = []
                    wp.state = "done"
                else:
                    i = _search(wp.stack, new_live)
                    if i is None:
                        fault(wp, F_LOST); continue
                    executed()
                    kind, epc, emask = wp.stack[i]
                    del wp.stack[i:]
                    wp.live = new_live
                    wp.pc = epc
                    wp.active = emask & new_live
            elif name == "bar":
                if wp.active != wp.live:
                    fault(wp, F_DIV_BAR); continue
                executed()
                wp.state = "bar"
                wp.pc = nxt
            elif name in ("bnz", "bz"):
                cond = 0
                for l in lanes:
                    v = st.regs[(wp.w, l)][rs1]
                    if (v != 0) == (name == "bnz"):
                        cond |= 1 << l
                nt = wp.active & ~cond
                if cond == 0:
                    executed(); st.n_branch += 1; wp.pc = nxt
                elif nt == 0:
                    executed(); st.n_branch += 1; wp.pc = tgt
                else:
                    if not wp.stack:
                        # RTL counts the divergent branch resolution before the fault
                        st.n_branch += 1; st.n_div += 1
                        st.trace[wp.w].append((pc, wp.active)); st.n_instr += 1
                        fault(wp, F_NO_REGION); continue
                    if len(wp.stack) == cfg.stack_depth:
                        st.n_branch += 1; st.n_div += 1
                        st.trace[wp.w].append((pc, wp.active)); st.n_instr += 1
                        fault(wp, F_STK_OVF); continue
                    executed()
                    st.n_branch += 1; st.n_div += 1
                    wp.stack.append((1, tgt, cond))
                    st.stk_hwm = max(st.stk_hwm, len(wp.stack))
                    wp.active = nt
                    wp.pc = nxt
            elif name in ("ldg", "lds", "stg", "sts"):
                executed()
                for l in lanes:
                    mem_op(st.mem, name, wp.wg, st.regs[(wp.w, l)], rs1, rs2, rd, imm12)
                wp.pc = nxt
            else:
                executed()
                for l in lanes:
                    alu_op(cfg, name, st.regs[(wp.w, l)], rd, rs1, rs2, imm17, wp.wg, wp.wi, l)
                wp.pc = nxt
    for wp in warps:
        st.warp_fault[wp.w] = wp.fault
    return st


# ---------------------------------------------------------------------------
# state dump (shared text format with the RTL testbench)
# ---------------------------------------------------------------------------
def dump_state(st, with_trace=True):
    cfg = st.cfg
    out = [f"STATUS fault={st.kernel_fault} reject={st.reject}"]
    if st.reject:
        return out
    for w in sorted(st.warp_fault):
        out.append(f"WARP {w} fault={st.warp_fault[w]}")
    for (w, lane) in sorted(st.regs):
        for r, v in enumerate(st.regs[(w, lane)]):
            if v:
                out.append(f"REG {w} {lane} {r} {v:08x}")
    for a, v in enumerate(st.mem.g):
        if v:
            out.append(f"GMEM {a:04x} {v:08x}")
    for wg in range(cfg.num_wg):
        for a, v in enumerate(st.mem.s[wg]):
            if v:
                out.append(f"SMEM {wg} {a:03x} {v:08x}")
    if with_trace:
        for w in sorted(st.trace):
            for pc, m in st.trace[w]:
                out.append(f"TRACE {w} {pc:04x} {m:08x}")
    return out


def counters(st):
    return {"issued": st.n_instr, "branch": st.n_branch, "div": st.n_div, "reconv": st.n_sync,
            "stk_hwm": st.stk_hwm, "bar_rel": st.n_bar_rel, "fault": st.n_fault}
