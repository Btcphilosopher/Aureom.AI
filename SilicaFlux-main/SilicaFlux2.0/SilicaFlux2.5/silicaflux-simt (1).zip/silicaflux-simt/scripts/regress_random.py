#!/usr/bin/env python3
"""Random legal-program regression: RTL vs the two reference simulators.

For every seed: generate a structured random program + launch shape + read-only
table, run (a) the per-thread MIMD model, (b) the lock-step SIMT model, and
(c) the RTL under a downstream timing profile. The RTL must match the MIMD
model's architectural state, and the SIMT model's state, per-warp issue trace
and counters (issued / branches / divergent branches / reconvergences / stack
high-water mark / barrier releases).
"""
import argparse
import os
import random
import sys
import time
from concurrent.futures import ProcessPoolExecutor

sys.path.insert(0, os.path.dirname(__file__))
import sfrun                                   # noqa: E402
from sfrun import ROOT                         # noqa: E402
from sfgen import Gen, random_cfg, gen_table   # noqa: E402
from sfisa import assemble, write_hex          # noqa: E402
import sfref                                   # noqa: E402


def one(args):
    cfgname, profile, seed, outroot, rtl_dir, build_root, gen_kw = args
    hw = sfrun.CONFIGS[cfgname]
    exe = sfrun.build(hw, rtl_dir=rtl_dir, build_root=build_root)
    rng = random.Random(seed)
    kw = dict(gen_kw)
    kw.setdefault("max_depth", min(4, hw.stack_depth // 2))
    kw["warp_size"] = hw.warp_size
    text = Gen(seed, **kw).generate()
    words, _, _ = assemble(text)
    nwg, wpw, tl = random_cfg(rng, hw.num_warps, hw.warp_size)
    kcfg = sfref.Cfg(num_warps=hw.num_warps, warp_size=hw.warp_size, stack_depth=hw.stack_depth,
                     num_wg=nwg, wpw=wpw, tlast=tl)
    tab = gen_table(seed)
    d = os.path.join(outroot, f"{cfgname}_{profile}")
    os.makedirs(d, exist_ok=True)
    tag = f"s{seed}"
    hexf = os.path.join(d, tag + ".hex")
    gmf = os.path.join(d, tag + ".gmem")
    write_hex(words, hexf)
    sfrun.write_gmem_hex(tab, gmf)
    try:
        m = sfref.run_mimd(words, kcfg, tab)
        s = sfref.run_simt(words, kcfg, tab)
    except sfref.RefError as e:
        return (seed, ["generator/ref error: " + str(e)], None)
    problems = []
    if sfref.dump_state(m, False) != sfref.dump_state(s, False):
        problems.append("reference models disagree (generator bug)")
    res = sfrun.run_rtl(exe, hexf, kcfg, profile=profile, seed=seed, gmem_hex=gmf, outdir=d, tag=tag)
    if not sfrun.tb_ok(res):
        problems.append("TB failure: " + " | ".join(l for l in res.stdout.splitlines()
                                                     if "ERROR" in l or "ASSERT" in l or "FAIL" in l or "RESULT" in l)[:600])
    else:
        problems += sfrun.compare(res, s)
        problems += ["vs MIMD: " + x for x in sfrun.compare(res, m, check_trace=False, check_perf=False)]
    cov = dict(div=s.n_div, branch=s.n_branch, hwm=s.stk_hwm, bar=s.n_bar_rel, sync=s.n_sync, instr=s.n_instr,
               warps=kcfg.num_wg * kcfg.wpw, cycles=res.result.get("cycles", 0) if res.result else 0,
               exits=sum(1 for w in s.trace if s.trace[w] and False))
    if not problems:
        for f in (hexf, gmf, os.path.join(d, tag + ".out")):
            try:
                os.remove(f)
            except OSError:
                pass
    else:
        open(os.path.join(d, tag + ".asm"), "w").write(text)
    return (seed, problems, cov)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="rr8", choices=sfrun.CONFIGS)
    ap.add_argument("--profile", default="mid", choices=sfrun.PROFILES)
    ap.add_argument("--n", type=int, default=40)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--out", default=os.path.join(ROOT, "out"))
    ap.add_argument("--rtl", default=None)
    ap.add_argument("--build-root", default=None)
    ap.add_argument("--stmts", type=int, default=40)
    ap.add_argument("--no-bar", action="store_true")
    ap.add_argument("--no-exit", action="store_true")
    ap.add_argument("--div", type=float, default=1.0)
    a = ap.parse_args()
    gen_kw = dict(n_stmts=a.stmts, allow_bar=not a.no_bar, allow_exit=not a.no_exit, div_weight=a.div)
    sfrun.build(sfrun.CONFIGS[a.config], rtl_dir=a.rtl, build_root=a.build_root)
    t0 = time.time()
    seeds = [a.seed * 1000003 + i for i in range(a.n)]
    jobs = [(a.config, a.profile, s, a.out, a.rtl, a.build_root, gen_kw) for s in seeds]
    bad = 0
    tot = dict(div=0, branch=0, bar=0, sync=0, instr=0, cycles=0)
    hwm = {}
    with ProcessPoolExecutor(max_workers=a.jobs) as ex:
        for seed, problems, cov in ex.map(one, jobs):
            if problems:
                bad += 1
                print(f"FAIL seed={seed}")
                for p in problems[:8]:
                    print("   ", p)
            if cov:
                for k in tot:
                    tot[k] += cov[k]
                hwm[cov["hwm"]] = hwm.get(cov["hwm"], 0) + 1
    dt = time.time() - t0
    print(f"[{a.config}/{a.profile}] {a.n} programs, {bad} failed, {dt:.1f}s | coverage: "
          f"branches={tot['branch']} divergent={tot['div']} reconv={tot['sync']} barrier-releases={tot['bar']} "
          f"warp-instrs={tot['instr']} rtl-cycles={tot['cycles']} stack-hwm-histogram={dict(sorted(hwm.items()))}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
