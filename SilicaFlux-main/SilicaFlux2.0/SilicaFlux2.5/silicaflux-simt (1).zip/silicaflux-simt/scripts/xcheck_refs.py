#!/usr/bin/env python3
"""Cross-check the two reference models (per-thread MIMD vs lock-step SIMT stack)
on random legal programs. Independent of the RTL; validates generator and spec."""
import argparse, os, random, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "model"))
from sfisa import assemble
from sfgen import Gen, random_cfg, gen_table
from sfref import Cfg, run_mimd, run_simt, dump_state

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=50)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--warps", type=int, default=8)
    ap.add_argument("--ws", type=int, default=32)
    ap.add_argument("--depth", type=int, default=8)
    a = ap.parse_args()
    bad = 0; t0 = time.time(); dyn = 0
    for i in range(a.n):
        seed = a.seed * 100003 + i
        rng = random.Random(seed)
        text = Gen(seed, max_depth=min(3, a.depth // 2), warp_size=a.ws).generate()
        words, _, _ = assemble(text)
        nwg, wpw, tl = random_cfg(rng, a.warps, a.ws)
        cfg = Cfg(num_warps=a.warps, warp_size=a.ws, stack_depth=a.depth, num_wg=nwg, wpw=wpw, tlast=tl)
        tab = gen_table(seed)
        m = run_mimd(words, cfg, tab)
        s = run_simt(words, cfg, tab)
        dm = dump_state(m, with_trace=False); ds = dump_state(s, with_trace=False)
        dyn += s.n_instr
        if dm != ds or s.kernel_fault:
            bad += 1
            print(f"MISMATCH seed={seed} cfg={cfg} fault={s.kernel_fault} wf={s.warp_fault}")
            sm, ss = set(dm), set(ds)
            for l in sorted(sm - ss)[:5]: print("  mimd only:", l)
            for l in sorted(ss - sm)[:5]: print("  simt only:", l)
    print(f"{a.n} programs, {bad} mismatches, {dyn} warp-instrs, {time.time()-t0:.1f}s")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
