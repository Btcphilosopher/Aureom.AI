"""Build / run / compare helpers shared by the directed suite, the random
regression and the mutation script."""
import hashlib
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "model"))

import sfref                                   # noqa: E402
from sfisa import assemble, write_hex          # noqa: E402

RTL_FILES = ["sf_simt_pkg.sv", "sf_simt_stack.sv", "sf_warp_arb.sv", "sf_simt_barrier.sv",
             "sf_simt_warp_ctx.sv", "sf_simt_ctrl.sv"]
TB_FILES = ["sf_simt_dsm.sv", "sf_simt_checker.sv", "tb_simt.sv"]


@dataclass(frozen=True)
class HwCfg:
    name: str
    num_warps: int = 8
    warp_size: int = 32
    stack_depth: int = 8
    num_slots: int = 4
    policy: int = 0          # 0 = RR, 1 = AGE


CONFIGS = {
    "rr8":    HwCfg("rr8"),
    "age8":   HwCfg("age8", policy=1),
    "rr16w8": HwCfg("rr16w8", num_warps=16, warp_size=8, stack_depth=6, num_slots=2),
    "age4":   HwCfg("age4", num_warps=4, stack_depth=8, num_slots=3, policy=1),
    "rr6":    HwCfg("rr6", num_warps=6, warp_size=16, stack_depth=4, num_slots=4),
}

PROFILES = {
    "ideal": dict(LAT_IF=1, LAT_ALU=1, LAT_MEM=1, RDY_PCT=100, IFRDY_PCT=100, SKIP_PCT=0),
    "mid":   dict(LAT_IF=3, LAT_ALU=4, LAT_MEM=12, RDY_PCT=70, IFRDY_PCT=80, SKIP_PCT=20),
    "slow":  dict(LAT_IF=8, LAT_ALU=6, LAT_MEM=40, RDY_PCT=40, IFRDY_PCT=50, SKIP_PCT=40),
    "memhv": dict(LAT_IF=2, LAT_ALU=2, LAT_MEM=60, RDY_PCT=60, IFRDY_PCT=90, SKIP_PCT=10),
    # heavy back-pressure: backend ports ready ~20% of cycles (forced at least every 5th): many candidates
    # blocked only by their port, the situation that starves a loose round robin
    "starve": dict(LAT_IF=2, LAT_ALU=3, LAT_MEM=10, RDY_PCT=20, IFRDY_PCT=60, SKIP_PCT=10),
}


def _env():
    e = dict(os.environ)
    return e


def _sources(rtl_dir):
    rtl = [os.path.join(rtl_dir, f) for f in RTL_FILES]
    tb = [os.path.join(ROOT, "tb", f) for f in TB_FILES]
    return rtl + tb


def build(cfg, rtl_dir=None, build_root=None, force=False, quiet=True):
    """Verilate + compile the testbench for a hardware configuration. Returns binary path."""
    rtl_dir = rtl_dir or os.environ.get("SF_RTL_DIR") or os.path.join(ROOT, "rtl")
    build_root = build_root or os.environ.get("SF_BUILD_ROOT") or os.path.join(ROOT, "build")
    d = os.path.join(build_root, cfg.name)
    exe = os.path.join(d, "Vtb")
    srcs = _sources(rtl_dir)
    stamp = hashlib.sha1()
    for s in srcs:
        stamp.update(open(s, "rb").read())
    stamp.update(repr(cfg).encode())
    opt = os.environ.get("SF_OPT", "-Os")          # C++ optimisation level of the simulation model
    stamp.update(opt.encode())
    stamp_f = os.path.join(d, "stamp")
    if not force and os.path.exists(exe) and os.path.exists(stamp_f) and open(stamp_f).read() == stamp.hexdigest():
        return exe
    os.makedirs(d, exist_ok=True)
    cmd = ["verilator", "--cc", "--exe", "--main", "--timing", "--assert", "-Wno-fatal", "-Wno-lint",
           "-Wno-style", "-Wno-BLKSEQ", "-Wno-INITIALDLY", "-Wno-TIMESCALEMOD", "--x-assign", "unique",
           "--x-initial", "unique", "-O2", "-Mdir", d, "--top-module", "tb_simt", "-o", "Vtb",
           f"-GNUM_WARPS={cfg.num_warps}", f"-GWARP_SIZE={cfg.warp_size}", f"-GSTACK_DEPTH={cfg.stack_depth}",
           f"-GNUM_SLOTS={cfg.num_slots}", f"-GPOLICY={cfg.policy}",
           "-I" + rtl_dir, "-I" + os.path.join(ROOT, "tb")] + srcs
    r = subprocess.run(cmd, capture_output=True, text=True, env=_env())
    if r.returncode != 0:
        raise RuntimeError("verilator failed:\n" + r.stdout[-3000:] + r.stderr[-3000:])
    for f in os.listdir(d):                          # stale objects / precompiled headers from other flags
        if f.endswith((".gch", ".o", ".d", ".a")) or f == "Vtb":
            os.remove(os.path.join(d, f))
    r = subprocess.run(["make", "-C", d, "-f", "Vtb_simt.mk", "-j4", "CFG_CXXFLAGS_PCH_I=-include",
                        f"OPT_FAST={opt}", f"OPT_SLOW={opt}"], capture_output=True, text=True, env=_env())
    if r.returncode != 0 or not os.path.exists(exe):
        raise RuntimeError("compile failed:\n" + r.stdout[-3000:] + r.stderr[-3000:])
    open(stamp_f, "w").write(stamp.hexdigest())
    return exe


@dataclass
class RtlResult:
    rc: int
    stdout: str
    result: dict = field(default_factory=dict)
    lines: list = field(default_factory=list)
    perf: dict = field(default_factory=dict)
    trace: dict = field(default_factory=dict)       # warp -> [(pc, mask)]
    order: list = field(default_factory=list)       # warp ids in global issue order
    status: dict = field(default_factory=dict)
    warp_fault: dict = field(default_factory=dict)
    arch: list = field(default_factory=list)         # REG/GMEM/SMEM lines


def run_rtl(exe, hexfile, kcfg, profile="ideal", seed=1, gmem_hex=None, outdir=".", tag="run",
            extra=(), timeout=300):
    out = os.path.join(outdir, tag + ".out")
    args = [exe, f"+PROG={hexfile}", f"+OUT={out}", f"+NUM_WG={kcfg.num_wg}", f"+WPW={kcfg.wpw}",
            f"+TLAST={kcfg.tlast}", f"+ENTRY={kcfg.entry}", f"+STKNEED={kcfg.stack_need}", f"+SEED={seed}"]
    for k, v in PROFILES[profile].items():
        args.append(f"+{k}={v}")
    if gmem_hex:
        args.append(f"+GMEM={gmem_hex}")
    args += list(extra)
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return RtlResult(-9, "TIMEOUT (wall)")
    res = RtlResult(p.returncode, p.stdout + p.stderr)
    m = re.search(r"\[TB\] RESULT (.*)", res.stdout)
    if m:
        res.result = {k: int(v) for k, v in (kv.split("=") for kv in m.group(1).split())}
    if os.path.exists(out):
        for ln in open(out).read().splitlines():
            t = ln.split()
            if not t:
                continue
            if t[0] == "PERF":
                res.perf[t[1]] = int(t[2])
            elif t[0] == "TRACE":
                res.trace.setdefault(int(t[1]), []).append((int(t[2], 16), int(t[3], 16)))
                res.order.append(int(t[1]))
            elif t[0] == "STATUS":
                res.status = dict(kv.split("=") for kv in t[1:])
                res.status = {k: int(v) for k, v in res.status.items()}
            elif t[0] == "WARP":
                res.warp_fault[int(t[1])] = int(t[2].split("=")[1])
            else:
                res.arch.append(ln)
            res.lines.append(ln)
    return res


def tb_ok(res):
    r = res.result
    return (res.rc == 0 and r and r.get("timeout") == 0 and r.get("assert_err") == 0 and
            r.get("chk_errs") == 0)


def compare(res, st, check_trace=True, check_perf=True, check_arch=True, arch_filter=None):
    """Compare an RTL result with a sfref State. Returns list of mismatch strings."""
    bad = []
    if res.status.get("reject", 0) != st.reject:
        bad.append(f"reject cause rtl={res.status.get('reject')} ref={st.reject}")
        return bad
    if st.reject:
        return bad
    if res.status.get("fault", 0) != st.kernel_fault:
        bad.append(f"kernel fault rtl={res.status.get('fault')} ref={st.kernel_fault}")
    ref_lines = sfref.dump_state(st, with_trace=False)
    ref_arch = [l for l in ref_lines if l.split()[0] in ("REG", "GMEM", "SMEM")]
    if check_arch:
        a, b = set(res.arch), set(ref_arch)
        if arch_filter:
            a = {l for l in a if arch_filter(l)}
            b = {l for l in b if arch_filter(l)}
        if a != b:
            only_rtl, only_ref = sorted(a - b), sorted(b - a)
            bad.append(f"architectural state differs: {len(only_rtl)} lines only in RTL, {len(only_ref)} only in ref")
            for l in only_rtl[:4]:
                bad.append("   rtl only: " + l)
            for l in only_ref[:4]:
                bad.append("   ref only: " + l)
    if check_trace:
        for w in sorted(set(st.trace) | set(res.trace)):
            rt, ft = res.trace.get(w, []), st.trace.get(w, [])
            if rt != ft:
                i = next((i for i, (x, y) in enumerate(zip(rt, ft)) if x != y), min(len(rt), len(ft)))
                bad.append(f"warp {w} issue trace differs at #{i}: rtl={rt[i] if i < len(rt) else None} "
                           f"ref={ft[i] if i < len(ft) else None} (len rtl={len(rt)} ref={len(ft)})")
    if check_perf and not st.kernel_fault:
        c = sfref.counters(st)
        p = res.perf
        for key, pk in (("issued", "issued"), ("branch", "branches"), ("div", "div_branches"),
                        ("reconv", "reconv"), ("stk_hwm", "stack_hwm"), ("bar_rel", "barrier_releases")):
            if p.get(pk) != c[key]:
                bad.append(f"counter {pk}: rtl={p.get(pk)} ref={c[key]}")
    return bad


def load_prog(path_or_text, is_text=False):
    text = path_or_text if is_text else open(path_or_text).read()
    words, labels, listing = assemble(text)
    return words


def write_gmem_hex(table, path):
    with open(path, "w") as f:
        for v in table:
            f.write(f"{v:08x}\n")
