#!/usr/bin/env python3
"""Full regression: lint -> reference cross-check -> directed suite -> random regression.

  python3 scripts/regress_all.py            # full (several minutes)
  python3 scripts/regress_all.py --quick    # smoke subset
"""
import argparse
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
PY = sys.executable
ENV = dict(os.environ, PYTHONPATH=os.path.join(ROOT, "model") + ":" + HERE)

RANDOM_PLAN = [                      # (config, profile, programs)
    ("rr8", "ideal", 60), ("rr8", "mid", 60), ("rr8", "slow", 60), ("rr8", "memhv", 40),
    ("age8", "ideal", 40), ("age8", "mid", 60), ("age8", "slow", 60), ("age8", "memhv", 40),
    ("rr16w8", "mid", 60), ("rr16w8", "slow", 40), ("rr16w8", "starve", 80), ("rr8", "starve", 80),
    ("age8", "starve", 60), ("rr6", "starve", 40),
    ("age4", "mid", 60), ("age4", "slow", 40),
    ("rr6", "mid", 60), ("rr6", "slow", 40),
]


def step(title, cmd):
    t0 = time.time()
    print(f"\n=== {title}", flush=True)
    p = subprocess.run(cmd, env=ENV, cwd=ROOT, capture_output=True, text=True)
    out = (p.stdout + p.stderr).strip().splitlines()
    for l in out[-14:]:
        print("   ", l)
    ok = p.returncode == 0
    print(f"=== {title}: {'PASS' if ok else 'FAIL'} ({time.time() - t0:.0f}s)", flush=True)
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    ok = True
    ok &= step("lint (verilator -Wall)", ["make", "-s", "lint"])
    ok &= step("ISA / package sync", [PY, os.path.join(ROOT, "tests", "test_isa_sync.py")])
    ok &= step("reference models cross-check (MIMD vs SIMT)",
               [PY, os.path.join(HERE, "xcheck_refs.py"), "--n", "30" if a.quick else "150"])
    cfgs = ["rr8", "age8"] if a.quick else ["rr8", "age8", "rr16w8", "age4", "rr6"]
    cmd = [PY, os.path.join(ROOT, "tests", "directed_suite.py"), "--jobs", str(a.jobs)]
    for c in cfgs:
        cmd += ["--config", c]
    ok &= step("directed suite " + ",".join(cfgs), cmd)
    plan = RANDOM_PLAN[:2] + RANDOM_PLAN[4:6] if a.quick else RANDOM_PLAN
    for cfg, prof, n in plan:
        n = max(10, n // 4) if a.quick else n
        ok &= step(f"random {cfg}/{prof} x{n}",
                   [PY, os.path.join(HERE, "regress_random.py"), "--config", cfg, "--profile", prof,
                    "--n", str(n), "--seed", "5", "--jobs", str(a.jobs)])
    print("\nREGRESSION", "PASSED" if ok else "FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
