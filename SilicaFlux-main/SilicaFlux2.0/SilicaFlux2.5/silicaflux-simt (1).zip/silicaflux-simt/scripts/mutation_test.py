#!/usr/bin/env python3
"""Mutation testing of the verification environment.

Each mutant is a small textual defect injected into a *copy* of the RTL (the real RTL is
never modified). The directed suite and a short random regression are then run against the
mutated design; a mutant is KILLED if any check fails. A surviving mutant means the
verification environment has a hole (or the mutation is behaviourally equivalent).
"""
import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))

# (id, description, file, old, new, hardware config)
MUTANTS = [
    ("M01_bar_premature", "barrier unit tolerates one missing member (off-by-one participant count)",
     "sf_simt_barrier.sv",
     ["      logic is_killed;\n", "      is_killed = 1'b0;\n",
      "          if (!(at_bar_i[w] || done_i[w])) all_in = 1'b0;"],
     ["      logic is_killed;\n      logic skip_q;\n", "      is_killed = 1'b0;\n      skip_q    = 1'b0;\n",
      "          if (!(at_bar_i[w] || done_i[w])) begin if (skip_q) all_in = 1'b0; skip_q = 1'b1; end"], "rr8"),
    ("M02_bar_drain_counted", "barrier counts a DRAINING warp as exited (its stores may still be in flight)",
     "sf_simt_ctrl.sv",
     ["  sf_simt_barrier #(.NUM_WARPS(NUM_WARPS)) u_barrier (", "    .done_i       (done_vec),"],
     ["  logic [NUM_WARPS-1:0] drain_mut;\n  always_comb for (int w = 0; w < NUM_WARPS; w++) drain_mut[w] = (state_vec[w] == W_DRAIN);\n  sf_simt_barrier #(.NUM_WARPS(NUM_WARPS)) u_barrier (",
      "    .done_i       (done_vec | drain_mut),"], "rr8"),
    ("M02b_bar_deadlock", "barrier never counts exited warps (deadlock when a warp exits)",
     "sf_simt_barrier.sv", "if (!(at_bar_i[w] || done_i[w])) all_in = 1'b0;", "if (!at_bar_i[w]) all_in = 1'b0;", "rr8"),
    ("M03_dup_issue", "instruction buffer not invalidated at issue (duplicate issue)",
     "sf_simt_warp_ctx.sv", "    if (grant_i) begin\n      n_ibuf_valid = 1'b0;",
     "    if (grant_i) begin\n      n_ibuf_valid = ibuf_valid_q;", "rr8"),
    ("M04_waw_ignored", "WAW hazard not checked in the scoreboard",
     "sf_simt_warp_ctx.sv", " || (di.wr_rd && pend_q[rd]);\n  assign haz_mem", ";\n  assign haz_mem", "rr8"),
    ("M05_stack_no_live", "SYNC restores mask without & live (resurrects exited threads)",
     "sf_simt_warp_ctx.sv", "n_active = stk_found_mask & live_q;", "n_active = stk_found_mask;", "rr8"),
    ("M06_bar_no_drain", "BAR does not wait for in-flight operations to retire",
     "sf_simt_warp_ctx.sv", "assign bar_blk  = is_bar_o && (|slot_v_q);", "assign bar_blk  = 1'b0;", "rr8"),
    ("M07_cmpl_any_slot", "completion retires without checking the slot is valid",
     "sf_simt_warp_ctx.sv", "c_ok[p] = slot_v_q[cmpl_slot_i[p]];", "c_ok[p] = 1'b1;", "rr8"),
    ("M08_rr_stuck", "round-robin pointer never advances",
     "sf_warp_arb.sv", "else if (found_w)   ptr_q <= nxt_ptr;", "else if (1'b0)       ptr_q <= nxt_ptr;", "rr8"),
    ("M09_swap_masks", "divergent branch defers the wrong thread set",
     "sf_simt_warp_ctx.sv", "stk_push_mask = br_cond;", "stk_push_mask = br_nt;", "rr8"),
    ("M10_age_update", "age matrix update incomplete (order no longer total)",
     "sf_warp_arb.sv", "                  older_q[j][k] <= 1'b1;\n", "", "age8"),
    ("M11_no_kill_gate", "faulted workgroup keeps issuing (kill not gating candidates)",
     "sf_simt_warp_ctx.sv", "(state_q == W_RUN) && ibuf_valid_q && core_run_i && !kill_i;",
     "(state_q == W_RUN) && ibuf_valid_q && core_run_i;", "rr8"),
    ("M12_div_bar_ok", "BAR accepted from a diverged warp",
     "sf_simt_warp_ctx.sv", "if (active_q != live_q) begin\n              fault_now = F_DIV_BAR;",
     "if (1'b0) begin\n              fault_now = F_DIV_BAR;", "rr8"),
    ("M13_rr_loose", "RR pointer jumps past a blocked candidate (loose RR: can starve a port-blocked warp)",
     "sf_warp_arb.sv", "if (!found_b) nxt_ptr = PTR_W'((idx + 1) % N);", "nxt_ptr = PTR_W'((idx + 1) % N);", "rr8"),
    ("M14_exit_keeps_live", "EXIT does not remove threads from the live mask",
     "sf_simt_warp_ctx.sv", "            n_live = live_q & ~active_q;\n            if (n_live == '0) begin",
     "            n_live = live_q;\n            if (live_q == active_q) begin", "rr8"),
    ("M15_perf_dep", "dependency stall counter drops a class",
     "sf_simt_ctrl.sv", "        WC_DEP:    inc_dep    = inc_dep + 1;", "        WC_DEP:    ;", "rr8"),
    ("M16_stk_ovf_ok", "stack overflow check removed from SSY",
     "sf_simt_warp_ctx.sv", "            if (stk_full) begin\n              fault_now = F_STK_OVF;\n            end else begin\n              stk_push      = 1'b1;\n              stk_push_kind = 1'b0;",
     "            if (1'b0) begin\n              fault_now = F_STK_OVF;\n            end else begin\n              stk_push      = 1'b1;\n              stk_push_kind = 1'b0;", "rr8"),
    # --- defects that no inline assertion can see: only RTL-vs-reference comparison catches them ---
    ("M17_sync_pc", "SYNC resumes at pc+1 instead of the popped entry's pc",
     "sf_simt_warp_ctx.sv", "n_pc     = stk_found_pc;\n              n_active = stk_found_mask & live_q;",
     "n_pc     = pc_plus1;\n              n_active = stk_found_mask & live_q;", "rr8"),
    ("M18_branch_target", "branch/jump target omits the +1 (off-by-one pc-relative offset)",
     "sf_simt_warp_ctx.sv", "assign tgt      = pc_q + PC_W'(1) + PC_W'(simm17);", "assign tgt      = pc_q + PC_W'(simm17);", "rr8"),
    ("M19_partial_mask", "partial last-warp mask off by one lane",
     "sf_simt_ctrl.sv", ": ((WARP_SIZE'(1) << launch_last_threads_i) - WARP_SIZE'(1));",
     ": ((WARP_SIZE'(1) << launch_last_threads_i));", "rr8"),
    ("M20_wg_widx_swap", "issue bus swaps workgroup id and warp-in-workgroup id",
     "sf_simt_ctrl.sv", "        iss_wg_o    = warp_wg_o[w];\n        iss_widx_o  = widx_vec[w];",
     "        iss_wg_o    = widx_vec[w];\n        iss_widx_o  = warp_wg_o[w];", "rr8"),
    ("M21_rs2_ignored", "RAW hazard on the second source operand not checked",
     "sf_simt_warp_ctx.sv", "(di.use_rs1 && pend_q[rs1]) || (di.use_rs2 && pend_q[rs2]) || (di.wr_rd && pend_q[rd]);",
     "(di.use_rs1 && pend_q[rs1]) || (di.wr_rd && pend_q[rd]);", "rr8"),
]


def run(cmd, env, timeout=1800):
    p = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=timeout, cwd=ROOT)
    return p.returncode, p.stdout + p.stderr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", action="append")
    ap.add_argument("--keep", action="store_true")
    ap.add_argument("--random-n", type=int, default=30)
    a = ap.parse_args()
    killed, survived, results = 0, 0, []
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    work = tempfile.mkdtemp(prefix="mut_", dir=os.path.join(ROOT, "build"))
    for mid, desc, fname, old, new, cfg in MUTANTS:
        if a.only and mid not in a.only:
            continue
        t0 = time.time()
        rtl = os.path.join(work, mid, "rtl")
        shutil.copytree(os.path.join(ROOT, "rtl"), rtl)
        path = os.path.join(rtl, fname)
        text = open(path).read()
        olds = old if isinstance(old, list) else [old]
        news = new if isinstance(new, list) else [new]
        bad = [o for o in olds if text.count(o) != 1]
        if bad:
            print(f"{mid}: PATCH ERROR ({text.count(bad[0])} matches of {bad[0][:60]!r} in {fname})")
            results.append((mid, "PATCH-ERROR", ""))
            continue
        for o, n in zip(olds, news):
            text = text.replace(o, n)
        open(path, "w").write(text)
        env = dict(os.environ)
        env["SF_RTL_DIR"] = rtl
        env["SF_BUILD_ROOT"] = os.path.join(work, mid, "build")
        env["SF_OPT"] = "-O0"                       # fast compile: mutants only need functional behaviour
        env["PYTHONPATH"] = os.path.join(ROOT, "model") + ":" + HERE
        how = None
        try:
            rc, out = run([sys.executable, os.path.join(ROOT, "tests", "directed_suite.py"), "--config", cfg,
                           "--out", os.path.join(work, mid, "out_d")], env)
            if rc != 0:
                first = next((l.strip() for l in out.splitlines() if l.startswith("FAIL")), "directed suite failed")
                detail = next((l.strip() for l in out.splitlines() if l.startswith("    ")), "")
                how = f"directed: {first} {detail[:140]}"
            else:
                for prof in ("mid", "slow"):
                    rc, out = run([sys.executable, os.path.join(HERE, "regress_random.py"), "--config", cfg,
                                   "--profile", prof, "--n", str(a.random_n), "--seed", "77",
                                   "--out", os.path.join(work, mid, "out_r")], env)
                    if rc != 0:
                        first = next((l.strip() for l in out.splitlines() if l.startswith("FAIL")), "random failed")
                        detail = next((l.strip() for l in out.splitlines() if l.startswith("    ")), "")
                        how = f"random/{prof}: {first} {detail[:140]}"
                        break
        except Exception as e:                       # build failure of the mutant etc.
            how = f"build/run error: {str(e)[:200]}"
            print(f"{mid}: {how}")
            results.append((mid, "ERROR", how))
            continue
        status = "KILLED" if how else "SURVIVED"
        if how:
            killed += 1
        else:
            survived += 1
        results.append((mid, status, how or ""))
        print(f"{mid:22s} {status:9s} {desc}\n{'':32s}{how or ''}   [{time.time() - t0:.0f}s]", flush=True)
    print(f"\nmutation score: {killed} killed, {survived} survived, "
          f"{len([r for r in results if r[1] in ('ERROR', 'PATCH-ERROR')])} errors")
    if not a.keep:
        shutil.rmtree(work, ignore_errors=True)
    return 1 if survived or any(r[1] in ("ERROR", "PATCH-ERROR") for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
