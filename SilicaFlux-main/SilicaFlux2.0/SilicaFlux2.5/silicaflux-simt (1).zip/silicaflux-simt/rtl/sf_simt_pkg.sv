// =============================================================================
//  SilicaFlux :: sf_simt_pkg.sv
//  Shared types, SFT-1 SIMT instruction set and pre-decode for the warp
//  scheduler / SIMT control unit.
// =============================================================================
//  Instruction word (32 bit, SilicaFlux field layout):
//     [31:27] op   [26:22] rd   [21:17] rs1   [16:12] rs2   [11:0] imm12
//     I-form reuses [16:0] as imm17 (rs2 field is then part of the immediate).
//
//  The control unit only interprets the *control* behaviour of an instruction
//  (class, register read/write sets, control-flow semantics). Arithmetic,
//  addressing and special-register semantics belong to the downstream
//  execution backend and are specified in docs/ARCHITECTURE.md section 3.
// =============================================================================

`default_nettype none

package sf_simt_pkg;

  // ---------------------------------------------------------------------------
  // Architectural constants
  // ---------------------------------------------------------------------------
  localparam int unsigned SF_NUM_REGS = 32;   // per-thread registers, r0 == 0
  localparam int unsigned SF_INSTR_W  = 32;

  // Scheduling policies
  localparam int unsigned SF_POLICY_RR  = 0;  // round robin, pointer never passes a waiting candidate
  localparam int unsigned SF_POLICY_AGE = 1;  // oldest-first (least-recently-issued) age matrix

  // Backend issue ports. ALU port carries ALU/S2R/branch-condition work, the
  // MEM port carries loads and stores.
  localparam int unsigned SF_PORT_ALU = 0;
  localparam int unsigned SF_PORT_MEM = 1;

  // ---------------------------------------------------------------------------
  // Opcodes
  // ---------------------------------------------------------------------------
  typedef enum logic [4:0] {
    OP_NOP  = 5'h00,
    OP_EXIT = 5'h01,   // active threads terminate
    OP_SSY  = 5'h02,   // push reconvergence TOKEN (pc+1+imm17, active mask)
    OP_SYNC = 5'h03,   // reconverge: pop to first entry that still holds live threads
    OP_BAR  = 5'h04,   // workgroup barrier (warp-level arrival, warp must be converged)
    OP_JMP  = 5'h05,   // warp-uniform jump pc+1+imm17
    OP_BNZ  = 5'h06,   // per-thread: taken if rs1 != 0
    OP_BZ   = 5'h07,   // per-thread: taken if rs1 == 0
    OP_ADD  = 5'h08,
    OP_SUB  = 5'h09,
    OP_MUL  = 5'h0A,
    OP_AND  = 5'h0B,
    OP_OR   = 5'h0C,
    OP_XOR  = 5'h0D,
    OP_SHL  = 5'h0E,
    OP_SHR  = 5'h0F,
    OP_SAR  = 5'h10,
    OP_SLT  = 5'h11,
    OP_SLTU = 5'h12,
    OP_ADDI = 5'h13,
    OP_LUI  = 5'h14,   // rd = imm17 << 15
    OP_S2R  = 5'h15,   // rd = special register [imm17]
    OP_LDG  = 5'h18,   // rd = gmem[rs1 + simm12]
    OP_STG  = 5'h19,   // gmem[rs1 + simm12] = rs2
    OP_LDS  = 5'h1A,   // rd = smem[rs1 + simm12]  (per-workgroup scratchpad)
    OP_STS  = 5'h1B    // smem[rs1 + simm12] = rs2
  } sf_op_e;

  // Instruction classes seen by the control unit
  typedef enum logic [2:0] {
    SF_CLS_LOCAL = 3'd0,   // executed inside the control unit (never leaves it)
    SF_CLS_ALU   = 3'd1,   // backend ALU port, writes rd
    SF_CLS_BR    = 3'd2,   // backend ALU port, returns per-thread taken mask
    SF_CLS_LD    = 3'd3,   // backend MEM port, writes rd
    SF_CLS_ST    = 3'd4    // backend MEM port, no register result
  } sf_cls_e;

  // Warp context states (registered)
  typedef enum logic [2:0] {
    W_FREE  = 3'd0,   // context not owned by any kernel
    W_RUN   = 3'd1,   // resident; fetching / issuing
    W_BRW   = 3'd2,   // conditional branch issued, waiting for taken mask
    W_BAR   = 3'd3,   // arrived at workgroup barrier
    W_DRAIN = 3'd4,   // no live threads; waiting for in-flight work to retire
    W_DONE  = 3'd5    // fully retired; owns nothing; counts as exited for barriers
  } sf_wstate_e;

  // Per-cycle, per-warp attribution (exactly one class per resident warp per cycle)
  typedef enum logic [3:0] {
    WC_FREE   = 4'd0,
    WC_ISSUED = 4'd1,   // won the issue slot (executed or faulted)
    WC_READY  = 4'd2,   // eligible, lost arbitration
    WC_DEP    = 4'd3,   // blocked: register hazard on a non-memory producer
    WC_MEM    = 4'd4,   // blocked: hazard on an outstanding load / drain of memory ops
    WC_STRUCT = 4'd5,   // blocked: backend port not ready or no free in-flight slot
    WC_FRONT  = 4'd6,   // waiting for instruction fetch or branch resolution
    WC_BAR    = 4'd7,   // waiting at workgroup barrier
    WC_DRAIN  = 4'd8,
    WC_DONE   = 4'd9
  } sf_wclass_e;

  // Fault causes (sticky per warp, first fault wins)
  typedef enum logic [3:0] {
    F_NONE      = 4'd0,
    F_STK_OVF   = 4'd1,   // reconvergence stack overflow
    F_STK_UNF   = 4'd2,   // SYNC with empty stack
    F_DIV_BAR   = 4'd3,   // BAR executed by a diverged warp
    F_ILLEGAL   = 4'd4,   // undefined opcode
    F_FETCH     = 4'd5,   // instruction fetch error (e.g. pc ran off the program)
    F_LOST      = 4'd6,   // live threads cannot be reconverged (malformed control flow)
    F_NO_REGION = 4'd7,   // divergent branch with no enclosing SSY region
    F_WG_KILLED = 4'd8    // collateral: workgroup terminated by a fault elsewhere
  } sf_fault_e;

  // Launch reject causes
  localparam logic [1:0] LREJ_NONE  = 2'd0;
  localparam logic [1:0] LREJ_DIMS  = 2'd1;   // zero / too many warps or workgroups
  localparam logic [1:0] LREJ_STACK = 2'd2;   // declared stack need exceeds STACK_DEPTH
  localparam logic [1:0] LREJ_LAST  = 2'd3;   // last-warp thread count out of range

  // Performance counter indices
  localparam int unsigned PERF_CYCLES     = 0;   // cycles with a kernel running
  localparam int unsigned PERF_ISSUED     = 1;   // instructions issued (executed)
  localparam int unsigned PERF_IDLE       = 2;   // running cycles with no instruction issued
  localparam int unsigned PERF_DEP_STALL  = 3;   // warp-cycles
  localparam int unsigned PERF_MEM_STALL  = 4;   // warp-cycles
  localparam int unsigned PERF_BAR_WAIT   = 5;   // warp-cycles
  localparam int unsigned PERF_STRUCT     = 6;   // warp-cycles
  localparam int unsigned PERF_FRONT      = 7;   // warp-cycles
  localparam int unsigned PERF_READY_WAIT = 8;   // warp-cycles (eligible, not granted)
  localparam int unsigned PERF_BRANCH     = 9;   // conditional branches resolved
  localparam int unsigned PERF_DIV        = 10;  // ... of which divergent
  localparam int unsigned PERF_RECONV     = 11;  // SYNC instructions executed
  localparam int unsigned PERF_STK_HWM    = 12;  // max stack depth seen on any warp
  localparam int unsigned PERF_FAULT      = 13;  // fault events
  localparam int unsigned PERF_BAR_REL    = 14;  // workgroup barrier releases
  localparam int unsigned PERF_RETIRED    = 15;  // backend completions retired
  localparam int unsigned PERF_PROTO      = 16;  // dropped (spurious/duplicate) completions or responses
  localparam int unsigned PERF_N          = 17;

  // ---------------------------------------------------------------------------
  // Decoded instruction (what the instruction buffer holds)
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic        fetch_err;   // fetch returned an error: faults when it reaches issue
    logic        illegal;     // undefined opcode: faults when it reaches issue
    sf_op_e      op;
    sf_cls_e     cls;
    logic        use_rs1;     // rs1 is read and non-zero  -> RAW check
    logic        use_rs2;     // rs2 is read and non-zero  -> RAW check
    logic        wr_rd;       // rd is written and non-zero -> WAW check, scoreboard set
    logic [31:0] raw;
  } sf_dinstr_t;

  // Field extraction ----------------------------------------------------------
  function automatic logic [4:0]  sf_f_rd   (input logic [31:0] i); return i[26:22]; endfunction
  function automatic logic [4:0]  sf_f_rs1  (input logic [31:0] i); return i[21:17]; endfunction
  function automatic logic [4:0]  sf_f_rs2  (input logic [31:0] i); return i[16:12]; endfunction
  function automatic logic [16:0] sf_f_imm17(input logic [31:0] i); return i[16:0];  endfunction

  // Pre-decode -----------------------------------------------------------------
  function automatic sf_dinstr_t sf_predecode(input logic [31:0] raw, input logic err);
    sf_dinstr_t d;
    logic [4:0] rd, rs1, rs2;
    d       = '0;
    d.raw   = raw;
    rd      = sf_f_rd(raw);
    rs1     = sf_f_rs1(raw);
    rs2     = sf_f_rs2(raw);
    d.op    = sf_op_e'(raw[31:27]);
    d.cls   = SF_CLS_LOCAL;
    if (err) begin
      d.fetch_err = 1'b1;
      d.op        = OP_NOP;
    end else begin
      case (raw[31:27])
        5'h00, 5'h01, 5'h02, 5'h03, 5'h04, 5'h05: begin
          d.cls = SF_CLS_LOCAL;
        end
        5'h06, 5'h07: begin
          d.cls     = SF_CLS_BR;
          d.use_rs1 = (rs1 != 5'd0);
        end
        5'h08, 5'h09, 5'h0A, 5'h0B, 5'h0C, 5'h0D, 5'h0E, 5'h0F, 5'h10, 5'h11, 5'h12: begin
          d.cls     = SF_CLS_ALU;
          d.use_rs1 = (rs1 != 5'd0);
          d.use_rs2 = (rs2 != 5'd0);
          d.wr_rd   = (rd  != 5'd0);
        end
        5'h13: begin  // ADDI
          d.cls     = SF_CLS_ALU;
          d.use_rs1 = (rs1 != 5'd0);
          d.wr_rd   = (rd  != 5'd0);
        end
        5'h14, 5'h15: begin  // LUI, S2R
          d.cls     = SF_CLS_ALU;
          d.wr_rd   = (rd  != 5'd0);
        end
        5'h18, 5'h1A: begin  // loads
          d.cls     = SF_CLS_LD;
          d.use_rs1 = (rs1 != 5'd0);
          d.wr_rd   = (rd  != 5'd0);
        end
        5'h19, 5'h1B: begin  // stores
          d.cls     = SF_CLS_ST;
          d.use_rs1 = (rs1 != 5'd0);
          d.use_rs2 = (rs2 != 5'd0);
        end
        default: begin
          d.illegal = 1'b1;
          d.op      = OP_NOP;
          d.cls     = SF_CLS_LOCAL;
        end
      endcase
    end
    return d;
  endfunction

endpackage : sf_simt_pkg
