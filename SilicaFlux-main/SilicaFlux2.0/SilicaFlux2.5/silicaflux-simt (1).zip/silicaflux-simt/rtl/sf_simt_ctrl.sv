// =============================================================================
//  SilicaFlux :: sf_simt_ctrl.sv
//  Warp scheduler and SIMT control unit (top level).
// =============================================================================
//  One single-issue core front end that owns NUM_WARPS resident warp contexts.
//
//      launch --> [launch FSM] --> warp contexts (state, pc, masks, stack,
//                                   ibuf, slots, scoreboard)  x NUM_WARPS
//                    fetch arb <-- want_fetch        cand/elig --> issue arb
//                    IMEM  <-> fetch req/rsp              grant --> contexts
//                    backend <-- issue bus (iss_*)   cmpl_* --> contexts
//                    barrier unit <-> warp states    perf counters
//
//  The authoritative specification, including the downstream contract and the
//  fairness assumptions that the progress properties rely on, is
//  docs/ARCHITECTURE.md. Summary of the contract:
//    * iss_ready_i[p] is a combinational readiness of backend port p in the
//      same cycle; it must not depend combinationally on iss_valid_o.
//    * Operands of an issued instruction are sampled by the backend in the
//      issue cycle. Memory operations of one warp are performed in issue order.
//    * Every accepted backend instruction returns exactly one completion
//      {warp, slot} within finite time (conditional branches also return the
//      per-thread taken mask). Completions arrive at least one cycle after the
//      issue cycle on either of the two interchangeable channels.
//    * Every fetch request is answered exactly once within finite time with the
//      echoed {warp, pc}; err_i marks a failed fetch.
// =============================================================================

`default_nettype none

module sf_simt_ctrl
  import sf_simt_pkg::*;
#(
  parameter int unsigned NUM_WARPS    = 8,
  parameter int unsigned WARP_SIZE    = 32,
  parameter int unsigned PC_W         = 16,
  parameter int unsigned STACK_DEPTH  = 8,
  parameter int unsigned NUM_SLOTS    = 4,
  parameter int unsigned POLICY       = SF_POLICY_RR,
  parameter int unsigned PERF_W       = 32
) (
  input  logic                                clk_i,
  input  logic                                rst_ni,

  // ---- kernel launch / status ------------------------------------------------
  input  logic                                launch_valid_i,
  output logic                                launch_ready_o,
  input  logic [PC_W-1:0]                     launch_pc_i,
  input  logic [$clog2(NUM_WARPS+1)-1:0]      launch_num_wg_i,        // 1 .. NUM_WARPS
  input  logic [$clog2(NUM_WARPS+1)-1:0]      launch_wpw_i,           // warps per workgroup
  input  logic [$clog2(WARP_SIZE+1)-1:0]      launch_last_threads_i,  // threads in last warp of a workgroup, 0 = full
  input  logic [$clog2(STACK_DEPTH+1)-1:0]    launch_stack_need_i,    // declared stack need, 0 = not declared
  output logic                                launch_reject_o,        // pulse, launch not accepted
  output logic [1:0]                          launch_reject_cause_o,

  output logic                                busy_o,
  output logic                                kernel_done_o,          // pulse
  output logic                                kernel_fault_o,         // level, cleared by the next launch

  // ---- instruction fetch -----------------------------------------------------------
  output logic                                if_req_valid_o,
  input  logic                                if_req_ready_i,
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] if_req_warp_o,
  output logic [PC_W-1:0]                     if_req_pc_o,
  input  logic                                if_rsp_valid_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] if_rsp_warp_i,
  input  logic [PC_W-1:0]                     if_rsp_pc_i,
  input  logic [31:0]                         if_rsp_instr_i,
  input  logic                                if_rsp_err_i,

  // ---- issue bus to the execution backend -----------------------------------------------
  output logic                                iss_valid_o,
  output logic                                iss_port_o,             // 0 = ALU port, 1 = MEM port
  input  logic [1:0]                          iss_ready_i,
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] iss_warp_o,
  output logic [(NUM_SLOTS>1 ? $clog2(NUM_SLOTS) : 1)-1:0] iss_slot_o,
  output logic [PC_W-1:0]                     iss_pc_o,
  output logic [WARP_SIZE-1:0]                iss_mask_o,
  output logic [31:0]                         iss_instr_o,
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] iss_wg_o,
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] iss_widx_o,

  // ---- completions from the backend -------------------------------------------------------
  input  logic [1:0]                          cmpl_valid_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] cmpl_warp_i [2],
  input  logic [(NUM_SLOTS>1 ? $clog2(NUM_SLOTS) : 1)-1:0] cmpl_slot_i [2],
  input  logic [WARP_SIZE-1:0]                cmpl_taken_i [2],

  // ---- configuration ---------------------------------------------------------------------------
  input  logic                                cfg_check_struct_i,     // enable compliant-code structural assertions
  input  logic                                perf_clear_i,

  // ---- performance counters (index = PERF_* in sf_simt_pkg) -----------------------------
  output logic [PERF_W-1:0]                   perf_o [PERF_N],

  // ---- trace / observability ----------------------------------------------------------------------
  output logic                                ev_issue_o,             // a warp consumed the issue slot
  output logic                                ev_exec_o,              // ... and its instruction executed
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] ev_warp_o,
  output logic [PC_W-1:0]                     ev_pc_o,
  output logic [WARP_SIZE-1:0]                ev_mask_o,
  output logic [31:0]                         ev_instr_o,
  output logic [NUM_WARPS-1:0]                ev_fill_o,              // per-warp: ibuf filled
  output logic [NUM_WARPS-1:0]                sched_cand_o,
  output logic [NUM_WARPS-1:0]                sched_elig_o,
  output logic [NUM_WARPS-1:0]                sched_grant_o,
  output logic [NUM_WARPS-1:0]                wg_release_o,           // per workgroup id, pulse
  output logic                                core_run_o,
  output sf_wstate_e                          warp_state_o  [NUM_WARPS],
  output sf_wclass_e                          warp_class_o  [NUM_WARPS],
  output logic [PC_W-1:0]                     warp_pc_o     [NUM_WARPS],
  output logic [WARP_SIZE-1:0]                warp_active_o [NUM_WARPS],
  output logic [WARP_SIZE-1:0]                warp_live_o   [NUM_WARPS],
  output logic [$clog2(STACK_DEPTH+1)-1:0]    warp_sp_o     [NUM_WARPS],
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] warp_wg_o [NUM_WARPS],
  output sf_fault_e                           warp_fault_o  [NUM_WARPS],

  output logic                                err_proto_o,            // sticky: dropped completion/response
  output logic                                err_assert_o            // sticky: internal assertion failed
);

  localparam int unsigned WID_W  = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1;
  localparam int unsigned SLOT_W = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1;
  localparam int unsigned CNT_W  = $clog2(NUM_WARPS + 1);
  localparam int unsigned LANE_W = $clog2(WARP_SIZE + 1);
  localparam int unsigned SP_W   = $clog2(STACK_DEPTH + 1);

  // ---------------------------------------------------------------------------
  // Launch FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [1:0] { L_IDLE = 2'd0, L_SETUP = 2'd1, L_RUN = 2'd2 } lfsm_e;
  lfsm_e                 fsm_q;
  logic [PC_W-1:0]       entry_pc_q;
  logic [CNT_W-1:0]      wpw_q, total_q, ls_w_q;
  logic [WID_W-1:0]      ls_wg_q, ls_widx_q;
  logic [WARP_SIZE-1:0]  last_mask_q;
  logic                  done_q, rej_q;
  logic [1:0]            rej_cause_q;

  logic launch_accept, launch_ok, dims_ok, last_ok, stack_ok;
  logic [2*CNT_W-1:0] total_w;

  assign launch_ready_o = (fsm_q == L_IDLE);
  assign launch_accept  = launch_valid_i && launch_ready_o;
  assign total_w        = (2*CNT_W)'(launch_num_wg_i) * (2*CNT_W)'(launch_wpw_i);
  assign dims_ok        = (launch_num_wg_i != '0) && (launch_wpw_i != '0) && (total_w <= (2*CNT_W)'(NUM_WARPS));
  assign last_ok        = (int'(launch_last_threads_i) <= int'(WARP_SIZE));
  assign stack_ok       = (launch_stack_need_i == '0) || (int'(launch_stack_need_i) <= int'(STACK_DEPTH));
  assign launch_ok      = dims_ok && last_ok && stack_ok;

  logic launch_go;
  assign launch_go = launch_accept && launch_ok;

  logic core_run;
  assign core_run   = (fsm_q == L_RUN);
  assign core_run_o = core_run;

  // ---------------------------------------------------------------------------
  // Warp contexts
  // ---------------------------------------------------------------------------
  logic [NUM_WARPS-1:0]       launch_vec, want_fetch, cand_vec, elig_vec, grant_vec, exec_vec,
                              iss_be_vec, bar_vec, fill_vec, fault_new_vec, proto_vec,
                              ev_branch_vec, ev_div_vec, ev_sync_vec;
  logic [NUM_WARPS-1:0]       kill_vec, bar_rel_vec, fetch_grant_vec, rsp_vec;
  logic [PC_W-1:0]            pc_vec        [NUM_WARPS];
  logic [PC_W-1:0]            pc_stat_vec   [NUM_WARPS];
  logic [WARP_SIZE-1:0]       mask_vec      [NUM_WARPS];
  logic [31:0]                instr_vec     [NUM_WARPS];
  logic [SLOT_W-1:0]          slot_vec      [NUM_WARPS];
  logic [WID_W-1:0]           widx_vec      [NUM_WARPS];
  logic [1:0]                 retire_vec    [NUM_WARPS];
  logic [$clog2(NUM_SLOTS+1)-1:0] infl_vec  [NUM_WARPS];
  logic [NUM_WARPS-1:0]       assert_vec;
  sf_wstate_e                 state_vec     [NUM_WARPS];
  sf_wclass_e                 class_vec     [NUM_WARPS];
  sf_fault_e                  fault_vec     [NUM_WARPS];

  sf_dinstr_t                 rsp_di;
  assign rsp_di = sf_predecode(if_rsp_instr_i, if_rsp_err_i);

  logic [WARP_SIZE-1:0] launch_mask;
  assign launch_mask = (ls_widx_q == (wpw_q[WID_W-1:0] - WID_W'(1))) ? last_mask_q : {WARP_SIZE{1'b1}};

  for (genvar w = 0; w < NUM_WARPS; w++) begin : g_warp
    assign launch_vec[w]      = (fsm_q == L_SETUP) && (int'(ls_w_q) == w);
    assign rsp_vec[w]         = if_rsp_valid_i && (int'(if_rsp_warp_i) == w);

    sf_simt_warp_ctx #(
      .WID         (w),
      .NUM_WARPS   (NUM_WARPS),
      .WARP_SIZE   (WARP_SIZE),
      .PC_W        (PC_W),
      .STACK_DEPTH (STACK_DEPTH),
      .NUM_SLOTS   (NUM_SLOTS)
    ) u_ctx (
      .clk_i         (clk_i),
      .rst_ni        (rst_ni),
      .launch_clr_i  (launch_go),
      .launch_i      (launch_vec[w]),
      .launch_pc_i   (entry_pc_q),
      .launch_mask_i (launch_mask),
      .launch_wg_i   (ls_wg_q),
      .launch_widx_i (ls_widx_q),
      .free_i        (free_all),
      .core_run_i    (core_run),
      .kill_i        (kill_vec[w]),
      .chk_struct_i  (cfg_check_struct_i),
      .want_fetch_o  (want_fetch[w]),
      .pc_o          (pc_vec[w]),
      .fetch_grant_i (fetch_grant_vec[w]),
      .rsp_valid_i   (rsp_vec[w]),
      .rsp_pc_i      (if_rsp_pc_i),
      .rsp_di_i      (rsp_di),
      .port_ready_i  (iss_ready_i),
      .cand_o        (cand_vec[w]),
      .elig_o        (elig_vec[w]),
      .grant_i       (grant_vec[w]),
      .iss_be_o      (iss_be_vec[w]),
      .iss_mask_o    (mask_vec[w]),
      .iss_instr_o   (instr_vec[w]),
      .iss_slot_o    (slot_vec[w]),
      .exec_o        (exec_vec[w]),
      .is_bar_o      (bar_vec[w]),
      .fill_o        (fill_vec[w]),
      .cmpl_valid_i  (cmpl_valid_i),
      .cmpl_warp_i   (cmpl_warp_i),
      .cmpl_slot_i   (cmpl_slot_i),
      .cmpl_taken_i  (cmpl_taken_i),
      .bar_release_i (bar_rel_vec[w]),
      .state_o       (state_vec[w]),
      .pc_status_o   (pc_stat_vec[w]),
      .active_o      (warp_active_o[w]),
      .live_o        (warp_live_o[w]),
      .sp_o          (warp_sp_o[w]),
      .wg_o          (warp_wg_o[w]),
      .widx_o        (widx_vec[w]),
      .fault_o       (fault_vec[w]),
      .fault_new_o   (fault_new_vec[w]),
      .class_o       (class_vec[w]),
      .inflight_o    (infl_vec[w]),
      .retire_o      (retire_vec[w]),
      .proto_err_o   (proto_vec[w]),
      .ev_branch_o   (ev_branch_vec[w]),
      .ev_div_o      (ev_div_vec[w]),
      .ev_sync_o     (ev_sync_vec[w]),
      .assert_err_o  (assert_vec[w])
    );

    assign warp_state_o[w] = state_vec[w];
    assign warp_class_o[w] = class_vec[w];
    assign warp_pc_o[w]    = pc_stat_vec[w];
    assign warp_fault_o[w] = fault_vec[w];
  end

  assign sched_cand_o = cand_vec;
  assign ev_fill_o    = fill_vec;

  // ---------------------------------------------------------------------------
  // Workgroup kill: a fault terminates every warp of the faulting workgroup.
  // wg_killed_q is set one cycle after the fault and cleared by the next launch.
  // ---------------------------------------------------------------------------
  logic [NUM_WARPS-1:0] wg_killed_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      wg_killed_q <= '0;
    end else if (launch_go) begin
      wg_killed_q <= '0;
    end else begin
      for (int w = 0; w < NUM_WARPS; w++)
        if (fault_new_vec[w]) wg_killed_q[warp_wg_o[w]] <= 1'b1;
    end
  end

  always_comb begin
    for (int w = 0; w < NUM_WARPS; w++) kill_vec[w] = wg_killed_q[warp_wg_o[w]] && (state_vec[w] != W_FREE);
  end

  // ---------------------------------------------------------------------------
  // Barrier release
  // ---------------------------------------------------------------------------
  logic [NUM_WARPS-1:0] member_vec, at_bar_vec, done_vec, bar_rel_raw, wg_rel_raw;
  always_comb begin
    for (int w = 0; w < NUM_WARPS; w++) begin
      member_vec[w] = (state_vec[w] != W_FREE);
      at_bar_vec[w] = (state_vec[w] == W_BAR);
      done_vec[w]   = (state_vec[w] == W_DONE);
    end
  end

  sf_simt_barrier #(.NUM_WARPS(NUM_WARPS)) u_barrier (
    .member_i     (member_vec),
    .at_bar_i     (at_bar_vec),
    .done_i       (done_vec),
    .killed_i     (kill_vec),
    .wg_i         (warp_wg_o),
    .release_o    (bar_rel_raw),
    .wg_release_o (wg_rel_raw)
  );

  assign bar_rel_vec  = core_run ? bar_rel_raw : '0;
  assign wg_release_o = core_run ? wg_rel_raw  : '0;

  // ---------------------------------------------------------------------------
  // Fetch arbitration (plain round robin; all candidates see the same IMEM
  // readiness, so every candidate is reached within NUM_WARPS grants)
  // ---------------------------------------------------------------------------
  logic [WID_W-1:0] fptr_q, fsel_idx;
  logic [NUM_WARPS-1:0] fsel_oh;

  always_comb begin
    fsel_oh  = '0;
    fsel_idx = '0;
    for (int k = NUM_WARPS; k > 0; k--) begin
      int idx;
      idx = (int'(fptr_q) + k - 1) % NUM_WARPS;
      if (want_fetch[idx]) begin
        fsel_oh      = '0;
        fsel_oh[idx] = 1'b1;
        fsel_idx     = WID_W'(idx);
      end
    end
  end

  assign if_req_valid_o  = |want_fetch;
  assign if_req_warp_o   = fsel_idx;
  assign if_req_pc_o     = pc_vec[fsel_idx];
  assign fetch_grant_vec = (if_req_valid_o && if_req_ready_i) ? fsel_oh : '0;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)                                  fptr_q <= '0;
    else if (launch_go)                           fptr_q <= '0;
    else if (if_req_valid_o && if_req_ready_i)    fptr_q <= WID_W'((int'(fsel_idx) + 1) % NUM_WARPS);
  end

  // ---------------------------------------------------------------------------
  // Issue arbitration
  // ---------------------------------------------------------------------------
  logic arb_err;

  sf_warp_arb #(
    .N            (NUM_WARPS),
    .POLICY       (POLICY)
  ) u_arb (
    .clk_i        (clk_i),
    .rst_ni       (rst_ni),
    .clear_i      (launch_go),
    .cand_i       (cand_vec),
    .elig_i       (elig_vec),
    .grant_o      (grant_vec),
    .assert_err_o (arb_err)
  );

  assign sched_elig_o  = elig_vec;
  assign sched_grant_o = grant_vec;

  // issue bus / trace mux
  logic sel_be;
  always_comb begin
    ev_issue_o  = |grant_vec;
    ev_exec_o   = |exec_vec;
    ev_warp_o   = '0;
    ev_pc_o     = '0;
    ev_mask_o   = '0;
    ev_instr_o  = '0;
    iss_slot_o  = '0;
    iss_wg_o    = '0;
    iss_widx_o  = '0;
    sel_be      = 1'b0;
    for (int w = 0; w < NUM_WARPS; w++) begin
      if (grant_vec[w]) begin
        ev_warp_o   = WID_W'(w);
        ev_pc_o     = pc_stat_vec[w];
        ev_mask_o   = mask_vec[w];
        ev_instr_o  = instr_vec[w];
        iss_slot_o  = slot_vec[w];
        iss_wg_o    = warp_wg_o[w];
        iss_widx_o  = widx_vec[w];
        sel_be      = iss_be_vec[w];
      end
    end
  end

  assign iss_valid_o = ev_issue_o && sel_be;
  assign iss_warp_o  = ev_warp_o;
  assign iss_pc_o    = ev_pc_o;
  assign iss_mask_o  = ev_mask_o;
  assign iss_instr_o = ev_instr_o;
  assign iss_port_o  = (ev_instr_o[31:27] == 5'h18) || (ev_instr_o[31:27] == 5'h19) ||
                       (ev_instr_o[31:27] == 5'h1A) || (ev_instr_o[31:27] == 5'h1B);

  // ---------------------------------------------------------------------------
  // Launch sequencing and kernel completion
  // ---------------------------------------------------------------------------
  logic all_done, free_all, cmpl_range_err;

  always_comb begin
    all_done = (|member_vec) && ((member_vec & ~done_vec) == '0);
    cmpl_range_err = 1'b0;
    for (int p = 0; p < 2; p++)
      if (cmpl_valid_i[p] && (int'(cmpl_warp_i[p]) >= int'(NUM_WARPS))) cmpl_range_err = 1'b1;
  end
  assign free_all = core_run && all_done;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      fsm_q       <= L_IDLE;
      entry_pc_q  <= '0;
      wpw_q       <= '0;
      total_q     <= '0;
      ls_w_q      <= '0;
      ls_wg_q     <= '0;
      ls_widx_q   <= '0;
      last_mask_q <= '1;
      done_q      <= 1'b0;
      rej_q       <= 1'b0;
      rej_cause_q <= LREJ_NONE;
    end else begin
      done_q <= 1'b0;
      rej_q  <= 1'b0;
      case (fsm_q)
        L_IDLE: begin
          if (launch_accept) begin
            if (launch_ok) begin
              entry_pc_q  <= launch_pc_i;
              wpw_q       <= launch_wpw_i;
              total_q     <= CNT_W'(total_w);
              ls_w_q      <= '0;
              ls_wg_q     <= '0;
              ls_widx_q   <= '0;
              last_mask_q <= ((launch_last_threads_i == '0) || (int'(launch_last_threads_i) == int'(WARP_SIZE)))
                             ? {WARP_SIZE{1'b1}}
                             : ((WARP_SIZE'(1) << launch_last_threads_i) - WARP_SIZE'(1));
              fsm_q       <= L_SETUP;
            end else begin
              rej_q       <= 1'b1;
              rej_cause_q <= !dims_ok ? LREJ_DIMS : (!last_ok ? LREJ_LAST : LREJ_STACK);
            end
          end
        end
        L_SETUP: begin
          if (int'(ls_w_q) == int'(total_q) - 1) begin
            fsm_q <= L_RUN;
          end else begin
            ls_w_q <= ls_w_q + CNT_W'(1);
          end
          if (int'(ls_widx_q) == int'(wpw_q) - 1) begin
            ls_widx_q <= '0;
            ls_wg_q   <= ls_wg_q + WID_W'(1);
          end else begin
            ls_widx_q <= ls_widx_q + WID_W'(1);
          end
        end
        L_RUN: begin
          if (free_all) begin
            fsm_q  <= L_IDLE;
            done_q <= 1'b1;
          end
        end
        default: fsm_q <= L_IDLE;
      endcase
    end
  end

  assign launch_reject_o       = rej_q;
  assign launch_reject_cause_o = rej_cause_q;
  assign kernel_done_o         = done_q;
  assign busy_o                = (fsm_q != L_IDLE);

  always_comb begin
    kernel_fault_o = 1'b0;
    for (int w = 0; w < NUM_WARPS; w++) if (fault_vec[w] != F_NONE) kernel_fault_o = 1'b1;
  end

  // ---------------------------------------------------------------------------
  // Performance counters
  //   Warp-cycle counters add the number of warps in each class each running cycle.
  //   Every resident warp is in exactly one class per cycle (warp_class_o).
  //   Identity: PERF_CYCLES == PERF_ISSUED + PERF_IDLE.
  // ---------------------------------------------------------------------------
  logic [PERF_W-1:0] cnt_q [PERF_N];
  int unsigned inc_dep, inc_mem, inc_bar, inc_struct, inc_front, inc_ready, inc_ret, inc_proto,
               inc_branch, inc_div, inc_sync, inc_fault, inc_rel, max_sp;

  always_comb begin
    inc_dep = 0; inc_mem = 0; inc_bar = 0; inc_struct = 0; inc_front = 0; inc_ready = 0;
    inc_ret = 0; inc_proto = 0; inc_branch = 0; inc_div = 0; inc_sync = 0; inc_fault = 0;
    inc_rel = 0; max_sp = 0;
    for (int w = 0; w < NUM_WARPS; w++) begin
      case (class_vec[w])
        WC_DEP:    inc_dep    = inc_dep + 1;
        WC_MEM:    inc_mem    = inc_mem + 1;
        WC_BAR:    inc_bar    = inc_bar + 1;
        WC_STRUCT: inc_struct = inc_struct + 1;
        WC_FRONT:  inc_front  = inc_front + 1;
        WC_READY:  inc_ready  = inc_ready + 1;
        default: ;
      endcase
      inc_ret    = inc_ret + int'(retire_vec[w]);
      inc_proto  = inc_proto + int'(proto_vec[w]);
      inc_branch = inc_branch + int'(ev_branch_vec[w]);
      inc_div    = inc_div + int'(ev_div_vec[w]);
      inc_sync   = inc_sync + int'(ev_sync_vec[w] && exec_vec[w]);
      inc_fault  = inc_fault + int'(fault_new_vec[w]);
      if (int'(warp_sp_o[w]) > int'(max_sp)) max_sp = int'(warp_sp_o[w]);
    end
    inc_proto = inc_proto + int'(cmpl_range_err) +
                int'(if_rsp_valid_i && (int'(if_rsp_warp_i) >= int'(NUM_WARPS)));
    inc_rel = $countones(wg_rel_raw & {NUM_WARPS{core_run}});
  end

  function automatic logic [PERF_W-1:0] sat_add(input logic [PERF_W-1:0] a, input int unsigned inc);
    logic [PERF_W:0] s;
    s = {1'b0, a} + (PERF_W+1)'(inc);
    return s[PERF_W] ? {PERF_W{1'b1}} : s[PERF_W-1:0];
  endfunction

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      for (int i = 0; i < PERF_N; i++) cnt_q[i] <= '0;
    end else if (launch_go || perf_clear_i) begin
      for (int i = 0; i < PERF_N; i++) cnt_q[i] <= '0;
    end else begin
      // protocol-error count is meaningful outside a running kernel as well
      cnt_q[PERF_PROTO] <= sat_add(cnt_q[PERF_PROTO], inc_proto);
      if (core_run) begin
        cnt_q[PERF_CYCLES]     <= sat_add(cnt_q[PERF_CYCLES], 1);
        cnt_q[PERF_ISSUED]     <= sat_add(cnt_q[PERF_ISSUED], int'(ev_exec_o));
        cnt_q[PERF_IDLE]       <= sat_add(cnt_q[PERF_IDLE], int'(!ev_exec_o));
        cnt_q[PERF_DEP_STALL]  <= sat_add(cnt_q[PERF_DEP_STALL], inc_dep);
        cnt_q[PERF_MEM_STALL]  <= sat_add(cnt_q[PERF_MEM_STALL], inc_mem);
        cnt_q[PERF_BAR_WAIT]   <= sat_add(cnt_q[PERF_BAR_WAIT], inc_bar);
        cnt_q[PERF_STRUCT]     <= sat_add(cnt_q[PERF_STRUCT], inc_struct);
        cnt_q[PERF_FRONT]      <= sat_add(cnt_q[PERF_FRONT], inc_front);
        cnt_q[PERF_READY_WAIT] <= sat_add(cnt_q[PERF_READY_WAIT], inc_ready);
        cnt_q[PERF_BRANCH]     <= sat_add(cnt_q[PERF_BRANCH], inc_branch);
        cnt_q[PERF_DIV]        <= sat_add(cnt_q[PERF_DIV], inc_div);
        cnt_q[PERF_RECONV]     <= sat_add(cnt_q[PERF_RECONV], inc_sync);
        if (int'(max_sp) > int'(cnt_q[PERF_STK_HWM])) cnt_q[PERF_STK_HWM] <= PERF_W'(max_sp);
        cnt_q[PERF_FAULT]      <= sat_add(cnt_q[PERF_FAULT], inc_fault);
        cnt_q[PERF_BAR_REL]    <= sat_add(cnt_q[PERF_BAR_REL], inc_rel);
        cnt_q[PERF_RETIRED]    <= sat_add(cnt_q[PERF_RETIRED], inc_ret);
      end
    end
  end

  for (genvar i = 0; i < PERF_N; i++) begin : g_perf
    assign perf_o[i] = cnt_q[i];
  end

  // ---------------------------------------------------------------------------
  // Sticky error flags and top-level assertions
  //   T1 grant implies a backend-port-ready cycle for backend instructions
  //   T2 kernel completion only with every warp FREE one cycle later
  //   T3 a killed workgroup never releases a barrier
  //   T4 no launch is accepted while busy (guaranteed by launch_ready_o)
  // ---------------------------------------------------------------------------
  logic err_proto_q, err_assert_q;
  assign err_proto_o  = err_proto_q;
  assign err_assert_o = err_assert_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      err_proto_q  <= 1'b0;
      err_assert_q <= 1'b0;
    end else begin
      if (launch_go) err_proto_q <= 1'b0;
      else if (inc_proto != 0) err_proto_q <= 1'b1;
      if (|assert_vec || arb_err) err_assert_q <= 1'b1;
`ifndef SYNTHESIS
      if (iss_valid_o && !iss_ready_i[iss_port_o]) begin
        err_assert_q <= 1'b1; $display("[SF-ASSERT] %m T1: backend issue while port not ready");
      end
      if (done_q && (|member_vec)) begin
        err_assert_q <= 1'b1; $display("[SF-ASSERT] %m T2: kernel done but contexts still owned");
      end
      for (int w = 0; w < NUM_WARPS; w++)
        if (bar_rel_vec[w] && kill_vec[w]) begin
          err_assert_q <= 1'b1; $display("[SF-ASSERT] %m T3: barrier release in killed workgroup");
        end
      if (launch_go && busy_o) begin
        err_assert_q <= 1'b1; $display("[SF-ASSERT] %m T4: launch while busy");
      end
`endif
    end
  end

endmodule : sf_simt_ctrl
