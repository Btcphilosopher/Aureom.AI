// =============================================================================
//  SilicaFlux :: sf_simt_barrier.sv
//  Workgroup barrier release logic.
// =============================================================================
//  Design choice: there are NO arrival counters. Release is a pure function of
//  the authoritative per-warp state, so the barrier can never drift out of step
//  with the warps (no premature release from an over-counted arrival, no
//  deadlock from an under-counted exit).
//
//  A workgroup g releases in cycle t iff
//      (a) it is not killed,
//      (b) at least one member warp is in W_BAR, and
//      (c) EVERY member warp is in W_BAR or W_DONE.
//
//  member  : warp owned by the running kernel (state != W_FREE)
//  W_DONE  : all threads exited AND all in-flight work retired. A warp that is
//            still draining (W_DRAIN) is deliberately NOT yet counted as exited,
//            so stores of an exiting warp are performed before the barrier opens.
//  Arrival into W_BAR is only possible after the warp's own in-flight work has
//  drained, so a release also implies that every arrived warp's earlier memory
//  operations have completed.
// =============================================================================

`default_nettype none

module sf_simt_barrier #(
  parameter int unsigned NUM_WARPS = 8
) (
  input  logic [NUM_WARPS-1:0] member_i,
  input  logic [NUM_WARPS-1:0] at_bar_i,
  input  logic [NUM_WARPS-1:0] done_i,
  input  logic [NUM_WARPS-1:0] killed_i,    // per-warp: workgroup already killed
  input  logic [$clog2(NUM_WARPS > 1 ? NUM_WARPS : 2)-1:0] wg_i [NUM_WARPS],

  output logic [NUM_WARPS-1:0] release_o,   // per warp
  output logic [NUM_WARPS-1:0] wg_release_o // per workgroup id (pulse)
);

  always_comb begin
    release_o    = '0;
    wg_release_o = '0;
    for (int unsigned g = 0; g < NUM_WARPS; g++) begin
      logic any_wait;
      logic all_in;
      logic is_killed;
      any_wait  = 1'b0;
      all_in    = 1'b1;
      is_killed = 1'b0;
      for (int unsigned w = 0; w < NUM_WARPS; w++) begin
        if (member_i[w] && (int'(wg_i[w]) == int'(g))) begin
          if (at_bar_i[w]) any_wait = 1'b1;
          if (!(at_bar_i[w] || done_i[w])) all_in = 1'b0;
          if (killed_i[w]) is_killed = 1'b1;
        end
      end
      if (any_wait && all_in && !is_killed) begin
        wg_release_o[g] = 1'b1;
        for (int unsigned w = 0; w < NUM_WARPS; w++)
          if (member_i[w] && (int'(wg_i[w]) == int'(g)) && at_bar_i[w]) release_o[w] = 1'b1;
      end
    end
  end

endmodule : sf_simt_barrier
