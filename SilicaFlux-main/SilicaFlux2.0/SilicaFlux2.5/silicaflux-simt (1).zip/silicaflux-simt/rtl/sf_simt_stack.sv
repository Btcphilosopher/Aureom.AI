// =============================================================================
//  SilicaFlux :: sf_simt_stack.sv
//  Per-warp reconvergence stack (one instance per resident warp).
// =============================================================================
//  Entry  = { kind, pc, mask }
//     kind 0 = TOKEN : pushed by SSY. pc = reconvergence point, mask = the
//                      threads that entered the region (active mask at SSY).
//     kind 1 = DIV   : pushed by a divergent branch. pc = start of the deferred
//                      (taken) path, mask = the threads that will run it.
//  Hardware treats both kinds identically; the kind bit exists for the
//  structural-invariant assertions, waveform debug and the reference trace.
//
//  Pop rule ("pop to first live entry")
//     The combinational search scans from the top of the stack downwards and
//     returns the first entry i with (mask[i] & live) != 0. Committing a pop
//     sets sp = i, i.e. the found entry *and everything above it* are
//     discarded. Entries whose threads have all exited are therefore skipped in
//     a single cycle, and the surviving mask is always (mask & live), so an
//     exited thread can never be resurrected by a reconvergence.
//
//  push and pop are mutually exclusive in a cycle; clear has priority.
// =============================================================================

`default_nettype none

module sf_simt_stack #(
  parameter int unsigned DEPTH  = 8,
  parameter int unsigned MASK_W = 32,
  parameter int unsigned PC_W   = 16
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,

  input  logic                         clear_i,
  input  logic                         push_i,
  input  logic                         push_kind_i,
  input  logic [PC_W-1:0]              push_pc_i,
  input  logic [MASK_W-1:0]            push_mask_i,
  input  logic                         pop_i,

  // search inputs (combinational)
  input  logic [MASK_W-1:0]            live_i,

  // observability / invariant checking inputs
  input  logic [MASK_W-1:0]            active_i,
  input  logic                         chk_struct_i,

  output logic [$clog2(DEPTH+1)-1:0]   sp_o,
  output logic                         full_o,
  output logic                         found_o,
  output logic [$clog2(DEPTH+1)-1:0]   found_idx_o,
  output logic                         found_kind_o,
  output logic [PC_W-1:0]              found_pc_o,
  output logic [MASK_W-1:0]            found_mask_o,

  output logic                         assert_err_o
);

  localparam int unsigned SP_W  = $clog2(DEPTH + 1);
  localparam int unsigned IDX_W = (DEPTH > 1) ? $clog2(DEPTH) : 1;   // sp < DEPTH whenever a push is legal

  logic [MASK_W-1:0] mask_q [DEPTH];
  logic [PC_W-1:0]   pc_q   [DEPTH];
  logic [DEPTH-1:0]  kind_q;
  logic [SP_W-1:0]   sp_q;

  assign sp_o   = sp_q;
  assign full_o = (sp_q == SP_W'(DEPTH));

  // First live entry from the top
  always_comb begin
    found_o      = 1'b0;
    found_idx_o  = '0;
    found_kind_o = 1'b0;
    found_pc_o   = '0;
    found_mask_o = '0;
    for (int unsigned i = 0; i < DEPTH; i++) begin
      if ((i < int'(sp_q)) && ((mask_q[i] & live_i) != '0)) begin
        found_o      = 1'b1;
        found_idx_o  = SP_W'(i);
        found_kind_o = kind_q[i];
        found_pc_o   = pc_q[i];
        found_mask_o = mask_q[i];
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sp_q   <= '0;
      kind_q <= '0;
      for (int unsigned i = 0; i < DEPTH; i++) begin
        mask_q[i] <= '0;
        pc_q[i]   <= '0;
      end
    end else if (clear_i) begin
      sp_q <= '0;
    end else if (push_i) begin
      if (sp_q != SP_W'(DEPTH)) begin
        mask_q[sp_q[IDX_W-1:0]] <= push_mask_i;
        pc_q[sp_q[IDX_W-1:0]]   <= push_pc_i;
        kind_q[sp_q[IDX_W-1:0]] <= push_kind_i;
        sp_q                   <= sp_q + SP_W'(1);
      end
    end else if (pop_i) begin
      if (found_o) sp_q <= found_idx_o;
    end
  end

  // ---------------------------------------------------------------------------
  // Assertions (simulation only)
  //   S1  sp never exceeds DEPTH, push is never attempted on a full stack
  //   S2  pop is never attempted without a found entry
  //   S3  push and pop never coincide
  //   S4  (compliant code) DIV entries are pairwise disjoint and disjoint from
  //       the active mask, after masking with live
  // ---------------------------------------------------------------------------
`ifndef SYNTHESIS
  logic err_q;
  assign assert_err_o = err_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      err_q <= 1'b0;
    end else begin
      if (sp_q > SP_W'(DEPTH)) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m S1: sp=%0d > DEPTH", sp_q);
      end
      if (push_i && !clear_i && sp_q == SP_W'(DEPTH)) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m S1: push on full stack");
      end
      if (pop_i && !clear_i && !found_o) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m S2: pop without found entry");
      end
      if (push_i && pop_i) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m S3: push and pop together");
      end
      if (chk_struct_i) begin
        for (int unsigned i = 0; i < DEPTH; i++) begin
          if (i < int'(sp_q) && kind_q[i]) begin
            if ((mask_q[i] & live_i & active_i) != '0) begin
              err_q <= 1'b1; $display("[SF-ASSERT] %m S4: DIV[%0d] overlaps active mask", i);
            end
            for (int unsigned j = i + 1; j < DEPTH; j++) begin
              if (j < int'(sp_q) && kind_q[j] && ((mask_q[i] & mask_q[j] & live_i) != '0)) begin
                err_q <= 1'b1; $display("[SF-ASSERT] %m S4: DIV[%0d] overlaps DIV[%0d]", i, j);
              end
            end
          end
        end
      end
    end
  end
`else
  assign assert_err_o = 1'b0;
`endif

endmodule : sf_simt_stack
