// =============================================================================
//  SilicaFlux :: sf_simt_warp_ctx.sv
//  One resident-warp context: state machine, PC, active/live masks,
//  reconvergence stack, 1-entry instruction buffer, in-flight slot table and
//  register scoreboard. All control-flow semantics (SSY/SYNC/EXIT/JMP/BAR and
//  conditional-branch resolution) are executed here.
// =============================================================================
//  Authoritative description: docs/ARCHITECTURE.md (sections 4-8).
//
//  Masks
//    live   : threads that have not executed EXIT (and were not killed)
//    active : threads executing the instruction at pc, active is a subset of live
//
//  Backend-bound instructions allocate one in-flight *slot* at issue. The slot
//  index is the transaction tag returned by the backend; a completion retires
//  exactly one valid slot. Slots are the sole owner of scoreboard bits:
//      pend  = OR over valid slots with a destination of (1 << rd)
//      pendm = same, restricted to loads
//  Completions that do not name a valid slot of a resident context (stale,
//  duplicate, wrong warp, out-of-range) are dropped and flagged: instructions
//  can never retire from an inactive context.
// =============================================================================

`default_nettype none

module sf_simt_warp_ctx
  import sf_simt_pkg::*;
#(
  parameter int unsigned WID         = 0,
  parameter int unsigned NUM_WARPS   = 8,
  parameter int unsigned WARP_SIZE   = 32,
  parameter int unsigned PC_W        = 16,
  parameter int unsigned STACK_DEPTH = 8,
  parameter int unsigned NUM_SLOTS   = 4
) (
  input  logic                                     clk_i,
  input  logic                                     rst_ni,

  // lifecycle ------------------------------------------------------------
  input  logic                                     launch_clr_i,   // new kernel accepted: clear sticky status
  input  logic                                     launch_i,       // activate this warp
  input  logic [PC_W-1:0]                          launch_pc_i,
  input  logic [WARP_SIZE-1:0]                     launch_mask_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] launch_wg_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] launch_widx_i,
  input  logic                                     free_i,         // kernel complete: DONE -> FREE
  input  logic                                     core_run_i,
  input  logic                                     kill_i,         // workgroup killed
  input  logic                                     chk_struct_i,

  // instruction fetch -------------------------------------------------------
  output logic                                     want_fetch_o,
  output logic [PC_W-1:0]                          pc_o,
  input  logic                                     fetch_grant_i,
  input  logic                                     rsp_valid_i,    // response addressed to this warp
  input  logic [PC_W-1:0]                          rsp_pc_i,
  input  sf_dinstr_t                               rsp_di_i,

  // issue ---------------------------------------------------------------------
  input  logic [1:0]                               port_ready_i,
  output logic                                     cand_o,
  output logic                                     elig_o,
  input  logic                                     grant_i,
  output logic                                     iss_be_o,       // head is a backend instruction
  output logic [WARP_SIZE-1:0]                     iss_mask_o,
  output logic [31:0]                              iss_instr_o,
  output logic [(NUM_SLOTS>1 ? $clog2(NUM_SLOTS) : 1)-1:0] iss_slot_o,
  output logic                                     exec_o,         // grant_i and no fault
  output logic                                     is_bar_o,       // head is BAR (checker/trace)
  output logic                                     fill_o,         // instruction buffer filled this cycle

  // completions (two interchangeable channels) --------------------------------
  input  logic [1:0]                               cmpl_valid_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] cmpl_warp_i [2],
  input  logic [(NUM_SLOTS>1 ? $clog2(NUM_SLOTS) : 1)-1:0] cmpl_slot_i [2],
  input  logic [WARP_SIZE-1:0]                     cmpl_taken_i [2],

  // barrier -----------------------------------------------------------------
  input  logic                                     bar_release_i,

  // status --------------------------------------------------------------------
  output sf_wstate_e                               state_o,
  output logic [PC_W-1:0]                          pc_status_o,
  output logic [WARP_SIZE-1:0]                     active_o,
  output logic [WARP_SIZE-1:0]                     live_o,
  output logic [$clog2(STACK_DEPTH+1)-1:0]         sp_o,
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] wg_o,
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] widx_o,
  output sf_fault_e                                fault_o,
  output logic                                     fault_new_o,    // fault raised this cycle
  output sf_wclass_e                               class_o,
  output logic [$clog2(NUM_SLOTS+1)-1:0]           inflight_o,

  // events for perf counters
  output logic [1:0]                               retire_o,       // completions retired this cycle
  output logic                                     proto_err_o,    // dropped completion / response
  output logic                                     ev_branch_o,
  output logic                                     ev_div_o,
  output logic                                     ev_sync_o,

  output logic                                     assert_err_o
);

  localparam int unsigned WID_W  = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1;
  localparam int unsigned SLOT_W = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1;
  localparam int unsigned SP_W   = $clog2(STACK_DEPTH + 1);

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  sf_wstate_e                 state_q,        n_state;
  logic [PC_W-1:0]            pc_q,           n_pc;
  logic [WARP_SIZE-1:0]       active_q,       n_active;
  logic [WARP_SIZE-1:0]       live_q,         n_live;
  logic                       ibuf_valid_q,   n_ibuf_valid;
  sf_dinstr_t                 ibuf_q,         n_ibuf;
  logic                       fetch_pend_q,   n_fetch_pend;
  logic [PC_W-1:0]            br_target_q,    n_br_target;
  logic [WID_W-1:0]           wg_q,           widx_q;
  sf_fault_e                  fault_q,        n_fault;

  logic [NUM_SLOTS-1:0]       slot_v_q,       n_slot_v;
  logic [NUM_SLOTS-1:0]       slot_wr_q,      n_slot_wr;
  logic [NUM_SLOTS-1:0]       slot_mem_q,     n_slot_mem;
  logic [NUM_SLOTS-1:0]       slot_br_q,      n_slot_br;
  logic [4:0]                 slot_rd_q [NUM_SLOTS];
  logic [4:0]                 n_slot_rd [NUM_SLOTS];
  logic [SF_NUM_REGS-1:0]     pend_q,         n_pend;
  logic [SF_NUM_REGS-1:0]     pendm_q,        n_pendm;

  // reconvergence stack control
  logic                       stk_clear, stk_push, stk_push_kind, stk_pop;
  logic [PC_W-1:0]            stk_push_pc;
  logic [WARP_SIZE-1:0]       stk_push_mask;
  logic [WARP_SIZE-1:0]       live_search;
  logic [SP_W-1:0]            stk_sp;
  logic                       stk_full, stk_found, stk_found_kind;
  logic [SP_W-1:0]            stk_found_idx;
  logic [PC_W-1:0]            stk_found_pc;
  logic [WARP_SIZE-1:0]       stk_found_mask;
  logic                       stk_err;

  // ---------------------------------------------------------------------------
  // Head instruction decode
  // ---------------------------------------------------------------------------
  sf_dinstr_t   di;
  logic [4:0]   rd, rs1, rs2;
  logic [16:0]  imm17;
  logic [PC_W-1:0] pc_plus1, tgt;

  assign di    = ibuf_q;
  assign rd    = sf_f_rd(di.raw);
  assign rs1   = sf_f_rs1(di.raw);
  assign rs2   = sf_f_rs2(di.raw);
  assign imm17 = sf_f_imm17(di.raw);

  logic signed [16:0] simm17;
  assign simm17   = $signed(imm17);
  assign pc_plus1 = pc_q + PC_W'(1);
  assign tgt      = pc_q + PC_W'(1) + PC_W'(simm17);

  assign is_bar_o = (di.op == OP_BAR) && !di.illegal && !di.fetch_err;

  // ---------------------------------------------------------------------------
  // Eligibility / stall attribution (registered state + backend-ready inputs)
  // ---------------------------------------------------------------------------
  logic have_free;
  logic [SLOT_W-1:0] free_idx;
  always_comb begin
    have_free = 1'b0;
    free_idx  = '0;
    for (int i = NUM_SLOTS - 1; i >= 0; i--) begin
      if (!slot_v_q[i]) begin
        have_free = 1'b1;
        free_idx  = SLOT_W'(i);
      end
    end
  end

  logic head_v, needs_be, port_idx, haz_any, haz_mem, bar_blk, mem_infl, slot_blk, port_blk;
  logic st_mem, st_dep, st_struct;

  assign head_v   = (state_q == W_RUN) && ibuf_valid_q && core_run_i && !kill_i;
  assign needs_be = (di.cls != SF_CLS_LOCAL);
  assign port_idx = (di.cls == SF_CLS_LD) || (di.cls == SF_CLS_ST);

  assign haz_any  = (di.use_rs1 && pend_q[rs1]) || (di.use_rs2 && pend_q[rs2]) || (di.wr_rd && pend_q[rd]);
  assign haz_mem  = (di.use_rs1 && pendm_q[rs1]) || (di.use_rs2 && pendm_q[rs2]) || (di.wr_rd && pendm_q[rd]);
  assign mem_infl = |(slot_v_q & slot_mem_q);
  // BAR is an implicit fence: it issues only when every earlier operation of
  // this warp has retired, so a barrier release implies memory visibility.
  assign bar_blk  = is_bar_o && (|slot_v_q);
  assign slot_blk = needs_be && !have_free;
  assign port_blk = needs_be && !port_ready_i[port_idx];

  assign cand_o   = head_v && !haz_any && !bar_blk && !slot_blk;
  assign elig_o   = cand_o && !port_blk;

  assign st_mem    = head_v && (haz_mem || (bar_blk && mem_infl));
  assign st_dep    = head_v && !st_mem && (haz_any || bar_blk);
  assign st_struct = head_v && !haz_any && !bar_blk && (slot_blk || port_blk);

  assign want_fetch_o = core_run_i && !kill_i && (state_q == W_RUN) && !ibuf_valid_q && !fetch_pend_q;
  assign pc_o         = pc_q;

  assign iss_be_o    = needs_be;
  assign iss_mask_o  = active_q;
  assign iss_instr_o = di.raw;
  assign iss_slot_o  = free_idx;

  // ---------------------------------------------------------------------------
  // Completion decode
  // ---------------------------------------------------------------------------
  logic [1:0] c_hit, c_ok;
  always_comb begin
    for (int p = 0; p < 2; p++) begin
      c_hit[p] = cmpl_valid_i[p] && (cmpl_warp_i[p] == WID_W'(WID));
      c_ok[p]  = 1'b0;
      if (c_hit[p] && (int'(cmpl_slot_i[p]) < int'(NUM_SLOTS)))
        c_ok[p] = slot_v_q[cmpl_slot_i[p]];
    end
    // same slot completed twice in one cycle: the second one is a duplicate
    if (c_ok[0] && c_ok[1] && (cmpl_slot_i[0] == cmpl_slot_i[1])) c_ok[1] = 1'b0;
  end

  assign retire_o = {1'b0, c_ok[0]} + {1'b0, c_ok[1]};

  // ---------------------------------------------------------------------------
  // Next-state logic
  // ---------------------------------------------------------------------------
  sf_fault_e                  fault_now;
  logic                       rsp_spurious;
  logic                       br_resp;
  logic [WARP_SIZE-1:0]       br_taken;
  logic [WARP_SIZE-1:0]       br_cond, br_nt;

  assign live_search = (di.op == OP_EXIT) ? (live_q & ~active_q) : live_q;

  always_comb begin
    // defaults ---------------------------------------------------------------
    n_state       = state_q;
    n_pc          = pc_q;
    n_active      = active_q;
    n_live        = live_q;
    n_ibuf_valid  = ibuf_valid_q;
    n_ibuf        = ibuf_q;
    n_fetch_pend  = fetch_pend_q;
    n_br_target   = br_target_q;
    n_fault       = fault_q;
    n_slot_v      = slot_v_q;
    n_slot_wr     = slot_wr_q;
    n_slot_mem    = slot_mem_q;
    n_slot_br     = slot_br_q;
    for (int s = 0; s < NUM_SLOTS; s++) n_slot_rd[s] = slot_rd_q[s];
    n_pend        = pend_q;
    n_pendm       = pendm_q;

    stk_clear     = 1'b0;
    stk_push      = 1'b0;
    stk_push_kind = 1'b0;
    stk_push_pc   = '0;
    stk_push_mask = '0;
    stk_pop       = 1'b0;

    fault_now     = F_NONE;
    rsp_spurious  = 1'b0;
    br_resp       = 1'b0;
    br_taken      = '0;
    br_cond       = '0;
    br_nt         = '0;
    ev_branch_o   = 1'b0;
    ev_div_o      = 1'b0;
    ev_sync_o     = 1'b0;

    // completions: free slots, clear scoreboard, capture branch result ----------
    for (int p = 0; p < 2; p++) begin
      if (c_ok[p]) begin
        n_slot_v[cmpl_slot_i[p]]   = 1'b0;
        n_slot_wr[cmpl_slot_i[p]]  = 1'b0;
        n_slot_mem[cmpl_slot_i[p]] = 1'b0;
        n_slot_br[cmpl_slot_i[p]]  = 1'b0;
        if (slot_wr_q[cmpl_slot_i[p]]) begin
          n_pend[slot_rd_q[cmpl_slot_i[p]]]  = 1'b0;
          n_pendm[slot_rd_q[cmpl_slot_i[p]]] = 1'b0;
        end
        if (slot_br_q[cmpl_slot_i[p]]) begin
          br_resp  = 1'b1;
          br_taken = cmpl_taken_i[p];
        end
      end
    end

    // instruction fetch response ---------------------------------------------------
    if (fetch_grant_i) n_fetch_pend = 1'b1;
    if (rsp_valid_i) begin
      if (!fetch_pend_q) begin
        rsp_spurious = 1'b1;                          // nobody asked
      end else if (state_q == W_RUN) begin
        if (rsp_pc_i == pc_q) begin
          n_ibuf        = rsp_di_i;
          n_ibuf_valid  = 1'b1;
          n_fetch_pend  = 1'b0;
        end else begin
          rsp_spurious  = 1'b1;                       // wrong pc: drop, keep waiting
        end
      end else begin
        n_fetch_pend = 1'b0;                          // draining context: discard
      end
    end

    // conditional-branch resolution ----------------------------------------------------
    if (br_resp && state_q == W_BRW) begin
      ev_branch_o = 1'b1;
      br_cond     = br_taken & active_q;
      br_nt       = active_q & ~br_taken;
      if (br_cond == '0) begin
        n_pc    = pc_plus1;
        n_state = W_RUN;
      end else if (br_nt == '0) begin
        n_pc    = br_target_q;
        n_state = W_RUN;
      end else begin
        ev_div_o = 1'b1;
        if (stk_sp == '0) begin
          fault_now = F_NO_REGION;
        end else if (stk_full) begin
          fault_now = F_STK_OVF;
        end else begin
          stk_push      = 1'b1;
          stk_push_kind = 1'b1;                       // DIV: deferred taken path
          stk_push_pc   = br_target_q;
          stk_push_mask = br_cond;
          n_active      = br_nt;                      // fall-through path first
          n_pc          = pc_plus1;
          n_state       = W_RUN;
        end
      end
    end

    // issue -----------------------------------------------------------------------------
    if (grant_i) begin
      n_ibuf_valid = 1'b0;
      if (di.fetch_err) begin
        fault_now = F_FETCH;
      end else if (di.illegal) begin
        fault_now = F_ILLEGAL;
      end else begin
        case (di.op)
          OP_NOP: n_pc = pc_plus1;
          OP_JMP: n_pc = tgt;
          OP_SSY: begin
            if (stk_full) begin
              fault_now = F_STK_OVF;
            end else begin
              stk_push      = 1'b1;
              stk_push_kind = 1'b0;                   // TOKEN
              stk_push_pc   = tgt;
              stk_push_mask = active_q;
              n_pc          = pc_plus1;
            end
          end
          OP_SYNC: begin
            ev_sync_o = 1'b1;
            if (stk_sp == '0) begin
              fault_now = F_STK_UNF;
            end else if (!stk_found) begin
              fault_now = F_LOST;
            end else begin
              stk_pop  = 1'b1;
              n_pc     = stk_found_pc;
              n_active = stk_found_mask & live_q;
            end
          end
          OP_EXIT: begin
            n_live = live_q & ~active_q;
            if (n_live == '0) begin
              n_state  = W_DRAIN;
              n_active = '0;
              stk_clear = 1'b1;
            end else if (!stk_found) begin
              fault_now = F_LOST;
            end else begin
              stk_pop  = 1'b1;
              n_pc     = stk_found_pc;
              n_active = stk_found_mask & n_live;
            end
          end
          OP_BAR: begin
            if (active_q != live_q) begin
              fault_now = F_DIV_BAR;
            end else begin
              n_state = W_BAR;
              n_pc    = pc_plus1;
            end
          end
          OP_BNZ, OP_BZ: begin
            n_slot_v[free_idx]   = 1'b1;
            n_slot_wr[free_idx]  = 1'b0;
            n_slot_mem[free_idx] = 1'b0;
            n_slot_br[free_idx]  = 1'b1;
            n_slot_rd[free_idx]  = 5'd0;
            n_br_target          = tgt;
            n_state              = W_BRW;
          end
          default: begin                              // ALU / LD / ST
            n_slot_v[free_idx]   = 1'b1;
            n_slot_wr[free_idx]  = di.wr_rd;
            n_slot_mem[free_idx] = (di.cls == SF_CLS_LD) || (di.cls == SF_CLS_ST);
            n_slot_br[free_idx]  = 1'b0;
            n_slot_rd[free_idx]  = rd;
            if (di.wr_rd) begin
              n_pend[rd]  = 1'b1;
              n_pendm[rd] = (di.cls == SF_CLS_LD);
            end
            n_pc = pc_plus1;
          end
        endcase
      end
    end

    // barrier release --------------------------------------------------------------------
    if (state_q == W_BAR && bar_release_i) n_state = W_RUN;

    // fault overlay: the faulting instruction is not executed; the warp drains -----------
    if (fault_now != F_NONE) begin
      n_state       = W_DRAIN;
      n_active      = '0;
      n_live        = '0;
      n_ibuf_valid  = 1'b0;
      stk_clear     = 1'b1;
      stk_push      = 1'b0;
      stk_pop       = 1'b0;
      if (fault_q == F_NONE) n_fault = fault_now;
    end

    // workgroup kill overlay ----------------------------------------------------------------
    if (kill_i && (state_q == W_RUN || state_q == W_BRW || state_q == W_BAR)) begin
      n_state       = W_DRAIN;
      n_active      = '0;
      n_live        = '0;
      n_ibuf_valid  = 1'b0;
      stk_clear     = 1'b1;
      stk_push      = 1'b0;
      stk_pop       = 1'b0;
      if (fault_q == F_NONE && fault_now == F_NONE) n_fault = F_WG_KILLED;
    end

    // drain -> done ----------------------------------------------------------------------------
    if (state_q == W_DRAIN && n_slot_v == '0 && !n_fetch_pend) n_state = W_DONE;
  end

  assign fill_o       = rsp_valid_i && fetch_pend_q && (state_q == W_RUN) && (rsp_pc_i == pc_q);
  assign fault_new_o  = (fault_now != F_NONE);
  assign exec_o       = grant_i && (fault_now == F_NONE);
  assign proto_err_o  = (|(c_hit & ~c_ok)) || rsp_spurious;

  // ---------------------------------------------------------------------------
  // Registers
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q      <= W_FREE;
      pc_q         <= '0;
      active_q     <= '0;
      live_q       <= '0;
      ibuf_valid_q <= 1'b0;
      ibuf_q       <= '0;
      fetch_pend_q <= 1'b0;
      br_target_q  <= '0;
      wg_q         <= '0;
      widx_q       <= '0;
      fault_q      <= F_NONE;
      slot_v_q     <= '0;
      slot_wr_q    <= '0;
      slot_mem_q   <= '0;
      slot_br_q    <= '0;
      for (int s = 0; s < NUM_SLOTS; s++) slot_rd_q[s] <= '0;
      pend_q       <= '0;
      pendm_q      <= '0;
    end else begin
      if (launch_clr_i) fault_q <= F_NONE;
      if (launch_i) begin
        state_q      <= W_RUN;
        pc_q         <= launch_pc_i;
        active_q     <= launch_mask_i;
        live_q       <= launch_mask_i;
        ibuf_valid_q <= 1'b0;
        fetch_pend_q <= 1'b0;
        wg_q         <= launch_wg_i;
        widx_q       <= launch_widx_i;
        slot_v_q     <= '0;
        slot_wr_q    <= '0;
        slot_mem_q   <= '0;
        slot_br_q    <= '0;
        pend_q       <= '0;
        pendm_q      <= '0;
      end else if (free_i) begin
        if (state_q == W_DONE) state_q <= W_FREE;
      end else begin
        state_q      <= n_state;
        pc_q         <= n_pc;
        active_q     <= n_active;
        live_q       <= n_live;
        ibuf_valid_q <= n_ibuf_valid;
        ibuf_q       <= n_ibuf;
        fetch_pend_q <= n_fetch_pend;
        br_target_q  <= n_br_target;
        if (!launch_clr_i) fault_q <= n_fault;
        slot_v_q     <= n_slot_v;
        slot_wr_q    <= n_slot_wr;
        slot_mem_q   <= n_slot_mem;
        slot_br_q    <= n_slot_br;
        for (int s = 0; s < NUM_SLOTS; s++) slot_rd_q[s] <= n_slot_rd[s];
        pend_q       <= n_pend;
        pendm_q      <= n_pendm;
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Reconvergence stack
  // ---------------------------------------------------------------------------
  sf_simt_stack #(
    .DEPTH  (STACK_DEPTH),
    .MASK_W (WARP_SIZE),
    .PC_W   (PC_W)
  ) u_stack (
    .clk_i        (clk_i),
    .rst_ni       (rst_ni),
    .clear_i      (stk_clear || launch_i),
    .push_i       (stk_push),
    .push_kind_i  (stk_push_kind),
    .push_pc_i    (stk_push_pc),
    .push_mask_i  (stk_push_mask),
    .pop_i        (stk_pop),
    .live_i       (live_search),
    .active_i     (active_q),
    .chk_struct_i (chk_struct_i && (state_q == W_RUN)),
    .sp_o         (stk_sp),
    .full_o       (stk_full),
    .found_o      (stk_found),
    .found_idx_o  (stk_found_idx),
    .found_kind_o (stk_found_kind),
    .found_pc_o   (stk_found_pc),
    .found_mask_o (stk_found_mask),
    .assert_err_o (stk_err)
  );

  // ---------------------------------------------------------------------------
  // Status outputs
  // ---------------------------------------------------------------------------
  assign state_o     = state_q;
  assign pc_status_o = pc_q;
  assign active_o    = active_q;
  assign live_o      = live_q;
  assign sp_o        = stk_sp;
  assign wg_o        = wg_q;
  assign widx_o      = widx_q;
  assign fault_o     = fault_q;

  always_comb begin
    inflight_o = '0;
    for (int s = 0; s < NUM_SLOTS; s++) inflight_o = inflight_o + ($clog2(NUM_SLOTS+1))'(slot_v_q[s]);
  end

  always_comb begin
    class_o = WC_FREE;
    case (state_q)
      W_FREE:  class_o = WC_FREE;
      W_DONE:  class_o = WC_DONE;
      W_DRAIN: class_o = WC_DRAIN;
      W_BAR:   class_o = WC_BAR;
      W_BRW:   class_o = WC_FRONT;
      W_RUN: begin
        if (!core_run_i)          class_o = WC_FRONT;
        else if (kill_i)          class_o = WC_DRAIN;
        else if (!ibuf_valid_q)   class_o = WC_FRONT;
        else if (grant_i)         class_o = WC_ISSUED;
        else if (elig_o)          class_o = WC_READY;
        else if (st_mem)          class_o = WC_MEM;
        else if (st_dep)          class_o = WC_DEP;
        else                      class_o = WC_STRUCT;
      end
      default: class_o = WC_FREE;
    endcase
  end

  // ---------------------------------------------------------------------------
  // Assertions (simulation only): warp-state consistency and bounded-resource
  // ownership. See docs/ARCHITECTURE.md section 13 for the property list.
  // ---------------------------------------------------------------------------
`ifndef SYNTHESIS
  logic                    err_q;
  logic [SF_NUM_REGS-1:0]  exp_pend, exp_pendm;
  assign assert_err_o = err_q | stk_err;

  always_comb begin
    exp_pend  = '0;
    exp_pendm = '0;
    for (int s = 0; s < NUM_SLOTS; s++) begin
      if (slot_v_q[s] && slot_wr_q[s]) begin
        exp_pend[slot_rd_q[s]]  = 1'b1;
        exp_pendm[slot_rd_q[s]] = slot_mem_q[s];
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      err_q <= 1'b0;
    end else begin
      // W1: state encoding legal
      if (state_q != W_FREE && state_q != W_RUN && state_q != W_BRW &&
          state_q != W_BAR  && state_q != W_DRAIN && state_q != W_DONE) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W1: illegal state %0d", state_q);
      end
      // W2: FREE/DONE contexts own nothing (bounded-resource ownership)
      if ((state_q == W_FREE || state_q == W_DONE) &&
          ((|slot_v_q) || (|pend_q) || (|pendm_q) || ibuf_valid_q || fetch_pend_q ||
           (|active_q) || (|live_q) || (stk_sp != '0))) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W2: inactive context owns resources (state=%0d)", state_q);
      end
      // W3: instruction buffer only in RUN, never together with an outstanding fetch
      if (ibuf_valid_q && state_q != W_RUN) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W3: ibuf valid outside RUN");
      end
      if (ibuf_valid_q && fetch_pend_q) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W3: ibuf valid with fetch pending");
      end
      if (fetch_pend_q && state_q != W_RUN && state_q != W_DRAIN) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W3: fetch pending in state %0d", state_q);
      end
      // W4: RUN has a non-empty active set contained in the live set
      if (state_q == W_RUN && ((active_q == '0) || (live_q == '0) || ((active_q & ~live_q) != '0))) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W4: RUN with bad masks active=%h live=%h", active_q, live_q);
      end
      // W5: DRAIN/DONE/FREE have empty masks and an empty stack (DRAIN)
      if ((state_q == W_DRAIN || state_q == W_DONE || state_q == W_FREE) &&
          ((|active_q) || (|live_q))) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W5: masks not empty in state %0d", state_q);
      end
      if (state_q == W_DRAIN && ibuf_valid_q) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W5: ibuf valid while draining");
      end
      // W6: exactly one branch slot while waiting; none outside BRW/DRAIN
      if (state_q == W_BRW && ($countones(slot_v_q & slot_br_q) != 1)) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W6: BRW without exactly one branch slot");
      end
      if (state_q != W_BRW && state_q != W_DRAIN && (|(slot_v_q & slot_br_q))) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W6: branch slot outside BRW/DRAIN");
      end
      // W7: scoreboard equals the union of valid slot destinations; r0 never pending
      if (pend_q != exp_pend || pendm_q != exp_pendm || pend_q[0]) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W7: scoreboard/slot mismatch pend=%h exp=%h", pend_q, exp_pend);
      end
      // W8: a warp waiting at a barrier is converged and fully drained
      if (state_q == W_BAR && ((active_q != live_q) || (|slot_v_q))) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W8: barrier arrival not converged/drained");
      end
      // W9: issue only from an eligible RUN context (no duplicate / phantom issue)
      if (grant_i && !(elig_o && state_q == W_RUN && ibuf_valid_q && !kill_i)) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W9: grant to non-eligible context");
      end
      // W10: structural invariant of compliant code: empty stack => fully converged
      if (chk_struct_i && state_q == W_RUN && stk_sp == '0 && active_q != live_q) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W10: empty stack but active != live");
      end
      // W11: a context that is not resident never retires an instruction
      if ((state_q == W_FREE) && (|c_ok)) begin
        err_q <= 1'b1; $display("[SF-ASSERT] %m W11: retire on FREE context");
      end
    end
  end
`else
  assign assert_err_o = 1'b0;
`endif

endmodule : sf_simt_warp_ctx
