// =============================================================================
//  SilicaFlux :: sf_warp_arb.sv
//  Single-grant warp issue arbiter. Two deterministic, starvation-free policies.
// =============================================================================
//  Inputs
//    cand_i[w]  warp w holds a hazard-free instruction and an in-flight slot
//               (it can only stop being a candidate by being granted or killed)
//    elig_i[w]  cand_i[w] AND the backend port it needs is ready this cycle
//               (elig_i is a subset of cand_i)
//  Output
//    grant_o    one-hot or zero; grant_o is a subset of elig_i (work conserving:
//               it is non-zero whenever elig_i is non-zero)
//
//  POLICY = SF_POLICY_RR  (round robin with a monotonic pointer)
//    Scan the warps cyclically starting at ptr.
//      winner  = the first ELIGIBLE warp in scan order
//      blocked = the first candidate that is NOT eligible (its backend port is busy)
//                and lies before the winner in scan order, if any
//    After a grant:  ptr = blocked if it exists, otherwise winner + 1.
//    Invariant: the pointer never moves past a candidate that has not been granted.
//    Consequence: a candidate is reached by the pointer after at most N-1 pointer
//    steps; each step needs a grant or a backend-port-ready event, so with every port
//    ready at least once per G cycles a candidate is granted within N*G + 1 cycles,
//    whatever the readiness pattern (no phase locking, no adversarial schedule).
//    (A "loose" RR that always sets ptr = winner+1 can starve a warp whose port is
//    ready only when the pointer has just passed it.)
//
//  POLICY = SF_POLICY_AGE (oldest-first, age = time since last issue)
//    older[j][i] = 1  <=>  warp j last issued earlier than warp i (j is older).
//    The matrix always encodes a strict total order (reset: lower id is older).
//    The oldest eligible warp wins; the winner becomes the youngest.
//    Bound : while a warp is eligible it is overtaken at most N-1 times,
//            independent of how backend readiness behaves.
// =============================================================================

`default_nettype none

module sf_warp_arb
  import sf_simt_pkg::*;
#(
  parameter int unsigned N      = 8,
  parameter int unsigned POLICY = SF_POLICY_RR
) (
  input  logic         clk_i,
  input  logic         rst_ni,
  input  logic         clear_i,     // re-initialise arbitration state (kernel launch)
  input  logic [N-1:0] cand_i,
  input  logic [N-1:0] elig_i,
  output logic [N-1:0] grant_o,
  output logic         assert_err_o
);

  localparam int unsigned PTR_W = (N > 1) ? $clog2(N) : 1;

  logic fire;
  assign fire = |grant_o;

  // ===========================================================================
  generate
    if (POLICY == SF_POLICY_AGE) begin : g_age
      // older_q[j][i] : j older than i
      logic [N-1:0] older_q [N];
      logic [N-1:0] col     [N];   // col[i][j] = older_q[j][i]

      always_comb begin
        for (int unsigned i = 0; i < N; i++)
          for (int unsigned j = 0; j < N; j++)
            col[i][j] = older_q[j][i];
        for (int unsigned i = 0; i < N; i++)
          grant_o[i] = elig_i[i] & ~(|(elig_i & col[i]));
      end

      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
          for (int unsigned i = 0; i < N; i++)
            for (int unsigned j = 0; j < N; j++)
              older_q[i][j] <= (i < j);
        end else if (clear_i) begin
          for (int unsigned i = 0; i < N; i++)
            for (int unsigned j = 0; j < N; j++)
              older_q[i][j] <= (i < j);
        end else if (fire) begin
          for (int unsigned k = 0; k < N; k++) begin
            if (grant_o[k]) begin
              for (int unsigned j = 0; j < N; j++) begin
                if (j != k) begin
                  older_q[j][k] <= 1'b1;
                  older_q[k][j] <= 1'b0;
                end
              end
            end
          end
        end
      end

`ifndef SYNTHESIS
      logic err_q;
      assign assert_err_o = err_q;
      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) err_q <= 1'b0;
        else begin
          for (int unsigned i = 0; i < N; i++) begin
            if (older_q[i][i]) begin
              err_q <= 1'b1; $display("[SF-ASSERT] %m A1: older[%0d][%0d] set", i, i);
            end
            for (int unsigned j = i + 1; j < N; j++)
              if (older_q[i][j] == older_q[j][i]) begin
                err_q <= 1'b1; $display("[SF-ASSERT] %m A1: age order not total (%0d,%0d)", i, j);
              end
          end
          if (|(grant_o & ~elig_i)) begin
            err_q <= 1'b1; $display("[SF-ASSERT] %m A2: grant of non-eligible warp");
          end
          if (!$onehot0(grant_o)) begin
            err_q <= 1'b1; $display("[SF-ASSERT] %m A3: grant not one-hot");
          end
        end
      end
`else
      assign assert_err_o = 1'b0;
`endif

    end else begin : g_rr
      logic [PTR_W-1:0] ptr_q, nxt_ptr;
      logic             found_w, found_b;

      // scan from ptr: first eligible warp wins; the first blocked candidate before it holds the pointer
      always_comb begin
        grant_o  = '0;
        nxt_ptr  = ptr_q;
        found_w  = 1'b0;
        found_b  = 1'b0;
        for (int unsigned k = 0; k < N; k++) begin
          int unsigned idx;
          idx = (int'(ptr_q) + int'(k)) % N;
          if (!found_w) begin
            if (elig_i[idx]) begin
              found_w       = 1'b1;
              grant_o[idx]  = 1'b1;
              if (!found_b) nxt_ptr = PTR_W'((idx + 1) % N);
            end else if (cand_i[idx] && !found_b) begin
              found_b = 1'b1;
              nxt_ptr = PTR_W'(idx);
            end
          end
        end
      end

      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni)        ptr_q <= '0;
        else if (clear_i)   ptr_q <= '0;
        else if (found_w)   ptr_q <= nxt_ptr;
      end

`ifndef SYNTHESIS
      logic err_q;
      assign assert_err_o = err_q;
      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) err_q <= 1'b0;
        else begin
          if (|(grant_o & ~elig_i)) begin
            err_q <= 1'b1; $display("[SF-ASSERT] %m A2: grant of non-eligible warp");
          end
          if (!$onehot0(grant_o)) begin
            err_q <= 1'b1; $display("[SF-ASSERT] %m A3: grant not one-hot");
          end
          if (|(elig_i & ~cand_i)) begin
            err_q <= 1'b1; $display("[SF-ASSERT] %m A4: eligible but not candidate");
          end
          if ((|elig_i) && !(|grant_o)) begin
            err_q <= 1'b1; $display("[SF-ASSERT] %m A5: eligible warps but no grant (not work-conserving)");
          end
          // A6: the pointer never moves past a candidate that was not granted
          if (found_w) begin
            for (int unsigned k = 0; k < N; k++) begin
              int unsigned idx, d_new;
              idx   = (int'(ptr_q) + int'(k)) % N;
              d_new = (int'(nxt_ptr) + N - int'(ptr_q)) % N;      // number of positions the pointer advances
              if (k < d_new && cand_i[idx] && !grant_o[idx]) begin
                err_q <= 1'b1; $display("[SF-ASSERT] %m A6: pointer passed non-granted candidate %0d", idx);
              end
            end
          end
        end
      end
`else
      assign assert_err_o = 1'b0;
`endif
    end
  endgenerate

endmodule : sf_warp_arb
