// =============================================================================
//  SilicaFlux :: sf_simt_dsm.sv   (simulation only)
//  Downstream model for the SIMT control unit: instruction memory, execution
//  backend (per-thread register files, ALU, global/shared memory) and the
//  completion network, with randomised but BOUNDED latency and back-pressure.
//
//  It implements exactly the downstream contract of docs/ARCHITECTURE.md
//  section 11 and therefore the fairness assumptions F1..F4:
//    F1 every accepted instruction completes (latency <= cfg_lat_*_max + completion-skip bound)
//    F2 each issue port is ready at least once every RDY_MAXGAP+1 cycles
//    F3 every fetch is answered (latency <= cfg_lat_if_max + skip bound)
//    F4 completions of an instruction never precede the cycle after its issue
//  Semantics: operands are sampled at the issue handshake; memory operations are
//  performed in issue order (functionally at issue); the register write happens
//  when the completion is presented.
// =============================================================================

`default_nettype none

module sf_simt_dsm #(
  parameter int unsigned NUM_WARPS   = 8,
  parameter int unsigned WARP_SIZE   = 32,
  parameter int unsigned PC_W        = 16,
  parameter int unsigned NUM_SLOTS   = 4,
  parameter int unsigned IMEM_WORDS  = 4096,
  parameter int unsigned GMEM_WORDS  = 16384,
  parameter int unsigned SMEM_WORDS  = 1024,
  parameter int unsigned POOL        = 64,
  parameter int unsigned RDY_MAXGAP  = 4,
  parameter int unsigned SKIP_MAXAGE = 6
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,

  // static configuration (set before launch)
  input  logic [31:0]                  cfg_seed_i,
  input  logic [31:0]                  cfg_lat_if_i,     // max fetch latency (>=1)
  input  logic [31:0]                  cfg_lat_alu_i,    // max ALU / branch latency (>=1)
  input  logic [31:0]                  cfg_lat_mem_i,    // max memory latency (>=1)
  input  logic [31:0]                  cfg_rdy_pct_i,    // % of cycles a backend port is ready (100 = always)
  input  logic [31:0]                  cfg_ifrdy_pct_i,  // % of cycles IMEM accepts a request
  input  logic [31:0]                  cfg_skip_pct_i,   // % chance an expired completion is delayed one more cycle
  input  logic [31:0]                  k_nwg_i,
  input  logic [31:0]                  k_wpw_i,
  input  logic [31:0]                  k_ntid_i,
  input  logic                         launch_i,         // clears register files

  // spurious traffic injection (one-cycle pulses; delayed until the channel is idle)
  input  logic                         inj_cmpl_i,
  input  logic [31:0]                  inj_cmpl_warp_i,
  input  logic [31:0]                  inj_cmpl_slot_i,
  input  logic                         inj_dup_i,        // re-send the last completion
  input  logic                         inj_rsp_i,
  input  logic [31:0]                  inj_rsp_warp_i,

  // instruction fetch
  input  logic                         if_req_valid_i,
  output logic                         if_req_ready_o,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] if_req_warp_i,
  input  logic [PC_W-1:0]              if_req_pc_i,
  output logic                         if_rsp_valid_o,
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] if_rsp_warp_o,
  output logic [PC_W-1:0]              if_rsp_pc_o,
  output logic [31:0]                  if_rsp_instr_o,
  output logic                         if_rsp_err_o,

  // issue
  input  logic                         iss_valid_i,
  input  logic                         iss_port_i,
  output logic [1:0]                   iss_ready_o,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] iss_warp_i,
  input  logic [(NUM_SLOTS>1 ? $clog2(NUM_SLOTS) : 1)-1:0] iss_slot_i,
  input  logic [PC_W-1:0]              iss_pc_i,
  input  logic [WARP_SIZE-1:0]         iss_mask_i,
  input  logic [31:0]                  iss_instr_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] iss_wg_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] iss_widx_i,

  // completions
  output logic [1:0]                   cmpl_valid_o,
  output logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] cmpl_warp_o [2],
  output logic [(NUM_SLOTS>1 ? $clog2(NUM_SLOTS) : 1)-1:0] cmpl_slot_o [2],
  output logic [WARP_SIZE-1:0]         cmpl_taken_o [2]
);

  localparam int unsigned WID_W  = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1;
  localparam int unsigned SLOT_W = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1;

  // ---------------------------------------------------------------------------
  // Memories and register files (hierarchically loaded / dumped by the TB)
  // ---------------------------------------------------------------------------
  logic [31:0] imem [IMEM_WORDS];
  logic [31:0] gmem [GMEM_WORDS];
  logic [31:0] smem [NUM_WARPS][SMEM_WORDS];
  logic [31:0] rf   [NUM_WARPS][WARP_SIZE][32];

  // ---------------------------------------------------------------------------
  // Pseudo random generator (xorshift32), deterministic from cfg_seed_i
  // ---------------------------------------------------------------------------
  logic [31:0] rng_s;
  function automatic logic [31:0] rnd();
    rng_s = rng_s ^ (rng_s << 13);
    rng_s = rng_s ^ (rng_s >> 17);
    rng_s = rng_s ^ (rng_s << 5);
    return rng_s;
  endfunction

  function automatic int unsigned urange(input logic [31:0] max);   // 0 .. max-1
    if (max <= 1) return 0;
    return int'(rnd() % max);
  endfunction

  // ---------------------------------------------------------------------------
  // Pools
  // ---------------------------------------------------------------------------
  // fetch pool
  localparam int unsigned FPOOL = NUM_WARPS + 4;
  logic                   f_v   [FPOOL];
  int unsigned            f_t   [FPOOL];
  int unsigned            f_age [FPOOL];
  int unsigned            f_seq [FPOOL];
  logic [WID_W-1:0]       f_warp[FPOOL];
  logic [PC_W-1:0]        f_pc  [FPOOL];

  // execution pool
  logic                   p_v   [POOL];
  int unsigned            p_t   [POOL];
  int unsigned            p_age [POOL];
  int unsigned            p_seq [POOL];
  logic [WID_W-1:0]       p_warp[POOL];
  logic [SLOT_W-1:0]      p_slot[POOL];
  logic                   p_br  [POOL];
  logic                   p_wr  [POOL];
  logic [4:0]             p_rd  [POOL];
  logic [WARP_SIZE-1:0]   p_mask[POOL];
  logic [WARP_SIZE-1:0]   p_taken[POOL];
  logic [31:0]            p_val [POOL][WARP_SIZE];

  int unsigned seq_ctr;
  int unsigned rdy_gap0_q, rdy_gap1_q, ifrdy_gap_q;
  logic        if_rdy_q;
  logic [1:0]  rdy_q;

  logic [WID_W-1:0] last_c_warp;
  logic [SLOT_W-1:0] last_c_slot;
  logic [WARP_SIZE-1:0] last_c_taken;
  logic              have_last;

  logic inj_c_pend, inj_d_pend, inj_r_pend;
  assign if_req_ready_o = if_rdy_q;
  assign iss_ready_o    = rdy_q;

  // ---------------------------------------------------------------------------
  // helpers
  // ---------------------------------------------------------------------------
  function automatic logic [31:0] sext17(input logic [16:0] v);
    return {{15{v[16]}}, v};
  endfunction
  function automatic logic [31:0] sext12(input logic [11:0] v);
    return {{20{v[11]}}, v};
  endfunction

  function automatic logic [31:0] alu_f(input logic [4:0] op, input logic [31:0] a, input logic [31:0] b);
    logic signed [31:0] sa, sb;
    sa = a; sb = b;
    case (op)
      5'h08: return a + b;
      5'h09: return a - b;
      5'h0A: return a * b;
      5'h0B: return a & b;
      5'h0C: return a | b;
      5'h0D: return a ^ b;
      5'h0E: return a << b[4:0];
      5'h0F: return a >> b[4:0];
      5'h10: return 32'(sa >>> b[4:0]);
      5'h11: return (sa < sb) ? 32'd1 : 32'd0;
      5'h12: return (a < b)  ? 32'd1 : 32'd0;
      default: return 32'd0;
    endcase
  endfunction

  function automatic logic [31:0] sreg_f(input logic [16:0] sid, input int wg, input int widx, input int lane);
    int tid;
    tid = widx * WARP_SIZE + lane;
    case (sid)
      17'd0: return 32'(lane);
      17'd1: return 32'(tid);
      17'd2: return k_ntid_i;
      17'd3: return 32'(wg);
      17'd4: return k_nwg_i;
      17'd5: return 32'(widx);
      17'd6: return 32'(wg) * (k_wpw_i * WARP_SIZE) + 32'(tid);
      17'd7: return 32'(wg) * k_wpw_i + 32'(widx);
      default: return 32'd0;
    endcase
  endfunction

  // ---------------------------------------------------------------------------
  // Main process
  // ---------------------------------------------------------------------------
  int unsigned best, cnt;
  logic        found;

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rng_s          <= (cfg_seed_i == 0) ? 32'h1BADB002 : cfg_seed_i;
      for (int i = 0; i < FPOOL; i++) f_v[i] = 1'b0;
      for (int i = 0; i < POOL;  i++) p_v[i] = 1'b0;
      seq_ctr        = 0;
      rdy_gap0_q     = 0;
      rdy_gap1_q     = 0;
      ifrdy_gap_q    = 0;
      if_rdy_q       <= 1'b0;
      rdy_q          <= 2'b00;
      if_rsp_valid_o <= 1'b0;
      cmpl_valid_o   <= 2'b00;
      have_last       = 1'b0;
      inj_c_pend      = 1'b0;
      inj_d_pend      = 1'b0;
      inj_r_pend      = 1'b0;
      for (int p = 0; p < 2; p++) begin
        cmpl_warp_o[p]  <= '0;
        cmpl_slot_o[p]  <= '0;
        cmpl_taken_o[p] <= '0;
      end
    end else begin
      // ---------------- launch clears the register files -----------------------------
      if (launch_i) begin
        for (int w = 0; w < NUM_WARPS; w++)
          for (int l = 0; l < WARP_SIZE; l++)
            for (int r = 0; r < 32; r++) rf[w][l][r] = 32'd0;
      end

      // ---------------- issue handshake: execute ---------------------------------------------
      if (iss_valid_i && iss_ready_o[iss_port_i]) begin
        logic [4:0]  op, rd, rs1, rs2;
        logic [16:0] imm17;
        logic [11:0] imm12;
        int          w, wg, widx, slot_i;
        logic [31:0] a, b, v;
        int          idx;
        logic [31:0] junk;
        idx = -1;
        for (int i = POOL - 1; i >= 0; i--) if (!p_v[i]) idx = i;
        if (idx < 0) $fatal(1, "[DSM] execution pool exhausted");
        op    = iss_instr_i[31:27];
        rd    = iss_instr_i[26:22];
        rs1   = iss_instr_i[21:17];
        rs2   = iss_instr_i[16:12];
        imm17 = iss_instr_i[16:0];
        imm12 = iss_instr_i[11:0];
        w     = int'(iss_warp_i);
        wg    = int'(iss_wg_i);
        widx  = int'(iss_widx_i);

        p_v[idx]     = 1'b1;
        p_warp[idx]  = iss_warp_i;
        p_slot[idx]  = iss_slot_i;
        p_mask[idx]  = iss_mask_i;
        p_br[idx]    = (op == 5'h06) || (op == 5'h07);
        p_wr[idx]    = 1'b0;
        p_rd[idx]    = rd;
        p_taken[idx] = '0;
        p_age[idx]   = 0;
        p_seq[idx]   = seq_ctr;
        seq_ctr      = seq_ctr + 1;
        for (int l = 0; l < WARP_SIZE; l++) p_val[idx][l] = 32'd0;

        for (int l = 0; l < WARP_SIZE; l++) begin
          a = (rs1 == 0) ? 32'd0 : rf[w][l][rs1];
          b = (rs2 == 0) ? 32'd0 : rf[w][l][rs2];
          if (iss_mask_i[l]) begin
            case (op)
              5'h06: p_taken[idx][l] = (a != 32'd0);
              5'h07: p_taken[idx][l] = (a == 32'd0);
              5'h08, 5'h09, 5'h0A, 5'h0B, 5'h0C, 5'h0D, 5'h0E, 5'h0F, 5'h10, 5'h11, 5'h12: begin
                p_val[idx][l] = alu_f(op, a, b); p_wr[idx] = 1'b1;
              end
              5'h13: begin p_val[idx][l] = a + sext17(imm17);            p_wr[idx] = 1'b1; end
              5'h14: begin p_val[idx][l] = {imm17, 15'd0};               p_wr[idx] = 1'b1; end
              5'h15: begin p_val[idx][l] = sreg_f(imm17, wg, widx, l);   p_wr[idx] = 1'b1; end
              5'h18: begin p_val[idx][l] = gmem[(a + sext12(imm12)) & (GMEM_WORDS - 1)]; p_wr[idx] = 1'b1; end
              5'h1A: begin p_val[idx][l] = smem[wg][(a + sext12(imm12)) & (SMEM_WORDS - 1)]; p_wr[idx] = 1'b1; end
              5'h19: gmem[(a + sext12(imm12)) & (GMEM_WORDS - 1)]      = b;
              5'h1B: smem[wg][(a + sext12(imm12)) & (SMEM_WORDS - 1)]  = b;
              default: ;
            endcase
          end else if (p_br[idx]) begin
            junk = rnd();
            p_taken[idx][l] = junk[7];      // garbage on inactive lanes: DUT must mask it
          end
        end
        // latency
        case (op)
          5'h18, 5'h19, 5'h1A, 5'h1B: p_t[idx] = urange(cfg_lat_mem_i);
          default:                    p_t[idx] = urange(cfg_lat_alu_i);
        endcase
      end

      // ---------------- age pools, then choose completions -----------------------------------------
      for (int i = 0; i < POOL; i++) begin
        if (p_v[i]) begin
          if (p_t[i] > 0) p_t[i] = p_t[i] - 1;
          else            p_age[i] = p_age[i] + 1;
        end
      end
      // (new entries created above have already been given their final timer; an entry with
      //  timer 0 is eligible in this very edge, so minimum issue->completion latency is 1 cycle)
      cmpl_valid_o <= 2'b00;
      begin
        int sel [2];
        // oldest expired entry -> channel 0, second oldest -> channel 1
        sel[0] = -1; sel[1] = -1;
        best = 32'hFFFF_FFFF;
        for (int i = 0; i < POOL; i++)
          if (p_v[i] && p_t[i] == 0 && p_seq[i] < best) begin best = p_seq[i]; sel[0] = i; end
        best = 32'hFFFF_FFFF;
        for (int i = 0; i < POOL; i++)
          if (p_v[i] && p_t[i] == 0 && i != sel[0] && p_seq[i] < best) begin best = p_seq[i]; sel[1] = i; end
        // optional extra delay, bounded by SKIP_MAXAGE cycles per entry (fairness assumption F1)
        for (int port = 0; port < 2; port++)
          if (sel[port] >= 0 && p_age[sel[port]] < SKIP_MAXAGE && urange(100) < cfg_skip_pct_i) sel[port] = -1;
        for (int port = 0; port < 2; port++) begin
          if (sel[port] >= 0) begin
            int i;
            i = sel[port];
            cmpl_valid_o[port]  <= 1'b1;
            cmpl_warp_o[port]   <= p_warp[i];
            cmpl_slot_o[port]   <= p_slot[i];
            cmpl_taken_o[port]  <= p_taken[i];
            last_c_warp          = p_warp[i];
            last_c_slot          = p_slot[i];
            last_c_taken         = p_taken[i];
            have_last            = 1'b1;
            if (p_wr[i] && p_rd[i] != 5'd0)
              for (int l = 0; l < WARP_SIZE; l++)
                if (p_mask[i][l]) rf[p_warp[i]][l][p_rd[i]] = p_val[i][l];
            p_v[i] = 1'b0;
          end
        end
        // spurious injections: latched, then driven on a channel that is idle this cycle.
        // A duplicate is driven on the *other* channel in the same cycle as the original completion
        // (same-cycle duplicate), which keeps the scenario independent of slot re-allocation timing.
        if (inj_cmpl_i) inj_c_pend = 1'b1;
        if (inj_dup_i)  inj_d_pend = 1'b1;
        if (inj_c_pend) begin
          int port;
          port = (sel[1] < 0) ? 1 : ((sel[0] < 0) ? 0 : -1);
          if (port >= 0) begin
            cmpl_valid_o[port] <= 1'b1;
            cmpl_warp_o[port]  <= WID_W'(inj_cmpl_warp_i);
            cmpl_slot_o[port]  <= SLOT_W'(inj_cmpl_slot_i);
            cmpl_taken_o[port] <= '0;
            inj_c_pend = 1'b0;
          end
        end else if (inj_d_pend) begin
          for (int port = 0; port < 2; port++) begin
            if (sel[port] >= 0 && sel[1 - port] < 0 && inj_d_pend) begin
              cmpl_valid_o[1 - port] <= 1'b1;
              cmpl_warp_o[1 - port]  <= p_warp[sel[port]];
              cmpl_slot_o[1 - port]  <= p_slot[sel[port]];
              cmpl_taken_o[1 - port] <= p_taken[sel[port]];
              inj_d_pend = 1'b0;
            end
          end
        end
      end

      // ---------------- fetch ------------------------------------------------------------------------
      for (int i = 0; i < FPOOL; i++) begin
        if (f_v[i]) begin
          if (f_t[i] > 0) f_t[i] = f_t[i] - 1;
          else            f_age[i] = f_age[i] + 1;
        end
      end
      if (if_req_valid_i && if_rdy_q) begin
        int idx;
        idx = -1;
        for (int i = FPOOL - 1; i >= 0; i--) if (!f_v[i]) idx = i;
        if (idx < 0) $fatal(1, "[DSM] fetch pool exhausted");
        f_v[idx]    = 1'b1;
        f_warp[idx] = if_req_warp_i;
        f_pc[idx]   = if_req_pc_i;
        f_t[idx]    = urange(cfg_lat_if_i);
        f_age[idx]  = 0;
        f_seq[idx]  = seq_ctr;
        seq_ctr     = seq_ctr + 1;
      end
      if_rsp_valid_o <= 1'b0;
      if (inj_rsp_i) inj_r_pend = 1'b1;
      begin
        int fsel;
        best = 32'hFFFF_FFFF; fsel = -1;
        for (int i = 0; i < FPOOL; i++)
          if (f_v[i] && f_t[i] == 0 && f_seq[i] < best) begin best = f_seq[i]; fsel = i; end
        if (fsel >= 0 && !(f_age[fsel] < SKIP_MAXAGE && urange(100) < cfg_skip_pct_i)) begin
          if_rsp_valid_o <= 1'b1;
          if_rsp_warp_o  <= f_warp[fsel];
          if_rsp_pc_o    <= f_pc[fsel];
          if (int'(f_pc[fsel]) >= int'(IMEM_WORDS)) begin
            if_rsp_instr_o <= 32'd0;
            if_rsp_err_o   <= 1'b1;
          end else begin
            if_rsp_instr_o <= imem[f_pc[fsel]];
            if_rsp_err_o   <= 1'b0;
          end
          f_v[fsel] = 1'b0;
        end else if (inj_r_pend) begin
          inj_r_pend = 1'b0;
          if_rsp_valid_o <= 1'b1;
          if_rsp_warp_o  <= WID_W'(inj_rsp_warp_i);
          if_rsp_pc_o    <= '0;
          if_rsp_instr_o <= 32'd0;
          if_rsp_err_o   <= 1'b0;
        end
      end

      // ---------------- readiness for the next cycle (bounded gaps) -------------------------------------
      if (cfg_rdy_pct_i >= 100) rdy_q <= 2'b11;
      else begin
        if (urange(100) < cfg_rdy_pct_i || rdy_gap0_q >= RDY_MAXGAP) begin rdy_q[0] <= 1'b1; rdy_gap0_q = 0; end
        else begin rdy_q[0] <= 1'b0; rdy_gap0_q = rdy_gap0_q + 1; end
        if (urange(100) < cfg_rdy_pct_i || rdy_gap1_q >= RDY_MAXGAP) begin rdy_q[1] <= 1'b1; rdy_gap1_q = 0; end
        else begin rdy_q[1] <= 1'b0; rdy_gap1_q = rdy_gap1_q + 1; end
      end
      if (cfg_ifrdy_pct_i >= 100) if_rdy_q <= 1'b1;
      else begin
        if (urange(100) < cfg_ifrdy_pct_i || ifrdy_gap_q >= RDY_MAXGAP) begin if_rdy_q <= 1'b1; ifrdy_gap_q = 0; end
        else begin if_rdy_q <= 1'b0; ifrdy_gap_q = ifrdy_gap_q + 1; end
      end
    end
  end

  // ---------------------------------------------------------------------------
  // State dump (called by the testbench)
  // ---------------------------------------------------------------------------
  task automatic dump_arch(input int fd, input int num_wg_used);
    for (int w = 0; w < NUM_WARPS; w++)
      for (int l = 0; l < WARP_SIZE; l++)
        for (int r = 1; r < 32; r++)
          if (rf[w][l][r] != 32'd0) $fdisplay(fd, "REG %0d %0d %0d %08x", w, l, r, rf[w][l][r]);
    for (int a = 0; a < GMEM_WORDS; a++)
      if (gmem[a] != 32'd0) $fdisplay(fd, "GMEM %04x %08x", a, gmem[a]);
    for (int g = 0; g < num_wg_used; g++)
      for (int a = 0; a < SMEM_WORDS; a++)
        if (smem[g][a] != 32'd0) $fdisplay(fd, "SMEM %0d %03x %08x", g, a, smem[g][a]);
  endtask

  task automatic clear_mem();
    for (int a = 0; a < GMEM_WORDS; a++) gmem[a] = 32'd0;
    for (int g = 0; g < NUM_WARPS; g++)
      for (int a = 0; a < SMEM_WORDS; a++) smem[g][a] = 32'd0;
    for (int a = 0; a < IMEM_WORDS; a++) imem[a] = 32'hFFFF_FFFF;
  endtask

endmodule : sf_simt_dsm
