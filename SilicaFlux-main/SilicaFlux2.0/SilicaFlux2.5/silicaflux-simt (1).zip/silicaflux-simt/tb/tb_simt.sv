// =============================================================================
//  SilicaFlux :: tb_simt.sv   (simulation only)
//  Self-contained testbench: DUT + downstream model + checker. Everything is
//  controlled by plusargs so one Verilator build serves a whole regression.
//
//   +PROG=<hex>      instruction memory image ($readmemh)       (required)
//   +GMEM=<hex>      initial global memory image ($readmemh)
//   +OUT=<file>      state dump (shared format with model/sfref.py)
//   +NUM_WG= +WPW= +TLAST= +ENTRY= +STKNEED=   kernel launch descriptor
//   +REPEAT=n        launch the same kernel n times back to back
//   +SEED= +LAT_IF= +LAT_ALU= +LAT_MEM= +RDY_PCT= +IFRDY_PCT= +SKIP_PCT=   downstream timing
//   +TIMEOUT=cycles  per-launch timeout
//   +NOSTRUCT        disable compliant-code structural assertions (malformed programs)
//   +INJ_CMPL_CYC= +INJ_CMPL_WARP= +INJ_CMPL_SLOT=  inject a spurious completion
//   +INJ_DUP_CYC=    re-send the last completion
//   +INJ_RSP_CYC= +INJ_RSP_WARP=   inject a spurious fetch response
//   +EXPECT_PROTO    spurious traffic is expected (protocol-drop checks inverted)
//   +VERBOSE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_simt;
  import sf_simt_pkg::*;

  parameter int unsigned NUM_WARPS    = 8;
  parameter int unsigned WARP_SIZE    = 32;
  parameter int unsigned PC_W         = 16;
  parameter int unsigned STACK_DEPTH  = 8;
  parameter int unsigned NUM_SLOTS    = 4;
  parameter int unsigned POLICY       = 0;
  parameter int unsigned PERF_W       = 32;

  localparam int unsigned WID_W  = (NUM_WARPS > 1) ? $clog2(NUM_WARPS) : 1;
  localparam int unsigned SLOT_W = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1;
  localparam int unsigned CNT_W  = $clog2(NUM_WARPS + 1);
  localparam int unsigned LANE_W = $clog2(WARP_SIZE + 1);
  localparam int unsigned SP_W   = $clog2(STACK_DEPTH + 1);
  localparam int unsigned RDY_MAXGAP = 4;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---- DUT wiring ------------------------------------------------------------------
  logic                  launch_valid, launch_ready, launch_reject;
  logic [PC_W-1:0]       launch_pc;
  logic [CNT_W-1:0]      launch_num_wg, launch_wpw;
  logic [LANE_W-1:0]     launch_last;
  logic [SP_W-1:0]       launch_stack_need;
  logic [1:0]            launch_reject_cause;
  logic                  busy, kernel_done, kernel_fault;
  logic                  if_req_valid, if_req_ready, if_rsp_valid, if_rsp_err;
  logic [WID_W-1:0]      if_req_warp, if_rsp_warp;
  logic [PC_W-1:0]       if_req_pc, if_rsp_pc;
  logic [31:0]           if_rsp_instr;
  logic                  iss_valid, iss_port;
  logic [1:0]            iss_ready;
  logic [WID_W-1:0]      iss_warp, iss_wg, iss_widx;
  logic [SLOT_W-1:0]     iss_slot;
  logic [PC_W-1:0]       iss_pc;
  logic [WARP_SIZE-1:0]  iss_mask;
  logic [31:0]           iss_instr;
  logic [1:0]            cmpl_valid;
  logic [WID_W-1:0]      cmpl_warp [2];
  logic [SLOT_W-1:0]     cmpl_slot [2];
  logic [WARP_SIZE-1:0]  cmpl_taken [2];
  logic                  cfg_check_struct, perf_clear;
  logic [PERF_W-1:0]     perf [PERF_N];
  logic                  ev_issue, ev_exec, core_run;
  logic [WID_W-1:0]      ev_warp;
  logic [PC_W-1:0]       ev_pc;
  logic [WARP_SIZE-1:0]  ev_mask;
  logic [31:0]           ev_instr;
  logic [NUM_WARPS-1:0]  ev_fill, sched_cand, sched_elig, sched_grant, wg_release;
  sf_wstate_e            warp_state  [NUM_WARPS];
  sf_wclass_e            warp_class  [NUM_WARPS];
  logic [PC_W-1:0]       warp_pc     [NUM_WARPS];
  logic [WARP_SIZE-1:0]  warp_active [NUM_WARPS];
  logic [WARP_SIZE-1:0]  warp_live   [NUM_WARPS];
  logic [SP_W-1:0]       warp_sp     [NUM_WARPS];
  logic [WID_W-1:0]      warp_wg     [NUM_WARPS];
  sf_fault_e             warp_fault  [NUM_WARPS];
  logic                  err_proto, err_assert;

  // ---- downstream config / injection ----------------------------------------------------
  logic [31:0] cfg_seed, cfg_lat_if, cfg_lat_alu, cfg_lat_mem, cfg_rdy_pct, cfg_ifrdy_pct, cfg_skip_pct;
  logic [31:0] k_nwg, k_wpw, k_ntid;
  logic        launch_pulse;
  logic        inj_cmpl, inj_dup, inj_rsp;
  logic [31:0] inj_cmpl_warp, inj_cmpl_slot, inj_rsp_warp;

  sf_simt_ctrl #(
    .NUM_WARPS(NUM_WARPS), .WARP_SIZE(WARP_SIZE), .PC_W(PC_W), .STACK_DEPTH(STACK_DEPTH),
    .NUM_SLOTS(NUM_SLOTS), .POLICY(POLICY), .PERF_W(PERF_W)
  ) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .launch_valid_i(launch_valid), .launch_ready_o(launch_ready), .launch_pc_i(launch_pc),
    .launch_num_wg_i(launch_num_wg), .launch_wpw_i(launch_wpw), .launch_last_threads_i(launch_last),
    .launch_stack_need_i(launch_stack_need), .launch_reject_o(launch_reject),
    .launch_reject_cause_o(launch_reject_cause),
    .busy_o(busy), .kernel_done_o(kernel_done), .kernel_fault_o(kernel_fault),
    .if_req_valid_o(if_req_valid), .if_req_ready_i(if_req_ready), .if_req_warp_o(if_req_warp),
    .if_req_pc_o(if_req_pc), .if_rsp_valid_i(if_rsp_valid), .if_rsp_warp_i(if_rsp_warp),
    .if_rsp_pc_i(if_rsp_pc), .if_rsp_instr_i(if_rsp_instr), .if_rsp_err_i(if_rsp_err),
    .iss_valid_o(iss_valid), .iss_port_o(iss_port), .iss_ready_i(iss_ready), .iss_warp_o(iss_warp),
    .iss_slot_o(iss_slot), .iss_pc_o(iss_pc), .iss_mask_o(iss_mask), .iss_instr_o(iss_instr),
    .iss_wg_o(iss_wg), .iss_widx_o(iss_widx),
    .cmpl_valid_i(cmpl_valid), .cmpl_warp_i(cmpl_warp), .cmpl_slot_i(cmpl_slot), .cmpl_taken_i(cmpl_taken),
    .cfg_check_struct_i(cfg_check_struct), .perf_clear_i(perf_clear), .perf_o(perf),
    .ev_issue_o(ev_issue), .ev_exec_o(ev_exec), .ev_warp_o(ev_warp), .ev_pc_o(ev_pc),
    .ev_mask_o(ev_mask), .ev_instr_o(ev_instr), .ev_fill_o(ev_fill),
    .sched_cand_o(sched_cand), .sched_elig_o(sched_elig), .sched_grant_o(sched_grant),
    .wg_release_o(wg_release), .core_run_o(core_run),
    .warp_state_o(warp_state), .warp_class_o(warp_class), .warp_pc_o(warp_pc),
    .warp_active_o(warp_active), .warp_live_o(warp_live), .warp_sp_o(warp_sp),
    .warp_wg_o(warp_wg), .warp_fault_o(warp_fault),
    .err_proto_o(err_proto), .err_assert_o(err_assert)
  );

  sf_simt_dsm #(
    .NUM_WARPS(NUM_WARPS), .WARP_SIZE(WARP_SIZE), .PC_W(PC_W), .NUM_SLOTS(NUM_SLOTS),
    .RDY_MAXGAP(RDY_MAXGAP)
  ) dsm (
    .clk_i(clk), .rst_ni(rst_n),
    .cfg_seed_i(cfg_seed), .cfg_lat_if_i(cfg_lat_if), .cfg_lat_alu_i(cfg_lat_alu), .cfg_lat_mem_i(cfg_lat_mem),
    .cfg_rdy_pct_i(cfg_rdy_pct), .cfg_ifrdy_pct_i(cfg_ifrdy_pct), .cfg_skip_pct_i(cfg_skip_pct),
    .k_nwg_i(k_nwg), .k_wpw_i(k_wpw), .k_ntid_i(k_ntid), .launch_i(launch_pulse),
    .inj_cmpl_i(inj_cmpl), .inj_cmpl_warp_i(inj_cmpl_warp), .inj_cmpl_slot_i(inj_cmpl_slot),
    .inj_dup_i(inj_dup), .inj_rsp_i(inj_rsp), .inj_rsp_warp_i(inj_rsp_warp),
    .if_req_valid_i(if_req_valid), .if_req_ready_o(if_req_ready), .if_req_warp_i(if_req_warp),
    .if_req_pc_i(if_req_pc), .if_rsp_valid_o(if_rsp_valid), .if_rsp_warp_o(if_rsp_warp),
    .if_rsp_pc_o(if_rsp_pc), .if_rsp_instr_o(if_rsp_instr), .if_rsp_err_o(if_rsp_err),
    .iss_valid_i(iss_valid), .iss_port_i(iss_port), .iss_ready_o(iss_ready), .iss_warp_i(iss_warp),
    .iss_slot_i(iss_slot), .iss_pc_i(iss_pc), .iss_mask_i(iss_mask), .iss_instr_i(iss_instr),
    .iss_wg_i(iss_wg), .iss_widx_i(iss_widx),
    .cmpl_valid_o(cmpl_valid), .cmpl_warp_o(cmpl_warp), .cmpl_slot_o(cmpl_slot), .cmpl_taken_o(cmpl_taken)
  );

  logic        expect_proto;
  int unsigned wd_bound, wait_bound, chk_errs;

  sf_simt_checker #(
    .NUM_WARPS(NUM_WARPS), .WARP_SIZE(WARP_SIZE), .PC_W(PC_W), .NUM_SLOTS(NUM_SLOTS),
    .STACK_DEPTH(STACK_DEPTH), .POLICY(POLICY), .PERF_W(PERF_W)
  ) chk (
    .clk_i(clk), .rst_ni(rst_n),
    .expect_proto_i(expect_proto), .wd_bound_i(wd_bound), .wait_bound_i(wait_bound),
    .busy_i(busy), .core_run_i(core_run), .kernel_done_i(kernel_done),
    .if_req_valid_i(if_req_valid), .if_req_ready_i(if_req_ready), .if_rsp_valid_i(if_rsp_valid),
    .iss_valid_i(iss_valid), .iss_warp_i(iss_warp), .iss_slot_i(iss_slot),
    .cmpl_valid_i(cmpl_valid), .cmpl_warp_i(cmpl_warp), .cmpl_slot_i(cmpl_slot),
    .ev_issue_i(ev_issue), .ev_exec_i(ev_exec), .ev_warp_i(ev_warp), .ev_instr_i(ev_instr),
    .ev_fill_i(ev_fill), .sched_cand_i(sched_cand), .sched_elig_i(sched_elig), .sched_grant_i(sched_grant),
    .wg_release_i(wg_release), .warp_state_i(warp_state), .warp_class_i(warp_class),
    .warp_wg_i(warp_wg), .warp_fault_i(warp_fault), .perf_i(perf), .err_cnt_o(chk_errs)
  );

  // ---- trace capture -----------------------------------------------------------------------
  int          tr_w  [$];
  int          tr_pc [$];
  logic [WARP_SIZE-1:0] tr_m [$];
  always @(posedge clk) begin
    if (rst_n && ev_exec) begin
      tr_w.push_back(int'(ev_warp));
      tr_pc.push_back(int'(ev_pc));
      tr_m.push_back(ev_mask);
    end
  end

  // ---- assertion error latch -----------------------------------------------------------------
  logic assert_seen;
  always @(posedge clk) if (rst_n && err_assert) assert_seen <= 1'b1;

  // The sequencer (initial block and tasks) drives and samples on the FALLING edge: all DUT/model state
  // changes happen on the rising edge, so this is race-free in any simulator and a one-cycle pulse is
  // always observed exactly once.

  // ---- helpers ---------------------------------------------------------------------------------
  function automatic int arg_i(input string name, input int dflt);
    int v;
    string fmt;
    fmt = {name, "=%d"};
    if ($value$plusargs(fmt, v)) return v;
    return dflt;
  endfunction

  string perf_names [PERF_N] = '{"cycles", "issued", "idle", "dep_stall", "mem_stall", "barrier_wait",
                                 "struct_stall", "front_stall", "ready_wait", "branches", "div_branches",
                                 "reconv", "stack_hwm", "faults", "barrier_releases", "retired", "proto_drops"};

  string prog_f, gmem_f, out_f;
  int    num_wg, wpw, tlast, entry, stkneed, repeat_n, timeout_c, verbose;
  int    inj_cmpl_cyc, inj_dup_cyc, inj_rsp_cyc;
  int    cyc, run_cyc, n_launch, n_reject, timed_out, rej_cause_seen;
  int    fd;

  always @(posedge clk) begin
    cyc <= cyc + 1;
    inj_cmpl <= (inj_cmpl_cyc >= 0) && (cyc == inj_cmpl_cyc);
    inj_dup  <= (inj_dup_cyc  >= 0) && (cyc == inj_dup_cyc);
    inj_rsp  <= (inj_rsp_cyc  >= 0) && (cyc == inj_rsp_cyc);
  end

  task automatic do_launch();
    int guard;
    launch_pulse = 1'b1;           // reset downstream register files
    tr_w.delete(); tr_pc.delete(); tr_m.delete();
    @(negedge clk);
    launch_pulse = 1'b0;
    launch_pc         = PC_W'(entry);
    launch_num_wg     = CNT_W'(num_wg);
    launch_wpw        = CNT_W'(wpw);
    launch_last       = LANE_W'(tlast);
    launch_stack_need = SP_W'(stkneed);
    k_nwg             = num_wg;
    k_wpw             = wpw;
    k_ntid            = (wpw - 1) * WARP_SIZE + ((tlast == 0 || tlast == WARP_SIZE) ? WARP_SIZE : tlast);
    launch_valid      = 1'b1;
    guard = 0;
    while (!launch_ready) begin
      @(negedge clk);
      guard++;
      if (guard > 1000) $fatal(1, "[TB] launch_ready never asserted");
    end
    @(negedge clk);                // the accept edge has passed: a reject pulse is visible now (1 cycle wide)
    launch_valid = 1'b0;
    n_launch++;
    if (launch_reject) begin
      n_reject++;
      rej_cause_seen = int'(launch_reject_cause);
    end
  endtask

  task automatic wait_done();
    int guard;
    guard = 0;
    forever begin
      @(negedge clk);
      if (launch_reject) begin
        n_reject++;
        rej_cause_seen = int'(launch_reject_cause);
        return;
      end
      if (kernel_done) return;
      guard++;
      if (guard > timeout_c) begin
        timed_out = 1;
        $display("[TB] TIMEOUT after %0d cycles", guard);
        return;
      end
    end
  endtask

  initial begin
    string s;
    cyc = 0; n_launch = 0; n_reject = 0; timed_out = 0; rej_cause_seen = 0;
    assert_seen = 1'b0;
    launch_valid = 1'b0; launch_pc = '0; launch_num_wg = '0; launch_wpw = '0; launch_last = '0;
    launch_stack_need = '0; launch_pulse = 1'b0; perf_clear = 1'b0;
    inj_cmpl = 1'b0; inj_dup = 1'b0; inj_rsp = 1'b0; inj_cmpl_warp = 0; inj_cmpl_slot = 0; inj_rsp_warp = 0;
    k_nwg = 1; k_wpw = 1; k_ntid = WARP_SIZE;

    num_wg    = arg_i("NUM_WG", 1);
    wpw       = arg_i("WPW", 1);
    tlast     = arg_i("TLAST", 0);
    entry     = arg_i("ENTRY", 0);
    stkneed   = arg_i("STKNEED", 0);
    repeat_n  = arg_i("REPEAT", 1);
    timeout_c = arg_i("TIMEOUT", 200000);
    verbose   = $test$plusargs("VERBOSE");
    cfg_check_struct = !$test$plusargs("NOSTRUCT");
    expect_proto     = $test$plusargs("EXPECT_PROTO");
    cfg_seed      = arg_i("SEED", 1);
    cfg_lat_if    = arg_i("LAT_IF", 1);
    cfg_lat_alu   = arg_i("LAT_ALU", 1);
    cfg_lat_mem   = arg_i("LAT_MEM", 1);
    cfg_rdy_pct   = arg_i("RDY_PCT", 100);
    cfg_ifrdy_pct = arg_i("IFRDY_PCT", 100);
    cfg_skip_pct  = arg_i("SKIP_PCT", 0);
    inj_cmpl_cyc  = arg_i("INJ_CMPL_CYC", -1);
    inj_cmpl_warp = arg_i("INJ_CMPL_WARP", 0);
    inj_cmpl_slot = arg_i("INJ_CMPL_SLOT", 0);
    inj_dup_cyc   = arg_i("INJ_DUP_CYC", -1);
    inj_rsp_cyc   = arg_i("INJ_RSP_CYC", -1);
    inj_rsp_warp  = arg_i("INJ_RSP_WARP", 0);

    // generous bounds derived from the downstream profile (fairness assumptions F1-F4)
    wd_bound   = 200 + 8 * (cfg_lat_if + cfg_lat_alu + cfg_lat_mem + 6 * (RDY_MAXGAP + 2));
    // candidate-wait bound (P4): <= N*(G+1)+G cycles with G = RDY_MAXGAP+1 (specification section 7), plus slack
    wait_bound = (NUM_WARPS + 2) * (RDY_MAXGAP + 2) + 4;

    dsm.clear_mem();
    if (!$value$plusargs("PROG=%s", prog_f)) $fatal(1, "[TB] +PROG=<hex> required");
    $readmemh(prog_f, dsm.imem);
    if ($value$plusargs("GMEM=%s", gmem_f)) $readmemh(gmem_f, dsm.gmem);

    rst_n = 1'b0;
    repeat (6) @(negedge clk);
    rst_n = 1'b1;
    repeat (3) @(negedge clk);

    for (int r = 0; r < repeat_n; r++) begin
      do_launch();
      if (n_reject == 0) wait_done();
      if (n_reject > 0 || timed_out) break;
      repeat (4) @(negedge clk);
    end
    repeat (8) @(negedge clk);

    // ---------------- dump -------------------------------------------------------------------------------------
    if ($value$plusargs("OUT=%s", out_f)) begin
      fd = $fopen(out_f, "w");
      $fdisplay(fd, "STATUS fault=%0d reject=%0d", kernel_fault ? 1 : 0, n_reject > 0 ? rej_cause_seen : 0);
      if (n_reject == 0) begin
        for (int w = 0; w < NUM_WARPS; w++)
          if (w < num_wg * wpw) $fdisplay(fd, "WARP %0d fault=%0d", w, int'(warp_fault[w]));
        dsm.dump_arch(fd, num_wg);
        for (int i = 0; i < tr_w.size(); i++)
          $fdisplay(fd, "TRACE %0d %04x %08x", tr_w[i], tr_pc[i], tr_m[i]);
      end
      for (int i = 0; i < PERF_N; i++) $fdisplay(fd, "PERF %s %0d", perf_names[i], perf[i]);
      $fdisplay(fd, "PERF cycles_total %0d", cyc);
      $fclose(fd);
    end

    $display("[TB] RESULT launches=%0d rejects=%0d timeout=%0d kernel_fault=%0d assert_err=%0d proto_err=%0d chk_errs=%0d cycles=%0d issued=%0d",
             n_launch, n_reject, timed_out, kernel_fault ? 1 : 0, assert_seen ? 1 : 0, err_proto ? 1 : 0, chk_errs,
             perf[PERF_CYCLES], perf[PERF_ISSUED]);
    if (verbose) for (int i = 0; i < PERF_N; i++) $display("[TB] PERF %-18s %0d", perf_names[i], perf[i]);
    if (timed_out || assert_seen || chk_errs != 0) $fatal(1, "[TB] FAILED");
    if (err_proto && !expect_proto) $fatal(1, "[TB] FAILED (protocol error flagged)");
    if (!err_proto && expect_proto) $fatal(1, "[TB] FAILED (expected protocol error flag missing)");
    $finish;
  end

endmodule : tb_simt
