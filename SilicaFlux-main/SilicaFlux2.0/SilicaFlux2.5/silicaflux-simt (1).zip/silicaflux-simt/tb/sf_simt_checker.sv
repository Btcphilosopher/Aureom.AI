// =============================================================================
//  SilicaFlux :: sf_simt_checker.sv   (simulation only, port-based monitor)
//  Independent protocol / liveness / safety checker for sf_simt_ctrl.
//  It re-derives each property from observable events with its own shadow
//  state (it does not reuse the RTL's internal logic), see docs/ARCHITECTURE.md
//  section 13 for the property list (P-numbers below).
//
//   P1  grant is one-hot-or-zero, eligible implies candidate, grant implies eligible
//   P2  scheduling policy model: grant equals the procedural RR / age model
//   P3  AGE policy: bounded overtaking (<= N-1) for eligible warps
//   P4  candidate wait watchdog: bounded wait under F2 (RR: pointer never passes a candidate, N*G+1 cycles)
//   P5  issue only from a RUN context with a filled instruction buffer (no duplicate
//       issue, no phantom issue): fills >= issues, fills - issues <= 1
//   P6  in-flight slots: allocate-once / retire-once, completions only retire valid
//       slots, FREE/DONE contexts own no slots
//   P7  barrier ordering by events: no warp runs past its k-th barrier before the
//       workgroup's k-th release; no release before every live member arrived;
//       a complete barrier releases in the same cycle (no stall)
//   P8  fault containment: no instruction of a faulted workgroup issues afterwards
//   P9  global progress watchdog
//   P10 per-warp class partition (exactly one class, consistent with state)
//   P11 performance counters equal an independent tally (conservation identities)
//   P12 kernel completion leaves no context, slot or scoreboard resources owned
// =============================================================================

`default_nettype none

module sf_simt_checker
  import sf_simt_pkg::*;
#(
  parameter int unsigned NUM_WARPS    = 8,
  parameter int unsigned WARP_SIZE    = 32,
  parameter int unsigned PC_W         = 16,
  parameter int unsigned NUM_SLOTS    = 4,
  parameter int unsigned STACK_DEPTH  = 8,
  parameter int unsigned POLICY       = SF_POLICY_RR,
  parameter int unsigned PERF_W       = 32
) (
  input  logic                         clk_i,
  input  logic                         rst_ni,

  input  logic                         expect_proto_i,   // spurious traffic is being injected on purpose
  input  int unsigned                  wd_bound_i,
  input  int unsigned                  wait_bound_i,

  input  logic                         busy_i,
  input  logic                         core_run_i,
  input  logic                         kernel_done_i,
  input  logic                         if_req_valid_i,
  input  logic                         if_req_ready_i,
  input  logic                         if_rsp_valid_i,
  input  logic                         iss_valid_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] iss_warp_i,
  input  logic [(NUM_SLOTS>1 ? $clog2(NUM_SLOTS) : 1)-1:0] iss_slot_i,
  input  logic [1:0]                   cmpl_valid_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] cmpl_warp_i [2],
  input  logic [(NUM_SLOTS>1 ? $clog2(NUM_SLOTS) : 1)-1:0] cmpl_slot_i [2],

  input  logic                         ev_issue_i,
  input  logic                         ev_exec_i,
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] ev_warp_i,
  input  logic [31:0]                  ev_instr_i,
  input  logic [NUM_WARPS-1:0]         ev_fill_i,
  input  logic [NUM_WARPS-1:0]         sched_cand_i,
  input  logic [NUM_WARPS-1:0]         sched_elig_i,
  input  logic [NUM_WARPS-1:0]         sched_grant_i,
  input  logic [NUM_WARPS-1:0]         wg_release_i,
  input  sf_wstate_e                   warp_state_i [NUM_WARPS],
  input  sf_wclass_e                   warp_class_i [NUM_WARPS],
  input  logic [(NUM_WARPS>1 ? $clog2(NUM_WARPS) : 1)-1:0] warp_wg_i [NUM_WARPS],
  input  sf_fault_e                    warp_fault_i [NUM_WARPS],
  input  logic [PERF_W-1:0]            perf_i [PERF_N],

  output int unsigned                  err_cnt_o
);

  localparam int unsigned N = NUM_WARPS;

  int unsigned errs;
  assign err_cnt_o = errs;

  task automatic err(input string msg);
    errs = errs + 1;
    if (errs <= 25) $display("[SF-CHK] t=%0t ERROR: %s", $time, msg);
  endtask

  // ------------------------------- shadow state ----------------------------------
  logic        busy_d;
  int unsigned fills   [N];
  int unsigned issues  [N];
  logic        slot_sh [N][NUM_SLOTS];
  int unsigned bars    [N];
  int unsigned rel     [N];
  int          rr_ptr;
  int          age_order [$];
  int unsigned ovt     [N];
  int unsigned cwait   [N];
  int unsigned wd;
  int unsigned fault_seen_cycle [N];     // per workgroup: cycles since first fault visible
  logic        fault_seen [N];
  // tallies
  int unsigned t_cycles, t_exec, t_dep, t_mem, t_bar, t_struct, t_front, t_ready, t_retired, t_proto, t_rel;

  function automatic int rr_first(input logic [N-1:0] v, input int ptr);
    for (int k = 0; k < N; k++) begin
      int i;
      i = (ptr + k) % N;
      if (v[i]) return i;
    end
    return -1;
  endfunction

  task automatic reset_shadow();
    for (int w = 0; w < N; w++) begin
      fills[w] = 0; issues[w] = 0; bars[w] = 0; rel[w] = 0; ovt[w] = 0; cwait[w] = 0;
      fault_seen[w] = 1'b0; fault_seen_cycle[w] = 0;
      for (int s = 0; s < NUM_SLOTS; s++) slot_sh[w][s] = 1'b0;
    end
    rr_ptr = 0;
    age_order.delete();
    for (int w = 0; w < N; w++) age_order.push_back(w);
    wd = 0;
    t_cycles = 0; t_exec = 0; t_dep = 0; t_mem = 0; t_bar = 0; t_struct = 0; t_front = 0;
    t_ready = 0; t_retired = 0; t_proto = 0; t_rel = 0;
  endtask

  initial begin
    errs   = 0;
    busy_d = 1'b0;
    reset_shadow();
  end

  // ---------------------------------- per-cycle checks ------------------------------------
  always @(posedge clk_i) begin
    if (!rst_ni) begin
      busy_d <= 1'b0;
    end else begin
      busy_d <= busy_i;
      if (busy_i && !busy_d) reset_shadow();

      // ======================= running-cycle checks ================================
      if (core_run_i) begin
        int          g_idx;
        int          nres;
        int          expct;
        t_cycles = t_cycles + 1;

        // ---- P1 ---------------------------------------------------------------------------
        if (!$onehot0(sched_grant_i))               err("P1 grant not one-hot");
        if ((sched_grant_i & ~sched_elig_i) != '0)  err("P1 grant of non-eligible warp");
        if ((sched_elig_i & ~sched_cand_i) != '0)   err("P1 eligible but not candidate");
        g_idx = -1;
        for (int w = 0; w < N; w++) if (sched_grant_i[w]) g_idx = w;
        if ((g_idx >= 0) != ev_issue_i)             err("P1 ev_issue disagrees with grant");
        if (ev_issue_i && int'(ev_warp_i) != g_idx) err("P1 ev_warp disagrees with grant");

        // ---- P2 policy model -----------------------------------------------------------------
        if (POLICY == SF_POLICY_AGE) begin
          expct = -1;
          foreach (age_order[i]) begin
            if (expct < 0 && sched_elig_i[age_order[i]]) expct = age_order[i];
          end
          if (expct != g_idx) err($sformatf("P2 AGE policy: expected grant %0d, got %0d", expct, g_idx));
          if (g_idx >= 0) begin
            foreach (age_order[i]) if (age_order[i] == g_idx) begin age_order.delete(i); break; end
            age_order.push_back(g_idx);
          end
        end else begin
          // RR model: first eligible warp from the pointer wins; the pointer never moves past a
          // candidate that has not been granted (a blocked candidate before the winner holds it)
          int blk;
          expct = -1; blk = -1;
          for (int k = 0; k < N; k++) begin
            int i;
            i = (rr_ptr + k) % N;
            if (expct < 0) begin
              if (sched_elig_i[i]) expct = i;
              else if (sched_cand_i[i] && blk < 0) blk = i;
            end
          end
          if (expct != g_idx) err($sformatf("P2 RR policy: expected grant %0d, got %0d (ptr=%0d)", expct, g_idx, rr_ptr));
          if (g_idx >= 0) begin
            if (g_idx == expct) rr_ptr = (blk >= 0) ? blk : (g_idx + 1) % N;
            else                rr_ptr = (g_idx + 1) % N;          // resynchronise after a reported mismatch
          end
        end

        // ---- P3 bounded overtaking / P4 candidate wait ---------------------------------------------
        for (int w = 0; w < N; w++) begin
          if (!sched_cand_i[w] || sched_grant_i[w]) begin
            ovt[w] = 0; cwait[w] = 0;
          end else begin
            cwait[w] = cwait[w] + 1;
            if (sched_elig_i[w] && g_idx >= 0) ovt[w] = ovt[w] + 1;
            if (POLICY == SF_POLICY_AGE && ovt[w] > N - 1)
              err($sformatf("P3 warp %0d overtaken %0d times while eligible (AGE bound %0d)", w, ovt[w], N - 1));
            if (cwait[w] > wait_bound_i) err($sformatf("P4 warp %0d candidate for %0d cycles without issue", w, cwait[w]));
          end
        end

        // ---- P5 issue legality -------------------------------------------------------------------------
        for (int w = 0; w < N; w++) begin
          if (ev_fill_i[w]) fills[w] = fills[w] + 1;
        end
        if (ev_issue_i) begin
          int w;
          w = int'(ev_warp_i);
          if (warp_state_i[w] != W_RUN) err($sformatf("P5 issue from warp %0d in state %0d", w, warp_state_i[w]));
          issues[w] = issues[w] + 1;
          if (issues[w] > fills[w])      err($sformatf("P5 duplicate/phantom issue on warp %0d (issues=%0d fills=%0d)", w, issues[w], fills[w]));
          if (fills[w] > issues[w] + 1)  err($sformatf("P5 two unissued fills on warp %0d", w));
        end

        // ---- P6 slots ----------------------------------------------------------------------------------------
        for (int p = 0; p < 2; p++) begin
          if (cmpl_valid_i[p]) begin
            int w, s;
            w = int'(cmpl_warp_i[p]);
            s = int'(cmpl_slot_i[p]);
            if (w < N && s < NUM_SLOTS && slot_sh[w][s]) begin
              slot_sh[w][s] = 1'b0;
              t_retired = t_retired + 1;
            end else begin
              t_proto = t_proto + 1;
              if (!expect_proto_i) err($sformatf("P6 completion of non-valid slot (warp %0d slot %0d)", w, s));
            end
          end
        end
        if (iss_valid_i) begin
          int w, s;
          w = int'(iss_warp_i);
          s = int'(iss_slot_i);
          if (slot_sh[w][s]) err($sformatf("P6 slot %0d of warp %0d allocated twice", s, w));
          slot_sh[w][s] = 1'b1;
          if (warp_state_i[w] != W_RUN) err($sformatf("P6 backend issue from non-RUN warp %0d", w));
        end
        for (int w = 0; w < N; w++) begin
          if (warp_state_i[w] == W_FREE || warp_state_i[w] == W_DONE)
            for (int s = 0; s < NUM_SLOTS; s++)
              if (slot_sh[w][s]) err($sformatf("P6 inactive warp %0d owns slot %0d", w, s));
        end

        // ---- P7 barriers ---------------------------------------------------------------------------------------------
        if (ev_exec_i) begin
          int w;
          w = int'(ev_warp_i);
          if (bars[w] > rel[int'(warp_wg_i[w])])
            err($sformatf("P7 warp %0d executes past barrier %0d before release (releases=%0d)", w, bars[w], rel[int'(warp_wg_i[w])]));
          if (ev_instr_i[31:27] == 5'h04) bars[w] = bars[w] + 1;
        end
        for (int g = 0; g < N; g++) begin
          logic any_bar, all_in, killed;
          any_bar = 1'b0; all_in = 1'b1; killed = 1'b0;
          for (int w = 0; w < N; w++) begin
            if (warp_state_i[w] != W_FREE && int'(warp_wg_i[w]) == g) begin
              if (warp_state_i[w] == W_BAR) any_bar = 1'b1;
              if (warp_state_i[w] != W_BAR && warp_state_i[w] != W_DONE) all_in = 1'b0;
              if (warp_fault_i[w] != F_NONE) killed = 1'b1;
            end
          end
          if (wg_release_i[g]) begin
            for (int w = 0; w < N; w++) begin
              if (warp_state_i[w] != W_FREE && int'(warp_wg_i[w]) == g && warp_state_i[w] != W_DONE) begin
                if (bars[w] < rel[g] + 1)
                  err($sformatf("P7 premature release of WG %0d: warp %0d has executed %0d barriers, needs %0d", g, w, bars[w], rel[g] + 1));
                if (warp_state_i[w] != W_BAR) err($sformatf("P7 release of WG %0d while warp %0d in state %0d", g, w, warp_state_i[w]));
              end
            end
            if (killed) err($sformatf("P7 release of faulted WG %0d", g));
            rel[g] = rel[g] + 1;
            t_rel = t_rel + 1;
          end else if (any_bar && all_in && !killed) begin
            err($sformatf("P7 complete barrier in WG %0d not released", g));
          end
        end

        // ---- P8 fault containment -----------------------------------------------------------------------------------------------
        for (int w = 0; w < N; w++) begin
          if (warp_state_i[w] != W_FREE && warp_fault_i[w] != F_NONE && !fault_seen[int'(warp_wg_i[w])]) begin
            fault_seen[int'(warp_wg_i[w])] = 1'b1;
            fault_seen_cycle[int'(warp_wg_i[w])] = 0;
          end
        end
        for (int g = 0; g < N; g++) if (fault_seen[g]) fault_seen_cycle[g] = fault_seen_cycle[g] + 1;
        if (ev_issue_i && fault_seen[int'(warp_wg_i[int'(ev_warp_i)])] &&
            fault_seen_cycle[int'(warp_wg_i[int'(ev_warp_i)])] > 1)
          err($sformatf("P8 warp %0d of a faulted workgroup issued after the kill took effect", ev_warp_i));

        // ---- P9 progress ----------------------------------------------------------------------------------------------------------------
        begin
          logic live_any;
          live_any = 1'b0;
          for (int w = 0; w < N; w++)
            if (warp_state_i[w] != W_FREE && warp_state_i[w] != W_DONE) live_any = 1'b1;
          if (ev_issue_i || (|cmpl_valid_i) || if_rsp_valid_i || (if_req_valid_i && if_req_ready_i) ||
              (|wg_release_i) || !live_any)
            wd = 0;
          else
            wd = wd + 1;
          if (wd > wd_bound_i) begin
            err($sformatf("P9 no progress for %0d cycles", wd));
            wd = 0;
          end
        end

        // ---- P10 class partition ---------------------------------------------------------------------------------------------------------
        nres = 0;
        for (int w = 0; w < N; w++) begin
          sf_wclass_e c;
          c = warp_class_i[w];
          case (warp_state_i[w])
            W_FREE:  if (c != WC_FREE)  err($sformatf("P10 warp %0d FREE has class %0d", w, c));
            W_DONE:  if (c != WC_DONE)  err($sformatf("P10 warp %0d DONE has class %0d", w, c));
            W_DRAIN: if (c != WC_DRAIN) err($sformatf("P10 warp %0d DRAIN has class %0d", w, c));
            W_BAR:   if (c != WC_BAR)   err($sformatf("P10 warp %0d BAR has class %0d", w, c));
            W_BRW:   if (c != WC_FRONT) err($sformatf("P10 warp %0d BRW has class %0d", w, c));
            default: if (c == WC_FREE || c == WC_DONE || c == WC_BAR) err($sformatf("P10 warp %0d RUN has class %0d", w, c));
          endcase
          if ((c == WC_ISSUED) != sched_grant_i[w]) err($sformatf("P10 warp %0d ISSUED class vs grant", w));
          if (c == WC_READY && !(sched_elig_i[w] && !sched_grant_i[w])) err($sformatf("P10 warp %0d READY but not eligible", w));
          if (warp_state_i[w] != W_FREE) nres = nres + 1;
          case (c)
            WC_DEP:    t_dep    = t_dep + 1;
            WC_MEM:    t_mem    = t_mem + 1;
            WC_BAR:    t_bar    = t_bar + 1;
            WC_STRUCT: t_struct = t_struct + 1;
            WC_FRONT:  t_front  = t_front + 1;
            WC_READY:  t_ready  = t_ready + 1;
            default: ;
          endcase
        end
        if (ev_exec_i) t_exec = t_exec + 1;
      end

      // ======================= kernel completion checks ===================================
      if (kernel_done_i) begin
        // P11 counters
        if (perf_i[PERF_CYCLES]     != t_cycles)           err($sformatf("P11 cycles %0d vs tally %0d", perf_i[PERF_CYCLES], t_cycles));
        if (perf_i[PERF_ISSUED]     != t_exec)             err($sformatf("P11 issued %0d vs tally %0d", perf_i[PERF_ISSUED], t_exec));
        if (perf_i[PERF_ISSUED] + perf_i[PERF_IDLE] != perf_i[PERF_CYCLES]) err("P11 cycles != issued + idle");
        if (perf_i[PERF_DEP_STALL]  != t_dep)              err($sformatf("P11 dep %0d vs tally %0d", perf_i[PERF_DEP_STALL], t_dep));
        if (perf_i[PERF_MEM_STALL]  != t_mem)              err($sformatf("P11 mem %0d vs tally %0d", perf_i[PERF_MEM_STALL], t_mem));
        if (perf_i[PERF_BAR_WAIT]   != t_bar)              err($sformatf("P11 bar %0d vs tally %0d", perf_i[PERF_BAR_WAIT], t_bar));
        if (perf_i[PERF_STRUCT]     != t_struct)           err($sformatf("P11 struct %0d vs tally %0d", perf_i[PERF_STRUCT], t_struct));
        if (perf_i[PERF_FRONT]      != t_front)            err($sformatf("P11 front %0d vs tally %0d", perf_i[PERF_FRONT], t_front));
        if (perf_i[PERF_READY_WAIT] != t_ready)            err($sformatf("P11 ready-wait %0d vs tally %0d", perf_i[PERF_READY_WAIT], t_ready));
        if (perf_i[PERF_RETIRED]    != t_retired)          err($sformatf("P11 retired %0d vs tally %0d", perf_i[PERF_RETIRED], t_retired));
        if (perf_i[PERF_BAR_REL]    != t_rel)              err($sformatf("P11 bar releases %0d vs tally %0d", perf_i[PERF_BAR_REL], t_rel));
        if (!expect_proto_i && perf_i[PERF_PROTO] != 0)    err($sformatf("P11 unexpected protocol drops: %0d", perf_i[PERF_PROTO]));
        // P12 resources
        for (int w = 0; w < N; w++) begin
          if (warp_state_i[w] != W_FREE) err($sformatf("P12 warp %0d not FREE at kernel done", w));
          for (int s = 0; s < NUM_SLOTS; s++)
            if (slot_sh[w][s]) err($sformatf("P12 warp %0d slot %0d still owned at kernel done", w, s));
        end
      end
    end
  end

endmodule : sf_simt_checker
