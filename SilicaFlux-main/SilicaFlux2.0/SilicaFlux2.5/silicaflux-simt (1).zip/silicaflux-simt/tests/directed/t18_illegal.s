; t18_illegal: undefined opcode reached at issue -> FAULT ILLEGAL (the instruction is not executed).
  movi r1, 1
  .word 0xF8000000
  movi r1, 2
  exit
