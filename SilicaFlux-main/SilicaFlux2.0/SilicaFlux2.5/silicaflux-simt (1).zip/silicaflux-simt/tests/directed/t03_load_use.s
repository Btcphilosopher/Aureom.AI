; t03_load_use: the only hazard is a use of a load result: attributed to memory stalls.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  ldg  r1, [r23 + 0]       ; load (zero)
  add  r2, r1, r1          ; RAW on the load
  stg  r2, [r23 + 1]       ; RAW on r2 (ALU) - short
  exit
