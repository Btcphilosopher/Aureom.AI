; t27_barrier_loop: a barrier inside a warp-uniform loop (3 iterations), 4 warps (+WPW=4).
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r6, 3
  movi r7, 0
  ssy  La
Ll:
  add  r1, r7, r20
  sts  r1, [r20 + 0]
  bar
  addi r10, r20, 1
  movi r8, 127
  and  r10, r10, r8
  lds  r9, [r10 + 0]
  bar
  add  r7, r7, r9
  addi r6, r6, -1
  bnz  r6, Ll
  sync
La:
  stg  r7, [r23 + 0]
  exit
