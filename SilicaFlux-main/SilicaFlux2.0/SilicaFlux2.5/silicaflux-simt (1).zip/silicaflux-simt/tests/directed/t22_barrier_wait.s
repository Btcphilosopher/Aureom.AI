; t22_barrier_wait: warp 1 spins 30 iterations before the barrier, warp 0 arrives at once;
; warp 0 must accumulate barrier-wait cycles. Run with +WPW=2.
  s2r  r28, widx
  movi r6, 1
  mul  r6, r6, r28
  movi r8, 30
  mul  r6, r6, r8           ; 0 for warp 0, 30 for warp 1
  addi r6, r6, 1
  ssy  La
Ll:
  addi r6, r6, -1
  bnz  r6, Ll
  sync
La:
  bar
  exit
