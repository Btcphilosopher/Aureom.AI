; t08_exit_div: threads leave through EXIT inside nested divergent regions; the survivors
; reconverge with the exited threads removed from every stack entry.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r8, 3
  and  r10, r21, r8         ; lane & 3
  movi r5, 5
  ssy  Lo_end
  bz   r10, Lo_else         ; (lane&3)==0 -> else; others fall through
    ssy  Li_end
    movi r8, 2
    sltu r14, r10, r8       ; 1 iff lane&3 == 1
    bz   r14, Li_else
      exit                  ; (lane&3)==1 lanes exit
    Li_else:
      addi r5, r5, 20       ; (lane&3) in {2,3}
      sync
    Li_end:
    addi r5, r5, 3
    sync
  Lo_else:
    addi r5, r5, 40         ; (lane&3)==0
    sync
Lo_end:
  addi r5, r5, 1
  stg  r5, [r23 + 0]
  exit
