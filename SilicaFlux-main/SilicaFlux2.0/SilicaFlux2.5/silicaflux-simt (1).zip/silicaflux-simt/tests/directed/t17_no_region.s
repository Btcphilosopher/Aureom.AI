; t17_no_region: a divergent conditional branch with no enclosing SSY region -> FAULT NO_REGION.
  s2r  r21, lane
  movi r8, 1
  and  r10, r21, r8
  bz   r10, Lx
  movi r1, 1
Lx:
  exit
