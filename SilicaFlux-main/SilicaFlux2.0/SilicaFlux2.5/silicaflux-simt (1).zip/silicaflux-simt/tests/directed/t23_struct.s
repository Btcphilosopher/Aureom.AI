; t23_struct.s: 12 independent loads in flight from one warp exhaust the in-flight slots
; (structural stalls) and later uses wait on memory.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  ldg  r1, [r23 + 0]
  ldg  r2, [r23 + 1]
  ldg  r3, [r23 + 2]
  ldg  r4, [r23 + 3]
  ldg  r5, [r23 + 4]
  ldg  r6, [r23 + 5]
  ldg  r7, [r23 + 6]
  ldg  r8, [r23 + 7]
  ldg  r9, [r23 + 8]
  ldg  r10, [r23 + 9]
  ldg  r11, [r23 + 10]
  ldg  r12, [r23 + 11]
  add  r13, r1, r12
  stg  r13, [r23 + 12]
  exit
