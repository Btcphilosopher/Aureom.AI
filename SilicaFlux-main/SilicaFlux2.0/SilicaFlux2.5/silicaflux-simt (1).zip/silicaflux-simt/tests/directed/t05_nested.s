; t05_nested: three nested divergent regions on lane bits 0,1,2 (stack depth reaches 6).
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r8, 1
  and  r10, r21, r8         ; b0
  movi r8, 2
  and  r11, r21, r8         ; b1
  movi r8, 4
  and  r12, r21, r8         ; b2
  movi r5, 0
  ssy  L0end
  bz   r10, L0else
    ssy  L1end
    bz   r11, L1else
      ssy  L2end
      bz   r12, L2else
        addi r5, r5, 1
        sync
      L2else:
        addi r5, r5, 2
        sync
      L2end:
      addi r5, r5, 10
      sync
    L1else:
      addi r5, r5, 100
      sync
    L1end:
    addi r5, r5, 1000
    sync
  L0else:
    addi r5, r5, 10000
    sync
L0end:
  addi r5, r5, 7
  stg  r5, [r23 + 0]
  exit
