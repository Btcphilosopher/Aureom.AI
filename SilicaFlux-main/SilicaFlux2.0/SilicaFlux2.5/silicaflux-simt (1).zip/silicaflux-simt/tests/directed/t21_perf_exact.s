; t21_perf_exact: 10 independent ALU instructions + EXIT: exactly 11 issued, 10 retired.
  movi r1, 1
  movi r2, 2
  movi r3, 3
  movi r4, 4
  movi r5, 5
  movi r6, 6
  movi r7, 7
  movi r8, 8
  movi r9, 9
  movi r10, 10
  exit
