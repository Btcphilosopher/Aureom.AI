; t16_underflow: SYNC with an empty stack -> FAULT STK_UNF.
  movi r1, 1
  sync
  movi r1, 2
  exit
