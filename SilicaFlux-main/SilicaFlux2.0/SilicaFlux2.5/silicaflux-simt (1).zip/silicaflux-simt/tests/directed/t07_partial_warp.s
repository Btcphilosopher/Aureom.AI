; t07_partial_warp: run with +TLAST=13 so the last warp of each workgroup has 13 threads.
; Inactive lanes must never write registers/memory and never contribute to branches.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r2, 1
  and  r3, r20, r2
  ssy  Lend
  bz   r3, Lelse
  addi r5, r20, 1000
  sync
Lelse:
  addi r5, r20, 2000
  sync
Lend:
  stg  r5, [r23 + 0]
  exit
