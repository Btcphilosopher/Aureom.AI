; t20_runaway: no EXIT; execution runs into unprogrammed instruction memory (illegal words).
  movi r1, 1
  movi r2, 2
