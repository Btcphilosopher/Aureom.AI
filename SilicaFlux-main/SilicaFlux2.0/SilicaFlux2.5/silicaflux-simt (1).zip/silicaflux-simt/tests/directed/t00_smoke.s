; t00_smoke: straight-line ALU, JMP/NOP, load/store, EXIT. One warp.
; Every thread stores (tid+100)^2 to its private slot and a reload+1 to the next.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r3, 100
  add  r4, r20, r3
  mul  r5, r4, r4
  stg  r5, [r23 + 0]
  nop
  jmp  Ldone
  movi r5, 999               ; skipped by JMP
Ldone:
  ldg  r6, [r23 + 0]
  addi r6, r6, 1
  stg  r6, [r23 + 1]
  exit
