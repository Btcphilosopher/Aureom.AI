; t02_dep_chain: RAW chain and WAW hazards on ALU results only (no memory):
; dependency stalls must be non-zero and memory stalls must be zero.
  s2r  r1, tid
  addi r2, r1, 3
  addi r3, r2, 5          ; RAW on r2
  add  r4, r3, r2         ; RAW on r3
  mul  r4, r4, r4         ; RAW + WAW on r4
  addi r4, r4, 1          ; RAW + WAW
  xor  r5, r4, r3
  sub  r5, r5, r2         ; WAW + RAW
  shl  r6, r5, r1
  add  r7, r6, r5
  exit
