; t10_barrier_xchg: shared-memory neighbour exchange between warps, bracketed by barriers.
; Run with +WPW=4 (ntid=128). Each thread reads the slot of thread (tid+1)&127.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r8, 7
  mul  r1, r20, r8
  addi r1, r1, 3
  sts  r1, [r20 + 0]
  bar
  addi r10, r20, 1
  movi r8, 127
  and  r10, r10, r8
  lds  r9, [r10 + 0]
  bar
  add  r11, r9, r1
  stg  r11, [r23 + 0]
  exit
