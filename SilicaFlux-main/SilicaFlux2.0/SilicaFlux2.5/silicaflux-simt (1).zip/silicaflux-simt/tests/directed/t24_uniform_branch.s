; t24_uniform_branch: warp-uniform loop branch (never diverges): zero divergent branches,
; stack high-water mark 1 (just the SSY TOKEN).
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r6, 5
  movi r7, 0
  ssy  Lafter
Lloop:
  addi r7, r7, 2
  addi r6, r6, -1
  bnz  r6, Lloop
  sync
Lafter:
  stg  r7, [r23 + 0]
  exit
