; t11_barrier_2wg: two workgroups with very different arrival times (WG0 spins 1 iteration,
; WG1 spins 41). Each workgroup's barrier must release on its own arrivals only.
; Run with +NUM_WG=2 +WPW=2 (ntid=64).
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  s2r  r27, wgid
  movi r8, 40
  mul  r6, r27, r8
  addi r6, r6, 1
  movi r7, 0
  ssy  La
Ll:
  addi r7, r7, 1
  addi r6, r6, -1
  bnz  r6, Ll
  sync
La:
  sts  r7, [r20 + 0]
  bar
  addi r10, r20, 1
  movi r8, 63
  and  r10, r10, r8
  lds  r9, [r10 + 0]
  bar
  add  r11, r9, r20
  stg  r11, [r23 + 0]
  exit
