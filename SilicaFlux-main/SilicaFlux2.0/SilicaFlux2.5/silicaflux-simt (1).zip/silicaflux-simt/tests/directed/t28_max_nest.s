; t28_max_nest: four fully divergent nested regions fill the stack exactly (high-water 8), no fault.
; Requires STACK_DEPTH >= 8.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r8, 1
  and  r10, r21, r8
  movi r8, 2
  and  r11, r21, r8
  movi r8, 4
  and  r12, r21, r8
  movi r8, 8
  and  r13, r21, r8
  movi r5, 0
  ssy  E1
  bz   r10, X1
    ssy  E2
    bz   r11, X2
      ssy  E3
      bz   r12, X3
        ssy  E4
        bz   r13, X4
          addi r5, r5, 1
          sync
        X4:
          addi r5, r5, 2
          sync
        E4:
        addi r5, r5, 4
        sync
      X3:
        addi r5, r5, 8
        sync
      E3:
      addi r5, r5, 16
      sync
    X2:
      addi r5, r5, 32
      sync
    E2:
    addi r5, r5, 64
    sync
X1:
  addi r5, r5, 128
  sync
E1:
  stg  r5, [r23 + 0]
  exit
