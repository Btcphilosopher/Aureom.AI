; t34_barrier_drain_exit: warp 1 stores to shared memory and EXITS without ever reaching the
; barrier; the other warps wait at the barrier. The barrier may open only after warp 1 has fully
; drained (W_DONE) so its stores are performed first; the survivors then read those values.
; Run with +WPW=3.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  s2r  r28, widx
  movi r8, 1
  xor  r9, r28, r8
  sltu r9, r9, r8            ; 1 iff widx == 1
  movi r1, 777
  ssy  Lx
  bz   r9, Lsync             ; warps other than 1 skip the block
  sts  r1, [r21 + 100]       ; lane-based addresses: independent of WARP_SIZE
  sts  r1, [r21 + 101]
  sts  r1, [r21 + 102]
  sts  r1, [r21 + 103]
  exit                       ; warp 1 leaves with stores still in flight
Lsync:
  sync
Lx:
  bar                        ; warps 0 and 2 arrive; warp 1 counts only once it is DONE
  lds  r7, [r21 + 100]       ; smem[100 + lane] written by warp 1
  stg  r7, [r23 + 0]
  exit
