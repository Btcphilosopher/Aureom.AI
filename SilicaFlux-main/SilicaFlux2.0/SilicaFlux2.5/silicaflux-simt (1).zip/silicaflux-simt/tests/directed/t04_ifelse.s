; t04_ifelse: one divergent if/else on lane parity (odd lanes first, then even lanes).
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r2, 1
  and  r3, r21, r2          ; odd lanes != 0
  ssy  Lend
  bz   r3, Lelse            ; taken: even lanes
  movi r5, 111              ; then path (odd lanes)
  sync
Lelse:
  movi r5, 222              ; else path (even lanes)
  sync
Lend:
  stg  r5, [r23 + 0]
  exit
