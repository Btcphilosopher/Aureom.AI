; t26_relaunch: read-modify-write of persistent global memory; run with +REPEAT=3. All warp,
; scoreboard and stack state must be clean at every launch (value ends at 3).
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  ldg  r1, [r23 + 0]
  addi r1, r1, 1
  stg  r1, [r23 + 0]
  exit
