; t15_overflow_div: the stack is exactly full when a divergent branch resolves ->
; FAULT STK_OVF at branch resolution (the branch itself was issued). STACK_DEPTH == 8.
  s2r  r21, lane
  movi r8, 1
  and  r10, r21, r8
  movi r8, 2
  and  r11, r21, r8
  movi r8, 4
  and  r12, r21, r8
  movi r8, 8
  and  r13, r21, r8
  movi r8, 16
  and  r14, r21, r8
  ssy  E1
  bz   r10, X1
    ssy  E2
    bz   r11, X2
      ssy  E3
      bz   r12, X3
        ssy  E4
        bz   r13, X4
          bz   r14, Xz           ; stack full (8), divergent -> overflow at resolve
          nop
        Xz:
          sync
        X4:
          sync
        E4:
        sync
      X3:
        sync
      E3:
      sync
    X2:
      sync
    E2:
    sync
X1:
  sync
E1:
  exit
