; t13_barrier_div_fault: invalid divergent barrier. Only (workgroup 0, warp 0) executes BAR
; with half of its lanes (odd lanes) active -> FAULT DIV_BAR, workgroup 0 is terminated.
; All other warps spin in a 25-iteration loop first, so when the fault hits, the sibling warp of
; workgroup 0 is still running (must be killed mid-loop) and workgroup 1 is unaffected.
; Run with +NUM_WG=2 +WPW=2.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  s2r  r27, wgid
  s2r  r28, widx
  or   r9, r27, r28
  movi r8, 1
  sltu r9, r9, r8            ; 1 iff wgid==0 && widx==0  (the faulty warp)
  sub  r10, r8, r9           ; 1 for every other warp
  movi r6, 24
  mul  r6, r6, r10
  addi r6, r6, 1             ; trip count: 1 (faulty warp) or 25
  movi r7, 0
  ssy  Lspin_end
Lspin:
  addi r7, r7, 1
  addi r6, r6, -1
  bnz  r6, Lspin
  sync
Lspin_end:
  ssy  Lend
  bz   r9, Lsync
  and  r6, r21, r8
  ssy  Lin
  bz   r6, Lis
  bar                        ; executed by odd lanes only: illegal
Lis:
  sync
Lin:
Lsync:
  sync
Lend:
  movi r5, 77
  sts  r5, [r20 + 0]
  bar
  lds  r6, [r20 + 0]
  add  r6, r6, r7
  stg  r6, [r23 + 0]
  exit
