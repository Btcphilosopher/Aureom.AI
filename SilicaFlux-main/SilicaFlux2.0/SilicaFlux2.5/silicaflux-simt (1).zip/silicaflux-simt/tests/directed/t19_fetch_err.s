; t19_fetch_err: jump beyond instruction memory -> fetch error -> FAULT FETCH at issue.
  movi r1, 1
  jmp  5000
  exit
