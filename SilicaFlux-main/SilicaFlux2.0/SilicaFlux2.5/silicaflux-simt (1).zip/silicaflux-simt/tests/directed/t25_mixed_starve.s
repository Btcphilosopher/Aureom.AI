; t25_mixed_starve: odd warps loop on loads (MEM port), even warps loop on ALU work (ALU port).
; Used with slow / memory-heavy downstream profiles to stress fairness (checker P2-P4).
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  s2r  r28, widx
  movi r8, 1
  and  r9, r28, r8
  movi r6, 24
  movi r7, 0
  ssy  Lend
  bz   r9, Lalu
Lmem:
    ldg  r1, [r23 + 0]
    add  r7, r7, r1
    addi r7, r7, 1
    addi r6, r6, -1
    bnz  r6, Lmem
    sync
Lalu:
    addi r7, r7, 3
    mul  r2, r7, r7
    xor  r7, r7, r2
    addi r6, r6, -1
    bnz  r6, Lalu
    sync
Lend:
  stg  r7, [r23 + 0]
  exit
