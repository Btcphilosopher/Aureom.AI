; t01_rr_order: 24 independent ALU instructions per warp (no hazards). With 4 warps
; and an ideal backend the steady-state issue order must be strictly cyclic 0,1,2,3,0,...
  movi r1, 1
  movi r2, 2
  movi r3, 3
  movi r4, 4
  movi r5, 5
  movi r6, 6
  movi r7, 7
  movi r8, 8
  movi r9, 9
  movi r10, 10
  movi r11, 11
  movi r12, 12
  movi r13, 13
  movi r14, 14
  movi r15, 15
  movi r16, 16
  movi r17, 17
  movi r18, 18
  movi r19, 19
  movi r20, 20
  movi r21, 21
  movi r22, 22
  movi r23, 23
  movi r24, 24
  exit
