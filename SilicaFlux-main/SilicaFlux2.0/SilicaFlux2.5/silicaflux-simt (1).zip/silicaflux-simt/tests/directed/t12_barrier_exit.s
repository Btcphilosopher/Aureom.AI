; t12_barrier_exit: barrier participant counting. Warp 1 exits completely before the barrier,
; lanes >= 16 of every other warp exit before it (partial exit). Everyone still alive must
; pass both barriers. Run with +WPW=3.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  s2r  r28, widx
  movi r8, 1
  xor  r9, r28, r8
  sltu r9, r9, r8            ; 1 iff widx == 1
  ssy  Lx
  bz   r9, Lsync
  exit                       ; whole warp 1 leaves
Lsync:
  sync
Lx:
  movi r8, 15
  slt  r9, r8, r21           ; 1 iff lane >= 16
  ssy  Ly
  bz   r9, Lsync2
  exit                       ; upper half of the remaining warps leaves
Lsync2:
  sync
Ly:
  movi r8, 5
  mul  r1, r20, r8
  sts  r1, [r20 + 0]
  bar
  addi r10, r20, 1
  movi r8, 127
  and  r10, r10, r8
  lds  r9, [r10 + 0]
  bar
  add  r11, r9, r1
  stg  r11, [r23 + 0]
  exit
