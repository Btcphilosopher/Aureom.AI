; t06_loop_div: do-while loop with a per-lane trip count ((lane & 3) + 1 = 1..4). The stack
; must stay bounded (high-water mark 2: one TOKEN + one DIV) regardless of the iterations.
  s2r  r22, gtid
  s2r  r21, lane
  s2r  r20, tid
  movi r2, 4
  shl  r23, r22, r2
  movi r3, 4096
  add  r23, r23, r3          ; r23 = private base = 0x1000 + gtid*16
  movi r8, 3
  and  r6, r21, r8
  addi r6, r6, 1            ; trip count 1..4
  movi r7, 0
  ssy  Lafter
Lloop:
  addi r7, r7, 3
  addi r6, r6, -1
  bnz  r6, Lloop
  sync
Lafter:
  stg  r7, [r23 + 0]
  exit
