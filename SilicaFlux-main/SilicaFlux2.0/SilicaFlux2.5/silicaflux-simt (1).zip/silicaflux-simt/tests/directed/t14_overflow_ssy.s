; t14_overflow_ssy: four fully divergent nested regions fill the 8-entry stack
; (TOKEN+DIV per level); the fifth SSY overflows -> FAULT STK_OVF at the SSY (not executed).
; Requires STACK_DEPTH == 8.
  s2r  r21, lane
  movi r8, 1
  and  r10, r21, r8
  movi r8, 2
  and  r11, r21, r8
  movi r8, 4
  and  r12, r21, r8
  movi r8, 8
  and  r13, r21, r8
  ssy  E1
  bz   r10, X1
    ssy  E2
    bz   r11, X2
      ssy  E3
      bz   r12, X3
        ssy  E4
        bz   r13, X4
          ssy  E5               ; sp == 8 here: overflow
          nop
          sync
        E5:
        X4:
          sync
        E4:
        sync
      X3:
        sync
      E3:
      sync
    X2:
      sync
    E2:
    sync
X1:
  sync
E1:
  exit
