#!/usr/bin/env python3
"""Directed test suite for the SilicaFlux warp scheduler / SIMT control unit.

Every test is a hand-written SFT-1 program (tests/directed/*.s). Each one is run on the
RTL under several hardware configurations and downstream timing profiles, then

  1. the full architectural state, per-warp issue trace and counters are compared with the
     lock-step SIMT reference model (and architectural state with the per-thread MIMD model
     for fault-free tests),
  2. test specific expectations are checked (stack high-water mark, fault codes, stall
     counters, barrier release counts, issue order, ...).

The testbench itself additionally runs the always-on checker (sf_simt_checker) and the
inline RTL assertions on every run; any failure there fails the test.
"""
import argparse
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from typing import Callable, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.join(ROOT, "model"))
import sfrun            # noqa: E402
import sfref            # noqa: E402
from sfisa import assemble, write_hex   # noqa: E402
from sfgen import gen_table             # noqa: E402

F = sfref   # fault code names live here
PRIV = 0x1000


@dataclass
class Ctx:
    hw: sfrun.HwCfg
    prof: str
    res: sfrun.RtlResult
    st: sfref.State
    kcfg: sfref.Cfg

    def gmem(self):
        return {int(l.split()[1], 16): int(l.split()[2], 16) for l in self.res.arch if l.startswith("GMEM")}

    def reg(self, w, lane, r):
        for l in self.res.arch:
            t = l.split()
            if t[0] == "REG" and int(t[1]) == w and int(t[2]) == lane and int(t[3]) == r:
                return int(t[4], 16)
        return 0

    def p(self, k):
        return self.res.perf[k]


@dataclass
class T:
    name: str
    file: str = None
    kcfg: Callable = lambda hw: {}                 # launch shape overrides
    profiles: tuple = ("ideal", "mid", "slow")
    configs: Callable = lambda hw: True            # which hardware configs apply
    check: Optional[Callable] = None
    mimd: bool = True                              # also compare arch state with the MIMD model
    perf: bool = True                              # compare counters with the SIMT model
    trace: bool = True
    arch_filter: Optional[Callable] = None
    extra: Callable = lambda hw: ()                # extra plusargs
    repeat: int = 1
    nostruct: bool = False
    gmem_table: bool = False
    determinism: bool = False                      # run twice, outputs must be identical
    expect_reject: int = 0


def need(cond):
    if not cond:
        raise AssertionError("expectation failed")


def expect(cond, msg):
    if not cond:
        raise AssertionError(msg)


# ---------------------------------------------------------------------------------------------
# test specific checks
# ---------------------------------------------------------------------------------------------
def chk_smoke(c):
    g = c.gmem()
    k = c.kcfg
    for wg in range(k.num_wg):
        for wi in range(k.wpw):
            for lane in range(k.lanes(wi)):
                tid = wi * k.warp_size + lane
                gtid = wg * k.wpw * k.warp_size + tid
                v = ((tid + 100) ** 2) & 0xFFFFFFFF
                expect(g.get(PRIV + gtid * 16) == v, f"smoke value gtid {gtid}")
                expect(g.get(PRIV + gtid * 16 + 1) == (v + 1) & 0xFFFFFFFF, f"smoke reload gtid {gtid}")
    expect(c.p("issued") == c.st.n_instr, "issued count")


def chk_rr_order(c):
    o = c.res.order
    expect(len(o) > 40, "enough issues")
    mid = o[10:-10]
    bad = [i for i in range(len(mid) - 1) if mid[i + 1] != (mid[i] + 1) % 4]
    expect(not bad, f"steady-state order is not cyclic 0,1,2,3 (first break at issue #{bad[:1]})")
    expect(c.p("issued") == 4 * 25, "issued = 4 warps x 25")


def chk_dep(c):
    if c.prof != "ideal":      # with a 1-cycle backend, fetch latency (CPI 3) hides the 2-cycle issue-to-use gap
        expect(c.p("dep_stall") > 0, "dependency stalls expected")
    expect(c.p("mem_stall") == 0, f"no memory stalls expected, got {c.p('mem_stall')}")
    expect(c.p("issued") == 11, "issued == 11")


def chk_load_use(c):
    if c.prof != "ideal":
        expect(c.p("mem_stall") > 0, "load-use must be attributed to memory stalls")


def chk_ifelse(c):
    g = c.gmem()
    k = c.kcfg
    odd = sum(1 << l for l in range(k.warp_size) if l & 1)
    even = sum(1 << l for l in range(k.warp_size) if not l & 1)
    masks = {m for pc, m in c.res.trace[0]}
    expect(odd in masks and even in masks, "both divergent paths must issue with complementary masks")
    for lane in range(k.warp_size):
        expect(g.get(PRIV + lane * 16) == (111 if lane & 1 else 222), f"lane {lane} value")
    expect(c.p("div_branches") == 1 and c.p("stack_hwm") == 2, "one divergent branch, hwm 2")


def chk_nested(c):
    expect(c.p("stack_hwm") == 6, f"stack hwm {c.p('stack_hwm')} != 6")
    # only the nested "then" path diverges again: levels 0, 1 and 2 -> 3 divergent branches
    expect(c.p("div_branches") == 3, f"divergent branches {c.p('div_branches')} != 3")


def chk_loop_div(c):
    expect(c.p("stack_hwm") == 2, f"loop stack hwm {c.p('stack_hwm')} != 2 (bounded, independent of trip count)")
    g = c.gmem()
    for lane in range(c.kcfg.warp_size):
        expect(g.get(PRIV + lane * 16) == 3 * ((lane & 3) + 1), f"lane {lane} trip result")


def chk_partial(c):
    k = c.kcfg
    last = k.last_threads()
    lastmask = (1 << last) - 1
    for wg in range(k.num_wg):
        w = wg * k.wpw + k.wpw - 1
        for pc, m in c.res.trace[w]:
            expect(m & ~lastmask == 0, f"warp {w} issued with inactive lanes in mask {m:x}")
    for l in c.res.arch:
        t = l.split()
        if t[0] == "REG":
            w, lane = int(t[1]), int(t[2])
            wi = w % k.wpw
            expect(lane < k.lanes(wi), f"register written by non-existent lane {lane} of warp {w}")


def chk_exit_div(c):
    expect(c.p("stack_hwm") == 4, f"hwm {c.p('stack_hwm')} != 4")
    g = c.gmem()
    for lane in range(c.kcfg.warp_size):
        b = lane & 3
        if b == 1:
            expect(g.get(PRIV + lane * 16) is None, f"lane {lane} exited and must not store")
        else:
            exp = {0: 5 + 40 + 1, 2: 5 + 20 + 3 + 1, 3: 5 + 20 + 3 + 1}[b]
            expect(g.get(PRIV + lane * 16) == exp, f"lane {lane}: {g.get(PRIV + lane * 16)} != {exp}")


def chk_cascade(c):
    g = c.gmem()
    for lane in range(c.kcfg.warp_size):
        if lane & 3 == 0:
            expect(g.get(PRIV + lane * 16) == 46, f"lane {lane} survivor value")
        else:
            expect(g.get(PRIV + lane * 16) is None, f"lane {lane} exited")
    expect(c.p("stack_hwm") == 4, "hwm 4")


def chk_bar_xchg(c):
    expect(c.p("barrier_releases") == 2, f"releases {c.p('barrier_releases')} != 2")
    k = c.kcfg
    g = c.gmem()
    for tid in range(k.ntid()):
        nb = (tid + 1) & 127
        nbv = (nb * 7 + 3) & 0xFFFFFFFF if nb < k.ntid() else 0
        exp = (nbv + tid * 7 + 3) & 0xFFFFFFFF
        expect(g.get(PRIV + tid * 16) == exp, f"tid {tid}: {g.get(PRIV + tid * 16)} != {exp}")


def chk_bar_2wg(c):
    expect(c.p("barrier_releases") == 4, f"releases {c.p('barrier_releases')} != 4 (2 WGs x 2)")


def chk_bar_exit(c):
    expect(c.p("barrier_releases") == 2, f"releases {c.p('barrier_releases')} != 2")
    expect(all(f == 0 for f in c.res.warp_fault.values()), "no faults")


def chk_drain_exit(c):
    expect(c.p("barrier_releases") == 1, f"releases {c.p('barrier_releases')} != 1")
    g = c.gmem()
    k = c.kcfg
    for wi in (0, 2):
        for lane in range(k.lanes(wi)):
            gt = wi * k.warp_size + lane
            expect(g.get(PRIV + gt * 16) == 777,
                   f"warp {wi} lane {lane}: exited warp's stores not visible after the barrier ({g.get(PRIV + gt * 16)})")
    expect(all(f == 0 for f in c.res.warp_fault.values()), "no faults")


def chk_bar_fault(c):
    wf = c.res.warp_fault
    expect(wf[0] == F.F_DIV_BAR, f"warp 0 fault {wf[0]} != DIV_BAR")
    expect(wf[1] in (F.F_NONE, F.F_WG_KILLED), f"warp 1 fault {wf[1]}")
    expect(wf[2] == F.F_NONE and wf[3] == F.F_NONE, "workgroup 1 must be unaffected")
    expect(c.res.status["fault"] == 1, "kernel fault flag")
    expect(c.p("faults") == 1, f"fault events {c.p('faults')} != 1")


def bar_fault_filter(l):
    t = l.split()
    if t[0] == "REG":
        return int(t[1]) >= 2           # warps 2,3 = workgroup 1
    if t[0] == "SMEM":
        return int(t[1]) == 1
    if t[0] == "GMEM":
        return int(t[1], 16) >= PRIV + 64 * 16     # private windows of workgroup 1
    return True


def fault_check(code, hwm=None):
    def f(c):
        expect(c.res.warp_fault[0] == code, f"warp 0 fault {c.res.warp_fault[0]} != {sfref.FAULT_NAMES[code]}")
        expect(c.res.status["fault"] == 1, "kernel fault flag")
        expect(c.p("faults") == 1, f"fault events {c.p('faults')}")
    return f


def chk_perf_exact(c):
    expect(c.p("issued") == 11, f"issued {c.p('issued')} != 11")
    expect(c.p("retired") == 10, f"retired {c.p('retired')} != 10")
    expect(c.p("branches") == 0 and c.p("barrier_wait") == 0 and c.p("dep_stall") == 0 and c.p("mem_stall") == 0,
           "no stall classes expected for independent ALU code")
    expect(c.p("cycles") == c.p("issued") + c.p("idle"), "cycles == issued + idle")


def chk_bar_wait(c):
    expect(c.p("barrier_wait") >= 20, f"barrier wait {c.p('barrier_wait')} too small")
    expect(c.p("barrier_releases") == 1, "one release")


def chk_struct(c):
    if c.prof != "ideal":
        expect(c.p("struct_stall") > 0, "structural stalls expected (in-flight slots exhausted)")


def chk_uniform(c):
    expect(c.p("div_branches") == 0, "no divergence")
    expect(c.p("stack_hwm") == 1, f"hwm {c.p('stack_hwm')} != 1")


def chk_mixed(c):
    if c.prof != "ideal":
        expect(c.p("ready_wait") > 0, "contention expected")


def chk_relaunch(c):
    g = c.gmem()
    k = c.kcfg
    for gt in range(k.num_wg * k.wpw * k.warp_size):
        wg, tid = divmod(gt, k.wpw * k.warp_size)
        if tid < k.ntid():
            expect(g.get(PRIV + gt * 16) == 3, f"gtid {gt} counter {g.get(PRIV + gt * 16)} != 3")


def chk_max_nest(c):
    expect(c.p("stack_hwm") == 8, f"hwm {c.p('stack_hwm')} != 8")
    expect(c.res.status["fault"] == 0, "no fault")
    expect(c.p("div_branches") == 4, f"divergent branches {c.p('div_branches')} != 4")


def chk_inject(c):
    expect(c.p("proto_drops") >= 1, "spurious traffic must be dropped and counted")
    expect(c.res.result["proto_err"] == 1, "protocol error flag")
    expect(c.res.status["fault"] == 0, "dropped traffic must not fault the kernel")


# ---------------------------------------------------------------------------------------------
D8 = lambda hw: hw.stack_depth == 8 and hw.warp_size == 32
W3 = lambda hw: hw.num_warps >= 3
W4 = lambda hw: hw.num_warps >= 4


def kc(**kw):
    return lambda hw: kw


def inj(**kw):
    return kw


TESTS = [
    T("t00_smoke", "t00_smoke.s", kc(num_wg=2, wpw=2), ("ideal", "mid", "slow", "memhv"), check=chk_smoke),
    T("t01_rr_order", "t01_rr_order.s", kc(num_wg=1, wpw=4), ("ideal",), W4, chk_rr_order, determinism=True),
    T("t02_dep_chain", "t02_dep_chain.s", kc(num_wg=1, wpw=1), ("ideal", "mid", "slow"), check=chk_dep),
    T("t03_load_use", "t03_load_use.s", kc(num_wg=1, wpw=1), ("ideal", "slow", "memhv"), check=chk_load_use),
    T("t04_ifelse", "t04_ifelse.s", kc(num_wg=1, wpw=1), check=chk_ifelse),
    T("t05_nested", "t05_nested.s", kc(num_wg=1, wpw=1), configs=lambda hw: hw.stack_depth >= 6 and hw.warp_size >= 8,
      check=chk_nested),
    T("t06_loop_div", "t06_loop_div.s", kc(num_wg=1, wpw=1), check=chk_loop_div),
    T("t07_partial_warp", "t07_partial_warp.s",
      lambda hw: dict(num_wg=2, wpw=min(3, hw.num_warps // 2), tlast=max(1, min(13, hw.warp_size - 3))),
      check=chk_partial),
    T("t08_exit_div", "t08_exit_div.s", kc(num_wg=1, wpw=2), check=chk_exit_div),
    T("t09_exit_cascade", "t09_exit_cascade.s", kc(num_wg=1, wpw=1), check=chk_cascade),
    T("t10_barrier_xchg", "t10_barrier_xchg.s", kc(num_wg=1, wpw=4), ("ideal", "mid", "slow", "memhv"), W4,
      chk_bar_xchg),
    T("t11_barrier_2wg", "t11_barrier_2wg.s", kc(num_wg=2, wpw=2), ("ideal", "mid", "slow"), W4, chk_bar_2wg),
    T("t12_barrier_exit", "t12_barrier_exit.s", kc(num_wg=1, wpw=3), ("ideal", "mid", "slow"), W3, chk_bar_exit),
    T("t13_barrier_div_fault", "t13_barrier_div_fault.s", kc(num_wg=2, wpw=2), ("ideal", "mid"), W4,
      chk_bar_fault, mimd=False, perf=False, trace=False, arch_filter=bar_fault_filter, nostruct=True),
    T("t34_barrier_drain_exit", "t34_barrier_drain_exit.s", kc(num_wg=1, wpw=3), ("ideal", "mid", "slow", "memhv"), W3,
      chk_drain_exit),
    T("t14_overflow_ssy", "t14_overflow_ssy.s", kc(num_wg=1, wpw=1), ("ideal", "mid"), D8,
      fault_check(F.F_STK_OVF), mimd=False, perf=False),
    T("t15_overflow_div", "t15_overflow_div.s", kc(num_wg=1, wpw=1), ("ideal", "mid"), D8,
      fault_check(F.F_STK_OVF), mimd=False, perf=False),
    T("t16_underflow", "t16_underflow.s", kc(num_wg=1, wpw=1), ("ideal", "mid"),
      check=fault_check(F.F_STK_UNF), mimd=False, perf=False, nostruct=True),
    T("t17_no_region", "t17_no_region.s", kc(num_wg=1, wpw=1), ("ideal", "mid"),
      check=fault_check(F.F_NO_REGION), mimd=False, perf=False, nostruct=True),
    T("t18_illegal", "t18_illegal.s", kc(num_wg=1, wpw=1), ("ideal", "mid"),
      check=fault_check(F.F_ILLEGAL), mimd=False, perf=False),
    T("t19_fetch_err", "t19_fetch_err.s", kc(num_wg=1, wpw=1), ("ideal", "mid"),
      check=fault_check(F.F_FETCH), mimd=False, perf=False),
    T("t20_runaway", "t20_runaway.s", kc(num_wg=1, wpw=1), ("ideal", "mid"),
      check=fault_check(F.F_ILLEGAL), mimd=False, perf=False),
    T("t21_perf_exact", "t21_perf_exact.s", kc(num_wg=1, wpw=1), ("ideal", "mid", "slow"), check=chk_perf_exact),
    T("t22_barrier_wait", "t22_barrier_wait.s", kc(num_wg=1, wpw=2), ("ideal", "mid"), check=chk_bar_wait),
    T("t23_struct", "t23_struct.s", kc(num_wg=1, wpw=1), ("ideal", "slow", "memhv"), check=chk_struct),
    T("t24_uniform_branch", "t24_uniform_branch.s", kc(num_wg=1, wpw=1), check=chk_uniform),
    T("t25_mixed_starve", "t25_mixed_starve.s", lambda hw: dict(num_wg=1, wpw=min(8, hw.num_warps)),
      ("ideal", "mid", "slow", "memhv", "starve"), check=chk_mixed, determinism=True),
    T("t26_relaunch", "t26_relaunch.s", kc(num_wg=2, wpw=2), ("ideal", "mid"), W4, chk_relaunch, repeat=3,
      trace=False, perf=True),
    T("t27_barrier_loop", "t27_barrier_loop.s", kc(num_wg=1, wpw=4), ("ideal", "mid", "slow"), W4,
      lambda c: expect(c.p("barrier_releases") == 6, "6 releases")),
    T("t28_max_nest", "t28_max_nest.s", kc(num_wg=1, wpw=1), ("ideal", "mid"), D8, chk_max_nest),
    T("t29_reject_dims", "t00_smoke.s", lambda hw: dict(num_wg=1, wpw=hw.num_warps + 1), ("ideal",),
      mimd=False, expect_reject=sfref.LREJ_DIMS),
    T("t29_reject_last", "t00_smoke.s", lambda hw: dict(num_wg=1, wpw=1, tlast=hw.warp_size + 1), ("ideal",),
      mimd=False, expect_reject=sfref.LREJ_LAST),
    T("t29_reject_stack", "t00_smoke.s", lambda hw: dict(num_wg=1, wpw=1, stack_need=hw.stack_depth + 1),
      ("ideal",), mimd=False, expect_reject=sfref.LREJ_STACK),
    T("t30_stack_need_ok", "t05_nested.s", lambda hw: dict(num_wg=1, wpw=1, stack_need=6), ("ideal",),
      configs=lambda hw: hw.stack_depth >= 6, check=chk_nested),
    T("t31_inject_cmpl_free", "t00_smoke.s", kc(num_wg=1, wpw=2), ("ideal", "mid"), check=chk_inject,
      extra=lambda hw: (f"+INJ_CMPL_CYC=30", f"+INJ_CMPL_WARP={hw.num_warps - 1}", "+INJ_CMPL_SLOT=1",
                        "+EXPECT_PROTO")),
    T("t32_inject_dup", "t00_smoke.s", kc(num_wg=1, wpw=2), ("ideal", "mid"), check=chk_inject,
      extra=lambda hw: ("+INJ_DUP_CYC=40", "+EXPECT_PROTO")),
    T("t33_inject_rsp", "t00_smoke.s", kc(num_wg=1, wpw=2), ("ideal", "mid"), check=chk_inject,
      extra=lambda hw: (f"+INJ_RSP_CYC=20", f"+INJ_RSP_WARP={hw.num_warps - 1}", "+EXPECT_PROTO")),
]
TESTS = [t for t in TESTS if t is not None]


# ---------------------------------------------------------------------------------------------
def run_one(job):
    try:
        return _run_one(job)
    except Exception as e:                      # report instead of killing the worker pool
        import traceback
        return (job[0], job[1], job[2], ["harness exception: " + traceback.format_exc(limit=3)[-600:]])


def _run_one(job):
    tname, cfgname, prof, outroot = job
    t = next(x for x in TESTS if x.name == tname)
    hw = sfrun.CONFIGS[cfgname]
    exe = sfrun.build(hw)
    shape = dict(num_wg=1, wpw=1, tlast=0, entry=0, stack_need=0)
    shape.update(t.kcfg(hw))
    kcfg = sfref.Cfg(num_warps=hw.num_warps, warp_size=hw.warp_size, stack_depth=hw.stack_depth, **shape)
    d = os.path.join(outroot, f"{cfgname}_{prof}")
    os.makedirs(d, exist_ok=True)
    words, _, _ = assemble(open(os.path.join(HERE, "directed", t.file)).read())
    hexf = os.path.join(d, t.name + ".hex")
    write_hex(words, hexf)
    errs = []
    table = [0] * 0
    # reference runs
    mem = None
    st = None
    try:
        for r in range(t.repeat):
            if mem is None:
                st = sfref.run_simt(words, kcfg, table)
            else:
                st = sfref.run_simt(words, kcfg, mem=mem)
            mem = st.mem
    except sfref.RefError as e:
        return (tname, cfgname, prof, [f"reference error: {e}"])
    st_mimd = None
    if t.mimd and not st.kernel_fault and not st.reject:
        try:
            mm = None
            for r in range(t.repeat):
                st_mimd = sfref.run_mimd(words, kcfg, table) if mm is None else sfref.run_mimd(words, kcfg, mem=mm)
                mm = st_mimd.mem
        except sfref.RefError as e:
            errs.append(f"MIMD reference error: {e}")
    extra = list(t.extra(hw))
    if t.repeat > 1:
        extra.append(f"+REPEAT={t.repeat}")
    if t.nostruct:
        extra.append("+NOSTRUCT")
    res = sfrun.run_rtl(exe, hexf, kcfg, profile=prof, seed=7, outdir=d, tag=t.name, extra=extra)
    if t.expect_reject:
        if res.status.get("reject") != t.expect_reject or st.reject != t.expect_reject:
            errs.append(f"expected launch reject {t.expect_reject}, rtl={res.status.get('reject')} ref={st.reject}")
        if res.result.get("timeout"):
            errs.append("timeout")
        return (tname, cfgname, prof, errs)
    if not sfrun.tb_ok(res):
        errs.append("TB failure: " + " | ".join(l for l in res.stdout.splitlines()
                                                if any(k in l for k in ("ERROR", "ASSERT", "FAIL", "RESULT", "TIMEOUT")))[:700])
        return (tname, cfgname, prof, errs)
    errs += sfrun.compare(res, st, check_trace=t.trace and t.repeat == 1, check_perf=t.perf,
                          arch_filter=t.arch_filter)
    if st_mimd is not None:
        errs += ["vs MIMD: " + x for x in sfrun.compare(res, st_mimd, check_trace=False, check_perf=False)]
    if t.check and not errs:
        try:
            t.check(Ctx(hw, prof, res, st, kcfg))
        except AssertionError as e:
            errs.append(f"expectation: {e}")
    if t.determinism and not errs:
        res2 = sfrun.run_rtl(exe, hexf, kcfg, profile=prof, seed=7, outdir=d, tag=t.name + "_b", extra=extra)
        if res2.lines != res.lines:
            errs.append("non-deterministic: two identical runs produced different output")
    return (tname, cfgname, prof, errs)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", action="append", choices=sfrun.CONFIGS)
    ap.add_argument("--test", action="append")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--out", default=os.path.join(ROOT, "out", "directed"))
    a = ap.parse_args()
    cfgs = a.config or ["rr8", "age8"]
    for c in cfgs:
        sfrun.build(sfrun.CONFIGS[c])
    jobs = []
    for t in TESTS:
        if a.test and t.name not in a.test:
            continue
        for c in cfgs:
            if not t.configs(sfrun.CONFIGS[c]):
                continue
            for p in t.profiles:
                jobs.append((t.name, c, p, a.out))
    t0 = time.time()
    bad = 0
    with ProcessPoolExecutor(max_workers=a.jobs) as ex:
        for name, cfg, prof, errs in ex.map(run_one, jobs):
            if errs:
                bad += 1
                print(f"FAIL {name} [{cfg}/{prof}]")
                for e in errs[:6]:
                    print("    ", e)
    print(f"directed: {len(jobs)} runs ({len(cfgs)} configs), {bad} failed, {time.time() - t0:.1f}s")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
