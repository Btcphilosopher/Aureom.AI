#!/usr/bin/env python3
"""Checks that the Python ISA/fault/counter tables (model/sfisa.py, model/sfref.py,
scripts/sfrun.py/tb names) and the SystemVerilog package (rtl/sf_simt_pkg.sv) agree."""
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "model"))
import sfisa    # noqa: E402
import sfref    # noqa: E402

pkg = open(os.path.join(ROOT, "rtl", "sf_simt_pkg.sv")).read()
tb = open(os.path.join(ROOT, "tb", "tb_simt.sv")).read()
bad = []

# opcodes: OP_NAME = 5'hNN
sv_ops = {m.group(1).lower(): int(m.group(2), 16) for m in re.finditer(r"OP_(\w+)\s*=\s*5'h([0-9A-Fa-f]+)", pkg)}
if sv_ops != sfisa.OPCODES:
    for k in sorted(set(sv_ops) | set(sfisa.OPCODES)):
        if sv_ops.get(k) != sfisa.OPCODES.get(k):
            bad.append(f"opcode {k}: sv={sv_ops.get(k)} py={sfisa.OPCODES.get(k)}")

# fault codes: F_NAME = 4'dN
sv_f = {m.group(1): int(m.group(2)) for m in re.finditer(r"\bF_(\w+)\s*=\s*4'd(\d+)", pkg)}
py_f = {n: i for i, n in enumerate(sfref.FAULT_NAMES)}
py_f = {("NONE" if n == "NONE" else n): i for n, i in py_f.items()}
if sv_f != py_f:
    bad.append(f"fault codes differ: sv={sv_f} py={py_f}")

# launch reject causes
sv_r = {m.group(1): int(m.group(2)) for m in re.finditer(r"LREJ_(\w+)\s*=\s*2'd(\d+)", pkg)}
py_r = {"NONE": sfref.LREJ_NONE, "DIMS": sfref.LREJ_DIMS, "STACK": sfref.LREJ_STACK, "LAST": sfref.LREJ_LAST}
if sv_r != py_r:
    bad.append(f"launch reject codes differ: sv={sv_r} py={py_r}")

# performance counter indices vs the names printed by the testbench
sv_p = sorted((int(m.group(2)), m.group(1)) for m in re.finditer(r"PERF_(\w+)\s*=\s*(\d+);", pkg) if m.group(1) != "N")
names = re.search(r'perf_names \[PERF_N\] = \'\{(.*?)\}', tb, re.S).group(1)
tb_names = re.findall(r'"([^"]+)"', names)
if len(tb_names) != len(sv_p):
    bad.append(f"perf counter count: sv={len(sv_p)} tb names={len(tb_names)}")

# special-register ids used by the backend model
dsm = open(os.path.join(ROOT, "tb", "sf_simt_dsm.sv")).read()
for name, sid in sfisa.SREGS.items():
    if not re.search(rf"17'd{sid}:", dsm):
        bad.append(f"special register {name} (id {sid}) missing in sf_simt_dsm.sv")

if bad:
    print("ISA/package sync FAILED")
    for b in bad:
        print("  ", b)
    sys.exit(1)
print(f"ISA/package sync OK: {len(sv_ops)} opcodes, {len(sv_f)} fault codes, {len(sv_p)} counters")
