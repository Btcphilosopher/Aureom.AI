# BURSTS - the documented subset (`sf_sdf_burst_seq`)

Labels: RTL-SIMULATION verified (`tb_sdf_burst` unit suite, 10 configurations; `tb_sdf` end-to-end through the real NoC, bridge and banks; mutation-tested).

## 1. Where bursts live

SFB3 has **no burst fields**; "a burst is a sequence of single-beat transactions" (SFB2 R10; spine PROTOCOL.md sec. 5). Adding `len`/`burst` signals to the fabric port would be a second, incompatible DataFabric protocol, so the
bridge's fabric port stays single-beat and sustains one beat per cycle per target port when beats map to free banks (reports/PERFORMANCE.md). The burst subset below is a **client-side sequencer**: a DMA, tile host or ControlCore
instantiates `sf_sdf_burst_seq`, issues one burst command, and gets back legal SFB3 beats and ONE completion. The sequencer is an SFB3 master; it can sit on a NoC master port or drive the bridge directly.

## 2. The subset

| item | rule |
|---|---|
| burst type | INCR only (no WRAP, no FIXED) |
| start address / length | any byte address, 1 .. `MAX_BYTES` bytes (default 4096) |
| beats | `nbeats = floor((addr + len - 1) / (DW/8)) - floor(addr / (DW/8)) + 1`; every beat is a full DW word on the port, beat `j` at `(addr & ~(DW/8-1)) + j * DW/8` |
| partial first / last word | write: `wstrb` marks the bytes inside `[addr, addr+len)` in the first and last beat; bytes outside are not written (verified for every first-word offset x lengths up to two beats + 3). Read: the full word comes back and `rd_strb` marks the valid bytes |
| data streams | write: bus-lane layout, lanes outside the burst are don't-care; read: bus-lane layout + valid-byte mask + `rd_last` |
| id | one id per burst (all beats), so the SFB3 same-pair ordering (R5/O2) returns the beats in order and response grouping is a counter |
| outstanding | acknowledged writes: `MAX_OUT` beats; reads: credit-limited by the read FIFO (`RD_FIFO` beats) so the master always drains the response channel (SFB3 M1) whatever the consumer does; posted writes: bounded by the fabric's `MST_MAXO` |
| operations | READ, WRITE (acknowledged: completes when every beat is acknowledged), WRITE_POSTED (completes when the last beat was accepted; failures surface as fabric events) |
| concurrency | one burst in flight per sequencer; instantiate several sequencers for several masters (tested: two burst masters + scripted traffic, `NTP = 2`, `NP = 2`) |
| beat errors | per beat: every beat is issued, an erroring beat has no side effect (SFB3). The completion reports status class `SLVERR` / `DECERR` of the **first** erroring beat and its index. A write to a range that is partly illegal therefore commits its legal beats: **no atomicity across beats** (controller O4) |

### Rejected before any beat is issued (completion status REJECT, nothing consumed, nothing issued)

| reason | condition |
|---|---|
| OPCODE | opcode not READ / WRITE / WRITE_POSTED |
| ZERO | length 0 |
| TOOLONG | length above `MAX_BYTES` |
| WRAP | `addr + len` wraps the address space |
| RANGE | `[addr, addr+len)` not inside `[LIM_LO, LIM_HI)` (the sequencer's allowed region; integrate it with the bridge window) |
| BOUNDARY | crosses a multiple of `BOUNDARY` bytes (when `BOUNDARY != 0`; off by default) |

## 3. Interface

Command `cmd_{valid,ready,op,addr,len,id,qos}`; write data `wd_{valid,ready,data}` + `wd_lane_mask_o`; read data `rd_{valid,ready,data,strb,last,status}`; completion
`done_{valid,ready,id,status,reason,beats,err_beat,bytes}`; SFB3 master port `m_*`; statistics (bursts, rejected, beats, payload bytes, wire bytes, error beats, busy, request stall, data starve, credit stall, read stall, protocol errors).
`wd_ready` is the SFB3 request handshake of that beat (the data is consumed when the fabric accepted the beat); the master must hold `wd_valid` and the data until `wd_ready` (an SFB3 R2 consequence).

## 4. Backpressure

* request side: `m_req_ready` low -> the beat and its write data are held (SFB3 R2);
* write data starvation: no beat is issued without data (`st_data_starve`);
* read consumer slow: the FIFO fills, issue stops at the credit limit, responses are still accepted (`st_rd_stall`, `st_credit_stall`);
* response side: always ready (SFB3 M1) - the credit scheme is what makes this safe.

## 5. NOT AXI4

No separate AW / W / B / AR / R channels, no WLAST, no narrow transfers, no wrap / fixed bursts, no `AxCACHE` / `AxPROT` / `AxLOCK`, no exclusive access, no interleaving, no reordering of beats of different bursts, no 4 KiB rule,
one burst at a time. Nothing in this repository claims AXI4 compliance.

## 6. Efficiency (measured: reports/PERFORMANCE.md sec. 8)

Payload bytes / bytes occupying the fabric: **100 %** for word-aligned bursts, **98 %** for a 251-byte unaligned burst (the partial first / last words are the only waste), **100 %** for 4 KiB bursts, and `len / (DW/8)` for a burst shorter than one beat
(7 bytes: 87 % at DW = 32, 43 % at DW = 128). Throughput with one burst in flight: 7.9 B/cycle (256-byte reads) to 10.4 B/cycle (4 KiB reads) at DW = 128 against the 16 B/cycle port limit, because each burst pays its request-to-completion round trip once
and the read side is limited to `RD_FIFO` = 4 beats (and the fabric's 4 outstanding transactions per master). A fabric beat narrower than the 16-byte controller line costs a whole bank access (controller limitation, no sub-line array access),
which wastes bank bandwidth but not fabric cycles: the bank accepts one access per cycle and a single target port issues at most one beat per cycle.
