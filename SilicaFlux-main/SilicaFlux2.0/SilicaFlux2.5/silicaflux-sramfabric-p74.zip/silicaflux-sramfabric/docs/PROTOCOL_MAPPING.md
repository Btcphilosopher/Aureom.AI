# PROTOCOL MAPPING - DataFabric (SFB3) to the SRAM controller

Status labels: every behaviour below is **RTL-SIMULATION** verified (docs/VERIFICATION.md). Nothing here is silicon data.

## 0. Which protocol, and why no new one

The documented DataFabric memory protocol is the SFB lineage: SFB (SilicaFlux-V) -> **SFB2** (DataFabric, `PROTOCOL.md`) -> **SFB3** (DataFabric-NoC, Project 22,
`third_party/noc_sfb3/PROTOCOL_SFB3.md`, spoken unchanged by the NoC spine of Project 34). The bridge is an SFB3 **target**. Its fabric-facing signal set is exactly the SFB3
target port: `t_req_{valid,ready,opcode,src,id,qos,addr,wdata,wstrb}` and `t_rsp_{valid,ready,src,id,opcode,status,rdata}`. No field was added, removed or re-purposed.
The only extra port is `rsp_cause_o`, an **informational sideband beside** the port (not part of SFB3).

SFB3 is **single-beat** (one DW-wide beat per transaction, byte enables, no burst fields; SFB2 R10: "a burst is a sequence of single-beat transactions"). Burst metadata is therefore
**not supported on the fabric port and none is invented**. Bursts are handled on the client side (`sf_sdf_burst_seq`, docs/BURSTS.md) and reach the bridge as ordinary beats.

The bridge is **not AXI4** and makes no AXI4 claim.

## 1. Conversion table (fabric request -> controller request)

| SFB3 (target port) | Conversion | Controller (master port) |
|---|---|---|
| `t_req_addr` (byte address) | window test, range test, alignment test (`sf_sdf_addr_xlate`); `off = addr & (2^WIN_LOG2 - 1)`; line address = `off` with the low `LB = 4` bits cleared | `c_req_addr` (byte address of the 128-bit line) |
| `t_req_opcode` READ (0) | legal address: read | `c_req_we = 0` |
| `t_req_opcode` WRITE (1), WRITE_POSTED (2) | legal address: write; the response is issued after the bank accepted the write (SFB2 R7). POSTED: executed identically, its response is the **completion** the fabric retires (SFB3 R5: exactly one response per accepted request) | `c_req_we = 1` |
| `t_req_opcode` 3..7 | FENCE and reserved opcodes never reach a target (the fabric answers them). If one does, it is rejected: cause OPCODE | forwarded as a harmless rejected read |
| `t_req_wdata` (DW bits) | steered to the lane `lane = off[LB-1:log2(DW/8)]` of the 128-bit line (DW = 32 / 64 / 128; DW = 128 has one lane) | `c_req_wdata` (128 bit) |
| `t_req_wstrb` (DW/8 bits) | placed on the same lane; every other lane's byte enable is 0. A write with `wstrb = 0` is an acknowledged no-op | `c_req_be` (16 bits) |
| `t_req_src`, `t_req_id`, opcode | carried through the controller as its transaction id `{bad, opcode, src, id, lane}` **and** held in the per-port transaction queue (`sf_sdf_txq`) in acceptance order | `c_req_id` |
| `t_req_qos` | not used: the SRAM does not reorder by class (QoS is applied by the fabric arbiter, `ARB_QOS`) | - |
| `(src, id)` | pinned to **one** controller port: `port = (src + id) mod NP`. The controller answers one port in acceptance order, so the SFB3 per-pair order (R5/O2) is the controller's per-port order. Different pairs may be answered out of order across ports (legal). NP = 1: fully in order | `c_req_valid[port]` |

An **illegal** request (cause != NONE) never touches an array. It is sent to the controller as a read of address `0xFFFFFFFF` (out of range **and** misaligned), which the controller rejects itself, so
exactly one response still exists for it and it stays in order behind earlier requests of the same pair (R5/O2). The bridge's own cause code (not the controller's status) is reported.

## 2. Response conversion (controller response -> fabric response)

| Controller | Bridge | SFB3 response |
|---|---|---|
| `c_rsp_id` | cross-checked with the head of the port's transaction queue (mismatch = counted protocol error) | `t_rsp_src`, `t_rsp_id`, `t_rsp_opcode` echo the request |
| `c_rsp_rdata` (128 bit) | the request's lane is selected; zero for writes and for every error | `t_rsp_rdata` (DW bits) |
| `SF_ST_OK` | cause NONE | `ST_OKAY` (0) |
| `SF_ST_ECC_UE` | cause ECC, rdata 0 | `ST_SLVERR` (1) |
| any other non-OK status of a legal request (RANGE / ALIGN / OWNER / BADOP) | cause SRAM, rdata 0 | `ST_SLVERR` |
| bridge-detected: window / range / allowed-range miss | cause ADDR | `ST_SLVERR` |
| bridge-detected: not DW aligned | cause ALIGN | `ST_SLVERR` |
| bridge-detected: opcode | cause OPCODE | `ST_SLVERR` |
| controller flushed / reset while the transaction was in flight | synthesised by the bridge, cause RESET | `ST_SLVERR` |
| no controller response within `TIMEOUT` cycles | synthesised, cause TIMEOUT | `ST_SLVERR` |
| `c_rsp_ce` (corrected ECC error) | counted (`SDF_P_CE`); the data is correct | `ST_OKAY` |

`ST_DECERR` (2) is a **fabric** status (unmapped / denied / misaligned with `CHECK_ALIGN` / reserved opcode) and is never produced by this target. Errors never have a side effect (SFB3).
Cause detail travels beside the response (`rsp_cause_o`), in the error log and in per-cause counters (docs/ERRORS_AND_RECOVERY.md).

## 3. Byte addressing, byte enables, transaction ids

* Byte addressed, little endian: byte `b` of a beat is bits `[8b+7:8b]` and holds address `A + b` of the DW-aligned word at `A` (SFB2 sec. 1).
* Beats are DW aligned (SFB3 R9). With the fabric's `CHECK_ALIGN = 1` a misaligned request is answered `ST_DECERR` by the fabric and never reaches the bridge; with `CHECK_ALIGN = 0` the bridge answers `ST_SLVERR` / cause ALIGN.
* `wstrb` is any pattern (including sparse). A read always returns a full DW word (SFB3 R10).
* The id is returned unchanged; the same `(src, id)` pair is answered in acceptance order.

## 4. Ready / valid flow control and the rules the bridge keeps

| Rule | How |
|---|---|
| R2 held request stable | the bridge never samples an un-accepted payload; with `REQ_REG = 1` the input skid buffer registers it |
| R3 `req_valid` must not depend on `req_ready` | the bridge does not drive `t_req_valid`; towards the controller `c_req_valid` depends on the held request only |
| R4 held response stable | with `RSP_REG = 1` the response comes from a register (also across a controller flush); with `RSP_REG = 0` the selected port is locked while stalled |
| R5 exactly one response per accepted request, never in the acceptance cycle | transaction queue + synthesised completions on flush / timeout; latency >= 2 cycles by construction (checked) |
| R11 reset | asynchronous assert / synchronous release; everything in flight is cancelled and no response is delivered for it. The controller must share the reset domain; a controller-only reset is `c_flush_i` (recovery below) |
| M1 masters always drain responses | not a bridge duty; the burst sequencer keeps the rule with credit-limited read buffering |
| no combinational path `t_rsp_ready -> t_req_ready` | `t_req_ready` depends on registered state (`REQ_REG = 1`) or on the controller grant (`REQ_REG = 0`), never on `t_rsp_ready` |

`t_req_ready` (REQ_REG = 1) is a registered skid-buffer ready; with `REQ_REG = 0` it is `c_req_ready[port] & ~recovering` (the controller's per-bank grant is then in the fabric's request path, see
reports/timing_depth.md). Back-pressure on the response side (`t_rsp_ready = 0`) holds the register, then the controller slot (the controller slot count is the limit), then the request side.

## 5. Differences from the earlier Project-71 adapter of the same name

`sf_sram_datafabric` (silicaflux-memorycore-sram) was a combinational single-port adapter. This module is port-compatible for the `t_*` / `c_*` signals when `NTP = 1` (extra ports: `c_rsp_ce`, `c_flush_*`, statistics, register page) and adds:
the explicit window / range / allowed-range check, registered boundaries, transaction queues, orphan and protocol checks, flush and timeout recovery (R5 under controller flush), per-cause error log,
performance counters, a register page, several target ports, and the burst sequencer. See docs/AUDIT.md.
