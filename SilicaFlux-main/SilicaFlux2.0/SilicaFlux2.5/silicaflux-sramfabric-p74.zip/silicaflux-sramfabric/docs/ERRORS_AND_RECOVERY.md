# ERRORS AND RECOVERY

Labels: RTL-SIMULATION verified (`tb_sdf`: S5 errors, flush rounds, timeout phase, reset phase, ECC phase; docs/VERIFICATION.md). No silicon data.

## 1. Error causes and the documented DataFabric response

SFB3 defines three statuses; a target answers `ST_OKAY` or `ST_SLVERR` (`ST_DECERR` belongs to the fabric). Every bridge cause maps to `ST_SLVERR` with `rdata = 0` and **no side effect**.
The cause is reported beside the response (`rsp_cause_o`), in the first-error log, and in per-cause counters.

| cause | value | condition | detected by | side effect |
|---|---|---|---|---|
| NONE | 0 | success (a corrected ECC error is still success; `SDF_P_CE` counts it) | - | the access |
| ADDR | 1 | **illegal address**: outside the window, outside `[ALLOW_LO, ALLOW_HI)`, beyond the controller capacity | bridge (`sf_sdf_addr_xlate`) | none |
| ALIGN | 2 | beat address not DW aligned (reaches the bridge only with `CHECK_ALIGN = 0` or direct drive) | bridge | none |
| OPCODE | 3 | **unsupported transfer**: opcode other than READ / WRITE / WRITE_POSTED (FENCE and reserved opcodes are answered by the fabric; this is defence) | bridge | none |
| SRAM | 4 | the controller answered RANGE / ALIGN / OWNER / BADOP for a request the bridge let through (a configuration mismatch, e.g. `ALLOW_HI` > capacity; elaboration rejects it) | controller status | none |
| ECC | 5 | **uncorrectable ECC error** (`SF_ST_ECC_UE`, ECC builds). A partial write onto an uncorrectable line is aborted by the bank | controller status | read: none; partial write: aborted |
| TIMEOUT | 6 | **timeout**: accepted by the controller, no response for `TIMEOUT` cycles | bridge watchdog | **outcome of a write unknown** (see 3) |
| RESET | 7 | **controller reset / flush** while the transaction was in flight | bridge (`c_flush_i`) | **outcome of a write unknown** (see 3) |

Not causes but monitored conditions (counters, never delivered as responses): **orphan** controller response (queue empty: consumed, counted `SDF_P_ORPHAN`), **protocol mismatch** between a controller response and the queue head (`SDF_P_PROTO`),
**queue overflow** (`SDF_P_OVF`; cannot happen when `TXQ_DEPTH >= controller NSLOT`, which is an elaboration check; an embedded assertion also fires). All three must be 0 in a healthy system and are checked 0 by every regression case.

**Interface overflow.** The request side cannot overflow: `t_req_ready` is the only intake and is low whenever the controller cannot take a request. The response register holds one response and `c_rsp_ready` is
low while it is full. The per-port transaction queue mirrors the controller reorder slots (`TXQ_DEPTH >= NSLOT`).

### Error reporting registers

Per target port: sticky first-error log `{cause, src, id, opcode, addr}`, error counter (saturating), per-cause counters, `irq_o` (= sticky). Register page (`rb_*`): `+0x02 ERR_STATUS`, `+0x03 ERR_CNT`,
`+0x04 ERR_INFO`, `+0x05 ERR_ADDR`, `+0x08..0x0F` per-cause counters; clear with a write to `+0x01` (bit 1 error log, bit 0 counters) or `err_clr_i`.
Posted writes: a failing completion returns `ST_SLVERR` to the fabric, which raises its own `ev_posted_err` (SFB3 sec. 3); the cause is in this log.

## 2. Reset

* **Fabric / system reset** (SFB3 R11): asynchronous assert, synchronous release; everything in flight is cancelled, **no response is delivered** for it (the scoreboard checks that nothing arrives for pre-reset requests and that the
  system is fully functional afterwards, `tb_sdf` reset phase). The controller must share the reset domain with the bridge; the array contents are not reset (controller O8; ECC builds re-initialise).
* **Controller-only flush / reset** (e.g. the MBIST sequencer's flush, an error-recovery flush, the controller's own reset): connect `c_flush_i = flush_busy_o | ~controller_rst_n`.

## 3. Controller flush recovery (`sf_sdf_port` state machine)

```
RUN --(c_flush_i)--> FLUSH --(flush ended)--> DRAIN --(all queues empty)--> RUN
RUN --(timeout, TO_ACTION=1: pulse c_flush_o)--> FLUSH ...
```

* While not in RUN the bridge accepts no new request (`t_req_ready = 0`); requests already held stay held (no withdrawal).
* A flush discards every response the controller owed (controller O7); writes the controller had accepted **stay committed** (the controller accepts a write into its bank in the same cycle it allocates the slot).
* In DRAIN the bridge answers **every** transaction that was in flight, in queue order per port, with `ST_SLVERR` and cause RESET (or TIMEOUT): exactly one response per accepted request (SFB3 R5).
  A response already in the response register at the time of the flush is delivered normally (it was popped before).
* **Guarantee given to the master**: a response with cause RESET / TIMEOUT means "the transaction completed abnormally and a write's outcome is unknown". With this controller a write that reached the queue is in fact committed
  (the scoreboard's byte model and the backdoor array check agree after every flush round), but software must not rely on it beyond what the SFB3 R11 text says.
* `RSP_REG = 1` is required: the held response must stay valid and unchanged across a flush (SFB3 R4). With `RSP_REG = 0` `c_flush_i` must be tied low (an embedded assertion checks it).

## 4. Timeout

`TIMEOUT` counts, per controller port, consecutive cycles in which the port has outstanding transactions, the controller presents no response **and** the bridge is not stalled by its own downstream.
A slow-but-alive controller therefore never times out (regression cases run with `TIMEOUT = 48` through all heavy-traffic phases and check "no timeout" - the counters stay 0; the lower bound is also checked: a mutant that fires after half
the time is killed).
`TO_ACTION = 1` (default): the bridge pulses `c_flush_o` (wire it to the controller `flush_i`) and recovers as above with cause TIMEOUT. If the flush never appears (not wired) the bridge gives up waiting after `FLUSH_WAIT`
cycles and drains anyway; late controller responses would then be counted as orphans - wire `c_flush_o` or use `TO_ACTION = 0`.
`TO_ACTION = 0`: report only (timeout counter, error log with cause TIMEOUT); transactions stay outstanding.
`TIMEOUT = 0` disables the watchdog (default in the unit tests).

## 5. What the bridge cannot do

* It cannot make the controller recover: a hung controller needs `c_flush_o` wired, and a controller that stays hung after the flush leaves the bridge answering RESET to everything.
* It does not detect data corruption other than the controller's ECC status; no parity on the bridge's own queues (simulation-grade design, docs/KNOWN_LIMITATIONS.md).
