# KNOWN LIMITATIONS (read before relying on anything)

## Not claimed / not done

1. **No silicon, timing, area or power data.** Every number is an RTL-simulation cycle count (Verilator 5.020) or a Yosys 0.33 generic-gate count / logic depth. "Depth" is a relative indicator of
   combinational path length, not a delay. No PDK, no OpenROAD, no STA.
2. **Not ASIC-ready.** The vendored controller / SRAM backends carry the limitations of the MemoryCore package (no vendor macro views, behavioural arrays; docs there).
3. **Bounded verification only.** There are no formal proofs in this package (no SymbiYosys flow was run). The assertions are simulation checks (`SF_ASSERT` embedded checks, `sf_sdf_tgt_chk`, `sfn_protocol_checker`).
4. **Mutation testing** uses a hand-written list (`tools/mutate.py`, 46 mutants of the bridge, sequencer and integration top). A full kill count says nothing about faults nobody thought to inject.
5. **Verilator is two-state.** X-propagation is not exercised (the protocol checkers flag X on handshakes in Icarus-style simulators only).
6. **Icarus / other simulators were not used for the regression**; the RTL follows the repository portability rules (flat ports, no interfaces / structs / packages in synthesizable code, sized literals) and elaborates in Yosys 0.33, but only Verilator results are claimed.

## Protocol / functional limits

7. **SFB3 has no burst metadata**; the fabric port is single-beat. Bursts need `sf_sdf_burst_seq` on the client side. The burst subset is **not AXI4** (docs/BURSTS.md sec. 5).
8. **One burst in flight per sequencer**; no burst pipelining (a bubble between bursts, measured in reports/PERFORMANCE.md).
9. **Fabric DW 32 / 64 / 128 only** (DW 256 / 512 not supported: a beat wider than the 128-bit line would need a two-line split and response merge).
10. **No coherence, no atomicity across beats or requests, no locks** (controller O4/O5, SFB3 sec. 5). Cross-path visibility (NoC vs direct ports) is through the write response only.
11. **A narrow beat costs a whole 16-byte bank access** (controller has no sub-line array access): bank energy and bank-limited throughput per useful byte are 4x worse for 32-bit beats.
12. **ECC is the controller's SECDED**: 3-bit errors may be silently miscorrected (documented there); the bridge adds nothing.
13. **After RESET / TIMEOUT recovery the outcome of a write is unknown to the master** (it is committed with this controller, but that is not part of the bridge contract).
14. **The controller must share the reset domain** with the bridge; a controller-only reset must be wired to `c_flush_i`. A bridge-only reset while the controller keeps serving would deliver stale responses to new
    transactions (counted as orphans only when the queue is empty) - not supported, not tested.
15. **`RSP_REG = 0` cannot recover from a controller flush** (R4); `c_flush_i` must be tied low there.
16. **`TO_ACTION = 1` needs `c_flush_o` wired to the controller flush**; unwired, late responses after a timeout would be orphans.
17. **`NTP <= 4`** (register page has four 64-word blocks); the burst sequencer's `MAX_BYTES` is a parameter, 4096 tested.
18. **Timestamps are 16 bit** (`TS_W`): a transaction older than 65 535 cycles would report a wrapped latency (the watchdog timeout is far below that).
19. **QoS is not used by the bridge**: priority is applied by the fabric arbiter.
19b. **Statistics are not trimmed by a parameter**: the 28 x 32-bit performance counters, per-bank and per-cause counters, the error log and the transaction queues dominate the bridge's flip-flop count in Yosys (reports/synthesis.md, thousands of flip-flops per target port). They are simulation- and bring-up-grade; a production build would parameterise them away.
20. **One DMA / burst master port per sequencer; the vector scratchpad's own burst DMA and the tensor DMA port are local** and are not routed through the NoC.

## Tool caveats

21. Verilator 5.020 quirks shaped the testbenches: a function call in a `while` condition across timing waits is not re-evaluated reliably (explicit `forever`/`break` loops are used); hierarchical backdoor reads need generate loops; no `fork`.
22. The perf testbench's numbers are single-seed open-loop windows (4000 cycles); random-pattern results carry sampling noise.
23. The integration testbench checks each agent in its own region; it does not scoreboard every NoC beat the way `tb_sdf` does (that is `tb_sdf`'s job on the NoC path).
