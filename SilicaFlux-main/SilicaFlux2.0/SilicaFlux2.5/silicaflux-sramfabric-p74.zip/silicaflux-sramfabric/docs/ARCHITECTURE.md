# ARCHITECTURE

Labels: RTL-SIMULATION unless stated; synthesis figures are Yosys generic-gate indicators (reports/synthesis.md, reports/timing_depth.md). No silicon data.

## 1. Pipeline

```
 DataFabric Request -> Protocol Adapter -> Address Decode -> SRAMController -> Banked SRAM
                                                             |
 DataFabric Response <- Response Adapter <------------------+

 t_* (SFB3 target)                                                                                c_* (controller master ports, NP per target port)
 request ---[REQ stage]--> sf_sdf_addr_xlate --> lane steering --> (src,id)->port --> c_req_*   ---> sf_sram_controller ---> NB x sf_sram_bank
            (2-entry skid,   window / range /      byte enables      NP-way select       |  txq push on controller acceptance
             registered      alignment, bank,      write data        gate when           |
             ready, opt.)    row, lane                               recovering          v
 response <-[RSP stage]---- status map / lane select <---- RR pick (locked) <---- c_rsp_* + txq head cross-check, orphan drop
            (register, opt.)        ^
                                    +---- synthetic RESET / TIMEOUT responses from the txq (flush / timeout recovery FSM)
```

| module | role |
|---|---|
| `sf_sram_datafabric` | top: `NTP` target ports (slices), register page, aggregation |
| `sf_sdf_port` | one SFB3 target port <-> `NP` controller ports: protocol adapter, response adapter, transaction queues, recovery FSM, error log, statistics, embedded assertions |
| `sf_sdf_addr_xlate` | address translation / bounds / alignment (combinational) |
| `sf_sdf_skid` | 2-entry skid buffer with registered ready (request stage) |
| `sf_sdf_txq` | outstanding-transaction queue per controller port (acceptance order) |
| `sf_sdf_burst_seq` | client-side burst sequencer (docs/BURSTS.md) |
| `sf_sdf_tgt_chk` | SFB3 target-port assertion monitor (verification only) |
| `sf_sram_fabric_top` | integration: NoC + bridge + controller + VectorScratch + TensorScratch (docs/MEMORY_MAP.md) |
| vendored (`third_party/`) | `sf_sram_controller`, banks, ECC, scratchpads, the SFB3 NoC and its protocol checker - byte identical, SHA-256 manifest |

## 2. Timing: where the registers are and why

* **`REQ_REG = 1` (default)**: a skid buffer whose `in_ready` is a flip-flop, so `t_req_ready` is a function of registered state only. Without it, `t_req_ready` is the controller's `c_req_ready[port]`, which depends on the request
  address (bank select), the per-bank grant logic, other masters' requests and slot availability: the controller's grant logic lands in the fabric's request path. The depth analysis (reports/timing_depth.md) shows the request cone
  with and without the register.
* **`RSP_REG = 1` (default)**: the response is registered. Reasons: (1) SFB3 R4 - a held response must stay valid and unchanged; the controller *withdraws* responses when flushed (O7), so recovery needs the register;
  (2) the response cone (controller `rdata` -> lane select -> status map -> fabric) is cut; (3) the response register accepts one response per cycle with `ready = ~full | t_rsp_ready`: full throughput.
* Both stages are **full-throughput** (measured: same bytes/cycle with and without, reports/PERFORMANCE.md section 7) and cost one cycle of latency each (measured and equal to the formula).
* No other stage is registered: the address translation and lane steering are shallow (reports/timing_depth.md, bridge slice alone) and sit between the skid register and the controller's grant logic. If a floorplan needs another cut,
  the place is between `sf_sdf_addr_xlate` and the controller request (one more skid stage; the transaction queue already decouples the response side).

**Latency**: unloaded read / write latency at the target port = `REQ_REG + RSP_REG + BANK_LAT + 1` cycles, `BANK_LAT = READ_LATENCY (+1 with ECC)`. Measured equal in all 12 pipeline x latency combinations and with ECC.

## 3. Concurrency and capacity

* One SFB3 target port accepts at most **one beat per cycle**; with `NP` controller ports per target port the bridge can keep `NP x NSLOT` transactions in flight (the (src,id) -> port pinning keeps the per-pair order).
  `NP > 1` helps when a slow bank access (ECC read-modify-write) would otherwise block the head of the single controller port.
* `NTP` target ports (each its own window alias) accept `NTP` beats per cycle, limited by the controller's one access per bank per cycle; concurrent masters on different banks proceed in parallel, masters that collide on a bank serialise
  with round-robin fairness (controller O6). Measured in reports/PERFORMANCE.md section 4.
* Outstanding transactions per controller port <= `NSLOT` (the controller slot count is the backpressure); `TXQ_DEPTH >= NSLOT` is an elaboration check.

## 4. Clocking, reset, parameters

One clock domain; asynchronous assert / synchronous release reset shared by fabric, bridge and controller (SFB3 R11). Parameters (selection): `NM`, `AW`, `DW` (32/64/128), `IDW`, `NTP` (<= 4), `NP`, `NB`, `DEPTH`,
`WIN_BASES`, `WIN_LOG2`, `ALLOW_LO`, `ALLOW_HI`, `REQ_REG`, `RSP_REG`, `CTRL_NSLOT`, `TXQ_DEPTH`, `TIMEOUT`, `TO_ACTION`, `TS_W`, `CNT_W`. Illegal combinations are elaboration errors (`SF_CFG_FATAL`), e.g. `TXQ_DEPTH < NSLOT`,
`ALLOW_HI` beyond the capacity, a window smaller than the allowed range.

## 5. Observability

Per target port: first-error log, per-cause counters, 28 performance counters (`SDF_P_*`), per-bank access and stall counters, outstanding count, recovery state, `irq_o`; a register page (`rb_*`) maps them (docs in the header of `sf_sram_datafabric.sv`).
The controller's own counters (`perf_conf_o`, `perf_stall_o`) complement them.

## 6. Tool rules kept (DataFabric PROTOCOL.md sec. 9, repository RTL coding rules)

Flat ports, no interfaces / structs / packages in synthesizable RTL (`sf_sdf_defs.svh` is a header of `define`s), sized literals in parameters, no `int'()` casts in RTL, package-free; the RTL elaborates in Verilator 5.020 and Yosys 0.33 (`make lint`, `make syn`).
