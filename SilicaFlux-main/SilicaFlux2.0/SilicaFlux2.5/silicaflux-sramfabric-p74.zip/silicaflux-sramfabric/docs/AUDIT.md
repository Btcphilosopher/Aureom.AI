# REPOSITORY AUDIT (what was inspected, what was reused, what was decided)

Source: `btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/` (nested project archives). Tools used for the audit and everything else: Verilator 5.020, Icarus 12 (not needed in the end), Yosys 0.33 - the same versions the existing
packages' tool-portability rules (DataFabric PROTOCOL.md sec. 9) were written for.

## 1. Inventory

| area asked for | found | used here? |
|---|---|---|
| DataFabric (SFB / SFB2) | `silicaflux-datafabric.zip`: `PROTOCOL.md` (SFB2 R1-R12), `MEMORY_MAP.md`, `sfb_crossbar`, `sfb_sram_slave` (SFB2 slave on the SRAM Wrapper Library), `silicaflux_dma` (buffered / burst engine, DW-aligned addresses, error codes SRC_ALIGN / DST_ALIGN / ...), protocol checker | protocol rules and the memory-map conventions; not instantiated |
| DataFabric NoC (**SFB3**) | `silicaflux-datafabric-noc.zip` (P22): `docs/PROTOCOL.md`, `silicaflux_noc` (shared bus / crossbar / mesh), `sfn_pkg`, bridges `sfn_sfb2_{mst,tgt}_bridge`, `sfn_protocol_checker` | **the protocol of the bridge**; the NoC RTL and checker are vendored byte-identical (`third_party/noc_sfb3`, SHA256SUMS, identity re-verified against the P22 archive) and used as the real fabric in every test |
| existing NoC spine | `silicaflux-noc-spine-p34.zip`: `docs/PROTOCOL.md` - speaks **SFB3 unchanged**, pipelined links, traffic classes | confirms SFB3 is the one fabric protocol; its section 5: "SFB3 is single-beat; bursts are streams of independent transactions" |
| other NoC | `silicaflux-datafabric-noc-v2.zip`: `sf_noc_mem_target_ni`, `noc_interconnect.sv` - the tile **memory NoC** around the legacy `memory_controller` | not used (a different, tile-memory protocol; the legacy controller fails its cross-check, see memorycore `docs/SF_COMPAT.md`) |
| SRAMController, SRAMBank | `silicaflux-memorycore-sram.zip` (Project 70-series MemoryCore): `sf_sram_controller` (NM x NB, 128-bit lines, byte enables, per-master in-order responses, flush / quiesce, ECC), `sf_sram_bank`, `sf_sram_core`, ECC, MBIST, backends | **vendored byte-identical** (`third_party/memorycore`); the controller contract (O1-O8) is the other fixed point |
| VectorScratch, TensorScratch | `sf_vector_scratchpad`, `sf_tensor_scratchpad` (+ `sf_ts_port`) in the same package | vendored; connected directly to the controller (`sf_sram_fabric_top`) |
| SRAM core library | `silicaflux-sramcore-p71.zip`, `silicaflux-sramlib.zip` (`sram_sp`, `sram_if`) | not used: the controller package has its own array / backends |
| memory-map definitions | DataFabric `MEMORY_MAP.md` (SRAM banks at `0x1000_0000`), ControlCore `MEMORY_MAP.md` (**DEVMEM `0x2000_0000`, 1 MiB shared device SRAM**) | the ControlCore DEVMEM window is reused (docs/MEMORY_MAP.md) |
| DMA | DataFabric `silicaflux_dma` (SFB2 master), ControlCore `mcu_dma`, Project-40 stand-in `sf_dma` (word copy, 16-bit address), vector scratchpad's line DMA | `silicaflux_dma` / `mcu_dma` attach to SFB3 through `sfn_sfb2_mst_bridge` (unchanged); the burst sequencer here is the **byte-granular** burst front end those engines lack (they need DW-aligned addresses) |
| accelerator interfaces | tensor / vector scratchpad ports (above); HPC tile and tensor unit are SFB2 masters (P22 `reports/endpoints.md`) | attach through `sfn_sfb2_mst_bridge` |
| existing bus protocol adapters | `sfn_sfb2_tgt_bridge` (SFB3 target -> SFB2 slave, tag FIFO, depth 1 for SFB2 slaves), `sfb_sram_slave`, **`sf_sram_datafabric` (Project 71)**: SFB3 target -> controller | the Project-71 adapter was read in full and is the baseline this work extends |

## 2. Findings that shaped the design

1. **One documented fabric protocol: SFB3.** Everything above SFB (V1) is an additive extension of the previous revision; the NoC spine speaks SFB3 unchanged. The bridge is an SFB3 target; no second protocol exists in this work.
2. **SFB3 has no burst metadata** (single beat, byte enables, ids, opcodes, status). "Burst metadata where supported" is therefore "not supported on the fabric port" and is documented as such; bursts are a client-side sequencer.
3. **The controller works in 128-bit lines** with byte enables; narrower fabric words use a lane of a line and cost a whole bank access (controller limitation 16). The controller guarantees in-order responses per master port, bounded outstanding (reorder slots), per-bank serialisation, and flush semantics that **withdraw** presented responses (O7) - which a naive adapter turns into an SFB3 R4 violation (the Project-71 adapter did).
4. **Gaps of the Project-71 adapter** found by reading it, all addressed: no explicit window / allowed-range check (relied on the controller's RANGE for offsets past capacity, no way to keep private regions off the NoC); illegal requests were forwarded as reads of the *real* address (array access, ECC event); fully combinational request path (`t_req_valid -> controller grant -> t_req_ready`); `t_rsp_valid` could drop under back-pressure when the controller flushed (R4); no handling of controller flush / reset (an accepted request would never be answered: R5), no timeout, no orphan / protocol / overflow monitoring; `rdata` of an ECC UE depended on the controller; no corrected-ECC visibility; no statistics; one target port only; no burst handling; mixed error status (all `SLVERR`, cause only in a sticky register).
5. The DataFabric DMA engines require DW-aligned addresses (`SRC_ALIGN` / `DST_ALIGN`); partial first / last words are not supported there. The burst sequencer adds them.

## 3. Decisions

| # | decision | reason |
|---|---|---|
| D1 | bridge = SFB3 target, signal-for-signal | "do not invent a second incompatible DataFabric protocol" |
| D2 | `ST_DECERR` never produced by the target; every bridge cause is `ST_SLVERR` + cause sideband | SFB3 ownership of DECERR; sideband keeps the documented port intact |
| D3 | illegal requests go to the controller as a rejected read (all-ones address) | one response per request, in order, no array access |
| D4 | transaction queue per controller port + sideband id | needed for orphan detection, timeout, flush completion (R5), latency; redundancy doubles as a cross-check |
| D5 | registered boundaries selectable (`REQ_REG`, `RSP_REG`), default both 1 | timing: logic-depth analysis (reports/timing_depth.md) - the registered ready removes the controller grant logic from the fabric request path; flush recovery needs the response register |
| D6 | `NTP` target ports on one controller (aliased windows) | the only way a single-port-per-target fabric can use the controller's bank parallelism (measured) |
| D7 | partition aperture shared / private with `ALLOW_HI` | tensor ownership cannot be bypassed from the NoC |
| D8 | burst sequencer on the client side, not new fabric signals | D1 |
| D9 | vendor the controller / scratchpads / NoC byte-identical with checksums, do not edit them | provenance and re-verification; this package's claim is only the new RTL |
| D10 | scoreboards decode independently and the serialisation order comes from the controller acceptance | an end-to-end check that does not trust the bridge's translation |
