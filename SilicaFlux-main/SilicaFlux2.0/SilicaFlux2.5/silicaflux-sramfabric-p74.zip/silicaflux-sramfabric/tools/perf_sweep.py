#!/usr/bin/env python3
"""Performance sweep: builds / runs tb/tb_sdf_perf.sv for a set of configurations and writes
reports/perf_raw.json, reports/perf.csv and reports/PERFORMANCE.md (tables) plus SVG charts.

Every number is an RTL-simulation cycle count (Verilator 5.020).  There is no silicon, timing or power data here.

  python3 tools/perf_sweep.py [--jobs 4] [--quick]
"""
import argparse, csv, json, os, re, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "sim"))
import run_regress as rr  # noqa: E402

PERF = "tb/tb_sdf_perf.sv"


def cfg(name, **kw):
    return rr.case(name, "tb_sdf_perf", PERF, kw)


CONFIGS = []
# A: bridge pipeline registers x controller read latency (DW = 128, one target port)
for rq in (0, 1):
    for rs in (0, 1):
        for rl in (1, 2, 3):
            CONFIGS.append(cfg(f"A_req{rq}_rsp{rs}_rl{rl}", REQ_REG=rq, RSP_REG=rs, READ_LATENCY=rl, NSLOT=(8 if rl < 3 else 8)))
# B: fabric data width
for dw in (32, 64, 128):
    CONFIGS.append(cfg(f"B_dw{dw}", DW=dw))
# C: number of target ports (aliased windows) -- concurrency
for ntp in (1, 2, 4):
    CONFIGS.append(cfg(f"C_ntp{ntp}_dw128", NTP=ntp))
    CONFIGS.append(cfg(f"C_ntp{ntp}_dw32", NTP=ntp, DW=32))
# C2: enough generators (NM = 6 -> 5 single-beat masters) to saturate 4 target ports
for ntp in (2, 4):
    CONFIGS.append(cfg(f"C_ntp{ntp}_nm6_dw128", NTP=ntp, NM=6))
# D: banks
for nb in (1, 2, 4, 8):
    CONFIGS.append(cfg(f"D_nb{nb}", NB=nb, DEPTH=(1024 // nb)))
# E: ECC
CONFIGS.append(cfg("E_ecc_rl1", ECC_EN=1))
CONFIGS.append(cfg("E_ecc_rl2", ECC_EN=1, READ_LATENCY=2))
# F: controller ports per target port
CONFIGS.append(cfg("F_np2_ntp1", NP=2))
CONFIGS.append(cfg("F_np2_ntp2", NP=2, NTP=2))

PAT = re.compile(r"PERF scen=(\S+) (.*)")


def parse(lines):
    out = {}
    for l in lines:
        m = PAT.match(l)
        if not m:
            continue
        d = {}
        for k, v in re.findall(r"(\w+)=(\[[^\]]*\]|\S+)", m.group(2)):
            d[k] = v
        out[m.group(1)] = d
    return out


def run(c):
    r = rr.run_case("perf", c)
    r["scen"] = parse(r.get("perf", []))
    r["cfg"] = c["over"]
    return r


def f(d, k, div=1.0, nd=2):
    try:
        return round(int(d[k]) / div, nd)
    except Exception:
        return None


def svg_bars(path, title, labels, values, unit, color="#2f6db5", width=640):
    h = 28 * len(labels) + 70
    vmax = max(values) if values else 1
    lines = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{h}" font-family="sans-serif" font-size="12">',
             f'<rect width="100%" height="100%" fill="#ffffff"/>', f'<text x="10" y="22" font-size="14" font-weight="bold">{title}</text>']
    for i, (lab, v) in enumerate(zip(labels, values)):
        y = 40 + 28 * i
        bw = 0 if vmax == 0 else int((width - 260) * v / vmax)
        lines.append(f'<text x="10" y="{y+14}">{lab}</text>')
        lines.append(f'<rect x="190" y="{y}" width="{bw}" height="18" fill="{color}"/>')
        lines.append(f'<text x="{190+bw+6}" y="{y+14}">{v} {unit}</text>')
    lines.append("</svg>")
    open(path, "w").write("\n".join(lines))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    cs = CONFIGS[:6] if a.quick else CONFIGS
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(run, cs))
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "perf_raw.json"), "w"), indent=1)
    bad = [r for r in res if r["status"] != "PASS"]
    for r in res:
        print(f"{r['status']:6s} {r['name']:22s} scenarios={len(r['scen'])}", flush=True)
    # ---- CSV
    with open(os.path.join(ROOT, "reports", "perf.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["config", "scenario", "cycles", "useful_bytes", "bytes_per_cycle", "responses", "lat_avg", "lat_min", "lat_max", "rtt_min", "occ_avg", "occ_max",
                    "req_stall", "rsp_stall", "ctrl_stall", "seq_pct", "bank_acc", "bank_stall", "ctl_conf", "burst_util_pct"])
        for r in res:
            for sc, d in r["scen"].items():
                w.writerow([r["name"], sc, d.get("cycles"), d.get("useful_bytes"), f(d, "bpc_x100", 100), d.get("rsp"), f(d, "lat_avg_x100", 100), d.get("lat_min"), d.get("lat_max"),
                            d.get("rtt_min"), f(d, "occ_avg_x100", 100), d.get("occ_max"), d.get("req_stall"), d.get("rsp_stall"), d.get("ctrl_stall"), d.get("seq_pct"),
                            d.get("bank_acc"), d.get("bank_stall"), d.get("ctl_conf"), d.get("burst_util_pct")])
    print("failed configs:", [r["name"] for r in bad])
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
