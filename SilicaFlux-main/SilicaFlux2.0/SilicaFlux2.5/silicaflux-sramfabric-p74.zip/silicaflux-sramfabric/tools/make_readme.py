#!/usr/bin/env python3
"""README.md from the results in reports/ (numbers are read, never typed)."""
import json, os, glob
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def load(n):
    p = os.path.join(ROOT, "reports", n)
    return json.load(open(p)) if os.path.exists(p) else None
def lines(pattern):
    return sum(len(open(f).read().splitlines()) for f in glob.glob(os.path.join(ROOT, pattern)))
suites = {n: load(f"regress_{n}.json") for n in ("sdf", "burst", "integ", "chk")}
tp = sum(r["passed"] for r in suites.values() if r); tt = sum(r["total"] for r in suites.values() if r); tc = sum(r["checks"] for r in suites.values() if r)
mut = load("mutation.json") or []
killed = sum(1 for m in mut if m["status"] == "KILLED")
raw = load("perf_raw.json") or []
P = {}
for r in raw:
    for sc, d in r["scen"].items():
        P[(r["name"], sc)] = d
def pv(c, sc, k, div=1.0, nd=2):
    d = P.get((c, sc))
    return None if not d or k not in d else round(int(d[k]) / div, nd)
syn = {r["name"]: r for r in (load("synthesis.json") or [])}
def dp(n): return syn.get(n, {}).get("depth")
rtl_loc = lines("rtl/*.sv") + lines("rtl/*.svh")
tb_loc = lines("tb/*.sv")
o = []
w = o.append
w("# SilicaFlux SRAMFabric - DataFabric (SFB3) to banked-SRAM bridge\n")
w("Project 74 | Aureom.AI | SilicaFlux Semiconductor Systems | SystemVerilog + Python tooling + Verilator / Yosys flows\n")
w("> **Read first.** This package contains **no silicon data**: every number is an RTL-simulation cycle count (Verilator 5.020), a Yosys 0.33 generic-gate indicator, or a parameter. It is **not AXI4** and claims nothing of the kind. "
  "The bridge speaks the **documented DataFabric protocol (SFB3) unchanged**; SFB3 has no burst fields, so bursts are a client-side sequencer. Formal proofs were not run. See `docs/KNOWN_LIMITATIONS.md`. "
  "Nothing was committed to git; this package was produced as a ZIP as requested.\n")
w("## What this is\n")
w("`sf_sram_datafabric` is an SFB3 **target** that connects the SilicaFlux DataFabric NoC to the existing `sf_sram_controller` and its banks:\n")
w("```\nDataFabric Request -> Protocol Adapter -> Address Decode -> SRAMController -> Banked SRAM -> Response Adapter -> DataFabric Response\n```\n")
w("It converts byte-addressed single-beat transactions (read / write / posted write, byte enables, ids, `ready/valid`) to 128-bit line accesses with lane steering, translates the unified SRAM window "
  "(reusing the ControlCore DEVMEM window at `0x2000_0000`) to word / bank / row, rejects illegal addresses, alignment, opcodes and out-of-range bursts without side effects, maps every error to a documented SFB3 status plus a cause sideband, "
  "recovers from controller flush / reset and timeouts (exactly one response per accepted request), and records latency, bytes, occupancy, bank conflicts and stalls. "
  "`sf_sdf_burst_seq` adds the burst subset (partial first / last words, response grouping, backpressure); `sf_sram_fabric_top` connects ControlCore, DMA, vector / tensor hosts, VectorScratch, TensorScratch and the shared SRAM.\n")
w("## Quick start\n")
w("```bash\nmake lint            # Verilator lint of the new RTL\nmake regress         # 4 suites, every case builds and runs under Verilator 5.x\nmake perf            # performance sweep -> reports/PERFORMANCE.md\nmake syn             # Yosys generic-gate synthesis + logic-depth analysis -> reports/timing_depth.md\nmake mutate          # mutation testing of the testbenches\n```\n")
w("Needs `verilator >= 5.020`, `yosys` (0.33 tested), `python3`. Build products go to `build/` (safe to delete); `reports/` holds the committed results.\n")
w("## Results at a glance (generated from `reports/`; all RTL simulation)\n")
w("| area | result | source |\n|---|---|---|")
w(f"| regression | **{tp}/{tt} cases pass, {tc:,} self-checks** (bridge behind the real SFB3 NoC and direct: {suites['sdf']['passed']}/{suites['sdf']['total']}; burst sequencer unit: {suites['burst']['passed']}/{suites['burst']['total']}; integration: {suites['integ']['passed']}/{suites['integ']['total']}; assertion-monitor self-test: {suites['chk']['passed']}/{suites['chk']['total']}) | `reports/regress_*.json`, `docs/VERIFICATION.md` |" if all(suites.values()) else "| regression | (run `make regress`) | |")
w(f"| mutation testing | **{killed} of {len(mut)}** injected faults killed by the testbenches | `reports/mutation.json` |")
l = lambda c: int(pv(c, "single_read_unloaded", "lat_min", 1, 0))
w(f"| latency (unloaded, RTL sim) | `REQ_REG + RSP_REG + READ_LATENCY + 1` cycles, measured equal in all 12 combinations: {l('A_req0_rsp0_rl1')} cycles with no bridge registers, **{l('A_req1_rsp1_rl1')} with the default registered boundaries** (RL = 1), {l('E_ecc_rl1')} with ECC; the crossbar adds 0 | `reports/PERFORMANCE.md` sec. 2 |")
w(f"| throughput (RTL sim) | one target port: {pv('B_dw128','seq_read_allm','bpc_x100',100)} B/cycle at DW = 128 (one beat per cycle, the port limit); {pv('C_ntp4_nm6_dw128','random_rw_allm','bpc_x100',100)} B/cycle (random read/write mix) with 4 target ports and 5 masters; "
  f"bursts {pv('B_dw128','burst_read_long_4096B','bpc_x100',100)} B/cycle (4 KiB, one burst in flight), utilisation 100 % aligned / 98 % unaligned | `reports/PERFORMANCE.md` sec. 3, 4, 8 |")
w(f"| logic depth (Yosys generic gates, **not timing**) | request cone: {dp("wrap_req_req0_rsp1")} gates without the input register vs {dp("wrap_req_req1_rsp1")} with it; response cone: {dp("wrap_rsp_req1_rsp0")} without the response register vs {dp("wrap_rsp_req1_rsp1")} with it | `reports/timing_depth.md` |")
w(f"| size | {rtl_loc:,} lines of new RTL, {tb_loc:,} lines of testbench | |\n")
w("## Deliverables (as requested)\n")
w("| requested | where |\n|---|---|")
w("| `sf_sram_datafabric.sv` | `rtl/sf_sram_datafabric.sv` (top, `NTP` target ports, register page) |")
w("| protocol adapter modules | `rtl/sf_sdf_port.sv` (request + response adapters, lane steering, status map, recovery), `rtl/sf_sdf_burst_seq.sv` |")
w("| address translation | `rtl/sf_sdf_addr_xlate.sv`, `docs/MEMORY_MAP.md` |")
w("| transaction buffers | `rtl/sf_sdf_skid.sv` (registered-ready request buffer), `rtl/sf_sdf_txq.sv` (outstanding-transaction queues), read FIFO inside `sf_sdf_burst_seq` |")
w("| assertions | embedded `SF_CHK` checks in `sf_sdf_port` (`-DSF_ASSERT`), `rtl/sf_sdf_tgt_chk.sv` (SFB3 R2 / R4 / R5 monitor, self-tested), vendored `sfn_protocol_checker` on every port |")
w("| tests | `tb/tb_sdf.sv`, `tb/tb_sdf_burst.sv`, `tb/tb_sdf_integ.sv`, `tb/tb_sdf_perf.sv`, `tb/tb_sdf_chk_selftest.sv`; `sim/run_regress.py`; `tools/mutate.py` |")
w("| memory map documentation | `docs/MEMORY_MAP.md` |")
w("| performance report | `reports/PERFORMANCE.md` (+ `perf.csv`, `perf_raw.json`, SVG charts), `reports/timing_depth.md`, `reports/synthesis.md` |")
w("| integration | `rtl/sf_sram_fabric_top.sv` (ControlCore, DMA, hosts on the NoC; VectorScratch and TensorScratch on direct local ports; one shared controller) |")
w("| documents | `docs/AUDIT.md`, `docs/PROTOCOL_MAPPING.md`, `docs/ERRORS_AND_RECOVERY.md`, `docs/BURSTS.md`, `docs/ARCHITECTURE.md`, `docs/VERIFICATION.md`, `docs/KNOWN_LIMITATIONS.md` |\n")
w("## Definition of done - status\n")
w("| requirement | status |\n|---|---|")
w("| a real DataFabric master issues a transaction, accesses banked SRAM and receives a correctly tagged response with no loss or duplication | **done**: masters on the real `silicaflux_noc` crossbar; end-to-end scoreboards check exactly-once, id / src / opcode echo, status, cause and data; physical byte placement in the bank arrays checked by backdoor |")
w("| single-word requests first, verified bursts after | **done in that order**: phase 1 (single word) was regressed and mutation-tested before `sf_sdf_burst_seq` was written |")
w("| read / write, partial writes, multi-beat, simultaneous masters, bank conflicts, request / response backpressure, errors, reset, data integrity | **done** (docs/VERIFICATION.md) |")
w("| error mapping: illegal address, SRAM error, ECC, timeout, unsupported transfer, controller reset, overflow | **done** (docs/ERRORS_AND_RECOVERY.md); ECC injection uses the controller's simulation-only SEU port |")
w("| integration of ControlCore, TensorScratch, VectorScratch, DMA, shared SRAM | **done** in `sf_sram_fabric_top` / `tb_sdf_integ`; isolation of the private partitions and the tensor ownership rule verified |")
w("| AXI4 | **not claimed** |")
w("| **not done** | formal proofs, gate-level simulation of the new RTL, X-propagation, silicon / timing / power data, DW 256 / 512 fabric words, burst pipelining (docs/KNOWN_LIMITATIONS.md) |\n")
w("## Decisions worth knowing\n")
w("1. **Protocol.** The documented DataFabric memory protocol is SFB3 (SFB -> SFB2 -> SFB3). The bridge is an SFB3 target, signal for signal; the only extra port is an informational cause sideband. No second protocol was introduced.")
w("2. **Bursts.** SFB3 carries no burst metadata, so \"burst metadata where supported\" is *not supported on the fabric port*. The burst subset (INCR, byte-granular start / length, partial first / last words, one id per burst, response grouping, rejects before any beat is issued) is a client-side sequencer that emits legal single-beat SFB3 transactions.")
w("3. **Existing adapter.** MemoryCore already contained a single-port `sf_sram_datafabric`; it was audited (`docs/AUDIT.md`) and this module supersedes it with the same name and compatible `t_*` / `c_*` ports (`NTP = 1`).")
w("4. **Private partitions.** The NoC window is limited to a shared part of the aperture (`ALLOW_HI`); the scratchpads' private regions are reachable only from their local ports, so tensor ownership cannot be bypassed from the fabric.")
w("5. **Timing.** `REQ_REG` / `RSP_REG` default to 1; justified by the logic-depth comparison (generic gates, not timing).\n")
w("## Layout\n")
w("| path | content |\n|---|---|")
w("| `rtl/` | new RTL (`sf_sdf_*`, `sf_sram_datafabric`, `sf_sram_fabric_top`) and `sf_sdf_defs.svh` |\n| `third_party/` | reused code, byte identical, SHA-256 manifest, provenance |\n| `tb/` | testbenches |\n| `sim/` | file lists, regression runner |\n| `tools/` | mutation testing, performance sweep / report generators |\n| `syn/` | Yosys scripts and the analysis wrapper |\n| `docs/` | documentation |\n| `reports/` | results of every run (JSON / Markdown / CSV / SVG) |\n| `scripts/` | helpers (`vrun.sh`, `make_zip.sh`, `final_run.sh`) |\n")
open(os.path.join(ROOT, "README.md"), "w").write("\n".join(o))
print("wrote README.md")
