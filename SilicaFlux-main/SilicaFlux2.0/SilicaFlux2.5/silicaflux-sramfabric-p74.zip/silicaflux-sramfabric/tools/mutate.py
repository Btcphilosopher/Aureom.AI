#!/usr/bin/env python3
"""Mutation testing of the SRAMFabric bridge testbench.

Each MUTANT is a single textual change to one RTL file.  The project is copied to build/mut/<name>/, the change is applied, and the
listed regression cases are built and run there.  A mutant is KILLED when at least one case fails (build errors do not count).
A SURVIVING mutant means the testbench cannot see that fault.  Results: reports/mutation.json / reports/mutation.md.

  python3 tools/mutate.py [--only NAME ...] [--jobs 4]
"""
import argparse, json, os, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P = "rtl/sf_sdf_port.sv"
B = "rtl/sf_sdf_burst_seq.sv"
T = "rtl/sf_sram_fabric_top.sv"
X = "rtl/sf_sdf_addr_xlate.sv"
K = "rtl/sf_sdf_skid.sv"
BASE = ["base_dw128"]
WIDE = ["ntp2_np2_dw64", "noc0_direct_dw32_np2"]
ECC = ["ecc_dw128"]

M = []
def mut(name, f, old, new, cases, why, suite="sdf"): M.append(dict(name=name, file=f, old=old, new=new, cases=cases, why=why, suite=suite))

mut("lane_read", P, "if (hd_lane == LANEW'(l)) rword = rline[l*DW +: DW];", "if (hd_lane == LANEW'(l)) rword = rline[((l+1)%(LINE_W/DW))*DW +: DW];",
    ["dw32_lanes"], "read data taken from the wrong lane of the line")
mut("strobe_ignored_narrow", P, "bline[l*SB +: SB] = s_wstrb;", "bline[l*SB +: SB] = {SB{1'b1}};", ["dw32_lanes"], "byte enables ignored (narrow fabric)")
mut("strobe_ignored_wide", P, "assign bline = (LINE_W/8)'(s_wstrb);", "assign bline = {(LINE_W/8){1'b1}};", BASE, "byte enables ignored (128-bit fabric)")
mut("write_lane_shift", P, "wline[l*DW +: DW] = s_wdata;", "wline[((l+1)%(LINE_W/DW))*DW +: DW] = s_wdata;", ["dw32_lanes"], "write data placed on the wrong lane")
mut("ecc_status_lost", P, "else if (rst3 == `SF_ST_ECC_UE)       cause_real = `SDF_CAUSE_ECC;", "else if (rst3 == `SF_ST_ECC_UE)       cause_real = `SDF_CAUSE_NONE;", ECC,
    "uncorrectable ECC error reported as success")
mut("rdata_not_zeroed", P, "(cause_real != `SDF_CAUSE_NONE || rwe || hd_op != OP_READ) ? '0 : rword", "(rwe || hd_op != OP_READ) ? '0 : rword", ECC,
    "stored (uncorrected) data returned with an error")
mut("no_align_check", X, "assign misal = (WB > 0) ? (off[WB-1:0] != '0) : 1'b0;", "assign misal = 1'b0;", ["noalign_chk"], "misaligned beat not rejected")
mut("allow_off_by_one", X, "(off_end <= (AW + 1)'(ALLOW_HI))", "(off_end <= (AW + 1)'(ALLOW_HI + SBYTES))", ["allow_half"], "allowed-range bound off by one beat")
mut("window_not_checked", X, "assign win_hit = ((addr & ~WMASK) == (WIN_BASE & ~WMASK));", "assign win_hit = 1'b1;", ["noc0_direct_dw128"], "window test removed")
mut("port_by_address", P, "wire [NPW-1:0] psel = (NP > 1) ? (NPW'(s_src) + NPW'(s_id)) : '0;", "wire [NPW-1:0] psel = (NP > 1) ? NPW'(s_addr[6]) : '0;", ["np2_dw64"],
    "(src,id) no longer pinned to one controller port: pair order lost")
mut("txq_pop_no_handshake", P, "q_pop[p]       = (c_rsp_valid[p] & c_rsp_ready[p] & ~q_empty[p] & ~orph[p])", "q_pop[p]       = (c_rsp_valid[p] & ~q_empty[p] & ~orph[p])", BASE,
    "queue popped without a response handshake")
mut("flush_no_drain", P, "else if (seen_q || fw_q >= 8'(FLUSH_WAIT)) fsm_q <= q_all_empty ? 2'(FSM_RUN) : 2'(FSM_DRAIN);", "else if (seen_q || fw_q >= 8'(FLUSH_WAIT)) fsm_q <= 2'(FSM_RUN);", WIDE,
    "transactions lost in a flush get no response")
mut("rsp_overwrite", P, "assign rin_ready = ~o_valid | t_rsp_ready;", "assign rin_ready = 1'b1;", BASE, "held response overwritten under back-pressure")
mut("skid_drops_data", K, "main_d <= skid_d;", "main_d <= main_d;", BASE, "skid buffer loses the stalled beat")
mut("bank_stat_wrong", P, "bacc[x_bank] <= bacc[x_bank] + 1'b1;", "bacc[0] <= bacc[0] + 1'b1;", BASE, "per-bank statistic attributes every access to bank 0")
mut("latency_off_by_one", P, "wire [TS_W-1:0]   lat_t = cyc - o_ts;", "wire [TS_W-1:0]   lat_t = cyc - o_ts + 1'b1;", BASE, "latency statistic off by one")
mut("posted_not_written", P, "wire do_wr  = is_wr & ~bad;", "wire do_wr  = is_wr & ~bad & (s_op != OP_WRITE_POSTED);", BASE, "posted writes dropped")
mut("illegal_not_redirected", P, "wire [AW-1:0]  caddr = bad ? {AW{1'b1}} : x_line;", "wire [AW-1:0]  caddr = x_line;", BASE, "illegal request reaches the array address")
mut("no_gate_in_flush", P, "wire        gate = (fsm_q != 2'(FSM_RUN)) | c_flush_i;", "wire        gate = 1'b0;", WIDE, "requests accepted while the controller is flushed / draining")
mut("rsp_id_corrupt", P, "wire [IDW-1:0]      hd_id    = hd[H_ID +: IDW];", "wire [IDW-1:0]      hd_id    = hd[H_ID +: IDW] ^ IDW'(1);", BASE, "response id corrupted")
mut("no_lock_rsp_direct", P, "assign sel = lock_q ? sel_q : pick;", "assign sel = pick;", ["noreg_rsp_np2"], "port lock removed (RSP_REG = 0, held response may change)")
mut("timeout_early", P, "(tcnt == TOW'(TIMEOUT - 1))", "(tcnt == TOW'(TIMEOUT / 2))", ["timeout_recovery"], "timeout fires after half the programmed time")
mut("synth_wrong_cause", P, "dcause_q <= `SDF_CAUSE_TIMEOUT;", "dcause_q <= `SDF_CAUSE_RESET;", ["timeout_recovery"], "timeout recovery reports the wrong cause")
mut("status_all_ok", P, "assign t_rsp_status = (o_cause == `SDF_CAUSE_NONE) ? `SDF_ST_OKAY : `SDF_ST_SLVERR;", "assign t_rsp_status = `SDF_ST_OKAY;", BASE, "errors reported as OKAY")
mut("opcode_echo", P, "assign t_rsp_opcode = o_op;", "assign t_rsp_opcode = `SDF_OP_READ;", BASE, "response opcode not echoed")
mut("bad_op_not_checked", P, "wire bad_op = ~(is_rd | is_wr);", "wire bad_op = 1'b0;", ["noc0_direct_dw128"], "unsupported opcode executed")


BURST = ["dw128", "dw32", "dw64_bnd1024"]
mut("seq_first_mask", B, "if ((WB+1)'(b) < fo) m[b] = 1'b0;", "if ((WB+1)'(b) <= fo) m[b] = 1'b0;", BURST, "first beat strobe drops one valid byte", suite="burst")
mut("seq_last_mask", B, "if ((WB+1)'(b) >= lc) m[b] = 1'b0;", "if ((WB+1)'(b) > lc) m[b] = 1'b0;", BURST, "last beat strobe keeps one byte too many", suite="burst")
mut("seq_nbeats", B, "nbeats_q <= BEATW'((last_ext >> WB) - (a_ext >> WB) + 1'b1);", "nbeats_q <= BEATW'((end_ext >> WB) - (a_ext >> WB) + 1'b1);", BURST, "beat count uses the exclusive end (extra beat when the burst ends on a word boundary)", suite="burst")
mut("seq_addr_step", B, "assign m_req_addr   = base_q + AW'(ib_q) * AW'(SB);", "assign m_req_addr   = base_q + AW'(ib_q) * AW'(SB) + AW'(ib_q[0]);", BURST, "beat address perturbed", suite="burst")
mut("seq_range", B, "wire          out_rng  = (a_ext < LIM_LO) || (end_ext > LIM_HI);", "wire          out_rng  = (a_ext < LIM_LO) || (end_ext > LIM_HI + 1);", BURST, "range check off by one byte", suite="burst")
mut("seq_len_zero", B, "wire          len_zero = (cmd_len == '0);", "wire          len_zero = 1'b0;", BURST, "zero-length burst accepted", suite="burst")
mut("seq_too_long", B, "wire          len_big  = (cmd_len > LENW'(MAX_BYTES));", "wire          len_big  = (cmd_len > LENW'(MAX_BYTES + 1));", BURST, "length limit off by one", suite="burst")
mut("seq_boundary", B, "(((a_ext ^ last_ext) >> $clog2(BOUNDARY)) != '0);", "(((a_ext ^ end_ext) >> $clog2(BOUNDARY)) != '0);", ["dw64_bnd1024", "dw128_bnd256_max1024"], "boundary test uses the exclusive end", suite="burst")
mut("seq_rdfifo_credit", B, "is_rd_q   ? (rdh_w < BEATW'(RD_FIFO)) :", "is_rd_q   ? (rdh_w < BEATW'(RD_FIFO + 1)) :", ["fifo1_out1"], "read credit one too generous: FIFO overflow", suite="burst")
mut("seq_err_first", B, "if (rsp_err && bstat_q == `SDF_BS_OK) begin", "if (rsp_err) begin", BURST, "last error reported instead of the first", suite="burst")
mut("seq_posted_resp", B, "(is_post_q ? 1'b1 :\n              is_rd_q   ? (cb_q == nbeats_q) :", "(is_post_q ? 1'b0 :\n              is_rd_q   ? (cb_q == nbeats_q) :", BURST, "posted write never completes", suite="burst")
mut("seq_wd_early", B, "assign wd_ready     = m_req_valid & m_req_ready & ~is_rd_q;", "assign wd_ready     = m_req_valid & ~is_rd_q;", BURST, "write data consumed before the beat is accepted", suite="burst")
mut("seq_out_credit", B, "(out_w < BEATW'(MAX_OUT));", "(out_w < BEATW'(MAX_OUT + 1));", ["fifo1_out1"], "acknowledged-write credit off by one", suite="burst")
E2E = ["burst_e2e_dw32_2bm"]
mut("e2e_seq_first_mask", B, "if ((WB+1)'(b) < fo) m[b] = 1'b0;", "if ((WB+1)'(b) <= fo) m[b] = 1'b0;", E2E, "first beat strobe drops one valid byte (end-to-end)", suite="sdf")
mut("e2e_seq_nbeats", B, "nbeats_q <= BEATW'((last_ext >> WB) - (a_ext >> WB) + 1'b1);", "nbeats_q <= BEATW'((end_ext >> WB) - (a_ext >> WB) + 1'b1);", E2E, "extra beat on word-aligned ends (end-to-end)", suite="sdf")
mut("e2e_seq_read_data", B, "assign rd_data   = rf_mem[rf_rp][DW+1:2];", "assign rd_data   = rf_mem[rf_rp][DW+1:2] ^ {{(DW-1){1'b0}}, rd_last};", E2E, "last read beat corrupted (end-to-end)", suite="sdf")
mut("seq_read_last", B, "assign rd_last   = (cb_q == nbeats_q - 1'b1);", "assign rd_last   = (cb_q == nbeats_q);", BURST, "rd_last flag wrong", suite="burst")

INTEG = ["dw128"]
mut("integ_no_isolation", T, ".ALLOW_LO(0), .ALLOW_HI(SHARED_BYTES),", ".ALLOW_LO(0), .ALLOW_HI(NB * DEPTH * 16),", INTEG, "private partitions reachable from the NoC", suite="integ")
mut("integ_vec_port_shift", T, "assign vs_req_ready = c_req_ready[NCP +: NPV];", "assign vs_req_ready = c_req_ready[NCP + 1 +: NPV];", INTEG, "vector scratchpad handshake wired to the wrong controller port", suite="integ")
mut("integ_rsp_data_map", T, "assign vs_rsp_rdata = c_rsp_rdata[NCP*LINE_W +: NPV*LINE_W];", "assign vs_rsp_rdata = c_rsp_rdata[0 +: NPV*LINE_W];", INTEG, "vector scratchpad read data taken from the bridge port", suite="integ")

def run(m):
    d = os.path.join(ROOT, "build", "mut", m["name"])
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    for sub in ("rtl", "sim", "tb", "scripts"):
        shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub))
    os.symlink(os.path.join(ROOT, "third_party"), os.path.join(d, "third_party"))
    fp = os.path.join(d, m["file"])
    s = open(fp).read()
    if m["old"] not in s:
        return dict(name=m["name"], status="BAD-MUTANT", why=m["why"])
    open(fp, "w").write(s.replace(m["old"], m["new"], 1))
    p = subprocess.run([sys.executable, "sim/run_regress.py", "--suite", m["suite"], "--only"] + m["cases"] + ["--jobs", "1", "--out", "mut.json"],
                       cwd=d, capture_output=True, text=True)
    try:
        r = json.load(open(os.path.join(d, "mut.json")))
        fails = [c for c in r["cases"] if c["status"] != "PASS"]
        bf = [c for c in fails if c["status"] == "BUILD-FAIL"]
        status = "KILLED" if (fails and not bf) else ("BUILD-FAIL" if bf else "SURVIVED")
        det = [(c["name"], (c.get("detail") or [""])[0][:110]) for c in fails]
    except Exception as e:
        status, det = "ERROR", [str(e)]
    shutil.rmtree(os.path.join(d, "build"), ignore_errors=True)
    return dict(name=m["name"], status=status, why=m["why"], cases=m["cases"], detail=det)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    ms = [m for m in M if not a.only or m["name"] in a.only]
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(run, ms))
    for r in res:
        print(f"{r['status']:10s} {r['name']:26s} {r['why']}", flush=True)
        if r["status"] != "KILLED":
            print("           ", r.get("detail"))
    k = sum(1 for r in res if r["status"] == "KILLED")
    print(f"SUMMARY {k}/{len(res)} mutants killed")
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "mutation.json"), "w"), indent=1)
