#!/bin/bash
# full regression + mutation campaign (what produced reports/regress_*.json and reports/mutation.json)
cd "$(dirname "$0")/.."
make verify-vendored
python3 sim/run_regress.py --suite sdf --jobs 4 --out reports/regress_sdf.json
python3 sim/run_regress.py --suite burst --jobs 4 --out reports/regress_burst.json
python3 sim/run_regress.py --suite integ --jobs 4 --out reports/regress_integ.json
python3 sim/run_regress.py --suite chk --jobs 1 --out reports/regress_chk.json
python3 tools/mutate.py --jobs 4
echo FINAL-RUN-DONE
