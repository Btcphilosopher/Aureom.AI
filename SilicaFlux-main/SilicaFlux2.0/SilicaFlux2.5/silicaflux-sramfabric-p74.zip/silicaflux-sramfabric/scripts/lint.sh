#!/bin/bash
# Lint the NEW RTL with -Wall.  Warnings that point into third_party/ (vendored, byte-identical, not edited here) are listed but do not fail the run.
cd "$(dirname "$0")/.."
mkdir -p build
rc=0
for top in sf_sram_datafabric sf_sdf_burst_seq sf_sram_fabric_top sf_sdf_port; do
  verilator --lint-only -Wall -Wno-DECLFILENAME -Wno-TIMESCALEMOD -Wno-PINCONNECTEMPTY -Wno-SYNCASYNCNET -DSF_ASSERT \
    -f sim/files_rtl.f -f sim/files_noc.f --top-module $top > build/lint_$top.log 2>&1
  new=$(grep -E "^%(Warning|Error)" build/lint_$top.log | grep -v "third_party/" | grep -v "Exiting due" | wc -l)
  old=$(grep -E "^%(Warning|Error)" build/lint_$top.log | grep "third_party/" | wc -l)
  echo "lint $top: $new warning(s) in new RTL, $old in vendored code"
  [ "$new" -ne 0 ] && { grep -E "^%(Warning|Error)" build/lint_$top.log | grep -v "third_party/"; rc=1; }
done
exit $rc
