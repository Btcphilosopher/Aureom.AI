#!/bin/bash
# Pack the project into <parent of the project directory>/silicaflux-sramfabric-p74.zip (no build products, no git metadata).  Does not touch git.
set -e
root="$(cd "$(dirname "$0")/.." && pwd)"
name="$(basename "$root")"
parent="$(dirname "$root")"
out="$parent/silicaflux-sramfabric-p74.zip"
rm -f "$out"
find "$root" -name __pycache__ -prune -exec rm -rf {} \; 2>/dev/null || true
cd "$parent"
zip -qr "$out" "$name" -x "$name/build/*" -x "$name/.git/*"
ls -l "$out"
