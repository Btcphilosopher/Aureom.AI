#!/bin/bash
# usage: scripts/vrun.sh <build-name> <top> <tb.sv> [-Gparam=value ...]
set -e
cd "$(dirname "$0")/.."
name=$1; top=$2; tb=$3; shift 3
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD --assert -DSF_ASSERT -Wno-DECLFILENAME \
  -f sim/files_rtl.f -f sim/files_noc.f $tb --top-module $top -Mdir build/$name -o tb.exe "$@" 2>&1 | grep -E "^%(Error|Warning)" | head -20 || true
build/$name/tb.exe
