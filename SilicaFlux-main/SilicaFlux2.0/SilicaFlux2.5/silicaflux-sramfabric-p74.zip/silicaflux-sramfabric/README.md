# SilicaFlux SRAMFabric - DataFabric (SFB3) to banked-SRAM bridge

Project 74 | Aureom.AI | SilicaFlux Semiconductor Systems | SystemVerilog + Python tooling + Verilator / Yosys flows

> **Read first.** This package contains **no silicon data**: every number is an RTL-simulation cycle count (Verilator 5.020), a Yosys 0.33 generic-gate indicator, or a parameter. It is **not AXI4** and claims nothing of the kind. The bridge speaks the **documented DataFabric protocol (SFB3) unchanged**; SFB3 has no burst fields, so bursts are a client-side sequencer. Formal proofs were not run. See `docs/KNOWN_LIMITATIONS.md`. Nothing was committed to git; this package was produced as a ZIP as requested.

## What this is

`sf_sram_datafabric` is an SFB3 **target** that connects the SilicaFlux DataFabric NoC to the existing `sf_sram_controller` and its banks:

```
DataFabric Request -> Protocol Adapter -> Address Decode -> SRAMController -> Banked SRAM -> Response Adapter -> DataFabric Response
```

It converts byte-addressed single-beat transactions (read / write / posted write, byte enables, ids, `ready/valid`) to 128-bit line accesses with lane steering, translates the unified SRAM window (reusing the ControlCore DEVMEM window at `0x2000_0000`) to word / bank / row, rejects illegal addresses, alignment, opcodes and out-of-range bursts without side effects, maps every error to a documented SFB3 status plus a cause sideband, recovers from controller flush / reset and timeouts (exactly one response per accepted request), and records latency, bytes, occupancy, bank conflicts and stalls. `sf_sdf_burst_seq` adds the burst subset (partial first / last words, response grouping, backpressure); `sf_sram_fabric_top` connects ControlCore, DMA, vector / tensor hosts, VectorScratch, TensorScratch and the shared SRAM.

## Quick start

```bash
make lint            # Verilator lint of the new RTL
make regress         # 4 suites, every case builds and runs under Verilator 5.x
make perf            # performance sweep -> reports/PERFORMANCE.md
make syn             # Yosys generic-gate synthesis + logic-depth analysis -> reports/timing_depth.md
make mutate          # mutation testing of the testbenches
```

Needs `verilator >= 5.020`, `yosys` (0.33 tested), `python3`. Build products go to `build/` (safe to delete); `reports/` holds the committed results.

## Results at a glance (generated from `reports/`; all RTL simulation)

| area | result | source |
|---|---|---|
| regression | **53/53 cases pass, 17,438,382 self-checks** (bridge behind the real SFB3 NoC and direct: 35/35; burst sequencer unit: 10/10; integration: 7/7; assertion-monitor self-test: 1/1) | `reports/regress_*.json`, `docs/VERIFICATION.md` |
| mutation testing | **46 of 46** injected faults killed by the testbenches | `reports/mutation.json` |
| latency (unloaded, RTL sim) | `REQ_REG + RSP_REG + READ_LATENCY + 1` cycles, measured equal in all 12 combinations: 2 cycles with no bridge registers, **4 with the default registered boundaries** (RL = 1), 5 with ECC; the crossbar adds 0 | `reports/PERFORMANCE.md` sec. 2 |
| throughput (RTL sim) | one target port: 15.96 B/cycle at DW = 128 (one beat per cycle, the port limit); 40.63 B/cycle (random read/write mix) with 4 target ports and 5 masters; bursts 10.4 B/cycle (4 KiB, one burst in flight), utilisation 100 % aligned / 98 % unaligned | `reports/PERFORMANCE.md` sec. 3, 4, 8 |
| logic depth (Yosys generic gates, **not timing**) | request cone: 13 gates without the input register vs 1 with it; response cone: 28 without the response register vs 2 with it | `reports/timing_depth.md` |
| size | 1,969 lines of new RTL, 3,086 lines of testbench | |

## Deliverables (as requested)

| requested | where |
|---|---|
| `sf_sram_datafabric.sv` | `rtl/sf_sram_datafabric.sv` (top, `NTP` target ports, register page) |
| protocol adapter modules | `rtl/sf_sdf_port.sv` (request + response adapters, lane steering, status map, recovery), `rtl/sf_sdf_burst_seq.sv` |
| address translation | `rtl/sf_sdf_addr_xlate.sv`, `docs/MEMORY_MAP.md` |
| transaction buffers | `rtl/sf_sdf_skid.sv` (registered-ready request buffer), `rtl/sf_sdf_txq.sv` (outstanding-transaction queues), read FIFO inside `sf_sdf_burst_seq` |
| assertions | embedded `SF_CHK` checks in `sf_sdf_port` (`-DSF_ASSERT`), `rtl/sf_sdf_tgt_chk.sv` (SFB3 R2 / R4 / R5 monitor, self-tested), vendored `sfn_protocol_checker` on every port |
| tests | `tb/tb_sdf.sv`, `tb/tb_sdf_burst.sv`, `tb/tb_sdf_integ.sv`, `tb/tb_sdf_perf.sv`, `tb/tb_sdf_chk_selftest.sv`; `sim/run_regress.py`; `tools/mutate.py` |
| memory map documentation | `docs/MEMORY_MAP.md` |
| performance report | `reports/PERFORMANCE.md` (+ `perf.csv`, `perf_raw.json`, SVG charts), `reports/timing_depth.md`, `reports/synthesis.md` |
| integration | `rtl/sf_sram_fabric_top.sv` (ControlCore, DMA, hosts on the NoC; VectorScratch and TensorScratch on direct local ports; one shared controller) |
| documents | `docs/AUDIT.md`, `docs/PROTOCOL_MAPPING.md`, `docs/ERRORS_AND_RECOVERY.md`, `docs/BURSTS.md`, `docs/ARCHITECTURE.md`, `docs/VERIFICATION.md`, `docs/KNOWN_LIMITATIONS.md` |

## Definition of done - status

| requirement | status |
|---|---|
| a real DataFabric master issues a transaction, accesses banked SRAM and receives a correctly tagged response with no loss or duplication | **done**: masters on the real `silicaflux_noc` crossbar; end-to-end scoreboards check exactly-once, id / src / opcode echo, status, cause and data; physical byte placement in the bank arrays checked by backdoor |
| single-word requests first, verified bursts after | **done in that order**: phase 1 (single word) was regressed and mutation-tested before `sf_sdf_burst_seq` was written |
| read / write, partial writes, multi-beat, simultaneous masters, bank conflicts, request / response backpressure, errors, reset, data integrity | **done** (docs/VERIFICATION.md) |
| error mapping: illegal address, SRAM error, ECC, timeout, unsupported transfer, controller reset, overflow | **done** (docs/ERRORS_AND_RECOVERY.md); ECC injection uses the controller's simulation-only SEU port |
| integration of ControlCore, TensorScratch, VectorScratch, DMA, shared SRAM | **done** in `sf_sram_fabric_top` / `tb_sdf_integ`; isolation of the private partitions and the tensor ownership rule verified |
| AXI4 | **not claimed** |
| **not done** | formal proofs, gate-level simulation of the new RTL, X-propagation, silicon / timing / power data, DW 256 / 512 fabric words, burst pipelining (docs/KNOWN_LIMITATIONS.md) |

## Decisions worth knowing

1. **Protocol.** The documented DataFabric memory protocol is SFB3 (SFB -> SFB2 -> SFB3). The bridge is an SFB3 target, signal for signal; the only extra port is an informational cause sideband. No second protocol was introduced.
2. **Bursts.** SFB3 carries no burst metadata, so "burst metadata where supported" is *not supported on the fabric port*. The burst subset (INCR, byte-granular start / length, partial first / last words, one id per burst, response grouping, rejects before any beat is issued) is a client-side sequencer that emits legal single-beat SFB3 transactions.
3. **Existing adapter.** MemoryCore already contained a single-port `sf_sram_datafabric`; it was audited (`docs/AUDIT.md`) and this module supersedes it with the same name and compatible `t_*` / `c_*` ports (`NTP = 1`).
4. **Private partitions.** The NoC window is limited to a shared part of the aperture (`ALLOW_HI`); the scratchpads' private regions are reachable only from their local ports, so tensor ownership cannot be bypassed from the fabric.
5. **Timing.** `REQ_REG` / `RSP_REG` default to 1; justified by the logic-depth comparison (generic gates, not timing).

## Layout

| path | content |
|---|---|
| `rtl/` | new RTL (`sf_sdf_*`, `sf_sram_datafabric`, `sf_sram_fabric_top`) and `sf_sdf_defs.svh` |
| `third_party/` | reused code, byte identical, SHA-256 manifest, provenance |
| `tb/` | testbenches |
| `sim/` | file lists, regression runner |
| `tools/` | mutation testing, performance sweep / report generators |
| `syn/` | Yosys scripts and the analysis wrapper |
| `docs/` | documentation |
| `reports/` | results of every run (JSON / Markdown / CSV / SVG) |
| `scripts/` | helpers (`vrun.sh`, `make_zip.sh`, `final_run.sh`) |
