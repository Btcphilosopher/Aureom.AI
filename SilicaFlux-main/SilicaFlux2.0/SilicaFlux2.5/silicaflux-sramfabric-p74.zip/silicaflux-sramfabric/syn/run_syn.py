#!/usr/bin/env python3
"""Yosys 0.33 generic-gate synthesis + logic-depth (`ltp`) analysis of the bridge and of bridge + controller.
No PDK, no timing: `depth` is the number of generic gates (AND/NAND/OR/NOR/XOR/XNOR/MUX/NOT) on the longest combinational path
(flip-flops are path boundaries).  It is a RELATIVE indicator used to justify the registered boundaries, not a delay.
  python3 syn/run_syn.py          -> reports/synthesis.md, reports/timing_depth.md, reports/synthesis.json
"""
import json, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = ["rtl/sf_sdf_skid.sv", "rtl/sf_sdf_txq.sv", "rtl/sf_sdf_addr_xlate.sv", "rtl/sf_sdf_port.sv", "rtl/sf_sram_datafabric.sv",
       "rtl/sf_sdf_burst_seq.sv"]
CTL = ["third_party/memorycore/rtl/sf_sram_core.sv", "third_party/memorycore/rtl/backends/sf_sram_fpga_bram.sv",
       "third_party/memorycore/rtl/backends/sf_sram_asic_sky130.sv", "third_party/memorycore/rtl/sf_sram_macro_wrapper.sv",
       "third_party/memorycore/rtl/sf_ecc_enc.sv", "third_party/memorycore/rtl/sf_ecc_dec.sv", "third_party/memorycore/rtl/sf_ecc_counters.sv",
       "third_party/memorycore/rtl/sf_sram_bank.sv", "third_party/memorycore/rtl/sf_sram_controller.sv",
       "third_party/ras_secded/sfras_secded_enc.sv", "third_party/ras_secded/sfras_secded_dec.sv"]
INC = "-I rtl -I third_party/memorycore/rtl -I third_party/ras_secded -I third_party/sramlib_mbist"
GATES = "AND,NAND,OR,NOR,XOR,XNOR,MUX"


FFS = ["$_DFF_P_", "$_DFF_N_", "$_DFF_PN0_", "$_DFF_PN1_", "$_DFFE_PP_", "$_DFFE_PN0P_", "$_DFFE_PN1P_", "$_SDFF_PN0_", "$_SDFF_PP0_", "$_SDFF_PN1_",
       "$_SDFFE_PN0P_", "$_SDFFE_PP0P_", "$_SDFFCE_PN0P_", "$_SDFFCE_PP0P_", "$_DFFE_PN0N_", "$_DFFE_PP0P_"]


def ys(name, files, top, params, cone=None):
    script = f"""read_verilog -sv {INC} {' '.join(files)}
{''.join(f'chparam -set {k} {v} {top}' + chr(10) for k, v in params.items())}hierarchy -top {top}
proc; flatten; opt -fast; memory -nomap; opt -fast
techmap; opt -fast
abc -g {GATES}
opt_clean
stat
{('select -set cone ' + cone + ' %ci*' + ''.join(':-' + t + '[Q]' for t in FFS) + chr(10) + 'ltp @cone') if cone else 'ltp -noff'}
"""
    sf = os.path.join(ROOT, "build", f"syn_{name}.ys")
    os.makedirs(os.path.dirname(sf), exist_ok=True)
    open(sf, "w").write(script)
    p = subprocess.run(["yosys", "-q", "-l", os.path.join(ROOT, "build", f"syn_{name}.log"), sf], cwd=ROOT, capture_output=True, text=True)
    log = open(os.path.join(ROOT, "build", f"syn_{name}.log")).read()
    m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", log)
    cells = re.search(r"Number of cells:\s+(\d+)", log) or re.search(r"\n\s+(\d+)\s+cells", log)
    ff = sum(int(x) for x in re.findall(r"\$_(?:DFF|SDFF|DFFE|SDFFE|ADFF|ADFFE|DLATCH)\w*_\s*\n?", log) ) if False else None
    dff = re.findall(r"\s(\d+)\s+\$_(?:S?DFF\w*|ADFF\w*)_", log)
    return dict(name=name, depth=int(m.group(1)) if m else None, cells=int(cells.group(1)) if cells else None, ffs=sum(int(x) for x in dff),
                rc=p.returncode, err=(p.stderr or "")[-300:])


def main():
    jobs = []
    # ---- bridge alone, area-ish counts (generic gates)
    for rq in (0, 1):
        for rs in (0, 1):
            jobs.append(("port", f"port_req{rq}_rsp{rs}", SRC, "sf_sdf_port", dict(REQ_REG=rq, RSP_REG=rs), None))
    jobs.append(("port", "port_dw32_np2", SRC, "sf_sdf_port", dict(DW=32, NP=2), None))
    jobs.append(("port", "port_dw128_np1_txq8", SRC, "sf_sdf_port", dict(DW=128, NP=1, TXQ_DEPTH=8), None))
    jobs.append(("port", "port_to1024", SRC, "sf_sdf_port", dict(TIMEOUT=1024), None))
    jobs.append(("seq", "burst_seq_dw128", SRC, "sf_sdf_burst_seq", dict(DW=128), None))
    jobs.append(("seq", "burst_seq_dw32", SRC, "sf_sdf_burst_seq", dict(DW=32), None))
    jobs.append(("xlate", "xlate_dw128", SRC, "sf_sdf_addr_xlate", dict(DW=128), None))
    # ---- bridge + controller: depth of each cone for the pipeline choices
    cones = {0: ("req", "o:o_req_ready"), 1: ("rsp", "o:o_rsp_*"), 2: ("creq", "o:o_c_req_*")}
    for rq in (0, 1):
        for rs in (0, 1):
            for cone, (nm, sel) in cones.items():
                jobs.append(("wrap", f"wrap_{nm}_req{rq}_rsp{rs}", SRC + CTL + ["syn/sf_sdf_syn_wrap.sv"], "sf_sdf_syn_wrap",
                             dict(OUTSEL=cone, REQ_REG=rq, RSP_REG=rs), sel))
    with ThreadPoolExecutor(max_workers=4) as ex:
        res = list(ex.map(lambda j: dict(kind=j[0], **ys(j[1], j[2], j[3], j[4], j[5]), params=j[4]), jobs))
    json.dump(res, open(os.path.join(ROOT, "reports", "synthesis.json"), "w"), indent=1)
    for r in res:
        print(f"{r['name']:26s} depth={r['depth']} cells={r['cells']} ffs={r['ffs']} rc={r['rc']} {r['err'] if r['rc'] else ''}")


if __name__ == "__main__":
    main()
