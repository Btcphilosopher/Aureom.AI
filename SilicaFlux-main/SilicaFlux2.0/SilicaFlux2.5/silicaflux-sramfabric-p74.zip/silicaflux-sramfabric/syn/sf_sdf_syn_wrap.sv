// =============================================================================
// SYNTHESIS-ONLY wrapper (Yosys logic-depth analysis; never part of a design): bridge + SRAM controller, one target port.
// OUTSEL selects which bridge output cone is kept so that `ltp` reports the longest combinational path of THAT cone:
//   0 request cone  : t_req_ready            (fabric request path through the controller's grant logic)
//   1 response cone : t_rsp_valid / status / rdata / id
//   2 controller request cone : c_req_* (what the bridge drives into the controller)
//   3 everything
// =============================================================================
`include "sf_sram_defs.svh"
`include "sf_sdf_defs.svh"
module sf_sdf_syn_wrap #(
  parameter int OUTSEL = 3, parameter int REQ_REG = 1, parameter int RSP_REG = 1, parameter int DW = 128, parameter int NP = 1,
  parameter int NB = 4, parameter int DEPTH = 64, parameter int NM = 4, parameter int IDW = 2, parameter int NSLOT = 8,
  parameter int ECC_EN = 0, parameter int READ_LATENCY = 1,
  parameter int SRCW = 2, parameter int SB = DW / 8, parameter int LANEW = (DW < 128) ? $clog2(128 / DW) : 1,
  parameter int IDC = 3 + SRCW + IDW + LANEW + 1
) (
  input  wire logic clk, input wire logic rst_n,
  input  wire logic t_req_valid, output logic o_req_ready,
  input  wire logic [2:0] t_req_opcode, input wire logic [SRCW-1:0] t_req_src, input wire logic [IDW-1:0] t_req_id,
  input  wire logic [31:0] t_req_addr, input wire logic [DW-1:0] t_req_wdata, input wire logic [SB-1:0] t_req_wstrb,
  output logic o_rsp_valid, input wire logic t_rsp_ready, output logic [DW-1:0] o_rsp_rdata, output logic [1:0] o_rsp_status,
  output logic [IDW-1:0] o_rsp_id,
  output logic [NP-1:0] o_c_req_valid, output logic [31:0] o_c_req_addr, output logic [127:0] o_c_req_wdata, output logic [15:0] o_c_req_be
);
  logic t_req_ready, t_rsp_valid;
  logic [SRCW-1:0] t_rsp_src; logic [IDW-1:0] t_rsp_id; logic [2:0] t_rsp_opcode; logic [1:0] t_rsp_status; logic [DW-1:0] t_rsp_rdata;
  logic [NP-1:0] c_req_valid, c_req_ready, c_req_we, c_rsp_valid, c_rsp_ready, c_rsp_we, c_rsp_ce;
  logic [NP*32-1:0] c_req_addr; logic [NP*128-1:0] c_req_wdata, c_rsp_rdata; logic [NP*16-1:0] c_req_be;
  logic [NP*IDC-1:0] c_req_id, c_rsp_id; logic [NP*3-1:0] c_rsp_status;
  logic c_flush_o, flush_busy;
  /* verilator lint_off PINMISSING */
  sf_sram_datafabric #(.NM(NM), .AW(32), .DW(DW), .IDW(IDW), .NTP(1), .NP(NP), .NB(NB), .DEPTH(DEPTH), .REQ_REG(REQ_REG), .RSP_REG(RSP_REG),
                       .CTRL_NSLOT(NSLOT), .TXQ_DEPTH(NSLOT), .TIMEOUT(0)) u_br (
    .clk, .rst_n, .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos(3'd0), .t_req_addr, .t_req_wdata, .t_req_wstrb,
    .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata, .rsp_cause_o(),
    .c_req_valid, .c_req_ready, .c_req_we, .c_req_addr, .c_req_wdata, .c_req_be, .c_req_id, .c_rsp_valid, .c_rsp_ready, .c_rsp_rdata, .c_rsp_id,
    .c_rsp_we, .c_rsp_status, .c_rsp_ce, .c_flush_i(flush_busy), .c_flush_o, .err_clr_i(1'b0), .rb_sel(1'b0), .rb_we(1'b0), .rb_addr(8'd0), .rb_wdata(32'd0));
  sf_sram_controller #(.NM(NP), .NB(NB), .DEPTH(DEPTH), .DW(128), .AW(32), .IDW(IDC), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN), .NSLOT(NSLOT),
                       .ARB(`SF_ARB_RR), .ALIGN_MODE(1), .INIT_ON_RESET(ECC_EN), .SIM_INIT(1), .FAULT_INJECT(0)) u_ctl (
    .clk, .rst_n, .m_req_valid(c_req_valid), .m_req_ready(c_req_ready), .m_req_we(c_req_we), .m_req_addr(c_req_addr), .m_req_wdata(c_req_wdata),
    .m_req_be(c_req_be), .m_req_id(c_req_id), .m_rsp_valid(c_rsp_valid), .m_rsp_ready(c_rsp_ready), .m_rsp_rdata(c_rsp_rdata), .m_rsp_id(c_rsp_id),
    .m_rsp_we(c_rsp_we), .m_rsp_status(c_rsp_status), .m_rsp_ce(c_rsp_ce), .flush_i(c_flush_o), .flush_busy_o(flush_busy), .quiesce_i(1'b0),
    .init_start_i(1'b0), .scrub_en_i(1'b0), .ecc_clr_i(1'b0), .tst_active_i(1'b0), .tst_sel_i('0), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i('0),
    .tst_wdata_i('0), .fi_bank('0), .fi_type(4'd0), .fi_row('0), .fi_row2('0), .fi_bit('0), .fi_bit2('0), .fi_val(1'b0), .fi_val2(1'b0),
    .seu_pulse(1'b0), .seu_row('0), .seu_mask('0));
  /* verilator lint_on PINMISSING */
  assign o_req_ready   = (OUTSEL == 0 || OUTSEL == 3) ? t_req_ready : 1'b0;
  assign o_rsp_valid   = (OUTSEL == 1 || OUTSEL == 3) ? t_rsp_valid : 1'b0;
  assign o_rsp_rdata   = (OUTSEL == 1 || OUTSEL == 3) ? t_rsp_rdata : '0;
  assign o_rsp_status  = (OUTSEL == 1 || OUTSEL == 3) ? t_rsp_status : '0;
  assign o_rsp_id      = (OUTSEL == 1 || OUTSEL == 3) ? t_rsp_id : '0;
  assign o_c_req_valid = (OUTSEL == 2 || OUTSEL == 3) ? c_req_valid : '0;
  assign o_c_req_addr  = (OUTSEL == 2 || OUTSEL == 3) ? c_req_addr[31:0] : '0;
  assign o_c_req_wdata = (OUTSEL == 2 || OUTSEL == 3) ? c_req_wdata[127:0] : '0;
  assign o_c_req_be    = (OUTSEL == 2 || OUTSEL == 3) ? c_req_be[15:0] : '0;
endmodule
