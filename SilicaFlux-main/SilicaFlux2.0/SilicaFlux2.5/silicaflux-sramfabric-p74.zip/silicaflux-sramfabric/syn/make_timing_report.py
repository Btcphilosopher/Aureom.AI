#!/usr/bin/env python3
"""reports/timing_depth.md and reports/synthesis.md from reports/synthesis.json (written by syn/run_syn.py)."""
import json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
res = json.load(open(os.path.join(ROOT, "reports", "synthesis.json")))
by = {r["name"]: r for r in res}
o = []
w = o.append
w("# TIMING JUSTIFICATION FOR THE REGISTERED BOUNDARIES (logic depth, Yosys 0.33 generic gates)\n")
w("> **Not a timing result.** No PDK, no STA, no wire model. `depth` = number of generic gates (AND / NAND / OR / NOR / XOR / XNOR / MUX / NOT cells after `abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX`) on the longest combinational path of the cone; flip-flops are path "
  "boundaries. It is a relative indicator of how much logic sits between two registers, used to decide whether a pipeline register is justified. Reproduce: `make syn`.\n")
w("Cones of the **bridge + SRAM controller** (one target port, `NB = 4`, `DEPTH = 64`, `NSLOT = 8`, `DW = 128`, `NP = 1`), measured by keeping only one output cone of `syn/sf_sdf_syn_wrap.sv`:\n")
w("| `REQ_REG` | `RSP_REG` | request cone: input -> `t_req_ready` | response cone: inputs -> `t_rsp_*` | bridge -> controller cone: inputs -> `c_req_*` |")
w("|---|---|---|---|---|")
for rq in (0, 1):
    for rs in (0, 1):
        a = by.get(f"wrap_req_req{rq}_rsp{rs}", {}).get("depth")
        b = by.get(f"wrap_rsp_req{rq}_rsp{rs}", {}).get("depth")
        c = by.get(f"wrap_creq_req{rq}_rsp{rs}", {}).get("depth")
        w(f"| {rq} | {rs} | {a} | {b} | {c} |")
w("")
w("Reading: the request cone is the path from the fabric request (`t_req_valid`, address, ids) through the bridge decode, the controller's decode and per-bank grant logic, and back to `t_req_ready`. "
  "With `REQ_REG = 1` it ends at the skid buffer's registered ready (depth 1-2); with `REQ_REG = 0` the controller grant logic is in the fabric's request path. The response cone is the path from controller response "
  "and the transaction queue head to the SFB3 response; `RSP_REG = 1` ends it at the response register. The default `REQ_REG = RSP_REG = 1` therefore trades 2 cycles of latency (measured, reports/PERFORMANCE.md) for the shortest "
  "combinational cones and for the flush-safe response (R4). Both registers are full-throughput stages (no throughput loss, measured).\n")
w("## Longest path inside the bridge slice alone (`sf_sdf_port`, controller ports are boundary ports)\n")
w("| configuration | longest path (gates) | cells | flip-flops |\n|---|---|---|---|")
for k in ("port_req0_rsp0", "port_req1_rsp0", "port_req0_rsp1", "port_req1_rsp1", "port_dw32_np2", "port_to1024"):
    r = by.get(k)
    if r:
        w(f"| {k} | {r['depth']} | {r['cells']} | {r['ffs']} |")
w("")
open(os.path.join(ROOT, "reports", "timing_depth.md"), "w").write("\n".join(o) + "\n")

o = []
w = o.append
w("# SYNTHESIS (Yosys 0.33, generic gates; no PDK, no timing, no area in um^2)\n")
w("All numbers are Yosys cell / flip-flop counts after `proc; flatten; memory -nomap; techmap; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX`. They are a size indicator only. Memories (`pc`, `bacc`, ... turned into registers by Yosys; the transaction-queue arrays) are counted as flip-flops where Yosys maps them to registers.\n")
w("| module / configuration | cells | flip-flops | longest comb path (gates) | return code |\n|---|---|---|---|---|")
for r in res:
    if r["kind"] in ("port", "seq", "xlate"):
        w(f"| {r['name']} | {r['cells']} | {r['ffs']} | {r['depth']} | {r['rc']} |")
w("\nEvery configuration synthesizes (return code 0). `sf_sdf_tgt_chk`, the testbenches and `syn/sf_sdf_syn_wrap.sv` are verification / analysis only and are not synthesizable.\n")
open(os.path.join(ROOT, "reports", "synthesis.md"), "w").write("\n".join(o) + "\n")
print("wrote reports/timing_depth.md reports/synthesis.md")
