// =============================================================================
// SilicaFlux SRAMFabric (P74) :: tb_sdf_integ -- the shared-SRAM subsystem as a system (sf_sram_fabric_top)
//
//   M0 ControlCore (single words, blocking tasks)   M1 DMA = sf_sdf_burst_seq (byte bursts)
//   M2 / M3 VectorTile / TensorCore hosts (random single-beat agents, private shared sub-regions)
//   direct local ports: VectorScratch (sub-word / vector / DMA) and TensorScratch (ownership FSM, A/B/C/DMA ports)
// all on ONE sf_sram_controller behind the real SFB3 NoC and the bridge.
//
// What is checked (each against golden data that the testbench computes itself):
//   I1  DMA burst write (unaligned) -> VectorScratch direct reads of the same bytes        [NoC write -> direct read]
//   I2  VectorScratch direct writes -> ControlCore single-word reads + DMA burst read      [direct write -> NoC read]
//   I3  isolation: NoC accesses to the private (vector / tensor) partition answer ST_SLVERR / cause ADDR, no side effect
//   I4  tensor flow: DMA burst reads tiles from the shared SRAM, filled into TensorScratch, computed through the A/B/C ports
//       (C = A + B per byte), drained, DMA burst writes C back, ControlCore verifies           [every path of the memory map]
//   I5  concurrency: DMA bursts, two host agents, vector agent and tensor flows at the same time, each in its own region
// Memory-map partition (byte offsets in the controller aperture; NoC window offset == aperture offset):
//   [0x0000,0x2000) shared (NoC visible)   [0x2000,0x2800) vector private   [0x2800, ...) tensor tiles private
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`include "sf_sdf_defs.svh"

module tb_sdf_integ #(
  parameter int DW = 128,
  parameter int NB = 4,
  parameter int DEPTH = 256,
  parameter int READ_LATENCY = 1,
  parameter int ECC_EN = 0,
  parameter int NTP = 1,
  parameter int NP = 1,
  parameter int REQ_REG = 1,
  parameter int RSP_REG = 1,
  parameter int I5_CYCLES = 6000,
  parameter int SEED = 32'h51C0DE
);
  localparam int AW = 32, NM = 4, IDW = 2, SB = DW / 8, WB = $clog2(SB), LINE_W = 128;
  localparam int WIN_LOG2 = 20;
  localparam logic [AW-1:0] SRAM_BASE = 32'h2000_0000;
  localparam int CAP = NB * DEPTH * 16;
  localparam int SHARED = 8192;
  localparam int V_BASE = 8192, V_SIZE = 2048;
  localparam int T_BASE_LINE = 640;                         // byte 10240
  localparam int TEN_ROWS = 4, TEN_NBUF = 2;
  localparam int BUFW = 1, TRW = 2, TLW = 2;
  localparam int MAXB = 256;
  localparam int BLW = $clog2(MAXB + 1) + 1;
  localparam int BBW = $clog2(MAXB / SB + 2) + 1;
  // shared sub-regions
  localparam int R_CC = 'h0000, R_SRC = 'h0400, R_RES = 'h1400, R_TA = 'h1600, R_TB = 'h1700, R_TC = 'h1800,
                 R_H2 = 'h1A00, R_H3 = 'h1C00, R_DMA2 = 'h0E00;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  `include "sfn_tb_common.svh"
  int errors = 0, checks = 0, tests = 0;
  task automatic check(input logic cond, input string msg);
    begin checks++; if (!cond) begin errors++; if (errors <= 25) $display("[FAIL] t=%0t %s", $time, msg); end end
  endtask

  // ---------------------------------------------------------------- NoC masters
  logic [NM-1:0]      m_req_valid, m_req_ready, m_rsp_valid, m_rsp_ready;
  logic [NM*3-1:0]    m_req_opcode, m_rsp_opcode, m_req_qos;
  logic [NM*IDW-1:0]  m_req_id, m_rsp_id;
  logic [NM*AW-1:0]   m_req_addr;
  logic [NM*DW-1:0]   m_req_wdata, m_rsp_rdata;
  logic [NM*SB-1:0]   m_req_wstrb;
  logic [NM*2-1:0]    m_rsp_status;
  // M0 ControlCore
  logic               cc_v = 1'b0;
  logic [2:0]         cc_op = '0;
  logic [AW-1:0]      cc_addr = '0;
  logic [DW-1:0]      cc_wd = '0;
  logic [SB-1:0]      cc_ws = '0;
  // M1 DMA (burst sequencer outputs)
  logic               dma_v;
  logic [2:0]         dma_op, dma_qos;
  logic [IDW-1:0]     dma_id;
  logic [AW-1:0]      dma_addr;
  logic [DW-1:0]      dma_wd;
  logic [SB-1:0]      dma_ws;
  logic               dma_rsp_ready;
  // M2 / M3 hosts
  logic [1:0]         h_v = '0;
  logic [2*3-1:0]     h_op = '0;
  logic [2*AW-1:0]    h_addr = '0;
  logic [2*DW-1:0]    h_wd = '0;
  logic [2*SB-1:0]    h_ws = '0;
  logic [1:0]         h_rsp_ready = 2'b11;
  assign m_req_valid  = {h_v[1], h_v[0], dma_v, cc_v};
  assign m_req_opcode = {h_op[5:3], h_op[2:0], dma_op, cc_op};
  assign m_req_id     = {IDW'(1), IDW'(1), dma_id, IDW'(0)};
  assign m_req_qos    = {3'd1, 3'd2, dma_qos, 3'd3};
  assign m_req_addr   = {h_addr[AW +: AW], h_addr[0 +: AW], dma_addr, cc_addr};
  assign m_req_wdata  = {h_wd[DW +: DW], h_wd[0 +: DW], dma_wd, cc_wd};
  assign m_req_wstrb  = {h_ws[SB +: SB], h_ws[0 +: SB], dma_ws, cc_ws};
  assign m_rsp_ready  = {h_rsp_ready, dma_rsp_ready, 1'b1};

  // ---------------------------------------------------------------- local ports
  logic               v_req_valid = 1'b0, v_req_ready, v_req_we = 1'b0, v_req_sext = 1'b0;
  logic [AW-1:0]      v_req_addr = '0;
  logic [2:0]         v_req_size = '0;
  logic [127:0]       v_req_wdata = '0;
  logic [3:0]         v_req_id = '0;
  logic               v_rsp_valid, v_rsp_we;
  logic [127:0]       v_rsp_rdata;
  logic [3:0]         v_rsp_id;
  logic [2:0]         v_rsp_status;
  logic               v_rsp_ready = 1'b1;
  logic               t_fill_req = 1'b0, t_fill_done = 1'b0, t_fill_grant, t_te_req = 1'b0, t_te_done = 1'b0, t_te_owned,
                      t_drain_req = 1'b0, t_drain_done = 1'b0, t_drain_grant;
  logic [BUFW-1:0]    t_fill_buf, t_te_buf, t_drain_buf;
  logic [TEN_NBUF*3-1:0] t_buf_state;
  logic               ta_v = 1'b0, ta_rdy, ta_rsp_v, tb_v = 1'b0, tb_rdy, tb_rsp_v, tc_v = 1'b0, tc_rdy, tc_rsp_v, tc_we = 1'b0, tc_rsp_we;
  logic [TRW-1:0]     ta_row = '0, tb_row = '0, tc_row = '0;
  logic [127:0]       ta_data, tb_data, tc_data, tc_wd = '0;
  logic [2:0]         ta_st, tb_st, tc_st;
  logic [15:0]        tc_be = '0;
  logic               td_v = 1'b0, td_rdy, td_we = 1'b0, td_rsp_v, td_rsp_we;
  logic [1:0]         td_region = '0;
  logic [BUFW-1:0]    td_buf = '0;
  logic [TLW-1:0]     td_line = '0;
  logic [127:0]       td_wd = '0, td_data;
  logic [15:0]        td_be = '0;
  logic [2:0]         td_st;
  logic               irq;
  logic [NTP-1:0]     err_sticky;
  logic [NTP*`SDF_NPERF*32-1:0] perf;
  logic [NTP*NB*32-1:0] bank_acc, bank_stall;
  logic [NB*32-1:0]   ctl_conf;
  logic [(NTP*NP+2+4)*32-1:0] ctl_stall;
  logic [31:0]        rb_rdata;
  logic               rb_err;
  logic               flush = 1'b0;
  logic               vdma_busy, vdma_done, vdma_err, vdma_in_ready, vdma_out_valid;
  logic [127:0]       vdma_out_data;

  sf_sram_fabric_top #(
    .NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .NTP(NTP), .NP(NP), .NB(NB), .DEPTH(DEPTH), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN),
    .NSLOT(8), .SRAM_BASE(SRAM_BASE), .WIN_LOG2(WIN_LOG2), .SHARED_BYTES(SHARED), .VEC_LINES(1), .TEN_BASE_LINE(T_BASE_LINE),
    .TEN_NBUF(TEN_NBUF), .TEN_ROWS(TEN_ROWS), .REQ_REG(REQ_REG), .RSP_REG(RSP_REG), .TIMEOUT(2048)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_opcode(m_req_opcode), .m_req_id(m_req_id), .m_req_qos(m_req_qos),
    .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_id(m_rsp_id), .m_rsp_opcode(m_rsp_opcode),
    .m_rsp_status(m_rsp_status), .m_rsp_rdata(m_rsp_rdata),
    .v_req_valid(v_req_valid), .v_req_ready(v_req_ready), .v_req_we(v_req_we), .v_req_addr(v_req_addr), .v_req_size(v_req_size),
    .v_req_sext(v_req_sext), .v_req_wdata(v_req_wdata), .v_req_id(v_req_id), .v_rsp_valid(v_rsp_valid), .v_rsp_ready(v_rsp_ready),
    .v_rsp_rdata(v_rsp_rdata), .v_rsp_id(v_rsp_id), .v_rsp_we(v_rsp_we), .v_rsp_status(v_rsp_status),
    .vdma_start_i(1'b0), .vdma_dir_i(1'b0), .vdma_base_i('0), .vdma_len_i('0), .vdma_stride_i('0), .vdma_busy_o(vdma_busy),
    .vdma_done_o(vdma_done), .vdma_err_o(vdma_err), .vdma_in_valid(1'b0), .vdma_in_ready(vdma_in_ready), .vdma_in_data('0),
    .vdma_out_valid(vdma_out_valid), .vdma_out_ready(1'b1), .vdma_out_data(vdma_out_data),
    .t_fill_req_i(t_fill_req), .t_fill_done_i(t_fill_done), .t_fill_grant_o(t_fill_grant), .t_fill_buf_o(t_fill_buf),
    .t_te_req_i(t_te_req), .t_te_done_i(t_te_done), .t_te_owned_o(t_te_owned), .t_te_buf_o(t_te_buf),
    .t_drain_req_i(t_drain_req), .t_drain_done_i(t_drain_done), .t_drain_grant_o(t_drain_grant), .t_drain_buf_o(t_drain_buf),
    .t_buf_state_o(t_buf_state),
    .ta_req_valid(ta_v), .ta_req_ready(ta_rdy), .ta_req_row(ta_row), .ta_rsp_valid(ta_rsp_v), .ta_rsp_ready(1'b1),
    .ta_rsp_data(ta_data), .ta_rsp_status(ta_st),
    .tb_req_valid(tb_v), .tb_req_ready(tb_rdy), .tb_req_row(tb_row), .tb_rsp_valid(tb_rsp_v), .tb_rsp_ready(1'b1),
    .tb_rsp_data(tb_data), .tb_rsp_status(tb_st),
    .tc_req_valid(tc_v), .tc_req_ready(tc_rdy), .tc_req_we(tc_we), .tc_req_row(tc_row), .tc_req_wdata(tc_wd), .tc_req_be(tc_be),
    .tc_rsp_valid(tc_rsp_v), .tc_rsp_ready(1'b1), .tc_rsp_data(tc_data), .tc_rsp_we(tc_rsp_we), .tc_rsp_status(tc_st),
    .td_req_valid(td_v), .td_req_ready(td_rdy), .td_req_we(td_we), .td_req_region(td_region), .td_req_buf(td_buf),
    .td_req_line(td_line), .td_req_wdata(td_wd), .td_req_be(td_be), .td_rsp_valid(td_rsp_v), .td_rsp_ready(1'b1),
    .td_rsp_data(td_data), .td_rsp_we(td_rsp_we), .td_rsp_status(td_st),
    .flush_i(flush), .irq_o(irq), .err_sticky_o(err_sticky), .perf_o(perf), .bank_acc_o(bank_acc), .bank_stall_o(bank_stall),
    .ctl_perf_conf_o(ctl_conf), .ctl_perf_stall_o(ctl_stall),
    .rb_sel(1'b0), .rb_we(1'b0), .rb_addr(8'd0), .rb_wdata(32'd0), .rb_rdata(rb_rdata), .rb_err(rb_err));

  // protocol checkers on every NoC master port
  for (genvar m = 0; m < NM; m++) begin : g_pc
    sfn_protocol_checker #(.QW(3+IDW+3+AW+DW+SB), .RW(IDW+3+2+DW), .NAME("master")) u_chk (
      .clk(clk), .rst_n(rst_n), .req_valid(m_req_valid[m]), .req_ready(m_req_ready[m]),
      .req_payload({m_req_opcode[m*3 +: 3], m_req_id[m*IDW +: IDW], m_req_qos[m*3 +: 3], m_req_addr[m*AW +: AW],
                    m_req_wdata[m*DW +: DW], m_req_wstrb[m*SB +: SB]}),
      .rsp_valid(m_rsp_valid[m]), .rsp_ready(m_rsp_ready[m]),
      .rsp_payload({m_rsp_id[m*IDW +: IDW], m_rsp_opcode[m*3 +: 3], m_rsp_status[m*2 +: 2], m_rsp_rdata[m*DW +: DW]}), .violations());
  end

  // ---------------------------------------------------------------- DMA = burst sequencer on M1
  logic              dcmd_valid = 1'b0, dcmd_ready, dwd_valid = 1'b0, dwd_ready, drd_valid, drd_last, ddone_valid, ddone_ready = 1'b1;
  logic [2:0]        dcmd_op = '0;
  logic [AW-1:0]     dcmd_addr = '0;
  logic [BLW-1:0]    dcmd_len = '0;
  logic [IDW-1:0]    dcmd_id = '0;
  logic [DW-1:0]     dwd_data = '0, drd_data;
  logic [SB-1:0]     drd_strb;
  logic [1:0]        drd_status, ddone_status;
  logic [2:0]        ddone_reason;
  logic [BBW-1:0]    ddone_beats, ddone_eb;
  logic [BLW-1:0]    ddone_bytes;
  logic [31:0]       dst_bursts, dst_rej, dst_beats, dst_bytes, dst_wire, dst_errb, dst_busy, dst_rst, dst_starve, dst_cst, dst_rds, dst_proto;
  sf_sdf_burst_seq #(.AW(AW), .DW(DW), .IDW(IDW), .MAX_BYTES(MAXB), .RD_FIFO(4), .MAX_OUT(4),
                     .LIM_LO({1'b0, SRAM_BASE}), .LIM_HI({1'b0, SRAM_BASE} + (AW+1)'(1 << WIN_LOG2))) u_dma (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(dcmd_valid), .cmd_ready(dcmd_ready), .cmd_op(dcmd_op), .cmd_addr(dcmd_addr), .cmd_len(dcmd_len), .cmd_id(dcmd_id), .cmd_qos(3'd0),
    .wd_valid(dwd_valid), .wd_ready(dwd_ready), .wd_data(dwd_data), .wd_lane_mask_o(),
    .rd_valid(drd_valid), .rd_ready(1'b1), .rd_data(drd_data), .rd_strb(drd_strb), .rd_last(drd_last), .rd_status(drd_status),
    .done_valid(ddone_valid), .done_ready(ddone_ready), .done_id(), .done_status(ddone_status), .done_reason(ddone_reason),
    .done_beats(ddone_beats), .done_err_beat(ddone_eb), .done_bytes(ddone_bytes),
    .m_req_valid(dma_v), .m_req_ready(m_req_ready[1]), .m_req_opcode(dma_op), .m_req_id(dma_id), .m_req_qos(dma_qos),
    .m_req_addr(dma_addr), .m_req_wdata(dma_wd), .m_req_wstrb(dma_ws),
    .m_rsp_valid(m_rsp_valid[1]), .m_rsp_ready(dma_rsp_ready), .m_rsp_id(m_rsp_id[1*IDW +: IDW]), .m_rsp_opcode(m_rsp_opcode[1*3 +: 3]),
    .m_rsp_status(m_rsp_status[1*2 +: 2]), .m_rsp_rdata(m_rsp_rdata[1*DW +: DW]),
    .cnt_clr_i(1'b0), .st_bursts_o(dst_bursts), .st_rejected_o(dst_rej), .st_beats_o(dst_beats), .st_bytes_o(dst_bytes),
    .st_wire_bytes_o(dst_wire), .st_errbeats_o(dst_errb), .st_busy_o(dst_busy), .st_req_stall_o(dst_rst), .st_data_starve_o(dst_starve),
    .st_credit_stall_o(dst_cst), .st_rd_stall_o(dst_rds), .st_proto_o(dst_proto), .busy_o());

  // golden data
  logic [7:0] g_sh [SHARED];            // shared partition
  logic [7:0] g_v [V_SIZE];             // vector private partition
  logic [7:0] dma_rd [MAXB];            // bytes delivered by the last DMA read burst
  logic [7:0] dma_wb [MAXB];            // explicit write payload (dma_use_buf = 1)
  logic       dma_use_buf = 1'b0;
  logic [MAXB-1:0] dma_rd_ok;           // ... which of them were delivered with status OK
  initial begin
    for (int i = 0; i < SHARED; i++) g_sh[i] = 8'h00;
    for (int i = 0; i < V_SIZE; i++) g_v[i] = 8'h00;
  end
  function automatic logic [7:0] pl(input int seed, input int k);
    logic [31:0] h;
    begin h = seed_mix(32'(seed * 7919 + 13), 32'(k + 1)); pl = h[15:8] ^ h[7:0]; end
  endfunction

  // DMA streams (clocked): write data from pl(seed, k), read bytes reassembled into dma_rd
  logic         dma_wr_run = 1'b0, dma_rd_run = 1'b0, dma_seen = 1'b0;
  int           dma_seed, dma_len, dma_nb, dws_j = 0, drd_j = 0;
  logic [AW-1:0] dma_a;
  logic [1:0]   dma_status;
  logic [2:0]   dma_reason;
  int           dma_eb, dma_beatsd;
  logic [31:0]  rd_dma;
  always @(posedge clk) begin
    rd_dma = xs32(rd_dma ^ 32'h5A5A);
    if (!rst_n) dwd_valid <= 1'b0;
    else if (dma_wr_run) begin
      if (dwd_valid && dwd_ready) begin dws_j++; dwd_valid <= 1'b0; end
      if ((!dwd_valid || dwd_ready) && dws_j < dma_nb && rd_dma[3:0] < 4'd12) begin
        logic [DW-1:0] w;
        for (int b = 0; b < SB; b++) begin
          int k;
          k = int'(dma_a & ~AW'(SB - 1)) + dws_j * SB + b - int'(dma_a);
          w[8*b +: 8] = (k >= 0 && k < dma_len) ? (dma_use_buf ? dma_wb[k] : pl(dma_seed, k)) : 8'hEE;
        end
        dwd_valid <= 1'b1; dwd_data <= w;
      end
    end else if (!(dwd_valid && !dwd_ready)) dwd_valid <= 1'b0;
    if (rst_n && drd_valid && dma_rd_run) begin
      for (int b = 0; b < SB; b++) if (drd_strb[b]) begin
        int k;
        k = int'(dma_a & ~AW'(SB - 1)) + drd_j * SB + b - int'(dma_a);
        if (k >= 0 && k < MAXB) begin dma_rd[k] = drd_data[8*b +: 8]; dma_rd_ok[k] = (drd_status == 2'd0); end
      end
      drd_j++;
    end
    if (rst_n && ddone_valid && ddone_ready) begin
      dma_seen <= 1'b1; dma_status <= ddone_status; dma_reason <= ddone_reason; dma_eb <= int'(ddone_eb); dma_beatsd <= int'(ddone_beats);
    end
  end

  // non-blocking DMA command (completion via dma_wait): op, shared-window byte offset, length
  task automatic dma_start(input logic [2:0] op, input int off, input int len, input int seed);
    begin
      dma_a = SRAM_BASE + AW'(off); dma_len = len; dma_seed = seed;
      dma_nb = int'(((dma_a + AW'(len) - 1) >> WB) - (dma_a >> WB) + 1);
      dws_j = 0; drd_j = 0; dma_seen = 1'b0;
      dma_wr_run = (op != `SDF_OP_READ); dma_rd_run = (op == `SDF_OP_READ);
      dma_rd_ok = '0;
      @(posedge clk); #1;
      dcmd_valid = 1'b1; dcmd_op = op; dcmd_addr = dma_a; dcmd_len = BLW'(len); dcmd_id = IDW'(2);
      @(posedge clk);
      while (!dcmd_ready) @(posedge clk);
      #1; dcmd_valid = 1'b0;
    end
  endtask
  task automatic dma_wait();
    int g;
    begin
      g = 0;
      while (!dma_seen && g < 100000) begin @(posedge clk); g++; end
      check(g < 100000, "DMA burst did not complete");
      repeat (2) @(posedge clk);
      dma_wr_run = 1'b0; dma_rd_run = 1'b0;
    end
  endtask
  task automatic g_write_burst(input int off, input int len, input int seed);       // golden update of the shared partition
    begin for (int k = 0; k < len; k++) if (off + k < SHARED) g_sh[off + k] = pl(seed, k); end
  endtask

  // ControlCore (M0): blocking single-beat accesses, acknowledged
  task automatic cc_access(input logic [2:0] op, input int off, input logic [DW-1:0] wd, input logic [SB-1:0] ws, output logic [DW-1:0] rd, output logic [1:0] st);
    int g;
    begin
      @(posedge clk); #1;
      cc_v = 1'b1; cc_op = op; cc_addr = SRAM_BASE + AW'(off); cc_wd = wd; cc_ws = ws;
      g = 0;
      @(posedge clk);
      while (!m_req_ready[0] && g < 5000) begin @(posedge clk); g++; end
      #1; cc_v = 1'b0;
      g = 0;
      while (!m_rsp_valid[0] && g < 5000) begin @(posedge clk); g++; end
      rd = m_rsp_rdata[0 +: DW]; st = m_rsp_status[1:0];
      check(g < 5000, "ControlCore access did not complete");
    end
  endtask
  task automatic cc_check_rd(input int off, input string what);                       // read one DW word and compare with g_sh
    logic [DW-1:0] rd;
    logic [1:0] st;
    logic [DW-1:0] exp;
    begin
      cc_access(`SDF_OP_READ, off, '0, '0, rd, st);
      exp = '0;
      for (int b = 0; b < SB; b++) exp[8*b +: 8] = g_sh[off + b];
      check(st == 2'd0, {what, ": status"});
      check(rd === exp, $sformatf("%s: word at %0h %h != golden %h", what, off, rd, exp));
    end
  endtask

  // VectorScratch direct port (one outstanding, blocking)
  task automatic v_access(input logic we, input int off, input int size, input logic [127:0] wd, output logic [127:0] rd, output logic [2:0] st);
    int g;
    begin
      @(posedge clk); #1;
      v_req_valid = 1'b1; v_req_we = we; v_req_addr = AW'(off); v_req_size = 3'(size); v_req_wdata = wd; v_req_sext = 1'b0; v_req_id = 4'h5;
      g = 0; @(posedge clk);
      while (!v_req_ready && g < 5000) begin @(posedge clk); g++; end
      #1; v_req_valid = 1'b0;
      g = 0;
      while (!v_rsp_valid && g < 5000) begin @(posedge clk); g++; end
      rd = v_rsp_rdata; st = v_rsp_status;
      check(g < 5000, "vector access did not complete");
    end
  endtask

  // TensorScratch helpers
  task automatic td_access(input logic we, input int region, input int buf_i, input int line, input logic [127:0] wd, output logic [127:0] rd, output logic [2:0] st);
    int g;
    begin
      @(posedge clk); #1;
      td_v = 1'b1; td_we = we; td_region = 2'(region); td_buf = BUFW'(buf_i); td_line = TLW'(line); td_wd = wd; td_be = we ? 16'hFFFF : 16'h0000;
      g = 0; @(posedge clk);
      while (!td_rdy && g < 5000) begin @(posedge clk); g++; end
      #1; td_v = 1'b0;
      g = 0;
      while (!td_rsp_v && g < 5000) begin @(posedge clk); g++; end
      rd = td_data; st = td_st;
      check(g < 5000, "tensor DMA-port access did not complete");
    end
  endtask
  task automatic t_read_ab(input int port, input int row, output logic [127:0] rd, output logic [2:0] st);   // port 0 = A, 1 = B
    int g;
    begin
      @(posedge clk); #1;
      if (port == 0) begin ta_v = 1'b1; ta_row = TRW'(row); end else begin tb_v = 1'b1; tb_row = TRW'(row); end
      g = 0; @(posedge clk);
      while (!((port == 0) ? ta_rdy : tb_rdy) && g < 5000) begin @(posedge clk); g++; end
      #1; ta_v = 1'b0; tb_v = 1'b0;
      g = 0;
      while (!((port == 0) ? ta_rsp_v : tb_rsp_v) && g < 5000) begin @(posedge clk); g++; end
      rd = (port == 0) ? ta_data : tb_data; st = (port == 0) ? ta_st : tb_st;
      check(g < 5000, "tensor A/B read did not complete");
    end
  endtask
  task automatic t_write_c(input int row, input logic [127:0] wd, output logic [2:0] st);
    int g;
    begin
      @(posedge clk); #1;
      tc_v = 1'b1; tc_we = 1'b1; tc_row = TRW'(row); tc_wd = wd; tc_be = 16'hFFFF;
      g = 0; @(posedge clk);
      while (!tc_rdy && g < 5000) begin @(posedge clk); g++; end
      #1; tc_v = 1'b0; tc_we = 1'b0;
      g = 0;
      while (!tc_rsp_v && g < 5000) begin @(posedge clk); g++; end
      st = tc_st;
      check(g < 5000, "tensor C write did not complete");
    end
  endtask

  // one tensor tile: A/B read from the shared SRAM by DMA bursts at offsets oa/ob, C written back to oc.  Returns when the
  // result is verified by the ControlCore.  `seed` makes the tile data unique.
  task automatic tensor_flow(input int oa, input int ob, input int oc, input int seedA, input int seedB, input logic verify_cc);
    logic [127:0] ra [TEN_ROWS], rb [TEN_ROWS], rc, rd;
    logic [127:0] cexp [TEN_ROWS];
    logic [2:0] st;
    int buf_i, g;
    begin
      tests++;
      // tiles in the shared SRAM
      dma_start(`SDF_OP_WRITE, oa, TEN_ROWS * 16, seedA); dma_wait(); g_write_burst(oa, TEN_ROWS * 16, seedA);
      dma_start(`SDF_OP_WRITE, ob, TEN_ROWS * 16, seedB); dma_wait(); g_write_burst(ob, TEN_ROWS * 16, seedB);
      // DMA reads the tiles back (burst read) -> operand rows
      dma_start(`SDF_OP_READ, oa, TEN_ROWS * 16, 0); dma_wait();
      for (int r = 0; r < TEN_ROWS; r++) for (int b = 0; b < 16; b++) ra[r][8*b +: 8] = dma_rd[r*16 + b];
      dma_start(`SDF_OP_READ, ob, TEN_ROWS * 16, 0); dma_wait();
      for (int r = 0; r < TEN_ROWS; r++) for (int b = 0; b < 16; b++) rb[r][8*b +: 8] = dma_rd[r*16 + b];
      // ---- fill (ownership: FREE -> FILLING)
      t_fill_req = 1'b1; g = 0;
      while (!t_fill_grant && g < 2000) begin @(posedge clk); g++; end
      check(g < 2000, "tensor fill grant");
      buf_i = int'(t_fill_buf);
      for (int r = 0; r < TEN_ROWS; r++) begin
        td_access(1'b1, 0, buf_i, r, ra[r], rd, st); check(st == 3'd0, "tensor fill A");
        td_access(1'b1, 1, buf_i, r, rb[r], rd, st); check(st == 3'd0, "tensor fill B");
        td_access(1'b1, 2, buf_i, r, 128'h0, rd, st); check(st == 3'd0, "tensor fill C");
      end
      @(posedge clk); #1; t_fill_done = 1'b1; @(posedge clk); #1; t_fill_done = 1'b0; t_fill_req = 1'b0;
      // ownership rule: the DMA port may not touch a buffer that is READY / being computed on
      repeat (4) @(posedge clk);
      td_access(1'b1, 0, buf_i, 0, 128'hDEAD, rd, st); check(st != 3'd0, "tensor: DMA write to a READY buffer must be rejected (ownership)");
      // ---- compute (READY -> COMPUTE): C = A + B bytewise through the A / B / C ports
      t_te_req = 1'b1; g = 0;
      while (!t_te_owned && g < 2000) begin @(posedge clk); g++; end
      check(g < 2000 && int'(t_te_buf) == buf_i, "tensor compute grant / buffer");
      for (int r = 0; r < TEN_ROWS; r++) begin
        logic [127:0] x, y, z;
        t_read_ab(0, r, x, st); check(st == 3'd0, "tensor A read");
        t_read_ab(1, r, y, st); check(st == 3'd0, "tensor B read");
        for (int b = 0; b < 16; b++) z[8*b +: 8] = x[8*b +: 8] + y[8*b +: 8];
        cexp[r] = z;
        t_write_c(r, z, st); check(st == 3'd0, "tensor C write");
      end
      @(posedge clk); #1; t_te_done = 1'b1; @(posedge clk); #1; t_te_done = 1'b0; t_te_req = 1'b0;
      // ---- drain (DONE -> DRAINING): C lines out through the DMA port
      t_drain_req = 1'b1; g = 0;
      while (!t_drain_grant && g < 2000) begin @(posedge clk); g++; end
      check(g < 2000, "tensor drain grant");
      for (int r = 0; r < TEN_ROWS; r++) begin
        td_access(1'b0, 2, buf_i, r, 128'h0, rc, st);
        check(st == 3'd0, "tensor drain status");
        check(rc === cexp[r], $sformatf("tensor C row %0d: drained %h != golden %h", r, rc, cexp[r]));
        for (int b = 0; b < 16; b++) begin dma_wb[r*16 + b] = rc[8*b +: 8]; g_sh[oc + r*16 + b] = rc[8*b +: 8]; end
      end
      @(posedge clk); #1; t_drain_done = 1'b1; @(posedge clk); #1; t_drain_done = 1'b0; t_drain_req = 1'b0;
      repeat (4) @(posedge clk);
      // the drained C tile goes back to the shared SRAM with a DMA burst write
      dma_use_buf = 1'b1; dma_start(`SDF_OP_WRITE, oc, TEN_ROWS * 16, 0); dma_wait(); dma_use_buf = 1'b0;
      check(dma_status == 2'd0, "tensor result DMA write status");
      if (verify_cc) begin
        for (int r = 0; r < TEN_ROWS * 16; r += SB) cc_check_rd(oc + r, "tensor result via NoC");
        dma_start(`SDF_OP_READ, oc, TEN_ROWS * 16, 0); dma_wait();
        for (int k = 0; k < TEN_ROWS * 16; k++) check(dma_rd[k] == g_sh[oc + k] && dma_rd_ok[k], "tensor result via DMA burst read");
      end
    end
  endtask

  // ---------------------------------------------------------------- I5 agents: hosts (M2, M3) and the vector agent
  logic         agents_on = 1'b0;
  logic [31:0]  rh [2];
  logic [31:0]  rv;
  logic [7:0]   g_h [2*512];                                  // host private golden (R_H2 / R_H3, 512 B each)
  logic         hp_busy [2];
  int           hp_n [2];
  int           host_ops = 0, host_errs = 0;
  initial begin
    rh[0] = 32'h1234_5671; rh[1] = 32'h7654_3211; rv = 32'h0BAD_F00D;
    for (int i = 0; i < 1024; i++) g_h[i] = 8'h00;
    hp_busy[0] = 1'b0; hp_busy[1] = 1'b0; hp_n[0] = 0; hp_n[1] = 0;
  end
  logic [DW-1:0] h_exp [2];
  logic [2:0]    h_pop [2];
  logic [AW-1:0] h_pa [2];
  always @(posedge clk) begin
    for (int h = 0; h < 2; h++) begin
      int base;
      base = (h == 0) ? R_H2 : R_H3;
      rh[h] = xs32(rh[h]);
      h_rsp_ready[h] <= rh[h][5:4] != 2'd0;
      // response
      if (m_rsp_valid[2 + h] && m_rsp_ready[2 + h]) begin
        check(hp_busy[h], "host response without a request");
        check(m_rsp_status[(2+h)*2 +: 2] == 2'd0, "host response status");
        if (h_pop[h] == `SDF_OP_READ) check(m_rsp_rdata[(2+h)*DW +: DW] === h_exp[h], $sformatf("host %0d read data %h != golden %h", h, m_rsp_rdata[(2+h)*DW +: DW], h_exp[h]));
        hp_busy[h] = 1'b0;
      end
      if (m_req_valid[2 + h] && m_req_ready[2 + h]) begin
        // accepted: apply to golden (private region, one outstanding)
        if (h_pop[h] != `SDF_OP_READ) for (int b = 0; b < SB; b++) if (h_ws[h*SB + b]) g_h[(h * 512) + int'(h_pa[h]) + b] = h_wd[h*DW + 8*b +: 8];
        if (h_pop[h] == `SDF_OP_READ) for (int b = 0; b < SB; b++) h_exp[h][8*b +: 8] = g_h[(h * 512) + int'(h_pa[h]) + b];
        h_v[h] <= 1'b0;
        host_ops++;
      end
      if (agents_on && !hp_busy[h] && !h_v[h]) begin
        logic [31:0] r;
        int off;
        r = xs32(rh[h] ^ 32'(h)); rh[h] = r;
        off = (int'(r[15:6]) % (512 / SB)) * SB;
        h_pa[h] = AW'(off);
        h_pop[h] = (r[2:0] < 3'd3) ? `SDF_OP_READ : `SDF_OP_WRITE;
        h_op[h*3 +: 3] <= h_pop[h];
        h_addr[h*AW +: AW] <= SRAM_BASE + AW'(base + off);
        h_ws[h*SB +: SB] <= (r[7:6] == 2'd0) ? '1 : SB'(r >> 8);
        h_wd[h*DW +: DW] <= {(DW/32){r ^ 32'h9E3779B9}};
        h_v[h] <= 1'b1; hp_busy[h] = 1'b1;
        hp_n[h]++;
      end
    end
  end
  // the two assignments above run in one block: h_pop is written before being read in the same edge, so use values consistently
  // vector agent: random sub-word / vector accesses in the vector private partition, golden g_v
  logic       va_busy = 1'b0;
  int         va_ops = 0;
  logic [AW-1:0] va_addr;
  int         va_size;
  logic       va_we;
  logic [127:0] va_exp;
  always @(posedge clk) begin
    rv = xs32(rv);
    if (v_req_valid && v_req_ready && agents_on) begin
      v_req_valid <= 1'b0;
      // golden: apply at acceptance
      if (va_we) for (int b = 0; b < (1 << va_size); b++) g_v[int'(va_addr) - V_BASE + b] = v_req_wdata[8*b +: 8];
      else begin va_exp = '0; for (int b = 0; b < (1 << va_size); b++) va_exp[8*b +: 8] = g_v[int'(va_addr) - V_BASE + b]; end
    end
    if (v_rsp_valid && agents_on && va_busy) begin
      check(v_rsp_status == 3'd0, "vector agent status");
      if (!v_rsp_we) check(v_rsp_rdata === va_exp, $sformatf("vector agent read %h != golden %h (addr %h size %0d)", v_rsp_rdata, va_exp, va_addr, va_size));
      va_busy = 1'b0; va_ops++;
    end
    if (agents_on && !va_busy && !v_req_valid) begin
      int sz, off;
      sz = int'(rv[2:0]) % 5;
      off = (int'(rv[21:4]) % (V_SIZE / 16)) * 16 + ((sz < 4) ? ((int'(rv[27:24]) % (16 >> sz)) << sz) : 0);
      va_size = sz; va_addr = AW'(V_BASE + off); va_we = rv[3];
      v_req_valid <= 1'b1; v_req_we <= rv[3]; v_req_addr <= AW'(V_BASE + off); v_req_size <= 3'(sz); v_req_sext <= 1'b0;
      v_req_wdata <= {4{rv ^ 32'hA5C35A3C}}; v_req_id <= 4'h3;
      va_busy = 1'b1;
    end
  end

  // ---------------------------------------------------------------- main
  logic [DW-1:0] rdw;
  logic [1:0]    st2;
  logic [127:0]  rd128;
  logic [2:0]    st3;
  initial begin
    $display("tb_sdf_integ: DW=%0d NB=%0d DEPTH=%0d RL=%0d ECC=%0d NTP=%0d NP=%0d REQ_REG=%0d RSP_REG=%0d", DW, NB, DEPTH, READ_LATENCY, ECC_EN, NTP, NP, REQ_REG, RSP_REG);
    rd_dma = 32'hC0FFEE11;
    rst_n = 1'b0; repeat (6) @(posedge clk); rst_n = 1'b1; repeat (6) @(posedge clk);

    // ---------------------------------------------------------------- I1 NoC (DMA burst) write -> direct vector reads
    tests++;
    dma_start(`SDF_OP_WRITE, R_SRC + 3, 211, 11); dma_wait(); g_write_burst(R_SRC + 3, 211, 11);
    check(dma_status == 2'd0 && dma_beatsd == int'(((SRAM_BASE + AW'(R_SRC + 3) + 210) >> WB) - ((SRAM_BASE + AW'(R_SRC + 3)) >> WB) + 1), "I1 DMA write completion");
    for (int ln = (R_SRC & ~15); ln < R_SRC + 3 + 211; ln += 16) begin
      v_access(1'b0, ln, 4, '0, rd128, st3);
      check(st3 == 3'd0, "I1 vector read status");
      for (int b = 0; b < 16; b++) if (ln + b >= R_SRC + 3 && ln + b < R_SRC + 3 + 211)
        check(rd128[8*b +: 8] == g_sh[ln + b], $sformatf("I1 byte %0h: vector read %h != DMA-written %h", ln + b, rd128[8*b +: 8], g_sh[ln + b]));
    end
    for (int sz = 0; sz < 4; sz++) begin                       // sub-word loads of the DMA data
      v_access(1'b0, R_SRC + 32 + (1 << sz), sz, '0, rd128, st3);
      check(st3 == 3'd0, "I1 sub-word load status");
      for (int b = 0; b < (1 << sz); b++) check(rd128[8*b +: 8] == g_sh[R_SRC + 32 + (1 << sz) + b], "I1 sub-word load");
    end
    // ---------------------------------------------------------------- I2 direct vector writes -> ControlCore / DMA reads
    tests++;
    for (int r = 0; r < 8; r++) begin
      logic [127:0] w;
      for (int b = 0; b < 16; b++) w[8*b +: 8] = pl(77 + r, b);
      v_access(1'b1, R_RES + r * 16, 4, w, rd128, st3);
      check(st3 == 3'd0, "I2 vector write status");
      for (int b = 0; b < 16; b++) g_sh[R_RES + r*16 + b] = w[8*b +: 8];
    end
    v_access(1'b1, R_RES + 8 * 16 + 5, 1, 128'hBEEF, rd128, st3);               // 2-byte store at an unaligned in-line address
    g_sh[R_RES + 8*16 + 5] = 8'hEF; g_sh[R_RES + 8*16 + 6] = 8'hBE;
    for (int off = 0; off < 9 * 16; off += SB) cc_check_rd(R_RES + off, "I2 ControlCore read of vector-written data");
    dma_start(`SDF_OP_READ, R_RES + 7, 100, 0); dma_wait();
    for (int k = 0; k < 100; k++) check(dma_rd[k] == g_sh[R_RES + 7 + k] && dma_rd_ok[k], $sformatf("I2 DMA burst read byte %0d", k));
    // ---------------------------------------------------------------- ControlCore writes, vector reads (same line, both directions)
    tests++;
    for (int off = 0; off < 64; off += SB) begin
      logic [DW-1:0] w;
      for (int b = 0; b < SB; b++) w[8*b +: 8] = pl(5, off + b);
      cc_access(`SDF_OP_WRITE, R_CC + off, w, '1, rdw, st2); check(st2 == 2'd0, "CC write");
      for (int b = 0; b < SB; b++) g_sh[R_CC + off + b] = w[8*b +: 8];
    end
    for (int ln = 0; ln < 64; ln += 16) begin
      v_access(1'b0, R_CC + ln, 4, '0, rd128, st3);
      for (int b = 0; b < 16; b++) check(rd128[8*b +: 8] == g_sh[R_CC + ln + b], "I2b vector read of ControlCore-written data");
    end
    // ---------------------------------------------------------------- I3 isolation of the private partition
    tests++;
    for (int i = 0; i < 32; i++) begin
      logic [127:0] w;
      for (int b = 0; b < 16; b++) w[8*b +: 8] = pl(300, i * 16 + b);
      v_access(1'b1, V_BASE + i * 16, 4, w, rd128, st3);
      for (int b = 0; b < 16; b++) g_v[i*16 + b] = w[8*b +: 8];
    end
    cc_access(`SDF_OP_WRITE, V_BASE + 32, {DW{1'b1}}, '1, rdw, st2);
    check(st2 == 2'd1, "I3 ControlCore write into the vector partition must answer ST_SLVERR");
    cc_access(`SDF_OP_READ, V_BASE + 32, '0, '0, rdw, st2);
    check(st2 == 2'd1 && rdw == '0, "I3 ControlCore read of the vector partition must answer ST_SLVERR with rdata 0");
    cc_access(`SDF_OP_WRITE, T_BASE_LINE * 16 + 16, {DW{1'b1}}, '1, rdw, st2);
    check(st2 == 2'd1, "I3 ControlCore write into the tensor partition must answer ST_SLVERR");
    cc_access(`SDF_OP_WRITE, CAP + 16, {DW{1'b1}}, '1, rdw, st2);
    check(st2 == 2'd1, "I3 write beyond the SRAM capacity must answer ST_SLVERR (never aliased)");
    dma_start(`SDF_OP_WRITE, V_BASE, 64, 999); dma_wait();
    check(dma_status == 2'd1 && dma_eb == 0, $sformatf("I3 DMA burst into the vector partition: status %0d first-error beat %0d", dma_status, dma_eb));
    for (int i = 0; i < 32; i++) begin
      v_access(1'b0, V_BASE + i * 16, 4, '0, rd128, st3);
      for (int b = 0; b < 16; b++) check(rd128[8*b +: 8] == g_v[i*16 + b], "I3 vector partition must be untouched by NoC writes");
    end
    check(perf[`SDF_P_ERR_RSP*32 +: 32] >= 5, "I3 bridge error counter");
    // ---------------------------------------------------------------- I4 tensor flow (two tiles: both ping-pong buffers)
    tensor_flow(R_TA, R_TB, R_TC, 21, 22, 1'b1);
    tensor_flow(R_TA + 64, R_TB + 64, R_TC + 64, 31, 32, 1'b1);
    // the vector partition and the tensor tile storage were not disturbed by the tensor flows or by the NoC isolation attempts
    for (int i = 0; i < 32; i++) begin
      v_access(1'b0, V_BASE + i * 16, 4, '0, rd128, st3);
      for (int b = 0; b < 16; b++) check(rd128[8*b +: 8] == g_v[i*16 + b], "I4 vector partition intact after the tensor flows");
    end

    // ---------------------------------------------------------------- I5 everything at once
    begin
      int t0, nrd;
      for (int i = 0; i < 1024; i++) g_h[i] = 8'h00;
      for (int h = 0; h < 2; h++) for (int i = 0; i < 512; i += SB) begin end
      agents_on = 1'b1;
      t0 = $time / 10;
      nrd = 0;
      // seed the host regions with zeros through the golden (they are zero already); DMA runs bursts in R_DMA2 / R_DST
      for (int round = 0; round < 12; round++) begin
        dma_start(`SDF_OP_WRITE_POSTED, R_DMA2 + 5 + round, 150 + round, 400 + round); dma_wait(); g_write_burst(R_DMA2 + 5 + round, 150 + round, 400 + round);
        dma_start(`SDF_OP_READ, R_DMA2 + 5 + round, 150 + round, 0); dma_wait();
        for (int k = 0; k < 150 + round; k++) check(dma_rd[k] == g_sh[R_DMA2 + 5 + round + k] && dma_rd_ok[k], "I5 DMA burst read-back under load");
        if (round % 4 == 1) tensor_flow(R_TA, R_TB, R_TC, 50 + round, 60 + round, 1'b1);
      end
      repeat (I5_CYCLES) @(posedge clk);
      agents_on = 1'b0;
      repeat (200) @(posedge clk);
      check(hp_n[0] > 20 && hp_n[1] > 20, "I5 host agents made progress");
      check(va_ops > 20, "I5 vector agent made progress");
      $display("  I5: host ops %0d, vector ops %0d, DMA bursts %0d, tensor tiles done; bank stalls (bridge) = %0d, controller conflicts = %0d",
               host_ops, va_ops, dst_bursts, bank_stall[31:0] + bank_stall[63:32], ctl_conf[31:0] + ctl_conf[63:32] + ctl_conf[95:64] + ctl_conf[127:96]);
    end
    // final: verify the host private regions and the shared golden through the NoC (ControlCore)
    tests++;
    for (int h = 0; h < 2; h++) begin
      int base;
      base = (h == 0) ? R_H2 : R_H3;
      for (int off = 0; off < 512; off += SB) begin
        cc_access(`SDF_OP_READ, base + off, '0, '0, rdw, st2);
        check(st2 == 2'd0, "final host region read");
        for (int b = 0; b < SB; b++) check(rdw[8*b +: 8] == g_h[h*512 + off + b], $sformatf("final host %0d region byte %0d", h, off + b));
      end
    end
    for (int off = R_DMA2; off < R_DMA2 + 192; off += SB) cc_check_rd(off, "final DMA region");
    for (int i = 0; i < V_SIZE / 16; i++) begin
      v_access(1'b0, V_BASE + i * 16, 4, '0, rd128, st3);
      for (int b = 0; b < 16; b++) check(rd128[8*b +: 8] == g_v[i*16 + b], "final vector partition byte");
    end
    // statistics
    check(dst_proto == 0, "DMA sequencer protocol errors");
    check(perf[`SDF_P_ORPHAN*32 +: 32] == 0 && perf[`SDF_P_PROTO*32 +: 32] == 0 && perf[`SDF_P_OVF*32 +: 32] == 0, "bridge orphan / proto / overflow counters");
    check(perf[`SDF_P_TIMEOUT*32 +: 32] == 0, "no timeout on a healthy controller");
    $display("PERF integ bridge_req=%0d bridge_rsp=%0d err_rsp=%0d lat_avg_x100=%0d lat_max=%0d dma_bursts=%0d dma_beats=%0d dma_util_pct=%0d",
             perf[`SDF_P_REQ*32 +: 32], perf[`SDF_P_RSP*32 +: 32], perf[`SDF_P_ERR_RSP*32 +: 32],
             (perf[`SDF_P_RSP*32 +: 32] == 0) ? 0 : (perf[`SDF_P_LAT_SUM*32 +: 32] * 100) / perf[`SDF_P_RSP*32 +: 32], perf[`SDF_P_LAT_MAX*32 +: 32],
             dst_bursts, dst_beats, (dst_wire == 0) ? 0 : (dst_bytes * 100) / dst_wire);
    repeat (10) @(posedge clk);
    $display("RESULT tests=%0d checks=%0d errors=%0d %s", tests, checks, errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin
    #(64'd600_000_000);
    $display("RESULT tests=%0d checks=%0d errors=%0d FAIL (global timeout)", tests, checks, errors + 1);
    $finish;
  end
endmodule
