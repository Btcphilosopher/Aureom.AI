// =============================================================================
// SilicaFlux SRAMFabric (P74) :: tb_sdf -- end-to-end transaction scoreboard for the DataFabric -> SRAM bridge
//
//   NOC = 1 : NM SFB3 masters -> REAL silicaflux_noc (crossbar, vendored, unmodified) -> NTP target ports
//   NOC = 0 : master m is wired straight to bridge target port m (NM == NTP): everything the fabric would have
//             filtered (reserved opcodes, FENCE, unmapped / misaligned addresses) reaches the bridge
//   -> sf_sdf_port x NTP (sf_sram_datafabric) -> sf_sram_controller (NCP = NTP*NP master ports) -> banks
//
// Scoreboard (independent of the bridge: it decodes the master's request itself):
//   master accept   : an entry {op, addr, wdata, wstrb} is created and queued in request order per (master, id):
//                     rq = responses the master must receive (local DECERR / FENCE entries are complete at once),
//                     tq = target-bound entries (matched to the target port in request order, SFB3 O2/R5)
//   target accept   : the oldest unmatched tq entry of (src,id) is pushed on the slice FIFO
//   controller accept (bridge c_req handshake, the serialisation point): the slice FIFO entry is applied to the byte
//                     model (write bytes / read data / error class) -- ORDER comes from the controller, CONTENT from the
//                     independent decode; the bridge's line address / byte enables / port are checked against it
//   flush           : entries applied but not yet answered by the controller are lost: expected SLVERR, cause RESET /
//                     TIMEOUT (writes stay committed: controller O7)
//   t_rsp / m_rsp   : compared with the entry (opcode, status, cause sideband, rdata, order per (src,id))
// Exactly-once: every entry must be matched by exactly one response (posted writes: one target completion); the final
// per-pair queue state must be empty; response counts are compared with the bridge's performance counters.
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`include "sf_sdf_defs.svh"

module tb_sdf #(
  parameter int NOC = 1,
  parameter int DW  = 128,
  parameter int NM  = 3,
  parameter int IDW = 2,
  parameter int NTP = 1,
  parameter int NP  = 1,
  parameter int NB  = 4,
  parameter int DEPTH = 64,
  parameter int READ_LATENCY = 1,
  parameter int ECC_EN = 0,
  parameter int NSLOT = 8,
  parameter int ARB = `SF_ARB_RR,
  parameter int REQ_REG = 1,
  parameter int RSP_REG = 1,
  parameter int CHK_ALIGN = 1,
  parameter int NRAND = 1500,
  parameter int P_RSP_STALL = 30,         // % of cycles a master refuses a response
  parameter int P_REQ_IDLE = 20,          // % of cycles a master idles between requests
  parameter int ALLOW_HI_DIV = 1,         // allowed range = [0, CAP/ALLOW_HI_DIV)
  parameter int TIMEOUT = 0,
  parameter int RUN_FLUSH = 1,
  parameter int RUN_TIMEOUT = 0,
  parameter int RUN_RESET = 1,
  parameter int RUN_ECC = 0,
  parameter int RUN_LAT = 1,
  parameter int NBURST = 0,              // masters that are burst sequencers (the last NBURST masters)
  parameter int NBCMD = 250,
  parameter int MAXB = 256,
  parameter int BRD_FIFO = 4,
  parameter int BMAXOUT = 4,
  parameter int SEED = 32'h0D15EA5E
);
  localparam int AW = 32;
  localparam int SB = DW / 8;
  localparam int LINE_W = 128;
  localparam int SRCW = (NM > 1) ? $clog2(NM) : 1;
  localparam int NMS = NM - NBURST;            // scripted (single-beat) masters
  localparam int NID = 1 << IDW;
  localparam int NPAIR = NM * NID;
  localparam int LANEW = (DW < LINE_W) ? $clog2(LINE_W / DW) : 1;
  localparam int IDC = 3 + SRCW + IDW + LANEW + 1;
  localparam int NCP = NTP * NP;
  localparam int CAP_BYTES = NB * DEPTH * 16;
  localparam int WIN_LOG2 = $clog2(CAP_BYTES) + 1;          // window = 2x capacity: the upper half is "beyond capacity"
  localparam int WIN_SIZE = 1 << WIN_LOG2;
  localparam logic [AW-1:0] WMASK = AW'(WIN_SIZE) - 1'b1;
  localparam int ALLOW_LO = 0;
  localparam int ALLOW_HI = CAP_BYTES / ALLOW_HI_DIV;
  localparam int STORE_W_ECC = 137;
  localparam int ROW_W = $clog2(DEPTH);
  localparam int BW = (NB > 1) ? $clog2(NB) : 1;
  localparam int FBW = 8;
  localparam int STORE_W = (ECC_EN != 0) ? 137 : 128;
  localparam int INIT_ON_RESET = ECC_EN;
  localparam int NENT = 16384;
  localparam int RING = 256;
  localparam int MAXCMD = NRAND + 64;
  localparam int CPQ = NSLOT + 8;

  localparam logic [4*AW-1:0] WB4 = {32'h2030_0000, 32'h2020_0000, 32'h2010_0000, 32'h2000_0000};
  localparam logic [NTP*AW-1:0] WBS = WB4[NTP*AW-1:0];
  function automatic logic [AW-1:0] win_base(input int t);
    win_base = 32'h2000_0000 + 32'(t) * 32'h0010_0000;
  endfunction

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  `include "sfn_tb_common.svh"

  int errors = 0, checks = 0, tests = 0;
  task automatic check(input logic cond, input string msg);
    begin
      checks++;
      if (!cond) begin
        errors++;
        if (errors <= 25) $display("[FAIL] t=%0t %s", $time, msg);
      end
    end
  endtask

  // ---------------------------------------------------------------- master side
  // scripted masters drive ms_*; burst-sequencer masters (indices NMS..NM-1) are wired below; both are combined onto m_*
  logic [NMS-1:0]     ms_req_valid;
  logic [NMS*3-1:0]   ms_req_opcode;
  logic [NMS*IDW-1:0] ms_req_id;
  logic [NMS*3-1:0]   ms_req_qos;
  logic [NMS*AW-1:0]  ms_req_addr;
  logic [NMS*DW-1:0]  ms_req_wdata;
  logic [NMS*(DW/8)-1:0] ms_req_wstrb;
  logic [NMS-1:0]     ms_rsp_ready;
  logic [NM-1:0]      m_req_valid, m_req_ready;
  logic [NM*3-1:0]    m_req_opcode;
  logic [NM*IDW-1:0]  m_req_id;
  logic [NM*3-1:0]    m_req_qos;
  logic [NM*AW-1:0]   m_req_addr;
  logic [NM*DW-1:0]   m_req_wdata;
  logic [NM*SB-1:0]   m_req_wstrb;
  logic [NM-1:0]      m_rsp_valid, m_rsp_ready;
  logic [NM*IDW-1:0]  m_rsp_id;
  logic [NM*3-1:0]    m_rsp_opcode;
  logic [NM*2-1:0]    m_rsp_status;
  logic [NM*DW-1:0]   m_rsp_rdata;
  for (genvar m = 0; m < NMS; m++) begin : g_ms
    assign m_req_valid[m] = ms_req_valid[m];
    assign m_req_opcode[m*3 +: 3] = ms_req_opcode[m*3 +: 3];
    assign m_req_id[m*IDW +: IDW] = ms_req_id[m*IDW +: IDW];
    assign m_req_qos[m*3 +: 3] = ms_req_qos[m*3 +: 3];
    assign m_req_addr[m*AW +: AW] = ms_req_addr[m*AW +: AW];
    assign m_req_wdata[m*DW +: DW] = ms_req_wdata[m*DW +: DW];
    assign m_req_wstrb[m*(DW/8) +: DW/8] = ms_req_wstrb[m*(DW/8) +: DW/8];
    assign m_rsp_ready[m] = ms_rsp_ready[m];
  end
  // ---------------------------------------------------------------- target side (bridge)
  logic [NTP-1:0]     t_req_valid, t_req_ready;
  logic [NTP*3-1:0]   t_req_opcode;
  logic [NTP*SRCW-1:0] t_req_src;
  logic [NTP*IDW-1:0] t_req_id;
  logic [NTP*3-1:0]   t_req_qos;
  logic [NTP*AW-1:0]  t_req_addr;
  logic [NTP*DW-1:0]  t_req_wdata;
  logic [NTP*SB-1:0]  t_req_wstrb;
  logic [NTP-1:0]     t_rsp_valid, t_rsp_ready;
  logic [NTP*SRCW-1:0] t_rsp_src;
  logic [NTP*IDW-1:0] t_rsp_id;
  logic [NTP*3-1:0]   t_rsp_opcode;
  logic [NTP*2-1:0]   t_rsp_status;
  logic [NTP*DW-1:0]  t_rsp_rdata;
  logic [NTP*3-1:0]   rsp_cause;

  if (NOC != 0) begin : g_noc
    logic [31:0] rb_rdata;
    logic        rb_err, irq_err, obs_bad_src;
    logic [NM-1:0] obs_sw_valid, obs_sw_ready, obs_decerr, obs_posted_err, obs_orphan;
    silicaflux_noc #(
      .TOPOLOGY(1), .NM(NM), .NT(NTP), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(1), .CHECK_ALIGN(CHK_ALIGN),
      .TGT_BASE(WBS), .TGT_MASK({NTP{~WMASK}}), .MAXO_MAX(4), .PERF(0)
    ) noc (
      .clk(clk), .rst_n(rst_n),
      .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_opcode(m_req_opcode), .m_req_id(m_req_id),
      .m_req_qos(m_req_qos), .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
      .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_id(m_rsp_id), .m_rsp_opcode(m_rsp_opcode),
      .m_rsp_status(m_rsp_status), .m_rsp_rdata(m_rsp_rdata),
      .t_req_valid(t_req_valid), .t_req_ready(t_req_ready), .t_req_opcode(t_req_opcode), .t_req_src(t_req_src),
      .t_req_id(t_req_id), .t_req_qos(t_req_qos), .t_req_addr(t_req_addr), .t_req_wdata(t_req_wdata),
      .t_req_wstrb(t_req_wstrb),
      .t_rsp_valid(t_rsp_valid), .t_rsp_ready(t_rsp_ready), .t_rsp_src(t_rsp_src), .t_rsp_id(t_rsp_id),
      .t_rsp_opcode(t_rsp_opcode), .t_rsp_status(t_rsp_status), .t_rsp_rdata(t_rsp_rdata),
      .rb_sel(1'b0), .rb_we(1'b0), .rb_addr(12'd0), .rb_wdata(32'd0), .rb_rdata(rb_rdata), .rb_err(rb_err),
      .irq_err(irq_err), .obs_sw_valid(obs_sw_valid), .obs_sw_ready(obs_sw_ready), .obs_out_cnt(),
      .obs_decerr(obs_decerr), .obs_posted_err(obs_posted_err), .obs_orphan(obs_orphan), .obs_bad_src(obs_bad_src));
    for (genvar m = 0; m < NM; m++) begin : g_pc
      sfn_protocol_checker #(.QW(3+IDW+3+AW+DW+SB), .RW(IDW+3+2+DW), .NAME("master")) u_chk (
        .clk(clk), .rst_n(rst_n), .req_valid(m_req_valid[m]), .req_ready(m_req_ready[m]),
        .req_payload({m_req_opcode[m*3 +: 3], m_req_id[m*IDW +: IDW], m_req_qos[m*3 +: 3], m_req_addr[m*AW +: AW],
                      m_req_wdata[m*DW +: DW], m_req_wstrb[m*SB +: SB]}),
        .rsp_valid(m_rsp_valid[m]), .rsp_ready(m_rsp_ready[m]),
        .rsp_payload({m_rsp_id[m*IDW +: IDW], m_rsp_opcode[m*3 +: 3], m_rsp_status[m*2 +: 2], m_rsp_rdata[m*DW +: DW]}),
        .violations());
    end
    wire unused_n = &{1'b0, rb_rdata, rb_err, irq_err, obs_bad_src, obs_sw_valid, obs_sw_ready, obs_decerr,
                      obs_posted_err, obs_orphan};
  end else begin : g_direct
    if (NM != NTP || NBURST != 0) begin : g_e
      initial $fatal(1, "tb_sdf: NOC=0 needs NM == NTP and no burst masters");
    end
    assign t_req_valid  = m_req_valid;
    assign m_req_ready  = t_req_ready;
    assign t_req_opcode = m_req_opcode;
    assign t_req_id     = m_req_id;
    assign t_req_qos    = m_req_qos;
    assign t_req_addr   = m_req_addr;
    assign t_req_wdata  = m_req_wdata;
    assign t_req_wstrb  = m_req_wstrb;
    for (genvar m = 0; m < NM; m++) begin : g_src
      assign t_req_src[m*SRCW +: SRCW] = SRCW'(m);
    end
    assign m_rsp_valid  = t_rsp_valid;
    assign t_rsp_ready  = m_rsp_ready;
    assign m_rsp_id     = t_rsp_id;
    assign m_rsp_opcode = t_rsp_opcode;
    assign m_rsp_status = t_rsp_status;
    assign m_rsp_rdata  = t_rsp_rdata;
  end

  // ---------------------------------------------------------------- bridge + controller
  logic [NCP-1:0]            c_req_valid, c_req_ready, c_req_we, c_rsp_valid, c_rsp_ready, c_rsp_we, c_rsp_ce;
  logic [NCP*AW-1:0]         c_req_addr;
  logic [NCP*LINE_W-1:0]     c_req_wdata, c_rsp_rdata;
  logic [NCP*(LINE_W/8)-1:0] c_req_be;
  logic [NCP*IDC-1:0]        c_req_id, c_rsp_id;
  logic [NCP*3-1:0]          c_rsp_status;
  logic [NTP-1:0]            err_sticky;
  logic [NTP*32-1:0]         err_cnt;
  logic [NTP*3-1:0]          err_code, err_opcode;
  logic [NTP*SRCW-1:0]       err_src;
  logic [NTP*IDW-1:0]        err_id;
  logic [NTP*AW-1:0]         err_addr;
  logic                      irq, c_flush_o;
  logic [NTP*`SDF_NPERF*32-1:0] perf;
  logic [NTP*NB*32-1:0]      bank_acc, bank_stall;
  logic [NTP*16-1:0]         out_cnt;
  logic [31:0]               rb_rdata_b;
  logic                      rb_err_b;
  logic                      err_clr = 1'b0;
  logic                      rb_sel = 1'b0, rb_we = 1'b0;
  logic [7:0]                rb_addr = 8'd0;
  logic [31:0]               rb_wdata = 32'd0;
  logic                      flush_tb = 1'b0;
  logic                      ctl_flush_busy;
  logic                      hide = 1'b0;                 // shim: hide controller responses from the bridge (timeout test)
  logic [NCP-1:0]            ctl_rsp_valid, ctl_rsp_ready;
  logic                      ctl_rst_n;
  wire                       c_flush_i = ctl_flush_busy | ~ctl_rst_n;

  sf_sram_datafabric #(
    .NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .NTP(NTP), .NP(NP), .NB(NB), .DEPTH(DEPTH), .WIN_BASES(WBS),
    .WIN_LOG2(WIN_LOG2), .ALLOW_LO(ALLOW_LO), .ALLOW_HI(ALLOW_HI), .REQ_REG(REQ_REG), .RSP_REG(RSP_REG),
    .CTRL_NSLOT(NSLOT), .TXQ_DEPTH(NSLOT), .TIMEOUT(TIMEOUT), .TO_ACTION(1)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .t_req_valid(t_req_valid), .t_req_ready(t_req_ready), .t_req_opcode(t_req_opcode), .t_req_src(t_req_src),
    .t_req_id(t_req_id), .t_req_qos(t_req_qos), .t_req_addr(t_req_addr), .t_req_wdata(t_req_wdata),
    .t_req_wstrb(t_req_wstrb),
    .t_rsp_valid(t_rsp_valid), .t_rsp_ready(t_rsp_ready), .t_rsp_src(t_rsp_src), .t_rsp_id(t_rsp_id),
    .t_rsp_opcode(t_rsp_opcode), .t_rsp_status(t_rsp_status), .t_rsp_rdata(t_rsp_rdata), .rsp_cause_o(rsp_cause),
    .c_req_valid(c_req_valid), .c_req_ready(c_req_ready), .c_req_we(c_req_we), .c_req_addr(c_req_addr),
    .c_req_wdata(c_req_wdata), .c_req_be(c_req_be), .c_req_id(c_req_id),
    .c_rsp_valid(c_rsp_valid), .c_rsp_ready(c_rsp_ready), .c_rsp_rdata(c_rsp_rdata), .c_rsp_id(c_rsp_id),
    .c_rsp_we(c_rsp_we), .c_rsp_status(c_rsp_status), .c_rsp_ce(c_rsp_ce),
    .c_flush_i(c_flush_i), .c_flush_o(c_flush_o),
    .err_clr_i(err_clr), .err_sticky_o(err_sticky), .err_cnt_o(err_cnt), .err_code_o(err_code), .err_src_o(err_src),
    .err_id_o(err_id), .err_opcode_o(err_opcode), .err_addr_o(err_addr), .irq_o(irq),
    .perf_o(perf), .bank_acc_o(bank_acc), .bank_stall_o(bank_stall), .out_cnt_o(out_cnt),
    .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(rb_rdata_b), .rb_err(rb_err_b));

  // controller reset is the shared reset in these tests; ctl_rst_n is separate only so that a controller-only reset can be applied
  logic ctl_rst_drv = 1'b1;
  assign ctl_rst_n = rst_n & ctl_rst_drv;

  logic [NCP-1:0]    ctl_rsp_valid_raw;
  assign ctl_rsp_valid = ctl_rsp_valid_raw;
  logic [NCP-1:0]    c_rsp_valid_br;
  assign c_rsp_valid   = ctl_rsp_valid_raw & {NCP{~hide}};
  assign ctl_rsp_ready = c_rsp_ready & {NCP{~hide}};

  logic [NB-1:0]     c_ev_ue, c_ev_ce;
  logic [NB*STORE_W-1:0] c_tst_rdata;
  logic [BW-1:0]     fi_bank = '0;
  logic              seu_pulse = 1'b0;
  logic [ROW_W-1:0]  seu_row = '0;
  logic [STORE_W-1:0] seu_mask = '0;
  logic [NB*32-1:0]  c_perf_acc, c_perf_conf, c_perf_busy;
  logic [NCP*32-1:0] c_perf_stall;
  logic              c_idle, c_flush_busy, c_init_busy;
  logic [NB-1:0]     c_bank_acc;

  sf_sram_controller #(
    .NM(NCP), .NB(NB), .DEPTH(DEPTH), .DW(LINE_W), .AW(AW), .IDW(IDC), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN),
    .NSLOT(NSLOT), .ARB(ARB), .ALIGN_MODE(1), .INIT_ON_RESET(INIT_ON_RESET), .SIM_INIT(1),
    .FAULT_INJECT((RUN_ECC != 0) ? 1 : 0)
  ) ctl (
    .clk(clk), .rst_n(ctl_rst_n),
    .m_req_valid(c_req_valid), .m_req_ready(c_req_ready), .m_req_we(c_req_we), .m_req_addr(c_req_addr),
    .m_req_wdata(c_req_wdata), .m_req_be(c_req_be), .m_req_id(c_req_id),
    .m_rsp_valid(ctl_rsp_valid_raw), .m_rsp_ready(ctl_rsp_ready), .m_rsp_rdata(c_rsp_rdata), .m_rsp_id(c_rsp_id),
    .m_rsp_we(c_rsp_we), .m_rsp_status(c_rsp_status), .m_rsp_ce(c_rsp_ce),
    .flush_i(flush_tb | c_flush_o), .flush_busy_o(ctl_flush_busy), .quiesce_i(1'b0), .idle_o(c_idle),
    .init_start_i(1'b0), .init_busy_o(c_init_busy), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(c_ev_ce), .ev_ue_o(c_ev_ue), .ce_cnt_o(), .ue_cnt_o(),
    .perf_acc_o(c_perf_acc), .perf_conf_o(c_perf_conf), .perf_busy_o(c_perf_busy), .perf_stall_o(c_perf_stall),
    .bank_acc_o(c_bank_acc),
    .tst_active_i(1'b0), .tst_sel_i({NB{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({ROW_W{1'b0}}),
    .tst_wdata_i({STORE_W{1'b0}}), .tst_rdata_o(c_tst_rdata),
    .fi_bank(fi_bank), .fi_type(4'd0), .fi_row({ROW_W{1'b0}}), .fi_row2({ROW_W{1'b0}}), .fi_bit({FBW{1'b0}}),
    .fi_bit2({FBW{1'b0}}), .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(seu_pulse), .seu_row(seu_row), .seu_mask(seu_mask));

  // backdoor view of the bank arrays (non-ECC builds): physical placement of every byte must equal the model
  logic dump_req = 1'b0;
  logic [LINE_W-1:0] dump [NB*DEPTH];
  for (genvar b = 0; b < NB; b++) begin : g_dump
    always @(dump_req) for (int r = 0; r < DEPTH; r++) dump[b*DEPTH + r] = ctl.g_bank[b].u_bank.u_core.g_behav.u_mem.mem[r];
  end

  // protocol checkers on the bridge's two sides
  for (genvar t = 0; t < NTP; t++) begin : g_tchk
    sfn_protocol_checker #(.QW(3+SRCW+IDW+3+AW+DW+SB), .RW(SRCW+IDW+3+2+DW), .NAME("bridge-target")) u_chk (
      .clk(clk), .rst_n(rst_n), .req_valid(t_req_valid[t]), .req_ready(t_req_ready[t]),
      .req_payload({t_req_opcode[t*3 +: 3], t_req_src[t*SRCW +: SRCW], t_req_id[t*IDW +: IDW], t_req_qos[t*3 +: 3],
                    t_req_addr[t*AW +: AW], t_req_wdata[t*DW +: DW], t_req_wstrb[t*SB +: SB]}),
      .rsp_valid(t_rsp_valid[t]), .rsp_ready(t_rsp_ready[t]),
      .rsp_payload({t_rsp_src[t*SRCW +: SRCW], t_rsp_id[t*IDW +: IDW], t_rsp_opcode[t*3 +: 3], t_rsp_status[t*2 +: 2],
                    t_rsp_rdata[t*DW +: DW]}), .violations());
  end
  // SFB3 target-port assertion monitor (R2, R4, R5 exactly-once, opcode echo, no response in the acceptance cycle)
  int tchk_viol [NTP];
  int tchk_out [NTP];
  logic tchk_quiet = 1'b0;
  for (genvar t = 0; t < NTP; t++) begin : g_tmon
    int v, o;
    sf_sdf_tgt_chk #(.NM(NM), .IDW(IDW), .AW(AW), .DW(DW), .NAME("sf_sdf_tgt_chk")) u_mon (
      .clk(clk), .rst_n(rst_n), .t_req_valid(t_req_valid[t]), .t_req_ready(t_req_ready[t]), .t_req_opcode(t_req_opcode[t*3 +: 3]),
      .t_req_src(t_req_src[t*SRCW +: SRCW]), .t_req_id(t_req_id[t*IDW +: IDW]), .t_req_addr(t_req_addr[t*AW +: AW]),
      .t_req_wdata(t_req_wdata[t*DW +: DW]), .t_req_wstrb(t_req_wstrb[t*SB +: SB]),
      .t_rsp_valid(t_rsp_valid[t]), .t_rsp_ready(t_rsp_ready[t]), .t_rsp_src(t_rsp_src[t*SRCW +: SRCW]), .t_rsp_id(t_rsp_id[t*IDW +: IDW]),
      .t_rsp_opcode(t_rsp_opcode[t*3 +: 3]), .t_rsp_status(t_rsp_status[t*2 +: 2]), .t_rsp_rdata(t_rsp_rdata[t*DW +: DW]),
      .quiet_i(tchk_quiet), .violations(v), .outstanding_o(o), .accepted_o(), .answered_o());
    always @* begin tchk_viol[t] = v; tchk_out[t] = o; end
  end
  for (genvar c = 0; c < NCP; c++) begin : g_cchk
    sfn_protocol_checker #(.QW(1+AW+LINE_W+LINE_W/8+IDC), .RW(LINE_W+IDC+1+3), .NAME("bridge-ctrl")) u_chk (
      // controller contract O7: a flush withdraws presented responses, so R4 is not checked while flushing
      .clk(clk), .rst_n(ctl_rst_n & ~c_flush_i), .req_valid(c_req_valid[c]), .req_ready(c_req_ready[c]),
      .req_payload({c_req_we[c], c_req_addr[c*AW +: AW], c_req_wdata[c*LINE_W +: LINE_W],
                    c_req_be[c*(LINE_W/8) +: LINE_W/8], c_req_id[c*IDC +: IDC]}),
      .rsp_valid(ctl_rsp_valid_raw[c]), .rsp_ready(ctl_rsp_ready[c]),
      .rsp_payload({c_rsp_rdata[c*LINE_W +: LINE_W], c_rsp_id[c*IDC +: IDC], c_rsp_we[c], c_rsp_status[c*3 +: 3]}),
      .violations());
  end

  // ================================================================ scoreboard state
  logic [7:0]   ref_mem [CAP_BYTES];
  logic         ue_line [CAP_BYTES/16];           // lines holding an injected uncorrectable error (ECC runs)
  int           ent_n = 0;
  logic [2:0]   e_op [NENT];
  logic [AW-1:0] e_addr [NENT];
  logic [DW-1:0] e_wdata [NENT];
  logic [SB-1:0] e_wstrb [NENT];
  int           e_m [NENT];
  int           e_id [NENT];
  int           e_slice [NENT];
  logic         e_target [NENT];
  logic         e_filled [NENT];
  logic [2:0]   e_xop [NENT];
  logic [1:0]   e_xst [NENT];
  logic [2:0]   e_xcause [NENT];
  logic         e_cause_any [NENT];            // cause may be RESET or TIMEOUT (flush tests)
  logic [DW-1:0] e_xrd [NENT];
  logic         e_lost [NENT];
  int           e_acc_cyc [NENT];
  int           e_ctl_cyc [NENT];
  int           e_tacc [NENT];
  int           tq [NPAIR][RING];
  int           tq_wp [NPAIR], tq_ap [NPAIR], tq_rp [NPAIR];
  int           rq [NPAIR][RING];
  int           rq_wp [NPAIR], rq_rp [NPAIR];
  int           sfq [NTP][64];
  int           sf_wp [NTP], sf_rp [NTP];
  int           cpq [NCP][CPQ];
  int           cp_wp [NCP], cp_rp [NCP];
  int           cycle = 0;
  int           lost_total = 0;
  logic [2:0]   lost_cause = `SDF_CAUSE_RESET;
  // expected statistics (legal / error / etc.)
  longint       x_req = 0, x_legal = 0, x_rd = 0, x_wr = 0, x_posted = 0, x_brd = 0, x_bwr = 0, x_errrsp = 0, x_rsp = 0;
  longint       x_bank [NB];
  longint       n_m_resp = 0, n_t_resp = 0, n_posted_done = 0, n_issued = 0, n_decerr = 0;
  longint       lat_sum_tb = 0, lat_n_tb = 0, lat_max_tb = 0, lat_min_tb = 64'h7fff_ffff;
  int           t_acc_cyc [NTP][64];             // target-accept cycle FIFO per slice (latency measurement)

  initial begin
    for (int i = 0; i < CAP_BYTES; i++) ref_mem[i] = 8'h00;
    for (int i = 0; i < CAP_BYTES/16; i++) ue_line[i] = 1'b0;
    for (int p = 0; p < NPAIR; p++) begin tq_wp[p] = 0; tq_ap[p] = 0; tq_rp[p] = 0; rq_wp[p] = 0; rq_rp[p] = 0; end
    for (int t = 0; t < NTP; t++) begin sf_wp[t] = 0; sf_rp[t] = 0; end
    for (int c = 0; c < NCP; c++) begin cp_wp[c] = 0; cp_rp[c] = 0; end
    for (int b = 0; b < NB; b++) x_bank[b] = 0;
  end

  function automatic int slice_of(input logic [AW-1:0] a);
    int r;
    begin
      r = -1;
      for (int t = 0; t < NTP; t++) if ((a & ~WMASK) == win_base(t)) r = t;
      slice_of = r;
    end
  endfunction

  function automatic logic fab_ok(input logic [2:0] op, input logic [AW-1:0] a);
    begin
      fab_ok = (op <= 3'd2) && (slice_of(a) >= 0) && ((CHK_ALIGN == 0) || (a[$clog2(SB)-1:0] == '0));
    end
  endfunction

  // apply entry e (target-bound) of slice t at the controller-accept edge: byte model + expectation
  task automatic apply_entry(input int e, input int t);
    logic [AW-1:0] off;
    logic [2:0] cause;
    int ln;
    logic full_line;
    begin
      off = e_addr[e] & WMASK;
      cause = `SDF_CAUSE_NONE;
      if (e_op[e] > 3'd2) cause = `SDF_CAUSE_OPCODE;
      else if ((e_addr[e] & ~WMASK) != win_base(t)) cause = `SDF_CAUSE_ADDR;
      else if ({1'b0, off} < (AW+1)'(ALLOW_LO) || ({1'b0, off} + (AW+1)'(SB)) > (AW+1)'(ALLOW_HI)) cause = `SDF_CAUSE_ADDR;
      else if (off[$clog2(SB)-1:0] != '0) cause = `SDF_CAUSE_ALIGN;
      e_xop[e] = e_op[e];
      e_xrd[e] = '0;
      e_xcause[e] = cause;
      e_xst[e] = (cause == `SDF_CAUSE_NONE) ? 2'd0 : 2'd1;
      x_req++;
      if (cause == `SDF_CAUSE_NONE) begin
        ln = int'(off >> 4);
        x_legal++;
        x_bank[ln % NB]++;
        if (e_op[e] == `SDF_OP_READ) begin
          x_rd++;
          x_brd += SB;
          if (ue_line[ln]) begin
            e_xst[e] = 2'd1; e_xcause[e] = `SDF_CAUSE_ECC;
          end else begin
            for (int b = 0; b < SB; b++) e_xrd[e][8*b +: 8] = ref_mem[int'(off) + b];
          end
        end else begin
          x_wr++;
          if (e_op[e] == `SDF_OP_WRITE_POSTED) x_posted++;
          for (int b = 0; b < SB; b++) if (e_wstrb[e][b]) x_bwr++;
          if (e_wstrb[e] != '0) begin
            full_line = (DW == LINE_W) && (e_wstrb[e] == {SB{1'b1}});
            if (ue_line[ln] && !full_line) begin
              e_xst[e] = 2'd1; e_xcause[e] = `SDF_CAUSE_ECC;                     // partial write onto an uncorrectable line: aborted
            end else begin
              for (int b = 0; b < SB; b++) if (e_wstrb[e][b]) ref_mem[int'(off) + b] = e_wdata[e][8*b +: 8];
              if (full_line) ue_line[ln] = 1'b0;                                 // a full-line write repairs the line
            end
          end
        end
      end
      e_filled[e] = 1'b1;
    end
  endtask

  // ================================================================ master agents (command scripts)
  int           ncmd [NM];
  int           cptr [NM];
  int           gapc [NM];
  logic [2:0]   cmd_op [NM*MAXCMD];
  int           cmd_id [NM*MAXCMD];
  logic [AW-1:0] cmd_addr [NM*MAXCMD];
  logic [DW-1:0] cmd_wdata [NM*MAXCMD];
  logic [SB-1:0] cmd_wstrb [NM*MAXCMD];
  int           cmd_gap [NM*MAXCMD];
  logic [31:0]  rngm [NM];
  logic         agents_on = 1'b0;
  int           m_infl [NM];
  int           out_lim = 8;
  logic [31:0]  rstate;

  initial begin
    for (int m = 0; m < NM; m++) begin ncmd[m] = 0; cptr[m] = 0; gapc[m] = 0; m_infl[m] = 0; rngm[m] = seed_mix(SEED, 32'(m + 100)); end
  end

  // ================================================================ burst masters: sf_sdf_burst_seq as NoC masters (indices NMS..NM-1)
  localparam int NBX = (NBURST > 0) ? NBURST : 1;
  localparam int BLW = $clog2(MAXB + 1) + 1;
  localparam int BBW = $clog2(MAXB / SB + 2) + 1;
  localparam int NBQ = NBCMD + 400;
  localparam int MAXBEAT = MAXB / SB + 3;
  logic [NBX-1:0]     bcmd_valid, bcmd_ready;
  logic [3*NBX-1:0]   bcmd_op;
  logic [AW*NBX-1:0]  bcmd_addr;
  logic [BLW*NBX-1:0] bcmd_len;
  logic [IDW*NBX-1:0] bcmd_id;
  logic [NBX-1:0]     bwd_valid, bwd_ready;
  logic [DW*NBX-1:0]  bwd_data;
  logic [NBX-1:0]     brd_valid, brd_ready, brd_last;
  logic [DW*NBX-1:0]  brd_data;
  logic [SB*NBX-1:0]  brd_strb;
  logic [2*NBX-1:0]   brd_status;
  logic [NBX-1:0]     bdone_valid, bdone_ready;
  logic [IDW*NBX-1:0] bdone_id;
  logic [2*NBX-1:0]   bdone_status;
  logic [3*NBX-1:0]   bdone_reason;
  logic [BBW*NBX-1:0] bdone_beats, bdone_errbeat;
  logic [BLW*NBX-1:0] bdone_bytes;
  logic [NBX-1:0]     bm_req_valid, bm_rsp_ready;
  logic [32*NBX-1:0]  bst_bursts, bst_rej, bst_beats, bst_bytes, bst_wire, bst_errb, bst_proto;
  initial begin bcmd_valid = '0; bwd_valid = '0; bcmd_op = '0; bcmd_addr = '0; bcmd_len = '0; bcmd_id = '0; bwd_data = '0; end

  for (genvar b = 0; b < NBURST; b++) begin : g_burst
    localparam logic [AW:0] LO = {1'b0, 32'h2000_0000} + (AW+1)'((b % NTP) * 32'h0010_0000);
    sf_sdf_burst_seq #(.AW(AW), .DW(DW), .IDW(IDW), .MAX_BYTES(MAXB), .RD_FIFO(BRD_FIFO), .MAX_OUT(BMAXOUT),
                       .LIM_LO(LO), .LIM_HI(LO + (AW+1)'(WIN_SIZE))) u_seq (
      .clk(clk), .rst_n(rst_n),
      .cmd_valid(bcmd_valid[b]), .cmd_ready(bcmd_ready[b]), .cmd_op(bcmd_op[b*3 +: 3]), .cmd_addr(bcmd_addr[b*AW +: AW]),
      .cmd_len(bcmd_len[b*BLW +: BLW]), .cmd_id(bcmd_id[b*IDW +: IDW]), .cmd_qos(3'd0),
      .wd_valid(bwd_valid[b]), .wd_ready(bwd_ready[b]), .wd_data(bwd_data[b*DW +: DW]), .wd_lane_mask_o(),
      .rd_valid(brd_valid[b]), .rd_ready(brd_ready[b]), .rd_data(brd_data[b*DW +: DW]), .rd_strb(brd_strb[b*SB +: SB]),
      .rd_last(brd_last[b]), .rd_status(brd_status[b*2 +: 2]),
      .done_valid(bdone_valid[b]), .done_ready(bdone_ready[b]), .done_id(bdone_id[b*IDW +: IDW]),
      .done_status(bdone_status[b*2 +: 2]), .done_reason(bdone_reason[b*3 +: 3]), .done_beats(bdone_beats[b*BBW +: BBW]),
      .done_err_beat(bdone_errbeat[b*BBW +: BBW]), .done_bytes(bdone_bytes[b*BLW +: BLW]),
      .m_req_valid(bm_req_valid[b]), .m_req_ready(m_req_ready[NMS + b]), .m_req_opcode(m_req_opcode[(NMS+b)*3 +: 3]),
      .m_req_id(m_req_id[(NMS+b)*IDW +: IDW]), .m_req_qos(m_req_qos[(NMS+b)*3 +: 3]), .m_req_addr(m_req_addr[(NMS+b)*AW +: AW]),
      .m_req_wdata(m_req_wdata[(NMS+b)*DW +: DW]), .m_req_wstrb(m_req_wstrb[(NMS+b)*SB +: SB]),
      .m_rsp_valid(m_rsp_valid[NMS + b]), .m_rsp_ready(bm_rsp_ready[b]), .m_rsp_id(m_rsp_id[(NMS+b)*IDW +: IDW]),
      .m_rsp_opcode(m_rsp_opcode[(NMS+b)*3 +: 3]), .m_rsp_status(m_rsp_status[(NMS+b)*2 +: 2]),
      .m_rsp_rdata(m_rsp_rdata[(NMS+b)*DW +: DW]),
      .cnt_clr_i(1'b0), .st_bursts_o(bst_bursts[b*32 +: 32]), .st_rejected_o(bst_rej[b*32 +: 32]), .st_beats_o(bst_beats[b*32 +: 32]),
      .st_bytes_o(bst_bytes[b*32 +: 32]), .st_wire_bytes_o(bst_wire[b*32 +: 32]), .st_errbeats_o(bst_errb[b*32 +: 32]),
      .st_busy_o(), .st_req_stall_o(), .st_data_starve_o(), .st_credit_stall_o(), .st_rd_stall_o(), .st_proto_o(bst_proto[b*32 +: 32]),
      .busy_o());
    assign m_req_valid[NMS + b] = bm_req_valid[b];
    assign m_rsp_ready[NMS + b] = bm_rsp_ready[b];
  end

  // scripts and state of the burst drivers
  int           bq_n [NBX], bq_i [NBX], bst [NBX];
  logic [2:0]   bq_op [NBX*NBQ];
  logic [AW-1:0] bq_addr [NBX*NBQ];
  int           bq_len [NBX*NBQ], bq_id [NBX*NBQ];
  logic         bq_pair [NBX*NBQ];                // read burst whose bytes must equal the payload of the previous write burst
  int           bc_serial [NBX];                  // command serial number (payload seed)
  logic [2:0]   bc_op [NBX];
  logic [AW-1:0] bc_addr [NBX];
  int           bc_len [NBX], bc_id [NBX], bc_nb [NBX], bc_j [NBX], bws_j [NBX], brd_j [NBX], bcap_n [NBX], bw_gap [NBX];
  logic         bc_acc [NBX], bd_seen [NBX], bc_rej [NBX], bc_pair [NBX];
  logic [2:0]   bc_rjr [NBX];
  logic [1:0]   bd_status [NBX];
  logic [2:0]   bd_reason [NBX];
  int           bd_beats [NBX], bd_eb [NBX], bd_bytes [NBX], bd_id [NBX];
  int           pair_serial [NBX];
  logic [DW-1:0] cap_rd [NBX*MAXBEAT];
  logic [1:0]   cap_st [NBX*MAXBEAT];
  logic [31:0]  rngb [NBX];
  int           x_bb_bursts = 0, x_bb_rej = 0, x_bb_beats = 0, x_bb_bytes = 0, x_bb_wire = 0, x_bb_errb = 0, x_bb_cmds = 0;
  initial for (int b = 0; b < NBX; b++) begin bq_n[b] = 0; bq_i[b] = 0; bst[b] = 0; bc_serial[b] = b * 100000; rngb[b] = seed_mix(SEED, 32'(b + 700)); end

  function automatic logic [7:0] bpb(input int n, input int k);
    logic [31:0] h;
    begin h = seed_mix(32'(n * 977 + k * 131 + 17), 32'(k + 3)); bpb = h[15:8] ^ h[7:0]; end
  endfunction
  function automatic logic [7:0] bjunk(input int j, input int l);
    bjunk = 8'(j * 41 + l * 13 + 8'h5A);
  endfunction
  function automatic logic [SB-1:0] bexp_strb(input logic [AW-1:0] a, input int len, input int j);
    logic [SB-1:0] m;
    int ba;
    begin
      m = '0;
      for (int k = 0; k < SB; k++) begin
        ba = int'(a & ~AW'(SB - 1)) + j * SB + k;
        if (ba >= int'(a) && ba < int'(a) + len) m[k] = 1'b1;
      end
      bexp_strb = m;
    end
  endfunction
  function automatic logic [2:0] bexp_reject(input logic [2:0] op, input logic [AW-1:0] a, input int len, input int bi);
    longint la, le, lo, hi;
    begin
      la = longint'(a); le = la + longint'(len);
      lo = longint'(win_base(bi % NTP)); hi = lo + WIN_SIZE;
      if (op > 3'd2) bexp_reject = `SDF_RJ_OPCODE;
      else if (len == 0) bexp_reject = `SDF_RJ_ZERO;
      else if (len > MAXB) bexp_reject = `SDF_RJ_TOOLONG;
      else if (le - 1 >= (64'd1 << 32)) bexp_reject = `SDF_RJ_WRAP;
      else if (la < lo || le > hi) bexp_reject = `SDF_RJ_RANGE;
      else bexp_reject = `SDF_RJ_NONE;
    end
  endfunction
  // beat is an error beat at the bridge: beyond the allowed range of the SRAM (SLVERR)
  function automatic int bbeat_err(input logic [AW-1:0] beat_addr);
    logic [AW-1:0] off;
    begin
      off = beat_addr & WMASK;
      bbeat_err = (off < AW'(ALLOW_LO) || (off + AW'(SB)) > AW'(ALLOW_HI)) ? 1 : 0;
    end
  endfunction

  task automatic bq_add(input int b, input logic [2:0] op, input logic [AW-1:0] a, input int len, input int id, input logic pair);
    int i;
    begin
      i = b * NBQ + bq_n[b];
      bq_op[i] = op; bq_addr[i] = a; bq_len[i] = len; bq_id[i] = id % NID; bq_pair[i] = pair;
      bq_n[b]++;
    end
  endtask

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      bcmd_valid <= '0; bwd_valid <= '0; brd_ready <= '0; bdone_ready <= '0;
      for (int b = 0; b < NBURST; b++) begin bst[b] = 0; bq_i[b] = bq_n[b]; bc_acc[b] = 1'b0; end
    end else begin
      for (int b = 0; b < NBURST; b++) begin
        int m;
        m = NMS + b;
        rngb[b] = xs32(rngb[b]);
        brd_ready[b]   <= (int'(rngb[b][11:4] % 100) >= P_RSP_STALL) || !agents_on;
        bdone_ready[b] <= (int'(rngb[b][19:12] % 100) >= P_RSP_STALL) || !agents_on;
        // ---- beat conformance at the NoC master port: the beats are exactly what the burst command means
        if (m_req_valid[m] && m_req_ready[m]) begin
          logic [SB-1:0] es;
          es = bexp_strb(bc_addr[b], bc_len[b], bc_j[b]);
          check(bc_acc[b] && !bc_rej[b], "burst master issued a beat outside an accepted command");
          check(bc_j[b] < bc_nb[b], "burst master issued more beats than the burst needs");
          check(m_req_opcode[m*3 +: 3] == bc_op[b] && int'(m_req_id[m*IDW +: IDW]) == bc_id[b], "burst beat opcode / id");
          check(m_req_addr[m*AW +: AW] == (bc_addr[b] & ~AW'(SB - 1)) + AW'(bc_j[b] * SB), "burst beat address not consecutive");
          if (bc_op[b] != `SDF_OP_READ) begin
            check(m_req_wstrb[m*SB +: SB] == es, $sformatf("burst beat %0d strobe %h != %h", bc_j[b], m_req_wstrb[m*SB +: SB], es));
            for (int k = 0; k < SB; k++) if (es[k])
              check(m_req_wdata[m*DW + 8*k +: 8] == bpb(bc_serial[b], int'(bc_addr[b] & ~AW'(SB - 1)) + bc_j[b] * SB + k - int'(bc_addr[b])), "burst beat data byte");
          end
          bc_j[b]++;
        end
        // ---- capture of the beat responses seen by the master (statuses and read words)
        if (m_rsp_valid[m] && bm_rsp_ready[b]) begin
          if (bcap_n[b] < MAXBEAT) begin cap_rd[b*MAXBEAT + bcap_n[b]] = m_rsp_rdata[m*DW +: DW]; cap_st[b*MAXBEAT + bcap_n[b]] = m_rsp_status[m*2 +: 2]; end
          bcap_n[b]++;
        end
        // ---- write data stream
        if (bst[b] == 2 && bc_op[b] != `SDF_OP_READ && !bc_rej[b]) begin
          if (bwd_valid[b] && bwd_ready[b]) begin bws_j[b]++; bwd_valid[b] <= 1'b0; end
          if (!bwd_valid[b] || bwd_ready[b]) begin
            if (bws_j[b] < bc_nb[b] && (int'(rngb[b][27:21]) * 100 / 128 >= P_REQ_IDLE || bw_gap[b] > 5)) begin
              logic [DW-1:0] w;
              for (int k = 0; k < SB; k++) begin
                int kk;
                kk = int'(bc_addr[b] & ~AW'(SB - 1)) + bws_j[b] * SB + k - int'(bc_addr[b]);
                w[8*k +: 8] = (kk >= 0 && kk < bc_len[b]) ? bpb(bc_serial[b], kk) : bjunk(bws_j[b], k);
              end
              bwd_valid[b] <= 1'b1; bwd_data[b*DW +: DW] <= w; bw_gap[b] = 0;
            end else if (bws_j[b] < bc_nb[b]) bw_gap[b]++;
          end
        end else if (!(bwd_valid[b] && !bwd_ready[b])) bwd_valid[b] <= 1'b0;
        // ---- read data consumer: forwarded data == what the master received, valid mask, last flag, status
        if (brd_valid[b] && brd_ready[b]) begin
          logic [SB-1:0] es;
          int j;
          j = brd_j[b];
          es = bexp_strb(bc_addr[b], bc_len[b], j);
          check(bc_op[b] == `SDF_OP_READ && !bc_rej[b], "read beat delivered for a non-read burst");
          check(j < bc_nb[b], "more read beats than the burst has");
          check(brd_strb[b*SB +: SB] == es, $sformatf("burst read beat %0d valid mask %h != %h", j, brd_strb[b*SB +: SB], es));
          check(brd_last[b] == (j == bc_nb[b] - 1), "burst read rd_last");
          if (j < MAXBEAT) begin
            check(brd_status[b*2 +: 2] == cap_st[b*MAXBEAT + j], "burst read status differs from the beat response");
            for (int k = 0; k < SB; k++) if (es[k]) begin
              check(brd_data[b*DW + 8*k +: 8] == cap_rd[b*MAXBEAT + j][8*k +: 8], "burst read data differs from the beat response");
              if (bc_pair[b] && cap_st[b*MAXBEAT + j] == 2'd0)
                check(brd_data[b*DW + 8*k +: 8] == bpb(pair_serial[b], int'(bc_addr[b] & ~AW'(SB - 1)) + j * SB + k - int'(bc_addr[b])),
                      $sformatf("burst read-back byte != payload written by the previous burst (beat %0d lane %0d)", j, k));
            end
          end
          brd_j[b]++;
        end
        // ---- completion capture
        if (bdone_valid[b] && bdone_ready[b]) begin
          check(!bd_seen[b], "second completion for one burst");
          bd_seen[b] = 1'b1; bd_status[b] = bdone_status[b*2 +: 2]; bd_reason[b] = bdone_reason[b*3 +: 3];
          bd_beats[b] = int'(bdone_beats[b*BBW +: BBW]); bd_eb[b] = int'(bdone_errbeat[b*BBW +: BBW]);
          bd_bytes[b] = int'(bdone_bytes[b*BLW +: BLW]); bd_id[b] = int'(bdone_id[b*IDW +: IDW]);
        end
        // ---- driver FSM
        case (bst[b])
          0: if (agents_on && bq_i[b] < bq_n[b] && !bdone_valid[b]) begin
            int i;
            i = b * NBQ + bq_i[b];
            bc_op[b] = bq_op[i]; bc_addr[b] = bq_addr[i]; bc_len[b] = bq_len[i]; bc_id[b] = bq_id[i]; bc_pair[b] = bq_pair[i];
            pair_serial[b] = bc_serial[b];
            bc_serial[b]++;
            bc_rjr[b] = bexp_reject(bc_op[b], bc_addr[b], bc_len[b], b);
            bc_rej[b] = (bc_rjr[b] != `SDF_RJ_NONE);
            bc_nb[b] = bc_rej[b] ? 0 : int'(((bc_addr[b] + AW'(bc_len[b]) - 1) >> $clog2(SB)) - (bc_addr[b] >> $clog2(SB)) + 1);
            bc_j[b] = 0; bws_j[b] = 0; brd_j[b] = 0; bcap_n[b] = 0; bw_gap[b] = 0; bc_acc[b] = 1'b0; bd_seen[b] = 1'b0;
            bcmd_valid[b] <= 1'b1; bcmd_op[b*3 +: 3] <= bc_op[b]; bcmd_addr[b*AW +: AW] <= bc_addr[b];
            bcmd_len[b*BLW +: BLW] <= BLW'(bc_len[b]); bcmd_id[b*IDW +: IDW] <= IDW'(bc_id[b]);
            bst[b] = 1;
          end
          1: if (bcmd_valid[b] && bcmd_ready[b]) begin bcmd_valid[b] <= 1'b0; bc_acc[b] = 1'b1; bst[b] = 2; end
          2: if (bd_seen[b]) begin
            // ---- completion checks
            int exp_stat, exp_eb, ne;
            exp_stat = 0; exp_eb = 0; ne = 0;
            if (bc_rej[b]) exp_stat = 3;
            else if (bc_op[b] != `SDF_OP_WRITE_POSTED) begin
              for (int j = 0; j < bc_nb[b]; j++) begin
                int e;
                e = bbeat_err((bc_addr[b] & ~AW'(SB - 1)) + AW'(j * SB));
                if (e != 0) begin if (exp_stat == 0) begin exp_stat = 1; exp_eb = j; end ne++; end
              end
            end
            check(bd_status[b] == 2'(exp_stat), $sformatf("burst completion status %0d != %0d (op %0d addr %h len %0d)", bd_status[b], exp_stat, bc_op[b], bc_addr[b], bc_len[b]));
            check(bd_id[b] == bc_id[b], "burst completion id");
            if (bc_rej[b]) begin
              check(bd_reason[b] == bc_rjr[b], $sformatf("burst reject reason %0d != %0d", bd_reason[b], bc_rjr[b]));
              check(bd_beats[b] == 0 && bc_j[b] == 0, "rejected burst issued beats");
              x_bb_rej++;
            end else begin
              check(bd_beats[b] == bc_nb[b] && bc_j[b] == bc_nb[b], $sformatf("burst beats %0d/%0d != %0d", bd_beats[b], bc_j[b], bc_nb[b]));
              check(bd_bytes[b] == bc_len[b], "burst completion bytes");
              if (exp_stat != 0) check(bd_eb[b] == exp_eb, $sformatf("first error beat %0d != %0d", bd_eb[b], exp_eb));
              if (bc_op[b] == `SDF_OP_READ) check(brd_j[b] == bc_nb[b], "burst read beats delivered");
              if (bc_op[b] != `SDF_OP_READ) check(bws_j[b] == bc_nb[b], "burst write beats consumed");
              if (bc_op[b] != `SDF_OP_WRITE_POSTED) check(bcap_n[b] == bc_nb[b], "burst beat responses seen by the master");
              x_bb_bursts++; x_bb_beats += bc_nb[b]; x_bb_bytes += bc_len[b]; x_bb_wire += bc_nb[b] * SB; x_bb_errb += ne;
            end
            x_bb_cmds++;
            bq_i[b]++;
            bst[b] = 0;
          end
          default: bst[b] = 0;
        endcase
      end
    end
  end

  function automatic logic all_idle();
    logic r;
    begin
      r = 1'b1;
      for (int m = 0; m < NMS; m++) if (cptr[m] < ncmd[m] || m_req_valid[m] || m_infl[m] != 0) r = 1'b0;
      for (int b = 0; b < NBURST; b++) if (bst[b] != 0 || bq_i[b] < bq_n[b] || m_infl[NMS + b] != 0) r = 1'b0;
      all_idle = r;
    end
  endfunction

  task automatic cmd_add(input int m, input logic [2:0] op, input int id, input logic [AW-1:0] a, input logic [DW-1:0] wd,
                         input logic [SB-1:0] ws, input int gap);
    int i;
    begin
      if (m < NMS) begin
      i = m * MAXCMD + ncmd[m];
      cmd_op[i] = op; cmd_id[i] = id; cmd_addr[i] = a; cmd_wdata[i] = wd; cmd_wstrb[i] = ws; cmd_gap[i] = gap;
      ncmd[m]++;
      end
    end
  endtask

  // the issued byte-lane view of a request is bit-exact what the master drives
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ms_req_valid <= '0; ms_req_opcode <= '0; ms_req_id <= '0; ms_req_qos <= '0; ms_req_addr <= '0; ms_req_wdata <= '0;
      ms_req_wstrb <= '0; ms_rsp_ready <= '0;
    end else begin
      for (int m = 0; m < NMS; m++) begin
        rngm[m] = xs32(rngm[m]);
        ms_rsp_ready[m] <= (int'(rngm[m][15:8] % 100) >= P_RSP_STALL) || !agents_on;
        if (!agents_on) begin
          if (!(ms_req_valid[m] && !m_req_ready[m])) ms_req_valid[m] <= 1'b0;
        end else if (!ms_req_valid[m] || m_req_ready[m]) begin
          if (cptr[m] < ncmd[m] && m_infl[m] < out_lim) begin
            if (gapc[m] > 0) begin
              gapc[m] <= gapc[m] - 1;
              ms_req_valid[m] <= 1'b0;
            end else if (int'(rngm[m][23:16] % 100) < P_REQ_IDLE) begin
              ms_req_valid[m] <= 1'b0;
            end else begin
              int i;
              i = m * MAXCMD + cptr[m];
              ms_req_valid[m] <= 1'b1;
              ms_req_opcode[m*3 +: 3] <= cmd_op[i];
              ms_req_id[m*IDW +: IDW] <= IDW'(cmd_id[i]);
              ms_req_qos[m*3 +: 3] <= rngm[m][26:24];
              ms_req_addr[m*AW +: AW] <= cmd_addr[i];
              ms_req_wdata[m*DW +: DW] <= cmd_wdata[i];
              ms_req_wstrb[m*SB +: SB] <= cmd_wstrb[i];
              gapc[m] <= cmd_gap[i];
              cptr[m] <= cptr[m] + 1;
            end
          end else ms_req_valid[m] <= 1'b0;
        end
      end
    end
  end
  // (cptr advances when a request is PRESENTED; it stays presented until accepted: R2)

  // ================================================================ monitors / scoreboard events
  logic [NCP-1:0] ctl_req_acc, ctl_rsp_hs;
  logic           c_flush_q = 1'b0;
  always @(posedge clk) begin
    cycle <= cycle + 1;
  end

  always @(posedge clk) if (rst_n) begin
    // ---- 1. master accepts: create entries
    for (int m = 0; m < NM; m++) begin
      if (m_req_valid[m] && m_req_ready[m]) begin
        int e, pr, id;
        logic [2:0] op;
        logic [AW-1:0] a;
        e = ent_n % NENT; ent_n++;
        id = int'(m_req_id[m*IDW +: IDW]);
        op = m_req_opcode[m*3 +: 3];
        a  = m_req_addr[m*AW +: AW];
        pr = m * NID + id;
        e_op[e] = op; e_addr[e] = a; e_wdata[e] = m_req_wdata[m*DW +: DW]; e_wstrb[e] = m_req_wstrb[m*SB +: SB];
        e_m[e] = m; e_id[e] = id; e_filled[e] = 1'b0; e_lost[e] = 1'b0; e_cause_any[e] = 1'b0; e_acc_cyc[e] = cycle;
        e_slice[e] = (NOC != 0) ? slice_of(a) : m;
        n_issued++;
        m_infl[m] = m_infl[m] + 1;
        if (NOC != 0 && op == `SDF_OP_FENCE) begin
          e_target[e] = 1'b0; e_filled[e] = 1'b1; e_xop[e] = op; e_xst[e] = 2'd0; e_xcause[e] = 3'd0; e_xrd[e] = '0;
          rq[pr][rq_wp[pr] % RING] = e; rq_wp[pr]++;
        end else if (NOC != 0 && !fab_ok(op, a)) begin
          n_decerr++;
          if (op == `SDF_OP_WRITE_POSTED) begin
            m_infl[m] = m_infl[m] - 1;                          // accepted and dropped by the fabric: no response exists
          end else begin
            e_target[e] = 1'b0; e_filled[e] = 1'b1; e_xop[e] = op; e_xst[e] = 2'd2; e_xcause[e] = 3'd0; e_xrd[e] = '0;
            rq[pr][rq_wp[pr] % RING] = e; rq_wp[pr]++;
          end
        end else begin
          e_target[e] = 1'b1;
          tq[pr][tq_wp[pr] % RING] = e; tq_wp[pr]++;
          if (NOC != 0 && op != `SDF_OP_WRITE_POSTED) begin rq[pr][rq_wp[pr] % RING] = e; rq_wp[pr]++; end
        end
      end
    end
    // ---- 2. target accepts: match the oldest unmatched target-bound entry of (src,id)
    for (int t = 0; t < NTP; t++) begin
      if (t_req_valid[t] && t_req_ready[t]) begin
        int pr, e;
        pr = int'(t_req_src[t*SRCW +: SRCW]) * NID + int'(t_req_id[t*IDW +: IDW]);
        check(tq_ap[pr] < tq_wp[pr], "target accepted a request no master issued (src,id)");
        if (tq_ap[pr] < tq_wp[pr]) begin
          e = tq[pr][tq_ap[pr] % RING]; tq_ap[pr]++;
          check(e_op[e] == t_req_opcode[t*3 +: 3] && e_addr[e] == t_req_addr[t*AW +: AW] && e_wdata[e] == t_req_wdata[t*DW +: DW] &&
                e_wstrb[e] == t_req_wstrb[t*SB +: SB], "target-port request differs from the master's request");
          check(e_slice[e] == t, "request reached the wrong target port");
          e_tacc[e] = cycle;
          sfq[t][sf_wp[t] % 64] = e; sf_wp[t]++;
        end
      end
    end
    // ---- 3. controller accepts (serialisation point): apply, cross-check the bridge's controller request
    for (int cp = 0; cp < NCP; cp++) begin
      if (c_req_valid[cp] && c_req_ready[cp]) begin
        int t, e;
        t = cp / NP;
        check(sf_rp[t] < sf_wp[t], "controller accepted a request with no pending target-port request");
        if (sf_rp[t] < sf_wp[t]) begin
          e = sfq[t][sf_rp[t] % 64]; sf_rp[t]++;
          e_ctl_cyc[e] = cycle;
          apply_entry(e, t);
          cpq[cp][cp_wp[cp] % CPQ] = e; cp_wp[cp]++;
          // white-box translation check against the independent decode
          if (e_xcause[e] == `SDF_CAUSE_NONE || e_xcause[e] == `SDF_CAUSE_ECC) begin
            logic [AW-1:0] off2;
            off2 = e_addr[e] & WMASK;
            check(c_req_addr[cp*AW +: AW] == {off2[AW-1:4], 4'b0}, "bridge controller address != independent line address");
            check(c_req_we[cp] == (e_op[e] != `SDF_OP_READ), "bridge controller we mismatch");
            if (e_op[e] != `SDF_OP_READ) begin
              for (int b = 0; b < SB; b++) begin
                check(c_req_be[cp*16 + int'(off2[3:0]) + b] == e_wstrb[e][b], "bridge byte enable placement mismatch");
                if (e_wstrb[e][b]) check(c_req_wdata[cp*LINE_W + 8*(int'(off2[3:0]) + b) +: 8] == e_wdata[e][8*b +: 8], "bridge write data lane mismatch");
              end
              check((c_req_be[cp*16 +: 16] & ~(((16'(1) << SB) - 16'(1)) << int'(off2[3:0]))) == 16'd0, "bridge byte enable outside the beat lane");
            end
          end else begin
            check(c_req_we[cp] == 1'b0, "illegal request must not be a write at the controller");
            check(c_req_addr[cp*AW +: AW] == {AW{1'b1}}, "illegal request not redirected to the rejected address");
          end
          check(c_req_id[cp*IDC + IDC - 1] == (e_xcause[e] != `SDF_CAUSE_NONE && e_xcause[e] != `SDF_CAUSE_ECC), "bad flag in controller id");
        end
      end
    end
    // ---- 4. controller responses handshaken at the shim (entry completed at the controller)
    for (int cp = 0; cp < NCP; cp++) begin
      if (ctl_rsp_valid[cp] && ctl_rsp_ready[cp]) begin
        check(cp_rp[cp] < cp_wp[cp], "controller response with nothing in flight (orphan)");
        if (cp_rp[cp] < cp_wp[cp]) cp_rp[cp]++;
      end
    end
    // ---- 5. flush: everything applied and not yet answered by the controller is lost
    if (c_flush_i && !c_flush_q) begin
      for (int cp = 0; cp < NCP; cp++) begin
        while (cp_rp[cp] < cp_wp[cp]) begin
          int e;
          e = cpq[cp][cp_rp[cp] % CPQ]; cp_rp[cp]++;
          e_lost[e] = 1'b1; e_xst[e] = 2'd1; e_xrd[e] = '0; e_xcause[e] = lost_cause; lost_total++;
        end
      end
    end
    c_flush_q <= c_flush_i;
    // ---- 6. target responses
    for (int t = 0; t < NTP; t++) begin
      if (t_rsp_valid[t] && t_rsp_ready[t]) begin
        int pr, e;
        pr = int'(t_rsp_src[t*SRCW +: SRCW]) * NID + int'(t_rsp_id[t*IDW +: IDW]);
        check(tq_rp[pr] < tq_ap[pr], "target response for a request not accepted (src,id)");
        if (tq_rp[pr] < tq_ap[pr]) begin
          e = tq[pr][tq_rp[pr] % RING]; tq_rp[pr]++;
          check(e_filled[e], "target response before the request was applied at the controller");
          check(t_rsp_opcode[t*3 +: 3] == e_op[e], "target response opcode echo");
          check(t_rsp_status[t*2 +: 2] == e_xst[e], $sformatf("target status %0d != expected %0d (op %0d addr %h cause %0d)",
                t_rsp_status[t*2 +: 2], e_xst[e], e_op[e], e_addr[e], e_xcause[e]));
          check(rsp_cause[t*3 +: 3] == e_xcause[e], $sformatf("target cause %0d != expected %0d", rsp_cause[t*3 +: 3], e_xcause[e]));
          check(t_rsp_rdata[t*DW +: DW] == e_xrd[e], $sformatf("target rdata mismatch op %0d addr %h got %h exp %h", e_op[e], e_addr[e],
                t_rsp_rdata[t*DW +: DW], e_xrd[e]));
          n_t_resp++;
          if (!e_lost[e]) begin
            lat_sum_tb += (cycle - e_tacc[e]); lat_n_tb++;
            if (cycle - e_tacc[e] > lat_max_tb) lat_max_tb = cycle - e_tacc[e];
            if (cycle - e_tacc[e] < lat_min_tb) lat_min_tb = cycle - e_tacc[e];
          end
          if (e_xst[e] != 2'd0) x_errrsp++;
          x_rsp++;
          if (NOC == 0) begin
            m_infl[e_m[e]] = m_infl[e_m[e]] - 1;
          end else if (e_op[e] == `SDF_OP_WRITE_POSTED) begin
            m_infl[e_m[e]] = m_infl[e_m[e]] - 1;
            n_posted_done++;
          end
        end
      end
    end
    // ---- 7. master responses
    for (int m = 0; m < NM; m++) begin
      if (m_rsp_valid[m] && m_rsp_ready[m] && NOC != 0) begin
        int pr, e;
        pr = m * NID + int'(m_rsp_id[m*IDW +: IDW]);
        check(rq_rp[pr] < rq_wp[pr], "master received a response it did not expect (id)");
        if (rq_rp[pr] < rq_wp[pr]) begin
          e = rq[pr][rq_rp[pr] % RING]; rq_rp[pr]++;
          check(e_filled[e], "master response before the transaction completed at the target");
          check(m_rsp_opcode[m*3 +: 3] == e_op[e], "master response opcode echo");
          check(m_rsp_status[m*2 +: 2] == e_xst[e], $sformatf("master status %0d != expected %0d (op %0d addr %h)", m_rsp_status[m*2 +: 2],
                e_xst[e], e_op[e], e_addr[e]));
          check(m_rsp_rdata[m*DW +: DW] == e_xrd[e], $sformatf("master rdata mismatch op %0d addr %h got %h exp %h", e_op[e], e_addr[e],
                m_rsp_rdata[m*DW +: DW], e_xrd[e]));
          n_m_resp++;
          m_infl[m] = m_infl[m] - 1;
        end
      end
    end
  end

  // ================================================================ phase control
  function automatic logic [AW-1:0] rand_addr(input logic [31:0] r, input int hot, input int mode);
    // mode 0: legal aligned inside the capacity; 1: anywhere in the window; 2: anywhere in the address space
    logic [AW-1:0] a;
    int n;
    begin
      n = (mode == 0) ? CAP_BYTES : WIN_SIZE;
      if (hot != 0) a = AW'((r[19:8] % 16) * SB * 5 % CAP_BYTES);
      else a = AW'((r[31:8]) % n);
      a = a & ~AW'(SB - 1);
      rand_addr = (mode == 2 && r[3:0] == 4'd0) ? {r[7:4], 28'h123456} : (win_base(int'(r[5:4]) % NTP) | a);
    end
  endfunction

  task automatic run_phase(input string name, input int maxcyc);
    int c;
    logic done;
    begin
      tests++;
      for (int m = 0; m < NM; m++) begin cptr[m] = 0; gapc[m] = 0; end
      agents_on = 1'b1;
      c = 0; done = 1'b0;
      while (!done && c < maxcyc) begin
        @(posedge clk);
        c++;
        done = 1'b1;
        if (!all_idle()) done = 1'b0;
      end
      // drain
      repeat (40) @(posedge clk);
      agents_on = 1'b0;
      repeat (4) @(posedge clk);
      tchk_quiet = 1'b1; @(posedge clk); tchk_quiet = 1'b0;
      check(c < maxcyc, {name, ": phase did not complete (hang)"});
      for (int p = 0; p < NPAIR; p++) begin
        check(tq_ap[p] == tq_wp[p] && tq_rp[p] == tq_wp[p], $sformatf("%s: pair %0d: %0d target entries unmatched", name, p, tq_wp[p] - tq_rp[p]));
        check(rq_rp[p] == rq_wp[p], $sformatf("%s: pair %0d: %0d master responses missing", name, p, rq_wp[p] - rq_rp[p]));
      end
      for (int t = 0; t < NTP; t++) check(sf_rp[t] == sf_wp[t], $sformatf("%s: slice %0d: requests not applied", name, t));
      for (int cp = 0; cp < NCP; cp++) check(cp_rp[cp] == cp_wp[cp], $sformatf("%s: controller port %0d: in-flight entries left", name, cp));
      for (int m = 0; m < NM; m++) begin ncmd[m] = 0; cptr[m] = 0; end
      for (int b = 0; b < NBURST; b++) begin bq_n[b] = 0; bq_i[b] = 0; end
      $display("  phase %-18s done in %0d cycles (issued %0d, target responses %0d)", name, c, n_issued, n_t_resp);
    end
  endtask

  task automatic gen_random(input int n, input int hot_pct, input int err_pct, input int posted_pct, input int fence_pct, input int gapmax);
    logic [31:0] r;
    logic [2:0] op;
    logic [AW-1:0] a;
    logic [DW-1:0] wd;
    logic [SB-1:0] ws;
    int id, k, sel;
    begin
      for (int m = 0; m < NM; m++) begin
        for (int i = 0; i < n; i++) begin
          rstate = seed_mix(SEED ^ 32'(i * 7919 + m * 131 + hot_pct), 32'(i + m * 1000));
          r = rstate;
          k = int'(r[7:0] % 100);
          id = int'(r[13:8] % NID);
          sel = int'(r[22:16] % 100);
          r = xs32(r); wd = '0;
          for (int w = 0; w < (DW + 31) / 32; w++) begin r = xs32(r); wd[32*w +: 32] = r; end
          r = xs32(r);
          case (int'(r[3:0]) % 6)
            0: ws = '1; 1: ws = SB'(1) << (r[8:4] % SB); 2: ws = SB'(r); 3: ws = '1; 4: ws = '0; default: ws = SB'(r) | SB'(r >> 7);
          endcase
          r = xs32(r);
          a = rand_addr(r, (int'(r[12:8] % 100) < hot_pct) ? 1 : 0, 0);
          if (sel < err_pct) begin
            case (int'(r[16:13]) % 6)
              0: a = rand_addr(r, 0, 1);                                    // anywhere in the window (upper half: beyond capacity)
              1: a = a | AW'(1);                                            // misaligned (when DW > 8 bits)
              2: a = rand_addr(r, 0, 2);                                    // possibly unmapped
              3: a = win_base(0) + AW'(CAP_BYTES) + AW'(SB * (r[8:4] % 4)); // just beyond capacity
              4: a = win_base(0) + AW'(ALLOW_HI) + AW'(SB * (r[8:4] % 4));  // just beyond the allowed range
              default: a = a ^ AW'(32'h0100_0000);                          // unmapped
            endcase
          end
          if (k < 40) op = `SDF_OP_READ;
          else if (k < 40 + (100 - 40 - posted_pct - fence_pct)) op = `SDF_OP_WRITE;
          else if (k < 100 - fence_pct) op = `SDF_OP_WRITE_POSTED;
          else op = `SDF_OP_FENCE;
          if (sel >= 100 - 2 && err_pct > 0) op = 3'(4 + (r[18:17] % 4));   // reserved opcode 4..7
          if (NOC == 0 && op == `SDF_OP_FENCE) op = `SDF_OP_READ;
          cmd_add(m, op, id, a, wd, ws, (gapmax == 0) ? 0 : int'(r[28:24] % (gapmax + 1)));
        end
      end
    end
  endtask

  // directed helpers
  task automatic add_wr(input int m, input int id, input logic [AW-1:0] a, input logic [DW-1:0] wd, input logic [SB-1:0] ws, input logic posted);
    cmd_add(m, posted ? `SDF_OP_WRITE_POSTED : `SDF_OP_WRITE, id, a, wd, ws, 0);
  endtask
  task automatic add_rd(input int m, input int id, input logic [AW-1:0] a);
    cmd_add(m, `SDF_OP_READ, id, a, '0, '0, 0);
  endtask

  // read back the whole memory (every DW word) through master 0 and compare with the model; backdoor check of the arrays
  task automatic readback(input string name);
    begin
      for (int off = 0; off < CAP_BYTES; off += SB) begin
        if (off >= ALLOW_LO && off + SB <= ALLOW_HI) add_rd(0, (off / SB) % NID, win_base(0) | AW'(off));
      end
      run_phase(name, 400000);
      if (ECC_EN == 0) begin
        dump_req = ~dump_req; #1;
        for (int ln = 0; ln < CAP_BYTES/16; ln++) begin
          for (int b = 0; b < 16; b++)
            check(dump[(ln % NB) * DEPTH + (ln / NB)][8*b +: 8] === ref_mem[ln*16 + b],
                  $sformatf("backdoor: line %0d byte %0d in the bank array != model", ln, b));
        end
      end
    end
  endtask

  int expect_to = 0;
  // perf counter cross-check (sum over slices)
  task automatic check_counters(input string name);
    longint s_req, s_legal, s_rd, s_wr, s_post, s_brd, s_bwr, s_rsp, s_err, s_orph, s_proto, s_ovf;
    longint s_bank [NB];
    begin
      s_req = 0; s_legal = 0; s_rd = 0; s_wr = 0; s_post = 0; s_brd = 0; s_bwr = 0; s_rsp = 0; s_err = 0; s_orph = 0; s_proto = 0; s_ovf = 0;
      for (int b = 0; b < NB; b++) s_bank[b] = 0;
      for (int t = 0; t < NTP; t++) begin
        s_req += perf[(t*`SDF_NPERF + `SDF_P_REQ)*32 +: 32];
        s_legal += perf[(t*`SDF_NPERF + `SDF_P_LINE_ACC)*32 +: 32];
        s_rd += perf[(t*`SDF_NPERF + `SDF_P_RD)*32 +: 32];
        s_wr += perf[(t*`SDF_NPERF + `SDF_P_WR)*32 +: 32];
        s_post += perf[(t*`SDF_NPERF + `SDF_P_POSTED)*32 +: 32];
        s_brd += perf[(t*`SDF_NPERF + `SDF_P_BYTES_RD)*32 +: 32];
        s_bwr += perf[(t*`SDF_NPERF + `SDF_P_BYTES_WR)*32 +: 32];
        s_rsp += perf[(t*`SDF_NPERF + `SDF_P_RSP)*32 +: 32];
        s_err += perf[(t*`SDF_NPERF + `SDF_P_ERR_RSP)*32 +: 32];
        s_orph += perf[(t*`SDF_NPERF + `SDF_P_ORPHAN)*32 +: 32];
        s_proto += perf[(t*`SDF_NPERF + `SDF_P_PROTO)*32 +: 32];
        s_ovf += perf[(t*`SDF_NPERF + `SDF_P_OVF)*32 +: 32];
        for (int b = 0; b < NB; b++) s_bank[b] += bank_acc[(t*NB + b)*32 +: 32];
      end
      check(s_req == x_req, $sformatf("%s: counter REQ %0d != model %0d", name, s_req, x_req));
      check(s_legal == x_legal, $sformatf("%s: counter LINE_ACC %0d != model %0d", name, s_legal, x_legal));
      check(s_rd == x_rd, $sformatf("%s: counter RD %0d != model %0d", name, s_rd, x_rd));
      check(s_wr == x_wr, $sformatf("%s: counter WR %0d != model %0d", name, s_wr, x_wr));
      check(s_post == x_posted, $sformatf("%s: counter POSTED %0d != model %0d", name, s_post, x_posted));
      check(s_brd == x_brd, $sformatf("%s: counter BYTES_RD %0d != model %0d", name, s_brd, x_brd));
      check(s_bwr == x_bwr, $sformatf("%s: counter BYTES_WR %0d != model %0d", name, s_bwr, x_bwr));
      check(s_rsp == x_rsp, $sformatf("%s: counter RSP %0d != model %0d", name, s_rsp, x_rsp));
      check(s_err == x_errrsp, $sformatf("%s: counter ERR_RSP %0d != model %0d", name, s_err, x_errrsp));
      for (int t = 0; t < NTP; t++) if (expect_to == 0)
        check(perf[(t*`SDF_NPERF + `SDF_P_TIMEOUT)*32 +: 32] == 0, $sformatf("%s: false timeout on slice %0d (controller was alive)", name, t));
      check(s_orph == 0 && s_proto == 0 && s_ovf == 0, $sformatf("%s: orphan %0d proto %0d ovf %0d must be 0", name, s_orph, s_proto, s_ovf));
      for (int b = 0; b < NB; b++) check(s_bank[b] == x_bank[b], $sformatf("%s: bank %0d accesses %0d != model %0d", name, b, s_bank[b], x_bank[b]));
    end
  endtask

  // ================================================================ main
  logic [AW-1:0] a0;
  logic [DW-1:0] pat;
  int hide_cyc = 0;
  initial begin
    $display("tb_sdf: NOC=%0d DW=%0d NM=%0d NTP=%0d NP=%0d NB=%0d DEPTH=%0d RL=%0d ECC=%0d NSLOT=%0d REQ_REG=%0d RSP_REG=%0d CHK_ALIGN=%0d",
             NOC, DW, NM, NTP, NP, NB, DEPTH, READ_LATENCY, ECC_EN, NSLOT, REQ_REG, RSP_REG, CHK_ALIGN);
    rst_n = 1'b0;
    repeat (6) @(posedge clk);
    rst_n = 1'b1;
    repeat (4) @(posedge clk);
    // init engine of ECC builds / first cycles
    while (c_init_busy) @(posedge clk);
    repeat (4) @(posedge clk);

    // ---------------------------------------------------------------- S1 single-word read/write, every master
    pat = '0;
    for (int w = 0; w < (DW + 31) / 32; w++) pat[32*w +: 32] = 32'hA5A5_0000 + w;
    for (int m = 0; m < NM; m++) begin
      a0 = win_base(m % NTP) | AW'(m * 64 * SB);
      add_wr(m, 0, a0, pat ^ DW'(m), '1, 1'b0);
      add_rd(m, 0, a0);
      add_wr(m, 1, a0 + AW'(SB), ~pat, '1, 1'b0);
      add_rd(m, 1, a0 + AW'(SB));
      add_rd(m, 0, a0);
    end
    run_phase("S1 single word", 5000);

    // ---------------------------------------------------------------- S2 partial writes: every single byte lane, sparse strobes
    for (int b = 0; b < SB; b++) begin
      a0 = win_base(0) | AW'(1024 + 3 * SB);
      add_wr(0, 0, a0, DW'(64'hFF) << (8 * b), SB'(1) << b, 1'b0);
      add_rd(0, 0, a0);
    end
    add_wr(0, 1, win_base(0) | AW'(2048), {DW/8{8'hC3}}, {SB/2{2'b01}} | SB'(1), 1'b0);
    add_rd(0, 1, win_base(0) | AW'(2048));
    add_wr(0, 1, win_base(0) | AW'(2048), {DW/8{8'h3C}}, '0, 1'b0);                  // strobe 0: acknowledged no-op
    add_rd(0, 1, win_base(0) | AW'(2048));
    run_phase("S2 partial writes", 8000);

    // ---------------------------------------------------------------- S3 multi-beat: sequential beats across lines / banks (a burst is a beat stream)
    for (int m = 0; m < NM; m++) begin
      for (int i = 0; i < 48; i++) add_wr(m, i % NID, win_base(m % NTP) | AW'(((m * 48 + i) * SB) % CAP_BYTES), DW'({16{i[7:0] ^ 8'(m)}}) ^ DW'(i), '1, (i % 7 == 3) ? 1'b1 : 1'b0);
      for (int i = 0; i < 48; i++) add_rd(m, i % NID, win_base(m % NTP) | AW'(((m * 48 + i) * SB) % CAP_BYTES));
    end
    run_phase("S3 multi-beat", 20000);

    // ---------------------------------------------------------------- S4 bank conflicts: all masters hammer one bank / one line
    for (int m = 0; m < NM; m++) begin
      for (int i = 0; i < 40; i++) begin
        add_wr(m, i % NID, win_base(m % NTP) | AW'((i % 8) * 16 * NB), DW'({16{8'(i + m)}}), '1, 1'b0);
        add_rd(m, i % NID, win_base(m % NTP) | AW'((i % 8) * 16 * NB));
      end
    end
    run_phase("S4 bank conflicts", 30000);

    // ---------------------------------------------------------------- S5 errors (directed)
    add_rd(0, 0, win_base(0) | AW'(CAP_BYTES));                                      // beyond capacity inside the window
    add_wr(0, 1, win_base(0) | AW'(CAP_BYTES + SB), pat, '1, 1'b0);
    add_wr(0, 1, win_base(0) | AW'(ALLOW_HI), pat, '1, 1'b1);                         // posted, beyond the allowed range
    add_rd(0, 1, win_base(0) | AW'(ALLOW_HI - SB));                                   // last legal beat
    add_rd(0, 2 % NID, win_base(0) | AW'(WIN_SIZE - SB));                             // last beat of the window
    if (NOC == 0) begin
      cmd_add(0, 3'd3, 0, win_base(0), '0, '0, 0);                                    // FENCE reaches the bridge: opcode error
      cmd_add(0, 3'd5, 1, win_base(0), '0, '0, 0);                                    // reserved opcode
      add_rd(0, 0, win_base(0) | AW'(1));                                             // misaligned
      add_rd(0, 0, 32'hDEAD_0000);                                                    // outside the window
    end else begin
      cmd_add(0, 3'd5, 1, win_base(0), '0, '0, 0);                                    // reserved opcode: fabric DECERR
      add_rd(0, 0, 32'hDEAD_0000);                                                    // unmapped: fabric DECERR
      add_rd(0, 0, win_base(0) | AW'(1));                                             // misaligned: fabric DECERR (CHK_ALIGN) or bridge ALIGN
      cmd_add(0, 3'd3, 2 % NID, win_base(0), '0, '0, 0);                              // FENCE
    end
    add_rd(0, 0, win_base(0));                                                        // still works
    run_phase("S5 errors", 8000);

    // ---------------------------------------------------------------- S6 random multi-master traffic
    gen_random(NRAND, 40, 6, 20, 4, 3);
    run_phase("S6 random", 600000);
    check_counters("after S6");
    readback("S6 readback");

    gen_random(NRAND / 2, 80, 0, 25, 0, 0);
    run_phase("S6b hot lines", 600000);

    // ---------------------------------------------------------------- E burst masters through the NoC into the banked SRAM
    if (NBURST > 0) begin
      // E1 quiet integrity: write burst then read burst back, every first-word offset and several lengths; the read-back
      // bytes must equal the payload written by the previous burst (no other traffic: scripted masters idle)
      for (int fo = 0; fo < SB; fo++) begin
        int lens [6];
        lens[0] = 1; lens[1] = SB - 1; lens[2] = SB; lens[3] = SB + 1; lens[4] = 2 * SB + 5; lens[5] = 100;
        for (int li = 0; li < 6; li++) begin
          bq_add(0, `SDF_OP_WRITE, win_base(0) | AW'(1024 + fo), lens[li], (fo + li) % NID, 1'b0);
          bq_add(0, `SDF_OP_READ,  win_base(0) | AW'(1024 + fo), lens[li], (fo + li) % NID, 1'b1);
        end
      end
      bq_add(0, `SDF_OP_WRITE_POSTED, win_base(0) | AW'(2048 + 3), 77, 1, 1'b0);
      bq_add(0, `SDF_OP_READ, win_base(0) | AW'(2048 + 3), 77, 1, 1'b1);                  // same id: sees the posted burst
      run_phase("E1 burst integrity", 400000);
      // E2 directed corner cases
      bq_add(0, `SDF_OP_WRITE, win_base(0) | AW'(CAP_BYTES - 5), 40, 2, 1'b0);              // runs off the end of the SRAM: beats beyond capacity -> SLVERR
      bq_add(0, `SDF_OP_READ, win_base(0) | AW'(CAP_BYTES - 5), 40, 2, 1'b0);
      bq_add(0, `SDF_OP_WRITE, win_base(0) | AW'(ALLOW_HI - 3), 9, 1, 1'b0);
      bq_add(0, `SDF_OP_READ, win_base(0) | AW'(WIN_SIZE - 4), 4, 1, 1'b0);                 // last bytes of the window (beyond capacity)
      bq_add(0, `SDF_OP_READ, win_base(0) | AW'(WIN_SIZE - 3), 4, 1, 1'b0);                 // crosses the window end: sequencer rejects
      bq_add(0, `SDF_OP_READ, win_base(0) | AW'(64), 0, 1, 1'b0);                           // zero length
      bq_add(0, `SDF_OP_WRITE, win_base(0) | AW'(64), MAXB + 1, 1, 1'b0);                   // too long
      bq_add(0, `SDF_OP_WRITE, 32'hFFFF_FFF8, 16, 1, 1'b0);                                 // wraps the address space
      bq_add(0, 3'd4, win_base(0) | AW'(64), 8, 1, 1'b0);                                   // reserved opcode
      bq_add(0, `SDF_OP_WRITE, win_base(0) | AW'(MAXB * 2 + 1), MAXB, 3 % NID, 1'b0);       // maximum length, unaligned
      bq_add(0, `SDF_OP_READ, win_base(0) | AW'(MAXB * 2 + 1), MAXB, 3 % NID, 1'b0);
      run_phase("E2 burst corners", 400000);
      // E3 all burst masters together with scripted single-beat traffic (bank conflicts, errors, posted, FENCE)
      for (int b = 0; b < NBURST; b++) begin
        for (int i = 0; i < NBCMD; i++) begin
          logic [31:0] r;
          logic [2:0] op;
          logic [AW-1:0] a;
          int len, k;
          r = seed_mix(SEED ^ 32'(b * 31), 32'(i + 9000)); k = int'(r[7:0] % 100);
          op = (k < 40) ? `SDF_OP_READ : (k < 75) ? `SDF_OP_WRITE : (k < 95) ? `SDF_OP_WRITE_POSTED : 3'd5;
          r = xs32(r); a = win_base(b % NTP) | AW'(r[23:4] % (CAP_BYTES + CAP_BYTES / 4));    // mostly inside the SRAM, some beats beyond it
          r = xs32(r); len = 1 + int'(r[15:0] % ((r[19:16] < 4'd3) ? 7 : (r[19:16] < 4'd10) ? (3 * SB) : MAXB));
          r = xs32(r);
          if (r[3:0] == 4'd0) a = win_base(b % NTP) | AW'(WIN_SIZE - len + int'(r[7:4] % 6) - 2);   // near the window end: sometimes a range reject
          bq_add(b, op, a, len, int'(r[27:24]), 1'b0);
        end
      end
      gen_random(NRAND / 3, 60, 4, 20, 3, 2);
      run_phase("E3 bursts + traffic", 1200000);
      check_counters("after E3");
      check(bst_proto == '0, "burst master saw a response with unexpected id / opcode");
      begin
        longint sb_bursts, sb_beats, sb_bytes, sb_wire, sb_rej, sb_errb;
        sb_bursts = 0; sb_beats = 0; sb_bytes = 0; sb_wire = 0; sb_rej = 0; sb_errb = 0;
        for (int b = 0; b < NBURST; b++) begin
          sb_bursts += bst_bursts[b*32 +: 32]; sb_beats += bst_beats[b*32 +: 32]; sb_bytes += bst_bytes[b*32 +: 32];
          sb_wire += bst_wire[b*32 +: 32]; sb_rej += bst_rej[b*32 +: 32]; sb_errb += bst_errb[b*32 +: 32];
        end
        check(sb_bursts == x_bb_bursts && sb_beats == x_bb_beats && sb_bytes == x_bb_bytes && sb_wire == x_bb_wire && sb_rej == x_bb_rej && sb_errb == x_bb_errb,
              $sformatf("sequencer statistics (%0d/%0d/%0d/%0d/%0d/%0d) != testbench (%0d/%0d/%0d/%0d/%0d/%0d)", sb_bursts, sb_beats, sb_bytes, sb_wire, sb_rej, sb_errb,
                        x_bb_bursts, x_bb_beats, x_bb_bytes, x_bb_wire, x_bb_rej, x_bb_errb));
        $display("PERF bursts=%0d rejected=%0d burst_beats=%0d payload_bytes=%0d wire_bytes=%0d burst_utilisation_pct=%0d", x_bb_bursts, x_bb_rej, x_bb_beats, x_bb_bytes, x_bb_wire,
                 (x_bb_wire == 0) ? 0 : (x_bb_bytes * 100) / x_bb_wire);
      end
      readback("E readback");
    end

    // ---------------------------------------------------------------- S8 error counters / error log
    check(err_sticky[0] || x_errrsp == 0 || NTP > 1, "error log sticky bit not set after error responses");
    rb_sel = 1'b1; rb_we = 1'b0; rb_addr = 8'h00; @(posedge clk); #1;
    check(rb_rdata_b == 32'h5344_4631, "register page ID");
    rb_addr = 8'h03; @(posedge clk); #1;
    check(rb_rdata_b[15:0] == err_cnt[15:0], "register page ERR_CNT mirrors err_cnt_o");
    rb_addr = 8'hFF; @(posedge clk); #1;
    check(rb_err_b == 1'b1, "register page: unmapped register must flag rb_err");
    rb_sel = 1'b0;
    @(posedge clk);

    check_counters("final");
    readback("final readback");

    // ---------------------------------------------------------------- unloaded latency (printed; used by the performance report)
    if (RUN_LAT != 0) begin
      repeat (30) @(posedge clk);
      for (int t = 0; t < NTP; t++) begin
        rb_sel = 1'b1; rb_we = 1'b1; rb_addr = 8'(t * 64 + 1); rb_wdata = 32'h1; @(posedge clk); #1; rb_sel = 1'b0; rb_we = 1'b0;   // clear counters (register page)
      end
      repeat (3) @(posedge clk);
      x_req = 0; x_legal = 0; x_rd = 0; x_wr = 0; x_posted = 0; x_brd = 0; x_bwr = 0; x_errrsp = 0; x_rsp = 0;       // model re-baselined with the counters
      for (int b = 0; b < NB; b++) x_bank[b] = 0;
      lat_sum_tb = 0; lat_n_tb = 0; lat_max_tb = 0; lat_min_tb = 64'h7fff_ffff;
      for (int i = 0; i < 6; i++) begin
        add_rd(0, 0, win_base(0) | AW'(i * SB * 3));
        run_phase("latency probe", 2000);
        repeat (6) @(posedge clk);
      end
      check(perf[`SDF_P_LAT_MIN*32 +: 32] == lat_min_tb && perf[`SDF_P_LAT_MAX*32 +: 32] == lat_max_tb &&
            perf[`SDF_P_LAT_SUM*32 +: 32] == lat_sum_tb, $sformatf("bridge latency counters min/max/sum %0d/%0d/%0d != testbench %0d/%0d/%0d",
            perf[`SDF_P_LAT_MIN*32 +: 32], perf[`SDF_P_LAT_MAX*32 +: 32], perf[`SDF_P_LAT_SUM*32 +: 32], lat_min_tb, lat_max_tb, lat_sum_tb));
      $display("PERF unloaded_read_latency_min=%0d max=%0d avg_x100=%0d (cycles, request accepted at target port -> response handshake)",
               lat_min_tb, lat_max_tb, (lat_n_tb == 0) ? 0 : (lat_sum_tb * 100) / lat_n_tb);
    end

    // ---------------------------------------------------------------- FLUSH recovery (controller discards in-flight work)
    if (RUN_FLUSH != 0) begin
      for (int round = 0; round < 6; round++) begin
        lost_cause = `SDF_CAUSE_RESET;
        for (int m = 0; m < NM; m++) begin
          for (int i = 0; i < 40; i++) begin
            if (i % 3 == 0) add_rd(m, i % NID, win_base(m % NTP) | AW'(((i * 5 + m) * SB) % CAP_BYTES));
            else add_wr(m, i % NID, win_base(m % NTP) | AW'(((i * 5 + m) * SB) % CAP_BYTES), DW'({16{8'(i * 3 + round)}}), '1, (i % 4 == 1));
          end
        end
        agents_on = 1'b1;
        for (int m = 0; m < NM; m++) begin cptr[m] = 0; gapc[m] = 0; end
        repeat (8 + round * 7) @(posedge clk);
        flush_tb = 1'b1; @(posedge clk); flush_tb = 1'b0;                            // controller flush mid-traffic
        // the generic phase machinery finishes and checks exactly-once completion
        begin
          int c; logic dn; c = 0; dn = 1'b0;
          while (!dn && c < 100000) begin
            @(posedge clk); c++; dn = 1'b1;
            if (!all_idle()) dn = 1'b0;
          end
          check(c < 100000, "flush round did not complete");
        end
        repeat (40) @(posedge clk); agents_on = 1'b0; repeat (4) @(posedge clk);
        tests++;
        for (int p = 0; p < NPAIR; p++) check(tq_rp[p] == tq_wp[p] && rq_rp[p] == rq_wp[p], "flush: entries left without a response");
        for (int m = 0; m < NM; m++) begin ncmd[m] = 0; cptr[m] = 0; end
      end
      $display("  flush rounds done: %0d transactions completed by the bridge with RESET (synthesised)", lost_total);
      check(lost_total > 0, "flush test never caught a transaction in flight");
      readback("flush readback");
      check_counters("after flush");
    end

    // ---------------------------------------------------------------- RESET mid-traffic (fabric + bridge + controller)
    if (RUN_RESET != 0) begin
      gen_random(200, 40, 0, 20, 0, 0);
      agents_on = 1'b1;
      for (int m = 0; m < NM; m++) begin cptr[m] = 0; gapc[m] = 0; end
      repeat (50) @(posedge clk);
      // cancel everything in flight (SFB3 R11): drop expectations, memory content persists unless the init engine re-zeroes it
      agents_on = 1'b0;
      rst_n = 1'b0;
      repeat (3) @(posedge clk);
      for (int p = 0; p < NPAIR; p++) begin tq_wp[p] = 0; tq_ap[p] = 0; tq_rp[p] = 0; rq_wp[p] = 0; rq_rp[p] = 0; end
      for (int t = 0; t < NTP; t++) begin sf_wp[t] = 0; sf_rp[t] = 0; end
      for (int c = 0; c < NCP; c++) begin cp_wp[c] = 0; cp_rp[c] = 0; end
      for (int m = 0; m < NM; m++) begin ncmd[m] = 0; cptr[m] = 0; m_infl[m] = 0; end
      if (INIT_ON_RESET != 0) begin
        for (int i = 0; i < CAP_BYTES; i++) ref_mem[i] = 8'h00;
        for (int i = 0; i < CAP_BYTES/16; i++) ue_line[i] = 1'b0;
      end
      repeat (3) @(posedge clk);
      rst_n = 1'b1;
      repeat (4) @(posedge clk);
      while (c_init_busy) @(posedge clk);
      repeat (4) @(posedge clk);
      for (int p = 0; p < NPAIR; p++) check(tq_wp[p] == 0, "reset: state");
      check(out_cnt == '0, "reset: bridge reports transactions in flight after reset");
      // counters restarted by reset: re-baseline the model
      x_req = 0; x_legal = 0; x_rd = 0; x_wr = 0; x_posted = 0; x_brd = 0; x_bwr = 0; x_errrsp = 0; x_rsp = 0;
      for (int b = 0; b < NB; b++) x_bank[b] = 0;
      gen_random(NRAND / 2, 40, 6, 20, 4, 2);
      run_phase("post-reset random", 400000);
      check_counters("after reset");
      readback("post-reset readback");
    end

    // ---------------------------------------------------------------- ECC: correctable / uncorrectable errors
    if (RUN_ECC != 0 && ECC_EN != 0) begin
      logic [AW-1:0] ea;
      int ln;
      // seed lines
      for (int i = 0; i < 8; i++) add_wr(0, i % NID, win_base(0) | AW'(i * 16 * 5), {16{8'(i + 1)}}, '1, 1'b0);
      run_phase("ECC seed", 4000);
      // single-bit error (corrected: OK + data), then a double-bit error (SLVERR / ECC)
      ln = 5;  ea = win_base(0) | AW'(ln * 16);
      fi_bank = BW'(ln % NB); seu_row = ROW_W'(ln / NB); seu_mask = STORE_W'(1) << 3; seu_pulse = 1'b1; @(posedge clk); seu_pulse = 1'b0;
      add_rd(0, 0, ea & ~AW'(SB - 1));
      run_phase("ECC CE read", 2000);
      check(perf[(`SDF_P_CE)*32 +: 32] >= 1, "corrected ECC event not counted");
      ln = 6;  ea = win_base(0) | AW'(ln * 16);
      fi_bank = BW'(ln % NB); seu_row = ROW_W'(ln / NB); seu_mask = (STORE_W'(1) << 3) | (STORE_W'(1) << 9); seu_pulse = 1'b1; @(posedge clk); seu_pulse = 1'b0;
      ue_line[ln] = 1'b1;
      add_rd(0, 0, ea);
      add_wr(0, 1, ea, {16{8'h77}}, SB'(1), 1'b0);                                    // partial write onto a UE line: aborted
      add_rd(0, 0, ea);
      add_wr(0, 1, ea, {16{8'h5A}}, '1, 1'b0);                                        // full line: repairs (DW=128) / still aborted (DW<128)
      add_rd(0, 0, ea);
      run_phase("ECC UE", 4000);
      check(err_sticky[0], "ECC UE did not set the error log");
      check(cc_seen_ecc(), "ECC error responses not counted under cause ECC");
    end

    // ---------------------------------------------------------------- TIMEOUT: controller stops answering
    if (RUN_TIMEOUT != 0 && TIMEOUT != 0) begin
      lost_cause = `SDF_CAUSE_TIMEOUT;
      for (int m = 0; m < NM; m++) for (int i = 0; i < 24; i++) begin
        if (i % 2 == 0) add_rd(m, i % NID, win_base(m % NTP) | AW'(((i * 3 + m) * SB) % CAP_BYTES));
        else add_wr(m, i % NID, win_base(m % NTP) | AW'(((i * 3 + m) * SB) % CAP_BYTES), DW'({16{8'(i)}}), '1, 1'b0);
      end
      agents_on = 1'b1;
      for (int m = 0; m < NM; m++) begin cptr[m] = 0; gapc[m] = 0; end
      repeat (10) @(posedge clk);
      expect_to = 1;
      hide = 1'b1; hide_cyc = cycle;                                                  // the controller "hangs": no response reaches the bridge
      begin
        int c; logic dn; c = 0; dn = 1'b0;
        while (!dn && c < 200000) begin
          @(posedge clk); c++;
          if (c_flush_o) begin
            hide = 1'b0;                                                             // the bridge flushed the controller: it answers again
            // the bridge's silence counter starts when the oldest in-flight transaction is due, up to BANK_LAT + 1 cycles before the
            // testbench hides the response: allow that much, nothing more (a mutant firing at TIMEOUT/2 is far outside it)
            check(cycle - hide_cyc >= TIMEOUT - (READ_LATENCY + ECC_EN + 2), $sformatf("timeout fired after only %0d cycles of silence (programmed %0d)", cycle - hide_cyc, TIMEOUT));
          end
          dn = !hide;
          if (!all_idle()) dn = 1'b0;
        end
        check(c < 200000, "timeout recovery did not complete");
      end
      repeat (60) @(posedge clk); agents_on = 1'b0; repeat (4) @(posedge clk);
      tests++;
      for (int p = 0; p < NPAIR; p++) check(tq_rp[p] == tq_wp[p] && rq_rp[p] == rq_wp[p], "timeout: entries left without a response");
      check(perf[(`SDF_P_TIMEOUT)*32 +: 32] >= 1, "timeout event not counted");
      check(perf[(`SDF_P_SYNTH)*32 +: 32] >= 1, "timeout: no synthesised responses");
      for (int m = 0; m < NM; m++) begin ncmd[m] = 0; cptr[m] = 0; end
      readback("timeout readback");
    end

    repeat (20) @(posedge clk);
    for (int t = 0; t < NTP; t++) begin
      check(tchk_viol[t] == 0, $sformatf("sf_sdf_tgt_chk: %0d SFB3 protocol violations on target port %0d", tchk_viol[t], t));
      check(tchk_out[t] == 0, $sformatf("sf_sdf_tgt_chk: %0d transactions still outstanding on target port %0d at the end", tchk_out[t], t));
    end
    $display("PERF window_bytes=%0d capacity_bytes=%0d allowed=[%0d,%0d)", WIN_SIZE, CAP_BYTES, ALLOW_LO, ALLOW_HI);
    $display("RESULT tests=%0d checks=%0d errors=%0d %s", tests, checks, errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end

  function automatic logic cc_seen_ecc();
    cc_seen_ecc = (dut.g_t[0].u_port.cc[`SDF_CAUSE_ECC] != 0);
  endfunction

  initial begin
    #(64'd400_000_000);
    $display("RESULT tests=%0d checks=%0d errors=%0d FAIL (global timeout)", tests, checks, errors + 1);
    $finish;
  end
endmodule
