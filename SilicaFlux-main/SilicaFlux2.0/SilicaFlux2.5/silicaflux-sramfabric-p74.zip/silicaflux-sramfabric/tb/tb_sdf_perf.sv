// =============================================================================
// SilicaFlux SRAMFabric (P74) :: tb_sdf_perf -- performance measurements (RTL simulation, cycle counts; no silicon data)
//
// NM SFB3 masters -> real silicaflux_noc (crossbar) -> sf_sram_datafabric (NTP target ports) -> sf_sram_controller -> banks.
// Master NM-1 is a burst sequencer (sf_sdf_burst_seq); masters 0..NM-2 are open-loop single-beat generators.
// Each scenario clears the bridge counters (register page), runs a fixed window with the stated injection, drains, and prints
//   PERF scen=<name> cycles=.. useful_bytes=.. bpc_x100=.. rsp=.. lat_avg_x100=.. lat_min=.. lat_max=.. rtt_avg_x100=.. occ_avg_x100=..
//        occ_max=.. req_stall=.. rsp_stall=.. ctrl_stall=.. seq_pct=.. bank_acc=[..] bank_stall=[..] ctl_conf=.. burst_util_pct=..
// Definitions (docs/PERFORMANCE_MODEL.md): lat = bridge counters (request accepted at the target port -> response handshake);
// rtt = master side (request accepted by the NoC -> response accepted by the master) in the single-request scenario;
// useful_bytes = DW/8 per read beat + set byte enables per write beat; occ = outstanding transactions inside the bridge
// (controller side + response register), averaged over the window.  Nothing is checked for data here (tb_sdf does that);
// the run only fails on hangs and on an impossible counter state.
// =============================================================================
`timescale 1ns/1ps
`include "sf_sram_defs.svh"
`include "sf_sdf_defs.svh"

module tb_sdf_perf #(
  parameter int DW = 128,
  parameter int NM = 4,
  parameter int IDW = 2,
  parameter int NTP = 1,
  parameter int NP = 1,
  parameter int NB = 4,
  parameter int DEPTH = 256,
  parameter int READ_LATENCY = 1,
  parameter int ECC_EN = 0,
  parameter int NSLOT = 8,
  parameter int REQ_REG = 1,
  parameter int RSP_REG = 1,
  parameter int WINDOW = 4000,
  parameter int SEED = 32'h9E3779B9
);
  localparam int AW = 32, SB = DW / 8, LINE_W = 128, SRCW = (NM > 1) ? $clog2(NM) : 1, NID = 1 << IDW;
  localparam int LANEW = (DW < LINE_W) ? $clog2(LINE_W / DW) : 1;
  localparam int IDC = 3 + SRCW + IDW + LANEW + 1;
  localparam int NCP = NTP * NP;
  localparam int CAP = NB * DEPTH * 16;
  localparam int WIN_LOG2 = $clog2(CAP) + 1;
  localparam int WIN = 1 << WIN_LOG2;
  localparam logic [AW-1:0] WMASK = AW'(WIN) - 1'b1;
  localparam int MAXB = 4096;
  localparam int BLW = $clog2(MAXB + 1) + 1;
  localparam int BBW = $clog2(MAXB / SB + 2) + 1;
  localparam int NS = NM - 1;                                     // single-beat generators
  localparam logic [4*AW-1:0] WB4 = {32'h2030_0000, 32'h2020_0000, 32'h2010_0000, 32'h2000_0000};
  localparam logic [NTP*AW-1:0] WBS = WB4[NTP*AW-1:0];
  function automatic logic [AW-1:0] win_base(input int t); win_base = 32'h2000_0000 + 32'(t) * 32'h0010_0000; endfunction

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  `include "sfn_tb_common.svh"
  int errors = 0, checks = 0;
  task automatic check(input logic cond, input string msg);
    begin checks++; if (!cond) begin errors++; if (errors <= 20) $display("[FAIL] t=%0t %s", $time, msg); end end
  endtask

  // ---------------------------------------------------------------- masters
  logic [NM-1:0]      m_req_valid, m_req_ready, m_rsp_valid, m_rsp_ready;
  logic [NM*3-1:0]    m_req_opcode, m_rsp_opcode, m_req_qos;
  logic [NM*IDW-1:0]  m_req_id, m_rsp_id;
  logic [NM*AW-1:0]   m_req_addr;
  logic [NM*DW-1:0]   m_req_wdata, m_rsp_rdata;
  logic [NM*SB-1:0]   m_req_wstrb;
  logic [NM*2-1:0]    m_rsp_status;
  logic [NS-1:0]      g_v = '0;
  logic [NS*3-1:0]    g_op = '0;
  logic [NS*IDW-1:0]  g_id = '0;
  logic [NS*AW-1:0]   g_addr = '0;
  logic [NS*DW-1:0]   g_wd = '0;
  logic [NS*SB-1:0]   g_ws = '0;
  logic [NS-1:0]      g_rr = '1;
  logic               bs_v;
  logic [2:0]         bs_op, bs_qos;
  logic [IDW-1:0]     bs_id;
  logic [AW-1:0]      bs_addr;
  logic [DW-1:0]      bs_wd;
  logic [SB-1:0]      bs_ws;
  logic               bs_rr;
  for (genvar m = 0; m < NS; m++) begin : g_g
    assign m_req_valid[m] = g_v[m];
    assign m_req_opcode[m*3 +: 3] = g_op[m*3 +: 3];
    assign m_req_id[m*IDW +: IDW] = g_id[m*IDW +: IDW];
    assign m_req_qos[m*3 +: 3] = 3'd1;
    assign m_req_addr[m*AW +: AW] = g_addr[m*AW +: AW];
    assign m_req_wdata[m*DW +: DW] = g_wd[m*DW +: DW];
    assign m_req_wstrb[m*SB +: SB] = g_ws[m*SB +: SB];
    assign m_rsp_ready[m] = g_rr[m];
  end
  assign m_req_valid[NS] = bs_v;
  assign m_req_opcode[NS*3 +: 3] = bs_op;
  assign m_req_id[NS*IDW +: IDW] = bs_id;
  assign m_req_qos[NS*3 +: 3] = bs_qos;
  assign m_req_addr[NS*AW +: AW] = bs_addr;
  assign m_req_wdata[NS*DW +: DW] = bs_wd;
  assign m_req_wstrb[NS*SB +: SB] = bs_ws;
  assign m_rsp_ready[NS] = bs_rr;

  // ---------------------------------------------------------------- fabric, bridge, controller
  logic [NTP-1:0]     t_req_valid, t_req_ready, t_rsp_valid, t_rsp_ready;
  logic [NTP*3-1:0]   t_req_opcode, t_rsp_opcode, t_req_qos;
  logic [NTP*SRCW-1:0] t_req_src, t_rsp_src;
  logic [NTP*IDW-1:0] t_req_id, t_rsp_id;
  logic [NTP*AW-1:0]  t_req_addr;
  logic [NTP*DW-1:0]  t_req_wdata, t_rsp_rdata;
  logic [NTP*SB-1:0]  t_req_wstrb;
  logic [NTP*2-1:0]   t_rsp_status;
  logic [NTP*3-1:0]   rsp_cause;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] noc_rb;  logic noc_rbe, noc_irq, obs_bs;  logic [NM-1:0] o1, o2, o3, o4, o5;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_noc #(.TOPOLOGY(1), .NM(NM), .NT(NTP), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(1), .CHECK_ALIGN(1),
                   .TGT_BASE(WBS), .TGT_MASK({NTP{~WMASK}}), .MAXO_MAX(4), .PERF(0)) noc (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_opcode(m_req_opcode), .m_req_id(m_req_id), .m_req_qos(m_req_qos),
    .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_id(m_rsp_id), .m_rsp_opcode(m_rsp_opcode),
    .m_rsp_status(m_rsp_status), .m_rsp_rdata(m_rsp_rdata),
    .t_req_valid(t_req_valid), .t_req_ready(t_req_ready), .t_req_opcode(t_req_opcode), .t_req_src(t_req_src), .t_req_id(t_req_id),
    .t_req_qos(t_req_qos), .t_req_addr(t_req_addr), .t_req_wdata(t_req_wdata), .t_req_wstrb(t_req_wstrb),
    .t_rsp_valid(t_rsp_valid), .t_rsp_ready(t_rsp_ready), .t_rsp_src(t_rsp_src), .t_rsp_id(t_rsp_id), .t_rsp_opcode(t_rsp_opcode),
    .t_rsp_status(t_rsp_status), .t_rsp_rdata(t_rsp_rdata),
    .rb_sel(1'b0), .rb_we(1'b0), .rb_addr(12'd0), .rb_wdata(32'd0), .rb_rdata(noc_rb), .rb_err(noc_rbe), .irq_err(noc_irq),
    .obs_sw_valid(o1), .obs_sw_ready(o2), .obs_out_cnt(), .obs_decerr(o3), .obs_posted_err(o4), .obs_orphan(o5), .obs_bad_src(obs_bs));

  logic [NCP-1:0]            c_req_valid, c_req_ready, c_req_we, c_rsp_valid, c_rsp_ready, c_rsp_we, c_rsp_ce;
  logic [NCP*AW-1:0]         c_req_addr;
  logic [NCP*LINE_W-1:0]     c_req_wdata, c_rsp_rdata;
  logic [NCP*16-1:0]         c_req_be;
  logic [NCP*IDC-1:0]        c_req_id, c_rsp_id;
  logic [NCP*3-1:0]          c_rsp_status;
  logic                      c_flush_o, ctl_flush_busy;
  logic [NTP-1:0]            err_sticky;
  logic [NTP*`SDF_NPERF*32-1:0] perf;
  logic [NTP*NB*32-1:0]      bank_acc, bank_stall;
  logic [31:0]               rb_rdata;
  logic                      rb_err;
  logic                      rb_sel = 1'b0, rb_we = 1'b0;
  logic [7:0]                rb_addr = '0;
  logic [31:0]               rb_wdata = '0;
  sf_sram_datafabric #(.NM(NM), .AW(AW), .DW(DW), .IDW(IDW), .NTP(NTP), .NP(NP), .NB(NB), .DEPTH(DEPTH), .WIN_BASES(WBS), .WIN_LOG2(WIN_LOG2),
                       .REQ_REG(REQ_REG), .RSP_REG(RSP_REG), .CTRL_NSLOT(NSLOT), .TXQ_DEPTH(NSLOT), .TIMEOUT(0)) dut (
    .clk(clk), .rst_n(rst_n),
    .t_req_valid(t_req_valid), .t_req_ready(t_req_ready), .t_req_opcode(t_req_opcode), .t_req_src(t_req_src), .t_req_id(t_req_id),
    .t_req_qos(t_req_qos), .t_req_addr(t_req_addr), .t_req_wdata(t_req_wdata), .t_req_wstrb(t_req_wstrb),
    .t_rsp_valid(t_rsp_valid), .t_rsp_ready(t_rsp_ready), .t_rsp_src(t_rsp_src), .t_rsp_id(t_rsp_id), .t_rsp_opcode(t_rsp_opcode),
    .t_rsp_status(t_rsp_status), .t_rsp_rdata(t_rsp_rdata), .rsp_cause_o(rsp_cause),
    .c_req_valid(c_req_valid), .c_req_ready(c_req_ready), .c_req_we(c_req_we), .c_req_addr(c_req_addr), .c_req_wdata(c_req_wdata),
    .c_req_be(c_req_be), .c_req_id(c_req_id), .c_rsp_valid(c_rsp_valid), .c_rsp_ready(c_rsp_ready), .c_rsp_rdata(c_rsp_rdata),
    .c_rsp_id(c_rsp_id), .c_rsp_we(c_rsp_we), .c_rsp_status(c_rsp_status), .c_rsp_ce(c_rsp_ce),
    .c_flush_i(ctl_flush_busy), .c_flush_o(c_flush_o), .err_clr_i(1'b0), .err_sticky_o(err_sticky), .err_cnt_o(), .err_code_o(),
    .err_src_o(), .err_id_o(), .err_opcode_o(), .err_addr_o(), .irq_o(), .perf_o(perf), .bank_acc_o(bank_acc),
    .bank_stall_o(bank_stall), .out_cnt_o(), .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata),
    .rb_rdata(rb_rdata), .rb_err(rb_err));
  localparam int ROW_W = $clog2(DEPTH), BW = (NB > 1) ? $clog2(NB) : 1;
  localparam int STORE_W = (ECC_EN != 0) ? 137 : 128;
  localparam int FBW = (STORE_W > 1) ? $clog2(STORE_W) : 1;
  logic [NB*32-1:0] ctl_acc, ctl_conf, ctl_busy;
  logic [NCP*32-1:0] ctl_stall;
  logic              ctl_idle, ctl_init;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NB-1:0] ev_ce, ev_ue, bacc_t;
  logic [NB*STORE_W-1:0] tst;
  /* verilator lint_on UNUSEDSIGNAL */
  sf_sram_controller #(.NM(NCP), .NB(NB), .DEPTH(DEPTH), .DW(LINE_W), .AW(AW), .IDW(IDC), .READ_LATENCY(READ_LATENCY), .ECC_EN(ECC_EN),
                       .NSLOT(NSLOT), .ARB(`SF_ARB_RR), .ALIGN_MODE(1), .INIT_ON_RESET(ECC_EN), .SIM_INIT(1), .FAULT_INJECT(0)) ctl (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(c_req_valid), .m_req_ready(c_req_ready), .m_req_we(c_req_we), .m_req_addr(c_req_addr), .m_req_wdata(c_req_wdata),
    .m_req_be(c_req_be), .m_req_id(c_req_id), .m_rsp_valid(c_rsp_valid), .m_rsp_ready(c_rsp_ready), .m_rsp_rdata(c_rsp_rdata),
    .m_rsp_id(c_rsp_id), .m_rsp_we(c_rsp_we), .m_rsp_status(c_rsp_status), .m_rsp_ce(c_rsp_ce),
    .flush_i(c_flush_o), .flush_busy_o(ctl_flush_busy), .quiesce_i(1'b0), .idle_o(ctl_idle), .init_start_i(1'b0), .init_busy_o(ctl_init),
    .scrub_en_i(1'b0), .ecc_clr_i(1'b0), .ev_ce_o(ev_ce), .ev_ue_o(ev_ue), .ce_cnt_o(), .ue_cnt_o(), .perf_acc_o(ctl_acc),
    .perf_conf_o(ctl_conf), .perf_busy_o(ctl_busy), .perf_stall_o(ctl_stall), .bank_acc_o(bacc_t),
    .tst_active_i(1'b0), .tst_sel_i({NB{1'b0}}), .tst_ce_i(1'b0), .tst_we_i(1'b0), .tst_addr_i({ROW_W{1'b0}}),
    .tst_wdata_i({STORE_W{1'b0}}), .tst_rdata_o(tst),
    .fi_bank({BW{1'b0}}), .fi_type(4'd0), .fi_row({ROW_W{1'b0}}), .fi_row2({ROW_W{1'b0}}), .fi_bit({FBW{1'b0}}), .fi_bit2({FBW{1'b0}}),
    .fi_val(1'b0), .fi_val2(1'b0), .seu_pulse(1'b0), .seu_row({ROW_W{1'b0}}), .seu_mask({STORE_W{1'b0}}));

  // ---------------------------------------------------------------- burst sequencer on master NM-1
  logic              bcmd_valid = 1'b0, bcmd_ready, bwd_valid, bwd_ready, brd_valid, brd_last, bdone_valid, bdone_ready = 1'b1;
  logic [2:0]        bcmd_op = '0;
  logic [AW-1:0]     bcmd_addr = '0;
  logic [BLW-1:0]    bcmd_len = '0;
  logic [DW-1:0]     bwd_data, brd_data;
  logic [SB-1:0]     brd_strb;
  logic [1:0]        brd_status, bdone_status;
  logic [BBW-1:0]    bdone_beats;
  logic [31:0]       bst_bursts, bst_beats, bst_bytes, bst_wire, bst_busy, bst_reqst, bst_starve, bst_cst, bst_rdst;
  logic              bseq_busy;
  logic              bseq_clr = 1'b0;
  assign bwd_valid = 1'b1;
  assign bwd_data  = {(DW/8){8'h5A}};
  sf_sdf_burst_seq #(.AW(AW), .DW(DW), .IDW(IDW), .MAX_BYTES(MAXB), .RD_FIFO(4), .MAX_OUT(4),
                     .LIM_LO({1'b0, win_base(0)}), .LIM_HI({1'b0, win_base(0)} + (AW+1)'(CAP))) u_bseq (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(bcmd_valid), .cmd_ready(bcmd_ready), .cmd_op(bcmd_op), .cmd_addr(bcmd_addr), .cmd_len(bcmd_len), .cmd_id(IDW'(0)), .cmd_qos(3'd0),
    .wd_valid(bwd_valid), .wd_ready(bwd_ready), .wd_data(bwd_data), .wd_lane_mask_o(),
    .rd_valid(brd_valid), .rd_ready(1'b1), .rd_data(brd_data), .rd_strb(brd_strb), .rd_last(brd_last), .rd_status(brd_status),
    .done_valid(bdone_valid), .done_ready(bdone_ready), .done_id(), .done_status(bdone_status), .done_reason(), .done_beats(bdone_beats),
    .done_err_beat(), .done_bytes(),
    .m_req_valid(bs_v), .m_req_ready(m_req_ready[NS]), .m_req_opcode(bs_op), .m_req_id(bs_id), .m_req_qos(bs_qos), .m_req_addr(bs_addr),
    .m_req_wdata(bs_wd), .m_req_wstrb(bs_ws),
    .m_rsp_valid(m_rsp_valid[NS]), .m_rsp_ready(bs_rr), .m_rsp_id(m_rsp_id[NS*IDW +: IDW]), .m_rsp_opcode(m_rsp_opcode[NS*3 +: 3]),
    .m_rsp_status(m_rsp_status[NS*2 +: 2]), .m_rsp_rdata(m_rsp_rdata[NS*DW +: DW]),
    .cnt_clr_i(bseq_clr), .st_bursts_o(bst_bursts), .st_rejected_o(), .st_beats_o(bst_beats), .st_bytes_o(bst_bytes), .st_wire_bytes_o(bst_wire),
    .st_errbeats_o(), .st_busy_o(bst_busy), .st_req_stall_o(bst_reqst), .st_data_starve_o(bst_starve), .st_credit_stall_o(bst_cst),
    .st_rd_stall_o(bst_rdst), .st_proto_o(), .busy_o(bseq_busy));
  logic unused_b = &{1'b0, brd_valid, brd_last, brd_data, brd_strb, brd_status, bdone_status, bdone_beats, bwd_ready, bdone_valid, bcmd_ready};

  // ---------------------------------------------------------------- open-loop generators
  int          p_inj [NS], p_rd [NS], p_post [NS], mode_g [NS], stall_pct;
  int          seqk [NS];
  logic [31:0] rg [NS];
  logic        gen_on = 1'b0;
  int          budget [NS];
  int          cycle = 0;
  longint      rtt_sum = 0, rtt_n = 0;
  int          rtt_min = 1 << 30, rtt_max = 0;
  int          issue_cyc [NS][NID];
  initial for (int m = 0; m < NS; m++) begin
    budget[m] = -1; p_inj[m] = 0; p_rd[m] = 100; p_post[m] = 0; mode_g[m] = 0; seqk[m] = 0; rg[m] = seed_mix(SEED, 32'(m + 1));
    for (int i = 0; i < NID; i++) issue_cyc[m][i] = 0;
  end
  always @(posedge clk) begin
    cycle <= cycle + 1;
    for (int m = 0; m < NS; m++) begin
      rg[m] = xs32(rg[m]);
      g_rr[m] <= (int'(rg[m][15:8] % 100) >= stall_pct);
      if (g_v[m] && m_req_ready[m]) begin
        issue_cyc[m][int'(g_id[m*IDW +: IDW])] = cycle;
        g_v[m] <= 1'b0;
      end
      if (m_rsp_valid[m] && g_rr[m]) begin
        int rt;
        rt = cycle - issue_cyc[m][int'(m_rsp_id[m*IDW +: IDW])];
        rtt_sum += rt; rtt_n++; if (rt < rtt_min) rtt_min = rt; if (rt > rtt_max) rtt_max = rt;
      end
      if (gen_on && budget[m] != 0 && (!g_v[m] || m_req_ready[m]) && int'(rg[m][7:0] % 100) < p_inj[m]) begin
        int region, off, k;
        logic [AW-1:0] a;
        if (budget[m] > 0) budget[m]--;
        k = seqk[m]; seqk[m] = seqk[m] + 1;
        region = CAP / 8;                                              // a power of two (>= 5 generators fit below the capacity): every beat stays DW aligned
        case (mode_g[m])
          0: off = m * region + ((k * SB) % region);                     // sequential in a private region (banks rotate); every stream starts on bank 0
          4: off = m * region + ((k * SB + m * 16) % region);     // like 0 but stream m starts m lines later: lockstep streams land on different banks
          1: off = ((k % 16) * 16 * NB) + (m * 16 * NB * 16) % CAP;      // every master hits bank 0 (distinct rows)
          2: off = (int'(rg[m][31:8]) % (CAP / SB)) * SB;                // random aligned
          default: off = (k * SB) % CAP;                                  // one shared sequential stream (all masters same addresses)
        endcase
        a = win_base(m % NTP) | AW'(off);
        g_v[m] <= 1'b1;
        g_op[m*3 +: 3] <= (int'(rg[m][23:16] % 100) < p_rd[m]) ? `SDF_OP_READ : (int'(rg[m][23:16] % 100) < p_rd[m] + p_post[m]) ? `SDF_OP_WRITE_POSTED : `SDF_OP_WRITE;
        g_id[m*IDW +: IDW] <= IDW'(k % NID);
        g_addr[m*AW +: AW] <= a;
        g_wd[m*DW +: DW] <= {(DW/32){rg[m] ^ 32'hC3A5C85C}};
        g_ws[m*SB +: SB] <= '1;
      end
    end
  end

  // ---------------------------------------------------------------- scenario machinery
  longint cnt0 [`SDF_NPERF];
  function automatic longint pf(input int idx);
    longint v;
    begin v = 0; for (int t = 0; t < NTP; t++) v += perf[(t*`SDF_NPERF + idx)*32 +: 32]; pf = v; end
  endfunction
  function automatic longint pfmax(input int idx);
    longint v;
    begin v = 0; for (int t = 0; t < NTP; t++) if (perf[(t*`SDF_NPERF + idx)*32 +: 32] > v) v = perf[(t*`SDF_NPERF + idx)*32 +: 32]; pfmax = v; end
  endfunction
  function automatic longint pfmin(input int idx);
    longint v;
    begin v = 64'h7fff_ffff; for (int t = 0; t < NTP; t++) if (perf[(t*`SDF_NPERF + idx)*32 +: 32] < v) v = perf[(t*`SDF_NPERF + idx)*32 +: 32]; pfmin = v; end
  endfunction

  task automatic clear_counters();
    begin
      for (int t = 0; t < NTP; t++) begin
        @(posedge clk); #1; rb_sel = 1'b1; rb_we = 1'b1; rb_addr = 8'(t * 64 + 1); rb_wdata = 32'h1;
        @(posedge clk); #1; rb_sel = 1'b0; rb_we = 1'b0;
      end
      @(posedge clk); #1; bseq_clr = 1'b1; @(posedge clk); #1; bseq_clr = 1'b0;
      repeat (2) @(posedge clk);
      rtt_sum = 0; rtt_n = 0; rtt_min = 1 << 30; rtt_max = 0;
    end
  endtask

  longint conf0;
  function automatic longint conf_sum();
    longint v;
    begin v = 0; for (int b = 0; b < NB; b++) v += ctl_conf[b*32 +: 32]; conf_sum = v; end
  endfunction
  task automatic report(input string name, input int cycles, input int burst_stats);
    longint useful, rsp, bpc, latavg, occavg, seqp, accs;
    string bacc_s, bst_s;
    begin
      useful = pf(`SDF_P_BYTES_RD) + pf(`SDF_P_BYTES_WR);
      rsp = pf(`SDF_P_RSP);
      bpc = (cycles == 0) ? 0 : (useful * 100) / cycles;
      latavg = (rsp == 0) ? 0 : (pf(`SDF_P_LAT_SUM) * 100) / rsp;
      occavg = (pf(`SDF_P_CYCLES) == 0) ? 0 : (pf(`SDF_P_OCC_SUM) * 100) / pf(`SDF_P_CYCLES);
      accs = pf(`SDF_P_RD) + pf(`SDF_P_WR);
      seqp = (accs == 0) ? 0 : (pf(`SDF_P_SEQ) * 100) / accs;
      bacc_s = ""; bst_s = "";
      for (int b = 0; b < NB; b++) begin
        longint a, s;
        a = 0; s = 0;
        for (int t = 0; t < NTP; t++) begin a += bank_acc[(t*NB + b)*32 +: 32]; s += bank_stall[(t*NB + b)*32 +: 32]; end
        bacc_s = {bacc_s, $sformatf("%0d%s", a, (b == NB - 1) ? "" : ",")};
        bst_s  = {bst_s, $sformatf("%0d%s", s, (b == NB - 1) ? "" : ",")};
      end
      $display("PERF scen=%s cycles=%0d useful_bytes=%0d bpc_x100=%0d rsp=%0d lat_avg_x100=%0d lat_min=%0d lat_max=%0d rtt_avg_x100=%0d rtt_min=%0d rtt_max=%0d occ_avg_x100=%0d occ_max=%0d req_stall=%0d rsp_stall=%0d ctrl_stall=%0d seq_pct=%0d bank_acc=[%s] bank_stall=[%s] ctl_conf=%0d burst_util_pct=%0d burst_bytes=%0d burst_beats=%0d burst_starve=%0d",
               name, cycles, useful, bpc, rsp, latavg, (rsp == 0) ? 0 : pfmin(`SDF_P_LAT_MIN), pfmax(`SDF_P_LAT_MAX), (rtt_n == 0) ? 0 : (rtt_sum * 100) / rtt_n,
               (rtt_n == 0) ? 0 : rtt_min, rtt_max, occavg, pfmax(`SDF_P_OCC_MAX), pf(`SDF_P_REQ_STALL), pf(`SDF_P_RSP_STALL), pf(`SDF_P_CTRL_STALL), seqp, bacc_s, bst_s,
               conf_sum() - conf0, (burst_stats != 0 && bst_wire != 0) ? (bst_bytes * 100) / bst_wire : 0, bst_bytes, bst_beats, bst_starve);
      check(pf(`SDF_P_ORPHAN) == 0 && pf(`SDF_P_PROTO) == 0 && pf(`SDF_P_OVF) == 0, "impossible counter state");
      check(rsp == pf(`SDF_P_REQ), $sformatf("%s: responses %0d != accepted %0d", name, rsp, pf(`SDF_P_REQ)));
    end
  endtask

  function automatic logic drained();
    logic a, b, c;
    begin
      a = (pf(`SDF_P_RSP) != pf(`SDF_P_REQ));
      b = (g_v != '0);
      c = (m_req_valid != '0);
      drained = !(a || b || c);
    end
  endfunction

  task automatic run_single(input string name, input int inj, input int rdp, input int postp, input int mode, input int nact, input int stall, input int win, input int bud);
    int c0, g;
    begin
      for (int m = 0; m < NS; m++) begin budget[m] = bud; p_inj[m] = (m < nact) ? inj : 0; p_rd[m] = rdp; p_post[m] = postp; mode_g[m] = mode; seqk[m] = 0; end
      stall_pct = stall;
      clear_counters();
      conf0 = conf_sum();
      c0 = cycle;
      gen_on = 1'b1;
      repeat (win) @(posedge clk);
      gen_on = 1'b0;
      g = 0;
      // (explicit break loop: a function call in a while condition across timing waits is not re-evaluated reliably by Verilator 5.020)
      forever begin
        @(posedge clk); g++;
        if (drained() || g >= 20000) break;
      end
      repeat (4) @(posedge clk);
      check(g < 20000, {name, ": did not drain"});
      report(name, cycle - c0, 0);
    end
  endtask

  task automatic run_burst(input string name, input int op, input int len, input int fo, input int count);
    int c0, g;
    begin
      for (int m = 0; m < NS; m++) p_inj[m] = 0;
      stall_pct = 0;
      clear_counters();
      conf0 = conf_sum();
      c0 = cycle;
      for (int i = 0; i < count; i++) begin
        @(posedge clk); #1;
        bcmd_valid = 1'b1; bcmd_op = 3'(op); bcmd_addr = win_base(0) | AW'(((i * 512) % (CAP - 512)) + fo); bcmd_len = BLW'(len);
        @(posedge clk);
        g = 0;
        while (!bcmd_ready && g < 100000) begin @(posedge clk); g++; end
        #1; bcmd_valid = 1'b0;
        g = 0;
        while (bseq_busy && g < 100000) begin @(posedge clk); g++; end
        check(g < 100000, {name, ": burst hang"});
      end
      repeat (6) @(posedge clk);
      report(name, cycle - c0, 1);
    end
  endtask

  initial begin
    $display("tb_sdf_perf: DW=%0d NM=%0d NTP=%0d NP=%0d NB=%0d DEPTH=%0d RL=%0d ECC=%0d NSLOT=%0d REQ_REG=%0d RSP_REG=%0d WINDOW=%0d",
             DW, NM, NTP, NP, NB, DEPTH, READ_LATENCY, ECC_EN, NSLOT, REQ_REG, RSP_REG, WINDOW);
    stall_pct = 0;
    rst_n = 1'b0; repeat (6) @(posedge clk); rst_n = 1'b1; repeat (6) @(posedge clk);
    while (ctl_init) @(posedge clk);
    repeat (10) @(posedge clk);
    // ---- latency: a single read in an idle system, then a single write
    run_single("single_read_unloaded", 100, 100, 0, 0, 1, 0, 80, 1);       // exactly one read into an idle system
    run_single("single_write_unloaded", 100, 0, 0, 0, 1, 0, 80, 1);
    run_single("seq_read_1m", 100, 100, 0, 0, 1, 0, WINDOW, -1);
    run_single("seq_write_acked_1m", 100, 0, 0, 0, 1, 0, WINDOW, -1);
    run_single("seq_write_posted_1m", 100, 0, 100, 0, 1, 0, WINDOW, -1);
    run_single("seq_read_allm", 100, 100, 0, 0, NS, 0, WINDOW, -1);
    run_single("seq_rw_allm", 100, 50, 25, 0, NS, 0, WINDOW, -1);
    run_single("seq_read_allm_skew", 100, 100, 0, 4, NS, 0, WINDOW, -1);
    run_single("seq_rw_allm_skew", 100, 50, 25, 4, NS, 0, WINDOW, -1);
    run_single("samebank_read_allm", 100, 100, 0, 1, NS, 0, WINDOW, -1);
    run_single("samebank_rw_allm", 100, 50, 25, 1, NS, 0, WINDOW, -1);
    run_single("random_rw_allm", 100, 60, 20, 2, NS, 0, WINDOW, -1);
    run_single("random_rw_allm_load50", 50, 60, 20, 2, NS, 0, WINDOW, -1);
    run_single("random_rw_allm_rspstall50", 100, 60, 20, 2, NS, 50, WINDOW, -1);
    run_single("shared_stream_allm", 100, 100, 0, 3, NS, 0, WINDOW, -1);
    run_burst("burst_read_aligned_256B", `SDF_OP_READ, 256, 0, 24);
    run_burst("burst_write_aligned_256B", `SDF_OP_WRITE, 256, 0, 24);
    run_burst("burst_write_posted_aligned_256B", `SDF_OP_WRITE_POSTED, 256, 0, 24);
    run_burst("burst_read_unaligned_251B", `SDF_OP_READ, 251, 3, 24);
    run_burst("burst_write_unaligned_251B", `SDF_OP_WRITE, 251, 3, 24);
    run_burst("burst_read_short_7B", `SDF_OP_READ, 7, 1, 48);
    run_burst("burst_read_long_4096B", `SDF_OP_READ, 4096, 0, 4);
    $display("RESULT tests=%0d checks=%0d errors=%0d %s", 21, checks, errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin
    #(64'd900_000_000);
    $display("RESULT tests=0 checks=%0d errors=%0d FAIL (global timeout)", checks, errors + 1);
    $finish;
  end
endmodule
