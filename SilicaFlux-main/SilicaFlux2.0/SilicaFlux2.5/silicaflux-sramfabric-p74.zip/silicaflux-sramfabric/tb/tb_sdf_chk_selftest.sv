// =============================================================================
// SilicaFlux SRAMFabric (P74) :: tb_sdf_chk_selftest -- the assertion monitor must fire on every illegal SFB3 sequence
//   and stay silent on a legal one.  Each scenario applies a hand-made sequence and compares the monitor's violation count.
// =============================================================================
`timescale 1ns/1ps
module tb_sdf_chk_selftest;
  localparam int NM = 2, IDW = 2, AW = 32, DW = 32, SRCW = 1, SB = 4;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  logic rv = 0, rr = 0, pv = 0, pr = 0, quiet = 0;
  logic [2:0] rop = 0, pop = 0;
  logic [SRCW-1:0] rsrc = 0, psrc = 0;
  logic [IDW-1:0] rid = 0, pid = 0;
  logic [AW-1:0] raddr = 0;
  logic [DW-1:0] rwd = 0, prd = 0;
  logic [1:0] pst = 0;
  int viol, outst, acc, ans;
  int errors = 0, checks = 0;
  sf_sdf_tgt_chk #(.NM(NM), .IDW(IDW), .AW(AW), .DW(DW), .NAME("selftest"), .QUIET(1'b1)) mon (
    .clk(clk), .rst_n(rst_n), .t_req_valid(rv), .t_req_ready(rr), .t_req_opcode(rop), .t_req_src(rsrc), .t_req_id(rid),
    .t_req_addr(raddr), .t_req_wdata(rwd), .t_req_wstrb(4'hF), .t_rsp_valid(pv), .t_rsp_ready(pr), .t_rsp_src(psrc), .t_rsp_id(pid),
    .t_rsp_opcode(pop), .t_rsp_status(pst), .t_rsp_rdata(prd), .quiet_i(quiet), .violations(viol), .outstanding_o(outst),
    .accepted_o(acc), .answered_o(ans));

  task automatic step(input logic rvv, input logic rrr, input logic [2:0] ro, input int rs, input int ri,
                      input logic pvv, input logic prr, input logic [2:0] po, input int ps, input int pi, input logic [31:0] rd);
    begin
      @(posedge clk); #1;
      rv = rvv; rr = rrr; rop = ro; rsrc = SRCW'(rs); rid = IDW'(ri); raddr = 32'h2000_0000;
      pv = pvv; pr = prr; pop = po; psrc = SRCW'(ps); pid = IDW'(pi); prd = rd;
    end
  endtask
  task automatic idle(); step(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); endtask
  task automatic expect_viol(input int n, input string what);
    begin
      checks++;
      if (viol != n) begin errors++; $display("[FAIL] %s: monitor reports %0d violations, expected %0d", what, viol, n); end
    end
  endtask

  initial begin
    repeat (3) @(posedge clk); rst_n = 1'b1; idle();
    // ---- legal: request accepted at cycle 1, response one cycle later (held one cycle), quiet at the end
    step(1, 1, 0, 1, 2, 0, 0, 0, 0, 0, 0);      // accept READ src1 id2
    step(0, 0, 0, 0, 0, 1, 0, 0, 1, 2, 7);      // response presented, not ready
    step(0, 0, 0, 0, 0, 1, 1, 0, 1, 2, 7);      // held unchanged, accepted
    idle(); idle(); quiet = 1; idle(); quiet = 0; idle();
    expect_viol(0, "legal sequence");
    // ---- response in the acceptance cycle
    step(1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0);      // accept WRITE src0 id1 and answer it in the same cycle
    idle(); idle();
    expect_viol(1, "response in the acceptance cycle");
    // ---- response for a pair that has nothing outstanding
    step(0, 0, 0, 0, 0, 1, 1, 0, 1, 3, 0); idle(); idle();
    expect_viol(2, "response without request");
    // ---- wrong opcode echo
    step(1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);      // READ src0 id0
    step(0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0);      // answered as WRITE
    idle(); idle();
    expect_viol(3, "opcode echo");
    // ---- held response changes
    step(1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0);
    step(0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 5);      // presented, not accepted
    step(0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 6);      // data changed while held
    idle(); idle();
    expect_viol(4, "held response must not change");
    // ---- held request withdrawn
    step(1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0);      // valid, not ready
    step(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);      // withdrawn
    idle();
    expect_viol(5, "held request withdrawn");
    // ---- lost response: request accepted, never answered, quiet asserted
    step(1, 1, 0, 1, 3, 0, 0, 0, 0, 0, 0); idle(); idle(); quiet = 1; idle(); quiet = 0;
    expect_viol(6, "lost response");
    // ---- duplicate response (second response for one request)
    step(1, 1, 0, 0, 3, 0, 0, 0, 0, 0, 0);
    step(0, 0, 0, 0, 0, 1, 1, 0, 0, 3, 0);
    step(0, 0, 0, 0, 0, 1, 1, 0, 0, 3, 0);
    idle(); idle();
    expect_viol(7, "duplicate response");
    $display("RESULT tests=8 checks=%0d errors=%0d %s", checks, errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule
