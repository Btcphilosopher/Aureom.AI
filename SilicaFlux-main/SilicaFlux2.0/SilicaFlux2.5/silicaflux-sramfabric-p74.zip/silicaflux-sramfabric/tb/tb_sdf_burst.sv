// =============================================================================
// SilicaFlux SRAMFabric (P74) :: tb_sdf_burst -- unit test of the burst sequencer against a behavioural SFB3 target
//
// DUT: sf_sdf_burst_seq.  Target model: SFB3 slave on a byte memory with random request acceptance, random in-order response
// latency, response back-pressure and error windows (SLVERR / DECERR beats, no side effect).  Posted writes get no response.
// The model applies every accepted beat to its memory at the acceptance edge; the TB holds an independent golden memory that is
// updated from the COMMAND semantics (bytes [addr, addr+len) minus erroring beats).  Checks:
//   * every issued beat: opcode, id, address (DW aligned, consecutive), byte strobe (computed byte by byte) and the data bytes
//     of the strobed lanes; no beat before the command was accepted, exactly nbeats beats, none for a rejected command
//   * memory equality after every write burst (partial first / last words must not touch neighbouring bytes)
//   * read streams: per-beat status, valid-byte mask, last flag, reassembled bytes == golden memory
//   * completion: status class, first error beat, beat count, byte count, reject reason; exactly one per command
//   * statistics counters equal the testbench's own counts
// Stimulus: exhaustive first/last-word alignments, boundary and length corner cases, rejects, error windows, posted writes,
// randomised bursts, with stalls on every channel.
// =============================================================================
`timescale 1ns/1ps
`include "sf_sdf_defs.svh"

module tb_sdf_burst #(
  parameter int DW = 128,
  parameter int IDW = 2,
  parameter int MAX_BYTES = 256,
  parameter int RD_FIFO = 4,
  parameter int MAX_OUT = 4,
  parameter int BOUNDARY = 0,
  parameter int P_TREQ_STALL = 30,
  parameter int P_RSP_DELAY = 40,
  parameter int P_RSP_STALL = 30,
  parameter int P_WD_GAP = 25,
  parameter int P_RD_STALL = 30,
  parameter int P_DONE_STALL = 30,
  parameter int NRAND = 1500,
  parameter int SEED = 32'hB0057E57
);
  localparam int AW = 32;
  localparam int SB = DW / 8;
  localparam int WB = $clog2(SB);
  localparam int LENW = $clog2(MAX_BYTES + 1) + 1;
  localparam int BEATW = $clog2(MAX_BYTES / SB + 2) + 1;
  localparam int MEMB = 16384;
  localparam logic [AW-1:0] BASE = 32'h2000_0000;
  localparam int ERR_LO = 12288, ERR_HI = 12288 + 64;       // SLVERR beats (offsets inside the memory)
  localparam int DEC_LO = 14336, DEC_HI = 14336 + 64;       // DECERR beats

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  `include "sfn_tb_common.svh"

  int errors = 0, checks = 0, tests = 0;
  task automatic check(input logic cond, input string msg);
    begin
      checks++;
      if (!cond) begin errors++; if (errors <= 25) $display("[FAIL] t=%0t %s", $time, msg); end
    end
  endtask

  // ---------------------------------------------------------------- DUT
  logic              cmd_valid = 1'b0, cmd_ready;
  logic [2:0]        cmd_op = '0;
  logic [AW-1:0]     cmd_addr = '0;
  logic [LENW-1:0]   cmd_len = '0;
  logic [IDW-1:0]    cmd_id = '0;
  logic              wd_valid = 1'b0, wd_ready;
  logic [DW-1:0]     wd_data = '0;
  logic [SB-1:0]     wd_lane_mask;
  logic              rd_valid, rd_ready = 1'b0, rd_last;
  logic [DW-1:0]     rd_data;
  logic [SB-1:0]     rd_strb;
  logic [1:0]        rd_status;
  logic              done_valid, done_ready = 1'b0;
  logic [IDW-1:0]    done_id;
  logic [1:0]        done_status;
  logic [2:0]        done_reason;
  logic [BEATW-1:0]  done_beats, done_err_beat;
  logic [LENW-1:0]   done_bytes;
  logic              m_req_valid, m_req_ready;
  logic [2:0]        m_req_opcode, m_req_qos;
  logic [IDW-1:0]    m_req_id;
  logic [AW-1:0]     m_req_addr;
  logic [DW-1:0]     m_req_wdata;
  logic [SB-1:0]     m_req_wstrb;
  logic              m_rsp_valid, m_rsp_ready;
  logic [IDW-1:0]    m_rsp_id;
  logic [2:0]        m_rsp_opcode;
  logic [1:0]        m_rsp_status;
  logic [DW-1:0]     m_rsp_rdata;
  logic [31:0]       st_bursts, st_rejected, st_beats, st_bytes, st_wire, st_errb, st_busy, st_rstall, st_starve, st_cstall, st_rdst, st_proto;
  logic              busy;
  logic              cnt_clr = 1'b0;

  sf_sdf_burst_seq #(.AW(AW), .DW(DW), .IDW(IDW), .MAX_BYTES(MAX_BYTES), .RD_FIFO(RD_FIFO), .MAX_OUT(MAX_OUT), .BOUNDARY(BOUNDARY),
                     .LIM_LO({1'b0, BASE}), .LIM_HI({1'b0, BASE} + (AW+1)'(MEMB))) dut (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_op(cmd_op), .cmd_addr(cmd_addr), .cmd_len(cmd_len), .cmd_id(cmd_id), .cmd_qos(3'd2),
    .wd_valid(wd_valid), .wd_ready(wd_ready), .wd_data(wd_data), .wd_lane_mask_o(wd_lane_mask),
    .rd_valid(rd_valid), .rd_ready(rd_ready), .rd_data(rd_data), .rd_strb(rd_strb), .rd_last(rd_last), .rd_status(rd_status),
    .done_valid(done_valid), .done_ready(done_ready), .done_id(done_id), .done_status(done_status), .done_reason(done_reason),
    .done_beats(done_beats), .done_err_beat(done_err_beat), .done_bytes(done_bytes),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_opcode(m_req_opcode), .m_req_id(m_req_id), .m_req_qos(m_req_qos),
    .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_id(m_rsp_id), .m_rsp_opcode(m_rsp_opcode),
    .m_rsp_status(m_rsp_status), .m_rsp_rdata(m_rsp_rdata),
    .cnt_clr_i(cnt_clr), .st_bursts_o(st_bursts), .st_rejected_o(st_rejected), .st_beats_o(st_beats), .st_bytes_o(st_bytes),
    .st_wire_bytes_o(st_wire), .st_errbeats_o(st_errb), .st_busy_o(st_busy), .st_req_stall_o(st_rstall),
    .st_data_starve_o(st_starve), .st_credit_stall_o(st_cstall), .st_rd_stall_o(st_rdst), .st_proto_o(st_proto), .busy_o(busy));

  sfn_protocol_checker #(.QW(3+IDW+3+AW+DW+SB), .RW(IDW+3+2+DW), .NAME("seq-master")) u_chk (
    .clk(clk), .rst_n(rst_n), .req_valid(m_req_valid), .req_ready(m_req_ready),
    .req_payload({m_req_opcode, m_req_id, m_req_qos, m_req_addr, m_req_wdata, m_req_wstrb}),
    .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready), .rsp_payload({m_rsp_id, m_rsp_opcode, m_rsp_status, m_rsp_rdata}), .violations());

  // ---------------------------------------------------------------- behavioural SFB3 target
  logic [7:0] tmem [MEMB];
  logic [7:0] gmem [MEMB];                              // golden memory (command semantics)
  logic [31:0] rt;
  localparam int QD = 64;
  logic [2:0]    q_op [QD];
  logic [IDW-1:0] q_id [QD];
  logic [1:0]    q_st [QD];
  logic [DW-1:0] q_rd [QD];
  int            q_due [QD];
  int            q_wp = 0, q_rp = 0, cyc = 0;
  logic          r_v = 1'b0;
  int            tgt_out = 0;                            // beats accepted and not yet answered (credit check)
  int            tgt_beats = 0;                          // beats accepted by the target since the last mark

  function automatic int beat_err(input int off);       // 0 ok, 1 SLVERR, 2 DECERR for the beat starting at memory offset off
    int e;
    begin
      e = 0;
      if (off >= ERR_LO && off < ERR_HI) e = 1;
      if (off >= DEC_LO && off < DEC_HI) e = 2;
      beat_err = e;
    end
  endfunction

  // expected-beat description of the command in flight (computed by the TB, independent of the DUT)
  logic         c_active = 1'b0;
  logic [2:0]   c_op;
  logic [AW-1:0] c_addr;
  int           c_len, c_id, c_nb, c_j = 0, c_n = 0;
  logic         c_reject;
  logic [2:0]   c_rjr;

  function automatic logic [7:0] pbyte(input int n, input int k);
    logic [31:0] h;
    begin
      h = seed_mix(32'(n * 977 + k * 131), 32'(k));
      pbyte = h[15:8] ^ h[7:0];
    end
  endfunction
  function automatic logic [7:0] junk(input int j, input int l);
    junk = 8'(j * 37 + l * 11 + 8'hA5);
  endfunction

  function automatic logic [SB-1:0] exp_strb(input int j);
    logic [SB-1:0] m;
    int ba;
    begin
      m = '0;
      for (int b = 0; b < SB; b++) begin
        ba = int'(c_addr & ~AW'(SB - 1)) + j * SB + b;
        if (ba >= int'(c_addr) && ba < int'(c_addr) + c_len) m[b] = 1'b1;
      end
      exp_strb = m;
    end
  endfunction

  // ---------------------------------------------------------------- target model + monitors (one clocked block)
  logic          c_accepted = 1'b0;
  logic          wr_stream = 1'b0, rd_stream = 1'b0;
  int            ws_j = 0, rb_j = 0, wd_gap = 0;
  logic          d_seen = 1'b0;
  logic [1:0]    d_status;
  logic [2:0]    d_reason;
  int            d_beats, d_errbeat, d_bytes, d_id;
  int            d_count = 0;
  int            x_bursts = 0, x_rej = 0, x_beats = 0, x_bytes = 0, x_wire = 0, x_errb = 0;
  logic [BEATW-1:0] unused_b;

  always @(posedge clk) begin
    cyc <= cyc + 1;
    rt = xs32(rt ^ 32'(cyc));
    m_req_ready <= (int'(rt[7:0] % 100) >= P_TREQ_STALL);
    rd_ready    <= (int'(rt[31:24] % 100) >= P_RD_STALL);
    done_ready  <= (int'(rt[15:8] % 100) >= P_DONE_STALL);
    // ---- command handshake
    if (rst_n && cmd_valid && cmd_ready) c_accepted <= 1'b1;
    // ---- beat acceptance at the target (m_req_valid && m_req_ready sampled before this edge's updates)
    if (rst_n && m_req_valid && m_req_ready) begin
      int off, e;
      logic [SB-1:0] es;
      off = int'(m_req_addr - BASE);
      es = exp_strb(c_j);
      check(c_active && c_accepted, "beat issued before / outside an accepted command");
      check(m_req_addr[WB-1:0] == '0, "beat address not DW aligned");
      if (c_active && c_accepted) begin
        check(c_j < c_nb, "more beats than the burst needs");
        check(m_req_opcode == c_op, "beat opcode");
        check(int'(m_req_id) == c_id, "beat id");
        check(m_req_addr == (c_addr & ~AW'(SB - 1)) + AW'(c_j * SB), "beat address not consecutive");
        if (c_op != `SDF_OP_READ) begin
          check(m_req_wstrb == es, $sformatf("beat %0d strobe %h != expected %h (addr %h len %0d)", c_j, m_req_wstrb, es, c_addr, c_len));
          for (int b = 0; b < SB; b++) if (es[b])
            check(m_req_wdata[8*b +: 8] == pbyte(c_n, int'(c_addr & ~AW'(SB - 1)) + c_j * SB + b - int'(c_addr)), $sformatf("beat %0d lane %0d data", c_j, b));
        end
        c_j++;
      end
      tgt_beats++;
      if (m_req_opcode != `SDF_OP_WRITE_POSTED) begin
        tgt_out++;
        check(tgt_out <= ((m_req_opcode == `SDF_OP_READ) ? RD_FIFO : MAX_OUT), $sformatf("outstanding beats %0d exceed the credit limit (read FIFO %0d / write %0d)", tgt_out, RD_FIFO, MAX_OUT));
      end
      e = beat_err(off);
      if (m_req_opcode == `SDF_OP_READ) begin
        q_op[q_wp % QD] = m_req_opcode; q_id[q_wp % QD] = m_req_id; q_st[q_wp % QD] = 2'(e); q_rd[q_wp % QD] = '0;
        if (e == 0) for (int b = 0; b < SB; b++) q_rd[q_wp % QD][8*b +: 8] = tmem[off + b];
        q_due[q_wp % QD] = cyc + 1 + ((int'(rt[14:8] % 100) < P_RSP_DELAY) ? int'(rt[19:16] % 6) : 0);
        q_wp++;
      end else begin
        if (e == 0) for (int b = 0; b < SB; b++) if (m_req_wstrb[b]) tmem[off + b] = m_req_wdata[8*b +: 8];
        if (m_req_opcode == `SDF_OP_WRITE) begin
          q_op[q_wp % QD] = m_req_opcode; q_id[q_wp % QD] = m_req_id; q_st[q_wp % QD] = 2'(e); q_rd[q_wp % QD] = '0;
          q_due[q_wp % QD] = cyc + 1 + ((int'(rt[14:8] % 100) < P_RSP_DELAY) ? int'(rt[19:16] % 6) : 0);
          q_wp++;
        end
      end
    end
    // ---- response channel: registered head, held until accepted (SFB3 R4), in order, responses >= 1 cycle after acceptance
    if (!rst_n) begin
      m_rsp_valid <= 1'b0;
    end else begin
      if (m_rsp_valid && m_rsp_ready) begin q_rp++; tgt_out--; end
      if (!m_rsp_valid || m_rsp_ready) begin
        if (q_rp < q_wp && cyc >= q_due[q_rp % QD] && int'(rt[22:20]) >= (P_RSP_STALL * 8 / 100)) begin
          m_rsp_valid <= 1'b1; m_rsp_id <= q_id[q_rp % QD]; m_rsp_opcode <= q_op[q_rp % QD];
          m_rsp_status <= q_st[q_rp % QD]; m_rsp_rdata <= q_rd[q_rp % QD];
        end else m_rsp_valid <= 1'b0;
      end
    end
    // ---- write data stream: hold valid with stable data until the sequencer takes it
    if (!rst_n) begin
      wd_valid <= 1'b0;
    end else if (wr_stream && c_accepted) begin
      if (wd_valid && wd_ready) begin
        ws_j++;
        wd_valid <= 1'b0;
      end
      if (!wd_valid || wd_ready) begin
        if (ws_j < c_nb && (int'(rt[30:25]) * 100 / 64 >= P_WD_GAP || wd_gap > 6)) begin
          logic [DW-1:0] w;
          int j;
          j = (wd_valid && wd_ready) ? ws_j : ws_j;        // ws_j already advanced above (blocking)
          for (int b = 0; b < SB; b++) begin
            int k;
            k = int'(c_addr & ~AW'(SB - 1)) + j * SB + b - int'(c_addr);
            w[8*b +: 8] = (k >= 0 && k < c_len) ? pbyte(c_n, k) : junk(j, b);
          end
          wd_valid <= 1'b1; wd_data <= w; wd_gap = 0;
        end else if (ws_j < c_nb) wd_gap++;
      end
    end else if (!(wd_valid && !wd_ready)) wd_valid <= 1'b0;
    // ---- read data stream consumer
    if (rst_n && rd_valid && rd_ready) begin
      int off, e;
      logic [SB-1:0] es;
      off = int'((c_addr & ~AW'(SB - 1)) - BASE) + rb_j * SB;
      e = beat_err(off);
      es = exp_strb(rb_j);
      check(rd_stream, "read beat delivered for a command that is not a read");
      check(rb_j < c_nb, "more read beats than the burst has");
      check(rd_status == 2'(e), $sformatf("read beat %0d status %0d != expected %0d", rb_j, rd_status, e));
      check(rd_strb == es, $sformatf("read beat %0d valid mask %h != expected %h", rb_j, rd_strb, es));
      check(rd_last == (rb_j == c_nb - 1), "rd_last flag");
      for (int b = 0; b < SB; b++) if (es[b])
        check(rd_data[8*b +: 8] == ((e == 0) ? gmem[off + b] : 8'h00), $sformatf("read beat %0d lane %0d data %h != %h", rb_j, b, rd_data[8*b +: 8], (e == 0) ? gmem[off + b] : 8'h00));
      rb_j++;
    end
    // ---- completion
    if (rst_n && done_valid && done_ready) begin
      check(!d_seen, "second completion for one command");
      d_seen <= 1'b1; d_status <= done_status; d_reason <= done_reason; d_beats <= int'(done_beats);
      d_errbeat <= int'(done_err_beat); d_bytes <= int'(done_bytes); d_id <= int'(done_id);
      d_count++;
    end
  end

  // expected reject reason, independent arithmetic (64-bit)
  function automatic logic [2:0] exp_reject(input logic [2:0] op, input logic [AW-1:0] a, input int len);
    longint la, le;
    begin
      la = longint'(a); le = la + longint'(len);
      if (op > 3'd2) exp_reject = `SDF_RJ_OPCODE;
      else if (len == 0) exp_reject = `SDF_RJ_ZERO;
      else if (len > MAX_BYTES) exp_reject = `SDF_RJ_TOOLONG;
      else if (le - 1 >= (64'd1 << 32)) exp_reject = `SDF_RJ_WRAP;
      else if (la < longint'(BASE) || le > longint'(BASE) + MEMB) exp_reject = `SDF_RJ_RANGE;
      else if (BOUNDARY != 0 && (la / BOUNDARY) != ((le - 1) / BOUNDARY)) exp_reject = `SDF_RJ_BOUNDARY;
      else exp_reject = `SDF_RJ_NONE;
    end
  endfunction

  // run one burst command to completion and check the outcome
  task automatic run_cmd(input logic [2:0] op, input logic [AW-1:0] a, input int len, input int id_in);
    int guard;
    int id;
    int exp_stat, exp_eb, nerr_ack;
    logic [2:0] rj;
    begin
      tests++;
      id = id_in % (1 << IDW);
      rj = exp_reject(op, a, len);
      c_op = op; c_addr = a; c_len = len; c_id = id; c_reject = (rj != `SDF_RJ_NONE); c_rjr = rj; c_n++;
      c_nb = c_reject ? 0 : int'(((a + AW'(len) - 1) >> WB) - (a >> WB) + 1);
      c_j = 0; ws_j = 0; rb_j = 0; wd_gap = 0; tgt_beats = 0; d_seen = 1'b0; c_accepted = 1'b0;
      wr_stream = (op != `SDF_OP_READ) && !c_reject; rd_stream = (op == `SDF_OP_READ) && !c_reject;
      exp_stat = 0; exp_eb = 0; nerr_ack = 0;
      if (c_reject) exp_stat = 3;
      else for (int j = 0; j < c_nb; j++) begin
        int e;
        e = beat_err(int'((a & ~AW'(SB - 1)) - BASE) + j * SB);
        if (e != 0 && op != `SDF_OP_WRITE_POSTED) begin
          if (exp_stat == 0) begin exp_stat = e; exp_eb = j; end
          nerr_ack++;
        end
      end
      c_active = 1'b1;
      @(posedge clk); #1;
      cmd_valid = 1'b1; cmd_op = op; cmd_addr = a; cmd_len = LENW'(len); cmd_id = IDW'(id);
      guard = 0;
      while (!c_accepted && guard < 2000) begin @(posedge clk); guard++; end
      check(guard < 2000, "command never accepted");
      #1; cmd_valid = 1'b0; cmd_op = '0; cmd_addr = '0; cmd_len = '0;
      guard = 0;
      while (!d_seen && guard < 20000) begin @(posedge clk); guard++; end
      check(guard < 20000, $sformatf("burst did not complete (op %0d addr %h len %0d)", op, a, len));
      repeat (3) @(posedge clk);
      // ---- completion fields
      check(d_status == 2'(exp_stat), $sformatf("completion status %0d != expected %0d (op %0d addr %h len %0d)", d_status, exp_stat, op, a, len));
      check(d_id == id, "completion id");
      if (c_reject) begin
        check(d_reason == rj, $sformatf("reject reason %0d != expected %0d", d_reason, rj));
        check(d_beats == 0, "rejected burst reports beats");
        check(tgt_beats == 0, "rejected burst issued beats");
        x_rej++;
      end else begin
        check(d_beats == c_nb, $sformatf("completion beats %0d != %0d", d_beats, c_nb));
        check(d_bytes == len, "completion bytes");
        check(tgt_beats == c_nb && c_j == c_nb, $sformatf("beats issued %0d != %0d", tgt_beats, c_nb));
        if (exp_stat != 0) check(d_errbeat == exp_eb, $sformatf("first error beat %0d != %0d", d_errbeat, exp_eb));
        if (op == `SDF_OP_READ) check(rb_j == c_nb, $sformatf("read beats delivered %0d != %0d", rb_j, c_nb));
        if (op != `SDF_OP_READ) check(ws_j == c_nb, $sformatf("write data beats consumed %0d != %0d", ws_j, c_nb));
        x_bursts++; x_beats += c_nb; x_bytes += len; x_wire += c_nb * SB; x_errb += nerr_ack;
        // ---- golden memory: command semantics (strobed bytes of non-error beats); compare the touched region
        if (op != `SDF_OP_READ) begin
          for (int k = 0; k < len; k++) begin
            int ao, bj;
            ao = int'(a - BASE) + k;
            bj = (ao / SB) - (int'(a - BASE) / SB);
            if (beat_err(int'((a & ~AW'(SB - 1)) - BASE) + bj * SB) == 0) gmem[ao] = pbyte(c_n, k);
          end
          for (int ao = int'((a & ~AW'(SB - 1)) - BASE); ao < int'(a - BASE) + len + SB && ao < MEMB; ao++)
            check(tmem[ao] == gmem[ao], $sformatf("memory byte %0d: target %h != golden %h (op %0d addr %h len %0d)", ao, tmem[ao], gmem[ao], op, a, len));
        end
      end
      c_active = 1'b0; wr_stream = 1'b0; rd_stream = 1'b0;
      repeat ((rt[3:0] % 3)) @(posedge clk);
    end
  endtask

  // ---------------------------------------------------------------- main
  int n;
  initial begin
    $display("tb_sdf_burst: DW=%0d IDW=%0d MAX_BYTES=%0d RD_FIFO=%0d MAX_OUT=%0d BOUNDARY=%0d", DW, IDW, MAX_BYTES, RD_FIFO, MAX_OUT, BOUNDARY);
    rt = 32'h1BADB002 ^ SEED;
    for (int i = 0; i < MEMB; i++) begin tmem[i] = 8'(i * 7 + 3); gmem[i] = 8'(i * 7 + 3); end
    m_rsp_valid = 1'b0; m_rsp_id = '0; m_rsp_opcode = '0; m_rsp_status = '0; m_rsp_rdata = '0;
    rst_n = 1'b0; repeat (5) @(posedge clk); rst_n = 1'b1; repeat (3) @(posedge clk);

    // B1 alignment sweep: every first-word offset x every length up to two beats + 3, write then read back
    for (int fo = 0; fo < SB; fo++) begin
      for (int len = 1; len <= 2 * SB + 3; len++) begin
        run_cmd(`SDF_OP_WRITE, BASE + AW'(1024 + fo), len, (fo + len) % (1 << IDW));
        run_cmd(`SDF_OP_READ, BASE + AW'(1024 + fo), len, (fo + len) % (1 << IDW));
      end
    end
    $display("  B1 alignment sweep done, %0d bursts", tests);
    // B2 neighbours untouched: a single byte write must not disturb bytes on either side (golden compare covers the region)
    for (int fo = 0; fo < SB; fo++) begin
      run_cmd(`SDF_OP_WRITE, BASE + AW'(3072 + fo), 1, 1);
      run_cmd(`SDF_OP_READ, BASE + AW'(3072 - SB), 3 * SB, 2);
    end
    // B3 lengths: maximum, maximum+1, zero, aligned and unaligned maxima
    run_cmd(`SDF_OP_WRITE, BASE + AW'(2048), MAX_BYTES, 0);
    run_cmd(`SDF_OP_READ, BASE + AW'(2048), MAX_BYTES, 0);
    run_cmd(`SDF_OP_WRITE, BASE + AW'(2048 + 3), MAX_BYTES, 1);
    run_cmd(`SDF_OP_READ, BASE + AW'(2048 + 3), MAX_BYTES, 1);
    run_cmd(`SDF_OP_WRITE_POSTED, BASE + AW'(4096 + 5), MAX_BYTES - 1, 2);
    run_cmd(`SDF_OP_READ, BASE + AW'(4096 + 5), MAX_BYTES - 1, 2);                     // same id: sees the posted writes (SFB3 order)
    run_cmd(`SDF_OP_READ, BASE + AW'(2048), MAX_BYTES + 1, 0);                         // too long
    run_cmd(`SDF_OP_WRITE, BASE + AW'(2048), 0, 0);                                    // zero length
    // B4 rejects: opcode, range (below / above / straddling the end), wrap
    run_cmd(3'd3, BASE + AW'(64), 16, 0);                                              // FENCE is not a burst
    run_cmd(3'd6, BASE + AW'(64), 16, 0);
    run_cmd(`SDF_OP_READ, BASE - 32'd4, 8, 0);                                         // below the window
    run_cmd(`SDF_OP_READ, BASE + AW'(MEMB), 4, 0);                                     // above
    run_cmd(`SDF_OP_WRITE, BASE + AW'(MEMB - 5), 16, 0);                               // straddles the end
    run_cmd(`SDF_OP_READ, BASE + AW'(MEMB - 16), 16, 0);                               // exactly the last 16 bytes: legal
    run_cmd(`SDF_OP_WRITE, 32'hFFFF_FFF0, 64, 0);                                      // wraps the address space
    run_cmd(`SDF_OP_WRITE, 32'hFFFF_FFFF, 1, 0);                                       // last byte of the space (outside LIM: range)
    if (BOUNDARY != 0) begin
      run_cmd(`SDF_OP_WRITE, BASE + AW'(BOUNDARY - 3), 8, 1);                          // crosses the boundary: rejected
      run_cmd(`SDF_OP_WRITE, BASE + AW'(BOUNDARY - 8), 8, 1);                          // ends exactly at the boundary: legal
      run_cmd(`SDF_OP_READ, BASE + AW'(2 * BOUNDARY - 1), 1, 1);                       // last byte before the next one: legal
      run_cmd(`SDF_OP_READ, BASE + AW'(2 * BOUNDARY - 1), 2, 1);                       // crosses
    end
    // B5 error beats: bursts that run into / through / out of the SLVERR and DECERR windows, acknowledged and posted
    for (int k = 0; k < 3; k++) begin
      logic [2:0] op;
      op = (k == 0) ? `SDF_OP_WRITE : (k == 1) ? `SDF_OP_READ : `SDF_OP_WRITE_POSTED;
      run_cmd(op, BASE + AW'(ERR_LO - SB - 3), 3 * SB + 5, 1);                         // enters the SLVERR window
      run_cmd(op, BASE + AW'(ERR_LO + 1), 20, 1);                                      // starts inside
      run_cmd(op, BASE + AW'(ERR_HI - 2), 2 * SB, 2);                                  // leaves it
      run_cmd(op, BASE + AW'(DEC_LO - 2 * SB + 7), 4 * SB, 3 % (1 << IDW));            // DECERR window
      run_cmd(op, BASE + AW'(ERR_LO), 40, 0);
    end
    run_cmd(`SDF_OP_READ, BASE + AW'(ERR_LO - 8), 16, 0);                              // read back what the error writes left
    $display("  B2-B5 done, %0d bursts", tests);

    // B6 randomised bursts
    for (int i = 0; i < NRAND; i++) begin
      logic [31:0] r;
      logic [2:0] op;
      logic [AW-1:0] a;
      int len, k;
      r = seed_mix(SEED, 32'(i + 5000)); k = int'(r[7:0] % 100);
      op = (k < 40) ? `SDF_OP_READ : (k < 75) ? `SDF_OP_WRITE : (k < 95) ? `SDF_OP_WRITE_POSTED : 3'd7;
      r = xs32(r); a = BASE + AW'(r[23:4] % MEMB);
      r = xs32(r); len = 1 + int'(r[15:0] % ((r[19:16] < 4'd3) ? 6 : (r[19:16] < 4'd10) ? (3 * SB) : MAX_BYTES));
      r = xs32(r);
      if (r[3:0] == 4'd0) a = BASE + AW'(MEMB - len + int'(r[7:4] % 5) - 2);          // near the end: sometimes a range reject
      if (r[11:8] == 4'd0) a = BASE + AW'(ERR_LO - int'(r[20:16] % 32));              // near the error window
      if (r[11:8] == 4'd1) a = BASE + AW'(DEC_LO - int'(r[20:16] % 32));
      run_cmd(op, a, len, int'(r[27:24]) % (1 << IDW));
    end
    $display("  B6 random done, %0d bursts total", tests);

    // ---- statistics vs the testbench's own counts
    repeat (10) @(posedge clk);
    check(int'(st_bursts) == x_bursts, $sformatf("counter bursts %0d != %0d", st_bursts, x_bursts));
    check(int'(st_rejected) == x_rej, $sformatf("counter rejected %0d != %0d", st_rejected, x_rej));
    check(int'(st_beats) == x_beats, $sformatf("counter beats %0d != %0d", st_beats, x_beats));
    check(int'(st_bytes) == x_bytes, $sformatf("counter bytes %0d != %0d", st_bytes, x_bytes));
    check(int'(st_wire) == x_wire, $sformatf("counter wire bytes %0d != %0d", st_wire, x_wire));
    check(int'(st_errb) == x_errb, $sformatf("counter error beats %0d != %0d", st_errb, x_errb));
    check(st_proto == 0, "response with unexpected id / opcode");
    check(d_count == tests, $sformatf("completions %0d != commands %0d", d_count, tests));
    check(!busy, "sequencer still busy");
    $display("PERF burst_utilisation_pct=%0d (payload bytes / bytes on the fabric) beats=%0d rejected=%0d busy_cycles=%0d req_stall=%0d starve=%0d credit_stall=%0d rd_stall=%0d",
             (x_wire == 0) ? 0 : (x_bytes * 100) / x_wire, x_beats, x_rej, st_busy, st_rstall, st_starve, st_cstall, st_rdst);
    $display("RESULT tests=%0d checks=%0d errors=%0d %s", tests, checks, errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin
    #(64'd2_000_000_000);
    $display("RESULT tests=%0d checks=%0d errors=%0d FAIL (global timeout)", tests, checks, errors + 1);
    $finish;
  end
endmodule
