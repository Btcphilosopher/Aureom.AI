// =============================================================================
// SilicaFlux SRAMFabric (Project 74) :: sf_sdf_tgt_chk -- SFB3 target-port assertion monitor (VERIFICATION ONLY)
//
// Watches one SFB3 target port (the bridge's t_* side) and checks, every cycle after reset:
//   X     valid / ready of both channels are never X / Z
//   R2    a held request (valid && !ready) stays valid with an unchanged payload
//   R4    a held response (valid && !ready) stays valid with an unchanged payload
//   R5    EXACTLY ONE response per accepted request:
//           * a response may only be presented for a (src,id) pair that has an accepted request from an EARLIER cycle
//             (never in the acceptance cycle),
//           * its opcode must echo the oldest outstanding request of the pair (in-order per pair),
//           * `quiet_i` (testbench: no traffic in flight) requires every pair to be balanced -> nothing lost, nothing duplicated
//   rules of the bridge contract:  err status never on a read of a legal address is NOT checked here (data model is in the
//   scoreboards); this monitor is protocol-only so it can be bound to any SFB3 target.
// Counts violations (each also printed as a [FAIL] line unless QUIET).  Not synthesizable.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_sdf_tgt_chk #(
  parameter int NM  = 4,
  parameter int IDW = 2,
  parameter int AW  = 32,
  parameter int DW  = 128,
  parameter     NAME = "sfb3-target",
  parameter bit QUIET = 1'b0,            // 1: count violations without printing (self-test)
  parameter int SRCW = (NM > 1) ? $clog2(NM) : 1,
  parameter int SB   = DW / 8
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            t_req_valid,
  input  wire logic            t_req_ready,
  input  wire logic [2:0]      t_req_opcode,
  input  wire logic [SRCW-1:0] t_req_src,
  input  wire logic [IDW-1:0]  t_req_id,
  input  wire logic [AW-1:0]   t_req_addr,
  input  wire logic [DW-1:0]   t_req_wdata,
  input  wire logic [SB-1:0]   t_req_wstrb,
  input  wire logic            t_rsp_valid,
  input  wire logic            t_rsp_ready,
  input  wire logic [SRCW-1:0] t_rsp_src,
  input  wire logic [IDW-1:0]  t_rsp_id,
  input  wire logic [2:0]      t_rsp_opcode,
  input  wire logic [1:0]      t_rsp_status,
  input  wire logic [DW-1:0]   t_rsp_rdata,
  input  wire logic            quiet_i,
  output int                   violations,
  output int                   outstanding_o,
  output int                   accepted_o,
  output int                   answered_o
);
  localparam int NID = 1 << IDW;
  localparam int NPAIR = NM * NID;
  localparam int QD = 64;
  int          cnt [NPAIR];
  logic [2:0]  opq [NPAIR][QD];
  int          wp [NPAIR], rp [NPAIR];
  logic        q_hold, r_hold;
  logic [3+SRCW+IDW+AW+DW+SB-1:0] q_pay;
  logic [SRCW+IDW+3+2+DW-1:0]     r_pay;
  int          total;

  initial begin
    violations = 0; outstanding_o = 0; accepted_o = 0; answered_o = 0; total = 0;
    for (int p = 0; p < NPAIR; p++) begin cnt[p] = 0; wp[p] = 0; rp[p] = 0; end
    q_hold = 1'b0; r_hold = 1'b0;
  end

  task automatic bad(input string msg);
    begin
      if (!QUIET) $display("[FAIL] t=%0t %s: %s", $time, NAME, msg);
      violations++;
    end
  endtask

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q_hold <= 1'b0; r_hold <= 1'b0; total = 0; outstanding_o = 0;
      for (int p = 0; p < NPAIR; p++) begin cnt[p] = 0; wp[p] = 0; rp[p] = 0; end
    end else begin
      int pr_q, pr_r;
      pr_q = int'(t_req_src) * NID + int'(t_req_id);
      pr_r = int'(t_rsp_src) * NID + int'(t_rsp_id);
      if ($isunknown({t_req_valid, t_req_ready, t_rsp_valid, t_rsp_ready})) bad("X/Z on a handshake signal");
      if (q_hold && (!t_req_valid || {t_req_opcode, t_req_src, t_req_id, t_req_addr, t_req_wdata, t_req_wstrb} !== q_pay)) bad("R2 request changed or withdrawn while held");
      if (r_hold && (!t_rsp_valid || {t_rsp_src, t_rsp_id, t_rsp_opcode, t_rsp_status, t_rsp_rdata} !== r_pay)) bad("R4 response changed or withdrawn while held");
      // response handshake first: it can only match requests accepted in EARLIER cycles (cnt is updated after)
      if (t_rsp_valid && t_rsp_ready) begin
        if (pr_r >= NPAIR || cnt[pr_r] <= 0) bad("R5 response without an earlier accepted request of that (src,id)");
        else begin
          if (opq[pr_r][rp[pr_r] % QD] !== t_rsp_opcode) bad("R5 response opcode does not echo the oldest outstanding request of the pair");
          rp[pr_r]++; cnt[pr_r]--; total--; answered_o++;
        end
      end
      if (t_rsp_valid && !t_rsp_ready && (pr_r >= NPAIR || cnt[pr_r] <= 0)) bad("R5 response presented for a pair with nothing outstanding");
      if (t_req_valid && t_req_ready) begin
        if (pr_q < NPAIR) begin
          if (cnt[pr_q] >= QD) bad("more than 64 outstanding requests on one (src,id): monitor depth exceeded");
          else begin opq[pr_q][wp[pr_q] % QD] = t_req_opcode; wp[pr_q]++; cnt[pr_q]++; total++; accepted_o++; end
        end
      end
      outstanding_o = total;
      if (quiet_i && total != 0) bad("quiescent port still has outstanding transactions (lost response)");
      q_hold <= t_req_valid && !t_req_ready;
      q_pay  <= {t_req_opcode, t_req_src, t_req_id, t_req_addr, t_req_wdata, t_req_wstrb};
      r_hold <= t_rsp_valid && !t_rsp_ready;
      r_pay  <= {t_rsp_src, t_rsp_id, t_rsp_opcode, t_rsp_status, t_rsp_rdata};
    end
  end
endmodule

`default_nettype wire
