#!/usr/bin/env python3
"""SilicaFlux SRAMFabric (P74) regression runner (Verilator 5.x, --binary --timing).

  python3 sim/run_regress.py --suite sdf [--jobs 4] [--only NAME ...] [--out reports/regress_sdf.json]
  python3 sim/run_regress.py --list

A SUITE is a list of CASES; a CASE is (name, testbench top, tb file, -G overrides).  Every case is built into
build/<suite>_<name>/ and run; the RESULT line printed by the testbench is parsed.  A case passes only when the testbench
printed `RESULT tests=.. checks=.. errors=0 PASS`, the process exited 0 and no %Error / assertion / [FAIL] text appeared.
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VFLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "--assert",
          "-DSF_ASSERT", "-Wno-DECLFILENAME"]
RTL = ["-f", "sim/files_rtl.f"]
NOC = ["-f", "sim/files_noc.f"]


def case(name, top, tb, over=None, flags=(), run_args=()):
    return dict(name=name, top=top, tb=tb, over=over or {}, flags=list(flags), run_args=list(run_args))


SDF = "tb/tb_sdf.sv"
SUITES = {}
SUITES["sdf"] = [
    case("base_dw128", "tb_sdf", SDF, {}),
    case("dw32_lanes", "tb_sdf", SDF, {"DW": 32}),
    case("dw64_lanes", "tb_sdf", SDF, {"DW": 64, "SEED": 0x1234567}),
    case("np2_dw64", "tb_sdf", SDF, {"NP": 2, "DW": 64, "NM": 4}),
    case("np4_dw32_nm4", "tb_sdf", SDF, {"NP": 4, "DW": 32, "NM": 4, "NSLOT": 8}),
    case("ntp2_nm4", "tb_sdf", SDF, {"NTP": 2, "NM": 4}),
    case("ntp4_nm4_dw32", "tb_sdf", SDF, {"NTP": 4, "NM": 4, "DW": 32}),
    case("ntp2_np2_dw64", "tb_sdf", SDF, {"NTP": 2, "NP": 2, "NM": 4, "DW": 64}),
    case("noreg_req", "tb_sdf", SDF, {"REQ_REG": 0}),
    case("noreg_rsp_noflush", "tb_sdf", SDF, {"RSP_REG": 0, "RUN_FLUSH": 0}),
    case("noreg_rsp_np2", "tb_sdf", SDF, {"RSP_REG": 0, "RUN_FLUSH": 0, "NP": 2, "NM": 4, "DW": 64}),
    case("noreg_both_noflush", "tb_sdf", SDF, {"REQ_REG": 0, "RSP_REG": 0, "RUN_FLUSH": 0, "DW": 32}),
    case("rl2_slot6", "tb_sdf", SDF, {"READ_LATENCY": 2, "NSLOT": 6}),
    case("rl3_slot6_np2", "tb_sdf", SDF, {"READ_LATENCY": 3, "NSLOT": 6, "NP": 2, "NM": 4}),
    case("ecc_dw128", "tb_sdf", SDF, {"ECC_EN": 1, "RUN_ECC": 1}),
    case("ecc_dw32_rl2", "tb_sdf", SDF, {"ECC_EN": 1, "RUN_ECC": 1, "DW": 32, "READ_LATENCY": 2}),
    case("noc0_direct_dw128", "tb_sdf", SDF, {"NOC": 0, "NM": 2, "NTP": 2}),
    case("noc0_direct_dw32_np2", "tb_sdf", SDF, {"NOC": 0, "NM": 3, "NTP": 3, "DW": 32, "NP": 2}),
    case("noc0_noreg_noflush", "tb_sdf", SDF, {"NOC": 0, "NM": 2, "NTP": 2, "REQ_REG": 0, "RSP_REG": 0, "RUN_FLUSH": 0, "DW": 64}),
    case("noalign_chk", "tb_sdf", SDF, {"CHK_ALIGN": 0}),
    case("allow_half", "tb_sdf", SDF, {"ALLOW_HI_DIV": 2}),
    case("timeout_recovery", "tb_sdf", SDF, {"TIMEOUT": 48, "RUN_TIMEOUT": 1}),
    case("timeout_np2_dw64", "tb_sdf", SDF, {"TIMEOUT": 48, "RUN_TIMEOUT": 1, "NP": 2, "DW": 64, "NM": 4}),
    case("no_stall", "tb_sdf", SDF, {"P_RSP_STALL": 0, "P_REQ_IDLE": 0, "SEED": 0x77}),
    case("heavy_rsp_stall", "tb_sdf", SDF, {"P_RSP_STALL": 75, "P_REQ_IDLE": 5, "SEED": 0x99}),
    case("fixed_arb_nm4", "tb_sdf", SDF, {"ARB": 0, "NM": 4, "SEED": 0x4242}),
    case("nb2_depth128", "tb_sdf", SDF, {"NB": 2, "DEPTH": 128}),
    case("nb1_depth256", "tb_sdf", SDF, {"NB": 1, "DEPTH": 256, "NM": 2}),
    case("idw1_nm2", "tb_sdf", SDF, {"IDW": 1, "NM": 2}),
    case("burst_e2e_dw128", "tb_sdf", SDF, {"NBURST": 1, "NM": 3}),
    case("burst_e2e_dw32_2bm", "tb_sdf", SDF, {"NBURST": 2, "NM": 4, "DW": 32}),
    case("burst_e2e_dw64_ntp2_np2", "tb_sdf", SDF, {"NBURST": 2, "NM": 4, "NTP": 2, "NP": 2, "DW": 64}),
    case("burst_e2e_ecc_rl2", "tb_sdf", SDF, {"NBURST": 1, "NM": 3, "ECC_EN": 1, "RUN_ECC": 1, "READ_LATENCY": 2}),
    case("burst_e2e_fifo1_max64", "tb_sdf", SDF, {"NBURST": 2, "NM": 4, "MAXB": 64, "BRD_FIFO": 1, "BMAXOUT": 1, "P_RSP_STALL": 60}),
    case("seed2_long", "tb_sdf", SDF, {"SEED": 0x5EED0002, "NRAND": 3000, "NM": 4}),
]

BU = "tb/tb_sdf_burst.sv"
SUITES["burst"] = [
    case("dw128", "tb_sdf_burst", BU, {}),
    case("dw32", "tb_sdf_burst", BU, {"DW": 32, "SEED": 0x1111}),
    case("dw64_bnd1024", "tb_sdf_burst", BU, {"DW": 64, "BOUNDARY": 1024, "SEED": 0x2222}),
    case("dw128_bnd256_max1024", "tb_sdf_burst", BU, {"BOUNDARY": 256, "MAX_BYTES": 1024, "SEED": 0x3333}),
    case("fifo1_out1", "tb_sdf_burst", BU, {"RD_FIFO": 1, "MAX_OUT": 1, "SEED": 0x4444}),
    case("fifo16_out16_dw32", "tb_sdf_burst", BU, {"RD_FIFO": 16, "MAX_OUT": 16, "DW": 32, "SEED": 0x5555}),
    case("no_stall_dw64", "tb_sdf_burst", BU, {"DW": 64, "P_TREQ_STALL": 0, "P_RSP_DELAY": 0, "P_RSP_STALL": 0, "P_WD_GAP": 0, "P_RD_STALL": 0, "P_DONE_STALL": 0}),
    case("heavy_stall", "tb_sdf_burst", BU, {"P_TREQ_STALL": 80, "P_RSP_DELAY": 90, "P_RSP_STALL": 70, "P_WD_GAP": 70, "P_RD_STALL": 80, "P_DONE_STALL": 80, "SEED": 0x6666}),
    case("idw1_max64", "tb_sdf_burst", BU, {"IDW": 1, "MAX_BYTES": 64, "SEED": 0x7777}),
    case("long_random", "tb_sdf_burst", BU, {"NRAND": 6000, "DW": 32, "MAX_BYTES": 512, "SEED": 0x8888}),
]

IT = "tb/tb_sdf_integ.sv"
SUITES["integ"] = [
    case("dw128", "tb_sdf_integ", IT, {}),
    case("dw32", "tb_sdf_integ", IT, {"DW": 32, "SEED": 0x1}),
    case("dw64_np2", "tb_sdf_integ", IT, {"DW": 64, "NP": 2}),
    case("ntp2_dw128", "tb_sdf_integ", IT, {"NTP": 2}),
    case("ecc_rl2", "tb_sdf_integ", IT, {"ECC_EN": 1, "READ_LATENCY": 2}),
    case("noreg_both", "tb_sdf_integ", IT, {"REQ_REG": 0, "RSP_REG": 0, "DW": 64}),
    case("rl3_nb2", "tb_sdf_integ", IT, {"READ_LATENCY": 3, "NB": 2, "DEPTH": 512}),
]

SUITES["chk"] = [case("monitor_selftest", "tb_sdf_chk_selftest", "tb/tb_sdf_chk_selftest.sv", {})]

# extra suites are registered by the later test benches (burst, integration) via sim/suites_extra.py
try:
    sys.path.insert(0, os.path.join(ROOT, "sim"))
    import suites_extra  # noqa: E402
    suites_extra.register(SUITES, case)
except ImportError:
    pass


def run_cmd(cmd, cwd, timeout):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or ""), time.time() - t0
    except subprocess.TimeoutExpired as e:
        out = e.stdout.decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        return 124, out + "\n[TIMEOUT]", time.time() - t0


def run_case(suite, c, build_timeout=900, run_timeout=1500):
    bdir = os.path.join(ROOT, "build", f"{suite}_{c['name']}")
    shutil.rmtree(bdir, ignore_errors=True)
    os.makedirs(os.path.dirname(bdir), exist_ok=True)
    gs = [f"-G{k}={v}" for k, v in c["over"].items()]
    cmd = (["verilator"] + VFLAGS + RTL + NOC + [c["tb"], "--top-module", c["top"], "-Mdir", bdir, "-o", "tb.exe"] + gs + c["flags"])
    rc, out, bs = run_cmd(cmd, ROOT, build_timeout)
    res = dict(suite=suite, name=c["name"], overrides=c["over"], build_rc=rc, build_secs=round(bs, 1))
    if rc != 0 or not os.path.exists(os.path.join(bdir, "tb.exe")):
        res.update(status="BUILD-FAIL", detail=[l for l in out.splitlines() if l.startswith("%Error")][:5])
        return res
    rc, out, rs = run_cmd([os.path.join(bdir, "tb.exe")] + c["run_args"], ROOT, run_timeout)
    m = None
    for l in out.splitlines():
        if l.startswith("RESULT"):
            m = l
    kv = dict(re.findall(r"(\w+)=([^\s]+)", m)) if m else {}
    bad = [l for l in out.splitlines() if re.search(r"%Error|%Fatal|Assertion failed|\[FAIL\]|\$fatal", l)]
    ok = (m is not None and rc == 0 and kv.get("errors") == "0" and m.rstrip().endswith("PASS") and not bad)
    res.update(run_rc=rc, run_secs=round(rs, 1), result=m, checks=int(kv.get("checks", 0)), tests=int(kv.get("tests", 0)),
               errors=int(kv.get("errors", -1)) if "errors" in kv else None, status="PASS" if ok else "FAIL")
    perf = [l for l in out.splitlines() if l.startswith("PERF")]
    if perf:
        res["perf"] = perf
    if not ok:
        res["detail"] = (bad or out.splitlines()[-6:])[:8]
    with open(os.path.join(bdir, "run.log"), "w") as f:
        f.write(out)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", action="append")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--out")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        for s, cs in SUITES.items():
            print(s, [c["name"] for c in cs])
        return 0
    suites = a.suite or list(SUITES)
    allres = []
    for s in suites:
        cases = [c for c in SUITES[s] if not a.only or c["name"] in a.only]
        print(f"== suite {s}: {len(cases)} cases", flush=True)
        with ThreadPoolExecutor(max_workers=a.jobs) as ex:
            futs = [ex.submit(run_case, s, c) for c in cases]
            for f in futs:
                r = f.result()
                allres.append(r)
                print(f"  {r['status']:10s} {r['name']:26s} checks={r.get('checks','-')} build={r['build_secs']}s run={r.get('run_secs','-')}s "
                      f"{'' if r['status']=='PASS' else r.get('detail')}", flush=True)
    npass = sum(1 for r in allres if r["status"] == "PASS")
    tot = sum(r.get("checks", 0) for r in allres)
    print(f"SUMMARY {npass}/{len(allres)} cases pass, {tot} self-checks")
    if a.out:
        with open(os.path.join(ROOT, a.out), "w") as f:
            json.dump(dict(cases=allres, passed=npass, total=len(allres), checks=tot), f, indent=1)
    return 0 if npass == len(allres) else 1


if __name__ == "__main__":
    sys.exit(main())
