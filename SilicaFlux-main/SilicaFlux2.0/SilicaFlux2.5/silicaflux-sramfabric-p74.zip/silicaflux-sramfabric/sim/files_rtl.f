// SilicaFlux SRAMFabric (P74) RTL file list (paths relative to the project root)
+incdir+rtl
+incdir+third_party/memorycore/rtl
+incdir+third_party/ras_secded
+incdir+third_party/sramlib_mbist
// ---- vendored, byte-identical: SRAM controller, banks, scratchpads (silicaflux-memorycore-sram)
third_party/memorycore/rtl/sf_sram_core.sv
third_party/memorycore/rtl/backends/sf_sram_fpga_bram.sv
third_party/memorycore/rtl/backends/sf_sram_asic_sky130.sv
third_party/memorycore/rtl/sf_sram_macro_wrapper.sv
third_party/memorycore/rtl/sf_ecc_enc.sv
third_party/memorycore/rtl/sf_ecc_dec.sv
third_party/memorycore/rtl/sf_ecc_counters.sv
third_party/memorycore/rtl/sf_sram_bank.sv
third_party/memorycore/rtl/sf_sram_controller.sv
third_party/memorycore/rtl/sf_sync_fifo.sv
third_party/memorycore/rtl/sf_vector_scratchpad.sv
third_party/memorycore/rtl/sf_ts_port.sv
third_party/memorycore/rtl/sf_tensor_scratchpad.sv
third_party/ras_secded/sfras_secded_enc.sv
third_party/ras_secded/sfras_secded_dec.sv
// ---- new in Project 74
rtl/sf_sdf_skid.sv
rtl/sf_sdf_txq.sv
rtl/sf_sdf_addr_xlate.sv
rtl/sf_sdf_port.sv
rtl/sf_sram_datafabric.sv
rtl/sf_sdf_burst_seq.sv
rtl/sf_sram_fabric_top.sv
rtl/sf_sdf_tgt_chk.sv
