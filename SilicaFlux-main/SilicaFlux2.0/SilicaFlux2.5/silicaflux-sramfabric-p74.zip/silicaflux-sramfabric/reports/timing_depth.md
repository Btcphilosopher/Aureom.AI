# TIMING JUSTIFICATION FOR THE REGISTERED BOUNDARIES (logic depth, Yosys 0.33 generic gates)

> **Not a timing result.** No PDK, no STA, no wire model. `depth` = number of generic gates (AND / NAND / OR / NOR / XOR / XNOR / MUX / NOT cells after `abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX`) on the longest combinational path of the cone; flip-flops are path boundaries. It is a relative indicator of how much logic sits between two registers, used to decide whether a pipeline register is justified. Reproduce: `make syn`.

Cones of the **bridge + SRAM controller** (one target port, `NB = 4`, `DEPTH = 64`, `NSLOT = 8`, `DW = 128`, `NP = 1`), measured by keeping only one output cone of `syn/sf_sdf_syn_wrap.sv`:

| `REQ_REG` | `RSP_REG` | request cone: input -> `t_req_ready` | response cone: inputs -> `t_rsp_*` | bridge -> controller cone: inputs -> `c_req_*` |
|---|---|---|---|---|
| 0 | 0 | 14 | 28 | 8 |
| 0 | 1 | 13 | 2 | 8 |
| 1 | 0 | 1 | 28 | 8 |
| 1 | 1 | 1 | 2 | 8 |

Reading: the request cone is the path from the fabric request (`t_req_valid`, address, ids) through the bridge decode, the controller's decode and per-bank grant logic, and back to `t_req_ready`. With `REQ_REG = 1` it ends at the skid buffer's registered ready (depth 1-2); with `REQ_REG = 0` the controller grant logic is in the fabric's request path. The response cone is the path from controller response and the transaction queue head to the SFB3 response; `RSP_REG = 1` ends it at the response register. The default `REQ_REG = RSP_REG = 1` therefore trades 2 cycles of latency (measured, reports/PERFORMANCE.md) for the shortest combinational cones and for the flush-safe response (R4). Both registers are full-throughput stages (no throughput loss, measured).

## Longest path inside the bridge slice alone (`sf_sdf_port`, controller ports are boundary ports)

| configuration | longest path (gates) | cells | flip-flops |
|---|---|---|---|
| port_req0_rsp0 | 57 | 7024 | 3888 |
| port_req1_rsp0 | 57 | 8314 | 4576 |
| port_req0_rsp1 | 53 | 7222 | 4304 |
| port_req1_rsp1 | 53 | 8455 | 4988 |
| port_dw32_np2 | 51 | 8165 | 4605 |
| port_to1024 | 53 | 8622 | 5013 |

