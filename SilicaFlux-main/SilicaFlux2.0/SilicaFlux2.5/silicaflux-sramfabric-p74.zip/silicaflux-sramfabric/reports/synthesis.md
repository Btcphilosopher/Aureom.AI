# SYNTHESIS (Yosys 0.33, generic gates; no PDK, no timing, no area in um^2)

All numbers are Yosys cell / flip-flop counts after `proc; flatten; memory -nomap; techmap; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX`. They are a size indicator only. Memories (`pc`, `bacc`, ... turned into registers by Yosys; the transaction-queue arrays) are counted as flip-flops where Yosys maps them to registers.

| module / configuration | cells | flip-flops | longest comb path (gates) | return code |
|---|---|---|---|---|
| port_req0_rsp0 | 7024 | 3888 | 57 | 0 |
| port_req0_rsp1 | 7222 | 4304 | 53 | 0 |
| port_req1_rsp0 | 8314 | 4576 | 57 | 0 |
| port_req1_rsp1 | 8455 | 4988 | 53 | 0 |
| port_dw32_np2 | 8165 | 4605 | 51 | 0 |
| port_dw128_np1_txq8 | 8419 | 4908 | 53 | 0 |
| port_to1024 | 8622 | 5013 | 53 | 0 |
| burst_seq_dw128 | 5988 | 3201 | 38 | 0 |
| burst_seq_dw32 | 3624 | 1752 | 42 | 0 |
| xlate_dw128 | 34 | 0 | 8 | 0 |

Every configuration synthesizes (return code 0). `sf_sdf_tgt_chk`, the testbenches and `syn/sf_sdf_syn_wrap.sv` are verification / analysis only and are not synthesizable.

