# third_party - existing SilicaFlux code reused BYTE-IDENTICAL (never edited here)

Source repository: `btcphilosopher/Aureom.AI`, directory `SilicaFlux-main/` (nested project archives). `SHA256SUMS` lists the digest of every vendored file: `cd third_party && sha256sum -c SHA256SUMS` (also `make verify-vendored`).

| directory | files | upstream archive | why reused instead of rewritten |
|---|---|---|---|
| `memorycore/rtl/` | `sf_sram_controller.sv`, `sf_sram_bank.sv`, `sf_sram_core.sv`, `sf_sram_macro_wrapper.sv`, `backends/*`, `sf_ecc_*.sv`, `sf_sync_fifo.sv`, `sf_vector_scratchpad.sv`, `sf_tensor_scratchpad.sv`, `sf_ts_port.sv`, `sf_sram_defs.svh` | `SilicaFlux-main/silicaflux-memorycore-sram.zip` (MemoryCore: "SRAM architecture, controller and physical-integration package") | the SRAMController / SRAMBank / VectorScratch / TensorScratch the bridge must connect to; its contract (`memorycore/CONTRACT.md`, copied) is a fixed point of this design |
| `ras_secded/` | `sfras_secded_enc.sv`, `sfras_secded_dec.sv`, `sfras_*.svh` | `SilicaFlux2.0/SilicaFlux2.5/silicaflux-ras-project26.zip` via MemoryCore | the controller's ECC leaf codec |
| `sramlib_mbist/` | `sram_mbist_march.sv`, `sram_defs.svh` | `silicaflux-sramlib.zip` via MemoryCore | include path of the controller package (not instantiated here) |
| `noc_sfb3/` | `rtl/sfn_*.sv`, `rtl/silicaflux_noc.sv`, `rtl/sfb_arbiter.sv`, `rtl/sfb_addr_decoder.sv`, `tb/sfn_protocol_checker.sv`, `tb/sfn_tb_common.svh`, `PROTOCOL_SFB3.md` | `SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric-noc.zip` (Project 22; identical to the copy vendored by MemoryCore - verified byte for byte against the P22 archive) | the implemented DataFabric NoC (SFB3). Used only as the real fabric in the tests, with its own protocol checker; the normative protocol text is `PROTOCOL_SFB3.md` |
| `memorycore/sim_models/` | `sky130_sram_standin.sv` | MemoryCore | labelled stand-in model for the SKY130 backend (not the vendor model); unused by the default flows |

**Not vendored on purpose:** MemoryCore's `rtl/sf_sram_datafabric.sv` (the Project-71 single-port adapter). This project's `rtl/sf_sram_datafabric.sv` has the same module name and supersedes it (docs/AUDIT.md sec. 2, docs/PROTOCOL_MAPPING.md sec. 5); keeping both would clash.

Nothing in this directory is part of the new-RTL claim; the new RTL lives in `rtl/`.
