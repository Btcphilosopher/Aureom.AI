# Codec formal proofs (Yosys 0.33 SAT)

298 / 298 proof obligations PROVED, 0 FAILED.

| top | INV | jobs | all proved | asserts (sum) | CPU seconds (sum) |
|---|---|---|---|---|---|
| f_clean | inv=0 | 1 | yes | 3 | 5 |
| f_all_safe | inv=0 | 1 | yes | 8 | 4 |
| f_all_none | inv=0 | 1 | yes | 1 | 4 |
| f_eq_enc | inv=0 | 1 | yes | 1 | 4 |
| f_eq_dec | inv=0 | 1 | yes | 9 | 6 |
| f_single | inv=0 | 1 | yes | 351 | 93 |
| f_all_fix | inv=0 | 72 | yes | 72 | 323 |
| f_double | inv=0 | 71 | yes | 10221 | 6345 |
| f_clean | inv=3 | 1 | yes | 4 | 8 |
| f_all_safe | inv=3 | 1 | yes | 8 | 8 |
| f_all_none | inv=3 | 1 | yes | 1 | 8 |
| f_eq_enc | inv=3 | 1 | yes | 1 | 8 |
| f_eq_dec | inv=3 | 1 | yes | 9 | 12 |
| f_single | inv=3 | 1 | yes | 360 | 189 |
| f_all_fix | inv=3 | 72 | yes | 72 | 663 |
| f_double | inv=3 | 71 | yes | 10224 | 14268 |
