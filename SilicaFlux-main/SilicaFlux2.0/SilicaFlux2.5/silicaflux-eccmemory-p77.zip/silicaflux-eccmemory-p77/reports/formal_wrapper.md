# Wrapper formal results (Yosys 0.33, bounded model checking)

Harness: `formal/wrapper_formal.sv` (K=16, 4 words, two byte lanes so that partial writes / RMW exist; every input free in every cycle,
including the raw MBIST port so the solver can place arbitrary stored words in the array; reset forced low for cycles 0-1, free afterwards).
Properties: the RTL assertion block (`SF_ASSERT`, atomicity / no-accept-while-locked / FIFO bounds / one event kind / ...) plus port-level shadow checks (B1-B4).
**These are BOUNDED proofs (no violation exists within the stated number of cycles), not unbounded proofs.**

| config | description | depth | assertions | result |
|---|---|---|---|---|
| F1 | LAT=1, external scrub master, FI off | 20 | all | **PROVED** |
| F2 | LAT=3 (RD_LAT=2 + DEC_PIPE), internal scrub engine, FI on, re-init after MBIST | 16 | all | **PROVED** |

## Reachability (cover) runs -- each must produce a witness (counter-example to the negated goal)

| config | goal | depth | result |
|---|---|---|---|
| F1 | bank locked (RMW / scrub FIX) | 20 | **WITNESS** |
| F1 | corrected read returned | 20 | **WITNESS** |
| F1 | uncorrectable read returned | 20 | **WITNESS** |
| F1 | RMW aborted on an uncorrectable word | 20 | **WITNESS** |
| F1 | RAS event raised | 20 | **WITNESS** |
| F1 | MBIST port granted | 20 | **WITNESS** |
| F1 | write acknowledged | 20 | **WITNESS** |
| F1 | response credits exhausted | 20 | **WITNESS** |
| F1 | fatal request raised | 20 | **WITNESS** |
| F1 | RMW completes on a corrected word (write-back path) | 20 | **WITNESS** |
| F2 | bank locked (RMW / scrub FIX) | 20 | **WITNESS** |
| F2 | MBIST port granted | 20 | **WITNESS** |
| F2 | RMW completes on a corrected word (write-back path) | 20 | **WITNESS** |
| F2 | scrub engine busy | 20 | **WITNESS** |
| F2 | init engine busy | 20 | **WITNESS** |
| F2 | fault injection fires | 20 | **WITNESS** |
