// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_sram_ecc_fi
// Controlled fault injection for the ECC SRAM wrapper.
//
// PRODUCTION SAFETY
//   FI_EN = 0 (default in the wrapper): the whole block is removed -- no registers,
//   no mask path, outputs tied off.  Nothing can be injected and nothing leaks.
//   FI_EN = 1: a command is honoured only while  auth_i && enable_i :
//     auth_i    hardware authorisation (e.g. lifecycle / debug-unlock fuse) -- the
//               integrator ties this low in production
//     enable_i  software enable (register bit)
//   A command refused for lack of authorisation raises blocked_o (pulse) and
//   increments blocked_cnt_o; it has NO other effect.
//
// MODES (cmd_mode_i)
//   SF_ECC_FI_WRITE  one-shot: the next write (optionally to cmd_addr_i) is stored
//                    with `mask ^` applied -> a LATENT error in the array that
//                    persists until the word is rewritten or scrubbed
//   SF_ECC_FI_READ   one-shot: the next read (optionally of cmd_addr_i) sees the raw
//                    word XOR mask -> a TRANSIENT error, array untouched
//   SF_ECC_FI_STUCK  persistent: every read of the address sees  (raw & ~mask) |
//                    (val & mask) until cleared -> a HARD fault that survives
//                    write-back (corrected-error persistence)
//   The mask is N bits wide over the STORED word: bits [K-1:0] hit data, [K+R-1:K]
//   check bits, [K+R] the overall parity bit.  Single, double, data-only and ECC-only
//   errors are just different masks.
//
// Re-arming while a one-shot is still armed or its tagged read is still in flight is
// refused (busy_o) -- it would overwrite a mask that is in use.
// Classification: SYNTHESIZABLE (FI_EN = 1) / empty (FI_EN = 0)
// =============================================================================
`include "sf_secded_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sf_sram_ecc_fi #(
  parameter int N     = 72,
  parameter int AW    = 8,
  parameter int FI_EN = 0
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  // authorisation
  input  wire logic          auth_i,
  input  wire logic          enable_i,
  // command (pulse)
  input  wire logic          cmd_valid_i,
  input  wire logic [1:0]    cmd_mode_i,
  input  wire logic [N-1:0]  cmd_mask_i,
  input  wire logic [N-1:0]  cmd_val_i,          // stuck-at values (STUCK mode)
  input  wire logic [AW-1:0] cmd_addr_i,
  input  wire logic          cmd_addr_en_i,      // 0 = match any address
  input  wire logic          clear_i,            // disarm everything (always allowed)
  // wrapper hooks
  input  wire logic          ld_rd_i,            // a macro read is being loaded into the issue stage
  input  wire logic [AW-1:0] ld_rd_addr_i,
  input  wire logic          ld_wr_i,            // a (non-init) macro write is being loaded
  input  wire logic [AW-1:0] ld_wr_addr_i,
  output logic               take_rd_o,          // tag that read with the transient mask
  output logic      [N-1:0]  wr_mask_o,          // XOR onto the stored word being loaded
  input  wire logic          res_fird_i,         // the read reaching the decode stage carries the tag
  input  wire logic [AW-1:0] res_addr_i,
  input  wire logic [N-1:0]  raw_i,
  output logic      [N-1:0]  raw_o,
  // status
  output logic               armed_o,
  output logic               stuck_o,
  output logic               fired_o,            // pulse: an injection was applied
  output logic               blocked_o,          // pulse: command refused (not authorised)
  output logic               busy_o,             // pulse: command refused (one-shot still in use)
  output logic      [15:0]   blocked_cnt_o
);
  if (FI_EN == 0) begin : g_off
    assign take_rd_o     = 1'b0;
    assign wr_mask_o     = '0;
    assign raw_o         = raw_i;
    assign armed_o       = 1'b0;
    assign stuck_o       = 1'b0;
    assign fired_o       = 1'b0;
    assign blocked_o     = 1'b0;
    assign busy_o        = 1'b0;
    assign blocked_cnt_o = '0;
  end else begin : g_on
    logic          arm_wr_q, arm_rd_q, rd_pend_q;
    logic [N-1:0]  wmask_q, rmask_q;
    logic [AW-1:0] waddr_q, raddr_q;
    logic          waddr_en_q, raddr_en_q;
    logic          stuck_q;
    logic [N-1:0]  smask_q, sval_q;
    logic [AW-1:0] saddr_q;
    logic          saddr_en_q;
    logic          fired_q, blocked_q, busy_q;
    logic [15:0]   bcnt_q;

    wire cmd_ok = auth_i && enable_i;

    wire wr_hit = arm_wr_q && ld_wr_i && (!waddr_en_q || (ld_wr_addr_i == waddr_q));
    wire rd_hit = arm_rd_q && ld_rd_i && (!raddr_en_q || (ld_rd_addr_i == raddr_q));

    assign wr_mask_o = wr_hit ? wmask_q : '0;
    assign take_rd_o = rd_hit;

    // transient mask applied to the tagged read, then the persistent stuck-at
    logic [N-1:0] raw_t;
    always_comb begin
      raw_t = raw_i;
      if (res_fird_i) raw_t = raw_t ^ rmask_q;
      if (stuck_q && (!saddr_en_q || (res_addr_i == saddr_q)))
        raw_t = (raw_t & ~smask_q) | (sval_q & smask_q);
    end
    assign raw_o = raw_t;

    always_ff @(posedge clk) begin
      if (!rst_n) begin
        arm_wr_q <= 1'b0; arm_rd_q <= 1'b0; rd_pend_q <= 1'b0; stuck_q <= 1'b0;
        fired_q <= 1'b0; blocked_q <= 1'b0; busy_q <= 1'b0; bcnt_q <= '0;
        wmask_q <= '0; rmask_q <= '0; smask_q <= '0; sval_q <= '0;
        waddr_q <= '0; raddr_q <= '0; saddr_q <= '0;
        waddr_en_q <= 1'b0; raddr_en_q <= 1'b0; saddr_en_q <= 1'b0;
      end else begin
        fired_q   <= 1'b0;
        blocked_q <= 1'b0;
        busy_q    <= 1'b0;
        // ---- consume
        if (wr_hit) begin arm_wr_q <= 1'b0; fired_q <= 1'b1; end
        if (rd_hit) begin arm_rd_q <= 1'b0; rd_pend_q <= 1'b1; fired_q <= 1'b1; end
        if (res_fird_i) rd_pend_q <= 1'b0;
        // ---- disarm (always allowed: it can only make the system safer)
        if (clear_i) begin arm_wr_q <= 1'b0; arm_rd_q <= 1'b0; stuck_q <= 1'b0; end
        // ---- command
        if (cmd_valid_i) begin
          if (!cmd_ok) begin
            blocked_q <= 1'b1;
            if (bcnt_q != 16'hFFFF) bcnt_q <= bcnt_q + 16'd1;
          end else begin
            case (cmd_mode_i)
              `SF_ECC_FI_WRITE: begin
                if (arm_wr_q) busy_q <= 1'b1;
                else begin arm_wr_q <= 1'b1; wmask_q <= cmd_mask_i; waddr_q <= cmd_addr_i; waddr_en_q <= cmd_addr_en_i; end
              end
              `SF_ECC_FI_READ: begin
                if (arm_rd_q || rd_pend_q) busy_q <= 1'b1;
                else begin arm_rd_q <= 1'b1; rmask_q <= cmd_mask_i; raddr_q <= cmd_addr_i; raddr_en_q <= cmd_addr_en_i; end
              end
              `SF_ECC_FI_STUCK: begin
                stuck_q <= 1'b1; smask_q <= cmd_mask_i; sval_q <= cmd_val_i; saddr_q <= cmd_addr_i; saddr_en_q <= cmd_addr_en_i;
              end
              default: busy_q <= 1'b1;
            endcase
          end
        end
      end
    end

    assign armed_o       = arm_wr_q | arm_rd_q | rd_pend_q;
    assign stuck_o       = stuck_q;
    assign fired_o       = fired_q;
    assign blocked_o     = blocked_q;
    assign busy_o        = busy_q;
    assign blocked_cnt_o = bcnt_q;
  end
endmodule

`default_nettype wire
