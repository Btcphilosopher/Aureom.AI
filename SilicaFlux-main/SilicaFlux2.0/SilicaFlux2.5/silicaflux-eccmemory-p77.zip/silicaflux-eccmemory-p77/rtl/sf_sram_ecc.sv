// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_sram_ecc            PRIMARY RTL
// SECDED-protected SRAM wrapper: K data bits + R Hamming check bits + 1 overall
// parity bit per word (K=64 -> 72 stored bits) over a single-port (1RW) macro.
//
//   write :  data -> sf_secded_enc -> macro                    (whole 72-bit word)
//   read  :  macro -> sf_secded_dec -> data + status
//   partial write (byte enables): atomic read-modify-write under a bank lock
//   scrub, fault injection, RAS counters/registers, MBIST raw port, init engine
//
// ------------------------------------------------------------------ pipeline
//   accept (cycle t) --> ISSUE register --> macro (t+1) --> decode --> response FIFO
//   * every functional op is accepted at most one per cycle and loaded into the issue
//     register, which drives the macro from flops.  Encoding happens in the accept
//     cycle (request data -> sf_secded_enc -> issue register).
//   * every functional/scrub op also enters a TAG PIPELINE of LAT = RD_LAT + DEC_PIPE
//     stages that has no stall.  When an op leaves it (decode stage) its macro data
//     is decoded and its response / event is produced.  Because the tag pipeline is
//     fixed-latency and in order, RESPONSES LEAVE IN ACCEPTANCE ORDER (a write's
//     acknowledge cannot overtake an earlier read).
//   * DEC_PIPE = 1 registers the raw macro word before the decoder (shorter path,
//     +1 cycle read latency).
//
// ------------------------------------------------------------------ latency (cycles)
//   read   accept -> rsp_valid   = LAT + 2     (no response backpressure)
//   full write / no-op ack       = LAT + 2     (array written at accept+1)
//   partial write (RMW)  accept -> rsp_valid = LAT + 4;  the bank is LOCKED
//                        accept+1 .. accept+LAT+2  (next accept at accept+LAT+3)
//   throughput: 1 read or full write per cycle while RSP_DEPTH >= LAT + 2 and the
//   consumer keeps up; 1 partial write per LAT+3 cycles.
//
// ------------------------------------------------------------------ partial write (RMW)
//   1 lock the bank (accept)   2 read the old codeword   3 decode + validate
//   4 merge the enabled bytes into the CORRECTED data    5 re-encode the whole word
//   6 commit the new codeword  7 release the lock        8 response (ce = old word had a CE)
//   Policy for an UNCORRECTABLE old word: the write is ABORTED -- the stored word is
//   left exactly as found (still uncorrectable, so the fault stays visible), the
//   response has err = 1 / ue = 1 and a UE event (src = RMW) is raised.  Bytes the old
//   word would have contributed are unknown, so no merged word is ever stored.  A
//   full-word write never reads the old word and therefore repairs such a word.
//
// ------------------------------------------------------------------ errors
//   read of a word with a single-bit error : rdata corrected, rsp_ce = 1
//   read of an uncorrectable word          : rsp_err = rsp_ue = 1; rdata = the stored,
//     UNCORRECTED data bits (UE_DATA_ZERO = 0) or zero (UE_DATA_ZERO = 1).  Consumers MUST
//     gate use of rdata with rsp_err -- uncorrectable data is never presented as valid.
//   out-of-range address                   : rsp_err = 1, rsp_ue = 0, no macro access
//   Reads do NOT write corrections back (see scrub); a latent single-bit error is
//   therefore corrected, and counted, on every read until it is scrubbed or rewritten.
//
// ------------------------------------------------------------------ RAS events
//   ONE decode point -> at most one event per decoded word, raised once:
//     CE / UE from a demand read (src READ), an RMW old-word read (src RMW) or a
//     scrub CHECK (src SCRUB).  A scrub FIX re-decodes the word under the lock; its CE
//     is suppressed when its syndrome equals the one CHECK already reported (same
//     correction event).  A VERIFY read that still sees a single-bit error after a FIX
//     is a PERSIST event (hard fault), not a second CE.
//
// ------------------------------------------------------------------ maintenance
//   init engine  writes the valid all-zero word (encode(0) ^ CHK_INV) to every address
//                after reset (INIT_ON_RESET), on init_start_i, and after the MBIST raw
//                port is released (REINIT_AFTER_TEST).  req_ready = 0 meanwhile.
//   MBIST port   tst_req_i quiesces the wrapper, then tst_grant_o = 1 and the macro is
//                driven raw (N-bit words: data AND check bits are testable).
//   CHK_INV      constant XORed onto the stored check/parity bits.  The default 0x03
//                makes the all-zero and all-ones stored words UNCORRECTABLE for K=64, so a
//                dead word line, a powered-up-as-zero macro or an MBIST zero-scrub is never
//                read as valid data.  (K=32 needs 0x09; see docs/01_math_model.md.)
//   K must be a multiple of 8 (byte enables).
//
// Classification: SYNTHESIZABLE (macro supplied outside; see sf_sram_ecc_sys.sv)
// =============================================================================
`include "sf_secded_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sf_sram_ecc #(
  parameter int K                 = 64,
  parameter int DEPTH             = 256,
  parameter int RD_LAT            = 1,       // macro read latency (cycles from read cycle to rdata)
  parameter int DEC_PIPE          = 0,       // 1 = register the raw word before the decoder
  parameter int RSP_DEPTH         = 8,       // response FIFO depth (credit-based, never overflows)
  parameter int ID_W              = 4,
  parameter int CHK_INV           = 3,
  parameter int UE_DATA_ZERO      = 0,
  parameter int INIT_ON_RESET     = 1,
  parameter int REINIT_AFTER_TEST = 1,
  parameter int TEST_EN           = 1,
  parameter int SCRUB_EN          = 0,       // 1 = internal scrub engine, 0 = external scrub master on xscr_*
  parameter int SCRUB_MAX_WAIT    = 16,      // a waiting scrub request takes the next free slot after this many cycles
  parameter int FI_EN             = 0,       // 0 = fault injection removed
  // ---- derived, do not override ----
  parameter int R    = $clog2(K + $clog2(K + 1) + 1),
  parameter int N    = K + R + 1,
  parameter int IW   = $clog2(N),
  parameter int AW   = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int BE_W = K / 8,
  parameter int SYN_W = R + 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ---------------- functional port (valid/ready request, valid/ready response)
  input  wire logic              req_valid,
  output logic                   req_ready,
  input  wire logic              req_we,
  input  wire logic [AW-1:0]     req_addr,
  input  wire logic [K-1:0]      req_wdata,
  input  wire logic [BE_W-1:0]   req_be,
  input  wire logic [ID_W-1:0]   req_id,
  output logic                   rsp_valid,
  input  wire logic              rsp_ready,
  output logic [K-1:0]           rsp_rdata,
  output logic                   rsp_err,         // data invalid / write not performed
  output logic                   rsp_ue,          // ... because of an uncorrectable ECC error
  output logic                   rsp_ce,          // a single-bit error was corrected
  output logic                   rsp_we,          // response to a write
  output logic [ID_W-1:0]        rsp_id,
  // ---------------- external scrub master (SCRUB_EN = 0); tied off when SCRUB_EN = 1
  input  wire logic              xscr_req_valid,
  output logic                   xscr_req_ready,
  input  wire logic [1:0]        xscr_req_op,     // 0 CHECK, 1 FIX, 2 VERIFY
  input  wire logic [AW-1:0]     xscr_req_addr,
  input  wire logic [SYN_W-1:0]  xscr_req_syn,
  output logic                   xscr_rsp_valid,
  output logic [1:0]             xscr_rsp_op,
  output logic                   xscr_rsp_ce,
  output logic                   xscr_rsp_ue,
  output logic [SYN_W-1:0]       xscr_rsp_syn,
  output logic [AW-1:0]          xscr_rsp_addr,
  // ---------------- internal scrub engine configuration / status (SCRUB_EN = 1)
  input  wire logic              scrub_en_i,
  input  wire logic [15:0]       scrub_interval_i,
  input  wire logic              scrub_fix_en_i,
  input  wire logic              scrub_ue_halt_i,
  input  wire logic              scrub_resume_i,
  output logic                   scrub_busy_o,
  output logic                   scrub_halted_o,
  output logic                   scrub_pass_o,
  output logic [AW-1:0]          scrub_addr_o,
  output logic [AW-1:0]          scrub_ue_addr_o,
  output logic [31:0]            scrub_words_o,
  output logic [31:0]            scrub_ce_found_o,
  output logic [31:0]            scrub_ue_found_o,
  output logic [31:0]            scrub_fixed_o,
  output logic [31:0]            scrub_persistent_o,
  output logic [31:0]            scrub_passes_o,
  // ---------------- maintenance
  input  wire logic              init_start_i,
  output logic                   init_busy_o,
  output logic                   quiet_o,         // no operation in flight
  output logic                   lock_o,          // bank locked by an RMW / scrub FIX
  input  wire logic              tst_req_i,       // MBIST raw-port request
  output logic                   tst_grant_o,
  input  wire logic              tst_en_i,
  input  wire logic              tst_we_i,
  input  wire logic [AW-1:0]     tst_addr_i,
  input  wire logic [N-1:0]      tst_wdata_i,
  output logic [N-1:0]           tst_rdata_o,
  // ---------------- fault injection (only effective when FI_EN = 1)
  input  wire logic              fi_auth_i,
  input  wire logic              fi_enable_i,
  input  wire logic              fi_cmd_valid_i,
  input  wire logic [1:0]        fi_cmd_mode_i,
  input  wire logic [N-1:0]      fi_cmd_mask_i,
  input  wire logic [N-1:0]      fi_cmd_val_i,
  input  wire logic [AW-1:0]     fi_cmd_addr_i,
  input  wire logic              fi_cmd_addr_en_i,
  input  wire logic              fi_clear_i,
  output logic                   fi_armed_o,
  output logic                   fi_stuck_o,
  output logic                   fi_fired_o,
  output logic                   fi_blocked_o,
  output logic                   fi_busy_o,
  output logic [15:0]            fi_blocked_cnt_o,
  // ---------------- RAS interface
  output logic                   ev_valid_o,      // one-cycle event pulse
  output logic                   ev_ce_o,
  output logic                   ev_ue_o,
  output logic                   ev_persist_o,
  output logic [1:0]             ev_src_o,        // SF_ECC_SRC_*
  output logic [AW-1:0]          ev_addr_o,
  output logic [SYN_W-1:0]       ev_syn_o,        // {pe, s}
  output logic [IW-1:0]          ev_pos_o,        // stored-bit index corrected (CE)
  input  wire logic              ras_reg_sel_i,
  input  wire logic              ras_reg_we_i,
  input  wire logic [7:0]        ras_reg_addr_i,
  input  wire logic [31:0]       ras_reg_wdata_i,
  output logic [31:0]            ras_reg_rdata_o,
  output logic                   ras_reg_err_o,
  output logic [31:0]            ce_count_o,
  output logic [31:0]            ue_count_o,
  output logic [31:0]            persist_count_o,
  output logic [AW-1:0]          last_addr_o,
  output logic [SYN_W-1:0]       last_syn_o,
  output logic                   ce_seen_o,
  output logic                   ue_seen_o,
  output logic                   irq_warn_o,
  output logic                   irq_ue_o,
  output logic                   fatal_req_o,
  // ---------------- macro port (single-port 1RW, N-bit word, NO byte mask)
  output logic                   m_en,
  output logic                   m_we,
  output logic [AW-1:0]          m_addr,
  output logic [N-1:0]           m_wdata,
  input  wire logic [N-1:0]      m_rdata
);
  // ------------------------------------------------------------ constants
  localparam int LAT = RD_LAT + DEC_PIPE;
  localparam int DW  = 6 + ID_W + AW;                 // tag descriptor
  localparam int FW  = K + 4 + ID_W;                  // response FIFO entry {data, err, ue, ce, we, id}
  localparam int PW  = (RSP_DEPTH > 1) ? $clog2(RSP_DEPTH) : 1;
  localparam int CW  = $clog2(RSP_DEPTH + 1);

  localparam logic [2:0] OP_NOP = 3'd0, OP_RD = 3'd1, OP_WR = 3'd2, OP_RMW = 3'd3, OP_SRD = 3'd4, OP_SFIX = 3'd5;
  localparam logic [1:0] LK_IDLE = 2'd0, LK_WAIT = 2'd1, LK_WB = 2'd2;
  localparam logic [1:0] IN_IDLE = 2'd0, IN_WAIT = 2'd1, IN_RUN = 2'd2;
  localparam logic [1:0] SC_CHECK = 2'd0, SC_FIX = 2'd1, SC_VERIFY = 2'd2;

  // descriptor field offsets
  localparam int D_ADDR = 0;
  localparam int D_ID   = AW;
  localparam int D_OP   = AW + ID_W;
  localparam int D_BAD  = AW + ID_W + 3;
  localparam int D_VER  = AW + ID_W + 4;
  localparam int D_FIRD = AW + ID_W + 5;

  if (K % 8 != 0) begin : g_err_k
    `SF_ECC_CFG_FATAL("sf_sram_ecc: K must be a multiple of 8 (byte enables)")
  end
  if (RD_LAT < 1 || DEC_PIPE < 0 || DEC_PIPE > 1) begin : g_err_lat
    `SF_ECC_CFG_FATAL("sf_sram_ecc: RD_LAT must be >= 1 and DEC_PIPE 0 or 1")
  end
  if (RSP_DEPTH < 2) begin : g_err_depth
    `SF_ECC_CFG_FATAL("sf_sram_ecc: RSP_DEPTH must be >= 2")
  end

  // ------------------------------------------------------------ state
  logic [1:0]      lk_st_q;
  logic [AW-1:0]   lk_addr_q;
  logic [K-1:0]    lk_wdata_q;
  logic [BE_W-1:0] lk_be_q;
  logic [ID_W-1:0] lk_id_q;
  logic            lk_isfix_q, lk_ce_q;
  logic [SYN_W-1:0] lk_expsyn_q;
  logic [K-1:0]    rmw_data_q;
  logic            done_push_q;

  logic [1:0]      init_st_q;
  logic [AW-1:0]   init_addr_q;
  logic            tst_grant_q, tst_rel_q;

  logic            iss_v_q, iss_acc_q, iss_we_q, iss_enter_q;
  logic [AW-1:0]   iss_addr_q;
  logic [N-1:0]    iss_cw_q;
  logic [DW-1:0]   iss_desc_q;

  logic [LAT-1:0]  tp_v_q;
  logic [DW-1:0]   tp_d_q [0:LAT-1];
  logic [N-1:0]    raw_q;

  logic [FW-1:0]   fifo_q [0:RSP_DEPTH-1];
  logic [PW-1:0]   wp_q, rp_q;
  logic [CW-1:0]   cnt_q, used_q;

  logic [15:0]     scr_wait_q;

  logic            ev_v_q, ev_ce_q, ev_ue_q, ev_per_q;
  logic [1:0]      ev_src_q;
  logic [AW-1:0]   ev_addr_q;
  logic [SYN_W-1:0] ev_syn_q;
  logic [IW-1:0]   ev_pos_q;

  logic            srsp_v_q, srsp_ce_q, srsp_ue_q;
  logic [1:0]      srsp_op_q;
  logic [SYN_W-1:0] srsp_syn_q;
  logic [AW-1:0]   srsp_addr_q;

  // scrub request presented to the wrapper (internal engine or external master); declared here, driven further down
  logic              scr_v;
  logic [1:0]        scr_op;
  logic [AW-1:0]     scr_a;
  logic [SYN_W-1:0]  scr_syn;

  // ------------------------------------------------------------ gating
  wire lock       = (lk_st_q != LK_IDLE);
  wire init_run   = (init_st_q == IN_RUN);
  wire tst_blk    = (TEST_EN != 0) && (tst_req_i || tst_grant_q);
  wire quiet_blk  = (init_st_q != IN_IDLE) || tst_blk || tst_rel_q;   // tst_rel_q: bridges the cycle between port release and init start
  wire can_s      = !lock && !quiet_blk;
  wire credit_ok  = (used_q < CW'(RSP_DEPTH));
  // starvation guard: a scrub request that has waited SCRUB_MAX_WAIT cycles takes the next free slot.
  // Only while a request is actually pending (SCRUB_MAX_WAIT = 0 would otherwise block the functional port forever).
  wire scr_force  = scr_v && (scr_wait_q >= 16'(SCRUB_MAX_WAIT));
  wire pipe_idle  = !iss_v_q && (tp_v_q == '0) && !lock && !done_push_q;

  assign req_ready = can_s && credit_ok && !scr_force;
  wire acc_f = req_valid && req_ready;

  // ------------------------------------------------------------ scrub request mux (engine or external master)
  wire               acc_s   = scr_v && can_s && !acc_f;
  wire               scr_rdy = can_s && !acc_f;

  if (SCRUB_EN != 0) begin : g_scrub
    sf_sram_ecc_scrub #(.DEPTH(DEPTH), .AW(AW), .SYN_W(SYN_W), .CNT_W(32)) u_scrub (
      .clk(clk), .rst_n(rst_n),
      .en_i(scrub_en_i), .interval_i(scrub_interval_i), .fix_en_i(scrub_fix_en_i),
      .ue_halt_i(scrub_ue_halt_i), .resume_i(scrub_resume_i),
      .req_valid_o(scr_v), .req_ready_i(scr_rdy), .req_op_o(scr_op), .req_addr_o(scr_a), .req_syn_o(scr_syn),
      .rsp_valid_i(srsp_v_q), .rsp_ce_i(srsp_ce_q), .rsp_ue_i(srsp_ue_q), .rsp_syn_i(srsp_syn_q),
      .busy_o(scrub_busy_o), .halted_o(scrub_halted_o), .addr_o(scrub_addr_o), .pass_o(scrub_pass_o),
      .ue_addr_o(scrub_ue_addr_o), .words_o(scrub_words_o), .ce_found_o(scrub_ce_found_o),
      .ue_found_o(scrub_ue_found_o), .fixed_o(scrub_fixed_o), .persistent_o(scrub_persistent_o),
      .passes_o(scrub_passes_o));
    assign xscr_req_ready = 1'b0;
  end else begin : g_xscrub
    assign scr_v   = xscr_req_valid;
    assign scr_op  = xscr_req_op;
    assign scr_a   = xscr_req_addr;
    assign scr_syn = xscr_req_syn;
    assign xscr_req_ready = scr_rdy;
    assign scrub_busy_o = 1'b0; assign scrub_halted_o = 1'b0; assign scrub_pass_o = 1'b0;
    assign scrub_addr_o = '0; assign scrub_ue_addr_o = '0; assign scrub_words_o = '0;
    assign scrub_ce_found_o = '0; assign scrub_ue_found_o = '0; assign scrub_fixed_o = '0;
    assign scrub_persistent_o = '0; assign scrub_passes_o = '0;
  end
  assign xscr_rsp_valid = (SCRUB_EN != 0) ? 1'b0 : srsp_v_q;
  assign xscr_rsp_op    = srsp_op_q;
  assign xscr_rsp_ce    = srsp_ce_q;
  assign xscr_rsp_ue    = srsp_ue_q;
  assign xscr_rsp_syn   = srsp_syn_q;
  assign xscr_rsp_addr  = srsp_addr_q;

  // ------------------------------------------------------------ functional op decode
  wire f_full = &req_be;
  wire f_zero = ~|req_be;
  wire f_inr  = ({1'b0, req_addr} < (AW+1)'(DEPTH));
  logic [2:0] f_op;
  always_comb begin
    if (!req_we)      f_op = OP_RD;
    else if (f_zero)  f_op = OP_NOP;
    else if (f_full)  f_op = OP_WR;
    else              f_op = OP_RMW;
  end
  wire f_bad = !f_inr;

  wire lk_start = (acc_f && (f_op == OP_RMW) && f_inr) || (acc_s && (scr_op == SC_FIX));

  // ------------------------------------------------------------ encoders
  wire [N-1:0] enc_fw, enc_wb, enc_zero;
  sf_secded_enc #(.K(K), .INV(CHK_INV)) u_enc_fw   (.data_i(req_wdata),  .cw_o(enc_fw));
  sf_secded_enc #(.K(K), .INV(CHK_INV)) u_enc_wb   (.data_i(rmw_data_q), .cw_o(enc_wb));
  sf_secded_enc #(.K(K), .INV(CHK_INV)) u_enc_zero (.data_i('0),         .cw_o(enc_zero));

  // ------------------------------------------------------------ issue-register load
  logic            ld_v, ld_acc, ld_we, ld_enter, ld_is_init;
  logic [AW-1:0]   ld_addr;
  logic [N-1:0]    ld_cw_base;
  logic [DW-1:0]   ld_desc_base;

  always_comb begin
    ld_v = 1'b0; ld_acc = 1'b0; ld_we = 1'b0; ld_enter = 1'b0; ld_is_init = 1'b0;
    ld_addr = '0; ld_cw_base = '0; ld_desc_base = '0;
    if (init_run) begin
      ld_v = 1'b1; ld_acc = 1'b1; ld_we = 1'b1; ld_is_init = 1'b1;
      ld_addr = init_addr_q; ld_cw_base = enc_zero;
    end else if (lk_st_q == LK_WB) begin
      ld_v = 1'b1; ld_acc = 1'b1; ld_we = 1'b1;
      ld_addr = lk_addr_q; ld_cw_base = enc_wb;
    end else if (acc_f) begin
      ld_v = 1'b1; ld_enter = 1'b1; ld_addr = req_addr;
      ld_desc_base[D_ADDR +: AW]   = req_addr;
      ld_desc_base[D_ID   +: ID_W] = req_id;
      ld_desc_base[D_OP   +: 3]    = f_op;
      ld_desc_base[D_BAD]          = f_bad;
      case (f_op)
        OP_RD:  begin ld_acc = f_inr; ld_we = 1'b0; end
        OP_WR:  begin ld_acc = f_inr; ld_we = 1'b1; ld_cw_base = enc_fw; end
        OP_RMW: begin ld_acc = f_inr; ld_we = 1'b0; end              // read first
        default: begin ld_acc = 1'b0; end                            // NOP: acknowledged, no access
      endcase
    end else if (acc_s) begin
      ld_v = 1'b1; ld_enter = 1'b1; ld_acc = 1'b1; ld_we = 1'b0; ld_addr = scr_a;
      ld_desc_base[D_ADDR +: AW] = scr_a;
      ld_desc_base[D_OP   +: 3]  = (scr_op == SC_FIX) ? OP_SFIX : OP_SRD;
      ld_desc_base[D_VER]        = (scr_op == SC_VERIFY);
    end
  end

  // ------------------------------------------------------------ fault injection
  wire              ld_rd = ld_v & ld_acc & ~ld_we & ld_enter;
  wire              ld_wr = ld_v & ld_acc &  ld_we & ~ld_is_init;
  wire              fi_take_rd;
  wire [N-1:0]      fi_wr_mask;
  logic [N-1:0]     raw_dec;                 // raw word after read-path injection (decoder input)
  logic [N-1:0]     raw_sel;
  logic             res_fird;
  logic [AW-1:0]    res_addr;
  logic             res_v;

  sf_sram_ecc_fi #(.N(N), .AW(AW), .FI_EN(FI_EN)) u_fi (
    .clk(clk), .rst_n(rst_n), .auth_i(fi_auth_i), .enable_i(fi_enable_i),
    .cmd_valid_i(fi_cmd_valid_i), .cmd_mode_i(fi_cmd_mode_i), .cmd_mask_i(fi_cmd_mask_i), .cmd_val_i(fi_cmd_val_i),
    .cmd_addr_i(fi_cmd_addr_i), .cmd_addr_en_i(fi_cmd_addr_en_i), .clear_i(fi_clear_i),
    .ld_rd_i(ld_rd), .ld_rd_addr_i(ld_addr), .ld_wr_i(ld_wr), .ld_wr_addr_i(ld_addr),
    .take_rd_o(fi_take_rd), .wr_mask_o(fi_wr_mask),
    .res_fird_i(res_v & res_fird), .res_addr_i(res_addr), .raw_i(raw_sel), .raw_o(raw_dec),
    .armed_o(fi_armed_o), .stuck_o(fi_stuck_o), .fired_o(fi_fired_o), .blocked_o(fi_blocked_o),
    .busy_o(fi_busy_o), .blocked_cnt_o(fi_blocked_cnt_o));

  wire [N-1:0]  ld_cw   = ld_cw_base ^ fi_wr_mask;
  logic [DW-1:0] ld_desc;
  always_comb begin
    ld_desc = ld_desc_base;
    ld_desc[D_FIRD] = fi_take_rd;
  end

  // ------------------------------------------------------------ issue register, tag pipeline
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      iss_v_q <= 1'b0; iss_acc_q <= 1'b0; iss_we_q <= 1'b0; iss_enter_q <= 1'b0;
      tp_v_q <= '0;
    end else begin
      iss_v_q <= ld_v; iss_acc_q <= ld_acc; iss_we_q <= ld_we; iss_enter_q <= ld_enter;
      tp_v_q[0] <= iss_v_q & iss_enter_q;
      for (int i = 1; i < LAT; i++) tp_v_q[i] <= tp_v_q[i-1];
    end
  end
  always_ff @(posedge clk) begin
    iss_addr_q <= ld_addr; iss_cw_q <= ld_cw; iss_desc_q <= ld_desc;
    tp_d_q[0] <= iss_desc_q;
    for (int i = 1; i < LAT; i++) tp_d_q[i] <= tp_d_q[i-1];
    raw_q <= m_rdata;
  end

  // ------------------------------------------------------------ macro port
  assign tst_grant_o = tst_grant_q;
  assign m_en    = tst_grant_q ? tst_en_i    : (iss_v_q & iss_acc_q);
  assign m_we    = tst_grant_q ? tst_we_i    : iss_we_q;
  assign m_addr  = tst_grant_q ? tst_addr_i  : iss_addr_q;
  assign m_wdata = tst_grant_q ? tst_wdata_i : iss_cw_q;
  assign tst_rdata_o = m_rdata;

  // ------------------------------------------------------------ decode stage
  assign raw_sel = (DEC_PIPE != 0) ? raw_q : m_rdata;

  assign res_v    = tp_v_q[LAT-1];
  wire [DW-1:0] res_d = tp_d_q[LAT-1];
  assign res_addr = res_d[D_ADDR +: AW];
  wire [ID_W-1:0] res_id = res_d[D_ID +: ID_W];
  wire [2:0] res_op   = res_d[D_OP +: 3];
  wire       res_bad  = res_d[D_BAD];
  wire       res_ver  = res_d[D_VER];
  assign res_fird = res_d[D_FIRD];

  wire [K-1:0]  dec_data;
  wire [N-1:0]  dec_cwc;
  wire          dec_none, dec_ce, dec_ue, dec_uei;
  wire [1:0]    dec_kind;
  wire [IW-1:0] dec_pos;
  wire [R:0]    dec_syn;
  sf_secded_dec #(.K(K), .INV(CHK_INV)) u_dec (
    .cw_i(raw_dec), .data_o(dec_data), .cw_corr_o(dec_cwc), .none_o(dec_none), .ce_o(dec_ce),
    .ue_o(dec_ue), .ue_inval_o(dec_uei), .err_kind_o(dec_kind), .err_pos_o(dec_pos), .syn_o(dec_syn));

  // merge for partial writes (bytes enabled -> new data, others -> corrected old data)
  logic [K-1:0] bmask;
  always_comb for (int i = 0; i < BE_W; i++) bmask[8*i +: 8] = {8{lk_be_q[i]}};
  wire [K-1:0] merged = (dec_data & ~bmask) | (lk_wdata_q & bmask);

  wire res_rmw_or_fix = res_v && ((res_op == OP_RMW) || (res_op == OP_SFIX)) && !res_bad;
  wire wb_needed = (res_op == OP_RMW) ? !dec_ue : dec_ce;

  // ------------------------------------------------------------ response push
  logic          push_v;
  logic [FW-1:0] push_d;
  wire [K-1:0]   rd_data = (dec_ue && (UE_DATA_ZERO != 0)) ? '0 : dec_data;
  always_comb begin
    push_v = 1'b0;
    push_d = '0;
    if (res_v) begin
      case (res_op)
        OP_RD: begin
          push_v = 1'b1;
          if (res_bad) push_d = {{K{1'b0}}, 1'b1, 1'b0, 1'b0, 1'b0, res_id};
          else         push_d = {rd_data, dec_ue, dec_ue, dec_ce, 1'b0, res_id};
        end
        OP_WR, OP_NOP: begin
          push_v = 1'b1;
          push_d = {{K{1'b0}}, res_bad, 1'b0, 1'b0, 1'b1, res_id};
        end
        OP_RMW: begin
          if (res_bad)     begin push_v = 1'b1; push_d = {{K{1'b0}}, 1'b1, 1'b0, 1'b0, 1'b1, res_id}; end
          else if (dec_ue) begin push_v = 1'b1; push_d = {{K{1'b0}}, 1'b1, 1'b1, 1'b0, 1'b1, res_id}; end   // ABORT policy
        end
        default: ;
      endcase
    end else if (done_push_q) begin
      push_v = 1'b1;
      push_d = {{K{1'b0}}, 1'b0, 1'b0, lk_ce_q, 1'b1, lk_id_q};
    end
  end

  // ------------------------------------------------------------ response FIFO (credit based)
  wire pop = rsp_valid && rsp_ready;
  assign rsp_valid = (cnt_q != '0);
  wire [FW-1:0] head = fifo_q[rp_q];
  assign {rsp_rdata, rsp_err, rsp_ue, rsp_ce, rsp_we, rsp_id} = head;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      wp_q <= '0; rp_q <= '0; cnt_q <= '0; used_q <= '0;
    end else begin
      if (push_v) begin
        fifo_q[wp_q] <= push_d;
        wp_q <= (wp_q == PW'(RSP_DEPTH - 1)) ? '0 : wp_q + (PW)'(1);
      end
      if (pop) rp_q <= (rp_q == PW'(RSP_DEPTH - 1)) ? '0 : rp_q + (PW)'(1);
      cnt_q  <= cnt_q  + (CW)'(push_v) - (CW)'(pop);
      used_q <= used_q + (CW)'(acc_f)  - (CW)'(pop);
    end
  end

  // ------------------------------------------------------------ RMW / scrub-FIX lock FSM
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      lk_st_q <= LK_IDLE; done_push_q <= 1'b0;
      lk_addr_q <= '0; lk_wdata_q <= '0; lk_be_q <= '0; lk_id_q <= '0; lk_isfix_q <= 1'b0; lk_ce_q <= 1'b0;
      lk_expsyn_q <= '0; rmw_data_q <= '0;
    end else begin
      done_push_q <= 1'b0;
      case (lk_st_q)
        LK_IDLE: if (lk_start) begin
          lk_st_q     <= LK_WAIT;
          lk_addr_q   <= acc_f ? req_addr  : scr_a;
          lk_wdata_q  <= acc_f ? req_wdata : '0;
          lk_be_q     <= acc_f ? req_be    : '0;
          lk_id_q     <= acc_f ? req_id    : '0;
          lk_isfix_q  <= !acc_f;
          lk_expsyn_q <= scr_syn;
        end
        LK_WAIT: if (res_rmw_or_fix) begin
          if (wb_needed) begin
            lk_st_q    <= LK_WB;
            rmw_data_q <= merged;
            lk_ce_q    <= dec_ce;
          end else lk_st_q <= LK_IDLE;                 // abort (UE) or nothing to repair
        end
        LK_WB: begin
          lk_st_q     <= LK_IDLE;
          done_push_q <= !lk_isfix_q;                  // RMW completion response; a FIX has none
        end
        default: lk_st_q <= LK_IDLE;
      endcase
    end
  end

  // ------------------------------------------------------------ init engine / MBIST raw port
  wire init_go = init_start_i || tst_rel_q;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      init_st_q   <= (INIT_ON_RESET != 0) ? IN_WAIT : IN_IDLE;
      init_addr_q <= '0;
    end else begin
      case (init_st_q)
        IN_IDLE: begin init_addr_q <= '0; if (init_go) init_st_q <= IN_WAIT; end
        IN_WAIT: if (pipe_idle && !tst_grant_q) init_st_q <= IN_RUN;
        IN_RUN: begin
          init_addr_q <= init_addr_q + (AW)'(1);
          if (init_addr_q == AW'(DEPTH - 1)) init_st_q <= IN_IDLE;
        end
        default: init_st_q <= IN_IDLE;
      endcase
    end
  end
  assign init_busy_o = (init_st_q != IN_IDLE);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      tst_grant_q <= 1'b0; tst_rel_q <= 1'b0;
    end else begin
      tst_rel_q <= 1'b0;
      if (TEST_EN != 0) begin
        if (!tst_grant_q) begin
          if (tst_req_i && pipe_idle && (init_st_q == IN_IDLE)) tst_grant_q <= 1'b1;
        end else if (!tst_req_i) begin
          tst_grant_q <= 1'b0;
          tst_rel_q   <= (REINIT_AFTER_TEST != 0);
        end
      end
    end
  end

  assign quiet_o = pipe_idle && (init_st_q == IN_IDLE);
  assign lock_o  = lock;

  // ------------------------------------------------------------ scrub-port arbitration starvation guard
  always_ff @(posedge clk) begin
    if (!rst_n) scr_wait_q <= '0;
    else if (acc_s || !scr_v) scr_wait_q <= '0;
    else if (scr_wait_q != 16'hFFFF) scr_wait_q <= scr_wait_q + 16'd1;
  end

  // ------------------------------------------------------------ events and scrub results (ONE decode point)
  wire res_real  = res_v && !res_bad && ((res_op == OP_RD) || (res_op == OP_RMW) || (res_op == OP_SRD) || (res_op == OP_SFIX));
  wire is_scrub  = (res_op == OP_SRD) || (res_op == OP_SFIX);
  wire sfix_dup  = (res_op == OP_SFIX) && (dec_syn == lk_expsyn_q);     // same correction event as CHECK
  wire ver_ce    = (res_op == OP_SRD) && res_ver && dec_ce;
  wire ev_ce_n   = res_real && dec_ce && !ver_ce && !sfix_dup;
  wire ev_per_n  = res_real && ver_ce;
  wire ev_ue_n   = res_real && dec_ue;
  wire [1:0] ev_src_n = is_scrub ? `SF_ECC_SRC_SCRUB : ((res_op == OP_RMW) ? `SF_ECC_SRC_RMW : `SF_ECC_SRC_READ);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      ev_v_q <= 1'b0; ev_ce_q <= 1'b0; ev_ue_q <= 1'b0; ev_per_q <= 1'b0;
      ev_src_q <= '0; ev_addr_q <= '0; ev_syn_q <= '0; ev_pos_q <= '0;
      srsp_v_q <= 1'b0; srsp_ce_q <= 1'b0; srsp_ue_q <= 1'b0; srsp_op_q <= '0; srsp_syn_q <= '0; srsp_addr_q <= '0;
    end else begin
      ev_v_q    <= ev_ce_n | ev_per_n | ev_ue_n;
      ev_ce_q   <= ev_ce_n;
      ev_ue_q   <= ev_ue_n;
      ev_per_q  <= ev_per_n;
      ev_src_q  <= ev_src_n;
      ev_addr_q <= res_addr;
      ev_syn_q  <= dec_syn;
      ev_pos_q  <= dec_pos;
      srsp_v_q    <= res_real && is_scrub;
      srsp_ce_q   <= dec_ce;
      srsp_ue_q   <= dec_ue;
      srsp_op_q   <= (res_op == OP_SFIX) ? SC_FIX : (res_ver ? SC_VERIFY : SC_CHECK);
      srsp_syn_q  <= dec_syn;
      srsp_addr_q <= res_addr;
    end
  end
  assign ev_valid_o   = ev_v_q;
  assign ev_ce_o      = ev_ce_q;
  assign ev_ue_o      = ev_ue_q;
  assign ev_persist_o = ev_per_q;
  assign ev_src_o     = ev_src_q;
  assign ev_addr_o    = ev_addr_q;
  assign ev_syn_o     = ev_syn_q;
  assign ev_pos_o     = ev_pos_q;

  // ------------------------------------------------------------ RAS block
  wire [31:0] ras_ce, ras_ue, ras_per;
  sf_sram_ecc_ras #(.K(K), .N(N), .AW(AW), .SYN_W(SYN_W), .POS_W(IW), .SCRUB_EN(SCRUB_EN), .FI_EN(FI_EN), .CNT_W(32)) u_ras (
    .clk(clk), .rst_n(rst_n),
    .ev_valid_i(ev_v_q), .ev_ce_i(ev_ce_q), .ev_ue_i(ev_ue_q), .ev_persist_i(ev_per_q),
    .ev_src_i(ev_src_q), .ev_addr_i(ev_addr_q), .ev_syn_i(ev_syn_q), .ev_pos_i(ev_pos_q),
    .reg_sel_i(ras_reg_sel_i), .reg_we_i(ras_reg_we_i), .reg_addr_i(ras_reg_addr_i), .reg_wdata_i(ras_reg_wdata_i),
    .reg_rdata_o(ras_reg_rdata_o), .reg_err_o(ras_reg_err_o),
    .ce_count_o(ras_ce), .ue_count_o(ras_ue), .persist_count_o(ras_per),
    .last_addr_o(last_addr_o), .last_syn_o(last_syn_o), .ce_seen_o(ce_seen_o), .ue_seen_o(ue_seen_o),
    .irq_warn_o(irq_warn_o), .irq_ue_o(irq_ue_o), .fatal_req_o(fatal_req_o));
  assign ce_count_o      = ras_ce;
  assign ue_count_o      = ras_ue;
  assign persist_count_o = ras_per;

`ifdef SF_ECC_ASSERT
  // ------------------------------------------------------------ run-time assertions (Verilator --assert and Yosys formal)
  // explicit arithmetic instead of $countones/$onehot (Icarus 12 miscounts concatenations)
  wire [1:0] ev_kinds = (ev_ce_q ? 2'd1 : 2'd0) + (ev_ue_q ? 2'd1 : 2'd0) + (ev_per_q ? 2'd1 : 2'd0);
  always @(posedge clk) if (rst_n) begin
    `SF_ASSERT(!(push_v && cnt_q == CW'(RSP_DEPTH) && !pop), "response FIFO overflow")
    `SF_ASSERT(used_q <= CW'(RSP_DEPTH), "credit counter above RSP_DEPTH")
    `SF_ASSERT(cnt_q <= used_q, "FIFO holds more entries than credits issued")
    `SF_ASSERT(!(res_v && done_push_q), "two response pushes in one cycle")
    `SF_ASSERT(!(lock && (acc_f || acc_s)), "an access was accepted while the bank is locked")
    // RMW / scrub-FIX ATOMICITY: while the bank is locked nothing but the write-back itself may load the issue stage
    `SF_ASSERT(!(lock && ld_v && !(lk_st_q == LK_WB && !ld_enter)), "issue stage loaded by something other than the write-back during a lock")
    `SF_ASSERT(!(lk_st_q == LK_WB && (acc_f || acc_s || init_run)), "write-back slot contested")
    `SF_ASSERT(!(init_run && (lk_st_q != LK_IDLE)), "init engine running while the bank is locked")
    `SF_ASSERT(!(init_run && (acc_f || acc_s)), "access accepted during init")
    `SF_ASSERT(!(tst_grant_q && (iss_v_q || (tp_v_q != '0))), "MBIST grant while operations in flight")
    `SF_ASSERT(!(tst_grant_q && (acc_f || acc_s)), "access accepted while the MBIST port is granted")
    `SF_ASSERT(!(ev_ce_n && ev_ue_n), "CE and UE in one event")
    `SF_ASSERT(ev_kinds <= 2'd1, "event kind not one-hot")
    `SF_ASSERT(!(rsp_valid && rsp_ue && !rsp_err), "rsp_ue without rsp_err")
    `SF_ASSERT(!(rsp_valid && rsp_ce && rsp_err), "corrected data flagged as an error")
  end
`endif
endmodule

`default_nettype wire
