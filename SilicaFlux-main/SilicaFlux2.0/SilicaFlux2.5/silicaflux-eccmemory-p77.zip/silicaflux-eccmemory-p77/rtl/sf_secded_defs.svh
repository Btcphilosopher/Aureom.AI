// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_secded_defs.svh
// Shared constants and the elaboration-time fatal macro.
// =============================================================================
`ifndef SF_SECDED_DEFS_SVH
`define SF_SECDED_DEFS_SVH

// ---- decoder verdict encoding used on the wrapper's status fields ----------
`define SF_ECC_NONE      2'd0
`define SF_ECC_CE        2'd1
`define SF_ECC_UE        2'd2

// ---- kind of the corrected bit (decoder err_kind_o) ------------------------
`define SF_ECC_KIND_DATA   2'd0      // a data bit was flipped back
`define SF_ECC_KIND_CHECK  2'd1      // a Hamming check bit was flipped back
`define SF_ECC_KIND_PAR    2'd2      // the overall-parity bit was flipped back

// ---- who caused a RAS event (ras ev_src) -----------------------------------
`define SF_ECC_SRC_READ    2'd0      // demand read
`define SF_ECC_SRC_RMW     2'd1      // old-word read of a partial write
`define SF_ECC_SRC_SCRUB   2'd2      // background scrub read / fix

// ---- fault-injection modes (sf_sram_ecc_fi) --------------------------------
`define SF_ECC_FI_WRITE    2'd0      // XOR mask into the stored word of the next matching write   (latent, persistent in array)
`define SF_ECC_FI_READ     2'd1      // XOR mask into the raw word of the next matching read       (transient, array untouched)
`define SF_ECC_FI_STUCK    2'd2      // stuck-at mask/value applied to every read of the address   (hard fault: survives write-back)

// ---- assertion macro: a plain `assert (c)` under formal, `assert (c) else $error(m)` in simulation
`ifdef FORMAL
  `define SF_ASSERT(c, m) assert (c);
`else
  `define SF_ASSERT(c, m) assert (c) else $error(m);
`endif

// ---- configuration errors ---------------------------------------------------
`ifdef __ICARUS__
  `define SF_ECC_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SF_ECC_CFG_FATAL(msg) $fatal(1, msg);
`endif

`endif // SF_SECDED_DEFS_SVH
