// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_sram_ecc_ram
// Behavioural single-port (1RW) synchronous SRAM, N bits wide, used under the
// ECC wrapper in simulation / formal.  Same port contract the wrapper assumes of
// any real macro (silicaflux-sramlib sram_backend_1rw with MASK_WIDTH = 1, or an
// ASIC macro with a registered output):
//   * one operation per cycle: en & we  -> write at the clock edge,
//                              en & ~we -> read, data on `rdata` RD_LAT cycles later
//   * NO byte/bit write mask: a stored word is always replaced as a whole
//   * `rdata` is only meaningful RD_LAT cycles after a read
// Simulation backdoor: testbenches read and write `mem[]` hierarchically (latent soft errors, raw-word checks).
// Classification: SIMULATION MODEL (the wrapper is what is synthesizable)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_sram_ecc_ram #(
  parameter int N        = 72,
  parameter int DEPTH    = 256,
  parameter int RD_LAT   = 1,
  parameter int INIT_ZERO = 1,            // simulation: array powers up all-zero
  parameter int AW       = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic          clk,
  input  wire logic          en,
  input  wire logic          we,
  input  wire logic [AW-1:0] addr,
  input  wire logic [N-1:0]  wdata,
  output logic      [N-1:0]  rdata
);
  logic [N-1:0] mem [0:DEPTH-1];
  logic [N-1:0] rd_pipe [0:RD_LAT-1];

`ifndef SYNTHESIS
`ifndef FORMAL
  initial begin
    if (INIT_ZERO != 0) for (int i = 0; i < DEPTH; i++) mem[i] = '0;
  end
`endif
`endif

  always_ff @(posedge clk) begin
    if (en && we)  mem[addr] <= wdata;
    if (en && !we) rd_pipe[0] <= mem[addr];
    for (int i = 1; i < RD_LAT; i++) rd_pipe[i] <= rd_pipe[i-1];
  end
  assign rdata = rd_pipe[RD_LAT-1];

endmodule

`default_nettype wire
