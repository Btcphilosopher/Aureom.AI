// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_secded_enc_pipe
// Pipelined variant of sf_secded_enc.  Same code, same bit layout, same INV.
//
//   STAGES = 0   purely combinational (identical to sf_secded_enc)
//   STAGES = 1   one register stage at the output           latency 1 cycle
//   STAGES = 2   the XOR trees are cut in the middle        latency 2 cycles
//                stage 1 registers: data, per-byte-lane partial parities
//                  partial[j][lane] = ^(data_lane & mask_j_lane)   (R x LANES)
//                  lanep[lane]      = ^data_lane ^ (^_j partial[j][lane])
//                stage 2: chk[j] = ^_lane partial[j][lane],  p = ^_lane lanep[lane]
//                (p = ^data ^ ^chk  rearranged so no stage needs the full tree)
//
// Flow control: a one-bit valid travels with the data; `en_i` is a global
// pipeline-advance enable (0 = every stage holds, i.e. stall).  With en_i = 1
// the pipeline accepts one word per cycle.  vld_o/cw_o are valid STAGES cycles
// after vld_i/data_i with en_i held high.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_secded_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sf_secded_enc_pipe #(
  parameter int K      = 64,
  parameter int INV    = 0,
  parameter int STAGES = 2,                                 // 0, 1 or 2
  // ---- derived, do not override ----
  parameter int R      = $clog2(K + $clog2(K + 1) + 1),
  parameter int N      = K + R + 1
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         en_i,          // pipeline advance (1 = advance, 0 = stall)
  input  wire logic         vld_i,
  input  wire logic [K-1:0] data_i,
  output logic              vld_o,
  output logic      [N-1:0] cw_o
);
  `include "sf_secded_funcs.svh"

  if (STAGES < 0 || STAGES > 2) begin : g_err_stages
    `SF_ECC_CFG_FATAL("sf_secded_enc_pipe: STAGES must be 0, 1 or 2")
  end
  if (R != sf_secded_r(K) || N != K + sf_secded_r(K) + 1) begin : g_err_derived
    `SF_ECC_CFG_FATAL("sf_secded_enc_pipe: R and N are derived parameters, do not override")
  end

  localparam logic [R:0] INV_V = (R+1)'(INV);
  localparam int LANES = (K + 7) / 8;

  if (STAGES == 0) begin : g_comb
    wire [N-1:0] cw_c;
    sf_secded_enc #(.K(K), .INV(INV)) u_enc (.data_i(data_i), .cw_o(cw_c));
    assign cw_o  = cw_c;
    assign vld_o = vld_i;
  end else if (STAGES == 1) begin : g_one
    wire [N-1:0] cw_c;
    sf_secded_enc #(.K(K), .INV(INV)) u_enc (.data_i(data_i), .cw_o(cw_c));
    always_ff @(posedge clk) begin
      if (!rst_n)    vld_o <= 1'b0;
      else if (en_i) vld_o <= vld_i;
    end
    always_ff @(posedge clk) begin
      if (en_i) cw_o <= cw_c;
    end
  end else begin : g_two
    // ---- stage 1: per-lane partial parities
    logic [LANES*R-1:0] part_c;       // lane l occupies part_c[l*R +: R], bit j = check j
    logic [LANES-1:0]   lanep_c;
    for (genvar l = 0; l < LANES; l++) begin : g_lane
      localparam int LO = l * 8;
      localparam int W  = (K - LO) < 8 ? (K - LO) : 8;
      wire [W-1:0] dl = data_i[LO +: W];
      logic [R-1:0] pj;
      for (genvar j = 0; j < R; j++) begin : g_j
        localparam logic [K-1:0] CM = sf_secded_cmask(j);
        assign pj[j] = ^(dl & CM[LO +: W]);
      end
      assign part_c[l*R +: R] = pj;
      assign lanep_c[l] = (^dl) ^ (^pj);
    end
    logic [K-1:0]     d_q;
    logic [LANES*R-1:0] part_q;
    logic [LANES-1:0]   lanep_q;
    logic               v_q;
    always_ff @(posedge clk) begin
      if (!rst_n)    v_q <= 1'b0;
      else if (en_i) v_q <= vld_i;
    end
    always_ff @(posedge clk) begin
      if (en_i) begin
        d_q     <= data_i;
        part_q  <= part_c;
        lanep_q <= lanep_c;
      end
    end
    // ---- stage 2: combine the lanes
    logic [R-1:0] chk2;
    always_comb begin
      chk2 = '0;
      for (int l = 0; l < LANES; l++) chk2 = chk2 ^ part_q[l*R +: R];
    end
    wire par2 = ^lanep_q;
    wire [N-1:0] cw2 = {par2 ^ INV_V[R], chk2 ^ INV_V[R-1:0], d_q};
    always_ff @(posedge clk) begin
      if (!rst_n)    vld_o <= 1'b0;
      else if (en_i) vld_o <= v_q;
    end
    always_ff @(posedge clk) begin
      if (en_i) cw_o <= cw2;
    end
  end

endmodule

`default_nettype wire
