// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_sram_ecc_scrub
// Optional background scrub controller for sf_sram_ecc.
//
// Walks the address space, one word per iteration:
//   1. CHECK    plain read + decode (no lock)
//   2. if the word had a single-bit error and fix_en_i:
//      FIX      an ATOMIC locked read-decode-write-back performed by the wrapper
//               (the word is re-read under the lock, so a functional write that
//               slipped in after CHECK is never overwritten with stale data)
//   3. VERIFY   plain read after the FIX; if the word STILL decodes as a single-bit
//               error the fault is persistent (hard): counted as `persistent`,
//               reported to the RAS block as PERSIST, NOT as another corrected error
//   4. next address (wraps; passes++)
// An uncorrectable word is never written: it is counted and recorded; with
// ue_halt_i the engine stops at it (halted_o) until resume_i skips it.
//
// Arbitration with normal traffic is done by the wrapper (functional requests win,
// a scrub request that has waited SCRUB_MAX_WAIT cycles takes the next free slot,
// and it can never pre-empt an access already in flight).  This block only presents
// a request and waits for the result, one outstanding request at a time.
//
// `en_i` is sampled only between words: dropping it never abandons a locked FIX.
// interval_i = idle cycles between words (0 = back to back).
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_sram_ecc_scrub #(
  parameter int DEPTH  = 256,
  parameter int AW     = 8,
  parameter int SYN_W  = 8,
  parameter int CNT_W  = 32
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // configuration
  input  wire logic             en_i,
  input  wire logic [15:0]      interval_i,
  input  wire logic             fix_en_i,        // 1 = repair correctable words
  input  wire logic             ue_halt_i,       // 1 = stop on an uncorrectable word
  input  wire logic             resume_i,        // pulse: continue after a halt (skips the word)
  // request to the wrapper's scrub port
  output logic                  req_valid_o,
  input  wire logic             req_ready_i,
  output logic [1:0]            req_op_o,        // 0 CHECK, 1 FIX, 2 VERIFY
  output logic [AW-1:0]         req_addr_o,
  output logic [SYN_W-1:0]      req_syn_o,       // syndrome seen by CHECK (lets the wrapper suppress a duplicate CE report)
  // result from the wrapper (one pulse per request)
  input  wire logic             rsp_valid_i,
  input  wire logic             rsp_ce_i,
  input  wire logic             rsp_ue_i,
  input  wire logic [SYN_W-1:0] rsp_syn_i,
  // status
  output logic                  busy_o,
  output logic                  halted_o,
  output logic [AW-1:0]         addr_o,
  output logic                  pass_o,          // pulse: one full pass completed
  output logic [AW-1:0]         ue_addr_o,       // last uncorrectable word found
  output logic [CNT_W-1:0]      words_o,
  output logic [CNT_W-1:0]      ce_found_o,
  output logic [CNT_W-1:0]      ue_found_o,
  output logic [CNT_W-1:0]      fixed_o,
  output logic [CNT_W-1:0]      persistent_o,
  output logic [CNT_W-1:0]      passes_o
);
  localparam logic [1:0] OP_CHECK = 2'd0, OP_FIX = 2'd1, OP_VERIFY = 2'd2;
  localparam logic [2:0] S_IDLE = 3'd0, S_REQ = 3'd1, S_WAIT = 3'd2, S_NEXT = 3'd3, S_HALT = 3'd4;

  logic [2:0]       st_q;
  logic [1:0]       op_q;
  logic [AW-1:0]    addr_q, ue_addr_q;
  logic [SYN_W-1:0] syn_q;
  logic [15:0]      tmr_q;
  logic             pass_q;
  logic [CNT_W-1:0] words_q, ce_q, ue_q, fixed_q, pers_q, passes_q;

  function automatic logic [CNT_W-1:0] sat_inc(input logic [CNT_W-1:0] v);
    sat_inc = (v == {CNT_W{1'b1}}) ? v : v + (CNT_W)'(1);
  endfunction

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st_q <= S_IDLE; op_q <= OP_CHECK; addr_q <= '0; ue_addr_q <= '0; syn_q <= '0; tmr_q <= '0; pass_q <= 1'b0;
      words_q <= '0; ce_q <= '0; ue_q <= '0; fixed_q <= '0; pers_q <= '0; passes_q <= '0;
    end else begin
      pass_q <= 1'b0;
      case (st_q)
        S_IDLE: begin
          if (tmr_q != 16'd0) tmr_q <= tmr_q - 16'd1;
          else if (en_i) begin st_q <= S_REQ; op_q <= OP_CHECK; end
        end
        S_REQ: if (req_ready_i) st_q <= S_WAIT;
        S_WAIT: if (rsp_valid_i) begin
          case (op_q)
            OP_CHECK: begin
              words_q <= sat_inc(words_q);
              if (rsp_ue_i) begin
                ue_q <= sat_inc(ue_q); ue_addr_q <= addr_q;
                st_q <= ue_halt_i ? S_HALT : S_NEXT;
              end else if (rsp_ce_i) begin
                ce_q <= sat_inc(ce_q);
                syn_q <= rsp_syn_i;
                if (fix_en_i) begin op_q <= OP_FIX; st_q <= S_REQ; end
                else st_q <= S_NEXT;
              end else st_q <= S_NEXT;
            end
            OP_FIX: begin
              if (rsp_ue_i) begin                         // got worse between CHECK and FIX
                ue_q <= sat_inc(ue_q); ue_addr_q <= addr_q;
                st_q <= ue_halt_i ? S_HALT : S_NEXT;
              end else if (rsp_ce_i) begin                // repaired: confirm with a read
                op_q <= OP_VERIFY; st_q <= S_REQ;
              end else st_q <= S_NEXT;                    // already clean (rewritten meanwhile)
            end
            default: begin                                // OP_VERIFY
              if (rsp_ue_i) begin
                ue_q <= sat_inc(ue_q); ue_addr_q <= addr_q;
                st_q <= ue_halt_i ? S_HALT : S_NEXT;
              end else if (rsp_ce_i) begin pers_q <= sat_inc(pers_q); st_q <= S_NEXT; end
              else begin fixed_q <= sat_inc(fixed_q); st_q <= S_NEXT; end
            end
          endcase
        end
        S_NEXT: begin
          if (addr_q == AW'(DEPTH - 1)) begin
            addr_q <= '0; passes_q <= sat_inc(passes_q); pass_q <= 1'b1;
          end else addr_q <= addr_q + (AW)'(1);
          tmr_q <= interval_i;
          st_q  <= S_IDLE;
        end
        S_HALT: if (resume_i) st_q <= S_NEXT;
        default: st_q <= S_IDLE;
      endcase
    end
  end

  assign req_valid_o = (st_q == S_REQ);
  assign req_op_o    = op_q;
  assign req_addr_o  = addr_q;
  assign req_syn_o   = syn_q;
  assign busy_o      = (st_q == S_REQ) || (st_q == S_WAIT) || (st_q == S_NEXT);
  assign halted_o    = (st_q == S_HALT);
  assign addr_o      = addr_q;
  assign pass_o      = pass_q;
  assign ue_addr_o   = ue_addr_q;
  assign words_o     = words_q;
  assign ce_found_o  = ce_q;
  assign ue_found_o  = ue_q;
  assign fixed_o     = fixed_q;
  assign persistent_o= pers_q;
  assign passes_o    = passes_q;
endmodule

`default_nettype wire
