// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_sram_ecc_ras
// Error-event collection, counters, severity policy and the firmware register page
// of the ECC SRAM wrapper.  The wrapper raises AT MOST ONE event pulse per decoded
// word (single decode point, see sf_sram_ecc.sv), so every ev_valid_i is counted
// exactly once -- backpressure on the response channel, pipeline stalls and the
// scrub CHECK -> FIX pair cannot make it count twice.
//
// Event kinds (one-hot on the *_i inputs):
//   ev_ce_i       a single-bit error was corrected
//   ev_ue_i       an uncorrectable error was detected
//   ev_persist_i  a word that a scrub FIX had just repaired still reads as a
//                 single-bit error (hard fault).  NOT counted as another CE.
//
// Outputs (the RAS interface):
//   ce_count_o / ue_count_o / persist_count_o   saturating 32-bit counters
//   last_ce_* / first_ue_* / last_ue_*          word address, syndrome {pe,s}, corrected-bit index, source
//   irq_warn_o   (CE seen & CE_IRQ_EN) | (PERSIST seen & CE_IRQ_EN) | CE-threshold hit
//   irq_ue_o     UE seen & UE_IRQ_EN
//   fatal_req_o  sticky fatal-error request (level).  Drives e.g. cc_ras EXT_FATAL.
//                Set by: UE from a demand read / RMW (UE_FATAL_EN, default 1);
//                UE found by scrub (SCRUB_UE_FATAL_EN, default 0: a latent UE in memory
//                nobody has consumed yet is reported, not fatal); PERSIST
//                (PERSIST_FATAL_EN); CE counter reaching CE_THR (CE_THR_FATAL_EN).
//                Cleared by writing 1 to STATUS.FATAL (it re-sets if the cause recurs).
//
// Register page (32-bit; zero-wait-state bus: reg_sel_i/we/addr/wdata -> rdata/err)
//   0x00 ID           RO   0x45434337 ("ECC7")
//   0x04 CFG          RO   [7:0] K  [15:8] N  [23:16] AW  [24] SCRUB_EN  [25] FI_EN
//   0x08 CTRL         RW   [0] CE_IRQ_EN [1] UE_IRQ_EN [2] UE_FATAL_EN(1) [3] SCRUB_UE_FATAL_EN
//                          [4] PERSIST_FATAL_EN [5] CE_THR_FATAL_EN
//   0x0C CE_THR       RW   0 = disabled; CE_COUNT >= CE_THR sets STATUS.CE_THR_HIT
//   0x10 STATUS       W1C  [0] CE_SEEN [1] UE_SEEN [2] PERSIST_SEEN [3] CE_THR_HIT [4] CNT_SAT [5] FATAL
//   0x14 CE_COUNT     RO
//   0x18 UE_COUNT     RO
//   0x1C PERSIST_COUNT RO
//   0x20 LAST_CE_ADDR RO
//   0x24 LAST_CE_INFO RO   [11:0] syndrome  [23:12] corrected-bit index  [25:24] source
//   0x28 FIRST_UE_ADDR RO  (captured once, re-armed by CLR[1])
//   0x2C FIRST_UE_INFO RO  same layout
//   0x30 LAST_UE_ADDR RO
//   0x34 LAST_UE_INFO RO
//   0x38 CLR          WO   [0] clear counters + CNT_SAT  [1] re-arm FIRST_UE capture
// A write to a RO register or a read of an unmapped offset sets reg_err_o.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_sram_ecc_ras #(
  parameter int K        = 64,
  parameter int N        = 72,
  parameter int AW       = 8,
  parameter int SYN_W    = 8,            // R + 1
  parameter int POS_W    = 7,
  parameter int SCRUB_EN = 0,
  parameter int FI_EN    = 0,
  parameter int CNT_W    = 32
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // event bus from the wrapper (single-cycle pulses)
  input  wire logic              ev_valid_i,
  input  wire logic              ev_ce_i,
  input  wire logic              ev_ue_i,
  input  wire logic              ev_persist_i,
  input  wire logic [1:0]        ev_src_i,
  input  wire logic [AW-1:0]     ev_addr_i,
  input  wire logic [SYN_W-1:0]  ev_syn_i,
  input  wire logic [POS_W-1:0]  ev_pos_i,
  // firmware register page
  input  wire logic              reg_sel_i,
  input  wire logic              reg_we_i,
  input  wire logic [7:0]        reg_addr_i,
  input  wire logic [31:0]       reg_wdata_i,
  output logic      [31:0]       reg_rdata_o,
  output logic                   reg_err_o,
  // RAS outputs
  output logic [CNT_W-1:0]       ce_count_o,
  output logic [CNT_W-1:0]       ue_count_o,
  output logic [CNT_W-1:0]       persist_count_o,
  output logic [AW-1:0]          last_addr_o,       // address of the most recent CE or UE
  output logic [SYN_W-1:0]       last_syn_o,        // its syndrome
  output logic                   ce_seen_o,         // sticky levels
  output logic                   ue_seen_o,
  output logic                   irq_warn_o,
  output logic                   irq_ue_o,
  output logic                   fatal_req_o
);
  localparam logic [31:0] ID = 32'h4543_4337;

  // ---------------------------------------------------------------- state
  logic ce_irq_en_q, ue_irq_en_q, ue_fatal_en_q, scr_ue_fatal_en_q, per_fatal_en_q, thr_fatal_en_q;
  logic [31:0] ce_thr_q;
  logic st_ce_q, st_ue_q, st_per_q, st_thr_q, st_sat_q, st_fatal_q;
  logic [CNT_W-1:0] ce_cnt_q, ue_cnt_q, per_cnt_q;
  logic [AW-1:0] lce_addr_q, fue_addr_q, lue_addr_q;
  logic [31:0]   lce_info_q, fue_info_q, lue_info_q;
  logic          fue_valid_q;
  logic [AW-1:0] last_addr_q;
  logic [SYN_W-1:0] last_syn_q;

  localparam logic [CNT_W-1:0] CNT_MAX = '1;

  wire [31:0] ev_info = {6'd0, ev_src_i, 12'(ev_pos_i), 12'(ev_syn_i)};

  wire ce_evt  = ev_valid_i && ev_ce_i;
  wire ue_evt  = ev_valid_i && ev_ue_i;
  wire per_evt = ev_valid_i && ev_persist_i;
  wire from_scrub = (ev_src_i == 2'd2);

  wire [CNT_W-1:0] ce_next = (ce_cnt_q == CNT_MAX) ? ce_cnt_q : ce_cnt_q + (CNT_W)'(1);
  wire thr_hit_now = ce_evt && (ce_thr_q != 32'd0) && ((32'(ce_next)) >= ce_thr_q);

  // register decode
  wire reg_wr = reg_sel_i && reg_we_i;
  wire clr_cnt  = reg_wr && (reg_addr_i == 8'h38) && reg_wdata_i[0];
  wire clr_fue  = reg_wr && (reg_addr_i == 8'h38) && reg_wdata_i[1];
  wire w1c_sts  = reg_wr && (reg_addr_i == 8'h10);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      ce_irq_en_q <= 1'b0; ue_irq_en_q <= 1'b0; ue_fatal_en_q <= 1'b1;
      scr_ue_fatal_en_q <= 1'b0; per_fatal_en_q <= 1'b0; thr_fatal_en_q <= 1'b0;
      ce_thr_q <= 32'd0;
      st_ce_q <= 1'b0; st_ue_q <= 1'b0; st_per_q <= 1'b0; st_thr_q <= 1'b0; st_sat_q <= 1'b0; st_fatal_q <= 1'b0;
      ce_cnt_q <= '0; ue_cnt_q <= '0; per_cnt_q <= '0;
      lce_addr_q <= '0; fue_addr_q <= '0; lue_addr_q <= '0;
      lce_info_q <= '0; fue_info_q <= '0; lue_info_q <= '0;
      fue_valid_q <= 1'b0; last_addr_q <= '0; last_syn_q <= '0;
    end else begin
      // ---------------- software writes (applied first; events below override on the same cycle)
      if (reg_wr) begin
        case (reg_addr_i)
          8'h08: begin
            ce_irq_en_q <= reg_wdata_i[0]; ue_irq_en_q <= reg_wdata_i[1]; ue_fatal_en_q <= reg_wdata_i[2];
            scr_ue_fatal_en_q <= reg_wdata_i[3]; per_fatal_en_q <= reg_wdata_i[4]; thr_fatal_en_q <= reg_wdata_i[5];
          end
          8'h0C: ce_thr_q <= reg_wdata_i;
          default: ;
        endcase
      end
      if (w1c_sts) begin
        if (reg_wdata_i[0]) st_ce_q <= 1'b0;
        if (reg_wdata_i[1]) st_ue_q <= 1'b0;
        if (reg_wdata_i[2]) st_per_q <= 1'b0;
        if (reg_wdata_i[3]) st_thr_q <= 1'b0;
        if (reg_wdata_i[4]) st_sat_q <= 1'b0;
        if (reg_wdata_i[5]) st_fatal_q <= 1'b0;
      end
      if (clr_cnt) begin ce_cnt_q <= '0; ue_cnt_q <= '0; per_cnt_q <= '0; st_sat_q <= 1'b0; end
      if (clr_fue) fue_valid_q <= 1'b0;

      // ---------------- events
      if (ce_evt) begin
        st_ce_q <= 1'b1;
        if (ce_cnt_q == CNT_MAX) st_sat_q <= 1'b1; else ce_cnt_q <= ce_next;
        lce_addr_q <= ev_addr_i; lce_info_q <= ev_info;
        last_addr_q <= ev_addr_i; last_syn_q <= ev_syn_i;
        if (thr_hit_now) begin
          st_thr_q <= 1'b1;
          if (thr_fatal_en_q) st_fatal_q <= 1'b1;
        end
      end
      if (ue_evt) begin
        st_ue_q <= 1'b1;
        if (ue_cnt_q == CNT_MAX) st_sat_q <= 1'b1; else ue_cnt_q <= ue_cnt_q + (CNT_W)'(1);
        lue_addr_q <= ev_addr_i; lue_info_q <= ev_info;
        last_addr_q <= ev_addr_i; last_syn_q <= ev_syn_i;
        if (!fue_valid_q) begin                       // first UE since reset / re-arm
          fue_valid_q <= 1'b1; fue_addr_q <= ev_addr_i; fue_info_q <= ev_info;
        end
        if (from_scrub ? scr_ue_fatal_en_q : ue_fatal_en_q) st_fatal_q <= 1'b1;
      end
      if (per_evt) begin
        st_per_q <= 1'b1;
        if (per_cnt_q == CNT_MAX) st_sat_q <= 1'b1; else per_cnt_q <= per_cnt_q + (CNT_W)'(1);
        if (per_fatal_en_q) st_fatal_q <= 1'b1;
      end
    end
  end

  // ---------------------------------------------------------------- register read
  always_comb begin
    reg_rdata_o = 32'd0;
    reg_err_o   = 1'b0;
    if (reg_sel_i) begin
      case (reg_addr_i)
        8'h00: begin reg_rdata_o = ID; reg_err_o = reg_we_i; end
        8'h04: begin reg_rdata_o = {6'd0, (FI_EN != 0), (SCRUB_EN != 0), 8'(AW), 8'(N), 8'(K)}; reg_err_o = reg_we_i; end
        8'h08: reg_rdata_o = {26'd0, thr_fatal_en_q, per_fatal_en_q, scr_ue_fatal_en_q, ue_fatal_en_q, ue_irq_en_q, ce_irq_en_q};
        8'h0C: reg_rdata_o = ce_thr_q;
        8'h10: reg_rdata_o = {26'd0, st_fatal_q, st_sat_q, st_thr_q, st_per_q, st_ue_q, st_ce_q};
        8'h14: begin reg_rdata_o = 32'(ce_cnt_q);  reg_err_o = reg_we_i; end
        8'h18: begin reg_rdata_o = 32'(ue_cnt_q);  reg_err_o = reg_we_i; end
        8'h1C: begin reg_rdata_o = 32'(per_cnt_q); reg_err_o = reg_we_i; end
        8'h20: begin reg_rdata_o = 32'(lce_addr_q); reg_err_o = reg_we_i; end
        8'h24: begin reg_rdata_o = lce_info_q;      reg_err_o = reg_we_i; end
        8'h28: begin reg_rdata_o = 32'(fue_addr_q); reg_err_o = reg_we_i; end
        8'h2C: begin reg_rdata_o = fue_info_q;      reg_err_o = reg_we_i; end
        8'h30: begin reg_rdata_o = 32'(lue_addr_q); reg_err_o = reg_we_i; end
        8'h34: begin reg_rdata_o = lue_info_q;      reg_err_o = reg_we_i; end
        8'h38: begin reg_rdata_o = 32'd0; end                       // write-only: reads as 0
        default: reg_err_o = 1'b1;
      endcase
    end
  end

  // ---------------------------------------------------------------- outputs
  assign ce_count_o      = ce_cnt_q;
  assign ue_count_o      = ue_cnt_q;
  assign persist_count_o = per_cnt_q;
  assign last_addr_o     = last_addr_q;
  assign last_syn_o      = last_syn_q;
  assign ce_seen_o       = st_ce_q;
  assign ue_seen_o       = st_ue_q;
  assign irq_warn_o      = ((st_ce_q || st_per_q) && ce_irq_en_q) || st_thr_q;
  assign irq_ue_o        = st_ue_q && ue_irq_en_q;
  assign fatal_req_o     = st_fatal_q;
endmodule

`default_nettype wire
