// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_secded_enc
// Combinational extended-Hamming SECDED encoder:  K data bits -> N = K+R+1 bits.
//
//   cw_o[K-1:0]   = data_i                                    (systematic)
//   cw_o[K+R-1:K] = c[j] = XOR of the data bits whose Hamming position has
//                   bit j set                                   j = 0..R-1
//   cw_o[K+R]     = p = (^data_i) ^ (^c)   (even parity over data + checks)
//   then cw_o[K+R:K] ^= INV
//
// PARITY CONVENTION (explicit): EVEN parity.  A valid (un-inverted) codeword has
// an even number of ones overall and every Hamming row (j) even.  K=64: R=7, N=72.
// Bit layout, positions and INV: rtl/sf_secded_funcs.svh, docs/01_math_model.md.
// Logic depth: one XOR tree per check bit (<= 36 inputs for K=64) plus the
// overall-parity tree.  Pipelined variant: sf_secded_enc_pipe.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_secded_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sf_secded_enc #(
  parameter int K   = 64,
  parameter int INV = 0,                                   // check/parity inversion mask (R+1 bits used)
  // ---- derived, do not override ----
  parameter int R   = $clog2(K + $clog2(K + 1) + 1),       // smallest r with 2^r >= K+r+1
  parameter int N   = K + R + 1
) (
  input  wire logic [K-1:0] data_i,
  output logic      [N-1:0] cw_o
);
  `include "sf_secded_funcs.svh"

  if (K < 1) begin : g_err_k
    `SF_ECC_CFG_FATAL("sf_secded_enc: K must be >= 1")
  end
  if (R != sf_secded_r(K) || N != K + sf_secded_r(K) + 1) begin : g_err_derived
    `SF_ECC_CFG_FATAL("sf_secded_enc: R and N are derived parameters, do not override")
  end

  localparam logic [R:0] INV_V = (R+1)'(INV);

  logic [R-1:0] chk;
  for (genvar j = 0; j < R; j++) begin : g_chk
    localparam logic [K-1:0] CMASK = sf_secded_cmask(j);
    assign chk[j] = ^(data_i & CMASK);
  end

  wire par = (^data_i) ^ (^chk);

  assign cw_o = {par ^ INV_V[R], chk ^ INV_V[R-1:0], data_i};

endmodule

`default_nettype wire
