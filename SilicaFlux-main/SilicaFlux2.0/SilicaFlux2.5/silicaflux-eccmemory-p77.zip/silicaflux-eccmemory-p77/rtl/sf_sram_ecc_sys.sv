// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_sram_ecc_sys
// sf_sram_ecc + the behavioural 1RW macro model (sf_sram_ecc_ram).  This is the
// unit the testbenches and the formal tops instantiate.  For an ASIC / FPGA flow
// instantiate sf_sram_ecc directly and connect m_* to the real macro.
// All ports of sf_sram_ecc are forwarded unchanged.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sf_sram_ecc_sys #(
  parameter int K                 = 64,
  parameter int DEPTH             = 256,
  parameter int RD_LAT            = 1,
  parameter int DEC_PIPE          = 0,
  parameter int RSP_DEPTH         = 8,
  parameter int ID_W              = 4,
  parameter int CHK_INV           = 3,
  parameter int UE_DATA_ZERO      = 0,
  parameter int INIT_ON_RESET     = 1,
  parameter int REINIT_AFTER_TEST = 1,
  parameter int TEST_EN           = 1,
  parameter int SCRUB_EN          = 0,
  parameter int SCRUB_MAX_WAIT    = 16,
  parameter int FI_EN             = 0,
  parameter int RAM_INIT_ZERO     = 1,
  parameter int R    = $clog2(K + $clog2(K + 1) + 1),
  parameter int N    = K + R + 1,
  parameter int IW   = $clog2(N),
  parameter int AW   = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  parameter int BE_W = K / 8,
  parameter int SYN_W = R + 1
) (
  input  wire logic              clk, rst_n,
  input  wire logic              req_valid, output logic req_ready, input wire logic req_we,
  input  wire logic [AW-1:0]     req_addr, input wire logic [K-1:0] req_wdata, input wire logic [BE_W-1:0] req_be,
  input  wire logic [ID_W-1:0]   req_id,
  output logic                   rsp_valid, input wire logic rsp_ready, output logic [K-1:0] rsp_rdata,
  output logic                   rsp_err, rsp_ue, rsp_ce, rsp_we, output logic [ID_W-1:0] rsp_id,
  input  wire logic              xscr_req_valid, output logic xscr_req_ready, input wire logic [1:0] xscr_req_op,
  input  wire logic [AW-1:0]     xscr_req_addr, input wire logic [SYN_W-1:0] xscr_req_syn,
  output logic                   xscr_rsp_valid, output logic [1:0] xscr_rsp_op, output logic xscr_rsp_ce, xscr_rsp_ue,
  output logic [SYN_W-1:0]       xscr_rsp_syn, output logic [AW-1:0] xscr_rsp_addr,
  input  wire logic              scrub_en_i, input wire logic [15:0] scrub_interval_i, input wire logic scrub_fix_en_i,
  input  wire logic              scrub_ue_halt_i, scrub_resume_i,
  output logic                   scrub_busy_o, scrub_halted_o, scrub_pass_o,
  output logic [AW-1:0]          scrub_addr_o, scrub_ue_addr_o,
  output logic [31:0]            scrub_words_o, scrub_ce_found_o, scrub_ue_found_o, scrub_fixed_o, scrub_persistent_o, scrub_passes_o,
  input  wire logic              init_start_i, output logic init_busy_o, quiet_o, lock_o,
  input  wire logic              tst_req_i, output logic tst_grant_o, input wire logic tst_en_i, tst_we_i,
  input  wire logic [AW-1:0]     tst_addr_i, input wire logic [N-1:0] tst_wdata_i, output logic [N-1:0] tst_rdata_o,
  input  wire logic              fi_auth_i, fi_enable_i, fi_cmd_valid_i, input wire logic [1:0] fi_cmd_mode_i,
  input  wire logic [N-1:0]      fi_cmd_mask_i, fi_cmd_val_i, input wire logic [AW-1:0] fi_cmd_addr_i,
  input  wire logic              fi_cmd_addr_en_i, fi_clear_i,
  output logic                   fi_armed_o, fi_stuck_o, fi_fired_o, fi_blocked_o, fi_busy_o, output logic [15:0] fi_blocked_cnt_o,
  output logic                   ev_valid_o, ev_ce_o, ev_ue_o, ev_persist_o, output logic [1:0] ev_src_o,
  output logic [AW-1:0]          ev_addr_o, output logic [SYN_W-1:0] ev_syn_o, output logic [IW-1:0] ev_pos_o,
  input  wire logic              ras_reg_sel_i, ras_reg_we_i, input wire logic [7:0] ras_reg_addr_i, input wire logic [31:0] ras_reg_wdata_i,
  output logic [31:0]            ras_reg_rdata_o, output logic ras_reg_err_o,
  output logic [31:0]            ce_count_o, ue_count_o, persist_count_o,
  output logic [AW-1:0]          last_addr_o, output logic [SYN_W-1:0] last_syn_o,
  output logic                   ce_seen_o, ue_seen_o, irq_warn_o, irq_ue_o, fatal_req_o
);
  wire          m_en, m_we;
  wire [AW-1:0] m_addr;
  wire [N-1:0]  m_wdata, m_rdata;

  sf_sram_ecc #(
    .K(K), .DEPTH(DEPTH), .RD_LAT(RD_LAT), .DEC_PIPE(DEC_PIPE), .RSP_DEPTH(RSP_DEPTH), .ID_W(ID_W),
    .CHK_INV(CHK_INV), .UE_DATA_ZERO(UE_DATA_ZERO), .INIT_ON_RESET(INIT_ON_RESET),
    .REINIT_AFTER_TEST(REINIT_AFTER_TEST), .TEST_EN(TEST_EN), .SCRUB_EN(SCRUB_EN),
    .SCRUB_MAX_WAIT(SCRUB_MAX_WAIT), .FI_EN(FI_EN)
  ) u_ecc (.*);

  sf_sram_ecc_ram #(.N(N), .DEPTH(DEPTH), .RD_LAT(RD_LAT), .INIT_ZERO(RAM_INIT_ZERO)) u_ram (
    .clk(clk), .en(m_en), .we(m_we), .addr(m_addr), .wdata(m_wdata), .rdata(m_rdata));
endmodule

`default_nettype wire
