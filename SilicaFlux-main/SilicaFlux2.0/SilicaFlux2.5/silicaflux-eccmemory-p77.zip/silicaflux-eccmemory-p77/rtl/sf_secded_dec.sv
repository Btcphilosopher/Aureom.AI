// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_secded_dec
// Combinational extended-Hamming SECDED decoder and error classifier.
//
// Input: a stored N-bit word (layout: sf_secded_funcs.svh).
//   c_rx = cw[K+R-1:K] ^ INV[R-1:0]     p_rx = cw[K+R] ^ INV[R]     d_rx = cw[K-1:0]
//   s    = (check bits recomputed from d_rx) ^ c_rx          R bits  (SYNDROME)
//   pe   = p_rx ^ (^c_rx) ^ (^d_rx)      parity of all N un-inverted bits
//   syn_o = {pe, s}
//
// Classification (exactly one of none / ce / ue):
//   s == 0, pe == 0            NONE
//   s == 0, pe == 1            CE   the overall-parity bit flipped   (err_kind = PAR)
//   s != 0, pe == 1, s <= K+R  CE   one error at Hamming position s: check bit
//                                   (s = 2^j) or data bit; flipped back
//   s != 0, pe == 1, s >  K+R  UE   INVALID syndrome: names no bit => >= 3 errors
//   s != 0, pe == 0            UE   double error (any even number >= 2)
//
// ce_o is asserted only when exactly ONE bit has been flipped back.  On UE the
// outputs data_o / cw_corr_o carry the STORED, UNCORRECTED bits: this block never
// substitutes or "repairs" data it cannot correct, and a double-bit error is
// never reported as a correction.  The caller must gate use of data_o with ue_o.
//
// Guarantee (proved in formal/, exhaustively checked in sim): every 1-bit error
// -> CE with the right bit; every 2-bit error -> UE.  NOT guaranteed: weight >= 3
// (odd weight may alias to a CE = miscorrection; even weight may be a codeword).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_secded_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sf_secded_dec #(
  parameter int K   = 64,
  parameter int INV = 0,
  // ---- derived, do not override ----
  parameter int R   = $clog2(K + $clog2(K + 1) + 1),
  parameter int N   = K + R + 1,
  parameter int IW  = $clog2(N)
) (
  input  wire logic [N-1:0]  cw_i,
  output logic      [K-1:0]  data_o,        // corrected data (raw stored data on UE)
  output logic      [N-1:0]  cw_corr_o,     // corrected stored word (raw on UE)
  output logic               none_o,        // no error
  output logic               ce_o,          // exactly one bit corrected
  output logic               ue_o,          // uncorrectable (do not use data_o)
  output logic               ue_inval_o,    // ue_o caused by an invalid syndrome (>= 3 errors)
  output logic      [1:0]    err_kind_o,    // SF_ECC_KIND_* of the corrected bit (valid with ce_o)
  output logic      [IW-1:0] err_pos_o,     // stored-bit index of the corrected bit (valid with ce_o)
  output logic      [R:0]    syn_o          // {pe, s}
);
  `include "sf_secded_funcs.svh"

  if (R != sf_secded_r(K) || N != K + sf_secded_r(K) + 1 || IW != $clog2(N)) begin : g_err_derived
    `SF_ECC_CFG_FATAL("sf_secded_dec: R, N, IW are derived parameters, do not override")
  end

  localparam logic [R:0] INV_V = (R+1)'(INV);

  // ------------------------------------------------------------- syndrome
  wire [K-1:0] d_rx = cw_i[K-1:0];
  wire [R-1:0] c_rx = cw_i[K+R-1:K] ^ INV_V[R-1:0];
  wire         p_rx = cw_i[K+R]     ^ INV_V[R];

  logic [R-1:0] s;
  for (genvar j = 0; j < R; j++) begin : g_syn
    localparam logic [K-1:0] CMASK = sf_secded_cmask(j);
    assign s[j] = (^(d_rx & CMASK)) ^ c_rx[j];
  end
  wire pe = p_rx ^ (^c_rx) ^ (^d_rx);

  wire s_zero  = (s == '0);
  wire s_valid = ({1'b0, s} <= (R+1)'(K + R));          // names an existing stored bit

  assign none_o     = s_zero && !pe;
  assign ce_o       = pe && (s_zero || s_valid);
  assign ue_o       = !s_zero && (!pe || !s_valid);
  assign ue_inval_o = !s_zero && pe && !s_valid;
  assign syn_o      = {pe, s};

  // ------------------------------------------------ one-hot error location
  logic [N-1:0] hit;
  for (genvar b = 0; b < N; b++) begin : g_hit
    localparam int HP = sf_secded_hpos(K, b);
    if (b == K + R) begin : g_par
      assign hit[b] = pe && s_zero;
    end else begin : g_pos
      assign hit[b] = pe && (s == R'(HP));
    end
  end

  assign cw_corr_o = cw_i ^ hit;             // hit is all-zero unless ce_o (an invalid s matches no bit)
  assign data_o    = d_rx ^ hit[K-1:0];

  assign err_kind_o = hit[K+R]            ? `SF_ECC_KIND_PAR   :
                      (|hit[K+R-1:K])     ? `SF_ECC_KIND_CHECK : `SF_ECC_KIND_DATA;

  always_comb begin
    err_pos_o = '0;
    for (int b = 0; b < N; b++) if (hit[b]) err_pos_o = err_pos_o | IW'(b);
  end

`ifdef SF_SECDED_ASSERT
  // NB: explicit arithmetic instead of $onehot/$countones (Icarus 12 miscounts concatenations)
  wire [1:0] nclass = (none_o ? 2'd1 : 2'd0) + (ce_o ? 2'd1 : 2'd0) + (ue_o ? 2'd1 : 2'd0);
  logic [R:0] nhit;
  always_comb begin
    nhit = '0;
    for (int b = 0; b < N; b++) nhit = nhit + (R+1)'(hit[b]);
  end
  always_comb begin
    if (!$isunknown(cw_i)) begin
      assert (nclass == 2'd1) else $error("%m: classification not one-hot");
      assert (nhit == (ce_o ? (R+1)'(1) : (R+1)'(0))) else $error("%m: correction mask weight != ce_o");
      assert (!(ue_o && (cw_corr_o != cw_i))) else $error("%m: UE must not modify the word");
    end
  end
`endif

endmodule

`default_nettype wire
