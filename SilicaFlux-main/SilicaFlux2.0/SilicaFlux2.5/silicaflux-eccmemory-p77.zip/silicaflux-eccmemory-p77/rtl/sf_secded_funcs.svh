// =============================================================================
// SilicaFlux Project 77 (ECCMemory) :: sf_secded_funcs.svh
// Elaboration-time functions that DEFINE the extended-Hamming SECDED code.
// Included INSIDE a module body that has a parameter K (data width).
// Verilog-2001 function style (assignment to the function name, no 'return',
// loop variables declared up front): Yosys 0.33 accepts nothing else in
// constant functions.
//
// Code: K data bits, R Hamming check bits, 1 overall parity bit, N = K+R+1.
//   R = smallest r with 2^r >= K + r + 1.     K=64 -> R=7, N=72.
//
// Hamming positions (the syndrome value that names a bit):
//   check bit j        -> 2^j                       j = 0..R-1   (1,2,4,..,64)
//   data bit i         -> (i+1)-th integer >= 3 that is not a power of two
//                         (3,5,6,7,9,10,11,12,13,..,71)       i = 0..K-1
//   overall parity bit -> position 0 (not covered by the syndrome)
// Positions 1..K+R are each used exactly once; a syndrome > K+R names no bit.
//
// Stored (systematic) layout of cw[N-1:0]:
//   cw[K-1:0]     data bits     (data bit i at cw[i])
//   cw[K+R-1:K]   check bits    (check bit j at cw[K+j])
//   cw[K+R]       overall parity (even parity over cw[K+R-1:0] before INV)
// then cw[K+R:K] ^= INV (R+1-bit constant; 0 = plain code).
// =============================================================================

  // number of Hamming check bits for k data bits
  function automatic integer sf_secded_r(input integer k);
    integer t;
    begin
      sf_secded_r = 0;
      for (t = 24; t >= 1; t = t - 1)
        if ((1 << t) >= k + t + 1) sf_secded_r = t;
    end
  endfunction

  // Hamming position of data bit i: start at i+1 and step over every power of two
  function automatic integer sf_secded_dpos(input integer i);
    integer t, p;
    begin
      p = i + 1;
      for (t = 0; t < 30; t = t + 1)
        if ((1 << t) <= p) p = p + 1;
      sf_secded_dpos = p;
    end
  endfunction

  // Hamming position of stored bit b of a K-data-bit codeword (0 = overall parity)
  function automatic integer sf_secded_hpos(input integer k, input integer b);
    integer r;
    begin
      r = sf_secded_r(k);
      if (b < k)          sf_secded_hpos = sf_secded_dpos(b);
      else if (b < k + r) sf_secded_hpos = (1 << (b - k));
      else                sf_secded_hpos = 0;
    end
  endfunction

  // mask of the data bits covered by Hamming check bit j (those whose position has bit j set)
  function automatic [K-1:0] sf_secded_cmask(input integer j);
    integer i;
    begin
      sf_secded_cmask = {K{1'b0}};
      for (i = 0; i < K; i = i + 1)
        if (((sf_secded_dpos(i) >> j) & 1) != 0) sf_secded_cmask[i] = 1'b1;
    end
  endfunction
