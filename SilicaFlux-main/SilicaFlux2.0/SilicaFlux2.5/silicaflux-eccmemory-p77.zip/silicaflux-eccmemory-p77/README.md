# SilicaFlux Project 77 — ECCMemory: SECDED SRAM error correction

64 data bits + 8 check bits = 72 stored bits per word. Extended-Hamming SECDED: **corrects every 1-bit error, detects every 2-bit error**, reports to RAS,
scrubs in the background, and keeps memory contents correct under byte-enable (partial) writes. **No claim is made for ≥ 3-bit errors.**

Primary RTL: `rtl/sf_sram_ecc.sv`. Not committed to git — delivered as this archive.

## What is in the box

| Deliverable | Where |
|---|---|
| Repository audit (SRAMCore/SRAMBank, existing SECDED, RAS, MBIST, macro wrappers, firmware registers) | `docs/00_audit.md` |
| **64/72 mathematical model** (positions, parity convention, syndrome, correction, proofs, hand-derived vectors) | `docs/01_math_model.md`, `model/` |
| Encoder (combinational + 1/2-stage pipelined), decoder | `rtl/sf_secded_enc.sv`, `sf_secded_enc_pipe.sv`, `sf_secded_dec.sv` |
| ECC SRAM wrapper (RMW, lock, init, MBIST port, latency-accounted, back-pressure safe) | `rtl/sf_sram_ecc.sv` |
| Scrub engine (optional) | `rtl/sf_sram_ecc_scrub.sv` |
| RAS interface (events, counters, syndrome, address, fatal request, register page) | `rtl/sf_sram_ecc_ras.sv`, `docs/04_ras_interface.md` |
| Fault injection (disabled unless `FI_EN` **and** authorised at run time) | `rtl/sf_sram_ecc_fi.sv`, tests P13/P14/P15/P18 |
| Formal assertions | `formal/` (SAT proofs for the codec, bounded model checking for the wrapper) and an immediate-assertion block in `rtl/sf_sram_ecc.sv` (`SF_ASSERT`, run in simulation and in formal) |
| Coverage report | `reports/coverage.md` |
| Capacity (12.5 % vs 11.11 %) | `docs/03_capacity.md`, `reports/capacity.md` |
| Everything verified, with numbers | `reports/SUMMARY.md` and the files it points to |
| What is **not** established | `docs/06_limitations.md` |

## Order of work (as requested)

1. **The mathematical model first, verified before any RTL touched a memory** — four independent software implementations agree on every compared field; d_min = 4 is *computed*, not assumed.
2. **Codec RTL** checked against Python-generated golden vectors on two simulators and **proved by SAT** for all data words and all single/double-bit errors; proved *identical* to the existing Project 26 cells.
3. **Wrapper** around a macro, then scrub / injection / RAS, each with a scoreboard that predicts every response and RAS event.

## Results at a glance (all generated; see `reports/SUMMARY.md`)

| Evidence | Result |
|---|---|
| Math model: 4 independent implementations (incl. Project 26's), field-by-field | agree on all 1-/2-/3-bit errors, random words, and the entire 2^13 word space at K = 8; d_min = 4 computed |
| Codec vs Python golden vectors, Icarus **and** Verilator, 6 configurations | 107,830 decode + 2,150 encode vectors at K = 64 (INV 0), PASS everywhere; P26 RTL cells agree on every vector |
| Codec SAT proofs (unbounded) | **298 / 298 PROVED**: all 2^64 data × every 1-bit error (72) and every 2-bit error (2,556 pairs); decoder verdict over all 2^72 words; equivalent to P26's encoder/decoder; for `CHK_INV` = 0 and 0x03 |
| Wrapper simulation, 5 configurations × 2 simulators (LAT 1–3, K = 32/64, FI, scrub, plain code, TEST_EN 0/1) | **10 / 10 PASS**, 430,058 scoreboard checks in total (≈214k per simulator) (every accepted request, response, RAS event and counter predicted) |
| Independent Python check of the raw words the macro holds | 240/240 (c1, c2) and 160/160 (c3–c5) stored words match the software reference, per simulator, including words with latent injected errors |
| Wrapper formal (bounded) | RTL assertion block **PROVED** to depth 20 (LAT 1) and 16 (LAT 3 + scrub + FI); 16 / 16 reachability goals witnessed |
| Mutation testing | **33 / 33** killed (25 by a named check, 5 by a check then a hang, 3 only by the hang watchdog) |
| Code coverage (Verilator, merged) | line 96.2 %, branch 97.8 %, toggle 84.6 %; every uncovered line listed and classified, 0 unclassified |

## Defects found by this verification (and fixed)

* **Design:** `SCRUB_MAX_WAIT = 0` blocked the functional port forever (found by review; now a mutant the testbench kills).
* **Testbench gaps exposed by mutation:** reset default of the fatal policy unchecked; stuck-at never read at another address; scrub-vs-functional race only tried with an RMW.
* **Testbench gaps exposed by coverage:** `init_start_i`, `TEST_EN = 0`, scrub interval / `fix_en = 0` / UE-at-FIX / UE-at-VERIFY / clean-FIX, RAS counter saturation, selective W1C.
* **Harness flaw exposed by reachability goals:** the first formal instance had one byte lane, so partial writes could not occur and the RMW path was never exercised.
* **Tool/report errors caught along the way:** an Icarus `$countones` miscount; two Icarus compiler crashes; Verilator not writing coverage by default; a coverage merge that mis-keyed parameterised modules; mutants orphaned by a timeout.

## Quick start

```bash
make quick        # math model + wrapper on Icarus, about a minute
make all          # + codec and wrapper on Icarus AND Verilator (assertions + coverage), coverage report
make formal-codec formal-wrapper mutation     # the long runs
```
Needs: `python3`, `iverilog` 12, `verilator` 5.020, `yosys` 0.33 (all `apt install`able).

## Design in one paragraph

Writes encode in the accept cycle and are stored as whole 72-bit words; reads decode after the macro with an optional register in front of the decoder (`DEC_PIPE`).
Every operation also flows through a fixed-latency tag pipeline, so responses leave in acceptance order and backpressure is credit-based (the response FIFO cannot overflow).
A byte-enable write is an **atomic read-modify-write under a bank lock**: read → decode → merge into the *corrected* data → re-encode the whole word → commit → release; an
**uncorrectable old word aborts the write and leaves the word as found**. A scrub FIX is the same locked machinery with nothing to merge, so scrubbing can never write stale data over a functional write.
RAS events come from **one decode point**; a scrub CHECK→FIX pair is one event and a post-repair VERIFY that still fails is reported as `PERSIST`, not as another CE.
`CHK_INV = 0x03` makes the all-zero and all-ones stored words *uncorrectable*, so a dead word line or an MBIST zero-scrub is never read as valid data.

Latency (cycles from the accepting edge; `LAT = RD_LAT + DEC_PIPE`): read / full write **LAT + 2**, partial write **LAT + 4** (bank locked LAT + 2 cycles), 1 read or full write per cycle sustained — all measured by the testbench.

## Honest status

* The codec's properties are **proved** (SAT, unbounded). The wrapper's structural properties are **bounded-model-checked** (depth 20/16, K = 16 four-word instance); its ordering and data correctness are established by **simulation** with a scoreboard, an independent Python check of the raw stored words, and a mutation campaign.
* **Not** done: integration into `sf_sram_bank`/`sf_sram_core`, simulation against the real `sram_backend_1rw` / MBIST adapter / `cc_ras`, gate-level or timing analysis, silicon data. See `docs/06_limitations.md`.
* The simulation environment, tool versions and two Icarus bugs that were worked around are listed in `docs/05_verification.md` and `docs/06_limitations.md`.
