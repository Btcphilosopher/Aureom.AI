// =============================================================================
// SilicaFlux Project 77 :: formal/codec_formal.sv
// Combinational proof tops for the 64/72 SECDED codec (Yosys `sat -prove-asserts`).
// The data word (64 bits) and, where stated, the whole received word (72 bits)
// are free symbolic inputs, so each assertion is proved for ALL 2^64 data words /
// ALL 2^72 received words -- not a sample.
//
//   f_clean      decode(encode(d)) is clean and returns d                       forall d
//   f_single     every 1-bit error (each of the 72 stored bits) is corrected: CE,
//                right index and kind, data and stored word restored            forall d, forall bit
//   f_double     every 2-bit error (each of the C(72,2) pairs) is detected: UE, NOT
//                CE, word and data returned unmodified                          forall d, forall pair
//   f_all_safe   decoder verdict over ALL 2^72 received words: exactly one of
//                none/ce/ue; CE flips exactly one bit; UE/NONE never modify the
//                word; UE returns the raw data; ue_inval implies UE
//   f_all_fix    for every bit b: "decoder located b" implies flipping b yields a
//                TRUE codeword (a CE never lands on garbage)                    forall rx
//   f_all_none   NONE implies the received word is a genuine codeword          forall rx
//   f_eq_enc     Project-26 encoder == Project-77 encoder                       forall d
//   f_eq_dec     Project-26 decoder == Project-77 decoder, every output         forall rx
//
// WHY THE CASE SPLIT.  Plain CDCL SAT needs exponential time to prove parity-tree
// identities like chk(d^e) = chk(d)^chk(e) when the error position is symbolic
// (measured: f_single with a symbolic position did not finish in 600 s).  With the
// error position a CONSTANT the two XOR trees are identical except for one inverted
// leaf, Yosys merges every off-path node, and the proof takes seconds.  Splitting
// over all 72 positions / 2556 pairs loses nothing: the cases are exhaustive.
//
// Macros: F_INV (check-bit inversion, default 0), F_I (first bit for f_double jobs),
//         F_B (bit for f_all_fix jobs).
// =============================================================================
`ifndef F_INV
  `define F_INV 0
`endif
`ifndef F_I
  `define F_I 0
`endif
`ifndef F_B
  `define F_B 0
`endif

// ---------------------------------------------------------------- shared decode wrapper
module f_dec_wrap #(parameter int INV = `F_INV) (
  input  wire [71:0] rx,
  output wire [63:0] data, output wire [71:0] cwc,
  output wire none, ce, ue, uei,
  output wire [1:0] kind, output wire [6:0] pos, output wire [7:0] syn
);
  sf_secded_dec #(.K(64), .INV(INV)) u (.cw_i(rx), .data_o(data), .cw_corr_o(cwc), .none_o(none),
    .ce_o(ce), .ue_o(ue), .ue_inval_o(uei), .err_kind_o(kind), .err_pos_o(pos), .syn_o(syn));
endmodule

// ---------------------------------------------------------------- clean words
module f_clean (input wire [63:0] d);
  wire [71:0] cw;
  sf_secded_enc #(.K(64), .INV(`F_INV)) e (.data_i(d), .cw_o(cw));
  wire [63:0] data; wire [71:0] cwc; wire none, ce, ue, uei; wire [1:0] kind; wire [6:0] pos; wire [7:0] syn;
  f_dec_wrap w (.rx(cw), .data(data), .cwc(cwc), .none(none), .ce(ce), .ue(ue), .uei(uei), .kind(kind), .pos(pos), .syn(syn));
  always @* begin
    assert (none && !ce && !ue && !uei);
    assert (data == d);
    assert (cwc == cw);
    assert (syn == 8'd0);
  end
endmodule

// ---------------------------------------------------------------- every single-bit error
module f_single (input wire [63:0] d);
  wire [71:0] cw;
  sf_secded_enc #(.K(64), .INV(`F_INV)) e (.data_i(d), .cw_o(cw));
  genvar b;
  generate for (b = 0; b < 72; b = b + 1) begin : g_b
    wire [71:0] rx = cw ^ (72'd1 << b);
    wire [63:0] data; wire [71:0] cwc; wire none, ce, ue, uei; wire [1:0] kind; wire [6:0] pos; wire [7:0] syn;
    f_dec_wrap w (.rx(rx), .data(data), .cwc(cwc), .none(none), .ce(ce), .ue(ue), .uei(uei), .kind(kind), .pos(pos), .syn(syn));
    always @* begin
      assert (ce && !ue && !none && !uei);
      assert (pos == b);
      assert (kind == ((b < 64) ? 2'd0 : (b < 71) ? 2'd1 : 2'd2));
      assert (data == d);                 // data restored for data-bit AND check-bit errors
      assert (cwc == cw);                 // the whole stored word is restored
    end
  end endgenerate
endmodule

// ---------------------------------------------------------------- every double-bit error (job: first bit F_I)
module f_double (input wire [63:0] d);
  localparam int I = `F_I;
  wire [71:0] cw;
  sf_secded_enc #(.K(64), .INV(`F_INV)) e (.data_i(d), .cw_o(cw));
  genvar j;
  generate for (j = I + 1; j < 72; j = j + 1) begin : g_j
    wire [71:0] rx = cw ^ (72'd1 << I) ^ (72'd1 << j);
    wire [63:0] data; wire [71:0] cwc; wire none, ce, ue, uei; wire [1:0] kind; wire [6:0] pos; wire [7:0] syn;
    f_dec_wrap w (.rx(rx), .data(data), .cwc(cwc), .none(none), .ce(ce), .ue(ue), .uei(uei), .kind(kind), .pos(pos), .syn(syn));
    always @* begin
      assert (ue && !ce && !none);        // detected, never reported as corrected
      assert (!uei);                      // a double error is an even-parity UE, not an invalid syndrome
      assert (cwc == rx);                 // the decoder did not "repair" anything
      assert (data == rx[63:0]);          // the raw stored data is returned (flagged by ue)
    end
  end endgenerate
endmodule

// ---------------------------------------------------------------- decoder verdict, all received words
module f_all_safe (input wire [71:0] rx);
  wire [63:0] data; wire [71:0] cwc; wire none, ce, ue, uei; wire [1:0] kind; wire [6:0] pos; wire [7:0] syn;
  f_dec_wrap w (.rx(rx), .data(data), .cwc(cwc), .none(none), .ce(ce), .ue(ue), .uei(uei), .kind(kind), .pos(pos), .syn(syn));
  wire [71:0] diff = cwc ^ rx;
  wire one_bit = (diff != 72'd0) && ((diff & (diff - 72'd1)) == 72'd0);
  always @* begin
    assert ((none ? 1 : 0) + (ce ? 1 : 0) + (ue ? 1 : 0) == 1);        // exactly one verdict
    assert (!uei || ue);
    assert (!ce || one_bit);            // a correction flips exactly one stored bit
    assert (!ce || (data == cwc[63:0]));
    assert (!ue || (diff == 72'd0));    // an uncorrectable word is never modified ...
    assert (!ue || (data == rx[63:0])); // ... and the raw data is what is returned
    assert (!none || (diff == 72'd0));
    assert (!ce || (diff[pos] == 1'b1));// the reported index is the flipped bit
  end
endmodule

// ---------------------------------------------------------------- CE lands on a codeword (job: bit F_B)
module f_all_fix (input wire [71:0] rx);
  localparam int B = `F_B;
  wire [63:0] data; wire [71:0] cwc; wire none, ce, ue, uei; wire [1:0] kind; wire [6:0] pos; wire [7:0] syn;
  f_dec_wrap w (.rx(rx), .data(data), .cwc(cwc), .none(none), .ce(ce), .ue(ue), .uei(uei), .kind(kind), .pos(pos), .syn(syn));
  wire [71:0] re;                       // encode(data of the corrected word)
  sf_secded_enc #(.K(64), .INV(`F_INV)) e (.data_i(cwc[63:0]), .cw_o(re));
  always @* begin
    // "the decoder corrected stored bit B" => the corrected word is a true codeword
    if (ce && pos == B) assert (re == cwc);
  end
endmodule

// ---------------------------------------------------------------- NONE implies codeword
module f_all_none (input wire [71:0] rx);
  wire [63:0] data; wire [71:0] cwc; wire none, ce, ue, uei; wire [1:0] kind; wire [6:0] pos; wire [7:0] syn;
  f_dec_wrap w (.rx(rx), .data(data), .cwc(cwc), .none(none), .ce(ce), .ue(ue), .uei(uei), .kind(kind), .pos(pos), .syn(syn));
  wire [71:0] re;
  sf_secded_enc #(.K(64), .INV(`F_INV)) e (.data_i(rx[63:0]), .cw_o(re));
  always @* if (none) assert (re == rx);
endmodule

// ---------------------------------------------------------------- equivalence with Project 26
module f_eq_enc (input wire [63:0] d);
  wire [71:0] a, b;
  sf_secded_enc #(.K(64), .INV(`F_INV)) e77 (.data_i(d), .cw_o(a));
  sfras_secded_enc #(.K(64), .INV(`F_INV)) e26 (.data_i(d), .cw_o(b));
  always @* assert (a == b);
endmodule

module f_eq_dec (input wire [71:0] rx);
  wire [63:0] data; wire [71:0] cwc; wire none, ce, ue, uei; wire [1:0] kind; wire [6:0] pos; wire [7:0] syn;
  f_dec_wrap w (.rx(rx), .data(data), .cwc(cwc), .none(none), .ce(ce), .ue(ue), .uei(uei), .kind(kind), .pos(pos), .syn(syn));
  wire [63:0] pdata; wire [71:0] pcwc; wire pnone, pce, pue, puei, pced; wire [6:0] pidx; wire [7:0] psyn;
  sfras_secded_dec #(.K(64), .INV(`F_INV)) d26 (.cw_i(rx), .data_o(pdata), .cw_corr_o(pcwc), .none_o(pnone), .ce_o(pce),
    .ue_o(pue), .ue_inval_o(puei), .ce_data_o(pced), .err_idx_o(pidx), .syn_o(psyn));
  always @* begin
    assert (none == pnone);
    assert (ce == pce);
    assert (ue == pue);
    assert (uei == puei);
    assert (data == pdata);
    assert (cwc == pcwc);
    assert (syn == psyn);
    assert (!ce || (pos == pidx));
    assert (!ce || ((kind == 2'd0) == pced));
  end
endmodule
