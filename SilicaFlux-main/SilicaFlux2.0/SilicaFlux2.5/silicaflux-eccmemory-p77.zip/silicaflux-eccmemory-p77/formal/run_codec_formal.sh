#!/usr/bin/env bash
# Formal proofs of the 64/72 codec with Yosys' built-in SAT (`sat -prove-asserts`).
#   formal/run_codec_formal.sh [JOBS]        (from the project root; default 3 parallel jobs)
# Writes reports/formal_codec.log (one line per proof) and reports/formal_codec.md (summary).
# Every proof prints the number of $assert cells it contains, so an empty (vacuous) proof is visible.
set -u
cd "$(dirname "$0")/.."
JOBS=${1:-3}
OUT=reports/formal_codec.log
mkdir -p reports sim/formal
: > "$OUT"

prove() {   # prove TOP INV [EXTRA_DEFINES]
  local top=$1 inv=$2 extra=${3:-}
  local t0=$(date +%s)
  local log
  log=$(yosys -p "read_verilog -sv -formal -DF_INV=$inv $extra -Irtl -Ithird_party/sfras_ref formal/codec_formal.sv rtl/sf_secded_enc.sv rtl/sf_secded_dec.sv third_party/sfras_ref/sfras_secded_enc.sv third_party/sfras_ref/sfras_secded_dec.sv; prep -top $top; flatten; opt -full; tee -o /dev/stdout stat; sat -verify -prove-asserts -set-assumes -timeout 1500" 2>&1)
  local t1=$(date +%s)
  local n
  n=$(echo "$log" | grep -E '^\s+\$assert' | tail -1 | awk '{print $NF}')
  if echo "$log" | grep -q 'no model found: SUCCESS'; then res=PROVED; else res=FAILED; fi
  printf '%s %s inv=%s %s asserts=%s time=%ss\n' "$res" "$top" "$inv" "$extra" "${n:-0}" "$((t1-t0))"
}
export -f prove

jobs_list() {
  for inv in 0 3; do
    echo "f_clean $inv"
    echo "f_all_safe $inv"
    echo "f_all_none $inv"
    echo "f_eq_enc $inv"
    echo "f_eq_dec $inv"
    echo "f_single $inv"
    for b in $(seq 0 71); do echo "f_all_fix $inv -DF_B=$b"; done
    for i in $(seq 0 70); do echo "f_double $inv -DF_I=$i"; done
  done
}

# longest jobs first for a balanced schedule
jobs_list | awk '{ w = ($1=="f_double") ? 100-$3+0 : 0; print }' > sim/formal/jobs.txt
jobs_list | xargs -P "$JOBS" -L 1 bash -c 'prove $0 $@' >> "$OUT" 2>&1

total=$(wc -l < "$OUT"); ok=$(grep -c '^PROVED' "$OUT"); bad=$(grep -c '^FAILED' "$OUT")
{
  echo "# Codec formal proofs (Yosys 0.33 SAT)"
  echo
  echo "$ok / $total proof obligations PROVED, $bad FAILED."
  echo
  echo "| top | INV | jobs | all proved | asserts (sum) | CPU seconds (sum) |"
  echo "|---|---|---|---|---|---|"
  for inv in 0 3; do
    for top in f_clean f_all_safe f_all_none f_eq_enc f_eq_dec f_single f_all_fix f_double; do
      awk -v t="$top" -v i="inv=$inv" '$2==t && $3==i { n++; if ($1=="PROVED") p++; split($0,a,"asserts="); split(a[2],b," "); s+=b[1]; split($0,c,"time="); gsub("s","",c[2]); tm+=c[2] } END { if (n>0) printf "| %s | %s | %d | %s | %d | %d |\n", t, i, n, (p==n?"yes":"**NO**"), s, tm }' "$OUT"
    done
  done
} > reports/formal_codec.md
cat reports/formal_codec.md
[ "$bad" -eq 0 ] && [ "$total" -gt 0 ] && echo FORMAL_CODEC_PASS || { echo FORMAL_CODEC_FAIL; exit 1; }
