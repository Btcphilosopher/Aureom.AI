// =============================================================================
// SilicaFlux Project 77 :: formal/wrapper_formal.sv
// Bounded-model-check harness for the ECC SRAM wrapper (Yosys `sat -seq N`).
// Every input is free in every cycle.  The raw MBIST port is free too, so the solver can
// place ARBITRARY stored words (clean, single-error, double-error, garbage) in the array.
//
// Properties checked at every step of every run:
//   * the RTL's own assertion block (rtl/sf_sram_ecc.sv, `SF_ASSERT`, built with -DFORMAL -DSF_ECC_ASSERT):
//       response FIFO never overflows; credits <= RSP_DEPTH; no two response pushes in one cycle;
//       NO access is accepted while the bank is locked; RMW / scrub-FIX ATOMICITY (while locked,
//       only the write-back itself may load the issue stage); init never overlaps a lock; no access
//       accepted during init or while the MBIST port is granted; MBIST grant only on an idle pipeline;
//       at most one RAS event kind per event; rsp_ue implies rsp_err; a corrected response is never an error
//   * f_wrap shadow checks on the PORTS only (independent of RTL internals):
//       B1 a response never appears without a request: accepted - consumed >= 0, and <= RSP_DEPTH
//       B2 a stalled response stays valid and unchanged
//       B3 the functional port is not ready while the MBIST port is granted
//       B4 after a reset cycle: no response, no lock, no fatal request, RAS counters zero
// Cover goals (FW_COVER=n) are run expecting a COUNTER-EXAMPLE, proving the interesting states are reachable
// (i.e. the checks above are not vacuously true).
// Configuration macros: FW_DEC_PIPE FW_RD_LAT FW_SCRUB FW_FI FW_INIT FW_REINIT FW_COVER
// =============================================================================
`ifndef FW_DEC_PIPE
  `define FW_DEC_PIPE 0
`endif
`ifndef FW_RD_LAT
  `define FW_RD_LAT 1
`endif
`ifndef FW_SCRUB
  `define FW_SCRUB 0
`endif
`ifndef FW_FI
  `define FW_FI 0
`endif
`ifndef FW_COVER
  `define FW_COVER 0
`endif
`ifndef FW_INIT
  `define FW_INIT 1
`endif
`ifndef FW_REINIT
  `define FW_REINIT 1
`endif

module f_wrap (
  input wire clk, input wire rst_n,
  input wire req_valid, input wire req_we, input wire [1:0] req_addr, input wire [15:0] req_wdata, input wire [1:0] req_be, input wire [0:0] req_id,
  input wire rsp_ready,
  input wire xscr_req_valid, input wire [1:0] xscr_req_op, input wire [1:0] xscr_req_addr, input wire [5:0] xscr_req_syn,
  input wire scrub_en_i, input wire [15:0] scrub_interval_i, input wire scrub_fix_en_i, input wire scrub_ue_halt_i, input wire scrub_resume_i,
  input wire init_start_i,
  input wire tst_req_i, input wire tst_en_i, input wire tst_we_i, input wire [1:0] tst_addr_i, input wire [21:0] tst_wdata_i,
  input wire fi_auth_i, input wire fi_enable_i, input wire fi_cmd_valid_i, input wire [1:0] fi_cmd_mode_i,
  input wire [21:0] fi_cmd_mask_i, input wire [21:0] fi_cmd_val_i, input wire [1:0] fi_cmd_addr_i, input wire fi_cmd_addr_en_i, input wire fi_clear_i,
  input wire ras_reg_sel_i, input wire ras_reg_we_i, input wire [7:0] ras_reg_addr_i, input wire [31:0] ras_reg_wdata_i
);
  // ---- reset: forced low for the first two cycles, free afterwards (reset may hit any in-flight operation)
  reg [2:0] cyc = 3'd0;
  always @(posedge clk) if (cyc != 3'd7) cyc <= cyc + 3'd1;
  always @* if (cyc < 3'd2) assume (!rst_n);
  // keep the scrub interval small so scrub states are reachable within the bound
  always @* assume (scrub_interval_i <= 16'd2);

  wire req_ready, rsp_valid, rsp_err, rsp_ue, rsp_ce, rsp_we;
  wire [15:0] rsp_rdata; wire [0:0] rsp_id;
  wire xscr_req_ready, xscr_rsp_valid, xscr_rsp_ce, xscr_rsp_ue; wire [1:0] xscr_rsp_op; wire [5:0] xscr_rsp_syn; wire [1:0] xscr_rsp_addr;
  wire scrub_busy_o, scrub_halted_o, scrub_pass_o; wire [1:0] scrub_addr_o, scrub_ue_addr_o;
  wire [31:0] scrub_words_o, scrub_ce_found_o, scrub_ue_found_o, scrub_fixed_o, scrub_persistent_o, scrub_passes_o;
  wire init_busy_o, quiet_o, lock_o, tst_grant_o; wire [21:0] tst_rdata_o;
  wire fi_armed_o, fi_stuck_o, fi_fired_o, fi_blocked_o, fi_busy_o; wire [15:0] fi_blocked_cnt_o;
  wire ev_valid_o, ev_ce_o, ev_ue_o, ev_persist_o; wire [1:0] ev_src_o; wire [1:0] ev_addr_o; wire [5:0] ev_syn_o; wire [4:0] ev_pos_o;
  wire [31:0] ras_reg_rdata_o; wire ras_reg_err_o;
  wire [31:0] ce_count_o, ue_count_o, persist_count_o; wire [1:0] last_addr_o; wire [5:0] last_syn_o;
  wire ce_seen_o, ue_seen_o, irq_warn_o, irq_ue_o, fatal_req_o;

  sf_sram_ecc_sys #(
    .K(16), .DEPTH(4), .RD_LAT(`FW_RD_LAT), .DEC_PIPE(`FW_DEC_PIPE), .RSP_DEPTH(4), .ID_W(1), .CHK_INV(3),
    .UE_DATA_ZERO(0), .INIT_ON_RESET(`FW_INIT), .REINIT_AFTER_TEST(`FW_REINIT), .TEST_EN(1), .SCRUB_EN(`FW_SCRUB),
    .SCRUB_MAX_WAIT(2), .FI_EN(`FW_FI), .RAM_INIT_ZERO(0)
  ) dut (.*);

  // ---------------------------------------------------------------- B1: conservation of responses
  reg [5:0] acc_cnt = 6'd0, pop_cnt = 6'd0;
  always @(posedge clk) begin
    if (!rst_n) begin acc_cnt <= 6'd0; pop_cnt <= 6'd0; end
    else begin
      if (req_valid && req_ready) acc_cnt <= acc_cnt + 6'd1;
      if (rsp_valid && rsp_ready) pop_cnt <= pop_cnt + 6'd1;
    end
  end
  always @* if (rst_n) begin
    assert (pop_cnt <= acc_cnt);                                   // no response without a request
    assert ((acc_cnt - pop_cnt) <= 6'd4);                          // never more outstanding than RSP_DEPTH
  end

  // ---------------------------------------------------------------- B2 / B4: need the previous cycle
  reg        past_valid = 1'b0;
  reg        p_stall = 1'b0, p_rst_n = 1'b1;
  reg [15:0] p_data = 16'd0; reg p_err = 1'b0, p_ue = 1'b0, p_ce = 1'b0, p_we = 1'b0; reg [0:0] p_id = 1'b0;
  always @(posedge clk) begin
    past_valid <= 1'b1;
    p_rst_n <= rst_n;
    p_stall <= rsp_valid && !rsp_ready;
    p_data <= rsp_rdata; p_err <= rsp_err; p_ue <= rsp_ue; p_ce <= rsp_ce; p_we <= rsp_we; p_id <= rsp_id;
  end
  always @* if (past_valid && p_rst_n && rst_n && p_stall) begin
    assert (rsp_valid);                                            // a stalled response is not withdrawn ...
    assert (rsp_rdata == p_data && rsp_err == p_err && rsp_ue == p_ue && rsp_ce == p_ce && rsp_we == p_we && rsp_id == p_id);   // ... or changed
  end
  always @* if (past_valid && !p_rst_n) begin
    assert (!rsp_valid);                                           // B4: nothing survives a reset
    assert (!lock_o);
    assert (!fatal_req_o);
    assert (ce_count_o == 32'd0 && ue_count_o == 32'd0 && persist_count_o == 32'd0);
  end
  always @* if (rst_n) begin
    if (tst_grant_o) assert (!req_ready);                          // B3
  end

  // ---------------------------------------------------------------- cover goals (expect a counter-example)
  always @* if (rst_n) begin
    if (`FW_COVER == 1) assert (!lock_o);                          // an RMW / scrub FIX can lock the bank
    if (`FW_COVER == 2) assert (!(rsp_valid && rsp_ce));           // a corrected read is reachable
    if (`FW_COVER == 3) assert (!(rsp_valid && rsp_ue && !rsp_we));// an uncorrectable read is reachable
    if (`FW_COVER == 4) assert (!(rsp_valid && rsp_we && rsp_ue)); // an aborted RMW is reachable
    if (`FW_COVER == 5) assert (!ev_valid_o);                      // a RAS event is reachable
    if (`FW_COVER == 6) assert (!tst_grant_o);                     // the MBIST grant is reachable
    if (`FW_COVER == 7) assert (!(rsp_valid && rsp_we && !rsp_err));// a write acknowledge is reachable
    if (`FW_COVER == 8) assert (!(acc_cnt - pop_cnt == 6'd4));     // response credits can be exhausted
    if (`FW_COVER == 9) assert (!fatal_req_o);                     // a fatal request is reachable
    if (`FW_COVER == 10) assert (!(rsp_valid && rsp_we && rsp_ce));// an RMW completing on a corrected word (write-back path) is reachable
    if (`FW_COVER == 11) assert (!scrub_busy_o);                   // the internal scrub engine runs
    if (`FW_COVER == 12) assert (!init_busy_o);                    // the init engine runs
    if (`FW_COVER == 13) assert (!fi_fired_o);                     // an injection fires
  end
endmodule
