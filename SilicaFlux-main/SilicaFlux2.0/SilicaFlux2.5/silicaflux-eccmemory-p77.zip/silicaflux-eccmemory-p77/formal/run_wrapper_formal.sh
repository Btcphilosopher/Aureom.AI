#!/usr/bin/env bash
# Bounded model checking of the ECC wrapper with Yosys' built-in SAT (sat -seq N), plus reachability (cover) runs.
#   formal/run_wrapper_formal.sh                  (from the project root)
# A cover run is EXPECTED to find a counter-example ("model found: FAIL!"): that is the witness that the state is reachable,
# i.e. the assertion proofs are not vacuous.  Results: reports/formal_wrapper.md
set -u
cd "$(dirname "$0")/.."
OUT=reports/formal_wrapper.md
RTLF="rtl/sf_sram_ecc_sys.sv rtl/sf_sram_ecc.sv rtl/sf_sram_ecc_ram.sv rtl/sf_sram_ecc_fi.sv rtl/sf_sram_ecc_ras.sv rtl/sf_sram_ecc_scrub.sv rtl/sf_secded_enc.sv rtl/sf_secded_dec.sv"
mkdir -p reports

fw() {   # fw DEPTH DEFINES...  -> prints PROVED | WITNESS | TIMEOUT
  local d=$1; shift
  local o
  o=$(timeout 3000 yosys -p "read_verilog -sv -formal -DFORMAL -DSF_ECC_ASSERT $* -Irtl formal/wrapper_formal.sv $RTLF; prep -top f_wrap; flatten; memory_map; opt -fast; sat -seq $d -set-init-zero -prove-asserts -set-assumes -timeout 2800" 2>&1)
  if   echo "$o" | grep -q 'no model found: SUCCESS'; then echo PROVED
  elif echo "$o" | grep -q 'model found: FAIL';        then echo WITNESS
  else echo TIMEOUT; fi
}

{
echo "# Wrapper formal results (Yosys 0.33, bounded model checking)"
echo
echo "Harness: \`formal/wrapper_formal.sv\` (K=16, 4 words, two byte lanes so that partial writes / RMW exist; every input free in every cycle,"
echo "including the raw MBIST port so the solver can place arbitrary stored words in the array; reset forced low for cycles 0-1, free afterwards)."
echo "Properties: the RTL assertion block (\`SF_ASSERT\`, atomicity / no-accept-while-locked / FIFO bounds / one event kind / ...) plus port-level shadow checks (B1-B4)."
echo "**These are BOUNDED proofs (no violation exists within the stated number of cycles), not unbounded proofs.**"
echo
echo "| config | description | depth | assertions | result |"
echo "|---|---|---|---|---|"
} > "$OUT"

declare -A CFG
declare -A DESC
CFG[F1]="-DFW_DEC_PIPE=0 -DFW_RD_LAT=1 -DFW_SCRUB=0 -DFW_FI=0 -DFW_INIT=0 -DFW_REINIT=0"
CFG[F2]="-DFW_DEC_PIPE=1 -DFW_RD_LAT=2 -DFW_SCRUB=1 -DFW_FI=1 -DFW_INIT=0 -DFW_REINIT=1"
DESC[F1]="LAT=1, external scrub master, FI off"
DESC[F2]="LAT=3 (RD_LAT=2 + DEC_PIPE), internal scrub engine, FI on, re-init after MBIST"

ALL_OK=1
for cfg in F1 F2; do
  depth=20; [ $cfg = F2 ] && depth=16
  r=$(fw $depth ${CFG[$cfg]} -DFW_COVER=0)
  echo "| $cfg | ${DESC[$cfg]} | $depth | all | **$r** |" >> "$OUT"
  [ "$r" = PROVED ] || ALL_OK=0
done
{
echo
echo "## Reachability (cover) runs -- each must produce a witness (counter-example to the negated goal)"
echo
echo "| config | goal | depth | result |"
echo "|---|---|---|---|"
} >> "$OUT"
declare -A GOAL
GOAL[1]="bank locked (RMW / scrub FIX)"; GOAL[2]="corrected read returned"; GOAL[3]="uncorrectable read returned"
GOAL[4]="RMW aborted on an uncorrectable word"; GOAL[5]="RAS event raised"; GOAL[6]="MBIST port granted"; GOAL[7]="write acknowledged"
GOAL[8]="response credits exhausted"; GOAL[9]="fatal request raised"; GOAL[10]="RMW completes on a corrected word (write-back path)"
GOAL[11]="scrub engine busy"; GOAL[12]="init engine busy"; GOAL[13]="fault injection fires"
for c in 1 2 3 4 5 6 7 8 9 10; do
  r=$(fw 20 ${CFG[F1]} -DFW_COVER=$c); echo "| F1 | ${GOAL[$c]} | 20 | **$r** |" >> "$OUT"
  [ "$r" = WITNESS ] || ALL_OK=0
done
for c in 1 6 10 11 12 13; do
  r=$(fw 20 ${CFG[F2]} -DFW_COVER=$c); echo "| F2 | ${GOAL[$c]} | 20 | **$r** |" >> "$OUT"
  [ "$r" = WITNESS ] || ALL_OK=0
done
cat "$OUT"
[ $ALL_OK -eq 1 ] && echo FORMAL_WRAPPER_PASS || { echo FORMAL_WRAPPER_FAIL; exit 1; }
