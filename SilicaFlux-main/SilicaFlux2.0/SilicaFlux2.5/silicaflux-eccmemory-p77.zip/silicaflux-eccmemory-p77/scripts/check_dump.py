#!/usr/bin/env python3
"""Independent check of the RAW words the ECC wrapper stored in the macro.

  python3 -I scripts/check_dump.py sim/mem_dump.txt K INV

For every dumped word (phase addr expected_data raw_word error_mask):
    raw ^ error_mask  must equal  Reference.encode(expected_data)
using the three independent software constructions (RefA/RefB/RefC) of model/secded_model.py.
(`error_mask` is the testbench's record of the bit flips it injected into that word; for clean words it is 0,
 so the stored check bits and overall parity are verified bit-exactly against the software ECC reference.)
Also confirms that the reference DECODER recovers the expected data from the raw word whenever at most one bit is flipped.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "model"))
import secded_model as M  # noqa: E402


def main():
    fn, k, inv = sys.argv[1], int(sys.argv[2]), int(sys.argv[3], 0)
    refs = (M.RefA(k, inv), M.RefB(k, inv), M.RefC(k, inv))
    n = refs[0].n
    total = bad = clean = latent = 0
    per_phase = {}
    with open(fn) as f:
        for line in f:
            tag, a, d, raw, mask = line.split()
            d, raw, mask = int(d, 16), int(raw, 16), int(mask, 16)
            total += 1
            per_phase[tag] = per_phase.get(tag, 0) + 1
            codeword = raw ^ mask
            for r in refs:
                if r.encode(d) != codeword:
                    bad += 1
                    print(f"MISMATCH {tag} addr {a}: raw={raw:x} mask={mask:x} stored codeword={codeword:x} "
                          f"{type(r).__name__}.encode({d:x})={r.encode(d):x}")
                    break
            w = bin(mask).count("1")
            if w == 0:
                clean += 1
            else:
                latent += 1
            if w <= 1:
                res = refs[0].decode(raw)
                assert res.cls in (M.NONE, M.CE) and res.data == d, f"reference decoder cannot recover addr {a} ({tag})"
    print(f"{os.path.basename(fn)}: K={k} INV=0x{inv:x}  {total} stored words checked against the software reference "
          f"({clean} clean, {latent} with latent injected errors) in {len(per_phase)} checkpoints "
          f"{dict(sorted(per_phase.items()))}: {'PASS' if bad == 0 else 'FAIL (%d)' % bad}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
