#!/usr/bin/env bash
# Codec regression: every configuration on Icarus Verilog AND Verilator.
#   scripts/run_codec.sh            (from the project root)
# Expected values come from the Python reference vectors in vectors/ (model/verify_math.py).
set -u
cd "$(dirname "$0")/.."
mkdir -p sim reports
LOG=reports/codec_sim.log
: > "$LOG"
RTL="rtl/sf_secded_enc.sv rtl/sf_secded_dec.sv rtl/sf_secded_enc_pipe.sv"
P26="third_party/sfras_ref/sfras_secded_enc.sv third_party/sfras_ref/sfras_secded_dec.sv"
fail=0
# K INV vec-dir tag
CONFIGS="64 0 vectors inv0
64 3 vectors invd
8 0 vectors/k8 inv0
16 0 vectors/k16 inv0
32 0 vectors/k32 inv0
128 0 vectors/k128 inv0"

echo "$CONFIGS" | while read -r K INV VEC TAG; do
  name="k${K}_inv${INV}"
  # ---------------- Icarus Verilog
  iverilog -g2012 -DTB_K=$K -DTB_INV=$INV -DTB_P26 -I rtl -I third_party/sfras_ref \
      -o sim/codec_${name}_iv tb/tb_secded_codec.sv $RTL $P26 2>>"$LOG" || { echo "FAIL build icarus $name" | tee -a "$LOG"; exit 1; }
  out=$(vvp -n sim/codec_${name}_iv +VEC=$VEC +TAG=$TAG 2>&1)
  echo "$out" | grep -E 'RESULT|TB_PASS|TB_FAIL|MISMATCH' | sed "s/^/[icarus   $name] /" | tee -a "$LOG"
  echo "$out" | grep -q TB_PASS || { echo "[icarus $name] FAILED" | tee -a "$LOG"; exit 1; }
  # ---------------- Verilator (with the RTL assertions enabled)
  rm -rf sim/vl_codec_${name}
  verilator --binary --timing --assert -Wno-fatal -Wno-WIDTH -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-DECLFILENAME \
      -DTB_K=$K -DTB_INV=$INV -DTB_P26 -DSF_SECDED_ASSERT -Irtl -Ithird_party/sfras_ref \
      --top-module tb_secded_codec -Mdir sim/vl_codec_${name} -o vtb \
      tb/tb_secded_codec.sv $RTL $P26 >>"$LOG" 2>&1 || { echo "FAIL build verilator $name" | tee -a "$LOG"; exit 1; }
  out=$(sim/vl_codec_${name}/vtb +VEC=$VEC +TAG=$TAG 2>&1)
  echo "$out" | grep -E 'RESULT|TB_PASS|TB_FAIL|MISMATCH|Assertion|%Error' | sed "s/^/[verilator $name] /" | tee -a "$LOG"
  echo "$out" | grep -q TB_PASS || { echo "[verilator $name] FAILED" | tee -a "$LOG"; exit 1; }
done
rc=$?
if [ $rc -eq 0 ]; then echo "CODEC_REGRESSION_PASS" | tee -a "$LOG"; else echo "CODEC_REGRESSION_FAIL" | tee -a "$LOG"; fi
exit $rc
