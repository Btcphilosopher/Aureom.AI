#!/usr/bin/env python3
"""Mutation testing of the ECC wrapper testbench (Icarus Verilog).

Each mutant is ONE deliberate RTL defect (exact string replacement; the script asserts the pattern occurs exactly
once).  A mutant is KILLED when the testbench reports a failure, aborts, or fails to build/finish; it SURVIVES when the
testbench still prints TB_PASS -- a testbench gap that is reported, never hidden.

  python3 -I scripts/run_mutation.py [-j 2]        (from the project root)

Writes reports/mutation.md and reports/mutation.json.
"""
import argparse
import concurrent.futures
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL_FILES = ["sf_sram_ecc_sys.sv", "sf_sram_ecc.sv", "sf_sram_ecc_ram.sv", "sf_sram_ecc_fi.sv", "sf_sram_ecc_ras.sv",
             "sf_sram_ecc_scrub.sv", "sf_secded_enc.sv", "sf_secded_dec.sv", "sf_secded_defs.svh", "sf_secded_funcs.svh",
             "sf_secded_enc_pipe.sv"]

# testbench configurations a mutant is run against (all must be compiled with the same defines the regression uses)
CFG = {
    "c1": "-DTB_FI=1 -DTB_SCRUB=0 -DTB_RDLAT=1 -DTB_DECPIPE=0 -DTB_DEPTH=48 -DTB_RSPD=8",
    "c2": "-DTB_FI=1 -DTB_SCRUB=1 -DTB_RDLAT=2 -DTB_DECPIPE=1 -DTB_DEPTH=48 -DTB_RSPD=8",
    "c3": "-DTB_FI=0 -DTB_SCRUB=0 -DTB_RDLAT=3 -DTB_DECPIPE=0 -DTB_DEPTH=32 -DTB_RSPD=6 -DTB_INIT=0 -DTB_UEZ=1 -DTB_MAXWAIT=0",
}

# (id, config, file, defect, old, new)
M = [
 ("M01", "c1", "sf_sram_ecc.sv", "RMW merges the UNCORRECTED old data (error baked into the re-encoded word)",
  "wire [K-1:0] merged = (dec_data & ~bmask) | (lk_wdata_q & bmask);", "wire [K-1:0] merged = (raw_dec[K-1:0] & ~bmask) | (lk_wdata_q & bmask);"),
 ("M02", "c1", "sf_sram_ecc.sv", "no bank lock during RMW / scrub FIX",
  "wire lock       = (lk_st_q != LK_IDLE);", "wire lock       = 1'b0;"),
 ("M03", "c1", "sf_sram_ecc.sv", "RMW onto an UNCORRECTABLE old word is not aborted (merged word written)",
  "wire wb_needed = (res_op == OP_RMW) ? !dec_ue : dec_ce;", "wire wb_needed = (res_op == OP_RMW) ? 1'b1 : dec_ce;"),
 ("M04", "c1", "sf_sram_ecc.sv", "uncorrectable read answered without error flags",
  "else         push_d = {rd_data, dec_ue, dec_ue, dec_ce, 1'b0, res_id};", "else         push_d = {rd_data, 1'b0, 1'b0, dec_ce, 1'b0, res_id};"),
 ("M05", "c1", "sf_sram_ecc.sv", "corrected errors never reported to RAS",
  "wire ev_ce_n   = res_real && dec_ce && !ver_ce && !sfix_dup;", "wire ev_ce_n   = 1'b0;"),
 ("M06", "c1", "sf_sram_ecc.sv", "scrub FIX re-reports the correction CHECK already reported (double counting)",
  "wire sfix_dup  = (res_op == OP_SFIX) && (dec_syn == lk_expsyn_q);", "wire sfix_dup  = 1'b0;"),
 ("M07", "c1", "sf_sram_ecc.sv", "a post-repair VERIFY that still sees an error is counted as a new CE, not PERSIST",
  "wire ver_ce    = (res_op == OP_SRD) && res_ver && dec_ce;", "wire ver_ce    = 1'b0;"),
 ("M08", "c1", "sf_sram_ecc.sv", "response credit off by one (FIFO can overflow under backpressure)",
  "wire credit_ok  = (used_q < CW'(RSP_DEPTH));", "wire credit_ok  = (used_q <= CW'(RSP_DEPTH));"),
 ("M09", "c2", "sf_sram_ecc.sv", "DEC_PIPE register bypassed (decoder samples the macro one cycle early)",
  "assign raw_sel = (DEC_PIPE != 0) ? raw_q : m_rdata;", "assign raw_sel = m_rdata;"),
 ("M10", "c1", "sf_sram_ecc.sv", "array not re-initialised after the MBIST raw port is released",
  "tst_rel_q   <= (REINIT_AFTER_TEST != 0);", "tst_rel_q   <= 1'b0;"),
 ("M11", "c1", "sf_sram_ecc.sv", "RMW write-back encoder drops the check-bit inversion",
  "sf_secded_enc #(.K(K), .INV(CHK_INV)) u_enc_wb   (.data_i(rmw_data_q), .cw_o(enc_wb));", "sf_secded_enc #(.K(K), .INV(0)) u_enc_wb   (.data_i(rmw_data_q), .cw_o(enc_wb));"),
 ("M12", "c1", "sf_sram_ecc.sv", "out-of-range address check removed",
  "wire f_inr  = ({1'b0, req_addr} < (AW+1)'(DEPTH));", "wire f_inr  = 1'b1;"),
 ("M13", "c1", "sf_sram_ecc_fi.sv", "fault injection ignores the hardware authorisation input",
  "wire cmd_ok = auth_i && enable_i;", "wire cmd_ok = enable_i;"),
 ("M14", "c1", "sf_sram_ecc_ras.sv", "CE counter advances by two per event",
  "if (ce_cnt_q == CNT_MAX) st_sat_q <= 1'b1; else ce_cnt_q <= ce_next;", "if (ce_cnt_q == CNT_MAX) st_sat_q <= 1'b1; else ce_cnt_q <= ce_next + (CNT_W)'(1);"),
 ("M15", "c1", "sf_sram_ecc_ras.sv", "scrub-found UE treated like a demand UE (fatal by default)",
  "if (from_scrub ? scr_ue_fatal_en_q : ue_fatal_en_q) st_fatal_q <= 1'b1;", "if (ue_fatal_en_q) st_fatal_q <= 1'b1;"),
 ("M16", "c1", "sf_sram_ecc.sv", "RMW write-back never committed (lock released without writing)",
  "            lk_st_q    <= LK_WB;\n            rmw_data_q <= merged;", "            lk_st_q    <= LK_IDLE;\n            rmw_data_q <= merged;"),
 ("M17", "c1", "sf_sram_ecc.sv", "init engine skips the last word",
  "if (init_addr_q == AW'(DEPTH - 1)) init_st_q <= IN_IDLE;", "if (init_addr_q == AW'(DEPTH - 2)) init_st_q <= IN_IDLE;"),
 ("M18", "c2", "sf_sram_ecc_scrub.sv", "scrub engine does not VERIFY after a FIX (persistent faults go unnoticed)",
  "                op_q <= OP_VERIFY; st_q <= S_REQ;", "                fixed_q <= sat_inc(fixed_q); st_q <= S_NEXT;"),
 ("M19", "c2", "sf_sram_ecc_scrub.sv", "scrub engine ignores the UE halt policy",
  "                ue_q <= sat_inc(ue_q); ue_addr_q <= addr_q;\n                st_q <= ue_halt_i ? S_HALT : S_NEXT;\n              end else if (rsp_ce_i) begin\n                ce_q <= sat_inc(ce_q);",
  "                ue_q <= sat_inc(ue_q); ue_addr_q <= addr_q;\n                st_q <= S_NEXT;\n              end else if (rsp_ce_i) begin\n                ce_q <= sat_inc(ce_q);"),
 ("M20", "c1", "sf_sram_ecc.sv", "byte-enable lane order reversed in the RMW merge",
  "bmask[8*i +: 8] = {8{lk_be_q[i]}};", "bmask[8*i +: 8] = {8{lk_be_q[BE_W-1-i]}};"),
 ("M21", "c1", "sf_secded_dec.sv", "decoder does not classify an overall-parity-bit error as correctable",
  "assign ce_o       = pe && (s_zero || s_valid);", "assign ce_o       = pe && s_valid && !s_zero;"),
 ("M22", "c1", "sf_secded_enc.sv", "encoder overall parity of the wrong sense",
  "wire par = (^data_i) ^ (^chk);", "wire par = ~((^data_i) ^ (^chk));"),
 ("M23", "c1", "sf_sram_ecc.sv", "RAS event syndrome loses the overall-parity bit",
  "ev_syn_q  <= dec_syn;", "ev_syn_q  <= {1'b0, dec_syn[R-1:0]};"),
 ("M24", "c3", "sf_sram_ecc.sv", "response FIFO write pointer does not wrap at a non-power-of-two depth",
  "wp_q <= (wp_q == PW'(RSP_DEPTH - 1)) ? '0 : wp_q + (PW)'(1);", "wp_q <= wp_q + (PW)'(1);"),
 ("M25", "c1", "sf_sram_ecc.sv", "functional port stays ready while the MBIST raw port is granted",
  "wire quiet_blk  = (init_st_q != IN_IDLE) || tst_blk || tst_rel_q;", "wire quiet_blk  = (init_st_q != IN_IDLE) || tst_rel_q;"),
 ("M26", "c1", "sf_sram_ecc_ras.sv", "UE fatal policy defaults to off",
  "ce_irq_en_q <= 1'b0; ue_irq_en_q <= 1'b0; ue_fatal_en_q <= 1'b1;", "ce_irq_en_q <= 1'b0; ue_irq_en_q <= 1'b0; ue_fatal_en_q <= 1'b0;"),
 ("M27", "c3", "sf_sram_ecc.sv", "UE_DATA_ZERO ignored (uncorrected data returned when zeros are configured)",
  "wire [K-1:0]   rd_data = (dec_ue && (UE_DATA_ZERO != 0)) ? '0 : dec_data;", "wire [K-1:0]   rd_data = dec_data;"),
 ("M28", "c1", "sf_sram_ecc.sv", "scrub FIX is not locked (no write-back at all)",
  "|| (acc_s && (scr_op == SC_FIX));", "|| 1'b0;"),
 ("M29", "c3", "sf_sram_ecc.sv", "reset leaves the bank lock state untouched",
  "      lk_st_q <= LK_IDLE; done_push_q <= 1'b0;\n      lk_addr_q <= '0;", "      done_push_q <= 1'b0;\n      lk_addr_q <= '0;"),
 ("M30", "c1", "sf_sram_ecc_fi.sv", "stuck-at fault applies to every address, ignoring the programmed address",
  "if (stuck_q && (!saddr_en_q || (res_addr_i == saddr_q)))", "if (stuck_q)"),
 ("M31", "c1", "sf_sram_ecc.sv", "write-back loaded over a concurrent functional accept (lock released one cycle early)",
  "  wire can_s      = !lock && !quiet_blk;", "  wire can_s      = (!lock || lk_st_q == LK_WB) && !quiet_blk;"),
 ("M33", "c3", "sf_sram_ecc.sv", "starvation guard not gated by a pending scrub request (SCRUB_MAX_WAIT = 0 blocks the functional port forever)",
  "wire scr_force  = scr_v && (scr_wait_q >= 16'(SCRUB_MAX_WAIT));", "wire scr_force  = (scr_wait_q >= 16'(SCRUB_MAX_WAIT));"),
 ("M32", "c1", "sf_sram_ecc.sv", "scrub request arbitration: scrub always wins over functional traffic",
  "wire               acc_s   = scr_v && can_s && !acc_f;", "wire               acc_s   = scr_v && can_s;"),
]


def run(cmd, cwd, timeout):
    """Run a shell command in its own process group; on timeout kill the WHOLE group (a hung simulator must not leak)."""
    import signal
    p = subprocess.Popen(cmd, cwd=cwd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, start_new_session=True)
    try:
        out, _ = p.communicate(timeout=timeout)
        return p.returncode, out
    except subprocess.TimeoutExpired:
        os.killpg(os.getpgid(p.pid), signal.SIGKILL)
        try:
            out, _ = p.communicate(timeout=10)
        except Exception:
            out = ""
        return 124, "TIMEOUT\n" + (out or "")


def one(m, workdir):
    mid, cfg, fname, desc, old, new = m
    d = os.path.join(workdir, mid)
    if os.path.isdir(d):
        shutil.rmtree(d)
    os.makedirs(os.path.join(d, "rtl"))
    for f in RTL_FILES:
        shutil.copy(os.path.join(ROOT, "rtl", f), os.path.join(d, "rtl", f))
    path = os.path.join(d, "rtl", fname)
    src = open(path).read()
    if src.count(old) != 1:
        return mid, "ERROR", f"pattern occurs {src.count(old)}x in {fname}", desc, cfg
    open(path, "w").write(src.replace(old, new))
    rtl = " ".join(os.path.join(d, "rtl", f) for f in RTL_FILES if f.endswith(".sv") and f != "sf_secded_enc_pipe.sv")
    exe = os.path.join(d, "sim.vvp")
    rc, out = run(f"iverilog -g2012 {CFG[cfg]} -I{d}/rtl -s tb_sf_sram_ecc -o {exe} tb/tb_sf_sram_ecc.sv {rtl}", ROOT, 300)
    if rc != 0:
        return mid, "KILLED", "build error", desc, cfg
    rc, out = run(f"stdbuf -oL -eL vvp -n {exe} +VEC=vectors +DUMP={d}/dump.txt", ROOT, 150)   # line-buffered: a hung run must still show the checks that fired
    if "TB_PASS" in out and rc == 0:
        return mid, "SURVIVED", "TB_PASS", desc, cfg
    first = next((l.strip() for l in out.splitlines() if "MISMATCH" in l), None)
    if rc == 124:
        why = (first + "  [then the run hung: killed by the 150 s watchdog]") if first else "hang only: no check fired before the watchdog"
    else:
        why = first or next((l.strip() for l in out.splitlines() if "TB_FAIL" in l or "FATAL" in l), "abnormal end")
    return mid, "KILLED", why[:170], desc, cfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-j", type=int, default=2)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    work = os.path.join(ROOT, "sim", "mut")
    os.makedirs(work, exist_ok=True)
    muts = [m for m in M if not a.only or m[0] in a.only.split(",")]
    t0 = time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.j) as ex:
        res = list(ex.map(lambda m: one(m, work), muts))
    res.sort()
    killed = sum(1 for r in res if r[1] == "KILLED")
    surv = [r for r in res if r[1] == "SURVIVED"]
    err = [r for r in res if r[1] == "ERROR"]
    lines = ["# Mutation testing of the ECC wrapper testbench", "",
             f"Icarus Verilog, {len(res)} single-defect mutants, generated by `scripts/run_mutation.py` in {time.time()-t0:.0f} s.", "",
             f"**{killed} / {len(res)} mutants killed**; {len(surv)} survived; {len(err)} could not be applied.", "",
             "| Id | TB config | File | Defect | Result | First failure seen |", "|---|---|---|---|---|---|"]
    for mid, st, why, desc, cfg in res:
        mm = next(x for x in M if x[0] == mid)
        lines.append(f"| {mid} | {cfg} | `{mm[2]}` | {desc} | **{st}** | {why} |")
    if surv:
        lines += ["", "## Surviving mutants (testbench gaps)", ""] + [f"* {r[0]}: {r[3]}" for r in surv]
    open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(lines) + "\n")
    json.dump([{"id": r[0], "result": r[1], "detail": r[2], "defect": r[3], "config": r[4]} for r in res],
              open(os.path.join(ROOT, "reports", "mutation.json"), "w"), indent=1)
    print("\n".join(lines))
    sys.exit(0 if not surv and not err else 1)


if __name__ == "__main__":
    main()
