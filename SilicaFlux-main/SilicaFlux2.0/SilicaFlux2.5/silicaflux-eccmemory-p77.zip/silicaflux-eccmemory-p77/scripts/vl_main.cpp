// Custom Verilator main: identical to the one `--binary` generates, plus it WRITES the coverage database
// (Verilator 5.020's generated main does not).  Usage: ./vtb ... +COVFILE=<path>
#include "verilated.h"
#include "verilated_cov.h"
#include "Vtb_sf_sram_ecc.h"
#include <string>

int main(int argc, char** argv, char**) {
    Verilated::debug(0);
    const std::unique_ptr<VerilatedContext> contextp{new VerilatedContext};
    contextp->commandArgs(argc, argv);
    const std::unique_ptr<Vtb_sf_sram_ecc> topp{new Vtb_sf_sram_ecc{contextp.get()}};
    while (!contextp->gotFinish()) {
        topp->eval();
        if (!topp->eventsPending()) break;
        contextp->time(topp->nextTimeSlot());
    }
    topp->final();
#if VM_COVERAGE
    std::string arg = contextp->commandArgsPlusMatch("COVFILE=");
    const std::string path = arg.empty() ? std::string("coverage.dat") : arg.substr(arg.find('=') + 1);
    contextp->coveragep()->write(path.c_str());
#endif
    return 0;
}
