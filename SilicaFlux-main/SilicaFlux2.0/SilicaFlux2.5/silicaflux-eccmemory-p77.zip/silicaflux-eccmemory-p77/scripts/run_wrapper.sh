#!/usr/bin/env bash
# Wrapper regression: every configuration on Icarus Verilog AND Verilator (assertions on, coverage on),
# then the independent Python check of the raw words each run left in the macro.
#   scripts/run_wrapper.sh [icarus|verilator|all]      (from the project root; default all)
set -u
cd "$(dirname "$0")/.."
WHICH=${1:-all}
mkdir -p sim reports sim/cov
LOG=reports/wrapper_sim.log
[ "$WHICH" = all ] && : > "$LOG"
RTL="rtl/sf_sram_ecc_sys.sv rtl/sf_sram_ecc.sv rtl/sf_sram_ecc_ram.sv rtl/sf_sram_ecc_fi.sv rtl/sf_sram_ecc_ras.sv rtl/sf_sram_ecc_scrub.sv rtl/sf_secded_enc.sv rtl/sf_secded_dec.sv"

# name | K | INV | vec dir | -D defines
CONFIGS=(
"c1|64|3|vectors|-DTB_FI=1 -DTB_SCRUB=0 -DTB_RDLAT=1 -DTB_DECPIPE=0 -DTB_DEPTH=48 -DTB_RSPD=8"
"c2|64|3|vectors|-DTB_FI=1 -DTB_SCRUB=1 -DTB_RDLAT=2 -DTB_DECPIPE=1 -DTB_DEPTH=48 -DTB_RSPD=8"
"c3|64|3|vectors|-DTB_FI=0 -DTB_SCRUB=0 -DTB_RDLAT=3 -DTB_DECPIPE=0 -DTB_DEPTH=32 -DTB_RSPD=6 -DTB_INIT=0 -DTB_UEZ=1 -DTB_MAXWAIT=0"
"c4|32|9|vectors/k32|-DTB_K=32 -DTB_INV=9 -DTB_FI=1 -DTB_SCRUB=1 -DTB_RDLAT=1 -DTB_DECPIPE=1 -DTB_DEPTH=32 -DTB_RSPD=8"
"c5|64|0|vectors|-DTB_INV=0 -DTB_FI=0 -DTB_SCRUB=0 -DTB_RDLAT=1 -DTB_DECPIPE=0 -DTB_DEPTH=32 -DTB_RSPD=8 -DTB_TESTEN=0"
)

fail=0
for cfg in "${CONFIGS[@]}"; do
  IFS='|' read -r name K INV VEC DEFS <<< "$cfg"
  if [ "$WHICH" = all ] || [ "$WHICH" = icarus ]; then
    iverilog -g2012 $DEFS -Irtl -s tb_sf_sram_ecc -o sim/wrap_${name}_iv tb/tb_sf_sram_ecc.sv $RTL 2>&1 | grep -v -E 'timescale|inherits' | tee -a "$LOG"
    out=$(vvp -n sim/wrap_${name}_iv +VEC=$VEC +DUMP=sim/dump_${name}_iv.txt 2>&1)
    echo "$out" | grep -E 'CONFIG|MISMATCH|RESULT|SUMMARY|TB_|COV' | sed "s/^/[icarus ${name}] /" | tee -a "$LOG"
    echo "$out" | grep -q '^TB_PASS' || { echo "[icarus ${name}] FAILED" | tee -a "$LOG"; fail=1; }
    python3 -I scripts/check_dump.py sim/dump_${name}_iv.txt $K $INV | sed "s/^/[icarus ${name}] /" | tee -a "$LOG" || fail=1
  fi
  if [ "$WHICH" = all ] || [ "$WHICH" = verilator ]; then
    rm -rf sim/vl_wrap_${name}
    verilator --cc --exe --build --timing --assert --coverage -Wno-fatal -Wno-WIDTH -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-DECLFILENAME -Wno-INITIALDLY -Wno-BLKSEQ -Wno-CASEINCOMPLETE \
        -DSF_ECC_ASSERT -DSF_SECDED_ASSERT $DEFS -Irtl --top-module tb_sf_sram_ecc -Mdir sim/vl_wrap_${name} -o vtb \
        tb/tb_sf_sram_ecc.sv $RTL "$PWD/scripts/vl_main.cpp" >> "$LOG" 2>&1 || { echo "[verilator ${name}] BUILD FAILED" | tee -a "$LOG"; fail=1; continue; }
    out=$(cd sim/vl_wrap_${name} && ./vtb +VEC=../../$VEC +DUMP=../dump_${name}_vl.txt +COVFILE=../cov/${name}.dat 2>&1)
    echo "$out" | grep -E 'CONFIG|MISMATCH|RESULT|SUMMARY|TB_|COV|Assertion|%Error|%Warning-ASSERT' | sed "s/^/[verilator ${name}] /" | tee -a "$LOG"
    echo "$out" | grep -q '^TB_PASS' || { echo "[verilator ${name}] FAILED" | tee -a "$LOG"; fail=1; }
    python3 -I scripts/check_dump.py sim/dump_${name}_vl.txt $K $INV | sed "s/^/[verilator ${name}] /" | tee -a "$LOG" || fail=1
  fi
done
[ $fail -eq 0 ] && echo WRAPPER_REGRESSION_PASS | tee -a "$LOG" || echo WRAPPER_REGRESSION_FAIL | tee -a "$LOG"
exit $fail
