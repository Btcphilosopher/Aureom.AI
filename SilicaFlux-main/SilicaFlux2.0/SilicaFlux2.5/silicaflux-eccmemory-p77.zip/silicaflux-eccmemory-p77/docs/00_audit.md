# 00 — Repository audit

Scope requested: SRAMCore, SRAMBank, existing SECDED modules, RAS, MBIST, SRAM macro wrappers, firmware error registers.
Source: the Aureom.AI repository checkout (`SilicaFlux-main/…`, mostly nested `.zip` archives; the repo has no loose `.sv`).
Archives were extracted read-only into a scratch directory; nothing in the repository was modified.

## 1. What was actually read (and what was only listed)

| Area | Archive | How deeply I looked |
|---|---|---|
| Existing SECDED codec, ECC SRAM wrapper, scrubber, fault injection, RAS | `silicaflux-ras-project26.zip` (**P26**) | **Read**: `sfras_ecc_funcs.svh`, `sfras_secded_enc.sv`, `sfras_secded_dec.sv`, `secded_ref.py`, header + ports of `sfras_ecc_sram.sv`, docs 00/01/08, regression + mutation reports. Other RTL listed only. |
| SRAMCore / SRAMBank | `silicaflux-memorycore-sram.zip` (`sf_sram_core.sv`, `sf_sram_bank.sv`, `sf_ecc_enc/dec.sv`, `sf_ecc_counters.sv`, `sf_sram_mbist_ctl.sv`) | **Read**: `docs/ECC.md`, `AUDIT.md`, `CONTRACT.md`, the port list of `sf_sram_bank.sv`, the file list. RTL bodies **not** read. |
| Firmware error registers | `silicaflux-controlcore.zip` → `cc_ras.sv` | **Read** the header comment, port list and register offsets. |
| SRAM macro wrappers, MBIST | nested `silicaflux-sramlib` copies (`sram_sp`, `sram_bank_controller`, `sram_backend_1rw`, `sram_mbist_march`, `sram_mbist_adapter`, ASIC leaf wrappers) | **File lists only.** Their behaviour (raw test port, March elements ending with an all-zero scrub, `MASK_WIDTH = 1` macro use) is taken from **P26's and memorycore's own documentation**, not verified here. |
| SRAM grid generator | `silicaflux-sramgrid-p33.zip` | listing only |

Statements about what P26 / memorycore verified (e.g. "39/39 runs passed", "22/22 mutants killed") are **their** reports, produced in a different environment; they were not re-run.
What *was* re-established here: the P26 codec cells are **formally equivalent** to the Project 77 codec (§3).

## 2. What already exists

| Item | Where | State |
|---|---|---|
| Parametric extended-Hamming SECDED cells | P26 `sfras_secded_enc/dec` (re-used by memorycore as `sf_ecc_enc/dec`) | verified by P26 against an independent Python model; (137,128) used by memorycore |
| ECC SRAM wrapper: RMW with port lock, scrubber (CHECK/FIX/VERIFY), init engine, raw MBIST port, fault injection, poison bit | P26 `sfras_ecc_sram.sv` (674 lines) | reported verified |
| ECC bank (K = 128 per 128-bit line): RMW, **partial write on an uncorrectable line aborts**, init, scrubber, counters, injection | memorycore `sf_sram_bank.sv` | reported verified (K = 32/64/128 codec tests) |
| 12-source RAS block with `EXT_WARN` / `EXT_FATAL` **level inputs**, sticky status, counters, first/last address | ControlCore `cc_ras.sv` | existing firmware sees `ext_warn/ext_fatal` immediately |
| MBIST March C-/MATS+/checkerboard engines testing **raw stored words**, ending with an all-zero scrub element | sramlib / TestCore | per P26's audit |
| Byte parity on IMEM/DMEM, scratchpads, memory core (`ECC_MODE=PARITY`) | various | SECDED mode "reserved for Project 26" |

## 3. What Project 77 reuses, what it does not

* **Code definition — reused.** Same extended-Hamming code and stored layout as P26 (`cw = {parity, checks, data}`, data bit *i* at the *i*-th non-power-of-two position, `CHK_INV` mask). Consequence: a Project 77 word is bit-identical to a P26 word, so the two can share a macro or a reference model.
* **Codec RTL — re-implemented, then proven equal.** `sf_secded_enc/dec` were written from the specification (own position/mask functions, own syndrome network). Yosys SAT proves them **identical to P26's cells for all 2^64 data words and all 2^72 received words**, for `CHK_INV = 0` and `0x03` (`reports/formal_codec.md`, tops `f_eq_enc`, `f_eq_dec`). Re-implementing and proving equivalence was chosen over copying so that the "independent" checks mean something, while still honouring *reuse verified implementations*.
* **Reference model — reused as a 4th cross-check.** P26's `secded_ref.py` is vendored unmodified (`third_party/sfras_ref/`, SHA-256 + provenance) and compared field-by-field with three new independent models.
* **Wrapper — new.** `sf_sram_ecc` is a fresh design for the 64/72 baseline. It adopts the memorycore contract rules that the audit found (full-word write never reads; partial write = atomic RMW under a lock; **uncorrectable old word ⇒ abort, word left as found**; responses in acceptance order) and P26's ideas (check-bit inversion, init after MBIST, FIX as a locked re-read). It is **not** a drop-in replacement for either project's wrapper: ports differ, there is no poison bit, and it has a tag-pipeline response path.
* **Names.** `sf_ecc_enc` / `sf_ecc_dec` already exist in memorycore with different content; Project 77 therefore uses the prefixes `sf_secded_*` and `sf_sram_ecc*` to avoid module-name collisions when archives are merged.

## 4. Findings that shaped the design

1. **All-zero must not be valid.** MBIST ends with an all-zero scrub and a dead word line reads zero; the plain extended-Hamming code accepts the all-zero word. → `CHK_INV` (default `0x03`) makes all-zero **and** all-ones stored words uncorrectable, and the wrapper re-initialises the array when the raw MBIST port is released.
2. **Partial writes under a word-wide code are a read-modify-write.** memorycore documents atomic RMW + "abort on UE". Project 77 keeps the policy, implements it with a bank lock, and **proves** with an assertion that nothing else may load the issue stage while locked (`SF_ASSERT` block, checked in simulation and by bounded formal).
3. **A scrub that rewrites a word is a race with functional writes.** Two designs avoid it in the repo (locked FIX). Project 77's FIX is the *same locked machinery* as a byte-write with no merge, so it re-decodes the word under the lock and can never write stale data. Tested with injected races and a mutant that must fail (`reports/mutation.md`).
4. **Counting.** `cc_ras` counts events per source; double counting arises when one correction is observed twice. Project 77 has **one decode point**, one event per decoded word, and an explicit rule for the scrub CHECK → FIX → VERIFY chain (`docs/04_ras_interface.md`).
5. **Error reporting to firmware.** The repo has no memory-ECC register page that matches the brief's list (address, syndrome, count, fatal). `sf_sram_ecc_ras` provides one (offsets in `docs/04_ras_interface.md`) and exposes `irq_warn_o` / `fatal_req_o` levels meant for `cc_ras` `lv_ext_warn` / `lv_ext_fatal`.

## 5. Not done / not claimed

* The wrapper is **not** instantiated inside `sf_sram_bank` / `sf_sram_core` (they are 128-bit line designs; a 64-bit word variant would need its own integration step and re-verification).
* The macro port was written against the **documented** `sram_backend_1rw` contract (one op per cycle, `MASK_WIDTH = 1`, registered read data); it was **not** simulated with the real sramlib backend in this session.
* The MBIST port is a raw pass-through; the actual `sram_mbist_march` / `sram_mbist_adapter` RTL was not connected.
