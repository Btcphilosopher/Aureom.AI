# 06 — Limitations and what is NOT claimed

**Protection**
* SECDED corrects every 1-bit error and detects every 2-bit error *in one stored word*. **Nothing is promised for ≥ 3 flipped bits in a word:** odd weights are miscorrected 62–76 % of the time, some even weights are invisible (`01_math_model.md §7`).
* Multiple-bit upsets from one particle strike are only covered if the macro's column interleaving puts adjacent cells in different words. **Bit interleaving is not implemented here.**
* The code protects stored data and check bits only. **Address-decoder faults** (reading the wrong word, which carries valid ECC) are not detected; the address is not folded into the code.
* Reads do not write corrections back. A latent error is corrected, and counted, on every read until scrubbed/rewritten (by design; `04_ras_interface.md §2`).
* A word that the decoder flags UE is returned *uncorrected* (or zero) and flagged. Consumers must honour `rsp_err`; ignoring it makes the data unsafe.

**Design scope**
* `K` must be a multiple of 8. `CHK_INV` defaults to `0x03`, which makes all-zero and all-ones stored words uncorrectable for K = 64 (also 8, 16, 128); K = 32 needs `0x09`. Other widths: use `model/secded_model.py:default_inv(k)`.
* RMW on an uncorrectable old word **aborts**; there is no poison-bit mode (unlike P26) and no alternative policy.
* The wrapper assumes a single-port macro with no write mask and registered read data. The real `sram_backend_1rw` / MBIST adapter / `cc_ras` / `sf_sram_bank` were **not** connected or simulated (`00_audit.md §5`). The register page offsets are Project 77's own.
* The pipelined encoder (`sf_secded_enc_pipe`) is a verified standalone variant; the wrapper itself uses the combinational encoder.
* The init engine costs `DEPTH` cycles per (re-)initialisation — thousands of cycles for a large array.

**Verification — what the evidence is, and is not**
* **Codec formal proofs are unbounded and exhaustive** (Yosys SAT over all 2^64 data words / 2^72 received words), but they use a **case split over error positions** (72 singles, 2,556 pairs) because plain SAT cannot prove parity-tree identities with a symbolic position (measured: it did not finish in 600 s). The split is exhaustive, so it loses nothing; the formal cover of the `f_double`/`f_single` sets is shown by assertion counts per job in `reports/formal_codec.log`.
* **Wrapper formal proofs are BOUNDED** (depth 20 / 16 cycles), on a **small instance (K = 16, 4 words)**, not on the shipping K = 64 / 48-word configuration, and prove only the structural properties listed in `formal/wrapper_formal.sv`. Ordering and data-correctness are verified by simulation, not by formal. No unbounded (induction) proof of the wrapper was obtained.
* **SymbiYosys is not installed in this environment**; formal runs use Yosys' built-in `sat` command directly. No `.sby` files are provided because none could be run.
* Simulation: Icarus Verilog 12.0 and Verilator 5.020 on a behavioural RAM; random stimulus with a fixed set of seeds per run (`$urandom` is not re-seeded, so each run is reproducible but explores one trajectory per configuration). **No gate-level, timing, power or silicon data exist.**
* Mutation testing uses 33 hand-written single-defect mutants; it shows the testbench can fail, not that no defect survives. Four mutants initially survived and exposed real testbench gaps (listed in `05_verification.md`); an equivalent mutant was replaced. Three mutants are killed only by the hang watchdog because two testbench wait loops (`issue()`, `xscr()`) have no bound of their own.
* Two Icarus 12 compiler/runtime bugs were worked around in the testbench (`$countones` on concatenations; constant-condition `?:` with string arguments). Both simulators are exercised, so a tool bug that affects only one would show as a disagreement.
* The `K = 64` Python model is generalised to other K for parametric checks (K = 8, 16, 32, 128 codec; K = 32 wrapper); K = 57 was checked structurally only.
