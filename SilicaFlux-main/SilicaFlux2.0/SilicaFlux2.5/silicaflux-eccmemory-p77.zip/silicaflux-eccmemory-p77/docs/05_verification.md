# 05 — Verification

Headline numbers are generated into `reports/SUMMARY.md` by `scripts/make_summary.py` from the logs; this page explains **what each piece of evidence is and is not**.
Tools: Icarus Verilog 12.0, Verilator 5.020, Yosys 0.33, Python 3.13. (SymbiYosys is not installed here; formal uses Yosys' built-in `sat`.)

## 1. Strategy and order

1. **Math model first** (`model/`, `reports/math_verification.md`): four independent implementations; golden vectors are generated only after they agree.
2. **Codec RTL, no memory attached**: golden-vector simulation on two simulators, plus SAT proofs.
3. **Wrapper**: scoreboard-checked simulation on two simulators in five configurations, an independent Python check of the raw stored words, bounded formal, mutation testing, coverage.

## 2. Independence of the reference

| Check | Reference used | Shares code with the RTL? |
|---|---|---|
| encode / decode vectors (`vectors/*.hex`) | Python RefA, cross-checked by RefB, RefC and the Project-26 model | no |
| expected syndrome and corrected-bit index of every injected error (`vectors/syn_*.hex`) | Python | no |
| the 72-bit words the macro actually holds (`scripts/check_dump.py` over `sim/dump_*.txt`) | RefA/RefB/RefC `encode()` | no |
| data/response/ordering/latency/counts | a transaction-level scoreboard in the testbench that knows only memory semantics and the injected error mask — it contains no ECC logic | no |
| equivalence with Project 26's cells | P26 RTL (SAT) and P26 Python model | different project, different code |

## 3. Codec

* **Simulation** (`tb/tb_secded_codec.sv`, `scripts/run_codec.sh`): six configurations (K = 8, 16, 32, 64 ×2 `CHK_INV`, 128) on Icarus **and** Verilator. For K = 64 / `INV=0`: 2,150 encode vectors and 107,830 decode vectors — every single-bit error for 24 data words, every double-bit error for 8 data words, every triple-bit error for data = 0 (59,640), random weight 3–12 errors and random raw words; class, returned data, corrected word, bit index, syndrome and `ue_inval` are compared bit-exactly, and "a UE never modifies the word" is checked independently of the vector. Pipelined encoders (0/1/2 stages) are checked against the combinational one under random stalls. The Project-26 RTL cells are run in lock-step on every vector.
* **Formal** (`formal/codec_formal.sv`, `formal/run_codec_formal.sh`): Yosys SAT, **unbounded** (the codec is combinational):

| top | statement | quantifiers |
|---|---|---|
| `f_clean` | decode(encode(d)) is clean and returns d | ∀ d ∈ 2^64 |
| `f_single` | every 1-bit error (all 72 bits) is corrected: CE, right index and kind, data and word restored | ∀ d, ∀ bit |
| `f_double` | every 2-bit error (all 2,556 pairs) is detected: UE, **not** CE, word and data unmodified | ∀ d, ∀ pair |
| `f_all_safe` | exactly one verdict; CE flips exactly one bit; UE/NONE never modify the word; UE returns raw data | ∀ received word ∈ 2^72 |
| `f_all_fix` | whenever the decoder corrects bit *b*, the result is a true codeword (a CE never lands on garbage) | ∀ received word, ∀ b |
| `f_all_none` | NONE implies a genuine codeword | ∀ received word |
| `f_eq_enc`, `f_eq_dec` | identical to the Project-26 encoder / decoder, every output | ∀ d / ∀ received word |

Each for `CHK_INV` = 0 and 0x03. **Why a case split:** a symbolic error position makes the two XOR trees structurally different and CDCL SAT needs exponential time (measured: `f_single` with a symbolic position did not finish in 600 s). With a constant position everything off the error's path is shared and each case takes seconds; the 72 / 2,556 cases are exhaustive. A negative control (a deliberately false assertion) was confirmed to fail, and every proof reports its `$assert` count so an empty proof would be visible. Result: **298 / 298 obligations proved, 0 failed** (`reports/formal_codec.md`). (During this long run `sf_secded_defs.svh` gained an assertion macro for the wrapper; proof jobs started afterwards read the updated header, which does not touch the codec logic.)

## 4. Wrapper simulation — what each phase checks

All phases run through the scoreboard: every accepted request is applied in acceptance order to a model of the memory and of the stored-error mask; response (data, `err/ue/ce`, `we`, `id`, order), RAS event (kind, source, address, **syndrome**, bit index) and counters are predicted and compared. Response payload stability under stall is checked every cycle.

| Phase | Checks |
|---|---|
| P0 reset/init | after reset every word equals the Python `encode(0)` word; with `INIT_ON_RESET=0` the powered-up zero array reads **UE for every word** (never valid zero) |
| P1 | all-zero, all-one, `A5…`/`5A…`, `00FF…`/`FF00…` patterns written to and read back from every word; walking 1 / walking 0 |
| P2 random | 1,500 random reads/writes + full readback |
| P3 | **every single-bit error position (all 72 stored bits)** ×3 data patterns: CE, data corrected, expected syndrome/index from Python, **read does not modify the array**, error persists (second read is CE again), RMW and full write repair |
| P4 | **every double-bit combination (all 2,556)** through the wrapper: UE flagged, never CE, raw data returned, array unchanged, RMW **aborts leaving the word as found**, full write repairs |
| P5 / P5b | 2,400 random partial/full/no-op/read operations with latent single/double errors injected between chunks; byte-accurate model; RMW onto CE words in a data, check and parity bit; 100 chained RMWs |
| P6 reset | 8 resets with RMWs in flight (memory re-initialised, no stale lock/response, RAS cleared); warm-reset configuration: an RMW cut at 9 different cycles leaves the word **old or merged, never torn** (both outcomes observed) |
| P7 | out-of-range × {read, write, RMW, be=0}: error response, no side effect |
| P8 backpressure | random / long / total stalls: no loss, duplicate or reorder; outstanding never exceeds `RSP_DEPTH`; `req_ready` drops at exactly `RSP_DEPTH` outstanding; RAS counts exact |
| P9 | latency and lock-window formulas (`02_architecture.md §3`) and 1 op/cycle sustained |
| P10 | all-zero / all-ones *stored* words decode UE; RMW onto them aborts |
| P11 | RAS register page: ID/CFG, reset defaults (`UE_FATAL_EN`), counts, address/syndrome/index/source, first/last UE, fatal policy incl. scrub-UE not fatal by default, CE threshold with and without fatal escalation, selective W1C of each status bit, **32-bit counter saturation** (backdoor deposit near the maximum), illegal access |
| P12 / P12b | MBIST raw port: functional port blocked, raw march with data **and** check bits, re-init afterwards; with `TEST_EN = 0` the request is ignored and the functional port is unaffected |
| P19 | `init_start_i` with RMWs still in flight: the engine waits for them, runs one word per cycle with the functional port blocked (also an every-cycle invariant), leaves a valid zero array |
| P13 / P14 | fault injection (FI build): authorisation gating, write/read/stuck modes, single/double, data/check/parity bits, persistence, stuck-at not leaking to other addresses, refusal of a re-armed one-shot and of an invalid mode; (FI-off build): commands have **no** effect |
| P15 (external scrub master) | CHECK/FIX/VERIFY: **one** CE event per correction; scrub FIX racing a functional write, read, RMW; bounded scrub wait behind back-to-back reads; UE never written; persistent fault ⇒ 1 CE + 1 PERSIST |
| P16–P18 (internal engine) | one pass: every CE repaired and counted once, UE untouched, counters exact; second pass; halt/resume; the **interval timer**; `fix_en = 0` (found and counted, never written); a word that gets **worse between CHECK and FIX**, and **between FIX and VERIFY** (injected exactly at the accept edge); **2,400 random operations concurrent with scrub** with exact data; persistent stuck-at found by the engine |

Configurations (`scripts/run_wrapper.sh`): c1 LAT = 1 + FI + external scrub; c2 LAT = 3 (RD_LAT 2 + DEC_PIPE) + FI + internal scrub; c3 LAT = 3 (RD_LAT 3), FI off, `INIT_ON_RESET = 0`, `UE_DATA_ZERO = 1`, `RSP_DEPTH = 6`, `SCRUB_MAX_WAIT = 0`; c4 K = 32 / `CHK_INV = 0x09`; c5 plain code (`CHK_INV = 0`) with `TEST_EN = 0`.
Verilator runs use `--assert` with the RTL assertion block enabled and `--coverage`.

## 5. Wrapper formal — scope

`formal/wrapper_formal.sv`, `reports/formal_wrapper.md`. **Bounded** (depth 20 and 16), on a **K = 16, 4-word instance** with all inputs free, including the raw MBIST port (so arbitrary stored words, hence CE/UE states, are reachable). Properties: the RTL assertion block (no accept while locked; **while locked only the write-back may load the issue stage** — the RMW/FIX atomicity property; FIFO bounds; one response push and one event kind per cycle; no access during init or MBIST grant; MBIST grant only on an idle pipeline) plus port-level checks (response conservation, stalled responses unchanged, nothing survives a reset). **16 cover goals each produced a witness**, which shows the properties are not vacuously true — and caught one real harness flaw: with K = 8 there is a single byte lane, a partial write cannot exist, and the RMW path was never exercised until the harness was moved to K = 16.

## 6. Mutation testing

`scripts/run_mutation.py`: 33 single-defect mutants of the RTL (encoder, decoder, wrapper, scrub, RAS, FI); each is applied to a copy, the testbench configuration that targets it is run on Icarus, and the mutant is *killed* if the testbench fails, aborts or hangs. See `reports/mutation.md` for the result and the first failure each mutant produced. **How they were killed:** 25 by a named testbench check; 5 (M02, M03, M12, M16, M31) by a named check followed by a hang; and **3 only by the hang watchdog** (M29 reset leaves the lock state untouched, M32 scrub-wins arbitration, M33 `SCRUB_MAX_WAIT = 0` deadlock) — each is a deadlock in a testbench wait loop (`issue()`, `xscr()`) that has no bound of its own. A deadlock is a legitimate failure, but a bounded wait with a named message would be a better detector; this is a known testbench weakness, not fixed in this revision. (The runner was first reporting these as bare timeouts because a `SIGKILL`ed simulator loses its buffered output; it now runs the simulator line-buffered so the checks that fired before the hang are visible.)
**What it found along the way (all fixed):** the first campaign killed 28/32. Of the four survivors one was an *equivalent* mutant (replaced by a real defect), and three exposed **genuine testbench gaps** — the reset default of the fatal policy was never checked (the TB overwrote CTRL first); a stuck-at fault was only ever read at its own address; and the scrub-versus-functional race used only an RMW, which masks the defect. Tests were added for each and the survivors then died. A further hand review found a **design bug** — `SCRUB_MAX_WAIT = 0` would have blocked the functional port forever — which was fixed in the RTL and added as mutant M33; and running Verilator exposed a **testbench bug** (a per-phase vs cumulative counter comparison) that Icarus's trajectory had hidden.

## 7. Coverage

`reports/coverage.md`: Verilator line/branch/toggle coverage merged over the five configurations with every uncovered line listed, plus the testbench's functional bins (operation × error-weight matrix, error location kind, lock cycles, credit exhaustion, scrub starvation guard, FI modes, MBIST, resets, register accesses, fatal).

**How coverage was used.** The first merged report listed `init_start_i`, `TEST_EN = 0`, the scrub interval timer, `fix_en = 0`, the engine's reaction to a UE appearing at FIX or VERIFY, RAS counter saturation, selective W1C and two FI refusal paths as uncovered. These were **real testbench gaps** (not unreachable code) and tests P12b, P19 and the P11/P13/P16 additions close them. Two of those new tests first failed because of *testbench* mistakes (a scrub-run helper that assumed interval 0; an error injected before the FIX write-back instead of after) — both fixed. What remains uncovered is classified in `reports/coverage.md`: defensive `default:` arms of fully-decoded state machines, saturation guards that need 2^16 cycles, X-input guards that a two-state simulator cannot reach, and simulation-only code.

An earlier version of the coverage report was also wrong in itself: Verilator names coverage pages after the *parameter-specialised* module, so my merge treated the same line in different configurations as different points and under-reported coverage; the merge key was corrected.

## 8. Reproduce

```bash
make math codec wrapper coverage          # simulation evidence
make formal-wrapper mutation              # tens of minutes on 4 cores
make formal-codec                         # SAT matrix; hours on a loaded 4-core machine
```
