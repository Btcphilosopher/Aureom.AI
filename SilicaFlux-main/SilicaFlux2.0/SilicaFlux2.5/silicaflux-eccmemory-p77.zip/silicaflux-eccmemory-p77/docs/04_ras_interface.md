# 04 — RAS interface

Everything the brief lists is exposed by `sf_sram_ecc` (and, as a register page, by `sf_sram_ecc_ras`):

| Required | Port / register |
|---|---|
| Correctable error | `ev_valid_o & ev_ce_o` (pulse); `ce_seen_o` (sticky level); `STATUS.CE_SEEN` |
| Uncorrectable error | `ev_valid_o & ev_ue_o` (pulse); `ue_seen_o`; `STATUS.UE_SEEN`; `irq_ue_o` |
| Error syndrome | `ev_syn_o = {pe, s}` (pulse bus); `last_syn_o`; `LAST_CE_INFO[11:0]`, `FIRST_UE_INFO`, `LAST_UE_INFO` |
| Word address | `ev_addr_o`; `last_addr_o`; `LAST_CE_ADDR`, `FIRST_UE_ADDR`, `LAST_UE_ADDR` |
| Correction count | `ce_count_o` (32-bit, saturating); `CE_COUNT`; also `ue_count_o`, `persist_count_o` |
| Fatal error request | `fatal_req_o` (sticky level) — drive `cc_ras` `lv_ext_fatal`; `irq_warn_o` → `lv_ext_warn` |

Also on the event bus: `ev_src_o` (0 demand read, 1 RMW old-word read, 2 scrub), `ev_pos_o` (corrected stored-bit index), `ev_persist_o`.

## 1. Event kinds

| kind | raised when |
|---|---|
| **CE** | a decode corrected exactly one bit |
| **UE** | a decode found an uncorrectable word (double error or invalid syndrome) |
| **PERSIST** | a scrub **VERIFY** read — issued right after a FIX — still decodes as a single-bit error: a hard fault. **Not** counted as another CE. |

## 2. Avoiding double counting

1. **One decode point.** Every functional read, RMW old-word read and scrub read passes through the *same* decoder in the *same* pipeline stage, once. The event is a registered **single-cycle pulse** produced there. Response backpressure, FIFO stalls and credit stalls happen *after* that point and cannot re-trigger it (tested: phase P8 holds the response channel stalled for up to 4 × `RSP_DEPTH` cycles while reads of words with latent single-bit errors are in flight, and the RAS counters must still equal the scoreboard's exact prediction).
2. **Scrub CHECK → FIX.** The FIX re-decodes the word under the lock. Its CE is **suppressed when its syndrome equals the syndrome CHECK reported** (the scrub engine passes it in the request): the same correction event is not reported twice. A different syndrome (the word changed in between) is reported normally.
3. **Scrub VERIFY.** A clean VERIFY adds nothing. A VERIFY that still sees an error is a PERSIST event, never a second CE.
4. **RMW.** The old-word read is decoded once; the write-back is not decoded.
5. **At most one event per cycle**, one-hot kind (formal-checked), so the counters never need to add two in one cycle.

What this does *not* do: **it does not de-duplicate separate reads of the same latent error.** Reads do not repair the array, so reading a word with a latent single-bit error *n* times is *n* real corrections and counts *n*. Use scrubbing (or rewrite) to remove the latent error; `PERSIST` identifies the ones that come back.

## 3. Fatal-error policy (`CTRL`)

| Condition | Sets `STATUS.FATAL` / `fatal_req_o` | Default |
|---|---|---|
| UE from a demand read or RMW | when `UE_FATAL_EN` | **on** |
| UE found by the scrubber | when `SCRUB_UE_FATAL_EN` | off — a latent UE in memory nobody has consumed yet is reported, not fatal |
| PERSIST | when `PERSIST_FATAL_EN` | off |
| `CE_COUNT ≥ CE_THR` (CE_THR ≠ 0) | when `CE_THR_FATAL_EN` (always sets `STATUS.CE_THR_HIT` → `irq_warn_o`) | off |

`STATUS` is sticky, write-1-to-clear; a condition that recurs sets it again. A UE read returns the stored bits **flagged** (`rsp_err`); `fatal_req_o` is the system-level escalation, not a data-path mechanism.

## 4. Register page (32-bit, zero-wait-state: `ras_reg_sel_i / we / addr[7:0] / wdata → rdata / err`)

| Offset | Name | Access | Description |
|---|---|---|---|
| 0x00 | ID | RO | `0x45434337` ("ECC7") |
| 0x04 | CFG | RO | [7:0] K, [15:8] N, [23:16] AW, [24] SCRUB_EN, [25] FI_EN |
| 0x08 | CTRL | RW | [0] CE_IRQ_EN [1] UE_IRQ_EN [2] UE_FATAL_EN (reset 1) [3] SCRUB_UE_FATAL_EN [4] PERSIST_FATAL_EN [5] CE_THR_FATAL_EN |
| 0x0C | CE_THR | RW | 0 = disabled |
| 0x10 | STATUS | W1C | [0] CE_SEEN [1] UE_SEEN [2] PERSIST_SEEN [3] CE_THR_HIT [4] CNT_SAT [5] FATAL |
| 0x14 / 0x18 / 0x1C | CE_COUNT / UE_COUNT / PERSIST_COUNT | RO | saturating 32-bit |
| 0x20 / 0x24 | LAST_CE_ADDR / LAST_CE_INFO | RO | INFO = `[11:0]` syndrome, `[23:12]` corrected-bit index, `[25:24]` source |
| 0x28 / 0x2C | FIRST_UE_ADDR / FIRST_UE_INFO | RO | captured once, re-armed by `CLR[1]` |
| 0x30 / 0x34 | LAST_UE_ADDR / LAST_UE_INFO | RO | |
| 0x38 | CLR | WO | [0] clear counters + CNT_SAT, [1] re-arm FIRST_UE capture |

A write to a RO register or a read of an unmapped offset sets `ras_reg_err_o`. Offsets are Project 77's own; they are **not** the `cc_ras` page and not P26's `sfras` page (see `00_audit.md`).

## 5. Wiring to the existing ControlCore RAS

`irq_warn_o → cc_ras.lv_ext_warn` (EXT_WARN, level) and `fatal_req_o → cc_ras.lv_ext_fatal` (EXT_FATAL, level) make existing firmware see memory-ECC events immediately, with `cc_ras`'s own sticky status, counters and `FATAL_TO_HOST` / `FATAL_ISOLATE` policy. Per-event detail (address, syndrome) stays in this block's registers. This wiring was **not** simulated with `cc_ras` here.
