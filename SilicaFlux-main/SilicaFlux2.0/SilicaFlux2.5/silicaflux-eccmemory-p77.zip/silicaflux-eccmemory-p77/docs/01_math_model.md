# 01 — The 64/72 mathematical model

This is the **specification** the RTL implements and the testbenches check. It was written and verified *before* any RTL was
connected to a memory (`model/verify_math.py`, report `reports/math_verification.md`).

## 1. The code

A **single-error-correcting, double-error-detecting (SECDED) extended Hamming code**, linear over GF(2):

| quantity | value |
|---|---|
| data bits K | 64 |
| Hamming check bits R | 7 — the smallest r with 2^r ≥ K + r + 1 (2^7 = 128 ≥ 72) |
| overall-parity bit | 1 |
| stored bits N = K + R + 1 | **72** |
| minimum distance | **4** (proved, §6) |
| rate | 64/72 |

## 2. Parity convention (explicit)

**EVEN parity throughout.** For an un-inverted codeword:

* every Hamming row *j* (j = 0…6) has an even number of ones among the bits it covers, and
* the whole 72-bit word has an even number of ones.

(The optional constant `CHK_INV`, §5, is applied *after* encoding and removed *before* decoding; everything in §3–§4 describes the
un-inverted code.)

## 3. Bit positions

### 3.1 Hamming positions (the number a syndrome uses to name a bit)

Positions 1 … 71 are used exactly once. Position 0 is the overall-parity bit (outside the syndrome).

* **Check bit j** sits at Hamming position **2^j**: positions **1, 2, 4, 8, 16, 32, 64** (c0 … c6).
* **Data bit i** sits at the (i+1)-th integer ≥ 3 that is **not a power of two**:

```
d00-> 3 | d01-> 5 | d02-> 6 | d03-> 7 | d04-> 9 | d05->10 | d06->11 | d07->12
d08->13 | d09->14 | d10->15 | d11->17 | d12->18 | d13->19 | d14->20 | d15->21
d16->22 | d17->23 | d18->24 | d19->25 | d20->26 | d21->27 | d22->28 | d23->29
d24->30 | d25->31 | d26->33 | d27->34 | d28->35 | d29->36 | d30->37 | d31->38
d32->39 | d33->40 | d34->41 | d35->42 | d36->43 | d37->44 | d38->45 | d39->46
d40->47 | d41->48 | d42->49 | d43->50 | d44->51 | d45->52 | d46->53 | d47->54
d48->55 | d49->56 | d50->57 | d51->58 | d52->59 | d53->60 | d54->61 | d55->62
d56->63 | d57->65 | d58->66 | d59->67 | d60->68 | d61->69 | d62->70 | d63->71
```

### 3.2 Stored (physical) layout — systematic

```
cw[63:0]    data bits           data bit i at cw[i]
cw[70:64]   Hamming check bits  check bit j at cw[64 + j]        j = 0..6
cw[71]      overall parity      even parity over cw[70:0]
```
Data is stored unchanged and contiguous (a macro can keep `cw[71:64]` in a separate narrow column group).

## 4. Encoding, syndrome, correction

**Encode.** Check bit *j* is the XOR of the data bits whose Hamming position has bit *j* set:

```
c[j] = XOR over { d[i] : (position(i) >> j) & 1 }          j = 0..6
p    = (XOR of all d) XOR (XOR of all c)                    overall parity, even
cw   = { p, c[6:0], d[63:0] }
```
Coverage (data bits per check bit): c0, c1, c2 → 35; c3, c4, c5 → 31; c6 → 7 (so a check-bit XOR tree has at most 36 inputs).

**Syndrome** of a received word `r` (after removing `CHK_INV`):

```
s  = ( recompute c from r.data )  XOR  r.c         7 bits   -- equals the XOR of the Hamming positions of all flipped bits
pe = XOR of all 72 bits of r                        1 bit    -- parity of the number of flipped bits
syn = { pe, s }                                      8 bits
```

**Correction procedure** (this is exactly the table the decoder RTL implements):

| s | pe | verdict | action |
|---|---|---|---|
| 0 | 0 | **NONE** | no error |
| 0 | 1 | **CE** | the overall-parity bit alone flipped; data untouched |
| ≠ 0, ≤ 71 | 1 | **CE** | one error at Hamming position *s*: a check bit (s = 2^j) or a data bit — flip it back |
| > 71 (72…127: 56 values) | 1 | **UE** | the syndrome names no bit ⇒ ≥ 3 errors; **not corrected** |
| ≠ 0 | 0 | **UE** | double error (any even number ≥ 2); **not corrected** |

On **UE** the decoder returns the *stored, uncorrected* bits and flags the verdict. A double-bit error is therefore **never**
presented as corrected data.

## 5. The check-bit inversion mask `CHK_INV`

An optional constant (R+1 = 8 bits) XORed onto `cw[71:64]` after encoding and removed before decoding. It does not change any
distance or correction property (it is a constant offset of the codeword set) but it chooses *which stored words are valid*.

With the plain code (`CHK_INV = 0`) the **all-zero and all-ones words are both valid codewords** (all-ones data encodes to
all-ones). A dead word line, a macro that powers up as zero, or an MBIST zero-scrub would then read back as *valid* zero data.
`CHK_INV = 0x03` (first bit pair whose inversion makes **both** all-zero and all-ones stored words uncorrectable; found by brute
force, and independently by Project 26) makes them **UE**. Recommended values per width: K = 8, 16, 64, 128 → `0x03`; K = 32 → `0x09`.
The wrapper default is `0x03`.

## 6. What is proved about the code (computed in `verify_math.py`)

* **d_min = 4.** All 72 columns of H are distinct and non-zero (⇒ d ≥ 3); none of the C(72,3) = 59,640 column triples sums to zero
  (⇒ d ≥ 4); a weight-4 dependency exists — stored bits `d0, d1, d2, parity` (positions 3 ⊕ 5 ⊕ 6 = 0) — so d = 4 exactly.
* Hence **every 1-bit error is correctable and every 2-bit error detectable, for every data word** (the code is linear: the verdict depends
  only on the error pattern).
* The same structure result was computed for K = 8, 16, 32, 57, 128.

## 7. Outside the guarantee (characterised, **not** promised)

Errors of weight ≥ 3 are beyond the code distance. Exact enumeration (weights 3–5) and 200,000-sample Monte-Carlo (weights 6–8) of what the decoder does:

| weight | patterns | miscorrected as CE | flagged UE | undetected (valid codeword) |
|---|---|---|---|---|
| 3 | 59,640 | 75.96 % | 24.04 % | 0 |
| 4 | 1,028,790 | 0 | 98.90 % | 1.101 % |
| 5 | 13,991,544 | 67.52 % | 32.48 % | 0 |
| 6 / 7 / 8 | sampled | 0 / 62.5 / 0 % | 99.05 / 37.5 / 99.12 % | 0.95 / 0 / 0.88 % |

An odd-weight error whose syndrome equals a valid column is **miscorrected** (a wrong bit is flipped and reported as CE); an
even-weight error that happens to be a codeword is **invisible**. This is a property of every distance-4 code. The weight-3 and
weight-4 figures match those Project 26 published independently. **No reliable classification is claimed beyond weight 2.**

## 8. How the model was verified (four independent implementations)

| implementation | construction | decode |
|---|---|---|
| **RefA** | systematic parity-check matrix H in stored order | column search |
| **RefB** | textbook interleaved Hamming (check bits at 2^k, overall parity at position 0) | "syndrome = XOR of positions of set bits" + overall parity |
| **RefC** | null space of the *logical* H (column x = [1; bin(x)]): Gauss-Jordan elimination, no XOR-of-positions formula | brute-force nearest codeword |
| **P26** | Project 26's `secded_ref.py` (written by a different project, vendored unmodified) | column search |

All four agree on every compared field (class, returned data, corrected stored word, corrected-bit index, syndrome) over: every 1-bit error,
every 2-bit error, every 3-bit error (data = 0), random weight 3–12 patterns, random raw words, and — for K = 8 — the **entire** 2^13 received-word space.
Hand-derivable anchor vectors (no implementation needed):

| data | stored word, `CHK_INV = 0` | why |
|---|---|---|
| `0000000000000000` | `00 0000000000000000` | linear |
| `FFFFFFFFFFFFFFFF` | `FF FFFFFFFFFFFFFFFF` | all-ones data → all-ones word |
| `0000000000000001` | `83 0000000000000001` | d0 at position 3 = `0000011` → c0,c1 = 1; p = 1 ⊕ parity(c) = 1 |
| `8000000000000000` | `C7 8000000000000000` | d63 at position 71 = `1000111` → c = 0x47; p = 1 ⊕ 0 = 1 |
| `0123456789ABCDEF` | `9C 0123456789ABCDEF` | (from the model) |

Golden vector files (`vectors/`, SHA-256 in `reports/math_verification.md`) are generated from RefA after RefB, RefC and P26 agree; the RTL testbenches read them and never compute an expected value from RTL.
