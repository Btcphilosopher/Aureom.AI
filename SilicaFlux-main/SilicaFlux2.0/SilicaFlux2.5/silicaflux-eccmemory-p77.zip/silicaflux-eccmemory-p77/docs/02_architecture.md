# 02 — Architecture

```
                         ┌───────────────────────────── sf_sram_ecc ─────────────────────────────┐
 req (valid/ready) ──►   accept ──► sf_secded_enc ──► ISSUE reg ──► macro (1RW, N bits, no mask)   │
 (we, addr, wdata, be, id)  │  ▲            ▲ write-back (RMW / scrub FIX)                │         │
        scrub port ───►     │  └── bank LOCK FSM ◄── decode stage ◄── [DEC_PIPE reg] ◄──┘ m_rdata │
        init engine ──►     └─► TAG PIPELINE (LAT stages, never stalls) ─► sf_secded_dec ─► response FIFO ─► rsp (valid/ready)
        MBIST raw port ─► (mux in front of the macro)                          └──► event ─► sf_sram_ecc_ras ─► counters / regs / irq / fatal
        fault injection (FI_EN) hooks: write-path mask, read-path mask, stuck-at
```

## 1. Files

| File | Role |
|---|---|
| `rtl/sf_sram_ecc.sv` | **primary RTL** — the wrapper (accept/issue, tag pipeline, decode stage, RMW lock FSM, response FIFO, init engine, MBIST port, events) |
| `rtl/sf_secded_enc.sv`, `sf_secded_dec.sv`, `sf_secded_enc_pipe.sv`, `sf_secded_funcs.svh`, `sf_secded_defs.svh` | encoder (comb + 0/1/2-stage pipelined), decoder, code definition |
| `rtl/sf_sram_ecc_scrub.sv` | optional scrub engine (`SCRUB_EN`) |
| `rtl/sf_sram_ecc_ras.sv` | RAS counters, severity policy, firmware register page |
| `rtl/sf_sram_ecc_fi.sv` | fault injection (`FI_EN`; removed when 0) |
| `rtl/sf_sram_ecc_ram.sv`, `rtl/sf_sram_ecc_sys.sv` | simulation macro model; wrapper + macro for testbenches / formal |

## 2. Encoder / decoder

* **`sf_secded_enc`** — combinational. One XOR tree per check bit (≤ 36 inputs for K = 64) plus the overall-parity tree. Parameters `K`, `INV`. ~169 generic cells (K = 64, Yosys `synth` + `abc`, technology-neutral).
* **`sf_secded_enc_pipe`** — `STAGES` = 0 (comb), 1 (output register), 2 (XOR trees cut per byte lane: stage 1 registers data and per-lane partial parities `R × LANES + LANES`, stage 2 combines). Global enable `en_i` stalls every stage; `vld` travels with the data. Verified against the combinational encoder under random stalls.
* **`sf_secded_dec`** — combinational syndrome + classifier + one-hot locator. Outputs: `data_o` (corrected; *raw stored data on UE*), `cw_corr_o`, `none_o / ce_o / ue_o` (exactly one), `ue_inval_o` (UE because the syndrome names no bit), `err_kind_o` (data / check / parity), `err_pos_o` (stored-bit index), `syn_o = {pe, s}`. On UE the word is **never** modified. ~518 generic cells.
* The wrapper uses the combinational encoder in the accept cycle (request data → `sf_secded_enc` → issue register) and the combinational decoder in the decode stage, with an optional register in front (`DEC_PIPE`). The pipelined encoder is a standalone variant for a retimed write path; it is not instantiated inside the wrapper.

## 3. Latency accounting (verified by test `P9` in all five wrapper configurations, LAT = 1, 2 and 3)

`LAT = RD_LAT + DEC_PIPE` (macro read latency + optional decoder register). Cycles counted from the clock edge that accepts a request.

| Operation | accept → `rsp_valid` (no backpressure) | notes |
|---|---|---|
| read | **LAT + 2** | issue register (1) + macro/decoder (LAT) + response FIFO register (1) |
| full write, `be = 0` no-op, out-of-range | **LAT + 2** | the array is written one cycle after accept; the response takes the same path as a read so **order is preserved** |
| partial write (RMW) | **LAT + 4** | + decode → merge register → write-back → commit |
| bank locked for | accept+1 … accept+**LAT + 2**; next request accepted at accept + **LAT + 3** | |
| sustained throughput | 1 read or full write / cycle | needs `RSP_DEPTH ≥ LAT + 2` and a consumer that keeps up |

Examples: `LAT = 1` → read 3, RMW response 5, lock 3 cycles. `LAT = 3` (RD_LAT 2 + DEC_PIPE) → read 5, RMW response 7, lock 5 cycles. A partial write therefore costs LAT + 3 cycles of bank time against 1 for a full write.

## 4. Partial writes — read-modify-write

Sequence (the numbering of the brief): (1) **lock** the bank at accept; (2) read the old codeword; (3) **decode and validate** it; (4) **merge** the enabled bytes into the *corrected* data; (5) **re-encode the complete word**; (6) **commit** the new codeword; (7) release the lock; (8) return completion.

* While locked, **no other access is accepted and nothing but the write-back may load the issue stage** (assertion `SF_ASSERT`, proved over all reachable states within the bounded-model-checking depth and checked on every simulation cycle). Reads accepted *before* the RMW are already in the pipeline and complete normally; responses stay in acceptance order.
* **Untouched bytes are never corrupted.** They are taken from the *corrected* old word; a single-bit error in an untouched byte is therefore repaired by the re-encode, not baked in (mutant M01 shows the testbench would catch the opposite).
* **Policy for an uncorrectable old word — ABORT.** The word is left **exactly as found** (still uncorrectable, so the fault stays visible), the response carries `err = 1, ue = 1`, and a UE event (`src = RMW`) is raised. The bytes the old word would have contributed are unknown, so no merged word is ever stored. A full-word write never reads the old word and so **repairs** such a word. (Alternative policies — storing a poisoned word — need a poison bit and are intentionally not implemented here.)
* `be = 0` → acknowledged no-op; an all-ones `be` is a full write (no read).
* Response flag for a successful RMW: `rsp_ce = 1` iff the old word had a corrected single-bit error.

## 5. Errors seen by a reader

| stored word | `rsp_rdata` | `rsp_err` | `rsp_ue` | `rsp_ce` | RAS event |
|---|---|---|---|---|---|
| clean | data | 0 | 0 | 0 | — |
| 1-bit error (data, check or parity bit) | **corrected** data | 0 | 0 | 1 | CE |
| 2-bit error | stored data **uncorrected** (`UE_DATA_ZERO = 0`) or 0 (`= 1`) | **1** | **1** | 0 | UE |
| ≥ 3-bit error | not guaranteed (§7 of `01_math_model.md`) | | | | |
| out-of-range address | 0 | 1 | 0 | 0 | — |

Consumers **must** gate use of `rsp_rdata` with `rsp_err`. Reads never write corrections back; a latent single-bit error is corrected — and counted — on **every** read until scrubbed or rewritten.

## 6. Scrub (`SCRUB_EN`)

`sf_sram_ecc_scrub` walks the address space (wrapping), one word at a time:

1. **CHECK** — plain read + decode.
2. single-bit error and `fix_en` → **FIX** — an atomic locked read-decode-write-back performed by the wrapper (the word is **re-read under the lock**).
3. **VERIFY** — plain read after the FIX. Still a single-bit error ⇒ **persistent** (hard) fault.
4. next address (pass counter at wrap).

* **Uncorrectable words are never written.** They are counted and recorded (`ue_addr`); with `ue_halt_i` the engine halts at the word until `resume_i` skips it.
* **Arbitration with normal traffic** (in the wrapper): functional requests win; a scrub request waits at most `SCRUB_MAX_WAIT` cycles, then takes the next free slot (tested: bounded wait behind back-to-back reads; tested under 2,400 random operations). The scrubber **never pre-empts** an access in flight and a FIX holds the same lock as an RMW, so *scrubbing cannot interfere with active writes*: a functional write is strictly before or strictly after the FIX, never in between. `en_i` is sampled only between words, so a locked FIX is never abandoned.
* Counters: words, `ce_found`, `ue_found`, `fixed`, `persistent`, `passes`. With `SCRUB_EN = 0` the same scrub port is exposed as `xscr_*` for an external master.

## 7. Initialisation, reset, MBIST

* **Init engine** — writes the *valid* all-zero word (`encode(0) ^ CHK_INV`) to every address after reset (`INIT_ON_RESET`), on `init_start_i`, and after the raw MBIST port is released (`REINIT_AFTER_TEST`); `req_ready = 0` meanwhile. It first waits until nothing is in flight.
* **Reset** clears all control state (lock, FIFO, tag pipeline, events, RAS). The **array itself is not reset** (a reset would prevent RAM inference): with `INIT_ON_RESET = 0` contents survive a warm reset. A reset that cuts an RMW leaves the word either entirely old or entirely merged — tested at every cut point.
* **MBIST port** — `tst_req_i` quiesces the wrapper (accepts stop immediately, in-flight work drains), then `tst_grant_o = 1` and the macro is driven with raw N-bit words (data **and** check bits are testable). On release the init engine restores a valid array.

## 8. Fault injection (disabled unless authorised)

`FI_EN = 0` (the wrapper default): **no injection logic exists** — the block is compiled to constants. `FI_EN = 1`: a command is honoured only while `fi_auth_i` (hardware authorisation, e.g. a debug-unlock fuse that the integrator ties low in production) **and** `fi_enable_i` (software enable) are both high; a refused command raises `fi_blocked_o` and increments a saturating counter and has **no other effect**.

| Mode | Effect | Models |
|---|---|---|
| `SF_ECC_FI_WRITE` | one-shot XOR mask on the stored word of the next matching write | a **latent** array error that persists until rewritten or scrubbed |
| `SF_ECC_FI_READ` | one-shot XOR mask on the raw word of the next matching read; array untouched | a **transient** error, seen once |
| `SF_ECC_FI_STUCK` | `(raw & ~mask) \| (val & mask)` on every read of an address until cleared | a **hard** fault that survives write-back — *corrected-error persistence* |

The mask spans the whole stored word, so single / double, data-only / ECC-only / parity-only errors are just different masks. Re-arming a one-shot that is still in use is refused.

## 9. Parameters (wrapper)

`K` (multiple of 8), `DEPTH`, `RD_LAT`, `DEC_PIPE`, `RSP_DEPTH`, `ID_W`, `CHK_INV`, `UE_DATA_ZERO`, `INIT_ON_RESET`, `REINIT_AFTER_TEST`, `TEST_EN`, `SCRUB_EN`, `SCRUB_MAX_WAIT`, `FI_EN`. Derived (do not override): `R, N, IW, AW, BE_W, SYN_W`.
Back-pressure is **credit based**: one credit per accepted functional request, returned when its response is consumed; `req_ready` drops when `RSP_DEPTH` responses are outstanding, so the response FIFO can never overflow.

## 10. Port-level contract (functional port)

* `req_ready` never depends on `req_valid` or `rsp_ready` (no combinational loops through the functional channels). It depends on registered state and — only for the starvation guard — on whether a scrub request is pending: a register output for the internal engine, but the **input** `xscr_req_valid` when an external scrub master is used, so with an external master `req_ready` has a combinational path from `xscr_req_valid`.
* A presented response (`rsp_valid && !rsp_ready`) stays valid and **unchanged** (tested + formal B2).
* Exactly one response per accepted request, in acceptance order (tested + formal B1).
* Address `≥ DEPTH` (non-power-of-two depth) → error response, no macro access, no side effect.

## 11. Integration with a real macro

`m_en, m_we, m_addr[AW], m_wdata[N], m_rdata[N]` is a plain single-port synchronous RAM: one operation per cycle, **no write mask** (a word is always replaced whole, so data and check bits can never get out of step), read data `RD_LAT` cycles after a read. Connect it to `silicaflux-sramlib`'s `sram_backend_1rw` with `MASK_WIDTH = 1` or to an ASIC macro with a registered output. **Do not put a macro that has its own ECC under this wrapper** (double encoding). This contract was written from the documentation; see `00_audit.md §5`.
