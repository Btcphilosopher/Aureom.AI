// =============================================================================
// SilicaFlux Project 77 :: tb_sf_sram_ecc
// Self-checking testbench for the ECC SRAM wrapper (sf_sram_ecc_sys).
//
// SCOREBOARD (transaction level, independent of the RTL's ECC logic):
//   exp_mem[a]   the 64-bit word the memory must hold
//   err_mask[a]  the stored-bit flips currently present in the array word (injected
//                errors); a read of a word with weight-0/1/2 error must return
//                clean / CE (data corrected) / UE (flagged, raw data, not "corrected")
// Every accepted request is applied to the model IN ACCEPTANCE ORDER and its
// response + RAS event are predicted; responses and events are compared as they
// appear.  Syndromes / corrected-bit indices come from the PYTHON reference tables
// (vectors/syn_single.hex, syn_double.hex), never from the RTL.
//
// Compile-time configuration (-D): TB_K TB_DEPTH TB_RDLAT TB_DECPIPE TB_RSPD TB_INV
//   TB_FI TB_SCRUB TB_INIT TB_UEZ TB_VEC (vector dir, string)
// =============================================================================
`timescale 1ns/1ps
`include "sf_secded_defs.svh"
`ifndef TB_K
  `define TB_K 64
`endif
`ifndef TB_DEPTH
  `define TB_DEPTH 48
`endif
`ifndef TB_RDLAT
  `define TB_RDLAT 1
`endif
`ifndef TB_DECPIPE
  `define TB_DECPIPE 0
`endif
`ifndef TB_RSPD
  `define TB_RSPD 8
`endif
`ifndef TB_INV
  `define TB_INV 3
`endif
`ifndef TB_FI
  `define TB_FI 0
`endif
`ifndef TB_SCRUB
  `define TB_SCRUB 0
`endif
`ifndef TB_INIT
  `define TB_INIT 1
`endif
`ifndef TB_UEZ
  `define TB_UEZ 0
`endif
`ifndef TB_VEC
  `define TB_VEC "vectors"
`endif
`ifndef TB_TESTEN
  `define TB_TESTEN 1
`endif
`ifndef TB_MAXWAIT
  `define TB_MAXWAIT 8
`endif
`ifndef TB_DUMP
  `define TB_DUMP "sim/mem_dump.txt"
`endif

module tb_sf_sram_ecc;
  localparam int K = `TB_K, DEPTH = `TB_DEPTH, RD_LAT = `TB_RDLAT, DEC_PIPE = `TB_DECPIPE, RSP_DEPTH = `TB_RSPD;
  localparam int TEST_EN = `TB_TESTEN;
  localparam int ID_W = 4, CHK_INV = `TB_INV, FI_EN = `TB_FI, SCRUB_EN = `TB_SCRUB, INIT_ON_RESET = `TB_INIT, UEZ = `TB_UEZ;
  localparam int R = $clog2(K + $clog2(K + 1) + 1), N = K + R + 1, IW = $clog2(N), AW = $clog2(DEPTH), BE_W = K / 8, SYN_W = R + 1;
  localparam int LAT = RD_LAT + DEC_PIPE;
  localparam int AMAX = (1 << AW);                 // addresses >= DEPTH are out of range when DEPTH is not a power of two
  localparam int B_A = K - 14, B_B = K - 4, B_C = K - 24;          // data-bit positions valid for K = 32 and K = 64
  localparam logic [BE_W-1:0] BE_LO   = {{(BE_W/2){1'b0}}, {(BE_W/2){1'b1}}};   // lower half of the bytes
  localparam logic [BE_W-1:0] BE_HI   = {{(BE_W/2){1'b1}}, {(BE_W/2){1'b0}}};
  localparam logic [BE_W-1:0] BE_ONE  = {{(BE_W-1){1'b0}}, 1'b1};

  // ------------------------------------------------------------------ clock / reset
  logic clk = 0;
  logic rst_n = 0;
  always #5 clk = ~clk;
  int cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ------------------------------------------------------------------ DUT signals (names match the ports for .*)
  logic              req_valid = 0;
  wire               req_ready;
  logic              req_we = 0;
  logic [AW-1:0]     req_addr = '0;
  logic [K-1:0]      req_wdata = '0;
  logic [BE_W-1:0]   req_be = '0;
  logic [ID_W-1:0]   req_id = '0;
  wire               rsp_valid;
  logic              rsp_ready = 1;
  wire  [K-1:0]      rsp_rdata;
  wire               rsp_err, rsp_ue, rsp_ce, rsp_we;
  wire  [ID_W-1:0]   rsp_id;
  logic              xscr_req_valid = 0;
  wire               xscr_req_ready;
  logic [1:0]        xscr_req_op = '0;
  logic [AW-1:0]     xscr_req_addr = '0;
  logic [SYN_W-1:0]  xscr_req_syn = '0;
  wire               xscr_rsp_valid;
  wire  [1:0]        xscr_rsp_op;
  wire               xscr_rsp_ce, xscr_rsp_ue;
  wire  [SYN_W-1:0]  xscr_rsp_syn;
  wire  [AW-1:0]     xscr_rsp_addr;
  logic              scrub_en_i = 0;
  logic [15:0]       scrub_interval_i = 0;
  logic              scrub_fix_en_i = 1;
  logic              scrub_ue_halt_i = 0;
  logic              scrub_resume_i = 0;
  wire               scrub_busy_o, scrub_halted_o, scrub_pass_o;
  wire  [AW-1:0]     scrub_addr_o, scrub_ue_addr_o;
  wire  [31:0]       scrub_words_o, scrub_ce_found_o, scrub_ue_found_o, scrub_fixed_o, scrub_persistent_o, scrub_passes_o;
  logic              init_start_i = 0;
  wire               init_busy_o, quiet_o, lock_o;
  logic              tst_req_i = 0;
  wire               tst_grant_o;
  logic              tst_en_i = 0, tst_we_i = 0;
  logic [AW-1:0]     tst_addr_i = '0;
  logic [N-1:0]      tst_wdata_i = '0;
  wire  [N-1:0]      tst_rdata_o;
  logic              fi_auth_i = 0, fi_enable_i = 0, fi_cmd_valid_i = 0;
  logic [1:0]        fi_cmd_mode_i = '0;
  logic [N-1:0]      fi_cmd_mask_i = '0, fi_cmd_val_i = '0;
  logic [AW-1:0]     fi_cmd_addr_i = '0;
  logic              fi_cmd_addr_en_i = 0, fi_clear_i = 0;
  wire               fi_armed_o, fi_stuck_o, fi_fired_o, fi_blocked_o, fi_busy_o;
  wire  [15:0]       fi_blocked_cnt_o;
  wire               ev_valid_o, ev_ce_o, ev_ue_o, ev_persist_o;
  wire  [1:0]        ev_src_o;
  wire  [AW-1:0]     ev_addr_o;
  wire  [SYN_W-1:0]  ev_syn_o;
  wire  [IW-1:0]     ev_pos_o;
  logic              ras_reg_sel_i = 0, ras_reg_we_i = 0;
  logic [7:0]        ras_reg_addr_i = '0;
  logic [31:0]       ras_reg_wdata_i = '0;
  wire  [31:0]       ras_reg_rdata_o;
  wire               ras_reg_err_o;
  wire  [31:0]       ce_count_o, ue_count_o, persist_count_o;
  wire  [AW-1:0]     last_addr_o;
  wire  [SYN_W-1:0]  last_syn_o;
  wire               ce_seen_o, ue_seen_o, irq_warn_o, irq_ue_o, fatal_req_o;

  sf_sram_ecc_sys #(
    .K(K), .DEPTH(DEPTH), .RD_LAT(RD_LAT), .DEC_PIPE(DEC_PIPE), .RSP_DEPTH(RSP_DEPTH), .ID_W(ID_W),
    .CHK_INV(CHK_INV), .UE_DATA_ZERO(UEZ), .INIT_ON_RESET(INIT_ON_RESET), .REINIT_AFTER_TEST(1), .TEST_EN(`TB_TESTEN),
    .SCRUB_EN(SCRUB_EN), .SCRUB_MAX_WAIT(`TB_MAXWAIT), .FI_EN(FI_EN), .RAM_INIT_ZERO(1)
  ) dut (.*);

  // ------------------------------------------------------------------ bookkeeping
  int errors = 0;
  int checks = 0;
  string vec_dir;
  string dumpf;
  string fname_tmp;
  string det_tmp;
  task automatic fail(input string msg);
    errors++;
    if (errors <= 30) $display("MISMATCH @%0d: %s", cyc, msg);
  endtask
  task automatic check(input bit cond, input string msg);
    checks++;
    if (!cond) fail(msg);
  endtask

  // ------------------------------------------------------------------ coverage counters (printed as COV lines)
  int cov_rd_w[3], cov_rmw_w[3], cov_wr, cov_nop, cov_oor, cov_kind[3], cov_pair, cov_fix_hit, cov_lock_cycles;
  int cov_stall_max, cov_bp_full, cov_scrub_force, cov_scrub_func_wait, cov_ev_ce, cov_ev_ue, cov_ev_per;
  int cov_fi[4], cov_fi_block, cov_tst, cov_reset, cov_halt, cov_reg_rd, cov_reg_wr, cov_reg_err, cov_fatal;
  int cov_rmw_abort, cov_rmw_ce_kind[3], cov_zero_word_ue, cov_ones_word_ue;

  // ------------------------------------------------------------------ reference tables (from the Python model)
  int syn1 [0:N-1];
  int syn2 [0:N-1][0:N-1];
  logic [N-1:0] enc0_exp;                           // encode(0) expected from the Python vectors
  initial begin
    int fd, rc, i, j, s;
    logic [N-1:0] cw0;
    logic [K-1:0] d0;
    if (!$value$plusargs("VEC=%s", vec_dir)) vec_dir = `TB_VEC;
    fname_tmp = {vec_dir, "/syn_single.hex"};
    fd = $fopen(fname_tmp, "r");
    if (fd == 0) $fatal(1, "missing %s/syn_single.hex", vec_dir);
    while (!$feof(fd)) begin rc = $fscanf(fd, "%h %h\n", i, s); if (rc == 2) syn1[i] = s; end
    $fclose(fd);
    fname_tmp = {vec_dir, "/syn_double.hex"};
    fd = $fopen(fname_tmp, "r");
    if (fd == 0) $fatal(1, "missing %s/syn_double.hex", vec_dir);
    while (!$feof(fd)) begin rc = $fscanf(fd, "%h %h %h\n", i, j, s); if (rc == 3) begin syn2[i][j] = s; syn2[j][i] = s; end end
    $fclose(fd);
    fname_tmp = (CHK_INV == 0) ? {vec_dir, "/enc_inv0.hex"} : {vec_dir, "/enc_invd.hex"};
    fd = $fopen(fname_tmp, "r");
    if (fd == 0) $fatal(1, "missing encode vectors");
    rc = $fscanf(fd, "%h %h\n", d0, cw0);
    if (d0 !== '0) $fatal(1, "first encode vector is not data=0");
    enc0_exp = cw0;
    $fclose(fd);
  end

  // ------------------------------------------------------------------ model state
  logic [K-1:0] exp_mem  [0:AMAX-1];
  logic [N-1:0] err_mask [0:AMAX-1];
  logic [N-1:0] rd_once_mask = '0;  bit rd_once_armed = 0;        // transient (read-path) injection, consumed by the next read
  bit           stuck_on = 0;  logic [N-1:0] stuck_mask = '0, stuck_val = '0;  int stuck_addr = 0;  bit stuck_addr_en = 0;
  bit           ev_check_en = 1;                                  // 0 = events are not predicted (races with the scrub engine)
  bit           ce_tolerant = 0;                                  // 1 = a weight-1 read may legally report ce = 0 or 1
  int           exp_ce = 0, exp_ue = 0;
  bit           force_ue [0:AMAX-1];                              // word known uncorrectable by construction (dead word line / powered-up zero array)
  bit           alt_armed = 0;  logic [K-1:0] alt_data;           // next read may return alt_data OR the model data (atomicity checks)
  logic [K-1:0] last_rsp_data;

  function automatic int popc(input logic [N-1:0] m);
    int c; c = 0;
    for (int i = 0; i < N; i++) if (m[i]) c++;
    return c;
  endfunction
  function automatic logic [N-1:0] bm(input int b);     // one-hot stored-bit mask (explicit width: no context-dependent shifts)
    logic [N-1:0] m;
    m = '0; m[b] = 1'b1;
    return m;
  endfunction
  function automatic int lowbit(input logic [N-1:0] m);
    for (int i = 0; i < N; i++) if (m[i]) return i;
    return -1;
  endfunction
  function automatic int highbit(input logic [N-1:0] m);
    for (int i = N-1; i >= 0; i--) if (m[i]) return i;
    return -1;
  endfunction
  function automatic int syn_of(input logic [N-1:0] m);
    int w;
    w = popc(m);
    if (w == 1) return syn1[lowbit(m)];
    if (w == 2) return syn2[lowbit(m)][highbit(m)];
    return -1;
  endfunction
  function automatic logic [N-1:0] eff_mask(input int a);
    logic [N-1:0] peek, raw, code;
    if (!stuck_on) return err_mask[a] ^ (rd_once_armed ? rd_once_mask : '0);
    peek = dut.u_ram.mem[a];
    raw  = peek ^ (rd_once_armed ? rd_once_mask : '0);
    if (!stuck_addr_en || stuck_addr == a) raw = (raw & ~stuck_mask) | (stuck_val & stuck_mask);
    code = peek ^ err_mask[a];
    return raw ^ code;
  endfunction

  task automatic model_zero_mem();                                  // memory re-initialised to valid zero; RAS counters untouched
    for (int a = 0; a < AMAX; a++) begin exp_mem[a] = '0; err_mask[a] = '0; force_ue[a] = 1'b0; end
  endtask
  task automatic model_clear();
    for (int a = 0; a < AMAX; a++) begin exp_mem[a] = '0; err_mask[a] = '0; force_ue[a] = 1'b0; end
    exp_ce = 0; exp_ue = 0;
  endtask
  initial model_clear();

  // ------------------------------------------------------------------ expected response / event queues
  localparam int QN = 8192;
  logic [K-1:0] eq_data [0:QN-1];
  bit           eq_we [0:QN-1], eq_err [0:QN-1], eq_ue [0:QN-1], eq_ce [0:QN-1], eq_tol [0:QN-1], eq_nodata [0:QN-1], eq_alt_v [0:QN-1];
  logic [K-1:0] eq_alt_d [0:QN-1];
  logic [ID_W-1:0] eq_id [0:QN-1];
  int           eq_cyc [0:QN-1];
  int           eq_head = 0, eq_tail = 0, eq_cnt = 0;

  int           ee_kind [0:QN-1], ee_src [0:QN-1], ee_addr [0:QN-1], ee_syn [0:QN-1], ee_pos [0:QN-1];
  int           ee_head = 0, ee_tail = 0, ee_cnt = 0;

  task automatic push_resp(input bit we, input logic [K-1:0] d, input bit err, input bit ue, input bit ce, input bit tol, input logic [ID_W-1:0] id);
    eq_we[eq_tail] = we; eq_data[eq_tail] = d; eq_err[eq_tail] = err; eq_ue[eq_tail] = ue; eq_ce[eq_tail] = ce;
    eq_tol[eq_tail] = tol; eq_id[eq_tail] = id; eq_cyc[eq_tail] = cyc; eq_nodata[eq_tail] = 1'b0; eq_alt_v[eq_tail] = 1'b0;
    eq_tail = (eq_tail + 1) % QN; eq_cnt++;
  endtask
  task automatic mark_last_nodata();  eq_nodata[(eq_tail + QN - 1) % QN] = 1'b1; endtask
  task automatic mark_last_alt(input logic [K-1:0] d);  eq_alt_v[(eq_tail + QN - 1) % QN] = 1'b1; eq_alt_d[(eq_tail + QN - 1) % QN] = d; endtask
  task automatic push_ev(input int kind, input int src, input int a, input logic [N-1:0] m);
    if (ev_check_en) begin
      ee_kind[ee_tail] = kind; ee_src[ee_tail] = src; ee_addr[ee_tail] = a;
      ee_syn[ee_tail] = syn_of(m); ee_pos[ee_tail] = (kind == 0) ? lowbit(m) : 0;
      ee_tail = (ee_tail + 1) % QN; ee_cnt++;
    end
    if (kind == 0) exp_ce++; else exp_ue++;
  endtask

  // ------------------------------------------------------------------ monitor: accept -> model + predictions
  logic [K-1:0] bmask_f, rawd;
  function automatic logic [K-1:0] bytemask(input logic [BE_W-1:0] be);
    logic [K-1:0] m;
    for (int i = 0; i < BE_W; i++) m[8*i +: 8] = {8{be[i]}};
    return m;
  endfunction

  always @(posedge clk) if (rst_n && req_valid && req_ready) begin : acc
    int a, w, kidx;
    logic [N-1:0] eff;
    a = req_addr;
    if (a >= DEPTH) begin
      cov_oor++;
      push_resp(req_we, '0, 1'b1, 1'b0, 1'b0, 1'b0, req_id);
    end else if (!req_we && force_ue[a]) begin
      push_resp(0, '0, 1, 1, 0, 0, req_id); mark_last_nodata();
      push_ev(1, 0, a, '0);
    end else if (!req_we) begin
      eff = eff_mask(a); w = popc(eff);
      if (rd_once_armed) rd_once_armed = 0;
      cov_rd_w[(w > 2) ? 2 : w]++;
      if (w == 0) begin
        push_resp(0, exp_mem[a], 0, 0, 0, 0, req_id);
        if (alt_armed) begin mark_last_alt(alt_data); alt_armed = 0; end
      end
      else if (w == 1) begin
        push_resp(0, exp_mem[a], 0, 0, 1, ce_tolerant, req_id);
        push_ev(0, 0, a, eff);
        kidx = lowbit(eff);
        kidx = (kidx < K) ? 0 : (kidx < K + R) ? 1 : 2;
        cov_kind[kidx]++;
      end else if (w == 2) begin
        rawd = exp_mem[a] ^ eff[K-1:0];                                 // the stored, UNCORRECTED data bits
        if (UEZ != 0) rawd = '0;
        push_resp(0, rawd, 1, 1, 0, 0, req_id);
        push_ev(1, 0, a, eff);
      end else $fatal(1, "TB: weight %0d error pattern outside the supported SECDED range", w);
    end else if (&req_be) begin                                     // full write: replaces the word
      cov_wr++;
      exp_mem[a] = req_wdata; err_mask[a] = '0; force_ue[a] = 1'b0;
      push_resp(1, '0, 0, 0, 0, 0, req_id);
    end else if (req_be == '0) begin                                // zero byte enables: acknowledged no-op
      cov_nop++;
      push_resp(1, '0, 0, 0, 0, 0, req_id);
    end else if (force_ue[a]) begin                                 // RMW onto a dead word: abort
      cov_rmw_abort++;
      push_resp(1, '0, 1, 1, 0, 0, req_id);
      push_ev(1, 1, a, '0);
    end else begin                                                  // partial write: RMW
      eff = eff_mask(a); w = popc(eff);
      if (rd_once_armed) rd_once_armed = 0;
      cov_rmw_w[(w > 2) ? 2 : w]++;
      if (w <= 1) begin
        bmask_f = bytemask(req_be);
        exp_mem[a] = (exp_mem[a] & ~bmask_f) | (req_wdata & bmask_f);
        err_mask[a] = '0;
        push_resp(1, '0, 0, 0, (w == 1), ce_tolerant, req_id);
        if (w == 1) begin
          push_ev(0, 1, a, eff);
          kidx = lowbit(eff);
          kidx = (kidx < K) ? 0 : (kidx < K + R) ? 1 : 2;
          cov_rmw_ce_kind[kidx]++;
        end
      end else if (w == 2) begin                                    // ABORT policy: word and error left exactly as found
        cov_rmw_abort++;
        push_resp(1, '0, 1, 1, 0, 0, req_id);
        push_ev(1, 1, a, eff);
      end else $fatal(1, "TB: weight %0d error pattern outside the supported SECDED range", w);
    end
  end

  // ------------------------------------------------------------------ monitor: responses
  logic        prev_stall = 0;
  logic [K+4+ID_W-1:0] prev_payload;
  int          out_max = 0;
  int          pops = 0, accepts = 0;
  always @(posedge clk) begin
    if (rst_n) begin
      // stability under backpressure
      if (prev_stall) begin
        check(rsp_valid, "response dropped while stalled");
        check({rsp_rdata, rsp_err, rsp_ue, rsp_ce, rsp_we, rsp_id} === prev_payload, "response payload changed while stalled");
      end
      prev_stall   <= rsp_valid && !rsp_ready;
      prev_payload <= {rsp_rdata, rsp_err, rsp_ue, rsp_ce, rsp_we, rsp_id};
      if (req_valid && req_ready) accepts++;
      if (rsp_valid && rsp_ready) begin
        pops++;
        if (eq_cnt == 0) fail("unexpected response (nothing outstanding)");
        else begin
          checks++;
          if (rsp_we !== eq_we[eq_head]) fail($sformatf("rsp_we exp=%b got=%b", eq_we[eq_head], rsp_we));
          if (rsp_id !== eq_id[eq_head]) fail($sformatf("rsp_id exp=%0d got=%0d (ordering?)", eq_id[eq_head], rsp_id));
          if (rsp_err !== eq_err[eq_head]) fail($sformatf("rsp_err exp=%b got=%b id=%0d", eq_err[eq_head], rsp_err, rsp_id));
          if (rsp_ue !== eq_ue[eq_head]) fail($sformatf("rsp_ue exp=%b got=%b id=%0d", eq_ue[eq_head], rsp_ue, rsp_id));
          if (!eq_tol[eq_head] && rsp_ce !== eq_ce[eq_head]) fail($sformatf("rsp_ce exp=%b got=%b id=%0d", eq_ce[eq_head], rsp_ce, rsp_id));
          if (eq_tol[eq_head] && eq_ce[eq_head] === 1'b0 && rsp_ce !== 1'b0) fail("rsp_ce set on a word that must be clean");
          if (!eq_we[eq_head] && !eq_nodata[eq_head] && (rsp_rdata !== eq_data[eq_head]) && !(eq_alt_v[eq_head] && rsp_rdata === eq_alt_d[eq_head]))
            fail($sformatf("rsp_rdata exp=%h got=%h id=%0d", eq_data[eq_head], rsp_rdata, rsp_id));
          last_rsp_data = rsp_rdata;
          if (rsp_ce && rsp_err) fail("rsp_ce together with rsp_err");
          if (rsp_ue && !rsp_err) fail("rsp_ue without rsp_err");
        end
        eq_head = (eq_head + 1) % QN; if (eq_cnt > 0) eq_cnt--;
      end
      // outstanding never exceeds the response credit
      if (accepts - pops > out_max) out_max = accepts - pops;
      if (accepts - pops > RSP_DEPTH) fail($sformatf("more outstanding responses (%0d) than RSP_DEPTH", accepts - pops));
      if (!req_ready && (accepts - pops) >= RSP_DEPTH) cov_bp_full++;
      // events
      if (ev_valid_o) begin
        if (ev_check_en) begin
          checks++;
          if (ee_cnt == 0) fail($sformatf("unexpected RAS event kind ce=%b ue=%b persist=%b addr=%0d", ev_ce_o, ev_ue_o, ev_persist_o, ev_addr_o));
          else begin
            if ((ev_ce_o ? 1 : 0) + (ev_ue_o ? 1 : 0) + (ev_persist_o ? 1 : 0) != 1) fail("event kind not one-hot");
            if (ee_kind[ee_head] == 0 && !ev_ce_o) fail($sformatf("event exp CE got ce=%b ue=%b", ev_ce_o, ev_ue_o));
            if (ee_kind[ee_head] == 1 && !ev_ue_o) fail($sformatf("event exp UE got ce=%b ue=%b", ev_ce_o, ev_ue_o));
            if (ee_kind[ee_head] == 2 && !ev_persist_o) fail("event exp PERSIST");
            if (ev_src_o !== 2'(ee_src[ee_head])) fail($sformatf("event src exp=%0d got=%0d", ee_src[ee_head], ev_src_o));
            if (ev_addr_o !== AW'(ee_addr[ee_head])) fail($sformatf("event addr exp=%0d got=%0d", ee_addr[ee_head], ev_addr_o));
            if (ee_syn[ee_head] >= 0 && ev_syn_o !== SYN_W'(ee_syn[ee_head])) fail($sformatf("event syndrome exp=%h got=%h (addr %0d)", ee_syn[ee_head], ev_syn_o, ev_addr_o));
            if (ee_kind[ee_head] == 0 && ev_pos_o !== IW'(ee_pos[ee_head])) fail($sformatf("event pos exp=%0d got=%0d", ee_pos[ee_head], ev_pos_o));
            ee_head = (ee_head + 1) % QN; ee_cnt--;
          end
        end
        if (ev_ce_o) cov_ev_ce++;
        if (ev_ue_o) cov_ev_ue++;
        if (ev_persist_o) cov_ev_per++;
      end
      if (init_busy_o && req_ready) fail("req_ready high while the init engine is busy");
      if (tst_grant_o && req_ready) fail("req_ready high while the MBIST port is granted");
      if (lock_o) cov_lock_cycles++;
      if (dut.u_ecc.scr_force && dut.u_ecc.scr_v) cov_scrub_force++;
    end
  end

  // ------------------------------------------------------------------ response consumer modes
  int rsp_mode = 0;           // 0 always ready, 1 random 50 %, 2 long stalls, 3 never ready
  int stall_run = 0;
  always @(negedge clk) begin
    case (rsp_mode)
      0: rsp_ready <= 1'b1;
      1: rsp_ready <= ($urandom_range(0, 1) == 1);
      2: begin
           if (stall_run > 0) begin stall_run--; rsp_ready <= 1'b0; end
           else begin rsp_ready <= 1'b1; if ($urandom_range(0, 9) == 0) stall_run = $urandom_range(RSP_DEPTH * 2, RSP_DEPTH * 4); end
         end
      default: rsp_ready <= 1'b0;
    endcase
  end

  // ------------------------------------------------------------------ driver tasks
  task automatic issue(input bit we, input int a, input logic [K-1:0] d, input logic [BE_W-1:0] be, input logic [ID_W-1:0] id);
    @(negedge clk);
    req_valid = 1; req_we = we; req_addr = a[AW-1:0]; req_wdata = d; req_be = be; req_id = id;
    do @(posedge clk); while (!req_ready);
    #1 req_valid = 0;
  endtask
  logic [ID_W-1:0] nid = 0;
  task automatic wr_full(input int a, input logic [K-1:0] d);   issue(1, a, d, {BE_W{1'b1}}, nid); nid++; endtask
  task automatic wr_part(input int a, input logic [K-1:0] d, input logic [BE_W-1:0] be); issue(1, a, d, be, nid); nid++; endtask
  task automatic rd(input int a);                                issue(0, a, '0, '0, nid); nid++; endtask

  task automatic drain();
    int guard;
    guard = 0;
    while ((eq_cnt != 0 || !quiet_o || lock_o) && guard < 100000) begin @(posedge clk); guard++; end
    if (guard >= 100000) fail("drain timeout");
    repeat (LAT + 6) @(posedge clk);        // let the last event / scrub result settle
  endtask

  task automatic inject(input int a, input logic [N-1:0] m);    // latent stored error (backdoor + model); call when drained
    dut.u_ram.mem[a] = dut.u_ram.mem[a] ^ m;
    err_mask[a] = err_mask[a] ^ m;
  endtask
  task automatic heal_model(input int a); err_mask[a] = '0; endtask

  function automatic logic [K-1:0] rnd_data();
    logic [K-1:0] d;
    for (int i = 0; i < K; i += 32) d[i +: 32] = $urandom();
    return d;
  endfunction
  function automatic logic [BE_W-1:0] rnd_pbe();                // never 0 and never all-ones: always a true partial write (RMW)
    logic [BE_W-1:0] b;
    b = $urandom();
    while (b == '0 || b == {BE_W{1'b1}}) b = $urandom();
    return b;
  endfunction
  function automatic logic [BE_W-1:0] rnd_be();
    logic [BE_W-1:0] b;
    b = $urandom();
    return b;
  endfunction

  task automatic do_reset(input int n);
    @(negedge clk); rst_n = 0; req_valid = 0;
    repeat (n) @(negedge clk);
    cov_reset++;
    eq_head = 0; eq_tail = 0; eq_cnt = 0; ee_head = 0; ee_tail = 0; ee_cnt = 0; accepts = 0; pops = 0; prev_stall = 0;
    if (INIT_ON_RESET != 0) model_clear();
    exp_ce = 0; exp_ue = 0; rd_once_armed = 0; alt_armed = 0;
    rst_n = 1;
  endtask
  task automatic wait_init();
    int guard; guard = 0;
    while (init_busy_o && guard < 100000) begin @(posedge clk); guard++; end
    repeat (4) @(posedge clk);
  endtask

  task automatic expect_counts(input string tag);
    check(ce_count_o === 32'(exp_ce), $sformatf("%s: ce_count exp=%0d got=%0d", tag, exp_ce, ce_count_o));
    check(ue_count_o === 32'(exp_ue), $sformatf("%s: ue_count exp=%0d got=%0d", tag, exp_ue, ue_count_o));
    if (ev_check_en) check(ee_cnt == 0, $sformatf("%s: %0d predicted events never arrived", tag, ee_cnt));
  endtask

  // scoreboard-checked read of the whole memory (all words must match the model)
  task automatic read_all();
    for (int a = 0; a < DEPTH; a++) rd(a);
    drain();
  endtask

  // ------------------------------------------------------------------ register helpers (RAS page)
  logic [31:0] reg_q;
  bit          reg_e;
  task automatic reg_read(input int off);
    @(negedge clk); ras_reg_sel_i = 1; ras_reg_we_i = 0; ras_reg_addr_i = off[7:0];
    #1; reg_q = ras_reg_rdata_o; reg_e = ras_reg_err_o;
    @(negedge clk); ras_reg_sel_i = 0;
    cov_reg_rd++; if (reg_e) cov_reg_err++;
  endtask
  task automatic reg_write(input int off, input logic [31:0] v);
    @(negedge clk); ras_reg_sel_i = 1; ras_reg_we_i = 1; ras_reg_addr_i = off[7:0]; ras_reg_wdata_i = v;
    #1; reg_e = ras_reg_err_o;
    @(negedge clk); ras_reg_sel_i = 0; ras_reg_we_i = 0;
    cov_reg_wr++; if (reg_e) cov_reg_err++;
  endtask

  // ------------------------------------------------------------------ scrub engine: run until exactly n passes are complete
  // (enable is dropped while the LAST word of pass n is in flight -- address = last AND busy; with a non-zero interval the engine
  //  advances the address first and then idles, so the address alone is not enough -- so no word of pass n+1 is started)
  task automatic scrub_run_to(input int n);
    int guard; guard = 0;
    @(negedge clk); scrub_en_i = 1;
    while (!(scrub_passes_o == n - 1 && scrub_addr_o == AW'(DEPTH - 1) && scrub_busy_o) && guard < 400000) begin @(posedge clk); guard++; end
    @(negedge clk); scrub_en_i = 0;
    guard = 0;
    while ((scrub_passes_o != n || scrub_busy_o) && guard < 100000) begin @(posedge clk); guard++; end
    if (guard >= 100000) fail($sformatf("scrub engine did not complete the pass (target %0d: passes=%0d addr=%0d busy=%b halted=%b en=%b halt_pol=%b)",
                                         n, scrub_passes_o, scrub_addr_o, scrub_busy_o, scrub_halted_o, scrub_en_i, scrub_ue_halt_i));
    repeat (2) @(posedge clk);
  endtask
  task automatic fi_clr();
    @(negedge clk); fi_clear_i = 1;
    @(negedge clk); fi_clear_i = 0;
    @(negedge clk);
  endtask
  bit fi_busy_seen = 0;
  always @(posedge clk) if (fi_busy_o) fi_busy_seen <= 1'b1;

  // ------------------------------------------------------------------ watchers: make the word 'get worse' while the engine is mid-sequence
  bit wd_fix_arm = 0, wd_ver_arm = 0, wd_fix_heal = 0;
  int wd_addr = 0;
  logic [N-1:0] wd_mask = '0;
  generate if (SCRUB_EN != 0) begin : g_wd
    // Fire on the edge that ACCEPTS the FIX / VERIFY request (acc_s), one nanosecond later: any earlier write-back of the same
    // sequence has committed by then (in-order macro) and the request's own macro read happens one clock later, so the injected
    // error is what that read sees.
    always @(posedge clk) begin
      if (wd_fix_arm && dut.u_ecc.acc_s && dut.u_ecc.g_scrub.u_scrub.op_q == 2'd1 && dut.u_ecc.g_scrub.u_scrub.addr_q == AW'(wd_addr)) begin
        wd_fix_arm = 0;
        #1;
        dut.u_ram.mem[wd_addr] = dut.u_ram.mem[wd_addr] ^ wd_mask;
        err_mask[wd_addr] = err_mask[wd_addr] ^ wd_mask;
      end
      if (wd_fix_heal && dut.u_ecc.acc_s && dut.u_ecc.g_scrub.u_scrub.op_q == 2'd1 && dut.u_ecc.g_scrub.u_scrub.addr_q == AW'(wd_addr)) begin
        wd_fix_heal = 0;                                               // the word is rewritten clean between CHECK and FIX (effect of a functional write)
        #1;
        dut.u_ram.mem[wd_addr] = dut.u_ram.mem[wd_addr] ^ err_mask[wd_addr];
        err_mask[wd_addr] = '0;
      end
      if (wd_ver_arm && dut.u_ecc.acc_s && dut.u_ecc.g_scrub.u_scrub.op_q == 2'd2 && dut.u_ecc.g_scrub.u_scrub.addr_q == AW'(wd_addr)) begin
        wd_ver_arm = 0;
        #1;
        dut.u_ram.mem[wd_addr] = dut.u_ram.mem[wd_addr] ^ wd_mask;     // the FIX has repaired the word: the model's old error is gone
        err_mask[wd_addr] = wd_mask;
      end
    end
  end endgenerate

  // ------------------------------------------------------------------ fault-injection helpers
  task automatic fi_cmd(input int mode, input logic [N-1:0] mask, input logic [N-1:0] val, input int a, input bit aen);
    @(negedge clk);
    fi_cmd_valid_i = 1; fi_cmd_mode_i = mode[1:0]; fi_cmd_mask_i = mask; fi_cmd_val_i = val; fi_cmd_addr_i = a[AW-1:0]; fi_cmd_addr_en_i = aen;
    @(negedge clk); fi_cmd_valid_i = 0;
  endtask

  // ------------------------------------------------------------------ external scrub master helpers (SCRUB_EN = 0)
  logic          xs_ce, xs_ue; logic [SYN_W-1:0] xs_syn; logic [1:0] xs_op; int xs_addr;
  int xs_req_cyc, xs_acc_cyc;
  task automatic xscr(input int op, input int a, input logic [SYN_W-1:0] syn);
    @(negedge clk);
    xscr_req_valid = 1; xscr_req_op = op[1:0]; xscr_req_addr = a[AW-1:0]; xscr_req_syn = syn;
    xs_req_cyc = cyc;
    do @(posedge clk); while (!xscr_req_ready);
    xs_acc_cyc = cyc;
    #1 xscr_req_valid = 0;
    do @(posedge clk); while (!xscr_rsp_valid);
    xs_ce = xscr_rsp_ce; xs_ue = xscr_rsp_ue; xs_syn = xscr_rsp_syn; xs_op = xscr_rsp_op; xs_addr = xscr_rsp_addr;
  endtask

  // ---------------------------------------------------------------- memory dump for the Python reference checker
  // one line per word: <phase> <addr> <expected data> <raw stored word> <stored-error mask>.  Appended; the checker verifies
  // raw ^ mask == ReferenceEncode(expected data) for every line, with the independent Python model.
  int dump_fd = 0;
  task automatic dump_mem(input string tag);
    if (dump_fd == 0) dump_fd = $fopen(dumpf, "w");
    for (int a = 0; a < DEPTH; a++)
      if (!force_ue[a]) $fdisplay(dump_fd, "%s %0d %h %h %h", tag, a, exp_mem[a], dut.u_ram.mem[a], err_mask[a]);
    $fflush(dump_fd);
  endtask

  // ====================================================================================================================
  //  TEST PHASES
  // ====================================================================================================================
  int phase_err0;
  task automatic phase_begin(); phase_err0 = errors; endtask
  task automatic phase_end(input string name, input string detail);
    $display("RESULT %-28s %s%s", name, detail, (errors == phase_err0) ? "  PASS" : "  FAIL");
  endtask

  // ---------------------------------------------------------------- P0: reset + init
  task automatic p0_init();
    int bad; logic [N-1:0] w;
    phase_begin();
    bad = 0;
    if (INIT_ON_RESET != 0) begin
      wait_init();
      for (int a = 0; a < DEPTH; a++) begin
        w = dut.u_ram.mem[a];
        if (w !== enc0_exp) bad++;
      end
      check(bad == 0, $sformatf("init: %0d words differ from the Python encode(0) word %h", bad, enc0_exp));
      check(ce_count_o == 0 && ue_count_o == 0, "init produced RAS events");
    end else begin
      // no init engine: the array (powered up all-zero) is NOT a valid codeword when CHK_INV != 0 -> UE, never "valid zero"
      repeat (6) @(posedge clk);
      check(!init_busy_o, "init_busy with INIT_ON_RESET=0");
    end
    read_all();
    phase_end("P0 reset/init", $sformatf("%0d words checked against Python encode(0)", DEPTH));
  endtask

  // ---------------------------------------------------------------- P1: all-zero / all-one / pattern words
  task automatic p1_patterns();
    logic [K-1:0] pats [0:5];
    phase_begin();
    pats[0] = '0; pats[1] = '1; pats[2] = {K/8{8'hA5}}; pats[3] = {K/8{8'h5A}}; pats[4] = {K/16{16'h00FF}}; pats[5] = {K/16{16'hFF00}};
    for (int p = 0; p < 6; p++) begin
      for (int a = 0; a < DEPTH; a++) wr_full(a, pats[p]);
      for (int a = 0; a < DEPTH; a++) rd(a);
      drain();
    end
    for (int b = 0; b < K; b++) begin              // walking one / walking zero on one rotating address
      wr_full(b % DEPTH, K'(1) << b); rd(b % DEPTH);
      wr_full((b + 7) % DEPTH, ~(K'(1) << b)); rd((b + 7) % DEPTH);
    end
    drain();
    expect_counts("P1");
    phase_end("P1 all-0/all-1/patterns", "6 patterns x all words + walking 1/0");
  endtask

  // ---------------------------------------------------------------- P2: random data
  task automatic p2_random(input int n);
    phase_begin();
    for (int i = 0; i < n; i++) begin
      int a;
      a = $urandom_range(0, DEPTH - 1);
      if ($urandom_range(0, 2) == 0) rd(a); else wr_full(a, rnd_data());
    end
    drain();
    read_all();
    dump_mem("P2");
    expect_counts("P2");
    phase_end("P2 random full-word", $sformatf("%0d random ops + full readback", n));
  endtask

  // ---------------------------------------------------------------- P3: every single-bit error position
  task automatic p3_singles();
    logic [N-1:0] pre;
    int a;
    phase_begin();
    for (int rep = 0; rep < 3; rep++) begin
      for (int b = 0; b < N; b++) begin
        a = (b * 5 + rep * 11) % DEPTH;
        wr_full(a, (rep == 0) ? rnd_data() : (rep == 1 ? '0 : '1)); drain();
        inject(a, bm(b));
        pre = dut.u_ram.mem[a];
        rd(a); rd(a); drain();                    // corrected twice: a read does NOT write back (error persists in the array)
        check(dut.u_ram.mem[a] === pre, $sformatf("read of a CE word modified the array (bit %0d)", b));
        if (rep == 0) begin
          wr_part(a, rnd_data(), rnd_pbe()); rd(a); drain();    // an RMW re-encodes the whole word -> clean afterwards
          check(dut.u_ram.mem[a] !== pre, "RMW did not repair the stored word");
        end else begin
          wr_full(a, rnd_data()); rd(a); drain();               // a full write also repairs
        end
      end
    end
    expect_counts("P3");
    phase_end("P3 every single-bit error", $sformatf("%0d positions x 3 reps (data, check, parity bits); CE x2 each, array unchanged by reads", N));
  endtask

  // ---------------------------------------------------------------- P4: every double-bit error combination
  task automatic p4_doubles();
    logic [N-1:0] pre; logic [N-1:0] m;
    int a, n;
    phase_begin();
    n = 0;
    for (int i = 0; i < N; i++) begin
      for (int j = i + 1; j < N; j++) begin
        a = n % DEPTH;
        wr_full(a, rnd_data()); drain();
        m = (bm(i)) | (bm(j));
        inject(a, m);
        pre = dut.u_ram.mem[a];
        rd(a); drain();                           // UE: flagged, raw data returned, array untouched
        check(dut.u_ram.mem[a] === pre, $sformatf("read of a UE word modified the array (%0d,%0d)", i, j));
        if (n % 9 == 0) begin                     // RMW onto a UE word aborts and leaves the word exactly as found
          wr_part(a, rnd_data(), rnd_pbe()); drain();
          check(dut.u_ram.mem[a] === pre, $sformatf("aborted RMW changed the word (%0d,%0d)", i, j));
          rd(a); drain();
        end
        wr_full(a, rnd_data()); rd(a); drain();   // a full write repairs
        n++; cov_pair++;
      end
    end
    expect_counts("P4");
    phase_end("P4 every double-bit error", $sformatf("%0d pairs: UE flagged, never CE, raw data, array unchanged, RMW aborts, full write repairs", n));
  endtask

  // ---------------------------------------------------------------- P5: partial writes
  task automatic p5_partial();
    phase_begin();
    for (int a = 0; a < DEPTH; a++) wr_full(a, rnd_data());
    drain();
    for (int c = 0; c < 40; c++) begin               // chunks of random traffic, errors injected between chunks
      for (int i = 0; i < 60; i++) begin
        int a, k;
        a = $urandom_range(0, DEPTH - 1);
        k = $urandom_range(0, 9);
        if (k < 3)       rd(a);
        else if (k < 4)  wr_full(a, rnd_data());
        else if (k < 5)  wr_part(a, rnd_data(), '0);                 // be = 0: acknowledged no-op
        else if (k < 6)  wr_part(a, rnd_data(), BE_ONE << $urandom_range(0, BE_W-1));   // single byte
        else             wr_part(a, rnd_data(), rnd_be());
      end
      drain();
      for (int e = 0; e < 4; e++) begin                              // sprinkle latent errors for the next chunk
        int a, w;
        a = $urandom_range(0, DEPTH - 1);
        w = $urandom_range(0, 3);
        if (err_mask[a] == '0 && w != 0) begin
          if (w == 3) inject(a, bm($urandom_range(0, N-1)) | bm($urandom_range(0, N-1)));   // may collapse to 0/1 flips: fine
          else inject(a, bm($urandom_range(0, N-1)));
        end
        if (popc(err_mask[a]) > 2) fail("TB generated an error weight above 2");
      end
    end
    drain();
    dump_mem("P5");                                                   // includes words with LATENT errors: raw ^ mask must still be a codeword
    expect_counts("P5");
    phase_end("P5 partial writes", "40 chunks x 60 byte-enable/RMW/read ops with latent single/double errors; byte-accurate scoreboard");
  endtask

  // ---------------------------------------------------------------- P5b: RMW details
  task automatic p5b_rmw_details();
    logic [K-1:0] old_d, new_d;
    logic [N-1:0] pre;
    phase_begin();
    for (int kind = 0; kind < 3; kind++) begin
      int a, bit_i;
      a = 3 + kind;
      old_d = rnd_data(); new_d = rnd_data();
      wr_full(a, old_d); drain();
      bit_i = (kind == 0) ? 5 : (kind == 1 ? K + 2 : K + R);       // a data bit, a check bit, the overall-parity bit
      inject(a, bm(bit_i));
      wr_part(a, new_d, BE_ONE);               // write only byte 0
      rd(a); drain();                                             // corrected on the way, merged, re-encoded: clean now
    end
    // untouched bytes are never corrupted by repeated RMW on one word
    wr_full(10, rnd_data());
    for (int i = 0; i < 100; i++) begin wr_part(10, rnd_data(), rnd_be()); if (i % 3 == 0) rd(10); end
    drain(); rd(10); drain();
    dump_mem("P5b");
    expect_counts("P5b");
    phase_end("P5b RMW detail", "CE in data/check/parity bit during RMW; 100 chained RMWs");
  endtask

  task automatic p6_reset();
    logic [K-1:0] d_old, d_new, merged_new;
    int saw_old, saw_new;
    phase_begin();
    if (INIT_ON_RESET != 0) begin
      for (int t = 0; t < 8; t++) begin
        for (int a = 0; a < DEPTH; a++) wr_full(a, rnd_data());
        drain();
        for (int i = 0; i < 6; i++) wr_part($urandom_range(0, DEPTH - 1), rnd_data(), rnd_be());   // burst, NOT drained: RMWs in flight
        repeat ($urandom_range(0, LAT + 8)) @(posedge clk);
        do_reset($urandom_range(1, 4));
        wait_init();
        check(!rsp_valid, "stale response after reset");
        check(!lock_o, "bank still locked after reset");
        check(ce_count_o == 0 && ue_count_o == 0 && !fatal_req_o, "RAS state survived reset");
        read_all();                                                  // memory is all zero and valid
        for (int a = 0; a < DEPTH; a++) check(dut.u_ram.mem[a] === enc0_exp, $sformatf("word %0d not re-initialised", a));
      end
    end else begin
      // warm reset: contents survive.  An RMW cut off by a reset leaves the word either OLD or fully MERGED -- never torn.
      for (int a = 0; a < DEPTH; a++) wr_full(a, rnd_data());
      drain();
      do_reset(3); repeat (6) @(posedge clk);
      read_all();                                                    // every word retained and valid
      saw_old = 0; saw_new = 0;
      for (int t = 0; t <= LAT + 5; t++) begin
        wr_full(7, rnd_data()); drain();
        d_old = exp_mem[7]; d_new = rnd_data();
        @(negedge clk);
        req_valid = 1; req_we = 1; req_addr = 7; req_wdata = d_new; req_be = BE_LO; req_id = nid; nid++;
        do @(posedge clk); while (!req_ready);
        #1 req_valid = 0;
        merged_new = exp_mem[7];                                     // the scoreboard applied the RMW at accept
        repeat (t) @(posedge clk);
        do_reset(2); repeat (4) @(posedge clk);
        exp_mem[7] = merged_new; alt_armed = 1; alt_data = d_old;
        rd(7); drain();                                              // clean read of old OR merged data (a torn word would be CE/UE or wrong)
        if (last_rsp_data === d_old) saw_old++; else saw_new++;
        exp_mem[7] = last_rsp_data;
        check(!lock_o && !rsp_valid, "lock or response left over after the cut");
      end
      check(saw_old > 0 && saw_new > 0, $sformatf("reset sweep covered old=%0d new=%0d: need both outcomes", saw_old, saw_new));
    end
    if (INIT_ON_RESET != 0) det_tmp = "8 resets with RMWs in flight: no stale lock/response, RAS cleared, memory re-initialised to valid zero";
    else det_tmp = $sformatf("warm reset retains contents; RMW cut at %0d points: old/merged only (never torn)", LAT + 6);
    phase_end("P6 memory reset", det_tmp);
  endtask

  // ---------------------------------------------------------------- P7: out-of-range + zero byte enable
  task automatic p7_range();
    phase_begin();
    for (int a = DEPTH; a < AMAX; a++) begin
      wr_full(a, rnd_data()); rd(a); wr_part(a, rnd_data(), BE_LO);
      issue(1, a, rnd_data(), '0, nid); nid++;
    end
    wr_full(1, rnd_data()); rd(1);
    drain();
    expect_counts("P7");
    phase_end("P7 out-of-range / be=0", $sformatf("%0d out-of-range addresses x 4 op types: err response, no side effect", AMAX - DEPTH));
  endtask

  // ---------------------------------------------------------------- P8: backpressure
  task automatic p8_backpressure();
    phase_begin();
    for (int m = 1; m <= 3; m++) begin
      rsp_mode = (m == 3) ? 2 : m;
      for (int c = 0; c < 20; c++) begin
        for (int i = 0; i < 50; i++) begin
          int a, k;
          a = $urandom_range(0, DEPTH - 1); k = $urandom_range(0, 9);
          if (k < 4) rd(a); else if (k < 6) wr_full(a, rnd_data()); else wr_part(a, rnd_data(), rnd_be());
          if (m == 1 && $urandom_range(0, 5) == 0) repeat ($urandom_range(1, 4)) @(negedge clk);
        end
        if (c % 5 == 4) begin rsp_mode = 0; drain(); rsp_mode = (m == 3) ? 2 : m;
          for (int e = 0; e < 3; e++) begin int a2; a2 = $urandom_range(0, DEPTH-1); if (err_mask[a2] == '0) inject(a2, bm($urandom_range(0, N-1))); end
        end
      end
      rsp_mode = 0; drain();
    end
    // hard stall: nothing is consumed -> the wrapper must stop accepting exactly at RSP_DEPTH outstanding, lose nothing
    rsp_mode = 3;
    for (int i = 0; i < RSP_DEPTH + 6; i++) begin
      @(negedge clk); req_valid = 1; req_we = 0; req_addr = i % DEPTH; req_id = nid; req_wdata = '0; req_be = '0;
      @(posedge clk);
      if (!req_ready) begin
        check((accepts - pops) == RSP_DEPTH, $sformatf("req_ready low with only %0d outstanding (RSP_DEPTH %0d)", accepts - pops, RSP_DEPTH));
      end else nid++;
    end
    @(negedge clk); req_valid = 0;
    check((accepts - pops) == RSP_DEPTH, $sformatf("credit stall: %0d outstanding, expected exactly RSP_DEPTH=%0d", accepts - pops, RSP_DEPTH));
    repeat (20) @(posedge clk);
    rsp_mode = 0; drain();
    dump_mem("P8");
    expect_counts("P8");
    phase_end("P8 backpressure", $sformatf("random/long/total stalls; max outstanding %0d <= RSP_DEPTH %0d; no loss/dup/reorder, payload stable", out_max, RSP_DEPTH));
  endtask

  // ---------------------------------------------------------------- P9: latency / throughput formulas
  task automatic p9_latency();
    int t0, t1, k, base;
    logic [K-1:0] d;
    phase_begin();
    wr_full(2, rnd_data()); drain();
    rsp_mode = 0;
    // read latency
    @(negedge clk); req_valid = 1; req_we = 0; req_addr = 2; req_be = '0; req_id = nid; nid++;
    do @(posedge clk); while (!req_ready);
    t0 = cyc; #1 req_valid = 0;
    do @(posedge clk); while (!rsp_valid);
    t1 = cyc;
    check((t1 - t0) == LAT + 2, $sformatf("read latency exp=%0d got=%0d", LAT + 2, t1 - t0));
    @(posedge clk); drain();
    // RMW: bank lock window and response latency
    @(negedge clk); req_valid = 1; req_we = 1; req_addr = 2; req_wdata = rnd_data(); req_be = BE_LO; req_id = nid; nid++;
    do @(posedge clk); while (!req_ready);
    t0 = cyc; #1 req_valid = 0;
    k = 0;
    // count cycles with the lock asserted and find when req_ready returns
    do begin @(posedge clk); if (lock_o) k++; end while (!req_ready);
    check(k == LAT + 2, $sformatf("RMW lock cycles exp=%0d got=%0d", LAT + 2, k));
    check((cyc - t0) == LAT + 3, $sformatf("RMW: next accept at +%0d exp +%0d", cyc - t0, LAT + 3));
    do @(posedge clk); while (!rsp_valid);
    check((cyc - t0) == LAT + 4, $sformatf("RMW response latency exp=%0d got=%0d", LAT + 4, cyc - t0));
    drain();
    // throughput: back-to-back reads and full writes, 1 per cycle
    t0 = cyc;
    for (int i = 0; i < 64; i++) rd(i % DEPTH);
    t1 = cyc;
    check((t1 - t0) <= 64 + 2, $sformatf("read throughput: 64 reads took %0d cycles", t1 - t0));
    drain();
    t0 = cyc;
    for (int i = 0; i < 64; i++) wr_full(i % DEPTH, rnd_data());
    t1 = cyc;
    check((t1 - t0) <= 64 + 2, $sformatf("write throughput: 64 writes took %0d cycles", t1 - t0));
    drain();
    expect_counts("P9");
    phase_end("P9 latency/throughput", $sformatf("LAT=%0d: read/write ack %0d, RMW %0d (lock %0d cycles); 1 op/cycle sustained", LAT, LAT + 2, LAT + 4, LAT + 2));
  endtask

  task automatic p10_zero_word();
    phase_begin();
    wr_full(5, '0); drain();
    dut.u_ram.mem[5] = '0;                    // a dead word line / macro that powers up or is scrubbed to zero
    force_ue[5] = 1'b1;
    rd(5); drain();                           // must be FLAGGED uncorrectable, never read as valid data
    cov_zero_word_ue++;
    dut.u_ram.mem[5] = '1;                    // all-ones stored word
    rd(5); drain();
    cov_ones_word_ue++;
    wr_part(5, rnd_data(), BE_LO); drain();   // RMW onto a dead word aborts and leaves it as found
    check(dut.u_ram.mem[5] === '1, "aborted RMW changed a dead word");
    wr_full(5, rnd_data()); drain();          // a full write repairs it
    rd(5); drain();
    expect_counts("P10");
    phase_end("P10 dead word / zero-word", "all-zero and all-ones STORED words decode UE (never valid data); RMW aborts; full write repairs");
  endtask

  // ---------------------------------------------------------------- P11: RAS register page + fatal policy
  task automatic p11_ras();
    int a;
    logic [N-1:0] m;
    phase_begin();
    wr_full(8, rnd_data()); drain();
    reg_read(8'h00); check(reg_q === 32'h4543_4337 && !reg_e, "ID register");
    reg_read(8'h08); check(reg_q === 32'h0000_0004, $sformatf("CTRL reset value %h (exp 4: UE_FATAL_EN only)", reg_q));
    // DEFAULT policy, before the testbench configures anything: a UE seen by a demand read must request a fatal error
    reg_write(8'h38, 32'h3); reg_write(8'h10, 32'h3F); exp_ce = 0; exp_ue = 0;
    inject(8, bm(1) | bm(2)); rd(8); drain();
    check(fatal_req_o && ue_seen_o, "default policy: a demand-read UE must raise fatal_req");
    wr_full(8, rnd_data()); drain(); heal_model(8);
    reg_write(8'h10, 32'h3F);
    reg_read(8'h04); check(reg_q[7:0] === K[7:0] && reg_q[15:8] === N[7:0] && reg_q[23:16] === AW[7:0] && reg_q[24] === (SCRUB_EN != 0) && reg_q[25] === (FI_EN != 0), $sformatf("CFG register %h", reg_q));
    reg_write(8'h38, 32'h3);                       // clear counters + re-arm the first-UE capture
    reg_write(8'h10, 32'h3F);                      // clear sticky status
    exp_ce = 0; exp_ue = 0;
    // CE
    m = bm(20); inject(8, m); rd(8); drain();
    reg_read(8'h14); check(reg_q == 1, $sformatf("CE_COUNT=%0d", reg_q));
    reg_read(8'h20); check(reg_q == 8, "LAST_CE_ADDR");
    reg_read(8'h24); check(reg_q[11:0] === 12'(syn1[20]) && reg_q[23:12] === 12'd20 && reg_q[25:24] === 2'd0, $sformatf("LAST_CE_INFO %h (exp syn %h pos 20 src 0)", reg_q, syn1[20]));
    reg_read(8'h10); check(reg_q[0] === 1'b1 && reg_q[1] === 1'b0 && reg_q[5] === 1'b0, "STATUS after a CE: CE_SEEN only, not fatal");
    check(ce_seen_o && !ue_seen_o && !fatal_req_o, "CE level outputs");
    check(!irq_warn_o, "irq_warn with CE_IRQ_EN=0");
    reg_write(8'h08, 32'h07);                      // CE_IRQ_EN, UE_IRQ_EN, UE_FATAL_EN
    check(irq_warn_o, "irq_warn with CE_IRQ_EN=1");
    wr_full(8, rnd_data()); drain(); heal_model(8);
    // UE on a demand read -> fatal request
    m = bm(3) | bm(B_C); inject(8, m); rd(8); drain();
    reg_read(8'h18); check(reg_q == 1, $sformatf("UE_COUNT=%0d", reg_q));
    reg_read(8'h28); check(reg_q == 8, "FIRST_UE_ADDR");
    reg_read(8'h2C); check(reg_q[11:0] === 12'(syn2[3][B_C]) && reg_q[25:24] === 2'd0, $sformatf("FIRST_UE_INFO %h exp syn %h", reg_q, syn2[3][B_C]));
    check(ue_seen_o && fatal_req_o && irq_ue_o, "UE must raise fatal_req and irq_ue");
    cov_fatal++;
    reg_read(8'h10); check(reg_q[1] === 1'b1 && reg_q[5] === 1'b1, "STATUS after UE: UE_SEEN + FATAL");
    reg_write(8'h10, 32'h20);                      // W1C FATAL
    check(!fatal_req_o, "fatal_req not cleared by W1C");
    // a second UE: first-UE capture is NOT overwritten, last-UE is
    wr_full(9, rnd_data()); drain(); heal_model(9);
    inject(9, bm(1) | bm(2)); rd(9); drain();
    reg_read(8'h28); check(reg_q == 8, "FIRST_UE_ADDR was overwritten");
    reg_read(8'h30); check(reg_q == 9, "LAST_UE_ADDR");
    reg_read(8'h18); check(reg_q == 2, "UE_COUNT after second UE");
    // policy bit: UE not fatal when UE_FATAL_EN = 0
    reg_write(8'h10, 32'h3F); reg_write(8'h08, 32'h00);
    wr_full(9, rnd_data()); drain(); heal_model(9);
    inject(9, bm(7) | bm(9)); rd(9); drain();
    check(!fatal_req_o, "UE raised fatal_req with UE_FATAL_EN=0");
    reg_write(8'h08, 32'h04);
    // CE threshold
    wr_full(11, rnd_data()); drain(); heal_model(11);
    reg_write(8'h38, 32'h1); reg_write(8'h10, 32'h3F); exp_ce = 0; exp_ue = 0;
    reg_write(8'h0C, 32'd3); reg_write(8'h08, 32'h24);       // CE_THR = 3, UE_FATAL_EN, CE_THR_FATAL_EN
    inject(11, bm(30));
    rd(11); rd(11); drain();
    reg_read(8'h10); check(reg_q[3] === 1'b0 && !fatal_req_o, "threshold hit too early");
    rd(11); drain();
    reg_read(8'h10); check(reg_q[3] === 1'b1 && fatal_req_o && irq_warn_o, "CE threshold did not escalate");
    reg_write(8'h10, 32'h3F); reg_write(8'h0C, 32'd0); reg_write(8'h08, 32'h04);
    // threshold reached WITHOUT the fatal escalation enabled: a warning only
    reg_write(8'h38, 32'h1); reg_write(8'h10, 32'h3F); exp_ce = 0; exp_ue = 0;
    reg_write(8'h0C, 32'd2); reg_write(8'h08, 32'h04);
    rd(11); rd(11); drain();
    reg_read(8'h10); check(reg_q[3] === 1'b1 && !fatal_req_o && irq_warn_o, "CE_THR reached without CE_THR_FATAL_EN must warn but not be fatal");
    reg_write(8'h10, 32'h3F); reg_write(8'h0C, 32'd0);
    // selective write-1-to-clear, LAST_UE_INFO
    wr_full(12, rnd_data()); drain(); heal_model(12);
    inject(12, bm(1) | bm(2)); rd(11); rd(12); drain();            // word 11 still carries its single error: CE; word 12: UE (fatal by default)
    reg_read(8'h34); check(reg_q[11:0] === 12'(syn2[1][2]) && reg_q[25:24] === 2'd0, $sformatf("LAST_UE_INFO %h exp syn %h", reg_q, syn2[1][2]));
    reg_read(8'h10); check(reg_q[0] === 1'b1 && reg_q[1] === 1'b1 && reg_q[5] === 1'b1, "STATUS before selective clear");
    reg_write(8'h10, 32'h01); reg_read(8'h10); check(reg_q[0] === 1'b0 && reg_q[1] === 1'b1 && reg_q[5] === 1'b1, "W1C of CE_SEEN alone must leave UE_SEEN and FATAL");
    reg_write(8'h10, 32'h02); reg_read(8'h10); check(reg_q[1] === 1'b0 && reg_q[5] === 1'b1 && fatal_req_o, "W1C of UE_SEEN alone must leave FATAL set");
    reg_write(8'h10, 32'h20); check(!fatal_req_o, "W1C of FATAL");
    // counters saturate instead of wrapping (backdoor deposit close to the maximum)
    wr_full(11, rnd_data()); drain(); heal_model(11);
    reg_write(8'h38, 32'h3); reg_write(8'h10, 32'h3F); exp_ce = 0; exp_ue = 0;
    dut.u_ecc.u_ras.ce_cnt_q = 32'hFFFF_FFFE; dut.u_ecc.u_ras.ue_cnt_q = 32'hFFFF_FFFE;
    inject(11, bm(30)); rd(11); rd(11); rd(11); drain();           // 3 CEs from FFFFFFFE
    check(ce_count_o === 32'hFFFF_FFFF, $sformatf("CE counter wrapped or stuck: %h", ce_count_o));
    reg_read(8'h10); check(reg_q[4] === 1'b1, "STATUS.CNT_SAT not set");
    wr_full(12, rnd_data()); drain(); heal_model(12); heal_model(11); wr_full(11, rnd_data()); drain();
    inject(12, bm(5) | bm(6)); rd(12); rd(12); rd(12); drain();   // 3 UEs from FFFFFFFE
    check(ue_count_o === 32'hFFFF_FFFF, $sformatf("UE counter wrapped or stuck: %h", ue_count_o));
    wr_full(12, rnd_data()); drain(); heal_model(12);
    reg_write(8'h38, 32'h3); reg_write(8'h10, 32'h3F); exp_ce = 0; exp_ue = 0;
    // illegal accesses
    reg_write(8'h14, 32'h5); check(reg_e, "write to RO CE_COUNT must error");
    reg_read(8'hF0);          check(reg_e, "read of unmapped offset must error");
    reg_write(8'h38, 32'h1);                         // clear counters via CLR
    reg_read(8'h14); check(reg_q == 0, "CLR did not clear CE_COUNT");
    wr_full(11, rnd_data()); drain(); heal_model(11);
    exp_ce = 0; exp_ue = 0;
    phase_end("P11 RAS registers/fatal", "ID/CFG, counts, syndrome/addr/pos/src, first/last UE, fatal policy, CE threshold, W1C, illegal access");
  endtask

  // ---------------------------------------------------------------- P12: MBIST raw port
  task automatic p12_mbist();
    logic [N-1:0] pat [0:3];
    int n;
    phase_begin();
    pat[0] = '0; pat[1] = '1; pat[2] = {N/2{2'b10}}; pat[3] = {N/2{2'b01}};
    wr_full(4, rnd_data()); drain();
    @(negedge clk); tst_req_i = 1;
    n = 0; while (!tst_grant_o && n < 1000) begin @(posedge clk); n++; end
    check(tst_grant_o, "MBIST grant never came");
    check(!req_ready, "functional port ready while the MBIST port is granted");
    // raw march: write every pattern to every word, read it back raw (data AND check bits)
    for (int p = 0; p < 4; p++) begin
      for (int a = 0; a < DEPTH; a++) begin
        @(negedge clk); tst_en_i = 1; tst_we_i = 1; tst_addr_i = a[AW-1:0]; tst_wdata_i = pat[p] ^ {N{a[0]}};
      end
      for (int a = 0; a < DEPTH; a++) begin
        @(negedge clk); tst_en_i = 1; tst_we_i = 0; tst_addr_i = a[AW-1:0];
        repeat (RD_LAT) @(posedge clk);
        #1 check(tst_rdata_o === (pat[p] ^ {N{a[0]}}), $sformatf("MBIST raw read-back word %0d pattern %0d: %h", a, p, tst_rdata_o));
        @(posedge clk);
      end
    end
    @(negedge clk); tst_en_i = 0; tst_we_i = 0;
    cov_tst++;
    @(negedge clk); tst_req_i = 0;
    // the wrapper re-initialises the array: afterwards every word is the valid zero word
    repeat (4) @(posedge clk);
    wait_init();
    model_clear();
    check(!tst_grant_o, "grant not released");
    read_all();
    for (int a = 0; a < DEPTH; a++) check(dut.u_ram.mem[a] === enc0_exp, $sformatf("word %0d not re-initialised after MBIST", a));
    phase_end("P12 MBIST raw port", "raw march with data+check bits, functional port blocked, re-init to valid zero afterwards");
  endtask

  // ---------------------------------------------------------------- P12b: MBIST port compiled out (TEST_EN = 0)
  task automatic p12b_test_off();
    phase_begin();
    wr_full(4, rnd_data()); drain();
    @(negedge clk); tst_req_i = 1;
    repeat (20) @(posedge clk);
    check(!tst_grant_o, "MBIST granted although TEST_EN = 0");
    wr_full(4, rnd_data()); rd(4); drain();                        // the functional port is unaffected by an ignored request
    check(req_ready && !tst_grant_o, "functional port blocked by an ignored MBIST request");
    @(negedge clk); tst_req_i = 0;
    phase_end("P12b MBIST disabled", "TEST_EN = 0: tst_req_i is ignored, the functional port keeps working");
  endtask

  // ---------------------------------------------------------------- P19: init_start_i
  task automatic p19_init_start();
    int t;
    phase_begin();
    for (int a = 0; a < DEPTH; a++) wr_full(a, rnd_data());
    drain();
    for (int i = 0; i < 4; i++) wr_part($urandom_range(0, DEPTH - 1), rnd_data(), rnd_pbe());   // RMWs still in flight when init is requested
    @(negedge clk); init_start_i = 1; @(negedge clk); init_start_i = 0;
    t = 0; while (!init_busy_o && t < 50) begin @(posedge clk); t++; end
    check(init_busy_o, "init_start_i did not start the init engine");
    t = 0; while (init_busy_o && t < 100000) begin @(posedge clk); t++; end
    check(t >= DEPTH, $sformatf("init took %0d cycles for %0d words", t, DEPTH));
    drain();
    model_zero_mem();                                              // in-flight work completed first, then every word became the valid zero word
    for (int a = 0; a < DEPTH; a++) check(dut.u_ram.mem[a] === enc0_exp, $sformatf("word %0d not re-initialised by init_start_i", a));
    read_all();
    expect_counts("P19");
    phase_end("P19 init_start_i", "init waits for in-flight RMWs, runs one word/cycle with the functional port blocked, leaves a valid zero array");
  endtask

  // ---------------------------------------------------------------- P13: fault injection (FI_EN = 1)
  task automatic p13_fi();
    logic [N-1:0] m, sm, sv, pre;
    phase_begin();
    wr_full(12, rnd_data()); wr_full(13, rnd_data()); drain();
    // ---- not authorised: refused, counted, no effect
    fi_auth_i = 0; fi_enable_i = 1;
    fi_cmd(`SF_ECC_FI_WRITE, bm(4), '0, 12, 1);
    check(fi_blocked_cnt_o == 1 && !fi_armed_o, "unauthorised FI command was not refused");
    fi_auth_i = 1; fi_enable_i = 0;
    fi_cmd(`SF_ECC_FI_READ, bm(4), '0, 12, 1);
    check(fi_blocked_cnt_o == 2 && !fi_armed_o, "FI without software enable was not refused");
    cov_fi_block++;
    wr_full(12, rnd_data()); rd(12); drain();                      // data path unaffected
    fi_auth_i = 1; fi_enable_i = 1;
    // ---- WRITE mode: latent single data-bit error stored by the next write to 12
    fi_cmd(`SF_ECC_FI_WRITE, bm(17), '0, 12, 1);
    check(fi_armed_o, "FI write not armed");
    wr_full(13, rnd_data()); drain();                              // different address: not consumed
    check(fi_armed_o, "FI consumed by the wrong address");
    wr_full(12, rnd_data());
    #1; drain();
    err_mask[12] = bm(17); cov_fi[0]++;
    check(!fi_armed_o, "FI write not disarmed after firing");
    rd(12); rd(12); drain();                                       // CE twice: corrected-error persistence
    wr_full(12, rnd_data()); drain(); heal_model(12);
    // ---- WRITE mode: double error across data + ECC bits (uncorrectable)
    fi_cmd(`SF_ECC_FI_WRITE, (bm(3)) | (bm(K)), '0, 12, 1);
    wr_full(12, rnd_data()); drain();
    err_mask[12] = (bm(3)) | (bm(K)); rd(12); drain();
    wr_full(12, rnd_data()); drain(); heal_model(12);
    // ---- WRITE mode, ECC-bit-only and parity-bit-only single errors, any address
    fi_cmd(`SF_ECC_FI_WRITE, bm(K + 1), '0, 0, 0);
    wr_full(14, rnd_data()); drain(); err_mask[14] = bm(K + 1); rd(14); drain();
    wr_full(14, rnd_data()); drain(); heal_model(14);
    fi_cmd(`SF_ECC_FI_WRITE, bm(K + R), '0, 0, 0);
    wr_full(14, rnd_data()); drain(); err_mask[14] = bm(K + R); rd(14); drain();
    wr_full(14, rnd_data()); drain(); heal_model(14);
    // ---- READ mode: transient, array untouched, seen exactly once
    wr_full(15, rnd_data()); drain();
    pre = dut.u_ram.mem[15];
    fi_cmd(`SF_ECC_FI_READ, bm(33), '0, 15, 1);
    rd_once_mask = bm(33); rd_once_armed = 1;
    rd(15); drain();
    check(dut.u_ram.mem[15] === pre, "transient read injection modified the array");
    cov_fi[1]++;
    rd(15); drain();                                               // clean again
    // re-arm refused while a one-shot is armed
    fi_busy_seen = 0;
    fi_cmd(`SF_ECC_FI_READ, bm(2), '0, 15, 1);
    fi_cmd(`SF_ECC_FI_READ, bm(3), '0, 15, 1);
    repeat (2) @(posedge clk);
    check(fi_busy_seen, "re-arming a one-shot that is still armed was not refused");
    rd_once_mask = bm(2); rd_once_armed = 1; rd(15); drain();
    // ---- STUCK mode: hard fault survives write-back (corrected-error persistence)
    wr_full(16, '0); drain();
    sm = bm(9); sv = bm(9);                                // stuck-at-1 on data bit 9
    fi_cmd(`SF_ECC_FI_STUCK, sm, sv, 16, 1);
    stuck_on = 1; stuck_mask = sm; stuck_val = sv; stuck_addr = 16; stuck_addr_en = 1;
    cov_fi[2]++;
    wr_full(17, '0); drain(); rd(17); drain();                     // a DIFFERENT address must stay clean while the fault at 16 is active
    rd(16); rd(16); drain();                                       // stored bit is 0, stuck at 1 -> CE every read
    wr_part(16, '0, BE_LO); drain(); rd(16); drain();              // RMW rewrites the word: still CE (write-back does not cure a hard fault)
    wr_full(16, '1); drain(); rd(16); drain();                     // bit 9 stored as 1 == stuck value: no error visible
    wr_full(16, '0); drain(); rd(16); drain();                     // error is back
    fi_clr();
    stuck_on = 0;
    check(!fi_stuck_o, "FI clear did not remove the stuck-at fault");
    rd(16); drain();
    // a second WRITE-mode arm while one is armed, and an invalid mode, are refused
    fi_busy_seen = 0;
    fi_cmd(`SF_ECC_FI_WRITE, bm(1), '0, 14, 1);
    fi_cmd(`SF_ECC_FI_WRITE, bm(2), '0, 14, 1);
    repeat (2) @(posedge clk);
    check(fi_busy_seen, "re-arming a write one-shot that is still armed was not refused");
    fi_clr();
    check(!fi_armed_o, "FI clear did not disarm the write one-shot");
    fi_busy_seen = 0;
    fi_cmd(3, bm(1), '0, 14, 1);
    repeat (2) @(posedge clk);
    check(fi_busy_seen && !fi_armed_o, "an invalid FI mode must be refused");
    expect_counts("P13");
    phase_end("P13 fault injection", "authorisation gating, write/read/stuck modes, single/double, data/check/parity bits, persistence");
  endtask

  // ---------------------------------------------------------------- P14: fault injection inert when FI_EN = 0
  task automatic p14_fi_off();
    phase_begin();
    wr_full(12, rnd_data()); drain();
    fi_auth_i = 1; fi_enable_i = 1;
    fi_cmd(`SF_ECC_FI_WRITE, bm(4), '0, 12, 1);
    fi_cmd(`SF_ECC_FI_STUCK, bm(4), bm(4), 12, 1);
    wr_full(12, rnd_data()); rd(12); drain();
    check(!fi_armed_o && !fi_stuck_o && !fi_fired_o && !fi_blocked_o, "FI_EN=0 build reacts to commands");
    check(ce_count_o == 0 && ue_count_o == 0, "FI_EN=0 build injected an error");
    fi_auth_i = 0; fi_enable_i = 0;
    phase_end("P14 FI disabled build", "authorised commands have no effect when FI_EN = 0");
  endtask

  // ---------------------------------------------------------------- P15: external scrub master: FIX race and double counting (SCRUB_EN = 0)
  task automatic p15_scrub_port();
    logic [K-1:0] d1, d2;
    logic [N-1:0] m, pre_raw;
    phase_begin();
    ev_check_en = 0; ce_tolerant = 0;
    exp_ce = 0; exp_ue = 0;
    reg_write(8'h38, 32'h1);
    reg_write(8'h10, 32'h3F); reg_write(8'h08, 32'h04);            // sticky status cleared, default policy (UE fatal for demand reads only)
    // --- CHECK then FIX on a single-bit error: ONE corrected-error event, word repaired
    d1 = rnd_data(); wr_full(20, d1); drain();
    m = bm(B_A); inject(20, m);
    xscr(0, 20, '0);
    check(xs_ce && !xs_ue && xs_syn === SYN_W'(syn1[B_A]) && xs_op === 2'd0, $sformatf("CHECK result ce=%b ue=%b syn=%h", xs_ce, xs_ue, xs_syn));
    xscr(1, 20, xs_syn);                                           // FIX with the syndrome CHECK reported
    check(xs_ce && xs_op === 2'd1, "FIX result");
    xscr(2, 20, '0);                                               // VERIFY: clean
    check(!xs_ce && !xs_ue && xs_op === 2'd2, "VERIFY after FIX not clean");
    heal_model(20);
    drain();
    check(ce_count_o == 1, $sformatf("scrub CHECK+FIX+VERIFY counted %0d corrections (exp 1: no double counting)", ce_count_o));
    check(persist_count_o == 0, "clean VERIFY counted as persistent");
    rd(20); drain();
    cov_fix_hit++;
    // --- RACE: CHECK finds a CE, a functional FULL write then rewrites the word, then the FIX must NOT write stale data back
    d1 = rnd_data(); d2 = rnd_data();
    wr_full(21, d1); drain();
    inject(21, bm(7));
    xscr(0, 21, '0); check(xs_ce, "CHECK should see the CE");
    wr_full(21, d2); drain(); heal_model(21);                      // functional write after CHECK
    xscr(1, 21, xs_syn);                                           // FIX re-reads under the lock: finds a clean word
    check(!xs_ce && !xs_ue, "FIX of an already-rewritten word reported an error");
    rd(21); drain();                                               // the NEW data must still be there
    // --- RACE: functional RMW racing with a scrub FIX issued in the same cycle: serialised, both effects survive
    d1 = rnd_data(); wr_full(22, d1); drain();
    inject(22, bm(11));
    fork
      begin xscr(0, 22, '0); end
    join
    ce_tolerant = 1;                                               // FIX may legally run before or after the RMW: the RMW sees CE or clean
    fork
      begin xscr(1, 22, xs_syn); end
      begin wr_part(22, rnd_data(), BE_HI); end
    join
    drain(); heal_model(22); ce_tolerant = 0;
    rd(22); drain();
    // --- a scrub FIX presented in the SAME cycle as a functional read / full write: functional goes first, then the FIX runs
    for (int v = 0; v < 2; v++) begin
      d1 = rnd_data(); wr_full(25, d1); drain();
      inject(25, bm(9));
      ce_tolerant = 1;
      fork
        begin xscr(1, 25, '0); end                                  // FIX presented with a stale/zero expected syndrome: reported as a (new) CE event, still repaired
        begin if (v == 0) rd(25); else begin d2 = rnd_data(); wr_full(25, d2); end end
      join
      drain(); heal_model(25); ce_tolerant = 0;
      rd(25); drain();                                              // whatever the order, the word is intact and clean
    end
    // --- starvation bound: a scrub request facing back-to-back functional traffic is served within SCRUB_MAX_WAIT (+ a few cycles)
    wr_full(26, rnd_data()); drain();
    fork
      begin for (int i = 0; i < 40; i++) rd(26 + (i % 4)); end
      begin repeat (3) @(negedge clk); xscr(0, 27, '0); end
    join
    drain();
    check((xs_acc_cyc - xs_req_cyc) <= `TB_MAXWAIT + 4, $sformatf("scrub request waited %0d cycles behind functional traffic (SCRUB_MAX_WAIT=%0d)", xs_acc_cyc - xs_req_cyc, `TB_MAXWAIT));
    // --- FIX on an uncorrectable word: never written
    wr_full(23, rnd_data()); drain();
    inject(23, bm(1) | bm(B_B));
    xscr(0, 23, '0); check(xs_ue && !xs_ce, "CHECK of a double error must report UE");
    drain();
    check(ue_seen_o && !fatal_req_o, "a UE found by SCRUB must be reported but not fatal by default (latent, not yet consumed)");
    reg_write(8'h08, 32'h0C);                                      // SCRUB_UE_FATAL_EN
    xscr(0, 23, '0); drain();
    check(fatal_req_o, "SCRUB_UE_FATAL_EN must make a scrub-found UE fatal");
    reg_write(8'h10, 32'h3F); reg_write(8'h08, 32'h04);
    pre_raw = dut.u_ram.mem[23];
    xscr(1, 23, '0);  check(xs_ue, "FIX of a double error must report UE and not write");
    drain();
    check(dut.u_ram.mem[23] === pre_raw, "scrub FIX wrote to an uncorrectable word");
    wr_full(23, rnd_data()); drain(); heal_model(23);
    // --- VERIFY seeing a CE after a FIX = persistent hard fault (needs the stuck-at injector)
    if (FI_EN != 0) begin
      wr_full(24, '0); drain();
      fi_auth_i = 1; fi_enable_i = 1;
      fi_cmd(`SF_ECC_FI_STUCK, bm(5), bm(5), 24, 1);
      stuck_on = 1; stuck_mask = bm(5); stuck_val = bm(5); stuck_addr = 24; stuck_addr_en = 1;
      reg_write(8'h38, 32'h1); exp_ce = 0;
      xscr(0, 24, '0); check(xs_ce, "stuck bit: CHECK should see a CE");
      xscr(1, 24, xs_syn); check(xs_ce, "stuck bit: FIX should still see the error under the lock");
      xscr(2, 24, '0); check(xs_ce && xs_op === 2'd2, "stuck bit: VERIFY must still see the error");
      drain();
      check(persist_count_o == 1, $sformatf("persistent count %0d exp 1", persist_count_o));
      check(ce_count_o == 1, $sformatf("a persistent fault must not be counted as another CE (ce_count=%0d)", ce_count_o));
      reg_read(8'h10); check(reg_q[2] === 1'b1, "STATUS.PERSIST_SEEN");
      reg_write(8'h08, 32'h14);                                    // PERSIST_FATAL_EN + UE_FATAL_EN
      xscr(2, 24, '0); drain();
      check(fatal_req_o, "persist fatal policy");
      dut.u_ecc.u_ras.per_cnt_q = 32'hFFFF_FFFE;                   // saturation (backdoor deposit)
      xscr(2, 24, '0); xscr(2, 24, '0); xscr(2, 24, '0); drain();
      reg_read(8'h1C); check(reg_q === 32'hFFFF_FFFF, $sformatf("PERSIST_COUNT must saturate: %h", reg_q));
      reg_read(8'h10); check(reg_q[4] === 1'b1, "STATUS.CNT_SAT after PERSIST saturation");
      fi_clr();
      stuck_on = 0;
      wr_full(24, rnd_data()); drain();
      reg_write(8'h10, 32'h3F); reg_write(8'h08, 32'h04);
    end
    reg_write(8'h38, 32'h1); exp_ce = 0; exp_ue = 0; ev_check_en = 1; ee_head = ee_tail; ee_cnt = 0;
    phase_end("P15 scrub port (external)", "CHECK/FIX/VERIFY, one CE event per correction, FIX race vs functional write/RMW, UE never written, persistent fault");
  endtask

  task automatic p16_scrub_engine();
    localparam int UE_A = 3;
    int n_ce, n_ue, w;
    logic [N-1:0] m;
    phase_begin();
    ev_check_en = 1; ce_tolerant = 0;
    for (int a2 = 0; a2 < DEPTH; a2++) wr_full(a2, rnd_data());
    drain();
    reg_write(8'h38, 32'h1); exp_ce = 0; exp_ue = 0;
    // seed single errors in data / check / parity bits (addresses 2,7,12,..) and one double error at UE_A
    for (int a2 = 2; a2 < DEPTH; a2 += 5) begin
      case (a2 % 3)
        0: m = bm(a2 % K);
        1: m = bm(K + (a2 % R));
        default: m = bm(K + R);
      endcase
      inject(a2, m);
    end
    inject(UE_A, bm(4) | bm(B_A));
    n_ce = 0; n_ue = 0;
    for (int a2 = 0; a2 < DEPTH; a2++) begin
      w = popc(err_mask[a2]);
      if (w == 1) begin push_ev(0, 2, a2, err_mask[a2]); n_ce++; end
      else if (w == 2) begin push_ev(1, 2, a2, err_mask[a2]); n_ue++; end
    end
    scrub_fix_en_i = 1; scrub_ue_halt_i = 0; scrub_interval_i = 0;
    scrub_run_to(1);
    drain();
    check(scrub_words_o == DEPTH, $sformatf("scrub words %0d exp %0d", scrub_words_o, DEPTH));
    check(scrub_ce_found_o == n_ce, $sformatf("scrub ce_found %0d exp %0d", scrub_ce_found_o, n_ce));
    check(scrub_fixed_o == n_ce, $sformatf("scrub fixed %0d exp %0d", scrub_fixed_o, n_ce));
    check(scrub_ue_found_o == n_ue, $sformatf("scrub ue_found %0d exp %0d", scrub_ue_found_o, n_ue));
    check(scrub_persistent_o == 0, "persistent count after a clean repair");
    check(ce_count_o == n_ce, $sformatf("RAS ce_count %0d exp %0d: a scrub correction must be counted exactly once", ce_count_o, n_ce));
    check(ue_count_o == n_ue, $sformatf("RAS ue_count %0d exp %0d", ue_count_o, n_ue));
    check(scrub_ue_addr_o == UE_A, $sformatf("scrub_ue_addr %0d exp %0d", scrub_ue_addr_o, UE_A));
    expect_counts("P16 pass 1");
    for (int a2 = 0; a2 < DEPTH; a2++) if (popc(err_mask[a2]) == 1) heal_model(a2);    // singles repaired in the array
    read_all();                                                       // repaired words read clean (CE would fail the scoreboard); UE word still UE
    // second pass: nothing left to repair, the uncorrectable word is re-reported
    for (int a2 = 0; a2 < DEPTH; a2++) if (popc(err_mask[a2]) == 2) push_ev(1, 2, a2, err_mask[a2]);
    scrub_run_to(2); drain();
    check(scrub_ce_found_o == n_ce && scrub_fixed_o == n_ce, "second pass found new single errors in a repaired array");
    check(scrub_ue_found_o == 2 * n_ue, $sformatf("UE re-found each pass: %0d", scrub_ue_found_o));
    expect_counts("P16 pass 2");
    // UE halt policy: stop at the uncorrectable word, hold, resume skips it
    scrub_ue_halt_i = 1;
    for (int a2 = 0; a2 < DEPTH; a2++) if (popc(err_mask[a2]) == 2) push_ev(1, 2, a2, err_mask[a2]);
    @(negedge clk); scrub_en_i = 1;
    begin int g; g = 0; while (!scrub_halted_o && g < 100000) begin @(posedge clk); g++; end end
    check(scrub_halted_o && scrub_ue_addr_o == UE_A && scrub_addr_o == UE_A, "scrub did not halt on the uncorrectable word");
    cov_halt++;
    repeat (25) @(posedge clk);
    check(scrub_halted_o && !scrub_busy_o, "halt not held");
    @(negedge clk); scrub_en_i = 0; scrub_resume_i = 1; @(negedge clk); scrub_resume_i = 0;
    repeat (6) @(posedge clk);
    check(!scrub_halted_o && scrub_addr_o == UE_A + 1, $sformatf("resume did not skip the word (addr %0d)", scrub_addr_o));
    scrub_run_to(3); drain();                                         // finish the pass
    scrub_ue_halt_i = 0;
    expect_counts("P16 halt");
    // repair the uncorrectable word so the next steps start from a clean array
    wr_full(UE_A, rnd_data()); drain();
    reg_write(8'h38, 32'h1); exp_ce = 0; exp_ue = 0;
    // ---- interval timer: idle cycles between words (a pass takes >= DEPTH * interval longer)
    begin
      int tA, tB;
      scrub_interval_i = 0; tA = cyc; scrub_run_to(scrub_passes_o + 1); tA = cyc - tA;
      scrub_interval_i = 6; tB = cyc; scrub_run_to(scrub_passes_o + 1); tB = cyc - tB;
      scrub_interval_i = 0;
      check(tB - tA >= DEPTH * 5, $sformatf("scrub interval: pass took %0d cycles with interval 6 vs %0d back-to-back", tB, tA));
    end
    // ---- fix_en = 0: errors are found and reported but never repaired
    begin
      int nn, cf0, fx0;
      scrub_fix_en_i = 0; nn = 0;
      for (int a2 = 2; a2 < DEPTH; a2 += 9) begin inject(a2, bm(a2 % K)); push_ev(0, 2, a2, err_mask[a2]); nn++; end
      cf0 = scrub_ce_found_o; fx0 = scrub_fixed_o;
      scrub_run_to(scrub_passes_o + 1); drain();
      check(scrub_ce_found_o - cf0 == nn && scrub_fixed_o == fx0, $sformatf("fix_en=0: found %0d (exp %0d) fixed %0d (exp 0)", scrub_ce_found_o - cf0, nn, scrub_fixed_o - fx0));
      read_all();                                                  // still CE on every word: nothing was written
      scrub_fix_en_i = 1;
      for (int a2 = 0; a2 < DEPTH; a2++) if (popc(err_mask[a2]) == 1) push_ev(0, 2, a2, err_mask[a2]);
      scrub_run_to(scrub_passes_o + 1); drain();                   // now they are repaired
      for (int a2 = 0; a2 < DEPTH; a2++) if (popc(err_mask[a2]) == 1) heal_model(a2);
      read_all();
      expect_counts("P16 fix_en");
    end
    // ---- the word gets WORSE between CHECK and FIX (FIX reads UE) and between FIX and VERIFY (VERIFY reads UE)
    begin
      int cf0, fx0, uf0, pe0, cc0, uc0;
      ev_check_en = 0;
      reg_write(8'h38, 32'h1);
      cf0 = scrub_ce_found_o; fx0 = scrub_fixed_o; uf0 = scrub_ue_found_o; pe0 = scrub_persistent_o;
      wr_full(5, rnd_data()); drain(); inject(5, bm(3));
      wd_addr = 5; wd_mask = bm(20); wd_fix_arm = 1;
      scrub_run_to(scrub_passes_o + 1); drain();
      check(!wd_fix_arm, "watcher never saw the FIX request");
      check(scrub_ce_found_o - cf0 == 1 && scrub_ue_found_o - uf0 == 1 && scrub_fixed_o == fx0, $sformatf("FIX-UE: ce_found +%0d ue_found +%0d fixed +%0d", scrub_ce_found_o - cf0, scrub_ue_found_o - uf0, scrub_fixed_o - fx0));
      check(ce_count_o == 1 && ue_count_o == 1, $sformatf("FIX-UE RAS counts ce=%0d ue=%0d (exp 1/1)", ce_count_o, ue_count_o));
      wr_full(5, rnd_data()); drain(); heal_model(5);
      reg_write(8'h38, 32'h1);
      cf0 = scrub_ce_found_o; fx0 = scrub_fixed_o; uf0 = scrub_ue_found_o; pe0 = scrub_persistent_o;
      wr_full(6, rnd_data()); drain(); inject(6, bm(7));
      wd_addr = 6; wd_mask = bm(9) | bm(11); wd_ver_arm = 1;
      scrub_run_to(scrub_passes_o + 1); drain();
      check(!wd_ver_arm, "watcher never saw the VERIFY request");
      check(scrub_ce_found_o - cf0 == 1 && scrub_ue_found_o - uf0 == 1 && scrub_fixed_o == fx0 && scrub_persistent_o == pe0,
            $sformatf("VERIFY-UE: ce_found +%0d ue_found +%0d fixed +%0d persistent +%0d", scrub_ce_found_o - cf0, scrub_ue_found_o - uf0, scrub_fixed_o - fx0, scrub_persistent_o - pe0));
      check(ce_count_o == 1 && ue_count_o == 1, $sformatf("VERIFY-UE RAS counts ce=%0d ue=%0d (exp 1/1)", ce_count_o, ue_count_o));
      wr_full(6, rnd_data()); drain(); heal_model(6);
      // ---- the word is rewritten clean between CHECK and FIX: the FIX finds nothing to repair and writes nothing
      reg_write(8'h38, 32'h1);
      cf0 = scrub_ce_found_o; fx0 = scrub_fixed_o; uf0 = scrub_ue_found_o; pe0 = scrub_persistent_o;
      wr_full(7, rnd_data()); drain(); inject(7, bm(4));
      wd_addr = 7; wd_fix_heal = 1;
      scrub_run_to(scrub_passes_o + 1); drain();
      check(!wd_fix_heal, "watcher never saw the FIX request (clean case)");
      check(scrub_ce_found_o - cf0 == 1 && scrub_fixed_o == fx0 && scrub_ue_found_o == uf0 && scrub_persistent_o == pe0,
            $sformatf("clean-FIX: ce_found +%0d fixed +%0d ue +%0d persistent +%0d", scrub_ce_found_o - cf0, scrub_fixed_o - fx0, scrub_ue_found_o - uf0, scrub_persistent_o - pe0));
      check(ce_count_o == 1 && ue_count_o == 0, $sformatf("clean-FIX RAS counts ce=%0d ue=%0d (exp 1/0: the FIX must not report again)", ce_count_o, ue_count_o));
      ev_check_en = 1; ee_head = ee_tail; ee_cnt = 0;
      reg_write(8'h38, 32'h1); exp_ce = 0; exp_ue = 0;
    end
    phase_end("P16 scrub engine", $sformatf("pass 1: %0d CE repaired + counted once each, %0d UE untouched; pass 2; UE halt/resume; interval; fix_en=0; FIX sees UE / clean; VERIFY sees UE", n_ce, n_ue));
  endtask

  // ---------------------------------------------------------------- P17: contention: random traffic + scrub engine
  task automatic p17_contention();
    int guard, p0, fx0;
    phase_begin();
    ev_check_en = 0; ce_tolerant = 1;
    fx0 = scrub_fixed_o;                                              // the engine's counters are cumulative; the RAS counters were cleared after P16
    for (int a2 = 0; a2 < DEPTH; a2++) wr_full(a2, rnd_data());
    drain();
    for (int a2 = 0; a2 < DEPTH; a2 += 3) inject(a2, bm($urandom_range(0, N-1)));       // latent single errors everywhere
    scrub_fix_en_i = 1; scrub_ue_halt_i = 0; scrub_interval_i = 0;
    @(negedge clk); scrub_en_i = 1;
    p0 = scrub_passes_o;
    for (int c = 0; c < 60; c++) begin
      rsp_mode = (c % 3);
      for (int i = 0; i < 40; i++) begin
        int a, k;
        a = $urandom_range(0, DEPTH - 1); k = $urandom_range(0, 9);
        if (k < 3) rd(a);
        else if (k < 5) wr_full(a, rnd_data());
        else wr_part(a, rnd_data(), rnd_be());
        if ($urandom_range(0, 3) == 0) repeat ($urandom_range(1, 3)) @(negedge clk);
      end
    end
    rsp_mode = 0;
    // functional traffic stops; let the scrubber finish two more passes: every latent error must be gone
    guard = 0; while (scrub_passes_o < p0 + 3 && guard < 400000) begin @(posedge clk); guard++; end
    @(negedge clk); scrub_en_i = 0; wait (!scrub_busy_o); drain();
    for (int a2 = 0; a2 < DEPTH; a2++) err_mask[a2] = '0;
    ce_tolerant = 0;
    read_all();                                                       // every word equals the scoreboard and decodes clean
    check(ce_count_o >= scrub_fixed_o - fx0, $sformatf("RAS CE count %0d below the number of scrub repairs in this phase (%0d)", ce_count_o, scrub_fixed_o - fx0));
    phase_end("P17 contention + scrub", $sformatf("2400 random ops with scrub FIX running; data exact; scrub forced %0d times; all latent errors repaired", cov_scrub_force));
    reg_write(8'h38, 32'h1); exp_ce = 0; exp_ue = 0; ev_check_en = 1; ee_head = ee_tail; ee_cnt = 0;
  endtask

  // ---------------------------------------------------------------- P18: persistent fault found by the scrub engine (FI_EN = 1 and SCRUB_EN = 1)
  task automatic p18_scrub_persistent();
    int guard, cf0, fx0, pe0;
    phase_begin();
    ev_check_en = 0;
    for (int a2 = 0; a2 < DEPTH; a2++) wr_full(a2, '0);
    drain();
    scrub_fix_en_i = 1; scrub_ue_halt_i = 0; scrub_interval_i = 0;
    scrub_run_to(scrub_passes_o + 1); drain();                         // bring the engine to a pass boundary (address 0)
    reg_write(8'h38, 32'h1);
    cf0 = scrub_ce_found_o; fx0 = scrub_fixed_o; pe0 = scrub_persistent_o;
    fi_auth_i = 1; fi_enable_i = 1;
    fi_cmd(`SF_ECC_FI_STUCK, bm(6), bm(6), 9, 1);                      // stuck-at-1 on data bit 6 of word 9
    reg_write(8'h08, 32'h14);
    scrub_run_to(scrub_passes_o + 1); drain();                         // exactly one full pass
    check(scrub_persistent_o - pe0 == 1, $sformatf("scrub persistent %0d exp 1", scrub_persistent_o - pe0));
    check(scrub_ce_found_o - cf0 == 1 && scrub_fixed_o - fx0 == 0, $sformatf("ce_found=%0d fixed=%0d", scrub_ce_found_o - cf0, scrub_fixed_o - fx0));
    check(persist_count_o == 1 && ce_count_o == 1, $sformatf("RAS: persist=%0d ce=%0d (a persistent fault is one CE + one PERSIST, not two CEs)", persist_count_o, ce_count_o));
    check(fatal_req_o, "persistent fault with PERSIST_FATAL_EN must raise fatal_req");
    fi_clr();
    reg_write(8'h10, 32'h3F); reg_write(8'h08, 32'h04); reg_write(8'h38, 32'h1);
    wr_full(9, rnd_data()); drain();
    for (int a2 = 0; a2 < DEPTH; a2++) err_mask[a2] = '0;
    exp_ce = 0; exp_ue = 0; ev_check_en = 1; ee_head = ee_tail; ee_cnt = 0;
    phase_end("P18 persistent fault", "stuck-at cell: CHECK -> FIX -> VERIFY still bad => PERSIST (1 CE + 1 PERSIST), fatal policy");
  endtask


  // ====================================================================================================================
  //  MAIN
  // ====================================================================================================================
  initial begin
    if (!$value$plusargs("DUMP=%s", dumpf)) dumpf = `TB_DUMP;
    $display("CONFIG K=%0d N=%0d DEPTH=%0d RD_LAT=%0d DEC_PIPE=%0d RSP_DEPTH=%0d CHK_INV=0x%0h FI_EN=%0d SCRUB_EN=%0d INIT_ON_RESET=%0d UE_DATA_ZERO=%0d",
             K, N, DEPTH, RD_LAT, DEC_PIPE, RSP_DEPTH, CHK_INV, FI_EN, SCRUB_EN, INIT_ON_RESET, UEZ);
    repeat (4) @(negedge clk);
    rst_n = 1;
    if (INIT_ON_RESET == 0) begin
      // no init engine: the array powers up all-zero.  With CHK_INV != 0 that is NOT a valid codeword -> every word must read UE
      if (CHK_INV != 0) begin
        for (int a = 0; a < DEPTH; a++) force_ue[a] = 1'b1;
        for (int a = 0; a < DEPTH; a++) rd(a);
        drain();
        $display("RESULT %-28s %s", "P0a powered-up zero array", (errors == 0) ? "all words read UE (never valid zero)  PASS" : "FAIL");
      end
      for (int a = 0; a < DEPTH; a++) wr_full(a, '0);                 // explicit full writes bring it to a defined state
      drain();
    end
    p0_init();
    p1_patterns();
    p2_random(1500);
    p3_singles();
    p4_doubles();
    p5_partial();
    p5b_rmw_details();
    if (AMAX > DEPTH) p7_range();
    p8_backpressure();
    p9_latency();
    p6_reset();
    if (CHK_INV != 0) p10_zero_word();
    p11_ras();
    if (TEST_EN != 0) p12_mbist(); else p12b_test_off();
    p19_init_start();
    if (FI_EN != 0) p13_fi(); else p14_fi_off();
    if (SCRUB_EN == 0) p15_scrub_port();
    else begin p16_scrub_engine(); p17_contention(); if (FI_EN != 0) p18_scrub_persistent(); end
    // final sweep: every word equals the scoreboard, then dump raw words for the independent Python check
    for (int a = 0; a < DEPTH; a++) if (err_mask[a] != '0) begin wr_full(a, exp_mem[a]); end
    drain();
    for (int a = 0; a < DEPTH; a++) err_mask[a] = '0;
    read_all();
    dump_mem("final");
    $display("COV rd_w0=%0d rd_w1=%0d rd_w2=%0d rmw_w0=%0d rmw_w1=%0d rmw_w2=%0d wr=%0d nop=%0d oor=%0d", cov_rd_w[0], cov_rd_w[1], cov_rd_w[2], cov_rmw_w[0], cov_rmw_w[1], cov_rmw_w[2], cov_wr, cov_nop, cov_oor);
    $display("COV ce_kind_data=%0d ce_kind_check=%0d ce_kind_parity=%0d rmw_ce_data=%0d rmw_ce_check=%0d rmw_ce_parity=%0d rmw_abort=%0d pairs=%0d", cov_kind[0], cov_kind[1], cov_kind[2], cov_rmw_ce_kind[0], cov_rmw_ce_kind[1], cov_rmw_ce_kind[2], cov_rmw_abort, cov_pair);
    $display("COV lock_cycles=%0d out_max=%0d bp_full_cycles=%0d scrub_force=%0d ev_ce=%0d ev_ue=%0d ev_persist=%0d", cov_lock_cycles, out_max, cov_bp_full, cov_scrub_force, cov_ev_ce, cov_ev_ue, cov_ev_per);
    $display("COV fi_write=%0d fi_read=%0d fi_stuck=%0d fi_blocked_phase=%0d mbist=%0d resets=%0d scrub_halt=%0d reg_rd=%0d reg_wr=%0d reg_err=%0d fatal=%0d zero_word_ue=%0d ones_word_ue=%0d", cov_fi[0], cov_fi[1], cov_fi[2], cov_fi_block, cov_tst, cov_reset, cov_halt, cov_reg_rd, cov_reg_wr, cov_reg_err, cov_fatal, cov_zero_word_ue, cov_ones_word_ue);
    $display("SUMMARY checks=%0d errors=%0d cycles=%0d", checks, errors, cyc);
    if (errors == 0) $display("TB_PASS tb_sf_sram_ecc");
    else begin $display("TB_FAIL tb_sf_sram_ecc errors=%0d", errors); $fatal(1, "wrapper testbench failed"); end
    $finish;
  end

  initial begin
    #2000000000;
    $display("TB_FAIL watchdog");
    $fatal(1, "watchdog");
  end
endmodule
