// =============================================================================
// SilicaFlux Project 77 :: tb_secded_codec
// Codec-only testbench (NO SRAM).  Expected values come from the independent
// Python reference (model/verify_math.py -> vectors/*.hex), never from the RTL.
//
//   +VEC=<dir>   vector directory (default vectors)
//   +TAG=<tag>   vector tag, e.g. inv0 / invd (default inv0)
//   compile-time: -DTB_K=<k> -DTB_INV=<inv>  [-DTB_P26 cross-checks the vendored
//   Project 26 cells on every vector]  [-DSF_SECDED_ASSERT]
//
// enc file lines: <data> <codeword>
// dec file lines: <received> <class 0/1/2> <data> <corrected word> <pos> <syndrome>
// =============================================================================
`timescale 1ns/1ps
`ifndef TB_K
  `define TB_K 64
`endif
`ifndef TB_INV
  `define TB_INV 0
`endif

module tb_secded_codec;
  localparam int K   = `TB_K;
  localparam int INV = `TB_INV;
  localparam int R   = $clog2(K + $clog2(K + 1) + 1);
  localparam int N   = K + R + 1;
  localparam int IW  = $clog2(N);

  // ------------------------------------------------------------------ DUT
  logic [K-1:0] d;
  wire  [N-1:0] cw;
  sf_secded_enc #(.K(K), .INV(INV)) u_enc (.data_i(d), .cw_o(cw));

  logic [N-1:0] rx;
  wire  [K-1:0] dd;
  wire  [N-1:0] cwc;
  wire          none, ce, ue, uei;
  wire  [1:0]   kind;
  wire  [IW-1:0] pos;
  wire  [R:0]   syn;
  sf_secded_dec #(.K(K), .INV(INV)) u_dec (
    .cw_i(rx), .data_o(dd), .cw_corr_o(cwc), .none_o(none), .ce_o(ce), .ue_o(ue),
    .ue_inval_o(uei), .err_kind_o(kind), .err_pos_o(pos), .syn_o(syn));

`ifdef TB_P26
  wire  [N-1:0] p_cw;
  sfras_secded_enc #(.K(K), .INV(INV)) u_p26e (.data_i(d), .cw_o(p_cw));
  wire  [K-1:0] p_dd;
  wire  [N-1:0] p_cwc;
  wire          p_none, p_ce, p_ue, p_uei, p_cedata;
  wire  [IW-1:0] p_idx;
  wire  [R:0]   p_syn;
  sfras_secded_dec #(.K(K), .INV(INV)) u_p26d (
    .cw_i(rx), .data_o(p_dd), .cw_corr_o(p_cwc), .none_o(p_none), .ce_o(p_ce), .ue_o(p_ue),
    .ue_inval_o(p_uei), .ce_data_o(p_cedata), .err_idx_o(p_idx), .syn_o(p_syn));
`endif

  // pipelined encoders (STAGES = 0,1,2)
  logic clk = 0;
  logic rst_n = 0;
  logic en = 1;
  logic vld = 0;
  wire  v0, v1, v2;
  wire  [N-1:0] c0, c1, c2;
  sf_secded_enc_pipe #(.K(K), .INV(INV), .STAGES(0)) u_p0 (.clk(clk), .rst_n(rst_n), .en_i(en), .vld_i(vld), .data_i(d), .vld_o(v0), .cw_o(c0));
  sf_secded_enc_pipe #(.K(K), .INV(INV), .STAGES(1)) u_p1 (.clk(clk), .rst_n(rst_n), .en_i(en), .vld_i(vld), .data_i(d), .vld_o(v1), .cw_o(c1));
  sf_secded_enc_pipe #(.K(K), .INV(INV), .STAGES(2)) u_p2 (.clk(clk), .rst_n(rst_n), .en_i(en), .vld_i(vld), .data_i(d), .vld_o(v2), .cw_o(c2));

  always #5 clk = ~clk;

  // ------------------------------------------------------------------ bookkeeping
  int errors = 0;
  int n_enc = 0, n_dec = 0, n_ce = 0, n_ue = 0, n_none = 0, n_p26 = 0;
  string vec_dir, tag;

  task automatic fail(input string msg);
    errors++;
    if (errors <= 20) $display("MISMATCH: %s", msg);
  endtask

  // ------------------------------------------------------------------ encoder vectors
  task automatic run_enc(input string fname);
    int fd, rc;
    logic [K-1:0] vd;
    logic [N-1:0] vcw;
    fd = $fopen(fname, "r");
    if (fd == 0) begin $display("cannot open %s", fname); $fatal(1, "missing vector file"); end
    while (!$feof(fd)) begin
      rc = $fscanf(fd, "%h %h\n", vd, vcw);
      if (rc == 2) begin
        d = vd;
        #1;
        n_enc++;
        if (cw !== vcw) fail($sformatf("enc K=%0d data=%h exp=%h got=%h", K, vd, vcw, cw));
`ifdef TB_P26
        if (p_cw !== vcw) fail($sformatf("P26 enc data=%h exp=%h got=%h", vd, vcw, p_cw));
`endif
      end
    end
    $fclose(fd);
  endtask

  // ------------------------------------------------------------------ pipelined encoder, random stalls
  logic [N-1:0] m1_cw, m2a_cw, m2b_cw;
  logic         m1_v, m2a_v, m2b_v;
  int           n_pipe = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      m1_v <= 0; m2a_v <= 0; m2b_v <= 0;
    end else if (en) begin
      m1_v <= vld;  m1_cw <= cw;
      m2a_v <= vld; m2a_cw <= cw;
      m2b_v <= m2a_v; m2b_cw <= m2a_cw;
    end
  end
  // compare at the falling edge (outputs settled)
  always @(negedge clk) if (rst_n) begin
    if (v0 !== vld)                     fail("pipe0 valid");
    if (vld && c0 !== cw)               fail("pipe0 data");
    if (v1 !== m1_v)                    fail($sformatf("pipe1 valid exp=%b got=%b", m1_v, v1));
    if (m1_v && c1 !== m1_cw)           fail($sformatf("pipe1 data exp=%h got=%h", m1_cw, c1));
    if (v2 !== m2b_v)                   fail($sformatf("pipe2 valid exp=%b got=%b", m2b_v, v2));
    if (m2b_v && c2 !== m2b_cw)         fail($sformatf("pipe2 data exp=%h got=%h", m2b_cw, c2));
    if (m2b_v) n_pipe++;
  end

  task automatic run_pipe(input string fname);
    int fd, rc, k2;
    logic [K-1:0] vd;
    logic [N-1:0] vcw;
    fd = $fopen(fname, "r");
    @(negedge clk); rst_n = 0; en = 1; vld = 0;
    repeat (3) @(negedge clk);
    rst_n = 1;
    while (!$feof(fd)) begin
      rc = $fscanf(fd, "%h %h\n", vd, vcw);
      if (rc == 2) begin
        // random stall: hold the pipeline AND the input for 0..3 cycles
        k2 = $urandom_range(0, 3);
        d = vd; vld = ($urandom_range(0, 7) != 0);
        #2;
        if (vld && cw !== vcw) fail($sformatf("pipe-feed exp=%h got=%h", vcw, cw));
        en = 1;
        @(negedge clk);
        while (k2 > 0) begin en = 0; @(negedge clk); k2--; end
        en = 1;
      end
    end
    vld = 0;
    repeat (6) @(negedge clk);
    $fclose(fd);
  endtask

  // ------------------------------------------------------------------ decoder vectors
  task automatic run_dec(input string fname);
    int fd, rc;
    logic [N-1:0] vrx, vcw;
    logic [K-1:0] vd;
    logic [3:0]   vcls, vpos_h;
    logic [IW-1:0] vpos;
    logic [R:0]   vsyn;
    logic [7:0]   vpos8;
    int           cls_rtl;
    fd = $fopen(fname, "r");
    if (fd == 0) begin $display("cannot open %s", fname); $fatal(1, "missing vector file"); end
    while (!$feof(fd)) begin
      rc = $fscanf(fd, "%h %h %h %h %h %h\n", vrx, vcls, vd, vcw, vpos8, vsyn);
      if (rc == 6) begin
        rx = vrx;
        #1;
        n_dec++;
        cls_rtl = ce ? 1 : (ue ? 2 : 0);
        if ((none ? 1 : 0) + (ce ? 1 : 0) + (ue ? 1 : 0) != 1) fail($sformatf("classification not one-hot rx=%h", vrx));
        if (cls_rtl !== int'(vcls))  fail($sformatf("class rx=%h exp=%0d got=%0d", vrx, vcls, cls_rtl));
        if (dd  !== vd)              fail($sformatf("data  rx=%h exp=%h got=%h", vrx, vd, dd));
        if (cwc !== vcw)             fail($sformatf("cw    rx=%h exp=%h got=%h", vrx, vcw, cwc));
        if (syn !== vsyn)            fail($sformatf("syn   rx=%h exp=%h got=%h", vrx, vsyn, syn));
        if (vcls == 1) begin
          vpos = vpos8[IW-1:0];
          if (pos !== vpos)          fail($sformatf("pos   rx=%h exp=%0d got=%0d", vrx, vpos, pos));
          if (kind !== ((vpos8 < K) ? 2'd0 : (vpos8 < K + R) ? 2'd1 : 2'd2))
                                     fail($sformatf("kind  rx=%h pos=%0d got=%0d", vrx, vpos8, kind));
        end
        if (uei !== (vcls == 2 && vsyn[R] && (vsyn[R-1:0] > (K + R))))
                                     fail($sformatf("ue_inval rx=%h syn=%h got=%b", vrx, vsyn, uei));
        // the defining safety property, checked independently of the vector: a UE never alters the word
        if (ue && (cwc !== vrx))     fail($sformatf("UE modified the word rx=%h", vrx));
        if (vcls == 0) n_none++; else if (vcls == 1) n_ce++; else n_ue++;
`ifdef TB_P26
        n_p26++;
        if ((p_none !== none) || (p_ce !== ce) || (p_ue !== ue) || (p_uei !== uei) || (p_dd !== dd) || (p_cwc !== cwc) || (p_syn !== syn))
          fail($sformatf("P26 RTL differs rx=%h", vrx));
        if (ce && (p_idx !== pos))   fail($sformatf("P26 idx rx=%h exp=%0d got=%0d", vrx, pos, p_idx));
`endif
      end
    end
    $fclose(fd);
  endtask

  initial begin
    if (!$value$plusargs("VEC=%s", vec_dir)) vec_dir = "vectors";
    if (!$value$plusargs("TAG=%s", tag))     tag = "inv0";
    d = '0; rx = '0;
    #10;
    run_enc({vec_dir, "/enc_", tag, ".hex"});
    $display("RESULT enc: K=%0d INV=0x%0h  %0d vectors vs Python reference%s", K, INV, n_enc, (errors == 0) ? "  PASS" : "  FAIL");
    run_dec({vec_dir, "/dec_", tag, ".hex"});
    $display("RESULT dec: K=%0d INV=0x%0h  %0d vectors (none=%0d CE=%0d UE=%0d)%s", K, INV, n_dec, n_none, n_ce, n_ue, (errors == 0) ? "  PASS" : "  FAIL");
`ifdef TB_P26
    $display("RESULT p26: Project-26 RTL cells agree on %0d decode vectors", n_p26);
`endif
    run_pipe({vec_dir, "/enc_", tag, ".hex"});
    $display("RESULT pipe: STAGES 0/1/2 vs combinational encoder, random stalls, %0d valid outputs checked%s", n_pipe, (errors == 0) ? "  PASS" : "  FAIL");
    if (errors == 0) $display("TB_PASS tb_secded_codec K=%0d INV=0x%0h", K, INV);
    else begin
      $display("TB_FAIL tb_secded_codec errors=%0d", errors);
      $fatal(1, "codec testbench failed");
    end
    $finish;
  end

  // watchdog
  initial begin
    #2000000000;
    $display("TB_FAIL watchdog");
    $fatal(1, "watchdog");
  end
endmodule
