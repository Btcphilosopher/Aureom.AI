# Vendored reference sources (unmodified)

Origin: Aureom.AI repository, `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-ras-project26.zip`
-> `silicaflux-ras/{rtl,model}/` (Project 26, RAS).  Byte-identical copies; `SHA256SUMS` was computed on the copies.

| File | Use in Project 77 |
|---|---|
| `secded_ref.py` | independent cross-check model (4th implementation); `scripts/crosscheck_p26.py` |
| `sfras_secded_enc.sv`, `sfras_secded_dec.sv`, `sfras_ecc_funcs.svh`, `sfras_defs.svh` | formal equivalence and simulation cross-check against the Project 77 codec (`formal/`, `tb/`). **Not** part of the Project 77 design. |
