#!/usr/bin/env python3
"""SilicaFlux Project 77 -- SECDED software reference model.

Baseline: 64 data bits + 7 Hamming check bits + 1 overall parity bit = 72 stored
bits.  Every class takes the data width `k` (default 64) so the parametric RTL
codec can be checked at other widths; the baseline is what the project claims.

Three INDEPENDENT constructions of the same extended-Hamming code.  They share
only the written specification (docs/01_math_model.md); none of them calls
another, and none shares code with the RTL.

  RefA  systematic parity-check matrix H (stored-bit order), decode by H-column
        search: the received word is a codeword, or H*r equals exactly one
        column (that bit is wrong), or neither (uncorrectable).
  RefB  textbook interleaved Hamming: an N-position logical word, check bits at
        positions 1,2,4,..,64, overall parity at position 0; encode with "check
        bit k = XOR of the data bits whose position has bit k set"; decode with
        "syndrome = XOR of the positions of all set bits" + overall parity.
        No matrix, no column search.
  RefC  GF(2) linear algebra: the code IS the null space of the logical parity
        check matrix H_L (column x = [1; binary(x)], x = 0..N-1).  Encoding is
        Gauss-Jordan elimination (solve H_R*c = H_I*d); decoding is a brute
        force nearest-codeword search.  No "XOR of positions" formula at all.

Stored layout (the physical word "cw", N = k + r + 1 bits; k=64 -> r=7, N=72):
    cw[k-1:0]      data bits       data bit i at cw[i]
    cw[k+r-1:k]    Hamming checks  check bit j at cw[k+j]       j = 0..r-1
    cw[k+r]        overall parity  even parity over cw[k+r-1:0]
Optional constant INV (r+1 bits) is XORed onto cw[k+r:k] after encoding and
removed before decoding (it selects which stored words are "valid"; it does not
change any distance property).

Hamming position of a stored bit (the syndrome value that names it):
    check bit j -> 2**j                       (1,2,4,8,16,32,64 for r=7)
    data  bit i -> (i+1)-th integer >= 3 that is not a power of two  (3,5,6,7,9,..,71)
    overall parity bit -> position 0 (outside the syndrome)
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass

K = 64                 # baseline data width
NONE, CE, UE = 0, 1, 2
CLASS_NAME = {NONE: "NONE", CE: "CE", UE: "UE"}


def r_for(k: int) -> int:
    """Smallest r with 2**r >= k + r + 1 (Hamming bound)."""
    r = 1
    while (1 << r) < k + r + 1:
        r += 1
    return r


def popcount(x: int) -> int:
    return bin(x).count("1")


def parity(x: int) -> int:
    return popcount(x) & 1


@dataclass(frozen=True)
class Dec:
    """Decoder verdict in the exact terms the RTL reports."""
    cls: int        # NONE / CE / UE
    data: int       # corrected data (raw stored data bits on UE)
    cw: int         # corrected stored word (received word on UE)
    pos: int        # stored-bit index of the corrected bit (meaningful only for CE)
    syn: int        # {P, s[r-1:0]}

    def tup(self):
        return (self.cls, self.data, self.cw, self.pos if self.cls == CE else 0, self.syn)


def data_positions(k: int):
    """Hamming positions of data bits 0..k-1: integers >= 3 that are not powers of two."""
    out, p = [], 3
    while len(out) < k:
        if p & (p - 1):
            out.append(p)
        p += 1
    return out


class _Base:
    def __init__(self, k: int = K, inv: int = 0):
        self.k = k
        self.r = r_for(k)
        self.n = k + self.r + 1
        self.mask_k = (1 << k) - 1
        self.mask_n = (1 << self.n) - 1
        self.inv = inv & ((1 << (self.r + 1)) - 1)
        self.dpos = data_positions(k)
        assert max(self.dpos) <= k + self.r

    def stored_pos(self, b: int) -> int:
        """Hamming position of stored bit b (0 for the overall parity bit)."""
        if b < self.k:
            return self.dpos[b]
        if b < self.k + self.r:
            return 1 << (b - self.k)
        return 0

    def encode(self, d: int) -> int:
        return self.encode_plain(d) ^ (self.inv << self.k)


# --------------------------------------------------------------------------- RefA
class RefA(_Base):
    """Systematic H-matrix model, column-search decode."""

    def __init__(self, k: int = K, inv: int = 0):
        super().__init__(k, inv)
        self.rows = []
        for j in range(self.r):
            row = 0
            for b in range(self.n):
                if (self.stored_pos(b) >> j) & 1:
                    row |= 1 << b
            self.rows.append(row)
        self.rows.append(self.mask_n)                     # overall-parity row
        self.cols = {}
        for b in range(self.n):
            c = 0
            for j, row in enumerate(self.rows):
                c |= ((row >> b) & 1) << j
            assert c != 0 and c not in self.cols, "H columns must be non-zero and distinct"
            self.cols[c] = b

    def _syn(self, plain: int) -> int:
        v = 0
        for j, row in enumerate(self.rows):
            v |= parity(plain & row) << j
        return v          # bit r = overall-parity row = P, bits r-1:0 = s

    def encode_plain(self, d: int) -> int:
        assert 0 <= d <= self.mask_k
        c = 0
        for j in range(self.r):
            c |= parity(d & self.rows[j] & self.mask_k) << j
        cw = d | (c << self.k)
        cw |= parity(cw) << (self.k + self.r)
        assert self._syn(cw) == 0
        return cw

    def decode(self, rx: int) -> Dec:
        plain = rx ^ (self.inv << self.k)
        v = self._syn(plain)
        if v == 0:
            return Dec(NONE, plain & self.mask_k, rx, 0, 0)
        b = self.cols.get(v)
        if b is not None:
            return Dec(CE, (plain ^ (1 << b)) & self.mask_k, rx ^ (1 << b), b, v)
        return Dec(UE, plain & self.mask_k, rx, 0, v)


# --------------------------------------------------------------------------- RefB
class RefB(_Base):
    """Textbook interleaved Hamming, logical positions 0..n-1."""

    def __init__(self, k: int = K, inv: int = 0):
        super().__init__(k, inv)
        self.pow2 = [1 << j for j in range(self.r)]
        self.data_slots = [x for x in range(1, self.k + self.r + 1) if x not in self.pow2]
        assert len(self.data_slots) == k
        self.l2s = {}                                    # logical position -> stored index
        for i, x in enumerate(self.data_slots):
            self.l2s[x] = i
        for j, x in enumerate(self.pow2):
            self.l2s[x] = k + j
        self.l2s[0] = k + self.r
        assert sorted(self.l2s.values()) == list(range(self.n))

    def to_logical(self, cw: int):
        return [(cw >> self.l2s[x]) & 1 for x in range(self.n)]

    def to_stored(self, w) -> int:
        cw = 0
        for x in range(self.n):
            cw |= w[x] << self.l2s[x]
        return cw

    def encode_plain(self, d: int) -> int:
        assert 0 <= d <= self.mask_k
        w = [0] * self.n
        for i, x in enumerate(self.data_slots):
            w[x] = (d >> i) & 1
        for j in range(self.r):                          # check bit j at position 2**j
            p = 0
            for x in self.data_slots:
                if (x >> j) & 1:
                    p ^= w[x]
            w[1 << j] = p
        t = 0
        for x in range(1, self.n):
            t ^= w[x]
        w[0] = t                                         # even overall parity
        return self.to_stored(w)

    def decode(self, rx: int) -> Dec:
        plain = rx ^ (self.inv << self.k)
        w = self.to_logical(plain)
        s = 0
        for x in range(1, self.n):
            if w[x]:
                s ^= x                                   # syndrome = XOR of positions of set bits
        P = 0
        for x in range(self.n):
            P ^= w[x]
        syn = (P << self.r) | s
        raw_d = plain & self.mask_k
        if s == 0 and P == 0:
            return Dec(NONE, raw_d, rx, 0, syn)
        if P == 1:
            if s == 0:
                b = self.k + self.r                      # overall-parity bit flipped
            elif s <= self.k + self.r:
                b = self.l2s[s]
            else:
                return Dec(UE, raw_d, rx, 0, syn)        # position does not exist: >= 3 errors
            return Dec(CE, (plain ^ (1 << b)) & self.mask_k, rx ^ (1 << b), b, syn)
        return Dec(UE, raw_d, rx, 0, syn)                # P == 0, s != 0: even number of errors


# --------------------------------------------------------------------------- RefC
class RefC(_Base):
    """GF(2) linear algebra: code = null space of the logical H_L; brute-force decode."""

    def __init__(self, k: int = K, inv: int = 0):
        super().__init__(k, inv)
        n, r = self.n, self.r
        # logical H_L: (r+1) x n, column x = [1 ; bin(x)]   (bit r of the column = ones row)
        self.hl_cols = [(1 << r) | x for x in range(n)]
        self.red = [0] + [1 << j for j in range(r)]              # redundancy positions (r+1)
        self.info = [x for x in range(1, k + r + 1) if x not in self.red]
        assert len(self.info) == k and len(self.red) == r + 1
        self.inv_hr = self._invert([self.hl_cols[x] for x in self.red])
        self.l2s = {x: i for i, x in enumerate(self.info)}
        self.l2s.update({x: k + j for j, x in enumerate(self.red[1:])})
        self.l2s[0] = k + r
        assert sorted(self.l2s.values()) == list(range(n))
        # stored bit -> logical position (for syndrome evaluation)
        self.s2l = {v: x for x, v in self.l2s.items()}

    @staticmethod
    def _invert(cols):
        """Invert a square GF(2) matrix given as column bit-vectors (bit r = row r)."""
        n = len(cols)
        m = [[(cols[c] >> r) & 1 for c in range(n)] + [1 if r == c else 0 for c in range(n)]
             for r in range(n)]
        for c in range(n):
            piv = next(r for r in range(c, n) if m[r][c])
            m[c], m[piv] = m[piv], m[c]
            for r in range(n):
                if r != c and m[r][c]:
                    m[r] = [a ^ b for a, b in zip(m[r], m[c])]
        return [sum(m[r][n + c] << c for c in range(n)) for r in range(n)]

    def _hl_syn(self, plain: int) -> int:
        """H_L * (word given in STORED order)."""
        v = 0
        w = plain
        b = 0
        while w:
            if w & 1:
                v ^= self.hl_cols[self.s2l[b]]
            w >>= 1
            b += 1
        return v

    def encode_plain(self, d: int) -> int:
        assert 0 <= d <= self.mask_k
        rhs = 0
        for i, x in enumerate(self.info):
            if (d >> i) & 1:
                rhs ^= self.hl_cols[x]                   # H_I * d
        c = 0
        for row in range(self.r + 1):                    # c = H_R^{-1} * rhs
            c |= parity(self.inv_hr[row] & rhs) << row
        cw = d
        for row, x in enumerate(self.red):
            cw |= ((c >> row) & 1) << self.l2s[x]
        assert self._hl_syn(cw) == 0
        return cw

    def decode(self, rx: int) -> Dec:
        plain = rx ^ (self.inv << self.k)
        syn = self._hl_syn(plain)
        raw_d = plain & self.mask_k
        if syn == 0:
            return Dec(NONE, raw_d, rx, 0, syn)
        hits = [b for b in range(self.n) if self._hl_syn(plain ^ (1 << b)) == 0]
        assert len(hits) <= 1, "two codewords at distance 1 -- distance < 3"
        if hits:
            b = hits[0]
            return Dec(CE, (plain ^ (1 << b)) & self.mask_k, rx ^ (1 << b), b, syn)
        return Dec(UE, raw_d, rx, 0, syn)


# ------------------------------------------------------------------ helpers
def default_inv(k: int = K) -> int:
    """First pair (a<b) of the r+1 inversion bits such that BOTH the all-zero and
    the all-ones stored words decode as UE (brute force with the RefC decoder)."""
    r = r_for(k)
    allones = (1 << (k + r + 1)) - 1
    for a, b in itertools.combinations(range(r + 1), 2):
        c = RefC(k, inv=(1 << a) | (1 << b))
        if c.decode(0).cls == UE and c.decode(allones).cls == UE:
            return (1 << a) | (1 << b)
    return 0x3          # no pair satisfies both; all-zero is still UE for any even-weight inversion


if __name__ == "__main__":
    a, b, c = RefA(), RefB(), RefC()
    for d in (0, (1 << K) - 1, 1, 1 << 63, 0x0123456789ABCDEF):
        x, y, z = a.encode(d), b.encode(d), c.encode(d)
        assert x == y == z, (hex(d), hex(x), hex(y), hex(z))
        print(f"d={d:016x} cw={x:018x}")
    print("default INV =", hex(default_inv()))
