#!/usr/bin/env python3
"""Project 77 -- verify the SECDED mathematical model BEFORE any RTL is connected.

  python3 -I model/verify_math.py            # from the project root

What is proved / checked (every statement is computed here, none is assumed):

  S1  structure   H columns non-zero + distinct (d>=3), no three columns sum to
                  zero (d>=4, all C(72,3) triples), a weight-4 dependency exists
                  (d = 4 exactly).  => SEC + DED for every error pattern of
                  weight 1 and 2, for every data word (the code is linear).
  S2  hand-derived facts that need no implementation at all (single-data-bit
                  words, all-zero, all-ones).
  S3  encode   RefA == RefB == RefC == Project-26 model, on structured + random
                  data, INV = 0 and INV = default.
  S4  decode   the same four models agree field-by-field (class, data, corrected
                  word, bit index, syndrome) on: every single-bit error, every
                  double-bit error, every triple-bit error (data = 0), random
                  weight 3..12 patterns, random raw words.  For K=8 the ENTIRE
                  received-word space (2^13) is compared.
  S5  guarantees  weight-1 => CE with the right bit and original data restored;
                  weight-2 => UE, decoder never returns "corrected" data.
  S6  beyond-distance characterisation (NOT a guarantee): exact counts for
                  weight 3,4,5; sampled for 6..8.
  S7  golden vector files for the RTL testbenches.
"""
from __future__ import annotations

import hashlib
import importlib.util
import itertools
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import secded_model as M                      # noqa: E402

# Project-26 model (independent prior implementation), loaded by path
_spec = importlib.util.spec_from_file_location("p26_secded_ref", os.path.join(ROOT, "third_party", "sfras_ref", "secded_ref.py"))
P26 = importlib.util.module_from_spec(_spec)
sys.modules["p26_secded_ref"] = P26
_spec.loader.exec_module(P26)

LOG = []


def log(msg=""):
    print(msg, flush=True)
    LOG.append(msg)


def p26_tuple(res):
    # P26 DecodeResult: cls, data, cw_corr, idx, syn  (idx only meaningful for CE)
    return (res.cls, res.data, res.cw_corr, res.idx if res.cls == M.CE else 0, res.syn)


def flips(cw: int, positions) -> int:
    for p in positions:
        cw ^= 1 << p
    return cw


def structured_data(k: int):
    mk = (1 << k) - 1
    out = [0, mk, 1, 1 << (k - 1)]
    out += [1 << i for i in range(k)]
    out += [mk ^ (1 << i) for i in range(k)]
    a5 = int("A5" * ((k + 7) // 8), 16) & mk
    out += [a5, a5 ^ mk, int("AA" * ((k + 7) // 8), 16) & mk, int("55" * ((k + 7) // 8), 16) & mk]
    for b in range(0, k, 8):                       # byte lane FF / 00 patterns
        out.append(((1 << min(8, k - b)) - 1) << b)
        out.append(mk ^ (((1 << min(8, k - b)) - 1) << b))
    seen, res = set(), []
    for d in out:
        if d not in seen:
            seen.add(d)
            res.append(d)
    return res


# =================================================================== S1
def s1_structure(k: int):
    a = M.RefA(k)
    n, r = a.n, a.r
    cols = [None] * n
    for b in range(n):
        c = 0
        for j, row in enumerate(a.rows):
            c |= ((row >> b) & 1) << j
        cols[b] = c
    assert all(c != 0 for c in cols), "zero column => a single error is invisible"
    assert len(set(cols)) == n, "repeated column => two single errors alias"
    # no 3 columns XOR to zero  (=> no codeword of weight <= 3)
    t3 = 0
    for x, y in itertools.combinations(range(n), 2):
        need = cols[x] ^ cols[y]
        t3 += 1
        for z in range(y + 1, n):
            assert cols[z] != need, f"weight-3 codeword at stored bits {x},{y},{z}"
    # and a weight-4 dependency exists
    dep4 = None
    for q in itertools.combinations(range(n), 4):
        if cols[q[0]] ^ cols[q[1]] ^ cols[q[2]] ^ cols[q[3]] == 0:
            dep4 = q
            break
    assert dep4 is not None
    return {"k": k, "r": r, "n": n, "columns_distinct_nonzero": True,
            "triples_checked": n * (n - 1) * (n - 2) // 6, "min_distance": 4, "weight4_example": list(dep4)}


# =================================================================== S2
def s2_hand_facts(refs):
    k = M.K
    dpos = M.data_positions(k)
    for ref in refs:
        assert ref.encode_plain(0) == 0
        assert ref.encode_plain((1 << k) - 1) == (1 << ref.n) - 1       # all-ones data -> all-ones word
        for i in range(k):
            p = dpos[i]                                                 # hand rule: checks = binary(position)
            expect = (1 << i) | (p << k) | ((1 ^ M.parity(p)) << (k + 7))   # overall parity = parity(1 data bit + checks)
            assert ref.encode_plain(1 << i) == expect, (type(ref).__name__, i)
    return True


# =================================================================== S3 / S4
def make_refs(k: int, inv: int):
    return M.RefA(k, inv), M.RefB(k, inv), M.RefC(k, inv), P26.Secded(k, inv=inv)


def check_encode(k: int, inv: int, data, rnd):
    A, B, C, P = make_refs(k, inv)
    n = 0
    for d in data:
        x = A.encode(d)
        assert x == B.encode(d) == C.encode(d) == P.encode(d), (k, inv, hex(d))
        n += 1
    return n


def agree(res_list, ctx):
    t0 = res_list[0]
    for r in res_list[1:]:
        assert r == t0, (ctx, t0, r)


def check_decode_set(k: int, inv: int, words, use_c=True, use_p26=True, use_b=True):
    A, B, C, P = make_refs(k, inv)
    n = 0
    for rx in words:
        ra = A.decode(rx).tup()
        if use_b:
            assert B.decode(rx).tup() == ra, (k, inv, hex(rx), "B", ra, B.decode(rx).tup())
        if use_c:
            assert C.decode(rx).tup() == ra, (k, inv, hex(rx), "C")
        if use_p26:
            assert p26_tuple(P.decode(rx)) == ra, (k, inv, hex(rx), "P26", ra, p26_tuple(P.decode(rx)))
        n += 1
    return n


def s45_guarantees(k: int, inv: int, data):
    """weight 1 -> CE + restored data; weight 2 -> UE + raw data (never 'corrected')."""
    A = M.RefA(k, inv)
    n = A.n
    c1 = c2 = 0
    for d in data:
        cw = A.encode(d)
        assert A.decode(cw).cls == M.NONE and A.decode(cw).data == d
        for p in range(n):
            res = A.decode(cw ^ (1 << p))
            assert res.cls == M.CE and res.pos == p and res.data == d and res.cw == cw, (k, hex(d), p)
            c1 += 1
        for p, q in itertools.combinations(range(n), 2):
            rx = cw ^ (1 << p) ^ (1 << q)
            res = A.decode(rx)
            assert res.cls == M.UE and res.cw == rx, (k, hex(d), p, q)
            # decoder must not have 'corrected' anything: data is the raw stored data
            assert res.data == (rx ^ (inv << k)) & A.mask_k
            c2 += 1
    return c1, c2


# =================================================================== S6
def s6_characterise(k: int = M.K, sample=200_000, seed=0x77):
    A = M.RefA(k)
    n, r = A.n, A.r
    cols = [0] * n
    for b in range(n):
        c = 0
        for j, row in enumerate(A.rows):
            c |= ((row >> b) & 1) << j
        cols[b] = c
    pbit = 1 << r
    valid = set(cols)                              # H columns: syndromes that name a stored bit
    rows = {}
    rnd = random.Random(seed)

    def classify(v):
        # v = H * error pattern = {P, s}
        if v == 0:
            return "undetected"
        return "ce_mis" if v in valid else "ue"

    for w in (3, 4, 5):
        cnt = {"undetected": 0, "ce_mis": 0, "ue": 0}
        tot = 0
        for comb in itertools.combinations(cols, w):
            v = 0
            for c in comb:
                v ^= c
            cnt[classify(v)] += 1
            tot += 1
        rows[w] = (tot, cnt, "exact")
    for w in (6, 7, 8):
        cnt = {"undetected": 0, "ce_mis": 0, "ue": 0}
        for _ in range(sample):
            v = 0
            for b in rnd.sample(range(n), w):
                v ^= cols[b]
            cnt[classify(v)] += 1
        rows[w] = (sample, cnt, "sampled")
    return rows


# =================================================================== S7
def write_vectors(outdir, k, inv, tag, rnd, big=True):
    os.makedirs(outdir, exist_ok=True)
    A = M.RefA(k, inv)
    n = A.n
    data = structured_data(k)
    rdata = [rnd.getrandbits(k) for _ in range(2000 if k >= 32 else 300)]
    # ---- encode
    with open(os.path.join(outdir, f"enc_{tag}.hex"), "w") as f:
        if k <= 8:
            alld = list(range(1 << k))
        else:
            alld = data + rdata
        for d in alld:
            f.write(f"{d:x} {A.encode(d):x}\n")
        nenc = len(alld)
    # ---- decode
    lines = []

    def emit(rx):
        r = A.decode(rx)
        lines.append(f"{rx:x} {r.cls:x} {r.data:x} {r.cw:x} {r.pos if r.cls == M.CE else 0:x} {r.syn:x}")

    ndata1 = data[:24] if big else data[:6]
    for d in ndata1:                                         # every single-bit error
        cw = A.encode(d)
        for p in range(n):
            emit(cw ^ (1 << p))
    for d in (data[:8] if big else data[:2]):                # every double-bit error
        cw = A.encode(d)
        for p, q in itertools.combinations(range(n), 2):
            emit(cw ^ (1 << p) ^ (1 << q))
    for d in data[:12]:                                      # clean words
        emit(A.encode(d))
    if k == 64 and big:                                      # every triple-bit error for data = 0
        cw = A.encode(0)
        for t in itertools.combinations(range(n), 3):
            emit(cw ^ (1 << t[0]) ^ (1 << t[1]) ^ (1 << t[2]))
    if k <= 8:                                               # the complete received-word space
        for rx in range(1 << n):
            emit(rx)
    for _ in range(20000 if (k == 64 and big) else 3000):    # random weight 3..12 on random data
        d = rnd.getrandbits(k)
        w = rnd.randint(3, 12)
        emit(flips(A.encode(d), rnd.sample(range(n), w)))
    for _ in range(6000 if (k == 64 and big) else 1000):     # random raw words
        emit(rnd.getrandbits(n))
    emit(0)
    emit((1 << n) - 1)
    with open(os.path.join(outdir, f"dec_{tag}.hex"), "w") as f:
        f.write("\n".join(lines) + "\n")
    return nenc, len(lines)


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def main():
    t0 = time.time()
    rnd = random.Random(0x77)
    summary = {}
    log("# Project 77 -- SECDED mathematical model verification")
    log("")
    log("Generated by `model/verify_math.py` (deterministic, seed 0x77). Four independent implementations are compared:")
    log("RefA (H-matrix column search), RefB (textbook interleaved Hamming), RefC (GF(2) nullspace + brute-force decode),")
    log("and the Project-26 reference model (`third_party/sfras_ref/secded_ref.py`).")
    log("")

    # ---- S1
    log("## S1  Code structure (distance)")
    log("")
    log("| k | r | n | H columns distinct & non-zero | triples checked (none dependent) | d_min | weight-4 dependency (stored bits) |")
    log("|---|---|---|---|---|---|---|")
    ks = (8, 16, 32, 57, 64, 128)
    s1 = []
    for k in ks:
        s = s1_structure(k)
        s1.append(s)
        log(f"| {k} | {s['r']} | {s['n']} | yes | {s['triples_checked']:,} | {s['min_distance']} | {s['weight4_example']} |")
    summary["s1"] = s1
    log("")
    log("`d_min = 4` follows: no 1, 2 or 3 columns of H are linearly dependent (so no codeword of weight <= 3) and a")
    log("weight-4 dependency exists. Hence every 1-bit error is correctable and every 2-bit error detectable, for **every**")
    log("data word (the code is linear: the verdict depends only on the error pattern).")
    log("")

    # ---- S2
    refs64 = (M.RefA(), M.RefB(), M.RefC())
    s2_hand_facts(refs64)
    log("## S2  Hand-derived facts (no implementation needed)")
    log("")
    log("* all-zero data -> all-zero stored word; all-ones data -> **all-ones** stored word (so with INV=0 both are valid codewords)")
    log("* a word with only data bit i set has checks = binary(position of bit i) and overall parity = 1 xor parity(position)")
    log("  (e.g. data=1 -> position 3 -> checks 0000011, parity 1 -> stored `0x83_0000_0000_0000_0001`; data bit 63 -> position 71 = 1000111 -> `0xC7_8000_0000_0000_0000`)")
    log("* asserted for all 64 single-bit data words in RefA, RefB and RefC: PASS")
    log("")

    # ---- default inversion
    dinv = M.default_inv(64)
    p26inv = P26.default_inv_for(64)
    assert dinv == p26inv, (dinv, p26inv)
    log("## Check-bit inversion mask")
    log("")
    log(f"Default `CHK_INV` for k=64 = **0x{dinv:02x}** (first bit pair whose inversion makes BOTH the all-zero and the all-ones stored word")
    log(f"uncorrectable; brute force with RefC). Project 26 independently computes 0x{p26inv:02x}: match.")
    A0 = M.RefA(64, 0)
    Ad = M.RefA(64, dinv)
    log(f"With INV=0: all-zero word -> {M.CLASS_NAME[A0.decode(0).cls]}, all-ones word -> {M.CLASS_NAME[A0.decode((1 << 72) - 1).cls]}.  "
        f"With INV=0x{dinv:02x}: all-zero -> {M.CLASS_NAME[Ad.decode(0).cls]}, all-ones -> {M.CLASS_NAME[Ad.decode((1 << 72) - 1).cls]}.")
    assert Ad.decode(0).cls == M.UE and Ad.decode((1 << 72) - 1).cls == M.UE
    log("")
    summary["default_inv_k64"] = dinv

    # ---- S3 encode
    log("## S3  Encoder agreement (RefA == RefB == RefC == Project-26)")
    log("")
    log("| k | INV | words | result |")
    log("|---|---|---|---|")
    for k in (8, 16, 32, 64, 128):
        inv_set = (0, M.default_inv(k))
        for inv in inv_set:
            if k == 8:
                data = list(range(256))
            else:
                data = structured_data(k) + [rnd.getrandbits(k) for _ in range(1500)]
            n = check_encode(k, inv, data, rnd)
            log(f"| {k} | 0x{inv:x} | {n:,} | PASS |")
    log("")

    # ---- S4 decode
    log("## S4  Decoder agreement (all four models, field by field)")
    log("")
    log("Compared fields: class, returned data, corrected stored word, corrected-bit index (CE only), syndrome {P,s}.")
    log("")
    log("| set | k | INV | received words | models compared | result |")
    log("|---|---|---|---|---|---|")
    A64 = M.RefA(64, 0)
    for inv in (0, dinv):
        A = M.RefA(64, inv)
        dsets = structured_data(64)[:6]
        # every single-bit error
        w = []
        for d in dsets:
            cw = A.encode(d)
            w += [cw ^ (1 << p) for p in range(72)]
        n1 = check_decode_set(64, inv, w)
        log(f"| every 1-bit error x {len(dsets)} data | 64 | 0x{inv:x} | {n1:,} | A,B,C,P26 | PASS |")
        # every double-bit error (C on fewer)
        w = []
        for d in dsets[:2]:
            cw = A.encode(d)
            w += [cw ^ (1 << p) ^ (1 << q) for p, q in itertools.combinations(range(72), 2)]
        n2 = check_decode_set(64, inv, w)
        log(f"| every 2-bit error x 2 data (all C(72,2)=2556) | 64 | 0x{inv:x} | {n2:,} | A,B,C,P26 | PASS |")
        # more data for doubles without C
        w = []
        for d in structured_data(64)[6:40]:
            cw = A.encode(d)
            w += [cw ^ (1 << p) ^ (1 << q) for p, q in itertools.combinations(range(72), 2)]
        n2b = check_decode_set(64, inv, w, use_c=False)
        log(f"| every 2-bit error x 34 more data | 64 | 0x{inv:x} | {n2b:,} | A,B,P26 | PASS |")
        # all triples for d = 0 (C excluded: brute force is slow; checked on a sample below)
        cw0 = A.encode(0)
        w = [cw0 ^ (1 << a) ^ (1 << b) ^ (1 << c) for a, b, c in itertools.combinations(range(72), 3)]
        n3 = check_decode_set(64, inv, w, use_c=False)
        log(f"| every 3-bit error, data=0 (all C(72,3)=59,640) | 64 | 0x{inv:x} | {n3:,} | A,B,P26 | PASS |")
        w = []
        for _ in range(400):
            d = rnd.getrandbits(64)
            w.append(flips(A.encode(d), rnd.sample(range(72), rnd.randint(3, 12))))
        for _ in range(400):
            w.append(rnd.getrandbits(72))
        n4 = check_decode_set(64, inv, w)
        log(f"| random weight 3..12 + random raw words (sample) | 64 | 0x{inv:x} | {n4:,} | A,B,C,P26 | PASS |")
    # complete received-word space for k = 8
    for inv in (0, M.default_inv(8)):
        n8 = check_decode_set(8, inv, range(1 << 13))
        log(f"| **entire received-word space** 2^13 | 8 | 0x{inv:x} | {n8:,} | A,B,C,P26 | PASS |")
    for k in (16, 32, 128):
        for inv in (0, M.default_inv(k)):
            A = M.RefA(k, inv)
            w = []
            for d in structured_data(k)[:4]:
                cw = A.encode(d)
                w += [cw ^ (1 << p) for p in range(A.n)]
                w += [cw ^ (1 << p) ^ (1 << q) for p, q in itertools.combinations(range(A.n), 2)]
            for _ in range(300):
                w.append(flips(A.encode(rnd.getrandbits(k)), rnd.sample(range(A.n), rnd.randint(3, 9))))
            nn = check_decode_set(k, inv, w, use_c=(k <= 32))
            log(f"| all 1-bit + all 2-bit x 4 data + 300 random | {k} | 0x{inv:x} | {nn:,} | A,B,{'C,' if k <= 32 else ''}P26 | PASS |")
    log("")

    # ---- S5
    log("## S5  Guarantees on real words")
    log("")
    log("| k | INV | data words | 1-bit errors (all positions) | 2-bit errors (all pairs) | result |")
    log("|---|---|---|---|---|---|")
    for k, inv, nd in ((64, 0, 64), (64, dinv, 64), (8, 0, 256), (16, 0, 64), (32, 0, 32), (128, 0, 8)):
        data = list(range(256)) if k == 8 else structured_data(k)[:nd]
        c1, c2 = s45_guarantees(k, inv, data)
        log(f"| {k} | 0x{inv:x} | {len(data)} | {c1:,} corrected (data restored, right bit) | {c2:,} flagged UE (data NOT presented as corrected) | PASS |")
    log("")

    # ---- S6
    rows = s6_characterise()
    log("## S6  Beyond the code distance (characterisation, NOT a guarantee)")
    log("")
    log("Error patterns of weight >= 3 are outside the SECDED guarantee. Odd-weight patterns whose syndrome equals a valid column are")
    log("**miscorrected** (a wrong bit is flipped and reported as CE); even-weight patterns whose syndrome is 0 are **undetected**")
    log("(they are valid codewords). Exact for w=3,4,5; Monte-Carlo (200,000 samples, seed 0x77) for w=6,7,8.")
    log("")
    log("| weight | patterns | method | miscorrected as CE | flagged UE | undetected (valid codeword) |")
    log("|---|---|---|---|---|---|")
    s6 = {}
    for w, (tot, cnt, how) in rows.items():
        log(f"| {w} | {tot:,} | {how} | {cnt['ce_mis']:,} ({100*cnt['ce_mis']/tot:.2f} %) | {cnt['ue']:,} ({100*cnt['ue']/tot:.2f} %) | {cnt['undetected']:,} ({100*cnt['undetected']/tot:.3f} %) |")
        s6[w] = {"patterns": tot, "method": how, **cnt}
    summary["s6"] = s6
    # cross-check with Project-26's published exhaustive figures
    t3 = rows[3]
    assert abs(100 * t3[1]["ue"] / t3[0] - 24.04) < 0.01, "differs from Project-26's published 3-bit figure"
    assert abs(100 * rows[4][1]["undetected"] / rows[4][0] - 1.10) < 0.01, "differs from Project-26's published 4-bit figure"
    log("")
    log("The weight-3 (24.04 % / 75.96 %) and weight-4 (1.10 %) figures match those published independently by Project 26 (`docs/01_ecc_architecture.md`).")
    log("")

    # ---- S7
    log("## S7  Golden vector files")
    log("")
    vdir = os.path.join(ROOT, "vectors")
    log("| file | lines | sha256 (first 16) |")
    log("|---|---|---|")
    vrnd = random.Random(0x7777)
    files = []
    for tag, inv in (("inv0", 0), ("invd", dinv)):
        ne, nd = write_vectors(vdir, 64, inv, tag, vrnd, big=(tag == "inv0"))
        files += [(f"enc_{tag}.hex", ne), (f"dec_{tag}.hex", nd)]
    for k in (8, 16, 32, 128):
        for tag, inv in (("inv0", 0),):
            ne, nd = write_vectors(os.path.join(vdir, f"k{k}"), k, inv, tag, vrnd, big=False)
            files += [(f"k{k}/enc_{tag}.hex", ne), (f"k{k}/dec_{tag}.hex", nd)]
    # ---- extra sets for the wrapper testbench (appended AFTER the random generation so earlier files are unchanged)
    ne, nd = write_vectors(os.path.join(vdir, "k32"), 32, M.default_inv(32), "invd", vrnd, big=False)
    files += [("k32/enc_invd.hex", ne), ("k32/dec_invd.hex", nd)]
    # ---- syndrome tables: the expected {P,s} of every single-bit and every double-bit error pattern
    #      (depends only on the error pattern, not on data or INV)
    for k in (64, 32):
        A = M.RefA(k, 0)
        d = os.path.join(vdir, "" if k == 64 else f"k{k}")
        cw = A.encode(0x5A5A5A5A5A5A5A5A & ((1 << k) - 1))
        with open(os.path.join(d, "syn_single.hex"), "w") as f:
            for b in range(A.n):
                r = A.decode(cw ^ (1 << b))
                assert r.cls == M.CE and r.pos == b
                f.write(f"{b:x} {r.syn:x}\n")
        with open(os.path.join(d, "syn_double.hex"), "w") as f:
            for i, j in itertools.combinations(range(A.n), 2):
                r = A.decode(cw ^ (1 << i) ^ (1 << j))
                assert r.cls == M.UE
                f.write(f"{i:x} {j:x} {r.syn:x}\n")
        files += [((f"k{k}/" if k != 64 else "") + "syn_single.hex", A.n),
                  ((f"k{k}/" if k != 64 else "") + "syn_double.hex", A.n * (A.n - 1) // 2)]
    vsum = {}
    for fn, cnt in files:
        h = sha(os.path.join(vdir, fn))
        vsum[fn] = {"lines": cnt, "sha256": h}
        log(f"| `vectors/{fn}` | {cnt:,} | `{h[:16]}` |")
    summary["vectors"] = vsum
    log("")
    log(f"All checks passed in {time.time()-t0:.1f} s.")

    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports", "math_verification.md"), "w") as f:
        f.write("\n".join(LOG) + "\n")
    with open(os.path.join(ROOT, "reports", "math_verification.json"), "w") as f:
        json.dump(summary, f, indent=1, default=str)


if __name__ == "__main__":
    main()
