"""Independent FP32 oracle: exact integer arithmetic + GNU MPFR rounding (gmpy2).

Written for this framework, independently of SoftFloat and of the RTL authors'
models, to validate the primary oracle (SoftFloat-3e).  Method:

* every finite operand is decoded to an exact dyadic (-1)^s * M * 2^E;
* a+b, a*b and a*b+c are computed EXACTLY with Python integers;
* the exact value is rounded by MPFR into binary32
  (precision 24, emin -148, emax 128, subnormalize) and, for tininess, into 24
  bits with an unbounded exponent range;
* flags follow IEEE 754-2019 default exception handling (RISC-V conventions):
  OF = rounded-with-unbounded-exponent magnitude > max finite (NX also set);
  UF = tiny after rounding AND inexact;  NX = delivered != exact;
  NV per the NaN / inf / zero rules below;  DZ never (no division).
* RMM (ties away) is derived from the toward-zero / away-from-zero candidates
  because MPFR has no ties-away rounding attribute.
* NaN results are the canonical quiet NaN 0x7FC00000 (RISC-V);
  NV for any signalling-NaN input, inf-inf, 0*inf (FMA: even with a quiet-NaN
  addend).

Not modelled here: FMV/IADD/IMUL are trivial bit operations; they are checked
against SoftFloat-shim results by construction.
"""
from __future__ import annotations

import gmpy2
from gmpy2 import mpfr

CNAN = 0x7FC00000
NV, DZ, OF, UF, NX = 16, 8, 4, 2, 1
MAXF = (2 ** 24 - 1) * 2 ** 104                        # largest finite, exact integer
_MODES = {0: gmpy2.RoundToNearest, 1: gmpy2.RoundToZero, 2: gmpy2.RoundDown, 3: gmpy2.RoundUp}
_CTX32 = {m: gmpy2.context(precision=24, emin=-148, emax=128, subnormalize=True, round=r)
          for m, r in list(_MODES.items()) + [("A", gmpy2.RoundAwayZero)]}
_CTXU = {m: gmpy2.context(precision=24, emin=-(1 << 30), emax=(1 << 30), round=r)
         for m, r in list(_MODES.items()) + [("A", gmpy2.RoundAwayZero)]}
_CTXW = gmpy2.context(precision=2048, emin=-(1 << 30), emax=(1 << 30))


def _isnan(x):  return (x & 0x7F800000) == 0x7F800000 and (x & 0x7FFFFF) != 0
def _issnan(x): return _isnan(x) and not (x & 0x400000)
def _isinf(x):  return (x & 0x7FFFFFFF) == 0x7F800000
def _iszero(x): return (x & 0x7FFFFFFF) == 0


def _dec(x):
    """finite x -> (sign, M, E): value = (-1)^sign * M * 2^E (exact)."""
    s, e, f = x >> 31, (x >> 23) & 0xFF, x & 0x7FFFFF
    return (s, f, -149) if e == 0 else (s, f | 0x800000, e - 150)


def _exact_mpfr(n: int, e: int):
    with gmpy2.local_context(_CTXW):
        return gmpy2.mul_2exp(mpfr(n), e)              # exact: |n| < 2^2048


def _round(ctxs, n: int, e: int, rm: int):
    """round the exact value n*2^e (n != 0) in context family ctxs."""
    x = _exact_mpfr(n, e)
    if rm != 4:
        with gmpy2.local_context(ctxs[rm]):
            return +x
    with gmpy2.local_context(ctxs[1]):
        lo = +x
    with gmpy2.local_context(ctxs["A"]):
        hi = +x
    if lo == hi:
        return lo
    hv = hi if not gmpy2.is_infinite(hi) else (mpfr(2) ** 128 if hi > 0 else -mpfr(2) ** 128)
    with gmpy2.local_context(_CTXW):
        mid = (lo + hv) / 2                            # exact at 2048 bits
        return hi if abs(x) >= abs(mid) else lo


def _encode(r, sign_if_zero: int) -> int:
    if gmpy2.is_infinite(r):
        return 0x7F800000 | (0x80000000 if r < 0 else 0)
    if r == 0:
        return (sign_if_zero & 1) << 31
    s = 1 if r < 0 else 0
    m, e = abs(r).as_mantissa_exp()
    m, e = int(m), int(e)
    E = m.bit_length() - 1 + e                         # 2^E <= |r| < 2^(E+1)
    if E < -126:
        return (s << 31) | _scale(m, e, -149)          # subnormal: multiple of 2^-149
    return (s << 31) | ((E + 127) << 23) | (_scale(m, e, E - 23) - (1 << 23))


def _scale(m: int, e: int, te: int) -> int:
    """m * 2^(e - te) as an exact integer (asserts exactness)."""
    d = e - te
    if d >= 0:
        return m << d
    assert m & ((1 << -d) - 1) == 0, "value not representable at the target exponent"
    return m >> -d


def _finish(n: int, e: int, rm: int, zero_sign: int):
    """round exact n*2^e (n may be 0: exact zero with sign zero_sign)."""
    if n == 0:
        return (zero_sign & 1) << 31, 0
    neg = n < 0
    ru = _round(_CTXU, n, e, rm)                       # unbounded exponent, 24 bits
    if abs(ru) > MAXF:                                 # overflow
        inf = rm in (0, 4) or (rm == 3 and not neg) or (rm == 2 and neg)
        mag = 0x7F800000 if inf else 0x7F7FFFFF
        return mag | (0x80000000 if neg else 0), OF | NX
    r32 = _round(_CTX32, n, e, rm)
    exact = _exact_mpfr(n, e)
    inexact = r32 != exact
    tiny = abs(ru) < mpfr(2) ** -126
    flags = (NX if inexact else 0) | (UF if (tiny and inexact) else 0)
    return _encode(r32, 1 if neg else 0), flags


def _zero_sum_sign(s1, s2, rm):
    return s1 if s1 == s2 else (1 if rm == 2 else 0)


def add(a, b, rm, negb=False):
    if negb:
        b ^= 0x80000000
    if _isnan(a) or _isnan(b):
        return CNAN, NV if (_issnan(a) or _issnan(b)) else 0
    if _isinf(a) or _isinf(b):
        if _isinf(a) and _isinf(b) and (a >> 31) != (b >> 31):
            return CNAN, NV
        return (a if _isinf(a) else b), 0
    sa, Ma, Ea = _dec(a)
    sb, Mb, Eb = _dec(b)
    e = min(Ea, Eb)
    n = (-1) ** sa * (Ma << (Ea - e)) + (-1) ** sb * (Mb << (Eb - e))
    zs = _zero_sum_sign(sa, sb, rm) if (Ma == 0 and Mb == 0) else (1 if rm == 2 else 0)
    return _finish(n, e, rm, zs)


def mul(a, b, rm):
    if _isnan(a) or _isnan(b):
        return CNAN, NV if (_issnan(a) or _issnan(b)) else 0
    s = (a ^ b) >> 31
    if _isinf(a) or _isinf(b):
        if _iszero(a) or _iszero(b):
            return CNAN, NV
        return 0x7F800000 | (s << 31), 0
    sa, Ma, Ea = _dec(a)
    sb, Mb, Eb = _dec(b)
    n = Ma * Mb * (-1) ** s
    return _finish(n, Ea + Eb, rm, s)


def fma(a, b, c, rm, negp=False, negc=False):
    """(+/-)(a*b) (+/-) c with one rounding; RISC-V NaN / NV rules."""
    if negp:
        a ^= 0x80000000
    if negc:
        c ^= 0x80000000
    sn = _issnan(a) or _issnan(b) or _issnan(c)
    inf0 = (_isinf(a) and _iszero(b)) or (_iszero(a) and _isinf(b))
    if _isnan(a) or _isnan(b):
        return CNAN, NV if sn else 0
    if inf0:
        return CNAN, NV                                # even with a quiet-NaN addend
    if _isnan(c):
        return CNAN, NV if sn else 0
    sp = (a ^ b) >> 31
    if _isinf(a) or _isinf(b):
        if _isinf(c) and (c >> 31) != sp:
            return CNAN, NV
        return 0x7F800000 | (sp << 31), 0
    if _isinf(c):
        return c, 0
    sa, Ma, Ea = _dec(a)
    sb, Mb, Eb = _dec(b)
    sc, Mc, Ec = _dec(c)
    Mp, Ep = Ma * Mb, Ea + Eb
    e = min(Ep, Ec)
    n = (-1) ** sp * (Mp << (Ep - e)) + (-1) ** sc * (Mc << (Ec - e))
    zs = _zero_sum_sign(sp, sc, rm) if (Mp == 0 and Mc == 0) else (1 if rm == 2 else 0)
    return _finish(n, e, rm, zs)


def _val(x):
    s, M, E = _dec(x)
    return (-1) ** s * M * gmpy2.mpq(2) ** E if not _isinf(x) else (float("-inf") if x >> 31 else float("inf"))


def _lt(a, b):
    return _val(a) < _val(b)


def _eq(a, b):
    return _val(a) == _val(b)


def compare(kind, a, b):
    """kind: 'eq' (quiet), 'lt', 'le' (signalling) -> (0/1, flags)."""
    an, bn = _isnan(a), _isnan(b)
    if an or bn:
        if kind == "eq":
            return 0, NV if (_issnan(a) or _issnan(b)) else 0
        return 0, NV
    if kind == "eq":
        return int(_eq(a, b)), 0
    if kind == "lt":
        return int(_lt(a, b)), 0
    return int(_lt(a, b) or _eq(a, b)), 0


def minmax(a, b, is_max):
    f = NV if (_issnan(a) or _issnan(b)) else 0
    an, bn = _isnan(a), _isnan(b)
    if an and bn:
        return CNAN, f
    if an:
        return b, f
    if bn:
        return a, f
    if _eq(a, b):
        if _iszero(a) and _iszero(b):                  # -0 < +0
            neg = (a >> 31) & (b >> 31) if is_max else (a >> 31) | (b >> 31)
            return neg << 31, f
        return a, f
    lt = _lt(a, b)
    return (b if lt else a) if is_max else (a if lt else b), f


def execute(opc: int, rm: int, a: int, b: int, c: int):
    """Same contract as fp32_softfloat.op (tininess after rounding). -> (res, flags, illegal)."""
    if 0x01 <= opc <= 0x07 and rm > 4:
        return 0, 0, 1
    if opc == 0x00:
        return a, 0, 0
    if opc in (0x01, 0x02):
        r, f = add(a, b, rm, negb=(opc == 0x02))
    elif opc == 0x03:
        r, f = mul(a, b, rm)
    elif 0x04 <= opc <= 0x07:
        r, f = fma(a, b, c, rm, negp=opc in (0x06, 0x07), negc=opc in (0x05, 0x07))
    elif opc in (0x08, 0x09):
        r, f = minmax(a, b, opc == 0x09)
    elif opc in (0x0A, 0x0B, 0x0C):
        r, f = compare({0x0A: "eq", 0x0B: "lt", 0x0C: "le"}[opc], a, b)
    elif opc == 0x10:
        r, f = (a + b) & 0xFFFFFFFF, 0
    elif opc == 0x11:
        r, f = (a * b) & 0xFFFFFFFF, 0
    else:
        return 0, 0, 1
    return r, f, 0


def version() -> str:
    return f"GNU MPFR {gmpy2.mpfr_version().split()[-1]} via gmpy2 {gmpy2.version()}"
