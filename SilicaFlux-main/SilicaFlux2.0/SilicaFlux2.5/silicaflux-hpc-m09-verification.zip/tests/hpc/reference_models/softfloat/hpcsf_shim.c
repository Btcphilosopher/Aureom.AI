/* =============================================================================
 * SilicaFlux-HPC verification framework :: SoftFloat-3e golden reference shim
 *
 * Primary IEEE 754 binary32 oracle for every SilicaFlux-HPC lane operation.
 * Built against Berkeley SoftFloat Release 3e (RISCV specialisation: canonical
 * quiet NaN 0x7FC00000, NaN payloads not propagated), vendored unmodified in
 * the Module 01 archive (third_party/berkeley-softfloat-3, BSD-3-Clause).
 *
 * Operation codes are the hpc_vector_pkg encodings (Module 02):
 *   0x00 FMV   0x01 FADD  0x02 FSUB  0x03 FMUL
 *   0x04 FMADD 0x05 FMSUB 0x06 FNMSUB 0x07 FNMADD
 *   0x08 FMIN  0x09 FMAX  0x0A FEQ   0x0B FLT  0x0C FLE
 *   0x10 IADD  0x11 IMUL  (others: illegal)
 *
 * Mapping to SoftFloat (identical to the RISC-V ISA simulator Spike):
 *   FMSUB  = f32_mulAdd(a, b, -c)         FNMSUB = f32_mulAdd(-a, b, c)
 *   FNMADD = f32_mulAdd(-a, b, -c)        (negation of the INPUTS, single rounding)
 *   FMIN/FMAX: IEEE 754-2019 minimumNumber/maximumNumber as RISC-V F 2.2:
 *     both NaN -> canonical NaN; one NaN -> the other operand; -0 < +0;
 *     NV iff either input is a signalling NaN (f32_lt_quiet / f32_eq raise
 *     NV for signalling NaNs only).
 *   FEQ = f32_eq (quiet), FLT = f32_lt, FLE = f32_le (signalling).
 * rm: 0 RNE, 1 RTZ, 2 RDN, 3 RUP, 4 RMM.  For a rounding operation (0x01-0x07)
 * rm 5..7 is reported as illegal (lane contract); rounding is irrelevant to
 * the other operations.
 * flags: {NV,DZ,OF,UF,NX} = bits 4..0 (RISC-V fflags order).
 * ========================================================================== */
#include <stddef.h>
#include <stdint.h>
#include "softfloat.h"

#define F32_SIGN 0x80000000u
#define CNAN     0x7FC00000u

static int is_nan(uint32_t x)  { return ((x & 0x7F800000u) == 0x7F800000u) && (x & 0x007FFFFFu); }

static uint_fast8_t map_rm(unsigned rm)
{
    switch (rm) {
    case 1:  return softfloat_round_minMag;
    case 2:  return softfloat_round_min;
    case 3:  return softfloat_round_max;
    case 4:  return softfloat_round_near_maxMag;
    default: return softfloat_round_near_even;
    }
}

static unsigned map_flags(uint_fast8_t f)
{
    unsigned r = 0;
    if (f & softfloat_flag_inexact)   r |= 1u << 0;
    if (f & softfloat_flag_underflow) r |= 1u << 1;
    if (f & softfloat_flag_overflow)  r |= 1u << 2;
    if (f & softfloat_flag_infinite)  r |= 1u << 3;
    if (f & softfloat_flag_invalid)   r |= 1u << 4;
    return r;
}

static float32_t F(uint32_t v) { float32_t f; f.v = v; return f; }

static uint32_t minmax(uint32_t a, uint32_t b, int is_max)
{
    int an = is_nan(a), bn = is_nan(b);
    /* raise NV for signalling inputs (quiet comparison does exactly that) */
    int a_lt_b = f32_lt_quiet(F(a), F(b));
    int eq     = f32_eq(F(a), F(b));
    if (an && bn) return CNAN;
    if (an) return b;
    if (bn) return a;
    if (eq) {                                   /* equal incl. +0 / -0 */
        if (is_max) return ((a & F32_SIGN) && !(b & F32_SIGN)) ? b : a;
        return ((b & F32_SIGN) && !(a & F32_SIGN)) ? b : a;
    }
    if (is_max) return a_lt_b ? b : a;
    return a_lt_b ? a : b;
}

/* returns the result; *flags receives the exception flags, *illegal 1 for an
 * illegal operation (result and flags 0) */
uint32_t hpcsf_op(unsigned op, unsigned rm, uint32_t a, uint32_t b, uint32_t c,
                  unsigned tininess_after, unsigned *flags, unsigned *illegal)
{
    uint32_t r = 0;
    int rounding = (op >= 0x01 && op <= 0x07);
    *illegal = 0;
    *flags = 0;
    if (rounding && rm > 4) { *illegal = 1; return 0; }
    softfloat_roundingMode   = map_rm(rm);
    softfloat_detectTininess = tininess_after ? softfloat_tininess_afterRounding
                                              : softfloat_tininess_beforeRounding;
    softfloat_exceptionFlags = 0;
    switch (op) {
    case 0x00: r = a; break;
    case 0x01: r = f32_add(F(a), F(b)).v; break;
    case 0x02: r = f32_sub(F(a), F(b)).v; break;
    case 0x03: r = f32_mul(F(a), F(b)).v; break;
    case 0x04: r = f32_mulAdd(F(a), F(b), F(c)).v; break;
    case 0x05: r = f32_mulAdd(F(a), F(b), F(c ^ F32_SIGN)).v; break;
    case 0x06: r = f32_mulAdd(F(a ^ F32_SIGN), F(b), F(c)).v; break;
    case 0x07: r = f32_mulAdd(F(a ^ F32_SIGN), F(b), F(c ^ F32_SIGN)).v; break;
    case 0x08: r = minmax(a, b, 0); break;
    case 0x09: r = minmax(a, b, 1); break;
    case 0x0A: r = f32_eq(F(a), F(b)) ? 1u : 0u; break;
    case 0x0B: r = f32_lt(F(a), F(b)) ? 1u : 0u; break;
    case 0x0C: r = f32_le(F(a), F(b)) ? 1u : 0u; break;
    case 0x10: r = a + b; break;
    case 0x11: r = (uint32_t)((uint64_t)a * (uint64_t)b); break;
    default:   *illegal = 1; return 0;
    }
    *flags = map_flags(softfloat_exceptionFlags);
    return r;
}

void hpcsf_batch(size_t n, const uint8_t *op, const uint8_t *rm, const uint32_t *a,
                 const uint32_t *b, const uint32_t *c, unsigned tininess_after,
                 uint32_t *res, uint8_t *flags, uint8_t *illegal)
{
    for (size_t i = 0; i < n; i++) {
        unsigned f, il;
        res[i] = hpcsf_op(op[i], rm[i], a[i], b[i], c[i], tininess_after, &f, &il);
        flags[i] = (uint8_t)f;
        illegal[i] = (uint8_t)il;
    }
}

/* sequential FP32 sum in a given order (used by the reduction model) */
uint32_t hpcsf_add(uint32_t a, uint32_t b, unsigned rm, unsigned *flags)
{
    unsigned il;
    return hpcsf_op(0x01, rm, a, b, 0, 1, flags, &il);
}

const char *hpcsf_version(void) { return "Berkeley SoftFloat Release 3e, RISCV specialisation"; }
