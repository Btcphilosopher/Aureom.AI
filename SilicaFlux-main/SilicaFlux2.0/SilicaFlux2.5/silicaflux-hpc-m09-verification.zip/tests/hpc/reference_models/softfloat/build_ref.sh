#!/usr/bin/env bash
# =============================================================================
# Build the framework's golden FP references.
#  1. Berkeley SoftFloat-3e / TestFloat-3e: built by Module 01's own, pinned
#     ref/build_ref.sh (reused unmodified; sources vendored in the M01 archive).
#  2. libhpcsf.so / hpcsf_shim.o: all-operation shim (reference_models/softfloat/
#     hpcsf_shim.c) linked against the RISCV-specialised softfloat.a.
# Outputs: tests/hpc/build/ref/{libhpcsf.so,hpcsf_shim.o,testfloat_gen,testfloat_ver}
# Idempotent.
# =============================================================================
set -euo pipefail
HPC="$(cd "$(dirname "$0")/../.." && pwd)"
BLD="${HPC_BUILD:-$HPC/build}"
M01="$BLD/src/silicaflux-hpc-fp32-fma"
OUT="$BLD/ref"
[ -d "$M01" ] || python3 "$HPC/common/fetch_rtl.py" --quiet
bash "$M01/ref/build_ref.sh" >/dev/null
SF="$M01/third_party/berkeley-softfloat-3"
SFB="$M01/build/ref/softfloat-RISCV"
mkdir -p "$OUT"
SHIM="$HPC/reference_models/softfloat/hpcsf_shim.c"
if [ ! -f "$OUT/libhpcsf.so" ] || [ "$SHIM" -nt "$OUT/libhpcsf.so" ]; then
  gcc -O2 -fPIC -Wall -Wextra -I"$SF/source/include" -I"$SFB" -c "$SHIM" -o "$OUT/hpcsf_shim.o"
  gcc -shared -o "$OUT/libhpcsf.so" "$OUT/hpcsf_shim.o" "$SFB/softfloat.a"
fi
cp -f "$SFB/softfloat.a" "$OUT/softfloat_riscv.a"
cp -f "$SF/source/include/softfloat.h" "$SF/source/include/softfloat_types.h" "$OUT/"
ln -sf "$M01/build/ref/testfloat/testfloat_gen" "$OUT/testfloat_gen"
ln -sf "$M01/build/ref/testfloat/testfloat_ver" "$OUT/testfloat_ver"
echo "reference build OK: $OUT"
